fill 489 135 568 490 135 569 minecraft:lapis_block
fill 489 135 581 490 135 582 minecraft:lapis_block
fill 491 135 569 502 135 569 minecraft:lapis_block
fill 491 135 581 502 135 581 minecraft:lapis_block
fill 492 135 567 496 135 568 minecraft:lapis_block
fill 492 135 582 496 135 583 minecraft:lapis_block
fill 493 135 564 495 135 566 minecraft:lapis_block
fill 493 135 570 495 135 572 minecraft:lapis_block
fill 493 135 584 495 135 586 minecraft:lapis_block
fill 494 135 562 494 136 563 minecraft:lapis_block
fill 494 135 587 494 136 588 minecraft:lapis_block
fill 496 135 574 505 135 576 minecraft:lapis_block
fill 497 135 580 501 135 580 minecraft:lapis_block
fill 498 135 568 502 136 568 minecraft:lapis_block
fill 498 135 582 502 136 582 minecraft:lapis_block
fill 499 135 570 500 135 572 minecraft:lapis_block
fill 500 135 567 502 136 567 minecraft:lapis_block
fill 500 135 577 500 135 579 minecraft:lapis_block
fill 500 135 583 502 136 583 minecraft:lapis_block
fill 501 135 570 501 136 571 minecraft:lapis_block
fill 501 135 577 502 136 577 minecraft:lapis_block
fill 501 135 579 501 136 579 minecraft:lapis_block
fill 503 135 566 503 136 566 minecraft:lapis_block
fill 503 135 584 503 136 584 minecraft:lapis_block
fill 506 135 575 507 136 575 minecraft:lapis_block
fill 471 136 558 480 136 598 minecraft:quartz_block
fill 481 136 558 482 136 574 minecraft:quartz_block
fill 481 136 575 484 136 575 minecraft:lapis_block
fill 481 136 576 482 136 598 minecraft:quartz_block
fill 483 136 558 484 136 573 minecraft:quartz_block
fill 483 136 574 486 136 574 minecraft:lapis_block
fill 483 136 576 486 136 576 minecraft:lapis_block
fill 483 136 577 484 136 598 minecraft:quartz_block
fill 485 136 558 492 136 565 minecraft:quartz_block
fill 485 136 567 485 136 573 minecraft:quartz_block
fill 485 136 575 489 136 575 minecraft:gold_block
fill 485 136 577 485 136 583 minecraft:quartz_block
fill 485 136 585 492 136 598 minecraft:quartz_block
fill 486 136 566 492 136 566 minecraft:quartz_block
fill 486 136 567 487 136 569 minecraft:lapis_block
fill 486 136 570 486 136 572 minecraft:quartz_block
fill 486 136 573 488 136 573 minecraft:lapis_block
fill 486 136 577 489 136 577 minecraft:lapis_block
fill 486 136 578 486 136 580 minecraft:quartz_block
fill 486 136 581 487 136 583 minecraft:lapis_block
fill 486 136 584 492 136 584 minecraft:quartz_block
fill 487 136 570 487 136 571 minecraft:lapis_block
setblock 487 136 572 minecraft:quartz_block
fill 487 136 574 490 136 574 minecraft:gold_block
fill 487 136 576 490 136 576 minecraft:gold_block
setblock 487 136 578 minecraft:quartz_block
fill 487 136 579 487 136 580 minecraft:lapis_block
fill 488 136 567 488 136 568 minecraft:lapis_block
fill 488 136 569 488 136 570 minecraft:gold_block
fill 488 136 571 488 136 572 minecraft:lapis_block
fill 488 136 578 488 136 579 minecraft:lapis_block
fill 488 136 580 489 136 581 minecraft:gold_block
fill 488 136 582 488 136 583 minecraft:lapis_block
fill 489 136 567 491 136 567 minecraft:quartz_block
fill 489 136 568 490 136 568 minecraft:lapis_block
fill 489 136 569 489 136 573 minecraft:pearlescent_froglight
fill 489 136 578 491 136 579 minecraft:gold_block
fill 489 136 582 490 136 582 minecraft:lapis_block
fill 489 136 583 491 136 583 minecraft:quartz_block
fill 490 136 569 493 136 569 minecraft:pearlescent_froglight
fill 490 136 570 492 136 572 minecraft:quartz_block
fill 490 136 573 492 136 573 minecraft:pearlescent_froglight
fill 490 136 575 491 136 575 minecraft:pearlescent_froglight
setblock 490 136 577 minecraft:gold_block
fill 490 136 580 491 136 580 minecraft:gold_block
fill 490 136 581 492 136 581 minecraft:lapis_block
setblock 491 136 568 minecraft:quartz_block
setblock 491 136 574 minecraft:pearlescent_froglight
fill 491 136 576 491 136 577 minecraft:pearlescent_froglight
setblock 491 136 582 minecraft:quartz_block
fill 492 136 567 492 136 568 minecraft:lapis_block
fill 492 136 574 492 136 576 minecraft:sea_lantern
fill 492 136 577 492 136 578 minecraft:pearlescent_froglight
fill 492 136 579 493 136 579 minecraft:gold_block
setblock 492 136 580 minecraft:lapis_block
fill 492 136 582 492 136 583 minecraft:lapis_block
fill 493 136 558 493 136 563 minecraft:quartz_block
fill 493 136 564 493 136 567 minecraft:lapis_block
fill 493 136 568 495 136 568 minecraft:gold_block
fill 493 136 570 493 136 572 minecraft:pearlescent_froglight
fill 493 136 573 495 136 573 minecraft:sea_lantern
fill 493 136 577 495 136 577 minecraft:sea_lantern
fill 493 136 578 496 136 578 minecraft:pearlescent_froglight
fill 493 136 580 495 136 582 minecraft:gold_block
fill 493 136 583 493 136 586 minecraft:lapis_block
fill 493 136 587 493 136 598 minecraft:quartz_block
fill 494 136 558 511 136 561 minecraft:quartz_block
fill 494 136 564 495 136 565 minecraft:lapis_block
fill 494 136 566 494 136 567 minecraft:gold_block
fill 494 136 569 494 136 570 minecraft:gold_block
fill 494 136 571 495 136 572 minecraft:pearlescent_froglight
setblock 494 136 579 minecraft:pearlescent_froglight
fill 494 136 583 494 136 584 minecraft:gold_block
fill 494 136 585 495 136 586 minecraft:lapis_block
fill 494 136 589 511 136 598 minecraft:quartz_block
fill 495 136 562 511 136 563 minecraft:quartz_block
fill 495 136 566 495 136 567 minecraft:lapis_block
fill 495 136 569 495 136 570 minecraft:pearlescent_froglight
setblock 495 136 579 minecraft:gold_block
fill 495 136 583 495 136 584 minecraft:lapis_block
fill 495 136 587 511 136 588 minecraft:quartz_block
fill 496 136 564 502 136 566 minecraft:quartz_block
fill 496 136 567 496 136 568 minecraft:lapis_block
fill 496 136 569 499 136 569 minecraft:pearlescent_froglight
fill 496 136 570 498 136 572 minecraft:quartz_block
fill 496 136 573 499 136 573 minecraft:pearlescent_froglight
fill 496 136 574 496 136 576 minecraft:sea_lantern
setblock 496 136 577 minecraft:pearlescent_froglight
fill 496 136 579 496 136 580 minecraft:pearlescent_froglight
fill 496 136 581 496 136 583 minecraft:lapis_block
fill 496 136 584 502 136 586 minecraft:quartz_block
fill 497 136 567 497 136 568 minecraft:quartz_block
fill 497 136 574 497 136 576 minecraft:pearlescent_froglight
fill 497 136 577 499 136 579 minecraft:quartz_block
fill 497 136 580 500 136 580 minecraft:pearlescent_froglight
fill 497 136 581 498 136 581 minecraft:lapis_block
fill 497 136 582 497 136 583 minecraft:quartz_block
fill 498 136 567 499 136 567 minecraft:quartz_block
fill 498 136 574 501 136 574 minecraft:gold_block
fill 498 136 575 498 136 576 minecraft:pearlescent_froglight
fill 498 136 583 499 136 583 minecraft:quartz_block
fill 499 136 570 499 136 572 minecraft:pearlescent_froglight
fill 499 136 575 503 136 575 minecraft:gold_block
fill 499 136 576 500 136 576 minecraft:pearlescent_froglight
fill 499 136 581 500 136 581 minecraft:gold_block
fill 500 136 569 500 136 570 minecraft:gold_block
fill 500 136 571 500 136 573 minecraft:lapis_block
fill 500 136 577 500 136 579 minecraft:pearlescent_froglight
fill 501 136 569 502 136 569 minecraft:lapis_block
fill 501 136 572 511 136 572 minecraft:quartz_block
fill 501 136 573 502 136 573 minecraft:lapis_block
setblock 501 136 576 minecraft:gold_block
fill 501 136 578 511 136 578 minecraft:quartz_block
fill 501 136 580 501 136 581 minecraft:lapis_block
fill 502 136 570 511 136 571 minecraft:quartz_block
fill 502 136 574 505 136 574 minecraft:lapis_block
fill 502 136 576 505 136 576 minecraft:lapis_block
fill 502 136 579 511 136 580 minecraft:quartz_block
setblock 502 136 581 minecraft:lapis_block
fill 503 136 564 511 136 565 minecraft:quartz_block
fill 503 136 567 511 136 569 minecraft:quartz_block
fill 503 136 573 511 136 573 minecraft:quartz_block
fill 503 136 577 511 136 577 minecraft:quartz_block
fill 503 136 581 511 136 583 minecraft:quartz_block
fill 503 136 585 511 136 586 minecraft:quartz_block
fill 504 136 566 511 136 566 minecraft:quartz_block
fill 504 136 575 505 136 575 minecraft:lapis_block
fill 504 136 584 511 136 584 minecraft:quartz_block
fill 506 136 574 511 136 574 minecraft:quartz_block
fill 506 136 576 511 136 576 minecraft:quartz_block
fill 508 136 575 511 136 575 minecraft:quartz_block
setblock 473 137 560 minecraft:light[level=14]
setblock 473 137 568 minecraft:light[level=14]
setblock 473 137 576 minecraft:light[level=14]
setblock 473 137 584 minecraft:light[level=14]
setblock 473 137 592 minecraft:light[level=14]
setblock 481 137 560 minecraft:light[level=14]
setblock 481 137 568 minecraft:light[level=14]
setblock 481 137 576 minecraft:light[level=14]
setblock 481 137 584 minecraft:light[level=14]
setblock 481 137 592 minecraft:light[level=14]
fill 482 137 563 492 137 587 minecraft:prismarine_bricks
setblock 489 137 560 minecraft:light[level=14]
setblock 489 137 592 minecraft:light[level=14]
fill 493 137 563 506 137 573 minecraft:prismarine_bricks
fill 493 137 577 506 137 587 minecraft:prismarine_bricks
fill 496 137 574 506 137 576 minecraft:prismarine_bricks
setblock 497 137 560 minecraft:light[level=14]
setblock 497 137 592 minecraft:light[level=14]
setblock 505 137 560 minecraft:light[level=14]
setblock 505 137 592 minecraft:light[level=14]
fill 482 138 563 491 138 587 minecraft:prismarine_bricks
fill 492 138 563 492 138 574 minecraft:prismarine_bricks
fill 492 138 576 492 138 587 minecraft:prismarine_bricks
fill 493 138 563 493 138 573 minecraft:prismarine_bricks
fill 493 138 577 493 138 587 minecraft:prismarine_bricks
fill 494 138 563 506 138 572 minecraft:prismarine_bricks
fill 494 138 578 506 138 587 minecraft:prismarine_bricks
fill 495 138 573 506 138 573 minecraft:prismarine_bricks
fill 495 138 577 506 138 577 minecraft:prismarine_bricks
fill 496 138 574 506 138 574 minecraft:prismarine_bricks
fill 496 138 576 506 138 576 minecraft:prismarine_bricks
fill 497 138 575 506 138 575 minecraft:prismarine_bricks
fill 483 139 564 483 140 564 minecraft:sea_lantern
fill 483 139 586 483 140 586 minecraft:sea_lantern
fill 484 139 565 491 140 585 minecraft:dark_prismarine
fill 492 139 565 492 140 573 minecraft:dark_prismarine
fill 492 139 577 492 140 585 minecraft:dark_prismarine
fill 493 139 565 504 140 572 minecraft:dark_prismarine
fill 493 139 578 504 140 585 minecraft:dark_prismarine
fill 496 139 573 504 140 573 minecraft:dark_prismarine
fill 496 139 577 504 140 577 minecraft:dark_prismarine
fill 497 139 574 504 140 576 minecraft:dark_prismarine
fill 505 139 564 505 140 564 minecraft:sea_lantern
fill 505 139 586 505 140 586 minecraft:sea_lantern
fill 471 140 558 473 225 558 minecraft:quartz_pillar
fill 471 140 568 471 225 570 minecraft:quartz_pillar
fill 471 140 580 471 225 582 minecraft:quartz_pillar
fill 471 140 592 471 225 594 minecraft:quartz_pillar
fill 472 140 567 472 145 569 minecraft:quartz_pillar
fill 472 140 579 472 145 581 minecraft:quartz_pillar
fill 472 140 591 472 145 593 minecraft:quartz_pillar
fill 477 140 598 479 225 598 minecraft:quartz_pillar
fill 478 140 597 480 145 597 minecraft:quartz_pillar
fill 482 140 559 484 145 559 minecraft:quartz_pillar
fill 483 140 558 485 225 558 minecraft:quartz_pillar
fill 489 140 598 491 225 598 minecraft:quartz_pillar
fill 490 140 597 492 145 597 minecraft:quartz_pillar
fill 494 140 559 496 145 559 minecraft:quartz_pillar
fill 495 140 558 497 225 558 minecraft:quartz_pillar
fill 501 140 598 503 225 598 minecraft:quartz_pillar
fill 502 140 597 504 145 597 minecraft:quartz_pillar
fill 505 140 562 505 140 563 minecraft:smooth_quartz
fill 506 140 559 508 145 559 minecraft:quartz_pillar
fill 506 140 561 509 140 561 minecraft:smooth_quartz
fill 506 140 562 509 225 563 minecraft:quartz_pillar
setblock 506 140 564 minecraft:smooth_quartz
fill 507 140 558 509 225 558 minecraft:quartz_pillar
fill 507 140 564 508 225 564 minecraft:quartz_pillar
fill 507 140 565 508 140 565 minecraft:smooth_quartz
setblock 509 140 564 minecraft:smooth_quartz
setblock 510 140 563 minecraft:smooth_quartz
fill 510 140 567 510 145 569 minecraft:quartz_pillar
fill 510 140 579 510 145 581 minecraft:quartz_pillar
fill 510 140 591 510 145 593 minecraft:quartz_pillar
fill 511 140 566 511 225 568 minecraft:quartz_pillar
fill 511 140 578 511 225 580 minecraft:quartz_pillar
fill 511 140 590 511 225 592 minecraft:quartz_pillar
fill 486 141 567 491 142 583 minecraft:prismarine_bricks
fill 492 141 567 492 142 573 minecraft:prismarine_bricks
fill 492 141 577 492 142 583 minecraft:prismarine_bricks
fill 493 141 567 502 142 572 minecraft:prismarine_bricks
fill 493 141 578 502 142 583 minecraft:prismarine_bricks
fill 496 141 573 502 142 573 minecraft:prismarine_bricks
fill 496 141 577 502 142 577 minecraft:prismarine_bricks
fill 497 141 574 502 142 576 minecraft:prismarine_bricks
fill 488 143 569 491 143 581 minecraft:dark_prismarine
fill 492 143 569 500 143 572 minecraft:dark_prismarine
fill 492 143 578 500 143 581 minecraft:dark_prismarine
fill 497 143 573 500 143 577 minecraft:dark_prismarine
fill 471 144 595 471 145 595 minecraft:quartz_pillar
fill 488 144 569 490 144 581 minecraft:dark_prismarine
fill 491 144 569 491 144 574 minecraft:dark_prismarine
fill 491 144 576 491 144 581 minecraft:dark_prismarine
fill 492 144 569 493 144 572 minecraft:dark_prismarine
fill 492 144 578 493 144 581 minecraft:dark_prismarine
fill 494 144 569 500 144 571 minecraft:dark_prismarine
fill 494 144 579 500 144 581 minecraft:dark_prismarine
fill 495 144 572 500 144 572 minecraft:dark_prismarine
fill 495 144 578 500 144 578 minecraft:dark_prismarine
fill 497 144 573 500 144 574 minecraft:dark_prismarine
fill 497 144 576 500 144 577 minecraft:dark_prismarine
fill 498 144 575 500 144 575 minecraft:dark_prismarine
fill 510 144 594 511 144 595 minecraft:quartz_pillar
fill 511 144 593 511 145 593 minecraft:quartz_pillar
fill 471 145 561 471 145 566 minecraft:smooth_quartz
fill 471 145 573 471 145 578 minecraft:smooth_quartz
fill 471 145 585 471 145 590 minecraft:smooth_quartz
fill 471 145 597 471 145 598 minecraft:smooth_quartz
fill 472 145 594 472 146 595 minecraft:quartz_pillar
fill 472 145 598 475 145 598 minecraft:smooth_quartz
setblock 473 145 560 minecraft:light[level=14]
setblock 473 145 568 minecraft:light[level=14]
setblock 473 145 576 minecraft:light[level=14]
setblock 473 145 584 minecraft:light[level=14]
setblock 473 145 592 minecraft:light[level=14]
fill 473 145 594 473 148 594 minecraft:quartz_pillar
fill 475 145 558 480 145 558 minecraft:smooth_quartz
setblock 481 145 560 minecraft:light[level=14]
setblock 481 145 568 minecraft:light[level=14]
setblock 481 145 576 minecraft:light[level=14]
setblock 481 145 584 minecraft:light[level=14]
setblock 481 145 592 minecraft:light[level=14]
fill 482 145 598 487 145 598 minecraft:smooth_quartz
fill 487 145 558 492 145 558 minecraft:smooth_quartz
setblock 489 145 560 minecraft:light[level=14]
setblock 489 145 568 minecraft:light[level=14]
setblock 489 145 576 minecraft:light[level=14]
setblock 489 145 584 minecraft:light[level=14]
setblock 489 145 592 minecraft:light[level=14]
fill 490 145 571 490 146 579 minecraft:prismarine_bricks
fill 491 145 571 491 146 573 minecraft:prismarine_bricks
fill 491 145 577 491 146 579 minecraft:prismarine_bricks
fill 492 145 571 492 146 572 minecraft:prismarine_bricks
fill 492 145 578 492 146 579 minecraft:prismarine_bricks
fill 493 145 571 498 146 571 minecraft:prismarine_bricks
fill 493 145 579 498 146 579 minecraft:prismarine_bricks
fill 494 145 598 499 145 598 minecraft:smooth_quartz
fill 496 145 572 498 146 572 minecraft:prismarine_bricks
fill 496 145 578 498 146 578 minecraft:prismarine_bricks
setblock 497 145 560 minecraft:light[level=14]
setblock 497 145 568 minecraft:light[level=14]
fill 497 145 573 498 146 573 minecraft:prismarine_bricks
fill 497 145 577 498 146 577 minecraft:prismarine_bricks
setblock 497 145 584 minecraft:light[level=14]
setblock 497 145 592 minecraft:light[level=14]
fill 498 145 574 498 146 576 minecraft:prismarine_bricks
fill 499 145 558 504 145 558 minecraft:smooth_quartz
setblock 505 145 560 minecraft:light[level=14]
setblock 505 145 568 minecraft:light[level=14]
setblock 505 145 576 minecraft:light[level=14]
setblock 505 145 584 minecraft:light[level=14]
setblock 505 145 592 minecraft:light[level=14]
fill 506 145 598 511 145 598 minecraft:smooth_quartz
fill 508 145 594 510 146 594 minecraft:quartz_pillar
fill 509 145 593 509 146 593 minecraft:quartz_pillar
fill 509 145 595 510 145 595 minecraft:quartz_pillar
fill 511 145 558 511 145 563 minecraft:smooth_quartz
fill 511 145 570 511 145 575 minecraft:smooth_quartz
fill 511 145 582 511 145 587 minecraft:smooth_quartz
fill 511 145 594 511 145 597 minecraft:smooth_quartz
fill 470 146 563 470 151 566 minecraft:pearlescent_froglight
fill 470 146 575 470 151 578 minecraft:pearlescent_froglight
fill 470 146 587 470 151 590 minecraft:pearlescent_froglight
fill 470 146 599 473 151 599 minecraft:pearlescent_froglight
fill 472 146 593 473 146 593 minecraft:quartz_pillar
fill 473 146 595 473 147 595 minecraft:quartz_pillar
fill 474 146 594 474 148 594 minecraft:quartz_pillar
fill 477 146 557 480 151 557 minecraft:pearlescent_froglight
fill 482 146 599 485 151 599 minecraft:pearlescent_froglight
fill 489 146 557 492 151 557 minecraft:pearlescent_froglight
fill 494 146 599 497 151 599 minecraft:pearlescent_froglight
fill 501 146 557 504 151 557 minecraft:pearlescent_froglight
fill 506 146 599 509 151 599 minecraft:pearlescent_froglight
fill 507 146 594 507 148 594 minecraft:quartz_pillar
fill 508 146 593 508 147 593 minecraft:quartz_pillar
fill 508 146 595 509 146 595 minecraft:quartz_pillar
setblock 511 146 594 minecraft:gold_block
fill 512 146 558 512 151 561 minecraft:pearlescent_froglight
fill 512 146 570 512 151 573 minecraft:pearlescent_froglight
fill 512 146 582 512 151 585 minecraft:pearlescent_froglight
fill 512 146 594 512 151 597 minecraft:pearlescent_froglight
setblock 472 147 594 minecraft:quartz_pillar
fill 473 147 593 475 147 593 minecraft:quartz_pillar
fill 474 147 595 475 148 595 minecraft:quartz_pillar
fill 475 147 594 475 149 594 minecraft:quartz_pillar
fill 506 147 593 506 148 595 minecraft:quartz_pillar
fill 507 147 593 507 148 593 minecraft:quartz_pillar
fill 507 147 595 508 147 595 minecraft:quartz_pillar
fill 508 147 594 509 147 594 minecraft:quartz_pillar
setblock 510 147 594 minecraft:gold_block
setblock 472 148 594 minecraft:gold_block
fill 474 148 593 476 148 593 minecraft:quartz_pillar
fill 476 148 594 476 149 595 minecraft:quartz_pillar
fill 477 148 594 477 150 594 minecraft:quartz_pillar
fill 504 148 594 505 150 594 minecraft:quartz_pillar
fill 505 148 562 505 148 563 minecraft:smooth_quartz
fill 505 148 593 505 149 593 minecraft:quartz_pillar
fill 505 148 595 505 149 595 minecraft:quartz_pillar
fill 506 148 561 509 148 561 minecraft:smooth_quartz
setblock 506 148 564 minecraft:smooth_quartz
fill 507 148 565 508 148 565 minecraft:smooth_quartz
setblock 507 148 595 minecraft:quartz_pillar
setblock 508 148 594 minecraft:quartz_pillar
setblock 509 148 564 minecraft:smooth_quartz
setblock 509 148 594 minecraft:gold_block
setblock 510 148 563 minecraft:smooth_quartz
setblock 474 149 594 minecraft:gold_block
fill 476 149 593 477 149 593 minecraft:quartz_pillar
fill 477 149 595 477 150 595 minecraft:quartz_pillar
fill 478 149 594 478 151 594 minecraft:quartz_pillar
fill 503 149 594 503 151 594 minecraft:quartz_pillar
fill 504 149 593 504 150 593 minecraft:quartz_pillar
fill 504 149 595 504 150 595 minecraft:quartz_pillar
setblock 506 149 594 minecraft:quartz_pillar
setblock 507 149 594 minecraft:gold_block
fill 475 150 594 476 150 594 minecraft:gold_block
fill 477 150 593 479 150 593 minecraft:quartz_pillar
fill 478 150 595 479 150 595 minecraft:quartz_pillar
fill 479 150 594 480 152 594 minecraft:quartz_pillar
fill 501 150 594 502 152 594 minecraft:quartz_pillar
fill 502 150 593 503 150 593 minecraft:quartz_pillar
fill 502 150 595 503 150 595 minecraft:quartz_pillar
setblock 506 150 594 minecraft:gold_block
setblock 477 151 594 minecraft:gold_block
fill 479 151 593 481 151 593 minecraft:quartz_pillar
fill 479 151 595 481 151 595 minecraft:quartz_pillar
fill 481 151 594 482 152 594 minecraft:quartz_pillar
fill 499 151 594 500 153 594 minecraft:quartz_pillar
fill 500 151 593 502 151 593 minecraft:quartz_pillar
fill 500 151 595 502 151 595 minecraft:quartz_pillar
setblock 504 151 594 minecraft:gold_block
fill 470 152 563 470 165 563 minecraft:smooth_quartz
fill 470 152 564 470 152 565 minecraft:pearlescent_froglight
fill 470 152 566 470 165 566 minecraft:smooth_quartz
fill 470 152 575 470 165 575 minecraft:smooth_quartz
fill 470 152 576 470 152 577 minecraft:pearlescent_froglight
fill 470 152 578 470 165 578 minecraft:smooth_quartz
fill 470 152 587 470 165 587 minecraft:smooth_quartz
fill 470 152 588 470 152 589 minecraft:pearlescent_froglight
fill 470 152 590 470 165 590 minecraft:smooth_quartz
fill 470 152 599 470 165 599 minecraft:smooth_quartz
fill 471 152 599 472 152 599 minecraft:pearlescent_froglight
fill 473 152 599 473 165 599 minecraft:smooth_quartz
fill 477 152 557 477 165 557 minecraft:smooth_quartz
fill 478 152 557 479 152 557 minecraft:pearlescent_froglight
setblock 478 152 594 minecraft:gold_block
fill 480 152 557 480 165 557 minecraft:smooth_quartz
fill 480 152 593 483 152 593 minecraft:quartz_pillar
fill 480 152 595 483 152 595 minecraft:quartz_pillar
fill 482 152 599 482 165 599 minecraft:smooth_quartz
fill 483 152 594 484 154 594 minecraft:quartz_pillar
fill 483 152 599 484 152 599 minecraft:pearlescent_froglight
fill 485 152 599 485 165 599 minecraft:smooth_quartz
fill 489 152 557 489 165 557 minecraft:smooth_quartz
fill 490 152 557 491 152 557 minecraft:pearlescent_froglight
fill 492 152 557 492 165 557 minecraft:smooth_quartz
fill 494 152 599 494 165 599 minecraft:smooth_quartz
fill 495 152 599 496 152 599 minecraft:pearlescent_froglight
fill 497 152 594 498 154 594 minecraft:quartz_pillar
fill 497 152 599 497 165 599 minecraft:smooth_quartz
fill 498 152 593 501 152 593 minecraft:quartz_pillar
fill 498 152 595 501 152 595 minecraft:quartz_pillar
fill 501 152 557 501 165 557 minecraft:smooth_quartz
fill 502 152 557 503 152 557 minecraft:pearlescent_froglight
setblock 503 152 594 minecraft:gold_block
fill 504 152 557 504 165 557 minecraft:smooth_quartz
fill 506 152 599 506 165 599 minecraft:smooth_quartz
fill 507 152 599 508 152 599 minecraft:pearlescent_froglight
fill 509 152 599 509 165 599 minecraft:smooth_quartz
fill 512 152 558 512 165 558 minecraft:smooth_quartz
fill 512 152 559 512 152 560 minecraft:pearlescent_froglight
fill 512 152 561 512 165 561 minecraft:smooth_quartz
fill 512 152 570 512 165 570 minecraft:smooth_quartz
fill 512 152 571 512 152 572 minecraft:pearlescent_froglight
fill 512 152 573 512 165 573 minecraft:smooth_quartz
fill 512 152 582 512 165 582 minecraft:smooth_quartz
fill 512 152 583 512 152 584 minecraft:pearlescent_froglight
fill 512 152 585 512 165 585 minecraft:smooth_quartz
fill 512 152 594 512 165 594 minecraft:smooth_quartz
fill 512 152 595 512 152 596 minecraft:pearlescent_froglight
fill 512 152 597 512 165 597 minecraft:smooth_quartz
fill 470 153 564 470 165 565 minecraft:smooth_quartz
fill 470 153 576 470 165 577 minecraft:smooth_quartz
fill 470 153 588 470 165 589 minecraft:smooth_quartz
fill 471 153 599 472 165 599 minecraft:smooth_quartz
setblock 473 153 560 minecraft:light[level=14]
setblock 473 153 568 minecraft:light[level=14]
setblock 473 153 576 minecraft:light[level=14]
setblock 473 153 584 minecraft:light[level=14]
setblock 473 153 592 minecraft:light[level=14]
fill 478 153 557 479 165 557 minecraft:smooth_quartz
fill 480 153 594 481 153 594 minecraft:gold_block
setblock 481 153 560 minecraft:light[level=14]
setblock 481 153 568 minecraft:light[level=14]
setblock 481 153 576 minecraft:light[level=14]
setblock 481 153 584 minecraft:light[level=14]
setblock 481 153 592 minecraft:light[level=14]
fill 482 153 593 482 153 595 minecraft:quartz_pillar
fill 483 153 593 485 153 593 minecraft:quartz_pillar
fill 483 153 595 485 153 595 minecraft:quartz_pillar
fill 483 153 599 484 165 599 minecraft:smooth_quartz
fill 485 153 594 489 154 594 minecraft:quartz_pillar
setblock 489 153 560 minecraft:light[level=14]
setblock 489 153 568 minecraft:light[level=14]
setblock 489 153 576 minecraft:light[level=14]
setblock 489 153 584 minecraft:light[level=14]
setblock 489 153 592 minecraft:light[level=14]
fill 490 153 557 491 165 557 minecraft:smooth_quartz
fill 492 153 594 496 154 594 minecraft:quartz_pillar
fill 495 153 599 496 165 599 minecraft:smooth_quartz
fill 496 153 593 499 153 593 minecraft:quartz_pillar
fill 496 153 595 499 153 595 minecraft:quartz_pillar
setblock 497 153 560 minecraft:light[level=14]
setblock 497 153 568 minecraft:light[level=14]
setblock 497 153 576 minecraft:light[level=14]
setblock 497 153 584 minecraft:light[level=14]
setblock 497 153 592 minecraft:light[level=14]
setblock 501 153 594 minecraft:gold_block
fill 502 153 557 503 165 557 minecraft:smooth_quartz
setblock 505 153 560 minecraft:light[level=14]
setblock 505 153 568 minecraft:light[level=14]
setblock 505 153 576 minecraft:light[level=14]
setblock 505 153 584 minecraft:light[level=14]
setblock 505 153 592 minecraft:light[level=14]
fill 507 153 599 508 165 599 minecraft:smooth_quartz
fill 512 153 559 512 165 560 minecraft:smooth_quartz
fill 512 153 571 512 165 572 minecraft:smooth_quartz
fill 512 153 583 512 165 584 minecraft:smooth_quartz
fill 512 153 595 512 165 596 minecraft:smooth_quartz
fill 481 154 594 482 154 594 minecraft:gold_block
fill 485 154 593 496 154 593 minecraft:quartz_pillar
fill 485 154 595 496 154 595 minecraft:quartz_pillar
fill 490 154 594 491 155 594 minecraft:quartz_pillar
fill 499 154 594 500 154 594 minecraft:gold_block
fill 484 155 594 485 155 594 minecraft:gold_block
fill 486 155 594 489 155 594 minecraft:quartz_pillar
fill 489 155 593 492 155 593 minecraft:quartz_pillar
fill 489 155 595 492 155 595 minecraft:quartz_pillar
fill 492 155 594 495 155 594 minecraft:quartz_pillar
fill 496 155 594 497 155 594 minecraft:gold_block
fill 486 156 594 495 156 594 minecraft:gold_block
fill 505 156 562 505 156 563 minecraft:smooth_quartz
fill 506 156 561 509 156 561 minecraft:smooth_quartz
setblock 506 156 564 minecraft:smooth_quartz
fill 507 156 565 508 156 565 minecraft:smooth_quartz
setblock 509 156 564 minecraft:smooth_quartz
setblock 510 156 563 minecraft:smooth_quartz
fill 472 160 567 472 165 569 minecraft:quartz_pillar
fill 472 160 579 472 165 581 minecraft:quartz_pillar
fill 472 160 591 472 165 593 minecraft:quartz_pillar
fill 478 160 597 480 165 597 minecraft:quartz_pillar
fill 482 160 559 484 165 559 minecraft:quartz_pillar
fill 490 160 597 492 165 597 minecraft:quartz_pillar
fill 494 160 559 496 165 559 minecraft:quartz_pillar
fill 502 160 597 504 165 597 minecraft:quartz_pillar
fill 506 160 559 508 165 559 minecraft:quartz_pillar
fill 510 160 567 510 165 569 minecraft:quartz_pillar
fill 510 160 579 510 165 581 minecraft:quartz_pillar
fill 510 160 591 510 165 593 minecraft:quartz_pillar
setblock 473 161 560 minecraft:light[level=14]
setblock 473 161 568 minecraft:light[level=14]
setblock 473 161 576 minecraft:light[level=14]
setblock 473 161 584 minecraft:light[level=14]
setblock 473 161 592 minecraft:light[level=14]
setblock 481 161 560 minecraft:light[level=14]
setblock 481 161 568 minecraft:light[level=14]
setblock 481 161 576 minecraft:light[level=14]
setblock 481 161 584 minecraft:light[level=14]
setblock 481 161 592 minecraft:light[level=14]
setblock 489 161 560 minecraft:light[level=14]
setblock 489 161 568 minecraft:light[level=14]
setblock 489 161 576 minecraft:light[level=14]
setblock 489 161 584 minecraft:light[level=14]
setblock 489 161 592 minecraft:light[level=14]
setblock 497 161 560 minecraft:light[level=14]
setblock 497 161 568 minecraft:light[level=14]
setblock 497 161 576 minecraft:light[level=14]
setblock 497 161 584 minecraft:light[level=14]
setblock 497 161 592 minecraft:light[level=14]
setblock 505 161 560 minecraft:light[level=14]
setblock 505 161 568 minecraft:light[level=14]
setblock 505 161 576 minecraft:light[level=14]
setblock 505 161 584 minecraft:light[level=14]
setblock 505 161 592 minecraft:light[level=14]
fill 505 164 562 505 164 563 minecraft:smooth_quartz
fill 506 164 561 509 164 561 minecraft:smooth_quartz
setblock 506 164 564 minecraft:smooth_quartz
fill 507 164 565 508 164 565 minecraft:smooth_quartz
setblock 509 164 564 minecraft:smooth_quartz
setblock 510 164 563 minecraft:smooth_quartz
fill 471 165 561 471 165 566 minecraft:smooth_quartz
fill 471 165 573 471 165 578 minecraft:smooth_quartz
fill 471 165 585 471 165 590 minecraft:smooth_quartz
fill 471 165 597 471 165 598 minecraft:smooth_quartz
fill 472 165 598 475 165 598 minecraft:smooth_quartz
fill 475 165 558 480 165 558 minecraft:smooth_quartz
fill 482 165 598 487 165 598 minecraft:smooth_quartz
fill 487 165 558 492 165 558 minecraft:smooth_quartz
fill 494 165 598 499 165 598 minecraft:smooth_quartz
fill 499 165 558 504 165 558 minecraft:smooth_quartz
fill 506 165 598 511 165 598 minecraft:smooth_quartz
fill 511 165 558 511 165 563 minecraft:smooth_quartz
fill 511 165 570 511 165 575 minecraft:smooth_quartz
fill 511 165 582 511 165 587 minecraft:smooth_quartz
fill 511 165 594 511 165 597 minecraft:smooth_quartz
fill 470 166 563 470 171 566 minecraft:pearlescent_froglight
fill 470 166 575 470 171 578 minecraft:pearlescent_froglight
fill 470 166 587 470 171 590 minecraft:pearlescent_froglight
fill 470 166 599 473 171 599 minecraft:pearlescent_froglight
fill 477 166 557 480 171 557 minecraft:pearlescent_froglight
fill 482 166 599 485 171 599 minecraft:pearlescent_froglight
fill 489 166 557 492 171 557 minecraft:pearlescent_froglight
fill 494 166 599 497 171 599 minecraft:pearlescent_froglight
fill 501 166 557 504 171 557 minecraft:pearlescent_froglight
fill 506 166 599 509 171 599 minecraft:pearlescent_froglight
fill 512 166 558 512 171 561 minecraft:pearlescent_froglight
fill 512 166 570 512 171 573 minecraft:pearlescent_froglight
fill 512 166 582 512 171 585 minecraft:pearlescent_froglight
fill 512 166 594 512 171 597 minecraft:pearlescent_froglight
setblock 473 169 560 minecraft:light[level=14]
setblock 473 169 568 minecraft:light[level=14]
setblock 473 169 576 minecraft:light[level=14]
setblock 473 169 584 minecraft:light[level=14]
setblock 473 169 592 minecraft:light[level=14]
setblock 481 169 560 minecraft:light[level=14]
setblock 481 169 568 minecraft:light[level=14]
setblock 481 169 576 minecraft:light[level=14]
setblock 481 169 584 minecraft:light[level=14]
setblock 481 169 592 minecraft:light[level=14]
setblock 489 169 560 minecraft:light[level=14]
setblock 489 169 568 minecraft:light[level=14]
setblock 489 169 576 minecraft:light[level=14]
setblock 489 169 584 minecraft:light[level=14]
setblock 489 169 592 minecraft:light[level=14]
setblock 497 169 560 minecraft:light[level=14]
setblock 497 169 568 minecraft:light[level=14]
setblock 497 169 576 minecraft:light[level=14]
setblock 497 169 584 minecraft:light[level=14]
setblock 497 169 592 minecraft:light[level=14]
setblock 505 169 560 minecraft:light[level=14]
setblock 505 169 568 minecraft:light[level=14]
setblock 505 169 576 minecraft:light[level=14]
setblock 505 169 584 minecraft:light[level=14]
setblock 505 169 592 minecraft:light[level=14]
fill 470 172 563 470 185 563 minecraft:smooth_quartz
fill 470 172 564 470 172 565 minecraft:pearlescent_froglight
fill 470 172 566 470 185 566 minecraft:smooth_quartz
fill 470 172 575 470 185 575 minecraft:smooth_quartz
fill 470 172 576 470 172 577 minecraft:pearlescent_froglight
fill 470 172 578 470 185 578 minecraft:smooth_quartz
fill 470 172 587 470 185 587 minecraft:smooth_quartz
fill 470 172 588 470 172 589 minecraft:pearlescent_froglight
fill 470 172 590 470 185 590 minecraft:smooth_quartz
fill 470 172 599 470 185 599 minecraft:smooth_quartz
fill 471 172 599 472 172 599 minecraft:pearlescent_froglight
fill 473 172 599 473 185 599 minecraft:smooth_quartz
fill 477 172 557 477 185 557 minecraft:smooth_quartz
fill 478 172 557 479 172 557 minecraft:pearlescent_froglight
fill 480 172 557 480 185 557 minecraft:smooth_quartz
fill 482 172 599 482 185 599 minecraft:smooth_quartz
fill 483 172 599 484 172 599 minecraft:pearlescent_froglight
fill 485 172 599 485 185 599 minecraft:smooth_quartz
fill 489 172 557 489 185 557 minecraft:smooth_quartz
fill 490 172 557 491 172 557 minecraft:pearlescent_froglight
fill 492 172 557 492 185 557 minecraft:smooth_quartz
fill 494 172 599 494 185 599 minecraft:smooth_quartz
fill 495 172 599 496 172 599 minecraft:pearlescent_froglight
fill 497 172 599 497 185 599 minecraft:smooth_quartz
fill 501 172 557 501 185 557 minecraft:smooth_quartz
fill 502 172 557 503 172 557 minecraft:pearlescent_froglight
fill 504 172 557 504 185 557 minecraft:smooth_quartz
fill 505 172 562 505 172 563 minecraft:smooth_quartz
fill 506 172 561 509 172 561 minecraft:smooth_quartz
setblock 506 172 564 minecraft:smooth_quartz
fill 506 172 599 506 185 599 minecraft:smooth_quartz
fill 507 172 565 508 172 565 minecraft:smooth_quartz
fill 507 172 599 508 172 599 minecraft:pearlescent_froglight
setblock 509 172 564 minecraft:smooth_quartz
fill 509 172 599 509 185 599 minecraft:smooth_quartz
setblock 510 172 563 minecraft:smooth_quartz
fill 512 172 558 512 185 558 minecraft:smooth_quartz
fill 512 172 559 512 172 560 minecraft:pearlescent_froglight
fill 512 172 561 512 185 561 minecraft:smooth_quartz
fill 512 172 570 512 185 570 minecraft:smooth_quartz
fill 512 172 571 512 172 572 minecraft:pearlescent_froglight
fill 512 172 573 512 185 573 minecraft:smooth_quartz
fill 512 172 582 512 185 582 minecraft:smooth_quartz
fill 512 172 583 512 172 584 minecraft:pearlescent_froglight
fill 512 172 585 512 185 585 minecraft:smooth_quartz
fill 512 172 594 512 185 594 minecraft:smooth_quartz
fill 512 172 595 512 172 596 minecraft:pearlescent_froglight
fill 512 172 597 512 185 597 minecraft:smooth_quartz
fill 470 173 564 470 185 565 minecraft:smooth_quartz
fill 470 173 576 470 185 577 minecraft:smooth_quartz
fill 470 173 588 470 185 589 minecraft:smooth_quartz
fill 471 173 588 477 173 588 minecraft:smooth_quartz
fill 471 173 599 472 185 599 minecraft:smooth_quartz
fill 473 173 586 477 174 587 minecraft:smooth_quartz
fill 473 173 589 477 174 590 minecraft:smooth_quartz
fill 478 173 557 479 185 557 minecraft:smooth_quartz
fill 483 173 599 484 185 599 minecraft:smooth_quartz
fill 490 173 557 491 185 557 minecraft:smooth_quartz
fill 495 173 599 496 185 599 minecraft:smooth_quartz
fill 502 173 557 503 185 557 minecraft:smooth_quartz
fill 507 173 599 508 185 599 minecraft:smooth_quartz
fill 512 173 559 512 185 560 minecraft:smooth_quartz
fill 512 173 571 512 185 572 minecraft:smooth_quartz
fill 512 173 583 512 185 584 minecraft:smooth_quartz
fill 512 173 595 512 185 596 minecraft:smooth_quartz
fill 473 174 588 477 174 588 minecraft:smooth_quartz
fill 474 175 587 476 176 589 minecraft:quartz_pillar
setblock 473 177 560 minecraft:light[level=14]
setblock 473 177 568 minecraft:light[level=14]
setblock 473 177 576 minecraft:light[level=14]
setblock 473 177 584 minecraft:light[level=14]
setblock 473 177 592 minecraft:light[level=14]
fill 474 177 588 476 179 588 minecraft:quartz_pillar
fill 475 177 587 475 179 587 minecraft:quartz_pillar
fill 475 177 589 475 179 589 minecraft:quartz_pillar
setblock 481 177 560 minecraft:light[level=14]
setblock 481 177 568 minecraft:light[level=14]
setblock 481 177 576 minecraft:light[level=14]
setblock 481 177 584 minecraft:light[level=14]
setblock 481 177 592 minecraft:light[level=14]
setblock 489 177 560 minecraft:light[level=14]
setblock 489 177 568 minecraft:light[level=14]
setblock 489 177 576 minecraft:light[level=14]
setblock 489 177 584 minecraft:light[level=14]
setblock 489 177 592 minecraft:light[level=14]
setblock 497 177 560 minecraft:light[level=14]
setblock 497 177 568 minecraft:light[level=14]
setblock 497 177 576 minecraft:light[level=14]
setblock 497 177 584 minecraft:light[level=14]
setblock 497 177 592 minecraft:light[level=14]
setblock 505 177 560 minecraft:light[level=14]
setblock 505 177 568 minecraft:light[level=14]
setblock 505 177 576 minecraft:light[level=14]
setblock 505 177 584 minecraft:light[level=14]
setblock 505 177 592 minecraft:light[level=14]
fill 472 180 567 472 185 569 minecraft:quartz_pillar
fill 472 180 579 472 185 581 minecraft:quartz_pillar
fill 472 180 591 472 185 593 minecraft:quartz_pillar
fill 475 180 588 475 184 588 minecraft:quartz_pillar
fill 478 180 597 480 185 597 minecraft:quartz_pillar
fill 482 180 559 484 185 559 minecraft:quartz_pillar
fill 490 180 597 492 185 597 minecraft:quartz_pillar
fill 494 180 559 496 185 559 minecraft:quartz_pillar
fill 502 180 597 504 185 597 minecraft:quartz_pillar
fill 505 180 562 505 180 563 minecraft:smooth_quartz
fill 506 180 559 508 185 559 minecraft:quartz_pillar
fill 506 180 561 509 180 561 minecraft:smooth_quartz
setblock 506 180 564 minecraft:smooth_quartz
fill 507 180 565 508 180 565 minecraft:smooth_quartz
setblock 509 180 564 minecraft:smooth_quartz
setblock 510 180 563 minecraft:smooth_quartz
fill 510 180 567 510 185 569 minecraft:quartz_pillar
fill 510 180 579 510 185 581 minecraft:quartz_pillar
fill 510 180 591 510 185 593 minecraft:quartz_pillar
fill 471 185 561 471 185 566 minecraft:smooth_quartz
fill 471 185 573 471 185 578 minecraft:smooth_quartz
fill 471 185 585 471 185 590 minecraft:smooth_quartz
fill 471 185 597 471 185 598 minecraft:smooth_quartz
fill 472 185 598 475 185 598 minecraft:smooth_quartz
setblock 473 185 560 minecraft:light[level=14]
setblock 473 185 568 minecraft:light[level=14]
setblock 473 185 576 minecraft:light[level=14]
setblock 473 185 584 minecraft:light[level=14]
setblock 473 185 592 minecraft:light[level=14]
fill 475 185 558 480 185 558 minecraft:smooth_quartz
setblock 475 185 588 minecraft:pearlescent_froglight
setblock 481 185 560 minecraft:light[level=14]
setblock 481 185 568 minecraft:light[level=14]
setblock 481 185 576 minecraft:light[level=14]
setblock 481 185 584 minecraft:light[level=14]
setblock 481 185 592 minecraft:light[level=14]
fill 482 185 598 487 185 598 minecraft:smooth_quartz
fill 487 185 558 492 185 558 minecraft:smooth_quartz
setblock 489 185 560 minecraft:light[level=14]
setblock 489 185 568 minecraft:light[level=14]
setblock 489 185 576 minecraft:light[level=14]
setblock 489 185 584 minecraft:light[level=14]
setblock 489 185 592 minecraft:light[level=14]
fill 494 185 598 499 185 598 minecraft:smooth_quartz
setblock 497 185 560 minecraft:light[level=14]
setblock 497 185 568 minecraft:light[level=14]
setblock 497 185 576 minecraft:light[level=14]
setblock 497 185 584 minecraft:light[level=14]
setblock 497 185 592 minecraft:light[level=14]
fill 499 185 558 504 185 558 minecraft:smooth_quartz
setblock 505 185 560 minecraft:light[level=14]
setblock 505 185 568 minecraft:light[level=14]
setblock 505 185 576 minecraft:light[level=14]
setblock 505 185 584 minecraft:light[level=14]
setblock 505 185 592 minecraft:light[level=14]
fill 506 185 598 511 185 598 minecraft:smooth_quartz
fill 511 185 558 511 185 563 minecraft:smooth_quartz
fill 511 185 570 511 185 575 minecraft:smooth_quartz
fill 511 185 582 511 185 587 minecraft:smooth_quartz
fill 511 185 594 511 185 597 minecraft:smooth_quartz
fill 470 186 563 470 191 566 minecraft:pearlescent_froglight
fill 470 186 575 470 191 578 minecraft:pearlescent_froglight
fill 470 186 587 470 191 590 minecraft:pearlescent_froglight
fill 470 186 599 473 191 599 minecraft:pearlescent_froglight
fill 477 186 557 480 191 557 minecraft:pearlescent_froglight
fill 482 186 599 485 191 599 minecraft:pearlescent_froglight
fill 489 186 557 492 191 557 minecraft:pearlescent_froglight
fill 494 186 599 497 191 599 minecraft:pearlescent_froglight
fill 501 186 557 504 191 557 minecraft:pearlescent_froglight
fill 506 186 599 509 191 599 minecraft:pearlescent_froglight
fill 512 186 558 512 191 561 minecraft:pearlescent_froglight
fill 512 186 570 512 191 573 minecraft:pearlescent_froglight
fill 512 186 582 512 191 585 minecraft:pearlescent_froglight
fill 512 186 594 512 191 597 minecraft:pearlescent_froglight
setblock 470 188 561 minecraft:quartz_block
fill 470 188 562 470 191 562 minecraft:smooth_quartz
fill 470 188 570 470 191 571 minecraft:smooth_quartz
setblock 470 188 572 minecraft:quartz_block
fill 470 188 573 470 191 573 minecraft:smooth_quartz
setblock 470 188 583 minecraft:quartz_block
fill 470 188 584 470 189 585 minecraft:smooth_quartz
fill 474 188 599 474 189 599 minecraft:smooth_quartz
fill 475 188 599 475 189 599 minecraft:quartz_block
fill 476 188 599 481 189 599 minecraft:smooth_quartz
setblock 487 188 599 minecraft:quartz_block
fill 496 188 557 497 188 557 minecraft:quartz_block
setblock 498 188 599 minecraft:quartz_block
fill 499 188 599 500 191 599 minecraft:smooth_quartz
setblock 501 188 599 minecraft:quartz_block
fill 502 188 599 502 191 599 minecraft:smooth_quartz
setblock 503 188 599 minecraft:quartz_block
fill 504 188 599 504 189 599 minecraft:smooth_quartz
setblock 505 188 557 minecraft:quartz_block
fill 505 188 562 505 188 563 minecraft:smooth_quartz
fill 506 188 557 511 188 557 minecraft:smooth_quartz
fill 506 188 561 509 188 561 minecraft:smooth_quartz
setblock 506 188 564 minecraft:smooth_quartz
fill 507 188 565 508 188 565 minecraft:smooth_quartz
setblock 509 188 564 minecraft:smooth_quartz
setblock 510 188 563 minecraft:smooth_quartz
setblock 512 188 557 minecraft:quartz_block
fill 512 188 574 512 191 578 minecraft:smooth_quartz
fill 512 188 579 512 189 579 minecraft:quartz_block
fill 512 188 580 512 191 581 minecraft:smooth_quartz
setblock 512 188 593 minecraft:quartz_block
setblock 512 188 599 minecraft:quartz_block
setblock 470 189 558 minecraft:quartz_block
fill 470 189 559 470 191 561 minecraft:smooth_quartz
fill 470 189 567 470 191 567 minecraft:smooth_quartz
setblock 470 189 568 minecraft:quartz_block
setblock 470 189 569 minecraft:smooth_quartz
fill 470 189 572 470 191 572 minecraft:smooth_quartz
fill 470 189 583 470 191 583 minecraft:smooth_quartz
setblock 470 189 594 minecraft:quartz_block
fill 470 189 595 470 191 596 minecraft:smooth_quartz
fill 481 189 557 481 191 557 minecraft:smooth_quartz
setblock 482 189 557 minecraft:quartz_block
fill 487 189 599 487 191 599 minecraft:smooth_quartz
fill 496 189 557 498 191 557 minecraft:smooth_quartz
fill 498 189 599 498 191 599 minecraft:smooth_quartz
setblock 499 189 557 minecraft:quartz_block
setblock 500 189 557 minecraft:smooth_quartz
fill 501 189 599 501 191 599 minecraft:smooth_quartz
setblock 503 189 599 minecraft:smooth_quartz
fill 505 189 557 509 191 557 minecraft:smooth_quartz
fill 510 189 557 511 189 557 minecraft:quartz_block
setblock 510 189 599 minecraft:quartz_block
fill 511 189 599 512 191 599 minecraft:smooth_quartz
setblock 512 189 557 minecraft:smooth_quartz
setblock 512 189 568 minecraft:quartz_block
setblock 512 189 586 minecraft:quartz_block
fill 512 189 587 512 191 587 minecraft:smooth_quartz
fill 512 189 588 512 189 589 minecraft:quartz_block
setblock 512 189 591 minecraft:quartz_block
fill 512 189 593 512 193 593 minecraft:smooth_quartz
fill 470 190 558 470 191 558 minecraft:smooth_quartz
fill 470 190 568 470 192 568 minecraft:smooth_quartz
setblock 470 190 569 minecraft:quartz_block
fill 470 190 584 470 192 584 minecraft:smooth_quartz
setblock 470 190 585 minecraft:quartz_block
fill 470 190 594 470 192 594 minecraft:smooth_quartz
fill 471 190 557 471 191 557 minecraft:smooth_quartz
fill 471 190 562 471 191 564 minecraft:quartz_pillar
fill 472 190 557 473 190 557 minecraft:quartz_block
fill 474 190 557 474 191 557 minecraft:smooth_quartz
setblock 474 190 599 minecraft:quartz_block
setblock 475 190 557 minecraft:quartz_block
fill 475 190 599 476 191 599 minecraft:smooth_quartz
fill 476 190 557 476 191 557 minecraft:smooth_quartz
setblock 477 190 599 minecraft:quartz_block
fill 478 190 599 481 191 599 minecraft:smooth_quartz
fill 482 190 557 482 191 557 minecraft:smooth_quartz
fill 488 190 599 488 191 599 minecraft:smooth_quartz
setblock 489 190 599 minecraft:quartz_block
setblock 491 190 599 minecraft:quartz_block
fill 492 190 599 493 191 599 minecraft:smooth_quartz
fill 493 190 557 493 191 557 minecraft:smooth_quartz
setblock 494 190 557 minecraft:quartz_block
fill 499 190 557 499 191 557 minecraft:smooth_quartz
setblock 500 190 557 minecraft:quartz_block
fill 503 190 599 504 190 599 minecraft:quartz_block
fill 510 190 557 511 191 557 minecraft:smooth_quartz
fill 510 190 562 511 191 564 minecraft:quartz_pillar
fill 510 190 599 510 191 599 minecraft:smooth_quartz
setblock 512 190 557 minecraft:quartz_block
fill 512 190 562 512 191 566 minecraft:smooth_quartz
setblock 512 190 567 minecraft:quartz_block
fill 512 190 568 512 191 568 minecraft:smooth_quartz
fill 512 190 579 512 191 579 minecraft:smooth_quartz
fill 512 190 586 512 191 586 minecraft:smooth_quartz
fill 512 190 588 512 191 589 minecraft:smooth_quartz
fill 512 190 591 512 191 591 minecraft:smooth_quartz
setblock 470 191 569 minecraft:smooth_quartz
setblock 470 191 585 minecraft:smooth_quartz
fill 472 191 557 473 191 557 minecraft:smooth_quartz
fill 472 191 562 472 192 564 minecraft:quartz_pillar
fill 473 191 563 473 194 563 minecraft:quartz_pillar
setblock 474 191 599 minecraft:smooth_quartz
setblock 475 191 557 minecraft:smooth_quartz
fill 477 191 599 477 192 599 minecraft:smooth_quartz
setblock 489 191 599 minecraft:smooth_quartz
setblock 491 191 599 minecraft:smooth_quartz
setblock 494 191 557 minecraft:smooth_quartz
setblock 500 191 557 minecraft:smooth_quartz
fill 502 191 559 502 200 559 minecraft:blue_wool
fill 503 191 599 504 191 599 minecraft:smooth_quartz
fill 509 191 564 509 192 564 minecraft:quartz_pillar
fill 512 191 557 512 192 557 minecraft:smooth_quartz
setblock 512 191 567 minecraft:smooth_quartz
fill 470 192 557 470 192 560 minecraft:quartz_block
setblock 470 192 561 minecraft:smooth_quartz
fill 470 192 562 470 192 563 minecraft:quartz_block
fill 470 192 564 470 192 565 minecraft:pearlescent_froglight
fill 470 192 566 470 205 567 minecraft:quartz_block
fill 470 192 569 470 192 575 minecraft:quartz_block
fill 470 192 576 470 192 577 minecraft:pearlescent_froglight
fill 470 192 578 470 205 578 minecraft:quartz_block
setblock 470 192 579 minecraft:smooth_quartz
fill 470 192 580 470 192 583 minecraft:quartz_block
fill 470 192 585 470 205 587 minecraft:quartz_block
fill 470 192 588 470 192 589 minecraft:pearlescent_froglight
fill 470 192 590 470 192 593 minecraft:quartz_block
fill 470 192 595 470 307 598 minecraft:quartz_block
setblock 470 192 599 minecraft:smooth_quartz
fill 471 192 557 476 307 557 minecraft:quartz_block
setblock 471 192 563 minecraft:quartz_pillar
fill 471 192 599 472 192 599 minecraft:pearlescent_froglight
fill 473 192 562 473 193 562 minecraft:quartz_pillar
fill 473 192 564 473 193 564 minecraft:quartz_pillar
fill 473 192 599 475 193 599 minecraft:quartz_block
fill 474 192 563 474 194 563 minecraft:quartz_pillar
setblock 476 192 599 minecraft:smooth_quartz
fill 477 192 557 477 193 557 minecraft:smooth_quartz
fill 478 192 557 479 192 557 minecraft:pearlescent_froglight
fill 478 192 599 480 192 599 minecraft:quartz_block
fill 480 192 557 482 193 557 minecraft:quartz_block
setblock 481 192 599 minecraft:smooth_quartz
fill 482 192 599 482 205 599 minecraft:quartz_block
fill 483 192 599 484 192 599 minecraft:pearlescent_froglight
fill 484 192 557 489 205 557 minecraft:quartz_block
fill 485 192 599 485 205 599 minecraft:quartz_block
fill 487 192 599 489 307 599 minecraft:quartz_block
fill 490 192 557 491 192 557 minecraft:pearlescent_froglight
fill 491 192 599 494 205 599 minecraft:quartz_block
fill 492 192 557 494 192 557 minecraft:quartz_block
fill 495 192 599 496 192 599 minecraft:pearlescent_froglight
fill 496 192 557 496 307 557 minecraft:quartz_block
setblock 497 192 557 minecraft:smooth_quartz
fill 497 192 599 506 193 599 minecraft:quartz_block
fill 498 192 557 501 205 557 minecraft:quartz_block
fill 500 192 559 501 200 559 minecraft:blue_wool
fill 502 192 557 503 192 557 minecraft:pearlescent_froglight
fill 503 192 559 504 200 559 minecraft:blue_wool
fill 504 192 557 511 192 557 minecraft:quartz_block
fill 507 192 599 508 192 599 minecraft:pearlescent_froglight
fill 509 192 599 512 193 599 minecraft:quartz_block
setblock 510 192 563 minecraft:quartz_pillar
setblock 511 192 563 minecraft:gold_block
fill 512 192 558 512 205 558 minecraft:quartz_block
fill 512 192 559 512 192 560 minecraft:pearlescent_froglight
fill 512 192 561 512 193 563 minecraft:quartz_block
fill 512 192 564 512 194 564 minecraft:smooth_quartz
fill 512 192 565 512 193 570 minecraft:quartz_block
fill 512 192 571 512 192 572 minecraft:pearlescent_froglight
fill 512 192 573 512 193 579 minecraft:quartz_block
setblock 512 192 580 minecraft:smooth_quartz
fill 512 192 581 512 205 582 minecraft:quartz_block
fill 512 192 583 512 192 584 minecraft:pearlescent_froglight
setblock 512 192 585 minecraft:smooth_quartz
fill 512 192 586 512 193 587 minecraft:quartz_block
setblock 512 192 588 minecraft:smooth_quartz
fill 512 192 589 512 307 592 minecraft:quartz_block
fill 512 192 594 512 193 594 minecraft:quartz_block
fill 512 192 595 512 192 596 minecraft:pearlescent_froglight
setblock 512 192 597 minecraft:quartz_block
setblock 470 193 557 minecraft:smooth_quartz
fill 470 193 558 470 193 561 minecraft:quartz_block
setblock 470 193 562 minecraft:smooth_quartz
fill 470 193 563 470 205 565 minecraft:quartz_block
fill 470 193 568 470 193 571 minecraft:quartz_block
setblock 470 193 572 minecraft:smooth_quartz
fill 470 193 573 470 307 573 minecraft:quartz_block
setblock 470 193 574 minecraft:smooth_quartz
fill 470 193 575 470 205 577 minecraft:quartz_block
fill 470 193 579 470 307 582 minecraft:quartz_block
setblock 470 193 583 minecraft:smooth_quartz
fill 470 193 584 470 307 584 minecraft:quartz_block
fill 470 193 588 470 205 591 minecraft:quartz_block
fill 470 193 592 470 194 592 minecraft:smooth_quartz
fill 470 193 593 470 307 594 minecraft:quartz_block
fill 470 193 599 472 193 599 minecraft:quartz_block
setblock 471 193 563 minecraft:gold_block
setblock 472 193 563 minecraft:quartz_pillar
setblock 473 193 560 minecraft:light[level=14]
setblock 473 193 568 minecraft:light[level=14]
setblock 473 193 576 minecraft:light[level=14]
setblock 473 193 584 minecraft:light[level=14]
setblock 473 193 592 minecraft:light[level=14]
fill 474 193 562 475 194 562 minecraft:quartz_pillar
fill 474 193 564 475 194 564 minecraft:quartz_pillar
fill 475 193 563 475 195 563 minecraft:quartz_pillar
fill 476 193 599 479 193 599 minecraft:quartz_block
fill 478 193 557 479 205 557 minecraft:quartz_block
setblock 480 193 599 minecraft:smooth_quartz
setblock 481 193 560 minecraft:light[level=14]
setblock 481 193 568 minecraft:light[level=14]
setblock 481 193 576 minecraft:light[level=14]
setblock 481 193 584 minecraft:light[level=14]
setblock 481 193 592 minecraft:light[level=14]
fill 481 193 599 481 307 599 minecraft:quartz_block
setblock 483 193 599 minecraft:smooth_quartz
fill 484 193 599 484 205 599 minecraft:quartz_block
fill 486 193 599 486 307 599 minecraft:quartz_block
setblock 489 193 560 minecraft:light[level=14]
setblock 489 193 568 minecraft:light[level=14]
setblock 489 193 576 minecraft:light[level=14]
setblock 489 193 584 minecraft:light[level=14]
setblock 489 193 592 minecraft:light[level=14]
fill 490 193 557 493 205 557 minecraft:quartz_block
fill 490 193 599 490 307 599 minecraft:quartz_block
setblock 494 193 557 minecraft:smooth_quartz
fill 495 193 557 495 307 557 minecraft:quartz_block
fill 495 193 599 496 205 599 minecraft:quartz_block
fill 497 193 557 497 307 557 minecraft:quartz_block
setblock 497 193 560 minecraft:light[level=14]
setblock 497 193 568 minecraft:light[level=14]
setblock 497 193 576 minecraft:light[level=14]
setblock 497 193 584 minecraft:light[level=14]
setblock 497 193 592 minecraft:light[level=14]
fill 502 193 557 503 193 557 minecraft:quartz_block
setblock 504 193 557 minecraft:smooth_quartz
fill 505 193 557 509 307 557 minecraft:quartz_block
setblock 505 193 560 minecraft:light[level=14]
setblock 505 193 568 minecraft:light[level=14]
setblock 505 193 576 minecraft:light[level=14]
setblock 505 193 584 minecraft:light[level=14]
setblock 505 193 592 minecraft:light[level=14]
fill 506 193 564 506 194 564 minecraft:quartz_pillar
fill 507 193 599 508 205 599 minecraft:quartz_block
setblock 510 193 557 minecraft:smooth_quartz
setblock 510 193 563 minecraft:gold_block
fill 511 193 557 512 307 557 minecraft:quartz_block
fill 512 193 559 512 205 560 minecraft:quartz_block
fill 512 193 571 512 205 572 minecraft:quartz_block
setblock 512 193 580 minecraft:quartz_block
fill 512 193 583 512 205 585 minecraft:quartz_block
fill 512 193 588 512 307 588 minecraft:quartz_block
fill 512 193 595 512 205 596 minecraft:quartz_block
setblock 512 193 597 minecraft:smooth_quartz
fill 512 193 598 512 307 598 minecraft:quartz_block
fill 470 194 557 470 307 560 minecraft:quartz_block
setblock 470 194 561 minecraft:smooth_quartz
fill 470 194 562 470 307 562 minecraft:quartz_block
fill 470 194 568 470 307 569 minecraft:quartz_block
setblock 470 194 570 minecraft:smooth_quartz
fill 470 194 571 470 307 572 minecraft:quartz_block
fill 470 194 574 470 307 574 minecraft:quartz_block
fill 470 194 583 470 307 583 minecraft:quartz_block
fill 470 194 599 470 205 599 minecraft:quartz_block
setblock 471 194 599 minecraft:smooth_quartz
setblock 472 194 563 minecraft:gold_block
fill 472 194 599 474 205 599 minecraft:quartz_block
setblock 475 194 599 minecraft:smooth_quartz
fill 476 194 562 476 195 564 minecraft:quartz_pillar
fill 476 194 599 477 307 599 minecraft:quartz_block
fill 477 194 557 477 205 557 minecraft:quartz_block
fill 477 194 563 477 196 563 minecraft:quartz_pillar
setblock 478 194 599 minecraft:smooth_quartz
fill 479 194 599 480 307 599 minecraft:quartz_block
setblock 480 194 557 minecraft:smooth_quartz
fill 481 194 557 482 307 557 minecraft:quartz_block
fill 483 194 599 483 205 599 minecraft:quartz_block
fill 494 194 557 494 307 557 minecraft:quartz_block
setblock 497 194 599 minecraft:smooth_quartz
fill 498 194 599 504 307 599 minecraft:quartz_block
fill 502 194 557 502 205 557 minecraft:quartz_block
setblock 503 194 557 minecraft:smooth_quartz
fill 504 194 557 504 205 557 minecraft:quartz_block
fill 504 194 563 505 195 563 minecraft:quartz_pillar
fill 505 194 562 505 195 562 minecraft:quartz_pillar
fill 505 194 564 505 195 564 minecraft:quartz_pillar
setblock 505 194 599 minecraft:smooth_quartz
fill 506 194 599 506 205 599 minecraft:quartz_block
fill 509 194 599 511 205 599 minecraft:quartz_block
fill 510 194 557 510 307 557 minecraft:quartz_block
fill 512 194 561 512 205 561 minecraft:quartz_block
setblock 512 194 562 minecraft:smooth_quartz
fill 512 194 563 512 307 563 minecraft:quartz_block
fill 512 194 565 512 307 567 minecraft:quartz_block
setblock 512 194 568 minecraft:smooth_quartz
fill 512 194 569 512 307 569 minecraft:quartz_block
setblock 512 194 570 minecraft:smooth_quartz
fill 512 194 573 512 205 576 minecraft:quartz_block
setblock 512 194 577 minecraft:smooth_quartz
fill 512 194 578 512 307 579 minecraft:quartz_block
setblock 512 194 580 minecraft:smooth_quartz
setblock 512 194 586 minecraft:smooth_quartz
fill 512 194 587 512 307 587 minecraft:quartz_block
fill 512 194 593 512 307 593 minecraft:quartz_block
setblock 512 194 594 minecraft:smooth_quartz
fill 512 194 597 512 205 597 minecraft:quartz_block
setblock 512 194 599 minecraft:smooth_quartz
fill 470 195 561 470 307 561 minecraft:quartz_block
fill 470 195 570 470 307 570 minecraft:quartz_block
fill 470 195 592 470 307 592 minecraft:quartz_block
fill 471 195 599 471 205 599 minecraft:quartz_block
setblock 474 195 563 minecraft:gold_block
fill 475 195 599 475 307 599 minecraft:quartz_block
fill 477 195 562 477 196 562 minecraft:quartz_pillar
fill 477 195 564 477 196 564 minecraft:quartz_pillar
fill 478 195 563 478 197 563 minecraft:quartz_pillar
fill 478 195 599 478 307 599 minecraft:quartz_block
fill 480 195 557 480 205 557 minecraft:quartz_block
fill 483 195 557 483 307 557 minecraft:quartz_block
fill 497 195 599 497 205 599 minecraft:quartz_block
fill 503 195 557 503 205 557 minecraft:quartz_block
fill 503 195 563 503 197 563 minecraft:quartz_pillar
fill 504 195 562 504 196 562 minecraft:quartz_pillar
fill 504 195 564 504 196 564 minecraft:quartz_pillar
fill 505 195 599 505 307 599 minecraft:quartz_block
fill 512 195 562 512 307 562 minecraft:quartz_block
fill 512 195 564 512 307 564 minecraft:quartz_block
fill 512 195 568 512 307 568 minecraft:quartz_block
fill 512 195 570 512 205 570 minecraft:quartz_block
fill 512 195 577 512 307 577 minecraft:quartz_block
fill 512 195 580 512 307 580 minecraft:quartz_block
fill 512 195 586 512 307 586 minecraft:quartz_block
fill 512 195 594 512 205 594 minecraft:quartz_block
fill 512 195 599 512 307 599 minecraft:quartz_block
fill 475 196 563 476 196 563 minecraft:gold_block
fill 478 196 562 479 196 562 minecraft:quartz_pillar
fill 478 196 564 479 196 564 minecraft:quartz_pillar
fill 479 196 563 480 198 563 minecraft:quartz_pillar
fill 501 196 563 502 198 563 minecraft:quartz_pillar
fill 502 196 562 503 196 562 minecraft:quartz_pillar
fill 502 196 564 503 196 564 minecraft:quartz_pillar
setblock 504 196 563 minecraft:quartz_pillar
fill 505 196 562 505 196 563 minecraft:smooth_quartz
fill 506 196 561 509 196 561 minecraft:smooth_quartz
setblock 506 196 564 minecraft:smooth_quartz
fill 507 196 565 508 196 565 minecraft:smooth_quartz
setblock 509 196 564 minecraft:smooth_quartz
setblock 510 196 563 minecraft:smooth_quartz
setblock 477 197 563 minecraft:gold_block
fill 479 197 562 481 197 562 minecraft:quartz_pillar
fill 479 197 564 481 197 564 minecraft:quartz_pillar
fill 481 197 563 482 198 563 minecraft:quartz_pillar
fill 499 197 563 500 199 563 minecraft:quartz_pillar
fill 500 197 562 502 197 562 minecraft:quartz_pillar
fill 500 197 564 502 197 564 minecraft:quartz_pillar
setblock 504 197 563 minecraft:gold_block
setblock 478 198 563 minecraft:gold_block
fill 480 198 562 483 198 562 minecraft:quartz_pillar
fill 480 198 564 483 198 564 minecraft:quartz_pillar
fill 483 198 563 484 200 563 minecraft:quartz_pillar
fill 497 198 563 498 200 563 minecraft:quartz_pillar
fill 498 198 562 501 198 562 minecraft:quartz_pillar
fill 498 198 564 501 198 564 minecraft:quartz_pillar
setblock 503 198 563 minecraft:gold_block
fill 480 199 563 481 199 563 minecraft:gold_block
fill 482 199 562 482 199 564 minecraft:quartz_pillar
fill 483 199 562 485 199 562 minecraft:quartz_pillar
fill 483 199 564 485 199 564 minecraft:quartz_pillar
fill 485 199 563 489 200 563 minecraft:quartz_pillar
fill 492 199 563 496 200 563 minecraft:quartz_pillar
fill 496 199 562 499 199 562 minecraft:quartz_pillar
fill 496 199 564 499 199 564 minecraft:quartz_pillar
setblock 501 199 563 minecraft:gold_block
fill 472 200 567 472 205 569 minecraft:quartz_pillar
fill 472 200 579 472 205 581 minecraft:quartz_pillar
fill 472 200 591 472 205 593 minecraft:quartz_pillar
fill 478 200 597 480 205 597 minecraft:quartz_pillar
fill 481 200 563 482 200 563 minecraft:gold_block
fill 482 200 559 484 205 559 minecraft:quartz_pillar
fill 485 200 562 496 200 562 minecraft:quartz_pillar
fill 485 200 564 496 200 564 minecraft:quartz_pillar
fill 490 200 563 491 201 563 minecraft:quartz_pillar
fill 490 200 597 492 205 597 minecraft:quartz_pillar
fill 494 200 559 496 205 559 minecraft:quartz_pillar
fill 499 200 563 500 200 563 minecraft:gold_block
fill 502 200 597 504 205 597 minecraft:quartz_pillar
fill 506 200 559 508 205 559 minecraft:quartz_pillar
fill 510 200 567 510 205 569 minecraft:quartz_pillar
fill 510 200 579 510 205 581 minecraft:quartz_pillar
fill 510 200 591 510 205 593 minecraft:quartz_pillar
setblock 473 201 560 minecraft:light[level=14]
setblock 473 201 568 minecraft:light[level=14]
setblock 473 201 576 minecraft:light[level=14]
setblock 473 201 584 minecraft:light[level=14]
setblock 473 201 592 minecraft:light[level=14]
setblock 481 201 560 minecraft:light[level=14]
setblock 481 201 568 minecraft:light[level=14]
setblock 481 201 576 minecraft:light[level=14]
setblock 481 201 584 minecraft:light[level=14]
setblock 481 201 592 minecraft:light[level=14]
fill 484 201 563 485 201 563 minecraft:gold_block
fill 486 201 563 489 201 563 minecraft:quartz_pillar
setblock 489 201 560 minecraft:light[level=14]
fill 489 201 562 492 201 562 minecraft:quartz_pillar
fill 489 201 564 492 201 564 minecraft:quartz_pillar
setblock 489 201 568 minecraft:light[level=14]
setblock 489 201 576 minecraft:light[level=14]
setblock 489 201 584 minecraft:light[level=14]
setblock 489 201 592 minecraft:light[level=14]
fill 492 201 563 495 201 563 minecraft:quartz_pillar
fill 496 201 563 497 201 563 minecraft:gold_block
setblock 497 201 560 minecraft:light[level=14]
setblock 497 201 568 minecraft:light[level=14]
setblock 497 201 576 minecraft:light[level=14]
setblock 497 201 584 minecraft:light[level=14]
setblock 497 201 592 minecraft:light[level=14]
fill 499 201 559 505 202 559 minecraft:iron_block
setblock 505 201 560 minecraft:light[level=14]
setblock 505 201 568 minecraft:light[level=14]
setblock 505 201 576 minecraft:light[level=14]
setblock 505 201 584 minecraft:light[level=14]
setblock 505 201 592 minecraft:light[level=14]
fill 486 202 563 495 202 563 minecraft:gold_block
fill 505 204 562 505 204 563 minecraft:smooth_quartz
fill 506 204 561 509 204 561 minecraft:smooth_quartz
setblock 506 204 564 minecraft:smooth_quartz
fill 507 204 565 508 204 565 minecraft:smooth_quartz
setblock 509 204 564 minecraft:smooth_quartz
setblock 510 204 563 minecraft:smooth_quartz
fill 471 205 561 471 205 566 minecraft:smooth_quartz
fill 471 205 573 471 205 578 minecraft:smooth_quartz
fill 471 205 585 471 205 590 minecraft:smooth_quartz
fill 471 205 597 471 205 598 minecraft:smooth_quartz
fill 472 205 598 475 205 598 minecraft:smooth_quartz
fill 475 205 558 480 205 558 minecraft:smooth_quartz
fill 482 205 598 487 205 598 minecraft:smooth_quartz
fill 487 205 558 492 205 558 minecraft:smooth_quartz
fill 494 205 598 499 205 598 minecraft:smooth_quartz
fill 499 205 558 504 205 558 minecraft:smooth_quartz
fill 506 205 598 511 205 598 minecraft:smooth_quartz
fill 511 205 558 511 205 563 minecraft:smooth_quartz
fill 511 205 570 511 205 575 minecraft:smooth_quartz
fill 511 205 582 511 205 587 minecraft:smooth_quartz
fill 511 205 594 511 205 597 minecraft:smooth_quartz
fill 470 206 563 470 211 566 minecraft:pearlescent_froglight
fill 470 206 567 470 307 567 minecraft:quartz_block
fill 470 206 575 470 211 578 minecraft:pearlescent_froglight
fill 470 206 585 470 307 586 minecraft:quartz_block
fill 470 206 587 470 211 590 minecraft:pearlescent_froglight
fill 470 206 591 470 307 591 minecraft:quartz_block
fill 470 206 599 473 211 599 minecraft:pearlescent_froglight
fill 474 206 599 474 307 599 minecraft:quartz_block
fill 477 206 557 480 211 557 minecraft:pearlescent_froglight
fill 482 206 599 485 211 599 minecraft:pearlescent_froglight
fill 484 206 557 488 307 557 minecraft:quartz_block
fill 489 206 557 492 211 557 minecraft:pearlescent_froglight
fill 491 206 599 493 307 599 minecraft:quartz_block
fill 493 206 557 493 307 557 minecraft:quartz_block
fill 494 206 599 497 211 599 minecraft:pearlescent_froglight
fill 498 206 557 500 307 557 minecraft:quartz_block
fill 501 206 557 504 211 557 minecraft:pearlescent_froglight
fill 506 206 599 509 211 599 minecraft:pearlescent_froglight
fill 510 206 599 511 307 599 minecraft:quartz_block
fill 512 206 558 512 211 561 minecraft:pearlescent_froglight
fill 512 206 570 512 211 573 minecraft:pearlescent_froglight
fill 512 206 574 512 307 576 minecraft:quartz_block
fill 512 206 581 512 307 581 minecraft:quartz_block
fill 512 206 582 512 211 585 minecraft:pearlescent_froglight
fill 512 206 594 512 211 597 minecraft:pearlescent_froglight
setblock 473 209 560 minecraft:light[level=14]
setblock 473 209 568 minecraft:light[level=14]
setblock 473 209 576 minecraft:light[level=14]
setblock 473 209 584 minecraft:light[level=14]
setblock 473 209 592 minecraft:light[level=14]
setblock 481 209 560 minecraft:light[level=14]
setblock 481 209 568 minecraft:light[level=14]
setblock 481 209 576 minecraft:light[level=14]
setblock 481 209 584 minecraft:light[level=14]
setblock 481 209 592 minecraft:light[level=14]
setblock 489 209 560 minecraft:light[level=14]
setblock 489 209 568 minecraft:light[level=14]
setblock 489 209 576 minecraft:light[level=14]
setblock 489 209 584 minecraft:light[level=14]
setblock 489 209 592 minecraft:light[level=14]
setblock 497 209 560 minecraft:light[level=14]
setblock 497 209 568 minecraft:light[level=14]
setblock 497 209 576 minecraft:light[level=14]
setblock 497 209 584 minecraft:light[level=14]
setblock 497 209 592 minecraft:light[level=14]
setblock 505 209 560 minecraft:light[level=14]
setblock 505 209 568 minecraft:light[level=14]
setblock 505 209 576 minecraft:light[level=14]
setblock 505 209 584 minecraft:light[level=14]
setblock 505 209 592 minecraft:light[level=14]
fill 470 212 563 470 245 563 minecraft:quartz_block
fill 470 212 564 470 212 565 minecraft:pearlescent_froglight
fill 470 212 566 470 245 566 minecraft:quartz_block
fill 470 212 575 470 245 575 minecraft:quartz_block
fill 470 212 576 470 212 577 minecraft:pearlescent_froglight
fill 470 212 578 470 245 578 minecraft:quartz_block
fill 470 212 587 470 245 587 minecraft:quartz_block
fill 470 212 588 470 212 589 minecraft:pearlescent_froglight
fill 470 212 590 470 245 590 minecraft:quartz_block
fill 470 212 599 470 245 599 minecraft:quartz_block
fill 471 212 599 472 212 599 minecraft:pearlescent_froglight
fill 473 212 599 473 245 599 minecraft:quartz_block
fill 477 212 557 477 245 557 minecraft:quartz_block
fill 478 212 557 479 212 557 minecraft:pearlescent_froglight
fill 480 212 557 480 245 557 minecraft:quartz_block
fill 482 212 599 482 245 599 minecraft:quartz_block
fill 483 212 599 484 212 599 minecraft:pearlescent_froglight
fill 485 212 599 485 245 599 minecraft:quartz_block
fill 489 212 557 489 245 557 minecraft:quartz_block
fill 490 212 557 491 212 557 minecraft:pearlescent_froglight
fill 492 212 557 492 245 557 minecraft:quartz_block
fill 494 212 599 494 245 599 minecraft:quartz_block
fill 495 212 599 496 212 599 minecraft:pearlescent_froglight
fill 497 212 599 497 245 599 minecraft:quartz_block
fill 501 212 557 501 245 557 minecraft:quartz_block
fill 502 212 557 503 212 557 minecraft:pearlescent_froglight
fill 504 212 557 504 245 557 minecraft:quartz_block
fill 505 212 562 505 212 563 minecraft:smooth_quartz
fill 506 212 561 509 212 561 minecraft:smooth_quartz
setblock 506 212 564 minecraft:smooth_quartz
fill 506 212 599 506 245 599 minecraft:quartz_block
fill 507 212 565 508 212 565 minecraft:smooth_quartz
fill 507 212 599 508 212 599 minecraft:pearlescent_froglight
setblock 509 212 564 minecraft:smooth_quartz
fill 509 212 599 509 245 599 minecraft:quartz_block
setblock 510 212 563 minecraft:smooth_quartz
fill 512 212 558 512 245 558 minecraft:quartz_block
fill 512 212 559 512 212 560 minecraft:pearlescent_froglight
fill 512 212 561 512 245 561 minecraft:quartz_block
fill 512 212 570 512 245 570 minecraft:quartz_block
fill 512 212 571 512 212 572 minecraft:pearlescent_froglight
fill 512 212 573 512 245 573 minecraft:quartz_block
fill 512 212 582 512 245 582 minecraft:quartz_block
fill 512 212 583 512 212 584 minecraft:pearlescent_froglight
fill 512 212 585 512 245 585 minecraft:quartz_block
fill 512 212 594 512 245 594 minecraft:quartz_block
fill 512 212 595 512 212 596 minecraft:pearlescent_froglight
fill 512 212 597 512 245 597 minecraft:quartz_block
fill 470 213 564 470 245 565 minecraft:quartz_block
fill 470 213 576 470 245 577 minecraft:quartz_block
fill 470 213 588 470 245 589 minecraft:quartz_block
fill 471 213 599 472 245 599 minecraft:quartz_block
fill 478 213 557 479 245 557 minecraft:quartz_block
fill 483 213 599 484 245 599 minecraft:quartz_block
fill 490 213 557 491 245 557 minecraft:quartz_block
fill 495 213 599 496 245 599 minecraft:quartz_block
fill 502 213 557 503 245 557 minecraft:quartz_block
fill 507 213 599 508 245 599 minecraft:quartz_block
fill 512 213 559 512 245 560 minecraft:quartz_block
fill 512 213 571 512 245 572 minecraft:quartz_block
fill 512 213 583 512 245 584 minecraft:quartz_block
fill 512 213 595 512 245 596 minecraft:quartz_block
setblock 473 217 560 minecraft:light[level=14]
setblock 473 217 568 minecraft:light[level=14]
setblock 473 217 576 minecraft:light[level=14]
setblock 473 217 584 minecraft:light[level=14]
setblock 473 217 592 minecraft:light[level=14]
setblock 481 217 560 minecraft:light[level=14]
setblock 481 217 568 minecraft:light[level=14]
setblock 481 217 576 minecraft:light[level=14]
setblock 481 217 584 minecraft:light[level=14]
setblock 481 217 592 minecraft:light[level=14]
setblock 489 217 560 minecraft:light[level=14]
setblock 489 217 568 minecraft:light[level=14]
setblock 489 217 576 minecraft:light[level=14]
setblock 489 217 584 minecraft:light[level=14]
setblock 489 217 592 minecraft:light[level=14]
setblock 497 217 560 minecraft:light[level=14]
setblock 497 217 568 minecraft:light[level=14]
setblock 497 217 576 minecraft:light[level=14]
setblock 497 217 584 minecraft:light[level=14]
setblock 497 217 592 minecraft:light[level=14]
setblock 505 217 560 minecraft:light[level=14]
setblock 505 217 568 minecraft:light[level=14]
setblock 505 217 576 minecraft:light[level=14]
setblock 505 217 584 minecraft:light[level=14]
setblock 505 217 592 minecraft:light[level=14]
fill 472 220 567 472 225 569 minecraft:quartz_pillar
fill 472 220 579 472 225 581 minecraft:quartz_pillar
fill 472 220 591 472 225 593 minecraft:quartz_pillar
fill 478 220 597 480 225 597 minecraft:quartz_pillar
fill 482 220 559 484 225 559 minecraft:quartz_pillar
fill 490 220 597 492 225 597 minecraft:quartz_pillar
fill 494 220 559 496 225 559 minecraft:quartz_pillar
fill 502 220 597 504 225 597 minecraft:quartz_pillar
fill 505 220 562 505 220 563 minecraft:smooth_quartz
fill 506 220 559 508 225 559 minecraft:quartz_pillar
fill 506 220 561 509 220 561 minecraft:smooth_quartz
setblock 506 220 564 minecraft:smooth_quartz
fill 507 220 565 508 220 565 minecraft:smooth_quartz
setblock 509 220 564 minecraft:smooth_quartz
setblock 510 220 563 minecraft:smooth_quartz
fill 510 220 567 510 225 569 minecraft:quartz_pillar
fill 510 220 579 510 225 581 minecraft:quartz_pillar
fill 510 220 591 510 225 593 minecraft:quartz_pillar
fill 506 224 561 509 225 561 minecraft:gold_block
fill 506 224 564 506 225 564 minecraft:gold_block
fill 507 224 565 508 225 565 minecraft:gold_block
fill 509 224 564 509 225 564 minecraft:gold_block
fill 471 225 561 471 225 566 minecraft:smooth_quartz
fill 471 225 573 471 225 578 minecraft:smooth_quartz
fill 471 225 585 471 225 590 minecraft:smooth_quartz
fill 471 225 597 471 225 598 minecraft:smooth_quartz
fill 472 225 598 475 225 598 minecraft:smooth_quartz
setblock 473 225 560 minecraft:light[level=14]
setblock 473 225 568 minecraft:light[level=14]
setblock 473 225 576 minecraft:light[level=14]
setblock 473 225 584 minecraft:light[level=14]
setblock 473 225 592 minecraft:light[level=14]
fill 475 225 558 480 225 558 minecraft:smooth_quartz
setblock 481 225 560 minecraft:light[level=14]
setblock 481 225 568 minecraft:light[level=14]
setblock 481 225 576 minecraft:light[level=14]
setblock 481 225 584 minecraft:light[level=14]
setblock 481 225 592 minecraft:light[level=14]
fill 482 225 598 487 225 598 minecraft:smooth_quartz
fill 487 225 558 492 225 558 minecraft:smooth_quartz
setblock 489 225 560 minecraft:light[level=14]
setblock 489 225 568 minecraft:light[level=14]
setblock 489 225 584 minecraft:light[level=14]
setblock 489 225 592 minecraft:light[level=14]
fill 494 225 598 499 225 598 minecraft:smooth_quartz
setblock 497 225 560 minecraft:light[level=14]
setblock 497 225 568 minecraft:light[level=14]
setblock 497 225 576 minecraft:light[level=14]
setblock 497 225 584 minecraft:light[level=14]
setblock 497 225 592 minecraft:light[level=14]
fill 499 225 558 504 225 558 minecraft:smooth_quartz
setblock 505 225 560 minecraft:light[level=14]
setblock 505 225 568 minecraft:light[level=14]
setblock 505 225 576 minecraft:light[level=14]
setblock 505 225 584 minecraft:light[level=14]
setblock 505 225 592 minecraft:light[level=14]
fill 506 225 598 511 225 598 minecraft:smooth_quartz
fill 511 225 558 511 225 563 minecraft:smooth_quartz
fill 511 225 570 511 225 575 minecraft:smooth_quartz
fill 511 225 582 511 225 587 minecraft:smooth_quartz
fill 511 225 594 511 225 597 minecraft:smooth_quartz
fill 485 230 572 487 230 574 minecraft:redstone_block
fill 486 230 579 488 230 581 minecraft:redstone_block
fill 490 230 570 492 230 572 minecraft:redstone_block
fill 492 230 579 494 230 581 minecraft:redstone_block
fill 472 231 574 484 231 578 minecraft:gold_block
fill 485 231 575 488 231 578 minecraft:gold_block
fill 488 231 558 489 231 574 minecraft:gold_block
fill 488 231 582 492 231 594 minecraft:gold_block
fill 489 231 578 491 231 581 minecraft:gold_block
fill 490 231 558 492 231 569 minecraft:gold_block
fill 490 231 573 492 231 574 minecraft:gold_block
fill 492 231 575 508 231 578 minecraft:gold_block
fill 493 231 574 508 231 574 minecraft:gold_block
fill 471 232 558 471 232 598 minecraft:smooth_quartz
fill 472 232 558 483 232 573 minecraft:smooth_quartz
fill 472 232 574 483 232 574 minecraft:lapis_block
fill 472 232 575 483 232 577 minecraft:gold_block
fill 472 232 578 484 232 578 minecraft:lapis_block
fill 472 232 579 484 232 598 minecraft:smooth_quartz
fill 484 232 558 487 232 570 minecraft:smooth_quartz
fill 484 232 571 484 232 575 minecraft:pearlescent_froglight
fill 484 232 576 487 232 577 minecraft:gold_block
fill 485 232 571 489 232 571 minecraft:pearlescent_froglight
fill 485 232 572 487 232 574 minecraft:smooth_quartz
fill 485 232 575 488 232 575 minecraft:pearlescent_froglight
fill 485 232 578 485 232 582 minecraft:pearlescent_froglight
fill 485 232 583 487 232 598 minecraft:smooth_quartz
fill 486 232 578 495 232 578 minecraft:pearlescent_froglight
fill 486 232 579 488 232 581 minecraft:smooth_quartz
fill 486 232 582 489 232 582 minecraft:pearlescent_froglight
fill 488 232 558 488 232 570 minecraft:lapis_block
fill 488 232 572 489 232 574 minecraft:pearlescent_froglight
fill 488 232 576 488 232 577 minecraft:pearlescent_froglight
fill 488 232 583 488 232 594 minecraft:lapis_block
fill 488 232 595 511 232 598 minecraft:smooth_quartz
fill 489 232 558 491 232 568 minecraft:gold_block
fill 489 232 569 489 232 570 minecraft:pearlescent_froglight
fill 489 232 579 489 232 581 minecraft:pearlescent_froglight
fill 489 232 583 491 232 594 minecraft:gold_block
fill 490 232 569 493 232 569 minecraft:pearlescent_froglight
fill 490 232 570 492 232 572 minecraft:smooth_quartz
fill 490 232 573 492 232 574 minecraft:pearlescent_froglight
fill 490 232 579 490 232 582 minecraft:gold_block
fill 491 232 579 491 232 582 minecraft:pearlescent_froglight
fill 492 232 558 492 232 568 minecraft:lapis_block
fill 492 232 575 492 232 577 minecraft:pearlescent_froglight
fill 492 232 579 494 232 581 minecraft:smooth_quartz
fill 492 232 582 495 232 582 minecraft:pearlescent_froglight
fill 492 232 583 492 232 594 minecraft:lapis_block
fill 493 232 558 511 232 568 minecraft:smooth_quartz
fill 493 232 570 493 232 573 minecraft:pearlescent_froglight
fill 493 232 574 508 232 574 minecraft:lapis_block
fill 493 232 575 508 232 577 minecraft:gold_block
fill 493 232 583 511 232 594 minecraft:smooth_quartz
fill 494 232 569 511 232 573 minecraft:smooth_quartz
fill 495 232 579 495 232 581 minecraft:pearlescent_froglight
fill 496 232 578 508 232 578 minecraft:lapis_block
fill 496 232 579 511 232 582 minecraft:smooth_quartz
fill 509 232 574 511 232 578 minecraft:smooth_quartz
setblock 473 233 560 minecraft:light[level=14]
setblock 473 233 568 minecraft:light[level=14]
setblock 473 233 576 minecraft:light[level=14]
setblock 473 233 584 minecraft:light[level=14]
setblock 473 233 592 minecraft:light[level=14]
setblock 481 233 560 minecraft:light[level=14]
setblock 481 233 568 minecraft:light[level=14]
setblock 481 233 576 minecraft:light[level=14]
setblock 481 233 584 minecraft:light[level=14]
setblock 481 233 592 minecraft:light[level=14]
setblock 489 233 560 minecraft:light[level=14]
setblock 489 233 568 minecraft:light[level=14]
setblock 489 233 584 minecraft:light[level=14]
setblock 489 233 592 minecraft:light[level=14]
setblock 497 233 560 minecraft:light[level=14]
setblock 497 233 568 minecraft:light[level=14]
setblock 497 233 576 minecraft:light[level=14]
setblock 497 233 584 minecraft:light[level=14]
setblock 497 233 592 minecraft:light[level=14]
setblock 505 233 560 minecraft:light[level=14]
setblock 505 233 568 minecraft:light[level=14]
setblock 505 233 576 minecraft:light[level=14]
setblock 505 233 584 minecraft:light[level=14]
setblock 505 233 592 minecraft:light[level=14]
fill 471 236 558 473 273 558 minecraft:quartz_pillar
fill 471 236 568 471 273 570 minecraft:quartz_pillar
fill 471 236 580 471 273 582 minecraft:quartz_pillar
fill 471 236 592 471 273 594 minecraft:quartz_pillar
fill 472 236 562 472 236 563 minecraft:smooth_quartz
setblock 473 236 561 minecraft:smooth_quartz
fill 473 236 562 475 273 563 minecraft:quartz_pillar
setblock 473 236 564 minecraft:smooth_quartz
setblock 474 236 560 minecraft:smooth_quartz
fill 474 236 561 475 273 561 minecraft:quartz_pillar
fill 474 236 564 475 273 564 minecraft:quartz_pillar
fill 474 236 565 475 236 565 minecraft:smooth_quartz
fill 476 236 561 476 236 564 minecraft:smooth_quartz
fill 477 236 598 479 273 598 minecraft:quartz_pillar
fill 483 236 558 485 273 558 minecraft:quartz_pillar
fill 489 236 598 491 273 598 minecraft:quartz_pillar
fill 495 236 558 497 273 558 minecraft:quartz_pillar
fill 501 236 598 503 273 598 minecraft:quartz_pillar
fill 507 236 558 509 273 558 minecraft:quartz_pillar
fill 511 236 566 511 273 568 minecraft:quartz_pillar
fill 511 236 578 511 273 580 minecraft:quartz_pillar
fill 511 236 590 511 273 592 minecraft:quartz_pillar
fill 472 240 567 472 245 569 minecraft:quartz_pillar
fill 472 240 579 472 245 581 minecraft:quartz_pillar
fill 472 240 591 472 245 593 minecraft:quartz_pillar
fill 478 240 597 480 245 597 minecraft:quartz_pillar
fill 482 240 559 484 245 559 minecraft:quartz_pillar
fill 490 240 597 492 245 597 minecraft:quartz_pillar
fill 494 240 559 496 245 559 minecraft:quartz_pillar
fill 502 240 597 504 245 597 minecraft:quartz_pillar
fill 506 240 559 508 245 559 minecraft:quartz_pillar
fill 510 240 567 510 245 569 minecraft:quartz_pillar
fill 510 240 579 510 245 581 minecraft:quartz_pillar
fill 510 240 591 510 245 593 minecraft:quartz_pillar
setblock 473 241 560 minecraft:light[level=14]
setblock 473 241 568 minecraft:light[level=14]
setblock 473 241 576 minecraft:light[level=14]
setblock 473 241 584 minecraft:light[level=14]
setblock 473 241 592 minecraft:light[level=14]
setblock 481 241 560 minecraft:light[level=14]
setblock 481 241 568 minecraft:light[level=14]
setblock 481 241 576 minecraft:light[level=14]
setblock 481 241 584 minecraft:light[level=14]
setblock 481 241 592 minecraft:light[level=14]
setblock 489 241 560 minecraft:light[level=14]
setblock 489 241 568 minecraft:light[level=14]
setblock 489 241 584 minecraft:light[level=14]
setblock 489 241 592 minecraft:light[level=14]
setblock 497 241 560 minecraft:light[level=14]
setblock 497 241 568 minecraft:light[level=14]
setblock 497 241 576 minecraft:light[level=14]
setblock 497 241 584 minecraft:light[level=14]
setblock 497 241 592 minecraft:light[level=14]
setblock 505 241 560 minecraft:light[level=14]
setblock 505 241 568 minecraft:light[level=14]
setblock 505 241 576 minecraft:light[level=14]
setblock 505 241 584 minecraft:light[level=14]
setblock 505 241 592 minecraft:light[level=14]
fill 472 244 562 472 244 563 minecraft:smooth_quartz
setblock 473 244 561 minecraft:smooth_quartz
setblock 473 244 564 minecraft:smooth_quartz
setblock 474 244 560 minecraft:smooth_quartz
fill 474 244 565 475 244 565 minecraft:smooth_quartz
fill 476 244 561 476 244 564 minecraft:smooth_quartz
fill 484 244 593 484 245 593 minecraft:smooth_quartz
fill 493 244 562 493 245 562 minecraft:smooth_quartz
fill 499 244 562 499 245 562 minecraft:smooth_quartz
fill 506 244 592 506 245 592 minecraft:smooth_quartz
fill 471 245 561 471 245 566 minecraft:smooth_quartz
fill 471 245 573 471 245 578 minecraft:smooth_quartz
fill 471 245 585 471 245 590 minecraft:smooth_quartz
fill 471 245 597 471 245 598 minecraft:smooth_quartz
fill 472 245 598 475 245 598 minecraft:smooth_quartz
fill 475 245 558 480 245 558 minecraft:smooth_quartz
fill 482 245 598 487 245 598 minecraft:smooth_quartz
fill 484 245 594 484 246 594 minecraft:smooth_quartz
fill 487 245 558 492 245 558 minecraft:smooth_quartz
fill 493 245 561 493 246 561 minecraft:smooth_quartz
fill 494 245 598 499 245 598 minecraft:smooth_quartz
fill 499 245 558 504 245 558 minecraft:smooth_quartz
fill 499 245 561 499 246 561 minecraft:smooth_quartz
fill 506 245 598 511 245 598 minecraft:smooth_quartz
fill 507 245 592 507 246 592 minecraft:smooth_quartz
fill 511 245 558 511 245 563 minecraft:smooth_quartz
fill 511 245 570 511 245 575 minecraft:smooth_quartz
fill 511 245 582 511 245 587 minecraft:smooth_quartz
fill 511 245 594 511 245 597 minecraft:smooth_quartz
fill 470 246 563 470 251 566 minecraft:pearlescent_froglight
fill 470 246 575 470 251 578 minecraft:pearlescent_froglight
fill 470 246 587 470 251 590 minecraft:pearlescent_froglight
fill 470 246 599 473 251 599 minecraft:pearlescent_froglight
fill 477 246 557 480 251 557 minecraft:pearlescent_froglight
fill 482 246 599 485 251 599 minecraft:pearlescent_froglight
fill 484 246 595 484 247 595 minecraft:smooth_quartz
fill 489 246 557 492 251 557 minecraft:pearlescent_froglight
fill 493 246 560 493 247 560 minecraft:smooth_quartz
fill 494 246 599 497 251 599 minecraft:pearlescent_froglight
fill 499 246 560 499 247 560 minecraft:smooth_quartz
fill 501 246 557 504 251 557 minecraft:pearlescent_froglight
fill 506 246 599 509 251 599 minecraft:pearlescent_froglight
fill 508 246 592 508 247 592 minecraft:smooth_quartz
fill 512 246 558 512 251 561 minecraft:pearlescent_froglight
fill 512 246 570 512 251 573 minecraft:pearlescent_froglight
fill 512 246 582 512 251 585 minecraft:pearlescent_froglight
fill 512 246 594 512 251 597 minecraft:pearlescent_froglight
fill 484 247 596 484 248 596 minecraft:smooth_quartz
fill 493 247 559 493 248 559 minecraft:smooth_quartz
fill 499 247 559 499 248 559 minecraft:smooth_quartz
fill 509 247 592 509 248 592 minecraft:smooth_quartz
fill 484 248 597 484 249 597 minecraft:smooth_quartz
fill 493 248 558 493 249 558 minecraft:smooth_quartz
fill 499 248 558 499 249 558 minecraft:smooth_quartz
fill 510 248 592 510 249 592 minecraft:smooth_quartz
setblock 473 249 560 minecraft:light[level=14]
setblock 473 249 568 minecraft:light[level=14]
setblock 473 249 576 minecraft:light[level=14]
setblock 473 249 584 minecraft:light[level=14]
setblock 473 249 592 minecraft:light[level=14]
setblock 475 249 570 minecraft:pearlescent_froglight
setblock 475 249 576 minecraft:pearlescent_froglight
setblock 475 249 582 minecraft:pearlescent_froglight
setblock 475 249 588 minecraft:pearlescent_froglight
setblock 475 249 594 minecraft:pearlescent_froglight
setblock 477 249 562 minecraft:pearlescent_froglight
setblock 481 249 560 minecraft:light[level=14]
setblock 481 249 568 minecraft:light[level=14]
setblock 481 249 576 minecraft:light[level=14]
setblock 481 249 584 minecraft:light[level=14]
setblock 481 249 592 minecraft:light[level=14]
setblock 481 249 594 minecraft:pearlescent_froglight
setblock 483 249 562 minecraft:pearlescent_froglight
setblock 487 249 594 minecraft:pearlescent_froglight
setblock 489 249 560 minecraft:light[level=14]
setblock 489 249 562 minecraft:pearlescent_froglight
setblock 489 249 568 minecraft:light[level=14]
setblock 489 249 584 minecraft:light[level=14]
setblock 489 249 592 minecraft:light[level=14]
setblock 493 249 594 minecraft:pearlescent_froglight
setblock 495 249 562 minecraft:pearlescent_froglight
setblock 497 249 560 minecraft:light[level=14]
setblock 497 249 568 minecraft:light[level=14]
setblock 497 249 576 minecraft:light[level=14]
setblock 497 249 584 minecraft:light[level=14]
setblock 497 249 592 minecraft:light[level=14]
setblock 499 249 594 minecraft:pearlescent_froglight
setblock 501 249 562 minecraft:pearlescent_froglight
setblock 505 249 560 minecraft:light[level=14]
setblock 505 249 568 minecraft:light[level=14]
setblock 505 249 576 minecraft:light[level=14]
setblock 505 249 584 minecraft:light[level=14]
setblock 505 249 592 minecraft:light[level=14]
setblock 505 249 594 minecraft:pearlescent_froglight
setblock 507 249 562 minecraft:pearlescent_froglight
setblock 507 249 568 minecraft:pearlescent_froglight
setblock 507 249 574 minecraft:pearlescent_froglight
setblock 507 249 580 minecraft:pearlescent_froglight
setblock 507 249 586 minecraft:pearlescent_froglight
setblock 507 249 592 minecraft:pearlescent_froglight
fill 471 250 559 472 250 567 minecraft:quartz_pillar
fill 471 250 571 475 250 579 minecraft:quartz_pillar
fill 471 250 583 475 250 591 minecraft:quartz_pillar
fill 471 250 595 476 250 598 minecraft:quartz_pillar
fill 472 250 568 475 250 570 minecraft:quartz_pillar
fill 472 250 580 475 250 582 minecraft:quartz_pillar
fill 472 250 592 475 250 594 minecraft:quartz_pillar
fill 473 250 559 473 250 561 minecraft:quartz_pillar
fill 473 250 564 473 250 567 minecraft:quartz_pillar
fill 474 250 558 482 250 560 minecraft:quartz_pillar
fill 474 250 565 475 250 567 minecraft:quartz_pillar
fill 476 250 561 511 250 562 minecraft:quartz_pillar
fill 476 250 594 511 250 594 minecraft:quartz_pillar
fill 477 250 595 511 250 597 minecraft:quartz_pillar
fill 480 250 598 488 250 598 minecraft:quartz_pillar
fill 483 250 559 511 250 560 minecraft:quartz_pillar
fill 486 250 558 494 250 558 minecraft:quartz_pillar
fill 492 250 598 500 250 598 minecraft:quartz_pillar
fill 498 250 558 506 250 558 minecraft:quartz_pillar
fill 504 250 598 511 250 598 minecraft:quartz_pillar
fill 507 250 563 510 250 593 minecraft:quartz_pillar
fill 510 250 558 511 250 558 minecraft:quartz_pillar
fill 511 250 563 511 250 565 minecraft:quartz_pillar
fill 511 250 569 511 250 577 minecraft:quartz_pillar
fill 511 250 581 511 250 589 minecraft:quartz_pillar
setblock 511 250 593 minecraft:quartz_pillar
fill 475 251 565 475 251 594 minecraft:gold_block
fill 476 251 562 507 251 562 minecraft:gold_block
fill 476 251 594 507 251 594 minecraft:gold_block
fill 507 251 563 507 251 593 minecraft:gold_block
fill 509 251 565 509 264 565 minecraft:blue_wool
fill 470 252 563 470 265 563 minecraft:quartz_block
fill 470 252 564 470 252 565 minecraft:pearlescent_froglight
fill 470 252 566 470 265 566 minecraft:quartz_block
fill 470 252 575 470 265 575 minecraft:quartz_block
fill 470 252 576 470 252 577 minecraft:pearlescent_froglight
fill 470 252 578 470 265 578 minecraft:quartz_block
fill 470 252 587 470 265 587 minecraft:quartz_block
fill 470 252 588 470 252 589 minecraft:pearlescent_froglight
fill 470 252 590 470 265 590 minecraft:quartz_block
fill 470 252 599 470 265 599 minecraft:quartz_block
fill 471 252 599 472 252 599 minecraft:pearlescent_froglight
fill 472 252 562 472 252 563 minecraft:smooth_quartz
setblock 473 252 561 minecraft:smooth_quartz
setblock 473 252 564 minecraft:smooth_quartz
fill 473 252 599 473 265 599 minecraft:quartz_block
setblock 474 252 560 minecraft:smooth_quartz
fill 474 252 565 475 252 565 minecraft:smooth_quartz
fill 476 252 561 476 252 564 minecraft:smooth_quartz
fill 477 252 557 477 265 557 minecraft:quartz_block
fill 478 252 557 479 252 557 minecraft:pearlescent_froglight
fill 480 252 557 480 265 557 minecraft:quartz_block
fill 482 252 599 482 265 599 minecraft:quartz_block
fill 483 252 599 484 252 599 minecraft:pearlescent_froglight
fill 485 252 599 485 265 599 minecraft:quartz_block
fill 489 252 557 489 265 557 minecraft:quartz_block
fill 490 252 557 491 252 557 minecraft:pearlescent_froglight
fill 492 252 557 492 265 557 minecraft:quartz_block
fill 494 252 599 494 265 599 minecraft:quartz_block
fill 495 252 599 496 252 599 minecraft:pearlescent_froglight
fill 497 252 599 497 265 599 minecraft:quartz_block
fill 501 252 557 501 265 557 minecraft:quartz_block
fill 502 252 557 503 252 557 minecraft:pearlescent_froglight
fill 504 252 557 504 265 557 minecraft:quartz_block
fill 506 252 599 506 265 599 minecraft:quartz_block
fill 507 252 599 508 252 599 minecraft:pearlescent_froglight
fill 509 252 563 509 264 564 minecraft:blue_wool
fill 509 252 566 509 264 567 minecraft:blue_wool
fill 509 252 599 509 265 599 minecraft:quartz_block
fill 512 252 558 512 265 558 minecraft:quartz_block
fill 512 252 559 512 252 560 minecraft:pearlescent_froglight
fill 512 252 561 512 265 561 minecraft:quartz_block
fill 512 252 570 512 265 570 minecraft:quartz_block
fill 512 252 571 512 252 572 minecraft:pearlescent_froglight
fill 512 252 573 512 265 573 minecraft:quartz_block
fill 512 252 582 512 265 582 minecraft:quartz_block
fill 512 252 583 512 252 584 minecraft:pearlescent_froglight
fill 512 252 585 512 265 585 minecraft:quartz_block
fill 512 252 594 512 265 594 minecraft:quartz_block
fill 512 252 595 512 252 596 minecraft:pearlescent_froglight
fill 512 252 597 512 265 597 minecraft:quartz_block
fill 470 253 564 470 265 565 minecraft:quartz_block
fill 470 253 576 470 265 577 minecraft:quartz_block
fill 470 253 588 470 265 589 minecraft:quartz_block
fill 471 253 599 472 265 599 minecraft:quartz_block
fill 478 253 557 479 265 557 minecraft:quartz_block
fill 483 253 599 484 265 599 minecraft:quartz_block
fill 490 253 557 491 265 557 minecraft:quartz_block
fill 495 253 599 496 265 599 minecraft:quartz_block
fill 502 253 557 503 265 557 minecraft:quartz_block
fill 507 253 599 508 265 599 minecraft:quartz_block
fill 512 253 559 512 265 560 minecraft:quartz_block
fill 512 253 571 512 265 572 minecraft:quartz_block
fill 512 253 583 512 265 584 minecraft:quartz_block
fill 512 253 595 512 265 596 minecraft:quartz_block
setblock 473 257 560 minecraft:light[level=14]
setblock 473 257 568 minecraft:light[level=14]
setblock 473 257 576 minecraft:light[level=14]
setblock 473 257 584 minecraft:light[level=14]
setblock 473 257 592 minecraft:light[level=14]
setblock 481 257 560 minecraft:light[level=14]
setblock 481 257 568 minecraft:light[level=14]
setblock 481 257 576 minecraft:light[level=14]
setblock 481 257 584 minecraft:light[level=14]
setblock 481 257 592 minecraft:light[level=14]
setblock 489 257 560 minecraft:light[level=14]
setblock 489 257 568 minecraft:light[level=14]
setblock 489 257 576 minecraft:light[level=14]
setblock 489 257 584 minecraft:light[level=14]
setblock 489 257 592 minecraft:light[level=14]
setblock 497 257 560 minecraft:light[level=14]
setblock 497 257 568 minecraft:light[level=14]
setblock 497 257 576 minecraft:light[level=14]
setblock 497 257 584 minecraft:light[level=14]
setblock 497 257 592 minecraft:light[level=14]
setblock 505 257 560 minecraft:light[level=14]
setblock 505 257 568 minecraft:light[level=14]
setblock 505 257 576 minecraft:light[level=14]
setblock 505 257 584 minecraft:light[level=14]
setblock 505 257 592 minecraft:light[level=14]
fill 472 260 562 472 260 563 minecraft:smooth_quartz
fill 472 260 567 472 265 569 minecraft:quartz_pillar
fill 472 260 579 472 265 581 minecraft:quartz_pillar
fill 472 260 591 472 265 593 minecraft:quartz_pillar
setblock 473 260 561 minecraft:smooth_quartz
setblock 473 260 564 minecraft:smooth_quartz
setblock 474 260 560 minecraft:smooth_quartz
fill 474 260 565 475 260 565 minecraft:smooth_quartz
fill 476 260 561 476 260 564 minecraft:smooth_quartz
fill 478 260 597 480 265 597 minecraft:quartz_pillar
fill 482 260 559 484 265 559 minecraft:quartz_pillar
fill 490 260 597 492 265 597 minecraft:quartz_pillar
fill 494 260 559 496 265 559 minecraft:quartz_pillar
fill 502 260 597 504 265 597 minecraft:quartz_pillar
fill 506 260 559 508 265 559 minecraft:quartz_pillar
fill 510 260 567 510 265 569 minecraft:quartz_pillar
fill 510 260 579 510 265 581 minecraft:quartz_pillar
fill 510 260 591 510 265 593 minecraft:quartz_pillar
fill 471 265 561 471 265 566 minecraft:smooth_quartz
fill 471 265 573 471 265 578 minecraft:smooth_quartz
fill 471 265 585 471 265 590 minecraft:smooth_quartz
fill 471 265 597 471 265 598 minecraft:smooth_quartz
fill 472 265 598 475 265 598 minecraft:smooth_quartz
setblock 473 265 560 minecraft:light[level=14]
setblock 473 265 568 minecraft:light[level=14]
setblock 473 265 576 minecraft:light[level=14]
setblock 473 265 584 minecraft:light[level=14]
setblock 473 265 592 minecraft:light[level=14]
fill 475 265 558 480 265 558 minecraft:smooth_quartz
setblock 481 265 560 minecraft:light[level=14]
setblock 481 265 568 minecraft:light[level=14]
setblock 481 265 576 minecraft:light[level=14]
setblock 481 265 584 minecraft:light[level=14]
setblock 481 265 592 minecraft:light[level=14]
fill 482 265 598 487 265 598 minecraft:smooth_quartz
fill 487 265 558 492 265 558 minecraft:smooth_quartz
setblock 489 265 560 minecraft:light[level=14]
setblock 489 265 568 minecraft:light[level=14]
setblock 489 265 576 minecraft:light[level=14]
setblock 489 265 584 minecraft:light[level=14]
setblock 489 265 592 minecraft:light[level=14]
fill 494 265 598 499 265 598 minecraft:smooth_quartz
setblock 497 265 560 minecraft:light[level=14]
setblock 497 265 568 minecraft:light[level=14]
setblock 497 265 576 minecraft:light[level=14]
setblock 497 265 584 minecraft:light[level=14]
setblock 497 265 592 minecraft:light[level=14]
fill 499 265 558 504 265 558 minecraft:smooth_quartz
setblock 505 265 560 minecraft:light[level=14]
setblock 505 265 568 minecraft:light[level=14]
setblock 505 265 576 minecraft:light[level=14]
setblock 505 265 584 minecraft:light[level=14]
setblock 505 265 592 minecraft:light[level=14]
fill 506 265 598 511 265 598 minecraft:smooth_quartz
fill 509 265 562 509 266 568 minecraft:iron_block
fill 511 265 558 511 265 563 minecraft:smooth_quartz
fill 511 265 570 511 265 575 minecraft:smooth_quartz
fill 511 265 582 511 265 587 minecraft:smooth_quartz
fill 511 265 594 511 265 597 minecraft:smooth_quartz
fill 470 266 563 470 271 566 minecraft:pearlescent_froglight
fill 470 266 575 470 271 578 minecraft:pearlescent_froglight
fill 470 266 587 470 271 590 minecraft:pearlescent_froglight
fill 470 266 599 473 271 599 minecraft:pearlescent_froglight
fill 477 266 557 480 271 557 minecraft:pearlescent_froglight
fill 482 266 599 485 271 599 minecraft:pearlescent_froglight
fill 489 266 557 492 271 557 minecraft:pearlescent_froglight
fill 494 266 599 497 271 599 minecraft:pearlescent_froglight
fill 501 266 557 504 271 557 minecraft:pearlescent_froglight
fill 506 266 599 509 271 599 minecraft:pearlescent_froglight
fill 512 266 558 512 271 561 minecraft:pearlescent_froglight
fill 512 266 570 512 271 573 minecraft:pearlescent_froglight
fill 512 266 582 512 271 585 minecraft:pearlescent_froglight
fill 512 266 594 512 271 597 minecraft:pearlescent_froglight
fill 472 268 562 472 268 563 minecraft:smooth_quartz
setblock 473 268 561 minecraft:smooth_quartz
setblock 473 268 564 minecraft:smooth_quartz
setblock 474 268 560 minecraft:smooth_quartz
fill 474 268 565 475 268 565 minecraft:smooth_quartz
fill 476 268 561 476 268 564 minecraft:smooth_quartz
fill 470 272 563 470 285 563 minecraft:quartz_block
fill 470 272 564 470 272 565 minecraft:pearlescent_froglight
fill 470 272 566 470 285 566 minecraft:quartz_block
fill 470 272 575 470 285 575 minecraft:quartz_block
fill 470 272 576 470 272 577 minecraft:pearlescent_froglight
fill 470 272 578 470 285 578 minecraft:quartz_block
fill 470 272 587 470 285 587 minecraft:quartz_block
fill 470 272 588 470 272 589 minecraft:pearlescent_froglight
fill 470 272 590 470 285 590 minecraft:quartz_block
fill 470 272 599 470 285 599 minecraft:quartz_block
fill 471 272 599 472 272 599 minecraft:pearlescent_froglight
fill 472 272 562 472 273 563 minecraft:gold_block
fill 473 272 561 473 273 561 minecraft:gold_block
fill 473 272 564 473 273 564 minecraft:gold_block
fill 473 272 599 473 285 599 minecraft:quartz_block
fill 476 272 561 476 273 564 minecraft:gold_block
fill 477 272 557 477 285 557 minecraft:quartz_block
fill 478 272 557 479 272 557 minecraft:pearlescent_froglight
fill 480 272 557 480 285 557 minecraft:quartz_block
fill 482 272 599 482 285 599 minecraft:quartz_block
fill 483 272 599 484 272 599 minecraft:pearlescent_froglight
fill 485 272 599 485 285 599 minecraft:quartz_block
fill 489 272 557 489 285 557 minecraft:quartz_block
fill 490 272 557 491 272 557 minecraft:pearlescent_froglight
fill 492 272 557 492 285 557 minecraft:quartz_block
fill 494 272 599 494 285 599 minecraft:quartz_block
fill 495 272 599 496 272 599 minecraft:pearlescent_froglight
fill 497 272 599 497 285 599 minecraft:quartz_block
fill 501 272 557 501 285 557 minecraft:quartz_block
fill 502 272 557 503 272 557 minecraft:pearlescent_froglight
fill 504 272 557 504 285 557 minecraft:quartz_block
fill 506 272 599 506 285 599 minecraft:quartz_block
fill 507 272 599 508 272 599 minecraft:pearlescent_froglight
fill 509 272 599 509 285 599 minecraft:quartz_block
fill 512 272 558 512 285 558 minecraft:quartz_block
fill 512 272 559 512 272 560 minecraft:pearlescent_froglight
fill 512 272 561 512 285 561 minecraft:quartz_block
fill 512 272 570 512 285 570 minecraft:quartz_block
fill 512 272 571 512 272 572 minecraft:pearlescent_froglight
fill 512 272 573 512 285 573 minecraft:quartz_block
fill 512 272 582 512 285 582 minecraft:quartz_block
fill 512 272 583 512 272 584 minecraft:pearlescent_froglight
fill 512 272 585 512 285 585 minecraft:quartz_block
fill 512 272 594 512 285 594 minecraft:quartz_block
fill 512 272 595 512 272 596 minecraft:pearlescent_froglight
fill 512 272 597 512 285 597 minecraft:quartz_block
fill 470 273 564 470 285 565 minecraft:quartz_block
fill 470 273 576 470 285 577 minecraft:quartz_block
fill 470 273 588 470 285 589 minecraft:quartz_block
fill 471 273 599 472 285 599 minecraft:quartz_block
setblock 473 273 560 minecraft:light[level=14]
setblock 473 273 568 minecraft:light[level=14]
setblock 473 273 576 minecraft:light[level=14]
setblock 473 273 584 minecraft:light[level=14]
setblock 473 273 592 minecraft:light[level=14]
fill 478 273 557 479 285 557 minecraft:quartz_block
setblock 481 273 560 minecraft:light[level=14]
setblock 481 273 568 minecraft:light[level=14]
setblock 481 273 576 minecraft:light[level=14]
setblock 481 273 584 minecraft:light[level=14]
setblock 481 273 592 minecraft:light[level=14]
fill 483 273 599 484 285 599 minecraft:quartz_block
setblock 489 273 560 minecraft:light[level=14]
setblock 489 273 568 minecraft:light[level=14]
setblock 489 273 576 minecraft:light[level=14]
setblock 489 273 584 minecraft:light[level=14]
setblock 489 273 592 minecraft:light[level=14]
fill 490 273 557 491 285 557 minecraft:quartz_block
fill 495 273 599 496 285 599 minecraft:quartz_block
setblock 497 273 560 minecraft:light[level=14]
setblock 497 273 568 minecraft:light[level=14]
setblock 497 273 576 minecraft:light[level=14]
setblock 497 273 584 minecraft:light[level=14]
setblock 497 273 592 minecraft:light[level=14]
fill 502 273 557 503 285 557 minecraft:quartz_block
setblock 505 273 560 minecraft:light[level=14]
setblock 505 273 568 minecraft:light[level=14]
setblock 505 273 576 minecraft:light[level=14]
setblock 505 273 584 minecraft:light[level=14]
setblock 505 273 592 minecraft:light[level=14]
fill 507 273 599 508 285 599 minecraft:quartz_block
fill 512 273 559 512 285 560 minecraft:quartz_block
fill 512 273 571 512 285 572 minecraft:quartz_block
fill 512 273 583 512 285 584 minecraft:quartz_block
fill 512 273 595 512 285 596 minecraft:quartz_block
fill 483 278 574 485 278 576 minecraft:redstone_block
fill 484 278 581 486 278 583 minecraft:redstone_block
fill 490 278 573 492 278 575 minecraft:redstone_block
fill 490 278 581 492 278 583 minecraft:redstone_block
fill 471 279 568 482 279 588 minecraft:smooth_quartz
fill 472 279 566 510 279 567 minecraft:smooth_quartz
fill 472 279 589 510 279 590 minecraft:smooth_quartz
fill 473 279 565 509 279 565 minecraft:smooth_quartz
fill 473 279 591 509 279 591 minecraft:smooth_quartz
fill 474 279 564 508 279 564 minecraft:smooth_quartz
fill 474 279 592 508 279 592 minecraft:smooth_quartz
fill 475 279 563 507 279 563 minecraft:smooth_quartz
fill 475 279 593 507 279 593 minecraft:smooth_quartz
fill 476 279 562 506 279 562 minecraft:smooth_quartz
fill 476 279 594 506 279 594 minecraft:smooth_quartz
fill 477 279 561 505 279 561 minecraft:smooth_quartz
fill 477 279 595 505 279 595 minecraft:smooth_quartz
fill 478 279 560 504 279 560 minecraft:smooth_quartz
fill 478 279 596 504 279 596 minecraft:smooth_quartz
fill 479 279 559 503 279 559 minecraft:smooth_quartz
fill 479 279 597 503 279 597 minecraft:smooth_quartz
fill 481 279 558 501 279 558 minecraft:smooth_quartz
fill 481 279 598 501 279 598 minecraft:smooth_quartz
fill 483 279 568 489 279 573 minecraft:smooth_quartz
fill 483 279 577 483 279 588 minecraft:smooth_quartz
fill 484 279 577 485 279 580 minecraft:smooth_quartz
fill 484 279 584 511 279 588 minecraft:smooth_quartz
fill 486 279 574 486 279 576 minecraft:smooth_quartz
fill 486 279 577 486 279 579 minecraft:gold_block
setblock 486 279 580 minecraft:smooth_quartz
fill 487 279 574 489 279 575 minecraft:smooth_quartz
fill 487 279 576 489 279 576 minecraft:gold_block
fill 487 279 580 489 279 580 minecraft:gold_block
fill 487 279 581 489 279 583 minecraft:smooth_quartz
fill 490 279 568 511 279 572 minecraft:smooth_quartz
fill 490 279 576 511 279 576 minecraft:smooth_quartz
fill 490 279 577 490 279 579 minecraft:gold_block
fill 490 279 580 511 279 580 minecraft:smooth_quartz
fill 491 279 577 511 279 579 minecraft:smooth_quartz
fill 493 279 573 511 279 575 minecraft:smooth_quartz
fill 493 279 581 511 279 583 minecraft:smooth_quartz
fill 471 280 558 471 280 568 minecraft:quartz_block
fill 471 280 569 471 280 587 minecraft:smooth_quartz
fill 471 280 588 471 280 598 minecraft:quartz_block
fill 472 280 558 472 280 566 minecraft:quartz_block
fill 472 280 567 472 280 568 minecraft:smooth_quartz
fill 472 280 569 481 280 587 minecraft:quartz_block
fill 472 280 588 472 280 589 minecraft:smooth_quartz
fill 472 280 590 472 280 598 minecraft:quartz_block
fill 473 280 558 473 280 565 minecraft:quartz_block
setblock 473 280 566 minecraft:smooth_quartz
fill 473 280 567 509 280 568 minecraft:quartz_block
fill 473 280 588 509 280 589 minecraft:quartz_block
setblock 473 280 590 minecraft:smooth_quartz
fill 473 280 591 473 280 598 minecraft:quartz_block
fill 474 280 558 474 280 564 minecraft:quartz_block
setblock 474 280 565 minecraft:smooth_quartz
fill 474 280 566 508 280 566 minecraft:quartz_block
fill 474 280 590 508 280 590 minecraft:quartz_block
setblock 474 280 591 minecraft:smooth_quartz
fill 474 280 592 474 280 598 minecraft:quartz_block
fill 475 280 558 475 280 562 minecraft:quartz_block
fill 475 280 563 475 280 564 minecraft:smooth_quartz
fill 475 280 565 507 280 565 minecraft:quartz_block
fill 475 280 591 507 280 591 minecraft:quartz_block
fill 475 280 592 475 280 593 minecraft:smooth_quartz
fill 475 280 594 475 280 598 minecraft:quartz_block
fill 476 280 558 477 280 561 minecraft:quartz_block
fill 476 280 562 477 280 562 minecraft:smooth_quartz
fill 476 280 563 506 280 564 minecraft:quartz_block
fill 476 280 592 506 280 593 minecraft:quartz_block
fill 476 280 594 477 280 594 minecraft:smooth_quartz
fill 476 280 595 477 280 598 minecraft:quartz_block
fill 478 280 558 478 280 560 minecraft:quartz_block
setblock 478 280 561 minecraft:smooth_quartz
fill 478 280 562 504 280 562 minecraft:quartz_block
fill 478 280 594 504 280 594 minecraft:quartz_block
setblock 478 280 595 minecraft:smooth_quartz
fill 478 280 596 478 280 598 minecraft:quartz_block
fill 479 280 558 479 280 559 minecraft:quartz_block
setblock 479 280 560 minecraft:smooth_quartz
fill 479 280 561 503 280 561 minecraft:quartz_block
fill 479 280 595 503 280 595 minecraft:quartz_block
setblock 479 280 596 minecraft:smooth_quartz
fill 479 280 597 479 280 598 minecraft:quartz_block
fill 480 280 558 481 280 558 minecraft:quartz_block
fill 480 280 559 481 280 559 minecraft:smooth_quartz
fill 480 280 560 502 280 560 minecraft:quartz_block
fill 480 280 596 502 280 596 minecraft:quartz_block
fill 480 280 597 481 280 597 minecraft:smooth_quartz
fill 480 280 598 481 280 598 minecraft:quartz_block
fill 482 280 558 500 280 558 minecraft:smooth_quartz
fill 482 280 559 500 280 559 minecraft:quartz_block
fill 482 280 569 488 281 572 minecraft:quartz_block
fill 482 280 573 482 280 577 minecraft:pearlescent_froglight
fill 482 280 578 482 282 587 minecraft:quartz_block
fill 482 280 597 500 280 597 minecraft:quartz_block
fill 482 280 598 500 280 598 minecraft:smooth_quartz
fill 483 280 573 486 280 573 minecraft:pearlescent_froglight
fill 483 280 574 485 280 576 minecraft:quartz_block
fill 483 280 577 486 280 577 minecraft:pearlescent_froglight
fill 483 280 578 484 280 579 minecraft:quartz_block
fill 483 280 580 483 280 584 minecraft:pearlescent_froglight
fill 483 280 585 510 280 587 minecraft:quartz_block
fill 484 280 580 493 280 580 minecraft:pearlescent_froglight
fill 484 280 581 486 280 583 minecraft:quartz_block
fill 484 280 584 487 280 584 minecraft:pearlescent_froglight
fill 485 280 578 485 280 579 minecraft:gold_block
fill 486 280 574 486 280 576 minecraft:pearlescent_froglight
fill 486 280 578 486 280 579 minecraft:pearlescent_froglight
fill 487 280 573 487 280 574 minecraft:quartz_block
fill 487 280 575 488 280 575 minecraft:gold_block
fill 487 280 576 493 280 576 minecraft:pearlescent_froglight
fill 487 280 581 487 280 583 minecraft:pearlescent_froglight
setblock 488 280 573 minecraft:quartz_block
setblock 488 280 574 minecraft:gold_block
fill 488 280 581 488 280 582 minecraft:gold_block
fill 488 280 583 488 280 584 minecraft:quartz_block
fill 489 280 569 510 280 571 minecraft:quartz_block
fill 489 280 572 489 280 575 minecraft:pearlescent_froglight
fill 489 280 581 489 280 584 minecraft:pearlescent_froglight
fill 490 280 572 493 280 572 minecraft:pearlescent_froglight
fill 490 280 573 492 280 575 minecraft:quartz_block
fill 490 280 577 490 280 579 minecraft:pearlescent_froglight
fill 490 280 581 492 280 583 minecraft:quartz_block
fill 490 280 584 493 280 584 minecraft:pearlescent_froglight
fill 491 280 577 492 280 579 minecraft:gold_block
fill 493 280 573 493 280 575 minecraft:pearlescent_froglight
fill 493 280 577 510 280 579 minecraft:quartz_block
fill 493 280 581 493 280 583 minecraft:pearlescent_froglight
fill 494 280 572 510 280 576 minecraft:quartz_block
fill 494 280 580 510 280 584 minecraft:quartz_block
fill 501 280 558 511 280 558 minecraft:quartz_block
fill 501 280 559 502 280 559 minecraft:smooth_quartz
fill 501 280 597 502 280 597 minecraft:smooth_quartz
fill 501 280 598 511 280 598 minecraft:quartz_block
fill 503 280 559 511 280 559 minecraft:quartz_block
setblock 503 280 560 minecraft:smooth_quartz
setblock 503 280 596 minecraft:smooth_quartz
fill 503 280 597 511 280 597 minecraft:quartz_block
fill 504 280 560 511 280 560 minecraft:quartz_block
setblock 504 280 561 minecraft:smooth_quartz
setblock 504 280 595 minecraft:smooth_quartz
fill 504 280 596 511 280 596 minecraft:quartz_block
fill 505 280 561 511 280 561 minecraft:quartz_block
fill 505 280 562 506 280 562 minecraft:smooth_quartz
fill 505 280 594 506 280 594 minecraft:smooth_quartz
fill 505 280 595 511 280 595 minecraft:quartz_block
fill 507 280 562 511 280 562 minecraft:quartz_block
fill 507 280 563 507 280 564 minecraft:smooth_quartz
fill 507 280 592 507 280 593 minecraft:smooth_quartz
fill 507 280 594 511 280 594 minecraft:quartz_block
fill 508 280 563 511 280 564 minecraft:quartz_block
setblock 508 280 565 minecraft:smooth_quartz
setblock 508 280 591 minecraft:smooth_quartz
fill 508 280 592 511 280 593 minecraft:quartz_block
fill 509 280 565 511 280 565 minecraft:quartz_block
setblock 509 280 566 minecraft:smooth_quartz
setblock 509 280 590 minecraft:smooth_quartz
fill 509 280 591 511 280 591 minecraft:quartz_block
fill 510 280 566 511 280 566 minecraft:quartz_block
fill 510 280 567 510 280 568 minecraft:smooth_quartz
fill 510 280 588 510 280 589 minecraft:smooth_quartz
fill 510 280 590 511 280 590 minecraft:quartz_block
fill 511 280 567 511 280 568 minecraft:quartz_block
fill 511 280 569 511 280 587 minecraft:smooth_quartz
fill 511 280 588 511 280 589 minecraft:quartz_block
fill 471 281 571 471 281 585 minecraft:smooth_quartz
fill 472 281 569 472 281 570 minecraft:smooth_quartz
fill 472 281 571 481 281 585 minecraft:quartz_block
fill 472 281 586 472 281 587 minecraft:smooth_quartz
setblock 473 281 560 minecraft:light[level=14]
fill 473 281 567 473 281 568 minecraft:smooth_quartz
fill 473 281 569 481 281 570 minecraft:quartz_block
fill 473 281 586 481 281 587 minecraft:quartz_block
fill 473 281 588 473 281 589 minecraft:smooth_quartz
setblock 473 281 592 minecraft:light[level=14]
setblock 474 281 566 minecraft:smooth_quartz
fill 474 281 567 508 281 568 minecraft:quartz_block
fill 474 281 588 508 281 589 minecraft:quartz_block
setblock 474 281 590 minecraft:smooth_quartz
fill 475 281 564 475 281 565 minecraft:smooth_quartz
fill 475 281 566 507 281 566 minecraft:quartz_block
fill 475 281 590 507 281 590 minecraft:quartz_block
fill 475 281 591 475 281 592 minecraft:smooth_quartz
setblock 476 281 563 minecraft:smooth_quartz
fill 476 281 564 506 281 565 minecraft:quartz_block
fill 476 281 591 506 281 592 minecraft:quartz_block
setblock 476 281 593 minecraft:smooth_quartz
fill 477 281 562 478 281 562 minecraft:smooth_quartz
fill 477 281 563 505 281 563 minecraft:quartz_block
fill 477 281 593 505 281 593 minecraft:quartz_block
fill 477 281 594 478 281 594 minecraft:smooth_quartz
setblock 479 281 561 minecraft:smooth_quartz
fill 479 281 562 503 281 562 minecraft:quartz_block
fill 479 281 594 503 281 594 minecraft:quartz_block
setblock 479 281 595 minecraft:smooth_quartz
fill 480 281 560 481 281 560 minecraft:smooth_quartz
fill 480 281 561 502 281 561 minecraft:quartz_block
fill 480 281 595 502 281 595 minecraft:quartz_block
fill 480 281 596 481 281 596 minecraft:smooth_quartz
fill 482 281 559 483 281 559 minecraft:smooth_quartz
fill 482 281 560 500 281 560 minecraft:quartz_block
fill 482 281 573 483 281 577 minecraft:quartz_block
fill 482 281 596 500 281 596 minecraft:quartz_block
fill 482 281 597 483 281 597 minecraft:smooth_quartz
fill 483 281 578 483 281 587 minecraft:quartz_block
fill 484 281 558 498 281 558 minecraft:smooth_quartz
fill 484 281 559 498 281 559 minecraft:quartz_block
fill 484 281 573 484 281 575 minecraft:quartz_block
fill 484 281 576 484 281 580 minecraft:gold_block
fill 484 281 581 484 281 587 minecraft:quartz_block
fill 484 281 597 498 281 597 minecraft:quartz_block
fill 484 281 598 498 281 598 minecraft:smooth_quartz
fill 485 281 573 486 281 573 minecraft:quartz_block
fill 485 281 574 485 281 576 minecraft:gold_block
fill 485 281 580 485 281 582 minecraft:gold_block
fill 485 281 583 486 281 587 minecraft:quartz_block
fill 486 281 574 487 281 574 minecraft:gold_block
fill 486 281 582 487 281 582 minecraft:gold_block
fill 487 281 573 491 281 573 minecraft:gold_block
fill 487 281 583 491 281 583 minecraft:gold_block
fill 487 281 584 509 281 587 minecraft:quartz_block
fill 489 281 569 509 281 572 minecraft:quartz_block
setblock 489 281 576 minecraft:light[level=14]
fill 490 281 574 493 281 574 minecraft:gold_block
fill 490 281 582 493 281 582 minecraft:gold_block
fill 492 281 573 510 281 573 minecraft:quartz_block
fill 492 281 575 493 281 575 minecraft:gold_block
fill 492 281 581 493 281 581 minecraft:gold_block
fill 492 281 583 510 281 583 minecraft:quartz_block
fill 493 281 576 494 281 580 minecraft:gold_block
fill 494 281 574 510 281 575 minecraft:quartz_block
fill 494 281 581 510 281 582 minecraft:quartz_block
fill 495 281 576 510 281 580 minecraft:quartz_block
fill 499 281 559 500 281 559 minecraft:smooth_quartz
fill 499 281 597 500 281 597 minecraft:smooth_quartz
fill 501 281 560 502 281 560 minecraft:smooth_quartz
fill 501 281 596 502 281 596 minecraft:smooth_quartz
setblock 503 281 561 minecraft:smooth_quartz
setblock 503 281 595 minecraft:smooth_quartz
fill 504 281 562 505 281 562 minecraft:smooth_quartz
fill 504 281 594 505 281 594 minecraft:smooth_quartz
setblock 505 281 560 minecraft:light[level=14]
setblock 506 281 563 minecraft:smooth_quartz
setblock 506 281 593 minecraft:smooth_quartz
fill 507 281 564 507 281 565 minecraft:smooth_quartz
fill 507 281 591 507 281 592 minecraft:smooth_quartz
setblock 508 281 566 minecraft:smooth_quartz
setblock 508 281 590 minecraft:smooth_quartz
fill 509 281 567 509 281 568 minecraft:smooth_quartz
fill 509 281 588 509 281 589 minecraft:smooth_quartz
fill 510 281 569 510 281 570 minecraft:smooth_quartz
fill 510 281 571 510 281 572 minecraft:quartz_block
fill 510 281 584 510 281 585 minecraft:quartz_block
fill 510 281 586 510 281 587 minecraft:smooth_quartz
fill 511 281 571 511 281 585 minecraft:smooth_quartz
fill 471 282 573 471 282 583 minecraft:smooth_quartz
fill 472 282 570 472 282 572 minecraft:smooth_quartz
fill 472 282 573 481 282 583 minecraft:quartz_block
fill 472 282 584 472 282 586 minecraft:smooth_quartz
fill 473 282 568 473 282 569 minecraft:smooth_quartz
fill 473 282 570 485 282 572 minecraft:quartz_block
fill 473 282 584 481 282 586 minecraft:quartz_block
fill 473 282 587 473 282 588 minecraft:smooth_quartz
setblock 474 282 567 minecraft:smooth_quartz
fill 474 282 568 508 282 569 minecraft:quartz_block
fill 474 282 587 481 282 588 minecraft:quartz_block
setblock 474 282 589 minecraft:smooth_quartz
fill 475 282 565 475 282 566 minecraft:smooth_quartz
fill 475 282 567 507 282 567 minecraft:quartz_block
fill 475 282 589 507 282 589 minecraft:quartz_block
fill 475 282 590 475 282 591 minecraft:smooth_quartz
setblock 476 282 564 minecraft:smooth_quartz
fill 476 282 565 506 282 566 minecraft:quartz_block
fill 476 282 590 506 282 591 minecraft:quartz_block
setblock 476 282 592 minecraft:smooth_quartz
setblock 477 282 563 minecraft:smooth_quartz
fill 477 282 564 505 282 564 minecraft:quartz_block
fill 477 282 592 505 282 592 minecraft:quartz_block
setblock 477 282 593 minecraft:smooth_quartz
fill 478 282 562 479 282 562 minecraft:smooth_quartz
fill 478 282 563 504 282 563 minecraft:quartz_block
fill 478 282 593 504 282 593 minecraft:quartz_block
fill 478 282 594 479 282 594 minecraft:smooth_quartz
setblock 480 282 561 minecraft:smooth_quartz
fill 480 282 562 502 282 562 minecraft:quartz_block
fill 480 282 594 502 282 594 minecraft:quartz_block
setblock 480 282 595 minecraft:smooth_quartz
fill 481 282 560 482 282 560 minecraft:smooth_quartz
fill 481 282 561 501 282 561 minecraft:quartz_block
fill 481 282 595 501 282 595 minecraft:quartz_block
fill 481 282 596 482 282 596 minecraft:smooth_quartz
fill 482 282 573 482 282 577 minecraft:quartz_block
fill 482 282 588 508 282 588 minecraft:quartz_block
fill 483 282 559 485 282 559 minecraft:smooth_quartz
fill 483 282 560 499 282 560 minecraft:quartz_block
fill 483 282 573 483 282 574 minecraft:quartz_block
fill 483 282 575 483 282 581 minecraft:gold_block
fill 483 282 582 483 282 587 minecraft:quartz_block
fill 483 282 596 499 282 596 minecraft:quartz_block
fill 483 282 597 485 282 597 minecraft:smooth_quartz
setblock 484 282 573 minecraft:quartz_block
fill 484 282 574 484 282 575 minecraft:gold_block
fill 484 282 581 484 282 582 minecraft:gold_block
fill 484 282 583 484 282 587 minecraft:quartz_block
fill 485 282 573 486 282 573 minecraft:gold_block
fill 485 282 583 486 282 583 minecraft:gold_block
fill 485 282 584 485 282 587 minecraft:quartz_block
fill 486 282 558 496 282 558 minecraft:smooth_quartz
fill 486 282 559 496 282 559 minecraft:quartz_block
fill 486 282 570 487 282 571 minecraft:quartz_block
fill 486 282 572 493 282 572 minecraft:gold_block
fill 486 282 584 493 282 584 minecraft:gold_block
fill 486 282 585 487 282 587 minecraft:quartz_block
fill 486 282 597 496 282 597 minecraft:quartz_block
fill 486 282 598 496 282 598 minecraft:smooth_quartz
fill 488 282 570 509 282 570 minecraft:quartz_block
fill 488 282 571 491 282 571 minecraft:gold_block
fill 488 282 585 491 282 585 minecraft:gold_block
fill 488 282 586 508 282 587 minecraft:quartz_block
fill 492 282 571 509 282 571 minecraft:quartz_block
fill 492 282 573 494 282 573 minecraft:gold_block
fill 492 282 583 494 282 583 minecraft:gold_block
fill 492 282 585 509 282 585 minecraft:quartz_block
fill 494 282 572 509 282 572 minecraft:quartz_block
fill 494 282 574 495 282 575 minecraft:gold_block
fill 494 282 581 495 282 582 minecraft:gold_block
fill 494 282 584 509 282 584 minecraft:quartz_block
fill 495 282 573 510 282 573 minecraft:quartz_block
fill 495 282 576 496 282 580 minecraft:gold_block
fill 495 282 583 510 282 583 minecraft:quartz_block
fill 496 282 574 510 282 574 minecraft:quartz_block
setblock 496 282 575 minecraft:gold_block
setblock 496 282 581 minecraft:gold_block
fill 496 282 582 510 282 582 minecraft:quartz_block
fill 497 282 559 499 282 559 minecraft:smooth_quartz
fill 497 282 575 510 282 581 minecraft:quartz_block
fill 497 282 597 499 282 597 minecraft:smooth_quartz
fill 500 282 560 501 282 560 minecraft:smooth_quartz
fill 500 282 596 501 282 596 minecraft:smooth_quartz
setblock 502 282 561 minecraft:smooth_quartz
setblock 502 282 595 minecraft:smooth_quartz
fill 503 282 562 504 282 562 minecraft:smooth_quartz
fill 503 282 594 504 282 594 minecraft:smooth_quartz
setblock 505 282 563 minecraft:smooth_quartz
setblock 505 282 593 minecraft:smooth_quartz
setblock 506 282 564 minecraft:smooth_quartz
setblock 506 282 592 minecraft:smooth_quartz
fill 507 282 565 507 282 566 minecraft:smooth_quartz
fill 507 282 590 507 282 591 minecraft:smooth_quartz
setblock 508 282 567 minecraft:smooth_quartz
setblock 508 282 589 minecraft:smooth_quartz
fill 509 282 568 509 282 569 minecraft:smooth_quartz
setblock 509 282 586 minecraft:quartz_block
fill 509 282 587 509 282 588 minecraft:smooth_quartz
fill 510 282 570 510 282 572 minecraft:smooth_quartz
fill 510 282 584 510 282 586 minecraft:smooth_quartz
fill 511 282 573 511 282 583 minecraft:smooth_quartz
fill 472 283 573 472 283 583 minecraft:smooth_quartz
fill 473 283 570 473 283 572 minecraft:smooth_quartz
fill 473 283 573 480 283 583 minecraft:quartz_block
fill 473 283 584 473 283 586 minecraft:smooth_quartz
fill 474 283 568 474 283 569 minecraft:smooth_quartz
fill 474 283 570 483 283 572 minecraft:quartz_block
fill 474 283 584 483 283 586 minecraft:quartz_block
fill 474 283 587 474 283 588 minecraft:smooth_quartz
setblock 475 283 567 minecraft:smooth_quartz
fill 475 283 568 507 283 569 minecraft:quartz_block
fill 475 283 587 507 283 588 minecraft:quartz_block
setblock 475 283 589 minecraft:smooth_quartz
fill 476 283 565 476 283 566 minecraft:smooth_quartz
fill 476 283 567 506 283 567 minecraft:quartz_block
fill 476 283 589 506 283 589 minecraft:quartz_block
fill 476 283 590 476 283 591 minecraft:smooth_quartz
fill 477 283 564 477 283 565 minecraft:smooth_quartz
fill 477 283 566 505 283 566 minecraft:quartz_block
fill 477 283 590 505 283 590 minecraft:quartz_block
fill 477 283 591 477 283 592 minecraft:smooth_quartz
fill 478 283 563 478 283 564 minecraft:smooth_quartz
fill 478 283 565 504 283 565 minecraft:quartz_block
fill 478 283 591 504 283 591 minecraft:quartz_block
fill 478 283 592 478 283 593 minecraft:smooth_quartz
setblock 479 283 563 minecraft:smooth_quartz
fill 479 283 564 503 283 564 minecraft:quartz_block
fill 479 283 592 503 283 592 minecraft:quartz_block
setblock 479 283 593 minecraft:smooth_quartz
setblock 480 283 562 minecraft:smooth_quartz
fill 480 283 563 502 283 563 minecraft:quartz_block
fill 480 283 593 502 283 593 minecraft:quartz_block
setblock 480 283 594 minecraft:smooth_quartz
fill 481 283 561 482 283 561 minecraft:smooth_quartz
fill 481 283 562 501 283 562 minecraft:quartz_block
fill 481 283 573 481 283 577 minecraft:quartz_block
fill 481 283 578 482 283 578 minecraft:gold_block
fill 481 283 579 481 283 583 minecraft:quartz_block
fill 481 283 594 501 283 594 minecraft:quartz_block
fill 481 283 595 482 283 595 minecraft:smooth_quartz
setblock 482 283 573 minecraft:quartz_block
fill 482 283 574 482 283 577 minecraft:gold_block
fill 482 283 579 482 283 582 minecraft:gold_block
setblock 482 283 583 minecraft:quartz_block
fill 483 283 560 485 283 560 minecraft:smooth_quartz
fill 483 283 561 499 283 561 minecraft:quartz_block
fill 483 283 573 483 283 574 minecraft:gold_block
fill 483 283 582 483 283 583 minecraft:gold_block
fill 483 283 595 499 283 595 minecraft:quartz_block
fill 483 283 596 485 283 596 minecraft:smooth_quartz
fill 484 283 570 484 283 571 minecraft:quartz_block
fill 484 283 572 484 283 573 minecraft:gold_block
fill 484 283 583 484 283 584 minecraft:gold_block
fill 484 283 585 484 283 586 minecraft:quartz_block
setblock 485 283 570 minecraft:quartz_block
fill 485 283 571 485 283 572 minecraft:gold_block
fill 485 283 584 485 283 585 minecraft:gold_block
setblock 485 283 586 minecraft:quartz_block
fill 486 283 559 496 283 559 minecraft:smooth_quartz
fill 486 283 560 496 283 560 minecraft:quartz_block
fill 486 283 570 487 283 571 minecraft:gold_block
fill 486 283 585 487 283 586 minecraft:gold_block
fill 486 283 596 496 283 596 minecraft:quartz_block
fill 486 283 597 496 283 597 minecraft:smooth_quartz
fill 488 283 570 493 283 570 minecraft:gold_block
fill 488 283 586 493 283 586 minecraft:gold_block
fill 492 283 571 495 283 571 minecraft:gold_block
fill 492 283 585 495 283 585 minecraft:gold_block
fill 494 283 570 508 283 570 minecraft:quartz_block
fill 494 283 572 496 283 572 minecraft:gold_block
fill 494 283 584 496 283 584 minecraft:gold_block
fill 494 283 586 508 283 586 minecraft:quartz_block
fill 495 283 573 497 283 573 minecraft:gold_block
fill 495 283 583 497 283 583 minecraft:gold_block
fill 496 283 571 508 283 571 minecraft:quartz_block
fill 496 283 574 497 283 574 minecraft:gold_block
fill 496 283 582 497 283 582 minecraft:gold_block
fill 496 283 585 508 283 585 minecraft:quartz_block
fill 497 283 560 499 283 560 minecraft:smooth_quartz
fill 497 283 572 508 283 572 minecraft:quartz_block
fill 497 283 575 498 283 581 minecraft:gold_block
fill 497 283 584 508 283 584 minecraft:quartz_block
fill 497 283 596 499 283 596 minecraft:smooth_quartz
fill 498 283 573 509 283 574 minecraft:quartz_block
fill 498 283 582 509 283 583 minecraft:quartz_block
fill 499 283 575 509 283 581 minecraft:quartz_block
fill 500 283 561 501 283 561 minecraft:smooth_quartz
fill 500 283 595 501 283 595 minecraft:smooth_quartz
setblock 502 283 562 minecraft:smooth_quartz
setblock 502 283 594 minecraft:smooth_quartz
fill 503 283 563 504 283 563 minecraft:smooth_quartz
fill 503 283 593 504 283 593 minecraft:smooth_quartz
fill 504 283 564 505 283 564 minecraft:smooth_quartz
fill 504 283 592 505 283 592 minecraft:smooth_quartz
fill 505 283 565 506 283 565 minecraft:smooth_quartz
fill 505 283 591 506 283 591 minecraft:smooth_quartz
setblock 506 283 566 minecraft:smooth_quartz
setblock 506 283 590 minecraft:smooth_quartz
setblock 507 283 567 minecraft:smooth_quartz
setblock 507 283 589 minecraft:smooth_quartz
fill 508 283 568 508 283 569 minecraft:smooth_quartz
fill 508 283 587 508 283 588 minecraft:smooth_quartz
fill 509 283 570 509 283 572 minecraft:smooth_quartz
fill 509 283 584 509 283 586 minecraft:smooth_quartz
fill 510 283 573 510 283 583 minecraft:smooth_quartz
fill 471 284 558 473 300 558 minecraft:quartz_pillar
fill 471 284 568 471 300 570 minecraft:quartz_pillar
fill 471 284 580 471 300 582 minecraft:quartz_pillar
fill 471 284 592 471 300 594 minecraft:quartz_pillar
fill 472 284 567 472 285 569 minecraft:quartz_pillar
fill 472 284 579 472 285 581 minecraft:quartz_pillar
fill 472 284 591 472 285 593 minecraft:quartz_pillar
fill 473 284 573 473 284 583 minecraft:smooth_quartz
fill 474 284 570 474 284 572 minecraft:smooth_quartz
fill 474 284 573 479 284 583 minecraft:quartz_block
fill 474 284 584 474 284 586 minecraft:smooth_quartz
fill 475 284 568 475 284 570 minecraft:smooth_quartz
fill 475 284 571 481 284 572 minecraft:quartz_block
fill 475 284 584 481 284 585 minecraft:quartz_block
fill 475 284 586 475 284 588 minecraft:smooth_quartz
fill 476 284 567 476 284 568 minecraft:smooth_quartz
fill 476 284 569 483 284 570 minecraft:quartz_block
fill 476 284 586 483 284 587 minecraft:quartz_block
fill 476 284 588 476 284 589 minecraft:smooth_quartz
setblock 477 284 566 minecraft:smooth_quartz
fill 477 284 567 486 284 568 minecraft:quartz_block
fill 477 284 588 486 284 589 minecraft:quartz_block
setblock 477 284 590 minecraft:smooth_quartz
fill 477 284 598 479 300 598 minecraft:quartz_pillar
setblock 478 284 565 minecraft:smooth_quartz
fill 478 284 566 504 284 566 minecraft:quartz_block
fill 478 284 590 504 284 590 minecraft:quartz_block
setblock 478 284 591 minecraft:smooth_quartz
fill 478 284 597 480 285 597 minecraft:quartz_pillar
setblock 479 284 564 minecraft:smooth_quartz
fill 479 284 565 503 284 565 minecraft:quartz_block
fill 479 284 591 503 284 591 minecraft:quartz_block
setblock 479 284 592 minecraft:smooth_quartz
fill 480 284 563 481 284 563 minecraft:smooth_quartz
fill 480 284 564 502 284 564 minecraft:quartz_block
fill 480 284 573 480 284 575 minecraft:quartz_block
fill 480 284 576 480 284 580 minecraft:gold_block
fill 480 284 581 480 284 583 minecraft:quartz_block
fill 480 284 592 502 284 592 minecraft:quartz_block
fill 480 284 593 481 284 593 minecraft:smooth_quartz
fill 481 284 562 483 284 562 minecraft:smooth_quartz
setblock 481 284 573 minecraft:quartz_block
fill 481 284 574 481 284 577 minecraft:gold_block
fill 481 284 579 481 284 582 minecraft:gold_block
setblock 481 284 583 minecraft:quartz_block
fill 481 284 594 483 284 594 minecraft:smooth_quartz
fill 482 284 559 484 285 559 minecraft:quartz_pillar
fill 482 284 563 500 284 563 minecraft:quartz_block
setblock 482 284 571 minecraft:quartz_block
fill 482 284 572 482 284 573 minecraft:gold_block
fill 482 284 583 482 284 584 minecraft:gold_block
setblock 482 284 585 minecraft:quartz_block
fill 482 284 593 500 284 593 minecraft:quartz_block
fill 483 284 558 485 300 558 minecraft:quartz_pillar
fill 483 284 561 485 284 561 minecraft:smooth_quartz
fill 483 284 571 483 284 572 minecraft:gold_block
fill 483 284 584 483 284 585 minecraft:gold_block
fill 483 284 595 485 284 595 minecraft:smooth_quartz
fill 484 284 562 498 284 562 minecraft:quartz_block
setblock 484 284 569 minecraft:quartz_block
fill 484 284 570 484 284 571 minecraft:gold_block
fill 484 284 585 484 284 586 minecraft:gold_block
setblock 484 284 587 minecraft:quartz_block
fill 484 284 594 498 284 594 minecraft:quartz_block
fill 485 284 569 485 284 570 minecraft:gold_block
fill 485 284 586 485 284 587 minecraft:gold_block
fill 486 284 560 496 284 560 minecraft:smooth_quartz
fill 486 284 561 496 284 561 minecraft:quartz_block
fill 486 284 569 495 284 569 minecraft:gold_block
fill 486 284 587 495 284 587 minecraft:gold_block
fill 486 284 595 496 284 595 minecraft:quartz_block
fill 486 284 596 496 284 596 minecraft:smooth_quartz
fill 487 284 567 505 284 567 minecraft:quartz_block
fill 487 284 568 493 284 568 minecraft:gold_block
fill 487 284 588 493 284 588 minecraft:gold_block
fill 487 284 589 505 284 589 minecraft:quartz_block
fill 489 284 598 491 300 598 minecraft:quartz_pillar
fill 490 284 597 492 285 597 minecraft:quartz_pillar
fill 494 284 559 496 285 559 minecraft:quartz_pillar
fill 494 284 568 505 284 568 minecraft:quartz_block
fill 494 284 570 497 284 570 minecraft:gold_block
fill 494 284 586 497 284 586 minecraft:gold_block
fill 494 284 588 505 284 588 minecraft:quartz_block
fill 495 284 558 497 300 558 minecraft:quartz_pillar
fill 496 284 569 506 284 569 minecraft:quartz_block
fill 496 284 571 498 284 571 minecraft:gold_block
fill 496 284 585 498 284 585 minecraft:gold_block
fill 496 284 587 506 284 587 minecraft:quartz_block
fill 497 284 561 499 284 561 minecraft:smooth_quartz
fill 497 284 572 499 284 572 minecraft:gold_block
fill 497 284 584 499 284 584 minecraft:gold_block
fill 497 284 595 499 284 595 minecraft:smooth_quartz
fill 498 284 570 506 284 570 minecraft:quartz_block
fill 498 284 573 499 284 574 minecraft:gold_block
fill 498 284 582 499 284 583 minecraft:gold_block
fill 498 284 586 506 284 586 minecraft:quartz_block
fill 499 284 562 501 284 562 minecraft:smooth_quartz
fill 499 284 571 507 284 571 minecraft:quartz_block
fill 499 284 575 500 284 581 minecraft:gold_block
fill 499 284 585 507 284 585 minecraft:quartz_block
schedule function dropper:buildpart/142_2 1t
