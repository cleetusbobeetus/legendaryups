setblock 142 93 305 minecraft:snow_block
setblock 142 93 306 minecraft:packed_ice
setblock 143 93 284 minecraft:snow_block
fill 143 93 285 143 96 285 minecraft:packed_ice
setblock 143 93 289 minecraft:snow_block
fill 145 93 279 145 95 279 minecraft:packed_ice
fill 145 93 281 145 95 281 minecraft:packed_ice
fill 147 93 279 147 95 279 minecraft:packed_ice
fill 147 93 281 147 95 281 minecraft:packed_ice
fill 152 93 276 152 96 276 minecraft:packed_ice
setblock 155 93 277 minecraft:snow_block
setblock 156 93 276 minecraft:snow_block
fill 156 93 277 156 96 277 minecraft:packed_ice
setblock 156 93 315 minecraft:packed_ice
setblock 156 93 316 minecraft:snow_block
fill 157 93 276 157 96 276 minecraft:packed_ice
setblock 157 93 315 minecraft:snow_block
fill 157 93 316 157 96 316 minecraft:packed_ice
fill 158 93 315 158 96 315 minecraft:packed_ice
setblock 160 93 317 minecraft:white_concrete
setblock 161 93 316 minecraft:snow_block
fill 162 93 316 162 96 316 minecraft:packed_ice
setblock 167 93 295 minecraft:snow_block
fill 168 93 275 168 114 275 minecraft:packed_ice
setblock 175 93 316 minecraft:packed_ice
setblock 176 93 286 minecraft:snow_block
setblock 176 93 304 minecraft:snow_block
setblock 176 93 316 minecraft:snow_block
setblock 178 93 275 minecraft:packed_ice
fill 180 93 287 180 94 287 minecraft:snow_block
fill 180 93 302 180 97 302 minecraft:snow_block
setblock 180 93 307 minecraft:snow_block
setblock 180 93 308 minecraft:packed_ice
setblock 181 93 286 minecraft:snow_block
fill 181 93 287 181 96 287 minecraft:packed_ice
fill 181 93 299 181 97 301 minecraft:snow_block
setblock 181 93 302 minecraft:packed_ice
setblock 181 93 306 minecraft:snow_block
fill 181 93 307 181 96 307 minecraft:packed_ice
setblock 182 93 285 minecraft:snow_block
fill 182 93 286 183 96 286 minecraft:packed_ice
setblock 182 93 290 minecraft:snow_block
fill 182 93 291 182 96 291 minecraft:packed_ice
setblock 182 93 295 minecraft:snow_block
setblock 182 93 296 minecraft:packed_ice
setblock 182 93 300 minecraft:snow_block
fill 182 93 301 182 94 301 minecraft:packed_ice
setblock 182 93 305 minecraft:snow_block
fill 182 93 306 182 96 306 minecraft:packed_ice
setblock 182 93 310 minecraft:snow_block
fill 182 93 311 182 96 311 minecraft:packed_ice
fill 141 94 281 141 114 281 minecraft:packed_ice
setblock 141 94 301 minecraft:light_blue_concrete
fill 141 94 302 141 115 302 minecraft:packed_ice
setblock 142 94 280 minecraft:packed_ice
setblock 142 94 284 minecraft:snow_block
fill 142 94 285 142 97 285 minecraft:packed_ice
setblock 142 94 289 minecraft:snow_block
fill 142 94 290 142 97 290 minecraft:packed_ice
setblock 143 94 283 minecraft:snow_block
fill 143 94 284 143 97 284 minecraft:packed_ice
setblock 143 94 288 minecraft:snow_block
fill 143 94 289 143 97 289 minecraft:packed_ice
setblock 144 94 278 minecraft:light[level=12]
setblock 144 94 285 minecraft:light[level=12]
setblock 144 94 292 minecraft:light[level=12]
setblock 144 94 299 minecraft:light[level=12]
setblock 144 94 306 minecraft:light[level=12]
setblock 144 94 313 minecraft:light[level=12]
fill 144 94 314 144 100 314 minecraft:packed_ice
fill 151 94 276 151 97 276 minecraft:packed_ice
setblock 151 94 278 minecraft:light[level=12]
setblock 151 94 285 minecraft:light[level=12]
setblock 151 94 292 minecraft:light[level=12]
setblock 151 94 299 minecraft:light[level=12]
setblock 151 94 306 minecraft:light[level=12]
setblock 151 94 313 minecraft:light[level=12]
fill 153 94 316 153 95 316 minecraft:packed_ice
setblock 154 94 277 minecraft:snow_block
setblock 155 94 276 minecraft:snow_block
fill 155 94 277 155 97 277 minecraft:packed_ice
setblock 155 94 315 minecraft:packed_ice
setblock 155 94 316 minecraft:snow_block
fill 156 94 276 156 97 276 minecraft:packed_ice
setblock 156 94 315 minecraft:snow_block
fill 156 94 316 156 97 316 minecraft:packed_ice
fill 157 94 315 157 97 315 minecraft:packed_ice
setblock 158 94 278 minecraft:light[level=12]
setblock 158 94 285 minecraft:light[level=12]
setblock 158 94 292 minecraft:light[level=12]
setblock 158 94 299 minecraft:light[level=12]
setblock 158 94 306 minecraft:light[level=12]
setblock 158 94 313 minecraft:light[level=12]
fill 159 94 308 159 95 308 minecraft:blue_ice
setblock 160 94 276 minecraft:snow_block
setblock 160 94 316 minecraft:snow_block
fill 160 94 317 160 114 317 minecraft:packed_ice
fill 161 94 316 161 97 316 minecraft:packed_ice
setblock 165 94 278 minecraft:light[level=12]
setblock 165 94 285 minecraft:light[level=12]
setblock 165 94 292 minecraft:light[level=12]
setblock 165 94 299 minecraft:light[level=12]
setblock 165 94 306 minecraft:light[level=12]
setblock 165 94 313 minecraft:light[level=12]
fill 166 94 277 166 95 277 minecraft:packed_ice
fill 167 94 276 167 95 276 minecraft:packed_ice
fill 167 94 278 167 95 278 minecraft:packed_ice
fill 168 94 277 168 95 277 minecraft:packed_ice
fill 168 94 290 168 95 290 minecraft:sea_lantern
fill 168 94 300 168 95 300 minecraft:sea_lantern
setblock 172 94 278 minecraft:light[level=12]
setblock 172 94 285 minecraft:light[level=12]
setblock 172 94 306 minecraft:light[level=12]
setblock 172 94 313 minecraft:light[level=12]
fill 173 94 316 174 94 316 minecraft:packed_ice
setblock 175 94 316 minecraft:snow_block
fill 176 94 316 176 97 316 minecraft:packed_ice
setblock 178 94 275 minecraft:light_blue_concrete
setblock 179 94 278 minecraft:light[level=12]
setblock 179 94 285 minecraft:light[level=12]
setblock 179 94 313 minecraft:light[level=12]
fill 180 94 304 180 94 306 minecraft:snow_block
setblock 180 94 307 minecraft:packed_ice
setblock 181 94 285 minecraft:snow_block
fill 181 94 286 181 97 286 minecraft:packed_ice
setblock 181 94 290 minecraft:snow_block
fill 181 94 291 181 97 291 minecraft:packed_ice
fill 181 94 302 181 95 302 minecraft:snow_block
setblock 181 94 305 minecraft:snow_block
fill 181 94 306 181 96 306 minecraft:packed_ice
setblock 182 94 284 minecraft:snow_block
fill 182 94 285 182 97 285 minecraft:packed_ice
setblock 182 94 289 minecraft:snow_block
fill 182 94 290 182 97 290 minecraft:packed_ice
setblock 182 94 294 minecraft:snow_block
fill 182 94 295 182 97 295 minecraft:packed_ice
fill 182 94 296 182 95 299 minecraft:snow_block
setblock 182 94 300 minecraft:packed_ice
setblock 182 94 304 minecraft:snow_block
fill 182 94 305 182 97 305 minecraft:packed_ice
setblock 182 94 309 minecraft:snow_block
fill 182 94 310 182 97 310 minecraft:packed_ice
fill 141 95 301 141 110 301 minecraft:packed_ice
setblock 141 95 311 minecraft:white_concrete
fill 141 95 312 141 112 312 minecraft:packed_ice
setblock 142 95 283 minecraft:snow_block
fill 142 95 284 142 98 284 minecraft:packed_ice
setblock 142 95 288 minecraft:snow_block
fill 142 95 289 142 98 289 minecraft:packed_ice
setblock 142 95 293 minecraft:snow_block
setblock 143 95 287 minecraft:snow_block
fill 143 95 288 143 98 288 minecraft:packed_ice
fill 143 95 290 143 96 290 minecraft:packed_ice
setblock 144 95 280 minecraft:packed_ice
setblock 146 95 278 minecraft:packed_ice
setblock 146 95 282 minecraft:packed_ice
setblock 148 95 280 minecraft:packed_ice
fill 150 95 276 150 98 276 minecraft:packed_ice
fill 151 95 316 152 96 316 minecraft:packed_ice
setblock 153 95 277 minecraft:snow_block
fill 153 95 315 154 95 315 minecraft:packed_ice
setblock 154 95 276 minecraft:snow_block
fill 154 95 277 154 98 277 minecraft:packed_ice
setblock 154 95 316 minecraft:snow_block
fill 155 95 276 155 98 276 minecraft:packed_ice
setblock 155 95 315 minecraft:snow_block
fill 155 95 316 155 98 316 minecraft:packed_ice
fill 156 95 315 156 98 315 minecraft:packed_ice
setblock 159 95 276 minecraft:snow_block
setblock 159 95 316 minecraft:snow_block
setblock 160 95 315 minecraft:snow_block
fill 160 95 316 160 98 316 minecraft:packed_ice
fill 167 95 291 167 95 292 minecraft:sea_lantern
fill 168 95 291 168 96 291 minecraft:sea_lantern
fill 171 95 316 173 95 316 minecraft:packed_ice
setblock 174 95 316 minecraft:snow_block
fill 175 95 316 175 98 316 minecraft:packed_ice
fill 177 95 316 177 96 316 minecraft:packed_ice
fill 178 95 275 178 112 275 minecraft:packed_ice
fill 180 95 304 180 131 305 minecraft:snow_block
fill 181 95 285 181 98 285 minecraft:packed_ice
setblock 181 95 289 minecraft:snow_block
fill 181 95 290 181 98 290 minecraft:packed_ice
fill 181 95 292 181 96 292 minecraft:packed_ice
fill 181 95 293 181 96 294 minecraft:snow_block
setblock 181 95 305 minecraft:packed_ice
setblock 181 95 309 minecraft:snow_block
setblock 182 95 283 minecraft:snow_block
fill 182 95 284 182 98 284 minecraft:packed_ice
setblock 182 95 288 minecraft:snow_block
fill 182 95 289 182 98 289 minecraft:packed_ice
setblock 182 95 293 minecraft:snow_block
fill 182 95 294 182 98 294 minecraft:packed_ice
fill 182 95 300 182 96 301 minecraft:snow_block
setblock 182 95 303 minecraft:snow_block
fill 182 95 304 182 97 304 minecraft:packed_ice
setblock 182 95 308 minecraft:snow_block
fill 182 95 309 182 98 309 minecraft:packed_ice
setblock 183 95 311 minecraft:light_blue_concrete
fill 183 95 312 183 112 313 minecraft:packed_ice
fill 141 96 311 141 114 311 minecraft:packed_ice
setblock 142 96 282 minecraft:snow_block
fill 142 96 283 142 99 283 minecraft:packed_ice
setblock 142 96 287 minecraft:snow_block
fill 142 96 288 142 99 288 minecraft:packed_ice
setblock 142 96 292 minecraft:snow_block
fill 142 96 293 142 98 294 minecraft:packed_ice
setblock 143 96 286 minecraft:snow_block
fill 143 96 287 143 99 287 minecraft:packed_ice
fill 149 96 276 149 99 276 minecraft:packed_ice
fill 150 96 316 150 98 316 minecraft:packed_ice
setblock 152 96 277 minecraft:snow_block
fill 152 96 315 153 96 315 minecraft:packed_ice
setblock 153 96 276 minecraft:snow_block
fill 153 96 277 153 99 277 minecraft:packed_ice
setblock 153 96 316 minecraft:snow_block
fill 154 96 276 154 99 276 minecraft:packed_ice
setblock 154 96 314 minecraft:packed_ice
setblock 154 96 315 minecraft:snow_block
fill 154 96 316 154 99 316 minecraft:packed_ice
setblock 155 96 314 minecraft:snow_block
fill 155 96 315 155 99 315 minecraft:packed_ice
fill 156 96 314 158 97 314 minecraft:packed_ice
setblock 157 96 277 minecraft:snow_block
setblock 158 96 276 minecraft:snow_block
setblock 158 96 316 minecraft:snow_block
fill 159 96 276 159 99 276 minecraft:packed_ice
fill 159 96 308 159 105 308 minecraft:packed_ice
setblock 159 96 315 minecraft:snow_block
fill 159 96 316 159 99 316 minecraft:packed_ice
fill 160 96 315 161 98 315 minecraft:packed_ice
fill 161 96 275 161 106 275 minecraft:packed_ice
setblock 162 96 275 minecraft:white_concrete
fill 163 96 275 164 114 275 minecraft:packed_ice
setblock 163 96 316 minecraft:snow_block
fill 164 96 316 164 99 316 minecraft:packed_ice
setblock 168 96 316 minecraft:snow_block
fill 169 96 316 172 96 316 minecraft:packed_ice
fill 171 96 315 173 96 315 minecraft:packed_ice
setblock 173 96 316 minecraft:snow_block
setblock 174 96 315 minecraft:snow_block
fill 174 96 316 174 99 316 minecraft:packed_ice
fill 175 96 315 176 98 315 minecraft:packed_ice
setblock 178 96 316 minecraft:snow_block
setblock 180 96 288 minecraft:packed_ice
fill 180 96 290 180 99 290 minecraft:packed_ice
setblock 181 96 288 minecraft:snow_block
fill 181 96 289 181 99 289 minecraft:packed_ice
setblock 181 96 308 minecraft:snow_block
setblock 181 96 309 minecraft:packed_ice
fill 182 96 283 182 99 283 minecraft:packed_ice
setblock 182 96 287 minecraft:snow_block
fill 182 96 288 182 99 288 minecraft:packed_ice
setblock 182 96 292 minecraft:snow_block
fill 182 96 293 182 99 293 minecraft:packed_ice
setblock 182 96 296 minecraft:packed_ice
fill 182 96 297 182 96 299 minecraft:snow_block
setblock 182 96 303 minecraft:packed_ice
setblock 182 96 307 minecraft:snow_block
fill 182 96 308 182 99 308 minecraft:packed_ice
fill 183 96 311 183 115 311 minecraft:packed_ice
setblock 141 97 296 minecraft:light_blue_concrete
setblock 142 97 281 minecraft:snow_block
fill 142 97 282 142 100 282 minecraft:packed_ice
setblock 142 97 286 minecraft:snow_block
fill 142 97 287 142 100 287 minecraft:packed_ice
setblock 142 97 291 minecraft:snow_block
fill 142 97 292 142 100 292 minecraft:packed_ice
setblock 143 97 285 minecraft:snow_block
fill 143 97 286 143 100 286 minecraft:packed_ice
setblock 143 97 290 minecraft:snow_block
fill 143 97 291 143 100 291 minecraft:packed_ice
fill 148 97 276 148 100 276 minecraft:packed_ice
fill 148 97 316 149 99 316 minecraft:packed_ice
fill 150 97 315 152 97 315 minecraft:packed_ice
fill 150 97 317 152 105 317 minecraft:packed_ice
setblock 151 97 277 minecraft:snow_block
setblock 151 97 316 minecraft:packed_ice
setblock 152 97 276 minecraft:snow_block
fill 152 97 277 152 100 277 minecraft:packed_ice
fill 152 97 314 153 97 314 minecraft:packed_ice
setblock 152 97 316 minecraft:snow_block
fill 153 97 276 153 100 276 minecraft:packed_ice
setblock 153 97 315 minecraft:snow_block
fill 153 97 316 153 100 316 minecraft:packed_ice
setblock 153 97 317 minecraft:light_blue_concrete
setblock 154 97 314 minecraft:snow_block
fill 154 97 315 154 100 315 minecraft:packed_ice
fill 154 97 317 154 114 317 minecraft:packed_ice
setblock 155 97 313 minecraft:snow_block
fill 155 97 314 155 100 314 minecraft:packed_ice
setblock 156 97 277 minecraft:snow_block
fill 156 97 313 156 100 313 minecraft:packed_ice
setblock 157 97 276 minecraft:snow_block
fill 157 97 277 157 100 277 minecraft:packed_ice
setblock 157 97 316 minecraft:snow_block
fill 158 97 276 158 100 276 minecraft:packed_ice
setblock 158 97 315 minecraft:snow_block
fill 158 97 316 158 100 316 minecraft:packed_ice
fill 159 97 307 159 105 307 minecraft:packed_ice
setblock 159 97 314 minecraft:snow_block
fill 159 97 315 159 100 315 minecraft:packed_ice
fill 160 97 314 160 100 314 minecraft:packed_ice
fill 162 97 275 162 114 275 minecraft:packed_ice
setblock 162 97 315 minecraft:packed_ice
setblock 162 97 316 minecraft:snow_block
fill 163 97 316 163 100 316 minecraft:packed_ice
fill 165 97 316 166 97 316 minecraft:packed_ice
setblock 167 97 316 minecraft:snow_block
fill 168 97 316 171 97 316 minecraft:packed_ice
fill 169 97 315 172 97 315 minecraft:packed_ice
fill 171 97 314 173 97 314 minecraft:packed_ice
setblock 172 97 316 minecraft:snow_block
setblock 173 97 315 minecraft:snow_block
fill 173 97 316 173 100 316 minecraft:packed_ice
setblock 174 97 314 minecraft:snow_block
fill 174 97 315 174 100 315 minecraft:packed_ice
fill 175 97 314 175 100 314 minecraft:packed_ice
setblock 177 97 315 minecraft:packed_ice
setblock 177 97 316 minecraft:snow_block
fill 178 97 316 178 100 316 minecraft:packed_ice
fill 179 97 292 179 101 292 minecraft:snow_block
setblock 180 97 287 minecraft:packed_ice
setblock 180 97 288 minecraft:snow_block
fill 180 97 289 180 100 289 minecraft:packed_ice
fill 180 97 291 180 97 292 minecraft:packed_ice
setblock 181 97 287 minecraft:snow_block
fill 181 97 288 181 100 288 minecraft:packed_ice
setblock 181 97 292 minecraft:snow_block
fill 181 97 293 181 99 294 minecraft:packed_ice
setblock 182 97 286 minecraft:snow_block
fill 182 97 287 182 100 287 minecraft:packed_ice
setblock 182 97 291 minecraft:snow_block
fill 182 97 292 182 100 292 minecraft:packed_ice
setblock 182 97 296 minecraft:snow_block
fill 182 97 297 182 100 297 minecraft:packed_ice
fill 182 97 298 182 97 300 minecraft:snow_block
setblock 182 97 306 minecraft:snow_block
fill 182 97 307 182 99 307 minecraft:packed_ice
setblock 182 97 311 minecraft:snow_block
fill 182 97 312 182 100 312 minecraft:packed_ice
fill 183 97 286 183 111 286 minecraft:packed_ice
fill 141 98 296 141 110 296 minecraft:packed_ice
fill 142 98 281 142 101 281 minecraft:packed_ice
setblock 142 98 285 minecraft:snow_block
fill 142 98 286 142 101 286 minecraft:packed_ice
setblock 142 98 290 minecraft:snow_block
fill 142 98 291 142 101 291 minecraft:packed_ice
setblock 142 98 295 minecraft:snow_block
fill 143 98 285 143 100 285 minecraft:packed_ice
setblock 143 98 289 minecraft:snow_block
fill 143 98 290 143 101 290 minecraft:packed_ice
fill 143 98 292 143 99 292 minecraft:packed_ice
fill 143 98 314 143 100 314 minecraft:packed_ice
fill 144 98 313 144 100 313 minecraft:packed_ice
fill 144 98 315 144 100 315 minecraft:packed_ice
fill 145 98 314 145 100 314 minecraft:packed_ice
setblock 146 98 276 minecraft:snow_block
fill 147 98 276 147 101 276 minecraft:packed_ice
fill 147 98 316 147 101 316 minecraft:packed_ice
fill 148 98 315 151 98 315 minecraft:packed_ice
setblock 149 98 277 minecraft:packed_ice
setblock 150 98 277 minecraft:snow_block
fill 150 98 314 152 98 314 minecraft:packed_ice
setblock 151 98 276 minecraft:snow_block
fill 151 98 277 151 101 277 minecraft:packed_ice
setblock 151 98 316 minecraft:snow_block
fill 152 98 276 152 101 276 minecraft:packed_ice
setblock 152 98 315 minecraft:snow_block
fill 152 98 316 152 101 316 minecraft:packed_ice
setblock 153 98 313 minecraft:packed_ice
setblock 153 98 314 minecraft:snow_block
fill 153 98 315 153 101 315 minecraft:packed_ice
fill 153 98 317 153 114 317 minecraft:packed_ice
setblock 154 98 313 minecraft:snow_block
fill 154 98 314 154 101 314 minecraft:packed_ice
setblock 155 98 277 minecraft:snow_block
fill 155 98 313 155 101 313 minecraft:packed_ice
setblock 156 98 276 minecraft:snow_block
fill 156 98 277 156 101 277 minecraft:packed_ice
fill 156 98 314 157 98 314 minecraft:packed_ice
setblock 156 98 316 minecraft:snow_block
setblock 156 98 317 minecraft:light_blue_concrete
fill 157 98 276 157 101 276 minecraft:packed_ice
fill 157 98 313 158 98 313 minecraft:packed_ice
setblock 157 98 315 minecraft:snow_block
fill 157 98 316 157 101 316 minecraft:packed_ice
setblock 158 98 314 minecraft:snow_block
fill 158 98 315 158 101 315 minecraft:packed_ice
fill 159 98 314 159 101 314 minecraft:packed_ice
setblock 160 98 276 minecraft:packed_ice
fill 160 98 307 160 105 308 minecraft:packed_ice
setblock 161 98 316 minecraft:snow_block
setblock 162 98 315 minecraft:snow_block
fill 162 98 316 162 101 316 minecraft:packed_ice
fill 163 98 315 166 98 315 minecraft:packed_ice
setblock 165 98 316 minecraft:packed_ice
setblock 166 98 316 minecraft:snow_block
fill 167 98 276 168 99 279 minecraft:snow_block
setblock 167 98 315 minecraft:snow_block
fill 167 98 316 170 98 316 minecraft:packed_ice
fill 168 98 280 168 99 285 minecraft:snow_block
fill 168 98 315 171 98 315 minecraft:packed_ice
fill 169 98 314 172 98 314 minecraft:packed_ice
setblock 171 98 316 minecraft:snow_block
fill 172 98 280 172 104 280 minecraft:packed_ice
setblock 172 98 315 minecraft:snow_block
fill 172 98 316 172 101 316 minecraft:packed_ice
fill 173 98 276 174 99 276 minecraft:packed_ice
setblock 173 98 314 minecraft:snow_block
fill 173 98 315 173 101 315 minecraft:packed_ice
fill 174 98 314 174 101 314 minecraft:packed_ice
fill 176 98 314 176 99 314 minecraft:packed_ice
setblock 176 98 316 minecraft:snow_block
setblock 177 98 315 minecraft:snow_block
fill 177 98 316 177 101 316 minecraft:packed_ice
fill 179 98 316 179 99 316 minecraft:packed_ice
setblock 180 98 287 minecraft:snow_block
fill 180 98 288 180 100 288 minecraft:packed_ice
setblock 180 98 291 minecraft:packed_ice
setblock 180 98 292 minecraft:snow_block
fill 180 98 293 180 101 293 minecraft:packed_ice
setblock 180 98 294 minecraft:snow_block
setblock 181 98 286 minecraft:snow_block
fill 181 98 287 181 101 287 minecraft:packed_ice
setblock 181 98 291 minecraft:snow_block
fill 181 98 292 181 101 292 minecraft:packed_ice
setblock 181 98 295 minecraft:packed_ice
setblock 181 98 296 minecraft:snow_block
fill 181 98 299 181 99 300 minecraft:snow_block
setblock 182 98 285 minecraft:snow_block
fill 182 98 286 182 101 286 minecraft:packed_ice
setblock 182 98 290 minecraft:snow_block
fill 182 98 291 182 101 291 minecraft:packed_ice
setblock 182 98 295 minecraft:snow_block
fill 182 98 296 182 101 296 minecraft:packed_ice
fill 182 98 298 182 99 298 minecraft:packed_ice
setblock 182 98 299 minecraft:snow_block
setblock 182 98 306 minecraft:packed_ice
setblock 182 98 310 minecraft:snow_block
fill 182 98 311 182 101 311 minecraft:packed_ice
fill 183 98 292 183 114 293 minecraft:packed_ice
setblock 183 98 294 minecraft:white_concrete
fill 183 98 295 183 110 295 minecraft:packed_ice
setblock 142 99 284 minecraft:snow_block
fill 142 99 285 142 102 285 minecraft:packed_ice
setblock 142 99 289 minecraft:snow_block
fill 142 99 290 142 102 290 minecraft:packed_ice
setblock 142 99 293 minecraft:packed_ice
setblock 142 99 294 minecraft:snow_block
fill 142 99 295 142 102 295 minecraft:packed_ice
fill 142 99 311 142 99 313 minecraft:packed_ice
setblock 142 99 314 minecraft:snow_block
setblock 143 99 288 minecraft:snow_block
fill 143 99 289 143 102 289 minecraft:packed_ice
fill 143 99 313 143 100 313 minecraft:packed_ice
fill 143 99 315 143 100 315 minecraft:packed_ice
setblock 144 99 276 minecraft:packed_ice
setblock 145 99 276 minecraft:snow_block
fill 145 99 313 145 100 313 minecraft:packed_ice
fill 145 99 315 145 104 315 minecraft:packed_ice
setblock 145 99 316 minecraft:snow_block
fill 146 99 276 146 102 276 minecraft:packed_ice
fill 146 99 316 146 102 316 minecraft:packed_ice
fill 147 99 315 150 99 315 minecraft:packed_ice
setblock 148 99 277 minecraft:packed_ice
setblock 149 99 277 minecraft:snow_block
fill 149 99 314 151 99 314 minecraft:packed_ice
setblock 150 99 276 minecraft:snow_block
fill 150 99 277 150 102 277 minecraft:packed_ice
setblock 150 99 316 minecraft:snow_block
fill 151 99 276 151 102 276 minecraft:packed_ice
fill 151 99 313 152 99 313 minecraft:packed_ice
setblock 151 99 315 minecraft:snow_block
fill 151 99 316 151 102 316 minecraft:packed_ice
setblock 152 99 314 minecraft:snow_block
fill 152 99 315 152 102 315 minecraft:packed_ice
setblock 153 99 313 minecraft:snow_block
fill 153 99 314 153 102 314 minecraft:packed_ice
setblock 154 99 277 minecraft:snow_block
fill 154 99 313 154 102 313 minecraft:packed_ice
setblock 155 99 276 minecraft:snow_block
fill 155 99 277 155 102 277 minecraft:packed_ice
setblock 155 99 316 minecraft:snow_block
setblock 155 99 317 minecraft:light_blue_concrete
fill 156 99 276 156 102 276 minecraft:packed_ice
setblock 156 99 314 minecraft:packed_ice
setblock 156 99 315 minecraft:snow_block
fill 156 99 316 156 102 317 minecraft:packed_ice
setblock 157 99 313 minecraft:packed_ice
setblock 157 99 314 minecraft:snow_block
fill 157 99 315 157 102 315 minecraft:packed_ice
fill 158 99 307 158 105 308 minecraft:packed_ice
setblock 158 99 313 minecraft:snow_block
fill 158 99 314 158 102 314 minecraft:packed_ice
fill 159 99 306 160 105 306 minecraft:packed_ice
fill 159 99 309 160 105 309 minecraft:packed_ice
setblock 160 99 276 minecraft:snow_block
setblock 160 99 315 minecraft:packed_ice
setblock 160 99 316 minecraft:snow_block
fill 161 99 308 161 105 308 minecraft:packed_ice
setblock 161 99 314 minecraft:packed_ice
setblock 161 99 315 minecraft:snow_block
fill 161 99 316 161 102 316 minecraft:packed_ice
fill 162 99 280 162 100 281 minecraft:white_concrete
fill 162 99 315 165 99 315 minecraft:packed_ice
setblock 165 99 316 minecraft:snow_block
setblock 166 99 315 minecraft:snow_block
fill 166 99 316 169 99 316 minecraft:packed_ice
fill 167 99 280 167 99 284 minecraft:snow_block
setblock 167 99 314 minecraft:snow_block
fill 167 99 315 170 99 315 minecraft:packed_ice
fill 168 99 286 168 100 295 minecraft:snow_block
fill 168 99 314 171 99 314 minecraft:packed_ice
fill 169 99 285 169 99 291 minecraft:snow_block
fill 169 99 300 169 100 303 minecraft:snow_block
fill 170 99 313 172 99 313 minecraft:packed_ice
setblock 170 99 316 minecraft:snow_block
fill 171 99 276 172 101 276 minecraft:packed_ice
setblock 171 99 315 minecraft:snow_block
fill 171 99 316 171 102 316 minecraft:packed_ice
setblock 172 99 314 minecraft:snow_block
fill 172 99 315 172 102 315 minecraft:packed_ice
setblock 173 99 313 minecraft:snow_block
fill 173 99 314 173 102 314 minecraft:packed_ice
fill 174 99 313 174 100 313 minecraft:packed_ice
setblock 175 99 276 minecraft:snow_block
setblock 175 99 315 minecraft:packed_ice
setblock 175 99 316 minecraft:snow_block
fill 176 99 276 176 102 276 minecraft:packed_ice
setblock 176 99 315 minecraft:snow_block
fill 176 99 316 176 102 316 minecraft:packed_ice
fill 177 99 315 178 100 315 minecraft:packed_ice
setblock 180 99 291 minecraft:snow_block
fill 180 99 292 180 102 292 minecraft:packed_ice
fill 180 99 294 180 100 294 minecraft:packed_ice
setblock 180 99 300 minecraft:snow_block
fill 181 99 286 181 100 286 minecraft:packed_ice
setblock 181 99 290 minecraft:snow_block
fill 181 99 291 181 102 291 minecraft:packed_ice
setblock 181 99 295 minecraft:snow_block
fill 181 99 296 181 102 296 minecraft:packed_ice
setblock 182 99 284 minecraft:snow_block
fill 182 99 285 182 102 285 minecraft:packed_ice
setblock 182 99 289 minecraft:snow_block
fill 182 99 290 182 102 290 minecraft:packed_ice
setblock 182 99 294 minecraft:snow_block
fill 182 99 295 182 102 295 minecraft:packed_ice
setblock 182 99 309 minecraft:snow_block
fill 182 99 310 182 100 310 minecraft:packed_ice
setblock 182 99 313 minecraft:packed_ice
fill 183 99 294 183 114 294 minecraft:packed_ice
setblock 141 100 298 minecraft:light_blue_concrete
fill 142 100 276 142 100 277 minecraft:packed_ice
setblock 142 100 283 minecraft:snow_block
fill 142 100 284 142 102 284 minecraft:packed_ice
setblock 142 100 288 minecraft:snow_block
fill 142 100 289 142 103 289 minecraft:packed_ice
setblock 142 100 293 minecraft:snow_block
fill 142 100 294 142 103 294 minecraft:packed_ice
fill 142 100 296 142 101 296 minecraft:packed_ice
fill 142 100 311 142 100 312 minecraft:packed_ice
setblock 142 100 313 minecraft:snow_block
fill 142 100 314 142 101 316 minecraft:packed_ice
setblock 143 100 276 minecraft:packed_ice
setblock 143 100 287 minecraft:snow_block
fill 143 100 288 143 102 288 minecraft:packed_ice
setblock 143 100 292 minecraft:snow_block
fill 143 100 293 143 102 293 minecraft:packed_ice
setblock 143 100 316 minecraft:packed_ice
setblock 144 100 276 minecraft:snow_block
setblock 144 100 278 minecraft:light[level=15]
setblock 144 100 285 minecraft:light[level=12]
setblock 144 100 286 minecraft:light[level=15]
setblock 144 100 292 minecraft:light[level=12]
setblock 144 100 294 minecraft:light[level=15]
setblock 144 100 299 minecraft:light[level=12]
setblock 144 100 302 minecraft:light[level=15]
setblock 144 100 306 minecraft:light[level=12]
setblock 144 100 310 minecraft:light[level=15]
setblock 144 100 316 minecraft:snow_block
fill 145 100 276 145 103 276 minecraft:packed_ice
fill 145 100 316 145 103 316 minecraft:packed_ice
fill 146 100 315 149 100 315 minecraft:packed_ice
setblock 147 100 277 minecraft:packed_ice
setblock 148 100 277 minecraft:snow_block
fill 148 100 314 150 100 314 minecraft:packed_ice
setblock 148 100 316 minecraft:packed_ice
setblock 149 100 276 minecraft:snow_block
fill 149 100 277 149 103 277 minecraft:packed_ice
setblock 149 100 316 minecraft:snow_block
fill 150 100 276 150 103 276 minecraft:packed_ice
fill 150 100 313 151 100 313 minecraft:packed_ice
setblock 150 100 315 minecraft:snow_block
fill 150 100 316 150 103 316 minecraft:packed_ice
setblock 151 100 278 minecraft:packed_ice
setblock 151 100 285 minecraft:light[level=12]
setblock 151 100 292 minecraft:light[level=12]
setblock 151 100 299 minecraft:light[level=12]
setblock 151 100 306 minecraft:light[level=12]
setblock 151 100 314 minecraft:snow_block
fill 151 100 315 151 103 315 minecraft:packed_ice
setblock 152 100 278 minecraft:snow_block
setblock 152 100 286 minecraft:light[level=15]
setblock 152 100 294 minecraft:light[level=15]
setblock 152 100 302 minecraft:light[level=15]
setblock 152 100 310 minecraft:light[level=15]
setblock 152 100 313 minecraft:snow_block
fill 152 100 314 152 103 314 minecraft:packed_ice
setblock 153 100 277 minecraft:snow_block
fill 153 100 278 153 102 278 minecraft:packed_ice
fill 153 100 313 153 103 313 minecraft:packed_ice
setblock 154 100 276 minecraft:snow_block
fill 154 100 277 154 103 277 minecraft:packed_ice
setblock 154 100 316 minecraft:snow_block
fill 155 100 276 155 103 276 minecraft:packed_ice
setblock 155 100 315 minecraft:snow_block
fill 155 100 316 155 103 317 minecraft:packed_ice
setblock 156 100 314 minecraft:snow_block
fill 156 100 315 156 103 315 minecraft:packed_ice
setblock 157 100 313 minecraft:snow_block
fill 157 100 314 157 103 314 minecraft:packed_ice
setblock 158 100 278 minecraft:light[level=12]
setblock 158 100 285 minecraft:light[level=12]
setblock 158 100 292 minecraft:light[level=12]
setblock 158 100 299 minecraft:light[level=12]
fill 158 100 306 158 105 306 minecraft:packed_ice
fill 158 100 309 158 105 309 minecraft:packed_ice
fill 158 100 313 158 101 313 minecraft:packed_ice
setblock 159 100 276 minecraft:snow_block
setblock 159 100 316 minecraft:snow_block
fill 160 100 276 160 102 276 minecraft:packed_ice
setblock 160 100 278 minecraft:light[level=15]
setblock 160 100 286 minecraft:light[level=15]
setblock 160 100 294 minecraft:light[level=15]
setblock 160 100 302 minecraft:light[level=15]
setblock 160 100 310 minecraft:light[level=15]
setblock 160 100 315 minecraft:snow_block
fill 160 100 316 160 103 316 minecraft:packed_ice
fill 161 100 307 161 105 307 minecraft:packed_ice
fill 161 100 309 161 105 309 minecraft:packed_ice
setblock 161 100 314 minecraft:snow_block
fill 161 100 315 164 100 315 minecraft:packed_ice
fill 162 100 314 165 100 314 minecraft:packed_ice
setblock 164 100 316 minecraft:snow_block
setblock 165 100 278 minecraft:light[level=12]
setblock 165 100 285 minecraft:light[level=12]
setblock 165 100 292 minecraft:light[level=12]
setblock 165 100 299 minecraft:light[level=12]
setblock 165 100 306 minecraft:light[level=12]
setblock 165 100 313 minecraft:light[level=12]
setblock 165 100 315 minecraft:snow_block
fill 165 100 316 168 100 316 minecraft:packed_ice
setblock 166 100 314 minecraft:snow_block
fill 166 100 315 169 100 315 minecraft:packed_ice
fill 167 100 276 167 100 277 minecraft:blue_ice
fill 167 100 314 170 100 314 minecraft:packed_ice
fill 168 100 277 168 100 285 minecraft:blue_ice
setblock 168 100 302 minecraft:light[level=15]
setblock 168 100 310 minecraft:light[level=15]
setblock 169 100 276 minecraft:snow_block
fill 169 100 290 169 100 291 minecraft:snow_block
fill 169 100 304 170 100 311 minecraft:snow_block
fill 169 100 313 171 100 313 minecraft:packed_ice
setblock 169 100 316 minecraft:snow_block
fill 170 100 276 170 103 276 minecraft:packed_ice
fill 170 100 300 170 100 303 minecraft:snow_block
fill 170 100 312 170 101 312 minecraft:snow_block
setblock 170 100 315 minecraft:snow_block
fill 170 100 316 170 103 316 minecraft:packed_ice
setblock 171 100 314 minecraft:snow_block
fill 171 100 315 171 103 315 minecraft:packed_ice
setblock 172 100 278 minecraft:light[level=12]
setblock 172 100 285 minecraft:light[level=12]
setblock 172 100 306 minecraft:light[level=12]
setblock 172 100 313 minecraft:snow_block
fill 172 100 314 172 103 314 minecraft:packed_ice
setblock 173 100 276 minecraft:packed_ice
fill 173 100 313 173 101 313 minecraft:packed_ice
setblock 174 100 276 minecraft:snow_block
setblock 174 100 316 minecraft:snow_block
fill 175 100 276 175 103 276 minecraft:packed_ice
setblock 175 100 315 minecraft:snow_block
fill 175 100 316 175 103 316 minecraft:packed_ice
setblock 176 100 278 minecraft:light[level=15]
setblock 176 100 286 minecraft:light[level=15]
setblock 176 100 302 minecraft:light[level=15]
setblock 176 100 310 minecraft:light[level=15]
setblock 176 100 314 minecraft:snow_block
fill 176 100 315 176 103 315 minecraft:packed_ice
setblock 179 100 278 minecraft:light[level=12]
setblock 179 100 285 minecraft:light[level=12]
setblock 179 100 300 minecraft:snow_block
setblock 179 100 313 minecraft:light[level=12]
setblock 179 100 316 minecraft:snow_block
setblock 180 100 290 minecraft:snow_block
fill 180 100 291 180 102 291 minecraft:packed_ice
setblock 181 100 289 minecraft:snow_block
fill 181 100 290 181 103 290 minecraft:packed_ice
setblock 181 100 293 minecraft:packed_ice
setblock 181 100 294 minecraft:snow_block
fill 181 100 295 181 103 295 minecraft:packed_ice
fill 182 100 284 182 101 284 minecraft:packed_ice
setblock 182 100 288 minecraft:snow_block
fill 182 100 289 182 103 289 minecraft:packed_ice
setblock 182 100 293 minecraft:snow_block
fill 182 100 294 182 103 294 minecraft:packed_ice
setblock 182 100 298 minecraft:snow_block
setblock 182 100 309 minecraft:packed_ice
setblock 182 100 313 minecraft:snow_block
fill 182 100 314 182 101 314 minecraft:packed_ice
setblock 183 100 290 minecraft:light_blue_concrete
fill 141 101 298 141 112 298 minecraft:packed_ice
setblock 142 101 276 minecraft:packed_ice
setblock 142 101 277 minecraft:snow_block
fill 142 101 278 142 103 279 minecraft:packed_ice
setblock 142 101 282 minecraft:snow_block
fill 142 101 283 142 102 283 minecraft:packed_ice
setblock 142 101 287 minecraft:snow_block
fill 142 101 288 142 104 288 minecraft:packed_ice
setblock 142 101 292 minecraft:snow_block
fill 142 101 293 142 104 293 minecraft:packed_ice
setblock 142 101 311 minecraft:packed_ice
setblock 142 101 312 minecraft:snow_block
fill 142 101 313 142 103 313 minecraft:packed_ice
setblock 143 101 276 minecraft:snow_block
setblock 143 101 286 minecraft:snow_block
setblock 143 101 287 minecraft:packed_ice
setblock 143 101 291 minecraft:snow_block
fill 143 101 292 143 103 292 minecraft:packed_ice
setblock 143 101 316 minecraft:snow_block
fill 144 101 276 144 104 276 minecraft:packed_ice
fill 144 101 316 144 104 316 minecraft:packed_ice
setblock 146 101 277 minecraft:packed_ice
fill 146 101 315 148 101 315 minecraft:packed_ice
setblock 147 101 277 minecraft:snow_block
fill 147 101 314 149 101 314 minecraft:packed_ice
setblock 148 101 276 minecraft:snow_block
fill 148 101 277 148 104 277 minecraft:packed_ice
setblock 148 101 316 minecraft:snow_block
fill 149 101 276 149 104 276 minecraft:packed_ice
setblock 149 101 315 minecraft:snow_block
fill 149 101 316 149 104 316 minecraft:packed_ice
setblock 150 101 278 minecraft:packed_ice
setblock 150 101 313 minecraft:packed_ice
setblock 150 101 314 minecraft:snow_block
fill 150 101 315 150 104 315 minecraft:packed_ice
setblock 151 101 278 minecraft:snow_block
setblock 151 101 313 minecraft:snow_block
fill 151 101 314 151 104 314 minecraft:packed_ice
setblock 152 101 277 minecraft:snow_block
fill 152 101 278 152 104 278 minecraft:packed_ice
fill 152 101 313 152 104 313 minecraft:packed_ice
setblock 153 101 276 minecraft:snow_block
fill 153 101 277 153 104 277 minecraft:packed_ice
setblock 153 101 316 minecraft:snow_block
fill 154 101 276 154 104 276 minecraft:packed_ice
setblock 154 101 315 minecraft:snow_block
fill 154 101 316 154 104 316 minecraft:packed_ice
setblock 155 101 314 minecraft:snow_block
fill 155 101 315 155 104 315 minecraft:packed_ice
setblock 156 101 313 minecraft:snow_block
fill 156 101 314 156 104 314 minecraft:packed_ice
setblock 157 101 277 minecraft:snow_block
fill 157 101 313 157 102 313 minecraft:packed_ice
setblock 158 101 276 minecraft:snow_block
setblock 158 101 316 minecraft:snow_block
fill 159 101 276 159 104 276 minecraft:packed_ice
fill 159 101 305 160 105 305 minecraft:packed_ice
fill 159 101 310 160 105 310 minecraft:packed_ice
setblock 159 101 315 minecraft:snow_block
fill 159 101 316 159 104 316 minecraft:packed_ice
setblock 160 101 314 minecraft:snow_block
fill 160 101 315 163 101 315 minecraft:packed_ice
fill 161 101 306 161 105 306 minecraft:packed_ice
fill 161 101 314 164 101 314 minecraft:packed_ice
fill 162 101 308 162 105 308 minecraft:packed_ice
setblock 163 101 316 minecraft:snow_block
setblock 164 101 315 minecraft:snow_block
fill 164 101 316 167 101 316 minecraft:packed_ice
setblock 165 101 314 minecraft:snow_block
fill 165 101 315 168 101 315 minecraft:packed_ice
fill 166 101 314 169 101 314 minecraft:packed_ice
setblock 168 101 276 minecraft:snow_block
fill 168 101 288 168 101 289 minecraft:blue_ice
fill 168 101 313 170 101 313 minecraft:packed_ice
setblock 168 101 316 minecraft:snow_block
fill 169 101 276 169 104 276 minecraft:packed_ice
fill 169 101 292 169 101 295 minecraft:blue_ice
fill 169 101 300 169 101 304 minecraft:blue_ice
setblock 169 101 315 minecraft:snow_block
fill 169 101 316 169 104 316 minecraft:packed_ice
fill 170 101 307 170 101 311 minecraft:snow_block
setblock 170 101 314 minecraft:snow_block
fill 170 101 315 170 104 315 minecraft:packed_ice
setblock 171 101 313 minecraft:snow_block
fill 171 101 314 171 104 314 minecraft:packed_ice
fill 172 101 313 172 102 313 minecraft:packed_ice
setblock 173 101 276 minecraft:snow_block
setblock 173 101 316 minecraft:snow_block
fill 174 101 276 174 104 276 minecraft:packed_ice
setblock 174 101 315 minecraft:snow_block
fill 174 101 316 174 104 316 minecraft:packed_ice
setblock 175 101 314 minecraft:snow_block
fill 175 101 315 175 104 315 minecraft:packed_ice
setblock 176 101 314 minecraft:packed_ice
setblock 177 101 276 minecraft:packed_ice
fill 177 101 315 177 102 315 minecraft:packed_ice
setblock 178 101 316 minecraft:snow_block
fill 179 101 316 179 102 316 minecraft:packed_ice
setblock 180 101 289 minecraft:snow_block
fill 180 101 290 180 102 290 minecraft:packed_ice
setblock 180 101 294 minecraft:snow_block
setblock 181 101 288 minecraft:snow_block
fill 181 101 289 181 103 289 minecraft:packed_ice
setblock 181 101 293 minecraft:snow_block
fill 181 101 294 181 104 294 minecraft:packed_ice
setblock 182 101 287 minecraft:snow_block
fill 182 101 288 182 104 288 minecraft:packed_ice
setblock 182 101 292 minecraft:snow_block
fill 182 101 293 182 104 293 minecraft:packed_ice
setblock 182 101 297 minecraft:snow_block
fill 182 101 298 182 104 298 minecraft:packed_ice
setblock 182 101 312 minecraft:snow_block
setblock 182 101 313 minecraft:packed_ice
fill 183 101 290 183 114 290 minecraft:packed_ice
setblock 142 102 276 minecraft:snow_block
fill 142 102 277 142 105 277 minecraft:packed_ice
setblock 142 102 286 minecraft:snow_block
fill 142 102 287 142 104 287 minecraft:packed_ice
setblock 142 102 291 minecraft:snow_block
fill 142 102 292 142 105 292 minecraft:packed_ice
setblock 142 102 296 minecraft:snow_block
setblock 142 102 312 minecraft:packed_ice
fill 142 102 314 142 102 315 minecraft:packed_ice
setblock 142 102 316 minecraft:snow_block
fill 143 102 276 143 105 276 minecraft:packed_ice
setblock 143 102 290 minecraft:snow_block
fill 143 102 291 143 103 291 minecraft:packed_ice
fill 143 102 316 143 105 316 minecraft:packed_ice
fill 144 102 315 144 105 315 minecraft:packed_ice
setblock 145 102 277 minecraft:packed_ice
setblock 146 102 277 minecraft:snow_block
fill 146 102 315 147 102 315 minecraft:packed_ice
setblock 147 102 276 minecraft:snow_block
fill 147 102 277 147 105 277 minecraft:packed_ice
fill 147 102 314 148 102 314 minecraft:packed_ice
setblock 147 102 316 minecraft:snow_block
fill 148 102 276 148 105 276 minecraft:packed_ice
setblock 148 102 315 minecraft:snow_block
fill 148 102 316 148 105 316 minecraft:packed_ice
setblock 149 102 278 minecraft:packed_ice
setblock 149 102 313 minecraft:packed_ice
setblock 149 102 314 minecraft:snow_block
fill 149 102 315 149 105 315 minecraft:packed_ice
setblock 150 102 278 minecraft:snow_block
setblock 150 102 313 minecraft:snow_block
fill 150 102 314 150 105 314 minecraft:packed_ice
setblock 151 102 277 minecraft:snow_block
fill 151 102 278 151 105 278 minecraft:packed_ice
fill 151 102 313 151 104 313 minecraft:packed_ice
setblock 152 102 276 minecraft:snow_block
fill 152 102 277 152 105 277 minecraft:packed_ice
setblock 152 102 316 minecraft:snow_block
fill 153 102 276 153 105 276 minecraft:packed_ice
setblock 153 102 315 minecraft:snow_block
fill 153 102 316 153 105 316 minecraft:packed_ice
setblock 154 102 314 minecraft:snow_block
fill 154 102 315 154 105 315 minecraft:packed_ice
setblock 155 102 313 minecraft:snow_block
fill 155 102 314 155 105 314 minecraft:packed_ice
setblock 156 102 277 minecraft:snow_block
setblock 156 102 313 minecraft:packed_ice
setblock 157 102 276 minecraft:snow_block
fill 157 102 306 157 105 306 minecraft:packed_ice
fill 157 102 309 157 105 309 minecraft:packed_ice
setblock 157 102 316 minecraft:snow_block
fill 158 102 276 158 105 276 minecraft:packed_ice
fill 158 102 305 158 105 305 minecraft:packed_ice
fill 158 102 310 158 105 310 minecraft:packed_ice
setblock 158 102 315 minecraft:snow_block
fill 158 102 316 158 105 316 minecraft:packed_ice
setblock 159 102 314 minecraft:snow_block
fill 159 102 315 162 102 315 minecraft:packed_ice
fill 160 102 314 163 102 314 minecraft:packed_ice
fill 161 102 310 161 105 310 minecraft:packed_ice
fill 162 102 306 162 105 307 minecraft:packed_ice
fill 162 102 309 162 105 309 minecraft:packed_ice
setblock 162 102 316 minecraft:snow_block
setblock 163 102 315 minecraft:snow_block
fill 163 102 316 166 102 316 minecraft:packed_ice
setblock 164 102 314 minecraft:snow_block
fill 164 102 315 167 102 315 minecraft:packed_ice
fill 165 102 314 168 102 314 minecraft:packed_ice
setblock 167 102 276 minecraft:snow_block
setblock 167 102 316 minecraft:snow_block
fill 168 102 276 168 105 276 minecraft:packed_ice
setblock 168 102 315 minecraft:snow_block
fill 168 102 316 168 105 316 minecraft:packed_ice
setblock 169 102 313 minecraft:packed_ice
setblock 169 102 314 minecraft:snow_block
fill 169 102 315 169 105 315 minecraft:packed_ice
fill 170 102 309 170 102 312 minecraft:blue_ice
setblock 170 102 313 minecraft:snow_block
fill 170 102 314 170 105 314 minecraft:packed_ice
setblock 171 102 276 minecraft:packed_ice
setblock 171 102 313 minecraft:packed_ice
setblock 172 102 276 minecraft:snow_block
setblock 172 102 316 minecraft:snow_block
fill 173 102 276 173 105 276 minecraft:packed_ice
setblock 173 102 315 minecraft:snow_block
fill 173 102 316 173 105 316 minecraft:packed_ice
setblock 174 102 314 minecraft:snow_block
fill 174 102 315 174 105 315 minecraft:packed_ice
setblock 175 102 314 minecraft:packed_ice
setblock 177 102 276 minecraft:snow_block
setblock 177 102 316 minecraft:snow_block
fill 178 102 316 178 103 316 minecraft:packed_ice
setblock 180 102 293 minecraft:snow_block
setblock 180 102 294 minecraft:packed_ice
setblock 181 102 287 minecraft:snow_block
setblock 181 102 288 minecraft:packed_ice
setblock 181 102 292 minecraft:snow_block
fill 181 102 293 181 105 293 minecraft:packed_ice
setblock 182 102 286 minecraft:snow_block
fill 182 102 287 182 104 287 minecraft:packed_ice
setblock 182 102 291 minecraft:snow_block
fill 182 102 292 182 105 292 minecraft:packed_ice
setblock 182 102 296 minecraft:snow_block
fill 182 102 297 182 105 297 minecraft:packed_ice
setblock 141 103 288 minecraft:white_concrete
setblock 141 103 299 minecraft:white_concrete
fill 141 103 300 141 112 300 minecraft:packed_ice
fill 142 103 276 142 106 276 minecraft:packed_ice
fill 142 103 282 145 104 284 minecraft:blue_ice
setblock 142 103 285 minecraft:snow_block
setblock 142 103 286 minecraft:packed_ice
setblock 142 103 290 minecraft:snow_block
fill 142 103 291 142 105 291 minecraft:packed_ice
setblock 142 103 295 minecraft:snow_block
fill 142 103 296 142 104 296 minecraft:packed_ice
setblock 142 103 314 minecraft:packed_ice
setblock 142 103 315 minecraft:snow_block
fill 142 103 316 142 106 316 minecraft:packed_ice
setblock 143 103 290 minecraft:packed_ice
setblock 144 103 277 minecraft:packed_ice
setblock 145 103 277 minecraft:snow_block
setblock 146 103 276 minecraft:snow_block
fill 146 103 277 146 106 277 minecraft:packed_ice
fill 146 103 283 149 103 283 minecraft:blue_ice
setblock 146 103 315 minecraft:packed_ice
setblock 146 103 316 minecraft:snow_block
fill 147 103 276 147 106 276 minecraft:packed_ice
setblock 147 103 314 minecraft:packed_ice
setblock 147 103 315 minecraft:snow_block
fill 147 103 316 147 106 316 minecraft:packed_ice
setblock 148 103 278 minecraft:packed_ice
setblock 148 103 314 minecraft:snow_block
fill 148 103 315 148 106 315 minecraft:packed_ice
setblock 149 103 278 minecraft:snow_block
setblock 149 103 313 minecraft:snow_block
fill 149 103 314 149 106 314 minecraft:packed_ice
setblock 150 103 277 minecraft:snow_block
fill 150 103 278 150 106 278 minecraft:packed_ice
fill 150 103 313 150 104 313 minecraft:packed_ice
setblock 151 103 276 minecraft:snow_block
fill 151 103 277 151 106 277 minecraft:packed_ice
setblock 151 103 316 minecraft:snow_block
fill 152 103 276 152 106 276 minecraft:packed_ice
setblock 152 103 315 minecraft:snow_block
fill 152 103 316 152 106 316 minecraft:packed_ice
setblock 153 103 314 minecraft:snow_block
fill 153 103 315 153 106 315 minecraft:packed_ice
setblock 154 103 313 minecraft:snow_block
fill 154 103 314 154 106 314 minecraft:packed_ice
setblock 155 103 277 minecraft:snow_block
setblock 155 103 313 minecraft:packed_ice
setblock 156 103 276 minecraft:snow_block
setblock 156 103 277 minecraft:packed_ice
fill 156 103 309 156 105 309 minecraft:packed_ice
setblock 156 103 316 minecraft:snow_block
fill 156 103 317 156 111 317 minecraft:packed_ice
fill 157 103 276 157 106 276 minecraft:packed_ice
fill 157 103 305 157 105 305 minecraft:packed_ice
fill 157 103 310 157 105 310 minecraft:packed_ice
setblock 157 103 315 minecraft:snow_block
fill 157 103 316 157 106 316 minecraft:packed_ice
setblock 158 103 314 minecraft:snow_block
fill 158 103 315 161 103 315 minecraft:packed_ice
fill 159 103 304 159 105 304 minecraft:packed_ice
fill 159 103 311 160 105 311 minecraft:packed_ice
setblock 159 103 314 minecraft:packed_ice
setblock 161 103 316 minecraft:snow_block
fill 162 103 310 162 105 310 minecraft:packed_ice
setblock 162 103 315 minecraft:snow_block
fill 162 103 316 165 103 316 minecraft:packed_ice
fill 163 103 315 166 103 315 minecraft:packed_ice
fill 165 103 314 167 103 314 minecraft:packed_ice
setblock 166 103 276 minecraft:snow_block
setblock 166 103 316 minecraft:snow_block
fill 167 103 276 167 106 276 minecraft:packed_ice
setblock 167 103 315 minecraft:snow_block
fill 167 103 316 167 106 316 minecraft:packed_ice
setblock 168 103 314 minecraft:snow_block
fill 168 103 315 168 106 315 minecraft:packed_ice
fill 169 103 314 169 105 314 minecraft:packed_ice
setblock 171 103 276 minecraft:snow_block
fill 171 103 280 171 104 280 minecraft:packed_ice
setblock 171 103 316 minecraft:snow_block
fill 172 103 276 172 106 276 minecraft:packed_ice
fill 172 103 279 172 104 279 minecraft:packed_ice
fill 172 103 281 172 104 281 minecraft:packed_ice
setblock 172 103 315 minecraft:snow_block
fill 172 103 316 172 106 316 minecraft:packed_ice
fill 173 103 280 173 104 280 minecraft:packed_ice
setblock 173 103 314 minecraft:snow_block
fill 173 103 315 173 105 315 minecraft:packed_ice
setblock 174 103 314 minecraft:packed_ice
setblock 176 103 276 minecraft:snow_block
setblock 176 103 316 minecraft:snow_block
fill 177 103 316 177 104 316 minecraft:packed_ice
setblock 180 103 292 minecraft:snow_block
setblock 180 103 293 minecraft:packed_ice
setblock 181 103 291 minecraft:snow_block
fill 181 103 292 181 105 292 minecraft:packed_ice
setblock 181 103 296 minecraft:snow_block
setblock 182 103 286 minecraft:packed_ice
setblock 182 103 290 minecraft:snow_block
fill 182 103 291 182 106 291 minecraft:packed_ice
setblock 182 103 295 minecraft:snow_block
fill 182 103 296 182 106 296 minecraft:packed_ice
fill 141 104 288 141 114 288 minecraft:packed_ice
fill 141 104 299 141 114 299 minecraft:packed_ice
setblock 142 104 278 minecraft:packed_ice
setblock 142 104 279 minecraft:snow_block
setblock 142 104 289 minecraft:snow_block
fill 142 104 290 142 105 290 minecraft:packed_ice
setblock 142 104 294 minecraft:snow_block
fill 142 104 295 142 106 295 minecraft:packed_ice
setblock 142 104 314 minecraft:snow_block
fill 142 104 315 142 107 315 minecraft:packed_ice
setblock 144 104 277 minecraft:snow_block
setblock 145 104 276 minecraft:snow_block
fill 145 104 277 145 107 277 minecraft:packed_ice
setblock 145 104 316 minecraft:snow_block
fill 146 104 276 146 107 276 minecraft:packed_ice
setblock 146 104 283 minecraft:blue_ice
fill 146 104 294 146 109 294 minecraft:snow_block
setblock 146 104 315 minecraft:snow_block
fill 146 104 316 146 107 316 minecraft:packed_ice
setblock 147 104 314 minecraft:snow_block
fill 147 104 315 147 107 315 minecraft:packed_ice
setblock 148 104 278 minecraft:snow_block
fill 148 104 314 148 107 314 minecraft:packed_ice
setblock 149 104 277 minecraft:snow_block
fill 149 104 278 149 107 278 minecraft:packed_ice
setblock 150 104 276 minecraft:snow_block
fill 150 104 277 150 107 277 minecraft:packed_ice
setblock 150 104 316 minecraft:snow_block
fill 151 104 276 151 107 276 minecraft:packed_ice
setblock 151 104 315 minecraft:snow_block
fill 151 104 316 151 107 316 minecraft:packed_ice
setblock 152 104 314 minecraft:snow_block
fill 152 104 315 152 107 315 minecraft:packed_ice
setblock 153 104 313 minecraft:snow_block
fill 153 104 314 153 107 314 minecraft:packed_ice
setblock 154 104 277 minecraft:snow_block
setblock 155 104 276 minecraft:snow_block
setblock 155 104 277 minecraft:packed_ice
setblock 155 104 316 minecraft:snow_block
fill 155 104 317 155 115 317 minecraft:packed_ice
fill 156 104 276 156 107 276 minecraft:packed_ice
fill 156 104 306 156 105 306 minecraft:packed_ice
fill 156 104 310 156 105 310 minecraft:packed_ice
setblock 156 104 315 minecraft:snow_block
fill 156 104 316 156 107 316 minecraft:packed_ice
fill 157 104 311 158 105 311 minecraft:packed_ice
setblock 157 104 314 minecraft:snow_block
fill 157 104 315 160 104 315 minecraft:packed_ice
fill 158 104 304 158 105 304 minecraft:packed_ice
setblock 160 104 316 minecraft:snow_block
fill 161 104 311 161 105 311 minecraft:packed_ice
setblock 161 104 315 minecraft:snow_block
fill 161 104 316 164 104 316 minecraft:packed_ice
fill 162 104 305 162 105 305 minecraft:packed_ice
fill 162 104 315 165 104 315 minecraft:packed_ice
fill 163 104 306 163 105 309 minecraft:packed_ice
setblock 165 104 316 minecraft:snow_block
fill 166 104 276 166 107 276 minecraft:packed_ice
setblock 166 104 314 minecraft:packed_ice
setblock 166 104 315 minecraft:snow_block
fill 166 104 316 166 107 316 minecraft:packed_ice
setblock 167 104 314 minecraft:snow_block
fill 167 104 315 167 107 315 minecraft:packed_ice
fill 168 104 314 168 105 314 minecraft:packed_ice
setblock 170 104 276 minecraft:snow_block
setblock 170 104 316 minecraft:snow_block
fill 171 104 276 171 107 276 minecraft:packed_ice
setblock 171 104 315 minecraft:snow_block
fill 171 104 316 171 107 316 minecraft:packed_ice
fill 172 104 275 172 110 275 minecraft:packed_ice
setblock 172 104 314 minecraft:snow_block
fill 172 104 315 172 106 315 minecraft:packed_ice
setblock 173 104 275 minecraft:white_concrete
fill 174 104 275 174 114 275 minecraft:packed_ice
setblock 175 104 276 minecraft:snow_block
setblock 175 104 316 minecraft:snow_block
setblock 176 104 276 minecraft:packed_ice
fill 176 104 316 176 105 316 minecraft:packed_ice
fill 179 104 279 179 108 279 minecraft:packed_ice
setblock 181 104 290 minecraft:snow_block
fill 181 104 291 181 105 291 minecraft:packed_ice
setblock 181 104 295 minecraft:snow_block
setblock 181 104 296 minecraft:packed_ice
setblock 182 104 289 minecraft:snow_block
fill 182 104 290 182 107 290 minecraft:packed_ice
setblock 182 104 294 minecraft:snow_block
fill 182 104 295 182 107 295 minecraft:packed_ice
fill 183 104 302 183 114 303 minecraft:packed_ice
setblock 183 104 304 minecraft:white_concrete
fill 183 104 305 183 115 305 minecraft:packed_ice
setblock 142 105 278 minecraft:snow_block
fill 142 105 279 142 107 280 minecraft:packed_ice
setblock 142 105 283 minecraft:blue_ice
setblock 142 105 289 minecraft:packed_ice
setblock 142 105 293 minecraft:snow_block
fill 142 105 294 142 107 294 minecraft:packed_ice
fill 142 105 314 142 106 314 minecraft:packed_ice
setblock 143 105 277 minecraft:snow_block
setblock 144 105 276 minecraft:snow_block
fill 144 105 277 144 108 277 minecraft:packed_ice
setblock 144 105 316 minecraft:snow_block
fill 145 105 276 145 108 276 minecraft:packed_ice
setblock 145 105 315 minecraft:snow_block
fill 145 105 316 145 108 316 minecraft:packed_ice
fill 146 105 315 146 108 315 minecraft:packed_ice
setblock 147 105 278 minecraft:snow_block
fill 147 105 314 147 108 314 minecraft:packed_ice
setblock 148 105 277 minecraft:snow_block
fill 148 105 278 148 108 278 minecraft:packed_ice
setblock 149 105 276 minecraft:snow_block
fill 149 105 277 149 108 277 minecraft:packed_ice
setblock 149 105 316 minecraft:snow_block
fill 150 105 276 150 108 276 minecraft:packed_ice
setblock 150 105 315 minecraft:snow_block
fill 150 105 316 150 108 316 minecraft:packed_ice
setblock 151 105 314 minecraft:snow_block
fill 151 105 315 151 108 315 minecraft:packed_ice
fill 152 105 314 152 107 314 minecraft:packed_ice
setblock 153 105 277 minecraft:snow_block
setblock 154 105 276 minecraft:snow_block
fill 154 105 277 154 107 277 minecraft:packed_ice
setblock 154 105 316 minecraft:snow_block
fill 155 105 276 155 108 276 minecraft:packed_ice
fill 155 105 306 155 105 309 minecraft:packed_ice
setblock 155 105 315 minecraft:snow_block
fill 155 105 316 155 108 316 minecraft:packed_ice
setblock 156 105 305 minecraft:packed_ice
setblock 156 105 314 minecraft:snow_block
fill 156 105 315 159 105 315 minecraft:packed_ice
setblock 157 105 304 minecraft:packed_ice
fill 158 105 312 160 105 312 minecraft:packed_ice
setblock 159 105 303 minecraft:packed_ice
setblock 159 105 316 minecraft:snow_block
setblock 160 105 315 minecraft:snow_block
fill 160 105 316 163 105 316 minecraft:packed_ice
fill 161 105 315 164 105 315 minecraft:packed_ice
setblock 162 105 311 minecraft:packed_ice
setblock 163 105 305 minecraft:packed_ice
setblock 163 105 310 minecraft:packed_ice
setblock 164 105 316 minecraft:snow_block
fill 165 105 276 165 108 276 minecraft:packed_ice
setblock 165 105 315 minecraft:snow_block
fill 165 105 316 165 108 316 minecraft:packed_ice
fill 166 105 315 166 108 315 minecraft:packed_ice
setblock 167 105 314 minecraft:packed_ice
setblock 169 105 276 minecraft:snow_block
setblock 169 105 316 minecraft:snow_block
fill 170 105 276 170 108 276 minecraft:packed_ice
setblock 170 105 315 minecraft:snow_block
fill 170 105 316 170 108 316 minecraft:packed_ice
setblock 171 105 314 minecraft:snow_block
fill 171 105 315 171 107 315 minecraft:packed_ice
fill 173 105 275 173 114 275 minecraft:packed_ice
setblock 174 105 276 minecraft:snow_block
fill 174 105 293 174 106 295 minecraft:snow_block
setblock 174 105 316 minecraft:snow_block
fill 175 105 276 175 106 276 minecraft:packed_ice
fill 175 105 293 175 106 294 minecraft:snow_block
fill 175 105 316 175 106 316 minecraft:packed_ice
setblock 181 105 294 minecraft:snow_block
fill 181 105 295 181 106 295 minecraft:packed_ice
setblock 182 105 288 minecraft:snow_block
fill 182 105 289 182 107 289 minecraft:packed_ice
setblock 182 105 293 minecraft:snow_block
fill 182 105 294 182 108 294 minecraft:packed_ice
setblock 182 105 298 minecraft:snow_block
fill 183 105 304 183 114 304 minecraft:packed_ice
setblock 142 106 277 minecraft:snow_block
fill 142 106 278 143 108 278 minecraft:packed_ice
setblock 142 106 292 minecraft:snow_block
setblock 142 106 293 minecraft:packed_ice
setblock 143 106 276 minecraft:snow_block
fill 143 106 277 143 109 277 minecraft:packed_ice
setblock 143 106 316 minecraft:snow_block
fill 144 106 276 144 109 276 minecraft:packed_ice
setblock 144 106 278 minecraft:light[level=12]
setblock 144 106 285 minecraft:light[level=12]
setblock 144 106 292 minecraft:light[level=12]
setblock 144 106 299 minecraft:light[level=12]
setblock 144 106 306 minecraft:light[level=12]
setblock 144 106 313 minecraft:light[level=12]
setblock 144 106 315 minecraft:snow_block
fill 144 106 316 144 109 316 minecraft:packed_ice
fill 145 106 315 145 109 315 minecraft:packed_ice
setblock 147 106 277 minecraft:snow_block
fill 147 106 278 147 109 278 minecraft:packed_ice
setblock 148 106 276 minecraft:snow_block
fill 148 106 277 148 109 277 minecraft:packed_ice
fill 148 106 279 148 107 279 minecraft:blue_ice
setblock 148 106 316 minecraft:snow_block
fill 149 106 276 149 109 276 minecraft:packed_ice
setblock 149 106 315 minecraft:snow_block
fill 149 106 316 149 109 316 minecraft:packed_ice
setblock 150 106 314 minecraft:snow_block
fill 150 106 315 150 109 315 minecraft:packed_ice
fill 150 106 317 150 114 317 minecraft:packed_ice
setblock 151 106 278 minecraft:light[level=12]
setblock 151 106 285 minecraft:light[level=12]
setblock 151 106 292 minecraft:light[level=12]
setblock 151 106 299 minecraft:light[level=12]
setblock 151 106 306 minecraft:light[level=12]
setblock 151 106 313 minecraft:light[level=12]
fill 151 106 314 151 108 314 minecraft:packed_ice
setblock 151 106 317 minecraft:white_concrete
setblock 152 106 277 minecraft:snow_block
fill 152 106 317 152 111 317 minecraft:packed_ice
setblock 153 106 276 minecraft:snow_block
fill 153 106 277 153 109 277 minecraft:packed_ice
setblock 153 106 316 minecraft:snow_block
fill 154 106 276 154 109 276 minecraft:packed_ice
setblock 154 106 315 minecraft:snow_block
fill 154 106 316 154 109 316 minecraft:packed_ice
fill 155 106 275 157 114 275 minecraft:packed_ice
fill 155 106 315 158 106 315 minecraft:packed_ice
setblock 158 106 275 minecraft:white_concrete
setblock 158 106 278 minecraft:light[level=12]
setblock 158 106 285 minecraft:light[level=12]
setblock 158 106 292 minecraft:light[level=12]
setblock 158 106 299 minecraft:light[level=12]
setblock 158 106 306 minecraft:light[level=12]
setblock 158 106 313 minecraft:light[level=12]
setblock 158 106 316 minecraft:snow_block
fill 159 106 307 160 107 308 minecraft:blue_ice
setblock 159 106 315 minecraft:snow_block
fill 159 106 316 162 106 316 minecraft:packed_ice
fill 162 106 315 163 106 315 minecraft:packed_ice
setblock 163 106 316 minecraft:snow_block
setblock 164 106 315 minecraft:snow_block
fill 164 106 316 164 109 316 minecraft:packed_ice
setblock 165 106 278 minecraft:light[level=12]
setblock 165 106 285 minecraft:light[level=12]
setblock 165 106 292 minecraft:light[level=12]
setblock 165 106 299 minecraft:light[level=12]
setblock 165 106 306 minecraft:light[level=12]
setblock 165 106 313 minecraft:light[level=12]
fill 165 106 315 165 109 315 minecraft:packed_ice
setblock 168 106 276 minecraft:snow_block
setblock 168 106 316 minecraft:snow_block
fill 169 106 276 169 109 276 minecraft:packed_ice
setblock 169 106 315 minecraft:snow_block
fill 169 106 316 169 109 316 minecraft:packed_ice
fill 170 106 315 170 108 315 minecraft:packed_ice
setblock 172 106 278 minecraft:light[level=12]
setblock 172 106 285 minecraft:light[level=12]
setblock 172 106 292 minecraft:light[level=12]
setblock 172 106 299 minecraft:light[level=12]
setblock 172 106 306 minecraft:light[level=12]
setblock 172 106 313 minecraft:light[level=12]
setblock 173 106 276 minecraft:snow_block
setblock 173 106 316 minecraft:snow_block
fill 174 106 276 174 109 276 minecraft:packed_ice
fill 174 106 316 174 107 316 minecraft:packed_ice
fill 178 106 279 178 108 279 minecraft:packed_ice
fill 179 106 278 179 108 278 minecraft:packed_ice
fill 179 106 280 179 108 280 minecraft:packed_ice
setblock 179 106 285 minecraft:light[level=12]
setblock 179 106 292 minecraft:light[level=12]
fill 179 106 294 179 116 294 minecraft:packed_ice
setblock 179 106 299 minecraft:light[level=12]
setblock 179 106 313 minecraft:light[level=12]
fill 180 106 279 180 108 279 minecraft:packed_ice
setblock 181 106 293 minecraft:snow_block
setblock 181 106 294 minecraft:packed_ice
fill 181 106 311 181 109 311 minecraft:blue_ice
setblock 182 106 276 minecraft:packed_ice
setblock 182 106 277 minecraft:snow_block
setblock 182 106 292 minecraft:snow_block
fill 182 106 293 182 109 293 minecraft:packed_ice
setblock 182 106 297 minecraft:snow_block
fill 182 106 298 182 109 298 minecraft:packed_ice
setblock 142 107 276 minecraft:snow_block
fill 142 107 277 142 110 277 minecraft:packed_ice
setblock 142 107 281 minecraft:snow_block
setblock 142 107 316 minecraft:snow_block
fill 143 107 276 143 110 276 minecraft:packed_ice
setblock 143 107 279 minecraft:packed_ice
fill 143 107 316 143 110 316 minecraft:packed_ice
fill 144 107 315 144 110 315 minecraft:packed_ice
fill 145 107 294 145 109 294 minecraft:snow_block
setblock 146 107 277 minecraft:snow_block
fill 146 107 278 146 110 278 minecraft:packed_ice
fill 146 107 293 146 109 293 minecraft:snow_block
fill 146 107 295 146 109 295 minecraft:snow_block
setblock 147 107 276 minecraft:snow_block
fill 147 107 277 147 110 277 minecraft:packed_ice
fill 147 107 294 147 109 294 minecraft:snow_block
setblock 147 107 316 minecraft:snow_block
fill 148 107 276 148 110 276 minecraft:packed_ice
fill 148 107 280 148 108 281 minecraft:blue_ice
setblock 148 107 315 minecraft:snow_block
fill 148 107 316 148 110 316 minecraft:packed_ice
setblock 149 107 314 minecraft:snow_block
fill 149 107 315 149 110 315 minecraft:packed_ice
setblock 150 107 278 minecraft:snow_block
fill 150 107 314 150 110 314 minecraft:packed_ice
fill 151 107 275 151 110 275 minecraft:packed_ice
setblock 151 107 277 minecraft:snow_block
fill 151 107 317 151 114 317 minecraft:packed_ice
setblock 152 107 275 minecraft:light_blue_concrete
setblock 152 107 276 minecraft:snow_block
fill 152 107 277 152 110 277 minecraft:packed_ice
setblock 152 107 316 minecraft:snow_block
fill 153 107 276 153 110 276 minecraft:packed_ice
setblock 153 107 315 minecraft:snow_block
fill 153 107 316 153 110 316 minecraft:packed_ice
fill 154 107 315 157 107 315 minecraft:packed_ice
setblock 157 107 276 minecraft:snow_block
setblock 157 107 316 minecraft:snow_block
fill 158 107 275 158 114 275 minecraft:packed_ice
fill 158 107 316 161 107 316 minecraft:packed_ice
setblock 161 107 275 minecraft:white_concrete
setblock 162 107 316 minecraft:snow_block
fill 163 107 316 163 110 316 minecraft:packed_ice
fill 164 107 276 164 109 276 minecraft:packed_ice
fill 164 107 315 164 110 315 minecraft:packed_ice
setblock 167 107 276 minecraft:snow_block
setblock 167 107 316 minecraft:snow_block
fill 168 107 276 168 110 276 minecraft:packed_ice
setblock 168 107 315 minecraft:snow_block
fill 168 107 316 168 110 316 minecraft:packed_ice
fill 169 107 315 169 109 315 minecraft:packed_ice
setblock 172 107 276 minecraft:snow_block
setblock 172 107 316 minecraft:snow_block
fill 173 107 276 173 110 276 minecraft:packed_ice
fill 173 107 316 173 108 316 minecraft:packed_ice
fill 178 107 278 178 108 278 minecraft:packed_ice
fill 178 107 280 178 108 280 minecraft:packed_ice
fill 180 107 278 180 108 278 minecraft:packed_ice
fill 180 107 280 180 108 280 minecraft:packed_ice
fill 180 107 310 180 108 312 minecraft:blue_ice
setblock 181 107 276 minecraft:packed_ice
fill 181 107 310 182 108 310 minecraft:blue_ice
fill 181 107 312 182 108 312 minecraft:blue_ice
setblock 182 107 276 minecraft:snow_block
fill 182 107 277 182 108 279 minecraft:packed_ice
setblock 182 107 291 minecraft:snow_block
fill 182 107 292 182 110 292 minecraft:packed_ice
setblock 182 107 296 minecraft:snow_block
fill 182 107 297 182 110 297 minecraft:packed_ice
fill 182 107 311 182 108 311 minecraft:blue_ice
fill 141 108 286 141 114 286 minecraft:packed_ice
setblock 141 108 287 minecraft:white_concrete
fill 142 108 276 142 111 276 minecraft:packed_ice
setblock 142 108 279 minecraft:packed_ice
setblock 142 108 280 minecraft:snow_block
fill 142 108 281 142 110 282 minecraft:packed_ice
setblock 142 108 314 minecraft:packed_ice
setblock 142 108 315 minecraft:snow_block
fill 142 108 316 142 111 316 minecraft:packed_ice
setblock 143 108 279 minecraft:snow_block
fill 143 108 280 143 111 280 minecraft:packed_ice
setblock 144 108 278 minecraft:snow_block
setblock 144 108 286 minecraft:light[level=15]
setblock 144 108 294 minecraft:light[level=15]
setblock 144 108 302 minecraft:light[level=15]
setblock 144 108 310 minecraft:light[level=15]
setblock 145 108 277 minecraft:snow_block
fill 145 108 278 145 111 278 minecraft:packed_ice
fill 145 108 293 145 109 293 minecraft:snow_block
fill 145 108 295 145 109 295 minecraft:snow_block
setblock 146 108 276 minecraft:snow_block
fill 146 108 277 146 111 277 minecraft:packed_ice
setblock 146 108 316 minecraft:snow_block
fill 147 108 276 147 111 276 minecraft:packed_ice
fill 147 108 293 147 109 293 minecraft:snow_block
setblock 147 108 315 minecraft:snow_block
fill 147 108 316 147 111 316 minecraft:packed_ice
setblock 148 108 282 minecraft:blue_ice
setblock 148 108 314 minecraft:snow_block
fill 148 108 315 148 111 315 minecraft:packed_ice
setblock 149 108 278 minecraft:snow_block
fill 149 108 314 149 111 314 minecraft:packed_ice
setblock 150 108 277 minecraft:snow_block
fill 150 108 278 150 111 278 minecraft:packed_ice
setblock 151 108 276 minecraft:snow_block
fill 151 108 277 151 111 277 minecraft:packed_ice
setblock 151 108 316 minecraft:snow_block
fill 152 108 275 152 111 276 minecraft:packed_ice
setblock 152 108 278 minecraft:light[level=15]
setblock 152 108 286 minecraft:light[level=15]
setblock 152 108 294 minecraft:light[level=15]
setblock 152 108 302 minecraft:light[level=15]
setblock 152 108 310 minecraft:light[level=15]
setblock 152 108 315 minecraft:snow_block
fill 152 108 316 152 111 316 minecraft:packed_ice
fill 153 108 315 155 108 315 minecraft:packed_ice
setblock 156 108 276 minecraft:snow_block
setblock 156 108 316 minecraft:snow_block
fill 157 108 316 160 108 316 minecraft:packed_ice
fill 159 108 307 159 108 308 minecraft:blue_ice
setblock 160 108 278 minecraft:light[level=15]
setblock 160 108 286 minecraft:light[level=15]
setblock 160 108 294 minecraft:light[level=15]
setblock 160 108 302 minecraft:light[level=15]
setblock 160 108 308 minecraft:blue_ice
setblock 160 108 310 minecraft:light[level=15]
fill 161 108 275 161 111 275 minecraft:packed_ice
setblock 161 108 316 minecraft:snow_block
fill 162 108 316 162 111 316 minecraft:packed_ice
fill 163 108 276 163 110 276 minecraft:packed_ice
setblock 166 108 276 minecraft:snow_block
setblock 166 108 316 minecraft:snow_block
fill 167 108 276 167 111 276 minecraft:packed_ice
setblock 167 108 315 minecraft:snow_block
fill 167 108 316 167 111 316 minecraft:packed_ice
setblock 168 108 278 minecraft:light[level=15]
setblock 168 108 286 minecraft:light[level=15]
setblock 168 108 294 minecraft:light[level=15]
setblock 168 108 302 minecraft:light[level=15]
setblock 168 108 310 minecraft:light[level=15]
fill 168 108 315 168 110 315 minecraft:packed_ice
setblock 171 108 276 minecraft:snow_block
setblock 171 108 316 minecraft:snow_block
fill 172 108 276 172 111 276 minecraft:packed_ice
fill 172 108 316 172 110 316 minecraft:packed_ice
setblock 176 108 278 minecraft:light[level=15]
setblock 176 108 286 minecraft:light[level=15]
setblock 176 108 294 minecraft:light[level=15]
setblock 176 108 302 minecraft:light[level=15]
setblock 176 108 310 minecraft:light[level=15]
fill 178 108 311 179 109 311 minecraft:blue_ice
setblock 179 108 310 minecraft:blue_ice
setblock 179 108 312 minecraft:blue_ice
setblock 180 108 276 minecraft:packed_ice
setblock 180 108 317 minecraft:light_blue_concrete
setblock 181 108 276 minecraft:snow_block
fill 181 108 317 183 112 317 minecraft:packed_ice
fill 182 108 276 182 111 276 minecraft:packed_ice
setblock 182 108 280 minecraft:snow_block
fill 182 108 281 182 111 281 minecraft:packed_ice
setblock 182 108 290 minecraft:snow_block
fill 182 108 291 182 111 291 minecraft:packed_ice
setblock 182 108 295 minecraft:snow_block
fill 182 108 296 182 111 296 minecraft:packed_ice
setblock 182 108 299 minecraft:packed_ice
fill 141 109 287 141 114 287 minecraft:packed_ice
setblock 141 109 315 minecraft:light_blue_concrete
fill 141 109 316 141 114 317 minecraft:packed_ice
setblock 142 109 278 minecraft:packed_ice
setblock 142 109 279 minecraft:snow_block
fill 142 109 280 142 112 280 minecraft:packed_ice
setblock 142 109 283 minecraft:packed_ice
fill 142 109 295 142 110 297 minecraft:packed_ice
setblock 142 109 314 minecraft:snow_block
fill 142 109 315 143 111 315 minecraft:packed_ice
setblock 143 109 278 minecraft:snow_block
fill 143 109 279 144 111 279 minecraft:packed_ice
fill 143 109 281 143 110 281 minecraft:packed_ice
setblock 144 109 277 minecraft:snow_block
fill 144 109 278 144 112 278 minecraft:packed_ice
setblock 144 109 294 minecraft:snow_block
setblock 145 109 276 minecraft:snow_block
fill 145 109 277 145 112 277 minecraft:packed_ice
setblock 145 109 316 minecraft:snow_block
fill 146 109 276 146 112 276 minecraft:packed_ice
setblock 146 109 292 minecraft:snow_block
setblock 146 109 296 minecraft:snow_block
setblock 146 109 315 minecraft:snow_block
fill 146 109 316 146 112 316 minecraft:packed_ice
setblock 147 109 314 minecraft:snow_block
fill 147 109 315 147 112 315 minecraft:packed_ice
setblock 148 109 278 minecraft:snow_block
fill 148 109 314 148 112 314 minecraft:packed_ice
setblock 149 109 277 minecraft:snow_block
fill 149 109 278 149 112 278 minecraft:packed_ice
setblock 150 109 276 minecraft:snow_block
fill 150 109 277 150 112 277 minecraft:packed_ice
setblock 150 109 316 minecraft:snow_block
fill 151 109 276 151 112 276 minecraft:packed_ice
setblock 151 109 315 minecraft:snow_block
fill 151 109 316 151 112 316 minecraft:packed_ice
fill 152 109 315 154 110 315 minecraft:packed_ice
setblock 155 109 276 minecraft:snow_block
setblock 155 109 316 minecraft:snow_block
fill 156 109 276 156 112 276 minecraft:packed_ice
fill 156 109 316 159 109 316 minecraft:packed_ice
setblock 159 109 308 minecraft:blue_ice
setblock 160 109 316 minecraft:snow_block
fill 161 109 316 161 112 316 minecraft:packed_ice
fill 162 109 276 162 111 276 minecraft:packed_ice
setblock 165 109 276 minecraft:snow_block
setblock 165 109 316 minecraft:snow_block
fill 166 109 276 166 112 276 minecraft:packed_ice
setblock 166 109 315 minecraft:snow_block
fill 166 109 316 166 112 316 minecraft:packed_ice
fill 167 109 277 168 109 277 minecraft:packed_ice
fill 167 109 315 167 112 315 minecraft:packed_ice
setblock 169 109 277 minecraft:snow_block
setblock 170 109 276 minecraft:snow_block
fill 170 109 277 170 112 277 minecraft:packed_ice
setblock 170 109 316 minecraft:snow_block
fill 171 109 276 171 112 276 minecraft:packed_ice
fill 171 109 316 171 112 316 minecraft:packed_ice
setblock 175 109 276 minecraft:snow_block
fill 177 109 311 177 110 311 minecraft:blue_ice
setblock 179 109 276 minecraft:packed_ice
setblock 180 109 276 minecraft:snow_block
setblock 180 109 311 minecraft:blue_ice
fill 180 109 317 180 110 317 minecraft:packed_ice
fill 181 109 276 181 112 276 minecraft:packed_ice
fill 182 109 277 182 109 278 minecraft:packed_ice
setblock 182 109 279 minecraft:snow_block
fill 182 109 280 182 112 280 minecraft:packed_ice
fill 182 109 282 182 109 283 minecraft:packed_ice
fill 182 109 290 182 112 290 minecraft:packed_ice
setblock 182 109 294 minecraft:snow_block
fill 182 109 295 182 112 295 minecraft:packed_ice
setblock 182 109 299 minecraft:snow_block
fill 182 109 300 182 112 300 minecraft:packed_ice
fill 141 110 315 141 116 315 minecraft:packed_ice
setblock 142 110 278 minecraft:snow_block
fill 142 110 279 142 113 279 minecraft:packed_ice
setblock 142 110 283 minecraft:snow_block
fill 142 110 284 142 113 284 minecraft:packed_ice
fill 142 110 294 142 113 294 minecraft:packed_ice
setblock 142 110 298 minecraft:snow_block
fill 142 110 299 142 112 300 minecraft:packed_ice
fill 142 110 314 142 113 314 minecraft:packed_ice
setblock 143 110 277 minecraft:snow_block
fill 143 110 278 143 113 278 minecraft:packed_ice
setblock 143 110 282 minecraft:snow_block
setblock 144 110 276 minecraft:snow_block
fill 144 110 277 144 113 277 minecraft:packed_ice
setblock 144 110 280 minecraft:packed_ice
setblock 144 110 316 minecraft:snow_block
fill 145 110 276 145 113 276 minecraft:packed_ice
setblock 145 110 315 minecraft:snow_block
fill 145 110 316 145 113 316 minecraft:packed_ice
fill 146 110 315 146 113 315 minecraft:packed_ice
setblock 147 110 278 minecraft:snow_block
fill 147 110 314 147 113 314 minecraft:packed_ice
setblock 148 110 277 minecraft:snow_block
fill 148 110 278 148 113 278 minecraft:packed_ice
setblock 149 110 276 minecraft:snow_block
fill 149 110 277 149 113 277 minecraft:packed_ice
setblock 149 110 316 minecraft:snow_block
fill 150 110 276 150 113 276 minecraft:packed_ice
setblock 150 110 315 minecraft:snow_block
fill 150 110 316 150 113 316 minecraft:packed_ice
fill 151 110 315 151 113 315 minecraft:packed_ice
setblock 153 110 277 minecraft:snow_block
setblock 154 110 276 minecraft:snow_block
setblock 154 110 316 minecraft:snow_block
fill 155 110 276 155 113 276 minecraft:packed_ice
fill 155 110 316 158 110 316 minecraft:packed_ice
setblock 159 110 316 minecraft:snow_block
fill 160 110 316 160 113 316 minecraft:packed_ice
fill 161 110 276 161 112 276 minecraft:packed_ice
setblock 164 110 276 minecraft:snow_block
setblock 164 110 316 minecraft:snow_block
fill 165 110 276 165 112 277 minecraft:packed_ice
setblock 165 110 315 minecraft:snow_block
fill 165 110 316 165 113 316 minecraft:packed_ice
fill 166 110 277 167 110 277 minecraft:packed_ice
fill 166 110 315 166 113 315 minecraft:packed_ice
setblock 168 110 277 minecraft:snow_block
setblock 169 110 276 minecraft:snow_block
fill 169 110 277 169 113 277 minecraft:packed_ice
setblock 169 110 316 minecraft:snow_block
fill 170 110 276 170 113 276 minecraft:packed_ice
fill 170 110 316 170 113 316 minecraft:packed_ice
fill 171 110 277 171 111 277 minecraft:packed_ice
setblock 174 110 276 minecraft:snow_block
fill 175 110 276 178 110 276 minecraft:packed_ice
setblock 179 110 276 minecraft:snow_block
fill 180 110 276 180 113 276 minecraft:packed_ice
fill 181 110 277 181 110 278 minecraft:packed_ice
setblock 181 110 279 minecraft:snow_block
fill 181 110 280 181 113 280 minecraft:packed_ice
setblock 182 110 277 minecraft:packed_ice
setblock 182 110 278 minecraft:snow_block
fill 182 110 279 182 113 279 minecraft:packed_ice
setblock 182 110 282 minecraft:packed_ice
setblock 182 110 283 minecraft:snow_block
fill 182 110 284 182 110 287 minecraft:packed_ice
setblock 182 110 288 minecraft:snow_block
fill 182 110 289 182 113 289 minecraft:packed_ice
setblock 182 110 293 minecraft:snow_block
fill 182 110 294 182 113 294 minecraft:packed_ice
setblock 182 110 298 minecraft:snow_block
fill 182 110 299 182 113 299 minecraft:packed_ice
fill 182 110 301 182 111 301 minecraft:packed_ice
setblock 141 111 282 minecraft:blue_ice
setblock 141 111 283 minecraft:light_blue_concrete
setblock 141 111 285 minecraft:blue_ice
fill 141 111 296 141 113 296 minecraft:blue_ice
setblock 141 111 301 minecraft:blue_ice
fill 141 111 303 141 111 304 minecraft:blue_ice
fill 141 111 305 141 112 306 minecraft:packed_ice
setblock 142 111 277 minecraft:snow_block
fill 142 111 278 142 114 278 minecraft:packed_ice
setblock 142 111 281 minecraft:packed_ice
setblock 142 111 282 minecraft:snow_block
fill 142 111 283 143 113 283 minecraft:packed_ice
fill 142 111 285 142 112 285 minecraft:packed_ice
fill 142 111 295 142 111 296 minecraft:packed_ice
setblock 142 111 297 minecraft:snow_block
fill 142 111 298 142 114 298 minecraft:packed_ice
setblock 142 111 301 minecraft:packed_ice
setblock 142 111 302 minecraft:snow_block
fill 142 111 313 142 114 313 minecraft:packed_ice
setblock 142 111 317 minecraft:blue_ice
fill 143 111 275 143 114 275 minecraft:packed_ice
setblock 143 111 276 minecraft:snow_block
fill 143 111 277 143 114 277 minecraft:packed_ice
setblock 143 111 281 minecraft:snow_block
fill 143 111 282 143 114 282 minecraft:packed_ice
fill 143 111 314 143 112 314 minecraft:packed_ice
setblock 143 111 316 minecraft:snow_block
setblock 144 111 275 minecraft:blue_ice
fill 144 111 276 144 114 276 minecraft:packed_ice
setblock 144 111 280 minecraft:snow_block
fill 144 111 281 144 114 281 minecraft:packed_ice
setblock 144 111 315 minecraft:snow_block
fill 144 111 316 144 114 316 minecraft:packed_ice
fill 145 111 275 145 114 275 minecraft:packed_ice
setblock 145 111 279 minecraft:snow_block
fill 145 111 315 145 114 315 minecraft:packed_ice
setblock 146 111 278 minecraft:snow_block
fill 146 111 279 147 113 279 minecraft:packed_ice
fill 146 111 314 146 114 314 minecraft:packed_ice
setblock 147 111 277 minecraft:snow_block
fill 147 111 278 147 114 278 minecraft:packed_ice
fill 148 111 275 148 114 275 minecraft:packed_ice
setblock 148 111 276 minecraft:snow_block
fill 148 111 277 148 114 277 minecraft:packed_ice
setblock 148 111 316 minecraft:snow_block
fill 149 111 275 149 112 275 minecraft:blue_ice
fill 149 111 276 149 114 276 minecraft:packed_ice
setblock 149 111 315 minecraft:snow_block
fill 149 111 316 149 114 316 minecraft:packed_ice
fill 150 111 275 150 114 275 minecraft:packed_ice
fill 150 111 315 150 114 315 minecraft:packed_ice
setblock 151 111 275 minecraft:blue_ice
setblock 152 111 277 minecraft:snow_block
fill 152 111 315 153 111 315 minecraft:packed_ice
setblock 153 111 276 minecraft:snow_block
fill 153 111 277 153 113 277 minecraft:packed_ice
setblock 153 111 316 minecraft:snow_block
fill 154 111 276 154 114 276 minecraft:packed_ice
fill 154 111 316 157 111 316 minecraft:packed_ice
setblock 157 111 276 minecraft:packed_ice
setblock 158 111 316 minecraft:snow_block
fill 159 111 275 160 111 275 minecraft:blue_ice
fill 159 111 276 160 113 276 minecraft:packed_ice
fill 159 111 316 159 114 316 minecraft:packed_ice
setblock 163 111 276 minecraft:snow_block
setblock 163 111 316 minecraft:snow_block
fill 164 111 276 164 113 277 minecraft:packed_ice
setblock 164 111 315 minecraft:snow_block
fill 164 111 316 164 114 316 minecraft:packed_ice
fill 165 111 315 165 114 315 minecraft:packed_ice
setblock 166 111 277 minecraft:packed_ice
setblock 167 111 277 minecraft:snow_block
setblock 168 111 276 minecraft:snow_block
fill 168 111 277 168 114 277 minecraft:packed_ice
setblock 168 111 316 minecraft:snow_block
fill 169 111 276 169 114 276 minecraft:packed_ice
fill 169 111 316 169 114 316 minecraft:packed_ice
setblock 172 111 275 minecraft:blue_ice
setblock 173 111 276 minecraft:snow_block
fill 174 111 276 177 111 276 minecraft:packed_ice
fill 175 111 317 175 114 317 minecraft:packed_ice
setblock 176 111 317 minecraft:blue_ice
fill 177 111 317 178 111 317 minecraft:packed_ice
setblock 178 111 276 minecraft:snow_block
fill 178 111 294 178 112 294 minecraft:packed_ice
fill 179 111 276 179 114 276 minecraft:packed_ice
fill 179 111 293 179 112 293 minecraft:packed_ice
fill 179 111 295 179 112 295 minecraft:packed_ice
setblock 180 111 275 minecraft:blue_ice
fill 180 111 277 181 111 277 minecraft:packed_ice
fill 180 111 280 180 114 280 minecraft:packed_ice
fill 180 111 294 180 112 294 minecraft:packed_ice
setblock 180 111 317 minecraft:blue_ice
setblock 181 111 278 minecraft:snow_block
fill 181 111 279 181 114 279 minecraft:packed_ice
fill 181 111 281 181 111 282 minecraft:packed_ice
fill 181 111 295 181 111 297 minecraft:packed_ice
setblock 181 111 298 minecraft:snow_block
setblock 182 111 275 minecraft:blue_ice
setblock 182 111 277 minecraft:snow_block
fill 182 111 278 182 114 278 minecraft:packed_ice
setblock 182 111 282 minecraft:snow_block
fill 182 111 283 182 111 286 minecraft:packed_ice
setblock 182 111 287 minecraft:snow_block
fill 182 111 288 182 114 288 minecraft:packed_ice
setblock 182 111 292 minecraft:snow_block
fill 182 111 293 182 114 293 minecraft:packed_ice
setblock 182 111 297 minecraft:snow_block
fill 182 111 298 182 114 298 minecraft:packed_ice
setblock 182 111 302 minecraft:snow_block
setblock 182 111 316 minecraft:packed_ice
fill 183 111 275 183 114 275 minecraft:packed_ice
setblock 183 111 281 minecraft:light_blue_concrete
setblock 183 111 285 minecraft:blue_ice
setblock 183 111 291 minecraft:blue_ice
setblock 183 111 295 minecraft:blue_ice
fill 183 111 314 183 111 315 minecraft:blue_ice
setblock 141 112 275 minecraft:blue_ice
fill 141 112 276 141 114 277 minecraft:packed_ice
setblock 141 112 279 minecraft:blue_ice
fill 141 112 282 141 114 283 minecraft:packed_ice
setblock 141 112 285 minecraft:packed_ice
setblock 141 112 292 minecraft:blue_ice
setblock 141 112 301 minecraft:packed_ice
fill 141 112 303 142 113 304 minecraft:packed_ice
fill 141 112 308 141 115 308 minecraft:packed_ice
setblock 141 112 309 minecraft:blue_ice
setblock 142 112 276 minecraft:snow_block
fill 142 112 277 142 115 277 minecraft:packed_ice
setblock 142 112 281 minecraft:snow_block
fill 142 112 282 142 115 282 minecraft:packed_ice
setblock 142 112 286 minecraft:snow_block
fill 142 112 287 142 115 287 minecraft:packed_ice
fill 142 112 293 142 114 293 minecraft:packed_ice
setblock 142 112 295 minecraft:packed_ice
setblock 142 112 296 minecraft:snow_block
fill 142 112 297 143 114 297 minecraft:packed_ice
setblock 142 112 301 minecraft:snow_block
fill 142 112 302 143 114 302 minecraft:packed_ice
setblock 142 112 305 minecraft:packed_ice
fill 142 112 312 142 115 312 minecraft:packed_ice
setblock 142 112 315 minecraft:packed_ice
setblock 142 112 316 minecraft:snow_block
fill 142 112 317 142 114 317 minecraft:packed_ice
fill 143 112 276 143 115 276 minecraft:packed_ice
setblock 143 112 279 minecraft:packed_ice
setblock 143 112 280 minecraft:snow_block
fill 143 112 281 143 115 281 minecraft:packed_ice
setblock 143 112 284 minecraft:packed_ice
fill 143 112 298 143 112 299 minecraft:packed_ice
setblock 143 112 300 minecraft:snow_block
fill 143 112 301 143 115 301 minecraft:packed_ice
setblock 143 112 315 minecraft:snow_block
fill 143 112 316 143 115 316 minecraft:packed_ice
fill 144 112 275 144 114 275 minecraft:packed_ice
setblock 144 112 279 minecraft:snow_block
fill 144 112 280 145 114 280 minecraft:packed_ice
fill 144 112 282 144 113 282 minecraft:packed_ice
setblock 144 112 285 minecraft:light[level=12]
setblock 144 112 292 minecraft:light[level=12]
setblock 144 112 299 minecraft:light[level=12]
setblock 144 112 306 minecraft:light[level=12]
setblock 144 112 313 minecraft:light[level=12]
fill 144 112 315 144 115 315 minecraft:packed_ice
setblock 145 112 278 minecraft:snow_block
fill 145 112 279 145 115 279 minecraft:packed_ice
fill 145 112 314 145 115 314 minecraft:packed_ice
setblock 146 112 277 minecraft:snow_block
fill 146 112 278 146 115 278 minecraft:packed_ice
setblock 147 112 276 minecraft:snow_block
fill 147 112 277 147 115 277 minecraft:packed_ice
setblock 147 112 316 minecraft:snow_block
fill 148 112 276 148 115 276 minecraft:packed_ice
setblock 148 112 279 minecraft:packed_ice
setblock 148 112 315 minecraft:snow_block
fill 148 112 316 148 115 316 minecraft:packed_ice
setblock 149 112 314 minecraft:snow_block
fill 149 112 315 149 115 315 minecraft:packed_ice
setblock 150 112 278 minecraft:snow_block
fill 151 112 275 152 114 275 minecraft:packed_ice
setblock 151 112 277 minecraft:snow_block
setblock 151 112 278 minecraft:light[level=12]
setblock 151 112 285 minecraft:light[level=12]
setblock 151 112 292 minecraft:light[level=12]
setblock 151 112 299 minecraft:light[level=12]
setblock 151 112 306 minecraft:light[level=12]
setblock 151 112 313 minecraft:light[level=12]
setblock 152 112 276 minecraft:snow_block
fill 152 112 277 152 114 277 minecraft:packed_ice
setblock 152 112 315 minecraft:packed_ice
setblock 152 112 316 minecraft:snow_block
setblock 152 112 317 minecraft:blue_ice
fill 153 112 276 153 115 276 minecraft:packed_ice
setblock 153 112 315 minecraft:snow_block
fill 153 112 316 156 112 316 minecraft:packed_ice
setblock 154 112 275 minecraft:blue_ice
setblock 156 112 317 minecraft:blue_ice
setblock 157 112 276 minecraft:snow_block
setblock 157 112 316 minecraft:snow_block
fill 158 112 276 158 115 276 minecraft:packed_ice
setblock 158 112 278 minecraft:light[level=12]
setblock 158 112 285 minecraft:light[level=12]
setblock 158 112 292 minecraft:light[level=12]
setblock 158 112 299 minecraft:light[level=12]
setblock 158 112 306 minecraft:light[level=12]
setblock 158 112 313 minecraft:light[level=12]
fill 158 112 316 158 115 316 minecraft:packed_ice
fill 159 112 275 160 114 275 minecraft:packed_ice
setblock 159 112 317 minecraft:white_concrete
setblock 161 112 275 minecraft:light_blue_concrete
setblock 162 112 276 minecraft:snow_block
fill 162 112 277 163 114 277 minecraft:packed_ice
setblock 162 112 316 minecraft:snow_block
fill 163 112 276 163 115 276 minecraft:packed_ice
setblock 163 112 315 minecraft:snow_block
fill 163 112 316 163 115 316 minecraft:packed_ice
fill 164 112 315 164 114 315 minecraft:packed_ice
setblock 165 112 278 minecraft:light[level=12]
setblock 165 112 285 minecraft:light[level=12]
setblock 165 112 292 minecraft:light[level=12]
setblock 165 112 299 minecraft:light[level=12]
setblock 165 112 306 minecraft:light[level=12]
setblock 165 112 313 minecraft:light[level=12]
setblock 166 112 275 minecraft:blue_ice
setblock 166 112 277 minecraft:snow_block
fill 167 112 275 167 114 275 minecraft:packed_ice
setblock 167 112 276 minecraft:snow_block
fill 167 112 277 167 115 277 minecraft:packed_ice
setblock 167 112 316 minecraft:snow_block
fill 168 112 276 168 115 276 minecraft:packed_ice
fill 168 112 316 168 115 316 minecraft:packed_ice
setblock 168 112 317 minecraft:light_blue_concrete
fill 169 112 317 171 112 317 minecraft:packed_ice
setblock 171 112 277 minecraft:snow_block
fill 172 112 275 172 114 275 minecraft:packed_ice
setblock 172 112 276 minecraft:snow_block
fill 172 112 277 172 114 277 minecraft:packed_ice
setblock 172 112 278 minecraft:light[level=12]
setblock 172 112 285 minecraft:light[level=12]
setblock 172 112 292 minecraft:light[level=12]
setblock 172 112 299 minecraft:light[level=12]
setblock 172 112 306 minecraft:light[level=12]
setblock 172 112 313 minecraft:light[level=12]
fill 173 112 276 176 112 276 minecraft:packed_ice
fill 175 112 275 176 114 275 minecraft:packed_ice
fill 176 112 317 177 114 317 minecraft:packed_ice
setblock 177 112 275 minecraft:blue_ice
setblock 177 112 276 minecraft:snow_block
fill 178 112 276 178 114 277 minecraft:packed_ice
setblock 178 112 317 minecraft:white_concrete
fill 179 112 277 180 112 277 minecraft:packed_ice
setblock 179 112 278 minecraft:light[level=12]
setblock 179 112 285 minecraft:light[level=12]
setblock 179 112 292 minecraft:light[level=12]
setblock 179 112 299 minecraft:light[level=12]
setblock 179 112 313 minecraft:light[level=12]
setblock 179 112 317 minecraft:blue_ice
fill 180 112 275 180 114 275 minecraft:packed_ice
fill 180 112 317 180 114 317 minecraft:packed_ice
setblock 181 112 277 minecraft:snow_block
fill 181 112 278 181 115 278 minecraft:packed_ice
setblock 181 112 281 minecraft:packed_ice
setblock 181 112 282 minecraft:snow_block
fill 181 112 283 182 112 285 minecraft:packed_ice
fill 181 112 295 181 112 296 minecraft:packed_ice
setblock 181 112 297 minecraft:snow_block
fill 181 112 298 181 113 300 minecraft:packed_ice
setblock 181 112 316 minecraft:packed_ice
fill 182 112 275 182 114 275 minecraft:packed_ice
setblock 182 112 276 minecraft:snow_block
fill 182 112 277 182 115 277 minecraft:packed_ice
setblock 182 112 281 minecraft:snow_block
fill 182 112 282 182 115 282 minecraft:packed_ice
setblock 182 112 286 minecraft:snow_block
fill 182 112 287 182 115 287 minecraft:packed_ice
setblock 182 112 291 minecraft:snow_block
fill 182 112 292 182 115 292 minecraft:packed_ice
setblock 182 112 296 minecraft:snow_block
fill 182 112 297 183 114 297 minecraft:packed_ice
setblock 182 112 301 minecraft:snow_block
fill 182 112 302 182 113 304 minecraft:packed_ice
fill 182 112 315 183 112 315 minecraft:packed_ice
setblock 182 112 316 minecraft:snow_block
setblock 183 112 276 minecraft:blue_ice
fill 183 112 278 183 112 279 minecraft:blue_ice
fill 183 112 281 183 114 281 minecraft:packed_ice
fill 183 112 285 183 114 285 minecraft:packed_ice
setblock 183 112 286 minecraft:blue_ice
fill 183 112 291 183 114 291 minecraft:packed_ice
fill 183 112 295 183 114 295 minecraft:packed_ice
setblock 183 112 298 minecraft:blue_ice
setblock 183 112 310 minecraft:blue_ice
fill 183 112 314 183 114 314 minecraft:packed_ice
fill 141 113 275 141 114 275 minecraft:packed_ice
fill 141 113 279 141 114 279 minecraft:packed_ice
setblock 141 113 285 minecraft:blue_ice
fill 141 113 289 142 113 289 minecraft:packed_ice
fill 141 113 290 141 113 291 minecraft:blue_ice
fill 141 113 292 141 114 292 minecraft:packed_ice
fill 141 113 297 141 113 298 minecraft:blue_ice
setblock 141 113 300 minecraft:white_concrete
setblock 141 113 301 minecraft:blue_ice
fill 141 113 305 141 114 305 minecraft:packed_ice
setblock 141 113 306 minecraft:blue_ice
fill 141 113 309 142 113 309 minecraft:packed_ice
setblock 141 113 310 minecraft:blue_ice
fill 141 113 312 141 113 313 minecraft:blue_ice
fill 142 113 276 142 116 276 minecraft:packed_ice
setblock 142 113 280 minecraft:snow_block
fill 142 113 281 142 116 281 minecraft:packed_ice
setblock 142 113 285 minecraft:snow_block
fill 142 113 286 142 116 286 minecraft:packed_ice
fill 142 113 288 142 114 288 minecraft:packed_ice
setblock 142 113 295 minecraft:snow_block
fill 142 113 296 143 115 296 minecraft:packed_ice
setblock 142 113 299 minecraft:packed_ice
setblock 142 113 300 minecraft:snow_block
fill 142 113 301 142 116 301 minecraft:packed_ice
setblock 142 113 305 minecraft:snow_block
fill 142 113 306 142 114 308 minecraft:packed_ice
setblock 142 113 310 minecraft:snow_block
fill 142 113 311 142 116 311 minecraft:packed_ice
setblock 142 113 315 minecraft:snow_block
fill 142 113 316 142 116 316 minecraft:packed_ice
setblock 143 113 279 minecraft:snow_block
fill 143 113 280 143 116 280 minecraft:packed_ice
setblock 143 113 284 minecraft:snow_block
fill 143 113 285 143 116 285 minecraft:packed_ice
setblock 143 113 298 minecraft:packed_ice
setblock 143 113 299 minecraft:snow_block
fill 143 113 300 144 115 300 minecraft:packed_ice
setblock 143 113 303 minecraft:packed_ice
setblock 143 113 304 minecraft:snow_block
fill 143 113 305 143 115 306 minecraft:packed_ice
fill 143 113 312 143 113 313 minecraft:packed_ice
setblock 143 113 314 minecraft:snow_block
fill 143 113 315 143 116 315 minecraft:packed_ice
setblock 144 113 278 minecraft:snow_block
fill 144 113 279 144 116 279 minecraft:packed_ice
setblock 144 113 283 minecraft:snow_block
fill 144 113 301 144 113 302 minecraft:packed_ice
setblock 145 113 277 minecraft:snow_block
fill 145 113 278 145 116 278 minecraft:packed_ice
setblock 145 113 281 minecraft:packed_ice
setblock 146 113 276 minecraft:snow_block
fill 146 113 277 146 116 277 minecraft:packed_ice
setblock 146 113 316 minecraft:snow_block
fill 147 113 276 147 116 276 minecraft:packed_ice
setblock 147 113 315 minecraft:snow_block
fill 147 113 316 147 116 316 minecraft:packed_ice
setblock 148 113 279 minecraft:snow_block
setblock 148 113 314 minecraft:snow_block
fill 148 113 315 148 116 315 minecraft:packed_ice
fill 149 113 275 149 114 275 minecraft:packed_ice
setblock 149 113 278 minecraft:snow_block
setblock 150 113 277 minecraft:snow_block
fill 150 113 278 150 114 278 minecraft:packed_ice
setblock 151 113 276 minecraft:snow_block
fill 151 113 277 151 115 277 minecraft:packed_ice
setblock 151 113 316 minecraft:snow_block
fill 152 113 276 152 116 276 minecraft:packed_ice
setblock 152 113 315 minecraft:snow_block
fill 152 113 316 152 115 317 minecraft:packed_ice
fill 153 113 316 155 113 316 minecraft:packed_ice
fill 154 113 275 154 114 275 minecraft:packed_ice
setblock 156 113 276 minecraft:snow_block
setblock 156 113 316 minecraft:snow_block
fill 156 113 317 156 114 317 minecraft:packed_ice
fill 157 113 276 157 115 276 minecraft:packed_ice
fill 157 113 316 157 115 316 minecraft:packed_ice
fill 159 113 317 159 114 317 minecraft:packed_ice
fill 161 113 275 161 114 275 minecraft:packed_ice
setblock 161 113 276 minecraft:snow_block
fill 161 113 277 161 116 277 minecraft:packed_ice
setblock 161 113 316 minecraft:snow_block
fill 162 113 276 162 116 276 minecraft:packed_ice
fill 162 113 316 162 116 316 minecraft:packed_ice
fill 163 113 315 163 114 315 minecraft:packed_ice
setblock 165 113 276 minecraft:packed_ice
setblock 165 113 277 minecraft:snow_block
fill 165 113 278 168 113 278 minecraft:packed_ice
fill 166 113 275 166 114 275 minecraft:packed_ice
setblock 166 113 276 minecraft:snow_block
fill 166 113 277 166 116 277 minecraft:packed_ice
setblock 166 113 316 minecraft:snow_block
fill 167 113 276 167 116 276 minecraft:packed_ice
fill 167 113 316 167 116 316 minecraft:packed_ice
fill 168 113 317 169 114 317 minecraft:packed_ice
setblock 170 113 277 minecraft:snow_block
setblock 170 113 317 minecraft:blue_ice
setblock 171 113 276 minecraft:snow_block
fill 171 113 277 171 115 277 minecraft:packed_ice
fill 171 113 317 171 114 317 minecraft:packed_ice
fill 172 113 276 175 113 276 minecraft:packed_ice
setblock 176 113 276 minecraft:snow_block
fill 177 113 275 177 115 277 minecraft:packed_ice
setblock 178 113 275 minecraft:blue_ice
fill 178 113 317 179 114 317 minecraft:packed_ice
setblock 179 113 277 minecraft:packed_ice
setblock 180 113 277 minecraft:snow_block
fill 180 113 278 180 115 279 minecraft:packed_ice
setblock 180 113 281 minecraft:packed_ice
setblock 180 113 282 minecraft:snow_block
setblock 181 113 276 minecraft:snow_block
fill 181 113 277 181 116 277 minecraft:packed_ice
setblock 181 113 281 minecraft:snow_block
fill 181 113 282 181 113 285 minecraft:packed_ice
setblock 181 113 286 minecraft:snow_block
fill 181 113 287 181 116 287 minecraft:packed_ice
fill 181 113 294 181 113 295 minecraft:packed_ice
setblock 181 113 296 minecraft:snow_block
fill 181 113 297 181 116 297 minecraft:packed_ice
setblock 181 113 301 minecraft:snow_block
fill 181 113 302 181 116 302 minecraft:packed_ice
setblock 181 113 316 minecraft:snow_block
fill 181 113 317 182 113 317 minecraft:blue_ice
fill 182 113 276 183 114 276 minecraft:packed_ice
setblock 182 113 280 minecraft:snow_block
fill 182 113 281 182 116 281 minecraft:packed_ice
fill 182 113 283 182 113 284 minecraft:packed_ice
setblock 182 113 285 minecraft:snow_block
fill 182 113 286 183 114 286 minecraft:packed_ice
setblock 182 113 290 minecraft:snow_block
fill 182 113 291 182 116 291 minecraft:packed_ice
setblock 182 113 295 minecraft:snow_block
fill 182 113 296 182 116 296 minecraft:packed_ice
setblock 182 113 300 minecraft:snow_block
fill 182 113 301 182 116 301 minecraft:packed_ice
setblock 182 113 305 minecraft:snow_block
fill 182 113 306 182 116 306 minecraft:packed_ice
setblock 182 113 315 minecraft:snow_block
fill 182 113 316 182 116 316 minecraft:packed_ice
setblock 183 113 277 minecraft:blue_ice
fill 183 113 278 183 114 279 minecraft:packed_ice
fill 183 113 283 183 113 284 minecraft:blue_ice
setblock 183 113 289 minecraft:blue_ice
fill 183 113 298 183 114 298 minecraft:packed_ice
setblock 183 113 309 minecraft:blue_ice
fill 183 113 310 183 114 310 minecraft:packed_ice
setblock 183 113 312 minecraft:blue_ice
fill 183 113 313 183 114 313 minecraft:packed_ice
fill 183 113 315 183 114 315 minecraft:packed_ice
fill 183 113 317 183 114 317 minecraft:packed_ice
fill 141 114 285 142 114 285 minecraft:packed_ice
fill 141 114 289 141 114 291 minecraft:packed_ice
fill 141 114 296 141 114 298 minecraft:packed_ice
fill 141 114 300 141 114 301 minecraft:packed_ice
fill 141 114 303 141 114 304 minecraft:packed_ice
setblock 141 114 306 minecraft:packed_ice
fill 141 114 309 141 114 310 minecraft:packed_ice
fill 141 114 312 141 114 313 minecraft:packed_ice
setblock 142 114 279 minecraft:snow_block
fill 142 114 280 142 117 280 minecraft:packed_ice
setblock 142 114 283 minecraft:packed_ice
setblock 142 114 284 minecraft:snow_block
setblock 142 114 289 minecraft:snow_block
fill 142 114 290 142 115 292 minecraft:packed_ice
setblock 142 114 294 minecraft:snow_block
fill 142 114 295 142 117 295 minecraft:packed_ice
setblock 142 114 299 minecraft:snow_block
fill 142 114 300 142 117 300 minecraft:packed_ice
setblock 142 114 303 minecraft:packed_ice
setblock 142 114 304 minecraft:snow_block
fill 142 114 305 142 117 305 minecraft:packed_ice
setblock 142 114 309 minecraft:snow_block
fill 142 114 310 143 116 310 minecraft:packed_ice
setblock 142 114 314 minecraft:snow_block
fill 142 114 315 142 117 315 minecraft:packed_ice
setblock 143 114 278 minecraft:snow_block
fill 143 114 279 143 117 279 minecraft:packed_ice
setblock 143 114 283 minecraft:snow_block
fill 143 114 284 144 116 284 minecraft:packed_ice
fill 143 114 286 143 115 286 minecraft:packed_ice
setblock 143 114 298 minecraft:snow_block
fill 143 114 299 144 115 299 minecraft:packed_ice
setblock 143 114 303 minecraft:snow_block
fill 143 114 304 144 116 304 minecraft:packed_ice
setblock 143 114 307 minecraft:packed_ice
setblock 143 114 308 minecraft:snow_block
fill 143 114 309 143 117 309 minecraft:packed_ice
fill 143 114 311 143 114 312 minecraft:packed_ice
setblock 143 114 313 minecraft:snow_block
fill 143 114 314 144 116 314 minecraft:packed_ice
setblock 144 114 277 minecraft:snow_block
fill 144 114 278 144 117 278 minecraft:packed_ice
setblock 144 114 282 minecraft:snow_block
fill 144 114 283 144 117 283 minecraft:packed_ice
setblock 144 114 301 minecraft:packed_ice
setblock 144 114 302 minecraft:snow_block
fill 144 114 303 144 117 303 minecraft:packed_ice
fill 144 114 305 144 115 305 minecraft:packed_ice
setblock 144 114 306 minecraft:blue_ice
setblock 145 114 276 minecraft:snow_block
fill 145 114 277 145 117 277 minecraft:packed_ice
setblock 145 114 281 minecraft:snow_block
fill 145 114 282 145 116 282 minecraft:packed_ice
setblock 145 114 316 minecraft:snow_block
fill 146 114 276 146 117 276 minecraft:packed_ice
setblock 146 114 279 minecraft:packed_ice
setblock 146 114 315 minecraft:snow_block
fill 146 114 316 146 117 316 minecraft:packed_ice
setblock 147 114 279 minecraft:snow_block
setblock 147 114 314 minecraft:snow_block
fill 147 114 315 147 117 315 minecraft:packed_ice
setblock 148 114 278 minecraft:snow_block
setblock 149 114 277 minecraft:snow_block
fill 149 114 278 149 115 278 minecraft:packed_ice
setblock 150 114 276 minecraft:snow_block
fill 150 114 277 150 116 277 minecraft:packed_ice
setblock 150 114 316 minecraft:snow_block
fill 151 114 276 151 117 276 minecraft:packed_ice
setblock 151 114 315 minecraft:snow_block
fill 151 114 316 151 117 316 minecraft:packed_ice
fill 153 114 316 154 114 316 minecraft:packed_ice
setblock 155 114 276 minecraft:snow_block
setblock 155 114 316 minecraft:snow_block
setblock 156 114 276 minecraft:packed_ice
fill 156 114 316 156 115 316 minecraft:packed_ice
setblock 159 114 276 minecraft:packed_ice
setblock 160 114 276 minecraft:snow_block
setblock 160 114 316 minecraft:snow_block
fill 161 114 276 161 117 276 minecraft:packed_ice
fill 161 114 316 161 117 316 minecraft:packed_ice
setblock 164 114 276 minecraft:packed_ice
setblock 164 114 277 minecraft:snow_block
fill 164 114 278 167 114 278 minecraft:packed_ice
setblock 165 114 276 minecraft:snow_block
fill 165 114 277 165 117 277 minecraft:packed_ice
setblock 165 114 316 minecraft:snow_block
fill 166 114 276 166 117 276 minecraft:packed_ice
fill 166 114 316 166 116 316 minecraft:packed_ice
setblock 168 114 278 minecraft:snow_block
setblock 169 114 277 minecraft:snow_block
setblock 170 114 276 minecraft:snow_block
fill 170 114 277 170 115 277 minecraft:packed_ice
setblock 170 114 317 minecraft:packed_ice
fill 171 114 276 174 114 276 minecraft:packed_ice
setblock 175 114 276 minecraft:snow_block
fill 176 114 276 176 116 277 minecraft:packed_ice
setblock 178 114 275 minecraft:packed_ice
setblock 179 114 277 minecraft:snow_block
fill 179 114 278 179 117 278 minecraft:packed_ice
fill 179 114 280 179 115 280 minecraft:packed_ice
setblock 180 114 276 minecraft:snow_block
fill 180 114 277 180 117 277 minecraft:packed_ice
setblock 180 114 281 minecraft:snow_block
fill 180 114 282 181 114 284 minecraft:packed_ice
setblock 180 114 316 minecraft:snow_block
fill 181 114 276 181 117 276 minecraft:packed_ice
setblock 181 114 280 minecraft:snow_block
fill 181 114 281 181 117 281 minecraft:packed_ice
setblock 181 114 285 minecraft:snow_block
fill 181 114 286 181 117 286 minecraft:packed_ice
fill 181 114 288 181 115 288 minecraft:packed_ice
setblock 181 114 294 minecraft:packed_ice
setblock 181 114 295 minecraft:snow_block
fill 181 114 296 181 116 296 minecraft:packed_ice
fill 181 114 298 181 114 299 minecraft:packed_ice
setblock 181 114 300 minecraft:snow_block
fill 181 114 301 181 117 301 minecraft:packed_ice
fill 181 114 303 182 114 303 minecraft:packed_ice
fill 181 114 316 181 114 317 minecraft:packed_ice
setblock 182 114 279 minecraft:snow_block
fill 182 114 280 182 117 280 minecraft:packed_ice
fill 182 114 283 183 114 283 minecraft:packed_ice
setblock 182 114 284 minecraft:snow_block
fill 182 114 285 182 117 285 minecraft:packed_ice
setblock 182 114 289 minecraft:snow_block
fill 182 114 290 182 117 290 minecraft:packed_ice
setblock 182 114 294 minecraft:snow_block
fill 182 114 295 182 117 295 minecraft:packed_ice
setblock 182 114 299 minecraft:snow_block
fill 182 114 300 182 117 300 minecraft:packed_ice
fill 182 114 302 182 115 302 minecraft:packed_ice
setblock 182 114 304 minecraft:snow_block
fill 182 114 305 182 117 305 minecraft:packed_ice
fill 182 114 307 182 115 307 minecraft:packed_ice
setblock 182 114 314 minecraft:snow_block
fill 182 114 315 182 117 315 minecraft:packed_ice
fill 182 114 317 182 115 317 minecraft:packed_ice
setblock 183 114 277 minecraft:packed_ice
fill 183 114 284 183 115 284 minecraft:packed_ice
setblock 183 114 289 minecraft:packed_ice
setblock 183 114 309 minecraft:packed_ice
setblock 183 114 312 minecraft:packed_ice
fill 141 115 275 141 115 283 minecraft:blue_ice
setblock 141 115 285 minecraft:light_blue_concrete
fill 141 115 286 141 116 288 minecraft:blue_ice
fill 141 115 289 142 115 289 minecraft:packed_ice
fill 141 115 290 141 115 301 minecraft:blue_ice
fill 141 115 303 141 115 307 minecraft:blue_ice
fill 141 115 309 141 122 312 minecraft:blue_ice
setblock 141 115 313 minecraft:packed_ice
fill 141 115 314 141 179 314 minecraft:blue_ice
fill 141 115 316 141 123 317 minecraft:blue_ice
fill 142 115 275 145 115 275 minecraft:blue_ice
setblock 142 115 278 minecraft:snow_block
fill 142 115 279 142 118 279 minecraft:packed_ice
setblock 142 115 283 minecraft:snow_block
fill 142 115 284 142 117 285 minecraft:packed_ice
setblock 142 115 288 minecraft:snow_block
setblock 142 115 293 minecraft:snow_block
fill 142 115 294 142 116 294 minecraft:packed_ice
setblock 142 115 297 minecraft:packed_ice
setblock 142 115 298 minecraft:snow_block
fill 142 115 299 142 118 299 minecraft:packed_ice
setblock 142 115 302 minecraft:packed_ice
setblock 142 115 303 minecraft:snow_block
fill 142 115 304 142 118 304 minecraft:packed_ice
fill 142 115 306 142 115 307 minecraft:packed_ice
setblock 142 115 308 minecraft:snow_block
fill 142 115 309 142 118 309 minecraft:packed_ice
setblock 142 115 313 minecraft:snow_block
fill 142 115 314 142 118 314 minecraft:packed_ice
fill 142 115 317 151 115 317 minecraft:blue_ice
setblock 143 115 277 minecraft:snow_block
fill 143 115 278 143 118 278 minecraft:packed_ice
setblock 143 115 282 minecraft:snow_block
fill 143 115 283 143 118 283 minecraft:packed_ice
setblock 143 115 287 minecraft:snow_block
setblock 143 115 297 minecraft:snow_block
fill 143 115 298 143 117 298 minecraft:packed_ice
setblock 143 115 302 minecraft:snow_block
fill 143 115 303 143 118 303 minecraft:packed_ice
setblock 143 115 307 minecraft:snow_block
fill 143 115 308 143 118 308 minecraft:packed_ice
setblock 143 115 311 minecraft:packed_ice
setblock 143 115 312 minecraft:snow_block
fill 143 115 313 143 118 313 minecraft:packed_ice
setblock 144 115 276 minecraft:snow_block
fill 144 115 277 144 118 277 minecraft:packed_ice
setblock 144 115 280 minecraft:packed_ice
setblock 144 115 281 minecraft:snow_block
fill 144 115 282 144 118 282 minecraft:packed_ice
setblock 144 115 285 minecraft:packed_ice
setblock 144 115 301 minecraft:snow_block
fill 144 115 302 144 118 302 minecraft:packed_ice
setblock 144 115 306 minecraft:snow_block
fill 144 115 307 144 118 307 minecraft:packed_ice
setblock 144 115 316 minecraft:snow_block
fill 145 115 276 145 118 276 minecraft:packed_ice
setblock 145 115 280 minecraft:snow_block
fill 145 115 281 145 116 281 minecraft:packed_ice
fill 145 115 305 146 116 307 minecraft:blue_ice
setblock 145 115 315 minecraft:snow_block
fill 145 115 316 145 118 316 minecraft:packed_ice
setblock 146 115 279 minecraft:snow_block
setblock 146 115 314 minecraft:snow_block
fill 146 115 315 146 118 315 minecraft:packed_ice
fill 147 115 275 169 115 275 minecraft:blue_ice
setblock 147 115 278 minecraft:snow_block
setblock 147 115 279 minecraft:packed_ice
fill 147 115 306 147 116 306 minecraft:blue_ice
setblock 147 115 314 minecraft:packed_ice
setblock 148 115 277 minecraft:snow_block
fill 148 115 278 148 116 278 minecraft:packed_ice
setblock 149 115 276 minecraft:snow_block
fill 149 115 277 149 117 277 minecraft:packed_ice
setblock 149 115 316 minecraft:snow_block
fill 150 115 276 150 117 276 minecraft:packed_ice
setblock 150 115 315 minecraft:snow_block
fill 150 115 316 150 117 316 minecraft:packed_ice
setblock 153 115 316 minecraft:packed_ice
fill 153 115 317 154 115 317 minecraft:blue_ice
setblock 154 115 276 minecraft:snow_block
setblock 154 115 316 minecraft:snow_block
setblock 155 115 276 minecraft:packed_ice
setblock 155 115 316 minecraft:packed_ice
fill 156 115 317 164 115 317 minecraft:blue_ice
setblock 159 115 276 minecraft:snow_block
setblock 159 115 316 minecraft:snow_block
fill 160 115 276 160 118 276 minecraft:packed_ice
fill 160 115 316 160 118 316 minecraft:packed_ice
setblock 162 115 277 minecraft:packed_ice
setblock 163 115 277 minecraft:snow_block
setblock 164 115 276 minecraft:snow_block
fill 164 115 277 164 116 278 minecraft:packed_ice
setblock 164 115 316 minecraft:snow_block
fill 165 115 276 165 118 276 minecraft:packed_ice
fill 165 115 278 166 115 278 minecraft:packed_ice
fill 165 115 316 165 115 317 minecraft:packed_ice
setblock 167 115 278 minecraft:snow_block
fill 167 115 317 173 116 317 minecraft:blue_ice
setblock 168 115 277 minecraft:snow_block
setblock 169 115 276 minecraft:snow_block
fill 169 115 277 169 116 277 minecraft:packed_ice
setblock 170 115 275 minecraft:light_blue_concrete
fill 170 115 276 173 115 276 minecraft:packed_ice
fill 171 115 275 176 115 275 minecraft:blue_ice
setblock 174 115 276 minecraft:snow_block
fill 175 115 276 175 117 276 minecraft:packed_ice
fill 175 115 317 175 163 317 minecraft:blue_ice
setblock 176 115 317 minecraft:packed_ice
fill 177 115 317 181 128 317 minecraft:blue_ice
setblock 178 115 275 minecraft:blue_ice
setblock 178 115 276 minecraft:packed_ice
setblock 178 115 277 minecraft:snow_block
fill 178 115 278 178 117 278 minecraft:packed_ice
fill 178 115 294 178 116 294 minecraft:packed_ice
setblock 179 115 276 minecraft:snow_block
fill 179 115 277 179 118 277 minecraft:packed_ice
fill 179 115 293 179 116 293 minecraft:packed_ice
fill 179 115 295 179 116 295 minecraft:packed_ice
fill 180 115 275 183 116 275 minecraft:blue_ice
fill 180 115 276 180 118 276 minecraft:packed_ice
setblock 180 115 280 minecraft:snow_block
fill 180 115 281 180 115 284 minecraft:packed_ice
setblock 180 115 285 minecraft:snow_block
fill 180 115 294 180 116 294 minecraft:packed_ice
fill 180 115 316 181 117 316 minecraft:packed_ice
setblock 181 115 279 minecraft:snow_block
fill 181 115 280 181 118 280 minecraft:packed_ice
fill 181 115 282 181 115 283 minecraft:packed_ice
setblock 181 115 284 minecraft:snow_block
fill 181 115 285 181 118 285 minecraft:packed_ice
setblock 181 115 289 minecraft:snow_block
fill 181 115 290 181 118 290 minecraft:packed_ice
setblock 181 115 295 minecraft:packed_ice
setblock 181 115 298 minecraft:packed_ice
setblock 181 115 299 minecraft:snow_block
fill 181 115 300 181 118 300 minecraft:packed_ice
setblock 181 115 303 minecraft:packed_ice
setblock 181 115 304 minecraft:snow_block
fill 182 115 276 182 116 276 minecraft:packed_ice
setblock 182 115 278 minecraft:snow_block
fill 182 115 279 182 118 279 minecraft:packed_ice
setblock 182 115 283 minecraft:snow_block
fill 182 115 284 182 118 284 minecraft:packed_ice
fill 182 115 286 182 116 286 minecraft:packed_ice
setblock 182 115 288 minecraft:snow_block
fill 182 115 289 182 118 289 minecraft:packed_ice
setblock 182 115 293 minecraft:snow_block
fill 182 115 294 182 118 294 minecraft:packed_ice
setblock 182 115 297 minecraft:packed_ice
setblock 182 115 298 minecraft:snow_block
fill 182 115 299 182 118 299 minecraft:packed_ice
setblock 182 115 303 minecraft:snow_block
fill 182 115 304 182 118 304 minecraft:packed_ice
setblock 182 115 308 minecraft:snow_block
fill 182 115 309 182 117 310 minecraft:packed_ice
setblock 182 115 313 minecraft:snow_block
fill 182 115 314 182 118 314 minecraft:packed_ice
fill 183 115 276 183 115 277 minecraft:blue_ice
setblock 183 115 278 minecraft:packed_ice
fill 183 115 279 183 127 283 minecraft:blue_ice
fill 183 115 285 183 115 300 minecraft:blue_ice
fill 183 115 302 183 115 304 minecraft:blue_ice
fill 183 115 306 183 116 310 minecraft:blue_ice
fill 183 115 312 183 115 317 minecraft:blue_ice
fill 141 116 275 141 131 281 minecraft:blue_ice
setblock 141 116 282 minecraft:light_blue_concrete
setblock 141 116 283 minecraft:white_concrete
fill 141 116 284 141 179 285 minecraft:blue_ice
setblock 141 116 289 minecraft:white_concrete
fill 141 116 290 141 116 293 minecraft:blue_ice
setblock 141 116 294 minecraft:packed_ice
fill 141 116 295 141 122 298 minecraft:blue_ice
setblock 141 116 299 minecraft:packed_ice
fill 141 116 300 141 125 305 minecraft:blue_ice
fill 141 116 306 142 116 306 minecraft:packed_ice
fill 141 116 307 141 116 308 minecraft:blue_ice
fill 141 116 313 141 179 313 minecraft:blue_ice
fill 142 116 275 144 147 275 minecraft:blue_ice
setblock 142 116 277 minecraft:snow_block
fill 142 116 278 142 119 278 minecraft:packed_ice
setblock 142 116 282 minecraft:snow_block
fill 142 116 283 142 119 283 minecraft:packed_ice
setblock 142 116 287 minecraft:snow_block
fill 142 116 288 142 116 291 minecraft:packed_ice
setblock 142 116 292 minecraft:snow_block
setblock 142 116 293 minecraft:packed_ice
setblock 142 116 296 minecraft:packed_ice
setblock 142 116 297 minecraft:snow_block
fill 142 116 298 142 119 298 minecraft:packed_ice
setblock 142 116 302 minecraft:snow_block
fill 142 116 303 142 119 303 minecraft:packed_ice
setblock 142 116 307 minecraft:snow_block
fill 142 116 308 142 119 308 minecraft:packed_ice
setblock 142 116 312 minecraft:snow_block
fill 142 116 313 142 119 313 minecraft:packed_ice
fill 142 116 317 148 116 317 minecraft:blue_ice
setblock 143 116 276 minecraft:snow_block
fill 143 116 277 143 119 277 minecraft:packed_ice
setblock 143 116 281 minecraft:snow_block
fill 143 116 282 143 119 282 minecraft:packed_ice
setblock 143 116 286 minecraft:snow_block
fill 143 116 287 143 119 287 minecraft:packed_ice
setblock 143 116 297 minecraft:packed_ice
fill 143 116 299 143 116 300 minecraft:packed_ice
setblock 143 116 301 minecraft:snow_block
fill 143 116 302 143 119 302 minecraft:packed_ice
setblock 143 116 305 minecraft:packed_ice
setblock 143 116 306 minecraft:snow_block
fill 143 116 307 143 119 307 minecraft:packed_ice
setblock 143 116 311 minecraft:snow_block
fill 143 116 312 143 119 312 minecraft:packed_ice
setblock 143 116 316 minecraft:snow_block
fill 144 116 276 144 119 276 minecraft:packed_ice
setblock 144 116 280 minecraft:snow_block
fill 144 116 281 144 119 281 minecraft:packed_ice
setblock 144 116 285 minecraft:snow_block
setblock 144 116 286 minecraft:light[level=15]
setblock 144 116 294 minecraft:light[level=15]
setblock 144 116 300 minecraft:snow_block
fill 144 116 301 144 117 301 minecraft:packed_ice
setblock 144 116 305 minecraft:snow_block
fill 144 116 306 144 119 306 minecraft:packed_ice
fill 144 116 308 144 116 309 minecraft:packed_ice
setblock 144 116 310 minecraft:light[level=15]
setblock 144 116 315 minecraft:snow_block
fill 144 116 316 144 119 316 minecraft:packed_ice
setblock 145 116 275 minecraft:packed_ice
setblock 145 116 279 minecraft:snow_block
fill 145 116 280 145 117 280 minecraft:packed_ice
setblock 145 116 314 minecraft:snow_block
fill 145 116 315 145 119 315 minecraft:packed_ice
fill 146 116 275 150 116 275 minecraft:blue_ice
setblock 146 116 278 minecraft:snow_block
setblock 146 116 279 minecraft:packed_ice
setblock 147 116 277 minecraft:snow_block
fill 147 116 278 147 117 278 minecraft:packed_ice
setblock 148 116 276 minecraft:snow_block
fill 148 116 277 148 117 277 minecraft:packed_ice
fill 148 116 306 149 116 306 minecraft:blue_ice
setblock 148 116 316 minecraft:snow_block
fill 149 116 276 149 118 276 minecraft:packed_ice
setblock 149 116 315 minecraft:snow_block
fill 149 116 316 149 118 316 minecraft:packed_ice
setblock 149 116 317 minecraft:light_blue_concrete
fill 150 116 317 153 127 317 minecraft:blue_ice
setblock 151 116 275 minecraft:light_blue_concrete
setblock 152 116 275 minecraft:packed_ice
setblock 152 116 278 minecraft:light[level=15]
setblock 152 116 286 minecraft:light[level=15]
setblock 152 116 294 minecraft:light[level=15]
setblock 152 116 302 minecraft:light[level=15]
setblock 152 116 310 minecraft:light[level=15]
setblock 152 116 316 minecraft:packed_ice
fill 153 116 275 164 116 275 minecraft:blue_ice
setblock 153 116 316 minecraft:snow_block
setblock 154 116 317 minecraft:packed_ice
fill 155 116 317 155 162 317 minecraft:blue_ice
fill 156 116 317 156 117 317 minecraft:packed_ice
fill 157 116 317 166 116 317 minecraft:blue_ice
setblock 158 116 276 minecraft:snow_block
setblock 158 116 316 minecraft:snow_block
fill 159 116 276 159 117 276 minecraft:packed_ice
fill 159 116 316 159 117 316 minecraft:packed_ice
setblock 160 116 278 minecraft:light[level=15]
setblock 160 116 286 minecraft:light[level=15]
setblock 160 116 294 minecraft:light[level=15]
setblock 160 116 302 minecraft:light[level=15]
setblock 160 116 310 minecraft:light[level=15]
setblock 162 116 277 minecraft:snow_block
setblock 163 116 276 minecraft:snow_block
fill 163 116 277 163 117 277 minecraft:packed_ice
setblock 163 116 316 minecraft:snow_block
fill 164 116 276 164 119 276 minecraft:packed_ice
fill 164 116 316 165 117 316 minecraft:packed_ice
setblock 165 116 275 minecraft:packed_ice
setblock 165 116 278 minecraft:packed_ice
fill 166 116 275 173 116 275 minecraft:blue_ice
setblock 166 116 278 minecraft:snow_block
setblock 167 116 277 minecraft:snow_block
setblock 168 116 276 minecraft:snow_block
setblock 168 116 277 minecraft:packed_ice
setblock 168 116 278 minecraft:light[level=15]
setblock 168 116 286 minecraft:light[level=15]
setblock 168 116 294 minecraft:light[level=15]
setblock 168 116 302 minecraft:light[level=15]
setblock 168 116 310 minecraft:light[level=15]
fill 169 116 276 172 116 276 minecraft:packed_ice
setblock 173 116 276 minecraft:snow_block
fill 174 116 275 174 116 276 minecraft:packed_ice
setblock 174 116 317 minecraft:blue_ice
fill 175 116 275 175 121 275 minecraft:blue_ice
setblock 176 116 275 minecraft:packed_ice
setblock 176 116 278 minecraft:light[level=15]
setblock 176 116 286 minecraft:light[level=15]
setblock 176 116 294 minecraft:light[level=15]
setblock 176 116 302 minecraft:light[level=15]
setblock 176 116 310 minecraft:light[level=15]
fill 176 116 317 176 179 317 minecraft:blue_ice
fill 177 116 275 177 130 275 minecraft:blue_ice
setblock 177 116 276 minecraft:packed_ice
setblock 177 116 277 minecraft:snow_block
setblock 178 116 275 minecraft:packed_ice
schedule function dropper:buildpart/63_3 1t
