setblock 228 208 542 minecraft:pearlescent_froglight
setblock 229 208 531 minecraft:pearlescent_froglight
setblock 229 208 533 minecraft:pearlescent_froglight
setblock 229 208 535 minecraft:pearlescent_froglight
setblock 229 208 537 minecraft:pearlescent_froglight
setblock 229 208 539 minecraft:pearlescent_froglight
setblock 229 208 541 minecraft:pearlescent_froglight
fill 189 209 515 189 210 515 minecraft:gray_concrete
fill 189 209 517 189 210 517 minecraft:gray_concrete
fill 189 209 519 189 210 519 minecraft:gray_concrete
fill 189 209 521 189 210 521 minecraft:gray_concrete
fill 189 209 523 189 210 523 minecraft:gray_concrete
fill 190 209 514 190 210 514 minecraft:gray_concrete
fill 190 209 516 190 210 516 minecraft:gray_concrete
fill 190 209 518 190 210 518 minecraft:gray_concrete
fill 190 209 520 190 210 520 minecraft:gray_concrete
fill 190 209 522 190 210 522 minecraft:gray_concrete
fill 190 209 524 190 210 524 minecraft:gray_concrete
setblock 191 209 513 minecraft:light[level=10]
fill 191 209 515 191 210 515 minecraft:gray_concrete
fill 191 209 517 191 210 517 minecraft:gray_concrete
fill 191 209 519 191 210 519 minecraft:gray_concrete
fill 191 209 521 191 210 521 minecraft:gray_concrete
fill 191 209 523 191 210 523 minecraft:gray_concrete
setblock 191 209 529 minecraft:light[level=10]
setblock 191 209 537 minecraft:light[level=10]
setblock 191 209 545 minecraft:light[level=10]
fill 192 209 514 192 210 514 minecraft:gray_concrete
fill 192 209 516 192 210 516 minecraft:gray_concrete
fill 192 209 518 192 210 518 minecraft:gray_concrete
fill 192 209 520 192 210 520 minecraft:gray_concrete
fill 192 209 522 192 210 522 minecraft:gray_concrete
fill 192 209 524 192 210 524 minecraft:gray_concrete
fill 193 209 515 193 210 515 minecraft:gray_concrete
fill 193 209 517 193 210 517 minecraft:gray_concrete
fill 193 209 519 193 210 519 minecraft:gray_concrete
fill 193 209 521 193 210 521 minecraft:gray_concrete
fill 193 209 523 193 210 523 minecraft:gray_concrete
setblock 199 209 513 minecraft:light[level=10]
setblock 199 209 521 minecraft:light[level=10]
setblock 199 209 529 minecraft:light[level=10]
setblock 199 209 537 minecraft:light[level=10]
setblock 199 209 545 minecraft:light[level=10]
setblock 204 209 519 minecraft:dark_oak_planks
setblock 204 209 531 minecraft:dark_oak_planks
setblock 207 209 513 minecraft:light[level=10]
setblock 207 209 521 minecraft:light[level=10]
setblock 207 209 529 minecraft:light[level=10]
setblock 207 209 537 minecraft:light[level=10]
setblock 207 209 545 minecraft:light[level=10]
setblock 215 209 513 minecraft:light[level=10]
setblock 215 209 521 minecraft:light[level=10]
setblock 215 209 529 minecraft:light[level=10]
setblock 215 209 537 minecraft:light[level=10]
setblock 215 209 545 minecraft:light[level=10]
setblock 216 209 519 minecraft:dark_oak_planks
setblock 216 209 531 minecraft:dark_oak_planks
fill 221 209 531 221 210 531 minecraft:gray_concrete
fill 221 209 533 221 210 533 minecraft:gray_concrete
fill 221 209 535 221 210 535 minecraft:gray_concrete
fill 221 209 537 221 210 537 minecraft:gray_concrete
fill 221 209 539 221 210 539 minecraft:gray_concrete
fill 221 209 541 221 210 541 minecraft:gray_concrete
fill 222 209 530 222 210 530 minecraft:gray_concrete
fill 222 209 532 222 210 532 minecraft:gray_concrete
fill 222 209 534 222 210 534 minecraft:gray_concrete
fill 222 209 536 222 210 536 minecraft:gray_concrete
fill 222 209 538 222 210 538 minecraft:gray_concrete
fill 222 209 540 222 210 540 minecraft:gray_concrete
fill 222 209 542 222 210 542 minecraft:gray_concrete
setblock 223 209 513 minecraft:light[level=10]
setblock 223 209 521 minecraft:light[level=10]
setblock 223 209 529 minecraft:light[level=10]
fill 223 209 531 223 210 531 minecraft:gray_concrete
fill 223 209 533 223 210 533 minecraft:gray_concrete
fill 223 209 535 223 210 535 minecraft:gray_concrete
fill 223 209 537 223 210 537 minecraft:gray_concrete
fill 223 209 539 223 210 539 minecraft:gray_concrete
fill 223 209 541 223 210 541 minecraft:gray_concrete
setblock 223 209 545 minecraft:light[level=10]
fill 224 209 530 224 210 530 minecraft:gray_concrete
fill 224 209 532 224 210 532 minecraft:gray_concrete
fill 224 209 534 224 210 534 minecraft:gray_concrete
fill 224 209 536 224 210 536 minecraft:gray_concrete
fill 224 209 538 224 210 538 minecraft:gray_concrete
fill 224 209 540 224 210 540 minecraft:gray_concrete
fill 224 209 542 224 210 542 minecraft:gray_concrete
fill 225 209 531 225 210 531 minecraft:gray_concrete
fill 225 209 533 225 210 533 minecraft:gray_concrete
fill 225 209 535 225 210 535 minecraft:gray_concrete
fill 225 209 537 225 210 537 minecraft:gray_concrete
fill 225 209 539 225 210 539 minecraft:gray_concrete
fill 225 209 541 225 210 541 minecraft:gray_concrete
fill 226 209 530 226 210 530 minecraft:gray_concrete
fill 226 209 532 226 210 532 minecraft:gray_concrete
fill 226 209 534 226 210 534 minecraft:gray_concrete
fill 226 209 536 226 210 536 minecraft:gray_concrete
fill 226 209 538 226 210 538 minecraft:gray_concrete
fill 226 209 540 226 210 540 minecraft:gray_concrete
fill 226 209 542 226 210 542 minecraft:gray_concrete
fill 227 209 531 227 210 531 minecraft:gray_concrete
fill 227 209 533 227 210 533 minecraft:gray_concrete
fill 227 209 535 227 210 535 minecraft:gray_concrete
fill 227 209 537 227 210 537 minecraft:gray_concrete
fill 227 209 539 227 210 539 minecraft:gray_concrete
fill 227 209 541 227 210 541 minecraft:gray_concrete
fill 228 209 530 228 210 530 minecraft:gray_concrete
fill 228 209 532 228 210 532 minecraft:gray_concrete
fill 228 209 534 228 210 534 minecraft:gray_concrete
fill 228 209 536 228 210 536 minecraft:gray_concrete
fill 228 209 538 228 210 538 minecraft:gray_concrete
fill 228 209 540 228 210 540 minecraft:gray_concrete
fill 228 209 542 228 210 542 minecraft:gray_concrete
fill 229 209 531 229 210 531 minecraft:gray_concrete
fill 229 209 533 229 210 533 minecraft:gray_concrete
fill 229 209 535 229 210 535 minecraft:gray_concrete
fill 229 209 537 229 210 537 minecraft:gray_concrete
fill 229 209 539 229 210 539 minecraft:gray_concrete
fill 229 209 541 229 210 541 minecraft:gray_concrete
fill 189 210 511 189 211 513 minecraft:gray_concrete
fill 189 210 527 190 210 532 minecraft:gray_concrete
fill 189 210 535 190 210 540 minecraft:gray_concrete
fill 189 210 543 190 210 548 minecraft:gray_concrete
fill 189 210 551 194 211 551 minecraft:gray_concrete
fill 190 210 512 190 210 513 minecraft:gray_concrete
fill 190 210 525 190 210 526 minecraft:gray_concrete
fill 190 210 533 190 210 534 minecraft:gray_concrete
fill 190 210 541 190 210 542 minecraft:gray_concrete
fill 190 210 549 190 210 550 minecraft:gray_concrete
fill 191 210 512 228 210 512 minecraft:gray_concrete
fill 191 210 550 229 210 550 minecraft:gray_concrete
fill 192 210 511 197 211 511 minecraft:gray_concrete
fill 197 210 551 202 211 551 minecraft:gray_concrete
fill 200 210 511 205 211 511 minecraft:gray_concrete
fill 205 210 551 210 211 551 minecraft:gray_concrete
fill 208 210 511 213 211 511 minecraft:gray_concrete
fill 213 210 551 218 211 551 minecraft:gray_concrete
fill 216 210 511 221 211 511 minecraft:gray_concrete
fill 221 210 551 226 211 551 minecraft:gray_concrete
fill 224 210 511 229 211 511 minecraft:gray_concrete
fill 228 210 513 228 210 529 minecraft:gray_concrete
fill 228 210 543 228 210 549 minecraft:gray_concrete
fill 229 210 514 229 211 519 minecraft:gray_concrete
fill 229 210 522 229 211 527 minecraft:gray_concrete
fill 229 210 543 229 211 543 minecraft:gray_concrete
fill 229 210 546 229 211 549 minecraft:gray_concrete
fill 229 210 551 229 211 551 minecraft:gray_concrete
setblock 189 211 515 minecraft:pearlescent_froglight
setblock 189 211 517 minecraft:pearlescent_froglight
setblock 189 211 519 minecraft:pearlescent_froglight
setblock 189 211 521 minecraft:pearlescent_froglight
setblock 189 211 523 minecraft:pearlescent_froglight
fill 189 211 527 189 211 532 minecraft:gray_concrete
fill 189 211 535 189 211 540 minecraft:gray_concrete
fill 189 211 543 189 211 548 minecraft:gray_concrete
setblock 190 211 514 minecraft:pearlescent_froglight
setblock 190 211 516 minecraft:pearlescent_froglight
setblock 190 211 518 minecraft:pearlescent_froglight
setblock 190 211 520 minecraft:pearlescent_froglight
setblock 190 211 522 minecraft:pearlescent_froglight
setblock 190 211 524 minecraft:pearlescent_froglight
setblock 191 211 515 minecraft:pearlescent_froglight
setblock 191 211 517 minecraft:pearlescent_froglight
setblock 191 211 519 minecraft:pearlescent_froglight
setblock 191 211 521 minecraft:pearlescent_froglight
setblock 191 211 523 minecraft:pearlescent_froglight
setblock 192 211 514 minecraft:pearlescent_froglight
setblock 192 211 516 minecraft:pearlescent_froglight
setblock 192 211 518 minecraft:pearlescent_froglight
setblock 192 211 520 minecraft:pearlescent_froglight
setblock 192 211 522 minecraft:pearlescent_froglight
setblock 192 211 524 minecraft:pearlescent_froglight
setblock 193 211 515 minecraft:pearlescent_froglight
setblock 193 211 517 minecraft:pearlescent_froglight
setblock 193 211 519 minecraft:pearlescent_froglight
setblock 193 211 521 minecraft:pearlescent_froglight
setblock 193 211 523 minecraft:pearlescent_froglight
setblock 221 211 531 minecraft:pearlescent_froglight
setblock 221 211 533 minecraft:pearlescent_froglight
setblock 221 211 535 minecraft:pearlescent_froglight
setblock 221 211 537 minecraft:pearlescent_froglight
setblock 221 211 539 minecraft:pearlescent_froglight
setblock 221 211 541 minecraft:pearlescent_froglight
setblock 222 211 530 minecraft:pearlescent_froglight
setblock 222 211 532 minecraft:pearlescent_froglight
setblock 222 211 534 minecraft:pearlescent_froglight
setblock 222 211 536 minecraft:pearlescent_froglight
setblock 222 211 538 minecraft:pearlescent_froglight
setblock 222 211 540 minecraft:pearlescent_froglight
setblock 222 211 542 minecraft:pearlescent_froglight
setblock 223 211 531 minecraft:pearlescent_froglight
setblock 223 211 533 minecraft:pearlescent_froglight
setblock 223 211 535 minecraft:pearlescent_froglight
setblock 223 211 537 minecraft:pearlescent_froglight
setblock 223 211 539 minecraft:pearlescent_froglight
setblock 223 211 541 minecraft:pearlescent_froglight
setblock 224 211 530 minecraft:pearlescent_froglight
setblock 224 211 532 minecraft:pearlescent_froglight
setblock 224 211 534 minecraft:pearlescent_froglight
setblock 224 211 536 minecraft:pearlescent_froglight
setblock 224 211 538 minecraft:pearlescent_froglight
setblock 224 211 540 minecraft:pearlescent_froglight
setblock 224 211 542 minecraft:pearlescent_froglight
setblock 225 211 531 minecraft:pearlescent_froglight
setblock 225 211 533 minecraft:pearlescent_froglight
setblock 225 211 535 minecraft:pearlescent_froglight
setblock 225 211 537 minecraft:pearlescent_froglight
setblock 225 211 539 minecraft:pearlescent_froglight
setblock 225 211 541 minecraft:pearlescent_froglight
setblock 226 211 530 minecraft:pearlescent_froglight
setblock 226 211 532 minecraft:pearlescent_froglight
setblock 226 211 534 minecraft:pearlescent_froglight
setblock 226 211 536 minecraft:pearlescent_froglight
setblock 226 211 538 minecraft:pearlescent_froglight
setblock 226 211 540 minecraft:pearlescent_froglight
setblock 226 211 542 minecraft:pearlescent_froglight
setblock 227 211 531 minecraft:pearlescent_froglight
setblock 227 211 533 minecraft:pearlescent_froglight
setblock 227 211 535 minecraft:pearlescent_froglight
setblock 227 211 537 minecraft:pearlescent_froglight
setblock 227 211 539 minecraft:pearlescent_froglight
setblock 227 211 541 minecraft:pearlescent_froglight
setblock 228 211 530 minecraft:pearlescent_froglight
setblock 228 211 532 minecraft:pearlescent_froglight
setblock 228 211 534 minecraft:pearlescent_froglight
setblock 228 211 536 minecraft:pearlescent_froglight
setblock 228 211 538 minecraft:pearlescent_froglight
setblock 228 211 540 minecraft:pearlescent_froglight
setblock 228 211 542 minecraft:pearlescent_froglight
setblock 229 211 531 minecraft:pearlescent_froglight
setblock 229 211 533 minecraft:pearlescent_froglight
setblock 229 211 535 minecraft:pearlescent_froglight
setblock 229 211 537 minecraft:pearlescent_froglight
setblock 229 211 539 minecraft:pearlescent_froglight
setblock 229 211 541 minecraft:pearlescent_froglight
setblock 229 211 550 minecraft:gray_concrete
fill 189 212 515 189 213 515 minecraft:gray_concrete
fill 189 212 517 189 213 517 minecraft:gray_concrete
fill 189 212 519 189 213 519 minecraft:gray_concrete
fill 189 212 521 189 213 521 minecraft:gray_concrete
fill 189 212 523 189 213 523 minecraft:gray_concrete
fill 190 212 514 190 213 514 minecraft:gray_concrete
fill 190 212 516 190 213 516 minecraft:gray_concrete
fill 190 212 518 190 213 518 minecraft:gray_concrete
fill 190 212 520 190 213 520 minecraft:gray_concrete
fill 190 212 522 190 213 522 minecraft:gray_concrete
fill 190 212 524 190 213 524 minecraft:gray_concrete
fill 191 212 515 191 213 515 minecraft:gray_concrete
fill 191 212 517 191 213 517 minecraft:gray_concrete
fill 191 212 519 191 213 519 minecraft:gray_concrete
fill 191 212 521 191 213 521 minecraft:gray_concrete
fill 191 212 523 191 213 523 minecraft:gray_concrete
fill 192 212 514 192 213 514 minecraft:gray_concrete
fill 192 212 516 192 213 516 minecraft:gray_concrete
fill 192 212 518 192 213 518 minecraft:gray_concrete
fill 192 212 520 192 213 520 minecraft:gray_concrete
fill 192 212 522 192 213 522 minecraft:gray_concrete
fill 192 212 524 192 213 524 minecraft:gray_concrete
fill 193 212 515 193 213 515 minecraft:gray_concrete
fill 193 212 517 193 213 517 minecraft:gray_concrete
fill 193 212 519 193 213 519 minecraft:gray_concrete
fill 193 212 521 193 213 521 minecraft:gray_concrete
fill 193 212 523 193 213 523 minecraft:gray_concrete
fill 201 212 513 205 213 517 minecraft:black_concrete
fill 203 212 511 203 212 512 minecraft:black_concrete
fill 221 212 531 221 213 531 minecraft:gray_concrete
fill 221 212 533 221 213 533 minecraft:gray_concrete
fill 221 212 535 221 213 535 minecraft:gray_concrete
fill 221 212 537 221 213 537 minecraft:gray_concrete
fill 221 212 539 221 213 539 minecraft:gray_concrete
fill 221 212 541 221 213 541 minecraft:gray_concrete
fill 222 212 530 222 213 530 minecraft:gray_concrete
fill 222 212 532 222 213 532 minecraft:gray_concrete
fill 222 212 534 222 213 534 minecraft:gray_concrete
fill 222 212 536 222 213 536 minecraft:gray_concrete
fill 222 212 538 222 213 538 minecraft:gray_concrete
fill 222 212 540 222 213 540 minecraft:gray_concrete
fill 222 212 542 222 213 542 minecraft:gray_concrete
fill 223 212 531 223 213 531 minecraft:gray_concrete
fill 223 212 533 223 213 533 minecraft:gray_concrete
fill 223 212 535 223 213 535 minecraft:gray_concrete
fill 223 212 537 223 213 537 minecraft:gray_concrete
fill 223 212 539 223 213 539 minecraft:gray_concrete
fill 223 212 541 223 213 541 minecraft:gray_concrete
fill 224 212 530 224 213 530 minecraft:gray_concrete
fill 224 212 532 224 213 532 minecraft:gray_concrete
fill 224 212 534 224 213 534 minecraft:gray_concrete
fill 224 212 536 224 213 536 minecraft:gray_concrete
fill 224 212 538 224 213 538 minecraft:gray_concrete
fill 224 212 540 224 213 540 minecraft:gray_concrete
fill 224 212 542 224 213 542 minecraft:gray_concrete
fill 225 212 531 225 213 531 minecraft:gray_concrete
fill 225 212 533 225 213 533 minecraft:gray_concrete
fill 225 212 535 225 213 535 minecraft:gray_concrete
fill 225 212 537 225 213 537 minecraft:gray_concrete
fill 225 212 539 225 213 539 minecraft:gray_concrete
fill 225 212 541 225 213 541 minecraft:gray_concrete
fill 226 212 530 226 213 530 minecraft:gray_concrete
fill 226 212 532 226 213 532 minecraft:gray_concrete
fill 226 212 534 226 213 534 minecraft:gray_concrete
fill 226 212 536 226 213 536 minecraft:gray_concrete
fill 226 212 538 226 213 538 minecraft:gray_concrete
fill 226 212 540 226 213 540 minecraft:gray_concrete
fill 226 212 542 226 213 542 minecraft:gray_concrete
fill 227 212 531 227 213 531 minecraft:gray_concrete
fill 227 212 533 227 213 533 minecraft:gray_concrete
fill 227 212 535 227 213 535 minecraft:gray_concrete
fill 227 212 537 227 213 537 minecraft:gray_concrete
fill 227 212 539 227 213 539 minecraft:gray_concrete
fill 227 212 541 227 213 541 minecraft:gray_concrete
fill 228 212 530 228 213 530 minecraft:gray_concrete
fill 228 212 532 228 213 532 minecraft:gray_concrete
fill 228 212 534 228 213 534 minecraft:gray_concrete
fill 228 212 536 228 213 536 minecraft:gray_concrete
fill 228 212 538 228 213 538 minecraft:gray_concrete
fill 228 212 540 228 213 540 minecraft:gray_concrete
fill 228 212 542 228 213 542 minecraft:gray_concrete
fill 229 212 531 229 213 531 minecraft:gray_concrete
fill 229 212 533 229 213 533 minecraft:gray_concrete
fill 229 212 535 229 213 535 minecraft:gray_concrete
fill 229 212 537 229 213 537 minecraft:gray_concrete
fill 229 212 539 229 213 539 minecraft:gray_concrete
fill 229 212 541 229 213 541 minecraft:gray_concrete
fill 188 214 515 189 214 515 minecraft:pearlescent_froglight
fill 188 214 523 189 214 523 minecraft:pearlescent_froglight
fill 188 214 531 188 219 531 minecraft:pearlescent_froglight
fill 188 214 539 188 219 539 minecraft:pearlescent_froglight
fill 188 214 547 188 219 547 minecraft:pearlescent_froglight
setblock 189 214 517 minecraft:pearlescent_froglight
setblock 189 214 519 minecraft:pearlescent_froglight
setblock 189 214 521 minecraft:pearlescent_froglight
setblock 190 214 514 minecraft:pearlescent_froglight
setblock 190 214 516 minecraft:pearlescent_froglight
setblock 190 214 518 minecraft:pearlescent_froglight
setblock 190 214 520 minecraft:pearlescent_froglight
setblock 190 214 522 minecraft:pearlescent_froglight
setblock 190 214 524 minecraft:pearlescent_froglight
setblock 191 214 515 minecraft:pearlescent_froglight
setblock 191 214 517 minecraft:pearlescent_froglight
setblock 191 214 519 minecraft:pearlescent_froglight
setblock 191 214 521 minecraft:pearlescent_froglight
setblock 191 214 523 minecraft:pearlescent_froglight
fill 191 214 552 191 219 552 minecraft:pearlescent_froglight
setblock 192 214 514 minecraft:pearlescent_froglight
setblock 192 214 516 minecraft:pearlescent_froglight
setblock 192 214 518 minecraft:pearlescent_froglight
setblock 192 214 520 minecraft:pearlescent_froglight
setblock 192 214 522 minecraft:pearlescent_froglight
setblock 192 214 524 minecraft:pearlescent_froglight
setblock 193 214 515 minecraft:pearlescent_froglight
setblock 193 214 517 minecraft:pearlescent_froglight
setblock 193 214 519 minecraft:pearlescent_froglight
setblock 193 214 521 minecraft:pearlescent_froglight
setblock 193 214 523 minecraft:pearlescent_froglight
fill 195 214 510 195 219 510 minecraft:pearlescent_froglight
fill 199 214 552 199 219 552 minecraft:pearlescent_froglight
fill 202 214 514 204 215 516 minecraft:gray_concrete
fill 203 214 510 203 219 510 minecraft:pearlescent_froglight
fill 207 214 552 207 219 552 minecraft:pearlescent_froglight
fill 211 214 510 211 219 510 minecraft:pearlescent_froglight
fill 215 214 552 215 219 552 minecraft:pearlescent_froglight
fill 219 214 510 219 219 510 minecraft:pearlescent_froglight
setblock 221 214 531 minecraft:pearlescent_froglight
setblock 221 214 533 minecraft:pearlescent_froglight
setblock 221 214 535 minecraft:pearlescent_froglight
setblock 221 214 537 minecraft:pearlescent_froglight
setblock 221 214 539 minecraft:pearlescent_froglight
setblock 221 214 541 minecraft:pearlescent_froglight
setblock 222 214 530 minecraft:pearlescent_froglight
setblock 222 214 532 minecraft:pearlescent_froglight
setblock 222 214 534 minecraft:pearlescent_froglight
setblock 222 214 536 minecraft:pearlescent_froglight
setblock 222 214 538 minecraft:pearlescent_froglight
setblock 222 214 540 minecraft:pearlescent_froglight
setblock 222 214 542 minecraft:pearlescent_froglight
setblock 223 214 531 minecraft:pearlescent_froglight
setblock 223 214 533 minecraft:pearlescent_froglight
setblock 223 214 535 minecraft:pearlescent_froglight
setblock 223 214 537 minecraft:pearlescent_froglight
setblock 223 214 539 minecraft:pearlescent_froglight
setblock 223 214 541 minecraft:pearlescent_froglight
fill 223 214 552 223 219 552 minecraft:pearlescent_froglight
setblock 224 214 530 minecraft:pearlescent_froglight
setblock 224 214 532 minecraft:pearlescent_froglight
setblock 224 214 534 minecraft:pearlescent_froglight
setblock 224 214 536 minecraft:pearlescent_froglight
setblock 224 214 538 minecraft:pearlescent_froglight
setblock 224 214 540 minecraft:pearlescent_froglight
setblock 224 214 542 minecraft:pearlescent_froglight
setblock 225 214 531 minecraft:pearlescent_froglight
setblock 225 214 533 minecraft:pearlescent_froglight
setblock 225 214 535 minecraft:pearlescent_froglight
setblock 225 214 537 minecraft:pearlescent_froglight
setblock 225 214 539 minecraft:pearlescent_froglight
setblock 225 214 541 minecraft:pearlescent_froglight
setblock 226 214 530 minecraft:pearlescent_froglight
setblock 226 214 532 minecraft:pearlescent_froglight
setblock 226 214 534 minecraft:pearlescent_froglight
setblock 226 214 536 minecraft:pearlescent_froglight
setblock 226 214 538 minecraft:pearlescent_froglight
setblock 226 214 540 minecraft:pearlescent_froglight
setblock 226 214 542 minecraft:pearlescent_froglight
fill 227 214 510 227 219 510 minecraft:pearlescent_froglight
setblock 227 214 531 minecraft:pearlescent_froglight
setblock 227 214 533 minecraft:pearlescent_froglight
setblock 227 214 535 minecraft:pearlescent_froglight
setblock 227 214 537 minecraft:pearlescent_froglight
setblock 227 214 539 minecraft:pearlescent_froglight
setblock 227 214 541 minecraft:pearlescent_froglight
setblock 228 214 530 minecraft:pearlescent_froglight
setblock 228 214 532 minecraft:pearlescent_froglight
setblock 228 214 534 minecraft:pearlescent_froglight
setblock 228 214 536 minecraft:pearlescent_froglight
setblock 228 214 538 minecraft:pearlescent_froglight
setblock 228 214 540 minecraft:pearlescent_froglight
setblock 228 214 542 minecraft:pearlescent_froglight
fill 229 214 531 230 214 531 minecraft:pearlescent_froglight
setblock 229 214 533 minecraft:pearlescent_froglight
setblock 229 214 535 minecraft:pearlescent_froglight
setblock 229 214 537 minecraft:pearlescent_froglight
fill 229 214 539 230 214 539 minecraft:pearlescent_froglight
setblock 229 214 541 minecraft:pearlescent_froglight
fill 230 214 515 230 219 515 minecraft:pearlescent_froglight
fill 230 214 523 230 219 523 minecraft:pearlescent_froglight
fill 230 214 547 230 219 547 minecraft:pearlescent_froglight
fill 188 215 515 188 219 515 minecraft:pearlescent_froglight
fill 188 215 523 188 219 523 minecraft:pearlescent_froglight
fill 189 215 515 189 217 515 minecraft:gray_concrete
fill 189 215 517 189 234 517 minecraft:gray_concrete
fill 189 215 519 189 217 519 minecraft:gray_concrete
fill 189 215 521 189 217 521 minecraft:gray_concrete
fill 189 215 523 189 217 523 minecraft:gray_concrete
fill 190 215 514 190 217 514 minecraft:gray_concrete
fill 190 215 516 190 217 516 minecraft:gray_concrete
fill 190 215 518 190 217 518 minecraft:gray_concrete
fill 190 215 520 190 217 520 minecraft:gray_concrete
fill 190 215 522 190 217 522 minecraft:gray_concrete
fill 190 215 524 190 217 524 minecraft:gray_concrete
fill 191 215 515 191 217 515 minecraft:gray_concrete
fill 191 215 517 191 217 517 minecraft:gray_concrete
fill 191 215 519 191 217 519 minecraft:gray_concrete
fill 191 215 521 191 217 521 minecraft:gray_concrete
fill 191 215 523 191 217 523 minecraft:gray_concrete
fill 192 215 514 192 217 514 minecraft:gray_concrete
fill 192 215 516 192 217 516 minecraft:gray_concrete
fill 192 215 518 192 217 518 minecraft:gray_concrete
fill 192 215 520 192 217 520 minecraft:gray_concrete
fill 192 215 522 192 217 522 minecraft:gray_concrete
fill 192 215 524 192 217 524 minecraft:gray_concrete
fill 193 215 515 193 217 515 minecraft:gray_concrete
fill 193 215 517 193 217 517 minecraft:gray_concrete
fill 193 215 519 193 217 519 minecraft:gray_concrete
fill 193 215 521 193 217 521 minecraft:gray_concrete
fill 193 215 523 193 217 523 minecraft:gray_concrete
fill 221 215 531 221 216 531 minecraft:gray_concrete
fill 221 215 533 221 216 533 minecraft:gray_concrete
fill 221 215 535 221 216 535 minecraft:gray_concrete
fill 221 215 537 221 216 537 minecraft:gray_concrete
fill 221 215 539 221 216 539 minecraft:gray_concrete
fill 221 215 541 221 216 541 minecraft:gray_concrete
fill 222 215 530 222 216 530 minecraft:gray_concrete
fill 222 215 532 222 216 532 minecraft:gray_concrete
fill 222 215 534 222 216 534 minecraft:gray_concrete
fill 222 215 536 222 216 536 minecraft:gray_concrete
fill 222 215 538 222 216 538 minecraft:gray_concrete
fill 222 215 540 222 216 540 minecraft:gray_concrete
fill 222 215 542 222 216 542 minecraft:gray_concrete
fill 223 215 531 223 216 531 minecraft:gray_concrete
fill 223 215 533 223 216 533 minecraft:gray_concrete
fill 223 215 535 223 216 535 minecraft:gray_concrete
fill 223 215 537 223 216 537 minecraft:gray_concrete
fill 223 215 539 223 216 539 minecraft:gray_concrete
fill 223 215 541 223 216 541 minecraft:gray_concrete
fill 224 215 530 224 216 530 minecraft:gray_concrete
fill 224 215 532 224 216 532 minecraft:gray_concrete
fill 224 215 534 224 216 534 minecraft:gray_concrete
fill 224 215 536 224 216 536 minecraft:gray_concrete
fill 224 215 538 224 216 538 minecraft:gray_concrete
fill 224 215 540 224 216 540 minecraft:gray_concrete
fill 224 215 542 224 216 542 minecraft:gray_concrete
fill 225 215 531 225 216 531 minecraft:gray_concrete
fill 225 215 533 225 216 533 minecraft:gray_concrete
fill 225 215 535 225 216 535 minecraft:gray_concrete
fill 225 215 537 225 216 537 minecraft:gray_concrete
fill 225 215 539 225 216 539 minecraft:gray_concrete
fill 225 215 541 225 216 541 minecraft:gray_concrete
fill 226 215 530 226 216 530 minecraft:gray_concrete
fill 226 215 532 226 216 532 minecraft:gray_concrete
fill 226 215 534 226 216 534 minecraft:gray_concrete
fill 226 215 536 226 216 536 minecraft:gray_concrete
fill 226 215 538 226 216 538 minecraft:gray_concrete
fill 226 215 540 226 216 540 minecraft:gray_concrete
fill 226 215 542 226 216 542 minecraft:gray_concrete
fill 227 215 531 227 216 531 minecraft:gray_concrete
fill 227 215 533 227 216 533 minecraft:gray_concrete
fill 227 215 535 227 216 535 minecraft:gray_concrete
fill 227 215 537 227 216 537 minecraft:gray_concrete
fill 227 215 539 227 216 539 minecraft:gray_concrete
fill 227 215 541 227 216 541 minecraft:gray_concrete
fill 228 215 530 228 216 530 minecraft:gray_concrete
fill 228 215 532 228 216 532 minecraft:gray_concrete
fill 228 215 534 228 216 534 minecraft:gray_concrete
fill 228 215 536 228 216 536 minecraft:gray_concrete
fill 228 215 538 228 216 538 minecraft:gray_concrete
fill 228 215 540 228 216 540 minecraft:gray_concrete
fill 228 215 542 228 216 542 minecraft:gray_concrete
fill 229 215 531 229 216 531 minecraft:gray_concrete
fill 229 215 533 229 216 533 minecraft:gray_concrete
fill 229 215 535 229 216 535 minecraft:gray_concrete
fill 229 215 537 229 234 537 minecraft:gray_concrete
fill 229 215 539 229 216 539 minecraft:gray_concrete
fill 229 215 541 229 216 541 minecraft:gray_concrete
fill 230 215 531 230 219 531 minecraft:pearlescent_froglight
fill 230 215 539 230 219 539 minecraft:pearlescent_froglight
fill 202 216 515 204 218 515 minecraft:gray_concrete
fill 203 216 514 203 218 514 minecraft:gray_concrete
fill 203 216 516 203 218 516 minecraft:gray_concrete
setblock 191 217 513 minecraft:light[level=10]
setblock 191 217 529 minecraft:light[level=10]
setblock 191 217 537 minecraft:light[level=10]
setblock 191 217 545 minecraft:light[level=10]
setblock 199 217 513 minecraft:light[level=10]
setblock 199 217 521 minecraft:light[level=10]
setblock 199 217 529 minecraft:light[level=10]
setblock 199 217 537 minecraft:light[level=10]
setblock 199 217 545 minecraft:light[level=10]
setblock 207 217 513 minecraft:light[level=10]
setblock 207 217 521 minecraft:light[level=10]
setblock 207 217 529 minecraft:light[level=10]
setblock 207 217 537 minecraft:light[level=10]
setblock 207 217 545 minecraft:light[level=10]
setblock 215 217 513 minecraft:light[level=10]
setblock 215 217 521 minecraft:light[level=10]
setblock 215 217 529 minecraft:light[level=10]
setblock 215 217 537 minecraft:light[level=10]
setblock 215 217 545 minecraft:light[level=10]
fill 222 217 531 228 217 541 minecraft:white_concrete
setblock 223 217 513 minecraft:light[level=10]
setblock 223 217 521 minecraft:light[level=10]
setblock 223 217 529 minecraft:light[level=10]
setblock 223 217 545 minecraft:light[level=10]
fill 189 218 525 189 234 526 minecraft:gray_concrete
fill 190 218 515 192 218 523 minecraft:white_concrete
fill 194 218 511 194 219 513 minecraft:gray_concrete
fill 223 218 532 227 218 540 minecraft:white_concrete
fill 191 219 516 191 219 522 minecraft:white_concrete
fill 203 219 515 203 223 515 minecraft:gray_concrete
fill 224 219 533 226 219 539 minecraft:white_concrete
fill 188 220 515 188 227 515 minecraft:black_concrete
fill 188 220 523 188 227 523 minecraft:black_concrete
fill 188 220 531 188 227 531 minecraft:black_concrete
fill 188 220 539 188 227 539 minecraft:black_concrete
fill 188 220 547 188 227 547 minecraft:black_concrete
fill 190 220 517 192 220 521 minecraft:white_concrete
fill 191 220 552 191 227 552 minecraft:black_concrete
fill 195 220 510 195 227 510 minecraft:black_concrete
fill 199 220 552 199 227 552 minecraft:black_concrete
fill 203 220 510 203 227 510 minecraft:black_concrete
fill 207 220 552 207 227 552 minecraft:black_concrete
fill 211 220 510 211 227 510 minecraft:black_concrete
fill 215 220 552 215 227 552 minecraft:black_concrete
fill 219 220 510 219 227 510 minecraft:black_concrete
fill 223 220 552 223 227 552 minecraft:black_concrete
fill 225 220 534 225 220 538 minecraft:white_concrete
fill 227 220 510 227 227 510 minecraft:black_concrete
fill 230 220 515 230 227 515 minecraft:black_concrete
fill 230 220 523 230 227 523 minecraft:black_concrete
fill 230 220 531 230 227 531 minecraft:black_concrete
fill 230 220 539 230 227 539 minecraft:black_concrete
fill 230 220 547 230 227 547 minecraft:black_concrete
fill 189 221 519 193 221 520 minecraft:white_concrete
fill 190 221 518 193 221 518 minecraft:white_concrete
fill 189 224 511 189 225 516 minecraft:gray_concrete
fill 189 224 519 190 224 524 minecraft:gray_concrete
fill 189 224 527 190 224 532 minecraft:gray_concrete
fill 189 224 535 190 224 540 minecraft:gray_concrete
fill 189 224 543 190 224 548 minecraft:gray_concrete
fill 189 224 551 194 225 551 minecraft:gray_concrete
fill 190 224 512 190 224 518 minecraft:gray_concrete
fill 190 224 525 190 224 526 minecraft:gray_concrete
fill 190 224 533 190 224 534 minecraft:gray_concrete
fill 190 224 541 190 224 542 minecraft:gray_concrete
fill 190 224 549 190 224 550 minecraft:gray_concrete
fill 191 224 512 228 224 512 minecraft:gray_concrete
fill 191 224 550 229 224 550 minecraft:gray_concrete
fill 192 224 511 197 225 511 minecraft:gray_concrete
fill 197 224 551 202 225 551 minecraft:gray_concrete
fill 200 224 511 205 225 511 minecraft:gray_concrete
setblock 203 224 515 minecraft:pearlescent_froglight
fill 205 224 551 210 225 551 minecraft:gray_concrete
fill 208 224 511 213 225 511 minecraft:gray_concrete
fill 213 224 551 218 225 551 minecraft:gray_concrete
fill 216 224 511 221 225 511 minecraft:gray_concrete
fill 221 224 551 226 225 551 minecraft:gray_concrete
fill 224 224 511 229 225 511 minecraft:gray_concrete
fill 228 224 513 228 224 549 minecraft:gray_concrete
fill 229 224 514 229 225 519 minecraft:gray_concrete
fill 229 224 522 229 225 527 minecraft:gray_concrete
fill 229 224 530 229 225 535 minecraft:gray_concrete
fill 229 224 538 229 225 543 minecraft:gray_concrete
fill 229 224 546 229 225 549 minecraft:gray_concrete
fill 229 224 551 229 225 551 minecraft:gray_concrete
fill 189 225 519 189 225 524 minecraft:gray_concrete
fill 189 225 527 189 225 532 minecraft:gray_concrete
fill 189 225 535 189 225 540 minecraft:gray_concrete
fill 189 225 543 189 225 548 minecraft:gray_concrete
setblock 191 225 513 minecraft:light[level=10]
setblock 191 225 521 minecraft:light[level=10]
setblock 191 225 529 minecraft:light[level=10]
setblock 191 225 537 minecraft:light[level=10]
setblock 191 225 545 minecraft:light[level=10]
setblock 199 225 513 minecraft:light[level=10]
setblock 199 225 521 minecraft:light[level=10]
setblock 199 225 529 minecraft:light[level=10]
setblock 199 225 537 minecraft:light[level=10]
setblock 199 225 545 minecraft:light[level=10]
setblock 207 225 513 minecraft:light[level=10]
setblock 207 225 521 minecraft:light[level=10]
setblock 207 225 529 minecraft:light[level=10]
setblock 207 225 537 minecraft:light[level=10]
setblock 207 225 545 minecraft:light[level=10]
setblock 215 225 513 minecraft:light[level=10]
setblock 215 225 521 minecraft:light[level=10]
setblock 215 225 529 minecraft:light[level=10]
setblock 215 225 537 minecraft:light[level=10]
setblock 215 225 545 minecraft:light[level=10]
setblock 223 225 513 minecraft:light[level=10]
setblock 223 225 521 minecraft:light[level=10]
setblock 223 225 529 minecraft:light[level=10]
setblock 223 225 537 minecraft:light[level=10]
setblock 223 225 545 minecraft:light[level=10]
setblock 229 225 550 minecraft:gray_concrete
fill 188 228 515 188 233 515 minecraft:pearlescent_froglight
fill 188 228 523 188 233 523 minecraft:pearlescent_froglight
fill 188 228 531 188 233 531 minecraft:pearlescent_froglight
fill 188 228 539 188 233 539 minecraft:pearlescent_froglight
fill 188 228 547 188 233 547 minecraft:pearlescent_froglight
fill 191 228 552 191 233 552 minecraft:pearlescent_froglight
fill 195 228 510 195 233 510 minecraft:pearlescent_froglight
fill 199 228 552 199 233 552 minecraft:pearlescent_froglight
fill 203 228 510 203 233 510 minecraft:pearlescent_froglight
fill 207 228 552 207 233 552 minecraft:pearlescent_froglight
fill 211 228 510 211 233 510 minecraft:pearlescent_froglight
fill 215 228 552 215 233 552 minecraft:pearlescent_froglight
fill 219 228 510 219 233 510 minecraft:pearlescent_froglight
fill 223 228 552 223 233 552 minecraft:pearlescent_froglight
fill 227 228 510 227 233 510 minecraft:pearlescent_froglight
fill 230 228 515 230 233 515 minecraft:pearlescent_froglight
fill 230 228 523 230 233 523 minecraft:pearlescent_froglight
fill 230 228 531 230 233 531 minecraft:pearlescent_froglight
fill 230 228 539 230 233 539 minecraft:pearlescent_froglight
fill 230 228 547 230 233 547 minecraft:pearlescent_froglight
setblock 191 233 513 minecraft:light[level=10]
setblock 191 233 521 minecraft:light[level=10]
setblock 191 233 529 minecraft:light[level=10]
setblock 191 233 537 minecraft:light[level=10]
setblock 191 233 545 minecraft:light[level=10]
setblock 199 233 513 minecraft:light[level=10]
setblock 199 233 521 minecraft:light[level=10]
setblock 199 233 529 minecraft:light[level=10]
setblock 199 233 537 minecraft:light[level=10]
setblock 199 233 545 minecraft:light[level=10]
setblock 207 233 513 minecraft:light[level=10]
setblock 207 233 521 minecraft:light[level=10]
setblock 207 233 529 minecraft:light[level=10]
setblock 207 233 537 minecraft:light[level=10]
setblock 207 233 545 minecraft:light[level=10]
setblock 215 233 513 minecraft:light[level=10]
setblock 215 233 521 minecraft:light[level=10]
setblock 215 233 529 minecraft:light[level=10]
setblock 215 233 537 minecraft:light[level=10]
setblock 215 233 545 minecraft:light[level=10]
setblock 223 233 513 minecraft:light[level=10]
setblock 223 233 521 minecraft:light[level=10]
setblock 223 233 529 minecraft:light[level=10]
setblock 223 233 537 minecraft:light[level=10]
setblock 223 233 545 minecraft:light[level=10]
fill 188 234 515 188 244 515 minecraft:black_concrete
fill 188 234 523 188 244 523 minecraft:black_concrete
fill 188 234 531 188 244 531 minecraft:black_concrete
fill 188 234 539 188 244 539 minecraft:black_concrete
fill 188 234 547 188 244 547 minecraft:black_concrete
fill 191 234 552 191 244 552 minecraft:black_concrete
fill 195 234 510 195 244 510 minecraft:black_concrete
fill 199 234 552 199 244 552 minecraft:black_concrete
fill 203 234 510 203 244 510 minecraft:black_concrete
fill 207 234 552 207 244 552 minecraft:black_concrete
fill 211 234 510 211 244 510 minecraft:black_concrete
fill 215 234 552 215 244 552 minecraft:black_concrete
fill 219 234 510 219 244 510 minecraft:black_concrete
fill 223 234 552 223 244 552 minecraft:black_concrete
fill 227 234 510 227 244 510 minecraft:black_concrete
fill 230 234 515 230 244 515 minecraft:black_concrete
fill 230 234 523 230 244 523 minecraft:black_concrete
fill 230 234 531 230 244 531 minecraft:black_concrete
fill 230 234 539 230 244 539 minecraft:black_concrete
fill 230 234 547 230 244 547 minecraft:black_concrete
fill 197 240 521 202 241 522 minecraft:gray_concrete
fill 197 240 532 202 241 533 minecraft:gray_concrete
fill 198 240 523 215 240 523 minecraft:gray_concrete
fill 198 240 531 215 240 531 minecraft:gray_concrete
fill 199 240 524 214 240 524 minecraft:gray_concrete
fill 199 240 530 214 240 530 minecraft:gray_concrete
fill 200 240 525 208 240 525 minecraft:gray_concrete
fill 200 240 529 208 240 529 minecraft:gray_concrete
fill 201 240 526 207 240 526 minecraft:gray_concrete
fill 201 240 528 207 240 528 minecraft:gray_concrete
fill 203 240 522 204 241 522 minecraft:gray_concrete
fill 203 240 527 206 240 527 minecraft:gray_concrete
fill 203 240 532 204 241 532 minecraft:gray_concrete
fill 205 240 516 208 240 521 minecraft:gray_concrete
fill 205 240 533 208 240 538 minecraft:gray_concrete
fill 206 240 514 206 241 515 minecraft:gray_concrete
fill 206 240 522 216 240 522 minecraft:gray_concrete
fill 206 240 532 216 240 532 minecraft:gray_concrete
fill 206 240 539 206 241 540 minecraft:gray_concrete
fill 207 240 515 207 241 515 minecraft:gray_concrete
fill 207 240 539 207 241 539 minecraft:gray_concrete
fill 209 240 517 209 240 521 minecraft:gray_concrete
fill 209 240 533 209 240 537 minecraft:gray_concrete
fill 210 240 520 210 240 521 minecraft:gray_concrete
fill 210 240 525 219 240 525 minecraft:gray_concrete
fill 210 240 529 219 240 529 minecraft:gray_concrete
fill 210 240 533 210 240 534 minecraft:gray_concrete
fill 211 240 521 216 240 521 minecraft:gray_concrete
fill 211 240 526 221 240 526 minecraft:gray_concrete
fill 211 240 528 221 240 528 minecraft:gray_concrete
fill 211 240 533 216 240 533 minecraft:gray_concrete
fill 212 240 519 217 240 520 minecraft:gray_concrete
fill 212 240 527 223 240 527 minecraft:gray_concrete
fill 212 240 534 217 240 535 minecraft:gray_concrete
fill 214 240 518 217 241 518 minecraft:gray_concrete
fill 214 240 536 217 241 536 minecraft:gray_concrete
fill 215 240 517 217 241 517 minecraft:gray_concrete
fill 215 240 537 217 241 537 minecraft:gray_concrete
fill 189 241 511 196 241 551 minecraft:black_concrete
fill 197 241 511 204 241 520 minecraft:black_concrete
fill 197 241 523 197 241 531 minecraft:black_concrete
fill 197 241 534 204 241 551 minecraft:black_concrete
fill 198 241 523 200 241 523 minecraft:gray_concrete
fill 198 241 524 198 241 530 minecraft:black_concrete
fill 198 241 531 200 241 531 minecraft:gray_concrete
fill 199 241 524 200 241 524 minecraft:gray_concrete
fill 199 241 525 199 241 529 minecraft:black_concrete
fill 199 241 530 200 241 530 minecraft:gray_concrete
fill 200 241 525 201 241 525 minecraft:gray_concrete
fill 200 241 526 200 241 528 minecraft:black_concrete
fill 200 241 529 201 241 529 minecraft:gray_concrete
fill 201 241 523 205 241 524 minecraft:black_concrete
fill 201 241 526 202 241 526 minecraft:gray_concrete
fill 201 241 527 202 241 527 minecraft:black_concrete
fill 201 241 528 202 241 528 minecraft:gray_concrete
fill 201 241 530 205 241 531 minecraft:black_concrete
fill 202 241 525 205 241 525 minecraft:black_concrete
fill 202 241 529 205 241 529 minecraft:black_concrete
fill 203 241 521 204 241 521 minecraft:black_concrete
fill 203 241 526 205 241 526 minecraft:black_concrete
fill 203 241 527 204 241 527 minecraft:gray_concrete
fill 203 241 528 205 241 528 minecraft:black_concrete
fill 203 241 533 204 241 533 minecraft:black_concrete
fill 205 241 511 205 241 515 minecraft:black_concrete
fill 205 241 516 206 241 519 minecraft:gray_concrete
fill 205 241 520 213 252 521 minecraft:green_terracotta
fill 205 241 522 206 241 522 minecraft:black_concrete
setblock 205 241 527 minecraft:white_concrete
fill 205 241 532 206 241 532 minecraft:black_concrete
fill 205 241 533 213 252 534 minecraft:lime_terracotta
fill 205 241 535 206 241 538 minecraft:gray_concrete
fill 205 241 539 205 241 551 minecraft:black_concrete
fill 206 241 511 229 241 513 minecraft:black_concrete
setblock 206 241 523 minecraft:gray_concrete
setblock 206 241 524 minecraft:black_concrete
setblock 206 241 525 minecraft:white_concrete
fill 206 241 526 206 241 528 minecraft:pearlescent_froglight
setblock 206 241 529 minecraft:white_concrete
setblock 206 241 530 minecraft:black_concrete
setblock 206 241 531 minecraft:gray_concrete
fill 206 241 541 229 241 551 minecraft:black_concrete
fill 207 241 514 229 241 514 minecraft:black_concrete
fill 207 241 516 208 241 517 minecraft:gray_concrete
setblock 207 241 518 minecraft:black_concrete
fill 207 241 519 211 252 519 minecraft:green_terracotta
fill 207 241 522 211 251 522 minecraft:green_terracotta
fill 207 241 523 208 241 523 minecraft:black_concrete
setblock 207 241 524 minecraft:white_concrete
fill 207 241 525 207 241 526 minecraft:verdant_froglight
fill 207 241 528 207 241 529 minecraft:verdant_froglight
setblock 207 241 530 minecraft:white_concrete
fill 207 241 531 208 241 531 minecraft:black_concrete
fill 207 241 532 211 251 532 minecraft:lime_terracotta
fill 207 241 535 211 252 535 minecraft:lime_terracotta
setblock 207 241 536 minecraft:black_concrete
fill 207 241 537 208 241 538 minecraft:gray_concrete
fill 207 241 540 229 241 540 minecraft:black_concrete
fill 208 241 515 229 241 515 minecraft:black_concrete
fill 208 241 518 209 241 518 minecraft:gray_concrete
fill 208 241 524 210 241 524 minecraft:pearlescent_froglight
setblock 208 241 525 minecraft:verdant_froglight
setblock 208 241 529 minecraft:verdant_froglight
fill 208 241 530 210 241 530 minecraft:pearlescent_froglight
fill 208 241 536 209 241 536 minecraft:gray_concrete
fill 208 241 539 229 241 539 minecraft:black_concrete
fill 209 241 516 229 241 516 minecraft:black_concrete
setblock 209 241 517 minecraft:gray_concrete
setblock 209 241 523 minecraft:white_concrete
setblock 209 241 531 minecraft:white_concrete
setblock 209 241 537 minecraft:gray_concrete
fill 209 241 538 229 241 538 minecraft:black_concrete
fill 210 241 517 213 241 518 minecraft:black_concrete
fill 210 241 523 214 241 523 minecraft:black_concrete
fill 210 241 525 211 241 525 minecraft:verdant_froglight
fill 210 241 529 211 241 529 minecraft:verdant_froglight
fill 210 241 531 214 241 531 minecraft:black_concrete
fill 210 241 536 213 241 537 minecraft:black_concrete
setblock 211 241 524 minecraft:white_concrete
setblock 211 241 526 minecraft:verdant_froglight
setblock 211 241 528 minecraft:verdant_froglight
setblock 211 241 530 minecraft:white_concrete
fill 212 241 519 217 241 519 minecraft:gray_concrete
fill 212 241 522 214 241 522 minecraft:black_concrete
fill 212 241 524 213 241 524 minecraft:black_concrete
setblock 212 241 525 minecraft:white_concrete
fill 212 241 526 212 241 528 minecraft:pearlescent_froglight
setblock 212 241 529 minecraft:white_concrete
fill 212 241 530 213 241 530 minecraft:black_concrete
fill 212 241 532 214 241 532 minecraft:black_concrete
fill 212 241 535 217 241 535 minecraft:gray_concrete
fill 213 241 525 213 241 526 minecraft:black_concrete
setblock 213 241 527 minecraft:white_concrete
fill 213 241 528 213 241 529 minecraft:black_concrete
setblock 214 241 517 minecraft:black_concrete
fill 214 241 520 214 241 521 minecraft:black_concrete
fill 214 241 524 214 241 525 minecraft:gray_concrete
fill 214 241 526 217 241 528 minecraft:black_concrete
fill 214 241 529 214 241 530 minecraft:gray_concrete
fill 214 241 533 214 241 534 minecraft:black_concrete
setblock 214 241 537 minecraft:black_concrete
setblock 215 241 520 minecraft:black_concrete
fill 215 241 521 215 241 523 minecraft:gray_concrete
fill 215 241 524 229 241 524 minecraft:black_concrete
fill 215 241 525 219 241 525 minecraft:gray_concrete
fill 215 241 529 219 241 529 minecraft:gray_concrete
fill 215 241 530 229 241 530 minecraft:black_concrete
fill 215 241 531 215 241 533 minecraft:gray_concrete
setblock 215 241 534 minecraft:black_concrete
fill 216 241 520 216 241 522 minecraft:gray_concrete
fill 216 241 523 229 241 523 minecraft:black_concrete
fill 216 241 531 229 241 531 minecraft:black_concrete
fill 216 241 532 216 241 534 minecraft:gray_concrete
setblock 217 241 520 minecraft:gray_concrete
fill 217 241 521 229 241 522 minecraft:black_concrete
fill 217 241 532 229 241 533 minecraft:black_concrete
setblock 217 241 534 minecraft:gray_concrete
fill 218 241 517 229 241 520 minecraft:black_concrete
fill 218 241 526 221 241 526 minecraft:gray_concrete
setblock 218 241 527 minecraft:black_concrete
fill 218 241 528 221 241 528 minecraft:gray_concrete
fill 218 241 534 229 241 537 minecraft:black_concrete
fill 219 241 527 223 241 527 minecraft:gray_concrete
fill 220 241 525 229 241 525 minecraft:black_concrete
fill 220 241 529 229 241 529 minecraft:black_concrete
fill 222 241 526 229 241 526 minecraft:black_concrete
fill 222 241 528 229 241 528 minecraft:black_concrete
fill 224 241 527 229 241 527 minecraft:black_concrete
fill 203 242 519 204 251 522 minecraft:green_terracotta
fill 203 242 532 204 251 535 minecraft:lime_terracotta
fill 205 242 519 206 252 519 minecraft:green_terracotta
fill 205 242 522 206 252 522 minecraft:green_terracotta
fill 205 242 532 206 252 532 minecraft:lime_terracotta
fill 205 242 535 206 252 535 minecraft:lime_terracotta
fill 206 242 518 212 251 518 minecraft:green_terracotta
fill 206 242 523 212 246 523 minecraft:green_terracotta
fill 206 242 531 212 246 531 minecraft:lime_terracotta
fill 206 242 536 212 251 536 minecraft:lime_terracotta
fill 212 242 519 215 251 519 minecraft:green_terracotta
fill 212 242 522 215 251 522 minecraft:green_terracotta
fill 212 242 532 215 251 532 minecraft:lime_terracotta
fill 212 242 535 215 251 535 minecraft:lime_terracotta
fill 214 242 520 215 252 521 minecraft:green_terracotta
fill 214 242 533 215 252 534 minecraft:lime_terracotta
fill 201 243 520 202 251 521 minecraft:green_terracotta
fill 201 243 533 202 251 534 minecraft:lime_terracotta
fill 202 243 519 202 251 519 minecraft:green_terracotta
fill 202 243 522 202 251 522 minecraft:green_terracotta
fill 202 243 532 202 251 532 minecraft:lime_terracotta
fill 202 243 535 202 251 535 minecraft:lime_terracotta
fill 203 243 518 205 250 518 minecraft:green_terracotta
fill 203 243 523 205 247 523 minecraft:green_terracotta
fill 203 243 531 205 247 531 minecraft:lime_terracotta
fill 203 243 536 205 250 536 minecraft:lime_terracotta
fill 208 243 517 210 250 517 minecraft:green_terracotta
fill 208 243 524 210 243 524 minecraft:green_terracotta
fill 208 243 530 210 243 530 minecraft:lime_terracotta
fill 208 243 537 210 250 537 minecraft:lime_terracotta
fill 213 243 518 215 250 518 minecraft:green_terracotta
fill 213 243 523 215 246 523 minecraft:green_terracotta
fill 213 243 531 215 246 531 minecraft:lime_terracotta
fill 213 243 536 215 250 536 minecraft:lime_terracotta
fill 216 243 519 216 251 522 minecraft:green_terracotta
fill 216 243 532 216 251 535 minecraft:lime_terracotta
fill 217 243 520 217 251 521 minecraft:green_terracotta
fill 217 243 533 217 251 534 minecraft:lime_terracotta
fill 200 244 519 200 249 522 minecraft:green_terracotta
fill 200 244 532 200 249 535 minecraft:lime_terracotta
fill 201 244 519 201 250 519 minecraft:green_terracotta
fill 201 244 522 201 250 522 minecraft:green_terracotta
fill 201 244 532 201 250 532 minecraft:lime_terracotta
fill 201 244 535 201 250 535 minecraft:lime_terracotta
fill 202 244 518 202 250 518 minecraft:green_terracotta
fill 202 244 523 202 250 523 minecraft:green_terracotta
fill 202 244 531 202 250 531 minecraft:lime_terracotta
fill 202 244 536 202 250 536 minecraft:lime_terracotta
fill 205 244 517 207 250 517 minecraft:green_terracotta
fill 205 244 524 208 244 524 minecraft:green_terracotta
fill 205 244 530 208 244 530 minecraft:lime_terracotta
fill 205 244 537 207 250 537 minecraft:lime_terracotta
fill 210 244 524 213 244 524 minecraft:green_terracotta
fill 210 244 530 213 244 530 minecraft:lime_terracotta
fill 211 244 517 213 250 517 minecraft:green_terracotta
fill 211 244 537 213 250 537 minecraft:lime_terracotta
fill 216 244 518 216 250 518 minecraft:green_terracotta
fill 216 244 523 216 248 523 minecraft:green_terracotta
fill 216 244 531 216 248 531 minecraft:lime_terracotta
fill 216 244 536 216 250 536 minecraft:lime_terracotta
fill 217 244 519 218 249 519 minecraft:green_terracotta
fill 217 244 522 218 249 522 minecraft:green_terracotta
fill 217 244 532 218 249 532 minecraft:lime_terracotta
fill 217 244 535 218 249 535 minecraft:lime_terracotta
fill 218 244 520 218 250 521 minecraft:green_terracotta
fill 218 244 533 218 250 534 minecraft:lime_terracotta
fill 188 245 515 188 247 515 minecraft:pearlescent_froglight
fill 188 245 523 188 247 523 minecraft:pearlescent_froglight
fill 188 245 531 188 247 531 minecraft:pearlescent_froglight
fill 188 245 539 188 247 539 minecraft:pearlescent_froglight
fill 188 245 547 188 247 547 minecraft:pearlescent_froglight
fill 189 245 517 189 273 518 minecraft:gray_concrete
fill 189 245 525 189 273 526 minecraft:gray_concrete
fill 189 245 533 189 273 534 minecraft:gray_concrete
fill 189 245 541 189 273 542 minecraft:gray_concrete
fill 189 245 547 195 246 551 minecraft:gray_concrete
fill 190 245 511 191 273 511 minecraft:gray_concrete
fill 191 245 552 191 247 552 minecraft:pearlescent_froglight
fill 195 245 510 195 247 510 minecraft:pearlescent_froglight
fill 196 245 551 196 273 551 minecraft:gray_concrete
fill 198 245 511 199 273 511 minecraft:gray_concrete
fill 199 245 520 199 249 521 minecraft:green_terracotta
fill 199 245 533 199 249 534 minecraft:lime_terracotta
fill 199 245 552 199 247 552 minecraft:pearlescent_froglight
fill 201 245 518 201 249 518 minecraft:green_terracotta
fill 201 245 523 201 249 523 minecraft:green_terracotta
fill 201 245 531 201 249 531 minecraft:lime_terracotta
fill 201 245 536 201 249 536 minecraft:lime_terracotta
fill 203 245 510 203 247 510 minecraft:pearlescent_froglight
fill 203 245 517 204 248 517 minecraft:green_terracotta
fill 203 245 524 207 246 524 minecraft:green_terracotta
fill 203 245 530 207 246 530 minecraft:lime_terracotta
fill 203 245 537 204 248 537 minecraft:lime_terracotta
fill 203 245 551 204 273 551 minecraft:gray_concrete
fill 206 245 511 207 273 511 minecraft:gray_concrete
fill 207 245 552 207 247 552 minecraft:pearlescent_froglight
fill 211 245 510 211 247 510 minecraft:pearlescent_froglight
fill 211 245 524 215 246 524 minecraft:green_terracotta
fill 211 245 530 215 246 530 minecraft:lime_terracotta
fill 211 245 551 212 273 551 minecraft:gray_concrete
fill 214 245 511 215 258 511 minecraft:gray_concrete
fill 214 245 517 215 248 517 minecraft:green_terracotta
fill 214 245 537 215 248 537 minecraft:lime_terracotta
fill 215 245 552 215 247 552 minecraft:pearlescent_froglight
fill 217 245 518 217 249 518 minecraft:green_terracotta
fill 217 245 523 217 249 523 minecraft:green_terracotta
fill 217 245 531 217 249 531 minecraft:lime_terracotta
fill 217 245 536 217 249 536 minecraft:lime_terracotta
fill 219 245 510 219 247 510 minecraft:pearlescent_froglight
fill 219 245 520 219 249 521 minecraft:green_terracotta
fill 219 245 533 219 249 534 minecraft:lime_terracotta
fill 219 245 551 220 273 551 minecraft:gray_concrete
fill 222 245 511 223 273 511 minecraft:gray_concrete
fill 223 245 552 223 247 552 minecraft:pearlescent_froglight
fill 227 245 510 227 247 510 minecraft:pearlescent_froglight
fill 227 245 551 228 273 551 minecraft:gray_concrete
fill 229 245 512 229 273 513 minecraft:gray_concrete
fill 229 245 520 229 273 521 minecraft:gray_concrete
fill 229 245 528 229 273 529 minecraft:gray_concrete
fill 229 245 536 229 273 537 minecraft:gray_concrete
fill 229 245 544 229 273 545 minecraft:gray_concrete
fill 230 245 515 230 247 515 minecraft:pearlescent_froglight
fill 230 245 523 230 247 523 minecraft:pearlescent_froglight
fill 230 245 531 230 247 531 minecraft:pearlescent_froglight
fill 230 245 539 230 247 539 minecraft:pearlescent_froglight
fill 230 245 547 230 247 547 minecraft:pearlescent_froglight
fill 199 246 519 199 248 519 minecraft:green_terracotta
fill 199 246 522 199 248 522 minecraft:green_terracotta
fill 199 246 532 199 248 532 minecraft:lime_terracotta
fill 199 246 535 199 248 535 minecraft:lime_terracotta
fill 200 246 518 200 247 518 minecraft:green_terracotta
fill 200 246 523 200 247 523 minecraft:green_terracotta
fill 200 246 531 200 247 531 minecraft:lime_terracotta
fill 200 246 536 200 247 536 minecraft:lime_terracotta
fill 218 246 518 218 247 518 minecraft:green_terracotta
fill 218 246 523 218 247 523 minecraft:green_terracotta
fill 218 246 531 218 247 531 minecraft:lime_terracotta
fill 218 246 536 218 247 536 minecraft:lime_terracotta
fill 219 246 519 219 248 519 minecraft:green_terracotta
fill 219 246 522 219 248 522 minecraft:green_terracotta
fill 219 246 532 219 248 532 minecraft:lime_terracotta
fill 219 246 535 219 248 535 minecraft:lime_terracotta
setblock 189 247 547 minecraft:pearlescent_froglight
fill 189 247 548 189 267 548 minecraft:gray_concrete
setblock 189 247 549 minecraft:pearlescent_froglight
fill 189 247 550 189 273 550 minecraft:gray_concrete
setblock 189 247 551 minecraft:pearlescent_froglight
fill 190 247 547 190 266 547 minecraft:gray_concrete
setblock 190 247 548 minecraft:pearlescent_froglight
fill 190 247 549 190 266 549 minecraft:gray_concrete
setblock 190 247 550 minecraft:pearlescent_froglight
fill 190 247 551 190 267 551 minecraft:gray_concrete
setblock 191 247 547 minecraft:pearlescent_froglight
fill 191 247 548 191 266 548 minecraft:gray_concrete
setblock 191 247 549 minecraft:pearlescent_froglight
fill 191 247 550 191 266 550 minecraft:gray_concrete
setblock 191 247 551 minecraft:pearlescent_froglight
fill 192 247 547 192 266 547 minecraft:gray_concrete
setblock 192 247 548 minecraft:pearlescent_froglight
fill 192 247 549 192 266 549 minecraft:gray_concrete
setblock 192 247 550 minecraft:pearlescent_froglight
fill 192 247 551 192 267 551 minecraft:gray_concrete
setblock 193 247 547 minecraft:pearlescent_froglight
fill 193 247 548 193 266 548 minecraft:gray_concrete
setblock 193 247 549 minecraft:pearlescent_froglight
fill 193 247 550 193 266 550 minecraft:gray_concrete
setblock 193 247 551 minecraft:pearlescent_froglight
fill 194 247 547 194 266 547 minecraft:gray_concrete
setblock 194 247 548 minecraft:pearlescent_froglight
fill 194 247 549 194 266 549 minecraft:gray_concrete
setblock 194 247 550 minecraft:pearlescent_froglight
fill 194 247 551 194 267 551 minecraft:gray_concrete
setblock 195 247 547 minecraft:pearlescent_froglight
fill 195 247 548 195 266 548 minecraft:gray_concrete
setblock 195 247 549 minecraft:pearlescent_froglight
fill 195 247 550 195 266 550 minecraft:gray_concrete
setblock 195 247 551 minecraft:pearlescent_froglight
fill 203 247 524 203 249 524 minecraft:white_concrete
fill 203 247 530 203 249 530 minecraft:white_concrete
fill 204 247 524 206 248 524 minecraft:green_terracotta
fill 204 247 530 206 248 530 minecraft:lime_terracotta
fill 206 247 523 206 251 523 minecraft:green_terracotta
fill 206 247 531 206 251 531 minecraft:lime_terracotta
fill 207 247 523 207 249 524 minecraft:white_concrete
fill 207 247 530 207 249 531 minecraft:white_concrete
fill 208 247 523 212 247 523 minecraft:green_terracotta
fill 208 247 531 212 247 531 minecraft:lime_terracotta
fill 212 247 524 212 248 524 minecraft:green_terracotta
fill 212 247 530 212 248 530 minecraft:lime_terracotta
fill 213 247 523 213 249 524 minecraft:white_concrete
fill 213 247 530 213 249 531 minecraft:white_concrete
fill 214 247 523 215 247 524 minecraft:green_terracotta
fill 214 247 530 215 247 531 minecraft:lime_terracotta
fill 216 247 524 216 249 524 minecraft:white_concrete
fill 216 247 530 216 249 530 minecraft:white_concrete
fill 188 248 515 188 255 515 minecraft:black_concrete
fill 188 248 523 188 255 523 minecraft:black_concrete
fill 188 248 531 188 255 531 minecraft:black_concrete
fill 188 248 539 188 255 539 minecraft:black_concrete
fill 188 248 547 188 255 547 minecraft:black_concrete
fill 189 248 547 189 249 547 minecraft:gray_concrete
fill 189 248 549 189 249 549 minecraft:gray_concrete
fill 189 248 551 189 249 551 minecraft:gray_concrete
fill 190 248 548 190 249 548 minecraft:gray_concrete
fill 190 248 550 190 249 550 minecraft:gray_concrete
fill 191 248 547 191 249 547 minecraft:gray_concrete
fill 191 248 549 191 249 549 minecraft:gray_concrete
fill 191 248 551 191 249 551 minecraft:gray_concrete
fill 191 248 552 191 255 552 minecraft:black_concrete
fill 192 248 548 192 249 548 minecraft:gray_concrete
fill 192 248 550 192 249 550 minecraft:gray_concrete
fill 193 248 547 193 249 547 minecraft:gray_concrete
fill 193 248 549 193 249 549 minecraft:gray_concrete
fill 193 248 551 193 249 551 minecraft:gray_concrete
fill 194 248 548 194 249 548 minecraft:gray_concrete
fill 194 248 550 194 249 550 minecraft:gray_concrete
fill 195 248 510 195 255 510 minecraft:black_concrete
fill 195 248 547 195 249 547 minecraft:gray_concrete
fill 195 248 549 195 249 549 minecraft:gray_concrete
fill 195 248 551 195 249 551 minecraft:gray_concrete
fill 199 248 552 199 255 552 minecraft:black_concrete
fill 202 248 524 202 249 524 minecraft:white_concrete
fill 202 248 530 202 249 530 minecraft:white_concrete
fill 203 248 510 203 255 510 minecraft:black_concrete
fill 203 248 523 203 249 523 minecraft:white_concrete
fill 203 248 531 203 249 531 minecraft:white_concrete
fill 204 248 523 205 251 523 minecraft:green_terracotta
fill 204 248 531 205 251 531 minecraft:lime_terracotta
fill 207 248 552 207 255 552 minecraft:black_concrete
fill 208 248 523 208 249 524 minecraft:white_concrete
fill 208 248 530 208 249 531 minecraft:white_concrete
fill 210 248 523 212 248 523 minecraft:green_terracotta
fill 210 248 531 212 248 531 minecraft:lime_terracotta
fill 211 248 510 211 255 510 minecraft:black_concrete
fill 214 248 523 215 248 523 minecraft:green_terracotta
fill 214 248 524 214 249 524 minecraft:white_concrete
fill 214 248 530 214 249 530 minecraft:white_concrete
fill 214 248 531 215 248 531 minecraft:lime_terracotta
setblock 215 248 524 minecraft:green_terracotta
setblock 215 248 530 minecraft:lime_terracotta
fill 215 248 552 215 255 552 minecraft:black_concrete
fill 219 248 510 219 255 510 minecraft:black_concrete
fill 223 248 552 223 255 552 minecraft:black_concrete
fill 227 248 510 227 255 510 minecraft:black_concrete
fill 230 248 515 230 255 515 minecraft:black_concrete
fill 230 248 523 230 255 523 minecraft:black_concrete
fill 230 248 531 230 255 531 minecraft:black_concrete
fill 230 248 539 230 255 539 minecraft:black_concrete
fill 230 248 547 230 255 547 minecraft:black_concrete
setblock 191 249 513 minecraft:light[level=10]
setblock 191 249 521 minecraft:light[level=10]
setblock 191 249 529 minecraft:light[level=10]
setblock 191 249 537 minecraft:light[level=10]
setblock 191 249 545 minecraft:light[level=10]
setblock 199 249 513 minecraft:light[level=10]
setblock 199 249 529 minecraft:light[level=10]
setblock 199 249 537 minecraft:light[level=10]
setblock 199 249 545 minecraft:light[level=10]
setblock 204 249 517 minecraft:green_terracotta
fill 204 249 524 205 249 524 minecraft:green_terracotta
fill 204 249 530 205 249 530 minecraft:lime_terracotta
setblock 204 249 537 minecraft:lime_terracotta
setblock 207 249 513 minecraft:light[level=10]
setblock 207 249 525 minecraft:white_concrete
setblock 207 249 529 minecraft:white_concrete
setblock 207 249 545 minecraft:light[level=10]
fill 211 249 523 212 249 523 minecraft:green_terracotta
fill 211 249 531 212 249 531 minecraft:lime_terracotta
setblock 213 249 525 minecraft:white_concrete
setblock 213 249 529 minecraft:white_concrete
setblock 214 249 517 minecraft:green_terracotta
setblock 214 249 523 minecraft:white_concrete
setblock 214 249 531 minecraft:white_concrete
setblock 214 249 537 minecraft:lime_terracotta
setblock 215 249 513 minecraft:light[level=10]
fill 215 249 523 215 250 523 minecraft:green_terracotta
setblock 215 249 529 minecraft:light[level=10]
fill 215 249 531 215 250 531 minecraft:lime_terracotta
setblock 215 249 537 minecraft:light[level=10]
setblock 215 249 545 minecraft:light[level=10]
setblock 216 249 523 minecraft:white_concrete
setblock 216 249 531 minecraft:white_concrete
setblock 223 249 513 minecraft:light[level=10]
setblock 223 249 521 minecraft:light[level=10]
setblock 223 249 529 minecraft:light[level=10]
setblock 223 249 537 minecraft:light[level=10]
setblock 223 249 545 minecraft:light[level=10]
setblock 189 250 547 minecraft:pearlescent_froglight
setblock 189 250 549 minecraft:pearlescent_froglight
setblock 189 250 551 minecraft:pearlescent_froglight
setblock 190 250 548 minecraft:pearlescent_froglight
setblock 190 250 550 minecraft:pearlescent_froglight
setblock 191 250 547 minecraft:pearlescent_froglight
setblock 191 250 549 minecraft:pearlescent_froglight
setblock 191 250 551 minecraft:pearlescent_froglight
setblock 192 250 548 minecraft:pearlescent_froglight
setblock 192 250 550 minecraft:pearlescent_froglight
setblock 193 250 547 minecraft:pearlescent_froglight
setblock 193 250 549 minecraft:pearlescent_froglight
setblock 193 250 551 minecraft:pearlescent_froglight
setblock 194 250 548 minecraft:pearlescent_froglight
setblock 194 250 550 minecraft:pearlescent_froglight
setblock 195 250 547 minecraft:pearlescent_froglight
setblock 195 250 549 minecraft:pearlescent_froglight
setblock 195 250 551 minecraft:pearlescent_froglight
fill 200 250 520 200 250 521 minecraft:green_terracotta
fill 200 250 533 200 250 534 minecraft:lime_terracotta
setblock 203 250 523 minecraft:green_terracotta
setblock 203 250 531 minecraft:lime_terracotta
setblock 205 250 524 minecraft:green_terracotta
setblock 205 250 530 minecraft:lime_terracotta
fill 212 250 523 214 251 523 minecraft:green_terracotta
fill 212 250 531 214 251 531 minecraft:lime_terracotta
setblock 213 250 524 minecraft:green_terracotta
setblock 213 250 530 minecraft:lime_terracotta
setblock 216 250 523 minecraft:green_terracotta
setblock 216 250 531 minecraft:lime_terracotta
setblock 217 250 519 minecraft:green_terracotta
setblock 217 250 522 minecraft:green_terracotta
setblock 217 250 532 minecraft:lime_terracotta
setblock 217 250 535 minecraft:lime_terracotta
fill 189 251 547 189 252 547 minecraft:gray_concrete
fill 189 251 549 189 252 549 minecraft:gray_concrete
fill 189 251 551 189 252 551 minecraft:gray_concrete
fill 190 251 548 190 252 548 minecraft:gray_concrete
fill 190 251 550 190 252 550 minecraft:gray_concrete
fill 191 251 547 191 252 547 minecraft:gray_concrete
fill 191 251 549 191 252 549 minecraft:gray_concrete
fill 191 251 551 191 252 551 minecraft:gray_concrete
fill 192 251 548 192 252 548 minecraft:gray_concrete
fill 192 251 550 192 252 550 minecraft:gray_concrete
fill 193 251 547 193 252 547 minecraft:gray_concrete
fill 193 251 549 193 252 549 minecraft:gray_concrete
fill 193 251 551 193 252 551 minecraft:gray_concrete
fill 194 251 548 194 252 548 minecraft:gray_concrete
fill 194 251 550 194 252 550 minecraft:gray_concrete
fill 195 251 547 195 252 547 minecraft:gray_concrete
fill 195 251 549 195 252 549 minecraft:gray_concrete
fill 195 251 551 195 252 551 minecraft:gray_concrete
fill 204 251 518 205 251 518 minecraft:green_terracotta
fill 204 251 536 205 251 536 minecraft:lime_terracotta
fill 213 251 518 214 251 518 minecraft:green_terracotta
fill 213 251 536 214 251 536 minecraft:lime_terracotta
fill 189 252 511 189 253 516 minecraft:gray_concrete
fill 189 252 519 190 252 524 minecraft:gray_concrete
fill 189 252 527 190 252 532 minecraft:gray_concrete
fill 189 252 535 190 252 540 minecraft:gray_concrete
fill 189 252 543 190 252 546 minecraft:gray_concrete
fill 190 252 512 190 252 518 minecraft:gray_concrete
fill 190 252 525 190 252 526 minecraft:gray_concrete
fill 190 252 533 190 252 534 minecraft:gray_concrete
fill 190 252 541 190 252 542 minecraft:gray_concrete
fill 191 252 512 228 252 512 minecraft:gray_concrete
fill 192 252 511 197 253 511 minecraft:gray_concrete
fill 196 252 550 229 252 550 minecraft:gray_concrete
fill 197 252 551 202 253 551 minecraft:gray_concrete
fill 200 252 511 205 253 511 minecraft:gray_concrete
fill 202 252 521 204 253 521 minecraft:pearlescent_froglight
fill 202 252 533 204 253 533 minecraft:pearlescent_froglight
fill 203 252 520 203 253 520 minecraft:pearlescent_froglight
fill 203 252 522 203 253 522 minecraft:pearlescent_froglight
fill 203 252 532 203 253 532 minecraft:pearlescent_froglight
fill 203 252 534 203 253 534 minecraft:pearlescent_froglight
fill 204 252 519 204 252 520 minecraft:green_terracotta
setblock 204 252 522 minecraft:green_terracotta
setblock 204 252 532 minecraft:lime_terracotta
fill 204 252 534 204 252 535 minecraft:lime_terracotta
fill 205 252 551 210 253 551 minecraft:gray_concrete
fill 207 252 518 211 252 518 minecraft:green_terracotta
fill 207 252 522 208 252 522 minecraft:green_terracotta
fill 207 252 532 208 252 532 minecraft:lime_terracotta
fill 207 252 536 211 252 536 minecraft:lime_terracotta
fill 208 252 511 213 253 511 minecraft:gray_concrete
fill 210 252 522 214 252 522 minecraft:green_terracotta
fill 210 252 532 214 252 532 minecraft:lime_terracotta
fill 212 252 519 214 252 519 minecraft:green_terracotta
fill 212 252 535 214 252 535 minecraft:lime_terracotta
fill 213 252 551 218 253 551 minecraft:gray_concrete
fill 216 252 511 221 253 511 minecraft:gray_concrete
fill 221 252 551 226 253 551 minecraft:gray_concrete
fill 222 252 520 226 253 524 minecraft:black_concrete
fill 224 252 511 229 253 511 minecraft:gray_concrete
setblock 227 252 522 minecraft:black_concrete
fill 228 252 513 228 252 549 minecraft:gray_concrete
fill 229 252 514 229 253 519 minecraft:gray_concrete
fill 229 252 522 229 253 527 minecraft:gray_concrete
fill 229 252 530 229 253 535 minecraft:gray_concrete
fill 229 252 538 229 253 543 minecraft:gray_concrete
fill 229 252 546 229 253 549 minecraft:gray_concrete
fill 229 252 551 229 253 551 minecraft:gray_concrete
fill 189 253 519 189 253 524 minecraft:gray_concrete
fill 189 253 527 189 253 532 minecraft:gray_concrete
fill 189 253 535 189 253 540 minecraft:gray_concrete
fill 189 253 543 189 253 546 minecraft:gray_concrete
setblock 189 253 547 minecraft:pearlescent_froglight
setblock 189 253 549 minecraft:pearlescent_froglight
setblock 189 253 551 minecraft:pearlescent_froglight
setblock 190 253 548 minecraft:pearlescent_froglight
setblock 190 253 550 minecraft:pearlescent_froglight
setblock 191 253 547 minecraft:pearlescent_froglight
setblock 191 253 549 minecraft:pearlescent_froglight
setblock 191 253 551 minecraft:pearlescent_froglight
setblock 192 253 548 minecraft:pearlescent_froglight
setblock 192 253 550 minecraft:pearlescent_froglight
setblock 193 253 547 minecraft:pearlescent_froglight
setblock 193 253 549 minecraft:pearlescent_froglight
setblock 193 253 551 minecraft:pearlescent_froglight
setblock 194 253 548 minecraft:pearlescent_froglight
setblock 194 253 550 minecraft:pearlescent_froglight
setblock 195 253 547 minecraft:pearlescent_froglight
setblock 195 253 549 minecraft:pearlescent_froglight
setblock 195 253 551 minecraft:pearlescent_froglight
fill 206 253 520 212 253 521 minecraft:green_terracotta
fill 206 253 533 212 253 534 minecraft:lime_terracotta
fill 213 253 512 213 257 512 minecraft:white_concrete
setblock 229 253 550 minecraft:gray_concrete
fill 189 254 547 189 255 547 minecraft:gray_concrete
fill 189 254 549 189 255 549 minecraft:gray_concrete
fill 189 254 551 189 255 551 minecraft:gray_concrete
fill 190 254 548 190 255 548 minecraft:gray_concrete
fill 190 254 550 190 255 550 minecraft:gray_concrete
fill 191 254 547 191 255 547 minecraft:gray_concrete
fill 191 254 549 191 255 549 minecraft:gray_concrete
fill 191 254 551 191 255 551 minecraft:gray_concrete
fill 192 254 548 192 255 548 minecraft:gray_concrete
fill 192 254 550 192 255 550 minecraft:gray_concrete
fill 193 254 547 193 255 547 minecraft:gray_concrete
fill 193 254 549 193 255 549 minecraft:gray_concrete
fill 193 254 551 193 255 551 minecraft:gray_concrete
fill 194 254 548 194 255 548 minecraft:gray_concrete
fill 194 254 550 194 255 550 minecraft:gray_concrete
fill 195 254 547 195 255 547 minecraft:gray_concrete
fill 195 254 549 195 255 549 minecraft:gray_concrete
fill 195 254 551 195 255 551 minecraft:gray_concrete
fill 213 254 513 213 257 513 minecraft:white_concrete
fill 223 254 521 225 255 523 minecraft:gray_concrete
fill 188 256 515 188 261 515 minecraft:pearlescent_froglight
fill 188 256 523 188 261 523 minecraft:pearlescent_froglight
fill 188 256 531 188 261 531 minecraft:pearlescent_froglight
fill 188 256 539 188 261 539 minecraft:pearlescent_froglight
fill 188 256 547 189 256 547 minecraft:pearlescent_froglight
setblock 189 256 549 minecraft:pearlescent_froglight
setblock 189 256 551 minecraft:pearlescent_froglight
setblock 190 256 548 minecraft:pearlescent_froglight
setblock 190 256 550 minecraft:pearlescent_froglight
setblock 191 256 547 minecraft:pearlescent_froglight
setblock 191 256 549 minecraft:pearlescent_froglight
fill 191 256 551 191 256 552 minecraft:pearlescent_froglight
setblock 192 256 548 minecraft:pearlescent_froglight
setblock 192 256 550 minecraft:pearlescent_froglight
setblock 193 256 547 minecraft:pearlescent_froglight
setblock 193 256 549 minecraft:pearlescent_froglight
setblock 193 256 551 minecraft:pearlescent_froglight
setblock 194 256 548 minecraft:pearlescent_froglight
setblock 194 256 550 minecraft:pearlescent_froglight
fill 195 256 510 195 261 510 minecraft:pearlescent_froglight
setblock 195 256 547 minecraft:pearlescent_froglight
setblock 195 256 549 minecraft:pearlescent_froglight
setblock 195 256 551 minecraft:pearlescent_froglight
fill 199 256 552 199 261 552 minecraft:pearlescent_froglight
fill 202 256 511 202 257 513 minecraft:gray_concrete
fill 203 256 510 203 261 510 minecraft:pearlescent_froglight
fill 207 256 552 207 261 552 minecraft:pearlescent_froglight
fill 211 256 510 211 261 510 minecraft:pearlescent_froglight
fill 212 256 512 212 257 513 minecraft:white_concrete
fill 213 256 511 213 257 511 minecraft:white_concrete
fill 214 256 512 214 257 513 minecraft:white_concrete
fill 215 256 552 215 261 552 minecraft:pearlescent_froglight
fill 219 256 510 219 261 510 minecraft:pearlescent_froglight
fill 223 256 522 225 258 522 minecraft:gray_concrete
fill 223 256 552 223 261 552 minecraft:pearlescent_froglight
fill 224 256 521 224 258 521 minecraft:gray_concrete
fill 224 256 523 224 258 523 minecraft:gray_concrete
fill 227 256 510 227 261 510 minecraft:pearlescent_froglight
fill 230 256 515 230 261 515 minecraft:pearlescent_froglight
fill 230 256 523 230 261 523 minecraft:pearlescent_froglight
fill 230 256 531 230 261 531 minecraft:pearlescent_froglight
fill 230 256 539 230 261 539 minecraft:pearlescent_froglight
fill 230 256 547 230 261 547 minecraft:pearlescent_froglight
fill 188 257 547 188 261 547 minecraft:pearlescent_froglight
fill 189 257 547 189 258 547 minecraft:gray_concrete
fill 189 257 549 189 258 549 minecraft:gray_concrete
fill 189 257 551 189 258 551 minecraft:gray_concrete
fill 190 257 548 190 258 548 minecraft:gray_concrete
fill 190 257 550 190 258 550 minecraft:gray_concrete
setblock 191 257 513 minecraft:light[level=10]
setblock 191 257 521 minecraft:light[level=10]
setblock 191 257 529 minecraft:light[level=10]
setblock 191 257 537 minecraft:light[level=10]
setblock 191 257 545 minecraft:light[level=10]
fill 191 257 547 191 258 547 minecraft:gray_concrete
fill 191 257 549 191 258 549 minecraft:gray_concrete
fill 191 257 551 191 258 551 minecraft:gray_concrete
fill 191 257 552 191 261 552 minecraft:pearlescent_froglight
fill 192 257 548 192 258 548 minecraft:gray_concrete
fill 192 257 550 192 258 550 minecraft:gray_concrete
fill 193 257 547 193 258 547 minecraft:gray_concrete
fill 193 257 549 193 258 549 minecraft:gray_concrete
fill 193 257 551 193 258 551 minecraft:gray_concrete
fill 194 257 548 194 258 548 minecraft:gray_concrete
fill 194 257 550 194 258 550 minecraft:gray_concrete
fill 195 257 547 195 258 547 minecraft:gray_concrete
fill 195 257 549 195 258 549 minecraft:gray_concrete
fill 195 257 551 195 258 551 minecraft:gray_concrete
setblock 199 257 513 minecraft:light[level=10]
setblock 199 257 521 minecraft:light[level=10]
setblock 199 257 529 minecraft:light[level=10]
setblock 199 257 537 minecraft:light[level=10]
setblock 199 257 545 minecraft:light[level=10]
setblock 207 257 513 minecraft:light[level=10]
setblock 207 257 537 minecraft:light[level=10]
setblock 207 257 545 minecraft:light[level=10]
setblock 215 257 513 minecraft:light[level=10]
setblock 215 257 521 minecraft:light[level=10]
setblock 215 257 537 minecraft:light[level=10]
setblock 215 257 545 minecraft:light[level=10]
fill 220 257 514 220 262 514 minecraft:white_concrete
setblock 223 257 513 minecraft:light[level=10]
setblock 223 257 521 minecraft:light[level=10]
setblock 223 257 529 minecraft:light[level=10]
setblock 223 257 537 minecraft:light[level=10]
setblock 223 257 545 minecraft:light[level=10]
fill 210 258 511 213 258 514 minecraft:gray_concrete
fill 214 258 512 216 258 514 minecraft:gray_concrete
fill 216 258 511 216 273 511 minecraft:gray_concrete
fill 220 258 513 220 262 513 minecraft:white_concrete
setblock 189 259 547 minecraft:pearlescent_froglight
setblock 189 259 549 minecraft:pearlescent_froglight
setblock 189 259 551 minecraft:pearlescent_froglight
setblock 190 259 548 minecraft:pearlescent_froglight
setblock 190 259 550 minecraft:pearlescent_froglight
setblock 191 259 547 minecraft:pearlescent_froglight
setblock 191 259 549 minecraft:pearlescent_froglight
setblock 191 259 551 minecraft:pearlescent_froglight
setblock 192 259 548 minecraft:pearlescent_froglight
setblock 192 259 550 minecraft:pearlescent_froglight
setblock 193 259 547 minecraft:pearlescent_froglight
setblock 193 259 549 minecraft:pearlescent_froglight
setblock 193 259 551 minecraft:pearlescent_froglight
setblock 194 259 548 minecraft:pearlescent_froglight
setblock 194 259 550 minecraft:pearlescent_froglight
setblock 195 259 547 minecraft:pearlescent_froglight
setblock 195 259 549 minecraft:pearlescent_froglight
setblock 195 259 551 minecraft:pearlescent_froglight
fill 210 259 511 210 273 511 minecraft:gray_concrete
setblock 210 259 512 minecraft:pearlescent_froglight
fill 210 259 513 210 273 513 minecraft:gray_concrete
setblock 210 259 514 minecraft:pearlescent_froglight
setblock 211 259 511 minecraft:pearlescent_froglight
fill 211 259 512 211 273 512 minecraft:gray_concrete
setblock 211 259 513 minecraft:pearlescent_froglight
fill 211 259 514 211 273 514 minecraft:gray_concrete
fill 212 259 511 212 273 511 minecraft:gray_concrete
setblock 212 259 512 minecraft:pearlescent_froglight
fill 212 259 513 212 273 513 minecraft:gray_concrete
setblock 212 259 514 minecraft:pearlescent_froglight
setblock 213 259 511 minecraft:pearlescent_froglight
fill 213 259 512 213 273 512 minecraft:gray_concrete
setblock 213 259 513 minecraft:pearlescent_froglight
fill 213 259 514 213 273 514 minecraft:gray_concrete
fill 214 259 511 214 273 511 minecraft:gray_concrete
setblock 214 259 512 minecraft:pearlescent_froglight
fill 214 259 513 214 273 513 minecraft:gray_concrete
setblock 214 259 514 minecraft:pearlescent_froglight
setblock 215 259 511 minecraft:pearlescent_froglight
fill 215 259 512 215 273 512 minecraft:gray_concrete
setblock 215 259 513 minecraft:pearlescent_froglight
fill 215 259 514 215 273 514 minecraft:gray_concrete
setblock 216 259 512 minecraft:pearlescent_froglight
fill 216 259 513 216 273 513 minecraft:gray_concrete
setblock 216 259 514 minecraft:pearlescent_froglight
fill 219 259 513 219 262 514 minecraft:white_concrete
fill 220 259 515 220 262 515 minecraft:white_concrete
fill 221 259 513 221 262 514 minecraft:white_concrete
fill 224 259 522 224 263 522 minecraft:gray_concrete
fill 189 260 547 189 261 547 minecraft:gray_concrete
fill 189 260 549 189 261 549 minecraft:gray_concrete
fill 189 260 551 189 261 551 minecraft:gray_concrete
fill 190 260 548 190 261 548 minecraft:gray_concrete
fill 190 260 550 190 261 550 minecraft:gray_concrete
fill 191 260 547 191 261 547 minecraft:gray_concrete
fill 191 260 549 191 261 549 minecraft:gray_concrete
fill 191 260 551 191 261 551 minecraft:gray_concrete
fill 192 260 548 192 261 548 minecraft:gray_concrete
fill 192 260 550 192 261 550 minecraft:gray_concrete
fill 193 260 547 193 261 547 minecraft:gray_concrete
fill 193 260 549 193 261 549 minecraft:gray_concrete
fill 193 260 551 193 261 551 minecraft:gray_concrete
fill 194 260 548 194 261 548 minecraft:gray_concrete
fill 194 260 550 194 261 550 minecraft:gray_concrete
fill 195 260 547 195 261 547 minecraft:gray_concrete
fill 195 260 549 195 261 549 minecraft:gray_concrete
fill 195 260 551 195 261 551 minecraft:gray_concrete
fill 210 260 512 210 261 512 minecraft:gray_concrete
fill 210 260 514 210 261 514 minecraft:gray_concrete
fill 211 260 511 211 261 511 minecraft:gray_concrete
fill 211 260 513 211 261 513 minecraft:gray_concrete
fill 212 260 512 212 261 512 minecraft:gray_concrete
fill 212 260 514 212 261 514 minecraft:gray_concrete
fill 213 260 511 213 261 511 minecraft:gray_concrete
fill 213 260 513 213 261 513 minecraft:gray_concrete
fill 214 260 512 214 261 512 minecraft:gray_concrete
fill 214 260 514 214 261 514 minecraft:gray_concrete
fill 215 260 511 215 261 511 minecraft:gray_concrete
fill 215 260 513 215 261 513 minecraft:gray_concrete
fill 216 260 512 216 261 512 minecraft:gray_concrete
fill 216 260 514 216 261 514 minecraft:gray_concrete
fill 219 260 515 219 262 515 minecraft:white_concrete
fill 220 260 512 220 262 512 minecraft:white_concrete
fill 221 260 515 221 262 515 minecraft:white_concrete
fill 218 261 513 218 262 514 minecraft:white_concrete
fill 219 261 512 219 262 512 minecraft:white_concrete
fill 220 261 516 220 262 516 minecraft:white_concrete
fill 221 261 512 221 262 512 minecraft:white_concrete
fill 222 261 513 222 262 514 minecraft:white_concrete
fill 188 262 515 188 269 515 minecraft:black_concrete
fill 188 262 523 188 269 523 minecraft:black_concrete
fill 188 262 531 188 269 531 minecraft:black_concrete
fill 188 262 539 188 269 539 minecraft:black_concrete
fill 188 262 547 188 269 547 minecraft:black_concrete
setblock 189 262 547 minecraft:pearlescent_froglight
setblock 189 262 549 minecraft:pearlescent_froglight
setblock 189 262 551 minecraft:pearlescent_froglight
setblock 190 262 548 minecraft:pearlescent_froglight
setblock 190 262 550 minecraft:pearlescent_froglight
setblock 191 262 547 minecraft:pearlescent_froglight
setblock 191 262 549 minecraft:pearlescent_froglight
setblock 191 262 551 minecraft:pearlescent_froglight
fill 191 262 552 191 269 552 minecraft:black_concrete
setblock 192 262 548 minecraft:pearlescent_froglight
setblock 192 262 550 minecraft:pearlescent_froglight
setblock 193 262 547 minecraft:pearlescent_froglight
setblock 193 262 549 minecraft:pearlescent_froglight
setblock 193 262 551 minecraft:pearlescent_froglight
setblock 194 262 548 minecraft:pearlescent_froglight
setblock 194 262 550 minecraft:pearlescent_froglight
fill 195 262 510 195 269 510 minecraft:black_concrete
setblock 195 262 547 minecraft:pearlescent_froglight
setblock 195 262 549 minecraft:pearlescent_froglight
setblock 195 262 551 minecraft:pearlescent_froglight
fill 199 262 552 199 269 552 minecraft:black_concrete
fill 203 262 510 203 269 510 minecraft:black_concrete
fill 207 262 552 207 269 552 minecraft:black_concrete
setblock 210 262 512 minecraft:pearlescent_froglight
setblock 210 262 514 minecraft:pearlescent_froglight
fill 211 262 510 211 269 510 minecraft:black_concrete
setblock 211 262 511 minecraft:pearlescent_froglight
setblock 211 262 513 minecraft:pearlescent_froglight
setblock 212 262 512 minecraft:pearlescent_froglight
setblock 212 262 514 minecraft:pearlescent_froglight
setblock 213 262 511 minecraft:pearlescent_froglight
setblock 213 262 513 minecraft:pearlescent_froglight
setblock 214 262 512 minecraft:pearlescent_froglight
setblock 214 262 514 minecraft:pearlescent_froglight
setblock 215 262 511 minecraft:pearlescent_froglight
setblock 215 262 513 minecraft:pearlescent_froglight
fill 215 262 552 215 269 552 minecraft:black_concrete
setblock 216 262 512 minecraft:pearlescent_froglight
setblock 216 262 514 minecraft:pearlescent_froglight
setblock 218 262 512 minecraft:white_concrete
setblock 218 262 515 minecraft:white_concrete
fill 219 262 510 219 269 510 minecraft:black_concrete
setblock 219 262 516 minecraft:white_concrete
setblock 220 262 511 minecraft:white_concrete
setblock 221 262 516 minecraft:white_concrete
setblock 222 262 512 minecraft:white_concrete
setblock 222 262 515 minecraft:white_concrete
fill 223 262 552 223 269 552 minecraft:black_concrete
fill 227 262 510 227 269 510 minecraft:black_concrete
fill 230 262 515 230 269 515 minecraft:black_concrete
fill 230 262 523 230 269 523 minecraft:black_concrete
fill 230 262 531 230 269 531 minecraft:black_concrete
fill 230 262 539 230 269 539 minecraft:black_concrete
fill 230 262 547 230 269 547 minecraft:black_concrete
fill 189 263 547 189 264 547 minecraft:gray_concrete
fill 189 263 549 189 264 549 minecraft:gray_concrete
fill 189 263 551 189 264 551 minecraft:gray_concrete
fill 190 263 548 190 264 548 minecraft:gray_concrete
fill 190 263 550 190 264 550 minecraft:gray_concrete
fill 191 263 547 191 264 547 minecraft:gray_concrete
fill 191 263 549 191 264 549 minecraft:gray_concrete
fill 191 263 551 191 264 551 minecraft:gray_concrete
fill 192 263 548 192 264 548 minecraft:gray_concrete
fill 192 263 550 192 264 550 minecraft:gray_concrete
fill 193 263 547 193 264 547 minecraft:gray_concrete
fill 193 263 549 193 264 549 minecraft:gray_concrete
fill 193 263 551 193 264 551 minecraft:gray_concrete
fill 194 263 548 194 264 548 minecraft:gray_concrete
fill 194 263 550 194 264 550 minecraft:gray_concrete
fill 195 263 547 195 264 547 minecraft:gray_concrete
fill 195 263 549 195 264 549 minecraft:gray_concrete
fill 195 263 551 195 264 551 minecraft:gray_concrete
fill 210 263 512 210 264 512 minecraft:gray_concrete
fill 210 263 514 210 264 514 minecraft:gray_concrete
fill 211 263 511 211 264 511 minecraft:gray_concrete
fill 211 263 513 211 264 513 minecraft:gray_concrete
fill 212 263 512 212 264 512 minecraft:gray_concrete
fill 212 263 514 212 264 514 minecraft:gray_concrete
fill 213 263 511 213 264 511 minecraft:gray_concrete
fill 213 263 513 213 264 513 minecraft:gray_concrete
fill 214 263 512 214 264 512 minecraft:gray_concrete
fill 214 263 514 214 264 514 minecraft:gray_concrete
fill 215 263 511 215 264 511 minecraft:gray_concrete
fill 215 263 513 215 264 513 minecraft:gray_concrete
fill 215 263 515 225 273 517 minecraft:gray_concrete
fill 216 263 512 225 264 512 minecraft:gray_concrete
fill 216 263 514 225 264 514 minecraft:gray_concrete
fill 217 263 511 221 273 511 minecraft:gray_concrete
fill 217 263 513 225 273 513 minecraft:gray_concrete
fill 224 263 511 225 273 511 minecraft:gray_concrete
setblock 224 264 522 minecraft:pearlescent_froglight
setblock 189 265 547 minecraft:pearlescent_froglight
setblock 189 265 549 minecraft:pearlescent_froglight
setblock 189 265 551 minecraft:pearlescent_froglight
setblock 190 265 548 minecraft:pearlescent_froglight
setblock 190 265 550 minecraft:pearlescent_froglight
setblock 191 265 513 minecraft:light[level=10]
setblock 191 265 521 minecraft:light[level=10]
setblock 191 265 529 minecraft:light[level=10]
setblock 191 265 537 minecraft:light[level=10]
setblock 191 265 545 minecraft:light[level=10]
setblock 191 265 547 minecraft:pearlescent_froglight
setblock 191 265 549 minecraft:pearlescent_froglight
setblock 191 265 551 minecraft:pearlescent_froglight
setblock 192 265 548 minecraft:pearlescent_froglight
setblock 192 265 550 minecraft:pearlescent_froglight
setblock 193 265 547 minecraft:pearlescent_froglight
setblock 193 265 549 minecraft:pearlescent_froglight
setblock 193 265 551 minecraft:pearlescent_froglight
setblock 194 265 548 minecraft:pearlescent_froglight
setblock 194 265 550 minecraft:pearlescent_froglight
setblock 195 265 547 minecraft:pearlescent_froglight
setblock 195 265 549 minecraft:pearlescent_froglight
setblock 195 265 551 minecraft:pearlescent_froglight
setblock 199 265 513 minecraft:light[level=10]
setblock 199 265 521 minecraft:light[level=10]
setblock 199 265 529 minecraft:light[level=10]
setblock 199 265 537 minecraft:light[level=10]
setblock 199 265 545 minecraft:light[level=10]
setblock 207 265 513 minecraft:light[level=10]
setblock 207 265 521 minecraft:light[level=10]
setblock 207 265 537 minecraft:light[level=10]
setblock 207 265 545 minecraft:light[level=10]
setblock 210 265 512 minecraft:pearlescent_froglight
setblock 210 265 514 minecraft:pearlescent_froglight
setblock 211 265 511 minecraft:pearlescent_froglight
setblock 211 265 513 minecraft:pearlescent_froglight
setblock 212 265 512 minecraft:pearlescent_froglight
setblock 212 265 514 minecraft:pearlescent_froglight
setblock 213 265 511 minecraft:pearlescent_froglight
setblock 213 265 513 minecraft:pearlescent_froglight
setblock 214 265 512 minecraft:pearlescent_froglight
setblock 214 265 514 minecraft:pearlescent_froglight
setblock 215 265 511 minecraft:pearlescent_froglight
setblock 215 265 513 minecraft:pearlescent_froglight
setblock 215 265 521 minecraft:light[level=10]
setblock 215 265 529 minecraft:light[level=10]
setblock 215 265 537 minecraft:light[level=10]
setblock 215 265 545 minecraft:light[level=10]
setblock 216 265 512 minecraft:pearlescent_froglight
setblock 216 265 514 minecraft:pearlescent_froglight
fill 217 265 512 225 273 512 minecraft:gray_concrete
fill 217 265 514 225 273 514 minecraft:gray_concrete
setblock 223 265 521 minecraft:light[level=10]
setblock 223 265 529 minecraft:light[level=10]
setblock 223 265 537 minecraft:light[level=10]
setblock 223 265 545 minecraft:light[level=10]
fill 189 266 511 189 267 516 minecraft:gray_concrete
fill 189 266 519 190 266 524 minecraft:gray_concrete
fill 189 266 527 190 266 532 minecraft:gray_concrete
fill 189 266 535 190 266 540 minecraft:gray_concrete
fill 189 266 543 189 267 547 minecraft:gray_concrete
fill 189 266 549 189 273 549 minecraft:gray_concrete
fill 189 266 551 189 267 551 minecraft:gray_concrete
fill 190 266 512 190 266 518 minecraft:gray_concrete
fill 190 266 525 190 266 526 minecraft:gray_concrete
fill 190 266 533 190 266 534 minecraft:gray_concrete
fill 190 266 541 190 266 546 minecraft:gray_concrete
setblock 190 266 548 minecraft:gray_concrete
setblock 190 266 550 minecraft:gray_concrete
fill 191 266 512 210 266 512 minecraft:gray_concrete
setblock 191 266 547 minecraft:gray_concrete
setblock 191 266 549 minecraft:gray_concrete
fill 191 266 551 191 267 551 minecraft:gray_concrete
fill 192 266 511 197 267 511 minecraft:gray_concrete
setblock 192 266 548 minecraft:gray_concrete
setblock 192 266 550 minecraft:gray_concrete
setblock 193 266 547 minecraft:gray_concrete
setblock 193 266 549 minecraft:gray_concrete
fill 193 266 551 193 267 551 minecraft:gray_concrete
setblock 194 266 548 minecraft:gray_concrete
setblock 194 266 550 minecraft:gray_concrete
setblock 195 266 547 minecraft:gray_concrete
setblock 195 266 549 minecraft:gray_concrete
fill 195 266 551 195 273 551 minecraft:gray_concrete
fill 196 266 550 229 266 550 minecraft:gray_concrete
fill 197 266 551 202 267 551 minecraft:gray_concrete
fill 200 266 511 205 267 511 minecraft:gray_concrete
fill 205 266 551 210 267 551 minecraft:gray_concrete
fill 208 266 511 209 267 511 minecraft:gray_concrete
fill 210 266 514 210 267 514 minecraft:gray_concrete
fill 211 266 511 211 267 511 minecraft:gray_concrete
fill 211 266 513 211 267 513 minecraft:gray_concrete
fill 212 266 512 212 267 512 minecraft:gray_concrete
fill 212 266 514 212 267 514 minecraft:gray_concrete
fill 213 266 511 213 267 511 minecraft:gray_concrete
fill 213 266 513 213 267 513 minecraft:gray_concrete
fill 213 266 551 218 267 551 minecraft:gray_concrete
fill 214 266 512 214 267 512 minecraft:gray_concrete
fill 214 266 514 214 267 514 minecraft:gray_concrete
fill 215 266 511 215 267 511 minecraft:gray_concrete
fill 215 266 513 215 267 513 minecraft:gray_concrete
fill 216 266 512 216 267 512 minecraft:gray_concrete
fill 216 266 514 216 267 514 minecraft:gray_concrete
fill 221 266 551 226 267 551 minecraft:gray_concrete
fill 226 266 511 228 266 512 minecraft:gray_concrete
fill 228 266 513 228 266 549 minecraft:gray_concrete
fill 229 266 511 229 267 511 minecraft:gray_concrete
fill 229 266 514 229 267 519 minecraft:gray_concrete
fill 229 266 522 229 267 527 minecraft:gray_concrete
fill 229 266 530 229 267 535 minecraft:gray_concrete
fill 229 266 538 229 267 543 minecraft:gray_concrete
fill 229 266 546 229 267 549 minecraft:gray_concrete
fill 229 266 551 229 267 551 minecraft:gray_concrete
fill 189 267 519 189 267 524 minecraft:gray_concrete
fill 189 267 527 189 267 532 minecraft:gray_concrete
fill 189 267 535 189 267 540 minecraft:gray_concrete
fill 190 267 548 194 267 550 minecraft:white_concrete
setblock 210 267 512 minecraft:gray_concrete
fill 226 267 511 228 267 511 minecraft:gray_concrete
setblock 229 267 550 minecraft:gray_concrete
fill 191 268 549 193 268 549 minecraft:white_concrete
setblock 210 268 512 minecraft:pearlescent_froglight
setblock 210 268 514 minecraft:pearlescent_froglight
setblock 211 268 511 minecraft:pearlescent_froglight
setblock 211 268 513 minecraft:pearlescent_froglight
setblock 212 268 512 minecraft:pearlescent_froglight
setblock 212 268 514 minecraft:pearlescent_froglight
setblock 213 268 511 minecraft:pearlescent_froglight
setblock 213 268 513 minecraft:pearlescent_froglight
setblock 214 268 512 minecraft:pearlescent_froglight
setblock 214 268 514 minecraft:pearlescent_froglight
setblock 215 268 511 minecraft:pearlescent_froglight
setblock 215 268 513 minecraft:pearlescent_froglight
setblock 216 268 512 minecraft:pearlescent_froglight
setblock 216 268 514 minecraft:pearlescent_froglight
fill 192 269 548 192 270 550 minecraft:white_concrete
fill 210 269 512 210 270 512 minecraft:gray_concrete
fill 210 269 514 210 270 514 minecraft:gray_concrete
fill 211 269 511 211 270 511 minecraft:gray_concrete
fill 211 269 513 211 270 513 minecraft:gray_concrete
fill 212 269 512 212 270 512 minecraft:gray_concrete
fill 212 269 514 212 270 514 minecraft:gray_concrete
fill 213 269 511 213 270 511 minecraft:gray_concrete
fill 213 269 513 213 270 513 minecraft:gray_concrete
fill 214 269 512 214 270 512 minecraft:gray_concrete
fill 214 269 514 214 270 514 minecraft:gray_concrete
fill 215 269 511 215 270 511 minecraft:gray_concrete
fill 215 269 513 215 270 513 minecraft:gray_concrete
fill 216 269 512 216 270 512 minecraft:gray_concrete
fill 216 269 514 216 270 514 minecraft:gray_concrete
fill 188 270 515 188 273 515 minecraft:pearlescent_froglight
fill 188 270 523 188 273 523 minecraft:pearlescent_froglight
fill 188 270 531 188 273 531 minecraft:pearlescent_froglight
fill 188 270 539 188 273 539 minecraft:pearlescent_froglight
fill 188 270 547 188 273 547 minecraft:pearlescent_froglight
fill 191 270 547 191 270 551 minecraft:white_concrete
fill 191 270 552 191 273 552 minecraft:pearlescent_froglight
fill 192 270 547 193 270 547 minecraft:white_concrete
fill 192 270 551 193 270 551 minecraft:white_concrete
fill 193 270 548 193 270 550 minecraft:white_concrete
fill 195 270 510 195 273 510 minecraft:pearlescent_froglight
fill 199 270 552 199 273 552 minecraft:pearlescent_froglight
fill 203 270 510 203 273 510 minecraft:pearlescent_froglight
fill 207 270 552 207 273 552 minecraft:pearlescent_froglight
fill 211 270 510 211 273 510 minecraft:pearlescent_froglight
fill 215 270 552 215 273 552 minecraft:pearlescent_froglight
fill 219 270 510 219 273 510 minecraft:pearlescent_froglight
fill 223 270 552 223 273 552 minecraft:pearlescent_froglight
fill 227 270 510 227 273 510 minecraft:pearlescent_froglight
fill 230 270 515 230 273 515 minecraft:pearlescent_froglight
fill 230 270 523 230 273 523 minecraft:pearlescent_froglight
fill 230 270 531 230 273 531 minecraft:pearlescent_froglight
fill 230 270 539 230 273 539 minecraft:pearlescent_froglight
fill 230 270 547 230 273 547 minecraft:pearlescent_froglight
setblock 210 271 512 minecraft:pearlescent_froglight
setblock 210 271 514 minecraft:pearlescent_froglight
setblock 211 271 511 minecraft:pearlescent_froglight
setblock 211 271 513 minecraft:pearlescent_froglight
setblock 212 271 512 minecraft:pearlescent_froglight
setblock 212 271 514 minecraft:pearlescent_froglight
setblock 213 271 511 minecraft:pearlescent_froglight
setblock 213 271 513 minecraft:pearlescent_froglight
setblock 214 271 512 minecraft:pearlescent_froglight
setblock 214 271 514 minecraft:pearlescent_froglight
setblock 215 271 511 minecraft:pearlescent_froglight
setblock 215 271 513 minecraft:pearlescent_froglight
setblock 216 271 512 minecraft:pearlescent_froglight
setblock 216 271 514 minecraft:pearlescent_froglight
fill 210 272 512 210 273 512 minecraft:gray_concrete
fill 210 272 514 210 273 514 minecraft:gray_concrete
fill 211 272 511 211 273 511 minecraft:gray_concrete
fill 211 272 513 211 273 513 minecraft:gray_concrete
fill 212 272 512 212 273 512 minecraft:gray_concrete
fill 212 272 514 212 273 514 minecraft:gray_concrete
fill 213 272 511 213 273 511 minecraft:gray_concrete
fill 213 272 513 213 273 513 minecraft:gray_concrete
fill 214 272 512 214 273 512 minecraft:gray_concrete
fill 214 272 514 214 273 514 minecraft:gray_concrete
fill 215 272 511 215 273 511 minecraft:gray_concrete
fill 215 272 513 215 273 513 minecraft:gray_concrete
fill 216 272 512 216 273 512 minecraft:gray_concrete
fill 216 272 514 216 273 514 minecraft:gray_concrete
setblock 191 273 513 minecraft:light[level=10]
setblock 191 273 521 minecraft:light[level=10]
setblock 191 273 529 minecraft:light[level=10]
setblock 191 273 537 minecraft:light[level=10]
setblock 191 273 545 minecraft:light[level=10]
setblock 199 273 513 minecraft:light[level=10]
setblock 199 273 521 minecraft:light[level=10]
setblock 199 273 529 minecraft:light[level=10]
setblock 199 273 537 minecraft:light[level=10]
setblock 199 273 545 minecraft:light[level=10]
setblock 207 273 513 minecraft:light[level=10]
setblock 207 273 521 minecraft:light[level=10]
setblock 207 273 537 minecraft:light[level=10]
setblock 207 273 545 minecraft:light[level=10]
setblock 215 273 521 minecraft:light[level=10]
setblock 215 273 529 minecraft:light[level=10]
setblock 215 273 537 minecraft:light[level=10]
setblock 215 273 545 minecraft:light[level=10]
setblock 223 273 521 minecraft:light[level=10]
setblock 223 273 529 minecraft:light[level=10]
setblock 223 273 537 minecraft:light[level=10]
setblock 223 273 545 minecraft:light[level=10]
fill 188 274 515 188 283 515 minecraft:black_concrete
fill 188 274 523 188 283 523 minecraft:black_concrete
fill 188 274 531 188 283 531 minecraft:black_concrete
fill 188 274 539 188 283 539 minecraft:black_concrete
fill 188 274 547 188 283 547 minecraft:black_concrete
fill 191 274 552 191 283 552 minecraft:black_concrete
fill 195 274 510 195 283 510 minecraft:black_concrete
fill 199 274 552 199 283 552 minecraft:black_concrete
fill 203 274 510 203 283 510 minecraft:black_concrete
fill 207 274 552 207 283 552 minecraft:black_concrete
fill 211 274 510 211 283 510 minecraft:black_concrete
fill 215 274 552 215 283 552 minecraft:black_concrete
fill 219 274 510 219 283 510 minecraft:black_concrete
fill 223 274 552 223 283 552 minecraft:black_concrete
fill 227 274 510 227 283 510 minecraft:black_concrete
fill 230 274 515 230 283 515 minecraft:black_concrete
fill 230 274 523 230 283 523 minecraft:black_concrete
fill 230 274 531 230 283 531 minecraft:black_concrete
fill 230 274 539 230 283 539 minecraft:black_concrete
fill 230 274 547 230 283 547 minecraft:black_concrete
fill 189 279 511 189 280 516 minecraft:black_concrete
fill 189 279 517 189 280 517 minecraft:gray_concrete
fill 189 279 518 189 280 525 minecraft:black_concrete
fill 189 279 526 189 280 526 minecraft:gray_concrete
fill 189 279 527 189 280 534 minecraft:black_concrete
fill 189 279 535 189 280 535 minecraft:gray_concrete
fill 189 279 536 189 280 543 minecraft:black_concrete
fill 189 279 544 189 280 544 minecraft:gray_concrete
fill 189 279 545 190 280 551 minecraft:black_concrete
fill 190 279 511 190 280 515 minecraft:black_concrete
fill 190 279 516 190 280 516 minecraft:gray_concrete
fill 190 279 517 190 280 524 minecraft:black_concrete
fill 190 279 525 190 280 525 minecraft:gray_concrete
fill 190 279 526 190 280 533 minecraft:black_concrete
fill 190 279 534 190 280 534 minecraft:gray_concrete
fill 190 279 535 190 280 542 minecraft:black_concrete
fill 190 279 543 190 280 543 minecraft:gray_concrete
fill 190 279 544 197 280 544 minecraft:black_concrete
fill 191 279 511 191 280 514 minecraft:black_concrete
fill 191 279 515 191 280 515 minecraft:gray_concrete
fill 191 279 516 191 280 523 minecraft:black_concrete
fill 191 279 524 191 280 524 minecraft:gray_concrete
fill 191 279 525 191 280 532 minecraft:black_concrete
fill 191 279 533 191 280 533 minecraft:gray_concrete
fill 191 279 534 191 280 541 minecraft:black_concrete
fill 191 279 542 191 280 542 minecraft:gray_concrete
fill 191 279 543 198 280 543 minecraft:black_concrete
fill 191 279 545 191 280 550 minecraft:black_concrete
fill 191 279 551 191 280 551 minecraft:gray_concrete
fill 192 279 511 192 280 513 minecraft:black_concrete
fill 192 279 514 192 280 514 minecraft:gray_concrete
fill 192 279 515 192 280 522 minecraft:black_concrete
fill 192 279 523 192 280 523 minecraft:gray_concrete
fill 192 279 524 192 280 531 minecraft:black_concrete
fill 192 279 532 192 280 532 minecraft:gray_concrete
fill 192 279 533 192 280 540 minecraft:black_concrete
fill 192 279 541 192 280 541 minecraft:gray_concrete
fill 192 279 542 199 280 542 minecraft:black_concrete
fill 192 279 545 192 280 549 minecraft:black_concrete
fill 192 279 550 192 280 550 minecraft:gray_concrete
fill 192 279 551 199 280 551 minecraft:black_concrete
fill 193 279 511 193 280 512 minecraft:black_concrete
fill 193 279 513 193 280 513 minecraft:gray_concrete
fill 193 279 514 193 280 521 minecraft:black_concrete
fill 193 279 522 193 280 522 minecraft:gray_concrete
fill 193 279 523 193 280 530 minecraft:black_concrete
fill 193 279 531 193 280 531 minecraft:gray_concrete
fill 193 279 532 193 280 539 minecraft:black_concrete
fill 193 279 540 193 280 540 minecraft:gray_concrete
fill 193 279 541 200 280 541 minecraft:black_concrete
fill 193 279 545 193 280 548 minecraft:black_concrete
fill 193 279 549 193 280 549 minecraft:gray_concrete
fill 193 279 550 200 280 550 minecraft:black_concrete
fill 194 279 511 194 280 511 minecraft:black_concrete
fill 194 279 512 194 280 512 minecraft:gray_concrete
fill 194 279 513 194 280 520 minecraft:black_concrete
fill 194 279 521 194 280 521 minecraft:gray_concrete
fill 194 279 522 194 280 529 minecraft:black_concrete
fill 194 279 530 194 280 530 minecraft:gray_concrete
fill 194 279 531 194 280 538 minecraft:black_concrete
fill 194 279 539 194 280 539 minecraft:gray_concrete
fill 194 279 540 201 280 540 minecraft:black_concrete
fill 194 279 545 194 280 547 minecraft:black_concrete
fill 194 279 548 194 280 548 minecraft:gray_concrete
fill 194 279 549 201 280 549 minecraft:black_concrete
fill 195 279 511 195 280 511 minecraft:gray_concrete
fill 195 279 512 195 280 519 minecraft:black_concrete
fill 195 279 520 195 280 520 minecraft:gray_concrete
fill 195 279 521 195 280 528 minecraft:black_concrete
fill 195 279 529 195 280 529 minecraft:gray_concrete
fill 195 279 530 195 280 537 minecraft:black_concrete
fill 195 279 538 195 280 538 minecraft:gray_concrete
fill 195 279 539 202 280 539 minecraft:black_concrete
fill 195 279 545 195 280 546 minecraft:black_concrete
fill 195 279 547 195 280 547 minecraft:gray_concrete
fill 195 279 548 202 280 548 minecraft:black_concrete
fill 196 279 511 196 280 518 minecraft:black_concrete
fill 196 279 519 196 280 519 minecraft:gray_concrete
fill 196 279 520 196 280 527 minecraft:black_concrete
fill 196 279 528 196 280 528 minecraft:gray_concrete
fill 196 279 529 196 280 536 minecraft:black_concrete
fill 196 279 537 196 280 537 minecraft:gray_concrete
fill 196 279 538 203 280 538 minecraft:black_concrete
fill 196 279 545 196 280 545 minecraft:black_concrete
fill 196 279 546 196 280 546 minecraft:gray_concrete
fill 196 279 547 203 280 547 minecraft:black_concrete
fill 197 279 511 197 280 517 minecraft:black_concrete
fill 197 279 518 197 280 518 minecraft:gray_concrete
fill 197 279 519 197 280 526 minecraft:black_concrete
fill 197 279 527 197 280 527 minecraft:gray_concrete
fill 197 279 528 197 280 535 minecraft:black_concrete
fill 197 279 536 197 280 536 minecraft:gray_concrete
fill 197 279 537 204 280 537 minecraft:black_concrete
fill 197 279 545 197 280 545 minecraft:gray_concrete
fill 197 279 546 204 280 546 minecraft:black_concrete
fill 198 279 511 198 280 516 minecraft:black_concrete
fill 198 279 517 198 280 517 minecraft:gray_concrete
fill 198 279 518 198 280 525 minecraft:black_concrete
fill 198 279 526 198 280 526 minecraft:gray_concrete
fill 198 279 527 198 280 534 minecraft:black_concrete
fill 198 279 535 198 280 535 minecraft:gray_concrete
fill 198 279 536 205 280 536 minecraft:black_concrete
fill 198 279 544 198 280 544 minecraft:gray_concrete
fill 198 279 545 205 280 545 minecraft:black_concrete
fill 199 279 511 199 280 515 minecraft:black_concrete
fill 199 279 516 199 280 516 minecraft:gray_concrete
fill 199 279 517 199 280 524 minecraft:black_concrete
fill 199 279 525 199 280 525 minecraft:gray_concrete
fill 199 279 526 199 280 533 minecraft:black_concrete
fill 199 279 534 199 280 534 minecraft:gray_concrete
fill 199 279 535 206 280 535 minecraft:black_concrete
fill 199 279 543 199 280 543 minecraft:gray_concrete
fill 199 279 544 206 280 544 minecraft:black_concrete
fill 200 279 511 200 280 514 minecraft:black_concrete
fill 200 279 515 200 280 515 minecraft:gray_concrete
fill 200 279 516 200 280 523 minecraft:black_concrete
fill 200 279 524 200 280 524 minecraft:gray_concrete
fill 200 279 525 200 280 532 minecraft:black_concrete
fill 200 279 533 200 280 533 minecraft:gray_concrete
fill 200 279 534 207 280 534 minecraft:black_concrete
fill 200 279 542 200 280 542 minecraft:gray_concrete
fill 200 279 543 207 280 543 minecraft:black_concrete
fill 200 279 551 200 280 551 minecraft:gray_concrete
fill 201 279 511 201 280 513 minecraft:black_concrete
fill 201 279 514 201 280 514 minecraft:gray_concrete
fill 201 279 515 201 280 522 minecraft:black_concrete
fill 201 279 523 201 280 523 minecraft:gray_concrete
fill 201 279 524 201 280 531 minecraft:black_concrete
fill 201 279 532 201 280 532 minecraft:gray_concrete
fill 201 279 533 208 280 533 minecraft:black_concrete
fill 201 279 541 201 280 541 minecraft:gray_concrete
fill 201 279 542 208 280 542 minecraft:black_concrete
fill 201 279 550 201 280 550 minecraft:gray_concrete
fill 201 279 551 208 280 551 minecraft:black_concrete
fill 202 279 511 202 280 512 minecraft:black_concrete
fill 202 279 513 202 280 513 minecraft:gray_concrete
fill 202 279 514 202 280 521 minecraft:black_concrete
fill 202 279 522 202 280 522 minecraft:gray_concrete
fill 202 279 523 202 280 530 minecraft:black_concrete
fill 202 279 531 202 280 531 minecraft:gray_concrete
fill 202 279 532 209 279 532 minecraft:black_concrete
fill 202 279 540 202 280 540 minecraft:gray_concrete
fill 202 279 541 209 280 541 minecraft:black_concrete
fill 202 279 549 202 280 549 minecraft:gray_concrete
fill 202 279 550 209 280 550 minecraft:black_concrete
fill 203 279 511 203 280 511 minecraft:black_concrete
fill 203 279 512 203 280 512 minecraft:gray_concrete
fill 203 279 513 203 280 520 minecraft:black_concrete
fill 203 279 521 203 280 521 minecraft:gray_concrete
fill 203 279 522 203 280 529 minecraft:black_concrete
fill 203 279 530 203 280 530 minecraft:gray_concrete
fill 203 279 531 206 279 531 minecraft:black_concrete
fill 203 279 539 203 280 539 minecraft:gray_concrete
fill 203 279 540 210 280 540 minecraft:black_concrete
fill 203 279 548 203 280 548 minecraft:gray_concrete
fill 203 279 549 210 280 549 minecraft:black_concrete
fill 204 279 511 204 280 511 minecraft:gray_concrete
fill 204 279 512 204 280 519 minecraft:black_concrete
fill 204 279 520 204 280 520 minecraft:gray_concrete
fill 204 279 521 204 279 528 minecraft:black_concrete
setblock 204 279 529 minecraft:gray_concrete
fill 204 279 530 205 279 530 minecraft:black_concrete
fill 204 279 538 204 280 538 minecraft:gray_concrete
fill 204 279 539 211 280 539 minecraft:black_concrete
fill 204 279 547 204 280 547 minecraft:gray_concrete
fill 204 279 548 211 280 548 minecraft:black_concrete
fill 205 279 511 205 280 518 minecraft:black_concrete
fill 205 279 519 205 280 519 minecraft:gray_concrete
fill 205 279 520 205 279 527 minecraft:black_concrete
setblock 205 279 528 minecraft:gray_concrete
fill 205 279 537 205 280 537 minecraft:gray_concrete
fill 205 279 538 212 280 538 minecraft:black_concrete
fill 205 279 546 205 280 546 minecraft:gray_concrete
fill 205 279 547 212 280 547 minecraft:black_concrete
fill 206 279 511 206 280 517 minecraft:black_concrete
fill 206 279 518 206 280 518 minecraft:gray_concrete
fill 206 279 519 206 279 526 minecraft:black_concrete
setblock 206 279 527 minecraft:gray_concrete
fill 206 279 536 206 280 536 minecraft:gray_concrete
fill 206 279 537 213 280 537 minecraft:black_concrete
fill 206 279 545 206 280 545 minecraft:gray_concrete
fill 206 279 546 213 280 546 minecraft:black_concrete
fill 207 279 511 207 280 516 minecraft:black_concrete
fill 207 279 517 207 280 517 minecraft:gray_concrete
fill 207 279 518 207 280 525 minecraft:black_concrete
setblock 207 279 526 minecraft:gray_concrete
fill 207 279 535 207 280 535 minecraft:gray_concrete
fill 207 279 536 214 280 536 minecraft:black_concrete
fill 207 279 544 207 280 544 minecraft:gray_concrete
fill 207 279 545 214 280 545 minecraft:black_concrete
fill 208 279 511 208 280 515 minecraft:black_concrete
fill 208 279 516 208 280 516 minecraft:gray_concrete
fill 208 279 517 208 280 524 minecraft:black_concrete
fill 208 279 525 208 280 525 minecraft:gray_concrete
fill 208 279 526 214 279 527 minecraft:black_concrete
fill 208 279 531 210 279 531 minecraft:black_concrete
fill 208 279 534 208 280 534 minecraft:gray_concrete
fill 208 279 535 215 280 535 minecraft:black_concrete
fill 208 279 543 208 280 543 minecraft:gray_concrete
fill 208 279 544 215 280 544 minecraft:black_concrete
fill 209 279 511 209 280 514 minecraft:black_concrete
fill 209 279 515 209 280 515 minecraft:gray_concrete
fill 209 279 516 209 280 523 minecraft:black_concrete
fill 209 279 524 209 280 524 minecraft:gray_concrete
fill 209 279 525 216 280 525 minecraft:black_concrete
fill 209 279 528 213 279 528 minecraft:black_concrete
fill 209 279 530 211 279 530 minecraft:black_concrete
fill 209 279 533 209 280 533 minecraft:gray_concrete
fill 209 279 534 216 280 534 minecraft:black_concrete
fill 209 279 542 209 280 542 minecraft:gray_concrete
fill 209 279 543 216 280 543 minecraft:black_concrete
fill 209 279 551 209 280 551 minecraft:gray_concrete
fill 210 279 511 210 280 513 minecraft:black_concrete
fill 210 279 514 210 280 514 minecraft:gray_concrete
fill 210 279 515 210 280 522 minecraft:black_concrete
fill 210 279 523 210 280 523 minecraft:gray_concrete
fill 210 279 524 217 280 524 minecraft:black_concrete
fill 210 279 529 212 279 529 minecraft:black_concrete
fill 210 279 532 210 280 532 minecraft:gray_concrete
fill 210 279 533 217 280 533 minecraft:black_concrete
fill 210 279 541 210 280 541 minecraft:gray_concrete
fill 210 279 542 217 280 542 minecraft:black_concrete
fill 210 279 550 210 280 550 minecraft:gray_concrete
fill 210 279 551 217 280 551 minecraft:black_concrete
fill 211 279 511 211 280 512 minecraft:black_concrete
fill 211 279 513 211 280 513 minecraft:gray_concrete
fill 211 279 514 211 280 521 minecraft:black_concrete
fill 211 279 522 211 280 522 minecraft:gray_concrete
fill 211 279 523 218 280 523 minecraft:black_concrete
fill 211 279 531 211 280 531 minecraft:gray_concrete
fill 211 279 532 218 280 532 minecraft:black_concrete
fill 211 279 540 211 280 540 minecraft:gray_concrete
fill 211 279 541 218 280 541 minecraft:black_concrete
fill 211 279 549 211 280 549 minecraft:gray_concrete
fill 211 279 550 218 280 550 minecraft:black_concrete
fill 212 279 511 212 280 511 minecraft:black_concrete
fill 212 279 512 212 280 512 minecraft:gray_concrete
fill 212 279 513 212 280 520 minecraft:black_concrete
fill 212 279 521 212 280 521 minecraft:gray_concrete
fill 212 279 522 219 280 522 minecraft:black_concrete
fill 212 279 530 212 280 530 minecraft:gray_concrete
fill 212 279 531 219 280 531 minecraft:black_concrete
fill 212 279 539 212 280 539 minecraft:gray_concrete
fill 212 279 540 219 280 540 minecraft:black_concrete
fill 212 279 548 212 280 548 minecraft:gray_concrete
fill 212 279 549 219 280 549 minecraft:black_concrete
fill 213 279 511 213 280 511 minecraft:gray_concrete
fill 213 279 512 213 280 519 minecraft:black_concrete
fill 213 279 520 213 280 520 minecraft:gray_concrete
fill 213 279 521 220 280 521 minecraft:black_concrete
fill 213 279 529 213 280 529 minecraft:gray_concrete
fill 213 279 530 220 280 530 minecraft:black_concrete
fill 213 279 538 213 280 538 minecraft:gray_concrete
fill 213 279 539 220 280 539 minecraft:black_concrete
fill 213 279 547 213 280 547 minecraft:gray_concrete
fill 213 279 548 220 280 548 minecraft:black_concrete
fill 214 279 511 214 280 518 minecraft:black_concrete
fill 214 279 519 214 280 519 minecraft:gray_concrete
fill 214 279 520 221 280 520 minecraft:black_concrete
fill 214 279 528 214 280 528 minecraft:gray_concrete
fill 214 279 529 221 280 529 minecraft:black_concrete
fill 214 279 537 214 280 537 minecraft:gray_concrete
fill 214 279 538 221 280 538 minecraft:black_concrete
fill 214 279 546 214 280 546 minecraft:gray_concrete
fill 214 279 547 221 280 547 minecraft:black_concrete
fill 215 279 511 215 280 517 minecraft:black_concrete
fill 215 279 518 215 280 518 minecraft:gray_concrete
fill 215 279 519 222 280 519 minecraft:black_concrete
fill 215 279 526 215 280 526 minecraft:black_concrete
fill 215 279 527 215 280 527 minecraft:gray_concrete
fill 215 279 528 222 280 528 minecraft:black_concrete
fill 215 279 536 215 280 536 minecraft:gray_concrete
fill 215 279 537 222 280 537 minecraft:black_concrete
fill 215 279 545 215 280 545 minecraft:gray_concrete
fill 215 279 546 222 280 546 minecraft:black_concrete
fill 216 279 511 216 280 516 minecraft:black_concrete
fill 216 279 517 216 280 517 minecraft:gray_concrete
fill 216 279 518 223 280 518 minecraft:black_concrete
fill 216 279 526 216 280 526 minecraft:gray_concrete
fill 216 279 527 223 280 527 minecraft:black_concrete
fill 216 279 535 216 280 535 minecraft:gray_concrete
fill 216 279 536 223 280 536 minecraft:black_concrete
fill 216 279 544 216 280 544 minecraft:gray_concrete
fill 216 279 545 223 280 545 minecraft:black_concrete
fill 217 279 511 217 280 515 minecraft:black_concrete
fill 217 279 516 217 280 516 minecraft:gray_concrete
fill 217 279 517 224 280 517 minecraft:black_concrete
fill 217 279 525 217 280 525 minecraft:gray_concrete
fill 217 279 526 224 280 526 minecraft:black_concrete
fill 217 279 534 217 280 534 minecraft:gray_concrete
fill 217 279 535 224 280 535 minecraft:black_concrete
fill 217 279 543 217 280 543 minecraft:gray_concrete
fill 217 279 544 224 280 544 minecraft:black_concrete
fill 218 279 511 218 280 514 minecraft:black_concrete
fill 218 279 515 218 280 515 minecraft:gray_concrete
fill 218 279 516 225 280 516 minecraft:black_concrete
fill 218 279 524 218 280 524 minecraft:gray_concrete
fill 218 279 525 225 280 525 minecraft:black_concrete
fill 218 279 533 218 280 533 minecraft:gray_concrete
fill 218 279 534 225 280 534 minecraft:black_concrete
fill 218 279 542 218 280 542 minecraft:gray_concrete
fill 218 279 543 225 280 543 minecraft:black_concrete
fill 218 279 551 218 280 551 minecraft:gray_concrete
fill 219 279 511 219 280 513 minecraft:black_concrete
fill 219 279 514 219 280 514 minecraft:gray_concrete
fill 219 279 515 226 280 515 minecraft:black_concrete
fill 219 279 523 219 280 523 minecraft:gray_concrete
fill 219 279 524 226 280 524 minecraft:black_concrete
fill 219 279 532 219 280 532 minecraft:gray_concrete
fill 219 279 533 226 280 533 minecraft:black_concrete
fill 219 279 541 219 280 541 minecraft:gray_concrete
fill 219 279 542 226 280 542 minecraft:black_concrete
fill 219 279 550 219 280 550 minecraft:gray_concrete
fill 219 279 551 226 280 551 minecraft:black_concrete
fill 220 279 511 220 280 512 minecraft:black_concrete
fill 220 279 513 220 280 513 minecraft:gray_concrete
fill 220 279 514 227 280 514 minecraft:black_concrete
fill 220 279 522 220 280 522 minecraft:gray_concrete
fill 220 279 523 227 280 523 minecraft:black_concrete
fill 220 279 531 220 280 531 minecraft:gray_concrete
fill 220 279 532 227 280 532 minecraft:black_concrete
fill 220 279 540 220 280 540 minecraft:gray_concrete
fill 220 279 541 227 280 541 minecraft:black_concrete
fill 220 279 549 220 280 549 minecraft:gray_concrete
fill 220 279 550 227 280 550 minecraft:black_concrete
fill 221 279 511 221 280 511 minecraft:black_concrete
fill 221 279 512 221 280 512 minecraft:gray_concrete
fill 221 279 513 228 280 513 minecraft:black_concrete
fill 221 279 521 221 280 521 minecraft:gray_concrete
fill 221 279 522 228 280 522 minecraft:black_concrete
fill 221 279 530 221 280 530 minecraft:gray_concrete
fill 221 279 531 228 280 531 minecraft:black_concrete
fill 221 279 539 221 280 539 minecraft:gray_concrete
fill 221 279 540 228 280 540 minecraft:black_concrete
fill 221 279 548 221 280 548 minecraft:gray_concrete
fill 221 279 549 228 280 549 minecraft:black_concrete
fill 222 279 511 222 280 511 minecraft:gray_concrete
fill 222 279 512 229 280 512 minecraft:black_concrete
fill 222 279 520 222 280 520 minecraft:gray_concrete
fill 222 279 521 229 280 521 minecraft:black_concrete
fill 222 279 529 222 280 529 minecraft:gray_concrete
fill 222 279 530 229 280 530 minecraft:black_concrete
fill 222 279 538 222 280 538 minecraft:gray_concrete
fill 222 279 539 229 280 539 minecraft:black_concrete
fill 222 279 547 222 280 547 minecraft:gray_concrete
fill 222 279 548 229 280 548 minecraft:black_concrete
fill 223 279 511 229 280 511 minecraft:black_concrete
fill 223 279 519 223 280 519 minecraft:gray_concrete
fill 223 279 520 229 280 520 minecraft:black_concrete
fill 223 279 528 223 280 528 minecraft:gray_concrete
fill 223 279 529 229 280 529 minecraft:black_concrete
fill 223 279 537 223 280 537 minecraft:gray_concrete
fill 223 279 538 229 280 538 minecraft:black_concrete
fill 223 279 546 223 280 546 minecraft:gray_concrete
fill 223 279 547 229 280 547 minecraft:black_concrete
fill 224 279 518 224 280 518 minecraft:gray_concrete
fill 224 279 519 229 280 519 minecraft:black_concrete
fill 224 279 527 224 280 527 minecraft:gray_concrete
fill 224 279 528 229 280 528 minecraft:black_concrete
fill 224 279 536 224 280 536 minecraft:gray_concrete
fill 224 279 537 229 280 537 minecraft:black_concrete
fill 224 279 545 224 280 545 minecraft:gray_concrete
fill 224 279 546 229 280 546 minecraft:black_concrete
fill 225 279 517 225 280 517 minecraft:gray_concrete
fill 225 279 518 229 280 518 minecraft:black_concrete
fill 225 279 526 225 280 526 minecraft:gray_concrete
fill 225 279 527 229 280 527 minecraft:black_concrete
fill 225 279 535 225 280 535 minecraft:gray_concrete
fill 225 279 536 229 280 536 minecraft:black_concrete
fill 225 279 544 225 280 544 minecraft:gray_concrete
fill 225 279 545 229 280 545 minecraft:black_concrete
fill 226 279 516 226 280 516 minecraft:gray_concrete
fill 226 279 517 229 280 517 minecraft:black_concrete
fill 226 279 525 226 280 525 minecraft:gray_concrete
fill 226 279 526 229 280 526 minecraft:black_concrete
fill 226 279 534 226 280 534 minecraft:gray_concrete
fill 226 279 535 229 280 535 minecraft:black_concrete
fill 226 279 543 226 280 543 minecraft:gray_concrete
fill 226 279 544 229 280 544 minecraft:black_concrete
fill 227 279 515 227 280 515 minecraft:gray_concrete
fill 227 279 516 229 280 516 minecraft:black_concrete
fill 227 279 524 227 280 524 minecraft:gray_concrete
fill 227 279 525 229 280 525 minecraft:black_concrete
fill 227 279 533 227 280 533 minecraft:gray_concrete
fill 227 279 534 229 280 534 minecraft:black_concrete
fill 227 279 542 227 280 542 minecraft:gray_concrete
fill 227 279 543 229 280 543 minecraft:black_concrete
fill 227 279 551 227 280 551 minecraft:gray_concrete
fill 228 279 514 228 280 514 minecraft:gray_concrete
fill 228 279 515 229 280 515 minecraft:black_concrete
fill 228 279 523 228 280 523 minecraft:gray_concrete
fill 228 279 524 229 280 524 minecraft:black_concrete
fill 228 279 532 228 280 532 minecraft:gray_concrete
fill 228 279 533 229 280 533 minecraft:black_concrete
fill 228 279 541 228 280 541 minecraft:gray_concrete
fill 228 279 542 229 280 542 minecraft:black_concrete
fill 228 279 550 228 280 550 minecraft:gray_concrete
fill 228 279 551 229 280 551 minecraft:black_concrete
fill 229 279 513 229 280 513 minecraft:gray_concrete
fill 229 279 514 229 280 514 minecraft:black_concrete
fill 229 279 522 229 280 522 minecraft:gray_concrete
fill 229 279 523 229 280 523 minecraft:black_concrete
fill 229 279 531 229 280 531 minecraft:gray_concrete
fill 229 279 532 229 280 532 minecraft:black_concrete
fill 229 279 540 229 280 540 minecraft:gray_concrete
fill 229 279 541 229 280 541 minecraft:black_concrete
fill 229 279 549 229 280 549 minecraft:gray_concrete
fill 229 279 550 229 280 550 minecraft:black_concrete
fill 202 280 532 205 280 532 minecraft:black_concrete
fill 203 280 531 204 280 531 minecraft:black_concrete
fill 204 280 521 204 280 527 minecraft:black_concrete
fill 204 280 528 204 280 530 minecraft:pearlescent_froglight
fill 205 280 520 205 280 526 minecraft:black_concrete
fill 205 280 527 205 280 528 minecraft:pearlescent_froglight
fill 205 280 530 205 280 531 minecraft:pearlescent_froglight
fill 206 280 519 206 280 525 minecraft:black_concrete
fill 206 280 526 206 280 527 minecraft:pearlescent_froglight
fill 206 280 531 206 280 532 minecraft:pearlescent_froglight
fill 207 280 526 208 280 526 minecraft:pearlescent_froglight
fill 207 280 532 208 280 532 minecraft:pearlescent_froglight
fill 208 280 527 209 280 527 minecraft:pearlescent_froglight
fill 208 280 531 209 280 531 minecraft:pearlescent_froglight
fill 209 280 526 214 280 526 minecraft:black_concrete
fill 209 280 528 210 280 528 minecraft:pearlescent_froglight
fill 209 280 530 210 280 530 minecraft:pearlescent_froglight
setblock 209 280 532 minecraft:black_concrete
fill 210 280 527 214 280 527 minecraft:black_concrete
setblock 210 280 529 minecraft:pearlescent_froglight
setblock 210 280 531 minecraft:black_concrete
fill 211 280 528 211 280 530 minecraft:black_concrete
fill 212 280 528 212 280 529 minecraft:black_concrete
setblock 213 280 528 minecraft:black_concrete
setblock 191 281 513 minecraft:light[level=10]
setblock 191 281 521 minecraft:light[level=10]
setblock 191 281 529 minecraft:light[level=10]
setblock 191 281 537 minecraft:light[level=10]
setblock 191 281 545 minecraft:light[level=10]
setblock 199 281 513 minecraft:light[level=10]
setblock 199 281 521 minecraft:light[level=10]
setblock 199 281 529 minecraft:light[level=10]
setblock 199 281 537 minecraft:light[level=10]
setblock 199 281 545 minecraft:light[level=10]
setblock 207 281 513 minecraft:light[level=10]
setblock 207 281 521 minecraft:light[level=10]
setblock 207 281 537 minecraft:light[level=10]
setblock 207 281 545 minecraft:light[level=10]
setblock 215 281 513 minecraft:light[level=10]
setblock 215 281 521 minecraft:light[level=10]
setblock 215 281 529 minecraft:light[level=10]
setblock 215 281 537 minecraft:light[level=10]
setblock 215 281 545 minecraft:light[level=10]
setblock 223 281 513 minecraft:light[level=10]
setblock 223 281 521 minecraft:light[level=10]
setblock 223 281 529 minecraft:light[level=10]
setblock 223 281 537 minecraft:light[level=10]
setblock 223 281 545 minecraft:light[level=10]
fill 188 284 515 188 289 515 minecraft:pearlescent_froglight
fill 188 284 523 188 289 523 minecraft:pearlescent_froglight
fill 188 284 531 188 289 531 minecraft:pearlescent_froglight
fill 188 284 539 188 289 539 minecraft:pearlescent_froglight
fill 188 284 547 188 289 547 minecraft:pearlescent_froglight
fill 189 284 517 189 300 518 minecraft:gray_concrete
fill 189 284 525 189 300 526 minecraft:gray_concrete
fill 189 284 533 189 300 534 minecraft:gray_concrete
fill 189 284 541 189 300 542 minecraft:gray_concrete
fill 189 284 549 189 300 550 minecraft:gray_concrete
fill 190 284 511 191 300 511 minecraft:gray_concrete
fill 191 284 552 191 289 552 minecraft:pearlescent_froglight
fill 195 284 510 195 289 510 minecraft:pearlescent_froglight
fill 195 284 551 196 300 551 minecraft:gray_concrete
fill 198 284 511 199 300 511 minecraft:gray_concrete
fill 199 284 552 199 289 552 minecraft:pearlescent_froglight
fill 203 284 510 203 289 510 minecraft:pearlescent_froglight
fill 203 284 551 204 300 551 minecraft:gray_concrete
fill 206 284 511 207 300 511 minecraft:gray_concrete
fill 207 284 543 219 285 551 minecraft:gray_concrete
fill 207 284 552 207 289 552 minecraft:pearlescent_froglight
fill 211 284 510 211 289 510 minecraft:pearlescent_froglight
fill 214 284 511 215 300 511 minecraft:gray_concrete
fill 215 284 552 215 289 552 minecraft:pearlescent_froglight
fill 219 284 510 219 289 510 minecraft:pearlescent_froglight
fill 220 284 544 220 285 551 minecraft:gray_concrete
fill 221 284 544 229 285 550 minecraft:gray_concrete
fill 222 284 511 229 285 511 minecraft:gray_concrete
fill 223 284 543 229 285 543 minecraft:gray_concrete
fill 223 284 552 223 289 552 minecraft:pearlescent_froglight
fill 224 284 512 229 285 517 minecraft:gray_concrete
fill 227 284 510 227 289 510 minecraft:pearlescent_froglight
fill 227 284 551 228 300 551 minecraft:gray_concrete
fill 229 284 520 229 300 521 minecraft:gray_concrete
fill 229 284 528 229 300 529 minecraft:gray_concrete
fill 229 284 536 229 300 537 minecraft:gray_concrete
fill 230 284 515 230 289 515 minecraft:pearlescent_froglight
fill 230 284 523 230 289 523 minecraft:pearlescent_froglight
fill 230 284 531 230 289 531 minecraft:pearlescent_froglight
fill 230 284 539 230 289 539 minecraft:pearlescent_froglight
fill 230 284 547 230 289 547 minecraft:pearlescent_froglight
setblock 207 286 543 minecraft:pearlescent_froglight
fill 207 286 544 207 300 544 minecraft:gray_concrete
setblock 207 286 545 minecraft:pearlescent_froglight
fill 207 286 546 207 300 546 minecraft:gray_concrete
setblock 207 286 547 minecraft:pearlescent_froglight
fill 207 286 548 207 300 548 minecraft:gray_concrete
setblock 207 286 549 minecraft:pearlescent_froglight
fill 207 286 550 207 300 550 minecraft:gray_concrete
setblock 207 286 551 minecraft:pearlescent_froglight
fill 208 286 543 208 300 543 minecraft:gray_concrete
setblock 208 286 544 minecraft:pearlescent_froglight
fill 208 286 545 208 300 545 minecraft:gray_concrete
setblock 208 286 546 minecraft:pearlescent_froglight
fill 208 286 547 208 300 547 minecraft:gray_concrete
setblock 208 286 548 minecraft:pearlescent_froglight
fill 208 286 549 208 300 549 minecraft:gray_concrete
setblock 208 286 550 minecraft:pearlescent_froglight
fill 208 286 551 208 300 551 minecraft:gray_concrete
setblock 209 286 543 minecraft:pearlescent_froglight
fill 209 286 544 209 300 544 minecraft:gray_concrete
setblock 209 286 545 minecraft:pearlescent_froglight
fill 209 286 546 209 300 546 minecraft:gray_concrete
setblock 209 286 547 minecraft:pearlescent_froglight
fill 209 286 548 209 300 548 minecraft:gray_concrete
setblock 209 286 549 minecraft:pearlescent_froglight
fill 209 286 550 209 300 550 minecraft:gray_concrete
setblock 209 286 551 minecraft:pearlescent_froglight
fill 210 286 543 210 300 543 minecraft:gray_concrete
setblock 210 286 544 minecraft:pearlescent_froglight
fill 210 286 545 210 300 545 minecraft:gray_concrete
setblock 210 286 546 minecraft:pearlescent_froglight
fill 210 286 547 210 300 547 minecraft:gray_concrete
setblock 210 286 548 minecraft:pearlescent_froglight
fill 210 286 549 210 300 549 minecraft:gray_concrete
setblock 210 286 550 minecraft:pearlescent_froglight
fill 210 286 551 210 300 551 minecraft:gray_concrete
setblock 211 286 543 minecraft:pearlescent_froglight
fill 211 286 544 211 300 544 minecraft:gray_concrete
setblock 211 286 545 minecraft:pearlescent_froglight
fill 211 286 546 211 300 546 minecraft:gray_concrete
setblock 211 286 547 minecraft:pearlescent_froglight
fill 211 286 548 211 300 548 minecraft:gray_concrete
setblock 211 286 549 minecraft:pearlescent_froglight
fill 211 286 550 211 300 550 minecraft:gray_concrete
setblock 211 286 551 minecraft:pearlescent_froglight
fill 212 286 543 212 300 543 minecraft:gray_concrete
setblock 212 286 544 minecraft:pearlescent_froglight
fill 212 286 545 212 300 545 minecraft:gray_concrete
setblock 212 286 546 minecraft:pearlescent_froglight
fill 212 286 547 212 300 547 minecraft:gray_concrete
setblock 212 286 548 minecraft:pearlescent_froglight
fill 212 286 549 212 300 549 minecraft:gray_concrete
setblock 212 286 550 minecraft:pearlescent_froglight
fill 212 286 551 212 300 551 minecraft:gray_concrete
setblock 213 286 543 minecraft:pearlescent_froglight
fill 213 286 544 213 300 544 minecraft:gray_concrete
setblock 213 286 545 minecraft:pearlescent_froglight
fill 213 286 546 213 300 546 minecraft:gray_concrete
setblock 213 286 547 minecraft:pearlescent_froglight
fill 213 286 548 213 300 548 minecraft:gray_concrete
setblock 213 286 549 minecraft:pearlescent_froglight
fill 213 286 550 213 300 550 minecraft:gray_concrete
setblock 213 286 551 minecraft:pearlescent_froglight
fill 214 286 543 214 300 543 minecraft:gray_concrete
setblock 214 286 544 minecraft:pearlescent_froglight
fill 214 286 545 214 300 545 minecraft:gray_concrete
setblock 214 286 546 minecraft:pearlescent_froglight
fill 214 286 547 214 300 547 minecraft:gray_concrete
setblock 214 286 548 minecraft:pearlescent_froglight
fill 214 286 549 214 300 549 minecraft:gray_concrete
setblock 214 286 550 minecraft:pearlescent_froglight
fill 214 286 551 214 300 551 minecraft:gray_concrete
setblock 215 286 543 minecraft:pearlescent_froglight
fill 215 286 544 215 300 544 minecraft:gray_concrete
setblock 215 286 545 minecraft:pearlescent_froglight
fill 215 286 546 215 300 546 minecraft:gray_concrete
setblock 215 286 547 minecraft:pearlescent_froglight
fill 215 286 548 215 300 548 minecraft:gray_concrete
setblock 215 286 549 minecraft:pearlescent_froglight
fill 215 286 550 215 300 550 minecraft:gray_concrete
setblock 215 286 551 minecraft:pearlescent_froglight
fill 216 286 543 216 300 543 minecraft:gray_concrete
setblock 216 286 544 minecraft:pearlescent_froglight
fill 216 286 545 216 300 545 minecraft:gray_concrete
setblock 216 286 546 minecraft:pearlescent_froglight
fill 216 286 547 216 300 547 minecraft:gray_concrete
setblock 216 286 548 minecraft:pearlescent_froglight
fill 216 286 549 216 300 549 minecraft:gray_concrete
setblock 216 286 550 minecraft:pearlescent_froglight
fill 216 286 551 216 300 551 minecraft:gray_concrete
setblock 217 286 543 minecraft:pearlescent_froglight
fill 217 286 544 217 300 544 minecraft:gray_concrete
setblock 217 286 545 minecraft:pearlescent_froglight
fill 217 286 546 217 300 546 minecraft:gray_concrete
setblock 217 286 547 minecraft:pearlescent_froglight
fill 217 286 548 217 300 548 minecraft:gray_concrete
setblock 217 286 549 minecraft:pearlescent_froglight
fill 217 286 550 217 300 550 minecraft:gray_concrete
setblock 217 286 551 minecraft:pearlescent_froglight
fill 218 286 543 218 300 543 minecraft:gray_concrete
setblock 218 286 544 minecraft:pearlescent_froglight
fill 218 286 545 218 300 545 minecraft:gray_concrete
setblock 218 286 546 minecraft:pearlescent_froglight
fill 218 286 547 218 300 547 minecraft:gray_concrete
setblock 218 286 548 minecraft:pearlescent_froglight
fill 218 286 549 218 300 549 minecraft:gray_concrete
setblock 218 286 550 minecraft:pearlescent_froglight
fill 218 286 551 218 300 551 minecraft:gray_concrete
setblock 219 286 543 minecraft:pearlescent_froglight
fill 219 286 544 219 300 544 minecraft:gray_concrete
setblock 219 286 545 minecraft:pearlescent_froglight
fill 219 286 546 219 300 546 minecraft:gray_concrete
setblock 219 286 547 minecraft:pearlescent_froglight
fill 219 286 548 219 300 548 minecraft:gray_concrete
setblock 219 286 549 minecraft:pearlescent_froglight
fill 219 286 550 219 300 550 minecraft:gray_concrete
setblock 219 286 551 minecraft:pearlescent_froglight
fill 220 286 510 223 307 510 minecraft:black_concrete
setblock 220 286 544 minecraft:pearlescent_froglight
fill 220 286 545 220 300 545 minecraft:gray_concrete
setblock 220 286 546 minecraft:pearlescent_froglight
fill 220 286 547 220 300 547 minecraft:gray_concrete
setblock 220 286 548 minecraft:pearlescent_froglight
fill 220 286 549 220 300 549 minecraft:gray_concrete
setblock 220 286 550 minecraft:pearlescent_froglight
fill 220 286 551 220 300 551 minecraft:gray_concrete
fill 221 286 544 221 300 544 minecraft:gray_concrete
setblock 221 286 545 minecraft:pearlescent_froglight
fill 221 286 546 221 300 546 minecraft:gray_concrete
setblock 221 286 547 minecraft:pearlescent_froglight
fill 221 286 548 221 300 548 minecraft:gray_concrete
setblock 221 286 549 minecraft:pearlescent_froglight
fill 221 286 550 221 300 550 minecraft:gray_concrete
fill 222 286 511 224 295 511 minecraft:gray_concrete
setblock 222 286 544 minecraft:pearlescent_froglight
fill 222 286 545 222 300 545 minecraft:gray_concrete
setblock 222 286 546 minecraft:pearlescent_froglight
fill 222 286 547 222 300 547 minecraft:gray_concrete
setblock 222 286 548 minecraft:pearlescent_froglight
fill 222 286 549 222 300 549 minecraft:gray_concrete
setblock 222 286 550 minecraft:pearlescent_froglight
setblock 223 286 543 minecraft:pearlescent_froglight
fill 223 286 544 223 300 544 minecraft:gray_concrete
setblock 223 286 545 minecraft:pearlescent_froglight
fill 223 286 546 223 300 546 minecraft:gray_concrete
setblock 223 286 547 minecraft:pearlescent_froglight
fill 223 286 548 223 300 548 minecraft:gray_concrete
setblock 223 286 549 minecraft:pearlescent_froglight
fill 223 286 550 223 300 550 minecraft:gray_concrete
setblock 224 286 510 minecraft:pearlescent_froglight
setblock 224 286 512 minecraft:pearlescent_froglight
fill 224 286 513 224 295 513 minecraft:gray_concrete
setblock 224 286 514 minecraft:pearlescent_froglight
fill 224 286 515 224 295 515 minecraft:gray_concrete
setblock 224 286 516 minecraft:pearlescent_froglight
fill 224 286 517 224 295 517 minecraft:gray_concrete
fill 224 286 543 224 296 543 minecraft:gray_concrete
setblock 224 286 544 minecraft:pearlescent_froglight
fill 224 286 545 224 296 545 minecraft:gray_concrete
setblock 224 286 546 minecraft:pearlescent_froglight
fill 224 286 547 224 296 547 minecraft:gray_concrete
setblock 224 286 548 minecraft:pearlescent_froglight
fill 224 286 549 224 300 549 minecraft:gray_concrete
setblock 224 286 550 minecraft:pearlescent_froglight
fill 225 286 510 225 307 510 minecraft:black_concrete
setblock 225 286 511 minecraft:pearlescent_froglight
fill 225 286 512 225 295 512 minecraft:gray_concrete
setblock 225 286 513 minecraft:pearlescent_froglight
fill 225 286 514 225 295 514 minecraft:gray_concrete
setblock 225 286 515 minecraft:pearlescent_froglight
fill 225 286 516 225 295 516 minecraft:gray_concrete
setblock 225 286 517 minecraft:pearlescent_froglight
setblock 225 286 543 minecraft:pearlescent_froglight
fill 225 286 544 225 296 544 minecraft:gray_concrete
setblock 225 286 545 minecraft:pearlescent_froglight
fill 225 286 546 225 296 546 minecraft:gray_concrete
setblock 225 286 547 minecraft:pearlescent_froglight
fill 225 286 548 225 296 548 minecraft:gray_concrete
setblock 225 286 549 minecraft:pearlescent_froglight
fill 225 286 550 225 300 550 minecraft:gray_concrete
setblock 226 286 510 minecraft:pearlescent_froglight
fill 226 286 511 226 295 511 minecraft:gray_concrete
setblock 226 286 512 minecraft:pearlescent_froglight
fill 226 286 513 226 295 513 minecraft:gray_concrete
schedule function dropper:buildpart/124_3 1t
