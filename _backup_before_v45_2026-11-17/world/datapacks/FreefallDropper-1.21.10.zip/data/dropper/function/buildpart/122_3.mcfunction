setblock 116 71 551 minecraft:smooth_basalt
fill 117 71 511 117 74 511 minecraft:blackstone
setblock 117 71 550 minecraft:smooth_basalt
fill 117 71 551 117 74 551 minecraft:blackstone
setblock 118 71 549 minecraft:smooth_basalt
fill 118 71 550 118 73 550 minecraft:blackstone
setblock 121 71 551 minecraft:smooth_basalt
setblock 122 71 551 minecraft:blackstone
setblock 126 71 551 minecraft:smooth_basalt
fill 127 71 551 127 74 551 minecraft:blackstone
fill 128 71 511 130 71 511 minecraft:blackstone
setblock 130 71 512 minecraft:smooth_basalt
setblock 131 71 511 minecraft:smooth_basalt
fill 131 71 512 131 74 512 minecraft:blackstone
setblock 131 71 550 minecraft:blackstone
setblock 131 71 551 minecraft:smooth_basalt
fill 132 71 511 132 74 511 minecraft:blackstone
setblock 132 71 525 minecraft:smooth_basalt
fill 132 71 526 132 73 526 minecraft:blackstone
setblock 132 71 530 minecraft:smooth_basalt
fill 132 71 531 132 72 531 minecraft:blackstone
setblock 132 71 550 minecraft:smooth_basalt
fill 132 71 551 132 74 551 minecraft:blackstone
setblock 133 71 520 minecraft:blackstone
setblock 133 71 524 minecraft:smooth_basalt
fill 133 71 525 133 74 525 minecraft:blackstone
setblock 133 71 529 minecraft:smooth_basalt
fill 133 71 530 133 74 530 minecraft:blackstone
fill 133 71 550 133 74 550 minecraft:blackstone
setblock 134 71 512 minecraft:blackstone
setblock 134 71 513 minecraft:smooth_basalt
fill 134 71 514 134 74 514 minecraft:blackstone
setblock 134 71 518 minecraft:smooth_basalt
fill 134 71 519 134 74 519 minecraft:blackstone
setblock 134 71 523 minecraft:smooth_basalt
fill 134 71 524 134 74 524 minecraft:blackstone
setblock 134 71 528 minecraft:smooth_basalt
fill 134 71 529 134 74 529 minecraft:blackstone
setblock 134 71 533 minecraft:smooth_basalt
fill 134 71 534 134 74 534 minecraft:blackstone
setblock 134 71 548 minecraft:smooth_basalt
fill 134 71 549 134 74 549 minecraft:blackstone
setblock 135 71 512 minecraft:smooth_basalt
fill 135 71 513 135 74 513 minecraft:blackstone
setblock 135 71 517 minecraft:smooth_basalt
fill 135 71 518 135 74 518 minecraft:blackstone
setblock 135 71 522 minecraft:smooth_basalt
fill 135 71 523 135 74 523 minecraft:blackstone
setblock 135 71 527 minecraft:smooth_basalt
fill 135 71 528 135 74 528 minecraft:blackstone
setblock 135 71 532 minecraft:smooth_basalt
fill 135 71 533 135 74 533 minecraft:blackstone
setblock 135 71 537 minecraft:smooth_basalt
setblock 135 71 538 minecraft:blackstone
setblock 135 71 542 minecraft:smooth_basalt
setblock 135 71 543 minecraft:blackstone
setblock 135 71 547 minecraft:smooth_basalt
fill 135 71 548 135 74 548 minecraft:blackstone
setblock 95 72 511 minecraft:smooth_basalt
fill 95 72 512 95 75 512 minecraft:blackstone
setblock 95 72 516 minecraft:smooth_basalt
fill 95 72 517 95 75 517 minecraft:blackstone
setblock 95 72 521 minecraft:smooth_basalt
fill 95 72 522 95 74 522 minecraft:blackstone
setblock 95 72 526 minecraft:smooth_basalt
fill 95 72 527 95 75 527 minecraft:blackstone
setblock 95 72 531 minecraft:smooth_basalt
fill 95 72 532 95 75 532 minecraft:blackstone
setblock 95 72 546 minecraft:smooth_basalt
fill 95 72 547 95 75 547 minecraft:blackstone
setblock 95 72 551 minecraft:smooth_basalt
fill 96 72 511 96 75 511 minecraft:blackstone
setblock 96 72 515 minecraft:smooth_basalt
setblock 96 72 516 minecraft:blackstone
setblock 96 72 525 minecraft:smooth_basalt
setblock 96 72 526 minecraft:blackstone
setblock 96 72 530 minecraft:smooth_basalt
setblock 96 72 531 minecraft:blackstone
fill 96 72 544 96 77 545 minecraft:smooth_basalt
setblock 96 72 546 minecraft:blackstone
setblock 96 72 550 minecraft:smooth_basalt
fill 96 72 551 99 72 551 minecraft:blackstone
setblock 97 72 513 minecraft:light[level=12]
setblock 97 72 521 minecraft:light[level=12]
setblock 97 72 529 minecraft:light[level=12]
setblock 97 72 537 minecraft:light[level=12]
setblock 97 72 549 minecraft:smooth_basalt
fill 97 72 550 100 72 550 minecraft:blackstone
fill 98 72 549 99 72 549 minecraft:blackstone
setblock 99 72 512 minecraft:smooth_basalt
setblock 100 72 511 minecraft:smooth_basalt
setblock 100 72 512 minecraft:blackstone
setblock 100 72 551 minecraft:smooth_basalt
fill 101 72 511 104 72 511 minecraft:blackstone
setblock 101 72 550 minecraft:smooth_basalt
fill 101 72 551 101 75 551 minecraft:blackstone
fill 102 72 550 105 72 550 minecraft:blackstone
setblock 105 72 511 minecraft:smooth_basalt
setblock 105 72 513 minecraft:light[level=12]
setblock 105 72 521 minecraft:light[level=12]
setblock 105 72 529 minecraft:light[level=12]
setblock 105 72 537 minecraft:light[level=12]
setblock 105 72 545 minecraft:light[level=12]
setblock 105 72 551 minecraft:smooth_basalt
fill 106 72 511 109 72 511 minecraft:blackstone
setblock 106 72 549 minecraft:blackstone
setblock 106 72 550 minecraft:smooth_basalt
fill 106 72 551 106 75 551 minecraft:blackstone
setblock 107 72 549 minecraft:smooth_basalt
fill 107 72 550 107 75 550 minecraft:blackstone
fill 108 72 549 108 75 549 minecraft:blackstone
setblock 110 72 511 minecraft:smooth_basalt
fill 110 72 512 110 75 512 minecraft:blackstone
setblock 110 72 551 minecraft:smooth_basalt
fill 111 72 511 111 75 511 minecraft:blackstone
setblock 111 72 550 minecraft:smooth_basalt
fill 111 72 551 111 75 551 minecraft:blackstone
setblock 112 72 549 minecraft:smooth_basalt
fill 112 72 550 112 75 550 minecraft:blackstone
setblock 113 72 513 minecraft:light[level=12]
setblock 113 72 521 minecraft:light[level=12]
setblock 113 72 529 minecraft:light[level=12]
setblock 113 72 537 minecraft:light[level=12]
setblock 113 72 545 minecraft:light[level=12]
setblock 113 72 548 minecraft:smooth_basalt
fill 113 72 549 113 74 549 minecraft:blackstone
setblock 114 72 511 minecraft:blackstone
setblock 114 72 512 minecraft:smooth_basalt
setblock 114 72 548 minecraft:blackstone
setblock 115 72 511 minecraft:smooth_basalt
setblock 115 72 551 minecraft:smooth_basalt
fill 116 72 511 116 75 511 minecraft:blackstone
setblock 116 72 550 minecraft:smooth_basalt
fill 116 72 551 116 75 551 minecraft:blackstone
setblock 117 72 549 minecraft:smooth_basalt
fill 117 72 550 117 73 550 minecraft:blackstone
setblock 120 72 551 minecraft:smooth_basalt
setblock 121 72 513 minecraft:light[level=12]
setblock 121 72 521 minecraft:light[level=12]
setblock 121 72 529 minecraft:light[level=12]
setblock 121 72 537 minecraft:light[level=12]
setblock 121 72 545 minecraft:light[level=12]
setblock 121 72 551 minecraft:blackstone
fill 127 72 511 129 72 511 minecraft:blackstone
setblock 129 72 513 minecraft:light[level=12]
setblock 129 72 521 minecraft:light[level=12]
setblock 129 72 529 minecraft:light[level=12]
setblock 129 72 537 minecraft:light[level=12]
setblock 129 72 545 minecraft:light[level=12]
setblock 130 72 511 minecraft:smooth_basalt
fill 130 72 512 130 75 512 minecraft:blackstone
setblock 130 72 551 minecraft:smooth_basalt
fill 131 72 511 131 75 511 minecraft:blackstone
setblock 131 72 550 minecraft:smooth_basalt
fill 131 72 551 131 75 551 minecraft:blackstone
setblock 132 72 525 minecraft:blackstone
setblock 132 72 529 minecraft:smooth_basalt
fill 132 72 530 132 73 530 minecraft:blackstone
fill 132 72 550 132 75 550 minecraft:blackstone
setblock 133 72 513 minecraft:smooth_basalt
setblock 133 72 523 minecraft:smooth_basalt
fill 133 72 524 133 74 524 minecraft:blackstone
setblock 133 72 528 minecraft:smooth_basalt
fill 133 72 529 133 75 529 minecraft:blackstone
setblock 133 72 532 minecraft:blackstone
setblock 133 72 533 minecraft:smooth_basalt
setblock 134 72 512 minecraft:smooth_basalt
fill 134 72 513 134 75 513 minecraft:blackstone
setblock 134 72 517 minecraft:smooth_basalt
fill 134 72 518 134 75 518 minecraft:blackstone
setblock 134 72 522 minecraft:smooth_basalt
fill 134 72 523 134 75 523 minecraft:blackstone
setblock 134 72 527 minecraft:smooth_basalt
fill 134 72 528 134 75 528 minecraft:blackstone
setblock 134 72 532 minecraft:smooth_basalt
fill 134 72 533 134 75 533 minecraft:blackstone
setblock 134 72 547 minecraft:smooth_basalt
fill 134 72 548 134 73 548 minecraft:blackstone
setblock 135 72 511 minecraft:smooth_basalt
fill 135 72 512 135 75 512 minecraft:blackstone
setblock 135 72 516 minecraft:smooth_basalt
fill 135 72 517 135 75 517 minecraft:blackstone
setblock 135 72 521 minecraft:smooth_basalt
fill 135 72 522 135 75 522 minecraft:blackstone
setblock 135 72 526 minecraft:smooth_basalt
fill 135 72 527 135 75 527 minecraft:blackstone
setblock 135 72 531 minecraft:smooth_basalt
fill 135 72 532 135 75 532 minecraft:blackstone
setblock 135 72 536 minecraft:smooth_basalt
setblock 135 72 537 minecraft:blackstone
setblock 135 72 546 minecraft:smooth_basalt
fill 135 72 547 135 74 547 minecraft:blackstone
setblock 135 72 551 minecraft:smooth_basalt
fill 95 73 511 95 76 511 minecraft:blackstone
setblock 95 73 515 minecraft:smooth_basalt
fill 95 73 516 95 76 516 minecraft:blackstone
setblock 95 73 520 minecraft:smooth_basalt
setblock 95 73 521 minecraft:blackstone
setblock 95 73 525 minecraft:smooth_basalt
fill 95 73 526 95 75 526 minecraft:blackstone
setblock 95 73 530 minecraft:smooth_basalt
fill 95 73 531 95 76 531 minecraft:blackstone
setblock 95 73 535 minecraft:smooth_basalt
fill 95 73 543 95 77 543 minecraft:smooth_basalt
setblock 95 73 545 minecraft:smooth_basalt
fill 95 73 546 95 75 546 minecraft:blackstone
setblock 95 73 550 minecraft:smooth_basalt
fill 95 73 551 98 73 551 minecraft:blackstone
setblock 96 73 514 minecraft:smooth_basalt
setblock 96 73 515 minecraft:blackstone
setblock 96 73 529 minecraft:smooth_basalt
setblock 96 73 530 minecraft:blackstone
setblock 96 73 549 minecraft:smooth_basalt
fill 96 73 550 99 73 550 minecraft:blackstone
setblock 97 73 549 minecraft:blackstone
setblock 98 73 512 minecraft:smooth_basalt
setblock 99 73 511 minecraft:smooth_basalt
setblock 99 73 512 minecraft:blackstone
setblock 99 73 551 minecraft:smooth_basalt
fill 100 73 511 103 73 511 minecraft:blackstone
setblock 100 73 550 minecraft:smooth_basalt
fill 100 73 551 100 76 551 minecraft:blackstone
fill 101 73 550 104 73 550 minecraft:blackstone
setblock 104 73 511 minecraft:smooth_basalt
setblock 104 73 551 minecraft:smooth_basalt
fill 105 73 511 108 73 511 minecraft:blackstone
setblock 105 73 550 minecraft:smooth_basalt
fill 105 73 551 105 76 551 minecraft:blackstone
fill 106 73 550 106 76 550 minecraft:blackstone
fill 107 73 549 107 74 549 minecraft:blackstone
setblock 109 73 511 minecraft:smooth_basalt
setblock 109 73 551 minecraft:smooth_basalt
fill 110 73 511 110 76 511 minecraft:blackstone
setblock 110 73 550 minecraft:smooth_basalt
fill 110 73 551 110 76 551 minecraft:blackstone
setblock 111 73 549 minecraft:smooth_basalt
fill 111 73 550 111 76 550 minecraft:blackstone
setblock 112 73 512 minecraft:blackstone
fill 112 73 549 112 75 549 minecraft:blackstone
setblock 113 73 512 minecraft:smooth_basalt
setblock 114 73 511 minecraft:smooth_basalt
setblock 114 73 551 minecraft:smooth_basalt
fill 115 73 511 115 76 511 minecraft:blackstone
setblock 115 73 550 minecraft:smooth_basalt
fill 115 73 551 115 76 551 minecraft:blackstone
setblock 116 73 549 minecraft:smooth_basalt
fill 116 73 550 116 74 550 minecraft:blackstone
setblock 119 73 551 minecraft:smooth_basalt
setblock 120 73 551 minecraft:blackstone
fill 127 73 511 128 73 511 minecraft:blackstone
setblock 129 73 511 minecraft:smooth_basalt
fill 129 73 512 129 76 512 minecraft:blackstone
setblock 129 73 551 minecraft:smooth_basalt
fill 130 73 511 130 76 511 minecraft:blackstone
setblock 130 73 550 minecraft:smooth_basalt
fill 130 73 551 130 76 551 minecraft:blackstone
fill 131 73 550 131 75 550 minecraft:blackstone
setblock 132 73 513 minecraft:smooth_basalt
setblock 132 73 528 minecraft:smooth_basalt
setblock 132 73 529 minecraft:blackstone
setblock 133 73 512 minecraft:smooth_basalt
fill 133 73 513 133 76 513 minecraft:blackstone
setblock 133 73 522 minecraft:smooth_basalt
setblock 133 73 523 minecraft:blackstone
setblock 133 73 527 minecraft:smooth_basalt
fill 133 73 528 133 75 528 minecraft:blackstone
setblock 133 73 532 minecraft:smooth_basalt
fill 133 73 533 133 74 533 minecraft:blackstone
setblock 134 73 511 minecraft:smooth_basalt
fill 134 73 512 134 76 512 minecraft:blackstone
setblock 134 73 516 minecraft:smooth_basalt
fill 134 73 517 134 76 517 minecraft:blackstone
setblock 134 73 521 minecraft:smooth_basalt
fill 134 73 522 134 74 522 minecraft:blackstone
setblock 134 73 526 minecraft:smooth_basalt
fill 134 73 527 134 76 527 minecraft:blackstone
setblock 134 73 531 minecraft:smooth_basalt
fill 134 73 532 134 76 532 minecraft:blackstone
setblock 134 73 551 minecraft:smooth_basalt
fill 135 73 511 135 76 511 minecraft:blackstone
setblock 135 73 515 minecraft:smooth_basalt
fill 135 73 516 135 76 516 minecraft:blackstone
setblock 135 73 520 minecraft:smooth_basalt
fill 135 73 521 135 76 521 minecraft:blackstone
setblock 135 73 525 minecraft:smooth_basalt
fill 135 73 526 135 76 526 minecraft:blackstone
setblock 135 73 530 minecraft:smooth_basalt
fill 135 73 531 135 76 531 minecraft:blackstone
setblock 135 73 535 minecraft:smooth_basalt
fill 135 73 536 135 75 536 minecraft:blackstone
setblock 135 73 546 minecraft:blackstone
setblock 135 73 550 minecraft:smooth_basalt
fill 135 73 551 135 76 551 minecraft:blackstone
setblock 95 74 514 minecraft:smooth_basalt
fill 95 74 515 95 77 515 minecraft:blackstone
setblock 95 74 519 minecraft:smooth_basalt
setblock 95 74 520 minecraft:blackstone
setblock 95 74 524 minecraft:smooth_basalt
setblock 95 74 525 minecraft:blackstone
setblock 95 74 529 minecraft:smooth_basalt
fill 95 74 530 95 76 530 minecraft:blackstone
setblock 95 74 534 minecraft:smooth_basalt
fill 95 74 540 95 75 542 minecraft:gold_block
fill 95 74 544 95 77 544 minecraft:smooth_basalt
setblock 95 74 545 minecraft:blackstone
setblock 95 74 549 minecraft:smooth_basalt
fill 95 74 550 97 74 551 minecraft:blackstone
setblock 96 74 513 minecraft:smooth_basalt
fill 96 74 514 96 77 514 minecraft:blackstone
fill 96 74 539 96 74 541 minecraft:gold_block
fill 96 74 546 100 74 547 minecraft:gold_block
setblock 96 74 548 minecraft:smooth_basalt
fill 96 74 549 96 75 549 minecraft:blackstone
setblock 97 74 512 minecraft:smooth_basalt
fill 97 74 539 99 74 540 minecraft:gold_block
fill 97 74 548 99 74 548 minecraft:gold_block
setblock 98 74 511 minecraft:smooth_basalt
fill 98 74 512 98 76 512 minecraft:blackstone
setblock 98 74 550 minecraft:blackstone
setblock 98 74 551 minecraft:smooth_basalt
fill 99 74 511 102 74 511 minecraft:blackstone
fill 99 74 541 101 74 541 minecraft:gold_block
setblock 99 74 550 minecraft:smooth_basalt
fill 99 74 551 99 77 551 minecraft:blackstone
fill 100 74 540 101 74 540 minecraft:gold_block
fill 100 74 542 102 74 542 minecraft:gold_block
fill 100 74 544 102 74 545 minecraft:gold_block
fill 100 74 550 103 74 550 minecraft:blackstone
fill 101 74 543 102 74 543 minecraft:gold_block
setblock 101 74 546 minecraft:gold_block
setblock 103 74 511 minecraft:smooth_basalt
setblock 103 74 551 minecraft:smooth_basalt
fill 104 74 511 107 74 511 minecraft:blackstone
setblock 104 74 550 minecraft:smooth_basalt
fill 104 74 551 104 77 551 minecraft:blackstone
fill 105 74 550 105 77 550 minecraft:blackstone
setblock 108 74 511 minecraft:smooth_basalt
fill 108 74 524 109 74 528 minecraft:gold_block
setblock 108 74 551 minecraft:smooth_basalt
fill 109 74 511 109 77 511 minecraft:blackstone
fill 109 74 523 114 74 523 minecraft:gold_block
fill 109 74 529 115 74 529 minecraft:gold_block
setblock 109 74 550 minecraft:smooth_basalt
fill 109 74 551 109 77 551 minecraft:blackstone
fill 110 74 524 111 76 524 minecraft:gold_block
fill 110 74 528 110 76 528 minecraft:gold_block
fill 110 74 530 111 74 530 minecraft:gold_block
setblock 110 74 549 minecraft:smooth_basalt
fill 110 74 550 110 77 550 minecraft:blackstone
fill 111 74 522 113 74 522 minecraft:gold_block
fill 111 74 549 111 76 549 minecraft:blackstone
setblock 112 74 512 minecraft:smooth_basalt
setblock 113 74 511 minecraft:smooth_basalt
fill 113 74 524 115 74 524 minecraft:gold_block
setblock 113 74 551 minecraft:smooth_basalt
fill 114 74 511 114 77 511 minecraft:blackstone
fill 114 74 525 116 74 525 minecraft:gold_block
fill 114 74 528 116 74 528 minecraft:gold_block
setblock 114 74 530 minecraft:gold_block
setblock 114 74 550 minecraft:smooth_basalt
fill 114 74 551 114 77 551 minecraft:blackstone
fill 115 74 526 116 74 527 minecraft:gold_block
fill 115 74 550 115 75 550 minecraft:blackstone
setblock 118 74 551 minecraft:smooth_basalt
setblock 119 74 551 minecraft:blackstone
fill 126 74 511 127 74 511 minecraft:blackstone
setblock 128 74 511 minecraft:smooth_basalt
setblock 128 74 551 minecraft:smooth_basalt
fill 129 74 511 129 77 511 minecraft:blackstone
fill 129 74 551 129 77 551 minecraft:blackstone
setblock 132 74 512 minecraft:smooth_basalt
fill 132 74 513 132 77 513 minecraft:blackstone
setblock 133 74 511 minecraft:smooth_basalt
fill 133 74 512 133 77 512 minecraft:blackstone
fill 133 74 514 133 75 514 minecraft:blackstone
setblock 133 74 526 minecraft:smooth_basalt
fill 133 74 527 133 75 527 minecraft:blackstone
setblock 133 74 531 minecraft:smooth_basalt
fill 133 74 532 133 75 532 minecraft:blackstone
setblock 133 74 551 minecraft:smooth_basalt
fill 134 74 511 134 77 511 minecraft:blackstone
setblock 134 74 515 minecraft:smooth_basalt
fill 134 74 516 134 77 516 minecraft:blackstone
setblock 134 74 520 minecraft:smooth_basalt
setblock 134 74 521 minecraft:blackstone
setblock 134 74 525 minecraft:smooth_basalt
fill 134 74 526 134 76 526 minecraft:blackstone
setblock 134 74 530 minecraft:smooth_basalt
fill 134 74 531 134 77 531 minecraft:blackstone
setblock 134 74 550 minecraft:smooth_basalt
fill 134 74 551 134 77 551 minecraft:blackstone
setblock 135 74 514 minecraft:smooth_basalt
fill 135 74 515 135 77 515 minecraft:blackstone
setblock 135 74 519 minecraft:smooth_basalt
fill 135 74 520 135 77 520 minecraft:blackstone
setblock 135 74 524 minecraft:smooth_basalt
fill 135 74 525 135 77 525 minecraft:blackstone
setblock 135 74 529 minecraft:smooth_basalt
fill 135 74 530 135 77 530 minecraft:blackstone
setblock 135 74 534 minecraft:smooth_basalt
fill 135 74 535 135 77 535 minecraft:blackstone
setblock 135 74 549 minecraft:smooth_basalt
fill 135 74 550 135 77 550 minecraft:blackstone
setblock 95 75 513 minecraft:smooth_basalt
fill 95 75 514 95 77 514 minecraft:blackstone
setblock 95 75 518 minecraft:smooth_basalt
setblock 95 75 528 minecraft:smooth_basalt
fill 95 75 529 95 76 529 minecraft:blackstone
setblock 95 75 533 minecraft:smooth_basalt
fill 95 75 534 95 77 534 minecraft:blackstone
fill 95 75 545 95 76 545 minecraft:gold_block
setblock 95 75 548 minecraft:smooth_basalt
fill 95 75 549 95 76 551 minecraft:blackstone
setblock 96 75 512 minecraft:smooth_basalt
fill 96 75 513 96 77 513 minecraft:blackstone
fill 96 75 540 96 75 541 minecraft:gold_block
fill 96 75 546 99 75 547 minecraft:gold_block
fill 96 75 550 96 75 551 minecraft:blackstone
setblock 97 75 511 minecraft:smooth_basalt
fill 97 75 512 97 77 512 minecraft:blackstone
fill 97 75 540 99 75 540 minecraft:gold_block
setblock 97 75 550 minecraft:blackstone
setblock 97 75 551 minecraft:smooth_basalt
fill 98 75 511 101 75 511 minecraft:blackstone
setblock 98 75 550 minecraft:smooth_basalt
fill 98 75 551 98 77 551 minecraft:blackstone
fill 99 75 541 100 75 541 minecraft:gold_block
setblock 99 75 550 minecraft:blackstone
fill 100 75 542 101 75 542 minecraft:gold_block
fill 100 75 544 100 75 546 minecraft:gold_block
fill 101 75 543 101 75 545 minecraft:gold_block
setblock 102 75 511 minecraft:smooth_basalt
setblock 102 75 551 minecraft:smooth_basalt
fill 103 75 511 106 75 511 minecraft:blackstone
setblock 103 75 550 minecraft:smooth_basalt
fill 103 75 551 103 77 551 minecraft:blackstone
fill 104 75 550 104 77 550 minecraft:blackstone
setblock 107 75 511 minecraft:smooth_basalt
setblock 107 75 551 minecraft:smooth_basalt
fill 108 75 511 108 77 511 minecraft:blackstone
setblock 108 75 550 minecraft:smooth_basalt
fill 108 75 551 108 77 551 minecraft:blackstone
fill 109 75 512 109 76 512 minecraft:blackstone
fill 109 75 524 109 75 528 minecraft:gold_block
setblock 109 75 549 minecraft:smooth_basalt
fill 109 75 550 109 77 550 minecraft:blackstone
fill 110 75 523 113 75 523 minecraft:gold_block
fill 110 75 529 114 75 529 minecraft:gold_block
fill 110 75 549 110 76 549 minecraft:blackstone
setblock 111 75 512 minecraft:smooth_basalt
setblock 111 75 530 minecraft:gold_block
setblock 112 75 511 minecraft:smooth_basalt
fill 112 75 512 112 77 512 minecraft:blackstone
setblock 112 75 551 minecraft:smooth_basalt
fill 113 75 511 113 77 511 minecraft:blackstone
fill 113 75 524 114 75 524 minecraft:gold_block
setblock 113 75 550 minecraft:smooth_basalt
fill 113 75 551 113 77 551 minecraft:blackstone
fill 114 75 525 115 75 525 minecraft:gold_block
fill 114 75 528 115 75 528 minecraft:gold_block
fill 114 75 550 114 76 550 minecraft:blackstone
fill 115 75 526 115 75 527 minecraft:gold_block
setblock 117 75 551 minecraft:smooth_basalt
setblock 118 75 551 minecraft:blackstone
setblock 126 75 511 minecraft:blackstone
setblock 127 75 511 minecraft:smooth_basalt
setblock 127 75 551 minecraft:smooth_basalt
fill 128 75 511 128 77 512 minecraft:blackstone
fill 128 75 551 128 77 551 minecraft:blackstone
setblock 131 75 512 minecraft:smooth_basalt
fill 131 75 513 131 77 513 minecraft:blackstone
setblock 132 75 511 minecraft:smooth_basalt
fill 132 75 512 132 77 512 minecraft:blackstone
setblock 132 75 551 minecraft:smooth_basalt
fill 133 75 511 133 77 511 minecraft:blackstone
setblock 133 75 530 minecraft:smooth_basalt
fill 133 75 531 133 76 531 minecraft:blackstone
setblock 133 75 550 minecraft:smooth_basalt
fill 133 75 551 133 77 551 minecraft:blackstone
setblock 134 75 514 minecraft:smooth_basalt
fill 134 75 515 134 77 515 minecraft:blackstone
setblock 134 75 524 minecraft:smooth_basalt
fill 134 75 525 134 76 525 minecraft:blackstone
setblock 134 75 529 minecraft:smooth_basalt
fill 134 75 530 134 77 530 minecraft:blackstone
setblock 134 75 534 minecraft:smooth_basalt
setblock 134 75 550 minecraft:blackstone
setblock 135 75 513 minecraft:smooth_basalt
fill 135 75 514 135 77 514 minecraft:blackstone
setblock 135 75 518 minecraft:smooth_basalt
fill 135 75 519 135 77 519 minecraft:blackstone
setblock 135 75 523 minecraft:smooth_basalt
fill 135 75 524 135 77 524 minecraft:blackstone
setblock 135 75 528 minecraft:smooth_basalt
fill 135 75 529 135 77 529 minecraft:blackstone
setblock 135 75 533 minecraft:smooth_basalt
fill 135 75 534 135 77 534 minecraft:blackstone
setblock 135 75 548 minecraft:smooth_basalt
fill 135 75 549 135 76 549 minecraft:blackstone
setblock 95 76 512 minecraft:smooth_basalt
fill 95 76 513 95 77 513 minecraft:blackstone
setblock 95 76 517 minecraft:smooth_basalt
setblock 95 76 532 minecraft:smooth_basalt
fill 95 76 533 95 77 533 minecraft:blackstone
fill 95 76 541 95 76 542 minecraft:gold_block
setblock 95 76 547 minecraft:smooth_basalt
fill 95 76 548 95 77 548 minecraft:blackstone
setblock 96 76 511 minecraft:smooth_basalt
fill 96 76 512 96 77 512 minecraft:blackstone
setblock 96 76 541 minecraft:gold_block
fill 96 76 546 99 76 546 minecraft:gold_block
setblock 96 76 550 minecraft:blackstone
setblock 96 76 551 minecraft:smooth_basalt
fill 97 76 511 100 76 511 minecraft:blackstone
setblock 97 76 550 minecraft:smooth_basalt
fill 97 76 551 97 77 551 minecraft:blackstone
setblock 99 76 541 minecraft:gold_block
setblock 100 76 542 minecraft:gold_block
fill 100 76 544 100 76 545 minecraft:gold_block
setblock 101 76 511 minecraft:smooth_basalt
setblock 101 76 551 minecraft:smooth_basalt
fill 102 76 511 105 76 511 minecraft:blackstone
fill 102 76 551 102 77 551 minecraft:blackstone
setblock 106 76 511 minecraft:smooth_basalt
setblock 106 76 551 minecraft:smooth_basalt
fill 107 76 511 107 77 511 minecraft:blackstone
setblock 107 76 550 minecraft:smooth_basalt
fill 107 76 551 107 77 551 minecraft:blackstone
fill 108 76 512 108 77 512 minecraft:blackstone
fill 108 76 550 108 77 550 minecraft:blackstone
fill 109 76 526 109 76 527 minecraft:gold_block
setblock 109 76 549 minecraft:blackstone
setblock 110 76 512 minecraft:smooth_basalt
setblock 111 76 511 minecraft:smooth_basalt
fill 111 76 512 111 77 512 minecraft:blackstone
fill 111 76 529 113 76 529 minecraft:gold_block
setblock 111 76 551 minecraft:smooth_basalt
fill 112 76 511 112 77 511 minecraft:blackstone
setblock 112 76 550 minecraft:smooth_basalt
fill 112 76 551 112 77 551 minecraft:blackstone
setblock 113 76 524 minecraft:gold_block
fill 113 76 550 113 77 550 minecraft:blackstone
setblock 114 76 525 minecraft:gold_block
setblock 114 76 528 minecraft:gold_block
setblock 116 76 511 minecraft:smooth_basalt
setblock 116 76 551 minecraft:smooth_basalt
setblock 117 76 551 minecraft:blackstone
setblock 125 76 511 minecraft:blackstone
setblock 126 76 511 minecraft:smooth_basalt
fill 127 76 511 127 77 512 minecraft:blackstone
fill 127 76 551 127 77 551 minecraft:blackstone
setblock 130 76 512 minecraft:smooth_basalt
fill 130 76 513 130 77 513 minecraft:blackstone
setblock 131 76 511 minecraft:smooth_basalt
fill 131 76 512 131 77 512 minecraft:blackstone
setblock 131 76 551 minecraft:smooth_basalt
fill 132 76 511 132 77 511 minecraft:blackstone
fill 132 76 551 132 77 551 minecraft:blackstone
setblock 133 76 514 minecraft:smooth_basalt
fill 133 76 515 133 77 515 minecraft:blackstone
setblock 133 76 529 minecraft:smooth_basalt
setblock 133 76 530 minecraft:blackstone
setblock 134 76 513 minecraft:smooth_basalt
fill 134 76 514 134 77 514 minecraft:blackstone
setblock 134 76 518 minecraft:smooth_basalt
setblock 134 76 528 minecraft:smooth_basalt
fill 134 76 529 134 77 529 minecraft:blackstone
setblock 134 76 533 minecraft:smooth_basalt
fill 134 76 534 134 77 534 minecraft:blackstone
setblock 135 76 512 minecraft:smooth_basalt
fill 135 76 513 135 77 513 minecraft:blackstone
setblock 135 76 517 minecraft:smooth_basalt
fill 135 76 518 135 77 518 minecraft:blackstone
setblock 135 76 522 minecraft:smooth_basalt
fill 135 76 523 135 77 523 minecraft:blackstone
setblock 135 76 527 minecraft:smooth_basalt
fill 135 76 528 135 77 528 minecraft:blackstone
setblock 135 76 532 minecraft:smooth_basalt
fill 135 76 533 135 77 533 minecraft:blackstone
setblock 95 77 511 minecraft:smooth_basalt
setblock 95 77 512 minecraft:blackstone
setblock 95 77 516 minecraft:smooth_basalt
setblock 95 77 517 minecraft:blackstone
setblock 95 77 531 minecraft:smooth_basalt
setblock 95 77 532 minecraft:blackstone
setblock 95 77 547 minecraft:blackstone
fill 95 77 549 95 77 550 minecraft:blackstone
setblock 95 77 551 minecraft:smooth_basalt
fill 96 77 511 99 77 511 minecraft:blackstone
setblock 96 77 550 minecraft:smooth_basalt
setblock 96 77 551 minecraft:blackstone
setblock 100 77 511 minecraft:smooth_basalt
setblock 100 77 551 minecraft:smooth_basalt
fill 101 77 511 104 77 511 minecraft:blackstone
setblock 101 77 551 minecraft:blackstone
setblock 105 77 511 minecraft:smooth_basalt
setblock 105 77 551 minecraft:smooth_basalt
setblock 106 77 511 minecraft:blackstone
setblock 106 77 550 minecraft:smooth_basalt
setblock 106 77 551 minecraft:blackstone
setblock 107 77 512 minecraft:blackstone
setblock 107 77 550 minecraft:blackstone
setblock 109 77 512 minecraft:smooth_basalt
setblock 110 77 511 minecraft:smooth_basalt
setblock 110 77 512 minecraft:blackstone
setblock 110 77 551 minecraft:smooth_basalt
setblock 111 77 511 minecraft:blackstone
setblock 111 77 550 minecraft:smooth_basalt
setblock 111 77 551 minecraft:blackstone
setblock 112 77 550 minecraft:blackstone
setblock 115 77 511 minecraft:smooth_basalt
setblock 115 77 551 minecraft:smooth_basalt
setblock 116 77 551 minecraft:blackstone
setblock 124 77 511 minecraft:blackstone
setblock 125 77 511 minecraft:smooth_basalt
fill 126 77 511 126 77 512 minecraft:blackstone
setblock 129 77 512 minecraft:smooth_basalt
setblock 129 77 513 minecraft:blackstone
setblock 130 77 511 minecraft:smooth_basalt
setblock 130 77 512 minecraft:blackstone
setblock 130 77 551 minecraft:smooth_basalt
setblock 131 77 511 minecraft:blackstone
setblock 131 77 551 minecraft:blackstone
setblock 133 77 513 minecraft:smooth_basalt
setblock 133 77 514 minecraft:blackstone
setblock 133 77 516 minecraft:blackstone
setblock 134 77 512 minecraft:smooth_basalt
setblock 134 77 513 minecraft:blackstone
setblock 134 77 517 minecraft:smooth_basalt
setblock 134 77 518 minecraft:blackstone
setblock 134 77 528 minecraft:blackstone
setblock 134 77 532 minecraft:smooth_basalt
setblock 134 77 533 minecraft:blackstone
setblock 135 77 511 minecraft:smooth_basalt
setblock 135 77 512 minecraft:blackstone
setblock 135 77 516 minecraft:smooth_basalt
setblock 135 77 517 minecraft:blackstone
setblock 135 77 521 minecraft:smooth_basalt
setblock 135 77 522 minecraft:blackstone
setblock 135 77 526 minecraft:smooth_basalt
setblock 135 77 527 minecraft:blackstone
setblock 135 77 531 minecraft:smooth_basalt
setblock 135 77 532 minecraft:blackstone
setblock 135 77 551 minecraft:smooth_basalt
setblock 97 80 513 minecraft:light[level=12]
setblock 97 80 521 minecraft:light[level=12]
setblock 97 80 529 minecraft:light[level=12]
setblock 97 80 537 minecraft:light[level=12]
setblock 97 80 545 minecraft:light[level=12]
setblock 105 80 513 minecraft:light[level=12]
setblock 105 80 521 minecraft:light[level=12]
setblock 105 80 529 minecraft:light[level=12]
setblock 105 80 537 minecraft:light[level=12]
setblock 105 80 545 minecraft:light[level=12]
setblock 113 80 513 minecraft:light[level=12]
setblock 113 80 521 minecraft:light[level=12]
setblock 113 80 529 minecraft:light[level=12]
setblock 113 80 537 minecraft:light[level=12]
setblock 113 80 545 minecraft:light[level=12]
setblock 121 80 513 minecraft:light[level=12]
setblock 121 80 521 minecraft:light[level=12]
setblock 121 80 529 minecraft:light[level=12]
setblock 121 80 537 minecraft:light[level=12]
setblock 121 80 545 minecraft:light[level=12]
setblock 129 80 513 minecraft:light[level=12]
setblock 129 80 521 minecraft:light[level=12]
setblock 129 80 529 minecraft:light[level=12]
setblock 129 80 537 minecraft:light[level=12]
setblock 129 80 545 minecraft:light[level=12]
fill 109 82 536 111 82 538 minecraft:redstone_block
fill 115 82 528 117 82 530 minecraft:redstone_block
fill 117 82 533 119 82 535 minecraft:redstone_block
fill 94 83 510 94 91 532 minecraft:gilded_blackstone
fill 94 83 533 111 83 533 minecraft:blackstone
fill 94 83 534 94 91 552 minecraft:gilded_blackstone
fill 95 83 527 111 83 532 minecraft:blackstone
fill 95 83 534 108 83 539 minecraft:blackstone
fill 95 83 552 112 91 552 minecraft:gilded_blackstone
fill 96 83 525 130 83 526 minecraft:blackstone
fill 96 83 540 130 83 541 minecraft:blackstone
fill 97 83 523 129 83 524 minecraft:blackstone
fill 97 83 542 129 83 543 minecraft:blackstone
fill 98 83 522 128 83 522 minecraft:blackstone
fill 98 83 544 128 83 544 minecraft:blackstone
fill 99 83 521 127 83 521 minecraft:blackstone
fill 99 83 545 127 83 545 minecraft:blackstone
fill 100 83 520 126 83 520 minecraft:blackstone
fill 100 83 546 126 83 546 minecraft:blackstone
fill 101 83 519 125 83 519 minecraft:blackstone
fill 101 83 547 125 83 547 minecraft:blackstone
fill 102 83 518 124 83 518 minecraft:blackstone
fill 102 83 548 124 83 548 minecraft:blackstone
fill 103 83 517 123 83 517 minecraft:blackstone
fill 103 83 549 123 83 549 minecraft:blackstone
fill 105 83 516 121 83 516 minecraft:blackstone
fill 105 83 550 121 83 550 minecraft:blackstone
fill 107 83 515 119 83 515 minecraft:blackstone
fill 107 83 551 119 83 551 minecraft:blackstone
fill 109 83 534 111 83 535 minecraft:blackstone
fill 109 83 539 131 83 539 minecraft:blackstone
fill 112 83 527 114 83 531 minecraft:blackstone
fill 112 83 535 116 83 538 minecraft:blackstone
fill 113 83 514 113 90 514 minecraft:blackstone
fill 113 83 552 113 90 552 minecraft:blackstone
fill 114 83 552 136 91 552 minecraft:gilded_blackstone
fill 115 83 527 131 83 527 minecraft:blackstone
fill 115 83 531 116 83 534 minecraft:blackstone
fill 117 83 531 131 83 532 minecraft:blackstone
fill 117 83 536 131 83 538 minecraft:blackstone
fill 118 83 528 131 83 530 minecraft:blackstone
fill 120 83 533 131 83 535 minecraft:blackstone
fill 132 83 533 132 90 533 minecraft:blackstone
fill 94 84 533 108 85 533 minecraft:blackstone
fill 95 84 511 95 84 526 minecraft:basalt
fill 95 84 527 95 90 530 minecraft:blackstone
fill 95 84 531 95 90 531 minecraft:gold_block
fill 95 84 532 105 87 532 minecraft:blackstone
fill 95 84 534 95 90 539 minecraft:blackstone
fill 95 84 540 95 84 551 minecraft:basalt
fill 96 84 511 96 84 524 minecraft:basalt
fill 96 84 525 98 90 529 minecraft:blackstone
fill 96 84 530 97 90 530 minecraft:gold_block
fill 96 84 531 108 86 531 minecraft:blackstone
fill 96 84 534 96 90 538 minecraft:blackstone
fill 96 84 539 96 90 539 minecraft:gold_block
fill 96 84 540 101 89 541 minecraft:blackstone
fill 96 84 542 96 84 551 minecraft:basalt
fill 97 84 511 97 84 522 minecraft:basalt
fill 97 84 523 97 90 524 minecraft:blackstone
fill 97 84 534 97 90 536 minecraft:blackstone
fill 97 84 537 97 90 537 minecraft:gold_block
fill 97 84 538 102 89 539 minecraft:blackstone
fill 97 84 542 100 90 543 minecraft:blackstone
fill 97 84 544 97 84 551 minecraft:basalt
fill 98 84 511 98 84 521 minecraft:basalt
fill 98 84 522 109 88 522 minecraft:blackstone
fill 98 84 523 100 90 523 minecraft:gold_block
fill 98 84 524 103 89 524 minecraft:blackstone
fill 98 84 530 109 85 530 minecraft:blackstone
fill 98 84 534 98 90 535 minecraft:blackstone
fill 98 84 536 98 90 536 minecraft:gold_block
fill 98 84 537 103 88 537 minecraft:blackstone
fill 98 84 544 105 89 544 minecraft:blackstone
fill 98 84 545 98 84 551 minecraft:basalt
fill 99 84 511 99 84 520 minecraft:basalt
fill 99 84 521 108 89 521 minecraft:blackstone
fill 99 84 525 106 87 528 minecraft:blackstone
fill 99 84 529 100 89 529 minecraft:gold_block
fill 99 84 534 100 89 534 minecraft:blackstone
fill 99 84 535 99 89 535 minecraft:gold_block
fill 99 84 536 104 87 536 minecraft:blackstone
fill 99 84 545 99 90 545 minecraft:blackstone
fill 99 84 546 99 84 551 minecraft:basalt
fill 100 84 511 100 84 519 minecraft:basalt
fill 100 84 520 107 89 520 minecraft:blackstone
fill 100 84 535 107 86 535 minecraft:blackstone
fill 100 84 545 100 90 546 minecraft:gold_block
fill 100 84 547 100 84 551 minecraft:basalt
fill 101 84 511 101 84 518 minecraft:basalt
fill 101 84 519 113 89 519 minecraft:blackstone
fill 101 84 523 110 88 523 minecraft:blackstone
fill 101 84 529 106 87 529 minecraft:blackstone
fill 101 84 534 101 89 534 minecraft:gold_block
fill 101 84 542 101 90 542 minecraft:gold_block
fill 101 84 543 105 89 543 minecraft:blackstone
fill 101 84 545 105 90 547 minecraft:blackstone
fill 101 84 548 101 84 551 minecraft:basalt
fill 102 84 511 102 84 517 minecraft:basalt
fill 102 84 518 103 90 518 minecraft:blackstone
fill 102 84 534 108 86 534 minecraft:blackstone
fill 102 84 540 102 89 540 minecraft:gold_block
fill 102 84 541 113 87 542 minecraft:blackstone
fill 102 84 548 120 90 548 minecraft:blackstone
fill 102 84 549 102 84 551 minecraft:basalt
fill 103 84 511 104 84 516 minecraft:basalt
fill 103 84 517 112 90 517 minecraft:blackstone
fill 103 84 538 103 88 538 minecraft:gold_block
fill 103 84 539 107 87 540 minecraft:blackstone
fill 103 84 549 112 90 549 minecraft:blackstone
fill 103 84 550 104 84 551 minecraft:basalt
fill 104 84 518 105 90 518 minecraft:gold_block
fill 104 84 524 105 89 524 minecraft:gold_block
fill 104 84 537 104 88 537 minecraft:gold_block
fill 104 84 538 107 87 538 minecraft:blackstone
fill 105 84 511 106 84 515 minecraft:basalt
fill 105 84 516 111 90 516 minecraft:blackstone
fill 105 84 536 105 87 536 minecraft:gold_block
fill 105 84 537 107 86 537 minecraft:blackstone
fill 105 84 550 106 90 550 minecraft:blackstone
fill 105 84 551 106 84 551 minecraft:basalt
fill 106 84 518 124 90 518 minecraft:blackstone
fill 106 84 524 124 87 524 minecraft:blackstone
fill 106 84 532 106 86 532 minecraft:gold_block
fill 106 84 536 107 86 536 minecraft:blackstone
fill 106 84 543 106 89 547 minecraft:gold_block
fill 107 84 511 112 84 514 minecraft:basalt
fill 107 84 515 110 90 515 minecraft:blackstone
fill 107 84 525 107 88 525 minecraft:gold_block
fill 107 84 526 112 86 528 minecraft:blackstone
fill 107 84 529 107 86 529 minecraft:gold_block
fill 107 84 532 108 86 532 minecraft:blackstone
fill 107 84 543 110 88 547 minecraft:blackstone
fill 107 84 550 107 90 551 minecraft:gold_block
fill 108 84 520 108 89 520 minecraft:gold_block
fill 108 84 525 111 87 525 minecraft:blackstone
fill 108 84 529 110 85 529 minecraft:blackstone
fill 108 84 535 108 84 539 minecraft:shroomlight
fill 108 84 540 130 86 540 minecraft:blackstone
fill 108 84 550 113 90 551 minecraft:blackstone
fill 109 84 520 119 89 520 minecraft:blackstone
fill 109 84 521 109 89 521 minecraft:gold_block
fill 109 84 531 110 85 534 minecraft:magma_block
fill 109 84 535 116 84 535 minecraft:shroomlight
fill 109 84 536 111 84 538 minecraft:basalt
fill 109 84 539 112 84 539 minecraft:shroomlight
fill 110 84 521 114 88 521 minecraft:blackstone
fill 110 84 522 110 88 522 minecraft:gold_block
fill 110 84 530 113 85 530 minecraft:magma_block
fill 111 84 515 111 90 515 minecraft:gold_block
fill 111 84 522 114 88 522 minecraft:blackstone
fill 111 84 523 111 88 523 minecraft:gold_block
fill 111 84 529 113 85 529 minecraft:magma_block
fill 111 84 531 111 84 534 minecraft:shroomlight
fill 111 84 543 114 88 543 minecraft:blackstone
fill 111 84 544 111 88 545 minecraft:gold_block
fill 111 84 546 111 89 547 minecraft:blackstone
fill 112 84 515 118 90 515 minecraft:blackstone
fill 112 84 516 112 90 516 minecraft:gold_block
fill 112 84 523 119 88 523 minecraft:blackstone
fill 112 84 525 112 87 525 minecraft:gold_block
fill 112 84 531 118 84 531 minecraft:shroomlight
fill 112 84 536 112 84 538 minecraft:shroomlight
fill 112 84 544 115 88 546 minecraft:blackstone
fill 112 84 547 112 89 547 minecraft:gold_block
fill 113 84 511 135 84 513 minecraft:basalt
fill 113 84 516 118 90 516 minecraft:blackstone
fill 113 84 517 113 90 517 minecraft:gold_block
fill 113 84 525 113 86 527 minecraft:blackstone
fill 113 84 528 113 85 528 minecraft:gold_block
fill 113 84 536 115 85 537 minecraft:magma_block
fill 113 84 538 113 85 538 minecraft:gold_block
fill 113 84 539 131 86 539 minecraft:blackstone
fill 113 84 547 125 89 547 minecraft:blackstone
fill 113 84 549 113 90 549 minecraft:gold_block
fill 114 84 514 135 84 514 minecraft:basalt
fill 114 84 517 123 90 517 minecraft:blackstone
fill 114 84 519 114 89 519 minecraft:gold_block
fill 114 84 525 123 86 526 minecraft:blackstone
fill 114 84 527 114 84 530 minecraft:shroomlight
fill 114 84 538 131 86 538 minecraft:blackstone
fill 114 84 541 114 87 541 minecraft:gold_block
fill 114 84 542 120 87 542 minecraft:blackstone
fill 114 84 549 123 90 549 minecraft:blackstone
fill 114 84 550 114 90 550 minecraft:gold_block
fill 114 84 551 114 90 551 minecraft:blackstone
fill 115 84 519 119 89 519 minecraft:blackstone
fill 115 84 521 115 88 522 minecraft:gold_block
fill 115 84 527 118 84 527 minecraft:shroomlight
fill 115 84 528 117 84 530 minecraft:basalt
fill 115 84 532 116 84 534 minecraft:shroomlight
fill 115 84 541 118 87 541 minecraft:blackstone
fill 115 84 543 115 88 543 minecraft:gold_block
fill 115 84 550 121 90 550 minecraft:blackstone
fill 115 84 551 115 90 551 minecraft:gold_block
fill 116 84 521 119 88 522 minecraft:blackstone
fill 116 84 536 120 84 536 minecraft:shroomlight
fill 116 84 537 118 85 537 minecraft:blackstone
fill 116 84 543 125 88 543 minecraft:blackstone
fill 116 84 544 116 88 544 minecraft:gold_block
fill 116 84 545 116 89 546 minecraft:blackstone
fill 116 84 551 119 90 551 minecraft:blackstone
fill 117 84 532 120 84 532 minecraft:shroomlight
fill 117 84 533 119 84 535 minecraft:basalt
fill 117 84 544 128 88 544 minecraft:blackstone
fill 117 84 545 117 89 545 minecraft:gold_block
fill 117 84 546 117 89 546 minecraft:blackstone
fill 118 84 528 118 84 530 minecraft:shroomlight
fill 118 84 545 127 89 545 minecraft:blackstone
fill 118 84 546 118 89 546 minecraft:gold_block
fill 119 84 515 119 90 516 minecraft:gold_block
fill 119 84 527 120 86 531 minecraft:blackstone
fill 119 84 537 119 86 537 minecraft:gold_block
fill 119 84 541 119 88 541 minecraft:gold_block
fill 119 84 546 126 89 546 minecraft:blackstone
fill 120 84 515 135 84 515 minecraft:basalt
fill 120 84 516 121 90 516 minecraft:blackstone
fill 120 84 519 120 89 523 minecraft:gold_block
fill 120 84 533 120 84 535 minecraft:shroomlight
fill 120 84 537 125 87 537 minecraft:blackstone
fill 120 84 541 130 88 541 minecraft:blackstone
fill 120 84 551 135 84 551 minecraft:basalt
fill 121 84 519 125 89 523 minecraft:blackstone
fill 121 84 527 121 87 529 minecraft:blackstone
fill 121 84 530 121 87 530 minecraft:gold_block
fill 121 84 531 124 87 536 minecraft:blackstone
fill 121 84 542 122 89 542 minecraft:gold_block
fill 121 84 548 122 90 548 minecraft:gold_block
fill 122 84 516 135 84 516 minecraft:basalt
fill 122 84 527 122 88 528 minecraft:blackstone
fill 122 84 529 122 88 529 minecraft:gold_block
fill 122 84 530 127 87 530 minecraft:blackstone
fill 122 84 550 135 84 550 minecraft:basalt
fill 123 84 527 129 88 527 minecraft:blackstone
fill 123 84 528 123 88 528 minecraft:gold_block
fill 123 84 529 128 88 529 minecraft:blackstone
fill 123 84 542 129 89 542 minecraft:blackstone
fill 123 84 548 124 90 548 minecraft:blackstone
fill 124 84 517 135 84 517 minecraft:basalt
fill 124 84 525 130 89 525 minecraft:blackstone
fill 124 84 526 124 89 526 minecraft:gold_block
fill 124 84 528 131 89 528 minecraft:blackstone
fill 124 84 549 135 84 549 minecraft:basalt
fill 125 84 518 135 84 518 minecraft:basalt
fill 125 84 524 125 90 524 minecraft:gold_block
fill 125 84 526 130 89 526 minecraft:blackstone
fill 125 84 531 126 89 531 minecraft:blackstone
fill 125 84 532 125 89 532 minecraft:gold_block
fill 125 84 533 128 88 536 minecraft:blackstone
fill 125 84 548 135 84 548 minecraft:basalt
fill 126 84 519 135 84 519 minecraft:basalt
fill 126 84 520 126 90 521 minecraft:gold_block
fill 126 84 522 128 90 524 minecraft:blackstone
fill 126 84 532 131 89 532 minecraft:blackstone
fill 126 84 537 127 89 537 minecraft:gold_block
fill 126 84 543 128 90 543 minecraft:gold_block
fill 126 84 547 135 84 547 minecraft:basalt
fill 127 84 520 135 84 520 minecraft:basalt
fill 127 84 521 127 90 521 minecraft:blackstone
fill 127 84 531 127 89 531 minecraft:gold_block
fill 127 84 546 135 84 546 minecraft:basalt
fill 128 84 521 135 84 521 minecraft:basalt
fill 128 84 530 128 90 530 minecraft:gold_block
fill 128 84 531 131 90 531 minecraft:blackstone
fill 128 84 537 131 90 537 minecraft:blackstone
fill 128 84 545 135 84 545 minecraft:basalt
fill 129 84 522 135 84 522 minecraft:basalt
fill 129 84 523 129 90 524 minecraft:blackstone
fill 129 84 529 129 90 529 minecraft:gold_block
fill 129 84 530 131 90 530 minecraft:blackstone
fill 129 84 533 130 90 535 minecraft:blackstone
fill 129 84 536 130 90 536 minecraft:gold_block
fill 129 84 543 129 90 543 minecraft:blackstone
fill 129 84 544 135 84 544 minecraft:basalt
fill 130 84 523 135 84 524 minecraft:basalt
fill 130 84 527 130 90 527 minecraft:gold_block
fill 130 84 529 131 90 529 minecraft:blackstone
fill 130 84 542 135 84 543 minecraft:basalt
fill 131 84 525 135 84 526 minecraft:basalt
fill 131 84 527 131 90 527 minecraft:blackstone
fill 131 84 533 131 90 534 minecraft:blackstone
fill 131 84 535 131 90 535 minecraft:gold_block
fill 131 84 536 131 90 536 minecraft:blackstone
fill 131 84 540 135 84 541 minecraft:basalt
fill 132 84 527 135 84 532 minecraft:basalt
fill 132 84 534 135 84 539 minecraft:basalt
fill 133 84 533 135 84 533 minecraft:basalt
fill 108 85 535 108 86 539 minecraft:blackstone
fill 109 85 535 111 85 535 minecraft:magma_block
fill 109 85 536 109 85 539 minecraft:blackstone
fill 110 85 536 112 85 536 minecraft:magma_block
fill 110 85 537 110 85 539 minecraft:blackstone
setblock 111 85 531 minecraft:magma_block
fill 111 85 537 112 85 537 minecraft:magma_block
fill 111 85 538 112 86 539 minecraft:blackstone
fill 114 85 527 118 86 528 minecraft:blackstone
fill 114 85 529 115 85 530 minecraft:magma_block
fill 115 85 531 117 85 531 minecraft:magma_block
fill 115 85 535 117 85 535 minecraft:magma_block
fill 116 85 529 118 85 529 minecraft:blackstone
setblock 116 85 530 minecraft:magma_block
fill 116 85 532 117 85 534 minecraft:magma_block
setblock 116 85 536 minecraft:magma_block
fill 117 85 530 118 85 530 minecraft:blackstone
fill 117 85 536 120 85 536 minecraft:blackstone
fill 118 85 531 118 85 535 minecraft:blackstone
fill 119 85 532 119 86 535 minecraft:blackstone
fill 120 85 532 120 86 533 minecraft:blackstone
fill 120 85 534 120 86 534 minecraft:gold_block
fill 120 85 535 120 86 535 minecraft:blackstone
fill 94 86 533 107 86 533 minecraft:blackstone
fill 98 86 530 108 86 530 minecraft:blackstone
fill 108 86 529 109 86 529 minecraft:blackstone
fill 109 86 537 109 86 539 minecraft:blackstone
fill 110 86 538 110 86 539 minecraft:blackstone
fill 117 86 529 118 86 529 minecraft:blackstone
fill 117 86 537 118 86 537 minecraft:blackstone
fill 118 86 530 118 86 532 minecraft:blackstone
fill 118 86 534 118 86 536 minecraft:blackstone
fill 119 86 536 120 86 536 minecraft:blackstone
fill 94 87 533 105 87 533 minecraft:blackstone
fill 96 87 531 105 87 531 minecraft:blackstone
fill 98 87 530 106 87 530 minecraft:blackstone
fill 100 87 535 105 87 535 minecraft:blackstone
fill 102 87 534 105 87 534 minecraft:blackstone
fill 105 87 537 106 87 537 minecraft:blackstone
setblock 106 87 536 minecraft:blackstone
fill 107 87 526 107 87 528 minecraft:blackstone
fill 108 87 526 108 87 527 minecraft:blackstone
fill 108 87 539 108 87 540 minecraft:blackstone
fill 109 87 526 110 87 526 minecraft:blackstone
fill 109 87 540 110 87 540 minecraft:blackstone
fill 113 87 525 123 87 525 minecraft:blackstone
fill 116 87 526 123 87 526 minecraft:blackstone
fill 116 87 540 130 87 540 minecraft:blackstone
fill 118 87 527 120 87 527 minecraft:blackstone
fill 118 87 539 131 87 539 minecraft:blackstone
fill 119 87 528 120 87 528 minecraft:blackstone
fill 119 87 538 131 87 538 minecraft:blackstone
fill 120 87 529 120 87 530 minecraft:blackstone
setblock 120 87 536 minecraft:blackstone
fill 94 88 533 103 88 533 minecraft:blackstone
fill 95 88 532 103 88 532 minecraft:blackstone
setblock 95 88 540 minecraft:smooth_basalt
fill 95 88 541 95 88 544 minecraft:blackstone
setblock 95 88 545 minecraft:smooth_basalt
fill 95 88 546 95 90 547 minecraft:blackstone
fill 96 88 531 103 88 531 minecraft:blackstone
fill 96 88 542 96 88 543 minecraft:blackstone
setblock 97 88 513 minecraft:light[level=12]
setblock 97 88 521 minecraft:light[level=12]
setblock 97 88 545 minecraft:light[level=12]
fill 98 88 530 103 88 530 minecraft:blackstone
fill 99 88 525 104 88 528 minecraft:blackstone
fill 99 88 536 103 88 536 minecraft:blackstone
fill 100 88 535 103 88 535 minecraft:blackstone
fill 100 88 551 103 88 551 minecraft:blackstone
fill 101 88 529 104 88 529 minecraft:blackstone
fill 102 88 534 103 88 534 minecraft:blackstone
fill 102 88 541 107 88 542 minecraft:blackstone
fill 103 88 539 105 88 540 minecraft:blackstone
setblock 104 88 538 minecraft:blackstone
setblock 104 88 551 minecraft:smooth_basalt
setblock 105 88 513 minecraft:light[level=12]
fill 105 88 525 105 88 527 minecraft:blackstone
setblock 105 88 529 minecraft:light[level=12]
setblock 105 88 537 minecraft:light[level=12]
fill 105 88 551 106 88 551 minecraft:blackstone
fill 106 88 524 106 88 526 minecraft:blackstone
setblock 106 88 540 minecraft:blackstone
fill 107 88 524 109 88 524 minecraft:blackstone
fill 108 88 542 109 88 542 minecraft:blackstone
setblock 113 88 513 minecraft:light[level=12]
setblock 113 88 529 minecraft:light[level=12]
setblock 113 88 537 minecraft:light[level=12]
fill 117 88 524 124 88 524 minecraft:blackstone
fill 117 88 542 120 88 542 minecraft:blackstone
fill 119 88 525 123 88 525 minecraft:blackstone
fill 120 88 526 123 88 526 minecraft:blackstone
fill 120 88 540 130 88 540 minecraft:blackstone
fill 121 88 511 123 88 511 minecraft:blackstone
setblock 121 88 513 minecraft:light[level=12]
setblock 121 88 527 minecraft:blackstone
setblock 121 88 529 minecraft:light[level=12]
setblock 121 88 537 minecraft:light[level=12]
fill 121 88 539 131 88 539 minecraft:blackstone
setblock 122 88 512 minecraft:blackstone
fill 122 88 537 125 88 538 minecraft:blackstone
setblock 123 88 512 minecraft:smooth_basalt
fill 123 88 530 124 88 536 minecraft:blackstone
setblock 124 88 511 minecraft:smooth_basalt
fill 124 88 512 126 88 513 minecraft:blackstone
fill 125 88 511 128 88 511 minecraft:blackstone
fill 125 88 530 127 89 530 minecraft:blackstone
fill 126 88 538 131 89 538 minecraft:blackstone
setblock 127 88 512 minecraft:blackstone
setblock 127 88 513 minecraft:smooth_basalt
setblock 128 88 512 minecraft:smooth_basalt
setblock 129 88 511 minecraft:smooth_basalt
setblock 129 88 512 minecraft:blackstone
setblock 129 88 513 minecraft:light[level=12]
setblock 129 88 521 minecraft:light[level=12]
setblock 129 88 545 minecraft:light[level=12]
fill 130 88 511 132 88 511 minecraft:blackstone
fill 135 88 513 135 88 514 minecraft:blackstone
setblock 135 88 515 minecraft:smooth_basalt
fill 135 88 516 135 88 519 minecraft:blackstone
setblock 135 88 520 minecraft:smooth_basalt
setblock 135 88 521 minecraft:blackstone
fill 94 89 533 100 89 533 minecraft:blackstone
fill 95 89 532 101 89 532 minecraft:blackstone
fill 95 89 540 95 89 543 minecraft:blackstone
setblock 95 89 544 minecraft:smooth_basalt
fill 95 89 545 95 92 545 minecraft:blackstone
fill 96 89 531 101 89 531 minecraft:blackstone
setblock 96 89 542 minecraft:blackstone
setblock 96 89 543 minecraft:smooth_basalt
fill 96 89 544 96 92 544 minecraft:blackstone
fill 98 89 522 108 89 522 minecraft:blackstone
fill 98 89 530 101 89 530 minecraft:blackstone
fill 98 89 537 101 89 537 minecraft:blackstone
fill 99 89 525 102 89 528 minecraft:blackstone
fill 99 89 536 101 89 536 minecraft:blackstone
fill 100 89 535 101 89 535 minecraft:blackstone
fill 100 89 551 102 89 551 minecraft:blackstone
fill 101 89 523 106 89 523 minecraft:blackstone
setblock 101 89 529 minecraft:blackstone
fill 102 89 541 104 89 542 minecraft:blackstone
fill 103 89 525 103 89 526 minecraft:blackstone
setblock 103 89 540 minecraft:blackstone
setblock 103 89 551 minecraft:smooth_basalt
setblock 104 89 525 minecraft:blackstone
fill 104 89 551 105 89 551 minecraft:blackstone
setblock 105 89 542 minecraft:blackstone
fill 107 89 544 108 89 547 minecraft:blackstone
fill 109 89 545 110 89 547 minecraft:blackstone
fill 110 89 521 112 89 521 minecraft:blackstone
setblock 111 89 545 minecraft:gold_block
fill 112 89 545 112 89 546 minecraft:blackstone
fill 113 89 546 115 89 546 minecraft:blackstone
setblock 114 89 521 minecraft:blackstone
fill 114 89 545 115 89 545 minecraft:blackstone
setblock 115 89 521 minecraft:gold_block
fill 116 89 521 119 89 521 minecraft:blackstone
fill 118 89 522 119 89 522 minecraft:blackstone
fill 118 89 544 128 89 544 minecraft:blackstone
fill 120 89 543 125 89 543 minecraft:blackstone
fill 121 89 511 122 89 511 minecraft:blackstone
fill 121 89 524 124 89 524 minecraft:blackstone
fill 122 89 525 123 89 525 minecraft:blackstone
fill 122 89 541 130 89 541 minecraft:blackstone
setblock 123 89 511 minecraft:smooth_basalt
fill 123 89 512 126 89 512 minecraft:blackstone
setblock 123 89 526 minecraft:blackstone
fill 123 89 540 130 89 540 minecraft:blackstone
fill 124 89 511 127 89 511 minecraft:blackstone
fill 124 89 527 129 89 527 minecraft:blackstone
fill 124 89 538 125 89 539 minecraft:blackstone
fill 125 89 529 128 89 529 minecraft:blackstone
fill 125 89 534 125 89 537 minecraft:blackstone
fill 126 89 533 128 89 536 minecraft:blackstone
fill 126 89 539 131 89 539 minecraft:blackstone
setblock 127 89 512 minecraft:smooth_basalt
setblock 128 89 511 minecraft:smooth_basalt
fill 129 89 511 130 89 511 minecraft:blackstone
fill 135 89 515 135 89 518 minecraft:blackstone
setblock 135 89 519 minecraft:smooth_basalt
fill 135 89 520 135 92 520 minecraft:blackstone
fill 94 90 533 98 90 533 minecraft:blackstone
fill 95 90 532 98 90 532 minecraft:blackstone
fill 95 90 540 95 90 542 minecraft:blackstone
setblock 95 90 543 minecraft:smooth_basalt
fill 95 90 544 95 93 544 minecraft:blackstone
setblock 95 90 548 minecraft:smooth_basalt
fill 96 90 531 98 90 531 minecraft:blackstone
fill 96 90 540 100 90 541 minecraft:blackstone
setblock 96 90 542 minecraft:smooth_basalt
fill 96 90 543 96 93 543 minecraft:blackstone
fill 96 90 545 96 91 545 minecraft:blackstone
fill 97 90 538 99 90 539 minecraft:blackstone
fill 98 90 522 103 90 522 minecraft:blackstone
fill 98 90 524 101 90 524 minecraft:blackstone
setblock 98 90 530 minecraft:blackstone
fill 98 90 537 99 90 537 minecraft:blackstone
fill 98 90 544 103 90 544 minecraft:blackstone
fill 99 90 521 105 90 521 minecraft:blackstone
fill 99 90 525 99 90 528 minecraft:blackstone
setblock 99 90 529 minecraft:gold_block
fill 100 90 520 106 90 520 minecraft:blackstone
fill 100 90 525 100 90 526 minecraft:blackstone
fill 100 90 551 101 90 551 minecraft:blackstone
fill 101 90 519 109 90 519 minecraft:blackstone
fill 101 90 523 102 90 523 minecraft:blackstone
setblock 101 90 525 minecraft:blackstone
setblock 101 90 541 minecraft:blackstone
fill 101 90 543 102 90 543 minecraft:blackstone
setblock 102 90 551 minecraft:smooth_basalt
fill 103 90 551 104 92 551 minecraft:blackstone
fill 106 90 546 106 90 547 minecraft:gold_block
fill 107 90 547 109 90 547 minecraft:blackstone
fill 117 90 519 119 90 519 minecraft:blackstone
fill 117 90 547 125 90 547 minecraft:blackstone
fill 120 90 519 120 90 520 minecraft:gold_block
fill 120 90 546 126 90 546 minecraft:blackstone
setblock 121 90 511 minecraft:blackstone
fill 121 90 519 125 90 521 minecraft:blackstone
fill 121 90 545 127 90 545 minecraft:blackstone
setblock 122 90 511 minecraft:smooth_basalt
fill 123 90 511 125 90 512 minecraft:blackstone
fill 123 90 522 125 90 522 minecraft:blackstone
fill 123 90 544 128 90 544 minecraft:blackstone
fill 124 90 523 125 90 523 minecraft:blackstone
fill 124 90 543 125 90 543 minecraft:blackstone
fill 125 90 525 130 90 525 minecraft:blackstone
fill 125 90 541 129 90 542 minecraft:blackstone
setblock 126 90 511 minecraft:blackstone
fill 126 90 526 130 90 526 minecraft:blackstone
fill 126 90 540 130 90 540 minecraft:blackstone
setblock 127 90 511 minecraft:smooth_basalt
fill 127 90 527 128 90 529 minecraft:blackstone
setblock 127 90 537 minecraft:gold_block
fill 127 90 538 131 90 539 minecraft:blackstone
fill 128 90 511 128 91 511 minecraft:blackstone
fill 128 90 532 128 90 536 minecraft:blackstone
fill 129 90 527 129 90 528 minecraft:blackstone
fill 129 90 532 131 90 532 minecraft:blackstone
fill 130 90 528 131 90 528 minecraft:blackstone
setblock 130 90 541 minecraft:blackstone
setblock 135 90 517 minecraft:blackstone
setblock 135 90 518 minecraft:smooth_basalt
fill 135 90 519 135 91 519 minecraft:blackstone
setblock 135 90 543 minecraft:smooth_basalt
fill 135 90 544 135 93 544 minecraft:blackstone
fill 94 91 533 94 95 533 minecraft:gilded_blackstone
fill 95 91 538 95 91 541 minecraft:blackstone
setblock 95 91 542 minecraft:smooth_basalt
fill 95 91 543 95 94 543 minecraft:blackstone
setblock 95 91 546 minecraft:blackstone
setblock 95 91 547 minecraft:smooth_basalt
fill 95 91 548 95 94 548 minecraft:blackstone
setblock 96 91 540 minecraft:blackstone
setblock 96 91 541 minecraft:smooth_basalt
fill 96 91 542 96 94 542 minecraft:blackstone
setblock 96 91 546 minecraft:smooth_basalt
fill 97 91 543 97 92 543 minecraft:blackstone
fill 99 91 551 100 91 551 minecraft:blackstone
setblock 101 91 551 minecraft:smooth_basalt
fill 102 91 551 102 94 551 minecraft:blackstone
setblock 113 91 552 minecraft:gilded_blackstone
setblock 121 91 511 minecraft:smooth_basalt
fill 122 91 511 125 91 511 minecraft:blackstone
setblock 126 91 511 minecraft:smooth_basalt
fill 127 91 511 127 94 511 minecraft:blackstone
setblock 135 91 542 minecraft:smooth_basalt
fill 135 91 543 135 94 543 minecraft:blackstone
fill 135 91 545 135 91 546 minecraft:blackstone
setblock 135 91 547 minecraft:smooth_basalt
fill 94 92 510 99 92 510 minecraft:gilded_blackstone
setblock 94 92 511 minecraft:blackstone
fill 94 92 512 94 95 513 minecraft:gilded_blackstone
setblock 94 92 514 minecraft:blackstone
fill 94 92 515 94 95 528 minecraft:gilded_blackstone
setblock 94 92 529 minecraft:blackstone
fill 94 92 530 94 95 532 minecraft:gilded_blackstone
fill 94 92 534 94 95 535 minecraft:gilded_blackstone
setblock 94 92 536 minecraft:blackstone
fill 94 92 537 94 92 552 minecraft:gilded_blackstone
fill 95 92 538 95 92 540 minecraft:blackstone
setblock 95 92 541 minecraft:smooth_basalt
fill 95 92 542 95 95 542 minecraft:blackstone
setblock 95 92 546 minecraft:smooth_basalt
fill 95 92 547 96 94 547 minecraft:blackstone
fill 95 92 549 95 92 550 minecraft:blackstone
fill 95 92 552 98 92 552 minecraft:gilded_blackstone
setblock 96 92 540 minecraft:smooth_basalt
fill 96 92 541 97 94 541 minecraft:blackstone
setblock 96 92 545 minecraft:smooth_basalt
fill 96 92 546 96 95 546 minecraft:blackstone
fill 96 92 548 96 93 548 minecraft:blackstone
fill 97 92 542 97 93 542 minecraft:blackstone
setblock 97 92 544 minecraft:smooth_basalt
fill 97 92 545 97 95 545 minecraft:blackstone
fill 97 92 551 99 92 551 minecraft:blackstone
setblock 99 92 552 minecraft:blackstone
setblock 100 92 510 minecraft:blackstone
setblock 100 92 550 minecraft:blackstone
setblock 100 92 551 minecraft:smooth_basalt
fill 100 92 552 104 92 552 minecraft:gilded_blackstone
fill 101 92 510 111 92 510 minecraft:gilded_blackstone
setblock 101 92 550 minecraft:smooth_basalt
fill 101 92 551 101 95 551 minecraft:blackstone
setblock 105 92 552 minecraft:blackstone
fill 106 92 552 109 92 552 minecraft:gilded_blackstone
fill 110 92 552 110 93 552 minecraft:blackstone
fill 111 92 552 111 95 552 minecraft:gilded_blackstone
setblock 112 92 510 minecraft:blackstone
fill 112 92 552 113 92 552 minecraft:blackstone
fill 113 92 510 127 93 510 minecraft:gilded_blackstone
fill 114 92 552 116 95 552 minecraft:gilded_blackstone
fill 117 92 552 117 93 552 minecraft:blackstone
fill 118 92 552 120 92 552 minecraft:gilded_blackstone
setblock 120 92 511 minecraft:smooth_basalt
fill 121 92 511 124 92 511 minecraft:blackstone
fill 121 92 552 122 92 552 minecraft:blackstone
fill 123 92 551 124 92 551 minecraft:blackstone
fill 123 92 552 125 95 552 minecraft:gilded_blackstone
setblock 125 92 511 minecraft:smooth_basalt
setblock 125 92 551 minecraft:smooth_basalt
fill 126 92 511 126 95 511 minecraft:blackstone
setblock 126 92 552 minecraft:blackstone
fill 127 92 552 130 95 552 minecraft:gilded_blackstone
setblock 128 92 510 minecraft:blackstone
fill 129 92 510 136 93 510 minecraft:gilded_blackstone
setblock 131 92 552 minecraft:blackstone
fill 132 92 552 136 95 552 minecraft:gilded_blackstone
setblock 135 92 521 minecraft:smooth_basalt
setblock 135 92 541 minecraft:smooth_basalt
fill 135 92 542 135 95 542 minecraft:blackstone
setblock 135 92 545 minecraft:blackstone
setblock 135 92 546 minecraft:smooth_basalt
fill 135 92 547 135 93 549 minecraft:blackstone
fill 136 92 511 136 92 514 minecraft:gilded_blackstone
fill 136 92 515 136 92 517 minecraft:blackstone
fill 136 92 518 136 95 520 minecraft:gilded_blackstone
fill 136 92 521 136 92 523 minecraft:blackstone
fill 136 92 524 136 95 527 minecraft:gilded_blackstone
setblock 136 92 528 minecraft:blackstone
fill 136 92 529 136 95 532 minecraft:gilded_blackstone
setblock 136 92 533 minecraft:blackstone
fill 136 92 534 136 95 536 minecraft:gilded_blackstone
fill 136 92 537 136 92 539 minecraft:blackstone
fill 136 92 540 136 92 545 minecraft:gilded_blackstone
setblock 136 92 546 minecraft:blackstone
fill 136 92 547 136 93 551 minecraft:gilded_blackstone
setblock 94 93 510 minecraft:blackstone
fill 94 93 511 94 95 511 minecraft:gilded_blackstone
fill 94 93 514 94 95 514 minecraft:gilded_blackstone
fill 94 93 529 94 95 529 minecraft:gilded_blackstone
fill 94 93 536 94 95 536 minecraft:gilded_blackstone
setblock 94 93 537 minecraft:blackstone
fill 94 93 538 94 93 544 minecraft:gilded_blackstone
setblock 94 93 545 minecraft:blackstone
fill 94 93 546 94 93 549 minecraft:gilded_blackstone
fill 94 93 550 94 94 550 minecraft:blackstone
fill 94 93 551 94 95 551 minecraft:gilded_blackstone
setblock 94 93 552 minecraft:blackstone
fill 95 93 510 103 93 510 minecraft:gilded_blackstone
fill 95 93 538 95 93 539 minecraft:blackstone
setblock 95 93 540 minecraft:smooth_basalt
fill 95 93 541 95 96 541 minecraft:blackstone
setblock 95 93 545 minecraft:smooth_basalt
fill 95 93 546 95 96 546 minecraft:blackstone
setblock 95 93 549 minecraft:blackstone
setblock 95 93 550 minecraft:smooth_basalt
fill 95 93 551 98 93 551 minecraft:blackstone
fill 95 93 552 97 95 552 minecraft:gilded_blackstone
setblock 96 93 539 minecraft:smooth_basalt
fill 96 93 540 96 96 540 minecraft:blackstone
setblock 96 93 544 minecraft:smooth_basalt
fill 96 93 545 96 96 545 minecraft:blackstone
setblock 96 93 549 minecraft:smooth_basalt
setblock 97 93 543 minecraft:smooth_basalt
fill 97 93 544 97 96 544 minecraft:blackstone
fill 97 93 546 97 93 547 minecraft:blackstone
fill 98 93 550 99 93 550 minecraft:blackstone
fill 98 93 552 98 94 552 minecraft:blackstone
setblock 99 93 551 minecraft:smooth_basalt
fill 99 93 552 103 93 552 minecraft:gilded_blackstone
setblock 100 93 550 minecraft:smooth_basalt
fill 100 93 551 100 96 551 minecraft:blackstone
fill 101 93 550 103 94 550 minecraft:blackstone
setblock 103 93 551 minecraft:blackstone
setblock 104 93 510 minecraft:blackstone
setblock 104 93 551 minecraft:smooth_basalt
setblock 104 93 552 minecraft:blackstone
fill 105 93 510 110 95 510 minecraft:gilded_blackstone
fill 105 93 552 105 97 552 minecraft:gilded_blackstone
setblock 106 93 552 minecraft:blackstone
fill 107 93 552 109 95 552 minecraft:gilded_blackstone
setblock 111 93 510 minecraft:blackstone
fill 112 93 510 112 96 510 minecraft:gilded_blackstone
fill 112 93 552 113 95 552 minecraft:gilded_blackstone
fill 118 93 552 119 95 552 minecraft:gilded_blackstone
setblock 119 93 511 minecraft:smooth_basalt
fill 120 93 511 123 93 511 minecraft:blackstone
fill 120 93 551 120 93 552 minecraft:blackstone
fill 121 93 551 123 93 551 minecraft:blackstone
fill 121 93 552 122 95 552 minecraft:gilded_blackstone
setblock 122 93 512 minecraft:blackstone
setblock 123 93 512 minecraft:smooth_basalt
setblock 124 93 511 minecraft:smooth_basalt
fill 124 93 512 124 96 512 minecraft:blackstone
setblock 124 93 551 minecraft:smooth_basalt
fill 125 93 511 125 96 511 minecraft:blackstone
fill 125 93 551 127 94 551 minecraft:blackstone
setblock 126 93 552 minecraft:gilded_blackstone
fill 128 93 510 128 96 510 minecraft:gilded_blackstone
setblock 131 93 552 minecraft:gilded_blackstone
setblock 135 93 519 minecraft:blackstone
setblock 135 93 520 minecraft:smooth_basalt
fill 135 93 521 135 95 522 minecraft:blackstone
fill 135 93 541 135 96 541 minecraft:blackstone
setblock 135 93 545 minecraft:smooth_basalt
fill 135 93 546 135 96 546 minecraft:blackstone
setblock 135 93 550 minecraft:smooth_basalt
fill 135 93 551 135 96 551 minecraft:blackstone
fill 136 93 511 136 95 511 minecraft:gilded_blackstone
setblock 136 93 512 minecraft:blackstone
fill 136 93 513 136 93 517 minecraft:gilded_blackstone
fill 136 93 521 136 95 523 minecraft:gilded_blackstone
fill 136 93 528 136 96 528 minecraft:gilded_blackstone
fill 136 93 533 136 95 533 minecraft:gilded_blackstone
fill 136 93 537 136 95 537 minecraft:gilded_blackstone
setblock 136 93 538 minecraft:blackstone
fill 136 93 539 136 95 543 minecraft:gilded_blackstone
fill 136 93 544 136 93 545 minecraft:blackstone
fill 136 93 546 136 95 546 minecraft:gilded_blackstone
fill 94 94 510 98 95 510 minecraft:gilded_blackstone
fill 94 94 537 94 95 540 minecraft:gilded_blackstone
setblock 94 94 541 minecraft:blackstone
fill 94 94 542 94 95 545 minecraft:gilded_blackstone
setblock 94 94 546 minecraft:blackstone
fill 94 94 547 94 95 549 minecraft:gilded_blackstone
fill 94 94 552 94 95 552 minecraft:gilded_blackstone
fill 95 94 521 95 94 523 minecraft:blackstone
setblock 95 94 524 minecraft:smooth_basalt
fill 95 94 525 95 96 526 minecraft:blackstone
fill 95 94 537 95 94 538 minecraft:blackstone
setblock 95 94 539 minecraft:smooth_basalt
fill 95 94 540 95 97 540 minecraft:blackstone
setblock 95 94 544 minecraft:smooth_basalt
fill 95 94 545 95 97 545 minecraft:blackstone
setblock 95 94 549 minecraft:smooth_basalt
fill 95 94 550 97 94 551 minecraft:blackstone
fill 96 94 539 96 97 539 minecraft:blackstone
setblock 96 94 543 minecraft:smooth_basalt
fill 96 94 544 96 97 544 minecraft:blackstone
setblock 96 94 548 minecraft:smooth_basalt
fill 96 94 549 96 97 549 minecraft:blackstone
fill 97 94 540 97 95 540 minecraft:blackstone
setblock 97 94 542 minecraft:smooth_basalt
fill 97 94 543 98 96 543 minecraft:blackstone
setblock 97 94 546 minecraft:blackstone
setblock 97 94 547 minecraft:smooth_basalt
fill 97 94 548 97 97 548 minecraft:blackstone
fill 98 94 542 98 97 542 minecraft:blackstone
fill 98 94 544 98 94 545 minecraft:blackstone
setblock 98 94 546 minecraft:smooth_basalt
fill 98 94 549 98 94 550 minecraft:blackstone
setblock 98 94 551 minecraft:smooth_basalt
setblock 99 94 510 minecraft:blackstone
setblock 99 94 549 minecraft:blackstone
setblock 99 94 550 minecraft:smooth_basalt
fill 99 94 551 99 94 552 minecraft:blackstone
fill 100 94 510 104 95 510 minecraft:gilded_blackstone
setblock 100 94 549 minecraft:smooth_basalt
fill 100 94 550 100 97 550 minecraft:blackstone
fill 100 94 552 100 95 552 minecraft:gilded_blackstone
fill 101 94 549 102 96 549 minecraft:blackstone
setblock 101 94 552 minecraft:blackstone
fill 102 94 552 104 95 552 minecraft:gilded_blackstone
setblock 103 94 551 minecraft:smooth_basalt
fill 104 94 551 105 96 551 minecraft:blackstone
fill 106 94 552 106 95 552 minecraft:gilded_blackstone
fill 110 94 552 110 95 552 minecraft:gilded_blackstone
fill 111 94 510 111 95 510 minecraft:gilded_blackstone
fill 113 94 510 115 95 510 minecraft:gilded_blackstone
setblock 116 94 510 minecraft:blackstone
fill 117 94 510 117 95 510 minecraft:gilded_blackstone
fill 117 94 552 117 95 552 minecraft:gilded_blackstone
setblock 118 94 510 minecraft:blackstone
setblock 118 94 511 minecraft:smooth_basalt
fill 119 94 510 127 95 510 minecraft:gilded_blackstone
fill 119 94 511 122 94 511 minecraft:blackstone
fill 119 94 551 122 94 551 minecraft:blackstone
fill 120 94 512 121 94 512 minecraft:blackstone
fill 120 94 552 120 95 552 minecraft:gilded_blackstone
fill 121 94 550 123 94 550 minecraft:blackstone
setblock 122 94 512 minecraft:smooth_basalt
setblock 123 94 511 minecraft:smooth_basalt
fill 123 94 512 123 97 512 minecraft:blackstone
setblock 123 94 551 minecraft:smooth_basalt
fill 124 94 511 124 97 511 minecraft:blackstone
setblock 124 94 550 minecraft:smooth_basalt
fill 124 94 551 124 97 551 minecraft:blackstone
setblock 126 94 552 minecraft:blackstone
setblock 128 94 511 minecraft:smooth_basalt
setblock 128 94 551 minecraft:smooth_basalt
fill 129 94 510 129 95 510 minecraft:gilded_blackstone
fill 129 94 551 129 97 551 minecraft:blackstone
setblock 130 94 510 minecraft:blackstone
fill 131 94 510 132 95 510 minecraft:gilded_blackstone
setblock 131 94 552 minecraft:blackstone
setblock 132 94 551 minecraft:blackstone
setblock 133 94 510 minecraft:blackstone
setblock 133 94 551 minecraft:smooth_basalt
fill 134 94 510 136 95 510 minecraft:gilded_blackstone
setblock 134 94 544 minecraft:blackstone
setblock 134 94 545 minecraft:smooth_basalt
fill 134 94 546 134 94 549 minecraft:blackstone
fill 134 94 551 134 97 551 minecraft:blackstone
setblock 135 94 519 minecraft:smooth_basalt
fill 135 94 520 135 97 520 minecraft:blackstone
setblock 135 94 523 minecraft:blackstone
setblock 135 94 524 minecraft:smooth_basalt
fill 135 94 540 135 97 540 minecraft:blackstone
setblock 135 94 544 minecraft:smooth_basalt
fill 135 94 545 136 94 545 minecraft:blackstone
fill 135 94 547 135 94 548 minecraft:blackstone
setblock 135 94 549 minecraft:smooth_basalt
fill 135 94 550 135 97 550 minecraft:blackstone
fill 136 94 512 136 95 512 minecraft:gilded_blackstone
setblock 136 94 513 minecraft:blackstone
fill 136 94 514 136 95 517 minecraft:gilded_blackstone
fill 136 94 538 136 95 538 minecraft:gilded_blackstone
fill 136 94 544 136 95 544 minecraft:gilded_blackstone
setblock 136 94 547 minecraft:blackstone
fill 136 94 548 136 95 551 minecraft:gilded_blackstone
setblock 94 95 541 minecraft:gilded_blackstone
setblock 94 95 546 minecraft:gilded_blackstone
setblock 94 95 550 minecraft:gilded_blackstone
fill 95 95 520 95 95 522 minecraft:blackstone
setblock 95 95 523 minecraft:smooth_basalt
fill 95 95 524 96 97 524 minecraft:blackstone
setblock 95 95 527 minecraft:blackstone
setblock 95 95 528 minecraft:smooth_basalt
fill 95 95 529 95 97 530 minecraft:blackstone
fill 95 95 536 95 95 537 minecraft:blackstone
setblock 95 95 538 minecraft:smooth_basalt
fill 95 95 539 95 98 539 minecraft:blackstone
setblock 95 95 543 minecraft:smooth_basalt
fill 95 95 544 95 98 544 minecraft:blackstone
setblock 95 95 547 minecraft:blackstone
setblock 95 95 548 minecraft:smooth_basalt
fill 95 95 549 95 96 551 minecraft:blackstone
fill 96 95 523 96 98 523 minecraft:blackstone
fill 96 95 525 96 95 526 minecraft:blackstone
setblock 96 95 527 minecraft:smooth_basalt
fill 96 95 538 96 98 538 minecraft:blackstone
setblock 96 95 541 minecraft:blackstone
setblock 96 95 542 minecraft:smooth_basalt
fill 96 95 543 96 98 543 minecraft:blackstone
setblock 96 95 547 minecraft:smooth_basalt
fill 96 95 548 96 98 548 minecraft:blackstone
fill 96 95 550 96 95 551 minecraft:blackstone
setblock 97 95 541 minecraft:smooth_basalt
fill 97 95 542 97 98 542 minecraft:blackstone
setblock 97 95 546 minecraft:smooth_basalt
fill 97 95 547 98 97 547 minecraft:blackstone
fill 97 95 549 97 95 550 minecraft:blackstone
setblock 97 95 551 minecraft:smooth_basalt
setblock 98 95 544 minecraft:blackstone
setblock 98 95 545 minecraft:smooth_basalt
fill 98 95 546 98 98 546 minecraft:blackstone
fill 98 95 548 98 95 549 minecraft:blackstone
setblock 98 95 550 minecraft:smooth_basalt
fill 98 95 551 99 97 551 minecraft:blackstone
fill 98 95 552 99 95 552 minecraft:gilded_blackstone
setblock 99 95 510 minecraft:gilded_blackstone
setblock 99 95 548 minecraft:blackstone
setblock 99 95 549 minecraft:smooth_basalt
fill 99 95 550 99 98 550 minecraft:blackstone
setblock 100 95 548 minecraft:smooth_basalt
fill 100 95 549 100 98 549 minecraft:blackstone
fill 101 95 550 102 95 550 minecraft:blackstone
setblock 101 95 552 minecraft:gilded_blackstone
setblock 102 95 551 minecraft:smooth_basalt
setblock 103 95 550 minecraft:smooth_basalt
fill 103 95 551 103 98 551 minecraft:blackstone
fill 104 95 550 104 98 550 minecraft:blackstone
fill 116 95 510 116 96 510 minecraft:gilded_blackstone
setblock 117 95 511 minecraft:smooth_basalt
setblock 117 95 551 minecraft:smooth_basalt
setblock 118 95 510 minecraft:gilded_blackstone
fill 118 95 511 121 95 511 minecraft:blackstone
fill 118 95 551 121 95 551 minecraft:blackstone
fill 119 95 512 120 95 512 minecraft:blackstone
fill 119 95 550 122 95 550 minecraft:blackstone
setblock 121 95 512 minecraft:smooth_basalt
setblock 122 95 511 minecraft:smooth_basalt
fill 122 95 512 122 98 512 minecraft:blackstone
setblock 122 95 551 minecraft:smooth_basalt
fill 123 95 511 123 98 511 minecraft:blackstone
setblock 123 95 550 minecraft:smooth_basalt
fill 123 95 551 123 98 551 minecraft:blackstone
fill 124 95 550 126 96 550 minecraft:blackstone
setblock 125 95 512 minecraft:blackstone
fill 125 95 551 126 95 551 minecraft:blackstone
setblock 126 95 552 minecraft:gilded_blackstone
setblock 127 95 511 minecraft:smooth_basalt
setblock 127 95 551 minecraft:smooth_basalt
fill 128 95 511 129 97 511 minecraft:blackstone
fill 128 95 551 128 98 551 minecraft:blackstone
setblock 130 95 510 minecraft:gilded_blackstone
fill 130 95 551 131 95 551 minecraft:blackstone
setblock 131 95 552 minecraft:gilded_blackstone
setblock 132 95 551 minecraft:smooth_basalt
setblock 133 95 510 minecraft:gilded_blackstone
setblock 133 95 550 minecraft:smooth_basalt
fill 133 95 551 133 98 551 minecraft:blackstone
setblock 134 95 543 minecraft:blackstone
setblock 134 95 544 minecraft:smooth_basalt
fill 134 95 545 134 95 548 minecraft:blackstone
setblock 134 95 549 minecraft:smooth_basalt
fill 134 95 550 134 98 550 minecraft:blackstone
fill 135 95 511 135 96 511 minecraft:blackstone
setblock 135 95 518 minecraft:smooth_basalt
fill 135 95 519 135 98 519 minecraft:blackstone
setblock 135 95 523 minecraft:smooth_basalt
fill 135 95 524 135 95 527 minecraft:blackstone
setblock 135 95 543 minecraft:smooth_basalt
fill 135 95 544 135 97 545 minecraft:blackstone
setblock 135 95 547 minecraft:blackstone
setblock 135 95 548 minecraft:smooth_basalt
fill 135 95 549 135 98 549 minecraft:blackstone
setblock 136 95 513 minecraft:gilded_blackstone
fill 136 95 545 136 96 545 minecraft:gilded_blackstone
setblock 136 95 547 minecraft:gilded_blackstone
fill 94 96 510 94 96 533 minecraft:blackstone
setblock 94 96 534 minecraft:gilded_blackstone
fill 94 96 535 94 97 546 minecraft:blackstone
setblock 94 96 547 minecraft:gilded_blackstone
fill 94 96 548 94 199 552 minecraft:blackstone
fill 95 96 510 97 96 510 minecraft:blackstone
fill 95 96 520 95 96 521 minecraft:blackstone
setblock 95 96 522 minecraft:smooth_basalt
fill 95 96 523 95 99 523 minecraft:blackstone
setblock 95 96 527 minecraft:smooth_basalt
fill 95 96 528 97 97 528 minecraft:blackstone
setblock 95 96 531 minecraft:blackstone
setblock 95 96 532 minecraft:smooth_basalt
fill 95 96 533 95 96 536 minecraft:blackstone
setblock 95 96 537 minecraft:smooth_basalt
fill 95 96 538 95 99 538 minecraft:blackstone
setblock 95 96 542 minecraft:smooth_basalt
fill 95 96 543 95 99 543 minecraft:blackstone
setblock 95 96 547 minecraft:smooth_basalt
fill 95 96 548 95 99 548 minecraft:blackstone
fill 95 96 552 96 201 552 minecraft:blackstone
fill 96 96 522 96 99 522 minecraft:blackstone
setblock 96 96 525 minecraft:blackstone
setblock 96 96 526 minecraft:smooth_basalt
fill 96 96 527 97 98 527 minecraft:blackstone
fill 96 96 529 96 96 530 minecraft:blackstone
setblock 96 96 531 minecraft:smooth_basalt
fill 96 96 532 96 99 532 minecraft:blackstone
setblock 96 96 536 minecraft:smooth_basalt
fill 96 96 537 96 99 537 minecraft:blackstone
setblock 96 96 541 minecraft:smooth_basalt
fill 96 96 542 96 99 542 minecraft:blackstone
setblock 96 96 546 minecraft:smooth_basalt
fill 96 96 547 96 99 547 minecraft:blackstone
setblock 96 96 550 minecraft:blackstone
setblock 96 96 551 minecraft:smooth_basalt
fill 97 96 511 100 96 511 minecraft:blackstone
setblock 97 96 513 minecraft:light[level=12]
setblock 97 96 521 minecraft:light[level=12]
setblock 97 96 524 minecraft:blackstone
setblock 97 96 525 minecraft:smooth_basalt
fill 97 96 526 97 99 526 minecraft:blackstone
setblock 97 96 529 minecraft:light[level=12]
setblock 97 96 537 minecraft:light[level=12]
setblock 97 96 539 minecraft:blackstone
setblock 97 96 540 minecraft:smooth_basalt
fill 97 96 541 98 97 541 minecraft:blackstone
setblock 97 96 545 minecraft:smooth_basalt
fill 97 96 546 97 99 546 minecraft:blackstone
setblock 97 96 549 minecraft:blackstone
setblock 97 96 550 minecraft:smooth_basalt
fill 97 96 551 97 99 551 minecraft:blackstone
setblock 97 96 552 minecraft:gilded_blackstone
setblock 98 96 510 minecraft:gilded_blackstone
setblock 98 96 544 minecraft:smooth_basalt
fill 98 96 545 98 99 545 minecraft:blackstone
setblock 98 96 548 minecraft:blackstone
setblock 98 96 549 minecraft:smooth_basalt
fill 98 96 550 98 99 550 minecraft:blackstone
fill 98 96 552 104 96 552 minecraft:blackstone
fill 99 96 510 99 201 510 minecraft:blackstone
setblock 99 96 548 minecraft:smooth_basalt
fill 99 96 549 99 99 549 minecraft:blackstone
fill 100 96 510 100 97 510 minecraft:gilded_blackstone
fill 100 96 548 101 98 548 minecraft:blackstone
fill 101 96 510 103 198 510 minecraft:blackstone
setblock 101 96 511 minecraft:smooth_basalt
setblock 101 96 550 minecraft:blackstone
setblock 101 96 551 minecraft:smooth_basalt
setblock 102 96 550 minecraft:smooth_basalt
fill 102 96 551 102 99 551 minecraft:blackstone
setblock 103 96 549 minecraft:smooth_basalt
fill 103 96 550 103 99 550 minecraft:blackstone
fill 104 96 510 105 96 510 minecraft:gilded_blackstone
setblock 105 96 513 minecraft:light[level=12]
setblock 105 96 521 minecraft:light[level=12]
setblock 105 96 529 minecraft:light[level=12]
setblock 105 96 537 minecraft:light[level=12]
setblock 105 96 545 minecraft:light[level=12]
fill 106 96 510 107 201 510 minecraft:blackstone
fill 106 96 552 113 97 552 minecraft:blackstone
setblock 108 96 510 minecraft:gilded_blackstone
fill 109 96 510 111 198 510 minecraft:blackstone
fill 113 96 510 115 96 510 minecraft:blackstone
setblock 113 96 513 minecraft:light[level=12]
setblock 113 96 521 minecraft:light[level=12]
setblock 113 96 529 minecraft:light[level=12]
setblock 113 96 537 minecraft:light[level=12]
setblock 113 96 545 minecraft:light[level=12]
setblock 114 96 552 minecraft:gilded_blackstone
setblock 115 96 511 minecraft:blackstone
fill 115 96 551 115 96 552 minecraft:blackstone
setblock 116 96 511 minecraft:smooth_basalt
setblock 116 96 551 minecraft:smooth_basalt
fill 116 96 552 129 96 552 minecraft:blackstone
fill 117 96 510 119 96 512 minecraft:blackstone
setblock 117 96 550 minecraft:smooth_basalt
fill 117 96 551 120 96 551 minecraft:blackstone
fill 118 96 550 121 96 550 minecraft:blackstone
fill 120 96 510 120 96 511 minecraft:blackstone
setblock 120 96 512 minecraft:smooth_basalt
fill 120 96 549 122 96 549 minecraft:blackstone
fill 121 96 510 127 96 510 minecraft:blackstone
setblock 121 96 511 minecraft:smooth_basalt
fill 121 96 512 121 99 512 minecraft:blackstone
setblock 121 96 513 minecraft:light[level=12]
setblock 121 96 521 minecraft:light[level=12]
setblock 121 96 529 minecraft:light[level=12]
setblock 121 96 537 minecraft:light[level=12]
setblock 121 96 545 minecraft:light[level=12]
setblock 121 96 551 minecraft:smooth_basalt
fill 122 96 511 122 99 511 minecraft:blackstone
setblock 122 96 550 minecraft:smooth_basalt
fill 122 96 551 122 99 551 minecraft:blackstone
setblock 123 96 549 minecraft:smooth_basalt
fill 123 96 550 123 99 550 minecraft:blackstone
setblock 125 96 512 minecraft:smooth_basalt
setblock 125 96 551 minecraft:blackstone
setblock 126 96 511 minecraft:smooth_basalt
setblock 126 96 551 minecraft:smooth_basalt
fill 127 96 511 127 99 511 minecraft:blackstone
setblock 127 96 550 minecraft:smooth_basalt
fill 127 96 551 127 99 551 minecraft:blackstone
fill 128 96 550 131 96 550 minecraft:blackstone
fill 129 96 510 136 97 510 minecraft:blackstone
setblock 129 96 513 minecraft:light[level=12]
setblock 129 96 521 minecraft:light[level=12]
setblock 129 96 529 minecraft:light[level=12]
setblock 129 96 537 minecraft:light[level=12]
setblock 129 96 545 minecraft:light[level=12]
setblock 130 96 511 minecraft:blackstone
setblock 130 96 551 minecraft:blackstone
setblock 130 96 552 minecraft:gilded_blackstone
setblock 131 96 511 minecraft:smooth_basalt
setblock 131 96 551 minecraft:smooth_basalt
fill 131 96 552 136 96 552 minecraft:blackstone
fill 132 96 511 134 97 511 minecraft:blackstone
setblock 132 96 550 minecraft:smooth_basalt
fill 132 96 551 132 99 551 minecraft:blackstone
fill 133 96 547 133 96 548 minecraft:blackstone
fill 133 96 550 133 99 550 minecraft:blackstone
setblock 134 96 542 minecraft:blackstone
setblock 134 96 543 minecraft:smooth_basalt
fill 134 96 544 134 96 547 minecraft:blackstone
setblock 134 96 548 minecraft:smooth_basalt
fill 134 96 549 134 99 549 minecraft:blackstone
setblock 135 96 512 minecraft:smooth_basalt
fill 135 96 513 136 97 513 minecraft:blackstone
fill 135 96 518 136 98 518 minecraft:blackstone
fill 135 96 521 136 96 521 minecraft:blackstone
setblock 135 96 522 minecraft:smooth_basalt
fill 135 96 523 135 96 526 minecraft:blackstone
setblock 135 96 527 minecraft:smooth_basalt
fill 135 96 528 135 98 529 minecraft:blackstone
fill 135 96 539 136 98 539 minecraft:blackstone
setblock 135 96 542 minecraft:smooth_basalt
fill 135 96 543 136 99 543 minecraft:blackstone
setblock 135 96 547 minecraft:smooth_basalt
fill 135 96 548 135 99 548 minecraft:blackstone
fill 136 96 511 136 201 512 minecraft:blackstone
fill 136 96 514 136 97 517 minecraft:blackstone
setblock 136 96 519 minecraft:blackstone
setblock 136 96 520 minecraft:gilded_blackstone
fill 136 96 522 136 201 522 minecraft:blackstone
setblock 136 96 523 minecraft:gilded_blackstone
fill 136 96 524 136 199 525 minecraft:blackstone
setblock 136 96 526 minecraft:gilded_blackstone
fill 136 96 527 136 199 527 minecraft:blackstone
fill 136 96 529 136 96 531 minecraft:blackstone
setblock 136 96 532 minecraft:gilded_blackstone
fill 136 96 533 136 97 538 minecraft:blackstone
setblock 136 96 540 minecraft:gilded_blackstone
fill 136 96 541 136 201 542 minecraft:blackstone
fill 136 96 544 136 97 544 minecraft:blackstone
fill 136 96 546 136 97 547 minecraft:blackstone
fill 136 96 548 136 97 548 minecraft:gilded_blackstone
fill 136 96 549 136 201 551 minecraft:blackstone
fill 94 97 510 94 97 515 minecraft:blackstone
setblock 94 97 516 minecraft:gilded_blackstone
fill 94 97 517 94 197 528 minecraft:blackstone
setblock 94 97 529 minecraft:gilded_blackstone
fill 94 97 530 94 97 534 minecraft:blackstone
fill 94 97 547 95 100 547 minecraft:blackstone
setblock 95 97 510 minecraft:blackstone
setblock 95 97 511 minecraft:smooth_basalt
setblock 95 97 520 minecraft:blackstone
setblock 95 97 521 minecraft:smooth_basalt
fill 95 97 522 95 100 522 minecraft:blackstone
setblock 95 97 525 minecraft:blackstone
setblock 95 97 526 minecraft:smooth_basalt
fill 95 97 527 95 100 527 minecraft:blackstone
setblock 95 97 531 minecraft:smooth_basalt
fill 95 97 532 95 97 535 minecraft:blackstone
setblock 95 97 536 minecraft:smooth_basalt
fill 95 97 537 95 100 537 minecraft:blackstone
setblock 95 97 541 minecraft:smooth_basalt
fill 95 97 542 95 100 542 minecraft:blackstone
setblock 95 97 546 minecraft:smooth_basalt
fill 95 97 549 95 97 550 minecraft:blackstone
setblock 95 97 551 minecraft:smooth_basalt
setblock 96 97 510 minecraft:gilded_blackstone
fill 96 97 511 99 97 511 minecraft:blackstone
fill 96 97 521 96 98 521 minecraft:blackstone
setblock 96 97 525 minecraft:smooth_basalt
fill 96 97 526 96 100 526 minecraft:blackstone
setblock 96 97 529 minecraft:blackstone
setblock 96 97 530 minecraft:smooth_basalt
fill 96 97 531 97 99 531 minecraft:blackstone
fill 96 97 533 96 97 534 minecraft:blackstone
setblock 96 97 535 minecraft:smooth_basalt
fill 96 97 536 96 100 536 minecraft:blackstone
setblock 96 97 540 minecraft:smooth_basalt
fill 96 97 541 96 100 541 minecraft:blackstone
setblock 96 97 545 minecraft:smooth_basalt
fill 96 97 546 96 100 546 minecraft:blackstone
setblock 96 97 550 minecraft:smooth_basalt
fill 96 97 551 96 100 551 minecraft:blackstone
fill 97 97 510 98 197 510 minecraft:blackstone
setblock 97 97 523 minecraft:blackstone
setblock 97 97 524 minecraft:smooth_basalt
fill 97 97 525 97 100 525 minecraft:blackstone
setblock 97 97 529 minecraft:smooth_basalt
fill 97 97 530 97 100 530 minecraft:blackstone
fill 97 97 532 97 98 532 minecraft:blackstone
setblock 97 97 538 minecraft:blackstone
setblock 97 97 539 minecraft:smooth_basalt
fill 97 97 540 97 100 540 minecraft:blackstone
setblock 97 97 543 minecraft:blackstone
setblock 97 97 544 minecraft:smooth_basalt
fill 97 97 545 97 100 545 minecraft:blackstone
setblock 97 97 549 minecraft:smooth_basalt
fill 97 97 550 97 100 550 minecraft:blackstone
fill 97 97 552 99 199 552 minecraft:blackstone
setblock 98 97 527 minecraft:blackstone
setblock 98 97 543 minecraft:smooth_basalt
fill 98 97 544 98 99 544 minecraft:blackstone
setblock 98 97 548 minecraft:smooth_basalt
fill 98 97 549 98 100 549 minecraft:blackstone
fill 99 97 548 99 100 548 minecraft:blackstone
setblock 100 97 511 minecraft:smooth_basalt
setblock 100 97 551 minecraft:smooth_basalt
setblock 100 97 552 minecraft:gilded_blackstone
fill 101 97 511 102 99 511 minecraft:blackstone
setblock 101 97 549 minecraft:blackstone
setblock 101 97 550 minecraft:smooth_basalt
fill 101 97 551 101 100 552 minecraft:blackstone
setblock 102 97 549 minecraft:smooth_basalt
fill 102 97 550 102 100 550 minecraft:blackstone
fill 102 97 552 104 197 552 minecraft:blackstone
fill 103 97 549 103 98 549 minecraft:blackstone
fill 104 97 510 105 201 510 minecraft:blackstone
setblock 104 97 551 minecraft:blackstone
setblock 105 97 551 minecraft:smooth_basalt
fill 106 97 551 106 99 551 minecraft:blackstone
fill 108 97 510 108 201 510 minecraft:blackstone
fill 112 97 510 112 201 510 minecraft:blackstone
setblock 113 97 510 minecraft:gilded_blackstone
fill 114 97 510 114 97 511 minecraft:blackstone
fill 114 97 551 114 97 552 minecraft:blackstone
fill 115 97 510 123 197 510 minecraft:blackstone
setblock 115 97 511 minecraft:smooth_basalt
setblock 115 97 551 minecraft:smooth_basalt
fill 115 97 552 123 97 552 minecraft:blackstone
fill 116 97 511 118 97 512 minecraft:blackstone
setblock 116 97 550 minecraft:smooth_basalt
fill 116 97 551 119 97 551 minecraft:blackstone
fill 117 97 550 120 97 550 minecraft:blackstone
fill 118 97 549 121 97 549 minecraft:blackstone
setblock 119 97 511 minecraft:blackstone
setblock 119 97 512 minecraft:smooth_basalt
fill 119 97 513 121 98 513 minecraft:blackstone
setblock 120 97 511 minecraft:smooth_basalt
fill 120 97 512 120 100 512 minecraft:blackstone
setblock 120 97 551 minecraft:smooth_basalt
fill 121 97 511 121 100 511 minecraft:blackstone
setblock 121 97 550 minecraft:smooth_basalt
fill 121 97 551 121 100 551 minecraft:blackstone
setblock 122 97 549 minecraft:smooth_basalt
fill 122 97 550 122 100 550 minecraft:blackstone
fill 123 97 549 124 99 549 minecraft:blackstone
setblock 124 97 510 minecraft:gilded_blackstone
setblock 124 97 512 minecraft:smooth_basalt
fill 124 97 550 125 97 550 minecraft:blackstone
setblock 124 97 552 minecraft:gilded_blackstone
fill 125 97 510 128 197 510 minecraft:blackstone
setblock 125 97 511 minecraft:smooth_basalt
fill 125 97 512 125 100 512 minecraft:blackstone
setblock 125 97 551 minecraft:smooth_basalt
fill 125 97 552 135 197 552 minecraft:blackstone
fill 126 97 511 126 100 511 minecraft:blackstone
setblock 126 97 550 minecraft:smooth_basalt
fill 126 97 551 126 100 551 minecraft:blackstone
fill 127 97 550 130 97 550 minecraft:blackstone
setblock 130 97 511 minecraft:smooth_basalt
setblock 130 97 551 minecraft:smooth_basalt
fill 131 97 511 131 100 511 minecraft:blackstone
setblock 131 97 550 minecraft:smooth_basalt
fill 131 97 551 131 100 551 minecraft:blackstone
setblock 132 97 549 minecraft:smooth_basalt
fill 132 97 550 132 100 550 minecraft:blackstone
fill 133 97 545 133 97 547 minecraft:blackstone
setblock 133 97 548 minecraft:smooth_basalt
fill 133 97 549 133 100 549 minecraft:blackstone
setblock 134 97 542 minecraft:smooth_basalt
fill 134 97 543 134 97 546 minecraft:blackstone
setblock 134 97 547 minecraft:smooth_basalt
fill 134 97 548 134 100 548 minecraft:blackstone
setblock 135 97 511 minecraft:smooth_basalt
fill 135 97 512 135 100 512 minecraft:blackstone
fill 135 97 514 135 97 515 minecraft:blackstone
setblock 135 97 517 minecraft:blackstone
setblock 135 97 521 minecraft:smooth_basalt
fill 135 97 522 135 97 525 minecraft:blackstone
setblock 135 97 526 minecraft:smooth_basalt
fill 135 97 527 135 100 527 minecraft:blackstone
setblock 135 97 530 minecraft:blackstone
setblock 135 97 531 minecraft:smooth_basalt
fill 135 97 538 135 99 538 minecraft:blackstone
setblock 135 97 541 minecraft:smooth_basalt
fill 135 97 542 135 100 542 minecraft:blackstone
setblock 135 97 546 minecraft:smooth_basalt
fill 135 97 547 135 100 547 minecraft:blackstone
setblock 135 97 551 minecraft:smooth_basalt
setblock 136 97 519 minecraft:gilded_blackstone
fill 136 97 520 136 199 521 minecraft:blackstone
fill 136 97 523 136 201 523 minecraft:blackstone
fill 136 97 526 136 201 526 minecraft:blackstone
fill 136 97 528 136 201 529 minecraft:blackstone
setblock 136 97 530 minecraft:gilded_blackstone
fill 136 97 531 136 201 532 minecraft:blackstone
fill 136 97 540 136 201 540 minecraft:blackstone
fill 136 97 545 136 199 545 minecraft:blackstone
setblock 136 97 552 minecraft:gilded_blackstone
fill 94 98 510 94 197 513 minecraft:blackstone
setblock 94 98 514 minecraft:gilded_blackstone
fill 94 98 515 94 197 516 minecraft:blackstone
fill 94 98 529 94 201 530 minecraft:blackstone
setblock 94 98 531 minecraft:gilded_blackstone
fill 94 98 532 94 197 539 minecraft:blackstone
setblock 94 98 540 minecraft:gilded_blackstone
fill 94 98 541 94 199 542 minecraft:blackstone
setblock 94 98 543 minecraft:gilded_blackstone
fill 94 98 544 94 198 546 minecraft:blackstone
setblock 95 98 510 minecraft:gilded_blackstone
fill 95 98 511 95 100 512 minecraft:blackstone
setblock 95 98 520 minecraft:smooth_basalt
fill 95 98 521 95 101 521 minecraft:blackstone
setblock 95 98 524 minecraft:blackstone
setblock 95 98 525 minecraft:smooth_basalt
fill 95 98 526 95 101 526 minecraft:blackstone
fill 95 98 528 95 98 529 minecraft:blackstone
setblock 95 98 530 minecraft:smooth_basalt
fill 95 98 531 95 98 534 minecraft:blackstone
setblock 95 98 535 minecraft:smooth_basalt
fill 95 98 536 95 101 536 minecraft:blackstone
setblock 95 98 540 minecraft:smooth_basalt
fill 95 98 541 95 101 541 minecraft:blackstone
setblock 95 98 545 minecraft:smooth_basalt
fill 95 98 546 95 101 546 minecraft:blackstone
setblock 95 98 549 minecraft:blackstone
setblock 95 98 550 minecraft:smooth_basalt
fill 95 98 551 95 101 551 minecraft:blackstone
fill 96 98 510 96 100 511 minecraft:blackstone
setblock 96 98 524 minecraft:smooth_basalt
fill 96 98 525 96 101 525 minecraft:blackstone
setblock 96 98 528 minecraft:blackstone
setblock 96 98 529 minecraft:smooth_basalt
fill 96 98 530 96 101 530 minecraft:blackstone
setblock 96 98 533 minecraft:blackstone
setblock 96 98 534 minecraft:smooth_basalt
fill 96 98 535 97 100 535 minecraft:blackstone
setblock 96 98 539 minecraft:smooth_basalt
fill 96 98 540 96 101 540 minecraft:blackstone
setblock 96 98 544 minecraft:smooth_basalt
fill 96 98 545 96 101 545 minecraft:blackstone
setblock 96 98 549 minecraft:smooth_basalt
fill 96 98 550 96 101 550 minecraft:blackstone
fill 97 98 511 98 98 511 minecraft:blackstone
setblock 97 98 523 minecraft:smooth_basalt
fill 97 98 524 97 101 524 minecraft:blackstone
setblock 97 98 528 minecraft:smooth_basalt
fill 97 98 529 98 100 529 minecraft:blackstone
setblock 97 98 533 minecraft:smooth_basalt
fill 97 98 534 97 101 534 minecraft:blackstone
setblock 97 98 537 minecraft:blackstone
setblock 97 98 538 minecraft:smooth_basalt
fill 97 98 539 97 100 539 minecraft:blackstone
fill 97 98 541 97 99 541 minecraft:blackstone
setblock 97 98 543 minecraft:smooth_basalt
fill 97 98 544 97 101 544 minecraft:blackstone
setblock 97 98 547 minecraft:blackstone
setblock 97 98 548 minecraft:smooth_basalt
fill 97 98 549 97 101 549 minecraft:blackstone
fill 98 98 525 98 98 526 minecraft:blackstone
setblock 98 98 527 minecraft:smooth_basalt
fill 98 98 528 98 101 528 minecraft:blackstone
fill 98 98 530 98 99 530 minecraft:blackstone
setblock 98 98 542 minecraft:smooth_basalt
fill 98 98 543 98 99 543 minecraft:blackstone
setblock 98 98 547 minecraft:smooth_basalt
fill 98 98 548 98 100 548 minecraft:blackstone
setblock 98 98 551 minecraft:blackstone
setblock 99 98 511 minecraft:smooth_basalt
setblock 99 98 551 minecraft:smooth_basalt
fill 100 98 510 100 101 511 minecraft:blackstone
setblock 100 98 550 minecraft:smooth_basalt
fill 100 98 551 100 101 552 minecraft:blackstone
setblock 101 98 549 minecraft:smooth_basalt
fill 101 98 550 101 101 550 minecraft:blackstone
fill 102 98 549 102 99 549 minecraft:blackstone
setblock 104 98 551 minecraft:smooth_basalt
fill 105 98 551 105 100 552 minecraft:blackstone
fill 106 98 552 109 197 552 minecraft:blackstone
setblock 110 98 552 minecraft:gilded_blackstone
fill 111 98 552 116 197 552 minecraft:blackstone
fill 112 98 551 113 98 551 minecraft:blackstone
fill 113 98 510 113 98 511 minecraft:blackstone
fill 114 98 510 114 201 510 minecraft:blackstone
setblock 114 98 511 minecraft:smooth_basalt
setblock 114 98 551 minecraft:smooth_basalt
fill 115 98 511 117 98 512 minecraft:blackstone
setblock 115 98 550 minecraft:smooth_basalt
fill 115 98 551 118 98 551 minecraft:blackstone
fill 116 98 550 119 98 550 minecraft:blackstone
fill 117 98 549 120 98 549 minecraft:blackstone
setblock 117 98 552 minecraft:gilded_blackstone
setblock 118 98 511 minecraft:blackstone
setblock 118 98 512 minecraft:smooth_basalt
fill 118 98 513 118 101 513 minecraft:blackstone
fill 118 98 552 124 197 552 minecraft:blackstone
setblock 119 98 511 minecraft:smooth_basalt
fill 119 98 512 119 101 512 minecraft:blackstone
setblock 119 98 551 minecraft:smooth_basalt
fill 120 98 511 120 101 511 minecraft:blackstone
setblock 120 98 550 minecraft:smooth_basalt
fill 120 98 551 120 101 551 minecraft:blackstone
setblock 121 98 549 minecraft:smooth_basalt
fill 121 98 550 121 101 550 minecraft:blackstone
setblock 122 98 513 minecraft:smooth_basalt
fill 122 98 549 122 100 549 minecraft:blackstone
setblock 123 98 512 minecraft:smooth_basalt
fill 124 98 510 124 201 510 minecraft:blackstone
setblock 124 98 511 minecraft:smooth_basalt
fill 124 98 512 124 101 512 minecraft:blackstone
setblock 124 98 550 minecraft:blackstone
setblock 124 98 551 minecraft:smooth_basalt
fill 125 98 511 125 101 511 minecraft:blackstone
setblock 125 98 549 minecraft:blackstone
setblock 125 98 550 minecraft:smooth_basalt
fill 125 98 551 125 101 551 minecraft:blackstone
fill 126 98 550 129 98 550 minecraft:blackstone
setblock 128 98 511 minecraft:blackstone
fill 129 98 510 131 197 510 minecraft:blackstone
setblock 129 98 511 minecraft:smooth_basalt
setblock 129 98 551 minecraft:smooth_basalt
fill 130 98 511 130 101 511 minecraft:blackstone
setblock 130 98 550 minecraft:smooth_basalt
fill 130 98 551 130 101 551 minecraft:blackstone
setblock 131 98 549 minecraft:smooth_basalt
fill 131 98 550 131 101 550 minecraft:blackstone
setblock 132 98 510 minecraft:gilded_blackstone
fill 132 98 511 133 98 511 minecraft:blackstone
fill 132 98 549 132 101 549 minecraft:blackstone
fill 133 98 510 135 201 510 minecraft:blackstone
fill 133 98 545 133 98 546 minecraft:blackstone
setblock 133 98 547 minecraft:smooth_basalt
fill 133 98 548 133 101 548 minecraft:blackstone
setblock 134 98 511 minecraft:smooth_basalt
setblock 134 98 525 minecraft:blackstone
setblock 134 98 526 minecraft:smooth_basalt
fill 134 98 542 134 98 545 minecraft:blackstone
setblock 134 98 546 minecraft:smooth_basalt
fill 134 98 547 134 101 547 minecraft:blackstone
setblock 134 98 551 minecraft:smooth_basalt
fill 135 98 511 135 101 511 minecraft:blackstone
fill 135 98 513 135 98 514 minecraft:blackstone
setblock 135 98 515 minecraft:smooth_basalt
fill 135 98 516 136 99 516 minecraft:blackstone
setblock 135 98 520 minecraft:smooth_basalt
fill 135 98 521 135 98 524 minecraft:blackstone
setblock 135 98 525 minecraft:smooth_basalt
fill 135 98 526 135 101 526 minecraft:blackstone
setblock 135 98 530 minecraft:smooth_basalt
fill 135 98 531 135 98 534 minecraft:blackstone
setblock 135 98 535 minecraft:smooth_basalt
fill 135 98 536 136 100 537 minecraft:blackstone
setblock 135 98 540 minecraft:smooth_basalt
fill 135 98 541 135 101 541 minecraft:blackstone
setblock 135 98 544 minecraft:blackstone
setblock 135 98 545 minecraft:smooth_basalt
fill 135 98 546 136 101 546 minecraft:blackstone
setblock 135 98 550 minecraft:smooth_basalt
fill 135 98 551 135 101 551 minecraft:blackstone
setblock 136 98 510 minecraft:gilded_blackstone
fill 136 98 513 136 98 514 minecraft:gilded_blackstone
fill 136 98 515 136 201 515 minecraft:blackstone
fill 136 98 517 136 197 517 minecraft:blackstone
fill 136 98 519 136 201 519 minecraft:blackstone
fill 136 98 530 136 198 530 minecraft:blackstone
setblock 136 98 533 minecraft:gilded_blackstone
fill 136 98 534 136 197 535 minecraft:blackstone
fill 136 98 538 136 197 538 minecraft:blackstone
setblock 136 98 544 minecraft:gilded_blackstone
setblock 136 98 547 minecraft:gilded_blackstone
fill 136 98 548 136 201 548 minecraft:blackstone
fill 136 98 552 136 201 552 minecraft:blackstone
fill 94 99 514 94 203 514 minecraft:blackstone
fill 94 99 531 95 101 531 minecraft:blackstone
fill 94 99 540 95 102 540 minecraft:blackstone
fill 94 99 543 94 198 543 minecraft:blackstone
fill 95 99 510 95 201 510 minecraft:blackstone
fill 95 99 520 95 100 520 minecraft:blackstone
setblock 95 99 524 minecraft:smooth_basalt
fill 95 99 525 95 102 525 minecraft:blackstone
setblock 95 99 528 minecraft:blackstone
setblock 95 99 529 minecraft:smooth_basalt
fill 95 99 530 95 102 530 minecraft:blackstone
fill 95 99 532 95 99 533 minecraft:blackstone
setblock 95 99 534 minecraft:smooth_basalt
fill 95 99 535 95 102 535 minecraft:blackstone
setblock 95 99 539 minecraft:smooth_basalt
setblock 95 99 544 minecraft:smooth_basalt
fill 95 99 545 95 102 545 minecraft:blackstone
setblock 95 99 549 minecraft:smooth_basalt
fill 95 99 550 95 102 550 minecraft:blackstone
setblock 96 99 523 minecraft:smooth_basalt
fill 96 99 524 96 102 524 minecraft:blackstone
setblock 96 99 527 minecraft:blackstone
setblock 96 99 528 minecraft:smooth_basalt
fill 96 99 529 96 102 529 minecraft:blackstone
setblock 96 99 533 minecraft:smooth_basalt
fill 96 99 534 96 102 534 minecraft:blackstone
setblock 96 99 538 minecraft:smooth_basalt
fill 96 99 539 96 102 539 minecraft:blackstone
setblock 96 99 543 minecraft:smooth_basalt
fill 96 99 544 96 102 544 minecraft:blackstone
setblock 96 99 548 minecraft:smooth_basalt
fill 96 99 549 96 102 549 minecraft:blackstone
setblock 97 99 511 minecraft:blackstone
setblock 97 99 523 minecraft:blackstone
setblock 97 99 527 minecraft:smooth_basalt
fill 97 99 528 97 102 528 minecraft:blackstone
setblock 97 99 532 minecraft:smooth_basalt
fill 97 99 533 97 102 533 minecraft:blackstone
setblock 97 99 536 minecraft:blackstone
setblock 97 99 537 minecraft:smooth_basalt
fill 97 99 538 97 100 538 minecraft:blackstone
setblock 97 99 542 minecraft:smooth_basalt
fill 97 99 543 97 101 543 minecraft:blackstone
setblock 97 99 547 minecraft:smooth_basalt
fill 97 99 548 97 102 548 minecraft:blackstone
setblock 98 99 511 minecraft:smooth_basalt
setblock 98 99 525 minecraft:blackstone
setblock 98 99 526 minecraft:smooth_basalt
fill 98 99 527 98 101 527 minecraft:blackstone
setblock 98 99 531 minecraft:smooth_basalt
fill 98 99 532 98 102 532 minecraft:blackstone
setblock 98 99 546 minecraft:smooth_basalt
fill 98 99 547 98 100 547 minecraft:blackstone
setblock 98 99 551 minecraft:smooth_basalt
fill 99 99 511 99 102 511 minecraft:blackstone
setblock 99 99 550 minecraft:smooth_basalt
fill 99 99 551 99 102 551 minecraft:blackstone
setblock 100 99 548 minecraft:blackstone
setblock 100 99 549 minecraft:smooth_basalt
fill 100 99 550 100 102 550 minecraft:blackstone
fill 101 99 549 101 100 549 minecraft:blackstone
setblock 103 99 551 minecraft:smooth_basalt
setblock 104 99 550 minecraft:smooth_basalt
fill 104 99 551 104 101 551 minecraft:blackstone
fill 110 99 552 110 201 552 minecraft:blackstone
fill 111 99 551 112 99 551 minecraft:blackstone
setblock 112 99 511 minecraft:blackstone
fill 113 99 510 113 201 510 minecraft:blackstone
setblock 113 99 511 minecraft:smooth_basalt
setblock 113 99 551 minecraft:smooth_basalt
fill 114 99 511 116 99 512 minecraft:blackstone
setblock 114 99 550 minecraft:smooth_basalt
fill 114 99 551 117 99 551 minecraft:blackstone
fill 115 99 550 118 99 550 minecraft:blackstone
fill 116 99 549 119 99 549 minecraft:blackstone
setblock 117 99 511 minecraft:blackstone
setblock 117 99 512 minecraft:smooth_basalt
fill 117 99 513 117 102 513 minecraft:blackstone
fill 117 99 552 117 201 552 minecraft:blackstone
setblock 118 99 511 minecraft:smooth_basalt
fill 118 99 512 118 102 512 minecraft:blackstone
setblock 118 99 551 minecraft:smooth_basalt
fill 119 99 511 119 102 511 minecraft:blackstone
fill 119 99 513 120 99 513 minecraft:blackstone
setblock 119 99 550 minecraft:smooth_basalt
fill 119 99 551 119 102 551 minecraft:blackstone
setblock 120 99 549 minecraft:smooth_basalt
fill 120 99 550 120 102 550 minecraft:blackstone
setblock 121 99 513 minecraft:smooth_basalt
fill 121 99 549 121 101 549 minecraft:blackstone
setblock 122 99 512 minecraft:smooth_basalt
setblock 123 99 511 minecraft:smooth_basalt
fill 123 99 512 123 102 512 minecraft:blackstone
setblock 123 99 551 minecraft:smooth_basalt
fill 124 99 511 124 102 511 minecraft:blackstone
setblock 124 99 550 minecraft:smooth_basalt
fill 124 99 551 124 102 551 minecraft:blackstone
fill 125 99 550 128 99 550 minecraft:blackstone
setblock 128 99 511 minecraft:smooth_basalt
setblock 128 99 551 minecraft:smooth_basalt
fill 129 99 511 129 102 511 minecraft:blackstone
setblock 129 99 550 minecraft:smooth_basalt
fill 129 99 551 129 102 551 minecraft:blackstone
setblock 130 99 549 minecraft:smooth_basalt
fill 130 99 550 130 102 550 minecraft:blackstone
fill 131 99 549 131 102 549 minecraft:blackstone
fill 132 99 510 132 99 511 minecraft:blackstone
setblock 133 99 511 minecraft:smooth_basalt
setblock 133 99 545 minecraft:blackstone
setblock 133 99 546 minecraft:smooth_basalt
fill 133 99 547 133 102 547 minecraft:blackstone
setblock 133 99 551 minecraft:smooth_basalt
fill 134 99 511 134 101 512 minecraft:blackstone
setblock 134 99 525 minecraft:smooth_basalt
fill 134 99 526 134 99 529 minecraft:blackstone
fill 134 99 542 134 99 544 minecraft:blackstone
setblock 134 99 545 minecraft:smooth_basalt
fill 134 99 546 134 102 546 minecraft:blackstone
setblock 134 99 550 minecraft:smooth_basalt
fill 134 99 551 134 102 551 minecraft:blackstone
fill 135 99 513 136 99 513 minecraft:blackstone
setblock 135 99 514 minecraft:smooth_basalt
fill 135 99 515 135 102 515 minecraft:blackstone
setblock 135 99 519 minecraft:smooth_basalt
fill 135 99 520 135 99 523 minecraft:blackstone
setblock 135 99 524 minecraft:smooth_basalt
fill 135 99 525 135 102 525 minecraft:blackstone
setblock 135 99 528 minecraft:blackstone
setblock 135 99 529 minecraft:smooth_basalt
fill 135 99 530 135 99 533 minecraft:blackstone
setblock 135 99 534 minecraft:smooth_basalt
fill 135 99 535 135 102 535 minecraft:blackstone
setblock 135 99 539 minecraft:smooth_basalt
fill 135 99 540 135 102 540 minecraft:blackstone
setblock 135 99 544 minecraft:smooth_basalt
fill 135 99 545 135 102 545 minecraft:blackstone
setblock 135 99 549 minecraft:smooth_basalt
fill 135 99 550 135 102 550 minecraft:blackstone
fill 136 99 510 136 201 510 minecraft:blackstone
fill 136 99 514 136 201 514 minecraft:blackstone
fill 136 99 518 136 201 518 minecraft:blackstone
fill 136 99 533 136 201 533 minecraft:blackstone
fill 136 99 539 136 202 539 minecraft:blackstone
fill 136 99 544 136 201 544 minecraft:blackstone
fill 136 99 547 136 201 547 minecraft:blackstone
setblock 95 100 513 minecraft:smooth_basalt
setblock 95 100 523 minecraft:smooth_basalt
fill 95 100 524 95 103 524 minecraft:blackstone
setblock 95 100 528 minecraft:smooth_basalt
fill 95 100 529 95 103 529 minecraft:blackstone
setblock 95 100 532 minecraft:blackstone
setblock 95 100 533 minecraft:smooth_basalt
fill 95 100 534 95 103 534 minecraft:blackstone
setblock 95 100 538 minecraft:smooth_basalt
fill 95 100 539 95 103 539 minecraft:blackstone
setblock 95 100 543 minecraft:smooth_basalt
fill 95 100 544 95 103 544 minecraft:blackstone
setblock 95 100 548 minecraft:smooth_basalt
fill 95 100 549 95 103 549 minecraft:blackstone
setblock 96 100 522 minecraft:smooth_basalt
fill 96 100 523 96 102 523 minecraft:blackstone
setblock 96 100 527 minecraft:smooth_basalt
fill 96 100 528 96 103 528 minecraft:blackstone
setblock 96 100 531 minecraft:blackstone
setblock 96 100 532 minecraft:smooth_basalt
fill 96 100 533 96 103 533 minecraft:blackstone
setblock 96 100 537 minecraft:smooth_basalt
fill 96 100 538 96 103 538 minecraft:blackstone
setblock 96 100 542 minecraft:smooth_basalt
fill 96 100 543 96 103 543 minecraft:blackstone
setblock 96 100 547 minecraft:smooth_basalt
fill 96 100 548 96 103 548 minecraft:blackstone
setblock 97 100 511 minecraft:smooth_basalt
setblock 97 100 526 minecraft:smooth_basalt
fill 97 100 527 97 103 527 minecraft:blackstone
setblock 97 100 531 minecraft:smooth_basalt
fill 97 100 532 97 103 532 minecraft:blackstone
setblock 97 100 536 minecraft:smooth_basalt
fill 97 100 537 97 101 537 minecraft:blackstone
setblock 97 100 541 minecraft:smooth_basalt
fill 97 100 542 97 101 542 minecraft:blackstone
setblock 97 100 546 minecraft:smooth_basalt
fill 97 100 547 97 102 547 minecraft:blackstone
setblock 97 100 551 minecraft:smooth_basalt
fill 98 100 511 98 103 511 minecraft:blackstone
setblock 98 100 526 minecraft:blackstone
setblock 98 100 530 minecraft:smooth_basalt
fill 98 100 531 98 103 531 minecraft:blackstone
setblock 98 100 545 minecraft:smooth_basalt
setblock 98 100 546 minecraft:blackstone
setblock 98 100 550 minecraft:smooth_basalt
fill 98 100 551 98 103 551 minecraft:blackstone
setblock 99 100 549 minecraft:smooth_basalt
fill 99 100 550 99 103 550 minecraft:blackstone
fill 100 100 549 100 101 549 minecraft:blackstone
setblock 101 100 511 minecraft:blackstone
setblock 102 100 511 minecraft:smooth_basalt
setblock 102 100 551 minecraft:smooth_basalt
setblock 103 100 550 minecraft:smooth_basalt
fill 103 100 551 103 102 551 minecraft:blackstone
setblock 111 100 511 minecraft:blackstone
setblock 111 100 551 minecraft:blackstone
setblock 112 100 511 minecraft:smooth_basalt
setblock 112 100 551 minecraft:smooth_basalt
fill 113 100 511 116 100 511 minecraft:blackstone
setblock 113 100 550 minecraft:smooth_basalt
fill 113 100 551 116 100 551 minecraft:blackstone
fill 114 100 512 115 100 512 minecraft:blackstone
fill 114 100 550 117 100 550 minecraft:blackstone
setblock 116 100 512 minecraft:smooth_basalt
fill 116 100 513 116 103 513 minecraft:blackstone
fill 116 100 549 118 100 549 minecraft:blackstone
setblock 117 100 511 minecraft:smooth_basalt
fill 117 100 512 117 103 512 minecraft:blackstone
setblock 117 100 551 minecraft:smooth_basalt
fill 118 100 511 118 103 511 minecraft:blackstone
setblock 118 100 550 minecraft:smooth_basalt
fill 118 100 551 118 103 551 minecraft:blackstone
setblock 119 100 513 minecraft:blackstone
setblock 119 100 549 minecraft:smooth_basalt
fill 119 100 550 119 103 550 minecraft:blackstone
setblock 120 100 513 minecraft:smooth_basalt
fill 120 100 549 120 101 549 minecraft:blackstone
setblock 121 100 512 minecraft:smooth_basalt
setblock 121 100 513 minecraft:blackstone
setblock 122 100 511 minecraft:smooth_basalt
fill 122 100 512 122 103 512 minecraft:blackstone
setblock 122 100 551 minecraft:smooth_basalt
fill 123 100 511 123 103 511 minecraft:blackstone
setblock 123 100 549 minecraft:blackstone
setblock 123 100 550 minecraft:smooth_basalt
fill 123 100 551 123 103 551 minecraft:blackstone
fill 124 100 550 127 100 550 minecraft:blackstone
setblock 127 100 511 minecraft:smooth_basalt
setblock 127 100 551 minecraft:smooth_basalt
fill 128 100 511 128 103 511 minecraft:blackstone
setblock 128 100 550 minecraft:smooth_basalt
fill 128 100 551 128 103 551 minecraft:blackstone
fill 129 100 550 129 103 550 minecraft:blackstone
setblock 130 100 549 minecraft:blackstone
fill 132 100 510 132 197 510 minecraft:blackstone
setblock 132 100 511 minecraft:smooth_basalt
setblock 132 100 551 minecraft:smooth_basalt
fill 133 100 511 133 103 511 minecraft:blackstone
setblock 133 100 545 minecraft:smooth_basalt
fill 133 100 546 133 102 546 minecraft:blackstone
setblock 133 100 550 minecraft:smooth_basalt
fill 133 100 551 133 103 551 minecraft:blackstone
fill 134 100 526 134 100 528 minecraft:blackstone
setblock 134 100 529 minecraft:smooth_basalt
fill 134 100 530 135 102 530 minecraft:blackstone
fill 134 100 542 134 100 543 minecraft:blackstone
setblock 134 100 544 minecraft:smooth_basalt
fill 134 100 545 134 103 545 minecraft:blackstone
setblock 134 100 549 minecraft:smooth_basalt
fill 134 100 550 134 103 550 minecraft:blackstone
setblock 135 100 513 minecraft:smooth_basalt
fill 135 100 514 135 103 514 minecraft:blackstone
fill 135 100 520 135 100 522 minecraft:blackstone
setblock 135 100 523 minecraft:smooth_basalt
fill 135 100 524 135 103 524 minecraft:blackstone
setblock 135 100 528 minecraft:smooth_basalt
fill 135 100 529 135 103 529 minecraft:blackstone
fill 135 100 531 135 100 532 minecraft:blackstone
setblock 135 100 533 minecraft:smooth_basalt
fill 135 100 534 135 103 534 minecraft:blackstone
setblock 135 100 538 minecraft:smooth_basalt
fill 135 100 539 135 103 539 minecraft:blackstone
setblock 135 100 543 minecraft:smooth_basalt
fill 135 100 544 135 103 544 minecraft:blackstone
setblock 135 100 548 minecraft:smooth_basalt
fill 135 100 549 135 103 549 minecraft:blackstone
fill 136 100 513 136 198 513 minecraft:blackstone
fill 136 100 516 136 201 516 minecraft:blackstone
fill 136 100 543 136 199 543 minecraft:blackstone
fill 94 101 547 94 201 547 minecraft:blackstone
setblock 95 101 511 minecraft:blackstone
setblock 95 101 512 minecraft:smooth_basalt
fill 95 101 513 95 104 513 minecraft:blackstone
setblock 95 101 522 minecraft:smooth_basalt
fill 95 101 523 95 104 523 minecraft:blackstone
setblock 95 101 527 minecraft:smooth_basalt
fill 95 101 528 95 104 528 minecraft:blackstone
setblock 95 101 532 minecraft:smooth_basalt
fill 95 101 533 95 104 533 minecraft:blackstone
setblock 95 101 537 minecraft:smooth_basalt
fill 95 101 538 95 104 538 minecraft:blackstone
setblock 95 101 542 minecraft:smooth_basalt
fill 95 101 543 95 104 543 minecraft:blackstone
setblock 95 101 547 minecraft:smooth_basalt
fill 95 101 548 95 104 548 minecraft:blackstone
fill 96 101 510 96 201 510 minecraft:blackstone
setblock 96 101 511 minecraft:smooth_basalt
setblock 96 101 526 minecraft:smooth_basalt
fill 96 101 527 96 104 527 minecraft:blackstone
setblock 96 101 531 minecraft:smooth_basalt
fill 96 101 532 96 104 532 minecraft:blackstone
setblock 96 101 535 minecraft:blackstone
setblock 96 101 536 minecraft:smooth_basalt
fill 96 101 537 96 104 537 minecraft:blackstone
setblock 96 101 541 minecraft:smooth_basalt
fill 96 101 542 96 103 542 minecraft:blackstone
setblock 96 101 546 minecraft:smooth_basalt
fill 96 101 547 96 104 547 minecraft:blackstone
setblock 96 101 551 minecraft:smooth_basalt
fill 97 101 511 97 104 511 minecraft:blackstone
setblock 97 101 525 minecraft:smooth_basalt
fill 97 101 526 97 103 526 minecraft:blackstone
setblock 97 101 529 minecraft:blackstone
setblock 97 101 530 minecraft:smooth_basalt
fill 97 101 531 97 104 531 minecraft:blackstone
setblock 97 101 535 minecraft:smooth_basalt
fill 97 101 536 97 104 536 minecraft:blackstone
setblock 97 101 545 minecraft:smooth_basalt
fill 97 101 546 97 102 546 minecraft:blackstone
setblock 97 101 550 minecraft:smooth_basalt
fill 97 101 551 97 104 551 minecraft:blackstone
setblock 98 101 529 minecraft:smooth_basalt
fill 98 101 530 98 103 530 minecraft:blackstone
setblock 98 101 549 minecraft:smooth_basalt
fill 98 101 550 98 104 550 minecraft:blackstone
fill 99 101 549 99 102 549 minecraft:blackstone
setblock 101 101 511 minecraft:smooth_basalt
setblock 101 101 551 minecraft:smooth_basalt
fill 101 101 552 101 201 552 minecraft:blackstone
setblock 102 101 511 minecraft:blackstone
setblock 102 101 550 minecraft:smooth_basalt
fill 102 101 551 102 103 551 minecraft:blackstone
fill 105 101 552 105 201 552 minecraft:blackstone
setblock 110 101 511 minecraft:blackstone
setblock 111 101 511 minecraft:smooth_basalt
setblock 111 101 551 minecraft:smooth_basalt
fill 112 101 511 115 101 511 minecraft:blackstone
fill 112 101 551 115 101 551 minecraft:blackstone
fill 113 101 512 114 101 512 minecraft:blackstone
fill 113 101 550 116 101 550 minecraft:blackstone
setblock 115 101 512 minecraft:smooth_basalt
setblock 116 101 511 minecraft:smooth_basalt
fill 116 101 512 116 104 512 minecraft:blackstone
fill 116 101 549 117 101 549 minecraft:blackstone
setblock 116 101 551 minecraft:smooth_basalt
fill 117 101 511 117 104 511 minecraft:blackstone
setblock 117 101 550 minecraft:smooth_basalt
fill 117 101 551 117 104 551 minecraft:blackstone
setblock 118 101 549 minecraft:smooth_basalt
fill 118 101 550 118 104 550 minecraft:blackstone
setblock 119 101 513 minecraft:smooth_basalt
fill 119 101 549 119 102 549 minecraft:blackstone
setblock 120 101 512 minecraft:smooth_basalt
fill 120 101 513 120 102 513 minecraft:blackstone
setblock 121 101 511 minecraft:smooth_basalt
fill 121 101 512 121 104 512 minecraft:blackstone
setblock 121 101 551 minecraft:smooth_basalt
fill 122 101 511 122 104 511 minecraft:blackstone
setblock 122 101 550 minecraft:smooth_basalt
fill 122 101 551 122 104 551 minecraft:blackstone
fill 123 101 550 126 101 550 minecraft:blackstone
setblock 126 101 511 minecraft:smooth_basalt
setblock 126 101 551 minecraft:smooth_basalt
fill 127 101 511 127 104 511 minecraft:blackstone
setblock 127 101 550 minecraft:smooth_basalt
fill 127 101 551 127 104 551 minecraft:blackstone
fill 128 101 550 128 104 550 minecraft:blackstone
setblock 131 101 511 minecraft:smooth_basalt
setblock 131 101 551 minecraft:smooth_basalt
fill 132 101 511 132 104 511 minecraft:blackstone
setblock 132 101 550 minecraft:smooth_basalt
fill 132 101 551 132 104 551 minecraft:blackstone
fill 133 101 512 133 102 512 minecraft:blackstone
setblock 133 101 549 minecraft:smooth_basalt
fill 133 101 550 133 104 550 minecraft:blackstone
setblock 134 101 527 minecraft:blackstone
setblock 134 101 528 minecraft:smooth_basalt
fill 134 101 529 134 104 529 minecraft:blackstone
fill 134 101 531 134 101 532 minecraft:blackstone
setblock 134 101 542 minecraft:blackstone
setblock 134 101 543 minecraft:smooth_basalt
fill 134 101 544 134 104 544 minecraft:blackstone
setblock 134 101 548 minecraft:smooth_basalt
fill 134 101 549 134 104 549 minecraft:blackstone
setblock 135 101 512 minecraft:smooth_basalt
fill 135 101 513 135 104 513 minecraft:blackstone
setblock 135 101 522 minecraft:smooth_basalt
fill 135 101 523 135 102 523 minecraft:blackstone
setblock 135 101 527 minecraft:smooth_basalt
fill 135 101 528 135 104 528 minecraft:blackstone
setblock 135 101 531 minecraft:blackstone
setblock 135 101 532 minecraft:smooth_basalt
fill 135 101 533 135 104 533 minecraft:blackstone
fill 135 101 536 136 101 536 minecraft:blackstone
setblock 135 101 537 minecraft:smooth_basalt
fill 135 101 538 135 104 538 minecraft:blackstone
setblock 135 101 542 minecraft:smooth_basalt
fill 135 101 543 135 104 543 minecraft:blackstone
setblock 135 101 547 minecraft:smooth_basalt
fill 135 101 548 135 104 548 minecraft:blackstone
fill 136 101 537 136 197 537 minecraft:blackstone
fill 94 102 531 94 201 531 minecraft:blackstone
setblock 95 102 511 minecraft:smooth_basalt
fill 95 102 512 95 105 512 minecraft:blackstone
fill 95 102 522 95 103 522 minecraft:blackstone
setblock 95 102 526 minecraft:smooth_basalt
fill 95 102 527 95 105 527 minecraft:blackstone
setblock 95 102 531 minecraft:smooth_basalt
fill 95 102 532 95 105 532 minecraft:blackstone
setblock 95 102 536 minecraft:smooth_basalt
fill 95 102 537 95 105 537 minecraft:blackstone
schedule function dropper:buildpart/122_4 1t
