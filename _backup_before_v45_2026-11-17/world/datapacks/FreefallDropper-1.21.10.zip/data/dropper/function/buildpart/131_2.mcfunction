fill 517 207 531 517 218 531 minecraft:blue_concrete
fill 517 207 534 517 209 534 minecraft:orange_concrete
setblock 517 207 537 minecraft:magma_block
fill 517 207 550 517 209 550 minecraft:orange_concrete
fill 521 207 510 521 209 510 minecraft:orange_concrete
setblock 522 207 510 minecraft:shroomlight
setblock 523 207 528 minecraft:magma_block
fill 524 207 523 525 208 524 minecraft:magma_block
fill 531 207 552 531 209 552 minecraft:orange_concrete
fill 534 207 520 535 208 521 minecraft:red_terracotta
fill 537 207 510 537 209 510 minecraft:orange_concrete
fill 547 207 552 547 209 552 minecraft:orange_concrete
fill 553 207 510 553 209 510 minecraft:orange_concrete
fill 559 207 520 559 209 520 minecraft:orange_concrete
setblock 559 207 521 minecraft:white_concrete
fill 559 207 536 559 209 536 minecraft:orange_concrete
fill 517 208 522 517 221 522 minecraft:blue_concrete
fill 517 208 537 517 221 537 minecraft:blue_concrete
setblock 517 208 542 minecraft:white_concrete
fill 522 208 510 522 219 510 minecraft:blue_concrete
setblock 538 208 552 minecraft:white_concrete
setblock 541 208 552 minecraft:shroomlight
fill 550 208 523 550 208 524 minecraft:magma_block
setblock 551 208 523 minecraft:magma_block
fill 559 208 521 559 221 521 minecraft:blue_concrete
fill 517 209 542 517 222 542 minecraft:blue_concrete
fill 538 209 552 538 215 552 minecraft:blue_concrete
fill 541 209 552 541 221 552 minecraft:blue_concrete
fill 517 210 518 517 221 518 minecraft:blue_concrete
setblock 517 210 530 minecraft:shroomlight
fill 517 210 534 517 221 534 minecraft:blue_concrete
fill 517 210 550 517 216 550 minecraft:blue_concrete
fill 521 210 510 521 217 510 minecraft:blue_concrete
fill 531 210 552 531 219 552 minecraft:blue_concrete
fill 537 210 510 537 221 510 minecraft:blue_concrete
fill 547 210 552 547 219 552 minecraft:blue_concrete
setblock 553 210 510 minecraft:blue_concrete
fill 559 210 520 559 221 520 minecraft:blue_concrete
setblock 559 210 532 minecraft:magma_block
fill 559 210 536 559 221 536 minecraft:blue_concrete
setblock 517 211 525 minecraft:white_concrete
fill 517 211 526 517 214 526 minecraft:blue_concrete
fill 517 211 530 517 217 530 minecraft:blue_concrete
setblock 553 211 510 minecraft:white_concrete
fill 559 211 532 559 221 532 minecraft:blue_concrete
fill 517 212 525 517 221 525 minecraft:blue_concrete
setblock 548 212 552 minecraft:shroomlight
setblock 552 212 552 minecraft:shroomlight
fill 553 212 510 553 221 510 minecraft:blue_concrete
setblock 557 212 552 minecraft:shroomlight
setblock 558 212 552 minecraft:white_concrete
fill 559 212 552 559 221 552 minecraft:blue_concrete
setblock 520 213 513 minecraft:light[level=14]
setblock 520 213 521 minecraft:light[level=14]
setblock 520 213 529 minecraft:light[level=14]
setblock 520 213 537 minecraft:light[level=14]
setblock 520 213 545 minecraft:light[level=14]
setblock 528 213 513 minecraft:light[level=14]
setblock 528 213 521 minecraft:light[level=14]
setblock 528 213 529 minecraft:light[level=14]
setblock 528 213 537 minecraft:light[level=14]
setblock 528 213 545 minecraft:light[level=14]
setblock 536 213 513 minecraft:light[level=14]
setblock 536 213 521 minecraft:light[level=14]
setblock 536 213 529 minecraft:light[level=14]
setblock 536 213 537 minecraft:light[level=14]
setblock 536 213 545 minecraft:light[level=14]
setblock 536 213 552 minecraft:shroomlight
setblock 544 213 513 minecraft:light[level=14]
setblock 544 213 521 minecraft:light[level=14]
setblock 544 213 529 minecraft:light[level=14]
setblock 544 213 537 minecraft:light[level=14]
setblock 544 213 545 minecraft:light[level=14]
fill 548 213 552 548 221 552 minecraft:blue_concrete
setblock 552 213 513 minecraft:light[level=14]
setblock 552 213 521 minecraft:light[level=14]
setblock 552 213 529 minecraft:light[level=14]
setblock 552 213 537 minecraft:light[level=14]
setblock 552 213 545 minecraft:light[level=14]
setblock 552 213 552 minecraft:magma_block
fill 557 213 552 558 218 552 minecraft:blue_concrete
setblock 559 213 519 minecraft:magma_block
setblock 517 214 519 minecraft:magma_block
fill 536 214 552 536 221 552 minecraft:blue_concrete
fill 541 214 510 541 221 510 minecraft:blue_concrete
setblock 542 214 510 minecraft:magma_block
fill 543 214 510 544 221 510 minecraft:blue_concrete
setblock 552 214 552 minecraft:shroomlight
setblock 554 214 510 minecraft:white_concrete
fill 559 214 519 559 219 519 minecraft:blue_concrete
setblock 559 214 542 minecraft:white_concrete
fill 559 214 543 559 221 543 minecraft:blue_concrete
setblock 559 214 549 minecraft:magma_block
fill 517 215 519 517 221 519 minecraft:blue_concrete
setblock 517 215 526 minecraft:magma_block
fill 542 215 510 542 221 510 minecraft:blue_concrete
fill 552 215 552 552 217 552 minecraft:blue_concrete
fill 554 215 510 554 221 510 minecraft:blue_concrete
fill 559 215 542 559 222 542 minecraft:blue_concrete
fill 559 215 549 559 221 549 minecraft:blue_concrete
setblock 517 216 526 minecraft:blue_concrete
setblock 538 216 552 minecraft:magma_block
setblock 544 216 552 minecraft:white_concrete
setblock 554 216 552 minecraft:shroomlight
setblock 559 216 516 minecraft:shroomlight
setblock 559 216 523 minecraft:white_concrete
setblock 517 217 526 minecraft:shroomlight
setblock 517 217 538 minecraft:shroomlight
setblock 517 217 550 minecraft:magma_block
setblock 535 217 510 minecraft:white_concrete
fill 538 217 552 538 220 552 minecraft:blue_concrete
fill 544 217 552 544 218 552 minecraft:blue_concrete
fill 554 217 552 554 220 552 minecraft:blue_concrete
fill 559 217 516 559 219 516 minecraft:blue_concrete
fill 559 217 523 559 218 523 minecraft:blue_concrete
setblock 517 218 526 minecraft:black_concrete
setblock 517 218 530 minecraft:black_concrete
fill 517 218 538 517 221 538 minecraft:blue_concrete
fill 517 218 550 517 221 550 minecraft:blue_concrete
setblock 519 218 510 minecraft:black_concrete
setblock 521 218 510 minecraft:black_concrete
fill 527 218 510 527 220 510 minecraft:black_concrete
setblock 532 218 552 minecraft:black_concrete
fill 535 218 510 535 221 510 minecraft:blue_concrete
setblock 540 218 552 minecraft:black_concrete
setblock 546 218 552 minecraft:black_concrete
setblock 549 218 552 minecraft:black_concrete
setblock 552 218 552 minecraft:black_concrete
setblock 559 218 514 minecraft:magma_block
setblock 559 218 515 minecraft:black_concrete
setblock 559 218 537 minecraft:white_concrete
setblock 559 218 538 minecraft:black_concrete
fill 559 218 545 559 220 545 minecraft:black_concrete
fill 517 219 512 517 222 512 minecraft:blue_concrete
setblock 517 219 513 minecraft:black_concrete
setblock 517 219 520 minecraft:black_concrete
setblock 517 219 523 minecraft:black_concrete
fill 517 219 526 517 222 526 minecraft:blue_concrete
fill 517 219 530 517 221 530 minecraft:blue_concrete
setblock 517 219 531 minecraft:black_concrete
fill 517 219 535 517 220 535 minecraft:black_concrete
setblock 517 219 540 minecraft:black_concrete
setblock 517 219 543 minecraft:black_concrete
setblock 517 219 545 minecraft:white_concrete
setblock 517 219 548 minecraft:black_concrete
fill 519 219 510 519 221 510 minecraft:blue_concrete
fill 521 219 510 521 221 510 minecraft:blue_concrete
fill 532 219 552 532 221 552 minecraft:blue_concrete
setblock 539 219 510 minecraft:black_concrete
fill 540 219 552 540 221 552 minecraft:blue_concrete
setblock 544 219 552 minecraft:white_concrete
fill 546 219 552 546 221 552 minecraft:blue_concrete
fill 549 219 552 549 221 552 minecraft:blue_concrete
fill 552 219 552 552 221 552 minecraft:blue_concrete
setblock 555 219 552 minecraft:black_concrete
fill 557 219 552 557 222 552 minecraft:blue_concrete
fill 558 219 552 558 220 552 minecraft:black_concrete
setblock 559 219 510 minecraft:black_concrete
fill 559 219 514 559 219 515 minecraft:blue_concrete
setblock 559 219 523 minecraft:black_concrete
fill 559 219 537 559 221 538 minecraft:blue_concrete
setblock 559 219 539 minecraft:black_concrete
fill 517 220 513 517 221 513 minecraft:blue_concrete
fill 517 220 520 517 221 520 minecraft:blue_concrete
fill 517 220 523 517 221 523 minecraft:blue_concrete
setblock 517 220 524 minecraft:black_concrete
setblock 517 220 527 minecraft:black_concrete
fill 517 220 531 517 221 531 minecraft:blue_concrete
setblock 517 220 539 minecraft:black_concrete
fill 517 220 540 517 221 540 minecraft:blue_concrete
fill 517 220 543 517 221 543 minecraft:blue_concrete
setblock 517 220 544 minecraft:black_concrete
fill 517 220 545 517 221 545 minecraft:blue_concrete
setblock 517 220 547 minecraft:black_concrete
fill 517 220 548 517 221 548 minecraft:blue_concrete
setblock 521 220 552 minecraft:black_concrete
setblock 522 220 510 minecraft:black_concrete
setblock 523 220 510 minecraft:shroomlight
setblock 525 220 552 minecraft:black_concrete
setblock 528 220 510 minecraft:black_concrete
setblock 530 220 510 minecraft:black_concrete
fill 530 220 532 532 220 534 minecraft:redstone_block
fill 531 220 525 533 220 527 minecraft:redstone_block
setblock 531 220 552 minecraft:black_concrete
setblock 533 220 510 minecraft:black_concrete
fill 537 220 525 539 220 527 minecraft:redstone_block
fill 537 220 533 539 220 535 minecraft:redstone_block
fill 539 220 510 539 221 510 minecraft:blue_concrete
fill 544 220 552 544 221 552 minecraft:blue_concrete
setblock 547 220 552 minecraft:black_concrete
fill 548 220 510 549 220 510 minecraft:black_concrete
fill 550 220 510 551 221 510 minecraft:blue_concrete
fill 555 220 552 555 221 552 minecraft:blue_concrete
fill 559 220 510 559 222 510 minecraft:blue_concrete
setblock 559 220 514 minecraft:black_concrete
fill 559 220 515 559 221 515 minecraft:blue_concrete
setblock 559 220 516 minecraft:black_concrete
setblock 559 220 519 minecraft:black_concrete
fill 559 220 523 559 221 523 minecraft:blue_concrete
setblock 559 220 528 minecraft:black_concrete
fill 559 220 533 559 220 534 minecraft:black_concrete
fill 559 220 539 559 221 539 minecraft:blue_concrete
setblock 559 220 540 minecraft:magma_block
setblock 559 220 548 minecraft:black_concrete
setblock 517 221 524 minecraft:blue_concrete
setblock 517 221 527 minecraft:blue_concrete
setblock 517 221 535 minecraft:blue_concrete
setblock 517 221 539 minecraft:blue_concrete
setblock 517 221 544 minecraft:blue_concrete
setblock 517 221 547 minecraft:blue_concrete
fill 518 221 511 519 222 512 minecraft:black_concrete
fill 518 221 513 518 222 513 minecraft:gray_concrete
fill 518 221 514 518 222 519 minecraft:black_concrete
fill 518 221 520 518 222 520 minecraft:gray_concrete
fill 518 221 521 518 222 526 minecraft:black_concrete
fill 518 221 527 518 222 527 minecraft:gray_concrete
fill 518 221 528 518 222 533 minecraft:black_concrete
fill 518 221 534 518 222 534 minecraft:gray_concrete
fill 518 221 535 518 222 540 minecraft:black_concrete
fill 518 221 541 518 222 541 minecraft:gray_concrete
fill 518 221 542 518 222 547 minecraft:black_concrete
fill 518 221 548 518 222 548 minecraft:gray_concrete
fill 518 221 549 518 222 551 minecraft:black_concrete
fill 519 221 513 520 222 515 minecraft:black_concrete
fill 519 221 516 519 222 516 minecraft:gray_concrete
fill 519 221 517 519 222 522 minecraft:black_concrete
fill 519 221 523 519 222 523 minecraft:gray_concrete
fill 519 221 524 519 222 529 minecraft:black_concrete
fill 519 221 530 519 222 530 minecraft:gray_concrete
fill 519 221 531 519 222 536 minecraft:black_concrete
fill 519 221 537 519 222 537 minecraft:gray_concrete
fill 519 221 538 519 222 543 minecraft:black_concrete
fill 519 221 544 519 222 544 minecraft:gray_concrete
fill 519 221 545 519 222 550 minecraft:black_concrete
fill 519 221 551 519 222 551 minecraft:gray_concrete
fill 520 221 511 521 222 511 minecraft:black_concrete
fill 520 221 512 520 222 512 minecraft:gray_concrete
fill 520 221 516 521 222 518 minecraft:black_concrete
fill 520 221 519 520 222 519 minecraft:gray_concrete
fill 520 221 520 520 222 525 minecraft:black_concrete
fill 520 221 526 520 222 526 minecraft:gray_concrete
fill 520 221 527 520 222 532 minecraft:black_concrete
fill 520 221 533 520 222 533 minecraft:gray_concrete
fill 520 221 534 520 222 539 minecraft:black_concrete
fill 520 221 540 520 222 540 minecraft:gray_concrete
fill 520 221 541 520 222 546 minecraft:black_concrete
fill 520 221 547 520 222 547 minecraft:gray_concrete
fill 520 221 548 520 222 551 minecraft:black_concrete
fill 521 221 512 522 222 514 minecraft:black_concrete
fill 521 221 515 521 222 515 minecraft:gray_concrete
fill 521 221 519 522 222 521 minecraft:black_concrete
fill 521 221 522 521 222 522 minecraft:gray_concrete
fill 521 221 523 521 222 528 minecraft:black_concrete
fill 521 221 529 521 222 529 minecraft:gray_concrete
fill 521 221 530 521 222 535 minecraft:black_concrete
fill 521 221 536 521 222 536 minecraft:gray_concrete
fill 521 221 537 521 222 542 minecraft:black_concrete
fill 521 221 543 521 222 543 minecraft:gray_concrete
fill 521 221 544 521 222 549 minecraft:black_concrete
fill 521 221 550 521 222 550 minecraft:gray_concrete
fill 521 221 551 525 222 551 minecraft:black_concrete
setblock 521 221 552 minecraft:blue_concrete
fill 522 221 510 523 221 510 minecraft:blue_concrete
fill 522 221 511 522 222 511 minecraft:gray_concrete
fill 522 221 515 523 222 517 minecraft:black_concrete
fill 522 221 518 522 222 518 minecraft:gray_concrete
fill 522 221 522 523 222 524 minecraft:black_concrete
fill 522 221 525 522 222 525 minecraft:gray_concrete
fill 522 221 526 522 222 531 minecraft:black_concrete
fill 522 221 532 522 222 532 minecraft:gray_concrete
fill 522 221 533 522 222 538 minecraft:black_concrete
fill 522 221 539 522 222 539 minecraft:gray_concrete
fill 522 221 540 522 222 545 minecraft:black_concrete
fill 522 221 546 522 222 546 minecraft:gray_concrete
fill 522 221 547 522 222 550 minecraft:black_concrete
fill 523 221 511 524 222 513 minecraft:black_concrete
fill 523 221 514 523 222 514 minecraft:gray_concrete
fill 523 221 518 524 222 520 minecraft:black_concrete
fill 523 221 521 523 222 521 minecraft:gray_concrete
fill 523 221 525 524 222 527 minecraft:black_concrete
fill 523 221 528 523 222 528 minecraft:gray_concrete
fill 523 221 529 523 222 534 minecraft:black_concrete
fill 523 221 535 523 222 535 minecraft:gray_concrete
fill 523 221 536 523 222 541 minecraft:black_concrete
fill 523 221 542 523 222 542 minecraft:gray_concrete
fill 523 221 543 523 222 548 minecraft:black_concrete
fill 523 221 549 523 222 549 minecraft:gray_concrete
fill 523 221 550 527 222 550 minecraft:black_concrete
fill 524 221 514 525 222 516 minecraft:black_concrete
fill 524 221 517 524 222 517 minecraft:gray_concrete
fill 524 221 521 525 222 523 minecraft:black_concrete
fill 524 221 524 524 222 524 minecraft:gray_concrete
fill 524 221 528 525 222 530 minecraft:black_concrete
fill 524 221 531 524 222 531 minecraft:gray_concrete
fill 524 221 532 524 222 537 minecraft:black_concrete
fill 524 221 538 524 222 538 minecraft:gray_concrete
fill 524 221 539 524 222 544 minecraft:black_concrete
fill 524 221 545 524 222 545 minecraft:gray_concrete
fill 524 221 546 524 222 549 minecraft:black_concrete
fill 525 221 511 526 222 512 minecraft:black_concrete
fill 525 221 513 525 222 513 minecraft:gray_concrete
fill 525 221 517 526 222 519 minecraft:black_concrete
fill 525 221 520 525 222 520 minecraft:gray_concrete
fill 525 221 524 526 222 526 minecraft:black_concrete
fill 525 221 527 525 222 527 minecraft:gray_concrete
fill 525 221 531 526 222 533 minecraft:black_concrete
fill 525 221 534 525 222 534 minecraft:gray_concrete
fill 525 221 535 525 222 540 minecraft:black_concrete
fill 525 221 541 525 222 541 minecraft:gray_concrete
fill 525 221 542 525 222 547 minecraft:black_concrete
fill 525 221 548 525 222 548 minecraft:gray_concrete
fill 525 221 549 529 222 549 minecraft:black_concrete
setblock 525 221 552 minecraft:blue_concrete
fill 526 221 513 527 222 515 minecraft:black_concrete
fill 526 221 516 526 222 516 minecraft:gray_concrete
fill 526 221 520 527 222 522 minecraft:black_concrete
fill 526 221 523 526 222 523 minecraft:gray_concrete
fill 526 221 527 527 222 529 minecraft:black_concrete
fill 526 221 530 526 222 530 minecraft:gray_concrete
fill 526 221 534 527 222 536 minecraft:black_concrete
fill 526 221 537 526 222 537 minecraft:gray_concrete
fill 526 221 538 526 222 543 minecraft:black_concrete
fill 526 221 544 526 222 544 minecraft:gray_concrete
fill 526 221 545 526 222 548 minecraft:black_concrete
fill 526 221 551 526 222 551 minecraft:gray_concrete
fill 527 221 510 528 221 510 minecraft:blue_concrete
fill 527 221 511 528 222 511 minecraft:black_concrete
fill 527 221 512 527 222 512 minecraft:gray_concrete
fill 527 221 516 528 222 518 minecraft:black_concrete
fill 527 221 519 527 222 519 minecraft:gray_concrete
fill 527 221 523 528 222 525 minecraft:black_concrete
fill 527 221 526 527 222 526 minecraft:gray_concrete
fill 527 221 530 528 222 532 minecraft:black_concrete
fill 527 221 533 527 222 533 minecraft:gray_concrete
fill 527 221 537 528 222 539 minecraft:black_concrete
fill 527 221 540 527 222 540 minecraft:gray_concrete
fill 527 221 541 527 222 546 minecraft:black_concrete
fill 527 221 547 527 222 547 minecraft:gray_concrete
fill 527 221 548 531 222 548 minecraft:black_concrete
fill 527 221 551 532 222 551 minecraft:black_concrete
fill 528 221 512 529 222 514 minecraft:black_concrete
fill 528 221 515 528 222 515 minecraft:gray_concrete
fill 528 221 519 529 222 521 minecraft:black_concrete
fill 528 221 522 528 222 522 minecraft:gray_concrete
fill 528 221 526 529 222 528 minecraft:black_concrete
fill 528 221 529 528 222 529 minecraft:gray_concrete
fill 528 221 533 529 221 535 minecraft:black_concrete
fill 528 221 536 528 222 536 minecraft:gray_concrete
fill 528 221 540 529 222 542 minecraft:black_concrete
fill 528 221 543 528 222 543 minecraft:gray_concrete
fill 528 221 544 528 222 547 minecraft:black_concrete
fill 528 221 550 528 222 550 minecraft:gray_concrete
fill 529 221 511 529 222 511 minecraft:gray_concrete
fill 529 221 515 530 222 517 minecraft:black_concrete
fill 529 221 518 529 222 518 minecraft:gray_concrete
fill 529 221 522 530 221 524 minecraft:black_concrete
fill 529 221 525 529 222 525 minecraft:gray_concrete
fill 529 221 529 530 221 531 minecraft:black_concrete
setblock 529 221 532 minecraft:gray_concrete
fill 529 221 536 530 222 538 minecraft:black_concrete
fill 529 221 539 529 222 539 minecraft:gray_concrete
fill 529 221 543 530 222 545 minecraft:black_concrete
fill 529 221 546 529 222 546 minecraft:gray_concrete
fill 529 221 547 533 222 547 minecraft:black_concrete
fill 529 221 550 534 222 550 minecraft:black_concrete
setblock 530 221 510 minecraft:blue_concrete
fill 530 221 511 531 222 513 minecraft:black_concrete
fill 530 221 514 530 222 514 minecraft:gray_concrete
fill 530 221 518 531 222 520 minecraft:black_concrete
fill 530 221 521 530 222 521 minecraft:gray_concrete
fill 530 221 525 530 221 527 minecraft:black_concrete
setblock 530 221 528 minecraft:gray_concrete
setblock 530 221 535 minecraft:gray_concrete
fill 530 221 539 531 222 541 minecraft:black_concrete
fill 530 221 542 530 222 542 minecraft:gray_concrete
fill 530 221 546 535 222 546 minecraft:black_concrete
fill 530 221 549 530 222 549 minecraft:gray_concrete
fill 531 221 514 532 222 516 minecraft:black_concrete
fill 531 221 517 531 222 517 minecraft:gray_concrete
fill 531 221 521 532 222 523 minecraft:black_concrete
setblock 531 221 524 minecraft:gray_concrete
fill 531 221 528 532 221 530 minecraft:black_concrete
setblock 531 221 531 minecraft:gray_concrete
fill 531 221 535 532 221 537 minecraft:black_concrete
fill 531 221 538 531 222 538 minecraft:gray_concrete
fill 531 221 542 532 222 544 minecraft:black_concrete
fill 531 221 545 531 222 545 minecraft:gray_concrete
fill 531 221 549 536 222 549 minecraft:black_concrete
setblock 531 221 552 minecraft:blue_concrete
fill 532 221 511 533 222 512 minecraft:black_concrete
fill 532 221 513 532 222 513 minecraft:gray_concrete
fill 532 221 517 533 222 519 minecraft:black_concrete
fill 532 221 520 532 222 520 minecraft:gray_concrete
fill 532 221 524 537 221 524 minecraft:black_concrete
fill 532 221 531 533 221 531 minecraft:black_concrete
fill 532 221 538 533 222 540 minecraft:black_concrete
fill 532 221 541 532 222 541 minecraft:gray_concrete
fill 532 221 545 537 222 545 minecraft:black_concrete
fill 532 221 548 532 222 548 minecraft:gray_concrete
setblock 533 221 510 minecraft:blue_concrete
fill 533 221 513 534 222 515 minecraft:black_concrete
fill 533 221 516 533 222 516 minecraft:gray_concrete
fill 533 221 520 534 222 522 minecraft:black_concrete
fill 533 221 523 533 222 523 minecraft:gray_concrete
fill 533 221 528 533 221 529 minecraft:black_concrete
setblock 533 221 530 minecraft:gray_concrete
fill 533 221 532 533 221 536 minecraft:black_concrete
fill 533 221 537 533 222 537 minecraft:gray_concrete
fill 533 221 541 534 222 543 minecraft:black_concrete
fill 533 221 544 533 222 544 minecraft:gray_concrete
fill 533 221 548 538 222 548 minecraft:black_concrete
fill 533 221 551 533 222 551 minecraft:gray_concrete
fill 534 221 511 535 222 511 minecraft:black_concrete
fill 534 221 512 534 222 512 minecraft:gray_concrete
fill 534 221 516 535 222 518 minecraft:black_concrete
fill 534 221 519 534 222 519 minecraft:gray_concrete
fill 534 221 523 539 222 523 minecraft:black_concrete
fill 534 221 525 535 221 525 minecraft:black_concrete
setblock 534 221 526 minecraft:gray_concrete
fill 534 221 527 536 221 528 minecraft:black_concrete
fill 534 221 532 535 221 532 minecraft:black_concrete
fill 534 221 533 534 222 533 minecraft:gray_concrete
fill 534 221 534 534 222 539 minecraft:black_concrete
fill 534 221 540 534 222 540 minecraft:gray_concrete
fill 534 221 544 539 222 544 minecraft:black_concrete
fill 534 221 547 534 222 547 minecraft:gray_concrete
fill 534 221 551 539 222 551 minecraft:black_concrete
fill 535 221 512 536 222 514 minecraft:black_concrete
fill 535 221 515 535 222 515 minecraft:gray_concrete
fill 535 221 519 536 222 521 minecraft:black_concrete
fill 535 221 522 535 222 522 minecraft:gray_concrete
fill 535 221 526 536 221 526 minecraft:black_concrete
fill 535 221 533 536 221 535 minecraft:black_concrete
fill 535 221 536 535 222 536 minecraft:gray_concrete
fill 535 221 537 535 222 542 minecraft:black_concrete
fill 535 221 543 535 222 543 minecraft:gray_concrete
fill 535 221 547 540 222 547 minecraft:black_concrete
fill 535 221 550 535 222 550 minecraft:gray_concrete
fill 536 221 511 536 222 511 minecraft:gray_concrete
fill 536 221 515 537 222 517 minecraft:black_concrete
fill 536 221 518 536 222 518 minecraft:gray_concrete
fill 536 221 522 541 222 522 minecraft:black_concrete
setblock 536 221 525 minecraft:gray_concrete
setblock 536 221 532 minecraft:gray_concrete
fill 536 221 536 537 221 538 minecraft:black_concrete
fill 536 221 539 536 222 539 minecraft:gray_concrete
fill 536 221 540 536 222 543 minecraft:black_concrete
fill 536 221 546 536 222 546 minecraft:gray_concrete
fill 536 221 550 541 222 550 minecraft:black_concrete
fill 537 221 511 538 222 513 minecraft:black_concrete
fill 537 221 514 537 222 514 minecraft:gray_concrete
fill 537 221 518 538 222 520 minecraft:black_concrete
fill 537 221 521 537 222 521 minecraft:gray_concrete
setblock 537 221 528 minecraft:gray_concrete
fill 537 221 529 537 221 532 minecraft:black_concrete
fill 537 221 539 538 222 541 minecraft:black_concrete
fill 537 221 542 537 222 542 minecraft:gray_concrete
fill 537 221 543 541 222 543 minecraft:black_concrete
fill 537 221 546 542 222 546 minecraft:black_concrete
fill 537 221 549 537 222 549 minecraft:gray_concrete
fill 538 221 514 539 222 516 minecraft:black_concrete
fill 538 221 517 538 222 517 minecraft:gray_concrete
fill 538 221 521 543 222 521 minecraft:black_concrete
setblock 538 221 524 minecraft:gray_concrete
fill 538 221 528 539 221 530 minecraft:black_concrete
fill 538 221 531 538 222 531 minecraft:gray_concrete
fill 538 221 532 542 221 532 minecraft:black_concrete
fill 538 221 536 539 221 537 minecraft:black_concrete
fill 538 221 538 538 222 538 minecraft:gray_concrete
fill 538 221 542 543 222 542 minecraft:black_concrete
fill 538 221 545 538 222 545 minecraft:gray_concrete
fill 538 221 549 543 222 549 minecraft:black_concrete
setblock 538 221 552 minecraft:white_concrete
fill 539 221 511 540 222 512 minecraft:black_concrete
fill 539 221 513 539 222 513 minecraft:gray_concrete
fill 539 221 517 540 222 519 minecraft:black_concrete
fill 539 221 520 539 222 520 minecraft:gray_concrete
fill 539 221 524 544 221 524 minecraft:black_concrete
fill 539 221 531 544 222 531 minecraft:black_concrete
fill 539 221 538 540 222 540 minecraft:black_concrete
fill 539 221 541 539 222 541 minecraft:gray_concrete
fill 539 221 545 544 222 545 minecraft:black_concrete
fill 539 221 548 539 222 548 minecraft:gray_concrete
fill 540 221 513 541 222 515 minecraft:black_concrete
fill 540 221 516 540 222 516 minecraft:gray_concrete
fill 540 221 520 545 222 520 minecraft:black_concrete
fill 540 221 523 540 222 523 minecraft:gray_concrete
fill 540 221 525 540 221 529 minecraft:black_concrete
fill 540 221 530 540 222 530 minecraft:gray_concrete
fill 540 221 533 540 221 536 minecraft:black_concrete
fill 540 221 537 540 222 537 minecraft:gray_concrete
fill 540 221 541 545 222 541 minecraft:black_concrete
fill 540 221 544 540 222 544 minecraft:gray_concrete
fill 540 221 548 545 222 548 minecraft:black_concrete
fill 540 221 551 540 222 551 minecraft:gray_concrete
fill 541 221 511 542 222 511 minecraft:black_concrete
fill 541 221 512 541 222 512 minecraft:gray_concrete
fill 541 221 516 542 222 518 minecraft:black_concrete
fill 541 221 519 541 222 519 minecraft:gray_concrete
fill 541 221 523 546 222 523 minecraft:black_concrete
fill 541 221 525 542 222 525 minecraft:black_concrete
fill 541 221 526 541 222 526 minecraft:gray_concrete
fill 541 221 527 541 222 530 minecraft:black_concrete
fill 541 221 533 541 222 533 minecraft:gray_concrete
fill 541 221 534 541 222 539 minecraft:black_concrete
fill 541 221 540 541 222 540 minecraft:gray_concrete
fill 541 221 544 546 222 544 minecraft:black_concrete
fill 541 221 547 541 222 547 minecraft:gray_concrete
fill 541 221 551 546 222 551 minecraft:black_concrete
fill 542 221 512 543 222 514 minecraft:black_concrete
fill 542 221 515 542 222 515 minecraft:gray_concrete
fill 542 221 519 547 222 519 minecraft:black_concrete
fill 542 221 522 542 222 522 minecraft:gray_concrete
fill 542 221 526 543 222 528 minecraft:black_concrete
fill 542 221 529 542 222 529 minecraft:gray_concrete
fill 542 221 530 546 222 530 minecraft:black_concrete
fill 542 221 533 543 222 535 minecraft:black_concrete
fill 542 221 536 542 222 536 minecraft:gray_concrete
fill 542 221 537 542 222 540 minecraft:black_concrete
fill 542 221 543 542 222 543 minecraft:gray_concrete
fill 542 221 547 547 222 547 minecraft:black_concrete
fill 542 221 550 542 222 550 minecraft:gray_concrete
fill 543 221 511 543 222 511 minecraft:gray_concrete
fill 543 221 515 544 222 517 minecraft:black_concrete
fill 543 221 518 543 222 518 minecraft:gray_concrete
fill 543 221 522 548 222 522 minecraft:black_concrete
fill 543 221 525 543 222 525 minecraft:gray_concrete
fill 543 221 529 548 222 529 minecraft:black_concrete
fill 543 221 532 543 222 532 minecraft:gray_concrete
fill 543 221 536 544 222 538 minecraft:black_concrete
fill 543 221 539 543 222 539 minecraft:gray_concrete
fill 543 221 540 547 222 540 minecraft:black_concrete
fill 543 221 543 548 222 543 minecraft:black_concrete
fill 543 221 546 543 222 546 minecraft:gray_concrete
fill 543 221 550 548 222 550 minecraft:black_concrete
fill 544 221 511 545 222 513 minecraft:black_concrete
fill 544 221 514 544 222 514 minecraft:gray_concrete
fill 544 221 518 549 222 518 minecraft:black_concrete
fill 544 221 521 544 222 521 minecraft:gray_concrete
fill 544 221 525 545 222 527 minecraft:black_concrete
fill 544 221 528 544 222 528 minecraft:gray_concrete
fill 544 221 532 545 222 534 minecraft:black_concrete
fill 544 221 535 544 222 535 minecraft:gray_concrete
fill 544 221 539 549 222 539 minecraft:black_concrete
fill 544 221 542 544 222 542 minecraft:gray_concrete
fill 544 221 546 549 222 546 minecraft:black_concrete
fill 544 221 549 544 222 549 minecraft:gray_concrete
fill 545 221 514 546 222 516 minecraft:black_concrete
fill 545 221 517 545 222 517 minecraft:gray_concrete
fill 545 221 521 550 222 521 minecraft:black_concrete
fill 545 221 524 545 222 524 minecraft:gray_concrete
fill 545 221 528 550 222 528 minecraft:black_concrete
fill 545 221 531 545 222 531 minecraft:gray_concrete
fill 545 221 535 546 222 537 minecraft:black_concrete
fill 545 221 538 545 222 538 minecraft:gray_concrete
fill 545 221 542 550 222 542 minecraft:black_concrete
fill 545 221 545 545 222 545 minecraft:gray_concrete
fill 545 221 549 550 222 549 minecraft:black_concrete
fill 546 221 511 547 222 512 minecraft:black_concrete
fill 546 221 513 546 222 513 minecraft:gray_concrete
fill 546 221 517 551 222 517 minecraft:black_concrete
fill 546 221 520 546 222 520 minecraft:gray_concrete
fill 546 221 524 547 222 526 minecraft:black_concrete
fill 546 221 527 546 222 527 minecraft:gray_concrete
fill 546 221 531 547 222 533 minecraft:black_concrete
fill 546 221 534 546 222 534 minecraft:gray_concrete
fill 546 221 538 551 222 538 minecraft:black_concrete
fill 546 221 541 546 222 541 minecraft:gray_concrete
fill 546 221 545 551 222 545 minecraft:black_concrete
fill 546 221 548 546 222 548 minecraft:gray_concrete
fill 547 221 513 548 222 515 minecraft:black_concrete
fill 547 221 516 547 222 516 minecraft:gray_concrete
fill 547 221 520 552 222 520 minecraft:black_concrete
fill 547 221 523 547 222 523 minecraft:gray_concrete
fill 547 221 527 552 222 527 minecraft:black_concrete
fill 547 221 530 547 222 530 minecraft:gray_concrete
fill 547 221 534 548 222 536 minecraft:black_concrete
fill 547 221 537 547 222 537 minecraft:gray_concrete
fill 547 221 541 552 222 541 minecraft:black_concrete
fill 547 221 544 547 222 544 minecraft:gray_concrete
fill 547 221 548 552 222 548 minecraft:black_concrete
fill 547 221 551 547 222 551 minecraft:gray_concrete
setblock 547 221 552 minecraft:blue_concrete
setblock 548 221 510 minecraft:white_concrete
fill 548 221 511 549 222 511 minecraft:black_concrete
fill 548 221 512 548 222 512 minecraft:gray_concrete
fill 548 221 516 553 222 516 minecraft:black_concrete
fill 548 221 519 548 222 519 minecraft:gray_concrete
fill 548 221 523 549 222 525 minecraft:black_concrete
fill 548 221 526 548 222 526 minecraft:gray_concrete
fill 548 221 530 549 222 532 minecraft:black_concrete
fill 548 221 533 548 222 533 minecraft:gray_concrete
fill 548 221 537 553 222 537 minecraft:black_concrete
fill 548 221 540 548 222 540 minecraft:gray_concrete
fill 548 221 544 553 222 544 minecraft:black_concrete
fill 548 221 547 548 222 547 minecraft:gray_concrete
fill 548 221 551 553 222 551 minecraft:black_concrete
setblock 549 221 510 minecraft:blue_concrete
fill 549 221 512 550 222 514 minecraft:black_concrete
fill 549 221 515 549 222 515 minecraft:gray_concrete
fill 549 221 519 554 222 519 minecraft:black_concrete
fill 549 221 522 549 222 522 minecraft:gray_concrete
fill 549 221 526 554 222 526 minecraft:black_concrete
fill 549 221 529 549 222 529 minecraft:gray_concrete
fill 549 221 533 550 222 535 minecraft:black_concrete
fill 549 221 536 549 222 536 minecraft:gray_concrete
fill 549 221 540 554 222 540 minecraft:black_concrete
fill 549 221 543 549 222 543 minecraft:gray_concrete
fill 549 221 547 554 222 547 minecraft:black_concrete
fill 549 221 550 549 222 550 minecraft:gray_concrete
fill 550 221 511 550 222 511 minecraft:gray_concrete
fill 550 221 515 555 222 515 minecraft:black_concrete
fill 550 221 518 550 222 518 minecraft:gray_concrete
fill 550 221 522 551 222 524 minecraft:black_concrete
fill 550 221 525 550 222 525 minecraft:gray_concrete
fill 550 221 529 551 222 531 minecraft:black_concrete
fill 550 221 532 550 222 532 minecraft:gray_concrete
fill 550 221 536 555 222 536 minecraft:black_concrete
fill 550 221 539 550 222 539 minecraft:gray_concrete
fill 550 221 543 555 222 543 minecraft:black_concrete
fill 550 221 546 550 222 546 minecraft:gray_concrete
fill 550 221 550 555 222 550 minecraft:black_concrete
fill 551 221 511 552 222 513 minecraft:black_concrete
fill 551 221 514 551 222 514 minecraft:gray_concrete
fill 551 221 518 556 222 518 minecraft:black_concrete
fill 551 221 521 551 222 521 minecraft:gray_concrete
fill 551 221 525 556 222 525 minecraft:black_concrete
fill 551 221 528 551 222 528 minecraft:gray_concrete
fill 551 221 532 552 222 534 minecraft:black_concrete
fill 551 221 535 551 222 535 minecraft:gray_concrete
fill 551 221 539 556 222 539 minecraft:black_concrete
fill 551 221 542 551 222 542 minecraft:gray_concrete
fill 551 221 546 556 222 546 minecraft:black_concrete
fill 551 221 549 551 222 549 minecraft:gray_concrete
fill 552 221 514 557 222 514 minecraft:black_concrete
fill 552 221 517 552 222 517 minecraft:gray_concrete
fill 552 221 521 553 222 523 minecraft:black_concrete
fill 552 221 524 552 222 524 minecraft:gray_concrete
fill 552 221 528 553 222 530 minecraft:black_concrete
fill 552 221 531 552 222 531 minecraft:gray_concrete
fill 552 221 535 557 222 535 minecraft:black_concrete
fill 552 221 538 552 222 538 minecraft:gray_concrete
fill 552 221 542 557 222 542 minecraft:black_concrete
fill 552 221 545 552 222 545 minecraft:gray_concrete
fill 552 221 549 557 222 549 minecraft:black_concrete
fill 553 221 511 554 222 512 minecraft:black_concrete
fill 553 221 513 553 222 513 minecraft:gray_concrete
fill 553 221 517 558 222 517 minecraft:black_concrete
fill 553 221 520 553 222 520 minecraft:gray_concrete
fill 553 221 524 558 222 524 minecraft:black_concrete
fill 553 221 527 553 222 527 minecraft:gray_concrete
fill 553 221 531 554 222 533 minecraft:black_concrete
fill 553 221 534 553 222 534 minecraft:gray_concrete
fill 553 221 538 558 222 538 minecraft:black_concrete
fill 553 221 541 553 222 541 minecraft:gray_concrete
fill 553 221 545 558 222 545 minecraft:black_concrete
fill 553 221 548 553 222 548 minecraft:gray_concrete
fill 554 221 513 558 222 513 minecraft:black_concrete
fill 554 221 516 554 222 516 minecraft:gray_concrete
fill 554 221 520 555 222 522 minecraft:black_concrete
fill 554 221 523 554 222 523 minecraft:gray_concrete
fill 554 221 527 555 222 529 minecraft:black_concrete
fill 554 221 530 554 222 530 minecraft:gray_concrete
fill 554 221 534 558 222 534 minecraft:black_concrete
fill 554 221 537 554 222 537 minecraft:gray_concrete
fill 554 221 541 558 222 541 minecraft:black_concrete
fill 554 221 544 554 222 544 minecraft:gray_concrete
fill 554 221 548 558 222 548 minecraft:black_concrete
fill 554 221 551 554 222 551 minecraft:gray_concrete
setblock 554 221 552 minecraft:magma_block
fill 555 221 511 556 222 511 minecraft:black_concrete
fill 555 221 512 555 222 512 minecraft:gray_concrete
fill 555 221 516 558 222 516 minecraft:black_concrete
fill 555 221 519 555 222 519 minecraft:gray_concrete
fill 555 221 523 558 222 523 minecraft:black_concrete
fill 555 221 526 555 222 526 minecraft:gray_concrete
fill 555 221 530 556 222 532 minecraft:black_concrete
fill 555 221 533 555 222 533 minecraft:gray_concrete
fill 555 221 537 558 222 537 minecraft:black_concrete
fill 555 221 540 555 222 540 minecraft:gray_concrete
fill 555 221 544 558 222 544 minecraft:black_concrete
fill 555 221 547 555 222 547 minecraft:gray_concrete
fill 555 221 551 558 222 551 minecraft:black_concrete
fill 556 221 512 558 222 512 minecraft:black_concrete
fill 556 221 515 556 222 515 minecraft:gray_concrete
fill 556 221 519 557 222 521 minecraft:black_concrete
fill 556 221 522 556 222 522 minecraft:gray_concrete
fill 556 221 526 557 222 528 minecraft:black_concrete
fill 556 221 529 556 222 529 minecraft:gray_concrete
fill 556 221 533 558 222 533 minecraft:black_concrete
fill 556 221 536 556 222 536 minecraft:gray_concrete
fill 556 221 540 558 222 540 minecraft:black_concrete
fill 556 221 543 556 222 543 minecraft:gray_concrete
fill 556 221 547 558 222 547 minecraft:black_concrete
fill 556 221 550 556 222 550 minecraft:gray_concrete
fill 557 221 511 557 222 511 minecraft:gray_concrete
fill 557 221 515 558 222 515 minecraft:black_concrete
fill 557 221 518 557 222 518 minecraft:gray_concrete
fill 557 221 522 558 222 522 minecraft:black_concrete
fill 557 221 525 557 222 525 minecraft:gray_concrete
fill 557 221 529 558 222 531 minecraft:black_concrete
fill 557 221 532 557 222 532 minecraft:gray_concrete
fill 557 221 536 558 222 536 minecraft:black_concrete
fill 557 221 539 557 222 539 minecraft:gray_concrete
fill 557 221 543 558 222 543 minecraft:black_concrete
fill 557 221 546 557 222 546 minecraft:gray_concrete
fill 557 221 550 558 222 550 minecraft:black_concrete
fill 558 221 511 558 222 511 minecraft:black_concrete
fill 558 221 514 558 222 514 minecraft:gray_concrete
fill 558 221 518 558 222 520 minecraft:black_concrete
fill 558 221 521 558 222 521 minecraft:gray_concrete
fill 558 221 525 558 222 527 minecraft:black_concrete
fill 558 221 528 558 222 528 minecraft:gray_concrete
fill 558 221 532 558 222 532 minecraft:black_concrete
fill 558 221 535 558 222 535 minecraft:gray_concrete
fill 558 221 539 558 222 539 minecraft:black_concrete
fill 558 221 542 558 222 542 minecraft:gray_concrete
fill 558 221 546 558 222 546 minecraft:black_concrete
fill 558 221 549 558 222 549 minecraft:gray_concrete
setblock 558 221 552 minecraft:blue_concrete
setblock 559 221 514 minecraft:blue_concrete
setblock 559 221 516 minecraft:blue_concrete
setblock 559 221 519 minecraft:blue_concrete
setblock 559 221 528 minecraft:blue_concrete
fill 559 221 533 559 221 534 minecraft:blue_concrete
setblock 559 221 540 minecraft:blue_concrete
setblock 559 221 545 minecraft:blue_concrete
setblock 559 221 548 minecraft:blue_concrete
fill 517 222 510 543 222 510 minecraft:black_concrete
fill 517 222 513 517 230 516 minecraft:black_concrete
setblock 517 222 517 minecraft:blue_concrete
fill 517 222 518 517 223 525 minecraft:black_concrete
fill 517 222 527 517 222 532 minecraft:black_concrete
fill 517 222 534 517 222 541 minecraft:black_concrete
setblock 517 222 543 minecraft:magma_block
fill 517 222 544 517 223 552 minecraft:black_concrete
fill 518 222 552 519 306 552 minecraft:black_concrete
setblock 520 222 552 minecraft:shroomlight
fill 521 222 552 537 222 552 minecraft:black_concrete
fill 528 222 533 528 222 535 minecraft:black_concrete
fill 529 222 522 529 222 524 minecraft:black_concrete
fill 529 222 529 532 222 530 minecraft:black_concrete
fill 529 222 531 529 222 535 minecraft:shroomlight
fill 530 222 522 530 222 523 minecraft:black_concrete
fill 530 222 524 530 222 528 minecraft:shroomlight
fill 530 222 531 533 222 531 minecraft:shroomlight
fill 530 222 532 532 222 534 minecraft:black_concrete
fill 530 222 535 533 222 535 minecraft:shroomlight
fill 531 222 524 534 222 524 minecraft:shroomlight
fill 531 222 525 533 222 527 minecraft:black_concrete
fill 531 222 528 540 222 528 minecraft:shroomlight
fill 531 222 536 532 222 537 minecraft:black_concrete
fill 533 222 529 533 222 530 minecraft:shroomlight
fill 533 222 532 533 222 534 minecraft:shroomlight
setblock 533 222 536 minecraft:black_concrete
fill 534 222 525 534 222 527 minecraft:shroomlight
fill 534 222 532 540 222 532 minecraft:shroomlight
fill 535 222 524 535 222 527 minecraft:black_concrete
fill 535 222 533 535 222 535 minecraft:black_concrete
fill 536 222 524 536 222 527 minecraft:shroomlight
fill 536 222 533 536 222 536 minecraft:shroomlight
fill 536 222 537 537 222 538 minecraft:black_concrete
fill 537 222 524 540 222 524 minecraft:shroomlight
fill 537 222 525 539 222 527 minecraft:black_concrete
fill 537 222 529 537 222 531 minecraft:shroomlight
fill 537 222 533 539 222 535 minecraft:black_concrete
fill 537 222 536 540 222 536 minecraft:shroomlight
fill 538 222 529 539 222 530 minecraft:black_concrete
fill 538 222 537 539 222 537 minecraft:black_concrete
setblock 538 222 552 minecraft:blue_concrete
fill 539 222 552 546 222 552 minecraft:black_concrete
fill 540 222 525 540 222 527 minecraft:shroomlight
setblock 540 222 529 minecraft:black_concrete
fill 540 222 533 540 222 535 minecraft:shroomlight
fill 541 222 524 544 222 524 minecraft:black_concrete
fill 541 222 532 542 222 532 minecraft:black_concrete
setblock 544 222 510 minecraft:blue_concrete
fill 545 222 510 551 231 510 minecraft:black_concrete
setblock 547 222 552 minecraft:magma_block
fill 548 222 552 556 222 552 minecraft:black_concrete
fill 553 222 510 556 222 510 minecraft:black_concrete
fill 558 222 510 558 261 510 minecraft:black_concrete
fill 558 222 552 559 224 552 minecraft:black_concrete
fill 559 222 511 559 222 528 minecraft:black_concrete
fill 559 222 530 559 267 530 minecraft:black_concrete
fill 559 222 532 559 222 541 minecraft:black_concrete
fill 559 222 543 559 222 551 minecraft:black_concrete
fill 517 223 510 519 282 510 minecraft:black_concrete
fill 517 223 512 517 307 512 minecraft:black_concrete
fill 517 223 517 517 307 517 minecraft:black_concrete
fill 517 223 526 517 223 529 minecraft:black_concrete
setblock 517 223 530 minecraft:blue_concrete
fill 517 223 531 517 224 532 minecraft:black_concrete
fill 517 223 534 517 225 535 minecraft:black_concrete
setblock 517 223 536 minecraft:blue_concrete
fill 517 223 537 517 223 543 minecraft:black_concrete
setblock 520 223 510 minecraft:blue_concrete
fill 520 223 552 533 223 552 minecraft:black_concrete
fill 521 223 510 544 223 510 minecraft:black_concrete
setblock 534 223 552 minecraft:blue_concrete
fill 535 223 552 541 223 552 minecraft:black_concrete
setblock 542 223 552 minecraft:blue_concrete
setblock 543 223 552 minecraft:shroomlight
fill 544 223 552 546 226 552 minecraft:black_concrete
setblock 547 223 552 minecraft:blue_concrete
fill 548 223 552 549 223 552 minecraft:black_concrete
setblock 550 223 552 minecraft:blue_concrete
fill 551 223 552 552 223 552 minecraft:black_concrete
fill 552 223 510 555 223 510 minecraft:black_concrete
setblock 553 223 552 minecraft:blue_concrete
fill 554 223 552 557 224 552 minecraft:black_concrete
setblock 556 223 510 minecraft:blue_concrete
fill 557 223 510 557 307 510 minecraft:black_concrete
setblock 559 223 510 minecraft:black_concrete
fill 559 223 511 559 224 511 minecraft:blue_concrete
fill 559 223 512 559 239 513 minecraft:black_concrete
setblock 559 223 514 minecraft:blue_concrete
fill 559 223 515 559 223 528 minecraft:black_concrete
fill 559 223 531 559 223 536 minecraft:black_concrete
setblock 559 223 537 minecraft:blue_concrete
fill 559 223 538 559 223 542 minecraft:black_concrete
setblock 559 223 543 minecraft:blue_concrete
fill 559 223 544 559 223 547 minecraft:black_concrete
setblock 559 223 548 minecraft:blue_concrete
fill 559 223 549 559 250 551 minecraft:black_concrete
fill 517 224 518 517 224 519 minecraft:blue_concrete
fill 517 224 520 517 239 524 minecraft:black_concrete
setblock 517 224 525 minecraft:blue_concrete
fill 517 224 526 517 240 528 minecraft:black_concrete
setblock 517 224 529 minecraft:blue_concrete
fill 517 224 530 517 245 530 minecraft:black_concrete
fill 517 224 533 517 269 533 minecraft:black_concrete
fill 517 224 536 517 249 536 minecraft:black_concrete
setblock 517 224 537 minecraft:blue_concrete
fill 517 224 538 517 231 542 minecraft:black_concrete
setblock 517 224 543 minecraft:blue_concrete
fill 517 224 544 517 225 549 minecraft:black_concrete
setblock 517 224 550 minecraft:blue_concrete
fill 517 224 551 517 307 552 minecraft:black_concrete
fill 520 224 510 529 225 510 minecraft:black_concrete
fill 520 224 552 520 307 552 minecraft:black_concrete
fill 521 224 552 522 224 552 minecraft:blue_concrete
fill 523 224 552 532 224 552 minecraft:black_concrete
setblock 530 224 510 minecraft:magma_block
fill 531 224 510 542 225 510 minecraft:black_concrete
setblock 533 224 552 minecraft:blue_concrete
fill 534 224 552 536 227 552 minecraft:black_concrete
setblock 537 224 552 minecraft:blue_concrete
fill 538 224 552 543 225 552 minecraft:black_concrete
setblock 543 224 510 minecraft:blue_concrete
fill 544 224 510 544 285 510 minecraft:black_concrete
fill 547 224 552 547 225 552 minecraft:black_concrete
setblock 548 224 552 minecraft:magma_block
setblock 549 224 552 minecraft:blue_concrete
fill 550 224 552 550 307 552 minecraft:black_concrete
setblock 551 224 552 minecraft:blue_concrete
fill 552 224 510 552 307 510 minecraft:black_concrete
fill 552 224 552 553 226 552 minecraft:black_concrete
fill 553 224 510 554 224 510 minecraft:blue_concrete
fill 555 224 510 556 235 510 minecraft:black_concrete
setblock 559 224 510 minecraft:blue_concrete
fill 559 224 514 559 241 515 minecraft:black_concrete
setblock 559 224 516 minecraft:blue_concrete
fill 559 224 517 559 225 527 minecraft:black_concrete
setblock 559 224 528 minecraft:blue_concrete
fill 559 224 531 559 254 533 minecraft:black_concrete
setblock 559 224 534 minecraft:blue_concrete
fill 559 224 535 559 225 538 minecraft:black_concrete
setblock 559 224 539 minecraft:blue_concrete
fill 559 224 540 559 239 544 minecraft:black_concrete
setblock 559 224 545 minecraft:magma_block
fill 559 224 546 559 281 548 minecraft:black_concrete
fill 517 225 511 517 243 511 minecraft:black_concrete
fill 517 225 518 517 225 519 minecraft:black_concrete
fill 517 225 525 517 272 525 minecraft:black_concrete
fill 517 225 529 517 267 529 minecraft:black_concrete
fill 517 225 531 517 234 531 minecraft:black_concrete
setblock 517 225 532 minecraft:shroomlight
fill 517 225 537 517 307 537 minecraft:black_concrete
fill 517 225 543 517 252 543 minecraft:black_concrete
setblock 517 225 550 minecraft:black_concrete
fill 521 225 552 523 235 552 minecraft:black_concrete
setblock 524 225 552 minecraft:magma_block
fill 525 225 552 533 225 552 minecraft:black_concrete
fill 530 225 510 530 243 510 minecraft:black_concrete
fill 537 225 552 537 307 552 minecraft:black_concrete
fill 543 225 510 543 275 510 minecraft:black_concrete
fill 548 225 552 549 255 552 minecraft:black_concrete
fill 551 225 552 551 245 552 minecraft:black_concrete
fill 553 225 510 554 225 510 minecraft:black_concrete
fill 554 225 552 554 296 552 minecraft:black_concrete
setblock 555 225 552 minecraft:magma_block
fill 556 225 552 557 225 552 minecraft:black_concrete
setblock 558 225 552 minecraft:magma_block
fill 559 225 510 559 307 511 minecraft:black_concrete
fill 559 225 516 559 231 516 minecraft:black_concrete
fill 559 225 528 559 242 529 minecraft:black_concrete
fill 559 225 534 559 253 534 minecraft:black_concrete
fill 559 225 539 559 241 539 minecraft:black_concrete
fill 559 225 545 559 307 545 minecraft:black_concrete
fill 559 225 552 559 307 552 minecraft:black_concrete
fill 517 226 518 517 227 518 minecraft:orange_concrete
fill 517 226 519 517 307 519 minecraft:black_concrete
fill 517 226 532 517 228 532 minecraft:black_concrete
fill 517 226 534 517 227 534 minecraft:orange_concrete
fill 517 226 535 517 240 535 minecraft:black_concrete
fill 517 226 544 517 261 548 minecraft:black_concrete
setblock 517 226 549 minecraft:shroomlight
fill 517 226 550 517 227 550 minecraft:orange_concrete
fill 520 226 510 520 307 510 minecraft:black_concrete
fill 521 226 510 521 227 510 minecraft:orange_concrete
fill 522 226 510 526 229 510 minecraft:black_concrete
fill 524 226 552 530 226 552 minecraft:black_concrete
setblock 527 226 510 minecraft:white_concrete
fill 528 226 510 529 269 510 minecraft:black_concrete
fill 531 226 510 536 266 510 minecraft:black_concrete
fill 531 226 552 531 227 552 minecraft:orange_concrete
fill 532 226 552 533 248 552 minecraft:black_concrete
fill 537 226 510 537 227 510 minecraft:orange_concrete
fill 538 226 510 542 236 510 minecraft:black_concrete
fill 538 226 552 539 258 552 minecraft:black_concrete
setblock 540 226 552 minecraft:magma_block
fill 541 226 552 543 263 552 minecraft:black_concrete
fill 547 226 552 547 227 552 minecraft:orange_concrete
fill 553 226 510 553 227 510 minecraft:orange_concrete
fill 554 226 510 554 294 510 minecraft:black_concrete
fill 555 226 552 555 295 552 minecraft:black_concrete
setblock 556 226 552 minecraft:magma_block
fill 557 226 552 558 238 552 minecraft:black_concrete
fill 559 226 517 559 301 518 minecraft:black_concrete
setblock 559 226 519 minecraft:white_concrete
fill 559 226 520 559 227 520 minecraft:orange_concrete
fill 559 226 521 559 227 527 minecraft:black_concrete
fill 559 226 535 559 307 535 minecraft:black_concrete
fill 559 226 536 559 227 536 minecraft:orange_concrete
fill 559 226 537 559 258 538 minecraft:black_concrete
fill 517 227 549 517 260 549 minecraft:black_concrete
setblock 524 227 552 minecraft:magma_block
fill 525 227 552 530 229 552 minecraft:black_concrete
fill 527 227 510 527 277 510 minecraft:black_concrete
fill 540 227 552 540 307 552 minecraft:black_concrete
setblock 544 227 552 minecraft:shroomlight
fill 545 227 552 546 263 552 minecraft:black_concrete
setblock 552 227 552 minecraft:white_concrete
fill 553 227 552 553 307 552 minecraft:black_concrete
fill 556 227 533 556 228 533 minecraft:blue_concrete
fill 556 227 552 556 291 552 minecraft:black_concrete
fill 559 227 519 559 264 519 minecraft:black_concrete
fill 517 228 518 517 229 518 minecraft:black_concrete
fill 517 228 534 517 233 534 minecraft:black_concrete
fill 517 228 550 517 233 550 minecraft:black_concrete
fill 521 228 510 521 231 510 minecraft:black_concrete
fill 524 228 552 524 291 552 minecraft:black_concrete
fill 531 228 552 531 230 552 minecraft:black_concrete
setblock 534 228 552 minecraft:shroomlight
fill 535 228 552 536 254 552 minecraft:black_concrete
fill 537 228 510 537 233 510 minecraft:black_concrete
fill 544 228 552 544 307 552 minecraft:black_concrete
fill 547 228 552 547 233 552 minecraft:black_concrete
fill 552 228 552 552 307 552 minecraft:black_concrete
fill 553 228 510 553 233 510 minecraft:black_concrete
fill 559 228 520 559 233 522 minecraft:black_concrete
setblock 559 228 523 minecraft:magma_block
fill 559 228 524 559 245 527 minecraft:black_concrete
fill 559 228 536 559 233 536 minecraft:black_concrete
setblock 517 229 532 minecraft:white_concrete
setblock 520 229 513 minecraft:light[level=14]
setblock 520 229 521 minecraft:light[level=14]
setblock 520 229 529 minecraft:light[level=14]
setblock 520 229 537 minecraft:light[level=14]
setblock 520 229 545 minecraft:light[level=14]
setblock 528 229 513 minecraft:light[level=14]
setblock 528 229 521 minecraft:light[level=14]
setblock 528 229 529 minecraft:light[level=14]
setblock 528 229 537 minecraft:light[level=14]
setblock 528 229 545 minecraft:light[level=14]
fill 534 229 552 534 247 552 minecraft:black_concrete
setblock 536 229 513 minecraft:light[level=14]
setblock 536 229 521 minecraft:light[level=14]
setblock 536 229 529 minecraft:light[level=14]
setblock 536 229 537 minecraft:light[level=14]
setblock 536 229 545 minecraft:light[level=14]
setblock 544 229 513 minecraft:light[level=14]
setblock 544 229 521 minecraft:light[level=14]
setblock 544 229 529 minecraft:light[level=14]
setblock 544 229 537 minecraft:light[level=14]
setblock 544 229 545 minecraft:light[level=14]
setblock 552 229 513 minecraft:light[level=14]
setblock 552 229 521 minecraft:light[level=14]
setblock 552 229 529 minecraft:light[level=14]
setblock 552 229 537 minecraft:light[level=14]
setblock 552 229 545 minecraft:light[level=14]
fill 559 229 523 559 307 523 minecraft:black_concrete
setblock 517 230 518 minecraft:shroomlight
fill 517 230 532 517 307 532 minecraft:black_concrete
fill 522 230 510 523 230 510 minecraft:black_concrete
setblock 524 230 510 minecraft:white_concrete
fill 525 230 510 526 241 510 minecraft:black_concrete
fill 525 230 552 527 233 552 minecraft:black_concrete
setblock 528 230 552 minecraft:shroomlight
fill 529 230 552 530 307 552 minecraft:black_concrete
setblock 517 231 513 minecraft:magma_block
fill 517 231 514 517 237 516 minecraft:black_concrete
fill 517 231 518 517 233 518 minecraft:black_concrete
setblock 522 231 510 minecraft:magma_block
setblock 523 231 510 minecraft:shroomlight
fill 524 231 510 524 263 510 minecraft:black_concrete
fill 528 231 552 528 307 552 minecraft:black_concrete
setblock 531 231 552 minecraft:magma_block
fill 517 232 513 517 268 513 minecraft:black_concrete
fill 517 232 538 517 241 539 minecraft:black_concrete
setblock 517 232 540 minecraft:magma_block
fill 517 232 541 517 246 542 minecraft:black_concrete
setblock 521 232 510 minecraft:shroomlight
fill 522 232 510 523 241 510 minecraft:black_concrete
fill 531 232 552 531 233 552 minecraft:black_concrete
fill 545 232 510 550 234 510 minecraft:black_concrete
setblock 551 232 510 minecraft:shroomlight
setblock 559 232 516 minecraft:shroomlight
fill 517 233 540 517 289 540 minecraft:black_concrete
setblock 521 233 510 minecraft:black_concrete
fill 551 233 510 551 254 510 minecraft:black_concrete
fill 559 233 516 559 307 516 minecraft:black_concrete
fill 517 234 518 517 236 518 minecraft:orange_concrete
fill 517 234 534 517 236 534 minecraft:orange_concrete
fill 517 234 550 517 236 550 minecraft:orange_concrete
fill 521 234 510 521 236 510 minecraft:orange_concrete
setblock 525 234 552 minecraft:white_concrete
fill 526 234 552 527 240 552 minecraft:black_concrete
fill 531 234 552 531 236 552 minecraft:orange_concrete
fill 537 234 510 537 236 510 minecraft:orange_concrete
fill 547 234 552 547 236 552 minecraft:orange_concrete
fill 553 234 510 553 236 510 minecraft:orange_concrete
fill 559 234 520 559 236 520 minecraft:orange_concrete
fill 559 234 521 559 251 522 minecraft:black_concrete
fill 559 234 536 559 236 536 minecraft:orange_concrete
setblock 517 235 531 minecraft:shroomlight
fill 525 235 552 525 250 552 minecraft:black_concrete
setblock 545 235 510 minecraft:white_concrete
fill 546 235 510 550 247 510 minecraft:black_concrete
fill 517 236 531 517 307 531 minecraft:black_concrete
fill 521 236 552 522 279 552 minecraft:black_concrete
setblock 523 236 552 minecraft:magma_block
fill 545 236 510 545 307 510 minecraft:black_concrete
setblock 555 236 510 minecraft:white_concrete
fill 556 236 510 556 307 510 minecraft:black_concrete
fill 517 237 518 517 242 518 minecraft:black_concrete
fill 517 237 534 517 242 534 minecraft:black_concrete
setblock 517 237 550 minecraft:magma_block
setblock 520 237 513 minecraft:light[level=14]
setblock 520 237 521 minecraft:light[level=14]
setblock 520 237 529 minecraft:light[level=14]
setblock 520 237 537 minecraft:light[level=14]
setblock 520 237 545 minecraft:light[level=14]
fill 521 237 510 521 242 510 minecraft:black_concrete
fill 523 237 552 523 307 552 minecraft:black_concrete
setblock 528 237 513 minecraft:light[level=14]
setblock 528 237 521 minecraft:light[level=14]
setblock 528 237 529 minecraft:light[level=14]
setblock 528 237 537 minecraft:light[level=14]
setblock 528 237 545 minecraft:light[level=14]
fill 531 237 552 531 242 552 minecraft:black_concrete
setblock 536 237 513 minecraft:light[level=14]
setblock 536 237 521 minecraft:light[level=14]
setblock 536 237 529 minecraft:light[level=14]
setblock 536 237 537 minecraft:light[level=14]
setblock 536 237 545 minecraft:light[level=14]
fill 537 237 510 540 242 510 minecraft:black_concrete
setblock 541 237 510 minecraft:shroomlight
fill 542 237 510 542 261 510 minecraft:black_concrete
setblock 544 237 513 minecraft:light[level=14]
setblock 544 237 521 minecraft:light[level=14]
setblock 544 237 529 minecraft:light[level=14]
setblock 544 237 537 minecraft:light[level=14]
setblock 544 237 545 minecraft:light[level=14]
fill 547 237 552 547 242 552 minecraft:black_concrete
setblock 552 237 513 minecraft:light[level=14]
setblock 552 237 521 minecraft:light[level=14]
setblock 552 237 529 minecraft:light[level=14]
setblock 552 237 537 minecraft:light[level=14]
setblock 552 237 545 minecraft:light[level=14]
fill 553 237 510 553 242 510 minecraft:black_concrete
fill 555 237 510 555 307 510 minecraft:black_concrete
fill 559 237 520 559 242 520 minecraft:black_concrete
setblock 559 237 536 minecraft:white_concrete
fill 517 238 514 517 307 514 minecraft:black_concrete
setblock 517 238 515 minecraft:shroomlight
fill 517 238 516 517 307 516 minecraft:black_concrete
fill 517 238 550 517 242 550 minecraft:black_concrete
fill 541 238 510 541 243 510 minecraft:black_concrete
fill 559 238 536 559 242 536 minecraft:black_concrete
fill 517 239 515 517 307 515 minecraft:black_concrete
fill 538 239 518 538 240 518 minecraft:blackstone
fill 554 239 532 555 240 532 minecraft:blackstone
setblock 557 239 552 minecraft:shroomlight
fill 558 239 552 558 240 552 minecraft:black_concrete
setblock 517 240 520 minecraft:white_concrete
fill 517 240 521 517 271 524 minecraft:black_concrete
fill 557 240 552 557 307 552 minecraft:black_concrete
setblock 559 240 512 minecraft:shroomlight
fill 559 240 513 559 243 513 minecraft:black_concrete
setblock 559 240 540 minecraft:magma_block
fill 559 240 541 559 243 544 minecraft:black_concrete
fill 517 241 520 517 288 520 minecraft:black_concrete
fill 517 241 526 517 248 526 minecraft:black_concrete
setblock 517 241 527 minecraft:magma_block
fill 517 241 528 517 296 528 minecraft:black_concrete
setblock 517 241 535 minecraft:shroomlight
fill 526 241 552 526 307 552 minecraft:black_concrete
setblock 527 241 552 minecraft:white_concrete
setblock 558 241 552 minecraft:white_concrete
setblock 559 241 512 minecraft:black_concrete
fill 559 241 540 559 307 540 minecraft:black_concrete
fill 517 242 527 517 244 527 minecraft:black_concrete
fill 517 242 535 517 307 535 minecraft:black_concrete
fill 517 242 538 517 248 538 minecraft:black_concrete
setblock 517 242 539 minecraft:magma_block
setblock 522 242 510 minecraft:magma_block
fill 523 242 510 523 250 510 minecraft:black_concrete
fill 525 242 510 525 285 510 minecraft:black_concrete
setblock 526 242 510 minecraft:white_concrete
fill 527 242 552 527 266 552 minecraft:black_concrete
fill 558 242 552 558 307 552 minecraft:black_concrete
setblock 559 242 512 minecraft:magma_block
fill 559 242 514 559 303 514 minecraft:black_concrete
setblock 559 242 515 minecraft:white_concrete
setblock 559 242 539 minecraft:shroomlight
fill 517 243 518 517 245 518 minecraft:orange_concrete
fill 517 243 534 517 245 534 minecraft:orange_concrete
fill 517 243 539 517 302 539 minecraft:black_concrete
fill 517 243 550 517 245 550 minecraft:orange_concrete
fill 521 243 510 521 245 510 minecraft:orange_concrete
fill 522 243 510 522 282 510 minecraft:black_concrete
fill 526 243 510 526 307 510 minecraft:black_concrete
fill 531 243 552 531 245 552 minecraft:orange_concrete
fill 537 243 510 537 245 510 minecraft:orange_concrete
fill 538 243 510 540 276 510 minecraft:black_concrete
fill 547 243 552 547 245 552 minecraft:orange_concrete
fill 553 243 510 553 245 510 minecraft:orange_concrete
fill 559 243 512 559 259 512 minecraft:black_concrete
fill 559 243 515 559 301 515 minecraft:black_concrete
fill 559 243 520 559 245 520 minecraft:orange_concrete
setblock 559 243 528 minecraft:magma_block
fill 559 243 529 559 307 529 minecraft:black_concrete
fill 559 243 536 559 245 536 minecraft:orange_concrete
fill 559 243 539 559 246 539 minecraft:black_concrete
setblock 517 244 511 minecraft:magma_block
setblock 530 244 510 minecraft:magma_block
setblock 541 244 510 minecraft:magma_block
setblock 559 244 513 minecraft:shroomlight
fill 559 244 528 559 307 528 minecraft:black_concrete
fill 559 244 541 559 260 541 minecraft:black_concrete
setblock 559 244 542 minecraft:shroomlight
fill 559 244 543 559 300 544 minecraft:black_concrete
fill 517 245 511 517 307 511 minecraft:black_concrete
setblock 517 245 527 minecraft:white_concrete
setblock 520 245 513 minecraft:light[level=14]
setblock 520 245 521 minecraft:light[level=14]
setblock 520 245 529 minecraft:light[level=14]
setblock 520 245 537 minecraft:light[level=14]
setblock 520 245 545 minecraft:light[level=14]
setblock 528 245 513 minecraft:light[level=14]
setblock 528 245 521 minecraft:light[level=14]
setblock 528 245 529 minecraft:light[level=14]
setblock 528 245 537 minecraft:light[level=14]
setblock 528 245 545 minecraft:light[level=14]
fill 530 245 510 530 280 510 minecraft:black_concrete
setblock 536 245 513 minecraft:light[level=14]
setblock 536 245 521 minecraft:light[level=14]
setblock 536 245 529 minecraft:light[level=14]
setblock 536 245 537 minecraft:light[level=14]
setblock 536 245 545 minecraft:light[level=14]
fill 541 245 510 541 307 510 minecraft:black_concrete
setblock 544 245 513 minecraft:light[level=14]
setblock 544 245 521 minecraft:light[level=14]
setblock 544 245 529 minecraft:light[level=14]
setblock 544 245 537 minecraft:light[level=14]
setblock 544 245 545 minecraft:light[level=14]
setblock 552 245 513 minecraft:light[level=14]
setblock 552 245 521 minecraft:light[level=14]
setblock 552 245 529 minecraft:light[level=14]
setblock 552 245 537 minecraft:light[level=14]
setblock 552 245 545 minecraft:light[level=14]
fill 559 245 513 559 264 513 minecraft:black_concrete
fill 559 245 542 559 289 542 minecraft:black_concrete
fill 517 246 518 517 251 518 minecraft:black_concrete
fill 517 246 527 517 307 527 minecraft:black_concrete
setblock 517 246 530 minecraft:shroomlight
fill 517 246 534 517 251 534 minecraft:black_concrete
fill 517 246 550 517 249 550 minecraft:black_concrete
fill 521 246 510 521 251 510 minecraft:black_concrete
fill 531 246 552 531 251 552 minecraft:black_concrete
fill 537 246 510 537 251 510 minecraft:black_concrete
fill 547 246 552 547 251 552 minecraft:black_concrete
setblock 551 246 552 minecraft:magma_block
fill 553 246 510 553 251 510 minecraft:black_concrete
fill 559 246 520 559 251 520 minecraft:black_concrete
fill 559 246 524 559 250 526 minecraft:black_concrete
setblock 559 246 527 minecraft:white_concrete
fill 559 246 536 559 251 536 minecraft:black_concrete
fill 517 247 530 517 277 530 minecraft:black_concrete
setblock 517 247 541 minecraft:white_concrete
fill 517 247 542 517 291 542 minecraft:black_concrete
fill 540 247 539 540 248 539 minecraft:blue_concrete
fill 551 247 552 551 269 552 minecraft:black_concrete
fill 559 247 527 559 307 527 minecraft:black_concrete
setblock 559 247 539 minecraft:magma_block
fill 517 248 541 517 307 541 minecraft:black_concrete
setblock 534 248 552 minecraft:magma_block
fill 546 248 510 546 251 510 minecraft:black_concrete
setblock 547 248 510 minecraft:shroomlight
fill 548 248 510 550 297 510 minecraft:black_concrete
fill 559 248 539 559 274 539 minecraft:black_concrete
setblock 517 249 526 minecraft:white_concrete
setblock 517 249 538 minecraft:shroomlight
setblock 532 249 552 minecraft:white_concrete
fill 533 249 552 534 260 552 minecraft:black_concrete
fill 547 249 510 547 294 510 minecraft:black_concrete
fill 517 250 526 517 279 526 minecraft:black_concrete
setblock 517 250 536 minecraft:white_concrete
setblock 517 250 538 minecraft:black_concrete
setblock 517 250 550 minecraft:magma_block
fill 532 250 552 532 261 552 minecraft:black_concrete
fill 517 251 536 517 296 536 minecraft:black_concrete
setblock 517 251 538 minecraft:shroomlight
setblock 517 251 550 minecraft:black_concrete
setblock 523 251 510 minecraft:white_concrete
setblock 525 251 552 minecraft:magma_block
fill 530 251 524 530 252 525 minecraft:red_terracotta
fill 531 251 524 531 252 524 minecraft:red_terracotta
fill 559 251 524 559 307 524 minecraft:black_concrete
setblock 559 251 525 minecraft:white_concrete
fill 559 251 526 559 307 526 minecraft:black_concrete
fill 559 251 549 559 285 550 minecraft:black_concrete
setblock 559 251 551 minecraft:shroomlight
fill 517 252 518 517 254 518 minecraft:orange_concrete
fill 517 252 534 517 254 534 minecraft:orange_concrete
fill 517 252 538 517 261 538 minecraft:black_concrete
fill 517 252 550 517 254 550 minecraft:orange_concrete
fill 521 252 510 521 254 510 minecraft:orange_concrete
fill 523 252 510 523 267 510 minecraft:black_concrete
fill 525 252 552 525 278 552 minecraft:black_concrete
fill 531 252 552 531 254 552 minecraft:orange_concrete
fill 537 252 510 537 254 510 minecraft:orange_concrete
setblock 546 252 510 minecraft:white_concrete
fill 547 252 552 547 254 552 minecraft:orange_concrete
fill 553 252 510 553 254 510 minecraft:orange_concrete
fill 559 252 520 559 254 520 minecraft:orange_concrete
setblock 559 252 521 minecraft:magma_block
fill 559 252 522 559 302 522 minecraft:black_concrete
fill 559 252 525 559 307 525 minecraft:black_concrete
fill 559 252 536 559 254 536 minecraft:orange_concrete
fill 559 252 551 559 307 551 minecraft:black_concrete
setblock 517 253 543 minecraft:white_concrete
setblock 520 253 513 minecraft:light[level=14]
setblock 520 253 521 minecraft:light[level=14]
setblock 520 253 529 minecraft:light[level=14]
setblock 520 253 537 minecraft:light[level=14]
setblock 520 253 545 minecraft:light[level=14]
setblock 528 253 513 minecraft:light[level=14]
setblock 528 253 521 minecraft:light[level=14]
setblock 528 253 529 minecraft:light[level=14]
setblock 528 253 537 minecraft:light[level=14]
setblock 528 253 545 minecraft:light[level=14]
setblock 536 253 513 minecraft:light[level=14]
setblock 536 253 521 minecraft:light[level=14]
setblock 536 253 529 minecraft:light[level=14]
setblock 536 253 537 minecraft:light[level=14]
setblock 536 253 545 minecraft:light[level=14]
setblock 544 253 513 minecraft:light[level=14]
setblock 544 253 521 minecraft:light[level=14]
setblock 544 253 529 minecraft:light[level=14]
setblock 544 253 537 minecraft:light[level=14]
setblock 544 253 545 minecraft:light[level=14]
fill 546 253 510 546 268 510 minecraft:black_concrete
setblock 552 253 513 minecraft:light[level=14]
setblock 552 253 521 minecraft:light[level=14]
setblock 552 253 529 minecraft:light[level=14]
setblock 552 253 537 minecraft:light[level=14]
setblock 552 253 545 minecraft:light[level=14]
fill 559 253 521 559 266 521 minecraft:black_concrete
fill 517 254 543 517 276 543 minecraft:black_concrete
setblock 559 254 534 minecraft:shroomlight
fill 517 255 518 517 260 518 minecraft:black_concrete
fill 517 255 534 517 260 534 minecraft:black_concrete
fill 517 255 550 517 260 550 minecraft:black_concrete
fill 521 255 510 521 260 510 minecraft:black_concrete
fill 531 255 552 531 260 552 minecraft:black_concrete
setblock 535 255 552 minecraft:shroomlight
fill 536 255 552 536 307 552 minecraft:black_concrete
fill 537 255 510 537 260 510 minecraft:black_concrete
fill 547 255 552 547 260 552 minecraft:black_concrete
setblock 551 255 510 minecraft:white_concrete
fill 553 255 510 553 260 510 minecraft:black_concrete
fill 559 255 520 559 260 520 minecraft:black_concrete
fill 559 255 531 559 307 531 minecraft:black_concrete
setblock 559 255 532 minecraft:white_concrete
fill 559 255 533 559 285 534 minecraft:black_concrete
fill 559 255 536 559 260 536 minecraft:black_concrete
fill 535 256 552 535 307 552 minecraft:black_concrete
fill 548 256 552 548 270 552 minecraft:black_concrete
setblock 549 256 552 minecraft:white_concrete
fill 551 256 510 551 276 510 minecraft:black_concrete
fill 559 256 532 559 307 532 minecraft:black_concrete
fill 549 257 552 549 307 552 minecraft:black_concrete
fill 541 258 521 541 259 521 minecraft:magma_block
setblock 538 259 552 minecraft:magma_block
fill 539 259 552 539 299 552 minecraft:black_concrete
fill 545 259 516 545 260 516 minecraft:blackstone
fill 559 259 537 559 280 537 minecraft:black_concrete
setblock 559 259 538 minecraft:shroomlight
fill 538 260 552 538 304 552 minecraft:black_concrete
setblock 559 260 512 minecraft:magma_block
fill 559 260 538 559 279 538 minecraft:black_concrete
fill 517 261 518 517 263 518 minecraft:orange_concrete
fill 517 261 534 517 263 534 minecraft:orange_concrete
setblock 517 261 549 minecraft:magma_block
fill 517 261 550 517 263 550 minecraft:orange_concrete
setblock 520 261 513 minecraft:light[level=14]
setblock 520 261 521 minecraft:light[level=14]
setblock 520 261 529 minecraft:light[level=14]
setblock 520 261 537 minecraft:light[level=14]
setblock 520 261 545 minecraft:light[level=14]
fill 521 261 510 521 263 510 minecraft:orange_concrete
setblock 528 261 513 minecraft:light[level=14]
setblock 528 261 521 minecraft:light[level=14]
setblock 528 261 529 minecraft:light[level=14]
setblock 528 261 537 minecraft:light[level=14]
setblock 528 261 545 minecraft:light[level=14]
fill 531 261 552 531 263 552 minecraft:orange_concrete
setblock 533 261 552 minecraft:shroomlight
fill 534 261 552 534 306 552 minecraft:black_concrete
setblock 536 261 513 minecraft:light[level=14]
setblock 536 261 521 minecraft:light[level=14]
setblock 536 261 529 minecraft:light[level=14]
setblock 536 261 537 minecraft:light[level=14]
setblock 536 261 545 minecraft:light[level=14]
fill 537 261 510 537 263 510 minecraft:orange_concrete
setblock 544 261 513 minecraft:light[level=14]
setblock 544 261 521 minecraft:light[level=14]
setblock 544 261 529 minecraft:light[level=14]
setblock 544 261 537 minecraft:light[level=14]
setblock 544 261 545 minecraft:light[level=14]
fill 545 261 523 546 262 523 minecraft:blue_concrete
fill 547 261 552 547 263 552 minecraft:orange_concrete
setblock 552 261 513 minecraft:light[level=14]
setblock 552 261 521 minecraft:light[level=14]
setblock 552 261 529 minecraft:light[level=14]
setblock 552 261 537 minecraft:light[level=14]
setblock 552 261 545 minecraft:light[level=14]
fill 553 261 510 553 263 510 minecraft:orange_concrete
fill 554 261 535 556 262 535 minecraft:blue_concrete
fill 555 261 534 555 262 534 minecraft:blue_concrete
fill 555 261 536 555 262 536 minecraft:blue_concrete
fill 559 261 512 559 307 512 minecraft:black_concrete
fill 559 261 520 559 263 520 minecraft:orange_concrete
fill 559 261 536 559 263 536 minecraft:orange_concrete
setblock 559 261 541 minecraft:magma_block
setblock 517 262 538 minecraft:shroomlight
fill 517 262 544 517 262 547 minecraft:black_concrete
setblock 517 262 548 minecraft:shroomlight
fill 517 262 549 517 294 549 minecraft:black_concrete
setblock 532 262 552 minecraft:shroomlight
fill 533 262 552 533 296 552 minecraft:black_concrete
setblock 542 262 510 minecraft:white_concrete
setblock 558 262 510 minecraft:shroomlight
fill 559 262 541 559 275 541 minecraft:black_concrete
fill 517 263 538 517 307 538 minecraft:black_concrete
fill 517 263 544 517 265 546 minecraft:black_concrete
setblock 517 263 547 minecraft:white_concrete
fill 517 263 548 517 307 548 minecraft:black_concrete
fill 532 263 552 532 307 552 minecraft:black_concrete
fill 542 263 510 542 292 510 minecraft:black_concrete
fill 558 263 510 558 299 510 minecraft:black_concrete
setblock 517 264 518 minecraft:black_concrete
fill 517 264 534 517 269 534 minecraft:black_concrete
setblock 517 264 547 minecraft:magma_block
fill 517 264 550 517 269 550 minecraft:black_concrete
fill 521 264 510 521 269 510 minecraft:black_concrete
setblock 524 264 510 minecraft:magma_block
fill 531 264 552 531 269 552 minecraft:black_concrete
fill 537 264 510 537 269 510 minecraft:black_concrete
fill 541 264 552 542 280 552 minecraft:black_concrete
setblock 543 264 552 minecraft:magma_block
fill 545 264 552 545 307 552 minecraft:black_concrete
setblock 546 264 552 minecraft:magma_block
fill 547 264 552 547 269 552 minecraft:black_concrete
fill 553 264 510 553 269 510 minecraft:black_concrete
fill 559 264 520 559 269 520 minecraft:black_concrete
fill 559 264 536 559 269 536 minecraft:black_concrete
setblock 517 265 518 minecraft:magma_block
fill 517 265 547 517 307 547 minecraft:black_concrete
fill 524 265 510 524 307 510 minecraft:black_concrete
fill 543 265 552 543 282 552 minecraft:black_concrete
fill 546 265 552 546 307 552 minecraft:black_concrete
setblock 559 265 513 minecraft:white_concrete
setblock 559 265 519 minecraft:shroomlight
fill 517 266 518 517 269 518 minecraft:black_concrete
fill 517 266 544 517 307 544 minecraft:black_concrete
setblock 517 266 545 minecraft:white_concrete
fill 517 266 546 517 307 546 minecraft:black_concrete
fill 559 266 513 559 307 513 minecraft:black_concrete
fill 559 266 519 559 307 519 minecraft:black_concrete
fill 517 267 545 517 307 545 minecraft:black_concrete
setblock 527 267 552 minecraft:magma_block
fill 531 267 510 532 281 510 minecraft:black_concrete
setblock 533 267 510 minecraft:magma_block
fill 534 267 510 536 282 510 minecraft:black_concrete
setblock 559 267 521 minecraft:shroomlight
setblock 517 268 529 minecraft:white_concrete
setblock 523 268 510 minecraft:shroomlight
fill 527 268 552 527 307 552 minecraft:black_concrete
fill 528 268 532 528 269 533 minecraft:blue_concrete
fill 533 268 510 533 307 510 minecraft:black_concrete
fill 559 268 521 559 307 521 minecraft:black_concrete
setblock 559 268 530 minecraft:white_concrete
setblock 517 269 513 minecraft:shroomlight
fill 517 269 529 517 307 529 minecraft:black_concrete
setblock 520 269 513 minecraft:light[level=14]
setblock 520 269 521 minecraft:light[level=14]
setblock 520 269 529 minecraft:light[level=14]
setblock 520 269 537 minecraft:light[level=14]
setblock 520 269 545 minecraft:light[level=14]
fill 523 269 510 523 307 510 minecraft:black_concrete
setblock 528 269 513 minecraft:light[level=14]
setblock 528 269 521 minecraft:light[level=14]
setblock 528 269 529 minecraft:light[level=14]
setblock 528 269 537 minecraft:light[level=14]
setblock 528 269 545 minecraft:light[level=14]
setblock 536 269 513 minecraft:light[level=14]
setblock 536 269 521 minecraft:light[level=14]
setblock 536 269 529 minecraft:light[level=14]
setblock 536 269 537 minecraft:light[level=14]
setblock 536 269 545 minecraft:light[level=14]
setblock 544 269 513 minecraft:light[level=14]
setblock 544 269 521 minecraft:light[level=14]
setblock 544 269 529 minecraft:light[level=14]
setblock 544 269 537 minecraft:light[level=14]
setblock 544 269 545 minecraft:light[level=14]
setblock 546 269 510 minecraft:white_concrete
setblock 552 269 513 minecraft:light[level=14]
setblock 552 269 521 minecraft:light[level=14]
setblock 552 269 529 minecraft:light[level=14]
setblock 552 269 537 minecraft:light[level=14]
setblock 552 269 545 minecraft:light[level=14]
fill 559 269 530 559 276 530 minecraft:black_concrete
fill 517 270 513 517 274 513 minecraft:black_concrete
fill 517 270 518 517 272 518 minecraft:orange_concrete
fill 517 270 533 517 271 533 minecraft:white_concrete
fill 517 270 534 517 272 534 minecraft:orange_concrete
fill 517 270 550 517 272 550 minecraft:orange_concrete
fill 521 270 510 521 272 510 minecraft:orange_concrete
setblock 528 270 510 minecraft:magma_block
fill 529 270 510 529 307 510 minecraft:black_concrete
fill 531 270 552 531 272 552 minecraft:orange_concrete
fill 537 270 510 537 272 510 minecraft:orange_concrete
fill 546 270 510 546 296 510 minecraft:black_concrete
fill 547 270 552 547 272 552 minecraft:orange_concrete
setblock 551 270 552 minecraft:white_concrete
fill 553 270 510 553 272 510 minecraft:orange_concrete
fill 559 270 520 559 272 520 minecraft:orange_concrete
fill 559 270 536 559 272 536 minecraft:orange_concrete
fill 528 271 510 528 307 510 minecraft:black_concrete
setblock 548 271 552 minecraft:shroomlight
fill 551 271 552 551 307 552 minecraft:black_concrete
fill 517 272 521 517 282 523 minecraft:black_concrete
setblock 517 272 524 minecraft:white_concrete
fill 517 272 533 517 307 533 minecraft:black_concrete
fill 521 272 526 521 273 527 minecraft:blackstone
fill 535 272 530 539 272 530 minecraft:orange_terracotta
setblock 535 272 533 minecraft:orange_terracotta
fill 536 272 529 538 272 529 minecraft:orange_terracotta
fill 536 272 534 538 272 534 minecraft:orange_terracotta
fill 537 272 531 539 272 531 minecraft:orange_terracotta
fill 537 272 533 539 272 533 minecraft:orange_terracotta
fill 538 272 532 539 272 532 minecraft:orange_terracotta
fill 548 272 552 548 307 552 minecraft:black_concrete
fill 517 273 518 517 287 518 minecraft:black_concrete
fill 517 273 524 517 307 524 minecraft:black_concrete
setblock 517 273 525 minecraft:white_concrete
fill 517 273 534 517 277 534 minecraft:black_concrete
fill 517 273 550 517 287 550 minecraft:black_concrete
fill 521 273 510 521 287 510 minecraft:black_concrete
fill 531 273 552 531 287 552 minecraft:black_concrete
fill 533 273 530 534 273 533 minecraft:orange_terracotta
fill 534 273 528 535 273 529 minecraft:orange_terracotta
fill 534 273 534 535 273 535 minecraft:orange_terracotta
fill 535 273 530 539 277 530 minecraft:red_terracotta
fill 535 273 533 535 277 533 minecraft:red_terracotta
fill 536 273 527 538 273 528 minecraft:orange_terracotta
fill 536 273 529 538 279 529 minecraft:red_terracotta
fill 536 273 534 538 277 534 minecraft:red_terracotta
fill 536 273 535 538 273 536 minecraft:orange_terracotta
fill 537 273 510 537 274 510 minecraft:black_concrete
fill 537 273 531 539 277 531 minecraft:red_terracotta
fill 537 273 533 539 277 533 minecraft:red_terracotta
fill 538 273 532 539 277 532 minecraft:red_terracotta
fill 539 273 528 540 273 529 minecraft:orange_terracotta
fill 539 273 534 540 273 535 minecraft:orange_terracotta
fill 540 273 530 541 273 533 minecraft:orange_terracotta
fill 547 273 552 547 287 552 minecraft:black_concrete
fill 553 273 510 553 287 510 minecraft:black_concrete
fill 559 273 520 559 287 520 minecraft:black_concrete
fill 559 273 536 559 287 536 minecraft:black_concrete
fill 517 274 525 517 289 525 minecraft:black_concrete
fill 532 274 529 532 274 534 minecraft:orange_terracotta
fill 533 274 528 533 274 529 minecraft:orange_terracotta
fill 533 274 530 534 277 533 minecraft:red_terracotta
fill 533 274 534 533 274 535 minecraft:orange_terracotta
fill 534 274 527 535 274 527 minecraft:orange_terracotta
fill 534 274 528 535 279 529 minecraft:red_terracotta
fill 534 274 534 535 279 535 minecraft:red_terracotta
fill 534 274 536 535 274 536 minecraft:orange_terracotta
fill 536 274 526 538 274 526 minecraft:orange_terracotta
fill 536 274 527 538 285 528 minecraft:red_terracotta
fill 536 274 535 538 279 536 minecraft:red_terracotta
fill 536 274 537 538 274 537 minecraft:orange_terracotta
fill 539 274 527 540 274 527 minecraft:orange_terracotta
fill 539 274 528 540 285 529 minecraft:red_terracotta
fill 539 274 534 540 285 535 minecraft:red_terracotta
fill 539 274 536 540 274 536 minecraft:orange_terracotta
fill 540 274 530 541 285 533 minecraft:red_terracotta
fill 541 274 528 541 274 529 minecraft:orange_terracotta
fill 541 274 534 541 274 535 minecraft:orange_terracotta
fill 542 274 529 542 274 534 minecraft:orange_terracotta
setblock 517 275 513 minecraft:shroomlight
fill 531 275 529 531 275 534 minecraft:orange_terracotta
setblock 532 275 528 minecraft:orange_terracotta
fill 532 275 529 532 284 534 minecraft:red_terracotta
setblock 532 275 535 minecraft:orange_terracotta
setblock 533 275 527 minecraft:orange_terracotta
fill 533 275 528 533 284 529 minecraft:red_terracotta
fill 533 275 534 533 284 535 minecraft:red_terracotta
setblock 533 275 536 minecraft:orange_terracotta
fill 534 275 526 535 275 526 minecraft:orange_terracotta
fill 534 275 527 535 284 527 minecraft:red_terracotta
fill 534 275 536 535 284 536 minecraft:red_terracotta
fill 534 275 537 535 275 537 minecraft:orange_terracotta
fill 536 275 525 538 276 525 minecraft:orange_terracotta
fill 536 275 526 538 284 526 minecraft:red_terracotta
fill 536 275 537 538 284 537 minecraft:red_terracotta
fill 536 275 538 538 276 538 minecraft:orange_terracotta
setblock 537 275 510 minecraft:white_concrete
fill 539 275 526 540 275 526 minecraft:orange_terracotta
fill 539 275 527 540 284 527 minecraft:red_terracotta
fill 539 275 536 540 284 536 minecraft:red_terracotta
fill 539 275 537 540 275 537 minecraft:orange_terracotta
setblock 541 275 527 minecraft:orange_terracotta
fill 541 275 528 541 284 529 minecraft:red_terracotta
fill 541 275 534 541 284 535 minecraft:red_terracotta
setblock 541 275 536 minecraft:orange_terracotta
setblock 542 275 528 minecraft:orange_terracotta
fill 542 275 529 542 284 534 minecraft:red_terracotta
setblock 542 275 535 minecraft:orange_terracotta
fill 543 275 529 543 275 534 minecraft:orange_terracotta
setblock 559 275 539 minecraft:white_concrete
fill 517 276 513 517 307 513 minecraft:black_concrete
fill 530 276 530 530 283 533 minecraft:orange_terracotta
fill 531 276 528 531 276 529 minecraft:orange_terracotta
fill 531 276 530 531 283 533 minecraft:red_terracotta
fill 531 276 534 531 276 535 minecraft:orange_terracotta
setblock 532 276 527 minecraft:orange_terracotta
fill 532 276 528 532 283 528 minecraft:red_terracotta
fill 532 276 535 532 283 535 minecraft:red_terracotta
setblock 532 276 536 minecraft:orange_terracotta
fill 533 276 526 533 277 526 minecraft:orange_terracotta
fill 533 276 527 533 283 527 minecraft:red_terracotta
fill 533 276 536 533 283 536 minecraft:red_terracotta
fill 533 276 537 533 277 537 minecraft:orange_terracotta
fill 534 276 525 535 277 525 minecraft:orange_terracotta
fill 534 276 526 535 283 526 minecraft:red_terracotta
fill 534 276 537 535 283 537 minecraft:red_terracotta
fill 534 276 538 535 277 538 minecraft:orange_terracotta
fill 537 276 510 537 287 510 minecraft:black_concrete
fill 539 276 525 540 277 525 minecraft:orange_terracotta
fill 539 276 526 540 283 526 minecraft:red_terracotta
fill 539 276 537 540 283 537 minecraft:red_terracotta
fill 539 276 538 540 277 538 minecraft:orange_terracotta
fill 541 276 526 541 277 526 minecraft:orange_terracotta
fill 541 276 527 541 283 527 minecraft:red_terracotta
fill 541 276 536 541 283 536 minecraft:red_terracotta
fill 541 276 537 541 277 537 minecraft:orange_terracotta
setblock 542 276 527 minecraft:orange_terracotta
fill 542 276 528 542 283 528 minecraft:red_terracotta
fill 542 276 535 542 283 535 minecraft:red_terracotta
setblock 542 276 536 minecraft:orange_terracotta
setblock 543 276 510 minecraft:magma_block
fill 543 276 528 543 276 529 minecraft:orange_terracotta
fill 543 276 530 543 283 533 minecraft:red_terracotta
fill 543 276 534 543 276 535 minecraft:orange_terracotta
fill 544 276 530 544 283 533 minecraft:orange_terracotta
fill 559 276 539 559 293 539 minecraft:black_concrete
setblock 559 276 541 minecraft:white_concrete
setblock 517 277 543 minecraft:magma_block
setblock 520 277 513 minecraft:light[level=14]
setblock 520 277 521 minecraft:light[level=14]
setblock 520 277 529 minecraft:light[level=14]
setblock 520 277 537 minecraft:light[level=14]
setblock 520 277 545 minecraft:light[level=14]
setblock 528 277 513 minecraft:light[level=14]
setblock 528 277 521 minecraft:light[level=14]
setblock 528 277 529 minecraft:light[level=14]
setblock 528 277 537 minecraft:light[level=14]
setblock 528 277 545 minecraft:light[level=14]
fill 530 277 529 530 282 529 minecraft:orange_terracotta
fill 530 277 534 530 282 534 minecraft:orange_terracotta
fill 531 277 527 531 277 528 minecraft:orange_terracotta
fill 531 277 529 531 282 529 minecraft:red_terracotta
fill 531 277 534 531 282 534 minecraft:red_terracotta
fill 531 277 535 531 277 536 minecraft:orange_terracotta
fill 532 277 526 532 282 526 minecraft:orange_terracotta
fill 532 277 527 532 282 527 minecraft:red_terracotta
fill 532 277 536 532 282 536 minecraft:red_terracotta
fill 532 277 537 532 282 537 minecraft:orange_terracotta
setblock 535 277 531 minecraft:red_terracotta
setblock 536 277 513 minecraft:light[level=14]
setblock 536 277 521 minecraft:light[level=14]
fill 536 277 524 538 282 524 minecraft:orange_terracotta
fill 536 277 525 538 282 525 minecraft:red_terracotta
fill 536 277 538 538 282 538 minecraft:red_terracotta
fill 536 277 539 538 282 539 minecraft:orange_terracotta
setblock 536 277 545 minecraft:light[level=14]
fill 538 277 510 538 307 510 minecraft:black_concrete
setblock 539 277 510 minecraft:shroomlight
fill 540 277 510 540 307 510 minecraft:black_concrete
fill 542 277 526 542 282 526 minecraft:orange_terracotta
fill 542 277 527 542 282 527 minecraft:red_terracotta
fill 542 277 536 542 282 536 minecraft:red_terracotta
fill 542 277 537 542 282 537 minecraft:orange_terracotta
fill 543 277 510 543 307 510 minecraft:black_concrete
fill 543 277 527 543 277 528 minecraft:orange_terracotta
fill 543 277 529 543 282 529 minecraft:red_terracotta
fill 543 277 534 543 282 534 minecraft:red_terracotta
fill 543 277 535 543 277 536 minecraft:orange_terracotta
setblock 544 277 513 minecraft:light[level=14]
setblock 544 277 521 minecraft:light[level=14]
fill 544 277 529 544 282 529 minecraft:orange_terracotta
fill 544 277 534 544 282 534 minecraft:orange_terracotta
setblock 544 277 537 minecraft:light[level=14]
setblock 544 277 545 minecraft:light[level=14]
setblock 551 277 510 minecraft:white_concrete
setblock 552 277 513 minecraft:light[level=14]
setblock 552 277 521 minecraft:light[level=14]
setblock 552 277 529 minecraft:light[level=14]
setblock 552 277 537 minecraft:light[level=14]
setblock 552 277 545 minecraft:light[level=14]
setblock 559 277 530 minecraft:shroomlight
fill 559 277 541 559 295 541 minecraft:black_concrete
setblock 517 278 530 minecraft:magma_block
setblock 517 278 534 minecraft:magma_block
fill 517 278 543 517 307 543 minecraft:black_concrete
setblock 527 278 510 minecraft:shroomlight
fill 530 278 528 530 281 528 minecraft:orange_terracotta
fill 530 278 535 530 281 535 minecraft:orange_terracotta
fill 531 278 527 531 282 527 minecraft:orange_terracotta
fill 531 278 528 531 281 528 minecraft:red_terracotta
fill 531 278 535 531 281 535 minecraft:red_terracotta
fill 531 278 536 531 282 536 minecraft:orange_terracotta
fill 533 278 525 534 281 525 minecraft:orange_terracotta
fill 533 278 526 533 281 526 minecraft:red_terracotta
fill 533 278 530 533 279 533 minecraft:red_terracotta
fill 533 278 537 533 281 537 minecraft:red_terracotta
fill 533 278 538 534 281 538 minecraft:orange_terracotta
fill 534 278 530 534 279 531 minecraft:red_terracotta
fill 534 278 533 534 279 533 minecraft:red_terracotta
fill 535 278 524 535 281 524 minecraft:orange_terracotta
fill 535 278 525 535 281 525 minecraft:red_terracotta
fill 535 278 530 535 279 530 minecraft:red_terracotta
fill 535 278 538 535 281 538 minecraft:red_terracotta
fill 535 278 539 535 281 539 minecraft:orange_terracotta
fill 537 278 530 539 279 530 minecraft:red_terracotta
fill 537 278 534 538 279 534 minecraft:red_terracotta
fill 538 278 531 539 279 531 minecraft:red_terracotta
fill 538 278 533 539 279 533 minecraft:red_terracotta
fill 539 278 510 539 293 510 minecraft:black_concrete
fill 539 278 524 539 281 524 minecraft:orange_terracotta
fill 539 278 525 539 281 525 minecraft:red_terracotta
fill 539 278 532 539 279 532 minecraft:red_terracotta
fill 539 278 538 539 281 538 minecraft:red_terracotta
fill 539 278 539 539 281 539 minecraft:orange_terracotta
fill 540 278 525 541 281 525 minecraft:orange_terracotta
fill 540 278 538 541 281 538 minecraft:orange_terracotta
fill 541 278 526 541 281 526 minecraft:red_terracotta
fill 541 278 537 541 281 537 minecraft:red_terracotta
fill 543 278 527 543 282 527 minecraft:orange_terracotta
fill 543 278 528 543 281 528 minecraft:red_terracotta
fill 543 278 535 543 281 535 minecraft:red_terracotta
fill 543 278 536 543 282 536 minecraft:orange_terracotta
fill 544 278 528 544 281 528 minecraft:orange_terracotta
fill 544 278 535 544 281 535 minecraft:orange_terracotta
fill 551 278 510 551 295 510 minecraft:black_concrete
fill 559 278 530 559 307 530 minecraft:black_concrete
fill 517 279 530 517 307 530 minecraft:black_concrete
fill 517 279 534 517 287 534 minecraft:black_concrete
setblock 525 279 552 minecraft:magma_block
fill 527 279 510 527 307 510 minecraft:black_concrete
setblock 517 280 526 minecraft:white_concrete
fill 518 280 511 529 280 551 minecraft:black_concrete
fill 521 280 552 521 307 552 minecraft:black_concrete
setblock 522 280 552 minecraft:magma_block
fill 525 280 552 525 307 552 minecraft:black_concrete
fill 530 280 511 530 280 527 minecraft:black_concrete
fill 530 280 536 530 280 551 minecraft:black_concrete
fill 531 280 511 531 280 526 minecraft:black_concrete
fill 531 280 537 531 280 551 minecraft:black_concrete
fill 532 280 511 532 280 525 minecraft:black_concrete
fill 532 280 538 532 280 551 minecraft:black_concrete
fill 533 280 511 534 280 524 minecraft:black_concrete
fill 533 280 530 533 285 530 minecraft:red_terracotta
fill 533 280 531 533 280 533 minecraft:shroomlight
fill 533 280 539 534 280 551 minecraft:black_concrete
fill 534 280 528 534 285 529 minecraft:red_terracotta
fill 534 280 530 534 280 531 minecraft:shroomlight
fill 534 280 533 534 280 534 minecraft:shroomlight
fill 534 280 535 534 285 535 minecraft:red_terracotta
fill 535 280 511 558 280 523 minecraft:black_concrete
fill 535 280 528 535 285 528 minecraft:red_terracotta
fill 535 280 529 535 280 530 minecraft:shroomlight
fill 535 280 534 535 280 535 minecraft:shroomlight
fill 535 280 540 558 280 551 minecraft:black_concrete
fill 536 280 529 537 280 529 minecraft:shroomlight
fill 536 280 535 537 280 535 minecraft:shroomlight
fill 536 280 536 538 285 536 minecraft:red_terracotta
fill 537 280 530 538 280 530 minecraft:shroomlight
fill 537 280 534 538 280 534 minecraft:shroomlight
fill 538 280 529 538 286 529 minecraft:red_terracotta
fill 538 280 531 539 280 531 minecraft:shroomlight
fill 538 280 533 539 280 533 minecraft:shroomlight
fill 538 280 535 538 285 535 minecraft:red_terracotta
fill 539 280 530 539 286 530 minecraft:red_terracotta
setblock 539 280 532 minecraft:shroomlight
fill 540 280 524 558 280 524 minecraft:black_concrete
fill 540 280 539 558 280 539 minecraft:black_concrete
fill 542 280 525 558 280 525 minecraft:black_concrete
fill 542 280 538 558 280 538 minecraft:black_concrete
fill 543 280 526 558 280 526 minecraft:black_concrete
fill 543 280 537 558 280 537 minecraft:black_concrete
fill 544 280 527 558 280 527 minecraft:black_concrete
fill 544 280 536 558 280 536 minecraft:black_concrete
fill 545 280 528 558 280 535 minecraft:black_concrete
setblock 559 280 538 minecraft:shroomlight
fill 517 281 526 517 288 526 minecraft:black_concrete
fill 522 281 552 522 307 552 minecraft:black_concrete
setblock 530 281 510 minecraft:magma_block
fill 533 281 531 533 285 533 minecraft:red_terracotta
fill 534 281 530 534 285 531 minecraft:red_terracotta
fill 534 281 533 534 285 534 minecraft:red_terracotta
fill 535 281 529 535 285 530 minecraft:red_terracotta
fill 535 281 534 535 285 535 minecraft:red_terracotta
fill 536 281 529 537 286 529 minecraft:red_terracotta
fill 536 281 535 537 285 535 minecraft:red_terracotta
fill 537 281 530 538 286 530 minecraft:red_terracotta
fill 537 281 534 538 286 534 minecraft:red_terracotta
fill 538 281 531 539 286 531 minecraft:red_terracotta
fill 538 281 533 539 286 533 minecraft:red_terracotta
fill 539 281 532 539 286 532 minecraft:red_terracotta
setblock 541 281 552 minecraft:shroomlight
fill 542 281 552 542 307 552 minecraft:black_concrete
setblock 559 281 537 minecraft:shroomlight
fill 559 281 538 559 299 538 minecraft:black_concrete
fill 530 282 510 530 307 510 minecraft:black_concrete
setblock 531 282 510 minecraft:magma_block
fill 531 282 528 531 283 528 minecraft:orange_terracotta
fill 531 282 535 531 283 535 minecraft:orange_terracotta
fill 532 282 510 532 307 510 minecraft:black_concrete
fill 533 282 526 533 283 526 minecraft:orange_terracotta
fill 533 282 537 533 283 537 minecraft:orange_terracotta
fill 534 282 525 535 283 525 minecraft:orange_terracotta
fill 534 282 538 535 283 538 minecraft:orange_terracotta
fill 539 282 525 540 283 525 minecraft:orange_terracotta
fill 539 282 538 540 283 538 minecraft:orange_terracotta
fill 541 282 526 541 283 526 minecraft:orange_terracotta
fill 541 282 537 541 283 537 minecraft:orange_terracotta
fill 541 282 552 541 292 552 minecraft:black_concrete
fill 543 282 528 543 283 528 minecraft:orange_terracotta
fill 543 282 535 543 283 535 minecraft:orange_terracotta
fill 559 282 537 559 307 537 minecraft:black_concrete
setblock 559 282 546 minecraft:magma_block
fill 559 282 547 559 297 548 minecraft:black_concrete
fill 517 283 510 517 307 510 minecraft:black_concrete
setblock 517 283 521 minecraft:shroomlight
fill 517 283 522 517 307 523 minecraft:black_concrete
setblock 518 283 510 minecraft:magma_block
fill 519 283 510 519 307 510 minecraft:black_concrete
setblock 522 283 510 minecraft:magma_block
fill 531 283 510 531 307 510 minecraft:black_concrete
fill 531 283 529 531 284 529 minecraft:orange_terracotta
fill 531 283 534 531 284 534 minecraft:orange_terracotta
setblock 532 283 527 minecraft:orange_terracotta
setblock 532 283 536 minecraft:orange_terracotta
fill 534 283 510 534 307 510 minecraft:black_concrete
fill 534 283 532 534 285 532 minecraft:red_terracotta
setblock 535 283 510 minecraft:shroomlight
fill 535 283 531 535 286 531 minecraft:red_terracotta
fill 535 283 533 535 286 533 minecraft:red_terracotta
fill 536 283 510 536 307 510 minecraft:black_concrete
fill 536 283 525 538 284 525 minecraft:orange_terracotta
fill 536 283 530 536 286 530 minecraft:red_terracotta
fill 536 283 534 536 286 534 minecraft:red_terracotta
fill 536 283 538 538 284 538 minecraft:orange_terracotta
fill 537 283 531 537 286 531 minecraft:red_terracotta
fill 537 283 533 537 286 533 minecraft:red_terracotta
fill 538 283 532 538 286 532 minecraft:red_terracotta
setblock 542 283 527 minecraft:orange_terracotta
setblock 542 283 536 minecraft:orange_terracotta
fill 543 283 529 543 284 529 minecraft:orange_terracotta
fill 543 283 534 543 284 534 minecraft:orange_terracotta
setblock 543 283 552 minecraft:shroomlight
fill 559 283 546 559 285 546 minecraft:black_concrete
fill 517 284 521 517 307 521 minecraft:black_concrete
fill 518 284 510 518 307 510 minecraft:black_concrete
fill 522 284 510 522 305 510 minecraft:black_concrete
fill 527 284 534 527 285 535 minecraft:blackstone
fill 531 284 530 531 284 533 minecraft:orange_terracotta
fill 532 284 520 532 285 521 minecraft:blue_concrete
setblock 532 284 528 minecraft:orange_terracotta
setblock 532 284 535 minecraft:orange_terracotta
setblock 533 284 527 minecraft:orange_terracotta
setblock 533 284 536 minecraft:orange_terracotta
fill 534 284 526 535 284 526 minecraft:orange_terracotta
fill 534 284 537 535 284 537 minecraft:orange_terracotta
fill 535 284 510 535 307 510 minecraft:black_concrete
fill 539 284 526 540 284 526 minecraft:orange_terracotta
fill 539 284 537 540 284 537 minecraft:orange_terracotta
setblock 541 284 527 minecraft:orange_terracotta
setblock 541 284 536 minecraft:orange_terracotta
setblock 542 284 528 minecraft:orange_terracotta
setblock 542 284 535 minecraft:orange_terracotta
fill 543 284 530 543 284 533 minecraft:orange_terracotta
fill 543 284 552 543 307 552 minecraft:black_concrete
setblock 520 285 513 minecraft:light[level=14]
setblock 520 285 521 minecraft:light[level=14]
setblock 520 285 529 minecraft:light[level=14]
setblock 520 285 537 minecraft:light[level=14]
setblock 520 285 545 minecraft:light[level=14]
setblock 528 285 513 minecraft:light[level=14]
setblock 528 285 521 minecraft:light[level=14]
setblock 528 285 529 minecraft:light[level=14]
setblock 528 285 537 minecraft:light[level=14]
setblock 528 285 545 minecraft:light[level=14]
fill 532 285 529 532 285 534 minecraft:orange_terracotta
fill 533 285 528 533 285 529 minecraft:orange_terracotta
fill 533 285 534 533 285 535 minecraft:orange_terracotta
fill 534 285 527 535 285 527 minecraft:orange_terracotta
fill 534 285 536 535 285 536 minecraft:orange_terracotta
setblock 536 285 513 minecraft:light[level=14]
setblock 536 285 521 minecraft:light[level=14]
fill 536 285 526 538 285 526 minecraft:orange_terracotta
fill 536 285 537 538 285 537 minecraft:orange_terracotta
setblock 536 285 545 minecraft:light[level=14]
fill 539 285 527 540 285 527 minecraft:orange_terracotta
fill 539 285 536 540 285 536 minecraft:orange_terracotta
fill 541 285 528 541 285 529 minecraft:orange_terracotta
fill 541 285 534 541 285 535 minecraft:orange_terracotta
fill 542 285 529 542 285 534 minecraft:orange_terracotta
setblock 544 285 513 minecraft:light[level=14]
setblock 544 285 521 minecraft:light[level=14]
setblock 544 285 529 minecraft:light[level=14]
setblock 544 285 537 minecraft:light[level=14]
setblock 544 285 545 minecraft:light[level=14]
fill 545 285 525 545 286 526 minecraft:blue_concrete
setblock 552 285 513 minecraft:light[level=14]
setblock 552 285 521 minecraft:light[level=14]
setblock 552 285 529 minecraft:light[level=14]
setblock 552 285 537 minecraft:light[level=14]
setblock 552 285 545 minecraft:light[level=14]
setblock 525 286 510 minecraft:shroomlight
fill 533 286 530 534 286 533 minecraft:orange_terracotta
fill 534 286 528 535 286 529 minecraft:orange_terracotta
fill 534 286 534 535 286 535 minecraft:orange_terracotta
setblock 535 286 530 minecraft:red_terracotta
fill 536 286 527 538 286 528 minecraft:orange_terracotta
fill 536 286 535 538 286 536 minecraft:orange_terracotta
fill 539 286 528 540 286 529 minecraft:orange_terracotta
fill 539 286 534 540 286 535 minecraft:orange_terracotta
fill 540 286 530 541 286 533 minecraft:orange_terracotta
setblock 544 286 510 minecraft:shroomlight
fill 550 286 526 550 287 526 minecraft:magma_block
setblock 559 286 533 minecraft:shroomlight
fill 559 286 534 559 307 534 minecraft:black_concrete
setblock 559 286 546 minecraft:magma_block
setblock 559 286 549 minecraft:shroomlight
fill 559 286 550 559 294 550 minecraft:black_concrete
fill 525 287 510 525 307 510 minecraft:black_concrete
fill 535 287 530 535 287 531 minecraft:orange_terracotta
setblock 535 287 533 minecraft:orange_terracotta
fill 536 287 529 538 287 530 minecraft:orange_terracotta
fill 536 287 534 538 287 534 minecraft:orange_terracotta
fill 537 287 531 539 287 531 minecraft:orange_terracotta
fill 537 287 533 539 287 533 minecraft:orange_terracotta
fill 538 287 532 539 287 532 minecraft:orange_terracotta
setblock 539 287 530 minecraft:orange_terracotta
fill 544 287 510 544 307 510 minecraft:black_concrete
fill 559 287 533 559 307 533 minecraft:black_concrete
fill 559 287 546 559 295 546 minecraft:black_concrete
fill 559 287 549 559 307 549 minecraft:black_concrete
fill 517 288 518 517 290 518 minecraft:orange_concrete
fill 517 288 534 517 290 534 minecraft:orange_concrete
fill 517 288 550 517 290 550 minecraft:orange_concrete
fill 521 288 510 521 290 510 minecraft:orange_concrete
fill 522 288 537 526 295 537 minecraft:yellow_concrete
fill 523 288 536 526 295 536 minecraft:yellow_concrete
fill 523 288 538 525 295 539 minecraft:yellow_concrete
fill 524 288 535 524 295 535 minecraft:yellow_concrete
fill 526 288 538 526 295 538 minecraft:yellow_concrete
fill 531 288 552 531 290 552 minecraft:orange_concrete
fill 537 288 510 537 290 510 minecraft:orange_concrete
fill 547 288 552 547 290 552 minecraft:orange_concrete
fill 550 288 526 550 296 526 minecraft:blackstone
fill 553 288 510 553 290 510 minecraft:orange_concrete
fill 559 288 520 559 290 520 minecraft:orange_concrete
fill 559 288 536 559 290 536 minecraft:orange_concrete
setblock 517 289 520 minecraft:white_concrete
setblock 517 289 526 minecraft:shroomlight
fill 521 289 537 521 294 538 minecraft:yellow_concrete
fill 522 289 535 522 294 536 minecraft:yellow_concrete
fill 522 289 538 522 294 539 minecraft:yellow_concrete
fill 523 289 535 523 294 535 minecraft:yellow_concrete
fill 523 289 540 526 294 540 minecraft:yellow_concrete
fill 524 289 534 525 294 534 minecraft:yellow_concrete
fill 525 289 535 526 294 535 minecraft:yellow_concrete
fill 526 289 539 527 294 539 minecraft:yellow_concrete
fill 527 289 536 527 294 538 minecraft:yellow_concrete
fill 550 289 527 550 296 527 minecraft:blackstone
fill 551 289 526 551 296 526 minecraft:blackstone
fill 517 290 520 517 301 520 minecraft:black_concrete
setblock 517 290 525 minecraft:shroomlight
fill 517 290 526 517 307 526 minecraft:black_concrete
setblock 517 290 540 minecraft:magma_block
fill 521 290 536 521 293 536 minecraft:yellow_concrete
fill 521 290 539 521 293 539 minecraft:yellow_concrete
fill 522 290 540 522 293 540 minecraft:yellow_concrete
fill 523 290 534 523 293 534 minecraft:yellow_concrete
fill 524 290 541 525 293 541 minecraft:yellow_concrete
fill 526 290 534 526 293 534 minecraft:yellow_concrete
fill 527 290 535 527 293 535 minecraft:yellow_concrete
fill 527 290 540 527 293 540 minecraft:yellow_concrete
fill 528 290 537 528 293 538 minecraft:yellow_concrete
fill 551 290 527 551 296 527 minecraft:blackstone
setblock 559 290 542 minecraft:shroomlight
fill 517 291 518 517 296 518 minecraft:black_concrete
fill 517 291 525 517 307 525 minecraft:black_concrete
fill 517 291 534 517 296 534 minecraft:black_concrete
fill 517 291 540 517 307 540 minecraft:black_concrete
fill 517 291 550 517 296 550 minecraft:black_concrete
fill 521 291 510 521 296 510 minecraft:black_concrete
fill 521 291 535 521 292 535 minecraft:yellow_concrete
fill 522 291 534 522 292 534 minecraft:yellow_concrete
fill 523 291 541 523 292 541 minecraft:yellow_concrete
fill 526 291 541 526 292 541 minecraft:yellow_concrete
fill 528 291 536 528 292 536 minecraft:yellow_concrete
fill 528 291 539 528 292 539 minecraft:yellow_concrete
fill 531 291 552 531 296 552 minecraft:black_concrete
fill 537 291 510 537 296 510 minecraft:black_concrete
setblock 547 291 552 minecraft:black_concrete
fill 548 291 543 549 292 544 minecraft:blackstone
fill 549 291 526 549 296 527 minecraft:blackstone
fill 550 291 525 551 296 525 minecraft:blackstone
fill 550 291 528 551 296 528 minecraft:blackstone
fill 552 291 526 552 296 527 minecraft:blackstone
fill 553 291 510 553 296 510 minecraft:black_concrete
fill 559 291 520 559 294 520 minecraft:black_concrete
fill 559 291 536 559 296 536 minecraft:black_concrete
fill 559 291 542 559 307 542 minecraft:black_concrete
setblock 517 292 542 minecraft:shroomlight
setblock 524 292 552 minecraft:white_concrete
setblock 547 292 552 minecraft:shroomlight
fill 549 292 525 549 296 525 minecraft:blackstone
fill 549 292 528 549 296 528 minecraft:blackstone
fill 552 292 525 552 296 525 minecraft:blackstone
setblock 556 292 552 minecraft:shroomlight
fill 517 293 542 517 307 542 minecraft:black_concrete
setblock 520 293 513 minecraft:light[level=14]
setblock 520 293 521 minecraft:light[level=14]
setblock 520 293 529 minecraft:light[level=14]
setblock 520 293 537 minecraft:light[level=14]
setblock 520 293 545 minecraft:light[level=14]
fill 524 293 552 524 307 552 minecraft:black_concrete
setblock 528 293 513 minecraft:light[level=14]
setblock 528 293 521 minecraft:light[level=14]
setblock 528 293 529 minecraft:light[level=14]
setblock 528 293 545 minecraft:light[level=14]
setblock 536 293 513 minecraft:light[level=14]
setblock 536 293 521 minecraft:light[level=14]
setblock 536 293 529 minecraft:light[level=14]
setblock 536 293 537 minecraft:light[level=14]
setblock 536 293 545 minecraft:light[level=14]
setblock 541 293 552 minecraft:shroomlight
setblock 542 293 510 minecraft:magma_block
setblock 544 293 513 minecraft:light[level=14]
setblock 544 293 521 minecraft:light[level=14]
setblock 544 293 529 minecraft:light[level=14]
setblock 544 293 537 minecraft:light[level=14]
setblock 544 293 545 minecraft:light[level=14]
fill 547 293 552 547 296 552 minecraft:black_concrete
fill 548 293 526 548 296 527 minecraft:blackstone
fill 550 293 524 551 296 524 minecraft:blackstone
fill 550 293 529 551 296 529 minecraft:blackstone
setblock 552 293 513 minecraft:light[level=14]
setblock 552 293 521 minecraft:light[level=14]
fill 552 293 528 552 296 528 minecraft:blackstone
setblock 552 293 529 minecraft:light[level=14]
setblock 552 293 537 minecraft:light[level=14]
setblock 552 293 545 minecraft:light[level=14]
fill 553 293 526 553 296 526 minecraft:blackstone
fill 556 293 552 556 307 552 minecraft:black_concrete
setblock 539 294 510 minecraft:shroomlight
fill 541 294 523 541 295 524 minecraft:blue_concrete
fill 541 294 552 541 307 552 minecraft:black_concrete
fill 542 294 510 542 307 510 minecraft:black_concrete
fill 548 294 525 548 296 525 minecraft:blackstone
fill 548 294 528 548 296 528 minecraft:blackstone
fill 549 294 524 549 296 524 minecraft:blackstone
fill 549 294 529 549 296 529 minecraft:blackstone
fill 552 294 524 552 296 524 minecraft:blackstone
fill 552 294 529 552 296 529 minecraft:blackstone
fill 553 294 525 553 296 525 minecraft:blackstone
fill 553 294 527 553 296 528 minecraft:blackstone
setblock 559 294 539 minecraft:white_concrete
setblock 517 295 549 minecraft:magma_block
fill 539 295 510 539 307 510 minecraft:black_concrete
setblock 547 295 510 minecraft:white_concrete
fill 547 295 525 547 296 527 minecraft:blackstone
fill 548 295 524 548 296 524 minecraft:blackstone
fill 548 295 529 548 296 529 minecraft:blackstone
fill 550 295 523 551 296 523 minecraft:blackstone
fill 550 295 530 551 296 530 minecraft:blackstone
fill 553 295 524 553 296 524 minecraft:blackstone
setblock 554 295 510 minecraft:shroomlight
setblock 559 295 520 minecraft:white_concrete
fill 559 295 539 559 300 539 minecraft:black_concrete
setblock 559 295 550 minecraft:shroomlight
fill 517 296 549 517 307 549 minecraft:black_concrete
fill 534 296 548 534 297 548 minecraft:red_terracotta
fill 547 296 510 547 307 510 minecraft:black_concrete
setblock 547 296 524 minecraft:blackstone
setblock 547 296 528 minecraft:blackstone
fill 549 296 515 550 297 517 minecraft:blackstone
setblock 549 296 523 minecraft:blackstone
setblock 549 296 530 minecraft:blackstone
setblock 551 296 510 minecraft:magma_block
setblock 552 296 523 minecraft:blackstone
setblock 552 296 530 minecraft:blackstone
setblock 553 296 529 minecraft:blackstone
fill 554 296 510 554 307 510 minecraft:black_concrete
fill 554 296 525 554 296 528 minecraft:blackstone
setblock 555 296 552 minecraft:magma_block
setblock 559 296 520 minecraft:black_concrete
setblock 559 296 541 minecraft:white_concrete
setblock 559 296 546 minecraft:shroomlight
fill 559 296 550 559 307 550 minecraft:black_concrete
fill 517 297 518 517 299 518 minecraft:orange_concrete
setblock 517 297 528 minecraft:white_concrete
fill 517 297 534 517 299 534 minecraft:orange_concrete
setblock 517 297 536 minecraft:magma_block
fill 517 297 550 517 299 550 minecraft:orange_concrete
fill 521 297 510 521 299 510 minecraft:orange_concrete
fill 530 297 541 531 298 541 minecraft:magma_block
fill 531 297 552 531 299 552 minecraft:orange_concrete
setblock 533 297 552 minecraft:shroomlight
fill 537 297 510 537 299 510 minecraft:orange_concrete
setblock 546 297 510 minecraft:white_concrete
fill 547 297 552 547 299 552 minecraft:orange_concrete
fill 550 297 526 551 298 527 minecraft:magma_block
fill 551 297 510 551 307 510 minecraft:black_concrete
fill 553 297 510 553 299 510 minecraft:orange_concrete
setblock 554 297 552 minecraft:shroomlight
fill 555 297 552 555 307 552 minecraft:black_concrete
fill 559 297 520 559 299 520 minecraft:orange_concrete
fill 559 297 536 559 299 536 minecraft:orange_concrete
fill 559 297 541 559 307 541 minecraft:black_concrete
fill 559 297 546 559 307 546 minecraft:black_concrete
setblock 517 298 528 minecraft:shroomlight
fill 517 298 536 517 307 536 minecraft:black_concrete
fill 533 298 552 533 307 552 minecraft:black_concrete
fill 546 298 510 546 307 510 minecraft:black_concrete
setblock 548 298 510 minecraft:magma_block
setblock 549 298 510 minecraft:shroomlight
fill 550 298 510 550 307 510 minecraft:black_concrete
fill 554 298 552 554 306 552 minecraft:black_concrete
fill 559 298 547 559 307 547 minecraft:black_concrete
setblock 559 298 548 minecraft:magma_block
fill 517 299 528 517 307 528 minecraft:black_concrete
fill 548 299 510 549 307 510 minecraft:black_concrete
fill 550 299 526 550 299 527 minecraft:magma_block
setblock 551 299 526 minecraft:magma_block
fill 559 299 548 559 307 548 minecraft:black_concrete
fill 517 300 518 517 307 518 minecraft:black_concrete
fill 517 300 534 517 307 534 minecraft:black_concrete
fill 517 300 550 517 307 550 minecraft:black_concrete
fill 521 300 510 521 307 510 minecraft:black_concrete
fill 531 300 552 531 307 552 minecraft:black_concrete
fill 537 300 510 537 307 510 minecraft:black_concrete
setblock 539 300 552 minecraft:magma_block
fill 547 300 552 547 307 552 minecraft:black_concrete
setblock 550 300 526 minecraft:magma_block
fill 553 300 510 553 307 510 minecraft:black_concrete
setblock 558 300 510 minecraft:white_concrete
setblock 559 300 520 minecraft:black_concrete
fill 559 300 536 559 307 536 minecraft:black_concrete
setblock 559 300 538 minecraft:white_concrete
setblock 520 301 513 minecraft:light[level=14]
setblock 520 301 521 minecraft:light[level=14]
setblock 520 301 529 minecraft:light[level=14]
setblock 520 301 537 minecraft:light[level=14]
setblock 520 301 545 minecraft:light[level=14]
setblock 528 301 513 minecraft:light[level=14]
setblock 528 301 521 minecraft:light[level=14]
setblock 528 301 529 minecraft:light[level=14]
setblock 528 301 537 minecraft:light[level=14]
setblock 528 301 545 minecraft:light[level=14]
setblock 536 301 513 minecraft:light[level=14]
setblock 536 301 521 minecraft:light[level=14]
setblock 536 301 529 minecraft:light[level=14]
setblock 536 301 537 minecraft:light[level=14]
setblock 536 301 545 minecraft:light[level=14]
fill 539 301 552 539 307 552 minecraft:black_concrete
setblock 544 301 513 minecraft:light[level=14]
setblock 544 301 521 minecraft:light[level=14]
setblock 544 301 529 minecraft:light[level=14]
setblock 544 301 537 minecraft:light[level=14]
setblock 544 301 545 minecraft:light[level=14]
setblock 552 301 513 minecraft:light[level=14]
setblock 552 301 521 minecraft:light[level=14]
setblock 552 301 529 minecraft:light[level=14]
setblock 552 301 537 minecraft:light[level=14]
setblock 552 301 545 minecraft:light[level=14]
fill 558 301 510 558 307 510 minecraft:black_concrete
setblock 559 301 520 minecraft:shroomlight
fill 559 301 538 559 307 538 minecraft:black_concrete
setblock 559 301 539 minecraft:magma_block
setblock 559 301 543 minecraft:shroomlight
fill 559 301 544 559 307 544 minecraft:black_concrete
setblock 517 302 520 minecraft:shroomlight
setblock 559 302 515 minecraft:white_concrete
setblock 559 302 517 minecraft:shroomlight
fill 559 302 518 559 307 518 minecraft:black_concrete
fill 559 302 520 559 307 520 minecraft:black_concrete
fill 559 302 539 559 307 539 minecraft:black_concrete
fill 559 302 543 559 304 543 minecraft:black_concrete
fill 517 303 520 517 307 520 minecraft:black_concrete
setblock 517 303 539 minecraft:white_concrete
fill 559 303 515 559 307 515 minecraft:black_concrete
fill 559 303 517 559 307 517 minecraft:black_concrete
setblock 559 303 522 minecraft:shroomlight
fill 517 304 539 517 307 539 minecraft:black_concrete
setblock 559 304 514 minecraft:shroomlight
fill 559 304 522 559 307 522 minecraft:black_concrete
setblock 538 305 552 minecraft:magma_block
fill 559 305 514 559 307 514 minecraft:black_concrete
setblock 559 305 543 minecraft:white_concrete
setblock 522 306 510 minecraft:shroomlight
fill 538 306 552 538 307 552 minecraft:black_concrete
fill 559 306 543 559 307 543 minecraft:black_concrete
setblock 518 307 552 minecraft:shroomlight
setblock 519 307 552 minecraft:black_concrete
setblock 522 307 510 minecraft:black_concrete
setblock 534 307 552 minecraft:shroomlight
setblock 554 307 552 minecraft:magma_block
