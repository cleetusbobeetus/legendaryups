fill 214 269 354 214 271 354 minecraft:light_gray_concrete
fill 214 269 356 214 271 356 minecraft:light_gray_concrete
fill 214 269 358 214 271 358 minecraft:light_gray_concrete
fill 214 269 360 214 271 360 minecraft:light_gray_concrete
fill 214 269 362 214 271 362 minecraft:light_gray_concrete
fill 215 269 342 215 271 342 minecraft:lime_stained_glass
fill 215 269 346 215 271 346 minecraft:lime_stained_glass
fill 215 269 355 215 271 355 minecraft:light_gray_concrete
fill 215 269 357 215 271 357 minecraft:light_gray_concrete
fill 215 269 359 215 271 359 minecraft:light_gray_concrete
fill 215 269 361 215 271 361 minecraft:light_gray_concrete
fill 215 269 363 215 271 363 minecraft:light_gray_concrete
setblock 216 269 344 minecraft:lime_stained_glass
fill 216 269 354 216 271 354 minecraft:light_gray_concrete
fill 216 269 356 216 271 356 minecraft:light_gray_concrete
fill 216 269 358 216 271 358 minecraft:light_gray_concrete
fill 216 269 360 216 271 360 minecraft:light_gray_concrete
fill 216 269 362 216 271 362 minecraft:light_gray_concrete
fill 217 269 355 217 271 355 minecraft:light_gray_concrete
fill 217 269 357 217 271 357 minecraft:light_gray_concrete
fill 217 269 359 217 271 359 minecraft:light_gray_concrete
fill 217 269 361 217 271 361 minecraft:light_gray_concrete
fill 217 269 363 217 271 363 minecraft:light_gray_concrete
fill 218 269 354 218 271 354 minecraft:light_gray_concrete
fill 218 269 356 218 271 356 minecraft:light_gray_concrete
fill 218 269 358 218 271 358 minecraft:light_gray_concrete
fill 218 269 360 218 271 360 minecraft:light_gray_concrete
fill 218 269 362 218 271 362 minecraft:light_gray_concrete
fill 219 269 355 219 271 355 minecraft:light_gray_concrete
fill 219 269 357 219 271 357 minecraft:light_gray_concrete
fill 219 269 359 219 271 359 minecraft:light_gray_concrete
fill 219 269 361 219 271 361 minecraft:light_gray_concrete
fill 219 269 363 219 271 363 minecraft:light_gray_concrete
setblock 230 269 335 minecraft:white_concrete
setblock 188 270 352 minecraft:ochre_froglight
setblock 189 270 322 minecraft:white_concrete
fill 193 270 322 193 292 322 minecraft:black_concrete
fill 206 270 364 206 285 364 minecraft:black_concrete
fill 207 270 343 207 272 343 minecraft:lime_stained_glass
fill 207 270 345 207 272 345 minecraft:lime_stained_glass
fill 208 270 341 208 272 341 minecraft:lime_stained_glass
fill 208 270 347 208 272 347 minecraft:lime_stained_glass
fill 210 270 340 210 272 340 minecraft:lime_stained_glass
fill 210 270 348 210 272 348 minecraft:lime_stained_glass
fill 212 270 340 212 272 340 minecraft:lime_stained_glass
fill 212 270 348 212 272 348 minecraft:lime_stained_glass
fill 214 270 341 214 272 341 minecraft:lime_stained_glass
fill 214 270 347 214 272 347 minecraft:lime_stained_glass
fill 215 270 343 215 272 343 minecraft:lime_stained_glass
fill 215 270 345 215 272 345 minecraft:lime_stained_glass
setblock 218 270 322 minecraft:sea_lantern
setblock 223 270 364 minecraft:white_concrete
fill 230 270 335 230 278 335 minecraft:black_concrete
fill 188 271 352 188 308 352 minecraft:black_concrete
fill 189 271 322 189 298 322 minecraft:black_concrete
setblock 191 271 322 minecraft:sea_lantern
setblock 191 271 325 minecraft:light[level=12]
setblock 191 271 332 minecraft:light[level=12]
setblock 191 271 339 minecraft:light[level=12]
setblock 191 271 346 minecraft:light[level=12]
setblock 196 271 364 minecraft:white_concrete
setblock 198 271 325 minecraft:light[level=12]
setblock 198 271 332 minecraft:light[level=12]
setblock 198 271 339 minecraft:light[level=12]
setblock 198 271 346 minecraft:light[level=12]
setblock 202 271 364 minecraft:sea_lantern
setblock 205 271 325 minecraft:light[level=12]
setblock 205 271 332 minecraft:light[level=12]
setblock 205 271 339 minecraft:light[level=12]
setblock 205 271 346 minecraft:light[level=12]
setblock 205 271 353 minecraft:light[level=12]
setblock 205 271 360 minecraft:light[level=12]
fill 207 271 344 207 272 344 minecraft:lime_stained_glass
fill 211 271 340 211 272 340 minecraft:lime_stained_glass
fill 211 271 348 211 272 348 minecraft:lime_stained_glass
setblock 212 271 325 minecraft:light[level=12]
setblock 212 271 332 minecraft:light[level=12]
setblock 212 271 339 minecraft:light[level=12]
setblock 212 271 346 minecraft:light[level=12]
setblock 212 271 353 minecraft:light[level=12]
fill 215 271 344 215 272 344 minecraft:lime_stained_glass
fill 218 271 322 218 279 322 minecraft:black_concrete
setblock 219 271 325 minecraft:light[level=12]
setblock 219 271 332 minecraft:light[level=12]
setblock 219 271 339 minecraft:light[level=12]
setblock 219 271 346 minecraft:light[level=12]
setblock 219 271 353 minecraft:light[level=12]
fill 223 271 364 223 278 364 minecraft:black_concrete
setblock 226 271 325 minecraft:light[level=12]
setblock 226 271 332 minecraft:light[level=12]
setblock 226 271 346 minecraft:light[level=12]
setblock 226 271 353 minecraft:light[level=12]
setblock 226 271 360 minecraft:light[level=12]
setblock 230 271 325 minecraft:ochre_froglight
setblock 230 271 360 minecraft:white_concrete
fill 191 272 322 191 287 322 minecraft:black_concrete
setblock 196 272 322 minecraft:pearlescent_froglight
fill 196 272 364 196 308 364 minecraft:black_concrete
fill 202 272 364 202 295 364 minecraft:black_concrete
fill 208 272 342 208 274 342 minecraft:lime_stained_glass
fill 208 272 346 208 274 346 minecraft:lime_stained_glass
fill 209 272 341 209 274 341 minecraft:lime_stained_glass
fill 209 272 347 209 274 347 minecraft:lime_stained_glass
fill 213 272 341 213 274 341 minecraft:lime_stained_glass
fill 213 272 347 213 274 347 minecraft:lime_stained_glass
fill 214 272 342 214 274 342 minecraft:lime_stained_glass
fill 214 272 346 214 274 346 minecraft:lime_stained_glass
fill 230 272 325 230 308 325 minecraft:black_concrete
setblock 230 272 329 minecraft:white_concrete
fill 230 272 360 230 295 360 minecraft:black_concrete
setblock 191 273 325 minecraft:light[level=15]
setblock 191 273 333 minecraft:light[level=15]
setblock 191 273 341 minecraft:light[level=15]
setblock 191 273 349 minecraft:light[level=15]
setblock 191 273 357 minecraft:light[level=15]
fill 196 273 322 196 308 322 minecraft:black_concrete
setblock 199 273 325 minecraft:light[level=15]
setblock 199 273 333 minecraft:light[level=15]
setblock 199 273 341 minecraft:light[level=15]
setblock 199 273 349 minecraft:light[level=15]
setblock 199 273 357 minecraft:light[level=15]
setblock 207 273 325 minecraft:light[level=15]
setblock 207 273 333 minecraft:light[level=15]
setblock 207 273 341 minecraft:light[level=15]
setblock 207 273 349 minecraft:light[level=15]
setblock 207 273 357 minecraft:light[level=15]
setblock 215 273 325 minecraft:light[level=15]
setblock 215 273 333 minecraft:light[level=15]
setblock 215 273 341 minecraft:light[level=15]
setblock 215 273 349 minecraft:light[level=15]
setblock 215 273 357 minecraft:light[level=15]
setblock 223 273 325 minecraft:light[level=15]
setblock 223 273 333 minecraft:light[level=15]
setblock 223 273 341 minecraft:light[level=15]
setblock 223 273 349 minecraft:light[level=15]
setblock 223 273 357 minecraft:light[level=15]
fill 230 273 329 230 308 329 minecraft:black_concrete
setblock 230 273 339 minecraft:ochre_froglight
setblock 230 273 352 minecraft:ochre_froglight
setblock 197 274 364 minecraft:sea_lantern
fill 208 274 343 208 275 345 minecraft:lime_stained_glass
fill 210 274 341 212 275 341 minecraft:lime_stained_glass
fill 210 274 347 212 275 347 minecraft:lime_stained_glass
setblock 211 274 322 minecraft:ochre_froglight
fill 214 274 343 214 275 345 minecraft:lime_stained_glass
fill 230 274 339 230 308 339 minecraft:black_concrete
fill 230 274 352 230 308 352 minecraft:black_concrete
setblock 230 274 353 minecraft:ochre_froglight
fill 197 275 364 197 290 364 minecraft:black_concrete
fill 209 275 342 209 276 342 minecraft:lime_stained_glass
fill 209 275 346 209 276 346 minecraft:lime_stained_glass
setblock 209 275 364 minecraft:ochre_froglight
fill 211 275 322 211 308 322 minecraft:black_concrete
fill 213 275 342 213 276 342 minecraft:lime_stained_glass
fill 213 275 346 213 276 346 minecraft:lime_stained_glass
setblock 220 275 322 minecraft:white_concrete
setblock 227 275 364 minecraft:sea_lantern
fill 230 275 353 230 308 353 minecraft:black_concrete
setblock 230 275 361 minecraft:pearlescent_froglight
setblock 190 276 322 minecraft:white_concrete
setblock 208 276 344 minecraft:lime_stained_glass
fill 209 276 364 209 308 364 minecraft:black_concrete
setblock 211 276 341 minecraft:lime_stained_glass
setblock 211 276 347 minecraft:lime_stained_glass
setblock 214 276 344 minecraft:lime_stained_glass
setblock 220 276 322 minecraft:black_concrete
fill 227 276 364 227 308 364 minecraft:black_concrete
fill 230 276 361 230 297 361 minecraft:black_concrete
setblock 188 277 338 minecraft:sea_lantern
fill 190 277 322 190 308 322 minecraft:black_concrete
setblock 191 277 325 minecraft:light[level=12]
setblock 191 277 332 minecraft:light[level=12]
setblock 191 277 339 minecraft:light[level=12]
setblock 191 277 346 minecraft:light[level=12]
setblock 191 277 353 minecraft:light[level=12]
setblock 191 277 360 minecraft:light[level=12]
setblock 198 277 325 minecraft:light[level=12]
setblock 198 277 332 minecraft:light[level=12]
setblock 198 277 339 minecraft:light[level=12]
setblock 198 277 346 minecraft:light[level=12]
setblock 198 277 353 minecraft:light[level=12]
setblock 198 277 360 minecraft:light[level=12]
fill 199 277 343 203 280 343 minecraft:light_gray_concrete
fill 199 277 344 200 277 345 minecraft:verdant_froglight
fill 200 277 339 204 280 340 minecraft:light_gray_concrete
fill 200 277 341 200 277 342 minecraft:verdant_froglight
fill 200 277 346 203 280 347 minecraft:light_gray_concrete
fill 200 277 348 200 277 349 minecraft:verdant_froglight
setblock 201 277 338 minecraft:verdant_froglight
fill 201 277 341 203 280 342 minecraft:light_gray_concrete
fill 201 277 344 203 280 345 minecraft:light_gray_concrete
fill 201 277 348 204 280 348 minecraft:light_gray_concrete
setblock 201 277 349 minecraft:verdant_froglight
fill 201 277 350 206 280 350 minecraft:light_gray_concrete
fill 202 277 336 206 280 338 minecraft:light_gray_concrete
fill 202 277 349 205 280 349 minecraft:light_gray_concrete
fill 202 277 351 202 277 352 minecraft:verdant_froglight
fill 203 277 335 204 277 335 minecraft:verdant_froglight
fill 203 277 351 208 280 351 minecraft:light_gray_concrete
setblock 203 277 352 minecraft:verdant_froglight
fill 203 277 353 219 280 353 minecraft:light_gray_concrete
fill 204 277 341 204 281 341 minecraft:light_gray_concrete
fill 204 277 342 204 277 346 minecraft:iron_block
fill 204 277 347 204 281 347 minecraft:light_gray_concrete
fill 204 277 352 218 280 352 minecraft:light_gray_concrete
setblock 205 277 325 minecraft:light[level=12]
setblock 205 277 332 minecraft:light[level=12]
fill 205 277 334 217 280 335 minecraft:light_gray_concrete
fill 205 277 339 205 280 339 minecraft:light_gray_concrete
fill 205 277 340 205 277 341 minecraft:iron_block
fill 205 277 342 208 278 346 minecraft:light_gray_concrete
fill 205 277 347 205 277 348 minecraft:iron_block
fill 205 277 354 206 277 354 minecraft:verdant_froglight
setblock 205 277 360 minecraft:light[level=12]
fill 206 277 333 208 277 333 minecraft:verdant_froglight
setblock 206 277 339 minecraft:iron_block
fill 206 277 340 216 278 341 minecraft:light_gray_concrete
fill 206 277 347 216 278 348 minecraft:light_gray_concrete
setblock 206 277 349 minecraft:iron_block
fill 206 277 355 208 280 355 minecraft:light_gray_concrete
fill 207 277 336 208 280 337 minecraft:light_gray_concrete
fill 207 277 338 208 277 338 minecraft:iron_block
fill 207 277 339 215 281 339 minecraft:light_gray_concrete
fill 207 277 349 215 279 349 minecraft:light_gray_concrete
fill 207 277 350 208 277 350 minecraft:iron_block
fill 207 277 354 215 280 354 minecraft:light_gray_concrete
fill 209 277 333 209 280 333 minecraft:light_gray_concrete
fill 209 277 336 220 280 336 minecraft:light_gray_concrete
fill 209 277 337 213 277 337 minecraft:iron_block
fill 209 277 338 213 281 338 minecraft:light_gray_concrete
fill 209 277 342 209 278 342 minecraft:light_gray_concrete
fill 209 277 346 209 278 346 minecraft:light_gray_concrete
fill 209 277 350 213 281 350 minecraft:light_gray_concrete
fill 209 277 351 213 277 351 minecraft:iron_block
setblock 209 277 355 minecraft:verdant_froglight
fill 210 277 332 211 277 333 minecraft:verdant_froglight
fill 210 277 355 211 280 356 minecraft:light_gray_concrete
setblock 212 277 325 minecraft:light[level=12]
fill 212 277 332 212 280 333 minecraft:light_gray_concrete
fill 212 277 355 212 277 356 minecraft:verdant_froglight
setblock 212 277 360 minecraft:light[level=12]
fill 213 277 333 213 280 333 minecraft:light_gray_concrete
fill 213 277 342 217 278 342 minecraft:light_gray_concrete
fill 213 277 346 217 278 346 minecraft:light_gray_concrete
setblock 213 277 355 minecraft:verdant_froglight
setblock 213 277 364 minecraft:ochre_froglight
fill 214 277 333 215 277 333 minecraft:verdant_froglight
fill 214 277 337 219 280 337 minecraft:light_gray_concrete
fill 214 277 338 215 277 338 minecraft:iron_block
fill 214 277 343 217 278 345 minecraft:light_gray_concrete
fill 214 277 350 215 277 350 minecraft:iron_block
fill 214 277 351 220 279 351 minecraft:light_gray_concrete
fill 214 277 355 215 280 355 minecraft:light_gray_concrete
setblock 215 277 322 minecraft:sea_lantern
fill 216 277 333 216 280 333 minecraft:light_gray_concrete
fill 216 277 338 220 280 338 minecraft:light_gray_concrete
setblock 216 277 339 minecraft:iron_block
setblock 216 277 349 minecraft:iron_block
fill 216 277 350 221 279 350 minecraft:light_gray_concrete
fill 216 277 354 216 277 355 minecraft:verdant_froglight
fill 217 277 339 222 280 339 minecraft:light_gray_concrete
fill 217 277 340 217 277 341 minecraft:iron_block
fill 217 277 347 217 277 348 minecraft:iron_block
fill 217 277 349 220 279 349 minecraft:light_gray_concrete
setblock 217 277 354 minecraft:verdant_froglight
fill 218 277 335 219 277 335 minecraft:verdant_froglight
fill 218 277 340 221 280 341 minecraft:light_gray_concrete
fill 218 277 342 218 277 346 minecraft:iron_block
fill 218 277 347 221 279 348 minecraft:light_gray_concrete
setblock 219 277 325 minecraft:light[level=12]
setblock 219 277 332 minecraft:light[level=12]
fill 219 277 342 221 280 346 minecraft:light_gray_concrete
fill 219 277 352 220 277 352 minecraft:verdant_froglight
setblock 219 277 360 minecraft:light[level=12]
setblock 220 277 322 minecraft:sea_lantern
setblock 220 277 337 minecraft:verdant_froglight
setblock 221 277 338 minecraft:verdant_froglight
fill 221 277 349 222 277 349 minecraft:verdant_froglight
fill 222 277 340 222 280 340 minecraft:light_gray_concrete
fill 222 277 341 222 277 342 minecraft:verdant_froglight
fill 222 277 343 223 280 343 minecraft:light_gray_concrete
fill 222 277 344 223 277 345 minecraft:verdant_froglight
fill 222 277 346 222 280 347 minecraft:light_gray_concrete
setblock 222 277 348 minecraft:verdant_froglight
setblock 225 277 364 minecraft:white_concrete
setblock 226 277 325 minecraft:light[level=12]
setblock 226 277 332 minecraft:light[level=12]
setblock 226 277 339 minecraft:light[level=12]
setblock 226 277 346 minecraft:light[level=12]
setblock 226 277 353 minecraft:light[level=12]
setblock 226 277 360 minecraft:light[level=12]
setblock 230 277 343 minecraft:ochre_froglight
fill 188 278 338 188 308 338 minecraft:black_concrete
fill 198 278 340 198 279 348 minecraft:light_gray_concrete
fill 199 278 338 199 279 342 minecraft:light_gray_concrete
fill 199 278 344 199 279 350 minecraft:light_gray_concrete
fill 200 278 336 201 279 338 minecraft:light_gray_concrete
fill 200 278 341 200 279 342 minecraft:light_gray_concrete
fill 200 278 344 200 279 345 minecraft:light_gray_concrete
fill 200 278 348 200 279 352 minecraft:light_gray_concrete
fill 201 278 335 204 279 335 minecraft:light_gray_concrete
fill 201 278 349 201 279 349 minecraft:light_gray_concrete
fill 201 278 351 202 279 353 minecraft:light_gray_concrete
fill 202 278 334 204 279 334 minecraft:light_gray_concrete
fill 202 278 354 206 279 354 minecraft:light_gray_concrete
fill 203 278 333 208 279 333 minecraft:light_gray_concrete
fill 203 278 352 203 279 352 minecraft:light_gray_concrete
fill 203 278 355 205 279 355 minecraft:light_gray_concrete
fill 204 278 342 204 280 346 minecraft:light_gray_concrete
fill 205 278 332 211 279 332 minecraft:light_gray_concrete
fill 205 278 340 205 280 341 minecraft:light_gray_concrete
fill 205 278 347 205 280 348 minecraft:light_gray_concrete
fill 205 278 356 209 279 356 minecraft:light_gray_concrete
fill 206 278 339 206 280 339 minecraft:light_gray_concrete
fill 206 278 349 206 280 349 minecraft:light_gray_concrete
setblock 207 278 322 minecraft:white_concrete
fill 207 278 331 215 279 331 minecraft:light_gray_concrete
fill 207 278 338 208 280 338 minecraft:light_gray_concrete
fill 207 278 350 208 280 350 minecraft:light_gray_concrete
fill 207 278 357 215 279 357 minecraft:light_gray_concrete
fill 209 278 337 213 280 337 minecraft:light_gray_concrete
fill 209 278 351 213 280 351 minecraft:light_gray_concrete
fill 209 278 355 209 279 355 minecraft:light_gray_concrete
fill 210 278 333 211 279 333 minecraft:light_gray_concrete
fill 212 278 355 213 279 356 minecraft:light_gray_concrete
fill 213 278 332 217 279 332 minecraft:light_gray_concrete
fill 213 278 364 213 281 364 minecraft:black_concrete
fill 214 278 333 215 279 333 minecraft:light_gray_concrete
fill 214 278 338 215 280 338 minecraft:light_gray_concrete
fill 214 278 350 215 279 350 minecraft:light_gray_concrete
fill 214 278 356 217 279 356 minecraft:light_gray_concrete
fill 215 278 322 215 286 322 minecraft:black_concrete
fill 216 278 339 216 280 339 minecraft:light_gray_concrete
fill 216 278 349 216 279 349 minecraft:light_gray_concrete
fill 216 278 354 219 279 355 minecraft:light_gray_concrete
fill 217 278 333 219 279 333 minecraft:light_gray_concrete
fill 217 278 340 217 280 341 minecraft:light_gray_concrete
fill 217 278 347 217 279 348 minecraft:light_gray_concrete
fill 218 278 334 220 279 335 minecraft:light_gray_concrete
fill 218 278 342 218 280 346 minecraft:light_gray_concrete
fill 219 278 352 222 279 352 minecraft:light_gray_concrete
fill 220 278 322 220 285 322 minecraft:black_concrete
fill 220 278 337 222 279 337 minecraft:light_gray_concrete
fill 220 278 353 220 279 354 minecraft:light_gray_concrete
fill 221 278 335 221 279 336 minecraft:light_gray_concrete
fill 221 278 338 223 279 338 minecraft:light_gray_concrete
fill 221 278 349 223 279 349 minecraft:light_gray_concrete
fill 221 278 351 222 279 351 minecraft:light_gray_concrete
fill 221 278 353 221 279 353 minecraft:light_gray_concrete
setblock 221 278 364 minecraft:white_concrete
fill 222 278 336 222 279 336 minecraft:light_gray_concrete
fill 222 278 341 224 279 342 minecraft:light_gray_concrete
fill 222 278 344 224 279 345 minecraft:light_gray_concrete
fill 222 278 348 224 279 348 minecraft:light_gray_concrete
fill 222 278 350 223 279 350 minecraft:light_gray_concrete
fill 223 278 339 223 279 340 minecraft:light_gray_concrete
fill 223 278 346 224 279 347 minecraft:light_gray_concrete
fill 224 278 340 224 279 340 minecraft:light_gray_concrete
fill 224 278 343 224 279 343 minecraft:light_gray_concrete
fill 225 278 364 225 287 364 minecraft:black_concrete
setblock 230 278 327 minecraft:white_concrete
fill 230 278 343 230 308 343 minecraft:black_concrete
fill 189 279 323 189 279 328 minecraft:black_stained_glass
setblock 189 279 329 minecraft:sea_lantern
fill 189 279 330 189 279 341 minecraft:black_stained_glass
setblock 189 279 342 minecraft:sea_lantern
fill 189 279 343 189 279 354 minecraft:black_stained_glass
setblock 189 279 355 minecraft:sea_lantern
fill 189 279 356 189 279 363 minecraft:black_stained_glass
setblock 190 279 323 minecraft:sea_lantern
fill 190 279 324 190 279 335 minecraft:black_stained_glass
setblock 190 279 336 minecraft:sea_lantern
fill 190 279 337 190 279 348 minecraft:black_stained_glass
setblock 190 279 349 minecraft:sea_lantern
fill 190 279 350 190 279 361 minecraft:black_stained_glass
setblock 190 279 362 minecraft:sea_lantern
fill 190 279 363 191 279 363 minecraft:black_stained_glass
fill 191 279 323 191 279 329 minecraft:black_stained_glass
setblock 191 279 330 minecraft:sea_lantern
fill 191 279 331 191 279 342 minecraft:black_stained_glass
setblock 191 279 343 minecraft:sea_lantern
fill 191 279 344 191 279 355 minecraft:black_stained_glass
setblock 191 279 356 minecraft:sea_lantern
fill 191 279 357 192 279 362 minecraft:black_stained_glass
fill 192 279 323 202 279 323 minecraft:black_stained_glass
setblock 192 279 324 minecraft:sea_lantern
fill 192 279 325 192 279 336 minecraft:black_stained_glass
setblock 192 279 337 minecraft:sea_lantern
fill 192 279 338 192 279 349 minecraft:black_stained_glass
setblock 192 279 350 minecraft:sea_lantern
fill 192 279 351 193 279 356 minecraft:black_stained_glass
setblock 192 279 363 minecraft:sea_lantern
setblock 192 279 364 minecraft:ochre_froglight
fill 193 279 324 193 279 330 minecraft:black_stained_glass
setblock 193 279 331 minecraft:sea_lantern
fill 193 279 332 193 279 343 minecraft:black_stained_glass
setblock 193 279 344 minecraft:sea_lantern
fill 193 279 345 194 279 350 minecraft:black_stained_glass
setblock 193 279 357 minecraft:sea_lantern
fill 193 279 358 194 279 363 minecraft:black_stained_glass
fill 194 279 324 204 279 324 minecraft:black_stained_glass
setblock 194 279 325 minecraft:sea_lantern
fill 194 279 326 194 279 337 minecraft:black_stained_glass
setblock 194 279 338 minecraft:sea_lantern
fill 194 279 339 195 279 344 minecraft:black_stained_glass
setblock 194 279 351 minecraft:sea_lantern
fill 194 279 352 195 279 357 minecraft:black_stained_glass
fill 195 279 325 195 279 331 minecraft:black_stained_glass
setblock 195 279 332 minecraft:sea_lantern
fill 195 279 333 196 279 338 minecraft:black_stained_glass
setblock 195 279 345 minecraft:sea_lantern
fill 195 279 346 196 279 351 minecraft:black_stained_glass
setblock 195 279 358 minecraft:sea_lantern
fill 195 279 359 196 279 363 minecraft:black_stained_glass
fill 196 279 325 206 279 325 minecraft:black_stained_glass
setblock 196 279 326 minecraft:sea_lantern
fill 196 279 327 197 279 332 minecraft:black_stained_glass
setblock 196 279 339 minecraft:sea_lantern
fill 196 279 340 197 279 345 minecraft:black_stained_glass
setblock 196 279 352 minecraft:sea_lantern
fill 196 279 353 197 279 358 minecraft:black_stained_glass
fill 197 279 326 208 279 326 minecraft:black_stained_glass
setblock 197 279 333 minecraft:sea_lantern
fill 197 279 334 198 279 339 minecraft:black_stained_glass
setblock 197 279 346 minecraft:sea_lantern
fill 197 279 347 197 279 352 minecraft:black_stained_glass
setblock 197 279 359 minecraft:sea_lantern
fill 197 279 360 198 279 363 minecraft:black_stained_glass
setblock 198 279 327 minecraft:sea_lantern
fill 198 279 328 199 279 333 minecraft:black_stained_glass
fill 198 279 349 198 279 352 minecraft:black_stained_glass
setblock 198 279 353 minecraft:sea_lantern
fill 198 279 354 199 279 359 minecraft:black_stained_glass
fill 199 279 327 210 279 327 minecraft:black_stained_glass
setblock 199 279 334 minecraft:sea_lantern
fill 199 279 335 199 279 337 minecraft:black_stained_glass
fill 199 279 351 199 279 353 minecraft:black_stained_glass
setblock 199 279 360 minecraft:sea_lantern
fill 199 279 361 200 279 363 minecraft:black_stained_glass
setblock 200 279 328 minecraft:sea_lantern
fill 200 279 329 200 279 335 minecraft:black_stained_glass
setblock 200 279 353 minecraft:black_stained_glass
setblock 200 279 354 minecraft:sea_lantern
fill 200 279 355 201 279 360 minecraft:black_stained_glass
fill 201 279 328 201 279 334 minecraft:black_stained_glass
setblock 201 279 354 minecraft:black_stained_glass
setblock 201 279 361 minecraft:sea_lantern
fill 201 279 362 202 279 363 minecraft:black_stained_glass
fill 202 279 328 212 279 328 minecraft:black_stained_glass
setblock 202 279 329 minecraft:sea_lantern
fill 202 279 330 202 279 333 minecraft:black_stained_glass
setblock 202 279 355 minecraft:sea_lantern
fill 202 279 356 203 279 361 minecraft:black_stained_glass
setblock 203 279 323 minecraft:sea_lantern
fill 203 279 329 203 279 332 minecraft:black_stained_glass
setblock 203 279 362 minecraft:sea_lantern
fill 203 279 363 204 279 363 minecraft:black_stained_glass
setblock 203 279 364 minecraft:ochre_froglight
fill 204 279 323 215 279 323 minecraft:black_stained_glass
fill 204 279 329 214 279 329 minecraft:black_stained_glass
setblock 204 279 330 minecraft:sea_lantern
fill 204 279 331 204 279 332 minecraft:black_stained_glass
setblock 204 279 356 minecraft:sea_lantern
fill 204 279 357 205 279 362 minecraft:black_stained_glass
setblock 205 279 324 minecraft:sea_lantern
fill 205 279 330 205 279 331 minecraft:black_stained_glass
fill 205 279 342 207 281 346 minecraft:light_gray_concrete
setblock 205 279 363 minecraft:sea_lantern
fill 206 279 324 217 279 324 minecraft:black_stained_glass
fill 206 279 330 216 279 330 minecraft:black_stained_glass
setblock 206 279 331 minecraft:sea_lantern
fill 206 279 340 208 281 341 minecraft:light_gray_concrete
fill 206 279 347 208 281 348 minecraft:light_gray_concrete
setblock 206 279 357 minecraft:sea_lantern
fill 206 279 358 207 279 363 minecraft:black_stained_glass
fill 207 279 322 207 308 322 minecraft:black_concrete
setblock 207 279 325 minecraft:sea_lantern
fill 208 279 325 219 279 325 minecraft:black_stained_glass
fill 208 279 342 208 279 346 minecraft:verdant_froglight
setblock 208 279 358 minecraft:sea_lantern
fill 208 279 359 209 279 363 minecraft:black_stained_glass
setblock 209 279 326 minecraft:sea_lantern
fill 209 279 340 216 281 340 minecraft:light_gray_concrete
fill 209 279 341 209 279 342 minecraft:verdant_froglight
fill 209 279 346 209 279 347 minecraft:verdant_froglight
fill 209 279 348 216 279 348 minecraft:light_gray_concrete
fill 209 279 358 220 279 358 minecraft:black_stained_glass
fill 210 279 326 221 279 326 minecraft:black_stained_glass
fill 210 279 341 213 279 341 minecraft:verdant_froglight
fill 210 279 347 213 279 347 minecraft:verdant_froglight
setblock 210 279 359 minecraft:sea_lantern
fill 210 279 360 211 279 363 minecraft:black_stained_glass
setblock 211 279 327 minecraft:sea_lantern
fill 211 279 359 222 279 359 minecraft:black_stained_glass
fill 212 279 327 223 279 327 minecraft:black_stained_glass
setblock 212 279 360 minecraft:sea_lantern
fill 212 279 361 213 279 363 minecraft:black_stained_glass
setblock 213 279 328 minecraft:sea_lantern
fill 213 279 342 214 279 342 minecraft:verdant_froglight
fill 213 279 346 214 279 346 minecraft:verdant_froglight
fill 213 279 360 224 279 360 minecraft:black_stained_glass
fill 214 279 328 225 279 328 minecraft:black_stained_glass
fill 214 279 341 216 281 341 minecraft:light_gray_concrete
fill 214 279 343 214 279 345 minecraft:verdant_froglight
fill 214 279 347 216 279 347 minecraft:light_gray_concrete
setblock 214 279 361 minecraft:sea_lantern
fill 214 279 362 215 279 363 minecraft:black_stained_glass
setblock 215 279 329 minecraft:sea_lantern
fill 215 279 342 217 281 346 minecraft:light_gray_concrete
fill 215 279 361 226 279 361 minecraft:black_stained_glass
setblock 216 279 323 minecraft:sea_lantern
fill 216 279 329 227 279 329 minecraft:black_stained_glass
fill 216 279 331 218 279 331 minecraft:black_stained_glass
fill 216 279 357 218 279 357 minecraft:black_stained_glass
setblock 216 279 362 minecraft:sea_lantern
fill 216 279 363 217 279 363 minecraft:black_stained_glass
fill 217 279 323 228 279 323 minecraft:black_stained_glass
setblock 217 279 330 minecraft:sea_lantern
fill 217 279 362 228 279 362 minecraft:black_stained_glass
setblock 218 279 324 minecraft:sea_lantern
fill 218 279 330 229 279 330 minecraft:black_stained_glass
fill 218 279 332 220 279 332 minecraft:black_stained_glass
fill 218 279 356 229 279 356 minecraft:black_stained_glass
setblock 218 279 363 minecraft:sea_lantern
fill 219 279 324 229 279 324 minecraft:black_stained_glass
setblock 219 279 331 minecraft:sea_lantern
setblock 219 279 357 minecraft:sea_lantern
fill 219 279 363 229 279 363 minecraft:black_stained_glass
setblock 220 279 325 minecraft:sea_lantern
fill 220 279 331 229 279 331 minecraft:black_stained_glass
fill 220 279 333 222 279 333 minecraft:black_stained_glass
fill 220 279 355 227 279 355 minecraft:black_stained_glass
fill 220 279 357 229 279 357 minecraft:black_stained_glass
fill 221 279 325 229 279 325 minecraft:black_stained_glass
setblock 221 279 332 minecraft:sea_lantern
fill 221 279 334 224 279 334 minecraft:black_stained_glass
fill 221 279 354 225 279 354 minecraft:black_stained_glass
setblock 221 279 358 minecraft:sea_lantern
fill 221 279 364 221 291 364 minecraft:black_concrete
setblock 222 279 326 minecraft:sea_lantern
fill 222 279 332 229 279 332 minecraft:black_stained_glass
fill 222 279 335 226 279 335 minecraft:black_stained_glass
fill 222 279 353 223 279 353 minecraft:black_stained_glass
fill 222 279 358 229 279 358 minecraft:black_stained_glass
fill 223 279 326 229 279 326 minecraft:black_stained_glass
setblock 223 279 333 minecraft:sea_lantern
fill 223 279 336 228 279 337 minecraft:black_stained_glass
fill 223 279 351 229 279 352 minecraft:black_stained_glass
setblock 223 279 359 minecraft:sea_lantern
setblock 223 279 364 minecraft:white_concrete
setblock 224 279 327 minecraft:sea_lantern
fill 224 279 333 229 279 333 minecraft:black_stained_glass
fill 224 279 338 229 279 339 minecraft:black_stained_glass
fill 224 279 349 228 279 350 minecraft:black_stained_glass
setblock 224 279 353 minecraft:sea_lantern
fill 224 279 359 229 279 359 minecraft:black_stained_glass
fill 225 279 327 229 279 327 minecraft:black_stained_glass
setblock 225 279 334 minecraft:sea_lantern
fill 225 279 340 225 279 346 minecraft:black_stained_glass
setblock 225 279 347 minecraft:sea_lantern
fill 225 279 348 226 279 348 minecraft:black_stained_glass
fill 225 279 353 229 279 353 minecraft:black_stained_glass
setblock 225 279 360 minecraft:sea_lantern
setblock 226 279 328 minecraft:sea_lantern
fill 226 279 334 229 279 334 minecraft:black_stained_glass
fill 226 279 340 229 279 340 minecraft:black_stained_glass
setblock 226 279 341 minecraft:sea_lantern
fill 226 279 342 227 279 347 minecraft:black_stained_glass
setblock 226 279 354 minecraft:sea_lantern
fill 226 279 360 229 279 360 minecraft:black_stained_glass
fill 227 279 328 229 279 328 minecraft:black_stained_glass
setblock 227 279 335 minecraft:sea_lantern
fill 227 279 341 229 279 341 minecraft:black_stained_glass
setblock 227 279 348 minecraft:sea_lantern
fill 227 279 354 229 279 354 minecraft:black_stained_glass
setblock 227 279 361 minecraft:sea_lantern
setblock 228 279 322 minecraft:sea_lantern
setblock 228 279 329 minecraft:sea_lantern
fill 228 279 335 229 279 335 minecraft:black_stained_glass
setblock 228 279 342 minecraft:sea_lantern
fill 228 279 343 229 279 348 minecraft:black_stained_glass
setblock 228 279 355 minecraft:sea_lantern
fill 228 279 361 229 279 361 minecraft:black_stained_glass
setblock 229 279 323 minecraft:sea_lantern
setblock 229 279 329 minecraft:black_stained_glass
setblock 229 279 336 minecraft:sea_lantern
setblock 229 279 337 minecraft:black_stained_glass
setblock 229 279 342 minecraft:black_stained_glass
setblock 229 279 349 minecraft:sea_lantern
setblock 229 279 350 minecraft:black_stained_glass
setblock 229 279 355 minecraft:black_stained_glass
setblock 229 279 362 minecraft:sea_lantern
fill 230 279 327 230 308 327 minecraft:black_concrete
setblock 230 279 333 minecraft:pearlescent_froglight
setblock 230 279 335 minecraft:pearlescent_froglight
setblock 230 279 359 minecraft:pearlescent_froglight
fill 188 280 343 188 308 343 minecraft:black_concrete
setblock 188 280 344 minecraft:white_concrete
setblock 188 280 357 minecraft:sea_lantern
fill 192 280 364 192 308 364 minecraft:black_concrete
setblock 193 280 364 minecraft:white_concrete
fill 199 280 344 200 280 345 minecraft:verdant_froglight
fill 200 280 341 200 280 342 minecraft:verdant_froglight
fill 200 280 348 200 280 349 minecraft:verdant_froglight
setblock 201 280 338 minecraft:verdant_froglight
setblock 201 280 349 minecraft:verdant_froglight
fill 202 280 351 202 280 352 minecraft:verdant_froglight
fill 203 280 335 204 280 335 minecraft:verdant_froglight
setblock 203 280 352 minecraft:verdant_froglight
setblock 203 280 364 minecraft:black_concrete
fill 205 280 354 206 280 354 minecraft:verdant_froglight
fill 206 280 333 208 280 333 minecraft:verdant_froglight
fill 207 280 349 213 281 349 minecraft:light_gray_concrete
fill 208 280 342 208 281 346 minecraft:light_gray_concrete
fill 209 280 341 209 281 342 minecraft:light_gray_concrete
fill 209 280 346 209 281 348 minecraft:light_gray_concrete
setblock 209 280 355 minecraft:verdant_froglight
fill 210 280 332 211 280 333 minecraft:verdant_froglight
fill 210 280 341 213 281 341 minecraft:light_gray_concrete
fill 210 280 347 213 281 348 minecraft:light_gray_concrete
fill 212 280 355 212 280 356 minecraft:verdant_froglight
fill 213 280 342 214 281 342 minecraft:light_gray_concrete
fill 213 280 346 214 281 346 minecraft:light_gray_concrete
setblock 213 280 355 minecraft:verdant_froglight
fill 214 280 333 215 280 333 minecraft:verdant_froglight
fill 214 280 343 214 281 345 minecraft:light_gray_concrete
fill 214 280 347 214 281 347 minecraft:light_gray_concrete
fill 214 280 348 218 281 350 minecraft:cyan_stained_glass
fill 214 280 351 214 281 351 minecraft:light_gray_concrete
fill 215 280 347 217 281 347 minecraft:cyan_stained_glass
fill 215 280 351 217 281 351 minecraft:cyan_stained_glass
fill 216 280 354 216 280 355 minecraft:verdant_froglight
setblock 217 280 354 minecraft:verdant_froglight
setblock 218 280 322 minecraft:ochre_froglight
fill 218 280 335 219 280 335 minecraft:verdant_froglight
fill 218 280 347 221 280 347 minecraft:light_gray_concrete
fill 218 280 351 220 280 351 minecraft:light_gray_concrete
fill 219 280 348 220 280 350 minecraft:light_gray_concrete
fill 219 280 352 220 280 352 minecraft:verdant_froglight
setblock 220 280 337 minecraft:verdant_froglight
setblock 221 280 338 minecraft:verdant_froglight
setblock 221 280 348 minecraft:light_gray_concrete
fill 221 280 349 222 280 349 minecraft:verdant_froglight
setblock 221 280 350 minecraft:light_gray_concrete
fill 222 280 341 222 280 342 minecraft:verdant_froglight
fill 222 280 344 223 280 345 minecraft:verdant_froglight
setblock 222 280 348 minecraft:verdant_froglight
fill 223 280 364 223 297 364 minecraft:black_concrete
fill 228 280 322 228 299 322 minecraft:black_concrete
setblock 230 280 333 minecraft:black_concrete
fill 230 280 335 230 308 335 minecraft:black_concrete
setblock 230 280 348 minecraft:white_concrete
fill 230 280 359 230 297 359 minecraft:black_concrete
fill 188 281 344 188 295 344 minecraft:black_concrete
fill 188 281 357 188 294 357 minecraft:black_concrete
setblock 188 281 360 minecraft:pearlescent_froglight
setblock 191 281 325 minecraft:light[level=15]
setblock 191 281 333 minecraft:light[level=15]
setblock 191 281 341 minecraft:light[level=15]
setblock 191 281 349 minecraft:light[level=15]
setblock 191 281 357 minecraft:light[level=15]
fill 193 281 364 193 308 364 minecraft:black_concrete
setblock 199 281 325 minecraft:light[level=15]
setblock 199 281 333 minecraft:light[level=15]
setblock 199 281 341 minecraft:light[level=15]
setblock 199 281 349 minecraft:light[level=15]
setblock 199 281 357 minecraft:light[level=15]
setblock 203 281 364 minecraft:ochre_froglight
fill 204 281 342 204 281 346 minecraft:iron_block
fill 205 281 340 205 281 341 minecraft:iron_block
fill 205 281 347 205 281 348 minecraft:iron_block
setblock 206 281 339 minecraft:iron_block
setblock 206 281 349 minecraft:iron_block
setblock 207 281 325 minecraft:light[level=15]
setblock 207 281 333 minecraft:light[level=15]
fill 207 281 338 208 281 338 minecraft:iron_block
fill 207 281 350 208 281 350 minecraft:iron_block
setblock 207 281 357 minecraft:light[level=15]
setblock 208 281 337 minecraft:light_gray_concrete
setblock 208 281 351 minecraft:light_gray_concrete
fill 209 281 337 213 281 337 minecraft:iron_block
fill 209 281 351 213 281 351 minecraft:iron_block
setblock 214 281 337 minecraft:light_gray_concrete
fill 214 281 338 215 281 338 minecraft:iron_block
setblock 215 281 325 minecraft:light[level=15]
setblock 215 281 333 minecraft:light[level=15]
setblock 215 281 357 minecraft:light[level=15]
setblock 216 281 339 minecraft:iron_block
fill 217 281 340 217 281 341 minecraft:iron_block
fill 218 281 322 218 288 322 minecraft:black_concrete
setblock 218 281 341 minecraft:light_gray_concrete
fill 218 281 342 218 281 346 minecraft:iron_block
setblock 218 281 347 minecraft:light_gray_concrete
setblock 223 281 325 minecraft:light[level=15]
setblock 223 281 333 minecraft:light[level=15]
setblock 223 281 341 minecraft:light[level=15]
setblock 223 281 349 minecraft:light[level=15]
setblock 223 281 357 minecraft:light[level=15]
setblock 230 281 333 minecraft:pearlescent_froglight
setblock 230 281 348 minecraft:black_concrete
setblock 188 282 354 minecraft:ochre_froglight
fill 188 282 360 188 303 360 minecraft:black_concrete
fill 203 282 364 203 308 364 minecraft:black_concrete
setblock 213 282 364 minecraft:sea_lantern
fill 214 282 349 218 282 349 minecraft:cyan_stained_glass
fill 215 282 348 217 282 348 minecraft:cyan_stained_glass
fill 215 282 350 217 282 350 minecraft:cyan_stained_glass
setblock 216 282 347 minecraft:cyan_stained_glass
setblock 216 282 351 minecraft:cyan_stained_glass
fill 230 282 333 230 308 333 minecraft:black_concrete
setblock 230 282 348 minecraft:ochre_froglight
setblock 230 282 355 minecraft:sea_lantern
setblock 188 283 351 minecraft:white_concrete
fill 188 283 354 188 285 354 minecraft:black_concrete
setblock 188 283 358 minecraft:sea_lantern
setblock 191 283 325 minecraft:light[level=12]
setblock 191 283 332 minecraft:light[level=12]
setblock 191 283 339 minecraft:light[level=12]
setblock 191 283 346 minecraft:light[level=12]
setblock 191 283 353 minecraft:light[level=12]
setblock 191 283 360 minecraft:light[level=12]
setblock 198 283 325 minecraft:light[level=12]
setblock 198 283 332 minecraft:light[level=12]
fill 198 283 336 202 286 336 minecraft:gray_concrete
setblock 198 283 339 minecraft:light[level=12]
setblock 198 283 346 minecraft:light[level=12]
setblock 198 283 353 minecraft:light[level=12]
setblock 198 283 360 minecraft:light[level=12]
fill 199 283 335 202 286 335 minecraft:gray_concrete
fill 199 283 337 201 286 338 minecraft:gray_concrete
fill 200 283 334 201 286 334 minecraft:gray_concrete
fill 201 283 358 205 284 361 minecraft:lime_concrete
fill 202 283 337 202 286 337 minecraft:gray_concrete
fill 202 283 357 204 284 357 minecraft:lime_concrete
fill 203 283 362 203 284 362 minecraft:lime_concrete
setblock 205 283 325 minecraft:light[level=12]
setblock 205 283 332 minecraft:light[level=12]
setblock 205 283 339 minecraft:light[level=12]
setblock 205 283 346 minecraft:light[level=12]
setblock 205 283 353 minecraft:light[level=12]
fill 211 283 323 212 285 327 minecraft:light_gray_concrete
setblock 212 283 332 minecraft:light[level=12]
setblock 212 283 339 minecraft:light[level=12]
setblock 212 283 346 minecraft:light[level=12]
setblock 212 283 353 minecraft:light[level=12]
setblock 212 283 360 minecraft:light[level=12]
fill 213 283 323 213 285 323 minecraft:light_gray_concrete
fill 213 283 324 217 283 325 minecraft:lime_concrete
fill 213 283 326 213 285 327 minecraft:light_gray_concrete
fill 213 283 364 213 297 364 minecraft:black_concrete
fill 214 283 323 216 283 323 minecraft:lime_concrete
fill 214 283 326 216 283 326 minecraft:lime_concrete
fill 214 283 327 214 300 327 minecraft:light_gray_concrete
setblock 215 283 327 minecraft:lime_concrete
fill 216 283 327 219 285 327 minecraft:light_gray_concrete
setblock 216 283 349 minecraft:cyan_stained_glass
fill 217 283 323 219 285 323 minecraft:light_gray_concrete
fill 217 283 326 219 285 326 minecraft:light_gray_concrete
fill 218 283 324 219 285 325 minecraft:light_gray_concrete
setblock 219 283 332 minecraft:light[level=12]
setblock 219 283 339 minecraft:light[level=12]
setblock 219 283 346 minecraft:light[level=12]
setblock 219 283 353 minecraft:light[level=12]
setblock 219 283 360 minecraft:light[level=12]
setblock 222 283 364 minecraft:ochre_froglight
fill 224 283 337 226 284 337 minecraft:gray_concrete
fill 225 283 336 225 284 336 minecraft:gray_concrete
fill 225 283 338 225 284 338 minecraft:gray_concrete
setblock 226 283 325 minecraft:light[level=12]
setblock 226 283 332 minecraft:light[level=12]
setblock 226 283 339 minecraft:light[level=12]
setblock 226 283 346 minecraft:light[level=12]
setblock 226 283 353 minecraft:light[level=12]
setblock 226 283 360 minecraft:light[level=12]
setblock 230 283 342 minecraft:sea_lantern
fill 230 283 348 230 308 348 minecraft:black_concrete
fill 230 283 355 230 284 355 minecraft:black_concrete
setblock 188 284 334 minecraft:pearlescent_froglight
fill 188 284 351 188 300 351 minecraft:black_concrete
fill 188 284 358 188 308 358 minecraft:black_concrete
setblock 198 284 322 minecraft:pearlescent_froglight
fill 198 284 335 198 286 335 minecraft:gray_concrete
fill 198 284 337 198 286 337 minecraft:gray_concrete
fill 199 284 334 199 286 334 minecraft:gray_concrete
fill 199 284 356 199 285 363 minecraft:light_gray_concrete
fill 200 284 356 200 285 357 minecraft:light_gray_concrete
fill 200 284 358 200 284 360 minecraft:lime_concrete
fill 200 284 361 200 285 363 minecraft:light_gray_concrete
fill 201 284 356 202 285 356 minecraft:light_gray_concrete
setblock 201 284 357 minecraft:lime_concrete
fill 201 284 362 201 285 363 minecraft:light_gray_concrete
fill 202 284 334 202 286 334 minecraft:gray_concrete
fill 202 284 338 202 286 338 minecraft:gray_concrete
setblock 202 284 362 minecraft:lime_concrete
fill 202 284 363 207 285 363 minecraft:light_gray_concrete
fill 203 284 336 203 286 337 minecraft:gray_concrete
setblock 203 284 356 minecraft:lime_concrete
fill 204 284 356 207 285 356 minecraft:light_gray_concrete
setblock 204 284 362 minecraft:lime_concrete
setblock 205 284 357 minecraft:lime_concrete
fill 205 284 362 207 285 362 minecraft:light_gray_concrete
fill 206 284 357 207 285 357 minecraft:light_gray_concrete
fill 206 284 358 206 284 360 minecraft:lime_concrete
fill 206 284 361 207 285 361 minecraft:light_gray_concrete
fill 207 284 358 207 285 360 minecraft:light_gray_concrete
fill 213 284 324 217 285 325 minecraft:light_gray_concrete
fill 214 284 323 216 285 323 minecraft:light_gray_concrete
fill 214 284 326 216 285 326 minecraft:light_gray_concrete
fill 215 284 327 215 285 327 minecraft:light_gray_concrete
fill 219 284 339 219 285 340 minecraft:end_stone
fill 222 284 364 222 308 364 minecraft:black_concrete
setblock 229 284 364 minecraft:ochre_froglight
fill 230 284 342 230 308 342 minecraft:black_concrete
setblock 188 285 323 minecraft:white_concrete
fill 188 285 334 188 308 334 minecraft:black_concrete
fill 198 285 322 198 286 322 minecraft:black_concrete
fill 198 285 334 198 286 334 minecraft:gray_concrete
fill 198 285 338 198 286 338 minecraft:gray_concrete
fill 199 285 339 201 286 339 minecraft:gray_concrete
fill 200 285 333 201 286 333 minecraft:gray_concrete
fill 200 285 358 206 285 360 minecraft:light_gray_concrete
fill 201 285 357 205 285 357 minecraft:light_gray_concrete
fill 201 285 361 205 285 361 minecraft:light_gray_concrete
fill 202 285 362 204 285 362 minecraft:light_gray_concrete
fill 203 285 335 203 286 335 minecraft:gray_concrete
fill 203 285 338 203 286 338 minecraft:gray_concrete
fill 203 285 356 203 300 356 minecraft:light_gray_concrete
fill 213 285 355 215 292 355 minecraft:lime_stained_glass
fill 214 285 356 214 292 356 minecraft:lime_stained_glass
fill 229 285 364 229 294 364 minecraft:black_concrete
setblock 230 285 355 minecraft:pearlescent_froglight
fill 188 286 323 188 306 323 minecraft:black_concrete
setblock 188 286 354 minecraft:sea_lantern
fill 197 286 335 197 286 337 minecraft:gray_concrete
setblock 198 286 339 minecraft:gray_concrete
setblock 199 286 333 minecraft:gray_concrete
fill 199 286 356 199 300 356 minecraft:light_gray_concrete
setblock 199 286 357 minecraft:verdant_froglight
fill 199 286 358 199 300 358 minecraft:light_gray_concrete
setblock 199 286 359 minecraft:verdant_froglight
fill 199 286 360 199 300 360 minecraft:light_gray_concrete
setblock 199 286 361 minecraft:verdant_froglight
fill 199 286 362 199 300 362 minecraft:light_gray_concrete
setblock 199 286 363 minecraft:verdant_froglight
fill 200 286 342 200 287 344 minecraft:gray_concrete
setblock 200 286 356 minecraft:verdant_froglight
fill 200 286 357 200 300 357 minecraft:light_gray_concrete
setblock 200 286 358 minecraft:verdant_froglight
fill 200 286 359 200 300 359 minecraft:light_gray_concrete
setblock 200 286 360 minecraft:verdant_froglight
fill 200 286 361 200 300 361 minecraft:light_gray_concrete
setblock 200 286 362 minecraft:verdant_froglight
fill 200 286 363 200 300 363 minecraft:light_gray_concrete
fill 201 286 343 201 287 344 minecraft:gray_concrete
fill 201 286 356 201 300 356 minecraft:light_gray_concrete
setblock 201 286 357 minecraft:verdant_froglight
fill 201 286 358 201 300 358 minecraft:light_gray_concrete
setblock 201 286 359 minecraft:verdant_froglight
fill 201 286 360 201 300 360 minecraft:light_gray_concrete
setblock 201 286 361 minecraft:verdant_froglight
fill 201 286 362 201 300 362 minecraft:light_gray_concrete
setblock 201 286 363 minecraft:verdant_froglight
setblock 202 286 322 minecraft:ochre_froglight
setblock 202 286 333 minecraft:gray_concrete
setblock 202 286 339 minecraft:gray_concrete
setblock 202 286 356 minecraft:verdant_froglight
fill 202 286 357 202 300 357 minecraft:light_gray_concrete
setblock 202 286 358 minecraft:verdant_froglight
fill 202 286 359 202 300 359 minecraft:light_gray_concrete
setblock 202 286 360 minecraft:verdant_froglight
fill 202 286 361 202 300 361 minecraft:light_gray_concrete
setblock 202 286 362 minecraft:verdant_froglight
fill 202 286 363 202 300 363 minecraft:light_gray_concrete
setblock 203 286 334 minecraft:gray_concrete
setblock 203 286 357 minecraft:verdant_froglight
fill 203 286 358 203 300 358 minecraft:light_gray_concrete
setblock 203 286 359 minecraft:verdant_froglight
fill 203 286 360 203 300 360 minecraft:light_gray_concrete
setblock 203 286 361 minecraft:verdant_froglight
fill 203 286 362 203 300 362 minecraft:light_gray_concrete
setblock 203 286 363 minecraft:verdant_froglight
fill 204 286 336 204 286 337 minecraft:gray_concrete
setblock 204 286 356 minecraft:verdant_froglight
fill 204 286 357 204 300 357 minecraft:light_gray_concrete
setblock 204 286 358 minecraft:verdant_froglight
fill 204 286 359 204 300 359 minecraft:light_gray_concrete
setblock 204 286 360 minecraft:verdant_froglight
fill 204 286 361 204 300 361 minecraft:light_gray_concrete
setblock 204 286 362 minecraft:verdant_froglight
fill 204 286 363 204 300 363 minecraft:light_gray_concrete
fill 205 286 356 205 300 356 minecraft:light_gray_concrete
setblock 205 286 357 minecraft:verdant_froglight
fill 205 286 358 205 300 358 minecraft:light_gray_concrete
setblock 205 286 359 minecraft:verdant_froglight
fill 205 286 360 205 300 360 minecraft:light_gray_concrete
setblock 205 286 361 minecraft:verdant_froglight
fill 205 286 362 205 300 362 minecraft:light_gray_concrete
setblock 205 286 363 minecraft:verdant_froglight
setblock 206 286 356 minecraft:verdant_froglight
fill 206 286 357 206 300 357 minecraft:light_gray_concrete
setblock 206 286 358 minecraft:verdant_froglight
fill 206 286 359 206 300 359 minecraft:light_gray_concrete
setblock 206 286 360 minecraft:verdant_froglight
fill 206 286 361 206 300 361 minecraft:light_gray_concrete
setblock 206 286 362 minecraft:verdant_froglight
fill 206 286 363 206 300 363 minecraft:light_gray_concrete
setblock 206 286 364 minecraft:white_concrete
fill 207 286 356 207 300 356 minecraft:light_gray_concrete
setblock 207 286 357 minecraft:verdant_froglight
fill 207 286 358 207 300 358 minecraft:light_gray_concrete
setblock 207 286 359 minecraft:verdant_froglight
fill 207 286 360 207 300 360 minecraft:light_gray_concrete
setblock 207 286 361 minecraft:verdant_froglight
fill 207 286 362 207 300 362 minecraft:light_gray_concrete
setblock 207 286 363 minecraft:verdant_froglight
setblock 211 286 323 minecraft:verdant_froglight
fill 211 286 324 211 300 324 minecraft:light_gray_concrete
setblock 211 286 325 minecraft:verdant_froglight
fill 211 286 326 211 300 326 minecraft:light_gray_concrete
setblock 211 286 327 minecraft:verdant_froglight
fill 212 286 323 212 300 323 minecraft:light_gray_concrete
setblock 212 286 324 minecraft:verdant_froglight
fill 212 286 325 212 300 325 minecraft:light_gray_concrete
setblock 212 286 326 minecraft:verdant_froglight
fill 212 286 327 212 300 327 minecraft:light_gray_concrete
setblock 213 286 323 minecraft:verdant_froglight
fill 213 286 324 213 300 324 minecraft:light_gray_concrete
setblock 213 286 325 minecraft:verdant_froglight
fill 213 286 326 213 300 326 minecraft:light_gray_concrete
setblock 213 286 327 minecraft:verdant_froglight
fill 214 286 323 214 300 323 minecraft:light_gray_concrete
setblock 214 286 324 minecraft:verdant_froglight
fill 214 286 325 214 300 325 minecraft:light_gray_concrete
setblock 214 286 326 minecraft:verdant_froglight
fill 214 286 354 214 291 354 minecraft:lime_stained_glass
setblock 215 286 323 minecraft:verdant_froglight
fill 215 286 324 215 300 324 minecraft:light_gray_concrete
setblock 215 286 325 minecraft:verdant_froglight
fill 215 286 326 215 300 326 minecraft:light_gray_concrete
setblock 215 286 327 minecraft:verdant_froglight
fill 216 286 323 216 300 323 minecraft:light_gray_concrete
setblock 216 286 324 minecraft:verdant_froglight
fill 216 286 325 216 300 325 minecraft:light_gray_concrete
setblock 216 286 326 minecraft:verdant_froglight
fill 216 286 327 216 300 327 minecraft:light_gray_concrete
setblock 217 286 323 minecraft:verdant_froglight
fill 217 286 324 217 300 324 minecraft:light_gray_concrete
setblock 217 286 325 minecraft:verdant_froglight
fill 217 286 326 217 300 326 minecraft:light_gray_concrete
setblock 217 286 327 minecraft:verdant_froglight
fill 218 286 323 218 300 323 minecraft:light_gray_concrete
setblock 218 286 324 minecraft:verdant_froglight
fill 218 286 325 218 300 325 minecraft:light_gray_concrete
setblock 218 286 326 minecraft:verdant_froglight
fill 218 286 327 218 300 327 minecraft:light_gray_concrete
setblock 219 286 323 minecraft:verdant_froglight
fill 219 286 324 219 300 324 minecraft:light_gray_concrete
setblock 219 286 325 minecraft:verdant_froglight
fill 219 286 326 219 300 326 minecraft:light_gray_concrete
setblock 219 286 327 minecraft:verdant_froglight
setblock 220 286 322 minecraft:ochre_froglight
fill 230 286 355 230 308 355 minecraft:black_concrete
fill 188 287 354 188 308 354 minecraft:black_concrete
setblock 198 287 322 minecraft:white_concrete
fill 199 287 357 199 288 357 minecraft:light_gray_concrete
fill 199 287 359 199 288 359 minecraft:light_gray_concrete
fill 199 287 361 199 288 361 minecraft:light_gray_concrete
fill 199 287 363 199 288 363 minecraft:light_gray_concrete
fill 200 287 335 201 287 337 minecraft:lime_stained_glass
fill 200 287 356 200 288 356 minecraft:light_gray_concrete
fill 200 287 358 200 288 358 minecraft:light_gray_concrete
fill 200 287 360 200 288 360 minecraft:light_gray_concrete
fill 200 287 362 200 288 362 minecraft:light_gray_concrete
fill 201 287 357 201 288 357 minecraft:light_gray_concrete
fill 201 287 359 201 288 359 minecraft:light_gray_concrete
fill 201 287 361 201 288 361 minecraft:light_gray_concrete
fill 201 287 363 201 288 363 minecraft:light_gray_concrete
fill 202 287 322 202 308 322 minecraft:black_concrete
fill 202 287 356 202 288 356 minecraft:light_gray_concrete
fill 202 287 358 202 288 358 minecraft:light_gray_concrete
fill 202 287 360 202 288 360 minecraft:light_gray_concrete
fill 202 287 362 202 288 362 minecraft:light_gray_concrete
fill 203 287 357 203 288 357 minecraft:light_gray_concrete
fill 203 287 359 203 288 359 minecraft:light_gray_concrete
fill 203 287 361 203 288 361 minecraft:light_gray_concrete
fill 203 287 363 203 288 363 minecraft:light_gray_concrete
fill 204 287 356 204 288 356 minecraft:light_gray_concrete
fill 204 287 358 204 288 358 minecraft:light_gray_concrete
fill 204 287 360 204 288 360 minecraft:light_gray_concrete
fill 204 287 362 204 288 362 minecraft:light_gray_concrete
fill 205 287 357 205 288 357 minecraft:light_gray_concrete
fill 205 287 359 205 288 359 minecraft:light_gray_concrete
fill 205 287 361 205 288 361 minecraft:light_gray_concrete
fill 205 287 363 205 288 363 minecraft:light_gray_concrete
setblock 205 287 364 minecraft:sea_lantern
fill 206 287 356 206 288 356 minecraft:light_gray_concrete
fill 206 287 358 206 288 358 minecraft:light_gray_concrete
fill 206 287 360 206 288 360 minecraft:light_gray_concrete
fill 206 287 362 206 288 362 minecraft:light_gray_concrete
fill 206 287 364 206 308 364 minecraft:black_concrete
fill 207 287 357 207 288 357 minecraft:light_gray_concrete
fill 207 287 359 207 288 359 minecraft:light_gray_concrete
fill 207 287 361 207 288 361 minecraft:light_gray_concrete
fill 207 287 363 207 288 363 minecraft:light_gray_concrete
fill 211 287 323 211 288 323 minecraft:light_gray_concrete
fill 211 287 325 211 288 325 minecraft:light_gray_concrete
fill 211 287 327 211 288 327 minecraft:light_gray_concrete
fill 212 287 324 212 288 324 minecraft:light_gray_concrete
fill 212 287 326 212 288 326 minecraft:light_gray_concrete
fill 212 287 356 212 288 357 minecraft:gray_concrete
fill 213 287 323 213 288 323 minecraft:light_gray_concrete
fill 213 287 325 213 288 325 minecraft:light_gray_concrete
fill 213 287 327 213 288 327 minecraft:light_gray_concrete
fill 214 287 324 214 288 324 minecraft:light_gray_concrete
fill 214 287 326 214 288 326 minecraft:light_gray_concrete
setblock 215 287 322 minecraft:sea_lantern
fill 215 287 323 215 288 323 minecraft:light_gray_concrete
fill 215 287 325 215 288 325 minecraft:light_gray_concrete
fill 215 287 327 215 288 327 minecraft:light_gray_concrete
fill 216 287 324 216 288 324 minecraft:light_gray_concrete
fill 216 287 326 216 288 326 minecraft:light_gray_concrete
fill 217 287 323 217 288 323 minecraft:light_gray_concrete
fill 217 287 325 217 288 325 minecraft:light_gray_concrete
fill 217 287 327 217 288 327 minecraft:light_gray_concrete
fill 218 287 324 218 288 324 minecraft:light_gray_concrete
fill 218 287 326 218 288 326 minecraft:light_gray_concrete
fill 219 287 323 219 288 323 minecraft:light_gray_concrete
fill 219 287 325 219 288 325 minecraft:light_gray_concrete
fill 219 287 327 219 288 327 minecraft:light_gray_concrete
fill 220 287 322 220 308 322 minecraft:black_concrete
setblock 191 288 322 minecraft:ochre_froglight
setblock 195 288 322 minecraft:sea_lantern
fill 198 288 322 198 293 322 minecraft:black_concrete
fill 200 288 336 200 288 337 minecraft:lime_stained_glass
fill 201 288 336 201 289 336 minecraft:lime_stained_glass
fill 205 288 364 205 299 364 minecraft:black_concrete
fill 215 288 322 215 308 322 minecraft:black_concrete
setblock 216 288 322 minecraft:pearlescent_froglight
fill 225 288 349 225 289 349 minecraft:gray_concrete
setblock 225 288 364 minecraft:sea_lantern
setblock 226 288 364 minecraft:pearlescent_froglight
fill 191 289 322 191 295 322 minecraft:black_concrete
setblock 191 289 325 minecraft:light[level=15]
setblock 191 289 332 minecraft:light[level=12]
setblock 191 289 333 minecraft:light[level=15]
setblock 191 289 339 minecraft:light[level=12]
setblock 191 289 341 minecraft:light[level=15]
setblock 191 289 346 minecraft:light[level=12]
setblock 191 289 349 minecraft:light[level=15]
setblock 191 289 353 minecraft:light[level=12]
setblock 191 289 357 minecraft:light[level=15]
setblock 191 289 360 minecraft:light[level=12]
fill 195 289 322 195 298 322 minecraft:black_concrete
setblock 198 289 325 minecraft:light[level=12]
setblock 198 289 332 minecraft:light[level=12]
setblock 198 289 339 minecraft:light[level=12]
setblock 198 289 346 minecraft:light[level=12]
setblock 198 289 353 minecraft:light[level=12]
setblock 198 289 360 minecraft:light[level=12]
setblock 199 289 325 minecraft:light[level=15]
setblock 199 289 333 minecraft:light[level=15]
setblock 199 289 341 minecraft:light[level=15]
setblock 199 289 349 minecraft:light[level=15]
setblock 199 289 357 minecraft:verdant_froglight
setblock 199 289 359 minecraft:verdant_froglight
setblock 199 289 361 minecraft:verdant_froglight
setblock 199 289 363 minecraft:verdant_froglight
fill 200 289 336 200 290 336 minecraft:lime_stained_glass
setblock 200 289 356 minecraft:verdant_froglight
setblock 200 289 358 minecraft:verdant_froglight
setblock 200 289 360 minecraft:verdant_froglight
setblock 200 289 362 minecraft:verdant_froglight
setblock 201 289 357 minecraft:verdant_froglight
setblock 201 289 359 minecraft:verdant_froglight
setblock 201 289 361 minecraft:verdant_froglight
setblock 201 289 363 minecraft:verdant_froglight
setblock 202 289 356 minecraft:verdant_froglight
setblock 202 289 358 minecraft:verdant_froglight
setblock 202 289 360 minecraft:verdant_froglight
setblock 202 289 362 minecraft:verdant_froglight
setblock 203 289 357 minecraft:verdant_froglight
setblock 203 289 359 minecraft:verdant_froglight
setblock 203 289 361 minecraft:verdant_froglight
setblock 203 289 363 minecraft:verdant_froglight
setblock 204 289 356 minecraft:verdant_froglight
setblock 204 289 358 minecraft:verdant_froglight
setblock 204 289 360 minecraft:verdant_froglight
setblock 204 289 362 minecraft:verdant_froglight
setblock 205 289 325 minecraft:light[level=12]
setblock 205 289 332 minecraft:light[level=12]
setblock 205 289 339 minecraft:light[level=12]
setblock 205 289 346 minecraft:light[level=12]
setblock 205 289 353 minecraft:light[level=12]
setblock 205 289 357 minecraft:verdant_froglight
setblock 205 289 359 minecraft:verdant_froglight
setblock 205 289 361 minecraft:verdant_froglight
setblock 205 289 363 minecraft:verdant_froglight
setblock 206 289 356 minecraft:verdant_froglight
setblock 206 289 358 minecraft:verdant_froglight
setblock 206 289 360 minecraft:verdant_froglight
setblock 206 289 362 minecraft:verdant_froglight
setblock 207 289 325 minecraft:light[level=15]
setblock 207 289 333 minecraft:light[level=15]
setblock 207 289 341 minecraft:light[level=15]
setblock 207 289 349 minecraft:light[level=15]
setblock 207 289 357 minecraft:verdant_froglight
setblock 207 289 359 minecraft:verdant_froglight
setblock 207 289 361 minecraft:verdant_froglight
setblock 207 289 363 minecraft:verdant_froglight
setblock 211 289 323 minecraft:verdant_froglight
setblock 211 289 325 minecraft:verdant_froglight
setblock 211 289 327 minecraft:verdant_froglight
setblock 212 289 324 minecraft:verdant_froglight
setblock 212 289 326 minecraft:verdant_froglight
setblock 212 289 332 minecraft:light[level=12]
setblock 212 289 339 minecraft:light[level=12]
setblock 212 289 346 minecraft:light[level=12]
setblock 212 289 353 minecraft:light[level=12]
setblock 212 289 360 minecraft:light[level=12]
setblock 213 289 322 minecraft:pearlescent_froglight
setblock 213 289 323 minecraft:verdant_froglight
setblock 213 289 325 minecraft:verdant_froglight
setblock 213 289 327 minecraft:verdant_froglight
setblock 214 289 324 minecraft:verdant_froglight
setblock 214 289 326 minecraft:verdant_froglight
setblock 215 289 323 minecraft:verdant_froglight
setblock 215 289 325 minecraft:verdant_froglight
setblock 215 289 327 minecraft:verdant_froglight
setblock 215 289 333 minecraft:light[level=15]
setblock 215 289 341 minecraft:light[level=15]
setblock 215 289 349 minecraft:light[level=15]
setblock 215 289 357 minecraft:light[level=15]
fill 216 289 322 216 308 322 minecraft:black_concrete
setblock 216 289 324 minecraft:verdant_froglight
setblock 216 289 326 minecraft:verdant_froglight
setblock 217 289 323 minecraft:verdant_froglight
setblock 217 289 325 minecraft:verdant_froglight
setblock 217 289 327 minecraft:verdant_froglight
setblock 218 289 322 minecraft:white_concrete
setblock 218 289 324 minecraft:verdant_froglight
setblock 218 289 326 minecraft:verdant_froglight
setblock 219 289 323 minecraft:verdant_froglight
setblock 219 289 325 minecraft:verdant_froglight
setblock 219 289 327 minecraft:verdant_froglight
setblock 219 289 332 minecraft:light[level=12]
setblock 219 289 339 minecraft:light[level=12]
setblock 219 289 346 minecraft:light[level=12]
setblock 219 289 353 minecraft:light[level=12]
setblock 219 289 360 minecraft:light[level=12]
setblock 223 289 325 minecraft:light[level=15]
setblock 223 289 333 minecraft:light[level=15]
setblock 223 289 341 minecraft:light[level=15]
setblock 223 289 349 minecraft:light[level=15]
setblock 223 289 357 minecraft:light[level=15]
fill 225 289 364 226 300 364 minecraft:black_concrete
setblock 226 289 325 minecraft:light[level=12]
setblock 226 289 332 minecraft:light[level=12]
setblock 226 289 339 minecraft:light[level=12]
setblock 226 289 346 minecraft:light[level=12]
setblock 226 289 353 minecraft:light[level=12]
setblock 226 289 360 minecraft:light[level=12]
setblock 188 290 355 minecraft:ochre_froglight
fill 199 290 357 199 291 357 minecraft:light_gray_concrete
fill 199 290 359 199 291 359 minecraft:light_gray_concrete
fill 199 290 361 199 291 361 minecraft:light_gray_concrete
fill 199 290 363 199 291 363 minecraft:light_gray_concrete
fill 200 290 356 200 291 356 minecraft:light_gray_concrete
fill 200 290 358 200 291 358 minecraft:light_gray_concrete
fill 200 290 360 200 291 360 minecraft:light_gray_concrete
fill 200 290 362 200 291 362 minecraft:light_gray_concrete
fill 201 290 357 201 291 357 minecraft:light_gray_concrete
fill 201 290 359 201 291 359 minecraft:light_gray_concrete
fill 201 290 361 201 291 361 minecraft:light_gray_concrete
fill 201 290 363 201 291 363 minecraft:light_gray_concrete
fill 202 290 356 202 291 356 minecraft:light_gray_concrete
fill 202 290 358 202 291 358 minecraft:light_gray_concrete
fill 202 290 360 202 291 360 minecraft:light_gray_concrete
fill 202 290 362 202 291 362 minecraft:light_gray_concrete
fill 203 290 357 203 291 357 minecraft:light_gray_concrete
fill 203 290 359 203 291 359 minecraft:light_gray_concrete
fill 203 290 361 203 291 361 minecraft:light_gray_concrete
fill 203 290 363 203 291 363 minecraft:light_gray_concrete
fill 204 290 356 204 291 356 minecraft:light_gray_concrete
fill 204 290 358 204 291 358 minecraft:light_gray_concrete
fill 204 290 360 204 291 360 minecraft:light_gray_concrete
fill 204 290 362 204 291 362 minecraft:light_gray_concrete
fill 205 290 357 205 291 357 minecraft:light_gray_concrete
fill 205 290 359 205 291 359 minecraft:light_gray_concrete
fill 205 290 361 205 291 361 minecraft:light_gray_concrete
fill 205 290 363 205 291 363 minecraft:light_gray_concrete
fill 206 290 356 206 291 356 minecraft:light_gray_concrete
fill 206 290 358 206 291 358 minecraft:light_gray_concrete
fill 206 290 360 206 291 360 minecraft:light_gray_concrete
fill 206 290 362 206 291 362 minecraft:light_gray_concrete
fill 207 290 357 207 291 357 minecraft:light_gray_concrete
fill 207 290 359 207 291 359 minecraft:light_gray_concrete
fill 207 290 361 207 291 361 minecraft:light_gray_concrete
fill 207 290 363 207 291 363 minecraft:light_gray_concrete
fill 211 290 323 211 291 323 minecraft:light_gray_concrete
fill 211 290 325 211 291 325 minecraft:light_gray_concrete
fill 211 290 327 211 291 327 minecraft:light_gray_concrete
fill 212 290 324 212 291 324 minecraft:light_gray_concrete
fill 212 290 326 212 291 326 minecraft:light_gray_concrete
fill 213 290 322 213 308 322 minecraft:black_concrete
fill 213 290 323 213 291 323 minecraft:light_gray_concrete
fill 213 290 325 213 291 325 minecraft:light_gray_concrete
fill 213 290 327 213 291 327 minecraft:light_gray_concrete
fill 214 290 324 214 291 324 minecraft:light_gray_concrete
fill 214 290 326 214 291 326 minecraft:light_gray_concrete
fill 215 290 323 215 291 323 minecraft:light_gray_concrete
fill 215 290 325 215 291 325 minecraft:light_gray_concrete
fill 215 290 327 215 291 327 minecraft:light_gray_concrete
fill 216 290 324 216 291 324 minecraft:light_gray_concrete
fill 216 290 326 216 291 326 minecraft:light_gray_concrete
fill 217 290 323 217 291 323 minecraft:light_gray_concrete
fill 217 290 325 217 291 325 minecraft:light_gray_concrete
fill 217 290 327 217 291 327 minecraft:light_gray_concrete
fill 218 290 322 218 308 322 minecraft:black_concrete
fill 218 290 324 218 291 324 minecraft:light_gray_concrete
fill 218 290 326 218 291 326 minecraft:light_gray_concrete
fill 219 290 323 219 291 323 minecraft:light_gray_concrete
fill 219 290 325 219 291 325 minecraft:light_gray_concrete
fill 219 290 327 219 291 327 minecraft:light_gray_concrete
setblock 230 290 336 minecraft:sea_lantern
setblock 188 291 329 minecraft:pearlescent_froglight
setblock 188 291 330 minecraft:sea_lantern
fill 188 291 355 188 294 355 minecraft:black_concrete
setblock 197 291 364 minecraft:pearlescent_froglight
setblock 200 291 364 minecraft:ochre_froglight
setblock 219 291 364 minecraft:sea_lantern
fill 230 291 336 230 308 336 minecraft:black_concrete
fill 188 292 329 188 308 330 minecraft:black_concrete
setblock 188 292 336 minecraft:sea_lantern
fill 195 292 337 196 293 338 minecraft:end_stone
fill 197 292 364 197 308 364 minecraft:black_concrete
fill 198 292 349 199 293 349 minecraft:end_stone
setblock 199 292 357 minecraft:verdant_froglight
setblock 199 292 359 minecraft:verdant_froglight
setblock 199 292 361 minecraft:verdant_froglight
setblock 199 292 363 minecraft:verdant_froglight
setblock 199 292 364 minecraft:ochre_froglight
setblock 200 292 322 minecraft:ochre_froglight
setblock 200 292 356 minecraft:verdant_froglight
setblock 200 292 358 minecraft:verdant_froglight
setblock 200 292 360 minecraft:verdant_froglight
setblock 200 292 362 minecraft:verdant_froglight
fill 200 292 364 200 308 364 minecraft:black_concrete
setblock 201 292 322 minecraft:pearlescent_froglight
setblock 201 292 357 minecraft:verdant_froglight
setblock 201 292 359 minecraft:verdant_froglight
setblock 201 292 361 minecraft:verdant_froglight
setblock 201 292 363 minecraft:verdant_froglight
setblock 202 292 356 minecraft:verdant_froglight
setblock 202 292 358 minecraft:verdant_froglight
setblock 202 292 360 minecraft:verdant_froglight
setblock 202 292 362 minecraft:verdant_froglight
setblock 203 292 357 minecraft:verdant_froglight
setblock 203 292 359 minecraft:verdant_froglight
setblock 203 292 361 minecraft:verdant_froglight
setblock 203 292 363 minecraft:verdant_froglight
setblock 204 292 356 minecraft:verdant_froglight
setblock 204 292 358 minecraft:verdant_froglight
setblock 204 292 360 minecraft:verdant_froglight
setblock 204 292 362 minecraft:verdant_froglight
setblock 205 292 357 minecraft:verdant_froglight
setblock 205 292 359 minecraft:verdant_froglight
setblock 205 292 361 minecraft:verdant_froglight
setblock 205 292 363 minecraft:verdant_froglight
setblock 206 292 356 minecraft:verdant_froglight
setblock 206 292 358 minecraft:verdant_froglight
setblock 206 292 360 minecraft:verdant_froglight
setblock 206 292 362 minecraft:verdant_froglight
setblock 207 292 357 minecraft:verdant_froglight
setblock 207 292 359 minecraft:verdant_froglight
setblock 207 292 361 minecraft:verdant_froglight
setblock 207 292 363 minecraft:verdant_froglight
setblock 211 292 323 minecraft:verdant_froglight
setblock 211 292 325 minecraft:verdant_froglight
setblock 211 292 327 minecraft:verdant_froglight
setblock 212 292 324 minecraft:verdant_froglight
setblock 212 292 326 minecraft:verdant_froglight
setblock 213 292 323 minecraft:verdant_froglight
setblock 213 292 325 minecraft:verdant_froglight
setblock 213 292 327 minecraft:verdant_froglight
setblock 214 292 324 minecraft:verdant_froglight
setblock 214 292 326 minecraft:verdant_froglight
setblock 215 292 323 minecraft:verdant_froglight
setblock 215 292 325 minecraft:verdant_froglight
setblock 215 292 327 minecraft:verdant_froglight
setblock 216 292 324 minecraft:verdant_froglight
setblock 216 292 326 minecraft:verdant_froglight
setblock 217 292 323 minecraft:verdant_froglight
setblock 217 292 325 minecraft:verdant_froglight
setblock 217 292 327 minecraft:verdant_froglight
setblock 218 292 324 minecraft:verdant_froglight
setblock 218 292 326 minecraft:verdant_froglight
setblock 219 292 323 minecraft:verdant_froglight
setblock 219 292 325 minecraft:verdant_froglight
setblock 219 292 327 minecraft:verdant_froglight
fill 219 292 364 219 308 364 minecraft:black_concrete
setblock 221 292 364 minecraft:sea_lantern
fill 188 293 336 188 302 336 minecraft:black_concrete
setblock 193 293 322 minecraft:sea_lantern
fill 199 293 357 199 294 357 minecraft:light_gray_concrete
fill 199 293 359 199 294 359 minecraft:light_gray_concrete
fill 199 293 361 199 294 361 minecraft:light_gray_concrete
fill 199 293 363 199 294 363 minecraft:light_gray_concrete
fill 199 293 364 199 308 364 minecraft:black_concrete
fill 200 293 322 201 308 322 minecraft:black_concrete
fill 200 293 356 200 294 356 minecraft:light_gray_concrete
fill 200 293 358 200 294 358 minecraft:light_gray_concrete
fill 200 293 360 200 294 360 minecraft:light_gray_concrete
fill 200 293 362 200 294 362 minecraft:light_gray_concrete
fill 201 293 357 201 294 357 minecraft:light_gray_concrete
fill 201 293 359 201 294 359 minecraft:light_gray_concrete
fill 201 293 361 201 294 361 minecraft:light_gray_concrete
fill 201 293 363 201 294 363 minecraft:light_gray_concrete
fill 202 293 356 202 294 356 minecraft:light_gray_concrete
fill 202 293 358 202 294 358 minecraft:light_gray_concrete
fill 202 293 360 202 294 360 minecraft:light_gray_concrete
fill 202 293 362 202 294 362 minecraft:light_gray_concrete
fill 203 293 357 203 294 357 minecraft:light_gray_concrete
fill 203 293 359 203 294 359 minecraft:light_gray_concrete
fill 203 293 361 203 294 361 minecraft:light_gray_concrete
fill 203 293 363 203 294 363 minecraft:light_gray_concrete
fill 204 293 356 204 294 356 minecraft:light_gray_concrete
fill 204 293 358 204 294 358 minecraft:light_gray_concrete
fill 204 293 360 204 294 360 minecraft:light_gray_concrete
fill 204 293 362 204 294 362 minecraft:light_gray_concrete
fill 205 293 357 205 294 357 minecraft:light_gray_concrete
fill 205 293 359 205 294 359 minecraft:light_gray_concrete
fill 205 293 361 205 294 361 minecraft:light_gray_concrete
fill 205 293 363 205 294 363 minecraft:light_gray_concrete
fill 206 293 356 206 294 356 minecraft:light_gray_concrete
fill 206 293 358 206 294 358 minecraft:light_gray_concrete
fill 206 293 360 206 294 360 minecraft:light_gray_concrete
fill 206 293 362 206 294 362 minecraft:light_gray_concrete
fill 207 293 357 207 294 357 minecraft:light_gray_concrete
fill 207 293 359 207 294 359 minecraft:light_gray_concrete
fill 207 293 361 207 294 361 minecraft:light_gray_concrete
fill 207 293 363 207 294 363 minecraft:light_gray_concrete
fill 211 293 323 211 294 323 minecraft:light_gray_concrete
fill 211 293 325 211 294 325 minecraft:light_gray_concrete
fill 211 293 327 211 294 327 minecraft:light_gray_concrete
fill 212 293 324 212 294 324 minecraft:light_gray_concrete
fill 212 293 326 212 294 326 minecraft:light_gray_concrete
fill 213 293 323 213 294 323 minecraft:light_gray_concrete
fill 213 293 325 213 294 325 minecraft:light_gray_concrete
fill 213 293 327 213 294 327 minecraft:light_gray_concrete
fill 213 293 353 215 293 357 minecraft:white_concrete
fill 214 293 324 214 294 324 minecraft:light_gray_concrete
fill 214 293 326 214 294 326 minecraft:light_gray_concrete
fill 215 293 323 215 294 323 minecraft:light_gray_concrete
fill 215 293 325 215 294 325 minecraft:light_gray_concrete
fill 215 293 327 215 294 327 minecraft:light_gray_concrete
fill 216 293 324 216 294 324 minecraft:light_gray_concrete
fill 216 293 326 216 294 326 minecraft:light_gray_concrete
fill 217 293 323 217 294 323 minecraft:light_gray_concrete
fill 217 293 325 217 294 325 minecraft:light_gray_concrete
fill 217 293 327 217 294 327 minecraft:light_gray_concrete
fill 218 293 324 218 294 324 minecraft:light_gray_concrete
fill 218 293 326 218 294 326 minecraft:light_gray_concrete
fill 219 293 323 219 294 323 minecraft:light_gray_concrete
fill 219 293 325 219 294 325 minecraft:light_gray_concrete
fill 219 293 327 219 294 327 minecraft:light_gray_concrete
fill 221 293 364 221 308 364 minecraft:black_concrete
fill 193 294 322 193 300 322 minecraft:black_concrete
setblock 198 294 322 minecraft:pearlescent_froglight
fill 213 294 353 213 294 357 minecraft:white_concrete
fill 214 294 353 215 294 353 minecraft:white_concrete
fill 214 294 354 214 294 355 minecraft:black_concrete
fill 214 294 356 215 294 357 minecraft:white_concrete
fill 215 294 354 215 294 355 minecraft:white_concrete
setblock 230 294 337 minecraft:ochre_froglight
setblock 188 295 355 minecraft:ochre_froglight
setblock 188 295 357 minecraft:sea_lantern
setblock 191 295 325 minecraft:light[level=12]
setblock 191 295 332 minecraft:light[level=12]
setblock 191 295 339 minecraft:light[level=12]
setblock 191 295 346 minecraft:light[level=12]
setblock 191 295 353 minecraft:light[level=12]
setblock 191 295 360 minecraft:light[level=12]
fill 198 295 322 198 308 322 minecraft:black_concrete
setblock 198 295 325 minecraft:light[level=12]
setblock 198 295 332 minecraft:light[level=12]
setblock 198 295 339 minecraft:light[level=12]
setblock 198 295 346 minecraft:light[level=12]
setblock 198 295 353 minecraft:light[level=12]
setblock 198 295 360 minecraft:light[level=12]
setblock 199 295 357 minecraft:verdant_froglight
setblock 199 295 359 minecraft:verdant_froglight
setblock 199 295 361 minecraft:verdant_froglight
setblock 199 295 363 minecraft:verdant_froglight
setblock 200 295 356 minecraft:verdant_froglight
setblock 200 295 358 minecraft:verdant_froglight
setblock 200 295 360 minecraft:verdant_froglight
setblock 200 295 362 minecraft:verdant_froglight
setblock 201 295 357 minecraft:verdant_froglight
setblock 201 295 359 minecraft:verdant_froglight
setblock 201 295 361 minecraft:verdant_froglight
setblock 201 295 363 minecraft:verdant_froglight
setblock 202 295 356 minecraft:verdant_froglight
setblock 202 295 358 minecraft:verdant_froglight
setblock 202 295 360 minecraft:verdant_froglight
setblock 202 295 362 minecraft:verdant_froglight
setblock 203 295 357 minecraft:verdant_froglight
setblock 203 295 359 minecraft:verdant_froglight
setblock 203 295 361 minecraft:verdant_froglight
setblock 203 295 363 minecraft:verdant_froglight
setblock 204 295 356 minecraft:verdant_froglight
setblock 204 295 358 minecraft:verdant_froglight
setblock 204 295 360 minecraft:verdant_froglight
setblock 204 295 362 minecraft:verdant_froglight
setblock 205 295 325 minecraft:light[level=12]
setblock 205 295 332 minecraft:light[level=12]
setblock 205 295 339 minecraft:light[level=12]
setblock 205 295 346 minecraft:light[level=12]
setblock 205 295 353 minecraft:light[level=12]
setblock 205 295 357 minecraft:verdant_froglight
setblock 205 295 359 minecraft:verdant_froglight
setblock 205 295 361 minecraft:verdant_froglight
setblock 205 295 363 minecraft:verdant_froglight
setblock 206 295 356 minecraft:verdant_froglight
setblock 206 295 358 minecraft:verdant_froglight
setblock 206 295 360 minecraft:verdant_froglight
setblock 206 295 362 minecraft:verdant_froglight
setblock 207 295 357 minecraft:verdant_froglight
setblock 207 295 359 minecraft:verdant_froglight
setblock 207 295 361 minecraft:verdant_froglight
setblock 207 295 363 minecraft:verdant_froglight
setblock 211 295 323 minecraft:verdant_froglight
setblock 211 295 325 minecraft:verdant_froglight
setblock 211 295 327 minecraft:verdant_froglight
setblock 212 295 324 minecraft:verdant_froglight
setblock 212 295 326 minecraft:verdant_froglight
setblock 212 295 332 minecraft:light[level=12]
setblock 212 295 339 minecraft:light[level=12]
setblock 212 295 346 minecraft:light[level=12]
setblock 212 295 353 minecraft:light[level=12]
setblock 212 295 360 minecraft:light[level=12]
setblock 213 295 323 minecraft:verdant_froglight
setblock 213 295 325 minecraft:verdant_froglight
setblock 213 295 327 minecraft:verdant_froglight
setblock 214 295 324 minecraft:verdant_froglight
setblock 214 295 326 minecraft:verdant_froglight
setblock 215 295 323 minecraft:verdant_froglight
setblock 215 295 325 minecraft:verdant_froglight
setblock 215 295 327 minecraft:verdant_froglight
setblock 216 295 324 minecraft:verdant_froglight
setblock 216 295 326 minecraft:verdant_froglight
setblock 217 295 323 minecraft:verdant_froglight
setblock 217 295 325 minecraft:verdant_froglight
setblock 217 295 327 minecraft:verdant_froglight
setblock 218 295 324 minecraft:verdant_froglight
setblock 218 295 326 minecraft:verdant_froglight
setblock 219 295 323 minecraft:verdant_froglight
setblock 219 295 325 minecraft:verdant_froglight
setblock 219 295 327 minecraft:verdant_froglight
setblock 219 295 332 minecraft:light[level=12]
setblock 219 295 339 minecraft:light[level=12]
setblock 219 295 346 minecraft:light[level=12]
setblock 219 295 353 minecraft:light[level=12]
setblock 219 295 360 minecraft:light[level=12]
setblock 226 295 325 minecraft:light[level=12]
setblock 226 295 332 minecraft:light[level=12]
setblock 226 295 339 minecraft:light[level=12]
setblock 226 295 346 minecraft:light[level=12]
setblock 226 295 353 minecraft:light[level=12]
setblock 226 295 360 minecraft:light[level=12]
setblock 229 295 364 minecraft:sea_lantern
fill 230 295 337 230 308 337 minecraft:black_concrete
setblock 188 296 344 minecraft:sea_lantern
fill 188 296 355 188 308 355 minecraft:black_concrete
fill 188 296 357 188 308 357 minecraft:black_concrete
setblock 191 296 322 minecraft:ochre_froglight
fill 199 296 357 199 297 357 minecraft:light_gray_concrete
fill 199 296 359 199 297 359 minecraft:light_gray_concrete
fill 199 296 361 199 297 361 minecraft:light_gray_concrete
fill 199 296 363 199 297 363 minecraft:light_gray_concrete
fill 200 296 356 200 297 356 minecraft:light_gray_concrete
fill 200 296 358 200 297 358 minecraft:light_gray_concrete
fill 200 296 360 200 297 360 minecraft:light_gray_concrete
fill 200 296 362 200 297 362 minecraft:light_gray_concrete
fill 201 296 357 201 297 357 minecraft:light_gray_concrete
fill 201 296 359 201 297 359 minecraft:light_gray_concrete
fill 201 296 361 201 297 361 minecraft:light_gray_concrete
fill 201 296 363 201 297 363 minecraft:light_gray_concrete
fill 202 296 356 202 297 356 minecraft:light_gray_concrete
fill 202 296 358 202 297 358 minecraft:light_gray_concrete
fill 202 296 360 202 297 360 minecraft:light_gray_concrete
fill 202 296 362 202 297 362 minecraft:light_gray_concrete
setblock 202 296 364 minecraft:sea_lantern
fill 203 296 357 203 297 357 minecraft:light_gray_concrete
fill 203 296 359 203 297 359 minecraft:light_gray_concrete
fill 203 296 361 203 297 361 minecraft:light_gray_concrete
fill 203 296 363 203 297 363 minecraft:light_gray_concrete
fill 204 296 356 204 297 356 minecraft:light_gray_concrete
fill 204 296 358 204 297 358 minecraft:light_gray_concrete
fill 204 296 360 204 297 360 minecraft:light_gray_concrete
fill 204 296 362 204 297 362 minecraft:light_gray_concrete
fill 205 296 357 205 297 357 minecraft:light_gray_concrete
fill 205 296 359 205 297 359 minecraft:light_gray_concrete
fill 205 296 361 205 297 361 minecraft:light_gray_concrete
fill 205 296 363 205 297 363 minecraft:light_gray_concrete
fill 206 296 356 206 297 356 minecraft:light_gray_concrete
fill 206 296 358 206 297 358 minecraft:light_gray_concrete
fill 206 296 360 206 297 360 minecraft:light_gray_concrete
fill 206 296 362 206 297 362 minecraft:light_gray_concrete
fill 207 296 357 207 297 357 minecraft:light_gray_concrete
fill 207 296 359 207 297 359 minecraft:light_gray_concrete
fill 207 296 361 207 297 361 minecraft:light_gray_concrete
fill 207 296 363 207 297 363 minecraft:light_gray_concrete
fill 211 296 323 211 297 323 minecraft:light_gray_concrete
fill 211 296 325 211 297 325 minecraft:light_gray_concrete
fill 211 296 327 211 297 327 minecraft:light_gray_concrete
fill 212 296 324 212 297 324 minecraft:light_gray_concrete
fill 212 296 326 212 297 326 minecraft:light_gray_concrete
fill 213 296 323 213 297 323 minecraft:light_gray_concrete
fill 213 296 325 213 297 325 minecraft:light_gray_concrete
fill 213 296 327 213 297 327 minecraft:light_gray_concrete
fill 214 296 324 214 297 324 minecraft:light_gray_concrete
fill 214 296 326 214 297 326 minecraft:light_gray_concrete
fill 215 296 323 215 297 323 minecraft:light_gray_concrete
fill 215 296 325 215 297 325 minecraft:light_gray_concrete
fill 215 296 327 215 297 327 minecraft:light_gray_concrete
fill 216 296 324 216 297 324 minecraft:light_gray_concrete
fill 216 296 326 216 297 326 minecraft:light_gray_concrete
fill 217 296 323 217 297 323 minecraft:light_gray_concrete
fill 217 296 325 217 297 325 minecraft:light_gray_concrete
fill 217 296 327 217 297 327 minecraft:light_gray_concrete
fill 218 296 324 218 297 324 minecraft:light_gray_concrete
fill 218 296 326 218 297 326 minecraft:light_gray_concrete
fill 219 296 323 219 297 323 minecraft:light_gray_concrete
fill 219 296 325 219 297 325 minecraft:light_gray_concrete
fill 219 296 327 219 297 327 minecraft:light_gray_concrete
fill 229 296 364 229 300 364 minecraft:black_concrete
setblock 230 296 331 minecraft:sea_lantern
setblock 230 296 360 minecraft:white_concrete
fill 188 297 344 188 308 344 minecraft:black_concrete
setblock 188 297 350 minecraft:white_concrete
fill 191 297 322 191 306 322 minecraft:black_concrete
setblock 191 297 325 minecraft:light[level=15]
setblock 191 297 333 minecraft:light[level=15]
setblock 191 297 341 minecraft:light[level=15]
setblock 191 297 349 minecraft:light[level=15]
setblock 191 297 357 minecraft:light[level=15]
setblock 199 297 325 minecraft:light[level=15]
setblock 199 297 333 minecraft:light[level=15]
setblock 199 297 341 minecraft:light[level=15]
setblock 199 297 349 minecraft:light[level=15]
fill 202 297 364 202 308 364 minecraft:black_concrete
setblock 207 297 325 minecraft:light[level=15]
setblock 207 297 333 minecraft:light[level=15]
setblock 207 297 341 minecraft:light[level=15]
setblock 207 297 349 minecraft:light[level=15]
fill 208 297 333 210 298 333 minecraft:gray_concrete
setblock 209 297 322 minecraft:pearlescent_froglight
fill 209 297 334 209 298 334 minecraft:gray_concrete
setblock 212 297 322 minecraft:sea_lantern
setblock 215 297 333 minecraft:light[level=15]
setblock 215 297 341 minecraft:light[level=15]
setblock 215 297 349 minecraft:light[level=15]
setblock 215 297 357 minecraft:light[level=15]
setblock 223 297 325 minecraft:light[level=15]
setblock 223 297 333 minecraft:light[level=15]
setblock 223 297 341 minecraft:light[level=15]
setblock 223 297 349 minecraft:light[level=15]
setblock 223 297 357 minecraft:light[level=15]
fill 230 297 331 230 308 331 minecraft:black_concrete
fill 230 297 360 230 308 360 minecraft:black_concrete
fill 188 298 350 188 308 350 minecraft:black_concrete
setblock 191 298 364 minecraft:ochre_froglight
setblock 199 298 357 minecraft:verdant_froglight
setblock 199 298 359 minecraft:verdant_froglight
setblock 199 298 361 minecraft:verdant_froglight
setblock 199 298 363 minecraft:verdant_froglight
setblock 200 298 356 minecraft:verdant_froglight
setblock 200 298 358 minecraft:verdant_froglight
setblock 200 298 360 minecraft:verdant_froglight
setblock 200 298 362 minecraft:verdant_froglight
setblock 201 298 357 minecraft:verdant_froglight
setblock 201 298 359 minecraft:verdant_froglight
setblock 201 298 361 minecraft:verdant_froglight
setblock 201 298 363 minecraft:verdant_froglight
setblock 202 298 356 minecraft:verdant_froglight
setblock 202 298 358 minecraft:verdant_froglight
setblock 202 298 360 minecraft:verdant_froglight
setblock 202 298 362 minecraft:verdant_froglight
setblock 203 298 357 minecraft:verdant_froglight
setblock 203 298 359 minecraft:verdant_froglight
setblock 203 298 361 minecraft:verdant_froglight
setblock 203 298 363 minecraft:verdant_froglight
setblock 204 298 356 minecraft:verdant_froglight
setblock 204 298 358 minecraft:verdant_froglight
setblock 204 298 360 minecraft:verdant_froglight
setblock 204 298 362 minecraft:verdant_froglight
setblock 205 298 357 minecraft:verdant_froglight
setblock 205 298 359 minecraft:verdant_froglight
setblock 205 298 361 minecraft:verdant_froglight
setblock 205 298 363 minecraft:verdant_froglight
setblock 206 298 356 minecraft:verdant_froglight
setblock 206 298 358 minecraft:verdant_froglight
setblock 206 298 360 minecraft:verdant_froglight
setblock 206 298 362 minecraft:verdant_froglight
setblock 207 298 357 minecraft:verdant_froglight
setblock 207 298 359 minecraft:verdant_froglight
setblock 207 298 361 minecraft:verdant_froglight
setblock 207 298 363 minecraft:verdant_froglight
fill 209 298 322 209 308 322 minecraft:black_concrete
setblock 211 298 323 minecraft:verdant_froglight
setblock 211 298 325 minecraft:verdant_froglight
setblock 211 298 327 minecraft:verdant_froglight
fill 212 298 322 212 308 322 minecraft:black_concrete
setblock 212 298 324 minecraft:verdant_froglight
setblock 212 298 326 minecraft:verdant_froglight
setblock 213 298 323 minecraft:verdant_froglight
setblock 213 298 325 minecraft:verdant_froglight
setblock 213 298 327 minecraft:verdant_froglight
setblock 213 298 364 minecraft:pearlescent_froglight
setblock 214 298 324 minecraft:verdant_froglight
setblock 214 298 326 minecraft:verdant_froglight
setblock 215 298 323 minecraft:verdant_froglight
setblock 215 298 325 minecraft:verdant_froglight
setblock 215 298 327 minecraft:verdant_froglight
setblock 216 298 324 minecraft:verdant_froglight
setblock 216 298 326 minecraft:verdant_froglight
setblock 217 298 323 minecraft:verdant_froglight
setblock 217 298 325 minecraft:verdant_froglight
setblock 217 298 327 minecraft:verdant_froglight
setblock 218 298 324 minecraft:verdant_froglight
setblock 218 298 326 minecraft:verdant_froglight
setblock 219 298 323 minecraft:verdant_froglight
setblock 219 298 325 minecraft:verdant_froglight
setblock 219 298 327 minecraft:verdant_froglight
setblock 223 298 322 minecraft:sea_lantern
setblock 223 298 364 minecraft:pearlescent_froglight
setblock 230 298 359 minecraft:white_concrete
setblock 230 298 361 minecraft:ochre_froglight
setblock 189 299 322 minecraft:pearlescent_froglight
fill 191 299 364 191 308 364 minecraft:black_concrete
setblock 195 299 322 minecraft:pearlescent_froglight
fill 199 299 357 199 300 357 minecraft:light_gray_concrete
fill 199 299 359 199 300 359 minecraft:light_gray_concrete
fill 199 299 361 199 300 361 minecraft:light_gray_concrete
fill 199 299 363 199 300 363 minecraft:light_gray_concrete
fill 200 299 356 200 300 356 minecraft:light_gray_concrete
fill 200 299 358 200 300 358 minecraft:light_gray_concrete
fill 200 299 360 200 300 360 minecraft:light_gray_concrete
fill 200 299 362 200 300 362 minecraft:light_gray_concrete
fill 201 299 357 201 300 357 minecraft:light_gray_concrete
fill 201 299 359 201 300 359 minecraft:light_gray_concrete
fill 201 299 361 201 300 361 minecraft:light_gray_concrete
fill 201 299 363 201 300 363 minecraft:light_gray_concrete
fill 202 299 356 202 300 356 minecraft:light_gray_concrete
fill 202 299 358 202 300 358 minecraft:light_gray_concrete
fill 202 299 360 202 300 360 minecraft:light_gray_concrete
fill 202 299 362 202 300 362 minecraft:light_gray_concrete
fill 203 299 357 203 300 357 minecraft:light_gray_concrete
fill 203 299 359 203 300 359 minecraft:light_gray_concrete
fill 203 299 361 203 300 361 minecraft:light_gray_concrete
fill 203 299 363 203 300 363 minecraft:light_gray_concrete
fill 204 299 356 204 300 356 minecraft:light_gray_concrete
fill 204 299 358 204 300 358 minecraft:light_gray_concrete
fill 204 299 360 204 300 360 minecraft:light_gray_concrete
fill 204 299 362 204 300 362 minecraft:light_gray_concrete
fill 205 299 357 205 300 357 minecraft:light_gray_concrete
fill 205 299 359 205 300 359 minecraft:light_gray_concrete
fill 205 299 361 205 300 361 minecraft:light_gray_concrete
fill 205 299 363 205 300 363 minecraft:light_gray_concrete
fill 206 299 356 206 300 356 minecraft:light_gray_concrete
fill 206 299 358 206 300 358 minecraft:light_gray_concrete
fill 206 299 360 206 300 360 minecraft:light_gray_concrete
fill 206 299 362 206 300 362 minecraft:light_gray_concrete
fill 207 299 357 207 300 357 minecraft:light_gray_concrete
fill 207 299 359 207 300 359 minecraft:light_gray_concrete
fill 207 299 361 207 300 361 minecraft:light_gray_concrete
fill 207 299 363 207 300 363 minecraft:light_gray_concrete
fill 211 299 323 211 300 323 minecraft:light_gray_concrete
fill 211 299 325 211 300 325 minecraft:light_gray_concrete
fill 211 299 327 211 300 327 minecraft:light_gray_concrete
fill 212 299 324 212 300 324 minecraft:light_gray_concrete
fill 212 299 326 212 300 326 minecraft:light_gray_concrete
fill 213 299 323 213 300 323 minecraft:light_gray_concrete
fill 213 299 325 213 300 325 minecraft:light_gray_concrete
fill 213 299 327 213 300 327 minecraft:light_gray_concrete
fill 213 299 364 213 308 364 minecraft:black_concrete
fill 214 299 324 214 300 324 minecraft:light_gray_concrete
fill 214 299 326 214 300 326 minecraft:light_gray_concrete
fill 215 299 323 215 300 323 minecraft:light_gray_concrete
fill 215 299 325 215 300 325 minecraft:light_gray_concrete
fill 215 299 327 215 300 327 minecraft:light_gray_concrete
fill 216 299 324 216 300 324 minecraft:light_gray_concrete
fill 216 299 326 216 300 326 minecraft:light_gray_concrete
fill 217 299 323 217 300 323 minecraft:light_gray_concrete
fill 217 299 325 217 300 325 minecraft:light_gray_concrete
fill 217 299 327 217 300 327 minecraft:light_gray_concrete
fill 218 299 324 218 300 324 minecraft:light_gray_concrete
fill 218 299 326 218 300 326 minecraft:light_gray_concrete
fill 219 299 323 219 300 323 minecraft:light_gray_concrete
fill 219 299 325 219 300 325 minecraft:light_gray_concrete
fill 219 299 327 219 300 327 minecraft:light_gray_concrete
fill 223 299 322 223 308 322 minecraft:black_concrete
fill 223 299 364 223 308 364 minecraft:black_concrete
fill 230 299 359 230 308 359 minecraft:black_concrete
fill 230 299 361 230 308 361 minecraft:black_concrete
setblock 188 300 353 minecraft:white_concrete
fill 189 300 322 189 307 322 minecraft:black_concrete
setblock 190 300 364 minecraft:sea_lantern
setblock 195 300 322 minecraft:ochre_froglight
setblock 205 300 364 minecraft:ochre_froglight
setblock 214 300 364 minecraft:sea_lantern
setblock 216 300 364 minecraft:ochre_froglight
setblock 221 300 322 minecraft:sea_lantern
fill 228 300 322 228 301 322 minecraft:sea_lantern
setblock 188 301 348 minecraft:ochre_froglight
setblock 188 301 351 minecraft:pearlescent_froglight
fill 188 301 353 188 308 353 minecraft:black_concrete
fill 190 301 364 190 308 364 minecraft:black_concrete
setblock 191 301 325 minecraft:light[level=12]
setblock 191 301 332 minecraft:light[level=12]
setblock 191 301 339 minecraft:light[level=12]
setblock 191 301 346 minecraft:light[level=12]
setblock 191 301 353 minecraft:light[level=12]
setblock 191 301 360 minecraft:light[level=12]
setblock 193 301 322 minecraft:ochre_froglight
fill 195 301 322 195 308 322 minecraft:black_concrete
setblock 198 301 325 minecraft:light[level=12]
setblock 198 301 332 minecraft:light[level=12]
setblock 198 301 339 minecraft:light[level=12]
setblock 198 301 346 minecraft:light[level=12]
setblock 198 301 353 minecraft:light[level=12]
setblock 198 301 360 minecraft:light[level=12]
setblock 205 301 325 minecraft:light[level=12]
setblock 205 301 332 minecraft:light[level=12]
setblock 205 301 339 minecraft:light[level=12]
setblock 205 301 346 minecraft:light[level=12]
setblock 205 301 353 minecraft:light[level=12]
setblock 205 301 360 minecraft:light[level=12]
fill 205 301 364 205 308 364 minecraft:black_concrete
setblock 212 301 325 minecraft:light[level=12]
setblock 212 301 332 minecraft:light[level=12]
setblock 212 301 339 minecraft:light[level=12]
setblock 212 301 346 minecraft:light[level=12]
setblock 212 301 353 minecraft:light[level=12]
setblock 212 301 360 minecraft:light[level=12]
fill 214 301 364 214 305 364 minecraft:black_concrete
fill 216 301 364 216 302 364 minecraft:black_concrete
setblock 219 301 325 minecraft:light[level=12]
setblock 219 301 332 minecraft:light[level=12]
setblock 219 301 339 minecraft:light[level=12]
setblock 219 301 346 minecraft:light[level=12]
setblock 219 301 353 minecraft:light[level=12]
setblock 219 301 360 minecraft:light[level=12]
fill 221 301 322 221 308 322 minecraft:black_concrete
setblock 225 301 364 minecraft:sea_lantern
setblock 226 301 325 minecraft:light[level=12]
setblock 226 301 332 minecraft:light[level=12]
setblock 226 301 339 minecraft:light[level=12]
setblock 226 301 346 minecraft:light[level=12]
setblock 226 301 353 minecraft:light[level=12]
setblock 226 301 360 minecraft:light[level=12]
fill 226 301 364 226 308 364 minecraft:black_concrete
setblock 229 301 364 minecraft:white_concrete
fill 188 302 348 188 308 348 minecraft:black_concrete
fill 188 302 351 188 308 351 minecraft:black_concrete
fill 193 302 322 193 308 322 minecraft:black_concrete
fill 225 302 364 225 308 364 minecraft:black_concrete
fill 228 302 322 228 306 322 minecraft:black_concrete
fill 229 302 364 229 308 364 minecraft:black_concrete
setblock 188 303 336 minecraft:sea_lantern
setblock 188 303 359 minecraft:pearlescent_froglight
setblock 216 303 364 minecraft:pearlescent_froglight
fill 188 304 336 188 308 336 minecraft:black_concrete
fill 188 304 359 188 308 359 minecraft:black_concrete
setblock 188 304 360 minecraft:ochre_froglight
setblock 188 304 363 minecraft:white_concrete
fill 216 304 364 216 308 364 minecraft:black_concrete
fill 188 305 360 188 308 360 minecraft:black_concrete
fill 188 305 363 188 308 363 minecraft:black_concrete
setblock 188 306 325 minecraft:white_concrete
setblock 214 306 364 minecraft:sea_lantern
setblock 227 306 322 minecraft:pearlescent_froglight
setblock 188 307 323 minecraft:white_concrete
fill 188 307 325 188 308 325 minecraft:black_concrete
setblock 191 307 322 minecraft:pearlescent_froglight
fill 214 307 364 214 308 364 minecraft:black_concrete
fill 227 307 322 227 308 322 minecraft:black_concrete
setblock 228 307 322 minecraft:sea_lantern
setblock 230 307 358 minecraft:ochre_froglight
setblock 188 308 323 minecraft:black_concrete
setblock 188 308 324 minecraft:white_concrete
setblock 188 308 356 minecraft:sea_lantern
setblock 189 308 322 minecraft:ochre_froglight
setblock 191 308 322 minecraft:black_concrete
setblock 228 308 322 minecraft:black_concrete
setblock 230 308 358 minecraft:black_concrete
