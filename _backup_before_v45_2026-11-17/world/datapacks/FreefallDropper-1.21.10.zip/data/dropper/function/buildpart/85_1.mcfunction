fill 62 122 369 62 143 369 minecraft:purple_concrete
fill 66 122 411 66 143 411 minecraft:purple_concrete
fill 70 122 369 70 143 369 minecraft:purple_concrete
fill 72 122 378 72 123 378 minecraft:cyan_concrete
fill 74 122 411 74 143 411 minecraft:purple_concrete
fill 78 122 369 78 143 369 minecraft:purple_concrete
fill 82 122 411 82 143 411 minecraft:purple_concrete
fill 86 122 369 86 143 369 minecraft:purple_concrete
fill 89 122 374 89 143 374 minecraft:purple_concrete
fill 89 122 382 89 143 382 minecraft:purple_concrete
fill 89 122 390 89 143 390 minecraft:purple_concrete
fill 89 122 398 89 143 398 minecraft:purple_concrete
fill 89 122 406 89 143 406 minecraft:purple_concrete
fill 48 126 370 48 127 375 minecraft:magenta_concrete
fill 48 126 378 49 126 383 minecraft:magenta_concrete
fill 48 126 386 49 126 391 minecraft:magenta_concrete
fill 48 126 394 49 126 399 minecraft:magenta_concrete
fill 48 126 402 49 126 407 minecraft:magenta_concrete
fill 48 126 410 53 127 410 minecraft:magenta_concrete
fill 49 126 371 49 126 377 minecraft:magenta_concrete
fill 49 126 384 49 126 385 minecraft:magenta_concrete
fill 49 126 392 49 126 393 minecraft:magenta_concrete
fill 49 126 400 49 126 401 minecraft:magenta_concrete
fill 49 126 408 49 126 409 minecraft:magenta_concrete
fill 50 126 371 87 126 371 minecraft:magenta_concrete
fill 50 126 409 88 126 409 minecraft:magenta_concrete
fill 51 126 370 56 127 370 minecraft:magenta_concrete
fill 56 126 410 61 127 410 minecraft:magenta_concrete
fill 59 126 370 64 127 370 minecraft:magenta_concrete
fill 64 126 410 69 127 410 minecraft:magenta_concrete
fill 67 126 370 72 127 370 minecraft:magenta_concrete
fill 72 126 410 77 127 410 minecraft:magenta_concrete
fill 75 126 370 80 127 370 minecraft:magenta_concrete
fill 80 126 410 85 127 410 minecraft:magenta_concrete
fill 83 126 370 88 127 370 minecraft:magenta_concrete
fill 87 126 372 87 126 408 minecraft:magenta_concrete
fill 88 126 373 88 127 378 minecraft:magenta_concrete
fill 88 126 381 88 127 386 minecraft:magenta_concrete
fill 88 126 389 88 127 394 minecraft:magenta_concrete
fill 88 126 397 88 127 402 minecraft:magenta_concrete
fill 88 126 405 88 127 408 minecraft:magenta_concrete
fill 88 126 410 88 127 410 minecraft:magenta_concrete
fill 48 127 378 48 127 383 minecraft:magenta_concrete
fill 48 127 386 48 127 391 minecraft:magenta_concrete
fill 48 127 394 48 127 399 minecraft:magenta_concrete
fill 48 127 402 48 127 407 minecraft:magenta_concrete
setblock 88 127 409 minecraft:magenta_concrete
setblock 50 129 372 minecraft:light[level=14]
setblock 50 129 380 minecraft:light[level=14]
setblock 50 129 388 minecraft:light[level=14]
setblock 50 129 396 minecraft:light[level=14]
setblock 50 129 404 minecraft:light[level=14]
setblock 58 129 372 minecraft:light[level=14]
setblock 58 129 380 minecraft:light[level=14]
setblock 58 129 388 minecraft:light[level=14]
setblock 58 129 396 minecraft:light[level=14]
setblock 58 129 404 minecraft:light[level=14]
setblock 66 129 372 minecraft:light[level=14]
setblock 66 129 380 minecraft:light[level=14]
setblock 66 129 388 minecraft:light[level=14]
setblock 66 129 396 minecraft:light[level=14]
setblock 66 129 404 minecraft:light[level=14]
setblock 74 129 372 minecraft:light[level=14]
setblock 74 129 380 minecraft:light[level=14]
setblock 74 129 388 minecraft:light[level=14]
setblock 74 129 396 minecraft:light[level=14]
setblock 74 129 404 minecraft:light[level=14]
setblock 82 129 372 minecraft:light[level=14]
setblock 82 129 380 minecraft:light[level=14]
setblock 82 129 388 minecraft:light[level=14]
setblock 82 129 396 minecraft:light[level=14]
setblock 82 129 404 minecraft:light[level=14]
fill 48 133 370 50 134 410 minecraft:black_concrete
fill 51 133 370 51 134 410 minecraft:yellow_concrete
fill 52 133 370 54 134 410 minecraft:black_concrete
fill 55 133 370 55 134 410 minecraft:yellow_concrete
fill 56 133 370 58 134 410 minecraft:black_concrete
fill 59 133 370 59 134 410 minecraft:yellow_concrete
fill 60 133 370 61 133 410 minecraft:black_concrete
fill 62 133 370 62 133 386 minecraft:black_concrete
fill 62 133 390 62 133 410 minecraft:black_concrete
fill 63 133 370 63 133 385 minecraft:yellow_concrete
fill 63 133 391 63 133 410 minecraft:yellow_concrete
fill 64 133 370 66 133 385 minecraft:black_concrete
fill 64 133 391 66 133 410 minecraft:black_concrete
setblock 66 133 386 minecraft:black_concrete
setblock 66 133 390 minecraft:black_concrete
fill 67 133 370 67 133 410 minecraft:yellow_concrete
fill 68 133 370 70 134 410 minecraft:black_concrete
fill 71 133 370 71 134 410 minecraft:yellow_concrete
fill 72 133 370 74 134 410 minecraft:black_concrete
fill 75 133 370 75 134 410 minecraft:yellow_concrete
fill 76 133 370 78 134 410 minecraft:black_concrete
fill 79 133 370 79 134 410 minecraft:yellow_concrete
fill 80 133 370 82 134 410 minecraft:black_concrete
fill 83 133 370 83 134 410 minecraft:yellow_concrete
fill 84 133 370 86 134 410 minecraft:black_concrete
fill 87 133 370 87 134 410 minecraft:yellow_concrete
fill 88 133 370 88 134 410 minecraft:black_concrete
fill 60 134 370 60 134 410 minecraft:black_concrete
fill 61 134 370 61 134 385 minecraft:black_concrete
fill 61 134 386 61 134 390 minecraft:sea_lantern
fill 61 134 391 61 134 410 minecraft:black_concrete
fill 62 134 370 62 134 384 minecraft:black_concrete
fill 62 134 385 62 134 386 minecraft:sea_lantern
fill 62 134 390 62 134 391 minecraft:sea_lantern
fill 62 134 392 62 134 410 minecraft:black_concrete
fill 63 134 370 63 134 384 minecraft:yellow_concrete
fill 63 134 385 66 134 385 minecraft:sea_lantern
fill 63 134 391 66 134 391 minecraft:sea_lantern
fill 63 134 392 63 134 410 minecraft:yellow_concrete
fill 64 134 370 66 134 384 minecraft:black_concrete
fill 64 134 392 66 134 410 minecraft:black_concrete
fill 66 134 386 67 134 386 minecraft:sea_lantern
fill 66 134 390 67 134 390 minecraft:sea_lantern
fill 67 134 370 67 134 385 minecraft:yellow_concrete
fill 67 134 387 67 134 389 minecraft:sea_lantern
fill 67 134 391 67 134 410 minecraft:yellow_concrete
fill 50 135 388 52 149 388 minecraft:pink_concrete
fill 51 135 387 51 149 387 minecraft:pink_concrete
fill 51 135 389 51 149 389 minecraft:pink_concrete
fill 54 135 378 55 149 379 minecraft:light_blue_concrete
fill 54 135 397 55 149 398 minecraft:light_blue_concrete
fill 63 135 375 65 149 375 minecraft:pink_concrete
fill 63 135 401 65 149 401 minecraft:pink_concrete
fill 64 135 374 64 149 374 minecraft:pink_concrete
fill 64 135 376 64 149 376 minecraft:pink_concrete
fill 64 135 400 64 149 400 minecraft:pink_concrete
fill 64 135 402 64 149 402 minecraft:pink_concrete
fill 73 135 378 74 149 379 minecraft:light_blue_concrete
fill 73 135 397 74 149 398 minecraft:light_blue_concrete
fill 76 135 388 78 149 388 minecraft:pink_concrete
fill 77 135 387 77 149 387 minecraft:pink_concrete
fill 77 135 389 77 149 389 minecraft:pink_concrete
fill 57 136 387 58 137 389 minecraft:magenta_concrete
fill 58 136 385 58 137 386 minecraft:magenta_concrete
fill 58 136 390 58 137 391 minecraft:magenta_concrete
fill 59 136 383 59 137 384 minecraft:magenta_concrete
fill 59 136 392 59 137 393 minecraft:magenta_concrete
fill 60 136 383 60 137 383 minecraft:magenta_concrete
fill 60 136 393 60 137 393 minecraft:magenta_concrete
fill 61 136 382 67 137 382 minecraft:magenta_concrete
fill 61 136 394 67 137 394 minecraft:magenta_concrete
fill 63 136 381 65 137 381 minecraft:magenta_concrete
fill 63 136 395 65 137 395 minecraft:magenta_concrete
fill 68 136 383 69 137 383 minecraft:magenta_concrete
fill 68 136 393 69 137 393 minecraft:magenta_concrete
fill 69 136 384 69 137 384 minecraft:magenta_concrete
fill 69 136 392 69 137 392 minecraft:magenta_concrete
fill 70 136 385 70 137 391 minecraft:magenta_concrete
fill 71 136 387 71 137 389 minecraft:magenta_concrete
setblock 50 137 372 minecraft:light[level=14]
setblock 50 137 380 minecraft:light[level=14]
setblock 50 137 396 minecraft:light[level=14]
setblock 50 137 404 minecraft:light[level=14]
setblock 58 137 372 minecraft:light[level=14]
setblock 58 137 380 minecraft:light[level=14]
setblock 58 137 396 minecraft:light[level=14]
setblock 58 137 404 minecraft:light[level=14]
setblock 66 137 372 minecraft:light[level=14]
setblock 66 137 380 minecraft:light[level=14]
setblock 66 137 388 minecraft:light[level=14]
setblock 66 137 396 minecraft:light[level=14]
setblock 66 137 404 minecraft:light[level=14]
setblock 74 137 372 minecraft:light[level=14]
setblock 74 137 380 minecraft:light[level=14]
setblock 74 137 388 minecraft:light[level=14]
setblock 74 137 396 minecraft:light[level=14]
setblock 74 137 404 minecraft:light[level=14]
setblock 82 137 372 minecraft:light[level=14]
setblock 82 137 380 minecraft:light[level=14]
setblock 82 137 388 minecraft:light[level=14]
setblock 82 137 396 minecraft:light[level=14]
setblock 82 137 404 minecraft:light[level=14]
fill 48 138 376 48 209 377 minecraft:magenta_concrete
fill 48 138 384 48 209 385 minecraft:magenta_concrete
fill 48 138 392 48 209 393 minecraft:magenta_concrete
fill 48 138 400 48 209 401 minecraft:magenta_concrete
fill 48 138 408 48 209 409 minecraft:magenta_concrete
fill 49 138 370 50 209 370 minecraft:magenta_concrete
fill 54 138 410 55 209 410 minecraft:magenta_concrete
fill 57 138 370 66 161 370 minecraft:magenta_concrete
fill 58 138 371 63 161 374 minecraft:magenta_concrete
fill 62 138 410 63 209 410 minecraft:magenta_concrete
fill 64 138 371 64 161 373 minecraft:magenta_concrete
fill 70 138 410 71 209 410 minecraft:magenta_concrete
fill 73 138 370 74 209 370 minecraft:magenta_concrete
fill 78 138 410 79 209 410 minecraft:magenta_concrete
fill 81 138 370 82 209 370 minecraft:magenta_concrete
fill 83 138 375 87 138 377 minecraft:cyan_concrete
fill 84 138 374 86 138 374 minecraft:cyan_concrete
fill 84 138 378 86 138 378 minecraft:cyan_concrete
fill 84 138 379 88 138 387 minecraft:magenta_concrete
fill 86 138 410 87 209 410 minecraft:magenta_concrete
fill 88 138 371 88 209 372 minecraft:magenta_concrete
fill 88 138 388 88 209 388 minecraft:magenta_concrete
fill 88 138 395 88 209 396 minecraft:magenta_concrete
fill 88 138 403 88 209 404 minecraft:magenta_concrete
fill 83 139 376 87 139 376 minecraft:cyan_concrete
fill 84 139 375 86 139 375 minecraft:cyan_concrete
fill 84 139 377 86 139 377 minecraft:cyan_concrete
fill 84 139 379 84 152 379 minecraft:magenta_concrete
setblock 84 139 380 minecraft:sea_lantern
fill 84 139 381 84 152 381 minecraft:magenta_concrete
setblock 84 139 382 minecraft:sea_lantern
fill 84 139 383 84 152 383 minecraft:magenta_concrete
setblock 84 139 384 minecraft:sea_lantern
fill 84 139 385 84 152 385 minecraft:magenta_concrete
setblock 84 139 386 minecraft:sea_lantern
fill 84 139 387 84 152 387 minecraft:magenta_concrete
setblock 85 139 374 minecraft:cyan_concrete
setblock 85 139 378 minecraft:cyan_concrete
setblock 85 139 379 minecraft:sea_lantern
fill 85 139 380 85 152 380 minecraft:magenta_concrete
setblock 85 139 381 minecraft:sea_lantern
fill 85 139 382 85 152 382 minecraft:magenta_concrete
setblock 85 139 383 minecraft:sea_lantern
fill 85 139 384 85 152 384 minecraft:magenta_concrete
setblock 85 139 385 minecraft:sea_lantern
fill 85 139 386 85 152 386 minecraft:magenta_concrete
setblock 85 139 387 minecraft:sea_lantern
fill 86 139 379 86 152 379 minecraft:magenta_concrete
setblock 86 139 380 minecraft:sea_lantern
fill 86 139 381 86 152 381 minecraft:magenta_concrete
setblock 86 139 382 minecraft:sea_lantern
fill 86 139 383 86 152 383 minecraft:magenta_concrete
setblock 86 139 384 minecraft:sea_lantern
fill 86 139 385 86 152 385 minecraft:magenta_concrete
setblock 86 139 386 minecraft:sea_lantern
fill 86 139 387 86 152 387 minecraft:magenta_concrete
setblock 87 139 379 minecraft:sea_lantern
fill 87 139 380 87 152 380 minecraft:magenta_concrete
setblock 87 139 381 minecraft:sea_lantern
fill 87 139 382 87 152 382 minecraft:magenta_concrete
setblock 87 139 383 minecraft:sea_lantern
fill 87 139 384 87 152 384 minecraft:magenta_concrete
setblock 87 139 385 minecraft:sea_lantern
fill 87 139 386 87 152 386 minecraft:magenta_concrete
setblock 87 139 387 minecraft:sea_lantern
fill 88 139 379 88 209 379 minecraft:magenta_concrete
setblock 88 139 380 minecraft:sea_lantern
fill 88 139 381 88 152 381 minecraft:magenta_concrete
setblock 88 139 382 minecraft:sea_lantern
fill 88 139 383 88 152 383 minecraft:magenta_concrete
setblock 88 139 384 minecraft:sea_lantern
fill 88 139 385 88 152 385 minecraft:magenta_concrete
setblock 88 139 386 minecraft:sea_lantern
fill 88 139 387 88 209 387 minecraft:magenta_concrete
fill 48 140 370 48 141 375 minecraft:magenta_concrete
fill 48 140 378 49 140 383 minecraft:magenta_concrete
fill 48 140 386 49 140 391 minecraft:magenta_concrete
fill 48 140 394 49 140 399 minecraft:magenta_concrete
fill 48 140 402 49 140 407 minecraft:magenta_concrete
fill 48 140 410 53 141 410 minecraft:magenta_concrete
fill 49 140 371 49 140 377 minecraft:magenta_concrete
fill 49 140 384 49 140 385 minecraft:magenta_concrete
fill 49 140 392 49 140 393 minecraft:magenta_concrete
fill 49 140 400 49 140 401 minecraft:magenta_concrete
fill 49 140 408 49 140 409 minecraft:magenta_concrete
fill 50 140 371 57 140 371 minecraft:magenta_concrete
fill 50 140 409 88 140 409 minecraft:magenta_concrete
fill 51 140 370 56 141 370 minecraft:magenta_concrete
fill 55 140 387 56 141 389 minecraft:cyan_concrete
fill 56 140 384 56 141 386 minecraft:cyan_concrete
fill 56 140 390 56 141 392 minecraft:cyan_concrete
fill 56 140 410 61 141 410 minecraft:magenta_concrete
fill 57 140 383 57 141 384 minecraft:cyan_concrete
fill 57 140 392 57 141 393 minecraft:cyan_concrete
fill 58 140 382 58 141 382 minecraft:cyan_concrete
fill 58 140 394 58 141 394 minecraft:cyan_concrete
fill 59 140 381 60 141 381 minecraft:cyan_concrete
fill 59 140 395 60 141 395 minecraft:cyan_concrete
fill 60 140 380 68 141 380 minecraft:cyan_concrete
fill 60 140 396 68 141 396 minecraft:cyan_concrete
fill 63 140 379 65 141 379 minecraft:cyan_concrete
fill 63 140 397 65 141 397 minecraft:cyan_concrete
fill 64 140 410 69 141 410 minecraft:magenta_concrete
fill 65 140 371 87 140 371 minecraft:magenta_concrete
fill 67 140 370 72 141 370 minecraft:magenta_concrete
fill 68 140 381 69 141 381 minecraft:cyan_concrete
fill 68 140 395 69 141 395 minecraft:cyan_concrete
fill 70 140 382 70 141 382 minecraft:cyan_concrete
fill 70 140 394 70 141 394 minecraft:cyan_concrete
fill 71 140 383 71 141 384 minecraft:cyan_concrete
fill 71 140 392 71 141 393 minecraft:cyan_concrete
fill 72 140 384 72 141 392 minecraft:cyan_concrete
fill 72 140 410 77 141 410 minecraft:magenta_concrete
fill 73 140 387 73 141 389 minecraft:cyan_concrete
fill 75 140 370 80 141 370 minecraft:magenta_concrete
fill 80 140 410 85 141 410 minecraft:magenta_concrete
fill 83 140 370 88 141 370 minecraft:magenta_concrete
fill 84 140 380 84 141 380 minecraft:magenta_concrete
fill 84 140 382 84 141 382 minecraft:magenta_concrete
fill 84 140 384 84 141 384 minecraft:magenta_concrete
fill 84 140 386 84 141 386 minecraft:magenta_concrete
setblock 85 140 376 minecraft:cyan_concrete
fill 85 140 379 85 141 379 minecraft:magenta_concrete
fill 85 140 381 85 141 381 minecraft:magenta_concrete
fill 85 140 383 85 141 383 minecraft:magenta_concrete
fill 85 140 385 85 141 385 minecraft:magenta_concrete
fill 85 140 387 85 141 387 minecraft:magenta_concrete
fill 86 140 380 86 141 380 minecraft:magenta_concrete
fill 86 140 382 86 141 382 minecraft:magenta_concrete
fill 86 140 384 86 141 384 minecraft:magenta_concrete
fill 86 140 386 86 141 386 minecraft:magenta_concrete
fill 87 140 372 87 140 379 minecraft:magenta_concrete
fill 87 140 381 87 141 381 minecraft:magenta_concrete
fill 87 140 383 87 141 383 minecraft:magenta_concrete
fill 87 140 385 87 141 385 minecraft:magenta_concrete
fill 87 140 387 87 140 408 minecraft:magenta_concrete
fill 88 140 373 88 141 378 minecraft:magenta_concrete
fill 88 140 380 88 141 380 minecraft:magenta_concrete
fill 88 140 382 88 141 382 minecraft:magenta_concrete
fill 88 140 384 88 141 384 minecraft:magenta_concrete
fill 88 140 386 88 141 386 minecraft:magenta_concrete
fill 88 140 389 88 141 394 minecraft:magenta_concrete
fill 88 140 397 88 141 402 minecraft:magenta_concrete
fill 88 140 405 88 141 408 minecraft:magenta_concrete
fill 88 140 410 88 141 410 minecraft:magenta_concrete
fill 48 141 378 48 141 383 minecraft:magenta_concrete
fill 48 141 386 48 141 391 minecraft:magenta_concrete
fill 48 141 394 48 141 399 minecraft:magenta_concrete
fill 48 141 402 48 141 407 minecraft:magenta_concrete
setblock 87 141 379 minecraft:magenta_concrete
setblock 87 141 387 minecraft:magenta_concrete
setblock 88 141 409 minecraft:magenta_concrete
setblock 84 142 380 minecraft:sea_lantern
setblock 84 142 382 minecraft:sea_lantern
setblock 84 142 384 minecraft:sea_lantern
setblock 84 142 386 minecraft:sea_lantern
setblock 85 142 379 minecraft:sea_lantern
setblock 85 142 381 minecraft:sea_lantern
setblock 85 142 383 minecraft:sea_lantern
setblock 85 142 385 minecraft:sea_lantern
setblock 85 142 387 minecraft:sea_lantern
setblock 86 142 380 minecraft:sea_lantern
setblock 86 142 382 minecraft:sea_lantern
setblock 86 142 384 minecraft:sea_lantern
setblock 86 142 386 minecraft:sea_lantern
setblock 87 142 379 minecraft:sea_lantern
setblock 87 142 381 minecraft:sea_lantern
setblock 87 142 383 minecraft:sea_lantern
setblock 87 142 385 minecraft:sea_lantern
setblock 87 142 387 minecraft:sea_lantern
setblock 88 142 380 minecraft:sea_lantern
setblock 88 142 382 minecraft:sea_lantern
setblock 88 142 384 minecraft:sea_lantern
setblock 88 142 386 minecraft:sea_lantern
fill 80 143 407 80 144 409 minecraft:gray_concrete
fill 84 143 380 84 144 380 minecraft:magenta_concrete
fill 84 143 382 84 144 382 minecraft:magenta_concrete
fill 84 143 384 84 144 384 minecraft:magenta_concrete
fill 84 143 386 84 144 386 minecraft:magenta_concrete
fill 85 143 379 85 144 379 minecraft:magenta_concrete
fill 85 143 381 85 144 381 minecraft:magenta_concrete
fill 85 143 383 85 144 383 minecraft:magenta_concrete
fill 85 143 385 85 144 385 minecraft:magenta_concrete
fill 85 143 387 85 144 387 minecraft:magenta_concrete
fill 86 143 380 86 144 380 minecraft:magenta_concrete
fill 86 143 382 86 144 382 minecraft:magenta_concrete
fill 86 143 384 86 144 384 minecraft:magenta_concrete
fill 86 143 386 86 144 386 minecraft:magenta_concrete
fill 87 143 379 87 144 379 minecraft:magenta_concrete
fill 87 143 381 87 144 381 minecraft:magenta_concrete
fill 87 143 383 87 144 383 minecraft:magenta_concrete
fill 87 143 385 87 144 385 minecraft:magenta_concrete
fill 87 143 387 87 144 387 minecraft:magenta_concrete
fill 88 143 380 88 144 380 minecraft:magenta_concrete
fill 88 143 382 88 144 382 minecraft:magenta_concrete
fill 88 143 384 88 144 384 minecraft:magenta_concrete
fill 88 143 386 88 144 386 minecraft:magenta_concrete
fill 47 144 374 47 149 374 minecraft:sea_lantern
fill 47 144 382 47 149 382 minecraft:sea_lantern
fill 47 144 390 47 149 390 minecraft:sea_lantern
fill 47 144 398 47 149 398 minecraft:sea_lantern
fill 47 144 406 47 149 406 minecraft:sea_lantern
fill 50 144 411 50 149 411 minecraft:sea_lantern
fill 53 144 387 54 145 389 minecraft:lime_concrete
fill 54 144 369 54 149 369 minecraft:sea_lantern
fill 54 144 384 54 145 386 minecraft:lime_concrete
fill 54 144 390 54 145 392 minecraft:lime_concrete
fill 55 144 382 55 145 383 minecraft:lime_concrete
fill 55 144 393 55 145 394 minecraft:lime_concrete
fill 56 144 381 56 145 382 minecraft:lime_concrete
fill 56 144 394 56 145 395 minecraft:lime_concrete
fill 57 144 380 57 145 381 minecraft:lime_concrete
fill 57 144 395 57 145 396 minecraft:lime_concrete
fill 58 144 379 58 145 380 minecraft:lime_concrete
fill 58 144 396 58 145 397 minecraft:lime_concrete
fill 58 144 411 58 149 411 minecraft:sea_lantern
fill 59 144 379 59 145 379 minecraft:lime_concrete
fill 59 144 397 59 145 397 minecraft:lime_concrete
fill 60 144 378 68 145 378 minecraft:lime_concrete
fill 60 144 398 68 145 398 minecraft:lime_concrete
fill 62 144 369 62 149 369 minecraft:sea_lantern
fill 63 144 377 65 145 377 minecraft:lime_concrete
fill 63 144 399 65 145 399 minecraft:lime_concrete
fill 66 144 411 66 149 411 minecraft:sea_lantern
fill 69 144 379 70 145 379 minecraft:lime_concrete
fill 69 144 397 70 145 397 minecraft:lime_concrete
fill 70 144 369 70 149 369 minecraft:sea_lantern
fill 70 144 380 71 145 380 minecraft:lime_concrete
fill 70 144 396 71 145 396 minecraft:lime_concrete
fill 71 144 381 72 145 381 minecraft:lime_concrete
fill 71 144 395 72 145 395 minecraft:lime_concrete
fill 72 144 382 73 145 382 minecraft:lime_concrete
fill 72 144 394 73 145 394 minecraft:lime_concrete
fill 73 144 383 73 145 383 minecraft:lime_concrete
fill 73 144 393 73 145 393 minecraft:lime_concrete
fill 74 144 384 74 145 392 minecraft:lime_concrete
fill 74 144 411 74 149 411 minecraft:sea_lantern
fill 75 144 387 75 145 389 minecraft:lime_concrete
fill 78 144 369 78 149 369 minecraft:sea_lantern
fill 82 144 411 82 149 411 minecraft:sea_lantern
fill 86 144 369 86 149 369 minecraft:sea_lantern
fill 89 144 374 89 149 374 minecraft:sea_lantern
fill 89 144 382 89 149 382 minecraft:sea_lantern
fill 89 144 390 89 149 390 minecraft:sea_lantern
fill 89 144 398 89 149 398 minecraft:sea_lantern
fill 89 144 406 89 149 406 minecraft:sea_lantern
setblock 50 145 372 minecraft:light[level=14]
setblock 50 145 380 minecraft:light[level=14]
setblock 50 145 396 minecraft:light[level=14]
setblock 50 145 404 minecraft:light[level=14]
setblock 58 145 388 minecraft:light[level=14]
setblock 58 145 404 minecraft:light[level=14]
setblock 66 145 372 minecraft:light[level=14]
setblock 66 145 380 minecraft:light[level=14]
setblock 66 145 388 minecraft:light[level=14]
setblock 66 145 396 minecraft:light[level=14]
setblock 66 145 404 minecraft:light[level=14]
setblock 74 145 372 minecraft:light[level=14]
setblock 74 145 380 minecraft:light[level=14]
setblock 74 145 396 minecraft:light[level=14]
setblock 74 145 404 minecraft:light[level=14]
setblock 82 145 372 minecraft:light[level=14]
setblock 82 145 380 minecraft:light[level=14]
setblock 82 145 388 minecraft:light[level=14]
setblock 82 145 396 minecraft:light[level=14]
setblock 82 145 404 minecraft:light[level=14]
setblock 84 145 380 minecraft:sea_lantern
setblock 84 145 382 minecraft:sea_lantern
setblock 84 145 384 minecraft:sea_lantern
setblock 84 145 386 minecraft:sea_lantern
setblock 85 145 379 minecraft:sea_lantern
setblock 85 145 381 minecraft:sea_lantern
setblock 85 145 383 minecraft:sea_lantern
setblock 85 145 385 minecraft:sea_lantern
setblock 85 145 387 minecraft:sea_lantern
setblock 86 145 380 minecraft:sea_lantern
setblock 86 145 382 minecraft:sea_lantern
setblock 86 145 384 minecraft:sea_lantern
setblock 86 145 386 minecraft:sea_lantern
setblock 87 145 379 minecraft:sea_lantern
setblock 87 145 381 minecraft:sea_lantern
setblock 87 145 383 minecraft:sea_lantern
setblock 87 145 385 minecraft:sea_lantern
setblock 87 145 387 minecraft:sea_lantern
setblock 88 145 380 minecraft:sea_lantern
setblock 88 145 382 minecraft:sea_lantern
setblock 88 145 384 minecraft:sea_lantern
setblock 88 145 386 minecraft:sea_lantern
fill 84 146 380 84 147 380 minecraft:magenta_concrete
fill 84 146 382 84 147 382 minecraft:magenta_concrete
fill 84 146 384 84 147 384 minecraft:magenta_concrete
fill 84 146 386 84 147 386 minecraft:magenta_concrete
fill 85 146 379 85 147 379 minecraft:magenta_concrete
fill 85 146 381 85 147 381 minecraft:magenta_concrete
fill 85 146 383 85 147 383 minecraft:magenta_concrete
fill 85 146 385 85 147 385 minecraft:magenta_concrete
fill 85 146 387 85 147 387 minecraft:magenta_concrete
fill 86 146 380 86 147 380 minecraft:magenta_concrete
fill 86 146 382 86 147 382 minecraft:magenta_concrete
fill 86 146 384 86 147 384 minecraft:magenta_concrete
fill 86 146 386 86 147 386 minecraft:magenta_concrete
fill 87 146 379 87 147 379 minecraft:magenta_concrete
fill 87 146 381 87 147 381 minecraft:magenta_concrete
fill 87 146 383 87 147 383 minecraft:magenta_concrete
fill 87 146 385 87 147 385 minecraft:magenta_concrete
fill 87 146 387 87 147 387 minecraft:magenta_concrete
fill 88 146 380 88 147 380 minecraft:magenta_concrete
fill 88 146 382 88 147 382 minecraft:magenta_concrete
fill 88 146 384 88 147 384 minecraft:magenta_concrete
fill 88 146 386 88 147 386 minecraft:magenta_concrete
setblock 84 148 380 minecraft:sea_lantern
setblock 84 148 382 minecraft:sea_lantern
setblock 84 148 384 minecraft:sea_lantern
setblock 84 148 386 minecraft:sea_lantern
setblock 85 148 379 minecraft:sea_lantern
setblock 85 148 381 minecraft:sea_lantern
setblock 85 148 383 minecraft:sea_lantern
setblock 85 148 385 minecraft:sea_lantern
setblock 85 148 387 minecraft:sea_lantern
setblock 86 148 380 minecraft:sea_lantern
setblock 86 148 382 minecraft:sea_lantern
setblock 86 148 384 minecraft:sea_lantern
setblock 86 148 386 minecraft:sea_lantern
setblock 87 148 379 minecraft:sea_lantern
setblock 87 148 381 minecraft:sea_lantern
setblock 87 148 383 minecraft:sea_lantern
setblock 87 148 385 minecraft:sea_lantern
setblock 87 148 387 minecraft:sea_lantern
setblock 88 148 380 minecraft:sea_lantern
setblock 88 148 382 minecraft:sea_lantern
setblock 88 148 384 minecraft:sea_lantern
setblock 88 148 386 minecraft:sea_lantern
fill 84 149 380 84 150 380 minecraft:magenta_concrete
fill 84 149 382 84 150 382 minecraft:magenta_concrete
fill 84 149 384 84 150 384 minecraft:magenta_concrete
fill 84 149 386 84 150 386 minecraft:magenta_concrete
fill 85 149 379 85 150 379 minecraft:magenta_concrete
fill 85 149 381 85 150 381 minecraft:magenta_concrete
fill 85 149 383 85 150 383 minecraft:magenta_concrete
fill 85 149 385 85 150 385 minecraft:magenta_concrete
fill 85 149 387 85 150 387 minecraft:magenta_concrete
fill 86 149 380 86 150 380 minecraft:magenta_concrete
fill 86 149 382 86 150 382 minecraft:magenta_concrete
fill 86 149 384 86 150 384 minecraft:magenta_concrete
fill 86 149 386 86 150 386 minecraft:magenta_concrete
fill 87 149 379 87 150 379 minecraft:magenta_concrete
fill 87 149 381 87 150 381 minecraft:magenta_concrete
fill 87 149 383 87 150 383 minecraft:magenta_concrete
fill 87 149 385 87 150 385 minecraft:magenta_concrete
fill 87 149 387 87 150 387 minecraft:magenta_concrete
fill 88 149 380 88 150 380 minecraft:magenta_concrete
fill 88 149 382 88 150 382 minecraft:magenta_concrete
fill 88 149 384 88 150 384 minecraft:magenta_concrete
fill 88 149 386 88 150 386 minecraft:magenta_concrete
fill 47 150 374 47 157 374 minecraft:purple_concrete
fill 47 150 382 47 157 382 minecraft:purple_concrete
fill 47 150 390 47 157 390 minecraft:purple_concrete
fill 47 150 398 47 157 398 minecraft:purple_concrete
fill 47 150 406 47 157 406 minecraft:purple_concrete
fill 50 150 388 52 150 388 minecraft:glowstone
fill 50 150 411 50 157 411 minecraft:purple_concrete
setblock 51 150 387 minecraft:glowstone
setblock 51 150 389 minecraft:glowstone
fill 54 150 369 54 157 369 minecraft:purple_concrete
fill 54 150 378 55 150 379 minecraft:glowstone
fill 54 150 397 55 150 398 minecraft:glowstone
setblock 55 150 380 minecraft:glowstone
setblock 55 150 396 minecraft:glowstone
setblock 56 150 379 minecraft:glowstone
setblock 56 150 397 minecraft:glowstone
fill 58 150 411 58 157 411 minecraft:purple_concrete
fill 62 150 369 62 157 369 minecraft:purple_concrete
fill 63 150 375 65 150 375 minecraft:glowstone
fill 63 150 401 65 150 401 minecraft:glowstone
setblock 64 150 374 minecraft:glowstone
setblock 64 150 376 minecraft:glowstone
setblock 64 150 400 minecraft:glowstone
setblock 64 150 402 minecraft:glowstone
fill 66 150 411 66 157 411 minecraft:purple_concrete
fill 70 150 369 70 157 369 minecraft:purple_concrete
fill 72 150 379 74 150 379 minecraft:glowstone
fill 72 150 397 74 150 397 minecraft:glowstone
fill 73 150 378 74 150 378 minecraft:glowstone
setblock 73 150 380 minecraft:glowstone
setblock 73 150 396 minecraft:glowstone
fill 73 150 398 74 150 398 minecraft:glowstone
fill 74 150 411 74 157 411 minecraft:purple_concrete
fill 76 150 388 78 150 388 minecraft:glowstone
setblock 77 150 387 minecraft:glowstone
setblock 77 150 389 minecraft:glowstone
fill 78 150 369 78 157 369 minecraft:purple_concrete
fill 82 150 411 82 157 411 minecraft:purple_concrete
fill 86 150 369 86 157 369 minecraft:purple_concrete
fill 89 150 374 89 157 374 minecraft:purple_concrete
fill 89 150 382 89 157 382 minecraft:purple_concrete
fill 89 150 390 89 157 390 minecraft:purple_concrete
fill 89 150 398 89 157 398 minecraft:purple_concrete
fill 89 150 406 89 157 406 minecraft:purple_concrete
fill 64 151 374 64 161 374 minecraft:magenta_concrete
setblock 84 151 380 minecraft:sea_lantern
setblock 84 151 382 minecraft:sea_lantern
setblock 84 151 384 minecraft:sea_lantern
setblock 84 151 386 minecraft:sea_lantern
setblock 85 151 379 minecraft:sea_lantern
setblock 85 151 381 minecraft:sea_lantern
setblock 85 151 383 minecraft:sea_lantern
setblock 85 151 385 minecraft:sea_lantern
setblock 85 151 387 minecraft:sea_lantern
fill 85 151 397 87 152 397 minecraft:gray_concrete
setblock 86 151 380 minecraft:sea_lantern
setblock 86 151 382 minecraft:sea_lantern
setblock 86 151 384 minecraft:sea_lantern
setblock 86 151 386 minecraft:sea_lantern
setblock 87 151 379 minecraft:sea_lantern
setblock 87 151 381 minecraft:sea_lantern
setblock 87 151 383 minecraft:sea_lantern
setblock 87 151 385 minecraft:sea_lantern
setblock 87 151 387 minecraft:sea_lantern
setblock 88 151 380 minecraft:sea_lantern
setblock 88 151 382 minecraft:sea_lantern
setblock 88 151 384 minecraft:sea_lantern
setblock 88 151 386 minecraft:sea_lantern
setblock 84 152 380 minecraft:magenta_concrete
setblock 84 152 382 minecraft:magenta_concrete
setblock 84 152 384 minecraft:magenta_concrete
setblock 84 152 386 minecraft:magenta_concrete
setblock 85 152 379 minecraft:magenta_concrete
setblock 85 152 381 minecraft:magenta_concrete
setblock 85 152 383 minecraft:magenta_concrete
setblock 85 152 385 minecraft:magenta_concrete
setblock 85 152 387 minecraft:magenta_concrete
setblock 86 152 380 minecraft:magenta_concrete
setblock 86 152 382 minecraft:magenta_concrete
setblock 86 152 384 minecraft:magenta_concrete
setblock 86 152 386 minecraft:magenta_concrete
setblock 87 152 379 minecraft:magenta_concrete
setblock 87 152 381 minecraft:magenta_concrete
setblock 87 152 383 minecraft:magenta_concrete
setblock 87 152 385 minecraft:magenta_concrete
setblock 87 152 387 minecraft:magenta_concrete
fill 88 152 380 88 209 380 minecraft:magenta_concrete
setblock 88 152 382 minecraft:magenta_concrete
setblock 88 152 384 minecraft:magenta_concrete
setblock 88 152 386 minecraft:magenta_concrete
setblock 50 153 372 minecraft:light[level=14]
setblock 50 153 380 minecraft:light[level=14]
setblock 50 153 388 minecraft:light[level=14]
setblock 50 153 396 minecraft:light[level=14]
setblock 50 153 404 minecraft:light[level=14]
setblock 58 153 380 minecraft:light[level=14]
setblock 58 153 388 minecraft:light[level=14]
setblock 58 153 396 minecraft:light[level=14]
setblock 58 153 404 minecraft:light[level=14]
setblock 66 153 372 minecraft:light[level=14]
setblock 66 153 380 minecraft:light[level=14]
setblock 66 153 388 minecraft:light[level=14]
setblock 66 153 396 minecraft:light[level=14]
setblock 66 153 404 minecraft:light[level=14]
setblock 74 153 372 minecraft:light[level=14]
setblock 74 153 380 minecraft:light[level=14]
setblock 74 153 388 minecraft:light[level=14]
setblock 74 153 396 minecraft:light[level=14]
setblock 74 153 404 minecraft:light[level=14]
setblock 82 153 372 minecraft:light[level=14]
setblock 82 153 380 minecraft:light[level=14]
setblock 82 153 388 minecraft:light[level=14]
setblock 82 153 396 minecraft:light[level=14]
setblock 82 153 404 minecraft:light[level=14]
fill 48 154 370 48 155 375 minecraft:magenta_concrete
fill 48 154 378 49 154 383 minecraft:magenta_concrete
fill 48 154 386 49 154 391 minecraft:magenta_concrete
fill 48 154 394 49 154 399 minecraft:magenta_concrete
fill 48 154 402 49 154 407 minecraft:magenta_concrete
fill 48 154 410 53 155 410 minecraft:magenta_concrete
fill 49 154 371 49 154 377 minecraft:magenta_concrete
fill 49 154 384 49 154 385 minecraft:magenta_concrete
fill 49 154 392 49 154 393 minecraft:magenta_concrete
fill 49 154 400 49 154 401 minecraft:magenta_concrete
fill 49 154 408 49 154 409 minecraft:magenta_concrete
fill 50 154 371 57 154 371 minecraft:magenta_concrete
fill 50 154 409 88 154 409 minecraft:magenta_concrete
fill 51 154 370 56 155 370 minecraft:magenta_concrete
fill 56 154 410 61 155 410 minecraft:magenta_concrete
fill 64 154 410 69 155 410 minecraft:magenta_concrete
fill 65 154 371 87 154 371 minecraft:magenta_concrete
fill 67 154 370 72 155 370 minecraft:magenta_concrete
fill 72 154 410 77 155 410 minecraft:magenta_concrete
fill 75 154 370 80 155 370 minecraft:magenta_concrete
fill 80 154 410 85 155 410 minecraft:magenta_concrete
fill 83 154 370 88 155 370 minecraft:magenta_concrete
fill 87 154 372 87 154 408 minecraft:magenta_concrete
fill 88 154 373 88 155 378 minecraft:magenta_concrete
fill 88 154 381 88 155 386 minecraft:magenta_concrete
fill 88 154 389 88 155 394 minecraft:magenta_concrete
fill 88 154 397 88 155 402 minecraft:magenta_concrete
fill 88 154 405 88 155 408 minecraft:magenta_concrete
fill 88 154 410 88 155 410 minecraft:magenta_concrete
fill 48 155 378 48 155 383 minecraft:magenta_concrete
fill 48 155 386 48 155 391 minecraft:magenta_concrete
fill 48 155 394 48 155 399 minecraft:magenta_concrete
fill 48 155 402 48 155 407 minecraft:magenta_concrete
setblock 88 155 409 minecraft:magenta_concrete
fill 85 157 387 87 158 387 minecraft:gray_concrete
fill 47 158 374 47 163 374 minecraft:sea_lantern
fill 47 158 382 47 163 382 minecraft:sea_lantern
fill 47 158 390 47 163 390 minecraft:sea_lantern
fill 47 158 398 47 163 398 minecraft:sea_lantern
fill 47 158 406 47 163 406 minecraft:sea_lantern
fill 50 158 411 50 163 411 minecraft:sea_lantern
fill 54 158 369 54 163 369 minecraft:sea_lantern
fill 58 158 411 58 163 411 minecraft:sea_lantern
fill 62 158 369 62 163 369 minecraft:sea_lantern
fill 66 158 411 66 163 411 minecraft:sea_lantern
fill 70 158 369 70 163 369 minecraft:sea_lantern
fill 74 158 411 74 163 411 minecraft:sea_lantern
fill 78 158 369 78 163 369 minecraft:sea_lantern
fill 82 158 411 82 163 411 minecraft:sea_lantern
fill 86 158 369 86 163 369 minecraft:sea_lantern
fill 89 158 374 89 163 374 minecraft:sea_lantern
fill 89 158 382 89 163 382 minecraft:sea_lantern
fill 89 158 390 89 163 390 minecraft:sea_lantern
fill 89 158 398 89 163 398 minecraft:sea_lantern
fill 89 158 406 89 163 406 minecraft:sea_lantern
setblock 50 161 372 minecraft:light[level=14]
setblock 50 161 380 minecraft:light[level=14]
setblock 50 161 388 minecraft:light[level=14]
setblock 50 161 396 minecraft:light[level=14]
setblock 50 161 404 minecraft:light[level=14]
fill 54 161 385 54 162 387 minecraft:red_concrete
fill 55 161 385 55 162 386 minecraft:red_concrete
setblock 58 161 380 minecraft:light[level=14]
setblock 58 161 388 minecraft:light[level=14]
setblock 58 161 396 minecraft:light[level=14]
setblock 58 161 404 minecraft:light[level=14]
setblock 66 161 372 minecraft:light[level=14]
setblock 66 161 380 minecraft:light[level=14]
setblock 66 161 388 minecraft:light[level=14]
setblock 66 161 396 minecraft:light[level=14]
setblock 66 161 404 minecraft:light[level=14]
setblock 74 161 372 minecraft:light[level=14]
setblock 74 161 380 minecraft:light[level=14]
setblock 74 161 388 minecraft:light[level=14]
setblock 74 161 396 minecraft:light[level=14]
setblock 74 161 404 minecraft:light[level=14]
setblock 82 161 372 minecraft:light[level=14]
setblock 82 161 380 minecraft:light[level=14]
setblock 82 161 388 minecraft:light[level=14]
setblock 82 161 396 minecraft:light[level=14]
setblock 82 161 404 minecraft:light[level=14]
fill 56 162 399 56 163 400 minecraft:red_concrete
fill 57 162 370 58 209 370 minecraft:magenta_concrete
fill 65 162 370 66 209 370 minecraft:magenta_concrete
fill 47 164 374 47 171 374 minecraft:purple_concrete
fill 47 164 382 47 171 382 minecraft:purple_concrete
fill 47 164 390 47 171 390 minecraft:purple_concrete
fill 47 164 398 47 171 398 minecraft:purple_concrete
fill 47 164 406 47 171 406 minecraft:purple_concrete
fill 50 164 411 50 171 411 minecraft:purple_concrete
fill 54 164 369 54 171 369 minecraft:purple_concrete
fill 58 164 411 58 171 411 minecraft:purple_concrete
fill 62 164 369 62 171 369 minecraft:purple_concrete
fill 66 164 411 66 171 411 minecraft:purple_concrete
fill 70 164 369 70 171 369 minecraft:purple_concrete
fill 74 164 411 74 171 411 minecraft:purple_concrete
fill 78 164 369 78 171 369 minecraft:purple_concrete
fill 82 164 411 82 171 411 minecraft:purple_concrete
fill 86 164 369 86 171 369 minecraft:purple_concrete
fill 89 164 374 89 171 374 minecraft:purple_concrete
fill 89 164 382 89 171 382 minecraft:purple_concrete
fill 89 164 390 89 171 390 minecraft:purple_concrete
fill 89 164 398 89 171 398 minecraft:purple_concrete
fill 89 164 406 89 171 406 minecraft:purple_concrete
fill 48 168 370 48 169 375 minecraft:magenta_concrete
fill 48 168 378 49 168 383 minecraft:magenta_concrete
fill 48 168 386 49 168 391 minecraft:magenta_concrete
fill 48 168 394 49 168 399 minecraft:magenta_concrete
fill 48 168 402 49 168 407 minecraft:magenta_concrete
fill 48 168 410 53 169 410 minecraft:magenta_concrete
fill 49 168 371 49 168 377 minecraft:magenta_concrete
fill 49 168 384 49 168 385 minecraft:magenta_concrete
fill 49 168 392 49 168 393 minecraft:magenta_concrete
fill 49 168 400 49 168 401 minecraft:magenta_concrete
fill 49 168 408 49 168 409 minecraft:magenta_concrete
fill 50 168 371 87 168 371 minecraft:magenta_concrete
fill 50 168 409 88 168 409 minecraft:magenta_concrete
fill 51 168 370 56 169 370 minecraft:magenta_concrete
fill 56 168 410 61 169 410 minecraft:magenta_concrete
fill 59 168 370 64 169 370 minecraft:magenta_concrete
fill 64 168 410 69 169 410 minecraft:magenta_concrete
fill 67 168 370 72 169 370 minecraft:magenta_concrete
fill 72 168 410 77 169 410 minecraft:magenta_concrete
fill 75 168 370 80 169 370 minecraft:magenta_concrete
fill 80 168 410 85 169 410 minecraft:magenta_concrete
fill 83 168 370 88 169 370 minecraft:magenta_concrete
fill 87 168 372 87 168 408 minecraft:magenta_concrete
fill 88 168 373 88 169 378 minecraft:magenta_concrete
fill 88 168 381 88 169 386 minecraft:magenta_concrete
fill 88 168 389 88 169 394 minecraft:magenta_concrete
fill 88 168 397 88 169 402 minecraft:magenta_concrete
fill 88 168 405 88 169 408 minecraft:magenta_concrete
fill 88 168 410 88 169 410 minecraft:magenta_concrete
fill 48 169 378 48 169 383 minecraft:magenta_concrete
fill 48 169 386 48 169 391 minecraft:magenta_concrete
fill 48 169 394 48 169 399 minecraft:magenta_concrete
fill 48 169 402 48 169 407 minecraft:magenta_concrete
setblock 50 169 372 minecraft:light[level=14]
setblock 50 169 380 minecraft:light[level=14]
setblock 50 169 388 minecraft:light[level=14]
setblock 50 169 396 minecraft:light[level=14]
setblock 50 169 404 minecraft:light[level=14]
setblock 58 169 372 minecraft:light[level=14]
setblock 58 169 380 minecraft:light[level=14]
setblock 58 169 388 minecraft:light[level=14]
setblock 58 169 396 minecraft:light[level=14]
setblock 58 169 404 minecraft:light[level=14]
setblock 66 169 372 minecraft:light[level=14]
setblock 66 169 380 minecraft:light[level=14]
setblock 66 169 388 minecraft:light[level=14]
setblock 66 169 396 minecraft:light[level=14]
setblock 66 169 404 minecraft:light[level=14]
setblock 74 169 372 minecraft:light[level=14]
setblock 74 169 380 minecraft:light[level=14]
setblock 74 169 388 minecraft:light[level=14]
setblock 74 169 396 minecraft:light[level=14]
setblock 74 169 404 minecraft:light[level=14]
setblock 82 169 372 minecraft:light[level=14]
setblock 82 169 380 minecraft:light[level=14]
setblock 82 169 388 minecraft:light[level=14]
setblock 82 169 396 minecraft:light[level=14]
setblock 82 169 404 minecraft:light[level=14]
setblock 88 169 409 minecraft:magenta_concrete
fill 47 172 374 47 177 374 minecraft:sea_lantern
fill 47 172 382 47 177 382 minecraft:sea_lantern
fill 47 172 390 47 177 390 minecraft:sea_lantern
fill 47 172 398 47 177 398 minecraft:sea_lantern
fill 47 172 406 47 177 406 minecraft:sea_lantern
fill 50 172 411 50 177 411 minecraft:sea_lantern
fill 54 172 369 54 177 369 minecraft:sea_lantern
fill 58 172 411 58 177 411 minecraft:sea_lantern
fill 62 172 369 62 177 369 minecraft:sea_lantern
fill 66 172 411 66 177 411 minecraft:sea_lantern
fill 70 172 369 70 177 369 minecraft:sea_lantern
fill 74 172 411 74 177 411 minecraft:sea_lantern
fill 78 172 369 78 177 369 minecraft:sea_lantern
fill 82 172 411 82 177 411 minecraft:sea_lantern
fill 86 172 369 86 177 369 minecraft:sea_lantern
fill 89 172 374 89 177 374 minecraft:sea_lantern
fill 89 172 382 89 177 382 minecraft:sea_lantern
fill 89 172 390 89 177 390 minecraft:sea_lantern
fill 89 172 398 89 177 398 minecraft:sea_lantern
fill 89 172 406 89 177 406 minecraft:sea_lantern
setblock 50 177 372 minecraft:light[level=14]
setblock 50 177 380 minecraft:light[level=14]
setblock 50 177 388 minecraft:light[level=14]
setblock 50 177 396 minecraft:light[level=14]
setblock 50 177 404 minecraft:light[level=14]
setblock 58 177 372 minecraft:light[level=14]
setblock 58 177 380 minecraft:light[level=14]
setblock 58 177 388 minecraft:light[level=14]
setblock 58 177 396 minecraft:light[level=14]
setblock 58 177 404 minecraft:light[level=14]
setblock 66 177 372 minecraft:light[level=14]
setblock 66 177 380 minecraft:light[level=14]
setblock 66 177 388 minecraft:light[level=14]
setblock 66 177 396 minecraft:light[level=14]
setblock 66 177 404 minecraft:light[level=14]
setblock 74 177 372 minecraft:light[level=14]
setblock 74 177 380 minecraft:light[level=14]
setblock 74 177 388 minecraft:light[level=14]
setblock 74 177 396 minecraft:light[level=14]
setblock 74 177 404 minecraft:light[level=14]
setblock 82 177 372 minecraft:light[level=14]
setblock 82 177 380 minecraft:light[level=14]
setblock 82 177 388 minecraft:light[level=14]
setblock 82 177 396 minecraft:light[level=14]
setblock 82 177 404 minecraft:light[level=14]
fill 47 178 374 47 183 374 minecraft:purple_concrete
fill 47 178 382 47 185 382 minecraft:purple_concrete
fill 47 178 390 47 185 390 minecraft:purple_concrete
fill 47 178 398 47 184 398 minecraft:purple_concrete
fill 47 178 406 47 183 406 minecraft:purple_concrete
fill 50 178 411 50 184 411 minecraft:purple_concrete
fill 54 178 369 54 185 369 minecraft:purple_concrete
fill 58 178 411 58 184 411 minecraft:purple_concrete
fill 62 178 369 62 185 369 minecraft:purple_concrete
fill 66 178 411 66 185 411 minecraft:purple_concrete
fill 70 178 369 70 185 369 minecraft:purple_concrete
fill 74 178 411 74 183 411 minecraft:purple_concrete
fill 78 178 369 78 185 369 minecraft:purple_concrete
fill 82 178 411 82 185 411 minecraft:purple_concrete
fill 86 178 369 86 184 369 minecraft:purple_concrete
fill 89 178 374 89 185 374 minecraft:purple_concrete
fill 89 178 382 89 185 382 minecraft:purple_concrete
fill 89 178 390 89 184 390 minecraft:purple_concrete
fill 89 178 398 89 185 398 minecraft:purple_concrete
fill 89 178 406 89 185 406 minecraft:purple_concrete
fill 78 180 384 79 181 385 minecraft:yellow_concrete
fill 81 181 407 81 181 409 minecraft:gray_concrete
fill 48 182 370 48 183 375 minecraft:magenta_concrete
fill 48 182 378 49 182 383 minecraft:magenta_concrete
fill 48 182 386 49 182 391 minecraft:magenta_concrete
fill 48 182 394 49 182 399 minecraft:magenta_concrete
fill 48 182 402 49 182 407 minecraft:magenta_concrete
fill 48 182 410 53 183 410 minecraft:magenta_concrete
fill 49 182 371 49 182 377 minecraft:magenta_concrete
fill 49 182 384 49 182 385 minecraft:magenta_concrete
fill 49 182 392 49 182 393 minecraft:magenta_concrete
fill 49 182 400 49 182 401 minecraft:magenta_concrete
fill 49 182 408 49 182 409 minecraft:magenta_concrete
fill 50 182 371 87 182 371 minecraft:magenta_concrete
fill 50 182 409 88 182 409 minecraft:magenta_concrete
fill 51 182 370 56 183 370 minecraft:magenta_concrete
fill 56 182 410 61 183 410 minecraft:magenta_concrete
fill 59 182 370 64 183 370 minecraft:magenta_concrete
fill 60 182 404 60 183 404 minecraft:red_concrete
fill 64 182 410 69 183 410 minecraft:magenta_concrete
fill 67 182 370 72 183 370 minecraft:magenta_concrete
fill 72 182 410 77 183 410 minecraft:magenta_concrete
fill 75 182 370 80 183 370 minecraft:magenta_concrete
fill 80 182 410 85 183 410 minecraft:magenta_concrete
fill 81 182 407 81 182 408 minecraft:gray_concrete
fill 83 182 370 88 183 370 minecraft:magenta_concrete
fill 87 182 372 87 182 408 minecraft:magenta_concrete
fill 88 182 373 88 183 378 minecraft:magenta_concrete
fill 88 182 381 88 183 386 minecraft:magenta_concrete
fill 88 182 389 88 183 394 minecraft:magenta_concrete
fill 88 182 397 88 183 402 minecraft:magenta_concrete
fill 88 182 405 88 183 408 minecraft:magenta_concrete
fill 88 182 410 88 183 410 minecraft:magenta_concrete
setblock 47 183 376 minecraft:black_concrete
setblock 47 183 384 minecraft:black_concrete
fill 47 183 385 47 186 385 minecraft:purple_concrete
setblock 47 183 386 minecraft:black_concrete
fill 47 183 388 47 183 389 minecraft:black_concrete
setblock 47 183 393 minecraft:black_concrete
setblock 47 183 399 minecraft:black_concrete
fill 47 183 400 47 186 400 minecraft:purple_concrete
setblock 47 183 407 minecraft:black_concrete
fill 48 183 378 48 183 383 minecraft:magenta_concrete
fill 48 183 386 48 183 391 minecraft:magenta_concrete
fill 48 183 394 48 183 399 minecraft:magenta_concrete
fill 48 183 402 48 183 407 minecraft:magenta_concrete
fill 51 183 411 52 186 411 minecraft:purple_concrete
fill 53 183 411 54 183 411 minecraft:black_concrete
fill 55 183 411 55 186 411 minecraft:purple_concrete
fill 59 183 369 60 183 369 minecraft:black_concrete
setblock 59 183 411 minecraft:black_concrete
fill 61 183 369 61 186 369 minecraft:purple_concrete
fill 65 183 369 66 183 369 minecraft:black_concrete
fill 72 183 369 72 184 369 minecraft:black_concrete
fill 73 183 369 74 183 369 minecraft:purple_concrete
setblock 75 183 369 minecraft:black_concrete
fill 76 183 369 77 183 369 minecraft:purple_concrete
setblock 88 183 409 minecraft:magenta_concrete
setblock 89 183 391 minecraft:black_concrete
fill 89 183 392 89 186 392 minecraft:purple_concrete
setblock 89 183 393 minecraft:black_concrete
setblock 47 184 374 minecraft:black_concrete
fill 47 184 376 47 186 376 minecraft:purple_concrete
setblock 47 184 379 minecraft:black_concrete
setblock 47 184 384 minecraft:purple_concrete
setblock 47 184 386 minecraft:purple_concrete
fill 47 184 388 47 184 389 minecraft:purple_concrete
fill 47 184 393 47 186 393 minecraft:purple_concrete
fill 47 184 396 47 188 396 minecraft:purple_concrete
setblock 47 184 397 minecraft:black_concrete
fill 47 184 399 47 186 399 minecraft:purple_concrete
setblock 47 184 406 minecraft:black_concrete
fill 47 184 407 47 186 407 minecraft:purple_concrete
fill 53 184 411 53 185 411 minecraft:black_concrete
fill 54 184 411 54 186 411 minecraft:purple_concrete
setblock 56 184 369 minecraft:purple_concrete
setblock 57 184 369 minecraft:black_concrete
fill 59 184 369 60 186 369 minecraft:purple_concrete
fill 59 184 411 59 187 411 minecraft:purple_concrete
fill 61 184 411 61 186 411 minecraft:purple_concrete
fill 62 184 411 63 184 411 minecraft:black_concrete
fill 64 184 411 64 186 411 minecraft:purple_concrete
fill 65 184 369 66 184 369 minecraft:purple_concrete
setblock 65 184 411 minecraft:black_concrete
setblock 73 184 369 minecraft:purple_concrete
setblock 74 184 369 minecraft:black_concrete
setblock 74 184 411 minecraft:black_concrete
fill 75 184 369 75 186 369 minecraft:purple_concrete
setblock 76 184 369 minecraft:black_concrete
setblock 76 184 411 minecraft:black_concrete
fill 77 184 369 77 186 369 minecraft:purple_concrete
fill 77 184 411 81 184 411 minecraft:purple_concrete
fill 79 184 369 79 186 369 minecraft:purple_concrete
fill 80 184 369 81 184 369 minecraft:black_concrete
setblock 86 184 411 minecraft:black_concrete
setblock 89 184 380 minecraft:black_concrete
setblock 89 184 385 minecraft:black_concrete
fill 89 184 386 89 184 389 minecraft:purple_concrete
fill 89 184 391 89 186 391 minecraft:purple_concrete
fill 89 184 393 89 186 393 minecraft:purple_concrete
setblock 47 185 374 minecraft:purple_concrete
fill 47 185 379 47 186 380 minecraft:purple_concrete
setblock 47 185 381 minecraft:black_concrete
setblock 47 185 384 minecraft:black_concrete
setblock 47 185 386 minecraft:black_concrete
setblock 47 185 388 minecraft:black_concrete
fill 47 185 389 47 186 389 minecraft:purple_concrete
setblock 47 185 395 minecraft:black_concrete
fill 47 185 397 47 186 397 minecraft:purple_concrete
setblock 47 185 398 minecraft:black_concrete
setblock 47 185 406 minecraft:purple_concrete
fill 47 185 408 47 186 410 minecraft:purple_concrete
setblock 47 185 411 minecraft:black_concrete
setblock 50 185 372 minecraft:light[level=14]
setblock 50 185 380 minecraft:light[level=14]
setblock 50 185 388 minecraft:light[level=14]
setblock 50 185 396 minecraft:light[level=14]
setblock 50 185 404 minecraft:light[level=14]
setblock 50 185 411 minecraft:black_concrete
setblock 56 185 369 minecraft:black_concrete
fill 57 185 369 57 186 369 minecraft:purple_concrete
fill 57 185 411 58 185 411 minecraft:black_concrete
setblock 58 185 369 minecraft:black_concrete
setblock 58 185 372 minecraft:light[level=14]
setblock 58 185 380 minecraft:light[level=14]
setblock 58 185 388 minecraft:light[level=14]
setblock 58 185 396 minecraft:light[level=14]
setblock 58 185 404 minecraft:light[level=14]
fill 62 185 411 63 186 411 minecraft:purple_concrete
setblock 65 185 369 minecraft:black_concrete
fill 65 185 411 65 186 411 minecraft:purple_concrete
fill 66 185 369 66 189 369 minecraft:purple_concrete
setblock 66 185 372 minecraft:light[level=14]
setblock 66 185 380 minecraft:light[level=14]
setblock 66 185 388 minecraft:light[level=14]
setblock 66 185 396 minecraft:light[level=14]
setblock 66 185 404 minecraft:light[level=14]
fill 67 185 411 69 186 411 minecraft:purple_concrete
setblock 70 185 411 minecraft:black_concrete
fill 71 185 411 74 185 411 minecraft:purple_concrete
fill 72 185 369 72 186 369 minecraft:purple_concrete
setblock 73 185 369 minecraft:black_concrete
fill 74 185 369 74 187 369 minecraft:purple_concrete
setblock 74 185 372 minecraft:light[level=14]
setblock 74 185 380 minecraft:light[level=14]
setblock 74 185 388 minecraft:light[level=14]
setblock 74 185 396 minecraft:light[level=14]
setblock 74 185 404 minecraft:light[level=14]
fill 76 185 369 76 186 369 minecraft:purple_concrete
fill 76 185 411 76 186 411 minecraft:purple_concrete
fill 77 185 411 78 185 411 minecraft:black_concrete
fill 79 185 411 81 186 411 minecraft:purple_concrete
fill 80 185 369 81 186 369 minecraft:purple_concrete
setblock 82 185 372 minecraft:light[level=14]
setblock 82 185 380 minecraft:light[level=14]
setblock 82 185 388 minecraft:light[level=14]
setblock 82 185 396 minecraft:light[level=14]
setblock 82 185 404 minecraft:light[level=14]
fill 83 185 411 84 185 411 minecraft:black_concrete
setblock 86 185 369 minecraft:black_concrete
fill 86 185 411 86 186 411 minecraft:purple_concrete
setblock 89 185 370 minecraft:black_concrete
fill 89 185 375 89 186 378 minecraft:purple_concrete
setblock 89 185 379 minecraft:black_concrete
fill 89 185 380 89 186 380 minecraft:purple_concrete
fill 89 185 385 89 186 388 minecraft:purple_concrete
fill 89 185 389 89 185 390 minecraft:black_concrete
fill 47 186 374 47 191 374 minecraft:sea_lantern
setblock 47 186 381 minecraft:purple_concrete
fill 47 186 382 47 191 382 minecraft:sea_lantern
setblock 47 186 384 minecraft:purple_concrete
fill 47 186 386 47 187 386 minecraft:purple_concrete
setblock 47 186 388 minecraft:purple_concrete
fill 47 186 390 47 191 390 minecraft:sea_lantern
setblock 47 186 395 minecraft:purple_concrete
fill 47 186 398 47 191 398 minecraft:sea_lantern
fill 47 186 406 47 191 406 minecraft:sea_lantern
setblock 47 186 411 minecraft:purple_concrete
fill 50 186 411 50 191 411 minecraft:sea_lantern
setblock 53 186 411 minecraft:purple_concrete
fill 54 186 369 54 191 369 minecraft:sea_lantern
setblock 56 186 369 minecraft:purple_concrete
setblock 57 186 411 minecraft:purple_concrete
setblock 58 186 369 minecraft:purple_concrete
fill 58 186 411 58 191 411 minecraft:sea_lantern
fill 62 186 369 62 191 369 minecraft:sea_lantern
setblock 65 186 369 minecraft:purple_concrete
fill 66 186 411 66 191 411 minecraft:sea_lantern
fill 70 186 369 70 191 369 minecraft:sea_lantern
fill 70 186 411 73 186 411 minecraft:purple_concrete
setblock 73 186 369 minecraft:purple_concrete
fill 74 186 411 74 191 411 minecraft:sea_lantern
fill 77 186 411 78 186 411 minecraft:purple_concrete
fill 78 186 369 78 191 369 minecraft:sea_lantern
fill 82 186 411 82 191 411 minecraft:sea_lantern
fill 83 186 411 84 186 411 minecraft:purple_concrete
fill 86 186 369 86 191 369 minecraft:sea_lantern
fill 89 186 370 89 187 370 minecraft:purple_concrete
fill 89 186 374 89 191 374 minecraft:sea_lantern
setblock 89 186 379 minecraft:purple_concrete
fill 89 186 382 89 191 382 minecraft:sea_lantern
setblock 89 186 389 minecraft:purple_concrete
fill 89 186 390 89 191 390 minecraft:sea_lantern
fill 89 186 398 89 191 398 minecraft:sea_lantern
fill 89 186 406 89 191 406 minecraft:sea_lantern
setblock 47 187 369 minecraft:purple_concrete
fill 47 187 370 47 285 371 minecraft:black_concrete
setblock 47 187 372 minecraft:purple_concrete
fill 47 187 373 47 285 373 minecraft:black_concrete
fill 47 187 375 47 307 377 minecraft:black_concrete
fill 47 187 378 47 187 379 minecraft:purple_concrete
fill 47 187 380 47 307 381 minecraft:black_concrete
fill 47 187 383 47 307 385 minecraft:black_concrete
fill 47 187 387 47 187 389 minecraft:black_concrete
setblock 47 187 391 minecraft:purple_concrete
fill 47 187 392 47 307 395 minecraft:black_concrete
fill 47 187 397 47 307 397 minecraft:black_concrete
fill 47 187 399 47 187 405 minecraft:black_concrete
fill 47 187 407 47 307 411 minecraft:black_concrete
fill 48 187 369 53 188 369 minecraft:black_concrete
fill 48 187 411 49 307 411 minecraft:black_concrete
fill 51 187 411 57 188 411 minecraft:black_concrete
fill 55 187 369 61 187 369 minecraft:black_concrete
fill 61 187 411 65 188 411 minecraft:black_concrete
fill 63 187 369 65 307 369 minecraft:black_concrete
fill 67 187 369 69 307 369 minecraft:black_concrete
fill 67 187 411 73 188 411 minecraft:black_concrete
fill 71 187 369 73 307 369 minecraft:black_concrete
fill 75 187 369 77 307 369 minecraft:black_concrete
fill 75 187 411 81 188 411 minecraft:black_concrete
fill 79 187 369 85 187 369 minecraft:black_concrete
fill 83 187 411 89 187 411 minecraft:black_concrete
fill 87 187 369 88 307 369 minecraft:black_concrete
setblock 89 187 369 minecraft:purple_concrete
fill 89 187 371 89 187 373 minecraft:black_concrete
fill 89 187 375 89 187 381 minecraft:black_concrete
fill 89 187 383 89 187 389 minecraft:black_concrete
fill 89 187 391 89 187 397 minecraft:black_concrete
fill 89 187 400 89 188 405 minecraft:black_concrete
fill 89 187 407 89 307 410 minecraft:black_concrete
fill 47 188 369 47 307 369 minecraft:black_concrete
setblock 47 188 372 minecraft:black_concrete
fill 47 188 378 47 188 379 minecraft:black_concrete
fill 47 188 386 47 188 387 minecraft:black_concrete
setblock 47 188 388 minecraft:purple_concrete
fill 47 188 389 47 307 389 minecraft:black_concrete
setblock 47 188 391 minecraft:black_concrete
fill 47 188 399 47 307 401 minecraft:black_concrete
setblock 47 188 402 minecraft:purple_concrete
fill 47 188 403 47 307 405 minecraft:black_concrete
fill 55 188 369 55 307 369 minecraft:black_concrete
setblock 56 188 369 minecraft:purple_concrete
fill 57 188 369 58 188 369 minecraft:black_concrete
fill 59 188 369 59 189 369 minecraft:purple_concrete
fill 59 188 411 60 188 411 minecraft:black_concrete
fill 60 188 369 61 307 369 minecraft:black_concrete
fill 74 188 369 74 307 369 minecraft:black_concrete
fill 79 188 369 82 307 369 minecraft:black_concrete
setblock 83 188 369 minecraft:purple_concrete
fill 83 188 411 84 307 411 minecraft:black_concrete
fill 84 188 369 85 307 369 minecraft:black_concrete
setblock 85 188 411 minecraft:purple_concrete
fill 86 188 411 87 307 411 minecraft:black_concrete
setblock 88 188 411 minecraft:purple_concrete
fill 89 188 369 89 188 370 minecraft:black_concrete
setblock 89 188 371 minecraft:purple_concrete
fill 89 188 372 89 307 372 minecraft:black_concrete
setblock 89 188 373 minecraft:purple_concrete
fill 89 188 375 89 307 380 minecraft:black_concrete
setblock 89 188 381 minecraft:purple_concrete
fill 89 188 383 89 307 384 minecraft:black_concrete
setblock 89 188 385 minecraft:purple_concrete
fill 89 188 386 89 307 387 minecraft:black_concrete
setblock 89 188 388 minecraft:purple_concrete
fill 89 188 389 89 307 389 minecraft:black_concrete
fill 89 188 391 89 307 396 minecraft:black_concrete
setblock 89 188 397 minecraft:purple_concrete
fill 89 188 399 89 307 399 minecraft:black_concrete
fill 89 188 411 89 307 411 minecraft:black_concrete
setblock 47 189 372 minecraft:purple_concrete
setblock 47 189 378 minecraft:purple_concrete
fill 47 189 379 47 307 379 minecraft:black_concrete
fill 47 189 386 47 307 386 minecraft:black_concrete
setblock 47 189 387 minecraft:purple_concrete
fill 47 189 388 47 307 388 minecraft:black_concrete
setblock 47 189 391 minecraft:purple_concrete
fill 47 189 396 47 307 396 minecraft:black_concrete
fill 47 189 402 47 307 402 minecraft:black_concrete
fill 48 189 369 49 189 369 minecraft:purple_concrete
fill 50 189 369 50 307 369 minecraft:black_concrete
setblock 51 189 369 minecraft:purple_concrete
fill 51 189 411 55 307 411 minecraft:black_concrete
fill 52 189 369 53 307 369 minecraft:black_concrete
fill 56 189 369 56 307 369 minecraft:black_concrete
setblock 56 189 411 minecraft:purple_concrete
setblock 57 189 369 minecraft:purple_concrete
fill 57 189 411 57 307 411 minecraft:black_concrete
fill 58 189 369 58 307 369 minecraft:black_concrete
setblock 59 189 411 minecraft:purple_concrete
fill 60 189 411 63 307 411 minecraft:black_concrete
fill 64 189 411 65 189 411 minecraft:purple_concrete
fill 67 189 411 70 307 411 minecraft:black_concrete
setblock 71 189 411 minecraft:purple_concrete
fill 72 189 411 73 307 411 minecraft:black_concrete
fill 75 189 411 76 307 411 minecraft:black_concrete
setblock 77 189 411 minecraft:purple_concrete
fill 78 189 411 81 307 411 minecraft:black_concrete
fill 83 189 369 83 307 369 minecraft:black_concrete
fill 85 189 411 85 307 411 minecraft:black_concrete
fill 88 189 411 88 307 411 minecraft:black_concrete
fill 89 189 369 89 307 369 minecraft:black_concrete
setblock 89 189 370 minecraft:purple_concrete
fill 89 189 371 89 307 371 minecraft:black_concrete
fill 89 189 373 89 307 373 minecraft:black_concrete
fill 89 189 381 89 307 381 minecraft:black_concrete
fill 89 189 385 89 307 385 minecraft:black_concrete
fill 89 189 388 89 307 388 minecraft:black_concrete
fill 89 189 397 89 307 397 minecraft:black_concrete
fill 89 189 400 89 307 400 minecraft:black_concrete
setblock 89 189 401 minecraft:purple_concrete
fill 89 189 402 89 307 405 minecraft:black_concrete
fill 47 190 372 47 307 372 minecraft:black_concrete
fill 47 190 378 47 307 378 minecraft:black_concrete
fill 47 190 387 47 307 387 minecraft:black_concrete
fill 47 190 391 47 307 391 minecraft:black_concrete
fill 48 190 369 49 307 369 minecraft:black_concrete
fill 51 190 369 51 307 369 minecraft:black_concrete
fill 56 190 411 56 307 411 minecraft:black_concrete
fill 57 190 369 57 307 369 minecraft:black_concrete
fill 59 190 369 59 307 369 minecraft:black_concrete
fill 59 190 411 59 307 411 minecraft:black_concrete
fill 64 190 411 65 307 411 minecraft:black_concrete
fill 66 190 369 66 307 369 minecraft:black_concrete
fill 71 190 411 71 307 411 minecraft:black_concrete
fill 77 190 411 77 307 411 minecraft:black_concrete
fill 89 190 370 89 307 370 minecraft:black_concrete
fill 89 190 401 89 307 401 minecraft:black_concrete
fill 47 192 374 47 199 374 minecraft:black_concrete
fill 47 192 382 47 199 382 minecraft:black_concrete
fill 47 192 390 47 199 390 minecraft:black_concrete
fill 47 192 398 47 199 398 minecraft:black_concrete
fill 47 192 406 47 199 406 minecraft:black_concrete
fill 50 192 411 50 199 411 minecraft:black_concrete
fill 54 192 369 54 199 369 minecraft:black_concrete
fill 58 192 411 58 199 411 minecraft:black_concrete
fill 62 192 369 62 199 369 minecraft:black_concrete
fill 66 192 411 66 199 411 minecraft:black_concrete
fill 70 192 369 70 199 369 minecraft:black_concrete
fill 74 192 411 74 199 411 minecraft:black_concrete
fill 78 192 369 78 199 369 minecraft:black_concrete
fill 82 192 411 82 199 411 minecraft:black_concrete
fill 86 192 369 86 199 369 minecraft:black_concrete
fill 89 192 374 89 199 374 minecraft:black_concrete
fill 89 192 382 89 199 382 minecraft:black_concrete
fill 89 192 390 89 199 390 minecraft:black_concrete
fill 89 192 398 89 199 398 minecraft:black_concrete
fill 89 192 406 89 199 406 minecraft:black_concrete
setblock 50 193 372 minecraft:light[level=14]
setblock 50 193 380 minecraft:light[level=14]
setblock 50 193 388 minecraft:light[level=14]
setblock 50 193 396 minecraft:light[level=14]
setblock 50 193 404 minecraft:light[level=14]
setblock 58 193 372 minecraft:light[level=14]
setblock 58 193 380 minecraft:light[level=14]
setblock 58 193 388 minecraft:light[level=14]
setblock 58 193 396 minecraft:light[level=14]
setblock 58 193 404 minecraft:light[level=14]
setblock 66 193 372 minecraft:light[level=14]
setblock 66 193 380 minecraft:light[level=14]
setblock 66 193 388 minecraft:light[level=14]
setblock 66 193 396 minecraft:light[level=14]
setblock 66 193 404 minecraft:light[level=14]
setblock 74 193 372 minecraft:light[level=14]
setblock 74 193 380 minecraft:light[level=14]
setblock 74 193 388 minecraft:light[level=14]
setblock 74 193 396 minecraft:light[level=14]
setblock 74 193 404 minecraft:light[level=14]
setblock 82 193 372 minecraft:light[level=14]
setblock 82 193 380 minecraft:light[level=14]
setblock 82 193 388 minecraft:light[level=14]
setblock 82 193 396 minecraft:light[level=14]
setblock 82 193 404 minecraft:light[level=14]
fill 71 194 379 71 195 380 minecraft:yellow_concrete
fill 77 195 370 80 195 374 minecraft:pink_concrete
fill 81 195 371 81 195 374 minecraft:pink_concrete
fill 48 196 370 48 197 375 minecraft:magenta_concrete
fill 48 196 378 49 196 383 minecraft:magenta_concrete
fill 48 196 386 49 196 391 minecraft:magenta_concrete
fill 48 196 394 49 196 399 minecraft:magenta_concrete
fill 48 196 402 49 196 407 minecraft:magenta_concrete
fill 48 196 410 53 197 410 minecraft:magenta_concrete
fill 49 196 371 49 196 377 minecraft:magenta_concrete
fill 49 196 384 49 196 385 minecraft:magenta_concrete
fill 49 196 392 49 196 393 minecraft:magenta_concrete
fill 49 196 400 49 196 401 minecraft:magenta_concrete
fill 49 196 408 49 196 409 minecraft:magenta_concrete
fill 50 196 371 87 196 371 minecraft:magenta_concrete
fill 50 196 409 88 196 409 minecraft:magenta_concrete
fill 51 196 370 56 197 370 minecraft:magenta_concrete
fill 56 196 410 61 197 410 minecraft:magenta_concrete
fill 59 196 370 64 197 370 minecraft:magenta_concrete
fill 64 196 410 69 197 410 minecraft:magenta_concrete
fill 67 196 370 72 197 370 minecraft:magenta_concrete
fill 72 196 410 77 197 410 minecraft:magenta_concrete
fill 75 196 370 80 197 370 minecraft:magenta_concrete
fill 77 196 372 81 196 374 minecraft:pink_concrete
fill 80 196 410 85 197 410 minecraft:magenta_concrete
fill 83 196 370 88 197 370 minecraft:magenta_concrete
fill 87 196 372 87 196 408 minecraft:magenta_concrete
fill 88 196 373 88 197 378 minecraft:magenta_concrete
fill 88 196 381 88 197 386 minecraft:magenta_concrete
fill 88 196 389 88 197 394 minecraft:magenta_concrete
fill 88 196 397 88 197 402 minecraft:magenta_concrete
fill 88 196 405 88 197 408 minecraft:magenta_concrete
fill 88 196 410 88 197 410 minecraft:magenta_concrete
fill 48 197 378 48 197 383 minecraft:magenta_concrete
fill 48 197 386 48 197 391 minecraft:magenta_concrete
fill 48 197 394 48 197 399 minecraft:magenta_concrete
fill 48 197 402 48 197 407 minecraft:magenta_concrete
fill 77 197 371 81 198 373 minecraft:pink_concrete
fill 78 197 374 80 198 374 minecraft:pink_concrete
setblock 88 197 409 minecraft:magenta_concrete
fill 78 198 370 80 198 370 minecraft:pink_concrete
fill 77 199 372 81 199 372 minecraft:pink_concrete
fill 78 199 371 80 199 371 minecraft:pink_concrete
fill 78 199 373 80 199 373 minecraft:pink_concrete
setblock 79 199 370 minecraft:pink_concrete
setblock 79 199 374 minecraft:pink_concrete
fill 47 200 374 47 205 374 minecraft:sea_lantern
fill 47 200 382 47 205 382 minecraft:sea_lantern
fill 47 200 390 47 205 390 minecraft:sea_lantern
fill 47 200 398 47 205 398 minecraft:sea_lantern
fill 47 200 406 47 205 406 minecraft:sea_lantern
fill 50 200 411 50 205 411 minecraft:sea_lantern
fill 54 200 369 54 205 369 minecraft:sea_lantern
fill 58 200 411 58 205 411 minecraft:sea_lantern
fill 62 200 369 62 205 369 minecraft:sea_lantern
fill 66 200 411 66 205 411 minecraft:sea_lantern
fill 70 200 369 70 205 369 minecraft:sea_lantern
fill 74 200 411 74 205 411 minecraft:sea_lantern
fill 78 200 369 78 205 369 minecraft:sea_lantern
setblock 79 200 372 minecraft:pink_concrete
fill 82 200 411 82 205 411 minecraft:sea_lantern
fill 86 200 369 86 205 369 minecraft:sea_lantern
fill 89 200 374 89 205 374 minecraft:sea_lantern
fill 89 200 382 89 205 382 minecraft:sea_lantern
fill 89 200 390 89 205 390 minecraft:sea_lantern
fill 89 200 398 89 205 398 minecraft:sea_lantern
fill 89 200 406 89 205 406 minecraft:sea_lantern
setblock 50 201 372 minecraft:light[level=14]
setblock 50 201 380 minecraft:light[level=14]
setblock 50 201 388 minecraft:light[level=14]
setblock 50 201 396 minecraft:light[level=14]
setblock 50 201 404 minecraft:light[level=14]
setblock 58 201 372 minecraft:light[level=14]
setblock 58 201 380 minecraft:light[level=14]
setblock 58 201 388 minecraft:light[level=14]
setblock 58 201 396 minecraft:light[level=14]
setblock 58 201 404 minecraft:light[level=14]
setblock 66 201 372 minecraft:light[level=14]
setblock 66 201 380 minecraft:light[level=14]
setblock 66 201 388 minecraft:light[level=14]
setblock 66 201 396 minecraft:light[level=14]
setblock 66 201 404 minecraft:light[level=14]
fill 72 201 370 72 202 372 minecraft:gray_concrete
setblock 74 201 372 minecraft:light[level=14]
setblock 74 201 380 minecraft:light[level=14]
setblock 74 201 388 minecraft:light[level=14]
setblock 74 201 396 minecraft:light[level=14]
setblock 74 201 404 minecraft:light[level=14]
setblock 82 201 372 minecraft:light[level=14]
setblock 82 201 380 minecraft:light[level=14]
setblock 82 201 388 minecraft:light[level=14]
setblock 82 201 396 minecraft:light[level=14]
setblock 82 201 404 minecraft:light[level=14]
fill 68 204 380 70 205 380 minecraft:lime_concrete
fill 69 204 379 69 205 379 minecraft:lime_concrete
fill 69 204 381 69 205 381 minecraft:lime_concrete
fill 47 206 374 47 227 374 minecraft:black_concrete
fill 47 206 382 47 227 382 minecraft:black_concrete
fill 47 206 390 47 227 390 minecraft:black_concrete
fill 47 206 398 47 227 398 minecraft:black_concrete
fill 47 206 406 47 227 406 minecraft:black_concrete
fill 50 206 411 50 227 411 minecraft:black_concrete
fill 54 206 369 54 227 369 minecraft:black_concrete
fill 58 206 411 58 227 411 minecraft:black_concrete
fill 62 206 369 62 227 369 minecraft:black_concrete
fill 66 206 411 66 227 411 minecraft:black_concrete
fill 70 206 369 70 227 369 minecraft:black_concrete
fill 74 206 411 74 227 411 minecraft:black_concrete
fill 78 206 369 78 227 369 minecraft:black_concrete
fill 82 206 411 82 227 411 minecraft:black_concrete
fill 86 206 369 86 227 369 minecraft:black_concrete
fill 89 206 374 89 227 374 minecraft:black_concrete
fill 89 206 382 89 227 382 minecraft:black_concrete
fill 89 206 390 89 227 390 minecraft:black_concrete
fill 89 206 398 89 227 398 minecraft:black_concrete
fill 89 206 406 89 227 406 minecraft:black_concrete
fill 72 207 382 73 208 383 minecraft:yellow_concrete
fill 58 208 383 60 209 383 minecraft:cyan_concrete
fill 59 208 384 59 209 384 minecraft:cyan_concrete
setblock 50 209 372 minecraft:light[level=14]
setblock 50 209 380 minecraft:light[level=14]
setblock 50 209 388 minecraft:light[level=14]
setblock 50 209 396 minecraft:light[level=14]
setblock 50 209 404 minecraft:light[level=14]
setblock 58 209 372 minecraft:light[level=14]
setblock 58 209 380 minecraft:light[level=14]
setblock 58 209 388 minecraft:light[level=14]
setblock 58 209 396 minecraft:light[level=14]
setblock 58 209 404 minecraft:light[level=14]
setblock 66 209 372 minecraft:light[level=14]
setblock 66 209 380 minecraft:light[level=14]
setblock 66 209 388 minecraft:light[level=14]
setblock 66 209 396 minecraft:light[level=14]
setblock 66 209 404 minecraft:light[level=14]
setblock 74 209 372 minecraft:light[level=14]
setblock 74 209 380 minecraft:light[level=14]
setblock 74 209 388 minecraft:light[level=14]
setblock 74 209 396 minecraft:light[level=14]
setblock 74 209 404 minecraft:light[level=14]
setblock 82 209 372 minecraft:light[level=14]
setblock 82 209 380 minecraft:light[level=14]
setblock 82 209 388 minecraft:light[level=14]
setblock 82 209 396 minecraft:light[level=14]
setblock 82 209 404 minecraft:light[level=14]
fill 48 215 370 50 216 372 minecraft:black_concrete
fill 48 215 373 50 215 378 minecraft:gray_concrete
fill 48 215 379 50 215 384 minecraft:black_concrete
fill 48 215 385 50 215 390 minecraft:gray_concrete
fill 48 215 391 50 215 396 minecraft:black_concrete
fill 48 215 397 50 215 402 minecraft:gray_concrete
fill 48 215 403 50 215 408 minecraft:black_concrete
fill 48 215 409 50 215 410 minecraft:gray_concrete
fill 51 215 370 56 215 372 minecraft:gray_concrete
fill 51 215 373 56 215 378 minecraft:black_concrete
fill 51 215 379 56 215 384 minecraft:gray_concrete
fill 51 215 385 56 215 390 minecraft:black_concrete
fill 51 215 391 56 215 396 minecraft:gray_concrete
fill 51 215 397 56 215 402 minecraft:black_concrete
fill 51 215 403 56 215 408 minecraft:gray_concrete
fill 51 215 409 56 215 410 minecraft:black_concrete
fill 57 215 370 62 215 372 minecraft:black_concrete
fill 57 215 373 62 215 378 minecraft:gray_concrete
fill 57 215 379 62 215 384 minecraft:black_concrete
fill 57 215 385 60 215 390 minecraft:gray_concrete
fill 57 215 391 60 215 396 minecraft:black_concrete
fill 57 215 397 62 215 402 minecraft:gray_concrete
fill 57 215 403 62 215 408 minecraft:black_concrete
fill 57 215 409 62 215 410 minecraft:gray_concrete
fill 61 215 385 61 215 389 minecraft:gray_concrete
fill 61 215 393 61 215 396 minecraft:black_concrete
fill 62 215 385 62 215 388 minecraft:gray_concrete
fill 62 215 394 62 215 396 minecraft:black_concrete
fill 63 215 370 68 215 372 minecraft:gray_concrete
fill 63 215 373 68 215 378 minecraft:black_concrete
fill 63 215 379 68 215 384 minecraft:gray_concrete
fill 63 215 385 68 215 388 minecraft:black_concrete
fill 63 215 394 68 215 396 minecraft:gray_concrete
fill 63 215 397 68 215 402 minecraft:black_concrete
fill 63 215 403 68 215 408 minecraft:gray_concrete
fill 63 215 409 68 215 410 minecraft:black_concrete
fill 65 215 389 68 215 389 minecraft:black_concrete
fill 65 215 393 68 215 393 minecraft:gray_concrete
fill 66 215 390 68 215 390 minecraft:black_concrete
fill 66 215 391 68 215 392 minecraft:gray_concrete
fill 69 215 370 74 215 372 minecraft:black_concrete
fill 69 215 373 74 215 378 minecraft:gray_concrete
fill 69 215 379 74 215 384 minecraft:black_concrete
fill 69 215 385 74 215 390 minecraft:gray_concrete
fill 69 215 391 74 215 396 minecraft:black_concrete
fill 69 215 397 74 215 402 minecraft:gray_concrete
fill 69 215 403 74 215 408 minecraft:black_concrete
fill 69 215 409 74 215 410 minecraft:gray_concrete
fill 75 215 370 80 215 372 minecraft:gray_concrete
fill 75 215 373 80 215 378 minecraft:black_concrete
fill 75 215 379 80 215 384 minecraft:gray_concrete
fill 75 215 385 80 215 390 minecraft:black_concrete
fill 75 215 391 80 215 396 minecraft:gray_concrete
fill 75 215 397 80 215 402 minecraft:black_concrete
fill 75 215 403 80 215 408 minecraft:gray_concrete
fill 75 215 409 80 215 410 minecraft:black_concrete
fill 81 215 370 86 215 372 minecraft:black_concrete
fill 81 215 373 86 215 378 minecraft:gray_concrete
fill 81 215 379 86 215 384 minecraft:black_concrete
fill 81 215 385 86 215 390 minecraft:gray_concrete
fill 81 215 391 86 215 396 minecraft:black_concrete
fill 81 215 397 86 215 402 minecraft:gray_concrete
fill 81 215 403 86 215 408 minecraft:black_concrete
fill 81 215 409 86 215 410 minecraft:gray_concrete
fill 87 215 370 88 215 372 minecraft:gray_concrete
fill 87 215 373 88 215 378 minecraft:black_concrete
fill 87 215 379 88 215 384 minecraft:gray_concrete
fill 87 215 385 88 215 390 minecraft:black_concrete
fill 87 215 391 88 215 396 minecraft:gray_concrete
fill 87 215 397 88 215 402 minecraft:black_concrete
fill 87 215 403 88 215 408 minecraft:gray_concrete
fill 87 215 409 88 215 410 minecraft:black_concrete
fill 48 216 373 88 216 373 minecraft:cyan_concrete
fill 48 216 374 50 216 378 minecraft:gray_concrete
fill 48 216 379 88 216 379 minecraft:cyan_concrete
fill 48 216 380 50 216 384 minecraft:black_concrete
fill 48 216 385 88 216 385 minecraft:cyan_concrete
fill 48 216 386 50 216 390 minecraft:gray_concrete
fill 48 216 391 59 216 391 minecraft:cyan_concrete
fill 48 216 392 50 216 396 minecraft:black_concrete
fill 48 216 397 88 216 397 minecraft:cyan_concrete
fill 48 216 398 50 216 402 minecraft:gray_concrete
fill 48 216 403 88 216 403 minecraft:cyan_concrete
fill 48 216 404 50 216 408 minecraft:black_concrete
fill 48 216 409 88 216 409 minecraft:cyan_concrete
fill 48 216 410 50 216 410 minecraft:gray_concrete
fill 51 216 370 51 216 372 minecraft:cyan_concrete
fill 51 216 374 51 216 378 minecraft:cyan_concrete
fill 51 216 380 51 216 384 minecraft:cyan_concrete
fill 51 216 386 51 216 390 minecraft:cyan_concrete
fill 51 216 392 51 216 396 minecraft:cyan_concrete
fill 51 216 398 51 216 402 minecraft:cyan_concrete
fill 51 216 404 51 216 408 minecraft:cyan_concrete
setblock 51 216 410 minecraft:cyan_concrete
fill 52 216 370 56 216 372 minecraft:gray_concrete
fill 52 216 374 56 216 378 minecraft:black_concrete
fill 52 216 380 56 216 384 minecraft:gray_concrete
fill 52 216 386 56 216 390 minecraft:black_concrete
fill 52 216 392 56 216 396 minecraft:gray_concrete
fill 52 216 398 56 216 402 minecraft:black_concrete
fill 52 216 404 56 216 408 minecraft:gray_concrete
fill 52 216 410 56 216 410 minecraft:black_concrete
fill 57 216 370 57 216 372 minecraft:cyan_concrete
fill 57 216 374 57 216 378 minecraft:cyan_concrete
fill 57 216 380 57 216 384 minecraft:cyan_concrete
fill 57 216 386 57 216 390 minecraft:cyan_concrete
fill 57 216 392 57 216 396 minecraft:cyan_concrete
fill 57 216 398 57 216 402 minecraft:cyan_concrete
fill 57 216 404 57 216 408 minecraft:cyan_concrete
setblock 57 216 410 minecraft:cyan_concrete
fill 58 216 370 62 216 372 minecraft:black_concrete
fill 58 216 374 62 216 378 minecraft:gray_concrete
fill 58 216 380 62 216 384 minecraft:black_concrete
fill 58 216 386 59 216 390 minecraft:gray_concrete
fill 58 216 392 59 216 396 minecraft:black_concrete
fill 58 216 398 62 216 402 minecraft:gray_concrete
fill 58 216 404 62 216 408 minecraft:black_concrete
fill 58 216 410 62 216 410 minecraft:gray_concrete
fill 60 216 386 60 216 388 minecraft:gray_concrete
fill 60 216 389 60 216 393 minecraft:sea_lantern
fill 60 216 394 60 216 396 minecraft:black_concrete
fill 61 216 386 62 216 387 minecraft:gray_concrete
fill 61 216 388 61 216 389 minecraft:sea_lantern
fill 61 216 393 61 216 394 minecraft:sea_lantern
fill 61 216 395 62 216 396 minecraft:black_concrete
fill 62 216 388 65 216 388 minecraft:sea_lantern
fill 62 216 394 65 216 394 minecraft:sea_lantern
fill 63 216 370 63 216 372 minecraft:cyan_concrete
fill 63 216 374 63 216 378 minecraft:cyan_concrete
fill 63 216 380 63 216 384 minecraft:cyan_concrete
fill 63 216 386 63 216 387 minecraft:cyan_concrete
fill 63 216 395 63 216 396 minecraft:cyan_concrete
fill 63 216 398 63 216 402 minecraft:cyan_concrete
fill 63 216 404 63 216 408 minecraft:cyan_concrete
setblock 63 216 410 minecraft:cyan_concrete
fill 64 216 370 68 216 372 minecraft:gray_concrete
fill 64 216 374 68 216 378 minecraft:black_concrete
fill 64 216 380 68 216 384 minecraft:gray_concrete
fill 64 216 386 68 216 387 minecraft:black_concrete
fill 64 216 395 68 216 396 minecraft:gray_concrete
fill 64 216 398 68 216 402 minecraft:black_concrete
fill 64 216 404 68 216 408 minecraft:gray_concrete
fill 64 216 410 68 216 410 minecraft:black_concrete
fill 65 216 389 66 216 389 minecraft:sea_lantern
fill 65 216 393 66 216 393 minecraft:sea_lantern
fill 66 216 388 68 216 388 minecraft:black_concrete
fill 66 216 390 66 216 392 minecraft:sea_lantern
fill 66 216 394 68 216 394 minecraft:gray_concrete
fill 67 216 389 68 216 390 minecraft:black_concrete
fill 67 216 391 88 216 391 minecraft:cyan_concrete
fill 67 216 392 68 216 393 minecraft:gray_concrete
fill 69 216 370 69 216 372 minecraft:cyan_concrete
fill 69 216 374 69 216 378 minecraft:cyan_concrete
fill 69 216 380 69 216 384 minecraft:cyan_concrete
fill 69 216 386 69 216 390 minecraft:cyan_concrete
fill 69 216 392 69 216 396 minecraft:cyan_concrete
fill 69 216 398 69 216 402 minecraft:cyan_concrete
fill 69 216 404 69 216 408 minecraft:cyan_concrete
setblock 69 216 410 minecraft:cyan_concrete
fill 70 216 370 74 216 372 minecraft:black_concrete
fill 70 216 374 74 216 378 minecraft:gray_concrete
fill 70 216 380 74 216 384 minecraft:black_concrete
fill 70 216 386 74 216 390 minecraft:gray_concrete
fill 70 216 392 74 216 396 minecraft:black_concrete
fill 70 216 398 74 216 402 minecraft:gray_concrete
fill 70 216 404 74 216 408 minecraft:black_concrete
fill 70 216 410 74 216 410 minecraft:gray_concrete
fill 75 216 370 75 216 372 minecraft:cyan_concrete
fill 75 216 374 75 216 378 minecraft:cyan_concrete
fill 75 216 380 75 216 384 minecraft:cyan_concrete
fill 75 216 386 75 216 390 minecraft:cyan_concrete
fill 75 216 392 75 216 396 minecraft:cyan_concrete
fill 75 216 398 75 216 402 minecraft:cyan_concrete
fill 75 216 404 75 216 408 minecraft:cyan_concrete
setblock 75 216 410 minecraft:cyan_concrete
fill 76 216 370 80 216 372 minecraft:gray_concrete
fill 76 216 374 80 216 378 minecraft:black_concrete
fill 76 216 380 80 216 384 minecraft:gray_concrete
fill 76 216 386 80 216 390 minecraft:black_concrete
fill 76 216 392 80 216 396 minecraft:gray_concrete
fill 76 216 398 80 216 402 minecraft:black_concrete
fill 76 216 404 80 216 408 minecraft:gray_concrete
fill 76 216 410 80 216 410 minecraft:black_concrete
fill 81 216 370 81 216 372 minecraft:cyan_concrete
fill 81 216 374 81 216 378 minecraft:cyan_concrete
fill 81 216 380 81 216 384 minecraft:cyan_concrete
fill 81 216 386 81 216 390 minecraft:cyan_concrete
fill 81 216 392 81 216 396 minecraft:cyan_concrete
fill 81 216 398 81 216 402 minecraft:cyan_concrete
fill 81 216 404 81 216 408 minecraft:cyan_concrete
setblock 81 216 410 minecraft:cyan_concrete
fill 82 216 370 86 216 372 minecraft:black_concrete
fill 82 216 374 86 216 378 minecraft:gray_concrete
fill 82 216 380 86 216 384 minecraft:black_concrete
fill 82 216 386 86 216 390 minecraft:gray_concrete
fill 82 216 392 86 216 396 minecraft:black_concrete
fill 82 216 398 86 216 402 minecraft:gray_concrete
fill 82 216 404 86 216 408 minecraft:black_concrete
fill 82 216 410 86 216 410 minecraft:gray_concrete
fill 87 216 370 87 216 372 minecraft:cyan_concrete
fill 87 216 374 87 216 378 minecraft:cyan_concrete
fill 87 216 380 87 216 384 minecraft:cyan_concrete
fill 87 216 386 87 216 390 minecraft:cyan_concrete
fill 87 216 392 87 216 396 minecraft:cyan_concrete
fill 87 216 398 87 216 402 minecraft:cyan_concrete
fill 87 216 404 87 216 408 minecraft:cyan_concrete
setblock 87 216 410 minecraft:cyan_concrete
fill 88 216 370 88 216 372 minecraft:gray_concrete
fill 88 216 374 88 216 378 minecraft:black_concrete
fill 88 216 380 88 216 384 minecraft:gray_concrete
fill 88 216 386 88 216 390 minecraft:black_concrete
fill 88 216 392 88 216 396 minecraft:gray_concrete
fill 88 216 398 88 216 402 minecraft:black_concrete
fill 88 216 404 88 216 408 minecraft:gray_concrete
setblock 88 216 410 minecraft:black_concrete
setblock 50 217 372 minecraft:light[level=14]
setblock 50 217 380 minecraft:light[level=14]
setblock 50 217 388 minecraft:light[level=14]
setblock 50 217 396 minecraft:light[level=14]
setblock 50 217 404 minecraft:light[level=14]
setblock 58 217 372 minecraft:light[level=14]
setblock 58 217 380 minecraft:light[level=14]
setblock 58 217 388 minecraft:light[level=14]
setblock 58 217 396 minecraft:light[level=14]
setblock 58 217 404 minecraft:light[level=14]
setblock 66 217 372 minecraft:light[level=14]
setblock 66 217 380 minecraft:light[level=14]
setblock 66 217 388 minecraft:light[level=14]
setblock 66 217 396 minecraft:light[level=14]
setblock 66 217 404 minecraft:light[level=14]
setblock 74 217 372 minecraft:light[level=14]
setblock 74 217 380 minecraft:light[level=14]
setblock 74 217 388 minecraft:light[level=14]
setblock 74 217 396 minecraft:light[level=14]
setblock 74 217 404 minecraft:light[level=14]
setblock 82 217 372 minecraft:light[level=14]
setblock 82 217 380 minecraft:light[level=14]
setblock 82 217 388 minecraft:light[level=14]
setblock 82 217 396 minecraft:light[level=14]
setblock 82 217 404 minecraft:light[level=14]
fill 48 220 376 48 272 377 minecraft:magenta_concrete
fill 48 220 384 48 272 385 minecraft:magenta_concrete
fill 48 220 392 48 272 393 minecraft:magenta_concrete
fill 48 220 400 48 272 401 minecraft:magenta_concrete
fill 48 220 408 48 272 409 minecraft:magenta_concrete
fill 49 220 370 50 272 370 minecraft:magenta_concrete
fill 54 220 410 55 272 410 minecraft:magenta_concrete
fill 57 220 370 58 272 370 minecraft:magenta_concrete
fill 62 220 410 63 272 410 minecraft:magenta_concrete
fill 65 220 370 66 272 370 minecraft:magenta_concrete
fill 70 220 410 71 272 410 minecraft:magenta_concrete
fill 73 220 370 74 272 370 minecraft:magenta_concrete
fill 78 220 410 79 272 410 minecraft:magenta_concrete
fill 79 220 400 88 222 406 minecraft:magenta_concrete
fill 81 220 370 82 272 370 minecraft:magenta_concrete
fill 86 220 410 87 272 410 minecraft:magenta_concrete
fill 88 220 371 88 272 372 minecraft:magenta_concrete
fill 88 220 379 88 272 380 minecraft:magenta_concrete
fill 88 220 387 88 272 388 minecraft:magenta_concrete
fill 88 220 395 88 272 396 minecraft:magenta_concrete
fill 79 223 400 79 230 400 minecraft:magenta_concrete
setblock 79 223 401 minecraft:sea_lantern
fill 79 223 402 79 230 402 minecraft:magenta_concrete
setblock 79 223 403 minecraft:sea_lantern
fill 79 223 404 79 230 404 minecraft:magenta_concrete
setblock 79 223 405 minecraft:sea_lantern
fill 79 223 406 79 230 406 minecraft:magenta_concrete
setblock 80 223 400 minecraft:sea_lantern
fill 80 223 401 80 230 401 minecraft:magenta_concrete
setblock 80 223 402 minecraft:sea_lantern
fill 80 223 403 80 230 403 minecraft:magenta_concrete
setblock 80 223 404 minecraft:sea_lantern
fill 80 223 405 80 230 405 minecraft:magenta_concrete
setblock 80 223 406 minecraft:sea_lantern
fill 81 223 400 81 230 400 minecraft:magenta_concrete
setblock 81 223 401 minecraft:sea_lantern
fill 81 223 402 81 230 402 minecraft:magenta_concrete
setblock 81 223 403 minecraft:sea_lantern
fill 81 223 404 81 230 404 minecraft:magenta_concrete
setblock 81 223 405 minecraft:sea_lantern
fill 81 223 406 81 230 406 minecraft:magenta_concrete
setblock 82 223 400 minecraft:sea_lantern
fill 82 223 401 82 230 401 minecraft:magenta_concrete
setblock 82 223 402 minecraft:sea_lantern
fill 82 223 403 82 230 403 minecraft:magenta_concrete
setblock 82 223 404 minecraft:sea_lantern
fill 82 223 405 82 230 405 minecraft:magenta_concrete
setblock 82 223 406 minecraft:sea_lantern
fill 83 223 400 83 230 400 minecraft:magenta_concrete
setblock 83 223 401 minecraft:sea_lantern
fill 83 223 402 83 230 402 minecraft:magenta_concrete
setblock 83 223 403 minecraft:sea_lantern
fill 83 223 404 83 230 404 minecraft:magenta_concrete
setblock 83 223 405 minecraft:sea_lantern
fill 83 223 406 83 230 406 minecraft:magenta_concrete
setblock 84 223 400 minecraft:sea_lantern
fill 84 223 401 84 230 401 minecraft:magenta_concrete
setblock 84 223 402 minecraft:sea_lantern
fill 84 223 403 84 230 403 minecraft:magenta_concrete
setblock 84 223 404 minecraft:sea_lantern
fill 84 223 405 84 230 405 minecraft:magenta_concrete
setblock 84 223 406 minecraft:sea_lantern
fill 85 223 400 85 230 400 minecraft:magenta_concrete
setblock 85 223 401 minecraft:sea_lantern
fill 85 223 402 85 230 402 minecraft:magenta_concrete
setblock 85 223 403 minecraft:sea_lantern
fill 85 223 404 85 230 404 minecraft:magenta_concrete
setblock 85 223 405 minecraft:sea_lantern
fill 85 223 406 85 230 406 minecraft:magenta_concrete
setblock 86 223 400 minecraft:sea_lantern
fill 86 223 401 86 230 401 minecraft:magenta_concrete
setblock 86 223 402 minecraft:sea_lantern
fill 86 223 403 86 230 403 minecraft:magenta_concrete
setblock 86 223 404 minecraft:sea_lantern
fill 86 223 405 86 230 405 minecraft:magenta_concrete
setblock 86 223 406 minecraft:sea_lantern
fill 87 223 400 87 230 400 minecraft:magenta_concrete
setblock 87 223 401 minecraft:sea_lantern
fill 87 223 402 87 230 402 minecraft:magenta_concrete
setblock 87 223 403 minecraft:sea_lantern
fill 87 223 404 87 230 404 minecraft:magenta_concrete
setblock 87 223 405 minecraft:sea_lantern
fill 87 223 406 87 230 406 minecraft:magenta_concrete
setblock 88 223 400 minecraft:sea_lantern
fill 88 223 401 88 230 401 minecraft:magenta_concrete
setblock 88 223 402 minecraft:sea_lantern
fill 88 223 403 88 272 403 minecraft:magenta_concrete
setblock 88 223 404 minecraft:sea_lantern
fill 88 223 405 88 230 405 minecraft:magenta_concrete
setblock 88 223 406 minecraft:sea_lantern
fill 48 224 370 48 225 375 minecraft:magenta_concrete
fill 48 224 378 49 224 383 minecraft:magenta_concrete
fill 48 224 386 49 224 391 minecraft:magenta_concrete
fill 48 224 394 49 224 399 minecraft:magenta_concrete
fill 48 224 402 49 224 407 minecraft:magenta_concrete
fill 48 224 410 53 225 410 minecraft:magenta_concrete
fill 49 224 371 49 224 377 minecraft:magenta_concrete
fill 49 224 384 49 224 385 minecraft:magenta_concrete
fill 49 224 392 49 224 393 minecraft:magenta_concrete
fill 49 224 400 49 224 401 minecraft:magenta_concrete
fill 49 224 408 49 224 409 minecraft:magenta_concrete
fill 50 224 371 87 224 371 minecraft:magenta_concrete
fill 50 224 409 88 224 409 minecraft:magenta_concrete
fill 51 224 370 56 225 370 minecraft:magenta_concrete
fill 56 224 410 61 225 410 minecraft:magenta_concrete
fill 59 224 370 64 225 370 minecraft:magenta_concrete
fill 64 224 410 69 225 410 minecraft:magenta_concrete
fill 67 224 370 72 225 370 minecraft:magenta_concrete
fill 72 224 410 77 225 410 minecraft:magenta_concrete
fill 75 224 370 80 225 370 minecraft:magenta_concrete
fill 79 224 401 79 225 401 minecraft:magenta_concrete
fill 79 224 403 79 225 403 minecraft:magenta_concrete
fill 79 224 405 79 225 405 minecraft:magenta_concrete
fill 80 224 400 80 225 400 minecraft:magenta_concrete
fill 80 224 402 80 225 402 minecraft:magenta_concrete
fill 80 224 404 80 225 404 minecraft:magenta_concrete
fill 80 224 406 80 225 406 minecraft:magenta_concrete
fill 80 224 410 85 225 410 minecraft:magenta_concrete
fill 81 224 401 81 225 401 minecraft:magenta_concrete
fill 81 224 403 81 225 403 minecraft:magenta_concrete
fill 81 224 405 81 225 405 minecraft:magenta_concrete
fill 82 224 400 82 225 400 minecraft:magenta_concrete
fill 82 224 402 82 225 402 minecraft:magenta_concrete
fill 82 224 404 82 225 404 minecraft:magenta_concrete
fill 82 224 406 82 225 406 minecraft:magenta_concrete
fill 83 224 370 88 225 370 minecraft:magenta_concrete
fill 83 224 401 83 225 401 minecraft:magenta_concrete
fill 83 224 403 83 225 403 minecraft:magenta_concrete
fill 83 224 405 83 225 405 minecraft:magenta_concrete
fill 84 224 400 84 225 400 minecraft:magenta_concrete
fill 84 224 402 84 225 402 minecraft:magenta_concrete
fill 84 224 404 84 225 404 minecraft:magenta_concrete
fill 84 224 406 84 225 406 minecraft:magenta_concrete
fill 85 224 401 85 225 401 minecraft:magenta_concrete
fill 85 224 403 85 225 403 minecraft:magenta_concrete
fill 85 224 405 85 225 405 minecraft:magenta_concrete
fill 86 224 400 86 225 400 minecraft:magenta_concrete
fill 86 224 402 86 225 402 minecraft:magenta_concrete
fill 86 224 404 86 225 404 minecraft:magenta_concrete
fill 86 224 406 86 225 406 minecraft:magenta_concrete
fill 87 224 372 87 224 399 minecraft:magenta_concrete
fill 87 224 401 87 225 401 minecraft:magenta_concrete
fill 87 224 403 87 225 403 minecraft:magenta_concrete
fill 87 224 405 87 225 405 minecraft:magenta_concrete
fill 87 224 407 88 224 408 minecraft:magenta_concrete
fill 88 224 373 88 225 378 minecraft:magenta_concrete
fill 88 224 381 88 225 386 minecraft:magenta_concrete
fill 88 224 389 88 225 394 minecraft:magenta_concrete
fill 88 224 397 88 225 400 minecraft:magenta_concrete
fill 88 224 402 88 225 402 minecraft:magenta_concrete
fill 88 224 404 88 225 404 minecraft:magenta_concrete
fill 88 224 406 88 225 406 minecraft:magenta_concrete
fill 88 224 410 88 225 410 minecraft:magenta_concrete
fill 48 225 378 48 225 383 minecraft:magenta_concrete
fill 48 225 386 48 225 391 minecraft:magenta_concrete
fill 48 225 394 48 225 399 minecraft:magenta_concrete
fill 48 225 402 48 225 407 minecraft:magenta_concrete
setblock 50 225 372 minecraft:light[level=14]
setblock 50 225 380 minecraft:light[level=14]
setblock 50 225 388 minecraft:light[level=14]
setblock 50 225 396 minecraft:light[level=14]
setblock 50 225 404 minecraft:light[level=14]
setblock 58 225 372 minecraft:light[level=14]
setblock 58 225 380 minecraft:light[level=14]
setblock 58 225 388 minecraft:light[level=14]
setblock 58 225 396 minecraft:light[level=14]
setblock 58 225 404 minecraft:light[level=14]
setblock 66 225 372 minecraft:light[level=14]
setblock 66 225 380 minecraft:light[level=14]
setblock 66 225 388 minecraft:light[level=14]
setblock 66 225 396 minecraft:light[level=14]
setblock 66 225 404 minecraft:light[level=14]
setblock 74 225 372 minecraft:light[level=14]
setblock 74 225 380 minecraft:light[level=14]
setblock 74 225 388 minecraft:light[level=14]
setblock 74 225 396 minecraft:light[level=14]
setblock 74 225 404 minecraft:light[level=14]
setblock 82 225 372 minecraft:light[level=14]
setblock 82 225 380 minecraft:light[level=14]
setblock 82 225 388 minecraft:light[level=14]
setblock 82 225 396 minecraft:light[level=14]
fill 88 225 407 88 225 409 minecraft:magenta_concrete
setblock 79 226 401 minecraft:sea_lantern
setblock 79 226 403 minecraft:sea_lantern
setblock 79 226 405 minecraft:sea_lantern
setblock 80 226 400 minecraft:sea_lantern
setblock 80 226 402 minecraft:sea_lantern
setblock 80 226 404 minecraft:sea_lantern
setblock 80 226 406 minecraft:sea_lantern
setblock 81 226 401 minecraft:sea_lantern
setblock 81 226 403 minecraft:sea_lantern
setblock 81 226 405 minecraft:sea_lantern
setblock 82 226 400 minecraft:sea_lantern
setblock 82 226 402 minecraft:sea_lantern
setblock 82 226 404 minecraft:sea_lantern
setblock 82 226 406 minecraft:sea_lantern
setblock 83 226 401 minecraft:sea_lantern
setblock 83 226 403 minecraft:sea_lantern
setblock 83 226 405 minecraft:sea_lantern
setblock 84 226 400 minecraft:sea_lantern
setblock 84 226 402 minecraft:sea_lantern
setblock 84 226 404 minecraft:sea_lantern
setblock 84 226 406 minecraft:sea_lantern
setblock 85 226 401 minecraft:sea_lantern
setblock 85 226 403 minecraft:sea_lantern
setblock 85 226 405 minecraft:sea_lantern
setblock 86 226 400 minecraft:sea_lantern
setblock 86 226 402 minecraft:sea_lantern
setblock 86 226 404 minecraft:sea_lantern
setblock 86 226 406 minecraft:sea_lantern
setblock 87 226 401 minecraft:sea_lantern
setblock 87 226 403 minecraft:sea_lantern
setblock 87 226 405 minecraft:sea_lantern
setblock 88 226 400 minecraft:sea_lantern
setblock 88 226 402 minecraft:sea_lantern
setblock 88 226 404 minecraft:sea_lantern
setblock 88 226 406 minecraft:sea_lantern
fill 79 227 401 79 228 401 minecraft:magenta_concrete
fill 79 227 403 79 228 403 minecraft:magenta_concrete
fill 79 227 405 79 228 405 minecraft:magenta_concrete
fill 80 227 400 80 228 400 minecraft:magenta_concrete
fill 80 227 402 80 228 402 minecraft:magenta_concrete
fill 80 227 404 80 228 404 minecraft:magenta_concrete
fill 80 227 406 80 228 406 minecraft:magenta_concrete
fill 80 227 407 80 228 409 minecraft:gray_concrete
fill 81 227 401 81 228 401 minecraft:magenta_concrete
fill 81 227 403 81 228 403 minecraft:magenta_concrete
fill 81 227 405 81 228 405 minecraft:magenta_concrete
fill 82 227 400 82 228 400 minecraft:magenta_concrete
fill 82 227 402 82 228 402 minecraft:magenta_concrete
fill 82 227 404 82 228 404 minecraft:magenta_concrete
fill 82 227 406 82 228 406 minecraft:magenta_concrete
fill 83 227 401 83 228 401 minecraft:magenta_concrete
fill 83 227 403 83 228 403 minecraft:magenta_concrete
fill 83 227 405 83 228 405 minecraft:magenta_concrete
fill 84 227 400 84 228 400 minecraft:magenta_concrete
fill 84 227 402 84 228 402 minecraft:magenta_concrete
fill 84 227 404 84 228 404 minecraft:magenta_concrete
fill 84 227 406 84 228 406 minecraft:magenta_concrete
fill 85 227 401 85 228 401 minecraft:magenta_concrete
fill 85 227 403 85 228 403 minecraft:magenta_concrete
fill 85 227 405 85 228 405 minecraft:magenta_concrete
fill 86 227 400 86 228 400 minecraft:magenta_concrete
fill 86 227 402 86 228 402 minecraft:magenta_concrete
fill 86 227 404 86 228 404 minecraft:magenta_concrete
fill 86 227 406 86 228 406 minecraft:magenta_concrete
fill 87 227 401 87 228 401 minecraft:magenta_concrete
fill 87 227 403 87 228 403 minecraft:magenta_concrete
fill 87 227 405 87 228 405 minecraft:magenta_concrete
fill 88 227 400 88 228 400 minecraft:magenta_concrete
fill 88 227 402 88 228 402 minecraft:magenta_concrete
fill 88 227 404 88 228 404 minecraft:magenta_concrete
fill 88 227 406 88 228 406 minecraft:magenta_concrete
fill 47 228 374 47 233 374 minecraft:sea_lantern
fill 47 228 382 47 233 382 minecraft:sea_lantern
fill 47 228 390 47 233 390 minecraft:sea_lantern
fill 47 228 398 47 233 398 minecraft:sea_lantern
fill 47 228 406 47 233 406 minecraft:sea_lantern
fill 50 228 411 50 233 411 minecraft:sea_lantern
fill 54 228 369 54 233 369 minecraft:sea_lantern
fill 58 228 411 58 233 411 minecraft:sea_lantern
fill 62 228 369 62 233 369 minecraft:sea_lantern
fill 66 228 411 66 233 411 minecraft:sea_lantern
fill 70 228 369 70 233 369 minecraft:sea_lantern
fill 74 228 411 74 233 411 minecraft:sea_lantern
fill 78 228 369 78 233 369 minecraft:sea_lantern
fill 82 228 411 82 233 411 minecraft:sea_lantern
fill 86 228 369 86 233 369 minecraft:sea_lantern
fill 89 228 374 89 233 374 minecraft:sea_lantern
fill 89 228 382 89 233 382 minecraft:sea_lantern
fill 89 228 390 89 233 390 minecraft:sea_lantern
fill 89 228 398 89 233 398 minecraft:sea_lantern
fill 89 228 406 89 233 406 minecraft:sea_lantern
setblock 79 229 401 minecraft:sea_lantern
setblock 79 229 403 minecraft:sea_lantern
setblock 79 229 405 minecraft:sea_lantern
setblock 80 229 400 minecraft:sea_lantern
setblock 80 229 402 minecraft:sea_lantern
setblock 80 229 404 minecraft:sea_lantern
setblock 80 229 406 minecraft:sea_lantern
setblock 81 229 401 minecraft:sea_lantern
setblock 81 229 403 minecraft:sea_lantern
setblock 81 229 405 minecraft:sea_lantern
setblock 82 229 400 minecraft:sea_lantern
setblock 82 229 402 minecraft:sea_lantern
setblock 82 229 404 minecraft:sea_lantern
setblock 82 229 406 minecraft:sea_lantern
setblock 83 229 401 minecraft:sea_lantern
setblock 83 229 403 minecraft:sea_lantern
setblock 83 229 405 minecraft:sea_lantern
setblock 84 229 400 minecraft:sea_lantern
setblock 84 229 402 minecraft:sea_lantern
setblock 84 229 404 minecraft:sea_lantern
setblock 84 229 406 minecraft:sea_lantern
setblock 85 229 401 minecraft:sea_lantern
setblock 85 229 403 minecraft:sea_lantern
setblock 85 229 405 minecraft:sea_lantern
setblock 86 229 400 minecraft:sea_lantern
setblock 86 229 402 minecraft:sea_lantern
setblock 86 229 404 minecraft:sea_lantern
setblock 86 229 406 minecraft:sea_lantern
setblock 87 229 401 minecraft:sea_lantern
setblock 87 229 403 minecraft:sea_lantern
setblock 87 229 405 minecraft:sea_lantern
setblock 88 229 400 minecraft:sea_lantern
setblock 88 229 402 minecraft:sea_lantern
setblock 88 229 404 minecraft:sea_lantern
setblock 88 229 406 minecraft:sea_lantern
setblock 79 230 401 minecraft:magenta_concrete
setblock 79 230 403 minecraft:magenta_concrete
setblock 79 230 405 minecraft:magenta_concrete
setblock 80 230 400 minecraft:magenta_concrete
setblock 80 230 402 minecraft:magenta_concrete
setblock 80 230 404 minecraft:magenta_concrete
setblock 80 230 406 minecraft:magenta_concrete
setblock 81 230 401 minecraft:magenta_concrete
setblock 81 230 403 minecraft:magenta_concrete
setblock 81 230 405 minecraft:magenta_concrete
setblock 82 230 400 minecraft:magenta_concrete
setblock 82 230 402 minecraft:magenta_concrete
setblock 82 230 404 minecraft:magenta_concrete
setblock 82 230 406 minecraft:magenta_concrete
setblock 83 230 401 minecraft:magenta_concrete
setblock 83 230 403 minecraft:magenta_concrete
setblock 83 230 405 minecraft:magenta_concrete
setblock 84 230 400 minecraft:magenta_concrete
setblock 84 230 402 minecraft:magenta_concrete
setblock 84 230 404 minecraft:magenta_concrete
setblock 84 230 406 minecraft:magenta_concrete
setblock 85 230 401 minecraft:magenta_concrete
setblock 85 230 403 minecraft:magenta_concrete
setblock 85 230 405 minecraft:magenta_concrete
setblock 86 230 400 minecraft:magenta_concrete
setblock 86 230 402 minecraft:magenta_concrete
setblock 86 230 404 minecraft:magenta_concrete
setblock 86 230 406 minecraft:magenta_concrete
setblock 87 230 401 minecraft:magenta_concrete
setblock 87 230 403 minecraft:magenta_concrete
setblock 87 230 405 minecraft:magenta_concrete
setblock 88 230 400 minecraft:magenta_concrete
setblock 88 230 402 minecraft:magenta_concrete
fill 88 230 404 88 272 404 minecraft:magenta_concrete
setblock 88 230 406 minecraft:magenta_concrete
setblock 50 233 372 minecraft:light[level=14]
setblock 50 233 380 minecraft:light[level=14]
setblock 50 233 388 minecraft:light[level=14]
setblock 50 233 396 minecraft:light[level=14]
setblock 50 233 404 minecraft:light[level=14]
setblock 58 233 372 minecraft:light[level=14]
setblock 58 233 380 minecraft:light[level=14]
setblock 58 233 388 minecraft:light[level=14]
setblock 58 233 396 minecraft:light[level=14]
setblock 58 233 404 minecraft:light[level=14]
setblock 66 233 372 minecraft:light[level=14]
setblock 66 233 380 minecraft:light[level=14]
setblock 66 233 388 minecraft:light[level=14]
setblock 66 233 396 minecraft:light[level=14]
setblock 66 233 404 minecraft:light[level=14]
setblock 74 233 372 minecraft:light[level=14]
setblock 74 233 380 minecraft:light[level=14]
setblock 74 233 388 minecraft:light[level=14]
setblock 74 233 396 minecraft:light[level=14]
setblock 74 233 404 minecraft:light[level=14]
setblock 82 233 372 minecraft:light[level=14]
setblock 82 233 380 minecraft:light[level=14]
setblock 82 233 388 minecraft:light[level=14]
setblock 82 233 396 minecraft:light[level=14]
setblock 82 233 404 minecraft:light[level=14]
fill 47 234 374 47 241 374 minecraft:black_concrete
fill 47 234 382 47 241 382 minecraft:black_concrete
fill 47 234 390 47 241 390 minecraft:black_concrete
fill 47 234 398 47 241 398 minecraft:black_concrete
fill 47 234 406 47 241 406 minecraft:black_concrete
fill 50 234 411 50 241 411 minecraft:black_concrete
fill 54 234 369 54 241 369 minecraft:black_concrete
fill 58 234 411 58 241 411 minecraft:black_concrete
fill 59 234 385 59 235 385 minecraft:yellow_concrete
fill 62 234 369 62 241 369 minecraft:black_concrete
fill 66 234 411 66 241 411 minecraft:black_concrete
fill 70 234 369 70 241 369 minecraft:black_concrete
fill 74 234 411 74 241 411 minecraft:black_concrete
fill 78 234 369 78 241 369 minecraft:black_concrete
fill 82 234 411 82 241 411 minecraft:black_concrete
fill 86 234 369 86 241 369 minecraft:black_concrete
fill 89 234 374 89 241 374 minecraft:black_concrete
fill 89 234 382 89 241 382 minecraft:black_concrete
fill 89 234 390 89 241 390 minecraft:black_concrete
fill 89 234 398 89 241 398 minecraft:black_concrete
fill 89 234 406 89 241 406 minecraft:black_concrete
fill 48 238 370 48 239 375 minecraft:magenta_concrete
fill 48 238 378 49 238 383 minecraft:magenta_concrete
fill 48 238 386 49 238 391 minecraft:magenta_concrete
fill 48 238 394 49 238 399 minecraft:magenta_concrete
fill 48 238 402 49 238 407 minecraft:magenta_concrete
fill 48 238 410 53 239 410 minecraft:magenta_concrete
fill 49 238 371 49 238 377 minecraft:magenta_concrete
fill 49 238 384 49 238 385 minecraft:magenta_concrete
fill 49 238 392 49 238 393 minecraft:magenta_concrete
fill 49 238 400 49 238 401 minecraft:magenta_concrete
fill 49 238 408 49 238 409 minecraft:magenta_concrete
fill 50 238 371 87 238 371 minecraft:magenta_concrete
fill 50 238 409 88 238 409 minecraft:magenta_concrete
fill 51 238 370 56 239 370 minecraft:magenta_concrete
fill 56 238 410 61 239 410 minecraft:magenta_concrete
fill 59 238 370 64 239 370 minecraft:magenta_concrete
fill 64 238 410 69 239 410 minecraft:magenta_concrete
fill 67 238 370 72 239 370 minecraft:magenta_concrete
fill 72 238 410 77 239 410 minecraft:magenta_concrete
fill 75 238 370 80 239 370 minecraft:magenta_concrete
fill 80 238 410 85 239 410 minecraft:magenta_concrete
fill 83 238 370 88 239 370 minecraft:magenta_concrete
fill 87 238 372 87 238 408 minecraft:magenta_concrete
fill 88 238 373 88 239 378 minecraft:magenta_concrete
fill 88 238 381 88 239 386 minecraft:magenta_concrete
fill 88 238 389 88 239 394 minecraft:magenta_concrete
fill 88 238 397 88 239 402 minecraft:magenta_concrete
fill 88 238 405 88 239 408 minecraft:magenta_concrete
fill 88 238 410 88 239 410 minecraft:magenta_concrete
fill 48 239 378 48 239 383 minecraft:magenta_concrete
fill 48 239 386 48 239 391 minecraft:magenta_concrete
fill 48 239 394 48 239 399 minecraft:magenta_concrete
fill 48 239 402 48 239 407 minecraft:magenta_concrete
fill 49 239 397 50 240 397 minecraft:gray_concrete
fill 78 239 396 78 240 397 minecraft:lime_concrete
setblock 88 239 409 minecraft:magenta_concrete
setblock 48 240 397 minecraft:gray_concrete
setblock 50 241 372 minecraft:light[level=14]
setblock 50 241 380 minecraft:light[level=14]
setblock 50 241 388 minecraft:light[level=14]
setblock 50 241 396 minecraft:light[level=14]
setblock 50 241 404 minecraft:light[level=14]
setblock 58 241 372 minecraft:light[level=14]
setblock 58 241 380 minecraft:light[level=14]
setblock 58 241 388 minecraft:light[level=14]
setblock 58 241 396 minecraft:light[level=14]
setblock 58 241 404 minecraft:light[level=14]
setblock 66 241 372 minecraft:light[level=14]
setblock 66 241 380 minecraft:light[level=14]
setblock 66 241 388 minecraft:light[level=14]
setblock 66 241 396 minecraft:light[level=14]
setblock 66 241 404 minecraft:light[level=14]
setblock 74 241 372 minecraft:light[level=14]
setblock 74 241 380 minecraft:light[level=14]
setblock 74 241 388 minecraft:light[level=14]
setblock 74 241 396 minecraft:light[level=14]
setblock 74 241 404 minecraft:light[level=14]
setblock 82 241 372 minecraft:light[level=14]
setblock 82 241 380 minecraft:light[level=14]
setblock 82 241 388 minecraft:light[level=14]
setblock 82 241 396 minecraft:light[level=14]
setblock 82 241 404 minecraft:light[level=14]
fill 47 242 374 47 247 374 minecraft:sea_lantern
fill 47 242 382 47 247 382 minecraft:sea_lantern
fill 47 242 390 47 247 390 minecraft:sea_lantern
fill 47 242 398 47 247 398 minecraft:sea_lantern
fill 47 242 406 47 247 406 minecraft:sea_lantern
fill 50 242 411 50 247 411 minecraft:sea_lantern
fill 54 242 369 54 247 369 minecraft:sea_lantern
fill 58 242 411 58 247 411 minecraft:sea_lantern
fill 62 242 369 62 247 369 minecraft:sea_lantern
fill 66 242 411 66 247 411 minecraft:sea_lantern
fill 70 242 369 70 247 369 minecraft:sea_lantern
fill 74 242 411 74 247 411 minecraft:sea_lantern
fill 78 242 369 78 247 369 minecraft:sea_lantern
fill 82 242 411 82 247 411 minecraft:sea_lantern
fill 86 242 369 86 247 369 minecraft:sea_lantern
fill 89 242 374 89 247 374 minecraft:sea_lantern
fill 89 242 382 89 247 382 minecraft:sea_lantern
fill 89 242 390 89 247 390 minecraft:sea_lantern
fill 89 242 398 89 247 398 minecraft:sea_lantern
fill 89 242 406 89 247 406 minecraft:sea_lantern
fill 47 248 374 47 255 374 minecraft:black_concrete
fill 47 248 382 47 255 382 minecraft:black_concrete
fill 47 248 390 47 255 390 minecraft:black_concrete
fill 47 248 398 47 255 398 minecraft:black_concrete
fill 47 248 406 47 255 406 minecraft:black_concrete
fill 50 248 411 50 255 411 minecraft:black_concrete
fill 54 248 369 54 255 369 minecraft:black_concrete
fill 58 248 411 58 255 411 minecraft:black_concrete
fill 62 248 369 62 255 369 minecraft:black_concrete
fill 66 248 411 66 255 411 minecraft:black_concrete
fill 70 248 369 70 255 369 minecraft:black_concrete
fill 74 248 411 74 255 411 minecraft:black_concrete
fill 78 248 369 78 255 369 minecraft:black_concrete
fill 82 248 411 82 255 411 minecraft:black_concrete
fill 86 248 369 86 255 369 minecraft:black_concrete
fill 89 248 374 89 255 374 minecraft:black_concrete
fill 89 248 382 89 255 382 minecraft:black_concrete
fill 89 248 390 89 255 390 minecraft:black_concrete
fill 89 248 398 89 255 398 minecraft:black_concrete
fill 89 248 406 89 255 406 minecraft:black_concrete
setblock 50 249 372 minecraft:light[level=14]
setblock 50 249 380 minecraft:light[level=14]
setblock 50 249 388 minecraft:light[level=14]
setblock 50 249 396 minecraft:light[level=14]
setblock 50 249 404 minecraft:light[level=14]
setblock 58 249 372 minecraft:light[level=14]
setblock 58 249 380 minecraft:light[level=14]
setblock 58 249 388 minecraft:light[level=14]
setblock 58 249 396 minecraft:light[level=14]
setblock 58 249 404 minecraft:light[level=14]
setblock 66 249 372 minecraft:light[level=14]
setblock 66 249 380 minecraft:light[level=14]
setblock 66 249 388 minecraft:light[level=14]
setblock 66 249 396 minecraft:light[level=14]
setblock 66 249 404 minecraft:light[level=14]
setblock 74 249 372 minecraft:light[level=14]
setblock 74 249 380 minecraft:light[level=14]
setblock 74 249 388 minecraft:light[level=14]
setblock 74 249 396 minecraft:light[level=14]
setblock 74 249 404 minecraft:light[level=14]
setblock 82 249 372 minecraft:light[level=14]
setblock 82 249 380 minecraft:light[level=14]
setblock 82 249 388 minecraft:light[level=14]
setblock 82 249 396 minecraft:light[level=14]
setblock 82 249 404 minecraft:light[level=14]
fill 62 250 370 62 251 372 minecraft:gray_concrete
fill 48 252 370 48 253 375 minecraft:magenta_concrete
fill 48 252 378 49 252 383 minecraft:magenta_concrete
fill 48 252 386 49 252 391 minecraft:magenta_concrete
fill 48 252 394 49 252 399 minecraft:magenta_concrete
fill 48 252 402 49 252 407 minecraft:magenta_concrete
fill 48 252 410 53 253 410 minecraft:magenta_concrete
fill 49 252 371 49 252 377 minecraft:magenta_concrete
fill 49 252 384 49 252 385 minecraft:magenta_concrete
fill 49 252 392 49 252 393 minecraft:magenta_concrete
fill 49 252 400 49 252 401 minecraft:magenta_concrete
fill 49 252 408 49 252 409 minecraft:magenta_concrete
fill 50 252 371 87 252 371 minecraft:magenta_concrete
fill 50 252 409 88 252 409 minecraft:magenta_concrete
fill 51 252 370 56 253 370 minecraft:magenta_concrete
fill 56 252 410 61 253 410 minecraft:magenta_concrete
fill 59 252 370 64 253 370 minecraft:magenta_concrete
fill 64 252 410 69 253 410 minecraft:magenta_concrete
fill 67 252 370 72 253 370 minecraft:magenta_concrete
fill 72 252 410 77 253 410 minecraft:magenta_concrete
fill 75 252 370 80 253 370 minecraft:magenta_concrete
fill 80 252 410 85 253 410 minecraft:magenta_concrete
fill 83 252 370 88 253 370 minecraft:magenta_concrete
fill 87 252 372 87 252 408 minecraft:magenta_concrete
fill 88 252 373 88 253 378 minecraft:magenta_concrete
fill 88 252 381 88 253 386 minecraft:magenta_concrete
fill 88 252 389 88 253 394 minecraft:magenta_concrete
fill 88 252 397 88 253 402 minecraft:magenta_concrete
fill 88 252 405 88 253 408 minecraft:magenta_concrete
fill 88 252 410 88 253 410 minecraft:magenta_concrete
fill 48 253 378 48 253 383 minecraft:magenta_concrete
fill 48 253 386 48 253 391 minecraft:magenta_concrete
fill 48 253 394 48 253 399 minecraft:magenta_concrete
fill 48 253 402 48 253 407 minecraft:magenta_concrete
setblock 88 253 409 minecraft:magenta_concrete
fill 47 256 374 47 261 374 minecraft:sea_lantern
fill 47 256 382 47 261 382 minecraft:sea_lantern
fill 47 256 390 47 261 390 minecraft:sea_lantern
fill 47 256 398 47 261 398 minecraft:sea_lantern
fill 47 256 406 47 261 406 minecraft:sea_lantern
fill 50 256 411 50 261 411 minecraft:sea_lantern
fill 54 256 369 54 261 369 minecraft:sea_lantern
fill 58 256 411 58 261 411 minecraft:sea_lantern
fill 62 256 369 62 261 369 minecraft:sea_lantern
fill 66 256 411 66 261 411 minecraft:sea_lantern
fill 70 256 369 70 261 369 minecraft:sea_lantern
fill 74 256 411 74 261 411 minecraft:sea_lantern
fill 78 256 369 78 261 369 minecraft:sea_lantern
fill 82 256 411 82 261 411 minecraft:sea_lantern
fill 86 256 369 86 261 369 minecraft:sea_lantern
fill 89 256 374 89 261 374 minecraft:sea_lantern
fill 89 256 382 89 261 382 minecraft:sea_lantern
fill 89 256 390 89 261 390 minecraft:sea_lantern
fill 89 256 398 89 261 398 minecraft:sea_lantern
fill 89 256 406 89 261 406 minecraft:sea_lantern
setblock 50 257 372 minecraft:light[level=14]
setblock 50 257 380 minecraft:light[level=14]
setblock 50 257 388 minecraft:light[level=14]
setblock 50 257 396 minecraft:light[level=14]
setblock 50 257 404 minecraft:light[level=14]
setblock 58 257 372 minecraft:light[level=14]
setblock 58 257 380 minecraft:light[level=14]
setblock 58 257 388 minecraft:light[level=14]
setblock 58 257 396 minecraft:light[level=14]
setblock 58 257 404 minecraft:light[level=14]
setblock 66 257 372 minecraft:light[level=14]
setblock 66 257 380 minecraft:light[level=14]
setblock 66 257 388 minecraft:light[level=14]
setblock 66 257 396 minecraft:light[level=14]
setblock 66 257 404 minecraft:light[level=14]
setblock 74 257 372 minecraft:light[level=14]
setblock 74 257 380 minecraft:light[level=14]
setblock 74 257 388 minecraft:light[level=14]
setblock 74 257 396 minecraft:light[level=14]
setblock 74 257 404 minecraft:light[level=14]
setblock 82 257 372 minecraft:light[level=14]
setblock 82 257 380 minecraft:light[level=14]
setblock 82 257 388 minecraft:light[level=14]
setblock 82 257 396 minecraft:light[level=14]
setblock 82 257 404 minecraft:light[level=14]
fill 47 262 374 47 269 374 minecraft:black_concrete
fill 47 262 382 47 269 382 minecraft:black_concrete
fill 47 262 390 47 269 390 minecraft:black_concrete
fill 47 262 398 47 269 398 minecraft:black_concrete
fill 47 262 406 47 269 406 minecraft:black_concrete
fill 50 262 411 50 269 411 minecraft:black_concrete
fill 54 262 369 54 269 369 minecraft:black_concrete
fill 58 262 411 58 269 411 minecraft:black_concrete
fill 62 262 369 62 269 369 minecraft:black_concrete
fill 66 262 411 66 269 411 minecraft:black_concrete
fill 70 262 369 70 269 369 minecraft:black_concrete
fill 74 262 411 74 269 411 minecraft:black_concrete
fill 78 262 369 78 269 369 minecraft:black_concrete
fill 82 262 411 82 269 411 minecraft:black_concrete
fill 86 262 369 86 269 369 minecraft:black_concrete
fill 89 262 374 89 269 374 minecraft:black_concrete
fill 89 262 382 89 269 382 minecraft:black_concrete
fill 89 262 390 89 269 390 minecraft:black_concrete
fill 89 262 398 89 269 398 minecraft:black_concrete
fill 89 262 406 89 269 406 minecraft:black_concrete
fill 54 263 386 54 264 387 minecraft:yellow_concrete
setblock 50 265 372 minecraft:light[level=14]
setblock 50 265 380 minecraft:light[level=14]
setblock 50 265 388 minecraft:light[level=14]
setblock 50 265 396 minecraft:light[level=14]
setblock 50 265 404 minecraft:light[level=14]
setblock 58 265 372 minecraft:light[level=14]
setblock 58 265 380 minecraft:light[level=14]
setblock 58 265 388 minecraft:light[level=14]
setblock 58 265 396 minecraft:light[level=14]
setblock 58 265 404 minecraft:light[level=14]
setblock 66 265 372 minecraft:light[level=14]
setblock 66 265 380 minecraft:light[level=14]
setblock 66 265 388 minecraft:light[level=14]
setblock 66 265 396 minecraft:light[level=14]
setblock 66 265 404 minecraft:light[level=14]
setblock 74 265 372 minecraft:light[level=14]
setblock 74 265 380 minecraft:light[level=14]
setblock 74 265 388 minecraft:light[level=14]
setblock 74 265 396 minecraft:light[level=14]
setblock 74 265 404 minecraft:light[level=14]
setblock 82 265 372 minecraft:light[level=14]
setblock 82 265 380 minecraft:light[level=14]
setblock 82 265 388 minecraft:light[level=14]
setblock 82 265 396 minecraft:light[level=14]
setblock 82 265 404 minecraft:light[level=14]
fill 48 266 370 48 267 375 minecraft:magenta_concrete
fill 48 266 378 49 266 383 minecraft:magenta_concrete
fill 48 266 386 49 266 391 minecraft:magenta_concrete
fill 48 266 394 49 266 399 minecraft:magenta_concrete
fill 48 266 402 49 266 407 minecraft:magenta_concrete
fill 48 266 410 53 267 410 minecraft:magenta_concrete
fill 49 266 371 49 266 377 minecraft:magenta_concrete
fill 49 266 384 49 266 385 minecraft:magenta_concrete
fill 49 266 392 49 266 393 minecraft:magenta_concrete
fill 49 266 400 49 266 401 minecraft:magenta_concrete
fill 49 266 408 49 266 409 minecraft:magenta_concrete
fill 50 266 371 87 266 371 minecraft:magenta_concrete
fill 50 266 409 88 266 409 minecraft:magenta_concrete
fill 51 266 370 56 267 370 minecraft:magenta_concrete
fill 56 266 410 61 267 410 minecraft:magenta_concrete
fill 59 266 370 64 267 370 minecraft:magenta_concrete
fill 64 266 410 69 267 410 minecraft:magenta_concrete
fill 67 266 370 72 267 370 minecraft:magenta_concrete
fill 72 266 410 77 267 410 minecraft:magenta_concrete
fill 75 266 370 80 267 370 minecraft:magenta_concrete
fill 80 266 410 85 267 410 minecraft:magenta_concrete
fill 83 266 370 88 267 370 minecraft:magenta_concrete
fill 87 266 372 87 266 408 minecraft:magenta_concrete
fill 88 266 373 88 267 378 minecraft:magenta_concrete
fill 88 266 381 88 267 386 minecraft:magenta_concrete
fill 88 266 389 88 267 394 minecraft:magenta_concrete
fill 88 266 397 88 267 402 minecraft:magenta_concrete
fill 88 266 405 88 267 408 minecraft:magenta_concrete
fill 88 266 410 88 267 410 minecraft:magenta_concrete
fill 48 267 378 48 267 383 minecraft:magenta_concrete
fill 48 267 386 48 267 391 minecraft:magenta_concrete
fill 48 267 394 48 267 399 minecraft:magenta_concrete
fill 48 267 402 48 267 407 minecraft:magenta_concrete
setblock 88 267 409 minecraft:magenta_concrete
fill 47 270 374 47 272 374 minecraft:sea_lantern
fill 47 270 382 47 272 382 minecraft:sea_lantern
fill 47 270 390 47 272 390 minecraft:sea_lantern
fill 47 270 398 47 272 398 minecraft:sea_lantern
fill 47 270 406 47 272 406 minecraft:sea_lantern
fill 50 270 411 50 272 411 minecraft:sea_lantern
fill 54 270 369 54 272 369 minecraft:sea_lantern
fill 58 270 411 58 272 411 minecraft:sea_lantern
fill 62 270 369 62 272 369 minecraft:sea_lantern
fill 66 270 411 66 272 411 minecraft:sea_lantern
fill 70 270 369 70 272 369 minecraft:sea_lantern
fill 74 270 411 74 272 411 minecraft:sea_lantern
fill 78 270 369 78 272 369 minecraft:sea_lantern
fill 82 270 411 82 272 411 minecraft:sea_lantern
fill 86 270 369 86 272 369 minecraft:sea_lantern
fill 89 270 374 89 272 374 minecraft:sea_lantern
fill 89 270 382 89 272 382 minecraft:sea_lantern
fill 89 270 390 89 272 390 minecraft:sea_lantern
fill 89 270 398 89 272 398 minecraft:sea_lantern
fill 89 270 406 89 272 406 minecraft:sea_lantern
fill 47 273 374 47 283 374 minecraft:black_concrete
fill 47 273 382 47 283 382 minecraft:black_concrete
fill 47 273 390 47 283 390 minecraft:black_concrete
fill 47 273 398 47 283 398 minecraft:black_concrete
fill 47 273 406 47 283 406 minecraft:black_concrete
setblock 50 273 372 minecraft:light[level=14]
setblock 50 273 380 minecraft:light[level=14]
setblock 50 273 388 minecraft:light[level=14]
setblock 50 273 396 minecraft:light[level=14]
setblock 50 273 404 minecraft:light[level=14]
fill 50 273 411 50 283 411 minecraft:black_concrete
fill 54 273 369 54 283 369 minecraft:black_concrete
setblock 58 273 372 minecraft:light[level=14]
setblock 58 273 380 minecraft:light[level=14]
setblock 58 273 388 minecraft:light[level=14]
setblock 58 273 396 minecraft:light[level=14]
setblock 58 273 404 minecraft:light[level=14]
fill 58 273 411 58 283 411 minecraft:black_concrete
fill 62 273 369 62 283 369 minecraft:black_concrete
setblock 66 273 372 minecraft:light[level=14]
setblock 66 273 380 minecraft:light[level=14]
setblock 66 273 388 minecraft:light[level=14]
setblock 66 273 396 minecraft:light[level=14]
setblock 66 273 404 minecraft:light[level=14]
fill 66 273 411 66 283 411 minecraft:black_concrete
fill 70 273 369 70 283 369 minecraft:black_concrete
setblock 74 273 372 minecraft:light[level=14]
setblock 74 273 380 minecraft:light[level=14]
setblock 74 273 388 minecraft:light[level=14]
setblock 74 273 396 minecraft:light[level=14]
setblock 74 273 404 minecraft:light[level=14]
fill 74 273 411 74 283 411 minecraft:black_concrete
fill 78 273 369 78 283 369 minecraft:black_concrete
setblock 82 273 372 minecraft:light[level=14]
setblock 82 273 380 minecraft:light[level=14]
setblock 82 273 388 minecraft:light[level=14]
setblock 82 273 396 minecraft:light[level=14]
setblock 82 273 404 minecraft:light[level=14]
fill 82 273 411 82 283 411 minecraft:black_concrete
fill 86 273 369 86 283 369 minecraft:black_concrete
fill 89 273 374 89 283 374 minecraft:black_concrete
fill 89 273 382 89 283 382 minecraft:black_concrete
fill 89 273 390 89 283 390 minecraft:black_concrete
fill 89 273 398 89 283 398 minecraft:black_concrete
fill 89 273 406 89 283 406 minecraft:black_concrete
fill 55 278 392 63 278 392 minecraft:black_concrete
fill 56 278 388 64 278 391 minecraft:black_concrete
fill 56 278 393 64 278 396 minecraft:black_concrete
fill 57 278 386 77 278 387 minecraft:black_concrete
fill 57 278 397 77 278 398 minecraft:black_concrete
fill 58 278 385 76 278 385 minecraft:black_concrete
fill 58 278 399 76 278 399 minecraft:black_concrete
fill 59 278 384 75 278 384 minecraft:black_concrete
fill 59 278 400 75 278 400 minecraft:black_concrete
fill 60 278 383 74 278 383 minecraft:black_concrete
fill 60 278 401 74 278 401 minecraft:black_concrete
fill 61 278 382 73 278 382 minecraft:black_concrete
fill 61 278 402 73 278 402 minecraft:black_concrete
fill 63 278 381 71 278 381 minecraft:black_concrete
fill 63 278 403 71 278 403 minecraft:black_concrete
fill 65 278 388 66 278 389 minecraft:black_concrete
fill 65 278 395 66 278 396 minecraft:black_concrete
setblock 67 278 380 minecraft:black_concrete
fill 67 278 388 78 278 388 minecraft:black_concrete
fill 67 278 396 78 278 396 minecraft:black_concrete
setblock 67 278 404 minecraft:black_concrete
fill 68 278 389 78 278 389 minecraft:black_concrete
fill 68 278 395 78 278 395 minecraft:black_concrete
fill 70 278 390 78 278 391 minecraft:black_concrete
fill 70 278 393 78 278 394 minecraft:black_concrete
fill 71 278 392 79 278 392 minecraft:black_concrete
fill 48 279 370 54 279 410 minecraft:purple_concrete
fill 55 279 370 55 279 391 minecraft:purple_concrete
fill 55 279 392 56 279 392 minecraft:red_concrete
fill 55 279 393 55 279 410 minecraft:purple_concrete
fill 56 279 370 56 279 387 minecraft:purple_concrete
fill 56 279 388 56 279 391 minecraft:red_concrete
fill 56 279 393 56 279 396 minecraft:red_concrete
fill 56 279 397 56 279 410 minecraft:purple_concrete
fill 57 279 370 57 279 385 minecraft:purple_concrete
fill 57 279 386 57 279 387 minecraft:red_concrete
fill 57 279 388 61 279 396 minecraft:black_concrete
fill 57 279 397 57 279 398 minecraft:red_concrete
fill 57 279 399 57 279 410 minecraft:purple_concrete
fill 58 279 370 58 279 384 minecraft:purple_concrete
setblock 58 279 385 minecraft:red_concrete
fill 58 279 386 59 279 387 minecraft:black_concrete
fill 58 279 397 59 279 398 minecraft:black_concrete
setblock 58 279 399 minecraft:red_concrete
fill 58 279 400 58 279 410 minecraft:purple_concrete
fill 59 279 370 59 279 383 minecraft:purple_concrete
setblock 59 279 384 minecraft:red_concrete
fill 59 279 385 61 279 385 minecraft:gray_concrete
fill 59 279 399 61 279 399 minecraft:gray_concrete
setblock 59 279 400 minecraft:red_concrete
fill 59 279 401 59 279 410 minecraft:purple_concrete
fill 60 279 370 60 279 382 minecraft:purple_concrete
setblock 60 279 383 minecraft:red_concrete
setblock 60 279 384 minecraft:gray_concrete
fill 60 279 386 62 279 386 minecraft:gray_concrete
setblock 60 279 387 minecraft:black_concrete
setblock 60 279 397 minecraft:black_concrete
fill 60 279 398 62 279 398 minecraft:gray_concrete
setblock 60 279 400 minecraft:gray_concrete
setblock 60 279 401 minecraft:red_concrete
fill 60 279 402 60 279 410 minecraft:purple_concrete
fill 61 279 370 62 279 381 minecraft:purple_concrete
fill 61 279 382 62 279 382 minecraft:red_concrete
fill 61 279 383 73 279 384 minecraft:black_concrete
fill 61 279 387 63 279 387 minecraft:gray_concrete
fill 61 279 397 63 279 397 minecraft:gray_concrete
fill 61 279 400 73 279 401 minecraft:black_concrete
fill 61 279 402 62 279 402 minecraft:red_concrete
fill 61 279 403 62 279 410 minecraft:purple_concrete
fill 62 279 385 72 279 385 minecraft:black_concrete
fill 62 279 388 63 279 388 minecraft:gray_concrete
setblock 62 279 389 minecraft:black_concrete
fill 62 279 390 62 279 394 minecraft:white_concrete
setblock 62 279 395 minecraft:black_concrete
fill 62 279 396 63 279 396 minecraft:gray_concrete
fill 62 279 399 72 279 399 minecraft:black_concrete
fill 63 279 370 66 279 380 minecraft:purple_concrete
fill 63 279 381 71 279 381 minecraft:red_concrete
fill 63 279 382 71 279 382 minecraft:black_concrete
fill 63 279 386 71 279 386 minecraft:black_concrete
setblock 63 279 389 minecraft:white_concrete
setblock 63 279 390 minecraft:black_concrete
fill 63 279 391 63 279 393 minecraft:sea_lantern
setblock 63 279 394 minecraft:black_concrete
setblock 63 279 395 minecraft:white_concrete
fill 63 279 398 71 279 398 minecraft:black_concrete
fill 63 279 402 71 279 402 minecraft:black_concrete
fill 63 279 403 71 279 403 minecraft:red_concrete
fill 63 279 404 66 279 410 minecraft:purple_concrete
setblock 64 279 387 minecraft:black_concrete
setblock 64 279 388 minecraft:white_concrete
fill 64 279 389 64 279 391 minecraft:sea_lantern
fill 64 279 393 64 279 395 minecraft:sea_lantern
setblock 64 279 396 minecraft:white_concrete
setblock 64 279 397 minecraft:black_concrete
fill 65 279 387 69 279 387 minecraft:white_concrete
setblock 65 279 388 minecraft:black_concrete
fill 65 279 389 66 279 389 minecraft:sea_lantern
fill 65 279 395 66 279 395 minecraft:sea_lantern
setblock 65 279 396 minecraft:black_concrete
fill 65 279 397 69 279 397 minecraft:white_concrete
fill 66 279 388 68 279 388 minecraft:sea_lantern
fill 66 279 396 68 279 396 minecraft:sea_lantern
fill 67 279 370 88 279 379 minecraft:purple_concrete
setblock 67 279 380 minecraft:red_concrete
setblock 67 279 404 minecraft:red_concrete
fill 67 279 405 88 279 410 minecraft:purple_concrete
fill 68 279 380 88 279 380 minecraft:purple_concrete
fill 68 279 389 70 279 389 minecraft:sea_lantern
fill 68 279 395 70 279 395 minecraft:sea_lantern
fill 68 279 404 88 279 404 minecraft:purple_concrete
setblock 69 279 388 minecraft:black_concrete
setblock 69 279 396 minecraft:black_concrete
setblock 70 279 387 minecraft:black_concrete
setblock 70 279 388 minecraft:white_concrete
fill 70 279 390 70 279 391 minecraft:sea_lantern
fill 70 279 393 70 279 394 minecraft:sea_lantern
setblock 70 279 396 minecraft:white_concrete
setblock 70 279 397 minecraft:black_concrete
fill 71 279 387 72 279 388 minecraft:gray_concrete
setblock 71 279 389 minecraft:white_concrete
setblock 71 279 390 minecraft:black_concrete
fill 71 279 391 71 279 393 minecraft:sea_lantern
schedule function dropper:buildpart/85_2 1t
