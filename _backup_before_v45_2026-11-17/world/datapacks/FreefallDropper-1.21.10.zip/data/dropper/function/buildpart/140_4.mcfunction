fill 405 247 578 417 247 578 minecraft:black_concrete
fill 406 247 557 406 249 557 minecraft:black_concrete
fill 406 247 571 417 247 572 minecraft:black_concrete
fill 406 247 573 406 252 575 minecraft:red_nether_bricks
fill 406 247 576 417 247 577 minecraft:black_concrete
fill 407 247 573 417 249 575 minecraft:black_concrete
fill 413 247 557 414 247 557 minecraft:purple_concrete
fill 416 247 599 417 247 599 minecraft:purple_concrete
fill 418 247 564 418 247 565 minecraft:purple_concrete
fill 418 247 572 418 247 573 minecraft:purple_concrete
setblock 418 247 576 minecraft:purple_concrete
fill 418 247 577 418 249 577 minecraft:black_concrete
fill 418 247 584 418 247 585 minecraft:purple_concrete
setblock 418 247 593 minecraft:purple_concrete
fill 418 247 596 418 247 597 minecraft:purple_concrete
fill 376 248 562 376 249 562 minecraft:purple_concrete
fill 376 248 564 376 253 564 minecraft:black_concrete
fill 376 248 565 376 248 566 minecraft:purple_concrete
fill 376 248 567 376 253 567 minecraft:black_concrete
fill 376 248 573 376 249 574 minecraft:purple_concrete
fill 376 248 575 383 249 576 minecraft:black_concrete
fill 376 248 585 376 248 586 minecraft:purple_concrete
fill 376 248 587 376 253 588 minecraft:black_concrete
fill 376 248 593 376 249 594 minecraft:purple_concrete
fill 376 248 595 376 253 596 minecraft:black_concrete
setblock 376 248 597 minecraft:purple_concrete
fill 376 248 598 376 250 599 minecraft:black_concrete
fill 377 248 571 383 248 574 minecraft:black_concrete
fill 377 248 577 383 248 585 minecraft:black_concrete
fill 378 248 569 383 248 570 minecraft:black_concrete
fill 378 248 586 383 248 587 minecraft:black_concrete
fill 379 248 567 390 248 568 minecraft:black_concrete
fill 379 248 588 415 248 589 minecraft:black_concrete
fill 380 248 566 414 248 566 minecraft:black_concrete
fill 380 248 590 414 248 590 minecraft:black_concrete
fill 381 248 557 382 253 557 minecraft:black_concrete
fill 381 248 565 413 249 565 minecraft:black_concrete
fill 381 248 591 413 249 591 minecraft:black_concrete
fill 382 248 563 412 248 563 minecraft:black_concrete
fill 382 248 593 412 248 593 minecraft:black_concrete
fill 382 248 599 383 249 599 minecraft:purple_concrete
fill 383 248 557 384 248 557 minecraft:purple_concrete
fill 383 248 562 411 248 562 minecraft:black_concrete
fill 383 248 594 411 248 594 minecraft:black_concrete
fill 384 248 599 385 253 599 minecraft:black_concrete
fill 385 248 561 409 248 561 minecraft:black_concrete
fill 385 248 595 409 248 595 minecraft:black_concrete
fill 386 248 560 408 248 560 minecraft:black_concrete
fill 386 248 596 408 248 596 minecraft:black_concrete
fill 387 248 569 389 251 569 minecraft:black_concrete
fill 387 248 579 388 248 587 minecraft:black_concrete
fill 388 248 559 406 248 559 minecraft:black_concrete
fill 388 248 597 406 248 597 minecraft:black_concrete
setblock 389 248 579 minecraft:purple_concrete
fill 389 248 580 389 248 587 minecraft:black_concrete
fill 390 248 558 404 248 558 minecraft:black_concrete
fill 390 248 569 390 252 569 minecraft:red_nether_bricks
fill 390 248 579 390 252 579 minecraft:red_nether_bricks
fill 390 248 580 390 248 581 minecraft:purple_concrete
fill 390 248 582 390 248 587 minecraft:black_concrete
fill 390 248 598 390 248 599 minecraft:black_concrete
fill 391 248 567 392 250 567 minecraft:black_concrete
fill 391 248 568 391 251 568 minecraft:red_nether_bricks
fill 391 248 580 391 251 580 minecraft:red_nether_bricks
fill 391 248 581 391 248 582 minecraft:purple_concrete
fill 391 248 583 391 248 587 minecraft:black_concrete
fill 391 248 598 404 248 598 minecraft:black_concrete
fill 391 248 599 391 249 599 minecraft:purple_concrete
fill 392 248 582 392 248 583 minecraft:purple_concrete
fill 392 248 584 393 248 587 minecraft:black_concrete
fill 393 248 557 394 253 557 minecraft:black_concrete
fill 393 248 567 393 251 567 minecraft:red_nether_bricks
fill 393 248 581 393 251 581 minecraft:red_nether_bricks
fill 393 248 583 394 248 583 minecraft:purple_concrete
fill 393 248 599 393 253 599 minecraft:black_concrete
fill 394 248 584 400 248 584 minecraft:purple_concrete
fill 394 248 585 416 248 587 minecraft:black_concrete
fill 394 248 599 395 248 599 minecraft:purple_concrete
fill 395 248 557 396 249 557 minecraft:purple_concrete
fill 395 248 570 395 250 570 minecraft:red_nether_bricks
fill 395 248 578 395 250 578 minecraft:red_nether_bricks
fill 396 248 599 397 250 599 minecraft:black_concrete
fill 400 248 583 402 248 583 minecraft:purple_concrete
fill 400 248 599 401 249 599 minecraft:black_concrete
fill 401 248 567 401 251 567 minecraft:red_nether_bricks
fill 401 248 581 401 251 581 minecraft:red_nether_bricks
fill 401 248 584 418 248 584 minecraft:black_concrete
fill 402 248 557 402 253 557 minecraft:black_concrete
fill 402 248 567 415 248 567 minecraft:black_concrete
fill 402 248 582 403 248 582 minecraft:purple_concrete
fill 402 248 599 403 249 599 minecraft:purple_concrete
fill 403 248 557 404 248 557 minecraft:purple_concrete
fill 403 248 568 403 251 568 minecraft:red_nether_bricks
fill 403 248 580 403 251 580 minecraft:red_nether_bricks
fill 403 248 581 404 248 581 minecraft:purple_concrete
fill 403 248 583 417 248 583 minecraft:black_concrete
fill 404 248 568 415 249 568 minecraft:black_concrete
fill 404 248 569 404 252 569 minecraft:red_nether_bricks
fill 404 248 579 404 252 579 minecraft:red_nether_bricks
setblock 404 248 580 minecraft:purple_concrete
fill 404 248 582 417 248 582 minecraft:black_concrete
fill 404 248 599 405 253 599 minecraft:black_concrete
fill 405 248 557 405 253 557 minecraft:black_concrete
fill 405 248 569 416 248 569 minecraft:black_concrete
fill 405 248 570 405 252 570 minecraft:red_nether_bricks
fill 405 248 578 405 252 578 minecraft:red_nether_bricks
setblock 405 248 579 minecraft:purple_concrete
fill 405 248 580 417 248 581 minecraft:black_concrete
fill 406 248 570 416 248 571 minecraft:black_concrete
fill 406 248 572 406 252 572 minecraft:red_nether_bricks
fill 406 248 576 406 252 576 minecraft:red_nether_bricks
fill 406 248 577 417 248 579 minecraft:black_concrete
fill 407 248 557 407 249 557 minecraft:purple_concrete
fill 407 248 572 418 248 572 minecraft:black_concrete
fill 407 248 576 418 249 576 minecraft:black_concrete
setblock 408 248 557 minecraft:black_concrete
fill 413 248 557 414 253 557 minecraft:black_concrete
fill 414 248 599 415 248 599 minecraft:purple_concrete
fill 415 248 557 416 249 557 minecraft:purple_concrete
fill 416 248 599 417 253 599 minecraft:black_concrete
setblock 417 248 571 minecraft:black_concrete
fill 417 248 585 418 248 585 minecraft:black_concrete
fill 418 248 562 418 251 562 minecraft:black_concrete
setblock 418 248 563 minecraft:purple_concrete
fill 418 248 564 418 253 565 minecraft:black_concrete
fill 418 248 566 418 249 567 minecraft:purple_concrete
fill 418 248 573 418 253 573 minecraft:black_concrete
fill 418 248 574 418 248 575 minecraft:purple_concrete
fill 418 248 586 418 249 587 minecraft:purple_concrete
fill 418 248 593 418 251 594 minecraft:black_concrete
setblock 418 248 595 minecraft:purple_concrete
fill 418 248 596 418 253 597 minecraft:black_concrete
fill 418 248 598 418 249 598 minecraft:purple_concrete
setblock 376 249 561 minecraft:purple_concrete
fill 376 249 565 376 252 566 minecraft:black_concrete
setblock 376 249 582 minecraft:purple_concrete
setblock 376 249 585 minecraft:purple_concrete
fill 376 249 586 376 252 586 minecraft:black_concrete
fill 376 249 597 376 252 597 minecraft:black_concrete
fill 377 249 573 383 249 574 minecraft:black_concrete
fill 377 249 577 383 249 583 minecraft:black_concrete
fill 378 249 570 383 249 572 minecraft:black_concrete
fill 378 249 584 383 249 586 minecraft:black_concrete
fill 378 249 599 378 251 599 minecraft:black_concrete
fill 379 249 568 383 249 569 minecraft:black_concrete
fill 379 249 587 383 249 588 minecraft:black_concrete
setblock 379 249 599 minecraft:purple_concrete
fill 380 249 567 390 249 567 minecraft:black_concrete
fill 380 249 589 414 249 589 minecraft:black_concrete
fill 381 249 566 413 249 566 minecraft:black_concrete
fill 381 249 590 413 249 590 minecraft:black_concrete
fill 382 249 564 412 249 564 minecraft:black_concrete
fill 382 249 592 412 249 592 minecraft:black_concrete
fill 383 249 557 383 252 557 minecraft:black_concrete
fill 383 249 563 411 249 563 minecraft:black_concrete
fill 383 249 593 411 249 593 minecraft:black_concrete
setblock 384 249 557 minecraft:purple_concrete
fill 384 249 562 410 249 562 minecraft:black_concrete
fill 384 249 568 390 251 568 minecraft:black_concrete
fill 384 249 588 415 249 588 minecraft:black_concrete
fill 384 249 594 410 249 594 minecraft:black_concrete
fill 385 249 572 385 252 572 minecraft:black_concrete
fill 385 249 573 385 250 573 minecraft:nether_bricks
fill 385 249 575 385 250 575 minecraft:nether_bricks
fill 385 249 576 385 251 576 minecraft:black_concrete
fill 386 249 561 408 249 561 minecraft:black_concrete
fill 386 249 595 408 249 595 minecraft:black_concrete
setblock 387 249 557 minecraft:purple_concrete
fill 387 249 560 407 249 560 minecraft:black_concrete
fill 387 249 579 387 249 587 minecraft:black_concrete
fill 387 249 596 407 249 596 minecraft:black_concrete
setblock 388 249 579 minecraft:crying_obsidian
fill 388 249 580 388 249 587 minecraft:black_concrete
fill 389 249 559 405 249 559 minecraft:black_concrete
fill 389 249 580 389 249 581 minecraft:crying_obsidian
fill 389 249 582 389 249 587 minecraft:black_concrete
fill 389 249 597 405 249 597 minecraft:black_concrete
fill 390 249 582 390 249 583 minecraft:crying_obsidian
fill 390 249 584 390 249 587 minecraft:black_concrete
setblock 390 249 599 minecraft:purple_concrete
fill 391 249 583 391 249 584 minecraft:crying_obsidian
fill 391 249 585 392 249 587 minecraft:black_concrete
fill 392 249 558 402 249 558 minecraft:black_concrete
fill 392 249 584 393 249 584 minecraft:crying_obsidian
fill 392 249 598 402 249 598 minecraft:black_concrete
setblock 393 249 573 minecraft:nether_bricks
setblock 393 249 575 minecraft:nether_bricks
fill 393 249 585 401 249 585 minecraft:crying_obsidian
fill 393 249 586 394 249 587 minecraft:black_concrete
setblock 394 249 599 minecraft:purple_concrete
fill 395 249 586 399 249 586 minecraft:crying_obsidian
fill 395 249 587 415 249 587 minecraft:black_concrete
fill 395 249 599 395 252 599 minecraft:black_concrete
fill 400 249 586 416 249 586 minecraft:black_concrete
fill 401 249 584 403 249 584 minecraft:crying_obsidian
fill 402 249 567 414 249 567 minecraft:black_concrete
fill 402 249 585 416 249 585 minecraft:black_concrete
fill 403 249 557 404 252 557 minecraft:black_concrete
fill 403 249 583 404 249 583 minecraft:crying_obsidian
setblock 404 249 582 minecraft:crying_obsidian
fill 404 249 584 416 249 584 minecraft:black_concrete
fill 405 249 569 415 249 569 minecraft:black_concrete
fill 405 249 580 405 249 581 minecraft:crying_obsidian
fill 405 249 582 417 249 583 minecraft:black_concrete
fill 406 249 570 416 249 570 minecraft:black_concrete
fill 406 249 571 406 251 571 minecraft:red_nether_bricks
fill 406 249 577 406 251 577 minecraft:red_nether_bricks
fill 406 249 578 406 249 579 minecraft:crying_obsidian
fill 406 249 580 417 249 581 minecraft:black_concrete
fill 407 249 571 416 249 572 minecraft:black_concrete
fill 407 249 577 417 249 579 minecraft:black_concrete
setblock 408 249 557 minecraft:purple_concrete
setblock 411 249 599 minecraft:purple_concrete
setblock 414 249 599 minecraft:purple_concrete
fill 415 249 599 415 252 599 minecraft:black_concrete
setblock 418 249 558 minecraft:purple_concrete
fill 418 249 563 418 252 563 minecraft:black_concrete
fill 418 249 572 418 253 572 minecraft:black_concrete
fill 418 249 574 418 252 574 minecraft:black_concrete
setblock 418 249 575 minecraft:purple_concrete
fill 418 249 578 418 249 579 minecraft:purple_concrete
fill 418 249 584 418 253 585 minecraft:black_concrete
fill 418 249 595 418 252 595 minecraft:black_concrete
fill 376 250 559 376 251 560 minecraft:purple_concrete
fill 376 250 561 376 255 562 minecraft:black_concrete
setblock 376 250 563 minecraft:purple_concrete
fill 376 250 571 376 251 572 minecraft:purple_concrete
fill 376 250 573 376 253 576 minecraft:black_concrete
setblock 376 250 579 minecraft:black_concrete
fill 376 250 580 376 251 580 minecraft:purple_concrete
fill 376 250 582 376 255 582 minecraft:black_concrete
fill 376 250 583 376 250 584 minecraft:purple_concrete
fill 376 250 585 376 255 585 minecraft:black_concrete
fill 376 250 591 376 251 592 minecraft:purple_concrete
fill 376 250 593 376 255 594 minecraft:black_concrete
fill 377 250 557 378 251 557 minecraft:purple_concrete
fill 378 250 573 383 250 583 minecraft:black_concrete
fill 379 250 570 383 250 572 minecraft:black_concrete
fill 379 250 584 383 250 586 minecraft:black_concrete
fill 379 250 599 379 251 599 minecraft:black_concrete
fill 380 250 568 383 250 569 minecraft:black_concrete
fill 380 250 587 383 250 588 minecraft:black_concrete
fill 380 250 599 381 250 599 minecraft:purple_concrete
fill 381 250 567 390 250 567 minecraft:black_concrete
fill 381 250 589 413 250 589 minecraft:black_concrete
fill 382 250 565 412 250 566 minecraft:black_concrete
fill 382 250 590 412 250 591 minecraft:black_concrete
fill 382 250 599 383 255 599 minecraft:black_concrete
fill 383 250 564 411 250 564 minecraft:black_concrete
fill 383 250 592 411 250 592 minecraft:black_concrete
fill 384 250 557 384 255 557 minecraft:black_concrete
fill 384 250 563 410 250 563 minecraft:black_concrete
fill 384 250 572 384 253 572 minecraft:black_concrete
setblock 384 250 573 minecraft:nether_bricks
setblock 384 250 575 minecraft:nether_bricks
fill 384 250 576 384 252 576 minecraft:black_concrete
fill 384 250 588 414 250 588 minecraft:black_concrete
fill 384 250 593 410 250 593 minecraft:black_concrete
fill 385 250 557 386 250 557 minecraft:purple_concrete
fill 385 250 571 385 253 571 minecraft:black_concrete
fill 385 250 577 385 251 577 minecraft:black_concrete
fill 386 250 562 408 250 562 minecraft:black_concrete
fill 386 250 594 408 250 594 minecraft:black_concrete
fill 387 250 557 387 255 557 minecraft:black_concrete
fill 387 250 561 407 250 561 minecraft:black_concrete
fill 387 250 570 388 251 570 minecraft:black_concrete
fill 387 250 578 387 250 580 minecraft:purple_concrete
fill 387 250 581 387 250 587 minecraft:black_concrete
fill 387 250 595 407 250 595 minecraft:black_concrete
fill 388 250 580 388 250 582 minecraft:purple_concrete
fill 388 250 583 388 250 587 minecraft:black_concrete
fill 388 250 599 389 251 599 minecraft:purple_concrete
fill 389 250 557 389 251 557 minecraft:purple_concrete
fill 389 250 560 405 250 560 minecraft:black_concrete
fill 389 250 570 391 252 570 minecraft:red_nether_bricks
fill 389 250 578 391 252 578 minecraft:red_nether_bricks
fill 389 250 582 389 250 583 minecraft:purple_concrete
fill 389 250 584 389 250 587 minecraft:black_concrete
fill 389 250 596 405 250 596 minecraft:black_concrete
setblock 390 250 557 minecraft:black_concrete
setblock 390 250 584 minecraft:purple_concrete
fill 390 250 585 390 250 587 minecraft:black_concrete
fill 390 250 599 391 255 599 minecraft:black_concrete
fill 391 250 585 392 250 585 minecraft:purple_concrete
fill 391 250 586 391 250 587 minecraft:black_concrete
fill 392 250 559 402 250 559 minecraft:black_concrete
fill 392 250 586 394 250 586 minecraft:purple_concrete
fill 392 250 587 393 250 587 minecraft:black_concrete
fill 392 250 597 402 250 597 minecraft:black_concrete
setblock 392 250 599 minecraft:purple_concrete
fill 393 250 571 393 252 571 minecraft:red_nether_bricks
fill 393 250 577 393 252 577 minecraft:red_nether_bricks
fill 394 250 587 400 250 587 minecraft:purple_concrete
fill 394 250 599 394 252 599 minecraft:black_concrete
fill 395 250 557 396 255 557 minecraft:black_concrete
fill 397 250 557 398 251 557 minecraft:purple_concrete
fill 400 250 586 402 250 586 minecraft:purple_concrete
fill 400 250 599 401 251 599 minecraft:purple_concrete
fill 401 250 571 401 252 571 minecraft:red_nether_bricks
fill 401 250 577 401 252 577 minecraft:red_nether_bricks
fill 401 250 587 414 250 587 minecraft:black_concrete
fill 402 250 567 413 250 567 minecraft:black_concrete
fill 402 250 573 404 252 573 minecraft:red_nether_bricks
fill 402 250 575 404 252 575 minecraft:red_nether_bricks
fill 402 250 585 403 250 585 minecraft:purple_concrete
fill 402 250 599 403 255 599 minecraft:black_concrete
fill 403 250 586 415 250 586 minecraft:black_concrete
fill 404 250 568 414 250 568 minecraft:black_concrete
setblock 404 250 584 minecraft:purple_concrete
fill 404 250 585 415 250 585 minecraft:black_concrete
fill 405 250 569 414 250 569 minecraft:black_concrete
fill 405 250 582 405 250 583 minecraft:purple_concrete
fill 405 250 584 415 250 584 minecraft:black_concrete
setblock 406 250 557 minecraft:purple_concrete
fill 406 250 570 415 250 570 minecraft:black_concrete
fill 406 250 580 406 250 582 minecraft:purple_concrete
fill 406 250 583 416 250 583 minecraft:black_concrete
fill 407 250 557 408 255 557 minecraft:black_concrete
fill 407 250 571 415 250 573 minecraft:black_concrete
fill 407 250 574 407 250 580 minecraft:purple_concrete
fill 407 250 581 416 250 582 minecraft:black_concrete
fill 408 250 574 416 250 580 minecraft:black_concrete
setblock 408 250 599 minecraft:black_concrete
fill 409 250 557 410 251 557 minecraft:purple_concrete
fill 409 250 599 409 251 599 minecraft:purple_concrete
fill 411 250 599 411 255 599 minecraft:black_concrete
fill 412 250 599 413 250 599 minecraft:purple_concrete
fill 414 250 599 414 255 599 minecraft:black_concrete
fill 415 250 557 416 255 557 minecraft:black_concrete
setblock 416 250 573 minecraft:black_concrete
fill 417 250 557 418 250 557 minecraft:purple_concrete
fill 418 250 558 418 255 558 minecraft:black_concrete
fill 418 250 566 418 255 567 minecraft:black_concrete
fill 418 250 568 418 251 569 minecraft:purple_concrete
fill 418 250 575 418 253 576 minecraft:black_concrete
setblock 418 250 577 minecraft:purple_concrete
fill 418 250 578 418 255 579 minecraft:black_concrete
fill 418 250 580 418 251 580 minecraft:purple_concrete
setblock 418 250 581 minecraft:black_concrete
fill 418 250 586 418 255 587 minecraft:black_concrete
fill 418 250 588 418 250 589 minecraft:purple_concrete
fill 418 250 598 418 255 598 minecraft:black_concrete
fill 376 251 563 376 254 563 minecraft:black_concrete
setblock 376 251 568 minecraft:purple_concrete
setblock 376 251 579 minecraft:purple_concrete
fill 376 251 583 376 253 584 minecraft:black_concrete
setblock 376 251 598 minecraft:black_concrete
fill 376 251 599 377 251 599 minecraft:purple_concrete
fill 379 251 573 383 251 583 minecraft:black_concrete
fill 380 251 570 383 251 572 minecraft:black_concrete
fill 380 251 584 383 251 586 minecraft:black_concrete
setblock 380 251 599 minecraft:purple_concrete
fill 381 251 568 383 251 569 minecraft:black_concrete
fill 381 251 587 383 251 588 minecraft:black_concrete
fill 381 251 599 381 254 599 minecraft:black_concrete
fill 382 251 567 391 251 567 minecraft:black_concrete
fill 382 251 589 412 251 589 minecraft:black_concrete
fill 383 251 566 393 251 566 minecraft:black_concrete
fill 383 251 590 411 251 590 minecraft:black_concrete
fill 384 251 565 410 251 565 minecraft:black_concrete
fill 384 251 573 384 252 575 minecraft:black_concrete
fill 384 251 588 392 251 588 minecraft:black_concrete
fill 384 251 591 410 251 591 minecraft:black_concrete
fill 385 251 557 386 254 557 minecraft:black_concrete
fill 385 251 564 409 251 564 minecraft:black_concrete
fill 385 251 573 385 252 573 minecraft:black_concrete
setblock 385 251 574 minecraft:nether_bricks
setblock 385 251 575 minecraft:black_concrete
fill 385 251 578 385 251 587 minecraft:black_concrete
fill 385 251 592 409 251 592 minecraft:black_concrete
fill 386 251 563 408 251 563 minecraft:black_concrete
fill 386 251 571 387 251 571 minecraft:black_concrete
setblock 386 251 572 minecraft:nether_bricks
setblock 386 251 576 minecraft:nether_bricks
fill 386 251 577 386 251 580 minecraft:purple_concrete
fill 386 251 581 386 251 587 minecraft:black_concrete
fill 386 251 593 408 251 593 minecraft:black_concrete
fill 387 251 562 407 251 562 minecraft:black_concrete
fill 387 251 581 387 251 583 minecraft:purple_concrete
fill 387 251 584 387 251 587 minecraft:black_concrete
fill 387 251 594 407 251 594 minecraft:black_concrete
fill 388 251 571 390 251 571 minecraft:nether_bricks
fill 388 251 577 390 251 577 minecraft:nether_bricks
fill 388 251 583 388 251 584 minecraft:purple_concrete
fill 388 251 585 388 251 587 minecraft:black_concrete
fill 389 251 561 405 251 561 minecraft:black_concrete
fill 389 251 584 389 251 585 minecraft:purple_concrete
fill 389 251 586 389 251 587 minecraft:black_concrete
fill 389 251 595 405 251 595 minecraft:black_concrete
setblock 390 251 557 minecraft:purple_concrete
fill 390 251 580 390 252 580 minecraft:white_concrete
fill 390 251 585 390 251 586 minecraft:purple_concrete
setblock 390 251 587 minecraft:black_concrete
fill 391 251 571 392 254 571 minecraft:red_nether_bricks
fill 391 251 577 392 254 577 minecraft:red_nether_bricks
fill 391 251 582 391 252 583 minecraft:white_concrete
fill 391 251 586 391 251 587 minecraft:purple_concrete
fill 392 251 560 402 251 560 minecraft:black_concrete
setblock 392 251 567 minecraft:purple_concrete
setblock 392 251 572 minecraft:nether_bricks
setblock 392 251 576 minecraft:nether_bricks
setblock 392 251 582 minecraft:white_concrete
fill 392 251 584 393 252 584 minecraft:white_concrete
fill 392 251 587 393 251 587 minecraft:purple_concrete
fill 392 251 596 402 251 596 minecraft:black_concrete
fill 392 251 599 392 254 599 minecraft:black_concrete
setblock 393 251 583 minecraft:white_concrete
fill 393 251 588 401 251 588 minecraft:purple_concrete
fill 394 251 566 400 251 566 minecraft:purple_concrete
fill 395 251 584 395 251 585 minecraft:white_concrete
fill 396 251 599 396 253 599 minecraft:black_concrete
fill 397 251 585 397 251 586 minecraft:white_concrete
setblock 397 251 599 minecraft:purple_concrete
fill 399 251 584 399 251 585 minecraft:white_concrete
setblock 401 251 557 minecraft:purple_concrete
fill 401 251 566 411 251 566 minecraft:black_concrete
fill 401 251 583 401 251 584 minecraft:white_concrete
fill 401 251 587 403 251 587 minecraft:purple_concrete
setblock 402 251 567 minecraft:purple_concrete
fill 402 251 582 403 251 582 minecraft:white_concrete
fill 402 251 584 402 252 584 minecraft:white_concrete
fill 402 251 588 413 251 588 minecraft:black_concrete
fill 403 251 567 412 251 567 minecraft:black_concrete
fill 403 251 583 403 252 583 minecraft:white_concrete
fill 403 251 586 404 251 586 minecraft:purple_concrete
fill 404 251 568 413 251 568 minecraft:black_concrete
fill 404 251 580 404 252 580 minecraft:white_concrete
fill 404 251 585 405 251 585 minecraft:purple_concrete
fill 404 251 587 413 251 587 minecraft:black_concrete
fill 405 251 569 413 251 569 minecraft:black_concrete
fill 405 251 584 406 251 584 minecraft:purple_concrete
fill 405 251 586 414 251 586 minecraft:black_concrete
fill 406 251 557 406 254 557 minecraft:black_concrete
fill 406 251 570 414 251 570 minecraft:black_concrete
fill 406 251 583 407 251 583 minecraft:purple_concrete
fill 406 251 585 414 251 585 minecraft:black_concrete
fill 407 251 571 414 251 571 minecraft:black_concrete
fill 407 251 572 407 251 573 minecraft:purple_concrete
fill 407 251 581 407 251 582 minecraft:purple_concrete
fill 407 251 584 414 251 584 minecraft:black_concrete
fill 408 251 572 414 251 573 minecraft:black_concrete
fill 408 251 574 408 251 580 minecraft:purple_concrete
fill 408 251 581 415 251 583 minecraft:black_concrete
setblock 408 251 599 minecraft:purple_concrete
fill 409 251 574 415 251 580 minecraft:black_concrete
fill 412 251 599 413 254 599 minecraft:black_concrete
setblock 415 251 573 minecraft:black_concrete
fill 417 251 557 417 254 557 minecraft:black_concrete
setblock 418 251 557 minecraft:purple_concrete
fill 418 251 560 418 251 561 minecraft:purple_concrete
fill 418 251 577 418 254 577 minecraft:black_concrete
setblock 418 251 581 minecraft:purple_concrete
fill 418 251 588 418 254 588 minecraft:black_concrete
setblock 418 251 589 minecraft:purple_concrete
setblock 418 251 592 minecraft:purple_concrete
fill 376 252 557 376 253 558 minecraft:purple_concrete
fill 376 252 559 376 257 560 minecraft:black_concrete
fill 376 252 568 376 257 568 minecraft:black_concrete
fill 376 252 569 376 252 570 minecraft:purple_concrete
fill 376 252 571 376 257 572 minecraft:black_concrete
fill 376 252 577 376 253 578 minecraft:purple_concrete
fill 376 252 579 376 257 580 minecraft:black_concrete
setblock 376 252 581 minecraft:purple_concrete
fill 376 252 589 376 253 590 minecraft:purple_concrete
fill 376 252 591 376 257 592 minecraft:black_concrete
fill 376 252 598 376 253 598 minecraft:purple_concrete
fill 376 252 599 377 253 599 minecraft:black_concrete
fill 377 252 557 378 257 557 minecraft:black_concrete
fill 377 252 558 379 252 558 minecraft:obsidian
fill 377 252 560 377 252 562 minecraft:obsidian
fill 377 252 564 377 252 566 minecraft:obsidian
fill 377 252 568 377 252 570 minecraft:obsidian
fill 377 252 572 377 252 574 minecraft:obsidian
fill 377 252 576 377 252 578 minecraft:obsidian
fill 377 252 580 377 252 582 minecraft:obsidian
fill 377 252 584 377 252 586 minecraft:obsidian
fill 377 252 588 377 252 590 minecraft:obsidian
fill 377 252 592 377 252 594 minecraft:obsidian
fill 377 252 596 377 252 598 minecraft:obsidian
fill 378 252 599 379 252 599 minecraft:purple_concrete
fill 379 252 557 380 253 557 minecraft:purple_concrete
setblock 379 252 560 minecraft:light[level=12]
setblock 379 252 568 minecraft:light[level=12]
setblock 379 252 576 minecraft:light[level=12]
setblock 379 252 584 minecraft:light[level=12]
setblock 379 252 592 minecraft:light[level=12]
fill 379 252 598 381 252 598 minecraft:obsidian
fill 380 252 573 383 252 583 minecraft:black_concrete
fill 380 252 599 380 257 599 minecraft:black_concrete
fill 381 252 558 383 252 558 minecraft:obsidian
fill 381 252 571 383 252 572 minecraft:black_concrete
fill 381 252 584 383 252 585 minecraft:black_concrete
fill 382 252 569 383 252 570 minecraft:black_concrete
fill 382 252 586 383 252 587 minecraft:black_concrete
fill 383 252 567 389 252 568 minecraft:black_concrete
fill 383 252 588 389 252 589 minecraft:black_concrete
fill 383 252 598 385 252 598 minecraft:obsidian
fill 384 252 566 392 252 566 minecraft:black_concrete
fill 384 252 590 394 252 590 minecraft:black_concrete
fill 385 252 558 387 252 558 minecraft:obsidian
fill 385 252 565 395 252 565 minecraft:black_concrete
setblock 385 252 574 minecraft:black_concrete
fill 385 252 575 385 252 581 minecraft:crying_obsidian
fill 385 252 582 385 252 587 minecraft:black_concrete
fill 385 252 591 409 252 591 minecraft:black_concrete
fill 386 252 564 408 252 564 minecraft:black_concrete
setblock 386 252 571 minecraft:black_concrete
fill 386 252 572 386 252 574 minecraft:crying_obsidian
fill 386 252 581 386 252 583 minecraft:crying_obsidian
fill 386 252 584 386 252 587 minecraft:black_concrete
fill 386 252 592 408 252 592 minecraft:black_concrete
fill 386 252 599 387 253 599 minecraft:purple_concrete
setblock 387 252 560 minecraft:light[level=12]
fill 387 252 569 387 252 570 minecraft:black_concrete
setblock 387 252 571 minecraft:crying_obsidian
fill 387 252 575 387 253 575 minecraft:white_concrete
setblock 387 252 576 minecraft:light[level=12]
fill 387 252 578 388 253 578 minecraft:white_concrete
fill 387 252 581 389 252 581 minecraft:white_concrete
fill 387 252 584 387 252 585 minecraft:crying_obsidian
fill 387 252 586 387 252 587 minecraft:black_concrete
fill 387 252 598 389 252 598 minecraft:obsidian
setblock 388 252 557 minecraft:purple_concrete
fill 388 252 563 406 252 563 minecraft:black_concrete
setblock 388 252 569 minecraft:black_concrete
setblock 388 252 570 minecraft:crying_obsidian
fill 388 252 572 392 252 573 minecraft:red_nether_bricks
fill 388 252 574 390 252 574 minecraft:nether_bricks
fill 388 252 575 392 252 576 minecraft:red_nether_bricks
fill 388 252 585 388 252 586 minecraft:crying_obsidian
setblock 388 252 587 minecraft:black_concrete
fill 388 252 593 406 252 593 minecraft:black_concrete
fill 388 252 599 389 257 599 minecraft:black_concrete
fill 389 252 557 390 257 557 minecraft:black_concrete
fill 389 252 558 391 252 558 minecraft:obsidian
setblock 389 252 569 minecraft:crying_obsidian
fill 389 252 571 390 253 571 minecraft:red_nether_bricks
fill 389 252 577 390 253 577 minecraft:red_nether_bricks
setblock 389 252 580 minecraft:white_concrete
fill 389 252 583 390 252 584 minecraft:white_concrete
fill 389 252 586 389 252 587 minecraft:crying_obsidian
fill 390 252 562 404 252 562 minecraft:black_concrete
setblock 390 252 567 minecraft:black_concrete
setblock 390 252 568 minecraft:crying_obsidian
fill 390 252 587 390 252 588 minecraft:crying_obsidian
fill 390 252 589 391 252 589 minecraft:black_concrete
fill 390 252 594 404 252 594 minecraft:black_concrete
fill 391 252 557 392 253 557 minecraft:purple_concrete
fill 391 252 567 392 252 567 minecraft:crying_obsidian
fill 391 252 574 392 252 574 minecraft:red_nether_bricks
fill 391 252 585 392 252 586 minecraft:white_concrete
fill 391 252 588 392 252 588 minecraft:crying_obsidian
fill 391 252 595 402 252 595 minecraft:black_concrete
fill 391 252 598 393 252 598 minecraft:obsidian
fill 392 252 561 402 252 561 minecraft:black_concrete
fill 392 252 589 402 252 589 minecraft:crying_obsidian
fill 393 252 558 395 252 558 minecraft:obsidian
fill 393 252 566 395 252 566 minecraft:crying_obsidian
fill 394 252 567 398 252 567 minecraft:red_nether_bricks
fill 394 252 581 398 252 581 minecraft:red_nether_bricks
fill 394 252 586 394 252 588 minecraft:white_concrete
setblock 395 252 560 minecraft:light[level=12]
setblock 395 252 584 minecraft:light[level=12]
fill 395 252 585 395 252 586 minecraft:white_concrete
fill 395 252 590 399 252 590 minecraft:crying_obsidian
fill 395 252 598 397 252 598 minecraft:obsidian
fill 396 252 565 398 252 565 minecraft:crying_obsidian
fill 397 252 557 398 257 557 minecraft:black_concrete
fill 397 252 558 399 252 558 minecraft:obsidian
fill 397 252 586 397 252 588 minecraft:white_concrete
fill 397 252 599 397 257 599 minecraft:black_concrete
fill 398 252 599 399 252 599 minecraft:purple_concrete
fill 399 252 557 400 252 557 minecraft:purple_concrete
fill 399 252 565 409 252 565 minecraft:black_concrete
fill 399 252 566 401 252 566 minecraft:crying_obsidian
setblock 399 252 567 minecraft:black_concrete
setblock 399 252 581 minecraft:black_concrete
fill 399 252 585 399 252 586 minecraft:white_concrete
fill 399 252 598 401 252 598 minecraft:obsidian
setblock 400 252 567 minecraft:red_nether_bricks
setblock 400 252 581 minecraft:red_nether_bricks
fill 400 252 586 400 252 588 minecraft:white_concrete
fill 400 252 590 410 252 590 minecraft:black_concrete
fill 400 252 599 401 257 599 minecraft:black_concrete
fill 401 252 557 401 257 557 minecraft:black_concrete
fill 401 252 558 403 252 558 minecraft:obsidian
setblock 401 252 584 minecraft:white_concrete
fill 402 252 566 410 252 566 minecraft:black_concrete
fill 402 252 567 403 252 567 minecraft:crying_obsidian
fill 402 252 585 403 252 586 minecraft:white_concrete
fill 402 252 588 404 252 588 minecraft:crying_obsidian
setblock 403 252 560 minecraft:light[level=12]
setblock 403 252 568 minecraft:light[level=12]
setblock 403 252 582 minecraft:white_concrete
setblock 403 252 584 minecraft:light[level=12]
fill 403 252 589 411 252 589 minecraft:black_concrete
fill 403 252 598 405 252 598 minecraft:obsidian
fill 404 252 567 411 252 567 minecraft:black_concrete
setblock 404 252 568 minecraft:crying_obsidian
fill 404 252 583 405 252 584 minecraft:white_concrete
fill 404 252 587 405 252 587 minecraft:crying_obsidian
fill 405 252 558 407 252 558 minecraft:obsidian
fill 405 252 568 411 252 568 minecraft:black_concrete
setblock 405 252 569 minecraft:crying_obsidian
fill 405 252 580 405 252 581 minecraft:white_concrete
fill 405 252 586 406 252 586 minecraft:crying_obsidian
fill 405 252 588 411 252 588 minecraft:black_concrete
fill 406 252 569 412 252 569 minecraft:black_concrete
setblock 406 252 570 minecraft:crying_obsidian
fill 406 252 578 407 253 578 minecraft:white_concrete
fill 406 252 581 407 253 581 minecraft:white_concrete
fill 406 252 585 407 252 585 minecraft:crying_obsidian
fill 406 252 587 412 252 587 minecraft:black_concrete
fill 406 252 599 407 253 599 minecraft:purple_concrete
fill 407 252 570 412 252 570 minecraft:black_concrete
setblock 407 252 571 minecraft:crying_obsidian
fill 407 252 575 407 253 575 minecraft:white_concrete
setblock 407 252 584 minecraft:crying_obsidian
fill 407 252 586 412 252 586 minecraft:black_concrete
fill 407 252 598 409 252 598 minecraft:obsidian
fill 408 252 571 413 252 571 minecraft:black_concrete
fill 408 252 572 408 252 574 minecraft:crying_obsidian
fill 408 252 581 408 252 583 minecraft:crying_obsidian
fill 408 252 584 413 252 585 minecraft:black_concrete
fill 408 252 599 409 257 599 minecraft:black_concrete
fill 409 252 557 410 257 557 minecraft:black_concrete
fill 409 252 558 411 252 558 minecraft:obsidian
fill 409 252 572 413 252 574 minecraft:black_concrete
fill 409 252 575 409 252 581 minecraft:crying_obsidian
fill 409 252 582 414 252 583 minecraft:black_concrete
fill 410 252 575 414 252 581 minecraft:black_concrete
setblock 410 252 599 minecraft:purple_concrete
fill 411 252 557 412 253 557 minecraft:purple_concrete
setblock 411 252 560 minecraft:light[level=12]
setblock 411 252 592 minecraft:light[level=12]
fill 411 252 598 413 252 598 minecraft:obsidian
fill 412 252 567 412 257 568 minecraft:obsidian
fill 413 252 558 415 252 558 minecraft:obsidian
fill 414 252 573 414 252 574 minecraft:black_concrete
fill 415 252 598 417 252 598 minecraft:obsidian
fill 417 252 558 417 252 560 minecraft:obsidian
fill 417 252 562 417 252 564 minecraft:obsidian
fill 417 252 566 417 252 568 minecraft:obsidian
fill 417 252 570 417 252 572 minecraft:obsidian
fill 417 252 574 417 252 576 minecraft:obsidian
fill 417 252 578 417 252 580 minecraft:obsidian
fill 417 252 582 417 252 584 minecraft:obsidian
fill 417 252 586 417 252 588 minecraft:obsidian
fill 417 252 590 417 252 592 minecraft:obsidian
fill 417 252 594 417 252 596 minecraft:obsidian
fill 418 252 557 418 257 557 minecraft:black_concrete
setblock 418 252 559 minecraft:purple_concrete
fill 418 252 560 418 257 561 minecraft:black_concrete
fill 418 252 562 418 253 562 minecraft:purple_concrete
fill 418 252 568 418 257 569 minecraft:black_concrete
fill 418 252 570 418 252 571 minecraft:purple_concrete
fill 418 252 580 418 257 581 minecraft:black_concrete
fill 418 252 582 418 253 583 minecraft:purple_concrete
fill 418 252 589 418 257 589 minecraft:black_concrete
fill 418 252 590 418 252 591 minecraft:purple_concrete
fill 418 252 592 418 253 593 minecraft:black_concrete
fill 418 252 594 418 253 594 minecraft:purple_concrete
fill 418 252 599 418 253 599 minecraft:purple_concrete
fill 376 253 565 376 253 566 minecraft:purple_concrete
setblock 376 253 569 minecraft:purple_concrete
fill 376 253 570 376 256 570 minecraft:black_concrete
fill 376 253 581 376 255 581 minecraft:black_concrete
setblock 376 253 586 minecraft:purple_concrete
setblock 376 253 597 minecraft:purple_concrete
fill 378 253 599 379 255 599 minecraft:black_concrete
fill 381 253 576 383 253 580 minecraft:black_concrete
fill 382 253 572 383 253 575 minecraft:black_concrete
fill 382 253 581 383 253 584 minecraft:black_concrete
setblock 383 253 557 minecraft:purple_concrete
fill 383 253 570 383 253 571 minecraft:black_concrete
fill 383 253 585 385 253 586 minecraft:black_concrete
fill 384 253 573 384 253 574 minecraft:black_concrete
fill 384 253 575 384 253 581 minecraft:purple_concrete
fill 384 253 582 384 253 584 minecraft:black_concrete
fill 384 253 587 387 253 587 minecraft:black_concrete
fill 385 253 568 388 253 568 minecraft:black_concrete
fill 385 253 572 385 253 573 minecraft:purple_concrete
fill 385 253 574 386 254 575 minecraft:white_concrete
fill 385 253 577 386 254 579 minecraft:white_concrete
fill 385 253 581 387 253 582 minecraft:white_concrete
setblock 385 253 583 minecraft:purple_concrete
setblock 385 253 584 minecraft:black_concrete
fill 385 253 588 388 253 588 minecraft:black_concrete
fill 386 253 567 389 253 567 minecraft:black_concrete
setblock 386 253 571 minecraft:purple_concrete
fill 386 253 584 386 253 585 minecraft:purple_concrete
setblock 386 253 586 minecraft:black_concrete
fill 386 253 589 389 253 589 minecraft:black_concrete
fill 387 253 566 390 253 566 minecraft:black_concrete
setblock 387 253 569 minecraft:black_concrete
fill 387 253 570 388 254 572 minecraft:white_concrete
fill 387 253 574 387 254 574 minecraft:white_concrete
setblock 387 253 577 minecraft:white_concrete
setblock 387 253 579 minecraft:white_concrete
fill 387 253 584 388 254 586 minecraft:white_concrete
fill 387 253 590 391 253 590 minecraft:black_concrete
fill 388 253 557 388 256 557 minecraft:black_concrete
fill 388 253 565 392 253 565 minecraft:black_concrete
setblock 388 253 569 minecraft:purple_concrete
setblock 388 253 575 minecraft:white_concrete
setblock 388 253 581 minecraft:white_concrete
setblock 388 253 587 minecraft:purple_concrete
fill 388 253 591 394 253 591 minecraft:black_concrete
fill 389 253 564 405 253 564 minecraft:black_concrete
fill 389 253 568 390 254 569 minecraft:white_concrete
fill 389 253 572 391 253 576 minecraft:red_nether_bricks
fill 389 253 583 389 253 585 minecraft:white_concrete
fill 389 253 587 391 254 588 minecraft:white_concrete
fill 389 253 592 405 253 592 minecraft:black_concrete
setblock 390 253 567 minecraft:purple_concrete
fill 390 253 570 393 253 570 minecraft:red_nether_bricks
fill 390 253 578 393 253 578 minecraft:red_nether_bricks
setblock 390 253 584 minecraft:white_concrete
fill 390 253 586 392 253 586 minecraft:white_concrete
fill 390 253 589 391 253 589 minecraft:purple_concrete
fill 390 253 593 403 253 593 minecraft:black_concrete
fill 391 253 563 403 253 563 minecraft:black_concrete
fill 391 253 566 392 253 566 minecraft:purple_concrete
fill 391 253 568 391 254 568 minecraft:white_concrete
setblock 391 253 585 minecraft:white_concrete
fill 391 253 594 394 253 594 minecraft:purple_concrete
setblock 392 253 572 minecraft:red_nether_bricks
setblock 392 253 576 minecraft:red_nether_bricks
setblock 392 253 590 minecraft:purple_concrete
fill 392 253 595 397 254 595 minecraft:purple_concrete
fill 393 253 565 401 253 565 minecraft:purple_concrete
fill 393 253 566 394 254 567 minecraft:white_concrete
setblock 393 253 569 minecraft:red_nether_bricks
setblock 393 253 579 minecraft:red_nether_bricks
fill 393 253 588 394 253 590 minecraft:white_concrete
fill 394 253 569 394 254 569 minecraft:shroomlight
fill 394 253 579 394 254 579 minecraft:shroomlight
setblock 394 253 587 minecraft:white_concrete
fill 394 253 599 395 253 599 minecraft:purple_concrete
fill 395 253 562 399 253 562 minecraft:black_concrete
setblock 395 253 569 minecraft:red_nether_bricks
setblock 395 253 579 minecraft:red_nether_bricks
fill 395 253 591 399 253 591 minecraft:purple_concrete
fill 395 253 594 399 253 594 minecraft:black_concrete
fill 396 253 566 398 254 566 minecraft:white_concrete
fill 396 253 567 398 253 567 minecraft:red_nether_bricks
fill 396 253 581 398 253 581 minecraft:red_nether_bricks
fill 396 253 588 398 253 590 minecraft:white_concrete
setblock 397 253 587 minecraft:white_concrete
setblock 398 253 599 minecraft:purple_concrete
fill 399 253 557 399 256 557 minecraft:black_concrete
fill 399 253 566 402 253 566 minecraft:black_concrete
fill 399 253 569 401 253 569 minecraft:red_nether_bricks
fill 399 253 579 401 253 579 minecraft:red_nether_bricks
fill 399 253 582 402 253 582 minecraft:black_concrete
fill 399 253 599 399 256 599 minecraft:black_concrete
setblock 400 253 557 minecraft:purple_concrete
fill 400 253 567 401 254 567 minecraft:white_concrete
fill 400 253 587 400 253 590 minecraft:white_concrete
fill 400 253 591 406 253 591 minecraft:black_concrete
fill 401 253 570 402 254 570 minecraft:red_nether_bricks
fill 401 253 578 402 254 578 minecraft:red_nether_bricks
fill 401 253 588 401 254 590 minecraft:white_concrete
fill 402 253 565 406 253 565 minecraft:black_concrete
fill 402 253 586 404 253 586 minecraft:white_concrete
setblock 402 253 590 minecraft:purple_concrete
fill 403 253 557 404 253 557 minecraft:purple_concrete
setblock 403 253 566 minecraft:purple_concrete
fill 403 253 568 405 254 568 minecraft:white_concrete
fill 403 253 573 404 254 573 minecraft:red_nether_bricks
fill 403 253 575 404 254 575 minecraft:red_nether_bricks
setblock 403 253 585 minecraft:white_concrete
fill 403 253 587 405 254 588 minecraft:white_concrete
fill 403 253 589 404 253 589 minecraft:purple_concrete
fill 403 253 590 407 253 590 minecraft:black_concrete
fill 404 253 566 407 253 566 minecraft:black_concrete
setblock 404 253 567 minecraft:purple_concrete
fill 404 253 569 405 254 569 minecraft:white_concrete
fill 404 253 584 407 253 584 minecraft:white_concrete
fill 405 253 567 408 253 567 minecraft:black_concrete
setblock 405 253 583 minecraft:white_concrete
fill 405 253 585 407 253 585 minecraft:white_concrete
fill 405 253 589 408 253 589 minecraft:black_concrete
fill 406 253 568 409 253 568 minecraft:black_concrete
setblock 406 253 569 minecraft:purple_concrete
fill 406 253 570 407 254 572 minecraft:white_concrete
setblock 406 253 575 minecraft:white_concrete
fill 406 253 586 407 254 586 minecraft:white_concrete
setblock 406 253 587 minecraft:purple_concrete
fill 406 253 588 409 253 588 minecraft:black_concrete
fill 407 253 569 410 253 569 minecraft:black_concrete
fill 407 253 574 409 254 574 minecraft:white_concrete
fill 407 253 577 409 253 577 minecraft:white_concrete
fill 407 253 579 409 253 579 minecraft:white_concrete
fill 407 253 582 409 254 582 minecraft:white_concrete
fill 407 253 587 410 253 587 minecraft:black_concrete
fill 408 253 566 411 257 566 minecraft:obsidian
fill 408 253 570 411 253 570 minecraft:black_concrete
setblock 408 253 571 minecraft:purple_concrete
fill 408 253 575 409 254 575 minecraft:white_concrete
fill 408 253 578 409 254 578 minecraft:white_concrete
fill 408 253 581 409 254 581 minecraft:white_concrete
fill 408 253 584 408 253 585 minecraft:purple_concrete
fill 408 253 586 411 253 586 minecraft:black_concrete
fill 409 253 567 411 257 567 minecraft:obsidian
fill 409 253 571 411 253 571 minecraft:black_concrete
fill 409 253 572 409 253 573 minecraft:purple_concrete
setblock 409 253 583 minecraft:purple_concrete
fill 409 253 584 411 253 585 minecraft:black_concrete
fill 410 253 568 411 257 568 minecraft:obsidian
fill 410 253 572 412 253 574 minecraft:black_concrete
fill 410 253 575 410 253 581 minecraft:purple_concrete
fill 410 253 582 412 253 583 minecraft:black_concrete
fill 410 253 599 410 256 599 minecraft:black_concrete
fill 411 253 569 413 257 569 minecraft:obsidian
fill 411 253 575 412 253 581 minecraft:black_concrete
fill 412 253 570 412 257 571 minecraft:obsidian
setblock 412 253 584 minecraft:black_concrete
fill 413 253 568 413 257 568 minecraft:obsidian
fill 413 253 576 413 253 580 minecraft:black_concrete
setblock 415 253 599 minecraft:purple_concrete
fill 418 253 559 418 256 559 minecraft:black_concrete
setblock 418 253 563 minecraft:purple_concrete
fill 418 253 570 418 256 570 minecraft:black_concrete
setblock 418 253 571 minecraft:purple_concrete
setblock 418 253 574 minecraft:purple_concrete
fill 418 253 590 418 256 591 minecraft:black_concrete
setblock 418 253 595 minecraft:purple_concrete
fill 376 254 557 376 259 558 minecraft:black_concrete
fill 376 254 564 376 255 564 minecraft:purple_concrete
fill 376 254 565 376 259 566 minecraft:black_concrete
setblock 376 254 567 minecraft:purple_concrete
fill 376 254 569 376 259 569 minecraft:black_concrete
fill 376 254 573 376 255 574 minecraft:black_concrete
fill 376 254 575 376 255 576 minecraft:purple_concrete
fill 376 254 577 376 259 578 minecraft:black_concrete
setblock 376 254 583 minecraft:black_concrete
fill 376 254 584 376 255 584 minecraft:purple_concrete
fill 376 254 586 376 259 586 minecraft:black_concrete
fill 376 254 587 376 254 588 minecraft:purple_concrete
fill 376 254 589 376 256 590 minecraft:black_concrete
fill 376 254 595 376 255 596 minecraft:purple_concrete
fill 376 254 597 376 259 598 minecraft:black_concrete
setblock 376 254 599 minecraft:purple_concrete
fill 377 254 599 377 257 599 minecraft:black_concrete
fill 379 254 557 380 259 557 minecraft:black_concrete
fill 381 254 557 382 254 557 minecraft:purple_concrete
fill 383 254 557 383 259 557 minecraft:black_concrete
fill 383 254 578 384 254 578 minecraft:white_concrete
fill 384 254 573 384 254 575 minecraft:white_concrete
setblock 384 254 577 minecraft:white_concrete
setblock 384 254 579 minecraft:white_concrete
fill 384 254 581 385 254 583 minecraft:white_concrete
fill 384 254 599 385 255 599 minecraft:purple_concrete
setblock 385 254 573 minecraft:white_concrete
fill 386 254 570 386 254 571 minecraft:white_concrete
fill 386 254 581 386 254 582 minecraft:white_concrete
fill 386 254 585 386 254 586 minecraft:white_concrete
fill 386 254 599 387 259 599 minecraft:black_concrete
setblock 387 254 582 minecraft:white_concrete
fill 389 254 567 390 254 567 minecraft:white_concrete
fill 389 254 574 391 254 574 minecraft:red_nether_bricks
fill 389 254 589 390 254 589 minecraft:white_concrete
fill 390 254 571 390 254 573 minecraft:red_nether_bricks
fill 390 254 575 390 254 577 minecraft:red_nether_bricks
fill 391 254 557 392 259 557 minecraft:black_concrete
setblock 391 254 569 minecraft:white_concrete
fill 391 254 570 392 254 570 minecraft:red_nether_bricks
fill 391 254 572 391 255 573 minecraft:red_nether_bricks
fill 391 254 575 391 255 576 minecraft:red_nether_bricks
fill 391 254 578 392 254 578 minecraft:red_nether_bricks
setblock 391 254 592 minecraft:black_concrete
fill 391 254 593 399 254 593 minecraft:purple_concrete
setblock 391 254 594 minecraft:black_concrete
fill 392 254 565 392 254 566 minecraft:white_concrete
fill 392 254 590 394 254 591 minecraft:white_concrete
fill 392 254 592 396 255 592 minecraft:purple_concrete
fill 392 254 594 399 255 594 minecraft:purple_concrete
fill 393 254 557 394 255 557 minecraft:purple_concrete
fill 393 254 565 394 254 565 minecraft:white_concrete
setblock 393 254 568 minecraft:white_concrete
fill 393 254 569 393 254 570 minecraft:shroomlight
fill 393 254 578 393 254 579 minecraft:shroomlight
fill 393 254 588 393 254 589 minecraft:white_concrete
fill 393 254 599 393 255 599 minecraft:purple_concrete
setblock 394 254 589 minecraft:white_concrete
fill 394 254 599 395 259 599 minecraft:black_concrete
setblock 395 254 568 minecraft:red_nether_bricks
setblock 395 254 580 minecraft:red_nether_bricks
fill 395 254 591 395 256 591 minecraft:purple_concrete
setblock 395 254 596 minecraft:purple_concrete
fill 396 254 565 398 254 565 minecraft:white_concrete
fill 396 254 567 398 254 567 minecraft:white_concrete
fill 396 254 589 398 254 591 minecraft:white_concrete
setblock 396 254 599 minecraft:purple_concrete
setblock 397 254 564 minecraft:white_concrete
setblock 397 254 592 minecraft:white_concrete
fill 398 254 592 398 259 592 minecraft:purple_concrete
fill 398 254 595 398 259 595 minecraft:purple_concrete
fill 398 254 599 398 259 599 minecraft:black_concrete
setblock 399 254 566 minecraft:black_concrete
setblock 399 254 568 minecraft:red_nether_bricks
setblock 399 254 580 minecraft:red_nether_bricks
setblock 399 254 582 minecraft:black_concrete
fill 400 254 557 400 259 557 minecraft:black_concrete
fill 400 254 565 404 254 565 minecraft:black_concrete
fill 400 254 566 402 254 566 minecraft:white_concrete
fill 400 254 569 401 254 569 minecraft:red_nether_bricks
fill 400 254 579 401 254 579 minecraft:red_nether_bricks
fill 400 254 583 404 254 583 minecraft:black_concrete
fill 400 254 589 400 254 591 minecraft:white_concrete
setblock 401 254 568 minecraft:white_concrete
fill 401 254 591 402 254 591 minecraft:white_concrete
setblock 402 254 557 minecraft:purple_concrete
fill 402 254 571 403 254 571 minecraft:red_nether_bricks
fill 402 254 577 403 254 577 minecraft:red_nether_bricks
setblock 402 254 590 minecraft:white_concrete
fill 403 254 557 404 259 557 minecraft:black_concrete
fill 403 254 564 405 254 564 minecraft:black_concrete
setblock 403 254 569 minecraft:white_concrete
fill 403 254 572 403 255 572 minecraft:red_nether_bricks
fill 403 254 576 403 255 576 minecraft:red_nether_bricks
fill 403 254 584 405 254 584 minecraft:black_concrete
fill 404 254 567 405 254 567 minecraft:white_concrete
fill 404 254 589 405 254 589 minecraft:white_concrete
fill 404 254 599 405 255 599 minecraft:purple_concrete
fill 405 254 557 405 255 557 minecraft:purple_concrete
setblock 405 254 574 minecraft:red_nether_bricks
fill 406 254 568 409 257 569 minecraft:obsidian
fill 406 254 584 407 254 585 minecraft:white_concrete
fill 406 254 599 407 259 599 minecraft:black_concrete
fill 407 254 566 407 257 567 minecraft:obsidian
fill 408 254 567 408 257 567 minecraft:obsidian
fill 408 254 570 408 254 571 minecraft:white_concrete
fill 408 254 572 411 257 572 minecraft:obsidian
fill 408 254 577 410 254 577 minecraft:white_concrete
fill 408 254 579 410 254 579 minecraft:white_concrete
fill 408 254 585 408 254 586 minecraft:white_concrete
fill 409 254 565 411 257 565 minecraft:obsidian
fill 409 254 570 411 257 571 minecraft:obsidian
fill 409 254 573 410 254 573 minecraft:white_concrete
fill 409 254 583 410 254 583 minecraft:white_concrete
fill 410 254 569 410 257 569 minecraft:obsidian
fill 410 254 574 410 254 575 minecraft:white_concrete
fill 410 254 578 411 254 578 minecraft:white_concrete
fill 410 254 581 410 254 582 minecraft:white_concrete
fill 411 254 557 412 259 557 minecraft:black_concrete
fill 412 254 566 412 257 566 minecraft:obsidian
fill 413 254 557 414 254 557 minecraft:purple_concrete
fill 413 254 567 413 257 567 minecraft:obsidian
fill 413 254 570 413 257 570 minecraft:obsidian
fill 415 254 599 415 259 599 minecraft:black_concrete
fill 416 254 599 417 254 599 minecraft:purple_concrete
fill 418 254 562 418 259 563 minecraft:black_concrete
fill 418 254 564 418 255 565 minecraft:purple_concrete
fill 418 254 571 418 259 571 minecraft:black_concrete
fill 418 254 572 418 254 573 minecraft:purple_concrete
fill 418 254 574 418 255 575 minecraft:black_concrete
fill 418 254 576 418 255 576 minecraft:purple_concrete
fill 418 254 582 418 259 583 minecraft:black_concrete
fill 418 254 584 418 255 585 minecraft:purple_concrete
fill 418 254 592 418 257 592 minecraft:black_concrete
setblock 418 254 593 minecraft:purple_concrete
fill 418 254 594 418 259 595 minecraft:black_concrete
fill 418 254 596 418 255 597 minecraft:purple_concrete
fill 418 254 599 418 259 599 minecraft:black_concrete
setblock 376 255 563 minecraft:purple_concrete
fill 376 255 567 376 258 567 minecraft:black_concrete
setblock 376 255 583 minecraft:purple_concrete
setblock 376 255 587 minecraft:purple_concrete
fill 376 255 588 376 258 588 minecraft:black_concrete
fill 376 255 599 376 257 599 minecraft:black_concrete
fill 381 255 557 381 258 557 minecraft:black_concrete
setblock 381 255 599 minecraft:purple_concrete
setblock 382 255 557 minecraft:purple_concrete
fill 385 255 557 386 255 557 minecraft:purple_concrete
setblock 391 255 574 minecraft:red_nether_bricks
fill 392 255 593 400 255 593 minecraft:purple_concrete
setblock 392 255 599 minecraft:purple_concrete
fill 393 255 595 397 255 595 minecraft:purple_concrete
setblock 394 255 591 minecraft:purple_concrete
fill 396 255 591 398 256 591 minecraft:purple_concrete
fill 396 255 596 397 255 596 minecraft:purple_concrete
fill 396 255 599 396 258 599 minecraft:black_concrete
fill 397 255 592 397 258 592 minecraft:purple_concrete
setblock 399 255 565 minecraft:black_concrete
setblock 399 255 583 minecraft:black_concrete
fill 399 255 592 400 259 592 minecraft:purple_concrete
fill 399 255 595 399 259 595 minecraft:purple_concrete
setblock 400 255 564 minecraft:black_concrete
setblock 400 255 584 minecraft:black_concrete
fill 400 255 594 400 261 594 minecraft:purple_concrete
fill 402 255 557 402 258 557 minecraft:black_concrete
fill 402 255 564 403 255 564 minecraft:black_concrete
fill 402 255 584 403 255 584 minecraft:black_concrete
setblock 403 255 573 minecraft:red_nether_bricks
setblock 403 255 575 minecraft:red_nether_bricks
setblock 404 255 563 minecraft:black_concrete
setblock 404 255 585 minecraft:black_concrete
setblock 406 255 557 minecraft:purple_concrete
fill 406 255 567 406 257 567 minecraft:obsidian
fill 406 255 570 408 257 571 minecraft:obsidian
setblock 407 255 563 minecraft:black_concrete
fill 407 255 572 407 257 572 minecraft:obsidian
setblock 407 255 585 minecraft:black_concrete
fill 408 255 565 408 257 565 minecraft:obsidian
fill 409 255 573 410 257 573 minecraft:obsidian
fill 412 255 565 412 257 565 minecraft:obsidian
fill 412 255 572 412 257 572 minecraft:obsidian
fill 412 255 599 413 255 599 minecraft:purple_concrete
fill 413 255 557 413 258 557 minecraft:black_concrete
fill 413 255 566 413 257 566 minecraft:obsidian
fill 413 255 571 413 257 571 minecraft:obsidian
setblock 414 255 557 minecraft:purple_concrete
fill 414 255 568 414 257 569 minecraft:obsidian
setblock 416 255 599 minecraft:purple_concrete
setblock 417 255 557 minecraft:purple_concrete
fill 417 255 599 417 258 599 minecraft:black_concrete
fill 418 255 572 418 258 573 minecraft:black_concrete
setblock 418 255 577 minecraft:purple_concrete
setblock 418 255 588 minecraft:purple_concrete
fill 418 255 593 418 258 593 minecraft:black_concrete
fill 376 256 561 376 257 562 minecraft:purple_concrete
fill 376 256 563 376 261 564 minecraft:black_concrete
fill 376 256 573 376 256 574 minecraft:purple_concrete
fill 376 256 575 376 261 576 minecraft:black_concrete
fill 376 256 581 376 257 582 minecraft:purple_concrete
fill 376 256 583 376 261 584 minecraft:black_concrete
setblock 376 256 585 minecraft:purple_concrete
fill 376 256 587 376 258 587 minecraft:black_concrete
fill 376 256 593 376 257 594 minecraft:purple_concrete
fill 376 256 595 376 261 596 minecraft:black_concrete
setblock 378 256 599 minecraft:black_concrete
fill 379 256 599 379 257 599 minecraft:purple_concrete
fill 381 256 599 381 261 599 minecraft:black_concrete
fill 382 256 557 382 261 557 minecraft:black_concrete
fill 382 256 599 383 256 599 minecraft:purple_concrete
setblock 384 256 557 minecraft:purple_concrete
fill 384 256 599 385 258 599 minecraft:black_concrete
fill 385 256 557 386 261 557 minecraft:black_concrete
fill 387 256 557 387 257 557 minecraft:purple_concrete
fill 390 256 599 391 257 599 minecraft:purple_concrete
fill 392 256 599 393 261 599 minecraft:black_concrete
fill 393 256 557 394 261 557 minecraft:black_concrete
fill 393 256 593 401 256 593 minecraft:purple_concrete
fill 394 256 592 396 256 592 minecraft:purple_concrete
fill 394 256 594 397 256 595 minecraft:purple_concrete
fill 395 256 557 396 256 557 minecraft:purple_concrete
fill 397 256 596 399 257 596 minecraft:purple_concrete
fill 398 256 594 399 259 594 minecraft:purple_concrete
fill 399 256 564 399 257 564 minecraft:black_concrete
fill 399 256 584 399 257 584 minecraft:black_concrete
fill 399 256 591 400 259 591 minecraft:purple_concrete
fill 400 256 595 400 260 595 minecraft:purple_concrete
fill 401 256 563 401 257 563 minecraft:black_concrete
setblock 401 256 569 minecraft:blackstone
setblock 401 256 579 minecraft:blackstone
fill 401 256 585 401 257 585 minecraft:black_concrete
fill 401 256 592 401 257 592 minecraft:purple_concrete
fill 401 256 594 401 258 594 minecraft:purple_concrete
fill 402 256 599 403 256 599 minecraft:purple_concrete
setblock 403 256 563 minecraft:black_concrete
setblock 403 256 585 minecraft:black_concrete
fill 404 256 599 405 261 599 minecraft:black_concrete
fill 405 256 557 406 261 557 minecraft:black_concrete
fill 405 256 562 406 256 562 minecraft:black_concrete
fill 405 256 568 405 257 570 minecraft:obsidian
fill 405 256 586 406 256 586 minecraft:black_concrete
fill 406 256 566 406 257 566 minecraft:obsidian
fill 407 256 557 408 257 557 minecraft:purple_concrete
fill 407 256 565 407 257 565 minecraft:obsidian
fill 408 256 573 408 257 573 minecraft:obsidian
fill 409 256 562 410 256 562 minecraft:black_concrete
fill 409 256 564 411 257 564 minecraft:obsidian
fill 409 256 586 410 256 586 minecraft:black_concrete
fill 410 256 561 411 256 561 minecraft:black_concrete
fill 410 256 587 411 256 587 minecraft:black_concrete
fill 411 256 573 411 257 573 minecraft:obsidian
fill 411 256 599 411 257 599 minecraft:purple_concrete
fill 412 256 599 413 261 599 minecraft:black_concrete
fill 413 256 572 413 257 572 minecraft:obsidian
fill 414 256 557 414 261 557 minecraft:black_concrete
fill 414 256 567 414 257 567 minecraft:obsidian
fill 414 256 570 414 257 570 minecraft:obsidian
setblock 414 256 599 minecraft:purple_concrete
fill 415 256 557 416 256 557 minecraft:purple_concrete
fill 416 256 599 416 261 599 minecraft:black_concrete
fill 417 256 557 417 261 557 minecraft:black_concrete
fill 418 256 558 418 257 558 minecraft:purple_concrete
fill 418 256 564 418 261 565 minecraft:black_concrete
fill 418 256 566 418 257 567 minecraft:purple_concrete
fill 418 256 574 418 259 574 minecraft:black_concrete
setblock 418 256 575 minecraft:purple_concrete
fill 418 256 576 418 261 577 minecraft:black_concrete
fill 418 256 578 418 257 579 minecraft:purple_concrete
fill 418 256 584 418 261 585 minecraft:black_concrete
fill 418 256 586 418 256 587 minecraft:purple_concrete
fill 418 256 588 418 261 588 minecraft:black_concrete
fill 418 256 596 418 261 597 minecraft:black_concrete
fill 418 256 598 418 257 598 minecraft:purple_concrete
setblock 376 257 570 minecraft:purple_concrete
setblock 376 257 573 minecraft:purple_concrete
fill 376 257 574 376 260 574 minecraft:black_concrete
fill 376 257 585 376 260 585 minecraft:black_concrete
fill 376 257 589 376 259 589 minecraft:black_concrete
setblock 376 257 590 minecraft:purple_concrete
setblock 378 257 599 minecraft:purple_concrete
setblock 382 257 599 minecraft:purple_concrete
fill 383 257 599 383 260 599 minecraft:black_concrete
fill 384 257 557 384 260 557 minecraft:black_concrete
setblock 388 257 557 minecraft:purple_concrete
fill 393 257 593 394 259 593 minecraft:amethyst_block
fill 395 257 557 395 260 557 minecraft:black_concrete
fill 395 257 592 396 257 594 minecraft:purple_concrete
setblock 396 257 557 minecraft:purple_concrete
fill 396 257 595 397 257 595 minecraft:purple_concrete
fill 397 257 591 398 257 591 minecraft:purple_concrete
fill 397 257 593 397 259 594 minecraft:purple_concrete
fill 398 257 593 403 257 593 minecraft:purple_concrete
setblock 399 257 557 minecraft:purple_concrete
fill 399 257 563 399 258 563 minecraft:black_concrete
fill 399 257 585 399 258 585 minecraft:black_concrete
setblock 399 257 599 minecraft:purple_concrete
fill 401 257 562 401 258 562 minecraft:black_concrete
fill 401 257 568 402 258 568 minecraft:blackstone
fill 401 257 580 402 258 580 minecraft:blackstone
fill 401 257 586 401 258 586 minecraft:black_concrete
fill 401 257 591 402 257 591 minecraft:purple_concrete
fill 401 257 595 401 260 595 minecraft:purple_concrete
fill 402 257 569 402 259 569 minecraft:blackstone
fill 402 257 579 402 259 579 minecraft:blackstone
fill 402 257 592 403 257 592 minecraft:purple_concrete
setblock 402 257 594 minecraft:purple_concrete
setblock 402 257 599 minecraft:purple_concrete
fill 403 257 599 403 260 599 minecraft:black_concrete
fill 404 257 562 404 258 562 minecraft:black_concrete
fill 404 257 586 404 258 586 minecraft:black_concrete
setblock 405 257 567 minecraft:obsidian
setblock 405 257 571 minecraft:obsidian
setblock 406 257 565 minecraft:obsidian
setblock 406 257 572 minecraft:obsidian
setblock 407 257 561 minecraft:black_concrete
fill 407 257 564 408 257 564 minecraft:obsidian
setblock 407 257 573 minecraft:obsidian
setblock 407 257 587 minecraft:black_concrete
fill 408 257 560 408 258 560 minecraft:black_concrete
fill 408 257 588 408 258 588 minecraft:black_concrete
setblock 410 257 574 minecraft:obsidian
setblock 410 257 599 minecraft:purple_concrete
setblock 411 257 561 minecraft:black_concrete
setblock 411 257 587 minecraft:black_concrete
setblock 412 257 564 minecraft:obsidian
setblock 412 257 573 minecraft:obsidian
setblock 413 257 565 minecraft:obsidian
setblock 414 257 566 minecraft:obsidian
setblock 414 257 571 minecraft:obsidian
fill 414 257 599 414 260 599 minecraft:black_concrete
fill 415 257 557 416 260 557 minecraft:black_concrete
fill 415 257 568 415 257 569 minecraft:obsidian
setblock 418 257 559 minecraft:purple_concrete
setblock 418 257 570 minecraft:purple_concrete
fill 418 257 575 418 260 575 minecraft:black_concrete
fill 418 257 586 418 260 586 minecraft:black_concrete
setblock 418 257 587 minecraft:purple_concrete
fill 418 257 590 418 257 591 minecraft:purple_concrete
fill 376 258 559 376 259 560 minecraft:purple_concrete
fill 376 258 561 376 263 562 minecraft:black_concrete
fill 376 258 568 376 259 568 minecraft:purple_concrete
fill 376 258 570 376 263 570 minecraft:black_concrete
fill 376 258 571 376 258 572 minecraft:purple_concrete
fill 376 258 573 376 263 573 minecraft:black_concrete
fill 376 258 579 376 259 580 minecraft:purple_concrete
fill 376 258 581 376 263 582 minecraft:black_concrete
fill 376 258 590 376 259 590 minecraft:black_concrete
fill 376 258 591 376 258 592 minecraft:purple_concrete
fill 376 258 593 376 263 594 minecraft:black_concrete
fill 376 258 599 377 259 599 minecraft:purple_concrete
fill 377 258 557 378 258 557 minecraft:purple_concrete
fill 377 258 558 379 258 558 minecraft:obsidian
fill 377 258 560 377 258 562 minecraft:obsidian
fill 377 258 564 377 258 566 minecraft:obsidian
fill 377 258 568 377 258 570 minecraft:obsidian
fill 377 258 572 377 258 574 minecraft:obsidian
fill 377 258 576 377 258 578 minecraft:obsidian
fill 377 258 580 377 258 582 minecraft:obsidian
fill 377 258 584 377 258 586 minecraft:obsidian
fill 377 258 588 377 258 590 minecraft:obsidian
fill 377 258 592 377 258 594 minecraft:obsidian
fill 377 258 596 377 258 598 minecraft:obsidian
fill 378 258 599 379 263 599 minecraft:black_concrete
fill 379 258 598 381 258 598 minecraft:obsidian
setblock 380 258 599 minecraft:purple_concrete
fill 381 258 558 383 258 558 minecraft:obsidian
fill 382 258 599 382 260 599 minecraft:black_concrete
fill 383 258 598 385 258 598 minecraft:obsidian
fill 385 258 558 387 258 558 minecraft:obsidian
fill 387 258 557 388 263 557 minecraft:black_concrete
fill 387 258 598 389 258 598 minecraft:obsidian
fill 388 258 599 389 259 599 minecraft:purple_concrete
fill 389 258 557 390 259 557 minecraft:purple_concrete
fill 389 258 558 391 258 558 minecraft:obsidian
fill 390 258 599 391 263 599 minecraft:black_concrete
fill 391 258 598 393 258 598 minecraft:obsidian
fill 393 258 558 395 258 558 minecraft:obsidian
fill 395 258 598 397 258 598 minecraft:obsidian
fill 396 258 557 396 263 557 minecraft:black_concrete
fill 396 258 593 396 258 594 minecraft:purple_concrete
fill 397 258 557 398 258 557 minecraft:purple_concrete
fill 397 258 558 399 258 558 minecraft:obsidian
setblock 397 258 595 minecraft:purple_concrete
fill 397 258 599 397 259 599 minecraft:purple_concrete
setblock 398 258 591 minecraft:purple_concrete
fill 398 258 593 400 259 593 minecraft:purple_concrete
fill 399 258 557 399 263 557 minecraft:black_concrete
fill 399 258 598 401 258 598 minecraft:obsidian
fill 399 258 599 399 263 599 minecraft:black_concrete
fill 400 258 599 401 258 599 minecraft:purple_concrete
fill 401 258 557 401 259 557 minecraft:purple_concrete
fill 401 258 558 403 258 558 minecraft:obsidian
setblock 401 258 591 minecraft:purple_concrete
fill 401 258 592 404 262 593 minecraft:black_concrete
fill 402 258 591 403 263 591 minecraft:black_concrete
fill 402 258 594 403 262 594 minecraft:black_concrete
fill 402 258 595 402 259 595 minecraft:purple_concrete
fill 402 258 599 402 263 599 minecraft:black_concrete
fill 403 258 568 403 260 568 minecraft:blackstone
fill 403 258 580 403 260 580 minecraft:blackstone
fill 403 258 598 405 258 598 minecraft:obsidian
fill 405 258 558 407 258 558 minecraft:obsidian
fill 405 258 561 405 259 561 minecraft:black_concrete
fill 405 258 587 405 259 587 minecraft:black_concrete
fill 407 258 557 408 263 557 minecraft:black_concrete
fill 407 258 598 409 258 598 minecraft:obsidian
fill 408 258 599 409 259 599 minecraft:purple_concrete
fill 409 258 557 410 259 557 minecraft:purple_concrete
fill 409 258 558 411 258 558 minecraft:obsidian
fill 409 258 568 410 259 569 minecraft:amethyst_block
fill 410 258 599 411 263 599 minecraft:black_concrete
fill 411 258 598 413 258 598 minecraft:obsidian
fill 413 258 558 415 258 558 minecraft:obsidian
fill 415 258 598 417 258 598 minecraft:obsidian
fill 417 258 558 417 258 560 minecraft:obsidian
fill 417 258 562 417 258 564 minecraft:obsidian
fill 417 258 566 417 258 568 minecraft:obsidian
fill 417 258 570 417 258 572 minecraft:obsidian
fill 417 258 574 417 258 576 minecraft:obsidian
fill 417 258 578 417 258 580 minecraft:obsidian
fill 417 258 582 417 258 584 minecraft:obsidian
fill 417 258 586 417 258 588 minecraft:obsidian
fill 417 258 590 417 258 592 minecraft:obsidian
fill 417 258 594 417 258 596 minecraft:obsidian
setblock 418 258 557 minecraft:purple_concrete
fill 418 258 558 418 263 559 minecraft:black_concrete
fill 418 258 560 418 259 561 minecraft:purple_concrete
fill 418 258 566 418 263 567 minecraft:black_concrete
fill 418 258 568 418 258 569 minecraft:purple_concrete
fill 418 258 570 418 263 570 minecraft:black_concrete
fill 418 258 578 418 263 579 minecraft:black_concrete
fill 418 258 580 418 259 581 minecraft:purple_concrete
fill 418 258 587 418 263 587 minecraft:black_concrete
setblock 418 258 589 minecraft:purple_concrete
fill 418 258 590 418 263 591 minecraft:black_concrete
fill 418 258 592 418 259 592 minecraft:purple_concrete
fill 418 258 598 418 263 598 minecraft:black_concrete
setblock 376 259 567 minecraft:purple_concrete
fill 376 259 571 376 261 572 minecraft:black_concrete
fill 376 259 587 376 259 588 minecraft:purple_concrete
setblock 376 259 591 minecraft:purple_concrete
fill 376 259 592 376 262 592 minecraft:black_concrete
fill 377 259 557 377 262 557 minecraft:black_concrete
setblock 378 259 557 minecraft:purple_concrete
fill 380 259 599 380 262 599 minecraft:black_concrete
setblock 381 259 557 minecraft:purple_concrete
fill 384 259 599 384 261 599 minecraft:black_concrete
setblock 385 259 599 minecraft:purple_concrete
setblock 396 259 599 minecraft:purple_concrete
fill 397 259 557 398 262 557 minecraft:black_concrete
setblock 399 259 562 minecraft:black_concrete
setblock 399 259 586 minecraft:black_concrete
fill 400 259 599 401 262 599 minecraft:black_concrete
fill 401 259 590 401 260 590 minecraft:purple_concrete
fill 401 259 591 401 261 591 minecraft:black_concrete
fill 401 259 594 401 261 594 minecraft:black_concrete
setblock 402 259 557 minecraft:purple_concrete
fill 402 259 560 402 259 561 minecraft:black_concrete
fill 402 259 567 402 259 568 minecraft:blackstone
fill 402 259 580 402 259 581 minecraft:blackstone
fill 402 259 587 402 259 588 minecraft:black_concrete
fill 402 259 590 404 262 590 minecraft:black_concrete
fill 403 259 567 403 261 567 minecraft:blackstone
fill 403 259 581 403 261 581 minecraft:blackstone
setblock 403 259 595 minecraft:purple_concrete
fill 404 259 591 405 261 591 minecraft:black_concrete
fill 404 259 594 404 262 594 minecraft:black_concrete
fill 405 259 592 405 262 593 minecraft:black_concrete
setblock 413 259 557 minecraft:purple_concrete
setblock 417 259 599 minecraft:purple_concrete
fill 418 259 557 418 262 557 minecraft:black_concrete
fill 418 259 568 418 262 568 minecraft:black_concrete
setblock 418 259 569 minecraft:purple_concrete
fill 418 259 572 418 259 573 minecraft:purple_concrete
fill 418 259 589 418 262 589 minecraft:black_concrete
setblock 418 259 593 minecraft:purple_concrete
fill 376 260 557 376 260 558 minecraft:purple_concrete
fill 376 260 559 376 265 560 minecraft:black_concrete
fill 376 260 565 376 261 566 minecraft:purple_concrete
fill 376 260 567 376 265 568 minecraft:black_concrete
setblock 376 260 569 minecraft:purple_concrete
fill 376 260 577 376 261 578 minecraft:purple_concrete
fill 376 260 579 376 265 580 minecraft:black_concrete
fill 376 260 586 376 261 586 minecraft:purple_concrete
fill 376 260 587 376 261 588 minecraft:black_concrete
fill 376 260 589 376 260 590 minecraft:purple_concrete
fill 376 260 591 376 265 591 minecraft:black_concrete
fill 376 260 597 376 261 598 minecraft:purple_concrete
fill 376 260 599 377 265 599 minecraft:black_concrete
fill 378 260 557 378 265 557 minecraft:black_concrete
fill 379 260 557 380 260 557 minecraft:purple_concrete
setblock 379 260 560 minecraft:light[level=12]
setblock 379 260 568 minecraft:light[level=12]
setblock 379 260 576 minecraft:light[level=12]
setblock 379 260 584 minecraft:light[level=12]
setblock 379 260 592 minecraft:light[level=12]
fill 381 260 557 381 265 557 minecraft:black_concrete
fill 383 260 557 383 261 557 minecraft:purple_concrete
fill 385 260 599 385 265 599 minecraft:black_concrete
fill 386 260 599 387 260 599 minecraft:purple_concrete
setblock 387 260 560 minecraft:light[level=12]
setblock 387 260 568 minecraft:light[level=12]
setblock 387 260 576 minecraft:light[level=12]
setblock 387 260 584 minecraft:light[level=12]
setblock 387 260 592 minecraft:light[level=12]
fill 388 260 599 389 265 599 minecraft:black_concrete
fill 389 260 557 390 265 557 minecraft:black_concrete
fill 391 260 557 392 261 557 minecraft:purple_concrete
fill 394 260 599 395 261 599 minecraft:purple_concrete
setblock 395 260 560 minecraft:light[level=12]
setblock 395 260 584 minecraft:light[level=12]
setblock 395 260 592 minecraft:light[level=12]
fill 396 260 599 397 265 599 minecraft:black_concrete
fill 398 260 593 399 260 593 minecraft:purple_concrete
setblock 398 260 599 minecraft:purple_concrete
fill 399 260 561 399 261 561 minecraft:black_concrete
fill 399 260 587 399 261 587 minecraft:black_concrete
setblock 399 260 592 minecraft:purple_concrete
setblock 399 260 594 minecraft:purple_concrete
setblock 400 260 557 minecraft:purple_concrete
setblock 400 260 591 minecraft:purple_concrete
fill 400 260 592 400 260 593 minecraft:black_concrete
fill 401 260 557 402 265 557 minecraft:black_concrete
setblock 402 260 560 minecraft:black_concrete
setblock 402 260 568 minecraft:blackstone
setblock 402 260 580 minecraft:blackstone
setblock 402 260 588 minecraft:black_concrete
fill 402 260 595 403 261 595 minecraft:black_concrete
fill 403 260 557 404 261 557 minecraft:purple_concrete
setblock 403 260 560 minecraft:light[level=12]
setblock 403 260 584 minecraft:light[level=12]
fill 404 260 567 404 261 568 minecraft:blackstone
fill 404 260 580 404 261 581 minecraft:blackstone
fill 405 260 590 406 260 590 minecraft:black_concrete
fill 405 260 594 405 262 594 minecraft:black_concrete
fill 406 260 591 406 261 593 minecraft:black_concrete
fill 406 260 599 407 261 599 minecraft:purple_concrete
fill 408 260 599 409 265 599 minecraft:black_concrete
fill 409 260 557 410 265 557 minecraft:black_concrete
fill 409 260 569 410 260 569 minecraft:amethyst_block
setblock 410 260 568 minecraft:amethyst_block
fill 411 260 557 412 260 557 minecraft:purple_concrete
setblock 411 260 560 minecraft:light[level=12]
setblock 411 260 568 minecraft:light[level=12]
setblock 411 260 576 minecraft:light[level=12]
setblock 411 260 584 minecraft:light[level=12]
setblock 411 260 592 minecraft:light[level=12]
fill 413 260 557 413 265 557 minecraft:black_concrete
fill 415 260 599 415 261 599 minecraft:purple_concrete
fill 417 260 599 417 265 599 minecraft:black_concrete
fill 418 260 560 418 265 561 minecraft:black_concrete
fill 418 260 562 418 261 563 minecraft:purple_concrete
fill 418 260 569 418 265 569 minecraft:black_concrete
setblock 418 260 571 minecraft:purple_concrete
fill 418 260 572 418 265 573 minecraft:black_concrete
fill 418 260 574 418 261 574 minecraft:purple_concrete
fill 418 260 580 418 265 581 minecraft:black_concrete
fill 418 260 582 418 260 583 minecraft:purple_concrete
fill 418 260 592 418 265 593 minecraft:black_concrete
fill 418 260 594 418 261 595 minecraft:purple_concrete
setblock 418 260 599 minecraft:purple_concrete
setblock 376 261 557 minecraft:purple_concrete
fill 376 261 558 376 264 558 minecraft:black_concrete
fill 376 261 569 376 263 569 minecraft:black_concrete
setblock 376 261 574 minecraft:purple_concrete
setblock 376 261 585 minecraft:purple_concrete
fill 376 261 589 376 263 590 minecraft:black_concrete
fill 379 261 557 380 264 557 minecraft:black_concrete
fill 382 261 599 383 261 599 minecraft:purple_concrete
setblock 384 261 557 minecraft:purple_concrete
setblock 386 261 599 minecraft:purple_concrete
fill 387 261 599 387 264 599 minecraft:black_concrete
setblock 395 261 557 minecraft:purple_concrete
fill 398 261 599 398 264 599 minecraft:black_concrete
fill 400 261 557 400 264 557 minecraft:black_concrete
fill 400 261 592 400 261 593 minecraft:purple_concrete
setblock 403 261 599 minecraft:purple_concrete
fill 404 261 566 405 262 566 minecraft:blackstone
fill 404 261 582 405 262 582 minecraft:blackstone
fill 404 261 589 407 261 589 minecraft:black_concrete
fill 405 261 567 405 262 567 minecraft:blackstone
fill 405 261 581 405 262 581 minecraft:blackstone
setblock 405 261 590 minecraft:black_concrete
fill 406 261 590 407 266 590 minecraft:purple_concrete
fill 407 261 591 407 261 592 minecraft:black_concrete
setblock 410 261 569 minecraft:amethyst_block
fill 411 261 557 411 264 557 minecraft:black_concrete
setblock 412 261 557 minecraft:purple_concrete
setblock 414 261 599 minecraft:purple_concrete
fill 415 261 557 416 261 557 minecraft:purple_concrete
fill 418 261 571 418 264 571 minecraft:black_concrete
setblock 418 261 575 minecraft:purple_concrete
fill 418 261 582 418 264 582 minecraft:black_concrete
setblock 418 261 583 minecraft:purple_concrete
setblock 418 261 586 minecraft:purple_concrete
fill 418 261 599 418 264 599 minecraft:black_concrete
fill 376 262 557 376 267 557 minecraft:black_concrete
fill 376 262 563 376 263 564 minecraft:purple_concrete
fill 376 262 565 376 267 566 minecraft:black_concrete
setblock 376 262 571 minecraft:black_concrete
fill 376 262 572 376 263 572 minecraft:purple_concrete
fill 376 262 574 376 267 574 minecraft:black_concrete
fill 376 262 575 376 262 576 minecraft:purple_concrete
fill 376 262 577 376 264 578 minecraft:black_concrete
fill 376 262 583 376 263 584 minecraft:purple_concrete
fill 376 262 585 376 267 586 minecraft:black_concrete
setblock 376 262 587 minecraft:purple_concrete
fill 376 262 588 376 265 588 minecraft:black_concrete
fill 376 262 595 376 263 596 minecraft:purple_concrete
fill 376 262 597 376 267 598 minecraft:black_concrete
fill 381 262 599 381 263 599 minecraft:purple_concrete
setblock 382 262 557 minecraft:purple_concrete
fill 382 262 599 383 267 599 minecraft:black_concrete
fill 383 262 557 384 267 557 minecraft:black_concrete
setblock 384 262 599 minecraft:purple_concrete
fill 385 262 557 386 263 557 minecraft:purple_concrete
fill 386 262 599 386 267 599 minecraft:black_concrete
fill 391 262 557 392 267 557 minecraft:black_concrete
fill 392 262 599 393 263 599 minecraft:purple_concrete
fill 393 262 557 394 262 557 minecraft:purple_concrete
fill 394 262 599 395 267 599 minecraft:black_concrete
fill 395 262 557 395 267 557 minecraft:black_concrete
fill 403 262 557 404 267 557 minecraft:black_concrete
fill 403 262 599 403 267 599 minecraft:black_concrete
setblock 404 262 567 minecraft:blackstone
setblock 404 262 581 minecraft:blackstone
fill 404 262 589 404 264 589 minecraft:black_concrete
fill 404 262 591 404 263 591 minecraft:black_concrete
fill 404 262 599 405 262 599 minecraft:purple_concrete
fill 405 262 557 406 263 557 minecraft:purple_concrete
fill 405 262 589 405 265 591 minecraft:purple_concrete
setblock 406 262 588 minecraft:black_concrete
fill 406 262 589 408 267 589 minecraft:purple_concrete
fill 406 262 591 407 265 592 minecraft:purple_concrete
fill 406 262 593 407 263 593 minecraft:black_concrete
fill 406 262 599 407 267 599 minecraft:black_concrete
fill 407 262 588 407 268 588 minecraft:purple_concrete
fill 408 262 590 408 266 591 minecraft:purple_concrete
setblock 408 262 592 minecraft:black_concrete
fill 412 262 557 412 267 557 minecraft:black_concrete
fill 412 262 599 413 263 599 minecraft:purple_concrete
setblock 414 262 557 minecraft:purple_concrete
fill 414 262 599 415 267 599 minecraft:black_concrete
fill 415 262 557 416 267 557 minecraft:black_concrete
setblock 416 262 599 minecraft:purple_concrete
fill 417 262 557 417 263 557 minecraft:purple_concrete
fill 418 262 562 418 267 563 minecraft:black_concrete
fill 418 262 564 418 262 565 minecraft:purple_concrete
fill 418 262 574 418 267 575 minecraft:black_concrete
fill 418 262 576 418 263 577 minecraft:purple_concrete
fill 418 262 583 418 267 583 minecraft:black_concrete
fill 418 262 584 418 262 585 minecraft:purple_concrete
fill 418 262 586 418 267 586 minecraft:black_concrete
fill 418 262 588 418 263 588 minecraft:purple_concrete
fill 418 262 594 418 267 595 minecraft:black_concrete
fill 418 262 596 418 263 597 minecraft:purple_concrete
setblock 376 263 571 minecraft:purple_concrete
setblock 376 263 575 minecraft:purple_concrete
fill 376 263 576 376 266 576 minecraft:black_concrete
fill 376 263 587 376 265 587 minecraft:black_concrete
setblock 376 263 592 minecraft:purple_concrete
setblock 377 263 557 minecraft:purple_concrete
setblock 380 263 599 minecraft:purple_concrete
fill 382 263 557 382 266 557 minecraft:black_concrete
fill 384 263 599 384 266 599 minecraft:black_concrete
fill 393 263 557 393 266 557 minecraft:black_concrete
setblock 394 263 557 minecraft:purple_concrete
fill 397 263 557 398 263 557 minecraft:purple_concrete
fill 400 263 599 401 263 599 minecraft:purple_concrete
fill 402 263 592 404 263 593 minecraft:black_concrete
setblock 403 263 590 minecraft:black_concrete
fill 404 263 590 404 264 590 minecraft:purple_concrete
setblock 404 263 599 minecraft:purple_concrete
setblock 405 263 566 minecraft:blackstone
setblock 405 263 582 minecraft:blackstone
fill 405 263 588 406 265 588 minecraft:purple_concrete
fill 405 263 592 405 265 592 minecraft:purple_concrete
fill 405 263 593 405 264 593 minecraft:black_concrete
fill 405 263 599 405 266 599 minecraft:black_concrete
fill 408 263 587 408 269 588 minecraft:purple_concrete
fill 408 263 592 408 265 592 minecraft:purple_concrete
fill 409 263 588 409 266 591 minecraft:purple_concrete
fill 414 263 557 414 266 557 minecraft:black_concrete
fill 416 263 599 416 266 599 minecraft:black_concrete
setblock 418 263 557 minecraft:purple_concrete
fill 418 263 564 418 266 564 minecraft:black_concrete
setblock 418 263 565 minecraft:purple_concrete
setblock 418 263 568 minecraft:purple_concrete
fill 418 263 584 418 266 585 minecraft:black_concrete
setblock 418 263 589 minecraft:purple_concrete
fill 376 264 561 376 264 562 minecraft:purple_concrete
fill 376 264 563 376 269 564 minecraft:black_concrete
fill 376 264 569 376 265 570 minecraft:purple_concrete
fill 376 264 571 376 269 572 minecraft:black_concrete
setblock 376 264 573 minecraft:purple_concrete
fill 376 264 575 376 266 575 minecraft:black_concrete
fill 376 264 581 376 265 582 minecraft:purple_concrete
fill 376 264 583 376 269 584 minecraft:black_concrete
setblock 376 264 589 minecraft:black_concrete
fill 376 264 590 376 265 590 minecraft:purple_concrete
fill 376 264 592 376 269 592 minecraft:black_concrete
fill 376 264 593 376 264 594 minecraft:purple_concrete
fill 376 264 595 376 266 596 minecraft:black_concrete
fill 377 264 557 377 269 557 minecraft:black_concrete
fill 377 264 558 379 264 558 minecraft:obsidian
fill 377 264 560 377 264 562 minecraft:obsidian
fill 377 264 564 377 264 566 minecraft:obsidian
fill 377 264 568 377 264 570 minecraft:obsidian
fill 377 264 572 377 264 574 minecraft:obsidian
fill 377 264 576 377 264 578 minecraft:obsidian
fill 377 264 580 377 264 582 minecraft:obsidian
fill 377 264 584 377 264 586 minecraft:obsidian
fill 377 264 588 377 264 590 minecraft:obsidian
fill 377 264 592 377 264 594 minecraft:obsidian
fill 377 264 596 377 264 598 minecraft:obsidian
fill 378 264 599 379 265 599 minecraft:purple_concrete
fill 379 264 598 381 264 598 minecraft:obsidian
fill 380 264 599 381 269 599 minecraft:black_concrete
fill 381 264 558 383 264 558 minecraft:obsidian
fill 383 264 598 385 264 598 minecraft:obsidian
fill 385 264 557 386 269 557 minecraft:black_concrete
fill 385 264 558 387 264 558 minecraft:obsidian
fill 387 264 557 388 265 557 minecraft:purple_concrete
fill 387 264 598 389 264 598 minecraft:obsidian
fill 389 264 558 391 264 558 minecraft:obsidian
fill 390 264 599 391 264 599 minecraft:purple_concrete
fill 391 264 598 393 264 598 minecraft:obsidian
fill 392 264 599 393 269 599 minecraft:black_concrete
fill 393 264 558 395 264 558 minecraft:obsidian
fill 394 264 557 394 269 557 minecraft:black_concrete
fill 395 264 598 397 264 598 minecraft:obsidian
setblock 396 264 557 minecraft:purple_concrete
fill 397 264 557 398 269 557 minecraft:black_concrete
fill 397 264 558 399 264 558 minecraft:obsidian
fill 399 264 557 399 265 557 minecraft:purple_concrete
fill 399 264 598 401 264 598 minecraft:obsidian
fill 399 264 599 399 265 599 minecraft:purple_concrete
fill 400 264 599 401 269 599 minecraft:black_concrete
fill 401 264 558 403 264 558 minecraft:obsidian
setblock 402 264 599 minecraft:purple_concrete
fill 403 264 591 403 264 592 minecraft:black_concrete
fill 403 264 598 405 264 598 minecraft:obsidian
setblock 404 264 591 minecraft:purple_concrete
fill 404 264 592 404 264 593 minecraft:black_concrete
fill 404 264 599 404 269 599 minecraft:black_concrete
fill 405 264 557 406 269 557 minecraft:black_concrete
fill 405 264 558 407 264 558 minecraft:obsidian
fill 406 264 587 407 266 587 minecraft:purple_concrete
setblock 406 264 593 minecraft:black_concrete
fill 407 264 557 408 264 557 minecraft:purple_concrete
fill 407 264 598 409 264 598 minecraft:obsidian
fill 409 264 558 411 264 558 minecraft:obsidian
fill 409 264 587 410 270 587 minecraft:purple_concrete
fill 410 264 588 410 267 590 minecraft:purple_concrete
fill 410 264 599 411 265 599 minecraft:purple_concrete
fill 411 264 598 413 264 598 minecraft:obsidian
fill 412 264 599 413 269 599 minecraft:black_concrete
fill 413 264 558 415 264 558 minecraft:obsidian
fill 415 264 598 417 264 598 minecraft:obsidian
fill 417 264 557 418 269 557 minecraft:black_concrete
fill 417 264 558 417 264 560 minecraft:obsidian
fill 417 264 562 417 264 564 minecraft:obsidian
fill 417 264 566 417 264 568 minecraft:obsidian
fill 417 264 570 417 264 572 minecraft:obsidian
fill 417 264 574 417 264 576 minecraft:obsidian
fill 417 264 578 417 264 580 minecraft:obsidian
fill 417 264 582 417 264 584 minecraft:obsidian
fill 417 264 586 417 264 588 minecraft:obsidian
fill 417 264 590 417 264 592 minecraft:obsidian
fill 417 264 594 417 264 596 minecraft:obsidian
fill 418 264 558 418 265 559 minecraft:purple_concrete
fill 418 264 565 418 269 565 minecraft:black_concrete
fill 418 264 566 418 264 567 minecraft:purple_concrete
fill 418 264 568 418 269 568 minecraft:black_concrete
fill 418 264 570 418 265 570 minecraft:purple_concrete
fill 418 264 576 418 269 577 minecraft:black_concrete
fill 418 264 578 418 265 579 minecraft:purple_concrete
setblock 418 264 587 minecraft:purple_concrete
fill 418 264 588 418 269 589 minecraft:black_concrete
fill 418 264 590 418 265 591 minecraft:purple_concrete
fill 418 264 596 418 269 597 minecraft:black_concrete
setblock 418 264 598 minecraft:purple_concrete
setblock 376 265 558 minecraft:purple_concrete
setblock 376 265 561 minecraft:purple_concrete
fill 376 265 562 376 268 562 minecraft:black_concrete
fill 376 265 573 376 268 573 minecraft:black_concrete
fill 376 265 577 376 267 577 minecraft:black_concrete
setblock 376 265 578 minecraft:purple_concrete
setblock 376 265 589 minecraft:purple_concrete
setblock 376 265 593 minecraft:purple_concrete
fill 376 265 594 376 268 594 minecraft:black_concrete
fill 379 265 557 380 265 557 minecraft:purple_concrete
setblock 387 265 599 minecraft:purple_concrete
setblock 390 265 599 minecraft:purple_concrete
fill 391 265 599 391 268 599 minecraft:black_concrete
fill 396 265 557 396 268 557 minecraft:black_concrete
setblock 398 265 599 minecraft:purple_concrete
setblock 400 265 557 minecraft:purple_concrete
fill 402 265 599 402 268 599 minecraft:black_concrete
fill 404 265 590 404 265 591 minecraft:black_concrete
fill 407 265 557 407 268 557 minecraft:black_concrete
fill 407 265 586 411 267 586 minecraft:purple_concrete
setblock 408 265 557 minecraft:purple_concrete
setblock 411 265 557 minecraft:purple_concrete
fill 411 265 569 411 266 569 minecraft:obsidian
fill 411 265 587 411 268 589 minecraft:purple_concrete
fill 418 265 566 418 268 567 minecraft:black_concrete
setblock 418 265 571 minecraft:purple_concrete
setblock 418 265 582 minecraft:purple_concrete
fill 418 265 587 418 268 587 minecraft:black_concrete
fill 418 265 598 418 268 598 minecraft:black_concrete
setblock 418 265 599 minecraft:purple_concrete
fill 376 266 558 376 271 558 minecraft:black_concrete
fill 376 266 559 376 266 560 minecraft:purple_concrete
fill 376 266 561 376 271 561 minecraft:black_concrete
fill 376 266 567 376 267 568 minecraft:purple_concrete
fill 376 266 569 376 271 570 minecraft:black_concrete
fill 376 266 578 376 267 578 minecraft:black_concrete
fill 376 266 579 376 266 580 minecraft:purple_concrete
fill 376 266 581 376 271 582 minecraft:black_concrete
fill 376 266 587 376 267 588 minecraft:purple_concrete
fill 376 266 589 376 271 590 minecraft:black_concrete
setblock 376 266 591 minecraft:purple_concrete
fill 376 266 593 376 268 593 minecraft:black_concrete
fill 376 266 599 377 267 599 minecraft:purple_concrete
setblock 378 266 557 minecraft:purple_concrete
fill 378 266 599 379 271 599 minecraft:black_concrete
fill 379 266 557 380 271 557 minecraft:black_concrete
fill 381 266 557 381 267 557 minecraft:purple_concrete
fill 385 266 599 385 267 599 minecraft:purple_concrete
fill 387 266 557 388 271 557 minecraft:black_concrete
fill 387 266 599 387 271 599 minecraft:black_concrete
fill 388 266 599 389 266 599 minecraft:purple_concrete
fill 389 266 557 390 266 557 minecraft:purple_concrete
fill 390 266 599 390 271 599 minecraft:black_concrete
fill 396 266 599 397 267 599 minecraft:purple_concrete
fill 398 266 599 399 271 599 minecraft:black_concrete
fill 399 266 557 400 271 557 minecraft:black_concrete
fill 401 266 557 402 267 557 minecraft:purple_concrete
setblock 405 266 590 minecraft:purple_concrete
fill 406 266 588 406 267 588 minecraft:purple_concrete
fill 406 266 591 407 266 591 minecraft:purple_concrete
fill 408 266 557 408 271 557 minecraft:black_concrete
fill 408 266 585 411 269 585 minecraft:purple_concrete
fill 408 266 599 409 266 599 minecraft:purple_concrete
fill 409 266 557 410 266 557 minecraft:purple_concrete
fill 410 266 584 410 269 584 minecraft:purple_concrete
fill 410 266 599 411 271 599 minecraft:black_concrete
fill 411 266 557 411 271 557 minecraft:black_concrete
fill 412 266 586 412 270 587 minecraft:purple_concrete
fill 413 266 557 413 267 557 minecraft:purple_concrete
fill 417 266 599 417 267 599 minecraft:purple_concrete
fill 418 266 558 418 271 559 minecraft:black_concrete
fill 418 266 560 418 267 561 minecraft:purple_concrete
setblock 418 266 569 minecraft:purple_concrete
fill 418 266 570 418 271 571 minecraft:black_concrete
fill 418 266 572 418 267 573 minecraft:purple_concrete
fill 418 266 578 418 271 579 minecraft:black_concrete
fill 418 266 580 418 266 581 minecraft:purple_concrete
fill 418 266 582 418 271 582 minecraft:black_concrete
fill 418 266 590 418 271 591 minecraft:black_concrete
fill 418 266 592 418 267 593 minecraft:purple_concrete
fill 418 266 599 418 271 599 minecraft:black_concrete
fill 376 267 559 376 269 560 minecraft:black_concrete
fill 376 267 575 376 267 576 minecraft:purple_concrete
setblock 376 267 579 minecraft:purple_concrete
fill 376 267 580 376 270 580 minecraft:black_concrete
fill 376 267 591 376 270 591 minecraft:black_concrete
fill 376 267 595 376 269 595 minecraft:black_concrete
setblock 376 267 596 minecraft:purple_concrete
fill 378 267 557 378 270 557 minecraft:black_concrete
setblock 382 267 557 minecraft:purple_concrete
setblock 384 267 599 minecraft:purple_concrete
fill 388 267 599 389 270 599 minecraft:black_concrete
fill 389 267 557 389 270 557 minecraft:black_concrete
setblock 390 267 557 minecraft:purple_concrete
setblock 393 267 557 minecraft:purple_concrete
setblock 405 267 599 minecraft:purple_concrete
fill 406 267 590 406 270 590 minecraft:amethyst_block
fill 407 267 587 407 268 587 minecraft:purple_concrete
fill 407 267 590 409 267 590 minecraft:purple_concrete
setblock 408 267 599 minecraft:purple_concrete
fill 409 267 557 410 270 557 minecraft:black_concrete
fill 409 267 584 409 271 584 minecraft:purple_concrete
fill 409 267 588 409 268 589 minecraft:purple_concrete
fill 409 267 599 409 270 599 minecraft:black_concrete
fill 410 267 583 411 268 583 minecraft:purple_concrete
fill 411 267 584 412 268 584 minecraft:purple_concrete
fill 412 267 582 413 267 583 minecraft:amethyst_block
fill 412 267 585 412 269 585 minecraft:purple_concrete
fill 412 267 588 412 268 588 minecraft:purple_concrete
setblock 414 267 557 minecraft:purple_concrete
setblock 416 267 599 minecraft:purple_concrete
setblock 418 267 564 minecraft:purple_concrete
fill 418 267 569 418 270 569 minecraft:black_concrete
fill 418 267 580 418 270 580 minecraft:black_concrete
setblock 418 267 581 minecraft:purple_concrete
fill 418 267 584 418 267 585 minecraft:purple_concrete
setblock 376 268 557 minecraft:purple_concrete
fill 376 268 565 376 269 566 minecraft:purple_concrete
fill 376 268 567 376 285 568 minecraft:black_concrete
fill 376 268 574 376 269 574 minecraft:purple_concrete
fill 376 268 575 376 269 576 minecraft:black_concrete
fill 376 268 577 376 268 578 minecraft:purple_concrete
fill 376 268 579 376 285 579 minecraft:black_concrete
fill 376 268 585 376 269 586 minecraft:purple_concrete
fill 376 268 587 376 286 588 minecraft:black_concrete
fill 376 268 596 376 289 596 minecraft:black_concrete
fill 376 268 597 376 268 598 minecraft:purple_concrete
fill 376 268 599 377 285 599 minecraft:black_concrete
setblock 379 268 560 minecraft:light[level=12]
setblock 379 268 568 minecraft:light[level=12]
setblock 379 268 576 minecraft:light[level=12]
setblock 379 268 584 minecraft:light[level=12]
setblock 379 268 592 minecraft:light[level=12]
fill 381 268 557 382 286 557 minecraft:black_concrete
fill 382 268 599 383 269 599 minecraft:purple_concrete
fill 383 268 557 384 269 557 minecraft:purple_concrete
fill 384 268 599 385 286 599 minecraft:black_concrete
setblock 386 268 599 minecraft:purple_concrete
setblock 387 268 560 minecraft:light[level=12]
setblock 387 268 568 minecraft:light[level=12]
setblock 387 268 576 minecraft:light[level=12]
setblock 387 268 584 minecraft:light[level=12]
setblock 387 268 592 minecraft:light[level=12]
fill 390 268 557 390 285 557 minecraft:black_concrete
fill 391 268 557 392 268 557 minecraft:purple_concrete
fill 393 268 557 393 289 557 minecraft:black_concrete
fill 394 268 599 395 269 599 minecraft:purple_concrete
fill 395 268 557 395 269 557 minecraft:purple_concrete
setblock 395 268 560 minecraft:light[level=12]
setblock 395 268 568 minecraft:light[level=12]
setblock 395 268 584 minecraft:light[level=12]
setblock 395 268 592 minecraft:light[level=12]
fill 396 268 599 397 285 599 minecraft:black_concrete
fill 401 268 557 402 285 557 minecraft:black_concrete
fill 403 268 557 404 269 557 minecraft:purple_concrete
setblock 403 268 560 minecraft:light[level=12]
setblock 403 268 568 minecraft:light[level=12]
setblock 403 268 576 minecraft:light[level=12]
setblock 403 268 584 minecraft:light[level=12]
setblock 403 268 592 minecraft:light[level=12]
fill 403 268 599 403 269 599 minecraft:purple_concrete
fill 405 268 599 405 289 599 minecraft:black_concrete
fill 406 268 599 407 268 599 minecraft:purple_concrete
fill 407 268 589 408 268 589 minecraft:purple_concrete
fill 407 268 590 407 270 590 minecraft:amethyst_block
fill 408 268 586 411 269 586 minecraft:purple_concrete
fill 408 268 599 408 285 599 minecraft:black_concrete
fill 409 268 583 409 271 583 minecraft:purple_concrete
fill 410 268 588 410 268 589 minecraft:purple_concrete
setblock 411 268 560 minecraft:light[level=12]
setblock 411 268 568 minecraft:light[level=12]
setblock 411 268 576 minecraft:light[level=12]
fill 411 268 582 412 268 582 minecraft:purple_concrete
setblock 411 268 592 minecraft:light[level=12]
setblock 412 268 557 minecraft:purple_concrete
fill 412 268 583 413 268 583 minecraft:purple_concrete
fill 413 268 557 414 286 557 minecraft:black_concrete
setblock 413 268 582 minecraft:amethyst_block
fill 413 268 584 413 268 586 minecraft:purple_concrete
fill 414 268 599 415 269 599 minecraft:purple_concrete
fill 415 268 557 416 269 557 minecraft:purple_concrete
fill 416 268 599 417 286 599 minecraft:black_concrete
fill 418 268 560 418 285 561 minecraft:black_concrete
fill 418 268 562 418 268 563 minecraft:purple_concrete
fill 418 268 564 418 289 564 minecraft:black_concrete
fill 418 268 572 418 286 573 minecraft:black_concrete
fill 418 268 574 418 269 575 minecraft:purple_concrete
fill 418 268 581 418 285 581 minecraft:black_concrete
setblock 418 268 583 minecraft:purple_concrete
fill 418 268 584 418 289 585 minecraft:black_concrete
fill 418 268 586 418 269 586 minecraft:purple_concrete
fill 418 268 592 418 285 593 minecraft:black_concrete
fill 418 268 594 418 268 595 minecraft:purple_concrete
fill 376 269 557 376 271 557 minecraft:black_concrete
setblock 376 269 562 minecraft:purple_concrete
setblock 376 269 573 minecraft:purple_concrete
fill 376 269 577 376 271 578 minecraft:black_concrete
fill 376 269 593 376 269 594 minecraft:purple_concrete
setblock 376 269 597 minecraft:purple_concrete
fill 376 269 598 376 272 598 minecraft:black_concrete
fill 386 269 599 386 272 599 minecraft:black_concrete
fill 391 269 557 392 272 557 minecraft:black_concrete
setblock 391 269 599 minecraft:purple_concrete
setblock 396 269 557 minecraft:purple_concrete
setblock 402 269 599 minecraft:purple_concrete
fill 406 269 599 407 272 599 minecraft:black_concrete
setblock 407 269 557 minecraft:purple_concrete
fill 409 269 588 411 269 588 minecraft:purple_concrete
fill 410 269 582 413 273 583 minecraft:black_concrete
fill 411 269 581 413 273 581 minecraft:black_concrete
fill 411 269 584 413 273 584 minecraft:black_concrete
fill 411 269 587 411 270 587 minecraft:purple_concrete
fill 412 269 557 412 272 557 minecraft:black_concrete
fill 413 269 585 413 270 586 minecraft:purple_concrete
fill 418 269 562 418 272 562 minecraft:black_concrete
setblock 418 269 563 minecraft:purple_concrete
fill 418 269 566 418 269 567 minecraft:purple_concrete
fill 418 269 583 418 272 583 minecraft:black_concrete
setblock 418 269 587 minecraft:purple_concrete
fill 418 269 594 418 272 594 minecraft:black_concrete
setblock 418 269 595 minecraft:purple_concrete
setblock 418 269 598 minecraft:purple_concrete
setblock 376 270 559 minecraft:black_concrete
fill 376 270 560 376 271 560 minecraft:purple_concrete
fill 376 270 562 376 283 562 minecraft:black_concrete
fill 376 270 563 376 270 564 minecraft:purple_concrete
fill 376 270 565 376 272 566 minecraft:black_concrete
fill 376 270 571 376 271 572 minecraft:purple_concrete
fill 376 270 573 376 283 574 minecraft:black_concrete
setblock 376 270 575 minecraft:purple_concrete
fill 376 270 576 376 289 576 minecraft:black_concrete
fill 376 270 583 376 271 584 minecraft:purple_concrete
fill 376 270 585 376 283 586 minecraft:black_concrete
fill 376 270 592 376 271 592 minecraft:purple_concrete
fill 376 270 593 376 283 594 minecraft:black_concrete
setblock 376 270 595 minecraft:purple_concrete
fill 376 270 597 376 287 597 minecraft:black_concrete
fill 377 270 557 377 271 557 minecraft:purple_concrete
fill 377 270 558 379 270 558 minecraft:obsidian
fill 377 270 560 377 270 562 minecraft:obsidian
fill 377 270 564 377 270 566 minecraft:obsidian
fill 377 270 568 377 270 570 minecraft:obsidian
fill 377 270 572 377 270 574 minecraft:obsidian
fill 377 270 576 377 270 578 minecraft:obsidian
fill 377 270 580 377 270 582 minecraft:obsidian
fill 377 270 584 377 270 586 minecraft:obsidian
fill 377 270 588 377 270 590 minecraft:obsidian
fill 377 270 592 377 270 594 minecraft:obsidian
fill 377 270 596 377 270 598 minecraft:obsidian
fill 379 270 598 381 270 598 minecraft:obsidian
fill 380 270 599 381 271 599 minecraft:purple_concrete
fill 381 270 558 383 270 558 minecraft:obsidian
fill 382 270 599 383 283 599 minecraft:black_concrete
fill 383 270 557 384 283 557 minecraft:black_concrete
fill 383 270 598 385 270 598 minecraft:obsidian
fill 385 270 557 386 271 557 minecraft:purple_concrete
fill 385 270 558 387 270 558 minecraft:obsidian
fill 387 270 598 389 270 598 minecraft:obsidian
fill 389 270 558 391 270 558 minecraft:obsidian
fill 391 270 598 393 270 598 minecraft:obsidian
fill 391 270 599 391 283 599 minecraft:black_concrete
fill 392 270 599 393 270 599 minecraft:purple_concrete
fill 393 270 558 395 270 558 minecraft:obsidian
setblock 394 270 557 minecraft:purple_concrete
fill 394 270 599 395 287 599 minecraft:black_concrete
fill 395 270 557 396 283 557 minecraft:black_concrete
fill 395 270 598 397 270 598 minecraft:obsidian
fill 397 270 557 398 271 557 minecraft:purple_concrete
fill 397 270 558 399 270 558 minecraft:obsidian
fill 399 270 598 401 270 598 minecraft:obsidian
fill 400 270 599 401 271 599 minecraft:purple_concrete
fill 401 270 558 403 270 558 minecraft:obsidian
fill 402 270 599 403 283 599 minecraft:black_concrete
fill 403 270 557 404 287 557 minecraft:black_concrete
fill 403 270 598 405 270 598 minecraft:obsidian
setblock 404 270 599 minecraft:purple_concrete
fill 405 270 557 406 270 557 minecraft:purple_concrete
fill 405 270 558 407 270 558 minecraft:obsidian
fill 407 270 557 407 283 557 minecraft:black_concrete
fill 407 270 598 409 270 598 minecraft:obsidian
fill 409 270 558 411 270 558 minecraft:obsidian
setblock 409 270 582 minecraft:purple_concrete
fill 409 270 585 410 270 586 minecraft:purple_concrete
fill 410 270 581 410 273 581 minecraft:black_concrete
fill 410 270 584 410 272 584 minecraft:black_concrete
fill 411 270 580 413 273 580 minecraft:black_concrete
fill 411 270 585 412 272 585 minecraft:black_concrete
fill 411 270 586 411 271 586 minecraft:purple_concrete
fill 411 270 598 413 270 598 minecraft:obsidian
fill 412 270 599 413 271 599 minecraft:purple_concrete
fill 413 270 558 415 270 558 minecraft:obsidian
fill 414 270 581 414 271 584 minecraft:black_concrete
fill 414 270 599 415 283 599 minecraft:black_concrete
fill 415 270 557 416 283 557 minecraft:black_concrete
fill 415 270 598 417 270 598 minecraft:obsidian
fill 417 270 557 418 271 557 minecraft:purple_concrete
fill 417 270 558 417 270 560 minecraft:obsidian
fill 417 270 562 417 270 564 minecraft:obsidian
fill 417 270 566 417 270 568 minecraft:obsidian
fill 417 270 570 417 270 572 minecraft:obsidian
fill 417 270 574 417 270 576 minecraft:obsidian
fill 417 270 578 417 270 580 minecraft:obsidian
fill 417 270 582 417 270 584 minecraft:obsidian
fill 417 270 586 417 270 588 minecraft:obsidian
fill 417 270 590 417 270 592 minecraft:obsidian
fill 417 270 594 417 270 596 minecraft:obsidian
fill 418 270 563 418 287 563 minecraft:black_concrete
setblock 418 270 565 minecraft:purple_concrete
fill 418 270 566 418 283 567 minecraft:black_concrete
fill 418 270 568 418 271 568 minecraft:purple_concrete
fill 418 270 574 418 283 575 minecraft:black_concrete
fill 418 270 576 418 270 577 minecraft:purple_concrete
fill 418 270 586 418 283 587 minecraft:black_concrete
fill 418 270 588 418 271 589 minecraft:purple_concrete
fill 418 270 595 418 287 595 minecraft:black_concrete
fill 418 270 596 418 270 597 minecraft:purple_concrete
fill 418 270 598 418 283 598 minecraft:black_concrete
setblock 376 271 559 minecraft:purple_concrete
setblock 376 271 563 minecraft:purple_concrete
fill 376 271 564 376 289 564 minecraft:black_concrete
fill 376 271 575 376 289 575 minecraft:black_concrete
setblock 376 271 580 minecraft:purple_concrete
setblock 376 271 591 minecraft:purple_concrete
fill 376 271 595 376 289 595 minecraft:black_concrete
setblock 378 271 557 minecraft:purple_concrete
fill 388 271 599 389 271 599 minecraft:purple_concrete
setblock 389 271 557 minecraft:purple_concrete
setblock 392 271 599 minecraft:purple_concrete
fill 393 271 599 393 289 599 minecraft:black_concrete
fill 394 271 557 394 289 557 minecraft:black_concrete
fill 404 271 599 404 289 599 minecraft:black_concrete
fill 405 271 557 405 289 557 minecraft:black_concrete
setblock 406 271 557 minecraft:purple_concrete
fill 409 271 557 410 271 557 minecraft:purple_concrete
fill 409 271 585 410 271 585 minecraft:purple_concrete
setblock 409 271 599 minecraft:purple_concrete
fill 410 271 580 410 273 580 minecraft:black_concrete
setblock 410 271 586 minecraft:purple_concrete
fill 411 271 579 413 273 579 minecraft:black_concrete
fill 412 271 578 412 273 578 minecraft:black_concrete
setblock 412 271 586 minecraft:purple_concrete
setblock 413 271 585 minecraft:black_concrete
fill 414 271 580 414 273 580 minecraft:black_concrete
fill 418 271 565 418 289 565 minecraft:black_concrete
setblock 418 271 569 minecraft:purple_concrete
fill 418 271 576 418 289 576 minecraft:black_concrete
setblock 418 271 577 minecraft:purple_concrete
setblock 418 271 580 minecraft:purple_concrete
fill 418 271 596 418 289 597 minecraft:black_concrete
fill 376 272 557 376 273 558 minecraft:purple_concrete
fill 376 272 559 376 285 560 minecraft:black_concrete
setblock 376 272 561 minecraft:purple_concrete
fill 376 272 563 376 289 563 minecraft:black_concrete
fill 376 272 569 376 273 570 minecraft:purple_concrete
fill 376 272 571 376 285 572 minecraft:black_concrete
setblock 376 272 577 minecraft:black_concrete
fill 376 272 578 376 273 578 minecraft:purple_concrete
fill 376 272 580 376 285 580 minecraft:black_concrete
fill 376 272 581 376 272 582 minecraft:purple_concrete
fill 376 272 583 376 289 584 minecraft:black_concrete
fill 376 272 589 376 273 590 minecraft:purple_concrete
fill 376 272 591 376 285 592 minecraft:black_concrete
fill 377 272 557 378 285 557 minecraft:black_concrete
fill 378 272 599 379 272 599 minecraft:purple_concrete
fill 379 272 557 380 273 557 minecraft:purple_concrete
fill 380 272 599 381 285 599 minecraft:black_concrete
fill 385 272 557 386 289 557 minecraft:black_concrete
fill 387 272 557 388 272 557 minecraft:purple_concrete
fill 387 272 599 387 273 599 minecraft:purple_concrete
fill 388 272 599 389 285 599 minecraft:black_concrete
fill 389 272 557 389 285 557 minecraft:black_concrete
setblock 390 272 599 minecraft:purple_concrete
fill 392 272 599 392 289 599 minecraft:black_concrete
fill 397 272 557 398 285 557 minecraft:black_concrete
fill 398 272 599 399 273 599 minecraft:purple_concrete
fill 399 272 557 400 273 557 minecraft:purple_concrete
fill 400 272 599 401 285 599 minecraft:black_concrete
fill 406 272 557 406 289 557 minecraft:black_concrete
setblock 408 272 557 minecraft:purple_concrete
fill 408 272 571 408 273 571 minecraft:amethyst_block
fill 409 272 557 410 285 557 minecraft:black_concrete
fill 409 272 599 409 285 599 minecraft:black_concrete
fill 410 272 579 410 273 579 minecraft:black_concrete
setblock 410 272 585 minecraft:purple_concrete
fill 410 272 599 411 272 599 minecraft:purple_concrete
fill 411 272 557 411 273 557 minecraft:purple_concrete
fill 411 272 578 411 273 578 minecraft:black_concrete
fill 412 272 577 413 273 577 minecraft:black_concrete
fill 412 272 599 413 289 599 minecraft:black_concrete
fill 413 272 578 414 273 578 minecraft:black_concrete
fill 414 272 579 414 273 579 minecraft:black_concrete
fill 414 272 581 414 272 583 minecraft:black_concrete
fill 417 272 557 418 285 557 minecraft:black_concrete
fill 418 272 558 418 272 559 minecraft:purple_concrete
fill 418 272 568 418 285 569 minecraft:black_concrete
fill 418 272 570 418 273 571 minecraft:purple_concrete
fill 418 272 577 418 289 577 minecraft:black_concrete
fill 418 272 578 418 272 579 minecraft:purple_concrete
fill 418 272 580 418 285 580 minecraft:black_concrete
fill 418 272 582 418 273 582 minecraft:purple_concrete
fill 418 272 588 418 285 589 minecraft:black_concrete
fill 418 272 590 418 273 591 minecraft:purple_concrete
fill 418 272 599 418 273 599 minecraft:purple_concrete
fill 376 273 561 376 283 561 minecraft:black_concrete
fill 376 273 565 376 287 565 minecraft:black_concrete
setblock 376 273 566 minecraft:purple_concrete
setblock 376 273 577 minecraft:purple_concrete
setblock 376 273 581 minecraft:purple_concrete
fill 376 273 582 376 283 582 minecraft:black_concrete
setblock 376 273 598 minecraft:purple_concrete
setblock 378 273 599 minecraft:purple_concrete
fill 379 273 599 379 283 599 minecraft:black_concrete
setblock 386 273 599 minecraft:purple_concrete
fill 387 273 557 387 283 557 minecraft:black_concrete
setblock 388 273 557 minecraft:purple_concrete
fill 390 273 599 390 283 599 minecraft:black_concrete
fill 391 273 557 392 273 557 minecraft:purple_concrete
fill 406 273 599 407 273 599 minecraft:purple_concrete
fill 408 273 557 408 283 557 minecraft:black_concrete
setblock 410 273 578 minecraft:black_concrete
setblock 410 273 599 minecraft:purple_concrete
setblock 411 273 577 minecraft:black_concrete
fill 411 273 599 411 283 599 minecraft:black_concrete
setblock 412 273 557 minecraft:purple_concrete
fill 412 273 576 413 273 576 minecraft:black_concrete
setblock 414 273 577 minecraft:black_concrete
fill 414 273 581 414 273 582 minecraft:black_concrete
fill 415 273 579 415 273 580 minecraft:black_concrete
fill 418 273 558 418 283 558 minecraft:black_concrete
setblock 418 273 559 minecraft:purple_concrete
setblock 418 273 562 minecraft:purple_concrete
fill 418 273 578 418 283 579 minecraft:black_concrete
setblock 418 273 583 minecraft:purple_concrete
setblock 418 273 594 minecraft:purple_concrete
fill 376 274 557 376 287 558 minecraft:black_concrete
fill 376 274 566 376 287 566 minecraft:black_concrete
fill 376 274 569 376 284 570 minecraft:black_concrete
fill 376 274 577 376 287 578 minecraft:black_concrete
fill 376 274 581 376 283 581 minecraft:black_concrete
fill 376 274 589 376 284 590 minecraft:black_concrete
fill 376 274 598 376 287 598 minecraft:black_concrete
fill 378 274 599 378 284 599 minecraft:black_concrete
fill 379 274 557 380 284 557 minecraft:black_concrete
fill 386 274 599 387 287 599 minecraft:black_concrete
fill 388 274 557 388 284 557 minecraft:black_concrete
fill 391 274 557 392 287 557 minecraft:black_concrete
fill 398 274 599 399 284 599 minecraft:black_concrete
fill 399 274 557 400 284 557 minecraft:black_concrete
fill 406 274 599 407 287 599 minecraft:black_concrete
fill 410 274 599 410 284 599 minecraft:black_concrete
fill 411 274 557 412 287 557 minecraft:black_concrete
fill 418 274 559 418 284 559 minecraft:black_concrete
fill 418 274 562 418 287 562 minecraft:black_concrete
fill 418 274 570 418 284 571 minecraft:black_concrete
fill 418 274 582 418 287 583 minecraft:black_concrete
fill 418 274 590 418 284 591 minecraft:black_concrete
fill 418 274 594 418 287 594 minecraft:black_concrete
fill 418 274 599 418 287 599 minecraft:black_concrete
setblock 379 276 560 minecraft:light[level=12]
setblock 379 276 568 minecraft:light[level=12]
setblock 379 276 576 minecraft:light[level=12]
setblock 379 276 584 minecraft:light[level=12]
setblock 379 276 592 minecraft:light[level=12]
setblock 387 276 560 minecraft:light[level=12]
setblock 387 276 568 minecraft:light[level=12]
setblock 387 276 576 minecraft:light[level=12]
setblock 387 276 584 minecraft:light[level=12]
setblock 387 276 592 minecraft:light[level=12]
setblock 395 276 560 minecraft:light[level=12]
setblock 395 276 568 minecraft:light[level=12]
setblock 395 276 584 minecraft:light[level=12]
setblock 395 276 592 minecraft:light[level=12]
setblock 403 276 560 minecraft:light[level=12]
setblock 403 276 568 minecraft:light[level=12]
setblock 403 276 576 minecraft:light[level=12]
setblock 403 276 584 minecraft:light[level=12]
setblock 403 276 592 minecraft:light[level=12]
setblock 411 276 560 minecraft:light[level=12]
setblock 411 276 568 minecraft:light[level=12]
setblock 411 276 576 minecraft:light[level=12]
setblock 411 276 584 minecraft:light[level=12]
setblock 411 276 592 minecraft:light[level=12]
fill 381 279 576 392 279 576 minecraft:black_concrete
fill 383 279 575 393 279 575 minecraft:black_concrete
fill 383 279 577 393 279 577 minecraft:black_concrete
fill 384 279 574 394 279 574 minecraft:black_concrete
fill 384 279 578 394 279 578 minecraft:black_concrete
fill 387 279 573 403 279 573 minecraft:black_concrete
fill 387 279 579 403 279 579 minecraft:black_concrete
fill 388 279 564 388 280 569 minecraft:black_concrete
fill 388 279 583 388 280 588 minecraft:black_concrete
fill 389 279 565 390 279 572 minecraft:black_concrete
fill 389 279 580 390 279 587 minecraft:black_concrete
fill 391 279 566 392 279 572 minecraft:black_concrete
fill 391 279 580 392 279 586 minecraft:black_concrete
fill 393 279 567 393 279 572 minecraft:black_concrete
fill 393 279 580 393 279 585 minecraft:black_concrete
fill 394 279 568 394 279 572 minecraft:black_concrete
fill 394 279 580 394 279 584 minecraft:black_concrete
fill 395 279 570 401 279 572 minecraft:black_concrete
fill 395 279 580 401 279 582 minecraft:black_concrete
fill 396 279 568 402 279 569 minecraft:black_concrete
fill 396 279 574 406 279 574 minecraft:black_concrete
fill 396 279 578 406 279 578 minecraft:black_concrete
fill 396 279 583 402 279 584 minecraft:black_concrete
fill 397 279 567 402 280 567 minecraft:black_concrete
fill 397 279 575 407 279 575 minecraft:black_concrete
fill 397 279 577 407 279 577 minecraft:black_concrete
fill 397 279 585 402 280 585 minecraft:black_concrete
fill 398 279 566 402 280 566 minecraft:black_concrete
fill 398 279 576 409 279 576 minecraft:black_concrete
fill 398 279 586 402 280 586 minecraft:black_concrete
fill 400 279 565 402 280 565 minecraft:black_concrete
fill 400 279 587 402 280 587 minecraft:black_concrete
fill 402 279 564 402 280 564 minecraft:black_concrete
fill 402 279 588 402 280 588 minecraft:black_concrete
fill 377 280 558 380 280 598 minecraft:obsidian
fill 381 280 558 382 280 575 minecraft:obsidian
fill 381 280 576 385 280 576 minecraft:black_concrete
fill 381 280 577 382 280 598 minecraft:obsidian
fill 383 280 558 383 280 574 minecraft:obsidian
fill 383 280 575 386 280 575 minecraft:black_concrete
fill 383 280 577 386 280 577 minecraft:black_concrete
fill 383 280 578 383 280 598 minecraft:obsidian
fill 384 280 558 386 280 573 minecraft:obsidian
fill 384 280 574 388 280 574 minecraft:black_concrete
fill 384 280 578 388 280 578 minecraft:black_concrete
fill 384 280 579 386 280 598 minecraft:obsidian
fill 386 280 576 390 280 576 minecraft:purple_concrete
fill 387 280 558 387 280 572 minecraft:obsidian
fill 387 280 573 390 280 573 minecraft:black_concrete
fill 387 280 575 391 280 575 minecraft:purple_concrete
fill 387 280 577 391 280 577 minecraft:purple_concrete
fill 387 280 579 390 280 579 minecraft:black_concrete
fill 387 280 580 387 280 598 minecraft:obsidian
fill 388 280 558 417 280 563 minecraft:obsidian
fill 388 280 570 388 280 572 minecraft:obsidian
fill 388 280 580 388 280 582 minecraft:obsidian
fill 388 280 589 417 280 598 minecraft:obsidian
fill 389 280 564 401 280 564 minecraft:obsidian
fill 389 280 565 389 280 572 minecraft:black_concrete
fill 389 280 574 391 280 574 minecraft:purple_concrete
fill 389 280 578 391 280 578 minecraft:purple_concrete
fill 389 280 580 389 280 587 minecraft:black_concrete
fill 389 280 588 401 280 588 minecraft:obsidian
fill 390 280 565 390 280 567 minecraft:black_concrete
fill 390 280 568 391 280 571 minecraft:purple_concrete
setblock 390 280 572 minecraft:black_concrete
setblock 390 280 580 minecraft:black_concrete
fill 390 280 581 391 280 584 minecraft:purple_concrete
fill 390 280 585 390 280 587 minecraft:black_concrete
fill 391 280 565 399 280 565 minecraft:obsidian
fill 391 280 566 392 280 567 minecraft:black_concrete
fill 391 280 572 392 280 573 minecraft:purple_concrete
setblock 391 280 576 minecraft:amethyst_block
fill 391 280 579 392 280 580 minecraft:purple_concrete
fill 391 280 585 392 280 586 minecraft:black_concrete
fill 391 280 587 399 280 587 minecraft:obsidian
fill 392 280 568 394 280 568 minecraft:black_concrete
fill 392 280 569 392 280 571 minecraft:purple_concrete
setblock 392 280 574 minecraft:amethyst_block
fill 392 280 575 392 280 577 minecraft:crying_obsidian
setblock 392 280 578 minecraft:amethyst_block
fill 392 280 581 392 280 583 minecraft:purple_concrete
fill 392 280 584 394 280 584 minecraft:black_concrete
fill 393 280 566 397 280 566 minecraft:obsidian
setblock 393 280 567 minecraft:black_concrete
fill 393 280 569 394 280 569 minecraft:black_concrete
fill 393 280 570 394 280 572 minecraft:purple_concrete
setblock 393 280 573 minecraft:amethyst_block
fill 393 280 574 393 280 575 minecraft:crying_obsidian
fill 393 280 577 393 280 578 minecraft:crying_obsidian
setblock 393 280 579 minecraft:amethyst_block
fill 393 280 580 394 280 582 minecraft:purple_concrete
fill 393 280 583 394 280 583 minecraft:black_concrete
setblock 393 280 585 minecraft:black_concrete
fill 393 280 586 397 280 586 minecraft:obsidian
fill 394 280 567 396 280 567 minecraft:obsidian
fill 394 280 573 394 280 574 minecraft:crying_obsidian
fill 394 280 578 394 280 579 minecraft:crying_obsidian
fill 394 280 585 396 280 585 minecraft:obsidian
fill 395 280 568 395 280 569 minecraft:obsidian
fill 395 280 570 395 280 571 minecraft:black_concrete
setblock 395 280 572 minecraft:amethyst_block
fill 395 280 573 396 280 573 minecraft:crying_obsidian
fill 395 280 579 396 280 579 minecraft:crying_obsidian
setblock 395 280 580 minecraft:amethyst_block
fill 395 280 581 395 280 582 minecraft:black_concrete
fill 395 280 583 395 280 584 minecraft:obsidian
fill 396 280 568 397 280 569 minecraft:black_concrete
fill 396 280 570 399 280 572 minecraft:purple_concrete
fill 396 280 574 397 280 574 minecraft:crying_obsidian
fill 396 280 578 397 280 578 minecraft:crying_obsidian
fill 396 280 580 399 280 582 minecraft:purple_concrete
fill 396 280 583 397 280 584 minecraft:black_concrete
setblock 397 280 573 minecraft:amethyst_block
fill 397 280 575 398 280 575 minecraft:crying_obsidian
fill 397 280 577 398 280 577 minecraft:crying_obsidian
setblock 397 280 579 minecraft:amethyst_block
setblock 398 280 568 minecraft:black_concrete
fill 398 280 569 400 280 569 minecraft:purple_concrete
fill 398 280 573 399 280 573 minecraft:purple_concrete
setblock 398 280 574 minecraft:amethyst_block
setblock 398 280 576 minecraft:crying_obsidian
setblock 398 280 578 minecraft:amethyst_block
fill 398 280 579 399 280 579 minecraft:purple_concrete
fill 398 280 583 400 280 583 minecraft:purple_concrete
setblock 398 280 584 minecraft:black_concrete
fill 399 280 568 400 280 568 minecraft:purple_concrete
fill 399 280 574 401 280 575 minecraft:purple_concrete
setblock 399 280 576 minecraft:amethyst_block
fill 399 280 577 401 280 578 minecraft:purple_concrete
fill 399 280 584 400 280 584 minecraft:purple_concrete
fill 400 280 570 400 280 571 minecraft:purple_concrete
fill 400 280 572 401 280 573 minecraft:black_concrete
fill 400 280 576 404 280 576 minecraft:purple_concrete
fill 400 280 579 401 280 580 minecraft:black_concrete
fill 400 280 581 400 280 582 minecraft:purple_concrete
fill 401 280 568 401 280 571 minecraft:black_concrete
fill 401 280 581 401 280 584 minecraft:black_concrete
fill 402 280 568 402 280 569 minecraft:black_concrete
fill 402 280 570 417 280 572 minecraft:obsidian
fill 402 280 573 403 280 574 minecraft:black_concrete
fill 402 280 575 403 280 575 minecraft:purple_concrete
fill 402 280 577 403 280 577 minecraft:purple_concrete
fill 402 280 578 403 280 579 minecraft:black_concrete
fill 402 280 580 417 280 582 minecraft:obsidian
fill 402 280 583 402 280 584 minecraft:black_concrete
fill 403 280 564 417 280 569 minecraft:obsidian
fill 403 280 583 417 280 588 minecraft:obsidian
fill 404 280 573 417 280 573 minecraft:obsidian
fill 404 280 574 406 280 575 minecraft:black_concrete
fill 404 280 577 406 280 578 minecraft:black_concrete
fill 404 280 579 417 280 579 minecraft:obsidian
fill 405 280 576 409 280 576 minecraft:black_concrete
fill 407 280 574 417 280 574 minecraft:obsidian
setblock 407 280 575 minecraft:black_concrete
setblock 407 280 577 minecraft:black_concrete
fill 407 280 578 417 280 578 minecraft:obsidian
fill 408 280 575 417 280 575 minecraft:obsidian
fill 408 280 577 417 280 577 minecraft:obsidian
fill 410 280 576 417 280 576 minecraft:obsidian
fill 376 284 561 376 285 562 minecraft:purple_concrete
fill 376 284 573 376 284 574 minecraft:purple_concrete
fill 376 284 581 376 285 582 minecraft:purple_concrete
setblock 376 284 585 minecraft:purple_concrete
fill 376 284 586 376 287 586 minecraft:black_concrete
fill 376 284 593 376 285 594 minecraft:purple_concrete
setblock 379 284 560 minecraft:light[level=12]
setblock 379 284 568 minecraft:light[level=12]
setblock 379 284 576 minecraft:light[level=12]
setblock 379 284 584 minecraft:light[level=12]
setblock 379 284 592 minecraft:light[level=12]
fill 379 284 599 379 285 599 minecraft:purple_concrete
fill 382 284 599 383 284 599 minecraft:purple_concrete
fill 383 284 557 383 287 557 minecraft:black_concrete
setblock 384 284 557 minecraft:purple_concrete
fill 387 284 557 387 285 557 minecraft:purple_concrete
setblock 387 284 560 minecraft:light[level=12]
setblock 387 284 568 minecraft:light[level=12]
setblock 387 284 576 minecraft:light[level=12]
setblock 387 284 584 minecraft:light[level=12]
setblock 387 284 592 minecraft:light[level=12]
fill 390 284 599 391 285 599 minecraft:purple_concrete
fill 395 284 557 396 284 557 minecraft:purple_concrete
setblock 395 284 560 minecraft:light[level=12]
setblock 395 284 568 minecraft:light[level=12]
setblock 395 284 584 minecraft:light[level=12]
setblock 395 284 592 minecraft:light[level=12]
fill 402 284 599 403 284 599 minecraft:purple_concrete
setblock 403 284 560 minecraft:light[level=12]
setblock 403 284 568 minecraft:light[level=12]
setblock 403 284 576 minecraft:light[level=12]
setblock 403 284 584 minecraft:light[level=12]
setblock 403 284 592 minecraft:light[level=12]
fill 404 284 569 412 284 574 minecraft:obsidian
fill 405 284 568 411 284 568 minecraft:obsidian
fill 405 284 575 411 284 575 minecraft:obsidian
fill 406 284 567 410 284 567 minecraft:obsidian
fill 406 284 576 410 284 576 minecraft:obsidian
fill 407 284 557 408 285 557 minecraft:purple_concrete
setblock 411 284 560 minecraft:light[level=12]
setblock 411 284 576 minecraft:light[level=12]
setblock 411 284 584 minecraft:light[level=12]
setblock 411 284 592 minecraft:light[level=12]
fill 411 284 599 411 285 599 minecraft:purple_concrete
fill 413 284 570 413 284 573 minecraft:obsidian
setblock 414 284 599 minecraft:purple_concrete
fill 415 284 557 416 284 557 minecraft:purple_concrete
fill 415 284 599 415 287 599 minecraft:black_concrete
fill 418 284 558 418 285 558 minecraft:purple_concrete
fill 418 284 566 418 285 567 minecraft:purple_concrete
fill 418 284 574 418 287 574 minecraft:black_concrete
setblock 418 284 575 minecraft:purple_concrete
fill 418 284 578 418 285 579 minecraft:purple_concrete
fill 418 284 586 418 284 587 minecraft:purple_concrete
fill 418 284 598 418 285 598 minecraft:purple_concrete
fill 376 285 569 376 285 570 minecraft:purple_concrete
setblock 376 285 573 minecraft:purple_concrete
fill 376 285 574 376 288 574 minecraft:black_concrete
fill 376 285 585 376 288 585 minecraft:black_concrete
fill 376 285 589 376 287 589 minecraft:black_concrete
setblock 376 285 590 minecraft:purple_concrete
setblock 378 285 599 minecraft:purple_concrete
setblock 379 285 557 minecraft:purple_concrete
fill 380 285 557 380 287 557 minecraft:black_concrete
fill 382 285 599 383 288 599 minecraft:black_concrete
fill 384 285 557 384 288 557 minecraft:black_concrete
setblock 388 285 557 minecraft:purple_concrete
fill 395 285 557 395 288 557 minecraft:black_concrete
setblock 396 285 557 minecraft:purple_concrete
fill 398 285 599 398 287 599 minecraft:black_concrete
setblock 399 285 557 minecraft:purple_concrete
setblock 399 285 599 minecraft:purple_concrete
fill 400 285 557 400 287 557 minecraft:black_concrete
setblock 402 285 599 minecraft:purple_concrete
fill 403 285 599 403 288 599 minecraft:black_concrete
fill 407 285 571 409 285 572 minecraft:amethyst_block
setblock 410 285 599 minecraft:purple_concrete
fill 414 285 599 414 288 599 minecraft:black_concrete
fill 415 285 557 416 288 557 minecraft:black_concrete
setblock 418 285 559 minecraft:purple_concrete
setblock 418 285 570 minecraft:purple_concrete
fill 418 285 571 418 287 571 minecraft:black_concrete
fill 418 285 575 418 288 575 minecraft:black_concrete
fill 418 285 586 418 288 586 minecraft:black_concrete
setblock 418 285 587 minecraft:purple_concrete
fill 418 285 590 418 285 591 minecraft:purple_concrete
fill 376 286 559 376 287 560 minecraft:purple_concrete
fill 376 286 561 376 291 562 minecraft:black_concrete
setblock 376 286 567 minecraft:black_concrete
fill 376 286 568 376 287 568 minecraft:purple_concrete
fill 376 286 569 376 291 570 minecraft:black_concrete
setblock 376 286 571 minecraft:purple_concrete
fill 376 286 572 376 289 573 minecraft:black_concrete
fill 376 286 579 376 287 580 minecraft:purple_concrete
fill 376 286 581 376 291 582 minecraft:black_concrete
fill 376 286 590 376 291 590 minecraft:black_concrete
fill 376 286 591 376 286 592 minecraft:purple_concrete
fill 376 286 593 376 291 594 minecraft:black_concrete
fill 376 286 599 377 287 599 minecraft:purple_concrete
fill 377 286 557 378 286 557 minecraft:purple_concrete
fill 378 286 599 379 291 599 minecraft:black_concrete
fill 379 286 557 379 287 557 minecraft:black_concrete
setblock 380 286 599 minecraft:purple_concrete
fill 381 286 599 381 289 599 minecraft:black_concrete
fill 387 286 557 388 291 557 minecraft:black_concrete
fill 388 286 599 389 287 599 minecraft:purple_concrete
fill 389 286 557 390 287 557 minecraft:purple_concrete
fill 390 286 599 391 291 599 minecraft:black_concrete
fill 396 286 557 396 291 557 minecraft:black_concrete
setblock 396 286 599 minecraft:black_concrete
fill 397 286 557 398 286 557 minecraft:purple_concrete
fill 397 286 599 397 287 599 minecraft:purple_concrete
fill 399 286 557 399 291 557 minecraft:black_concrete
fill 399 286 599 399 291 599 minecraft:black_concrete
fill 400 286 599 401 286 599 minecraft:purple_concrete
fill 401 286 557 401 287 557 minecraft:purple_concrete
setblock 402 286 557 minecraft:black_concrete
fill 402 286 599 402 291 599 minecraft:black_concrete
fill 407 286 557 408 291 557 minecraft:black_concrete
fill 408 286 571 409 286 572 minecraft:amethyst_block
fill 408 286 599 409 287 599 minecraft:purple_concrete
fill 409 286 557 410 287 557 minecraft:purple_concrete
fill 410 286 599 411 291 599 minecraft:black_concrete
fill 417 286 557 417 289 557 minecraft:black_concrete
setblock 418 286 557 minecraft:purple_concrete
fill 418 286 558 418 291 559 minecraft:black_concrete
fill 418 286 560 418 287 561 minecraft:purple_concrete
fill 418 286 566 418 291 567 minecraft:black_concrete
fill 418 286 568 418 286 569 minecraft:purple_concrete
fill 418 286 570 418 291 570 minecraft:black_concrete
fill 418 286 578 418 291 579 minecraft:black_concrete
fill 418 286 580 418 287 581 minecraft:purple_concrete
fill 418 286 587 418 289 588 minecraft:black_concrete
setblock 418 286 589 minecraft:purple_concrete
fill 418 286 590 418 291 591 minecraft:black_concrete
fill 418 286 592 418 287 592 minecraft:purple_concrete
setblock 418 286 593 minecraft:black_concrete
fill 418 286 598 418 291 598 minecraft:black_concrete
setblock 376 287 567 minecraft:purple_concrete
fill 376 287 571 376 290 571 minecraft:black_concrete
fill 376 287 587 376 287 588 minecraft:purple_concrete
setblock 376 287 591 minecraft:purple_concrete
fill 376 287 592 376 290 592 minecraft:black_concrete
fill 377 287 557 377 290 557 minecraft:black_concrete
setblock 378 287 557 minecraft:purple_concrete
fill 380 287 599 380 290 599 minecraft:black_concrete
fill 381 287 557 382 287 557 minecraft:purple_concrete
fill 384 287 599 384 289 599 minecraft:black_concrete
setblock 385 287 599 minecraft:purple_concrete
setblock 396 287 599 minecraft:purple_concrete
fill 397 287 557 398 290 557 minecraft:black_concrete
fill 400 287 599 401 290 599 minecraft:black_concrete
setblock 402 287 557 minecraft:purple_concrete
fill 408 287 571 408 287 572 minecraft:amethyst_block
setblock 413 287 557 minecraft:purple_concrete
fill 414 287 557 414 289 557 minecraft:black_concrete
fill 416 287 599 416 289 599 minecraft:black_concrete
setblock 417 287 599 minecraft:purple_concrete
fill 418 287 557 418 290 557 minecraft:black_concrete
fill 418 287 568 418 290 568 minecraft:black_concrete
setblock 418 287 569 minecraft:purple_concrete
fill 418 287 572 418 287 573 minecraft:purple_concrete
fill 418 287 589 418 290 589 minecraft:black_concrete
setblock 418 287 593 minecraft:purple_concrete
fill 376 288 557 376 288 558 minecraft:purple_concrete
fill 376 288 559 376 290 560 minecraft:black_concrete
fill 376 288 565 376 289 566 minecraft:purple_concrete
fill 376 288 567 376 293 568 minecraft:black_concrete
fill 376 288 577 376 288 578 minecraft:purple_concrete
fill 376 288 579 376 293 580 minecraft:black_concrete
fill 376 288 586 376 289 586 minecraft:purple_concrete
fill 376 288 587 376 293 588 minecraft:black_concrete
setblock 376 288 589 minecraft:purple_concrete
fill 376 288 591 376 293 591 minecraft:black_concrete
fill 376 288 597 376 289 598 minecraft:purple_concrete
fill 376 288 599 377 293 599 minecraft:black_concrete
fill 377 288 558 379 288 558 minecraft:obsidian
fill 377 288 560 377 288 562 minecraft:obsidian
fill 377 288 564 377 288 566 minecraft:obsidian
fill 377 288 568 377 288 570 minecraft:obsidian
fill 377 288 572 377 288 574 minecraft:obsidian
fill 377 288 576 377 288 578 minecraft:obsidian
fill 377 288 580 377 288 582 minecraft:obsidian
fill 377 288 584 377 288 586 minecraft:obsidian
fill 377 288 588 377 288 590 minecraft:obsidian
fill 377 288 592 377 288 594 minecraft:obsidian
fill 377 288 596 377 288 598 minecraft:obsidian
fill 378 288 557 378 293 557 minecraft:black_concrete
fill 379 288 557 380 288 557 minecraft:purple_concrete
fill 379 288 598 381 288 598 minecraft:obsidian
fill 381 288 557 382 289 557 minecraft:black_concrete
fill 381 288 558 383 288 558 minecraft:obsidian
fill 383 288 557 383 289 557 minecraft:purple_concrete
fill 383 288 598 385 288 598 minecraft:obsidian
fill 385 288 558 387 288 558 minecraft:obsidian
fill 385 288 599 385 293 599 minecraft:black_concrete
fill 386 288 599 387 288 599 minecraft:purple_concrete
fill 387 288 598 389 288 598 minecraft:obsidian
fill 388 288 599 389 293 599 minecraft:black_concrete
fill 389 288 557 390 293 557 minecraft:black_concrete
fill 389 288 558 391 288 558 minecraft:obsidian
fill 391 288 557 392 289 557 minecraft:purple_concrete
fill 391 288 598 393 288 598 minecraft:obsidian
fill 393 288 558 395 288 558 minecraft:obsidian
fill 394 288 599 395 289 599 minecraft:purple_concrete
fill 395 288 598 397 288 598 minecraft:obsidian
fill 396 288 599 397 293 599 minecraft:black_concrete
fill 397 288 558 399 288 558 minecraft:obsidian
setblock 398 288 599 minecraft:purple_concrete
fill 399 288 598 401 288 598 minecraft:obsidian
setblock 400 288 557 minecraft:purple_concrete
fill 401 288 557 402 293 557 minecraft:black_concrete
fill 401 288 558 403 288 558 minecraft:obsidian
fill 403 288 557 404 289 557 minecraft:purple_concrete
fill 403 288 598 405 288 598 minecraft:obsidian
fill 405 288 558 407 288 558 minecraft:obsidian
fill 406 288 599 407 289 599 minecraft:purple_concrete
fill 407 288 598 409 288 598 minecraft:obsidian
setblock 408 288 571 minecraft:amethyst_block
fill 408 288 599 409 293 599 minecraft:black_concrete
fill 409 288 557 410 293 557 minecraft:black_concrete
fill 409 288 558 411 288 558 minecraft:obsidian
fill 411 288 557 412 288 557 minecraft:purple_concrete
fill 411 288 598 413 288 598 minecraft:obsidian
fill 413 288 557 413 293 557 minecraft:black_concrete
fill 413 288 558 415 288 558 minecraft:obsidian
fill 415 288 598 417 288 598 minecraft:obsidian
fill 415 288 599 415 289 599 minecraft:purple_concrete
fill 417 288 558 417 288 560 minecraft:obsidian
fill 417 288 562 417 288 564 minecraft:obsidian
fill 417 288 566 417 288 568 minecraft:obsidian
fill 417 288 570 417 288 572 minecraft:obsidian
fill 417 288 574 417 288 576 minecraft:obsidian
fill 417 288 578 417 288 580 minecraft:obsidian
fill 417 288 582 417 288 584 minecraft:obsidian
fill 417 288 586 417 288 588 minecraft:obsidian
fill 417 288 590 417 288 592 minecraft:obsidian
fill 417 288 594 417 288 596 minecraft:obsidian
fill 417 288 599 417 293 599 minecraft:black_concrete
fill 418 288 560 418 293 561 minecraft:black_concrete
fill 418 288 562 418 289 563 minecraft:purple_concrete
fill 418 288 569 418 293 569 minecraft:black_concrete
setblock 418 288 571 minecraft:purple_concrete
fill 418 288 572 418 293 573 minecraft:black_concrete
fill 418 288 574 418 289 574 minecraft:purple_concrete
fill 418 288 580 418 293 581 minecraft:black_concrete
fill 418 288 582 418 288 583 minecraft:purple_concrete
fill 418 288 592 418 293 593 minecraft:black_concrete
fill 418 288 594 418 289 595 minecraft:purple_concrete
schedule function dropper:buildpart/140_5 1t
