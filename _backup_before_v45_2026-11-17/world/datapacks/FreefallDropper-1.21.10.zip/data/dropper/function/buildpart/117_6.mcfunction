setblock 454 213 503 minecraft:polished_blackstone_bricks
fill 454 213 504 454 216 504 minecraft:blackstone
fill 456 213 463 457 215 463 minecraft:blackstone
setblock 458 213 464 minecraft:polished_blackstone_bricks
setblock 458 213 504 minecraft:polished_blackstone_bricks
setblock 458 213 505 minecraft:blackstone
fill 459 213 464 459 216 464 minecraft:blackstone
fill 459 213 504 459 216 504 minecraft:blackstone
fill 463 213 463 463 215 463 minecraft:blackstone
setblock 463 213 464 minecraft:polished_blackstone_bricks
setblock 463 213 504 minecraft:polished_blackstone_bricks
fill 464 213 464 464 215 465 minecraft:blackstone
fill 464 213 500 464 215 500 minecraft:blackstone
setblock 464 213 503 minecraft:polished_blackstone_bricks
fill 464 213 504 464 216 504 minecraft:blackstone
fill 465 213 463 465 215 463 minecraft:blackstone
setblock 465 213 464 minecraft:soul_soil
fill 465 213 465 465 215 467 minecraft:blackstone
setblock 465 213 470 minecraft:soul_soil
fill 465 213 471 465 213 472 minecraft:blackstone
setblock 465 213 488 minecraft:blackstone
setblock 465 213 489 minecraft:soul_soil
fill 465 213 490 465 215 490 minecraft:blackstone
fill 465 213 495 465 215 497 minecraft:blackstone
setblock 465 213 498 minecraft:soul_soil
setblock 465 213 500 minecraft:soul_soil
fill 423 214 463 423 215 463 minecraft:blackstone
setblock 423 214 464 minecraft:soul_soil
setblock 423 214 473 minecraft:soul_soil
fill 423 214 474 423 215 475 minecraft:blackstone
setblock 423 214 481 minecraft:soul_soil
fill 423 214 484 423 215 484 minecraft:blackstone
fill 423 214 488 423 215 488 minecraft:blackstone
fill 423 214 493 423 215 493 minecraft:blackstone
fill 423 214 497 423 215 500 minecraft:blackstone
setblock 423 214 501 minecraft:soul_soil
fill 423 214 502 423 215 504 minecraft:blackstone
fill 424 214 464 424 216 464 minecraft:blackstone
setblock 424 214 497 minecraft:polished_blackstone_bricks
fill 424 214 498 424 217 498 minecraft:blackstone
setblock 424 214 502 minecraft:polished_blackstone_bricks
fill 424 214 503 424 217 503 minecraft:blackstone
setblock 425 214 463 minecraft:soul_soil
setblock 425 214 501 minecraft:polished_blackstone_bricks
fill 425 214 502 428 214 502 minecraft:blackstone
fill 425 214 504 426 214 504 minecraft:blackstone
setblock 425 214 505 minecraft:soul_soil
setblock 426 214 500 minecraft:polished_blackstone_bricks
fill 426 214 501 426 217 501 minecraft:blackstone
fill 426 214 505 427 215 505 minecraft:blackstone
setblock 427 214 464 minecraft:polished_blackstone_bricks
setblock 427 214 504 minecraft:polished_blackstone_bricks
fill 428 214 464 428 217 464 minecraft:blackstone
setblock 428 214 503 minecraft:polished_blackstone_bricks
fill 428 214 504 428 217 504 minecraft:blackstone
setblock 429 214 502 minecraft:polished_blackstone_bricks
fill 429 214 503 429 217 503 minecraft:blackstone
setblock 430 214 501 minecraft:polished_blackstone_bricks
fill 430 214 502 430 217 502 minecraft:blackstone
setblock 432 214 464 minecraft:polished_blackstone_bricks
setblock 432 214 504 minecraft:polished_blackstone_bricks
fill 433 214 464 433 217 464 minecraft:blackstone
setblock 433 214 503 minecraft:polished_blackstone_bricks
fill 433 214 504 433 217 504 minecraft:blackstone
setblock 434 214 502 minecraft:polished_blackstone_bricks
fill 434 214 503 434 217 503 minecraft:blackstone
fill 436 214 463 436 215 463 minecraft:blackstone
setblock 437 214 463 minecraft:soul_soil
setblock 437 214 504 minecraft:polished_blackstone_bricks
fill 443 214 463 443 215 463 minecraft:blackstone
fill 444 214 505 445 214 505 minecraft:soul_soil
setblock 447 214 464 minecraft:polished_blackstone_bricks
setblock 447 214 504 minecraft:polished_blackstone_bricks
fill 448 214 464 448 217 464 minecraft:blackstone
fill 448 214 504 448 217 504 minecraft:blackstone
setblock 450 214 465 minecraft:blackstone
setblock 451 214 465 minecraft:polished_blackstone_bricks
setblock 452 214 464 minecraft:polished_blackstone_bricks
fill 452 214 465 452 217 465 minecraft:blackstone
setblock 452 214 504 minecraft:polished_blackstone_bricks
fill 453 214 464 453 217 464 minecraft:blackstone
setblock 453 214 503 minecraft:polished_blackstone_bricks
fill 453 214 504 453 217 504 minecraft:blackstone
setblock 454 214 503 minecraft:blackstone
setblock 455 214 465 minecraft:blackstone
setblock 455 214 505 minecraft:soul_soil
setblock 457 214 464 minecraft:polished_blackstone_bricks
setblock 457 214 504 minecraft:polished_blackstone_bricks
fill 458 214 464 458 217 464 minecraft:blackstone
fill 458 214 504 458 217 504 minecraft:blackstone
fill 458 214 505 459 214 505 minecraft:soul_soil
setblock 462 214 464 minecraft:polished_blackstone_bricks
setblock 462 214 504 minecraft:polished_blackstone_bricks
fill 463 214 464 463 217 464 minecraft:blackstone
fill 463 214 504 463 217 504 minecraft:blackstone
setblock 464 214 502 minecraft:polished_blackstone_bricks
fill 464 214 503 464 217 503 minecraft:blackstone
fill 465 214 464 465 215 464 minecraft:blackstone
fill 465 214 470 465 215 471 minecraft:blackstone
setblock 465 214 472 minecraft:soul_soil
setblock 465 214 474 minecraft:soul_soil
fill 465 214 475 465 215 475 minecraft:blackstone
fill 465 214 479 465 216 479 minecraft:blackstone
setblock 465 214 488 minecraft:soul_soil
fill 465 214 489 465 215 489 minecraft:blackstone
setblock 465 214 492 minecraft:soul_soil
fill 465 214 498 465 215 500 minecraft:blackstone
setblock 423 215 464 minecraft:blackstone
setblock 423 215 473 minecraft:blackstone
setblock 423 215 481 minecraft:blackstone
setblock 423 215 501 minecraft:blackstone
fill 424 215 497 424 218 497 minecraft:blackstone
setblock 424 215 501 minecraft:polished_blackstone_bricks
fill 424 215 502 427 215 502 minecraft:blackstone
setblock 425 215 463 minecraft:blackstone
setblock 425 215 500 minecraft:polished_blackstone_bricks
fill 425 215 501 425 218 501 minecraft:blackstone
fill 425 215 504 425 215 505 minecraft:blackstone
setblock 426 215 464 minecraft:polished_blackstone_bricks
fill 426 215 500 426 218 500 minecraft:blackstone
setblock 426 215 504 minecraft:polished_blackstone_bricks
fill 427 215 464 427 218 464 minecraft:blackstone
setblock 427 215 503 minecraft:polished_blackstone_bricks
fill 427 215 504 427 218 504 minecraft:blackstone
setblock 428 215 502 minecraft:polished_blackstone_bricks
fill 428 215 503 428 218 503 minecraft:blackstone
fill 429 215 502 429 218 502 minecraft:blackstone
setblock 431 215 464 minecraft:polished_blackstone_bricks
setblock 431 215 504 minecraft:polished_blackstone_bricks
fill 432 215 464 432 218 464 minecraft:blackstone
setblock 432 215 503 minecraft:polished_blackstone_bricks
fill 432 215 504 432 218 504 minecraft:blackstone
setblock 433 215 463 minecraft:blackstone
setblock 433 215 502 minecraft:polished_blackstone_bricks
fill 433 215 503 433 218 503 minecraft:blackstone
setblock 436 215 504 minecraft:polished_blackstone_bricks
setblock 437 215 463 minecraft:blackstone
fill 437 215 504 437 216 504 minecraft:blackstone
fill 444 215 505 445 215 505 minecraft:blackstone
setblock 446 215 464 minecraft:polished_blackstone_bricks
setblock 446 215 504 minecraft:polished_blackstone_bricks
fill 447 215 464 447 218 464 minecraft:blackstone
fill 447 215 504 447 218 504 minecraft:blackstone
setblock 449 215 465 minecraft:blackstone
fill 449 215 503 449 217 503 minecraft:blackstone
setblock 450 215 465 minecraft:polished_blackstone_bricks
setblock 451 215 464 minecraft:polished_blackstone_bricks
fill 451 215 465 451 218 465 minecraft:blackstone
setblock 451 215 504 minecraft:polished_blackstone_bricks
fill 452 215 464 452 218 464 minecraft:blackstone
setblock 452 215 503 minecraft:polished_blackstone_bricks
fill 452 215 504 452 218 504 minecraft:blackstone
fill 453 215 503 453 218 503 minecraft:blackstone
setblock 455 215 465 minecraft:polished_blackstone_bricks
setblock 455 215 505 minecraft:blackstone
setblock 456 215 464 minecraft:polished_blackstone_bricks
setblock 456 215 504 minecraft:polished_blackstone_bricks
fill 457 215 464 457 218 464 minecraft:blackstone
fill 457 215 504 457 218 504 minecraft:blackstone
fill 458 215 505 459 215 505 minecraft:blackstone
setblock 461 215 464 minecraft:polished_blackstone_bricks
setblock 461 215 504 minecraft:polished_blackstone_bricks
fill 462 215 464 462 218 464 minecraft:blackstone
fill 462 215 504 462 218 504 minecraft:blackstone
setblock 464 215 466 minecraft:polished_blackstone_bricks
setblock 464 215 501 minecraft:polished_blackstone_bricks
fill 464 215 502 464 218 502 minecraft:blackstone
setblock 465 215 472 minecraft:blackstone
setblock 465 215 474 minecraft:blackstone
setblock 465 215 488 minecraft:blackstone
setblock 465 215 492 minecraft:blackstone
fill 423 216 463 423 216 498 minecraft:soul_soil
setblock 423 216 499 minecraft:blackstone
fill 423 216 500 423 216 502 minecraft:soul_soil
setblock 423 216 503 minecraft:blackstone
fill 423 216 504 423 307 505 minecraft:soul_soil
fill 424 216 463 425 307 463 minecraft:soul_soil
setblock 424 216 465 minecraft:polished_blackstone_bricks
fill 424 216 481 424 216 484 minecraft:blackstone
setblock 424 216 485 minecraft:polished_blackstone_bricks
fill 424 216 486 424 219 486 minecraft:blackstone
fill 424 216 496 424 219 496 minecraft:blackstone
setblock 424 216 500 minecraft:polished_blackstone_bricks
fill 424 216 501 424 218 502 minecraft:blackstone
setblock 424 216 505 minecraft:soul_soil
setblock 425 216 464 minecraft:polished_blackstone_bricks
setblock 425 216 499 minecraft:polished_blackstone_bricks
fill 425 216 500 425 219 500 minecraft:blackstone
fill 425 216 502 426 216 502 minecraft:blackstone
setblock 425 216 504 minecraft:polished_blackstone_bricks
setblock 425 216 505 minecraft:blackstone
fill 426 216 464 426 219 464 minecraft:blackstone
setblock 426 216 466 minecraft:light[level=11]
setblock 426 216 474 minecraft:light[level=11]
setblock 426 216 482 minecraft:light[level=11]
setblock 426 216 490 minecraft:light[level=11]
setblock 426 216 498 minecraft:light[level=11]
setblock 426 216 503 minecraft:polished_blackstone_bricks
fill 426 216 504 426 219 504 minecraft:blackstone
fill 426 216 505 431 307 505 minecraft:soul_soil
fill 427 216 463 441 216 463 minecraft:soul_soil
setblock 427 216 502 minecraft:polished_blackstone_bricks
fill 427 216 503 427 219 503 minecraft:blackstone
fill 428 216 502 428 219 502 minecraft:blackstone
setblock 430 216 464 minecraft:polished_blackstone_bricks
setblock 430 216 504 minecraft:polished_blackstone_bricks
fill 431 216 464 431 219 464 minecraft:blackstone
setblock 431 216 503 minecraft:polished_blackstone_bricks
fill 431 216 504 431 219 504 minecraft:blackstone
setblock 432 216 502 minecraft:polished_blackstone_bricks
fill 432 216 503 432 219 503 minecraft:blackstone
fill 433 216 505 438 216 505 minecraft:soul_soil
setblock 434 216 464 minecraft:blackstone
setblock 434 216 466 minecraft:light[level=11]
setblock 434 216 474 minecraft:light[level=11]
setblock 434 216 482 minecraft:light[level=11]
setblock 434 216 490 minecraft:light[level=11]
setblock 434 216 498 minecraft:light[level=11]
setblock 435 216 504 minecraft:polished_blackstone_bricks
fill 436 216 504 436 219 504 minecraft:blackstone
fill 439 216 505 440 216 505 minecraft:blackstone
fill 441 216 505 443 217 505 minecraft:soul_soil
setblock 442 216 463 minecraft:blackstone
setblock 442 216 466 minecraft:light[level=11]
setblock 442 216 474 minecraft:light[level=11]
setblock 442 216 482 minecraft:light[level=11]
setblock 442 216 490 minecraft:light[level=11]
setblock 442 216 498 minecraft:light[level=11]
fill 443 216 463 458 217 463 minecraft:soul_soil
setblock 444 216 505 minecraft:blackstone
setblock 445 216 464 minecraft:polished_blackstone_bricks
setblock 445 216 504 minecraft:polished_blackstone_bricks
fill 445 216 505 447 307 505 minecraft:soul_soil
fill 446 216 464 446 219 464 minecraft:blackstone
fill 446 216 504 446 219 504 minecraft:blackstone
fill 447 216 465 448 216 465 minecraft:blackstone
fill 448 216 503 448 218 503 minecraft:blackstone
setblock 448 216 505 minecraft:blackstone
setblock 449 216 465 minecraft:polished_blackstone_bricks
fill 449 216 505 455 217 505 minecraft:soul_soil
setblock 450 216 464 minecraft:polished_blackstone_bricks
fill 450 216 465 450 219 465 minecraft:blackstone
setblock 450 216 466 minecraft:light[level=11]
setblock 450 216 474 minecraft:light[level=11]
setblock 450 216 482 minecraft:light[level=11]
setblock 450 216 498 minecraft:light[level=11]
setblock 450 216 504 minecraft:polished_blackstone_bricks
fill 451 216 464 451 219 464 minecraft:blackstone
setblock 451 216 503 minecraft:polished_blackstone_bricks
fill 451 216 504 451 219 504 minecraft:blackstone
fill 452 216 503 452 219 503 minecraft:blackstone
setblock 454 216 465 minecraft:polished_blackstone_bricks
setblock 455 216 464 minecraft:polished_blackstone_bricks
fill 455 216 465 456 218 465 minecraft:blackstone
setblock 455 216 504 minecraft:polished_blackstone_bricks
fill 456 216 464 456 219 464 minecraft:blackstone
fill 456 216 504 456 216 505 minecraft:blackstone
fill 457 216 505 458 307 505 minecraft:soul_soil
setblock 458 216 466 minecraft:light[level=11]
setblock 458 216 474 minecraft:light[level=11]
setblock 458 216 482 minecraft:light[level=11]
setblock 458 216 490 minecraft:light[level=11]
setblock 458 216 498 minecraft:light[level=11]
fill 459 216 505 459 217 505 minecraft:blackstone
fill 460 216 463 463 307 463 minecraft:soul_soil
setblock 460 216 464 minecraft:polished_blackstone_bricks
setblock 460 216 504 minecraft:polished_blackstone_bricks
fill 460 216 505 465 216 505 minecraft:soul_soil
fill 461 216 464 461 219 464 minecraft:blackstone
fill 461 216 504 461 219 504 minecraft:blackstone
fill 463 216 503 463 218 503 minecraft:blackstone
setblock 464 216 464 minecraft:blackstone
setblock 464 216 465 minecraft:polished_blackstone_bricks
fill 464 216 466 464 218 467 minecraft:blackstone
setblock 464 216 499 minecraft:blackstone
setblock 464 216 500 minecraft:polished_blackstone_bricks
fill 464 216 501 464 219 501 minecraft:blackstone
fill 465 216 463 465 216 467 minecraft:soul_soil
fill 465 216 469 465 216 472 minecraft:soul_soil
fill 465 216 474 465 216 478 minecraft:soul_soil
fill 465 216 480 465 307 480 minecraft:soul_soil
fill 465 216 482 465 217 484 minecraft:soul_soil
fill 465 216 486 465 217 492 minecraft:soul_soil
fill 465 216 494 465 217 499 minecraft:soul_soil
fill 465 216 500 465 217 500 minecraft:blackstone
setblock 465 216 501 minecraft:soul_soil
fill 465 216 503 465 216 504 minecraft:soul_soil
fill 423 217 463 423 217 467 minecraft:soul_soil
setblock 423 217 468 minecraft:blackstone
fill 423 217 469 423 217 471 minecraft:soul_soil
setblock 423 217 472 minecraft:blackstone
fill 423 217 473 423 217 489 minecraft:soul_soil
fill 423 217 490 424 217 490 minecraft:blackstone
fill 423 217 491 423 217 500 minecraft:soul_soil
setblock 423 217 501 minecraft:blackstone
fill 423 217 502 423 217 503 minecraft:soul_soil
setblock 424 217 464 minecraft:polished_blackstone_bricks
fill 424 217 465 424 219 466 minecraft:blackstone
fill 424 217 480 424 217 483 minecraft:blackstone
setblock 424 217 484 minecraft:polished_blackstone_bricks
fill 424 217 485 425 219 485 minecraft:blackstone
fill 424 217 487 424 217 488 minecraft:blackstone
setblock 424 217 489 minecraft:polished_blackstone_bricks
fill 424 217 495 424 220 495 minecraft:blackstone
setblock 424 217 499 minecraft:polished_blackstone_bricks
fill 424 217 500 424 220 500 minecraft:blackstone
setblock 424 217 504 minecraft:polished_blackstone_bricks
setblock 424 217 505 minecraft:blackstone
fill 425 217 464 425 220 464 minecraft:blackstone
setblock 425 217 482 minecraft:blackstone
setblock 425 217 483 minecraft:polished_blackstone_bricks
fill 425 217 484 425 220 484 minecraft:blackstone
fill 425 217 486 425 217 487 minecraft:blackstone
setblock 425 217 497 minecraft:blackstone
setblock 425 217 498 minecraft:polished_blackstone_bricks
fill 425 217 499 425 220 499 minecraft:blackstone
setblock 425 217 502 minecraft:blackstone
setblock 425 217 503 minecraft:polished_blackstone_bricks
fill 425 217 504 425 220 504 minecraft:blackstone
fill 425 217 505 425 307 505 minecraft:soul_soil
fill 426 217 463 426 307 463 minecraft:soul_soil
fill 426 217 465 427 217 465 minecraft:blackstone
setblock 426 217 502 minecraft:polished_blackstone_bricks
fill 426 217 503 426 220 503 minecraft:blackstone
setblock 427 217 463 minecraft:blackstone
fill 427 217 502 427 220 502 minecraft:blackstone
fill 428 217 463 434 217 463 minecraft:soul_soil
setblock 428 217 465 minecraft:polished_blackstone_bricks
setblock 429 217 464 minecraft:polished_blackstone_bricks
fill 429 217 465 430 219 465 minecraft:blackstone
setblock 429 217 504 minecraft:polished_blackstone_bricks
fill 430 217 464 430 220 464 minecraft:blackstone
setblock 430 217 503 minecraft:polished_blackstone_bricks
fill 430 217 504 430 220 504 minecraft:blackstone
setblock 431 217 502 minecraft:polished_blackstone_bricks
fill 431 217 503 431 220 503 minecraft:blackstone
setblock 432 217 502 minecraft:blackstone
fill 432 217 505 437 307 505 minecraft:soul_soil
setblock 434 217 464 minecraft:polished_blackstone_bricks
setblock 434 217 504 minecraft:polished_blackstone_bricks
setblock 435 217 463 minecraft:blackstone
fill 435 217 504 435 220 504 minecraft:blackstone
fill 436 217 463 437 217 463 minecraft:soul_soil
setblock 438 217 463 minecraft:blackstone
setblock 438 217 505 minecraft:blackstone
fill 439 217 463 440 307 463 minecraft:soul_soil
fill 439 217 505 439 307 505 minecraft:soul_soil
setblock 440 217 505 minecraft:blackstone
setblock 441 217 463 minecraft:blackstone
fill 442 217 463 442 307 463 minecraft:soul_soil
setblock 443 217 464 minecraft:blackstone
setblock 444 217 464 minecraft:polished_blackstone_bricks
setblock 444 217 504 minecraft:polished_blackstone_bricks
fill 444 217 505 444 307 505 minecraft:soul_soil
fill 445 217 464 445 220 464 minecraft:blackstone
fill 445 217 504 445 220 504 minecraft:blackstone
fill 446 217 465 447 217 465 minecraft:blackstone
fill 447 217 503 447 219 503 minecraft:blackstone
setblock 448 217 465 minecraft:polished_blackstone_bricks
fill 448 217 505 448 307 505 minecraft:soul_soil
setblock 449 217 464 minecraft:polished_blackstone_bricks
fill 449 217 465 449 219 466 minecraft:blackstone
setblock 449 217 504 minecraft:polished_blackstone_bricks
fill 450 217 464 450 220 464 minecraft:blackstone
fill 450 217 466 451 217 466 minecraft:blackstone
setblock 450 217 503 minecraft:polished_blackstone_bricks
fill 450 217 504 450 220 504 minecraft:blackstone
fill 451 217 503 451 220 503 minecraft:blackstone
setblock 452 217 466 minecraft:polished_blackstone_bricks
setblock 453 217 465 minecraft:polished_blackstone_bricks
setblock 454 217 464 minecraft:polished_blackstone_bricks
fill 454 217 465 454 220 465 minecraft:blackstone
setblock 454 217 504 minecraft:polished_blackstone_bricks
fill 455 217 464 455 220 464 minecraft:blackstone
fill 455 217 504 456 219 504 minecraft:blackstone
fill 456 217 505 456 307 505 minecraft:soul_soil
setblock 457 217 465 minecraft:blackstone
fill 459 217 463 459 307 463 minecraft:soul_soil
setblock 459 217 464 minecraft:polished_blackstone_bricks
setblock 459 217 504 minecraft:polished_blackstone_bricks
fill 460 217 464 460 220 464 minecraft:blackstone
fill 460 217 504 460 217 505 minecraft:blackstone
fill 461 217 465 462 217 465 minecraft:blackstone
setblock 461 217 505 minecraft:blackstone
fill 462 217 503 462 219 503 minecraft:blackstone
fill 462 217 505 462 307 505 minecraft:soul_soil
setblock 463 217 465 minecraft:polished_blackstone_bricks
fill 463 217 466 463 220 466 minecraft:blackstone
fill 463 217 502 463 219 502 minecraft:blackstone
setblock 463 217 505 minecraft:blackstone
fill 464 217 463 465 217 463 minecraft:soul_soil
setblock 464 217 464 minecraft:polished_blackstone_bricks
fill 464 217 465 464 220 465 minecraft:blackstone
setblock 464 217 468 minecraft:blackstone
setblock 464 217 469 minecraft:polished_blackstone_bricks
fill 464 217 481 464 217 483 minecraft:blackstone
setblock 464 217 484 minecraft:polished_blackstone_bricks
setblock 464 217 499 minecraft:polished_blackstone_bricks
fill 464 217 500 464 220 500 minecraft:blackstone
setblock 464 217 504 minecraft:polished_blackstone_bricks
fill 464 217 505 465 307 505 minecraft:soul_soil
fill 465 217 464 465 307 465 minecraft:soul_soil
setblock 465 217 466 minecraft:blackstone
fill 465 217 467 465 307 468 minecraft:soul_soil
setblock 465 217 469 minecraft:blackstone
fill 465 217 470 465 217 475 minecraft:soul_soil
setblock 465 217 476 minecraft:blackstone
fill 465 217 477 465 217 479 minecraft:soul_soil
fill 465 217 481 465 307 481 minecraft:soul_soil
fill 465 217 485 465 307 485 minecraft:soul_soil
fill 465 217 493 465 307 493 minecraft:soul_soil
fill 465 217 501 465 218 501 minecraft:blackstone
fill 465 217 502 465 307 503 minecraft:soul_soil
setblock 465 217 504 minecraft:blackstone
fill 423 218 463 423 307 464 minecraft:soul_soil
fill 423 218 465 423 218 466 minecraft:blackstone
fill 423 218 467 423 307 469 minecraft:soul_soil
setblock 423 218 470 minecraft:blackstone
fill 423 218 471 423 307 481 minecraft:soul_soil
fill 423 218 482 423 218 483 minecraft:blackstone
fill 423 218 484 423 307 485 minecraft:soul_soil
setblock 423 218 486 minecraft:blackstone
fill 423 218 487 423 307 493 minecraft:soul_soil
fill 423 218 494 424 218 494 minecraft:blackstone
fill 423 218 495 423 307 501 minecraft:soul_soil
setblock 423 218 502 minecraft:blackstone
fill 423 218 503 423 307 503 minecraft:soul_soil
fill 424 218 464 424 221 464 minecraft:blackstone
setblock 424 218 467 minecraft:blackstone
setblock 424 218 468 minecraft:polished_blackstone_bricks
fill 424 218 480 424 218 482 minecraft:blackstone
setblock 424 218 483 minecraft:polished_blackstone_bricks
fill 424 218 484 424 221 484 minecraft:blackstone
setblock 424 218 487 minecraft:blackstone
setblock 424 218 488 minecraft:polished_blackstone_bricks
fill 424 218 489 424 218 492 minecraft:blackstone
setblock 424 218 493 minecraft:polished_blackstone_bricks
setblock 424 218 498 minecraft:polished_blackstone_bricks
fill 424 218 499 424 221 499 minecraft:blackstone
setblock 424 218 503 minecraft:polished_blackstone_bricks
fill 424 218 504 424 221 504 minecraft:blackstone
fill 424 218 505 424 307 505 minecraft:soul_soil
fill 425 218 465 425 218 466 minecraft:blackstone
setblock 425 218 481 minecraft:blackstone
setblock 425 218 482 minecraft:polished_blackstone_bricks
fill 425 218 483 426 220 483 minecraft:blackstone
setblock 425 218 486 minecraft:blackstone
setblock 425 218 487 minecraft:polished_blackstone_bricks
fill 425 218 488 425 218 491 minecraft:blackstone
setblock 425 218 496 minecraft:blackstone
setblock 425 218 497 minecraft:polished_blackstone_bricks
fill 425 218 498 425 221 498 minecraft:blackstone
setblock 425 218 502 minecraft:polished_blackstone_bricks
fill 425 218 503 425 221 503 minecraft:blackstone
setblock 426 218 465 minecraft:blackstone
fill 426 218 484 426 218 485 minecraft:blackstone
setblock 426 218 486 minecraft:polished_blackstone_bricks
fill 426 218 487 426 220 488 minecraft:blackstone
fill 426 218 499 426 219 499 minecraft:blackstone
setblock 426 218 501 minecraft:polished_blackstone_bricks
fill 426 218 502 426 221 502 minecraft:blackstone
fill 427 218 463 429 307 463 minecraft:soul_soil
setblock 427 218 465 minecraft:polished_blackstone_bricks
setblock 428 218 464 minecraft:polished_blackstone_bricks
fill 428 218 465 428 221 465 minecraft:blackstone
setblock 428 218 504 minecraft:polished_blackstone_bricks
fill 429 218 464 429 221 464 minecraft:blackstone
setblock 429 218 503 minecraft:polished_blackstone_bricks
fill 429 218 504 429 221 504 minecraft:blackstone
setblock 430 218 463 minecraft:blackstone
setblock 430 218 502 minecraft:polished_blackstone_bricks
fill 430 218 503 430 221 503 minecraft:blackstone
fill 431 218 463 433 307 463 minecraft:soul_soil
setblock 431 218 465 minecraft:blackstone
fill 431 218 502 431 219 502 minecraft:blackstone
setblock 433 218 464 minecraft:polished_blackstone_bricks
setblock 433 218 504 minecraft:polished_blackstone_bricks
fill 434 218 463 434 218 464 minecraft:blackstone
setblock 434 218 503 minecraft:polished_blackstone_bricks
fill 434 218 504 434 221 504 minecraft:blackstone
fill 435 218 463 436 307 463 minecraft:soul_soil
setblock 437 218 463 minecraft:blackstone
fill 438 218 463 438 307 463 minecraft:soul_soil
fill 438 218 505 438 307 505 minecraft:soul_soil
fill 440 218 505 442 307 505 minecraft:soul_soil
fill 441 218 463 441 307 463 minecraft:soul_soil
setblock 442 218 464 minecraft:blackstone
fill 443 218 463 451 307 463 minecraft:soul_soil
setblock 443 218 464 minecraft:polished_blackstone_bricks
setblock 443 218 504 minecraft:polished_blackstone_bricks
setblock 443 218 505 minecraft:blackstone
fill 444 218 464 444 220 465 minecraft:blackstone
fill 444 218 504 444 221 504 minecraft:blackstone
fill 445 218 465 446 218 465 minecraft:blackstone
fill 446 218 503 446 220 503 minecraft:blackstone
setblock 447 218 465 minecraft:polished_blackstone_bricks
fill 447 218 466 448 220 466 minecraft:blackstone
setblock 448 218 464 minecraft:polished_blackstone_bricks
fill 448 218 465 448 221 465 minecraft:blackstone
setblock 448 218 504 minecraft:polished_blackstone_bricks
fill 449 218 464 449 221 464 minecraft:blackstone
setblock 449 218 503 minecraft:polished_blackstone_bricks
fill 449 218 504 449 221 504 minecraft:blackstone
fill 449 218 505 451 307 505 minecraft:soul_soil
setblock 450 218 466 minecraft:blackstone
fill 450 218 503 450 221 503 minecraft:blackstone
setblock 451 218 466 minecraft:polished_blackstone_bricks
setblock 452 218 463 minecraft:blackstone
setblock 452 218 465 minecraft:polished_blackstone_bricks
fill 452 218 466 453 220 466 minecraft:blackstone
setblock 452 218 505 minecraft:blackstone
fill 453 218 463 455 307 463 minecraft:soul_soil
setblock 453 218 464 minecraft:polished_blackstone_bricks
fill 453 218 465 453 221 465 minecraft:blackstone
setblock 453 218 504 minecraft:polished_blackstone_bricks
fill 453 218 505 455 307 505 minecraft:soul_soil
fill 454 218 464 454 221 464 minecraft:blackstone
fill 454 218 504 454 221 504 minecraft:blackstone
setblock 456 218 463 minecraft:blackstone
fill 457 218 463 458 307 463 minecraft:soul_soil
setblock 457 218 465 minecraft:polished_blackstone_bricks
setblock 458 218 464 minecraft:polished_blackstone_bricks
fill 458 218 465 461 218 465 minecraft:blackstone
setblock 458 218 504 minecraft:polished_blackstone_bricks
fill 459 218 464 459 221 464 minecraft:blackstone
fill 459 218 504 460 220 504 minecraft:blackstone
fill 459 218 505 461 307 505 minecraft:soul_soil
fill 461 218 503 461 220 503 minecraft:blackstone
setblock 462 218 465 minecraft:polished_blackstone_bricks
setblock 463 218 464 minecraft:polished_blackstone_bricks
fill 463 218 465 463 221 465 minecraft:blackstone
fill 463 218 467 463 219 467 minecraft:blackstone
fill 463 218 501 463 220 501 minecraft:blackstone
setblock 463 218 504 minecraft:polished_blackstone_bricks
fill 463 218 505 463 307 505 minecraft:soul_soil
fill 464 218 463 464 218 464 minecraft:blackstone
setblock 464 218 468 minecraft:polished_blackstone_bricks
fill 464 218 469 464 220 470 minecraft:blackstone
fill 464 218 480 464 218 482 minecraft:blackstone
setblock 464 218 483 minecraft:polished_blackstone_bricks
fill 464 218 484 464 218 487 minecraft:blackstone
setblock 464 218 498 minecraft:polished_blackstone_bricks
fill 464 218 499 464 221 499 minecraft:blackstone
setblock 464 218 503 minecraft:polished_blackstone_bricks
fill 464 218 504 464 221 504 minecraft:blackstone
fill 465 218 463 465 307 463 minecraft:soul_soil
fill 465 218 466 465 307 466 minecraft:soul_soil
fill 465 218 469 465 307 474 minecraft:soul_soil
setblock 465 218 475 minecraft:blackstone
fill 465 218 476 465 307 478 minecraft:soul_soil
setblock 465 218 479 minecraft:blackstone
fill 465 218 482 465 307 482 minecraft:soul_soil
setblock 465 218 483 minecraft:blackstone
fill 465 218 484 465 307 484 minecraft:soul_soil
fill 465 218 486 465 307 487 minecraft:soul_soil
setblock 465 218 488 minecraft:blackstone
fill 465 218 489 465 307 492 minecraft:soul_soil
fill 465 218 494 465 307 494 minecraft:soul_soil
setblock 465 218 495 minecraft:blackstone
fill 465 218 496 465 307 500 minecraft:soul_soil
fill 465 218 504 465 307 504 minecraft:soul_soil
fill 423 219 465 423 307 466 minecraft:soul_soil
fill 423 219 470 423 307 470 minecraft:soul_soil
fill 423 219 482 423 307 483 minecraft:soul_soil
fill 423 219 486 423 307 486 minecraft:soul_soil
fill 423 219 494 423 307 494 minecraft:soul_soil
fill 423 219 502 423 307 502 minecraft:soul_soil
setblock 424 219 467 minecraft:polished_blackstone_bricks
fill 424 219 468 424 221 469 minecraft:blackstone
fill 424 219 479 424 219 481 minecraft:blackstone
setblock 424 219 482 minecraft:polished_blackstone_bricks
fill 424 219 483 424 222 483 minecraft:blackstone
setblock 424 219 487 minecraft:polished_blackstone_bricks
fill 424 219 488 424 219 491 minecraft:blackstone
setblock 424 219 492 minecraft:polished_blackstone_bricks
fill 424 219 493 425 220 494 minecraft:blackstone
setblock 424 219 497 minecraft:polished_blackstone_bricks
fill 424 219 498 424 222 498 minecraft:blackstone
setblock 424 219 501 minecraft:blackstone
setblock 424 219 502 minecraft:polished_blackstone_bricks
fill 424 219 503 424 222 503 minecraft:blackstone
setblock 425 219 465 minecraft:blackstone
setblock 425 219 466 minecraft:polished_blackstone_bricks
fill 425 219 467 425 222 467 minecraft:blackstone
setblock 425 219 481 minecraft:polished_blackstone_bricks
fill 425 219 482 426 221 482 minecraft:blackstone
setblock 425 219 486 minecraft:polished_blackstone_bricks
fill 425 219 487 425 219 490 minecraft:blackstone
setblock 425 219 491 minecraft:polished_blackstone_bricks
fill 425 219 492 425 222 492 minecraft:blackstone
setblock 425 219 495 minecraft:blackstone
setblock 425 219 496 minecraft:polished_blackstone_bricks
fill 425 219 497 425 222 497 minecraft:blackstone
setblock 425 219 501 minecraft:polished_blackstone_bricks
fill 425 219 502 425 222 502 minecraft:blackstone
setblock 426 219 465 minecraft:polished_blackstone_bricks
setblock 426 219 484 minecraft:blackstone
setblock 426 219 485 minecraft:polished_blackstone_bricks
fill 426 219 486 427 221 486 minecraft:blackstone
setblock 426 219 489 minecraft:blackstone
setblock 426 219 490 minecraft:polished_blackstone_bricks
fill 426 219 491 426 222 491 minecraft:blackstone
fill 426 219 498 426 220 498 minecraft:blackstone
setblock 426 219 500 minecraft:polished_blackstone_bricks
fill 426 219 501 426 222 501 minecraft:blackstone
setblock 427 219 464 minecraft:polished_blackstone_bricks
fill 427 219 465 427 222 465 minecraft:blackstone
fill 427 219 485 427 222 485 minecraft:blackstone
fill 427 219 487 427 220 487 minecraft:blackstone
setblock 427 219 504 minecraft:polished_blackstone_bricks
fill 428 219 464 428 222 464 minecraft:blackstone
setblock 428 219 503 minecraft:polished_blackstone_bricks
fill 428 219 504 428 222 504 minecraft:blackstone
setblock 429 219 502 minecraft:polished_blackstone_bricks
fill 429 219 503 429 222 503 minecraft:blackstone
fill 430 219 463 430 307 463 minecraft:soul_soil
fill 430 219 502 430 220 502 minecraft:blackstone
setblock 431 219 465 minecraft:polished_blackstone_bricks
setblock 432 219 464 minecraft:polished_blackstone_bricks
setblock 432 219 504 minecraft:polished_blackstone_bricks
fill 433 219 464 435 220 464 minecraft:blackstone
setblock 433 219 503 minecraft:polished_blackstone_bricks
fill 433 219 504 433 222 504 minecraft:blackstone
fill 434 219 463 434 307 463 minecraft:soul_soil
fill 437 219 463 437 307 463 minecraft:soul_soil
fill 440 219 464 441 219 464 minecraft:blackstone
setblock 442 219 464 minecraft:polished_blackstone_bricks
setblock 442 219 504 minecraft:polished_blackstone_bricks
fill 443 219 464 443 221 465 minecraft:blackstone
fill 443 219 504 443 222 504 minecraft:blackstone
fill 443 219 505 443 307 505 minecraft:soul_soil
setblock 445 219 465 minecraft:blackstone
setblock 445 219 466 minecraft:polished_blackstone_bricks
setblock 446 219 465 minecraft:polished_blackstone_bricks
fill 446 219 466 446 222 466 minecraft:blackstone
setblock 447 219 464 minecraft:polished_blackstone_bricks
fill 447 219 465 447 222 465 minecraft:blackstone
setblock 447 219 504 minecraft:polished_blackstone_bricks
fill 448 219 464 448 222 464 minecraft:blackstone
setblock 448 219 503 minecraft:polished_blackstone_bricks
fill 448 219 504 448 222 504 minecraft:blackstone
fill 449 219 503 449 222 503 minecraft:blackstone
setblock 450 219 466 minecraft:polished_blackstone_bricks
setblock 451 219 465 minecraft:polished_blackstone_bricks
fill 451 219 466 451 222 466 minecraft:blackstone
fill 452 219 463 452 307 463 minecraft:soul_soil
setblock 452 219 464 minecraft:polished_blackstone_bricks
fill 452 219 465 452 222 465 minecraft:blackstone
setblock 452 219 504 minecraft:polished_blackstone_bricks
fill 452 219 505 452 307 505 minecraft:soul_soil
fill 453 219 464 453 222 464 minecraft:blackstone
setblock 453 219 503 minecraft:polished_blackstone_bricks
fill 453 219 504 453 222 504 minecraft:blackstone
setblock 454 219 466 minecraft:blackstone
setblock 455 219 465 minecraft:blackstone
fill 456 219 463 456 307 463 minecraft:soul_soil
setblock 456 219 465 minecraft:polished_blackstone_bricks
setblock 457 219 464 minecraft:polished_blackstone_bricks
fill 457 219 465 460 219 465 minecraft:blackstone
setblock 457 219 504 minecraft:polished_blackstone_bricks
fill 458 219 464 458 222 464 minecraft:blackstone
fill 458 219 504 458 222 504 minecraft:blackstone
setblock 461 219 465 minecraft:polished_blackstone_bricks
setblock 462 219 464 minecraft:polished_blackstone_bricks
fill 462 219 465 462 222 465 minecraft:blackstone
setblock 462 219 504 minecraft:polished_blackstone_bricks
fill 463 219 464 464 221 464 minecraft:blackstone
setblock 463 219 468 minecraft:polished_blackstone_bricks
setblock 463 219 503 minecraft:polished_blackstone_bricks
fill 463 219 504 463 222 504 minecraft:blackstone
fill 464 219 463 464 307 463 minecraft:soul_soil
setblock 464 219 466 minecraft:blackstone
setblock 464 219 467 minecraft:polished_blackstone_bricks
fill 464 219 468 464 222 468 minecraft:blackstone
setblock 464 219 471 minecraft:blackstone
fill 464 219 479 464 219 481 minecraft:blackstone
setblock 464 219 482 minecraft:polished_blackstone_bricks
fill 464 219 483 464 219 486 minecraft:blackstone
setblock 464 219 487 minecraft:polished_blackstone_bricks
fill 464 219 488 464 219 491 minecraft:blackstone
setblock 464 219 497 minecraft:polished_blackstone_bricks
fill 464 219 498 464 222 498 minecraft:blackstone
setblock 464 219 502 minecraft:polished_blackstone_bricks
fill 464 219 503 464 222 503 minecraft:blackstone
fill 465 219 475 465 307 475 minecraft:soul_soil
fill 465 219 479 465 307 479 minecraft:soul_soil
fill 465 219 483 465 307 483 minecraft:soul_soil
fill 465 219 488 465 307 488 minecraft:soul_soil
fill 465 219 495 465 307 495 minecraft:soul_soil
fill 465 219 501 465 307 501 minecraft:soul_soil
setblock 424 220 465 minecraft:blackstone
setblock 424 220 466 minecraft:polished_blackstone_bricks
fill 424 220 467 424 223 467 minecraft:blackstone
setblock 424 220 470 minecraft:blackstone
fill 424 220 478 424 220 480 minecraft:blackstone
setblock 424 220 481 minecraft:polished_blackstone_bricks
fill 424 220 482 424 223 482 minecraft:blackstone
setblock 424 220 485 minecraft:blackstone
setblock 424 220 486 minecraft:polished_blackstone_bricks
fill 424 220 487 424 220 490 minecraft:blackstone
setblock 424 220 491 minecraft:polished_blackstone_bricks
fill 424 220 492 424 223 492 minecraft:blackstone
setblock 424 220 496 minecraft:polished_blackstone_bricks
fill 424 220 497 424 223 497 minecraft:blackstone
setblock 424 220 501 minecraft:polished_blackstone_bricks
fill 424 220 502 424 223 502 minecraft:blackstone
setblock 425 220 465 minecraft:polished_blackstone_bricks
fill 425 220 466 427 221 466 minecraft:blackstone
fill 425 220 468 425 221 468 minecraft:blackstone
setblock 425 220 480 minecraft:polished_blackstone_bricks
fill 425 220 481 425 223 481 minecraft:blackstone
setblock 425 220 485 minecraft:polished_blackstone_bricks
fill 425 220 486 425 220 489 minecraft:blackstone
setblock 425 220 490 minecraft:polished_blackstone_bricks
fill 425 220 491 425 223 491 minecraft:blackstone
setblock 425 220 495 minecraft:polished_blackstone_bricks
fill 425 220 496 425 223 496 minecraft:blackstone
setblock 425 220 500 minecraft:polished_blackstone_bricks
fill 425 220 501 425 223 501 minecraft:blackstone
setblock 426 220 464 minecraft:polished_blackstone_bricks
fill 426 220 465 426 223 465 minecraft:blackstone
setblock 426 220 484 minecraft:polished_blackstone_bricks
fill 426 220 485 426 223 485 minecraft:blackstone
setblock 426 220 489 minecraft:polished_blackstone_bricks
fill 426 220 490 427 222 490 minecraft:blackstone
fill 426 220 492 426 220 493 minecraft:blackstone
setblock 426 220 494 minecraft:polished_blackstone_bricks
fill 426 220 495 426 223 495 minecraft:blackstone
fill 426 220 497 426 221 497 minecraft:blackstone
setblock 426 220 499 minecraft:polished_blackstone_bricks
fill 426 220 500 426 223 500 minecraft:blackstone
setblock 426 220 504 minecraft:polished_blackstone_bricks
fill 427 220 464 427 223 464 minecraft:blackstone
fill 427 220 484 427 223 484 minecraft:blackstone
setblock 427 220 488 minecraft:polished_blackstone_bricks
fill 427 220 489 427 223 489 minecraft:blackstone
setblock 427 220 503 minecraft:polished_blackstone_bricks
fill 427 220 504 427 223 504 minecraft:blackstone
setblock 428 220 502 minecraft:polished_blackstone_bricks
fill 428 220 503 428 223 503 minecraft:blackstone
setblock 429 220 465 minecraft:blackstone
fill 429 220 502 429 221 502 minecraft:blackstone
setblock 430 220 465 minecraft:polished_blackstone_bricks
fill 430 220 473 432 221 473 minecraft:cyan_stained_glass
setblock 431 220 464 minecraft:polished_blackstone_bricks
fill 431 220 465 432 221 465 minecraft:blackstone
fill 431 220 472 431 221 472 minecraft:cyan_stained_glass
fill 431 220 474 431 221 474 minecraft:cyan_stained_glass
setblock 431 220 504 minecraft:polished_blackstone_bricks
fill 432 220 464 432 223 464 minecraft:blackstone
setblock 432 220 503 minecraft:polished_blackstone_bricks
fill 432 220 504 432 223 504 minecraft:blackstone
setblock 433 220 503 minecraft:blackstone
setblock 436 220 464 minecraft:polished_blackstone_bricks
setblock 436 220 504 minecraft:polished_blackstone_bricks
fill 438 220 464 440 220 464 minecraft:blackstone
setblock 441 220 464 minecraft:polished_blackstone_bricks
setblock 441 220 504 minecraft:polished_blackstone_bricks
fill 442 220 464 442 222 465 minecraft:blackstone
fill 442 220 504 442 223 504 minecraft:blackstone
setblock 444 220 466 minecraft:polished_blackstone_bricks
setblock 445 220 465 minecraft:polished_blackstone_bricks
fill 445 220 466 445 223 466 minecraft:blackstone
fill 445 220 503 445 221 503 minecraft:blackstone
setblock 446 220 464 minecraft:polished_blackstone_bricks
fill 446 220 465 446 223 465 minecraft:blackstone
setblock 446 220 504 minecraft:polished_blackstone_bricks
fill 447 220 464 447 223 464 minecraft:blackstone
fill 447 220 467 447 220 470 minecraft:blackstone
setblock 447 220 503 minecraft:polished_blackstone_bricks
fill 447 220 504 447 223 504 minecraft:blackstone
setblock 448 220 467 minecraft:polished_blackstone_bricks
fill 448 220 468 451 221 470 minecraft:blackstone
fill 448 220 503 448 223 503 minecraft:blackstone
setblock 449 220 465 minecraft:blackstone
setblock 449 220 466 minecraft:polished_blackstone_bricks
fill 449 220 467 451 221 467 minecraft:blackstone
setblock 450 220 465 minecraft:polished_blackstone_bricks
fill 450 220 466 450 223 466 minecraft:blackstone
setblock 451 220 464 minecraft:polished_blackstone_bricks
fill 451 220 465 451 223 465 minecraft:blackstone
setblock 451 220 504 minecraft:polished_blackstone_bricks
fill 452 220 464 452 223 464 minecraft:blackstone
setblock 452 220 503 minecraft:polished_blackstone_bricks
fill 452 220 504 452 223 504 minecraft:blackstone
setblock 453 220 503 minecraft:blackstone
setblock 454 220 466 minecraft:polished_blackstone_bricks
setblock 455 220 465 minecraft:polished_blackstone_bricks
fill 455 220 466 456 222 466 minecraft:blackstone
setblock 455 220 504 minecraft:blackstone
setblock 456 220 464 minecraft:polished_blackstone_bricks
fill 456 220 465 459 220 465 minecraft:blackstone
setblock 456 220 504 minecraft:polished_blackstone_bricks
fill 457 220 464 457 223 464 minecraft:blackstone
fill 457 220 504 457 223 504 minecraft:blackstone
setblock 460 220 465 minecraft:polished_blackstone_bricks
fill 460 220 503 460 221 503 minecraft:blackstone
setblock 461 220 464 minecraft:polished_blackstone_bricks
fill 461 220 465 461 222 466 minecraft:blackstone
setblock 461 220 504 minecraft:polished_blackstone_bricks
fill 462 220 464 462 223 464 minecraft:blackstone
fill 462 220 466 462 220 467 minecraft:blackstone
setblock 462 220 503 minecraft:polished_blackstone_bricks
fill 462 220 504 462 223 504 minecraft:blackstone
setblock 463 220 467 minecraft:polished_blackstone_bricks
fill 463 220 468 463 222 469 minecraft:blackstone
fill 463 220 485 463 220 486 minecraft:blackstone
fill 463 220 500 463 221 500 minecraft:blackstone
setblock 463 220 502 minecraft:polished_blackstone_bricks
fill 463 220 503 463 223 503 minecraft:blackstone
setblock 464 220 466 minecraft:polished_blackstone_bricks
fill 464 220 467 464 223 467 minecraft:blackstone
setblock 464 220 471 minecraft:polished_blackstone_bricks
fill 464 220 472 464 222 473 minecraft:blackstone
fill 464 220 479 464 220 480 minecraft:blackstone
setblock 464 220 481 minecraft:polished_blackstone_bricks
fill 464 220 482 464 220 485 minecraft:blackstone
setblock 464 220 486 minecraft:polished_blackstone_bricks
fill 464 220 487 464 220 490 minecraft:blackstone
setblock 464 220 491 minecraft:polished_blackstone_bricks
fill 464 220 492 464 220 495 minecraft:blackstone
setblock 464 220 496 minecraft:polished_blackstone_bricks
fill 464 220 497 464 223 497 minecraft:blackstone
setblock 464 220 501 minecraft:polished_blackstone_bricks
fill 464 220 502 464 223 502 minecraft:blackstone
setblock 424 221 465 minecraft:polished_blackstone_bricks
fill 424 221 466 424 224 466 minecraft:blackstone
setblock 424 221 470 minecraft:polished_blackstone_bricks
fill 424 221 471 424 223 472 minecraft:blackstone
fill 424 221 478 424 221 479 minecraft:blackstone
setblock 424 221 480 minecraft:polished_blackstone_bricks
fill 424 221 481 424 224 481 minecraft:blackstone
setblock 424 221 485 minecraft:polished_blackstone_bricks
fill 424 221 486 424 221 489 minecraft:blackstone
setblock 424 221 490 minecraft:polished_blackstone_bricks
fill 424 221 491 424 224 491 minecraft:blackstone
fill 424 221 493 424 221 494 minecraft:blackstone
setblock 424 221 495 minecraft:polished_blackstone_bricks
fill 424 221 496 424 224 496 minecraft:blackstone
setblock 424 221 500 minecraft:polished_blackstone_bricks
fill 424 221 501 424 224 501 minecraft:blackstone
setblock 425 221 464 minecraft:polished_blackstone_bricks
fill 425 221 465 425 224 465 minecraft:blackstone
setblock 425 221 469 minecraft:polished_blackstone_bricks
fill 425 221 480 425 223 480 minecraft:blackstone
setblock 425 221 483 minecraft:blackstone
setblock 425 221 484 minecraft:polished_blackstone_bricks
fill 425 221 485 425 221 488 minecraft:blackstone
setblock 425 221 489 minecraft:polished_blackstone_bricks
fill 425 221 490 425 224 490 minecraft:blackstone
setblock 425 221 493 minecraft:blackstone
setblock 425 221 494 minecraft:polished_blackstone_bricks
fill 425 221 495 425 224 495 minecraft:blackstone
setblock 425 221 499 minecraft:polished_blackstone_bricks
fill 425 221 500 425 224 500 minecraft:blackstone
setblock 425 221 504 minecraft:polished_blackstone_bricks
fill 426 221 464 426 224 464 minecraft:blackstone
setblock 426 221 467 minecraft:blackstone
setblock 426 221 483 minecraft:polished_blackstone_bricks
fill 426 221 484 426 224 484 minecraft:blackstone
setblock 426 221 487 minecraft:blackstone
setblock 426 221 488 minecraft:polished_blackstone_bricks
fill 426 221 489 426 224 489 minecraft:blackstone
setblock 426 221 492 minecraft:blackstone
setblock 426 221 493 minecraft:polished_blackstone_bricks
fill 426 221 494 426 224 494 minecraft:blackstone
fill 426 221 496 426 222 496 minecraft:blackstone
setblock 426 221 498 minecraft:polished_blackstone_bricks
fill 426 221 499 426 223 499 minecraft:blackstone
setblock 426 221 503 minecraft:polished_blackstone_bricks
fill 426 221 504 426 224 504 minecraft:blackstone
setblock 427 221 487 minecraft:polished_blackstone_bricks
fill 427 221 488 427 224 488 minecraft:blackstone
setblock 427 221 491 minecraft:blackstone
setblock 427 221 492 minecraft:polished_blackstone_bricks
setblock 427 221 502 minecraft:polished_blackstone_bricks
fill 427 221 503 427 224 503 minecraft:blackstone
setblock 428 221 466 minecraft:polished_blackstone_bricks
fill 428 221 502 428 222 502 minecraft:blackstone
setblock 429 221 465 minecraft:polished_blackstone_bricks
setblock 430 221 464 minecraft:polished_blackstone_bricks
fill 430 221 465 430 223 465 minecraft:blackstone
setblock 430 221 504 minecraft:polished_blackstone_bricks
fill 431 221 464 431 224 464 minecraft:blackstone
setblock 431 221 503 minecraft:polished_blackstone_bricks
fill 431 221 504 431 224 504 minecraft:blackstone
setblock 432 221 503 minecraft:blackstone
fill 433 221 464 434 221 464 minecraft:blackstone
setblock 435 221 464 minecraft:polished_blackstone_bricks
setblock 435 221 504 minecraft:polished_blackstone_bricks
fill 436 221 464 439 221 464 minecraft:blackstone
setblock 440 221 464 minecraft:polished_blackstone_bricks
fill 441 221 464 441 223 465 minecraft:blackstone
fill 441 221 504 441 223 504 minecraft:blackstone
setblock 443 221 466 minecraft:polished_blackstone_bricks
setblock 444 221 464 minecraft:blackstone
setblock 444 221 465 minecraft:polished_blackstone_bricks
fill 444 221 466 444 224 466 minecraft:blackstone
setblock 445 221 464 minecraft:polished_blackstone_bricks
fill 445 221 465 445 224 465 minecraft:blackstone
fill 445 221 467 446 221 467 minecraft:blackstone
setblock 445 221 504 minecraft:polished_blackstone_bricks
fill 446 221 464 446 224 464 minecraft:blackstone
setblock 446 221 503 minecraft:polished_blackstone_bricks
fill 446 221 504 446 224 504 minecraft:blackstone
setblock 447 221 466 minecraft:blackstone
setblock 447 221 467 minecraft:polished_blackstone_bricks
fill 447 221 468 447 221 470 minecraft:blackstone
fill 447 221 503 447 223 503 minecraft:blackstone
setblock 448 221 466 minecraft:polished_blackstone_bricks
fill 448 221 467 448 224 467 minecraft:blackstone
setblock 449 221 465 minecraft:polished_blackstone_bricks
fill 449 221 466 449 224 466 minecraft:blackstone
setblock 450 221 464 minecraft:polished_blackstone_bricks
fill 450 221 465 450 224 465 minecraft:blackstone
setblock 450 221 504 minecraft:polished_blackstone_bricks
fill 451 221 464 451 224 464 minecraft:blackstone
setblock 451 221 503 minecraft:polished_blackstone_bricks
fill 451 221 504 451 224 504 minecraft:blackstone
setblock 452 221 466 minecraft:blackstone
setblock 452 221 467 minecraft:polished_blackstone_bricks
setblock 452 221 503 minecraft:blackstone
setblock 453 221 466 minecraft:polished_blackstone_bricks
setblock 454 221 465 minecraft:polished_blackstone_bricks
fill 454 221 466 454 224 466 minecraft:blackstone
setblock 455 221 464 minecraft:polished_blackstone_bricks
fill 455 221 465 458 221 465 minecraft:blackstone
setblock 455 221 504 minecraft:polished_blackstone_bricks
fill 456 221 464 456 224 464 minecraft:blackstone
fill 456 221 504 456 224 504 minecraft:blackstone
setblock 457 221 466 minecraft:blackstone
setblock 458 221 466 minecraft:polished_blackstone_bricks
setblock 459 221 465 minecraft:polished_blackstone_bricks
fill 459 221 466 460 223 466 minecraft:blackstone
setblock 459 221 504 minecraft:blackstone
setblock 460 221 464 minecraft:polished_blackstone_bricks
fill 460 221 465 460 224 465 minecraft:blackstone
setblock 460 221 504 minecraft:polished_blackstone_bricks
fill 461 221 464 461 224 464 minecraft:blackstone
setblock 461 221 503 minecraft:polished_blackstone_bricks
fill 461 221 504 461 224 504 minecraft:blackstone
setblock 462 221 466 minecraft:blackstone
setblock 462 221 467 minecraft:polished_blackstone_bricks
fill 462 221 468 462 224 468 minecraft:blackstone
fill 462 221 503 462 224 503 minecraft:blackstone
setblock 463 221 466 minecraft:polished_blackstone_bricks
fill 463 221 467 463 224 467 minecraft:blackstone
setblock 463 221 470 minecraft:blackstone
fill 463 221 484 463 221 485 minecraft:blackstone
setblock 463 221 486 minecraft:polished_blackstone_bricks
fill 463 221 487 463 221 490 minecraft:blackstone
setblock 463 221 501 minecraft:polished_blackstone_bricks
fill 463 221 502 463 224 502 minecraft:blackstone
setblock 464 221 465 minecraft:polished_blackstone_bricks
fill 464 221 466 464 224 466 minecraft:blackstone
setblock 464 221 469 minecraft:blackstone
setblock 464 221 470 minecraft:polished_blackstone_bricks
fill 464 221 471 464 224 471 minecraft:blackstone
setblock 464 221 474 minecraft:blackstone
setblock 464 221 479 minecraft:blackstone
setblock 464 221 480 minecraft:polished_blackstone_bricks
fill 464 221 481 464 221 484 minecraft:blackstone
setblock 464 221 485 minecraft:polished_blackstone_bricks
fill 464 221 486 464 221 489 minecraft:blackstone
setblock 464 221 490 minecraft:polished_blackstone_bricks
fill 464 221 491 464 221 494 minecraft:blackstone
setblock 464 221 495 minecraft:polished_blackstone_bricks
fill 464 221 496 464 224 496 minecraft:blackstone
setblock 464 221 500 minecraft:polished_blackstone_bricks
fill 464 221 501 464 224 501 minecraft:blackstone
setblock 424 222 464 minecraft:polished_blackstone_bricks
fill 424 222 465 424 225 465 minecraft:blackstone
setblock 424 222 468 minecraft:blackstone
setblock 424 222 469 minecraft:polished_blackstone_bricks
fill 424 222 470 425 224 470 minecraft:blackstone
setblock 424 222 473 minecraft:blackstone
setblock 424 222 478 minecraft:blackstone
setblock 424 222 479 minecraft:polished_blackstone_bricks
fill 424 222 480 424 225 480 minecraft:blackstone
setblock 424 222 484 minecraft:polished_blackstone_bricks
fill 424 222 485 424 222 488 minecraft:blackstone
setblock 424 222 489 minecraft:polished_blackstone_bricks
fill 424 222 490 424 225 490 minecraft:blackstone
setblock 424 222 493 minecraft:blackstone
setblock 424 222 494 minecraft:polished_blackstone_bricks
fill 424 222 495 424 225 495 minecraft:blackstone
setblock 424 222 499 minecraft:polished_blackstone_bricks
fill 424 222 500 424 225 500 minecraft:blackstone
setblock 424 222 504 minecraft:polished_blackstone_bricks
fill 425 222 464 425 225 464 minecraft:blackstone
fill 425 222 466 426 222 466 minecraft:blackstone
setblock 425 222 468 minecraft:polished_blackstone_bricks
fill 425 222 469 425 225 469 minecraft:blackstone
setblock 425 222 482 minecraft:blackstone
setblock 425 222 483 minecraft:polished_blackstone_bricks
fill 425 222 484 425 222 487 minecraft:blackstone
setblock 425 222 488 minecraft:polished_blackstone_bricks
fill 425 222 489 425 225 489 minecraft:blackstone
setblock 425 222 493 minecraft:polished_blackstone_bricks
fill 425 222 494 425 225 494 minecraft:blackstone
setblock 425 222 498 minecraft:polished_blackstone_bricks
fill 425 222 499 425 225 499 minecraft:blackstone
setblock 425 222 503 minecraft:polished_blackstone_bricks
fill 425 222 504 425 225 504 minecraft:blackstone
setblock 426 222 467 minecraft:polished_blackstone_bricks
setblock 426 222 482 minecraft:polished_blackstone_bricks
fill 426 222 483 426 224 483 minecraft:blackstone
setblock 426 222 486 minecraft:blackstone
setblock 426 222 487 minecraft:polished_blackstone_bricks
fill 426 222 488 426 225 488 minecraft:blackstone
setblock 426 222 492 minecraft:polished_blackstone_bricks
fill 426 222 493 427 224 493 minecraft:blackstone
setblock 426 222 497 minecraft:polished_blackstone_bricks
fill 426 222 498 426 223 498 minecraft:blackstone
setblock 426 222 502 minecraft:polished_blackstone_bricks
fill 426 222 503 426 225 503 minecraft:blackstone
setblock 427 222 466 minecraft:polished_blackstone_bricks
setblock 427 222 486 minecraft:polished_blackstone_bricks
fill 427 222 487 427 225 487 minecraft:blackstone
setblock 427 222 491 minecraft:polished_blackstone_bricks
fill 427 222 492 427 225 492 minecraft:blackstone
fill 427 222 502 427 223 502 minecraft:blackstone
setblock 428 222 465 minecraft:polished_blackstone_bricks
setblock 428 222 466 minecraft:blackstone
setblock 429 222 464 minecraft:polished_blackstone_bricks
fill 429 222 465 429 224 465 minecraft:blackstone
setblock 429 222 504 minecraft:polished_blackstone_bricks
fill 430 222 464 430 225 464 minecraft:blackstone
setblock 430 222 503 minecraft:polished_blackstone_bricks
fill 430 222 504 430 224 504 minecraft:blackstone
fill 431 222 465 431 223 465 minecraft:blackstone
setblock 431 222 503 minecraft:blackstone
setblock 433 222 464 minecraft:blackstone
setblock 434 222 464 minecraft:polished_blackstone_bricks
setblock 434 222 504 minecraft:polished_blackstone_bricks
fill 435 222 464 438 222 464 minecraft:blackstone
setblock 439 222 464 minecraft:polished_blackstone_bricks
fill 440 222 464 440 224 465 minecraft:blackstone
setblock 442 222 466 minecraft:polished_blackstone_bricks
setblock 443 222 464 minecraft:blackstone
setblock 443 222 465 minecraft:polished_blackstone_bricks
fill 443 222 466 443 225 466 minecraft:blackstone
setblock 444 222 464 minecraft:polished_blackstone_bricks
fill 444 222 465 444 225 465 minecraft:blackstone
fill 444 222 467 445 222 467 minecraft:blackstone
setblock 444 222 504 minecraft:polished_blackstone_bricks
fill 445 222 464 445 225 464 minecraft:blackstone
setblock 445 222 503 minecraft:polished_blackstone_bricks
fill 445 222 504 445 225 504 minecraft:blackstone
setblock 446 222 467 minecraft:polished_blackstone_bricks
fill 446 222 503 446 223 503 minecraft:blackstone
setblock 447 222 466 minecraft:polished_blackstone_bricks
fill 447 222 467 447 225 467 minecraft:blackstone
setblock 448 222 465 minecraft:polished_blackstone_bricks
fill 448 222 466 448 225 466 minecraft:blackstone
fill 448 222 468 450 226 468 minecraft:polished_blackstone_bricks
setblock 449 222 464 minecraft:polished_blackstone_bricks
fill 449 222 465 449 225 465 minecraft:blackstone
fill 449 222 467 450 222 467 minecraft:blackstone
setblock 449 222 504 minecraft:polished_blackstone_bricks
fill 450 222 464 450 225 464 minecraft:blackstone
setblock 450 222 503 minecraft:polished_blackstone_bricks
fill 450 222 504 450 225 504 minecraft:blackstone
setblock 451 222 467 minecraft:polished_blackstone_bricks
setblock 452 222 466 minecraft:polished_blackstone_bricks
setblock 452 222 467 minecraft:blackstone
setblock 453 222 465 minecraft:polished_blackstone_bricks
fill 453 222 466 453 224 466 minecraft:blackstone
setblock 454 222 464 minecraft:polished_blackstone_bricks
fill 454 222 465 457 222 465 minecraft:blackstone
setblock 454 222 504 minecraft:polished_blackstone_bricks
fill 455 222 464 455 225 464 minecraft:blackstone
fill 455 222 504 455 224 504 minecraft:blackstone
setblock 457 222 466 minecraft:polished_blackstone_bricks
setblock 458 222 465 minecraft:polished_blackstone_bricks
fill 458 222 466 458 224 466 minecraft:blackstone
setblock 459 222 464 minecraft:polished_blackstone_bricks
fill 459 222 465 459 225 465 minecraft:blackstone
setblock 459 222 504 minecraft:polished_blackstone_bricks
fill 460 222 464 460 225 464 minecraft:blackstone
setblock 460 222 503 minecraft:polished_blackstone_bricks
fill 460 222 504 460 225 504 minecraft:blackstone
fill 461 222 503 461 225 503 minecraft:blackstone
setblock 462 222 466 minecraft:polished_blackstone_bricks
fill 462 222 467 462 225 467 minecraft:blackstone
setblock 463 222 464 minecraft:blackstone
setblock 463 222 465 minecraft:polished_blackstone_bricks
fill 463 222 466 463 225 466 minecraft:blackstone
setblock 463 222 470 minecraft:polished_blackstone_bricks
fill 463 222 471 463 225 471 minecraft:blackstone
setblock 463 222 484 minecraft:blackstone
setblock 463 222 485 minecraft:polished_blackstone_bricks
fill 463 222 486 463 222 489 minecraft:blackstone
setblock 463 222 490 minecraft:polished_blackstone_bricks
fill 463 222 491 464 222 493 minecraft:blackstone
setblock 463 222 499 minecraft:blackstone
setblock 463 222 500 minecraft:polished_blackstone_bricks
fill 463 222 501 463 225 501 minecraft:blackstone
setblock 464 222 464 minecraft:polished_blackstone_bricks
fill 464 222 465 464 225 465 minecraft:blackstone
setblock 464 222 469 minecraft:polished_blackstone_bricks
fill 464 222 470 464 225 470 minecraft:blackstone
setblock 464 222 474 minecraft:polished_blackstone_bricks
fill 464 222 475 464 225 475 minecraft:blackstone
setblock 464 222 479 minecraft:polished_blackstone_bricks
fill 464 222 480 464 222 483 minecraft:blackstone
setblock 464 222 484 minecraft:polished_blackstone_bricks
fill 464 222 485 464 222 488 minecraft:blackstone
setblock 464 222 489 minecraft:polished_blackstone_bricks
fill 464 222 490 464 225 490 minecraft:blackstone
setblock 464 222 494 minecraft:polished_blackstone_bricks
fill 464 222 495 464 225 495 minecraft:blackstone
setblock 464 222 499 minecraft:polished_blackstone_bricks
fill 464 222 500 464 225 500 minecraft:blackstone
setblock 464 222 504 minecraft:polished_blackstone_bricks
fill 424 223 464 424 226 464 minecraft:blackstone
setblock 424 223 468 minecraft:polished_blackstone_bricks
fill 424 223 469 424 226 469 minecraft:blackstone
setblock 424 223 473 minecraft:polished_blackstone_bricks
fill 424 223 474 424 226 474 minecraft:blackstone
setblock 424 223 477 minecraft:blackstone
setblock 424 223 478 minecraft:polished_blackstone_bricks
fill 424 223 479 424 226 479 minecraft:blackstone
setblock 424 223 483 minecraft:polished_blackstone_bricks
fill 424 223 484 424 223 487 minecraft:blackstone
setblock 424 223 488 minecraft:polished_blackstone_bricks
fill 424 223 489 424 226 489 minecraft:blackstone
setblock 424 223 493 minecraft:polished_blackstone_bricks
fill 424 223 494 424 226 494 minecraft:blackstone
setblock 424 223 498 minecraft:polished_blackstone_bricks
fill 424 223 499 424 226 499 minecraft:blackstone
setblock 424 223 503 minecraft:polished_blackstone_bricks
fill 424 223 504 424 226 504 minecraft:blackstone
setblock 425 223 466 minecraft:blackstone
setblock 425 223 467 minecraft:polished_blackstone_bricks
fill 425 223 468 425 226 468 minecraft:blackstone
setblock 425 223 471 minecraft:blackstone
setblock 425 223 482 minecraft:polished_blackstone_bricks
fill 425 223 483 425 223 486 minecraft:blackstone
setblock 425 223 487 minecraft:polished_blackstone_bricks
fill 425 223 488 425 226 488 minecraft:blackstone
setblock 425 223 492 minecraft:polished_blackstone_bricks
fill 425 223 493 425 226 493 minecraft:blackstone
setblock 425 223 497 minecraft:polished_blackstone_bricks
fill 425 223 498 425 226 498 minecraft:blackstone
setblock 425 223 502 minecraft:polished_blackstone_bricks
fill 425 223 503 425 226 503 minecraft:blackstone
setblock 426 223 466 minecraft:polished_blackstone_bricks
fill 426 223 467 426 224 467 minecraft:blackstone
setblock 426 223 482 minecraft:blackstone
setblock 426 223 486 minecraft:polished_blackstone_bricks
fill 426 223 487 426 226 487 minecraft:blackstone
setblock 426 223 490 minecraft:blackstone
setblock 426 223 491 minecraft:polished_blackstone_bricks
fill 426 223 492 426 226 492 minecraft:blackstone
setblock 426 223 496 minecraft:polished_blackstone_bricks
fill 426 223 497 426 224 497 minecraft:blackstone
setblock 426 223 501 minecraft:polished_blackstone_bricks
setblock 426 223 502 minecraft:blackstone
setblock 427 223 465 minecraft:polished_blackstone_bricks
setblock 427 223 466 minecraft:blackstone
setblock 427 223 485 minecraft:polished_blackstone_bricks
fill 427 223 486 427 225 486 minecraft:blackstone
setblock 427 223 490 minecraft:polished_blackstone_bricks
fill 427 223 491 427 226 491 minecraft:blackstone
setblock 428 223 464 minecraft:polished_blackstone_bricks
fill 428 223 465 428 225 465 minecraft:blackstone
setblock 428 223 504 minecraft:polished_blackstone_bricks
fill 429 223 464 429 225 464 minecraft:blackstone
setblock 429 223 503 minecraft:polished_blackstone_bricks
fill 429 223 504 429 225 504 minecraft:blackstone
setblock 430 223 503 minecraft:blackstone
setblock 433 223 464 minecraft:polished_blackstone_bricks
setblock 434 223 464 minecraft:blackstone
setblock 437 223 464 minecraft:blackstone
setblock 438 223 464 minecraft:polished_blackstone_bricks
fill 439 223 464 439 226 464 minecraft:blackstone
setblock 442 223 464 minecraft:blackstone
setblock 442 223 465 minecraft:polished_blackstone_bricks
fill 442 223 466 442 226 466 minecraft:blackstone
setblock 443 223 464 minecraft:polished_blackstone_bricks
fill 443 223 465 443 226 465 minecraft:blackstone
setblock 443 223 504 minecraft:polished_blackstone_bricks
fill 444 223 464 444 226 464 minecraft:blackstone
setblock 444 223 467 minecraft:blackstone
fill 444 223 504 444 226 504 minecraft:blackstone
setblock 445 223 467 minecraft:polished_blackstone_bricks
setblock 446 223 466 minecraft:polished_blackstone_bricks
fill 446 223 467 446 226 467 minecraft:blackstone
setblock 447 223 465 minecraft:polished_blackstone_bricks
fill 447 223 466 447 226 466 minecraft:blackstone
setblock 448 223 464 minecraft:polished_blackstone_bricks
fill 448 223 465 448 226 465 minecraft:blackstone
setblock 448 223 504 minecraft:polished_blackstone_bricks
fill 449 223 464 449 226 464 minecraft:blackstone
setblock 449 223 467 minecraft:blackstone
fill 449 223 504 449 225 504 minecraft:blackstone
setblock 450 223 467 minecraft:polished_blackstone_bricks
setblock 451 223 466 minecraft:polished_blackstone_bricks
setblock 451 223 467 minecraft:blackstone
setblock 452 223 465 minecraft:polished_blackstone_bricks
fill 452 223 466 452 225 466 minecraft:blackstone
setblock 453 223 464 minecraft:polished_blackstone_bricks
fill 453 223 465 456 223 465 minecraft:blackstone
setblock 453 223 504 minecraft:polished_blackstone_bricks
fill 454 223 464 454 226 464 minecraft:blackstone
fill 454 223 504 454 224 504 minecraft:blackstone
setblock 455 223 466 minecraft:blackstone
setblock 456 223 466 minecraft:polished_blackstone_bricks
setblock 457 223 465 minecraft:polished_blackstone_bricks
setblock 457 223 466 minecraft:blackstone
setblock 458 223 464 minecraft:polished_blackstone_bricks
fill 458 223 465 458 226 465 minecraft:blackstone
setblock 458 223 504 minecraft:polished_blackstone_bricks
fill 459 223 464 459 226 464 minecraft:blackstone
fill 459 223 504 459 226 504 minecraft:blackstone
fill 460 223 503 460 224 503 minecraft:blackstone
setblock 461 223 465 minecraft:blackstone
setblock 461 223 466 minecraft:polished_blackstone_bricks
setblock 462 223 465 minecraft:polished_blackstone_bricks
fill 462 223 466 462 226 466 minecraft:blackstone
setblock 462 223 469 minecraft:blackstone
setblock 463 223 464 minecraft:polished_blackstone_bricks
fill 463 223 465 463 226 465 minecraft:blackstone
setblock 463 223 468 minecraft:blackstone
setblock 463 223 469 minecraft:polished_blackstone_bricks
fill 463 223 470 463 226 470 minecraft:blackstone
fill 463 223 472 464 223 472 minecraft:blackstone
setblock 463 223 484 minecraft:polished_blackstone_bricks
fill 463 223 485 463 223 488 minecraft:blackstone
setblock 463 223 489 minecraft:polished_blackstone_bricks
fill 463 223 490 463 223 493 minecraft:blackstone
setblock 463 223 494 minecraft:polished_blackstone_bricks
fill 463 223 495 463 223 498 minecraft:blackstone
setblock 463 223 499 minecraft:polished_blackstone_bricks
fill 463 223 500 463 226 500 minecraft:blackstone
setblock 463 223 504 minecraft:polished_blackstone_bricks
fill 464 223 464 464 226 464 minecraft:blackstone
setblock 464 223 468 minecraft:polished_blackstone_bricks
fill 464 223 469 464 226 469 minecraft:blackstone
setblock 464 223 473 minecraft:polished_blackstone_bricks
fill 464 223 474 464 226 474 minecraft:blackstone
fill 464 223 480 464 223 482 minecraft:blackstone
setblock 464 223 483 minecraft:polished_blackstone_bricks
fill 464 223 484 464 223 487 minecraft:blackstone
setblock 464 223 488 minecraft:polished_blackstone_bricks
fill 464 223 489 464 226 489 minecraft:blackstone
fill 464 223 491 464 223 492 minecraft:blackstone
setblock 464 223 493 minecraft:polished_blackstone_bricks
fill 464 223 494 464 226 494 minecraft:blackstone
setblock 464 223 498 minecraft:polished_blackstone_bricks
fill 464 223 499 464 226 499 minecraft:blackstone
setblock 464 223 503 minecraft:polished_blackstone_bricks
fill 464 223 504 464 226 504 minecraft:blackstone
setblock 424 224 467 minecraft:polished_blackstone_bricks
fill 424 224 468 424 227 468 minecraft:blackstone
setblock 424 224 471 minecraft:blackstone
setblock 424 224 472 minecraft:polished_blackstone_bricks
fill 424 224 473 424 227 473 minecraft:blackstone
fill 424 224 475 424 225 475 minecraft:blackstone
fill 424 224 478 424 225 478 minecraft:blackstone
setblock 424 224 482 minecraft:polished_blackstone_bricks
fill 424 224 483 424 224 486 minecraft:blackstone
setblock 424 224 487 minecraft:polished_blackstone_bricks
fill 424 224 488 424 227 488 minecraft:blackstone
setblock 424 224 492 minecraft:polished_blackstone_bricks
fill 424 224 493 424 227 493 minecraft:blackstone
setblock 424 224 497 minecraft:polished_blackstone_bricks
fill 424 224 498 424 227 498 minecraft:blackstone
setblock 424 224 502 minecraft:polished_blackstone_bricks
fill 424 224 503 424 227 503 minecraft:blackstone
setblock 425 224 466 minecraft:polished_blackstone_bricks
fill 425 224 467 425 227 467 minecraft:blackstone
setblock 425 224 471 minecraft:polished_blackstone_bricks
setblock 425 224 481 minecraft:polished_blackstone_bricks
fill 425 224 482 425 224 485 minecraft:blackstone
setblock 425 224 486 minecraft:polished_blackstone_bricks
fill 425 224 487 425 227 487 minecraft:blackstone
setblock 425 224 491 minecraft:polished_blackstone_bricks
fill 425 224 492 425 227 492 minecraft:blackstone
setblock 425 224 496 minecraft:polished_blackstone_bricks
fill 425 224 497 425 227 497 minecraft:blackstone
setblock 425 224 501 minecraft:polished_blackstone_bricks
fill 425 224 502 425 226 502 minecraft:blackstone
setblock 426 224 465 minecraft:polished_blackstone_bricks
setblock 426 224 466 minecraft:blackstone
setblock 426 224 474 minecraft:light[level=11]
setblock 426 224 482 minecraft:light[level=11]
setblock 426 224 485 minecraft:polished_blackstone_bricks
fill 426 224 486 426 227 486 minecraft:blackstone
setblock 426 224 490 minecraft:polished_blackstone_bricks
fill 426 224 491 426 227 491 minecraft:blackstone
setblock 426 224 495 minecraft:polished_blackstone_bricks
fill 426 224 496 426 226 496 minecraft:blackstone
setblock 426 224 498 minecraft:light[level=11]
setblock 427 224 464 minecraft:polished_blackstone_bricks
fill 427 224 465 427 225 465 minecraft:blackstone
setblock 427 224 485 minecraft:blackstone
setblock 427 224 489 minecraft:polished_blackstone_bricks
fill 427 224 490 427 226 490 minecraft:blackstone
setblock 427 224 504 minecraft:polished_blackstone_bricks
fill 428 224 464 428 226 464 minecraft:blackstone
setblock 428 224 503 minecraft:polished_blackstone_bricks
fill 428 224 504 428 226 504 minecraft:blackstone
setblock 432 224 464 minecraft:polished_blackstone_bricks
setblock 434 224 466 minecraft:light[level=11]
setblock 434 224 474 minecraft:light[level=11]
setblock 434 224 482 minecraft:light[level=11]
setblock 434 224 490 minecraft:light[level=11]
setblock 434 224 498 minecraft:light[level=11]
fill 438 224 464 438 225 464 minecraft:blackstone
setblock 441 224 464 minecraft:blackstone
setblock 441 224 465 minecraft:polished_blackstone_bricks
fill 441 224 466 441 226 466 minecraft:blackstone
setblock 442 224 464 minecraft:polished_blackstone_bricks
fill 442 224 465 442 227 465 minecraft:blackstone
setblock 442 224 474 minecraft:light[level=11]
setblock 442 224 482 minecraft:light[level=11]
setblock 442 224 490 minecraft:light[level=11]
setblock 442 224 498 minecraft:light[level=11]
setblock 442 224 504 minecraft:polished_blackstone_bricks
fill 443 224 464 443 227 464 minecraft:blackstone
setblock 443 224 467 minecraft:blackstone
fill 443 224 504 443 225 504 minecraft:blackstone
setblock 444 224 467 minecraft:polished_blackstone_bricks
setblock 445 224 466 minecraft:polished_blackstone_bricks
fill 445 224 467 445 227 467 minecraft:blackstone
setblock 446 224 465 minecraft:polished_blackstone_bricks
fill 446 224 466 446 227 466 minecraft:blackstone
setblock 447 224 464 minecraft:polished_blackstone_bricks
fill 447 224 465 447 227 465 minecraft:blackstone
setblock 447 224 504 minecraft:polished_blackstone_bricks
fill 448 224 464 448 227 464 minecraft:blackstone
fill 448 224 504 448 226 504 minecraft:blackstone
setblock 449 224 467 minecraft:polished_blackstone_bricks
setblock 450 224 466 minecraft:polished_blackstone_bricks
setblock 450 224 467 minecraft:blackstone
setblock 450 224 474 minecraft:light[level=11]
setblock 450 224 482 minecraft:light[level=11]
setblock 450 224 498 minecraft:light[level=11]
setblock 451 224 465 minecraft:polished_blackstone_bricks
fill 451 224 466 451 225 466 minecraft:blackstone
setblock 452 224 464 minecraft:polished_blackstone_bricks
fill 452 224 465 455 224 465 minecraft:blackstone
setblock 452 224 504 minecraft:polished_blackstone_bricks
fill 453 224 464 453 227 464 minecraft:blackstone
setblock 453 224 504 minecraft:blackstone
setblock 455 224 466 minecraft:polished_blackstone_bricks
setblock 456 224 465 minecraft:polished_blackstone_bricks
setblock 457 224 464 minecraft:polished_blackstone_bricks
fill 457 224 465 457 227 465 minecraft:blackstone
setblock 457 224 504 minecraft:polished_blackstone_bricks
fill 458 224 464 458 227 464 minecraft:blackstone
setblock 458 224 474 minecraft:light[level=11]
setblock 458 224 482 minecraft:light[level=11]
setblock 458 224 490 minecraft:light[level=11]
setblock 458 224 498 minecraft:light[level=11]
fill 458 224 504 458 227 504 minecraft:blackstone
setblock 459 224 466 minecraft:blackstone
setblock 460 224 466 minecraft:polished_blackstone_bricks
setblock 461 224 465 minecraft:polished_blackstone_bricks
fill 461 224 466 461 227 466 minecraft:blackstone
setblock 462 224 464 minecraft:polished_blackstone_bricks
fill 462 224 465 462 227 465 minecraft:blackstone
setblock 462 224 469 minecraft:polished_blackstone_bricks
setblock 462 224 504 minecraft:polished_blackstone_bricks
fill 463 224 464 463 227 464 minecraft:blackstone
setblock 463 224 468 minecraft:polished_blackstone_bricks
fill 463 224 469 463 227 469 minecraft:blackstone
setblock 463 224 472 minecraft:blackstone
fill 463 224 484 463 224 487 minecraft:blackstone
setblock 463 224 488 minecraft:polished_blackstone_bricks
fill 463 224 489 463 224 492 minecraft:blackstone
setblock 463 224 493 minecraft:polished_blackstone_bricks
fill 463 224 494 463 224 497 minecraft:blackstone
setblock 463 224 498 minecraft:polished_blackstone_bricks
fill 463 224 499 463 227 499 minecraft:blackstone
setblock 463 224 503 minecraft:polished_blackstone_bricks
fill 463 224 504 463 227 504 minecraft:blackstone
setblock 464 224 467 minecraft:polished_blackstone_bricks
fill 464 224 468 464 227 468 minecraft:blackstone
setblock 464 224 472 minecraft:polished_blackstone_bricks
fill 464 224 473 464 227 473 minecraft:blackstone
setblock 464 224 481 minecraft:blackstone
setblock 464 224 482 minecraft:polished_blackstone_bricks
fill 464 224 483 464 224 486 minecraft:blackstone
setblock 464 224 487 minecraft:polished_blackstone_bricks
fill 464 224 488 464 227 488 minecraft:blackstone
setblock 464 224 491 minecraft:blackstone
setblock 464 224 492 minecraft:polished_blackstone_bricks
fill 464 224 493 464 227 493 minecraft:blackstone
setblock 464 224 497 minecraft:polished_blackstone_bricks
fill 464 224 498 464 227 498 minecraft:blackstone
setblock 464 224 502 minecraft:polished_blackstone_bricks
fill 464 224 503 464 227 503 minecraft:blackstone
setblock 424 225 466 minecraft:polished_blackstone_bricks
fill 424 225 467 424 228 467 minecraft:blackstone
setblock 424 225 470 minecraft:blackstone
setblock 424 225 471 minecraft:polished_blackstone_bricks
fill 424 225 472 424 228 472 minecraft:blackstone
setblock 424 225 481 minecraft:polished_blackstone_bricks
fill 424 225 482 424 225 485 minecraft:blackstone
setblock 424 225 486 minecraft:polished_blackstone_bricks
fill 424 225 487 424 228 487 minecraft:blackstone
setblock 424 225 491 minecraft:polished_blackstone_bricks
fill 424 225 492 424 228 492 minecraft:blackstone
setblock 424 225 496 minecraft:polished_blackstone_bricks
fill 424 225 497 424 228 497 minecraft:blackstone
setblock 424 225 501 minecraft:polished_blackstone_bricks
fill 424 225 502 424 228 502 minecraft:blackstone
setblock 425 225 465 minecraft:polished_blackstone_bricks
fill 425 225 466 425 226 466 minecraft:blackstone
setblock 425 225 470 minecraft:polished_blackstone_bricks
fill 425 225 471 425 227 471 minecraft:blackstone
fill 425 225 482 425 225 484 minecraft:blackstone
setblock 425 225 485 minecraft:polished_blackstone_bricks
fill 425 225 486 425 228 486 minecraft:blackstone
setblock 425 225 490 minecraft:polished_blackstone_bricks
fill 425 225 491 425 228 491 minecraft:blackstone
setblock 425 225 495 minecraft:polished_blackstone_bricks
fill 425 225 496 425 228 496 minecraft:blackstone
setblock 425 225 500 minecraft:polished_blackstone_bricks
fill 425 225 501 425 226 501 minecraft:blackstone
setblock 426 225 464 minecraft:polished_blackstone_bricks
fill 426 225 465 426 226 465 minecraft:blackstone
setblock 426 225 484 minecraft:polished_blackstone_bricks
fill 426 225 485 426 226 485 minecraft:blackstone
setblock 426 225 489 minecraft:polished_blackstone_bricks
fill 426 225 490 426 228 490 minecraft:blackstone
setblock 426 225 493 minecraft:blackstone
setblock 426 225 494 minecraft:polished_blackstone_bricks
fill 426 225 495 426 228 495 minecraft:blackstone
setblock 426 225 504 minecraft:polished_blackstone_bricks
fill 427 225 464 427 226 464 minecraft:blackstone
setblock 427 225 488 minecraft:polished_blackstone_bricks
fill 427 225 489 427 226 489 minecraft:blackstone
setblock 427 225 493 minecraft:polished_blackstone_bricks
setblock 427 225 503 minecraft:polished_blackstone_bricks
fill 427 225 504 427 226 504 minecraft:blackstone
setblock 440 225 464 minecraft:blackstone
setblock 440 225 465 minecraft:polished_blackstone_bricks
setblock 441 225 464 minecraft:polished_blackstone_bricks
fill 441 225 465 441 228 465 minecraft:blackstone
fill 442 225 464 442 228 464 minecraft:blackstone
setblock 443 225 467 minecraft:polished_blackstone_bricks
setblock 444 225 466 minecraft:polished_blackstone_bricks
fill 444 225 467 444 227 467 minecraft:blackstone
setblock 445 225 465 minecraft:polished_blackstone_bricks
fill 445 225 466 445 228 466 minecraft:blackstone
setblock 446 225 464 minecraft:polished_blackstone_bricks
fill 446 225 465 446 228 465 minecraft:blackstone
setblock 446 225 504 minecraft:polished_blackstone_bricks
fill 447 225 464 447 228 464 minecraft:blackstone
fill 447 225 504 447 226 504 minecraft:blackstone
setblock 448 225 467 minecraft:polished_blackstone_bricks
setblock 449 225 466 minecraft:polished_blackstone_bricks
setblock 449 225 467 minecraft:blackstone
fill 449 225 469 449 226 469 minecraft:polished_blackstone_bricks
setblock 450 225 465 minecraft:polished_blackstone_bricks
fill 450 225 466 450 226 466 minecraft:blackstone
setblock 451 225 464 minecraft:polished_blackstone_bricks
fill 451 225 465 454 225 465 minecraft:blackstone
fill 452 225 464 452 228 464 minecraft:blackstone
setblock 455 225 465 minecraft:polished_blackstone_bricks
setblock 456 225 464 minecraft:polished_blackstone_bricks
fill 456 225 465 456 226 465 minecraft:blackstone
fill 457 225 464 457 228 464 minecraft:blackstone
setblock 457 225 504 minecraft:blackstone
setblock 459 225 466 minecraft:polished_blackstone_bricks
setblock 460 225 465 minecraft:polished_blackstone_bricks
fill 460 225 466 460 226 466 minecraft:blackstone
setblock 461 225 464 minecraft:polished_blackstone_bricks
fill 461 225 465 461 228 465 minecraft:blackstone
setblock 461 225 504 minecraft:polished_blackstone_bricks
fill 462 225 464 462 228 464 minecraft:blackstone
setblock 462 225 468 minecraft:polished_blackstone_bricks
fill 462 225 469 462 227 469 minecraft:blackstone
setblock 462 225 503 minecraft:polished_blackstone_bricks
fill 462 225 504 462 228 504 minecraft:blackstone
setblock 463 225 467 minecraft:polished_blackstone_bricks
fill 463 225 468 463 228 468 minecraft:blackstone
setblock 463 225 472 minecraft:polished_blackstone_bricks
fill 463 225 485 463 225 486 minecraft:blackstone
setblock 463 225 487 minecraft:polished_blackstone_bricks
fill 463 225 488 463 225 491 minecraft:blackstone
setblock 463 225 492 minecraft:polished_blackstone_bricks
fill 463 225 493 463 225 496 minecraft:blackstone
setblock 463 225 497 minecraft:polished_blackstone_bricks
fill 463 225 498 463 228 498 minecraft:blackstone
setblock 463 225 502 minecraft:polished_blackstone_bricks
fill 463 225 503 463 228 503 minecraft:blackstone
setblock 464 225 466 minecraft:polished_blackstone_bricks
fill 464 225 467 464 228 467 minecraft:blackstone
setblock 464 225 471 minecraft:polished_blackstone_bricks
fill 464 225 472 464 228 472 minecraft:blackstone
fill 464 225 482 464 225 485 minecraft:blackstone
setblock 464 225 486 minecraft:polished_blackstone_bricks
fill 464 225 487 464 228 487 minecraft:blackstone
setblock 464 225 491 minecraft:polished_blackstone_bricks
fill 464 225 492 464 228 492 minecraft:blackstone
setblock 464 225 496 minecraft:polished_blackstone_bricks
fill 464 225 497 464 228 497 minecraft:blackstone
setblock 464 225 501 minecraft:polished_blackstone_bricks
fill 464 225 502 464 228 502 minecraft:blackstone
setblock 424 226 465 minecraft:polished_blackstone_bricks
fill 424 226 466 424 229 466 minecraft:blackstone
setblock 424 226 470 minecraft:polished_blackstone_bricks
fill 424 226 471 424 229 471 minecraft:blackstone
setblock 424 226 475 minecraft:polished_blackstone_bricks
setblock 424 226 480 minecraft:polished_blackstone_bricks
fill 424 226 481 424 226 484 minecraft:blackstone
setblock 424 226 485 minecraft:polished_blackstone_bricks
fill 424 226 486 424 229 486 minecraft:blackstone
setblock 424 226 490 minecraft:polished_blackstone_bricks
fill 424 226 491 424 229 491 minecraft:blackstone
setblock 424 226 495 minecraft:polished_blackstone_bricks
fill 424 226 496 424 229 496 minecraft:blackstone
setblock 424 226 500 minecraft:polished_blackstone_bricks
fill 424 226 501 424 229 501 minecraft:blackstone
setblock 425 226 464 minecraft:polished_blackstone_bricks
setblock 425 226 465 minecraft:blackstone
setblock 425 226 469 minecraft:polished_blackstone_bricks
fill 425 226 470 425 228 470 minecraft:blackstone
setblock 425 226 483 minecraft:blackstone
setblock 425 226 484 minecraft:polished_blackstone_bricks
fill 425 226 485 425 229 485 minecraft:blackstone
setblock 425 226 489 minecraft:polished_blackstone_bricks
fill 425 226 490 425 229 490 minecraft:blackstone
setblock 425 226 494 minecraft:polished_blackstone_bricks
fill 425 226 495 425 229 495 minecraft:blackstone
setblock 425 226 499 minecraft:polished_blackstone_bricks
setblock 425 226 500 minecraft:blackstone
setblock 425 226 504 minecraft:polished_blackstone_bricks
fill 426 226 464 426 227 464 minecraft:blackstone
setblock 426 226 488 minecraft:polished_blackstone_bricks
fill 426 226 489 426 229 489 minecraft:blackstone
setblock 426 226 493 minecraft:polished_blackstone_bricks
fill 426 226 494 426 229 494 minecraft:blackstone
fill 426 226 504 426 227 504 minecraft:blackstone
setblock 427 226 488 minecraft:blackstone
setblock 427 226 492 minecraft:polished_blackstone_bricks
setblock 440 226 464 minecraft:polished_blackstone_bricks
fill 440 226 465 440 228 465 minecraft:blackstone
fill 441 226 464 441 229 464 minecraft:blackstone
setblock 443 226 466 minecraft:polished_blackstone_bricks
setblock 443 226 467 minecraft:blackstone
setblock 444 226 465 minecraft:polished_blackstone_bricks
fill 444 226 466 444 229 466 minecraft:blackstone
setblock 445 226 464 minecraft:polished_blackstone_bricks
fill 445 226 465 445 229 465 minecraft:blackstone
setblock 445 226 504 minecraft:polished_blackstone_bricks
fill 446 226 464 446 229 464 minecraft:blackstone
setblock 446 226 504 minecraft:blackstone
setblock 447 226 467 minecraft:polished_blackstone_bricks
setblock 448 226 466 minecraft:polished_blackstone_bricks
setblock 448 226 467 minecraft:blackstone
setblock 449 226 465 minecraft:polished_blackstone_bricks
fill 449 226 466 449 227 466 minecraft:blackstone
setblock 449 226 467 minecraft:polished_blackstone_bricks
setblock 450 226 464 minecraft:polished_blackstone_bricks
fill 450 226 465 453 226 465 minecraft:blackstone
fill 451 226 464 451 229 464 minecraft:blackstone
setblock 454 226 465 minecraft:polished_blackstone_bricks
setblock 455 226 464 minecraft:polished_blackstone_bricks
setblock 455 226 465 minecraft:blackstone
fill 456 226 464 456 229 464 minecraft:blackstone
setblock 459 226 465 minecraft:polished_blackstone_bricks
setblock 460 226 464 minecraft:polished_blackstone_bricks
fill 460 226 465 460 229 465 minecraft:blackstone
setblock 460 226 504 minecraft:polished_blackstone_bricks
fill 461 226 464 461 229 464 minecraft:blackstone
setblock 461 226 503 minecraft:polished_blackstone_bricks
fill 461 226 504 461 229 504 minecraft:blackstone
setblock 462 226 467 minecraft:polished_blackstone_bricks
fill 462 226 468 462 227 468 minecraft:blackstone
fill 462 226 503 462 229 503 minecraft:blackstone
setblock 463 226 466 minecraft:polished_blackstone_bricks
fill 463 226 467 463 229 467 minecraft:blackstone
setblock 463 226 471 minecraft:polished_blackstone_bricks
fill 463 226 472 463 229 472 minecraft:blackstone
setblock 463 226 486 minecraft:polished_blackstone_bricks
fill 463 226 487 463 226 490 minecraft:blackstone
setblock 463 226 491 minecraft:polished_blackstone_bricks
fill 463 226 492 463 226 495 minecraft:blackstone
setblock 463 226 496 minecraft:polished_blackstone_bricks
fill 463 226 497 463 229 497 minecraft:blackstone
setblock 463 226 501 minecraft:polished_blackstone_bricks
fill 463 226 502 463 229 502 minecraft:blackstone
setblock 464 226 465 minecraft:polished_blackstone_bricks
fill 464 226 466 464 229 466 minecraft:blackstone
setblock 464 226 470 minecraft:polished_blackstone_bricks
fill 464 226 471 464 229 471 minecraft:blackstone
setblock 464 226 475 minecraft:polished_blackstone_bricks
fill 464 226 483 464 226 484 minecraft:blackstone
setblock 464 226 485 minecraft:polished_blackstone_bricks
fill 464 226 486 464 229 486 minecraft:blackstone
setblock 464 226 490 minecraft:polished_blackstone_bricks
fill 464 226 491 464 229 491 minecraft:blackstone
setblock 464 226 495 minecraft:polished_blackstone_bricks
fill 464 226 496 464 229 496 minecraft:blackstone
setblock 464 226 500 minecraft:polished_blackstone_bricks
fill 464 226 501 464 229 501 minecraft:blackstone
setblock 424 227 464 minecraft:polished_blackstone_bricks
fill 424 227 465 424 229 465 minecraft:blackstone
setblock 424 227 469 minecraft:polished_blackstone_bricks
fill 424 227 470 424 230 470 minecraft:blackstone
setblock 424 227 474 minecraft:polished_blackstone_bricks
fill 424 227 475 424 229 476 minecraft:blackstone
fill 424 227 480 424 227 483 minecraft:blackstone
setblock 424 227 484 minecraft:polished_blackstone_bricks
fill 424 227 485 424 230 485 minecraft:blackstone
setblock 424 227 489 minecraft:polished_blackstone_bricks
fill 424 227 490 424 230 490 minecraft:blackstone
setblock 424 227 494 minecraft:polished_blackstone_bricks
fill 424 227 495 424 230 495 minecraft:blackstone
setblock 424 227 499 minecraft:polished_blackstone_bricks
fill 424 227 500 424 230 500 minecraft:blackstone
setblock 424 227 504 minecraft:polished_blackstone_bricks
fill 425 227 464 425 228 464 minecraft:blackstone
setblock 425 227 468 minecraft:polished_blackstone_bricks
fill 425 227 469 425 228 469 minecraft:blackstone
setblock 425 227 483 minecraft:polished_blackstone_bricks
fill 425 227 484 425 228 484 minecraft:blackstone
setblock 425 227 488 minecraft:polished_blackstone_bricks
fill 425 227 489 425 230 489 minecraft:blackstone
setblock 425 227 493 minecraft:polished_blackstone_bricks
fill 425 227 494 425 230 494 minecraft:blackstone
setblock 425 227 498 minecraft:polished_blackstone_bricks
setblock 425 227 499 minecraft:blackstone
fill 425 227 504 425 228 504 minecraft:blackstone
setblock 426 227 487 minecraft:polished_blackstone_bricks
fill 426 227 488 426 229 488 minecraft:blackstone
setblock 426 227 492 minecraft:polished_blackstone_bricks
fill 426 227 493 426 230 493 minecraft:blackstone
setblock 439 227 464 minecraft:polished_blackstone_bricks
fill 440 227 464 440 230 464 minecraft:blackstone
setblock 442 227 466 minecraft:polished_blackstone_bricks
setblock 443 227 465 minecraft:polished_blackstone_bricks
fill 443 227 466 443 230 466 minecraft:blackstone
setblock 444 227 464 minecraft:polished_blackstone_bricks
fill 444 227 465 444 230 465 minecraft:blackstone
fill 445 227 464 445 230 464 minecraft:blackstone
setblock 446 227 467 minecraft:polished_blackstone_bricks
setblock 447 227 466 minecraft:polished_blackstone_bricks
fill 447 227 488 448 227 492 minecraft:cyan_concrete
setblock 448 227 465 minecraft:polished_blackstone_bricks
setblock 448 227 466 minecraft:blackstone
fill 448 227 487 454 227 487 minecraft:cyan_concrete
fill 448 227 493 454 227 493 minecraft:cyan_concrete
setblock 449 227 464 minecraft:polished_blackstone_bricks
fill 449 227 465 451 227 465 minecraft:blackstone
fill 449 227 486 453 227 486 minecraft:cyan_concrete
fill 449 227 488 449 229 488 minecraft:cyan_concrete
fill 449 227 492 449 229 492 minecraft:cyan_concrete
fill 449 227 494 453 227 494 minecraft:cyan_concrete
fill 450 227 464 450 229 464 minecraft:blackstone
fill 453 227 488 455 227 488 minecraft:cyan_concrete
fill 453 227 492 455 227 492 minecraft:cyan_concrete
setblock 454 227 464 minecraft:polished_blackstone_bricks
fill 454 227 489 455 227 491 minecraft:cyan_concrete
fill 455 227 464 455 228 464 minecraft:blackstone
setblock 458 227 465 minecraft:polished_blackstone_bricks
setblock 459 227 464 minecraft:polished_blackstone_bricks
fill 459 227 465 459 229 465 minecraft:blackstone
setblock 459 227 504 minecraft:polished_blackstone_bricks
fill 460 227 464 460 230 464 minecraft:blackstone
fill 460 227 504 460 230 504 minecraft:blackstone
setblock 462 227 466 minecraft:polished_blackstone_bricks
setblock 462 227 467 minecraft:blackstone
setblock 462 227 491 minecraft:polished_blackstone_bricks
fill 462 227 492 463 228 493 minecraft:blackstone
setblock 463 227 465 minecraft:polished_blackstone_bricks
fill 463 227 466 463 230 466 minecraft:blackstone
setblock 463 227 470 minecraft:polished_blackstone_bricks
fill 463 227 471 463 230 471 minecraft:blackstone
fill 463 227 487 463 227 489 minecraft:blackstone
setblock 463 227 490 minecraft:polished_blackstone_bricks
fill 463 227 491 463 230 491 minecraft:blackstone
setblock 463 227 494 minecraft:blackstone
setblock 463 227 495 minecraft:polished_blackstone_bricks
fill 463 227 496 463 230 496 minecraft:blackstone
setblock 463 227 500 minecraft:polished_blackstone_bricks
fill 463 227 501 463 230 501 minecraft:blackstone
setblock 464 227 464 minecraft:polished_blackstone_bricks
fill 464 227 465 464 230 465 minecraft:blackstone
setblock 464 227 469 minecraft:polished_blackstone_bricks
fill 464 227 470 464 230 470 minecraft:blackstone
setblock 464 227 474 minecraft:polished_blackstone_bricks
fill 464 227 475 464 230 475 minecraft:blackstone
setblock 464 227 484 minecraft:polished_blackstone_bricks
fill 464 227 485 464 230 485 minecraft:blackstone
setblock 464 227 489 minecraft:polished_blackstone_bricks
fill 464 227 490 464 230 490 minecraft:blackstone
setblock 464 227 494 minecraft:polished_blackstone_bricks
fill 464 227 495 464 230 495 minecraft:blackstone
setblock 464 227 499 minecraft:polished_blackstone_bricks
fill 464 227 500 464 230 500 minecraft:blackstone
setblock 464 227 504 minecraft:polished_blackstone_bricks
setblock 424 228 464 minecraft:blackstone
setblock 424 228 468 minecraft:polished_blackstone_bricks
fill 424 228 469 424 230 469 minecraft:blackstone
setblock 424 228 473 minecraft:polished_blackstone_bricks
fill 424 228 474 424 230 474 minecraft:blackstone
fill 424 228 481 424 228 482 minecraft:blackstone
setblock 424 228 483 minecraft:polished_blackstone_bricks
fill 424 228 484 424 230 484 minecraft:blackstone
setblock 424 228 488 minecraft:polished_blackstone_bricks
fill 424 228 489 424 230 489 minecraft:blackstone
setblock 424 228 493 minecraft:polished_blackstone_bricks
fill 424 228 494 424 230 494 minecraft:blackstone
setblock 424 228 498 minecraft:polished_blackstone_bricks
fill 424 228 499 424 230 499 minecraft:blackstone
setblock 424 228 503 minecraft:polished_blackstone_bricks
fill 424 228 504 424 229 504 minecraft:blackstone
setblock 425 228 487 minecraft:polished_blackstone_bricks
fill 425 228 488 425 230 488 minecraft:blackstone
setblock 425 228 492 minecraft:polished_blackstone_bricks
fill 425 228 493 425 230 493 minecraft:blackstone
setblock 425 228 497 minecraft:polished_blackstone_bricks
fill 425 228 498 425 230 498 minecraft:blackstone
setblock 426 228 487 minecraft:blackstone
setblock 426 228 491 minecraft:polished_blackstone_bricks
fill 426 228 492 426 230 492 minecraft:blackstone
fill 435 228 486 436 229 486 minecraft:light_blue_stained_glass
fill 439 228 464 439 230 464 minecraft:blackstone
setblock 442 228 465 minecraft:polished_blackstone_bricks
fill 442 228 466 442 229 466 minecraft:blackstone
setblock 443 228 464 minecraft:polished_blackstone_bricks
fill 443 228 465 443 230 465 minecraft:blackstone
fill 444 228 464 444 230 464 minecraft:blackstone
setblock 446 228 466 minecraft:polished_blackstone_bricks
setblock 447 228 465 minecraft:polished_blackstone_bricks
setblock 447 228 466 minecraft:blackstone
setblock 448 228 464 minecraft:polished_blackstone_bricks
fill 448 228 465 449 228 465 minecraft:blackstone
fill 448 228 488 448 228 492 minecraft:cyan_concrete
fill 449 228 464 449 230 464 minecraft:blackstone
fill 449 228 487 453 228 487 minecraft:cyan_concrete
fill 449 228 493 453 228 493 minecraft:cyan_concrete
fill 450 228 486 452 228 486 minecraft:cyan_concrete
setblock 453 228 464 minecraft:polished_blackstone_bricks
fill 453 228 488 454 228 488 minecraft:cyan_concrete
fill 453 228 492 454 228 492 minecraft:cyan_concrete
setblock 454 228 464 minecraft:blackstone
fill 454 228 489 454 229 491 minecraft:cyan_concrete
setblock 455 228 490 minecraft:cyan_concrete
setblock 458 228 464 minecraft:polished_blackstone_bricks
setblock 458 228 465 minecraft:blackstone
setblock 458 228 504 minecraft:polished_blackstone_bricks
fill 459 228 464 459 230 464 minecraft:blackstone
fill 459 228 504 459 230 504 minecraft:blackstone
setblock 462 228 465 minecraft:polished_blackstone_bricks
fill 462 228 491 462 230 491 minecraft:blackstone
setblock 462 228 494 minecraft:blackstone
setblock 462 228 495 minecraft:polished_blackstone_bricks
setblock 463 228 464 minecraft:polished_blackstone_bricks
fill 463 228 465 463 230 465 minecraft:blackstone
setblock 463 228 469 minecraft:polished_blackstone_bricks
fill 463 228 470 463 230 470 minecraft:blackstone
fill 463 228 487 463 228 488 minecraft:blackstone
setblock 463 228 489 minecraft:polished_blackstone_bricks
fill 463 228 490 463 230 490 minecraft:blackstone
setblock 463 228 494 minecraft:polished_blackstone_bricks
fill 463 228 495 463 230 495 minecraft:blackstone
setblock 463 228 499 minecraft:polished_blackstone_bricks
fill 463 228 500 463 230 500 minecraft:blackstone
setblock 463 228 504 minecraft:polished_blackstone_bricks
fill 464 228 464 464 230 464 minecraft:blackstone
setblock 464 228 468 minecraft:polished_blackstone_bricks
fill 464 228 469 464 230 469 minecraft:blackstone
setblock 464 228 473 minecraft:polished_blackstone_bricks
fill 464 228 474 464 230 474 minecraft:blackstone
setblock 464 228 484 minecraft:blackstone
setblock 464 228 488 minecraft:polished_blackstone_bricks
fill 464 228 489 464 230 489 minecraft:blackstone
setblock 464 228 493 minecraft:polished_blackstone_bricks
fill 464 228 494 464 230 494 minecraft:blackstone
setblock 464 228 498 minecraft:polished_blackstone_bricks
fill 464 228 499 464 230 499 minecraft:blackstone
setblock 464 228 503 minecraft:polished_blackstone_bricks
fill 464 228 504 464 230 504 minecraft:blackstone
setblock 424 229 467 minecraft:polished_blackstone_bricks
fill 424 229 468 424 230 468 minecraft:blackstone
setblock 424 229 472 minecraft:polished_blackstone_bricks
fill 424 229 473 424 230 473 minecraft:blackstone
setblock 424 229 477 minecraft:polished_blackstone_bricks
fill 424 229 478 424 230 478 minecraft:blackstone
setblock 424 229 481 minecraft:blackstone
setblock 424 229 482 minecraft:polished_blackstone_bricks
fill 424 229 483 424 230 483 minecraft:blackstone
setblock 424 229 487 minecraft:polished_blackstone_bricks
fill 424 229 488 424 230 488 minecraft:blackstone
setblock 424 229 492 minecraft:polished_blackstone_bricks
fill 424 229 493 424 230 493 minecraft:blackstone
setblock 424 229 497 minecraft:polished_blackstone_bricks
fill 424 229 498 424 230 498 minecraft:blackstone
setblock 424 229 502 minecraft:polished_blackstone_bricks
setblock 424 229 503 minecraft:blackstone
setblock 425 229 486 minecraft:polished_blackstone_bricks
fill 425 229 487 425 230 487 minecraft:blackstone
setblock 425 229 491 minecraft:polished_blackstone_bricks
fill 425 229 492 425 230 492 minecraft:blackstone
setblock 425 229 496 minecraft:polished_blackstone_bricks
fill 425 229 497 425 230 497 minecraft:blackstone
setblock 426 229 490 minecraft:polished_blackstone_bricks
fill 426 229 491 426 230 491 minecraft:blackstone
setblock 426 229 495 minecraft:polished_blackstone_bricks
setblock 441 229 465 minecraft:polished_blackstone_bricks
setblock 442 229 464 minecraft:polished_blackstone_bricks
fill 442 229 465 442 230 465 minecraft:blackstone
fill 443 229 464 443 230 464 minecraft:blackstone
setblock 445 229 466 minecraft:polished_blackstone_bricks
setblock 446 229 465 minecraft:polished_blackstone_bricks
setblock 447 229 464 minecraft:polished_blackstone_bricks
fill 447 229 465 448 229 465 minecraft:blackstone
fill 448 229 464 448 230 464 minecraft:blackstone
fill 448 229 489 448 229 490 minecraft:cyan_concrete
fill 450 229 487 452 229 487 minecraft:cyan_concrete
setblock 451 229 493 minecraft:cyan_concrete
setblock 453 229 488 minecraft:cyan_concrete
setblock 453 229 492 minecraft:cyan_concrete
setblock 457 229 464 minecraft:polished_blackstone_bricks
fill 458 229 464 458 230 464 minecraft:blackstone
fill 458 229 504 458 230 504 minecraft:blackstone
setblock 461 229 465 minecraft:polished_blackstone_bricks
setblock 462 229 464 minecraft:polished_blackstone_bricks
fill 462 229 465 462 230 465 minecraft:blackstone
fill 462 229 492 462 229 493 minecraft:blackstone
setblock 462 229 494 minecraft:polished_blackstone_bricks
fill 462 229 495 462 230 496 minecraft:blackstone
setblock 462 229 504 minecraft:polished_blackstone_bricks
fill 463 229 464 463 230 464 minecraft:blackstone
setblock 463 229 468 minecraft:polished_blackstone_bricks
fill 463 229 469 463 230 469 minecraft:blackstone
setblock 463 229 487 minecraft:blackstone
setblock 463 229 488 minecraft:polished_blackstone_bricks
fill 463 229 489 463 230 489 minecraft:blackstone
setblock 463 229 492 minecraft:blackstone
setblock 463 229 493 minecraft:polished_blackstone_bricks
fill 463 229 494 463 230 494 minecraft:blackstone
setblock 463 229 498 minecraft:polished_blackstone_bricks
fill 463 229 499 463 230 499 minecraft:blackstone
setblock 463 229 503 minecraft:polished_blackstone_bricks
fill 463 229 504 463 230 504 minecraft:blackstone
setblock 464 229 467 minecraft:polished_blackstone_bricks
fill 464 229 468 464 230 468 minecraft:blackstone
setblock 464 229 472 minecraft:polished_blackstone_bricks
fill 464 229 473 464 230 473 minecraft:blackstone
setblock 464 229 487 minecraft:polished_blackstone_bricks
fill 464 229 488 464 230 488 minecraft:blackstone
setblock 464 229 492 minecraft:polished_blackstone_bricks
fill 464 229 493 464 230 493 minecraft:blackstone
setblock 464 229 497 minecraft:polished_blackstone_bricks
fill 464 229 498 464 230 498 minecraft:blackstone
setblock 464 229 502 minecraft:polished_blackstone_bricks
fill 464 229 503 464 230 503 minecraft:blackstone
setblock 424 230 466 minecraft:polished_blackstone_bricks
setblock 424 230 467 minecraft:blackstone
setblock 424 230 471 minecraft:polished_blackstone_bricks
setblock 424 230 472 minecraft:blackstone
setblock 424 230 475 minecraft:blackstone
setblock 424 230 476 minecraft:polished_blackstone_bricks
setblock 424 230 477 minecraft:blackstone
fill 424 230 479 424 230 480 minecraft:blackstone
setblock 424 230 481 minecraft:polished_blackstone_bricks
setblock 424 230 482 minecraft:blackstone
setblock 424 230 486 minecraft:polished_blackstone_bricks
setblock 424 230 487 minecraft:blackstone
setblock 424 230 491 minecraft:polished_blackstone_bricks
setblock 424 230 492 minecraft:blackstone
setblock 424 230 496 minecraft:polished_blackstone_bricks
setblock 424 230 497 minecraft:blackstone
setblock 424 230 501 minecraft:polished_blackstone_bricks
setblock 424 230 502 minecraft:blackstone
setblock 425 230 486 minecraft:blackstone
setblock 425 230 490 minecraft:polished_blackstone_bricks
setblock 425 230 491 minecraft:blackstone
setblock 425 230 495 minecraft:polished_blackstone_bricks
setblock 425 230 496 minecraft:blackstone
setblock 426 230 489 minecraft:polished_blackstone_bricks
setblock 426 230 490 minecraft:blackstone
setblock 426 230 494 minecraft:polished_blackstone_bricks
setblock 426 230 495 minecraft:blackstone
setblock 440 230 465 minecraft:polished_blackstone_bricks
setblock 441 230 464 minecraft:polished_blackstone_bricks
setblock 441 230 465 minecraft:blackstone
setblock 442 230 464 minecraft:blackstone
setblock 444 230 466 minecraft:polished_blackstone_bricks
setblock 445 230 465 minecraft:polished_blackstone_bricks
setblock 446 230 464 minecraft:polished_blackstone_bricks
fill 446 230 465 447 230 465 minecraft:blackstone
setblock 447 230 464 minecraft:blackstone
setblock 456 230 464 minecraft:polished_blackstone_bricks
setblock 457 230 464 minecraft:blackstone
setblock 460 230 465 minecraft:polished_blackstone_bricks
setblock 461 230 464 minecraft:polished_blackstone_bricks
setblock 461 230 465 minecraft:blackstone
setblock 461 230 503 minecraft:blackstone
setblock 461 230 504 minecraft:polished_blackstone_bricks
setblock 462 230 464 minecraft:blackstone
setblock 462 230 490 minecraft:blackstone
setblock 462 230 492 minecraft:blackstone
setblock 462 230 493 minecraft:polished_blackstone_bricks
setblock 462 230 494 minecraft:blackstone
setblock 462 230 497 minecraft:blackstone
setblock 462 230 498 minecraft:polished_blackstone_bricks
setblock 462 230 503 minecraft:polished_blackstone_bricks
setblock 462 230 504 minecraft:blackstone
setblock 463 230 467 minecraft:polished_blackstone_bricks
setblock 463 230 468 minecraft:blackstone
setblock 463 230 472 minecraft:polished_blackstone_bricks
setblock 463 230 473 minecraft:blackstone
setblock 463 230 488 minecraft:blackstone
setblock 463 230 492 minecraft:polished_blackstone_bricks
setblock 463 230 493 minecraft:blackstone
setblock 463 230 497 minecraft:polished_blackstone_bricks
setblock 463 230 498 minecraft:blackstone
setblock 463 230 502 minecraft:polished_blackstone_bricks
setblock 463 230 503 minecraft:blackstone
setblock 464 230 466 minecraft:polished_blackstone_bricks
setblock 464 230 467 minecraft:blackstone
setblock 464 230 471 minecraft:polished_blackstone_bricks
setblock 464 230 472 minecraft:blackstone
setblock 464 230 476 minecraft:polished_blackstone_bricks
setblock 464 230 486 minecraft:polished_blackstone_bricks
setblock 464 230 487 minecraft:blackstone
setblock 464 230 491 minecraft:polished_blackstone_bricks
setblock 464 230 492 minecraft:blackstone
setblock 464 230 496 minecraft:polished_blackstone_bricks
setblock 464 230 497 minecraft:blackstone
setblock 464 230 501 minecraft:polished_blackstone_bricks
setblock 464 230 502 minecraft:blackstone
setblock 426 232 466 minecraft:light[level=11]
setblock 426 232 474 minecraft:light[level=11]
setblock 426 232 482 minecraft:light[level=11]
setblock 426 232 490 minecraft:light[level=11]
setblock 426 232 498 minecraft:light[level=11]
setblock 434 232 466 minecraft:light[level=11]
setblock 434 232 474 minecraft:light[level=11]
setblock 434 232 482 minecraft:light[level=11]
setblock 434 232 490 minecraft:light[level=11]
setblock 434 232 498 minecraft:light[level=11]
setblock 442 232 466 minecraft:light[level=11]
setblock 442 232 474 minecraft:light[level=11]
setblock 442 232 482 minecraft:light[level=11]
setblock 442 232 490 minecraft:light[level=11]
setblock 442 232 498 minecraft:light[level=11]
setblock 450 232 466 minecraft:light[level=11]
setblock 450 232 474 minecraft:light[level=11]
setblock 450 232 482 minecraft:light[level=11]
setblock 450 232 490 minecraft:light[level=11]
setblock 450 232 498 minecraft:light[level=11]
setblock 458 232 466 minecraft:light[level=11]
setblock 458 232 474 minecraft:light[level=11]
setblock 458 232 482 minecraft:light[level=11]
setblock 458 232 490 minecraft:light[level=11]
setblock 458 232 498 minecraft:light[level=11]
fill 424 236 464 424 237 464 minecraft:blackstone
fill 424 236 465 424 236 469 minecraft:soul_soil
fill 424 236 470 424 236 474 minecraft:blackstone
fill 424 236 475 424 236 479 minecraft:soul_soil
fill 424 236 480 424 236 484 minecraft:blackstone
fill 424 236 485 424 236 489 minecraft:soul_soil
fill 424 236 490 424 236 494 minecraft:blackstone
fill 424 236 495 424 236 499 minecraft:soul_soil
fill 424 236 500 424 236 504 minecraft:blackstone
fill 425 236 464 429 236 464 minecraft:soul_soil
fill 425 236 465 429 236 469 minecraft:blackstone
fill 425 236 470 429 236 474 minecraft:soul_soil
fill 425 236 475 429 236 479 minecraft:blackstone
fill 425 236 480 429 236 484 minecraft:soul_soil
fill 425 236 485 429 236 489 minecraft:blackstone
fill 425 236 490 429 236 494 minecraft:soul_soil
fill 425 236 495 429 236 499 minecraft:blackstone
fill 425 236 500 429 236 504 minecraft:soul_soil
fill 430 236 464 434 236 464 minecraft:blackstone
fill 430 236 465 434 236 469 minecraft:soul_soil
fill 430 236 470 434 236 474 minecraft:blackstone
fill 430 236 475 434 236 479 minecraft:soul_soil
fill 430 236 480 434 236 484 minecraft:blackstone
fill 430 236 485 434 236 489 minecraft:soul_soil
fill 430 236 490 434 236 494 minecraft:blackstone
fill 430 236 495 434 236 499 minecraft:soul_soil
fill 430 236 500 434 236 504 minecraft:blackstone
fill 435 236 464 439 236 464 minecraft:soul_soil
fill 435 236 465 439 236 469 minecraft:blackstone
fill 435 236 470 439 236 474 minecraft:soul_soil
fill 435 236 475 439 236 479 minecraft:blackstone
fill 435 236 480 439 236 484 minecraft:soul_soil
fill 435 236 485 439 236 489 minecraft:blackstone
fill 435 236 490 439 236 494 minecraft:soul_soil
fill 435 236 495 439 236 499 minecraft:blackstone
fill 435 236 500 439 236 504 minecraft:soul_soil
fill 440 236 464 444 236 464 minecraft:blackstone
fill 440 236 465 444 236 469 minecraft:soul_soil
fill 440 236 470 444 236 474 minecraft:blackstone
fill 440 236 475 444 236 479 minecraft:soul_soil
fill 440 236 480 443 236 484 minecraft:blackstone
fill 440 236 485 442 236 489 minecraft:soul_soil
fill 440 236 490 444 236 494 minecraft:blackstone
fill 440 236 495 444 236 499 minecraft:soul_soil
fill 440 236 500 444 236 504 minecraft:blackstone
fill 443 236 486 443 236 489 minecraft:soul_soil
fill 444 236 480 444 236 483 minecraft:blackstone
fill 444 236 487 444 236 489 minecraft:soul_soil
fill 445 236 464 449 236 464 minecraft:soul_soil
fill 445 236 465 449 236 469 minecraft:blackstone
fill 445 236 470 449 236 474 minecraft:soul_soil
fill 445 236 475 449 236 479 minecraft:blackstone
fill 445 236 480 449 236 482 minecraft:soul_soil
fill 445 236 488 449 236 489 minecraft:blackstone
fill 445 236 490 449 236 494 minecraft:soul_soil
fill 445 236 495 449 236 499 minecraft:blackstone
fill 445 236 500 449 236 504 minecraft:soul_soil
fill 446 236 483 449 236 483 minecraft:soul_soil
fill 446 236 487 449 236 487 minecraft:blackstone
fill 447 236 484 449 236 484 minecraft:soul_soil
fill 447 236 486 449 236 486 minecraft:blackstone
fill 448 236 485 449 236 485 minecraft:blackstone
fill 450 236 464 454 236 464 minecraft:blackstone
fill 450 236 465 454 236 469 minecraft:soul_soil
fill 450 236 470 454 236 474 minecraft:blackstone
fill 450 236 475 454 236 479 minecraft:soul_soil
fill 450 236 480 454 236 484 minecraft:blackstone
fill 450 236 485 454 236 489 minecraft:soul_soil
fill 450 236 490 454 236 494 minecraft:blackstone
fill 450 236 495 454 236 499 minecraft:soul_soil
fill 450 236 500 454 236 504 minecraft:blackstone
fill 455 236 464 459 236 464 minecraft:soul_soil
fill 455 236 465 459 236 469 minecraft:blackstone
fill 455 236 470 459 236 474 minecraft:soul_soil
fill 455 236 475 459 236 479 minecraft:blackstone
fill 455 236 480 459 236 484 minecraft:soul_soil
fill 455 236 485 459 236 489 minecraft:blackstone
fill 455 236 490 459 236 494 minecraft:soul_soil
fill 455 236 495 459 236 499 minecraft:blackstone
fill 455 236 500 459 236 504 minecraft:soul_soil
fill 460 236 464 464 236 464 minecraft:blackstone
fill 460 236 465 464 236 469 minecraft:soul_soil
fill 460 236 470 464 236 474 minecraft:blackstone
fill 460 236 475 464 236 479 minecraft:soul_soil
fill 460 236 480 464 236 484 minecraft:blackstone
fill 460 236 485 464 236 489 minecraft:soul_soil
fill 460 236 490 464 236 494 minecraft:blackstone
fill 460 236 495 464 236 499 minecraft:soul_soil
fill 460 236 500 464 236 504 minecraft:blackstone
fill 424 237 465 464 237 465 minecraft:polished_blackstone
fill 424 237 466 424 237 469 minecraft:soul_soil
fill 424 237 470 464 237 470 minecraft:polished_blackstone
fill 424 237 471 424 237 474 minecraft:blackstone
fill 424 237 475 464 237 475 minecraft:polished_blackstone
fill 424 237 476 424 237 479 minecraft:soul_soil
fill 424 237 480 464 237 480 minecraft:polished_blackstone
fill 424 237 481 424 237 484 minecraft:blackstone
fill 424 237 485 441 237 485 minecraft:polished_blackstone
fill 424 237 486 424 237 489 minecraft:soul_soil
fill 424 237 490 464 237 490 minecraft:polished_blackstone
fill 424 237 491 424 237 494 minecraft:blackstone
fill 424 237 495 464 237 495 minecraft:polished_blackstone
fill 424 237 496 424 237 499 minecraft:soul_soil
fill 424 237 500 464 237 500 minecraft:polished_blackstone
fill 424 237 501 424 237 504 minecraft:blackstone
setblock 425 237 464 minecraft:polished_blackstone
fill 425 237 466 425 237 469 minecraft:polished_blackstone
fill 425 237 471 425 237 474 minecraft:polished_blackstone
fill 425 237 476 425 237 479 minecraft:polished_blackstone
fill 425 237 481 425 237 484 minecraft:polished_blackstone
fill 425 237 486 425 237 489 minecraft:polished_blackstone
fill 425 237 491 425 237 494 minecraft:polished_blackstone
fill 425 237 496 425 237 499 minecraft:polished_blackstone
fill 425 237 501 425 237 504 minecraft:polished_blackstone
fill 426 237 464 429 237 464 minecraft:soul_soil
fill 426 237 466 429 237 469 minecraft:blackstone
fill 426 237 471 429 237 474 minecraft:soul_soil
fill 426 237 476 429 237 479 minecraft:blackstone
fill 426 237 481 429 237 484 minecraft:soul_soil
fill 426 237 486 429 237 489 minecraft:blackstone
fill 426 237 491 429 237 494 minecraft:soul_soil
fill 426 237 496 429 237 499 minecraft:blackstone
fill 426 237 501 429 237 504 minecraft:soul_soil
setblock 430 237 464 minecraft:polished_blackstone
fill 430 237 466 430 237 469 minecraft:polished_blackstone
fill 430 237 471 430 237 474 minecraft:polished_blackstone
fill 430 237 476 430 237 479 minecraft:polished_blackstone
fill 430 237 481 430 237 484 minecraft:polished_blackstone
fill 430 237 486 430 237 489 minecraft:polished_blackstone
fill 430 237 491 430 237 494 minecraft:polished_blackstone
fill 430 237 496 430 237 499 minecraft:polished_blackstone
fill 430 237 501 430 237 504 minecraft:polished_blackstone
fill 431 237 464 434 237 464 minecraft:blackstone
fill 431 237 466 434 237 469 minecraft:soul_soil
fill 431 237 471 434 237 474 minecraft:blackstone
fill 431 237 476 434 237 479 minecraft:soul_soil
fill 431 237 481 434 237 484 minecraft:blackstone
fill 431 237 486 434 237 489 minecraft:soul_soil
fill 431 237 491 434 237 494 minecraft:blackstone
fill 431 237 496 434 237 499 minecraft:soul_soil
fill 431 237 501 434 237 504 minecraft:blackstone
setblock 435 237 464 minecraft:polished_blackstone
fill 435 237 466 435 237 469 minecraft:polished_blackstone
fill 435 237 471 435 237 474 minecraft:polished_blackstone
fill 435 237 476 435 237 479 minecraft:polished_blackstone
fill 435 237 481 435 237 484 minecraft:polished_blackstone
fill 435 237 486 435 237 489 minecraft:polished_blackstone
fill 435 237 491 435 237 494 minecraft:polished_blackstone
fill 435 237 496 435 237 499 minecraft:polished_blackstone
fill 435 237 501 435 237 504 minecraft:polished_blackstone
fill 436 237 464 439 237 464 minecraft:soul_soil
fill 436 237 466 439 237 469 minecraft:blackstone
fill 436 237 471 439 237 474 minecraft:soul_soil
fill 436 237 476 439 237 479 minecraft:blackstone
fill 436 237 481 439 237 484 minecraft:soul_soil
fill 436 237 486 439 237 489 minecraft:blackstone
fill 436 237 491 439 237 494 minecraft:soul_soil
fill 436 237 496 439 237 499 minecraft:blackstone
fill 436 237 501 439 237 504 minecraft:soul_soil
setblock 440 237 464 minecraft:polished_blackstone
fill 440 237 466 440 237 469 minecraft:polished_blackstone
fill 440 237 471 440 237 474 minecraft:polished_blackstone
fill 440 237 476 440 237 479 minecraft:polished_blackstone
fill 440 237 481 440 237 484 minecraft:polished_blackstone
fill 440 237 486 440 237 489 minecraft:polished_blackstone
fill 440 237 491 440 237 494 minecraft:polished_blackstone
fill 440 237 496 440 237 499 minecraft:polished_blackstone
fill 440 237 501 440 237 504 minecraft:polished_blackstone
fill 441 237 464 444 237 464 minecraft:blackstone
fill 441 237 466 444 237 469 minecraft:soul_soil
fill 441 237 471 444 237 474 minecraft:blackstone
fill 441 237 476 444 237 479 minecraft:soul_soil
fill 441 237 481 441 237 484 minecraft:blackstone
fill 441 237 486 441 237 489 minecraft:soul_soil
fill 441 237 491 444 237 494 minecraft:blackstone
fill 441 237 496 444 237 499 minecraft:soul_soil
fill 441 237 501 444 237 504 minecraft:blackstone
fill 442 237 481 442 237 483 minecraft:blackstone
fill 442 237 484 442 237 486 minecraft:sea_lantern
fill 442 237 487 442 237 489 minecraft:soul_soil
fill 443 237 481 443 237 482 minecraft:blackstone
fill 443 237 483 443 237 484 minecraft:sea_lantern
fill 443 237 486 443 237 487 minecraft:sea_lantern
fill 443 237 488 443 237 489 minecraft:soul_soil
setblock 444 237 481 minecraft:blackstone
fill 444 237 482 444 237 483 minecraft:sea_lantern
fill 444 237 487 444 237 488 minecraft:sea_lantern
setblock 444 237 489 minecraft:soul_soil
setblock 445 237 464 minecraft:polished_blackstone
fill 445 237 466 445 237 469 minecraft:polished_blackstone
fill 445 237 471 445 237 474 minecraft:polished_blackstone
fill 445 237 476 445 237 479 minecraft:polished_blackstone
setblock 445 237 481 minecraft:polished_blackstone
fill 445 237 482 446 237 482 minecraft:sea_lantern
fill 445 237 488 446 237 488 minecraft:sea_lantern
setblock 445 237 489 minecraft:polished_blackstone
fill 445 237 491 445 237 494 minecraft:polished_blackstone
fill 445 237 496 445 237 499 minecraft:polished_blackstone
fill 445 237 501 445 237 504 minecraft:polished_blackstone
fill 446 237 464 449 237 464 minecraft:soul_soil
fill 446 237 466 449 237 469 minecraft:blackstone
fill 446 237 471 449 237 474 minecraft:soul_soil
fill 446 237 476 449 237 479 minecraft:blackstone
fill 446 237 481 449 237 481 minecraft:soul_soil
fill 446 237 483 447 237 483 minecraft:sea_lantern
fill 446 237 487 447 237 487 minecraft:sea_lantern
fill 446 237 489 449 237 489 minecraft:blackstone
fill 446 237 491 449 237 494 minecraft:soul_soil
fill 446 237 496 449 237 499 minecraft:blackstone
fill 446 237 501 449 237 504 minecraft:soul_soil
fill 447 237 482 449 237 482 minecraft:soul_soil
fill 447 237 484 448 237 484 minecraft:sea_lantern
fill 447 237 486 448 237 486 minecraft:sea_lantern
fill 447 237 488 449 237 488 minecraft:blackstone
fill 448 237 483 449 237 483 minecraft:soul_soil
setblock 448 237 485 minecraft:sea_lantern
fill 448 237 487 449 237 487 minecraft:blackstone
setblock 449 237 484 minecraft:soul_soil
fill 449 237 485 464 237 485 minecraft:polished_blackstone
setblock 449 237 486 minecraft:blackstone
setblock 450 237 464 minecraft:polished_blackstone
fill 450 237 466 450 237 469 minecraft:polished_blackstone
fill 450 237 471 450 237 474 minecraft:polished_blackstone
fill 450 237 476 450 237 479 minecraft:polished_blackstone
fill 450 237 481 450 237 484 minecraft:polished_blackstone
fill 450 237 486 450 237 489 minecraft:polished_blackstone
fill 450 237 491 450 237 494 minecraft:polished_blackstone
fill 450 237 496 450 237 499 minecraft:polished_blackstone
fill 450 237 501 450 237 504 minecraft:polished_blackstone
fill 451 237 464 454 237 464 minecraft:blackstone
fill 451 237 466 454 237 469 minecraft:soul_soil
fill 451 237 471 454 237 474 minecraft:blackstone
fill 451 237 476 454 237 479 minecraft:soul_soil
fill 451 237 481 454 237 484 minecraft:blackstone
fill 451 237 486 454 237 489 minecraft:soul_soil
fill 451 237 491 454 237 494 minecraft:blackstone
fill 451 237 496 454 237 499 minecraft:soul_soil
fill 451 237 501 454 237 504 minecraft:blackstone
setblock 455 237 464 minecraft:polished_blackstone
fill 455 237 466 455 237 469 minecraft:polished_blackstone
fill 455 237 471 455 237 474 minecraft:polished_blackstone
fill 455 237 476 455 237 479 minecraft:polished_blackstone
fill 455 237 481 455 237 484 minecraft:polished_blackstone
fill 455 237 486 455 237 489 minecraft:polished_blackstone
fill 455 237 491 455 237 494 minecraft:polished_blackstone
fill 455 237 496 455 237 499 minecraft:polished_blackstone
fill 455 237 501 455 237 504 minecraft:polished_blackstone
fill 456 237 464 459 237 464 minecraft:soul_soil
fill 456 237 466 459 237 469 minecraft:blackstone
fill 456 237 471 459 237 474 minecraft:soul_soil
fill 456 237 476 459 237 479 minecraft:blackstone
fill 456 237 481 459 237 484 minecraft:soul_soil
fill 456 237 486 459 237 489 minecraft:blackstone
fill 456 237 491 459 237 494 minecraft:soul_soil
fill 456 237 496 459 237 499 minecraft:blackstone
fill 456 237 501 459 237 504 minecraft:soul_soil
setblock 460 237 464 minecraft:polished_blackstone
fill 460 237 466 460 237 469 minecraft:polished_blackstone
fill 460 237 471 460 237 474 minecraft:polished_blackstone
fill 460 237 476 460 237 479 minecraft:polished_blackstone
fill 460 237 481 460 237 484 minecraft:polished_blackstone
fill 460 237 486 460 237 489 minecraft:polished_blackstone
fill 460 237 491 460 237 494 minecraft:polished_blackstone
fill 460 237 496 460 237 499 minecraft:polished_blackstone
fill 460 237 501 460 237 504 minecraft:polished_blackstone
fill 461 237 464 464 237 464 minecraft:blackstone
fill 461 237 466 464 237 469 minecraft:soul_soil
fill 461 237 471 464 237 474 minecraft:blackstone
fill 461 237 476 464 237 479 minecraft:soul_soil
fill 461 237 481 464 237 484 minecraft:blackstone
fill 461 237 486 464 237 489 minecraft:soul_soil
fill 461 237 491 464 237 494 minecraft:blackstone
fill 461 237 496 464 237 499 minecraft:soul_soil
fill 461 237 501 464 237 504 minecraft:blackstone
setblock 426 240 466 minecraft:light[level=11]
setblock 426 240 474 minecraft:light[level=11]
setblock 426 240 482 minecraft:light[level=11]
setblock 426 240 490 minecraft:light[level=11]
setblock 426 240 498 minecraft:light[level=11]
setblock 434 240 466 minecraft:light[level=11]
setblock 434 240 474 minecraft:light[level=11]
setblock 434 240 482 minecraft:light[level=11]
setblock 434 240 490 minecraft:light[level=11]
setblock 434 240 498 minecraft:light[level=11]
setblock 442 240 466 minecraft:light[level=11]
setblock 442 240 474 minecraft:light[level=11]
setblock 442 240 482 minecraft:light[level=11]
setblock 442 240 490 minecraft:light[level=11]
setblock 442 240 498 minecraft:light[level=11]
setblock 450 240 466 minecraft:light[level=11]
setblock 450 240 474 minecraft:light[level=11]
setblock 450 240 482 minecraft:light[level=11]
setblock 450 240 490 minecraft:light[level=11]
setblock 450 240 498 minecraft:light[level=11]
setblock 458 240 466 minecraft:light[level=11]
setblock 458 240 474 minecraft:light[level=11]
setblock 458 240 482 minecraft:light[level=11]
setblock 458 240 490 minecraft:light[level=11]
setblock 458 240 498 minecraft:light[level=11]
setblock 424 241 475 minecraft:polished_blackstone_bricks
fill 424 241 476 424 241 479 minecraft:blackstone
setblock 424 241 480 minecraft:polished_blackstone_bricks
fill 424 241 481 424 241 484 minecraft:blackstone
setblock 424 241 485 minecraft:polished_blackstone_bricks
setblock 424 241 486 minecraft:blackstone
fill 424 241 498 424 241 499 minecraft:blackstone
setblock 424 241 500 minecraft:polished_blackstone_bricks
fill 425 241 477 425 241 478 minecraft:blackstone
setblock 425 241 479 minecraft:polished_blackstone_bricks
fill 425 241 480 425 242 482 minecraft:blackstone
fill 432 241 464 434 241 464 minecraft:blackstone
fill 432 241 504 434 241 504 minecraft:blackstone
fill 434 241 503 435 241 503 minecraft:blackstone
setblock 435 241 464 minecraft:polished_blackstone_bricks
fill 435 241 465 438 241 465 minecraft:blackstone
setblock 435 241 504 minecraft:polished_blackstone_bricks
fill 436 241 464 439 241 464 minecraft:blackstone
setblock 436 241 503 minecraft:polished_blackstone_bricks
fill 436 241 504 439 241 504 minecraft:blackstone
fill 437 241 503 440 241 503 minecraft:blackstone
setblock 439 241 465 minecraft:polished_blackstone_bricks
setblock 440 241 464 minecraft:polished_blackstone_bricks
setblock 440 241 465 minecraft:blackstone
setblock 440 241 504 minecraft:polished_blackstone_bricks
fill 441 241 464 444 241 464 minecraft:blackstone
setblock 441 241 503 minecraft:polished_blackstone_bricks
fill 441 241 504 444 241 504 minecraft:blackstone
setblock 442 241 503 minecraft:blackstone
setblock 445 241 464 minecraft:polished_blackstone_bricks
setblock 445 241 504 minecraft:polished_blackstone_bricks
fill 446 241 504 449 241 504 minecraft:blackstone
fill 448 241 503 450 241 503 minecraft:blackstone
setblock 449 241 464 minecraft:blackstone
setblock 450 241 464 minecraft:polished_blackstone_bricks
setblock 450 241 504 minecraft:polished_blackstone_bricks
fill 451 241 464 454 241 464 minecraft:blackstone
setblock 451 241 502 minecraft:blackstone
setblock 451 241 503 minecraft:polished_blackstone_bricks
fill 451 241 504 454 241 504 minecraft:blackstone
setblock 452 241 502 minecraft:polished_blackstone_bricks
fill 452 241 503 455 241 503 minecraft:blackstone
setblock 453 241 501 minecraft:polished_blackstone_bricks
fill 453 241 502 456 241 502 minecraft:blackstone
fill 454 241 501 457 241 501 minecraft:blackstone
setblock 455 241 464 minecraft:polished_blackstone_bricks
setblock 455 241 504 minecraft:polished_blackstone_bricks
fill 456 241 464 459 241 464 minecraft:blackstone
setblock 456 241 503 minecraft:polished_blackstone_bricks
fill 456 241 504 459 241 504 minecraft:blackstone
setblock 457 241 502 minecraft:polished_blackstone_bricks
fill 457 241 503 460 241 503 minecraft:blackstone
setblock 458 241 501 minecraft:polished_blackstone_bricks
fill 458 241 502 461 241 502 minecraft:blackstone
setblock 459 241 501 minecraft:blackstone
setblock 460 241 504 minecraft:polished_blackstone_bricks
setblock 461 241 503 minecraft:polished_blackstone_bricks
fill 461 241 504 464 241 504 minecraft:blackstone
fill 462 241 498 462 241 501 minecraft:blackstone
fill 462 241 503 464 241 503 minecraft:blackstone
setblock 463 241 496 minecraft:polished_blackstone_bricks
fill 463 241 497 463 241 500 minecraft:blackstone
setblock 463 241 501 minecraft:polished_blackstone_bricks
fill 463 241 502 464 241 502 minecraft:blackstone
fill 464 241 477 464 241 479 minecraft:blackstone
setblock 464 241 480 minecraft:polished_blackstone_bricks
fill 464 241 481 464 241 484 minecraft:blackstone
setblock 464 241 485 minecraft:polished_blackstone_bricks
fill 464 241 493 464 241 494 minecraft:blackstone
setblock 464 241 495 minecraft:polished_blackstone_bricks
fill 464 241 496 464 241 499 minecraft:blackstone
setblock 464 241 500 minecraft:polished_blackstone_bricks
fill 464 241 501 464 244 501 minecraft:blackstone
fill 424 242 475 424 242 478 minecraft:blackstone
setblock 424 242 479 minecraft:polished_blackstone_bricks
fill 424 242 480 424 242 483 minecraft:blackstone
setblock 424 242 484 minecraft:polished_blackstone_bricks
fill 424 242 485 424 245 485 minecraft:blackstone
setblock 425 242 478 minecraft:polished_blackstone_bricks
fill 425 242 479 425 243 479 minecraft:blackstone
fill 426 242 480 430 243 484 minecraft:blackstone
fill 431 242 464 433 242 464 minecraft:blackstone
fill 431 242 504 433 242 504 minecraft:blackstone
setblock 434 242 464 minecraft:polished_blackstone_bricks
fill 434 242 465 437 242 465 minecraft:blackstone
setblock 434 242 503 minecraft:blackstone
setblock 434 242 504 minecraft:polished_blackstone_bricks
fill 435 242 464 438 242 464 minecraft:blackstone
setblock 435 242 503 minecraft:polished_blackstone_bricks
fill 435 242 504 438 242 504 minecraft:blackstone
fill 436 242 503 439 242 503 minecraft:blackstone
setblock 438 242 465 minecraft:polished_blackstone_bricks
setblock 439 242 464 minecraft:polished_blackstone_bricks
fill 439 242 465 439 245 465 minecraft:blackstone
setblock 439 242 504 minecraft:polished_blackstone_bricks
fill 440 242 464 443 242 464 minecraft:blackstone
setblock 440 242 503 minecraft:polished_blackstone_bricks
fill 440 242 504 443 242 504 minecraft:blackstone
fill 441 242 503 441 243 503 minecraft:blackstone
setblock 444 242 464 minecraft:polished_blackstone_bricks
setblock 444 242 504 minecraft:polished_blackstone_bricks
fill 445 242 504 448 242 504 minecraft:blackstone
fill 448 242 503 449 242 503 minecraft:blackstone
setblock 449 242 464 minecraft:polished_blackstone_bricks
setblock 449 242 504 minecraft:polished_blackstone_bricks
fill 450 242 464 453 242 464 minecraft:blackstone
setblock 450 242 503 minecraft:polished_blackstone_bricks
fill 450 242 504 453 242 504 minecraft:blackstone
setblock 451 242 502 minecraft:polished_blackstone_bricks
fill 451 242 503 454 242 503 minecraft:blackstone
fill 452 242 502 455 242 502 minecraft:blackstone
fill 453 242 501 456 242 501 minecraft:blackstone
setblock 454 242 464 minecraft:polished_blackstone_bricks
setblock 454 242 504 minecraft:polished_blackstone_bricks
fill 455 242 464 458 242 464 minecraft:blackstone
setblock 455 242 503 minecraft:polished_blackstone_bricks
fill 455 242 504 458 242 504 minecraft:blackstone
setblock 456 242 502 minecraft:polished_blackstone_bricks
fill 456 242 503 459 242 503 minecraft:blackstone
setblock 457 242 501 minecraft:polished_blackstone_bricks
fill 457 242 502 460 242 502 minecraft:blackstone
setblock 458 242 501 minecraft:blackstone
setblock 459 242 464 minecraft:polished_blackstone_bricks
setblock 459 242 504 minecraft:polished_blackstone_bricks
setblock 460 242 503 minecraft:polished_blackstone_bricks
fill 460 242 504 463 242 504 minecraft:blackstone
fill 461 242 503 462 242 503 minecraft:blackstone
fill 463 242 498 463 242 499 minecraft:blackstone
setblock 463 242 500 minecraft:polished_blackstone_bricks
setblock 463 242 501 minecraft:blackstone
setblock 464 242 478 minecraft:blackstone
setblock 464 242 479 minecraft:polished_blackstone_bricks
fill 464 242 480 464 242 483 minecraft:blackstone
setblock 464 242 484 minecraft:polished_blackstone_bricks
fill 464 242 495 464 242 498 minecraft:blackstone
setblock 464 242 499 minecraft:polished_blackstone_bricks
fill 464 242 500 464 244 500 minecraft:blackstone
fill 464 242 502 464 242 503 minecraft:blackstone
setblock 464 242 504 minecraft:polished_blackstone_bricks
fill 424 243 476 424 243 477 minecraft:blackstone
setblock 424 243 478 minecraft:polished_blackstone_bricks
fill 424 243 479 424 243 482 minecraft:blackstone
setblock 424 243 483 minecraft:polished_blackstone_bricks
fill 424 243 484 424 246 484 minecraft:blackstone
fill 425 243 480 425 243 481 minecraft:blackstone
setblock 425 243 482 minecraft:polished_blackstone_bricks
fill 431 243 464 432 243 464 minecraft:blackstone
fill 431 243 504 432 243 504 minecraft:blackstone
setblock 433 243 464 minecraft:polished_blackstone_bricks
fill 433 243 465 436 243 465 minecraft:blackstone
setblock 433 243 503 minecraft:blackstone
setblock 433 243 504 minecraft:polished_blackstone_bricks
fill 434 243 464 437 243 464 minecraft:blackstone
setblock 434 243 503 minecraft:polished_blackstone_bricks
fill 434 243 504 437 243 504 minecraft:blackstone
fill 435 243 503 438 243 503 minecraft:blackstone
setblock 437 243 465 minecraft:polished_blackstone_bricks
setblock 438 243 464 minecraft:polished_blackstone_bricks
fill 438 243 465 438 246 465 minecraft:blackstone
setblock 438 243 504 minecraft:polished_blackstone_bricks
fill 439 243 464 442 243 464 minecraft:blackstone
setblock 439 243 503 minecraft:polished_blackstone_bricks
fill 439 243 504 442 243 504 minecraft:blackstone
fill 440 243 503 440 246 503 minecraft:blackstone
setblock 443 243 464 minecraft:polished_blackstone_bricks
setblock 443 243 504 minecraft:polished_blackstone_bricks
fill 444 243 464 445 245 464 minecraft:blackstone
fill 444 243 504 447 243 504 minecraft:blackstone
setblock 447 243 464 minecraft:blackstone
fill 447 243 503 448 243 503 minecraft:blackstone
setblock 448 243 464 minecraft:polished_blackstone_bricks
setblock 448 243 504 minecraft:polished_blackstone_bricks
fill 449 243 464 452 243 464 minecraft:blackstone
setblock 449 243 503 minecraft:polished_blackstone_bricks
fill 449 243 504 452 243 504 minecraft:blackstone
setblock 450 243 502 minecraft:polished_blackstone_bricks
fill 450 243 503 453 243 503 minecraft:blackstone
fill 451 243 502 454 243 502 minecraft:blackstone
setblock 453 243 464 minecraft:polished_blackstone_bricks
fill 453 243 501 455 243 501 minecraft:blackstone
setblock 453 243 504 minecraft:polished_blackstone_bricks
fill 454 243 464 457 243 464 minecraft:blackstone
setblock 454 243 503 minecraft:polished_blackstone_bricks
fill 454 243 504 457 243 504 minecraft:blackstone
setblock 455 243 502 minecraft:polished_blackstone_bricks
fill 455 243 503 458 243 503 minecraft:blackstone
setblock 456 243 501 minecraft:polished_blackstone_bricks
fill 456 243 502 459 243 502 minecraft:blackstone
setblock 457 243 501 minecraft:blackstone
setblock 458 243 464 minecraft:polished_blackstone_bricks
setblock 458 243 504 minecraft:polished_blackstone_bricks
setblock 459 243 503 minecraft:polished_blackstone_bricks
fill 459 243 504 462 243 504 minecraft:blackstone
fill 460 243 503 461 244 503 minecraft:blackstone
setblock 463 243 504 minecraft:polished_blackstone_bricks
fill 464 243 479 464 243 482 minecraft:blackstone
setblock 464 243 483 minecraft:polished_blackstone_bricks
fill 464 243 484 464 245 485 minecraft:blackstone
setblock 464 243 497 minecraft:blackstone
setblock 464 243 498 minecraft:polished_blackstone_bricks
fill 464 243 499 464 244 499 minecraft:blackstone
setblock 464 243 502 minecraft:blackstone
setblock 464 243 503 minecraft:polished_blackstone_bricks
setblock 424 244 477 minecraft:polished_blackstone_bricks
fill 424 244 478 424 244 481 minecraft:blackstone
setblock 424 244 482 minecraft:polished_blackstone_bricks
fill 424 244 483 424 247 483 minecraft:blackstone
setblock 424 244 486 minecraft:blackstone
setblock 425 244 480 minecraft:blackstone
setblock 425 244 481 minecraft:polished_blackstone_bricks
fill 425 244 482 425 247 482 minecraft:blackstone
fill 427 244 482 429 248 482 minecraft:polished_blackstone_bricks
fill 429 244 464 431 244 464 minecraft:blackstone
fill 430 244 504 431 244 504 minecraft:blackstone
setblock 432 244 464 minecraft:polished_blackstone_bricks
fill 432 244 465 435 244 465 minecraft:blackstone
setblock 432 244 503 minecraft:blackstone
setblock 432 244 504 minecraft:polished_blackstone_bricks
fill 433 244 464 436 244 464 minecraft:blackstone
setblock 433 244 503 minecraft:polished_blackstone_bricks
fill 433 244 504 436 244 504 minecraft:blackstone
fill 434 244 503 437 244 503 minecraft:blackstone
setblock 436 244 465 minecraft:polished_blackstone_bricks
setblock 437 244 464 minecraft:polished_blackstone_bricks
fill 437 244 465 437 247 465 minecraft:blackstone
setblock 437 244 504 minecraft:polished_blackstone_bricks
fill 438 244 464 441 244 464 minecraft:blackstone
setblock 438 244 503 minecraft:polished_blackstone_bricks
fill 438 244 504 441 244 504 minecraft:blackstone
fill 439 244 503 439 247 503 minecraft:blackstone
setblock 442 244 464 minecraft:polished_blackstone_bricks
setblock 442 244 504 minecraft:polished_blackstone_bricks
fill 443 244 464 443 247 464 minecraft:blackstone
fill 443 244 504 446 244 504 minecraft:blackstone
setblock 446 244 464 minecraft:blackstone
setblock 447 244 464 minecraft:polished_blackstone_bricks
setblock 447 244 503 minecraft:blackstone
setblock 447 244 504 minecraft:polished_blackstone_bricks
fill 448 244 464 451 244 464 minecraft:blackstone
setblock 448 244 503 minecraft:polished_blackstone_bricks
fill 448 244 504 451 244 504 minecraft:blackstone
fill 449 244 503 452 244 503 minecraft:blackstone
fill 450 244 502 453 244 502 minecraft:blackstone
setblock 452 244 464 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/117_7 1t
