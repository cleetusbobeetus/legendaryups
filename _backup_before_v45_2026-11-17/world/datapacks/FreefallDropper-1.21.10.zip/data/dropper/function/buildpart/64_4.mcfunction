fill 191 288 278 193 303 280 minecraft:quartz_pillar
fill 191 288 299 191 300 299 minecraft:prismarine_bricks
fill 191 288 312 193 303 314 minecraft:quartz_pillar
fill 194 288 309 198 289 313 minecraft:dark_prismarine
fill 196 288 314 196 288 315 minecraft:dark_prismarine
fill 208 288 277 210 303 279 minecraft:quartz_pillar
fill 208 288 313 210 288 315 minecraft:quartz_pillar
fill 214 288 309 215 289 313 minecraft:dark_prismarine
fill 216 288 285 216 289 286 minecraft:dark_prismarine
fill 216 288 288 216 289 288 minecraft:dark_prismarine
fill 217 288 284 217 289 284 minecraft:dark_prismarine
fill 218 288 290 218 289 290 minecraft:dark_prismarine
fill 219 288 283 220 289 283 minecraft:dark_prismarine
fill 221 288 290 221 289 290 minecraft:dark_prismarine
fill 222 288 284 222 289 284 minecraft:dark_prismarine
fill 223 288 286 223 289 288 minecraft:dark_prismarine
fill 225 288 277 225 300 277 minecraft:prismarine_bricks
fill 225 288 278 227 288 280 minecraft:quartz_pillar
fill 225 288 310 227 300 311 minecraft:prismarine_bricks
fill 225 288 312 227 303 314 minecraft:quartz_pillar
fill 226 288 295 228 303 297 minecraft:quartz_pillar
fill 230 288 282 230 308 282 minecraft:prismarine
fill 188 289 303 188 308 303 minecraft:prismarine
setblock 189 289 300 minecraft:sea_lantern
setblock 189 289 302 minecraft:sea_lantern
setblock 189 289 304 minecraft:sea_lantern
setblock 189 289 306 minecraft:sea_lantern
setblock 190 289 299 minecraft:sea_lantern
setblock 190 289 301 minecraft:sea_lantern
setblock 190 289 303 minecraft:sea_lantern
setblock 190 289 305 minecraft:sea_lantern
setblock 190 289 307 minecraft:sea_lantern
setblock 191 289 300 minecraft:sea_lantern
setblock 191 289 302 minecraft:sea_lantern
setblock 191 289 304 minecraft:sea_lantern
setblock 191 289 306 minecraft:sea_lantern
setblock 192 289 299 minecraft:sea_lantern
setblock 192 289 301 minecraft:sea_lantern
setblock 192 289 303 minecraft:sea_lantern
setblock 192 289 305 minecraft:sea_lantern
setblock 192 289 307 minecraft:sea_lantern
setblock 193 289 300 minecraft:sea_lantern
setblock 193 289 302 minecraft:sea_lantern
setblock 193 289 304 minecraft:sea_lantern
setblock 193 289 306 minecraft:sea_lantern
setblock 194 289 299 minecraft:sea_lantern
setblock 194 289 301 minecraft:sea_lantern
setblock 194 289 303 minecraft:sea_lantern
setblock 194 289 305 minecraft:sea_lantern
setblock 194 289 307 minecraft:sea_lantern
setblock 203 289 312 minecraft:sea_lantern
setblock 203 289 314 minecraft:sea_lantern
setblock 203 289 316 minecraft:sea_lantern
setblock 204 289 311 minecraft:sea_lantern
setblock 204 289 313 minecraft:sea_lantern
setblock 204 289 315 minecraft:sea_lantern
setblock 205 289 312 minecraft:sea_lantern
setblock 205 289 314 minecraft:sea_lantern
setblock 205 289 316 minecraft:sea_lantern
setblock 206 289 311 minecraft:sea_lantern
setblock 206 289 313 minecraft:sea_lantern
setblock 206 289 315 minecraft:sea_lantern
setblock 207 289 308 minecraft:sea_lantern
setblock 207 289 310 minecraft:sea_lantern
setblock 207 289 312 minecraft:sea_lantern
setblock 207 289 314 minecraft:sea_lantern
setblock 207 289 316 minecraft:sea_lantern
setblock 208 289 309 minecraft:sea_lantern
setblock 208 289 311 minecraft:sea_lantern
setblock 208 289 313 minecraft:sea_lantern
fill 208 289 314 208 303 314 minecraft:quartz_pillar
setblock 208 289 315 minecraft:sea_lantern
setblock 209 289 308 minecraft:sea_lantern
setblock 209 289 310 minecraft:sea_lantern
setblock 209 289 312 minecraft:sea_lantern
fill 209 289 313 209 303 313 minecraft:quartz_pillar
setblock 209 289 314 minecraft:sea_lantern
fill 209 289 315 209 303 315 minecraft:quartz_pillar
setblock 209 289 316 minecraft:sea_lantern
setblock 210 289 309 minecraft:sea_lantern
setblock 210 289 311 minecraft:sea_lantern
setblock 210 289 313 minecraft:sea_lantern
fill 210 289 314 210 303 314 minecraft:quartz_pillar
setblock 210 289 315 minecraft:sea_lantern
setblock 211 289 308 minecraft:sea_lantern
setblock 211 289 310 minecraft:sea_lantern
setblock 211 289 312 minecraft:sea_lantern
setblock 211 289 314 minecraft:sea_lantern
setblock 211 289 316 minecraft:sea_lantern
setblock 212 289 309 minecraft:sea_lantern
setblock 212 289 311 minecraft:sea_lantern
setblock 212 289 313 minecraft:sea_lantern
setblock 212 289 315 minecraft:sea_lantern
setblock 213 289 308 minecraft:sea_lantern
setblock 213 289 310 minecraft:sea_lantern
setblock 213 289 312 minecraft:sea_lantern
setblock 213 289 314 minecraft:sea_lantern
setblock 213 289 316 minecraft:sea_lantern
setblock 215 289 287 minecraft:dark_prismarine
setblock 216 289 284 minecraft:dark_prismarine
setblock 216 289 289 minecraft:dark_prismarine
setblock 217 289 276 minecraft:sea_lantern
setblock 217 289 278 minecraft:sea_lantern
setblock 217 289 280 minecraft:sea_lantern
setblock 217 289 282 minecraft:sea_lantern
setblock 217 289 290 minecraft:dark_prismarine
setblock 218 289 277 minecraft:sea_lantern
setblock 218 289 279 minecraft:sea_lantern
setblock 218 289 281 minecraft:sea_lantern
setblock 218 289 283 minecraft:dark_prismarine
fill 218 289 291 220 289 291 minecraft:dark_prismarine
setblock 219 289 276 minecraft:sea_lantern
setblock 219 289 278 minecraft:sea_lantern
setblock 219 289 280 minecraft:sea_lantern
setblock 219 289 282 minecraft:sea_lantern
setblock 220 289 277 minecraft:sea_lantern
setblock 220 289 279 minecraft:sea_lantern
setblock 220 289 281 minecraft:sea_lantern
setblock 221 289 276 minecraft:sea_lantern
setblock 221 289 278 minecraft:sea_lantern
setblock 221 289 280 minecraft:sea_lantern
setblock 221 289 282 minecraft:sea_lantern
setblock 221 289 283 minecraft:dark_prismarine
setblock 222 289 277 minecraft:sea_lantern
setblock 222 289 279 minecraft:sea_lantern
setblock 222 289 281 minecraft:sea_lantern
setblock 222 289 290 minecraft:dark_prismarine
setblock 223 289 276 minecraft:sea_lantern
setblock 223 289 278 minecraft:sea_lantern
setblock 223 289 280 minecraft:sea_lantern
setblock 223 289 282 minecraft:sea_lantern
setblock 223 289 285 minecraft:dark_prismarine
setblock 223 289 289 minecraft:dark_prismarine
setblock 224 289 277 minecraft:sea_lantern
setblock 224 289 279 minecraft:sea_lantern
setblock 224 289 281 minecraft:sea_lantern
setblock 225 289 276 minecraft:sea_lantern
setblock 225 289 278 minecraft:sea_lantern
fill 225 289 279 227 303 279 minecraft:quartz_pillar
setblock 225 289 280 minecraft:sea_lantern
setblock 225 289 282 minecraft:sea_lantern
fill 226 289 278 227 303 278 minecraft:quartz_pillar
fill 226 289 280 227 303 280 minecraft:quartz_pillar
setblock 227 289 275 minecraft:prismarine_bricks
fill 189 290 300 189 291 300 minecraft:prismarine_bricks
fill 189 290 302 189 291 302 minecraft:prismarine_bricks
fill 189 290 304 189 291 304 minecraft:prismarine_bricks
fill 189 290 306 189 291 306 minecraft:prismarine_bricks
fill 190 290 299 190 291 299 minecraft:prismarine_bricks
fill 190 290 301 190 291 301 minecraft:prismarine_bricks
fill 190 290 303 190 291 303 minecraft:prismarine_bricks
fill 190 290 305 190 291 305 minecraft:prismarine_bricks
fill 190 290 307 190 291 307 minecraft:prismarine_bricks
fill 191 290 300 191 291 300 minecraft:prismarine_bricks
fill 191 290 302 191 291 302 minecraft:prismarine_bricks
fill 191 290 304 191 291 304 minecraft:prismarine_bricks
fill 191 290 306 191 291 306 minecraft:prismarine_bricks
fill 192 290 299 192 291 299 minecraft:prismarine_bricks
fill 192 290 301 192 291 301 minecraft:prismarine_bricks
fill 192 290 303 192 291 303 minecraft:prismarine_bricks
fill 192 290 305 192 291 305 minecraft:prismarine_bricks
fill 192 290 307 192 291 307 minecraft:prismarine_bricks
fill 193 290 300 193 291 300 minecraft:prismarine_bricks
fill 193 290 302 193 291 302 minecraft:prismarine_bricks
fill 193 290 304 193 291 304 minecraft:prismarine_bricks
fill 193 290 306 193 291 306 minecraft:prismarine_bricks
fill 194 290 299 194 291 299 minecraft:prismarine_bricks
fill 194 290 301 194 291 301 minecraft:prismarine_bricks
fill 194 290 303 194 291 303 minecraft:prismarine_bricks
fill 194 290 305 194 291 305 minecraft:prismarine_bricks
fill 194 290 307 194 291 307 minecraft:prismarine_bricks
fill 195 290 310 197 291 312 minecraft:prismarine_bricks
fill 203 290 312 203 291 312 minecraft:prismarine_bricks
fill 203 290 314 203 291 314 minecraft:prismarine_bricks
fill 203 290 316 203 291 316 minecraft:prismarine_bricks
fill 204 290 311 204 291 311 minecraft:prismarine_bricks
fill 204 290 313 204 291 313 minecraft:prismarine_bricks
fill 204 290 315 204 291 315 minecraft:prismarine_bricks
fill 205 290 312 205 291 312 minecraft:prismarine_bricks
fill 205 290 314 205 291 314 minecraft:prismarine_bricks
fill 205 290 316 205 291 316 minecraft:prismarine_bricks
fill 206 290 311 206 291 311 minecraft:prismarine_bricks
fill 206 290 313 206 291 313 minecraft:prismarine_bricks
fill 206 290 315 206 291 315 minecraft:prismarine_bricks
fill 207 290 308 207 291 308 minecraft:prismarine_bricks
fill 207 290 310 207 291 310 minecraft:prismarine_bricks
fill 207 290 312 207 291 312 minecraft:prismarine_bricks
fill 207 290 314 207 291 314 minecraft:prismarine_bricks
fill 207 290 316 207 291 316 minecraft:prismarine_bricks
fill 208 290 309 208 291 309 minecraft:prismarine_bricks
fill 208 290 311 208 291 311 minecraft:prismarine_bricks
fill 208 290 313 208 291 313 minecraft:quartz_pillar
fill 208 290 315 208 291 315 minecraft:quartz_pillar
fill 209 290 308 209 291 308 minecraft:prismarine_bricks
fill 209 290 310 209 291 310 minecraft:prismarine_bricks
fill 209 290 312 209 291 312 minecraft:prismarine_bricks
fill 209 290 314 209 291 314 minecraft:quartz_pillar
fill 209 290 316 209 291 316 minecraft:prismarine_bricks
fill 210 290 309 210 291 309 minecraft:prismarine_bricks
fill 210 290 311 210 291 311 minecraft:prismarine_bricks
fill 210 290 313 210 291 313 minecraft:quartz_pillar
fill 210 290 315 210 291 315 minecraft:quartz_pillar
setblock 210 290 317 minecraft:sea_lantern
fill 211 290 308 211 291 308 minecraft:prismarine_bricks
fill 211 290 310 211 291 310 minecraft:prismarine_bricks
fill 211 290 312 211 291 312 minecraft:prismarine_bricks
fill 211 290 314 211 291 314 minecraft:prismarine_bricks
fill 211 290 316 211 291 316 minecraft:prismarine_bricks
fill 211 290 317 211 303 317 minecraft:prismarine
fill 212 290 309 212 291 309 minecraft:prismarine_bricks
fill 212 290 311 212 291 311 minecraft:prismarine_bricks
fill 212 290 313 212 291 313 minecraft:prismarine_bricks
fill 212 290 315 212 291 315 minecraft:prismarine_bricks
fill 213 290 308 213 291 308 minecraft:prismarine_bricks
fill 213 290 310 214 291 310 minecraft:prismarine_bricks
fill 213 290 312 214 291 312 minecraft:prismarine_bricks
fill 213 290 314 213 291 314 minecraft:prismarine_bricks
fill 213 290 316 213 291 316 minecraft:prismarine_bricks
fill 214 290 311 214 294 311 minecraft:prismarine_bricks
fill 217 290 276 217 291 276 minecraft:prismarine_bricks
fill 217 290 278 217 291 278 minecraft:prismarine_bricks
fill 217 290 280 217 291 280 minecraft:prismarine_bricks
fill 217 290 282 217 291 282 minecraft:prismarine_bricks
fill 218 290 277 218 291 277 minecraft:prismarine_bricks
fill 218 290 279 218 291 279 minecraft:prismarine_bricks
fill 218 290 281 218 291 281 minecraft:prismarine_bricks
fill 218 290 286 218 294 286 minecraft:prismarine_bricks
fill 219 290 276 219 291 276 minecraft:prismarine_bricks
fill 219 290 278 219 291 278 minecraft:prismarine_bricks
fill 219 290 280 219 291 280 minecraft:prismarine_bricks
fill 219 290 282 219 291 282 minecraft:prismarine_bricks
fill 220 290 277 220 291 277 minecraft:prismarine_bricks
fill 220 290 279 220 291 279 minecraft:prismarine_bricks
fill 220 290 281 220 291 281 minecraft:prismarine_bricks
fill 220 290 288 220 293 288 minecraft:prismarine_bricks
fill 221 290 276 221 291 276 minecraft:prismarine_bricks
fill 221 290 278 221 291 278 minecraft:prismarine_bricks
fill 221 290 280 221 291 280 minecraft:prismarine_bricks
fill 221 290 282 221 291 282 minecraft:prismarine_bricks
fill 221 290 286 221 291 286 minecraft:prismarine_bricks
fill 222 290 277 222 291 277 minecraft:prismarine_bricks
fill 222 290 279 222 291 279 minecraft:prismarine_bricks
fill 222 290 281 222 291 281 minecraft:prismarine_bricks
fill 223 290 276 223 291 276 minecraft:prismarine_bricks
fill 223 290 278 223 291 278 minecraft:prismarine_bricks
fill 223 290 280 223 291 280 minecraft:prismarine_bricks
fill 223 290 282 223 291 282 minecraft:prismarine_bricks
fill 224 290 277 224 291 277 minecraft:prismarine_bricks
fill 224 290 279 224 291 279 minecraft:prismarine_bricks
fill 224 290 281 224 291 281 minecraft:prismarine_bricks
fill 225 290 276 225 291 276 minecraft:prismarine_bricks
fill 225 290 278 225 291 278 minecraft:quartz_pillar
fill 225 290 280 225 291 280 minecraft:quartz_pillar
fill 225 290 282 225 291 282 minecraft:prismarine_bricks
fill 227 290 275 227 300 275 minecraft:prismarine
setblock 188 291 289 minecraft:prismarine_bricks
fill 188 291 290 188 307 290 minecraft:prismarine
setblock 191 291 285 minecraft:light[level=12]
setblock 191 291 292 minecraft:light[level=12]
setblock 198 291 278 minecraft:light[level=12]
setblock 198 291 285 minecraft:light[level=12]
setblock 198 291 292 minecraft:light[level=12]
setblock 198 291 299 minecraft:light[level=12]
setblock 198 291 306 minecraft:light[level=12]
setblock 198 291 313 minecraft:light[level=12]
setblock 199 291 317 minecraft:prismarine_bricks
setblock 205 291 278 minecraft:light[level=12]
setblock 205 291 285 minecraft:light[level=12]
setblock 205 291 292 minecraft:light[level=12]
setblock 205 291 299 minecraft:light[level=12]
setblock 205 291 306 minecraft:light[level=12]
fill 210 291 317 210 308 317 minecraft:prismarine
setblock 212 291 278 minecraft:light[level=12]
setblock 212 291 285 minecraft:light[level=12]
setblock 212 291 292 minecraft:light[level=12]
setblock 212 291 299 minecraft:light[level=12]
setblock 212 291 306 minecraft:light[level=12]
setblock 219 291 285 minecraft:light[level=12]
setblock 219 291 292 minecraft:light[level=12]
setblock 219 291 299 minecraft:light[level=12]
setblock 219 291 306 minecraft:light[level=12]
setblock 219 291 313 minecraft:light[level=12]
fill 224 291 310 224 291 313 minecraft:dark_prismarine
fill 225 291 283 226 291 283 minecraft:dark_prismarine
fill 225 291 309 227 291 309 minecraft:dark_prismarine
setblock 226 291 285 minecraft:light[level=12]
setblock 226 291 306 minecraft:light[level=12]
setblock 227 291 282 minecraft:dark_prismarine
fill 228 291 280 228 291 281 minecraft:dark_prismarine
fill 228 291 310 228 291 312 minecraft:dark_prismarine
fill 188 292 281 188 308 281 minecraft:prismarine
fill 188 292 282 188 292 283 minecraft:sea_lantern
fill 188 292 284 188 308 284 minecraft:prismarine
fill 188 292 289 188 308 289 minecraft:prismarine
fill 188 292 293 188 305 293 minecraft:prismarine
fill 188 292 294 188 292 295 minecraft:sea_lantern
fill 188 292 296 188 308 296 minecraft:prismarine
fill 188 292 305 188 308 305 minecraft:prismarine
fill 188 292 306 188 292 307 minecraft:sea_lantern
fill 188 292 308 188 308 308 minecraft:prismarine
fill 188 292 317 188 308 317 minecraft:prismarine
setblock 189 292 300 minecraft:sea_lantern
setblock 189 292 302 minecraft:sea_lantern
setblock 189 292 304 minecraft:sea_lantern
setblock 189 292 306 minecraft:sea_lantern
fill 189 292 317 190 292 317 minecraft:sea_lantern
setblock 190 292 299 minecraft:sea_lantern
setblock 190 292 301 minecraft:sea_lantern
setblock 190 292 303 minecraft:sea_lantern
setblock 190 292 305 minecraft:sea_lantern
setblock 190 292 307 minecraft:sea_lantern
setblock 191 292 300 minecraft:sea_lantern
setblock 191 292 302 minecraft:sea_lantern
setblock 191 292 304 minecraft:sea_lantern
setblock 191 292 306 minecraft:sea_lantern
fill 191 292 317 191 308 317 minecraft:prismarine
setblock 192 292 299 minecraft:sea_lantern
setblock 192 292 301 minecraft:sea_lantern
setblock 192 292 303 minecraft:sea_lantern
setblock 192 292 305 minecraft:sea_lantern
setblock 192 292 307 minecraft:sea_lantern
setblock 193 292 300 minecraft:sea_lantern
setblock 193 292 302 minecraft:sea_lantern
setblock 193 292 304 minecraft:sea_lantern
setblock 193 292 306 minecraft:sea_lantern
setblock 194 292 299 minecraft:sea_lantern
setblock 194 292 301 minecraft:sea_lantern
setblock 194 292 303 minecraft:sea_lantern
setblock 194 292 305 minecraft:sea_lantern
setblock 194 292 307 minecraft:sea_lantern
setblock 195 292 275 minecraft:prismarine_bricks
fill 195 292 311 197 294 311 minecraft:prismarine_bricks
fill 196 292 275 197 292 275 minecraft:sea_lantern
fill 196 292 310 196 294 310 minecraft:prismarine_bricks
fill 196 292 312 196 294 312 minecraft:prismarine_bricks
fill 198 292 275 198 308 275 minecraft:prismarine
fill 199 292 317 200 308 317 minecraft:prismarine
fill 201 292 317 202 292 317 minecraft:sea_lantern
setblock 203 292 312 minecraft:sea_lantern
setblock 203 292 314 minecraft:sea_lantern
setblock 203 292 316 minecraft:sea_lantern
fill 203 292 317 203 308 317 minecraft:prismarine
setblock 204 292 311 minecraft:sea_lantern
setblock 204 292 313 minecraft:sea_lantern
setblock 204 292 315 minecraft:sea_lantern
setblock 205 292 312 minecraft:sea_lantern
setblock 205 292 314 minecraft:sea_lantern
setblock 205 292 316 minecraft:sea_lantern
setblock 206 292 311 minecraft:sea_lantern
setblock 206 292 313 minecraft:sea_lantern
setblock 206 292 315 minecraft:sea_lantern
fill 207 292 275 207 297 275 minecraft:prismarine
setblock 207 292 308 minecraft:sea_lantern
setblock 207 292 310 minecraft:sea_lantern
setblock 207 292 312 minecraft:sea_lantern
setblock 207 292 314 minecraft:sea_lantern
setblock 207 292 316 minecraft:sea_lantern
fill 208 292 275 209 292 275 minecraft:sea_lantern
setblock 208 292 309 minecraft:sea_lantern
setblock 208 292 311 minecraft:sea_lantern
setblock 208 292 313 minecraft:sea_lantern
setblock 208 292 315 minecraft:sea_lantern
setblock 209 292 308 minecraft:sea_lantern
setblock 209 292 310 minecraft:sea_lantern
setblock 209 292 312 minecraft:sea_lantern
setblock 209 292 314 minecraft:sea_lantern
setblock 209 292 316 minecraft:sea_lantern
fill 210 292 275 210 308 275 minecraft:prismarine
setblock 210 292 309 minecraft:sea_lantern
setblock 210 292 311 minecraft:sea_lantern
setblock 210 292 313 minecraft:sea_lantern
setblock 210 292 315 minecraft:sea_lantern
setblock 211 292 308 minecraft:sea_lantern
setblock 211 292 310 minecraft:sea_lantern
setblock 211 292 312 minecraft:sea_lantern
setblock 211 292 314 minecraft:sea_lantern
setblock 211 292 316 minecraft:sea_lantern
setblock 212 292 309 minecraft:sea_lantern
setblock 212 292 311 minecraft:sea_lantern
setblock 212 292 313 minecraft:sea_lantern
setblock 212 292 315 minecraft:sea_lantern
fill 212 292 317 212 306 317 minecraft:prismarine
setblock 213 292 308 minecraft:sea_lantern
setblock 213 292 310 minecraft:sea_lantern
setblock 213 292 312 minecraft:sea_lantern
setblock 213 292 314 minecraft:sea_lantern
fill 213 292 316 213 292 317 minecraft:sea_lantern
setblock 214 292 317 minecraft:sea_lantern
fill 215 292 317 215 308 317 minecraft:prismarine
setblock 217 292 276 minecraft:sea_lantern
setblock 217 292 278 minecraft:sea_lantern
setblock 217 292 280 minecraft:sea_lantern
setblock 217 292 282 minecraft:sea_lantern
setblock 218 292 277 minecraft:sea_lantern
setblock 218 292 279 minecraft:sea_lantern
setblock 218 292 281 minecraft:sea_lantern
fill 219 292 275 219 308 275 minecraft:prismarine
setblock 219 292 276 minecraft:sea_lantern
setblock 219 292 278 minecraft:sea_lantern
setblock 219 292 280 minecraft:sea_lantern
setblock 219 292 282 minecraft:sea_lantern
fill 220 292 275 221 292 275 minecraft:sea_lantern
setblock 220 292 277 minecraft:sea_lantern
setblock 220 292 279 minecraft:sea_lantern
setblock 220 292 281 minecraft:sea_lantern
setblock 221 292 276 minecraft:sea_lantern
setblock 221 292 278 minecraft:sea_lantern
setblock 221 292 280 minecraft:sea_lantern
setblock 221 292 282 minecraft:sea_lantern
fill 222 292 275 222 308 275 minecraft:prismarine
setblock 222 292 277 minecraft:sea_lantern
setblock 222 292 279 minecraft:sea_lantern
setblock 222 292 281 minecraft:sea_lantern
setblock 223 292 276 minecraft:sea_lantern
setblock 223 292 278 minecraft:sea_lantern
setblock 223 292 280 minecraft:sea_lantern
setblock 223 292 282 minecraft:sea_lantern
setblock 224 292 277 minecraft:sea_lantern
setblock 224 292 279 minecraft:sea_lantern
setblock 224 292 281 minecraft:sea_lantern
fill 224 292 317 224 308 317 minecraft:prismarine
setblock 225 292 276 minecraft:sea_lantern
setblock 225 292 278 minecraft:sea_lantern
setblock 225 292 280 minecraft:sea_lantern
setblock 225 292 282 minecraft:sea_lantern
fill 225 292 317 226 292 317 minecraft:sea_lantern
fill 227 292 317 227 308 317 minecraft:prismarine
fill 230 292 276 230 308 276 minecraft:prismarine
fill 230 292 277 230 292 278 minecraft:sea_lantern
fill 230 292 279 230 308 279 minecraft:prismarine
fill 230 292 288 230 308 288 minecraft:prismarine
fill 230 292 289 230 292 290 minecraft:sea_lantern
fill 230 292 291 230 294 291 minecraft:prismarine
fill 230 292 300 230 308 300 minecraft:prismarine
fill 230 292 301 230 292 302 minecraft:sea_lantern
fill 230 292 303 230 308 303 minecraft:prismarine
fill 230 292 312 230 300 312 minecraft:prismarine
setblock 230 292 313 minecraft:sea_lantern
fill 230 292 315 230 308 315 minecraft:prismarine
fill 188 293 282 188 308 283 minecraft:prismarine
fill 188 293 294 188 297 295 minecraft:prismarine
fill 188 293 306 188 308 307 minecraft:prismarine
fill 189 293 300 189 294 300 minecraft:prismarine_bricks
fill 189 293 302 189 294 302 minecraft:prismarine_bricks
fill 189 293 304 189 294 304 minecraft:prismarine_bricks
fill 189 293 306 189 294 306 minecraft:prismarine_bricks
fill 189 293 317 190 308 317 minecraft:prismarine
fill 190 293 299 190 294 299 minecraft:prismarine_bricks
fill 190 293 301 190 294 301 minecraft:prismarine_bricks
fill 190 293 303 190 294 303 minecraft:prismarine_bricks
fill 190 293 305 190 294 305 minecraft:prismarine_bricks
fill 190 293 307 190 294 307 minecraft:prismarine_bricks
fill 191 293 300 191 294 300 minecraft:prismarine_bricks
fill 191 293 302 191 294 302 minecraft:prismarine_bricks
fill 191 293 304 191 294 304 minecraft:prismarine_bricks
fill 191 293 306 191 294 306 minecraft:prismarine_bricks
fill 192 293 299 192 294 299 minecraft:prismarine_bricks
fill 192 293 301 192 294 301 minecraft:prismarine_bricks
fill 192 293 303 192 294 303 minecraft:prismarine_bricks
fill 192 293 305 192 294 305 minecraft:prismarine_bricks
fill 192 293 307 192 294 307 minecraft:prismarine_bricks
fill 193 293 300 193 294 300 minecraft:prismarine_bricks
fill 193 293 302 193 294 302 minecraft:prismarine_bricks
fill 193 293 304 193 294 304 minecraft:prismarine_bricks
fill 193 293 306 193 294 306 minecraft:prismarine_bricks
fill 194 293 299 194 294 299 minecraft:prismarine_bricks
fill 194 293 301 194 294 301 minecraft:prismarine_bricks
fill 194 293 303 194 294 303 minecraft:prismarine_bricks
fill 194 293 305 194 294 305 minecraft:prismarine_bricks
fill 194 293 307 194 294 307 minecraft:prismarine_bricks
fill 195 293 275 197 308 275 minecraft:prismarine
fill 201 293 317 202 298 317 minecraft:prismarine
fill 203 293 312 203 294 312 minecraft:prismarine_bricks
fill 203 293 314 203 294 314 minecraft:prismarine_bricks
fill 203 293 316 203 294 316 minecraft:prismarine_bricks
fill 204 293 311 204 294 311 minecraft:prismarine_bricks
fill 204 293 313 204 294 313 minecraft:prismarine_bricks
fill 204 293 315 204 294 315 minecraft:prismarine_bricks
fill 205 293 312 205 294 312 minecraft:prismarine_bricks
fill 205 293 314 205 294 314 minecraft:prismarine_bricks
fill 205 293 316 205 294 316 minecraft:prismarine_bricks
fill 206 293 311 206 294 311 minecraft:prismarine_bricks
fill 206 293 313 206 294 313 minecraft:prismarine_bricks
fill 206 293 315 206 294 315 minecraft:prismarine_bricks
fill 207 293 308 207 294 308 minecraft:prismarine_bricks
fill 207 293 310 207 294 310 minecraft:prismarine_bricks
fill 207 293 312 207 294 312 minecraft:prismarine_bricks
fill 207 293 314 207 294 314 minecraft:prismarine_bricks
fill 207 293 316 207 293 317 minecraft:prismarine_bricks
fill 208 293 275 209 308 275 minecraft:prismarine
fill 208 293 309 208 294 309 minecraft:prismarine_bricks
fill 208 293 311 208 294 311 minecraft:prismarine_bricks
fill 208 293 313 208 294 313 minecraft:quartz_pillar
fill 208 293 315 208 294 315 minecraft:quartz_pillar
fill 209 293 308 209 294 308 minecraft:prismarine_bricks
fill 209 293 310 209 294 310 minecraft:prismarine_bricks
fill 209 293 312 209 294 312 minecraft:prismarine_bricks
fill 209 293 314 209 294 314 minecraft:quartz_pillar
fill 209 293 316 209 294 316 minecraft:prismarine_bricks
fill 210 293 309 210 294 309 minecraft:prismarine_bricks
fill 210 293 311 210 294 311 minecraft:prismarine_bricks
fill 210 293 313 210 294 313 minecraft:quartz_pillar
fill 210 293 315 210 294 315 minecraft:quartz_pillar
fill 211 293 308 211 294 308 minecraft:prismarine_bricks
fill 211 293 310 211 294 310 minecraft:prismarine_bricks
fill 211 293 312 211 294 312 minecraft:prismarine_bricks
fill 211 293 314 211 294 314 minecraft:prismarine_bricks
fill 211 293 316 211 294 316 minecraft:prismarine_bricks
fill 212 293 309 212 294 309 minecraft:prismarine_bricks
fill 212 293 311 212 294 311 minecraft:prismarine_bricks
fill 212 293 313 212 294 313 minecraft:prismarine_bricks
fill 212 293 315 212 294 315 minecraft:prismarine_bricks
fill 213 293 308 213 294 308 minecraft:prismarine_bricks
fill 213 293 310 213 294 310 minecraft:prismarine_bricks
fill 213 293 312 213 294 312 minecraft:prismarine_bricks
fill 213 293 314 213 294 314 minecraft:prismarine_bricks
fill 213 293 316 213 294 316 minecraft:prismarine_bricks
fill 213 293 317 214 308 317 minecraft:prismarine
fill 216 293 317 216 308 317 minecraft:prismarine
fill 217 293 276 217 294 276 minecraft:prismarine_bricks
fill 217 293 278 217 294 278 minecraft:prismarine_bricks
fill 217 293 280 217 294 280 minecraft:prismarine_bricks
fill 217 293 282 217 294 282 minecraft:prismarine_bricks
fill 217 293 317 218 293 317 minecraft:prismarine_bricks
fill 218 293 277 218 294 277 minecraft:prismarine_bricks
fill 218 293 279 218 294 279 minecraft:prismarine_bricks
fill 218 293 281 218 294 281 minecraft:prismarine_bricks
fill 219 293 276 219 294 276 minecraft:prismarine_bricks
fill 219 293 278 219 294 278 minecraft:prismarine_bricks
fill 219 293 280 219 294 280 minecraft:prismarine_bricks
fill 219 293 282 219 294 282 minecraft:prismarine_bricks
fill 220 293 275 221 308 275 minecraft:prismarine
fill 220 293 277 220 294 277 minecraft:prismarine_bricks
fill 220 293 279 220 294 279 minecraft:prismarine_bricks
fill 220 293 281 220 294 281 minecraft:prismarine_bricks
fill 221 293 276 221 294 276 minecraft:prismarine_bricks
fill 221 293 278 221 294 278 minecraft:prismarine_bricks
fill 221 293 280 221 294 280 minecraft:prismarine_bricks
fill 221 293 282 221 294 282 minecraft:prismarine_bricks
fill 222 293 277 222 294 277 minecraft:prismarine_bricks
fill 222 293 279 222 294 279 minecraft:prismarine_bricks
fill 222 293 281 222 294 281 minecraft:prismarine_bricks
fill 223 293 276 223 294 276 minecraft:prismarine_bricks
fill 223 293 278 223 294 278 minecraft:prismarine_bricks
fill 223 293 280 223 294 280 minecraft:prismarine_bricks
fill 223 293 282 223 294 282 minecraft:prismarine_bricks
fill 224 293 277 224 294 277 minecraft:prismarine_bricks
fill 224 293 279 224 294 279 minecraft:prismarine_bricks
fill 224 293 281 224 294 281 minecraft:prismarine_bricks
fill 225 293 276 225 294 276 minecraft:prismarine_bricks
fill 225 293 278 225 294 278 minecraft:quartz_pillar
fill 225 293 280 225 294 280 minecraft:quartz_pillar
fill 225 293 282 225 294 282 minecraft:prismarine_bricks
fill 225 293 317 226 308 317 minecraft:prismarine
fill 230 293 277 230 308 278 minecraft:prismarine
fill 230 293 289 230 308 290 minecraft:prismarine
fill 230 293 301 230 295 302 minecraft:prismarine
fill 230 293 313 230 308 314 minecraft:prismarine
setblock 207 294 316 minecraft:prismarine_bricks
fill 207 294 317 207 308 317 minecraft:prismarine
fill 217 294 317 218 298 317 minecraft:prismarine
fill 218 294 304 219 295 304 minecraft:white_stained_glass
setblock 230 294 311 minecraft:prismarine_bricks
setblock 189 295 300 minecraft:sea_lantern
setblock 189 295 302 minecraft:sea_lantern
setblock 189 295 304 minecraft:sea_lantern
setblock 189 295 306 minecraft:sea_lantern
setblock 190 295 299 minecraft:sea_lantern
setblock 190 295 301 minecraft:sea_lantern
setblock 190 295 303 minecraft:sea_lantern
setblock 190 295 305 minecraft:sea_lantern
setblock 190 295 307 minecraft:sea_lantern
setblock 191 295 286 minecraft:light[level=15]
setblock 191 295 294 minecraft:light[level=15]
setblock 191 295 300 minecraft:sea_lantern
setblock 191 295 302 minecraft:sea_lantern
setblock 191 295 304 minecraft:sea_lantern
setblock 191 295 306 minecraft:sea_lantern
setblock 191 295 310 minecraft:light[level=15]
setblock 192 295 299 minecraft:sea_lantern
setblock 192 295 301 minecraft:sea_lantern
setblock 192 295 303 minecraft:sea_lantern
setblock 192 295 305 minecraft:sea_lantern
setblock 192 295 307 minecraft:sea_lantern
setblock 193 295 300 minecraft:sea_lantern
setblock 193 295 302 minecraft:sea_lantern
setblock 193 295 304 minecraft:sea_lantern
setblock 193 295 306 minecraft:sea_lantern
setblock 194 295 299 minecraft:sea_lantern
setblock 194 295 301 minecraft:sea_lantern
setblock 194 295 303 minecraft:sea_lantern
setblock 194 295 305 minecraft:sea_lantern
setblock 194 295 307 minecraft:sea_lantern
fill 196 295 311 196 299 311 minecraft:prismarine_bricks
setblock 199 295 278 minecraft:light[level=15]
setblock 199 295 286 minecraft:light[level=15]
setblock 199 295 294 minecraft:light[level=15]
setblock 199 295 302 minecraft:light[level=15]
setblock 199 295 310 minecraft:light[level=15]
setblock 203 295 312 minecraft:sea_lantern
setblock 203 295 314 minecraft:sea_lantern
setblock 203 295 316 minecraft:sea_lantern
setblock 204 295 311 minecraft:sea_lantern
setblock 204 295 313 minecraft:sea_lantern
setblock 204 295 315 minecraft:sea_lantern
setblock 205 295 312 minecraft:sea_lantern
setblock 205 295 314 minecraft:sea_lantern
setblock 205 295 316 minecraft:sea_lantern
setblock 206 295 311 minecraft:sea_lantern
setblock 206 295 313 minecraft:sea_lantern
setblock 206 295 315 minecraft:sea_lantern
setblock 207 295 278 minecraft:light[level=15]
setblock 207 295 286 minecraft:light[level=15]
setblock 207 295 294 minecraft:light[level=15]
setblock 207 295 302 minecraft:light[level=15]
setblock 207 295 308 minecraft:sea_lantern
setblock 207 295 310 minecraft:sea_lantern
setblock 207 295 312 minecraft:sea_lantern
setblock 207 295 314 minecraft:sea_lantern
setblock 207 295 316 minecraft:sea_lantern
setblock 208 295 309 minecraft:sea_lantern
setblock 208 295 311 minecraft:sea_lantern
setblock 208 295 313 minecraft:sea_lantern
setblock 208 295 315 minecraft:sea_lantern
setblock 209 295 308 minecraft:sea_lantern
setblock 209 295 310 minecraft:sea_lantern
setblock 209 295 312 minecraft:sea_lantern
setblock 209 295 314 minecraft:sea_lantern
setblock 209 295 316 minecraft:sea_lantern
setblock 210 295 309 minecraft:sea_lantern
setblock 210 295 311 minecraft:sea_lantern
setblock 210 295 313 minecraft:sea_lantern
setblock 210 295 315 minecraft:sea_lantern
setblock 211 295 308 minecraft:sea_lantern
setblock 211 295 310 minecraft:sea_lantern
setblock 211 295 312 minecraft:sea_lantern
setblock 211 295 314 minecraft:sea_lantern
setblock 211 295 316 minecraft:sea_lantern
setblock 212 295 309 minecraft:sea_lantern
setblock 212 295 311 minecraft:sea_lantern
setblock 212 295 313 minecraft:sea_lantern
setblock 212 295 315 minecraft:sea_lantern
setblock 213 295 308 minecraft:sea_lantern
setblock 213 295 310 minecraft:sea_lantern
setblock 213 295 312 minecraft:sea_lantern
setblock 213 295 314 minecraft:sea_lantern
setblock 213 295 316 minecraft:sea_lantern
setblock 215 295 278 minecraft:light[level=15]
setblock 215 295 286 minecraft:light[level=15]
setblock 215 295 294 minecraft:light[level=15]
setblock 215 295 302 minecraft:light[level=15]
setblock 215 295 310 minecraft:light[level=15]
setblock 217 295 276 minecraft:sea_lantern
setblock 217 295 278 minecraft:sea_lantern
setblock 217 295 280 minecraft:sea_lantern
setblock 217 295 282 minecraft:sea_lantern
setblock 218 295 277 minecraft:sea_lantern
setblock 218 295 279 minecraft:sea_lantern
setblock 218 295 281 minecraft:sea_lantern
setblock 219 295 276 minecraft:sea_lantern
setblock 219 295 278 minecraft:sea_lantern
setblock 219 295 280 minecraft:sea_lantern
setblock 219 295 282 minecraft:sea_lantern
setblock 220 295 277 minecraft:sea_lantern
setblock 220 295 279 minecraft:sea_lantern
setblock 220 295 281 minecraft:sea_lantern
setblock 221 295 276 minecraft:sea_lantern
setblock 221 295 278 minecraft:sea_lantern
setblock 221 295 280 minecraft:sea_lantern
setblock 221 295 282 minecraft:sea_lantern
setblock 222 295 277 minecraft:sea_lantern
setblock 222 295 279 minecraft:sea_lantern
setblock 222 295 281 minecraft:sea_lantern
setblock 223 295 276 minecraft:sea_lantern
setblock 223 295 278 minecraft:sea_lantern
setblock 223 295 280 minecraft:sea_lantern
setblock 223 295 282 minecraft:sea_lantern
setblock 223 295 286 minecraft:light[level=15]
setblock 223 295 310 minecraft:light[level=15]
setblock 224 295 277 minecraft:sea_lantern
setblock 224 295 279 minecraft:sea_lantern
setblock 224 295 281 minecraft:sea_lantern
setblock 225 295 276 minecraft:sea_lantern
setblock 225 295 278 minecraft:sea_lantern
setblock 225 295 280 minecraft:sea_lantern
setblock 225 295 282 minecraft:sea_lantern
setblock 230 295 291 minecraft:sea_lantern
fill 230 295 311 230 308 311 minecraft:prismarine
setblock 188 296 280 minecraft:sea_lantern
fill 189 296 300 189 297 300 minecraft:prismarine_bricks
fill 189 296 302 189 297 302 minecraft:prismarine_bricks
fill 189 296 304 189 297 304 minecraft:prismarine_bricks
fill 189 296 306 189 297 306 minecraft:prismarine_bricks
fill 190 296 299 190 297 299 minecraft:prismarine_bricks
fill 190 296 301 190 297 301 minecraft:prismarine_bricks
fill 190 296 303 190 297 303 minecraft:prismarine_bricks
fill 190 296 305 190 297 305 minecraft:prismarine_bricks
fill 190 296 307 190 297 307 minecraft:prismarine_bricks
fill 191 296 300 191 297 300 minecraft:prismarine_bricks
fill 191 296 302 191 297 302 minecraft:prismarine_bricks
fill 191 296 304 191 297 304 minecraft:prismarine_bricks
fill 191 296 306 191 297 306 minecraft:prismarine_bricks
fill 192 296 299 192 297 299 minecraft:prismarine_bricks
fill 192 296 301 192 297 301 minecraft:prismarine_bricks
fill 192 296 303 192 297 303 minecraft:prismarine_bricks
fill 192 296 305 192 297 305 minecraft:prismarine_bricks
fill 192 296 307 192 297 307 minecraft:prismarine_bricks
setblock 193 296 275 minecraft:sea_lantern
fill 193 296 300 193 297 300 minecraft:prismarine_bricks
fill 193 296 302 193 297 302 minecraft:prismarine_bricks
fill 193 296 304 193 297 304 minecraft:prismarine_bricks
fill 193 296 306 193 297 306 minecraft:prismarine_bricks
fill 194 296 299 194 297 299 minecraft:prismarine_bricks
fill 194 296 301 194 297 301 minecraft:prismarine_bricks
fill 194 296 303 194 297 303 minecraft:prismarine_bricks
fill 194 296 305 194 297 305 minecraft:prismarine_bricks
fill 194 296 307 194 297 307 minecraft:prismarine_bricks
fill 203 296 312 203 297 312 minecraft:prismarine_bricks
fill 203 296 314 203 297 314 minecraft:prismarine_bricks
fill 203 296 316 203 297 316 minecraft:prismarine_bricks
fill 204 296 311 204 297 311 minecraft:prismarine_bricks
fill 204 296 313 204 297 313 minecraft:prismarine_bricks
fill 204 296 315 204 297 315 minecraft:prismarine_bricks
fill 205 296 312 205 297 312 minecraft:prismarine_bricks
fill 205 296 314 205 297 314 minecraft:prismarine_bricks
fill 205 296 316 205 297 316 minecraft:prismarine_bricks
fill 206 296 311 206 297 311 minecraft:prismarine_bricks
fill 206 296 313 206 297 313 minecraft:prismarine_bricks
fill 206 296 315 206 297 315 minecraft:prismarine_bricks
fill 207 296 308 207 297 308 minecraft:prismarine_bricks
fill 207 296 310 207 297 310 minecraft:prismarine_bricks
fill 207 296 312 207 297 312 minecraft:prismarine_bricks
fill 207 296 314 207 297 314 minecraft:prismarine_bricks
fill 207 296 316 207 297 316 minecraft:prismarine_bricks
fill 208 296 309 208 297 309 minecraft:prismarine_bricks
fill 208 296 311 208 297 311 minecraft:prismarine_bricks
fill 208 296 313 208 297 313 minecraft:quartz_pillar
fill 208 296 315 208 297 315 minecraft:quartz_pillar
fill 209 296 308 209 297 308 minecraft:prismarine_bricks
fill 209 296 310 209 297 310 minecraft:prismarine_bricks
fill 209 296 312 209 297 312 minecraft:prismarine_bricks
fill 209 296 314 209 297 314 minecraft:quartz_pillar
fill 209 296 316 209 297 316 minecraft:prismarine_bricks
fill 210 296 309 210 297 309 minecraft:prismarine_bricks
fill 210 296 311 210 297 311 minecraft:prismarine_bricks
fill 210 296 313 210 297 313 minecraft:quartz_pillar
fill 210 296 315 210 297 315 minecraft:quartz_pillar
fill 211 296 308 211 297 308 minecraft:prismarine_bricks
fill 211 296 310 211 297 310 minecraft:prismarine_bricks
fill 211 296 312 211 297 312 minecraft:prismarine_bricks
fill 211 296 314 211 297 314 minecraft:prismarine_bricks
fill 211 296 316 211 297 316 minecraft:prismarine_bricks
fill 212 296 309 212 297 309 minecraft:prismarine_bricks
fill 212 296 311 212 297 311 minecraft:prismarine_bricks
fill 212 296 313 212 297 313 minecraft:prismarine_bricks
fill 212 296 315 212 297 315 minecraft:prismarine_bricks
fill 213 296 308 213 297 308 minecraft:prismarine_bricks
fill 213 296 310 213 297 310 minecraft:prismarine_bricks
fill 213 296 312 213 297 312 minecraft:prismarine_bricks
fill 213 296 314 213 297 314 minecraft:prismarine_bricks
fill 213 296 316 213 297 316 minecraft:prismarine_bricks
fill 217 296 276 217 297 276 minecraft:prismarine_bricks
fill 217 296 278 217 297 278 minecraft:prismarine_bricks
fill 217 296 280 217 297 280 minecraft:prismarine_bricks
fill 217 296 282 217 297 282 minecraft:prismarine_bricks
fill 218 296 277 218 297 277 minecraft:prismarine_bricks
fill 218 296 279 218 297 279 minecraft:prismarine_bricks
fill 218 296 281 218 297 281 minecraft:prismarine_bricks
fill 219 296 276 219 297 276 minecraft:prismarine_bricks
fill 219 296 278 219 297 278 minecraft:prismarine_bricks
fill 219 296 280 219 297 280 minecraft:prismarine_bricks
fill 219 296 282 219 297 282 minecraft:prismarine_bricks
fill 220 296 277 220 297 277 minecraft:prismarine_bricks
fill 220 296 279 220 297 279 minecraft:prismarine_bricks
fill 220 296 281 220 297 281 minecraft:prismarine_bricks
fill 221 296 276 221 297 276 minecraft:prismarine_bricks
fill 221 296 278 221 297 278 minecraft:prismarine_bricks
fill 221 296 280 221 297 280 minecraft:prismarine_bricks
fill 221 296 282 221 297 282 minecraft:prismarine_bricks
fill 222 296 277 222 297 277 minecraft:prismarine_bricks
fill 222 296 279 222 297 279 minecraft:prismarine_bricks
fill 222 296 281 222 297 281 minecraft:prismarine_bricks
fill 223 296 276 223 297 276 minecraft:prismarine_bricks
fill 223 296 278 223 297 278 minecraft:prismarine_bricks
fill 223 296 280 223 297 280 minecraft:prismarine_bricks
fill 223 296 282 223 297 282 minecraft:prismarine_bricks
fill 224 296 277 224 297 277 minecraft:prismarine_bricks
fill 224 296 279 224 297 279 minecraft:prismarine_bricks
fill 224 296 281 224 297 281 minecraft:prismarine_bricks
fill 225 296 276 225 297 276 minecraft:prismarine_bricks
fill 225 296 278 225 297 278 minecraft:quartz_pillar
fill 225 296 280 225 297 280 minecraft:quartz_pillar
fill 225 296 282 225 297 282 minecraft:prismarine_bricks
fill 230 296 291 230 308 291 minecraft:prismarine
setblock 230 296 301 minecraft:sea_lantern
fill 230 296 302 230 308 302 minecraft:prismarine
fill 188 297 280 188 308 280 minecraft:prismarine
setblock 191 297 285 minecraft:light[level=12]
setblock 191 297 292 minecraft:light[level=12]
fill 193 297 275 193 308 275 minecraft:prismarine
setblock 198 297 278 minecraft:light[level=12]
setblock 198 297 285 minecraft:light[level=12]
setblock 198 297 292 minecraft:light[level=12]
setblock 198 297 299 minecraft:light[level=12]
setblock 198 297 306 minecraft:light[level=12]
setblock 198 297 313 minecraft:light[level=12]
setblock 205 297 278 minecraft:light[level=12]
setblock 205 297 285 minecraft:light[level=12]
setblock 205 297 292 minecraft:light[level=12]
setblock 205 297 299 minecraft:light[level=12]
setblock 205 297 306 minecraft:light[level=12]
setblock 212 297 278 minecraft:light[level=12]
setblock 212 297 285 minecraft:light[level=12]
setblock 212 297 292 minecraft:light[level=12]
setblock 212 297 299 minecraft:light[level=12]
setblock 212 297 306 minecraft:light[level=12]
setblock 219 297 285 minecraft:light[level=12]
setblock 219 297 292 minecraft:light[level=12]
setblock 219 297 299 minecraft:light[level=12]
setblock 219 297 306 minecraft:light[level=12]
setblock 219 297 313 minecraft:light[level=12]
setblock 226 297 285 minecraft:light[level=12]
setblock 226 297 306 minecraft:light[level=12]
fill 230 297 301 230 308 301 minecraft:prismarine
fill 188 298 294 188 308 294 minecraft:prismarine
setblock 188 298 295 minecraft:prismarine_bricks
fill 188 298 314 188 308 315 minecraft:prismarine
setblock 188 298 316 minecraft:prismarine_bricks
setblock 189 298 300 minecraft:sea_lantern
setblock 189 298 302 minecraft:sea_lantern
setblock 189 298 304 minecraft:sea_lantern
setblock 189 298 306 minecraft:sea_lantern
setblock 190 298 299 minecraft:sea_lantern
setblock 190 298 301 minecraft:sea_lantern
setblock 190 298 303 minecraft:sea_lantern
setblock 190 298 305 minecraft:sea_lantern
setblock 190 298 307 minecraft:sea_lantern
setblock 191 298 300 minecraft:sea_lantern
setblock 191 298 302 minecraft:sea_lantern
setblock 191 298 304 minecraft:sea_lantern
setblock 191 298 306 minecraft:sea_lantern
setblock 192 298 299 minecraft:sea_lantern
setblock 192 298 301 minecraft:sea_lantern
setblock 192 298 303 minecraft:sea_lantern
setblock 192 298 305 minecraft:sea_lantern
setblock 192 298 307 minecraft:sea_lantern
setblock 193 298 300 minecraft:sea_lantern
setblock 193 298 302 minecraft:sea_lantern
setblock 193 298 304 minecraft:sea_lantern
setblock 193 298 306 minecraft:sea_lantern
setblock 194 298 299 minecraft:sea_lantern
setblock 194 298 301 minecraft:sea_lantern
setblock 194 298 303 minecraft:sea_lantern
setblock 194 298 305 minecraft:sea_lantern
setblock 194 298 307 minecraft:sea_lantern
setblock 203 298 312 minecraft:sea_lantern
setblock 203 298 314 minecraft:sea_lantern
setblock 203 298 316 minecraft:sea_lantern
setblock 204 298 311 minecraft:sea_lantern
setblock 204 298 313 minecraft:sea_lantern
setblock 204 298 315 minecraft:sea_lantern
setblock 205 298 312 minecraft:sea_lantern
setblock 205 298 314 minecraft:sea_lantern
setblock 205 298 316 minecraft:sea_lantern
setblock 206 298 311 minecraft:sea_lantern
setblock 206 298 313 minecraft:sea_lantern
setblock 206 298 315 minecraft:sea_lantern
setblock 207 298 275 minecraft:sea_lantern
setblock 207 298 308 minecraft:sea_lantern
setblock 207 298 310 minecraft:sea_lantern
setblock 207 298 312 minecraft:sea_lantern
setblock 207 298 314 minecraft:sea_lantern
setblock 207 298 316 minecraft:sea_lantern
setblock 208 298 309 minecraft:sea_lantern
setblock 208 298 311 minecraft:sea_lantern
setblock 208 298 313 minecraft:sea_lantern
setblock 208 298 315 minecraft:sea_lantern
setblock 209 298 308 minecraft:sea_lantern
setblock 209 298 310 minecraft:sea_lantern
setblock 209 298 312 minecraft:sea_lantern
setblock 209 298 314 minecraft:sea_lantern
setblock 209 298 316 minecraft:sea_lantern
fill 210 298 306 210 299 307 minecraft:white_stained_glass
setblock 210 298 309 minecraft:sea_lantern
setblock 210 298 311 minecraft:sea_lantern
setblock 210 298 313 minecraft:sea_lantern
setblock 210 298 315 minecraft:sea_lantern
setblock 211 298 308 minecraft:sea_lantern
setblock 211 298 310 minecraft:sea_lantern
setblock 211 298 312 minecraft:sea_lantern
setblock 211 298 314 minecraft:sea_lantern
setblock 211 298 316 minecraft:sea_lantern
setblock 212 298 309 minecraft:sea_lantern
setblock 212 298 311 minecraft:sea_lantern
setblock 212 298 313 minecraft:sea_lantern
setblock 212 298 315 minecraft:sea_lantern
setblock 213 298 308 minecraft:sea_lantern
setblock 213 298 310 minecraft:sea_lantern
setblock 213 298 312 minecraft:sea_lantern
setblock 213 298 314 minecraft:sea_lantern
setblock 213 298 316 minecraft:sea_lantern
setblock 216 298 275 minecraft:sea_lantern
setblock 217 298 276 minecraft:sea_lantern
setblock 217 298 278 minecraft:sea_lantern
setblock 217 298 280 minecraft:sea_lantern
setblock 217 298 282 minecraft:sea_lantern
setblock 218 298 277 minecraft:sea_lantern
setblock 218 298 279 minecraft:sea_lantern
setblock 218 298 281 minecraft:sea_lantern
setblock 219 298 276 minecraft:sea_lantern
setblock 219 298 278 minecraft:sea_lantern
setblock 219 298 280 minecraft:sea_lantern
setblock 219 298 282 minecraft:sea_lantern
setblock 220 298 277 minecraft:sea_lantern
setblock 220 298 279 minecraft:sea_lantern
setblock 220 298 281 minecraft:sea_lantern
setblock 221 298 276 minecraft:sea_lantern
setblock 221 298 278 minecraft:sea_lantern
setblock 221 298 280 minecraft:sea_lantern
setblock 221 298 282 minecraft:sea_lantern
setblock 222 298 277 minecraft:sea_lantern
setblock 222 298 279 minecraft:sea_lantern
setblock 222 298 281 minecraft:sea_lantern
setblock 223 298 276 minecraft:sea_lantern
setblock 223 298 278 minecraft:sea_lantern
setblock 223 298 280 minecraft:sea_lantern
setblock 223 298 282 minecraft:sea_lantern
setblock 224 298 277 minecraft:sea_lantern
setblock 224 298 279 minecraft:sea_lantern
setblock 224 298 281 minecraft:sea_lantern
setblock 225 298 276 minecraft:sea_lantern
setblock 225 298 278 minecraft:sea_lantern
setblock 225 298 280 minecraft:sea_lantern
setblock 225 298 282 minecraft:sea_lantern
fill 230 298 283 230 308 283 minecraft:prismarine
setblock 230 298 284 minecraft:sea_lantern
fill 188 299 295 188 308 295 minecraft:prismarine
fill 188 299 316 188 308 316 minecraft:prismarine
fill 189 299 300 189 300 300 minecraft:prismarine_bricks
fill 189 299 302 189 300 302 minecraft:prismarine_bricks
fill 189 299 304 189 300 304 minecraft:prismarine_bricks
fill 189 299 306 189 300 306 minecraft:prismarine_bricks
fill 190 299 299 190 300 299 minecraft:prismarine_bricks
fill 190 299 301 190 300 301 minecraft:prismarine_bricks
fill 190 299 303 190 300 303 minecraft:prismarine_bricks
fill 190 299 305 190 300 305 minecraft:prismarine_bricks
fill 190 299 307 190 300 307 minecraft:prismarine_bricks
fill 191 299 300 191 300 300 minecraft:prismarine_bricks
fill 191 299 302 191 300 302 minecraft:prismarine_bricks
fill 191 299 304 191 300 304 minecraft:prismarine_bricks
fill 191 299 306 191 300 306 minecraft:prismarine_bricks
fill 192 299 299 192 300 299 minecraft:prismarine_bricks
fill 192 299 301 192 300 301 minecraft:prismarine_bricks
fill 192 299 303 192 300 303 minecraft:prismarine_bricks
fill 192 299 305 192 300 305 minecraft:prismarine_bricks
fill 192 299 307 192 300 307 minecraft:prismarine_bricks
fill 193 299 300 193 300 300 minecraft:prismarine_bricks
fill 193 299 302 193 300 302 minecraft:prismarine_bricks
fill 193 299 304 193 300 304 minecraft:prismarine_bricks
fill 193 299 306 193 300 306 minecraft:prismarine_bricks
fill 194 299 299 194 300 299 minecraft:prismarine_bricks
fill 194 299 301 194 300 301 minecraft:prismarine_bricks
fill 194 299 303 194 300 303 minecraft:prismarine_bricks
fill 194 299 305 194 300 305 minecraft:prismarine_bricks
fill 194 299 307 194 300 307 minecraft:prismarine_bricks
fill 201 299 317 201 308 317 minecraft:prismarine
setblock 202 299 317 minecraft:sea_lantern
fill 203 299 312 203 300 312 minecraft:prismarine_bricks
fill 203 299 314 203 300 314 minecraft:prismarine_bricks
fill 203 299 316 203 300 316 minecraft:prismarine_bricks
fill 204 299 311 204 300 311 minecraft:prismarine_bricks
fill 204 299 313 204 300 313 minecraft:prismarine_bricks
fill 204 299 315 204 300 315 minecraft:prismarine_bricks
fill 205 299 312 205 300 312 minecraft:prismarine_bricks
fill 205 299 314 205 300 314 minecraft:prismarine_bricks
fill 205 299 316 205 300 316 minecraft:prismarine_bricks
fill 206 299 311 206 300 311 minecraft:prismarine_bricks
fill 206 299 313 206 300 313 minecraft:prismarine_bricks
fill 206 299 315 206 300 315 minecraft:prismarine_bricks
fill 207 299 275 207 308 275 minecraft:prismarine
fill 207 299 308 207 300 308 minecraft:prismarine_bricks
fill 207 299 310 207 300 310 minecraft:prismarine_bricks
fill 207 299 312 207 300 312 minecraft:prismarine_bricks
fill 207 299 314 207 300 314 minecraft:prismarine_bricks
fill 207 299 316 207 300 316 minecraft:prismarine_bricks
fill 208 299 309 208 300 309 minecraft:prismarine_bricks
fill 208 299 311 208 300 311 minecraft:prismarine_bricks
fill 208 299 313 208 303 313 minecraft:quartz_pillar
fill 208 299 315 208 303 315 minecraft:quartz_pillar
fill 209 299 308 209 300 308 minecraft:prismarine_bricks
fill 209 299 310 209 300 310 minecraft:prismarine_bricks
fill 209 299 312 209 300 312 minecraft:prismarine_bricks
fill 209 299 314 209 303 314 minecraft:quartz_pillar
fill 209 299 316 209 300 316 minecraft:prismarine_bricks
fill 210 299 309 210 300 309 minecraft:prismarine_bricks
fill 210 299 311 210 300 311 minecraft:prismarine_bricks
fill 210 299 313 210 303 313 minecraft:quartz_pillar
fill 210 299 315 210 303 315 minecraft:quartz_pillar
fill 211 299 308 211 300 308 minecraft:prismarine_bricks
fill 211 299 310 211 300 310 minecraft:prismarine_bricks
fill 211 299 312 211 300 312 minecraft:prismarine_bricks
fill 211 299 314 211 300 314 minecraft:prismarine_bricks
fill 211 299 316 211 300 316 minecraft:prismarine_bricks
fill 212 299 309 212 300 309 minecraft:prismarine_bricks
fill 212 299 311 212 300 311 minecraft:prismarine_bricks
fill 212 299 313 212 300 313 minecraft:prismarine_bricks
fill 212 299 315 212 300 315 minecraft:prismarine_bricks
fill 213 299 308 213 300 308 minecraft:prismarine_bricks
fill 213 299 310 213 300 310 minecraft:prismarine_bricks
fill 213 299 312 213 300 312 minecraft:prismarine_bricks
fill 213 299 314 213 300 314 minecraft:prismarine_bricks
fill 213 299 316 213 300 316 minecraft:prismarine_bricks
fill 216 299 275 216 308 275 minecraft:prismarine
fill 217 299 276 217 300 276 minecraft:prismarine_bricks
fill 217 299 278 217 300 278 minecraft:prismarine_bricks
fill 217 299 280 217 300 280 minecraft:prismarine_bricks
fill 217 299 282 217 300 282 minecraft:prismarine_bricks
fill 217 299 317 217 308 317 minecraft:prismarine
fill 218 299 277 218 300 277 minecraft:prismarine_bricks
fill 218 299 279 218 300 279 minecraft:prismarine_bricks
fill 218 299 281 218 300 281 minecraft:prismarine_bricks
setblock 218 299 317 minecraft:prismarine_bricks
fill 219 299 276 219 300 276 minecraft:prismarine_bricks
fill 219 299 278 219 300 278 minecraft:prismarine_bricks
fill 219 299 280 219 300 280 minecraft:prismarine_bricks
fill 219 299 282 219 300 282 minecraft:prismarine_bricks
fill 220 299 277 220 300 277 minecraft:prismarine_bricks
fill 220 299 279 220 300 279 minecraft:prismarine_bricks
fill 220 299 281 220 300 281 minecraft:prismarine_bricks
fill 221 299 276 221 300 276 minecraft:prismarine_bricks
fill 221 299 278 221 300 278 minecraft:prismarine_bricks
fill 221 299 280 221 300 280 minecraft:prismarine_bricks
fill 221 299 282 221 300 282 minecraft:prismarine_bricks
fill 222 299 277 222 300 277 minecraft:prismarine_bricks
fill 222 299 279 222 300 279 minecraft:prismarine_bricks
fill 222 299 281 222 300 281 minecraft:prismarine_bricks
fill 223 299 276 223 300 276 minecraft:prismarine_bricks
fill 223 299 278 223 300 278 minecraft:prismarine_bricks
fill 223 299 280 223 300 280 minecraft:prismarine_bricks
fill 223 299 282 223 300 282 minecraft:prismarine_bricks
fill 224 299 277 224 300 277 minecraft:prismarine_bricks
fill 224 299 279 224 300 279 minecraft:prismarine_bricks
fill 224 299 281 224 300 281 minecraft:prismarine_bricks
fill 224 299 310 224 299 313 minecraft:dark_prismarine
fill 225 299 276 225 300 276 minecraft:prismarine_bricks
fill 225 299 278 225 303 278 minecraft:quartz_pillar
fill 225 299 280 225 303 280 minecraft:quartz_pillar
fill 225 299 282 225 300 282 minecraft:prismarine_bricks
fill 225 299 283 226 299 283 minecraft:dark_prismarine
fill 225 299 309 227 299 309 minecraft:dark_prismarine
setblock 227 299 282 minecraft:dark_prismarine
fill 228 299 280 228 299 281 minecraft:dark_prismarine
fill 228 299 310 228 299 312 minecraft:dark_prismarine
fill 230 299 284 230 308 284 minecraft:prismarine
setblock 230 299 306 minecraft:sea_lantern
fill 190 300 285 190 300 287 minecraft:prismarine_bricks
setblock 190 300 298 minecraft:prismarine_bricks
fill 190 300 309 190 300 311 minecraft:prismarine_bricks
setblock 196 300 311 minecraft:sea_lantern
fill 196 300 315 198 300 315 minecraft:prismarine_bricks
fill 200 300 277 202 300 277 minecraft:prismarine_bricks
fill 202 300 317 202 308 317 minecraft:prismarine
fill 212 300 277 214 300 277 minecraft:prismarine_bricks
fill 218 300 317 218 308 317 minecraft:prismarine
fill 220 300 315 222 300 315 minecraft:prismarine_bricks
fill 224 300 310 224 300 312 minecraft:gold_block
fill 225 300 309 226 300 309 minecraft:gold_block
setblock 226 300 277 minecraft:prismarine_bricks
setblock 227 300 282 minecraft:gold_block
fill 228 300 285 228 300 287 minecraft:prismarine_bricks
fill 228 300 309 228 300 311 minecraft:prismarine_bricks
setblock 228 300 312 minecraft:gold_block
fill 230 300 306 230 308 306 minecraft:prismarine
setblock 227 301 275 minecraft:prismarine_bricks
setblock 230 301 305 minecraft:prismarine_bricks
setblock 230 301 312 minecraft:prismarine_bricks
fill 227 302 275 227 308 275 minecraft:prismarine
setblock 230 302 292 minecraft:prismarine_bricks
fill 230 302 298 230 308 298 minecraft:prismarine
setblock 230 302 299 minecraft:sea_lantern
fill 230 302 305 230 308 305 minecraft:prismarine
fill 230 302 312 230 308 312 minecraft:prismarine
setblock 191 303 285 minecraft:light[level=12]
setblock 191 303 286 minecraft:light[level=15]
setblock 191 303 292 minecraft:light[level=12]
setblock 191 303 294 minecraft:light[level=15]
setblock 191 303 299 minecraft:light[level=12]
setblock 191 303 302 minecraft:light[level=15]
setblock 191 303 306 minecraft:light[level=12]
setblock 191 303 310 minecraft:light[level=15]
setblock 198 303 278 minecraft:light[level=12]
setblock 198 303 285 minecraft:light[level=12]
setblock 198 303 292 minecraft:light[level=12]
setblock 198 303 299 minecraft:light[level=12]
setblock 198 303 306 minecraft:light[level=12]
setblock 198 303 313 minecraft:light[level=12]
setblock 199 303 278 minecraft:light[level=15]
setblock 199 303 286 minecraft:light[level=15]
setblock 199 303 294 minecraft:light[level=15]
setblock 199 303 302 minecraft:light[level=15]
setblock 199 303 310 minecraft:light[level=15]
setblock 205 303 278 minecraft:light[level=12]
setblock 205 303 285 minecraft:light[level=12]
setblock 205 303 292 minecraft:light[level=12]
setblock 205 303 299 minecraft:light[level=12]
setblock 205 303 306 minecraft:light[level=12]
setblock 205 303 313 minecraft:light[level=12]
setblock 207 303 278 minecraft:light[level=15]
setblock 207 303 286 minecraft:light[level=15]
setblock 207 303 294 minecraft:light[level=15]
setblock 207 303 302 minecraft:light[level=15]
setblock 207 303 310 minecraft:light[level=15]
setblock 212 303 278 minecraft:light[level=12]
setblock 212 303 285 minecraft:light[level=12]
setblock 212 303 292 minecraft:light[level=12]
setblock 212 303 299 minecraft:light[level=12]
setblock 212 303 306 minecraft:light[level=12]
setblock 212 303 313 minecraft:light[level=12]
setblock 215 303 278 minecraft:light[level=15]
setblock 215 303 286 minecraft:light[level=15]
setblock 215 303 294 minecraft:light[level=15]
setblock 215 303 302 minecraft:light[level=15]
setblock 215 303 310 minecraft:light[level=15]
setblock 219 303 278 minecraft:light[level=12]
setblock 219 303 285 minecraft:light[level=12]
setblock 219 303 292 minecraft:light[level=12]
setblock 219 303 299 minecraft:light[level=12]
setblock 219 303 306 minecraft:light[level=12]
setblock 219 303 313 minecraft:light[level=12]
setblock 223 303 278 minecraft:light[level=15]
setblock 223 303 286 minecraft:light[level=15]
setblock 223 303 294 minecraft:light[level=15]
setblock 223 303 302 minecraft:light[level=15]
setblock 223 303 310 minecraft:light[level=15]
setblock 226 303 285 minecraft:light[level=12]
setblock 226 303 292 minecraft:light[level=12]
setblock 226 303 299 minecraft:light[level=12]
setblock 226 303 306 minecraft:light[level=12]
fill 230 303 292 230 308 292 minecraft:prismarine
fill 230 303 299 230 308 299 minecraft:prismarine
setblock 188 304 313 minecraft:sea_lantern
setblock 206 304 317 minecraft:sea_lantern
setblock 211 304 317 minecraft:sea_lantern
setblock 219 304 317 minecraft:prismarine_bricks
fill 188 305 313 188 308 313 minecraft:prismarine
fill 206 305 317 206 308 317 minecraft:prismarine
fill 211 305 317 211 308 317 minecraft:prismarine
fill 219 305 317 219 308 317 minecraft:prismarine
setblock 188 306 293 minecraft:prismarine_bricks
fill 188 307 293 188 308 293 minecraft:prismarine
setblock 188 307 299 minecraft:prismarine_bricks
setblock 194 307 275 minecraft:prismarine_bricks
setblock 212 307 317 minecraft:sea_lantern
setblock 229 307 317 minecraft:prismarine_bricks
setblock 188 308 290 minecraft:sea_lantern
setblock 188 308 299 minecraft:prismarine
setblock 194 308 275 minecraft:prismarine
setblock 212 308 317 minecraft:prismarine
setblock 229 308 317 minecraft:prismarine
