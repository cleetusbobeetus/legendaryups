fill 552 179 359 552 180 359 minecraft:stripped_dark_oak_log
fill 552 179 361 552 180 361 minecraft:stripped_dark_oak_log
fill 552 179 363 552 180 363 minecraft:stripped_dark_oak_log
fill 553 179 358 553 180 358 minecraft:stripped_dark_oak_log
fill 553 179 360 553 180 360 minecraft:stripped_dark_oak_log
fill 553 179 362 553 180 362 minecraft:stripped_dark_oak_log
fill 554 179 359 554 180 359 minecraft:stripped_dark_oak_log
fill 554 179 361 554 180 361 minecraft:stripped_dark_oak_log
fill 554 179 363 554 180 363 minecraft:stripped_dark_oak_log
fill 555 179 358 555 180 358 minecraft:stripped_dark_oak_log
fill 555 179 360 555 180 360 minecraft:stripped_dark_oak_log
fill 555 179 362 555 180 362 minecraft:stripped_dark_oak_log
fill 556 179 359 556 180 359 minecraft:stripped_dark_oak_log
fill 556 179 361 556 180 361 minecraft:stripped_dark_oak_log
fill 556 179 363 556 180 363 minecraft:stripped_dark_oak_log
fill 557 179 358 558 180 358 minecraft:stripped_dark_oak_log
fill 557 179 360 557 180 360 minecraft:stripped_dark_oak_log
fill 557 179 362 557 180 362 minecraft:stripped_dark_oak_log
fill 558 179 323 558 180 323 minecraft:stripped_dark_oak_log
fill 558 179 330 558 180 330 minecraft:stripped_dark_oak_log
fill 558 179 337 558 180 337 minecraft:stripped_dark_oak_log
fill 558 179 344 558 180 344 minecraft:stripped_dark_oak_log
fill 558 179 351 558 180 351 minecraft:stripped_dark_oak_log
fill 518 180 323 518 180 324 minecraft:stripped_dark_oak_log
fill 518 180 326 518 180 327 minecraft:stripped_dark_oak_log
fill 518 180 329 518 180 331 minecraft:stripped_dark_oak_log
fill 518 180 333 518 180 334 minecraft:stripped_dark_oak_log
fill 518 180 336 518 180 338 minecraft:stripped_dark_oak_log
fill 518 180 340 518 180 341 minecraft:stripped_dark_oak_log
fill 518 180 343 518 180 345 minecraft:stripped_dark_oak_log
fill 518 180 347 518 180 348 minecraft:stripped_dark_oak_log
fill 518 180 350 518 180 352 minecraft:stripped_dark_oak_log
fill 518 180 354 518 180 355 minecraft:stripped_dark_oak_log
fill 518 180 357 518 180 359 minecraft:stripped_dark_oak_log
fill 518 180 361 518 180 362 minecraft:stripped_dark_oak_log
setblock 519 180 323 minecraft:stripped_dark_oak_log
fill 519 180 330 519 181 330 minecraft:iron_bars
fill 519 180 331 520 180 337 minecraft:red_concrete
fill 519 180 363 521 180 363 minecraft:stripped_dark_oak_log
setblock 520 180 325 minecraft:light[level=14]
setblock 520 180 341 minecraft:light[level=14]
setblock 520 180 349 minecraft:light[level=14]
setblock 520 180 357 minecraft:light[level=14]
fill 521 180 323 522 180 323 minecraft:stripped_dark_oak_log
fill 523 180 363 524 180 363 minecraft:stripped_dark_oak_log
fill 524 180 323 526 180 323 minecraft:stripped_dark_oak_log
fill 526 180 363 528 180 363 minecraft:stripped_dark_oak_log
fill 528 180 323 529 180 323 minecraft:stripped_dark_oak_log
setblock 528 180 325 minecraft:light[level=14]
setblock 528 180 333 minecraft:light[level=14]
setblock 528 180 341 minecraft:light[level=14]
setblock 528 180 349 minecraft:light[level=14]
setblock 528 180 357 minecraft:light[level=14]
fill 530 180 363 531 180 363 minecraft:stripped_dark_oak_log
fill 531 180 323 533 180 323 minecraft:stripped_dark_oak_log
fill 533 180 363 535 180 363 minecraft:stripped_dark_oak_log
fill 535 180 323 536 180 323 minecraft:stripped_dark_oak_log
setblock 536 180 325 minecraft:light[level=14]
setblock 536 180 333 minecraft:light[level=14]
setblock 536 180 341 minecraft:light[level=14]
setblock 536 180 349 minecraft:light[level=14]
setblock 536 180 357 minecraft:light[level=14]
fill 537 180 363 538 180 363 minecraft:stripped_dark_oak_log
fill 538 180 323 540 180 323 minecraft:stripped_dark_oak_log
fill 540 180 363 542 180 363 minecraft:stripped_dark_oak_log
fill 542 180 323 543 180 323 minecraft:stripped_dark_oak_log
setblock 544 180 325 minecraft:light[level=14]
setblock 544 180 333 minecraft:light[level=14]
setblock 544 180 341 minecraft:light[level=14]
setblock 544 180 349 minecraft:light[level=14]
setblock 544 180 357 minecraft:light[level=14]
setblock 544 180 363 minecraft:stripped_dark_oak_log
fill 545 180 323 547 180 323 minecraft:stripped_dark_oak_log
fill 549 180 323 550 180 323 minecraft:stripped_dark_oak_log
fill 552 180 323 554 180 323 minecraft:stripped_dark_oak_log
setblock 552 180 325 minecraft:light[level=14]
setblock 552 180 333 minecraft:light[level=14]
setblock 552 180 341 minecraft:light[level=14]
setblock 552 180 349 minecraft:light[level=14]
setblock 552 180 357 minecraft:light[level=14]
fill 556 180 323 557 180 323 minecraft:stripped_dark_oak_log
fill 558 180 324 558 180 326 minecraft:stripped_dark_oak_log
fill 558 180 328 558 180 329 minecraft:stripped_dark_oak_log
fill 558 180 331 558 180 333 minecraft:stripped_dark_oak_log
fill 558 180 335 558 180 336 minecraft:stripped_dark_oak_log
fill 558 180 338 558 180 340 minecraft:stripped_dark_oak_log
fill 558 180 342 558 180 343 minecraft:stripped_dark_oak_log
fill 558 180 345 558 180 347 minecraft:stripped_dark_oak_log
fill 558 180 349 558 180 350 minecraft:stripped_dark_oak_log
fill 558 180 352 558 180 354 minecraft:stripped_dark_oak_log
fill 558 180 356 558 180 357 minecraft:stripped_dark_oak_log
fill 558 180 359 558 180 361 minecraft:stripped_dark_oak_log
setblock 558 180 363 minecraft:stripped_dark_oak_log
setblock 518 181 327 minecraft:stripped_dark_oak_log
fill 518 181 332 521 181 333 minecraft:red_concrete
setblock 518 181 334 minecraft:stripped_dark_oak_log
fill 518 181 336 521 181 336 minecraft:red_concrete
setblock 518 181 341 minecraft:stripped_dark_oak_log
setblock 518 181 348 minecraft:stripped_dark_oak_log
setblock 518 181 355 minecraft:stripped_dark_oak_log
setblock 518 181 362 minecraft:stripped_dark_oak_log
setblock 519 181 331 minecraft:iron_bars
fill 519 181 334 521 182 335 minecraft:red_concrete
setblock 521 181 323 minecraft:stripped_dark_oak_log
setblock 524 181 363 minecraft:stripped_dark_oak_log
setblock 528 181 323 minecraft:stripped_dark_oak_log
setblock 531 181 363 minecraft:stripped_dark_oak_log
setblock 535 181 323 minecraft:stripped_dark_oak_log
setblock 538 181 363 minecraft:stripped_dark_oak_log
setblock 542 181 323 minecraft:stripped_dark_oak_log
setblock 545 181 358 minecraft:shroomlight
setblock 545 181 360 minecraft:shroomlight
setblock 545 181 362 minecraft:shroomlight
setblock 546 181 359 minecraft:shroomlight
setblock 546 181 361 minecraft:shroomlight
setblock 546 181 363 minecraft:shroomlight
setblock 547 181 358 minecraft:shroomlight
setblock 547 181 360 minecraft:shroomlight
setblock 547 181 362 minecraft:shroomlight
setblock 548 181 359 minecraft:shroomlight
setblock 548 181 361 minecraft:shroomlight
setblock 548 181 363 minecraft:shroomlight
setblock 549 181 323 minecraft:stripped_dark_oak_log
setblock 549 181 358 minecraft:shroomlight
setblock 549 181 360 minecraft:shroomlight
setblock 549 181 362 minecraft:shroomlight
setblock 550 181 359 minecraft:shroomlight
setblock 550 181 361 minecraft:shroomlight
setblock 550 181 363 minecraft:shroomlight
setblock 551 181 358 minecraft:shroomlight
setblock 551 181 360 minecraft:shroomlight
setblock 551 181 362 minecraft:shroomlight
setblock 552 181 359 minecraft:shroomlight
setblock 552 181 361 minecraft:shroomlight
setblock 552 181 363 minecraft:shroomlight
setblock 553 181 358 minecraft:shroomlight
setblock 553 181 360 minecraft:shroomlight
setblock 553 181 362 minecraft:shroomlight
setblock 554 181 359 minecraft:shroomlight
setblock 554 181 361 minecraft:shroomlight
setblock 554 181 363 minecraft:shroomlight
setblock 555 181 358 minecraft:shroomlight
setblock 555 181 360 minecraft:shroomlight
setblock 555 181 362 minecraft:shroomlight
setblock 556 181 323 minecraft:stripped_dark_oak_log
setblock 556 181 359 minecraft:shroomlight
setblock 556 181 361 minecraft:shroomlight
setblock 556 181 363 minecraft:shroomlight
setblock 557 181 358 minecraft:shroomlight
setblock 557 181 360 minecraft:shroomlight
setblock 557 181 362 minecraft:shroomlight
setblock 558 181 328 minecraft:stripped_dark_oak_log
setblock 558 181 335 minecraft:stripped_dark_oak_log
setblock 558 181 342 minecraft:stripped_dark_oak_log
setblock 558 181 349 minecraft:stripped_dark_oak_log
setblock 558 181 356 minecraft:stripped_dark_oak_log
fill 518 182 333 518 182 334 minecraft:red_concrete
fill 519 182 333 522 182 333 minecraft:red_concrete
fill 522 182 334 522 182 335 minecraft:red_concrete
fill 545 182 358 545 184 358 minecraft:stripped_dark_oak_log
fill 545 182 360 545 184 360 minecraft:stripped_dark_oak_log
fill 545 182 362 545 184 362 minecraft:stripped_dark_oak_log
fill 546 182 359 546 184 359 minecraft:stripped_dark_oak_log
fill 546 182 361 546 184 361 minecraft:stripped_dark_oak_log
fill 546 182 363 546 217 363 minecraft:stripped_dark_oak_log
fill 547 182 358 547 184 358 minecraft:stripped_dark_oak_log
fill 547 182 360 547 184 360 minecraft:stripped_dark_oak_log
fill 547 182 362 547 184 362 minecraft:stripped_dark_oak_log
fill 548 182 359 548 184 359 minecraft:stripped_dark_oak_log
fill 548 182 361 548 184 361 minecraft:stripped_dark_oak_log
fill 548 182 363 548 184 363 minecraft:stripped_dark_oak_log
fill 549 182 358 549 184 358 minecraft:stripped_dark_oak_log
fill 549 182 360 549 184 360 minecraft:stripped_dark_oak_log
fill 549 182 362 549 184 362 minecraft:stripped_dark_oak_log
fill 550 182 359 550 184 359 minecraft:stripped_dark_oak_log
fill 550 182 361 550 184 361 minecraft:stripped_dark_oak_log
fill 550 182 363 550 184 363 minecraft:stripped_dark_oak_log
fill 551 182 358 551 184 358 minecraft:stripped_dark_oak_log
fill 551 182 360 551 184 360 minecraft:stripped_dark_oak_log
fill 551 182 362 551 184 362 minecraft:stripped_dark_oak_log
fill 552 182 359 552 184 359 minecraft:stripped_dark_oak_log
fill 552 182 361 552 184 361 minecraft:stripped_dark_oak_log
fill 552 182 363 552 184 363 minecraft:stripped_dark_oak_log
fill 553 182 358 553 184 358 minecraft:stripped_dark_oak_log
fill 553 182 360 553 184 360 minecraft:stripped_dark_oak_log
fill 553 182 362 553 184 362 minecraft:stripped_dark_oak_log
fill 554 182 359 554 184 359 minecraft:stripped_dark_oak_log
fill 554 182 361 554 184 361 minecraft:stripped_dark_oak_log
fill 554 182 363 554 184 363 minecraft:stripped_dark_oak_log
fill 555 182 358 555 184 358 minecraft:stripped_dark_oak_log
fill 555 182 360 555 184 360 minecraft:stripped_dark_oak_log
fill 555 182 362 555 184 362 minecraft:stripped_dark_oak_log
fill 556 182 359 556 184 359 minecraft:stripped_dark_oak_log
fill 556 182 361 556 184 361 minecraft:stripped_dark_oak_log
fill 556 182 363 556 185 363 minecraft:stripped_dark_oak_log
fill 557 182 358 557 184 358 minecraft:stripped_dark_oak_log
fill 557 182 360 557 184 360 minecraft:stripped_dark_oak_log
fill 557 182 362 557 184 362 minecraft:stripped_dark_oak_log
setblock 518 183 329 minecraft:stripped_dark_oak_log
setblock 518 183 336 minecraft:stripped_dark_oak_log
setblock 518 183 343 minecraft:stripped_dark_oak_log
setblock 518 183 350 minecraft:stripped_dark_oak_log
setblock 518 183 357 minecraft:stripped_dark_oak_log
setblock 519 183 323 minecraft:stripped_dark_oak_log
setblock 519 183 363 minecraft:stripped_dark_oak_log
setblock 526 183 323 minecraft:stripped_dark_oak_log
setblock 526 183 363 minecraft:stripped_dark_oak_log
setblock 533 183 323 minecraft:stripped_dark_oak_log
setblock 533 183 363 minecraft:stripped_dark_oak_log
setblock 540 183 323 minecraft:stripped_dark_oak_log
setblock 540 183 363 minecraft:stripped_dark_oak_log
setblock 547 183 323 minecraft:stripped_dark_oak_log
setblock 554 183 323 minecraft:stripped_dark_oak_log
setblock 558 183 326 minecraft:stripped_dark_oak_log
setblock 558 183 333 minecraft:stripped_dark_oak_log
setblock 558 183 340 minecraft:stripped_dark_oak_log
setblock 558 183 347 minecraft:stripped_dark_oak_log
setblock 558 183 354 minecraft:stripped_dark_oak_log
setblock 558 183 361 minecraft:stripped_dark_oak_log
setblock 518 184 323 minecraft:stripped_dark_oak_log
setblock 518 184 330 minecraft:stripped_dark_oak_log
setblock 518 184 337 minecraft:stripped_dark_oak_log
setblock 518 184 344 minecraft:stripped_dark_oak_log
setblock 518 184 351 minecraft:stripped_dark_oak_log
setblock 518 184 358 minecraft:stripped_dark_oak_log
setblock 520 184 363 minecraft:stripped_dark_oak_log
setblock 525 184 323 minecraft:stripped_dark_oak_log
setblock 527 184 363 minecraft:stripped_dark_oak_log
setblock 532 184 323 minecraft:stripped_dark_oak_log
setblock 534 184 363 minecraft:stripped_dark_oak_log
fill 538 184 324 538 185 324 minecraft:pink_wool
setblock 539 184 323 minecraft:stripped_dark_oak_log
setblock 541 184 363 minecraft:stripped_dark_oak_log
setblock 546 184 323 minecraft:stripped_dark_oak_log
setblock 553 184 323 minecraft:stripped_dark_oak_log
setblock 558 184 325 minecraft:stripped_dark_oak_log
setblock 558 184 332 minecraft:stripped_dark_oak_log
setblock 558 184 339 minecraft:stripped_dark_oak_log
setblock 558 184 346 minecraft:stripped_dark_oak_log
setblock 558 184 353 minecraft:stripped_dark_oak_log
setblock 558 184 360 minecraft:stripped_dark_oak_log
setblock 518 185 324 minecraft:stripped_dark_oak_log
setblock 518 185 331 minecraft:stripped_dark_oak_log
setblock 518 185 338 minecraft:stripped_dark_oak_log
setblock 518 185 345 minecraft:stripped_dark_oak_log
setblock 518 185 352 minecraft:stripped_dark_oak_log
setblock 518 185 359 minecraft:stripped_dark_oak_log
setblock 521 185 363 minecraft:stripped_dark_oak_log
setblock 524 185 323 minecraft:stripped_dark_oak_log
setblock 528 185 363 minecraft:stripped_dark_oak_log
setblock 531 185 323 minecraft:stripped_dark_oak_log
setblock 535 185 363 minecraft:stripped_dark_oak_log
setblock 538 185 323 minecraft:stripped_dark_oak_log
setblock 542 185 363 minecraft:stripped_dark_oak_log
setblock 545 185 323 minecraft:stripped_dark_oak_log
fill 546 185 359 556 185 362 minecraft:red_concrete
setblock 552 185 323 minecraft:stripped_dark_oak_log
setblock 558 185 324 minecraft:stripped_dark_oak_log
setblock 558 185 331 minecraft:stripped_dark_oak_log
setblock 558 185 338 minecraft:stripped_dark_oak_log
setblock 558 185 345 minecraft:stripped_dark_oak_log
setblock 558 185 352 minecraft:stripped_dark_oak_log
setblock 558 185 359 minecraft:stripped_dark_oak_log
setblock 518 186 325 minecraft:stripped_dark_oak_log
setblock 518 186 332 minecraft:stripped_dark_oak_log
setblock 518 186 339 minecraft:stripped_dark_oak_log
setblock 518 186 346 minecraft:stripped_dark_oak_log
setblock 518 186 353 minecraft:stripped_dark_oak_log
setblock 518 186 360 minecraft:stripped_dark_oak_log
setblock 522 186 363 minecraft:stripped_dark_oak_log
setblock 523 186 323 minecraft:stripped_dark_oak_log
setblock 529 186 363 minecraft:stripped_dark_oak_log
setblock 530 186 323 minecraft:stripped_dark_oak_log
setblock 536 186 363 minecraft:stripped_dark_oak_log
setblock 537 186 323 minecraft:stripped_dark_oak_log
setblock 543 186 363 minecraft:stripped_dark_oak_log
setblock 544 186 323 minecraft:stripped_dark_oak_log
fill 547 186 360 555 186 361 minecraft:red_concrete
setblock 550 186 363 minecraft:stripped_dark_oak_log
setblock 551 186 323 minecraft:stripped_dark_oak_log
setblock 557 186 363 minecraft:stripped_dark_oak_log
setblock 558 186 323 minecraft:stripped_dark_oak_log
setblock 558 186 330 minecraft:stripped_dark_oak_log
setblock 558 186 337 minecraft:stripped_dark_oak_log
setblock 558 186 344 minecraft:stripped_dark_oak_log
setblock 558 186 351 minecraft:stripped_dark_oak_log
setblock 558 186 358 minecraft:stripped_dark_oak_log
setblock 518 187 326 minecraft:stripped_dark_oak_log
setblock 518 187 333 minecraft:stripped_dark_oak_log
setblock 518 187 340 minecraft:stripped_dark_oak_log
setblock 518 187 347 minecraft:stripped_dark_oak_log
setblock 518 187 354 minecraft:stripped_dark_oak_log
setblock 518 187 361 minecraft:stripped_dark_oak_log
setblock 522 187 323 minecraft:stripped_dark_oak_log
setblock 523 187 363 minecraft:stripped_dark_oak_log
setblock 529 187 323 minecraft:stripped_dark_oak_log
setblock 530 187 363 minecraft:stripped_dark_oak_log
setblock 536 187 323 minecraft:stripped_dark_oak_log
setblock 537 187 363 minecraft:stripped_dark_oak_log
setblock 543 187 323 minecraft:stripped_dark_oak_log
setblock 544 187 363 minecraft:stripped_dark_oak_log
fill 548 187 360 554 187 361 minecraft:red_concrete
setblock 550 187 323 minecraft:stripped_dark_oak_log
setblock 551 187 363 minecraft:stripped_dark_oak_log
setblock 557 187 323 minecraft:stripped_dark_oak_log
setblock 558 187 329 minecraft:stripped_dark_oak_log
setblock 558 187 336 minecraft:stripped_dark_oak_log
setblock 558 187 343 minecraft:stripped_dark_oak_log
setblock 558 187 350 minecraft:stripped_dark_oak_log
setblock 558 187 357 minecraft:stripped_dark_oak_log
setblock 558 187 363 minecraft:stripped_dark_oak_log
setblock 518 188 327 minecraft:stripped_dark_oak_log
setblock 518 188 334 minecraft:stripped_dark_oak_log
setblock 518 188 341 minecraft:stripped_dark_oak_log
setblock 518 188 348 minecraft:stripped_dark_oak_log
setblock 518 188 355 minecraft:stripped_dark_oak_log
setblock 518 188 362 minecraft:stripped_dark_oak_log
setblock 520 188 325 minecraft:light[level=14]
setblock 520 188 333 minecraft:light[level=14]
setblock 520 188 341 minecraft:light[level=14]
setblock 520 188 349 minecraft:light[level=14]
setblock 520 188 357 minecraft:light[level=14]
setblock 521 188 323 minecraft:stripped_dark_oak_log
setblock 524 188 363 minecraft:stripped_dark_oak_log
setblock 528 188 323 minecraft:stripped_dark_oak_log
setblock 528 188 325 minecraft:light[level=14]
setblock 528 188 333 minecraft:light[level=14]
setblock 528 188 341 minecraft:light[level=14]
setblock 528 188 349 minecraft:light[level=14]
setblock 528 188 357 minecraft:light[level=14]
setblock 531 188 363 minecraft:stripped_dark_oak_log
setblock 535 188 323 minecraft:stripped_dark_oak_log
setblock 536 188 325 minecraft:light[level=14]
setblock 536 188 333 minecraft:light[level=14]
setblock 536 188 341 minecraft:light[level=14]
setblock 536 188 349 minecraft:light[level=14]
setblock 536 188 357 minecraft:light[level=14]
setblock 538 188 363 minecraft:stripped_dark_oak_log
setblock 542 188 323 minecraft:stripped_dark_oak_log
setblock 544 188 325 minecraft:light[level=14]
setblock 544 188 333 minecraft:light[level=14]
setblock 544 188 341 minecraft:light[level=14]
setblock 544 188 349 minecraft:light[level=14]
setblock 544 188 357 minecraft:light[level=14]
setblock 545 188 363 minecraft:stripped_dark_oak_log
setblock 549 188 323 minecraft:stripped_dark_oak_log
fill 549 188 359 553 188 362 minecraft:red_concrete
setblock 552 188 325 minecraft:light[level=14]
setblock 552 188 333 minecraft:light[level=14]
setblock 552 188 341 minecraft:light[level=14]
setblock 552 188 349 minecraft:light[level=14]
setblock 552 188 357 minecraft:light[level=14]
setblock 552 188 363 minecraft:stripped_dark_oak_log
setblock 556 188 323 minecraft:stripped_dark_oak_log
setblock 558 188 328 minecraft:stripped_dark_oak_log
setblock 558 188 335 minecraft:stripped_dark_oak_log
setblock 558 188 342 minecraft:stripped_dark_oak_log
setblock 558 188 349 minecraft:stripped_dark_oak_log
setblock 558 188 356 minecraft:stripped_dark_oak_log
fill 518 190 323 518 190 327 minecraft:stripped_dark_oak_log
fill 518 190 329 518 190 334 minecraft:stripped_dark_oak_log
fill 518 190 336 518 190 341 minecraft:stripped_dark_oak_log
fill 518 190 343 518 190 348 minecraft:stripped_dark_oak_log
fill 518 190 350 518 190 355 minecraft:stripped_dark_oak_log
fill 518 190 357 518 190 362 minecraft:stripped_dark_oak_log
setblock 519 190 323 minecraft:stripped_dark_oak_log
fill 519 190 363 524 190 363 minecraft:stripped_dark_oak_log
fill 521 190 323 526 190 323 minecraft:stripped_dark_oak_log
fill 526 190 363 531 190 363 minecraft:stripped_dark_oak_log
fill 528 190 323 533 190 323 minecraft:stripped_dark_oak_log
fill 533 190 363 538 190 363 minecraft:stripped_dark_oak_log
fill 535 190 323 540 190 323 minecraft:stripped_dark_oak_log
fill 540 190 363 545 190 363 minecraft:stripped_dark_oak_log
fill 542 190 323 547 190 323 minecraft:stripped_dark_oak_log
fill 547 190 363 552 190 363 minecraft:stripped_dark_oak_log
fill 549 190 323 554 190 323 minecraft:stripped_dark_oak_log
fill 554 190 363 558 190 363 minecraft:stripped_dark_oak_log
fill 556 190 323 558 190 323 minecraft:stripped_dark_oak_log
fill 558 190 324 558 190 326 minecraft:stripped_dark_oak_log
fill 558 190 328 558 190 333 minecraft:stripped_dark_oak_log
fill 558 190 335 558 190 340 minecraft:stripped_dark_oak_log
fill 558 190 342 558 190 347 minecraft:stripped_dark_oak_log
fill 558 190 349 558 190 354 minecraft:stripped_dark_oak_log
fill 558 190 356 558 190 361 minecraft:stripped_dark_oak_log
setblock 518 191 323 minecraft:stripped_dark_oak_log
setblock 518 191 330 minecraft:stripped_dark_oak_log
setblock 518 191 337 minecraft:stripped_dark_oak_log
setblock 518 191 344 minecraft:stripped_dark_oak_log
setblock 518 191 351 minecraft:stripped_dark_oak_log
setblock 518 191 358 minecraft:stripped_dark_oak_log
setblock 520 191 363 minecraft:stripped_dark_oak_log
setblock 525 191 323 minecraft:stripped_dark_oak_log
setblock 527 191 363 minecraft:stripped_dark_oak_log
setblock 532 191 323 minecraft:stripped_dark_oak_log
setblock 534 191 363 minecraft:stripped_dark_oak_log
setblock 539 191 323 minecraft:stripped_dark_oak_log
setblock 541 191 363 minecraft:stripped_dark_oak_log
setblock 546 191 323 minecraft:stripped_dark_oak_log
setblock 548 191 363 minecraft:stripped_dark_oak_log
setblock 553 191 323 minecraft:stripped_dark_oak_log
setblock 555 191 363 minecraft:stripped_dark_oak_log
setblock 558 191 325 minecraft:stripped_dark_oak_log
setblock 558 191 332 minecraft:stripped_dark_oak_log
setblock 558 191 339 minecraft:stripped_dark_oak_log
setblock 558 191 346 minecraft:stripped_dark_oak_log
setblock 558 191 353 minecraft:stripped_dark_oak_log
setblock 558 191 360 minecraft:stripped_dark_oak_log
setblock 518 192 324 minecraft:stripped_dark_oak_log
setblock 518 192 331 minecraft:stripped_dark_oak_log
setblock 518 192 338 minecraft:stripped_dark_oak_log
setblock 518 192 345 minecraft:stripped_dark_oak_log
setblock 518 192 352 minecraft:stripped_dark_oak_log
setblock 518 192 359 minecraft:stripped_dark_oak_log
setblock 521 192 363 minecraft:stripped_dark_oak_log
setblock 524 192 323 minecraft:stripped_dark_oak_log
setblock 528 192 363 minecraft:stripped_dark_oak_log
setblock 531 192 323 minecraft:stripped_dark_oak_log
setblock 535 192 363 minecraft:stripped_dark_oak_log
setblock 538 192 323 minecraft:stripped_dark_oak_log
setblock 542 192 363 minecraft:stripped_dark_oak_log
setblock 545 192 323 minecraft:stripped_dark_oak_log
setblock 549 192 363 minecraft:stripped_dark_oak_log
setblock 552 192 323 minecraft:stripped_dark_oak_log
setblock 556 192 363 minecraft:stripped_dark_oak_log
setblock 558 192 324 minecraft:stripped_dark_oak_log
setblock 558 192 331 minecraft:stripped_dark_oak_log
setblock 558 192 338 minecraft:stripped_dark_oak_log
setblock 558 192 345 minecraft:stripped_dark_oak_log
setblock 558 192 352 minecraft:stripped_dark_oak_log
setblock 558 192 359 minecraft:stripped_dark_oak_log
setblock 518 193 325 minecraft:stripped_dark_oak_log
setblock 518 193 332 minecraft:stripped_dark_oak_log
setblock 518 193 339 minecraft:stripped_dark_oak_log
setblock 518 193 346 minecraft:stripped_dark_oak_log
setblock 518 193 353 minecraft:stripped_dark_oak_log
setblock 518 193 360 minecraft:stripped_dark_oak_log
setblock 522 193 363 minecraft:stripped_dark_oak_log
setblock 523 193 323 minecraft:stripped_dark_oak_log
setblock 529 193 363 minecraft:stripped_dark_oak_log
setblock 530 193 323 minecraft:stripped_dark_oak_log
setblock 536 193 363 minecraft:stripped_dark_oak_log
setblock 537 193 323 minecraft:stripped_dark_oak_log
setblock 543 193 363 minecraft:stripped_dark_oak_log
setblock 544 193 323 minecraft:stripped_dark_oak_log
setblock 550 193 363 minecraft:stripped_dark_oak_log
setblock 551 193 323 minecraft:stripped_dark_oak_log
setblock 557 193 363 minecraft:stripped_dark_oak_log
setblock 558 193 323 minecraft:stripped_dark_oak_log
setblock 558 193 330 minecraft:stripped_dark_oak_log
setblock 558 193 337 minecraft:stripped_dark_oak_log
setblock 558 193 344 minecraft:stripped_dark_oak_log
setblock 558 193 351 minecraft:stripped_dark_oak_log
setblock 558 193 358 minecraft:stripped_dark_oak_log
setblock 518 194 326 minecraft:stripped_dark_oak_log
setblock 518 194 333 minecraft:stripped_dark_oak_log
setblock 518 194 340 minecraft:stripped_dark_oak_log
setblock 518 194 347 minecraft:stripped_dark_oak_log
setblock 518 194 354 minecraft:stripped_dark_oak_log
setblock 518 194 361 minecraft:stripped_dark_oak_log
setblock 522 194 323 minecraft:stripped_dark_oak_log
setblock 523 194 363 minecraft:stripped_dark_oak_log
setblock 529 194 323 minecraft:stripped_dark_oak_log
setblock 530 194 363 minecraft:stripped_dark_oak_log
setblock 536 194 323 minecraft:stripped_dark_oak_log
setblock 537 194 363 minecraft:stripped_dark_oak_log
setblock 543 194 323 minecraft:stripped_dark_oak_log
setblock 544 194 363 minecraft:stripped_dark_oak_log
setblock 550 194 323 minecraft:stripped_dark_oak_log
setblock 551 194 363 minecraft:stripped_dark_oak_log
setblock 557 194 323 minecraft:stripped_dark_oak_log
setblock 558 194 329 minecraft:stripped_dark_oak_log
setblock 558 194 336 minecraft:stripped_dark_oak_log
setblock 558 194 343 minecraft:stripped_dark_oak_log
setblock 558 194 350 minecraft:stripped_dark_oak_log
setblock 558 194 357 minecraft:stripped_dark_oak_log
setblock 558 194 363 minecraft:stripped_dark_oak_log
setblock 518 195 327 minecraft:stripped_dark_oak_log
setblock 518 195 334 minecraft:stripped_dark_oak_log
setblock 518 195 341 minecraft:stripped_dark_oak_log
setblock 518 195 348 minecraft:stripped_dark_oak_log
setblock 518 195 355 minecraft:stripped_dark_oak_log
setblock 518 195 362 minecraft:stripped_dark_oak_log
setblock 521 195 323 minecraft:stripped_dark_oak_log
setblock 524 195 363 minecraft:stripped_dark_oak_log
setblock 528 195 323 minecraft:stripped_dark_oak_log
setblock 531 195 363 minecraft:stripped_dark_oak_log
setblock 535 195 323 minecraft:stripped_dark_oak_log
setblock 538 195 363 minecraft:stripped_dark_oak_log
setblock 542 195 323 minecraft:stripped_dark_oak_log
setblock 545 195 363 minecraft:stripped_dark_oak_log
setblock 549 195 323 minecraft:stripped_dark_oak_log
setblock 552 195 363 minecraft:stripped_dark_oak_log
setblock 556 195 323 minecraft:stripped_dark_oak_log
setblock 558 195 328 minecraft:stripped_dark_oak_log
setblock 558 195 335 minecraft:stripped_dark_oak_log
setblock 558 195 342 minecraft:stripped_dark_oak_log
setblock 558 195 349 minecraft:stripped_dark_oak_log
setblock 558 195 356 minecraft:stripped_dark_oak_log
setblock 520 196 325 minecraft:light[level=14]
setblock 520 196 333 minecraft:light[level=14]
setblock 520 196 341 minecraft:light[level=14]
setblock 520 196 349 minecraft:light[level=14]
setblock 520 196 357 minecraft:light[level=14]
setblock 528 196 325 minecraft:light[level=14]
setblock 528 196 333 minecraft:light[level=14]
setblock 528 196 341 minecraft:light[level=14]
setblock 528 196 349 minecraft:light[level=14]
setblock 528 196 357 minecraft:light[level=14]
setblock 536 196 325 minecraft:light[level=14]
setblock 536 196 333 minecraft:light[level=14]
setblock 536 196 341 minecraft:light[level=14]
setblock 536 196 349 minecraft:light[level=14]
setblock 536 196 357 minecraft:light[level=14]
setblock 544 196 325 minecraft:light[level=14]
setblock 544 196 333 minecraft:light[level=14]
setblock 544 196 341 minecraft:light[level=14]
setblock 544 196 349 minecraft:light[level=14]
setblock 544 196 357 minecraft:light[level=14]
setblock 552 196 325 minecraft:light[level=14]
setblock 552 196 333 minecraft:light[level=14]
setblock 552 196 341 minecraft:light[level=14]
setblock 552 196 349 minecraft:light[level=14]
setblock 552 196 357 minecraft:light[level=14]
fill 517 197 329 517 197 331 minecraft:light_gray_terracotta
setblock 517 197 332 minecraft:white_terracotta
fill 517 197 333 517 200 335 minecraft:light_gray_terracotta
fill 517 197 337 517 200 338 minecraft:light_gray_terracotta
setblock 517 197 339 minecraft:white_terracotta
fill 517 197 340 517 198 340 minecraft:light_gray_terracotta
fill 517 197 342 517 198 343 minecraft:light_gray_terracotta
setblock 517 197 344 minecraft:white_terracotta
fill 517 197 345 517 198 347 minecraft:light_gray_terracotta
fill 517 197 355 517 197 356 minecraft:white_terracotta
fill 517 197 357 517 200 357 minecraft:light_gray_terracotta
setblock 518 197 329 minecraft:stripped_dark_oak_log
setblock 518 197 336 minecraft:stripped_dark_oak_log
setblock 518 197 343 minecraft:stripped_dark_oak_log
setblock 518 197 350 minecraft:stripped_dark_oak_log
setblock 518 197 357 minecraft:stripped_dark_oak_log
setblock 519 197 323 minecraft:stripped_dark_oak_log
setblock 519 197 363 minecraft:stripped_dark_oak_log
fill 523 197 322 528 197 322 minecraft:light_gray_terracotta
setblock 526 197 323 minecraft:stripped_dark_oak_log
setblock 526 197 363 minecraft:stripped_dark_oak_log
fill 527 197 364 528 200 364 minecraft:light_gray_terracotta
setblock 529 197 322 minecraft:white_terracotta
setblock 529 197 364 minecraft:white_terracotta
fill 530 197 322 532 200 322 minecraft:light_gray_terracotta
fill 530 197 364 531 200 364 minecraft:light_gray_terracotta
setblock 533 197 322 minecraft:white_terracotta
setblock 533 197 323 minecraft:stripped_dark_oak_log
setblock 533 197 363 minecraft:stripped_dark_oak_log
fill 534 197 322 535 198 322 minecraft:light_gray_terracotta
setblock 538 197 322 minecraft:light_gray_terracotta
setblock 539 197 322 minecraft:white_terracotta
setblock 539 197 364 minecraft:white_terracotta
fill 540 197 322 541 200 322 minecraft:light_gray_terracotta
setblock 540 197 323 minecraft:stripped_dark_oak_log
setblock 540 197 363 minecraft:stripped_dark_oak_log
fill 540 197 364 540 200 364 minecraft:light_gray_terracotta
setblock 541 197 364 minecraft:white_terracotta
fill 542 197 364 543 200 364 minecraft:light_gray_terracotta
setblock 543 197 322 minecraft:white_terracotta
fill 544 197 322 548 200 322 minecraft:light_gray_terracotta
fill 545 197 364 549 200 364 minecraft:light_gray_terracotta
fill 546 197 329 548 198 329 minecraft:cherry_leaves[persistent=true]
setblock 547 197 323 minecraft:stripped_dark_oak_log
fill 547 197 328 547 198 328 minecraft:cherry_leaves[persistent=true]
fill 547 197 330 547 198 330 minecraft:cherry_leaves[persistent=true]
setblock 547 197 363 minecraft:stripped_dark_oak_log
setblock 549 197 322 minecraft:white_terracotta
setblock 550 197 364 minecraft:white_terracotta
fill 551 197 322 551 198 322 minecraft:white_terracotta
fill 551 197 364 555 198 364 minecraft:light_gray_terracotta
fill 552 197 322 552 200 322 minecraft:light_gray_terracotta
setblock 554 197 323 minecraft:stripped_dark_oak_log
setblock 554 197 363 minecraft:stripped_dark_oak_log
fill 556 197 364 556 198 364 minecraft:white_terracotta
setblock 558 197 326 minecraft:stripped_dark_oak_log
setblock 558 197 333 minecraft:stripped_dark_oak_log
setblock 558 197 340 minecraft:stripped_dark_oak_log
setblock 558 197 347 minecraft:stripped_dark_oak_log
setblock 558 197 354 minecraft:stripped_dark_oak_log
setblock 558 197 361 minecraft:stripped_dark_oak_log
setblock 558 197 364 minecraft:white_terracotta
setblock 559 197 322 minecraft:white_terracotta
fill 559 197 323 559 200 324 minecraft:light_gray_terracotta
fill 559 197 325 559 197 326 minecraft:white_terracotta
fill 559 197 327 559 200 328 minecraft:light_gray_terracotta
setblock 559 197 329 minecraft:white_terracotta
fill 559 197 330 559 200 330 minecraft:light_gray_terracotta
fill 559 197 331 559 198 331 minecraft:white_terracotta
fill 559 197 332 559 200 333 minecraft:light_gray_terracotta
setblock 559 197 344 minecraft:white_terracotta
setblock 559 197 345 minecraft:light_gray_terracotta
fill 559 197 355 559 200 357 minecraft:light_gray_terracotta
setblock 559 197 358 minecraft:white_terracotta
fill 559 197 359 559 200 364 minecraft:light_gray_terracotta
setblock 517 198 326 minecraft:white_terracotta
fill 517 198 327 517 200 327 minecraft:light_gray_terracotta
fill 517 198 329 517 200 329 minecraft:light_gray_terracotta
setblock 517 198 330 minecraft:white_terracotta
fill 517 198 331 517 200 332 minecraft:light_gray_terracotta
fill 517 198 339 517 200 339 minecraft:light_gray_terracotta
fill 517 198 344 517 200 344 minecraft:light_gray_terracotta
fill 517 198 355 517 198 356 minecraft:light_gray_terracotta
fill 517 198 358 517 200 363 minecraft:light_gray_terracotta
fill 517 198 364 518 198 364 minecraft:white_terracotta
setblock 518 198 323 minecraft:stripped_dark_oak_log
setblock 518 198 330 minecraft:stripped_dark_oak_log
setblock 518 198 337 minecraft:stripped_dark_oak_log
setblock 518 198 344 minecraft:stripped_dark_oak_log
setblock 518 198 351 minecraft:stripped_dark_oak_log
setblock 518 198 358 minecraft:stripped_dark_oak_log
fill 519 198 322 519 200 322 minecraft:light_gray_terracotta
fill 519 198 364 525 198 364 minecraft:light_gray_terracotta
setblock 520 198 322 minecraft:white_terracotta
setblock 520 198 363 minecraft:stripped_dark_oak_log
fill 523 198 322 524 200 322 minecraft:light_gray_terracotta
setblock 525 198 322 minecraft:white_terracotta
setblock 525 198 323 minecraft:stripped_dark_oak_log
fill 526 198 322 529 200 322 minecraft:light_gray_terracotta
setblock 526 198 364 minecraft:white_terracotta
setblock 527 198 363 minecraft:stripped_dark_oak_log
fill 529 198 364 529 200 364 minecraft:light_gray_terracotta
setblock 532 198 323 minecraft:stripped_dark_oak_log
setblock 532 198 364 minecraft:white_terracotta
fill 533 198 322 533 200 322 minecraft:light_gray_terracotta
setblock 534 198 363 minecraft:stripped_dark_oak_log
fill 534 198 364 537 198 364 minecraft:light_gray_terracotta
setblock 536 198 322 minecraft:white_terracotta
fill 537 198 322 537 200 322 minecraft:light_gray_terracotta
setblock 538 198 322 minecraft:white_terracotta
setblock 538 198 364 minecraft:white_terracotta
fill 539 198 322 539 200 322 minecraft:light_gray_terracotta
setblock 539 198 323 minecraft:stripped_dark_oak_log
fill 539 198 364 539 200 364 minecraft:light_gray_terracotta
setblock 541 198 363 minecraft:stripped_dark_oak_log
fill 541 198 364 541 201 364 minecraft:light_gray_terracotta
fill 543 198 322 543 200 322 minecraft:light_gray_terracotta
setblock 546 198 323 minecraft:stripped_dark_oak_log
setblock 548 198 363 minecraft:stripped_dark_oak_log
fill 549 198 322 549 200 322 minecraft:light_gray_terracotta
fill 550 198 364 550 200 364 minecraft:light_gray_terracotta
setblock 553 198 323 minecraft:stripped_dark_oak_log
setblock 555 198 363 minecraft:stripped_dark_oak_log
fill 556 198 322 557 200 322 minecraft:light_gray_terracotta
setblock 558 198 322 minecraft:white_terracotta
setblock 558 198 325 minecraft:stripped_dark_oak_log
setblock 558 198 332 minecraft:stripped_dark_oak_log
setblock 558 198 339 minecraft:stripped_dark_oak_log
setblock 558 198 346 minecraft:stripped_dark_oak_log
setblock 558 198 353 minecraft:stripped_dark_oak_log
setblock 558 198 360 minecraft:stripped_dark_oak_log
setblock 558 198 364 minecraft:light_gray_terracotta
fill 559 198 322 559 200 322 minecraft:light_gray_terracotta
fill 559 198 325 559 200 326 minecraft:light_gray_terracotta
setblock 559 198 329 minecraft:light_gray_terracotta
fill 559 198 344 559 200 344 minecraft:light_gray_terracotta
setblock 559 198 345 minecraft:white_terracotta
fill 559 198 346 559 200 346 minecraft:light_gray_terracotta
setblock 559 198 347 minecraft:white_terracotta
fill 559 198 358 559 200 358 minecraft:light_gray_terracotta
fill 517 199 326 517 200 326 minecraft:light_gray_terracotta
fill 517 199 330 517 200 330 minecraft:light_gray_terracotta
fill 517 199 340 517 199 342 minecraft:white_terracotta
fill 517 199 343 517 200 343 minecraft:light_gray_terracotta
fill 517 199 345 517 200 346 minecraft:light_gray_terracotta
setblock 517 199 347 minecraft:white_terracotta
setblock 517 199 355 minecraft:white_terracotta
fill 517 199 356 517 200 356 minecraft:light_gray_terracotta
fill 517 199 364 523 200 364 minecraft:light_gray_terracotta
fill 518 199 324 518 200 324 minecraft:stripped_dark_oak_log
fill 518 199 331 518 200 331 minecraft:stripped_dark_oak_log
fill 518 199 338 518 200 338 minecraft:stripped_dark_oak_log
fill 518 199 345 518 200 345 minecraft:stripped_dark_oak_log
fill 518 199 352 518 200 352 minecraft:stripped_dark_oak_log
fill 518 199 359 518 200 359 minecraft:stripped_dark_oak_log
fill 520 199 322 520 201 322 minecraft:light_gray_terracotta
fill 521 199 363 521 200 363 minecraft:stripped_dark_oak_log
setblock 522 199 322 minecraft:white_terracotta
fill 524 199 323 524 200 323 minecraft:stripped_dark_oak_log
setblock 524 199 364 minecraft:white_terracotta
fill 525 199 322 525 200 322 minecraft:light_gray_terracotta
fill 525 199 364 526 200 364 minecraft:light_gray_terracotta
fill 528 199 363 528 200 363 minecraft:stripped_dark_oak_log
fill 531 199 323 531 200 323 minecraft:stripped_dark_oak_log
fill 532 199 364 532 200 364 minecraft:light_gray_terracotta
fill 534 199 322 534 200 322 minecraft:light_gray_terracotta
setblock 534 199 364 minecraft:white_terracotta
setblock 535 199 322 minecraft:white_terracotta
fill 535 199 363 535 200 363 minecraft:stripped_dark_oak_log
fill 535 199 364 536 200 364 minecraft:light_gray_terracotta
fill 536 199 322 536 200 322 minecraft:light_gray_terracotta
setblock 537 199 364 minecraft:white_terracotta
fill 538 199 322 538 200 322 minecraft:light_gray_terracotta
fill 538 199 323 538 200 323 minecraft:stripped_dark_oak_log
fill 538 199 364 538 200 364 minecraft:light_gray_terracotta
fill 542 199 363 542 200 363 minecraft:stripped_dark_oak_log
fill 545 199 323 545 200 323 minecraft:stripped_dark_oak_log
fill 549 199 363 549 200 363 minecraft:stripped_dark_oak_log
fill 551 199 322 551 200 322 minecraft:light_gray_terracotta
setblock 551 199 364 minecraft:white_terracotta
fill 552 199 323 552 200 323 minecraft:stripped_dark_oak_log
fill 552 199 364 556 200 364 minecraft:light_gray_terracotta
fill 556 199 363 556 200 363 minecraft:stripped_dark_oak_log
fill 558 199 322 558 200 322 minecraft:light_gray_terracotta
fill 558 199 324 558 200 324 minecraft:stripped_dark_oak_log
fill 558 199 331 558 200 331 minecraft:stripped_dark_oak_log
fill 558 199 338 558 200 338 minecraft:stripped_dark_oak_log
fill 558 199 345 558 200 345 minecraft:stripped_dark_oak_log
fill 558 199 352 558 200 352 minecraft:stripped_dark_oak_log
fill 558 199 359 558 200 359 minecraft:stripped_dark_oak_log
setblock 558 199 364 minecraft:white_terracotta
setblock 559 199 329 minecraft:white_terracotta
fill 559 199 331 559 200 331 minecraft:light_gray_terracotta
fill 559 199 345 559 200 345 minecraft:light_gray_terracotta
fill 559 199 347 559 200 347 minecraft:light_gray_terracotta
setblock 559 199 348 minecraft:white_terracotta
fill 559 199 350 559 200 350 minecraft:light_gray_terracotta
setblock 559 199 351 minecraft:white_terracotta
fill 559 199 352 559 200 353 minecraft:light_gray_terracotta
fill 517 200 340 517 200 342 minecraft:light_gray_terracotta
setblock 517 200 347 minecraft:light_gray_terracotta
setblock 517 200 355 minecraft:light_gray_terracotta
fill 518 200 323 519 200 323 minecraft:stripped_dark_oak_log
fill 518 200 325 518 200 327 minecraft:stripped_dark_oak_log
fill 518 200 329 518 200 330 minecraft:stripped_dark_oak_log
fill 518 200 332 518 200 334 minecraft:stripped_dark_oak_log
fill 518 200 336 518 200 337 minecraft:stripped_dark_oak_log
fill 518 200 339 518 200 341 minecraft:stripped_dark_oak_log
fill 518 200 343 518 200 344 minecraft:stripped_dark_oak_log
fill 518 200 346 518 200 348 minecraft:stripped_dark_oak_log
fill 518 200 350 518 200 351 minecraft:stripped_dark_oak_log
fill 518 200 353 518 200 355 minecraft:stripped_dark_oak_log
fill 518 200 357 518 200 358 minecraft:stripped_dark_oak_log
fill 518 200 360 518 200 362 minecraft:stripped_dark_oak_log
fill 519 200 363 520 200 363 minecraft:stripped_dark_oak_log
fill 521 200 323 523 200 323 minecraft:stripped_dark_oak_log
setblock 522 200 322 minecraft:light_gray_terracotta
fill 522 200 363 524 200 363 minecraft:stripped_dark_oak_log
setblock 524 200 364 minecraft:light_gray_terracotta
fill 525 200 323 526 200 323 minecraft:stripped_dark_oak_log
fill 526 200 363 527 200 363 minecraft:stripped_dark_oak_log
fill 528 200 323 530 200 323 minecraft:stripped_dark_oak_log
fill 529 200 363 531 200 363 minecraft:stripped_dark_oak_log
fill 532 200 323 533 200 323 minecraft:stripped_dark_oak_log
fill 533 200 363 534 200 363 minecraft:stripped_dark_oak_log
setblock 534 200 364 minecraft:light_gray_terracotta
fill 535 200 322 535 201 322 minecraft:light_gray_terracotta
fill 535 200 323 537 200 323 minecraft:stripped_dark_oak_log
fill 536 200 363 538 200 363 minecraft:stripped_dark_oak_log
fill 537 200 364 537 201 364 minecraft:light_gray_terracotta
fill 539 200 323 540 200 323 minecraft:stripped_dark_oak_log
fill 540 200 363 541 200 363 minecraft:stripped_dark_oak_log
fill 542 200 323 544 200 323 minecraft:stripped_dark_oak_log
fill 543 200 363 545 200 363 minecraft:stripped_dark_oak_log
fill 546 200 323 547 200 323 minecraft:stripped_dark_oak_log
fill 547 200 363 548 200 363 minecraft:stripped_dark_oak_log
fill 549 200 323 551 200 323 minecraft:stripped_dark_oak_log
fill 550 200 363 552 200 363 minecraft:stripped_dark_oak_log
setblock 551 200 364 minecraft:light_gray_terracotta
fill 553 200 323 554 200 323 minecraft:stripped_dark_oak_log
fill 554 200 363 555 200 363 minecraft:stripped_dark_oak_log
fill 556 200 323 558 200 323 minecraft:stripped_dark_oak_log
fill 557 200 363 558 200 363 minecraft:stripped_dark_oak_log
fill 558 200 325 558 200 326 minecraft:stripped_dark_oak_log
fill 558 200 328 558 200 330 minecraft:stripped_dark_oak_log
fill 558 200 332 558 200 333 minecraft:stripped_dark_oak_log
fill 558 200 335 558 200 337 minecraft:stripped_dark_oak_log
fill 558 200 339 558 200 340 minecraft:stripped_dark_oak_log
fill 558 200 342 558 200 344 minecraft:stripped_dark_oak_log
fill 558 200 346 558 200 347 minecraft:stripped_dark_oak_log
fill 558 200 349 558 200 351 minecraft:stripped_dark_oak_log
fill 558 200 353 558 200 354 minecraft:stripped_dark_oak_log
fill 558 200 356 558 200 358 minecraft:stripped_dark_oak_log
fill 558 200 360 558 200 361 minecraft:stripped_dark_oak_log
setblock 558 200 364 minecraft:light_gray_terracotta
setblock 559 200 329 minecraft:light_gray_terracotta
setblock 559 200 348 minecraft:light_gray_terracotta
setblock 559 200 351 minecraft:light_gray_terracotta
fill 517 201 322 517 307 322 minecraft:white_terracotta
setblock 517 201 323 minecraft:light_gray_terracotta
fill 517 201 324 517 201 358 minecraft:white_terracotta
setblock 517 201 359 minecraft:light_gray_terracotta
fill 517 201 360 517 201 364 minecraft:white_terracotta
setblock 518 201 326 minecraft:stripped_dark_oak_log
setblock 518 201 333 minecraft:stripped_dark_oak_log
setblock 518 201 340 minecraft:stripped_dark_oak_log
setblock 518 201 347 minecraft:stripped_dark_oak_log
setblock 518 201 354 minecraft:stripped_dark_oak_log
setblock 518 201 361 minecraft:stripped_dark_oak_log
fill 518 201 364 518 307 364 minecraft:white_terracotta
fill 519 201 322 519 307 322 minecraft:white_terracotta
fill 519 201 364 520 201 364 minecraft:light_gray_terracotta
fill 521 201 322 526 201 322 minecraft:white_terracotta
fill 521 201 364 522 201 364 minecraft:white_terracotta
setblock 522 201 323 minecraft:stripped_dark_oak_log
setblock 523 201 363 minecraft:stripped_dark_oak_log
setblock 523 201 364 minecraft:light_gray_terracotta
fill 524 201 364 524 307 364 minecraft:white_terracotta
setblock 525 201 364 minecraft:light_gray_terracotta
fill 526 201 364 527 202 364 minecraft:white_terracotta
setblock 527 201 322 minecraft:light_gray_terracotta
fill 528 201 322 534 202 322 minecraft:white_terracotta
setblock 528 201 364 minecraft:light_gray_terracotta
setblock 529 201 323 minecraft:stripped_dark_oak_log
fill 529 201 364 529 307 364 minecraft:white_terracotta
setblock 530 201 363 minecraft:stripped_dark_oak_log
setblock 530 201 364 minecraft:light_gray_terracotta
fill 531 201 364 536 201 364 minecraft:white_terracotta
fill 536 201 322 549 201 322 minecraft:white_terracotta
setblock 536 201 323 minecraft:stripped_dark_oak_log
setblock 537 201 363 minecraft:stripped_dark_oak_log
fill 538 201 364 540 201 364 minecraft:white_terracotta
fill 542 201 364 546 307 364 minecraft:white_terracotta
setblock 543 201 323 minecraft:stripped_dark_oak_log
setblock 544 201 363 minecraft:stripped_dark_oak_log
fill 547 201 364 549 201 364 minecraft:light_gray_terracotta
setblock 550 201 323 minecraft:stripped_dark_oak_log
fill 550 201 364 552 307 364 minecraft:white_terracotta
fill 551 201 322 552 307 322 minecraft:white_terracotta
setblock 551 201 363 minecraft:stripped_dark_oak_log
setblock 553 201 364 minecraft:light_gray_terracotta
fill 554 201 322 559 202 322 minecraft:white_terracotta
fill 554 201 364 555 201 364 minecraft:white_terracotta
setblock 556 201 364 minecraft:light_gray_terracotta
setblock 557 201 323 minecraft:stripped_dark_oak_log
fill 557 201 364 558 307 364 minecraft:white_terracotta
setblock 558 201 329 minecraft:stripped_dark_oak_log
setblock 558 201 336 minecraft:stripped_dark_oak_log
setblock 558 201 343 minecraft:stripped_dark_oak_log
setblock 558 201 350 minecraft:stripped_dark_oak_log
setblock 558 201 357 minecraft:stripped_dark_oak_log
setblock 558 201 363 minecraft:stripped_dark_oak_log
fill 559 201 323 559 307 337 minecraft:white_terracotta
setblock 559 201 338 minecraft:light_gray_terracotta
fill 559 201 339 559 201 353 minecraft:white_terracotta
fill 559 201 355 559 201 363 minecraft:white_terracotta
setblock 559 201 364 minecraft:light_gray_terracotta
fill 517 202 323 517 285 325 minecraft:white_terracotta
setblock 517 202 326 minecraft:light_gray_terracotta
fill 517 202 327 517 202 339 minecraft:white_terracotta
setblock 517 202 340 minecraft:light_gray_terracotta
fill 517 202 341 517 307 350 minecraft:white_terracotta
fill 517 202 351 517 202 352 minecraft:light_gray_terracotta
fill 517 202 353 517 202 360 minecraft:white_terracotta
setblock 517 202 361 minecraft:light_gray_terracotta
fill 517 202 362 517 307 364 minecraft:white_terracotta
fill 518 202 322 518 307 322 minecraft:white_terracotta
setblock 518 202 327 minecraft:stripped_dark_oak_log
setblock 518 202 334 minecraft:stripped_dark_oak_log
setblock 518 202 341 minecraft:stripped_dark_oak_log
setblock 518 202 348 minecraft:stripped_dark_oak_log
setblock 518 202 355 minecraft:stripped_dark_oak_log
setblock 518 202 362 minecraft:stripped_dark_oak_log
fill 519 202 364 520 307 364 minecraft:white_terracotta
fill 520 202 322 525 202 322 minecraft:white_terracotta
setblock 521 202 323 minecraft:stripped_dark_oak_log
fill 521 202 364 521 203 364 minecraft:light_gray_terracotta
fill 522 202 364 523 202 364 minecraft:white_terracotta
setblock 524 202 363 minecraft:stripped_dark_oak_log
fill 525 202 364 525 307 364 minecraft:white_terracotta
setblock 526 202 322 minecraft:light_gray_terracotta
fill 527 202 322 527 307 322 minecraft:white_terracotta
setblock 528 202 323 minecraft:stripped_dark_oak_log
fill 528 202 364 528 307 364 minecraft:white_terracotta
fill 530 202 364 531 202 364 minecraft:white_terracotta
setblock 531 202 363 minecraft:stripped_dark_oak_log
setblock 532 202 364 minecraft:light_gray_terracotta
fill 533 202 364 539 307 364 minecraft:white_terracotta
fill 535 202 322 536 307 322 minecraft:white_terracotta
setblock 535 202 323 minecraft:stripped_dark_oak_log
fill 537 202 322 538 202 322 minecraft:light_gray_terracotta
setblock 538 202 363 minecraft:stripped_dark_oak_log
setblock 539 202 322 minecraft:white_terracotta
setblock 540 202 322 minecraft:light_gray_terracotta
setblock 540 202 364 minecraft:light_gray_terracotta
fill 541 202 322 550 202 322 minecraft:white_terracotta
fill 541 202 364 541 307 364 minecraft:white_terracotta
setblock 542 202 323 minecraft:stripped_dark_oak_log
setblock 545 202 363 minecraft:stripped_dark_oak_log
fill 547 202 364 549 307 364 minecraft:white_terracotta
setblock 549 202 323 minecraft:stripped_dark_oak_log
setblock 552 202 363 minecraft:stripped_dark_oak_log
fill 553 202 322 553 307 322 minecraft:white_terracotta
fill 553 202 364 554 202 364 minecraft:white_terracotta
setblock 555 202 364 minecraft:light_gray_terracotta
setblock 556 202 323 minecraft:stripped_dark_oak_log
fill 556 202 364 556 307 364 minecraft:white_terracotta
setblock 558 202 328 minecraft:stripped_dark_oak_log
setblock 558 202 335 minecraft:stripped_dark_oak_log
setblock 558 202 342 minecraft:stripped_dark_oak_log
setblock 558 202 349 minecraft:stripped_dark_oak_log
setblock 558 202 356 minecraft:stripped_dark_oak_log
fill 559 202 338 559 307 341 minecraft:white_terracotta
setblock 559 202 342 minecraft:light_gray_terracotta
fill 559 202 343 559 202 349 minecraft:white_terracotta
setblock 559 202 350 minecraft:light_gray_terracotta
fill 559 202 351 559 202 358 minecraft:white_terracotta
setblock 559 202 359 minecraft:light_gray_terracotta
fill 559 202 360 559 307 364 minecraft:white_terracotta
fill 517 203 326 517 285 328 minecraft:white_terracotta
setblock 517 203 329 minecraft:light_gray_terracotta
fill 517 203 330 517 307 334 minecraft:white_terracotta
setblock 517 203 335 minecraft:light_gray_terracotta
fill 517 203 336 517 307 340 minecraft:white_terracotta
fill 517 203 351 517 307 358 minecraft:white_terracotta
setblock 517 203 359 minecraft:light_gray_terracotta
fill 517 203 360 517 307 361 minecraft:white_terracotta
fill 520 203 322 520 307 322 minecraft:white_terracotta
setblock 521 203 322 minecraft:light_gray_terracotta
fill 522 203 322 526 307 322 minecraft:white_terracotta
fill 522 203 364 522 307 364 minecraft:white_terracotta
setblock 523 203 364 minecraft:light_gray_terracotta
fill 526 203 364 526 307 364 minecraft:white_terracotta
setblock 527 203 364 minecraft:light_gray_terracotta
fill 528 203 322 529 307 322 minecraft:white_terracotta
setblock 530 203 322 minecraft:light_gray_terracotta
fill 530 203 364 530 307 364 minecraft:white_terracotta
fill 531 203 322 534 307 322 minecraft:white_terracotta
setblock 531 203 364 minecraft:light_gray_terracotta
fill 532 203 364 532 307 364 minecraft:white_terracotta
fill 537 203 322 538 307 322 minecraft:white_terracotta
setblock 539 203 322 minecraft:light_gray_terracotta
fill 540 203 322 540 307 322 minecraft:white_terracotta
fill 540 203 364 540 307 364 minecraft:white_terracotta
setblock 541 203 322 minecraft:light_gray_terracotta
fill 542 203 322 550 307 322 minecraft:white_terracotta
fill 553 203 364 553 307 364 minecraft:white_terracotta
fill 554 203 322 556 307 322 minecraft:white_terracotta
setblock 554 203 364 minecraft:light_gray_terracotta
fill 555 203 364 555 307 364 minecraft:white_terracotta
setblock 557 203 322 minecraft:light_gray_terracotta
fill 558 203 322 558 307 322 minecraft:white_terracotta
setblock 559 203 322 minecraft:light_gray_terracotta
fill 559 203 342 559 307 344 minecraft:white_terracotta
setblock 559 203 345 minecraft:light_gray_terracotta
fill 559 203 346 559 307 351 minecraft:white_terracotta
setblock 559 203 352 minecraft:light_gray_terracotta
fill 559 203 353 559 307 359 minecraft:white_terracotta
fill 517 204 329 517 307 329 minecraft:white_terracotta
fill 517 204 335 517 307 335 minecraft:white_terracotta
fill 517 204 359 517 307 359 minecraft:white_terracotta
setblock 518 204 329 minecraft:stripped_dark_oak_log
setblock 518 204 336 minecraft:stripped_dark_oak_log
setblock 518 204 343 minecraft:stripped_dark_oak_log
setblock 518 204 350 minecraft:stripped_dark_oak_log
setblock 518 204 357 minecraft:stripped_dark_oak_log
setblock 519 204 323 minecraft:stripped_dark_oak_log
setblock 519 204 363 minecraft:stripped_dark_oak_log
setblock 520 204 325 minecraft:light[level=14]
setblock 520 204 333 minecraft:light[level=14]
setblock 520 204 341 minecraft:light[level=14]
setblock 520 204 349 minecraft:light[level=14]
setblock 520 204 357 minecraft:light[level=14]
fill 521 204 322 521 307 322 minecraft:white_terracotta
fill 521 204 364 521 307 364 minecraft:white_terracotta
fill 523 204 364 523 307 364 minecraft:white_terracotta
setblock 526 204 323 minecraft:stripped_dark_oak_log
setblock 526 204 363 minecraft:stripped_dark_oak_log
fill 527 204 364 527 307 364 minecraft:white_terracotta
setblock 528 204 325 minecraft:light[level=14]
setblock 528 204 333 minecraft:light[level=14]
setblock 528 204 341 minecraft:light[level=14]
setblock 528 204 349 minecraft:light[level=14]
setblock 528 204 357 minecraft:light[level=14]
fill 530 204 322 530 307 322 minecraft:white_terracotta
fill 531 204 364 531 307 364 minecraft:white_terracotta
setblock 533 204 323 minecraft:stripped_dark_oak_log
setblock 533 204 363 minecraft:stripped_dark_oak_log
setblock 536 204 325 minecraft:light[level=14]
setblock 536 204 333 minecraft:light[level=14]
setblock 536 204 341 minecraft:light[level=14]
setblock 536 204 349 minecraft:light[level=14]
setblock 536 204 357 minecraft:light[level=14]
fill 539 204 322 539 307 322 minecraft:white_terracotta
setblock 540 204 323 minecraft:stripped_dark_oak_log
setblock 540 204 363 minecraft:stripped_dark_oak_log
fill 541 204 322 541 307 322 minecraft:white_terracotta
setblock 544 204 325 minecraft:light[level=14]
setblock 544 204 333 minecraft:light[level=14]
setblock 544 204 341 minecraft:light[level=14]
setblock 544 204 349 minecraft:light[level=14]
setblock 544 204 357 minecraft:light[level=14]
setblock 547 204 323 minecraft:stripped_dark_oak_log
setblock 547 204 363 minecraft:stripped_dark_oak_log
fill 548 204 333 549 205 333 minecraft:cherry_leaves[persistent=true]
setblock 552 204 325 minecraft:light[level=14]
setblock 552 204 333 minecraft:light[level=14]
setblock 552 204 341 minecraft:light[level=14]
setblock 552 204 349 minecraft:light[level=14]
setblock 552 204 357 minecraft:light[level=14]
setblock 554 204 323 minecraft:stripped_dark_oak_log
setblock 554 204 363 minecraft:stripped_dark_oak_log
fill 554 204 364 554 307 364 minecraft:white_terracotta
fill 557 204 322 557 307 322 minecraft:white_terracotta
setblock 558 204 326 minecraft:stripped_dark_oak_log
setblock 558 204 333 minecraft:stripped_dark_oak_log
setblock 558 204 340 minecraft:stripped_dark_oak_log
setblock 558 204 347 minecraft:stripped_dark_oak_log
setblock 558 204 354 minecraft:stripped_dark_oak_log
setblock 558 204 361 minecraft:stripped_dark_oak_log
fill 559 204 322 559 307 322 minecraft:white_terracotta
fill 559 204 345 559 307 345 minecraft:white_terracotta
fill 559 204 352 559 307 352 minecraft:white_terracotta
setblock 518 205 323 minecraft:stripped_dark_oak_log
setblock 518 205 330 minecraft:stripped_dark_oak_log
setblock 518 205 337 minecraft:stripped_dark_oak_log
setblock 518 205 344 minecraft:stripped_dark_oak_log
setblock 518 205 351 minecraft:stripped_dark_oak_log
setblock 518 205 358 minecraft:stripped_dark_oak_log
setblock 520 205 363 minecraft:stripped_dark_oak_log
setblock 525 205 323 minecraft:stripped_dark_oak_log
setblock 527 205 363 minecraft:stripped_dark_oak_log
setblock 532 205 323 minecraft:stripped_dark_oak_log
setblock 534 205 363 minecraft:stripped_dark_oak_log
setblock 539 205 323 minecraft:stripped_dark_oak_log
setblock 541 205 363 minecraft:stripped_dark_oak_log
setblock 546 205 323 minecraft:stripped_dark_oak_log
setblock 548 205 363 minecraft:stripped_dark_oak_log
setblock 553 205 323 minecraft:stripped_dark_oak_log
setblock 555 205 363 minecraft:stripped_dark_oak_log
setblock 558 205 325 minecraft:stripped_dark_oak_log
setblock 558 205 332 minecraft:stripped_dark_oak_log
setblock 558 205 339 minecraft:stripped_dark_oak_log
setblock 558 205 346 minecraft:stripped_dark_oak_log
setblock 558 205 353 minecraft:stripped_dark_oak_log
setblock 558 205 360 minecraft:stripped_dark_oak_log
setblock 518 206 324 minecraft:stripped_dark_oak_log
setblock 518 206 331 minecraft:stripped_dark_oak_log
setblock 518 206 338 minecraft:stripped_dark_oak_log
setblock 518 206 345 minecraft:stripped_dark_oak_log
setblock 518 206 352 minecraft:stripped_dark_oak_log
setblock 518 206 359 minecraft:stripped_dark_oak_log
setblock 521 206 363 minecraft:stripped_dark_oak_log
setblock 524 206 323 minecraft:stripped_dark_oak_log
setblock 528 206 363 minecraft:stripped_dark_oak_log
setblock 531 206 323 minecraft:stripped_dark_oak_log
setblock 535 206 363 minecraft:stripped_dark_oak_log
setblock 538 206 323 minecraft:stripped_dark_oak_log
setblock 542 206 363 minecraft:stripped_dark_oak_log
setblock 545 206 323 minecraft:stripped_dark_oak_log
setblock 549 206 363 minecraft:stripped_dark_oak_log
setblock 552 206 323 minecraft:stripped_dark_oak_log
setblock 556 206 363 minecraft:stripped_dark_oak_log
setblock 558 206 324 minecraft:stripped_dark_oak_log
setblock 558 206 331 minecraft:stripped_dark_oak_log
setblock 558 206 338 minecraft:stripped_dark_oak_log
setblock 558 206 345 minecraft:stripped_dark_oak_log
setblock 558 206 352 minecraft:stripped_dark_oak_log
setblock 558 206 359 minecraft:stripped_dark_oak_log
setblock 518 207 325 minecraft:stripped_dark_oak_log
setblock 518 207 332 minecraft:stripped_dark_oak_log
setblock 518 207 339 minecraft:stripped_dark_oak_log
setblock 518 207 346 minecraft:stripped_dark_oak_log
setblock 518 207 353 minecraft:stripped_dark_oak_log
setblock 518 207 360 minecraft:stripped_dark_oak_log
setblock 522 207 363 minecraft:stripped_dark_oak_log
setblock 523 207 323 minecraft:stripped_dark_oak_log
setblock 529 207 363 minecraft:stripped_dark_oak_log
setblock 530 207 323 minecraft:stripped_dark_oak_log
setblock 536 207 363 minecraft:stripped_dark_oak_log
setblock 537 207 323 minecraft:stripped_dark_oak_log
setblock 543 207 363 minecraft:stripped_dark_oak_log
setblock 544 207 323 minecraft:stripped_dark_oak_log
setblock 550 207 363 minecraft:stripped_dark_oak_log
setblock 551 207 323 minecraft:stripped_dark_oak_log
setblock 557 207 363 minecraft:stripped_dark_oak_log
setblock 558 207 323 minecraft:stripped_dark_oak_log
setblock 558 207 330 minecraft:stripped_dark_oak_log
setblock 558 207 337 minecraft:stripped_dark_oak_log
setblock 558 207 344 minecraft:stripped_dark_oak_log
setblock 558 207 351 minecraft:stripped_dark_oak_log
setblock 558 207 358 minecraft:stripped_dark_oak_log
setblock 518 208 326 minecraft:stripped_dark_oak_log
setblock 518 208 333 minecraft:stripped_dark_oak_log
setblock 518 208 340 minecraft:stripped_dark_oak_log
setblock 518 208 347 minecraft:stripped_dark_oak_log
setblock 518 208 354 minecraft:stripped_dark_oak_log
setblock 518 208 361 minecraft:stripped_dark_oak_log
setblock 522 208 323 minecraft:stripped_dark_oak_log
setblock 523 208 363 minecraft:stripped_dark_oak_log
setblock 529 208 323 minecraft:stripped_dark_oak_log
setblock 530 208 363 minecraft:stripped_dark_oak_log
setblock 536 208 323 minecraft:stripped_dark_oak_log
setblock 537 208 363 minecraft:stripped_dark_oak_log
setblock 543 208 323 minecraft:stripped_dark_oak_log
setblock 544 208 363 minecraft:stripped_dark_oak_log
setblock 550 208 323 minecraft:stripped_dark_oak_log
setblock 551 208 363 minecraft:stripped_dark_oak_log
setblock 557 208 323 minecraft:stripped_dark_oak_log
setblock 558 208 329 minecraft:stripped_dark_oak_log
setblock 558 208 336 minecraft:stripped_dark_oak_log
setblock 558 208 343 minecraft:stripped_dark_oak_log
setblock 558 208 350 minecraft:stripped_dark_oak_log
setblock 558 208 357 minecraft:stripped_dark_oak_log
setblock 558 208 363 minecraft:stripped_dark_oak_log
fill 518 209 327 518 210 327 minecraft:stripped_dark_oak_log
fill 518 209 334 518 210 334 minecraft:stripped_dark_oak_log
fill 518 209 341 518 210 341 minecraft:stripped_dark_oak_log
fill 518 209 348 518 210 348 minecraft:stripped_dark_oak_log
fill 518 209 355 518 210 355 minecraft:stripped_dark_oak_log
fill 518 209 362 518 210 362 minecraft:stripped_dark_oak_log
fill 521 209 323 521 210 323 minecraft:stripped_dark_oak_log
fill 524 209 363 524 210 363 minecraft:stripped_dark_oak_log
fill 528 209 323 528 210 323 minecraft:stripped_dark_oak_log
fill 531 209 363 531 210 363 minecraft:stripped_dark_oak_log
fill 535 209 323 535 210 323 minecraft:stripped_dark_oak_log
fill 538 209 363 538 210 363 minecraft:stripped_dark_oak_log
fill 542 209 323 542 210 323 minecraft:stripped_dark_oak_log
fill 545 209 363 545 210 363 minecraft:stripped_dark_oak_log
fill 549 209 323 549 210 323 minecraft:stripped_dark_oak_log
fill 552 209 363 552 210 363 minecraft:stripped_dark_oak_log
fill 556 209 323 556 210 323 minecraft:stripped_dark_oak_log
fill 558 209 328 558 210 328 minecraft:stripped_dark_oak_log
fill 558 209 335 558 210 335 minecraft:stripped_dark_oak_log
fill 558 209 342 558 210 342 minecraft:stripped_dark_oak_log
fill 558 209 349 558 210 349 minecraft:stripped_dark_oak_log
fill 558 209 356 558 210 356 minecraft:stripped_dark_oak_log
fill 518 210 323 518 210 326 minecraft:stripped_dark_oak_log
fill 518 210 329 518 210 333 minecraft:stripped_dark_oak_log
fill 518 210 336 518 210 340 minecraft:stripped_dark_oak_log
fill 518 210 343 518 210 347 minecraft:stripped_dark_oak_log
fill 518 210 350 518 210 354 minecraft:stripped_dark_oak_log
fill 518 210 357 518 210 361 minecraft:stripped_dark_oak_log
fill 519 210 323 519 211 323 minecraft:stripped_dark_oak_log
fill 519 210 363 523 210 363 minecraft:stripped_dark_oak_log
fill 522 210 323 526 210 323 minecraft:stripped_dark_oak_log
fill 526 210 363 530 210 363 minecraft:stripped_dark_oak_log
fill 529 210 323 533 210 323 minecraft:stripped_dark_oak_log
fill 533 210 363 537 210 363 minecraft:stripped_dark_oak_log
fill 536 210 323 540 210 323 minecraft:stripped_dark_oak_log
fill 537 210 356 537 211 356 minecraft:cherry_leaves[persistent=true]
fill 540 210 363 544 210 363 minecraft:stripped_dark_oak_log
fill 543 210 323 547 210 323 minecraft:stripped_dark_oak_log
fill 547 210 363 551 210 363 minecraft:stripped_dark_oak_log
fill 550 210 323 554 210 323 minecraft:stripped_dark_oak_log
fill 554 210 363 558 210 363 minecraft:stripped_dark_oak_log
fill 557 210 323 558 210 323 minecraft:stripped_dark_oak_log
fill 558 210 324 558 210 326 minecraft:stripped_dark_oak_log
fill 558 210 329 558 210 333 minecraft:stripped_dark_oak_log
fill 558 210 336 558 210 340 minecraft:stripped_dark_oak_log
fill 558 210 343 558 210 347 minecraft:stripped_dark_oak_log
fill 558 210 350 558 210 354 minecraft:stripped_dark_oak_log
fill 558 210 357 558 210 361 minecraft:stripped_dark_oak_log
setblock 518 211 329 minecraft:stripped_dark_oak_log
setblock 518 211 336 minecraft:stripped_dark_oak_log
setblock 518 211 343 minecraft:stripped_dark_oak_log
setblock 518 211 350 minecraft:stripped_dark_oak_log
setblock 518 211 357 minecraft:stripped_dark_oak_log
setblock 519 211 363 minecraft:stripped_dark_oak_log
setblock 526 211 323 minecraft:stripped_dark_oak_log
setblock 526 211 363 minecraft:stripped_dark_oak_log
setblock 533 211 323 minecraft:stripped_dark_oak_log
setblock 533 211 363 minecraft:stripped_dark_oak_log
setblock 540 211 323 minecraft:stripped_dark_oak_log
setblock 540 211 363 minecraft:stripped_dark_oak_log
setblock 547 211 323 minecraft:stripped_dark_oak_log
setblock 547 211 363 minecraft:stripped_dark_oak_log
setblock 554 211 323 minecraft:stripped_dark_oak_log
setblock 554 211 363 minecraft:stripped_dark_oak_log
setblock 558 211 326 minecraft:stripped_dark_oak_log
setblock 558 211 333 minecraft:stripped_dark_oak_log
setblock 558 211 340 minecraft:stripped_dark_oak_log
setblock 558 211 347 minecraft:stripped_dark_oak_log
setblock 558 211 354 minecraft:stripped_dark_oak_log
setblock 558 211 361 minecraft:stripped_dark_oak_log
setblock 518 212 323 minecraft:stripped_dark_oak_log
setblock 518 212 330 minecraft:stripped_dark_oak_log
setblock 518 212 337 minecraft:stripped_dark_oak_log
setblock 518 212 344 minecraft:stripped_dark_oak_log
setblock 518 212 351 minecraft:stripped_dark_oak_log
setblock 518 212 358 minecraft:stripped_dark_oak_log
setblock 520 212 325 minecraft:light[level=14]
setblock 520 212 333 minecraft:light[level=14]
setblock 520 212 341 minecraft:light[level=14]
setblock 520 212 349 minecraft:light[level=14]
setblock 520 212 357 minecraft:light[level=14]
setblock 520 212 363 minecraft:stripped_dark_oak_log
setblock 525 212 323 minecraft:stripped_dark_oak_log
setblock 527 212 363 minecraft:stripped_dark_oak_log
setblock 528 212 325 minecraft:light[level=14]
setblock 528 212 333 minecraft:light[level=14]
setblock 528 212 341 minecraft:light[level=14]
setblock 528 212 349 minecraft:light[level=14]
setblock 528 212 357 minecraft:light[level=14]
setblock 532 212 323 minecraft:stripped_dark_oak_log
fill 532 212 355 533 213 355 minecraft:pink_wool
setblock 534 212 363 minecraft:stripped_dark_oak_log
setblock 536 212 325 minecraft:light[level=14]
setblock 536 212 333 minecraft:light[level=14]
setblock 536 212 341 minecraft:light[level=14]
setblock 536 212 349 minecraft:light[level=14]
setblock 536 212 357 minecraft:light[level=14]
setblock 539 212 323 minecraft:stripped_dark_oak_log
setblock 541 212 363 minecraft:stripped_dark_oak_log
setblock 544 212 325 minecraft:light[level=14]
setblock 544 212 333 minecraft:light[level=14]
setblock 544 212 341 minecraft:light[level=14]
setblock 544 212 349 minecraft:light[level=14]
setblock 544 212 357 minecraft:light[level=14]
setblock 546 212 323 minecraft:stripped_dark_oak_log
setblock 548 212 363 minecraft:stripped_dark_oak_log
setblock 552 212 325 minecraft:light[level=14]
setblock 552 212 333 minecraft:light[level=14]
setblock 552 212 341 minecraft:light[level=14]
setblock 552 212 349 minecraft:light[level=14]
setblock 552 212 357 minecraft:light[level=14]
setblock 553 212 323 minecraft:stripped_dark_oak_log
setblock 555 212 363 minecraft:stripped_dark_oak_log
setblock 558 212 325 minecraft:stripped_dark_oak_log
setblock 558 212 332 minecraft:stripped_dark_oak_log
setblock 558 212 339 minecraft:stripped_dark_oak_log
setblock 558 212 346 minecraft:stripped_dark_oak_log
setblock 558 212 353 minecraft:stripped_dark_oak_log
setblock 558 212 360 minecraft:stripped_dark_oak_log
setblock 518 213 324 minecraft:stripped_dark_oak_log
setblock 518 213 331 minecraft:stripped_dark_oak_log
setblock 518 213 338 minecraft:stripped_dark_oak_log
setblock 518 213 345 minecraft:stripped_dark_oak_log
setblock 518 213 352 minecraft:stripped_dark_oak_log
setblock 518 213 359 minecraft:stripped_dark_oak_log
setblock 521 213 363 minecraft:stripped_dark_oak_log
setblock 524 213 323 minecraft:stripped_dark_oak_log
setblock 528 213 363 minecraft:stripped_dark_oak_log
setblock 531 213 323 minecraft:stripped_dark_oak_log
setblock 535 213 363 minecraft:stripped_dark_oak_log
setblock 538 213 323 minecraft:stripped_dark_oak_log
setblock 542 213 363 minecraft:stripped_dark_oak_log
setblock 545 213 323 minecraft:stripped_dark_oak_log
setblock 549 213 363 minecraft:stripped_dark_oak_log
setblock 552 213 323 minecraft:stripped_dark_oak_log
setblock 556 213 363 minecraft:stripped_dark_oak_log
setblock 558 213 324 minecraft:stripped_dark_oak_log
setblock 558 213 331 minecraft:stripped_dark_oak_log
setblock 558 213 338 minecraft:stripped_dark_oak_log
setblock 558 213 345 minecraft:stripped_dark_oak_log
setblock 558 213 352 minecraft:stripped_dark_oak_log
setblock 558 213 359 minecraft:stripped_dark_oak_log
setblock 518 214 325 minecraft:stripped_dark_oak_log
setblock 518 214 332 minecraft:stripped_dark_oak_log
setblock 518 214 339 minecraft:stripped_dark_oak_log
setblock 518 214 346 minecraft:stripped_dark_oak_log
setblock 518 214 353 minecraft:stripped_dark_oak_log
setblock 518 214 360 minecraft:stripped_dark_oak_log
setblock 522 214 363 minecraft:stripped_dark_oak_log
setblock 523 214 323 minecraft:stripped_dark_oak_log
fill 524 214 357 524 217 357 minecraft:red_concrete
setblock 529 214 363 minecraft:stripped_dark_oak_log
setblock 530 214 323 minecraft:stripped_dark_oak_log
fill 532 214 357 532 217 357 minecraft:red_concrete
setblock 536 214 363 minecraft:stripped_dark_oak_log
setblock 537 214 323 minecraft:stripped_dark_oak_log
setblock 543 214 363 minecraft:stripped_dark_oak_log
setblock 544 214 323 minecraft:stripped_dark_oak_log
setblock 550 214 363 minecraft:stripped_dark_oak_log
setblock 551 214 323 minecraft:stripped_dark_oak_log
setblock 557 214 363 minecraft:stripped_dark_oak_log
setblock 558 214 323 minecraft:stripped_dark_oak_log
setblock 558 214 330 minecraft:stripped_dark_oak_log
setblock 558 214 337 minecraft:stripped_dark_oak_log
setblock 558 214 344 minecraft:stripped_dark_oak_log
setblock 558 214 351 minecraft:stripped_dark_oak_log
setblock 558 214 358 minecraft:stripped_dark_oak_log
setblock 518 215 326 minecraft:stripped_dark_oak_log
setblock 518 215 333 minecraft:stripped_dark_oak_log
setblock 518 215 340 minecraft:stripped_dark_oak_log
setblock 518 215 347 minecraft:stripped_dark_oak_log
setblock 518 215 354 minecraft:stripped_dark_oak_log
setblock 518 215 361 minecraft:stripped_dark_oak_log
setblock 522 215 323 minecraft:stripped_dark_oak_log
setblock 523 215 363 minecraft:stripped_dark_oak_log
setblock 529 215 323 minecraft:stripped_dark_oak_log
setblock 530 215 363 minecraft:stripped_dark_oak_log
setblock 536 215 323 minecraft:stripped_dark_oak_log
setblock 537 215 363 minecraft:stripped_dark_oak_log
setblock 543 215 323 minecraft:stripped_dark_oak_log
setblock 544 215 363 minecraft:stripped_dark_oak_log
setblock 550 215 323 minecraft:stripped_dark_oak_log
setblock 551 215 363 minecraft:stripped_dark_oak_log
setblock 557 215 323 minecraft:stripped_dark_oak_log
setblock 558 215 329 minecraft:stripped_dark_oak_log
setblock 558 215 336 minecraft:stripped_dark_oak_log
setblock 558 215 343 minecraft:stripped_dark_oak_log
setblock 558 215 350 minecraft:stripped_dark_oak_log
setblock 558 215 357 minecraft:stripped_dark_oak_log
setblock 558 215 363 minecraft:stripped_dark_oak_log
setblock 518 216 327 minecraft:stripped_dark_oak_log
setblock 518 216 334 minecraft:stripped_dark_oak_log
setblock 518 216 341 minecraft:stripped_dark_oak_log
setblock 518 216 348 minecraft:stripped_dark_oak_log
setblock 518 216 355 minecraft:stripped_dark_oak_log
setblock 518 216 362 minecraft:stripped_dark_oak_log
setblock 521 216 323 minecraft:stripped_dark_oak_log
setblock 524 216 363 minecraft:stripped_dark_oak_log
setblock 528 216 323 minecraft:stripped_dark_oak_log
setblock 531 216 363 minecraft:stripped_dark_oak_log
setblock 535 216 323 minecraft:stripped_dark_oak_log
setblock 538 216 363 minecraft:stripped_dark_oak_log
setblock 542 216 323 minecraft:stripped_dark_oak_log
setblock 545 216 363 minecraft:stripped_dark_oak_log
setblock 549 216 323 minecraft:stripped_dark_oak_log
setblock 552 216 363 minecraft:stripped_dark_oak_log
setblock 556 216 323 minecraft:stripped_dark_oak_log
setblock 558 216 328 minecraft:stripped_dark_oak_log
setblock 558 216 335 minecraft:stripped_dark_oak_log
setblock 558 216 342 minecraft:stripped_dark_oak_log
setblock 558 216 349 minecraft:stripped_dark_oak_log
setblock 558 216 356 minecraft:stripped_dark_oak_log
setblock 520 220 325 minecraft:light[level=14]
setblock 520 220 333 minecraft:light[level=14]
setblock 520 220 341 minecraft:light[level=14]
setblock 520 220 349 minecraft:light[level=14]
setblock 520 220 357 minecraft:light[level=14]
setblock 528 220 325 minecraft:light[level=14]
setblock 528 220 333 minecraft:light[level=14]
setblock 528 220 341 minecraft:light[level=14]
setblock 528 220 349 minecraft:light[level=14]
setblock 528 220 357 minecraft:light[level=14]
setblock 536 220 325 minecraft:light[level=14]
setblock 536 220 333 minecraft:light[level=14]
setblock 536 220 341 minecraft:light[level=14]
setblock 536 220 349 minecraft:light[level=14]
setblock 536 220 357 minecraft:light[level=14]
setblock 544 220 325 minecraft:light[level=14]
setblock 544 220 333 minecraft:light[level=14]
setblock 544 220 341 minecraft:light[level=14]
setblock 544 220 349 minecraft:light[level=14]
setblock 544 220 357 minecraft:light[level=14]
setblock 552 220 325 minecraft:light[level=14]
setblock 552 220 333 minecraft:light[level=14]
setblock 552 220 341 minecraft:light[level=14]
setblock 552 220 349 minecraft:light[level=14]
setblock 552 220 357 minecraft:light[level=14]
fill 518 223 323 521 223 325 minecraft:bamboo_planks
fill 518 223 326 521 223 329 minecraft:birch_planks
fill 518 223 330 521 223 333 minecraft:bamboo_planks
fill 518 223 334 521 223 337 minecraft:birch_planks
fill 518 223 338 521 223 341 minecraft:bamboo_planks
fill 518 223 342 521 223 345 minecraft:birch_planks
fill 518 223 346 521 223 349 minecraft:bamboo_planks
fill 518 223 350 521 223 353 minecraft:birch_planks
fill 518 223 354 521 223 357 minecraft:bamboo_planks
fill 518 223 358 521 223 361 minecraft:birch_planks
fill 518 223 362 521 223 363 minecraft:bamboo_planks
fill 522 223 323 525 223 325 minecraft:birch_planks
fill 522 223 326 525 223 329 minecraft:bamboo_planks
fill 522 223 330 525 223 333 minecraft:birch_planks
fill 522 223 334 525 223 337 minecraft:bamboo_planks
fill 522 223 338 525 223 341 minecraft:birch_planks
fill 522 223 342 525 223 345 minecraft:bamboo_planks
fill 522 223 346 525 223 349 minecraft:birch_planks
fill 522 223 350 525 223 353 minecraft:bamboo_planks
fill 522 223 354 525 223 357 minecraft:birch_planks
fill 522 223 358 525 223 361 minecraft:bamboo_planks
fill 522 223 362 525 223 363 minecraft:birch_planks
fill 526 223 323 529 223 325 minecraft:bamboo_planks
fill 526 223 326 529 223 329 minecraft:birch_planks
fill 526 223 330 529 223 333 minecraft:bamboo_planks
fill 526 223 334 529 223 337 minecraft:birch_planks
fill 526 223 338 529 223 341 minecraft:bamboo_planks
fill 526 223 342 529 223 345 minecraft:birch_planks
fill 526 223 346 529 223 349 minecraft:bamboo_planks
fill 526 223 350 529 223 353 minecraft:birch_planks
fill 526 223 354 529 223 357 minecraft:bamboo_planks
fill 526 223 358 529 223 361 minecraft:birch_planks
fill 526 223 362 529 223 363 minecraft:bamboo_planks
fill 530 223 323 533 223 325 minecraft:birch_planks
fill 530 223 326 533 223 329 minecraft:bamboo_planks
fill 530 223 330 533 223 333 minecraft:birch_planks
fill 530 223 334 533 223 337 minecraft:bamboo_planks
fill 530 223 338 531 223 341 minecraft:birch_planks
fill 530 223 342 531 223 345 minecraft:bamboo_planks
fill 530 223 346 533 223 349 minecraft:birch_planks
fill 530 223 350 533 223 353 minecraft:bamboo_planks
fill 530 223 354 533 223 357 minecraft:birch_planks
fill 530 223 358 533 223 361 minecraft:bamboo_planks
fill 530 223 362 533 223 363 minecraft:birch_planks
fill 532 223 338 532 223 340 minecraft:birch_planks
fill 532 223 344 532 223 345 minecraft:bamboo_planks
fill 533 223 338 533 223 339 minecraft:birch_planks
setblock 533 223 345 minecraft:bamboo_planks
fill 534 223 323 537 223 325 minecraft:bamboo_planks
fill 534 223 326 537 223 329 minecraft:birch_planks
fill 534 223 330 537 223 333 minecraft:bamboo_planks
fill 534 223 334 537 223 337 minecraft:birch_planks
fill 534 223 338 537 223 339 minecraft:bamboo_planks
fill 534 223 345 537 223 345 minecraft:birch_planks
fill 534 223 346 537 223 349 minecraft:bamboo_planks
fill 534 223 350 537 223 353 minecraft:birch_planks
fill 534 223 354 537 223 357 minecraft:bamboo_planks
fill 534 223 358 537 223 361 minecraft:birch_planks
fill 534 223 362 537 223 363 minecraft:bamboo_planks
fill 536 223 340 537 223 340 minecraft:bamboo_planks
fill 536 223 344 537 223 344 minecraft:birch_planks
setblock 537 223 341 minecraft:bamboo_planks
fill 537 223 342 537 223 343 minecraft:birch_planks
fill 538 223 323 541 223 325 minecraft:birch_planks
fill 538 223 326 541 223 329 minecraft:bamboo_planks
fill 538 223 330 541 223 333 minecraft:birch_planks
fill 538 223 334 541 223 337 minecraft:bamboo_planks
fill 538 223 338 541 223 341 minecraft:birch_planks
fill 538 223 342 541 223 345 minecraft:bamboo_planks
fill 538 223 346 541 223 349 minecraft:birch_planks
fill 538 223 350 541 223 353 minecraft:bamboo_planks
fill 538 223 354 541 223 357 minecraft:birch_planks
fill 538 223 358 541 223 361 minecraft:bamboo_planks
fill 538 223 362 541 223 363 minecraft:birch_planks
fill 542 223 323 545 223 325 minecraft:bamboo_planks
fill 542 223 326 545 223 329 minecraft:birch_planks
fill 542 223 330 545 223 333 minecraft:bamboo_planks
fill 542 223 334 545 223 337 minecraft:birch_planks
fill 542 223 338 545 223 341 minecraft:bamboo_planks
fill 542 223 342 545 223 345 minecraft:birch_planks
fill 542 223 346 545 223 349 minecraft:bamboo_planks
fill 542 223 350 545 223 353 minecraft:birch_planks
fill 542 223 354 545 223 357 minecraft:bamboo_planks
fill 542 223 358 545 223 361 minecraft:birch_planks
fill 542 223 362 545 223 363 minecraft:bamboo_planks
fill 546 223 323 549 223 325 minecraft:birch_planks
fill 546 223 326 549 223 329 minecraft:bamboo_planks
fill 546 223 330 549 223 333 minecraft:birch_planks
fill 546 223 334 549 223 337 minecraft:bamboo_planks
fill 546 223 338 549 223 341 minecraft:birch_planks
fill 546 223 342 549 223 345 minecraft:bamboo_planks
fill 546 223 346 549 223 349 minecraft:birch_planks
fill 546 223 350 549 223 353 minecraft:bamboo_planks
fill 546 223 354 549 223 357 minecraft:birch_planks
fill 546 223 358 549 223 361 minecraft:bamboo_planks
fill 546 223 362 549 223 363 minecraft:birch_planks
fill 550 223 323 553 223 325 minecraft:bamboo_planks
fill 550 223 326 553 223 329 minecraft:birch_planks
fill 550 223 330 553 223 333 minecraft:bamboo_planks
fill 550 223 334 553 223 337 minecraft:birch_planks
fill 550 223 338 553 223 341 minecraft:bamboo_planks
fill 550 223 342 553 223 345 minecraft:birch_planks
fill 550 223 346 553 223 349 minecraft:bamboo_planks
fill 550 223 350 553 223 353 minecraft:birch_planks
fill 550 223 354 553 223 357 minecraft:bamboo_planks
fill 550 223 358 553 223 361 minecraft:birch_planks
fill 550 223 362 553 223 363 minecraft:bamboo_planks
fill 554 223 323 557 223 325 minecraft:birch_planks
fill 554 223 326 557 223 329 minecraft:bamboo_planks
fill 554 223 330 557 223 333 minecraft:birch_planks
fill 554 223 334 557 223 337 minecraft:bamboo_planks
fill 554 223 338 557 223 341 minecraft:birch_planks
fill 554 223 342 557 223 345 minecraft:bamboo_planks
fill 554 223 346 557 223 349 minecraft:birch_planks
fill 554 223 350 557 223 353 minecraft:bamboo_planks
fill 554 223 354 557 223 357 minecraft:birch_planks
fill 554 223 358 557 223 361 minecraft:bamboo_planks
fill 554 223 362 557 223 363 minecraft:birch_planks
fill 558 223 323 558 223 325 minecraft:bamboo_planks
fill 558 223 326 558 223 329 minecraft:birch_planks
fill 558 223 330 558 223 333 minecraft:bamboo_planks
fill 558 223 334 558 223 337 minecraft:birch_planks
fill 558 223 338 558 223 341 minecraft:bamboo_planks
fill 558 223 342 558 223 345 minecraft:birch_planks
fill 558 223 346 558 223 349 minecraft:bamboo_planks
fill 558 223 350 558 223 353 minecraft:birch_planks
fill 558 223 354 558 223 357 minecraft:bamboo_planks
fill 558 223 358 558 223 361 minecraft:birch_planks
fill 558 223 362 558 223 363 minecraft:bamboo_planks
fill 518 224 323 518 224 363 minecraft:dark_oak_planks
fill 519 224 323 521 224 325 minecraft:bamboo_planks
fill 519 224 326 558 224 326 minecraft:dark_oak_planks
fill 519 224 327 521 224 329 minecraft:birch_planks
fill 519 224 330 558 224 330 minecraft:dark_oak_planks
fill 519 224 331 521 224 333 minecraft:bamboo_planks
fill 519 224 334 558 224 334 minecraft:dark_oak_planks
fill 519 224 335 521 224 337 minecraft:birch_planks
fill 519 224 338 558 224 338 minecraft:dark_oak_planks
fill 519 224 339 521 224 341 minecraft:bamboo_planks
fill 519 224 342 530 224 342 minecraft:dark_oak_planks
fill 519 224 343 521 224 345 minecraft:birch_planks
fill 519 224 346 558 224 346 minecraft:dark_oak_planks
fill 519 224 347 521 224 349 minecraft:bamboo_planks
fill 519 224 350 558 224 350 minecraft:dark_oak_planks
fill 519 224 351 521 224 353 minecraft:birch_planks
fill 519 224 354 558 224 354 minecraft:dark_oak_planks
fill 519 224 355 521 224 357 minecraft:bamboo_planks
fill 519 224 358 558 224 358 minecraft:dark_oak_planks
fill 519 224 359 521 224 361 minecraft:birch_planks
fill 519 224 362 558 224 362 minecraft:dark_oak_planks
fill 519 224 363 521 224 363 minecraft:bamboo_planks
fill 522 224 323 522 224 325 minecraft:dark_oak_planks
fill 522 224 327 522 224 329 minecraft:dark_oak_planks
fill 522 224 331 522 224 333 minecraft:dark_oak_planks
fill 522 224 335 522 224 337 minecraft:dark_oak_planks
fill 522 224 339 522 224 341 minecraft:dark_oak_planks
fill 522 224 343 522 224 345 minecraft:dark_oak_planks
fill 522 224 347 522 224 349 minecraft:dark_oak_planks
fill 522 224 351 522 224 353 minecraft:dark_oak_planks
fill 522 224 355 522 224 357 minecraft:dark_oak_planks
fill 522 224 359 522 224 361 minecraft:dark_oak_planks
setblock 522 224 363 minecraft:dark_oak_planks
fill 523 224 323 525 224 325 minecraft:birch_planks
fill 523 224 327 525 224 329 minecraft:bamboo_planks
fill 523 224 331 525 224 333 minecraft:birch_planks
fill 523 224 335 525 224 337 minecraft:bamboo_planks
fill 523 224 339 525 224 341 minecraft:birch_planks
fill 523 224 343 525 224 345 minecraft:bamboo_planks
fill 523 224 347 525 224 349 minecraft:birch_planks
fill 523 224 351 525 224 353 minecraft:bamboo_planks
fill 523 224 355 525 224 357 minecraft:birch_planks
fill 523 224 359 525 224 361 minecraft:bamboo_planks
fill 523 224 363 525 224 363 minecraft:birch_planks
fill 526 224 323 526 224 325 minecraft:dark_oak_planks
fill 526 224 327 526 224 329 minecraft:dark_oak_planks
fill 526 224 331 526 224 333 minecraft:dark_oak_planks
fill 526 224 335 526 224 337 minecraft:dark_oak_planks
fill 526 224 339 526 224 341 minecraft:dark_oak_planks
fill 526 224 343 526 224 345 minecraft:dark_oak_planks
fill 526 224 347 526 224 349 minecraft:dark_oak_planks
fill 526 224 351 526 224 353 minecraft:dark_oak_planks
fill 526 224 355 526 224 357 minecraft:dark_oak_planks
fill 526 224 359 526 224 361 minecraft:dark_oak_planks
setblock 526 224 363 minecraft:dark_oak_planks
fill 527 224 323 529 224 325 minecraft:bamboo_planks
fill 527 224 327 529 224 329 minecraft:birch_planks
fill 527 224 331 529 224 333 minecraft:bamboo_planks
fill 527 224 335 529 224 337 minecraft:birch_planks
fill 527 224 339 529 224 341 minecraft:bamboo_planks
fill 527 224 343 529 224 345 minecraft:birch_planks
fill 527 224 347 529 224 349 minecraft:bamboo_planks
fill 527 224 351 529 224 353 minecraft:birch_planks
fill 527 224 355 529 224 357 minecraft:bamboo_planks
fill 527 224 359 529 224 361 minecraft:birch_planks
fill 527 224 363 529 224 363 minecraft:bamboo_planks
fill 530 224 323 530 224 325 minecraft:dark_oak_planks
fill 530 224 327 530 224 329 minecraft:dark_oak_planks
fill 530 224 331 530 224 333 minecraft:dark_oak_planks
fill 530 224 335 530 224 337 minecraft:dark_oak_planks
fill 530 224 339 530 224 341 minecraft:dark_oak_planks
fill 530 224 343 530 224 345 minecraft:dark_oak_planks
fill 530 224 347 530 224 349 minecraft:dark_oak_planks
fill 530 224 351 530 224 353 minecraft:dark_oak_planks
fill 530 224 355 530 224 357 minecraft:dark_oak_planks
fill 530 224 359 530 224 361 minecraft:dark_oak_planks
setblock 530 224 363 minecraft:dark_oak_planks
fill 531 224 323 533 224 325 minecraft:birch_planks
fill 531 224 327 533 224 329 minecraft:bamboo_planks
fill 531 224 331 533 224 333 minecraft:birch_planks
fill 531 224 335 533 224 337 minecraft:bamboo_planks
setblock 531 224 339 minecraft:birch_planks
fill 531 224 340 531 224 344 minecraft:shroomlight
setblock 531 224 345 minecraft:bamboo_planks
fill 531 224 347 533 224 349 minecraft:birch_planks
fill 531 224 351 533 224 353 minecraft:bamboo_planks
fill 531 224 355 533 224 357 minecraft:birch_planks
fill 531 224 359 533 224 361 minecraft:bamboo_planks
fill 531 224 363 533 224 363 minecraft:birch_planks
fill 532 224 339 532 224 340 minecraft:shroomlight
fill 532 224 344 532 224 345 minecraft:shroomlight
fill 533 224 339 536 224 339 minecraft:shroomlight
fill 533 224 345 536 224 345 minecraft:shroomlight
fill 534 224 323 534 224 325 minecraft:dark_oak_planks
fill 534 224 327 534 224 329 minecraft:dark_oak_planks
fill 534 224 331 534 224 333 minecraft:dark_oak_planks
fill 534 224 335 534 224 337 minecraft:dark_oak_planks
fill 534 224 347 534 224 349 minecraft:dark_oak_planks
fill 534 224 351 534 224 353 minecraft:dark_oak_planks
fill 534 224 355 534 224 357 minecraft:dark_oak_planks
fill 534 224 359 534 224 361 minecraft:dark_oak_planks
setblock 534 224 363 minecraft:dark_oak_planks
fill 535 224 323 537 224 325 minecraft:bamboo_planks
fill 535 224 327 537 224 329 minecraft:birch_planks
fill 535 224 331 537 224 333 minecraft:bamboo_planks
fill 535 224 335 537 224 337 minecraft:birch_planks
fill 535 224 347 537 224 349 minecraft:bamboo_planks
fill 535 224 351 537 224 353 minecraft:birch_planks
fill 535 224 355 537 224 357 minecraft:bamboo_planks
fill 535 224 359 537 224 361 minecraft:birch_planks
fill 535 224 363 537 224 363 minecraft:bamboo_planks
fill 536 224 340 537 224 340 minecraft:shroomlight
fill 536 224 344 537 224 344 minecraft:shroomlight
setblock 537 224 339 minecraft:bamboo_planks
fill 537 224 341 537 224 343 minecraft:shroomlight
setblock 537 224 345 minecraft:birch_planks
fill 538 224 323 538 224 325 minecraft:dark_oak_planks
fill 538 224 327 538 224 329 minecraft:dark_oak_planks
fill 538 224 331 538 224 333 minecraft:dark_oak_planks
fill 538 224 335 538 224 337 minecraft:dark_oak_planks
fill 538 224 339 538 224 345 minecraft:dark_oak_planks
fill 538 224 347 538 224 349 minecraft:dark_oak_planks
fill 538 224 351 538 224 353 minecraft:dark_oak_planks
fill 538 224 355 538 224 357 minecraft:dark_oak_planks
fill 538 224 359 538 224 361 minecraft:dark_oak_planks
setblock 538 224 363 minecraft:dark_oak_planks
fill 539 224 323 541 224 325 minecraft:birch_planks
fill 539 224 327 541 224 329 minecraft:bamboo_planks
fill 539 224 331 541 224 333 minecraft:birch_planks
fill 539 224 335 541 224 337 minecraft:bamboo_planks
fill 539 224 339 541 224 341 minecraft:birch_planks
fill 539 224 342 558 224 342 minecraft:dark_oak_planks
fill 539 224 343 541 224 345 minecraft:bamboo_planks
fill 539 224 347 541 224 349 minecraft:birch_planks
fill 539 224 351 541 224 353 minecraft:bamboo_planks
fill 539 224 355 541 224 357 minecraft:birch_planks
fill 539 224 359 541 224 361 minecraft:bamboo_planks
fill 539 224 363 541 224 363 minecraft:birch_planks
fill 542 224 323 542 224 325 minecraft:dark_oak_planks
fill 542 224 327 542 224 329 minecraft:dark_oak_planks
fill 542 224 331 542 224 333 minecraft:dark_oak_planks
fill 542 224 335 542 224 337 minecraft:dark_oak_planks
fill 542 224 339 542 224 341 minecraft:dark_oak_planks
fill 542 224 343 542 224 345 minecraft:dark_oak_planks
fill 542 224 347 542 224 349 minecraft:dark_oak_planks
fill 542 224 351 542 224 353 minecraft:dark_oak_planks
fill 542 224 355 542 224 357 minecraft:dark_oak_planks
fill 542 224 359 542 224 361 minecraft:dark_oak_planks
setblock 542 224 363 minecraft:dark_oak_planks
fill 543 224 323 545 224 325 minecraft:bamboo_planks
fill 543 224 327 545 224 329 minecraft:birch_planks
fill 543 224 331 545 224 333 minecraft:bamboo_planks
fill 543 224 335 545 224 337 minecraft:birch_planks
fill 543 224 339 545 224 341 minecraft:bamboo_planks
fill 543 224 343 545 224 345 minecraft:birch_planks
fill 543 224 347 545 224 349 minecraft:bamboo_planks
fill 543 224 351 545 224 353 minecraft:birch_planks
fill 543 224 355 545 224 357 minecraft:bamboo_planks
fill 543 224 359 545 224 361 minecraft:birch_planks
fill 543 224 363 545 224 363 minecraft:bamboo_planks
fill 546 224 323 546 224 325 minecraft:dark_oak_planks
fill 546 224 327 546 224 329 minecraft:dark_oak_planks
fill 546 224 331 546 224 333 minecraft:dark_oak_planks
fill 546 224 335 546 224 337 minecraft:dark_oak_planks
fill 546 224 339 546 224 341 minecraft:dark_oak_planks
fill 546 224 343 546 224 345 minecraft:dark_oak_planks
fill 546 224 347 546 224 349 minecraft:dark_oak_planks
fill 546 224 351 546 224 353 minecraft:dark_oak_planks
fill 546 224 355 546 224 357 minecraft:dark_oak_planks
fill 546 224 359 546 224 361 minecraft:dark_oak_planks
setblock 546 224 363 minecraft:dark_oak_planks
fill 547 224 323 549 224 325 minecraft:birch_planks
fill 547 224 327 549 224 329 minecraft:bamboo_planks
fill 547 224 331 549 224 333 minecraft:birch_planks
fill 547 224 335 549 224 337 minecraft:bamboo_planks
fill 547 224 339 549 224 341 minecraft:birch_planks
fill 547 224 343 549 224 345 minecraft:bamboo_planks
fill 547 224 347 549 224 349 minecraft:birch_planks
fill 547 224 351 549 224 353 minecraft:bamboo_planks
fill 547 224 355 549 224 357 minecraft:birch_planks
fill 547 224 359 549 224 361 minecraft:bamboo_planks
fill 547 224 363 549 224 363 minecraft:birch_planks
fill 550 224 323 550 224 325 minecraft:dark_oak_planks
fill 550 224 327 550 224 329 minecraft:dark_oak_planks
fill 550 224 331 550 224 333 minecraft:dark_oak_planks
fill 550 224 335 550 224 337 minecraft:dark_oak_planks
fill 550 224 339 550 224 341 minecraft:dark_oak_planks
fill 550 224 343 550 224 345 minecraft:dark_oak_planks
fill 550 224 347 550 224 349 minecraft:dark_oak_planks
fill 550 224 351 550 224 353 minecraft:dark_oak_planks
fill 550 224 355 550 224 357 minecraft:dark_oak_planks
fill 550 224 359 550 224 361 minecraft:dark_oak_planks
setblock 550 224 363 minecraft:dark_oak_planks
fill 551 224 323 553 224 325 minecraft:bamboo_planks
fill 551 224 327 553 224 329 minecraft:birch_planks
fill 551 224 331 553 224 333 minecraft:bamboo_planks
fill 551 224 335 553 224 337 minecraft:birch_planks
fill 551 224 339 553 224 341 minecraft:bamboo_planks
fill 551 224 343 553 224 345 minecraft:birch_planks
fill 551 224 347 553 224 349 minecraft:bamboo_planks
fill 551 224 351 553 224 353 minecraft:birch_planks
fill 551 224 355 553 224 357 minecraft:bamboo_planks
fill 551 224 359 553 224 361 minecraft:birch_planks
fill 551 224 363 553 224 363 minecraft:bamboo_planks
fill 554 224 323 554 224 325 minecraft:dark_oak_planks
fill 554 224 327 554 224 329 minecraft:dark_oak_planks
fill 554 224 331 554 224 333 minecraft:dark_oak_planks
fill 554 224 335 554 224 337 minecraft:dark_oak_planks
fill 554 224 339 554 224 341 minecraft:dark_oak_planks
fill 554 224 343 554 224 345 minecraft:dark_oak_planks
fill 554 224 347 554 224 349 minecraft:dark_oak_planks
fill 554 224 351 554 224 353 minecraft:dark_oak_planks
fill 554 224 355 554 224 357 minecraft:dark_oak_planks
fill 554 224 359 554 224 361 minecraft:dark_oak_planks
setblock 554 224 363 minecraft:dark_oak_planks
fill 555 224 323 557 224 325 minecraft:birch_planks
fill 555 224 327 557 224 329 minecraft:bamboo_planks
fill 555 224 331 557 224 333 minecraft:birch_planks
fill 555 224 335 557 224 337 minecraft:bamboo_planks
fill 555 224 339 557 224 341 minecraft:birch_planks
fill 555 224 343 557 224 345 minecraft:bamboo_planks
fill 555 224 347 557 224 349 minecraft:birch_planks
fill 555 224 351 557 224 353 minecraft:bamboo_planks
fill 555 224 355 557 224 357 minecraft:birch_planks
fill 555 224 359 557 224 361 minecraft:bamboo_planks
fill 555 224 363 557 224 363 minecraft:birch_planks
fill 558 224 323 558 224 325 minecraft:dark_oak_planks
fill 558 224 327 558 224 329 minecraft:dark_oak_planks
fill 558 224 331 558 224 333 minecraft:dark_oak_planks
fill 558 224 335 558 224 337 minecraft:dark_oak_planks
fill 558 224 339 558 224 341 minecraft:dark_oak_planks
fill 558 224 343 558 224 345 minecraft:dark_oak_planks
fill 558 224 347 558 224 349 minecraft:dark_oak_planks
fill 558 224 351 558 224 353 minecraft:dark_oak_planks
fill 558 224 355 558 224 357 minecraft:dark_oak_planks
fill 558 224 359 558 224 361 minecraft:dark_oak_planks
setblock 558 224 363 minecraft:dark_oak_planks
setblock 518 228 325 minecraft:stripped_dark_oak_log
fill 518 228 328 518 270 328 minecraft:stripped_dark_oak_log
setblock 518 228 332 minecraft:stripped_dark_oak_log
fill 518 228 335 518 270 335 minecraft:stripped_dark_oak_log
setblock 518 228 339 minecraft:stripped_dark_oak_log
fill 518 228 342 518 270 342 minecraft:stripped_dark_oak_log
setblock 518 228 346 minecraft:stripped_dark_oak_log
fill 518 228 349 518 270 349 minecraft:stripped_dark_oak_log
setblock 518 228 353 minecraft:stripped_dark_oak_log
fill 518 228 356 518 270 356 minecraft:stripped_dark_oak_log
setblock 518 228 360 minecraft:stripped_dark_oak_log
fill 518 228 363 518 270 363 minecraft:stripped_dark_oak_log
fill 520 228 323 520 270 323 minecraft:stripped_dark_oak_log
setblock 520 228 325 minecraft:light[level=14]
setblock 520 228 333 minecraft:light[level=14]
setblock 520 228 341 minecraft:light[level=14]
setblock 520 228 349 minecraft:light[level=14]
setblock 520 228 357 minecraft:light[level=14]
setblock 522 228 363 minecraft:stripped_dark_oak_log
setblock 523 228 323 minecraft:stripped_dark_oak_log
fill 525 228 363 525 270 363 minecraft:stripped_dark_oak_log
fill 527 228 323 527 270 323 minecraft:stripped_dark_oak_log
setblock 528 228 325 minecraft:light[level=14]
setblock 528 228 333 minecraft:light[level=14]
setblock 528 228 341 minecraft:light[level=14]
setblock 528 228 349 minecraft:light[level=14]
setblock 528 228 357 minecraft:light[level=14]
setblock 529 228 363 minecraft:stripped_dark_oak_log
setblock 530 228 323 minecraft:stripped_dark_oak_log
fill 530 228 331 531 232 332 minecraft:dark_oak_planks
fill 532 228 363 532 270 363 minecraft:stripped_dark_oak_log
fill 534 228 323 534 270 323 minecraft:stripped_dark_oak_log
fill 534 228 357 540 228 363 minecraft:stripped_dark_oak_log
setblock 536 228 325 minecraft:light[level=14]
setblock 536 228 333 minecraft:light[level=14]
setblock 536 228 341 minecraft:light[level=14]
setblock 536 228 349 minecraft:light[level=14]
setblock 537 228 323 minecraft:stripped_dark_oak_log
fill 541 228 323 541 270 323 minecraft:stripped_dark_oak_log
setblock 543 228 363 minecraft:stripped_dark_oak_log
setblock 544 228 323 minecraft:stripped_dark_oak_log
setblock 544 228 325 minecraft:light[level=14]
setblock 544 228 333 minecraft:light[level=14]
setblock 544 228 341 minecraft:light[level=14]
setblock 544 228 349 minecraft:light[level=14]
setblock 544 228 357 minecraft:light[level=14]
fill 546 228 363 546 270 363 minecraft:stripped_dark_oak_log
fill 548 228 323 548 270 323 minecraft:stripped_dark_oak_log
setblock 550 228 363 minecraft:stripped_dark_oak_log
setblock 551 228 323 minecraft:stripped_dark_oak_log
setblock 552 228 325 minecraft:light[level=14]
setblock 552 228 333 minecraft:light[level=14]
setblock 552 228 341 minecraft:light[level=14]
setblock 552 228 349 minecraft:light[level=14]
setblock 552 228 357 minecraft:light[level=14]
fill 553 228 363 553 270 363 minecraft:stripped_dark_oak_log
fill 555 228 323 555 270 323 minecraft:stripped_dark_oak_log
setblock 557 228 363 minecraft:stripped_dark_oak_log
setblock 558 228 323 minecraft:stripped_dark_oak_log
fill 558 228 327 558 270 327 minecraft:stripped_dark_oak_log
setblock 558 228 330 minecraft:stripped_dark_oak_log
fill 558 228 334 558 270 334 minecraft:stripped_dark_oak_log
setblock 558 228 337 minecraft:stripped_dark_oak_log
fill 558 228 341 558 270 341 minecraft:stripped_dark_oak_log
setblock 558 228 344 minecraft:stripped_dark_oak_log
fill 558 228 348 558 270 348 minecraft:stripped_dark_oak_log
setblock 558 228 351 minecraft:stripped_dark_oak_log
fill 558 228 355 558 270 355 minecraft:stripped_dark_oak_log
setblock 558 228 358 minecraft:stripped_dark_oak_log
fill 558 228 362 558 270 362 minecraft:stripped_dark_oak_log
fill 518 229 326 518 230 326 minecraft:stripped_dark_oak_log
fill 518 229 333 518 230 333 minecraft:stripped_dark_oak_log
fill 518 229 340 518 230 340 minecraft:stripped_dark_oak_log
fill 518 229 347 518 230 347 minecraft:stripped_dark_oak_log
fill 518 229 354 518 230 354 minecraft:stripped_dark_oak_log
fill 518 229 361 518 230 361 minecraft:stripped_dark_oak_log
fill 522 229 323 522 230 323 minecraft:stripped_dark_oak_log
fill 523 229 363 523 230 363 minecraft:stripped_dark_oak_log
fill 529 229 323 529 230 323 minecraft:stripped_dark_oak_log
fill 529 229 331 529 232 332 minecraft:dark_oak_planks
fill 530 229 330 531 232 330 minecraft:dark_oak_planks
fill 530 229 333 531 232 333 minecraft:dark_oak_planks
fill 530 229 363 530 230 363 minecraft:stripped_dark_oak_log
fill 532 229 331 532 232 332 minecraft:dark_oak_planks
setblock 534 229 357 minecraft:shroomlight
fill 534 229 358 534 241 358 minecraft:stripped_dark_oak_log
setblock 534 229 359 minecraft:shroomlight
fill 534 229 360 534 241 360 minecraft:stripped_dark_oak_log
setblock 534 229 361 minecraft:shroomlight
fill 534 229 362 534 241 362 minecraft:stripped_dark_oak_log
setblock 534 229 363 minecraft:shroomlight
fill 535 229 357 535 241 357 minecraft:stripped_dark_oak_log
setblock 535 229 358 minecraft:shroomlight
fill 535 229 359 535 241 359 minecraft:stripped_dark_oak_log
setblock 535 229 360 minecraft:shroomlight
fill 535 229 361 535 241 361 minecraft:stripped_dark_oak_log
setblock 535 229 362 minecraft:shroomlight
fill 535 229 363 535 241 363 minecraft:stripped_dark_oak_log
fill 536 229 323 536 230 323 minecraft:stripped_dark_oak_log
setblock 536 229 357 minecraft:shroomlight
fill 536 229 358 536 241 358 minecraft:stripped_dark_oak_log
setblock 536 229 359 minecraft:shroomlight
fill 536 229 360 536 241 360 minecraft:stripped_dark_oak_log
setblock 536 229 361 minecraft:shroomlight
fill 536 229 362 536 241 362 minecraft:stripped_dark_oak_log
setblock 536 229 363 minecraft:shroomlight
fill 537 229 357 537 241 357 minecraft:stripped_dark_oak_log
setblock 537 229 358 minecraft:shroomlight
fill 537 229 359 537 241 359 minecraft:stripped_dark_oak_log
setblock 537 229 360 minecraft:shroomlight
fill 537 229 361 537 241 361 minecraft:stripped_dark_oak_log
setblock 537 229 362 minecraft:shroomlight
fill 537 229 363 537 241 363 minecraft:stripped_dark_oak_log
setblock 538 229 357 minecraft:shroomlight
fill 538 229 358 538 241 358 minecraft:stripped_dark_oak_log
setblock 538 229 359 minecraft:shroomlight
fill 538 229 360 538 241 360 minecraft:stripped_dark_oak_log
setblock 538 229 361 minecraft:shroomlight
fill 538 229 362 538 241 362 minecraft:stripped_dark_oak_log
setblock 538 229 363 minecraft:shroomlight
fill 539 229 357 539 241 357 minecraft:stripped_dark_oak_log
setblock 539 229 358 minecraft:shroomlight
fill 539 229 359 539 241 359 minecraft:stripped_dark_oak_log
setblock 539 229 360 minecraft:shroomlight
fill 539 229 361 539 241 361 minecraft:stripped_dark_oak_log
setblock 539 229 362 minecraft:shroomlight
fill 539 229 363 539 270 363 minecraft:stripped_dark_oak_log
setblock 540 229 357 minecraft:shroomlight
fill 540 229 358 540 241 358 minecraft:stripped_dark_oak_log
setblock 540 229 359 minecraft:shroomlight
fill 540 229 360 540 241 360 minecraft:stripped_dark_oak_log
setblock 540 229 361 minecraft:shroomlight
fill 540 229 362 540 241 362 minecraft:stripped_dark_oak_log
setblock 540 229 363 minecraft:shroomlight
fill 543 229 323 543 230 323 minecraft:stripped_dark_oak_log
fill 544 229 363 544 230 363 minecraft:stripped_dark_oak_log
fill 550 229 323 550 230 323 minecraft:stripped_dark_oak_log
fill 551 229 363 551 230 363 minecraft:stripped_dark_oak_log
fill 557 229 323 557 230 323 minecraft:stripped_dark_oak_log
fill 558 229 329 558 230 329 minecraft:stripped_dark_oak_log
fill 558 229 336 558 230 336 minecraft:stripped_dark_oak_log
fill 558 229 343 558 230 343 minecraft:stripped_dark_oak_log
fill 558 229 350 558 230 350 minecraft:stripped_dark_oak_log
fill 558 229 357 558 230 357 minecraft:stripped_dark_oak_log
fill 558 229 363 558 230 363 minecraft:stripped_dark_oak_log
fill 518 230 323 518 230 325 minecraft:stripped_dark_oak_log
setblock 518 230 327 minecraft:stripped_dark_oak_log
fill 518 230 329 518 230 332 minecraft:stripped_dark_oak_log
setblock 518 230 334 minecraft:stripped_dark_oak_log
fill 518 230 336 518 230 339 minecraft:stripped_dark_oak_log
setblock 518 230 341 minecraft:stripped_dark_oak_log
fill 518 230 343 518 230 346 minecraft:stripped_dark_oak_log
setblock 518 230 348 minecraft:stripped_dark_oak_log
fill 518 230 350 518 230 353 minecraft:stripped_dark_oak_log
setblock 518 230 355 minecraft:stripped_dark_oak_log
fill 518 230 357 518 230 360 minecraft:stripped_dark_oak_log
setblock 518 230 362 minecraft:stripped_dark_oak_log
setblock 519 230 323 minecraft:stripped_dark_oak_log
fill 519 230 363 522 230 363 minecraft:stripped_dark_oak_log
setblock 521 230 323 minecraft:stripped_dark_oak_log
fill 523 230 323 526 230 323 minecraft:stripped_dark_oak_log
setblock 524 230 363 minecraft:stripped_dark_oak_log
fill 526 230 363 529 230 363 minecraft:stripped_dark_oak_log
setblock 528 230 323 minecraft:stripped_dark_oak_log
fill 529 230 330 529 232 330 minecraft:dark_oak_planks
fill 529 230 333 529 232 333 minecraft:dark_oak_planks
fill 530 230 323 533 230 323 minecraft:stripped_dark_oak_log
setblock 531 230 363 minecraft:stripped_dark_oak_log
fill 532 230 330 532 232 330 minecraft:dark_oak_planks
fill 532 230 333 532 232 333 minecraft:dark_oak_planks
fill 533 230 363 534 230 363 minecraft:stripped_dark_oak_log
fill 534 230 357 534 231 357 minecraft:stripped_dark_oak_log
fill 534 230 359 534 231 359 minecraft:stripped_dark_oak_log
fill 534 230 361 534 231 361 minecraft:stripped_dark_oak_log
setblock 535 230 323 minecraft:stripped_dark_oak_log
fill 535 230 358 535 231 358 minecraft:stripped_dark_oak_log
fill 535 230 360 535 231 360 minecraft:stripped_dark_oak_log
fill 535 230 362 535 231 362 minecraft:stripped_dark_oak_log
fill 536 230 357 536 231 357 minecraft:stripped_dark_oak_log
fill 536 230 359 536 231 359 minecraft:stripped_dark_oak_log
fill 536 230 361 536 231 361 minecraft:stripped_dark_oak_log
fill 536 230 363 536 231 363 minecraft:stripped_dark_oak_log
fill 537 230 323 540 230 323 minecraft:stripped_dark_oak_log
fill 537 230 358 537 231 358 minecraft:stripped_dark_oak_log
fill 537 230 360 537 231 360 minecraft:stripped_dark_oak_log
fill 537 230 362 537 231 362 minecraft:stripped_dark_oak_log
fill 538 230 357 538 231 357 minecraft:stripped_dark_oak_log
fill 538 230 359 538 231 359 minecraft:stripped_dark_oak_log
fill 538 230 361 538 231 361 minecraft:stripped_dark_oak_log
fill 538 230 363 538 231 363 minecraft:stripped_dark_oak_log
fill 539 230 358 539 231 358 minecraft:stripped_dark_oak_log
fill 539 230 360 539 231 360 minecraft:stripped_dark_oak_log
fill 539 230 362 539 231 362 minecraft:stripped_dark_oak_log
fill 540 230 357 540 231 357 minecraft:stripped_dark_oak_log
fill 540 230 359 540 231 359 minecraft:stripped_dark_oak_log
fill 540 230 361 540 231 361 minecraft:stripped_dark_oak_log
fill 540 230 363 543 230 363 minecraft:stripped_dark_oak_log
setblock 542 230 323 minecraft:stripped_dark_oak_log
fill 544 230 323 547 230 323 minecraft:stripped_dark_oak_log
setblock 545 230 363 minecraft:stripped_dark_oak_log
fill 547 230 363 550 230 363 minecraft:stripped_dark_oak_log
setblock 549 230 323 minecraft:stripped_dark_oak_log
fill 551 230 323 554 230 323 minecraft:stripped_dark_oak_log
setblock 552 230 363 minecraft:stripped_dark_oak_log
fill 554 230 363 557 230 363 minecraft:stripped_dark_oak_log
setblock 556 230 323 minecraft:stripped_dark_oak_log
fill 558 230 323 558 230 326 minecraft:stripped_dark_oak_log
setblock 558 230 328 minecraft:stripped_dark_oak_log
fill 558 230 330 558 230 333 minecraft:stripped_dark_oak_log
setblock 558 230 335 minecraft:stripped_dark_oak_log
fill 558 230 337 558 230 340 minecraft:stripped_dark_oak_log
setblock 558 230 342 minecraft:stripped_dark_oak_log
fill 558 230 344 558 230 347 minecraft:stripped_dark_oak_log
setblock 558 230 349 minecraft:stripped_dark_oak_log
fill 558 230 351 558 230 354 minecraft:stripped_dark_oak_log
setblock 558 230 356 minecraft:stripped_dark_oak_log
fill 558 230 358 558 230 361 minecraft:stripped_dark_oak_log
fill 528 231 331 528 232 332 minecraft:dark_oak_planks
fill 530 231 329 531 232 329 minecraft:dark_oak_planks
fill 530 231 334 531 232 334 minecraft:dark_oak_planks
fill 533 231 331 533 232 332 minecraft:dark_oak_planks
setblock 534 231 363 minecraft:stripped_dark_oak_log
setblock 540 231 363 minecraft:stripped_dark_oak_log
setblock 518 232 329 minecraft:stripped_dark_oak_log
setblock 518 232 336 minecraft:stripped_dark_oak_log
setblock 518 232 343 minecraft:stripped_dark_oak_log
setblock 518 232 350 minecraft:stripped_dark_oak_log
setblock 518 232 357 minecraft:stripped_dark_oak_log
setblock 519 232 323 minecraft:stripped_dark_oak_log
setblock 519 232 363 minecraft:stripped_dark_oak_log
setblock 526 232 323 minecraft:stripped_dark_oak_log
setblock 526 232 363 minecraft:stripped_dark_oak_log
setblock 528 232 330 minecraft:dark_oak_planks
setblock 528 232 333 minecraft:dark_oak_planks
setblock 529 232 329 minecraft:dark_oak_planks
setblock 529 232 334 minecraft:dark_oak_planks
setblock 532 232 329 minecraft:dark_oak_planks
setblock 532 232 334 minecraft:dark_oak_planks
setblock 533 232 323 minecraft:stripped_dark_oak_log
setblock 533 232 330 minecraft:dark_oak_planks
setblock 533 232 333 minecraft:dark_oak_planks
setblock 533 232 363 minecraft:stripped_dark_oak_log
setblock 534 232 357 minecraft:shroomlight
setblock 534 232 359 minecraft:shroomlight
setblock 534 232 361 minecraft:shroomlight
setblock 534 232 363 minecraft:shroomlight
setblock 535 232 358 minecraft:shroomlight
setblock 535 232 360 minecraft:shroomlight
setblock 535 232 362 minecraft:shroomlight
setblock 536 232 357 minecraft:shroomlight
setblock 536 232 359 minecraft:shroomlight
setblock 536 232 361 minecraft:shroomlight
setblock 536 232 363 minecraft:shroomlight
setblock 537 232 358 minecraft:shroomlight
setblock 537 232 360 minecraft:shroomlight
setblock 537 232 362 minecraft:shroomlight
setblock 538 232 357 minecraft:shroomlight
setblock 538 232 359 minecraft:shroomlight
setblock 538 232 361 minecraft:shroomlight
setblock 538 232 363 minecraft:shroomlight
setblock 539 232 358 minecraft:shroomlight
setblock 539 232 360 minecraft:shroomlight
setblock 539 232 362 minecraft:shroomlight
setblock 540 232 323 minecraft:stripped_dark_oak_log
setblock 540 232 357 minecraft:shroomlight
setblock 540 232 359 minecraft:shroomlight
setblock 540 232 361 minecraft:shroomlight
setblock 540 232 363 minecraft:shroomlight
setblock 547 232 323 minecraft:stripped_dark_oak_log
setblock 547 232 363 minecraft:stripped_dark_oak_log
setblock 554 232 323 minecraft:stripped_dark_oak_log
setblock 554 232 363 minecraft:stripped_dark_oak_log
setblock 558 232 326 minecraft:stripped_dark_oak_log
setblock 558 232 333 minecraft:stripped_dark_oak_log
setblock 558 232 340 minecraft:stripped_dark_oak_log
setblock 558 232 347 minecraft:stripped_dark_oak_log
setblock 558 232 354 minecraft:stripped_dark_oak_log
setblock 558 232 361 minecraft:stripped_dark_oak_log
setblock 518 233 323 minecraft:stripped_dark_oak_log
setblock 518 233 330 minecraft:stripped_dark_oak_log
setblock 518 233 337 minecraft:stripped_dark_oak_log
setblock 518 233 344 minecraft:stripped_dark_oak_log
setblock 518 233 351 minecraft:stripped_dark_oak_log
setblock 518 233 358 minecraft:stripped_dark_oak_log
setblock 520 233 363 minecraft:stripped_dark_oak_log
setblock 525 233 323 minecraft:stripped_dark_oak_log
setblock 527 233 363 minecraft:stripped_dark_oak_log
setblock 532 233 323 minecraft:stripped_dark_oak_log
fill 534 233 357 534 234 357 minecraft:stripped_dark_oak_log
fill 534 233 359 534 234 359 minecraft:stripped_dark_oak_log
fill 534 233 361 534 234 361 minecraft:stripped_dark_oak_log
fill 534 233 363 534 234 363 minecraft:stripped_dark_oak_log
fill 535 233 358 535 234 358 minecraft:stripped_dark_oak_log
fill 535 233 360 535 234 360 minecraft:stripped_dark_oak_log
fill 535 233 362 535 234 362 minecraft:stripped_dark_oak_log
fill 536 233 357 536 234 357 minecraft:stripped_dark_oak_log
fill 536 233 359 536 234 359 minecraft:stripped_dark_oak_log
fill 536 233 361 536 234 361 minecraft:stripped_dark_oak_log
fill 536 233 363 536 234 363 minecraft:stripped_dark_oak_log
fill 537 233 358 537 234 358 minecraft:stripped_dark_oak_log
fill 537 233 360 537 234 360 minecraft:stripped_dark_oak_log
fill 537 233 362 537 234 362 minecraft:stripped_dark_oak_log
fill 538 233 357 538 234 357 minecraft:stripped_dark_oak_log
fill 538 233 359 538 234 359 minecraft:stripped_dark_oak_log
fill 538 233 361 538 234 361 minecraft:stripped_dark_oak_log
fill 538 233 363 538 234 363 minecraft:stripped_dark_oak_log
setblock 539 233 323 minecraft:stripped_dark_oak_log
fill 539 233 358 539 234 358 minecraft:stripped_dark_oak_log
fill 539 233 360 539 234 360 minecraft:stripped_dark_oak_log
fill 539 233 362 539 234 362 minecraft:stripped_dark_oak_log
fill 540 233 357 540 234 357 minecraft:stripped_dark_oak_log
fill 540 233 359 540 234 359 minecraft:stripped_dark_oak_log
fill 540 233 361 540 234 361 minecraft:stripped_dark_oak_log
fill 540 233 363 541 233 363 minecraft:stripped_dark_oak_log
setblock 546 233 323 minecraft:stripped_dark_oak_log
fill 548 233 333 548 234 333 minecraft:cherry_leaves[persistent=true]
setblock 548 233 363 minecraft:stripped_dark_oak_log
setblock 553 233 323 minecraft:stripped_dark_oak_log
setblock 555 233 363 minecraft:stripped_dark_oak_log
setblock 558 233 325 minecraft:stripped_dark_oak_log
setblock 558 233 332 minecraft:stripped_dark_oak_log
setblock 558 233 339 minecraft:stripped_dark_oak_log
setblock 558 233 346 minecraft:stripped_dark_oak_log
setblock 558 233 353 minecraft:stripped_dark_oak_log
setblock 558 233 360 minecraft:stripped_dark_oak_log
setblock 518 234 324 minecraft:stripped_dark_oak_log
setblock 518 234 331 minecraft:stripped_dark_oak_log
setblock 518 234 338 minecraft:stripped_dark_oak_log
setblock 518 234 345 minecraft:stripped_dark_oak_log
setblock 518 234 352 minecraft:stripped_dark_oak_log
setblock 518 234 359 minecraft:stripped_dark_oak_log
setblock 521 234 363 minecraft:stripped_dark_oak_log
setblock 524 234 323 minecraft:stripped_dark_oak_log
setblock 528 234 363 minecraft:stripped_dark_oak_log
setblock 531 234 323 minecraft:stripped_dark_oak_log
setblock 538 234 323 minecraft:stripped_dark_oak_log
setblock 540 234 363 minecraft:stripped_dark_oak_log
setblock 542 234 363 minecraft:stripped_dark_oak_log
setblock 545 234 323 minecraft:stripped_dark_oak_log
setblock 549 234 363 minecraft:stripped_dark_oak_log
setblock 552 234 323 minecraft:stripped_dark_oak_log
setblock 556 234 363 minecraft:stripped_dark_oak_log
setblock 558 234 324 minecraft:stripped_dark_oak_log
setblock 558 234 331 minecraft:stripped_dark_oak_log
setblock 558 234 338 minecraft:stripped_dark_oak_log
setblock 558 234 345 minecraft:stripped_dark_oak_log
setblock 558 234 352 minecraft:stripped_dark_oak_log
setblock 558 234 359 minecraft:stripped_dark_oak_log
setblock 518 235 325 minecraft:stripped_dark_oak_log
setblock 518 235 332 minecraft:stripped_dark_oak_log
setblock 518 235 339 minecraft:stripped_dark_oak_log
setblock 518 235 346 minecraft:stripped_dark_oak_log
setblock 518 235 353 minecraft:stripped_dark_oak_log
setblock 518 235 360 minecraft:stripped_dark_oak_log
setblock 522 235 363 minecraft:stripped_dark_oak_log
setblock 523 235 323 minecraft:stripped_dark_oak_log
fill 525 235 332 525 236 332 minecraft:shroomlight
setblock 529 235 363 minecraft:stripped_dark_oak_log
setblock 530 235 323 minecraft:stripped_dark_oak_log
setblock 534 235 357 minecraft:shroomlight
setblock 534 235 359 minecraft:shroomlight
setblock 534 235 361 minecraft:shroomlight
setblock 534 235 363 minecraft:shroomlight
setblock 535 235 358 minecraft:shroomlight
setblock 535 235 360 minecraft:shroomlight
setblock 535 235 362 minecraft:shroomlight
setblock 536 235 357 minecraft:shroomlight
setblock 536 235 359 minecraft:shroomlight
setblock 536 235 361 minecraft:shroomlight
setblock 536 235 363 minecraft:shroomlight
setblock 537 235 323 minecraft:stripped_dark_oak_log
setblock 537 235 358 minecraft:shroomlight
setblock 537 235 360 minecraft:shroomlight
setblock 537 235 362 minecraft:shroomlight
setblock 538 235 357 minecraft:shroomlight
setblock 538 235 359 minecraft:shroomlight
setblock 538 235 361 minecraft:shroomlight
setblock 538 235 363 minecraft:shroomlight
setblock 539 235 358 minecraft:shroomlight
setblock 539 235 360 minecraft:shroomlight
setblock 539 235 362 minecraft:shroomlight
setblock 540 235 357 minecraft:shroomlight
setblock 540 235 359 minecraft:shroomlight
setblock 540 235 361 minecraft:shroomlight
setblock 540 235 363 minecraft:shroomlight
setblock 543 235 363 minecraft:stripped_dark_oak_log
setblock 544 235 323 minecraft:stripped_dark_oak_log
setblock 550 235 363 minecraft:stripped_dark_oak_log
setblock 551 235 323 minecraft:stripped_dark_oak_log
setblock 557 235 363 minecraft:stripped_dark_oak_log
setblock 558 235 323 minecraft:stripped_dark_oak_log
setblock 558 235 330 minecraft:stripped_dark_oak_log
setblock 558 235 337 minecraft:stripped_dark_oak_log
setblock 558 235 344 minecraft:stripped_dark_oak_log
setblock 558 235 351 minecraft:stripped_dark_oak_log
setblock 558 235 358 minecraft:stripped_dark_oak_log
setblock 518 236 326 minecraft:stripped_dark_oak_log
setblock 518 236 333 minecraft:stripped_dark_oak_log
setblock 518 236 340 minecraft:stripped_dark_oak_log
setblock 518 236 347 minecraft:stripped_dark_oak_log
setblock 518 236 354 minecraft:stripped_dark_oak_log
setblock 518 236 361 minecraft:stripped_dark_oak_log
setblock 520 236 325 minecraft:light[level=14]
setblock 520 236 333 minecraft:light[level=14]
setblock 520 236 341 minecraft:light[level=14]
setblock 520 236 349 minecraft:light[level=14]
setblock 520 236 357 minecraft:light[level=14]
setblock 522 236 323 minecraft:stripped_dark_oak_log
setblock 523 236 363 minecraft:stripped_dark_oak_log
setblock 528 236 325 minecraft:light[level=14]
setblock 528 236 333 minecraft:light[level=14]
setblock 528 236 341 minecraft:light[level=14]
setblock 528 236 349 minecraft:light[level=14]
setblock 528 236 357 minecraft:light[level=14]
setblock 529 236 323 minecraft:stripped_dark_oak_log
fill 529 236 331 532 238 332 minecraft:cherry_leaves[persistent=true]
fill 530 236 330 531 238 330 minecraft:cherry_leaves[persistent=true]
fill 530 236 333 531 238 333 minecraft:cherry_leaves[persistent=true]
setblock 530 236 363 minecraft:stripped_dark_oak_log
fill 534 236 357 534 237 357 minecraft:stripped_dark_oak_log
fill 534 236 359 534 237 359 minecraft:stripped_dark_oak_log
fill 534 236 361 534 237 361 minecraft:stripped_dark_oak_log
fill 534 236 363 534 237 363 minecraft:stripped_dark_oak_log
fill 535 236 358 535 237 358 minecraft:stripped_dark_oak_log
fill 535 236 360 535 237 360 minecraft:stripped_dark_oak_log
fill 535 236 362 535 237 362 minecraft:stripped_dark_oak_log
setblock 536 236 323 minecraft:stripped_dark_oak_log
setblock 536 236 325 minecraft:light[level=14]
setblock 536 236 333 minecraft:light[level=14]
setblock 536 236 341 minecraft:light[level=14]
setblock 536 236 349 minecraft:light[level=14]
fill 536 236 357 536 237 357 minecraft:stripped_dark_oak_log
fill 536 236 359 536 237 359 minecraft:stripped_dark_oak_log
fill 536 236 361 536 237 361 minecraft:stripped_dark_oak_log
fill 536 236 363 536 237 363 minecraft:stripped_dark_oak_log
fill 537 236 358 537 237 358 minecraft:stripped_dark_oak_log
fill 537 236 360 537 237 360 minecraft:stripped_dark_oak_log
fill 537 236 362 537 237 362 minecraft:stripped_dark_oak_log
fill 538 236 357 538 237 357 minecraft:stripped_dark_oak_log
fill 538 236 359 538 237 359 minecraft:stripped_dark_oak_log
fill 538 236 361 538 237 361 minecraft:stripped_dark_oak_log
fill 538 236 363 538 237 363 minecraft:stripped_dark_oak_log
fill 539 236 358 539 237 358 minecraft:stripped_dark_oak_log
fill 539 236 360 539 237 360 minecraft:stripped_dark_oak_log
fill 539 236 362 539 237 362 minecraft:stripped_dark_oak_log
fill 540 236 357 540 237 357 minecraft:stripped_dark_oak_log
fill 540 236 359 540 237 359 minecraft:stripped_dark_oak_log
fill 540 236 361 540 237 361 minecraft:stripped_dark_oak_log
fill 540 236 363 540 237 363 minecraft:stripped_dark_oak_log
setblock 543 236 323 minecraft:stripped_dark_oak_log
setblock 544 236 325 minecraft:light[level=14]
setblock 544 236 333 minecraft:light[level=14]
setblock 544 236 341 minecraft:light[level=14]
setblock 544 236 349 minecraft:light[level=14]
setblock 544 236 357 minecraft:light[level=14]
setblock 544 236 363 minecraft:stripped_dark_oak_log
setblock 550 236 323 minecraft:stripped_dark_oak_log
setblock 551 236 363 minecraft:stripped_dark_oak_log
setblock 552 236 325 minecraft:light[level=14]
setblock 552 236 333 minecraft:light[level=14]
setblock 552 236 341 minecraft:light[level=14]
setblock 552 236 349 minecraft:light[level=14]
setblock 552 236 357 minecraft:light[level=14]
setblock 557 236 323 minecraft:stripped_dark_oak_log
setblock 558 236 329 minecraft:stripped_dark_oak_log
setblock 558 236 336 minecraft:stripped_dark_oak_log
setblock 558 236 343 minecraft:stripped_dark_oak_log
setblock 558 236 350 minecraft:stripped_dark_oak_log
setblock 558 236 357 minecraft:stripped_dark_oak_log
setblock 558 236 363 minecraft:stripped_dark_oak_log
setblock 518 237 327 minecraft:stripped_dark_oak_log
setblock 518 237 334 minecraft:stripped_dark_oak_log
setblock 518 237 341 minecraft:stripped_dark_oak_log
setblock 518 237 348 minecraft:stripped_dark_oak_log
setblock 518 237 355 minecraft:stripped_dark_oak_log
setblock 518 237 362 minecraft:stripped_dark_oak_log
setblock 521 237 323 minecraft:stripped_dark_oak_log
setblock 524 237 363 minecraft:stripped_dark_oak_log
fill 525 237 332 525 247 332 minecraft:dark_oak_planks
setblock 528 237 323 minecraft:stripped_dark_oak_log
setblock 529 237 330 minecraft:cherry_leaves[persistent=true]
setblock 529 237 333 minecraft:cherry_leaves[persistent=true]
setblock 531 237 363 minecraft:stripped_dark_oak_log
setblock 532 237 330 minecraft:cherry_leaves[persistent=true]
setblock 532 237 333 minecraft:cherry_leaves[persistent=true]
setblock 535 237 323 minecraft:stripped_dark_oak_log
setblock 542 237 323 minecraft:stripped_dark_oak_log
setblock 545 237 363 minecraft:stripped_dark_oak_log
setblock 549 237 323 minecraft:stripped_dark_oak_log
setblock 552 237 363 minecraft:stripped_dark_oak_log
setblock 556 237 323 minecraft:stripped_dark_oak_log
setblock 558 237 328 minecraft:stripped_dark_oak_log
setblock 558 237 335 minecraft:stripped_dark_oak_log
setblock 558 237 342 minecraft:stripped_dark_oak_log
setblock 558 237 349 minecraft:stripped_dark_oak_log
setblock 558 237 356 minecraft:stripped_dark_oak_log
fill 525 238 333 526 247 333 minecraft:dark_oak_planks
fill 526 238 332 526 247 332 minecraft:dark_oak_planks
setblock 534 238 357 minecraft:shroomlight
setblock 534 238 359 minecraft:shroomlight
setblock 534 238 361 minecraft:shroomlight
setblock 534 238 363 minecraft:shroomlight
setblock 535 238 358 minecraft:shroomlight
setblock 535 238 360 minecraft:shroomlight
setblock 535 238 362 minecraft:shroomlight
setblock 536 238 357 minecraft:shroomlight
setblock 536 238 359 minecraft:shroomlight
setblock 536 238 361 minecraft:shroomlight
setblock 536 238 363 minecraft:shroomlight
setblock 537 238 358 minecraft:shroomlight
setblock 537 238 360 minecraft:shroomlight
setblock 537 238 362 minecraft:shroomlight
setblock 538 238 357 minecraft:shroomlight
setblock 538 238 359 minecraft:shroomlight
setblock 538 238 361 minecraft:shroomlight
setblock 538 238 363 minecraft:shroomlight
setblock 539 238 358 minecraft:shroomlight
setblock 539 238 360 minecraft:shroomlight
setblock 539 238 362 minecraft:shroomlight
setblock 540 238 357 minecraft:shroomlight
setblock 540 238 359 minecraft:shroomlight
setblock 540 238 361 minecraft:shroomlight
setblock 540 238 363 minecraft:shroomlight
fill 518 239 329 518 240 329 minecraft:stripped_dark_oak_log
fill 518 239 336 518 240 336 minecraft:stripped_dark_oak_log
fill 518 239 343 518 240 343 minecraft:stripped_dark_oak_log
fill 518 239 350 518 240 350 minecraft:stripped_dark_oak_log
fill 518 239 357 518 240 357 minecraft:stripped_dark_oak_log
fill 519 239 323 519 240 323 minecraft:stripped_dark_oak_log
fill 519 239 363 519 240 363 minecraft:stripped_dark_oak_log
fill 524 239 332 524 247 333 minecraft:dark_oak_planks
fill 526 239 323 526 240 323 minecraft:stripped_dark_oak_log
fill 526 239 363 526 240 363 minecraft:stripped_dark_oak_log
fill 533 239 323 533 240 323 minecraft:stripped_dark_oak_log
fill 533 239 363 534 240 363 minecraft:stripped_dark_oak_log
fill 534 239 357 534 241 357 minecraft:stripped_dark_oak_log
fill 534 239 359 534 241 359 minecraft:stripped_dark_oak_log
fill 534 239 361 534 241 361 minecraft:stripped_dark_oak_log
fill 535 239 358 535 241 358 minecraft:stripped_dark_oak_log
fill 535 239 360 535 241 360 minecraft:stripped_dark_oak_log
fill 535 239 362 535 241 362 minecraft:stripped_dark_oak_log
fill 536 239 357 536 241 357 minecraft:stripped_dark_oak_log
fill 536 239 359 536 241 359 minecraft:stripped_dark_oak_log
fill 536 239 361 536 241 361 minecraft:stripped_dark_oak_log
fill 536 239 363 536 242 363 minecraft:stripped_dark_oak_log
fill 537 239 358 537 241 358 minecraft:stripped_dark_oak_log
fill 537 239 360 537 241 360 minecraft:stripped_dark_oak_log
fill 537 239 362 537 241 362 minecraft:stripped_dark_oak_log
fill 538 239 357 538 241 357 minecraft:stripped_dark_oak_log
fill 538 239 359 538 241 359 minecraft:stripped_dark_oak_log
fill 538 239 361 538 241 361 minecraft:stripped_dark_oak_log
fill 538 239 363 538 241 363 minecraft:stripped_dark_oak_log
fill 539 239 358 539 241 358 minecraft:stripped_dark_oak_log
fill 539 239 360 539 241 360 minecraft:stripped_dark_oak_log
fill 539 239 362 539 241 362 minecraft:stripped_dark_oak_log
fill 540 239 323 540 240 323 minecraft:stripped_dark_oak_log
fill 540 239 357 540 241 357 minecraft:stripped_dark_oak_log
fill 540 239 359 540 241 359 minecraft:stripped_dark_oak_log
fill 540 239 361 540 241 361 minecraft:stripped_dark_oak_log
fill 540 239 363 540 241 363 minecraft:stripped_dark_oak_log
fill 547 239 323 547 240 323 minecraft:stripped_dark_oak_log
fill 547 239 363 547 240 363 minecraft:stripped_dark_oak_log
fill 554 239 323 554 240 323 minecraft:stripped_dark_oak_log
fill 554 239 363 554 240 363 minecraft:stripped_dark_oak_log
fill 558 239 326 558 240 326 minecraft:stripped_dark_oak_log
fill 558 239 333 558 240 333 minecraft:stripped_dark_oak_log
fill 558 239 340 558 240 340 minecraft:stripped_dark_oak_log
fill 558 239 347 558 240 347 minecraft:stripped_dark_oak_log
fill 558 239 354 558 240 354 minecraft:stripped_dark_oak_log
fill 558 239 361 558 240 361 minecraft:stripped_dark_oak_log
fill 518 240 323 518 240 327 minecraft:stripped_dark_oak_log
fill 518 240 330 518 240 334 minecraft:stripped_dark_oak_log
fill 518 240 337 518 240 341 minecraft:stripped_dark_oak_log
fill 518 240 344 518 240 348 minecraft:stripped_dark_oak_log
fill 518 240 351 518 240 355 minecraft:stripped_dark_oak_log
fill 518 240 358 518 240 362 minecraft:stripped_dark_oak_log
fill 520 240 363 524 240 363 minecraft:stripped_dark_oak_log
fill 521 240 323 525 240 323 minecraft:stripped_dark_oak_log
fill 524 240 331 526 247 331 minecraft:dark_oak_planks
fill 525 240 334 526 247 334 minecraft:dark_oak_planks
fill 527 240 332 527 247 333 minecraft:dark_oak_planks
fill 527 240 363 531 240 363 minecraft:stripped_dark_oak_log
fill 528 240 323 532 240 323 minecraft:stripped_dark_oak_log
fill 535 240 323 539 240 323 minecraft:stripped_dark_oak_log
fill 541 240 363 545 240 363 minecraft:stripped_dark_oak_log
fill 542 240 323 546 240 323 minecraft:stripped_dark_oak_log
fill 548 240 363 552 240 363 minecraft:stripped_dark_oak_log
fill 549 240 323 553 240 323 minecraft:stripped_dark_oak_log
fill 555 240 363 558 240 363 minecraft:stripped_dark_oak_log
fill 556 240 323 558 240 323 minecraft:stripped_dark_oak_log
fill 558 240 324 558 240 325 minecraft:stripped_dark_oak_log
fill 558 240 328 558 240 332 minecraft:stripped_dark_oak_log
fill 558 240 335 558 240 339 minecraft:stripped_dark_oak_log
fill 558 240 342 558 240 346 minecraft:stripped_dark_oak_log
fill 558 240 349 558 240 353 minecraft:stripped_dark_oak_log
fill 558 240 356 558 240 360 minecraft:stripped_dark_oak_log
setblock 518 241 324 minecraft:stripped_dark_oak_log
setblock 518 241 331 minecraft:stripped_dark_oak_log
setblock 518 241 338 minecraft:stripped_dark_oak_log
setblock 518 241 345 minecraft:stripped_dark_oak_log
setblock 518 241 352 minecraft:stripped_dark_oak_log
setblock 518 241 359 minecraft:stripped_dark_oak_log
setblock 521 241 363 minecraft:stripped_dark_oak_log
fill 523 241 332 523 247 333 minecraft:dark_oak_planks
setblock 524 241 323 minecraft:stripped_dark_oak_log
fill 524 241 334 524 247 334 minecraft:dark_oak_planks
fill 527 241 331 527 247 331 minecraft:dark_oak_planks
fill 527 241 334 527 247 334 minecraft:dark_oak_planks
setblock 528 241 363 minecraft:stripped_dark_oak_log
setblock 531 241 323 minecraft:stripped_dark_oak_log
setblock 534 241 363 minecraft:stripped_dark_oak_log
setblock 538 241 323 minecraft:stripped_dark_oak_log
setblock 542 241 363 minecraft:stripped_dark_oak_log
setblock 545 241 323 minecraft:stripped_dark_oak_log
setblock 549 241 363 minecraft:stripped_dark_oak_log
setblock 552 241 323 minecraft:stripped_dark_oak_log
setblock 556 241 363 minecraft:stripped_dark_oak_log
setblock 558 241 324 minecraft:stripped_dark_oak_log
setblock 558 241 331 minecraft:stripped_dark_oak_log
setblock 558 241 338 minecraft:stripped_dark_oak_log
setblock 558 241 345 minecraft:stripped_dark_oak_log
setblock 558 241 352 minecraft:stripped_dark_oak_log
setblock 558 241 359 minecraft:stripped_dark_oak_log
setblock 518 242 325 minecraft:stripped_dark_oak_log
setblock 518 242 332 minecraft:stripped_dark_oak_log
setblock 518 242 339 minecraft:stripped_dark_oak_log
setblock 518 242 346 minecraft:stripped_dark_oak_log
setblock 518 242 353 minecraft:stripped_dark_oak_log
setblock 518 242 360 minecraft:stripped_dark_oak_log
setblock 522 242 363 minecraft:stripped_dark_oak_log
setblock 523 242 323 minecraft:stripped_dark_oak_log
fill 523 242 331 523 247 331 minecraft:dark_oak_planks
fill 523 242 334 523 247 334 minecraft:dark_oak_planks
fill 524 242 330 526 247 330 minecraft:dark_oak_planks
fill 524 242 335 526 247 335 minecraft:dark_oak_planks
fill 528 242 332 528 247 333 minecraft:dark_oak_planks
setblock 529 242 363 minecraft:stripped_dark_oak_log
setblock 530 242 323 minecraft:stripped_dark_oak_log
fill 535 242 358 539 242 362 minecraft:red_concrete
setblock 537 242 323 minecraft:stripped_dark_oak_log
setblock 543 242 363 minecraft:stripped_dark_oak_log
setblock 544 242 323 minecraft:stripped_dark_oak_log
setblock 550 242 363 minecraft:stripped_dark_oak_log
setblock 551 242 323 minecraft:stripped_dark_oak_log
setblock 557 242 363 minecraft:stripped_dark_oak_log
setblock 558 242 323 minecraft:stripped_dark_oak_log
setblock 558 242 330 minecraft:stripped_dark_oak_log
setblock 558 242 337 minecraft:stripped_dark_oak_log
setblock 558 242 344 minecraft:stripped_dark_oak_log
setblock 558 242 351 minecraft:stripped_dark_oak_log
setblock 558 242 358 minecraft:stripped_dark_oak_log
setblock 518 243 326 minecraft:stripped_dark_oak_log
setblock 518 243 333 minecraft:stripped_dark_oak_log
setblock 518 243 340 minecraft:stripped_dark_oak_log
setblock 518 243 347 minecraft:stripped_dark_oak_log
setblock 518 243 354 minecraft:stripped_dark_oak_log
setblock 518 243 361 minecraft:stripped_dark_oak_log
setblock 522 243 323 minecraft:stripped_dark_oak_log
fill 522 243 332 522 247 333 minecraft:dark_oak_planks
fill 523 243 330 523 247 330 minecraft:dark_oak_planks
setblock 523 243 363 minecraft:stripped_dark_oak_log
fill 527 243 330 527 247 330 minecraft:dark_oak_planks
fill 527 243 335 527 247 335 minecraft:dark_oak_planks
fill 528 243 331 528 247 331 minecraft:dark_oak_planks
fill 528 243 334 528 247 334 minecraft:dark_oak_planks
setblock 529 243 323 minecraft:stripped_dark_oak_log
setblock 530 243 363 minecraft:stripped_dark_oak_log
setblock 536 243 323 minecraft:stripped_dark_oak_log
fill 536 243 359 538 243 361 minecraft:red_concrete
setblock 537 243 363 minecraft:stripped_dark_oak_log
setblock 543 243 323 minecraft:stripped_dark_oak_log
setblock 544 243 363 minecraft:stripped_dark_oak_log
setblock 550 243 323 minecraft:stripped_dark_oak_log
setblock 551 243 363 minecraft:stripped_dark_oak_log
setblock 557 243 323 minecraft:stripped_dark_oak_log
setblock 558 243 329 minecraft:stripped_dark_oak_log
setblock 558 243 336 minecraft:stripped_dark_oak_log
setblock 558 243 343 minecraft:stripped_dark_oak_log
setblock 558 243 350 minecraft:stripped_dark_oak_log
setblock 558 243 357 minecraft:stripped_dark_oak_log
setblock 558 243 363 minecraft:stripped_dark_oak_log
setblock 518 244 327 minecraft:stripped_dark_oak_log
setblock 518 244 334 minecraft:stripped_dark_oak_log
setblock 518 244 341 minecraft:stripped_dark_oak_log
setblock 518 244 348 minecraft:stripped_dark_oak_log
setblock 518 244 355 minecraft:stripped_dark_oak_log
setblock 518 244 362 minecraft:stripped_dark_oak_log
setblock 520 244 325 minecraft:light[level=14]
setblock 520 244 333 minecraft:light[level=14]
setblock 520 244 341 minecraft:light[level=14]
setblock 520 244 349 minecraft:light[level=14]
setblock 520 244 357 minecraft:light[level=14]
setblock 521 244 323 minecraft:stripped_dark_oak_log
fill 522 244 331 522 247 331 minecraft:dark_oak_planks
fill 522 244 334 522 247 334 minecraft:dark_oak_planks
fill 523 244 335 523 247 335 minecraft:dark_oak_planks
fill 524 244 329 527 247 329 minecraft:dark_oak_planks
fill 524 244 336 526 247 336 minecraft:dark_oak_planks
setblock 524 244 363 minecraft:stripped_dark_oak_log
setblock 528 244 323 minecraft:stripped_dark_oak_log
setblock 528 244 325 minecraft:light[level=14]
fill 528 244 330 528 247 330 minecraft:dark_oak_planks
fill 528 244 335 528 247 335 minecraft:dark_oak_planks
setblock 528 244 341 minecraft:light[level=14]
setblock 528 244 349 minecraft:light[level=14]
setblock 528 244 357 minecraft:light[level=14]
fill 529 244 332 529 247 333 minecraft:dark_oak_planks
setblock 531 244 363 minecraft:stripped_dark_oak_log
setblock 535 244 323 minecraft:stripped_dark_oak_log
setblock 536 244 325 minecraft:light[level=14]
setblock 536 244 333 minecraft:light[level=14]
setblock 536 244 349 minecraft:light[level=14]
setblock 536 244 357 minecraft:light[level=14]
fill 537 244 360 537 245 360 minecraft:red_concrete
setblock 538 244 363 minecraft:stripped_dark_oak_log
setblock 542 244 323 minecraft:stripped_dark_oak_log
setblock 544 244 325 minecraft:light[level=14]
setblock 544 244 333 minecraft:light[level=14]
setblock 544 244 341 minecraft:light[level=14]
setblock 544 244 349 minecraft:light[level=14]
setblock 544 244 357 minecraft:light[level=14]
setblock 545 244 363 minecraft:stripped_dark_oak_log
setblock 549 244 323 minecraft:stripped_dark_oak_log
setblock 552 244 325 minecraft:light[level=14]
setblock 552 244 333 minecraft:light[level=14]
setblock 552 244 341 minecraft:light[level=14]
setblock 552 244 349 minecraft:light[level=14]
setblock 552 244 357 minecraft:light[level=14]
setblock 552 244 363 minecraft:stripped_dark_oak_log
setblock 556 244 323 minecraft:stripped_dark_oak_log
setblock 558 244 328 minecraft:stripped_dark_oak_log
setblock 558 244 335 minecraft:stripped_dark_oak_log
setblock 558 244 342 minecraft:stripped_dark_oak_log
setblock 558 244 349 minecraft:stripped_dark_oak_log
setblock 558 244 356 minecraft:stripped_dark_oak_log
fill 521 245 332 521 247 333 minecraft:dark_oak_planks
fill 522 245 330 522 247 330 minecraft:dark_oak_planks
fill 522 245 335 522 247 335 minecraft:dark_oak_planks
fill 523 245 329 523 247 329 minecraft:dark_oak_planks
fill 523 245 336 523 247 336 minecraft:dark_oak_planks
fill 527 245 336 527 247 336 minecraft:dark_oak_planks
fill 528 245 329 528 247 329 minecraft:dark_oak_planks
fill 529 245 331 529 247 331 minecraft:dark_oak_planks
fill 529 245 334 529 247 334 minecraft:dark_oak_planks
fill 536 245 359 536 245 361 minecraft:red_concrete
fill 537 245 359 538 245 359 minecraft:red_concrete
fill 537 245 361 538 245 361 minecraft:red_concrete
setblock 538 245 360 minecraft:red_concrete
setblock 518 246 329 minecraft:stripped_dark_oak_log
setblock 518 246 336 minecraft:stripped_dark_oak_log
setblock 518 246 343 minecraft:stripped_dark_oak_log
setblock 518 246 350 minecraft:stripped_dark_oak_log
setblock 518 246 357 minecraft:stripped_dark_oak_log
setblock 519 246 323 minecraft:stripped_dark_oak_log
setblock 519 246 363 minecraft:stripped_dark_oak_log
fill 521 246 331 521 247 331 minecraft:dark_oak_planks
fill 521 246 334 521 247 334 minecraft:dark_oak_planks
fill 522 246 329 522 247 329 minecraft:dark_oak_planks
fill 522 246 336 522 247 336 minecraft:dark_oak_planks
fill 524 246 328 527 247 328 minecraft:dark_oak_planks
fill 524 246 337 526 247 337 minecraft:dark_oak_planks
setblock 526 246 323 minecraft:stripped_dark_oak_log
setblock 526 246 363 minecraft:stripped_dark_oak_log
fill 528 246 336 528 247 336 minecraft:dark_oak_planks
fill 529 246 330 529 247 330 minecraft:dark_oak_planks
fill 529 246 335 529 247 335 minecraft:dark_oak_planks
fill 530 246 332 530 247 333 minecraft:dark_oak_planks
setblock 533 246 323 minecraft:stripped_dark_oak_log
setblock 533 246 363 minecraft:stripped_dark_oak_log
setblock 540 246 323 minecraft:stripped_dark_oak_log
setblock 540 246 363 minecraft:stripped_dark_oak_log
setblock 547 246 323 minecraft:stripped_dark_oak_log
setblock 547 246 363 minecraft:stripped_dark_oak_log
setblock 554 246 323 minecraft:stripped_dark_oak_log
setblock 554 246 363 minecraft:stripped_dark_oak_log
setblock 558 246 326 minecraft:stripped_dark_oak_log
setblock 558 246 333 minecraft:stripped_dark_oak_log
setblock 558 246 340 minecraft:stripped_dark_oak_log
setblock 558 246 347 minecraft:stripped_dark_oak_log
setblock 558 246 354 minecraft:stripped_dark_oak_log
setblock 558 246 361 minecraft:stripped_dark_oak_log
setblock 518 247 323 minecraft:stripped_dark_oak_log
setblock 518 247 330 minecraft:stripped_dark_oak_log
setblock 518 247 337 minecraft:stripped_dark_oak_log
setblock 518 247 344 minecraft:stripped_dark_oak_log
setblock 518 247 351 minecraft:stripped_dark_oak_log
setblock 518 247 358 minecraft:stripped_dark_oak_log
fill 520 247 332 520 247 333 minecraft:dark_oak_planks
setblock 520 247 363 minecraft:stripped_dark_oak_log
setblock 521 247 330 minecraft:dark_oak_planks
setblock 521 247 335 minecraft:dark_oak_planks
setblock 523 247 328 minecraft:dark_oak_planks
setblock 523 247 337 minecraft:dark_oak_planks
setblock 525 247 323 minecraft:stripped_dark_oak_log
fill 527 247 337 528 247 337 minecraft:dark_oak_planks
setblock 527 247 363 minecraft:stripped_dark_oak_log
setblock 528 247 328 minecraft:dark_oak_planks
setblock 529 247 329 minecraft:dark_oak_planks
setblock 529 247 336 minecraft:dark_oak_planks
schedule function dropper:buildpart/83_4 1t
