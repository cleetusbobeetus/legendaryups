setblock 430 224 335 minecraft:green_stained_glass
fill 430 224 336 430 224 338 minecraft:lime_stained_glass
setblock 430 224 339 minecraft:green_stained_glass
fill 430 224 340 430 224 342 minecraft:lime_stained_glass
setblock 430 224 343 minecraft:green_stained_glass
fill 430 224 344 430 224 346 minecraft:lime_stained_glass
setblock 430 224 347 minecraft:green_stained_glass
fill 430 224 348 430 224 350 minecraft:lime_stained_glass
setblock 430 224 351 minecraft:green_stained_glass
fill 430 224 352 430 224 354 minecraft:lime_stained_glass
setblock 430 224 355 minecraft:green_stained_glass
fill 430 224 356 432 224 356 minecraft:lime_stained_glass
setblock 430 224 359 minecraft:green_stained_glass
fill 430 224 360 432 224 360 minecraft:lime_stained_glass
setblock 430 224 363 minecraft:green_stained_glass
fill 431 224 323 431 224 325 minecraft:lime_stained_glass
setblock 431 224 326 minecraft:green_stained_glass
fill 431 224 327 431 224 329 minecraft:lime_stained_glass
setblock 431 224 330 minecraft:green_stained_glass
fill 431 224 331 431 224 333 minecraft:lime_stained_glass
setblock 431 224 334 minecraft:green_stained_glass
fill 431 224 335 431 224 337 minecraft:lime_stained_glass
setblock 431 224 338 minecraft:green_stained_glass
fill 431 224 339 431 224 341 minecraft:lime_stained_glass
setblock 431 224 342 minecraft:green_stained_glass
fill 431 224 343 431 224 345 minecraft:lime_stained_glass
setblock 431 224 346 minecraft:green_stained_glass
fill 431 224 347 431 224 349 minecraft:lime_stained_glass
setblock 431 224 350 minecraft:green_stained_glass
fill 431 224 351 431 224 353 minecraft:lime_stained_glass
setblock 431 224 354 minecraft:green_stained_glass
fill 431 224 355 433 224 355 minecraft:lime_stained_glass
setblock 431 224 358 minecraft:green_stained_glass
fill 431 224 359 433 224 359 minecraft:lime_stained_glass
setblock 431 224 362 minecraft:green_stained_glass
fill 431 224 363 433 224 363 minecraft:lime_stained_glass
fill 432 224 323 432 224 324 minecraft:lime_stained_glass
setblock 432 224 325 minecraft:green_stained_glass
fill 432 224 326 432 224 328 minecraft:lime_stained_glass
setblock 432 224 329 minecraft:green_stained_glass
fill 432 224 330 432 224 332 minecraft:lime_stained_glass
setblock 432 224 333 minecraft:green_stained_glass
fill 432 224 334 432 224 336 minecraft:lime_stained_glass
setblock 432 224 337 minecraft:green_stained_glass
fill 432 224 338 432 224 340 minecraft:lime_stained_glass
setblock 432 224 341 minecraft:green_stained_glass
fill 432 224 342 432 224 344 minecraft:lime_stained_glass
setblock 432 224 345 minecraft:green_stained_glass
fill 432 224 346 432 224 348 minecraft:lime_stained_glass
setblock 432 224 349 minecraft:green_stained_glass
fill 432 224 350 432 224 352 minecraft:lime_stained_glass
setblock 432 224 353 minecraft:green_stained_glass
fill 432 224 354 434 224 354 minecraft:lime_stained_glass
setblock 432 224 357 minecraft:green_stained_glass
fill 432 224 358 434 224 358 minecraft:lime_stained_glass
setblock 432 224 361 minecraft:green_stained_glass
fill 432 224 362 434 224 362 minecraft:lime_stained_glass
setblock 433 224 323 minecraft:lime_stained_glass
setblock 433 224 324 minecraft:green_stained_glass
fill 433 224 325 433 224 327 minecraft:lime_stained_glass
setblock 433 224 328 minecraft:green_stained_glass
fill 433 224 329 433 224 331 minecraft:lime_stained_glass
setblock 433 224 332 minecraft:green_stained_glass
fill 433 224 333 433 224 335 minecraft:lime_stained_glass
setblock 433 224 336 minecraft:green_stained_glass
fill 433 224 337 433 224 339 minecraft:lime_stained_glass
setblock 433 224 340 minecraft:green_stained_glass
fill 433 224 341 433 224 343 minecraft:lime_stained_glass
setblock 433 224 344 minecraft:green_stained_glass
setblock 433 224 345 minecraft:lime_stained_glass
fill 433 224 346 440 224 346 minecraft:iron_block
setblock 433 224 347 minecraft:lime_stained_glass
setblock 433 224 348 minecraft:green_stained_glass
fill 433 224 349 433 224 351 minecraft:lime_stained_glass
setblock 433 224 352 minecraft:green_stained_glass
fill 433 224 353 435 224 353 minecraft:lime_stained_glass
setblock 433 224 356 minecraft:green_stained_glass
fill 433 224 357 435 224 357 minecraft:lime_stained_glass
setblock 433 224 360 minecraft:green_stained_glass
fill 433 224 361 435 224 361 minecraft:lime_stained_glass
setblock 434 224 323 minecraft:green_stained_glass
fill 434 224 324 434 224 326 minecraft:lime_stained_glass
setblock 434 224 327 minecraft:green_stained_glass
fill 434 224 328 434 224 330 minecraft:lime_stained_glass
setblock 434 224 331 minecraft:green_stained_glass
fill 434 224 332 434 224 334 minecraft:lime_stained_glass
setblock 434 224 335 minecraft:green_stained_glass
fill 434 224 336 434 224 338 minecraft:lime_stained_glass
setblock 434 224 339 minecraft:green_stained_glass
fill 434 224 340 434 224 341 minecraft:lime_stained_glass
fill 434 224 344 435 224 344 minecraft:lime_stained_glass
fill 434 224 345 440 224 345 minecraft:iron_block
setblock 434 224 347 minecraft:green_stained_glass
fill 434 224 348 437 224 348 minecraft:iron_block
fill 434 224 349 434 224 350 minecraft:lime_stained_glass
setblock 434 224 351 minecraft:green_stained_glass
fill 434 224 352 436 224 352 minecraft:lime_stained_glass
setblock 434 224 355 minecraft:green_stained_glass
fill 434 224 356 436 224 356 minecraft:lime_stained_glass
setblock 434 224 359 minecraft:green_stained_glass
fill 434 224 360 436 224 360 minecraft:lime_stained_glass
setblock 434 224 363 minecraft:green_stained_glass
fill 435 224 323 435 224 325 minecraft:lime_stained_glass
setblock 435 224 326 minecraft:green_stained_glass
fill 435 224 327 435 224 329 minecraft:lime_stained_glass
setblock 435 224 330 minecraft:green_stained_glass
fill 435 224 331 435 224 333 minecraft:lime_stained_glass
setblock 435 224 334 minecraft:green_stained_glass
fill 435 224 335 435 224 337 minecraft:lime_stained_glass
setblock 435 224 338 minecraft:green_stained_glass
fill 435 224 339 436 224 339 minecraft:lime_stained_glass
setblock 435 224 341 minecraft:lime_stained_glass
setblock 435 224 342 minecraft:green_stained_glass
fill 435 224 343 441 224 343 minecraft:iron_block
setblock 435 224 347 minecraft:lime_stained_glass
setblock 435 224 349 minecraft:lime_stained_glass
setblock 435 224 354 minecraft:green_stained_glass
fill 435 224 355 437 224 355 minecraft:lime_stained_glass
setblock 435 224 358 minecraft:green_stained_glass
fill 435 224 359 437 224 359 minecraft:lime_stained_glass
setblock 435 224 362 minecraft:green_stained_glass
fill 435 224 363 437 224 363 minecraft:lime_stained_glass
fill 436 224 323 436 224 324 minecraft:lime_stained_glass
setblock 436 224 325 minecraft:green_stained_glass
fill 436 224 326 436 224 328 minecraft:lime_stained_glass
setblock 436 224 329 minecraft:green_stained_glass
fill 436 224 330 436 224 332 minecraft:lime_stained_glass
setblock 436 224 333 minecraft:green_stained_glass
fill 436 224 334 436 224 336 minecraft:lime_stained_glass
setblock 436 224 337 minecraft:green_stained_glass
setblock 436 224 338 minecraft:lime_stained_glass
fill 436 224 341 441 224 342 minecraft:iron_block
fill 436 224 344 440 224 344 minecraft:iron_block
fill 436 224 347 437 224 347 minecraft:iron_block
fill 436 224 349 438 224 350 minecraft:iron_block
setblock 436 224 351 minecraft:lime_stained_glass
fill 436 224 354 437 224 354 minecraft:lime_stained_glass
setblock 436 224 357 minecraft:green_stained_glass
fill 436 224 358 438 224 358 minecraft:lime_stained_glass
setblock 436 224 361 minecraft:green_stained_glass
fill 436 224 362 438 224 362 minecraft:lime_stained_glass
setblock 437 224 323 minecraft:lime_stained_glass
setblock 437 224 324 minecraft:green_stained_glass
fill 437 224 325 437 224 327 minecraft:lime_stained_glass
setblock 437 224 328 minecraft:green_stained_glass
fill 437 224 329 437 224 331 minecraft:lime_stained_glass
setblock 437 224 332 minecraft:green_stained_glass
fill 437 224 333 437 224 335 minecraft:lime_stained_glass
setblock 437 224 336 minecraft:green_stained_glass
fill 437 224 337 438 224 337 minecraft:lime_stained_glass
setblock 437 224 340 minecraft:green_stained_glass
fill 437 224 351 439 224 352 minecraft:iron_block
setblock 437 224 356 minecraft:green_stained_glass
fill 437 224 357 439 224 357 minecraft:lime_stained_glass
setblock 437 224 360 minecraft:green_stained_glass
fill 437 224 361 439 224 361 minecraft:lime_stained_glass
setblock 438 224 323 minecraft:green_stained_glass
fill 438 224 324 438 224 326 minecraft:lime_stained_glass
setblock 438 224 327 minecraft:green_stained_glass
fill 438 224 328 438 224 330 minecraft:lime_stained_glass
setblock 438 224 331 minecraft:green_stained_glass
fill 438 224 332 438 224 334 minecraft:lime_stained_glass
setblock 438 224 335 minecraft:green_stained_glass
fill 438 224 336 440 224 336 minecraft:lime_stained_glass
setblock 438 224 338 minecraft:lime_stained_glass
fill 438 224 339 441 224 340 minecraft:iron_block
fill 438 224 347 440 224 348 minecraft:lime_concrete
setblock 438 224 353 minecraft:lime_stained_glass
fill 438 224 356 439 224 356 minecraft:lime_stained_glass
setblock 438 224 359 minecraft:green_stained_glass
fill 438 224 360 440 224 360 minecraft:lime_stained_glass
setblock 438 224 363 minecraft:green_stained_glass
fill 439 224 323 439 224 325 minecraft:lime_stained_glass
setblock 439 224 326 minecraft:green_stained_glass
fill 439 224 327 439 224 329 minecraft:lime_stained_glass
setblock 439 224 330 minecraft:green_stained_glass
fill 439 224 331 439 224 333 minecraft:lime_stained_glass
setblock 439 224 334 minecraft:green_stained_glass
fill 439 224 335 441 224 335 minecraft:lime_stained_glass
setblock 439 224 338 minecraft:green_stained_glass
fill 439 224 349 441 224 350 minecraft:lime_concrete
fill 439 224 355 440 224 355 minecraft:lime_stained_glass
setblock 439 224 358 minecraft:green_stained_glass
fill 439 224 359 441 224 359 minecraft:lime_stained_glass
setblock 439 224 362 minecraft:green_stained_glass
fill 439 224 363 441 224 363 minecraft:lime_stained_glass
fill 440 224 323 440 224 324 minecraft:lime_stained_glass
setblock 440 224 325 minecraft:green_stained_glass
fill 440 224 326 440 224 328 minecraft:lime_stained_glass
setblock 440 224 329 minecraft:green_stained_glass
fill 440 224 330 440 224 332 minecraft:lime_stained_glass
setblock 440 224 333 minecraft:green_stained_glass
fill 440 224 334 442 224 334 minecraft:lime_stained_glass
fill 440 224 351 441 224 351 minecraft:lime_concrete
fill 440 224 352 450 224 352 minecraft:iron_block
setblock 440 224 357 minecraft:green_stained_glass
fill 440 224 358 442 224 358 minecraft:lime_stained_glass
setblock 440 224 361 minecraft:green_stained_glass
fill 440 224 362 442 224 362 minecraft:lime_stained_glass
setblock 441 224 323 minecraft:lime_stained_glass
setblock 441 224 324 minecraft:green_stained_glass
fill 441 224 325 441 224 327 minecraft:lime_stained_glass
setblock 441 224 328 minecraft:green_stained_glass
fill 441 224 329 441 224 331 minecraft:lime_stained_glass
setblock 441 224 332 minecraft:green_stained_glass
fill 441 224 333 443 224 333 minecraft:lime_stained_glass
setblock 441 224 336 minecraft:green_stained_glass
setblock 441 224 337 minecraft:lime_stained_glass
fill 441 224 344 441 224 348 minecraft:verdant_froglight
fill 441 224 357 443 224 357 minecraft:lime_stained_glass
setblock 441 224 360 minecraft:green_stained_glass
fill 441 224 361 443 224 361 minecraft:lime_stained_glass
setblock 442 224 323 minecraft:green_stained_glass
fill 442 224 324 442 224 326 minecraft:lime_stained_glass
setblock 442 224 327 minecraft:green_stained_glass
fill 442 224 328 442 224 330 minecraft:lime_stained_glass
setblock 442 224 331 minecraft:green_stained_glass
fill 442 224 332 444 224 332 minecraft:lime_stained_glass
setblock 442 224 335 minecraft:green_stained_glass
fill 442 224 339 449 224 339 minecraft:iron_block
fill 442 224 340 446 224 342 minecraft:lime_concrete
fill 442 224 343 442 224 344 minecraft:verdant_froglight
fill 442 224 348 442 224 349 minecraft:verdant_froglight
fill 442 224 350 446 224 351 minecraft:iron_block
setblock 442 224 355 minecraft:green_stained_glass
setblock 442 224 356 minecraft:lime_stained_glass
setblock 442 224 359 minecraft:green_stained_glass
fill 442 224 360 444 224 360 minecraft:lime_stained_glass
setblock 442 224 363 minecraft:green_stained_glass
fill 443 224 323 443 224 325 minecraft:lime_stained_glass
setblock 443 224 326 minecraft:green_stained_glass
fill 443 224 327 443 224 329 minecraft:lime_stained_glass
setblock 443 224 330 minecraft:green_stained_glass
fill 443 224 331 445 224 331 minecraft:lime_stained_glass
setblock 443 224 334 minecraft:green_stained_glass
fill 443 224 335 443 224 337 minecraft:lime_stained_glass
fill 443 224 343 446 224 343 minecraft:verdant_froglight
fill 443 224 349 446 224 349 minecraft:verdant_froglight
setblock 443 224 358 minecraft:green_stained_glass
fill 443 224 359 445 224 359 minecraft:lime_stained_glass
setblock 443 224 362 minecraft:green_stained_glass
fill 443 224 363 445 224 363 minecraft:lime_stained_glass
fill 444 224 323 444 224 324 minecraft:lime_stained_glass
setblock 444 224 325 minecraft:green_stained_glass
fill 444 224 326 444 224 328 minecraft:lime_stained_glass
setblock 444 224 329 minecraft:green_stained_glass
fill 444 224 330 446 224 330 minecraft:lime_stained_glass
setblock 444 224 333 minecraft:green_stained_glass
fill 444 224 334 446 224 334 minecraft:lime_stained_glass
fill 444 224 358 446 224 358 minecraft:lime_stained_glass
setblock 444 224 361 minecraft:green_stained_glass
fill 444 224 362 446 224 362 minecraft:lime_stained_glass
setblock 445 224 323 minecraft:lime_stained_glass
setblock 445 224 324 minecraft:green_stained_glass
fill 445 224 325 445 224 327 minecraft:lime_stained_glass
setblock 445 224 328 minecraft:green_stained_glass
fill 445 224 329 447 224 329 minecraft:lime_stained_glass
setblock 445 224 332 minecraft:green_stained_glass
fill 445 224 333 447 224 333 minecraft:lime_stained_glass
setblock 445 224 335 minecraft:lime_stained_glass
setblock 445 224 355 minecraft:lime_stained_glass
setblock 445 224 356 minecraft:green_stained_glass
fill 445 224 357 447 224 357 minecraft:lime_stained_glass
setblock 445 224 360 minecraft:green_stained_glass
fill 445 224 361 447 224 361 minecraft:lime_stained_glass
setblock 446 224 323 minecraft:green_stained_glass
fill 446 224 324 446 224 326 minecraft:lime_stained_glass
setblock 446 224 327 minecraft:green_stained_glass
fill 446 224 328 448 224 328 minecraft:lime_stained_glass
setblock 446 224 331 minecraft:green_stained_glass
fill 446 224 332 448 224 332 minecraft:lime_stained_glass
setblock 446 224 335 minecraft:green_stained_glass
fill 446 224 336 446 224 337 minecraft:lime_stained_glass
fill 446 224 344 447 224 344 minecraft:verdant_froglight
fill 446 224 348 447 224 348 minecraft:verdant_froglight
setblock 446 224 359 minecraft:green_stained_glass
fill 446 224 360 448 224 360 minecraft:lime_stained_glass
setblock 446 224 363 minecraft:green_stained_glass
fill 447 224 323 447 224 325 minecraft:lime_stained_glass
setblock 447 224 326 minecraft:green_stained_glass
fill 447 224 327 449 224 327 minecraft:lime_stained_glass
setblock 447 224 330 minecraft:green_stained_glass
fill 447 224 331 449 224 331 minecraft:lime_stained_glass
setblock 447 224 334 minecraft:green_stained_glass
fill 447 224 335 449 224 335 minecraft:lime_stained_glass
fill 447 224 340 449 224 343 minecraft:iron_block
fill 447 224 345 447 224 347 minecraft:verdant_froglight
fill 447 224 349 448 224 351 minecraft:lime_concrete
fill 447 224 355 447 224 356 minecraft:lime_stained_glass
setblock 447 224 358 minecraft:green_stained_glass
fill 447 224 359 449 224 359 minecraft:lime_stained_glass
setblock 447 224 362 minecraft:green_stained_glass
fill 447 224 363 449 224 363 minecraft:lime_stained_glass
fill 448 224 323 448 224 324 minecraft:lime_stained_glass
setblock 448 224 325 minecraft:green_stained_glass
fill 448 224 326 450 224 326 minecraft:lime_stained_glass
setblock 448 224 329 minecraft:green_stained_glass
fill 448 224 330 450 224 330 minecraft:lime_stained_glass
setblock 448 224 333 minecraft:green_stained_glass
fill 448 224 334 450 224 334 minecraft:lime_stained_glass
setblock 448 224 337 minecraft:green_stained_glass
fill 448 224 344 452 224 345 minecraft:iron_block
fill 448 224 346 450 224 348 minecraft:lime_concrete
setblock 448 224 356 minecraft:lime_stained_glass
setblock 448 224 357 minecraft:green_stained_glass
fill 448 224 358 450 224 358 minecraft:lime_stained_glass
setblock 448 224 361 minecraft:green_stained_glass
fill 448 224 362 450 224 362 minecraft:lime_stained_glass
setblock 449 224 323 minecraft:lime_stained_glass
setblock 449 224 324 minecraft:green_stained_glass
fill 449 224 325 451 224 325 minecraft:lime_stained_glass
setblock 449 224 328 minecraft:green_stained_glass
fill 449 224 329 451 224 329 minecraft:lime_stained_glass
setblock 449 224 332 minecraft:green_stained_glass
fill 449 224 333 451 224 333 minecraft:lime_stained_glass
setblock 449 224 336 minecraft:green_stained_glass
setblock 449 224 337 minecraft:lime_stained_glass
fill 449 224 349 449 224 350 minecraft:lime_concrete
fill 449 224 351 450 224 351 minecraft:iron_block
fill 449 224 354 450 224 354 minecraft:lime_stained_glass
setblock 449 224 356 minecraft:green_stained_glass
fill 449 224 357 451 224 357 minecraft:lime_stained_glass
setblock 449 224 360 minecraft:green_stained_glass
fill 449 224 361 451 224 361 minecraft:lime_stained_glass
setblock 450 224 323 minecraft:green_stained_glass
fill 450 224 324 452 224 324 minecraft:lime_stained_glass
setblock 450 224 327 minecraft:green_stained_glass
fill 450 224 328 452 224 328 minecraft:lime_stained_glass
setblock 450 224 331 minecraft:green_stained_glass
fill 450 224 332 452 224 332 minecraft:lime_stained_glass
setblock 450 224 335 minecraft:green_stained_glass
fill 450 224 336 452 224 336 minecraft:lime_stained_glass
setblock 450 224 339 minecraft:green_stained_glass
fill 450 224 341 451 224 343 minecraft:iron_block
fill 450 224 349 452 224 350 minecraft:iron_block
setblock 450 224 355 minecraft:green_stained_glass
fill 450 224 356 452 224 356 minecraft:lime_stained_glass
setblock 450 224 359 minecraft:green_stained_glass
fill 450 224 360 452 224 360 minecraft:lime_stained_glass
setblock 450 224 363 minecraft:green_stained_glass
fill 451 224 323 453 224 323 minecraft:lime_stained_glass
setblock 451 224 326 minecraft:green_stained_glass
fill 451 224 327 453 224 327 minecraft:lime_stained_glass
setblock 451 224 330 minecraft:green_stained_glass
fill 451 224 331 453 224 331 minecraft:lime_stained_glass
setblock 451 224 334 minecraft:green_stained_glass
fill 451 224 335 453 224 335 minecraft:lime_stained_glass
setblock 451 224 337 minecraft:lime_stained_glass
setblock 451 224 338 minecraft:green_stained_glass
fill 451 224 346 452 224 348 minecraft:iron_block
setblock 451 224 352 minecraft:lime_stained_glass
fill 451 224 355 453 224 355 minecraft:lime_stained_glass
setblock 451 224 358 minecraft:green_stained_glass
fill 451 224 359 453 224 359 minecraft:lime_stained_glass
setblock 451 224 362 minecraft:green_stained_glass
fill 451 224 363 453 224 363 minecraft:lime_stained_glass
setblock 452 224 325 minecraft:green_stained_glass
fill 452 224 326 454 224 326 minecraft:lime_stained_glass
setblock 452 224 329 minecraft:green_stained_glass
fill 452 224 330 454 224 330 minecraft:lime_stained_glass
setblock 452 224 333 minecraft:green_stained_glass
fill 452 224 334 454 224 334 minecraft:lime_stained_glass
setblock 452 224 337 minecraft:green_stained_glass
fill 452 224 338 454 224 338 minecraft:lime_stained_glass
setblock 452 224 340 minecraft:lime_stained_glass
setblock 452 224 341 minecraft:green_stained_glass
setblock 452 224 343 minecraft:iron_block
setblock 452 224 353 minecraft:green_stained_glass
fill 452 224 354 454 224 354 minecraft:lime_stained_glass
setblock 452 224 357 minecraft:green_stained_glass
fill 452 224 358 454 224 358 minecraft:lime_stained_glass
setblock 452 224 361 minecraft:green_stained_glass
fill 452 224 362 454 224 362 minecraft:lime_stained_glass
setblock 453 224 324 minecraft:green_stained_glass
fill 453 224 325 455 224 325 minecraft:lime_stained_glass
setblock 453 224 328 minecraft:green_stained_glass
fill 453 224 329 455 224 329 minecraft:lime_stained_glass
setblock 453 224 332 minecraft:green_stained_glass
fill 453 224 333 455 224 333 minecraft:lime_stained_glass
setblock 453 224 336 minecraft:green_stained_glass
fill 453 224 337 455 224 337 minecraft:lime_stained_glass
setblock 453 224 339 minecraft:lime_stained_glass
setblock 453 224 340 minecraft:green_stained_glass
setblock 453 224 343 minecraft:lime_stained_glass
fill 453 224 344 454 224 344 minecraft:iron_block
fill 453 224 345 455 224 345 minecraft:lime_stained_glass
setblock 453 224 348 minecraft:green_stained_glass
fill 453 224 350 453 224 351 minecraft:lime_stained_glass
fill 453 224 353 455 224 353 minecraft:lime_stained_glass
setblock 453 224 356 minecraft:green_stained_glass
fill 453 224 357 455 224 357 minecraft:lime_stained_glass
setblock 453 224 360 minecraft:green_stained_glass
fill 453 224 361 455 224 361 minecraft:lime_stained_glass
setblock 454 224 323 minecraft:green_stained_glass
fill 454 224 324 456 224 324 minecraft:lime_stained_glass
setblock 454 224 327 minecraft:green_stained_glass
fill 454 224 328 456 224 328 minecraft:lime_stained_glass
setblock 454 224 331 minecraft:green_stained_glass
fill 454 224 332 456 224 332 minecraft:lime_stained_glass
setblock 454 224 335 minecraft:green_stained_glass
fill 454 224 336 456 224 336 minecraft:lime_stained_glass
setblock 454 224 339 minecraft:green_stained_glass
fill 454 224 340 454 224 342 minecraft:lime_stained_glass
setblock 454 224 343 minecraft:green_stained_glass
fill 454 224 348 456 224 348 minecraft:lime_stained_glass
setblock 454 224 351 minecraft:green_stained_glass
fill 454 224 352 456 224 352 minecraft:lime_stained_glass
setblock 454 224 355 minecraft:green_stained_glass
fill 454 224 356 456 224 356 minecraft:lime_stained_glass
setblock 454 224 359 minecraft:green_stained_glass
fill 454 224 360 456 224 360 minecraft:lime_stained_glass
setblock 454 224 363 minecraft:green_stained_glass
fill 455 224 323 457 224 323 minecraft:lime_stained_glass
setblock 455 224 326 minecraft:green_stained_glass
fill 455 224 327 457 224 327 minecraft:lime_stained_glass
setblock 455 224 330 minecraft:green_stained_glass
fill 455 224 331 457 224 331 minecraft:lime_stained_glass
setblock 455 224 334 minecraft:green_stained_glass
fill 455 224 335 457 224 335 minecraft:lime_stained_glass
setblock 455 224 338 minecraft:green_stained_glass
fill 455 224 339 455 224 341 minecraft:lime_stained_glass
setblock 455 224 342 minecraft:green_stained_glass
fill 455 224 343 456 224 344 minecraft:lime_stained_glass
fill 455 224 347 457 224 347 minecraft:lime_stained_glass
setblock 455 224 349 minecraft:lime_stained_glass
setblock 455 224 350 minecraft:green_stained_glass
fill 455 224 351 457 224 351 minecraft:lime_stained_glass
setblock 455 224 354 minecraft:green_stained_glass
fill 455 224 355 457 224 355 minecraft:lime_stained_glass
setblock 455 224 358 minecraft:green_stained_glass
fill 455 224 359 457 224 359 minecraft:lime_stained_glass
setblock 455 224 362 minecraft:green_stained_glass
fill 455 224 363 457 224 363 minecraft:lime_stained_glass
setblock 456 224 325 minecraft:green_stained_glass
fill 456 224 326 458 224 326 minecraft:lime_stained_glass
setblock 456 224 329 minecraft:green_stained_glass
fill 456 224 330 458 224 330 minecraft:lime_stained_glass
setblock 456 224 333 minecraft:green_stained_glass
fill 456 224 334 458 224 334 minecraft:lime_stained_glass
setblock 456 224 337 minecraft:green_stained_glass
fill 456 224 338 456 224 340 minecraft:lime_stained_glass
setblock 456 224 341 minecraft:green_stained_glass
fill 456 224 342 458 224 342 minecraft:lime_stained_glass
setblock 456 224 345 minecraft:green_stained_glass
fill 456 224 346 458 224 346 minecraft:lime_stained_glass
setblock 456 224 349 minecraft:green_stained_glass
fill 456 224 350 458 224 350 minecraft:lime_stained_glass
setblock 456 224 353 minecraft:green_stained_glass
fill 456 224 354 458 224 354 minecraft:lime_stained_glass
setblock 456 224 357 minecraft:green_stained_glass
fill 456 224 358 458 224 358 minecraft:lime_stained_glass
setblock 456 224 361 minecraft:green_stained_glass
fill 456 224 362 458 224 362 minecraft:lime_stained_glass
setblock 457 224 324 minecraft:green_stained_glass
fill 457 224 325 459 224 325 minecraft:lime_stained_glass
setblock 457 224 328 minecraft:green_stained_glass
fill 457 224 329 459 224 329 minecraft:lime_stained_glass
setblock 457 224 332 minecraft:green_stained_glass
fill 457 224 333 459 224 333 minecraft:lime_stained_glass
setblock 457 224 336 minecraft:green_stained_glass
fill 457 224 337 457 224 339 minecraft:lime_stained_glass
setblock 457 224 340 minecraft:green_stained_glass
fill 457 224 341 459 224 341 minecraft:lime_stained_glass
setblock 457 224 343 minecraft:lime_stained_glass
setblock 457 224 344 minecraft:green_stained_glass
fill 457 224 345 459 224 345 minecraft:lime_stained_glass
setblock 457 224 348 minecraft:green_stained_glass
fill 457 224 349 459 224 349 minecraft:lime_stained_glass
setblock 457 224 352 minecraft:green_stained_glass
fill 457 224 353 459 224 353 minecraft:lime_stained_glass
setblock 457 224 356 minecraft:green_stained_glass
fill 457 224 357 459 224 357 minecraft:lime_stained_glass
setblock 457 224 360 minecraft:green_stained_glass
fill 457 224 361 459 224 361 minecraft:lime_stained_glass
setblock 458 224 323 minecraft:green_stained_glass
fill 458 224 324 460 224 324 minecraft:lime_stained_glass
setblock 458 224 327 minecraft:green_stained_glass
fill 458 224 328 460 224 328 minecraft:lime_stained_glass
setblock 458 224 331 minecraft:green_stained_glass
fill 458 224 332 460 224 332 minecraft:lime_stained_glass
setblock 458 224 335 minecraft:green_stained_glass
fill 458 224 336 458 224 338 minecraft:lime_stained_glass
setblock 458 224 339 minecraft:green_stained_glass
fill 458 224 340 460 224 340 minecraft:lime_stained_glass
setblock 458 224 343 minecraft:green_stained_glass
fill 458 224 344 460 224 344 minecraft:lime_stained_glass
setblock 458 224 347 minecraft:green_stained_glass
fill 458 224 348 460 224 348 minecraft:lime_stained_glass
setblock 458 224 351 minecraft:green_stained_glass
fill 458 224 352 460 224 352 minecraft:lime_stained_glass
setblock 458 224 355 minecraft:green_stained_glass
fill 458 224 356 460 224 356 minecraft:lime_stained_glass
setblock 458 224 359 minecraft:green_stained_glass
fill 458 224 360 460 224 360 minecraft:lime_stained_glass
setblock 458 224 363 minecraft:green_stained_glass
fill 459 224 323 461 224 323 minecraft:lime_stained_glass
setblock 459 224 326 minecraft:green_stained_glass
fill 459 224 327 461 224 327 minecraft:lime_stained_glass
setblock 459 224 330 minecraft:green_stained_glass
fill 459 224 331 461 224 331 minecraft:lime_stained_glass
setblock 459 224 334 minecraft:green_stained_glass
fill 459 224 335 459 224 337 minecraft:lime_stained_glass
setblock 459 224 338 minecraft:green_stained_glass
fill 459 224 339 461 224 339 minecraft:lime_stained_glass
setblock 459 224 342 minecraft:green_stained_glass
fill 459 224 343 461 224 343 minecraft:lime_stained_glass
setblock 459 224 346 minecraft:green_stained_glass
fill 459 224 347 461 224 347 minecraft:lime_stained_glass
setblock 459 224 350 minecraft:green_stained_glass
fill 459 224 351 461 224 351 minecraft:lime_stained_glass
setblock 459 224 354 minecraft:green_stained_glass
fill 459 224 355 461 224 355 minecraft:lime_stained_glass
setblock 459 224 358 minecraft:green_stained_glass
fill 459 224 359 461 224 359 minecraft:lime_stained_glass
setblock 459 224 362 minecraft:green_stained_glass
fill 459 224 363 461 224 363 minecraft:lime_stained_glass
setblock 460 224 325 minecraft:green_stained_glass
fill 460 224 326 462 224 326 minecraft:lime_stained_glass
setblock 460 224 329 minecraft:green_stained_glass
fill 460 224 330 462 224 330 minecraft:lime_stained_glass
setblock 460 224 333 minecraft:green_stained_glass
fill 460 224 334 460 224 336 minecraft:lime_stained_glass
setblock 460 224 337 minecraft:green_stained_glass
fill 460 224 338 462 224 338 minecraft:lime_stained_glass
setblock 460 224 341 minecraft:green_stained_glass
fill 460 224 342 462 224 342 minecraft:lime_stained_glass
setblock 460 224 345 minecraft:green_stained_glass
fill 460 224 346 462 224 346 minecraft:lime_stained_glass
setblock 460 224 349 minecraft:green_stained_glass
fill 460 224 350 462 224 350 minecraft:lime_stained_glass
setblock 460 224 353 minecraft:green_stained_glass
fill 460 224 354 462 224 354 minecraft:lime_stained_glass
setblock 460 224 357 minecraft:green_stained_glass
fill 460 224 358 462 224 358 minecraft:lime_stained_glass
setblock 460 224 361 minecraft:green_stained_glass
fill 460 224 362 462 224 362 minecraft:lime_stained_glass
setblock 461 224 324 minecraft:green_stained_glass
fill 461 224 325 463 224 325 minecraft:lime_stained_glass
setblock 461 224 328 minecraft:green_stained_glass
fill 461 224 329 463 224 329 minecraft:lime_stained_glass
setblock 461 224 332 minecraft:green_stained_glass
fill 461 224 333 461 224 335 minecraft:lime_stained_glass
setblock 461 224 336 minecraft:green_stained_glass
fill 461 224 337 463 224 337 minecraft:lime_stained_glass
setblock 461 224 340 minecraft:green_stained_glass
fill 461 224 341 463 224 341 minecraft:lime_stained_glass
setblock 461 224 344 minecraft:green_stained_glass
fill 461 224 345 463 224 345 minecraft:lime_stained_glass
setblock 461 224 348 minecraft:green_stained_glass
fill 461 224 349 463 224 349 minecraft:lime_stained_glass
setblock 461 224 352 minecraft:green_stained_glass
fill 461 224 353 463 224 353 minecraft:lime_stained_glass
setblock 461 224 356 minecraft:green_stained_glass
fill 461 224 357 463 224 357 minecraft:lime_stained_glass
setblock 461 224 360 minecraft:green_stained_glass
fill 461 224 361 463 224 361 minecraft:lime_stained_glass
setblock 462 224 323 minecraft:green_stained_glass
fill 462 224 324 464 224 324 minecraft:lime_stained_glass
setblock 462 224 327 minecraft:green_stained_glass
fill 462 224 328 464 224 328 minecraft:lime_stained_glass
setblock 462 224 331 minecraft:green_stained_glass
fill 462 224 332 462 224 334 minecraft:lime_stained_glass
setblock 462 224 335 minecraft:green_stained_glass
fill 462 224 336 464 224 336 minecraft:lime_stained_glass
setblock 462 224 339 minecraft:green_stained_glass
fill 462 224 340 464 224 340 minecraft:lime_stained_glass
setblock 462 224 343 minecraft:green_stained_glass
fill 462 224 344 464 224 344 minecraft:lime_stained_glass
setblock 462 224 347 minecraft:green_stained_glass
fill 462 224 348 464 224 348 minecraft:lime_stained_glass
setblock 462 224 351 minecraft:green_stained_glass
fill 462 224 352 464 224 352 minecraft:lime_stained_glass
setblock 462 224 355 minecraft:green_stained_glass
fill 462 224 356 464 224 356 minecraft:lime_stained_glass
setblock 462 224 359 minecraft:green_stained_glass
fill 462 224 360 464 224 360 minecraft:lime_stained_glass
setblock 462 224 363 minecraft:green_stained_glass
fill 463 224 323 464 224 323 minecraft:lime_stained_glass
setblock 463 224 326 minecraft:green_stained_glass
fill 463 224 327 464 224 327 minecraft:lime_stained_glass
setblock 463 224 330 minecraft:green_stained_glass
fill 463 224 331 463 224 333 minecraft:lime_stained_glass
setblock 463 224 334 minecraft:green_stained_glass
fill 463 224 335 464 224 335 minecraft:lime_stained_glass
setblock 463 224 338 minecraft:green_stained_glass
fill 463 224 339 464 224 339 minecraft:lime_stained_glass
setblock 463 224 342 minecraft:green_stained_glass
fill 463 224 343 464 224 343 minecraft:lime_stained_glass
setblock 463 224 346 minecraft:green_stained_glass
fill 463 224 347 464 224 347 minecraft:lime_stained_glass
setblock 463 224 350 minecraft:green_stained_glass
fill 463 224 351 464 224 351 minecraft:lime_stained_glass
setblock 463 224 354 minecraft:green_stained_glass
fill 463 224 355 464 224 355 minecraft:lime_stained_glass
setblock 463 224 358 minecraft:green_stained_glass
fill 463 224 359 464 224 359 minecraft:lime_stained_glass
setblock 463 224 362 minecraft:green_stained_glass
fill 463 224 363 464 224 363 minecraft:lime_stained_glass
setblock 464 224 325 minecraft:green_stained_glass
setblock 464 224 326 minecraft:lime_stained_glass
setblock 464 224 329 minecraft:green_stained_glass
fill 464 224 330 464 224 332 minecraft:lime_stained_glass
setblock 464 224 333 minecraft:green_stained_glass
setblock 464 224 334 minecraft:lime_stained_glass
setblock 464 224 337 minecraft:green_stained_glass
setblock 464 224 338 minecraft:lime_stained_glass
setblock 464 224 341 minecraft:green_stained_glass
setblock 464 224 342 minecraft:lime_stained_glass
setblock 464 224 345 minecraft:green_stained_glass
setblock 464 224 346 minecraft:lime_stained_glass
setblock 464 224 349 minecraft:green_stained_glass
setblock 464 224 350 minecraft:lime_stained_glass
setblock 464 224 353 minecraft:green_stained_glass
setblock 464 224 354 minecraft:lime_stained_glass
setblock 464 224 357 minecraft:green_stained_glass
setblock 464 224 358 minecraft:lime_stained_glass
setblock 464 224 361 minecraft:green_stained_glass
setblock 464 224 362 minecraft:lime_stained_glass
setblock 426 225 325 minecraft:light[level=14]
setblock 426 225 333 minecraft:light[level=14]
setblock 426 225 341 minecraft:light[level=14]
setblock 426 225 349 minecraft:light[level=14]
setblock 426 225 357 minecraft:light[level=14]
setblock 434 225 325 minecraft:light[level=14]
setblock 434 225 333 minecraft:light[level=14]
setblock 434 225 341 minecraft:light[level=14]
setblock 434 225 349 minecraft:light[level=14]
setblock 434 225 357 minecraft:light[level=14]
setblock 442 225 325 minecraft:light[level=14]
setblock 442 225 333 minecraft:light[level=14]
setblock 442 225 341 minecraft:light[level=14]
setblock 442 225 349 minecraft:light[level=14]
setblock 442 225 357 minecraft:light[level=14]
setblock 450 225 325 minecraft:light[level=14]
setblock 450 225 333 minecraft:light[level=14]
setblock 450 225 341 minecraft:light[level=14]
setblock 450 225 349 minecraft:light[level=14]
setblock 450 225 357 minecraft:light[level=14]
setblock 458 225 325 minecraft:light[level=14]
setblock 458 225 333 minecraft:light[level=14]
setblock 458 225 341 minecraft:light[level=14]
setblock 458 225 349 minecraft:light[level=14]
setblock 458 225 357 minecraft:light[level=14]
fill 424 228 324 424 272 324 minecraft:iron_block
setblock 424 228 325 minecraft:light_gray_concrete
fill 424 228 334 424 272 334 minecraft:iron_block
setblock 424 228 335 minecraft:light_gray_concrete
fill 424 228 344 424 272 344 minecraft:iron_block
setblock 424 228 345 minecraft:light_gray_concrete
fill 424 228 354 424 272 354 minecraft:iron_block
setblock 424 228 355 minecraft:light_gray_concrete
fill 425 228 363 425 272 363 minecraft:iron_block
fill 426 228 334 428 272 336 minecraft:iron_block
setblock 426 228 363 minecraft:light_gray_concrete
setblock 430 228 323 minecraft:light_gray_concrete
fill 431 228 323 431 272 323 minecraft:iron_block
fill 435 228 363 435 272 363 minecraft:iron_block
setblock 436 228 363 minecraft:light_gray_concrete
setblock 440 228 323 minecraft:light_gray_concrete
fill 441 228 323 441 272 323 minecraft:iron_block
fill 445 228 363 445 272 363 minecraft:iron_block
setblock 446 228 363 minecraft:light_gray_concrete
setblock 450 228 323 minecraft:light_gray_concrete
fill 451 228 323 451 272 323 minecraft:iron_block
fill 455 228 363 455 272 363 minecraft:iron_block
setblock 456 228 363 minecraft:light_gray_concrete
setblock 460 228 323 minecraft:light_gray_concrete
fill 461 228 323 461 272 323 minecraft:iron_block
setblock 464 228 329 minecraft:light_gray_concrete
fill 464 228 330 464 272 330 minecraft:iron_block
setblock 464 228 339 minecraft:light_gray_concrete
fill 464 228 340 464 272 340 minecraft:iron_block
setblock 464 228 349 minecraft:light_gray_concrete
fill 464 228 350 464 272 350 minecraft:iron_block
setblock 464 228 359 minecraft:light_gray_concrete
fill 464 228 360 464 272 360 minecraft:iron_block
fill 423 229 328 423 229 331 minecraft:verdant_froglight
fill 423 229 338 423 229 341 minecraft:verdant_froglight
fill 423 229 348 423 229 351 minecraft:verdant_froglight
fill 423 229 358 423 229 361 minecraft:verdant_froglight
fill 426 229 322 429 229 322 minecraft:verdant_froglight
fill 427 229 364 430 229 364 minecraft:verdant_froglight
fill 436 229 322 439 229 322 minecraft:verdant_froglight
fill 437 229 364 440 229 364 minecraft:verdant_froglight
fill 446 229 322 449 229 322 minecraft:verdant_froglight
fill 447 229 364 450 229 364 minecraft:verdant_froglight
fill 456 229 322 459 229 322 minecraft:verdant_froglight
fill 457 229 364 460 229 364 minecraft:verdant_froglight
fill 465 229 323 465 229 326 minecraft:verdant_froglight
fill 465 229 333 465 229 336 minecraft:verdant_froglight
fill 465 229 343 465 229 346 minecraft:verdant_froglight
fill 465 229 353 465 229 356 minecraft:verdant_froglight
setblock 465 229 363 minecraft:verdant_froglight
fill 423 230 328 423 237 331 minecraft:white_concrete
fill 423 230 338 423 237 341 minecraft:white_concrete
fill 423 230 348 423 237 351 minecraft:white_concrete
fill 423 230 358 423 237 361 minecraft:white_concrete
fill 425 230 334 425 230 336 minecraft:light_gray_concrete
fill 426 230 322 429 237 322 minecraft:white_concrete
fill 426 230 333 428 230 333 minecraft:light_gray_concrete
fill 426 230 337 428 230 337 minecraft:light_gray_concrete
fill 427 230 364 430 237 364 minecraft:white_concrete
fill 429 230 334 429 230 336 minecraft:light_gray_concrete
fill 436 230 322 439 237 322 minecraft:white_concrete
fill 437 230 364 440 237 364 minecraft:white_concrete
fill 446 230 322 449 237 322 minecraft:white_concrete
fill 447 230 364 450 237 364 minecraft:white_concrete
fill 456 230 322 459 237 322 minecraft:white_concrete
fill 456 230 360 456 231 362 minecraft:iron_block
fill 457 230 364 460 237 364 minecraft:white_concrete
fill 465 230 323 465 237 326 minecraft:white_concrete
fill 465 230 333 465 237 336 minecraft:white_concrete
fill 465 230 343 465 237 346 minecraft:white_concrete
fill 465 230 353 465 237 356 minecraft:white_concrete
fill 465 230 363 465 237 363 minecraft:white_concrete
setblock 426 233 325 minecraft:light[level=14]
setblock 426 233 333 minecraft:light[level=14]
setblock 426 233 341 minecraft:light[level=14]
setblock 426 233 349 minecraft:light[level=14]
setblock 426 233 357 minecraft:light[level=14]
setblock 434 233 325 minecraft:light[level=14]
setblock 434 233 333 minecraft:light[level=14]
setblock 434 233 341 minecraft:light[level=14]
setblock 434 233 349 minecraft:light[level=14]
setblock 434 233 357 minecraft:light[level=14]
setblock 442 233 325 minecraft:light[level=14]
setblock 442 233 333 minecraft:light[level=14]
setblock 442 233 341 minecraft:light[level=14]
setblock 442 233 349 minecraft:light[level=14]
setblock 442 233 357 minecraft:light[level=14]
setblock 450 233 325 minecraft:light[level=14]
setblock 450 233 333 minecraft:light[level=14]
setblock 450 233 341 minecraft:light[level=14]
setblock 450 233 349 minecraft:light[level=14]
setblock 450 233 357 minecraft:light[level=14]
setblock 458 233 325 minecraft:light[level=14]
setblock 458 233 333 minecraft:light[level=14]
setblock 458 233 341 minecraft:light[level=14]
setblock 458 233 349 minecraft:light[level=14]
setblock 458 233 357 minecraft:light[level=14]
setblock 424 234 325 minecraft:light_gray_concrete
fill 424 234 327 424 234 330 minecraft:light_gray_concrete
setblock 424 234 335 minecraft:light_gray_concrete
fill 424 234 337 424 234 340 minecraft:light_gray_concrete
setblock 424 234 345 minecraft:light_gray_concrete
fill 424 234 347 424 234 350 minecraft:light_gray_concrete
setblock 424 234 355 minecraft:light_gray_concrete
fill 424 234 357 424 234 360 minecraft:light_gray_concrete
fill 425 234 323 428 234 323 minecraft:light_gray_concrete
setblock 426 234 363 minecraft:light_gray_concrete
fill 428 234 363 431 234 363 minecraft:light_gray_concrete
setblock 430 234 323 minecraft:light_gray_concrete
fill 435 234 323 438 234 323 minecraft:light_gray_concrete
setblock 436 234 363 minecraft:light_gray_concrete
fill 438 234 363 441 234 363 minecraft:light_gray_concrete
setblock 440 234 323 minecraft:light_gray_concrete
fill 445 234 323 448 234 323 minecraft:light_gray_concrete
setblock 446 234 363 minecraft:light_gray_concrete
fill 448 234 363 451 234 363 minecraft:light_gray_concrete
setblock 450 234 323 minecraft:light_gray_concrete
fill 455 234 323 458 234 323 minecraft:light_gray_concrete
setblock 456 234 363 minecraft:light_gray_concrete
fill 458 234 363 461 234 363 minecraft:light_gray_concrete
setblock 460 234 323 minecraft:light_gray_concrete
fill 464 234 324 464 234 327 minecraft:light_gray_concrete
setblock 464 234 329 minecraft:light_gray_concrete
fill 464 234 334 464 234 337 minecraft:light_gray_concrete
setblock 464 234 339 minecraft:light_gray_concrete
fill 464 234 344 464 234 347 minecraft:light_gray_concrete
setblock 464 234 349 minecraft:light_gray_concrete
fill 464 234 354 464 234 357 minecraft:light_gray_concrete
setblock 464 234 359 minecraft:light_gray_concrete
fill 424 235 358 426 236 358 minecraft:iron_block
fill 423 238 328 423 238 331 minecraft:verdant_froglight
fill 423 238 338 423 238 341 minecraft:verdant_froglight
fill 423 238 348 423 238 351 minecraft:verdant_froglight
fill 423 238 358 423 238 361 minecraft:verdant_froglight
fill 425 238 334 425 238 336 minecraft:light_gray_concrete
fill 426 238 322 429 238 322 minecraft:verdant_froglight
fill 426 238 333 428 238 333 minecraft:light_gray_concrete
fill 426 238 337 428 238 337 minecraft:light_gray_concrete
fill 427 238 364 430 238 364 minecraft:verdant_froglight
fill 429 238 334 429 238 336 minecraft:light_gray_concrete
fill 436 238 322 439 238 322 minecraft:verdant_froglight
fill 436 238 341 436 239 341 minecraft:lime_stained_glass
fill 437 238 364 440 238 364 minecraft:verdant_froglight
fill 446 238 322 449 238 322 minecraft:verdant_froglight
fill 447 238 364 450 238 364 minecraft:verdant_froglight
fill 456 238 322 459 238 322 minecraft:verdant_froglight
fill 457 238 364 460 238 364 minecraft:verdant_froglight
fill 465 238 323 465 238 326 minecraft:verdant_froglight
fill 465 238 333 465 238 336 minecraft:verdant_froglight
fill 465 238 343 465 238 346 minecraft:verdant_froglight
fill 465 238 353 465 238 356 minecraft:verdant_froglight
setblock 465 238 363 minecraft:verdant_froglight
fill 423 239 328 423 246 331 minecraft:white_concrete
fill 423 239 338 423 246 341 minecraft:white_concrete
fill 423 239 348 423 246 351 minecraft:white_concrete
fill 423 239 358 423 246 361 minecraft:white_concrete
fill 426 239 322 429 246 322 minecraft:white_concrete
fill 427 239 364 430 246 364 minecraft:white_concrete
fill 436 239 322 439 246 322 minecraft:white_concrete
fill 437 239 364 440 246 364 minecraft:white_concrete
fill 446 239 322 449 246 322 minecraft:white_concrete
fill 447 239 364 450 246 364 minecraft:white_concrete
fill 456 239 322 459 246 322 minecraft:white_concrete
fill 457 239 364 460 246 364 minecraft:white_concrete
fill 465 239 323 465 246 326 minecraft:white_concrete
fill 465 239 333 465 246 336 minecraft:white_concrete
fill 465 239 343 465 246 346 minecraft:white_concrete
fill 465 239 353 465 246 356 minecraft:white_concrete
fill 465 239 363 465 246 363 minecraft:white_concrete
setblock 424 240 325 minecraft:light_gray_concrete
setblock 424 240 335 minecraft:light_gray_concrete
setblock 424 240 345 minecraft:light_gray_concrete
setblock 424 240 355 minecraft:light_gray_concrete
setblock 426 240 363 minecraft:light_gray_concrete
setblock 430 240 323 minecraft:light_gray_concrete
setblock 436 240 363 minecraft:light_gray_concrete
setblock 440 240 323 minecraft:light_gray_concrete
setblock 446 240 363 minecraft:light_gray_concrete
setblock 450 240 323 minecraft:light_gray_concrete
setblock 456 240 363 minecraft:light_gray_concrete
setblock 460 240 323 minecraft:light_gray_concrete
setblock 464 240 329 minecraft:light_gray_concrete
setblock 464 240 339 minecraft:light_gray_concrete
setblock 464 240 349 minecraft:light_gray_concrete
setblock 464 240 359 minecraft:light_gray_concrete
setblock 426 241 325 minecraft:light[level=14]
setblock 426 241 333 minecraft:light[level=14]
setblock 426 241 341 minecraft:light[level=14]
setblock 426 241 349 minecraft:light[level=14]
setblock 426 241 357 minecraft:light[level=14]
fill 432 241 343 433 242 343 minecraft:lime_stained_glass
setblock 434 241 325 minecraft:light[level=14]
setblock 434 241 333 minecraft:light[level=14]
setblock 434 241 341 minecraft:light[level=14]
setblock 434 241 349 minecraft:light[level=14]
setblock 434 241 357 minecraft:light[level=14]
setblock 442 241 325 minecraft:light[level=14]
setblock 442 241 333 minecraft:light[level=14]
setblock 442 241 341 minecraft:light[level=14]
setblock 442 241 349 minecraft:light[level=14]
setblock 442 241 357 minecraft:light[level=14]
setblock 450 241 325 minecraft:light[level=14]
setblock 450 241 333 minecraft:light[level=14]
setblock 450 241 341 minecraft:light[level=14]
setblock 450 241 349 minecraft:light[level=14]
setblock 450 241 357 minecraft:light[level=14]
setblock 458 241 325 minecraft:light[level=14]
setblock 458 241 333 minecraft:light[level=14]
setblock 458 241 341 minecraft:light[level=14]
setblock 458 241 349 minecraft:light[level=14]
setblock 458 241 357 minecraft:light[level=14]
fill 424 243 327 424 243 330 minecraft:light_gray_concrete
fill 424 243 337 424 243 340 minecraft:light_gray_concrete
fill 424 243 347 424 243 350 minecraft:light_gray_concrete
fill 424 243 357 424 243 360 minecraft:light_gray_concrete
fill 425 243 323 428 243 323 minecraft:light_gray_concrete
fill 428 243 363 431 243 363 minecraft:light_gray_concrete
fill 435 243 323 438 243 323 minecraft:light_gray_concrete
fill 438 243 363 441 243 363 minecraft:light_gray_concrete
fill 445 243 323 448 243 323 minecraft:light_gray_concrete
fill 448 243 363 451 243 363 minecraft:light_gray_concrete
fill 455 243 323 458 243 323 minecraft:light_gray_concrete
fill 458 243 363 461 243 363 minecraft:light_gray_concrete
fill 464 243 324 464 243 327 minecraft:light_gray_concrete
fill 464 243 334 464 243 337 minecraft:light_gray_concrete
fill 464 243 344 464 243 347 minecraft:light_gray_concrete
fill 464 243 354 464 243 357 minecraft:light_gray_concrete
setblock 424 246 325 minecraft:light_gray_concrete
fill 424 246 335 425 246 335 minecraft:light_gray_concrete
fill 424 246 336 424 247 336 minecraft:iron_block
setblock 424 246 345 minecraft:light_gray_concrete
setblock 424 246 355 minecraft:light_gray_concrete
setblock 425 246 334 minecraft:light_gray_concrete
setblock 425 246 336 minecraft:light_gray_concrete
fill 426 246 333 428 246 333 minecraft:light_gray_concrete
fill 426 246 337 428 246 337 minecraft:light_gray_concrete
setblock 426 246 363 minecraft:light_gray_concrete
fill 429 246 334 429 246 336 minecraft:light_gray_concrete
setblock 430 246 323 minecraft:light_gray_concrete
setblock 436 246 363 minecraft:light_gray_concrete
setblock 440 246 323 minecraft:light_gray_concrete
setblock 446 246 363 minecraft:light_gray_concrete
setblock 450 246 323 minecraft:light_gray_concrete
setblock 456 246 363 minecraft:light_gray_concrete
setblock 460 246 323 minecraft:light_gray_concrete
setblock 464 246 329 minecraft:light_gray_concrete
setblock 464 246 339 minecraft:light_gray_concrete
setblock 464 246 349 minecraft:light_gray_concrete
setblock 464 246 359 minecraft:light_gray_concrete
fill 423 247 328 423 247 331 minecraft:verdant_froglight
fill 423 247 338 423 247 341 minecraft:verdant_froglight
fill 423 247 348 423 247 351 minecraft:verdant_froglight
fill 423 247 358 423 247 361 minecraft:verdant_froglight
fill 424 247 335 425 247 335 minecraft:iron_block
setblock 425 247 334 minecraft:iron_block
setblock 425 247 336 minecraft:iron_block
fill 426 247 322 429 247 322 minecraft:verdant_froglight
fill 427 247 364 430 247 364 minecraft:verdant_froglight
setblock 429 247 335 minecraft:verdant_froglight
fill 436 247 322 439 247 322 minecraft:verdant_froglight
fill 437 247 364 440 247 364 minecraft:verdant_froglight
fill 446 247 322 449 247 322 minecraft:verdant_froglight
fill 447 247 364 450 247 364 minecraft:verdant_froglight
fill 456 247 322 459 247 322 minecraft:verdant_froglight
fill 457 247 364 460 247 364 minecraft:verdant_froglight
fill 465 247 323 465 247 326 minecraft:verdant_froglight
fill 465 247 333 465 247 336 minecraft:verdant_froglight
fill 465 247 343 465 247 346 minecraft:verdant_froglight
fill 465 247 353 465 247 356 minecraft:verdant_froglight
setblock 465 247 363 minecraft:verdant_froglight
fill 423 248 328 423 255 331 minecraft:white_concrete
fill 423 248 338 423 255 341 minecraft:white_concrete
fill 423 248 348 423 255 351 minecraft:white_concrete
fill 423 248 358 423 255 361 minecraft:white_concrete
fill 426 248 322 429 255 322 minecraft:white_concrete
fill 427 248 364 430 255 364 minecraft:white_concrete
fill 436 248 322 439 255 322 minecraft:white_concrete
fill 437 248 364 440 255 364 minecraft:white_concrete
fill 446 248 322 449 255 322 minecraft:white_concrete
fill 447 248 364 450 255 364 minecraft:white_concrete
fill 456 248 322 459 255 322 minecraft:white_concrete
fill 457 248 364 460 255 364 minecraft:white_concrete
fill 465 248 323 465 255 326 minecraft:white_concrete
fill 465 248 333 465 255 336 minecraft:white_concrete
fill 465 248 343 465 255 346 minecraft:white_concrete
fill 465 248 353 465 255 356 minecraft:white_concrete
fill 465 248 363 465 255 363 minecraft:white_concrete
setblock 426 249 325 minecraft:light[level=14]
setblock 426 249 333 minecraft:light[level=14]
setblock 426 249 341 minecraft:light[level=14]
setblock 426 249 349 minecraft:light[level=14]
setblock 426 249 357 minecraft:light[level=14]
setblock 434 249 325 minecraft:light[level=14]
setblock 434 249 333 minecraft:light[level=14]
setblock 434 249 341 minecraft:light[level=14]
setblock 434 249 349 minecraft:light[level=14]
setblock 434 249 357 minecraft:light[level=14]
setblock 442 249 325 minecraft:light[level=14]
setblock 442 249 333 minecraft:light[level=14]
setblock 442 249 341 minecraft:light[level=14]
setblock 442 249 349 minecraft:light[level=14]
setblock 442 249 357 minecraft:light[level=14]
setblock 450 249 325 minecraft:light[level=14]
setblock 450 249 333 minecraft:light[level=14]
setblock 450 249 341 minecraft:light[level=14]
setblock 450 249 349 minecraft:light[level=14]
setblock 450 249 357 minecraft:light[level=14]
setblock 458 249 325 minecraft:light[level=14]
setblock 458 249 333 minecraft:light[level=14]
setblock 458 249 341 minecraft:light[level=14]
setblock 458 249 349 minecraft:light[level=14]
setblock 458 249 357 minecraft:light[level=14]
setblock 424 252 325 minecraft:light_gray_concrete
fill 424 252 327 424 252 330 minecraft:light_gray_concrete
setblock 424 252 335 minecraft:light_gray_concrete
fill 424 252 337 424 252 340 minecraft:light_gray_concrete
setblock 424 252 345 minecraft:light_gray_concrete
fill 424 252 347 424 252 350 minecraft:light_gray_concrete
setblock 424 252 355 minecraft:light_gray_concrete
fill 424 252 357 424 252 360 minecraft:light_gray_concrete
fill 425 252 323 428 252 323 minecraft:light_gray_concrete
setblock 426 252 363 minecraft:light_gray_concrete
fill 428 252 363 431 252 363 minecraft:light_gray_concrete
setblock 430 252 323 minecraft:light_gray_concrete
fill 435 252 323 438 252 323 minecraft:light_gray_concrete
setblock 436 252 363 minecraft:light_gray_concrete
fill 438 252 363 441 252 363 minecraft:light_gray_concrete
setblock 440 252 323 minecraft:light_gray_concrete
fill 445 252 323 448 252 323 minecraft:light_gray_concrete
setblock 446 252 363 minecraft:light_gray_concrete
fill 448 252 363 451 252 363 minecraft:light_gray_concrete
setblock 450 252 323 minecraft:light_gray_concrete
fill 455 252 323 458 252 323 minecraft:light_gray_concrete
setblock 456 252 363 minecraft:light_gray_concrete
fill 458 252 363 461 252 363 minecraft:light_gray_concrete
setblock 460 252 323 minecraft:light_gray_concrete
fill 464 252 324 464 252 327 minecraft:light_gray_concrete
setblock 464 252 329 minecraft:light_gray_concrete
fill 464 252 334 464 252 337 minecraft:light_gray_concrete
setblock 464 252 339 minecraft:light_gray_concrete
fill 464 252 344 464 252 347 minecraft:light_gray_concrete
setblock 464 252 349 minecraft:light_gray_concrete
fill 464 252 354 464 252 357 minecraft:light_gray_concrete
setblock 464 252 359 minecraft:light_gray_concrete
fill 425 254 334 425 254 336 minecraft:light_gray_concrete
fill 426 254 333 428 254 333 minecraft:light_gray_concrete
fill 426 254 337 428 254 337 minecraft:light_gray_concrete
fill 429 254 334 429 254 336 minecraft:light_gray_concrete
fill 423 256 328 423 256 331 minecraft:verdant_froglight
fill 423 256 338 423 256 341 minecraft:verdant_froglight
fill 423 256 348 423 256 351 minecraft:verdant_froglight
fill 423 256 358 423 256 361 minecraft:verdant_froglight
fill 426 256 322 429 256 322 minecraft:verdant_froglight
fill 427 256 364 430 256 364 minecraft:verdant_froglight
fill 436 256 322 439 256 322 minecraft:verdant_froglight
fill 437 256 364 440 256 364 minecraft:verdant_froglight
fill 446 256 322 449 256 322 minecraft:verdant_froglight
fill 447 256 364 450 256 364 minecraft:verdant_froglight
fill 456 256 322 459 256 322 minecraft:verdant_froglight
fill 457 256 364 460 256 364 minecraft:verdant_froglight
fill 465 256 323 465 256 326 minecraft:verdant_froglight
fill 465 256 333 465 256 336 minecraft:verdant_froglight
fill 465 256 343 465 256 346 minecraft:verdant_froglight
fill 465 256 353 465 256 356 minecraft:verdant_froglight
setblock 465 256 363 minecraft:verdant_froglight
fill 423 257 328 423 264 331 minecraft:white_concrete
fill 423 257 338 423 264 341 minecraft:white_concrete
fill 423 257 348 423 264 351 minecraft:white_concrete
fill 423 257 358 423 264 361 minecraft:white_concrete
fill 426 257 322 429 264 322 minecraft:white_concrete
setblock 426 257 325 minecraft:light[level=14]
setblock 426 257 333 minecraft:light[level=14]
setblock 426 257 341 minecraft:light[level=14]
setblock 426 257 349 minecraft:light[level=14]
setblock 426 257 357 minecraft:light[level=14]
fill 427 257 364 430 264 364 minecraft:white_concrete
setblock 434 257 325 minecraft:light[level=14]
setblock 434 257 333 minecraft:light[level=14]
setblock 434 257 341 minecraft:light[level=14]
setblock 434 257 349 minecraft:light[level=14]
setblock 434 257 357 minecraft:light[level=14]
fill 436 257 322 439 264 322 minecraft:white_concrete
fill 437 257 364 440 264 364 minecraft:white_concrete
setblock 442 257 325 minecraft:light[level=14]
setblock 442 257 333 minecraft:light[level=14]
setblock 442 257 341 minecraft:light[level=14]
setblock 442 257 349 minecraft:light[level=14]
setblock 442 257 357 minecraft:light[level=14]
fill 446 257 322 449 264 322 minecraft:white_concrete
fill 447 257 364 450 264 364 minecraft:white_concrete
setblock 450 257 325 minecraft:light[level=14]
setblock 450 257 333 minecraft:light[level=14]
setblock 450 257 341 minecraft:light[level=14]
setblock 450 257 349 minecraft:light[level=14]
setblock 450 257 357 minecraft:light[level=14]
fill 456 257 322 459 264 322 minecraft:white_concrete
fill 457 257 364 460 264 364 minecraft:white_concrete
setblock 458 257 325 minecraft:light[level=14]
setblock 458 257 333 minecraft:light[level=14]
setblock 458 257 341 minecraft:light[level=14]
setblock 458 257 349 minecraft:light[level=14]
setblock 458 257 357 minecraft:light[level=14]
fill 465 257 323 465 264 326 minecraft:white_concrete
fill 465 257 333 465 264 336 minecraft:white_concrete
fill 465 257 343 465 264 346 minecraft:white_concrete
fill 465 257 353 465 264 356 minecraft:white_concrete
fill 465 257 363 465 264 363 minecraft:white_concrete
setblock 424 258 325 minecraft:light_gray_concrete
setblock 424 258 335 minecraft:light_gray_concrete
setblock 424 258 345 minecraft:light_gray_concrete
setblock 424 258 355 minecraft:light_gray_concrete
setblock 426 258 363 minecraft:light_gray_concrete
setblock 430 258 323 minecraft:light_gray_concrete
setblock 436 258 363 minecraft:light_gray_concrete
setblock 440 258 323 minecraft:light_gray_concrete
setblock 446 258 363 minecraft:light_gray_concrete
setblock 450 258 323 minecraft:light_gray_concrete
setblock 456 258 363 minecraft:light_gray_concrete
setblock 460 258 323 minecraft:light_gray_concrete
fill 461 258 352 463 259 352 minecraft:iron_block
setblock 464 258 329 minecraft:light_gray_concrete
setblock 464 258 339 minecraft:light_gray_concrete
setblock 464 258 349 minecraft:light_gray_concrete
setblock 464 258 359 minecraft:light_gray_concrete
fill 424 261 327 424 261 330 minecraft:light_gray_concrete
fill 424 261 337 424 261 340 minecraft:light_gray_concrete
fill 424 261 347 424 261 350 minecraft:light_gray_concrete
fill 424 261 357 424 261 360 minecraft:light_gray_concrete
fill 425 261 323 428 261 323 minecraft:light_gray_concrete
fill 428 261 363 431 261 363 minecraft:light_gray_concrete
fill 435 261 323 438 261 323 minecraft:light_gray_concrete
fill 438 261 363 441 261 363 minecraft:light_gray_concrete
fill 445 261 323 448 261 323 minecraft:light_gray_concrete
fill 448 261 363 451 261 363 minecraft:light_gray_concrete
fill 455 261 323 458 261 323 minecraft:light_gray_concrete
fill 458 261 363 461 261 363 minecraft:light_gray_concrete
fill 464 261 324 464 261 327 minecraft:light_gray_concrete
fill 464 261 334 464 261 337 minecraft:light_gray_concrete
fill 464 261 344 464 261 347 minecraft:light_gray_concrete
fill 464 261 354 464 261 357 minecraft:light_gray_concrete
fill 425 262 334 425 262 336 minecraft:light_gray_concrete
fill 426 262 333 428 262 333 minecraft:light_gray_concrete
fill 426 262 337 428 262 337 minecraft:light_gray_concrete
fill 429 262 334 429 262 336 minecraft:light_gray_concrete
setblock 424 264 325 minecraft:light_gray_concrete
setblock 424 264 335 minecraft:light_gray_concrete
setblock 424 264 345 minecraft:light_gray_concrete
setblock 424 264 355 minecraft:light_gray_concrete
setblock 426 264 363 minecraft:light_gray_concrete
setblock 430 264 323 minecraft:light_gray_concrete
setblock 436 264 363 minecraft:light_gray_concrete
setblock 440 264 323 minecraft:light_gray_concrete
setblock 446 264 363 minecraft:light_gray_concrete
setblock 450 264 323 minecraft:light_gray_concrete
setblock 456 264 363 minecraft:light_gray_concrete
setblock 460 264 323 minecraft:light_gray_concrete
setblock 464 264 329 minecraft:light_gray_concrete
setblock 464 264 339 minecraft:light_gray_concrete
setblock 464 264 349 minecraft:light_gray_concrete
setblock 464 264 359 minecraft:light_gray_concrete
fill 423 265 328 423 265 331 minecraft:verdant_froglight
fill 423 265 338 423 265 341 minecraft:verdant_froglight
fill 423 265 348 423 265 351 minecraft:verdant_froglight
fill 423 265 358 423 265 361 minecraft:verdant_froglight
fill 426 265 322 429 265 322 minecraft:verdant_froglight
setblock 426 265 325 minecraft:light[level=14]
setblock 426 265 333 minecraft:light[level=14]
setblock 426 265 341 minecraft:light[level=14]
setblock 426 265 349 minecraft:light[level=14]
setblock 426 265 357 minecraft:light[level=14]
fill 427 265 364 430 265 364 minecraft:verdant_froglight
setblock 434 265 325 minecraft:light[level=14]
setblock 434 265 333 minecraft:light[level=14]
setblock 434 265 341 minecraft:light[level=14]
setblock 434 265 349 minecraft:light[level=14]
setblock 434 265 357 minecraft:light[level=14]
fill 436 265 322 439 265 322 minecraft:verdant_froglight
fill 437 265 364 440 265 364 minecraft:verdant_froglight
setblock 442 265 325 minecraft:light[level=14]
setblock 442 265 333 minecraft:light[level=14]
setblock 442 265 341 minecraft:light[level=14]
setblock 442 265 349 minecraft:light[level=14]
setblock 442 265 357 minecraft:light[level=14]
fill 446 265 322 449 265 322 minecraft:verdant_froglight
fill 447 265 364 450 265 364 minecraft:verdant_froglight
setblock 450 265 325 minecraft:light[level=14]
setblock 450 265 333 minecraft:light[level=14]
setblock 450 265 341 minecraft:light[level=14]
setblock 450 265 349 minecraft:light[level=14]
setblock 450 265 357 minecraft:light[level=14]
fill 456 265 322 459 265 322 minecraft:verdant_froglight
fill 457 265 364 460 265 364 minecraft:verdant_froglight
setblock 458 265 325 minecraft:light[level=14]
setblock 458 265 333 minecraft:light[level=14]
setblock 458 265 341 minecraft:light[level=14]
setblock 458 265 349 minecraft:light[level=14]
setblock 458 265 357 minecraft:light[level=14]
fill 465 265 323 465 265 326 minecraft:verdant_froglight
fill 465 265 333 465 265 336 minecraft:verdant_froglight
fill 465 265 343 465 265 346 minecraft:verdant_froglight
fill 465 265 353 465 265 356 minecraft:verdant_froglight
setblock 465 265 363 minecraft:verdant_froglight
fill 423 266 328 423 282 331 minecraft:white_concrete
fill 423 266 338 423 282 341 minecraft:white_concrete
fill 423 266 348 423 282 351 minecraft:white_concrete
fill 423 266 358 423 282 361 minecraft:white_concrete
fill 426 266 322 429 282 322 minecraft:white_concrete
fill 427 266 364 430 282 364 minecraft:white_concrete
fill 436 266 322 439 282 322 minecraft:white_concrete
fill 437 266 364 440 282 364 minecraft:white_concrete
fill 446 266 322 449 282 322 minecraft:white_concrete
fill 447 266 364 450 282 364 minecraft:white_concrete
fill 456 266 322 459 282 322 minecraft:white_concrete
fill 457 266 364 460 282 364 minecraft:white_concrete
fill 465 266 323 465 282 326 minecraft:white_concrete
fill 465 266 333 465 282 336 minecraft:white_concrete
fill 465 266 343 465 282 346 minecraft:white_concrete
fill 465 266 353 465 282 356 minecraft:white_concrete
fill 465 266 363 465 282 363 minecraft:white_concrete
fill 448 269 327 449 270 328 minecraft:lime_concrete
setblock 424 270 325 minecraft:light_gray_concrete
fill 424 270 327 424 270 330 minecraft:light_gray_concrete
fill 424 270 335 425 270 335 minecraft:light_gray_concrete
fill 424 270 337 424 270 340 minecraft:light_gray_concrete
setblock 424 270 345 minecraft:light_gray_concrete
fill 424 270 347 424 270 350 minecraft:light_gray_concrete
setblock 424 270 355 minecraft:light_gray_concrete
fill 424 270 357 424 270 360 minecraft:light_gray_concrete
fill 425 270 323 428 270 323 minecraft:light_gray_concrete
setblock 425 270 334 minecraft:light_gray_concrete
setblock 425 270 336 minecraft:light_gray_concrete
fill 426 270 333 428 270 333 minecraft:light_gray_concrete
fill 426 270 337 428 270 337 minecraft:light_gray_concrete
setblock 426 270 363 minecraft:light_gray_concrete
fill 428 270 363 431 270 363 minecraft:light_gray_concrete
fill 429 270 334 429 270 336 minecraft:light_gray_concrete
setblock 430 270 323 minecraft:light_gray_concrete
fill 435 270 323 438 270 323 minecraft:light_gray_concrete
setblock 436 270 363 minecraft:light_gray_concrete
fill 438 270 363 441 270 363 minecraft:light_gray_concrete
setblock 440 270 323 minecraft:light_gray_concrete
fill 445 270 323 448 270 323 minecraft:light_gray_concrete
setblock 446 270 363 minecraft:light_gray_concrete
fill 448 270 363 451 270 363 minecraft:light_gray_concrete
setblock 450 270 323 minecraft:light_gray_concrete
fill 455 270 323 458 270 323 minecraft:light_gray_concrete
setblock 456 270 363 minecraft:light_gray_concrete
fill 458 270 363 461 270 363 minecraft:light_gray_concrete
setblock 460 270 323 minecraft:light_gray_concrete
fill 464 270 324 464 270 327 minecraft:light_gray_concrete
setblock 464 270 329 minecraft:light_gray_concrete
fill 464 270 334 464 270 337 minecraft:light_gray_concrete
setblock 464 270 339 minecraft:light_gray_concrete
fill 464 270 344 464 270 347 minecraft:light_gray_concrete
setblock 464 270 349 minecraft:light_gray_concrete
fill 464 270 354 464 270 357 minecraft:light_gray_concrete
setblock 464 270 359 minecraft:light_gray_concrete
setblock 426 273 325 minecraft:light[level=14]
setblock 426 273 333 minecraft:light[level=14]
setblock 426 273 341 minecraft:light[level=14]
setblock 426 273 349 minecraft:light[level=14]
setblock 426 273 357 minecraft:light[level=14]
setblock 434 273 325 minecraft:light[level=14]
setblock 434 273 333 minecraft:light[level=14]
setblock 434 273 341 minecraft:light[level=14]
setblock 434 273 349 minecraft:light[level=14]
setblock 434 273 357 minecraft:light[level=14]
setblock 442 273 325 minecraft:light[level=14]
setblock 442 273 333 minecraft:light[level=14]
setblock 442 273 341 minecraft:light[level=14]
setblock 442 273 349 minecraft:light[level=14]
setblock 442 273 357 minecraft:light[level=14]
setblock 450 273 325 minecraft:light[level=14]
setblock 450 273 333 minecraft:light[level=14]
setblock 450 273 341 minecraft:light[level=14]
setblock 450 273 349 minecraft:light[level=14]
setblock 450 273 357 minecraft:light[level=14]
setblock 458 273 325 minecraft:light[level=14]
setblock 458 273 333 minecraft:light[level=14]
setblock 458 273 341 minecraft:light[level=14]
setblock 458 273 349 minecraft:light[level=14]
setblock 458 273 357 minecraft:light[level=14]
fill 424 278 323 424 279 325 minecraft:white_concrete
fill 424 278 326 424 279 328 minecraft:yellow_concrete
fill 424 278 329 424 279 331 minecraft:white_concrete
fill 424 278 332 424 279 334 minecraft:yellow_concrete
fill 424 278 335 424 279 337 minecraft:white_concrete
fill 424 278 338 424 279 340 minecraft:yellow_concrete
fill 424 278 341 424 279 343 minecraft:white_concrete
fill 424 278 344 424 279 346 minecraft:yellow_concrete
fill 424 278 347 424 279 349 minecraft:white_concrete
fill 424 278 350 424 279 352 minecraft:yellow_concrete
fill 424 278 353 424 279 355 minecraft:white_concrete
fill 424 278 356 424 279 358 minecraft:yellow_concrete
fill 424 278 359 424 279 361 minecraft:white_concrete
fill 424 278 362 425 279 363 minecraft:yellow_concrete
fill 425 278 323 425 279 324 minecraft:white_concrete
fill 425 278 325 425 279 327 minecraft:yellow_concrete
fill 425 278 328 425 279 330 minecraft:white_concrete
fill 425 278 331 425 279 333 minecraft:yellow_concrete
fill 425 278 334 425 279 336 minecraft:white_concrete
fill 425 278 337 425 279 339 minecraft:yellow_concrete
fill 425 278 340 425 279 342 minecraft:white_concrete
fill 425 278 343 425 279 345 minecraft:yellow_concrete
fill 425 278 346 425 279 348 minecraft:white_concrete
fill 425 278 349 425 279 351 minecraft:yellow_concrete
fill 425 278 352 425 279 354 minecraft:white_concrete
fill 425 278 355 425 279 357 minecraft:yellow_concrete
fill 425 278 358 425 279 360 minecraft:white_concrete
fill 425 278 361 427 279 361 minecraft:yellow_concrete
fill 426 278 323 426 279 323 minecraft:white_concrete
fill 426 278 324 426 279 326 minecraft:yellow_concrete
fill 426 278 327 426 279 329 minecraft:white_concrete
fill 426 278 330 426 279 332 minecraft:yellow_concrete
fill 426 278 333 426 279 335 minecraft:white_concrete
fill 426 278 336 426 279 338 minecraft:yellow_concrete
fill 426 278 339 426 279 341 minecraft:white_concrete
fill 426 278 342 426 279 344 minecraft:yellow_concrete
fill 426 278 345 426 279 347 minecraft:white_concrete
fill 426 278 348 426 279 350 minecraft:yellow_concrete
fill 426 278 351 426 279 353 minecraft:white_concrete
fill 426 278 354 426 279 356 minecraft:yellow_concrete
fill 426 278 357 426 279 359 minecraft:white_concrete
fill 426 278 360 428 279 360 minecraft:yellow_concrete
fill 426 278 362 426 279 362 minecraft:yellow_concrete
fill 426 278 363 428 279 363 minecraft:white_concrete
fill 427 278 323 427 279 325 minecraft:yellow_concrete
fill 427 278 326 427 279 328 minecraft:white_concrete
fill 427 278 329 427 279 331 minecraft:yellow_concrete
fill 427 278 332 427 279 334 minecraft:white_concrete
fill 427 278 335 427 279 337 minecraft:yellow_concrete
fill 427 278 338 427 279 340 minecraft:white_concrete
fill 427 278 341 427 279 343 minecraft:yellow_concrete
fill 427 278 344 427 279 346 minecraft:white_concrete
fill 427 278 347 427 279 349 minecraft:yellow_concrete
fill 427 278 350 427 279 352 minecraft:white_concrete
fill 427 278 353 427 279 355 minecraft:yellow_concrete
fill 427 278 356 427 279 358 minecraft:white_concrete
fill 427 278 359 429 279 359 minecraft:yellow_concrete
fill 427 278 362 429 279 362 minecraft:white_concrete
fill 428 278 323 428 279 324 minecraft:yellow_concrete
fill 428 278 325 428 279 327 minecraft:white_concrete
fill 428 278 328 428 279 330 minecraft:yellow_concrete
fill 428 278 331 428 279 333 minecraft:white_concrete
fill 428 278 334 428 279 336 minecraft:yellow_concrete
fill 428 278 337 428 279 339 minecraft:white_concrete
fill 428 278 340 428 279 342 minecraft:yellow_concrete
fill 428 278 343 428 279 345 minecraft:white_concrete
fill 428 278 346 428 279 348 minecraft:yellow_concrete
fill 428 278 349 428 279 351 minecraft:white_concrete
fill 428 278 352 428 279 354 minecraft:yellow_concrete
fill 428 278 355 428 279 357 minecraft:white_concrete
fill 428 278 358 430 279 358 minecraft:yellow_concrete
fill 428 278 361 430 279 361 minecraft:white_concrete
fill 429 278 323 429 279 323 minecraft:yellow_concrete
fill 429 278 324 429 279 326 minecraft:white_concrete
fill 429 278 327 429 279 329 minecraft:yellow_concrete
fill 429 278 330 429 279 332 minecraft:white_concrete
fill 429 278 333 429 279 335 minecraft:yellow_concrete
fill 429 278 336 429 279 338 minecraft:white_concrete
fill 429 278 339 429 279 341 minecraft:yellow_concrete
fill 429 278 342 429 279 344 minecraft:white_concrete
fill 429 278 345 429 279 347 minecraft:yellow_concrete
fill 429 278 348 429 279 350 minecraft:white_concrete
fill 429 278 351 429 279 353 minecraft:yellow_concrete
fill 429 278 354 429 279 356 minecraft:white_concrete
fill 429 278 357 431 279 357 minecraft:yellow_concrete
fill 429 278 360 431 279 360 minecraft:white_concrete
fill 429 278 363 431 279 363 minecraft:yellow_concrete
fill 430 278 323 430 279 325 minecraft:white_concrete
fill 430 278 326 430 279 328 minecraft:yellow_concrete
fill 430 278 329 430 279 331 minecraft:white_concrete
fill 430 278 332 430 279 334 minecraft:yellow_concrete
fill 430 278 335 430 279 337 minecraft:white_concrete
fill 430 278 338 430 279 340 minecraft:yellow_concrete
fill 430 278 341 430 279 343 minecraft:white_concrete
fill 430 278 344 430 279 346 minecraft:yellow_concrete
fill 430 278 347 430 279 349 minecraft:white_concrete
fill 430 278 350 430 279 352 minecraft:yellow_concrete
fill 430 278 353 430 279 355 minecraft:white_concrete
fill 430 278 356 432 279 356 minecraft:yellow_concrete
fill 430 278 359 432 279 359 minecraft:white_concrete
fill 430 278 362 432 279 362 minecraft:yellow_concrete
fill 431 278 323 431 279 324 minecraft:white_concrete
fill 431 278 325 431 279 327 minecraft:yellow_concrete
fill 431 278 328 431 279 330 minecraft:white_concrete
fill 431 278 331 431 279 333 minecraft:yellow_concrete
fill 431 278 334 431 279 336 minecraft:white_concrete
fill 431 278 337 431 279 339 minecraft:yellow_concrete
fill 431 278 340 431 279 342 minecraft:white_concrete
fill 431 278 343 431 279 345 minecraft:yellow_concrete
fill 431 278 346 431 279 348 minecraft:white_concrete
fill 431 278 349 431 279 351 minecraft:yellow_concrete
fill 431 278 352 431 279 354 minecraft:white_concrete
fill 431 278 355 433 279 355 minecraft:yellow_concrete
fill 431 278 358 433 279 358 minecraft:white_concrete
fill 431 278 361 433 279 361 minecraft:yellow_concrete
fill 432 278 323 432 279 323 minecraft:white_concrete
fill 432 278 324 432 279 326 minecraft:yellow_concrete
fill 432 278 327 432 279 329 minecraft:white_concrete
fill 432 278 330 432 279 332 minecraft:yellow_concrete
fill 432 278 333 432 279 335 minecraft:white_concrete
fill 432 278 336 432 279 338 minecraft:yellow_concrete
fill 432 278 339 432 279 341 minecraft:white_concrete
fill 432 278 342 432 279 344 minecraft:yellow_concrete
fill 432 278 345 432 279 347 minecraft:white_concrete
fill 432 278 348 432 279 350 minecraft:yellow_concrete
fill 432 278 351 432 279 353 minecraft:white_concrete
fill 432 278 354 434 279 354 minecraft:yellow_concrete
fill 432 278 357 434 279 357 minecraft:white_concrete
fill 432 278 360 434 279 360 minecraft:yellow_concrete
fill 432 278 363 434 279 363 minecraft:white_concrete
fill 433 278 323 433 279 325 minecraft:yellow_concrete
fill 433 278 326 433 279 328 minecraft:white_concrete
fill 433 278 329 433 279 331 minecraft:yellow_concrete
fill 433 278 332 433 279 334 minecraft:white_concrete
fill 433 278 335 433 279 337 minecraft:yellow_concrete
fill 433 278 338 433 279 340 minecraft:white_concrete
fill 433 278 341 433 279 343 minecraft:yellow_concrete
fill 433 278 344 433 279 346 minecraft:white_concrete
fill 433 278 347 433 279 349 minecraft:yellow_concrete
fill 433 278 350 433 279 352 minecraft:white_concrete
fill 433 278 353 435 279 353 minecraft:yellow_concrete
fill 433 278 356 435 279 356 minecraft:white_concrete
fill 433 278 359 435 279 359 minecraft:yellow_concrete
fill 433 278 362 435 279 362 minecraft:white_concrete
fill 434 278 323 434 279 324 minecraft:yellow_concrete
fill 434 278 325 434 279 327 minecraft:white_concrete
fill 434 278 328 434 279 330 minecraft:yellow_concrete
fill 434 278 331 434 279 333 minecraft:white_concrete
fill 434 278 334 434 279 336 minecraft:yellow_concrete
fill 434 278 337 434 279 339 minecraft:white_concrete
fill 434 278 340 434 279 342 minecraft:yellow_concrete
fill 434 278 343 434 279 345 minecraft:white_concrete
fill 434 278 346 434 279 348 minecraft:yellow_concrete
fill 434 278 349 434 279 351 minecraft:white_concrete
fill 434 278 352 436 279 352 minecraft:yellow_concrete
fill 434 278 355 436 279 355 minecraft:white_concrete
fill 434 278 358 436 279 358 minecraft:yellow_concrete
fill 434 278 361 436 279 361 minecraft:white_concrete
fill 435 278 323 435 279 323 minecraft:yellow_concrete
fill 435 278 324 435 279 326 minecraft:white_concrete
fill 435 278 327 435 279 329 minecraft:yellow_concrete
fill 435 278 330 435 279 332 minecraft:white_concrete
fill 435 278 333 435 279 335 minecraft:yellow_concrete
fill 435 278 336 435 279 338 minecraft:white_concrete
fill 435 278 339 435 279 341 minecraft:yellow_concrete
fill 435 278 342 435 279 344 minecraft:white_concrete
fill 435 278 345 435 279 347 minecraft:yellow_concrete
fill 435 278 348 435 279 350 minecraft:white_concrete
fill 435 278 351 437 279 351 minecraft:yellow_concrete
fill 435 278 354 437 279 354 minecraft:white_concrete
fill 435 278 357 437 279 357 minecraft:yellow_concrete
fill 435 278 360 437 279 360 minecraft:white_concrete
fill 435 278 363 437 279 363 minecraft:yellow_concrete
fill 436 278 323 436 279 325 minecraft:white_concrete
fill 436 278 326 436 279 328 minecraft:yellow_concrete
fill 436 278 329 436 279 331 minecraft:white_concrete
fill 436 278 332 436 279 334 minecraft:yellow_concrete
fill 436 278 335 436 279 337 minecraft:white_concrete
fill 436 278 338 436 279 340 minecraft:yellow_concrete
fill 436 278 341 436 279 343 minecraft:white_concrete
fill 436 278 344 436 279 346 minecraft:yellow_concrete
fill 436 278 347 436 279 349 minecraft:white_concrete
fill 436 278 350 438 279 350 minecraft:yellow_concrete
fill 436 278 353 438 279 353 minecraft:white_concrete
fill 436 278 356 438 279 356 minecraft:yellow_concrete
fill 436 278 359 438 279 359 minecraft:white_concrete
fill 436 278 362 438 279 362 minecraft:yellow_concrete
fill 437 278 323 437 279 324 minecraft:white_concrete
fill 437 278 325 437 279 327 minecraft:yellow_concrete
fill 437 278 328 437 279 330 minecraft:white_concrete
fill 437 278 331 437 279 333 minecraft:yellow_concrete
fill 437 278 334 437 279 336 minecraft:white_concrete
fill 437 278 337 437 279 339 minecraft:yellow_concrete
fill 437 278 340 437 279 342 minecraft:white_concrete
fill 437 278 343 437 279 345 minecraft:yellow_concrete
fill 437 278 346 437 279 348 minecraft:white_concrete
fill 437 278 349 439 279 349 minecraft:yellow_concrete
fill 437 278 352 439 279 352 minecraft:white_concrete
fill 437 278 355 439 279 355 minecraft:yellow_concrete
fill 437 278 358 439 279 358 minecraft:white_concrete
fill 437 278 361 439 279 361 minecraft:yellow_concrete
fill 438 278 323 438 279 323 minecraft:white_concrete
fill 438 278 324 438 279 326 minecraft:yellow_concrete
fill 438 278 327 438 279 329 minecraft:white_concrete
fill 438 278 330 438 279 332 minecraft:yellow_concrete
fill 438 278 333 438 279 335 minecraft:white_concrete
fill 438 278 336 438 279 338 minecraft:yellow_concrete
fill 438 278 339 438 279 341 minecraft:white_concrete
fill 438 278 342 438 278 344 minecraft:yellow_concrete
fill 438 278 345 438 279 347 minecraft:white_concrete
fill 438 278 348 440 279 348 minecraft:yellow_concrete
fill 438 278 351 440 279 351 minecraft:white_concrete
fill 438 278 354 440 279 354 minecraft:yellow_concrete
fill 438 278 357 440 279 357 minecraft:white_concrete
fill 438 278 360 440 279 360 minecraft:yellow_concrete
fill 438 278 363 440 279 363 minecraft:white_concrete
fill 439 278 323 439 279 325 minecraft:yellow_concrete
fill 439 278 326 439 279 328 minecraft:white_concrete
fill 439 278 329 439 279 331 minecraft:yellow_concrete
fill 439 278 332 439 279 334 minecraft:white_concrete
fill 439 278 335 439 279 337 minecraft:yellow_concrete
fill 439 278 338 439 278 340 minecraft:white_concrete
fill 439 278 341 439 278 342 minecraft:yellow_concrete
fill 439 278 344 439 278 346 minecraft:white_concrete
fill 439 278 347 441 278 347 minecraft:yellow_concrete
fill 439 278 350 441 279 350 minecraft:white_concrete
fill 439 278 353 441 279 353 minecraft:yellow_concrete
fill 439 278 356 441 279 356 minecraft:white_concrete
fill 439 278 359 441 279 359 minecraft:yellow_concrete
fill 439 278 362 441 279 362 minecraft:white_concrete
fill 440 278 323 440 279 324 minecraft:yellow_concrete
fill 440 278 325 440 279 327 minecraft:white_concrete
fill 440 278 328 440 279 330 minecraft:yellow_concrete
fill 440 278 331 440 279 333 minecraft:white_concrete
fill 440 278 334 440 279 336 minecraft:yellow_concrete
fill 440 278 337 440 279 339 minecraft:white_concrete
fill 440 278 340 441 278 340 minecraft:yellow_concrete
fill 440 278 346 441 278 346 minecraft:yellow_concrete
fill 440 278 349 442 279 349 minecraft:white_concrete
fill 440 278 352 442 279 352 minecraft:yellow_concrete
fill 440 278 355 442 279 355 minecraft:white_concrete
fill 440 278 358 442 279 358 minecraft:yellow_concrete
fill 440 278 361 442 279 361 minecraft:white_concrete
fill 441 278 323 441 279 323 minecraft:yellow_concrete
fill 441 278 324 441 279 326 minecraft:white_concrete
fill 441 278 327 441 279 329 minecraft:yellow_concrete
fill 441 278 330 441 279 332 minecraft:white_concrete
fill 441 278 333 441 279 335 minecraft:yellow_concrete
fill 441 278 336 441 279 338 minecraft:white_concrete
fill 441 278 339 443 278 339 minecraft:yellow_concrete
fill 441 278 348 443 279 348 minecraft:white_concrete
fill 441 278 351 443 279 351 minecraft:yellow_concrete
fill 441 278 354 443 279 354 minecraft:white_concrete
fill 441 278 357 443 279 357 minecraft:yellow_concrete
fill 441 278 360 443 279 360 minecraft:white_concrete
fill 441 278 363 443 279 363 minecraft:yellow_concrete
fill 442 278 323 442 279 325 minecraft:white_concrete
fill 442 278 326 442 279 328 minecraft:yellow_concrete
fill 442 278 329 442 279 331 minecraft:white_concrete
fill 442 278 332 442 279 334 minecraft:yellow_concrete
fill 442 278 335 442 279 337 minecraft:white_concrete
fill 442 278 338 444 279 338 minecraft:yellow_concrete
fill 442 278 347 444 278 347 minecraft:white_concrete
fill 442 278 350 444 279 350 minecraft:yellow_concrete
fill 442 278 353 444 279 353 minecraft:white_concrete
fill 442 278 356 444 279 356 minecraft:yellow_concrete
fill 442 278 359 444 279 359 minecraft:white_concrete
fill 442 278 362 444 279 362 minecraft:yellow_concrete
fill 443 278 323 443 279 324 minecraft:white_concrete
fill 443 278 325 443 279 327 minecraft:yellow_concrete
fill 443 278 328 443 279 330 minecraft:white_concrete
fill 443 278 331 443 279 333 minecraft:yellow_concrete
fill 443 278 334 443 279 336 minecraft:white_concrete
fill 443 278 337 445 279 337 minecraft:yellow_concrete
fill 443 278 340 445 278 340 minecraft:white_concrete
fill 443 278 346 445 278 346 minecraft:white_concrete
fill 443 278 349 445 279 349 minecraft:yellow_concrete
fill 443 278 352 445 279 352 minecraft:white_concrete
fill 443 278 355 445 279 355 minecraft:yellow_concrete
fill 443 278 358 445 279 358 minecraft:white_concrete
fill 443 278 361 445 279 361 minecraft:yellow_concrete
fill 444 278 323 444 279 323 minecraft:white_concrete
fill 444 278 324 444 279 326 minecraft:yellow_concrete
fill 444 278 327 444 279 329 minecraft:white_concrete
fill 444 278 330 444 279 332 minecraft:yellow_concrete
fill 444 278 333 444 279 335 minecraft:white_concrete
fill 444 278 336 446 279 336 minecraft:yellow_concrete
fill 444 278 339 446 279 339 minecraft:white_concrete
fill 444 278 348 446 279 348 minecraft:yellow_concrete
fill 444 278 351 446 279 351 minecraft:white_concrete
fill 444 278 354 446 279 354 minecraft:yellow_concrete
fill 444 278 357 446 279 357 minecraft:white_concrete
fill 444 278 360 446 279 360 minecraft:yellow_concrete
fill 444 278 363 446 279 363 minecraft:white_concrete
fill 445 278 323 445 279 325 minecraft:yellow_concrete
fill 445 278 326 445 279 328 minecraft:white_concrete
fill 445 278 329 445 279 331 minecraft:yellow_concrete
fill 445 278 332 445 279 334 minecraft:white_concrete
fill 445 278 335 447 279 335 minecraft:yellow_concrete
fill 445 278 338 447 279 338 minecraft:white_concrete
fill 445 278 341 446 278 342 minecraft:yellow_concrete
fill 445 278 344 446 278 345 minecraft:white_concrete
fill 445 278 347 447 279 347 minecraft:yellow_concrete
fill 445 278 350 447 279 350 minecraft:white_concrete
fill 445 278 353 447 279 353 minecraft:yellow_concrete
fill 445 278 356 447 279 356 minecraft:white_concrete
fill 445 278 359 447 279 359 minecraft:yellow_concrete
fill 445 278 362 447 279 362 minecraft:white_concrete
fill 446 278 323 446 279 324 minecraft:yellow_concrete
fill 446 278 325 446 279 327 minecraft:white_concrete
fill 446 278 328 446 279 330 minecraft:yellow_concrete
fill 446 278 331 446 279 333 minecraft:white_concrete
fill 446 278 334 448 279 334 minecraft:yellow_concrete
fill 446 278 337 448 279 337 minecraft:white_concrete
fill 446 278 340 448 279 340 minecraft:yellow_concrete
fill 446 278 343 448 278 343 minecraft:white_concrete
fill 446 278 346 448 279 346 minecraft:yellow_concrete
fill 446 278 349 448 279 349 minecraft:white_concrete
fill 446 278 352 448 279 352 minecraft:yellow_concrete
fill 446 278 355 448 279 355 minecraft:white_concrete
fill 446 278 358 448 279 358 minecraft:yellow_concrete
fill 446 278 361 448 279 361 minecraft:white_concrete
fill 447 278 323 447 279 323 minecraft:yellow_concrete
fill 447 278 324 447 279 326 minecraft:white_concrete
fill 447 278 327 447 279 329 minecraft:yellow_concrete
fill 447 278 330 447 279 332 minecraft:white_concrete
fill 447 278 333 449 279 333 minecraft:yellow_concrete
fill 447 278 336 449 279 336 minecraft:white_concrete
fill 447 278 339 449 279 339 minecraft:yellow_concrete
fill 447 278 341 447 279 341 minecraft:yellow_concrete
fill 447 278 342 449 279 342 minecraft:white_concrete
fill 447 278 344 447 279 344 minecraft:white_concrete
fill 447 278 345 449 279 345 minecraft:yellow_concrete
fill 447 278 348 449 279 348 minecraft:white_concrete
fill 447 278 351 449 279 351 minecraft:yellow_concrete
fill 447 278 354 449 279 354 minecraft:white_concrete
fill 447 278 357 449 279 357 minecraft:yellow_concrete
fill 447 278 360 449 279 360 minecraft:white_concrete
fill 447 278 363 449 279 363 minecraft:yellow_concrete
fill 448 278 323 448 279 325 minecraft:white_concrete
fill 448 278 326 448 279 328 minecraft:yellow_concrete
fill 448 278 329 448 279 331 minecraft:white_concrete
fill 448 278 332 450 279 332 minecraft:yellow_concrete
fill 448 278 335 450 279 335 minecraft:white_concrete
fill 448 278 338 450 279 338 minecraft:yellow_concrete
fill 448 278 341 450 279 341 minecraft:white_concrete
fill 448 278 344 450 279 344 minecraft:yellow_concrete
fill 448 278 347 450 279 347 minecraft:white_concrete
fill 448 278 350 450 279 350 minecraft:yellow_concrete
fill 448 278 353 450 279 353 minecraft:white_concrete
fill 448 278 356 450 279 356 minecraft:yellow_concrete
fill 448 278 359 450 279 359 minecraft:white_concrete
fill 448 278 362 450 279 362 minecraft:yellow_concrete
fill 449 278 323 449 279 324 minecraft:white_concrete
fill 449 278 325 449 279 327 minecraft:yellow_concrete
fill 449 278 328 449 279 330 minecraft:white_concrete
fill 449 278 331 451 279 331 minecraft:yellow_concrete
fill 449 278 334 451 279 334 minecraft:white_concrete
fill 449 278 337 451 279 337 minecraft:yellow_concrete
fill 449 278 340 451 279 340 minecraft:white_concrete
fill 449 278 343 451 279 343 minecraft:yellow_concrete
fill 449 278 346 451 279 346 minecraft:white_concrete
fill 449 278 349 451 279 349 minecraft:yellow_concrete
fill 449 278 352 451 279 352 minecraft:white_concrete
fill 449 278 355 451 279 355 minecraft:yellow_concrete
fill 449 278 358 451 279 358 minecraft:white_concrete
fill 449 278 361 451 279 361 minecraft:yellow_concrete
fill 450 278 323 450 279 323 minecraft:white_concrete
fill 450 278 324 450 279 326 minecraft:yellow_concrete
fill 450 278 327 450 279 329 minecraft:white_concrete
fill 450 278 330 452 279 330 minecraft:yellow_concrete
fill 450 278 333 452 279 333 minecraft:white_concrete
fill 450 278 336 452 279 336 minecraft:yellow_concrete
fill 450 278 339 452 279 339 minecraft:white_concrete
fill 450 278 342 452 279 342 minecraft:yellow_concrete
fill 450 278 345 452 279 345 minecraft:white_concrete
fill 450 278 348 452 279 348 minecraft:yellow_concrete
fill 450 278 351 452 279 351 minecraft:white_concrete
fill 450 278 354 452 279 354 minecraft:yellow_concrete
fill 450 278 357 452 279 357 minecraft:white_concrete
fill 450 278 360 452 279 360 minecraft:yellow_concrete
fill 450 278 363 452 279 363 minecraft:white_concrete
fill 451 278 323 451 279 325 minecraft:yellow_concrete
fill 451 278 326 451 279 328 minecraft:white_concrete
fill 451 278 329 453 279 329 minecraft:yellow_concrete
fill 451 278 332 453 279 332 minecraft:white_concrete
fill 451 278 335 453 279 335 minecraft:yellow_concrete
fill 451 278 338 453 279 338 minecraft:white_concrete
fill 451 278 341 453 279 341 minecraft:yellow_concrete
fill 451 278 344 453 279 344 minecraft:white_concrete
fill 451 278 347 453 279 347 minecraft:yellow_concrete
fill 451 278 350 453 279 350 minecraft:white_concrete
fill 451 278 353 453 279 353 minecraft:yellow_concrete
fill 451 278 356 453 279 356 minecraft:white_concrete
fill 451 278 359 453 279 359 minecraft:yellow_concrete
fill 451 278 362 453 279 362 minecraft:white_concrete
fill 452 278 323 452 279 324 minecraft:yellow_concrete
fill 452 278 325 452 279 327 minecraft:white_concrete
fill 452 278 328 454 279 328 minecraft:yellow_concrete
fill 452 278 331 454 279 331 minecraft:white_concrete
fill 452 278 334 454 279 334 minecraft:yellow_concrete
fill 452 278 337 454 279 337 minecraft:white_concrete
fill 452 278 340 454 279 340 minecraft:yellow_concrete
fill 452 278 343 454 279 343 minecraft:white_concrete
fill 452 278 346 454 279 346 minecraft:yellow_concrete
fill 452 278 349 454 279 349 minecraft:white_concrete
fill 452 278 352 454 279 352 minecraft:yellow_concrete
fill 452 278 355 454 279 355 minecraft:white_concrete
fill 452 278 358 454 279 358 minecraft:yellow_concrete
fill 452 278 361 454 279 361 minecraft:white_concrete
fill 453 278 323 453 279 323 minecraft:yellow_concrete
fill 453 278 324 453 279 326 minecraft:white_concrete
fill 453 278 327 455 279 327 minecraft:yellow_concrete
fill 453 278 330 455 279 330 minecraft:white_concrete
fill 453 278 333 455 279 333 minecraft:yellow_concrete
fill 453 278 336 455 279 336 minecraft:white_concrete
fill 453 278 339 455 279 339 minecraft:yellow_concrete
fill 453 278 342 455 279 342 minecraft:white_concrete
fill 453 278 345 455 279 345 minecraft:yellow_concrete
fill 453 278 348 455 279 348 minecraft:white_concrete
fill 453 278 351 455 279 351 minecraft:yellow_concrete
fill 453 278 354 455 279 354 minecraft:white_concrete
fill 453 278 357 455 279 357 minecraft:yellow_concrete
fill 453 278 360 455 279 360 minecraft:white_concrete
fill 453 278 363 455 279 363 minecraft:yellow_concrete
fill 454 278 323 454 279 325 minecraft:white_concrete
fill 454 278 326 456 279 326 minecraft:yellow_concrete
fill 454 278 329 456 279 329 minecraft:white_concrete
fill 454 278 332 456 279 332 minecraft:yellow_concrete
fill 454 278 335 456 279 335 minecraft:white_concrete
fill 454 278 338 456 279 338 minecraft:yellow_concrete
fill 454 278 341 456 279 341 minecraft:white_concrete
fill 454 278 344 456 279 344 minecraft:yellow_concrete
fill 454 278 347 456 279 347 minecraft:white_concrete
fill 454 278 350 456 279 350 minecraft:yellow_concrete
fill 454 278 353 456 279 353 minecraft:white_concrete
fill 454 278 356 456 279 356 minecraft:yellow_concrete
fill 454 278 359 456 279 359 minecraft:white_concrete
fill 454 278 362 456 279 362 minecraft:yellow_concrete
fill 455 278 323 455 279 324 minecraft:white_concrete
fill 455 278 325 457 279 325 minecraft:yellow_concrete
fill 455 278 328 457 279 328 minecraft:white_concrete
fill 455 278 331 457 279 331 minecraft:yellow_concrete
fill 455 278 334 457 279 334 minecraft:white_concrete
fill 455 278 337 457 279 337 minecraft:yellow_concrete
fill 455 278 340 457 279 340 minecraft:white_concrete
fill 455 278 343 457 279 343 minecraft:yellow_concrete
fill 455 278 346 457 279 346 minecraft:white_concrete
fill 455 278 349 457 279 349 minecraft:yellow_concrete
fill 455 278 352 457 279 352 minecraft:white_concrete
fill 455 278 355 457 279 355 minecraft:yellow_concrete
fill 455 278 358 457 279 358 minecraft:white_concrete
fill 455 278 361 457 279 361 minecraft:yellow_concrete
fill 456 278 323 456 279 323 minecraft:white_concrete
fill 456 278 324 458 279 324 minecraft:yellow_concrete
fill 456 278 327 458 279 327 minecraft:white_concrete
fill 456 278 330 458 279 330 minecraft:yellow_concrete
fill 456 278 333 458 279 333 minecraft:white_concrete
fill 456 278 336 458 279 336 minecraft:yellow_concrete
fill 456 278 339 458 279 339 minecraft:white_concrete
fill 456 278 342 458 279 342 minecraft:yellow_concrete
fill 456 278 345 458 279 345 minecraft:white_concrete
fill 456 278 348 458 279 348 minecraft:yellow_concrete
fill 456 278 351 458 279 351 minecraft:white_concrete
fill 456 278 354 458 279 354 minecraft:yellow_concrete
fill 456 278 357 458 279 357 minecraft:white_concrete
fill 456 278 360 458 279 360 minecraft:yellow_concrete
fill 456 278 363 458 279 363 minecraft:white_concrete
fill 457 278 323 459 279 323 minecraft:yellow_concrete
fill 457 278 326 459 279 326 minecraft:white_concrete
fill 457 278 329 459 279 329 minecraft:yellow_concrete
fill 457 278 332 459 279 332 minecraft:white_concrete
fill 457 278 335 459 279 335 minecraft:yellow_concrete
fill 457 278 338 459 279 338 minecraft:white_concrete
fill 457 278 341 459 279 341 minecraft:yellow_concrete
fill 457 278 344 459 279 344 minecraft:white_concrete
fill 457 278 347 459 279 347 minecraft:yellow_concrete
fill 457 278 350 459 279 350 minecraft:white_concrete
fill 457 278 353 459 279 353 minecraft:yellow_concrete
fill 457 278 356 459 279 356 minecraft:white_concrete
fill 457 278 359 459 279 359 minecraft:yellow_concrete
fill 457 278 362 459 279 362 minecraft:white_concrete
fill 458 278 325 460 279 325 minecraft:white_concrete
fill 458 278 328 460 279 328 minecraft:yellow_concrete
fill 458 278 331 460 279 331 minecraft:white_concrete
fill 458 278 334 460 279 334 minecraft:yellow_concrete
fill 458 278 337 460 279 337 minecraft:white_concrete
fill 458 278 340 460 279 340 minecraft:yellow_concrete
fill 458 278 343 460 279 343 minecraft:white_concrete
fill 458 278 346 460 279 346 minecraft:yellow_concrete
fill 458 278 349 460 279 349 minecraft:white_concrete
fill 458 278 352 460 279 352 minecraft:yellow_concrete
fill 458 278 355 460 279 355 minecraft:white_concrete
fill 458 278 358 460 279 358 minecraft:yellow_concrete
fill 458 278 361 460 279 361 minecraft:white_concrete
fill 459 278 324 461 279 324 minecraft:white_concrete
fill 459 278 327 461 279 327 minecraft:yellow_concrete
fill 459 278 330 461 279 330 minecraft:white_concrete
fill 459 278 333 461 279 333 minecraft:yellow_concrete
fill 459 278 336 461 279 336 minecraft:white_concrete
fill 459 278 339 461 279 339 minecraft:yellow_concrete
fill 459 278 342 461 279 342 minecraft:white_concrete
fill 459 278 345 461 279 345 minecraft:yellow_concrete
fill 459 278 348 461 279 348 minecraft:white_concrete
fill 459 278 351 461 279 351 minecraft:yellow_concrete
fill 459 278 354 461 279 354 minecraft:white_concrete
fill 459 278 357 461 279 357 minecraft:yellow_concrete
fill 459 278 360 461 279 360 minecraft:white_concrete
fill 459 278 363 461 279 363 minecraft:yellow_concrete
fill 460 278 323 462 279 323 minecraft:white_concrete
fill 460 278 326 462 279 326 minecraft:yellow_concrete
fill 460 278 329 462 279 329 minecraft:white_concrete
fill 460 278 332 462 279 332 minecraft:yellow_concrete
fill 460 278 335 462 279 335 minecraft:white_concrete
fill 460 278 338 462 279 338 minecraft:yellow_concrete
fill 460 278 341 462 279 341 minecraft:white_concrete
fill 460 278 344 462 279 344 minecraft:yellow_concrete
fill 460 278 347 462 279 347 minecraft:white_concrete
fill 460 278 350 462 279 350 minecraft:yellow_concrete
fill 460 278 353 462 279 353 minecraft:white_concrete
fill 460 278 356 462 279 356 minecraft:yellow_concrete
fill 460 278 359 462 279 359 minecraft:white_concrete
fill 460 278 362 462 279 362 minecraft:yellow_concrete
fill 461 278 325 463 279 325 minecraft:yellow_concrete
fill 461 278 328 463 279 328 minecraft:white_concrete
fill 461 278 331 463 279 331 minecraft:yellow_concrete
fill 461 278 334 463 279 334 minecraft:white_concrete
fill 461 278 337 463 279 337 minecraft:yellow_concrete
fill 461 278 340 463 279 340 minecraft:white_concrete
fill 461 278 343 463 279 343 minecraft:yellow_concrete
fill 461 278 346 463 279 346 minecraft:white_concrete
fill 461 278 349 463 279 349 minecraft:yellow_concrete
fill 461 278 352 463 279 352 minecraft:white_concrete
fill 461 278 355 463 279 355 minecraft:yellow_concrete
fill 461 278 358 463 279 358 minecraft:white_concrete
fill 461 278 361 463 279 361 minecraft:yellow_concrete
fill 462 278 324 464 279 324 minecraft:yellow_concrete
fill 462 278 327 464 279 327 minecraft:white_concrete
fill 462 278 330 464 279 330 minecraft:yellow_concrete
fill 462 278 333 464 279 333 minecraft:white_concrete
fill 462 278 336 464 279 336 minecraft:yellow_concrete
fill 462 278 339 464 279 339 minecraft:white_concrete
fill 462 278 342 464 279 342 minecraft:yellow_concrete
fill 462 278 345 464 279 345 minecraft:white_concrete
fill 462 278 348 464 279 348 minecraft:yellow_concrete
fill 462 278 351 464 279 351 minecraft:white_concrete
fill 462 278 354 464 279 354 minecraft:yellow_concrete
fill 462 278 357 464 279 357 minecraft:white_concrete
fill 462 278 360 464 279 360 minecraft:yellow_concrete
fill 462 278 363 464 279 363 minecraft:white_concrete
fill 463 278 323 464 279 323 minecraft:yellow_concrete
fill 463 278 326 464 279 326 minecraft:white_concrete
fill 463 278 329 464 279 329 minecraft:yellow_concrete
fill 463 278 332 464 279 332 minecraft:white_concrete
fill 463 278 335 464 279 335 minecraft:yellow_concrete
fill 463 278 338 464 279 338 minecraft:white_concrete
fill 463 278 341 464 279 341 minecraft:yellow_concrete
fill 463 278 344 464 279 344 minecraft:white_concrete
fill 463 278 347 464 279 347 minecraft:yellow_concrete
fill 463 278 350 464 279 350 minecraft:white_concrete
fill 463 278 353 464 279 353 minecraft:yellow_concrete
fill 463 278 356 464 279 356 minecraft:white_concrete
fill 463 278 359 464 279 359 minecraft:yellow_concrete
fill 463 278 362 464 279 362 minecraft:white_concrete
fill 464 278 325 464 279 325 minecraft:white_concrete
fill 464 278 328 464 279 328 minecraft:yellow_concrete
fill 464 278 331 464 279 331 minecraft:white_concrete
fill 464 278 334 464 279 334 minecraft:yellow_concrete
fill 464 278 337 464 279 337 minecraft:white_concrete
fill 464 278 340 464 279 340 minecraft:yellow_concrete
fill 464 278 343 464 279 343 minecraft:white_concrete
fill 464 278 346 464 279 346 minecraft:yellow_concrete
fill 464 278 349 464 279 349 minecraft:white_concrete
fill 464 278 352 464 279 352 minecraft:yellow_concrete
fill 464 278 355 464 279 355 minecraft:white_concrete
fill 464 278 358 464 279 358 minecraft:yellow_concrete
fill 464 278 361 464 279 361 minecraft:white_concrete
fill 438 279 342 438 279 344 minecraft:verdant_froglight
fill 439 279 338 439 279 339 minecraft:white_concrete
fill 439 279 340 439 279 342 minecraft:verdant_froglight
fill 439 279 344 439 279 346 minecraft:verdant_froglight
fill 439 279 347 440 279 347 minecraft:yellow_concrete
fill 440 279 340 441 279 340 minecraft:verdant_froglight
fill 440 279 346 441 279 346 minecraft:verdant_froglight
fill 441 279 339 443 279 339 minecraft:verdant_froglight
fill 441 279 347 443 279 347 minecraft:verdant_froglight
fill 443 279 340 445 279 340 minecraft:verdant_froglight
fill 443 279 346 445 279 346 minecraft:verdant_froglight
setblock 444 279 347 minecraft:white_concrete
fill 445 279 341 445 279 342 minecraft:verdant_froglight
fill 445 279 344 445 279 345 minecraft:verdant_froglight
setblock 446 279 341 minecraft:yellow_concrete
fill 446 279 342 446 279 344 minecraft:verdant_froglight
setblock 446 279 345 minecraft:white_concrete
fill 447 279 343 448 279 343 minecraft:white_concrete
setblock 426 281 325 minecraft:light[level=14]
setblock 426 281 333 minecraft:light[level=14]
setblock 426 281 341 minecraft:light[level=14]
setblock 426 281 349 minecraft:light[level=14]
setblock 426 281 357 minecraft:light[level=14]
setblock 434 281 325 minecraft:light[level=14]
setblock 434 281 333 minecraft:light[level=14]
setblock 434 281 341 minecraft:light[level=14]
setblock 434 281 349 minecraft:light[level=14]
setblock 434 281 357 minecraft:light[level=14]
setblock 442 281 325 minecraft:light[level=14]
setblock 442 281 333 minecraft:light[level=14]
setblock 442 281 349 minecraft:light[level=14]
setblock 442 281 357 minecraft:light[level=14]
setblock 450 281 325 minecraft:light[level=14]
setblock 450 281 333 minecraft:light[level=14]
setblock 450 281 341 minecraft:light[level=14]
setblock 450 281 349 minecraft:light[level=14]
setblock 450 281 357 minecraft:light[level=14]
setblock 458 281 325 minecraft:light[level=14]
setblock 458 281 333 minecraft:light[level=14]
setblock 458 281 341 minecraft:light[level=14]
setblock 458 281 349 minecraft:light[level=14]
setblock 458 281 357 minecraft:light[level=14]
fill 423 283 328 423 283 331 minecraft:verdant_froglight
fill 423 283 338 423 283 341 minecraft:verdant_froglight
fill 423 283 348 423 283 351 minecraft:verdant_froglight
fill 423 283 358 423 283 361 minecraft:verdant_froglight
fill 424 283 324 424 300 324 minecraft:iron_block
fill 424 283 334 424 300 334 minecraft:iron_block
fill 424 283 344 424 300 344 minecraft:iron_block
fill 424 283 354 424 300 354 minecraft:iron_block
fill 425 283 329 427 300 331 minecraft:iron_block
fill 425 283 363 425 300 363 minecraft:iron_block
fill 426 283 322 429 283 322 minecraft:verdant_froglight
fill 427 283 364 430 283 364 minecraft:verdant_froglight
fill 431 283 323 431 300 323 minecraft:iron_block
fill 435 283 363 435 300 363 minecraft:iron_block
fill 436 283 322 439 283 322 minecraft:verdant_froglight
fill 437 283 364 440 283 364 minecraft:verdant_froglight
fill 441 283 323 441 300 323 minecraft:iron_block
fill 445 283 363 445 300 363 minecraft:iron_block
fill 446 283 322 449 283 322 minecraft:verdant_froglight
fill 447 283 364 450 283 364 minecraft:verdant_froglight
fill 451 283 323 451 300 323 minecraft:iron_block
fill 455 283 363 455 300 363 minecraft:iron_block
fill 456 283 322 459 283 322 minecraft:verdant_froglight
fill 457 283 364 460 283 364 minecraft:verdant_froglight
fill 461 283 323 461 300 323 minecraft:iron_block
fill 464 283 330 464 300 330 minecraft:iron_block
fill 464 283 340 464 300 340 minecraft:iron_block
fill 464 283 350 464 300 350 minecraft:iron_block
fill 464 283 360 464 300 360 minecraft:iron_block
fill 465 283 323 465 283 326 minecraft:verdant_froglight
fill 465 283 333 465 283 336 minecraft:verdant_froglight
fill 465 283 343 465 283 346 minecraft:verdant_froglight
fill 465 283 353 465 283 356 minecraft:verdant_froglight
setblock 465 283 363 minecraft:verdant_froglight
fill 423 284 328 423 291 331 minecraft:white_concrete
fill 423 284 338 423 291 341 minecraft:white_concrete
fill 423 284 348 423 291 351 minecraft:white_concrete
fill 423 284 358 423 291 361 minecraft:white_concrete
fill 426 284 322 429 291 322 minecraft:white_concrete
fill 427 284 364 430 291 364 minecraft:white_concrete
fill 436 284 322 439 291 322 minecraft:white_concrete
fill 437 284 364 440 291 364 minecraft:white_concrete
fill 446 284 322 449 291 322 minecraft:white_concrete
fill 447 284 364 450 291 364 minecraft:white_concrete
fill 456 284 322 459 291 322 minecraft:white_concrete
fill 457 284 364 460 291 364 minecraft:white_concrete
fill 465 284 323 465 291 326 minecraft:white_concrete
fill 465 284 333 465 291 336 minecraft:white_concrete
fill 465 284 343 465 291 346 minecraft:white_concrete
fill 465 284 353 465 291 356 minecraft:white_concrete
fill 465 284 363 465 291 363 minecraft:white_concrete
fill 424 285 329 424 285 331 minecraft:light_gray_concrete
fill 425 285 328 427 285 328 minecraft:light_gray_concrete
fill 425 285 332 427 285 332 minecraft:light_gray_concrete
fill 428 285 329 428 285 331 minecraft:light_gray_concrete
fill 441 286 328 441 287 328 minecraft:lime_stained_glass
setblock 424 288 325 minecraft:light_gray_concrete
fill 424 288 327 424 288 330 minecraft:light_gray_concrete
setblock 424 288 335 minecraft:light_gray_concrete
fill 424 288 337 424 288 340 minecraft:light_gray_concrete
setblock 424 288 345 minecraft:light_gray_concrete
fill 424 288 347 424 288 350 minecraft:light_gray_concrete
setblock 424 288 355 minecraft:light_gray_concrete
fill 424 288 357 424 288 360 minecraft:light_gray_concrete
fill 425 288 323 428 288 323 minecraft:light_gray_concrete
setblock 426 288 363 minecraft:light_gray_concrete
fill 428 288 363 431 288 363 minecraft:light_gray_concrete
setblock 430 288 323 minecraft:light_gray_concrete
fill 435 288 323 438 288 323 minecraft:light_gray_concrete
setblock 436 288 363 minecraft:light_gray_concrete
fill 438 288 363 441 288 363 minecraft:light_gray_concrete
setblock 440 288 323 minecraft:light_gray_concrete
fill 445 288 323 448 288 323 minecraft:light_gray_concrete
setblock 446 288 363 minecraft:light_gray_concrete
fill 448 288 363 451 288 363 minecraft:light_gray_concrete
setblock 450 288 323 minecraft:light_gray_concrete
fill 455 288 323 458 288 323 minecraft:light_gray_concrete
setblock 456 288 363 minecraft:light_gray_concrete
fill 458 288 363 461 288 363 minecraft:light_gray_concrete
setblock 460 288 323 minecraft:light_gray_concrete
fill 464 288 324 464 288 327 minecraft:light_gray_concrete
setblock 464 288 329 minecraft:light_gray_concrete
fill 464 288 334 464 288 337 minecraft:light_gray_concrete
setblock 464 288 339 minecraft:light_gray_concrete
fill 464 288 344 464 288 347 minecraft:light_gray_concrete
setblock 464 288 349 minecraft:light_gray_concrete
fill 464 288 354 464 288 357 minecraft:light_gray_concrete
setblock 464 288 359 minecraft:light_gray_concrete
setblock 426 289 325 minecraft:light[level=14]
setblock 426 289 333 minecraft:light[level=14]
setblock 426 289 341 minecraft:light[level=14]
setblock 426 289 349 minecraft:light[level=14]
setblock 426 289 357 minecraft:light[level=14]
setblock 434 289 325 minecraft:light[level=14]
setblock 434 289 333 minecraft:light[level=14]
setblock 434 289 341 minecraft:light[level=14]
setblock 434 289 349 minecraft:light[level=14]
setblock 434 289 357 minecraft:light[level=14]
setblock 442 289 325 minecraft:light[level=14]
setblock 442 289 333 minecraft:light[level=14]
setblock 442 289 341 minecraft:light[level=14]
setblock 442 289 349 minecraft:light[level=14]
setblock 442 289 357 minecraft:light[level=14]
setblock 450 289 325 minecraft:light[level=14]
setblock 450 289 333 minecraft:light[level=14]
setblock 450 289 341 minecraft:light[level=14]
setblock 450 289 349 minecraft:light[level=14]
setblock 450 289 357 minecraft:light[level=14]
setblock 458 289 325 minecraft:light[level=14]
setblock 458 289 333 minecraft:light[level=14]
setblock 458 289 341 minecraft:light[level=14]
setblock 458 289 349 minecraft:light[level=14]
setblock 458 289 357 minecraft:light[level=14]
fill 424 290 329 424 290 331 minecraft:light_gray_concrete
fill 425 290 328 427 290 328 minecraft:light_gray_concrete
fill 425 290 332 427 290 332 minecraft:light_gray_concrete
fill 428 290 329 428 290 331 minecraft:light_gray_concrete
fill 437 291 360 439 292 360 minecraft:lime_stained_glass
fill 438 291 359 438 292 359 minecraft:lime_stained_glass
fill 423 292 328 423 292 331 minecraft:verdant_froglight
fill 423 292 338 423 292 341 minecraft:verdant_froglight
fill 423 292 348 423 292 351 minecraft:verdant_froglight
fill 423 292 358 423 292 361 minecraft:verdant_froglight
fill 426 292 322 429 292 322 minecraft:verdant_froglight
fill 427 292 364 430 292 364 minecraft:verdant_froglight
fill 436 292 322 439 292 322 minecraft:verdant_froglight
fill 437 292 364 440 292 364 minecraft:verdant_froglight
fill 446 292 322 449 292 322 minecraft:verdant_froglight
fill 447 292 364 450 292 364 minecraft:verdant_froglight
fill 456 292 322 459 292 322 minecraft:verdant_froglight
fill 457 292 364 460 292 364 minecraft:verdant_froglight
fill 465 292 323 465 292 326 minecraft:verdant_froglight
fill 465 292 333 465 292 336 minecraft:verdant_froglight
fill 465 292 343 465 292 346 minecraft:verdant_froglight
fill 465 292 353 465 292 356 minecraft:verdant_froglight
setblock 465 292 363 minecraft:verdant_froglight
fill 423 293 328 423 307 331 minecraft:white_concrete
fill 423 293 338 423 307 341 minecraft:white_concrete
fill 423 293 348 423 307 351 minecraft:white_concrete
fill 423 293 358 423 307 361 minecraft:white_concrete
fill 426 293 322 429 307 322 minecraft:white_concrete
fill 427 293 364 430 307 364 minecraft:white_concrete
fill 436 293 322 439 307 322 minecraft:white_concrete
fill 437 293 364 440 307 364 minecraft:white_concrete
fill 446 293 322 449 307 322 minecraft:white_concrete
fill 447 293 364 450 307 364 minecraft:white_concrete
fill 456 293 322 459 307 322 minecraft:white_concrete
fill 457 293 364 460 307 364 minecraft:white_concrete
fill 465 293 323 465 307 326 minecraft:white_concrete
fill 465 293 333 465 307 336 minecraft:white_concrete
fill 465 293 343 465 307 346 minecraft:white_concrete
fill 465 293 353 465 307 356 minecraft:white_concrete
fill 465 293 363 465 307 363 minecraft:white_concrete
fill 424 294 325 424 296 325 minecraft:light_gray_concrete
setblock 424 294 335 minecraft:light_gray_concrete
setblock 424 294 345 minecraft:light_gray_concrete
fill 424 294 355 424 296 355 minecraft:light_gray_concrete
setblock 426 294 363 minecraft:light_gray_concrete
setblock 430 294 323 minecraft:light_gray_concrete
setblock 436 294 363 minecraft:light_gray_concrete
setblock 440 294 323 minecraft:light_gray_concrete
setblock 446 294 363 minecraft:light_gray_concrete
setblock 450 294 323 minecraft:light_gray_concrete
fill 454 294 349 464 294 349 minecraft:light_gray_concrete
fill 455 294 355 463 294 355 minecraft:light_gray_concrete
setblock 456 294 363 minecraft:light_gray_concrete
setblock 460 294 323 minecraft:light_gray_concrete
setblock 464 294 329 minecraft:light_gray_concrete
setblock 464 294 339 minecraft:light_gray_concrete
setblock 464 294 359 minecraft:light_gray_concrete
fill 424 295 329 424 295 331 minecraft:light_gray_concrete
fill 424 295 337 463 295 337 minecraft:light_gray_concrete
fill 424 295 343 439 296 343 minecraft:light_gray_concrete
fill 424 295 349 459 295 349 minecraft:light_gray_concrete
fill 424 295 361 428 296 361 minecraft:light_gray_concrete
fill 425 295 325 428 296 325 minecraft:light_gray_concrete
fill 425 295 328 427 295 328 minecraft:light_gray_concrete
fill 425 295 332 427 295 332 minecraft:light_gray_concrete
fill 425 295 355 461 295 355 minecraft:light_gray_concrete
fill 428 295 329 428 295 331 minecraft:light_gray_concrete
fill 446 295 343 463 296 343 minecraft:light_gray_concrete
fill 424 296 329 424 296 331 minecraft:iron_block
fill 424 296 337 455 296 337 minecraft:light_gray_concrete
fill 424 296 349 426 296 349 minecraft:light_gray_concrete
fill 425 296 355 426 296 355 minecraft:light_gray_concrete
setblock 428 296 330 minecraft:verdant_froglight
fill 428 296 331 462 296 331 minecraft:light_gray_concrete
fill 429 296 325 463 296 325 minecraft:light_gray_concrete
fill 429 296 361 455 296 361 minecraft:light_gray_concrete
fill 449 296 360 449 297 360 minecraft:iron_block
fill 449 296 362 449 297 362 minecraft:iron_block
fill 456 296 349 456 296 363 minecraft:iron_block
fill 457 296 361 463 296 361 minecraft:light_gray_concrete
fill 424 297 327 424 297 330 minecraft:light_gray_concrete
fill 424 297 337 424 297 340 minecraft:light_gray_concrete
fill 424 297 347 424 297 350 minecraft:light_gray_concrete
fill 424 297 357 424 297 360 minecraft:light_gray_concrete
fill 425 297 323 428 297 323 minecraft:light_gray_concrete
fill 426 297 324 426 298 328 minecraft:iron_block
setblock 426 297 333 minecraft:light[level=14]
setblock 426 297 341 minecraft:light[level=14]
setblock 426 297 349 minecraft:light[level=14]
setblock 426 297 357 minecraft:light[level=14]
fill 428 297 363 431 297 363 minecraft:light_gray_concrete
fill 432 297 323 432 298 326 minecraft:iron_block
setblock 434 297 325 minecraft:light[level=14]
setblock 434 297 333 minecraft:light[level=14]
setblock 434 297 341 minecraft:light[level=14]
setblock 434 297 349 minecraft:light[level=14]
setblock 434 297 357 minecraft:light[level=14]
fill 435 297 323 438 297 323 minecraft:light_gray_concrete
fill 438 297 324 438 297 362 minecraft:iron_block
fill 438 297 363 441 297 363 minecraft:light_gray_concrete
setblock 442 297 325 minecraft:light[level=14]
setblock 442 297 333 minecraft:light[level=14]
setblock 442 297 341 minecraft:light[level=14]
setblock 442 297 349 minecraft:light[level=14]
setblock 442 297 357 minecraft:light[level=14]
fill 444 297 323 444 298 328 minecraft:iron_block
fill 445 297 323 448 297 323 minecraft:light_gray_concrete
fill 448 297 363 451 297 363 minecraft:light_gray_concrete
fill 449 297 361 450 297 361 minecraft:iron_block
fill 450 297 323 450 297 360 minecraft:iron_block
setblock 450 297 362 minecraft:iron_block
fill 455 297 323 458 297 323 minecraft:light_gray_concrete
fill 456 297 324 456 297 330 minecraft:iron_block
fill 456 297 331 463 297 331 minecraft:light_gray_concrete
fill 456 297 332 456 297 354 minecraft:iron_block
setblock 458 297 325 minecraft:light[level=14]
setblock 458 297 333 minecraft:light[level=14]
setblock 458 297 341 minecraft:light[level=14]
setblock 458 297 349 minecraft:light[level=14]
setblock 458 297 357 minecraft:light[level=14]
fill 458 297 363 461 297 363 minecraft:light_gray_concrete
fill 462 297 323 462 298 330 minecraft:iron_block
fill 462 297 332 462 298 362 minecraft:iron_block
fill 464 297 324 464 297 327 minecraft:light_gray_concrete
fill 464 297 334 464 297 337 minecraft:light_gray_concrete
fill 464 297 344 464 297 347 minecraft:light_gray_concrete
fill 464 297 354 464 297 357 minecraft:light_gray_concrete
setblock 426 298 323 minecraft:iron_block
fill 426 298 332 426 298 363 minecraft:iron_block
fill 432 298 327 432 298 362 minecraft:iron_block
fill 438 298 323 438 298 335 minecraft:iron_block
fill 444 298 329 444 298 339 minecraft:iron_block
fill 444 298 347 444 298 363 minecraft:iron_block
fill 450 298 323 450 298 327 minecraft:iron_block
fill 456 298 323 456 298 325 minecraft:iron_block
setblock 462 298 331 minecraft:iron_block
setblock 432 299 362 minecraft:iron_block
setblock 424 300 325 minecraft:light_gray_concrete
setblock 424 300 335 minecraft:light_gray_concrete
setblock 424 300 345 minecraft:light_gray_concrete
setblock 424 300 355 minecraft:light_gray_concrete
setblock 426 300 363 minecraft:light_gray_concrete
setblock 430 300 323 minecraft:light_gray_concrete
setblock 436 300 363 minecraft:light_gray_concrete
setblock 440 300 323 minecraft:light_gray_concrete
setblock 446 300 363 minecraft:light_gray_concrete
setblock 450 300 323 minecraft:light_gray_concrete
setblock 456 300 363 minecraft:light_gray_concrete
setblock 460 300 323 minecraft:light_gray_concrete
setblock 464 300 329 minecraft:light_gray_concrete
setblock 464 300 339 minecraft:light_gray_concrete
setblock 464 300 349 minecraft:light_gray_concrete
setblock 464 300 359 minecraft:light_gray_concrete
