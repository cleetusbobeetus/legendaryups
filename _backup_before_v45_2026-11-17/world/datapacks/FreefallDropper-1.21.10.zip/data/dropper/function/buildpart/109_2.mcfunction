fill 70 170 499 71 177 499 minecraft:basalt
fill 71 170 468 76 170 468 minecraft:basalt
fill 71 170 500 72 176 500 minecraft:basalt
fill 73 170 464 74 223 464 minecraft:quartz_block
setblock 73 170 467 minecraft:magma_block
setblock 73 170 500 minecraft:magma_block
fill 74 170 467 75 170 467 minecraft:basalt
fill 74 170 474 74 177 474 minecraft:basalt
fill 74 170 500 77 177 500 minecraft:basalt
fill 77 170 475 78 178 475 minecraft:basalt
fill 77 170 499 78 178 499 minecraft:basalt
setblock 78 170 468 minecraft:basalt
fill 78 170 504 84 170 504 minecraft:basalt
setblock 79 170 468 minecraft:magma_block
setblock 80 170 468 minecraft:basalt
fill 80 170 475 80 177 476 minecraft:basalt
fill 80 170 498 80 177 499 minecraft:basalt
fill 81 170 464 82 223 464 minecraft:quartz_block
fill 81 170 470 84 170 470 minecraft:basalt
fill 81 170 477 83 177 477 minecraft:basalt
fill 81 170 497 81 178 497 minecraft:basalt
fill 81 170 503 86 170 503 minecraft:basalt
setblock 82 170 497 minecraft:magma_block
fill 83 170 478 83 178 478 minecraft:basalt
fill 83 170 479 83 170 483 minecraft:black_concrete
fill 83 170 496 83 178 496 minecraft:basalt
fill 84 170 472 87 170 472 minecraft:basalt
fill 84 170 479 84 170 480 minecraft:basalt
fill 84 170 484 85 170 490 minecraft:quartz_block
fill 84 170 494 84 178 495 minecraft:basalt
fill 84 170 502 87 170 502 minecraft:basalt
setblock 85 170 481 minecraft:magma_block
setblock 85 170 493 minecraft:magma_block
fill 86 170 482 86 177 484 minecraft:basalt
fill 86 170 485 86 170 489 minecraft:quartz_block
fill 86 170 490 86 177 491 minecraft:basalt
fill 86 170 504 87 223 504 minecraft:quartz_block
fill 87 170 501 87 171 501 minecraft:basalt
fill 88 170 465 88 223 466 minecraft:quartz_block
setblock 88 170 501 minecraft:magma_block
fill 55 171 485 55 171 489 minecraft:basalt
fill 56 171 488 59 171 488 minecraft:basalt
fill 57 171 479 61 171 479 minecraft:basalt
setblock 57 171 480 minecraft:magma_block
fill 57 171 494 62 171 494 minecraft:basalt
setblock 57 171 495 minecraft:magma_block
fill 58 171 477 58 171 478 minecraft:basalt
fill 58 171 480 58 172 480 minecraft:basalt
fill 58 171 495 58 171 497 minecraft:basalt
fill 59 171 478 62 171 478 minecraft:basalt
fill 59 171 496 62 171 496 minecraft:basalt
fill 60 171 499 64 171 499 minecraft:basalt
setblock 60 171 500 minecraft:magma_block
fill 61 171 473 62 171 473 minecraft:basalt
fill 61 171 486 62 178 486 minecraft:basalt
fill 61 171 489 62 177 489 minecraft:basalt
fill 61 171 500 64 171 501 minecraft:basalt
fill 62 171 485 62 179 485 minecraft:basalt
fill 62 171 487 62 179 488 minecraft:basalt
setblock 63 171 472 minecraft:magma_block
fill 63 171 482 63 179 483 minecraft:basalt
fill 63 171 491 63 179 492 minecraft:basalt
setblock 63 171 502 minecraft:magma_block
fill 64 171 471 64 171 472 minecraft:basalt
fill 64 171 479 65 178 479 minecraft:basalt
fill 64 171 481 64 179 481 minecraft:basalt
fill 64 171 493 64 178 494 minecraft:basalt
fill 64 171 502 64 171 503 minecraft:basalt
fill 65 171 471 67 171 471 minecraft:basalt
fill 65 171 495 65 179 495 minecraft:basalt
fill 65 171 501 67 173 501 minecraft:basalt
fill 65 171 503 70 171 503 minecraft:basalt
fill 66 171 470 70 171 470 minecraft:basalt
fill 66 171 478 66 179 478 minecraft:basalt
fill 66 171 496 66 179 496 minecraft:basalt
setblock 66 171 504 minecraft:magma_block
setblock 67 171 504 minecraft:basalt
fill 68 171 469 69 171 469 minecraft:basalt
fill 68 171 477 68 179 477 minecraft:basalt
fill 68 171 497 68 179 497 minecraft:basalt
setblock 69 171 476 minecraft:magma_block
fill 69 171 498 70 178 498 minecraft:basalt
fill 70 171 476 70 179 476 minecraft:basalt
fill 72 171 468 74 171 468 minecraft:basalt
setblock 72 171 475 minecraft:magma_block
setblock 72 171 499 minecraft:magma_block
fill 73 171 475 76 178 475 minecraft:basalt
fill 73 171 499 73 178 500 minecraft:basalt
fill 74 171 499 76 178 499 minecraft:basalt
setblock 75 171 468 minecraft:magma_block
fill 75 171 469 80 171 469 minecraft:basalt
setblock 76 171 468 minecraft:basalt
fill 78 171 471 83 171 471 minecraft:basalt
setblock 78 171 476 minecraft:magma_block
fill 78 171 498 79 178 498 minecraft:basalt
fill 78 171 504 82 171 504 minecraft:basalt
fill 79 171 476 79 179 476 minecraft:basalt
setblock 80 171 477 minecraft:basalt
fill 80 171 497 80 179 497 minecraft:basalt
fill 81 171 470 82 171 470 minecraft:basalt
fill 81 171 500 86 172 500 minecraft:basalt
fill 81 171 503 84 171 503 minecraft:basalt
fill 82 171 478 82 179 478 minecraft:basalt
fill 82 171 496 82 178 497 minecraft:basalt
fill 83 171 479 84 178 479 minecraft:basalt
fill 83 171 482 83 171 487 minecraft:black_concrete
fill 83 171 495 83 179 495 minecraft:basalt
setblock 84 171 471 minecraft:magma_block
fill 84 171 472 85 171 472 minecraft:basalt
setblock 84 171 480 minecraft:magma_block
fill 84 171 481 85 178 481 minecraft:basalt
fill 84 171 488 84 171 492 minecraft:quartz_block
fill 84 171 493 85 178 493 minecraft:basalt
fill 84 171 502 85 171 502 minecraft:basalt
fill 85 171 482 85 179 483 minecraft:basalt
fill 85 171 488 85 171 490 minecraft:quartz_block
fill 85 171 491 85 179 492 minecraft:basalt
setblock 86 171 473 minecraft:basalt
fill 86 171 485 86 177 489 minecraft:basalt
setblock 87 171 473 minecraft:magma_block
setblock 87 171 500 minecraft:magma_block
fill 88 171 473 88 223 473 minecraft:quartz_block
setblock 88 171 500 minecraft:basalt
fill 47 172 468 47 177 468 minecraft:sea_lantern
fill 47 172 476 47 177 476 minecraft:sea_lantern
fill 47 172 484 47 177 484 minecraft:sea_lantern
fill 47 172 492 47 177 492 minecraft:sea_lantern
fill 47 172 500 47 177 500 minecraft:sea_lantern
fill 50 172 505 50 177 505 minecraft:sea_lantern
fill 54 172 463 54 177 463 minecraft:sea_lantern
setblock 56 172 485 minecraft:magma_block
setblock 56 172 488 minecraft:magma_block
fill 57 172 482 58 172 483 minecraft:basalt
fill 57 172 485 59 173 485 minecraft:basalt
fill 57 172 488 59 173 488 minecraft:basalt
fill 57 172 491 58 172 492 minecraft:basalt
fill 58 172 479 61 172 479 minecraft:basalt
fill 58 172 494 58 172 495 minecraft:basalt
fill 58 172 505 58 177 505 minecraft:sea_lantern
setblock 59 172 478 minecraft:magma_block
fill 59 172 482 60 174 482 minecraft:basalt
fill 59 172 491 59 175 491 minecraft:basalt
fill 59 172 494 62 174 494 minecraft:basalt
setblock 59 172 496 minecraft:magma_block
fill 60 172 476 61 172 476 minecraft:basalt
fill 60 172 478 62 173 478 minecraft:basalt
fill 60 172 496 62 173 496 minecraft:basalt
fill 61 172 475 64 172 475 minecraft:basalt
fill 61 172 499 64 172 499 minecraft:basalt
fill 62 172 463 62 177 463 minecraft:sea_lantern
setblock 62 172 474 minecraft:magma_block
fill 62 172 500 64 172 500 minecraft:basalt
fill 63 172 474 67 173 474 minecraft:basalt
fill 63 172 484 63 179 490 minecraft:basalt
fill 63 172 501 64 172 501 minecraft:basalt
setblock 64 172 472 minecraft:basalt
fill 64 172 482 64 180 482 minecraft:basalt
fill 64 172 492 64 180 492 minecraft:basalt
setblock 64 172 502 minecraft:basalt
fill 65 172 480 65 179 480 minecraft:basalt
setblock 65 172 494 minecraft:magma_block
fill 66 172 471 67 172 471 minecraft:basalt
fill 66 172 479 66 179 479 minecraft:basalt
fill 66 172 495 66 179 495 minecraft:basalt
fill 66 172 503 70 172 503 minecraft:basalt
fill 66 172 505 66 177 505 minecraft:sea_lantern
fill 67 172 478 67 178 478 minecraft:basalt
fill 67 172 496 67 178 496 minecraft:basalt
fill 68 172 470 70 172 470 minecraft:basalt
fill 69 172 476 69 179 477 minecraft:basalt
fill 69 172 497 69 179 497 minecraft:basalt
fill 70 172 463 70 177 463 minecraft:sea_lantern
fill 71 172 469 73 172 469 minecraft:basalt
fill 71 172 476 73 179 476 minecraft:basalt
setblock 71 172 498 minecraft:magma_block
fill 72 172 475 72 179 475 minecraft:basalt
fill 72 172 498 72 179 499 minecraft:basalt
fill 73 172 498 77 172 498 minecraft:basalt
setblock 74 172 476 minecraft:magma_block
fill 74 172 505 74 177 505 minecraft:sea_lantern
fill 75 172 469 76 172 469 minecraft:basalt
fill 75 172 476 78 179 476 minecraft:basalt
setblock 77 172 469 minecraft:magma_block
fill 78 172 463 78 177 463 minecraft:sea_lantern
fill 78 172 471 82 172 471 minecraft:basalt
fill 78 172 504 79 172 504 minecraft:basalt
fill 79 172 477 79 180 477 minecraft:basalt
setblock 79 172 497 minecraft:basalt
setblock 80 172 477 minecraft:magma_block
setblock 80 172 504 minecraft:magma_block
fill 81 172 478 81 179 478 minecraft:basalt
fill 81 172 496 81 179 496 minecraft:basalt
fill 81 172 503 82 172 503 minecraft:basalt
fill 82 172 479 82 178 479 minecraft:basalt
fill 82 172 495 82 179 495 minecraft:basalt
fill 82 172 505 82 177 505 minecraft:sea_lantern
fill 83 172 480 84 178 480 minecraft:basalt
fill 83 172 486 83 172 491 minecraft:black_concrete
setblock 83 172 494 minecraft:magma_block
setblock 84 172 472 minecraft:basalt
fill 84 172 475 87 172 476 minecraft:basalt
fill 84 172 482 84 180 482 minecraft:basalt
fill 84 172 492 84 179 492 minecraft:basalt
setblock 84 172 502 minecraft:basalt
fill 85 172 484 85 172 490 minecraft:basalt
fill 85 172 502 88 173 503 minecraft:quartz_block
fill 86 172 463 86 177 463 minecraft:sea_lantern
fill 86 172 499 87 172 499 minecraft:basalt
fill 86 172 501 88 173 501 minecraft:quartz_block
fill 87 172 500 88 172 500 minecraft:quartz_block
fill 88 172 474 88 223 474 minecraft:quartz_block
setblock 88 172 476 minecraft:basalt
setblock 88 172 499 minecraft:quartz_block
fill 88 172 504 88 173 504 minecraft:quartz_block
fill 89 172 468 89 177 468 minecraft:sea_lantern
fill 89 172 476 89 177 476 minecraft:sea_lantern
fill 89 172 484 89 177 484 minecraft:sea_lantern
fill 89 172 492 89 177 492 minecraft:sea_lantern
fill 89 172 500 89 177 500 minecraft:sea_lantern
fill 57 173 486 58 173 486 minecraft:basalt
fill 57 173 489 58 173 489 minecraft:basalt
fill 58 173 481 58 173 482 minecraft:basalt
setblock 58 173 483 minecraft:magma_block
fill 58 173 491 58 174 491 minecraft:basalt
setblock 58 173 492 minecraft:magma_block
fill 58 173 493 60 173 493 minecraft:basalt
fill 59 173 479 61 173 479 minecraft:basalt
fill 59 173 481 60 174 481 minecraft:basalt
fill 60 173 497 61 173 497 minecraft:basalt
setblock 61 173 476 minecraft:magma_block
fill 61 173 498 64 173 498 minecraft:basalt
fill 62 173 475 64 173 475 minecraft:basalt
fill 62 173 499 64 173 499 minecraft:basalt
fill 63 173 500 64 173 500 minecraft:basalt
fill 64 173 473 69 173 473 minecraft:basalt
fill 64 173 483 64 180 483 minecraft:basalt
setblock 64 173 484 minecraft:magma_block
setblock 64 173 490 minecraft:magma_block
fill 64 173 491 64 180 491 minecraft:basalt
setblock 64 173 501 minecraft:basalt
fill 65 173 481 65 180 481 minecraft:basalt
fill 65 173 493 65 179 494 minecraft:basalt
fill 66 173 480 66 179 480 minecraft:basalt
fill 66 173 494 66 180 494 minecraft:basalt
fill 67 173 479 67 180 479 minecraft:basalt
setblock 67 173 495 minecraft:magma_block
fill 68 173 478 68 180 478 minecraft:basalt
fill 68 173 496 68 180 496 minecraft:basalt
fill 68 173 503 69 173 503 minecraft:basalt
fill 70 173 477 71 180 477 minecraft:basalt
setblock 70 173 497 minecraft:magma_block
setblock 70 173 503 minecraft:magma_block
fill 70 173 504 70 223 504 minecraft:quartz_block
fill 71 173 497 71 179 498 minecraft:basalt
fill 71 173 504 75 173 504 minecraft:basalt
fill 72 173 470 77 173 470 minecraft:basalt
fill 72 173 503 78 173 503 minecraft:basalt
fill 73 173 498 75 179 498 minecraft:basalt
fill 74 173 476 74 180 476 minecraft:basalt
fill 75 173 472 81 174 472 minecraft:basalt
fill 75 173 502 81 174 502 minecraft:basalt
setblock 76 173 498 minecraft:magma_block
setblock 76 173 504 minecraft:magma_block
fill 77 173 477 78 180 477 minecraft:basalt
fill 77 173 497 77 179 498 minecraft:basalt
fill 78 173 471 80 173 471 minecraft:basalt
fill 78 173 497 78 179 497 minecraft:basalt
fill 78 173 504 85 173 504 minecraft:quartz_block
setblock 79 173 497 minecraft:magma_block
fill 79 173 501 84 173 501 minecraft:basalt
setblock 79 173 503 minecraft:magma_block
fill 80 173 477 80 179 478 minecraft:basalt
fill 80 173 496 80 180 496 minecraft:basalt
fill 81 173 473 84 173 474 minecraft:basalt
fill 81 173 479 81 180 479 minecraft:basalt
fill 81 173 495 81 180 495 minecraft:basalt
fill 81 173 500 85 173 500 minecraft:basalt
fill 81 173 503 84 173 503 minecraft:quartz_block
setblock 82 173 472 minecraft:magma_block
fill 82 173 480 82 180 480 minecraft:basalt
fill 82 173 494 83 179 494 minecraft:basalt
setblock 82 173 502 minecraft:magma_block
fill 83 173 481 83 180 481 minecraft:basalt
fill 83 173 489 83 173 492 minecraft:black_concrete
fill 83 173 493 83 180 493 minecraft:basalt
fill 83 173 502 84 173 502 minecraft:quartz_block
fill 84 173 475 86 173 476 minecraft:basalt
fill 84 173 483 84 179 484 minecraft:basalt
fill 84 173 490 84 180 491 minecraft:basalt
setblock 85 173 474 minecraft:magma_block
fill 85 173 484 85 178 485 minecraft:basalt
setblock 85 173 486 minecraft:magma_block
fill 85 173 487 85 180 488 minecraft:basalt
setblock 85 173 489 minecraft:magma_block
fill 85 173 490 85 178 490 minecraft:basalt
fill 85 173 497 87 174 497 minecraft:basalt
setblock 85 173 501 minecraft:quartz_block
setblock 86 173 499 minecraft:basalt
setblock 86 173 500 minecraft:quartz_block
setblock 87 173 476 minecraft:basalt
setblock 87 173 498 minecraft:basalt
setblock 88 173 497 minecraft:magma_block
fill 88 173 498 88 223 498 minecraft:quartz_block
fill 58 174 483 58 174 490 minecraft:basalt
fill 59 174 484 59 175 485 minecraft:basalt
fill 59 174 487 59 175 488 minecraft:basalt
fill 59 174 490 59 175 490 minecraft:basalt
fill 59 174 493 60 174 493 minecraft:basalt
fill 60 174 479 61 174 479 minecraft:basalt
fill 61 174 477 62 174 478 minecraft:basalt
fill 61 174 496 61 174 497 minecraft:basalt
fill 62 174 496 62 175 496 minecraft:basalt
fill 62 174 498 64 174 498 minecraft:basalt
fill 63 174 475 64 174 475 minecraft:basalt
fill 63 174 477 63 175 477 minecraft:basalt
fill 63 174 499 64 174 499 minecraft:basalt
fill 64 174 474 67 174 474 minecraft:basalt
fill 64 174 484 64 180 490 minecraft:basalt
setblock 64 174 500 minecraft:basalt
fill 65 174 482 65 180 483 minecraft:basalt
fill 65 174 491 65 180 492 minecraft:basalt
setblock 66 174 473 minecraft:magma_block
fill 66 174 481 66 181 481 minecraft:basalt
fill 66 174 493 66 181 493 minecraft:basalt
fill 66 174 501 67 174 501 minecraft:basalt
fill 67 174 472 68 174 473 minecraft:basalt
fill 67 174 480 67 181 480 minecraft:basalt
fill 67 174 494 67 180 495 minecraft:basalt
fill 67 174 502 68 174 502 minecraft:basalt
fill 68 174 479 68 181 479 minecraft:basalt
fill 68 174 495 68 181 495 minecraft:basalt
setblock 69 174 472 minecraft:magma_block
fill 69 174 473 69 175 473 minecraft:basalt
setblock 69 174 478 minecraft:magma_block
setblock 69 174 496 minecraft:magma_block
setblock 69 174 502 minecraft:magma_block
fill 70 174 471 71 174 472 minecraft:basalt
fill 70 174 478 70 181 478 minecraft:basalt
fill 70 174 496 70 180 497 minecraft:basalt
fill 70 174 502 70 174 503 minecraft:basalt
fill 71 174 502 73 175 502 minecraft:basalt
fill 71 174 504 71 223 504 minecraft:quartz_block
setblock 72 174 471 minecraft:magma_block
fill 72 174 472 73 175 472 minecraft:basalt
setblock 72 174 477 minecraft:magma_block
fill 72 174 497 74 180 497 minecraft:basalt
fill 72 174 503 74 174 503 minecraft:basalt
fill 73 174 471 76 174 471 minecraft:basalt
fill 73 174 477 76 181 477 minecraft:basalt
fill 73 174 504 82 174 504 minecraft:quartz_block
setblock 75 174 497 minecraft:magma_block
setblock 75 174 503 minecraft:magma_block
fill 76 174 497 76 180 498 minecraft:basalt
fill 76 174 503 78 174 503 minecraft:basalt
setblock 78 174 471 minecraft:basalt
setblock 78 174 478 minecraft:magma_block
setblock 78 174 496 minecraft:magma_block
fill 79 174 478 79 181 478 minecraft:basalt
fill 79 174 496 79 180 497 minecraft:basalt
fill 79 174 501 82 174 501 minecraft:basalt
fill 79 174 503 81 174 503 minecraft:quartz_block
fill 80 174 479 80 181 479 minecraft:basalt
fill 80 174 495 80 180 495 minecraft:basalt
fill 81 174 473 82 174 474 minecraft:basalt
setblock 81 174 480 minecraft:magma_block
fill 81 174 494 81 181 494 minecraft:basalt
fill 81 174 500 83 174 500 minecraft:basalt
fill 82 174 481 82 181 481 minecraft:basalt
fill 82 174 493 82 181 493 minecraft:basalt
fill 83 174 474 84 174 474 minecraft:basalt
fill 83 174 482 83 180 483 minecraft:basalt
fill 83 174 491 83 180 492 minecraft:basalt
fill 84 174 475 85 174 476 minecraft:basalt
setblock 84 174 485 minecraft:magma_block
fill 84 174 486 84 181 487 minecraft:basalt
setblock 84 174 488 minecraft:magma_block
fill 84 174 489 85 180 489 minecraft:basalt
setblock 84 174 500 minecraft:magma_block
fill 85 174 486 85 180 486 minecraft:basalt
setblock 86 174 476 minecraft:basalt
fill 86 174 478 86 175 478 minecraft:basalt
fill 86 174 496 86 175 496 minecraft:basalt
setblock 87 174 477 minecraft:basalt
setblock 87 174 478 minecraft:magma_block
setblock 87 174 496 minecraft:magma_block
fill 88 174 497 88 223 497 minecraft:quartz_block
setblock 59 175 483 minecraft:magma_block
setblock 59 175 486 minecraft:magma_block
setblock 59 175 489 minecraft:magma_block
fill 60 175 481 60 175 483 minecraft:basalt
fill 60 175 493 60 175 494 minecraft:basalt
setblock 61 175 479 minecraft:basalt
fill 61 175 494 61 175 495 minecraft:basalt
fill 62 175 477 62 175 478 minecraft:basalt
fill 62 175 494 62 177 494 minecraft:basalt
setblock 62 175 497 minecraft:magma_block
fill 63 175 498 65 175 498 minecraft:basalt
setblock 64 175 475 minecraft:basalt
setblock 64 175 499 minecraft:basalt
setblock 65 175 475 minecraft:magma_block
fill 65 175 476 65 176 476 minecraft:basalt
setblock 65 175 484 minecraft:magma_block
fill 65 175 485 65 180 485 minecraft:basalt
fill 65 175 489 65 181 489 minecraft:basalt
setblock 65 175 490 minecraft:magma_block
setblock 65 175 499 minecraft:magma_block
fill 66 175 474 67 175 474 minecraft:basalt
fill 66 175 482 66 181 482 minecraft:basalt
fill 66 175 492 66 181 492 minecraft:basalt
fill 66 175 500 68 175 500 minecraft:basalt
fill 67 175 473 68 175 473 minecraft:basalt
fill 67 175 481 67 181 481 minecraft:basalt
fill 67 175 493 67 181 493 minecraft:basalt
setblock 67 175 501 minecraft:basalt
setblock 68 175 480 minecraft:magma_block
fill 68 175 494 68 181 494 minecraft:basalt
setblock 68 175 501 minecraft:magma_block
fill 68 175 502 69 176 504 minecraft:quartz_block
fill 69 175 478 69 181 479 minecraft:basalt
fill 69 175 495 69 181 496 minecraft:basalt
fill 70 175 472 71 175 472 minecraft:basalt
setblock 70 175 502 minecraft:basalt
fill 70 175 503 75 175 503 minecraft:quartz_block
fill 71 175 478 72 181 478 minecraft:basalt
fill 71 175 496 72 181 496 minecraft:basalt
fill 72 175 477 72 181 477 minecraft:basalt
fill 72 175 504 76 175 504 minecraft:quartz_block
setblock 74 175 472 minecraft:magma_block
setblock 74 175 502 minecraft:magma_block
fill 75 175 472 78 175 472 minecraft:basalt
fill 75 175 497 75 181 497 minecraft:basalt
fill 75 175 502 78 175 502 minecraft:basalt
fill 76 175 478 78 180 478 minecraft:basalt
fill 76 175 496 78 180 496 minecraft:basalt
fill 78 175 504 79 223 504 minecraft:quartz_block
fill 79 175 479 79 181 479 minecraft:basalt
fill 79 175 495 79 181 495 minecraft:basalt
fill 79 175 501 81 175 501 minecraft:basalt
setblock 80 175 473 minecraft:magma_block
fill 80 175 474 82 175 474 minecraft:basalt
fill 80 175 480 81 180 480 minecraft:basalt
setblock 80 175 494 minecraft:magma_block
setblock 81 175 473 minecraft:basalt
fill 81 175 481 81 181 481 minecraft:basalt
fill 81 175 493 81 181 493 minecraft:basalt
fill 81 175 500 82 175 500 minecraft:basalt
fill 82 175 475 82 176 475 minecraft:basalt
fill 82 175 482 82 181 482 minecraft:basalt
fill 82 175 492 82 181 492 minecraft:basalt
fill 82 175 499 82 176 499 minecraft:basalt
setblock 83 175 475 minecraft:magma_block
setblock 83 175 484 minecraft:magma_block
fill 83 175 485 84 180 485 minecraft:basalt
fill 83 175 489 83 181 489 minecraft:basalt
setblock 83 175 490 minecraft:magma_block
setblock 83 175 499 minecraft:magma_block
fill 84 175 475 84 175 476 minecraft:basalt
fill 84 175 488 84 181 488 minecraft:basalt
fill 84 175 498 84 175 499 minecraft:basalt
setblock 85 175 476 minecraft:basalt
fill 85 175 497 85 175 498 minecraft:basalt
setblock 86 175 477 minecraft:magma_block
setblock 86 175 497 minecraft:basalt
fill 87 175 479 87 175 480 minecraft:basalt
fill 87 175 494 87 175 495 minecraft:basalt
setblock 88 175 480 minecraft:basalt
setblock 88 175 494 minecraft:basalt
fill 60 176 483 61 176 483 minecraft:basalt
setblock 61 176 480 minecraft:basalt
setblock 61 176 481 minecraft:magma_block
fill 61 176 482 61 177 482 minecraft:basalt
fill 61 176 491 61 177 492 minecraft:basalt
setblock 61 176 493 minecraft:magma_block
setblock 61 176 494 minecraft:basalt
setblock 64 176 477 minecraft:magma_block
fill 64 176 478 64 177 478 minecraft:basalt
fill 64 176 501 67 176 504 minecraft:quartz_block
fill 65 176 484 66 176 484 minecraft:basalt
fill 65 176 486 65 180 488 minecraft:basalt
fill 65 176 490 66 176 490 minecraft:basalt
setblock 65 176 498 minecraft:basalt
fill 65 176 500 66 177 500 minecraft:quartz_block
fill 66 176 483 66 181 483 minecraft:basalt
fill 66 176 491 66 181 491 minecraft:basalt
setblock 67 176 474 minecraft:basalt
setblock 67 176 482 minecraft:magma_block
fill 67 176 492 67 181 492 minecraft:basalt
setblock 67 176 500 minecraft:magma_block
fill 68 176 480 68 180 481 minecraft:basalt
fill 68 176 493 68 180 493 minecraft:basalt
setblock 68 176 500 minecraft:basalt
fill 68 176 501 69 176 501 minecraft:quartz_block
setblock 69 176 480 minecraft:basalt
fill 69 176 494 69 181 494 minecraft:basalt
fill 70 176 479 71 181 479 minecraft:basalt
fill 70 176 495 71 180 495 minecraft:basalt
fill 70 176 502 70 176 503 minecraft:quartz_block
fill 73 176 473 75 176 473 minecraft:basalt
fill 73 176 478 75 181 478 minecraft:basalt
fill 73 176 496 75 181 496 minecraft:basalt
setblock 73 176 501 minecraft:magma_block
fill 74 176 501 75 176 501 minecraft:basalt
setblock 76 176 473 minecraft:magma_block
fill 77 176 479 78 181 479 minecraft:basalt
fill 77 176 495 78 181 495 minecraft:basalt
fill 79 176 480 79 181 480 minecraft:basalt
fill 79 176 494 80 181 494 minecraft:basalt
fill 80 176 474 81 176 474 minecraft:basalt
fill 80 176 481 80 181 481 minecraft:basalt
fill 80 176 493 80 181 493 minecraft:basalt
setblock 81 176 482 minecraft:basalt
fill 81 176 492 81 181 492 minecraft:basalt
setblock 81 176 500 minecraft:basalt
setblock 82 176 483 minecraft:magma_block
fill 82 176 484 83 181 484 minecraft:basalt
fill 82 176 490 82 181 491 minecraft:basalt
fill 83 176 486 83 180 488 minecraft:basalt
fill 83 176 490 83 181 490 minecraft:basalt
setblock 87 176 480 minecraft:basalt
setblock 87 176 494 minecraft:basalt
fill 88 176 481 88 223 482 minecraft:quartz_block
setblock 88 176 484 minecraft:magma_block
setblock 88 176 486 minecraft:basalt
setblock 88 176 487 minecraft:magma_block
setblock 88 176 488 minecraft:basalt
setblock 88 176 490 minecraft:magma_block
setblock 50 177 466 minecraft:light[level=14]
setblock 50 177 474 minecraft:light[level=14]
setblock 50 177 482 minecraft:light[level=14]
setblock 50 177 490 minecraft:light[level=14]
setblock 50 177 498 minecraft:light[level=14]
setblock 58 177 466 minecraft:light[level=14]
setblock 58 177 474 minecraft:light[level=14]
setblock 58 177 482 minecraft:light[level=14]
setblock 58 177 490 minecraft:light[level=14]
setblock 58 177 498 minecraft:light[level=14]
fill 58 177 504 61 177 504 minecraft:quartz_block
fill 59 177 502 66 177 503 minecraft:quartz_block
fill 60 177 500 64 177 501 minecraft:quartz_block
setblock 61 177 483 minecraft:basalt
setblock 63 177 479 minecraft:magma_block
fill 63 177 480 63 178 480 minecraft:basalt
fill 64 177 504 66 177 504 minecraft:quartz_block
fill 65 177 484 65 181 484 minecraft:basalt
fill 65 177 490 65 181 490 minecraft:basalt
fill 65 177 501 66 177 501 minecraft:quartz_block
setblock 66 177 466 minecraft:light[level=14]
setblock 66 177 474 minecraft:light[level=14]
setblock 66 177 484 minecraft:magma_block
fill 66 177 485 66 181 486 minecraft:basalt
setblock 66 177 487 minecraft:magma_block
fill 66 177 488 66 181 489 minecraft:basalt
setblock 66 177 490 minecraft:magma_block
fill 67 177 482 67 181 483 minecraft:basalt
fill 67 177 491 67 181 491 minecraft:basalt
setblock 69 177 474 minecraft:magma_block
setblock 69 177 480 minecraft:magma_block
setblock 70 177 474 minecraft:basalt
fill 70 177 480 70 181 480 minecraft:basalt
fill 70 177 494 70 181 494 minecraft:basalt
setblock 71 177 500 minecraft:basalt
setblock 72 177 479 minecraft:magma_block
fill 72 177 495 76 177 495 minecraft:basalt
setblock 72 177 500 minecraft:magma_block
fill 73 177 479 76 180 479 minecraft:basalt
setblock 74 177 466 minecraft:light[level=14]
setblock 74 177 482 minecraft:light[level=14]
setblock 74 177 490 minecraft:light[level=14]
fill 75 177 474 77 177 474 minecraft:basalt
setblock 78 177 474 minecraft:magma_block
setblock 78 177 480 minecraft:magma_block
fill 78 177 494 78 181 494 minecraft:basalt
setblock 81 177 482 minecraft:magma_block
fill 81 177 483 82 181 483 minecraft:basalt
setblock 81 177 491 minecraft:magma_block
setblock 82 177 466 minecraft:light[level=14]
setblock 82 177 474 minecraft:light[level=14]
fill 82 177 485 82 181 489 minecraft:basalt
setblock 84 177 478 minecraft:magma_block
setblock 84 177 496 minecraft:magma_block
setblock 87 177 483 minecraft:magma_block
fill 87 177 484 87 177 485 minecraft:basalt
setblock 87 177 486 minecraft:magma_block
fill 87 177 487 87 178 488 minecraft:basalt
setblock 87 177 489 minecraft:magma_block
setblock 87 177 490 minecraft:basalt
setblock 87 177 492 minecraft:magma_block
fill 88 177 489 88 223 490 minecraft:quartz_block
fill 47 178 468 47 185 468 minecraft:light_gray_concrete
fill 47 178 476 47 185 476 minecraft:light_gray_concrete
fill 47 178 484 47 185 484 minecraft:light_gray_concrete
fill 47 178 492 47 185 492 minecraft:light_gray_concrete
fill 47 178 500 47 185 500 minecraft:light_gray_concrete
fill 50 178 505 50 185 505 minecraft:light_gray_concrete
fill 51 178 504 53 179 504 minecraft:quartz_block
fill 52 178 503 61 178 503 minecraft:quartz_block
fill 53 178 501 61 178 502 minecraft:quartz_block
fill 54 178 463 54 185 463 minecraft:light_gray_concrete
fill 54 178 500 62 178 500 minecraft:quartz_block
fill 56 178 504 60 178 504 minecraft:quartz_block
fill 58 178 505 58 185 505 minecraft:light_gray_concrete
fill 62 178 463 62 185 463 minecraft:light_gray_concrete
setblock 62 178 483 minecraft:basalt
setblock 62 178 484 minecraft:magma_block
fill 62 178 489 62 179 489 minecraft:basalt
setblock 62 178 490 minecraft:magma_block
setblock 62 178 491 minecraft:basalt
setblock 62 178 501 minecraft:quartz_block
setblock 63 178 481 minecraft:basalt
setblock 63 178 493 minecraft:basalt
fill 63 178 499 68 178 499 minecraft:black_concrete
setblock 65 178 478 minecraft:basalt
fill 66 178 484 67 181 484 minecraft:basalt
fill 66 178 487 66 181 487 minecraft:basalt
fill 66 178 490 67 181 490 minecraft:basalt
fill 66 178 505 66 185 505 minecraft:light_gray_concrete
fill 67 178 485 67 181 485 minecraft:basalt
fill 67 178 489 67 181 489 minecraft:basalt
setblock 68 178 476 minecraft:magma_block
setblock 68 178 482 minecraft:magma_block
fill 68 178 483 68 181 483 minecraft:basalt
setblock 68 178 491 minecraft:magma_block
fill 68 178 492 68 181 492 minecraft:basalt
fill 69 178 475 70 178 475 minecraft:basalt
fill 69 178 480 69 181 481 minecraft:basalt
fill 69 178 493 70 181 493 minecraft:basalt
fill 69 178 499 70 178 499 minecraft:basalt
fill 70 178 463 70 185 463 minecraft:light_gray_concrete
fill 70 178 481 70 181 481 minecraft:basalt
setblock 71 178 475 minecraft:magma_block
fill 71 178 480 72 180 480 minecraft:basalt
fill 71 178 494 72 181 494 minecraft:basalt
setblock 71 178 499 minecraft:magma_block
fill 72 178 479 72 181 479 minecraft:basalt
fill 72 178 495 73 181 495 minecraft:basalt
setblock 73 178 474 minecraft:basalt
setblock 74 178 474 minecraft:magma_block
setblock 74 178 495 minecraft:magma_block
fill 74 178 500 75 178 500 minecraft:basalt
fill 74 178 505 74 185 505 minecraft:light_gray_concrete
setblock 75 178 474 minecraft:basalt
fill 75 178 495 76 181 495 minecraft:basalt
fill 76 178 480 78 181 480 minecraft:basalt
fill 76 178 494 76 181 494 minecraft:basalt
setblock 77 178 494 minecraft:magma_block
fill 78 178 463 78 185 463 minecraft:light_gray_concrete
fill 78 178 481 79 181 481 minecraft:basalt
fill 78 178 493 79 181 493 minecraft:basalt
setblock 80 178 476 minecraft:basalt
fill 80 178 482 80 180 483 minecraft:basalt
fill 80 178 491 80 180 492 minecraft:basalt
setblock 80 178 498 minecraft:basalt
fill 81 178 477 82 178 477 minecraft:basalt
fill 81 178 482 81 181 482 minecraft:basalt
fill 81 178 484 81 181 485 minecraft:basalt
fill 81 178 489 81 181 491 minecraft:basalt
fill 82 178 505 82 185 505 minecraft:light_gray_concrete
fill 86 178 463 86 185 463 minecraft:light_gray_concrete
setblock 86 178 482 minecraft:magma_block
fill 86 178 483 86 178 484 minecraft:basalt
setblock 86 178 485 minecraft:magma_block
fill 86 178 486 86 178 490 minecraft:basalt
setblock 86 178 491 minecraft:magma_block
setblock 86 178 492 minecraft:basalt
setblock 87 178 486 minecraft:basalt
fill 89 178 468 89 185 468 minecraft:light_gray_concrete
fill 89 178 476 89 185 476 minecraft:light_gray_concrete
fill 89 178 484 89 185 484 minecraft:light_gray_concrete
fill 89 178 492 89 185 492 minecraft:light_gray_concrete
fill 89 178 500 89 185 500 minecraft:light_gray_concrete
fill 48 179 498 52 179 501 minecraft:quartz_block
fill 48 179 504 50 179 504 minecraft:quartz_block
fill 49 179 502 55 179 503 minecraft:quartz_block
fill 50 179 497 52 180 497 minecraft:quartz_block
fill 51 179 496 52 180 496 minecraft:quartz_block
fill 53 179 500 56 179 501 minecraft:quartz_block
setblock 56 179 502 minecraft:quartz_block
setblock 57 179 500 minecraft:quartz_block
fill 59 179 499 65 179 499 minecraft:black_concrete
setblock 62 179 486 minecraft:basalt
setblock 64 179 493 minecraft:basalt
setblock 65 179 479 minecraft:basalt
setblock 67 179 478 minecraft:magma_block
fill 67 179 486 67 181 486 minecraft:basalt
setblock 67 179 487 minecraft:magma_block
fill 67 179 488 67 181 488 minecraft:basalt
setblock 67 179 496 minecraft:magma_block
fill 68 179 482 69 181 482 minecraft:basalt
fill 68 179 484 68 180 484 minecraft:basalt
fill 68 179 490 68 180 491 minecraft:basalt
fill 69 179 492 69 181 492 minecraft:basalt
setblock 69 179 498 minecraft:basalt
setblock 70 179 498 minecraft:magma_block
fill 71 179 481 71 181 481 minecraft:basalt
fill 71 179 493 71 181 493 minecraft:basalt
fill 73 179 475 75 179 475 minecraft:basalt
fill 73 179 480 75 181 480 minecraft:basalt
setblock 73 179 494 minecraft:magma_block
fill 73 179 499 75 179 499 minecraft:basalt
fill 74 179 494 74 180 495 minecraft:basalt
fill 75 179 494 75 181 494 minecraft:basalt
setblock 76 179 475 minecraft:magma_block
setblock 76 179 499 minecraft:magma_block
fill 77 179 481 77 180 481 minecraft:basalt
fill 77 179 493 77 180 494 minecraft:basalt
setblock 78 179 498 minecraft:basalt
fill 79 179 482 79 181 482 minecraft:basalt
setblock 79 179 492 minecraft:magma_block
setblock 79 179 498 minecraft:magma_block
fill 80 179 484 80 181 484 minecraft:basalt
fill 80 179 490 80 181 490 minecraft:basalt
fill 81 179 486 81 181 488 minecraft:basalt
setblock 82 179 479 minecraft:magma_block
setblock 82 179 496 minecraft:basalt
fill 83 179 479 83 179 480 minecraft:basalt
setblock 84 179 481 minecraft:basalt
setblock 84 179 493 minecraft:basalt
setblock 85 179 484 minecraft:magma_block
fill 85 179 485 86 179 485 minecraft:basalt
setblock 85 179 490 minecraft:magma_block
fill 86 179 486 86 179 489 minecraft:basalt
fill 48 180 492 52 180 493 minecraft:quartz_block
fill 48 180 496 49 180 501 minecraft:quartz_block
fill 49 180 494 52 180 495 minecraft:quartz_block
fill 50 180 491 52 181 491 minecraft:quartz_block
setblock 50 180 496 minecraft:quartz_block
fill 50 180 498 50 180 500 minecraft:quartz_block
fill 51 180 498 51 180 499 minecraft:quartz_block
setblock 52 180 498 minecraft:quartz_block
fill 53 180 498 53 181 499 minecraft:black_concrete
fill 54 180 499 61 180 499 minecraft:black_concrete
fill 62 180 464 62 181 466 minecraft:iron_block
fill 63 180 485 63 180 486 minecraft:basalt
setblock 63 180 487 minecraft:magma_block
fill 63 180 488 63 180 489 minecraft:basalt
setblock 65 180 493 minecraft:basalt
setblock 66 180 480 minecraft:magma_block
fill 67 180 487 68 180 487 minecraft:basalt
fill 68 180 485 68 180 486 minecraft:basalt
fill 68 180 488 68 180 489 minecraft:basalt
setblock 69 180 477 minecraft:basalt
fill 69 180 483 69 181 483 minecraft:basalt
setblock 69 180 491 minecraft:magma_block
setblock 69 180 497 minecraft:magma_block
fill 70 180 482 70 181 482 minecraft:basalt
fill 70 180 492 70 181 492 minecraft:basalt
setblock 71 180 497 minecraft:basalt
fill 72 180 476 73 180 476 minecraft:basalt
setblock 72 180 481 minecraft:magma_block
setblock 72 180 493 minecraft:magma_block
fill 72 180 498 74 180 498 minecraft:basalt
fill 73 180 481 76 180 481 minecraft:basalt
fill 73 180 493 73 180 494 minecraft:basalt
fill 74 180 493 76 180 493 minecraft:basalt
fill 75 180 476 76 180 476 minecraft:basalt
setblock 75 180 498 minecraft:magma_block
setblock 77 180 497 minecraft:basalt
setblock 78 180 482 minecraft:magma_block
fill 78 180 492 79 181 492 minecraft:basalt
setblock 78 180 497 minecraft:magma_block
fill 79 180 483 79 181 483 minecraft:basalt
fill 79 180 491 79 181 491 minecraft:basalt
setblock 80 180 478 minecraft:basalt
fill 80 180 485 80 180 489 minecraft:basalt
setblock 82 180 494 minecraft:basalt
setblock 84 180 483 minecraft:magma_block
setblock 84 180 484 minecraft:basalt
setblock 84 180 492 minecraft:magma_block
setblock 85 180 485 minecraft:basalt
fill 48 181 488 49 182 493 minecraft:quartz_block
fill 49 181 487 52 182 487 minecraft:quartz_block
fill 49 181 494 50 181 494 minecraft:quartz_block
fill 50 181 488 52 181 490 minecraft:quartz_block
fill 50 181 492 51 181 493 minecraft:quartz_block
fill 52 181 486 52 182 486 minecraft:quartz_block
setblock 52 181 492 minecraft:quartz_block
fill 53 181 493 53 181 497 minecraft:black_concrete
fill 54 181 499 55 181 499 minecraft:black_concrete
fill 64 181 485 64 181 489 minecraft:basalt
setblock 65 181 482 minecraft:magma_block
setblock 65 181 483 minecraft:basalt
setblock 65 181 485 minecraft:magma_block
fill 65 181 486 65 181 487 minecraft:basalt
setblock 65 181 488 minecraft:magma_block
setblock 65 181 491 minecraft:magma_block
setblock 65 181 492 minecraft:basalt
setblock 67 181 487 minecraft:basalt
setblock 67 181 494 minecraft:basalt
setblock 68 181 480 minecraft:basalt
setblock 68 181 481 minecraft:magma_block
fill 68 181 484 69 181 484 minecraft:magma_block
setblock 68 181 485 minecraft:basalt
fill 68 181 486 68 181 488 minecraft:magma_block
setblock 68 181 489 minecraft:basalt
fill 68 181 490 69 181 490 minecraft:magma_block
fill 68 181 491 69 181 491 minecraft:basalt
setblock 68 181 493 minecraft:magma_block
fill 69 181 485 69 181 486 minecraft:magma_block
fill 69 181 488 69 181 489 minecraft:magma_block
setblock 70 181 483 minecraft:magma_block
setblock 70 181 491 minecraft:magma_block
fill 70 181 495 70 181 496 minecraft:basalt
setblock 71 181 480 minecraft:magma_block
fill 71 181 482 73 181 482 minecraft:magma_block
fill 71 181 492 73 181 492 minecraft:magma_block
setblock 71 181 495 minecraft:magma_block
fill 72 181 480 72 181 481 minecraft:basalt
setblock 72 181 493 minecraft:basalt
fill 72 181 497 73 181 497 minecraft:basalt
setblock 73 181 479 minecraft:basalt
fill 73 181 481 75 181 481 minecraft:magma_block
fill 73 181 493 75 181 493 minecraft:magma_block
setblock 73 181 494 minecraft:basalt
setblock 74 181 479 minecraft:magma_block
setblock 74 181 494 minecraft:magma_block
setblock 74 181 495 minecraft:basalt
setblock 74 181 497 minecraft:magma_block
fill 75 181 479 76 181 479 minecraft:basalt
fill 75 181 482 77 181 482 minecraft:magma_block
fill 75 181 492 77 181 492 minecraft:magma_block
setblock 76 181 478 minecraft:basalt
setblock 76 181 481 minecraft:basalt
setblock 76 181 493 minecraft:basalt
fill 76 181 496 76 181 497 minecraft:basalt
setblock 77 181 478 minecraft:magma_block
setblock 77 181 481 minecraft:magma_block
setblock 77 181 493 minecraft:magma_block
setblock 77 181 494 minecraft:basalt
setblock 77 181 496 minecraft:magma_block
setblock 78 181 478 minecraft:basalt
setblock 78 181 482 minecraft:basalt
setblock 78 181 483 minecraft:magma_block
setblock 78 181 491 minecraft:magma_block
fill 78 181 496 79 181 496 minecraft:basalt
fill 79 181 484 79 181 486 minecraft:magma_block
fill 79 181 488 79 181 490 minecraft:magma_block
setblock 80 181 480 minecraft:magma_block
setblock 80 181 482 minecraft:basalt
setblock 80 181 483 minecraft:magma_block
setblock 80 181 485 minecraft:basalt
fill 80 181 486 80 181 489 minecraft:magma_block
setblock 80 181 491 minecraft:basalt
setblock 80 181 492 minecraft:magma_block
setblock 80 181 495 minecraft:magma_block
setblock 81 181 480 minecraft:basalt
setblock 83 181 482 minecraft:magma_block
setblock 83 181 483 minecraft:basalt
setblock 83 181 485 minecraft:magma_block
fill 83 181 486 83 181 487 minecraft:basalt
setblock 83 181 488 minecraft:magma_block
setblock 83 181 491 minecraft:magma_block
setblock 83 181 492 minecraft:basalt
setblock 84 181 485 minecraft:basalt
setblock 84 181 489 minecraft:basalt
fill 48 182 464 48 183 469 minecraft:quartz_block
fill 48 182 472 49 182 477 minecraft:quartz_block
fill 48 182 480 49 182 485 minecraft:quartz_block
fill 48 182 496 49 182 501 minecraft:quartz_block
fill 48 182 504 53 183 504 minecraft:quartz_block
fill 49 182 465 49 182 471 minecraft:quartz_block
fill 49 182 478 49 184 479 minecraft:quartz_block
fill 49 182 486 51 182 486 minecraft:quartz_block
fill 49 182 494 49 182 495 minecraft:quartz_block
fill 49 182 502 49 182 503 minecraft:quartz_block
fill 50 182 465 87 182 465 minecraft:quartz_block
fill 50 182 482 51 182 485 minecraft:quartz_block
fill 50 182 488 52 182 488 minecraft:quartz_block
fill 50 182 503 88 182 503 minecraft:quartz_block
fill 51 182 464 56 183 464 minecraft:quartz_block
fill 52 182 483 52 182 485 minecraft:quartz_block
fill 53 182 489 53 182 495 minecraft:black_concrete
fill 56 182 504 61 183 504 minecraft:quartz_block
fill 59 182 464 64 183 464 minecraft:quartz_block
fill 64 182 504 69 183 504 minecraft:quartz_block
fill 67 182 464 72 183 464 minecraft:quartz_block
fill 72 182 504 77 183 504 minecraft:quartz_block
fill 75 182 464 80 183 464 minecraft:quartz_block
fill 80 182 504 85 183 504 minecraft:quartz_block
fill 83 182 464 88 183 464 minecraft:quartz_block
fill 87 182 466 87 182 502 minecraft:quartz_block
fill 88 182 467 88 183 472 minecraft:quartz_block
fill 88 182 475 88 183 480 minecraft:quartz_block
fill 88 182 483 88 183 488 minecraft:quartz_block
fill 88 182 491 88 183 496 minecraft:quartz_block
fill 88 182 499 88 183 502 minecraft:quartz_block
fill 88 182 504 88 183 504 minecraft:quartz_block
fill 48 183 472 48 184 477 minecraft:quartz_block
fill 48 183 480 48 183 485 minecraft:quartz_block
fill 48 183 488 48 183 493 minecraft:quartz_block
fill 48 183 496 48 183 501 minecraft:quartz_block
fill 49 183 477 49 184 477 minecraft:quartz_block
fill 49 183 480 52 183 484 minecraft:quartz_block
fill 50 183 478 52 184 479 minecraft:quartz_block
fill 53 183 485 53 183 490 minecraft:black_concrete
setblock 88 183 503 minecraft:quartz_block
fill 49 184 471 49 184 476 minecraft:quartz_block
fill 50 184 472 50 184 477 minecraft:quartz_block
fill 50 184 480 52 184 480 minecraft:quartz_block
fill 51 184 473 52 184 477 minecraft:quartz_block
fill 53 184 481 53 184 486 minecraft:black_concrete
fill 48 185 464 48 185 469 minecraft:quartz_block
fill 48 185 472 52 185 474 minecraft:quartz_block
fill 49 185 465 51 185 471 minecraft:quartz_block
fill 50 185 475 52 185 475 minecraft:quartz_block
setblock 50 185 482 minecraft:light[level=14]
setblock 50 185 490 minecraft:light[level=14]
setblock 50 185 498 minecraft:light[level=14]
fill 52 185 466 52 185 471 minecraft:quartz_block
setblock 52 185 476 minecraft:quartz_block
fill 53 185 468 53 186 468 minecraft:quartz_block
fill 53 185 477 53 185 482 minecraft:black_concrete
setblock 58 185 466 minecraft:light[level=14]
setblock 58 185 474 minecraft:light[level=14]
setblock 58 185 482 minecraft:light[level=14]
setblock 58 185 490 minecraft:light[level=14]
setblock 58 185 498 minecraft:light[level=14]
setblock 66 185 466 minecraft:light[level=14]
setblock 66 185 474 minecraft:light[level=14]
setblock 66 185 482 minecraft:light[level=14]
setblock 66 185 490 minecraft:light[level=14]
setblock 66 185 498 minecraft:light[level=14]
setblock 74 185 466 minecraft:light[level=14]
setblock 74 185 474 minecraft:light[level=14]
setblock 74 185 482 minecraft:light[level=14]
setblock 74 185 490 minecraft:light[level=14]
setblock 74 185 498 minecraft:light[level=14]
setblock 82 185 466 minecraft:light[level=14]
setblock 82 185 474 minecraft:light[level=14]
setblock 82 185 482 minecraft:light[level=14]
setblock 82 185 490 minecraft:light[level=14]
setblock 82 185 498 minecraft:light[level=14]
fill 47 186 468 47 191 468 minecraft:sea_lantern
fill 47 186 476 47 191 476 minecraft:sea_lantern
fill 47 186 484 47 191 484 minecraft:sea_lantern
fill 47 186 492 47 191 492 minecraft:sea_lantern
fill 47 186 500 47 191 500 minecraft:sea_lantern
fill 48 186 464 48 186 467 minecraft:quartz_block
fill 49 186 465 58 186 467 minecraft:quartz_block
fill 50 186 468 52 186 468 minecraft:quartz_block
fill 50 186 505 50 191 505 minecraft:sea_lantern
fill 51 186 464 56 186 464 minecraft:quartz_block
fill 51 186 469 52 186 469 minecraft:quartz_block
setblock 52 186 470 minecraft:quartz_block
fill 53 186 472 53 186 479 minecraft:black_concrete
fill 54 186 463 54 191 463 minecraft:sea_lantern
fill 54 186 468 59 186 468 minecraft:quartz_block
fill 58 186 505 58 191 505 minecraft:sea_lantern
fill 59 186 467 59 187 467 minecraft:quartz_block
fill 62 186 463 62 191 463 minecraft:sea_lantern
fill 66 186 505 66 191 505 minecraft:sea_lantern
fill 70 186 463 70 191 463 minecraft:sea_lantern
fill 74 186 505 74 191 505 minecraft:sea_lantern
fill 78 186 463 78 191 463 minecraft:sea_lantern
fill 82 186 505 82 191 505 minecraft:sea_lantern
fill 86 186 463 86 191 463 minecraft:sea_lantern
fill 89 186 468 89 191 468 minecraft:sea_lantern
fill 89 186 476 89 191 476 minecraft:sea_lantern
fill 89 186 484 89 191 484 minecraft:sea_lantern
fill 89 186 492 89 191 492 minecraft:sea_lantern
fill 89 186 500 89 191 500 minecraft:sea_lantern
fill 53 187 469 53 187 474 minecraft:black_concrete
fill 54 187 464 56 187 464 minecraft:quartz_block
fill 54 187 469 57 188 469 minecraft:black_concrete
fill 55 187 465 63 187 466 minecraft:quartz_block
fill 56 187 467 58 187 467 minecraft:quartz_block
fill 57 187 468 64 187 468 minecraft:quartz_block
fill 59 187 464 63 187 464 minecraft:quartz_block
fill 60 187 467 63 187 467 minecraft:quartz_block
fill 58 188 469 61 188 469 minecraft:black_concrete
fill 60 188 464 64 188 464 minecraft:quartz_block
fill 61 188 465 68 188 466 minecraft:quartz_block
fill 62 188 467 68 188 468 minecraft:quartz_block
fill 67 188 464 68 189 464 minecraft:quartz_block
fill 60 189 469 65 189 469 minecraft:black_concrete
fill 66 189 465 71 189 468 minecraft:quartz_block
fill 69 189 464 72 189 464 minecraft:quartz_block
fill 72 189 465 72 190 467 minecraft:quartz_block
fill 64 190 469 69 190 469 minecraft:black_concrete
fill 70 190 464 71 190 468 minecraft:quartz_block
setblock 72 190 464 minecraft:quartz_block
fill 72 190 468 76 190 468 minecraft:quartz_block
fill 73 190 465 76 190 467 minecraft:quartz_block
fill 75 190 464 78 190 464 minecraft:quartz_block
fill 77 190 465 77 191 466 minecraft:quartz_block
fill 68 191 469 73 191 469 minecraft:black_concrete
fill 74 191 467 82 191 468 minecraft:quartz_block
fill 75 191 465 76 191 466 minecraft:quartz_block
fill 76 191 464 80 191 464 minecraft:quartz_block
fill 78 191 465 83 191 466 minecraft:quartz_block
fill 83 191 464 85 192 464 minecraft:quartz_block
fill 83 191 467 83 192 467 minecraft:quartz_block
fill 84 191 465 84 192 465 minecraft:quartz_block
fill 47 192 468 47 199 468 minecraft:light_gray_concrete
fill 47 192 476 47 199 476 minecraft:light_gray_concrete
fill 47 192 484 47 199 484 minecraft:light_gray_concrete
fill 47 192 492 47 199 492 minecraft:light_gray_concrete
fill 47 192 500 47 199 500 minecraft:light_gray_concrete
fill 50 192 505 50 199 505 minecraft:light_gray_concrete
fill 54 192 463 54 199 463 minecraft:light_gray_concrete
fill 58 192 505 58 199 505 minecraft:light_gray_concrete
fill 62 192 463 62 199 463 minecraft:light_gray_concrete
fill 66 192 505 66 199 505 minecraft:light_gray_concrete
fill 70 192 463 70 199 463 minecraft:light_gray_concrete
fill 71 192 469 77 192 469 minecraft:black_concrete
fill 74 192 505 74 199 505 minecraft:light_gray_concrete
fill 78 192 463 78 199 463 minecraft:light_gray_concrete
fill 79 192 468 88 192 468 minecraft:quartz_block
fill 80 192 466 82 192 467 minecraft:quartz_block
fill 81 192 465 83 192 465 minecraft:quartz_block
fill 82 192 505 82 199 505 minecraft:light_gray_concrete
fill 83 192 466 87 192 466 minecraft:quartz_block
fill 84 192 467 88 192 467 minecraft:quartz_block
fill 84 192 469 85 192 472 minecraft:quartz_block
fill 85 192 465 87 192 465 minecraft:quartz_block
fill 86 192 463 86 199 463 minecraft:light_gray_concrete
fill 86 192 464 88 192 464 minecraft:quartz_block
fill 86 192 469 86 193 471 minecraft:quartz_block
fill 87 192 469 88 193 470 minecraft:quartz_block
fill 89 192 468 89 199 468 minecraft:light_gray_concrete
fill 89 192 476 89 199 476 minecraft:light_gray_concrete
fill 89 192 484 89 199 484 minecraft:light_gray_concrete
fill 89 192 492 89 199 492 minecraft:light_gray_concrete
fill 89 192 500 89 199 500 minecraft:light_gray_concrete
setblock 50 193 466 minecraft:light[level=14]
setblock 50 193 474 minecraft:light[level=14]
setblock 50 193 482 minecraft:light[level=14]
setblock 50 193 490 minecraft:light[level=14]
setblock 50 193 498 minecraft:light[level=14]
setblock 58 193 466 minecraft:light[level=14]
setblock 58 193 474 minecraft:light[level=14]
setblock 58 193 482 minecraft:light[level=14]
setblock 58 193 490 minecraft:light[level=14]
setblock 58 193 498 minecraft:light[level=14]
setblock 66 193 466 minecraft:light[level=14]
setblock 66 193 474 minecraft:light[level=14]
setblock 66 193 482 minecraft:light[level=14]
setblock 66 193 490 minecraft:light[level=14]
setblock 66 193 498 minecraft:light[level=14]
setblock 74 193 466 minecraft:light[level=14]
setblock 74 193 474 minecraft:light[level=14]
setblock 74 193 482 minecraft:light[level=14]
setblock 74 193 490 minecraft:light[level=14]
setblock 74 193 498 minecraft:light[level=14]
fill 75 193 469 83 193 469 minecraft:black_concrete
setblock 82 193 466 minecraft:light[level=14]
setblock 82 193 474 minecraft:light[level=14]
setblock 82 193 482 minecraft:light[level=14]
setblock 82 193 490 minecraft:light[level=14]
setblock 82 193 498 minecraft:light[level=14]
fill 83 193 470 83 194 470 minecraft:black_concrete
fill 84 193 470 85 193 477 minecraft:quartz_block
setblock 85 193 469 minecraft:quartz_block
fill 86 193 468 88 193 468 minecraft:quartz_block
fill 86 193 472 86 193 477 minecraft:quartz_block
fill 87 193 467 88 193 467 minecraft:quartz_block
fill 87 193 471 87 193 476 minecraft:quartz_block
fill 88 193 471 88 193 472 minecraft:quartz_block
fill 88 193 475 88 194 476 minecraft:quartz_block
fill 81 194 469 83 194 469 minecraft:black_concrete
fill 83 194 471 83 194 475 minecraft:black_concrete
fill 84 194 476 84 194 482 minecraft:quartz_block
fill 85 194 475 87 194 481 minecraft:quartz_block
fill 86 194 474 87 194 474 minecraft:quartz_block
fill 88 194 477 88 194 480 minecraft:quartz_block
fill 83 195 473 83 195 479 minecraft:black_concrete
fill 84 195 480 87 195 485 minecraft:quartz_block
fill 85 195 486 88 196 486 minecraft:quartz_block
fill 87 195 479 88 196 479 minecraft:quartz_block
fill 88 195 480 88 197 480 minecraft:quartz_block
fill 88 195 483 88 197 485 minecraft:quartz_block
fill 48 196 464 48 197 469 minecraft:quartz_block
fill 48 196 472 49 196 477 minecraft:quartz_block
fill 48 196 480 49 196 485 minecraft:quartz_block
fill 48 196 488 49 196 493 minecraft:quartz_block
fill 48 196 496 49 196 501 minecraft:quartz_block
fill 48 196 504 53 197 504 minecraft:quartz_block
fill 49 196 465 49 196 471 minecraft:quartz_block
fill 49 196 478 49 196 479 minecraft:quartz_block
fill 49 196 486 49 196 487 minecraft:quartz_block
fill 49 196 494 49 196 495 minecraft:quartz_block
fill 49 196 502 49 196 503 minecraft:quartz_block
fill 50 196 465 87 196 465 minecraft:quartz_block
fill 50 196 503 88 196 503 minecraft:quartz_block
fill 51 196 464 56 197 464 minecraft:quartz_block
fill 56 196 504 61 197 504 minecraft:quartz_block
fill 59 196 464 64 197 464 minecraft:quartz_block
fill 64 196 504 69 197 504 minecraft:quartz_block
fill 67 196 464 72 197 464 minecraft:quartz_block
fill 72 196 504 77 197 504 minecraft:quartz_block
fill 75 196 464 80 197 464 minecraft:quartz_block
fill 80 196 504 85 197 504 minecraft:quartz_block
fill 83 196 464 88 197 464 minecraft:quartz_block
fill 83 196 478 83 196 483 minecraft:black_concrete
fill 84 196 484 84 196 490 minecraft:quartz_block
fill 85 196 484 87 196 485 minecraft:quartz_block
fill 85 196 487 87 196 490 minecraft:quartz_block
fill 87 196 466 87 196 478 minecraft:quartz_block
fill 87 196 480 87 196 483 minecraft:quartz_block
fill 87 196 491 87 196 502 minecraft:quartz_block
fill 88 196 467 88 197 472 minecraft:quartz_block
fill 88 196 475 88 197 478 minecraft:quartz_block
fill 88 196 487 88 197 488 minecraft:quartz_block
fill 88 196 491 88 197 496 minecraft:quartz_block
fill 88 196 499 88 198 502 minecraft:quartz_block
fill 88 196 504 88 199 504 minecraft:quartz_block
fill 48 197 472 48 197 477 minecraft:quartz_block
fill 48 197 480 48 197 485 minecraft:quartz_block
fill 48 197 488 48 197 493 minecraft:quartz_block
fill 48 197 496 48 197 501 minecraft:quartz_block
fill 83 197 482 83 197 487 minecraft:black_concrete
fill 84 197 488 86 197 495 minecraft:quartz_block
fill 86 197 496 87 198 496 minecraft:quartz_block
fill 87 197 489 87 197 495 minecraft:quartz_block
fill 87 197 497 87 198 497 minecraft:quartz_block
setblock 88 197 479 minecraft:quartz_block
setblock 88 197 486 minecraft:quartz_block
fill 88 197 503 88 199 503 minecraft:quartz_block
fill 83 198 486 83 198 491 minecraft:black_concrete
fill 83 198 500 87 198 500 minecraft:quartz_block
fill 84 198 492 84 198 499 minecraft:quartz_block
fill 84 198 501 87 199 502 minecraft:quartz_block
fill 85 198 493 85 198 499 minecraft:quartz_block
fill 85 198 503 87 199 503 minecraft:quartz_block
fill 86 198 493 86 198 495 minecraft:quartz_block
fill 86 198 497 86 198 499 minecraft:quartz_block
fill 87 198 494 88 198 495 minecraft:quartz_block
fill 87 198 498 87 198 499 minecraft:quartz_block
setblock 88 198 496 minecraft:quartz_block
fill 77 199 500 83 199 501 minecraft:quartz_block
fill 78 199 502 83 199 503 minecraft:quartz_block
fill 80 199 504 85 199 504 minecraft:quartz_block
fill 83 199 489 83 199 496 minecraft:black_concrete
fill 84 199 498 84 199 500 minecraft:quartz_block
setblock 84 199 503 minecraft:quartz_block
fill 85 199 499 85 199 500 minecraft:quartz_block
setblock 86 199 500 minecraft:quartz_block
fill 88 199 501 88 199 502 minecraft:quartz_block
fill 47 200 468 47 205 468 minecraft:sea_lantern
fill 47 200 476 47 205 476 minecraft:sea_lantern
fill 47 200 484 47 205 484 minecraft:sea_lantern
fill 47 200 492 47 205 492 minecraft:sea_lantern
fill 47 200 500 47 205 500 minecraft:sea_lantern
fill 50 200 505 50 205 505 minecraft:sea_lantern
fill 54 200 463 54 205 463 minecraft:sea_lantern
fill 58 200 505 58 205 505 minecraft:sea_lantern
fill 62 200 463 62 205 463 minecraft:sea_lantern
fill 66 200 505 66 205 505 minecraft:sea_lantern
fill 70 200 463 70 205 463 minecraft:sea_lantern
fill 72 200 500 79 200 500 minecraft:quartz_block
fill 73 200 501 77 200 504 minecraft:quartz_block
fill 74 200 505 74 205 505 minecraft:sea_lantern
fill 78 200 463 78 205 463 minecraft:sea_lantern
fill 78 200 501 80 200 503 minecraft:quartz_block
fill 79 200 499 83 200 499 minecraft:black_concrete
fill 80 200 504 82 200 504 minecraft:quartz_block
fill 81 200 502 81 200 503 minecraft:quartz_block
fill 82 200 505 82 205 505 minecraft:sea_lantern
fill 83 200 494 83 200 498 minecraft:black_concrete
fill 86 200 463 86 205 463 minecraft:sea_lantern
fill 89 200 468 89 205 468 minecraft:sea_lantern
fill 89 200 476 89 205 476 minecraft:sea_lantern
fill 89 200 484 89 205 484 minecraft:sea_lantern
fill 89 200 492 89 205 492 minecraft:sea_lantern
fill 89 200 500 89 205 500 minecraft:sea_lantern
setblock 50 201 466 minecraft:light[level=14]
setblock 50 201 474 minecraft:light[level=14]
setblock 50 201 482 minecraft:light[level=14]
setblock 50 201 490 minecraft:light[level=14]
setblock 50 201 498 minecraft:light[level=14]
setblock 58 201 466 minecraft:light[level=14]
setblock 58 201 474 minecraft:light[level=14]
setblock 58 201 482 minecraft:light[level=14]
setblock 58 201 490 minecraft:light[level=14]
setblock 58 201 498 minecraft:light[level=14]
setblock 66 201 466 minecraft:light[level=14]
setblock 66 201 474 minecraft:light[level=14]
setblock 66 201 482 minecraft:light[level=14]
setblock 66 201 490 minecraft:light[level=14]
setblock 66 201 498 minecraft:light[level=14]
fill 68 201 500 69 202 504 minecraft:quartz_block
fill 70 201 500 74 201 503 minecraft:quartz_block
fill 72 201 504 76 201 504 minecraft:quartz_block
setblock 74 201 466 minecraft:light[level=14]
setblock 74 201 474 minecraft:light[level=14]
setblock 74 201 482 minecraft:light[level=14]
setblock 74 201 490 minecraft:light[level=14]
setblock 74 201 498 minecraft:light[level=14]
fill 75 201 499 82 201 499 minecraft:black_concrete
fill 75 201 502 75 201 503 minecraft:quartz_block
setblock 82 201 466 minecraft:light[level=14]
setblock 82 201 474 minecraft:light[level=14]
setblock 82 201 482 minecraft:light[level=14]
setblock 82 201 490 minecraft:light[level=14]
setblock 82 201 498 minecraft:light[level=14]
fill 64 202 501 67 202 504 minecraft:quartz_block
fill 65 202 500 67 202 500 minecraft:quartz_block
fill 70 202 500 70 202 503 minecraft:quartz_block
fill 71 202 499 76 202 499 minecraft:black_concrete
fill 58 203 504 61 203 504 minecraft:quartz_block
fill 59 203 502 66 203 503 minecraft:quartz_block
fill 60 203 500 66 203 501 minecraft:quartz_block
fill 64 203 504 66 203 504 minecraft:quartz_block
fill 67 203 499 72 203 499 minecraft:black_concrete
fill 51 204 504 53 205 504 minecraft:quartz_block
fill 52 204 503 61 204 503 minecraft:quartz_block
fill 53 204 501 61 204 502 minecraft:quartz_block
fill 54 204 500 62 204 500 minecraft:quartz_block
fill 56 204 504 60 204 504 minecraft:quartz_block
setblock 62 204 501 minecraft:quartz_block
fill 63 204 499 68 204 499 minecraft:black_concrete
fill 48 205 498 52 205 501 minecraft:quartz_block
fill 48 205 504 50 205 504 minecraft:quartz_block
fill 49 205 502 55 205 503 minecraft:quartz_block
fill 50 205 497 52 206 497 minecraft:quartz_block
fill 51 205 496 52 206 496 minecraft:quartz_block
fill 53 205 500 56 205 501 minecraft:quartz_block
setblock 56 205 502 minecraft:quartz_block
setblock 57 205 500 minecraft:quartz_block
fill 59 205 499 65 205 499 minecraft:black_concrete
fill 47 206 468 47 213 468 minecraft:light_gray_concrete
fill 47 206 476 47 213 476 minecraft:light_gray_concrete
fill 47 206 484 47 213 484 minecraft:light_gray_concrete
fill 47 206 492 47 213 492 minecraft:light_gray_concrete
fill 47 206 500 47 213 500 minecraft:light_gray_concrete
fill 48 206 492 52 206 493 minecraft:quartz_block
fill 48 206 496 49 206 501 minecraft:quartz_block
fill 49 206 494 52 206 495 minecraft:quartz_block
fill 50 206 491 52 207 491 minecraft:quartz_block
setblock 50 206 496 minecraft:quartz_block
fill 50 206 498 50 206 500 minecraft:quartz_block
fill 50 206 505 50 213 505 minecraft:light_gray_concrete
fill 51 206 498 51 206 499 minecraft:quartz_block
setblock 52 206 498 minecraft:quartz_block
fill 53 206 498 53 207 499 minecraft:black_concrete
fill 54 206 463 54 213 463 minecraft:light_gray_concrete
fill 54 206 499 61 206 499 minecraft:black_concrete
fill 58 206 505 58 213 505 minecraft:light_gray_concrete
fill 62 206 463 62 213 463 minecraft:light_gray_concrete
fill 66 206 505 66 213 505 minecraft:light_gray_concrete
fill 70 206 463 70 213 463 minecraft:light_gray_concrete
fill 74 206 505 74 213 505 minecraft:light_gray_concrete
fill 78 206 463 78 213 463 minecraft:light_gray_concrete
fill 82 206 505 82 213 505 minecraft:light_gray_concrete
fill 86 206 463 86 213 463 minecraft:light_gray_concrete
fill 89 206 468 89 213 468 minecraft:light_gray_concrete
fill 89 206 476 89 213 476 minecraft:light_gray_concrete
fill 89 206 484 89 213 484 minecraft:light_gray_concrete
fill 89 206 492 89 213 492 minecraft:light_gray_concrete
fill 89 206 500 89 213 500 minecraft:light_gray_concrete
fill 48 207 488 49 207 493 minecraft:quartz_block
fill 49 207 487 52 208 487 minecraft:quartz_block
fill 49 207 494 50 207 494 minecraft:quartz_block
fill 50 207 488 52 207 490 minecraft:quartz_block
fill 50 207 492 51 207 493 minecraft:quartz_block
fill 52 207 486 52 208 486 minecraft:quartz_block
setblock 52 207 492 minecraft:quartz_block
fill 53 207 493 53 207 497 minecraft:black_concrete
fill 54 207 499 55 207 499 minecraft:black_concrete
fill 48 208 482 51 208 485 minecraft:quartz_block
fill 48 208 488 49 208 489 minecraft:quartz_block
fill 49 208 486 51 208 486 minecraft:quartz_block
fill 50 208 488 52 208 488 minecraft:quartz_block
fill 52 208 483 52 208 485 minecraft:quartz_block
fill 53 208 489 53 208 495 minecraft:black_concrete
fill 48 209 477 49 210 477 minecraft:quartz_block
fill 48 209 480 52 209 484 minecraft:quartz_block
fill 49 209 478 52 210 479 minecraft:quartz_block
setblock 50 209 466 minecraft:light[level=14]
setblock 50 209 474 minecraft:light[level=14]
setblock 50 209 490 minecraft:light[level=14]
setblock 50 209 498 minecraft:light[level=14]
fill 53 209 485 53 209 490 minecraft:black_concrete
setblock 58 209 466 minecraft:light[level=14]
setblock 58 209 474 minecraft:light[level=14]
setblock 58 209 482 minecraft:light[level=14]
setblock 58 209 490 minecraft:light[level=14]
setblock 58 209 498 minecraft:light[level=14]
setblock 66 209 466 minecraft:light[level=14]
setblock 66 209 474 minecraft:light[level=14]
setblock 66 209 482 minecraft:light[level=14]
setblock 66 209 490 minecraft:light[level=14]
setblock 66 209 498 minecraft:light[level=14]
setblock 74 209 466 minecraft:light[level=14]
setblock 74 209 474 minecraft:light[level=14]
setblock 74 209 482 minecraft:light[level=14]
setblock 74 209 490 minecraft:light[level=14]
setblock 74 209 498 minecraft:light[level=14]
setblock 82 209 466 minecraft:light[level=14]
setblock 82 209 474 minecraft:light[level=14]
setblock 82 209 482 minecraft:light[level=14]
setblock 82 209 490 minecraft:light[level=14]
setblock 82 209 498 minecraft:light[level=14]
fill 48 210 464 48 211 469 minecraft:quartz_block
fill 48 210 472 50 210 476 minecraft:quartz_block
fill 48 210 480 49 210 485 minecraft:quartz_block
fill 48 210 488 49 210 493 minecraft:quartz_block
fill 48 210 496 49 210 501 minecraft:quartz_block
fill 48 210 504 53 211 504 minecraft:quartz_block
fill 49 210 465 49 211 471 minecraft:quartz_block
fill 49 210 486 49 210 487 minecraft:quartz_block
fill 49 210 494 49 210 495 minecraft:quartz_block
fill 49 210 502 49 210 503 minecraft:quartz_block
fill 50 210 465 87 210 465 minecraft:quartz_block
fill 50 210 477 52 210 477 minecraft:quartz_block
fill 50 210 480 52 210 480 minecraft:quartz_block
fill 50 210 503 88 210 503 minecraft:quartz_block
fill 51 210 464 56 212 464 minecraft:quartz_block
fill 51 210 473 52 210 476 minecraft:quartz_block
fill 53 210 481 53 210 486 minecraft:black_concrete
fill 56 210 504 61 211 504 minecraft:quartz_block
fill 59 210 464 64 211 464 minecraft:quartz_block
fill 64 210 504 69 211 504 minecraft:quartz_block
fill 67 210 464 72 211 464 minecraft:quartz_block
fill 72 210 504 77 211 504 minecraft:quartz_block
fill 75 210 464 80 211 464 minecraft:quartz_block
fill 80 210 504 85 211 504 minecraft:quartz_block
fill 83 210 464 88 211 464 minecraft:quartz_block
fill 87 210 466 87 210 502 minecraft:quartz_block
fill 88 210 467 88 211 472 minecraft:quartz_block
fill 88 210 475 88 211 480 minecraft:quartz_block
fill 88 210 483 88 211 488 minecraft:quartz_block
fill 88 210 491 88 211 496 minecraft:quartz_block
fill 88 210 499 88 211 502 minecraft:quartz_block
fill 88 210 504 88 211 504 minecraft:quartz_block
fill 48 211 472 48 211 477 minecraft:quartz_block
fill 48 211 480 48 211 485 minecraft:quartz_block
fill 48 211 488 48 211 493 minecraft:quartz_block
fill 48 211 496 48 211 501 minecraft:quartz_block
fill 49 211 472 52 211 474 minecraft:quartz_block
fill 50 211 465 51 211 471 minecraft:quartz_block
fill 50 211 475 52 211 475 minecraft:quartz_block
fill 52 211 466 52 211 471 minecraft:quartz_block
setblock 52 211 476 minecraft:quartz_block
fill 53 211 468 53 212 468 minecraft:quartz_block
fill 53 211 477 53 211 482 minecraft:black_concrete
setblock 88 211 503 minecraft:quartz_block
fill 48 212 464 48 212 467 minecraft:quartz_block
fill 49 212 465 58 212 467 minecraft:quartz_block
fill 50 212 468 52 212 468 minecraft:quartz_block
fill 51 212 469 52 212 469 minecraft:quartz_block
setblock 52 212 470 minecraft:quartz_block
fill 53 212 472 53 212 479 minecraft:black_concrete
fill 54 212 468 59 212 468 minecraft:quartz_block
fill 59 212 467 59 213 467 minecraft:quartz_block
fill 53 213 469 53 213 474 minecraft:black_concrete
fill 54 213 464 56 213 464 minecraft:quartz_block
fill 54 213 469 57 214 469 minecraft:black_concrete
fill 55 213 465 63 213 466 minecraft:quartz_block
fill 56 213 467 58 213 467 minecraft:quartz_block
fill 57 213 468 64 213 468 minecraft:quartz_block
fill 59 213 464 63 213 464 minecraft:quartz_block
fill 60 213 467 63 213 467 minecraft:quartz_block
fill 47 214 468 47 219 468 minecraft:sea_lantern
fill 47 214 476 47 219 476 minecraft:sea_lantern
fill 47 214 484 47 219 484 minecraft:sea_lantern
fill 47 214 492 47 219 492 minecraft:sea_lantern
fill 47 214 500 47 219 500 minecraft:sea_lantern
fill 50 214 505 50 219 505 minecraft:sea_lantern
fill 54 214 463 54 219 463 minecraft:sea_lantern
fill 58 214 469 61 214 469 minecraft:black_concrete
fill 58 214 505 58 219 505 minecraft:sea_lantern
fill 60 214 464 64 214 464 minecraft:quartz_block
fill 61 214 465 68 214 466 minecraft:quartz_block
fill 62 214 463 62 219 463 minecraft:sea_lantern
fill 62 214 467 68 214 468 minecraft:quartz_block
fill 66 214 505 66 219 505 minecraft:sea_lantern
fill 67 214 464 68 215 464 minecraft:quartz_block
fill 70 214 463 70 219 463 minecraft:sea_lantern
fill 74 214 505 74 219 505 minecraft:sea_lantern
fill 78 214 463 78 219 463 minecraft:sea_lantern
fill 82 214 505 82 219 505 minecraft:sea_lantern
fill 86 214 463 86 219 463 minecraft:sea_lantern
fill 89 214 468 89 219 468 minecraft:sea_lantern
fill 89 214 476 89 219 476 minecraft:sea_lantern
fill 89 214 484 89 219 484 minecraft:sea_lantern
fill 89 214 492 89 219 492 minecraft:sea_lantern
fill 89 214 500 89 219 500 minecraft:sea_lantern
fill 60 215 469 65 215 469 minecraft:black_concrete
fill 66 215 465 71 215 468 minecraft:quartz_block
fill 69 215 464 72 215 464 minecraft:quartz_block
fill 72 215 465 72 216 467 minecraft:quartz_block
fill 64 216 469 69 216 469 minecraft:black_concrete
fill 70 216 464 71 216 468 minecraft:quartz_block
setblock 72 216 464 minecraft:quartz_block
fill 72 216 468 76 216 468 minecraft:quartz_block
fill 73 216 465 76 216 467 minecraft:quartz_block
fill 75 216 464 78 216 464 minecraft:quartz_block
fill 77 216 465 77 217 466 minecraft:quartz_block
setblock 50 217 466 minecraft:light[level=14]
setblock 50 217 474 minecraft:light[level=14]
setblock 50 217 482 minecraft:light[level=14]
setblock 50 217 490 minecraft:light[level=14]
setblock 50 217 498 minecraft:light[level=14]
setblock 58 217 466 minecraft:light[level=14]
setblock 58 217 474 minecraft:light[level=14]
setblock 58 217 482 minecraft:light[level=14]
setblock 58 217 490 minecraft:light[level=14]
setblock 58 217 498 minecraft:light[level=14]
setblock 66 217 466 minecraft:light[level=14]
setblock 66 217 474 minecraft:light[level=14]
setblock 66 217 482 minecraft:light[level=14]
setblock 66 217 490 minecraft:light[level=14]
setblock 66 217 498 minecraft:light[level=14]
fill 68 217 469 73 217 469 minecraft:black_concrete
setblock 74 217 466 minecraft:light[level=14]
fill 74 217 467 82 217 468 minecraft:quartz_block
setblock 74 217 474 minecraft:light[level=14]
setblock 74 217 482 minecraft:light[level=14]
setblock 74 217 490 minecraft:light[level=14]
setblock 74 217 498 minecraft:light[level=14]
fill 75 217 465 76 217 466 minecraft:quartz_block
fill 76 217 464 80 217 464 minecraft:quartz_block
fill 78 217 465 83 217 466 minecraft:quartz_block
setblock 82 217 474 minecraft:light[level=14]
setblock 82 217 482 minecraft:light[level=14]
setblock 82 217 490 minecraft:light[level=14]
setblock 82 217 498 minecraft:light[level=14]
fill 83 217 464 85 218 464 minecraft:quartz_block
fill 83 217 467 83 218 467 minecraft:quartz_block
fill 84 217 465 84 218 465 minecraft:quartz_block
fill 71 218 469 77 218 469 minecraft:black_concrete
fill 79 218 468 88 218 468 minecraft:quartz_block
fill 80 218 466 82 218 467 minecraft:quartz_block
fill 81 218 465 83 218 465 minecraft:quartz_block
fill 83 218 466 87 218 466 minecraft:quartz_block
fill 84 218 467 88 218 467 minecraft:quartz_block
fill 84 218 469 85 218 472 minecraft:quartz_block
fill 85 218 465 87 218 465 minecraft:quartz_block
fill 86 218 464 88 218 464 minecraft:quartz_block
fill 86 218 469 86 219 471 minecraft:quartz_block
fill 87 218 469 88 219 470 minecraft:quartz_block
fill 75 219 469 83 219 469 minecraft:black_concrete
fill 83 219 470 83 220 470 minecraft:black_concrete
fill 84 219 470 85 219 477 minecraft:quartz_block
setblock 85 219 469 minecraft:quartz_block
fill 86 219 468 88 219 468 minecraft:quartz_block
fill 86 219 472 86 219 477 minecraft:quartz_block
fill 87 219 467 88 219 467 minecraft:quartz_block
fill 87 219 471 87 219 476 minecraft:quartz_block
fill 88 219 471 88 219 472 minecraft:quartz_block
fill 88 219 475 88 220 476 minecraft:quartz_block
fill 47 220 468 47 231 468 minecraft:light_gray_concrete
fill 47 220 476 47 227 476 minecraft:light_gray_concrete
fill 47 220 484 47 230 484 minecraft:light_gray_concrete
fill 47 220 492 47 226 492 minecraft:light_gray_concrete
fill 47 220 500 47 226 500 minecraft:light_gray_concrete
fill 50 220 505 50 230 505 minecraft:light_gray_concrete
fill 54 220 463 54 230 463 minecraft:light_gray_concrete
fill 58 220 505 58 227 505 minecraft:light_gray_concrete
fill 62 220 463 62 226 463 minecraft:light_gray_concrete
fill 66 220 505 66 226 505 minecraft:light_gray_concrete
fill 70 220 463 70 230 463 minecraft:light_gray_concrete
fill 74 220 505 74 228 505 minecraft:light_gray_concrete
fill 78 220 463 78 230 463 minecraft:light_gray_concrete
fill 81 220 469 83 220 469 minecraft:black_concrete
fill 82 220 505 82 227 505 minecraft:light_gray_concrete
fill 83 220 471 83 220 475 minecraft:black_concrete
fill 84 220 476 84 220 482 minecraft:quartz_block
fill 85 220 475 87 220 481 minecraft:quartz_block
fill 86 220 463 86 226 463 minecraft:light_gray_concrete
fill 86 220 474 87 220 474 minecraft:quartz_block
fill 88 220 477 88 220 480 minecraft:quartz_block
fill 89 220 468 89 230 468 minecraft:light_gray_concrete
fill 89 220 476 89 230 476 minecraft:light_gray_concrete
fill 89 220 484 89 228 484 minecraft:light_gray_concrete
fill 89 220 492 89 226 492 minecraft:light_gray_concrete
fill 89 220 500 89 230 500 minecraft:light_gray_concrete
fill 83 221 473 83 221 479 minecraft:black_concrete
fill 84 221 480 87 221 485 minecraft:quartz_block
fill 85 221 486 88 222 486 minecraft:quartz_block
fill 87 221 479 88 221 479 minecraft:quartz_block
setblock 88 221 480 minecraft:quartz_block
fill 88 221 483 88 221 485 minecraft:quartz_block
fill 83 222 478 83 222 483 minecraft:black_concrete
fill 84 222 484 84 222 490 minecraft:quartz_block
fill 85 222 484 88 222 485 minecraft:quartz_block
fill 85 222 487 87 222 490 minecraft:quartz_block
fill 87 222 491 88 223 491 minecraft:quartz_block
fill 88 222 487 88 222 488 minecraft:quartz_block
fill 83 223 482 83 223 487 minecraft:black_concrete
fill 84 223 488 86 223 495 minecraft:quartz_block
fill 86 223 496 88 223 496 minecraft:quartz_block
fill 87 223 489 87 223 490 minecraft:quartz_block
fill 87 223 492 88 223 495 minecraft:quartz_block
setblock 87 223 497 minecraft:quartz_block
setblock 50 225 466 minecraft:light[level=14]
setblock 50 225 474 minecraft:light[level=14]
setblock 50 225 482 minecraft:light[level=14]
setblock 50 225 490 minecraft:light[level=14]
setblock 50 225 498 minecraft:light[level=14]
setblock 58 225 466 minecraft:light[level=14]
setblock 58 225 474 minecraft:light[level=14]
setblock 58 225 482 minecraft:light[level=14]
setblock 58 225 490 minecraft:light[level=14]
setblock 58 225 498 minecraft:light[level=14]
setblock 66 225 466 minecraft:light[level=14]
setblock 66 225 474 minecraft:light[level=14]
setblock 66 225 482 minecraft:light[level=14]
setblock 66 225 490 minecraft:light[level=14]
setblock 66 225 498 minecraft:light[level=14]
setblock 74 225 466 minecraft:light[level=14]
setblock 74 225 474 minecraft:light[level=14]
setblock 74 225 482 minecraft:light[level=14]
setblock 74 225 490 minecraft:light[level=14]
setblock 74 225 498 minecraft:light[level=14]
setblock 82 225 466 minecraft:light[level=14]
setblock 82 225 474 minecraft:light[level=14]
setblock 82 225 482 minecraft:light[level=14]
setblock 82 225 490 minecraft:light[level=14]
setblock 82 225 498 minecraft:light[level=14]
fill 47 227 485 47 230 485 minecraft:light_gray_concrete
setblock 47 227 486 minecraft:white_concrete
fill 47 227 492 47 228 492 minecraft:white_concrete
setblock 47 227 500 minecraft:white_concrete
fill 47 227 501 47 228 503 minecraft:light_gray_concrete
setblock 47 227 504 minecraft:white_concrete
fill 54 227 505 54 230 505 minecraft:light_gray_concrete
fill 55 227 505 56 227 505 minecraft:white_concrete
fill 56 227 463 56 228 463 minecraft:white_concrete
fill 57 227 463 57 230 463 minecraft:light_gray_concrete
setblock 59 227 505 minecraft:white_concrete
fill 60 227 505 61 230 505 minecraft:light_gray_concrete
setblock 62 227 463 minecraft:white_concrete
setblock 66 227 505 minecraft:white_concrete
fill 68 227 505 68 228 505 minecraft:white_concrete
fill 69 227 505 72 227 505 minecraft:light_gray_concrete
setblock 73 227 505 minecraft:white_concrete
setblock 74 227 463 minecraft:white_concrete
fill 75 227 463 76 230 463 minecraft:light_gray_concrete
fill 75 227 505 78 227 505 minecraft:light_gray_concrete
setblock 77 227 463 minecraft:white_concrete
setblock 79 227 505 minecraft:white_concrete
fill 80 227 505 81 227 505 minecraft:light_gray_concrete
setblock 81 227 463 minecraft:white_concrete
fill 82 227 463 82 230 463 minecraft:light_gray_concrete
setblock 86 227 463 minecraft:white_concrete
setblock 89 227 465 minecraft:light_gray_concrete
fill 89 227 466 89 228 466 minecraft:white_concrete
fill 89 227 469 89 228 474 minecraft:light_gray_concrete
setblock 89 227 475 minecraft:white_concrete
setblock 89 227 477 minecraft:white_concrete
fill 89 227 487 89 230 487 minecraft:light_gray_concrete
setblock 89 227 488 minecraft:white_concrete
fill 89 227 489 89 230 489 minecraft:light_gray_concrete
fill 89 227 492 89 227 493 minecraft:white_concrete
fill 89 227 494 89 228 499 minecraft:light_gray_concrete
fill 47 228 463 47 230 463 minecraft:light_gray_concrete
setblock 47 228 464 minecraft:white_concrete
setblock 47 228 476 minecraft:white_concrete
fill 47 228 480 47 230 480 minecraft:light_gray_concrete
fill 47 228 481 47 228 482 minecraft:white_concrete
fill 47 228 486 47 230 486 minecraft:light_gray_concrete
setblock 47 228 487 minecraft:white_concrete
fill 47 228 494 47 230 494 minecraft:light_gray_concrete
setblock 47 228 495 minecraft:white_concrete
fill 47 228 496 47 230 497 minecraft:light_gray_concrete
setblock 47 228 498 minecraft:white_concrete
fill 47 228 500 47 230 500 minecraft:light_gray_concrete
setblock 47 228 504 minecraft:light_gray_concrete
setblock 47 228 505 minecraft:white_concrete
fill 55 228 505 56 230 505 minecraft:light_gray_concrete
setblock 58 228 505 minecraft:white_concrete
setblock 59 228 463 minecraft:white_concrete
fill 59 228 505 59 230 505 minecraft:light_gray_concrete
fill 60 228 463 62 230 463 minecraft:light_gray_concrete
fill 66 228 505 66 230 505 minecraft:light_gray_concrete
fill 69 228 505 71 230 505 minecraft:light_gray_concrete
setblock 72 228 505 minecraft:white_concrete
fill 73 228 505 73 230 505 minecraft:light_gray_concrete
setblock 74 228 463 minecraft:light_gray_concrete
fill 75 228 505 75 230 505 minecraft:light_gray_concrete
fill 76 228 505 76 229 505 minecraft:white_concrete
fill 77 228 463 77 230 463 minecraft:light_gray_concrete
fill 77 228 505 80 230 505 minecraft:light_gray_concrete
fill 81 228 463 81 230 463 minecraft:light_gray_concrete
fill 81 228 505 82 228 505 minecraft:white_concrete
fill 86 228 463 86 230 463 minecraft:light_gray_concrete
fill 87 228 463 87 229 463 minecraft:white_concrete
fill 87 228 505 88 230 505 minecraft:light_gray_concrete
fill 88 228 463 88 230 463 minecraft:light_gray_concrete
setblock 89 228 465 minecraft:white_concrete
fill 89 228 475 89 230 475 minecraft:light_gray_concrete
fill 89 228 477 89 230 477 minecraft:light_gray_concrete
setblock 89 228 479 minecraft:white_concrete
fill 89 228 480 89 230 482 minecraft:light_gray_concrete
setblock 89 228 483 minecraft:white_concrete
fill 89 228 488 89 230 488 minecraft:light_gray_concrete
fill 89 228 492 89 231 493 minecraft:light_gray_concrete
setblock 89 228 505 minecraft:white_concrete
fill 47 229 464 47 230 464 minecraft:light_gray_concrete
setblock 47 229 465 minecraft:white_concrete
fill 47 229 476 47 230 476 minecraft:light_gray_concrete
fill 47 229 481 47 230 482 minecraft:light_gray_concrete
fill 47 229 487 47 230 487 minecraft:light_gray_concrete
fill 47 229 490 47 230 490 minecraft:light_gray_concrete
setblock 47 229 491 minecraft:white_concrete
fill 47 229 492 47 230 492 minecraft:light_gray_concrete
fill 47 229 495 47 230 495 minecraft:light_gray_concrete
fill 47 229 498 47 230 498 minecraft:light_gray_concrete
fill 47 229 501 47 230 501 minecraft:light_gray_concrete
setblock 47 229 502 minecraft:white_concrete
fill 47 229 503 47 230 503 minecraft:light_gray_concrete
setblock 47 229 504 minecraft:white_concrete
fill 47 229 505 47 230 505 minecraft:light_gray_concrete
fill 48 229 463 52 230 463 minecraft:light_gray_concrete
setblock 48 229 505 minecraft:white_concrete
fill 49 229 505 49 230 505 minecraft:light_gray_concrete
fill 51 229 505 51 230 505 minecraft:light_gray_concrete
setblock 52 229 505 minecraft:white_concrete
setblock 53 229 463 minecraft:white_concrete
setblock 55 229 463 minecraft:white_concrete
fill 56 229 463 56 230 463 minecraft:light_gray_concrete
fill 57 229 484 62 230 484 minecraft:light_gray_concrete
fill 58 229 479 62 230 483 minecraft:light_gray_concrete
fill 58 229 485 62 230 489 minecraft:light_gray_concrete
fill 58 229 505 58 230 505 minecraft:light_gray_concrete
fill 59 229 463 59 230 463 minecraft:light_gray_concrete
fill 59 229 477 65 230 478 minecraft:light_gray_concrete
fill 59 229 490 62 230 491 minecraft:light_gray_concrete
fill 60 229 475 69 230 476 minecraft:light_gray_concrete
fill 60 229 492 63 230 493 minecraft:light_gray_concrete
fill 61 229 474 82 230 474 minecraft:light_gray_concrete
fill 61 229 494 65 230 494 minecraft:light_gray_concrete
fill 62 229 473 81 230 473 minecraft:light_gray_concrete
fill 62 229 495 66 230 495 minecraft:light_gray_concrete
fill 63 229 463 63 231 463 minecraft:light_gray_concrete
fill 63 229 472 80 230 472 minecraft:light_gray_concrete
fill 63 229 479 63 230 481 minecraft:light_gray_concrete
fill 63 229 482 66 230 490 minecraft:quartz_block
fill 63 229 491 63 230 491 minecraft:light_gray_concrete
fill 63 229 496 68 230 496 minecraft:light_gray_concrete
setblock 64 229 463 minecraft:white_concrete
fill 64 229 471 78 230 471 minecraft:light_gray_concrete
fill 64 229 479 64 230 479 minecraft:light_gray_concrete
fill 64 229 480 68 229 481 minecraft:quartz_block
fill 64 229 491 68 230 492 minecraft:quartz_block
fill 64 229 493 64 230 493 minecraft:light_gray_concrete
fill 64 229 497 70 230 497 minecraft:light_gray_concrete
fill 65 229 463 69 230 463 minecraft:light_gray_concrete
fill 65 229 479 77 229 479 minecraft:quartz_block
fill 65 229 493 72 230 493 minecraft:quartz_block
fill 66 229 470 76 230 470 minecraft:light_gray_concrete
fill 66 229 477 67 230 477 minecraft:light_gray_concrete
fill 66 229 478 76 229 478 minecraft:quartz_block
fill 66 229 494 84 230 494 minecraft:quartz_block
fill 66 229 498 80 230 498 minecraft:light_gray_concrete
fill 67 229 482 67 229 483 minecraft:quartz_block
fill 67 229 484 70 229 488 minecraft:light_gray_concrete
fill 67 229 489 67 230 490 minecraft:quartz_block
fill 67 229 495 83 230 495 minecraft:quartz_block
fill 68 229 469 70 230 469 minecraft:quartz_block
fill 68 229 477 75 230 477 minecraft:quartz_block
fill 68 229 482 71 229 483 minecraft:light_gray_concrete
fill 68 229 489 82 229 490 minecraft:light_gray_concrete
fill 68 229 499 78 230 499 minecraft:light_gray_concrete
fill 68 229 505 68 230 505 minecraft:light_gray_concrete
fill 69 229 480 77 229 480 minecraft:quartz_block
fill 69 229 481 73 229 481 minecraft:light_gray_concrete
fill 69 229 491 81 230 491 minecraft:light_gray_concrete
fill 69 229 492 69 230 492 minecraft:quartz_block
fill 69 229 496 81 230 496 minecraft:quartz_block
fill 70 229 475 82 230 475 minecraft:light_gray_concrete
fill 70 229 476 72 230 476 minecraft:quartz_block
fill 70 229 492 79 230 492 minecraft:light_gray_concrete
fill 71 229 469 72 230 469 minecraft:light_gray_concrete
fill 71 229 485 71 229 488 minecraft:light_gray_concrete
fill 71 229 497 79 230 497 minecraft:quartz_block
setblock 72 229 482 minecraft:light_gray_concrete
fill 72 229 486 72 229 488 minecraft:light_gray_concrete
fill 72 229 505 72 230 505 minecraft:light_gray_concrete
fill 73 229 468 73 230 469 minecraft:quartz_block
fill 73 229 476 83 230 476 minecraft:light_gray_concrete
fill 73 229 487 83 229 488 minecraft:light_gray_concrete
fill 73 229 493 77 230 493 minecraft:light_gray_concrete
fill 73 229 500 73 230 500 minecraft:light_gray_concrete
setblock 74 229 463 minecraft:white_concrete
fill 74 229 469 78 230 469 minecraft:quartz_block
fill 74 229 481 78 229 481 minecraft:quartz_block
setblock 74 229 482 minecraft:light_gray_concrete
fill 74 229 486 76 229 486 minecraft:quartz_block
setblock 74 229 505 minecraft:white_concrete
fill 75 229 482 78 229 483 minecraft:quartz_block
fill 75 229 485 77 229 485 minecraft:quartz_block
fill 76 229 477 84 230 477 minecraft:light_gray_concrete
fill 76 229 484 78 229 484 minecraft:quartz_block
fill 77 229 470 80 230 470 minecraft:quartz_block
fill 77 229 478 84 230 478 minecraft:light_gray_concrete
fill 77 229 486 84 229 486 minecraft:light_gray_concrete
fill 78 229 479 84 229 480 minecraft:light_gray_concrete
fill 78 229 485 84 229 485 minecraft:light_gray_concrete
fill 78 229 493 85 230 493 minecraft:quartz_block
fill 79 229 471 82 230 471 minecraft:quartz_block
fill 79 229 481 85 229 484 minecraft:light_gray_concrete
fill 80 229 492 86 230 492 minecraft:quartz_block
fill 80 229 497 82 230 497 minecraft:light_gray_concrete
fill 81 229 472 83 230 472 minecraft:quartz_block
fill 81 229 505 82 230 505 minecraft:light_gray_concrete
fill 82 229 473 84 230 473 minecraft:quartz_block
fill 82 229 491 86 230 491 minecraft:quartz_block
fill 82 229 496 83 230 496 minecraft:light_gray_concrete
fill 83 229 463 83 230 463 minecraft:light_gray_concrete
fill 83 229 474 85 230 475 minecraft:quartz_block
fill 83 229 489 83 230 489 minecraft:light_gray_concrete
fill 83 229 490 87 230 490 minecraft:quartz_block
setblock 84 229 463 minecraft:white_concrete
fill 84 229 476 86 230 476 minecraft:quartz_block
fill 84 229 487 84 230 487 minecraft:light_gray_concrete
fill 84 229 488 88 230 489 minecraft:quartz_block
fill 84 229 495 84 230 495 minecraft:light_gray_concrete
fill 85 229 463 85 230 463 minecraft:light_gray_concrete
fill 85 229 477 87 230 479 minecraft:quartz_block
fill 85 229 480 85 230 480 minecraft:light_gray_concrete
fill 85 229 485 88 230 487 minecraft:quartz_block
fill 85 229 494 85 230 494 minecraft:light_gray_concrete
fill 86 229 475 86 230 475 minecraft:quartz_block
fill 86 229 480 88 230 484 minecraft:quartz_block
fill 86 229 493 86 230 493 minecraft:light_gray_concrete
fill 87 229 491 87 230 491 minecraft:light_gray_concrete
fill 88 229 479 88 230 479 minecraft:quartz_block
setblock 89 229 463 minecraft:white_concrete
fill 89 229 464 89 230 466 minecraft:light_gray_concrete
fill 89 229 469 89 230 471 minecraft:light_gray_concrete
setblock 89 229 472 minecraft:white_concrete
fill 89 229 473 89 230 473 minecraft:light_gray_concrete
setblock 89 229 474 minecraft:white_concrete
fill 89 229 479 89 230 479 minecraft:light_gray_concrete
fill 89 229 483 89 230 483 minecraft:light_gray_concrete
fill 89 229 484 89 230 484 minecraft:quartz_block
fill 89 229 494 89 230 497 minecraft:light_gray_concrete
setblock 89 229 498 minecraft:white_concrete
fill 89 229 499 89 231 499 minecraft:light_gray_concrete
fill 89 229 505 89 230 505 minecraft:light_gray_concrete
fill 47 230 465 88 230 465 minecraft:light_gray_concrete
fill 47 230 491 58 230 491 minecraft:light_gray_concrete
fill 47 230 502 88 230 502 minecraft:light_gray_concrete
fill 47 230 504 88 230 504 minecraft:light_gray_concrete
fill 48 230 464 88 230 464 minecraft:light_gray_concrete
fill 48 230 466 56 230 490 minecraft:light_gray_concrete
fill 48 230 492 59 230 501 minecraft:light_gray_concrete
fill 48 230 503 88 230 503 minecraft:light_gray_concrete
setblock 48 230 505 minecraft:light_gray_concrete
fill 52 230 505 52 231 505 minecraft:light_gray_concrete
setblock 53 230 463 minecraft:light_gray_concrete
setblock 55 230 463 minecraft:light_gray_concrete
fill 57 230 466 57 230 483 minecraft:light_gray_concrete
fill 57 230 485 57 230 490 minecraft:light_gray_concrete
fill 58 230 466 58 230 478 minecraft:light_gray_concrete
setblock 58 230 490 minecraft:light_gray_concrete
fill 59 230 466 59 230 476 minecraft:light_gray_concrete
fill 60 230 466 60 230 474 minecraft:light_gray_concrete
fill 60 230 494 60 230 501 minecraft:light_gray_concrete
fill 61 230 466 61 230 473 minecraft:light_gray_concrete
fill 61 230 495 61 230 501 minecraft:light_gray_concrete
fill 62 230 466 62 230 472 minecraft:light_gray_concrete
fill 62 230 496 62 230 501 minecraft:light_gray_concrete
fill 63 230 466 63 230 471 minecraft:light_gray_concrete
fill 63 230 497 63 230 501 minecraft:light_gray_concrete
setblock 64 230 463 minecraft:light_gray_concrete
fill 64 230 466 65 230 470 minecraft:light_gray_concrete
fill 64 230 480 67 230 481 minecraft:quartz_block
fill 64 230 498 65 230 501 minecraft:light_gray_concrete
fill 65 230 479 68 230 479 minecraft:quartz_block
fill 66 230 466 67 230 469 minecraft:light_gray_concrete
fill 66 230 478 70 230 478 minecraft:quartz_block
fill 66 230 499 67 230 501 minecraft:light_gray_concrete
fill 67 230 482 70 230 486 minecraft:mossy_stone_bricks
fill 67 230 487 67 230 488 minecraft:light_gray_concrete
fill 68 230 466 72 230 468 minecraft:light_gray_concrete
fill 68 230 480 78 230 481 minecraft:mossy_stone_bricks
fill 68 230 487 78 230 488 minecraft:mossy_stone_bricks
fill 68 230 489 68 230 490 minecraft:light_gray_concrete
fill 68 230 500 72 230 501 minecraft:light_gray_concrete
fill 69 230 479 77 230 479 minecraft:mossy_stone_bricks
fill 69 230 489 77 230 489 minecraft:mossy_stone_bricks
fill 69 230 490 70 230 490 minecraft:light_gray_concrete
fill 71 230 478 75 230 478 minecraft:mossy_stone_bricks
fill 71 230 482 71 230 483 minecraft:mossy_stone_bricks
fill 71 230 485 71 230 486 minecraft:mossy_stone_bricks
fill 71 230 490 75 230 490 minecraft:mossy_stone_bricks
setblock 72 230 482 minecraft:mossy_stone_bricks
setblock 72 230 486 minecraft:mossy_stone_bricks
fill 73 230 466 88 230 467 minecraft:light_gray_concrete
fill 73 230 501 88 230 501 minecraft:light_gray_concrete
setblock 74 230 463 minecraft:light_gray_concrete
fill 74 230 468 88 230 468 minecraft:light_gray_concrete
fill 74 230 482 79 230 482 minecraft:mossy_stone_bricks
fill 74 230 486 79 230 486 minecraft:mossy_stone_bricks
fill 74 230 500 88 230 500 minecraft:light_gray_concrete
setblock 74 230 505 minecraft:light_gray_concrete
fill 75 230 483 79 230 483 minecraft:mossy_stone_bricks
fill 75 230 485 79 230 485 minecraft:mossy_stone_bricks
setblock 76 230 478 minecraft:quartz_block
fill 76 230 484 79 230 484 minecraft:mossy_stone_bricks
fill 76 230 490 82 230 490 minecraft:light_gray_concrete
setblock 76 230 505 minecraft:light_gray_concrete
fill 78 230 479 84 230 479 minecraft:light_gray_concrete
fill 78 230 489 82 230 489 minecraft:light_gray_concrete
fill 79 230 469 88 230 469 minecraft:light_gray_concrete
fill 79 230 480 84 230 481 minecraft:light_gray_concrete
fill 79 230 487 83 230 488 minecraft:light_gray_concrete
fill 79 230 499 88 230 499 minecraft:light_gray_concrete
fill 80 230 482 84 230 486 minecraft:light_gray_concrete
fill 81 230 470 88 230 470 minecraft:light_gray_concrete
fill 81 230 498 89 230 498 minecraft:light_gray_concrete
fill 83 230 471 88 230 471 minecraft:light_gray_concrete
fill 83 230 497 88 230 497 minecraft:light_gray_concrete
setblock 84 230 463 minecraft:light_gray_concrete
fill 84 230 472 89 230 472 minecraft:light_gray_concrete
fill 84 230 496 88 230 496 minecraft:light_gray_concrete
fill 85 230 473 88 230 473 minecraft:light_gray_concrete
fill 85 230 481 85 230 484 minecraft:light_gray_concrete
fill 85 230 495 88 230 495 minecraft:light_gray_concrete
fill 86 230 474 89 230 474 minecraft:light_gray_concrete
fill 86 230 494 88 230 494 minecraft:light_gray_concrete
fill 87 230 463 87 231 463 minecraft:light_gray_concrete
fill 87 230 475 88 230 476 minecraft:light_gray_concrete
fill 87 230 492 88 230 493 minecraft:light_gray_concrete
fill 88 230 477 88 230 478 minecraft:light_gray_concrete
fill 88 230 490 88 230 491 minecraft:light_gray_concrete
setblock 89 230 463 minecraft:light_gray_concrete
fill 47 231 463 47 231 464 minecraft:white_concrete
setblock 47 231 465 minecraft:light_gray_concrete
fill 47 231 466 47 231 467 minecraft:white_concrete
fill 47 231 469 47 232 471 minecraft:white_concrete
setblock 47 231 472 minecraft:light_gray_concrete
fill 47 231 473 47 231 503 minecraft:white_concrete
fill 47 231 504 47 232 504 minecraft:light_gray_concrete
fill 47 231 505 51 241 505 minecraft:white_concrete
fill 48 231 463 57 231 463 minecraft:white_concrete
fill 53 231 505 54 307 505 minecraft:white_concrete
setblock 55 231 505 minecraft:light_gray_concrete
setblock 56 231 505 minecraft:white_concrete
fill 58 231 505 77 231 505 minecraft:white_concrete
fill 59 231 463 62 231 463 minecraft:white_concrete
fill 64 231 463 74 241 463 minecraft:white_concrete
fill 65 231 482 66 240 486 minecraft:stone_bricks
fill 66 231 477 68 243 480 minecraft:cobblestone
fill 66 231 481 67 240 481 minecraft:stone_bricks
fill 66 231 487 67 241 487 minecraft:stone_bricks
fill 66 231 488 68 243 491 minecraft:cobblestone
fill 69 231 477 69 243 479 minecraft:cobblestone
fill 69 231 489 69 243 491 minecraft:cobblestone
fill 70 231 477 70 240 478 minecraft:stone_bricks
fill 70 231 490 70 240 491 minecraft:stone_bricks
fill 71 231 476 75 240 477 minecraft:stone_bricks
fill 71 231 491 75 240 492 minecraft:stone_bricks
setblock 75 231 463 minecraft:light_gray_concrete
fill 76 231 463 86 232 463 minecraft:white_concrete
fill 76 231 477 76 240 478 minecraft:stone_bricks
fill 76 231 490 76 241 491 minecraft:stone_bricks
fill 77 231 477 80 243 479 minecraft:cobblestone
fill 77 231 489 80 243 491 minecraft:cobblestone
fill 78 231 480 80 243 480 minecraft:cobblestone
fill 78 231 488 80 243 488 minecraft:cobblestone
fill 78 231 505 80 231 505 minecraft:light_gray_concrete
fill 79 231 481 80 241 481 minecraft:stone_bricks
fill 79 231 487 80 240 487 minecraft:stone_bricks
fill 80 231 482 81 240 486 minecraft:stone_bricks
fill 81 231 505 81 307 505 minecraft:white_concrete
setblock 82 231 505 minecraft:light_gray_concrete
fill 83 231 505 89 231 505 minecraft:white_concrete
fill 88 231 463 89 307 463 minecraft:white_concrete
fill 89 231 464 89 232 470 minecraft:white_concrete
setblock 89 231 471 minecraft:light_gray_concrete
fill 89 231 472 89 231 491 minecraft:white_concrete
fill 89 231 494 89 232 496 minecraft:white_concrete
setblock 89 231 497 minecraft:light_gray_concrete
fill 89 231 498 89 307 498 minecraft:white_concrete
fill 89 231 500 89 232 504 minecraft:white_concrete
setblock 47 232 463 minecraft:light_gray_concrete
fill 47 232 464 47 232 465 minecraft:white_concrete
fill 47 232 466 47 233 466 minecraft:light_gray_concrete
fill 47 232 467 47 241 468 minecraft:white_concrete
fill 47 232 472 47 307 475 minecraft:white_concrete
setblock 47 232 476 minecraft:light_gray_concrete
fill 47 232 477 47 307 477 minecraft:white_concrete
setblock 47 232 478 minecraft:light_gray_concrete
fill 47 232 479 47 307 483 minecraft:white_concrete
setblock 47 232 484 minecraft:light_gray_concrete
fill 47 232 485 47 241 496 minecraft:white_concrete
setblock 47 232 497 minecraft:light_gray_concrete
fill 47 232 498 47 307 498 minecraft:white_concrete
fill 47 232 499 47 232 500 minecraft:light_gray_concrete
fill 47 232 501 47 307 503 minecraft:white_concrete
fill 48 232 463 53 232 463 minecraft:white_concrete
fill 52 232 505 52 307 505 minecraft:white_concrete
setblock 54 232 463 minecraft:light_gray_concrete
fill 55 232 463 60 307 463 minecraft:white_concrete
fill 55 232 505 55 307 505 minecraft:white_concrete
setblock 56 232 505 minecraft:light_gray_concrete
fill 57 232 505 57 307 505 minecraft:white_concrete
setblock 58 232 505 minecraft:light_gray_concrete
fill 59 232 505 78 232 505 minecraft:white_concrete
fill 61 232 463 61 233 463 minecraft:light_gray_concrete
fill 62 232 463 63 232 463 minecraft:white_concrete
fill 75 232 463 75 307 463 minecraft:white_concrete
setblock 79 232 505 minecraft:light_gray_concrete
fill 80 232 505 80 307 505 minecraft:white_concrete
fill 82 232 505 86 232 505 minecraft:white_concrete
fill 87 232 463 87 307 463 minecraft:white_concrete
setblock 87 232 505 minecraft:light_gray_concrete
fill 88 232 505 88 307 505 minecraft:white_concrete
fill 89 232 471 89 232 477 minecraft:white_concrete
setblock 89 232 478 minecraft:light_gray_concrete
fill 89 232 479 89 307 483 minecraft:white_concrete
setblock 89 232 484 minecraft:light_gray_concrete
fill 89 232 485 89 307 490 minecraft:white_concrete
setblock 89 232 491 minecraft:light_gray_concrete
fill 89 232 492 89 241 493 minecraft:white_concrete
setblock 89 232 497 minecraft:white_concrete
fill 89 232 499 89 307 499 minecraft:white_concrete
setblock 89 232 505 minecraft:light_gray_concrete
fill 47 233 463 49 307 463 minecraft:white_concrete
setblock 47 233 464 minecraft:light_gray_concrete
fill 47 233 465 47 307 465 minecraft:white_concrete
fill 47 233 469 47 307 470 minecraft:white_concrete
setblock 47 233 471 minecraft:light_gray_concrete
fill 47 233 476 47 241 476 minecraft:white_concrete
fill 47 233 478 47 307 478 minecraft:white_concrete
fill 47 233 484 47 241 484 minecraft:white_concrete
fill 47 233 497 47 307 497 minecraft:white_concrete
fill 47 233 499 47 241 500 minecraft:white_concrete
fill 47 233 504 47 307 504 minecraft:white_concrete
setblock 50 233 463 minecraft:light_gray_concrete
setblock 50 233 466 minecraft:light[level=14]
setblock 50 233 474 minecraft:light[level=14]
setblock 50 233 482 minecraft:light[level=14]
setblock 50 233 490 minecraft:light[level=14]
setblock 50 233 498 minecraft:light[level=14]
fill 51 233 463 52 307 463 minecraft:white_concrete
setblock 53 233 463 minecraft:light_gray_concrete
fill 54 233 463 54 241 463 minecraft:white_concrete
fill 56 233 505 56 307 505 minecraft:white_concrete
setblock 58 233 466 minecraft:light[level=14]
setblock 58 233 474 minecraft:light[level=14]
setblock 58 233 482 minecraft:light[level=14]
setblock 58 233 490 minecraft:light[level=14]
setblock 58 233 498 minecraft:light[level=14]
fill 58 233 505 60 241 505 minecraft:white_concrete
setblock 61 233 505 minecraft:light_gray_concrete
setblock 62 233 463 minecraft:light_gray_concrete
fill 62 233 505 62 307 505 minecraft:white_concrete
fill 63 233 463 63 307 463 minecraft:white_concrete
setblock 63 233 505 minecraft:light_gray_concrete
fill 64 233 505 79 241 505 minecraft:white_concrete
setblock 66 233 466 minecraft:light[level=14]
setblock 66 233 474 minecraft:light[level=14]
setblock 66 233 498 minecraft:light[level=14]
setblock 74 233 466 minecraft:light[level=14]
setblock 74 233 474 minecraft:light[level=14]
setblock 74 233 482 minecraft:light[level=14]
setblock 74 233 490 minecraft:light[level=14]
setblock 74 233 498 minecraft:light[level=14]
fill 76 233 463 78 241 463 minecraft:white_concrete
setblock 79 233 463 minecraft:light_gray_concrete
fill 80 233 463 85 307 463 minecraft:white_concrete
setblock 82 233 466 minecraft:light[level=14]
setblock 82 233 474 minecraft:light[level=14]
setblock 82 233 482 minecraft:light[level=14]
setblock 82 233 490 minecraft:light[level=14]
setblock 82 233 498 minecraft:light[level=14]
fill 82 233 505 84 241 505 minecraft:white_concrete
setblock 85 233 505 minecraft:light_gray_concrete
setblock 86 233 463 minecraft:light_gray_concrete
fill 86 233 505 87 307 505 minecraft:white_concrete
fill 89 233 464 89 307 464 minecraft:white_concrete
setblock 89 233 465 minecraft:light_gray_concrete
fill 89 233 466 89 307 466 minecraft:white_concrete
setblock 89 233 467 minecraft:light_gray_concrete
fill 89 233 468 89 241 476 minecraft:white_concrete
setblock 89 233 477 minecraft:light_gray_concrete
fill 89 233 478 89 307 478 minecraft:white_concrete
fill 89 233 484 89 241 484 minecraft:white_concrete
fill 89 233 491 89 307 491 minecraft:white_concrete
fill 89 233 494 89 307 495 minecraft:white_concrete
fill 89 233 496 89 233 497 minecraft:light_gray_concrete
fill 89 233 500 89 241 500 minecraft:white_concrete
setblock 89 233 501 minecraft:light_gray_concrete
fill 89 233 502 89 307 505 minecraft:white_concrete
fill 47 234 464 47 307 464 minecraft:white_concrete
fill 47 234 466 47 307 466 minecraft:white_concrete
fill 47 234 471 47 307 471 minecraft:white_concrete
fill 48 234 470 48 273 471 minecraft:quartz_block
fill 48 234 478 48 273 479 minecraft:quartz_block
fill 48 234 486 48 273 487 minecraft:quartz_block
fill 48 234 494 48 273 495 minecraft:quartz_block
fill 48 234 502 48 273 503 minecraft:quartz_block
fill 49 234 464 50 273 464 minecraft:quartz_block
fill 50 234 463 50 307 463 minecraft:white_concrete
fill 53 234 463 53 307 463 minecraft:white_concrete
fill 54 234 504 55 273 504 minecraft:quartz_block
fill 57 234 464 58 273 464 minecraft:quartz_block
fill 61 234 463 62 241 463 minecraft:white_concrete
fill 61 234 505 61 307 505 minecraft:white_concrete
fill 62 234 504 63 273 504 minecraft:quartz_block
fill 63 234 505 63 307 505 minecraft:white_concrete
fill 65 234 464 66 273 464 minecraft:quartz_block
fill 70 234 504 71 273 504 minecraft:quartz_block
fill 73 234 464 74 273 464 minecraft:quartz_block
fill 78 234 504 79 273 504 minecraft:quartz_block
fill 79 234 463 79 307 463 minecraft:white_concrete
fill 81 234 464 82 273 464 minecraft:quartz_block
fill 83 234 473 83 234 479 minecraft:black_concrete
fill 84 234 480 88 234 485 minecraft:quartz_block
fill 85 234 486 88 235 486 minecraft:quartz_block
fill 85 234 505 85 307 505 minecraft:white_concrete
fill 86 234 463 86 241 463 minecraft:white_concrete
fill 86 234 504 87 273 504 minecraft:quartz_block
fill 87 234 479 88 234 479 minecraft:quartz_block
fill 88 234 465 88 273 466 minecraft:quartz_block
fill 88 234 473 88 273 474 minecraft:quartz_block
fill 88 234 489 88 273 490 minecraft:quartz_block
fill 88 234 497 88 273 498 minecraft:quartz_block
fill 89 234 465 89 307 465 minecraft:white_concrete
fill 89 234 467 89 307 467 minecraft:white_concrete
fill 89 234 477 89 307 477 minecraft:white_concrete
fill 89 234 496 89 307 497 minecraft:white_concrete
fill 89 234 501 89 307 501 minecraft:white_concrete
fill 83 235 478 83 235 483 minecraft:black_concrete
fill 84 235 484 84 235 490 minecraft:quartz_block
fill 85 235 484 88 235 485 minecraft:quartz_block
fill 85 235 487 87 235 490 minecraft:quartz_block
fill 87 235 491 88 236 491 minecraft:quartz_block
fill 88 235 481 88 273 482 minecraft:quartz_block
fill 88 235 487 88 235 488 minecraft:quartz_block
fill 83 236 482 83 236 487 minecraft:black_concrete
fill 84 236 488 86 236 495 minecraft:quartz_block
fill 86 236 496 88 237 496 minecraft:quartz_block
fill 87 236 489 87 236 490 minecraft:quartz_block
fill 87 236 492 88 236 495 minecraft:quartz_block
fill 87 236 497 87 238 497 minecraft:quartz_block
fill 83 237 486 83 237 491 minecraft:black_concrete
fill 83 237 500 88 238 500 minecraft:quartz_block
fill 84 237 492 84 237 499 minecraft:quartz_block
fill 84 237 501 88 238 502 minecraft:quartz_block
fill 85 237 493 85 237 499 minecraft:quartz_block
fill 85 237 503 88 238 503 minecraft:quartz_block
fill 86 237 493 86 237 495 minecraft:quartz_block
fill 86 237 497 86 237 499 minecraft:quartz_block
fill 87 237 494 88 238 495 minecraft:quartz_block
fill 87 237 498 87 238 499 minecraft:quartz_block
fill 88 237 499 88 239 499 minecraft:quartz_block
fill 88 237 504 88 239 504 minecraft:quartz_block
fill 48 238 464 48 239 469 minecraft:quartz_block
fill 48 238 472 49 238 477 minecraft:quartz_block
fill 48 238 480 49 238 485 minecraft:quartz_block
fill 48 238 488 49 238 493 minecraft:quartz_block
fill 48 238 496 49 238 501 minecraft:quartz_block
fill 48 238 504 53 239 504 minecraft:quartz_block
fill 49 238 465 49 238 471 minecraft:quartz_block
fill 49 238 478 49 238 479 minecraft:quartz_block
fill 49 238 486 49 238 487 minecraft:quartz_block
fill 49 238 494 49 238 495 minecraft:quartz_block
fill 49 238 502 49 238 503 minecraft:quartz_block
fill 50 238 465 87 238 465 minecraft:quartz_block
fill 50 238 503 84 238 503 minecraft:quartz_block
fill 51 238 464 56 239 464 minecraft:quartz_block
fill 56 238 504 61 239 504 minecraft:quartz_block
fill 59 238 464 64 239 464 minecraft:quartz_block
fill 64 238 504 69 239 504 minecraft:quartz_block
fill 67 238 464 72 239 464 minecraft:quartz_block
fill 72 238 504 77 239 504 minecraft:quartz_block
fill 75 238 464 80 239 464 minecraft:quartz_block
fill 77 238 500 82 238 501 minecraft:quartz_block
fill 78 238 502 83 238 502 minecraft:quartz_block
fill 80 238 504 85 239 504 minecraft:quartz_block
fill 83 238 464 88 239 464 minecraft:quartz_block
fill 83 238 489 83 238 496 minecraft:black_concrete
setblock 83 238 501 minecraft:quartz_block
fill 84 238 498 84 238 499 minecraft:quartz_block
setblock 85 238 499 minecraft:quartz_block
fill 87 238 466 87 238 493 minecraft:quartz_block
fill 87 238 496 88 238 496 minecraft:quartz_block
fill 88 238 467 88 239 472 minecraft:quartz_block
fill 88 238 475 88 239 480 minecraft:quartz_block
fill 88 238 483 88 239 488 minecraft:quartz_block
fill 88 238 491 88 239 493 minecraft:quartz_block
fill 48 239 472 48 239 477 minecraft:quartz_block
fill 48 239 480 48 239 485 minecraft:quartz_block
fill 48 239 488 48 239 493 minecraft:quartz_block
fill 48 239 496 48 239 501 minecraft:quartz_block
fill 72 239 500 79 239 500 minecraft:quartz_block
fill 73 239 501 80 239 503 minecraft:quartz_block
fill 79 239 499 83 239 499 minecraft:black_concrete
fill 81 239 502 81 239 503 minecraft:quartz_block
fill 83 239 494 83 239 498 minecraft:black_concrete
fill 88 239 494 88 239 496 minecraft:quartz_block
fill 88 239 500 88 239 503 minecraft:quartz_block
fill 68 240 500 69 241 504 minecraft:quartz_block
fill 70 240 500 74 240 503 minecraft:quartz_block
fill 72 240 504 76 240 504 minecraft:quartz_block
fill 75 240 499 82 240 499 minecraft:black_concrete
fill 75 240 502 75 240 503 minecraft:quartz_block
setblock 50 241 466 minecraft:light[level=14]
setblock 50 241 474 minecraft:light[level=14]
setblock 50 241 482 minecraft:light[level=14]
setblock 50 241 490 minecraft:light[level=14]
setblock 50 241 498 minecraft:light[level=14]
setblock 58 241 466 minecraft:light[level=14]
setblock 58 241 474 minecraft:light[level=14]
setblock 58 241 482 minecraft:light[level=14]
setblock 58 241 490 minecraft:light[level=14]
setblock 58 241 498 minecraft:light[level=14]
fill 64 241 501 67 241 504 minecraft:quartz_block
fill 65 241 482 66 241 482 minecraft:stone_bricks
fill 65 241 484 65 241 485 minecraft:stone_bricks
fill 65 241 500 67 241 500 minecraft:quartz_block
setblock 66 241 466 minecraft:light[level=14]
setblock 66 241 474 minecraft:light[level=14]
fill 66 241 483 66 241 484 minecraft:stone_bricks
setblock 66 241 498 minecraft:light[level=14]
fill 70 241 477 71 241 477 minecraft:stone_bricks
setblock 70 241 490 minecraft:stone_bricks
fill 70 241 500 70 241 503 minecraft:quartz_block
setblock 71 241 476 minecraft:stone_bricks
fill 71 241 499 76 241 499 minecraft:black_concrete
fill 72 241 491 73 241 492 minecraft:stone_bricks
setblock 74 241 466 minecraft:light[level=14]
setblock 74 241 474 minecraft:light[level=14]
fill 74 241 476 75 241 477 minecraft:stone_bricks
setblock 74 241 482 minecraft:light[level=14]
setblock 74 241 490 minecraft:light[level=14]
setblock 74 241 498 minecraft:light[level=14]
setblock 80 241 482 minecraft:stone_bricks
fill 80 241 484 81 241 485 minecraft:stone_bricks
setblock 81 241 486 minecraft:stone_bricks
setblock 82 241 466 minecraft:light[level=14]
setblock 82 241 474 minecraft:light[level=14]
setblock 82 241 482 minecraft:light[level=14]
setblock 82 241 490 minecraft:light[level=14]
setblock 82 241 498 minecraft:light[level=14]
fill 47 242 467 47 307 467 minecraft:white_concrete
fill 47 242 468 47 247 468 minecraft:sea_lantern
fill 47 242 476 47 247 476 minecraft:sea_lantern
fill 47 242 484 47 247 484 minecraft:sea_lantern
fill 47 242 485 47 307 491 minecraft:white_concrete
fill 47 242 492 47 247 492 minecraft:sea_lantern
fill 47 242 493 47 307 496 minecraft:white_concrete
fill 47 242 499 47 307 499 minecraft:white_concrete
fill 47 242 500 47 247 500 minecraft:sea_lantern
fill 47 242 505 49 307 505 minecraft:white_concrete
fill 50 242 505 50 247 505 minecraft:sea_lantern
fill 51 242 505 51 307 505 minecraft:white_concrete
fill 54 242 463 54 247 463 minecraft:sea_lantern
fill 58 242 504 61 242 504 minecraft:quartz_block
fill 58 242 505 58 247 505 minecraft:sea_lantern
fill 59 242 502 66 242 503 minecraft:quartz_block
fill 59 242 505 60 307 505 minecraft:white_concrete
fill 60 242 500 66 242 501 minecraft:quartz_block
fill 61 242 463 61 307 463 minecraft:white_concrete
fill 62 242 463 62 247 463 minecraft:sea_lantern
fill 64 242 463 69 307 463 minecraft:white_concrete
fill 64 242 504 66 242 504 minecraft:quartz_block
fill 64 242 505 65 307 505 minecraft:white_concrete
fill 66 242 505 66 247 505 minecraft:sea_lantern
fill 67 242 499 72 242 499 minecraft:black_concrete
fill 67 242 505 73 307 505 minecraft:white_concrete
fill 70 242 463 70 247 463 minecraft:sea_lantern
fill 71 242 463 74 307 463 minecraft:white_concrete
fill 74 242 505 74 247 505 minecraft:sea_lantern
fill 75 242 505 79 307 505 minecraft:white_concrete
fill 76 242 463 77 307 463 minecraft:white_concrete
fill 78 242 463 78 247 463 minecraft:sea_lantern
fill 82 242 505 82 247 505 minecraft:sea_lantern
fill 83 242 505 84 307 505 minecraft:white_concrete
fill 86 242 463 86 247 463 minecraft:sea_lantern
fill 89 242 468 89 247 468 minecraft:sea_lantern
fill 89 242 469 89 307 475 minecraft:white_concrete
fill 89 242 476 89 247 476 minecraft:sea_lantern
fill 89 242 484 89 247 484 minecraft:sea_lantern
fill 89 242 492 89 247 492 minecraft:sea_lantern
fill 89 242 493 89 307 493 minecraft:white_concrete
fill 89 242 500 89 247 500 minecraft:sea_lantern
fill 51 243 504 53 244 504 minecraft:quartz_block
fill 52 243 503 61 243 503 minecraft:quartz_block
fill 53 243 501 61 243 502 minecraft:quartz_block
fill 54 243 500 62 243 500 minecraft:quartz_block
fill 56 243 504 60 243 504 minecraft:quartz_block
setblock 62 243 501 minecraft:quartz_block
fill 63 243 499 68 243 499 minecraft:black_concrete
fill 48 244 498 52 244 501 minecraft:quartz_block
fill 48 244 504 50 244 504 minecraft:quartz_block
fill 49 244 502 55 244 503 minecraft:quartz_block
fill 50 244 497 52 245 497 minecraft:quartz_block
fill 51 244 496 52 245 496 minecraft:quartz_block
fill 53 244 500 56 244 501 minecraft:quartz_block
setblock 56 244 502 minecraft:quartz_block
setblock 57 244 500 minecraft:quartz_block
fill 59 244 499 65 244 499 minecraft:black_concrete
fill 65 244 478 69 244 479 minecraft:dark_oak_planks
fill 65 244 489 69 244 490 minecraft:dark_oak_planks
fill 66 244 477 69 244 477 minecraft:dark_oak_planks
fill 66 244 480 69 244 480 minecraft:dark_oak_planks
fill 66 244 488 69 244 488 minecraft:dark_oak_planks
fill 66 244 491 69 244 491 minecraft:dark_oak_planks
fill 67 244 476 68 244 476 minecraft:dark_oak_planks
fill 67 244 492 68 244 492 minecraft:dark_oak_planks
fill 77 244 477 80 244 480 minecraft:dark_oak_planks
fill 77 244 488 80 244 491 minecraft:dark_oak_planks
fill 78 244 476 79 244 476 minecraft:dark_oak_planks
fill 78 244 492 79 244 492 minecraft:dark_oak_planks
fill 81 244 478 81 244 479 minecraft:dark_oak_planks
fill 81 244 489 81 244 490 minecraft:dark_oak_planks
fill 48 245 492 52 245 493 minecraft:quartz_block
fill 48 245 496 49 245 501 minecraft:quartz_block
fill 49 245 494 52 245 495 minecraft:quartz_block
fill 50 245 491 52 246 491 minecraft:quartz_block
setblock 50 245 496 minecraft:quartz_block
fill 50 245 498 50 245 500 minecraft:quartz_block
fill 51 245 498 51 245 499 minecraft:quartz_block
setblock 52 245 498 minecraft:quartz_block
fill 53 245 498 53 246 499 minecraft:black_concrete
fill 54 245 499 61 245 499 minecraft:black_concrete
fill 66 245 477 68 245 479 minecraft:dark_oak_planks
fill 66 245 489 68 245 491 minecraft:dark_oak_planks
fill 67 245 480 68 245 480 minecraft:dark_oak_planks
fill 67 245 488 68 245 488 minecraft:dark_oak_planks
fill 69 245 478 69 245 479 minecraft:dark_oak_planks
fill 69 245 489 69 245 490 minecraft:dark_oak_planks
fill 77 245 478 80 245 479 minecraft:dark_oak_planks
fill 77 245 489 80 245 490 minecraft:dark_oak_planks
fill 78 245 477 80 245 477 minecraft:dark_oak_planks
fill 78 245 480 79 245 480 minecraft:dark_oak_planks
fill 78 245 488 79 245 488 minecraft:dark_oak_planks
fill 78 245 491 80 245 491 minecraft:dark_oak_planks
fill 48 246 488 49 246 493 minecraft:quartz_block
fill 49 246 487 52 247 487 minecraft:quartz_block
fill 49 246 494 50 246 494 minecraft:quartz_block
fill 50 246 488 52 246 490 minecraft:quartz_block
fill 50 246 492 51 246 493 minecraft:quartz_block
fill 52 246 486 52 247 486 minecraft:quartz_block
setblock 52 246 492 minecraft:quartz_block
fill 53 246 493 53 246 497 minecraft:black_concrete
fill 54 246 499 55 246 499 minecraft:black_concrete
fill 66 246 478 68 246 479 minecraft:dark_oak_planks
fill 66 246 489 68 246 490 minecraft:dark_oak_planks
fill 67 246 477 68 246 477 minecraft:dark_oak_planks
fill 67 246 491 68 246 491 minecraft:dark_oak_planks
fill 78 246 477 79 246 479 minecraft:dark_oak_planks
fill 78 246 489 79 246 491 minecraft:dark_oak_planks
fill 80 246 478 80 246 479 minecraft:dark_oak_planks
fill 80 246 489 80 246 490 minecraft:dark_oak_planks
fill 48 247 482 51 247 485 minecraft:quartz_block
fill 48 247 488 49 247 489 minecraft:quartz_block
fill 49 247 486 51 247 486 minecraft:quartz_block
fill 50 247 488 52 247 488 minecraft:quartz_block
fill 52 247 483 52 247 485 minecraft:quartz_block
fill 53 247 489 53 247 495 minecraft:black_concrete
fill 67 247 478 68 247 479 minecraft:dark_oak_planks
fill 67 247 489 68 247 490 minecraft:dark_oak_planks
fill 78 247 478 79 247 479 minecraft:dark_oak_planks
fill 78 247 489 79 247 490 minecraft:dark_oak_planks
fill 47 248 468 47 255 468 minecraft:white_concrete
fill 47 248 476 47 255 476 minecraft:white_concrete
fill 47 248 484 47 255 484 minecraft:white_concrete
fill 47 248 492 47 255 492 minecraft:white_concrete
fill 47 248 500 47 255 500 minecraft:white_concrete
fill 48 248 477 49 249 477 minecraft:quartz_block
fill 48 248 480 52 248 484 minecraft:quartz_block
fill 49 248 478 52 249 479 minecraft:quartz_block
fill 50 248 505 50 255 505 minecraft:white_concrete
fill 53 248 485 53 248 490 minecraft:black_concrete
fill 54 248 463 54 255 463 minecraft:white_concrete
fill 58 248 505 58 255 505 minecraft:white_concrete
fill 62 248 463 62 255 463 minecraft:white_concrete
fill 66 248 505 66 255 505 minecraft:white_concrete
setblock 67 248 478 minecraft:dark_oak_planks
setblock 67 248 490 minecraft:dark_oak_planks
fill 70 248 463 70 255 463 minecraft:white_concrete
fill 74 248 505 74 255 505 minecraft:white_concrete
fill 78 248 463 78 255 463 minecraft:white_concrete
setblock 79 248 478 minecraft:dark_oak_planks
setblock 79 248 490 minecraft:dark_oak_planks
fill 82 248 505 82 255 505 minecraft:white_concrete
fill 86 248 463 86 255 463 minecraft:white_concrete
fill 89 248 468 89 255 468 minecraft:white_concrete
fill 89 248 476 89 255 476 minecraft:white_concrete
fill 89 248 484 89 255 484 minecraft:white_concrete
fill 89 248 492 89 255 492 minecraft:white_concrete
fill 89 248 500 89 255 500 minecraft:white_concrete
fill 48 249 472 50 249 476 minecraft:quartz_block
fill 49 249 471 49 250 471 minecraft:quartz_block
setblock 50 249 466 minecraft:light[level=14]
fill 50 249 477 52 249 477 minecraft:quartz_block
fill 50 249 480 52 249 480 minecraft:quartz_block
setblock 50 249 482 minecraft:light[level=14]
setblock 50 249 490 minecraft:light[level=14]
setblock 50 249 498 minecraft:light[level=14]
fill 51 249 473 52 249 476 minecraft:quartz_block
fill 53 249 481 53 249 486 minecraft:black_concrete
setblock 58 249 466 minecraft:light[level=14]
setblock 58 249 474 minecraft:light[level=14]
setblock 58 249 482 minecraft:light[level=14]
setblock 58 249 490 minecraft:light[level=14]
setblock 58 249 498 minecraft:light[level=14]
setblock 66 249 466 minecraft:light[level=14]
setblock 66 249 474 minecraft:light[level=14]
setblock 66 249 482 minecraft:light[level=14]
setblock 66 249 490 minecraft:light[level=14]
setblock 66 249 498 minecraft:light[level=14]
setblock 74 249 466 minecraft:light[level=14]
setblock 74 249 474 minecraft:light[level=14]
setblock 74 249 482 minecraft:light[level=14]
setblock 74 249 490 minecraft:light[level=14]
setblock 74 249 498 minecraft:light[level=14]
setblock 82 249 466 minecraft:light[level=14]
setblock 82 249 474 minecraft:light[level=14]
setblock 82 249 482 minecraft:light[level=14]
setblock 82 249 490 minecraft:light[level=14]
setblock 82 249 498 minecraft:light[level=14]
fill 48 250 464 48 250 469 minecraft:quartz_block
fill 48 250 472 52 250 474 minecraft:quartz_block
fill 49 250 465 51 250 470 minecraft:quartz_block
fill 50 250 471 52 250 471 minecraft:quartz_block
fill 50 250 475 52 250 475 minecraft:quartz_block
fill 52 250 466 52 251 470 minecraft:quartz_block
setblock 52 250 476 minecraft:quartz_block
fill 53 250 468 53 251 468 minecraft:quartz_block
fill 53 250 477 53 250 482 minecraft:black_concrete
fill 48 251 464 48 253 467 minecraft:quartz_block
fill 49 251 465 51 251 467 minecraft:quartz_block
fill 50 251 468 51 251 468 minecraft:quartz_block
fill 51 251 464 56 253 464 minecraft:quartz_block
setblock 51 251 469 minecraft:quartz_block
fill 52 251 465 58 252 465 minecraft:quartz_block
fill 53 251 466 58 251 467 minecraft:quartz_block
fill 53 251 472 53 251 479 minecraft:black_concrete
fill 54 251 468 59 251 468 minecraft:quartz_block
fill 59 251 467 59 252 467 minecraft:quartz_block
fill 48 252 468 49 252 469 minecraft:quartz_block
fill 48 252 472 49 252 477 minecraft:quartz_block
fill 48 252 480 49 252 485 minecraft:quartz_block
fill 48 252 488 49 252 493 minecraft:quartz_block
fill 48 252 496 49 252 501 minecraft:quartz_block
fill 48 252 504 53 253 504 minecraft:quartz_block
fill 49 252 465 49 252 467 minecraft:quartz_block
fill 49 252 470 49 252 471 minecraft:quartz_block
fill 49 252 478 49 252 479 minecraft:quartz_block
fill 49 252 486 49 252 487 minecraft:quartz_block
fill 49 252 494 49 252 495 minecraft:quartz_block
fill 49 252 502 49 252 503 minecraft:quartz_block
fill 50 252 465 51 252 465 minecraft:quartz_block
fill 50 252 503 88 252 503 minecraft:quartz_block
fill 53 252 469 53 252 474 minecraft:black_concrete
fill 54 252 469 57 253 469 minecraft:black_concrete
fill 55 252 466 63 252 466 minecraft:quartz_block
fill 56 252 467 58 252 467 minecraft:quartz_block
fill 56 252 504 61 253 504 minecraft:quartz_block
fill 57 252 468 64 252 468 minecraft:quartz_block
fill 59 252 464 64 252 465 minecraft:quartz_block
fill 60 252 467 63 252 467 minecraft:quartz_block
fill 64 252 504 69 253 504 minecraft:quartz_block
fill 65 252 465 87 252 465 minecraft:quartz_block
fill 67 252 464 72 254 464 minecraft:quartz_block
fill 72 252 504 77 253 504 minecraft:quartz_block
fill 75 252 464 80 253 464 minecraft:quartz_block
fill 80 252 504 85 253 504 minecraft:quartz_block
fill 83 252 464 88 253 464 minecraft:quartz_block
fill 87 252 466 87 252 502 minecraft:quartz_block
fill 88 252 467 88 253 472 minecraft:quartz_block
fill 88 252 475 88 253 480 minecraft:quartz_block
fill 88 252 483 88 253 488 minecraft:quartz_block
fill 88 252 491 88 253 496 minecraft:quartz_block
fill 88 252 499 88 253 502 minecraft:quartz_block
fill 88 252 504 88 253 504 minecraft:quartz_block
fill 48 253 468 48 253 469 minecraft:quartz_block
fill 48 253 472 48 253 477 minecraft:quartz_block
fill 48 253 480 48 253 485 minecraft:quartz_block
fill 48 253 488 48 253 493 minecraft:quartz_block
fill 48 253 496 48 253 501 minecraft:quartz_block
fill 58 253 469 61 253 469 minecraft:black_concrete
fill 59 253 464 64 253 464 minecraft:quartz_block
fill 61 253 465 68 253 466 minecraft:quartz_block
fill 62 253 467 68 253 468 minecraft:quartz_block
setblock 88 253 503 minecraft:quartz_block
fill 60 254 469 65 254 469 minecraft:black_concrete
fill 66 254 465 71 254 468 minecraft:quartz_block
fill 72 254 465 72 255 467 minecraft:quartz_block
fill 64 255 469 69 255 469 minecraft:black_concrete
fill 70 255 464 71 255 468 minecraft:quartz_block
setblock 72 255 464 minecraft:quartz_block
fill 72 255 468 76 255 468 minecraft:quartz_block
fill 73 255 465 76 255 467 minecraft:quartz_block
fill 75 255 464 78 255 464 minecraft:quartz_block
fill 77 255 465 77 256 466 minecraft:quartz_block
fill 47 256 468 47 261 468 minecraft:sea_lantern
fill 47 256 476 47 261 476 minecraft:sea_lantern
fill 47 256 484 47 261 484 minecraft:sea_lantern
fill 47 256 492 47 261 492 minecraft:sea_lantern
fill 47 256 500 47 261 500 minecraft:sea_lantern
fill 50 256 505 50 261 505 minecraft:sea_lantern
fill 54 256 463 54 261 463 minecraft:sea_lantern
fill 58 256 505 58 261 505 minecraft:sea_lantern
fill 62 256 463 62 261 463 minecraft:sea_lantern
fill 66 256 505 66 261 505 minecraft:sea_lantern
fill 68 256 469 73 256 469 minecraft:black_concrete
fill 70 256 463 70 261 463 minecraft:sea_lantern
fill 74 256 467 82 256 468 minecraft:quartz_block
fill 74 256 505 74 261 505 minecraft:sea_lantern
fill 75 256 465 76 256 466 minecraft:quartz_block
fill 76 256 464 80 256 464 minecraft:quartz_block
fill 78 256 463 78 261 463 minecraft:sea_lantern
fill 78 256 465 83 256 466 minecraft:quartz_block
fill 82 256 505 82 261 505 minecraft:sea_lantern
fill 83 256 464 85 257 464 minecraft:quartz_block
fill 83 256 467 83 257 467 minecraft:quartz_block
fill 84 256 465 84 257 465 minecraft:quartz_block
fill 86 256 463 86 261 463 minecraft:sea_lantern
fill 89 256 468 89 261 468 minecraft:sea_lantern
fill 89 256 476 89 261 476 minecraft:sea_lantern
fill 89 256 484 89 261 484 minecraft:sea_lantern
fill 89 256 492 89 261 492 minecraft:sea_lantern
fill 89 256 500 89 261 500 minecraft:sea_lantern
setblock 50 257 466 minecraft:light[level=14]
setblock 50 257 474 minecraft:light[level=14]
setblock 50 257 482 minecraft:light[level=14]
setblock 50 257 490 minecraft:light[level=14]
setblock 50 257 498 minecraft:light[level=14]
setblock 58 257 466 minecraft:light[level=14]
setblock 58 257 474 minecraft:light[level=14]
setblock 58 257 482 minecraft:light[level=14]
setblock 58 257 490 minecraft:light[level=14]
setblock 58 257 498 minecraft:light[level=14]
setblock 66 257 466 minecraft:light[level=14]
setblock 66 257 474 minecraft:light[level=14]
setblock 66 257 482 minecraft:light[level=14]
setblock 66 257 490 minecraft:light[level=14]
setblock 66 257 498 minecraft:light[level=14]
fill 71 257 469 77 257 469 minecraft:black_concrete
setblock 74 257 466 minecraft:light[level=14]
setblock 74 257 474 minecraft:light[level=14]
setblock 74 257 482 minecraft:light[level=14]
setblock 74 257 490 minecraft:light[level=14]
setblock 74 257 498 minecraft:light[level=14]
fill 79 257 468 88 257 468 minecraft:quartz_block
fill 80 257 466 82 257 467 minecraft:quartz_block
fill 81 257 465 83 257 465 minecraft:quartz_block
setblock 82 257 474 minecraft:light[level=14]
setblock 82 257 482 minecraft:light[level=14]
setblock 82 257 490 minecraft:light[level=14]
setblock 82 257 498 minecraft:light[level=14]
fill 83 257 466 87 257 466 minecraft:quartz_block
fill 84 257 467 88 257 467 minecraft:quartz_block
fill 84 257 469 85 257 472 minecraft:quartz_block
fill 85 257 465 87 257 465 minecraft:quartz_block
fill 86 257 464 88 257 464 minecraft:quartz_block
fill 86 257 469 86 258 471 minecraft:quartz_block
fill 87 257 469 88 258 470 minecraft:quartz_block
fill 75 258 469 83 258 469 minecraft:black_concrete
fill 83 258 470 83 259 470 minecraft:black_concrete
fill 84 258 470 85 258 477 minecraft:quartz_block
setblock 85 258 469 minecraft:quartz_block
fill 86 258 468 88 258 468 minecraft:quartz_block
fill 86 258 472 86 258 477 minecraft:quartz_block
fill 87 258 467 88 258 467 minecraft:quartz_block
fill 87 258 471 87 258 476 minecraft:quartz_block
fill 88 258 471 88 258 472 minecraft:quartz_block
fill 88 258 475 88 259 476 minecraft:quartz_block
fill 81 259 469 83 259 469 minecraft:black_concrete
fill 83 259 471 83 259 475 minecraft:black_concrete
fill 84 259 476 84 259 482 minecraft:quartz_block
fill 85 259 475 87 259 481 minecraft:quartz_block
fill 86 259 474 87 259 474 minecraft:quartz_block
fill 88 259 477 88 259 480 minecraft:quartz_block
fill 83 260 473 83 260 479 minecraft:black_concrete
fill 84 260 480 87 260 485 minecraft:quartz_block
fill 85 260 486 88 261 486 minecraft:quartz_block
fill 87 260 479 88 260 479 minecraft:quartz_block
setblock 88 260 480 minecraft:quartz_block
fill 88 260 483 88 260 485 minecraft:quartz_block
fill 83 261 478 83 261 483 minecraft:black_concrete
fill 84 261 484 84 261 490 minecraft:quartz_block
fill 85 261 484 88 261 485 minecraft:quartz_block
fill 85 261 487 87 261 490 minecraft:quartz_block
fill 87 261 491 88 262 491 minecraft:quartz_block
fill 88 261 487 88 261 488 minecraft:quartz_block
fill 47 262 468 47 269 468 minecraft:white_concrete
fill 47 262 476 47 269 476 minecraft:white_concrete
fill 47 262 484 47 269 484 minecraft:white_concrete
fill 47 262 492 47 269 492 minecraft:white_concrete
fill 47 262 500 47 269 500 minecraft:white_concrete
fill 50 262 505 50 269 505 minecraft:white_concrete
fill 54 262 463 54 269 463 minecraft:white_concrete
fill 58 262 505 58 269 505 minecraft:white_concrete
fill 62 262 463 62 269 463 minecraft:white_concrete
fill 66 262 505 66 269 505 minecraft:white_concrete
fill 70 262 463 70 269 463 minecraft:white_concrete
fill 74 262 505 74 269 505 minecraft:white_concrete
fill 78 262 463 78 269 463 minecraft:white_concrete
fill 82 262 505 82 269 505 minecraft:white_concrete
fill 83 262 482 83 262 487 minecraft:black_concrete
fill 84 262 488 86 262 495 minecraft:quartz_block
fill 86 262 463 86 269 463 minecraft:white_concrete
fill 86 262 496 88 263 496 minecraft:quartz_block
fill 87 262 489 87 262 490 minecraft:quartz_block
fill 87 262 492 88 262 495 minecraft:quartz_block
fill 87 262 497 87 263 497 minecraft:quartz_block
fill 89 262 468 89 269 468 minecraft:white_concrete
fill 89 262 476 89 269 476 minecraft:white_concrete
fill 89 262 484 89 269 484 minecraft:white_concrete
schedule function dropper:buildpart/109_3 1t
