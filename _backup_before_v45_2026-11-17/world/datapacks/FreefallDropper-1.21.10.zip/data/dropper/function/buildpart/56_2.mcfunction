setblock 376 177 250 minecraft:jungle_leaves[persistent=true]
fill 376 177 251 376 200 252 minecraft:green_terracotta
fill 378 177 228 378 183 228 minecraft:green_terracotta
setblock 386 177 245 minecraft:light[level=12]
setblock 386 177 252 minecraft:light[level=12]
setblock 387 177 247 minecraft:light[level=15]
setblock 388 177 228 minecraft:moss_block
fill 388 177 270 388 190 270 minecraft:green_terracotta
fill 389 177 228 389 195 228 minecraft:green_terracotta
fill 391 177 270 391 191 270 minecraft:green_terracotta
setblock 393 177 245 minecraft:light[level=12]
setblock 393 177 252 minecraft:light[level=12]
setblock 395 177 247 minecraft:light[level=15]
setblock 395 177 255 minecraft:light[level=15]
setblock 400 177 245 minecraft:light[level=12]
setblock 400 177 252 minecraft:light[level=12]
fill 401 177 228 401 208 228 minecraft:green_terracotta
setblock 418 177 262 minecraft:moss_block
setblock 418 177 263 minecraft:mossy_cobblestone
setblock 376 178 244 minecraft:green_concrete
fill 376 178 250 376 219 250 minecraft:green_terracotta
fill 383 178 230 383 178 245 minecraft:brown_terracotta
fill 383 178 246 383 178 250 minecraft:bone_block
fill 383 178 251 383 178 268 minecraft:brown_terracotta
fill 384 178 244 384 178 245 minecraft:bone_block
fill 384 178 251 384 178 252 minecraft:bone_block
fill 385 178 230 385 181 241 minecraft:brown_terracotta
fill 385 178 242 385 178 243 minecraft:bone_block
fill 385 178 253 385 178 254 minecraft:bone_block
fill 385 178 255 385 181 268 minecraft:brown_terracotta
fill 386 178 230 386 181 240 minecraft:brown_terracotta
setblock 386 178 241 minecraft:bone_block
setblock 386 178 255 minecraft:bone_block
fill 386 178 256 386 181 268 minecraft:brown_terracotta
fill 387 178 230 387 182 239 minecraft:brown_terracotta
fill 387 178 240 388 178 240 minecraft:bone_block
fill 387 178 256 388 178 256 minecraft:bone_block
fill 387 178 257 387 182 268 minecraft:brown_terracotta
fill 388 178 228 388 195 228 minecraft:green_terracotta
fill 389 178 239 390 178 239 minecraft:bone_block
fill 389 178 257 390 178 257 minecraft:bone_block
fill 391 178 230 391 183 237 minecraft:brown_terracotta
fill 391 178 238 395 178 238 minecraft:bone_block
fill 391 178 258 395 178 258 minecraft:bone_block
fill 391 178 259 391 183 268 minecraft:brown_terracotta
fill 396 178 238 416 178 238 minecraft:brown_terracotta
fill 396 178 239 397 178 239 minecraft:bone_block
fill 396 178 257 397 178 257 minecraft:bone_block
fill 396 178 258 416 178 258 minecraft:brown_terracotta
fill 398 178 240 399 178 240 minecraft:bone_block
fill 398 178 256 399 178 256 minecraft:bone_block
fill 400 178 240 416 181 240 minecraft:brown_terracotta
setblock 400 178 241 minecraft:bone_block
setblock 400 178 255 minecraft:bone_block
fill 400 178 256 416 181 256 minecraft:brown_terracotta
fill 401 178 241 416 181 241 minecraft:brown_terracotta
fill 401 178 242 401 178 243 minecraft:bone_block
fill 401 178 253 401 178 254 minecraft:bone_block
fill 401 178 255 416 181 255 minecraft:brown_terracotta
fill 402 178 242 416 182 242 minecraft:brown_terracotta
fill 402 178 244 402 178 245 minecraft:bone_block
fill 402 178 251 402 178 252 minecraft:bone_block
fill 402 178 254 416 182 254 minecraft:brown_terracotta
fill 403 178 246 403 178 250 minecraft:bone_block
fill 404 178 246 416 183 246 minecraft:brown_terracotta
fill 404 178 250 416 183 250 minecraft:brown_terracotta
setblock 418 178 250 minecraft:moss_block
fill 418 178 262 418 196 263 minecraft:green_terracotta
setblock 376 179 235 minecraft:moss_block
setblock 376 179 238 minecraft:moss_block
fill 376 179 244 376 222 244 minecraft:green_terracotta
setblock 379 179 228 minecraft:moss_block
fill 383 179 230 383 181 244 minecraft:brown_terracotta
fill 383 179 245 383 181 251 minecraft:brown_concrete
fill 383 179 252 383 181 268 minecraft:brown_terracotta
fill 384 179 230 384 182 242 minecraft:brown_terracotta
fill 384 179 243 384 181 244 minecraft:brown_concrete
fill 384 179 252 384 181 253 minecraft:brown_concrete
fill 384 179 254 384 182 268 minecraft:brown_terracotta
fill 385 179 242 385 181 242 minecraft:brown_concrete
fill 385 179 254 385 181 254 minecraft:brown_concrete
fill 386 179 241 386 181 241 minecraft:brown_concrete
fill 386 179 255 386 181 255 minecraft:brown_concrete
fill 387 179 240 387 181 240 minecraft:brown_concrete
fill 387 179 256 387 181 256 minecraft:brown_concrete
fill 388 179 230 388 184 238 minecraft:brown_terracotta
fill 388 179 239 389 181 239 minecraft:brown_concrete
fill 388 179 257 389 181 257 minecraft:brown_concrete
fill 388 179 258 388 184 268 minecraft:brown_terracotta
fill 390 179 230 390 185 237 minecraft:brown_terracotta
fill 390 179 238 396 181 238 minecraft:brown_concrete
fill 390 179 258 396 181 258 minecraft:brown_concrete
fill 390 179 259 390 185 268 minecraft:brown_terracotta
fill 397 179 238 416 181 238 minecraft:brown_terracotta
fill 397 179 239 398 181 239 minecraft:brown_concrete
fill 397 179 257 398 181 257 minecraft:brown_concrete
fill 397 179 258 416 181 258 minecraft:brown_terracotta
fill 399 179 239 416 182 239 minecraft:brown_terracotta
fill 399 179 240 399 181 240 minecraft:brown_concrete
fill 399 179 256 399 181 256 minecraft:brown_concrete
fill 399 179 257 416 182 257 minecraft:brown_terracotta
fill 400 179 241 400 181 241 minecraft:brown_concrete
fill 400 179 255 400 181 255 minecraft:brown_concrete
fill 401 179 242 401 181 242 minecraft:brown_concrete
fill 401 179 254 401 181 254 minecraft:brown_concrete
fill 402 179 243 402 181 244 minecraft:brown_concrete
fill 402 179 252 402 181 253 minecraft:brown_concrete
fill 403 179 243 416 184 243 minecraft:brown_terracotta
fill 403 179 245 403 181 251 minecraft:brown_concrete
fill 403 179 253 416 184 253 minecraft:brown_terracotta
fill 404 179 245 416 185 245 minecraft:brown_terracotta
fill 404 179 251 416 185 251 minecraft:brown_terracotta
fill 418 179 250 418 222 250 minecraft:green_terracotta
fill 418 179 256 418 222 256 minecraft:green_terracotta
setblock 418 179 257 minecraft:mossy_cobblestone
fill 376 180 235 376 183 235 minecraft:green_terracotta
fill 376 180 238 376 218 238 minecraft:green_terracotta
fill 379 180 228 379 186 228 minecraft:green_terracotta
setblock 399 180 270 minecraft:mossy_cobblestone
setblock 418 180 246 minecraft:moss_block
fill 418 180 257 418 217 257 minecraft:green_terracotta
fill 399 181 270 399 222 270 minecraft:green_terracotta
fill 418 181 246 418 222 246 minecraft:green_terracotta
fill 383 182 230 383 184 243 minecraft:brown_terracotta
fill 383 182 244 383 182 252 minecraft:bone_block
fill 383 182 253 383 184 268 minecraft:brown_terracotta
setblock 384 182 243 minecraft:bone_block
setblock 384 182 253 minecraft:bone_block
fill 385 182 230 385 186 240 minecraft:brown_terracotta
fill 385 182 241 385 182 242 minecraft:bone_block
fill 385 182 254 385 182 255 minecraft:bone_block
fill 385 182 256 385 186 268 minecraft:brown_terracotta
fill 386 182 230 386 186 239 minecraft:brown_terracotta
fill 386 182 240 387 182 240 minecraft:bone_block
fill 386 182 256 387 182 256 minecraft:bone_block
fill 386 182 257 386 186 268 minecraft:brown_terracotta
setblock 388 182 239 minecraft:bone_block
setblock 388 182 257 minecraft:bone_block
fill 389 182 230 389 187 237 minecraft:brown_terracotta
fill 389 182 238 397 182 238 minecraft:bone_block
fill 389 182 258 397 182 258 minecraft:bone_block
fill 389 182 259 389 187 268 minecraft:brown_terracotta
fill 398 182 238 416 184 238 minecraft:brown_terracotta
setblock 398 182 239 minecraft:bone_block
setblock 398 182 257 minecraft:bone_block
fill 398 182 258 416 184 258 minecraft:brown_terracotta
fill 399 182 240 400 182 240 minecraft:bone_block
fill 399 182 256 400 182 256 minecraft:bone_block
fill 401 182 240 416 186 240 minecraft:brown_terracotta
fill 401 182 241 401 182 242 minecraft:bone_block
fill 401 182 254 401 182 255 minecraft:bone_block
fill 401 182 256 416 186 256 minecraft:brown_terracotta
fill 401 182 270 401 220 270 minecraft:green_terracotta
fill 402 182 241 416 186 241 minecraft:brown_terracotta
setblock 402 182 243 minecraft:bone_block
setblock 402 182 253 minecraft:bone_block
fill 402 182 255 416 186 255 minecraft:brown_terracotta
setblock 402 182 270 minecraft:moss_block
fill 403 182 244 403 182 252 minecraft:bone_block
fill 404 182 244 416 187 244 minecraft:brown_terracotta
fill 404 182 252 416 187 252 minecraft:brown_terracotta
fill 378 183 230 381 189 268 minecraft:brown_terracotta
fill 382 183 230 382 183 246 minecraft:brown_terracotta
fill 382 183 247 382 185 249 minecraft:brown_concrete
fill 382 183 250 382 183 268 minecraft:brown_terracotta
fill 383 183 244 383 183 246 minecraft:brown_concrete
fill 383 183 250 383 183 252 minecraft:brown_concrete
fill 384 183 230 384 186 241 minecraft:brown_terracotta
fill 384 183 242 384 184 243 minecraft:brown_concrete
fill 384 183 253 384 184 254 minecraft:brown_concrete
fill 384 183 255 384 186 268 minecraft:brown_terracotta
setblock 384 183 270 minecraft:green_terracotta
fill 385 183 241 385 185 241 minecraft:brown_concrete
fill 385 183 255 385 185 255 minecraft:brown_concrete
fill 385 183 270 385 187 270 minecraft:oak_leaves[persistent=true]
fill 386 183 240 386 185 240 minecraft:brown_concrete
setblock 386 183 245 minecraft:light[level=12]
setblock 386 183 252 minecraft:light[level=12]
fill 386 183 256 386 185 256 minecraft:brown_concrete
setblock 386 183 270 minecraft:green_terracotta
fill 387 183 230 387 188 238 minecraft:brown_terracotta
fill 387 183 239 388 184 239 minecraft:brown_concrete
fill 387 183 257 388 184 257 minecraft:brown_concrete
fill 387 183 258 387 188 268 minecraft:brown_terracotta
fill 389 183 238 391 183 238 minecraft:brown_concrete
fill 389 183 258 391 183 258 minecraft:brown_concrete
fill 392 183 230 416 189 236 minecraft:brown_terracotta
fill 392 183 237 394 185 237 minecraft:brown_concrete
fill 392 183 259 394 185 259 minecraft:brown_concrete
fill 392 183 260 416 189 268 minecraft:brown_terracotta
setblock 393 183 228 minecraft:moss_block
setblock 393 183 238 minecraft:light[level=12]
setblock 393 183 245 minecraft:light[level=12]
setblock 393 183 252 minecraft:light[level=12]
fill 395 183 237 416 183 237 minecraft:brown_terracotta
fill 395 183 238 397 183 238 minecraft:brown_concrete
fill 395 183 258 397 183 258 minecraft:brown_concrete
fill 395 183 259 416 183 259 minecraft:brown_terracotta
fill 398 183 239 399 184 239 minecraft:brown_concrete
fill 398 183 257 399 184 257 minecraft:brown_concrete
fill 400 183 239 416 186 239 minecraft:brown_terracotta
fill 400 183 240 400 185 240 minecraft:brown_concrete
setblock 400 183 245 minecraft:light[level=12]
setblock 400 183 252 minecraft:light[level=12]
fill 400 183 256 400 185 256 minecraft:brown_concrete
fill 400 183 257 416 186 257 minecraft:brown_terracotta
fill 401 183 241 401 185 241 minecraft:brown_concrete
fill 401 183 255 401 185 255 minecraft:brown_concrete
fill 402 183 242 402 184 243 minecraft:brown_concrete
fill 402 183 253 402 184 254 minecraft:brown_concrete
fill 402 183 270 402 222 270 minecraft:green_terracotta
fill 403 183 242 416 188 242 minecraft:brown_terracotta
fill 403 183 244 403 183 246 minecraft:brown_concrete
fill 403 183 250 403 183 252 minecraft:brown_concrete
fill 403 183 254 416 188 254 minecraft:brown_terracotta
fill 404 183 247 404 185 249 minecraft:brown_concrete
fill 405 183 247 416 189 249 minecraft:brown_terracotta
setblock 407 183 228 minecraft:green_terracotta
fill 408 183 228 409 187 228 minecraft:jungle_leaves[persistent=true]
fill 376 184 228 377 186 228 minecraft:oak_leaves[persistent=true]
fill 376 184 229 376 186 229 minecraft:jungle_leaves[persistent=true]
fill 376 184 234 376 185 234 minecraft:jungle_log
fill 376 184 235 376 186 236 minecraft:azalea_leaves[persistent=true]
setblock 376 184 254 minecraft:jungle_leaves[persistent=true]
fill 376 184 270 376 187 270 minecraft:jungle_leaves[persistent=true]
setblock 377 184 270 minecraft:jungle_log
setblock 378 184 228 minecraft:jungle_log
setblock 380 184 228 minecraft:green_concrete
fill 382 184 230 382 185 245 minecraft:brown_terracotta
fill 382 184 246 382 185 246 minecraft:brown_concrete
fill 382 184 250 382 185 250 minecraft:brown_concrete
fill 382 184 251 382 185 268 minecraft:brown_terracotta
setblock 383 184 228 minecraft:mossy_cobblestone
fill 383 184 244 383 185 245 minecraft:brown_concrete
fill 383 184 251 383 185 252 minecraft:brown_concrete
fill 384 184 270 384 188 270 minecraft:oak_leaves[persistent=true]
fill 386 184 270 386 187 270 minecraft:oak_leaves[persistent=true]
setblock 387 184 247 minecraft:light[level=15]
setblock 387 184 255 minecraft:light[level=15]
fill 389 184 238 390 185 238 minecraft:brown_concrete
fill 389 184 258 390 185 258 minecraft:brown_concrete
fill 391 184 230 391 190 236 minecraft:brown_terracotta
fill 391 184 237 391 185 237 minecraft:brown_concrete
fill 391 184 259 391 185 259 minecraft:brown_concrete
fill 391 184 260 391 190 268 minecraft:brown_terracotta
fill 393 184 228 393 222 228 minecraft:green_terracotta
fill 395 184 237 395 185 237 minecraft:brown_concrete
setblock 395 184 239 minecraft:light[level=15]
setblock 395 184 247 minecraft:light[level=15]
setblock 395 184 255 minecraft:light[level=15]
fill 395 184 259 395 185 259 minecraft:brown_concrete
fill 396 184 237 416 185 237 minecraft:brown_terracotta
fill 396 184 238 397 185 238 minecraft:brown_concrete
fill 396 184 258 397 185 258 minecraft:brown_concrete
fill 396 184 259 416 185 259 minecraft:brown_terracotta
fill 403 184 244 403 185 245 minecraft:brown_concrete
setblock 403 184 247 minecraft:light[level=15]
fill 403 184 251 403 185 252 minecraft:brown_concrete
fill 404 184 246 404 185 246 minecraft:brown_concrete
fill 404 184 250 404 185 250 minecraft:brown_concrete
fill 405 184 246 416 190 246 minecraft:brown_terracotta
fill 405 184 250 416 190 250 minecraft:brown_terracotta
fill 407 184 228 407 187 228 minecraft:jungle_leaves[persistent=true]
fill 410 184 228 410 187 228 minecraft:jungle_leaves[persistent=true]
fill 414 184 228 415 185 228 minecraft:jungle_log
fill 414 184 270 415 185 270 minecraft:jungle_log
setblock 418 184 252 minecraft:moss_block
fill 418 184 253 418 222 253 minecraft:green_terracotta
fill 376 185 237 376 186 237 minecraft:azalea_leaves[persistent=true]
fill 376 185 245 376 222 245 minecraft:green_terracotta
setblock 376 185 246 minecraft:green_concrete
fill 376 185 254 376 222 254 minecraft:green_terracotta
fill 376 185 260 376 210 260 minecraft:green_terracotta
setblock 376 185 261 minecraft:jungle_leaves[persistent=true]
fill 376 185 262 376 213 263 minecraft:green_terracotta
fill 376 185 269 376 186 269 minecraft:jungle_leaves[persistent=true]
fill 377 185 270 377 187 270 minecraft:jungle_leaves[persistent=true]
fill 378 185 228 378 186 228 minecraft:oak_leaves[persistent=true]
setblock 378 185 270 minecraft:jungle_log
fill 380 185 228 380 202 228 minecraft:green_terracotta
fill 383 185 228 383 210 228 minecraft:green_terracotta
fill 383 185 230 383 188 242 minecraft:brown_terracotta
setblock 383 185 243 minecraft:brown_concrete
setblock 383 185 253 minecraft:brown_concrete
fill 383 185 254 383 188 268 minecraft:brown_terracotta
fill 383 185 270 383 187 270 minecraft:oak_leaves[persistent=true]
setblock 384 185 242 minecraft:brown_concrete
setblock 384 185 254 minecraft:brown_concrete
setblock 387 185 239 minecraft:brown_concrete
setblock 387 185 257 minecraft:brown_concrete
fill 387 185 270 387 186 270 minecraft:oak_leaves[persistent=true]
fill 388 185 230 388 190 237 minecraft:brown_terracotta
setblock 388 185 238 minecraft:brown_concrete
setblock 388 185 258 minecraft:brown_concrete
fill 388 185 259 388 190 268 minecraft:brown_terracotta
setblock 398 185 238 minecraft:brown_concrete
setblock 398 185 258 minecraft:brown_concrete
fill 399 185 238 416 188 238 minecraft:brown_terracotta
setblock 399 185 239 minecraft:brown_concrete
setblock 399 185 257 minecraft:brown_concrete
fill 399 185 258 416 188 258 minecraft:brown_terracotta
setblock 402 185 242 minecraft:brown_concrete
setblock 402 185 254 minecraft:brown_concrete
setblock 403 185 243 minecraft:brown_concrete
setblock 403 185 253 minecraft:brown_concrete
fill 404 185 243 416 190 243 minecraft:brown_terracotta
fill 404 185 253 416 190 253 minecraft:brown_terracotta
fill 406 185 228 406 186 228 minecraft:jungle_leaves[persistent=true]
setblock 411 185 228 minecraft:jungle_leaves[persistent=true]
fill 412 185 228 412 222 228 minecraft:green_terracotta
fill 418 185 252 418 208 252 minecraft:green_terracotta
setblock 376 186 234 minecraft:azalea_leaves[persistent=true]
fill 376 186 246 376 213 246 minecraft:green_terracotta
fill 376 186 261 376 222 261 minecraft:green_terracotta
fill 378 186 270 378 197 270 minecraft:green_terracotta
fill 381 186 228 381 219 228 minecraft:green_terracotta
setblock 382 186 228 minecraft:jungle_leaves[persistent=true]
fill 382 186 230 382 187 244 minecraft:brown_terracotta
fill 382 186 245 382 186 251 minecraft:bone_block
fill 382 186 252 382 187 268 minecraft:brown_terracotta
fill 383 186 243 383 186 244 minecraft:bone_block
fill 383 186 252 383 186 253 minecraft:bone_block
setblock 384 186 242 minecraft:bone_block
setblock 384 186 254 minecraft:bone_block
setblock 385 186 241 minecraft:bone_block
setblock 385 186 255 minecraft:bone_block
setblock 386 186 240 minecraft:bone_block
setblock 386 186 256 minecraft:bone_block
setblock 387 186 239 minecraft:bone_block
setblock 387 186 257 minecraft:bone_block
fill 388 186 238 389 186 238 minecraft:bone_block
fill 388 186 258 389 186 258 minecraft:bone_block
fill 390 186 230 390 192 236 minecraft:brown_terracotta
fill 390 186 237 396 186 237 minecraft:bone_block
fill 390 186 259 396 186 259 minecraft:bone_block
fill 390 186 260 390 192 268 minecraft:brown_terracotta
fill 397 186 237 416 187 237 minecraft:brown_terracotta
fill 397 186 238 398 186 238 minecraft:bone_block
fill 397 186 258 398 186 258 minecraft:bone_block
fill 397 186 259 416 187 259 minecraft:brown_terracotta
setblock 399 186 239 minecraft:bone_block
setblock 399 186 257 minecraft:bone_block
setblock 400 186 240 minecraft:bone_block
setblock 400 186 256 minecraft:bone_block
setblock 401 186 241 minecraft:bone_block
setblock 401 186 255 minecraft:bone_block
setblock 402 186 242 minecraft:bone_block
setblock 402 186 254 minecraft:bone_block
fill 403 186 243 403 186 244 minecraft:bone_block
fill 403 186 252 403 186 253 minecraft:bone_block
fill 404 186 245 404 186 251 minecraft:bone_block
fill 405 186 245 416 192 245 minecraft:brown_terracotta
fill 405 186 251 416 192 251 minecraft:brown_terracotta
setblock 410 186 270 minecraft:green_concrete
fill 411 186 228 411 222 228 minecraft:green_terracotta
fill 414 186 228 415 209 228 minecraft:green_terracotta
fill 414 186 270 415 186 270 minecraft:green_terracotta
setblock 416 186 228 minecraft:green_concrete
fill 417 186 228 417 197 228 minecraft:green_terracotta
setblock 376 187 228 minecraft:oak_leaves[persistent=true]
fill 376 187 229 376 198 229 minecraft:green_terracotta
fill 376 187 234 376 223 234 minecraft:green_terracotta
setblock 376 187 235 minecraft:azalea_leaves[persistent=true]
fill 376 187 236 376 196 237 minecraft:green_terracotta
setblock 376 187 249 minecraft:jungle_leaves[persistent=true]
fill 376 187 269 376 191 269 minecraft:green_terracotta
setblock 377 187 228 minecraft:jungle_leaves[persistent=true]
fill 378 187 228 378 198 228 minecraft:green_terracotta
setblock 379 187 228 minecraft:moss_block
fill 382 187 228 382 209 228 minecraft:green_terracotta
fill 382 187 245 382 189 251 minecraft:brown_concrete
fill 383 187 243 383 187 244 minecraft:brown_concrete
fill 383 187 252 383 187 253 minecraft:brown_concrete
fill 384 187 230 384 191 240 minecraft:brown_terracotta
fill 384 187 241 384 188 242 minecraft:brown_concrete
fill 384 187 254 384 188 255 minecraft:brown_concrete
fill 384 187 256 384 191 268 minecraft:brown_terracotta
fill 385 187 230 385 191 239 minecraft:brown_terracotta
fill 385 187 240 385 189 240 minecraft:brown_concrete
fill 385 187 256 385 189 256 minecraft:brown_concrete
fill 385 187 257 385 191 268 minecraft:brown_terracotta
fill 386 187 230 386 192 238 minecraft:brown_terracotta
fill 386 187 239 387 188 239 minecraft:brown_concrete
fill 386 187 257 387 188 257 minecraft:brown_concrete
fill 386 187 258 386 192 268 minecraft:brown_terracotta
fill 387 187 270 387 222 270 minecraft:green_terracotta
fill 388 187 238 389 187 238 minecraft:brown_concrete
fill 388 187 258 389 187 258 minecraft:brown_concrete
fill 390 187 237 396 189 237 minecraft:brown_concrete
fill 390 187 259 396 189 259 minecraft:brown_concrete
fill 397 187 238 398 187 238 minecraft:brown_concrete
fill 397 187 258 398 187 258 minecraft:brown_concrete
fill 399 187 239 400 188 239 minecraft:brown_concrete
fill 399 187 257 400 188 257 minecraft:brown_concrete
fill 401 187 239 416 191 239 minecraft:brown_terracotta
fill 401 187 240 401 189 240 minecraft:brown_concrete
fill 401 187 256 401 189 256 minecraft:brown_concrete
fill 401 187 257 416 191 257 minecraft:brown_terracotta
fill 402 187 240 416 191 240 minecraft:brown_terracotta
fill 402 187 241 402 188 242 minecraft:brown_concrete
fill 402 187 254 402 188 255 minecraft:brown_concrete
fill 402 187 256 416 191 256 minecraft:brown_terracotta
fill 403 187 241 416 192 241 minecraft:brown_terracotta
fill 403 187 243 403 187 244 minecraft:brown_concrete
fill 403 187 252 403 187 253 minecraft:brown_concrete
fill 403 187 255 416 192 255 minecraft:brown_terracotta
fill 404 187 245 404 189 251 minecraft:brown_concrete
fill 406 187 228 406 197 228 minecraft:green_terracotta
fill 410 187 270 410 189 270 minecraft:green_terracotta
fill 414 187 270 414 218 270 minecraft:green_terracotta
setblock 415 187 270 minecraft:moss_block
fill 416 187 228 416 210 228 minecraft:green_terracotta
fill 376 188 228 377 222 228 minecraft:green_terracotta
fill 376 188 235 376 219 235 minecraft:green_terracotta
fill 376 188 249 376 215 249 minecraft:green_terracotta
fill 376 188 270 377 202 270 minecraft:green_terracotta
fill 379 188 228 379 193 228 minecraft:green_terracotta
setblock 380 188 270 minecraft:moss_block
fill 382 188 230 382 190 243 minecraft:brown_terracotta
fill 382 188 244 382 189 244 minecraft:brown_concrete
fill 382 188 252 382 189 252 minecraft:brown_concrete
fill 382 188 253 382 190 268 minecraft:brown_terracotta
fill 383 188 243 383 189 243 minecraft:brown_concrete
fill 383 188 253 383 189 253 minecraft:brown_concrete
fill 383 188 270 383 198 270 minecraft:green_terracotta
fill 385 188 270 386 219 270 minecraft:green_terracotta
fill 388 188 238 388 189 238 minecraft:brown_concrete
fill 388 188 258 388 189 258 minecraft:brown_concrete
fill 389 188 230 389 194 236 minecraft:brown_terracotta
fill 389 188 237 389 189 237 minecraft:brown_concrete
fill 389 188 259 389 189 259 minecraft:brown_concrete
fill 389 188 260 389 194 268 minecraft:brown_terracotta
fill 397 188 237 397 189 237 minecraft:brown_concrete
fill 397 188 259 397 189 259 minecraft:brown_concrete
fill 398 188 237 416 190 237 minecraft:brown_terracotta
fill 398 188 238 398 189 238 minecraft:brown_concrete
fill 398 188 258 398 189 258 minecraft:brown_concrete
fill 398 188 259 416 190 259 minecraft:brown_terracotta
fill 403 188 243 403 189 243 minecraft:brown_concrete
fill 403 188 253 403 189 253 minecraft:brown_concrete
fill 404 188 244 404 189 244 minecraft:brown_concrete
fill 404 188 252 404 189 252 minecraft:brown_concrete
fill 405 188 244 416 194 244 minecraft:brown_terracotta
fill 405 188 252 416 194 252 minecraft:brown_terracotta
fill 406 188 270 406 210 270 minecraft:green_terracotta
fill 407 188 228 407 196 228 minecraft:green_terracotta
setblock 407 188 270 minecraft:mossy_cobblestone
setblock 408 188 228 minecraft:jungle_leaves[persistent=true]
fill 408 188 270 409 209 270 minecraft:green_terracotta
fill 409 188 228 410 196 228 minecraft:green_terracotta
fill 415 188 270 415 192 270 minecraft:green_terracotta
fill 376 189 266 376 222 266 minecraft:green_terracotta
setblock 376 189 267 minecraft:moss_block
fill 380 189 270 380 196 270 minecraft:green_terracotta
fill 383 189 230 383 192 241 minecraft:brown_terracotta
setblock 383 189 242 minecraft:brown_concrete
setblock 383 189 254 minecraft:brown_concrete
fill 383 189 255 383 192 268 minecraft:brown_terracotta
setblock 384 189 241 minecraft:brown_concrete
setblock 384 189 255 minecraft:brown_concrete
fill 384 189 270 384 222 270 minecraft:green_terracotta
setblock 386 189 239 minecraft:brown_concrete
setblock 386 189 245 minecraft:light[level=12]
setblock 386 189 252 minecraft:light[level=12]
setblock 386 189 257 minecraft:brown_concrete
fill 387 189 230 387 194 237 minecraft:brown_terracotta
setblock 387 189 238 minecraft:brown_concrete
setblock 387 189 258 minecraft:brown_concrete
fill 387 189 259 387 194 268 minecraft:brown_terracotta
setblock 393 189 238 minecraft:light[level=12]
setblock 393 189 245 minecraft:light[level=12]
setblock 393 189 252 minecraft:light[level=12]
fill 396 189 270 396 220 270 minecraft:green_terracotta
setblock 397 189 270 minecraft:moss_block
setblock 399 189 238 minecraft:brown_concrete
setblock 399 189 258 minecraft:brown_concrete
fill 400 189 238 416 192 238 minecraft:brown_terracotta
setblock 400 189 239 minecraft:brown_concrete
setblock 400 189 245 minecraft:light[level=12]
setblock 400 189 252 minecraft:light[level=12]
setblock 400 189 257 minecraft:brown_concrete
fill 400 189 258 416 192 258 minecraft:brown_terracotta
setblock 402 189 241 minecraft:brown_concrete
setblock 402 189 255 minecraft:brown_concrete
setblock 403 189 242 minecraft:brown_concrete
setblock 403 189 254 minecraft:brown_concrete
fill 404 189 242 416 194 242 minecraft:brown_terracotta
fill 404 189 254 416 194 254 minecraft:brown_terracotta
fill 407 189 270 407 209 270 minecraft:green_terracotta
fill 408 189 228 408 196 228 minecraft:green_terracotta
fill 376 190 267 376 203 267 minecraft:green_terracotta
fill 378 190 230 380 196 268 minecraft:brown_terracotta
fill 381 190 230 381 190 246 minecraft:brown_terracotta
fill 381 190 247 381 190 249 minecraft:bone_block
fill 381 190 250 381 190 268 minecraft:brown_terracotta
fill 382 190 244 382 190 246 minecraft:bone_block
fill 382 190 250 382 190 252 minecraft:bone_block
fill 383 190 242 383 190 243 minecraft:bone_block
fill 383 190 253 383 190 254 minecraft:bone_block
setblock 384 190 241 minecraft:bone_block
setblock 384 190 255 minecraft:bone_block
setblock 385 190 240 minecraft:bone_block
setblock 385 190 256 minecraft:bone_block
setblock 386 190 239 minecraft:bone_block
setblock 386 190 257 minecraft:bone_block
fill 387 190 238 388 190 238 minecraft:bone_block
fill 387 190 258 388 190 258 minecraft:bone_block
fill 389 190 237 391 190 237 minecraft:bone_block
fill 389 190 259 391 190 259 minecraft:bone_block
fill 392 190 230 416 196 235 minecraft:brown_terracotta
fill 392 190 236 394 190 236 minecraft:bone_block
fill 392 190 260 394 190 260 minecraft:bone_block
fill 392 190 261 416 196 268 minecraft:brown_terracotta
fill 395 190 236 416 190 236 minecraft:brown_terracotta
fill 395 190 237 397 190 237 minecraft:bone_block
fill 395 190 259 397 190 259 minecraft:bone_block
fill 395 190 260 416 190 260 minecraft:brown_terracotta
fill 397 190 270 397 222 270 minecraft:green_terracotta
fill 398 190 238 399 190 238 minecraft:bone_block
fill 398 190 258 399 190 258 minecraft:bone_block
setblock 400 190 239 minecraft:bone_block
setblock 400 190 257 minecraft:bone_block
setblock 401 190 240 minecraft:bone_block
setblock 401 190 256 minecraft:bone_block
setblock 402 190 241 minecraft:bone_block
setblock 402 190 255 minecraft:bone_block
fill 403 190 242 403 190 243 minecraft:bone_block
fill 403 190 253 403 190 254 minecraft:bone_block
fill 404 190 244 404 190 246 minecraft:bone_block
fill 404 190 250 404 190 252 minecraft:bone_block
fill 405 190 247 405 190 249 minecraft:bone_block
fill 406 190 247 416 196 249 minecraft:brown_terracotta
setblock 410 190 270 minecraft:jungle_leaves[persistent=true]
fill 381 191 230 381 192 245 minecraft:brown_terracotta
fill 381 191 246 381 193 250 minecraft:brown_concrete
fill 381 191 251 381 192 268 minecraft:brown_terracotta
fill 382 191 230 382 194 242 minecraft:brown_terracotta
fill 382 191 243 382 192 245 minecraft:brown_concrete
fill 382 191 251 382 192 253 minecraft:brown_concrete
fill 382 191 254 382 194 268 minecraft:brown_terracotta
fill 383 191 242 383 193 242 minecraft:brown_concrete
fill 383 191 254 383 193 254 minecraft:brown_concrete
fill 384 191 241 384 192 241 minecraft:brown_concrete
fill 384 191 255 384 192 255 minecraft:brown_concrete
setblock 385 191 240 minecraft:brown_concrete
setblock 385 191 256 minecraft:brown_concrete
fill 386 191 239 386 192 239 minecraft:brown_concrete
fill 386 191 257 386 192 257 minecraft:brown_concrete
fill 387 191 238 387 193 238 minecraft:brown_concrete
setblock 387 191 239 minecraft:light[level=15]
setblock 387 191 247 minecraft:light[level=15]
setblock 387 191 255 minecraft:light[level=15]
fill 387 191 258 387 193 258 minecraft:brown_concrete
fill 388 191 230 388 197 236 minecraft:brown_terracotta
fill 388 191 237 390 192 237 minecraft:brown_concrete
fill 388 191 259 390 192 259 minecraft:brown_concrete
fill 388 191 260 388 197 268 minecraft:brown_terracotta
setblock 388 191 270 minecraft:jungle_leaves[persistent=true]
fill 391 191 230 391 197 235 minecraft:brown_terracotta
fill 391 191 236 395 193 236 minecraft:brown_concrete
fill 391 191 260 395 193 260 minecraft:brown_concrete
fill 391 191 261 391 197 268 minecraft:brown_terracotta
setblock 395 191 239 minecraft:light[level=15]
setblock 395 191 247 minecraft:light[level=15]
setblock 395 191 255 minecraft:light[level=15]
fill 396 191 236 416 192 236 minecraft:brown_terracotta
fill 396 191 237 398 192 237 minecraft:brown_concrete
fill 396 191 259 398 192 259 minecraft:brown_concrete
fill 396 191 260 416 192 260 minecraft:brown_terracotta
fill 399 191 237 416 194 237 minecraft:brown_terracotta
fill 399 191 238 399 193 238 minecraft:brown_concrete
fill 399 191 258 399 193 258 minecraft:brown_concrete
fill 399 191 259 416 194 259 minecraft:brown_terracotta
fill 400 191 239 400 192 239 minecraft:brown_concrete
fill 400 191 257 400 192 257 minecraft:brown_concrete
setblock 401 191 240 minecraft:brown_concrete
setblock 401 191 256 minecraft:brown_concrete
fill 402 191 241 402 192 241 minecraft:brown_concrete
fill 402 191 255 402 192 255 minecraft:brown_concrete
fill 403 191 242 403 193 242 minecraft:brown_concrete
setblock 403 191 247 minecraft:light[level=15]
fill 403 191 254 403 193 254 minecraft:brown_concrete
fill 404 191 243 404 192 245 minecraft:brown_concrete
fill 404 191 251 404 192 253 minecraft:brown_concrete
fill 405 191 243 416 197 243 minecraft:brown_terracotta
fill 405 191 246 405 193 250 minecraft:brown_concrete
fill 405 191 253 416 197 253 minecraft:brown_terracotta
fill 406 191 246 416 197 246 minecraft:brown_terracotta
fill 406 191 250 416 197 250 minecraft:brown_terracotta
fill 410 191 270 410 218 270 minecraft:green_terracotta
setblock 376 192 240 minecraft:mossy_cobblestone
fill 376 192 241 376 212 243 minecraft:green_terracotta
setblock 376 192 269 minecraft:jungle_leaves[persistent=true]
fill 384 192 230 384 196 239 minecraft:brown_terracotta
fill 384 192 240 384 193 240 minecraft:brown_concrete
fill 384 192 256 384 193 256 minecraft:brown_concrete
fill 384 192 257 384 196 268 minecraft:brown_terracotta
fill 385 192 230 385 196 238 minecraft:brown_terracotta
fill 385 192 239 385 193 239 minecraft:brown_concrete
fill 385 192 257 385 193 257 minecraft:brown_concrete
fill 385 192 258 385 196 268 minecraft:brown_terracotta
fill 388 192 270 388 222 270 minecraft:green_terracotta
setblock 391 192 270 minecraft:moss_block
fill 401 192 239 401 193 239 minecraft:brown_concrete
fill 401 192 257 401 193 257 minecraft:brown_concrete
fill 402 192 239 416 196 239 minecraft:brown_terracotta
fill 402 192 240 402 193 240 minecraft:brown_concrete
fill 402 192 256 402 193 256 minecraft:brown_concrete
fill 402 192 257 416 196 257 minecraft:brown_terracotta
fill 403 192 240 416 196 240 minecraft:brown_terracotta
fill 403 192 256 416 196 256 minecraft:brown_terracotta
fill 376 193 240 376 222 240 minecraft:green_terracotta
fill 376 193 269 376 209 269 minecraft:green_terracotta
fill 381 193 230 381 194 244 minecraft:brown_terracotta
setblock 381 193 245 minecraft:brown_concrete
setblock 381 193 251 minecraft:brown_concrete
fill 381 193 252 381 194 268 minecraft:brown_terracotta
fill 382 193 243 382 193 244 minecraft:brown_concrete
fill 382 193 252 382 193 253 minecraft:brown_concrete
fill 383 193 230 383 196 240 minecraft:brown_terracotta
setblock 383 193 241 minecraft:brown_concrete
setblock 383 193 255 minecraft:brown_concrete
fill 383 193 256 383 196 268 minecraft:brown_terracotta
fill 386 193 230 386 197 237 minecraft:brown_terracotta
setblock 386 193 238 minecraft:brown_concrete
setblock 386 193 258 minecraft:brown_concrete
fill 386 193 259 386 197 268 minecraft:brown_terracotta
fill 388 193 237 389 193 237 minecraft:brown_concrete
fill 388 193 259 389 193 259 minecraft:brown_concrete
fill 390 193 230 390 199 235 minecraft:brown_terracotta
setblock 390 193 236 minecraft:brown_concrete
setblock 390 193 260 minecraft:brown_concrete
fill 390 193 261 390 199 268 minecraft:brown_terracotta
fill 391 193 270 391 200 270 minecraft:green_terracotta
setblock 396 193 236 minecraft:brown_concrete
setblock 396 193 260 minecraft:brown_concrete
fill 397 193 236 416 194 236 minecraft:brown_terracotta
fill 397 193 237 398 193 237 minecraft:brown_concrete
fill 397 193 259 398 193 259 minecraft:brown_concrete
fill 397 193 260 416 194 260 minecraft:brown_terracotta
setblock 400 193 238 minecraft:brown_concrete
setblock 400 193 258 minecraft:brown_concrete
fill 401 193 238 416 196 238 minecraft:brown_terracotta
fill 401 193 258 416 196 258 minecraft:brown_terracotta
setblock 403 193 241 minecraft:brown_concrete
setblock 403 193 255 minecraft:brown_concrete
fill 404 193 241 416 197 241 minecraft:brown_terracotta
fill 404 193 243 404 193 244 minecraft:brown_concrete
fill 404 193 252 404 193 253 minecraft:brown_concrete
fill 404 193 255 416 197 255 minecraft:brown_terracotta
setblock 405 193 245 minecraft:brown_concrete
setblock 405 193 251 minecraft:brown_concrete
fill 406 193 245 416 199 245 minecraft:brown_terracotta
fill 406 193 251 416 199 251 minecraft:brown_terracotta
setblock 415 193 270 minecraft:mossy_cobblestone
setblock 379 194 228 minecraft:green_concrete
fill 381 194 245 381 194 251 minecraft:bone_block
fill 382 194 243 382 194 244 minecraft:bone_block
fill 382 194 252 382 194 253 minecraft:bone_block
fill 383 194 241 383 194 242 minecraft:bone_block
fill 383 194 254 383 194 255 minecraft:bone_block
setblock 384 194 240 minecraft:bone_block
setblock 384 194 256 minecraft:bone_block
setblock 385 194 239 minecraft:bone_block
setblock 385 194 257 minecraft:bone_block
fill 386 194 238 387 194 238 minecraft:bone_block
fill 386 194 258 387 194 258 minecraft:bone_block
fill 388 194 237 389 194 237 minecraft:bone_block
fill 388 194 259 389 194 259 minecraft:bone_block
fill 390 194 236 396 194 236 minecraft:bone_block
fill 390 194 260 396 194 260 minecraft:bone_block
fill 397 194 237 398 194 237 minecraft:bone_block
fill 397 194 259 398 194 259 minecraft:bone_block
fill 399 194 238 400 194 238 minecraft:bone_block
fill 399 194 258 400 194 258 minecraft:bone_block
setblock 401 194 239 minecraft:bone_block
setblock 401 194 257 minecraft:bone_block
setblock 402 194 240 minecraft:bone_block
setblock 402 194 256 minecraft:bone_block
fill 403 194 241 403 194 242 minecraft:bone_block
fill 403 194 254 403 194 255 minecraft:bone_block
fill 404 194 243 404 194 244 minecraft:bone_block
fill 404 194 252 404 194 253 minecraft:bone_block
fill 405 194 245 405 194 251 minecraft:bone_block
fill 415 194 270 415 196 270 minecraft:green_terracotta
fill 379 195 228 379 222 228 minecraft:green_terracotta
fill 381 195 230 381 197 243 minecraft:brown_terracotta
fill 381 195 244 381 196 252 minecraft:brown_concrete
fill 381 195 253 381 197 268 minecraft:brown_terracotta
fill 382 195 230 382 197 241 minecraft:brown_terracotta
fill 382 195 242 382 197 243 minecraft:brown_concrete
fill 382 195 253 382 197 254 minecraft:brown_concrete
fill 382 195 255 382 197 268 minecraft:brown_terracotta
fill 383 195 241 383 197 241 minecraft:brown_concrete
fill 383 195 255 383 197 255 minecraft:brown_concrete
fill 384 195 240 384 196 240 minecraft:brown_concrete
fill 384 195 256 384 196 256 minecraft:brown_concrete
fill 385 195 239 385 196 239 minecraft:brown_concrete
fill 385 195 257 385 196 257 minecraft:brown_concrete
fill 386 195 238 386 197 238 minecraft:brown_concrete
setblock 386 195 245 minecraft:light[level=12]
setblock 386 195 252 minecraft:light[level=12]
fill 386 195 258 386 197 258 minecraft:brown_concrete
fill 387 195 230 387 200 236 minecraft:brown_terracotta
fill 387 195 237 388 197 237 minecraft:brown_concrete
fill 387 195 259 388 197 259 minecraft:brown_concrete
fill 387 195 260 387 200 268 minecraft:brown_terracotta
fill 389 195 230 389 201 235 minecraft:brown_terracotta
fill 389 195 236 397 196 236 minecraft:brown_concrete
fill 389 195 260 397 196 260 minecraft:brown_concrete
fill 389 195 261 389 201 268 minecraft:brown_terracotta
setblock 393 195 238 minecraft:light[level=12]
setblock 393 195 245 minecraft:light[level=12]
setblock 393 195 252 minecraft:light[level=12]
setblock 393 195 259 minecraft:light[level=12]
fill 398 195 236 416 197 236 minecraft:brown_terracotta
fill 398 195 237 399 197 237 minecraft:brown_concrete
fill 398 195 259 399 197 259 minecraft:brown_concrete
fill 398 195 260 416 197 260 minecraft:brown_terracotta
fill 400 195 237 416 197 237 minecraft:brown_terracotta
fill 400 195 238 400 197 238 minecraft:brown_concrete
setblock 400 195 245 minecraft:light[level=12]
setblock 400 195 252 minecraft:light[level=12]
fill 400 195 258 400 197 258 minecraft:brown_concrete
fill 400 195 259 416 197 259 minecraft:brown_terracotta
fill 401 195 239 401 196 239 minecraft:brown_concrete
fill 401 195 257 401 196 257 minecraft:brown_concrete
fill 402 195 240 402 196 240 minecraft:brown_concrete
fill 402 195 256 402 196 256 minecraft:brown_concrete
fill 403 195 241 403 197 241 minecraft:brown_concrete
fill 403 195 255 403 197 255 minecraft:brown_concrete
fill 404 195 242 404 197 243 minecraft:brown_concrete
fill 404 195 253 404 197 254 minecraft:brown_concrete
fill 405 195 242 416 200 242 minecraft:brown_terracotta
fill 405 195 244 405 196 252 minecraft:brown_concrete
fill 405 195 254 416 200 254 minecraft:brown_terracotta
fill 406 195 244 416 201 244 minecraft:brown_terracotta
fill 406 195 252 416 201 252 minecraft:brown_terracotta
fill 388 196 228 389 196 228 minecraft:jungle_leaves[persistent=true]
setblock 396 196 228 minecraft:jungle_leaves[persistent=true]
fill 376 197 230 376 198 231 minecraft:jungle_log
setblock 376 197 232 minecraft:green_concrete
fill 376 197 236 376 222 236 minecraft:green_terracotta
setblock 376 197 237 minecraft:jungle_leaves[persistent=true]
fill 376 197 265 376 198 265 minecraft:jungle_log
fill 378 197 230 379 203 268 minecraft:brown_terracotta
fill 379 197 270 380 198 270 minecraft:jungle_log
fill 380 197 230 380 197 246 minecraft:brown_terracotta
fill 380 197 247 380 197 249 minecraft:brown_concrete
fill 380 197 250 380 197 268 minecraft:brown_terracotta
fill 381 197 244 381 197 246 minecraft:brown_concrete
fill 381 197 250 381 197 252 minecraft:brown_concrete
fill 383 197 230 383 201 239 minecraft:brown_terracotta
setblock 383 197 240 minecraft:brown_concrete
setblock 383 197 256 minecraft:brown_concrete
fill 383 197 257 383 201 268 minecraft:brown_terracotta
fill 384 197 230 384 201 238 minecraft:brown_terracotta
setblock 384 197 239 minecraft:brown_concrete
fill 384 197 240 385 198 240 minecraft:oak_leaves[persistent=true]
setblock 384 197 257 minecraft:brown_concrete
fill 384 197 258 384 201 268 minecraft:brown_terracotta
fill 385 197 230 385 202 237 minecraft:brown_terracotta
setblock 385 197 238 minecraft:brown_concrete
fill 385 197 239 385 199 239 minecraft:oak_leaves[persistent=true]
setblock 385 197 258 minecraft:brown_concrete
fill 385 197 259 385 202 268 minecraft:brown_terracotta
fill 388 197 228 389 222 228 minecraft:green_terracotta
fill 389 197 236 391 197 236 minecraft:brown_concrete
fill 389 197 260 391 197 260 minecraft:brown_concrete
fill 392 197 230 416 203 234 minecraft:brown_terracotta
fill 392 197 235 394 197 235 minecraft:brown_concrete
fill 392 197 261 394 197 261 minecraft:brown_concrete
fill 392 197 262 416 203 268 minecraft:brown_terracotta
fill 395 197 235 416 197 235 minecraft:brown_terracotta
fill 395 197 236 397 197 236 minecraft:brown_concrete
fill 395 197 260 397 197 260 minecraft:brown_concrete
fill 395 197 261 416 197 261 minecraft:brown_terracotta
fill 396 197 228 396 219 228 minecraft:green_terracotta
setblock 401 197 238 minecraft:brown_concrete
setblock 401 197 258 minecraft:brown_concrete
fill 402 197 238 416 201 238 minecraft:brown_terracotta
setblock 402 197 239 minecraft:brown_concrete
setblock 402 197 257 minecraft:brown_concrete
fill 402 197 258 416 201 258 minecraft:brown_terracotta
fill 403 197 239 416 201 239 minecraft:brown_terracotta
setblock 403 197 240 minecraft:brown_concrete
setblock 403 197 256 minecraft:brown_concrete
fill 403 197 257 416 201 257 minecraft:brown_terracotta
fill 404 197 240 416 202 240 minecraft:brown_terracotta
fill 404 197 256 416 202 256 minecraft:brown_terracotta
setblock 404 197 270 minecraft:mossy_cobblestone
fill 405 197 244 405 197 246 minecraft:brown_concrete
fill 405 197 250 405 197 252 minecraft:brown_concrete
fill 406 197 247 406 197 249 minecraft:brown_concrete
fill 407 197 228 409 199 228 minecraft:oak_leaves[persistent=true]
fill 407 197 247 416 203 249 minecraft:brown_terracotta
fill 410 197 228 410 210 228 minecraft:green_terracotta
fill 415 197 270 416 198 270 minecraft:jungle_log
fill 418 197 228 418 199 229 minecraft:jungle_leaves[persistent=true]
fill 418 197 230 418 198 230 minecraft:oak_leaves[persistent=true]
fill 418 197 231 418 198 231 minecraft:jungle_log
fill 418 197 262 418 199 263 minecraft:jungle_leaves[persistent=true]
setblock 418 197 264 minecraft:jungle_log
fill 376 198 232 376 222 232 minecraft:green_terracotta
fill 376 198 237 376 222 237 minecraft:green_terracotta
setblock 378 198 270 minecraft:jungle_leaves[persistent=true]
fill 380 198 230 380 199 245 minecraft:brown_terracotta
fill 380 198 246 380 198 250 minecraft:bone_block
fill 380 198 251 380 199 268 minecraft:brown_terracotta
fill 381 198 230 381 200 242 minecraft:brown_terracotta
fill 381 198 243 381 198 245 minecraft:bone_block
fill 381 198 251 381 198 253 minecraft:bone_block
fill 381 198 254 381 200 268 minecraft:brown_terracotta
fill 382 198 230 382 202 240 minecraft:brown_terracotta
fill 382 198 241 382 198 242 minecraft:bone_block
fill 382 198 254 382 198 255 minecraft:bone_block
fill 382 198 256 382 202 268 minecraft:brown_terracotta
setblock 383 198 240 minecraft:bone_block
fill 383 198 241 383 199 241 minecraft:oak_leaves[persistent=true]
setblock 383 198 256 minecraft:bone_block
setblock 384 198 239 minecraft:bone_block
setblock 384 198 257 minecraft:bone_block
setblock 385 198 238 minecraft:bone_block
setblock 385 198 258 minecraft:bone_block
fill 386 198 230 386 203 236 minecraft:brown_terracotta
fill 386 198 237 387 198 237 minecraft:bone_block
fill 386 198 238 386 198 239 minecraft:oak_leaves[persistent=true]
fill 386 198 259 387 198 259 minecraft:bone_block
fill 386 198 260 386 203 268 minecraft:brown_terracotta
setblock 387 198 239 minecraft:light[level=15]
setblock 387 198 247 minecraft:light[level=15]
setblock 387 198 255 minecraft:light[level=15]
fill 388 198 230 388 203 235 minecraft:brown_terracotta
fill 388 198 236 390 198 236 minecraft:bone_block
fill 388 198 260 390 198 260 minecraft:bone_block
fill 388 198 261 388 203 268 minecraft:brown_terracotta
fill 391 198 230 391 204 234 minecraft:brown_terracotta
fill 391 198 235 395 198 235 minecraft:bone_block
fill 391 198 261 395 198 261 minecraft:bone_block
fill 391 198 262 391 204 268 minecraft:brown_terracotta
setblock 395 198 239 minecraft:light[level=15]
setblock 395 198 247 minecraft:light[level=15]
setblock 395 198 255 minecraft:light[level=15]
fill 396 198 235 416 199 235 minecraft:brown_terracotta
fill 396 198 236 398 198 236 minecraft:bone_block
fill 396 198 260 398 198 260 minecraft:bone_block
fill 396 198 261 416 199 261 minecraft:brown_terracotta
fill 399 198 236 416 200 236 minecraft:brown_terracotta
fill 399 198 237 400 198 237 minecraft:bone_block
fill 399 198 259 400 198 259 minecraft:bone_block
fill 399 198 260 416 200 260 minecraft:brown_terracotta
fill 401 198 237 416 202 237 minecraft:brown_terracotta
setblock 401 198 238 minecraft:bone_block
setblock 401 198 258 minecraft:bone_block
fill 401 198 259 416 202 259 minecraft:brown_terracotta
setblock 402 198 239 minecraft:bone_block
setblock 402 198 257 minecraft:bone_block
setblock 403 198 240 minecraft:bone_block
setblock 403 198 247 minecraft:light[level=15]
setblock 403 198 255 minecraft:light[level=15]
setblock 403 198 256 minecraft:bone_block
setblock 404 198 228 minecraft:moss_block
fill 404 198 241 404 198 242 minecraft:bone_block
fill 404 198 254 404 198 255 minecraft:bone_block
fill 404 198 270 404 222 270 minecraft:green_terracotta
fill 405 198 241 416 203 241 minecraft:brown_terracotta
fill 405 198 243 405 198 245 minecraft:bone_block
fill 405 198 251 405 198 253 minecraft:bone_block
fill 405 198 255 416 203 255 minecraft:brown_terracotta
fill 406 198 228 406 200 228 minecraft:oak_leaves[persistent=true]
fill 406 198 243 416 203 243 minecraft:brown_terracotta
fill 406 198 246 406 198 250 minecraft:bone_block
fill 406 198 253 416 203 253 minecraft:brown_terracotta
fill 407 198 246 416 204 246 minecraft:brown_terracotta
fill 407 198 250 416 204 250 minecraft:brown_terracotta
fill 417 198 228 417 200 228 minecraft:jungle_leaves[persistent=true]
setblock 418 198 264 minecraft:jungle_leaves[persistent=true]
fill 376 199 229 376 199 230 minecraft:oak_leaves[persistent=true]
fill 376 199 231 376 222 231 minecraft:green_terracotta
fill 376 199 265 376 218 265 minecraft:green_terracotta
setblock 378 199 228 minecraft:mossy_cobblestone
fill 378 199 270 380 203 270 minecraft:green_terracotta
fill 380 199 246 380 201 250 minecraft:brown_concrete
fill 381 199 243 381 199 245 minecraft:brown_concrete
fill 381 199 251 381 199 253 minecraft:brown_concrete
fill 382 199 241 382 200 242 minecraft:brown_concrete
fill 382 199 254 382 200 255 minecraft:brown_concrete
fill 383 199 240 383 201 240 minecraft:brown_concrete
fill 383 199 256 383 201 256 minecraft:brown_concrete
setblock 383 199 270 minecraft:mossy_cobblestone
fill 384 199 239 384 201 239 minecraft:brown_concrete
setblock 384 199 240 minecraft:oak_leaves[persistent=true]
fill 384 199 257 384 201 257 minecraft:brown_concrete
fill 385 199 238 385 201 238 minecraft:brown_concrete
fill 385 199 258 385 201 258 minecraft:brown_concrete
fill 386 199 237 387 200 237 minecraft:brown_concrete
fill 386 199 238 386 200 238 minecraft:oak_leaves[persistent=true]
fill 386 199 259 387 200 259 minecraft:brown_concrete
fill 388 199 236 390 199 236 minecraft:brown_concrete
fill 388 199 260 390 199 260 minecraft:brown_concrete
fill 391 199 235 395 201 235 minecraft:brown_concrete
fill 391 199 261 395 201 261 minecraft:brown_concrete
fill 396 199 236 398 199 236 minecraft:brown_concrete
fill 396 199 260 398 199 260 minecraft:brown_concrete
fill 399 199 237 400 200 237 minecraft:brown_concrete
fill 399 199 259 400 200 259 minecraft:brown_concrete
fill 401 199 238 401 201 238 minecraft:brown_concrete
fill 401 199 258 401 201 258 minecraft:brown_concrete
fill 402 199 239 402 201 239 minecraft:brown_concrete
fill 402 199 257 402 201 257 minecraft:brown_concrete
fill 403 199 240 403 201 240 minecraft:brown_concrete
fill 403 199 256 403 201 256 minecraft:brown_concrete
fill 404 199 228 404 219 228 minecraft:green_terracotta
fill 404 199 241 404 200 242 minecraft:brown_concrete
fill 404 199 254 404 200 255 minecraft:brown_concrete
setblock 405 199 228 minecraft:oak_leaves[persistent=true]
fill 405 199 243 405 199 245 minecraft:brown_concrete
fill 405 199 251 405 199 253 minecraft:brown_concrete
fill 406 199 246 406 201 250 minecraft:brown_concrete
fill 415 199 270 416 218 270 minecraft:green_terracotta
fill 418 199 230 418 209 231 minecraft:green_terracotta
fill 418 199 264 418 221 264 minecraft:green_terracotta
setblock 376 200 229 minecraft:oak_leaves[persistent=true]
fill 376 200 230 376 222 230 minecraft:green_terracotta
fill 378 200 228 378 219 228 minecraft:green_terracotta
fill 380 200 230 380 201 244 minecraft:brown_terracotta
fill 380 200 245 380 201 245 minecraft:brown_concrete
fill 380 200 251 380 201 251 minecraft:brown_concrete
fill 380 200 252 380 201 268 minecraft:brown_terracotta
fill 381 200 243 381 201 244 minecraft:brown_concrete
fill 381 200 252 381 201 253 minecraft:brown_concrete
fill 383 200 270 383 218 270 minecraft:green_terracotta
fill 388 200 236 389 201 236 minecraft:brown_concrete
fill 388 200 260 389 201 260 minecraft:brown_concrete
fill 390 200 230 390 205 234 minecraft:brown_terracotta
fill 390 200 235 390 201 235 minecraft:brown_concrete
fill 390 200 261 390 201 261 minecraft:brown_concrete
fill 390 200 262 390 205 268 minecraft:brown_terracotta
fill 396 200 235 396 201 235 minecraft:brown_concrete
fill 396 200 261 396 201 261 minecraft:brown_concrete
fill 397 200 235 416 201 235 minecraft:brown_terracotta
fill 397 200 236 398 201 236 minecraft:brown_concrete
fill 397 200 260 398 201 260 minecraft:brown_concrete
fill 397 200 261 416 201 261 minecraft:brown_terracotta
fill 405 200 228 405 222 228 minecraft:green_terracotta
fill 405 200 243 405 201 244 minecraft:brown_concrete
fill 405 200 252 405 201 253 minecraft:brown_concrete
fill 406 200 245 406 201 245 minecraft:brown_concrete
fill 406 200 251 406 201 251 minecraft:brown_concrete
setblock 407 200 228 minecraft:oak_leaves[persistent=true]
fill 407 200 245 416 205 245 minecraft:brown_terracotta
fill 407 200 251 416 205 251 minecraft:brown_terracotta
fill 408 200 228 409 201 228 minecraft:green_terracotta
setblock 418 200 228 minecraft:jungle_leaves[persistent=true]
fill 418 200 229 418 211 229 minecraft:green_terracotta
fill 418 200 262 418 219 263 minecraft:green_terracotta
fill 376 201 229 376 222 229 minecraft:green_terracotta
fill 376 201 251 376 204 251 minecraft:green_terracotta
setblock 376 201 252 minecraft:green_concrete
fill 381 201 230 381 203 241 minecraft:brown_terracotta
setblock 381 201 242 minecraft:brown_concrete
setblock 381 201 254 minecraft:brown_concrete
fill 381 201 255 381 203 268 minecraft:brown_terracotta
setblock 382 201 241 minecraft:brown_concrete
setblock 382 201 255 minecraft:brown_concrete
setblock 386 201 237 minecraft:brown_concrete
setblock 386 201 238 minecraft:light[level=12]
setblock 386 201 245 minecraft:light[level=12]
setblock 386 201 252 minecraft:light[level=12]
setblock 386 201 259 minecraft:brown_concrete
fill 387 201 230 387 206 235 minecraft:brown_terracotta
setblock 387 201 236 minecraft:brown_concrete
setblock 387 201 260 minecraft:brown_concrete
fill 387 201 261 387 206 268 minecraft:brown_terracotta
setblock 391 201 270 minecraft:mossy_cobblestone
setblock 393 201 238 minecraft:light[level=12]
setblock 393 201 245 minecraft:light[level=12]
setblock 393 201 252 minecraft:light[level=12]
setblock 393 201 259 minecraft:light[level=12]
setblock 399 201 236 minecraft:brown_concrete
setblock 399 201 260 minecraft:brown_concrete
fill 400 201 236 416 203 236 minecraft:brown_terracotta
setblock 400 201 237 minecraft:brown_concrete
setblock 400 201 238 minecraft:light[level=12]
setblock 400 201 245 minecraft:light[level=12]
setblock 400 201 252 minecraft:light[level=12]
setblock 400 201 259 minecraft:brown_concrete
fill 400 201 260 416 203 260 minecraft:brown_terracotta
setblock 404 201 241 minecraft:brown_concrete
setblock 404 201 255 minecraft:brown_concrete
setblock 405 201 242 minecraft:brown_concrete
setblock 405 201 254 minecraft:brown_concrete
fill 406 201 228 407 201 228 minecraft:green_terracotta
fill 406 201 242 416 206 242 minecraft:brown_terracotta
fill 406 201 254 416 206 254 minecraft:brown_terracotta
fill 417 201 228 418 211 228 minecraft:green_terracotta
setblock 376 202 239 minecraft:jungle_leaves[persistent=true]
fill 376 202 252 376 222 252 minecraft:green_terracotta
fill 380 202 230 380 203 243 minecraft:brown_terracotta
fill 380 202 244 380 202 252 minecraft:bone_block
fill 380 202 253 380 203 268 minecraft:brown_terracotta
fill 381 202 242 381 202 243 minecraft:bone_block
fill 381 202 253 381 202 254 minecraft:bone_block
setblock 382 202 241 minecraft:bone_block
setblock 382 202 255 minecraft:bone_block
fill 383 202 230 383 206 238 minecraft:brown_terracotta
fill 383 202 239 383 202 240 minecraft:bone_block
fill 383 202 256 383 202 257 minecraft:bone_block
fill 383 202 258 383 206 268 minecraft:brown_terracotta
fill 384 202 230 384 206 237 minecraft:brown_terracotta
fill 384 202 238 385 202 238 minecraft:bone_block
fill 384 202 258 385 202 258 minecraft:bone_block
fill 384 202 259 384 206 268 minecraft:brown_terracotta
setblock 386 202 237 minecraft:bone_block
setblock 386 202 259 minecraft:bone_block
fill 387 202 236 388 202 236 minecraft:bone_block
fill 387 202 260 388 202 260 minecraft:bone_block
fill 389 202 230 389 207 234 minecraft:brown_terracotta
fill 389 202 235 397 202 235 minecraft:bone_block
fill 389 202 261 397 202 261 minecraft:bone_block
fill 389 202 262 389 207 268 minecraft:brown_terracotta
fill 391 202 270 391 218 270 minecraft:green_terracotta
fill 398 202 235 416 203 235 minecraft:brown_terracotta
fill 398 202 236 399 202 236 minecraft:bone_block
fill 398 202 260 399 202 260 minecraft:bone_block
fill 398 202 261 416 203 261 minecraft:brown_terracotta
setblock 400 202 237 minecraft:bone_block
setblock 400 202 259 minecraft:bone_block
fill 401 202 238 402 202 238 minecraft:bone_block
fill 401 202 258 402 202 258 minecraft:bone_block
fill 403 202 238 416 206 238 minecraft:brown_terracotta
fill 403 202 239 403 202 240 minecraft:bone_block
fill 403 202 256 403 202 257 minecraft:bone_block
fill 403 202 258 416 206 258 minecraft:brown_terracotta
fill 404 202 239 416 206 239 minecraft:brown_terracotta
setblock 404 202 241 minecraft:bone_block
setblock 404 202 255 minecraft:bone_block
fill 404 202 257 416 206 257 minecraft:brown_terracotta
fill 405 202 242 405 202 243 minecraft:bone_block
fill 405 202 253 405 202 254 minecraft:bone_block
setblock 406 202 228 minecraft:moss_block
fill 406 202 244 406 202 252 minecraft:bone_block
fill 407 202 228 408 208 228 minecraft:green_terracotta
fill 407 202 244 416 207 244 minecraft:brown_terracotta
fill 407 202 252 416 207 252 minecraft:brown_terracotta
setblock 409 202 228 minecraft:jungle_leaves[persistent=true]
fill 376 203 239 376 218 239 minecraft:green_terracotta
fill 376 203 270 376 210 270 minecraft:green_terracotta
setblock 377 203 270 minecraft:mossy_cobblestone
setblock 380 203 228 minecraft:moss_block
fill 380 203 244 380 203 252 minecraft:brown_concrete
fill 381 203 242 381 203 243 minecraft:brown_concrete
fill 381 203 253 381 203 254 minecraft:brown_concrete
fill 382 203 230 382 206 239 minecraft:brown_terracotta
fill 382 203 240 382 203 241 minecraft:brown_concrete
fill 382 203 255 382 203 256 minecraft:brown_concrete
fill 382 203 257 382 206 268 minecraft:brown_terracotta
fill 383 203 239 383 205 239 minecraft:brown_concrete
fill 383 203 257 383 205 257 minecraft:brown_concrete
fill 384 203 238 384 205 238 minecraft:brown_concrete
fill 384 203 258 384 205 258 minecraft:brown_concrete
fill 385 203 230 385 207 236 minecraft:brown_terracotta
fill 385 203 237 386 203 237 minecraft:brown_concrete
fill 385 203 259 386 203 259 minecraft:brown_concrete
fill 385 203 260 385 207 268 minecraft:brown_terracotta
fill 387 203 236 388 203 236 minecraft:brown_concrete
fill 387 203 260 388 203 260 minecraft:brown_concrete
fill 389 203 235 397 203 235 minecraft:brown_concrete
fill 389 203 261 397 203 261 minecraft:brown_concrete
fill 398 203 236 399 203 236 minecraft:brown_concrete
fill 398 203 260 399 203 260 minecraft:brown_concrete
fill 400 203 237 401 203 237 minecraft:brown_concrete
fill 400 203 259 401 203 259 minecraft:brown_concrete
fill 402 203 237 416 206 237 minecraft:brown_terracotta
fill 402 203 238 402 205 238 minecraft:brown_concrete
fill 402 203 258 402 205 258 minecraft:brown_concrete
fill 402 203 259 416 206 259 minecraft:brown_terracotta
fill 403 203 239 403 205 239 minecraft:brown_concrete
fill 403 203 257 403 205 257 minecraft:brown_concrete
fill 404 203 240 404 203 241 minecraft:brown_concrete
fill 404 203 255 404 203 256 minecraft:brown_concrete
fill 405 203 240 416 207 240 minecraft:brown_terracotta
fill 405 203 242 405 203 243 minecraft:brown_concrete
fill 405 203 253 405 203 254 minecraft:brown_concrete
fill 405 203 256 416 207 256 minecraft:brown_terracotta
fill 406 203 228 406 210 228 minecraft:green_terracotta
fill 406 203 244 406 203 252 minecraft:brown_concrete
fill 409 203 228 409 209 228 minecraft:green_terracotta
setblock 413 203 270 minecraft:mossy_cobblestone
setblock 376 204 248 minecraft:jungle_leaves[persistent=true]
setblock 376 204 267 minecraft:mossy_cobblestone
fill 377 204 270 378 219 270 minecraft:green_terracotta
fill 378 204 230 378 210 268 minecraft:brown_terracotta
fill 379 204 230 379 204 246 minecraft:brown_terracotta
fill 379 204 247 379 205 249 minecraft:brown_concrete
fill 379 204 250 379 204 268 minecraft:brown_terracotta
setblock 379 204 270 minecraft:green_concrete
fill 380 204 228 380 222 228 minecraft:green_terracotta
fill 380 204 230 380 206 242 minecraft:brown_terracotta
fill 380 204 243 380 204 246 minecraft:brown_concrete
fill 380 204 250 380 204 253 minecraft:brown_concrete
fill 380 204 254 380 206 268 minecraft:brown_terracotta
fill 380 204 270 380 218 270 minecraft:green_terracotta
fill 381 204 230 381 207 240 minecraft:brown_terracotta
fill 381 204 241 381 205 242 minecraft:brown_concrete
fill 381 204 254 381 205 255 minecraft:brown_concrete
fill 381 204 256 381 207 268 minecraft:brown_terracotta
fill 382 204 240 382 205 240 minecraft:brown_concrete
fill 382 204 256 382 205 256 minecraft:brown_concrete
fill 385 204 237 385 205 237 minecraft:brown_concrete
fill 385 204 259 385 205 259 minecraft:brown_concrete
fill 386 204 230 386 209 235 minecraft:brown_terracotta
fill 386 204 236 387 205 236 minecraft:brown_concrete
fill 386 204 260 387 205 260 minecraft:brown_concrete
fill 386 204 261 386 209 268 minecraft:brown_terracotta
fill 388 204 230 388 210 234 minecraft:brown_terracotta
fill 388 204 235 391 204 235 minecraft:brown_concrete
fill 388 204 261 391 204 261 minecraft:brown_concrete
fill 388 204 262 388 210 268 minecraft:brown_terracotta
fill 392 204 230 416 210 233 minecraft:brown_terracotta
fill 392 204 234 394 205 234 minecraft:brown_concrete
fill 392 204 262 394 205 262 minecraft:brown_concrete
fill 392 204 263 416 210 268 minecraft:brown_terracotta
fill 395 204 234 416 204 234 minecraft:brown_terracotta
fill 395 204 235 398 204 235 minecraft:brown_concrete
fill 395 204 261 398 204 261 minecraft:brown_concrete
fill 395 204 262 416 204 262 minecraft:brown_terracotta
fill 399 204 235 416 206 235 minecraft:brown_terracotta
fill 399 204 236 400 205 236 minecraft:brown_concrete
fill 399 204 260 400 205 260 minecraft:brown_concrete
fill 399 204 261 416 206 261 minecraft:brown_terracotta
fill 401 204 236 416 207 236 minecraft:brown_terracotta
fill 401 204 237 401 205 237 minecraft:brown_concrete
fill 401 204 259 401 205 259 minecraft:brown_concrete
fill 401 204 260 416 207 260 minecraft:brown_terracotta
fill 404 204 240 404 205 240 minecraft:brown_concrete
fill 404 204 256 404 205 256 minecraft:brown_concrete
fill 405 204 241 405 205 242 minecraft:brown_concrete
fill 405 204 254 405 205 255 minecraft:brown_concrete
fill 406 204 241 416 209 241 minecraft:brown_terracotta
fill 406 204 243 406 204 246 minecraft:brown_concrete
fill 406 204 250 406 204 253 minecraft:brown_concrete
fill 406 204 255 416 209 255 minecraft:brown_terracotta
fill 407 204 243 416 210 243 minecraft:brown_terracotta
fill 407 204 247 407 205 249 minecraft:brown_concrete
fill 407 204 253 416 210 253 minecraft:brown_terracotta
fill 408 204 247 416 210 249 minecraft:brown_terracotta
fill 413 204 270 413 218 270 minecraft:green_terracotta
setblock 418 204 265 minecraft:mossy_cobblestone
fill 376 205 248 376 222 248 minecraft:green_terracotta
setblock 376 205 251 minecraft:moss_block
fill 376 205 267 376 220 267 minecraft:green_terracotta
fill 379 205 230 379 205 245 minecraft:brown_terracotta
setblock 379 205 246 minecraft:brown_concrete
setblock 379 205 250 minecraft:brown_concrete
fill 379 205 251 379 205 268 minecraft:brown_terracotta
fill 379 205 270 379 222 270 minecraft:green_terracotta
fill 380 205 243 380 205 245 minecraft:brown_concrete
fill 380 205 251 380 205 253 minecraft:brown_concrete
setblock 387 205 239 minecraft:light[level=15]
setblock 387 205 247 minecraft:light[level=15]
setblock 387 205 255 minecraft:light[level=15]
fill 388 205 235 390 205 235 minecraft:brown_concrete
fill 388 205 261 390 205 261 minecraft:brown_concrete
fill 391 205 230 391 211 233 minecraft:brown_terracotta
setblock 391 205 234 minecraft:brown_concrete
setblock 391 205 262 minecraft:brown_concrete
fill 391 205 263 391 211 268 minecraft:brown_terracotta
setblock 395 205 234 minecraft:brown_concrete
setblock 395 205 239 minecraft:light[level=15]
setblock 395 205 247 minecraft:light[level=15]
setblock 395 205 255 minecraft:light[level=15]
setblock 395 205 262 minecraft:brown_concrete
fill 396 205 234 416 205 234 minecraft:brown_terracotta
fill 396 205 235 398 205 235 minecraft:brown_concrete
fill 396 205 261 398 205 261 minecraft:brown_concrete
fill 396 205 262 416 205 262 minecraft:brown_terracotta
setblock 403 205 247 minecraft:light[level=15]
setblock 403 205 255 minecraft:light[level=15]
fill 406 205 243 406 205 245 minecraft:brown_concrete
fill 406 205 251 406 205 253 minecraft:brown_concrete
setblock 407 205 246 minecraft:brown_concrete
setblock 407 205 250 minecraft:brown_concrete
fill 408 205 246 416 211 246 minecraft:brown_terracotta
fill 408 205 250 416 211 250 minecraft:brown_terracotta
fill 418 205 265 418 207 265 minecraft:green_terracotta
fill 376 206 251 376 210 251 minecraft:green_terracotta
fill 379 206 230 379 207 244 minecraft:brown_terracotta
fill 379 206 245 379 206 251 minecraft:bone_block
fill 379 206 252 379 207 268 minecraft:brown_terracotta
fill 380 206 243 380 206 244 minecraft:bone_block
fill 380 206 252 380 206 253 minecraft:bone_block
fill 381 206 241 381 206 242 minecraft:bone_block
fill 381 206 254 381 206 255 minecraft:bone_block
setblock 382 206 240 minecraft:bone_block
setblock 382 206 256 minecraft:bone_block
setblock 383 206 239 minecraft:bone_block
setblock 383 206 257 minecraft:bone_block
setblock 384 206 238 minecraft:bone_block
setblock 384 206 258 minecraft:bone_block
setblock 385 206 237 minecraft:bone_block
setblock 385 206 259 minecraft:bone_block
fill 386 206 236 387 206 236 minecraft:bone_block
fill 386 206 260 387 206 260 minecraft:bone_block
fill 388 206 235 389 206 235 minecraft:bone_block
fill 388 206 261 389 206 261 minecraft:bone_block
fill 390 206 230 390 212 233 minecraft:brown_terracotta
fill 390 206 234 396 206 234 minecraft:bone_block
fill 390 206 262 396 206 262 minecraft:bone_block
fill 390 206 263 390 212 268 minecraft:brown_terracotta
fill 397 206 234 416 207 234 minecraft:brown_terracotta
fill 397 206 235 398 206 235 minecraft:bone_block
fill 397 206 261 398 206 261 minecraft:bone_block
fill 397 206 262 416 207 262 minecraft:brown_terracotta
fill 399 206 236 400 206 236 minecraft:bone_block
fill 399 206 260 400 206 260 minecraft:bone_block
setblock 401 206 237 minecraft:bone_block
setblock 401 206 259 minecraft:bone_block
setblock 402 206 238 minecraft:bone_block
setblock 402 206 258 minecraft:bone_block
setblock 403 206 239 minecraft:bone_block
setblock 403 206 257 minecraft:bone_block
setblock 404 206 240 minecraft:bone_block
setblock 404 206 256 minecraft:bone_block
fill 405 206 241 405 206 242 minecraft:bone_block
fill 405 206 254 405 206 255 minecraft:bone_block
fill 406 206 243 406 206 244 minecraft:bone_block
fill 406 206 252 406 206 253 minecraft:bone_block
fill 407 206 245 407 206 251 minecraft:bone_block
fill 408 206 245 416 212 245 minecraft:brown_terracotta
fill 408 206 251 416 212 251 minecraft:brown_terracotta
setblock 418 206 238 minecraft:green_concrete
fill 379 207 245 379 209 251 minecraft:brown_concrete
fill 380 207 230 380 209 241 minecraft:brown_terracotta
fill 380 207 242 380 207 244 minecraft:brown_concrete
fill 380 207 252 380 207 254 minecraft:brown_concrete
fill 380 207 255 380 209 268 minecraft:brown_terracotta
fill 381 207 241 381 209 241 minecraft:brown_concrete
fill 381 207 255 381 209 255 minecraft:brown_concrete
fill 382 207 230 382 211 238 minecraft:brown_terracotta
fill 382 207 239 382 207 240 minecraft:brown_concrete
fill 382 207 256 382 207 257 minecraft:brown_concrete
fill 382 207 258 382 211 268 minecraft:brown_terracotta
fill 383 207 230 383 211 237 minecraft:brown_terracotta
fill 383 207 238 383 209 238 minecraft:brown_concrete
fill 383 207 258 383 209 258 minecraft:brown_concrete
fill 383 207 259 383 211 268 minecraft:brown_terracotta
fill 384 207 230 384 211 236 minecraft:brown_terracotta
fill 384 207 237 385 207 237 minecraft:brown_concrete
fill 384 207 259 385 207 259 minecraft:brown_concrete
fill 384 207 260 384 211 268 minecraft:brown_terracotta
fill 386 207 236 386 209 236 minecraft:brown_concrete
setblock 386 207 238 minecraft:light[level=12]
setblock 386 207 245 minecraft:light[level=12]
setblock 386 207 252 minecraft:light[level=12]
setblock 386 207 259 minecraft:light[level=12]
fill 386 207 260 386 209 260 minecraft:brown_concrete
fill 387 207 230 387 212 234 minecraft:brown_terracotta
fill 387 207 235 389 207 235 minecraft:brown_concrete
fill 387 207 261 389 207 261 minecraft:brown_concrete
fill 387 207 262 387 212 268 minecraft:brown_terracotta
fill 390 207 234 396 209 234 minecraft:brown_concrete
fill 390 207 262 396 209 262 minecraft:brown_concrete
setblock 393 207 238 minecraft:light[level=12]
setblock 393 207 245 minecraft:light[level=12]
setblock 393 207 252 minecraft:light[level=12]
setblock 393 207 259 minecraft:light[level=12]
fill 397 207 235 399 207 235 minecraft:brown_concrete
fill 397 207 261 399 207 261 minecraft:brown_concrete
fill 400 207 235 416 209 235 minecraft:brown_terracotta
fill 400 207 236 400 209 236 minecraft:brown_concrete
setblock 400 207 238 minecraft:light[level=12]
setblock 400 207 245 minecraft:light[level=12]
setblock 400 207 252 minecraft:light[level=12]
setblock 400 207 259 minecraft:light[level=12]
fill 400 207 260 400 209 260 minecraft:brown_concrete
fill 400 207 261 416 209 261 minecraft:brown_terracotta
fill 401 207 237 402 207 237 minecraft:brown_concrete
fill 401 207 259 402 207 259 minecraft:brown_concrete
fill 403 207 237 416 211 237 minecraft:brown_terracotta
fill 403 207 238 403 209 238 minecraft:brown_concrete
fill 403 207 258 403 209 258 minecraft:brown_concrete
fill 403 207 259 416 211 259 minecraft:brown_terracotta
fill 404 207 238 416 211 238 minecraft:brown_terracotta
fill 404 207 239 404 207 240 minecraft:brown_concrete
fill 404 207 256 404 207 257 minecraft:brown_concrete
fill 404 207 258 416 211 258 minecraft:brown_terracotta
fill 405 207 239 416 211 239 minecraft:brown_terracotta
fill 405 207 241 405 209 241 minecraft:brown_concrete
fill 405 207 255 405 209 255 minecraft:brown_concrete
fill 405 207 257 416 211 257 minecraft:brown_terracotta
fill 406 207 242 406 207 244 minecraft:brown_concrete
fill 406 207 252 406 207 254 minecraft:brown_concrete
fill 407 207 242 416 212 242 minecraft:brown_terracotta
fill 407 207 245 407 209 251 minecraft:brown_concrete
fill 407 207 254 416 212 254 minecraft:brown_terracotta
fill 418 207 238 418 221 238 minecraft:green_terracotta
fill 379 208 230 379 210 243 minecraft:brown_terracotta
fill 379 208 244 379 209 244 minecraft:brown_concrete
fill 379 208 252 379 209 252 minecraft:brown_concrete
fill 379 208 253 379 210 268 minecraft:brown_terracotta
fill 380 208 242 380 209 243 minecraft:brown_concrete
fill 380 208 253 380 209 254 minecraft:brown_concrete
fill 381 208 230 381 211 239 minecraft:brown_terracotta
fill 381 208 240 381 209 240 minecraft:brown_concrete
fill 381 208 256 381 209 256 minecraft:brown_concrete
fill 381 208 257 381 211 268 minecraft:brown_terracotta
fill 382 208 239 382 209 239 minecraft:brown_concrete
fill 382 208 257 382 209 257 minecraft:brown_concrete
fill 384 208 237 384 209 237 minecraft:brown_concrete
fill 384 208 259 384 209 259 minecraft:brown_concrete
fill 385 208 230 385 213 235 minecraft:brown_terracotta
fill 385 208 236 385 209 236 minecraft:brown_concrete
fill 385 208 260 385 209 260 minecraft:brown_concrete
fill 385 208 261 385 213 268 minecraft:brown_terracotta
setblock 386 208 228 minecraft:mossy_cobblestone
fill 387 208 235 388 209 235 minecraft:brown_concrete
fill 387 208 261 388 209 261 minecraft:brown_concrete
fill 389 208 230 389 214 233 minecraft:brown_terracotta
fill 389 208 234 389 209 234 minecraft:brown_concrete
fill 389 208 262 389 209 262 minecraft:brown_concrete
fill 389 208 263 389 214 268 minecraft:brown_terracotta
fill 397 208 234 397 209 234 minecraft:brown_concrete
fill 397 208 262 397 209 262 minecraft:brown_concrete
fill 398 208 234 416 210 234 minecraft:brown_terracotta
fill 398 208 235 399 209 235 minecraft:brown_concrete
fill 398 208 261 399 209 261 minecraft:brown_concrete
fill 398 208 262 416 210 262 minecraft:brown_terracotta
fill 401 208 236 401 209 236 minecraft:brown_concrete
fill 401 208 260 401 209 260 minecraft:brown_concrete
fill 402 208 236 416 211 236 minecraft:brown_terracotta
fill 402 208 237 402 209 237 minecraft:brown_concrete
fill 402 208 259 402 209 259 minecraft:brown_concrete
fill 402 208 260 416 211 260 minecraft:brown_terracotta
fill 404 208 239 404 209 239 minecraft:brown_concrete
fill 404 208 257 404 209 257 minecraft:brown_concrete
fill 405 208 240 405 209 240 minecraft:brown_concrete
fill 405 208 256 405 209 256 minecraft:brown_concrete
fill 406 208 240 416 213 240 minecraft:brown_terracotta
fill 406 208 242 406 209 243 minecraft:brown_concrete
fill 406 208 253 406 209 254 minecraft:brown_concrete
fill 406 208 256 416 213 256 minecraft:brown_terracotta
fill 407 208 244 407 209 244 minecraft:brown_concrete
fill 407 208 252 407 209 252 minecraft:brown_concrete
fill 408 208 244 416 214 244 minecraft:brown_terracotta
fill 408 208 252 416 214 252 minecraft:brown_terracotta
setblock 418 208 265 minecraft:mossy_cobblestone
setblock 418 208 269 minecraft:mossy_cobblestone
fill 418 208 270 418 222 270 minecraft:green_terracotta
fill 382 209 240 382 213 240 minecraft:jungle_leaves[persistent=true]
fill 386 209 228 386 218 228 minecraft:green_terracotta
setblock 401 209 228 minecraft:green_concrete
setblock 405 209 270 minecraft:moss_block
setblock 407 209 228 minecraft:green_terracotta
fill 408 209 228 408 213 228 minecraft:jungle_leaves[persistent=true]
setblock 418 209 252 minecraft:green_concrete
fill 418 209 265 418 219 265 minecraft:green_terracotta
setblock 418 209 268 minecraft:mossy_cobblestone
fill 418 209 269 418 222 269 minecraft:green_terracotta
fill 376 210 268 376 211 269 minecraft:oak_leaves[persistent=true]
fill 379 210 244 379 210 252 minecraft:bone_block
fill 380 210 230 380 213 240 minecraft:brown_terracotta
fill 380 210 241 380 210 243 minecraft:bone_block
fill 380 210 253 380 210 255 minecraft:bone_block
fill 380 210 256 380 213 268 minecraft:brown_terracotta
setblock 381 210 240 minecraft:bone_block
setblock 381 210 256 minecraft:bone_block
fill 382 210 228 382 211 228 minecraft:jungle_leaves[persistent=true]
setblock 382 210 239 minecraft:bone_block
setblock 382 210 257 minecraft:bone_block
setblock 383 210 238 minecraft:bone_block
fill 383 210 239 383 212 240 minecraft:jungle_leaves[persistent=true]
setblock 383 210 258 minecraft:bone_block
setblock 384 210 237 minecraft:bone_block
setblock 384 210 259 minecraft:bone_block
setblock 385 210 236 minecraft:bone_block
setblock 385 210 260 minecraft:bone_block
fill 386 210 230 386 215 234 minecraft:brown_terracotta
fill 386 210 235 388 210 235 minecraft:bone_block
fill 386 210 236 388 213 236 minecraft:azalea_leaves[persistent=true]
fill 386 210 260 386 213 260 minecraft:jungle_leaves[persistent=true]
fill 386 210 261 388 210 261 minecraft:bone_block
fill 386 210 262 386 215 268 minecraft:brown_terracotta
fill 389 210 234 397 210 234 minecraft:bone_block
fill 389 210 262 397 210 262 minecraft:bone_block
setblock 392 210 270 minecraft:green_concrete
fill 398 210 235 400 210 235 minecraft:bone_block
fill 398 210 261 400 210 261 minecraft:bone_block
fill 401 210 228 401 220 228 minecraft:green_terracotta
fill 401 210 235 416 213 235 minecraft:brown_terracotta
setblock 401 210 236 minecraft:bone_block
setblock 401 210 260 minecraft:bone_block
fill 401 210 261 416 213 261 minecraft:brown_terracotta
setblock 402 210 237 minecraft:bone_block
setblock 402 210 259 minecraft:bone_block
setblock 403 210 238 minecraft:bone_block
setblock 403 210 258 minecraft:bone_block
setblock 404 210 239 minecraft:bone_block
setblock 404 210 257 minecraft:bone_block
setblock 405 210 240 minecraft:bone_block
setblock 405 210 256 minecraft:bone_block
setblock 405 210 270 minecraft:jungle_leaves[persistent=true]
fill 406 210 241 406 210 243 minecraft:bone_block
fill 406 210 253 406 210 255 minecraft:bone_block
fill 407 210 228 407 213 228 minecraft:jungle_leaves[persistent=true]
fill 407 210 241 416 215 241 minecraft:brown_terracotta
fill 407 210 244 407 210 252 minecraft:bone_block
fill 407 210 255 416 215 255 minecraft:brown_terracotta
fill 407 210 270 408 213 270 minecraft:azalea_leaves[persistent=true]
fill 409 210 228 409 213 228 minecraft:jungle_leaves[persistent=true]
setblock 409 210 270 minecraft:green_terracotta
fill 414 210 228 414 216 228 minecraft:green_terracotta
fill 415 210 228 415 211 228 minecraft:jungle_log
fill 418 210 230 418 211 231 minecraft:jungle_log
fill 418 210 252 418 222 252 minecraft:green_terracotta
fill 418 210 260 418 222 260 minecraft:green_terracotta
setblock 418 210 261 minecraft:moss_block
fill 418 210 268 418 222 268 minecraft:green_terracotta
setblock 376 211 251 minecraft:green_concrete
fill 376 211 259 376 213 260 minecraft:oak_leaves[persistent=true]
fill 376 211 270 376 212 270 minecraft:oak_leaves[persistent=true]
fill 378 211 230 378 211 246 minecraft:brown_terracotta
fill 378 211 247 378 213 249 minecraft:brown_concrete
fill 378 211 250 378 211 268 minecraft:brown_terracotta
fill 379 211 230 379 212 242 minecraft:brown_terracotta
fill 379 211 243 379 211 246 minecraft:brown_concrete
fill 379 211 250 379 211 253 minecraft:brown_concrete
fill 379 211 254 379 212 268 minecraft:brown_terracotta
fill 380 211 241 380 212 242 minecraft:brown_concrete
fill 380 211 254 380 212 255 minecraft:brown_concrete
fill 381 211 240 381 213 240 minecraft:brown_concrete
fill 381 211 241 382 212 241 minecraft:jungle_leaves[persistent=true]
fill 381 211 256 381 213 256 minecraft:brown_concrete
setblock 382 211 239 minecraft:brown_concrete
setblock 382 211 257 minecraft:brown_concrete
fill 383 211 228 385 212 228 minecraft:jungle_leaves[persistent=true]
setblock 383 211 238 minecraft:brown_concrete
setblock 383 211 258 minecraft:brown_concrete
setblock 384 211 237 minecraft:brown_concrete
setblock 384 211 239 minecraft:jungle_leaves[persistent=true]
fill 384 211 258 384 212 258 minecraft:jungle_leaves[persistent=true]
setblock 384 211 259 minecraft:brown_concrete
fill 385 211 236 385 213 236 minecraft:brown_concrete
fill 385 211 259 385 213 259 minecraft:jungle_leaves[persistent=true]
fill 385 211 260 385 213 260 minecraft:brown_concrete
fill 386 211 235 387 212 235 minecraft:brown_concrete
fill 386 211 237 387 212 237 minecraft:azalea_leaves[persistent=true]
fill 386 211 261 387 212 261 minecraft:brown_concrete
fill 388 211 230 388 216 233 minecraft:brown_terracotta
fill 388 211 234 391 211 234 minecraft:brown_concrete
fill 388 211 235 389 211 235 minecraft:azalea_leaves[persistent=true]
fill 388 211 262 391 211 262 minecraft:brown_concrete
fill 388 211 263 388 216 268 minecraft:brown_terracotta
fill 392 211 230 416 216 232 minecraft:brown_terracotta
fill 392 211 233 394 213 233 minecraft:brown_concrete
fill 392 211 263 394 213 263 minecraft:brown_concrete
fill 392 211 264 416 216 268 minecraft:brown_terracotta
fill 392 211 270 392 222 270 minecraft:green_terracotta
fill 395 211 233 416 211 233 minecraft:brown_terracotta
fill 395 211 234 398 211 234 minecraft:brown_concrete
fill 395 211 262 398 211 262 minecraft:brown_concrete
fill 395 211 263 416 211 263 minecraft:brown_terracotta
fill 399 211 234 416 212 234 minecraft:brown_terracotta
fill 399 211 235 400 212 235 minecraft:brown_concrete
fill 399 211 261 400 212 261 minecraft:brown_concrete
fill 399 211 262 416 212 262 minecraft:brown_terracotta
fill 401 211 236 401 213 236 minecraft:brown_concrete
fill 401 211 260 401 213 260 minecraft:brown_concrete
setblock 402 211 237 minecraft:brown_concrete
setblock 402 211 259 minecraft:brown_concrete
setblock 403 211 238 minecraft:brown_concrete
setblock 403 211 258 minecraft:brown_concrete
setblock 404 211 239 minecraft:brown_concrete
setblock 404 211 257 minecraft:brown_concrete
fill 405 211 240 405 213 240 minecraft:brown_concrete
fill 405 211 256 405 213 256 minecraft:brown_concrete
fill 405 211 270 405 222 270 minecraft:green_terracotta
fill 406 211 228 406 213 228 minecraft:jungle_leaves[persistent=true]
fill 406 211 241 406 212 242 minecraft:brown_concrete
fill 406 211 254 406 212 255 minecraft:brown_concrete
fill 406 211 270 406 212 270 minecraft:azalea_leaves[persistent=true]
fill 407 211 243 407 211 246 minecraft:brown_concrete
fill 407 211 250 407 211 253 minecraft:brown_concrete
fill 408 211 243 416 216 243 minecraft:brown_terracotta
fill 408 211 247 408 213 249 minecraft:brown_concrete
fill 408 211 253 416 216 253 minecraft:brown_terracotta
fill 409 211 247 416 216 249 minecraft:brown_terracotta
fill 409 211 270 409 212 270 minecraft:azalea_leaves[persistent=true]
fill 410 211 228 410 212 228 minecraft:jungle_leaves[persistent=true]
fill 416 211 228 416 212 228 minecraft:jungle_leaves[persistent=true]
fill 418 211 261 418 222 261 minecraft:green_terracotta
setblock 418 211 266 minecraft:mossy_cobblestone
fill 376 212 251 376 215 251 minecraft:green_terracotta
fill 376 212 268 376 217 268 minecraft:green_terracotta
setblock 376 212 269 minecraft:oak_leaves[persistent=true]
fill 378 212 230 378 212 245 minecraft:brown_terracotta
fill 378 212 246 378 213 246 minecraft:brown_concrete
fill 378 212 250 378 213 250 minecraft:brown_concrete
fill 378 212 251 378 212 268 minecraft:brown_terracotta
fill 379 212 243 379 212 245 minecraft:brown_concrete
setblock 379 212 247 minecraft:light[level=15]
fill 379 212 251 379 212 253 minecraft:brown_concrete
fill 381 212 230 381 216 238 minecraft:brown_terracotta
fill 381 212 239 381 213 239 minecraft:brown_concrete
fill 381 212 257 381 213 257 minecraft:brown_concrete
fill 381 212 258 381 216 268 minecraft:brown_terracotta
fill 382 212 228 382 218 228 minecraft:green_terracotta
fill 382 212 230 382 216 237 minecraft:brown_terracotta
fill 382 212 238 382 213 238 minecraft:brown_concrete
fill 382 212 239 382 214 239 minecraft:jungle_leaves[persistent=true]
fill 382 212 258 382 213 258 minecraft:brown_concrete
fill 382 212 259 382 216 268 minecraft:brown_terracotta
fill 383 212 230 383 216 236 minecraft:brown_terracotta
fill 383 212 237 383 213 237 minecraft:brown_concrete
fill 383 212 238 383 213 238 minecraft:jungle_leaves[persistent=true]
fill 383 212 259 383 213 259 minecraft:brown_concrete
fill 383 212 260 383 216 268 minecraft:brown_terracotta
fill 384 212 230 384 216 235 minecraft:brown_terracotta
fill 384 212 236 384 213 236 minecraft:brown_concrete
fill 384 212 259 384 213 259 minecraft:jungle_leaves[persistent=true]
fill 384 212 260 384 213 260 minecraft:brown_concrete
fill 384 212 261 384 216 268 minecraft:brown_terracotta
setblock 387 212 239 minecraft:light[level=15]
setblock 387 212 247 minecraft:light[level=15]
setblock 387 212 255 minecraft:light[level=15]
fill 388 212 234 390 212 234 minecraft:brown_concrete
setblock 388 212 235 minecraft:azalea_leaves[persistent=true]
fill 388 212 262 390 212 262 minecraft:brown_concrete
fill 391 212 230 391 216 232 minecraft:brown_terracotta
fill 391 212 233 391 213 233 minecraft:brown_concrete
fill 391 212 263 391 213 263 minecraft:brown_concrete
fill 391 212 264 391 216 268 minecraft:brown_terracotta
fill 395 212 233 395 213 233 minecraft:brown_concrete
setblock 395 212 239 minecraft:light[level=15]
setblock 395 212 247 minecraft:light[level=15]
setblock 395 212 255 minecraft:light[level=15]
fill 395 212 263 395 213 263 minecraft:brown_concrete
fill 396 212 233 416 212 233 minecraft:brown_terracotta
fill 396 212 234 398 212 234 minecraft:brown_concrete
fill 396 212 262 398 212 262 minecraft:brown_concrete
fill 396 212 263 416 212 263 minecraft:brown_terracotta
fill 402 212 236 402 213 236 minecraft:brown_concrete
fill 402 212 260 402 213 260 minecraft:brown_concrete
fill 403 212 236 416 216 236 minecraft:brown_terracotta
fill 403 212 237 403 213 237 minecraft:brown_concrete
setblock 403 212 239 minecraft:light[level=15]
setblock 403 212 247 minecraft:light[level=15]
setblock 403 212 255 minecraft:light[level=15]
fill 403 212 259 403 213 259 minecraft:brown_concrete
fill 403 212 260 416 216 260 minecraft:brown_terracotta
fill 404 212 237 416 216 237 minecraft:brown_terracotta
fill 404 212 238 404 213 238 minecraft:brown_concrete
fill 404 212 258 404 213 258 minecraft:brown_concrete
fill 404 212 259 416 216 259 minecraft:brown_terracotta
fill 405 212 238 416 216 238 minecraft:brown_terracotta
fill 405 212 239 405 213 239 minecraft:brown_concrete
fill 405 212 257 405 213 257 minecraft:brown_concrete
fill 405 212 258 416 216 258 minecraft:brown_terracotta
fill 406 212 239 416 216 239 minecraft:brown_terracotta
fill 406 212 257 416 216 257 minecraft:brown_terracotta
fill 407 212 243 407 212 245 minecraft:brown_concrete
fill 407 212 251 407 212 253 minecraft:brown_concrete
fill 408 212 246 408 213 246 minecraft:brown_concrete
fill 408 212 250 408 213 250 minecraft:brown_concrete
fill 409 212 246 416 216 246 minecraft:brown_terracotta
fill 409 212 250 416 216 250 minecraft:brown_terracotta
fill 415 212 228 415 222 228 minecraft:green_terracotta
setblock 417 212 228 minecraft:jungle_leaves[persistent=true]
fill 418 212 228 418 218 228 minecraft:green_terracotta
setblock 418 212 229 minecraft:azalea_leaves[persistent=true]
fill 418 212 230 418 220 231 minecraft:green_terracotta
fill 418 212 266 418 222 266 minecraft:green_terracotta
fill 376 213 241 376 222 242 minecraft:green_terracotta
setblock 376 213 243 minecraft:moss_block
fill 376 213 269 376 219 270 minecraft:green_terracotta
fill 378 213 230 378 214 244 minecraft:brown_terracotta
setblock 378 213 245 minecraft:brown_concrete
setblock 378 213 251 minecraft:brown_concrete
fill 378 213 252 378 214 268 minecraft:brown_terracotta
fill 379 213 230 379 215 241 minecraft:brown_terracotta
fill 379 213 242 379 213 244 minecraft:brown_concrete
setblock 379 213 245 minecraft:light[level=12]
fill 379 213 252 379 213 254 minecraft:brown_concrete
fill 379 213 255 379 215 268 minecraft:brown_terracotta
setblock 380 213 241 minecraft:brown_concrete
setblock 380 213 255 minecraft:brown_concrete
setblock 381 213 241 minecraft:jungle_leaves[persistent=true]
fill 383 213 228 384 213 228 minecraft:jungle_leaves[persistent=true]
setblock 383 213 239 minecraft:jungle_leaves[persistent=true]
fill 385 213 228 385 222 228 minecraft:green_terracotta
setblock 386 213 235 minecraft:brown_concrete
setblock 386 213 238 minecraft:light[level=12]
setblock 386 213 245 minecraft:light[level=12]
setblock 386 213 252 minecraft:light[level=12]
setblock 386 213 259 minecraft:light[level=12]
setblock 386 213 261 minecraft:brown_concrete
fill 387 213 230 387 216 233 minecraft:brown_terracotta
fill 387 213 234 389 213 234 minecraft:brown_concrete
setblock 387 213 235 minecraft:azalea_leaves[persistent=true]
setblock 387 213 237 minecraft:azalea_leaves[persistent=true]
fill 387 213 262 389 213 262 minecraft:brown_concrete
fill 387 213 263 387 216 268 minecraft:brown_terracotta
fill 390 213 230 390 216 232 minecraft:brown_terracotta
setblock 390 213 233 minecraft:brown_concrete
setblock 390 213 263 minecraft:brown_concrete
fill 390 213 264 390 216 268 minecraft:brown_terracotta
setblock 393 213 238 minecraft:light[level=12]
setblock 393 213 245 minecraft:light[level=12]
setblock 393 213 259 minecraft:light[level=12]
setblock 396 213 233 minecraft:brown_concrete
setblock 396 213 263 minecraft:brown_concrete
fill 397 213 233 416 214 233 minecraft:brown_terracotta
fill 397 213 234 399 213 234 minecraft:brown_concrete
fill 397 213 262 399 213 262 minecraft:brown_concrete
fill 397 213 263 416 214 263 minecraft:brown_terracotta
fill 400 213 234 416 215 234 minecraft:brown_terracotta
setblock 400 213 235 minecraft:brown_concrete
setblock 400 213 238 minecraft:light[level=12]
setblock 400 213 245 minecraft:light[level=12]
setblock 400 213 252 minecraft:light[level=12]
setblock 400 213 259 minecraft:light[level=12]
setblock 400 213 261 minecraft:brown_concrete
fill 400 213 262 416 215 262 minecraft:brown_terracotta
setblock 406 213 241 minecraft:brown_concrete
setblock 406 213 255 minecraft:brown_concrete
fill 406 213 270 406 219 270 minecraft:green_terracotta
fill 407 213 242 407 213 244 minecraft:brown_concrete
setblock 407 213 245 minecraft:light[level=12]
fill 407 213 252 407 213 254 minecraft:brown_concrete
fill 408 213 242 416 216 242 minecraft:brown_terracotta
setblock 408 213 245 minecraft:brown_concrete
setblock 408 213 251 minecraft:brown_concrete
fill 408 213 254 416 216 254 minecraft:brown_terracotta
fill 409 213 245 416 216 245 minecraft:brown_terracotta
fill 409 213 251 416 216 251 minecraft:brown_terracotta
fill 409 213 270 409 214 270 minecraft:green_terracotta
fill 410 213 228 410 222 228 minecraft:green_terracotta
fill 416 213 228 417 222 228 minecraft:green_terracotta
fill 418 213 229 418 222 229 minecraft:green_terracotta
setblock 376 214 243 minecraft:green_terracotta
setblock 376 214 246 minecraft:jungle_leaves[persistent=true]
fill 376 214 259 376 222 259 minecraft:green_terracotta
setblock 376 214 260 minecraft:oak_leaves[persistent=true]
fill 376 214 262 376 219 262 minecraft:green_terracotta
fill 376 214 263 376 215 263 minecraft:mossy_cobblestone
fill 378 214 245 378 214 251 minecraft:bone_block
fill 379 214 242 379 214 244 minecraft:bone_block
fill 379 214 252 379 214 254 minecraft:bone_block
fill 380 214 230 380 216 239 minecraft:brown_terracotta
fill 380 214 240 380 214 241 minecraft:bone_block
fill 380 214 255 380 214 256 minecraft:bone_block
fill 380 214 257 380 216 268 minecraft:brown_terracotta
setblock 381 214 239 minecraft:bone_block
setblock 381 214 257 minecraft:bone_block
setblock 382 214 238 minecraft:bone_block
setblock 382 214 258 minecraft:bone_block
fill 383 214 228 384 214 228 minecraft:green_terracotta
setblock 383 214 237 minecraft:bone_block
setblock 383 214 259 minecraft:bone_block
setblock 384 214 236 minecraft:bone_block
setblock 384 214 260 minecraft:bone_block
fill 385 214 230 385 216 234 minecraft:brown_terracotta
fill 385 214 235 386 214 235 minecraft:bone_block
setblock 385 214 260 minecraft:jungle_leaves[persistent=true]
fill 385 214 261 386 214 261 minecraft:bone_block
fill 385 214 262 385 216 268 minecraft:brown_terracotta
fill 387 214 234 389 214 234 minecraft:bone_block
setblock 387 214 236 minecraft:azalea_leaves[persistent=true]
fill 387 214 262 389 214 262 minecraft:bone_block
fill 390 214 233 396 214 233 minecraft:bone_block
fill 390 214 263 396 214 263 minecraft:bone_block
fill 397 214 234 399 214 234 minecraft:bone_block
fill 397 214 262 399 214 262 minecraft:bone_block
fill 400 214 235 401 214 235 minecraft:bone_block
fill 400 214 261 401 214 261 minecraft:bone_block
fill 402 214 235 416 216 235 minecraft:brown_terracotta
setblock 402 214 236 minecraft:bone_block
setblock 402 214 260 minecraft:bone_block
fill 402 214 261 416 216 261 minecraft:brown_terracotta
setblock 403 214 237 minecraft:bone_block
setblock 403 214 259 minecraft:bone_block
setblock 404 214 238 minecraft:bone_block
setblock 404 214 258 minecraft:bone_block
setblock 405 214 239 minecraft:bone_block
setblock 405 214 257 minecraft:bone_block
fill 406 214 228 409 218 228 minecraft:green_terracotta
fill 406 214 240 406 214 241 minecraft:bone_block
fill 406 214 255 406 214 256 minecraft:bone_block
fill 407 214 240 416 216 240 minecraft:brown_terracotta
fill 407 214 242 407 214 244 minecraft:bone_block
fill 407 214 252 407 214 254 minecraft:bone_block
fill 407 214 256 416 216 256 minecraft:brown_terracotta
fill 407 214 270 408 220 270 minecraft:green_terracotta
fill 408 214 245 408 214 251 minecraft:bone_block
setblock 376 215 243 minecraft:jungle_leaves[persistent=true]
fill 376 215 246 376 222 246 minecraft:green_terracotta
fill 376 215 260 376 221 260 minecraft:green_terracotta
fill 378 215 230 378 216 243 minecraft:brown_terracotta
fill 378 215 244 378 217 252 minecraft:brown_concrete
fill 378 215 253 378 216 268 minecraft:brown_terracotta
fill 379 215 242 379 216 243 minecraft:brown_concrete
fill 379 215 253 379 216 254 minecraft:brown_concrete
fill 380 215 240 380 215 241 minecraft:brown_concrete
fill 380 215 248 380 220 248 minecraft:moss_block
fill 380 215 255 380 215 256 minecraft:brown_concrete
fill 381 215 239 381 217 239 minecraft:brown_concrete
fill 381 215 257 381 217 257 minecraft:brown_concrete
fill 382 215 238 382 216 238 minecraft:brown_concrete
fill 382 215 258 382 216 258 minecraft:brown_concrete
setblock 383 215 228 minecraft:green_concrete
fill 383 215 237 383 216 237 minecraft:brown_concrete
fill 383 215 259 383 216 259 minecraft:brown_concrete
fill 384 215 228 384 222 228 minecraft:green_terracotta
fill 384 215 236 384 217 236 minecraft:brown_concrete
fill 384 215 260 384 217 260 minecraft:brown_concrete
fill 385 215 235 386 215 235 minecraft:brown_concrete
fill 385 215 261 386 215 261 minecraft:brown_concrete
fill 387 215 234 388 216 234 minecraft:brown_concrete
fill 387 215 262 388 216 262 minecraft:brown_concrete
fill 389 215 230 389 216 232 minecraft:brown_terracotta
fill 389 215 233 397 217 233 minecraft:brown_concrete
fill 389 215 263 397 217 263 minecraft:brown_concrete
fill 389 215 264 389 216 268 minecraft:brown_terracotta
fill 398 215 233 416 216 233 minecraft:brown_terracotta
fill 398 215 234 399 216 234 minecraft:brown_concrete
fill 398 215 262 399 216 262 minecraft:brown_concrete
fill 398 215 263 416 216 263 minecraft:brown_terracotta
fill 399 215 228 399 220 228 minecraft:green_terracotta
fill 400 215 228 400 216 228 minecraft:jungle_leaves[persistent=true]
fill 400 215 235 401 215 235 minecraft:brown_concrete
fill 400 215 261 401 215 261 minecraft:brown_concrete
fill 402 215 236 402 217 236 minecraft:brown_concrete
fill 402 215 260 402 217 260 minecraft:brown_concrete
fill 403 215 237 403 216 237 minecraft:brown_concrete
fill 403 215 259 403 216 259 minecraft:brown_concrete
fill 404 215 238 404 216 238 minecraft:brown_concrete
fill 404 215 258 404 216 258 minecraft:brown_concrete
fill 405 215 239 405 217 239 minecraft:brown_concrete
fill 405 215 257 405 217 257 minecraft:brown_concrete
fill 406 215 240 406 215 241 minecraft:brown_concrete
fill 406 215 255 406 215 256 minecraft:brown_concrete
fill 407 215 242 407 216 243 minecraft:brown_concrete
fill 407 215 253 407 216 254 minecraft:brown_concrete
fill 408 215 244 408 217 252 minecraft:brown_concrete
fill 409 215 244 416 216 244 minecraft:brown_terracotta
fill 409 215 252 416 216 252 minecraft:brown_terracotta
setblock 409 215 270 minecraft:moss_block
fill 376 216 243 376 222 243 minecraft:green_terracotta
setblock 376 216 249 minecraft:green_concrete
setblock 376 216 251 minecraft:mossy_cobblestone
fill 376 216 263 376 222 263 minecraft:green_terracotta
fill 379 216 230 379 216 240 minecraft:brown_terracotta
fill 379 216 241 379 217 241 minecraft:brown_concrete
fill 379 216 255 379 217 255 minecraft:brown_concrete
fill 379 216 256 379 216 268 minecraft:brown_terracotta
fill 380 216 240 380 217 240 minecraft:brown_concrete
fill 380 216 256 380 217 256 minecraft:brown_concrete
fill 383 216 228 383 222 228 minecraft:green_terracotta
fill 385 216 235 385 217 235 minecraft:brown_concrete
fill 385 216 261 385 217 261 minecraft:brown_concrete
fill 386 216 230 386 216 233 minecraft:brown_terracotta
fill 386 216 234 386 217 234 minecraft:brown_concrete
fill 386 216 262 386 217 262 minecraft:brown_concrete
fill 386 216 263 386 216 268 minecraft:brown_terracotta
fill 400 216 234 400 217 234 minecraft:brown_concrete
fill 400 216 262 400 217 262 minecraft:brown_concrete
fill 401 216 234 416 216 234 minecraft:brown_terracotta
fill 401 216 235 401 217 235 minecraft:brown_concrete
fill 401 216 261 401 217 261 minecraft:brown_concrete
fill 401 216 262 416 216 262 minecraft:brown_terracotta
fill 406 216 240 406 217 240 minecraft:brown_concrete
fill 406 216 256 406 217 256 minecraft:brown_concrete
fill 407 216 241 407 217 241 minecraft:brown_concrete
fill 407 216 255 407 217 255 minecraft:brown_concrete
fill 408 216 241 416 216 241 minecraft:brown_terracotta
fill 408 216 255 416 216 255 minecraft:brown_terracotta
fill 409 216 270 409 219 270 minecraft:green_terracotta
fill 376 217 249 376 222 249 minecraft:green_terracotta
fill 376 217 251 376 222 251 minecraft:green_terracotta
fill 378 217 230 378 217 243 minecraft:brown_concrete
fill 378 217 253 378 217 268 minecraft:brown_concrete
fill 379 217 230 379 217 240 minecraft:brown_concrete
setblock 379 217 242 minecraft:brown_concrete
setblock 379 217 254 minecraft:brown_concrete
fill 379 217 256 379 217 268 minecraft:brown_concrete
fill 380 217 230 380 217 239 minecraft:brown_concrete
fill 380 217 257 380 217 268 minecraft:brown_concrete
fill 381 217 230 381 217 238 minecraft:brown_concrete
fill 381 217 258 381 217 268 minecraft:brown_concrete
fill 382 217 230 382 217 237 minecraft:brown_concrete
fill 382 217 259 382 217 268 minecraft:brown_concrete
setblock 382 217 270 minecraft:moss_block
fill 383 217 230 383 217 236 minecraft:brown_concrete
fill 383 217 260 383 217 268 minecraft:brown_concrete
fill 384 217 230 384 217 235 minecraft:brown_concrete
fill 384 217 261 384 217 268 minecraft:brown_concrete
fill 385 217 230 385 217 234 minecraft:brown_concrete
fill 385 217 262 385 217 268 minecraft:brown_concrete
fill 386 217 230 388 217 233 minecraft:brown_concrete
fill 386 217 263 388 217 268 minecraft:brown_concrete
setblock 387 217 234 minecraft:brown_concrete
setblock 387 217 262 minecraft:brown_concrete
fill 389 217 230 416 217 232 minecraft:brown_concrete
fill 389 217 264 416 217 268 minecraft:brown_concrete
fill 398 217 233 416 217 233 minecraft:brown_concrete
fill 398 217 263 416 217 263 minecraft:brown_concrete
setblock 399 217 234 minecraft:brown_concrete
setblock 399 217 262 minecraft:brown_concrete
fill 400 217 228 400 223 228 minecraft:green_terracotta
fill 401 217 234 416 217 234 minecraft:brown_concrete
fill 401 217 262 416 217 262 minecraft:brown_concrete
fill 402 217 235 416 217 235 minecraft:brown_concrete
fill 402 217 261 416 217 261 minecraft:brown_concrete
setblock 403 217 228 minecraft:moss_block
fill 403 217 236 416 217 236 minecraft:brown_concrete
fill 403 217 260 416 217 260 minecraft:brown_concrete
fill 404 217 237 416 217 237 minecraft:brown_concrete
fill 404 217 259 416 217 259 minecraft:brown_concrete
fill 405 217 238 416 217 238 minecraft:brown_concrete
fill 405 217 258 416 217 258 minecraft:brown_concrete
fill 406 217 239 416 217 239 minecraft:brown_concrete
fill 406 217 257 416 217 257 minecraft:brown_concrete
fill 407 217 240 416 217 240 minecraft:brown_concrete
fill 407 217 242 416 217 242 minecraft:brown_concrete
fill 407 217 254 416 217 254 minecraft:brown_concrete
fill 407 217 256 416 217 256 minecraft:brown_concrete
fill 408 217 241 416 217 241 minecraft:brown_concrete
fill 408 217 243 416 217 243 minecraft:brown_concrete
fill 408 217 253 416 217 253 minecraft:brown_concrete
fill 408 217 255 416 217 255 minecraft:brown_concrete
fill 409 217 244 416 217 252 minecraft:brown_concrete
setblock 414 217 228 minecraft:jungle_leaves[persistent=true]
setblock 418 217 240 minecraft:moss_block
setblock 418 217 248 minecraft:moss_block
setblock 376 218 264 minecraft:green_concrete
setblock 376 218 268 minecraft:moss_block
fill 377 218 231 383 220 233 minecraft:jungle_log
fill 377 218 265 383 220 267 minecraft:jungle_log
fill 378 218 230 382 220 230 minecraft:jungle_log
fill 378 218 234 382 220 234 minecraft:jungle_log
fill 378 218 264 382 220 264 minecraft:jungle_log
fill 378 218 268 382 220 268 minecraft:jungle_log
fill 379 218 229 381 220 229 minecraft:jungle_log
fill 379 218 235 381 220 235 minecraft:jungle_log
fill 379 218 263 381 220 263 minecraft:jungle_log
fill 379 218 269 381 220 269 minecraft:jungle_log
setblock 382 218 270 minecraft:green_terracotta
fill 387 218 246 387 228 248 minecraft:green_terracotta
setblock 387 218 249 minecraft:lime_terracotta
fill 387 218 250 387 235 250 minecraft:green_terracotta
setblock 388 218 242 minecraft:lime_terracotta
fill 388 218 243 388 234 245 minecraft:green_terracotta
setblock 388 218 246 minecraft:lime_terracotta
fill 388 218 247 388 222 249 minecraft:green_terracotta
setblock 388 218 250 minecraft:lime_terracotta
fill 388 218 251 388 220 253 minecraft:green_terracotta
setblock 388 218 254 minecraft:lime_terracotta
fill 389 218 241 390 226 242 minecraft:green_terracotta
setblock 389 218 243 minecraft:lime_terracotta
fill 389 218 244 389 223 246 minecraft:green_terracotta
setblock 389 218 247 minecraft:lime_terracotta
fill 389 218 248 389 219 250 minecraft:green_terracotta
fill 389 218 254 389 219 254 minecraft:green_terracotta
setblock 389 218 255 minecraft:lime_terracotta
fill 390 218 239 404 218 239 minecraft:brown_terracotta
setblock 390 218 240 minecraft:lime_terracotta
fill 390 218 243 392 221 243 minecraft:green_terracotta
setblock 390 218 244 minecraft:lime_terracotta
fill 390 218 245 390 222 247 minecraft:green_terracotta
setblock 390 218 248 minecraft:lime_terracotta
fill 390 218 249 390 219 249 minecraft:green_terracotta
fill 390 218 255 390 219 255 minecraft:green_terracotta
setblock 390 218 256 minecraft:lime_terracotta
fill 390 218 257 390 229 257 minecraft:green_terracotta
fill 391 218 238 403 218 238 minecraft:brown_terracotta
fill 391 218 240 393 228 240 minecraft:green_terracotta
setblock 391 218 241 minecraft:lime_terracotta
fill 391 218 242 391 231 242 minecraft:green_terracotta
fill 391 218 244 393 223 244 minecraft:green_terracotta
setblock 391 218 245 minecraft:lime_terracotta
fill 391 218 246 391 220 248 minecraft:green_terracotta
fill 391 218 256 393 220 256 minecraft:green_terracotta
setblock 391 218 257 minecraft:lime_terracotta
fill 391 218 258 391 229 258 minecraft:green_terracotta
fill 392 218 237 402 218 237 minecraft:brown_terracotta
fill 392 218 241 394 230 241 minecraft:green_terracotta
setblock 392 218 242 minecraft:lime_terracotta
fill 392 218 245 394 223 245 minecraft:green_terracotta
setblock 392 218 246 minecraft:lime_terracotta
fill 392 218 247 392 219 248 minecraft:green_terracotta
fill 392 218 257 394 221 257 minecraft:green_terracotta
setblock 392 218 258 minecraft:lime_terracotta
fill 392 218 259 392 225 259 minecraft:green_terracotta
fill 393 218 242 395 228 242 minecraft:green_terracotta
setblock 393 218 243 minecraft:lime_terracotta
fill 393 218 246 395 222 246 minecraft:green_terracotta
setblock 393 218 247 minecraft:lime_terracotta
fill 393 218 248 393 220 248 minecraft:green_terracotta
fill 393 218 258 395 224 258 minecraft:green_terracotta
setblock 393 218 259 minecraft:lime_terracotta
fill 394 218 236 400 218 236 minecraft:brown_terracotta
setblock 394 218 240 minecraft:lime_terracotta
fill 394 218 243 396 221 243 minecraft:green_terracotta
setblock 394 218 244 minecraft:lime_terracotta
fill 394 218 247 396 221 247 minecraft:green_terracotta
setblock 394 218 248 minecraft:lime_terracotta
fill 394 218 249 394 219 249 minecraft:green_terracotta
fill 394 218 255 396 219 255 minecraft:green_terracotta
setblock 394 218 256 minecraft:lime_terracotta
fill 394 218 259 396 225 259 minecraft:green_terracotta
setblock 394 218 260 minecraft:lime_terracotta
fill 395 218 240 397 231 240 minecraft:green_terracotta
setblock 395 218 241 minecraft:lime_terracotta
fill 395 218 244 397 223 244 minecraft:green_terracotta
setblock 395 218 245 minecraft:lime_terracotta
fill 395 218 248 397 221 248 minecraft:green_terracotta
setblock 395 218 249 minecraft:lime_terracotta
fill 395 218 250 395 219 250 minecraft:green_terracotta
fill 395 218 254 395 219 254 minecraft:green_terracotta
fill 395 218 256 397 221 256 minecraft:green_terracotta
setblock 395 218 257 minecraft:lime_terracotta
fill 395 218 260 397 223 260 minecraft:green_terracotta
setblock 395 218 270 minecraft:jungle_leaves[persistent=true]
fill 396 218 241 398 229 241 minecraft:green_terracotta
setblock 396 218 242 minecraft:lime_terracotta
fill 396 218 245 398 225 245 minecraft:green_terracotta
setblock 396 218 246 minecraft:lime_terracotta
fill 396 218 249 398 221 249 minecraft:green_terracotta
setblock 396 218 250 minecraft:lime_terracotta
fill 396 218 251 396 220 253 minecraft:green_terracotta
setblock 396 218 254 minecraft:lime_terracotta
fill 396 218 257 398 224 257 minecraft:green_terracotta
setblock 396 218 258 minecraft:lime_terracotta
fill 397 218 242 399 229 242 minecraft:green_terracotta
setblock 397 218 243 minecraft:lime_terracotta
fill 397 218 246 399 225 246 minecraft:green_terracotta
setblock 397 218 247 minecraft:lime_terracotta
fill 397 218 250 399 221 250 minecraft:green_terracotta
setblock 397 218 251 minecraft:lime_terracotta
fill 397 218 252 397 221 254 minecraft:green_terracotta
setblock 397 218 255 minecraft:lime_terracotta
fill 397 218 258 399 226 258 minecraft:green_terracotta
setblock 397 218 259 minecraft:lime_terracotta
setblock 398 218 240 minecraft:lime_terracotta
fill 398 218 243 400 221 243 minecraft:green_terracotta
setblock 398 218 244 minecraft:lime_terracotta
fill 398 218 247 400 225 247 minecraft:green_terracotta
setblock 398 218 248 minecraft:lime_terracotta
fill 398 218 251 400 222 251 minecraft:green_terracotta
setblock 398 218 252 minecraft:lime_terracotta
fill 398 218 253 398 223 255 minecraft:green_terracotta
setblock 398 218 256 minecraft:lime_terracotta
fill 398 218 259 400 225 259 minecraft:green_terracotta
setblock 398 218 260 minecraft:lime_terracotta
fill 399 218 240 401 231 240 minecraft:green_terracotta
setblock 399 218 241 minecraft:lime_terracotta
fill 399 218 244 401 223 244 minecraft:green_terracotta
setblock 399 218 245 minecraft:lime_terracotta
fill 399 218 248 401 225 248 minecraft:green_terracotta
setblock 399 218 249 minecraft:lime_terracotta
fill 399 218 252 401 221 252 minecraft:green_terracotta
setblock 399 218 253 minecraft:lime_terracotta
fill 399 218 254 399 225 256 minecraft:green_terracotta
setblock 399 218 257 minecraft:lime_terracotta
fill 399 218 260 400 228 260 minecraft:green_terracotta
fill 400 218 241 402 231 241 minecraft:green_terracotta
setblock 400 218 242 minecraft:lime_terracotta
fill 400 218 245 402 225 245 minecraft:green_terracotta
setblock 400 218 246 minecraft:lime_terracotta
fill 400 218 249 402 226 249 minecraft:green_terracotta
setblock 400 218 250 minecraft:lime_terracotta
fill 400 218 253 402 226 253 minecraft:green_terracotta
setblock 400 218 254 minecraft:lime_terracotta
fill 400 218 255 400 228 257 minecraft:green_terracotta
setblock 400 218 258 minecraft:lime_terracotta
fill 401 218 242 403 231 242 minecraft:green_terracotta
setblock 401 218 243 minecraft:lime_terracotta
fill 401 218 246 403 226 246 minecraft:green_terracotta
setblock 401 218 247 minecraft:lime_terracotta
fill 401 218 250 403 226 250 minecraft:green_terracotta
setblock 401 218 251 minecraft:lime_terracotta
fill 401 218 254 403 226 254 minecraft:green_terracotta
setblock 401 218 255 minecraft:lime_terracotta
fill 401 218 256 401 226 258 minecraft:green_terracotta
setblock 401 218 259 minecraft:lime_terracotta
setblock 402 218 240 minecraft:lime_terracotta
fill 402 218 243 404 231 243 minecraft:green_terracotta
setblock 402 218 244 minecraft:lime_terracotta
fill 402 218 247 404 230 247 minecraft:green_terracotta
setblock 402 218 248 minecraft:lime_terracotta
fill 402 218 251 404 225 251 minecraft:green_terracotta
setblock 402 218 252 minecraft:lime_terracotta
fill 402 218 255 404 227 255 minecraft:green_terracotta
setblock 402 218 256 minecraft:lime_terracotta
fill 402 218 257 402 226 259 minecraft:green_terracotta
fill 403 218 228 403 222 228 minecraft:green_terracotta
fill 403 218 240 404 226 240 minecraft:green_terracotta
setblock 403 218 241 minecraft:lime_terracotta
fill 403 218 244 405 232 244 minecraft:green_terracotta
setblock 403 218 245 minecraft:lime_terracotta
fill 403 218 248 405 227 248 minecraft:green_terracotta
setblock 403 218 249 minecraft:lime_terracotta
fill 403 218 252 405 225 252 minecraft:green_terracotta
setblock 403 218 253 minecraft:lime_terracotta
fill 403 218 256 404 234 256 minecraft:green_terracotta
setblock 403 218 257 minecraft:lime_terracotta
fill 403 218 258 403 226 258 minecraft:green_terracotta
fill 404 218 241 405 228 241 minecraft:green_terracotta
setblock 404 218 242 minecraft:lime_terracotta
fill 404 218 245 406 234 245 minecraft:green_terracotta
setblock 404 218 246 minecraft:lime_terracotta
fill 404 218 249 406 226 249 minecraft:green_terracotta
setblock 404 218 250 minecraft:lime_terracotta
fill 404 218 253 406 225 253 minecraft:green_terracotta
setblock 404 218 254 minecraft:lime_terracotta
fill 404 218 257 404 226 257 minecraft:green_terracotta
fill 405 218 242 406 233 242 minecraft:green_terracotta
setblock 405 218 243 minecraft:lime_terracotta
fill 405 218 246 407 235 246 minecraft:green_terracotta
setblock 405 218 247 minecraft:lime_terracotta
fill 405 218 250 407 226 250 minecraft:green_terracotta
setblock 405 218 251 minecraft:lime_terracotta
fill 405 218 254 406 225 254 minecraft:green_terracotta
setblock 405 218 255 minecraft:lime_terracotta
fill 406 218 243 406 234 243 minecraft:green_terracotta
setblock 406 218 244 minecraft:lime_terracotta
fill 406 218 247 407 235 247 minecraft:green_terracotta
setblock 406 218 248 minecraft:lime_terracotta
fill 406 218 251 406 225 251 minecraft:green_terracotta
setblock 406 218 252 minecraft:lime_terracotta
fill 407 218 248 407 234 248 minecraft:green_terracotta
setblock 407 218 249 minecraft:lime_terracotta
fill 411 218 231 417 220 233 minecraft:jungle_log
fill 411 218 265 417 220 267 minecraft:jungle_log
fill 412 218 230 416 220 230 minecraft:jungle_log
fill 412 218 234 416 220 234 minecraft:jungle_log
fill 412 218 264 416 220 264 minecraft:jungle_log
fill 412 218 268 416 220 268 minecraft:jungle_log
fill 413 218 229 415 220 229 minecraft:jungle_log
fill 413 218 235 415 220 235 minecraft:jungle_log
fill 413 218 263 415 220 263 minecraft:jungle_log
fill 413 218 269 415 220 269 minecraft:jungle_log
fill 414 218 228 414 223 228 minecraft:green_terracotta
fill 418 218 240 418 222 240 minecraft:green_terracotta
fill 418 218 248 418 222 248 minecraft:green_terracotta
setblock 418 218 257 minecraft:moss_block
fill 376 219 238 376 219 239 minecraft:lime_terracotta
setblock 376 219 255 minecraft:lime_terracotta
setblock 376 219 256 minecraft:green_concrete
setblock 376 219 264 minecraft:lime_terracotta
setblock 376 219 265 minecraft:jungle_leaves[persistent=true]
fill 376 219 268 376 222 268 minecraft:green_terracotta
setblock 379 219 238 minecraft:light[level=12]
setblock 379 219 239 minecraft:light[level=15]
setblock 379 219 245 minecraft:light[level=12]
setblock 379 219 247 minecraft:light[level=15]
setblock 379 219 252 minecraft:light[level=12]
setblock 379 219 255 minecraft:light[level=15]
setblock 379 219 259 minecraft:light[level=12]
setblock 380 219 270 minecraft:lime_terracotta
setblock 382 219 228 minecraft:lime_terracotta
fill 382 219 270 383 219 270 minecraft:lime_terracotta
setblock 386 219 228 minecraft:lime_terracotta
setblock 386 219 231 minecraft:light[level=12]
setblock 386 219 238 minecraft:light[level=12]
setblock 386 219 245 minecraft:light[level=12]
fill 386 219 248 386 227 248 minecraft:green_terracotta
setblock 386 219 252 minecraft:light[level=12]
setblock 386 219 259 minecraft:light[level=12]
setblock 386 219 266 minecraft:light[level=12]
setblock 387 219 231 minecraft:light[level=15]
setblock 387 219 239 minecraft:light[level=15]
setblock 387 219 243 minecraft:green_terracotta
setblock 387 219 244 minecraft:lime_terracotta
fill 387 219 245 387 228 245 minecraft:green_terracotta
fill 387 219 249 387 233 249 minecraft:green_terracotta
fill 387 219 251 387 234 251 minecraft:green_terracotta
setblock 387 219 252 minecraft:lime_terracotta
fill 387 219 253 387 233 253 minecraft:green_terracotta
setblock 387 219 255 minecraft:light[level=15]
setblock 387 219 263 minecraft:light[level=15]
fill 388 219 240 390 219 240 minecraft:green_terracotta
setblock 388 219 241 minecraft:lime_terracotta
fill 388 219 242 388 225 242 minecraft:green_terracotta
fill 388 219 246 388 233 246 minecraft:green_terracotta
fill 388 219 250 388 220 250 minecraft:green_terracotta
fill 388 219 254 388 219 256 minecraft:green_terracotta
setblock 389 219 239 minecraft:brown_terracotta
fill 389 219 243 389 221 243 minecraft:green_terracotta
fill 389 219 247 389 224 247 minecraft:green_terracotta
fill 389 219 255 389 220 257 minecraft:green_terracotta
fill 389 219 270 389 220 270 minecraft:lime_terracotta
setblock 390 219 238 minecraft:brown_terracotta
fill 390 219 239 404 226 239 minecraft:green_terracotta
fill 390 219 244 390 229 244 minecraft:green_terracotta
fill 390 219 248 390 220 248 minecraft:green_terracotta
fill 390 219 256 390 220 256 minecraft:green_terracotta
fill 390 219 258 390 234 258 minecraft:green_terracotta
setblock 391 219 237 minecraft:brown_terracotta
fill 391 219 238 403 225 238 minecraft:green_terracotta
fill 391 219 241 391 233 241 minecraft:green_terracotta
fill 391 219 245 391 224 245 minecraft:green_terracotta
fill 391 219 257 391 222 257 minecraft:green_terracotta
fill 391 219 259 391 234 259 minecraft:green_terracotta
setblock 391 219 270 minecraft:lime_terracotta
setblock 392 219 228 minecraft:lime_terracotta
fill 392 219 236 393 219 236 minecraft:brown_terracotta
fill 392 219 237 402 224 237 minecraft:green_terracotta
fill 392 219 242 392 229 242 minecraft:green_terracotta
fill 392 219 246 392 222 246 minecraft:green_terracotta
fill 392 219 258 392 225 258 minecraft:green_terracotta
fill 392 219 260 394 223 260 minecraft:green_terracotta
setblock 393 219 231 minecraft:light[level=12]
fill 393 219 243 393 227 243 minecraft:green_terracotta
fill 393 219 247 393 221 247 minecraft:green_terracotta
fill 393 219 259 393 226 259 minecraft:green_terracotta
setblock 393 219 266 minecraft:light[level=12]
fill 394 219 228 394 222 228 minecraft:green_terracotta
fill 394 219 235 400 219 235 minecraft:brown_terracotta
fill 394 219 236 400 225 236 minecraft:green_terracotta
fill 394 219 240 394 231 240 minecraft:green_terracotta
fill 394 219 244 394 225 244 minecraft:green_terracotta
fill 394 219 248 394 220 248 minecraft:green_terracotta
fill 394 219 256 394 220 256 minecraft:green_terracotta
fill 394 219 261 395 221 261 minecraft:green_terracotta
setblock 395 219 228 minecraft:lime_terracotta
setblock 395 219 231 minecraft:light[level=15]
fill 395 219 241 395 229 241 minecraft:green_terracotta
fill 395 219 245 395 224 245 minecraft:green_terracotta
fill 395 219 249 395 220 249 minecraft:green_terracotta
fill 395 219 257 395 223 257 minecraft:green_terracotta
setblock 395 219 263 minecraft:light[level=15]
fill 395 219 270 395 222 270 minecraft:green_terracotta
fill 396 219 242 396 228 242 minecraft:green_terracotta
fill 396 219 246 396 224 246 minecraft:green_terracotta
fill 396 219 250 396 220 250 minecraft:green_terracotta
fill 396 219 254 396 220 254 minecraft:green_terracotta
fill 396 219 258 396 226 258 minecraft:green_terracotta
setblock 396 219 261 minecraft:lime_terracotta
fill 397 219 243 397 228 243 minecraft:green_terracotta
fill 397 219 247 397 224 247 minecraft:green_terracotta
fill 397 219 251 397 221 251 minecraft:green_terracotta
fill 397 219 255 397 223 255 minecraft:green_terracotta
fill 397 219 259 397 229 259 minecraft:green_terracotta
fill 397 219 261 399 221 261 minecraft:green_terracotta
fill 398 219 240 398 231 240 minecraft:green_terracotta
fill 398 219 244 398 223 244 minecraft:green_terracotta
fill 398 219 248 398 224 248 minecraft:green_terracotta
fill 398 219 252 398 221 252 minecraft:green_terracotta
fill 398 219 256 398 226 256 minecraft:green_terracotta
fill 398 219 260 398 223 260 minecraft:green_terracotta
fill 399 219 241 399 230 241 minecraft:green_terracotta
fill 399 219 245 399 228 245 minecraft:green_terracotta
fill 399 219 249 399 225 249 minecraft:green_terracotta
fill 399 219 253 399 224 253 minecraft:green_terracotta
fill 399 219 257 399 229 257 minecraft:green_terracotta
setblock 400 219 231 minecraft:light[level=12]
fill 400 219 242 400 230 242 minecraft:green_terracotta
fill 400 219 246 400 228 246 minecraft:green_terracotta
fill 400 219 250 400 226 250 minecraft:green_terracotta
fill 400 219 254 400 227 254 minecraft:green_terracotta
fill 400 219 258 400 232 258 minecraft:green_terracotta
setblock 400 219 261 minecraft:lime_terracotta
setblock 400 219 266 minecraft:light[level=12]
setblock 400 219 270 minecraft:lime_terracotta
fill 401 219 236 402 219 236 minecraft:brown_terracotta
fill 401 219 243 401 221 243 minecraft:green_terracotta
fill 401 219 247 401 228 247 minecraft:green_terracotta
fill 401 219 251 401 227 251 minecraft:green_terracotta
fill 401 219 255 401 229 255 minecraft:green_terracotta
fill 401 219 259 401 223 260 minecraft:green_terracotta
fill 402 219 240 402 235 240 minecraft:green_terracotta
fill 402 219 244 402 232 244 minecraft:green_terracotta
fill 402 219 248 402 230 248 minecraft:green_terracotta
fill 402 219 252 402 227 252 minecraft:green_terracotta
fill 402 219 256 402 232 256 minecraft:green_terracotta
fill 402 219 260 402 225 260 minecraft:green_terracotta
setblock 403 219 231 minecraft:light[level=15]
setblock 403 219 237 minecraft:brown_terracotta
fill 403 219 241 403 235 241 minecraft:green_terracotta
fill 403 219 245 403 231 245 minecraft:green_terracotta
fill 403 219 249 403 227 249 minecraft:green_terracotta
fill 403 219 253 403 226 253 minecraft:green_terracotta
fill 403 219 257 403 235 257 minecraft:green_terracotta
fill 403 219 259 403 225 259 minecraft:green_terracotta
setblock 403 219 263 minecraft:light[level=15]
setblock 404 219 238 minecraft:brown_terracotta
fill 404 219 242 404 236 242 minecraft:green_terracotta
fill 404 219 246 404 233 246 minecraft:green_terracotta
fill 404 219 250 404 226 250 minecraft:green_terracotta
fill 404 219 254 404 225 254 minecraft:green_terracotta
fill 404 219 258 404 226 258 minecraft:green_terracotta
setblock 405 219 239 minecraft:brown_terracotta
fill 405 219 240 406 225 240 minecraft:green_terracotta
fill 405 219 243 405 236 243 minecraft:green_terracotta
fill 405 219 247 405 235 247 minecraft:green_terracotta
fill 405 219 251 405 225 251 minecraft:green_terracotta
fill 405 219 255 405 226 257 minecraft:green_terracotta
fill 406 219 228 406 223 228 minecraft:green_terracotta
fill 406 219 241 406 234 241 minecraft:green_terracotta
fill 406 219 244 406 235 244 minecraft:green_terracotta
fill 406 219 248 406 236 248 minecraft:green_terracotta
fill 406 219 252 406 225 252 minecraft:green_terracotta
setblock 406 219 255 minecraft:lime_terracotta
fill 406 219 256 406 226 256 minecraft:green_terracotta
setblock 407 219 228 minecraft:lime_terracotta
setblock 407 219 231 minecraft:light[level=12]
setblock 407 219 238 minecraft:light[level=12]
setblock 407 219 243 minecraft:green_terracotta
setblock 407 219 244 minecraft:lime_terracotta
fill 407 219 245 407 233 245 minecraft:green_terracotta
fill 407 219 249 407 229 249 minecraft:green_terracotta
fill 407 219 251 407 226 251 minecraft:green_terracotta
setblock 407 219 252 minecraft:lime_terracotta
fill 407 219 253 407 226 253 minecraft:green_terracotta
setblock 407 219 259 minecraft:light[level=12]
setblock 407 219 266 minecraft:light[level=12]
fill 408 219 228 409 222 228 minecraft:green_terracotta
setblock 408 219 248 minecraft:green_terracotta
setblock 410 219 270 minecraft:mossy_cobblestone
setblock 411 219 239 minecraft:light[level=15]
setblock 411 219 247 minecraft:light[level=15]
setblock 411 219 255 minecraft:light[level=15]
setblock 411 219 263 minecraft:light[level=15]
fill 413 219 270 416 219 270 minecraft:lime_terracotta
setblock 414 219 238 minecraft:light[level=12]
setblock 414 219 245 minecraft:light[level=12]
setblock 414 219 252 minecraft:light[level=12]
setblock 414 219 259 minecraft:light[level=12]
fill 418 219 228 418 220 228 minecraft:lime_terracotta
fill 418 219 232 418 222 232 minecraft:green_terracotta
setblock 418 219 233 minecraft:lime_terracotta
setblock 418 219 245 minecraft:lime_terracotta
setblock 418 219 247 minecraft:lime_terracotta
setblock 418 219 249 minecraft:lime_terracotta
fill 418 219 257 418 222 257 minecraft:green_terracotta
setblock 376 220 235 minecraft:lime_terracotta
fill 376 220 238 376 222 239 minecraft:green_terracotta
setblock 376 220 250 minecraft:lime_terracotta
fill 376 220 255 376 222 256 minecraft:green_terracotta
setblock 376 220 262 minecraft:lime_terracotta
fill 376 220 264 376 222 265 minecraft:green_terracotta
fill 376 220 269 376 220 270 minecraft:lime_terracotta
fill 377 220 270 377 221 270 minecraft:green_terracotta
fill 378 220 228 378 221 228 minecraft:lime_terracotta
setblock 378 220 270 minecraft:moss_block
setblock 380 220 270 minecraft:green_terracotta
setblock 381 220 228 minecraft:lime_terracotta
fill 381 220 270 381 221 270 minecraft:lime_terracotta
setblock 382 220 228 minecraft:green_terracotta
fill 382 220 270 383 222 270 minecraft:green_terracotta
fill 385 220 270 386 220 270 minecraft:lime_terracotta
setblock 386 220 228 minecraft:green_terracotta
fill 386 220 244 386 220 245 minecraft:green_terracotta
setblock 386 220 246 minecraft:lime_terracotta
fill 386 220 247 386 228 247 minecraft:green_terracotta
fill 386 220 249 386 230 249 minecraft:green_terracotta
setblock 386 220 250 minecraft:lime_terracotta
fill 386 220 251 386 221 252 minecraft:green_terracotta
fill 387 220 241 387 224 242 minecraft:green_terracotta
setblock 387 220 243 minecraft:lime_terracotta
fill 387 220 244 387 226 244 minecraft:green_terracotta
fill 387 220 252 387 230 252 minecraft:green_terracotta
fill 387 220 254 388 220 254 minecraft:green_terracotta
setblock 387 220 255 minecraft:lime_terracotta
fill 388 220 239 388 221 239 minecraft:brown_terracotta
setblock 388 220 240 minecraft:lime_terracotta
fill 388 220 241 388 225 241 minecraft:green_terracotta
fill 388 220 255 388 234 255 minecraft:green_terracotta
setblock 388 220 256 minecraft:lime_terracotta
fill 388 220 257 388 226 257 minecraft:green_terracotta
setblock 389 220 238 minecraft:brown_terracotta
fill 389 220 239 389 225 240 minecraft:green_terracotta
fill 389 220 248 389 220 249 minecraft:green_terracotta
setblock 389 220 250 minecraft:red_terracotta
setblock 389 220 254 minecraft:red_terracotta
fill 389 220 258 389 226 258 minecraft:green_terracotta
setblock 390 220 237 minecraft:brown_terracotta
fill 390 220 238 390 226 238 minecraft:green_terracotta
fill 390 220 240 390 226 240 minecraft:green_terracotta
setblock 390 220 249 minecraft:red_terracotta
setblock 390 220 255 minecraft:red_terracotta
fill 390 220 259 390 233 259 minecraft:green_terracotta
setblock 390 220 270 minecraft:lime_terracotta
setblock 391 220 236 minecraft:brown_terracotta
fill 391 220 237 391 224 237 minecraft:green_terracotta
fill 391 220 260 391 233 260 minecraft:green_terracotta
fill 391 220 270 391 222 270 minecraft:green_terracotta
fill 392 220 228 392 222 228 minecraft:green_terracotta
fill 392 220 235 393 220 235 minecraft:brown_terracotta
fill 392 220 236 393 223 236 minecraft:green_terracotta
setblock 392 220 247 minecraft:green_terracotta
setblock 392 220 248 minecraft:red_terracotta
fill 392 220 261 392 221 261 minecraft:green_terracotta
setblock 393 220 261 minecraft:lime_terracotta
fill 394 220 234 400 220 234 minecraft:brown_terracotta
fill 394 220 235 400 224 235 minecraft:green_terracotta
setblock 394 220 249 minecraft:red_terracotta
setblock 394 220 255 minecraft:red_terracotta
setblock 394 220 262 minecraft:lime_terracotta
fill 395 220 228 395 222 228 minecraft:green_terracotta
setblock 395 220 250 minecraft:red_terracotta
setblock 395 220 254 minecraft:red_terracotta
fill 395 220 255 396 220 255 minecraft:green_terracotta
fill 395 220 262 397 226 262 minecraft:green_terracotta
fill 396 220 228 397 220 228 minecraft:lime_terracotta
fill 396 220 261 396 234 261 minecraft:green_terracotta
setblock 398 220 262 minecraft:lime_terracotta
fill 399 220 262 400 225 262 minecraft:green_terracotta
fill 400 220 261 400 226 261 minecraft:green_terracotta
fill 400 220 270 400 223 270 minecraft:green_terracotta
fill 401 220 235 402 220 235 minecraft:brown_terracotta
fill 401 220 236 402 224 236 minecraft:green_terracotta
setblock 401 220 261 minecraft:lime_terracotta
fill 402 220 261 402 224 261 minecraft:green_terracotta
setblock 403 220 236 minecraft:brown_terracotta
fill 403 220 237 403 225 237 minecraft:green_terracotta
fill 403 220 260 403 225 260 minecraft:green_terracotta
fill 404 220 228 404 221 228 minecraft:lime_terracotta
setblock 404 220 237 minecraft:brown_terracotta
fill 404 220 238 404 226 238 minecraft:green_terracotta
fill 404 220 259 404 226 259 minecraft:green_terracotta
setblock 405 220 238 minecraft:brown_terracotta
fill 405 220 239 405 225 239 minecraft:green_terracotta
fill 405 220 258 405 225 258 minecraft:green_terracotta
fill 406 220 239 406 221 239 minecraft:brown_terracotta
fill 406 220 255 406 227 255 minecraft:green_terracotta
setblock 406 220 257 minecraft:green_terracotta
setblock 406 220 270 minecraft:lime_terracotta
fill 407 220 228 407 223 228 minecraft:green_terracotta
fill 407 220 241 407 232 242 minecraft:green_terracotta
setblock 407 220 243 minecraft:lime_terracotta
fill 407 220 244 407 234 244 minecraft:green_terracotta
fill 407 220 252 407 225 252 minecraft:green_terracotta
fill 407 220 254 407 226 254 minecraft:green_terracotta
setblock 407 220 255 minecraft:lime_terracotta
setblock 408 220 244 minecraft:lime_terracotta
fill 408 220 245 408 228 247 minecraft:green_terracotta
setblock 408 220 248 minecraft:lime_terracotta
fill 408 220 249 408 220 251 minecraft:green_terracotta
setblock 408 220 252 minecraft:lime_terracotta
setblock 409 220 270 minecraft:lime_terracotta
fill 410 220 270 410 222 270 minecraft:green_terracotta
setblock 413 220 228 minecraft:lime_terracotta
fill 413 220 270 413 222 270 minecraft:green_terracotta
setblock 414 220 270 minecraft:lime_terracotta
fill 415 220 270 416 220 270 minecraft:green_terracotta
setblock 416 220 247 minecraft:green_wool
fill 418 220 233 418 222 233 minecraft:green_terracotta
fill 418 220 245 418 222 245 minecraft:green_terracotta
fill 418 220 247 418 223 247 minecraft:green_terracotta
fill 418 220 249 418 222 249 minecraft:green_terracotta
setblock 418 220 262 minecraft:lime_terracotta
fill 418 220 263 418 222 263 minecraft:green_terracotta
setblock 418 220 265 minecraft:lime_terracotta
fill 376 221 235 376 222 235 minecraft:green_terracotta
fill 376 221 250 376 223 250 minecraft:green_terracotta
setblock 376 221 253 minecraft:lime_terracotta
setblock 376 221 258 minecraft:lime_terracotta
fill 376 221 262 376 223 262 minecraft:green_terracotta
setblock 376 221 267 minecraft:jungle_leaves[persistent=true]
fill 376 221 269 376 222 270 minecraft:green_terracotta
fill 377 221 229 384 221 269 minecraft:oak_leaves[persistent=true]
fill 378 221 270 378 223 270 minecraft:green_terracotta
setblock 380 221 270 minecraft:lime_terracotta
fill 381 221 228 381 222 228 minecraft:green_terracotta
setblock 382 221 228 minecraft:lime_terracotta
fill 385 221 229 385 221 245 minecraft:oak_leaves[persistent=true]
fill 385 221 246 385 221 247 minecraft:green_terracotta
setblock 385 221 248 minecraft:lime_terracotta
fill 385 221 249 385 222 250 minecraft:green_terracotta
fill 385 221 251 385 221 269 minecraft:oak_leaves[persistent=true]
fill 385 221 270 386 222 270 minecraft:green_terracotta
setblock 386 221 228 minecraft:lime_terracotta
fill 386 221 229 386 221 241 minecraft:oak_leaves[persistent=true]
fill 386 221 242 386 221 244 minecraft:green_terracotta
setblock 386 221 245 minecraft:lime_terracotta
fill 386 221 246 386 226 246 minecraft:green_terracotta
fill 386 221 250 386 230 250 minecraft:green_terracotta
setblock 386 221 253 minecraft:lime_terracotta
fill 386 221 254 387 228 254 minecraft:green_terracotta
fill 386 221 255 386 221 269 minecraft:oak_leaves[persistent=true]
fill 387 221 229 387 221 239 minecraft:oak_leaves[persistent=true]
fill 387 221 240 388 224 240 minecraft:green_terracotta
fill 387 221 243 387 226 243 minecraft:green_terracotta
fill 387 221 255 387 230 256 minecraft:green_terracotta
fill 387 221 257 387 221 269 minecraft:oak_leaves[persistent=true]
fill 388 221 229 388 221 237 minecraft:oak_leaves[persistent=true]
fill 388 221 238 388 222 238 minecraft:brown_terracotta
fill 388 221 250 389 221 250 minecraft:smooth_sandstone
fill 388 221 251 388 221 253 minecraft:ochre_froglight
fill 388 221 254 389 221 254 minecraft:smooth_sandstone
fill 388 221 256 389 229 256 minecraft:green_terracotta
setblock 388 221 258 minecraft:green_terracotta
fill 388 221 259 388 221 269 minecraft:oak_leaves[persistent=true]
fill 389 221 229 389 221 236 minecraft:oak_leaves[persistent=true]
setblock 389 221 237 minecraft:brown_terracotta
fill 389 221 238 389 225 238 minecraft:green_terracotta
fill 389 221 248 389 222 248 minecraft:green_terracotta
setblock 389 221 249 minecraft:ochre_froglight
setblock 389 221 255 minecraft:ochre_froglight
fill 389 221 257 389 228 257 minecraft:green_terracotta
fill 389 221 259 389 225 259 minecraft:green_terracotta
fill 389 221 260 389 221 269 minecraft:oak_leaves[persistent=true]
fill 389 221 270 390 222 270 minecraft:green_terracotta
fill 390 221 229 390 221 235 minecraft:oak_leaves[persistent=true]
setblock 390 221 236 minecraft:brown_terracotta
fill 390 221 237 390 232 237 minecraft:green_terracotta
fill 390 221 248 390 221 249 minecraft:smooth_sandstone
fill 390 221 255 390 221 256 minecraft:smooth_sandstone
fill 390 221 260 390 232 260 minecraft:green_terracotta
fill 390 221 261 390 221 269 minecraft:oak_leaves[persistent=true]
setblock 391 221 228 minecraft:lime_terracotta
fill 391 221 229 391 221 234 minecraft:oak_leaves[persistent=true]
setblock 391 221 235 minecraft:brown_terracotta
fill 391 221 236 391 224 236 minecraft:green_terracotta
fill 391 221 246 391 221 247 minecraft:green_terracotta
fill 391 221 248 393 221 248 minecraft:ochre_froglight
fill 391 221 256 393 221 256 minecraft:ochre_froglight
fill 391 221 261 391 224 261 minecraft:green_terracotta
fill 391 221 262 391 221 269 minecraft:oak_leaves[persistent=true]
fill 392 221 229 394 221 233 minecraft:oak_leaves[persistent=true]
fill 392 221 234 394 221 234 minecraft:brown_terracotta
fill 392 221 235 393 223 235 minecraft:green_terracotta
setblock 392 221 247 minecraft:red_terracotta
fill 392 221 262 394 221 262 minecraft:green_terracotta
fill 392 221 263 394 221 269 minecraft:oak_leaves[persistent=true]
fill 393 221 261 393 226 261 minecraft:green_terracotta
fill 394 221 248 394 221 249 minecraft:smooth_sandstone
fill 394 221 255 394 221 256 minecraft:smooth_sandstone
fill 395 221 229 417 222 232 minecraft:oak_leaves[persistent=true]
fill 395 221 233 399 222 233 minecraft:brown_terracotta
fill 395 221 234 399 223 234 minecraft:green_terracotta
setblock 395 221 249 minecraft:ochre_froglight
fill 395 221 250 396 221 250 minecraft:smooth_sandstone
fill 395 221 254 396 221 254 minecraft:smooth_sandstone
setblock 395 221 255 minecraft:ochre_froglight
fill 395 221 263 395 225 263 minecraft:green_terracotta
fill 395 221 264 417 222 269 minecraft:oak_leaves[persistent=true]
fill 396 221 228 397 222 228 minecraft:green_terracotta
fill 396 221 251 396 221 253 minecraft:ochre_froglight
setblock 396 221 255 minecraft:green_terracotta
setblock 396 221 263 minecraft:lime_terracotta
setblock 396 221 270 minecraft:lime_terracotta
fill 397 221 263 399 221 263 minecraft:green_terracotta
fill 398 221 262 398 226 262 minecraft:green_terracotta
setblock 399 221 228 minecraft:lime_terracotta
fill 400 221 233 417 221 233 minecraft:oak_leaves[persistent=true]
fill 400 221 234 402 221 234 minecraft:brown_terracotta
fill 400 221 263 417 221 263 minecraft:oak_leaves[persistent=true]
setblock 401 221 228 minecraft:lime_terracotta
fill 401 221 235 402 223 235 minecraft:green_terracotta
fill 401 221 261 401 221 262 minecraft:green_terracotta
setblock 401 221 270 minecraft:lime_terracotta
fill 402 221 262 402 223 262 minecraft:green_terracotta
fill 403 221 234 417 221 234 minecraft:oak_leaves[persistent=true]
setblock 403 221 235 minecraft:brown_terracotta
fill 403 221 236 403 224 236 minecraft:green_terracotta
fill 403 221 261 403 224 261 minecraft:green_terracotta
fill 403 221 262 417 221 262 minecraft:oak_leaves[persistent=true]
fill 404 221 235 417 221 235 minecraft:oak_leaves[persistent=true]
setblock 404 221 236 minecraft:brown_terracotta
fill 404 221 237 404 225 237 minecraft:green_terracotta
fill 404 221 260 404 226 260 minecraft:green_terracotta
fill 404 221 261 417 221 261 minecraft:oak_leaves[persistent=true]
fill 405 221 236 417 221 236 minecraft:oak_leaves[persistent=true]
setblock 405 221 237 minecraft:brown_terracotta
fill 405 221 238 405 225 238 minecraft:green_terracotta
fill 405 221 259 405 225 259 minecraft:green_terracotta
fill 405 221 260 417 221 260 minecraft:oak_leaves[persistent=true]
fill 406 221 237 417 221 237 minecraft:oak_leaves[persistent=true]
fill 406 221 238 406 222 238 minecraft:brown_terracotta
setblock 406 221 257 minecraft:lime_terracotta
fill 406 221 258 406 224 258 minecraft:green_terracotta
fill 406 221 259 417 221 259 minecraft:oak_leaves[persistent=true]
fill 406 221 270 407 222 270 minecraft:green_terracotta
fill 407 221 238 417 221 239 minecraft:oak_leaves[persistent=true]
fill 407 221 240 407 230 240 minecraft:green_terracotta
fill 407 221 243 407 233 243 minecraft:green_terracotta
fill 407 221 255 407 225 256 minecraft:green_terracotta
fill 407 221 257 417 221 258 minecraft:oak_leaves[persistent=true]
fill 408 221 240 417 221 241 minecraft:oak_leaves[persistent=true]
setblock 408 221 242 minecraft:green_terracotta
setblock 408 221 243 minecraft:lime_terracotta
fill 408 221 244 408 231 244 minecraft:green_terracotta
fill 408 221 248 408 229 250 minecraft:green_terracotta
setblock 408 221 251 minecraft:lime_terracotta
fill 408 221 252 408 221 254 minecraft:green_terracotta
fill 408 221 255 417 221 256 minecraft:oak_leaves[persistent=true]
setblock 408 221 270 minecraft:lime_terracotta
fill 409 221 242 417 221 245 minecraft:oak_leaves[persistent=true]
fill 409 221 246 409 221 247 minecraft:green_terracotta
setblock 409 221 248 minecraft:lime_terracotta
fill 409 221 249 409 222 250 minecraft:green_terracotta
fill 409 221 251 417 221 254 minecraft:oak_leaves[persistent=true]
fill 409 221 270 409 222 270 minecraft:green_terracotta
fill 410 221 246 417 222 250 minecraft:oak_leaves[persistent=true]
fill 413 221 228 413 222 228 minecraft:green_terracotta
fill 414 221 270 415 222 270 minecraft:green_terracotta
setblock 416 221 270 minecraft:lime_terracotta
schedule function dropper:buildpart/56_3 1t
