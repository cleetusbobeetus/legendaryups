fill 313 181 315 313 182 316 minecraft:iron_block
fill 314 181 311 318 181 311 minecraft:light_gray_concrete
fill 318 181 282 318 181 310 minecraft:light_gray_concrete
fill 282 182 295 282 192 295 minecraft:gray_concrete
fill 298 182 313 299 183 316 minecraft:iron_block
fill 299 182 309 299 183 312 minecraft:iron_block
fill 302 182 317 302 192 317 minecraft:gray_concrete
fill 307 182 276 308 182 281 minecraft:iron_block
fill 308 182 282 309 182 288 minecraft:iron_block
fill 309 182 275 311 192 275 minecraft:gray_concrete
fill 309 182 289 310 182 295 minecraft:iron_block
fill 310 182 297 310 182 301 minecraft:iron_block
fill 311 182 296 311 182 299 minecraft:iron_block
fill 311 182 307 311 182 308 minecraft:iron_block
setblock 312 182 275 minecraft:sea_lantern
fill 312 182 302 312 182 304 minecraft:iron_block
fill 313 182 309 313 182 310 minecraft:iron_block
fill 315 182 312 315 182 314 minecraft:iron_block
fill 316 182 312 317 182 312 minecraft:iron_block
fill 316 182 314 317 182 314 minecraft:iron_block
setblock 317 182 313 minecraft:iron_block
fill 282 183 285 282 192 286 minecraft:gray_concrete
setblock 282 183 287 minecraft:sea_lantern
fill 298 183 306 298 183 312 minecraft:iron_block
fill 299 183 297 299 184 308 minecraft:iron_block
fill 307 183 276 308 183 280 minecraft:iron_block
fill 308 183 281 308 183 286 minecraft:iron_block
fill 309 183 284 309 183 291 minecraft:iron_block
fill 310 183 293 310 183 295 minecraft:iron_block
fill 310 183 296 310 183 298 minecraft:light_gray_concrete
fill 311 183 299 311 183 305 minecraft:light_gray_concrete
fill 312 183 275 312 192 275 minecraft:gray_concrete
fill 312 183 306 312 183 312 minecraft:light_gray_concrete
fill 313 183 312 313 183 316 minecraft:light_gray_concrete
fill 282 184 281 282 184 284 minecraft:pearlescent_froglight
fill 282 184 287 282 189 287 minecraft:gray_concrete
fill 282 184 291 282 184 294 minecraft:pearlescent_froglight
fill 282 184 301 282 184 304 minecraft:pearlescent_froglight
fill 282 184 311 282 184 314 minecraft:pearlescent_froglight
fill 285 184 275 288 184 275 minecraft:pearlescent_froglight
setblock 285 184 278 minecraft:light[level=15]
setblock 285 184 286 minecraft:light[level=15]
setblock 285 184 294 minecraft:light[level=15]
setblock 285 184 302 minecraft:light[level=15]
fill 285 184 309 285 185 309 minecraft:gray_concrete
setblock 285 184 310 minecraft:light[level=15]
fill 286 184 317 289 184 317 minecraft:pearlescent_froglight
fill 289 184 275 291 190 275 minecraft:gray_concrete
setblock 292 184 275 minecraft:sea_lantern
fill 293 184 275 294 192 275 minecraft:gray_concrete
setblock 293 184 278 minecraft:light[level=15]
setblock 293 184 286 minecraft:light[level=15]
setblock 293 184 294 minecraft:light[level=15]
setblock 293 184 302 minecraft:light[level=15]
setblock 293 184 310 minecraft:light[level=15]
fill 294 184 282 294 185 282 minecraft:gray_concrete
fill 295 184 275 298 184 275 minecraft:pearlescent_froglight
fill 296 184 317 299 184 317 minecraft:pearlescent_froglight
fill 298 184 309 299 185 309 minecraft:gray_concrete
fill 299 184 286 300 185 291 minecraft:iron_block
fill 299 184 310 299 184 315 minecraft:light_gray_concrete
fill 300 184 283 300 185 285 minecraft:iron_block
fill 300 184 298 300 184 301 minecraft:iron_block
setblock 301 184 278 minecraft:light[level=15]
setblock 301 184 286 minecraft:light[level=15]
setblock 301 184 302 minecraft:light[level=15]
setblock 301 184 310 minecraft:light[level=15]
fill 303 184 317 305 192 317 minecraft:gray_concrete
fill 305 184 275 308 184 275 minecraft:pearlescent_froglight
fill 306 184 317 309 184 317 minecraft:pearlescent_froglight
fill 307 184 276 307 184 278 minecraft:light_gray_concrete
fill 308 184 279 308 184 284 minecraft:light_gray_concrete
setblock 309 184 278 minecraft:light[level=15]
fill 309 184 286 309 184 290 minecraft:light_gray_concrete
setblock 309 184 294 minecraft:light[level=15]
setblock 309 184 302 minecraft:light[level=15]
setblock 309 184 310 minecraft:light[level=15]
setblock 313 184 275 minecraft:redstone_block
fill 315 184 275 318 184 275 minecraft:pearlescent_froglight
fill 316 184 279 316 185 279 minecraft:gray_concrete
fill 316 184 312 316 185 312 minecraft:gray_concrete
fill 316 184 317 319 184 317 minecraft:pearlescent_froglight
setblock 317 184 286 minecraft:light[level=15]
setblock 317 184 294 minecraft:light[level=15]
setblock 317 184 302 minecraft:light[level=15]
setblock 317 184 310 minecraft:light[level=15]
fill 318 184 309 318 185 309 minecraft:gray_concrete
fill 324 184 276 324 184 279 minecraft:pearlescent_froglight
fill 324 184 286 324 184 289 minecraft:pearlescent_froglight
fill 324 184 296 324 184 299 minecraft:pearlescent_froglight
fill 324 184 306 324 184 309 minecraft:pearlescent_froglight
setblock 324 184 316 minecraft:pearlescent_froglight
fill 282 185 281 282 192 284 minecraft:gray_concrete
fill 282 185 291 282 188 294 minecraft:gray_concrete
fill 282 185 301 282 191 304 minecraft:gray_concrete
setblock 282 185 311 minecraft:redstone_block
fill 282 185 312 282 192 314 minecraft:gray_concrete
fill 285 185 275 288 192 275 minecraft:gray_concrete
fill 285 185 310 285 186 310 minecraft:gray_concrete
fill 286 185 317 289 192 317 minecraft:gray_concrete
fill 292 185 275 292 192 275 minecraft:gray_concrete
fill 294 185 281 294 186 281 minecraft:gray_concrete
fill 295 185 275 298 192 275 minecraft:gray_concrete
fill 296 185 317 299 192 317 minecraft:gray_concrete
fill 298 185 310 299 186 310 minecraft:gray_concrete
fill 299 185 278 299 185 285 minecraft:iron_block
fill 299 185 297 299 185 307 minecraft:light_gray_concrete
fill 300 185 277 300 185 282 minecraft:iron_block
fill 305 185 275 308 192 275 minecraft:gray_concrete
fill 306 185 317 309 192 317 minecraft:gray_concrete
fill 313 185 275 313 192 275 minecraft:gray_concrete
fill 315 185 275 318 192 275 minecraft:gray_concrete
fill 316 185 278 320 185 278 minecraft:iron_block
fill 316 185 280 320 185 280 minecraft:iron_block
fill 316 185 317 319 192 317 minecraft:gray_concrete
fill 317 185 277 319 185 277 minecraft:iron_block
fill 317 185 279 317 186 279 minecraft:gray_concrete
fill 317 185 281 319 185 281 minecraft:iron_block
fill 317 185 312 317 186 312 minecraft:gray_concrete
fill 318 185 279 320 185 279 minecraft:iron_block
fill 318 185 310 318 186 310 minecraft:gray_concrete
setblock 319 185 275 minecraft:sea_lantern
fill 320 185 275 322 192 275 minecraft:gray_concrete
fill 324 185 276 324 185 279 minecraft:gray_concrete
fill 324 185 286 324 192 289 minecraft:gray_concrete
fill 324 185 296 324 192 299 minecraft:gray_concrete
setblock 324 185 306 minecraft:sea_lantern
fill 324 185 307 324 185 309 minecraft:gray_concrete
fill 324 185 316 324 192 316 minecraft:gray_concrete
setblock 282 186 288 minecraft:sea_lantern
fill 282 186 311 282 192 311 minecraft:gray_concrete
setblock 283 186 278 minecraft:iron_block
setblock 283 186 288 minecraft:iron_block
setblock 283 186 298 minecraft:iron_block
setblock 283 186 308 minecraft:iron_block
fill 284 186 312 284 186 313 minecraft:gray_concrete
setblock 285 186 278 minecraft:light[level=12]
setblock 285 186 285 minecraft:light[level=12]
setblock 285 186 292 minecraft:light[level=12]
setblock 285 186 299 minecraft:light[level=12]
setblock 285 186 306 minecraft:light[level=12]
fill 285 186 311 285 187 311 minecraft:gray_concrete
setblock 285 186 314 minecraft:gray_concrete
setblock 285 186 316 minecraft:iron_block
fill 286 186 310 287 186 310 minecraft:gray_concrete
setblock 288 186 311 minecraft:gray_concrete
setblock 288 186 314 minecraft:gray_concrete
setblock 289 186 276 minecraft:iron_block
setblock 292 186 278 minecraft:light[level=12]
setblock 292 186 285 minecraft:light[level=12]
setblock 292 186 292 minecraft:light[level=12]
setblock 292 186 299 minecraft:light[level=12]
setblock 292 186 306 minecraft:light[level=12]
setblock 292 186 313 minecraft:light[level=12]
fill 294 186 280 294 187 280 minecraft:gray_concrete
setblock 295 186 316 minecraft:iron_block
fill 298 186 311 299 187 311 minecraft:gray_concrete
setblock 299 186 276 minecraft:iron_block
setblock 299 186 278 minecraft:light[level=12]
setblock 299 186 285 minecraft:light[level=12]
fill 299 186 290 299 186 291 minecraft:light_gray_concrete
setblock 299 186 292 minecraft:light[level=12]
setblock 299 186 299 minecraft:light[level=12]
setblock 299 186 306 minecraft:light[level=12]
setblock 299 186 313 minecraft:light[level=12]
fill 300 186 277 300 186 281 minecraft:iron_block
fill 300 186 282 300 186 290 minecraft:light_gray_concrete
setblock 305 186 316 minecraft:iron_block
setblock 306 186 278 minecraft:light[level=12]
setblock 306 186 285 minecraft:light[level=12]
setblock 306 186 292 minecraft:light[level=12]
setblock 306 186 299 minecraft:light[level=12]
setblock 306 186 306 minecraft:light[level=12]
setblock 306 186 313 minecraft:light[level=12]
setblock 309 186 276 minecraft:iron_block
setblock 313 186 278 minecraft:light[level=12]
setblock 313 186 285 minecraft:light[level=12]
setblock 313 186 292 minecraft:light[level=12]
setblock 313 186 299 minecraft:light[level=12]
setblock 313 186 306 minecraft:light[level=12]
setblock 313 186 313 minecraft:light[level=12]
setblock 315 186 316 minecraft:iron_block
fill 317 186 278 319 208 278 minecraft:iron_block
fill 317 186 280 319 208 280 minecraft:iron_block
fill 318 186 279 318 187 279 minecraft:gray_concrete
fill 318 186 311 318 187 312 minecraft:gray_concrete
fill 319 186 275 319 192 275 minecraft:gray_concrete
setblock 319 186 276 minecraft:iron_block
setblock 319 186 279 minecraft:iron_block
setblock 320 186 278 minecraft:light[level=12]
setblock 320 186 285 minecraft:light[level=12]
setblock 320 186 292 minecraft:light[level=12]
setblock 320 186 299 minecraft:light[level=12]
setblock 320 186 306 minecraft:light[level=12]
setblock 320 186 313 minecraft:light[level=12]
setblock 323 186 282 minecraft:iron_block
setblock 323 186 292 minecraft:iron_block
setblock 323 186 302 minecraft:iron_block
setblock 323 186 312 minecraft:iron_block
setblock 324 186 276 minecraft:redstone_block
fill 324 186 277 324 192 279 minecraft:gray_concrete
fill 324 186 300 324 192 304 minecraft:gray_concrete
setblock 324 186 305 minecraft:sea_lantern
fill 324 186 306 324 192 308 minecraft:gray_concrete
setblock 324 186 309 minecraft:redstone_block
fill 282 187 288 282 192 288 minecraft:gray_concrete
fill 285 187 312 285 188 312 minecraft:gray_concrete
fill 285 187 313 288 187 313 minecraft:iron_block
fill 286 187 312 288 208 312 minecraft:iron_block
fill 294 187 279 294 188 279 minecraft:gray_concrete
fill 298 187 312 299 188 312 minecraft:gray_concrete
fill 300 187 277 300 187 281 minecraft:light_gray_concrete
fill 317 187 279 317 208 279 minecraft:iron_block
fill 319 187 279 319 188 279 minecraft:gray_concrete
fill 319 187 312 319 188 312 minecraft:gray_concrete
fill 324 187 276 324 192 276 minecraft:gray_concrete
fill 324 187 305 324 192 305 minecraft:gray_concrete
fill 324 187 309 324 192 309 minecraft:gray_concrete
fill 285 188 313 285 189 313 minecraft:gray_concrete
fill 286 188 313 288 208 313 minecraft:iron_block
fill 290 188 317 293 192 317 minecraft:gray_concrete
fill 294 188 278 294 189 278 minecraft:gray_concrete
setblock 294 188 317 minecraft:redstone_block
fill 295 188 317 295 192 317 minecraft:gray_concrete
fill 298 188 313 299 189 313 minecraft:gray_concrete
fill 318 188 279 318 208 279 minecraft:iron_block
fill 318 188 312 318 188 313 minecraft:gray_concrete
fill 320 188 279 320 189 279 minecraft:gray_concrete
fill 320 188 312 320 189 312 minecraft:gray_concrete
fill 282 189 291 282 192 293 minecraft:gray_concrete
setblock 282 189 294 minecraft:sea_lantern
fill 283 189 280 283 189 283 minecraft:iron_block
fill 283 189 290 283 189 293 minecraft:iron_block
fill 283 189 300 283 189 303 minecraft:iron_block
fill 283 189 310 283 189 313 minecraft:iron_block
fill 284 189 276 287 189 276 minecraft:iron_block
fill 285 189 312 285 208 312 minecraft:iron_block
fill 285 189 314 285 190 314 minecraft:gray_concrete
fill 287 189 316 290 189 316 minecraft:iron_block
fill 294 189 276 297 189 276 minecraft:iron_block
fill 294 189 277 294 190 277 minecraft:gray_concrete
fill 294 189 317 294 192 317 minecraft:gray_concrete
fill 297 189 316 300 189 316 minecraft:iron_block
fill 298 189 314 299 190 314 minecraft:gray_concrete
fill 304 189 276 307 189 276 minecraft:iron_block
fill 307 189 316 310 189 316 minecraft:iron_block
fill 314 189 276 317 189 276 minecraft:iron_block
fill 315 189 312 315 189 314 minecraft:iron_block
fill 316 189 312 317 189 312 minecraft:iron_block
fill 316 189 314 317 189 314 minecraft:iron_block
setblock 317 189 313 minecraft:iron_block
fill 317 189 316 320 189 316 minecraft:iron_block
fill 318 189 303 318 198 303 minecraft:iron_block
fill 318 189 313 318 189 314 minecraft:gray_concrete
fill 319 189 279 319 208 279 minecraft:iron_block
fill 321 189 279 321 190 279 minecraft:gray_concrete
fill 321 189 312 321 190 312 minecraft:gray_concrete
fill 323 189 277 323 189 280 minecraft:iron_block
fill 323 189 287 323 189 290 minecraft:iron_block
fill 323 189 297 323 189 300 minecraft:iron_block
fill 323 189 307 323 189 310 minecraft:iron_block
setblock 282 190 287 minecraft:sea_lantern
fill 282 190 294 282 192 294 minecraft:gray_concrete
fill 285 190 313 285 208 313 minecraft:iron_block
fill 285 190 315 285 191 315 minecraft:gray_concrete
fill 294 190 276 294 191 276 minecraft:gray_concrete
fill 298 190 315 299 191 315 minecraft:gray_concrete
fill 316 190 278 316 190 280 minecraft:iron_block
fill 317 190 277 319 190 277 minecraft:iron_block
fill 317 190 281 319 190 281 minecraft:iron_block
fill 318 190 314 318 190 315 minecraft:gray_concrete
fill 320 190 278 320 190 280 minecraft:iron_block
fill 322 190 279 322 191 279 minecraft:gray_concrete
fill 322 190 312 322 191 312 minecraft:gray_concrete
fill 282 191 287 282 192 287 minecraft:gray_concrete
fill 289 191 275 289 192 275 minecraft:gray_concrete
setblock 289 191 286 minecraft:pearlescent_froglight
setblock 289 191 292 minecraft:pearlescent_froglight
setblock 289 191 298 minecraft:pearlescent_froglight
setblock 289 191 304 minecraft:pearlescent_froglight
setblock 289 191 310 minecraft:pearlescent_froglight
setblock 290 191 275 minecraft:redstone_block
fill 291 191 275 291 192 275 minecraft:gray_concrete
setblock 293 191 282 minecraft:pearlescent_froglight
setblock 295 191 310 minecraft:pearlescent_froglight
setblock 299 191 282 minecraft:pearlescent_froglight
setblock 301 191 310 minecraft:pearlescent_froglight
setblock 305 191 282 minecraft:pearlescent_froglight
setblock 307 191 310 minecraft:pearlescent_froglight
setblock 311 191 282 minecraft:pearlescent_froglight
setblock 313 191 310 minecraft:pearlescent_froglight
setblock 317 191 282 minecraft:pearlescent_froglight
setblock 317 191 288 minecraft:pearlescent_froglight
setblock 317 191 294 minecraft:pearlescent_froglight
setblock 317 191 300 minecraft:pearlescent_froglight
setblock 317 191 306 minecraft:pearlescent_froglight
setblock 318 191 315 minecraft:gray_concrete
fill 282 192 301 282 192 303 minecraft:gray_concrete
setblock 282 192 304 minecraft:redstone_block
fill 282 192 305 282 192 309 minecraft:gray_concrete
setblock 282 192 310 minecraft:redstone_block
setblock 283 192 276 minecraft:iron_block
fill 283 192 278 283 192 279 minecraft:iron_block
fill 283 192 281 283 192 282 minecraft:iron_block
fill 283 192 284 283 192 285 minecraft:iron_block
setblock 283 192 288 minecraft:iron_block
fill 283 192 290 283 192 291 minecraft:iron_block
fill 283 192 293 283 192 294 minecraft:iron_block
fill 283 192 296 284 192 296 minecraft:iron_block
fill 283 192 298 283 192 300 minecraft:iron_block
fill 283 192 302 283 192 303 minecraft:iron_block
fill 283 192 305 283 192 306 minecraft:iron_block
fill 283 192 308 283 192 309 minecraft:iron_block
fill 283 192 311 283 192 312 minecraft:iron_block
fill 283 192 314 283 192 315 minecraft:iron_block
fill 284 192 277 284 192 278 minecraft:iron_block
fill 284 192 280 284 192 281 minecraft:iron_block
fill 284 192 283 284 192 284 minecraft:iron_block
fill 284 192 286 284 192 287 minecraft:iron_block
fill 284 192 289 284 192 290 minecraft:iron_block
fill 284 192 292 284 192 293 minecraft:iron_block
fill 284 192 295 285 192 295 minecraft:iron_block
fill 284 192 298 284 192 299 minecraft:iron_block
fill 284 192 301 284 192 302 minecraft:iron_block
fill 284 192 304 284 192 305 minecraft:iron_block
fill 284 192 307 284 192 308 minecraft:iron_block
fill 284 192 310 284 192 311 minecraft:iron_block
fill 284 192 313 284 192 314 minecraft:iron_block
fill 285 192 276 285 192 277 minecraft:iron_block
setblock 285 192 278 minecraft:light[level=15]
fill 285 192 279 285 192 280 minecraft:iron_block
fill 285 192 282 285 192 283 minecraft:iron_block
fill 285 192 285 285 192 286 minecraft:iron_block
fill 285 192 288 285 192 289 minecraft:iron_block
fill 285 192 291 285 192 292 minecraft:iron_block
fill 285 192 294 286 192 294 minecraft:iron_block
fill 285 192 297 285 192 298 minecraft:iron_block
setblock 285 192 299 minecraft:light[level=12]
fill 285 192 300 285 192 301 minecraft:iron_block
setblock 285 192 302 minecraft:light[level=15]
fill 285 192 303 285 192 304 minecraft:iron_block
fill 285 192 306 285 192 307 minecraft:iron_block
fill 285 192 309 285 192 310 minecraft:iron_block
fill 285 192 315 285 192 316 minecraft:iron_block
setblock 286 192 276 minecraft:iron_block
fill 286 192 278 286 192 279 minecraft:iron_block
fill 286 192 281 286 192 282 minecraft:iron_block
fill 286 192 284 286 192 285 minecraft:iron_block
fill 286 192 287 286 192 288 minecraft:iron_block
fill 286 192 290 286 192 291 minecraft:iron_block
fill 286 192 293 287 192 293 minecraft:iron_block
fill 286 192 296 286 192 297 minecraft:iron_block
fill 286 192 299 286 192 300 minecraft:iron_block
fill 286 192 302 286 192 303 minecraft:iron_block
fill 286 192 305 286 192 306 minecraft:iron_block
fill 286 192 308 286 192 309 minecraft:iron_block
fill 286 192 315 286 194 315 minecraft:iron_block
fill 287 192 277 287 192 278 minecraft:iron_block
fill 287 192 280 287 192 281 minecraft:iron_block
fill 287 192 283 287 192 284 minecraft:iron_block
fill 287 192 286 287 192 287 minecraft:iron_block
fill 287 192 289 287 192 290 minecraft:iron_block
fill 287 192 292 288 192 292 minecraft:iron_block
fill 287 192 295 287 192 296 minecraft:iron_block
fill 287 192 298 287 192 299 minecraft:iron_block
fill 287 192 301 287 192 302 minecraft:iron_block
fill 287 192 304 287 192 305 minecraft:iron_block
fill 287 192 307 287 192 308 minecraft:iron_block
fill 287 192 310 288 192 310 minecraft:iron_block
fill 287 192 316 288 192 316 minecraft:iron_block
fill 288 192 276 288 192 277 minecraft:iron_block
fill 288 192 279 288 192 280 minecraft:iron_block
fill 288 192 282 288 192 283 minecraft:iron_block
fill 288 192 285 288 192 286 minecraft:iron_block
fill 288 192 288 288 192 289 minecraft:iron_block
fill 288 192 291 289 192 291 minecraft:iron_block
fill 288 192 294 288 192 295 minecraft:iron_block
fill 288 192 297 288 192 298 minecraft:iron_block
fill 288 192 300 288 192 301 minecraft:iron_block
fill 288 192 303 288 192 304 minecraft:iron_block
fill 288 192 306 288 192 307 minecraft:iron_block
fill 288 192 309 289 192 309 minecraft:iron_block
fill 288 192 315 289 192 315 minecraft:iron_block
setblock 289 192 276 minecraft:iron_block
fill 289 192 278 289 192 279 minecraft:iron_block
fill 289 192 281 289 192 282 minecraft:iron_block
fill 289 192 284 289 192 285 minecraft:iron_block
fill 289 192 287 289 192 288 minecraft:iron_block
setblock 289 192 290 minecraft:iron_block
fill 289 192 293 289 192 294 minecraft:iron_block
fill 289 192 296 289 192 297 minecraft:iron_block
fill 289 192 299 289 192 300 minecraft:iron_block
fill 289 192 302 289 192 303 minecraft:iron_block
fill 289 192 305 289 192 306 minecraft:iron_block
setblock 289 192 308 minecraft:iron_block
fill 289 192 311 289 192 312 minecraft:iron_block
fill 289 192 314 290 192 314 minecraft:iron_block
setblock 290 192 275 minecraft:gray_concrete
fill 290 192 277 290 192 278 minecraft:iron_block
fill 290 192 280 290 192 281 minecraft:iron_block
fill 290 192 310 290 192 311 minecraft:iron_block
fill 290 192 313 291 192 313 minecraft:iron_block
fill 290 192 316 291 192 316 minecraft:iron_block
fill 291 192 276 291 192 277 minecraft:iron_block
fill 291 192 279 291 192 280 minecraft:iron_block
fill 291 192 282 292 192 282 minecraft:iron_block
setblock 291 192 310 minecraft:iron_block
fill 291 192 312 292 192 312 minecraft:iron_block
fill 291 192 315 292 192 315 minecraft:iron_block
setblock 292 192 276 minecraft:iron_block
fill 292 192 278 292 192 279 minecraft:iron_block
fill 292 192 281 293 192 281 minecraft:iron_block
setblock 292 192 285 minecraft:light[level=12]
setblock 292 192 292 minecraft:light[level=12]
setblock 292 192 299 minecraft:light[level=12]
setblock 292 192 306 minecraft:light[level=12]
fill 292 192 311 293 192 311 minecraft:iron_block
setblock 292 192 313 minecraft:light[level=12]
fill 292 192 314 293 192 314 minecraft:iron_block
fill 293 192 277 293 192 278 minecraft:iron_block
fill 293 192 280 294 192 280 minecraft:iron_block
setblock 293 192 286 minecraft:light[level=15]
setblock 293 192 294 minecraft:light[level=15]
setblock 293 192 302 minecraft:light[level=15]
fill 293 192 310 294 192 310 minecraft:iron_block
fill 293 192 313 294 192 313 minecraft:iron_block
setblock 293 192 316 minecraft:iron_block
fill 294 192 276 294 192 277 minecraft:iron_block
fill 294 192 279 295 192 279 minecraft:iron_block
fill 294 192 282 295 192 282 minecraft:iron_block
fill 294 192 312 295 192 312 minecraft:iron_block
fill 294 192 315 295 192 315 minecraft:iron_block
setblock 295 192 276 minecraft:iron_block
fill 295 192 278 296 192 278 minecraft:iron_block
fill 295 192 281 296 192 281 minecraft:iron_block
fill 295 192 311 296 192 311 minecraft:iron_block
fill 295 192 314 296 192 314 minecraft:iron_block
fill 295 192 316 297 192 316 minecraft:iron_block
fill 296 192 277 297 192 277 minecraft:iron_block
fill 296 192 280 297 192 280 minecraft:iron_block
fill 296 192 310 297 192 310 minecraft:iron_block
fill 296 192 313 297 192 313 minecraft:iron_block
fill 297 192 276 299 192 276 minecraft:iron_block
fill 297 192 279 298 192 279 minecraft:iron_block
fill 297 192 282 298 192 282 minecraft:iron_block
fill 297 192 312 298 192 312 minecraft:iron_block
fill 297 192 315 298 192 315 minecraft:iron_block
fill 298 192 278 299 192 278 minecraft:iron_block
fill 298 192 281 299 192 281 minecraft:iron_block
fill 298 192 311 299 192 311 minecraft:iron_block
fill 298 192 314 299 192 314 minecraft:iron_block
fill 299 192 277 300 192 277 minecraft:iron_block
fill 299 192 280 300 192 280 minecraft:iron_block
setblock 299 192 285 minecraft:light[level=12]
setblock 299 192 292 minecraft:light[level=12]
setblock 299 192 299 minecraft:light[level=12]
setblock 299 192 306 minecraft:light[level=12]
fill 299 192 310 300 192 310 minecraft:iron_block
fill 299 192 313 300 192 313 minecraft:iron_block
fill 299 192 316 300 192 316 minecraft:iron_block
fill 300 192 279 301 192 279 minecraft:iron_block
fill 300 192 282 301 192 282 minecraft:iron_block
fill 300 192 312 301 192 312 minecraft:iron_block
fill 300 192 315 301 192 315 minecraft:iron_block
setblock 301 192 276 minecraft:iron_block
fill 301 192 278 302 192 278 minecraft:iron_block
fill 301 192 281 302 192 281 minecraft:iron_block
setblock 301 192 286 minecraft:light[level=15]
setblock 301 192 302 minecraft:light[level=15]
setblock 301 192 310 minecraft:light[level=15]
fill 301 192 311 302 192 311 minecraft:iron_block
fill 301 192 314 302 192 314 minecraft:iron_block
fill 302 192 277 303 192 277 minecraft:iron_block
fill 302 192 280 303 192 280 minecraft:iron_block
fill 302 192 310 303 192 310 minecraft:iron_block
fill 302 192 313 303 192 313 minecraft:iron_block
fill 302 192 316 303 192 316 minecraft:iron_block
fill 303 192 276 304 192 276 minecraft:iron_block
fill 303 192 279 304 192 279 minecraft:iron_block
fill 303 192 282 304 192 282 minecraft:iron_block
fill 303 192 312 304 192 312 minecraft:iron_block
fill 303 192 315 304 192 315 minecraft:iron_block
fill 304 192 278 305 192 278 minecraft:iron_block
fill 304 192 281 305 192 281 minecraft:iron_block
fill 304 192 311 305 192 311 minecraft:iron_block
fill 304 192 314 305 192 314 minecraft:iron_block
fill 305 192 277 306 192 277 minecraft:iron_block
fill 305 192 280 306 192 280 minecraft:iron_block
fill 305 192 310 306 192 310 minecraft:iron_block
fill 305 192 313 306 192 313 minecraft:iron_block
fill 305 192 316 306 192 316 minecraft:iron_block
fill 306 192 276 307 192 276 minecraft:iron_block
setblock 306 192 278 minecraft:light[level=12]
fill 306 192 279 307 192 279 minecraft:iron_block
fill 306 192 282 307 192 282 minecraft:iron_block
setblock 306 192 285 minecraft:light[level=12]
setblock 306 192 292 minecraft:light[level=12]
setblock 306 192 299 minecraft:light[level=12]
setblock 306 192 306 minecraft:light[level=12]
fill 306 192 312 307 192 312 minecraft:iron_block
fill 306 192 315 307 192 315 minecraft:iron_block
fill 307 192 278 308 192 278 minecraft:iron_block
fill 307 192 281 308 192 281 minecraft:iron_block
fill 307 192 311 308 192 311 minecraft:iron_block
fill 307 192 314 308 192 314 minecraft:iron_block
fill 308 192 277 309 192 277 minecraft:iron_block
fill 308 192 280 309 192 280 minecraft:iron_block
fill 308 192 310 309 192 310 minecraft:iron_block
fill 308 192 313 309 192 313 minecraft:iron_block
fill 308 192 316 309 192 316 minecraft:iron_block
setblock 309 192 276 minecraft:iron_block
setblock 309 192 278 minecraft:light[level=15]
fill 309 192 279 310 192 279 minecraft:iron_block
fill 309 192 282 310 192 282 minecraft:iron_block
setblock 309 192 286 minecraft:light[level=15]
setblock 309 192 294 minecraft:light[level=15]
setblock 309 192 302 minecraft:light[level=15]
fill 309 192 312 310 192 312 minecraft:iron_block
fill 309 192 315 310 192 315 minecraft:iron_block
fill 310 192 278 311 192 278 minecraft:iron_block
fill 310 192 281 311 192 281 minecraft:iron_block
fill 310 192 311 311 192 311 minecraft:iron_block
fill 310 192 314 311 192 314 minecraft:iron_block
fill 311 192 277 312 192 277 minecraft:iron_block
fill 311 192 280 312 192 280 minecraft:iron_block
fill 311 192 310 312 192 310 minecraft:iron_block
fill 311 192 313 312 192 313 minecraft:iron_block
fill 311 192 316 312 192 316 minecraft:iron_block
fill 312 192 276 313 192 276 minecraft:iron_block
fill 312 192 279 313 192 279 minecraft:iron_block
fill 312 192 282 313 192 282 minecraft:iron_block
fill 312 192 312 313 192 312 minecraft:iron_block
fill 312 192 315 313 192 315 minecraft:iron_block
fill 313 192 278 314 192 278 minecraft:iron_block
fill 313 192 281 314 192 281 minecraft:iron_block
setblock 313 192 285 minecraft:light[level=12]
setblock 313 192 292 minecraft:light[level=12]
setblock 313 192 299 minecraft:light[level=12]
setblock 313 192 306 minecraft:light[level=12]
fill 313 192 311 314 192 311 minecraft:iron_block
setblock 313 192 313 minecraft:light[level=12]
fill 313 192 314 314 192 314 minecraft:iron_block
fill 314 192 277 315 192 277 minecraft:iron_block
fill 314 192 280 315 192 280 minecraft:iron_block
fill 314 192 310 315 192 310 minecraft:iron_block
fill 314 192 313 315 192 313 minecraft:iron_block
fill 315 192 276 316 192 276 minecraft:iron_block
fill 315 192 279 316 192 279 minecraft:iron_block
fill 315 192 282 316 192 282 minecraft:iron_block
fill 315 192 312 316 192 312 minecraft:iron_block
fill 315 192 315 315 192 316 minecraft:iron_block
setblock 316 192 278 minecraft:iron_block
fill 316 192 281 317 192 281 minecraft:iron_block
fill 316 192 311 317 192 311 minecraft:iron_block
fill 316 192 314 316 192 315 minecraft:iron_block
fill 317 192 277 318 192 277 minecraft:iron_block
fill 317 192 283 317 192 284 minecraft:iron_block
fill 317 192 286 317 192 287 minecraft:iron_block
fill 317 192 289 317 192 290 minecraft:iron_block
fill 317 192 292 317 192 293 minecraft:iron_block
setblock 317 192 294 minecraft:light[level=15]
fill 317 192 295 317 192 296 minecraft:iron_block
fill 317 192 298 317 192 299 minecraft:iron_block
fill 317 192 301 317 192 302 minecraft:iron_block
fill 317 192 304 317 192 305 minecraft:iron_block
fill 317 192 307 317 192 308 minecraft:iron_block
fill 317 192 310 318 192 310 minecraft:iron_block
fill 317 192 313 317 192 314 minecraft:iron_block
fill 317 192 316 318 192 316 minecraft:iron_block
fill 318 192 276 319 192 276 minecraft:iron_block
fill 318 192 282 318 192 283 minecraft:iron_block
fill 318 192 285 318 192 286 minecraft:iron_block
fill 318 192 288 318 192 289 minecraft:iron_block
fill 318 192 291 318 192 292 minecraft:iron_block
fill 318 192 294 318 192 295 minecraft:iron_block
fill 318 192 297 318 192 298 minecraft:iron_block
fill 318 192 300 318 192 301 minecraft:iron_block
setblock 318 192 304 minecraft:iron_block
fill 318 192 306 318 192 307 minecraft:iron_block
fill 318 192 309 319 192 309 minecraft:iron_block
fill 318 192 312 318 192 313 minecraft:iron_block
fill 318 192 315 319 192 315 minecraft:iron_block
fill 319 192 281 319 192 282 minecraft:iron_block
fill 319 192 284 319 192 285 minecraft:iron_block
fill 319 192 287 319 192 288 minecraft:iron_block
fill 319 192 290 319 192 291 minecraft:iron_block
fill 319 192 293 319 192 294 minecraft:iron_block
fill 319 192 296 319 192 297 minecraft:iron_block
fill 319 192 299 319 192 300 minecraft:iron_block
fill 319 192 302 319 192 303 minecraft:iron_block
fill 319 192 305 319 192 306 minecraft:iron_block
fill 319 192 308 320 192 308 minecraft:iron_block
fill 319 192 311 319 192 312 minecraft:iron_block
fill 319 192 314 320 192 314 minecraft:iron_block
fill 320 192 277 320 192 278 minecraft:iron_block
fill 320 192 280 320 192 281 minecraft:iron_block
fill 320 192 283 320 192 284 minecraft:iron_block
setblock 320 192 285 minecraft:light[level=12]
fill 320 192 286 320 192 287 minecraft:iron_block
fill 320 192 289 320 192 290 minecraft:iron_block
fill 320 192 292 320 192 293 minecraft:iron_block
fill 320 192 295 320 192 296 minecraft:iron_block
fill 320 192 298 320 192 299 minecraft:iron_block
fill 320 192 301 320 192 302 minecraft:iron_block
fill 320 192 304 320 192 305 minecraft:iron_block
setblock 320 192 306 minecraft:light[level=12]
fill 320 192 307 321 192 307 minecraft:iron_block
fill 320 192 310 320 192 311 minecraft:iron_block
fill 320 192 313 321 192 313 minecraft:iron_block
fill 320 192 316 321 192 316 minecraft:iron_block
fill 321 192 276 321 192 277 minecraft:iron_block
fill 321 192 279 321 192 280 minecraft:iron_block
fill 321 192 282 321 192 283 minecraft:iron_block
fill 321 192 285 321 192 286 minecraft:iron_block
fill 321 192 288 321 192 289 minecraft:iron_block
fill 321 192 291 321 192 292 minecraft:iron_block
fill 321 192 294 321 192 295 minecraft:iron_block
fill 321 192 297 321 192 298 minecraft:iron_block
fill 321 192 300 321 192 301 minecraft:iron_block
fill 321 192 303 321 192 304 minecraft:iron_block
fill 321 192 306 322 192 306 minecraft:iron_block
fill 321 192 309 321 192 310 minecraft:iron_block
fill 321 192 312 323 192 312 minecraft:iron_block
fill 321 192 315 322 192 315 minecraft:iron_block
setblock 322 192 276 minecraft:iron_block
fill 322 192 278 322 192 279 minecraft:iron_block
fill 322 192 281 323 192 282 minecraft:iron_block
fill 322 192 284 322 192 285 minecraft:iron_block
fill 322 192 287 322 192 288 minecraft:iron_block
fill 322 192 290 322 192 291 minecraft:iron_block
fill 322 192 293 322 192 294 minecraft:iron_block
fill 322 192 296 322 192 297 minecraft:iron_block
fill 322 192 299 322 192 300 minecraft:iron_block
fill 322 192 302 322 192 303 minecraft:iron_block
fill 322 192 305 323 192 305 minecraft:iron_block
fill 322 192 308 322 192 309 minecraft:iron_block
fill 322 192 311 323 192 311 minecraft:iron_block
fill 322 192 314 323 192 314 minecraft:iron_block
fill 323 192 277 323 192 278 minecraft:iron_block
setblock 323 192 280 minecraft:iron_block
setblock 323 192 284 minecraft:iron_block
fill 323 192 286 323 192 287 minecraft:iron_block
fill 323 192 289 323 192 290 minecraft:iron_block
setblock 323 192 292 minecraft:iron_block
fill 323 192 295 323 192 296 minecraft:iron_block
fill 323 192 298 323 192 299 minecraft:iron_block
fill 323 192 301 323 192 302 minecraft:iron_block
setblock 323 192 304 minecraft:iron_block
fill 323 192 307 323 192 308 minecraft:iron_block
setblock 323 192 310 minecraft:iron_block
setblock 323 192 316 minecraft:iron_block
fill 282 193 275 282 194 276 minecraft:yellow_concrete
fill 282 193 277 282 194 278 minecraft:black_concrete
fill 282 193 279 282 194 280 minecraft:yellow_concrete
fill 282 193 281 282 193 284 minecraft:pearlescent_froglight
fill 282 193 285 282 194 286 minecraft:black_concrete
fill 282 193 287 282 194 288 minecraft:yellow_concrete
fill 282 193 289 282 194 290 minecraft:black_concrete
fill 282 193 291 282 193 294 minecraft:pearlescent_froglight
fill 282 193 295 282 194 296 minecraft:yellow_concrete
fill 282 193 297 282 194 298 minecraft:black_concrete
fill 282 193 299 282 194 300 minecraft:yellow_concrete
fill 282 193 301 282 193 304 minecraft:pearlescent_froglight
fill 282 193 305 282 194 306 minecraft:black_concrete
fill 282 193 307 282 194 308 minecraft:yellow_concrete
fill 282 193 309 282 194 310 minecraft:black_concrete
fill 282 193 311 282 193 314 minecraft:pearlescent_froglight
fill 282 193 315 282 194 316 minecraft:yellow_concrete
fill 282 193 317 282 194 317 minecraft:black_concrete
fill 283 193 275 283 194 275 minecraft:yellow_concrete
fill 283 193 317 283 194 317 minecraft:yellow_concrete
fill 284 193 275 284 194 275 minecraft:black_concrete
fill 284 193 317 285 194 317 minecraft:black_concrete
fill 285 193 275 288 193 275 minecraft:pearlescent_froglight
fill 286 193 317 289 193 317 minecraft:pearlescent_froglight
fill 289 193 275 289 194 275 minecraft:black_concrete
fill 289 193 282 289 193 310 minecraft:light_gray_concrete
fill 290 193 275 291 194 275 minecraft:yellow_concrete
fill 290 193 282 317 193 282 minecraft:light_gray_concrete
fill 290 193 310 317 193 310 minecraft:light_gray_concrete
fill 290 193 317 291 194 317 minecraft:yellow_concrete
fill 292 193 275 293 194 275 minecraft:black_concrete
fill 292 193 317 293 194 317 minecraft:black_concrete
fill 294 193 275 294 194 275 minecraft:yellow_concrete
fill 294 193 317 295 194 317 minecraft:yellow_concrete
fill 295 193 275 298 193 275 minecraft:pearlescent_froglight
fill 296 193 317 299 193 317 minecraft:pearlescent_froglight
fill 299 193 275 299 194 275 minecraft:yellow_concrete
fill 300 193 275 301 194 275 minecraft:black_concrete
fill 300 193 317 301 194 317 minecraft:black_concrete
fill 302 193 275 303 194 275 minecraft:yellow_concrete
fill 302 193 317 303 194 317 minecraft:yellow_concrete
fill 304 193 275 304 194 275 minecraft:black_concrete
fill 304 193 317 305 194 317 minecraft:black_concrete
fill 305 193 275 308 193 275 minecraft:pearlescent_froglight
fill 306 193 317 309 193 317 minecraft:pearlescent_froglight
fill 309 193 275 309 194 275 minecraft:black_concrete
fill 310 193 275 311 194 275 minecraft:yellow_concrete
fill 310 193 317 311 194 317 minecraft:yellow_concrete
fill 312 193 275 313 194 275 minecraft:black_concrete
fill 312 193 317 313 194 317 minecraft:black_concrete
fill 314 193 275 314 194 275 minecraft:yellow_concrete
fill 314 193 317 315 194 317 minecraft:yellow_concrete
fill 315 193 275 318 193 275 minecraft:pearlescent_froglight
fill 316 193 317 319 193 317 minecraft:pearlescent_froglight
fill 317 193 283 317 193 309 minecraft:light_gray_concrete
fill 319 193 275 319 194 275 minecraft:yellow_concrete
fill 320 193 275 321 194 275 minecraft:black_concrete
fill 320 193 317 321 194 317 minecraft:black_concrete
fill 322 193 275 323 194 275 minecraft:yellow_concrete
fill 322 193 317 323 194 317 minecraft:yellow_concrete
fill 324 193 275 324 194 275 minecraft:black_concrete
fill 324 193 276 324 193 279 minecraft:pearlescent_froglight
fill 324 193 280 324 194 280 minecraft:yellow_concrete
fill 324 193 281 324 194 282 minecraft:black_concrete
fill 324 193 283 324 194 284 minecraft:yellow_concrete
fill 324 193 285 324 194 285 minecraft:black_concrete
fill 324 193 286 324 193 289 minecraft:pearlescent_froglight
fill 324 193 290 324 194 290 minecraft:black_concrete
fill 324 193 291 324 194 292 minecraft:yellow_concrete
fill 324 193 293 324 194 294 minecraft:black_concrete
fill 324 193 295 324 194 295 minecraft:yellow_concrete
fill 324 193 296 324 193 299 minecraft:pearlescent_froglight
fill 324 193 300 324 194 300 minecraft:yellow_concrete
fill 324 193 301 324 194 302 minecraft:black_concrete
fill 324 193 303 324 194 304 minecraft:yellow_concrete
fill 324 193 305 324 194 305 minecraft:black_concrete
fill 324 193 306 324 193 309 minecraft:pearlescent_froglight
fill 324 193 310 324 194 310 minecraft:black_concrete
fill 324 193 311 324 194 312 minecraft:yellow_concrete
fill 324 193 313 324 194 314 minecraft:black_concrete
fill 324 193 315 324 194 315 minecraft:yellow_concrete
setblock 324 193 316 minecraft:pearlescent_froglight
fill 324 193 317 324 194 317 minecraft:black_concrete
fill 282 194 281 282 194 282 minecraft:black_concrete
fill 282 194 283 282 194 284 minecraft:yellow_concrete
fill 282 194 291 282 194 292 minecraft:yellow_concrete
fill 282 194 293 282 194 294 minecraft:black_concrete
fill 282 194 301 282 194 302 minecraft:black_concrete
fill 282 194 303 282 194 304 minecraft:yellow_concrete
fill 282 194 311 282 194 312 minecraft:yellow_concrete
fill 282 194 313 282 194 314 minecraft:black_concrete
fill 284 194 312 284 194 313 minecraft:gray_concrete
setblock 285 194 275 minecraft:black_concrete
setblock 285 194 311 minecraft:gray_concrete
setblock 285 194 314 minecraft:gray_concrete
fill 286 194 275 287 194 275 minecraft:yellow_concrete
fill 286 194 310 287 194 310 minecraft:gray_concrete
fill 286 194 317 287 194 317 minecraft:yellow_concrete
setblock 288 194 275 minecraft:black_concrete
setblock 288 194 311 minecraft:gray_concrete
setblock 288 194 314 minecraft:gray_concrete
fill 288 194 317 289 194 317 minecraft:black_concrete
setblock 295 194 275 minecraft:yellow_concrete
fill 296 194 275 297 194 275 minecraft:black_concrete
fill 296 194 317 297 194 317 minecraft:black_concrete
setblock 298 194 275 minecraft:yellow_concrete
fill 298 194 317 299 194 317 minecraft:yellow_concrete
setblock 305 194 275 minecraft:black_concrete
fill 306 194 275 307 194 275 minecraft:yellow_concrete
fill 306 194 317 307 194 317 minecraft:yellow_concrete
setblock 308 194 275 minecraft:black_concrete
fill 308 194 317 309 194 317 minecraft:black_concrete
setblock 315 194 275 minecraft:yellow_concrete
fill 316 194 275 317 194 275 minecraft:black_concrete
fill 316 194 317 317 194 317 minecraft:black_concrete
setblock 318 194 275 minecraft:yellow_concrete
fill 318 194 317 319 194 317 minecraft:yellow_concrete
setblock 324 194 276 minecraft:yellow_concrete
fill 324 194 277 324 194 278 minecraft:black_concrete
setblock 324 194 279 minecraft:yellow_concrete
setblock 324 194 286 minecraft:black_concrete
fill 324 194 287 324 194 288 minecraft:yellow_concrete
setblock 324 194 289 minecraft:black_concrete
setblock 324 194 296 minecraft:yellow_concrete
fill 324 194 297 324 194 298 minecraft:black_concrete
setblock 324 194 299 minecraft:yellow_concrete
setblock 324 194 306 minecraft:black_concrete
fill 324 194 307 324 194 308 minecraft:yellow_concrete
setblock 324 194 309 minecraft:black_concrete
setblock 324 194 316 minecraft:yellow_concrete
fill 282 195 275 282 201 317 minecraft:gray_concrete
fill 283 195 275 297 201 275 minecraft:gray_concrete
fill 283 195 317 290 201 317 minecraft:gray_concrete
setblock 291 195 317 minecraft:sea_lantern
fill 292 195 317 324 201 317 minecraft:gray_concrete
fill 295 195 276 295 196 278 minecraft:iron_block
setblock 298 195 275 minecraft:sea_lantern
fill 299 195 275 324 201 275 minecraft:gray_concrete
fill 316 195 278 316 195 280 minecraft:iron_block
fill 317 195 277 319 195 277 minecraft:iron_block
fill 317 195 281 319 195 281 minecraft:iron_block
fill 320 195 278 320 195 280 minecraft:iron_block
fill 320 195 313 320 196 315 minecraft:iron_block
fill 324 195 276 324 201 281 minecraft:gray_concrete
setblock 324 195 282 minecraft:redstone_block
fill 324 195 283 324 195 316 minecraft:gray_concrete
fill 291 196 317 291 220 317 minecraft:gray_concrete
fill 298 196 275 298 201 275 minecraft:gray_concrete
fill 315 196 312 315 196 314 minecraft:iron_block
fill 316 196 312 317 196 312 minecraft:iron_block
fill 316 196 314 317 196 314 minecraft:iron_block
setblock 317 196 313 minecraft:iron_block
fill 324 196 282 324 209 285 minecraft:gray_concrete
setblock 324 196 286 minecraft:redstone_block
fill 324 196 287 324 201 316 minecraft:gray_concrete
fill 318 197 276 318 198 277 minecraft:iron_block
fill 324 197 286 324 201 286 minecraft:gray_concrete
setblock 283 198 278 minecraft:iron_block
fill 283 198 280 283 198 283 minecraft:iron_block
setblock 283 198 288 minecraft:iron_block
fill 283 198 290 283 198 293 minecraft:iron_block
setblock 283 198 298 minecraft:iron_block
fill 283 198 300 283 198 303 minecraft:iron_block
setblock 283 198 308 minecraft:iron_block
fill 283 198 310 283 198 313 minecraft:iron_block
fill 284 198 276 287 198 276 minecraft:iron_block
setblock 285 198 278 minecraft:light[level=12]
setblock 285 198 285 minecraft:light[level=12]
setblock 285 198 292 minecraft:light[level=12]
setblock 285 198 299 minecraft:light[level=12]
setblock 285 198 306 minecraft:light[level=12]
setblock 285 198 316 minecraft:iron_block
fill 287 198 316 290 198 316 minecraft:iron_block
setblock 289 198 276 minecraft:iron_block
setblock 292 198 278 minecraft:light[level=12]
setblock 292 198 285 minecraft:light[level=12]
setblock 292 198 292 minecraft:light[level=12]
setblock 292 198 299 minecraft:light[level=12]
setblock 292 198 306 minecraft:light[level=12]
setblock 292 198 313 minecraft:light[level=12]
fill 294 198 276 297 198 276 minecraft:iron_block
setblock 295 198 316 minecraft:iron_block
fill 297 198 316 300 198 316 minecraft:iron_block
setblock 299 198 276 minecraft:iron_block
setblock 299 198 278 minecraft:light[level=12]
setblock 299 198 285 minecraft:light[level=12]
setblock 299 198 292 minecraft:light[level=12]
setblock 299 198 299 minecraft:light[level=12]
setblock 299 198 306 minecraft:light[level=12]
setblock 299 198 313 minecraft:light[level=12]
fill 304 198 276 307 198 276 minecraft:iron_block
setblock 305 198 316 minecraft:iron_block
setblock 306 198 278 minecraft:light[level=12]
setblock 306 198 285 minecraft:light[level=12]
setblock 306 198 292 minecraft:light[level=12]
setblock 306 198 299 minecraft:light[level=12]
setblock 306 198 306 minecraft:light[level=12]
setblock 306 198 313 minecraft:light[level=12]
fill 307 198 316 310 198 316 minecraft:iron_block
setblock 309 198 276 minecraft:iron_block
setblock 313 198 278 minecraft:light[level=12]
setblock 313 198 285 minecraft:light[level=12]
setblock 313 198 292 minecraft:light[level=12]
setblock 313 198 299 minecraft:light[level=12]
setblock 313 198 306 minecraft:light[level=12]
setblock 313 198 313 minecraft:light[level=12]
fill 314 198 276 317 198 276 minecraft:iron_block
setblock 315 198 316 minecraft:iron_block
fill 317 198 316 320 198 316 minecraft:iron_block
setblock 319 198 276 minecraft:iron_block
setblock 320 198 278 minecraft:light[level=12]
setblock 320 198 285 minecraft:light[level=12]
setblock 320 198 292 minecraft:light[level=12]
setblock 320 198 299 minecraft:light[level=12]
setblock 320 198 306 minecraft:light[level=12]
setblock 320 198 313 minecraft:light[level=12]
fill 323 198 277 323 198 280 minecraft:iron_block
setblock 323 198 282 minecraft:iron_block
fill 323 198 287 323 198 290 minecraft:iron_block
setblock 323 198 292 minecraft:iron_block
fill 323 198 297 323 198 300 minecraft:iron_block
setblock 323 198 302 minecraft:iron_block
fill 323 198 307 323 198 310 minecraft:iron_block
setblock 323 198 312 minecraft:iron_block
setblock 285 200 278 minecraft:light[level=15]
setblock 285 200 286 minecraft:light[level=15]
setblock 285 200 294 minecraft:light[level=15]
setblock 285 200 302 minecraft:light[level=15]
setblock 285 200 310 minecraft:light[level=15]
setblock 293 200 278 minecraft:light[level=15]
setblock 293 200 286 minecraft:light[level=15]
setblock 293 200 294 minecraft:light[level=15]
setblock 293 200 302 minecraft:light[level=15]
setblock 293 200 310 minecraft:light[level=15]
setblock 301 200 278 minecraft:light[level=15]
setblock 301 200 286 minecraft:light[level=15]
setblock 301 200 302 minecraft:light[level=15]
setblock 301 200 310 minecraft:light[level=15]
setblock 309 200 278 minecraft:light[level=15]
setblock 309 200 286 minecraft:light[level=15]
setblock 309 200 294 minecraft:light[level=15]
setblock 309 200 302 minecraft:light[level=15]
setblock 309 200 310 minecraft:light[level=15]
fill 316 200 278 316 200 280 minecraft:iron_block
fill 317 200 277 319 200 277 minecraft:iron_block
fill 317 200 281 319 200 281 minecraft:iron_block
setblock 317 200 286 minecraft:light[level=15]
setblock 317 200 294 minecraft:light[level=15]
setblock 317 200 302 minecraft:light[level=15]
setblock 317 200 310 minecraft:light[level=15]
fill 319 200 276 319 201 276 minecraft:iron_block
fill 320 200 278 320 200 280 minecraft:iron_block
setblock 319 201 277 minecraft:iron_block
fill 282 202 275 282 204 280 minecraft:gray_concrete
fill 282 202 281 282 202 284 minecraft:pearlescent_froglight
fill 282 202 285 282 218 290 minecraft:gray_concrete
fill 282 202 291 282 202 294 minecraft:pearlescent_froglight
fill 282 202 295 282 206 300 minecraft:gray_concrete
fill 282 202 301 282 202 304 minecraft:pearlescent_froglight
fill 282 202 305 282 210 310 minecraft:gray_concrete
fill 282 202 311 282 202 314 minecraft:pearlescent_froglight
fill 282 202 315 282 220 317 minecraft:gray_concrete
fill 283 202 275 284 220 275 minecraft:gray_concrete
fill 283 202 317 285 220 317 minecraft:gray_concrete
fill 284 202 312 284 202 313 minecraft:gray_concrete
fill 285 202 275 288 202 275 minecraft:pearlescent_froglight
setblock 285 202 311 minecraft:gray_concrete
setblock 285 202 314 minecraft:gray_concrete
fill 286 202 310 287 202 310 minecraft:gray_concrete
fill 286 202 317 289 202 317 minecraft:pearlescent_froglight
setblock 288 202 311 minecraft:gray_concrete
setblock 288 202 314 minecraft:gray_concrete
fill 289 202 275 294 219 275 minecraft:gray_concrete
fill 290 202 317 290 217 317 minecraft:gray_concrete
fill 292 202 276 293 203 281 minecraft:iron_block
fill 292 202 317 295 217 317 minecraft:gray_concrete
fill 293 202 282 293 203 287 minecraft:iron_block
fill 294 202 283 294 203 294 minecraft:iron_block
fill 295 202 275 298 202 275 minecraft:pearlescent_froglight
fill 295 202 290 295 203 301 minecraft:iron_block
fill 296 202 297 296 203 308 minecraft:iron_block
fill 296 202 317 299 202 317 minecraft:pearlescent_froglight
fill 297 202 304 297 203 315 minecraft:iron_block
fill 298 202 311 298 203 316 minecraft:iron_block
fill 299 202 275 304 209 275 minecraft:gray_concrete
fill 300 202 317 305 209 317 minecraft:gray_concrete
fill 305 202 275 308 202 275 minecraft:pearlescent_froglight
fill 306 202 317 309 202 317 minecraft:pearlescent_froglight
fill 309 202 275 314 219 275 minecraft:gray_concrete
fill 310 202 317 315 217 317 minecraft:gray_concrete
fill 315 202 275 318 202 275 minecraft:pearlescent_froglight
fill 316 202 317 319 202 317 minecraft:pearlescent_froglight
fill 319 202 275 324 219 275 minecraft:gray_concrete
fill 320 202 317 324 218 317 minecraft:gray_concrete
fill 324 202 276 324 202 279 minecraft:pearlescent_froglight
fill 324 202 280 324 217 281 minecraft:gray_concrete
fill 324 202 286 324 202 289 minecraft:pearlescent_froglight
fill 324 202 290 324 218 295 minecraft:gray_concrete
fill 324 202 296 324 202 299 minecraft:pearlescent_froglight
fill 324 202 300 324 217 305 minecraft:gray_concrete
fill 324 202 306 324 202 309 minecraft:pearlescent_froglight
fill 324 202 310 324 209 315 minecraft:gray_concrete
setblock 324 202 316 minecraft:pearlescent_froglight
fill 282 203 281 282 215 284 minecraft:gray_concrete
fill 282 203 291 282 218 294 minecraft:gray_concrete
fill 282 203 301 282 213 304 minecraft:gray_concrete
fill 282 203 311 282 219 314 minecraft:gray_concrete
fill 283 203 298 285 204 298 minecraft:iron_block
fill 285 203 275 288 217 275 minecraft:gray_concrete
fill 286 203 317 289 214 317 minecraft:gray_concrete
fill 295 203 275 298 218 275 minecraft:gray_concrete
fill 296 203 317 299 219 317 minecraft:gray_concrete
fill 305 203 275 308 217 275 minecraft:gray_concrete
fill 306 203 317 309 217 317 minecraft:gray_concrete
fill 315 203 275 318 217 275 minecraft:gray_concrete
fill 315 203 312 315 203 314 minecraft:iron_block
fill 316 203 312 317 203 312 minecraft:iron_block
fill 316 203 314 317 203 314 minecraft:iron_block
fill 316 203 317 319 219 317 minecraft:gray_concrete
setblock 317 203 313 minecraft:iron_block
fill 324 203 276 324 219 279 minecraft:gray_concrete
fill 324 203 286 324 219 289 minecraft:gray_concrete
fill 324 203 296 324 217 299 minecraft:gray_concrete
fill 324 203 306 324 218 309 minecraft:gray_concrete
fill 324 203 316 324 219 316 minecraft:gray_concrete
setblock 283 204 278 minecraft:iron_block
setblock 283 204 288 minecraft:iron_block
setblock 283 204 308 minecraft:iron_block
setblock 285 204 278 minecraft:light[level=12]
setblock 285 204 285 minecraft:light[level=12]
setblock 285 204 292 minecraft:light[level=12]
setblock 285 204 299 minecraft:light[level=12]
setblock 285 204 306 minecraft:light[level=12]
setblock 285 204 316 minecraft:iron_block
setblock 289 204 276 minecraft:iron_block
fill 292 204 276 292 204 278 minecraft:light_gray_concrete
setblock 292 204 285 minecraft:light[level=12]
setblock 292 204 292 minecraft:light[level=12]
setblock 292 204 299 minecraft:light[level=12]
setblock 292 204 306 minecraft:light[level=12]
setblock 292 204 313 minecraft:light[level=12]
fill 293 204 279 293 204 285 minecraft:light_gray_concrete
fill 294 204 285 294 204 292 minecraft:light_gray_concrete
fill 295 204 292 295 204 299 minecraft:light_gray_concrete
setblock 295 204 316 minecraft:iron_block
fill 296 204 299 296 204 306 minecraft:light_gray_concrete
fill 297 204 306 297 204 312 minecraft:light_gray_concrete
fill 298 204 313 298 204 316 minecraft:light_gray_concrete
setblock 299 204 276 minecraft:iron_block
setblock 299 204 278 minecraft:light[level=12]
setblock 299 204 285 minecraft:light[level=12]
setblock 299 204 292 minecraft:light[level=12]
setblock 299 204 299 minecraft:light[level=12]
setblock 299 204 306 minecraft:light[level=12]
setblock 299 204 313 minecraft:light[level=12]
setblock 305 204 316 minecraft:iron_block
setblock 306 204 278 minecraft:light[level=12]
setblock 306 204 285 minecraft:light[level=12]
setblock 306 204 292 minecraft:light[level=12]
setblock 306 204 299 minecraft:light[level=12]
setblock 306 204 306 minecraft:light[level=12]
setblock 306 204 313 minecraft:light[level=12]
setblock 309 204 276 minecraft:iron_block
setblock 313 204 278 minecraft:light[level=12]
setblock 313 204 285 minecraft:light[level=12]
setblock 313 204 292 minecraft:light[level=12]
setblock 313 204 299 minecraft:light[level=12]
setblock 313 204 306 minecraft:light[level=12]
setblock 313 204 313 minecraft:light[level=12]
setblock 315 204 316 minecraft:iron_block
setblock 319 204 276 minecraft:iron_block
setblock 320 204 278 minecraft:light[level=12]
setblock 320 204 285 minecraft:light[level=12]
setblock 320 204 292 minecraft:light[level=12]
setblock 320 204 299 minecraft:light[level=12]
setblock 320 204 306 minecraft:light[level=12]
setblock 320 204 313 minecraft:light[level=12]
setblock 323 204 282 minecraft:iron_block
setblock 323 204 292 minecraft:iron_block
setblock 323 204 302 minecraft:iron_block
setblock 323 204 312 minecraft:iron_block
fill 282 205 275 282 220 277 minecraft:gray_concrete
setblock 282 205 278 minecraft:redstone_block
fill 282 205 279 282 220 280 minecraft:gray_concrete
fill 316 205 278 316 205 280 minecraft:iron_block
fill 317 205 277 319 205 277 minecraft:iron_block
fill 317 205 281 319 205 281 minecraft:iron_block
fill 320 205 278 320 205 280 minecraft:iron_block
fill 282 206 278 282 219 278 minecraft:gray_concrete
fill 283 206 291 290 207 292 minecraft:iron_block
fill 291 206 291 300 207 291 minecraft:iron_block
fill 299 206 309 299 213 309 minecraft:iron_block
setblock 282 207 295 minecraft:sea_lantern
fill 282 207 296 282 210 300 minecraft:gray_concrete
fill 283 207 280 283 207 283 minecraft:iron_block
setblock 283 207 290 minecraft:iron_block
setblock 283 207 293 minecraft:iron_block
fill 283 207 300 283 207 303 minecraft:iron_block
fill 283 207 310 283 207 313 minecraft:iron_block
fill 284 207 276 287 207 276 minecraft:iron_block
fill 284 207 312 284 208 313 minecraft:light_gray_concrete
fill 285 207 311 285 208 311 minecraft:light_gray_concrete
fill 285 207 314 285 208 314 minecraft:light_gray_concrete
fill 287 207 316 290 207 316 minecraft:iron_block
fill 288 207 311 288 208 311 minecraft:light_gray_concrete
fill 288 207 314 288 208 314 minecraft:light_gray_concrete
fill 291 207 292 296 207 292 minecraft:iron_block
fill 294 207 276 297 207 276 minecraft:iron_block
fill 297 207 290 323 207 290 minecraft:iron_block
fill 297 207 316 300 207 316 minecraft:iron_block
fill 300 207 309 300 212 309 minecraft:iron_block
fill 304 207 276 307 207 276 minecraft:iron_block
fill 304 207 291 314 207 291 minecraft:iron_block
fill 307 207 316 310 207 316 minecraft:iron_block
fill 314 207 276 317 207 276 minecraft:iron_block
fill 317 207 289 323 207 289 minecraft:iron_block
fill 317 207 316 320 207 316 minecraft:iron_block
fill 323 207 277 323 207 280 minecraft:iron_block
fill 323 207 287 323 207 288 minecraft:iron_block
fill 323 207 297 323 207 300 minecraft:iron_block
fill 323 207 307 323 207 310 minecraft:iron_block
fill 282 208 295 282 220 295 minecraft:gray_concrete
fill 283 208 292 287 208 292 minecraft:light_gray_concrete
setblock 285 208 278 minecraft:light[level=15]
setblock 285 208 286 minecraft:light[level=15]
setblock 285 208 294 minecraft:light[level=15]
setblock 285 208 302 minecraft:light[level=15]
setblock 285 208 310 minecraft:light[level=15]
fill 286 208 291 300 208 291 minecraft:light_gray_concrete
setblock 293 208 278 minecraft:light[level=15]
setblock 293 208 286 minecraft:light[level=15]
setblock 293 208 294 minecraft:light[level=15]
setblock 293 208 302 minecraft:light[level=15]
setblock 293 208 310 minecraft:light[level=15]
setblock 301 208 278 minecraft:light[level=15]
setblock 301 208 286 minecraft:light[level=15]
setblock 301 208 302 minecraft:light[level=15]
setblock 301 208 310 minecraft:light[level=15]
fill 307 208 290 323 208 290 minecraft:iron_block
setblock 309 208 278 minecraft:light[level=15]
setblock 309 208 286 minecraft:light[level=15]
setblock 309 208 294 minecraft:light[level=15]
setblock 309 208 302 minecraft:light[level=15]
setblock 309 208 310 minecraft:light[level=15]
setblock 317 208 286 minecraft:light[level=15]
setblock 317 208 294 minecraft:light[level=15]
setblock 317 208 302 minecraft:light[level=15]
setblock 317 208 310 minecraft:light[level=15]
fill 319 208 289 323 208 289 minecraft:iron_block
setblock 285 210 278 minecraft:light[level=12]
setblock 285 210 285 minecraft:light[level=12]
setblock 285 210 292 minecraft:light[level=12]
setblock 285 210 299 minecraft:light[level=12]
setblock 285 210 306 minecraft:light[level=12]
setblock 285 210 313 minecraft:light[level=12]
setblock 292 210 278 minecraft:light[level=12]
setblock 292 210 285 minecraft:light[level=12]
setblock 292 210 292 minecraft:light[level=12]
setblock 292 210 299 minecraft:light[level=12]
setblock 292 210 306 minecraft:light[level=12]
setblock 292 210 313 minecraft:light[level=12]
fill 299 210 275 300 218 275 minecraft:gray_concrete
setblock 299 210 278 minecraft:light[level=12]
setblock 299 210 285 minecraft:light[level=12]
setblock 299 210 292 minecraft:light[level=12]
setblock 299 210 299 minecraft:light[level=12]
setblock 299 210 306 minecraft:light[level=12]
setblock 299 210 313 minecraft:light[level=12]
fill 300 210 317 300 220 317 minecraft:gray_concrete
setblock 301 210 275 minecraft:redstone_block
setblock 301 210 317 minecraft:redstone_block
fill 302 210 275 304 217 275 minecraft:gray_concrete
fill 302 210 317 305 212 317 minecraft:gray_concrete
setblock 306 210 278 minecraft:light[level=12]
setblock 306 210 285 minecraft:light[level=12]
setblock 306 210 292 minecraft:light[level=12]
setblock 306 210 299 minecraft:light[level=12]
setblock 306 210 306 minecraft:light[level=12]
setblock 306 210 313 minecraft:light[level=12]
setblock 313 210 278 minecraft:light[level=12]
setblock 313 210 285 minecraft:light[level=12]
setblock 313 210 292 minecraft:light[level=12]
setblock 313 210 299 minecraft:light[level=12]
setblock 313 210 306 minecraft:light[level=12]
setblock 313 210 313 minecraft:light[level=12]
setblock 320 210 278 minecraft:light[level=12]
setblock 320 210 285 minecraft:light[level=12]
setblock 320 210 292 minecraft:light[level=12]
setblock 320 210 299 minecraft:light[level=12]
setblock 320 210 306 minecraft:light[level=12]
setblock 320 210 313 minecraft:light[level=12]
fill 324 210 282 324 218 283 minecraft:gray_concrete
setblock 324 210 284 minecraft:sea_lantern
fill 324 210 285 324 219 285 minecraft:gray_concrete
fill 324 210 310 324 211 314 minecraft:gray_concrete
setblock 324 210 315 minecraft:sea_lantern
fill 282 211 296 282 219 296 minecraft:gray_concrete
setblock 282 211 297 minecraft:sea_lantern
fill 282 211 298 282 219 300 minecraft:gray_concrete
fill 282 211 305 282 218 307 minecraft:gray_concrete
setblock 282 211 308 minecraft:sea_lantern
fill 282 211 309 282 217 310 minecraft:gray_concrete
fill 301 211 275 301 218 275 minecraft:gray_concrete
fill 301 211 317 301 220 317 minecraft:gray_concrete
fill 324 211 284 324 216 284 minecraft:gray_concrete
fill 324 211 315 324 217 315 minecraft:gray_concrete
fill 282 212 297 282 218 297 minecraft:gray_concrete
fill 282 212 308 282 220 308 minecraft:gray_concrete
fill 324 212 310 324 220 311 minecraft:gray_concrete
setblock 324 212 312 minecraft:sea_lantern
fill 324 212 313 324 220 314 minecraft:gray_concrete
setblock 302 213 317 minecraft:redstone_block
fill 303 213 317 305 218 317 minecraft:gray_concrete
fill 324 213 312 324 220 312 minecraft:gray_concrete
fill 282 214 301 282 219 301 minecraft:gray_concrete
setblock 282 214 302 minecraft:redstone_block
fill 282 214 303 282 218 304 minecraft:gray_concrete
fill 290 214 294 297 214 294 minecraft:light_gray_concrete
fill 291 214 293 298 214 293 minecraft:light_gray_concrete
fill 291 214 296 291 214 298 minecraft:light_gray_concrete
fill 292 214 288 292 214 290 minecraft:light_gray_concrete
fill 292 214 296 298 214 297 minecraft:light_gray_concrete
fill 293 214 289 298 214 292 minecraft:light_gray_concrete
fill 293 214 295 298 214 295 minecraft:light_gray_concrete
fill 293 214 298 310 214 298 minecraft:light_gray_concrete
fill 293 214 300 294 214 301 minecraft:light_gray_concrete
fill 294 214 286 295 214 287 minecraft:light_gray_concrete
fill 294 214 299 310 214 299 minecraft:light_gray_concrete
fill 295 214 288 309 214 288 minecraft:light_gray_concrete
fill 295 214 300 307 214 300 minecraft:light_gray_concrete
fill 295 214 303 297 214 303 minecraft:light_gray_concrete
fill 296 214 287 306 214 287 minecraft:light_gray_concrete
fill 296 214 301 305 214 302 minecraft:light_gray_concrete
fill 297 214 284 299 214 284 minecraft:light_gray_concrete
fill 297 214 286 306 214 286 minecraft:light_gray_concrete
fill 298 214 285 299 214 285 minecraft:light_gray_concrete
fill 299 214 289 300 214 291 minecraft:light_gray_concrete
fill 299 214 297 300 214 297 minecraft:light_gray_concrete
fill 300 214 303 301 214 304 minecraft:light_gray_concrete
fill 301 214 283 301 214 285 minecraft:light_gray_concrete
fill 301 214 289 308 214 290 minecraft:light_gray_concrete
setblock 301 214 305 minecraft:light_gray_concrete
fill 302 214 284 302 214 285 minecraft:light_gray_concrete
fill 302 214 291 311 214 291 minecraft:light_gray_concrete
fill 302 214 297 309 214 297 minecraft:light_gray_concrete
fill 302 214 317 302 220 317 minecraft:gray_concrete
fill 303 214 303 304 214 304 minecraft:light_gray_concrete
fill 304 214 292 309 214 293 minecraft:light_gray_concrete
fill 304 214 295 309 214 296 minecraft:light_gray_concrete
fill 305 214 285 307 214 285 minecraft:light_gray_concrete
fill 305 214 294 312 214 294 minecraft:light_gray_concrete
setblock 305 214 304 minecraft:light_gray_concrete
fill 306 214 301 308 214 301 minecraft:light_gray_concrete
fill 307 214 302 308 214 302 minecraft:light_gray_concrete
fill 308 214 287 309 214 287 minecraft:light_gray_concrete
setblock 309 214 290 minecraft:light_gray_concrete
fill 310 214 292 311 214 292 minecraft:light_gray_concrete
fill 310 214 295 311 214 295 minecraft:light_gray_concrete
setblock 310 214 300 minecraft:light_gray_concrete
setblock 311 214 290 minecraft:light_gray_concrete
fill 282 215 302 282 219 302 minecraft:gray_concrete
fill 283 215 276 323 215 277 minecraft:black_concrete
fill 283 215 278 323 215 278 minecraft:yellow_concrete
fill 283 215 279 323 215 280 minecraft:black_concrete
fill 283 215 281 323 215 281 minecraft:yellow_concrete
fill 283 215 282 297 215 283 minecraft:black_concrete
fill 283 215 284 292 215 284 minecraft:yellow_concrete
fill 283 215 285 292 215 286 minecraft:black_concrete
fill 283 215 287 292 215 287 minecraft:yellow_concrete
fill 283 215 288 288 215 289 minecraft:black_concrete
fill 283 215 290 289 215 290 minecraft:yellow_concrete
fill 283 215 291 290 215 292 minecraft:black_concrete
fill 283 215 293 288 215 293 minecraft:yellow_concrete
fill 283 215 294 287 215 295 minecraft:black_concrete
fill 283 215 296 290 215 296 minecraft:yellow_concrete
fill 283 215 297 289 215 298 minecraft:black_concrete
fill 283 215 299 288 215 299 minecraft:yellow_concrete
fill 283 215 300 289 215 301 minecraft:black_concrete
fill 283 215 302 293 215 302 minecraft:yellow_concrete
fill 283 215 303 292 215 304 minecraft:black_concrete
fill 283 215 305 297 215 305 minecraft:yellow_concrete
fill 283 215 306 297 215 307 minecraft:black_concrete
fill 283 215 308 323 215 308 minecraft:yellow_concrete
fill 283 215 309 323 215 310 minecraft:black_concrete
fill 283 215 311 323 215 311 minecraft:yellow_concrete
fill 283 215 312 323 215 313 minecraft:black_concrete
fill 283 215 314 323 215 314 minecraft:yellow_concrete
fill 283 215 315 323 215 316 minecraft:black_concrete
fill 286 215 317 288 219 317 minecraft:gray_concrete
fill 288 215 294 296 216 294 minecraft:iron_block
setblock 288 215 295 minecraft:black_concrete
setblock 289 215 288 minecraft:black_concrete
fill 289 215 289 313 216 289 minecraft:iron_block
fill 289 215 293 289 216 293 minecraft:iron_block
fill 289 215 295 289 216 295 minecraft:iron_block
fill 289 215 299 313 216 299 minecraft:iron_block
setblock 289 215 317 minecraft:redstone_block
fill 290 215 288 312 216 288 minecraft:iron_block
fill 290 215 290 298 216 290 minecraft:iron_block
setblock 290 215 293 minecraft:yellow_concrete
setblock 290 215 295 minecraft:black_concrete
setblock 290 215 297 minecraft:black_concrete
fill 290 215 298 298 216 298 minecraft:iron_block
fill 290 215 300 312 216 300 minecraft:iron_block
fill 290 215 301 292 215 301 minecraft:black_concrete
fill 291 215 291 296 216 293 minecraft:iron_block
fill 291 215 295 296 216 297 minecraft:iron_block
fill 293 215 284 294 216 285 minecraft:iron_block
setblock 293 215 286 minecraft:black_concrete
fill 293 215 287 309 216 287 minecraft:iron_block
fill 293 215 301 309 216 301 minecraft:iron_block
fill 293 215 303 294 216 304 minecraft:iron_block
fill 294 215 286 308 216 286 minecraft:iron_block
fill 294 215 302 308 216 302 minecraft:iron_block
fill 295 215 284 296 215 284 minecraft:yellow_concrete
fill 295 215 285 309 216 285 minecraft:iron_block
fill 295 215 303 309 216 303 minecraft:iron_block
fill 295 215 304 296 215 304 minecraft:black_concrete
fill 297 215 284 305 216 284 minecraft:iron_block
fill 297 215 291 297 216 291 minecraft:iron_block
fill 297 215 292 297 217 296 minecraft:waxed_copper_block
fill 297 215 297 297 216 297 minecraft:iron_block
fill 297 215 304 305 216 304 minecraft:iron_block
fill 298 215 282 299 216 283 minecraft:iron_block
fill 298 215 291 298 216 292 minecraft:waxed_copper_block
setblock 298 215 293 minecraft:sea_lantern
setblock 298 215 295 minecraft:sea_lantern
fill 298 215 296 298 216 297 minecraft:waxed_copper_block
fill 298 215 305 299 216 306 minecraft:iron_block
fill 298 215 307 323 215 307 minecraft:black_concrete
fill 299 215 290 299 216 291 minecraft:waxed_copper_block
fill 299 215 297 299 216 298 minecraft:waxed_copper_block
fill 300 215 282 300 215 283 minecraft:black_concrete
fill 300 215 290 303 217 290 minecraft:waxed_copper_block
setblock 300 215 291 minecraft:sea_lantern
setblock 300 215 297 minecraft:sea_lantern
fill 300 215 298 303 217 298 minecraft:waxed_copper_block
setblock 300 215 305 minecraft:yellow_concrete
fill 300 215 306 302 215 306 minecraft:black_concrete
fill 301 215 282 302 215 282 minecraft:black_concrete
fill 301 215 283 301 216 283 minecraft:iron_block
fill 301 215 305 301 216 305 minecraft:iron_block
setblock 302 215 283 minecraft:black_concrete
setblock 302 215 291 minecraft:sea_lantern
setblock 302 215 297 minecraft:sea_lantern
setblock 302 215 305 minecraft:yellow_concrete
fill 303 215 282 304 216 283 minecraft:iron_block
fill 303 215 291 304 216 291 minecraft:waxed_copper_block
fill 303 215 297 304 216 297 minecraft:waxed_copper_block
fill 303 215 305 304 216 306 minecraft:iron_block
fill 304 215 290 312 216 290 minecraft:iron_block
fill 304 215 292 305 216 292 minecraft:waxed_copper_block
setblock 304 215 293 minecraft:sea_lantern
setblock 304 215 295 minecraft:sea_lantern
fill 304 215 296 305 216 296 minecraft:waxed_copper_block
fill 304 215 298 312 216 298 minecraft:iron_block
fill 305 215 282 323 215 283 minecraft:black_concrete
fill 305 215 291 311 216 291 minecraft:iron_block
fill 305 215 293 305 217 295 minecraft:waxed_copper_block
fill 305 215 297 311 216 297 minecraft:iron_block
fill 305 215 305 323 215 305 minecraft:yellow_concrete
fill 305 215 306 323 215 306 minecraft:black_concrete
fill 306 215 284 307 215 284 minecraft:yellow_concrete
fill 306 215 292 311 216 296 minecraft:iron_block
fill 306 215 304 307 215 304 minecraft:black_concrete
fill 308 215 284 309 216 284 minecraft:iron_block
fill 308 215 304 309 216 304 minecraft:iron_block
fill 309 215 286 323 215 286 minecraft:black_concrete
fill 309 215 302 323 215 302 minecraft:yellow_concrete
fill 310 215 284 323 215 284 minecraft:yellow_concrete
fill 310 215 285 323 215 285 minecraft:black_concrete
fill 310 215 287 323 215 287 minecraft:yellow_concrete
fill 310 215 301 323 215 301 minecraft:black_concrete
fill 310 215 303 323 215 304 minecraft:black_concrete
fill 312 215 291 323 215 292 minecraft:black_concrete
setblock 312 215 293 minecraft:yellow_concrete
fill 312 215 294 314 216 294 minecraft:iron_block
setblock 312 215 295 minecraft:black_concrete
fill 312 215 296 323 215 296 minecraft:yellow_concrete
fill 312 215 297 323 215 297 minecraft:black_concrete
fill 313 215 288 323 215 288 minecraft:black_concrete
fill 313 215 290 323 215 290 minecraft:yellow_concrete
fill 313 215 293 313 216 293 minecraft:iron_block
fill 313 215 295 313 216 295 minecraft:iron_block
fill 313 215 298 323 215 298 minecraft:black_concrete
fill 313 215 300 323 215 300 minecraft:black_concrete
fill 314 215 289 323 215 289 minecraft:black_concrete
fill 314 215 293 323 215 293 minecraft:yellow_concrete
fill 314 215 295 323 215 295 minecraft:black_concrete
fill 314 215 299 323 215 299 minecraft:yellow_concrete
fill 315 215 294 323 215 294 minecraft:black_concrete
fill 282 216 281 282 218 281 minecraft:gray_concrete
setblock 282 216 282 minecraft:redstone_block
fill 282 216 283 282 219 284 minecraft:gray_concrete
setblock 285 216 278 minecraft:light[level=15]
setblock 285 216 285 minecraft:light[level=12]
setblock 285 216 286 minecraft:light[level=15]
setblock 285 216 292 minecraft:light[level=12]
setblock 285 216 294 minecraft:light[level=15]
setblock 285 216 299 minecraft:light[level=12]
setblock 285 216 302 minecraft:light[level=15]
setblock 285 216 306 minecraft:light[level=12]
setblock 285 216 310 minecraft:light[level=15]
setblock 285 216 313 minecraft:light[level=12]
fill 289 216 317 289 219 317 minecraft:gray_concrete
setblock 292 216 278 minecraft:light[level=12]
setblock 292 216 285 minecraft:light[level=12]
setblock 292 216 306 minecraft:light[level=12]
setblock 292 216 313 minecraft:light[level=12]
setblock 293 216 278 minecraft:light[level=15]
setblock 293 216 286 minecraft:light[level=15]
setblock 293 216 302 minecraft:light[level=15]
setblock 293 216 310 minecraft:light[level=15]
setblock 299 216 278 minecraft:light[level=12]
setblock 299 216 313 minecraft:light[level=12]
setblock 301 216 278 minecraft:light[level=15]
setblock 301 216 310 minecraft:light[level=15]
setblock 306 216 278 minecraft:light[level=12]
setblock 306 216 306 minecraft:light[level=12]
setblock 306 216 313 minecraft:light[level=12]
setblock 309 216 278 minecraft:light[level=15]
setblock 309 216 286 minecraft:light[level=15]
setblock 309 216 302 minecraft:light[level=15]
setblock 309 216 310 minecraft:light[level=15]
setblock 313 216 278 minecraft:light[level=12]
setblock 313 216 285 minecraft:light[level=12]
setblock 313 216 292 minecraft:light[level=12]
setblock 313 216 306 minecraft:light[level=12]
setblock 313 216 313 minecraft:light[level=12]
setblock 317 216 278 minecraft:light[level=15]
setblock 317 216 286 minecraft:light[level=15]
setblock 317 216 294 minecraft:light[level=15]
setblock 317 216 302 minecraft:light[level=15]
setblock 317 216 310 minecraft:light[level=15]
setblock 320 216 278 minecraft:light[level=12]
setblock 320 216 285 minecraft:light[level=12]
setblock 320 216 292 minecraft:light[level=12]
setblock 320 216 299 minecraft:light[level=12]
setblock 320 216 306 minecraft:light[level=12]
setblock 320 216 313 minecraft:light[level=12]
fill 282 217 282 282 218 282 minecraft:gray_concrete
fill 294 217 292 294 217 296 minecraft:waxed_oxidized_copper
fill 295 217 290 295 217 291 minecraft:waxed_oxidized_copper
fill 295 217 297 295 217 298 minecraft:waxed_oxidized_copper
setblock 296 217 289 minecraft:waxed_oxidized_copper
setblock 296 217 299 minecraft:waxed_oxidized_copper
fill 297 217 288 298 217 288 minecraft:waxed_oxidized_copper
fill 297 217 300 298 217 300 minecraft:waxed_oxidized_copper
setblock 298 217 291 minecraft:waxed_copper_block
setblock 298 217 297 minecraft:waxed_copper_block
fill 299 217 287 303 217 287 minecraft:waxed_oxidized_copper
setblock 299 217 290 minecraft:waxed_copper_block
setblock 299 217 298 minecraft:waxed_copper_block
fill 299 217 301 303 217 301 minecraft:waxed_oxidized_copper
fill 304 217 288 305 217 288 minecraft:waxed_oxidized_copper
setblock 304 217 291 minecraft:waxed_copper_block
setblock 304 217 297 minecraft:waxed_copper_block
fill 304 217 300 305 217 300 minecraft:waxed_oxidized_copper
setblock 305 217 292 minecraft:waxed_copper_block
setblock 305 217 296 minecraft:waxed_copper_block
setblock 306 217 289 minecraft:waxed_oxidized_copper
setblock 306 217 299 minecraft:waxed_oxidized_copper
fill 307 217 290 307 217 291 minecraft:waxed_oxidized_copper
fill 307 217 297 307 217 298 minecraft:waxed_oxidized_copper
fill 308 217 292 308 217 296 minecraft:waxed_oxidized_copper
setblock 324 217 284 minecraft:sea_lantern
fill 282 218 309 282 220 309 minecraft:gray_concrete
setblock 282 218 310 minecraft:light_gray_concrete
fill 285 218 275 285 219 275 minecraft:gray_concrete
setblock 286 218 275 minecraft:light_gray_concrete
fill 287 218 275 288 219 275 minecraft:gray_concrete
setblock 290 218 317 minecraft:light_gray_concrete
setblock 292 218 317 minecraft:light_gray_concrete
fill 293 218 317 295 219 317 minecraft:gray_concrete
fill 302 218 275 302 219 275 minecraft:gray_concrete
setblock 303 218 275 minecraft:light_gray_concrete
setblock 304 218 275 minecraft:gray_concrete
setblock 305 218 275 minecraft:light_gray_concrete
fill 306 218 275 308 218 275 minecraft:gray_concrete
fill 306 218 317 307 218 317 minecraft:gray_concrete
fill 308 218 317 309 218 317 minecraft:light_gray_concrete
fill 310 218 317 311 220 317 minecraft:gray_concrete
setblock 312 218 317 minecraft:light_gray_concrete
fill 313 218 317 315 219 317 minecraft:gray_concrete
fill 315 218 275 316 219 275 minecraft:gray_concrete
setblock 317 218 275 minecraft:light_gray_concrete
fill 318 218 275 318 219 275 minecraft:gray_concrete
fill 324 218 280 324 220 280 minecraft:gray_concrete
setblock 324 218 281 minecraft:light_gray_concrete
fill 324 218 284 324 220 284 minecraft:gray_concrete
fill 324 218 296 324 218 297 minecraft:light_gray_concrete
fill 324 218 298 324 219 300 minecraft:gray_concrete
fill 324 218 301 324 218 303 minecraft:light_gray_concrete
fill 324 218 304 324 220 305 minecraft:gray_concrete
fill 324 218 315 324 219 315 minecraft:light_gray_concrete
fill 282 219 281 282 219 282 minecraft:light_gray_concrete
fill 282 219 285 282 220 286 minecraft:gray_concrete
setblock 282 219 287 minecraft:light_gray_concrete
fill 282 219 288 282 219 292 minecraft:gray_concrete
fill 282 219 293 282 219 294 minecraft:light_gray_concrete
setblock 282 219 297 minecraft:light_gray_concrete
setblock 282 219 303 minecraft:light_gray_concrete
setblock 282 219 304 minecraft:gray_concrete
setblock 282 219 305 minecraft:light_gray_concrete
fill 282 219 306 282 219 307 minecraft:gray_concrete
setblock 282 219 310 minecraft:gray_concrete
fill 283 219 277 283 270 277 minecraft:iron_block
fill 283 219 287 283 270 287 minecraft:iron_block
fill 283 219 297 283 270 297 minecraft:iron_block
fill 283 219 307 283 270 307 minecraft:iron_block
fill 284 219 316 284 270 316 minecraft:iron_block
fill 285 219 294 287 220 296 minecraft:iron_block
fill 285 219 312 287 270 314 minecraft:iron_block
setblock 286 219 275 minecraft:gray_concrete
fill 287 219 304 287 229 304 minecraft:iron_block
fill 290 219 276 290 270 276 minecraft:iron_block
fill 290 219 317 290 220 317 minecraft:gray_concrete
fill 292 219 317 292 220 317 minecraft:gray_concrete
fill 294 219 316 294 270 316 minecraft:iron_block
fill 295 219 275 296 219 275 minecraft:gray_concrete
setblock 297 219 275 minecraft:light_gray_concrete
fill 298 219 275 299 219 275 minecraft:gray_concrete
fill 300 219 275 301 219 275 minecraft:light_gray_concrete
fill 300 219 276 300 270 276 minecraft:iron_block
fill 303 219 275 303 220 275 minecraft:gray_concrete
setblock 303 219 317 minecraft:gray_concrete
setblock 304 219 275 minecraft:light_gray_concrete
fill 304 219 278 304 270 278 minecraft:iron_block
fill 304 219 316 304 270 316 minecraft:iron_block
setblock 304 219 317 minecraft:light_gray_concrete
setblock 305 219 275 minecraft:gray_concrete
fill 305 219 317 305 220 317 minecraft:gray_concrete
setblock 306 219 275 minecraft:light_gray_concrete
setblock 306 219 317 minecraft:light_gray_concrete
fill 307 219 275 308 219 275 minecraft:gray_concrete
fill 307 219 281 307 220 281 minecraft:iron_block
fill 307 219 317 309 219 317 minecraft:gray_concrete
fill 310 219 276 310 220 277 minecraft:iron_block
fill 311 219 277 323 219 277 minecraft:iron_block
fill 312 219 317 312 220 317 minecraft:gray_concrete
fill 314 219 297 322 219 297 minecraft:iron_block
fill 314 219 316 314 270 316 minecraft:iron_block
setblock 317 219 275 minecraft:gray_concrete
fill 319 219 295 321 270 295 minecraft:iron_block
fill 320 219 276 320 270 276 minecraft:iron_block
fill 320 219 287 322 220 287 minecraft:iron_block
fill 320 219 294 320 270 294 minecraft:iron_block
fill 320 219 296 320 270 296 minecraft:iron_block
setblock 320 219 317 minecraft:light_gray_concrete
fill 321 219 317 324 219 317 minecraft:gray_concrete
fill 323 219 283 323 270 283 minecraft:iron_block
fill 323 219 293 323 270 293 minecraft:iron_block
fill 323 219 303 323 270 303 minecraft:iron_block
fill 323 219 313 323 270 313 minecraft:iron_block
fill 324 219 281 324 220 281 minecraft:gray_concrete
fill 324 219 282 324 220 282 minecraft:light_gray_concrete
fill 324 219 283 324 220 283 minecraft:gray_concrete
setblock 324 219 290 minecraft:light_gray_concrete
fill 324 219 291 324 220 292 minecraft:gray_concrete
setblock 324 219 293 minecraft:light_gray_concrete
fill 324 219 294 324 219 297 minecraft:gray_concrete
fill 324 219 301 324 219 303 minecraft:gray_concrete
setblock 324 219 306 minecraft:light_gray_concrete
fill 324 219 307 324 219 309 minecraft:gray_concrete
setblock 282 220 278 minecraft:light_gray_concrete
fill 282 220 281 282 220 284 minecraft:pearlescent_froglight
fill 282 220 287 282 220 290 minecraft:gray_concrete
fill 282 220 291 282 220 294 minecraft:pearlescent_froglight
setblock 282 220 296 minecraft:light_gray_concrete
setblock 282 220 297 minecraft:gray_concrete
setblock 282 220 298 minecraft:light_gray_concrete
fill 282 220 299 282 220 300 minecraft:gray_concrete
fill 282 220 301 282 220 304 minecraft:pearlescent_froglight
fill 282 220 305 282 220 306 minecraft:gray_concrete
setblock 282 220 307 minecraft:light_gray_concrete
setblock 282 220 310 minecraft:sea_lantern
fill 282 220 311 282 220 314 minecraft:pearlescent_froglight
fill 283 220 282 289 221 282 minecraft:iron_block
fill 283 220 292 296 220 292 minecraft:iron_block
fill 283 220 302 285 221 302 minecraft:iron_block
fill 283 220 312 284 221 312 minecraft:iron_block
fill 284 220 277 309 220 277 minecraft:iron_block
fill 284 220 287 319 220 287 minecraft:iron_block
fill 284 220 297 297 220 297 minecraft:iron_block
fill 284 220 307 323 220 307 minecraft:iron_block
fill 285 220 275 288 220 275 minecraft:pearlescent_froglight
fill 286 220 317 289 220 317 minecraft:pearlescent_froglight
fill 288 220 312 289 221 312 minecraft:iron_block
fill 289 220 275 291 220 275 minecraft:gray_concrete
fill 292 220 275 293 220 275 minecraft:light_gray_concrete
setblock 293 220 317 minecraft:gray_concrete
setblock 294 220 275 minecraft:gray_concrete
setblock 294 220 317 minecraft:light_gray_concrete
fill 295 220 275 298 220 275 minecraft:pearlescent_froglight
setblock 295 220 317 minecraft:gray_concrete
fill 296 220 317 299 220 317 minecraft:pearlescent_froglight
fill 299 220 275 301 220 275 minecraft:gray_concrete
setblock 302 220 275 minecraft:light_gray_concrete
setblock 303 220 317 minecraft:light_gray_concrete
setblock 304 220 275 minecraft:gray_concrete
setblock 304 220 317 minecraft:gray_concrete
fill 305 220 275 308 220 275 minecraft:pearlescent_froglight
fill 306 220 292 323 220 292 minecraft:iron_block
fill 306 220 297 320 220 297 minecraft:iron_block
fill 306 220 317 309 220 317 minecraft:pearlescent_froglight
fill 309 220 275 310 220 275 minecraft:gray_concrete
setblock 311 220 275 minecraft:light_gray_concrete
fill 311 220 277 316 220 277 minecraft:iron_block
fill 312 220 275 314 220 275 minecraft:gray_concrete
setblock 313 220 317 minecraft:gray_concrete
setblock 314 220 317 minecraft:light_gray_concrete
fill 315 220 275 318 220 275 minecraft:pearlescent_froglight
setblock 315 220 317 minecraft:gray_concrete
fill 316 220 317 319 220 317 minecraft:pearlescent_froglight
setblock 319 220 275 minecraft:light_gray_concrete
fill 320 220 275 321 220 275 minecraft:gray_concrete
setblock 320 220 317 minecraft:gray_concrete
setblock 321 220 317 minecraft:light_gray_concrete
setblock 322 220 275 minecraft:light_gray_concrete
fill 322 220 317 324 220 317 minecraft:gray_concrete
setblock 323 220 275 minecraft:gray_concrete
setblock 324 220 275 minecraft:light_gray_concrete
fill 324 220 276 324 220 279 minecraft:pearlescent_froglight
setblock 324 220 285 minecraft:light_gray_concrete
fill 324 220 286 324 220 289 minecraft:pearlescent_froglight
setblock 324 220 290 minecraft:gray_concrete
fill 324 220 293 324 220 295 minecraft:gray_concrete
fill 324 220 296 324 220 299 minecraft:pearlescent_froglight
setblock 324 220 300 minecraft:gray_concrete
setblock 324 220 301 minecraft:light_gray_concrete
fill 324 220 302 324 220 303 minecraft:gray_concrete
fill 324 220 306 324 220 309 minecraft:pearlescent_froglight
setblock 324 220 315 minecraft:gray_concrete
setblock 324 220 316 minecraft:pearlescent_froglight
fill 282 221 275 282 222 276 minecraft:yellow_concrete
fill 282 221 277 282 222 278 minecraft:black_concrete
fill 282 221 279 282 222 280 minecraft:yellow_concrete
fill 282 221 281 282 222 282 minecraft:black_concrete
fill 282 221 283 282 222 284 minecraft:yellow_concrete
fill 282 221 285 282 222 286 minecraft:black_concrete
fill 282 221 287 282 222 288 minecraft:yellow_concrete
fill 282 221 289 282 222 290 minecraft:black_concrete
fill 282 221 291 282 222 292 minecraft:yellow_concrete
fill 282 221 293 282 222 294 minecraft:black_concrete
fill 282 221 295 282 222 296 minecraft:yellow_concrete
fill 282 221 297 282 222 298 minecraft:black_concrete
fill 282 221 299 282 222 300 minecraft:yellow_concrete
fill 282 221 301 282 222 302 minecraft:black_concrete
fill 282 221 303 282 222 304 minecraft:yellow_concrete
fill 282 221 305 282 222 306 minecraft:black_concrete
fill 282 221 307 282 222 308 minecraft:yellow_concrete
fill 282 221 309 282 222 310 minecraft:black_concrete
fill 282 221 311 282 222 312 minecraft:yellow_concrete
fill 282 221 313 282 222 314 minecraft:black_concrete
fill 282 221 315 282 222 316 minecraft:yellow_concrete
fill 282 221 317 282 222 317 minecraft:black_concrete
fill 283 221 275 283 222 275 minecraft:yellow_concrete
fill 283 221 292 286 221 292 minecraft:iron_block
fill 283 221 317 283 222 317 minecraft:yellow_concrete
fill 284 221 275 285 222 275 minecraft:black_concrete
fill 284 221 277 285 221 277 minecraft:iron_block
fill 284 221 287 286 221 287 minecraft:iron_block
fill 284 221 294 285 221 297 minecraft:iron_block
fill 284 221 303 284 221 311 minecraft:iron_block
fill 284 221 313 284 221 315 minecraft:iron_block
fill 284 221 317 285 222 317 minecraft:black_concrete
fill 285 221 293 286 221 293 minecraft:iron_block
fill 285 221 307 299 221 307 minecraft:iron_block
fill 285 221 311 287 221 311 minecraft:iron_block
fill 285 221 315 287 221 315 minecraft:iron_block
fill 286 221 275 287 222 275 minecraft:yellow_concrete
fill 286 221 294 288 222 294 minecraft:waxed_copper_block
fill 286 221 295 286 221 297 minecraft:iron_block
fill 286 221 302 315 221 302 minecraft:iron_block
fill 286 221 317 287 222 317 minecraft:yellow_concrete
fill 287 221 291 289 222 293 minecraft:waxed_copper_block
fill 287 221 295 289 222 297 minecraft:waxed_copper_block
fill 288 221 275 289 222 275 minecraft:black_concrete
fill 288 221 290 296 222 290 minecraft:waxed_copper_block
fill 288 221 298 296 222 298 minecraft:waxed_copper_block
fill 288 221 313 288 221 314 minecraft:iron_block
fill 288 221 317 289 222 317 minecraft:black_concrete
fill 289 221 289 295 222 289 minecraft:waxed_copper_block
fill 289 221 299 295 222 299 minecraft:waxed_copper_block
fill 290 221 275 291 222 275 minecraft:yellow_concrete
fill 290 221 282 323 221 282 minecraft:iron_block
fill 290 221 291 291 222 291 minecraft:waxed_copper_block
fill 290 221 292 294 221 292 minecraft:iron_block
fill 290 221 297 291 222 297 minecraft:waxed_copper_block
fill 290 221 312 323 221 312 minecraft:iron_block
fill 290 221 317 291 222 317 minecraft:yellow_concrete
fill 292 221 275 293 222 275 minecraft:black_concrete
fill 292 221 288 292 222 288 minecraft:waxed_copper_block
fill 292 221 300 292 222 300 minecraft:waxed_copper_block
fill 292 221 317 293 222 317 minecraft:black_concrete
fill 293 221 291 297 221 291 minecraft:waxed_copper_block
fill 293 221 297 297 221 297 minecraft:waxed_copper_block
fill 294 221 275 295 222 275 minecraft:yellow_concrete
fill 294 221 317 295 222 317 minecraft:yellow_concrete
fill 295 221 292 296 221 293 minecraft:waxed_copper_block
fill 295 221 295 296 221 296 minecraft:waxed_copper_block
fill 296 221 275 297 222 275 minecraft:black_concrete
setblock 296 221 294 minecraft:waxed_copper_block
fill 296 221 308 296 228 308 minecraft:iron_block
fill 296 221 317 297 222 317 minecraft:black_concrete
fill 298 221 275 299 222 275 minecraft:yellow_concrete
fill 298 221 317 299 222 317 minecraft:yellow_concrete
fill 299 221 310 299 222 311 minecraft:iron_block
fill 299 221 313 299 222 315 minecraft:iron_block
fill 300 221 275 301 222 275 minecraft:black_concrete
fill 300 221 317 301 222 317 minecraft:black_concrete
fill 302 221 275 303 222 275 minecraft:yellow_concrete
fill 302 221 317 303 222 317 minecraft:yellow_concrete
fill 303 221 277 303 221 279 minecraft:iron_block
fill 304 221 275 305 222 275 minecraft:black_concrete
fill 304 221 277 305 221 277 minecraft:iron_block
fill 304 221 279 305 221 279 minecraft:iron_block
fill 304 221 317 305 222 317 minecraft:black_concrete
setblock 305 221 278 minecraft:iron_block
fill 306 221 275 307 222 275 minecraft:yellow_concrete
fill 306 221 317 307 222 317 minecraft:yellow_concrete
fill 308 221 275 309 222 275 minecraft:black_concrete
fill 308 221 317 309 222 317 minecraft:black_concrete
fill 310 221 275 311 222 275 minecraft:yellow_concrete
fill 310 221 276 310 270 276 minecraft:iron_block
fill 310 221 317 311 222 317 minecraft:yellow_concrete
fill 312 221 275 313 222 275 minecraft:black_concrete
fill 312 221 317 313 222 317 minecraft:black_concrete
fill 314 221 275 315 222 275 minecraft:yellow_concrete
fill 314 221 317 315 222 317 minecraft:yellow_concrete
fill 316 221 275 317 222 275 minecraft:black_concrete
fill 316 221 317 317 222 317 minecraft:black_concrete
fill 318 221 275 319 222 275 minecraft:yellow_concrete
fill 318 221 317 319 222 317 minecraft:yellow_concrete
fill 319 221 294 319 222 294 minecraft:iron_block
fill 319 221 296 319 222 296 minecraft:iron_block
fill 319 221 304 319 221 311 minecraft:iron_block
fill 319 221 313 319 221 316 minecraft:iron_block
fill 320 221 275 321 222 275 minecraft:black_concrete
fill 320 221 317 321 222 317 minecraft:black_concrete
setblock 321 221 294 minecraft:iron_block
setblock 321 221 296 minecraft:iron_block
fill 322 221 275 323 222 275 minecraft:yellow_concrete
fill 322 221 317 323 222 317 minecraft:yellow_concrete
fill 324 221 275 324 222 275 minecraft:black_concrete
fill 324 221 276 324 222 276 minecraft:yellow_concrete
fill 324 221 277 324 222 278 minecraft:black_concrete
fill 324 221 279 324 222 280 minecraft:yellow_concrete
fill 324 221 281 324 222 282 minecraft:black_concrete
fill 324 221 283 324 222 284 minecraft:yellow_concrete
fill 324 221 285 324 222 286 minecraft:black_concrete
fill 324 221 287 324 222 288 minecraft:yellow_concrete
fill 324 221 289 324 222 290 minecraft:black_concrete
fill 324 221 291 324 222 292 minecraft:yellow_concrete
fill 324 221 293 324 222 294 minecraft:black_concrete
fill 324 221 295 324 222 296 minecraft:yellow_concrete
fill 324 221 297 324 222 298 minecraft:black_concrete
fill 324 221 299 324 222 300 minecraft:yellow_concrete
fill 324 221 301 324 222 302 minecraft:black_concrete
fill 324 221 303 324 222 304 minecraft:yellow_concrete
fill 324 221 305 324 222 306 minecraft:black_concrete
fill 324 221 307 324 222 308 minecraft:yellow_concrete
fill 324 221 309 324 222 310 minecraft:black_concrete
fill 324 221 311 324 222 312 minecraft:yellow_concrete
fill 324 221 313 324 222 314 minecraft:black_concrete
fill 324 221 315 324 222 316 minecraft:yellow_concrete
fill 324 221 317 324 222 317 minecraft:black_concrete
fill 283 222 278 284 222 278 minecraft:iron_block
fill 283 222 288 284 222 288 minecraft:iron_block
fill 283 222 298 284 222 298 minecraft:iron_block
fill 283 222 308 284 222 308 minecraft:iron_block
fill 284 222 276 284 223 277 minecraft:iron_block
fill 284 222 279 284 222 287 minecraft:iron_block
fill 284 222 289 284 222 297 minecraft:iron_block
fill 284 222 299 284 222 307 minecraft:iron_block
setblock 285 222 278 minecraft:light[level=12]
setblock 285 222 285 minecraft:light[level=12]
setblock 285 222 292 minecraft:light[level=12]
fill 285 222 294 285 270 296 minecraft:iron_block
setblock 285 222 299 minecraft:light[level=12]
setblock 285 222 306 minecraft:light[level=12]
setblock 285 222 316 minecraft:iron_block
fill 286 222 295 286 270 296 minecraft:iron_block
fill 289 222 276 289 223 278 minecraft:iron_block
setblock 292 222 278 minecraft:light[level=12]
setblock 292 222 285 minecraft:light[level=12]
setblock 292 222 292 minecraft:light[level=12]
setblock 292 222 306 minecraft:light[level=12]
setblock 292 222 313 minecraft:light[level=12]
fill 293 222 291 296 222 291 minecraft:waxed_copper_block
fill 293 222 297 296 222 297 minecraft:waxed_copper_block
fill 294 222 276 294 222 288 minecraft:iron_block
fill 294 222 292 294 222 296 minecraft:iron_block
fill 294 222 300 294 222 315 minecraft:iron_block
fill 295 222 292 295 222 293 minecraft:waxed_copper_block
fill 295 222 295 295 222 296 minecraft:waxed_copper_block
fill 295 222 308 295 227 308 minecraft:iron_block
setblock 295 222 316 minecraft:iron_block
setblock 296 222 292 minecraft:waxed_copper_block
setblock 296 222 296 minecraft:waxed_copper_block
fill 299 222 276 299 222 289 minecraft:iron_block
fill 299 222 299 299 222 309 minecraft:iron_block
setblock 299 222 312 minecraft:iron_block
fill 304 222 276 304 223 277 minecraft:iron_block
fill 304 222 279 304 223 289 minecraft:iron_block
setblock 305 222 316 minecraft:iron_block
setblock 306 222 278 minecraft:light[level=12]
setblock 306 222 285 minecraft:light[level=12]
setblock 306 222 292 minecraft:light[level=12]
setblock 306 222 299 minecraft:light[level=12]
setblock 306 222 306 minecraft:light[level=12]
setblock 306 222 313 minecraft:light[level=12]
fill 309 222 276 309 223 278 minecraft:iron_block
fill 310 222 302 323 222 302 minecraft:iron_block
setblock 313 222 278 minecraft:light[level=12]
setblock 313 222 285 minecraft:light[level=12]
setblock 313 222 292 minecraft:light[level=12]
setblock 313 222 299 minecraft:light[level=12]
setblock 313 222 306 minecraft:light[level=12]
setblock 313 222 313 minecraft:light[level=12]
fill 314 222 276 314 222 301 minecraft:iron_block
fill 314 222 303 314 222 315 minecraft:iron_block
setblock 315 222 316 minecraft:iron_block
fill 319 222 276 319 222 293 minecraft:iron_block
fill 319 222 297 319 222 301 minecraft:iron_block
fill 319 222 303 319 222 309 minecraft:iron_block
setblock 320 222 278 minecraft:light[level=12]
setblock 320 222 285 minecraft:light[level=12]
setblock 320 222 292 minecraft:light[level=12]
setblock 320 222 299 minecraft:light[level=12]
setblock 320 222 306 minecraft:light[level=12]
setblock 320 222 313 minecraft:light[level=12]
setblock 323 222 282 minecraft:iron_block
setblock 323 222 292 minecraft:iron_block
setblock 323 222 312 minecraft:iron_block
fill 282 223 275 282 223 283 minecraft:light_gray_concrete
setblock 282 223 284 minecraft:gray_concrete
fill 282 223 285 282 223 290 minecraft:light_gray_concrete
setblock 282 223 291 minecraft:gray_concrete
fill 282 223 292 282 223 317 minecraft:light_gray_concrete
fill 283 223 275 291 228 275 minecraft:light_gray_concrete
fill 283 223 317 285 248 317 minecraft:light_gray_concrete
setblock 284 223 278 minecraft:iron_block
fill 286 223 294 287 270 294 minecraft:iron_block
setblock 286 223 317 minecraft:redstone_block
fill 287 223 295 287 270 296 minecraft:iron_block
fill 287 223 317 288 228 317 minecraft:light_gray_concrete
fill 289 223 279 289 223 308 minecraft:iron_block
fill 289 223 317 290 223 317 minecraft:gray_concrete
fill 291 223 317 295 248 317 minecraft:light_gray_concrete
setblock 292 223 275 minecraft:gray_concrete
setblock 293 223 275 minecraft:light_gray_concrete
setblock 294 223 275 minecraft:gray_concrete
fill 294 223 276 294 223 281 minecraft:iron_block
fill 295 223 275 302 223 275 minecraft:light_gray_concrete
fill 296 223 317 297 223 317 minecraft:gray_concrete
fill 298 223 317 324 223 317 minecraft:light_gray_concrete
fill 299 223 276 299 223 279 minecraft:iron_block
setblock 303 223 275 minecraft:gray_concrete
fill 304 223 275 321 223 275 minecraft:light_gray_concrete
fill 304 223 299 304 223 315 minecraft:iron_block
fill 309 223 279 309 223 307 minecraft:iron_block
fill 314 223 276 314 223 281 minecraft:iron_block
fill 319 223 276 319 223 278 minecraft:iron_block
setblock 322 223 275 minecraft:gray_concrete
fill 323 223 275 324 233 275 minecraft:light_gray_concrete
fill 324 223 276 324 228 277 minecraft:light_gray_concrete
fill 324 223 278 324 223 279 minecraft:gray_concrete
fill 324 223 280 324 223 286 minecraft:light_gray_concrete
setblock 324 223 287 minecraft:gray_concrete
fill 324 223 288 324 223 305 minecraft:light_gray_concrete
fill 324 223 306 324 223 307 minecraft:gray_concrete
fill 324 223 308 324 228 308 minecraft:light_gray_concrete
setblock 324 223 309 minecraft:gray_concrete
fill 324 223 310 324 223 314 minecraft:light_gray_concrete
setblock 324 223 315 minecraft:gray_concrete
fill 324 223 316 324 228 316 minecraft:light_gray_concrete
fill 282 224 275 282 228 282 minecraft:light_gray_concrete
setblock 282 224 283 minecraft:gray_concrete
fill 282 224 284 282 228 284 minecraft:light_gray_concrete
setblock 282 224 285 minecraft:gray_concrete
fill 282 224 286 282 228 291 minecraft:light_gray_concrete
setblock 282 224 292 minecraft:gray_concrete
fill 282 224 293 282 228 300 minecraft:light_gray_concrete
fill 282 224 301 282 224 302 minecraft:gray_concrete
fill 282 224 303 282 228 305 minecraft:light_gray_concrete
fill 282 224 306 282 224 307 minecraft:gray_concrete
fill 282 224 308 282 248 308 minecraft:light_gray_concrete
setblock 282 224 309 minecraft:gray_concrete
fill 282 224 310 282 228 317 minecraft:light_gray_concrete
setblock 285 224 278 minecraft:light[level=15]
setblock 285 224 286 minecraft:light[level=15]
setblock 285 224 302 minecraft:light[level=15]
setblock 285 224 310 minecraft:light[level=15]
fill 286 224 317 286 228 317 minecraft:light_gray_concrete
fill 289 224 303 289 224 316 minecraft:iron_block
fill 289 224 317 290 228 317 minecraft:light_gray_concrete
fill 292 224 275 292 244 275 minecraft:light_gray_concrete
setblock 293 224 275 minecraft:gray_concrete
setblock 293 224 278 minecraft:light[level=15]
setblock 293 224 286 minecraft:light[level=15]
setblock 293 224 294 minecraft:light[level=15]
setblock 293 224 302 minecraft:light[level=15]
setblock 293 224 310 minecraft:light[level=15]
fill 294 224 275 296 228 275 minecraft:light_gray_concrete
fill 296 224 317 306 228 317 minecraft:light_gray_concrete
setblock 297 224 275 minecraft:gray_concrete
fill 298 224 275 313 228 275 minecraft:light_gray_concrete
setblock 301 224 278 minecraft:light[level=15]
setblock 301 224 286 minecraft:light[level=15]
setblock 301 224 302 minecraft:light[level=15]
setblock 301 224 310 minecraft:light[level=15]
setblock 307 224 317 minecraft:gray_concrete
fill 308 224 317 310 228 317 minecraft:light_gray_concrete
setblock 309 224 278 minecraft:light[level=15]
setblock 309 224 286 minecraft:light[level=15]
setblock 309 224 294 minecraft:light[level=15]
fill 309 224 302 309 224 316 minecraft:iron_block
setblock 311 224 317 minecraft:gray_concrete
fill 312 224 317 324 224 317 minecraft:light_gray_concrete
setblock 314 224 275 minecraft:gray_concrete
fill 315 224 275 322 228 275 minecraft:light_gray_concrete
setblock 317 224 278 minecraft:light[level=15]
setblock 317 224 286 minecraft:light[level=15]
setblock 317 224 294 minecraft:light[level=15]
setblock 317 224 302 minecraft:light[level=15]
setblock 317 224 310 minecraft:light[level=15]
fill 324 224 278 324 228 284 minecraft:light_gray_concrete
setblock 324 224 285 minecraft:sea_lantern
fill 324 224 286 324 227 296 minecraft:light_gray_concrete
setblock 324 224 297 minecraft:gray_concrete
fill 324 224 298 324 228 298 minecraft:light_gray_concrete
fill 324 224 299 324 224 300 minecraft:gray_concrete
fill 324 224 301 324 227 307 minecraft:light_gray_concrete
fill 324 224 309 324 228 311 minecraft:light_gray_concrete
setblock 324 224 312 minecraft:gray_concrete
fill 324 224 313 324 248 315 minecraft:light_gray_concrete
fill 282 225 283 282 228 283 minecraft:light_gray_concrete
fill 282 225 285 282 228 285 minecraft:light_gray_concrete
fill 282 225 292 282 228 292 minecraft:light_gray_concrete
fill 282 225 301 282 228 302 minecraft:light_gray_concrete
fill 282 225 306 282 248 307 minecraft:light_gray_concrete
fill 282 225 309 282 248 309 minecraft:light_gray_concrete
fill 283 225 280 283 225 283 minecraft:iron_block
fill 283 225 290 283 225 293 minecraft:iron_block
fill 283 225 300 283 225 303 minecraft:iron_block
fill 283 225 310 283 225 313 minecraft:iron_block
fill 284 225 276 287 225 276 minecraft:iron_block
fill 287 225 316 290 225 316 minecraft:iron_block
fill 293 225 275 293 230 275 minecraft:light_gray_concrete
fill 294 225 276 297 225 276 minecraft:iron_block
fill 297 225 275 297 228 275 minecraft:light_gray_concrete
fill 297 225 316 300 225 316 minecraft:iron_block
fill 304 225 276 307 225 276 minecraft:iron_block
fill 307 225 316 310 225 316 minecraft:iron_block
fill 307 225 317 307 228 317 minecraft:light_gray_concrete
fill 311 225 317 318 228 317 minecraft:light_gray_concrete
fill 314 225 275 314 248 275 minecraft:light_gray_concrete
fill 314 225 276 317 225 276 minecraft:iron_block
fill 317 225 316 320 225 316 minecraft:iron_block
setblock 319 225 317 minecraft:redstone_block
fill 320 225 317 324 248 317 minecraft:light_gray_concrete
fill 323 225 277 323 225 280 minecraft:iron_block
fill 323 225 287 323 225 290 minecraft:iron_block
fill 323 225 297 323 225 300 minecraft:iron_block
fill 323 225 307 323 225 310 minecraft:iron_block
fill 324 225 285 324 248 285 minecraft:light_gray_concrete
fill 324 225 297 324 228 297 minecraft:light_gray_concrete
fill 324 225 299 324 228 300 minecraft:light_gray_concrete
fill 324 225 312 324 248 312 minecraft:light_gray_concrete
fill 319 226 317 319 228 317 minecraft:light_gray_concrete
fill 303 227 277 303 227 279 minecraft:iron_block
fill 304 227 277 305 227 277 minecraft:iron_block
fill 304 227 279 305 227 279 minecraft:iron_block
setblock 305 227 278 minecraft:iron_block
fill 309 227 278 313 228 282 minecraft:gray_concrete
fill 311 227 276 311 227 277 minecraft:gray_concrete
setblock 283 228 278 minecraft:iron_block
setblock 283 228 288 minecraft:iron_block
setblock 283 228 298 minecraft:iron_block
setblock 283 228 308 minecraft:iron_block
fill 284 228 294 284 228 296 minecraft:iron_block
fill 284 228 312 284 228 314 minecraft:iron_block
setblock 285 228 278 minecraft:light[level=12]
setblock 285 228 285 minecraft:light[level=12]
setblock 285 228 292 minecraft:light[level=12]
fill 285 228 293 287 228 293 minecraft:iron_block
fill 285 228 297 287 228 297 minecraft:iron_block
setblock 285 228 299 minecraft:light[level=12]
setblock 285 228 306 minecraft:light[level=12]
fill 285 228 311 287 228 311 minecraft:iron_block
fill 285 228 315 285 228 316 minecraft:iron_block
fill 286 228 315 287 228 315 minecraft:iron_block
fill 288 228 294 288 228 296 minecraft:iron_block
fill 288 228 312 288 228 314 minecraft:iron_block
setblock 289 228 276 minecraft:iron_block
setblock 292 228 278 minecraft:light[level=12]
setblock 292 228 285 minecraft:light[level=12]
setblock 292 228 292 minecraft:light[level=12]
setblock 292 228 299 minecraft:light[level=12]
setblock 292 228 306 minecraft:light[level=12]
setblock 292 228 313 minecraft:light[level=12]
setblock 295 228 316 minecraft:iron_block
setblock 299 228 276 minecraft:iron_block
setblock 299 228 278 minecraft:light[level=12]
setblock 299 228 285 minecraft:light[level=12]
setblock 299 228 292 minecraft:light[level=12]
setblock 299 228 299 minecraft:light[level=12]
setblock 299 228 306 minecraft:light[level=12]
setblock 299 228 313 minecraft:light[level=12]
setblock 305 228 316 minecraft:iron_block
setblock 306 228 278 minecraft:light[level=12]
setblock 306 228 285 minecraft:light[level=12]
setblock 306 228 292 minecraft:light[level=12]
setblock 306 228 299 minecraft:light[level=12]
setblock 306 228 306 minecraft:light[level=12]
setblock 306 228 313 minecraft:light[level=12]
setblock 309 228 276 minecraft:iron_block
setblock 313 228 285 minecraft:light[level=12]
setblock 313 228 292 minecraft:light[level=12]
setblock 313 228 299 minecraft:light[level=12]
setblock 313 228 306 minecraft:light[level=12]
setblock 313 228 313 minecraft:light[level=12]
setblock 315 228 316 minecraft:iron_block
setblock 319 228 276 minecraft:iron_block
setblock 319 228 294 minecraft:iron_block
setblock 319 228 296 minecraft:iron_block
setblock 320 228 278 minecraft:light[level=12]
setblock 320 228 285 minecraft:light[level=12]
setblock 320 228 292 minecraft:light[level=12]
setblock 320 228 299 minecraft:light[level=12]
setblock 320 228 306 minecraft:light[level=12]
setblock 320 228 313 minecraft:light[level=12]
setblock 321 228 294 minecraft:iron_block
setblock 321 228 296 minecraft:iron_block
setblock 323 228 282 minecraft:iron_block
setblock 323 228 292 minecraft:iron_block
setblock 323 228 302 minecraft:iron_block
setblock 323 228 312 minecraft:iron_block
fill 324 228 286 324 228 291 minecraft:light_gray_concrete
setblock 324 228 292 minecraft:sea_lantern
fill 324 228 293 324 228 296 minecraft:light_gray_concrete
fill 324 228 301 324 248 303 minecraft:light_gray_concrete
setblock 324 228 304 minecraft:sea_lantern
fill 324 228 305 324 228 307 minecraft:light_gray_concrete
fill 282 229 275 282 248 280 minecraft:light_gray_concrete
fill 282 229 281 282 229 284 minecraft:pearlescent_froglight
setblock 282 229 285 minecraft:sea_lantern
fill 282 229 286 282 248 290 minecraft:light_gray_concrete
fill 282 229 291 282 229 294 minecraft:pearlescent_froglight
fill 282 229 295 282 235 300 minecraft:light_gray_concrete
fill 282 229 301 282 229 304 minecraft:pearlescent_froglight
fill 282 229 305 282 248 305 minecraft:light_gray_concrete
fill 282 229 310 282 248 310 minecraft:light_gray_concrete
fill 282 229 311 282 229 314 minecraft:pearlescent_froglight
fill 282 229 315 282 230 317 minecraft:light_gray_concrete
fill 283 229 275 284 248 275 minecraft:light_gray_concrete
fill 285 229 275 288 229 275 minecraft:pearlescent_froglight
fill 286 229 317 289 229 317 minecraft:pearlescent_froglight
fill 289 229 275 291 248 275 minecraft:light_gray_concrete
fill 290 229 317 290 248 317 minecraft:light_gray_concrete
fill 294 229 275 294 241 275 minecraft:light_gray_concrete
fill 295 229 275 298 229 275 minecraft:pearlescent_froglight
fill 296 229 317 299 229 317 minecraft:pearlescent_froglight
fill 299 229 275 304 248 275 minecraft:light_gray_concrete
fill 300 229 317 305 248 317 minecraft:light_gray_concrete
fill 305 229 275 308 229 275 minecraft:pearlescent_froglight
fill 306 229 317 309 229 317 minecraft:pearlescent_froglight
fill 309 229 275 313 248 275 minecraft:light_gray_concrete
fill 310 229 317 315 232 317 minecraft:light_gray_concrete
fill 315 229 275 318 229 275 minecraft:pearlescent_froglight
fill 316 229 317 319 229 317 minecraft:pearlescent_froglight
fill 319 229 275 322 248 275 minecraft:light_gray_concrete
fill 324 229 276 324 229 279 minecraft:pearlescent_froglight
fill 324 229 280 324 247 284 minecraft:light_gray_concrete
fill 324 229 286 324 229 289 minecraft:pearlescent_froglight
fill 324 229 290 324 248 295 minecraft:light_gray_concrete
fill 324 229 296 324 229 299 minecraft:pearlescent_froglight
fill 324 229 300 324 248 300 minecraft:light_gray_concrete
fill 324 229 304 324 248 305 minecraft:light_gray_concrete
fill 324 229 306 324 229 309 minecraft:pearlescent_froglight
fill 324 229 310 324 236 311 minecraft:light_gray_concrete
setblock 324 229 316 minecraft:pearlescent_froglight
fill 282 230 281 282 237 285 minecraft:light_gray_concrete
fill 282 230 291 282 237 294 minecraft:light_gray_concrete
fill 282 230 301 282 237 304 minecraft:light_gray_concrete
fill 282 230 311 282 237 314 minecraft:light_gray_concrete
fill 285 230 275 288 237 275 minecraft:light_gray_concrete
fill 286 230 317 289 237 317 minecraft:light_gray_concrete
fill 295 230 275 298 237 275 minecraft:light_gray_concrete
fill 296 230 317 299 237 317 minecraft:light_gray_concrete
fill 305 230 275 308 237 275 minecraft:light_gray_concrete
fill 306 230 317 309 237 317 minecraft:light_gray_concrete
fill 315 230 275 318 237 275 minecraft:light_gray_concrete
fill 316 230 317 317 237 317 minecraft:light_gray_concrete
setblock 318 230 317 minecraft:redstone_block
fill 319 230 317 319 237 317 minecraft:light_gray_concrete
fill 324 230 276 324 237 279 minecraft:light_gray_concrete
fill 324 230 286 324 237 289 minecraft:light_gray_concrete
fill 324 230 296 324 237 299 minecraft:light_gray_concrete
fill 324 230 306 324 232 309 minecraft:light_gray_concrete
fill 324 230 316 324 237 316 minecraft:light_gray_concrete
setblock 282 231 315 minecraft:sea_lantern
fill 282 231 316 282 235 317 minecraft:light_gray_concrete
setblock 293 231 275 minecraft:redstone_block
fill 318 231 317 318 237 317 minecraft:light_gray_concrete
fill 282 232 315 282 240 315 minecraft:light_gray_concrete
fill 283 232 296 284 233 296 minecraft:iron_block
fill 284 232 297 297 233 297 minecraft:iron_block
setblock 285 232 278 minecraft:light[level=15]
setblock 285 232 286 minecraft:light[level=15]
setblock 285 232 302 minecraft:light[level=15]
setblock 285 232 310 minecraft:light[level=15]
fill 288 232 296 288 233 296 minecraft:iron_block
fill 293 232 275 293 245 275 minecraft:light_gray_concrete
setblock 293 232 278 minecraft:light[level=15]
setblock 293 232 286 minecraft:light[level=15]
setblock 293 232 294 minecraft:light[level=15]
setblock 293 232 302 minecraft:light[level=15]
setblock 293 232 310 minecraft:light[level=15]
fill 300 232 298 300 233 298 minecraft:iron_block
setblock 301 232 278 minecraft:light[level=15]
setblock 301 232 286 minecraft:light[level=15]
setblock 301 232 294 minecraft:light[level=15]
setblock 301 232 302 minecraft:light[level=15]
setblock 301 232 310 minecraft:light[level=15]
fill 308 232 278 308 233 282 minecraft:iron_block
fill 309 232 277 309 233 278 minecraft:iron_block
fill 309 232 280 314 233 280 minecraft:iron_block
fill 309 232 282 309 233 283 minecraft:iron_block
setblock 309 232 286 minecraft:light[level=15]
setblock 309 232 294 minecraft:light[level=15]
setblock 309 232 302 minecraft:light[level=15]
setblock 309 232 310 minecraft:light[level=15]
fill 310 232 277 313 233 277 minecraft:iron_block
fill 310 232 283 313 233 283 minecraft:iron_block
fill 311 232 278 311 233 279 minecraft:iron_block
fill 311 232 281 311 233 282 minecraft:iron_block
fill 313 232 278 314 233 278 minecraft:iron_block
fill 313 232 282 314 233 282 minecraft:iron_block
fill 314 232 279 314 233 279 minecraft:iron_block
fill 314 232 281 314 233 281 minecraft:iron_block
setblock 317 232 278 minecraft:light[level=15]
setblock 317 232 286 minecraft:light[level=15]
setblock 317 232 294 minecraft:light[level=15]
setblock 317 232 302 minecraft:light[level=15]
setblock 317 232 310 minecraft:light[level=15]
fill 289 233 296 290 233 296 minecraft:iron_block
fill 292 233 298 299 233 298 minecraft:iron_block
fill 298 233 297 300 233 297 minecraft:iron_block
fill 303 233 277 303 233 279 minecraft:iron_block
fill 304 233 277 305 233 277 minecraft:iron_block
fill 304 233 279 305 233 279 minecraft:iron_block
setblock 305 233 278 minecraft:iron_block
fill 305 233 299 323 233 299 minecraft:iron_block
fill 306 233 298 316 233 298 minecraft:iron_block
setblock 310 233 317 minecraft:sea_lantern
fill 311 233 317 315 248 317 minecraft:light_gray_concrete
fill 320 233 292 322 234 292 minecraft:iron_block
fill 320 233 300 323 233 300 minecraft:iron_block
fill 324 233 306 324 237 308 minecraft:light_gray_concrete
setblock 324 233 309 minecraft:redstone_block
setblock 283 234 278 minecraft:iron_block
fill 283 234 280 283 234 283 minecraft:iron_block
setblock 283 234 288 minecraft:iron_block
fill 283 234 290 283 234 293 minecraft:iron_block
fill 283 234 296 284 234 296 minecraft:light_gray_concrete
setblock 283 234 298 minecraft:iron_block
fill 283 234 300 283 234 303 minecraft:iron_block
setblock 283 234 308 minecraft:iron_block
fill 283 234 310 283 234 313 minecraft:iron_block
fill 284 234 276 287 234 276 minecraft:iron_block
setblock 285 234 278 minecraft:light[level=12]
setblock 285 234 285 minecraft:light[level=12]
setblock 285 234 292 minecraft:light[level=12]
fill 285 234 297 297 234 297 minecraft:light_gray_concrete
setblock 285 234 299 minecraft:light[level=12]
setblock 285 234 306 minecraft:light[level=12]
setblock 285 234 316 minecraft:iron_block
fill 287 234 316 290 234 316 minecraft:iron_block
setblock 289 234 276 minecraft:iron_block
setblock 292 234 278 minecraft:light[level=12]
setblock 292 234 285 minecraft:light[level=12]
setblock 292 234 292 minecraft:light[level=12]
setblock 292 234 299 minecraft:light[level=12]
setblock 292 234 306 minecraft:light[level=12]
setblock 292 234 313 minecraft:light[level=12]
fill 294 234 276 297 234 276 minecraft:iron_block
setblock 295 234 316 minecraft:iron_block
fill 297 234 316 300 234 316 minecraft:iron_block
setblock 299 234 276 minecraft:iron_block
setblock 299 234 278 minecraft:light[level=12]
setblock 299 234 285 minecraft:light[level=12]
setblock 299 234 292 minecraft:light[level=12]
fill 299 234 298 300 234 298 minecraft:light_gray_concrete
setblock 299 234 299 minecraft:light[level=12]
setblock 299 234 306 minecraft:light[level=12]
setblock 299 234 313 minecraft:light[level=12]
fill 304 234 276 307 234 276 minecraft:iron_block
setblock 305 234 316 minecraft:iron_block
setblock 306 234 278 minecraft:light[level=12]
setblock 306 234 285 minecraft:light[level=12]
setblock 306 234 292 minecraft:light[level=12]
fill 306 234 298 313 234 298 minecraft:iron_block
setblock 306 234 299 minecraft:light[level=12]
setblock 306 234 306 minecraft:light[level=12]
setblock 306 234 313 minecraft:light[level=12]
fill 307 234 316 310 234 316 minecraft:iron_block
setblock 309 234 276 minecraft:iron_block
fill 310 234 317 310 248 317 minecraft:light_gray_concrete
fill 311 234 299 323 234 299 minecraft:iron_block
setblock 313 234 278 minecraft:light[level=12]
setblock 313 234 285 minecraft:light[level=12]
setblock 313 234 292 minecraft:light[level=12]
setblock 313 234 306 minecraft:light[level=12]
setblock 313 234 313 minecraft:light[level=12]
fill 314 234 276 317 234 276 minecraft:iron_block
setblock 315 234 316 minecraft:iron_block
fill 317 234 316 320 234 316 minecraft:iron_block
setblock 319 234 276 minecraft:iron_block
setblock 320 234 278 minecraft:light[level=12]
setblock 320 234 285 minecraft:light[level=12]
setblock 320 234 306 minecraft:light[level=12]
setblock 320 234 313 minecraft:light[level=12]
fill 321 234 300 323 234 300 minecraft:iron_block
setblock 323 234 275 minecraft:sea_lantern
fill 323 234 277 323 234 280 minecraft:iron_block
setblock 323 234 282 minecraft:iron_block
fill 323 234 287 323 234 290 minecraft:iron_block
setblock 323 234 292 minecraft:iron_block
fill 323 234 297 323 234 298 minecraft:iron_block
setblock 323 234 302 minecraft:iron_block
fill 323 234 307 323 234 310 minecraft:iron_block
setblock 323 234 312 minecraft:iron_block
fill 324 234 275 324 248 275 minecraft:light_gray_concrete
fill 324 234 309 324 237 309 minecraft:light_gray_concrete
fill 284 235 294 284 235 296 minecraft:iron_block
fill 284 235 312 284 235 314 minecraft:iron_block
fill 285 235 293 287 235 293 minecraft:iron_block
fill 285 235 297 287 235 297 minecraft:iron_block
fill 285 235 311 287 235 311 minecraft:iron_block
fill 285 235 315 287 235 315 minecraft:iron_block
fill 287 235 298 288 242 298 minecraft:iron_block
fill 288 235 294 288 235 296 minecraft:iron_block
fill 288 235 312 288 235 314 minecraft:iron_block
fill 306 235 298 308 235 298 minecraft:light_gray_concrete
fill 313 235 299 322 235 299 minecraft:light_gray_concrete
setblock 319 235 294 minecraft:iron_block
setblock 319 235 296 minecraft:iron_block
setblock 321 235 294 minecraft:iron_block
setblock 321 235 296 minecraft:iron_block
fill 323 235 275 323 248 275 minecraft:light_gray_concrete
fill 282 236 295 282 248 295 minecraft:light_gray_concrete
setblock 282 236 296 minecraft:sea_lantern
fill 282 236 297 282 246 300 minecraft:light_gray_concrete
setblock 282 236 316 minecraft:sea_lantern
fill 282 236 317 282 248 317 minecraft:light_gray_concrete
fill 282 237 296 282 248 296 minecraft:light_gray_concrete
fill 282 237 316 282 248 316 minecraft:light_gray_concrete
setblock 324 237 310 minecraft:sea_lantern
fill 324 237 311 324 248 311 minecraft:light_gray_concrete
fill 282 238 281 282 238 284 minecraft:pearlescent_froglight
fill 282 238 285 282 248 285 minecraft:light_gray_concrete
fill 282 238 291 282 238 294 minecraft:pearlescent_froglight
fill 282 238 301 282 238 304 minecraft:pearlescent_froglight
fill 282 238 311 282 238 314 minecraft:pearlescent_froglight
fill 285 238 275 288 238 275 minecraft:pearlescent_froglight
fill 286 238 317 289 238 317 minecraft:pearlescent_froglight
fill 295 238 275 298 238 275 minecraft:pearlescent_froglight
fill 296 238 317 299 238 317 minecraft:pearlescent_froglight
fill 305 238 275 308 238 275 minecraft:pearlescent_froglight
fill 306 238 317 309 238 317 minecraft:pearlescent_froglight
fill 309 238 312 310 239 315 minecraft:iron_block
fill 310 238 311 310 239 311 minecraft:iron_block
fill 310 238 316 310 239 316 minecraft:iron_block
fill 315 238 275 318 238 275 minecraft:pearlescent_froglight
fill 316 238 317 319 238 317 minecraft:pearlescent_froglight
fill 324 238 276 324 238 279 minecraft:pearlescent_froglight
fill 324 238 286 324 238 289 minecraft:pearlescent_froglight
fill 324 238 296 324 238 299 minecraft:pearlescent_froglight
fill 324 238 306 324 238 309 minecraft:pearlescent_froglight
fill 324 238 310 324 248 310 minecraft:light_gray_concrete
setblock 324 238 316 minecraft:pearlescent_froglight
fill 282 239 281 282 246 284 minecraft:light_gray_concrete
fill 282 239 291 282 242 294 minecraft:light_gray_concrete
fill 282 239 301 282 246 304 minecraft:light_gray_concrete
fill 282 239 311 282 246 314 minecraft:light_gray_concrete
fill 283 239 294 284 240 296 minecraft:iron_block
fill 285 239 275 288 246 275 minecraft:light_gray_concrete
fill 286 239 317 289 246 317 minecraft:light_gray_concrete
fill 295 239 275 298 246 275 minecraft:light_gray_concrete
fill 296 239 317 299 246 317 minecraft:light_gray_concrete
fill 303 239 277 303 239 279 minecraft:iron_block
fill 304 239 277 305 239 277 minecraft:iron_block
fill 304 239 279 305 239 279 minecraft:iron_block
fill 305 239 275 308 246 275 minecraft:light_gray_concrete
setblock 305 239 278 minecraft:iron_block
fill 306 239 317 309 246 317 minecraft:light_gray_concrete
fill 309 239 296 309 239 311 minecraft:iron_block
fill 310 239 300 310 239 310 minecraft:iron_block
fill 315 239 275 318 246 275 minecraft:light_gray_concrete
fill 316 239 317 319 246 317 minecraft:light_gray_concrete
fill 324 239 276 324 246 279 minecraft:light_gray_concrete
fill 324 239 286 324 246 289 minecraft:light_gray_concrete
fill 324 239 296 324 246 299 minecraft:light_gray_concrete
setblock 324 239 306 minecraft:sea_lantern
fill 324 239 307 324 246 309 minecraft:light_gray_concrete
fill 324 239 316 324 246 316 minecraft:light_gray_concrete
setblock 283 240 278 minecraft:iron_block
setblock 283 240 288 minecraft:iron_block
setblock 283 240 298 minecraft:iron_block
setblock 283 240 308 minecraft:iron_block
setblock 285 240 278 minecraft:light[level=15]
setblock 285 240 285 minecraft:light[level=12]
setblock 285 240 286 minecraft:light[level=15]
setblock 285 240 292 minecraft:light[level=12]
setblock 285 240 299 minecraft:light[level=12]
setblock 285 240 302 minecraft:light[level=15]
setblock 285 240 306 minecraft:light[level=12]
setblock 285 240 310 minecraft:light[level=15]
setblock 285 240 316 minecraft:iron_block
setblock 288 240 295 minecraft:pearlescent_froglight
setblock 289 240 276 minecraft:iron_block
setblock 292 240 278 minecraft:light[level=12]
setblock 292 240 285 minecraft:light[level=12]
setblock 292 240 292 minecraft:light[level=12]
setblock 292 240 299 minecraft:light[level=12]
setblock 292 240 306 minecraft:light[level=12]
setblock 292 240 313 minecraft:light[level=12]
setblock 293 240 278 minecraft:light[level=15]
setblock 293 240 286 minecraft:light[level=15]
setblock 293 240 294 minecraft:light[level=15]
setblock 293 240 302 minecraft:light[level=15]
setblock 293 240 310 minecraft:light[level=15]
setblock 295 240 316 minecraft:iron_block
setblock 299 240 276 minecraft:iron_block
setblock 299 240 278 minecraft:light[level=12]
setblock 299 240 285 minecraft:light[level=12]
setblock 299 240 292 minecraft:light[level=12]
setblock 299 240 299 minecraft:light[level=12]
setblock 299 240 306 minecraft:light[level=12]
setblock 299 240 313 minecraft:light[level=12]
setblock 301 240 278 minecraft:light[level=15]
setblock 301 240 286 minecraft:light[level=15]
setblock 301 240 294 minecraft:light[level=15]
setblock 301 240 302 minecraft:light[level=15]
setblock 301 240 310 minecraft:light[level=15]
setblock 305 240 316 minecraft:iron_block
setblock 306 240 278 minecraft:light[level=12]
setblock 306 240 285 minecraft:light[level=12]
setblock 306 240 292 minecraft:light[level=12]
setblock 306 240 299 minecraft:light[level=12]
setblock 306 240 306 minecraft:light[level=12]
setblock 306 240 313 minecraft:light[level=12]
fill 309 240 276 309 242 276 minecraft:iron_block
setblock 309 240 278 minecraft:light[level=15]
fill 309 240 283 309 240 307 minecraft:iron_block
setblock 309 240 310 minecraft:light[level=15]
fill 310 240 293 310 240 306 minecraft:iron_block
fill 310 240 310 310 240 315 minecraft:light_gray_concrete
setblock 313 240 278 minecraft:light[level=12]
setblock 313 240 285 minecraft:light[level=12]
setblock 313 240 292 minecraft:light[level=12]
setblock 313 240 299 minecraft:light[level=12]
setblock 313 240 306 minecraft:light[level=12]
setblock 313 240 313 minecraft:light[level=12]
setblock 315 240 316 minecraft:iron_block
setblock 317 240 278 minecraft:light[level=15]
setblock 317 240 286 minecraft:light[level=15]
setblock 317 240 294 minecraft:light[level=15]
setblock 317 240 302 minecraft:light[level=15]
setblock 317 240 310 minecraft:light[level=15]
setblock 319 240 276 minecraft:iron_block
setblock 320 240 278 minecraft:light[level=12]
setblock 320 240 285 minecraft:light[level=12]
setblock 320 240 292 minecraft:light[level=12]
setblock 320 240 299 minecraft:light[level=12]
setblock 320 240 306 minecraft:light[level=12]
setblock 320 240 313 minecraft:light[level=12]
setblock 323 240 282 minecraft:iron_block
setblock 323 240 292 minecraft:iron_block
setblock 323 240 302 minecraft:iron_block
setblock 323 240 312 minecraft:iron_block
fill 324 240 306 324 246 306 minecraft:light_gray_concrete
setblock 282 241 315 minecraft:redstone_block
fill 308 241 276 308 241 287 minecraft:iron_block
fill 309 241 277 309 241 295 minecraft:iron_block
fill 309 241 296 309 241 305 minecraft:light_gray_concrete
fill 282 242 315 282 248 315 minecraft:light_gray_concrete
fill 284 242 294 284 242 296 minecraft:iron_block
fill 284 242 312 284 242 314 minecraft:iron_block
fill 285 242 293 287 242 293 minecraft:iron_block
fill 285 242 297 287 242 297 minecraft:iron_block
fill 285 242 311 287 242 311 minecraft:iron_block
fill 285 242 315 287 242 315 minecraft:iron_block
fill 288 242 294 288 242 296 minecraft:iron_block
fill 288 242 312 288 242 314 minecraft:iron_block
setblock 294 242 275 minecraft:redstone_block
fill 308 242 276 308 242 278 minecraft:iron_block
fill 309 242 277 309 242 281 minecraft:iron_block
fill 309 242 282 309 242 294 minecraft:light_gray_concrete
setblock 319 242 294 minecraft:iron_block
setblock 319 242 296 minecraft:iron_block
setblock 321 242 294 minecraft:iron_block
setblock 321 242 296 minecraft:iron_block
fill 282 243 291 282 246 291 minecraft:light_gray_concrete
setblock 282 243 292 minecraft:sea_lantern
fill 282 243 293 282 246 294 minecraft:light_gray_concrete
fill 283 243 280 283 243 283 minecraft:iron_block
fill 283 243 290 283 243 293 minecraft:iron_block
fill 283 243 300 283 243 303 minecraft:iron_block
fill 283 243 310 283 243 313 minecraft:iron_block
fill 284 243 276 287 243 276 minecraft:iron_block
fill 287 243 316 290 243 316 minecraft:iron_block
fill 294 243 275 294 248 275 minecraft:light_gray_concrete
fill 294 243 276 297 243 276 minecraft:iron_block
fill 297 243 316 300 243 316 minecraft:iron_block
fill 304 243 276 307 243 276 minecraft:iron_block
fill 307 243 316 310 243 316 minecraft:iron_block
fill 309 243 276 309 243 280 minecraft:light_gray_concrete
fill 314 243 276 317 243 276 minecraft:iron_block
fill 317 243 316 320 243 316 minecraft:iron_block
fill 323 243 277 323 243 280 minecraft:iron_block
fill 323 243 287 323 243 290 minecraft:iron_block
fill 323 243 297 323 243 300 minecraft:iron_block
fill 323 243 307 323 243 310 minecraft:iron_block
fill 282 244 292 282 246 292 minecraft:light_gray_concrete
setblock 292 245 275 minecraft:sea_lantern
fill 303 245 277 303 245 279 minecraft:iron_block
fill 304 245 277 305 245 277 minecraft:iron_block
fill 304 245 279 305 245 279 minecraft:iron_block
setblock 305 245 278 minecraft:iron_block
setblock 283 246 278 minecraft:iron_block
setblock 283 246 288 minecraft:iron_block
setblock 283 246 298 minecraft:iron_block
setblock 283 246 308 minecraft:iron_block
setblock 285 246 278 minecraft:light[level=12]
setblock 285 246 285 minecraft:light[level=12]
setblock 285 246 292 minecraft:light[level=12]
setblock 285 246 299 minecraft:light[level=12]
setblock 285 246 306 minecraft:light[level=12]
setblock 285 246 316 minecraft:iron_block
setblock 289 246 276 minecraft:iron_block
fill 292 246 275 292 248 275 minecraft:light_gray_concrete
setblock 292 246 278 minecraft:light[level=12]
setblock 292 246 285 minecraft:light[level=12]
setblock 292 246 292 minecraft:light[level=12]
setblock 292 246 299 minecraft:light[level=12]
setblock 292 246 306 minecraft:light[level=12]
setblock 292 246 313 minecraft:light[level=12]
setblock 293 246 275 minecraft:sea_lantern
setblock 295 246 316 minecraft:iron_block
setblock 299 246 276 minecraft:iron_block
setblock 299 246 278 minecraft:light[level=12]
setblock 299 246 285 minecraft:light[level=12]
setblock 299 246 292 minecraft:light[level=12]
setblock 299 246 299 minecraft:light[level=12]
setblock 299 246 306 minecraft:light[level=12]
setblock 299 246 313 minecraft:light[level=12]
setblock 305 246 316 minecraft:iron_block
setblock 306 246 278 minecraft:light[level=12]
setblock 306 246 285 minecraft:light[level=12]
setblock 306 246 292 minecraft:light[level=12]
setblock 306 246 299 minecraft:light[level=12]
setblock 306 246 306 minecraft:light[level=12]
setblock 306 246 313 minecraft:light[level=12]
setblock 309 246 276 minecraft:iron_block
setblock 313 246 278 minecraft:light[level=12]
setblock 313 246 285 minecraft:light[level=12]
setblock 313 246 292 minecraft:light[level=12]
setblock 313 246 299 minecraft:light[level=12]
setblock 313 246 306 minecraft:light[level=12]
setblock 313 246 313 minecraft:light[level=12]
setblock 315 246 316 minecraft:iron_block
setblock 319 246 276 minecraft:iron_block
setblock 320 246 278 minecraft:light[level=12]
setblock 320 246 285 minecraft:light[level=12]
setblock 320 246 292 minecraft:light[level=12]
setblock 320 246 299 minecraft:light[level=12]
setblock 320 246 306 minecraft:light[level=12]
setblock 320 246 313 minecraft:light[level=12]
setblock 323 246 282 minecraft:iron_block
setblock 323 246 292 minecraft:iron_block
setblock 323 246 302 minecraft:iron_block
setblock 323 246 312 minecraft:iron_block
fill 282 247 281 282 247 284 minecraft:pearlescent_froglight
fill 282 247 291 282 247 294 minecraft:pearlescent_froglight
fill 282 247 297 282 248 299 minecraft:light_gray_concrete
setblock 282 247 300 minecraft:sea_lantern
fill 282 247 301 282 247 304 minecraft:pearlescent_froglight
fill 282 247 311 282 247 314 minecraft:pearlescent_froglight
fill 285 247 275 288 247 275 minecraft:pearlescent_froglight
fill 286 247 317 289 247 317 minecraft:pearlescent_froglight
fill 293 247 275 293 248 275 minecraft:light_gray_concrete
fill 295 247 275 298 247 275 minecraft:pearlescent_froglight
fill 296 247 317 299 247 317 minecraft:pearlescent_froglight
fill 305 247 275 308 247 275 minecraft:pearlescent_froglight
fill 306 247 317 309 247 317 minecraft:pearlescent_froglight
fill 315 247 275 318 247 275 minecraft:pearlescent_froglight
fill 316 247 313 316 248 315 minecraft:iron_block
fill 316 247 317 319 247 317 minecraft:pearlescent_froglight
fill 324 247 276 324 247 279 minecraft:pearlescent_froglight
fill 324 247 286 324 247 289 minecraft:pearlescent_froglight
fill 324 247 296 324 247 299 minecraft:pearlescent_froglight
fill 324 247 306 324 247 309 minecraft:pearlescent_froglight
setblock 324 247 316 minecraft:pearlescent_froglight
fill 282 248 281 282 248 284 minecraft:light_gray_concrete
fill 282 248 291 282 248 294 minecraft:light_gray_concrete
fill 282 248 300 282 248 304 minecraft:light_gray_concrete
fill 282 248 311 282 248 314 minecraft:light_gray_concrete
fill 285 248 275 288 248 275 minecraft:light_gray_concrete
setblock 285 248 278 minecraft:light[level=15]
setblock 285 248 286 minecraft:light[level=15]
setblock 285 248 302 minecraft:light[level=15]
setblock 285 248 310 minecraft:light[level=15]
fill 286 248 317 289 248 317 minecraft:light_gray_concrete
setblock 293 248 278 minecraft:light[level=15]
setblock 293 248 286 minecraft:light[level=15]
setblock 293 248 294 minecraft:light[level=15]
setblock 293 248 302 minecraft:light[level=15]
setblock 293 248 310 minecraft:light[level=15]
fill 295 248 275 298 248 275 minecraft:light_gray_concrete
fill 296 248 317 299 248 317 minecraft:light_gray_concrete
setblock 301 248 278 minecraft:light[level=15]
setblock 301 248 286 minecraft:light[level=15]
setblock 301 248 294 minecraft:light[level=15]
setblock 301 248 302 minecraft:light[level=15]
setblock 301 248 310 minecraft:light[level=15]
fill 305 248 275 308 248 275 minecraft:light_gray_concrete
fill 306 248 317 309 248 317 minecraft:light_gray_concrete
setblock 309 248 278 minecraft:light[level=15]
setblock 309 248 286 minecraft:light[level=15]
setblock 309 248 294 minecraft:light[level=15]
setblock 309 248 302 minecraft:light[level=15]
setblock 309 248 310 minecraft:light[level=15]
fill 315 248 275 318 248 275 minecraft:light_gray_concrete
fill 316 248 317 319 248 317 minecraft:light_gray_concrete
setblock 317 248 278 minecraft:light[level=15]
setblock 317 248 286 minecraft:light[level=15]
setblock 317 248 294 minecraft:light[level=15]
setblock 317 248 302 minecraft:light[level=15]
setblock 317 248 310 minecraft:light[level=15]
fill 324 248 276 324 248 282 minecraft:light_gray_concrete
setblock 324 248 283 minecraft:redstone_block
setblock 324 248 284 minecraft:light_gray_concrete
fill 324 248 286 324 248 289 minecraft:light_gray_concrete
fill 324 248 296 324 248 299 minecraft:light_gray_concrete
fill 324 248 306 324 248 309 minecraft:light_gray_concrete
setblock 324 248 316 minecraft:light_gray_concrete
schedule function dropper:buildpart/66_4 1t
