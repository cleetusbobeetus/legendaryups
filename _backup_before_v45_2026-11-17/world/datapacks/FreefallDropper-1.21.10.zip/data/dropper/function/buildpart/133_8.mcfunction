setblock 73 240 595 minecraft:calcite
fill 73 240 596 73 243 596 minecraft:cobbled_deepslate
fill 74 240 595 76 241 595 minecraft:cobbled_deepslate
setblock 75 240 558 minecraft:calcite
fill 75 240 596 76 240 596 minecraft:cobbled_deepslate
setblock 75 240 598 minecraft:calcite
fill 76 240 558 76 242 558 minecraft:cobbled_deepslate
setblock 76 240 597 minecraft:calcite
fill 76 240 598 76 243 598 minecraft:cobbled_deepslate
setblock 77 240 596 minecraft:calcite
fill 77 240 597 77 243 597 minecraft:cobbled_deepslate
fill 78 240 596 78 241 596 minecraft:cobbled_deepslate
setblock 79 240 598 minecraft:cobbled_deepslate
setblock 80 240 598 minecraft:calcite
setblock 87 240 566 minecraft:calcite
fill 87 240 567 87 243 567 minecraft:cobbled_deepslate
setblock 87 240 570 minecraft:cobbled_deepslate
setblock 87 240 571 minecraft:calcite
fill 87 240 572 87 243 572 minecraft:cobbled_deepslate
setblock 87 240 575 minecraft:cobbled_deepslate
fill 88 240 563 88 240 564 minecraft:cobbled_deepslate
setblock 88 240 565 minecraft:calcite
fill 88 240 566 88 243 566 minecraft:cobbled_deepslate
setblock 88 240 570 minecraft:calcite
fill 88 240 571 88 243 571 minecraft:cobbled_deepslate
setblock 88 240 574 minecraft:cobbled_deepslate
setblock 88 240 575 minecraft:calcite
fill 88 240 576 88 243 576 minecraft:cobbled_deepslate
setblock 88 240 579 minecraft:cobbled_deepslate
setblock 88 240 585 minecraft:calcite
fill 88 240 586 88 241 586 minecraft:cobbled_deepslate
setblock 88 240 589 minecraft:cobbled_deepslate
setblock 88 240 590 minecraft:calcite
fill 88 240 591 88 243 591 minecraft:cobbled_deepslate
setblock 88 240 594 minecraft:cobbled_deepslate
setblock 48 241 558 minecraft:cobbled_deepslate
setblock 48 241 559 minecraft:calcite
fill 48 241 560 48 241 563 minecraft:cobbled_deepslate
setblock 48 241 564 minecraft:calcite
fill 48 241 565 48 241 568 minecraft:cobbled_deepslate
setblock 48 241 569 minecraft:calcite
fill 48 241 570 48 244 570 minecraft:cobbled_deepslate
setblock 48 241 574 minecraft:calcite
fill 48 241 575 49 243 575 minecraft:cobbled_deepslate
fill 48 241 577 48 242 577 minecraft:cobbled_deepslate
setblock 48 241 589 minecraft:calcite
fill 48 241 590 48 243 590 minecraft:cobbled_deepslate
setblock 48 241 594 minecraft:calcite
fill 48 241 595 48 241 598 minecraft:cobbled_deepslate
setblock 49 241 558 minecraft:calcite
setblock 49 241 562 minecraft:cobbled_deepslate
setblock 49 241 563 minecraft:calcite
fill 49 241 564 49 241 567 minecraft:cobbled_deepslate
setblock 49 241 568 minecraft:calcite
fill 49 241 569 49 244 569 minecraft:cobbled_deepslate
setblock 49 241 573 minecraft:calcite
fill 49 241 574 49 244 574 minecraft:cobbled_deepslate
setblock 49 241 592 minecraft:cobbled_deepslate
setblock 49 241 593 minecraft:calcite
fill 49 241 594 49 244 594 minecraft:cobbled_deepslate
setblock 49 241 598 minecraft:calcite
fill 50 241 558 52 241 559 minecraft:cobbled_deepslate
setblock 50 241 567 minecraft:calcite
fill 50 241 568 50 244 568 minecraft:cobbled_deepslate
setblock 50 241 572 minecraft:calcite
fill 50 241 573 50 244 573 minecraft:cobbled_deepslate
setblock 50 241 597 minecraft:calcite
fill 50 241 598 53 241 598 minecraft:cobbled_deepslate
setblock 51 241 567 minecraft:cobbled_deepslate
fill 51 241 597 54 241 597 minecraft:cobbled_deepslate
fill 52 241 596 55 241 596 minecraft:cobbled_deepslate
setblock 53 241 558 minecraft:cobbled_deepslate
setblock 53 241 559 minecraft:calcite
fill 53 241 560 53 242 560 minecraft:cobbled_deepslate
setblock 54 241 558 minecraft:calcite
fill 54 241 559 57 241 559 minecraft:cobbled_deepslate
setblock 54 241 598 minecraft:calcite
fill 55 241 558 58 241 558 minecraft:cobbled_deepslate
fill 55 241 595 56 241 595 minecraft:cobbled_deepslate
setblock 55 241 597 minecraft:calcite
fill 55 241 598 58 241 598 minecraft:cobbled_deepslate
setblock 56 241 596 minecraft:calcite
fill 56 241 597 56 244 597 minecraft:cobbled_deepslate
setblock 57 241 595 minecraft:calcite
fill 57 241 596 57 244 596 minecraft:cobbled_deepslate
setblock 58 241 559 minecraft:calcite
setblock 59 241 558 minecraft:calcite
setblock 59 241 559 minecraft:cobbled_deepslate
setblock 59 241 598 minecraft:calcite
fill 60 241 558 60 244 558 minecraft:cobbled_deepslate
setblock 60 241 597 minecraft:calcite
fill 60 241 598 60 244 598 minecraft:cobbled_deepslate
setblock 61 241 596 minecraft:calcite
fill 61 241 597 61 244 597 minecraft:cobbled_deepslate
setblock 64 241 597 minecraft:cobbled_deepslate
setblock 64 241 598 minecraft:calcite
setblock 65 241 597 minecraft:calcite
fill 65 241 598 68 241 598 minecraft:cobbled_deepslate
fill 66 241 597 69 241 597 minecraft:cobbled_deepslate
fill 69 241 596 70 241 596 minecraft:cobbled_deepslate
setblock 69 241 598 minecraft:calcite
setblock 70 241 597 minecraft:calcite
fill 70 241 598 73 241 598 minecraft:cobbled_deepslate
setblock 71 241 595 minecraft:cobbled_deepslate
setblock 71 241 596 minecraft:calcite
fill 71 241 597 74 241 597 minecraft:cobbled_deepslate
fill 72 241 558 73 241 558 minecraft:cobbled_deepslate
setblock 72 241 595 minecraft:calcite
fill 72 241 596 72 244 596 minecraft:cobbled_deepslate
fill 73 241 595 73 244 595 minecraft:cobbled_deepslate
setblock 74 241 558 minecraft:calcite
setblock 74 241 598 minecraft:calcite
fill 75 241 558 75 243 558 minecraft:cobbled_deepslate
setblock 75 241 596 minecraft:cobbled_deepslate
setblock 75 241 597 minecraft:calcite
fill 75 241 598 75 244 598 minecraft:cobbled_deepslate
setblock 76 241 596 minecraft:calcite
fill 76 241 597 76 244 597 minecraft:cobbled_deepslate
fill 77 241 596 77 243 596 minecraft:cobbled_deepslate
setblock 79 241 598 minecraft:calcite
fill 80 241 598 80 242 598 minecraft:cobbled_deepslate
setblock 86 241 570 minecraft:cobbled_deepslate
setblock 86 241 571 minecraft:calcite
fill 86 241 572 86 243 572 minecraft:cobbled_deepslate
setblock 87 241 566 minecraft:cobbled_deepslate
setblock 87 241 570 minecraft:calcite
fill 87 241 571 87 244 571 minecraft:cobbled_deepslate
setblock 87 241 575 minecraft:calcite
fill 87 241 576 87 244 576 minecraft:cobbled_deepslate
setblock 88 241 563 minecraft:cobbled_deepslate
setblock 88 241 564 minecraft:calcite
fill 88 241 565 88 244 565 minecraft:cobbled_deepslate
setblock 88 241 569 minecraft:calcite
fill 88 241 570 88 244 570 minecraft:cobbled_deepslate
setblock 88 241 574 minecraft:calcite
fill 88 241 575 88 244 575 minecraft:cobbled_deepslate
setblock 88 241 579 minecraft:calcite
fill 88 241 580 88 244 580 minecraft:cobbled_deepslate
setblock 88 241 589 minecraft:calcite
fill 88 241 590 88 243 590 minecraft:cobbled_deepslate
setblock 88 241 594 minecraft:calcite
fill 88 241 595 88 244 595 minecraft:cobbled_deepslate
setblock 48 242 558 minecraft:calcite
fill 48 242 559 48 242 562 minecraft:cobbled_deepslate
setblock 48 242 563 minecraft:calcite
fill 48 242 564 48 242 567 minecraft:cobbled_deepslate
setblock 48 242 568 minecraft:calcite
fill 48 242 569 48 245 569 minecraft:cobbled_deepslate
setblock 48 242 573 minecraft:calcite
fill 48 242 574 48 245 574 minecraft:cobbled_deepslate
setblock 48 242 589 minecraft:cobbled_deepslate
setblock 48 242 592 minecraft:cobbled_deepslate
setblock 48 242 593 minecraft:calcite
fill 48 242 594 48 242 597 minecraft:cobbled_deepslate
setblock 48 242 598 minecraft:calcite
fill 49 242 558 52 242 558 minecraft:cobbled_deepslate
setblock 49 242 562 minecraft:calcite
fill 49 242 563 49 242 566 minecraft:cobbled_deepslate
setblock 49 242 567 minecraft:calcite
fill 49 242 568 49 245 568 minecraft:cobbled_deepslate
setblock 49 242 571 minecraft:cobbled_deepslate
setblock 49 242 572 minecraft:calcite
fill 49 242 573 49 245 573 minecraft:cobbled_deepslate
setblock 49 242 592 minecraft:calcite
fill 49 242 593 49 245 593 minecraft:cobbled_deepslate
fill 49 242 595 49 242 596 minecraft:cobbled_deepslate
setblock 49 242 597 minecraft:calcite
fill 49 242 598 52 242 598 minecraft:cobbled_deepslate
fill 50 242 559 51 242 559 minecraft:cobbled_deepslate
setblock 50 242 566 minecraft:calcite
fill 50 242 567 50 243 567 minecraft:cobbled_deepslate
setblock 50 242 571 minecraft:calcite
fill 50 242 572 50 245 572 minecraft:cobbled_deepslate
fill 50 242 597 53 242 597 minecraft:cobbled_deepslate
setblock 51 242 570 minecraft:calcite
fill 51 242 596 54 242 596 minecraft:cobbled_deepslate
setblock 52 242 559 minecraft:calcite
setblock 53 242 558 minecraft:calcite
fill 53 242 559 56 242 559 minecraft:cobbled_deepslate
setblock 53 242 598 minecraft:calcite
fill 54 242 558 57 242 558 minecraft:cobbled_deepslate
fill 54 242 595 55 242 595 minecraft:cobbled_deepslate
setblock 54 242 597 minecraft:calcite
fill 54 242 598 57 242 598 minecraft:cobbled_deepslate
setblock 55 242 596 minecraft:calcite
fill 55 242 597 55 245 597 minecraft:cobbled_deepslate
setblock 56 242 595 minecraft:calcite
fill 56 242 596 56 245 596 minecraft:cobbled_deepslate
setblock 57 242 559 minecraft:calcite
setblock 57 242 595 minecraft:cobbled_deepslate
setblock 58 242 558 minecraft:calcite
setblock 58 242 559 minecraft:cobbled_deepslate
setblock 58 242 598 minecraft:calcite
fill 59 242 558 59 245 558 minecraft:cobbled_deepslate
setblock 59 242 596 minecraft:cobbled_deepslate
setblock 59 242 597 minecraft:calcite
fill 59 242 598 59 245 598 minecraft:cobbled_deepslate
setblock 60 242 596 minecraft:calcite
fill 60 242 597 60 245 597 minecraft:cobbled_deepslate
setblock 61 242 596 minecraft:cobbled_deepslate
setblock 63 242 598 minecraft:calcite
setblock 64 242 597 minecraft:calcite
fill 64 242 598 67 242 598 minecraft:cobbled_deepslate
fill 65 242 597 68 242 597 minecraft:cobbled_deepslate
fill 68 242 596 69 242 596 minecraft:cobbled_deepslate
setblock 68 242 598 minecraft:calcite
setblock 69 242 597 minecraft:calcite
fill 69 242 598 72 242 598 minecraft:cobbled_deepslate
setblock 70 242 596 minecraft:calcite
fill 70 242 597 73 242 597 minecraft:cobbled_deepslate
setblock 71 242 595 minecraft:calcite
fill 71 242 596 71 245 596 minecraft:cobbled_deepslate
setblock 72 242 558 minecraft:cobbled_deepslate
fill 72 242 595 72 244 595 minecraft:cobbled_deepslate
setblock 73 242 558 minecraft:calcite
setblock 73 242 598 minecraft:calcite
fill 74 242 558 74 244 558 minecraft:cobbled_deepslate
fill 74 242 595 75 242 595 minecraft:cobbled_deepslate
setblock 74 242 597 minecraft:calcite
fill 74 242 598 74 245 598 minecraft:cobbled_deepslate
setblock 75 242 596 minecraft:calcite
fill 75 242 597 75 245 597 minecraft:cobbled_deepslate
fill 76 242 596 76 244 596 minecraft:cobbled_deepslate
setblock 78 242 598 minecraft:calcite
fill 79 242 598 79 244 598 minecraft:cobbled_deepslate
setblock 86 242 570 minecraft:calcite
fill 86 242 571 86 243 571 minecraft:cobbled_deepslate
fill 86 242 573 87 242 573 minecraft:cobbled_deepslate
setblock 87 242 569 minecraft:calcite
fill 87 242 570 87 245 570 minecraft:cobbled_deepslate
setblock 87 242 574 minecraft:calcite
fill 87 242 575 87 245 575 minecraft:cobbled_deepslate
setblock 88 242 563 minecraft:calcite
fill 88 242 564 88 245 564 minecraft:cobbled_deepslate
setblock 88 242 568 minecraft:calcite
fill 88 242 569 88 245 569 minecraft:cobbled_deepslate
setblock 88 242 573 minecraft:calcite
fill 88 242 574 88 245 574 minecraft:cobbled_deepslate
setblock 88 242 577 minecraft:cobbled_deepslate
setblock 88 242 578 minecraft:calcite
fill 88 242 579 88 245 579 minecraft:cobbled_deepslate
setblock 88 242 588 minecraft:calcite
fill 88 242 589 88 243 589 minecraft:cobbled_deepslate
setblock 88 242 592 minecraft:cobbled_deepslate
setblock 88 242 593 minecraft:calcite
fill 88 242 594 88 245 594 minecraft:cobbled_deepslate
fill 48 243 558 48 243 561 minecraft:cobbled_deepslate
setblock 48 243 562 minecraft:calcite
fill 48 243 563 48 243 566 minecraft:cobbled_deepslate
setblock 48 243 567 minecraft:calcite
fill 48 243 568 48 246 568 minecraft:cobbled_deepslate
setblock 48 243 572 minecraft:calcite
fill 48 243 573 48 246 573 minecraft:cobbled_deepslate
setblock 48 243 577 minecraft:calcite
setblock 48 243 592 minecraft:calcite
fill 48 243 593 48 243 596 minecraft:cobbled_deepslate
setblock 48 243 597 minecraft:calcite
fill 48 243 598 51 243 598 minecraft:cobbled_deepslate
fill 49 243 558 50 243 559 minecraft:cobbled_deepslate
fill 49 243 562 49 243 565 minecraft:cobbled_deepslate
setblock 49 243 566 minecraft:calcite
fill 49 243 567 49 246 567 minecraft:cobbled_deepslate
setblock 49 243 571 minecraft:calcite
fill 49 243 572 49 246 572 minecraft:cobbled_deepslate
setblock 49 243 576 minecraft:calcite
fill 49 243 592 49 244 592 minecraft:cobbled_deepslate
setblock 49 243 595 minecraft:cobbled_deepslate
setblock 49 243 596 minecraft:calcite
fill 49 243 597 52 243 597 minecraft:cobbled_deepslate
setblock 50 243 566 minecraft:cobbled_deepslate
setblock 50 243 570 minecraft:calcite
fill 50 243 571 50 245 571 minecraft:cobbled_deepslate
setblock 50 243 574 minecraft:cobbled_deepslate
setblock 51 243 558 minecraft:cobbled_deepslate
setblock 51 243 559 minecraft:calcite
fill 51 243 596 53 243 596 minecraft:cobbled_deepslate
setblock 52 243 558 minecraft:calcite
fill 52 243 559 55 243 559 minecraft:cobbled_deepslate
setblock 52 243 598 minecraft:calcite
fill 53 243 558 56 243 558 minecraft:cobbled_deepslate
setblock 53 243 597 minecraft:calcite
fill 53 243 598 56 243 598 minecraft:cobbled_deepslate
setblock 54 243 595 minecraft:cobbled_deepslate
setblock 54 243 596 minecraft:calcite
fill 54 243 597 54 246 597 minecraft:cobbled_deepslate
setblock 55 243 595 minecraft:calcite
fill 55 243 596 55 246 596 minecraft:cobbled_deepslate
setblock 56 243 559 minecraft:calcite
setblock 56 243 595 minecraft:cobbled_deepslate
setblock 57 243 558 minecraft:calcite
setblock 57 243 559 minecraft:cobbled_deepslate
setblock 57 243 598 minecraft:calcite
fill 58 243 558 58 246 558 minecraft:cobbled_deepslate
setblock 58 243 597 minecraft:calcite
fill 58 243 598 58 246 598 minecraft:cobbled_deepslate
setblock 59 243 596 minecraft:calcite
fill 59 243 597 59 246 597 minecraft:cobbled_deepslate
setblock 60 243 596 minecraft:cobbled_deepslate
setblock 62 243 598 minecraft:calcite
setblock 63 243 597 minecraft:calcite
fill 63 243 598 66 243 598 minecraft:cobbled_deepslate
fill 64 243 597 67 243 597 minecraft:cobbled_deepslate
setblock 67 243 598 minecraft:calcite
setblock 68 243 596 minecraft:cobbled_deepslate
setblock 68 243 597 minecraft:calcite
fill 68 243 598 71 243 598 minecraft:cobbled_deepslate
setblock 69 243 596 minecraft:calcite
fill 69 243 597 72 243 597 minecraft:cobbled_deepslate
fill 70 243 596 70 246 596 minecraft:cobbled_deepslate
fill 71 243 595 71 244 595 minecraft:cobbled_deepslate
setblock 72 243 558 minecraft:calcite
setblock 72 243 598 minecraft:calcite
fill 73 243 558 73 246 558 minecraft:cobbled_deepslate
setblock 73 243 597 minecraft:calcite
fill 73 243 598 73 246 598 minecraft:cobbled_deepslate
setblock 74 243 595 minecraft:cobbled_deepslate
setblock 74 243 596 minecraft:calcite
fill 74 243 597 74 246 597 minecraft:cobbled_deepslate
setblock 75 243 595 minecraft:calcite
fill 75 243 596 75 245 596 minecraft:cobbled_deepslate
setblock 77 243 598 minecraft:calcite
setblock 78 243 597 minecraft:calcite
fill 78 243 598 78 245 598 minecraft:cobbled_deepslate
setblock 86 243 573 minecraft:cobbled_deepslate
setblock 87 243 568 minecraft:calcite
fill 87 243 569 87 246 569 minecraft:cobbled_deepslate
setblock 87 243 573 minecraft:calcite
fill 87 243 574 87 246 574 minecraft:cobbled_deepslate
setblock 87 243 577 minecraft:cobbled_deepslate
setblock 88 243 563 minecraft:cobbled_deepslate
setblock 88 243 567 minecraft:calcite
fill 88 243 568 88 246 568 minecraft:cobbled_deepslate
setblock 88 243 572 minecraft:calcite
fill 88 243 573 88 246 573 minecraft:cobbled_deepslate
setblock 88 243 577 minecraft:calcite
fill 88 243 578 88 246 578 minecraft:cobbled_deepslate
setblock 88 243 592 minecraft:calcite
fill 88 243 593 88 246 593 minecraft:cobbled_deepslate
setblock 88 243 596 minecraft:cobbled_deepslate
fill 48 244 558 48 244 560 minecraft:cobbled_deepslate
setblock 48 244 561 minecraft:calcite
fill 48 244 562 48 244 565 minecraft:cobbled_deepslate
setblock 48 244 566 minecraft:calcite
fill 48 244 567 48 247 567 minecraft:cobbled_deepslate
setblock 48 244 571 minecraft:calcite
fill 48 244 572 48 247 572 minecraft:cobbled_deepslate
setblock 48 244 575 minecraft:cobbled_deepslate
setblock 48 244 576 minecraft:calcite
fill 48 244 577 48 246 578 minecraft:cobbled_deepslate
setblock 48 244 591 minecraft:calcite
fill 48 244 592 48 244 595 minecraft:cobbled_deepslate
setblock 48 244 596 minecraft:calcite
fill 48 244 597 50 244 598 minecraft:cobbled_deepslate
fill 49 244 558 49 244 559 minecraft:cobbled_deepslate
setblock 49 244 560 minecraft:calcite
setblock 49 244 564 minecraft:cobbled_deepslate
setblock 49 244 565 minecraft:calcite
fill 49 244 566 49 245 566 minecraft:cobbled_deepslate
setblock 49 244 570 minecraft:calcite
fill 49 244 571 49 247 571 minecraft:cobbled_deepslate
setblock 49 244 575 minecraft:calcite
fill 49 244 576 49 247 576 minecraft:cobbled_deepslate
setblock 49 244 595 minecraft:calcite
fill 49 244 596 52 244 596 minecraft:cobbled_deepslate
setblock 50 244 558 minecraft:cobbled_deepslate
setblock 50 244 559 minecraft:calcite
setblock 50 244 560 minecraft:light[level=14]
setblock 50 244 569 minecraft:calcite
fill 50 244 570 50 245 570 minecraft:cobbled_deepslate
setblock 50 244 576 minecraft:light[level=14]
setblock 50 244 584 minecraft:light[level=14]
setblock 50 244 592 minecraft:light[level=14]
fill 50 244 595 50 247 595 minecraft:cobbled_deepslate
setblock 51 244 558 minecraft:calcite
fill 51 244 559 54 244 559 minecraft:cobbled_deepslate
setblock 51 244 597 minecraft:cobbled_deepslate
setblock 51 244 598 minecraft:calcite
fill 52 244 558 55 244 558 minecraft:cobbled_deepslate
setblock 52 244 597 minecraft:calcite
fill 52 244 598 55 244 598 minecraft:cobbled_deepslate
setblock 53 244 596 minecraft:calcite
fill 53 244 597 53 247 597 minecraft:cobbled_deepslate
setblock 54 244 595 minecraft:calcite
fill 54 244 596 54 247 596 minecraft:cobbled_deepslate
setblock 55 244 559 minecraft:calcite
setblock 55 244 595 minecraft:cobbled_deepslate
setblock 56 244 558 minecraft:calcite
fill 56 244 559 56 245 559 minecraft:cobbled_deepslate
setblock 56 244 598 minecraft:calcite
fill 57 244 558 57 247 558 minecraft:cobbled_deepslate
setblock 57 244 597 minecraft:calcite
fill 57 244 598 57 247 598 minecraft:cobbled_deepslate
setblock 58 244 560 minecraft:light[level=14]
setblock 58 244 568 minecraft:light[level=14]
setblock 58 244 576 minecraft:light[level=14]
setblock 58 244 584 minecraft:light[level=14]
setblock 58 244 592 minecraft:light[level=14]
setblock 58 244 596 minecraft:calcite
fill 58 244 597 58 247 597 minecraft:cobbled_deepslate
setblock 59 244 596 minecraft:cobbled_deepslate
setblock 61 244 598 minecraft:calcite
setblock 62 244 597 minecraft:calcite
fill 62 244 598 65 244 598 minecraft:cobbled_deepslate
fill 63 244 597 66 244 597 minecraft:cobbled_deepslate
setblock 66 244 560 minecraft:light[level=14]
setblock 66 244 568 minecraft:light[level=14]
setblock 66 244 576 minecraft:light[level=14]
setblock 66 244 584 minecraft:light[level=14]
setblock 66 244 592 minecraft:light[level=14]
setblock 66 244 598 minecraft:calcite
setblock 67 244 596 minecraft:cobbled_deepslate
setblock 67 244 597 minecraft:calcite
fill 67 244 598 70 244 598 minecraft:cobbled_deepslate
setblock 68 244 596 minecraft:calcite
fill 68 244 597 71 244 597 minecraft:cobbled_deepslate
fill 69 244 596 69 247 596 minecraft:cobbled_deepslate
setblock 71 244 558 minecraft:calcite
setblock 71 244 598 minecraft:calcite
fill 72 244 558 72 247 558 minecraft:cobbled_deepslate
setblock 72 244 597 minecraft:calcite
fill 72 244 598 72 247 598 minecraft:cobbled_deepslate
setblock 73 244 596 minecraft:calcite
fill 73 244 597 73 247 597 minecraft:cobbled_deepslate
setblock 74 244 560 minecraft:light[level=14]
setblock 74 244 568 minecraft:light[level=14]
setblock 74 244 576 minecraft:light[level=14]
setblock 74 244 584 minecraft:light[level=14]
setblock 74 244 592 minecraft:light[level=14]
fill 74 244 596 74 246 596 minecraft:cobbled_deepslate
setblock 76 244 598 minecraft:calcite
setblock 77 244 597 minecraft:calcite
fill 77 244 598 77 247 598 minecraft:cobbled_deepslate
setblock 82 244 560 minecraft:light[level=14]
setblock 82 244 568 minecraft:light[level=14]
setblock 82 244 576 minecraft:light[level=14]
setblock 82 244 584 minecraft:light[level=14]
setblock 82 244 592 minecraft:light[level=14]
fill 87 244 568 87 245 568 minecraft:cobbled_deepslate
setblock 87 244 572 minecraft:calcite
fill 87 244 573 87 247 573 minecraft:cobbled_deepslate
setblock 87 244 577 minecraft:calcite
setblock 88 244 566 minecraft:calcite
fill 88 244 567 88 247 567 minecraft:cobbled_deepslate
setblock 88 244 571 minecraft:calcite
fill 88 244 572 88 247 572 minecraft:cobbled_deepslate
setblock 88 244 576 minecraft:calcite
fill 88 244 577 88 247 577 minecraft:cobbled_deepslate
setblock 88 244 591 minecraft:calcite
fill 88 244 592 88 245 592 minecraft:cobbled_deepslate
setblock 88 244 596 minecraft:calcite
fill 88 244 597 88 247 597 minecraft:cobbled_deepslate
fill 48 245 558 48 245 559 minecraft:cobbled_deepslate
setblock 48 245 560 minecraft:calcite
fill 48 245 561 48 245 564 minecraft:cobbled_deepslate
setblock 48 245 565 minecraft:calcite
fill 48 245 566 48 248 566 minecraft:cobbled_deepslate
setblock 48 245 570 minecraft:calcite
fill 48 245 571 48 248 571 minecraft:cobbled_deepslate
setblock 48 245 575 minecraft:calcite
fill 48 245 576 48 248 576 minecraft:cobbled_deepslate
fill 48 245 591 48 245 594 minecraft:cobbled_deepslate
setblock 48 245 595 minecraft:calcite
fill 48 245 596 49 245 598 minecraft:cobbled_deepslate
setblock 49 245 558 minecraft:cobbled_deepslate
setblock 49 245 559 minecraft:calcite
fill 49 245 560 49 248 560 minecraft:cobbled_deepslate
setblock 49 245 569 minecraft:calcite
fill 49 245 570 49 248 570 minecraft:cobbled_deepslate
setblock 49 245 574 minecraft:calcite
fill 49 245 575 49 248 575 minecraft:cobbled_deepslate
setblock 49 245 594 minecraft:calcite
fill 49 245 595 49 248 595 minecraft:cobbled_deepslate
setblock 50 245 558 minecraft:calcite
fill 50 245 559 53 245 559 minecraft:cobbled_deepslate
setblock 50 245 573 minecraft:calcite
fill 50 245 596 50 245 597 minecraft:cobbled_deepslate
setblock 50 245 598 minecraft:calcite
fill 51 245 558 54 245 558 minecraft:cobbled_deepslate
setblock 51 245 596 minecraft:cobbled_deepslate
setblock 51 245 597 minecraft:calcite
fill 51 245 598 54 245 598 minecraft:cobbled_deepslate
setblock 52 245 596 minecraft:calcite
fill 52 245 597 52 248 597 minecraft:cobbled_deepslate
fill 53 245 596 53 248 596 minecraft:cobbled_deepslate
setblock 54 245 559 minecraft:calcite
setblock 55 245 558 minecraft:calcite
fill 55 245 559 55 248 559 minecraft:cobbled_deepslate
setblock 55 245 598 minecraft:calcite
fill 56 245 558 56 248 558 minecraft:cobbled_deepslate
setblock 56 245 597 minecraft:calcite
fill 56 245 598 56 248 598 minecraft:cobbled_deepslate
setblock 57 245 596 minecraft:calcite
fill 57 245 597 57 248 597 minecraft:cobbled_deepslate
setblock 58 245 596 minecraft:cobbled_deepslate
setblock 60 245 598 minecraft:calcite
setblock 61 245 597 minecraft:calcite
fill 61 245 598 64 245 598 minecraft:cobbled_deepslate
fill 62 245 597 65 245 597 minecraft:cobbled_deepslate
setblock 65 245 598 minecraft:calcite
setblock 66 245 597 minecraft:calcite
fill 66 245 598 69 245 598 minecraft:cobbled_deepslate
fill 67 245 594 67 255 594 minecraft:deepslate
setblock 67 245 596 minecraft:calcite
fill 67 245 597 70 245 597 minecraft:cobbled_deepslate
fill 68 245 596 68 248 596 minecraft:cobbled_deepslate
setblock 70 245 598 minecraft:calcite
fill 71 245 558 71 248 558 minecraft:cobbled_deepslate
setblock 71 245 597 minecraft:calcite
fill 71 245 598 71 248 598 minecraft:cobbled_deepslate
setblock 72 245 596 minecraft:calcite
fill 72 245 597 72 248 597 minecraft:cobbled_deepslate
fill 73 245 596 73 247 596 minecraft:cobbled_deepslate
setblock 75 245 598 minecraft:calcite
setblock 76 245 597 minecraft:calcite
fill 76 245 598 76 248 598 minecraft:cobbled_deepslate
setblock 87 245 571 minecraft:calcite
fill 87 245 572 87 248 572 minecraft:cobbled_deepslate
setblock 87 245 576 minecraft:calcite
fill 87 245 577 87 248 577 minecraft:cobbled_deepslate
fill 88 245 558 88 246 558 minecraft:cobbled_deepslate
setblock 88 245 565 minecraft:calcite
fill 88 245 566 88 248 566 minecraft:cobbled_deepslate
setblock 88 245 570 minecraft:calcite
fill 88 245 571 88 248 571 minecraft:cobbled_deepslate
setblock 88 245 575 minecraft:calcite
fill 88 245 576 88 248 576 minecraft:cobbled_deepslate
setblock 88 245 580 minecraft:calcite
setblock 88 245 595 minecraft:calcite
fill 88 245 596 88 248 596 minecraft:cobbled_deepslate
fill 88 245 598 88 246 598 minecraft:cobbled_deepslate
setblock 48 246 558 minecraft:cobbled_deepslate
setblock 48 246 559 minecraft:calcite
fill 48 246 560 48 246 563 minecraft:cobbled_deepslate
setblock 48 246 564 minecraft:calcite
fill 48 246 565 48 249 565 minecraft:cobbled_deepslate
setblock 48 246 569 minecraft:calcite
fill 48 246 570 48 249 570 minecraft:cobbled_deepslate
setblock 48 246 574 minecraft:calcite
fill 48 246 575 48 249 575 minecraft:cobbled_deepslate
fill 48 246 591 48 246 593 minecraft:cobbled_deepslate
setblock 48 246 594 minecraft:calcite
fill 48 246 595 48 246 598 minecraft:cobbled_deepslate
setblock 49 246 558 minecraft:calcite
fill 49 246 559 52 246 559 minecraft:cobbled_deepslate
fill 49 246 561 49 247 561 minecraft:cobbled_deepslate
setblock 49 246 568 minecraft:calcite
fill 49 246 569 49 247 569 minecraft:cobbled_deepslate
setblock 49 246 573 minecraft:calcite
fill 49 246 574 49 249 574 minecraft:cobbled_deepslate
setblock 49 246 593 minecraft:calcite
fill 49 246 594 49 249 594 minecraft:cobbled_deepslate
fill 49 246 596 49 246 597 minecraft:cobbled_deepslate
setblock 49 246 598 minecraft:calcite
fill 50 246 558 53 246 558 minecraft:cobbled_deepslate
setblock 50 246 596 minecraft:cobbled_deepslate
setblock 50 246 597 minecraft:calcite
fill 50 246 598 53 246 598 minecraft:cobbled_deepslate
setblock 51 246 596 minecraft:calcite
fill 51 246 597 51 249 597 minecraft:cobbled_deepslate
fill 52 246 596 52 249 596 minecraft:cobbled_deepslate
setblock 53 246 559 minecraft:calcite
setblock 54 246 558 minecraft:calcite
fill 54 246 559 54 249 559 minecraft:cobbled_deepslate
setblock 54 246 598 minecraft:calcite
fill 55 246 558 55 249 558 minecraft:cobbled_deepslate
setblock 55 246 597 minecraft:calcite
fill 55 246 598 55 249 598 minecraft:cobbled_deepslate
setblock 56 246 596 minecraft:calcite
fill 56 246 597 56 249 597 minecraft:cobbled_deepslate
setblock 57 246 596 minecraft:cobbled_deepslate
setblock 59 246 598 minecraft:calcite
setblock 60 246 597 minecraft:calcite
fill 60 246 598 63 246 598 minecraft:cobbled_deepslate
fill 61 246 597 64 246 597 minecraft:cobbled_deepslate
setblock 64 246 598 minecraft:calcite
setblock 65 246 597 minecraft:calcite
fill 65 246 598 68 246 598 minecraft:cobbled_deepslate
fill 66 246 597 69 246 597 minecraft:cobbled_deepslate
fill 67 246 596 67 249 596 minecraft:cobbled_deepslate
setblock 69 246 598 minecraft:calcite
fill 70 246 558 70 249 558 minecraft:cobbled_deepslate
setblock 70 246 597 minecraft:calcite
fill 70 246 598 70 249 598 minecraft:cobbled_deepslate
setblock 71 246 596 minecraft:calcite
fill 71 246 597 71 249 597 minecraft:cobbled_deepslate
fill 72 246 596 72 249 596 minecraft:cobbled_deepslate
setblock 74 246 598 minecraft:calcite
setblock 75 246 597 minecraft:calcite
fill 75 246 598 75 249 598 minecraft:cobbled_deepslate
setblock 76 246 597 minecraft:cobbled_deepslate
setblock 87 246 570 minecraft:calcite
fill 87 246 571 87 249 571 minecraft:cobbled_deepslate
setblock 87 246 575 minecraft:calcite
fill 87 246 576 87 249 576 minecraft:cobbled_deepslate
fill 87 246 578 87 247 578 minecraft:cobbled_deepslate
setblock 88 246 559 minecraft:calcite
fill 88 246 560 88 249 560 minecraft:cobbled_deepslate
setblock 88 246 563 minecraft:cobbled_deepslate
setblock 88 246 564 minecraft:calcite
fill 88 246 565 88 249 565 minecraft:cobbled_deepslate
setblock 88 246 569 minecraft:calcite
fill 88 246 570 88 249 570 minecraft:cobbled_deepslate
setblock 88 246 574 minecraft:calcite
fill 88 246 575 88 249 575 minecraft:cobbled_deepslate
setblock 88 246 579 minecraft:calcite
fill 88 246 580 88 249 580 minecraft:cobbled_deepslate
setblock 88 246 594 minecraft:calcite
fill 88 246 595 88 249 595 minecraft:cobbled_deepslate
setblock 48 247 558 minecraft:calcite
fill 48 247 559 48 247 562 minecraft:cobbled_deepslate
setblock 48 247 563 minecraft:calcite
fill 48 247 564 48 250 564 minecraft:cobbled_deepslate
setblock 48 247 568 minecraft:calcite
fill 48 247 569 48 250 569 minecraft:cobbled_deepslate
setblock 48 247 573 minecraft:calcite
fill 48 247 574 48 250 574 minecraft:cobbled_deepslate
setblock 48 247 577 minecraft:cobbled_deepslate
setblock 48 247 578 minecraft:calcite
fill 48 247 579 48 250 579 minecraft:cobbled_deepslate
setblock 48 247 592 minecraft:cobbled_deepslate
setblock 48 247 593 minecraft:calcite
fill 48 247 594 48 247 597 minecraft:cobbled_deepslate
setblock 48 247 598 minecraft:calcite
fill 49 247 558 51 247 559 minecraft:cobbled_deepslate
setblock 49 247 572 minecraft:calcite
fill 49 247 573 49 250 573 minecraft:cobbled_deepslate
fill 49 247 593 49 250 593 minecraft:cobbled_deepslate
setblock 49 247 596 minecraft:cobbled_deepslate
setblock 49 247 597 minecraft:calcite
fill 49 247 598 52 247 598 minecraft:cobbled_deepslate
setblock 50 247 596 minecraft:calcite
fill 50 247 597 50 250 597 minecraft:cobbled_deepslate
fill 51 247 596 51 250 596 minecraft:cobbled_deepslate
setblock 52 247 558 minecraft:cobbled_deepslate
setblock 52 247 559 minecraft:calcite
setblock 53 247 558 minecraft:calcite
fill 53 247 559 53 250 559 minecraft:cobbled_deepslate
setblock 53 247 598 minecraft:calcite
fill 54 247 558 54 250 558 minecraft:cobbled_deepslate
setblock 54 247 597 minecraft:calcite
fill 54 247 598 54 250 598 minecraft:cobbled_deepslate
setblock 55 247 596 minecraft:calcite
fill 55 247 597 55 250 597 minecraft:cobbled_deepslate
fill 56 247 596 56 248 596 minecraft:cobbled_deepslate
setblock 58 247 558 minecraft:calcite
setblock 58 247 598 minecraft:calcite
setblock 59 247 597 minecraft:calcite
fill 59 247 598 62 247 598 minecraft:cobbled_deepslate
fill 60 247 597 63 247 597 minecraft:cobbled_deepslate
setblock 63 247 598 minecraft:calcite
setblock 64 247 597 minecraft:calcite
fill 64 247 598 67 247 598 minecraft:cobbled_deepslate
fill 65 247 597 68 247 597 minecraft:cobbled_deepslate
setblock 68 247 598 minecraft:calcite
fill 69 247 558 69 250 558 minecraft:cobbled_deepslate
setblock 69 247 597 minecraft:calcite
fill 69 247 598 69 250 598 minecraft:cobbled_deepslate
setblock 70 247 596 minecraft:calcite
fill 70 247 597 70 250 597 minecraft:cobbled_deepslate
fill 71 247 596 71 250 596 minecraft:cobbled_deepslate
setblock 73 247 558 minecraft:calcite
setblock 73 247 598 minecraft:calcite
setblock 74 247 597 minecraft:calcite
fill 74 247 598 74 250 598 minecraft:cobbled_deepslate
fill 75 247 597 75 248 597 minecraft:cobbled_deepslate
setblock 87 247 558 minecraft:cobbled_deepslate
setblock 87 247 569 minecraft:calcite
fill 87 247 570 87 250 570 minecraft:cobbled_deepslate
setblock 87 247 574 minecraft:calcite
fill 87 247 575 87 250 575 minecraft:cobbled_deepslate
setblock 87 247 598 minecraft:cobbled_deepslate
setblock 88 247 558 minecraft:calcite
fill 88 247 559 88 250 559 minecraft:cobbled_deepslate
fill 88 247 561 88 247 562 minecraft:cobbled_deepslate
setblock 88 247 563 minecraft:calcite
fill 88 247 564 88 250 564 minecraft:cobbled_deepslate
setblock 88 247 568 minecraft:calcite
fill 88 247 569 88 250 569 minecraft:cobbled_deepslate
setblock 88 247 573 minecraft:calcite
fill 88 247 574 88 250 574 minecraft:cobbled_deepslate
setblock 88 247 578 minecraft:calcite
fill 88 247 579 88 250 579 minecraft:cobbled_deepslate
fill 88 247 581 88 248 581 minecraft:cobbled_deepslate
fill 88 247 594 88 250 594 minecraft:cobbled_deepslate
setblock 88 247 598 minecraft:calcite
fill 48 248 558 48 248 561 minecraft:cobbled_deepslate
setblock 48 248 562 minecraft:calcite
fill 48 248 563 48 251 563 minecraft:cobbled_deepslate
setblock 48 248 567 minecraft:calcite
fill 48 248 568 48 251 568 minecraft:cobbled_deepslate
setblock 48 248 572 minecraft:calcite
fill 48 248 573 48 251 573 minecraft:cobbled_deepslate
setblock 48 248 577 minecraft:calcite
fill 48 248 578 48 251 578 minecraft:cobbled_deepslate
fill 48 248 580 48 249 580 minecraft:cobbled_deepslate
setblock 48 248 592 minecraft:calcite
fill 48 248 593 48 248 596 minecraft:cobbled_deepslate
setblock 48 248 597 minecraft:calcite
fill 48 248 598 51 248 598 minecraft:cobbled_deepslate
fill 49 248 558 50 248 559 minecraft:cobbled_deepslate
setblock 49 248 561 minecraft:calcite
fill 49 248 562 49 251 562 minecraft:cobbled_deepslate
setblock 49 248 571 minecraft:calcite
fill 49 248 572 49 251 572 minecraft:cobbled_deepslate
setblock 49 248 576 minecraft:calcite
fill 49 248 577 49 251 577 minecraft:cobbled_deepslate
setblock 49 248 596 minecraft:calcite
fill 49 248 597 49 251 597 minecraft:cobbled_deepslate
setblock 50 248 595 minecraft:calcite
fill 50 248 596 50 251 596 minecraft:cobbled_deepslate
setblock 51 248 558 minecraft:cobbled_deepslate
setblock 51 248 559 minecraft:calcite
setblock 52 248 558 minecraft:calcite
fill 52 248 559 52 251 559 minecraft:cobbled_deepslate
setblock 52 248 598 minecraft:calcite
fill 53 248 558 53 251 558 minecraft:cobbled_deepslate
setblock 53 248 597 minecraft:calcite
fill 53 248 598 53 251 598 minecraft:cobbled_deepslate
setblock 54 248 596 minecraft:calcite
fill 54 248 597 54 251 597 minecraft:cobbled_deepslate
fill 55 248 596 55 251 596 minecraft:cobbled_deepslate
setblock 57 248 558 minecraft:calcite
setblock 57 248 598 minecraft:calcite
fill 58 248 558 58 251 558 minecraft:cobbled_deepslate
setblock 58 248 597 minecraft:calcite
fill 58 248 598 61 248 598 minecraft:cobbled_deepslate
fill 59 248 597 62 248 597 minecraft:cobbled_deepslate
setblock 62 248 598 minecraft:calcite
setblock 63 248 597 minecraft:calcite
fill 63 248 598 66 248 598 minecraft:cobbled_deepslate
fill 64 248 597 67 248 597 minecraft:cobbled_deepslate
setblock 67 248 558 minecraft:calcite
setblock 67 248 598 minecraft:calcite
fill 68 248 558 68 251 558 minecraft:cobbled_deepslate
setblock 68 248 597 minecraft:calcite
fill 68 248 598 68 251 598 minecraft:cobbled_deepslate
setblock 69 248 596 minecraft:calcite
fill 69 248 597 69 251 597 minecraft:cobbled_deepslate
fill 70 248 596 70 251 596 minecraft:cobbled_deepslate
setblock 72 248 558 minecraft:calcite
setblock 72 248 598 minecraft:calcite
fill 73 248 558 74 250 558 minecraft:cobbled_deepslate
setblock 73 248 597 minecraft:calcite
fill 73 248 598 73 251 598 minecraft:cobbled_deepslate
fill 74 248 597 74 250 597 minecraft:cobbled_deepslate
setblock 86 248 558 minecraft:cobbled_deepslate
setblock 86 248 598 minecraft:cobbled_deepslate
setblock 87 248 558 minecraft:calcite
fill 87 248 569 87 251 569 minecraft:cobbled_deepslate
setblock 87 248 573 minecraft:calcite
fill 87 248 574 87 251 574 minecraft:cobbled_deepslate
setblock 87 248 578 minecraft:calcite
fill 87 248 579 87 251 579 minecraft:cobbled_deepslate
setblock 87 248 598 minecraft:calcite
fill 88 248 558 88 251 558 minecraft:cobbled_deepslate
setblock 88 248 561 minecraft:cobbled_deepslate
setblock 88 248 562 minecraft:calcite
fill 88 248 563 88 251 563 minecraft:cobbled_deepslate
setblock 88 248 567 minecraft:calcite
fill 88 248 568 88 251 568 minecraft:cobbled_deepslate
setblock 88 248 572 minecraft:calcite
fill 88 248 573 88 251 573 minecraft:cobbled_deepslate
setblock 88 248 577 minecraft:calcite
fill 88 248 578 88 251 578 minecraft:cobbled_deepslate
setblock 88 248 597 minecraft:calcite
fill 88 248 598 88 251 598 minecraft:cobbled_deepslate
fill 48 249 558 48 249 560 minecraft:cobbled_deepslate
setblock 48 249 561 minecraft:calcite
fill 48 249 562 48 252 562 minecraft:cobbled_deepslate
setblock 48 249 566 minecraft:calcite
fill 48 249 567 48 252 567 minecraft:cobbled_deepslate
setblock 48 249 571 minecraft:calcite
fill 48 249 572 48 252 572 minecraft:cobbled_deepslate
setblock 48 249 576 minecraft:calcite
fill 48 249 577 48 252 577 minecraft:cobbled_deepslate
setblock 48 249 581 minecraft:calcite
setblock 48 249 591 minecraft:calcite
fill 48 249 592 48 249 595 minecraft:cobbled_deepslate
setblock 48 249 596 minecraft:calcite
fill 48 249 597 48 251 598 minecraft:cobbled_deepslate
fill 49 249 558 49 249 559 minecraft:cobbled_deepslate
setblock 49 249 560 minecraft:calcite
fill 49 249 561 49 252 561 minecraft:cobbled_deepslate
fill 49 249 563 49 250 563 minecraft:cobbled_deepslate
fill 49 249 571 49 250 571 minecraft:cobbled_deepslate
setblock 49 249 575 minecraft:calcite
fill 49 249 576 49 252 576 minecraft:cobbled_deepslate
fill 49 249 578 49 250 578 minecraft:cobbled_deepslate
setblock 49 249 595 minecraft:calcite
fill 49 249 596 49 252 596 minecraft:cobbled_deepslate
fill 49 249 598 50 249 598 minecraft:cobbled_deepslate
setblock 50 249 558 minecraft:cobbled_deepslate
setblock 50 249 559 minecraft:calcite
fill 50 249 560 51 251 560 minecraft:cobbled_deepslate
fill 50 249 595 50 252 595 minecraft:cobbled_deepslate
setblock 51 249 558 minecraft:calcite
fill 51 249 559 51 252 559 minecraft:cobbled_deepslate
setblock 51 249 598 minecraft:calcite
fill 52 249 558 52 252 558 minecraft:cobbled_deepslate
setblock 52 249 597 minecraft:calcite
fill 52 249 598 52 252 598 minecraft:cobbled_deepslate
setblock 53 249 596 minecraft:calcite
fill 53 249 597 53 252 597 minecraft:cobbled_deepslate
fill 54 249 596 54 252 596 minecraft:cobbled_deepslate
setblock 55 249 559 minecraft:calcite
setblock 56 249 558 minecraft:calcite
setblock 56 249 598 minecraft:calcite
fill 57 249 558 57 252 558 minecraft:cobbled_deepslate
setblock 57 249 597 minecraft:calcite
fill 57 249 598 60 249 598 minecraft:cobbled_deepslate
fill 58 249 597 61 249 597 minecraft:cobbled_deepslate
fill 59 249 558 59 250 558 minecraft:cobbled_deepslate
setblock 61 249 598 minecraft:calcite
setblock 62 249 597 minecraft:calcite
fill 62 249 598 65 249 598 minecraft:cobbled_deepslate
fill 63 249 597 66 249 597 minecraft:cobbled_deepslate
setblock 66 249 558 minecraft:calcite
setblock 66 249 598 minecraft:calcite
fill 67 249 558 67 252 558 minecraft:cobbled_deepslate
setblock 67 249 597 minecraft:calcite
fill 67 249 598 67 252 598 minecraft:cobbled_deepslate
setblock 68 249 596 minecraft:calcite
fill 68 249 597 68 252 597 minecraft:cobbled_deepslate
fill 69 249 596 69 252 596 minecraft:cobbled_deepslate
setblock 71 249 558 minecraft:calcite
setblock 71 249 598 minecraft:calcite
fill 72 249 558 72 252 558 minecraft:cobbled_deepslate
setblock 72 249 597 minecraft:calcite
fill 72 249 598 72 252 598 minecraft:cobbled_deepslate
fill 73 249 597 73 252 597 minecraft:cobbled_deepslate
setblock 76 249 598 minecraft:calcite
setblock 85 249 558 minecraft:cobbled_deepslate
setblock 85 249 598 minecraft:cobbled_deepslate
setblock 86 249 558 minecraft:calcite
fill 86 249 574 86 250 576 minecraft:cobbled_deepslate
setblock 86 249 598 minecraft:calcite
fill 87 249 558 87 250 560 minecraft:cobbled_deepslate
setblock 87 249 572 minecraft:calcite
fill 87 249 573 87 252 573 minecraft:cobbled_deepslate
setblock 87 249 577 minecraft:calcite
fill 87 249 578 87 252 578 minecraft:cobbled_deepslate
fill 87 249 580 87 250 580 minecraft:cobbled_deepslate
fill 87 249 598 87 252 598 minecraft:cobbled_deepslate
setblock 88 249 561 minecraft:calcite
fill 88 249 562 88 252 562 minecraft:cobbled_deepslate
setblock 88 249 566 minecraft:calcite
fill 88 249 567 88 252 567 minecraft:cobbled_deepslate
setblock 88 249 571 minecraft:calcite
fill 88 249 572 88 252 572 minecraft:cobbled_deepslate
setblock 88 249 576 minecraft:calcite
fill 88 249 577 88 252 577 minecraft:cobbled_deepslate
setblock 88 249 581 minecraft:calcite
fill 88 249 582 88 252 582 minecraft:cobbled_deepslate
setblock 88 249 596 minecraft:calcite
fill 88 249 597 88 252 597 minecraft:cobbled_deepslate
fill 48 250 558 48 250 559 minecraft:cobbled_deepslate
setblock 48 250 560 minecraft:calcite
fill 48 250 561 48 253 561 minecraft:cobbled_deepslate
setblock 48 250 565 minecraft:calcite
fill 48 250 566 48 253 566 minecraft:cobbled_deepslate
setblock 48 250 570 minecraft:calcite
fill 48 250 571 48 253 571 minecraft:cobbled_deepslate
setblock 48 250 575 minecraft:calcite
fill 48 250 576 48 253 576 minecraft:cobbled_deepslate
setblock 48 250 580 minecraft:calcite
fill 48 250 581 48 252 582 minecraft:cobbled_deepslate
fill 48 250 591 48 250 594 minecraft:cobbled_deepslate
setblock 48 250 595 minecraft:calcite
fill 48 250 596 48 253 596 minecraft:cobbled_deepslate
setblock 49 250 558 minecraft:cobbled_deepslate
setblock 49 250 559 minecraft:calcite
fill 49 250 560 49 253 560 minecraft:cobbled_deepslate
setblock 49 250 564 minecraft:calcite
setblock 49 250 574 minecraft:calcite
fill 49 250 575 49 253 575 minecraft:cobbled_deepslate
setblock 49 250 579 minecraft:calcite
setblock 49 250 594 minecraft:calcite
fill 49 250 595 49 253 595 minecraft:cobbled_deepslate
setblock 49 250 598 minecraft:cobbled_deepslate
setblock 50 250 558 minecraft:calcite
fill 50 250 559 50 253 559 minecraft:cobbled_deepslate
fill 50 250 561 50 251 561 minecraft:cobbled_deepslate
setblock 50 250 598 minecraft:calcite
fill 51 250 558 51 253 558 minecraft:cobbled_deepslate
setblock 51 250 597 minecraft:calcite
fill 51 250 598 51 253 598 minecraft:cobbled_deepslate
setblock 52 250 560 minecraft:cobbled_deepslate
setblock 52 250 596 minecraft:calcite
fill 52 250 597 52 253 597 minecraft:cobbled_deepslate
fill 53 250 596 53 253 596 minecraft:cobbled_deepslate
setblock 54 250 559 minecraft:calcite
setblock 55 250 558 minecraft:calcite
fill 55 250 559 55 253 559 minecraft:cobbled_deepslate
setblock 55 250 598 minecraft:calcite
fill 56 250 558 56 253 558 minecraft:cobbled_deepslate
setblock 56 250 597 minecraft:calcite
fill 56 250 598 59 250 598 minecraft:cobbled_deepslate
fill 57 250 597 60 250 597 minecraft:cobbled_deepslate
setblock 60 250 558 minecraft:calcite
setblock 60 250 598 minecraft:calcite
setblock 61 250 597 minecraft:calcite
fill 61 250 598 64 250 598 minecraft:cobbled_deepslate
fill 62 250 597 65 250 597 minecraft:cobbled_deepslate
fill 63 250 558 64 250 558 minecraft:cobbled_deepslate
setblock 65 250 558 minecraft:calcite
setblock 65 250 598 minecraft:calcite
fill 66 250 558 66 253 558 minecraft:cobbled_deepslate
setblock 66 250 596 minecraft:cobbled_deepslate
setblock 66 250 597 minecraft:calcite
fill 66 250 598 66 253 598 minecraft:cobbled_deepslate
setblock 67 250 596 minecraft:calcite
fill 67 250 597 67 253 597 minecraft:cobbled_deepslate
fill 68 250 596 68 253 596 minecraft:cobbled_deepslate
setblock 70 250 558 minecraft:calcite
setblock 70 250 598 minecraft:calcite
fill 71 250 558 71 253 558 minecraft:cobbled_deepslate
setblock 71 250 597 minecraft:calcite
fill 71 250 598 71 253 598 minecraft:cobbled_deepslate
fill 72 250 597 72 253 597 minecraft:cobbled_deepslate
setblock 75 250 558 minecraft:calcite
setblock 75 250 598 minecraft:calcite
fill 76 250 598 76 252 598 minecraft:cobbled_deepslate
fill 83 250 558 84 250 558 minecraft:cobbled_deepslate
setblock 84 250 598 minecraft:cobbled_deepslate
setblock 85 250 558 minecraft:calcite
setblock 85 250 598 minecraft:calcite
fill 86 250 558 86 252 559 minecraft:cobbled_deepslate
fill 86 250 573 86 253 573 minecraft:cobbled_deepslate
setblock 86 250 577 minecraft:calcite
fill 86 250 598 86 253 598 minecraft:cobbled_deepslate
setblock 87 250 561 minecraft:calcite
fill 87 250 562 87 252 563 minecraft:cobbled_deepslate
fill 87 250 568 87 252 568 minecraft:cobbled_deepslate
setblock 87 250 571 minecraft:calcite
fill 87 250 572 87 253 572 minecraft:cobbled_deepslate
setblock 87 250 576 minecraft:calcite
fill 87 250 577 87 253 577 minecraft:cobbled_deepslate
setblock 87 250 581 minecraft:calcite
fill 87 250 597 87 253 597 minecraft:cobbled_deepslate
setblock 88 250 560 minecraft:calcite
fill 88 250 561 88 253 561 minecraft:cobbled_deepslate
setblock 88 250 565 minecraft:calcite
fill 88 250 566 88 253 566 minecraft:cobbled_deepslate
setblock 88 250 570 minecraft:calcite
fill 88 250 571 88 253 571 minecraft:cobbled_deepslate
setblock 88 250 575 minecraft:calcite
fill 88 250 576 88 253 576 minecraft:cobbled_deepslate
setblock 88 250 580 minecraft:calcite
fill 88 250 581 88 253 581 minecraft:cobbled_deepslate
fill 88 250 583 88 251 583 minecraft:cobbled_deepslate
fill 88 250 593 88 251 593 minecraft:cobbled_deepslate
setblock 88 250 595 minecraft:calcite
fill 88 250 596 88 253 596 minecraft:cobbled_deepslate
setblock 48 251 558 minecraft:cobbled_deepslate
setblock 48 251 559 minecraft:calcite
fill 48 251 560 48 254 560 minecraft:cobbled_deepslate
setblock 48 251 564 minecraft:calcite
fill 48 251 565 49 253 565 minecraft:cobbled_deepslate
setblock 48 251 569 minecraft:calcite
fill 48 251 570 48 254 570 minecraft:cobbled_deepslate
setblock 48 251 574 minecraft:calcite
fill 48 251 575 48 254 575 minecraft:cobbled_deepslate
setblock 48 251 579 minecraft:calcite
fill 48 251 580 49 253 580 minecraft:cobbled_deepslate
setblock 48 251 583 minecraft:cobbled_deepslate
setblock 48 251 584 minecraft:calcite
fill 48 251 590 48 251 593 minecraft:cobbled_deepslate
setblock 48 251 594 minecraft:calcite
fill 48 251 595 48 254 595 minecraft:cobbled_deepslate
setblock 49 251 558 minecraft:calcite
fill 49 251 559 49 254 559 minecraft:cobbled_deepslate
setblock 49 251 563 minecraft:calcite
fill 49 251 564 49 254 564 minecraft:cobbled_deepslate
setblock 49 251 573 minecraft:calcite
fill 49 251 574 49 254 574 minecraft:cobbled_deepslate
setblock 49 251 578 minecraft:calcite
fill 49 251 579 49 254 579 minecraft:cobbled_deepslate
fill 49 251 581 49 252 581 minecraft:cobbled_deepslate
setblock 49 251 592 minecraft:cobbled_deepslate
setblock 49 251 593 minecraft:calcite
fill 49 251 594 50 253 594 minecraft:cobbled_deepslate
setblock 49 251 598 minecraft:calcite
fill 50 251 558 50 254 558 minecraft:cobbled_deepslate
setblock 50 251 562 minecraft:calcite
setblock 50 251 597 minecraft:calcite
fill 50 251 598 50 254 598 minecraft:cobbled_deepslate
setblock 51 251 596 minecraft:calcite
fill 51 251 597 51 254 597 minecraft:cobbled_deepslate
setblock 52 251 560 minecraft:calcite
fill 52 251 596 52 254 596 minecraft:cobbled_deepslate
setblock 53 251 559 minecraft:calcite
fill 53 251 560 53 254 560 minecraft:cobbled_deepslate
setblock 54 251 558 minecraft:calcite
fill 54 251 559 54 254 559 minecraft:cobbled_deepslate
setblock 54 251 598 minecraft:calcite
fill 55 251 558 55 254 558 minecraft:cobbled_deepslate
setblock 55 251 597 minecraft:calcite
fill 55 251 598 58 251 598 minecraft:cobbled_deepslate
fill 56 251 559 56 252 559 minecraft:cobbled_deepslate
fill 56 251 597 59 251 597 minecraft:cobbled_deepslate
setblock 59 251 558 minecraft:calcite
setblock 59 251 598 minecraft:calcite
fill 60 251 558 63 251 558 minecraft:cobbled_deepslate
setblock 60 251 597 minecraft:calcite
fill 60 251 598 63 251 598 minecraft:cobbled_deepslate
fill 61 251 597 64 251 597 minecraft:cobbled_deepslate
setblock 64 251 558 minecraft:calcite
setblock 64 251 598 minecraft:calcite
fill 65 251 558 65 254 558 minecraft:cobbled_deepslate
setblock 65 251 596 minecraft:cobbled_deepslate
setblock 65 251 597 minecraft:calcite
fill 65 251 598 65 254 598 minecraft:cobbled_deepslate
fill 66 251 594 66 255 594 minecraft:deepslate
setblock 66 251 596 minecraft:calcite
fill 66 251 597 66 254 597 minecraft:cobbled_deepslate
setblock 67 251 559 minecraft:cobbled_deepslate
fill 67 251 593 67 255 593 minecraft:deepslate
fill 67 251 595 67 255 595 minecraft:deepslate
fill 67 251 596 67 254 596 minecraft:cobbled_deepslate
setblock 68 251 559 minecraft:calcite
fill 68 251 594 68 255 594 minecraft:deepslate
setblock 69 251 558 minecraft:calcite
fill 69 251 559 71 252 559 minecraft:cobbled_deepslate
setblock 69 251 598 minecraft:calcite
fill 70 251 558 70 254 558 minecraft:cobbled_deepslate
setblock 70 251 597 minecraft:calcite
fill 70 251 598 70 254 598 minecraft:cobbled_deepslate
setblock 71 251 596 minecraft:calcite
fill 71 251 597 71 254 597 minecraft:cobbled_deepslate
setblock 73 251 558 minecraft:cobbled_deepslate
setblock 74 251 558 minecraft:calcite
setblock 74 251 598 minecraft:calcite
fill 75 251 558 76 253 558 minecraft:cobbled_deepslate
fill 75 251 598 75 254 598 minecraft:cobbled_deepslate
fill 81 251 558 83 251 558 minecraft:cobbled_deepslate
setblock 83 251 598 minecraft:cobbled_deepslate
setblock 84 251 558 minecraft:calcite
fill 84 251 559 85 253 559 minecraft:cobbled_deepslate
setblock 84 251 598 minecraft:calcite
fill 85 251 558 85 254 558 minecraft:cobbled_deepslate
fill 85 251 598 85 254 598 minecraft:cobbled_deepslate
fill 86 251 574 86 251 575 minecraft:cobbled_deepslate
setblock 86 251 576 minecraft:calcite
fill 86 251 577 86 252 579 minecraft:cobbled_deepslate
fill 86 251 597 86 254 597 minecraft:cobbled_deepslate
fill 87 251 558 87 251 559 minecraft:cobbled_deepslate
setblock 87 251 560 minecraft:calcite
fill 87 251 561 87 254 561 minecraft:cobbled_deepslate
setblock 87 251 564 minecraft:cobbled_deepslate
setblock 87 251 565 minecraft:calcite
fill 87 251 566 87 253 567 minecraft:cobbled_deepslate
setblock 87 251 570 minecraft:calcite
fill 87 251 571 87 254 571 minecraft:cobbled_deepslate
setblock 87 251 575 minecraft:calcite
fill 87 251 576 87 254 576 minecraft:cobbled_deepslate
setblock 87 251 580 minecraft:calcite
fill 87 251 581 87 253 582 minecraft:cobbled_deepslate
fill 87 251 596 87 254 596 minecraft:cobbled_deepslate
setblock 88 251 559 minecraft:calcite
fill 88 251 560 88 254 560 minecraft:cobbled_deepslate
setblock 88 251 564 minecraft:calcite
fill 88 251 565 88 254 565 minecraft:cobbled_deepslate
setblock 88 251 569 minecraft:calcite
fill 88 251 570 88 254 570 minecraft:cobbled_deepslate
setblock 88 251 574 minecraft:calcite
fill 88 251 575 88 254 575 minecraft:cobbled_deepslate
setblock 88 251 579 minecraft:calcite
fill 88 251 580 88 254 580 minecraft:cobbled_deepslate
setblock 88 251 584 minecraft:calcite
fill 88 251 585 88 254 585 minecraft:cobbled_deepslate
setblock 88 251 594 minecraft:calcite
fill 88 251 595 88 254 595 minecraft:cobbled_deepslate
setblock 48 252 558 minecraft:calcite
fill 48 252 559 48 255 559 minecraft:cobbled_deepslate
setblock 48 252 563 minecraft:calcite
fill 48 252 564 48 255 564 minecraft:cobbled_deepslate
setblock 48 252 568 minecraft:calcite
fill 48 252 569 48 255 569 minecraft:cobbled_deepslate
setblock 48 252 573 minecraft:calcite
fill 48 252 574 48 255 574 minecraft:cobbled_deepslate
setblock 48 252 578 minecraft:calcite
fill 48 252 579 48 255 579 minecraft:cobbled_deepslate
setblock 48 252 583 minecraft:calcite
fill 48 252 584 48 252 587 minecraft:cobbled_deepslate
setblock 48 252 588 minecraft:calcite
fill 48 252 589 48 252 592 minecraft:cobbled_deepslate
setblock 48 252 593 minecraft:calcite
fill 48 252 594 48 255 594 minecraft:cobbled_deepslate
setblock 48 252 597 minecraft:cobbled_deepslate
setblock 48 252 598 minecraft:calcite
fill 49 252 558 49 255 558 minecraft:cobbled_deepslate
setblock 49 252 562 minecraft:calcite
fill 49 252 563 50 254 563 minecraft:cobbled_deepslate
setblock 49 252 566 minecraft:cobbled_deepslate
setblock 49 252 572 minecraft:calcite
fill 49 252 573 49 253 573 minecraft:cobbled_deepslate
setblock 49 252 577 minecraft:calcite
fill 49 252 578 49 255 578 minecraft:cobbled_deepslate
setblock 49 252 582 minecraft:calcite
fill 49 252 583 49 255 583 minecraft:cobbled_deepslate
setblock 49 252 592 minecraft:calcite
fill 49 252 593 49 255 593 minecraft:cobbled_deepslate
setblock 49 252 597 minecraft:calcite
fill 49 252 598 49 255 598 minecraft:cobbled_deepslate
setblock 50 252 560 minecraft:cobbled_deepslate
setblock 50 252 561 minecraft:calcite
fill 50 252 562 50 255 562 minecraft:cobbled_deepslate
setblock 50 252 568 minecraft:light[level=14]
setblock 50 252 576 minecraft:light[level=14]
setblock 50 252 584 minecraft:light[level=14]
setblock 50 252 592 minecraft:light[level=14]
setblock 50 252 596 minecraft:calcite
fill 50 252 597 50 255 597 minecraft:cobbled_deepslate
setblock 51 252 560 minecraft:calcite
fill 51 252 596 51 255 596 minecraft:cobbled_deepslate
setblock 52 252 559 minecraft:calcite
fill 52 252 560 52 255 560 minecraft:cobbled_deepslate
setblock 53 252 558 minecraft:calcite
fill 53 252 559 53 255 559 minecraft:cobbled_deepslate
setblock 53 252 598 minecraft:calcite
fill 54 252 558 54 255 558 minecraft:cobbled_deepslate
setblock 54 252 597 minecraft:calcite
fill 54 252 598 57 252 598 minecraft:cobbled_deepslate
fill 55 252 597 58 252 597 minecraft:cobbled_deepslate
setblock 58 252 558 minecraft:calcite
setblock 58 252 560 minecraft:light[level=14]
setblock 58 252 568 minecraft:light[level=14]
setblock 58 252 576 minecraft:light[level=14]
setblock 58 252 584 minecraft:light[level=14]
setblock 58 252 592 minecraft:light[level=14]
setblock 58 252 598 minecraft:calcite
fill 59 252 558 62 252 558 minecraft:cobbled_deepslate
setblock 59 252 597 minecraft:calcite
fill 59 252 598 62 252 598 minecraft:cobbled_deepslate
fill 60 252 597 63 252 597 minecraft:cobbled_deepslate
setblock 63 252 558 minecraft:calcite
setblock 63 252 598 minecraft:calcite
fill 64 252 558 64 255 558 minecraft:cobbled_deepslate
setblock 64 252 597 minecraft:calcite
fill 64 252 598 64 255 598 minecraft:cobbled_deepslate
fill 65 252 559 66 252 559 minecraft:cobbled_deepslate
setblock 65 252 596 minecraft:calcite
fill 65 252 597 65 255 597 minecraft:cobbled_deepslate
setblock 66 252 560 minecraft:light[level=14]
setblock 66 252 568 minecraft:light[level=14]
setblock 66 252 576 minecraft:light[level=14]
setblock 66 252 584 minecraft:light[level=14]
setblock 66 252 592 minecraft:light[level=14]
fill 66 252 596 66 255 596 minecraft:cobbled_deepslate
setblock 67 252 559 minecraft:calcite
setblock 68 252 558 minecraft:calcite
fill 68 252 559 68 255 559 minecraft:cobbled_deepslate
setblock 68 252 598 minecraft:calcite
fill 69 252 558 69 255 558 minecraft:cobbled_deepslate
setblock 69 252 597 minecraft:calcite
fill 69 252 598 69 255 598 minecraft:cobbled_deepslate
setblock 70 252 596 minecraft:calcite
fill 70 252 597 70 255 597 minecraft:cobbled_deepslate
setblock 72 252 559 minecraft:calcite
setblock 73 252 558 minecraft:calcite
setblock 73 252 598 minecraft:calcite
fill 74 252 558 74 255 558 minecraft:cobbled_deepslate
setblock 74 252 560 minecraft:light[level=14]
setblock 74 252 568 minecraft:light[level=14]
setblock 74 252 576 minecraft:light[level=14]
setblock 74 252 584 minecraft:light[level=14]
setblock 74 252 592 minecraft:light[level=14]
fill 74 252 598 74 255 598 minecraft:cobbled_deepslate
setblock 77 252 558 minecraft:cobbled_deepslate
setblock 78 252 558 minecraft:calcite
fill 79 252 558 82 252 558 minecraft:cobbled_deepslate
setblock 82 252 560 minecraft:light[level=14]
setblock 82 252 568 minecraft:light[level=14]
setblock 82 252 576 minecraft:light[level=14]
setblock 82 252 584 minecraft:light[level=14]
setblock 82 252 592 minecraft:light[level=14]
setblock 82 252 598 minecraft:cobbled_deepslate
setblock 83 252 558 minecraft:calcite
fill 83 252 559 83 255 559 minecraft:cobbled_deepslate
setblock 83 252 598 minecraft:calcite
fill 84 252 558 84 255 558 minecraft:cobbled_deepslate
fill 84 252 598 84 255 598 minecraft:cobbled_deepslate
setblock 85 252 560 minecraft:cobbled_deepslate
setblock 86 252 560 minecraft:calcite
fill 86 252 561 86 253 563 minecraft:cobbled_deepslate
fill 86 252 572 86 254 572 minecraft:cobbled_deepslate
setblock 86 252 574 minecraft:cobbled_deepslate
setblock 86 252 575 minecraft:calcite
fill 86 252 576 86 255 576 minecraft:cobbled_deepslate
setblock 86 252 580 minecraft:calcite
setblock 87 252 558 minecraft:cobbled_deepslate
setblock 87 252 559 minecraft:calcite
fill 87 252 560 87 255 560 minecraft:cobbled_deepslate
setblock 87 252 564 minecraft:calcite
fill 87 252 565 87 255 565 minecraft:cobbled_deepslate
setblock 87 252 569 minecraft:calcite
fill 87 252 570 87 255 570 minecraft:cobbled_deepslate
setblock 87 252 574 minecraft:calcite
fill 87 252 575 87 255 575 minecraft:cobbled_deepslate
setblock 87 252 579 minecraft:calcite
fill 87 252 580 87 255 580 minecraft:cobbled_deepslate
setblock 87 252 583 minecraft:cobbled_deepslate
setblock 88 252 558 minecraft:calcite
fill 88 252 559 88 255 559 minecraft:cobbled_deepslate
setblock 88 252 563 minecraft:calcite
fill 88 252 564 88 255 564 minecraft:cobbled_deepslate
setblock 88 252 568 minecraft:calcite
fill 88 252 569 88 255 569 minecraft:cobbled_deepslate
setblock 88 252 573 minecraft:calcite
fill 88 252 574 88 255 574 minecraft:cobbled_deepslate
setblock 88 252 578 minecraft:calcite
fill 88 252 579 88 255 579 minecraft:cobbled_deepslate
setblock 88 252 583 minecraft:calcite
fill 88 252 584 88 255 584 minecraft:cobbled_deepslate
fill 88 252 586 88 253 586 minecraft:cobbled_deepslate
setblock 88 252 592 minecraft:cobbled_deepslate
setblock 88 252 593 minecraft:calcite
fill 88 252 594 88 255 594 minecraft:cobbled_deepslate
setblock 88 252 598 minecraft:calcite
fill 48 253 558 48 256 558 minecraft:cobbled_deepslate
setblock 48 253 562 minecraft:calcite
fill 48 253 563 48 256 563 minecraft:cobbled_deepslate
setblock 48 253 567 minecraft:calcite
fill 48 253 568 48 256 568 minecraft:cobbled_deepslate
setblock 48 253 572 minecraft:calcite
fill 48 253 573 48 256 573 minecraft:cobbled_deepslate
setblock 48 253 577 minecraft:calcite
fill 48 253 578 48 256 578 minecraft:cobbled_deepslate
setblock 48 253 581 minecraft:cobbled_deepslate
setblock 48 253 582 minecraft:calcite
fill 48 253 583 48 253 586 minecraft:cobbled_deepslate
setblock 48 253 587 minecraft:calcite
fill 48 253 588 48 253 591 minecraft:cobbled_deepslate
setblock 48 253 592 minecraft:calcite
fill 48 253 593 48 256 593 minecraft:cobbled_deepslate
setblock 48 253 597 minecraft:calcite
fill 48 253 598 48 256 598 minecraft:cobbled_deepslate
setblock 49 253 561 minecraft:calcite
fill 49 253 562 49 256 562 minecraft:cobbled_deepslate
setblock 49 253 566 minecraft:calcite
fill 49 253 567 49 255 567 minecraft:cobbled_deepslate
setblock 49 253 576 minecraft:calcite
fill 49 253 577 49 256 577 minecraft:cobbled_deepslate
setblock 49 253 581 minecraft:calcite
fill 49 253 582 49 256 582 minecraft:cobbled_deepslate
fill 49 253 584 49 253 585 minecraft:cobbled_deepslate
fill 49 253 592 49 256 592 minecraft:cobbled_deepslate
setblock 49 253 596 minecraft:calcite
fill 49 253 597 49 256 597 minecraft:cobbled_deepslate
setblock 50 253 560 minecraft:calcite
fill 50 253 561 50 256 561 minecraft:cobbled_deepslate
setblock 50 253 595 minecraft:calcite
fill 50 253 596 50 256 596 minecraft:cobbled_deepslate
setblock 51 253 559 minecraft:calcite
fill 51 253 560 51 256 560 minecraft:cobbled_deepslate
setblock 52 253 558 minecraft:calcite
fill 52 253 559 52 256 559 minecraft:cobbled_deepslate
setblock 52 253 598 minecraft:calcite
fill 53 253 558 53 256 558 minecraft:cobbled_deepslate
setblock 53 253 597 minecraft:calcite
fill 53 253 598 56 253 598 minecraft:cobbled_deepslate
setblock 54 253 596 minecraft:calcite
fill 54 253 597 57 253 597 minecraft:cobbled_deepslate
setblock 56 253 559 minecraft:calcite
setblock 57 253 558 minecraft:calcite
setblock 57 253 598 minecraft:calcite
fill 58 253 558 61 253 558 minecraft:cobbled_deepslate
setblock 58 253 597 minecraft:calcite
fill 58 253 598 61 253 598 minecraft:cobbled_deepslate
fill 59 253 597 62 253 597 minecraft:cobbled_deepslate
setblock 62 253 558 minecraft:calcite
setblock 62 253 598 minecraft:calcite
fill 63 253 558 63 255 559 minecraft:cobbled_deepslate
setblock 63 253 597 minecraft:calcite
fill 63 253 598 63 256 598 minecraft:cobbled_deepslate
fill 64 253 559 65 253 559 minecraft:cobbled_deepslate
setblock 64 253 596 minecraft:calcite
fill 64 253 597 64 256 597 minecraft:cobbled_deepslate
fill 65 253 596 65 255 596 minecraft:cobbled_deepslate
setblock 66 253 559 minecraft:calcite
setblock 67 253 558 minecraft:calcite
fill 67 253 559 67 256 559 minecraft:cobbled_deepslate
setblock 67 253 598 minecraft:calcite
fill 68 253 558 68 256 558 minecraft:cobbled_deepslate
setblock 68 253 597 minecraft:calcite
fill 68 253 598 68 256 598 minecraft:cobbled_deepslate
fill 69 253 559 70 253 559 minecraft:cobbled_deepslate
setblock 69 253 596 minecraft:calcite
fill 69 253 597 69 256 597 minecraft:cobbled_deepslate
setblock 71 253 559 minecraft:calcite
setblock 72 253 558 minecraft:calcite
fill 72 253 559 73 255 559 minecraft:cobbled_deepslate
setblock 72 253 598 minecraft:calcite
fill 73 253 558 73 256 558 minecraft:cobbled_deepslate
fill 73 253 598 73 255 598 minecraft:cobbled_deepslate
setblock 77 253 558 minecraft:calcite
fill 78 253 558 81 253 558 minecraft:cobbled_deepslate
fill 80 253 595 81 253 598 minecraft:light_blue_stained_glass
setblock 81 253 559 minecraft:calcite
fill 81 253 592 81 254 594 minecraft:light_blue_stained_glass
setblock 82 253 558 minecraft:calcite
fill 82 253 559 82 256 559 minecraft:cobbled_deepslate
fill 82 253 595 82 255 597 minecraft:light_blue_stained_glass
setblock 82 253 598 minecraft:calcite
fill 83 253 558 83 256 558 minecraft:cobbled_deepslate
fill 83 253 598 83 256 598 minecraft:cobbled_deepslate
setblock 84 253 560 minecraft:cobbled_deepslate
setblock 85 253 560 minecraft:calcite
fill 85 253 597 85 255 597 minecraft:cobbled_deepslate
setblock 86 253 558 minecraft:cobbled_deepslate
setblock 86 253 559 minecraft:calcite
fill 86 253 560 86 256 560 minecraft:cobbled_deepslate
setblock 86 253 564 minecraft:calcite
fill 86 253 565 86 256 565 minecraft:cobbled_deepslate
setblock 86 253 574 minecraft:calcite
fill 86 253 575 86 256 575 minecraft:cobbled_deepslate
fill 86 253 577 86 253 578 minecraft:cobbled_deepslate
setblock 86 253 579 minecraft:calcite
fill 86 253 580 86 255 581 minecraft:cobbled_deepslate
setblock 87 253 558 minecraft:calcite
fill 87 253 559 87 256 559 minecraft:cobbled_deepslate
setblock 87 253 562 minecraft:cobbled_deepslate
setblock 87 253 563 minecraft:calcite
fill 87 253 564 87 256 564 minecraft:cobbled_deepslate
setblock 87 253 568 minecraft:calcite
fill 87 253 569 87 256 569 minecraft:cobbled_deepslate
setblock 87 253 573 minecraft:calcite
fill 87 253 574 87 256 574 minecraft:cobbled_deepslate
setblock 87 253 578 minecraft:calcite
fill 87 253 579 87 256 579 minecraft:cobbled_deepslate
setblock 87 253 583 minecraft:calcite
fill 87 253 584 87 256 584 minecraft:cobbled_deepslate
fill 87 253 595 87 255 595 minecraft:cobbled_deepslate
setblock 87 253 598 minecraft:calcite
fill 88 253 558 88 256 558 minecraft:cobbled_deepslate
setblock 88 253 562 minecraft:calcite
fill 88 253 563 88 256 563 minecraft:cobbled_deepslate
setblock 88 253 567 minecraft:calcite
fill 88 253 568 88 256 568 minecraft:cobbled_deepslate
setblock 88 253 572 minecraft:calcite
fill 88 253 573 88 256 573 minecraft:cobbled_deepslate
setblock 88 253 577 minecraft:calcite
fill 88 253 578 88 256 578 minecraft:cobbled_deepslate
setblock 88 253 582 minecraft:calcite
fill 88 253 583 88 256 583 minecraft:cobbled_deepslate
setblock 88 253 587 minecraft:calcite
fill 88 253 588 88 256 588 minecraft:cobbled_deepslate
setblock 88 253 592 minecraft:calcite
fill 88 253 593 88 256 593 minecraft:cobbled_deepslate
setblock 88 253 597 minecraft:calcite
fill 88 253 598 88 256 598 minecraft:cobbled_deepslate
setblock 48 254 561 minecraft:calcite
fill 48 254 562 48 257 562 minecraft:cobbled_deepslate
setblock 48 254 565 minecraft:cobbled_deepslate
setblock 48 254 566 minecraft:calcite
fill 48 254 567 48 257 567 minecraft:cobbled_deepslate
setblock 48 254 571 minecraft:calcite
fill 48 254 572 48 256 572 minecraft:cobbled_deepslate
setblock 48 254 576 minecraft:calcite
fill 48 254 577 48 257 577 minecraft:cobbled_deepslate
setblock 48 254 580 minecraft:cobbled_deepslate
setblock 48 254 581 minecraft:calcite
fill 48 254 582 48 254 585 minecraft:cobbled_deepslate
setblock 48 254 586 minecraft:calcite
fill 48 254 587 48 254 590 minecraft:cobbled_deepslate
setblock 48 254 591 minecraft:calcite
fill 48 254 592 48 257 592 minecraft:cobbled_deepslate
setblock 48 254 596 minecraft:calcite
fill 48 254 597 48 257 597 minecraft:cobbled_deepslate
setblock 49 254 560 minecraft:calcite
fill 49 254 561 49 257 561 minecraft:cobbled_deepslate
setblock 49 254 565 minecraft:calcite
fill 49 254 566 49 257 566 minecraft:cobbled_deepslate
setblock 49 254 575 minecraft:calcite
fill 49 254 576 49 255 576 minecraft:cobbled_deepslate
setblock 49 254 580 minecraft:calcite
fill 49 254 581 49 257 581 minecraft:cobbled_deepslate
setblock 49 254 584 minecraft:cobbled_deepslate
setblock 49 254 585 minecraft:calcite
fill 49 254 586 49 256 587 minecraft:cobbled_deepslate
fill 49 254 591 49 256 591 minecraft:cobbled_deepslate
setblock 49 254 594 minecraft:cobbled_deepslate
setblock 49 254 595 minecraft:calcite
fill 49 254 596 49 257 596 minecraft:cobbled_deepslate
setblock 50 254 559 minecraft:calcite
fill 50 254 560 50 257 560 minecraft:cobbled_deepslate
fill 50 254 595 50 255 595 minecraft:cobbled_deepslate
setblock 51 254 558 minecraft:calcite
fill 51 254 559 51 257 559 minecraft:cobbled_deepslate
setblock 51 254 598 minecraft:calcite
fill 52 254 558 52 257 558 minecraft:cobbled_deepslate
setblock 52 254 597 minecraft:calcite
fill 52 254 598 55 254 598 minecraft:cobbled_deepslate
setblock 53 254 596 minecraft:calcite
fill 53 254 597 56 254 597 minecraft:cobbled_deepslate
setblock 55 254 559 minecraft:calcite
setblock 56 254 558 minecraft:calcite
fill 56 254 559 57 254 559 minecraft:cobbled_deepslate
setblock 56 254 598 minecraft:calcite
fill 57 254 558 60 254 558 minecraft:cobbled_deepslate
setblock 57 254 597 minecraft:calcite
fill 57 254 598 60 254 598 minecraft:cobbled_deepslate
fill 58 254 597 61 254 597 minecraft:cobbled_deepslate
setblock 61 254 558 minecraft:calcite
setblock 61 254 598 minecraft:calcite
fill 62 254 558 62 256 559 minecraft:cobbled_deepslate
setblock 62 254 597 minecraft:calcite
fill 62 254 598 62 257 598 minecraft:cobbled_deepslate
fill 63 254 597 63 257 597 minecraft:cobbled_deepslate
setblock 64 254 559 minecraft:cobbled_deepslate
setblock 64 254 596 minecraft:cobbled_deepslate
setblock 65 254 559 minecraft:calcite
setblock 66 254 558 minecraft:calcite
fill 66 254 559 66 257 559 minecraft:cobbled_deepslate
fill 66 254 593 66 255 593 minecraft:deepslate
fill 66 254 595 66 255 595 minecraft:deepslate
setblock 66 254 598 minecraft:calcite
fill 67 254 558 67 257 558 minecraft:cobbled_deepslate
fill 67 254 560 68 254 560 minecraft:cobbled_deepslate
setblock 67 254 597 minecraft:calcite
fill 67 254 598 67 257 598 minecraft:cobbled_deepslate
fill 68 254 593 68 255 593 minecraft:deepslate
fill 68 254 595 68 255 595 minecraft:deepslate
setblock 68 254 596 minecraft:calcite
fill 68 254 597 68 257 597 minecraft:cobbled_deepslate
setblock 69 254 559 minecraft:cobbled_deepslate
setblock 70 254 559 minecraft:calcite
setblock 71 254 558 minecraft:calcite
fill 71 254 559 71 257 559 minecraft:cobbled_deepslate
setblock 71 254 598 minecraft:calcite
fill 72 254 558 72 257 558 minecraft:cobbled_deepslate
setblock 72 254 597 minecraft:calcite
fill 72 254 598 72 256 598 minecraft:cobbled_deepslate
setblock 75 254 558 minecraft:cobbled_deepslate
setblock 76 254 558 minecraft:calcite
fill 77 254 558 80 254 558 minecraft:cobbled_deepslate
fill 79 254 596 80 255 598 minecraft:light_blue_stained_glass
setblock 80 254 559 minecraft:calcite
fill 80 254 593 80 254 595 minecraft:light_blue_stained_glass
setblock 81 254 558 minecraft:calcite
fill 81 254 559 81 257 559 minecraft:cobbled_deepslate
setblock 81 254 591 minecraft:light_blue_stained_glass
fill 81 254 595 81 256 597 minecraft:light_blue_stained_glass
setblock 81 254 598 minecraft:calcite
fill 82 254 558 82 257 558 minecraft:cobbled_deepslate
fill 82 254 560 83 254 560 minecraft:cobbled_deepslate
fill 82 254 593 82 254 594 minecraft:light_blue_stained_glass
fill 82 254 598 82 257 598 minecraft:cobbled_deepslate
fill 83 254 596 83 255 597 minecraft:light_blue_stained_glass
setblock 84 254 559 minecraft:cobbled_deepslate
setblock 84 254 560 minecraft:calcite
setblock 85 254 559 minecraft:calcite
fill 85 254 560 85 255 562 minecraft:cobbled_deepslate
setblock 86 254 558 minecraft:calcite
fill 86 254 559 86 257 559 minecraft:cobbled_deepslate
fill 86 254 561 86 254 562 minecraft:cobbled_deepslate
setblock 86 254 563 minecraft:calcite
fill 86 254 564 86 257 564 minecraft:cobbled_deepslate
fill 86 254 566 86 254 567 minecraft:cobbled_deepslate
setblock 86 254 573 minecraft:calcite
fill 86 254 574 86 255 574 minecraft:cobbled_deepslate
setblock 86 254 577 minecraft:cobbled_deepslate
setblock 86 254 578 minecraft:calcite
fill 86 254 579 86 257 579 minecraft:cobbled_deepslate
setblock 86 254 582 minecraft:cobbled_deepslate
setblock 86 254 598 minecraft:calcite
fill 87 254 558 87 257 558 minecraft:cobbled_deepslate
setblock 87 254 562 minecraft:calcite
fill 87 254 563 87 257 563 minecraft:cobbled_deepslate
setblock 87 254 566 minecraft:cobbled_deepslate
setblock 87 254 567 minecraft:calcite
fill 87 254 568 87 257 568 minecraft:cobbled_deepslate
setblock 87 254 572 minecraft:calcite
fill 87 254 573 87 257 573 minecraft:cobbled_deepslate
setblock 87 254 577 minecraft:calcite
fill 87 254 578 87 257 578 minecraft:cobbled_deepslate
setblock 87 254 581 minecraft:cobbled_deepslate
setblock 87 254 582 minecraft:calcite
fill 87 254 583 87 257 583 minecraft:cobbled_deepslate
fill 87 254 585 87 255 585 minecraft:cobbled_deepslate
setblock 87 254 597 minecraft:calcite
fill 87 254 598 87 257 598 minecraft:cobbled_deepslate
setblock 88 254 561 minecraft:calcite
fill 88 254 562 88 257 562 minecraft:cobbled_deepslate
setblock 88 254 566 minecraft:calcite
fill 88 254 567 88 257 567 minecraft:cobbled_deepslate
setblock 88 254 571 minecraft:calcite
fill 88 254 572 88 257 572 minecraft:cobbled_deepslate
setblock 88 254 576 minecraft:calcite
fill 88 254 577 88 257 577 minecraft:cobbled_deepslate
setblock 88 254 581 minecraft:calcite
fill 88 254 582 88 257 582 minecraft:cobbled_deepslate
setblock 88 254 586 minecraft:calcite
fill 88 254 587 88 257 587 minecraft:cobbled_deepslate
fill 88 254 589 88 254 590 minecraft:cobbled_deepslate
setblock 88 254 591 minecraft:calcite
fill 88 254 592 88 257 592 minecraft:cobbled_deepslate
setblock 88 254 596 minecraft:calcite
fill 88 254 597 88 257 597 minecraft:cobbled_deepslate
setblock 48 255 560 minecraft:calcite
fill 48 255 561 48 258 561 minecraft:cobbled_deepslate
setblock 48 255 565 minecraft:calcite
fill 48 255 566 48 258 566 minecraft:cobbled_deepslate
setblock 48 255 570 minecraft:calcite
fill 48 255 571 48 256 571 minecraft:cobbled_deepslate
setblock 48 255 575 minecraft:calcite
fill 48 255 576 48 258 576 minecraft:cobbled_deepslate
setblock 48 255 580 minecraft:calcite
fill 48 255 581 48 255 584 minecraft:cobbled_deepslate
setblock 48 255 585 minecraft:calcite
fill 48 255 586 48 255 589 minecraft:cobbled_deepslate
setblock 48 255 590 minecraft:calcite
fill 48 255 591 48 258 591 minecraft:cobbled_deepslate
setblock 48 255 595 minecraft:calcite
fill 48 255 596 48 258 596 minecraft:cobbled_deepslate
setblock 49 255 559 minecraft:calcite
fill 49 255 560 49 258 560 minecraft:cobbled_deepslate
setblock 49 255 563 minecraft:cobbled_deepslate
setblock 49 255 564 minecraft:calcite
fill 49 255 565 49 258 565 minecraft:cobbled_deepslate
setblock 49 255 575 minecraft:cobbled_deepslate
setblock 49 255 579 minecraft:calcite
fill 49 255 580 49 258 580 minecraft:cobbled_deepslate
setblock 49 255 584 minecraft:calcite
fill 49 255 585 49 258 585 minecraft:cobbled_deepslate
setblock 49 255 588 minecraft:cobbled_deepslate
setblock 49 255 589 minecraft:calcite
fill 49 255 590 49 256 590 minecraft:cobbled_deepslate
setblock 49 255 594 minecraft:calcite
fill 49 255 595 49 258 595 minecraft:cobbled_deepslate
setblock 50 255 558 minecraft:calcite
fill 50 255 559 50 258 559 minecraft:cobbled_deepslate
setblock 50 255 563 minecraft:calcite
setblock 50 255 598 minecraft:calcite
fill 51 255 558 51 258 558 minecraft:cobbled_deepslate
setblock 51 255 597 minecraft:calcite
fill 51 255 598 54 255 598 minecraft:cobbled_deepslate
fill 52 255 597 55 255 597 minecraft:cobbled_deepslate
setblock 53 255 560 minecraft:calcite
setblock 54 255 559 minecraft:calcite
setblock 55 255 558 minecraft:calcite
fill 55 255 559 56 255 559 minecraft:cobbled_deepslate
setblock 55 255 598 minecraft:calcite
fill 56 255 558 59 255 558 minecraft:cobbled_deepslate
setblock 56 255 597 minecraft:calcite
fill 56 255 598 59 255 598 minecraft:cobbled_deepslate
fill 57 255 597 60 255 597 minecraft:cobbled_deepslate
setblock 60 255 558 minecraft:calcite
setblock 60 255 598 minecraft:calcite
fill 61 255 558 61 257 559 minecraft:cobbled_deepslate
setblock 61 255 597 minecraft:calcite
fill 61 255 598 61 258 598 minecraft:cobbled_deepslate
fill 62 255 597 62 257 597 minecraft:cobbled_deepslate
setblock 64 255 559 minecraft:calcite
setblock 65 255 558 minecraft:calcite
fill 65 255 559 65 258 559 minecraft:cobbled_deepslate
setblock 65 255 598 minecraft:calcite
fill 66 255 558 66 258 558 minecraft:cobbled_deepslate
fill 66 255 560 67 255 560 minecraft:cobbled_deepslate
setblock 66 255 597 minecraft:calcite
fill 66 255 598 66 258 598 minecraft:cobbled_deepslate
setblock 67 255 596 minecraft:calcite
fill 67 255 597 67 257 597 minecraft:cobbled_deepslate
setblock 68 255 560 minecraft:calcite
setblock 69 255 559 minecraft:calcite
setblock 69 255 560 minecraft:cobbled_deepslate
setblock 70 255 558 minecraft:calcite
fill 70 255 559 70 257 559 minecraft:cobbled_deepslate
setblock 70 255 598 minecraft:calcite
fill 71 255 558 71 258 558 minecraft:cobbled_deepslate
setblock 71 255 597 minecraft:calcite
fill 71 255 598 71 257 598 minecraft:cobbled_deepslate
setblock 75 255 558 minecraft:calcite
fill 76 255 558 79 255 558 minecraft:cobbled_deepslate
setblock 79 255 559 minecraft:calcite
setblock 80 255 558 minecraft:calcite
fill 80 255 559 80 258 559 minecraft:cobbled_deepslate
fill 80 255 594 80 255 595 minecraft:light_blue_stained_glass
fill 81 255 558 81 258 558 minecraft:cobbled_deepslate
fill 81 255 593 81 255 594 minecraft:light_blue_stained_glass
fill 81 255 598 81 256 598 minecraft:cobbled_deepslate
setblock 82 255 560 minecraft:cobbled_deepslate
setblock 82 255 594 minecraft:light_blue_stained_glass
setblock 83 255 560 minecraft:calcite
setblock 84 255 559 minecraft:calcite
fill 84 255 560 84 257 561 minecraft:cobbled_deepslate
setblock 85 255 558 minecraft:calcite
fill 85 255 559 85 258 559 minecraft:cobbled_deepslate
setblock 85 255 563 minecraft:calcite
fill 85 255 564 85 258 564 minecraft:cobbled_deepslate
setblock 85 255 598 minecraft:calcite
fill 86 255 558 86 258 558 minecraft:cobbled_deepslate
setblock 86 255 561 minecraft:cobbled_deepslate
setblock 86 255 562 minecraft:calcite
fill 86 255 563 86 258 563 minecraft:cobbled_deepslate
setblock 86 255 566 minecraft:cobbled_deepslate
setblock 86 255 567 minecraft:calcite
fill 86 255 568 86 258 568 minecraft:cobbled_deepslate
setblock 86 255 573 minecraft:cobbled_deepslate
setblock 86 255 577 minecraft:calcite
fill 86 255 578 86 257 578 minecraft:cobbled_deepslate
setblock 86 255 582 minecraft:calcite
fill 86 255 583 86 257 583 minecraft:cobbled_deepslate
setblock 86 255 597 minecraft:calcite
fill 86 255 598 86 258 598 minecraft:cobbled_deepslate
setblock 87 255 561 minecraft:calcite
fill 87 255 562 87 258 562 minecraft:cobbled_deepslate
setblock 87 255 566 minecraft:calcite
fill 87 255 567 87 258 567 minecraft:cobbled_deepslate
setblock 87 255 571 minecraft:calcite
fill 87 255 572 87 257 572 minecraft:cobbled_deepslate
setblock 87 255 576 minecraft:calcite
fill 87 255 577 87 258 577 minecraft:cobbled_deepslate
setblock 87 255 581 minecraft:calcite
fill 87 255 582 87 258 582 minecraft:cobbled_deepslate
setblock 87 255 586 minecraft:calcite
setblock 87 255 596 minecraft:calcite
fill 87 255 597 87 258 597 minecraft:cobbled_deepslate
setblock 88 255 560 minecraft:calcite
fill 88 255 561 88 258 561 minecraft:cobbled_deepslate
setblock 88 255 565 minecraft:calcite
fill 88 255 566 88 258 566 minecraft:cobbled_deepslate
setblock 88 255 570 minecraft:calcite
fill 88 255 571 88 258 571 minecraft:cobbled_deepslate
setblock 88 255 575 minecraft:calcite
fill 88 255 576 88 258 576 minecraft:cobbled_deepslate
setblock 88 255 580 minecraft:calcite
fill 88 255 581 88 258 581 minecraft:cobbled_deepslate
setblock 88 255 585 minecraft:calcite
fill 88 255 586 88 258 586 minecraft:cobbled_deepslate
setblock 88 255 589 minecraft:cobbled_deepslate
setblock 88 255 590 minecraft:calcite
fill 88 255 591 88 257 591 minecraft:cobbled_deepslate
setblock 88 255 595 minecraft:calcite
fill 88 255 596 88 258 596 minecraft:cobbled_deepslate
setblock 48 256 559 minecraft:calcite
fill 48 256 560 48 259 560 minecraft:cobbled_deepslate
setblock 48 256 564 minecraft:calcite
fill 48 256 565 48 259 565 minecraft:cobbled_deepslate
setblock 48 256 569 minecraft:calcite
fill 48 256 570 48 257 570 minecraft:cobbled_deepslate
setblock 48 256 574 minecraft:calcite
fill 48 256 575 48 257 575 minecraft:cobbled_deepslate
setblock 48 256 579 minecraft:calcite
fill 48 256 580 48 256 583 minecraft:cobbled_deepslate
setblock 48 256 584 minecraft:calcite
fill 48 256 585 48 256 588 minecraft:cobbled_deepslate
setblock 48 256 589 minecraft:calcite
fill 48 256 590 48 259 590 minecraft:cobbled_deepslate
setblock 48 256 594 minecraft:calcite
fill 48 256 595 48 259 595 minecraft:cobbled_deepslate
setblock 49 256 558 minecraft:calcite
fill 49 256 559 49 259 559 minecraft:cobbled_deepslate
setblock 49 256 563 minecraft:calcite
fill 49 256 564 49 259 564 minecraft:cobbled_deepslate
setblock 49 256 578 minecraft:calcite
fill 49 256 579 49 257 579 minecraft:cobbled_deepslate
setblock 49 256 583 minecraft:calcite
fill 49 256 584 49 259 584 minecraft:cobbled_deepslate
setblock 49 256 588 minecraft:calcite
fill 49 256 589 49 258 589 minecraft:cobbled_deepslate
setblock 49 256 593 minecraft:calcite
fill 49 256 594 49 257 594 minecraft:cobbled_deepslate
setblock 49 256 598 minecraft:calcite
fill 50 256 558 50 259 558 minecraft:cobbled_deepslate
setblock 50 256 562 minecraft:calcite
fill 50 256 563 50 257 563 minecraft:cobbled_deepslate
setblock 50 256 597 minecraft:calcite
fill 50 256 598 53 256 598 minecraft:cobbled_deepslate
fill 51 256 597 54 256 597 minecraft:cobbled_deepslate
setblock 52 256 560 minecraft:calcite
setblock 53 256 559 minecraft:calcite
setblock 54 256 558 minecraft:calcite
fill 54 256 559 55 256 559 minecraft:cobbled_deepslate
setblock 54 256 598 minecraft:calcite
fill 55 256 558 58 256 558 minecraft:cobbled_deepslate
setblock 55 256 597 minecraft:calcite
fill 55 256 598 58 256 598 minecraft:cobbled_deepslate
setblock 59 256 558 minecraft:calcite
setblock 59 256 598 minecraft:calcite
fill 60 256 558 60 259 558 minecraft:cobbled_deepslate
setblock 60 256 597 minecraft:calcite
fill 60 256 598 60 259 598 minecraft:cobbled_deepslate
fill 61 256 597 61 257 597 minecraft:cobbled_deepslate
setblock 63 256 558 minecraft:cobbled_deepslate
setblock 63 256 559 minecraft:calcite
setblock 64 256 558 minecraft:calcite
fill 64 256 559 64 259 559 minecraft:cobbled_deepslate
setblock 64 256 598 minecraft:calcite
fill 65 256 558 65 259 558 minecraft:cobbled_deepslate
fill 65 256 560 66 256 560 minecraft:cobbled_deepslate
setblock 65 256 597 minecraft:calcite
fill 65 256 598 65 259 598 minecraft:cobbled_deepslate
fill 66 256 597 66 257 597 minecraft:cobbled_deepslate
setblock 67 256 560 minecraft:calcite
setblock 68 256 559 minecraft:calcite
setblock 68 256 560 minecraft:cobbled_deepslate
setblock 69 256 558 minecraft:calcite
fill 69 256 559 69 258 559 minecraft:cobbled_deepslate
setblock 69 256 598 minecraft:calcite
fill 70 256 558 70 259 558 minecraft:cobbled_deepslate
fill 70 256 598 70 257 598 minecraft:cobbled_deepslate
setblock 72 256 559 minecraft:cobbled_deepslate
setblock 74 256 558 minecraft:calcite
fill 75 256 558 78 256 558 minecraft:cobbled_deepslate
setblock 79 256 558 minecraft:calcite
fill 79 256 559 79 259 559 minecraft:cobbled_deepslate
fill 80 256 558 80 259 558 minecraft:cobbled_deepslate
fill 80 256 596 80 256 598 minecraft:light_blue_stained_glass
setblock 81 256 560 minecraft:cobbled_deepslate
setblock 82 256 560 minecraft:calcite
fill 82 256 596 82 256 597 minecraft:light_blue_stained_glass
setblock 83 256 559 minecraft:calcite
fill 83 256 560 83 258 561 minecraft:cobbled_deepslate
setblock 84 256 558 minecraft:calcite
fill 84 256 559 84 259 559 minecraft:cobbled_deepslate
setblock 84 256 598 minecraft:calcite
fill 85 256 558 85 259 558 minecraft:cobbled_deepslate
fill 85 256 560 85 256 561 minecraft:cobbled_deepslate
setblock 85 256 562 minecraft:calcite
fill 85 256 563 85 259 563 minecraft:cobbled_deepslate
fill 85 256 565 85 257 565 minecraft:cobbled_deepslate
setblock 85 256 597 minecraft:calcite
fill 85 256 598 85 259 598 minecraft:cobbled_deepslate
setblock 86 256 561 minecraft:calcite
fill 86 256 562 86 259 562 minecraft:cobbled_deepslate
setblock 86 256 566 minecraft:calcite
fill 86 256 567 86 259 567 minecraft:cobbled_deepslate
setblock 86 256 569 minecraft:cobbled_deepslate
setblock 86 256 576 minecraft:calcite
fill 86 256 577 86 257 577 minecraft:cobbled_deepslate
setblock 86 256 580 minecraft:cobbled_deepslate
setblock 86 256 581 minecraft:calcite
fill 86 256 582 86 258 582 minecraft:cobbled_deepslate
fill 86 256 597 86 257 597 minecraft:cobbled_deepslate
setblock 87 256 560 minecraft:calcite
fill 87 256 561 87 259 561 minecraft:cobbled_deepslate
setblock 87 256 565 minecraft:calcite
fill 87 256 566 87 259 566 minecraft:cobbled_deepslate
setblock 87 256 570 minecraft:calcite
fill 87 256 571 87 258 571 minecraft:cobbled_deepslate
setblock 87 256 575 minecraft:calcite
fill 87 256 576 87 258 576 minecraft:cobbled_deepslate
setblock 87 256 580 minecraft:calcite
fill 87 256 581 87 259 581 minecraft:cobbled_deepslate
setblock 87 256 585 minecraft:calcite
fill 87 256 586 87 259 586 minecraft:cobbled_deepslate
setblock 87 256 596 minecraft:cobbled_deepslate
setblock 88 256 559 minecraft:calcite
fill 88 256 560 88 259 560 minecraft:cobbled_deepslate
setblock 88 256 564 minecraft:calcite
fill 88 256 565 88 259 565 minecraft:cobbled_deepslate
setblock 88 256 569 minecraft:calcite
fill 88 256 570 88 259 570 minecraft:cobbled_deepslate
setblock 88 256 574 minecraft:calcite
fill 88 256 575 88 259 575 minecraft:cobbled_deepslate
setblock 88 256 579 minecraft:calcite
fill 88 256 580 88 259 580 minecraft:cobbled_deepslate
setblock 88 256 584 minecraft:calcite
fill 88 256 585 88 259 585 minecraft:cobbled_deepslate
setblock 88 256 589 minecraft:calcite
fill 88 256 590 88 259 590 minecraft:cobbled_deepslate
setblock 88 256 594 minecraft:calcite
fill 88 256 595 88 258 595 minecraft:cobbled_deepslate
setblock 48 257 558 minecraft:calcite
fill 48 257 559 48 260 559 minecraft:cobbled_deepslate
setblock 48 257 563 minecraft:calcite
fill 48 257 564 48 260 564 minecraft:cobbled_deepslate
setblock 48 257 568 minecraft:calcite
fill 48 257 569 48 258 569 minecraft:cobbled_deepslate
setblock 48 257 574 minecraft:cobbled_deepslate
setblock 48 257 578 minecraft:calcite
fill 48 257 579 48 257 582 minecraft:cobbled_deepslate
setblock 48 257 583 minecraft:calcite
fill 48 257 584 48 257 587 minecraft:cobbled_deepslate
setblock 48 257 588 minecraft:calcite
fill 48 257 589 48 260 589 minecraft:cobbled_deepslate
setblock 48 257 593 minecraft:calcite
fill 48 257 594 48 260 594 minecraft:cobbled_deepslate
setblock 48 257 598 minecraft:calcite
fill 49 257 558 49 260 558 minecraft:cobbled_deepslate
setblock 49 257 562 minecraft:calcite
fill 49 257 563 49 260 563 minecraft:cobbled_deepslate
setblock 49 257 582 minecraft:calcite
fill 49 257 583 49 259 583 minecraft:cobbled_deepslate
setblock 49 257 586 minecraft:cobbled_deepslate
setblock 49 257 587 minecraft:calcite
fill 49 257 588 49 260 588 minecraft:cobbled_deepslate
setblock 49 257 593 minecraft:cobbled_deepslate
setblock 49 257 597 minecraft:calcite
fill 49 257 598 52 257 598 minecraft:cobbled_deepslate
setblock 50 257 561 minecraft:calcite
fill 50 257 562 50 258 562 minecraft:cobbled_deepslate
fill 50 257 597 53 257 597 minecraft:cobbled_deepslate
setblock 51 257 560 minecraft:calcite
setblock 52 257 559 minecraft:calcite
setblock 53 257 558 minecraft:calcite
fill 53 257 559 54 257 559 minecraft:cobbled_deepslate
setblock 53 257 598 minecraft:calcite
fill 54 257 558 57 257 558 minecraft:cobbled_deepslate
fill 54 257 598 57 257 598 minecraft:cobbled_deepslate
setblock 58 257 558 minecraft:calcite
setblock 58 257 598 minecraft:calcite
fill 59 257 558 59 259 558 minecraft:cobbled_deepslate
fill 59 257 598 59 259 598 minecraft:cobbled_deepslate
setblock 62 257 558 minecraft:cobbled_deepslate
setblock 62 257 559 minecraft:calcite
setblock 63 257 558 minecraft:calcite
fill 63 257 559 63 259 559 minecraft:cobbled_deepslate
setblock 63 257 598 minecraft:calcite
fill 64 257 558 64 260 558 minecraft:cobbled_deepslate
setblock 64 257 597 minecraft:calcite
fill 64 257 598 64 260 598 minecraft:cobbled_deepslate
fill 65 257 597 65 258 597 minecraft:cobbled_deepslate
setblock 66 257 560 minecraft:calcite
setblock 67 257 559 minecraft:calcite
setblock 67 257 560 minecraft:cobbled_deepslate
setblock 68 257 558 minecraft:calcite
fill 68 257 559 68 258 559 minecraft:cobbled_deepslate
setblock 68 257 598 minecraft:calcite
fill 69 257 558 69 259 558 minecraft:cobbled_deepslate
fill 69 257 598 69 258 598 minecraft:cobbled_deepslate
setblock 73 257 558 minecraft:calcite
fill 74 257 558 77 257 558 minecraft:cobbled_deepslate
setblock 78 257 558 minecraft:calcite
fill 79 257 558 79 260 558 minecraft:cobbled_deepslate
setblock 81 257 560 minecraft:calcite
setblock 82 257 559 minecraft:calcite
fill 82 257 560 82 260 560 minecraft:cobbled_deepslate
setblock 83 257 558 minecraft:calcite
fill 83 257 559 83 260 559 minecraft:cobbled_deepslate
setblock 83 257 598 minecraft:calcite
fill 84 257 558 84 260 558 minecraft:cobbled_deepslate
fill 84 257 598 84 260 598 minecraft:cobbled_deepslate
setblock 85 257 560 minecraft:cobbled_deepslate
setblock 85 257 561 minecraft:calcite
fill 85 257 562 85 260 562 minecraft:cobbled_deepslate
setblock 85 257 597 minecraft:cobbled_deepslate
setblock 86 257 560 minecraft:calcite
fill 86 257 561 86 260 561 minecraft:cobbled_deepslate
setblock 86 257 565 minecraft:calcite
fill 86 257 566 86 260 566 minecraft:cobbled_deepslate
setblock 86 257 580 minecraft:calcite
fill 86 257 581 86 258 581 minecraft:cobbled_deepslate
setblock 87 257 559 minecraft:calcite
fill 87 257 560 87 260 560 minecraft:cobbled_deepslate
setblock 87 257 564 minecraft:calcite
fill 87 257 565 87 260 565 minecraft:cobbled_deepslate
setblock 87 257 569 minecraft:calcite
fill 87 257 570 87 259 570 minecraft:cobbled_deepslate
setblock 87 257 574 minecraft:calcite
setblock 87 257 575 minecraft:cobbled_deepslate
setblock 87 257 579 minecraft:calcite
fill 87 257 580 87 259 580 minecraft:cobbled_deepslate
setblock 87 257 584 minecraft:calcite
fill 87 257 585 87 260 585 minecraft:cobbled_deepslate
setblock 87 257 587 minecraft:cobbled_deepslate
setblock 88 257 558 minecraft:calcite
fill 88 257 559 88 260 559 minecraft:cobbled_deepslate
setblock 88 257 563 minecraft:calcite
fill 88 257 564 88 260 564 minecraft:cobbled_deepslate
setblock 88 257 568 minecraft:calcite
fill 88 257 569 88 260 569 minecraft:cobbled_deepslate
setblock 88 257 573 minecraft:calcite
fill 88 257 574 88 259 574 minecraft:cobbled_deepslate
setblock 88 257 578 minecraft:calcite
fill 88 257 579 88 260 579 minecraft:cobbled_deepslate
setblock 88 257 583 minecraft:calcite
fill 88 257 584 88 260 584 minecraft:cobbled_deepslate
setblock 88 257 588 minecraft:calcite
fill 88 257 589 88 260 589 minecraft:cobbled_deepslate
setblock 88 257 593 minecraft:calcite
fill 88 257 594 88 258 594 minecraft:cobbled_deepslate
setblock 88 257 598 minecraft:calcite
fill 48 258 558 48 261 558 minecraft:cobbled_deepslate
setblock 48 258 562 minecraft:calcite
fill 48 258 563 48 261 563 minecraft:cobbled_deepslate
setblock 48 258 567 minecraft:calcite
fill 48 258 568 48 260 568 minecraft:cobbled_deepslate
setblock 48 258 577 minecraft:calcite
fill 48 258 578 48 258 581 minecraft:cobbled_deepslate
setblock 48 258 582 minecraft:calcite
fill 48 258 583 48 258 586 minecraft:cobbled_deepslate
setblock 48 258 587 minecraft:calcite
fill 48 258 588 48 261 588 minecraft:cobbled_deepslate
setblock 48 258 592 minecraft:calcite
fill 48 258 593 48 261 593 minecraft:cobbled_deepslate
setblock 48 258 597 minecraft:calcite
fill 48 258 598 51 258 598 minecraft:cobbled_deepslate
setblock 49 258 561 minecraft:calcite
fill 49 258 562 49 261 562 minecraft:cobbled_deepslate
setblock 49 258 581 minecraft:calcite
fill 49 258 582 49 259 582 minecraft:cobbled_deepslate
setblock 49 258 586 minecraft:calcite
fill 49 258 587 49 261 587 minecraft:cobbled_deepslate
setblock 49 258 596 minecraft:calcite
fill 49 258 597 51 258 597 minecraft:cobbled_deepslate
setblock 50 258 560 minecraft:calcite
setblock 50 258 561 minecraft:cobbled_deepslate
setblock 51 258 559 minecraft:calcite
setblock 52 258 558 minecraft:calcite
setblock 52 258 559 minecraft:cobbled_deepslate
setblock 52 258 598 minecraft:calcite
fill 53 258 558 56 258 558 minecraft:cobbled_deepslate
fill 53 258 598 56 258 598 minecraft:cobbled_deepslate
setblock 57 258 558 minecraft:calcite
setblock 57 258 598 minecraft:calcite
setblock 58 258 558 minecraft:cobbled_deepslate
setblock 58 258 598 minecraft:cobbled_deepslate
setblock 61 258 558 minecraft:cobbled_deepslate
setblock 62 258 558 minecraft:calcite
setblock 62 258 559 minecraft:cobbled_deepslate
setblock 62 258 598 minecraft:calcite
fill 63 258 558 63 261 558 minecraft:cobbled_deepslate
setblock 63 258 597 minecraft:calcite
fill 63 258 598 63 261 598 minecraft:cobbled_deepslate
setblock 64 258 597 minecraft:cobbled_deepslate
setblock 66 258 559 minecraft:calcite
setblock 67 258 558 minecraft:calcite
fill 67 258 559 67 259 559 minecraft:cobbled_deepslate
setblock 67 258 598 minecraft:calcite
fill 68 258 558 68 260 558 minecraft:cobbled_deepslate
setblock 68 258 598 minecraft:cobbled_deepslate
setblock 72 258 558 minecraft:calcite
setblock 77 258 558 minecraft:calcite
fill 78 258 558 78 260 558 minecraft:cobbled_deepslate
setblock 81 258 559 minecraft:calcite
fill 81 258 560 81 261 560 minecraft:cobbled_deepslate
setblock 82 258 558 minecraft:calcite
fill 82 258 559 82 261 559 minecraft:cobbled_deepslate
setblock 82 258 598 minecraft:calcite
fill 83 258 558 83 261 558 minecraft:cobbled_deepslate
fill 83 258 598 83 260 598 minecraft:cobbled_deepslate
setblock 84 258 560 minecraft:cobbled_deepslate
setblock 84 258 561 minecraft:calcite
setblock 85 258 560 minecraft:calcite
fill 85 258 561 85 261 561 minecraft:cobbled_deepslate
setblock 85 258 565 minecraft:calcite
fill 85 258 589 85 266 589 minecraft:deepslate
setblock 86 258 559 minecraft:calcite
fill 86 258 560 86 261 560 minecraft:cobbled_deepslate
setblock 86 258 564 minecraft:calcite
fill 86 258 565 86 261 565 minecraft:cobbled_deepslate
setblock 87 258 558 minecraft:calcite
fill 87 258 559 87 261 559 minecraft:cobbled_deepslate
setblock 87 258 563 minecraft:calcite
fill 87 258 564 87 261 564 minecraft:cobbled_deepslate
setblock 87 258 568 minecraft:calcite
fill 87 258 569 87 261 569 minecraft:cobbled_deepslate
setblock 87 258 578 minecraft:calcite
fill 87 258 579 87 259 579 minecraft:cobbled_deepslate
setblock 87 258 583 minecraft:calcite
fill 87 258 584 87 260 584 minecraft:cobbled_deepslate
setblock 87 258 598 minecraft:calcite
fill 88 258 558 88 261 558 minecraft:cobbled_deepslate
setblock 88 258 562 minecraft:calcite
fill 88 258 563 88 261 563 minecraft:cobbled_deepslate
setblock 88 258 567 minecraft:calcite
fill 88 258 568 88 261 568 minecraft:cobbled_deepslate
setblock 88 258 572 minecraft:calcite
fill 88 258 573 88 259 573 minecraft:cobbled_deepslate
setblock 88 258 577 minecraft:calcite
fill 88 258 578 88 259 578 minecraft:cobbled_deepslate
setblock 88 258 582 minecraft:calcite
fill 88 258 583 88 261 583 minecraft:cobbled_deepslate
setblock 88 258 587 minecraft:calcite
fill 88 258 588 88 261 588 minecraft:cobbled_deepslate
setblock 88 258 597 minecraft:calcite
fill 88 258 598 88 261 598 minecraft:cobbled_deepslate
setblock 48 259 561 minecraft:calcite
fill 48 259 562 48 262 562 minecraft:cobbled_deepslate
setblock 48 259 566 minecraft:calcite
fill 48 259 567 48 262 567 minecraft:cobbled_deepslate
fill 48 259 578 48 259 580 minecraft:cobbled_deepslate
setblock 48 259 581 minecraft:calcite
fill 48 259 582 48 259 585 minecraft:cobbled_deepslate
setblock 48 259 586 minecraft:calcite
fill 48 259 587 48 262 587 minecraft:cobbled_deepslate
setblock 48 259 591 minecraft:calcite
fill 48 259 592 48 262 592 minecraft:cobbled_deepslate
setblock 48 259 596 minecraft:calcite
fill 48 259 597 49 259 598 minecraft:cobbled_deepslate
setblock 49 259 560 minecraft:calcite
fill 49 259 561 49 261 561 minecraft:cobbled_deepslate
setblock 49 259 565 minecraft:calcite
setblock 49 259 585 minecraft:calcite
fill 49 259 586 49 262 586 minecraft:cobbled_deepslate
setblock 50 259 559 minecraft:calcite
setblock 50 259 598 minecraft:cobbled_deepslate
setblock 51 259 558 minecraft:calcite
setblock 51 259 559 minecraft:cobbled_deepslate
setblock 51 259 598 minecraft:calcite
fill 52 259 558 53 259 558 minecraft:cobbled_deepslate
fill 52 259 598 53 259 598 minecraft:cobbled_deepslate
setblock 61 259 558 minecraft:calcite
setblock 61 259 598 minecraft:calcite
fill 62 259 558 62 261 558 minecraft:cobbled_deepslate
fill 62 259 598 62 261 598 minecraft:cobbled_deepslate
setblock 65 259 559 minecraft:calcite
setblock 66 259 558 minecraft:calcite
setblock 66 259 559 minecraft:cobbled_deepslate
setblock 66 259 598 minecraft:calcite
fill 67 259 558 67 260 558 minecraft:cobbled_deepslate
setblock 67 259 598 minecraft:cobbled_deepslate
setblock 80 259 559 minecraft:calcite
setblock 81 259 558 minecraft:calcite
fill 81 259 559 81 262 559 minecraft:cobbled_deepslate
fill 82 259 558 82 262 558 minecraft:cobbled_deepslate
setblock 83 259 560 minecraft:cobbled_deepslate
setblock 83 259 561 minecraft:calcite
setblock 84 259 560 minecraft:calcite
fill 84 259 561 84 261 561 minecraft:cobbled_deepslate
setblock 85 259 559 minecraft:calcite
fill 85 259 560 85 262 560 minecraft:cobbled_deepslate
setblock 85 259 564 minecraft:calcite
fill 85 259 565 85 262 565 minecraft:cobbled_deepslate
setblock 86 259 558 minecraft:calcite
fill 86 259 559 86 262 559 minecraft:cobbled_deepslate
setblock 86 259 563 minecraft:calcite
fill 86 259 564 86 262 564 minecraft:cobbled_deepslate
setblock 86 259 568 minecraft:calcite
setblock 86 259 598 minecraft:calcite
fill 87 259 558 87 262 558 minecraft:cobbled_deepslate
setblock 87 259 562 minecraft:calcite
fill 87 259 563 87 262 563 minecraft:cobbled_deepslate
setblock 87 259 567 minecraft:calcite
fill 87 259 568 87 262 568 minecraft:cobbled_deepslate
setblock 87 259 582 minecraft:calcite
fill 87 259 583 87 260 583 minecraft:cobbled_deepslate
fill 87 259 598 87 262 598 minecraft:cobbled_deepslate
setblock 88 259 561 minecraft:calcite
fill 88 259 562 88 262 562 minecraft:cobbled_deepslate
setblock 88 259 566 minecraft:calcite
fill 88 259 567 88 262 567 minecraft:cobbled_deepslate
setblock 88 259 571 minecraft:calcite
setblock 88 259 572 minecraft:cobbled_deepslate
setblock 88 259 576 minecraft:calcite
setblock 88 259 577 minecraft:cobbled_deepslate
setblock 88 259 581 minecraft:calcite
fill 88 259 582 88 261 582 minecraft:cobbled_deepslate
setblock 88 259 586 minecraft:calcite
fill 88 259 587 88 262 587 minecraft:cobbled_deepslate
setblock 88 259 596 minecraft:calcite
fill 88 259 597 88 260 597 minecraft:cobbled_deepslate
setblock 48 260 560 minecraft:calcite
fill 48 260 561 48 263 561 minecraft:cobbled_deepslate
setblock 48 260 565 minecraft:calcite
fill 48 260 566 48 263 566 minecraft:cobbled_deepslate
setblock 48 260 580 minecraft:calcite
fill 48 260 581 48 260 584 minecraft:cobbled_deepslate
setblock 48 260 585 minecraft:calcite
fill 48 260 586 48 263 586 minecraft:cobbled_deepslate
setblock 48 260 590 minecraft:calcite
fill 48 260 591 48 263 591 minecraft:cobbled_deepslate
setblock 48 260 595 minecraft:calcite
fill 48 260 596 48 261 598 minecraft:cobbled_deepslate
setblock 49 260 559 minecraft:calcite
setblock 49 260 560 minecraft:cobbled_deepslate
setblock 49 260 564 minecraft:calcite
setblock 49 260 584 minecraft:calcite
fill 49 260 585 49 261 585 minecraft:cobbled_deepslate
setblock 49 260 598 minecraft:cobbled_deepslate
setblock 50 260 558 minecraft:calcite
setblock 50 260 560 minecraft:light[level=14]
setblock 50 260 568 minecraft:light[level=14]
setblock 50 260 576 minecraft:light[level=14]
setblock 50 260 584 minecraft:light[level=14]
setblock 50 260 592 minecraft:light[level=14]
setblock 50 260 598 minecraft:calcite
setblock 51 260 558 minecraft:cobbled_deepslate
setblock 51 260 598 minecraft:cobbled_deepslate
fill 57 260 558 59 263 559 minecraft:light_blue_stained_glass
fill 58 260 560 58 262 560 minecraft:light_blue_stained_glass
setblock 58 260 568 minecraft:light[level=14]
setblock 58 260 576 minecraft:light[level=14]
setblock 58 260 584 minecraft:light[level=14]
setblock 58 260 592 minecraft:light[level=14]
setblock 61 260 558 minecraft:cobbled_deepslate
setblock 61 260 598 minecraft:cobbled_deepslate
setblock 65 260 558 minecraft:calcite
setblock 65 260 598 minecraft:calcite
fill 66 260 558 66 261 558 minecraft:cobbled_deepslate
setblock 66 260 560 minecraft:light[level=14]
setblock 66 260 568 minecraft:light[level=14]
setblock 66 260 576 minecraft:light[level=14]
setblock 66 260 584 minecraft:light[level=14]
setblock 66 260 592 minecraft:light[level=14]
setblock 74 260 560 minecraft:light[level=14]
setblock 74 260 568 minecraft:light[level=14]
setblock 74 260 576 minecraft:light[level=14]
setblock 74 260 584 minecraft:light[level=14]
setblock 74 260 592 minecraft:light[level=14]
setblock 80 260 558 minecraft:calcite
fill 80 260 559 80 263 559 minecraft:cobbled_deepslate
fill 81 260 558 81 263 558 minecraft:cobbled_deepslate
setblock 82 260 568 minecraft:light[level=14]
setblock 82 260 576 minecraft:light[level=14]
setblock 82 260 584 minecraft:light[level=14]
setblock 82 260 592 minecraft:light[level=14]
setblock 83 260 560 minecraft:calcite
fill 83 260 561 83 261 561 minecraft:cobbled_deepslate
setblock 84 260 559 minecraft:calcite
fill 84 260 560 84 263 560 minecraft:cobbled_deepslate
setblock 85 260 558 minecraft:calcite
fill 85 260 559 85 263 559 minecraft:cobbled_deepslate
setblock 85 260 563 minecraft:calcite
fill 85 260 564 85 263 564 minecraft:cobbled_deepslate
setblock 85 260 598 minecraft:calcite
fill 86 260 558 86 263 558 minecraft:cobbled_deepslate
setblock 86 260 562 minecraft:calcite
fill 86 260 563 86 263 563 minecraft:cobbled_deepslate
setblock 86 260 567 minecraft:calcite
fill 86 260 598 86 263 598 minecraft:cobbled_deepslate
setblock 87 260 561 minecraft:calcite
fill 87 260 562 87 263 562 minecraft:cobbled_deepslate
setblock 87 260 566 minecraft:calcite
fill 87 260 567 87 263 567 minecraft:cobbled_deepslate
setblock 87 260 582 minecraft:cobbled_deepslate
setblock 88 260 560 minecraft:calcite
fill 88 260 561 88 263 561 minecraft:cobbled_deepslate
setblock 88 260 565 minecraft:calcite
fill 88 260 566 88 263 566 minecraft:cobbled_deepslate
setblock 88 260 570 minecraft:calcite
setblock 88 260 571 minecraft:cobbled_deepslate
setblock 88 260 580 minecraft:calcite
fill 88 260 581 88 261 581 minecraft:cobbled_deepslate
setblock 88 260 585 minecraft:calcite
fill 88 260 586 88 263 586 minecraft:cobbled_deepslate
setblock 48 261 559 minecraft:calcite
fill 48 261 560 48 264 560 minecraft:cobbled_deepslate
setblock 48 261 564 minecraft:calcite
fill 48 261 565 48 264 565 minecraft:cobbled_deepslate
fill 48 261 581 48 261 583 minecraft:cobbled_deepslate
setblock 48 261 584 minecraft:calcite
fill 48 261 585 48 264 585 minecraft:cobbled_deepslate
setblock 48 261 589 minecraft:calcite
fill 48 261 590 48 264 590 minecraft:cobbled_deepslate
setblock 48 261 594 minecraft:calcite
fill 48 261 595 48 264 595 minecraft:cobbled_deepslate
setblock 49 261 558 minecraft:calcite
fill 49 261 584 49 267 584 minecraft:deepslate
setblock 49 261 588 minecraft:calcite
fill 49 261 596 51 266 597 minecraft:light_blue_stained_glass
setblock 49 261 598 minecraft:calcite
setblock 50 261 558 minecraft:cobbled_deepslate
fill 50 261 598 51 266 598 minecraft:light_blue_stained_glass
fill 56 261 558 56 262 558 minecraft:light_blue_stained_glass
fill 57 261 560 57 261 561 minecraft:light_blue_stained_glass
fill 58 261 561 58 261 562 minecraft:light_blue_stained_glass
fill 59 261 560 59 261 561 minecraft:light_blue_stained_glass
fill 60 261 558 60 262 558 minecraft:light_blue_stained_glass
setblock 64 261 558 minecraft:calcite
setblock 65 261 558 minecraft:cobbled_deepslate
setblock 79 261 558 minecraft:calcite
fill 80 261 558 80 264 558 minecraft:cobbled_deepslate
setblock 82 261 560 minecraft:calcite
setblock 83 261 559 minecraft:calcite
fill 83 261 560 83 264 560 minecraft:cobbled_deepslate
setblock 84 261 558 minecraft:calcite
fill 84 261 559 84 264 559 minecraft:cobbled_deepslate
setblock 84 261 598 minecraft:calcite
fill 85 261 558 85 264 558 minecraft:cobbled_deepslate
setblock 85 261 562 minecraft:calcite
fill 85 261 563 85 263 563 minecraft:cobbled_deepslate
fill 85 261 598 85 264 598 minecraft:cobbled_deepslate
setblock 86 261 561 minecraft:calcite
fill 86 261 562 86 264 562 minecraft:cobbled_deepslate
setblock 86 261 566 minecraft:calcite
fill 86 261 567 86 264 567 minecraft:cobbled_deepslate
setblock 87 261 560 minecraft:calcite
fill 87 261 561 87 264 561 minecraft:cobbled_deepslate
setblock 87 261 565 minecraft:calcite
fill 87 261 566 87 264 566 minecraft:cobbled_deepslate
setblock 88 261 559 minecraft:calcite
fill 88 261 560 88 264 560 minecraft:cobbled_deepslate
setblock 88 261 564 minecraft:calcite
fill 88 261 565 88 264 565 minecraft:cobbled_deepslate
setblock 88 261 569 minecraft:calcite
fill 88 261 570 88 264 570 minecraft:cobbled_deepslate
setblock 88 261 584 minecraft:calcite
fill 88 261 585 88 264 585 minecraft:cobbled_deepslate
setblock 88 261 589 minecraft:calcite
setblock 48 262 558 minecraft:calcite
fill 48 262 559 48 263 559 minecraft:cobbled_deepslate
setblock 48 262 563 minecraft:calcite
fill 48 262 564 48 265 564 minecraft:cobbled_deepslate
setblock 48 262 582 minecraft:cobbled_deepslate
setblock 48 262 583 minecraft:calcite
fill 48 262 584 48 265 584 minecraft:cobbled_deepslate
setblock 48 262 588 minecraft:calcite
fill 48 262 589 48 265 589 minecraft:cobbled_deepslate
setblock 48 262 593 minecraft:calcite
fill 48 262 594 48 265 594 minecraft:cobbled_deepslate
fill 48 262 596 48 262 597 minecraft:cobbled_deepslate
setblock 48 262 598 minecraft:calcite
setblock 49 262 558 minecraft:cobbled_deepslate
setblock 49 262 587 minecraft:calcite
fill 49 262 588 49 265 588 minecraft:cobbled_deepslate
fill 49 262 595 51 266 595 minecraft:light_blue_stained_glass
fill 49 262 598 49 266 598 minecraft:light_blue_stained_glass
fill 52 262 596 52 265 598 minecraft:light_blue_stained_glass
setblock 57 262 560 minecraft:light_blue_stained_glass
setblock 58 262 561 minecraft:light_blue_stained_glass
setblock 59 262 560 minecraft:light_blue_stained_glass
fill 79 262 558 79 265 558 minecraft:cobbled_deepslate
setblock 81 262 560 minecraft:calcite
setblock 82 262 559 minecraft:calcite
fill 82 262 560 82 265 560 minecraft:cobbled_deepslate
setblock 83 262 558 minecraft:calcite
fill 83 262 559 83 265 559 minecraft:cobbled_deepslate
fill 84 262 558 84 265 558 minecraft:cobbled_deepslate
fill 84 262 598 84 265 598 minecraft:cobbled_deepslate
setblock 85 262 562 minecraft:cobbled_deepslate
setblock 86 262 560 minecraft:calcite
fill 86 262 561 86 264 561 minecraft:cobbled_deepslate
setblock 86 262 565 minecraft:calcite
fill 86 262 566 86 265 566 minecraft:cobbled_deepslate
setblock 87 262 559 minecraft:calcite
fill 87 262 560 87 265 560 minecraft:cobbled_deepslate
setblock 87 262 564 minecraft:calcite
fill 87 262 565 87 265 565 minecraft:cobbled_deepslate
setblock 87 262 569 minecraft:calcite
setblock 88 262 558 minecraft:calcite
fill 88 262 559 88 265 559 minecraft:cobbled_deepslate
setblock 88 262 563 minecraft:calcite
fill 88 262 564 88 265 564 minecraft:cobbled_deepslate
setblock 88 262 568 minecraft:calcite
fill 88 262 569 88 265 569 minecraft:cobbled_deepslate
setblock 88 262 583 minecraft:calcite
fill 88 262 584 88 263 584 minecraft:cobbled_deepslate
setblock 88 262 588 minecraft:calcite
fill 88 262 589 88 264 590 minecraft:cobbled_deepslate
setblock 48 263 558 minecraft:cobbled_deepslate
setblock 48 263 562 minecraft:calcite
fill 48 263 563 48 266 563 minecraft:cobbled_deepslate
setblock 48 263 567 minecraft:calcite
fill 48 263 583 48 265 583 minecraft:cobbled_deepslate
setblock 48 263 587 minecraft:calcite
fill 48 263 588 48 266 588 minecraft:cobbled_deepslate
setblock 48 263 592 minecraft:calcite
fill 48 263 593 48 266 593 minecraft:cobbled_deepslate
setblock 48 263 596 minecraft:cobbled_deepslate
fill 48 263 597 48 264 597 minecraft:light_blue_stained_glass
setblock 48 263 598 minecraft:cobbled_deepslate
fill 49 263 587 49 266 587 minecraft:cobbled_deepslate
fill 49 263 589 49 264 589 minecraft:cobbled_deepslate
fill 50 263 594 50 267 594 minecraft:light_blue_stained_glass
fill 52 263 595 52 265 595 minecraft:light_blue_stained_glass
fill 78 263 558 78 266 558 minecraft:cobbled_deepslate
setblock 81 263 559 minecraft:calcite
fill 81 263 560 81 266 560 minecraft:cobbled_deepslate
setblock 82 263 558 minecraft:calcite
fill 82 263 559 82 266 559 minecraft:cobbled_deepslate
fill 83 263 558 83 266 558 minecraft:cobbled_deepslate
fill 83 263 598 83 266 598 minecraft:cobbled_deepslate
setblock 85 263 560 minecraft:calcite
setblock 85 263 565 minecraft:calcite
setblock 86 263 559 minecraft:calcite
setblock 86 263 560 minecraft:cobbled_deepslate
setblock 86 263 564 minecraft:calcite
fill 86 263 565 86 266 565 minecraft:cobbled_deepslate
fill 86 263 590 86 273 590 minecraft:deepslate
setblock 87 263 558 minecraft:calcite
fill 87 263 559 87 265 559 minecraft:cobbled_deepslate
setblock 87 263 563 minecraft:calcite
fill 87 263 564 87 266 564 minecraft:cobbled_deepslate
setblock 87 263 568 minecraft:calcite
fill 87 263 569 87 266 569 minecraft:cobbled_deepslate
fill 88 263 558 88 266 558 minecraft:cobbled_deepslate
setblock 88 263 562 minecraft:calcite
fill 88 263 563 88 266 563 minecraft:cobbled_deepslate
setblock 88 263 567 minecraft:calcite
fill 88 263 568 88 266 568 minecraft:cobbled_deepslate
setblock 88 263 587 minecraft:calcite
fill 88 263 588 88 266 588 minecraft:cobbled_deepslate
setblock 48 264 561 minecraft:calcite
fill 48 264 562 48 265 562 minecraft:cobbled_deepslate
setblock 48 264 566 minecraft:calcite
fill 48 264 567 48 267 567 minecraft:cobbled_deepslate
setblock 48 264 586 minecraft:calcite
fill 48 264 587 48 267 587 minecraft:cobbled_deepslate
setblock 48 264 591 minecraft:calcite
fill 48 264 592 48 267 592 minecraft:cobbled_deepslate
setblock 48 264 596 minecraft:calcite
fill 48 264 598 48 265 598 minecraft:light_blue_stained_glass
fill 49 264 583 49 267 583 minecraft:deepslate
fill 49 264 585 49 267 585 minecraft:deepslate
fill 49 264 586 49 267 586 minecraft:cobbled_deepslate
setblock 49 264 590 minecraft:calcite
fill 49 264 594 49 266 594 minecraft:light_blue_stained_glass
fill 50 264 584 50 267 584 minecraft:deepslate
fill 50 264 588 50 267 590 minecraft:light_blue_stained_glass
fill 51 264 594 51 266 594 minecraft:light_blue_stained_glass
setblock 79 264 559 minecraft:cobbled_deepslate
setblock 80 264 559 minecraft:calcite
setblock 81 264 558 minecraft:calcite
fill 81 264 559 81 267 559 minecraft:cobbled_deepslate
fill 82 264 558 82 267 558 minecraft:cobbled_deepslate
fill 82 264 598 82 267 598 minecraft:cobbled_deepslate
setblock 84 264 560 minecraft:calcite
fill 84 264 589 84 266 589 minecraft:deepslate
setblock 85 264 559 minecraft:calcite
fill 85 264 560 85 265 560 minecraft:cobbled_deepslate
setblock 85 264 564 minecraft:calcite
fill 85 264 588 85 266 588 minecraft:deepslate
fill 85 264 590 85 266 590 minecraft:deepslate
setblock 86 264 558 minecraft:calcite
fill 86 264 559 86 267 559 minecraft:cobbled_deepslate
setblock 86 264 563 minecraft:calcite
fill 86 264 564 86 267 564 minecraft:cobbled_deepslate
fill 86 264 589 86 266 589 minecraft:deepslate
setblock 86 264 598 minecraft:calcite
fill 87 264 558 87 267 558 minecraft:cobbled_deepslate
setblock 87 264 562 minecraft:calcite
fill 87 264 563 87 267 563 minecraft:cobbled_deepslate
setblock 87 264 567 minecraft:calcite
fill 87 264 568 87 267 568 minecraft:cobbled_deepslate
setblock 88 264 561 minecraft:calcite
fill 88 264 562 88 267 562 minecraft:cobbled_deepslate
setblock 88 264 566 minecraft:calcite
fill 88 264 567 88 267 567 minecraft:cobbled_deepslate
setblock 88 264 586 minecraft:calcite
fill 88 264 587 88 267 587 minecraft:cobbled_deepslate
setblock 88 264 591 minecraft:calcite
fill 88 264 592 88 267 592 minecraft:cobbled_deepslate
setblock 48 265 565 minecraft:calcite
fill 48 265 566 48 268 566 minecraft:cobbled_deepslate
setblock 48 265 585 minecraft:calcite
fill 48 265 586 48 268 586 minecraft:cobbled_deepslate
setblock 48 265 590 minecraft:calcite
fill 48 265 591 49 267 591 minecraft:cobbled_deepslate
setblock 48 265 595 minecraft:calcite
fill 48 265 596 48 267 597 minecraft:cobbled_deepslate
setblock 49 265 589 minecraft:calcite
fill 49 265 590 49 268 590 minecraft:cobbled_deepslate
fill 49 265 592 49 266 592 minecraft:cobbled_deepslate
fill 50 265 587 50 266 587 minecraft:light_blue_stained_glass
fill 50 265 591 50 266 591 minecraft:light_blue_stained_glass
fill 50 265 593 50 267 593 minecraft:light_blue_stained_glass
fill 51 265 588 52 267 590 minecraft:light_blue_stained_glass
setblock 60 265 598 minecraft:calcite
fill 61 265 598 61 268 598 minecraft:cobbled_deepslate
fill 77 265 558 77 267 558 minecraft:cobbled_deepslate
setblock 79 265 559 minecraft:calcite
setblock 80 265 558 minecraft:calcite
fill 80 265 559 80 267 560 minecraft:cobbled_deepslate
fill 81 265 558 81 268 558 minecraft:cobbled_deepslate
fill 81 265 598 81 268 598 minecraft:cobbled_deepslate
setblock 83 265 560 minecraft:calcite
setblock 84 265 559 minecraft:calcite
fill 84 265 560 84 267 560 minecraft:cobbled_deepslate
setblock 85 265 558 minecraft:calcite
fill 85 265 559 85 268 559 minecraft:cobbled_deepslate
setblock 85 265 598 minecraft:calcite
fill 86 265 558 86 268 558 minecraft:cobbled_deepslate
setblock 86 265 562 minecraft:calcite
fill 86 265 563 86 266 563 minecraft:cobbled_deepslate
setblock 86 265 567 minecraft:calcite
fill 86 265 568 86 268 568 minecraft:cobbled_deepslate
fill 86 265 598 87 267 598 minecraft:cobbled_deepslate
setblock 87 265 561 minecraft:calcite
fill 87 265 562 87 268 562 minecraft:cobbled_deepslate
setblock 87 265 566 minecraft:calcite
fill 87 265 567 87 268 567 minecraft:cobbled_deepslate
setblock 88 265 560 minecraft:calcite
fill 88 265 561 88 268 561 minecraft:cobbled_deepslate
setblock 88 265 565 minecraft:calcite
fill 88 265 566 88 268 566 minecraft:cobbled_deepslate
setblock 88 265 570 minecraft:calcite
setblock 88 265 585 minecraft:calcite
fill 88 265 586 88 268 586 minecraft:cobbled_deepslate
setblock 88 265 589 minecraft:cobbled_deepslate
setblock 88 265 590 minecraft:calcite
fill 88 265 591 88 268 591 minecraft:cobbled_deepslate
fill 88 265 593 88 265 594 minecraft:cobbled_deepslate
setblock 48 266 564 minecraft:calcite
fill 48 266 565 48 267 565 minecraft:cobbled_deepslate
setblock 48 266 568 minecraft:cobbled_deepslate
setblock 48 266 584 minecraft:calcite
fill 48 266 585 48 269 585 minecraft:cobbled_deepslate
setblock 48 266 589 minecraft:calcite
fill 48 266 590 48 269 590 minecraft:cobbled_deepslate
setblock 48 266 594 minecraft:calcite
fill 48 266 595 48 269 595 minecraft:cobbled_deepslate
setblock 48 266 598 minecraft:cobbled_deepslate
setblock 49 266 588 minecraft:calcite
fill 49 266 589 49 269 589 minecraft:cobbled_deepslate
setblock 49 266 593 minecraft:calcite
fill 53 266 588 53 266 590 minecraft:light_blue_stained_glass
fill 54 266 589 55 266 589 minecraft:light_blue_stained_glass
setblock 58 266 598 minecraft:cobbled_deepslate
setblock 59 266 598 minecraft:calcite
fill 60 266 598 60 269 598 minecraft:cobbled_deepslate
fill 62 266 598 62 267 598 minecraft:cobbled_deepslate
setblock 78 266 559 minecraft:calcite
setblock 79 266 558 minecraft:calcite
fill 79 266 559 79 269 559 minecraft:cobbled_deepslate
setblock 79 266 598 minecraft:calcite
fill 80 266 558 80 269 558 minecraft:cobbled_deepslate
fill 80 266 598 80 269 598 minecraft:cobbled_deepslate
setblock 82 266 560 minecraft:calcite
setblock 83 266 559 minecraft:calcite
fill 83 266 560 83 268 560 minecraft:cobbled_deepslate
setblock 84 266 558 minecraft:calcite
fill 84 266 559 84 269 559 minecraft:cobbled_deepslate
setblock 84 266 598 minecraft:calcite
fill 85 266 558 85 269 558 minecraft:cobbled_deepslate
fill 85 266 598 85 269 598 minecraft:cobbled_deepslate
setblock 86 266 566 minecraft:calcite
fill 86 266 567 86 268 567 minecraft:cobbled_deepslate
setblock 87 266 560 minecraft:calcite
fill 87 266 561 87 267 561 minecraft:cobbled_deepslate
setblock 87 266 565 minecraft:calcite
fill 87 266 566 87 269 566 minecraft:cobbled_deepslate
setblock 87 266 589 minecraft:cobbled_deepslate
setblock 87 266 590 minecraft:calcite
fill 87 266 591 87 269 591 minecraft:cobbled_deepslate
setblock 88 266 559 minecraft:calcite
fill 88 266 560 88 269 560 minecraft:cobbled_deepslate
setblock 88 266 564 minecraft:calcite
fill 88 266 565 88 269 565 minecraft:cobbled_deepslate
setblock 88 266 569 minecraft:calcite
fill 88 266 570 88 268 571 minecraft:cobbled_deepslate
setblock 88 266 589 minecraft:calcite
fill 88 266 590 88 269 590 minecraft:cobbled_deepslate
setblock 88 266 593 minecraft:cobbled_deepslate
setblock 88 266 594 minecraft:calcite
fill 88 266 595 88 267 597 minecraft:cobbled_deepslate
setblock 48 267 568 minecraft:calcite
fill 48 267 569 48 270 569 minecraft:cobbled_deepslate
setblock 48 267 583 minecraft:deepslate
fill 48 267 584 48 269 584 minecraft:cobbled_deepslate
setblock 48 267 588 minecraft:calcite
fill 48 267 589 48 270 589 minecraft:cobbled_deepslate
setblock 48 267 593 minecraft:calcite
fill 48 267 594 49 269 594 minecraft:cobbled_deepslate
setblock 48 267 598 minecraft:calcite
setblock 49 267 587 minecraft:calcite
fill 49 267 588 49 270 588 minecraft:cobbled_deepslate
setblock 49 267 592 minecraft:calcite
fill 49 267 593 49 270 593 minecraft:cobbled_deepslate
setblock 50 267 583 minecraft:deepslate
setblock 50 267 585 minecraft:deepslate
setblock 50 267 595 minecraft:light_blue_stained_glass
setblock 53 267 589 minecraft:light_blue_stained_glass
fill 56 267 598 57 267 598 minecraft:cobbled_deepslate
setblock 58 267 598 minecraft:calcite
fill 59 267 598 59 270 598 minecraft:cobbled_deepslate
fill 76 267 558 76 268 558 minecraft:cobbled_deepslate
setblock 77 267 559 minecraft:calcite
setblock 78 267 558 minecraft:calcite
fill 78 267 559 78 270 559 minecraft:cobbled_deepslate
setblock 78 267 598 minecraft:calcite
fill 79 267 558 79 270 558 minecraft:cobbled_deepslate
fill 79 267 560 79 268 560 minecraft:cobbled_deepslate
fill 79 267 598 79 270 598 minecraft:cobbled_deepslate
setblock 81 267 560 minecraft:calcite
fill 81 267 597 83 267 597 minecraft:cobbled_deepslate
setblock 82 267 559 minecraft:calcite
fill 82 267 560 82 269 560 minecraft:cobbled_deepslate
setblock 83 267 558 minecraft:calcite
fill 83 267 559 83 270 559 minecraft:cobbled_deepslate
setblock 83 267 598 minecraft:calcite
fill 84 267 558 84 270 558 minecraft:cobbled_deepslate
setblock 84 267 597 minecraft:calcite
fill 84 267 598 84 270 598 minecraft:cobbled_deepslate
setblock 86 267 565 minecraft:calcite
fill 86 267 566 86 268 566 minecraft:cobbled_deepslate
setblock 87 267 564 minecraft:calcite
fill 87 267 565 87 269 565 minecraft:cobbled_deepslate
setblock 87 267 569 minecraft:calcite
fill 87 267 570 87 269 570 minecraft:cobbled_deepslate
setblock 87 267 588 minecraft:cobbled_deepslate
setblock 87 267 589 minecraft:calcite
fill 87 267 590 87 270 590 minecraft:cobbled_deepslate
fill 87 267 592 87 267 593 minecraft:cobbled_deepslate
setblock 87 267 594 minecraft:calcite
setblock 88 267 558 minecraft:calcite
fill 88 267 559 88 269 559 minecraft:cobbled_deepslate
setblock 88 267 563 minecraft:calcite
fill 88 267 564 88 270 564 minecraft:cobbled_deepslate
setblock 88 267 568 minecraft:calcite
fill 88 267 569 88 270 569 minecraft:cobbled_deepslate
setblock 88 267 588 minecraft:calcite
fill 88 267 589 88 270 589 minecraft:cobbled_deepslate
setblock 88 267 593 minecraft:calcite
fill 88 267 594 88 270 594 minecraft:cobbled_deepslate
setblock 88 267 598 minecraft:calcite
setblock 48 268 567 minecraft:calcite
fill 48 268 568 48 269 568 minecraft:cobbled_deepslate
fill 48 268 570 48 269 570 minecraft:cobbled_deepslate
setblock 48 268 587 minecraft:calcite
fill 48 268 588 48 271 588 minecraft:cobbled_deepslate
setblock 48 268 591 minecraft:cobbled_deepslate
setblock 48 268 592 minecraft:calcite
fill 48 268 593 48 271 593 minecraft:cobbled_deepslate
setblock 48 268 596 minecraft:cobbled_deepslate
setblock 48 268 597 minecraft:calcite
fill 48 268 598 49 270 598 minecraft:cobbled_deepslate
setblock 49 268 586 minecraft:calcite
schedule function dropper:buildpart/133_9 1t
