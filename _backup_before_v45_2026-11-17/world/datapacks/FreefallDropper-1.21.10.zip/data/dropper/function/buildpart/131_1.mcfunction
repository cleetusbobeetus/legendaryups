fill 533 74 510 533 90 510 minecraft:black_concrete
fill 559 74 532 559 106 532 minecraft:black_concrete
fill 517 75 518 517 81 518 minecraft:black_concrete
fill 517 75 534 517 81 534 minecraft:black_concrete
fill 517 75 550 517 81 550 minecraft:black_concrete
setblock 517 75 551 minecraft:magma_block
fill 517 75 552 517 132 552 minecraft:black_concrete
fill 521 75 510 521 81 510 minecraft:black_concrete
fill 525 75 522 525 78 524 minecraft:orange_concrete
fill 526 75 521 528 78 521 minecraft:orange_concrete
fill 526 75 525 528 78 525 minecraft:orange_concrete
fill 529 75 522 529 78 524 minecraft:orange_concrete
fill 531 75 552 531 81 552 minecraft:black_concrete
setblock 532 75 510 minecraft:magma_block
fill 537 75 510 537 81 510 minecraft:black_concrete
fill 547 75 552 547 81 552 minecraft:black_concrete
fill 553 75 510 553 81 510 minecraft:black_concrete
fill 559 75 520 559 81 520 minecraft:black_concrete
fill 559 75 536 559 77 536 minecraft:black_concrete
fill 559 75 548 559 78 549 minecraft:black_concrete
setblock 559 75 550 minecraft:white_concrete
fill 517 76 551 517 114 551 minecraft:black_concrete
fill 524 76 523 524 77 523 minecraft:orange_concrete
fill 525 76 521 525 77 521 minecraft:orange_concrete
fill 525 76 525 525 77 525 minecraft:orange_concrete
fill 527 76 520 527 77 520 minecraft:orange_concrete
fill 529 76 521 529 77 521 minecraft:orange_concrete
fill 529 76 525 529 77 525 minecraft:orange_concrete
fill 532 76 510 532 132 510 minecraft:black_concrete
setblock 559 76 515 minecraft:magma_block
fill 559 76 550 559 100 550 minecraft:black_concrete
fill 517 77 510 519 135 510 minecraft:black_concrete
fill 517 77 519 517 135 519 minecraft:black_concrete
setblock 517 77 520 minecraft:magma_block
setblock 517 77 547 minecraft:magma_block
fill 517 77 548 517 94 548 minecraft:black_concrete
setblock 520 77 510 minecraft:magma_block
setblock 520 77 513 minecraft:light[level=14]
setblock 520 77 521 minecraft:light[level=14]
setblock 520 77 529 minecraft:light[level=14]
setblock 520 77 537 minecraft:light[level=14]
setblock 520 77 545 minecraft:light[level=14]
setblock 528 77 513 minecraft:light[level=14]
setblock 528 77 529 minecraft:light[level=14]
setblock 528 77 537 minecraft:light[level=14]
setblock 528 77 545 minecraft:light[level=14]
setblock 531 77 510 minecraft:shroomlight
setblock 536 77 513 minecraft:light[level=14]
setblock 536 77 521 minecraft:light[level=14]
setblock 536 77 529 minecraft:light[level=14]
setblock 536 77 537 minecraft:light[level=14]
setblock 536 77 545 minecraft:light[level=14]
fill 538 77 510 542 82 510 minecraft:black_concrete
setblock 543 77 510 minecraft:magma_block
fill 544 77 510 546 116 510 minecraft:black_concrete
setblock 544 77 513 minecraft:light[level=14]
setblock 544 77 521 minecraft:light[level=14]
setblock 544 77 529 minecraft:light[level=14]
setblock 544 77 537 minecraft:light[level=14]
setblock 544 77 545 minecraft:light[level=14]
setblock 544 77 552 minecraft:shroomlight
setblock 552 77 513 minecraft:light[level=14]
setblock 552 77 521 minecraft:light[level=14]
setblock 552 77 529 minecraft:light[level=14]
setblock 552 77 537 minecraft:light[level=14]
setblock 552 77 545 minecraft:light[level=14]
fill 559 77 515 559 119 515 minecraft:black_concrete
fill 517 78 520 517 133 520 minecraft:black_concrete
fill 517 78 547 517 135 547 minecraft:black_concrete
fill 520 78 510 520 98 510 minecraft:black_concrete
fill 531 78 510 531 122 510 minecraft:black_concrete
fill 543 78 510 543 117 510 minecraft:black_concrete
fill 544 78 552 544 137 552 minecraft:black_concrete
setblock 554 78 552 minecraft:white_concrete
fill 559 78 533 559 135 533 minecraft:black_concrete
setblock 559 78 534 minecraft:shroomlight
fill 559 78 535 559 94 535 minecraft:black_concrete
setblock 559 78 536 minecraft:magma_block
fill 517 79 514 517 83 514 minecraft:black_concrete
setblock 517 79 515 minecraft:magma_block
fill 517 79 516 517 135 517 minecraft:black_concrete
fill 554 79 552 554 131 552 minecraft:black_concrete
fill 559 79 525 559 136 525 minecraft:black_concrete
setblock 559 79 526 minecraft:shroomlight
fill 559 79 527 559 136 527 minecraft:black_concrete
fill 559 79 534 559 100 534 minecraft:black_concrete
fill 559 79 536 559 81 536 minecraft:black_concrete
setblock 559 79 545 minecraft:magma_block
setblock 559 79 548 minecraft:white_concrete
fill 559 79 549 559 110 549 minecraft:black_concrete
fill 517 80 515 517 135 515 minecraft:black_concrete
fill 517 80 535 517 135 535 minecraft:black_concrete
setblock 517 80 536 minecraft:white_concrete
fill 517 80 537 517 92 537 minecraft:black_concrete
setblock 542 80 552 minecraft:white_concrete
fill 543 80 552 543 95 552 minecraft:black_concrete
setblock 549 80 552 minecraft:white_concrete
fill 550 80 552 550 123 552 minecraft:black_concrete
fill 559 80 526 559 89 526 minecraft:black_concrete
fill 559 80 545 559 131 545 minecraft:black_concrete
fill 559 80 548 559 131 548 minecraft:black_concrete
fill 517 81 536 517 82 536 minecraft:black_concrete
fill 532 81 540 532 82 540 minecraft:magma_block
fill 542 81 552 542 135 552 minecraft:black_concrete
setblock 548 81 552 minecraft:shroomlight
fill 549 81 552 549 135 552 minecraft:black_concrete
fill 517 82 518 517 83 518 minecraft:orange_concrete
fill 517 82 534 517 83 534 minecraft:orange_concrete
fill 517 82 550 517 83 550 minecraft:orange_concrete
fill 521 82 510 521 83 510 minecraft:orange_concrete
fill 531 82 552 531 83 552 minecraft:orange_concrete
fill 537 82 510 537 83 510 minecraft:orange_concrete
fill 547 82 552 547 83 552 minecraft:orange_concrete
setblock 548 82 552 minecraft:black_concrete
fill 553 82 510 553 83 510 minecraft:orange_concrete
fill 559 82 520 559 83 520 minecraft:orange_concrete
fill 559 82 536 559 83 536 minecraft:orange_concrete
setblock 517 83 536 minecraft:magma_block
fill 521 83 522 522 84 523 minecraft:blackstone
fill 532 83 540 532 91 540 minecraft:blackstone
fill 538 83 510 540 83 510 minecraft:black_concrete
setblock 541 83 510 minecraft:magma_block
fill 542 83 510 542 124 510 minecraft:black_concrete
setblock 548 83 552 minecraft:white_concrete
setblock 559 83 519 minecraft:shroomlight
setblock 517 84 514 minecraft:white_concrete
fill 517 84 518 517 90 518 minecraft:black_concrete
fill 517 84 534 517 90 534 minecraft:black_concrete
fill 517 84 536 517 135 536 minecraft:black_concrete
fill 517 84 550 517 90 550 minecraft:black_concrete
setblock 520 84 552 minecraft:magma_block
fill 521 84 510 521 90 510 minecraft:black_concrete
fill 531 84 552 531 90 552 minecraft:black_concrete
fill 537 84 510 538 90 510 minecraft:black_concrete
setblock 539 84 510 minecraft:magma_block
fill 540 84 510 541 88 510 minecraft:black_concrete
fill 547 84 552 548 90 552 minecraft:black_concrete
fill 553 84 510 553 90 510 minecraft:black_concrete
setblock 558 84 552 minecraft:white_concrete
fill 559 84 519 559 90 520 minecraft:black_concrete
setblock 559 84 531 minecraft:white_concrete
fill 559 84 536 559 90 536 minecraft:black_concrete
setblock 559 84 546 minecraft:shroomlight
fill 559 84 552 559 133 552 minecraft:black_concrete
fill 517 85 514 517 135 514 minecraft:black_concrete
setblock 517 85 533 minecraft:shroomlight
setblock 520 85 513 minecraft:light[level=14]
setblock 520 85 521 minecraft:light[level=14]
setblock 520 85 529 minecraft:light[level=14]
setblock 520 85 537 minecraft:light[level=14]
setblock 520 85 545 minecraft:light[level=14]
fill 520 85 552 520 135 552 minecraft:black_concrete
setblock 521 85 552 minecraft:white_concrete
fill 522 85 552 522 94 552 minecraft:black_concrete
setblock 528 85 513 minecraft:light[level=14]
setblock 528 85 521 minecraft:light[level=14]
setblock 528 85 529 minecraft:light[level=14]
setblock 528 85 537 minecraft:light[level=14]
setblock 528 85 545 minecraft:light[level=14]
fill 532 85 541 533 91 541 minecraft:blackstone
fill 533 85 540 533 91 540 minecraft:blackstone
setblock 536 85 513 minecraft:light[level=14]
setblock 536 85 521 minecraft:light[level=14]
setblock 536 85 529 minecraft:light[level=14]
setblock 536 85 537 minecraft:light[level=14]
setblock 536 85 545 minecraft:light[level=14]
fill 539 85 510 539 135 510 minecraft:black_concrete
setblock 544 85 513 minecraft:light[level=14]
setblock 544 85 521 minecraft:light[level=14]
setblock 544 85 529 minecraft:light[level=14]
setblock 544 85 537 minecraft:light[level=14]
setblock 544 85 545 minecraft:light[level=14]
setblock 552 85 513 minecraft:light[level=14]
setblock 552 85 521 minecraft:light[level=14]
setblock 552 85 529 minecraft:light[level=14]
setblock 552 85 537 minecraft:light[level=14]
setblock 552 85 545 minecraft:light[level=14]
fill 558 85 552 558 100 552 minecraft:black_concrete
fill 559 85 531 559 135 531 minecraft:black_concrete
setblock 559 85 542 minecraft:shroomlight
fill 559 85 546 559 136 546 minecraft:black_concrete
fill 517 86 533 517 111 533 minecraft:black_concrete
fill 521 86 552 521 132 552 minecraft:black_concrete
setblock 523 86 510 minecraft:magma_block
setblock 523 86 552 minecraft:white_concrete
fill 524 86 510 524 136 510 minecraft:black_concrete
fill 531 86 540 531 91 541 minecraft:blackstone
fill 532 86 539 533 91 539 minecraft:blackstone
setblock 536 86 552 minecraft:white_concrete
fill 559 86 542 559 95 542 minecraft:black_concrete
fill 517 87 540 517 98 542 minecraft:black_concrete
setblock 517 87 543 minecraft:shroomlight
fill 517 87 544 517 117 544 minecraft:black_concrete
fill 523 87 510 523 135 510 minecraft:black_concrete
fill 523 87 552 523 91 552 minecraft:black_concrete
fill 531 87 539 531 91 539 minecraft:blackstone
fill 532 87 542 533 91 542 minecraft:blackstone
fill 534 87 540 534 91 541 minecraft:blackstone
fill 536 87 552 536 102 552 minecraft:black_concrete
setblock 559 87 518 minecraft:shroomlight
fill 517 88 543 517 126 543 minecraft:black_concrete
fill 530 88 540 530 91 541 minecraft:blackstone
fill 531 88 542 531 91 542 minecraft:blackstone
fill 532 88 538 533 91 538 minecraft:blackstone
fill 534 88 539 534 91 539 minecraft:blackstone
fill 534 88 542 534 91 542 minecraft:blackstone
fill 559 88 518 559 115 518 minecraft:black_concrete
setblock 517 89 512 minecraft:magma_block
setblock 524 89 552 minecraft:magma_block
fill 530 89 539 530 91 539 minecraft:blackstone
fill 530 89 542 530 91 542 minecraft:blackstone
fill 531 89 538 531 91 538 minecraft:blackstone
fill 532 89 543 533 91 543 minecraft:blackstone
fill 534 89 538 534 91 538 minecraft:blackstone
fill 535 89 539 535 91 541 minecraft:blackstone
setblock 540 89 510 minecraft:white_concrete
fill 541 89 510 541 122 510 minecraft:black_concrete
fill 517 90 512 517 109 512 minecraft:black_concrete
fill 524 90 552 524 101 552 minecraft:black_concrete
fill 529 90 540 529 91 541 minecraft:blackstone
fill 530 90 538 530 91 538 minecraft:blackstone
fill 531 90 543 531 91 543 minecraft:blackstone
fill 532 90 537 533 91 537 minecraft:blackstone
fill 534 90 543 534 91 543 minecraft:blackstone
fill 535 90 542 535 91 542 minecraft:blackstone
fill 539 90 520 539 91 522 minecraft:blackstone
fill 540 90 510 540 135 510 minecraft:black_concrete
fill 540 90 521 540 91 522 minecraft:blackstone
setblock 559 90 526 minecraft:white_concrete
fill 517 91 518 517 92 518 minecraft:orange_concrete
fill 517 91 534 517 92 534 minecraft:orange_concrete
fill 517 91 550 517 92 550 minecraft:orange_concrete
fill 521 91 510 521 92 510 minecraft:orange_concrete
fill 525 91 552 529 132 552 minecraft:black_concrete
fill 526 91 510 529 94 510 minecraft:black_concrete
setblock 529 91 539 minecraft:blackstone
setblock 529 91 542 minecraft:blackstone
setblock 530 91 510 minecraft:white_concrete
setblock 530 91 543 minecraft:blackstone
setblock 530 91 552 minecraft:shroomlight
setblock 531 91 537 minecraft:blackstone
fill 531 91 552 531 92 552 minecraft:orange_concrete
fill 532 91 544 533 91 544 minecraft:blackstone
setblock 533 91 510 minecraft:white_concrete
setblock 534 91 537 minecraft:blackstone
setblock 535 91 538 minecraft:blackstone
setblock 535 91 543 minecraft:blackstone
fill 536 91 539 536 91 541 minecraft:blackstone
fill 537 91 510 537 92 510 minecraft:orange_concrete
fill 538 91 510 538 135 510 minecraft:black_concrete
fill 547 91 552 547 92 552 minecraft:orange_concrete
fill 548 91 552 548 133 552 minecraft:black_concrete
fill 553 91 510 553 92 510 minecraft:orange_concrete
fill 559 91 519 559 114 519 minecraft:black_concrete
fill 559 91 520 559 92 520 minecraft:orange_concrete
fill 559 91 526 559 102 526 minecraft:black_concrete
fill 559 91 536 559 92 536 minecraft:orange_concrete
setblock 523 92 552 minecraft:shroomlight
fill 530 92 510 530 131 510 minecraft:black_concrete
fill 530 92 552 530 135 552 minecraft:black_concrete
fill 532 92 539 532 92 541 minecraft:magma_block
fill 533 92 510 533 135 510 minecraft:black_concrete
fill 533 92 540 533 93 541 minecraft:magma_block
fill 559 92 513 559 135 513 minecraft:black_concrete
setblock 559 92 514 minecraft:magma_block
fill 517 93 518 517 97 518 minecraft:black_concrete
fill 517 93 534 517 99 534 minecraft:black_concrete
setblock 517 93 537 minecraft:magma_block
fill 517 93 550 517 99 550 minecraft:black_concrete
setblock 520 93 513 minecraft:light[level=14]
setblock 520 93 521 minecraft:light[level=14]
setblock 520 93 529 minecraft:light[level=14]
setblock 520 93 537 minecraft:light[level=14]
setblock 520 93 545 minecraft:light[level=14]
setblock 521 93 510 minecraft:black_concrete
fill 523 93 552 523 119 552 minecraft:black_concrete
setblock 528 93 513 minecraft:light[level=14]
setblock 528 93 521 minecraft:light[level=14]
setblock 528 93 529 minecraft:light[level=14]
setblock 528 93 537 minecraft:light[level=14]
setblock 528 93 545 minecraft:light[level=14]
fill 531 93 552 531 99 552 minecraft:black_concrete
fill 532 93 540 532 93 541 minecraft:magma_block
setblock 536 93 513 minecraft:light[level=14]
setblock 536 93 521 minecraft:light[level=14]
setblock 536 93 529 minecraft:light[level=14]
setblock 536 93 537 minecraft:light[level=14]
setblock 536 93 545 minecraft:light[level=14]
fill 537 93 510 537 99 510 minecraft:black_concrete
setblock 544 93 513 minecraft:light[level=14]
setblock 544 93 521 minecraft:light[level=14]
setblock 544 93 529 minecraft:light[level=14]
setblock 544 93 537 minecraft:light[level=14]
setblock 544 93 545 minecraft:light[level=14]
fill 547 93 552 547 99 552 minecraft:black_concrete
setblock 552 93 513 minecraft:light[level=14]
setblock 552 93 521 minecraft:light[level=14]
setblock 552 93 529 minecraft:light[level=14]
setblock 552 93 537 minecraft:light[level=14]
setblock 552 93 545 minecraft:light[level=14]
fill 553 93 510 553 99 510 minecraft:black_concrete
fill 559 93 514 559 99 514 minecraft:black_concrete
fill 559 93 520 559 99 520 minecraft:black_concrete
fill 559 93 536 559 99 536 minecraft:black_concrete
fill 517 94 537 517 111 537 minecraft:black_concrete
setblock 521 94 510 minecraft:shroomlight
fill 532 94 540 533 94 540 minecraft:magma_block
setblock 556 94 510 minecraft:magma_block
setblock 517 95 548 minecraft:white_concrete
fill 521 95 510 521 99 510 minecraft:black_concrete
setblock 522 95 552 minecraft:magma_block
fill 526 95 510 526 111 510 minecraft:black_concrete
setblock 527 95 510 minecraft:white_concrete
fill 528 95 510 529 131 510 minecraft:black_concrete
setblock 532 95 540 minecraft:magma_block
fill 551 95 532 551 96 533 minecraft:blackstone
fill 556 95 510 556 135 510 minecraft:black_concrete
setblock 559 95 535 minecraft:white_concrete
setblock 517 96 525 minecraft:magma_block
fill 517 96 526 517 121 526 minecraft:black_concrete
fill 517 96 548 517 111 548 minecraft:black_concrete
setblock 522 96 552 minecraft:white_concrete
fill 527 96 510 527 131 510 minecraft:black_concrete
setblock 543 96 552 minecraft:white_concrete
fill 559 96 535 559 105 535 minecraft:black_concrete
setblock 559 96 542 minecraft:white_concrete
fill 517 97 525 517 124 525 minecraft:black_concrete
setblock 517 97 539 minecraft:white_concrete
fill 522 97 552 522 120 552 minecraft:black_concrete
fill 543 97 552 543 122 552 minecraft:black_concrete
setblock 559 97 538 minecraft:white_concrete
fill 559 97 542 559 135 542 minecraft:black_concrete
setblock 517 98 518 minecraft:white_concrete
fill 517 98 539 517 108 539 minecraft:black_concrete
fill 559 98 538 559 123 538 minecraft:black_concrete
setblock 517 99 518 minecraft:black_concrete
setblock 517 99 530 minecraft:white_concrete
fill 517 99 531 517 99 532 minecraft:black_concrete
setblock 517 99 540 minecraft:white_concrete
fill 517 99 541 517 103 542 minecraft:black_concrete
setblock 520 99 510 minecraft:white_concrete
fill 517 100 518 517 101 518 minecraft:orange_concrete
fill 517 100 530 517 135 530 minecraft:black_concrete
setblock 517 100 531 minecraft:shroomlight
fill 517 100 532 517 132 532 minecraft:black_concrete
fill 517 100 534 517 101 534 minecraft:orange_concrete
fill 517 100 540 517 135 540 minecraft:black_concrete
fill 517 100 550 517 101 550 minecraft:orange_concrete
fill 520 100 510 520 131 510 minecraft:black_concrete
fill 521 100 510 521 101 510 minecraft:orange_concrete
fill 531 100 552 531 101 552 minecraft:orange_concrete
fill 537 100 510 537 101 510 minecraft:orange_concrete
fill 547 100 552 547 101 552 minecraft:orange_concrete
fill 553 100 510 553 101 510 minecraft:orange_concrete
setblock 559 100 514 minecraft:shroomlight
fill 559 100 520 559 101 520 minecraft:orange_concrete
fill 559 100 536 559 101 536 minecraft:orange_concrete
fill 517 101 531 517 129 531 minecraft:black_concrete
setblock 520 101 513 minecraft:light[level=14]
setblock 520 101 521 minecraft:light[level=14]
setblock 520 101 529 minecraft:light[level=14]
setblock 520 101 537 minecraft:light[level=14]
setblock 520 101 545 minecraft:light[level=14]
setblock 528 101 513 minecraft:light[level=14]
setblock 528 101 521 minecraft:light[level=14]
setblock 528 101 529 minecraft:light[level=14]
setblock 528 101 537 minecraft:light[level=14]
setblock 528 101 545 minecraft:light[level=14]
fill 535 101 552 535 102 552 minecraft:white_concrete
setblock 536 101 513 minecraft:light[level=14]
setblock 536 101 521 minecraft:light[level=14]
setblock 536 101 529 minecraft:light[level=14]
setblock 536 101 537 minecraft:light[level=14]
setblock 536 101 545 minecraft:light[level=14]
setblock 544 101 513 minecraft:light[level=14]
setblock 544 101 521 minecraft:light[level=14]
setblock 544 101 529 minecraft:light[level=14]
setblock 544 101 537 minecraft:light[level=14]
setblock 544 101 545 minecraft:light[level=14]
fill 549 101 539 549 102 540 minecraft:blackstone
setblock 552 101 513 minecraft:light[level=14]
setblock 552 101 521 minecraft:light[level=14]
setblock 552 101 529 minecraft:light[level=14]
setblock 552 101 537 minecraft:light[level=14]
setblock 552 101 545 minecraft:light[level=14]
setblock 558 101 552 minecraft:shroomlight
fill 559 101 514 559 125 514 minecraft:black_concrete
setblock 559 101 521 minecraft:white_concrete
setblock 559 101 534 minecraft:magma_block
setblock 559 101 550 minecraft:shroomlight
fill 517 102 518 517 108 518 minecraft:black_concrete
fill 517 102 534 517 108 534 minecraft:black_concrete
fill 517 102 550 517 108 550 minecraft:black_concrete
fill 521 102 510 521 108 510 minecraft:black_concrete
setblock 524 102 552 minecraft:shroomlight
fill 531 102 552 531 107 552 minecraft:black_concrete
fill 532 102 545 533 103 546 minecraft:magma_block
fill 537 102 510 537 108 510 minecraft:black_concrete
fill 547 102 552 547 108 552 minecraft:black_concrete
fill 553 102 510 553 108 510 minecraft:black_concrete
fill 558 102 552 558 135 552 minecraft:black_concrete
fill 559 102 520 559 108 521 minecraft:black_concrete
fill 559 102 534 559 133 534 minecraft:black_concrete
fill 559 102 536 559 108 536 minecraft:black_concrete
fill 559 102 550 559 131 550 minecraft:black_concrete
fill 524 103 552 524 133 552 minecraft:black_concrete
fill 535 103 552 535 135 552 minecraft:black_concrete
setblock 536 103 552 minecraft:shroomlight
setblock 559 103 526 minecraft:white_concrete
fill 517 104 541 517 135 541 minecraft:black_concrete
setblock 517 104 542 minecraft:white_concrete
fill 536 104 552 536 136 552 minecraft:black_concrete
fill 548 104 510 548 131 510 minecraft:black_concrete
setblock 549 104 510 minecraft:magma_block
fill 550 104 510 550 135 510 minecraft:black_concrete
fill 559 104 526 559 137 526 minecraft:black_concrete
fill 517 105 542 517 135 542 minecraft:black_concrete
fill 530 105 539 531 106 540 minecraft:magma_block
setblock 545 105 552 minecraft:white_concrete
fill 546 105 552 546 131 552 minecraft:black_concrete
fill 549 105 510 549 126 510 minecraft:black_concrete
fill 545 106 552 545 135 552 minecraft:black_concrete
setblock 557 106 510 minecraft:white_concrete
setblock 559 106 535 minecraft:white_concrete
fill 552 107 534 553 108 535 minecraft:magma_block
fill 557 107 510 557 133 510 minecraft:black_concrete
setblock 559 107 532 minecraft:shroomlight
fill 559 107 535 559 135 535 minecraft:black_concrete
setblock 531 108 552 minecraft:shroomlight
fill 559 108 532 559 137 532 minecraft:black_concrete
fill 517 109 518 517 110 518 minecraft:orange_concrete
fill 517 109 534 517 110 534 minecraft:orange_concrete
setblock 517 109 539 minecraft:magma_block
fill 517 109 550 517 110 550 minecraft:orange_concrete
setblock 520 109 513 minecraft:light[level=14]
setblock 520 109 521 minecraft:light[level=14]
setblock 520 109 529 minecraft:light[level=14]
setblock 520 109 537 minecraft:light[level=14]
setblock 520 109 545 minecraft:light[level=14]
fill 521 109 510 521 110 510 minecraft:orange_concrete
setblock 528 109 513 minecraft:light[level=14]
setblock 528 109 521 minecraft:light[level=14]
setblock 528 109 529 minecraft:light[level=14]
setblock 528 109 537 minecraft:light[level=14]
setblock 528 109 545 minecraft:light[level=14]
fill 531 109 552 531 110 552 minecraft:orange_concrete
setblock 536 109 513 minecraft:light[level=14]
setblock 536 109 521 minecraft:light[level=14]
setblock 536 109 529 minecraft:light[level=14]
setblock 536 109 537 minecraft:light[level=14]
setblock 536 109 545 minecraft:light[level=14]
fill 537 109 510 537 110 510 minecraft:orange_concrete
setblock 544 109 513 minecraft:light[level=14]
setblock 544 109 521 minecraft:light[level=14]
setblock 544 109 529 minecraft:light[level=14]
setblock 544 109 537 minecraft:light[level=14]
setblock 544 109 545 minecraft:light[level=14]
fill 547 109 552 547 110 552 minecraft:orange_concrete
setblock 552 109 513 minecraft:light[level=14]
setblock 552 109 521 minecraft:light[level=14]
setblock 552 109 529 minecraft:light[level=14]
setblock 552 109 537 minecraft:light[level=14]
setblock 552 109 545 minecraft:light[level=14]
fill 553 109 510 553 110 510 minecraft:orange_concrete
fill 559 109 520 559 110 520 minecraft:orange_concrete
fill 559 109 521 559 110 521 minecraft:black_concrete
fill 559 109 536 559 110 536 minecraft:orange_concrete
setblock 559 109 551 minecraft:magma_block
setblock 517 110 512 minecraft:magma_block
fill 517 110 539 517 133 539 minecraft:black_concrete
fill 527 110 540 529 111 540 minecraft:red_terracotta
fill 528 110 539 528 111 539 minecraft:red_terracotta
fill 528 110 541 528 111 541 minecraft:red_terracotta
fill 559 110 551 559 132 551 minecraft:black_concrete
fill 517 111 512 517 135 512 minecraft:black_concrete
fill 517 111 518 517 117 518 minecraft:black_concrete
fill 517 111 534 517 116 534 minecraft:black_concrete
fill 517 111 550 517 117 550 minecraft:black_concrete
fill 521 111 510 521 117 510 minecraft:black_concrete
fill 531 111 552 531 117 552 minecraft:black_concrete
fill 537 111 510 537 117 510 minecraft:black_concrete
fill 547 111 552 547 117 552 minecraft:black_concrete
fill 553 111 510 553 117 510 minecraft:black_concrete
fill 559 111 520 559 115 520 minecraft:black_concrete
setblock 559 111 521 minecraft:shroomlight
fill 559 111 536 559 117 536 minecraft:black_concrete
setblock 559 111 537 minecraft:shroomlight
setblock 559 111 549 minecraft:magma_block
setblock 517 112 533 minecraft:white_concrete
setblock 517 112 537 minecraft:magma_block
setblock 517 112 548 minecraft:shroomlight
setblock 526 112 510 minecraft:white_concrete
setblock 538 112 552 minecraft:shroomlight
fill 559 112 521 559 131 521 minecraft:black_concrete
fill 559 112 537 559 135 537 minecraft:black_concrete
fill 559 112 549 559 131 549 minecraft:black_concrete
fill 517 113 533 517 131 533 minecraft:black_concrete
fill 517 113 537 517 135 537 minecraft:black_concrete
fill 517 113 548 517 135 548 minecraft:black_concrete
fill 526 113 510 526 130 510 minecraft:black_concrete
fill 538 113 552 538 135 552 minecraft:black_concrete
fill 551 113 510 551 131 510 minecraft:black_concrete
setblock 552 113 510 minecraft:white_concrete
fill 542 114 519 542 115 519 minecraft:magma_block
fill 552 114 510 552 123 510 minecraft:black_concrete
setblock 517 115 538 minecraft:white_concrete
setblock 517 115 551 minecraft:white_concrete
fill 544 115 521 544 116 523 minecraft:blackstone
fill 545 115 522 545 116 523 minecraft:blackstone
setblock 559 115 519 minecraft:magma_block
fill 517 116 538 517 120 538 minecraft:black_concrete
fill 517 116 551 517 135 551 minecraft:black_concrete
setblock 559 116 518 minecraft:white_concrete
fill 559 116 519 559 132 519 minecraft:black_concrete
setblock 559 116 520 minecraft:white_concrete
setblock 517 117 534 minecraft:magma_block
setblock 520 117 513 minecraft:light[level=14]
setblock 520 117 521 minecraft:light[level=14]
setblock 520 117 529 minecraft:light[level=14]
setblock 520 117 537 minecraft:light[level=14]
setblock 520 117 545 minecraft:light[level=14]
setblock 528 117 513 minecraft:light[level=14]
setblock 528 117 521 minecraft:light[level=14]
setblock 528 117 529 minecraft:light[level=14]
setblock 528 117 537 minecraft:light[level=14]
setblock 528 117 545 minecraft:light[level=14]
setblock 533 117 552 minecraft:magma_block
fill 534 117 552 534 128 552 minecraft:black_concrete
setblock 536 117 513 minecraft:light[level=14]
setblock 536 117 521 minecraft:light[level=14]
setblock 536 117 529 minecraft:light[level=14]
setblock 536 117 537 minecraft:light[level=14]
setblock 536 117 545 minecraft:light[level=14]
fill 544 117 510 544 136 510 minecraft:black_concrete
setblock 544 117 513 minecraft:light[level=14]
setblock 544 117 521 minecraft:light[level=14]
setblock 544 117 529 minecraft:light[level=14]
setblock 544 117 537 minecraft:light[level=14]
setblock 544 117 545 minecraft:light[level=14]
setblock 545 117 510 minecraft:white_concrete
setblock 546 117 510 minecraft:black_concrete
setblock 552 117 513 minecraft:light[level=14]
setblock 552 117 521 minecraft:light[level=14]
setblock 552 117 529 minecraft:light[level=14]
setblock 552 117 537 minecraft:light[level=14]
setblock 552 117 545 minecraft:light[level=14]
setblock 559 117 518 minecraft:magma_block
setblock 559 117 520 minecraft:black_concrete
fill 517 118 518 517 119 518 minecraft:orange_concrete
fill 517 118 534 517 119 534 minecraft:orange_concrete
setblock 517 118 544 minecraft:shroomlight
fill 517 118 550 517 119 550 minecraft:orange_concrete
fill 521 118 510 521 119 510 minecraft:orange_concrete
fill 531 118 552 531 119 552 minecraft:orange_concrete
fill 533 118 552 533 135 552 minecraft:black_concrete
fill 537 118 510 537 119 510 minecraft:orange_concrete
setblock 543 118 510 minecraft:white_concrete
fill 545 118 510 545 125 510 minecraft:black_concrete
setblock 546 118 510 minecraft:white_concrete
fill 547 118 552 547 119 552 minecraft:orange_concrete
fill 553 118 510 553 119 510 minecraft:orange_concrete
fill 559 118 518 559 135 518 minecraft:black_concrete
fill 559 118 520 559 119 520 minecraft:orange_concrete
fill 559 118 536 559 119 536 minecraft:orange_concrete
fill 517 119 544 517 135 544 minecraft:black_concrete
fill 543 119 510 543 135 510 minecraft:black_concrete
fill 545 119 517 545 120 517 minecraft:blackstone
fill 546 119 510 546 135 510 minecraft:black_concrete
fill 517 120 518 517 126 518 minecraft:black_concrete
fill 517 120 534 517 124 534 minecraft:black_concrete
fill 517 120 550 517 126 550 minecraft:black_concrete
fill 521 120 510 521 126 510 minecraft:black_concrete
setblock 523 120 552 minecraft:white_concrete
fill 531 120 552 531 121 552 minecraft:black_concrete
fill 537 120 510 537 126 510 minecraft:black_concrete
fill 541 120 516 543 121 516 minecraft:blue_concrete
fill 542 120 515 542 121 515 minecraft:blue_concrete
fill 542 120 517 542 121 517 minecraft:blue_concrete
fill 547 120 552 547 126 552 minecraft:black_concrete
fill 553 120 510 553 126 510 minecraft:black_concrete
setblock 559 120 515 minecraft:magma_block
fill 559 120 520 559 126 520 minecraft:black_concrete
fill 559 120 536 559 124 536 minecraft:black_concrete
setblock 517 121 538 minecraft:magma_block
setblock 522 121 552 minecraft:white_concrete
fill 523 121 552 523 135 552 minecraft:black_concrete
fill 559 121 515 559 135 515 minecraft:black_concrete
setblock 517 122 526 minecraft:shroomlight
fill 517 122 538 517 135 538 minecraft:black_concrete
fill 522 122 552 522 123 552 minecraft:black_concrete
setblock 531 122 552 minecraft:magma_block
setblock 551 122 552 minecraft:white_concrete
fill 517 123 526 517 133 526 minecraft:black_concrete
fill 519 123 533 520 124 533 minecraft:blue_concrete
setblock 531 123 510 minecraft:shroomlight
fill 531 123 552 531 126 552 minecraft:black_concrete
setblock 541 123 510 minecraft:white_concrete
setblock 543 123 552 minecraft:white_concrete
fill 551 123 552 551 135 552 minecraft:black_concrete
fill 517 124 545 517 135 545 minecraft:black_concrete
setblock 517 124 546 minecraft:white_concrete
setblock 522 124 552 minecraft:magma_block
fill 531 124 510 531 135 510 minecraft:black_concrete
fill 534 124 510 534 133 510 minecraft:black_concrete
setblock 535 124 510 minecraft:white_concrete
fill 536 124 510 536 131 510 minecraft:black_concrete
fill 541 124 510 541 135 510 minecraft:black_concrete
fill 543 124 552 543 135 552 minecraft:black_concrete
setblock 550 124 552 minecraft:white_concrete
setblock 552 124 510 minecraft:white_concrete
setblock 559 124 538 minecraft:magma_block
setblock 517 125 525 minecraft:magma_block
setblock 517 125 534 minecraft:white_concrete
fill 517 125 546 517 135 546 minecraft:black_concrete
setblock 520 125 513 minecraft:light[level=14]
setblock 520 125 521 minecraft:light[level=14]
setblock 520 125 529 minecraft:light[level=14]
setblock 520 125 537 minecraft:light[level=14]
setblock 520 125 545 minecraft:light[level=14]
fill 522 125 552 522 135 552 minecraft:black_concrete
setblock 528 125 513 minecraft:light[level=14]
setblock 528 125 521 minecraft:light[level=14]
setblock 528 125 529 minecraft:light[level=14]
setblock 528 125 537 minecraft:light[level=14]
setblock 528 125 545 minecraft:light[level=14]
fill 535 125 510 535 135 510 minecraft:black_concrete
setblock 536 125 513 minecraft:light[level=14]
setblock 536 125 521 minecraft:light[level=14]
setblock 536 125 529 minecraft:light[level=14]
setblock 536 125 537 minecraft:light[level=14]
setblock 536 125 545 minecraft:light[level=14]
setblock 539 125 552 minecraft:shroomlight
setblock 542 125 510 minecraft:magma_block
setblock 544 125 513 minecraft:light[level=14]
setblock 544 125 521 minecraft:light[level=14]
setblock 544 125 529 minecraft:light[level=14]
setblock 544 125 537 minecraft:light[level=14]
setblock 544 125 545 minecraft:light[level=14]
fill 550 125 552 550 135 552 minecraft:black_concrete
fill 552 125 510 552 136 510 minecraft:black_concrete
setblock 552 125 513 minecraft:light[level=14]
setblock 552 125 521 minecraft:light[level=14]
setblock 552 125 529 minecraft:light[level=14]
setblock 552 125 537 minecraft:light[level=14]
setblock 552 125 545 minecraft:light[level=14]
setblock 559 125 536 minecraft:white_concrete
fill 559 125 538 559 135 538 minecraft:black_concrete
fill 517 126 525 517 131 525 minecraft:black_concrete
setblock 517 126 534 minecraft:black_concrete
fill 539 126 552 539 131 552 minecraft:black_concrete
fill 542 126 510 542 135 510 minecraft:black_concrete
setblock 545 126 510 minecraft:shroomlight
setblock 559 126 514 minecraft:shroomlight
setblock 559 126 517 minecraft:magma_block
setblock 559 126 536 minecraft:black_concrete
setblock 559 126 539 minecraft:shroomlight
fill 517 127 518 517 128 518 minecraft:orange_concrete
fill 517 127 534 517 128 534 minecraft:orange_concrete
setblock 517 127 543 minecraft:white_concrete
fill 517 127 550 517 128 550 minecraft:orange_concrete
fill 521 127 510 521 128 510 minecraft:orange_concrete
fill 531 127 552 531 128 552 minecraft:orange_concrete
fill 537 127 510 537 128 510 minecraft:orange_concrete
fill 545 127 510 545 135 510 minecraft:black_concrete
fill 547 127 552 547 128 552 minecraft:orange_concrete
setblock 549 127 510 minecraft:white_concrete
fill 553 127 510 553 128 510 minecraft:orange_concrete
fill 559 127 514 559 135 514 minecraft:black_concrete
setblock 559 127 516 minecraft:white_concrete
fill 559 127 517 559 135 517 minecraft:black_concrete
fill 559 127 520 559 128 520 minecraft:orange_concrete
fill 559 127 536 559 128 536 minecraft:orange_concrete
fill 559 127 539 559 135 539 minecraft:black_concrete
fill 517 128 543 517 136 543 minecraft:black_concrete
fill 549 128 510 549 135 510 minecraft:black_concrete
fill 559 128 516 559 133 516 minecraft:black_concrete
fill 517 129 518 517 130 518 minecraft:black_concrete
fill 517 129 534 517 132 534 minecraft:black_concrete
setblock 517 129 550 minecraft:magma_block
fill 521 129 510 521 135 510 minecraft:black_concrete
fill 531 129 552 531 135 552 minecraft:black_concrete
setblock 534 129 552 minecraft:magma_block
fill 537 129 510 537 133 510 minecraft:black_concrete
setblock 540 129 552 minecraft:white_concrete
fill 547 129 552 547 135 552 minecraft:black_concrete
setblock 553 129 510 minecraft:black_concrete
fill 559 129 520 559 135 520 minecraft:black_concrete
fill 559 129 536 559 135 536 minecraft:black_concrete
setblock 517 130 529 minecraft:shroomlight
setblock 517 130 531 minecraft:shroomlight
fill 517 130 550 517 131 550 minecraft:black_concrete
fill 534 130 552 534 135 552 minecraft:black_concrete
setblock 540 130 552 minecraft:shroomlight
setblock 553 130 510 minecraft:shroomlight
setblock 559 130 524 minecraft:shroomlight
setblock 517 131 518 minecraft:white_concrete
fill 517 131 529 517 132 529 minecraft:black_concrete
fill 517 131 531 517 135 531 minecraft:black_concrete
setblock 526 131 510 minecraft:shroomlight
fill 540 131 552 540 133 552 minecraft:black_concrete
fill 551 131 534 552 132 535 minecraft:blue_concrete
fill 553 131 510 553 135 510 minecraft:black_concrete
setblock 559 131 524 minecraft:black_concrete
fill 517 132 518 517 135 518 minecraft:black_concrete
fill 517 132 522 517 135 522 minecraft:black_concrete
setblock 517 132 523 minecraft:blue_concrete
fill 517 132 525 517 133 525 minecraft:blue_concrete
setblock 517 132 527 minecraft:blue_concrete
setblock 517 132 533 minecraft:blue_concrete
setblock 517 132 550 minecraft:blue_concrete
setblock 520 132 510 minecraft:blue_concrete
fill 526 132 510 526 135 510 minecraft:black_concrete
fill 527 132 510 528 133 510 minecraft:blue_concrete
fill 529 132 510 529 135 510 minecraft:black_concrete
setblock 530 132 510 minecraft:blue_concrete
setblock 536 132 510 minecraft:blue_concrete
setblock 539 132 552 minecraft:blue_concrete
setblock 546 132 552 minecraft:blue_concrete
setblock 548 132 510 minecraft:blue_concrete
setblock 551 132 510 minecraft:blue_concrete
setblock 554 132 552 minecraft:blue_concrete
setblock 557 132 552 minecraft:blue_concrete
setblock 559 132 521 minecraft:blue_concrete
setblock 559 132 524 minecraft:blue_concrete
fill 559 132 528 559 133 528 minecraft:blue_concrete
fill 559 132 545 559 133 545 minecraft:blue_concrete
setblock 559 132 548 minecraft:blue_concrete
setblock 559 132 549 minecraft:shroomlight
setblock 559 132 550 minecraft:blue_concrete
fill 517 133 523 517 135 523 minecraft:black_concrete
fill 517 133 527 517 135 527 minecraft:black_concrete
setblock 517 133 529 minecraft:blue_concrete
setblock 517 133 532 minecraft:blue_concrete
fill 517 133 533 517 135 533 minecraft:black_concrete
setblock 517 133 534 minecraft:white_concrete
setblock 517 133 550 minecraft:black_concrete
fill 517 133 552 517 134 552 minecraft:blue_concrete
fill 520 133 510 520 135 510 minecraft:black_concrete
setblock 520 133 513 minecraft:light[level=14]
setblock 520 133 521 minecraft:light[level=14]
setblock 520 133 529 minecraft:light[level=14]
setblock 520 133 537 minecraft:light[level=14]
setblock 520 133 545 minecraft:light[level=14]
setblock 521 133 552 minecraft:blue_concrete
fill 525 133 552 525 135 552 minecraft:black_concrete
setblock 526 133 552 minecraft:blue_concrete
fill 527 133 552 529 133 552 minecraft:black_concrete
setblock 528 133 513 minecraft:light[level=14]
setblock 528 133 521 minecraft:light[level=14]
setblock 528 133 529 minecraft:light[level=14]
setblock 528 133 537 minecraft:light[level=14]
setblock 528 133 545 minecraft:light[level=14]
fill 530 133 510 530 135 510 minecraft:black_concrete
setblock 532 133 510 minecraft:blue_concrete
setblock 532 133 552 minecraft:blue_concrete
fill 536 133 510 536 135 510 minecraft:black_concrete
setblock 536 133 513 minecraft:light[level=14]
setblock 536 133 521 minecraft:light[level=14]
setblock 536 133 529 minecraft:light[level=14]
setblock 536 133 537 minecraft:light[level=14]
setblock 536 133 545 minecraft:light[level=14]
fill 539 133 552 539 135 552 minecraft:black_concrete
setblock 544 133 513 minecraft:light[level=14]
setblock 544 133 521 minecraft:light[level=14]
setblock 544 133 529 minecraft:light[level=14]
setblock 544 133 537 minecraft:light[level=14]
setblock 544 133 545 minecraft:light[level=14]
fill 546 133 552 546 135 552 minecraft:black_concrete
fill 548 133 510 548 135 510 minecraft:black_concrete
fill 551 133 510 551 135 510 minecraft:black_concrete
setblock 552 133 513 minecraft:light[level=14]
setblock 552 133 521 minecraft:light[level=14]
setblock 552 133 529 minecraft:light[level=14]
setblock 552 133 537 minecraft:light[level=14]
setblock 552 133 545 minecraft:light[level=14]
setblock 554 133 510 minecraft:blue_concrete
setblock 554 133 552 minecraft:black_concrete
fill 555 133 510 555 135 510 minecraft:black_concrete
fill 557 133 552 557 134 552 minecraft:black_concrete
setblock 559 133 510 minecraft:blue_concrete
setblock 559 133 519 minecraft:blue_concrete
setblock 559 133 521 minecraft:black_concrete
fill 559 133 524 559 135 524 minecraft:black_concrete
setblock 559 133 548 minecraft:black_concrete
setblock 559 133 549 minecraft:blue_concrete
fill 559 133 550 559 135 550 minecraft:black_concrete
setblock 559 133 551 minecraft:blue_concrete
setblock 517 134 511 minecraft:blue_concrete
setblock 517 134 520 minecraft:blue_concrete
fill 517 134 525 517 135 525 minecraft:black_concrete
setblock 517 134 526 minecraft:blue_concrete
fill 517 134 529 517 135 529 minecraft:black_concrete
fill 517 134 532 517 135 532 minecraft:black_concrete
fill 517 134 534 517 135 534 minecraft:black_concrete
setblock 517 134 539 minecraft:blue_concrete
setblock 517 134 550 minecraft:blue_concrete
fill 521 134 552 521 135 552 minecraft:black_concrete
setblock 524 134 552 minecraft:blue_concrete
fill 526 134 552 527 135 552 minecraft:black_concrete
fill 527 134 510 528 136 510 minecraft:black_concrete
setblock 528 134 552 minecraft:blue_concrete
fill 529 134 552 529 135 552 minecraft:black_concrete
fill 532 134 510 532 135 510 minecraft:black_concrete
fill 532 134 552 532 135 552 minecraft:black_concrete
setblock 534 134 510 minecraft:blue_concrete
setblock 537 134 510 minecraft:blue_concrete
setblock 540 134 552 minecraft:blue_concrete
setblock 548 134 552 minecraft:blue_concrete
fill 554 134 510 554 135 510 minecraft:black_concrete
fill 554 134 552 555 134 552 minecraft:blue_concrete
fill 556 134 552 556 135 552 minecraft:black_concrete
fill 557 134 510 558 134 510 minecraft:blue_concrete
fill 559 134 510 559 135 510 minecraft:black_concrete
setblock 559 134 516 minecraft:blue_concrete
fill 559 134 519 559 135 519 minecraft:black_concrete
fill 559 134 521 559 134 522 minecraft:blue_concrete
fill 559 134 523 559 135 523 minecraft:black_concrete
fill 559 134 528 559 135 528 minecraft:black_concrete
setblock 559 134 534 minecraft:blue_concrete
fill 559 134 545 559 135 545 minecraft:black_concrete
setblock 559 134 548 minecraft:magma_block
fill 559 134 549 559 135 549 minecraft:black_concrete
fill 559 134 551 559 135 551 minecraft:black_concrete
setblock 559 134 552 minecraft:blue_concrete
setblock 517 135 511 minecraft:black_concrete
setblock 517 135 520 minecraft:black_concrete
setblock 517 135 526 minecraft:black_concrete
setblock 517 135 539 minecraft:black_concrete
setblock 517 135 550 minecraft:black_concrete
setblock 517 135 552 minecraft:black_concrete
setblock 524 135 552 minecraft:black_concrete
setblock 528 135 552 minecraft:black_concrete
setblock 534 135 510 minecraft:black_concrete
setblock 537 135 510 minecraft:black_concrete
setblock 540 135 552 minecraft:black_concrete
setblock 548 135 552 minecraft:black_concrete
fill 554 135 552 555 135 552 minecraft:black_concrete
setblock 557 135 510 minecraft:shroomlight
setblock 557 135 552 minecraft:magma_block
setblock 558 135 510 minecraft:black_concrete
setblock 559 135 516 minecraft:black_concrete
fill 559 135 521 559 135 522 minecraft:black_concrete
setblock 559 135 534 minecraft:black_concrete
setblock 559 135 548 minecraft:black_concrete
setblock 559 135 552 minecraft:black_concrete
setblock 517 136 510 minecraft:black_concrete
fill 517 136 511 517 161 517 minecraft:blue_concrete
fill 517 136 518 517 137 518 minecraft:orange_concrete
fill 517 136 519 517 136 533 minecraft:blue_concrete
fill 517 136 534 517 137 534 minecraft:orange_concrete
fill 517 136 535 517 136 542 minecraft:blue_concrete
fill 517 136 544 517 145 549 minecraft:blue_concrete
fill 517 136 550 517 137 550 minecraft:orange_concrete
setblock 517 136 551 minecraft:shroomlight
fill 517 136 552 517 221 552 minecraft:blue_concrete
fill 518 136 510 520 136 510 minecraft:blue_concrete
setblock 518 136 552 minecraft:white_concrete
fill 519 136 552 528 136 552 minecraft:blue_concrete
fill 521 136 510 521 137 510 minecraft:orange_concrete
fill 522 136 510 523 148 510 minecraft:blue_concrete
fill 523 136 536 523 137 536 minecraft:red_terracotta
fill 525 136 510 526 198 510 minecraft:blue_concrete
fill 529 136 510 536 137 510 minecraft:blue_concrete
setblock 529 136 552 minecraft:shroomlight
setblock 530 136 552 minecraft:blue_concrete
fill 531 136 552 531 137 552 minecraft:orange_concrete
fill 532 136 552 535 137 552 minecraft:blue_concrete
fill 537 136 510 537 137 510 minecraft:orange_concrete
fill 537 136 552 543 136 552 minecraft:blue_concrete
fill 538 136 510 543 136 510 minecraft:blue_concrete
fill 545 136 510 551 153 510 minecraft:blue_concrete
fill 545 136 552 546 136 552 minecraft:blue_concrete
fill 547 136 552 547 137 552 minecraft:orange_concrete
fill 548 136 552 553 137 552 minecraft:blue_concrete
fill 553 136 510 553 137 510 minecraft:orange_concrete
fill 554 136 510 557 137 510 minecraft:blue_concrete
setblock 554 136 552 minecraft:black_concrete
fill 555 136 552 559 146 552 minecraft:blue_concrete
setblock 558 136 510 minecraft:shroomlight
fill 559 136 510 559 136 519 minecraft:blue_concrete
fill 559 136 520 559 137 520 minecraft:orange_concrete
fill 559 136 521 559 137 524 minecraft:blue_concrete
fill 559 136 528 559 137 531 minecraft:blue_concrete
fill 559 136 533 559 143 535 minecraft:blue_concrete
fill 559 136 536 559 137 536 minecraft:orange_concrete
fill 559 136 537 559 137 537 minecraft:blue_concrete
setblock 559 136 538 minecraft:shroomlight
setblock 559 136 539 minecraft:magma_block
fill 559 136 540 559 187 540 minecraft:blue_concrete
fill 559 136 542 559 137 545 minecraft:blue_concrete
fill 559 136 547 559 137 551 minecraft:blue_concrete
fill 517 137 510 519 143 510 minecraft:blue_concrete
fill 517 137 519 517 137 522 minecraft:blue_concrete
setblock 517 137 523 minecraft:black_concrete
fill 517 137 524 517 137 533 minecraft:blue_concrete
setblock 517 137 535 minecraft:black_concrete
fill 517 137 536 517 137 543 minecraft:blue_concrete
fill 517 137 551 517 221 551 minecraft:blue_concrete
fill 518 137 552 520 163 552 minecraft:blue_concrete
setblock 520 137 510 minecraft:magma_block
setblock 521 137 552 minecraft:black_concrete
fill 522 137 552 529 144 552 minecraft:blue_concrete
fill 524 137 510 524 221 510 minecraft:blue_concrete
fill 527 137 510 528 137 510 minecraft:blue_concrete
setblock 530 137 552 minecraft:black_concrete
fill 536 137 552 539 144 552 minecraft:blue_concrete
fill 538 137 510 538 168 510 minecraft:blue_concrete
setblock 539 137 510 minecraft:black_concrete
fill 540 137 510 544 165 510 minecraft:blue_concrete
fill 540 137 552 541 137 552 minecraft:black_concrete
fill 542 137 552 543 181 552 minecraft:blue_concrete
setblock 545 137 552 minecraft:blue_concrete
setblock 546 137 552 minecraft:magma_block
fill 552 137 510 552 180 510 minecraft:blue_concrete
fill 554 137 552 554 150 552 minecraft:blue_concrete
fill 558 137 510 559 144 510 minecraft:blue_concrete
setblock 559 137 511 minecraft:black_concrete
fill 559 137 512 559 137 513 minecraft:blue_concrete
setblock 559 137 514 minecraft:black_concrete
fill 559 137 515 559 143 518 minecraft:blue_concrete
setblock 559 137 519 minecraft:black_concrete
setblock 559 137 525 minecraft:blue_concrete
fill 559 137 527 559 181 527 minecraft:blue_concrete
fill 559 137 538 559 188 539 minecraft:blue_concrete
fill 559 137 541 559 176 541 minecraft:blue_concrete
fill 559 137 546 559 144 546 minecraft:blue_concrete
setblock 517 138 518 minecraft:white_concrete
fill 517 138 519 517 213 519 minecraft:blue_concrete
setblock 517 138 520 minecraft:black_concrete
fill 517 138 521 517 145 528 minecraft:blue_concrete
setblock 517 138 529 minecraft:black_concrete
fill 517 138 530 517 194 530 minecraft:blue_concrete
setblock 517 138 531 minecraft:black_concrete
fill 517 138 532 517 142 537 minecraft:blue_concrete
setblock 517 138 538 minecraft:black_concrete
fill 517 138 539 517 162 541 minecraft:blue_concrete
setblock 517 138 542 minecraft:black_concrete
fill 517 138 543 517 163 543 minecraft:blue_concrete
fill 517 138 550 517 147 550 minecraft:blue_concrete
fill 520 138 510 521 139 510 minecraft:blue_concrete
fill 521 138 552 521 140 552 minecraft:blue_concrete
setblock 527 138 510 minecraft:white_concrete
fill 528 138 510 528 142 510 minecraft:blue_concrete
fill 529 138 510 531 138 510 minecraft:black_concrete
fill 530 138 552 534 153 552 minecraft:blue_concrete
fill 532 138 510 536 140 510 minecraft:blue_concrete
setblock 535 138 552 minecraft:black_concrete
setblock 537 138 510 minecraft:magma_block
fill 539 138 510 539 183 510 minecraft:blue_concrete
setblock 540 138 552 minecraft:black_concrete
fill 541 138 552 541 207 552 minecraft:blue_concrete
fill 544 138 552 544 168 552 minecraft:blue_concrete
setblock 545 138 552 minecraft:black_concrete
fill 546 138 552 552 150 552 minecraft:blue_concrete
fill 553 138 510 555 153 510 minecraft:blue_concrete
setblock 553 138 552 minecraft:white_concrete
fill 556 138 510 557 138 510 minecraft:black_concrete
fill 559 138 511 559 170 511 minecraft:blue_concrete
setblock 559 138 512 minecraft:black_concrete
fill 559 138 513 559 147 514 minecraft:blue_concrete
fill 559 138 519 559 138 520 minecraft:blue_concrete
fill 559 138 521 559 138 522 minecraft:black_concrete
fill 559 138 523 559 180 524 minecraft:blue_concrete
setblock 559 138 525 minecraft:black_concrete
fill 559 138 526 559 166 526 minecraft:blue_concrete
fill 559 138 528 559 219 528 minecraft:blue_concrete
setblock 559 138 529 minecraft:black_concrete
fill 559 138 530 559 141 532 minecraft:blue_concrete
fill 559 138 536 559 153 536 minecraft:blue_concrete
setblock 559 138 537 minecraft:black_concrete
fill 559 138 542 559 213 543 minecraft:blue_concrete
setblock 559 138 544 minecraft:black_concrete
fill 559 138 545 559 152 545 minecraft:blue_concrete
fill 559 138 547 559 221 547 minecraft:blue_concrete
setblock 559 138 548 minecraft:black_concrete
fill 559 138 549 559 140 551 minecraft:blue_concrete
fill 517 139 518 517 153 518 minecraft:blue_concrete
fill 517 139 520 517 218 520 minecraft:blue_concrete
fill 517 139 529 517 144 529 minecraft:blue_concrete
fill 517 139 531 517 202 531 minecraft:blue_concrete
fill 517 139 538 517 170 538 minecraft:blue_concrete
setblock 517 139 542 minecraft:blue_concrete
fill 527 139 510 527 156 510 minecraft:blue_concrete
fill 529 139 510 531 146 510 minecraft:blue_concrete
fill 535 139 552 535 156 552 minecraft:blue_concrete
fill 537 139 510 537 153 510 minecraft:blue_concrete
fill 540 139 552 540 217 552 minecraft:blue_concrete
fill 545 139 552 545 221 552 minecraft:blue_concrete
fill 553 139 552 553 199 552 minecraft:blue_concrete
fill 556 139 510 557 196 510 minecraft:blue_concrete
fill 559 139 512 559 168 512 minecraft:blue_concrete
setblock 559 139 519 minecraft:magma_block
fill 559 139 520 559 152 522 minecraft:blue_concrete
fill 559 139 525 559 193 525 minecraft:blue_concrete
fill 559 139 529 559 141 529 minecraft:blue_concrete
fill 559 139 537 559 177 537 minecraft:blue_concrete
fill 559 139 544 559 170 544 minecraft:blue_concrete
fill 559 139 548 559 142 548 minecraft:blue_concrete
setblock 517 140 542 minecraft:shroomlight
fill 520 140 510 520 165 510 minecraft:blue_concrete
setblock 521 140 510 minecraft:shroomlight
fill 527 140 528 528 141 529 minecraft:blackstone
fill 535 140 528 535 140 530 minecraft:light_blue_concrete
fill 536 140 529 538 140 531 minecraft:light_blue_concrete
fill 537 140 528 539 140 528 minecraft:light_blue_concrete
setblock 538 140 527 minecraft:light_blue_concrete
fill 539 140 529 539 140 530 minecraft:light_blue_concrete
fill 559 140 519 559 162 519 minecraft:blue_concrete
fill 517 141 542 517 168 542 minecraft:blue_concrete
setblock 520 141 513 minecraft:light[level=14]
setblock 520 141 521 minecraft:light[level=14]
setblock 520 141 529 minecraft:light[level=14]
setblock 520 141 537 minecraft:light[level=14]
setblock 520 141 545 minecraft:light[level=14]
fill 521 141 510 521 153 510 minecraft:blue_concrete
setblock 521 141 552 minecraft:shroomlight
setblock 528 141 513 minecraft:light[level=14]
setblock 528 141 521 minecraft:light[level=14]
setblock 528 141 537 minecraft:light[level=14]
setblock 528 141 545 minecraft:light[level=14]
fill 532 141 510 534 141 510 minecraft:blue_concrete
fill 533 141 527 534 141 531 minecraft:light_blue_concrete
fill 534 141 526 535 141 526 minecraft:light_blue_concrete
fill 534 141 532 540 141 532 minecraft:light_blue_concrete
setblock 535 141 510 minecraft:white_concrete
fill 535 141 525 539 141 525 minecraft:light_blue_concrete
fill 535 141 528 535 145 530 minecraft:blue_concrete
setblock 535 141 531 minecraft:light_blue_concrete
fill 535 141 533 539 141 533 minecraft:light_blue_concrete
fill 536 141 510 536 146 510 minecraft:blue_concrete
setblock 536 141 513 minecraft:light[level=14]
setblock 536 141 521 minecraft:light[level=14]
fill 536 141 529 538 145 531 minecraft:blue_concrete
setblock 536 141 537 minecraft:light[level=14]
setblock 536 141 545 minecraft:light[level=14]
fill 537 141 528 539 145 528 minecraft:blue_concrete
fill 538 141 526 540 141 526 minecraft:light_blue_concrete
fill 538 141 527 538 147 527 minecraft:blue_concrete
fill 539 141 527 541 141 527 minecraft:light_blue_concrete
fill 539 141 529 539 145 530 minecraft:blue_concrete
fill 539 141 531 541 141 531 minecraft:light_blue_concrete
fill 540 141 528 541 141 530 minecraft:light_blue_concrete
setblock 544 141 513 minecraft:light[level=14]
setblock 544 141 521 minecraft:light[level=14]
setblock 544 141 529 minecraft:light[level=14]
setblock 544 141 537 minecraft:light[level=14]
setblock 544 141 545 minecraft:light[level=14]
setblock 552 141 513 minecraft:light[level=14]
setblock 552 141 521 minecraft:light[level=14]
setblock 552 141 529 minecraft:light[level=14]
setblock 552 141 537 minecraft:light[level=14]
setblock 552 141 545 minecraft:light[level=14]
fill 559 141 549 559 163 549 minecraft:blue_concrete
setblock 559 141 550 minecraft:shroomlight
fill 559 141 551 559 221 551 minecraft:blue_concrete
fill 521 142 552 521 219 552 minecraft:blue_concrete
setblock 532 142 510 minecraft:magma_block
fill 532 142 527 532 142 531 minecraft:light_blue_concrete
fill 533 142 510 535 143 510 minecraft:blue_concrete
fill 533 142 525 533 142 526 minecraft:light_blue_concrete
fill 533 142 527 534 145 531 minecraft:blue_concrete
fill 533 142 532 533 142 533 minecraft:light_blue_concrete
setblock 534 142 525 minecraft:light_blue_concrete
fill 534 142 526 535 145 526 minecraft:blue_concrete
fill 534 142 532 540 145 532 minecraft:blue_concrete
setblock 534 142 533 minecraft:light_blue_concrete
fill 535 142 524 539 142 524 minecraft:light_blue_concrete
fill 535 142 525 539 147 525 minecraft:blue_concrete
fill 535 142 531 535 145 531 minecraft:blue_concrete
fill 535 142 533 539 145 533 minecraft:blue_concrete
fill 535 142 534 539 142 534 minecraft:light_blue_concrete
fill 538 142 526 540 147 526 minecraft:blue_concrete
fill 539 142 527 541 148 527 minecraft:blue_concrete
fill 539 142 531 541 145 531 minecraft:blue_concrete
fill 540 142 525 541 142 525 minecraft:light_blue_concrete
fill 540 142 528 541 145 530 minecraft:blue_concrete
fill 540 142 533 541 142 533 minecraft:light_blue_concrete
setblock 541 142 526 minecraft:light_blue_concrete
setblock 541 142 532 minecraft:light_blue_concrete
fill 542 142 527 542 142 531 minecraft:light_blue_concrete
setblock 559 142 529 minecraft:magma_block
setblock 559 142 530 minecraft:white_concrete
fill 559 142 531 559 180 532 minecraft:blue_concrete
fill 559 142 550 559 202 550 minecraft:blue_concrete
fill 517 143 532 517 165 533 minecraft:blue_concrete
setblock 517 143 534 minecraft:shroomlight
fill 517 143 535 517 158 537 minecraft:blue_concrete
setblock 528 143 510 minecraft:white_concrete
fill 531 143 527 531 143 531 minecraft:light_blue_concrete
fill 532 143 510 532 178 510 minecraft:blue_concrete
fill 532 143 525 532 143 526 minecraft:light_blue_concrete
fill 532 143 527 532 152 531 minecraft:blue_concrete
fill 532 143 532 532 143 533 minecraft:light_blue_concrete
fill 533 143 524 534 143 524 minecraft:light_blue_concrete
fill 533 143 525 533 152 526 minecraft:blue_concrete
fill 533 143 532 533 147 533 minecraft:blue_concrete
fill 533 143 534 534 143 534 minecraft:light_blue_concrete
fill 534 143 525 534 147 525 minecraft:blue_concrete
fill 534 143 533 534 145 533 minecraft:blue_concrete
fill 535 143 523 539 143 523 minecraft:light_blue_concrete
fill 535 143 524 539 147 524 minecraft:blue_concrete
fill 535 143 534 539 147 534 minecraft:blue_concrete
fill 535 143 535 539 143 535 minecraft:light_blue_concrete
fill 540 143 524 541 143 524 minecraft:light_blue_concrete
fill 540 143 525 541 152 525 minecraft:blue_concrete
fill 540 143 533 541 152 533 minecraft:blue_concrete
fill 540 143 534 541 143 534 minecraft:light_blue_concrete
fill 541 143 526 541 152 526 minecraft:blue_concrete
fill 541 143 532 541 147 532 minecraft:blue_concrete
fill 542 143 525 542 143 526 minecraft:light_blue_concrete
fill 542 143 527 542 147 531 minecraft:blue_concrete
fill 542 143 532 542 143 533 minecraft:light_blue_concrete
fill 543 143 527 543 143 531 minecraft:light_blue_concrete
fill 559 143 529 559 146 530 minecraft:blue_concrete
setblock 559 143 548 minecraft:shroomlight
fill 517 144 510 518 163 510 minecraft:blue_concrete
fill 517 144 534 517 153 534 minecraft:blue_concrete
setblock 519 144 510 minecraft:magma_block
fill 528 144 510 528 219 510 minecraft:blue_concrete
fill 530 144 528 530 151 530 minecraft:light_blue_concrete
fill 531 144 526 531 144 527 minecraft:light_blue_concrete
fill 531 144 528 531 151 530 minecraft:blue_concrete
fill 531 144 531 531 144 532 minecraft:light_blue_concrete
fill 532 144 524 532 144 525 minecraft:light_blue_concrete
fill 532 144 526 532 151 526 minecraft:blue_concrete
fill 532 144 532 532 151 532 minecraft:blue_concrete
fill 532 144 533 532 144 534 minecraft:light_blue_concrete
setblock 533 144 510 minecraft:white_concrete
setblock 533 144 524 minecraft:light_blue_concrete
setblock 533 144 534 minecraft:light_blue_concrete
fill 534 144 510 535 161 510 minecraft:blue_concrete
fill 534 144 523 535 144 523 minecraft:light_blue_concrete
fill 534 144 524 534 151 524 minecraft:blue_concrete
fill 534 144 534 534 147 534 minecraft:blue_concrete
fill 534 144 535 535 144 535 minecraft:light_blue_concrete
fill 536 144 522 538 145 522 minecraft:light_blue_concrete
fill 536 144 523 538 145 523 minecraft:blue_concrete
fill 536 144 535 538 150 535 minecraft:blue_concrete
fill 536 144 536 538 148 536 minecraft:light_blue_concrete
fill 539 144 523 540 144 523 minecraft:light_blue_concrete
fill 539 144 535 540 144 535 minecraft:light_blue_concrete
fill 540 144 524 540 151 524 minecraft:blue_concrete
fill 540 144 534 540 151 534 minecraft:blue_concrete
fill 541 144 524 542 144 524 minecraft:light_blue_concrete
fill 541 144 534 542 144 534 minecraft:light_blue_concrete
setblock 542 144 525 minecraft:light_blue_concrete
fill 542 144 526 542 151 526 minecraft:blue_concrete
fill 542 144 532 542 147 532 minecraft:blue_concrete
setblock 542 144 533 minecraft:light_blue_concrete
fill 543 144 526 543 144 527 minecraft:light_blue_concrete
fill 543 144 528 543 151 530 minecraft:blue_concrete
fill 543 144 531 543 144 532 minecraft:light_blue_concrete
fill 544 144 528 544 151 530 minecraft:light_blue_concrete
fill 559 144 515 559 217 515 minecraft:blue_concrete
setblock 559 144 516 minecraft:magma_block
fill 559 144 517 559 169 518 minecraft:blue_concrete
fill 559 144 533 559 152 534 minecraft:blue_concrete
setblock 559 144 535 minecraft:white_concrete
fill 559 144 548 559 219 548 minecraft:blue_concrete
setblock 517 145 529 minecraft:magma_block
fill 519 145 510 519 217 510 minecraft:blue_concrete
fill 522 145 552 522 189 552 minecraft:blue_concrete
setblock 523 145 552 minecraft:magma_block
fill 524 145 552 529 164 552 minecraft:blue_concrete
fill 530 145 527 530 148 527 minecraft:light_blue_concrete
fill 530 145 531 530 150 531 minecraft:light_blue_concrete
fill 531 145 525 531 145 526 minecraft:light_blue_concrete
fill 531 145 527 531 150 527 minecraft:blue_concrete
fill 531 145 531 531 150 531 minecraft:blue_concrete
fill 531 145 532 531 145 533 minecraft:light_blue_concrete
setblock 532 145 524 minecraft:light_blue_concrete
fill 532 145 525 532 150 525 minecraft:blue_concrete
fill 532 145 533 532 150 533 minecraft:blue_concrete
setblock 532 145 534 minecraft:light_blue_concrete
fill 533 145 510 533 219 510 minecraft:blue_concrete
fill 533 145 523 534 145 523 minecraft:light_blue_concrete
fill 533 145 524 533 150 524 minecraft:blue_concrete
fill 533 145 534 533 147 534 minecraft:blue_concrete
fill 533 145 535 534 145 535 minecraft:light_blue_concrete
fill 535 145 522 535 147 522 minecraft:light_blue_concrete
fill 535 145 523 535 147 523 minecraft:blue_concrete
fill 535 145 535 535 150 535 minecraft:blue_concrete
fill 535 145 536 535 150 536 minecraft:light_blue_concrete
fill 536 145 552 537 180 552 minecraft:blue_concrete
setblock 538 145 552 minecraft:shroomlight
fill 539 145 522 539 147 522 minecraft:light_blue_concrete
fill 539 145 523 539 147 523 minecraft:blue_concrete
fill 539 145 535 539 150 535 minecraft:blue_concrete
fill 539 145 536 539 148 536 minecraft:light_blue_concrete
fill 539 145 552 539 169 552 minecraft:blue_concrete
fill 540 145 523 541 145 523 minecraft:light_blue_concrete
fill 540 145 535 541 145 535 minecraft:light_blue_concrete
fill 541 145 524 541 150 524 minecraft:blue_concrete
fill 541 145 534 541 150 534 minecraft:blue_concrete
setblock 542 145 524 minecraft:light_blue_concrete
fill 542 145 525 542 150 525 minecraft:blue_concrete
fill 542 145 533 542 150 533 minecraft:blue_concrete
setblock 542 145 534 minecraft:light_blue_concrete
fill 543 145 525 543 145 526 minecraft:light_blue_concrete
fill 543 145 527 543 150 527 minecraft:blue_concrete
fill 543 145 531 543 150 531 minecraft:blue_concrete
fill 543 145 532 543 145 533 minecraft:light_blue_concrete
fill 544 145 527 544 150 527 minecraft:light_blue_concrete
fill 544 145 531 544 150 531 minecraft:light_blue_concrete
setblock 558 145 510 minecraft:magma_block
fill 559 145 510 559 218 510 minecraft:blue_concrete
fill 559 145 516 559 166 516 minecraft:blue_concrete
fill 559 145 535 559 221 535 minecraft:blue_concrete
setblock 559 145 546 minecraft:white_concrete
fill 517 146 521 517 181 523 minecraft:blue_concrete
setblock 517 146 524 minecraft:shroomlight
fill 517 146 525 517 148 529 minecraft:blue_concrete
fill 517 146 544 517 146 546 minecraft:blue_concrete
setblock 517 146 547 minecraft:white_concrete
fill 517 146 548 517 162 549 minecraft:blue_concrete
fill 523 146 552 523 221 552 minecraft:blue_concrete
fill 530 146 526 530 149 526 minecraft:light_blue_concrete
fill 530 146 532 530 149 532 minecraft:light_blue_concrete
fill 531 146 524 531 149 525 minecraft:light_blue_concrete
fill 531 146 526 531 149 526 minecraft:blue_concrete
fill 531 146 532 531 149 532 minecraft:blue_concrete
fill 531 146 533 531 149 534 minecraft:light_blue_concrete
fill 532 146 523 533 149 523 minecraft:light_blue_concrete
fill 532 146 524 532 149 524 minecraft:blue_concrete
fill 532 146 534 532 149 534 minecraft:blue_concrete
fill 532 146 535 533 149 535 minecraft:light_blue_concrete
fill 533 146 527 533 147 531 minecraft:blue_concrete
fill 534 146 522 534 149 522 minecraft:light_blue_concrete
fill 534 146 523 534 149 523 minecraft:blue_concrete
fill 534 146 526 534 147 530 minecraft:blue_concrete
fill 534 146 531 536 146 533 minecraft:redstone_block
fill 534 146 535 534 149 535 minecraft:blue_concrete
fill 534 146 536 534 149 536 minecraft:light_blue_concrete
fill 535 146 529 538 147 530 minecraft:blue_concrete
fill 536 146 521 538 146 523 minecraft:redstone_block
fill 537 146 531 538 147 533 minecraft:blue_concrete
fill 538 146 528 541 147 528 minecraft:blue_concrete
fill 538 146 552 538 207 552 minecraft:blue_concrete
fill 539 146 529 541 146 531 minecraft:redstone_block
fill 539 146 532 539 147 533 minecraft:blue_concrete
fill 540 146 522 540 149 522 minecraft:light_blue_concrete
fill 540 146 523 540 149 523 minecraft:blue_concrete
fill 540 146 532 540 147 532 minecraft:blue_concrete
fill 540 146 535 540 149 535 minecraft:blue_concrete
fill 540 146 536 540 149 536 minecraft:light_blue_concrete
fill 541 146 523 542 149 523 minecraft:light_blue_concrete
fill 541 146 535 542 149 535 minecraft:light_blue_concrete
fill 542 146 524 542 149 524 minecraft:blue_concrete
fill 542 146 534 542 149 534 minecraft:blue_concrete
fill 543 146 524 543 149 525 minecraft:light_blue_concrete
fill 543 146 526 543 149 526 minecraft:blue_concrete
fill 543 146 532 543 149 532 minecraft:blue_concrete
fill 543 146 533 543 149 534 minecraft:light_blue_concrete
fill 544 146 526 544 149 526 minecraft:light_blue_concrete
fill 544 146 532 544 149 532 minecraft:light_blue_concrete
fill 558 146 510 558 221 510 minecraft:blue_concrete
fill 559 146 546 559 194 546 minecraft:blue_concrete
fill 517 147 524 517 219 524 minecraft:blue_concrete
fill 517 147 544 517 165 544 minecraft:blue_concrete
setblock 517 147 545 minecraft:shroomlight
fill 517 147 546 517 188 547 minecraft:blue_concrete
fill 529 147 510 530 148 510 minecraft:blue_concrete
setblock 531 147 510 minecraft:magma_block
setblock 536 147 510 minecraft:magma_block
setblock 555 147 552 minecraft:magma_block
fill 556 147 552 559 165 552 minecraft:blue_concrete
fill 559 147 529 559 160 529 minecraft:blue_concrete
setblock 559 147 530 minecraft:magma_block
fill 517 148 545 517 218 545 minecraft:blue_concrete
setblock 517 148 550 minecraft:white_concrete
fill 518 148 511 529 148 551 minecraft:black_concrete
fill 530 148 511 530 148 525 minecraft:black_concrete
fill 530 148 533 530 148 551 minecraft:black_concrete
fill 531 148 510 531 221 510 minecraft:blue_concrete
fill 531 148 511 531 148 523 minecraft:black_concrete
fill 531 148 535 531 148 551 minecraft:black_concrete
fill 532 148 511 533 148 522 minecraft:black_concrete
fill 532 148 536 533 148 551 minecraft:black_concrete
fill 533 148 527 533 148 529 minecraft:blue_concrete
fill 533 148 530 533 148 534 minecraft:shroomlight
fill 534 148 511 534 148 521 minecraft:black_concrete
setblock 534 148 525 minecraft:shroomlight
fill 534 148 526 534 148 528 minecraft:ochre_froglight
fill 534 148 529 534 148 530 minecraft:shroomlight
fill 534 148 531 536 148 533 minecraft:black_concrete
fill 534 148 534 537 148 534 minecraft:shroomlight
fill 534 148 537 558 148 551 minecraft:black_concrete
fill 535 148 511 558 148 519 minecraft:black_concrete
fill 535 148 520 535 148 524 minecraft:shroomlight
fill 535 148 525 537 148 525 minecraft:ochre_froglight
fill 535 148 529 537 148 529 minecraft:ochre_froglight
fill 535 148 530 538 148 530 minecraft:shroomlight
fill 536 148 510 536 180 510 minecraft:blue_concrete
fill 536 148 520 539 148 520 minecraft:shroomlight
fill 536 148 521 538 148 523 minecraft:black_concrete
fill 536 148 524 539 148 524 minecraft:shroomlight
fill 537 148 531 537 148 533 minecraft:shroomlight
setblock 538 148 525 minecraft:shroomlight
fill 538 148 526 538 148 528 minecraft:ochre_froglight
setblock 538 148 529 minecraft:shroomlight
fill 538 148 531 538 148 532 minecraft:shroomlight
fill 538 148 533 539 152 534 minecraft:blue_concrete
fill 539 148 521 539 148 523 minecraft:shroomlight
fill 539 148 525 539 153 526 minecraft:blue_concrete
fill 539 148 528 542 148 528 minecraft:shroomlight
fill 539 148 529 541 148 531 minecraft:black_concrete
fill 539 148 532 542 148 532 minecraft:shroomlight
fill 540 148 520 558 148 521 minecraft:black_concrete
fill 540 148 526 540 153 526 minecraft:blue_concrete
fill 541 148 522 558 148 522 minecraft:black_concrete
fill 541 148 536 558 148 536 minecraft:black_concrete
setblock 542 148 527 minecraft:blue_concrete
fill 542 148 529 542 148 531 minecraft:shroomlight
fill 543 148 523 558 148 523 minecraft:black_concrete
fill 543 148 535 558 148 535 minecraft:black_concrete
fill 544 148 524 558 148 525 minecraft:black_concrete
fill 544 148 533 558 148 534 minecraft:black_concrete
fill 545 148 526 558 148 532 minecraft:black_concrete
fill 555 148 552 555 218 552 minecraft:blue_concrete
fill 559 148 513 559 204 513 minecraft:blue_concrete
setblock 559 148 514 minecraft:shroomlight
fill 559 148 530 559 150 530 minecraft:blue_concrete
fill 517 149 525 517 194 527 minecraft:blue_concrete
setblock 517 149 528 minecraft:shroomlight
fill 517 149 529 517 156 529 minecraft:blue_concrete
fill 517 149 550 517 151 550 minecraft:blue_concrete
setblock 520 149 513 minecraft:light[level=14]
setblock 520 149 521 minecraft:light[level=14]
setblock 520 149 529 minecraft:light[level=14]
setblock 520 149 537 minecraft:light[level=14]
setblock 520 149 545 minecraft:light[level=14]
setblock 522 149 510 minecraft:shroomlight
fill 523 149 510 523 219 510 minecraft:blue_concrete
fill 527 149 518 527 150 518 minecraft:bone_block
fill 527 149 527 527 155 527 minecraft:bone_block
fill 527 149 536 527 150 536 minecraft:bone_block
setblock 528 149 513 minecraft:light[level=14]
setblock 528 149 521 minecraft:light[level=14]
setblock 528 149 529 minecraft:light[level=14]
setblock 528 149 537 minecraft:light[level=14]
setblock 528 149 545 minecraft:light[level=14]
setblock 529 149 510 minecraft:white_concrete
fill 530 149 510 530 173 510 minecraft:blue_concrete
fill 530 149 518 530 150 518 minecraft:bone_block
fill 530 149 527 530 155 527 minecraft:bone_block
fill 530 149 536 530 150 536 minecraft:bone_block
fill 533 149 518 533 150 518 minecraft:bone_block
fill 533 149 527 533 155 527 minecraft:bone_block
fill 533 149 528 534 150 534 minecraft:blue_concrete
fill 533 149 536 533 150 536 minecraft:bone_block
fill 534 149 525 534 152 527 minecraft:blue_concrete
fill 535 149 522 539 150 522 minecraft:light_blue_concrete
fill 535 149 523 538 150 525 minecraft:blue_concrete
fill 535 149 529 537 152 534 minecraft:blue_concrete
setblock 536 149 513 minecraft:light[level=14]
fill 536 149 518 536 150 518 minecraft:bone_block
setblock 536 149 521 minecraft:light[level=14]
fill 536 149 536 536 150 536 minecraft:bone_block
setblock 536 149 537 minecraft:light[level=14]
setblock 536 149 545 minecraft:light[level=14]
fill 537 149 536 538 151 536 minecraft:light_blue_concrete
fill 538 149 526 538 153 532 minecraft:blue_concrete
fill 539 149 518 539 150 518 minecraft:bone_block
fill 539 149 523 539 150 524 minecraft:blue_concrete
fill 539 149 527 539 155 527 minecraft:bone_block
fill 539 149 528 542 151 532 minecraft:blue_concrete
fill 539 149 536 539 150 536 minecraft:bone_block
fill 540 149 527 541 153 527 minecraft:blue_concrete
fill 542 149 518 542 150 518 minecraft:bone_block
fill 542 149 527 542 155 527 minecraft:bone_block
fill 542 149 536 542 150 536 minecraft:bone_block
setblock 544 149 513 minecraft:light[level=14]
setblock 544 149 521 minecraft:light[level=14]
setblock 544 149 537 minecraft:light[level=14]
setblock 544 149 545 minecraft:light[level=14]
fill 545 149 518 545 150 518 minecraft:bone_block
fill 545 149 527 545 159 527 minecraft:bone_block
fill 545 149 536 545 150 536 minecraft:bone_block
setblock 552 149 513 minecraft:light[level=14]
setblock 552 149 521 minecraft:light[level=14]
setblock 552 149 529 minecraft:light[level=14]
setblock 552 149 537 minecraft:light[level=14]
setblock 552 149 545 minecraft:light[level=14]
fill 559 149 514 559 217 514 minecraft:blue_concrete
fill 517 150 528 517 221 528 minecraft:blue_concrete
fill 522 150 510 522 163 510 minecraft:blue_concrete
fill 529 150 510 529 163 510 minecraft:blue_concrete
fill 531 150 525 531 150 526 minecraft:light_blue_concrete
fill 531 150 532 531 150 533 minecraft:light_blue_concrete
fill 532 150 524 532 151 524 minecraft:light_blue_concrete
fill 532 150 534 532 151 534 minecraft:light_blue_concrete
fill 533 150 523 534 150 523 minecraft:light_blue_concrete
fill 533 150 535 534 150 535 minecraft:light_blue_concrete
fill 540 150 523 541 150 523 minecraft:light_blue_concrete
fill 540 150 535 541 150 535 minecraft:light_blue_concrete
fill 542 150 524 542 151 524 minecraft:light_blue_concrete
fill 542 150 534 542 151 534 minecraft:light_blue_concrete
fill 543 150 525 543 150 526 minecraft:light_blue_concrete
fill 543 150 532 543 150 533 minecraft:light_blue_concrete
fill 527 151 519 527 152 519 minecraft:bone_block
fill 527 151 535 527 152 535 minecraft:bone_block
fill 530 151 519 530 152 519 minecraft:bone_block
fill 530 151 535 530 152 535 minecraft:bone_block
fill 531 151 526 531 151 527 minecraft:light_blue_concrete
fill 531 151 531 531 151 532 minecraft:light_blue_concrete
fill 532 151 525 532 152 525 minecraft:light_blue_concrete
fill 532 151 533 532 152 533 minecraft:light_blue_concrete
fill 533 151 519 533 152 519 minecraft:bone_block
fill 533 151 524 533 152 524 minecraft:light_blue_concrete
fill 533 151 528 534 152 533 minecraft:blue_concrete
fill 533 151 534 533 152 534 minecraft:light_blue_concrete
fill 533 151 535 533 152 535 minecraft:bone_block
fill 534 151 523 535 151 523 minecraft:light_blue_concrete
setblock 534 151 534 minecraft:blue_concrete
fill 534 151 535 535 151 535 minecraft:light_blue_concrete
fill 535 151 524 535 152 526 minecraft:blue_concrete
fill 536 151 519 536 152 519 minecraft:bone_block
fill 536 151 522 538 151 522 minecraft:light_blue_concrete
fill 536 151 523 538 151 525 minecraft:blue_concrete
fill 536 151 535 536 152 535 minecraft:bone_block
setblock 536 151 536 minecraft:light_blue_concrete
fill 537 151 526 537 153 526 minecraft:blue_concrete
fill 537 151 528 537 154 528 minecraft:blue_concrete
fill 537 151 535 538 151 535 minecraft:blue_concrete
fill 539 151 519 539 152 519 minecraft:bone_block
fill 539 151 523 540 151 523 minecraft:light_blue_concrete
fill 539 151 524 539 152 524 minecraft:blue_concrete
fill 539 151 535 539 152 535 minecraft:bone_block
setblock 540 151 535 minecraft:light_blue_concrete
fill 541 151 524 541 152 524 minecraft:light_blue_concrete
fill 541 151 534 541 152 534 minecraft:light_blue_concrete
fill 542 151 519 542 152 519 minecraft:bone_block
fill 542 151 525 542 152 525 minecraft:light_blue_concrete
fill 542 151 533 542 152 533 minecraft:light_blue_concrete
fill 542 151 535 542 152 535 minecraft:bone_block
fill 543 151 526 543 151 527 minecraft:light_blue_concrete
fill 543 151 531 543 151 532 minecraft:light_blue_concrete
fill 545 151 519 545 152 519 minecraft:bone_block
fill 545 151 535 545 152 535 minecraft:bone_block
fill 546 151 552 548 153 552 minecraft:blue_concrete
setblock 549 151 552 minecraft:shroomlight
fill 550 151 552 552 172 552 minecraft:blue_concrete
setblock 554 151 552 minecraft:shroomlight
setblock 559 151 530 minecraft:shroomlight
setblock 517 152 550 minecraft:magma_block
fill 531 152 527 531 152 531 minecraft:light_blue_concrete
setblock 532 152 526 minecraft:light_blue_concrete
setblock 532 152 532 minecraft:light_blue_concrete
setblock 534 152 524 minecraft:light_blue_concrete
setblock 534 152 534 minecraft:light_blue_concrete
fill 534 152 542 538 154 546 minecraft:blackstone
fill 535 152 523 539 152 523 minecraft:light_blue_concrete
setblock 535 152 535 minecraft:light_blue_concrete
fill 536 152 524 538 152 525 minecraft:blue_concrete
fill 536 152 547 536 154 547 minecraft:blackstone
fill 537 152 535 538 152 535 minecraft:light_blue_concrete
fill 539 152 528 541 152 532 minecraft:blue_concrete
fill 539 152 544 539 154 544 minecraft:blackstone
setblock 540 152 524 minecraft:light_blue_concrete
setblock 540 152 534 minecraft:light_blue_concrete
setblock 542 152 526 minecraft:light_blue_concrete
fill 542 152 528 542 152 531 minecraft:blue_concrete
setblock 542 152 532 minecraft:light_blue_concrete
fill 543 152 527 543 152 531 minecraft:light_blue_concrete
fill 549 152 552 549 217 552 minecraft:blue_concrete
fill 551 152 525 551 153 525 minecraft:magma_block
fill 554 152 552 554 178 552 minecraft:blue_concrete
fill 559 152 530 559 188 530 minecraft:blue_concrete
setblock 517 153 550 minecraft:blue_concrete
fill 527 153 520 527 154 520 minecraft:bone_block
fill 527 153 534 527 154 534 minecraft:bone_block
fill 530 153 520 530 154 520 minecraft:bone_block
fill 530 153 534 530 154 534 minecraft:bone_block
fill 532 153 527 532 153 531 minecraft:light_blue_concrete
fill 533 153 520 533 154 520 minecraft:bone_block
fill 533 153 525 533 153 526 minecraft:light_blue_concrete
fill 533 153 528 534 153 531 minecraft:blue_concrete
fill 533 153 532 533 153 533 minecraft:light_blue_concrete
fill 533 153 534 533 154 534 minecraft:bone_block
fill 533 153 543 533 154 545 minecraft:blackstone
setblock 534 153 525 minecraft:light_blue_concrete
fill 534 153 526 534 153 527 minecraft:blue_concrete
fill 534 153 532 537 153 532 minecraft:blue_concrete
setblock 534 153 533 minecraft:light_blue_concrete
fill 535 153 524 539 153 524 minecraft:light_blue_concrete
fill 535 153 525 535 153 526 minecraft:blue_concrete
fill 535 153 529 537 153 531 minecraft:blue_concrete
fill 535 153 533 539 153 533 minecraft:blue_concrete
setblock 535 153 534 minecraft:light_blue_concrete
fill 535 153 541 537 154 541 minecraft:blackstone
fill 535 153 547 535 154 547 minecraft:blackstone
fill 536 153 520 536 154 520 minecraft:bone_block
fill 536 153 525 538 153 525 minecraft:blue_concrete
fill 536 153 534 536 154 534 minecraft:bone_block
fill 537 153 534 538 153 534 minecraft:light_blue_concrete
fill 537 153 547 537 154 547 minecraft:blackstone
fill 539 153 520 539 154 520 minecraft:bone_block
fill 539 153 528 540 153 532 minecraft:blue_concrete
fill 539 153 534 539 154 534 minecraft:bone_block
fill 539 153 543 539 154 543 minecraft:blackstone
fill 539 153 545 539 154 545 minecraft:blackstone
fill 540 153 525 541 153 525 minecraft:light_blue_concrete
fill 540 153 533 541 153 533 minecraft:light_blue_concrete
setblock 541 153 526 minecraft:light_blue_concrete
fill 541 153 528 541 153 531 minecraft:blue_concrete
setblock 541 153 532 minecraft:light_blue_concrete
fill 542 153 520 542 154 520 minecraft:bone_block
fill 542 153 528 542 153 531 minecraft:light_blue_concrete
fill 542 153 534 542 154 534 minecraft:bone_block
fill 545 153 520 545 154 520 minecraft:bone_block
fill 545 153 534 545 154 534 minecraft:bone_block
fill 548 153 526 549 159 529 minecraft:bone_block
fill 550 153 526 550 160 527 minecraft:bone_block
setblock 559 153 520 minecraft:magma_block
fill 559 153 521 559 164 522 minecraft:blue_concrete
fill 559 153 533 559 219 533 minecraft:blue_concrete
setblock 559 153 534 minecraft:white_concrete
setblock 559 153 545 minecraft:shroomlight
fill 517 154 518 517 155 518 minecraft:orange_concrete
fill 517 154 534 517 155 534 minecraft:orange_concrete
fill 517 154 550 517 155 550 minecraft:orange_concrete
fill 521 154 510 521 155 510 minecraft:orange_concrete
fill 527 154 521 527 156 521 minecraft:bone_block
fill 527 154 533 527 156 533 minecraft:bone_block
fill 530 154 521 530 156 521 minecraft:bone_block
fill 530 154 533 530 156 533 minecraft:bone_block
fill 530 154 552 530 221 552 minecraft:blue_concrete
fill 531 154 552 531 155 552 minecraft:orange_concrete
fill 532 154 552 534 178 552 minecraft:blue_concrete
fill 533 154 521 533 156 521 minecraft:bone_block
fill 533 154 528 534 154 531 minecraft:light_blue_concrete
fill 533 154 533 533 156 533 minecraft:bone_block
setblock 533 154 542 minecraft:blackstone
setblock 533 154 546 minecraft:blackstone
fill 534 154 526 534 154 527 minecraft:light_blue_concrete
fill 534 154 532 540 154 532 minecraft:light_blue_concrete
setblock 534 154 541 minecraft:blackstone
setblock 534 154 547 minecraft:blackstone
fill 535 154 525 535 154 526 minecraft:light_blue_concrete
fill 535 154 529 539 154 530 minecraft:blue_concrete
setblock 535 154 531 minecraft:light_blue_concrete
setblock 535 154 533 minecraft:light_blue_concrete
fill 536 154 521 536 156 521 minecraft:bone_block
fill 536 154 525 539 154 525 minecraft:light_blue_concrete
fill 536 154 531 538 154 531 minecraft:blue_concrete
fill 536 154 533 536 156 533 minecraft:bone_block
fill 537 154 510 537 155 510 minecraft:orange_concrete
fill 537 154 526 540 154 526 minecraft:light_blue_concrete
fill 537 154 533 538 154 533 minecraft:light_blue_concrete
fill 538 154 527 538 154 528 minecraft:blue_concrete
setblock 538 154 541 minecraft:blackstone
setblock 538 154 547 minecraft:blackstone
fill 539 154 521 539 156 521 minecraft:bone_block
setblock 539 154 528 minecraft:blue_concrete
fill 539 154 531 541 154 531 minecraft:light_blue_concrete
fill 539 154 533 539 156 533 minecraft:bone_block
setblock 539 154 542 minecraft:blackstone
setblock 539 154 546 minecraft:blackstone
fill 540 154 527 541 154 530 minecraft:light_blue_concrete
setblock 540 154 544 minecraft:blackstone
fill 542 154 521 542 156 521 minecraft:bone_block
fill 542 154 533 542 156 533 minecraft:bone_block
fill 545 154 510 547 221 510 minecraft:blue_concrete
fill 545 154 521 545 156 521 minecraft:bone_block
fill 545 154 533 545 156 533 minecraft:bone_block
fill 546 154 526 547 158 526 minecraft:bone_block
fill 546 154 528 547 158 528 minecraft:bone_block
fill 546 154 552 546 174 552 minecraft:blue_concrete
fill 547 154 527 547 159 527 minecraft:bone_block
fill 547 154 529 547 159 529 minecraft:bone_block
fill 547 154 552 547 155 552 minecraft:orange_concrete
setblock 548 154 510 minecraft:white_concrete
fill 548 154 525 551 159 525 minecraft:bone_block
fill 548 154 530 550 158 530 minecraft:bone_block
fill 548 154 552 548 190 552 minecraft:blue_concrete
fill 549 154 510 551 219 510 minecraft:blue_concrete
fill 549 154 524 550 158 524 minecraft:bone_block
fill 550 154 528 551 159 529 minecraft:bone_block
fill 551 154 526 551 160 527 minecraft:bone_block
fill 553 154 510 553 155 510 minecraft:orange_concrete
fill 554 154 510 555 169 510 minecraft:blue_concrete
fill 559 154 520 559 155 520 minecraft:orange_concrete
fill 559 154 534 559 171 534 minecraft:blue_concrete
fill 559 154 536 559 155 536 minecraft:orange_concrete
fill 559 154 545 559 204 545 minecraft:blue_concrete
fill 527 155 526 527 158 526 minecraft:bone_block
fill 527 155 528 527 158 528 minecraft:bone_block
fill 528 155 528 528 156 528 minecraft:red_terracotta
fill 530 155 526 530 158 526 minecraft:bone_block
fill 530 155 528 530 158 528 minecraft:bone_block
fill 533 155 526 533 158 526 minecraft:bone_block
fill 533 155 528 533 158 528 minecraft:bone_block
fill 535 155 529 539 155 530 minecraft:light_blue_concrete
fill 535 155 544 537 155 544 minecraft:magma_block
fill 536 155 531 538 155 531 minecraft:light_blue_concrete
setblock 536 155 543 minecraft:magma_block
fill 536 155 545 536 156 545 minecraft:magma_block
fill 537 155 528 538 155 528 minecraft:light_blue_concrete
setblock 537 155 543 minecraft:red_terracotta
setblock 538 155 527 minecraft:light_blue_concrete
setblock 538 155 544 minecraft:red_terracotta
fill 539 155 526 539 158 526 minecraft:bone_block
fill 539 155 528 539 158 528 minecraft:bone_block
fill 542 155 526 542 158 526 minecraft:bone_block
fill 542 155 528 542 158 528 minecraft:bone_block
fill 545 155 526 545 158 526 minecraft:bone_block
fill 545 155 528 545 158 528 minecraft:bone_block
fill 546 155 525 547 158 525 minecraft:bone_block
fill 546 155 527 546 159 527 minecraft:bone_block
fill 546 155 529 546 158 529 minecraft:bone_block
fill 547 155 530 547 157 530 minecraft:bone_block
setblock 548 155 510 minecraft:magma_block
fill 548 155 524 548 159 524 minecraft:bone_block
fill 551 155 524 551 157 524 minecraft:bone_block
fill 551 155 530 551 158 530 minecraft:bone_block
fill 552 155 526 552 158 529 minecraft:bone_block
fill 517 156 518 517 161 518 minecraft:blue_concrete
fill 517 156 534 517 161 534 minecraft:blue_concrete
fill 517 156 550 517 161 550 minecraft:blue_concrete
fill 521 156 510 521 161 510 minecraft:blue_concrete
fill 527 156 522 527 157 522 minecraft:bone_block
fill 527 156 532 527 157 532 minecraft:bone_block
fill 530 156 522 530 157 522 minecraft:bone_block
fill 530 156 532 530 157 532 minecraft:bone_block
fill 531 156 552 531 161 552 minecraft:blue_concrete
fill 533 156 522 533 157 522 minecraft:bone_block
fill 533 156 532 533 157 532 minecraft:bone_block
fill 536 156 522 536 157 522 minecraft:bone_block
fill 536 156 526 536 158 526 minecraft:bone_block
fill 536 156 532 536 157 532 minecraft:bone_block
fill 536 156 544 537 156 544 minecraft:magma_block
fill 537 156 510 537 161 510 minecraft:blue_concrete
fill 539 156 522 539 157 522 minecraft:bone_block
fill 539 156 532 539 157 532 minecraft:bone_block
fill 542 156 522 542 157 522 minecraft:bone_block
fill 542 156 532 542 157 532 minecraft:bone_block
fill 545 156 522 545 157 522 minecraft:bone_block
fill 545 156 532 545 157 532 minecraft:bone_block
fill 547 156 524 547 158 524 minecraft:bone_block
fill 547 156 552 547 161 552 minecraft:blue_concrete
fill 548 156 510 548 187 510 minecraft:blue_concrete
setblock 549 156 523 minecraft:bone_block
setblock 552 156 525 minecraft:bone_block
fill 552 156 530 552 157 530 minecraft:bone_block
fill 553 156 510 553 161 510 minecraft:blue_concrete
fill 559 156 520 559 161 520 minecraft:blue_concrete
fill 559 156 536 559 161 536 minecraft:blue_concrete
setblock 517 157 529 minecraft:magma_block
setblock 520 157 513 minecraft:light[level=14]
setblock 520 157 521 minecraft:light[level=14]
setblock 520 157 529 minecraft:light[level=14]
setblock 520 157 537 minecraft:light[level=14]
setblock 520 157 545 minecraft:light[level=14]
setblock 527 157 510 minecraft:magma_block
fill 527 157 523 527 158 523 minecraft:bone_block
fill 527 157 531 527 158 531 minecraft:bone_block
setblock 528 157 513 minecraft:light[level=14]
setblock 528 157 521 minecraft:light[level=14]
setblock 528 157 529 minecraft:light[level=14]
setblock 528 157 537 minecraft:light[level=14]
setblock 528 157 545 minecraft:light[level=14]
fill 530 157 523 530 158 523 minecraft:bone_block
fill 530 157 531 530 158 531 minecraft:bone_block
fill 533 157 523 533 158 523 minecraft:bone_block
fill 533 157 531 533 158 531 minecraft:bone_block
setblock 535 157 552 minecraft:white_concrete
setblock 536 157 513 minecraft:light[level=14]
setblock 536 157 521 minecraft:light[level=14]
fill 536 157 523 536 158 523 minecraft:bone_block
setblock 536 157 529 minecraft:light[level=14]
fill 536 157 531 536 158 531 minecraft:bone_block
setblock 536 157 537 minecraft:light[level=14]
fill 536 157 544 536 159 544 minecraft:magma_block
setblock 536 157 545 minecraft:light[level=14]
fill 539 157 523 539 158 523 minecraft:bone_block
fill 539 157 531 539 158 531 minecraft:bone_block
fill 542 157 523 542 158 523 minecraft:bone_block
fill 542 157 531 542 158 531 minecraft:bone_block
setblock 544 157 513 minecraft:light[level=14]
setblock 544 157 521 minecraft:light[level=14]
setblock 544 157 529 minecraft:light[level=14]
setblock 544 157 537 minecraft:light[level=14]
setblock 544 157 545 minecraft:light[level=14]
fill 545 157 523 545 158 523 minecraft:bone_block
fill 545 157 531 545 158 531 minecraft:bone_block
setblock 546 157 524 minecraft:bone_block
setblock 548 157 523 minecraft:bone_block
setblock 552 157 513 minecraft:light[level=14]
setblock 552 157 521 minecraft:light[level=14]
fill 552 157 524 552 164 525 minecraft:blackstone
setblock 552 157 537 minecraft:light[level=14]
setblock 552 157 545 minecraft:light[level=14]
setblock 553 157 528 minecraft:bone_block
fill 517 158 529 517 197 529 minecraft:blue_concrete
fill 525 158 527 534 159 527 minecraft:bone_block
fill 527 158 510 527 217 510 minecraft:blue_concrete
fill 527 158 524 527 158 525 minecraft:bone_block
fill 527 158 529 527 158 530 minecraft:bone_block
fill 530 158 524 530 158 525 minecraft:bone_block
fill 530 158 529 530 158 530 minecraft:bone_block
fill 533 158 524 533 158 525 minecraft:bone_block
fill 533 158 529 533 158 530 minecraft:bone_block
fill 535 158 552 535 221 552 minecraft:blue_concrete
fill 536 158 524 536 158 525 minecraft:bone_block
fill 536 158 529 536 158 530 minecraft:bone_block
fill 537 158 527 544 159 527 minecraft:bone_block
fill 539 158 524 539 158 525 minecraft:bone_block
fill 539 158 529 539 158 530 minecraft:bone_block
fill 542 158 524 542 158 525 minecraft:bone_block
fill 542 158 529 542 158 530 minecraft:bone_block
fill 545 158 524 545 158 525 minecraft:bone_block
fill 545 158 529 545 158 530 minecraft:bone_block
fill 551 158 524 551 164 524 minecraft:blackstone
fill 553 158 525 553 164 526 minecraft:blackstone
setblock 517 159 535 minecraft:white_concrete
fill 517 159 536 517 189 537 minecraft:blue_concrete
fill 547 159 525 547 159 526 minecraft:bone_block
setblock 547 159 528 minecraft:bone_block
fill 548 159 530 549 159 530 minecraft:bone_block
setblock 549 159 524 minecraft:bone_block
fill 550 159 523 550 164 524 minecraft:blackstone
fill 551 159 523 552 164 523 minecraft:blackstone
fill 552 159 526 552 159 528 minecraft:bone_block
fill 553 159 524 553 164 524 minecraft:blackstone
fill 553 159 527 553 164 527 minecraft:blackstone
fill 517 160 535 517 218 535 minecraft:blue_concrete
fill 548 160 525 548 164 526 minecraft:blackstone
fill 548 160 528 549 160 529 minecraft:bone_block
fill 549 160 523 549 164 525 minecraft:blackstone
fill 549 160 526 549 160 527 minecraft:bone_block
fill 550 160 525 551 164 525 minecraft:blackstone
fill 550 160 528 552 164 528 minecraft:blackstone
fill 552 160 526 552 164 527 minecraft:blackstone
fill 553 160 523 553 164 523 minecraft:blackstone
fill 554 160 525 554 164 526 minecraft:blackstone
fill 548 161 524 548 164 524 minecraft:blackstone
fill 548 161 527 551 164 527 minecraft:blackstone
fill 549 161 526 551 164 526 minecraft:blackstone
fill 549 161 528 549 164 528 minecraft:blackstone
fill 550 161 522 552 164 522 minecraft:blackstone
fill 551 161 529 551 164 529 minecraft:blackstone
fill 553 161 528 553 164 528 minecraft:blackstone
fill 554 161 524 554 164 524 minecraft:blackstone
fill 554 161 527 554 164 527 minecraft:blackstone
setblock 559 161 529 minecraft:shroomlight
fill 517 162 511 517 167 511 minecraft:blue_concrete
setblock 517 162 512 minecraft:magma_block
fill 517 162 513 517 162 517 minecraft:blue_concrete
fill 517 162 518 517 164 518 minecraft:orange_concrete
fill 517 162 534 517 164 534 minecraft:orange_concrete
fill 517 162 550 517 164 550 minecraft:orange_concrete
fill 521 162 510 521 164 510 minecraft:orange_concrete
fill 531 162 552 531 164 552 minecraft:orange_concrete
setblock 534 162 510 minecraft:white_concrete
fill 535 162 510 535 216 510 minecraft:blue_concrete
fill 537 162 510 537 164 510 minecraft:orange_concrete
fill 547 162 525 547 164 526 minecraft:blackstone
fill 547 162 552 547 164 552 minecraft:orange_concrete
fill 548 162 523 548 164 523 minecraft:blackstone
fill 548 162 528 548 164 528 minecraft:blackstone
fill 549 162 522 549 164 522 minecraft:blackstone
fill 549 162 529 550 164 529 minecraft:blackstone
fill 552 162 529 553 164 529 minecraft:blackstone
fill 553 162 510 553 164 510 minecraft:orange_concrete
fill 553 162 522 553 164 522 minecraft:blackstone
fill 554 162 523 554 164 523 minecraft:blackstone
fill 554 162 528 554 164 528 minecraft:blackstone
fill 555 162 524 555 164 526 minecraft:blackstone
fill 559 162 520 559 164 520 minecraft:orange_concrete
fill 559 162 529 559 199 529 minecraft:blue_concrete
fill 559 162 536 559 164 536 minecraft:orange_concrete
fill 517 163 512 517 172 514 minecraft:blue_concrete
setblock 517 163 515 minecraft:white_concrete
fill 517 163 516 517 221 517 minecraft:blue_concrete
fill 517 163 539 517 219 539 minecraft:blue_concrete
setblock 517 163 540 minecraft:shroomlight
fill 517 163 541 517 192 541 minecraft:blue_concrete
setblock 517 163 548 minecraft:white_concrete
fill 517 163 549 517 221 549 minecraft:blue_concrete
fill 534 163 510 534 221 510 minecraft:blue_concrete
fill 547 163 523 547 164 524 minecraft:blackstone
fill 547 163 527 547 164 527 minecraft:blackstone
fill 548 163 522 548 164 522 minecraft:blackstone
fill 548 163 529 548 164 529 minecraft:blackstone
fill 550 163 521 552 164 521 minecraft:blackstone
fill 551 163 530 551 164 530 minecraft:blackstone
fill 554 163 522 554 164 522 minecraft:blackstone
fill 554 163 529 554 164 529 minecraft:blackstone
fill 555 163 523 555 164 523 minecraft:blackstone
fill 555 163 527 555 164 527 minecraft:blackstone
setblock 559 163 519 minecraft:magma_block
fill 517 164 510 517 221 510 minecraft:blue_concrete
fill 517 164 515 517 221 515 minecraft:blue_concrete
fill 517 164 540 517 218 540 minecraft:blue_concrete
setblock 517 164 543 minecraft:shroomlight
fill 517 164 548 517 218 548 minecraft:blue_concrete
setblock 518 164 510 minecraft:magma_block
fill 518 164 552 519 221 552 minecraft:blue_concrete
setblock 520 164 552 minecraft:shroomlight
setblock 522 164 510 minecraft:shroomlight
setblock 529 164 510 minecraft:shroomlight
fill 546 164 524 546 164 526 minecraft:blackstone
setblock 547 164 528 minecraft:blackstone
setblock 549 164 521 minecraft:blackstone
fill 549 164 530 550 164 530 minecraft:blackstone
fill 552 164 530 553 164 530 minecraft:blackstone
setblock 553 164 521 minecraft:blackstone
setblock 555 164 528 minecraft:blackstone
fill 556 164 524 556 164 526 minecraft:blackstone
fill 559 164 519 559 176 519 minecraft:blue_concrete
setblock 559 164 549 minecraft:magma_block
fill 517 165 518 517 170 518 minecraft:blue_concrete
fill 517 165 534 517 170 534 minecraft:blue_concrete
setblock 517 165 543 minecraft:magma_block
fill 517 165 550 517 170 550 minecraft:blue_concrete
fill 518 165 510 518 172 510 minecraft:blue_concrete
setblock 520 165 513 minecraft:light[level=14]
setblock 520 165 521 minecraft:light[level=14]
setblock 520 165 529 minecraft:light[level=14]
setblock 520 165 537 minecraft:light[level=14]
setblock 520 165 545 minecraft:light[level=14]
fill 520 165 552 520 195 552 minecraft:blue_concrete
fill 521 165 510 522 170 510 minecraft:blue_concrete
setblock 524 165 552 minecraft:magma_block
fill 525 165 552 529 193 552 minecraft:blue_concrete
setblock 528 165 513 minecraft:light[level=14]
setblock 528 165 521 minecraft:light[level=14]
setblock 528 165 529 minecraft:light[level=14]
setblock 528 165 537 minecraft:light[level=14]
setblock 528 165 545 minecraft:light[level=14]
fill 529 165 510 529 176 510 minecraft:blue_concrete
fill 531 165 552 531 170 552 minecraft:blue_concrete
setblock 536 165 513 minecraft:light[level=14]
setblock 536 165 521 minecraft:light[level=14]
setblock 536 165 537 minecraft:light[level=14]
setblock 536 165 545 minecraft:light[level=14]
fill 537 165 510 537 168 510 minecraft:blue_concrete
setblock 544 165 513 minecraft:light[level=14]
setblock 544 165 521 minecraft:light[level=14]
setblock 544 165 529 minecraft:light[level=14]
setblock 544 165 537 minecraft:light[level=14]
setblock 544 165 545 minecraft:light[level=14]
fill 547 165 552 547 166 552 minecraft:blue_concrete
fill 550 165 525 552 165 526 minecraft:magma_block
setblock 552 165 513 minecraft:light[level=14]
setblock 552 165 521 minecraft:light[level=14]
setblock 552 165 529 minecraft:light[level=14]
setblock 552 165 537 minecraft:light[level=14]
setblock 552 165 545 minecraft:light[level=14]
fill 553 165 510 553 170 510 minecraft:blue_concrete
fill 559 165 520 559 170 521 minecraft:blue_concrete
setblock 559 165 522 minecraft:shroomlight
fill 559 165 536 559 170 536 minecraft:blue_concrete
setblock 559 165 549 minecraft:blue_concrete
setblock 517 166 532 minecraft:white_concrete
fill 517 166 533 517 223 533 minecraft:blue_concrete
fill 517 166 543 517 218 543 minecraft:blue_concrete
setblock 517 166 544 minecraft:shroomlight
setblock 520 166 510 minecraft:magma_block
fill 524 166 552 524 221 552 minecraft:blue_concrete
setblock 540 166 510 minecraft:white_concrete
fill 541 166 510 544 213 510 minecraft:blue_concrete
fill 551 166 525 551 167 526 minecraft:magma_block
fill 556 166 552 556 221 552 minecraft:blue_concrete
setblock 557 166 552 minecraft:white_concrete
fill 558 166 552 559 211 552 minecraft:blue_concrete
fill 559 166 522 559 221 522 minecraft:blue_concrete
setblock 559 166 549 minecraft:white_concrete
fill 517 167 532 517 171 532 minecraft:blue_concrete
fill 517 167 544 517 182 544 minecraft:blue_concrete
fill 520 167 510 520 221 510 minecraft:blue_concrete
fill 540 167 510 540 203 510 minecraft:blue_concrete
setblock 547 167 552 minecraft:magma_block
fill 557 167 552 557 195 552 minecraft:blue_concrete
setblock 559 167 516 minecraft:magma_block
setblock 559 167 526 minecraft:white_concrete
fill 559 167 549 559 213 549 minecraft:blue_concrete
setblock 517 168 511 minecraft:magma_block
fill 533 168 543 534 169 544 minecraft:magma_block
fill 547 168 552 547 170 552 minecraft:blue_concrete
setblock 551 168 525 minecraft:magma_block
fill 559 168 516 559 215 516 minecraft:blue_concrete
fill 559 168 526 559 172 526 minecraft:blue_concrete
fill 517 169 511 517 224 511 minecraft:blue_concrete
setblock 517 169 542 minecraft:shroomlight
setblock 537 169 510 minecraft:shroomlight
setblock 538 169 510 minecraft:magma_block
setblock 544 169 552 minecraft:shroomlight
setblock 559 169 512 minecraft:white_concrete
fill 517 170 542 517 207 542 minecraft:blue_concrete
fill 537 170 510 538 170 510 minecraft:blue_concrete
setblock 539 170 552 minecraft:magma_block
fill 544 170 552 544 194 552 minecraft:blue_concrete
setblock 554 170 510 minecraft:magma_block
fill 555 170 510 555 201 510 minecraft:blue_concrete
fill 559 170 512 559 172 512 minecraft:blue_concrete
fill 559 170 517 559 221 517 minecraft:blue_concrete
setblock 559 170 518 minecraft:magma_block
fill 517 171 518 517 173 518 minecraft:orange_concrete
fill 517 171 534 517 173 534 minecraft:orange_concrete
setblock 517 171 538 minecraft:white_concrete
fill 517 171 550 517 173 550 minecraft:orange_concrete
fill 521 171 510 521 173 510 minecraft:orange_concrete
fill 522 171 510 522 193 510 minecraft:blue_concrete
fill 531 171 552 531 173 552 minecraft:orange_concrete
fill 537 171 510 537 173 510 minecraft:orange_concrete
fill 538 171 510 538 221 510 minecraft:blue_concrete
fill 539 171 552 539 221 552 minecraft:blue_concrete
fill 547 171 552 547 173 552 minecraft:orange_concrete
fill 553 171 510 553 173 510 minecraft:orange_concrete
fill 554 171 510 554 213 510 minecraft:blue_concrete
setblock 559 171 511 minecraft:shroomlight
fill 559 171 518 559 177 518 minecraft:blue_concrete
fill 559 171 520 559 173 520 minecraft:orange_concrete
fill 559 171 521 559 194 521 minecraft:blue_concrete
fill 559 171 536 559 173 536 minecraft:orange_concrete
setblock 559 171 544 minecraft:magma_block
setblock 517 172 532 minecraft:white_concrete
fill 517 172 538 517 182 538 minecraft:blue_concrete
fill 559 172 511 559 221 511 minecraft:blue_concrete
setblock 559 172 534 minecraft:magma_block
fill 559 172 544 559 221 544 minecraft:blue_concrete
fill 517 173 512 517 218 513 minecraft:blue_concrete
setblock 517 173 514 minecraft:magma_block
fill 517 173 532 517 221 532 minecraft:blue_concrete
setblock 518 173 510 minecraft:shroomlight
setblock 520 173 513 minecraft:light[level=14]
setblock 520 173 521 minecraft:light[level=14]
setblock 520 173 529 minecraft:light[level=14]
setblock 520 173 537 minecraft:light[level=14]
setblock 520 173 545 minecraft:light[level=14]
setblock 528 173 513 minecraft:light[level=14]
setblock 528 173 521 minecraft:light[level=14]
setblock 528 173 529 minecraft:light[level=14]
setblock 528 173 537 minecraft:light[level=14]
setblock 528 173 545 minecraft:light[level=14]
setblock 536 173 513 minecraft:light[level=14]
setblock 536 173 521 minecraft:light[level=14]
setblock 536 173 537 minecraft:light[level=14]
setblock 536 173 545 minecraft:light[level=14]
setblock 544 173 513 minecraft:light[level=14]
setblock 544 173 521 minecraft:light[level=14]
setblock 544 173 529 minecraft:light[level=14]
setblock 544 173 537 minecraft:light[level=14]
setblock 544 173 545 minecraft:light[level=14]
fill 550 173 552 550 201 552 minecraft:blue_concrete
setblock 551 173 552 minecraft:shroomlight
setblock 552 173 513 minecraft:light[level=14]
setblock 552 173 521 minecraft:light[level=14]
setblock 552 173 529 minecraft:light[level=14]
setblock 552 173 537 minecraft:light[level=14]
setblock 552 173 545 minecraft:light[level=14]
fill 552 173 552 552 185 552 minecraft:blue_concrete
setblock 559 173 512 minecraft:white_concrete
setblock 559 173 526 minecraft:magma_block
fill 559 173 534 559 179 534 minecraft:blue_concrete
fill 517 174 514 517 221 514 minecraft:blue_concrete
fill 517 174 518 517 179 518 minecraft:blue_concrete
fill 517 174 534 517 179 534 minecraft:blue_concrete
fill 517 174 550 517 179 550 minecraft:blue_concrete
fill 518 174 510 518 186 510 minecraft:blue_concrete
fill 521 174 510 521 179 510 minecraft:blue_concrete
setblock 530 174 510 minecraft:magma_block
fill 531 174 552 531 179 552 minecraft:blue_concrete
fill 537 174 510 537 179 510 minecraft:blue_concrete
fill 547 174 552 547 179 552 minecraft:blue_concrete
fill 551 174 552 551 204 552 minecraft:blue_concrete
fill 553 174 510 553 179 510 minecraft:blue_concrete
fill 559 174 512 559 221 512 minecraft:blue_concrete
fill 559 174 520 559 179 520 minecraft:blue_concrete
fill 559 174 526 559 221 526 minecraft:blue_concrete
fill 559 174 536 559 179 536 minecraft:blue_concrete
fill 530 175 510 530 219 510 minecraft:blue_concrete
setblock 546 175 552 minecraft:white_concrete
fill 532 176 521 532 177 522 minecraft:magma_block
fill 546 176 552 546 181 552 minecraft:blue_concrete
fill 549 176 519 549 177 519 minecraft:magma_block
setblock 529 177 510 minecraft:magma_block
setblock 559 177 519 minecraft:shroomlight
setblock 559 177 541 minecraft:shroomlight
fill 529 178 510 529 221 510 minecraft:blue_concrete
fill 549 178 519 549 188 519 minecraft:blackstone
setblock 559 178 518 minecraft:shroomlight
fill 559 178 519 559 200 519 minecraft:blue_concrete
setblock 559 178 537 minecraft:magma_block
fill 559 178 541 559 221 541 minecraft:blue_concrete
setblock 532 179 510 minecraft:shroomlight
setblock 532 179 552 minecraft:white_concrete
fill 533 179 552 534 191 552 minecraft:blue_concrete
fill 548 179 519 548 188 520 minecraft:blackstone
fill 549 179 520 549 188 520 minecraft:blackstone
setblock 554 179 552 minecraft:shroomlight
fill 559 179 518 559 221 518 minecraft:blue_concrete
fill 559 179 537 559 217 537 minecraft:blue_concrete
fill 517 180 518 517 182 518 minecraft:orange_concrete
fill 517 180 534 517 182 534 minecraft:orange_concrete
fill 517 180 550 517 182 550 minecraft:orange_concrete
fill 521 180 510 521 182 510 minecraft:orange_concrete
fill 531 180 552 531 182 552 minecraft:orange_concrete
fill 532 180 510 532 194 510 minecraft:blue_concrete
fill 532 180 552 532 196 552 minecraft:blue_concrete
fill 537 180 510 537 182 510 minecraft:orange_concrete
fill 547 180 552 547 182 552 minecraft:orange_concrete
fill 548 180 518 549 188 518 minecraft:blackstone
fill 550 180 519 550 188 520 minecraft:blackstone
fill 553 180 510 553 182 510 minecraft:orange_concrete
fill 554 180 552 554 185 552 minecraft:blue_concrete
fill 559 180 520 559 182 520 minecraft:orange_concrete
setblock 559 180 534 minecraft:shroomlight
fill 559 180 536 559 182 536 minecraft:orange_concrete
setblock 520 181 513 minecraft:light[level=14]
setblock 520 181 521 minecraft:light[level=14]
setblock 520 181 529 minecraft:light[level=14]
setblock 520 181 537 minecraft:light[level=14]
setblock 520 181 545 minecraft:light[level=14]
setblock 528 181 513 minecraft:light[level=14]
setblock 528 181 521 minecraft:light[level=14]
setblock 528 181 529 minecraft:light[level=14]
setblock 528 181 537 minecraft:light[level=14]
setblock 528 181 545 minecraft:light[level=14]
setblock 536 181 510 minecraft:magma_block
setblock 536 181 513 minecraft:light[level=14]
setblock 536 181 521 minecraft:light[level=14]
setblock 536 181 537 minecraft:light[level=14]
setblock 536 181 545 minecraft:light[level=14]
setblock 536 181 552 minecraft:shroomlight
fill 537 181 552 537 221 552 minecraft:blue_concrete
setblock 544 181 513 minecraft:light[level=14]
setblock 544 181 521 minecraft:light[level=14]
setblock 544 181 529 minecraft:light[level=14]
setblock 544 181 537 minecraft:light[level=14]
setblock 544 181 545 minecraft:light[level=14]
fill 547 181 519 547 188 520 minecraft:blackstone
fill 548 181 521 549 188 521 minecraft:blackstone
fill 550 181 518 550 188 518 minecraft:blackstone
setblock 552 181 510 minecraft:white_concrete
setblock 552 181 513 minecraft:light[level=14]
setblock 552 181 521 minecraft:light[level=14]
setblock 552 181 529 minecraft:light[level=14]
setblock 552 181 537 minecraft:light[level=14]
setblock 552 181 545 minecraft:light[level=14]
fill 559 181 523 559 215 523 minecraft:blue_concrete
setblock 559 181 524 minecraft:magma_block
fill 559 181 531 559 222 531 minecraft:blue_concrete
setblock 559 181 532 minecraft:magma_block
fill 559 181 534 559 219 534 minecraft:blue_concrete
fill 517 182 521 517 221 521 minecraft:blue_concrete
setblock 517 182 522 minecraft:shroomlight
fill 517 182 523 517 218 523 minecraft:blue_concrete
fill 536 182 510 536 221 510 minecraft:blue_concrete
fill 536 182 552 536 212 552 minecraft:blue_concrete
setblock 542 182 552 minecraft:magma_block
fill 543 182 552 543 198 552 minecraft:blue_concrete
setblock 546 182 552 minecraft:magma_block
fill 547 182 518 547 188 518 minecraft:blackstone
fill 547 182 521 547 188 521 minecraft:blackstone
fill 548 182 517 549 188 517 minecraft:blackstone
fill 550 182 521 550 188 521 minecraft:blackstone
fill 551 182 519 551 188 520 minecraft:blackstone
fill 552 182 510 552 222 510 minecraft:blue_concrete
fill 559 182 524 559 221 524 minecraft:blue_concrete
setblock 559 182 527 minecraft:shroomlight
fill 559 182 532 559 209 532 minecraft:blue_concrete
fill 517 183 518 517 188 518 minecraft:blue_concrete
fill 517 183 522 517 206 522 minecraft:blue_concrete
fill 517 183 534 517 188 534 minecraft:blue_concrete
setblock 517 183 538 minecraft:magma_block
setblock 517 183 544 minecraft:white_concrete
fill 517 183 550 517 188 550 minecraft:blue_concrete
fill 521 183 510 521 186 510 minecraft:blue_concrete
fill 526 183 523 527 184 523 minecraft:blackstone
fill 531 183 552 531 188 552 minecraft:blue_concrete
fill 537 183 510 537 188 510 minecraft:blue_concrete
fill 542 183 552 542 221 552 minecraft:blue_concrete
fill 546 183 519 546 188 520 minecraft:blackstone
fill 546 183 552 547 188 552 minecraft:blue_concrete
fill 547 183 517 547 188 517 minecraft:blackstone
fill 548 183 522 549 188 522 minecraft:blackstone
fill 550 183 517 550 188 517 minecraft:blackstone
fill 551 183 518 551 188 518 minecraft:blackstone
fill 551 183 521 551 188 521 minecraft:blackstone
fill 553 183 510 553 188 510 minecraft:blue_concrete
fill 559 183 520 559 188 520 minecraft:blue_concrete
fill 559 183 527 559 221 527 minecraft:blue_concrete
fill 559 183 536 559 188 536 minecraft:blue_concrete
fill 517 184 538 517 202 538 minecraft:blue_concrete
setblock 517 184 544 minecraft:magma_block
setblock 539 184 510 minecraft:magma_block
fill 546 184 518 546 188 518 minecraft:blackstone
fill 546 184 521 546 188 521 minecraft:blackstone
fill 547 184 522 547 188 522 minecraft:blackstone
fill 548 184 516 549 188 516 minecraft:blackstone
fill 550 184 522 550 188 522 minecraft:blackstone
fill 551 184 517 551 188 517 minecraft:blackstone
fill 552 184 519 552 188 520 minecraft:blackstone
fill 553 184 539 554 185 540 minecraft:blackstone
fill 517 185 544 517 186 544 minecraft:blue_concrete
fill 539 185 510 539 197 510 minecraft:blue_concrete
fill 545 185 518 545 188 520 minecraft:blackstone
fill 546 185 517 546 188 517 minecraft:blackstone
fill 546 185 522 546 188 522 minecraft:blackstone
fill 547 185 516 547 188 516 minecraft:blackstone
fill 548 185 523 550 188 523 minecraft:blackstone
fill 550 185 516 550 188 516 minecraft:blackstone
fill 551 185 522 551 188 522 minecraft:blackstone
fill 552 185 518 552 188 518 minecraft:blackstone
fill 552 185 521 552 188 521 minecraft:blackstone
fill 541 186 539 541 187 539 minecraft:blackstone
fill 545 186 517 545 188 517 minecraft:blackstone
fill 545 186 521 545 188 521 minecraft:blackstone
fill 546 186 516 546 188 516 minecraft:blackstone
fill 547 186 523 547 188 523 minecraft:blackstone
fill 548 186 515 549 188 515 minecraft:blackstone
fill 551 186 516 551 188 516 minecraft:blackstone
fill 551 186 523 551 188 523 minecraft:blackstone
fill 552 186 517 552 188 517 minecraft:blackstone
fill 552 186 522 552 188 522 minecraft:blackstone
setblock 552 186 552 minecraft:shroomlight
fill 553 186 519 553 188 520 minecraft:blackstone
setblock 554 186 552 minecraft:magma_block
setblock 517 187 544 minecraft:magma_block
setblock 518 187 510 minecraft:magma_block
setblock 521 187 510 minecraft:magma_block
fill 544 187 518 544 188 520 minecraft:blackstone
fill 545 187 522 545 188 522 minecraft:blackstone
fill 546 187 523 546 188 523 minecraft:blackstone
fill 547 187 515 547 188 515 minecraft:blackstone
fill 548 187 524 550 188 524 minecraft:blackstone
fill 550 187 515 551 188 515 minecraft:blackstone
fill 552 187 516 552 188 516 minecraft:blackstone
fill 552 187 552 552 211 552 minecraft:blue_concrete
fill 553 187 517 553 188 518 minecraft:blackstone
fill 553 187 521 553 188 521 minecraft:blackstone
fill 554 187 552 554 197 552 minecraft:blue_concrete
fill 517 188 544 517 219 544 minecraft:blue_concrete
fill 518 188 510 518 221 510 minecraft:blue_concrete
setblock 521 188 510 minecraft:blue_concrete
setblock 544 188 517 minecraft:blackstone
fill 544 188 521 544 188 522 minecraft:blackstone
setblock 545 188 516 minecraft:blackstone
setblock 545 188 523 minecraft:blackstone
setblock 546 188 515 minecraft:blackstone
fill 546 188 524 547 188 524 minecraft:blackstone
setblock 548 188 510 minecraft:shroomlight
fill 548 188 514 549 188 514 minecraft:blackstone
setblock 551 188 524 minecraft:blackstone
setblock 552 188 515 minecraft:blackstone
setblock 552 188 523 minecraft:blackstone
setblock 553 188 516 minecraft:blackstone
setblock 553 188 522 minecraft:blackstone
fill 554 188 519 554 188 520 minecraft:blackstone
setblock 559 188 540 minecraft:magma_block
fill 517 189 518 517 191 518 minecraft:orange_concrete
fill 517 189 534 517 191 534 minecraft:orange_concrete
fill 517 189 546 517 221 546 minecraft:blue_concrete
setblock 517 189 547 minecraft:magma_block
fill 517 189 550 517 191 550 minecraft:orange_concrete
setblock 520 189 513 minecraft:light[level=14]
setblock 520 189 521 minecraft:light[level=14]
setblock 520 189 529 minecraft:light[level=14]
setblock 520 189 537 minecraft:light[level=14]
setblock 520 189 545 minecraft:light[level=14]
fill 521 189 510 521 191 510 minecraft:orange_concrete
setblock 528 189 513 minecraft:light[level=14]
setblock 528 189 521 minecraft:light[level=14]
setblock 528 189 529 minecraft:light[level=14]
setblock 528 189 537 minecraft:light[level=14]
setblock 528 189 545 minecraft:light[level=14]
fill 531 189 552 531 191 552 minecraft:orange_concrete
setblock 536 189 513 minecraft:light[level=14]
setblock 536 189 521 minecraft:light[level=14]
setblock 536 189 537 minecraft:light[level=14]
setblock 536 189 545 minecraft:light[level=14]
fill 537 189 510 537 191 510 minecraft:orange_concrete
setblock 544 189 513 minecraft:light[level=14]
setblock 544 189 521 minecraft:light[level=14]
setblock 544 189 529 minecraft:light[level=14]
setblock 544 189 537 minecraft:light[level=14]
setblock 544 189 545 minecraft:light[level=14]
fill 546 189 552 546 217 552 minecraft:blue_concrete
fill 547 189 552 547 191 552 minecraft:orange_concrete
fill 548 189 510 548 219 510 minecraft:blue_concrete
fill 548 189 519 549 190 520 minecraft:magma_block
setblock 552 189 513 minecraft:light[level=14]
setblock 552 189 521 minecraft:light[level=14]
setblock 552 189 529 minecraft:light[level=14]
setblock 552 189 537 minecraft:light[level=14]
setblock 552 189 545 minecraft:light[level=14]
fill 553 189 510 553 191 510 minecraft:orange_concrete
fill 559 189 520 559 191 520 minecraft:orange_concrete
setblock 559 189 530 minecraft:shroomlight
fill 559 189 536 559 191 536 minecraft:orange_concrete
fill 559 189 538 559 217 538 minecraft:blue_concrete
setblock 559 189 539 minecraft:shroomlight
fill 559 189 540 559 219 540 minecraft:blue_concrete
setblock 517 190 536 minecraft:white_concrete
fill 517 190 537 517 206 537 minecraft:blue_concrete
fill 517 190 547 517 219 547 minecraft:blue_concrete
setblock 522 190 552 minecraft:shroomlight
fill 559 190 530 559 196 530 minecraft:blue_concrete
fill 559 190 539 559 218 539 minecraft:blue_concrete
fill 517 191 536 517 193 536 minecraft:blue_concrete
fill 522 191 552 522 221 552 minecraft:blue_concrete
fill 523 191 528 523 192 528 minecraft:magma_block
fill 548 191 519 549 191 519 minecraft:magma_block
setblock 548 191 552 minecraft:magma_block
setblock 549 191 520 minecraft:magma_block
fill 517 192 518 517 197 518 minecraft:blue_concrete
fill 517 192 534 517 197 534 minecraft:blue_concrete
fill 517 192 550 517 197 550 minecraft:blue_concrete
fill 521 192 510 521 197 510 minecraft:blue_concrete
fill 531 192 552 531 197 552 minecraft:blue_concrete
fill 533 192 552 533 221 552 minecraft:blue_concrete
setblock 534 192 552 minecraft:magma_block
fill 537 192 510 537 196 510 minecraft:blue_concrete
fill 547 192 552 548 197 552 minecraft:blue_concrete
setblock 549 192 519 minecraft:magma_block
fill 553 192 510 553 197 510 minecraft:blue_concrete
fill 559 192 520 559 196 520 minecraft:blue_concrete
fill 559 192 536 559 197 536 minecraft:blue_concrete
setblock 517 193 541 minecraft:white_concrete
fill 523 193 528 523 203 528 minecraft:blackstone
fill 534 193 552 534 221 552 minecraft:blue_concrete
fill 550 193 523 550 195 523 minecraft:magma_block
setblock 517 194 536 minecraft:shroomlight
fill 517 194 541 517 221 541 minecraft:blue_concrete
setblock 522 194 510 minecraft:white_concrete
fill 523 194 527 523 203 527 minecraft:blackstone
fill 525 194 552 528 200 552 minecraft:blue_concrete
setblock 529 194 552 minecraft:shroomlight
setblock 559 194 525 minecraft:magma_block
fill 517 195 525 517 210 526 minecraft:blue_concrete
setblock 517 195 527 minecraft:white_concrete
setblock 517 195 530 minecraft:shroomlight
fill 517 195 536 517 221 536 minecraft:blue_concrete
fill 522 195 510 522 206 510 minecraft:blue_concrete
fill 524 195 527 524 203 528 minecraft:blackstone
fill 529 195 552 529 221 552 minecraft:blue_concrete
setblock 532 195 510 minecraft:magma_block
setblock 544 195 552 minecraft:shroomlight
setblock 559 195 521 minecraft:white_concrete
fill 559 195 525 559 204 525 minecraft:blue_concrete
setblock 559 195 546 minecraft:shroomlight
fill 517 196 527 517 219 527 minecraft:blue_concrete
fill 517 196 530 517 209 530 minecraft:blue_concrete
setblock 520 196 552 minecraft:white_concrete
fill 522 196 527 522 203 528 minecraft:blackstone
fill 523 196 526 523 203 526 minecraft:blackstone
fill 523 196 529 524 203 529 minecraft:blackstone
fill 523 196 542 523 197 542 minecraft:blackstone
fill 532 196 510 532 221 510 minecraft:blue_concrete
fill 544 196 552 544 215 552 minecraft:blue_concrete
fill 550 196 523 550 205 524 minecraft:blackstone
setblock 557 196 552 minecraft:white_concrete
fill 559 196 521 559 206 521 minecraft:blue_concrete
fill 559 196 546 559 221 546 minecraft:blue_concrete
setblock 520 197 513 minecraft:light[level=14]
setblock 520 197 521 minecraft:light[level=14]
setblock 520 197 529 minecraft:light[level=14]
setblock 520 197 537 minecraft:light[level=14]
setblock 520 197 545 minecraft:light[level=14]
fill 520 197 552 520 221 552 minecraft:blue_concrete
fill 522 197 526 522 203 526 minecraft:blackstone
fill 522 197 529 522 203 529 minecraft:blackstone
fill 524 197 526 524 203 526 minecraft:blackstone
fill 525 197 527 525 203 529 minecraft:blackstone
setblock 528 197 513 minecraft:light[level=14]
setblock 528 197 521 minecraft:light[level=14]
setblock 528 197 529 minecraft:light[level=14]
setblock 528 197 537 minecraft:light[level=14]
setblock 528 197 545 minecraft:light[level=14]
setblock 532 197 552 minecraft:magma_block
setblock 536 197 513 minecraft:light[level=14]
setblock 536 197 521 minecraft:light[level=14]
setblock 536 197 537 minecraft:light[level=14]
setblock 536 197 545 minecraft:light[level=14]
setblock 537 197 510 minecraft:shroomlight
setblock 544 197 513 minecraft:light[level=14]
setblock 544 197 521 minecraft:light[level=14]
setblock 544 197 529 minecraft:light[level=14]
setblock 544 197 537 minecraft:light[level=14]
setblock 544 197 545 minecraft:light[level=14]
fill 551 197 523 551 205 524 minecraft:blackstone
setblock 552 197 513 minecraft:light[level=14]
setblock 552 197 521 minecraft:light[level=14]
setblock 552 197 529 minecraft:light[level=14]
setblock 552 197 537 minecraft:light[level=14]
setblock 552 197 545 minecraft:light[level=14]
setblock 556 197 510 minecraft:magma_block
fill 557 197 510 557 200 510 minecraft:blue_concrete
fill 557 197 552 557 211 552 minecraft:blue_concrete
setblock 559 197 520 minecraft:white_concrete
setblock 559 197 530 minecraft:shroomlight
fill 517 198 518 517 200 518 minecraft:orange_concrete
setblock 517 198 529 minecraft:white_concrete
fill 517 198 534 517 200 534 minecraft:orange_concrete
fill 517 198 550 517 200 550 minecraft:orange_concrete
fill 521 198 510 521 200 510 minecraft:orange_concrete
fill 521 198 527 521 203 529 minecraft:blackstone
fill 523 198 525 523 203 525 minecraft:blackstone
fill 523 198 530 524 203 530 minecraft:blackstone
fill 525 198 526 525 203 526 minecraft:blackstone
fill 531 198 552 531 200 552 minecraft:orange_concrete
fill 532 198 552 532 217 552 minecraft:blue_concrete
fill 537 198 510 537 200 510 minecraft:orange_concrete
setblock 539 198 510 minecraft:white_concrete
fill 547 198 552 547 200 552 minecraft:orange_concrete
fill 548 198 552 548 211 552 minecraft:blue_concrete
fill 549 198 523 549 205 524 minecraft:blackstone
fill 550 198 522 551 205 522 minecraft:blackstone
fill 550 198 525 551 205 525 minecraft:blackstone
fill 552 198 523 552 205 524 minecraft:blackstone
fill 553 198 510 553 200 510 minecraft:orange_concrete
setblock 554 198 552 minecraft:white_concrete
fill 556 198 510 556 221 510 minecraft:blue_concrete
fill 559 198 520 559 200 520 minecraft:orange_concrete
fill 559 198 530 559 221 530 minecraft:blue_concrete
fill 559 198 536 559 200 536 minecraft:orange_concrete
fill 517 199 529 517 221 529 minecraft:blue_concrete
fill 521 199 526 521 203 526 minecraft:blackstone
fill 522 199 525 522 203 525 minecraft:blackstone
fill 522 199 530 522 203 530 minecraft:blackstone
fill 524 199 525 525 203 525 minecraft:blackstone
fill 525 199 510 525 201 510 minecraft:blue_concrete
fill 525 199 530 525 203 530 minecraft:blackstone
setblock 526 199 510 minecraft:magma_block
fill 526 199 526 526 203 529 minecraft:blackstone
fill 539 199 510 539 218 510 minecraft:blue_concrete
setblock 543 199 552 minecraft:shroomlight
fill 549 199 522 549 205 522 minecraft:blackstone
fill 549 199 525 549 205 525 minecraft:blackstone
fill 552 199 522 552 205 522 minecraft:blackstone
fill 553 199 521 554 200 522 minecraft:red_terracotta
fill 554 199 552 554 215 552 minecraft:blue_concrete
fill 520 200 527 520 203 529 minecraft:blackstone
fill 521 200 525 521 203 525 minecraft:blackstone
fill 521 200 530 521 203 530 minecraft:blackstone
fill 522 200 531 524 203 531 minecraft:blackstone
fill 523 200 524 523 203 524 minecraft:blackstone
fill 526 200 510 526 221 510 minecraft:blue_concrete
fill 526 200 530 526 203 530 minecraft:blackstone
fill 543 200 552 543 221 552 minecraft:blue_concrete
fill 548 200 523 548 205 524 minecraft:blackstone
fill 550 200 521 551 205 521 minecraft:blackstone
fill 550 200 526 551 205 526 minecraft:blackstone
fill 552 200 525 552 205 525 minecraft:blackstone
fill 553 200 523 553 205 524 minecraft:blackstone
setblock 553 200 552 minecraft:magma_block
setblock 559 200 529 minecraft:magma_block
fill 517 201 518 517 206 518 minecraft:blue_concrete
fill 517 201 534 517 206 534 minecraft:blue_concrete
fill 517 201 550 517 206 550 minecraft:blue_concrete
fill 520 201 526 520 203 526 minecraft:blackstone
fill 520 201 530 520 203 530 minecraft:blackstone
fill 521 201 510 521 206 510 minecraft:blue_concrete
fill 521 201 531 521 203 531 minecraft:blackstone
fill 522 201 524 522 203 524 minecraft:blackstone
fill 524 201 524 525 203 524 minecraft:blackstone
fill 525 201 531 525 203 531 minecraft:blackstone
fill 525 201 552 525 219 552 minecraft:blue_concrete
fill 526 201 525 526 203 525 minecraft:blackstone
setblock 526 201 552 minecraft:magma_block
fill 527 201 526 527 203 529 minecraft:blackstone
fill 527 201 552 527 221 552 minecraft:blue_concrete
setblock 528 201 552 minecraft:white_concrete
fill 530 201 534 530 202 534 minecraft:red_terracotta
fill 531 201 552 531 206 552 minecraft:blue_concrete
fill 537 201 510 537 206 510 minecraft:blue_concrete
fill 547 201 552 547 206 552 minecraft:blue_concrete
fill 548 201 522 548 205 522 minecraft:blackstone
fill 548 201 525 548 205 525 minecraft:blackstone
fill 549 201 521 549 205 521 minecraft:blackstone
fill 549 201 526 549 205 526 minecraft:blackstone
fill 552 201 521 552 205 521 minecraft:blackstone
fill 552 201 526 552 205 526 minecraft:blackstone
fill 553 201 510 553 206 510 minecraft:blue_concrete
fill 553 201 522 553 205 522 minecraft:blackstone
fill 553 201 525 553 205 525 minecraft:blackstone
fill 553 201 552 553 221 552 minecraft:blue_concrete
setblock 557 201 510 minecraft:white_concrete
setblock 559 201 519 minecraft:shroomlight
fill 559 201 520 559 206 520 minecraft:blue_concrete
fill 559 201 529 559 224 529 minecraft:blue_concrete
fill 559 201 536 559 206 536 minecraft:blue_concrete
fill 519 202 526 519 203 529 minecraft:blackstone
fill 520 202 525 520 203 525 minecraft:blackstone
fill 521 202 524 521 203 524 minecraft:blackstone
fill 522 202 532 524 203 532 minecraft:blackstone
fill 523 202 523 523 203 523 minecraft:blackstone
setblock 525 202 510 minecraft:shroomlight
fill 526 202 524 526 203 524 minecraft:blackstone
fill 526 202 531 526 203 531 minecraft:blackstone
fill 526 202 552 526 221 552 minecraft:blue_concrete
fill 527 202 525 527 203 525 minecraft:blackstone
fill 527 202 530 527 203 530 minecraft:blackstone
fill 528 202 552 528 221 552 minecraft:blue_concrete
fill 547 202 523 547 205 524 minecraft:blackstone
fill 548 202 521 548 205 521 minecraft:blackstone
fill 548 202 526 548 205 526 minecraft:blackstone
fill 550 202 520 551 205 520 minecraft:blackstone
fill 550 202 527 551 205 527 minecraft:blackstone
setblock 550 202 552 minecraft:magma_block
fill 553 202 521 553 205 521 minecraft:blackstone
fill 553 202 526 553 205 526 minecraft:blackstone
fill 554 202 523 554 205 524 minecraft:blackstone
setblock 555 202 510 minecraft:shroomlight
fill 557 202 510 557 222 510 minecraft:blue_concrete
fill 559 202 519 559 212 519 minecraft:blue_concrete
setblock 517 203 531 minecraft:white_concrete
setblock 517 203 538 minecraft:magma_block
setblock 519 203 525 minecraft:blackstone
setblock 519 203 530 minecraft:blackstone
setblock 520 203 524 minecraft:blackstone
setblock 520 203 531 minecraft:blackstone
setblock 521 203 532 minecraft:blackstone
setblock 522 203 523 minecraft:blackstone
fill 524 203 523 525 203 523 minecraft:blackstone
fill 525 203 510 525 221 510 minecraft:blue_concrete
setblock 525 203 532 minecraft:blackstone
setblock 527 203 531 minecraft:blackstone
fill 528 203 526 528 203 529 minecraft:blackstone
fill 547 203 522 547 205 522 minecraft:blackstone
fill 547 203 525 547 205 525 minecraft:blackstone
fill 549 203 520 549 205 520 minecraft:blackstone
fill 549 203 527 549 205 527 minecraft:blackstone
fill 550 203 552 550 221 552 minecraft:blue_concrete
fill 552 203 520 552 205 520 minecraft:blackstone
fill 552 203 527 552 205 527 minecraft:blackstone
fill 554 203 522 554 205 522 minecraft:blackstone
fill 554 203 525 554 205 525 minecraft:blackstone
fill 555 203 510 555 221 510 minecraft:blue_concrete
setblock 559 203 550 minecraft:shroomlight
fill 517 204 531 517 205 531 minecraft:blue_concrete
fill 517 204 538 517 216 538 minecraft:blue_concrete
fill 523 204 527 524 205 528 minecraft:magma_block
setblock 540 204 510 minecraft:magma_block
fill 546 204 522 546 205 525 minecraft:blackstone
fill 547 204 521 547 205 521 minecraft:blackstone
fill 547 204 526 547 205 526 minecraft:blackstone
fill 548 204 520 548 205 520 minecraft:blackstone
fill 548 204 527 548 205 527 minecraft:blackstone
fill 550 204 519 551 205 519 minecraft:blackstone
fill 550 204 528 551 205 528 minecraft:blackstone
fill 553 204 520 553 205 520 minecraft:blackstone
fill 553 204 527 553 205 527 minecraft:blackstone
fill 554 204 521 554 205 521 minecraft:blackstone
fill 554 204 526 554 205 526 minecraft:blackstone
fill 555 204 523 555 205 524 minecraft:blackstone
fill 559 204 550 559 221 550 minecraft:blue_concrete
setblock 520 205 513 minecraft:light[level=14]
setblock 520 205 521 minecraft:light[level=14]
setblock 520 205 529 minecraft:light[level=14]
setblock 520 205 537 minecraft:light[level=14]
setblock 520 205 545 minecraft:light[level=14]
setblock 528 205 513 minecraft:light[level=14]
setblock 528 205 521 minecraft:light[level=14]
setblock 528 205 529 minecraft:light[level=14]
setblock 528 205 537 minecraft:light[level=14]
setblock 528 205 545 minecraft:light[level=14]
setblock 536 205 513 minecraft:light[level=14]
setblock 536 205 521 minecraft:light[level=14]
setblock 536 205 537 minecraft:light[level=14]
setblock 536 205 545 minecraft:light[level=14]
fill 540 205 510 540 221 510 minecraft:blue_concrete
setblock 544 205 513 minecraft:light[level=14]
setblock 544 205 521 minecraft:light[level=14]
setblock 544 205 529 minecraft:light[level=14]
setblock 544 205 537 minecraft:light[level=14]
setblock 544 205 545 minecraft:light[level=14]
setblock 546 205 521 minecraft:blackstone
setblock 546 205 526 minecraft:blackstone
setblock 547 205 520 minecraft:blackstone
setblock 547 205 527 minecraft:blackstone
fill 548 205 519 549 205 519 minecraft:blackstone
fill 548 205 528 549 205 528 minecraft:blackstone
setblock 551 205 552 minecraft:white_concrete
setblock 552 205 513 minecraft:light[level=14]
setblock 552 205 519 minecraft:blackstone
setblock 552 205 528 minecraft:blackstone
setblock 552 205 529 minecraft:light[level=14]
setblock 552 205 537 minecraft:light[level=14]
setblock 552 205 545 minecraft:light[level=14]
setblock 554 205 520 minecraft:blackstone
setblock 554 205 527 minecraft:blackstone
setblock 555 205 522 minecraft:blackstone
setblock 555 205 525 minecraft:blackstone
setblock 559 205 513 minecraft:white_concrete
setblock 559 205 525 minecraft:magma_block
setblock 559 205 545 minecraft:white_concrete
setblock 517 206 531 minecraft:shroomlight
fill 523 206 527 523 206 528 minecraft:magma_block
setblock 524 206 528 minecraft:magma_block
fill 545 206 519 545 207 520 minecraft:blue_concrete
fill 550 206 523 551 207 524 minecraft:magma_block
fill 551 206 552 551 221 552 minecraft:blue_concrete
fill 559 206 513 559 221 513 minecraft:blue_concrete
fill 559 206 525 559 221 525 minecraft:blue_concrete
fill 559 206 545 559 217 545 minecraft:blue_concrete
fill 517 207 518 517 209 518 minecraft:orange_concrete
setblock 517 207 522 minecraft:white_concrete
schedule function dropper:buildpart/131_2 1t
