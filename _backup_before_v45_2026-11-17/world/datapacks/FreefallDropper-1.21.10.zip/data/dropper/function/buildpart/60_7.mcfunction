fill 10 286 301 10 286 302 minecraft:dripstone_block
setblock 11 286 301 minecraft:dripstone_block
fill 15 286 294 15 286 295 minecraft:dripstone_block
setblock 16 286 294 minecraft:dripstone_block
fill 16 286 307 16 286 308 minecraft:dripstone_block
fill 17 286 306 18 286 307 minecraft:dripstone_block
setblock 18 286 290 minecraft:dripstone_block
fill 18 286 301 19 286 302 minecraft:dripstone_block
fill 19 286 284 20 286 284 minecraft:dripstone_block
setblock 20 286 283 minecraft:dripstone_block
fill 22 286 299 22 286 300 minecraft:dripstone_block
setblock 24 286 289 minecraft:dripstone_block
fill 25 286 299 26 286 299 minecraft:dripstone_block
fill 26 286 300 26 287 300 minecraft:dripstone_block
fill 30 286 283 30 287 283 minecraft:dripstone_block
setblock 31 286 277 minecraft:dripstone_block
fill 31 286 304 31 286 305 minecraft:dripstone_block
fill 35 286 308 36 286 308 minecraft:dripstone_block
fill 35 286 311 36 286 311 minecraft:dripstone_block
setblock 36 286 310 minecraft:dripstone_block
fill 38 286 310 38 287 310 minecraft:dripstone_block
setblock 40 286 300 minecraft:dripstone_block
fill 42 286 301 42 308 301 minecraft:deepslate_tiles
fill 0 287 288 0 308 288 minecraft:deepslate_tiles
fill 0 287 300 0 287 301 minecraft:amethyst_block
fill 0 287 304 0 308 305 minecraft:deepslate_tiles
setblock 0 287 306 minecraft:crying_obsidian
fill 0 287 307 0 308 309 minecraft:deepslate_tiles
setblock 5 287 312 minecraft:dripstone_block
fill 5 287 317 5 308 317 minecraft:deepslate_tiles
fill 6 287 314 6 289 314 minecraft:dripstone_block
fill 10 287 301 10 289 301 minecraft:dripstone_block
setblock 10 287 305 minecraft:dripstone_block
fill 11 287 285 12 287 285 minecraft:dripstone_block
setblock 11 287 308 minecraft:dripstone_block
fill 15 287 294 15 288 294 minecraft:dripstone_block
fill 16 287 276 18 287 277 minecraft:amethyst_block
setblock 16 287 298 minecraft:dripstone_block
fill 16 287 307 16 289 307 minecraft:dripstone_block
setblock 17 287 278 minecraft:amethyst_block
setblock 18 287 301 minecraft:dripstone_block
fill 18 287 306 18 288 306 minecraft:dripstone_block
fill 19 287 302 19 288 302 minecraft:dripstone_block
fill 20 287 284 20 288 284 minecraft:dripstone_block
setblock 22 287 300 minecraft:dripstone_block
fill 26 287 299 26 289 299 minecraft:dripstone_block
fill 29 287 292 30 287 292 minecraft:dripstone_block
setblock 30 287 291 minecraft:dripstone_block
fill 31 287 304 31 288 304 minecraft:dripstone_block
setblock 34 287 275 minecraft:purple_concrete
fill 36 287 281 36 293 281 minecraft:blackstone
setblock 36 287 308 minecraft:dripstone_block
fill 36 287 311 36 288 311 minecraft:dripstone_block
fill 0 288 300 0 308 300 minecraft:deepslate_tiles
fill 0 288 301 0 288 302 minecraft:amethyst_block
fill 0 288 306 0 308 306 minecraft:deepslate_tiles
fill 2 288 300 2 288 301 minecraft:amethyst_block
setblock 3 288 278 minecraft:light[level=12]
fill 3 288 285 3 288 286 minecraft:light[level=12]
setblock 3 288 292 minecraft:light[level=12]
setblock 3 288 294 minecraft:light[level=12]
setblock 3 288 299 minecraft:light[level=12]
setblock 3 288 302 minecraft:light[level=12]
setblock 3 288 306 minecraft:light[level=12]
setblock 3 288 310 minecraft:light[level=12]
setblock 3 288 313 minecraft:light[level=12]
setblock 7 288 307 minecraft:dripstone_block
fill 10 288 278 11 288 278 minecraft:light[level=12]
setblock 10 288 285 minecraft:light[level=12]
setblock 10 288 292 minecraft:light[level=12]
setblock 10 288 299 minecraft:light[level=12]
setblock 10 288 306 minecraft:light[level=12]
setblock 10 288 313 minecraft:light[level=12]
setblock 11 288 286 minecraft:light[level=12]
setblock 11 288 294 minecraft:light[level=12]
setblock 11 288 302 minecraft:light[level=12]
setblock 11 288 310 minecraft:light[level=12]
fill 12 288 285 12 289 285 minecraft:dripstone_block
setblock 17 288 276 minecraft:amethyst_block
setblock 17 288 278 minecraft:light[level=12]
setblock 17 288 285 minecraft:light[level=12]
setblock 17 288 292 minecraft:light[level=12]
setblock 17 288 299 minecraft:light[level=12]
setblock 17 288 306 minecraft:light[level=12]
setblock 17 288 313 minecraft:light[level=12]
setblock 19 288 278 minecraft:light[level=12]
setblock 19 288 286 minecraft:light[level=12]
setblock 19 288 310 minecraft:light[level=12]
setblock 24 288 278 minecraft:light[level=12]
setblock 24 288 285 minecraft:light[level=12]
setblock 24 288 292 minecraft:light[level=12]
setblock 24 288 299 minecraft:light[level=12]
setblock 24 288 306 minecraft:light[level=12]
setblock 24 288 313 minecraft:light[level=12]
setblock 27 288 278 minecraft:light[level=12]
setblock 27 288 286 minecraft:light[level=12]
setblock 27 288 294 minecraft:light[level=12]
setblock 27 288 302 minecraft:light[level=12]
setblock 27 288 310 minecraft:light[level=12]
fill 30 288 292 30 289 292 minecraft:dripstone_block
fill 31 288 278 31 289 278 minecraft:dripstone_block
setblock 31 288 285 minecraft:light[level=12]
setblock 31 288 292 minecraft:light[level=12]
setblock 31 288 299 minecraft:light[level=12]
setblock 31 288 306 minecraft:light[level=12]
setblock 31 288 313 minecraft:light[level=12]
fill 31 288 317 31 308 317 minecraft:deepslate_tiles
setblock 32 288 317 minecraft:magma_block
fill 33 288 317 33 308 317 minecraft:deepslate_tiles
fill 34 288 275 34 308 275 minecraft:deepslate_tiles
setblock 35 288 278 minecraft:light[level=12]
fill 35 288 281 35 293 281 minecraft:blackstone
setblock 35 288 286 minecraft:light[level=12]
setblock 35 288 294 minecraft:light[level=12]
setblock 35 288 302 minecraft:light[level=12]
setblock 35 288 310 minecraft:light[level=12]
fill 36 288 280 36 293 280 minecraft:blackstone
fill 36 288 282 36 293 282 minecraft:blackstone
fill 37 288 281 37 293 281 minecraft:blackstone
setblock 38 288 278 minecraft:light[level=12]
setblock 38 288 285 minecraft:light[level=12]
setblock 38 288 292 minecraft:light[level=12]
setblock 38 288 299 minecraft:light[level=12]
setblock 38 288 306 minecraft:light[level=12]
setblock 38 288 313 minecraft:light[level=12]
fill 0 289 301 0 308 302 minecraft:deepslate_tiles
setblock 1 289 301 minecraft:amethyst_block
fill 32 289 317 32 308 317 minecraft:deepslate_tiles
fill 35 290 280 35 293 280 minecraft:blackstone
fill 35 290 282 35 293 282 minecraft:blackstone
fill 37 290 280 37 293 280 minecraft:blackstone
fill 37 290 282 37 293 282 minecraft:blackstone
setblock 0 291 277 minecraft:crying_obsidian
fill 10 291 316 10 293 316 minecraft:amethyst_block
fill 12 291 275 12 308 275 minecraft:deepslate_tiles
setblock 13 291 275 minecraft:magma_block
fill 14 291 275 14 292 275 minecraft:deepslate_tiles
setblock 21 291 317 minecraft:magma_block
fill 34 291 309 41 291 309 minecraft:amethyst_block
fill 39 291 308 40 293 308 minecraft:amethyst_block
fill 39 291 310 40 293 310 minecraft:amethyst_block
setblock 42 291 290 minecraft:magma_block
fill 0 292 277 0 302 284 minecraft:deepslate_tiles
setblock 0 292 285 minecraft:amethyst_block
fill 0 292 286 0 308 287 minecraft:deepslate_tiles
fill 6 292 317 9 292 317 minecraft:deepslate_tiles
fill 9 292 316 9 293 316 minecraft:amethyst_block
fill 10 292 315 11 293 315 minecraft:amethyst_block
fill 10 292 317 11 293 317 minecraft:amethyst_block
fill 11 292 316 11 293 316 minecraft:amethyst_block
fill 13 292 275 13 308 275 minecraft:deepslate_tiles
fill 21 292 317 21 308 317 minecraft:deepslate_tiles
fill 36 292 309 41 292 309 minecraft:amethyst_block
fill 37 292 308 38 292 308 minecraft:amethyst_block
fill 37 292 310 38 292 310 minecraft:amethyst_block
fill 41 292 308 41 293 308 minecraft:amethyst_block
fill 41 292 310 41 293 310 minecraft:amethyst_block
fill 42 292 290 42 308 290 minecraft:deepslate_tiles
fill 0 293 285 0 308 285 minecraft:deepslate_tiles
setblock 1 293 275 minecraft:purple_concrete
fill 6 293 317 8 308 317 minecraft:deepslate_tiles
setblock 9 293 315 minecraft:amethyst_block
setblock 9 293 317 minecraft:amethyst_block
setblock 12 293 317 minecraft:purple_concrete
setblock 14 293 275 minecraft:purple_concrete
setblock 34 293 281 minecraft:blackstone
setblock 36 293 279 minecraft:blackstone
setblock 36 293 283 minecraft:blackstone
fill 37 293 309 41 293 309 minecraft:amethyst_block
setblock 38 293 281 minecraft:blackstone
setblock 38 293 308 minecraft:amethyst_block
setblock 38 293 310 minecraft:amethyst_block
fill 1 294 275 1 308 275 minecraft:deepslate_tiles
fill 3 294 278 3 295 278 minecraft:light[level=12]
setblock 3 294 285 minecraft:light[level=12]
setblock 3 294 292 minecraft:light[level=12]
setblock 3 294 299 minecraft:light[level=12]
setblock 3 294 306 minecraft:light[level=12]
setblock 3 294 313 minecraft:light[level=12]
fill 9 294 317 9 308 317 minecraft:deepslate_tiles
setblock 10 294 278 minecraft:light[level=12]
setblock 10 294 285 minecraft:light[level=12]
setblock 10 294 292 minecraft:light[level=12]
setblock 10 294 299 minecraft:light[level=12]
setblock 10 294 306 minecraft:light[level=12]
setblock 10 294 313 minecraft:light[level=12]
setblock 10 294 315 minecraft:amethyst_block
setblock 10 294 317 minecraft:amethyst_block
fill 11 294 317 12 308 317 minecraft:deepslate_tiles
fill 14 294 275 14 308 275 minecraft:deepslate_tiles
setblock 17 294 278 minecraft:light[level=12]
setblock 17 294 285 minecraft:light[level=12]
setblock 17 294 292 minecraft:light[level=12]
setblock 17 294 299 minecraft:light[level=12]
setblock 17 294 306 minecraft:light[level=12]
setblock 17 294 313 minecraft:light[level=12]
setblock 24 294 278 minecraft:light[level=12]
setblock 24 294 285 minecraft:light[level=12]
setblock 24 294 292 minecraft:light[level=12]
setblock 24 294 299 minecraft:light[level=12]
setblock 24 294 306 minecraft:light[level=12]
setblock 24 294 313 minecraft:light[level=12]
setblock 31 294 278 minecraft:light[level=12]
setblock 31 294 285 minecraft:light[level=12]
setblock 31 294 292 minecraft:light[level=12]
setblock 31 294 299 minecraft:light[level=12]
setblock 31 294 306 minecraft:light[level=12]
setblock 31 294 313 minecraft:light[level=12]
setblock 38 294 278 minecraft:light[level=12]
setblock 38 294 285 minecraft:light[level=12]
setblock 38 294 292 minecraft:light[level=12]
setblock 38 294 299 minecraft:light[level=12]
setblock 38 294 306 minecraft:light[level=12]
setblock 38 294 313 minecraft:light[level=12]
fill 39 294 309 41 294 309 minecraft:amethyst_block
setblock 40 294 308 minecraft:amethyst_block
setblock 40 294 310 minecraft:amethyst_block
setblock 42 294 298 minecraft:crying_obsidian
setblock 3 295 286 minecraft:light[level=12]
setblock 3 295 294 minecraft:light[level=12]
setblock 3 295 302 minecraft:light[level=12]
setblock 3 295 310 minecraft:light[level=12]
fill 10 295 317 10 308 317 minecraft:deepslate_tiles
setblock 11 295 278 minecraft:light[level=12]
setblock 11 295 286 minecraft:light[level=12]
setblock 11 295 294 minecraft:light[level=12]
setblock 11 295 302 minecraft:light[level=12]
setblock 11 295 310 minecraft:light[level=12]
setblock 19 295 278 minecraft:light[level=12]
setblock 19 295 286 minecraft:light[level=12]
setblock 19 295 302 minecraft:light[level=12]
setblock 19 295 310 minecraft:light[level=12]
setblock 27 295 278 minecraft:light[level=12]
setblock 27 295 286 minecraft:light[level=12]
setblock 27 295 294 minecraft:light[level=12]
setblock 27 295 302 minecraft:light[level=12]
setblock 27 295 310 minecraft:light[level=12]
setblock 35 295 278 minecraft:light[level=12]
setblock 35 295 286 minecraft:light[level=12]
setblock 35 295 294 minecraft:light[level=12]
setblock 35 295 302 minecraft:light[level=12]
setblock 35 295 310 minecraft:light[level=12]
setblock 42 295 282 minecraft:magma_block
fill 42 295 283 42 297 283 minecraft:deepslate_tiles
fill 42 295 298 42 298 298 minecraft:deepslate_tiles
setblock 7 296 275 minecraft:magma_block
fill 42 296 282 42 308 282 minecraft:deepslate_tiles
fill 7 297 275 7 308 275 minecraft:deepslate_tiles
setblock 42 297 300 minecraft:purple_concrete
setblock 42 298 283 minecraft:magma_block
fill 42 298 300 42 308 300 minecraft:deepslate_tiles
fill 42 299 283 42 308 283 minecraft:deepslate_tiles
setblock 42 299 298 minecraft:magma_block
setblock 0 300 289 minecraft:amethyst_block
setblock 3 300 278 minecraft:light[level=12]
setblock 3 300 285 minecraft:light[level=12]
setblock 3 300 292 minecraft:light[level=12]
setblock 3 300 299 minecraft:light[level=12]
setblock 3 300 306 minecraft:light[level=12]
setblock 3 300 313 minecraft:light[level=12]
setblock 10 300 278 minecraft:light[level=12]
setblock 10 300 285 minecraft:light[level=12]
setblock 10 300 292 minecraft:light[level=12]
setblock 10 300 299 minecraft:light[level=12]
setblock 10 300 306 minecraft:light[level=12]
setblock 10 300 313 minecraft:light[level=12]
setblock 17 300 278 minecraft:light[level=12]
setblock 17 300 285 minecraft:light[level=12]
setblock 17 300 292 minecraft:light[level=12]
setblock 17 300 299 minecraft:light[level=12]
setblock 17 300 306 minecraft:light[level=12]
setblock 17 300 313 minecraft:light[level=12]
setblock 24 300 278 minecraft:light[level=12]
setblock 24 300 285 minecraft:light[level=12]
setblock 24 300 292 minecraft:light[level=12]
setblock 24 300 299 minecraft:light[level=12]
setblock 24 300 306 minecraft:light[level=12]
setblock 24 300 313 minecraft:light[level=12]
setblock 29 300 275 minecraft:crying_obsidian
setblock 31 300 278 minecraft:light[level=12]
setblock 31 300 285 minecraft:light[level=12]
setblock 31 300 292 minecraft:light[level=12]
setblock 31 300 299 minecraft:light[level=12]
setblock 31 300 306 minecraft:light[level=12]
setblock 31 300 313 minecraft:light[level=12]
setblock 35 300 317 minecraft:crying_obsidian
setblock 37 300 317 minecraft:magma_block
setblock 38 300 278 minecraft:light[level=12]
setblock 38 300 285 minecraft:light[level=12]
setblock 38 300 292 minecraft:light[level=12]
setblock 38 300 299 minecraft:light[level=12]
setblock 38 300 306 minecraft:light[level=12]
setblock 38 300 313 minecraft:light[level=12]
fill 38 300 317 38 308 317 minecraft:deepslate_tiles
fill 42 300 293 42 308 293 minecraft:deepslate_tiles
setblock 42 300 294 minecraft:magma_block
fill 42 300 295 42 308 295 minecraft:deepslate_tiles
fill 42 300 298 42 308 298 minecraft:deepslate_tiles
fill 0 301 289 0 308 289 minecraft:deepslate_tiles
fill 29 301 275 29 308 275 minecraft:deepslate_tiles
fill 35 301 317 35 308 317 minecraft:deepslate_tiles
fill 37 301 317 37 308 317 minecraft:deepslate_tiles
setblock 42 301 291 minecraft:purple_concrete
fill 42 301 294 42 308 294 minecraft:deepslate_tiles
setblock 42 301 306 minecraft:purple_concrete
fill 42 301 307 42 304 308 minecraft:deepslate_tiles
setblock 3 302 278 minecraft:light[level=12]
setblock 3 302 286 minecraft:light[level=12]
setblock 3 302 294 minecraft:light[level=12]
setblock 3 302 302 minecraft:light[level=12]
setblock 3 302 310 minecraft:light[level=12]
setblock 11 302 278 minecraft:light[level=12]
setblock 11 302 286 minecraft:light[level=12]
setblock 11 302 294 minecraft:light[level=12]
setblock 11 302 302 minecraft:light[level=12]
setblock 11 302 310 minecraft:light[level=12]
setblock 19 302 278 minecraft:light[level=12]
setblock 19 302 286 minecraft:light[level=12]
setblock 19 302 294 minecraft:light[level=12]
setblock 19 302 302 minecraft:light[level=12]
setblock 19 302 310 minecraft:light[level=12]
setblock 27 302 278 minecraft:light[level=12]
setblock 27 302 286 minecraft:light[level=12]
setblock 27 302 294 minecraft:light[level=12]
setblock 27 302 302 minecraft:light[level=12]
setblock 27 302 310 minecraft:light[level=12]
setblock 35 302 278 minecraft:light[level=12]
setblock 35 302 286 minecraft:light[level=12]
setblock 35 302 294 minecraft:light[level=12]
setblock 35 302 302 minecraft:light[level=12]
setblock 35 302 310 minecraft:light[level=12]
fill 42 302 291 42 308 291 minecraft:deepslate_tiles
fill 42 302 306 42 308 306 minecraft:deepslate_tiles
fill 0 303 277 0 308 279 minecraft:deepslate_tiles
setblock 0 303 280 minecraft:magma_block
fill 0 303 281 0 308 284 minecraft:deepslate_tiles
fill 0 304 280 0 305 280 minecraft:deepslate_tiles
setblock 42 304 313 minecraft:amethyst_block
setblock 42 305 307 minecraft:crying_obsidian
fill 42 305 308 42 308 308 minecraft:deepslate_tiles
fill 42 305 313 42 308 313 minecraft:deepslate_tiles
setblock 0 306 280 minecraft:magma_block
fill 16 306 317 18 308 317 minecraft:deepslate_tiles
setblock 19 306 317 minecraft:crying_obsidian
fill 42 306 307 42 308 307 minecraft:deepslate_tiles
fill 0 307 280 0 308 280 minecraft:deepslate_tiles
fill 19 307 317 19 308 317 minecraft:deepslate_tiles
setblock 0 308 293 minecraft:crying_obsidian
