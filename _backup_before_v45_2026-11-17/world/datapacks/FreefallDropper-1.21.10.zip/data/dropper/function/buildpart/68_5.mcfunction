setblock 387 184 280 minecraft:red_terracotta
setblock 387 184 286 minecraft:light[level=15]
setblock 387 184 294 minecraft:light[level=15]
setblock 387 184 310 minecraft:light[level=15]
fill 387 184 315 387 187 315 minecraft:red_terracotta
setblock 388 184 278 minecraft:stripped_oak_log
fill 388 184 279 388 186 279 minecraft:red_terracotta
setblock 389 184 277 minecraft:stripped_oak_log
fill 389 184 278 389 187 278 minecraft:red_terracotta
setblock 390 184 276 minecraft:stripped_oak_log
fill 390 184 277 390 187 277 minecraft:red_terracotta
setblock 390 184 316 minecraft:stripped_oak_log
fill 391 184 276 391 187 276 minecraft:red_terracotta
setblock 391 184 315 minecraft:stripped_oak_log
fill 391 184 316 391 187 316 minecraft:red_terracotta
setblock 392 184 279 minecraft:stripped_oak_log
fill 392 184 315 392 186 315 minecraft:red_terracotta
setblock 393 184 278 minecraft:stripped_oak_log
setblock 394 184 277 minecraft:stripped_oak_log
setblock 394 184 278 minecraft:red_terracotta
setblock 395 184 276 minecraft:stripped_oak_log
setblock 395 184 277 minecraft:red_terracotta
setblock 395 184 278 minecraft:light[level=15]
setblock 395 184 286 minecraft:light[level=15]
setblock 395 184 294 minecraft:light[level=15]
setblock 395 184 302 minecraft:light[level=15]
setblock 395 184 310 minecraft:light[level=15]
setblock 395 184 316 minecraft:stripped_oak_log
fill 396 184 276 396 185 276 minecraft:red_terracotta
fill 396 184 316 396 186 316 minecraft:red_terracotta
setblock 400 184 316 minecraft:stripped_oak_log
fill 401 184 316 401 187 316 minecraft:red_terracotta
setblock 403 184 278 minecraft:light[level=15]
setblock 403 184 286 minecraft:light[level=15]
setblock 403 184 294 minecraft:light[level=15]
setblock 403 184 302 minecraft:light[level=15]
setblock 403 184 310 minecraft:light[level=15]
setblock 405 184 276 minecraft:stripped_oak_log
setblock 405 184 316 minecraft:stripped_oak_log
fill 406 184 276 406 187 276 minecraft:red_terracotta
setblock 406 184 315 minecraft:stripped_oak_log
fill 406 184 316 406 187 316 minecraft:red_terracotta
fill 407 184 315 407 186 315 minecraft:red_terracotta
setblock 409 184 277 minecraft:stripped_oak_log
setblock 410 184 276 minecraft:stripped_oak_log
setblock 410 184 277 minecraft:red_terracotta
setblock 410 184 316 minecraft:stripped_oak_log
fill 411 184 276 411 185 276 minecraft:red_terracotta
setblock 411 184 278 minecraft:light[level=15]
setblock 411 184 286 minecraft:light[level=15]
setblock 411 184 294 minecraft:light[level=15]
setblock 411 184 302 minecraft:light[level=15]
setblock 411 184 310 minecraft:light[level=15]
fill 411 184 316 411 186 316 minecraft:red_terracotta
setblock 414 184 302 minecraft:stripped_oak_log
setblock 414 184 303 minecraft:red_terracotta
setblock 415 184 301 minecraft:stripped_oak_log
fill 415 184 302 415 185 302 minecraft:red_terracotta
setblock 415 184 306 minecraft:stripped_oak_log
fill 416 184 281 416 185 281 minecraft:red_terracotta
setblock 416 184 284 minecraft:red_terracotta
setblock 416 184 285 minecraft:stripped_oak_log
fill 416 184 286 417 185 287 minecraft:red_terracotta
setblock 416 184 300 minecraft:stripped_oak_log
fill 416 184 301 416 186 301 minecraft:red_terracotta
setblock 416 184 305 minecraft:stripped_oak_log
fill 416 184 306 416 186 306 minecraft:red_terracotta
setblock 417 184 279 minecraft:stripped_oak_log
fill 417 184 280 417 187 280 minecraft:red_terracotta
setblock 417 184 284 minecraft:stripped_oak_log
fill 417 184 285 417 187 285 minecraft:red_terracotta
setblock 417 184 288 minecraft:red_terracotta
setblock 417 184 289 minecraft:stripped_oak_log
fill 417 184 290 417 187 290 minecraft:red_terracotta
setblock 417 184 294 minecraft:stripped_oak_log
fill 417 184 295 417 186 295 minecraft:red_terracotta
setblock 417 184 299 minecraft:stripped_oak_log
fill 417 184 300 417 187 300 minecraft:red_terracotta
setblock 417 184 304 minecraft:stripped_oak_log
fill 417 184 305 417 187 305 minecraft:red_terracotta
setblock 417 184 309 minecraft:stripped_oak_log
fill 418 184 276 418 187 316 minecraft:terracotta
setblock 377 185 277 minecraft:red_terracotta
setblock 377 185 278 minecraft:stripped_oak_log
fill 377 185 279 377 188 279 minecraft:red_terracotta
setblock 377 185 283 minecraft:stripped_oak_log
fill 377 185 284 377 185 287 minecraft:red_terracotta
setblock 377 185 288 minecraft:stripped_oak_log
fill 377 185 289 377 188 289 minecraft:red_terracotta
setblock 377 185 299 minecraft:red_terracotta
setblock 377 185 303 minecraft:stripped_oak_log
fill 377 185 304 377 186 304 minecraft:red_terracotta
setblock 378 185 282 minecraft:stripped_oak_log
fill 378 185 283 378 188 283 minecraft:red_terracotta
fill 378 185 285 378 185 286 minecraft:red_terracotta
setblock 378 185 287 minecraft:stripped_oak_log
fill 378 185 288 378 188 288 minecraft:red_terracotta
setblock 379 185 276 minecraft:stripped_oak_log
setblock 379 185 281 minecraft:stripped_oak_log
fill 379 185 282 379 186 282 minecraft:red_terracotta
setblock 379 185 285 minecraft:red_terracotta
fill 380 185 276 380 188 276 minecraft:red_terracotta
fill 382 185 278 382 196 278 minecraft:stripped_oak_log
setblock 383 185 277 minecraft:stripped_oak_log
fill 383 185 278 383 187 278 minecraft:red_terracotta
setblock 384 185 276 minecraft:stripped_oak_log
fill 384 185 277 384 188 277 minecraft:red_terracotta
setblock 384 185 316 minecraft:stripped_oak_log
fill 385 185 276 385 188 276 minecraft:red_terracotta
fill 385 185 316 385 188 316 minecraft:red_terracotta
setblock 386 185 279 minecraft:stripped_oak_log
fill 386 185 315 386 188 315 minecraft:red_terracotta
setblock 387 185 278 minecraft:stripped_oak_log
fill 387 185 279 387 186 279 minecraft:red_terracotta
setblock 388 185 277 minecraft:stripped_oak_log
fill 388 185 278 388 188 278 minecraft:red_terracotta
setblock 389 185 276 minecraft:stripped_oak_log
fill 389 185 277 389 188 277 minecraft:red_terracotta
setblock 389 185 316 minecraft:stripped_oak_log
fill 390 185 276 390 188 276 minecraft:red_terracotta
setblock 390 185 315 minecraft:stripped_oak_log
fill 390 185 316 390 188 316 minecraft:red_terracotta
setblock 391 185 279 minecraft:stripped_oak_log
fill 391 185 315 391 187 315 minecraft:red_terracotta
setblock 392 185 278 minecraft:stripped_oak_log
setblock 393 185 277 minecraft:stripped_oak_log
setblock 393 185 278 minecraft:red_terracotta
setblock 394 185 276 minecraft:stripped_oak_log
setblock 394 185 277 minecraft:red_terracotta
setblock 394 185 316 minecraft:stripped_oak_log
fill 395 185 276 395 186 276 minecraft:red_terracotta
fill 395 185 316 395 187 316 minecraft:red_terracotta
setblock 400 185 316 minecraft:red_terracotta
setblock 404 185 276 minecraft:stripped_oak_log
setblock 404 185 316 minecraft:stripped_oak_log
fill 405 185 276 405 186 276 minecraft:red_terracotta
setblock 405 185 315 minecraft:stripped_oak_log
fill 405 185 316 405 188 316 minecraft:red_terracotta
fill 406 185 315 406 187 315 minecraft:red_terracotta
setblock 407 185 277 minecraft:red_terracotta
setblock 408 185 276 minecraft:red_terracotta
setblock 408 185 277 minecraft:stripped_oak_log
setblock 409 185 276 minecraft:stripped_oak_log
setblock 409 185 277 minecraft:red_terracotta
setblock 409 185 316 minecraft:stripped_oak_log
fill 410 185 276 410 186 276 minecraft:red_terracotta
fill 410 185 316 410 186 316 minecraft:red_terracotta
setblock 415 185 301 minecraft:red_terracotta
setblock 415 185 305 minecraft:stripped_oak_log
setblock 416 185 284 minecraft:stripped_oak_log
fill 416 185 285 416 188 285 minecraft:red_terracotta
setblock 416 185 288 minecraft:red_terracotta
setblock 416 185 299 minecraft:stripped_oak_log
fill 416 185 300 416 186 300 minecraft:red_terracotta
setblock 416 185 304 minecraft:stripped_oak_log
fill 416 185 305 416 187 305 minecraft:red_terracotta
setblock 417 185 279 minecraft:red_terracotta
setblock 417 185 283 minecraft:stripped_oak_log
fill 417 185 284 417 188 284 minecraft:red_terracotta
setblock 417 185 288 minecraft:stripped_oak_log
fill 417 185 289 417 188 289 minecraft:red_terracotta
setblock 417 185 293 minecraft:stripped_oak_log
setblock 417 185 294 minecraft:red_terracotta
setblock 417 185 298 minecraft:stripped_oak_log
fill 417 185 299 417 187 299 minecraft:red_terracotta
setblock 417 185 303 minecraft:stripped_oak_log
fill 417 185 304 417 188 304 minecraft:red_terracotta
setblock 417 185 308 minecraft:stripped_oak_log
fill 417 185 309 417 186 309 minecraft:red_terracotta
setblock 377 186 277 minecraft:stripped_oak_log
fill 377 186 278 377 187 278 minecraft:red_terracotta
setblock 377 186 282 minecraft:stripped_oak_log
fill 377 186 283 377 186 286 minecraft:red_terracotta
setblock 377 186 287 minecraft:stripped_oak_log
fill 377 186 288 377 189 288 minecraft:red_terracotta
setblock 377 186 302 minecraft:stripped_oak_log
setblock 377 186 303 minecraft:red_terracotta
setblock 378 186 281 minecraft:stripped_oak_log
fill 378 186 282 378 189 282 minecraft:red_terracotta
setblock 378 186 285 minecraft:red_terracotta
setblock 378 186 286 minecraft:stripped_oak_log
fill 378 186 287 378 189 287 minecraft:red_terracotta
setblock 379 186 276 minecraft:red_terracotta
setblock 379 186 278 minecraft:light[level=12]
setblock 379 186 285 minecraft:stripped_oak_log
setblock 379 186 292 minecraft:light[level=12]
setblock 379 186 299 minecraft:light[level=12]
setblock 379 186 306 minecraft:light[level=12]
setblock 379 186 313 minecraft:light[level=12]
setblock 382 186 277 minecraft:stripped_oak_log
setblock 383 186 276 minecraft:stripped_oak_log
fill 383 186 277 383 189 277 minecraft:red_terracotta
setblock 383 186 316 minecraft:stripped_oak_log
fill 384 186 276 384 189 276 minecraft:red_terracotta
fill 384 186 278 384 187 278 minecraft:red_terracotta
fill 384 186 279 385 218 279 minecraft:stripped_oak_log
fill 384 186 316 384 189 316 minecraft:red_terracotta
setblock 386 186 278 minecraft:stripped_oak_log
setblock 386 186 279 minecraft:red_terracotta
setblock 386 186 285 minecraft:light[level=12]
setblock 386 186 292 minecraft:light[level=12]
setblock 386 186 306 minecraft:light[level=12]
setblock 386 186 313 minecraft:light[level=12]
setblock 387 186 277 minecraft:stripped_oak_log
fill 387 186 278 387 188 278 minecraft:red_terracotta
setblock 388 186 276 minecraft:stripped_oak_log
fill 388 186 277 388 189 277 minecraft:red_terracotta
setblock 388 186 316 minecraft:stripped_oak_log
fill 389 186 276 389 189 276 minecraft:red_terracotta
setblock 389 186 315 minecraft:stripped_oak_log
fill 389 186 316 389 189 316 minecraft:red_terracotta
fill 390 186 315 390 189 315 minecraft:red_terracotta
setblock 391 186 278 minecraft:stripped_oak_log
setblock 392 186 277 minecraft:stripped_oak_log
setblock 393 186 276 minecraft:stripped_oak_log
setblock 393 186 277 minecraft:red_terracotta
setblock 393 186 278 minecraft:light[level=12]
setblock 393 186 285 minecraft:light[level=12]
setblock 393 186 292 minecraft:light[level=12]
setblock 393 186 299 minecraft:light[level=12]
setblock 393 186 306 minecraft:light[level=12]
setblock 393 186 313 minecraft:light[level=12]
setblock 393 186 316 minecraft:stripped_oak_log
fill 394 186 276 394 187 276 minecraft:red_terracotta
fill 394 186 316 394 187 316 minecraft:red_terracotta
setblock 400 186 278 minecraft:light[level=12]
setblock 400 186 285 minecraft:light[level=12]
setblock 400 186 292 minecraft:light[level=12]
setblock 400 186 299 minecraft:light[level=12]
setblock 400 186 306 minecraft:light[level=12]
setblock 400 186 313 minecraft:light[level=12]
setblock 403 186 316 minecraft:stripped_oak_log
setblock 404 186 276 minecraft:red_terracotta
fill 404 186 316 404 189 316 minecraft:red_terracotta
setblock 405 186 315 minecraft:red_terracotta
setblock 407 186 278 minecraft:light[level=12]
setblock 407 186 285 minecraft:light[level=12]
setblock 407 186 292 minecraft:light[level=12]
setblock 407 186 299 minecraft:light[level=12]
setblock 407 186 306 minecraft:light[level=12]
setblock 407 186 313 minecraft:light[level=12]
setblock 408 186 276 minecraft:stripped_oak_log
setblock 408 186 316 minecraft:stripped_oak_log
setblock 409 186 276 minecraft:red_terracotta
fill 409 186 294 409 187 294 minecraft:shroomlight
fill 409 186 316 409 187 316 minecraft:red_terracotta
setblock 414 186 278 minecraft:light[level=12]
setblock 414 186 285 minecraft:light[level=12]
setblock 414 186 292 minecraft:light[level=12]
setblock 414 186 299 minecraft:light[level=12]
setblock 414 186 306 minecraft:light[level=12]
setblock 414 186 313 minecraft:light[level=12]
setblock 416 186 283 minecraft:stripped_oak_log
fill 416 186 284 416 188 284 minecraft:red_terracotta
fill 416 186 286 416 186 287 minecraft:red_terracotta
setblock 416 186 288 minecraft:stripped_oak_log
setblock 416 186 303 minecraft:stripped_oak_log
fill 416 186 304 416 187 304 minecraft:red_terracotta
setblock 417 186 282 minecraft:stripped_oak_log
fill 417 186 283 417 189 283 minecraft:red_terracotta
setblock 417 186 286 minecraft:red_terracotta
setblock 417 186 287 minecraft:stripped_oak_log
fill 417 186 288 417 189 288 minecraft:red_terracotta
setblock 417 186 292 minecraft:stripped_oak_log
setblock 417 186 293 minecraft:red_terracotta
setblock 417 186 297 minecraft:stripped_oak_log
setblock 417 186 298 minecraft:red_terracotta
setblock 417 186 302 minecraft:stripped_oak_log
fill 417 186 303 417 188 303 minecraft:red_terracotta
setblock 417 186 307 minecraft:stripped_oak_log
fill 417 186 308 417 188 308 minecraft:red_terracotta
setblock 377 187 281 minecraft:stripped_oak_log
fill 377 187 282 377 187 285 minecraft:red_terracotta
setblock 377 187 286 minecraft:stripped_oak_log
fill 377 187 287 377 190 287 minecraft:red_terracotta
setblock 377 187 291 minecraft:stripped_oak_log
setblock 378 187 280 minecraft:stripped_oak_log
fill 378 187 281 378 188 281 minecraft:red_terracotta
setblock 378 187 284 minecraft:red_terracotta
setblock 378 187 285 minecraft:stripped_oak_log
fill 378 187 286 378 190 286 minecraft:red_terracotta
setblock 379 187 284 minecraft:stripped_oak_log
setblock 379 187 285 minecraft:red_terracotta
setblock 382 187 276 minecraft:stripped_oak_log
fill 382 187 277 382 188 277 minecraft:red_terracotta
fill 383 187 276 383 190 276 minecraft:red_terracotta
fill 383 187 316 383 190 316 minecraft:red_terracotta
setblock 385 187 278 minecraft:stripped_oak_log
fill 385 187 315 385 189 315 minecraft:red_terracotta
setblock 386 187 277 minecraft:stripped_oak_log
fill 386 187 278 386 188 278 minecraft:red_terracotta
setblock 387 187 276 minecraft:stripped_oak_log
fill 387 187 277 387 190 277 minecraft:red_terracotta
setblock 387 187 316 minecraft:stripped_oak_log
fill 388 187 276 388 190 276 minecraft:red_terracotta
setblock 388 187 315 minecraft:stripped_oak_log
fill 388 187 316 388 190 316 minecraft:red_terracotta
fill 389 187 315 389 190 315 minecraft:red_terracotta
setblock 390 187 278 minecraft:stripped_oak_log
setblock 391 187 277 minecraft:stripped_oak_log
setblock 392 187 276 minecraft:stripped_oak_log
setblock 392 187 277 minecraft:red_terracotta
setblock 392 187 316 minecraft:stripped_oak_log
setblock 393 187 276 minecraft:red_terracotta
fill 393 187 316 393 188 316 minecraft:red_terracotta
setblock 402 187 316 minecraft:stripped_oak_log
fill 403 187 316 403 190 316 minecraft:red_terracotta
setblock 407 187 276 minecraft:stripped_oak_log
setblock 407 187 316 minecraft:stripped_oak_log
setblock 408 187 276 minecraft:red_terracotta
fill 408 187 316 408 188 316 minecraft:red_terracotta
setblock 416 187 283 minecraft:red_terracotta
setblock 416 187 286 minecraft:red_terracotta
setblock 416 187 287 minecraft:stripped_oak_log
fill 416 187 288 416 190 288 minecraft:red_terracotta
setblock 416 187 303 minecraft:red_terracotta
setblock 417 187 281 minecraft:stripped_oak_log
fill 417 187 282 417 189 282 minecraft:red_terracotta
setblock 417 187 286 minecraft:stripped_oak_log
fill 417 187 287 417 190 287 minecraft:red_terracotta
setblock 417 187 291 minecraft:stripped_oak_log
fill 417 187 292 417 190 292 minecraft:red_terracotta
setblock 417 187 301 minecraft:stripped_oak_log
fill 417 187 302 417 188 302 minecraft:red_terracotta
setblock 417 187 306 minecraft:stripped_oak_log
fill 417 187 307 417 188 307 minecraft:red_terracotta
fill 376 188 275 376 191 317 minecraft:brown_terracotta
fill 377 188 275 418 191 275 minecraft:brown_terracotta
setblock 377 188 280 minecraft:stripped_oak_log
fill 377 188 281 377 188 284 minecraft:red_terracotta
setblock 377 188 285 minecraft:stripped_oak_log
fill 377 188 286 377 191 286 minecraft:red_terracotta
setblock 377 188 290 minecraft:stripped_oak_log
fill 377 188 317 418 191 317 minecraft:brown_terracotta
setblock 378 188 284 minecraft:stripped_oak_log
fill 378 188 285 378 191 285 minecraft:red_terracotta
setblock 381 188 276 minecraft:stripped_oak_log
fill 382 188 276 382 191 276 minecraft:red_terracotta
fill 383 188 278 384 197 278 minecraft:stripped_oak_log
setblock 385 188 277 minecraft:stripped_oak_log
setblock 385 188 278 minecraft:red_terracotta
setblock 386 188 276 minecraft:stripped_oak_log
fill 386 188 277 386 191 277 minecraft:red_terracotta
setblock 386 188 316 minecraft:stripped_oak_log
fill 387 188 276 387 191 276 minecraft:red_terracotta
setblock 387 188 315 minecraft:stripped_oak_log
fill 387 188 316 387 191 316 minecraft:red_terracotta
fill 388 188 315 388 191 315 minecraft:red_terracotta
setblock 390 188 277 minecraft:stripped_oak_log
setblock 391 188 276 minecraft:stripped_oak_log
setblock 391 188 316 minecraft:stripped_oak_log
setblock 392 188 276 minecraft:red_terracotta
fill 392 188 316 392 190 316 minecraft:red_terracotta
fill 402 188 316 402 191 316 minecraft:red_terracotta
setblock 406 188 316 minecraft:stripped_oak_log
fill 407 188 316 407 190 316 minecraft:red_terracotta
fill 409 188 294 409 198 294 minecraft:brown_terracotta
setblock 416 188 286 minecraft:stripped_oak_log
fill 416 188 287 416 191 287 minecraft:red_terracotta
setblock 417 188 281 minecraft:red_terracotta
setblock 417 188 285 minecraft:stripped_oak_log
fill 417 188 286 417 191 286 minecraft:red_terracotta
setblock 417 188 290 minecraft:stripped_oak_log
fill 417 188 291 417 191 291 minecraft:red_terracotta
setblock 417 188 305 minecraft:stripped_oak_log
fill 417 188 306 417 189 306 minecraft:red_terracotta
fill 418 188 276 418 191 316 minecraft:brown_terracotta
fill 377 189 280 377 189 283 minecraft:red_terracotta
setblock 377 189 284 minecraft:stripped_oak_log
fill 377 189 285 377 192 285 minecraft:red_terracotta
setblock 377 189 289 minecraft:stripped_oak_log
fill 377 189 290 377 192 290 minecraft:red_terracotta
setblock 378 189 283 minecraft:stripped_oak_log
fill 378 189 284 378 192 284 minecraft:red_terracotta
setblock 378 189 288 minecraft:stripped_oak_log
fill 381 189 276 381 192 276 minecraft:red_terracotta
fill 382 189 316 382 191 316 minecraft:red_terracotta
setblock 384 189 277 minecraft:stripped_oak_log
setblock 385 189 276 minecraft:stripped_oak_log
fill 385 189 277 385 192 277 minecraft:red_terracotta
fill 385 189 278 385 218 278 minecraft:stripped_oak_log
setblock 385 189 316 minecraft:stripped_oak_log
fill 386 189 276 386 192 276 minecraft:red_terracotta
setblock 386 189 315 minecraft:stripped_oak_log
fill 386 189 316 386 192 316 minecraft:red_terracotta
fill 387 189 315 387 192 315 minecraft:red_terracotta
setblock 389 189 277 minecraft:stripped_oak_log
setblock 390 189 276 minecraft:stripped_oak_log
setblock 390 189 316 minecraft:stripped_oak_log
setblock 391 189 276 minecraft:red_terracotta
fill 391 189 316 391 192 316 minecraft:red_terracotta
setblock 405 189 316 minecraft:stripped_oak_log
fill 406 189 316 406 192 316 minecraft:red_terracotta
fill 408 189 294 408 198 294 minecraft:brown_terracotta
fill 409 189 295 409 198 295 minecraft:brown_terracotta
setblock 416 189 286 minecraft:red_terracotta
setblock 417 189 284 minecraft:stripped_oak_log
fill 417 189 285 417 192 285 minecraft:red_terracotta
setblock 417 189 289 minecraft:stripped_oak_log
fill 417 189 290 417 192 290 minecraft:red_terracotta
setblock 417 189 305 minecraft:red_terracotta
fill 377 190 280 377 190 282 minecraft:red_terracotta
setblock 377 190 283 minecraft:stripped_oak_log
fill 377 190 284 377 193 284 minecraft:red_terracotta
setblock 377 190 288 minecraft:stripped_oak_log
fill 377 190 289 377 193 289 minecraft:red_terracotta
setblock 378 190 283 minecraft:red_terracotta
setblock 378 190 287 minecraft:stripped_oak_log
fill 378 190 288 378 193 288 minecraft:red_terracotta
setblock 383 190 277 minecraft:stripped_oak_log
setblock 384 190 276 minecraft:stripped_oak_log
fill 384 190 277 384 193 277 minecraft:red_terracotta
setblock 384 190 315 minecraft:red_terracotta
setblock 384 190 316 minecraft:stripped_oak_log
fill 385 190 276 385 193 276 minecraft:red_terracotta
setblock 385 190 315 minecraft:stripped_oak_log
fill 385 190 316 385 193 316 minecraft:red_terracotta
fill 386 190 315 386 193 315 minecraft:red_terracotta
setblock 389 190 276 minecraft:stripped_oak_log
setblock 389 190 316 minecraft:stripped_oak_log
setblock 390 190 276 minecraft:red_terracotta
fill 390 190 316 390 193 316 minecraft:red_terracotta
setblock 404 190 316 minecraft:stripped_oak_log
fill 405 190 316 405 193 316 minecraft:red_terracotta
fill 408 190 293 409 198 293 minecraft:brown_terracotta
fill 408 190 295 408 198 295 minecraft:brown_terracotta
fill 410 190 294 410 198 295 minecraft:brown_terracotta
fill 414 190 306 414 196 306 minecraft:stripped_oak_log
setblock 417 190 283 minecraft:stripped_oak_log
fill 417 190 284 417 193 284 minecraft:red_terracotta
setblock 417 190 288 minecraft:stripped_oak_log
fill 417 190 289 417 193 289 minecraft:red_terracotta
setblock 377 191 281 minecraft:red_terracotta
setblock 377 191 282 minecraft:stripped_oak_log
fill 377 191 283 377 194 283 minecraft:red_terracotta
setblock 377 191 287 minecraft:stripped_oak_log
fill 377 191 288 377 194 288 minecraft:red_terracotta
setblock 377 191 291 minecraft:red_terracotta
setblock 378 191 286 minecraft:stripped_oak_log
fill 378 191 287 378 194 287 minecraft:red_terracotta
fill 380 191 276 380 193 276 minecraft:red_terracotta
fill 381 191 316 381 192 316 minecraft:red_terracotta
setblock 383 191 276 minecraft:stripped_oak_log
fill 383 191 277 383 194 277 minecraft:red_terracotta
setblock 383 191 315 minecraft:red_terracotta
setblock 383 191 316 minecraft:stripped_oak_log
fill 384 191 276 384 194 276 minecraft:red_terracotta
setblock 384 191 315 minecraft:stripped_oak_log
fill 384 191 316 384 194 316 minecraft:red_terracotta
fill 385 191 315 385 194 315 minecraft:red_terracotta
setblock 388 191 276 minecraft:stripped_oak_log
setblock 388 191 316 minecraft:stripped_oak_log
setblock 389 191 276 minecraft:red_terracotta
setblock 389 191 315 minecraft:stripped_oak_log
fill 389 191 316 389 194 316 minecraft:red_terracotta
fill 401 191 316 401 192 316 minecraft:red_terracotta
setblock 403 191 316 minecraft:stripped_oak_log
fill 404 191 316 404 194 316 minecraft:red_terracotta
fill 407 191 294 407 198 295 minecraft:brown_terracotta
fill 408 191 296 409 198 296 minecraft:brown_terracotta
fill 410 191 293 410 198 293 minecraft:brown_terracotta
setblock 416 191 288 minecraft:stripped_oak_log
fill 417 191 283 417 194 283 minecraft:red_terracotta
setblock 417 191 287 minecraft:stripped_oak_log
fill 417 191 288 417 194 288 minecraft:red_terracotta
setblock 417 191 292 minecraft:stripped_oak_log
fill 376 192 275 376 195 317 minecraft:light_gray_terracotta
fill 377 192 275 418 195 275 minecraft:light_gray_terracotta
setblock 377 192 281 minecraft:stripped_oak_log
fill 377 192 282 377 195 282 minecraft:red_terracotta
setblock 377 192 286 minecraft:stripped_oak_log
fill 377 192 287 377 195 287 minecraft:red_terracotta
setblock 377 192 291 minecraft:stripped_oak_log
fill 377 192 317 418 195 317 minecraft:light_gray_terracotta
setblock 378 192 285 minecraft:stripped_oak_log
fill 378 192 286 378 195 286 minecraft:red_terracotta
setblock 378 192 289 minecraft:red_terracotta
setblock 379 192 278 minecraft:light[level=15]
setblock 379 192 285 minecraft:light[level=12]
setblock 379 192 286 minecraft:light[level=15]
setblock 379 192 292 minecraft:light[level=12]
setblock 379 192 294 minecraft:light[level=15]
setblock 379 192 299 minecraft:light[level=12]
setblock 379 192 302 minecraft:light[level=15]
setblock 379 192 306 minecraft:light[level=12]
setblock 379 192 310 minecraft:light[level=15]
setblock 379 192 313 minecraft:light[level=12]
fill 380 192 316 380 193 316 minecraft:red_terracotta
setblock 382 192 276 minecraft:stripped_oak_log
setblock 382 192 315 minecraft:red_terracotta
setblock 382 192 316 minecraft:stripped_oak_log
fill 383 192 276 383 195 276 minecraft:red_terracotta
setblock 383 192 315 minecraft:stripped_oak_log
fill 383 192 316 383 195 316 minecraft:red_terracotta
fill 384 192 315 384 195 315 minecraft:red_terracotta
setblock 386 192 278 minecraft:light[level=12]
setblock 386 192 285 minecraft:light[level=12]
setblock 386 192 292 minecraft:light[level=12]
setblock 386 192 306 minecraft:light[level=12]
setblock 386 192 313 minecraft:light[level=12]
setblock 387 192 276 minecraft:stripped_oak_log
setblock 387 192 278 minecraft:light[level=15]
setblock 387 192 286 minecraft:light[level=15]
setblock 387 192 294 minecraft:light[level=15]
setblock 387 192 310 minecraft:light[level=15]
setblock 387 192 316 minecraft:stripped_oak_log
fill 388 192 276 388 195 276 minecraft:red_terracotta
setblock 388 192 315 minecraft:stripped_oak_log
fill 388 192 316 388 195 316 minecraft:red_terracotta
fill 389 192 315 389 195 315 minecraft:red_terracotta
setblock 393 192 278 minecraft:light[level=12]
setblock 393 192 285 minecraft:light[level=12]
setblock 393 192 292 minecraft:light[level=12]
setblock 393 192 299 minecraft:light[level=12]
setblock 393 192 306 minecraft:light[level=12]
setblock 393 192 313 minecraft:light[level=12]
setblock 395 192 278 minecraft:light[level=15]
setblock 395 192 286 minecraft:light[level=15]
setblock 395 192 294 minecraft:light[level=15]
setblock 395 192 302 minecraft:light[level=15]
setblock 395 192 310 minecraft:light[level=15]
setblock 400 192 278 minecraft:light[level=12]
setblock 400 192 285 minecraft:light[level=12]
setblock 400 192 292 minecraft:light[level=12]
setblock 400 192 299 minecraft:light[level=12]
setblock 400 192 306 minecraft:light[level=12]
setblock 400 192 313 minecraft:light[level=12]
fill 400 192 316 400 193 316 minecraft:red_terracotta
setblock 402 192 316 minecraft:stripped_oak_log
setblock 403 192 278 minecraft:light[level=15]
setblock 403 192 286 minecraft:light[level=15]
setblock 403 192 294 minecraft:light[level=15]
setblock 403 192 302 minecraft:light[level=15]
setblock 403 192 310 minecraft:light[level=15]
setblock 403 192 315 minecraft:stripped_oak_log
fill 403 192 316 403 195 316 minecraft:red_terracotta
fill 404 192 315 404 195 315 minecraft:red_terracotta
setblock 407 192 278 minecraft:light[level=12]
setblock 407 192 285 minecraft:light[level=12]
setblock 407 192 292 minecraft:light[level=12]
fill 407 192 293 407 198 293 minecraft:brown_terracotta
fill 407 192 296 407 198 296 minecraft:brown_terracotta
setblock 407 192 299 minecraft:light[level=12]
setblock 407 192 306 minecraft:light[level=12]
setblock 407 192 313 minecraft:light[level=12]
fill 408 192 292 409 198 292 minecraft:brown_terracotta
fill 410 192 296 410 198 296 minecraft:brown_terracotta
setblock 411 192 278 minecraft:light[level=15]
setblock 411 192 286 minecraft:light[level=15]
fill 411 192 294 411 198 295 minecraft:brown_terracotta
setblock 411 192 302 minecraft:light[level=15]
setblock 411 192 310 minecraft:light[level=15]
setblock 414 192 278 minecraft:light[level=12]
setblock 414 192 285 minecraft:light[level=12]
setblock 414 192 292 minecraft:light[level=12]
setblock 414 192 299 minecraft:light[level=12]
setblock 414 192 313 minecraft:light[level=12]
setblock 416 192 287 minecraft:stripped_oak_log
fill 416 192 288 416 194 289 minecraft:red_terracotta
setblock 417 192 286 minecraft:stripped_oak_log
fill 417 192 287 417 195 287 minecraft:red_terracotta
setblock 417 192 291 minecraft:stripped_oak_log
fill 417 192 292 417 194 293 minecraft:red_terracotta
fill 418 192 276 418 195 316 minecraft:light_gray_terracotta
fill 377 193 281 377 196 281 minecraft:red_terracotta
setblock 377 193 285 minecraft:stripped_oak_log
fill 377 193 286 377 196 286 minecraft:red_terracotta
setblock 377 193 290 minecraft:stripped_oak_log
fill 377 193 291 377 195 292 minecraft:red_terracotta
setblock 378 193 284 minecraft:stripped_oak_log
fill 378 193 285 378 196 285 minecraft:red_terracotta
setblock 378 193 289 minecraft:stripped_oak_log
fill 378 193 290 378 196 290 minecraft:red_terracotta
fill 379 193 276 379 194 276 minecraft:red_terracotta
fill 379 193 310 379 194 310 minecraft:brown_terracotta
fill 379 193 316 379 194 316 minecraft:red_terracotta
setblock 381 193 276 minecraft:stripped_oak_log
setblock 381 193 315 minecraft:red_terracotta
setblock 381 193 316 minecraft:stripped_oak_log
fill 382 193 276 382 195 277 minecraft:red_terracotta
fill 382 193 310 382 194 310 minecraft:brown_terracotta
setblock 382 193 315 minecraft:stripped_oak_log
fill 382 193 316 382 196 316 minecraft:red_terracotta
setblock 383 193 314 minecraft:stripped_oak_log
fill 383 193 315 383 196 315 minecraft:red_terracotta
fill 384 193 314 387 193 314 minecraft:red_terracotta
setblock 386 193 276 minecraft:stripped_oak_log
setblock 386 193 316 minecraft:stripped_oak_log
fill 387 193 276 387 196 276 minecraft:red_terracotta
setblock 387 193 315 minecraft:stripped_oak_log
fill 387 193 316 387 196 316 minecraft:red_terracotta
fill 388 193 315 388 196 315 minecraft:red_terracotta
fill 390 193 315 390 194 315 minecraft:red_terracotta
setblock 391 193 316 minecraft:stripped_oak_log
fill 392 193 316 392 196 316 minecraft:red_terracotta
fill 393 193 310 393 194 310 minecraft:brown_terracotta
fill 398 193 316 399 194 316 minecraft:red_terracotta
fill 400 193 315 401 193 315 minecraft:red_terracotta
setblock 401 193 316 minecraft:stripped_oak_log
setblock 402 193 315 minecraft:stripped_oak_log
fill 402 193 316 402 196 316 minecraft:red_terracotta
fill 403 193 310 403 194 310 minecraft:brown_terracotta
fill 403 193 315 403 196 315 minecraft:red_terracotta
fill 405 193 315 405 194 315 minecraft:red_terracotta
fill 406 193 294 406 198 295 minecraft:brown_terracotta
setblock 406 193 316 minecraft:stripped_oak_log
fill 407 193 292 407 198 292 minecraft:brown_terracotta
fill 408 193 276 408 194 278 minecraft:iron_bars
fill 408 193 297 410 198 297 minecraft:brown_terracotta
fill 410 193 292 410 198 292 minecraft:brown_terracotta
fill 411 193 293 411 198 293 minecraft:brown_terracotta
fill 411 193 296 411 198 296 minecraft:brown_terracotta
fill 416 193 287 416 196 287 minecraft:red_terracotta
setblock 416 193 290 minecraft:red_terracotta
setblock 416 193 291 minecraft:stripped_oak_log
setblock 417 193 285 minecraft:stripped_oak_log
fill 417 193 286 417 196 286 minecraft:red_terracotta
setblock 417 193 290 minecraft:stripped_oak_log
fill 417 193 291 417 196 291 minecraft:red_terracotta
setblock 417 193 294 minecraft:red_terracotta
fill 377 194 280 377 197 280 minecraft:red_terracotta
setblock 377 194 284 minecraft:stripped_oak_log
fill 377 194 285 377 197 285 minecraft:red_terracotta
setblock 377 194 289 minecraft:stripped_oak_log
fill 377 194 290 377 197 290 minecraft:red_terracotta
setblock 377 194 293 minecraft:red_terracotta
fill 377 194 310 377 194 313 minecraft:red_terracotta
setblock 377 194 314 minecraft:stripped_oak_log
fill 377 194 315 377 197 315 minecraft:red_terracotta
fill 378 194 276 378 195 276 minecraft:red_terracotta
fill 378 194 284 378 197 284 minecraft:red_terracotta
setblock 378 194 288 minecraft:stripped_oak_log
fill 378 194 289 378 197 289 minecraft:red_terracotta
fill 378 194 291 378 195 291 minecraft:red_terracotta
fill 378 194 316 378 195 316 minecraft:red_terracotta
fill 379 194 311 379 195 311 minecraft:brown_terracotta
fill 379 194 315 380 194 315 minecraft:red_terracotta
setblock 380 194 276 minecraft:stripped_oak_log
setblock 380 194 316 minecraft:stripped_oak_log
fill 381 194 276 381 196 277 minecraft:red_terracotta
setblock 381 194 314 minecraft:red_terracotta
setblock 381 194 315 minecraft:stripped_oak_log
fill 381 194 316 381 197 316 minecraft:red_terracotta
fill 382 194 311 382 195 311 minecraft:brown_terracotta
setblock 382 194 314 minecraft:stripped_oak_log
fill 382 194 315 382 197 315 minecraft:red_terracotta
fill 383 194 314 386 194 314 minecraft:red_terracotta
setblock 384 194 277 minecraft:stripped_oak_log
setblock 385 194 276 minecraft:stripped_oak_log
fill 385 194 277 385 197 277 minecraft:red_terracotta
setblock 385 194 316 minecraft:stripped_oak_log
fill 386 194 276 386 197 276 minecraft:red_terracotta
setblock 386 194 315 minecraft:stripped_oak_log
fill 386 194 316 386 197 316 minecraft:red_terracotta
setblock 387 194 314 minecraft:stripped_oak_log
fill 387 194 315 387 197 315 minecraft:red_terracotta
fill 388 194 314 388 197 314 minecraft:red_terracotta
setblock 390 194 316 minecraft:stripped_oak_log
fill 391 194 316 391 197 316 minecraft:red_terracotta
fill 393 194 311 393 195 311 minecraft:brown_terracotta
fill 393 194 316 394 194 316 minecraft:red_terracotta
setblock 395 194 316 minecraft:stripped_oak_log
fill 396 194 316 397 196 316 minecraft:red_terracotta
fill 398 194 315 400 194 315 minecraft:red_terracotta
setblock 400 194 316 minecraft:stripped_oak_log
setblock 401 194 314 minecraft:red_terracotta
setblock 401 194 315 minecraft:stripped_oak_log
fill 401 194 316 401 197 316 minecraft:red_terracotta
setblock 402 194 314 minecraft:stripped_oak_log
fill 402 194 315 402 197 315 minecraft:red_terracotta
fill 403 194 311 403 195 311 minecraft:brown_terracotta
fill 403 194 314 403 197 314 minecraft:red_terracotta
setblock 405 194 316 minecraft:stripped_oak_log
fill 406 194 293 406 198 293 minecraft:brown_terracotta
fill 406 194 296 406 198 296 minecraft:brown_terracotta
fill 406 194 316 407 196 316 minecraft:red_terracotta
fill 407 194 297 407 198 297 minecraft:brown_terracotta
fill 408 194 291 409 198 291 minecraft:brown_terracotta
fill 411 194 292 411 198 292 minecraft:brown_terracotta
fill 412 194 294 412 198 295 minecraft:brown_terracotta
fill 413 194 306 413 196 306 minecraft:stripped_oak_log
fill 414 194 305 414 196 305 minecraft:stripped_oak_log
fill 414 194 307 414 196 307 minecraft:stripped_oak_log
fill 415 194 306 415 196 306 minecraft:stripped_oak_log
fill 416 194 286 416 197 286 minecraft:red_terracotta
setblock 416 194 290 minecraft:stripped_oak_log
fill 416 194 291 416 196 292 minecraft:red_terracotta
setblock 417 194 284 minecraft:stripped_oak_log
fill 417 194 285 417 197 285 minecraft:red_terracotta
setblock 417 194 289 minecraft:stripped_oak_log
fill 417 194 290 417 197 290 minecraft:red_terracotta
setblock 417 194 294 minecraft:stripped_oak_log
fill 417 194 295 417 197 295 minecraft:red_terracotta
fill 377 195 276 377 195 277 minecraft:red_terracotta
setblock 377 195 278 minecraft:stripped_oak_log
fill 377 195 279 377 198 279 minecraft:red_terracotta
setblock 377 195 283 minecraft:stripped_oak_log
fill 377 195 284 377 198 284 minecraft:red_terracotta
setblock 377 195 288 minecraft:stripped_oak_log
fill 377 195 289 377 198 289 minecraft:red_terracotta
setblock 377 195 293 minecraft:stripped_oak_log
fill 377 195 294 377 198 294 minecraft:red_terracotta
fill 377 195 309 377 195 312 minecraft:red_terracotta
setblock 377 195 313 minecraft:stripped_oak_log
fill 377 195 314 378 197 314 minecraft:red_terracotta
fill 377 195 316 377 196 316 minecraft:red_terracotta
fill 378 195 283 378 198 283 minecraft:red_terracotta
setblock 378 195 287 minecraft:stripped_oak_log
fill 378 195 288 379 197 288 minecraft:red_terracotta
setblock 378 195 292 minecraft:stripped_oak_log
fill 378 195 310 378 195 311 minecraft:red_terracotta
setblock 378 195 312 minecraft:stripped_oak_log
fill 378 195 313 378 198 313 minecraft:red_terracotta
fill 378 195 315 379 195 315 minecraft:red_terracotta
setblock 379 195 276 minecraft:stripped_oak_log
fill 379 195 277 380 197 277 minecraft:red_terracotta
fill 379 195 289 379 196 289 minecraft:red_terracotta
setblock 379 195 312 minecraft:brown_terracotta
setblock 379 195 316 minecraft:stripped_oak_log
fill 380 195 276 380 198 276 minecraft:red_terracotta
setblock 380 195 314 minecraft:red_terracotta
setblock 380 195 315 minecraft:stripped_oak_log
fill 380 195 316 380 198 316 minecraft:red_terracotta
setblock 381 195 314 minecraft:stripped_oak_log
fill 381 195 315 381 198 315 minecraft:red_terracotta
fill 382 195 312 382 196 312 minecraft:brown_terracotta
fill 382 195 314 385 195 314 minecraft:red_terracotta
setblock 383 195 277 minecraft:stripped_oak_log
fill 383 195 313 385 196 313 minecraft:red_terracotta
setblock 384 195 276 minecraft:stripped_oak_log
fill 384 195 277 384 198 277 minecraft:red_terracotta
setblock 384 195 316 minecraft:stripped_oak_log
fill 385 195 276 385 198 276 minecraft:red_terracotta
setblock 385 195 315 minecraft:stripped_oak_log
fill 385 195 316 385 198 316 minecraft:red_terracotta
setblock 386 195 314 minecraft:stripped_oak_log
fill 386 195 315 386 198 315 minecraft:red_terracotta
fill 387 195 314 387 198 314 minecraft:red_terracotta
fill 389 195 314 389 196 314 minecraft:red_terracotta
setblock 389 195 316 minecraft:stripped_oak_log
setblock 390 195 315 minecraft:stripped_oak_log
fill 390 195 316 390 198 316 minecraft:red_terracotta
fill 391 195 315 392 197 315 minecraft:red_terracotta
fill 393 195 312 393 196 312 minecraft:brown_terracotta
setblock 393 195 316 minecraft:red_terracotta
setblock 394 195 316 minecraft:stripped_oak_log
setblock 395 195 315 minecraft:stripped_oak_log
fill 395 195 316 395 198 316 minecraft:red_terracotta
fill 396 195 315 399 195 315 minecraft:red_terracotta
setblock 398 195 316 minecraft:red_terracotta
fill 399 195 314 400 195 314 minecraft:red_terracotta
setblock 399 195 316 minecraft:stripped_oak_log
setblock 400 195 315 minecraft:stripped_oak_log
fill 400 195 316 400 198 316 minecraft:red_terracotta
setblock 401 195 314 minecraft:stripped_oak_log
fill 401 195 315 401 198 315 minecraft:red_terracotta
fill 402 195 314 402 198 314 minecraft:red_terracotta
fill 403 195 312 403 196 312 minecraft:brown_terracotta
fill 404 195 314 404 196 314 minecraft:red_terracotta
setblock 404 195 316 minecraft:stripped_oak_log
fill 405 195 293 405 198 295 minecraft:brown_terracotta
setblock 405 195 315 minecraft:stripped_oak_log
fill 405 195 316 405 198 316 minecraft:red_terracotta
fill 406 195 292 406 198 292 minecraft:brown_terracotta
fill 406 195 297 406 198 297 minecraft:brown_terracotta
fill 406 195 315 406 198 315 minecraft:red_terracotta
fill 407 195 291 407 198 291 minecraft:brown_terracotta
fill 408 195 298 410 198 298 minecraft:brown_terracotta
fill 410 195 291 410 198 291 minecraft:brown_terracotta
fill 411 195 297 411 198 297 minecraft:brown_terracotta
fill 412 195 292 412 198 293 minecraft:brown_terracotta
fill 412 195 296 412 198 296 minecraft:brown_terracotta
setblock 416 195 288 minecraft:red_terracotta
setblock 416 195 289 minecraft:stripped_oak_log
fill 416 195 290 416 198 290 minecraft:red_terracotta
setblock 416 195 293 minecraft:red_terracotta
setblock 416 195 294 minecraft:stripped_oak_log
setblock 417 195 282 minecraft:red_terracotta
setblock 417 195 283 minecraft:stripped_oak_log
fill 417 195 284 417 198 284 minecraft:red_terracotta
setblock 417 195 288 minecraft:stripped_oak_log
fill 417 195 289 417 198 289 minecraft:red_terracotta
setblock 417 195 292 minecraft:red_terracotta
setblock 417 195 293 minecraft:stripped_oak_log
fill 417 195 294 417 198 294 minecraft:red_terracotta
fill 417 195 296 417 196 296 minecraft:red_terracotta
fill 417 195 310 417 195 312 minecraft:red_terracotta
setblock 417 195 313 minecraft:stripped_oak_log
fill 376 196 275 376 199 317 minecraft:orange_terracotta
fill 377 196 275 418 199 275 minecraft:orange_terracotta
setblock 377 196 276 minecraft:red_terracotta
setblock 377 196 277 minecraft:stripped_oak_log
fill 377 196 278 378 198 278 minecraft:red_terracotta
setblock 377 196 282 minecraft:stripped_oak_log
fill 377 196 283 377 199 283 minecraft:red_terracotta
setblock 377 196 287 minecraft:stripped_oak_log
fill 377 196 288 377 199 288 minecraft:red_terracotta
setblock 377 196 291 minecraft:red_terracotta
setblock 377 196 292 minecraft:stripped_oak_log
fill 377 196 293 378 198 293 minecraft:red_terracotta
fill 377 196 295 377 197 295 minecraft:red_terracotta
fill 377 196 308 377 196 311 minecraft:red_terracotta
setblock 377 196 312 minecraft:stripped_oak_log
fill 377 196 313 377 199 313 minecraft:red_terracotta
fill 377 196 317 418 199 317 minecraft:orange_terracotta
setblock 378 196 276 minecraft:stripped_oak_log
fill 378 196 277 378 199 277 minecraft:red_terracotta
fill 378 196 279 378 197 279 minecraft:red_terracotta
fill 378 196 282 378 199 282 minecraft:red_terracotta
setblock 378 196 286 minecraft:stripped_oak_log
fill 378 196 287 379 198 287 minecraft:red_terracotta
setblock 378 196 291 minecraft:stripped_oak_log
fill 378 196 292 378 199 292 minecraft:red_terracotta
fill 378 196 294 378 197 294 minecraft:red_terracotta
fill 378 196 309 378 196 310 minecraft:red_terracotta
setblock 378 196 311 minecraft:stripped_oak_log
fill 378 196 312 379 198 312 minecraft:red_terracotta
setblock 378 196 315 minecraft:red_terracotta
setblock 378 196 316 minecraft:stripped_oak_log
fill 379 196 276 379 199 276 minecraft:red_terracotta
setblock 379 196 290 minecraft:stripped_oak_log
fill 379 196 291 379 199 291 minecraft:red_terracotta
fill 379 196 311 379 199 311 minecraft:red_terracotta
fill 379 196 313 379 196 314 minecraft:red_terracotta
setblock 379 196 315 minecraft:stripped_oak_log
fill 379 196 316 379 199 316 minecraft:red_terracotta
setblock 380 196 314 minecraft:stripped_oak_log
fill 380 196 315 380 199 315 minecraft:red_terracotta
setblock 381 196 313 minecraft:stripped_oak_log
fill 381 196 314 384 196 314 minecraft:red_terracotta
setblock 382 196 276 minecraft:red_terracotta
setblock 382 196 277 minecraft:stripped_oak_log
fill 382 196 313 382 199 313 minecraft:red_terracotta
setblock 383 196 276 minecraft:stripped_oak_log
fill 383 196 277 383 199 277 minecraft:red_terracotta
setblock 383 196 316 minecraft:stripped_oak_log
fill 384 196 276 384 199 276 minecraft:red_terracotta
setblock 384 196 315 minecraft:stripped_oak_log
fill 384 196 316 384 199 316 minecraft:red_terracotta
setblock 385 196 314 minecraft:stripped_oak_log
fill 385 196 315 385 199 315 minecraft:red_terracotta
setblock 386 196 277 minecraft:red_terracotta
setblock 386 196 313 minecraft:stripped_oak_log
fill 386 196 314 386 199 314 minecraft:red_terracotta
setblock 388 196 276 minecraft:stripped_oak_log
setblock 388 196 316 minecraft:stripped_oak_log
fill 389 196 276 389 199 276 minecraft:red_terracotta
setblock 389 196 315 minecraft:stripped_oak_log
fill 389 196 316 389 199 316 minecraft:red_terracotta
fill 390 196 315 390 199 315 minecraft:red_terracotta
fill 393 196 313 393 197 313 minecraft:brown_terracotta
setblock 393 196 315 minecraft:red_terracotta
setblock 393 196 316 minecraft:stripped_oak_log
setblock 394 196 315 minecraft:stripped_oak_log
fill 394 196 316 394 199 316 minecraft:red_terracotta
fill 395 196 315 398 196 315 minecraft:red_terracotta
fill 396 196 314 399 196 314 minecraft:red_terracotta
setblock 398 196 316 minecraft:stripped_oak_log
setblock 399 196 315 minecraft:stripped_oak_log
fill 399 196 316 399 199 316 minecraft:red_terracotta
fill 400 196 276 402 196 276 minecraft:red_terracotta
setblock 400 196 313 minecraft:red_terracotta
setblock 400 196 314 minecraft:stripped_oak_log
fill 400 196 315 400 199 315 minecraft:red_terracotta
setblock 401 196 313 minecraft:stripped_oak_log
fill 401 196 314 401 199 314 minecraft:red_terracotta
fill 402 196 313 402 199 313 minecraft:red_terracotta
setblock 403 196 276 minecraft:stripped_oak_log
fill 403 196 313 403 197 313 minecraft:brown_terracotta
setblock 403 196 316 minecraft:stripped_oak_log
fill 404 196 276 404 199 276 minecraft:red_terracotta
setblock 404 196 315 minecraft:stripped_oak_log
fill 404 196 316 404 199 316 minecraft:red_terracotta
fill 405 196 292 405 198 292 minecraft:brown_terracotta
fill 405 196 296 405 198 296 minecraft:brown_terracotta
setblock 405 196 314 minecraft:stripped_oak_log
fill 405 196 315 405 199 315 minecraft:red_terracotta
fill 406 196 291 406 198 291 minecraft:brown_terracotta
fill 407 196 298 407 198 298 minecraft:brown_terracotta
fill 408 196 290 410 198 290 minecraft:brown_terracotta
setblock 408 196 316 minecraft:stripped_oak_log
fill 411 196 291 411 198 291 minecraft:brown_terracotta
fill 411 196 298 411 198 298 minecraft:brown_terracotta
fill 412 196 297 412 198 297 minecraft:brown_terracotta
fill 413 196 293 413 198 295 minecraft:brown_terracotta
setblock 413 196 305 minecraft:stripped_oak_log
setblock 413 196 307 minecraft:stripped_oak_log
setblock 415 196 289 minecraft:stripped_oak_log
fill 415 196 290 415 198 291 minecraft:red_terracotta
setblock 415 196 305 minecraft:stripped_oak_log
setblock 415 196 307 minecraft:stripped_oak_log
fill 416 196 285 416 198 285 minecraft:red_terracotta
setblock 416 196 288 minecraft:stripped_oak_log
fill 416 196 289 416 199 289 minecraft:red_terracotta
setblock 416 196 293 minecraft:stripped_oak_log
fill 416 196 294 416 198 295 minecraft:red_terracotta
setblock 417 196 276 minecraft:red_terracotta
setblock 417 196 277 minecraft:stripped_oak_log
fill 417 196 278 417 196 281 minecraft:red_terracotta
setblock 417 196 282 minecraft:stripped_oak_log
fill 417 196 283 417 199 283 minecraft:red_terracotta
setblock 417 196 287 minecraft:stripped_oak_log
fill 417 196 288 417 199 288 minecraft:red_terracotta
setblock 417 196 292 minecraft:stripped_oak_log
fill 417 196 293 417 199 293 minecraft:red_terracotta
setblock 417 196 297 minecraft:stripped_oak_log
fill 417 196 298 417 199 298 minecraft:red_terracotta
fill 417 196 309 417 196 311 minecraft:red_terracotta
setblock 417 196 312 minecraft:stripped_oak_log
fill 417 196 313 417 196 316 minecraft:red_terracotta
fill 418 196 276 418 199 316 minecraft:orange_terracotta
setblock 377 197 276 minecraft:stripped_oak_log
fill 377 197 277 377 200 277 minecraft:red_terracotta
setblock 377 197 281 minecraft:stripped_oak_log
fill 377 197 282 377 200 282 minecraft:red_terracotta
setblock 377 197 286 minecraft:stripped_oak_log
fill 377 197 287 377 200 287 minecraft:red_terracotta
setblock 377 197 291 minecraft:stripped_oak_log
fill 377 197 292 377 200 292 minecraft:red_terracotta
setblock 377 197 296 minecraft:stripped_oak_log
fill 377 197 297 377 200 297 minecraft:red_terracotta
fill 377 197 307 377 197 310 minecraft:red_terracotta
setblock 377 197 311 minecraft:stripped_oak_log
fill 377 197 312 377 200 312 minecraft:red_terracotta
setblock 377 197 316 minecraft:stripped_oak_log
fill 378 197 276 378 200 276 minecraft:red_terracotta
setblock 378 197 280 minecraft:stripped_oak_log
fill 378 197 281 378 200 281 minecraft:red_terracotta
setblock 378 197 285 minecraft:stripped_oak_log
fill 378 197 286 378 200 286 minecraft:red_terracotta
setblock 378 197 290 minecraft:stripped_oak_log
fill 378 197 291 378 200 291 minecraft:red_terracotta
setblock 378 197 295 minecraft:stripped_oak_log
setblock 378 197 309 minecraft:red_terracotta
setblock 378 197 310 minecraft:stripped_oak_log
fill 378 197 311 378 200 311 minecraft:red_terracotta
setblock 378 197 315 minecraft:stripped_oak_log
fill 378 197 316 378 200 316 minecraft:red_terracotta
setblock 379 197 289 minecraft:stripped_oak_log
fill 379 197 290 379 200 290 minecraft:red_terracotta
fill 379 197 292 379 198 292 minecraft:red_terracotta
fill 379 197 310 379 200 310 minecraft:red_terracotta
setblock 379 197 313 minecraft:red_terracotta
setblock 379 197 314 minecraft:stripped_oak_log
fill 379 197 315 379 200 315 minecraft:red_terracotta
setblock 380 197 278 minecraft:stripped_oak_log
setblock 380 197 312 minecraft:red_terracotta
setblock 380 197 313 minecraft:stripped_oak_log
fill 380 197 314 383 197 314 minecraft:red_terracotta
setblock 381 197 276 minecraft:red_terracotta
setblock 381 197 277 minecraft:stripped_oak_log
fill 381 197 278 382 199 278 minecraft:red_terracotta
fill 381 197 313 381 200 313 minecraft:red_terracotta
setblock 382 197 276 minecraft:stripped_oak_log
fill 382 197 277 382 200 277 minecraft:red_terracotta
setblock 382 197 316 minecraft:stripped_oak_log
fill 383 197 276 383 200 276 minecraft:red_terracotta
fill 383 197 313 384 197 313 minecraft:red_terracotta
setblock 383 197 315 minecraft:stripped_oak_log
fill 383 197 316 383 200 316 minecraft:red_terracotta
setblock 384 197 314 minecraft:stripped_oak_log
fill 384 197 315 384 200 315 minecraft:red_terracotta
setblock 385 197 313 minecraft:stripped_oak_log
fill 385 197 314 385 200 314 minecraft:red_terracotta
setblock 386 197 277 minecraft:stripped_oak_log
fill 386 197 313 386 199 313 minecraft:red_terracotta
setblock 387 197 276 minecraft:stripped_oak_log
setblock 387 197 316 minecraft:stripped_oak_log
fill 388 197 276 388 200 276 minecraft:red_terracotta
setblock 388 197 315 minecraft:stripped_oak_log
fill 388 197 316 388 200 316 minecraft:red_terracotta
setblock 389 197 314 minecraft:stripped_oak_log
fill 389 197 315 389 200 315 minecraft:red_terracotta
fill 390 197 314 391 199 314 minecraft:red_terracotta
setblock 392 197 316 minecraft:stripped_oak_log
setblock 393 197 314 minecraft:brown_terracotta
setblock 393 197 315 minecraft:stripped_oak_log
fill 393 197 316 393 200 316 minecraft:red_terracotta
setblock 394 197 314 minecraft:stripped_oak_log
fill 394 197 315 397 197 315 minecraft:red_terracotta
fill 395 197 314 398 197 314 minecraft:red_terracotta
setblock 396 197 316 minecraft:red_terracotta
setblock 397 197 316 minecraft:stripped_oak_log
fill 398 197 276 401 197 276 minecraft:red_terracotta
fill 398 197 313 399 197 313 minecraft:red_terracotta
setblock 398 197 315 minecraft:stripped_oak_log
fill 398 197 316 398 200 316 minecraft:red_terracotta
setblock 399 197 314 minecraft:stripped_oak_log
fill 399 197 315 399 200 315 minecraft:red_terracotta
setblock 400 197 313 minecraft:stripped_oak_log
fill 400 197 314 400 200 314 minecraft:red_terracotta
fill 401 197 313 401 199 313 minecraft:red_terracotta
setblock 402 197 276 minecraft:stripped_oak_log
setblock 402 197 316 minecraft:stripped_oak_log
fill 403 197 276 403 200 276 minecraft:red_terracotta
setblock 403 197 315 minecraft:stripped_oak_log
fill 403 197 316 403 200 316 minecraft:red_terracotta
fill 404 197 293 404 198 295 minecraft:brown_terracotta
setblock 404 197 314 minecraft:stripped_oak_log
fill 404 197 315 404 200 315 minecraft:red_terracotta
fill 405 197 276 405 198 276 minecraft:red_terracotta
fill 405 197 297 405 198 297 minecraft:brown_terracotta
fill 405 197 314 405 198 314 minecraft:red_terracotta
fill 406 197 298 406 198 298 minecraft:brown_terracotta
setblock 406 197 316 minecraft:red_terracotta
fill 407 197 290 407 198 290 minecraft:brown_terracotta
setblock 407 197 315 minecraft:red_terracotta
setblock 407 197 316 minecraft:stripped_oak_log
fill 408 197 299 410 198 299 minecraft:brown_terracotta
fill 408 197 316 408 200 316 minecraft:red_terracotta
fill 411 197 290 411 198 290 minecraft:brown_terracotta
fill 412 197 291 412 198 291 minecraft:brown_terracotta
fill 412 197 298 412 198 298 minecraft:brown_terracotta
fill 413 197 292 413 198 292 minecraft:brown_terracotta
fill 413 197 296 413 198 296 minecraft:brown_terracotta
fill 415 197 289 415 200 289 minecraft:red_terracotta
setblock 415 197 292 minecraft:red_terracotta
setblock 415 197 293 minecraft:stripped_oak_log
fill 415 197 316 416 197 316 minecraft:red_terracotta
setblock 416 197 276 minecraft:red_terracotta
fill 416 197 284 416 199 284 minecraft:red_terracotta
setblock 416 197 287 minecraft:stripped_oak_log
fill 416 197 288 416 200 288 minecraft:red_terracotta
setblock 416 197 291 minecraft:red_terracotta
setblock 416 197 292 minecraft:stripped_oak_log
fill 416 197 293 416 200 293 minecraft:red_terracotta
setblock 416 197 296 minecraft:red_terracotta
setblock 417 197 276 minecraft:stripped_oak_log
fill 417 197 277 417 197 280 minecraft:red_terracotta
setblock 417 197 281 minecraft:stripped_oak_log
fill 417 197 282 417 200 282 minecraft:red_terracotta
setblock 417 197 286 minecraft:stripped_oak_log
fill 417 197 287 417 200 287 minecraft:red_terracotta
setblock 417 197 291 minecraft:stripped_oak_log
fill 417 197 292 417 200 292 minecraft:red_terracotta
setblock 417 197 296 minecraft:stripped_oak_log
fill 417 197 297 417 200 297 minecraft:red_terracotta
fill 417 197 299 417 198 299 minecraft:red_terracotta
fill 417 197 309 417 197 310 minecraft:red_terracotta
setblock 417 197 311 minecraft:stripped_oak_log
fill 417 197 312 417 197 315 minecraft:red_terracotta
setblock 417 197 316 minecraft:stripped_oak_log
fill 377 198 276 377 201 276 minecraft:red_terracotta
setblock 377 198 280 minecraft:stripped_oak_log
fill 377 198 281 377 201 281 minecraft:red_terracotta
setblock 377 198 285 minecraft:stripped_oak_log
fill 377 198 286 377 201 286 minecraft:red_terracotta
setblock 377 198 290 minecraft:stripped_oak_log
fill 377 198 291 377 201 291 minecraft:red_terracotta
setblock 377 198 295 minecraft:stripped_oak_log
fill 377 198 296 378 200 296 minecraft:red_terracotta
fill 377 198 298 377 199 298 minecraft:red_terracotta
fill 377 198 307 377 198 309 minecraft:red_terracotta
setblock 377 198 310 minecraft:stripped_oak_log
fill 377 198 311 377 201 311 minecraft:red_terracotta
setblock 377 198 314 minecraft:red_terracotta
setblock 377 198 315 minecraft:stripped_oak_log
fill 377 198 316 377 201 316 minecraft:red_terracotta
setblock 378 198 279 minecraft:stripped_oak_log
fill 378 198 280 378 201 280 minecraft:red_terracotta
setblock 378 198 284 minecraft:stripped_oak_log
fill 378 198 285 378 201 285 minecraft:red_terracotta
setblock 378 198 288 minecraft:red_terracotta
setblock 378 198 289 minecraft:stripped_oak_log
fill 378 198 290 378 201 290 minecraft:red_terracotta
setblock 378 198 294 minecraft:stripped_oak_log
fill 378 198 295 378 201 295 minecraft:red_terracotta
setblock 378 198 308 minecraft:red_terracotta
setblock 378 198 309 minecraft:stripped_oak_log
fill 378 198 310 378 201 310 minecraft:red_terracotta
setblock 378 198 314 minecraft:stripped_oak_log
fill 378 198 315 378 201 315 minecraft:red_terracotta
setblock 379 198 277 minecraft:red_terracotta
setblock 379 198 278 minecraft:stripped_oak_log
fill 379 198 279 379 201 279 minecraft:red_terracotta
setblock 379 198 285 minecraft:light[level=12]
setblock 379 198 288 minecraft:stripped_oak_log
fill 379 198 289 379 199 289 minecraft:red_terracotta
setblock 379 198 293 minecraft:stripped_oak_log
fill 379 198 294 379 201 294 minecraft:red_terracotta
setblock 379 198 299 minecraft:light[level=12]
setblock 379 198 306 minecraft:light[level=12]
setblock 379 198 313 minecraft:stripped_oak_log
fill 379 198 314 382 198 314 minecraft:red_terracotta
setblock 380 198 277 minecraft:stripped_oak_log
fill 380 198 278 380 201 278 minecraft:red_terracotta
setblock 380 198 312 minecraft:stripped_oak_log
fill 380 198 313 380 201 313 minecraft:red_terracotta
setblock 381 198 276 minecraft:stripped_oak_log
fill 381 198 277 381 201 277 minecraft:red_terracotta
setblock 381 198 316 minecraft:stripped_oak_log
fill 382 198 276 382 201 276 minecraft:red_terracotta
setblock 382 198 315 minecraft:stripped_oak_log
fill 382 198 316 382 201 316 minecraft:red_terracotta
setblock 383 198 278 minecraft:red_terracotta
setblock 383 198 313 minecraft:red_terracotta
setblock 383 198 314 minecraft:stripped_oak_log
fill 383 198 315 383 201 315 minecraft:red_terracotta
fill 384 198 278 384 218 278 minecraft:stripped_oak_log
setblock 384 198 313 minecraft:stripped_oak_log
fill 384 198 314 384 201 314 minecraft:red_terracotta
setblock 385 198 277 minecraft:stripped_oak_log
fill 385 198 313 385 200 313 minecraft:red_terracotta
setblock 386 198 276 minecraft:stripped_oak_log
fill 386 198 277 386 200 277 minecraft:red_terracotta
setblock 386 198 278 minecraft:light[level=12]
setblock 386 198 285 minecraft:light[level=12]
setblock 386 198 292 minecraft:light[level=12]
setblock 386 198 306 minecraft:light[level=12]
setblock 386 198 316 minecraft:stripped_oak_log
fill 387 198 276 387 201 276 minecraft:red_terracotta
setblock 387 198 315 minecraft:stripped_oak_log
fill 387 198 316 387 201 316 minecraft:red_terracotta
setblock 388 198 314 minecraft:stripped_oak_log
fill 388 198 315 388 201 315 minecraft:red_terracotta
fill 389 198 314 389 200 314 minecraft:red_terracotta
setblock 390 198 276 minecraft:red_terracotta
setblock 391 198 315 minecraft:red_terracotta
setblock 391 198 316 minecraft:stripped_oak_log
setblock 392 198 314 minecraft:red_terracotta
setblock 392 198 315 minecraft:stripped_oak_log
fill 392 198 316 392 201 316 minecraft:red_terracotta
setblock 393 198 278 minecraft:light[level=12]
setblock 393 198 285 minecraft:light[level=12]
setblock 393 198 292 minecraft:light[level=12]
setblock 393 198 299 minecraft:light[level=12]
setblock 393 198 306 minecraft:light[level=12]
setblock 393 198 313 minecraft:light[level=12]
setblock 393 198 314 minecraft:stripped_oak_log
fill 393 198 315 396 198 315 minecraft:red_terracotta
fill 394 198 314 397 198 314 minecraft:red_terracotta
setblock 396 198 276 minecraft:stripped_oak_log
setblock 396 198 316 minecraft:stripped_oak_log
fill 397 198 276 400 198 276 minecraft:red_terracotta
fill 397 198 313 398 198 313 minecraft:red_terracotta
setblock 397 198 315 minecraft:stripped_oak_log
fill 397 198 316 397 201 316 minecraft:red_terracotta
setblock 398 198 314 minecraft:stripped_oak_log
fill 398 198 315 398 201 315 minecraft:red_terracotta
setblock 399 198 313 minecraft:stripped_oak_log
fill 399 198 314 399 201 314 minecraft:red_terracotta
setblock 400 198 278 minecraft:light[level=12]
setblock 400 198 285 minecraft:light[level=12]
setblock 400 198 292 minecraft:light[level=12]
setblock 400 198 299 minecraft:light[level=12]
setblock 400 198 306 minecraft:light[level=12]
fill 400 198 313 400 200 313 minecraft:red_terracotta
setblock 401 198 276 minecraft:stripped_oak_log
setblock 401 198 316 minecraft:stripped_oak_log
fill 402 198 276 402 201 276 minecraft:red_terracotta
setblock 402 198 315 minecraft:stripped_oak_log
fill 402 198 316 402 201 316 minecraft:red_terracotta
setblock 403 198 314 minecraft:stripped_oak_log
fill 403 198 315 403 201 315 minecraft:red_terracotta
setblock 404 198 292 minecraft:brown_terracotta
fill 404 198 296 404 198 297 minecraft:brown_terracotta
fill 404 198 314 404 199 314 minecraft:red_terracotta
setblock 405 198 291 minecraft:brown_terracotta
setblock 405 198 298 minecraft:brown_terracotta
setblock 406 198 276 minecraft:stripped_oak_log
setblock 406 198 290 minecraft:brown_terracotta
fill 406 198 299 407 198 299 minecraft:brown_terracotta
setblock 406 198 316 minecraft:stripped_oak_log
setblock 407 198 278 minecraft:light[level=12]
setblock 407 198 285 minecraft:light[level=12]
setblock 407 198 306 minecraft:light[level=12]
setblock 407 198 313 minecraft:light[level=12]
setblock 407 198 315 minecraft:stripped_oak_log
fill 407 198 316 407 201 316 minecraft:red_terracotta
fill 408 198 289 410 198 289 minecraft:brown_terracotta
fill 409 198 316 409 199 316 minecraft:red_terracotta
setblock 411 198 299 minecraft:brown_terracotta
setblock 412 198 290 minecraft:brown_terracotta
fill 412 198 306 412 199 306 minecraft:brown_terracotta
setblock 413 198 291 minecraft:brown_terracotta
setblock 413 198 297 minecraft:brown_terracotta
fill 414 198 276 415 198 276 minecraft:red_terracotta
setblock 414 198 278 minecraft:light[level=12]
setblock 414 198 285 minecraft:light[level=12]
setblock 414 198 292 minecraft:light[level=12]
fill 414 198 293 414 198 295 minecraft:brown_terracotta
setblock 414 198 299 minecraft:light[level=12]
setblock 414 198 306 minecraft:light[level=12]
setblock 414 198 313 minecraft:light[level=12]
fill 414 198 316 415 198 316 minecraft:red_terracotta
fill 415 198 288 415 199 288 minecraft:red_terracotta
setblock 415 198 292 minecraft:stripped_oak_log
fill 415 198 293 415 200 294 minecraft:red_terracotta
setblock 416 198 276 minecraft:stripped_oak_log
setblock 416 198 286 minecraft:stripped_oak_log
fill 416 198 287 416 201 287 minecraft:red_terracotta
setblock 416 198 291 minecraft:stripped_oak_log
fill 416 198 292 416 201 292 minecraft:red_terracotta
setblock 416 198 296 minecraft:stripped_oak_log
fill 416 198 297 416 201 297 minecraft:red_terracotta
fill 416 198 314 416 198 315 minecraft:red_terracotta
setblock 416 198 316 minecraft:stripped_oak_log
fill 417 198 276 417 198 279 minecraft:red_terracotta
setblock 417 198 280 minecraft:stripped_oak_log
fill 417 198 281 417 201 281 minecraft:red_terracotta
setblock 417 198 285 minecraft:stripped_oak_log
fill 417 198 286 417 201 286 minecraft:red_terracotta
setblock 417 198 290 minecraft:stripped_oak_log
fill 417 198 291 417 201 291 minecraft:red_terracotta
setblock 417 198 295 minecraft:stripped_oak_log
fill 417 198 296 417 201 296 minecraft:red_terracotta
setblock 417 198 300 minecraft:stripped_oak_log
fill 417 198 308 417 198 309 minecraft:red_terracotta
setblock 417 198 310 minecraft:stripped_oak_log
fill 417 198 311 417 198 314 minecraft:red_terracotta
setblock 417 198 315 minecraft:stripped_oak_log
fill 417 198 316 417 201 316 minecraft:red_terracotta
setblock 377 199 278 minecraft:red_terracotta
setblock 377 199 279 minecraft:stripped_oak_log
fill 377 199 280 377 202 280 minecraft:red_terracotta
setblock 377 199 284 minecraft:stripped_oak_log
fill 377 199 285 377 202 285 minecraft:red_terracotta
setblock 377 199 289 minecraft:stripped_oak_log
fill 377 199 290 377 202 290 minecraft:red_terracotta
setblock 377 199 293 minecraft:red_terracotta
setblock 377 199 294 minecraft:stripped_oak_log
fill 377 199 295 377 202 295 minecraft:red_terracotta
setblock 377 199 299 minecraft:stripped_oak_log
fill 377 199 300 377 202 300 minecraft:red_terracotta
fill 377 199 307 377 199 308 minecraft:red_terracotta
setblock 377 199 309 minecraft:stripped_oak_log
fill 377 199 310 377 202 310 minecraft:red_terracotta
setblock 377 199 314 minecraft:stripped_oak_log
fill 377 199 315 377 202 315 minecraft:red_terracotta
setblock 378 199 278 minecraft:stripped_oak_log
fill 378 199 279 378 202 279 minecraft:red_terracotta
setblock 378 199 283 minecraft:stripped_oak_log
fill 378 199 284 378 201 284 minecraft:red_terracotta
setblock 378 199 287 minecraft:red_terracotta
setblock 378 199 288 minecraft:stripped_oak_log
fill 378 199 289 378 202 289 minecraft:red_terracotta
setblock 378 199 293 minecraft:stripped_oak_log
fill 378 199 294 378 202 294 minecraft:red_terracotta
setblock 378 199 297 minecraft:red_terracotta
setblock 378 199 308 minecraft:stripped_oak_log
fill 378 199 309 378 202 309 minecraft:red_terracotta
setblock 378 199 312 minecraft:red_terracotta
setblock 378 199 313 minecraft:stripped_oak_log
fill 378 199 314 381 199 314 minecraft:red_terracotta
setblock 379 199 277 minecraft:stripped_oak_log
fill 379 199 278 379 202 278 minecraft:red_terracotta
fill 379 199 280 379 200 280 minecraft:red_terracotta
setblock 379 199 288 minecraft:red_terracotta
setblock 379 199 292 minecraft:stripped_oak_log
fill 379 199 293 379 201 293 minecraft:red_terracotta
fill 379 199 295 379 200 295 minecraft:red_terracotta
setblock 379 199 312 minecraft:stripped_oak_log
fill 379 199 313 379 202 313 minecraft:red_terracotta
setblock 380 199 276 minecraft:stripped_oak_log
fill 380 199 277 380 202 277 minecraft:red_terracotta
fill 380 199 311 380 200 311 minecraft:stripped_oak_log
fill 380 199 312 380 201 312 minecraft:red_terracotta
setblock 380 199 316 minecraft:stripped_oak_log
fill 381 199 276 381 202 276 minecraft:red_terracotta
setblock 381 199 315 minecraft:stripped_oak_log
fill 381 199 316 381 202 316 minecraft:red_terracotta
setblock 382 199 287 minecraft:shroomlight
setblock 382 199 293 minecraft:shroomlight
setblock 382 199 299 minecraft:shroomlight
setblock 382 199 305 minecraft:shroomlight
setblock 382 199 311 minecraft:shroomlight
setblock 382 199 314 minecraft:stripped_oak_log
fill 382 199 315 382 202 315 minecraft:red_terracotta
setblock 383 199 278 minecraft:stripped_oak_log
setblock 383 199 313 minecraft:stripped_oak_log
fill 383 199 314 383 202 314 minecraft:red_terracotta
setblock 384 199 277 minecraft:stripped_oak_log
fill 384 199 313 384 200 313 minecraft:red_terracotta
setblock 385 199 276 minecraft:stripped_oak_log
fill 385 199 277 385 202 277 minecraft:red_terracotta
setblock 385 199 316 minecraft:stripped_oak_log
fill 386 199 276 386 202 276 minecraft:red_terracotta
setblock 386 199 315 minecraft:stripped_oak_log
fill 386 199 316 386 202 316 minecraft:red_terracotta
setblock 387 199 314 minecraft:stripped_oak_log
fill 387 199 315 387 202 315 minecraft:red_terracotta
setblock 388 199 281 minecraft:shroomlight
setblock 388 199 311 minecraft:shroomlight
fill 388 199 314 388 201 314 minecraft:red_terracotta
setblock 390 199 276 minecraft:stripped_oak_log
setblock 390 199 316 minecraft:stripped_oak_log
fill 391 199 276 391 202 276 minecraft:red_terracotta
setblock 391 199 315 minecraft:stripped_oak_log
fill 391 199 316 391 202 316 minecraft:red_terracotta
setblock 392 199 314 minecraft:stripped_oak_log
fill 392 199 315 395 199 315 minecraft:red_terracotta
fill 393 199 276 394 199 276 minecraft:red_terracotta
fill 393 199 314 396 199 314 minecraft:red_terracotta
setblock 394 199 281 minecraft:shroomlight
setblock 394 199 311 minecraft:shroomlight
setblock 395 199 276 minecraft:stripped_oak_log
setblock 395 199 316 minecraft:stripped_oak_log
fill 396 199 276 399 199 276 minecraft:red_terracotta
setblock 396 199 315 minecraft:stripped_oak_log
fill 396 199 316 396 202 316 minecraft:red_terracotta
setblock 397 199 313 minecraft:red_terracotta
setblock 397 199 314 minecraft:stripped_oak_log
fill 397 199 315 397 202 315 minecraft:red_terracotta
setblock 398 199 313 minecraft:stripped_oak_log
fill 398 199 314 398 202 314 minecraft:red_terracotta
fill 399 199 313 399 200 313 minecraft:red_terracotta
setblock 400 199 276 minecraft:stripped_oak_log
setblock 400 199 281 minecraft:shroomlight
setblock 400 199 311 minecraft:shroomlight
setblock 400 199 316 minecraft:stripped_oak_log
fill 401 199 276 401 201 277 minecraft:red_terracotta
setblock 401 199 315 minecraft:stripped_oak_log
fill 401 199 316 401 202 316 minecraft:red_terracotta
setblock 402 199 314 minecraft:stripped_oak_log
fill 402 199 315 402 202 315 minecraft:red_terracotta
fill 403 199 314 403 200 314 minecraft:red_terracotta
setblock 405 199 276 minecraft:stripped_oak_log
setblock 405 199 316 minecraft:stripped_oak_log
fill 406 199 276 407 201 276 minecraft:red_terracotta
setblock 406 199 281 minecraft:shroomlight
setblock 406 199 311 minecraft:shroomlight
setblock 406 199 315 minecraft:stripped_oak_log
fill 406 199 316 406 202 316 minecraft:red_terracotta
fill 408 199 294 409 200 295 minecraft:shroomlight
setblock 410 199 294 minecraft:shroomlight
fill 412 199 276 414 199 276 minecraft:red_terracotta
setblock 412 199 281 minecraft:shroomlight
setblock 412 199 287 minecraft:shroomlight
setblock 412 199 293 minecraft:shroomlight
setblock 412 199 299 minecraft:shroomlight
setblock 412 199 305 minecraft:shroomlight
setblock 412 199 311 minecraft:shroomlight
fill 412 199 316 414 199 316 minecraft:red_terracotta
setblock 415 199 276 minecraft:stripped_oak_log
setblock 415 199 290 minecraft:red_terracotta
setblock 415 199 291 minecraft:stripped_oak_log
fill 415 199 292 415 202 292 minecraft:red_terracotta
setblock 415 199 295 minecraft:red_terracotta
setblock 415 199 316 minecraft:stripped_oak_log
fill 416 199 276 416 199 279 minecraft:red_terracotta
setblock 416 199 280 minecraft:stripped_oak_log
fill 416 199 282 416 200 283 minecraft:red_terracotta
setblock 416 199 285 minecraft:stripped_oak_log
fill 416 199 286 416 202 286 minecraft:red_terracotta
setblock 416 199 290 minecraft:stripped_oak_log
fill 416 199 291 416 202 291 minecraft:red_terracotta
setblock 416 199 294 minecraft:red_terracotta
setblock 416 199 295 minecraft:stripped_oak_log
fill 416 199 296 416 202 296 minecraft:red_terracotta
fill 416 199 298 416 200 298 minecraft:red_terracotta
fill 416 199 313 416 199 314 minecraft:red_terracotta
setblock 416 199 315 minecraft:stripped_oak_log
fill 416 199 316 416 202 316 minecraft:red_terracotta
fill 417 199 276 417 199 278 minecraft:red_terracotta
setblock 417 199 279 minecraft:stripped_oak_log
fill 417 199 280 417 202 280 minecraft:red_terracotta
setblock 417 199 284 minecraft:stripped_oak_log
fill 417 199 285 417 202 285 minecraft:red_terracotta
setblock 417 199 289 minecraft:stripped_oak_log
fill 417 199 290 417 202 290 minecraft:red_terracotta
setblock 417 199 294 minecraft:stripped_oak_log
fill 417 199 295 417 202 295 minecraft:red_terracotta
setblock 417 199 299 minecraft:stripped_oak_log
fill 417 199 300 417 201 301 minecraft:red_terracotta
setblock 417 199 308 minecraft:red_terracotta
setblock 417 199 309 minecraft:stripped_oak_log
fill 417 199 310 417 199 313 minecraft:red_terracotta
setblock 417 199 314 minecraft:stripped_oak_log
fill 417 199 315 417 202 315 minecraft:red_terracotta
fill 376 200 275 376 203 317 minecraft:red_terracotta
fill 377 200 275 418 203 275 minecraft:red_terracotta
setblock 377 200 278 minecraft:stripped_oak_log
fill 377 200 279 377 203 279 minecraft:red_terracotta
setblock 377 200 283 minecraft:stripped_oak_log
fill 377 200 284 377 203 284 minecraft:red_terracotta
setblock 377 200 288 minecraft:stripped_oak_log
fill 377 200 289 377 203 289 minecraft:red_terracotta
setblock 377 200 293 minecraft:stripped_oak_log
fill 377 200 294 377 203 294 minecraft:red_terracotta
setblock 377 200 298 minecraft:stripped_oak_log
fill 377 200 299 377 203 299 minecraft:red_terracotta
fill 377 200 301 377 201 301 minecraft:red_terracotta
fill 377 200 302 382 200 305 minecraft:stripped_oak_log
fill 377 200 306 377 200 307 minecraft:red_terracotta
setblock 377 200 308 minecraft:stripped_oak_log
fill 377 200 309 377 203 309 minecraft:red_terracotta
setblock 377 200 313 minecraft:stripped_oak_log
fill 377 200 314 380 200 314 minecraft:red_terracotta
fill 377 200 317 418 203 317 minecraft:red_terracotta
setblock 378 200 277 minecraft:stripped_oak_log
fill 378 200 278 378 203 278 minecraft:red_terracotta
fill 378 200 282 382 200 282 minecraft:stripped_oak_log
fill 378 200 283 378 202 283 minecraft:red_terracotta
fill 378 200 287 382 200 287 minecraft:stripped_oak_log
fill 378 200 288 378 201 288 minecraft:red_terracotta
setblock 378 200 292 minecraft:stripped_oak_log
fill 378 200 293 378 203 293 minecraft:red_terracotta
fill 378 200 297 382 200 297 minecraft:stripped_oak_log
fill 378 200 298 378 203 298 minecraft:red_terracotta
fill 378 200 299 382 200 301 minecraft:stripped_oak_log
fill 378 200 306 382 200 307 minecraft:stripped_oak_log
setblock 378 200 308 minecraft:red_terracotta
setblock 378 200 312 minecraft:stripped_oak_log
fill 378 200 313 378 203 313 minecraft:red_terracotta
setblock 379 200 276 minecraft:stripped_oak_log
fill 379 200 277 379 203 277 minecraft:red_terracotta
fill 379 200 281 381 200 281 minecraft:stripped_oak_log
fill 379 200 283 382 200 286 minecraft:stripped_oak_log
fill 379 200 288 382 200 289 minecraft:stripped_oak_log
fill 379 200 291 382 200 291 minecraft:stripped_oak_log
fill 379 200 292 379 201 292 minecraft:red_terracotta
fill 379 200 296 382 200 296 minecraft:stripped_oak_log
fill 379 200 298 382 200 298 minecraft:stripped_oak_log
fill 379 200 308 382 200 309 minecraft:stripped_oak_log
setblock 379 200 311 minecraft:stripped_oak_log
fill 379 200 312 379 203 312 minecraft:red_terracotta
setblock 379 200 316 minecraft:stripped_oak_log
fill 380 200 276 380 203 276 minecraft:red_terracotta
fill 380 200 279 380 200 280 minecraft:stripped_oak_log
fill 380 200 290 382 200 290 minecraft:stripped_oak_log
fill 380 200 292 382 200 295 minecraft:stripped_oak_log
fill 380 200 310 382 200 310 minecraft:stripped_oak_log
setblock 380 200 315 minecraft:stripped_oak_log
fill 380 200 316 380 203 316 minecraft:red_terracotta
setblock 381 200 278 minecraft:red_terracotta
fill 381 200 311 416 200 312 minecraft:stripped_oak_log
setblock 381 200 314 minecraft:stripped_oak_log
fill 381 200 315 381 203 315 minecraft:red_terracotta
setblock 382 200 278 minecraft:stripped_oak_log
setblock 382 200 313 minecraft:stripped_oak_log
fill 382 200 314 382 203 314 minecraft:red_terracotta
setblock 383 200 277 minecraft:stripped_oak_log
setblock 383 200 278 minecraft:red_terracotta
fill 383 200 313 383 201 313 minecraft:red_terracotta
setblock 384 200 276 minecraft:stripped_oak_log
fill 384 200 277 384 203 277 minecraft:red_terracotta
setblock 384 200 316 minecraft:stripped_oak_log
fill 385 200 276 385 203 276 minecraft:red_terracotta
setblock 385 200 315 minecraft:stripped_oak_log
fill 385 200 316 385 203 316 minecraft:red_terracotta
fill 386 200 278 415 200 281 minecraft:stripped_oak_log
fill 386 200 313 386 200 314 minecraft:stripped_oak_log
fill 386 200 315 386 203 315 minecraft:red_terracotta
fill 387 200 277 398 200 277 minecraft:stripped_oak_log
setblock 387 200 286 minecraft:light[level=15]
setblock 387 200 294 minecraft:light[level=15]
setblock 387 200 310 minecraft:light[level=15]
fill 387 200 313 397 200 313 minecraft:stripped_oak_log
fill 387 200 314 387 201 314 minecraft:red_terracotta
setblock 389 200 276 minecraft:stripped_oak_log
setblock 389 200 316 minecraft:stripped_oak_log
fill 390 200 276 390 203 276 minecraft:red_terracotta
setblock 390 200 314 minecraft:red_terracotta
setblock 390 200 315 minecraft:stripped_oak_log
fill 390 200 316 390 203 316 minecraft:red_terracotta
setblock 391 200 314 minecraft:stripped_oak_log
fill 391 200 315 394 200 315 minecraft:red_terracotta
fill 392 200 276 393 200 276 minecraft:red_terracotta
fill 392 200 314 395 200 314 minecraft:red_terracotta
setblock 394 200 276 minecraft:stripped_oak_log
setblock 394 200 316 minecraft:stripped_oak_log
fill 395 200 276 398 200 276 minecraft:red_terracotta
setblock 395 200 286 minecraft:light[level=15]
setblock 395 200 294 minecraft:light[level=15]
setblock 395 200 302 minecraft:light[level=15]
setblock 395 200 310 minecraft:light[level=15]
setblock 395 200 315 minecraft:stripped_oak_log
fill 395 200 316 395 203 316 minecraft:red_terracotta
setblock 396 200 314 minecraft:stripped_oak_log
fill 396 200 315 396 203 315 minecraft:red_terracotta
fill 397 200 314 397 203 314 minecraft:red_terracotta
setblock 398 200 313 minecraft:red_terracotta
setblock 399 200 276 minecraft:stripped_oak_log
fill 399 200 277 400 202 277 minecraft:red_terracotta
setblock 399 200 316 minecraft:stripped_oak_log
fill 400 200 276 400 203 276 minecraft:red_terracotta
setblock 400 200 315 minecraft:stripped_oak_log
fill 400 200 316 400 203 316 minecraft:red_terracotta
fill 401 200 313 401 200 314 minecraft:stripped_oak_log
fill 401 200 315 401 203 315 minecraft:red_terracotta
setblock 402 200 277 minecraft:red_terracotta
fill 402 200 313 415 200 313 minecraft:stripped_oak_log
fill 402 200 314 402 201 314 minecraft:red_terracotta
fill 403 200 277 414 200 277 minecraft:stripped_oak_log
setblock 403 200 286 minecraft:light[level=15]
setblock 403 200 294 minecraft:light[level=15]
setblock 403 200 302 minecraft:light[level=15]
setblock 403 200 310 minecraft:light[level=15]
setblock 404 200 276 minecraft:stripped_oak_log
fill 404 200 314 416 200 314 minecraft:stripped_oak_log
setblock 404 200 316 minecraft:stripped_oak_log
fill 405 200 276 405 203 276 minecraft:red_terracotta
setblock 405 200 315 minecraft:stripped_oak_log
fill 405 200 316 405 203 316 minecraft:red_terracotta
setblock 406 200 315 minecraft:red_terracotta
fill 407 200 315 415 200 315 minecraft:stripped_oak_log
setblock 408 200 276 minecraft:red_terracotta
fill 409 200 276 410 200 276 minecraft:stripped_oak_log
fill 409 200 316 410 200 316 minecraft:stripped_oak_log
fill 411 200 276 413 200 276 minecraft:red_terracotta
setblock 411 200 286 minecraft:light[level=15]
setblock 411 200 294 minecraft:light[level=15]
setblock 411 200 302 minecraft:light[level=15]
setblock 411 200 310 minecraft:light[level=15]
fill 411 200 316 413 200 316 minecraft:red_terracotta
fill 412 200 282 414 200 310 minecraft:stripped_oak_log
setblock 414 200 276 minecraft:stripped_oak_log
setblock 414 200 316 minecraft:stripped_oak_log
fill 415 200 276 418 200 277 minecraft:red_terracotta
fill 415 200 282 415 200 288 minecraft:stripped_oak_log
setblock 415 200 290 minecraft:stripped_oak_log
fill 415 200 291 415 202 291 minecraft:red_terracotta
setblock 415 200 295 minecraft:stripped_oak_log
fill 415 200 296 415 203 296 minecraft:red_terracotta
fill 415 200 297 415 200 310 minecraft:stripped_oak_log
fill 415 200 316 415 203 316 minecraft:red_terracotta
setblock 416 200 278 minecraft:red_terracotta
setblock 416 200 279 minecraft:stripped_oak_log
fill 416 200 280 416 202 281 minecraft:red_terracotta
setblock 416 200 284 minecraft:stripped_oak_log
fill 416 200 285 416 203 285 minecraft:red_terracotta
setblock 416 200 289 minecraft:stripped_oak_log
fill 416 200 290 416 203 290 minecraft:red_terracotta
setblock 416 200 294 minecraft:stripped_oak_log
fill 416 200 295 416 203 295 minecraft:red_terracotta
fill 416 200 299 416 200 310 minecraft:stripped_oak_log
setblock 416 200 313 minecraft:red_terracotta
fill 416 200 315 416 203 315 minecraft:red_terracotta
setblock 417 200 278 minecraft:stripped_oak_log
fill 417 200 279 418 203 279 minecraft:red_terracotta
setblock 417 200 283 minecraft:stripped_oak_log
fill 417 200 284 418 203 284 minecraft:red_terracotta
setblock 417 200 288 minecraft:stripped_oak_log
fill 417 200 289 418 203 289 minecraft:red_terracotta
setblock 417 200 293 minecraft:stripped_oak_log
fill 417 200 294 418 203 294 minecraft:red_terracotta
setblock 417 200 298 minecraft:stripped_oak_log
fill 417 200 299 418 203 299 minecraft:red_terracotta
fill 417 200 302 417 200 308 minecraft:stripped_oak_log
fill 417 200 309 418 200 312 minecraft:red_terracotta
setblock 417 200 313 minecraft:stripped_oak_log
fill 417 200 314 418 203 314 minecraft:red_terracotta
fill 418 200 278 418 203 278 minecraft:red_terracotta
fill 418 200 280 418 203 283 minecraft:red_terracotta
fill 418 200 285 418 203 288 minecraft:red_terracotta
fill 418 200 290 418 203 293 minecraft:red_terracotta
fill 418 200 295 418 203 298 minecraft:red_terracotta
fill 418 200 300 418 203 308 minecraft:red_terracotta
fill 418 200 313 418 203 313 minecraft:red_terracotta
fill 418 200 315 418 203 316 minecraft:red_terracotta
setblock 377 201 277 minecraft:stripped_oak_log
fill 377 201 278 377 204 278 minecraft:red_terracotta
setblock 377 201 282 minecraft:stripped_oak_log
fill 377 201 283 377 204 283 minecraft:red_terracotta
setblock 377 201 287 minecraft:stripped_oak_log
fill 377 201 288 377 204 288 minecraft:red_terracotta
setblock 377 201 292 minecraft:stripped_oak_log
fill 377 201 293 377 204 293 minecraft:red_terracotta
setblock 377 201 296 minecraft:red_terracotta
setblock 377 201 297 minecraft:stripped_oak_log
fill 377 201 298 377 204 298 minecraft:red_terracotta
setblock 377 201 302 minecraft:stripped_oak_log
setblock 377 201 306 minecraft:red_terracotta
setblock 377 201 307 minecraft:stripped_oak_log
fill 377 201 308 377 204 308 minecraft:red_terracotta
setblock 377 201 312 minecraft:stripped_oak_log
fill 377 201 313 377 203 314 minecraft:red_terracotta
setblock 378 201 276 minecraft:stripped_oak_log
fill 378 201 277 378 204 277 minecraft:red_terracotta
setblock 378 201 281 minecraft:stripped_oak_log
fill 378 201 282 378 204 282 minecraft:red_terracotta
setblock 378 201 286 minecraft:stripped_oak_log
setblock 378 201 287 minecraft:red_terracotta
setblock 378 201 291 minecraft:stripped_oak_log
fill 378 201 292 378 203 292 minecraft:red_terracotta
setblock 378 201 296 minecraft:stripped_oak_log
fill 378 201 297 378 204 297 minecraft:red_terracotta
fill 378 201 299 378 202 299 minecraft:red_terracotta
setblock 378 201 311 minecraft:stripped_oak_log
fill 378 201 312 378 204 312 minecraft:red_terracotta
fill 378 201 314 379 201 314 minecraft:red_terracotta
setblock 378 201 316 minecraft:stripped_oak_log
fill 379 201 276 379 204 276 minecraft:red_terracotta
setblock 379 201 280 minecraft:stripped_oak_log
setblock 379 201 295 minecraft:stripped_oak_log
setblock 379 201 310 minecraft:stripped_oak_log
fill 379 201 311 379 202 311 minecraft:red_terracotta
setblock 379 201 315 minecraft:stripped_oak_log
fill 379 201 316 379 204 316 minecraft:red_terracotta
setblock 380 201 314 minecraft:stripped_oak_log
fill 380 201 315 380 204 315 minecraft:red_terracotta
setblock 381 201 278 minecraft:stripped_oak_log
setblock 381 201 313 minecraft:stripped_oak_log
fill 381 201 314 381 204 314 minecraft:red_terracotta
setblock 382 201 277 minecraft:stripped_oak_log
fill 382 201 278 382 202 278 minecraft:red_terracotta
fill 382 201 282 382 201 311 minecraft:orange_terracotta
setblock 382 201 313 minecraft:red_terracotta
setblock 383 201 276 minecraft:stripped_oak_log
fill 383 201 277 383 204 277 minecraft:red_terracotta
fill 383 201 278 383 218 278 minecraft:stripped_oak_log
fill 383 201 311 412 201 311 minecraft:orange_terracotta
setblock 383 201 316 minecraft:stripped_oak_log
fill 384 201 276 384 204 276 minecraft:red_terracotta
setblock 384 201 315 minecraft:stripped_oak_log
fill 384 201 316 384 204 316 minecraft:red_terracotta
setblock 385 201 314 minecraft:stripped_oak_log
fill 385 201 315 385 204 315 minecraft:red_terracotta
fill 386 201 281 412 201 281 minecraft:orange_terracotta
fill 386 201 314 386 202 314 minecraft:red_terracotta
setblock 388 201 276 minecraft:stripped_oak_log
setblock 388 201 316 minecraft:stripped_oak_log
fill 389 201 276 389 203 276 minecraft:red_terracotta
setblock 389 201 315 minecraft:stripped_oak_log
fill 389 201 316 389 204 316 minecraft:red_terracotta
fill 390 201 315 393 201 315 minecraft:red_terracotta
setblock 392 201 276 minecraft:red_terracotta
setblock 393 201 276 minecraft:stripped_oak_log
fill 393 201 314 394 201 314 minecraft:red_terracotta
setblock 393 201 316 minecraft:stripped_oak_log
fill 394 201 276 397 201 276 minecraft:red_terracotta
setblock 394 201 315 minecraft:stripped_oak_log
fill 394 201 316 394 204 316 minecraft:red_terracotta
setblock 395 201 314 minecraft:stripped_oak_log
fill 395 201 315 395 204 315 minecraft:red_terracotta
fill 396 201 314 396 203 314 minecraft:red_terracotta
setblock 398 201 276 minecraft:stripped_oak_log
fill 398 201 277 398 204 277 minecraft:red_terracotta
setblock 398 201 316 minecraft:stripped_oak_log
fill 399 201 276 399 204 276 minecraft:red_terracotta
setblock 399 201 315 minecraft:stripped_oak_log
fill 399 201 316 399 204 316 minecraft:red_terracotta
setblock 400 201 314 minecraft:stripped_oak_log
fill 400 201 315 400 204 315 minecraft:red_terracotta
fill 401 201 314 401 202 314 minecraft:red_terracotta
setblock 402 201 277 minecraft:stripped_oak_log
setblock 403 201 276 minecraft:stripped_oak_log
setblock 403 201 316 minecraft:stripped_oak_log
fill 404 201 276 404 204 276 minecraft:red_terracotta
setblock 404 201 315 minecraft:stripped_oak_log
fill 404 201 316 404 203 316 minecraft:red_terracotta
setblock 405 201 315 minecraft:red_terracotta
setblock 408 201 276 minecraft:stripped_oak_log
setblock 408 201 316 minecraft:stripped_oak_log
fill 409 201 276 412 201 276 minecraft:red_terracotta
fill 409 201 294 409 201 295 minecraft:shroomlight
fill 412 201 282 412 201 310 minecraft:orange_terracotta
setblock 412 201 316 minecraft:red_terracotta
setblock 413 201 276 minecraft:stripped_oak_log
setblock 413 201 316 minecraft:stripped_oak_log
fill 414 201 276 416 201 277 minecraft:red_terracotta
fill 414 201 316 414 204 316 minecraft:red_terracotta
setblock 415 201 289 minecraft:stripped_oak_log
setblock 415 201 290 minecraft:red_terracotta
setblock 415 201 293 minecraft:red_terracotta
setblock 415 201 294 minecraft:stripped_oak_log
fill 415 201 295 415 203 295 minecraft:red_terracotta
fill 415 201 315 415 203 315 minecraft:red_terracotta
setblock 416 201 278 minecraft:stripped_oak_log
fill 416 201 279 416 204 279 minecraft:red_terracotta
setblock 416 201 282 minecraft:red_terracotta
setblock 416 201 283 minecraft:stripped_oak_log
fill 416 201 284 416 204 284 minecraft:red_terracotta
setblock 416 201 288 minecraft:stripped_oak_log
fill 416 201 289 416 204 289 minecraft:red_terracotta
setblock 416 201 293 minecraft:stripped_oak_log
fill 416 201 294 416 204 294 minecraft:red_terracotta
setblock 416 201 298 minecraft:stripped_oak_log
fill 416 201 299 416 204 299 minecraft:red_terracotta
setblock 416 201 313 minecraft:stripped_oak_log
fill 416 201 314 416 203 314 minecraft:red_terracotta
fill 417 201 276 418 201 276 minecraft:red_terracotta
setblock 417 201 277 minecraft:stripped_oak_log
fill 417 201 278 417 204 278 minecraft:red_terracotta
setblock 417 201 282 minecraft:stripped_oak_log
fill 417 201 283 417 204 283 minecraft:red_terracotta
setblock 417 201 287 minecraft:stripped_oak_log
fill 417 201 288 417 204 288 minecraft:red_terracotta
setblock 417 201 292 minecraft:stripped_oak_log
fill 417 201 293 417 204 293 minecraft:red_terracotta
setblock 417 201 297 minecraft:stripped_oak_log
fill 417 201 298 417 204 298 minecraft:red_terracotta
setblock 417 201 302 minecraft:stripped_oak_log
fill 417 201 309 418 201 311 minecraft:red_terracotta
setblock 417 201 312 minecraft:stripped_oak_log
fill 417 201 313 417 204 313 minecraft:red_terracotta
fill 418 201 277 418 203 277 minecraft:red_terracotta
fill 418 201 312 418 203 312 minecraft:red_terracotta
setblock 377 202 276 minecraft:stripped_oak_log
fill 377 202 277 377 205 277 minecraft:red_terracotta
setblock 377 202 281 minecraft:stripped_oak_log
fill 377 202 282 377 205 282 minecraft:red_terracotta
setblock 377 202 286 minecraft:stripped_oak_log
fill 377 202 287 377 204 287 minecraft:red_terracotta
setblock 377 202 291 minecraft:stripped_oak_log
fill 377 202 292 377 205 292 minecraft:red_terracotta
setblock 377 202 296 minecraft:stripped_oak_log
fill 377 202 297 377 205 297 minecraft:red_terracotta
setblock 377 202 301 minecraft:stripped_oak_log
fill 377 202 302 377 204 303 minecraft:red_terracotta
fill 377 202 307 377 203 307 minecraft:red_terracotta
setblock 377 202 311 minecraft:stripped_oak_log
fill 377 202 312 377 205 312 minecraft:red_terracotta
setblock 377 202 316 minecraft:stripped_oak_log
fill 378 202 276 378 205 276 minecraft:red_terracotta
setblock 378 202 280 minecraft:stripped_oak_log
fill 378 202 281 378 205 281 minecraft:red_terracotta
setblock 378 202 290 minecraft:stripped_oak_log
fill 378 202 291 378 203 291 minecraft:red_terracotta
setblock 378 202 295 minecraft:stripped_oak_log
fill 378 202 296 378 205 296 minecraft:red_terracotta
setblock 378 202 310 minecraft:stripped_oak_log
fill 378 202 311 378 204 311 minecraft:red_terracotta
setblock 378 202 314 minecraft:red_terracotta
setblock 378 202 315 minecraft:stripped_oak_log
fill 378 202 316 378 205 316 minecraft:red_terracotta
setblock 379 202 279 minecraft:stripped_oak_log
setblock 379 202 280 minecraft:red_terracotta
setblock 379 202 314 minecraft:stripped_oak_log
fill 379 202 315 379 205 315 minecraft:red_terracotta
setblock 380 202 278 minecraft:stripped_oak_log
setblock 380 202 313 minecraft:stripped_oak_log
fill 380 202 314 380 205 314 minecraft:red_terracotta
setblock 381 202 277 minecraft:stripped_oak_log
fill 381 202 278 381 203 278 minecraft:red_terracotta
fill 381 202 294 381 203 294 minecraft:shroomlight
setblock 382 202 276 minecraft:stripped_oak_log
fill 382 202 277 382 205 277 minecraft:red_terracotta
setblock 382 202 316 minecraft:stripped_oak_log
fill 383 202 276 383 205 276 minecraft:red_terracotta
setblock 383 202 315 minecraft:stripped_oak_log
fill 383 202 316 383 205 316 minecraft:red_terracotta
setblock 384 202 314 minecraft:stripped_oak_log
fill 384 202 315 384 205 315 minecraft:red_terracotta
setblock 385 202 314 minecraft:red_terracotta
setblock 387 202 276 minecraft:stripped_oak_log
setblock 387 202 316 minecraft:stripped_oak_log
fill 388 202 276 388 203 276 minecraft:red_terracotta
setblock 388 202 315 minecraft:stripped_oak_log
fill 388 202 316 388 205 316 minecraft:red_terracotta
fill 389 202 315 392 202 315 minecraft:red_terracotta
setblock 392 202 276 minecraft:stripped_oak_log
setblock 392 202 316 minecraft:stripped_oak_log
fill 393 202 276 396 202 276 minecraft:red_terracotta
setblock 393 202 315 minecraft:stripped_oak_log
fill 393 202 316 393 205 316 minecraft:red_terracotta
setblock 394 202 314 minecraft:stripped_oak_log
fill 394 202 315 394 205 315 minecraft:red_terracotta
setblock 395 202 314 minecraft:red_terracotta
setblock 397 202 276 minecraft:stripped_oak_log
fill 397 202 277 397 205 277 minecraft:red_terracotta
setblock 397 202 316 minecraft:stripped_oak_log
fill 398 202 276 398 205 276 minecraft:red_terracotta
setblock 398 202 315 minecraft:stripped_oak_log
fill 398 202 316 398 205 316 minecraft:red_terracotta
setblock 399 202 314 minecraft:stripped_oak_log
fill 399 202 315 399 205 315 minecraft:red_terracotta
setblock 400 202 314 minecraft:red_terracotta
setblock 401 202 276 minecraft:red_terracotta
setblock 401 202 277 minecraft:stripped_oak_log
setblock 402 202 276 minecraft:stripped_oak_log
setblock 402 202 277 minecraft:red_terracotta
setblock 402 202 316 minecraft:stripped_oak_log
fill 403 202 276 403 205 276 minecraft:red_terracotta
setblock 403 202 315 minecraft:stripped_oak_log
fill 403 202 316 403 204 316 minecraft:red_terracotta
setblock 406 202 276 minecraft:red_terracotta
setblock 407 202 276 minecraft:stripped_oak_log
fill 408 202 276 411 202 276 minecraft:red_terracotta
setblock 409 202 294 minecraft:shroomlight
setblock 412 202 276 minecraft:stripped_oak_log
fill 412 202 306 412 204 306 minecraft:brown_terracotta
setblock 412 202 316 minecraft:stripped_oak_log
fill 413 202 276 415 202 277 minecraft:red_terracotta
fill 413 202 316 413 205 316 minecraft:red_terracotta
setblock 415 202 293 minecraft:stripped_oak_log
fill 415 202 294 415 203 294 minecraft:red_terracotta
setblock 416 202 276 minecraft:red_terracotta
setblock 416 202 277 minecraft:stripped_oak_log
fill 416 202 278 416 205 278 minecraft:red_terracotta
setblock 416 202 282 minecraft:stripped_oak_log
fill 416 202 283 416 205 283 minecraft:red_terracotta
setblock 416 202 287 minecraft:stripped_oak_log
fill 416 202 288 416 204 288 minecraft:red_terracotta
setblock 416 202 292 minecraft:stripped_oak_log
fill 416 202 293 416 205 293 minecraft:red_terracotta
setblock 416 202 297 minecraft:stripped_oak_log
fill 416 202 298 416 205 298 minecraft:red_terracotta
setblock 417 202 276 minecraft:stripped_oak_log
fill 417 202 277 417 205 277 minecraft:red_terracotta
setblock 417 202 281 minecraft:stripped_oak_log
fill 417 202 282 417 205 282 minecraft:red_terracotta
setblock 417 202 286 minecraft:stripped_oak_log
fill 417 202 287 417 205 287 minecraft:red_terracotta
setblock 417 202 291 minecraft:stripped_oak_log
fill 417 202 292 417 205 292 minecraft:red_terracotta
setblock 417 202 296 minecraft:stripped_oak_log
fill 417 202 297 417 205 297 minecraft:red_terracotta
setblock 417 202 300 minecraft:red_terracotta
setblock 417 202 301 minecraft:stripped_oak_log
fill 417 202 302 417 205 302 minecraft:red_terracotta
fill 417 202 310 418 202 310 minecraft:red_terracotta
setblock 417 202 311 minecraft:stripped_oak_log
fill 417 202 312 417 205 312 minecraft:red_terracotta
setblock 417 202 316 minecraft:stripped_oak_log
fill 418 202 276 418 203 276 minecraft:red_terracotta
fill 418 202 309 418 203 309 minecraft:red_terracotta
fill 418 202 311 418 203 311 minecraft:red_terracotta
fill 377 203 276 377 206 276 minecraft:red_terracotta
setblock 377 203 280 minecraft:stripped_oak_log
fill 377 203 281 377 206 281 minecraft:red_terracotta
setblock 377 203 285 minecraft:stripped_oak_log
fill 377 203 286 377 204 286 minecraft:red_terracotta
setblock 377 203 290 minecraft:stripped_oak_log
fill 377 203 291 377 205 291 minecraft:red_terracotta
setblock 377 203 295 minecraft:stripped_oak_log
fill 377 203 296 377 206 296 minecraft:red_terracotta
setblock 377 203 300 minecraft:stripped_oak_log
fill 377 203 301 377 206 301 minecraft:red_terracotta
setblock 377 203 310 minecraft:stripped_oak_log
fill 377 203 311 377 206 311 minecraft:red_terracotta
setblock 377 203 315 minecraft:stripped_oak_log
fill 377 203 316 377 206 316 minecraft:red_terracotta
setblock 378 203 279 minecraft:stripped_oak_log
fill 378 203 280 378 206 280 minecraft:red_terracotta
setblock 378 203 294 minecraft:stripped_oak_log
fill 378 203 295 378 205 295 minecraft:red_terracotta
setblock 378 203 299 minecraft:stripped_oak_log
setblock 378 203 310 minecraft:red_terracotta
setblock 378 203 314 minecraft:stripped_oak_log
fill 378 203 315 378 206 315 minecraft:red_terracotta
setblock 379 203 278 minecraft:stripped_oak_log
fill 379 203 279 379 206 279 minecraft:red_terracotta
setblock 379 203 313 minecraft:stripped_oak_log
fill 379 203 314 379 205 314 minecraft:red_terracotta
setblock 380 203 277 minecraft:stripped_oak_log
fill 380 203 278 380 205 278 minecraft:red_terracotta
setblock 381 203 276 minecraft:stripped_oak_log
fill 381 203 277 381 206 277 minecraft:red_terracotta
setblock 381 203 316 minecraft:stripped_oak_log
fill 382 203 276 382 206 276 minecraft:red_terracotta
fill 382 203 278 382 218 278 minecraft:stripped_oak_log
setblock 382 203 315 minecraft:stripped_oak_log
fill 382 203 316 382 206 316 minecraft:red_terracotta
setblock 383 203 314 minecraft:stripped_oak_log
fill 383 203 315 383 206 315 minecraft:red_terracotta
setblock 384 203 314 minecraft:red_terracotta
setblock 386 203 276 minecraft:stripped_oak_log
setblock 386 203 316 minecraft:stripped_oak_log
fill 387 203 276 387 204 276 minecraft:red_terracotta
setblock 387 203 315 minecraft:stripped_oak_log
fill 387 203 316 387 206 316 minecraft:red_terracotta
fill 388 203 315 391 203 315 minecraft:red_terracotta
setblock 391 203 276 minecraft:stripped_oak_log
setblock 391 203 316 minecraft:stripped_oak_log
fill 392 203 276 395 203 276 minecraft:red_terracotta
setblock 392 203 315 minecraft:stripped_oak_log
fill 392 203 316 392 206 316 minecraft:red_terracotta
fill 393 203 315 393 205 315 minecraft:red_terracotta
setblock 396 203 276 minecraft:stripped_oak_log
setblock 396 203 316 minecraft:stripped_oak_log
fill 397 203 276 397 206 276 minecraft:red_terracotta
setblock 397 203 315 minecraft:stripped_oak_log
fill 397 203 316 397 206 316 minecraft:red_terracotta
setblock 398 203 314 minecraft:stripped_oak_log
fill 398 203 315 398 205 315 minecraft:red_terracotta
setblock 399 203 277 minecraft:red_terracotta
setblock 400 203 277 minecraft:stripped_oak_log
setblock 401 203 276 minecraft:stripped_oak_log
setblock 401 203 277 minecraft:red_terracotta
setblock 401 203 316 minecraft:stripped_oak_log
fill 402 203 276 402 206 276 minecraft:red_terracotta
setblock 402 203 315 minecraft:stripped_oak_log
fill 402 203 316 402 205 316 minecraft:red_terracotta
fill 406 203 276 408 203 278 minecraft:terracotta
fill 409 203 276 410 203 276 minecraft:red_terracotta
setblock 411 203 276 minecraft:stripped_oak_log
fill 411 203 306 411 204 306 minecraft:brown_terracotta
fill 412 203 276 415 203 276 minecraft:red_terracotta
fill 412 203 305 412 204 305 minecraft:brown_terracotta
fill 412 203 307 412 204 307 minecraft:brown_terracotta
setblock 412 203 316 minecraft:red_terracotta
fill 413 203 277 414 203 277 minecraft:red_terracotta
fill 413 203 306 413 204 306 minecraft:brown_terracotta
setblock 415 203 277 minecraft:stripped_oak_log
fill 415 203 278 415 206 278 minecraft:red_terracotta
setblock 415 203 292 minecraft:stripped_oak_log
setblock 415 203 293 minecraft:red_terracotta
setblock 416 203 276 minecraft:stripped_oak_log
fill 416 203 277 416 206 277 minecraft:red_terracotta
setblock 416 203 280 minecraft:red_terracotta
setblock 416 203 281 minecraft:stripped_oak_log
fill 416 203 282 416 206 282 minecraft:red_terracotta
setblock 416 203 286 minecraft:stripped_oak_log
fill 416 203 287 416 204 287 minecraft:red_terracotta
setblock 416 203 291 minecraft:stripped_oak_log
fill 416 203 292 416 206 292 minecraft:red_terracotta
setblock 416 203 296 minecraft:stripped_oak_log
fill 416 203 297 416 206 297 minecraft:red_terracotta
setblock 416 203 316 minecraft:stripped_oak_log
fill 417 203 276 417 206 276 minecraft:red_terracotta
setblock 417 203 280 minecraft:stripped_oak_log
fill 417 203 281 417 206 281 minecraft:red_terracotta
setblock 417 203 285 minecraft:stripped_oak_log
fill 417 203 286 417 206 286 minecraft:red_terracotta
setblock 417 203 290 minecraft:stripped_oak_log
fill 417 203 291 417 206 291 minecraft:red_terracotta
setblock 417 203 295 minecraft:stripped_oak_log
fill 417 203 296 417 206 296 minecraft:red_terracotta
setblock 417 203 300 minecraft:stripped_oak_log
fill 417 203 301 417 206 301 minecraft:red_terracotta
setblock 417 203 311 minecraft:red_terracotta
setblock 417 203 315 minecraft:stripped_oak_log
fill 417 203 316 417 206 316 minecraft:red_terracotta
setblock 418 203 310 minecraft:red_terracotta
fill 376 204 275 376 207 317 minecraft:yellow_terracotta
fill 377 204 275 418 207 275 minecraft:yellow_terracotta
setblock 377 204 279 minecraft:stripped_oak_log
fill 377 204 280 377 207 280 minecraft:red_terracotta
setblock 377 204 284 minecraft:stripped_oak_log
fill 377 204 285 377 207 285 minecraft:red_terracotta
setblock 377 204 289 minecraft:stripped_oak_log
setblock 377 204 290 minecraft:red_terracotta
setblock 377 204 294 minecraft:stripped_oak_log
fill 377 204 295 377 207 295 minecraft:red_terracotta
setblock 377 204 299 minecraft:stripped_oak_log
fill 377 204 300 378 206 300 minecraft:red_terracotta
setblock 377 204 304 minecraft:stripped_oak_log
setblock 377 204 309 minecraft:stripped_oak_log
fill 377 204 310 377 207 310 minecraft:red_terracotta
setblock 377 204 313 minecraft:red_terracotta
setblock 377 204 314 minecraft:stripped_oak_log
fill 377 204 315 377 207 315 minecraft:red_terracotta
fill 377 204 317 418 207 317 minecraft:yellow_terracotta
setblock 378 204 278 minecraft:stripped_oak_log
fill 378 204 279 378 207 279 minecraft:red_terracotta
setblock 378 204 294 minecraft:red_terracotta
setblock 378 204 298 minecraft:stripped_oak_log
fill 378 204 299 378 207 299 minecraft:red_terracotta
setblock 378 204 313 minecraft:stripped_oak_log
fill 378 204 314 378 207 314 minecraft:red_terracotta
setblock 379 204 277 minecraft:stripped_oak_log
fill 379 204 278 379 207 278 minecraft:red_terracotta
setblock 379 204 285 minecraft:light[level=12]
setblock 379 204 292 minecraft:light[level=12]
setblock 379 204 299 minecraft:light[level=12]
setblock 379 204 306 minecraft:light[level=12]
setblock 379 204 313 minecraft:red_terracotta
setblock 380 204 276 minecraft:stripped_oak_log
fill 380 204 277 380 207 277 minecraft:red_terracotta
setblock 380 204 316 minecraft:stripped_oak_log
fill 381 204 276 381 207 276 minecraft:red_terracotta
fill 381 204 294 381 210 294 minecraft:brown_terracotta
setblock 381 204 315 minecraft:stripped_oak_log
fill 381 204 316 381 207 316 minecraft:red_terracotta
setblock 382 204 314 minecraft:stripped_oak_log
fill 382 204 315 382 206 315 minecraft:red_terracotta
fill 384 204 277 384 218 277 minecraft:stripped_oak_log
setblock 385 204 276 minecraft:stripped_oak_log
setblock 385 204 316 minecraft:stripped_oak_log
fill 386 204 276 386 205 276 minecraft:red_terracotta
setblock 386 204 278 minecraft:light[level=12]
setblock 386 204 285 minecraft:light[level=12]
setblock 386 204 292 minecraft:light[level=12]
setblock 386 204 306 minecraft:light[level=12]
setblock 386 204 313 minecraft:light[level=12]
setblock 386 204 315 minecraft:stripped_oak_log
fill 386 204 316 386 207 316 minecraft:red_terracotta
setblock 390 204 316 minecraft:stripped_oak_log
fill 391 204 276 394 204 276 minecraft:red_terracotta
fill 391 204 316 391 207 316 minecraft:red_terracotta
setblock 392 204 315 minecraft:red_terracotta
setblock 393 204 278 minecraft:light[level=12]
setblock 393 204 285 minecraft:light[level=12]
setblock 393 204 292 minecraft:light[level=12]
setblock 393 204 299 minecraft:light[level=12]
setblock 393 204 306 minecraft:light[level=12]
setblock 393 204 313 minecraft:light[level=12]
setblock 395 204 276 minecraft:stripped_oak_log
setblock 395 204 316 minecraft:stripped_oak_log
fill 396 204 276 396 207 276 minecraft:red_terracotta
setblock 396 204 315 minecraft:stripped_oak_log
fill 396 204 316 396 207 316 minecraft:red_terracotta
fill 397 204 315 397 206 315 minecraft:red_terracotta
setblock 399 204 277 minecraft:stripped_oak_log
setblock 400 204 276 minecraft:stripped_oak_log
setblock 400 204 277 minecraft:red_terracotta
setblock 400 204 278 minecraft:light[level=12]
setblock 400 204 285 minecraft:light[level=12]
setblock 400 204 292 minecraft:light[level=12]
setblock 400 204 299 minecraft:light[level=12]
setblock 400 204 306 minecraft:light[level=12]
setblock 400 204 313 minecraft:light[level=12]
setblock 400 204 316 minecraft:stripped_oak_log
fill 401 204 276 401 207 276 minecraft:red_terracotta
fill 401 204 316 401 206 316 minecraft:red_terracotta
setblock 405 204 276 minecraft:stripped_oak_log
fill 407 204 277 407 210 277 minecraft:green_concrete
setblock 407 204 278 minecraft:light[level=12]
setblock 407 204 285 minecraft:light[level=12]
setblock 407 204 292 minecraft:light[level=12]
setblock 407 204 299 minecraft:light[level=12]
setblock 407 204 306 minecraft:light[level=12]
setblock 407 204 313 minecraft:light[level=12]
setblock 409 204 276 minecraft:red_terracotta
setblock 410 204 276 minecraft:stripped_oak_log
fill 411 204 276 414 204 276 minecraft:red_terracotta
fill 412 204 277 413 204 277 minecraft:red_terracotta
setblock 414 204 277 minecraft:stripped_oak_log
setblock 414 204 278 minecraft:light[level=12]
setblock 414 204 285 minecraft:light[level=12]
setblock 414 204 292 minecraft:light[level=12]
setblock 414 204 299 minecraft:light[level=12]
setblock 414 204 306 minecraft:light[level=12]
setblock 414 204 313 minecraft:light[level=12]
setblock 415 204 276 minecraft:stripped_oak_log
fill 415 204 277 415 207 277 minecraft:red_terracotta
fill 415 204 279 415 205 279 minecraft:red_terracotta
setblock 415 204 316 minecraft:stripped_oak_log
fill 416 204 276 416 207 276 minecraft:red_terracotta
setblock 416 204 280 minecraft:stripped_oak_log
fill 416 204 281 416 207 281 minecraft:red_terracotta
setblock 416 204 285 minecraft:stripped_oak_log
setblock 416 204 286 minecraft:red_terracotta
setblock 416 204 290 minecraft:stripped_oak_log
fill 416 204 291 416 205 291 minecraft:red_terracotta
setblock 416 204 295 minecraft:stripped_oak_log
fill 416 204 296 416 207 296 minecraft:red_terracotta
setblock 416 204 315 minecraft:stripped_oak_log
fill 416 204 316 416 207 316 minecraft:red_terracotta
setblock 417 204 279 minecraft:stripped_oak_log
fill 417 204 280 417 207 280 minecraft:red_terracotta
setblock 417 204 284 minecraft:stripped_oak_log
fill 417 204 285 417 207 285 minecraft:red_terracotta
setblock 417 204 289 minecraft:stripped_oak_log
fill 417 204 290 417 207 290 minecraft:red_terracotta
setblock 417 204 294 minecraft:stripped_oak_log
fill 417 204 295 417 207 295 minecraft:red_terracotta
setblock 417 204 299 minecraft:stripped_oak_log
fill 417 204 300 417 207 300 minecraft:red_terracotta
setblock 417 204 314 minecraft:stripped_oak_log
fill 417 204 315 417 207 315 minecraft:red_terracotta
fill 418 204 276 418 207 316 minecraft:yellow_terracotta
setblock 377 205 278 minecraft:stripped_oak_log
fill 377 205 279 377 208 279 minecraft:red_terracotta
setblock 377 205 283 minecraft:stripped_oak_log
fill 377 205 284 377 208 284 minecraft:red_terracotta
setblock 377 205 293 minecraft:stripped_oak_log
fill 377 205 294 377 208 294 minecraft:red_terracotta
setblock 377 205 298 minecraft:stripped_oak_log
fill 377 205 299 377 208 299 minecraft:red_terracotta
setblock 377 205 302 minecraft:red_terracotta
setblock 377 205 303 minecraft:stripped_oak_log
fill 377 205 304 377 207 305 minecraft:red_terracotta
setblock 377 205 308 minecraft:stripped_oak_log
fill 377 205 309 377 208 309 minecraft:red_terracotta
setblock 377 205 313 minecraft:stripped_oak_log
fill 377 205 314 377 208 314 minecraft:red_terracotta
setblock 378 205 277 minecraft:stripped_oak_log
fill 378 205 278 378 208 278 minecraft:red_terracotta
setblock 378 205 282 minecraft:stripped_oak_log
setblock 378 205 297 minecraft:stripped_oak_log
fill 378 205 298 378 208 298 minecraft:red_terracotta
setblock 378 205 312 minecraft:stripped_oak_log
fill 378 205 313 378 208 313 minecraft:red_terracotta
setblock 379 205 276 minecraft:stripped_oak_log
fill 379 205 277 379 208 277 minecraft:red_terracotta
setblock 379 205 316 minecraft:stripped_oak_log
fill 380 205 276 380 208 276 minecraft:red_terracotta
fill 380 205 294 380 210 294 minecraft:brown_terracotta
setblock 380 205 315 minecraft:stripped_oak_log
fill 380 205 316 380 208 316 minecraft:red_terracotta
fill 381 205 295 381 210 295 minecraft:brown_terracotta
fill 381 205 315 381 207 315 minecraft:red_terracotta
fill 383 205 277 383 218 277 minecraft:stripped_oak_log
setblock 384 205 276 minecraft:stripped_oak_log
setblock 384 205 316 minecraft:stripped_oak_log
fill 385 205 276 385 206 276 minecraft:red_terracotta
fill 385 205 316 385 208 316 minecraft:red_terracotta
setblock 389 205 316 minecraft:stripped_oak_log
fill 390 205 316 390 208 316 minecraft:red_terracotta
fill 391 205 276 393 205 276 minecraft:red_terracotta
setblock 394 205 276 minecraft:stripped_oak_log
setblock 394 205 316 minecraft:stripped_oak_log
fill 395 205 276 395 208 276 minecraft:red_terracotta
setblock 395 205 315 minecraft:stripped_oak_log
fill 395 205 316 395 208 316 minecraft:red_terracotta
fill 396 205 277 396 206 277 minecraft:red_terracotta
fill 396 205 315 396 206 315 minecraft:red_terracotta
setblock 398 205 277 minecraft:stripped_oak_log
setblock 399 205 276 minecraft:stripped_oak_log
fill 399 205 277 399 206 277 minecraft:red_terracotta
setblock 399 205 316 minecraft:stripped_oak_log
fill 400 205 276 400 208 276 minecraft:red_terracotta
fill 400 205 316 400 207 316 minecraft:red_terracotta
setblock 404 205 276 minecraft:stripped_oak_log
setblock 409 205 276 minecraft:stripped_oak_log
fill 410 205 276 413 205 276 minecraft:red_terracotta
setblock 412 205 277 minecraft:red_terracotta
setblock 413 205 277 minecraft:stripped_oak_log
setblock 414 205 276 minecraft:stripped_oak_log
fill 414 205 277 414 207 278 minecraft:red_terracotta
setblock 414 205 316 minecraft:stripped_oak_log
fill 415 205 276 415 208 276 minecraft:red_terracotta
setblock 415 205 280 minecraft:stripped_oak_log
fill 415 205 316 415 208 316 minecraft:red_terracotta
setblock 416 205 279 minecraft:stripped_oak_log
fill 416 205 280 416 208 280 minecraft:red_terracotta
setblock 416 205 284 minecraft:stripped_oak_log
fill 416 205 285 416 208 285 minecraft:red_terracotta
setblock 416 205 290 minecraft:red_terracotta
setblock 416 205 294 minecraft:stripped_oak_log
fill 416 205 295 416 208 295 minecraft:red_terracotta
setblock 416 205 299 minecraft:stripped_oak_log
fill 416 205 300 416 208 300 minecraft:red_terracotta
fill 416 205 315 416 206 315 minecraft:red_terracotta
setblock 417 205 278 minecraft:stripped_oak_log
fill 417 205 279 417 208 279 minecraft:red_terracotta
setblock 417 205 283 minecraft:stripped_oak_log
fill 417 205 284 417 208 284 minecraft:red_terracotta
setblock 417 205 288 minecraft:stripped_oak_log
fill 417 205 289 417 208 289 minecraft:red_terracotta
setblock 417 205 293 minecraft:stripped_oak_log
fill 417 205 294 417 208 294 minecraft:red_terracotta
setblock 417 205 298 minecraft:stripped_oak_log
fill 417 205 299 417 208 299 minecraft:red_terracotta
setblock 417 205 313 minecraft:stripped_oak_log
fill 417 205 314 417 208 314 minecraft:red_terracotta
setblock 377 206 277 minecraft:stripped_oak_log
fill 377 206 278 377 209 278 minecraft:red_terracotta
setblock 377 206 282 minecraft:stripped_oak_log
fill 377 206 283 377 209 283 minecraft:red_terracotta
setblock 377 206 292 minecraft:stripped_oak_log
fill 377 206 293 377 207 293 minecraft:red_terracotta
setblock 377 206 297 minecraft:stripped_oak_log
fill 377 206 298 377 209 298 minecraft:red_terracotta
setblock 377 206 302 minecraft:stripped_oak_log
fill 377 206 303 377 209 303 minecraft:red_terracotta
setblock 377 206 306 minecraft:red_terracotta
setblock 377 206 307 minecraft:stripped_oak_log
fill 377 206 308 377 209 308 minecraft:red_terracotta
setblock 377 206 312 minecraft:stripped_oak_log
fill 377 206 313 377 209 313 minecraft:red_terracotta
setblock 378 206 276 minecraft:stripped_oak_log
fill 378 206 277 378 209 277 minecraft:red_terracotta
setblock 378 206 281 minecraft:stripped_oak_log
fill 378 206 282 378 209 282 minecraft:red_terracotta
setblock 378 206 297 minecraft:red_terracotta
setblock 378 206 312 minecraft:red_terracotta
setblock 378 206 316 minecraft:stripped_oak_log
fill 379 206 276 379 209 276 minecraft:red_terracotta
setblock 379 206 315 minecraft:stripped_oak_log
fill 379 206 316 379 209 316 minecraft:red_terracotta
fill 380 206 293 381 210 293 minecraft:brown_terracotta
fill 380 206 295 380 210 295 minecraft:brown_terracotta
fill 380 206 315 380 209 315 minecraft:red_terracotta
setblock 382 206 277 minecraft:stripped_oak_log
fill 382 206 294 382 210 294 minecraft:brown_terracotta
setblock 383 206 276 minecraft:stripped_oak_log
setblock 383 206 316 minecraft:stripped_oak_log
fill 384 206 276 384 208 276 minecraft:red_terracotta
fill 384 206 316 384 209 316 minecraft:red_terracotta
setblock 388 206 316 minecraft:stripped_oak_log
fill 389 206 316 389 209 316 minecraft:red_terracotta
fill 391 206 276 392 206 276 minecraft:red_terracotta
setblock 393 206 276 minecraft:stripped_oak_log
setblock 393 206 316 minecraft:stripped_oak_log
fill 394 206 276 394 209 276 minecraft:red_terracotta
fill 394 206 316 394 209 316 minecraft:red_terracotta
setblock 395 206 315 minecraft:red_terracotta
setblock 397 206 277 minecraft:stripped_oak_log
setblock 398 206 276 minecraft:stripped_oak_log
fill 398 206 277 398 209 277 minecraft:red_terracotta
setblock 398 206 316 minecraft:stripped_oak_log
fill 399 206 276 399 209 276 minecraft:red_terracotta
fill 399 206 316 399 208 316 minecraft:red_terracotta
setblock 403 206 276 minecraft:stripped_oak_log
fill 409 206 276 412 206 276 minecraft:red_terracotta
setblock 411 206 277 minecraft:red_terracotta
setblock 412 206 277 minecraft:stripped_oak_log
setblock 413 206 276 minecraft:stripped_oak_log
fill 413 206 277 413 208 278 minecraft:red_terracotta
setblock 413 206 316 minecraft:stripped_oak_log
fill 414 206 276 414 209 276 minecraft:red_terracotta
fill 414 206 316 414 209 316 minecraft:red_terracotta
setblock 415 206 279 minecraft:stripped_oak_log
fill 415 206 280 415 208 281 minecraft:red_terracotta
setblock 416 206 278 minecraft:stripped_oak_log
fill 416 206 279 416 209 279 minecraft:red_terracotta
setblock 416 206 283 minecraft:stripped_oak_log
fill 416 206 284 416 209 284 minecraft:red_terracotta
setblock 416 206 293 minecraft:stripped_oak_log
fill 416 206 294 416 207 294 minecraft:red_terracotta
setblock 416 206 298 minecraft:stripped_oak_log
fill 416 206 299 416 209 299 minecraft:red_terracotta
setblock 417 206 277 minecraft:stripped_oak_log
fill 417 206 278 417 209 278 minecraft:red_terracotta
setblock 417 206 282 minecraft:stripped_oak_log
fill 417 206 283 417 209 283 minecraft:red_terracotta
setblock 417 206 287 minecraft:stripped_oak_log
fill 417 206 288 417 209 288 minecraft:red_terracotta
setblock 417 206 292 minecraft:stripped_oak_log
fill 417 206 293 417 209 293 minecraft:red_terracotta
setblock 417 206 297 minecraft:stripped_oak_log
fill 417 206 298 417 209 298 minecraft:red_terracotta
setblock 417 206 302 minecraft:stripped_oak_log
fill 417 206 303 417 209 303 minecraft:red_terracotta
fill 417 206 313 417 209 313 minecraft:red_terracotta
setblock 377 207 276 minecraft:stripped_oak_log
fill 377 207 277 377 210 277 minecraft:red_terracotta
setblock 377 207 281 minecraft:stripped_oak_log
fill 377 207 282 377 210 282 minecraft:red_terracotta
setblock 377 207 296 minecraft:stripped_oak_log
fill 377 207 297 377 210 297 minecraft:red_terracotta
setblock 377 207 300 minecraft:red_terracotta
setblock 377 207 301 minecraft:stripped_oak_log
fill 377 207 302 378 209 302 minecraft:red_terracotta
setblock 377 207 306 minecraft:stripped_oak_log
fill 377 207 307 377 210 307 minecraft:red_terracotta
setblock 377 207 311 minecraft:stripped_oak_log
fill 377 207 312 377 210 312 minecraft:red_terracotta
setblock 377 207 316 minecraft:stripped_oak_log
fill 378 207 276 378 210 276 minecraft:red_terracotta
setblock 378 207 280 minecraft:stripped_oak_log
fill 378 207 281 378 210 281 minecraft:red_terracotta
setblock 378 207 300 minecraft:stripped_oak_log
fill 378 207 301 378 210 301 minecraft:red_terracotta
setblock 378 207 315 minecraft:stripped_oak_log
fill 378 207 316 378 210 316 minecraft:red_terracotta
fill 379 207 294 379 210 294 minecraft:brown_terracotta
fill 379 207 315 379 210 315 minecraft:red_terracotta
setblock 381 207 277 minecraft:stripped_oak_log
setblock 382 207 276 minecraft:stripped_oak_log
setblock 382 207 277 minecraft:red_terracotta
fill 382 207 293 382 210 293 minecraft:brown_terracotta
fill 382 207 295 382 210 295 minecraft:brown_terracotta
setblock 382 207 316 minecraft:stripped_oak_log
fill 383 207 276 383 210 276 minecraft:red_terracotta
fill 383 207 316 383 210 316 minecraft:red_terracotta
setblock 387 207 316 minecraft:stripped_oak_log
setblock 388 207 316 minecraft:red_terracotta
setblock 391 207 276 minecraft:red_terracotta
setblock 392 207 276 minecraft:stripped_oak_log
setblock 392 207 316 minecraft:stripped_oak_log
fill 393 207 276 393 210 276 minecraft:red_terracotta
fill 393 207 316 393 210 316 minecraft:red_terracotta
setblock 395 207 277 minecraft:red_terracotta
setblock 396 207 277 minecraft:stripped_oak_log
setblock 397 207 276 minecraft:stripped_oak_log
fill 397 207 277 397 210 277 minecraft:red_terracotta
setblock 397 207 316 minecraft:stripped_oak_log
fill 398 207 276 398 210 276 minecraft:red_terracotta
fill 398 207 316 398 209 316 minecraft:red_terracotta
setblock 402 207 276 minecraft:stripped_oak_log
fill 408 207 276 411 207 276 minecraft:red_terracotta
fill 408 207 277 408 209 277 minecraft:green_concrete
setblock 410 207 277 minecraft:red_terracotta
setblock 411 207 277 minecraft:stripped_oak_log
setblock 412 207 276 minecraft:stripped_oak_log
fill 412 207 277 412 209 278 minecraft:red_terracotta
fill 413 207 276 413 210 276 minecraft:red_terracotta
fill 413 207 316 413 210 316 minecraft:red_terracotta
setblock 415 207 278 minecraft:stripped_oak_log
fill 415 207 279 415 210 279 minecraft:red_terracotta
setblock 415 207 282 minecraft:red_terracotta
setblock 416 207 277 minecraft:stripped_oak_log
fill 416 207 278 416 210 278 minecraft:red_terracotta
setblock 416 207 282 minecraft:stripped_oak_log
fill 416 207 283 416 210 283 minecraft:red_terracotta
setblock 416 207 297 minecraft:stripped_oak_log
fill 416 207 298 416 210 298 minecraft:red_terracotta
setblock 417 207 276 minecraft:stripped_oak_log
fill 417 207 277 417 210 277 minecraft:red_terracotta
setblock 417 207 281 minecraft:stripped_oak_log
fill 417 207 282 417 210 282 minecraft:red_terracotta
setblock 417 207 286 minecraft:stripped_oak_log
fill 417 207 287 417 210 287 minecraft:red_terracotta
setblock 417 207 291 minecraft:stripped_oak_log
fill 417 207 292 417 210 292 minecraft:red_terracotta
setblock 417 207 296 minecraft:stripped_oak_log
fill 417 207 297 417 210 297 minecraft:red_terracotta
setblock 417 207 301 minecraft:stripped_oak_log
fill 417 207 302 417 210 302 minecraft:red_terracotta
fill 417 207 304 417 208 304 minecraft:red_terracotta
setblock 417 207 316 minecraft:stripped_oak_log
fill 376 208 275 376 211 317 minecraft:white_terracotta
fill 377 208 275 418 211 275 minecraft:white_terracotta
fill 377 208 276 377 211 276 minecraft:red_terracotta
setblock 377 208 280 minecraft:stripped_oak_log
fill 377 208 281 377 211 281 minecraft:red_terracotta
setblock 377 208 285 minecraft:stripped_oak_log
setblock 377 208 295 minecraft:stripped_oak_log
fill 377 208 296 377 211 296 minecraft:red_terracotta
setblock 377 208 300 minecraft:stripped_oak_log
fill 377 208 301 377 211 301 minecraft:red_terracotta
setblock 377 208 304 minecraft:red_terracotta
setblock 377 208 305 minecraft:stripped_oak_log
fill 377 208 306 377 211 306 minecraft:red_terracotta
setblock 377 208 310 minecraft:stripped_oak_log
fill 377 208 311 377 211 311 minecraft:red_terracotta
setblock 377 208 315 minecraft:stripped_oak_log
fill 377 208 316 377 211 316 minecraft:red_terracotta
fill 377 208 317 418 211 317 minecraft:white_terracotta
setblock 378 208 279 minecraft:stripped_oak_log
fill 378 208 280 378 211 280 minecraft:red_terracotta
setblock 378 208 299 minecraft:stripped_oak_log
fill 378 208 300 378 211 300 minecraft:red_terracotta
setblock 378 208 303 minecraft:red_terracotta
setblock 378 208 304 minecraft:stripped_oak_log
setblock 378 208 314 minecraft:stripped_oak_log
fill 378 208 315 378 211 315 minecraft:red_terracotta
setblock 379 208 278 minecraft:stripped_oak_log
setblock 379 208 286 minecraft:light[level=15]
fill 379 208 293 379 210 293 minecraft:brown_terracotta
fill 379 208 295 379 210 295 minecraft:brown_terracotta
setblock 379 208 302 minecraft:light[level=15]
setblock 379 208 310 minecraft:light[level=15]
setblock 380 208 277 minecraft:stripped_oak_log
fill 380 208 292 381 210 292 minecraft:brown_terracotta
fill 380 208 296 382 210 296 minecraft:brown_terracotta
setblock 381 208 276 minecraft:stripped_oak_log
fill 381 208 277 381 210 277 minecraft:red_terracotta
setblock 381 208 316 minecraft:stripped_oak_log
fill 382 208 276 382 211 276 minecraft:red_terracotta
fill 382 208 316 382 211 316 minecraft:red_terracotta
fill 383 208 294 383 210 294 minecraft:brown_terracotta
setblock 387 208 278 minecraft:light[level=15]
setblock 387 208 286 minecraft:light[level=15]
setblock 387 208 294 minecraft:light[level=15]
setblock 387 208 310 minecraft:light[level=15]
setblock 390 208 276 minecraft:red_terracotta
setblock 391 208 276 minecraft:stripped_oak_log
setblock 391 208 316 minecraft:stripped_oak_log
fill 392 208 276 392 211 276 minecraft:red_terracotta
fill 392 208 316 392 211 316 minecraft:red_terracotta
setblock 394 208 277 minecraft:red_terracotta
setblock 395 208 277 minecraft:stripped_oak_log
setblock 395 208 278 minecraft:light[level=15]
setblock 395 208 286 minecraft:light[level=15]
setblock 395 208 294 minecraft:light[level=15]
setblock 395 208 302 minecraft:light[level=15]
setblock 395 208 310 minecraft:light[level=15]
setblock 396 208 276 minecraft:stripped_oak_log
fill 396 208 277 396 211 277 minecraft:red_terracotta
setblock 396 208 316 minecraft:stripped_oak_log
fill 397 208 276 397 211 276 minecraft:red_terracotta
fill 397 208 316 397 211 316 minecraft:red_terracotta
setblock 401 208 276 minecraft:stripped_oak_log
fill 402 208 276 402 211 276 minecraft:red_terracotta
setblock 403 208 278 minecraft:light[level=15]
setblock 403 208 286 minecraft:light[level=15]
setblock 403 208 294 minecraft:light[level=15]
setblock 403 208 302 minecraft:light[level=15]
setblock 403 208 310 minecraft:light[level=15]
fill 407 208 276 410 208 276 minecraft:red_terracotta
setblock 410 208 277 minecraft:stripped_oak_log
setblock 411 208 276 minecraft:stripped_oak_log
fill 411 208 277 411 211 277 minecraft:red_terracotta
setblock 411 208 278 minecraft:light[level=15]
setblock 411 208 286 minecraft:light[level=15]
setblock 411 208 294 minecraft:light[level=15]
setblock 411 208 302 minecraft:light[level=15]
setblock 411 208 310 minecraft:light[level=15]
fill 412 208 276 412 211 276 minecraft:red_terracotta
fill 412 208 316 412 211 316 minecraft:red_terracotta
setblock 414 208 277 minecraft:red_terracotta
setblock 414 208 278 minecraft:stripped_oak_log
fill 414 208 279 414 211 279 minecraft:red_terracotta
setblock 415 208 277 minecraft:stripped_oak_log
fill 415 208 278 415 211 278 minecraft:red_terracotta
setblock 415 208 282 minecraft:stripped_oak_log
fill 415 208 283 415 211 283 minecraft:red_terracotta
setblock 416 208 276 minecraft:stripped_oak_log
fill 416 208 277 416 211 277 minecraft:red_terracotta
setblock 416 208 281 minecraft:stripped_oak_log
fill 416 208 282 416 211 282 minecraft:red_terracotta
setblock 416 208 286 minecraft:stripped_oak_log
setblock 416 208 296 minecraft:stripped_oak_log
fill 416 208 297 416 211 297 minecraft:red_terracotta
setblock 416 208 301 minecraft:stripped_oak_log
setblock 416 208 316 minecraft:stripped_oak_log
fill 417 208 276 417 211 276 minecraft:red_terracotta
setblock 417 208 280 minecraft:stripped_oak_log
fill 417 208 281 417 211 281 minecraft:red_terracotta
setblock 417 208 285 minecraft:stripped_oak_log
fill 417 208 286 417 211 286 minecraft:red_terracotta
setblock 417 208 290 minecraft:stripped_oak_log
fill 417 208 291 417 211 291 minecraft:red_terracotta
setblock 417 208 295 minecraft:stripped_oak_log
fill 417 208 296 417 211 296 minecraft:red_terracotta
setblock 417 208 300 minecraft:stripped_oak_log
fill 417 208 301 417 211 301 minecraft:red_terracotta
setblock 417 208 305 minecraft:stripped_oak_log
setblock 417 208 315 minecraft:stripped_oak_log
fill 417 208 316 417 211 316 minecraft:red_terracotta
fill 418 208 276 418 211 316 minecraft:white_terracotta
setblock 377 209 279 minecraft:stripped_oak_log
fill 377 209 280 377 212 280 minecraft:red_terracotta
setblock 377 209 284 minecraft:stripped_oak_log
fill 377 209 285 377 211 286 minecraft:red_terracotta
fill 377 209 295 377 211 295 minecraft:red_terracotta
setblock 377 209 299 minecraft:stripped_oak_log
fill 377 209 300 377 212 300 minecraft:red_terracotta
setblock 377 209 304 minecraft:stripped_oak_log
fill 377 209 305 378 211 305 minecraft:red_terracotta
setblock 377 209 309 minecraft:stripped_oak_log
fill 377 209 310 377 212 310 minecraft:red_terracotta
setblock 377 209 314 minecraft:stripped_oak_log
fill 377 209 315 377 212 315 minecraft:red_terracotta
setblock 378 209 278 minecraft:stripped_oak_log
fill 378 209 279 378 212 279 minecraft:red_terracotta
setblock 378 209 298 minecraft:stripped_oak_log
fill 378 209 299 378 212 299 minecraft:red_terracotta
setblock 378 209 303 minecraft:stripped_oak_log
fill 378 209 304 378 212 304 minecraft:red_terracotta
fill 378 209 306 378 210 306 minecraft:red_terracotta
setblock 378 209 313 minecraft:stripped_oak_log
fill 378 209 314 378 212 314 minecraft:red_terracotta
setblock 379 209 277 minecraft:stripped_oak_log
setblock 379 209 278 minecraft:red_terracotta
fill 379 209 292 379 210 292 minecraft:brown_terracotta
fill 379 209 296 379 210 296 minecraft:brown_terracotta
setblock 380 209 276 minecraft:stripped_oak_log
fill 380 209 277 380 212 277 minecraft:red_terracotta
setblock 380 209 316 minecraft:stripped_oak_log
fill 381 209 276 381 212 276 minecraft:red_terracotta
fill 381 209 316 381 212 316 minecraft:red_terracotta
fill 382 209 292 382 210 292 minecraft:brown_terracotta
fill 383 209 293 383 210 293 minecraft:brown_terracotta
fill 383 209 295 383 210 295 minecraft:brown_terracotta
setblock 390 209 276 minecraft:stripped_oak_log
setblock 390 209 316 minecraft:stripped_oak_log
fill 391 209 276 391 212 276 minecraft:red_terracotta
fill 391 209 316 391 212 316 minecraft:red_terracotta
setblock 393 209 277 minecraft:red_terracotta
setblock 394 209 277 minecraft:stripped_oak_log
setblock 395 209 276 minecraft:stripped_oak_log
fill 395 209 277 395 212 277 minecraft:red_terracotta
setblock 395 209 316 minecraft:stripped_oak_log
fill 396 209 276 396 212 276 minecraft:red_terracotta
fill 396 209 316 396 212 316 minecraft:red_terracotta
setblock 399 209 277 minecraft:stripped_oak_log
setblock 400 209 276 minecraft:stripped_oak_log
fill 401 209 276 401 212 276 minecraft:red_terracotta
fill 406 209 276 409 209 276 minecraft:red_terracotta
setblock 409 209 277 minecraft:stripped_oak_log
setblock 410 209 276 minecraft:stripped_oak_log
fill 410 209 277 410 212 277 minecraft:red_terracotta
fill 411 209 276 411 212 276 minecraft:red_terracotta
fill 411 209 278 411 210 278 minecraft:red_terracotta
setblock 413 209 277 minecraft:red_terracotta
setblock 413 209 278 minecraft:stripped_oak_log
fill 413 209 279 413 212 279 minecraft:red_terracotta
setblock 414 209 277 minecraft:stripped_oak_log
fill 414 209 278 414 212 278 minecraft:red_terracotta
fill 414 209 280 414 209 281 minecraft:red_terracotta
setblock 415 209 276 minecraft:stripped_oak_log
fill 415 209 277 415 212 277 minecraft:red_terracotta
setblock 415 209 280 minecraft:red_terracotta
setblock 415 209 281 minecraft:stripped_oak_log
fill 415 209 282 415 212 282 minecraft:red_terracotta
fill 415 209 284 415 210 284 minecraft:red_terracotta
setblock 415 209 316 minecraft:stripped_oak_log
fill 416 209 276 416 212 276 minecraft:red_terracotta
setblock 416 209 280 minecraft:stripped_oak_log
fill 416 209 281 416 212 281 minecraft:red_terracotta
setblock 416 209 285 minecraft:stripped_oak_log
fill 416 209 286 416 211 287 minecraft:red_terracotta
setblock 416 209 295 minecraft:stripped_oak_log
fill 416 209 296 416 210 296 minecraft:red_terracotta
setblock 416 209 300 minecraft:stripped_oak_log
fill 416 209 301 416 210 303 minecraft:red_terracotta
setblock 416 209 315 minecraft:stripped_oak_log
fill 416 209 316 416 212 316 minecraft:red_terracotta
setblock 417 209 279 minecraft:stripped_oak_log
fill 417 209 280 417 212 280 minecraft:red_terracotta
setblock 417 209 284 minecraft:stripped_oak_log
fill 417 209 285 417 212 285 minecraft:red_terracotta
setblock 417 209 289 minecraft:stripped_oak_log
fill 417 209 290 417 212 290 minecraft:red_terracotta
setblock 417 209 294 minecraft:stripped_oak_log
fill 417 209 295 417 212 295 minecraft:red_terracotta
setblock 417 209 299 minecraft:stripped_oak_log
fill 417 209 300 417 212 300 minecraft:red_terracotta
setblock 417 209 304 minecraft:stripped_oak_log
fill 417 209 305 417 210 307 minecraft:red_terracotta
fill 417 209 312 417 210 312 minecraft:red_terracotta
setblock 417 209 314 minecraft:stripped_oak_log
fill 417 209 315 417 212 315 minecraft:red_terracotta
setblock 377 210 278 minecraft:stripped_oak_log
fill 377 210 279 377 213 279 minecraft:red_terracotta
setblock 377 210 283 minecraft:stripped_oak_log
fill 377 210 284 377 213 284 minecraft:red_terracotta
setblock 377 210 298 minecraft:stripped_oak_log
fill 377 210 299 377 213 299 minecraft:red_terracotta
setblock 377 210 302 minecraft:red_terracotta
setblock 377 210 303 minecraft:stripped_oak_log
fill 377 210 304 377 213 304 minecraft:red_terracotta
setblock 377 210 308 minecraft:stripped_oak_log
fill 377 210 309 377 213 309 minecraft:red_terracotta
schedule function dropper:buildpart/68_6 1t
