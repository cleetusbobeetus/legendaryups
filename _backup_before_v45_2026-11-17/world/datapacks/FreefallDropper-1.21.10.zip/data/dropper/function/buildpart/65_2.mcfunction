fill 242 128 294 242 129 294 minecraft:cut_sandstone
fill 242 128 296 242 129 296 minecraft:cut_sandstone
fill 242 128 298 242 129 298 minecraft:cut_sandstone
fill 242 128 300 242 129 300 minecraft:cut_sandstone
fill 242 128 302 242 129 302 minecraft:cut_sandstone
fill 242 128 304 242 129 304 minecraft:cut_sandstone
fill 242 128 306 242 129 306 minecraft:cut_sandstone
fill 242 128 308 242 129 308 minecraft:cut_sandstone
fill 242 128 317 244 212 317 minecraft:sandstone
fill 249 128 275 249 216 275 minecraft:sandstone
fill 251 128 275 251 215 275 minecraft:sandstone
fill 265 128 275 265 216 275 minecraft:sandstone
fill 265 128 317 265 216 317 minecraft:sandstone
fill 267 128 281 267 129 281 minecraft:cut_sandstone
fill 267 128 283 267 129 283 minecraft:cut_sandstone
fill 267 128 285 267 129 285 minecraft:cut_sandstone
fill 267 128 287 267 129 287 minecraft:cut_sandstone
fill 267 128 289 267 129 289 minecraft:cut_sandstone
fill 267 128 291 267 129 291 minecraft:cut_sandstone
fill 268 128 282 268 129 282 minecraft:cut_sandstone
fill 268 128 284 268 129 284 minecraft:cut_sandstone
fill 268 128 286 268 129 286 minecraft:cut_sandstone
fill 268 128 288 268 129 288 minecraft:cut_sandstone
fill 268 128 290 268 129 290 minecraft:cut_sandstone
fill 269 128 281 269 129 281 minecraft:cut_sandstone
fill 269 128 283 269 129 283 minecraft:cut_sandstone
fill 269 128 285 269 129 285 minecraft:cut_sandstone
fill 269 128 287 269 129 287 minecraft:cut_sandstone
fill 269 128 289 269 129 289 minecraft:cut_sandstone
fill 269 128 291 269 129 291 minecraft:cut_sandstone
fill 269 128 317 270 133 317 minecraft:sandstone
fill 270 128 282 270 129 282 minecraft:cut_sandstone
fill 270 128 284 270 129 284 minecraft:cut_sandstone
fill 270 128 286 270 129 286 minecraft:cut_sandstone
fill 270 128 288 270 129 288 minecraft:cut_sandstone
fill 270 128 290 270 129 290 minecraft:cut_sandstone
fill 271 128 281 271 129 281 minecraft:cut_sandstone
fill 271 128 283 271 129 283 minecraft:cut_sandstone
fill 271 128 285 271 129 285 minecraft:cut_sandstone
fill 271 128 287 271 129 287 minecraft:cut_sandstone
fill 271 128 289 271 129 289 minecraft:cut_sandstone
fill 271 128 291 271 129 291 minecraft:cut_sandstone
fill 272 128 282 272 129 282 minecraft:cut_sandstone
fill 272 128 284 272 129 284 minecraft:cut_sandstone
fill 272 128 286 272 129 286 minecraft:cut_sandstone
fill 272 128 288 272 129 288 minecraft:cut_sandstone
fill 272 128 290 272 129 290 minecraft:cut_sandstone
fill 273 128 281 273 129 281 minecraft:cut_sandstone
fill 273 128 283 273 129 283 minecraft:cut_sandstone
fill 273 128 285 273 129 285 minecraft:cut_sandstone
fill 273 128 287 273 129 287 minecraft:cut_sandstone
fill 273 128 289 273 129 289 minecraft:cut_sandstone
fill 273 128 291 273 129 291 minecraft:cut_sandstone
fill 274 128 282 274 129 282 minecraft:cut_sandstone
fill 274 128 284 274 129 284 minecraft:cut_sandstone
fill 274 128 286 274 129 286 minecraft:cut_sandstone
fill 274 128 288 274 129 288 minecraft:cut_sandstone
fill 274 128 290 274 129 290 minecraft:cut_sandstone
fill 275 128 281 275 129 281 minecraft:cut_sandstone
fill 275 128 283 275 129 283 minecraft:cut_sandstone
fill 275 128 285 275 129 285 minecraft:cut_sandstone
fill 275 128 287 275 129 287 minecraft:cut_sandstone
fill 275 128 289 275 129 289 minecraft:cut_sandstone
fill 275 128 291 275 129 291 minecraft:cut_sandstone
fill 276 128 282 276 129 282 minecraft:cut_sandstone
fill 276 128 284 276 129 284 minecraft:cut_sandstone
fill 276 128 286 276 129 286 minecraft:cut_sandstone
fill 276 128 288 276 129 288 minecraft:cut_sandstone
fill 276 128 290 276 129 290 minecraft:cut_sandstone
fill 276 128 317 276 168 317 minecraft:sandstone
fill 277 128 275 277 216 275 minecraft:sandstone
fill 277 128 298 277 188 298 minecraft:sandstone
fill 277 128 304 277 195 304 minecraft:sandstone
fill 241 129 317 241 133 317 minecraft:sandstone
fill 258 129 275 260 170 275 minecraft:sandstone
setblock 261 129 275 minecraft:black_terracotta
fill 262 129 275 264 149 275 minecraft:sandstone
setblock 236 130 290 minecraft:glowstone
setblock 236 130 292 minecraft:glowstone
setblock 236 130 294 minecraft:glowstone
setblock 236 130 296 minecraft:glowstone
setblock 236 130 298 minecraft:glowstone
setblock 236 130 300 minecraft:glowstone
setblock 236 130 302 minecraft:glowstone
setblock 236 130 304 minecraft:glowstone
setblock 236 130 306 minecraft:glowstone
setblock 236 130 308 minecraft:glowstone
setblock 237 130 291 minecraft:glowstone
setblock 237 130 293 minecraft:glowstone
setblock 237 130 295 minecraft:glowstone
setblock 237 130 297 minecraft:glowstone
setblock 237 130 299 minecraft:glowstone
setblock 237 130 301 minecraft:glowstone
setblock 237 130 303 minecraft:glowstone
setblock 237 130 305 minecraft:glowstone
setblock 237 130 307 minecraft:glowstone
setblock 238 130 278 minecraft:light[level=15]
setblock 238 130 285 minecraft:light[level=12]
setblock 238 130 286 minecraft:light[level=15]
setblock 238 130 290 minecraft:glowstone
setblock 238 130 292 minecraft:glowstone
setblock 238 130 294 minecraft:glowstone
setblock 238 130 296 minecraft:glowstone
setblock 238 130 298 minecraft:glowstone
setblock 238 130 300 minecraft:glowstone
setblock 238 130 302 minecraft:glowstone
setblock 238 130 304 minecraft:glowstone
setblock 238 130 306 minecraft:glowstone
setblock 238 130 308 minecraft:glowstone
setblock 238 130 310 minecraft:light[level=15]
setblock 238 130 313 minecraft:light[level=12]
setblock 239 130 291 minecraft:glowstone
setblock 239 130 293 minecraft:glowstone
setblock 239 130 295 minecraft:glowstone
setblock 239 130 297 minecraft:glowstone
setblock 239 130 299 minecraft:glowstone
setblock 239 130 301 minecraft:glowstone
setblock 239 130 303 minecraft:glowstone
setblock 239 130 305 minecraft:glowstone
setblock 239 130 307 minecraft:glowstone
setblock 240 130 290 minecraft:glowstone
setblock 240 130 292 minecraft:glowstone
setblock 240 130 294 minecraft:glowstone
setblock 240 130 296 minecraft:glowstone
setblock 240 130 298 minecraft:glowstone
setblock 240 130 300 minecraft:glowstone
setblock 240 130 302 minecraft:glowstone
setblock 240 130 304 minecraft:glowstone
setblock 240 130 306 minecraft:glowstone
setblock 240 130 308 minecraft:glowstone
setblock 241 130 291 minecraft:glowstone
setblock 241 130 293 minecraft:glowstone
setblock 241 130 295 minecraft:glowstone
setblock 241 130 297 minecraft:glowstone
setblock 241 130 299 minecraft:glowstone
setblock 241 130 301 minecraft:glowstone
setblock 241 130 303 minecraft:glowstone
setblock 241 130 305 minecraft:glowstone
setblock 241 130 307 minecraft:glowstone
setblock 242 130 290 minecraft:glowstone
setblock 242 130 292 minecraft:glowstone
setblock 242 130 294 minecraft:glowstone
setblock 242 130 296 minecraft:glowstone
setblock 242 130 298 minecraft:glowstone
setblock 242 130 300 minecraft:glowstone
setblock 242 130 302 minecraft:glowstone
setblock 242 130 304 minecraft:glowstone
setblock 242 130 306 minecraft:glowstone
setblock 242 130 308 minecraft:glowstone
setblock 245 130 278 minecraft:light[level=12]
setblock 245 130 285 minecraft:light[level=12]
setblock 245 130 292 minecraft:light[level=12]
setblock 245 130 299 minecraft:light[level=12]
setblock 245 130 306 minecraft:light[level=12]
setblock 245 130 313 minecraft:light[level=12]
setblock 246 130 278 minecraft:light[level=15]
setblock 246 130 286 minecraft:light[level=15]
setblock 246 130 294 minecraft:light[level=15]
setblock 246 130 302 minecraft:light[level=15]
setblock 246 130 310 minecraft:light[level=15]
setblock 252 130 278 minecraft:light[level=12]
setblock 252 130 285 minecraft:light[level=12]
setblock 252 130 292 minecraft:light[level=12]
setblock 252 130 299 minecraft:light[level=12]
setblock 252 130 306 minecraft:light[level=12]
setblock 252 130 313 minecraft:light[level=12]
setblock 253 130 317 minecraft:orange_terracotta
setblock 254 130 278 minecraft:light[level=15]
setblock 254 130 286 minecraft:light[level=15]
setblock 254 130 294 minecraft:light[level=15]
setblock 254 130 302 minecraft:light[level=15]
setblock 254 130 310 minecraft:light[level=15]
setblock 259 130 278 minecraft:light[level=12]
setblock 259 130 285 minecraft:light[level=12]
setblock 259 130 292 minecraft:light[level=12]
setblock 259 130 299 minecraft:light[level=12]
setblock 259 130 306 minecraft:light[level=12]
setblock 259 130 313 minecraft:light[level=12]
fill 261 130 275 261 149 275 minecraft:sandstone
setblock 262 130 278 minecraft:light[level=15]
setblock 262 130 286 minecraft:light[level=15]
setblock 262 130 294 minecraft:light[level=15]
setblock 262 130 302 minecraft:light[level=15]
setblock 262 130 310 minecraft:light[level=15]
setblock 266 130 278 minecraft:light[level=12]
setblock 266 130 285 minecraft:light[level=12]
setblock 266 130 292 minecraft:light[level=12]
setblock 266 130 299 minecraft:light[level=12]
setblock 266 130 306 minecraft:light[level=12]
setblock 266 130 313 minecraft:light[level=12]
setblock 267 130 281 minecraft:glowstone
setblock 267 130 283 minecraft:glowstone
setblock 267 130 285 minecraft:glowstone
setblock 267 130 287 minecraft:glowstone
setblock 267 130 289 minecraft:glowstone
setblock 267 130 291 minecraft:glowstone
setblock 268 130 282 minecraft:glowstone
setblock 268 130 284 minecraft:glowstone
setblock 268 130 286 minecraft:glowstone
setblock 268 130 288 minecraft:glowstone
setblock 268 130 290 minecraft:glowstone
setblock 269 130 281 minecraft:glowstone
setblock 269 130 283 minecraft:glowstone
setblock 269 130 285 minecraft:glowstone
setblock 269 130 287 minecraft:glowstone
setblock 269 130 289 minecraft:glowstone
setblock 269 130 291 minecraft:glowstone
setblock 270 130 278 minecraft:light[level=15]
setblock 270 130 282 minecraft:glowstone
setblock 270 130 284 minecraft:glowstone
setblock 270 130 286 minecraft:glowstone
setblock 270 130 288 minecraft:glowstone
setblock 270 130 290 minecraft:glowstone
setblock 270 130 294 minecraft:light[level=15]
setblock 270 130 302 minecraft:light[level=15]
setblock 270 130 310 minecraft:light[level=15]
setblock 271 130 281 minecraft:glowstone
setblock 271 130 283 minecraft:glowstone
setblock 271 130 285 minecraft:glowstone
setblock 271 130 287 minecraft:glowstone
setblock 271 130 289 minecraft:glowstone
setblock 271 130 291 minecraft:glowstone
setblock 272 130 282 minecraft:glowstone
setblock 272 130 284 minecraft:glowstone
setblock 272 130 286 minecraft:glowstone
setblock 272 130 288 minecraft:glowstone
setblock 272 130 290 minecraft:glowstone
setblock 273 130 278 minecraft:light[level=12]
setblock 273 130 281 minecraft:glowstone
setblock 273 130 283 minecraft:glowstone
setblock 273 130 285 minecraft:glowstone
setblock 273 130 287 minecraft:glowstone
setblock 273 130 289 minecraft:glowstone
setblock 273 130 291 minecraft:glowstone
setblock 273 130 292 minecraft:light[level=12]
setblock 273 130 299 minecraft:light[level=12]
setblock 273 130 306 minecraft:light[level=12]
setblock 273 130 313 minecraft:light[level=12]
setblock 274 130 282 minecraft:glowstone
setblock 274 130 284 minecraft:glowstone
setblock 274 130 286 minecraft:glowstone
setblock 274 130 288 minecraft:glowstone
setblock 274 130 290 minecraft:glowstone
setblock 275 130 281 minecraft:glowstone
setblock 275 130 283 minecraft:glowstone
setblock 275 130 285 minecraft:glowstone
setblock 275 130 287 minecraft:glowstone
setblock 275 130 289 minecraft:glowstone
setblock 275 130 291 minecraft:glowstone
setblock 276 130 282 minecraft:glowstone
setblock 276 130 284 minecraft:glowstone
setblock 276 130 286 minecraft:glowstone
setblock 276 130 288 minecraft:glowstone
setblock 276 130 290 minecraft:glowstone
fill 277 130 283 277 154 286 minecraft:sandstone
setblock 277 130 287 minecraft:blue_terracotta
fill 236 131 290 236 132 290 minecraft:cut_sandstone
fill 236 131 292 236 132 292 minecraft:cut_sandstone
fill 236 131 294 236 132 294 minecraft:cut_sandstone
fill 236 131 296 236 132 296 minecraft:cut_sandstone
fill 236 131 298 236 132 298 minecraft:cut_sandstone
fill 236 131 300 236 132 300 minecraft:cut_sandstone
fill 236 131 302 236 132 302 minecraft:cut_sandstone
fill 236 131 304 236 132 304 minecraft:cut_sandstone
fill 236 131 306 236 132 306 minecraft:cut_sandstone
fill 236 131 308 236 132 308 minecraft:cut_sandstone
fill 237 131 291 237 132 291 minecraft:cut_sandstone
fill 237 131 293 237 132 293 minecraft:cut_sandstone
fill 237 131 295 237 132 295 minecraft:cut_sandstone
fill 237 131 297 237 132 297 minecraft:cut_sandstone
fill 237 131 299 237 132 299 minecraft:cut_sandstone
fill 237 131 301 237 132 301 minecraft:cut_sandstone
fill 237 131 303 237 132 303 minecraft:cut_sandstone
fill 237 131 305 237 132 305 minecraft:cut_sandstone
fill 237 131 307 237 132 307 minecraft:cut_sandstone
fill 238 131 290 238 132 290 minecraft:cut_sandstone
fill 238 131 292 238 132 292 minecraft:cut_sandstone
fill 238 131 294 238 132 294 minecraft:cut_sandstone
fill 238 131 296 238 132 296 minecraft:cut_sandstone
fill 238 131 298 238 132 298 minecraft:cut_sandstone
fill 238 131 300 238 132 300 minecraft:cut_sandstone
fill 238 131 302 238 132 302 minecraft:cut_sandstone
fill 238 131 304 238 132 304 minecraft:cut_sandstone
fill 238 131 306 238 132 306 minecraft:cut_sandstone
fill 238 131 308 238 132 308 minecraft:cut_sandstone
fill 239 131 291 239 132 291 minecraft:cut_sandstone
fill 239 131 293 239 132 293 minecraft:cut_sandstone
fill 239 131 295 239 132 295 minecraft:cut_sandstone
fill 239 131 297 239 132 297 minecraft:cut_sandstone
fill 239 131 299 239 132 299 minecraft:cut_sandstone
fill 239 131 301 239 132 301 minecraft:cut_sandstone
fill 239 131 303 239 132 303 minecraft:cut_sandstone
fill 239 131 305 239 132 305 minecraft:cut_sandstone
fill 239 131 307 239 132 307 minecraft:cut_sandstone
fill 240 131 290 240 132 290 minecraft:cut_sandstone
fill 240 131 292 240 132 292 minecraft:cut_sandstone
fill 240 131 294 240 132 294 minecraft:cut_sandstone
fill 240 131 296 240 132 296 minecraft:cut_sandstone
fill 240 131 298 240 132 298 minecraft:cut_sandstone
fill 240 131 300 240 132 300 minecraft:cut_sandstone
fill 240 131 302 240 132 302 minecraft:cut_sandstone
fill 240 131 304 240 132 304 minecraft:cut_sandstone
fill 240 131 306 240 132 306 minecraft:cut_sandstone
fill 240 131 308 240 132 308 minecraft:cut_sandstone
fill 241 131 291 241 132 291 minecraft:cut_sandstone
fill 241 131 293 241 132 293 minecraft:cut_sandstone
fill 241 131 295 241 132 295 minecraft:cut_sandstone
fill 241 131 297 241 132 297 minecraft:cut_sandstone
fill 241 131 299 241 132 299 minecraft:cut_sandstone
fill 241 131 301 241 132 301 minecraft:cut_sandstone
fill 241 131 303 241 132 303 minecraft:cut_sandstone
fill 241 131 305 241 132 305 minecraft:cut_sandstone
fill 241 131 307 241 132 307 minecraft:cut_sandstone
fill 242 131 290 242 132 290 minecraft:cut_sandstone
fill 242 131 292 242 132 292 minecraft:cut_sandstone
fill 242 131 294 242 132 294 minecraft:cut_sandstone
fill 242 131 296 242 132 296 minecraft:cut_sandstone
fill 242 131 298 242 132 298 minecraft:cut_sandstone
fill 242 131 300 242 132 300 minecraft:cut_sandstone
fill 242 131 302 242 132 302 minecraft:cut_sandstone
fill 242 131 304 242 132 304 minecraft:cut_sandstone
fill 242 131 306 242 132 306 minecraft:cut_sandstone
fill 242 131 308 242 132 308 minecraft:cut_sandstone
fill 243 131 311 249 131 315 minecraft:chiseled_sandstone
fill 253 131 317 253 148 317 minecraft:sandstone
fill 267 131 281 267 132 281 minecraft:cut_sandstone
fill 267 131 283 267 132 283 minecraft:cut_sandstone
fill 267 131 285 267 132 285 minecraft:cut_sandstone
fill 267 131 287 267 132 287 minecraft:cut_sandstone
fill 267 131 289 267 132 289 minecraft:cut_sandstone
fill 267 131 291 267 132 291 minecraft:cut_sandstone
fill 268 131 282 268 132 282 minecraft:cut_sandstone
fill 268 131 284 268 132 284 minecraft:cut_sandstone
fill 268 131 286 268 132 286 minecraft:cut_sandstone
fill 268 131 288 268 132 288 minecraft:cut_sandstone
fill 268 131 290 268 132 290 minecraft:cut_sandstone
fill 269 131 281 269 132 281 minecraft:cut_sandstone
fill 269 131 283 269 132 283 minecraft:cut_sandstone
fill 269 131 285 269 132 285 minecraft:cut_sandstone
fill 269 131 287 269 132 287 minecraft:cut_sandstone
fill 269 131 289 269 132 289 minecraft:cut_sandstone
fill 269 131 291 269 132 291 minecraft:cut_sandstone
fill 270 131 282 270 132 282 minecraft:cut_sandstone
fill 270 131 284 270 132 284 minecraft:cut_sandstone
fill 270 131 286 270 132 286 minecraft:cut_sandstone
fill 270 131 288 270 132 288 minecraft:cut_sandstone
fill 270 131 290 270 132 290 minecraft:cut_sandstone
fill 271 131 275 274 143 275 minecraft:sandstone
fill 271 131 281 271 132 281 minecraft:cut_sandstone
fill 271 131 283 271 132 283 minecraft:cut_sandstone
fill 271 131 285 271 132 285 minecraft:cut_sandstone
fill 271 131 287 271 132 287 minecraft:cut_sandstone
fill 271 131 289 271 132 289 minecraft:cut_sandstone
fill 271 131 291 271 132 291 minecraft:cut_sandstone
fill 272 131 282 272 132 282 minecraft:cut_sandstone
fill 272 131 284 272 132 284 minecraft:cut_sandstone
fill 272 131 286 272 132 286 minecraft:cut_sandstone
fill 272 131 288 272 132 288 minecraft:cut_sandstone
fill 272 131 290 272 132 290 minecraft:cut_sandstone
fill 273 131 281 273 132 281 minecraft:cut_sandstone
fill 273 131 283 273 132 283 minecraft:cut_sandstone
fill 273 131 285 273 132 285 minecraft:cut_sandstone
fill 273 131 287 273 132 287 minecraft:cut_sandstone
fill 273 131 289 273 132 289 minecraft:cut_sandstone
fill 273 131 291 273 132 291 minecraft:cut_sandstone
fill 274 131 282 274 132 282 minecraft:cut_sandstone
fill 274 131 284 274 132 284 minecraft:cut_sandstone
fill 274 131 286 274 132 286 minecraft:cut_sandstone
fill 274 131 288 274 132 288 minecraft:cut_sandstone
fill 274 131 290 274 132 290 minecraft:cut_sandstone
setblock 275 131 275 minecraft:blue_terracotta
fill 275 131 281 275 132 281 minecraft:cut_sandstone
fill 275 131 283 275 132 283 minecraft:cut_sandstone
fill 275 131 285 275 132 285 minecraft:cut_sandstone
fill 275 131 287 275 132 287 minecraft:cut_sandstone
fill 275 131 289 275 132 289 minecraft:cut_sandstone
fill 275 131 291 275 132 291 minecraft:cut_sandstone
fill 276 131 275 276 216 275 minecraft:sandstone
fill 276 131 282 276 132 282 minecraft:cut_sandstone
fill 276 131 284 276 132 284 minecraft:cut_sandstone
fill 276 131 286 276 132 286 minecraft:cut_sandstone
fill 276 131 288 276 132 288 minecraft:cut_sandstone
fill 276 131 290 276 132 290 minecraft:cut_sandstone
fill 277 131 287 277 148 287 minecraft:sandstone
fill 235 132 281 235 145 281 minecraft:sandstone
fill 235 132 282 235 132 283 minecraft:glowstone
fill 235 132 284 235 145 284 minecraft:sandstone
fill 235 132 293 235 145 293 minecraft:sandstone
fill 235 132 294 235 132 295 minecraft:glowstone
fill 235 132 296 235 145 296 minecraft:sandstone
fill 235 132 305 235 145 305 minecraft:sandstone
fill 235 132 306 235 132 307 minecraft:glowstone
fill 235 132 308 235 145 308 minecraft:sandstone
fill 235 132 317 235 145 317 minecraft:sandstone
fill 236 132 317 237 132 317 minecraft:glowstone
fill 238 132 317 238 145 317 minecraft:sandstone
fill 242 132 275 242 145 275 minecraft:sandstone
fill 243 132 275 244 132 275 minecraft:glowstone
fill 243 132 311 249 132 315 minecraft:cut_sandstone
fill 245 132 275 245 145 275 minecraft:sandstone
fill 247 132 317 247 145 317 minecraft:sandstone
fill 248 132 317 249 132 317 minecraft:glowstone
fill 250 132 317 250 145 317 minecraft:sandstone
fill 254 132 275 254 145 275 minecraft:sandstone
fill 255 132 275 256 132 275 minecraft:glowstone
fill 257 132 275 257 145 275 minecraft:sandstone
fill 259 132 317 259 140 317 minecraft:sandstone
fill 260 132 317 261 132 317 minecraft:glowstone
fill 262 132 317 262 145 317 minecraft:sandstone
fill 266 132 275 266 145 275 minecraft:sandstone
fill 267 132 275 268 132 275 minecraft:glowstone
fill 269 132 275 269 145 275 minecraft:sandstone
fill 271 132 317 271 145 317 minecraft:sandstone
fill 272 132 317 273 132 317 minecraft:glowstone
fill 274 132 317 274 145 317 minecraft:sandstone
fill 275 132 275 275 150 275 minecraft:sandstone
fill 277 132 276 277 145 276 minecraft:sandstone
fill 277 132 277 277 132 278 minecraft:glowstone
fill 277 132 279 277 135 279 minecraft:sandstone
fill 277 132 288 277 145 288 minecraft:sandstone
fill 277 132 289 277 132 290 minecraft:glowstone
fill 277 132 291 277 145 291 minecraft:sandstone
fill 277 132 300 277 145 300 minecraft:sandstone
fill 277 132 301 277 132 302 minecraft:glowstone
fill 277 132 303 277 134 303 minecraft:sandstone
fill 277 132 312 277 145 312 minecraft:sandstone
fill 277 132 313 277 132 314 minecraft:glowstone
fill 277 132 315 277 145 315 minecraft:sandstone
fill 235 133 282 235 145 283 minecraft:sandstone
fill 235 133 294 235 145 295 minecraft:sandstone
fill 235 133 306 235 134 307 minecraft:sandstone
setblock 236 133 290 minecraft:glowstone
setblock 236 133 292 minecraft:glowstone
setblock 236 133 294 minecraft:glowstone
setblock 236 133 296 minecraft:glowstone
setblock 236 133 298 minecraft:glowstone
setblock 236 133 300 minecraft:glowstone
setblock 236 133 302 minecraft:glowstone
setblock 236 133 304 minecraft:glowstone
setblock 236 133 306 minecraft:glowstone
setblock 236 133 308 minecraft:glowstone
fill 236 133 317 237 145 317 minecraft:sandstone
setblock 237 133 291 minecraft:glowstone
setblock 237 133 293 minecraft:glowstone
setblock 237 133 295 minecraft:glowstone
setblock 237 133 297 minecraft:glowstone
setblock 237 133 299 minecraft:glowstone
setblock 237 133 301 minecraft:glowstone
setblock 237 133 303 minecraft:glowstone
setblock 237 133 305 minecraft:glowstone
setblock 237 133 307 minecraft:glowstone
setblock 238 133 290 minecraft:glowstone
setblock 238 133 292 minecraft:glowstone
setblock 238 133 294 minecraft:glowstone
setblock 238 133 296 minecraft:glowstone
setblock 238 133 298 minecraft:glowstone
setblock 238 133 300 minecraft:glowstone
setblock 238 133 302 minecraft:glowstone
setblock 238 133 304 minecraft:glowstone
setblock 238 133 306 minecraft:glowstone
setblock 238 133 308 minecraft:glowstone
setblock 239 133 291 minecraft:glowstone
setblock 239 133 293 minecraft:glowstone
setblock 239 133 295 minecraft:glowstone
setblock 239 133 297 minecraft:glowstone
setblock 239 133 299 minecraft:glowstone
setblock 239 133 301 minecraft:glowstone
setblock 239 133 303 minecraft:glowstone
setblock 239 133 305 minecraft:glowstone
setblock 239 133 307 minecraft:glowstone
setblock 240 133 290 minecraft:glowstone
setblock 240 133 292 minecraft:glowstone
setblock 240 133 294 minecraft:glowstone
setblock 240 133 296 minecraft:glowstone
setblock 240 133 298 minecraft:glowstone
setblock 240 133 300 minecraft:glowstone
setblock 240 133 302 minecraft:glowstone
setblock 240 133 304 minecraft:glowstone
setblock 240 133 306 minecraft:glowstone
setblock 240 133 308 minecraft:glowstone
setblock 241 133 291 minecraft:glowstone
setblock 241 133 293 minecraft:glowstone
setblock 241 133 295 minecraft:glowstone
setblock 241 133 297 minecraft:glowstone
setblock 241 133 299 minecraft:glowstone
setblock 241 133 301 minecraft:glowstone
setblock 241 133 303 minecraft:glowstone
setblock 241 133 305 minecraft:glowstone
setblock 241 133 307 minecraft:glowstone
setblock 242 133 290 minecraft:glowstone
setblock 242 133 292 minecraft:glowstone
setblock 242 133 294 minecraft:glowstone
setblock 242 133 296 minecraft:glowstone
setblock 242 133 298 minecraft:glowstone
setblock 242 133 300 minecraft:glowstone
setblock 242 133 302 minecraft:glowstone
setblock 242 133 304 minecraft:glowstone
setblock 242 133 306 minecraft:glowstone
setblock 242 133 308 minecraft:glowstone
fill 243 133 275 244 135 275 minecraft:sandstone
fill 243 133 311 249 133 311 minecraft:lapis_block
fill 245 133 316 247 136 316 minecraft:glowstone
fill 248 133 317 249 145 317 minecraft:sandstone
fill 255 133 275 256 145 275 minecraft:sandstone
fill 260 133 317 261 145 317 minecraft:sandstone
fill 267 133 275 268 145 275 minecraft:sandstone
setblock 267 133 281 minecraft:glowstone
setblock 267 133 283 minecraft:glowstone
setblock 267 133 285 minecraft:glowstone
setblock 267 133 287 minecraft:glowstone
setblock 267 133 289 minecraft:glowstone
setblock 267 133 291 minecraft:glowstone
setblock 268 133 282 minecraft:glowstone
setblock 268 133 284 minecraft:glowstone
setblock 268 133 286 minecraft:glowstone
setblock 268 133 288 minecraft:glowstone
setblock 268 133 290 minecraft:glowstone
setblock 269 133 281 minecraft:glowstone
setblock 269 133 283 minecraft:glowstone
setblock 269 133 285 minecraft:glowstone
setblock 269 133 287 minecraft:glowstone
setblock 269 133 289 minecraft:glowstone
setblock 269 133 291 minecraft:glowstone
setblock 270 133 282 minecraft:glowstone
setblock 270 133 284 minecraft:glowstone
setblock 270 133 286 minecraft:glowstone
setblock 270 133 288 minecraft:glowstone
setblock 270 133 290 minecraft:glowstone
setblock 271 133 281 minecraft:glowstone
setblock 271 133 283 minecraft:glowstone
setblock 271 133 285 minecraft:glowstone
setblock 271 133 287 minecraft:glowstone
setblock 271 133 289 minecraft:glowstone
setblock 271 133 291 minecraft:glowstone
setblock 272 133 282 minecraft:glowstone
setblock 272 133 284 minecraft:glowstone
setblock 272 133 286 minecraft:glowstone
setblock 272 133 288 minecraft:glowstone
setblock 272 133 290 minecraft:glowstone
fill 272 133 317 273 145 317 minecraft:sandstone
setblock 273 133 281 minecraft:glowstone
setblock 273 133 283 minecraft:glowstone
setblock 273 133 285 minecraft:glowstone
setblock 273 133 287 minecraft:glowstone
setblock 273 133 289 minecraft:glowstone
setblock 273 133 291 minecraft:glowstone
setblock 274 133 282 minecraft:glowstone
setblock 274 133 284 minecraft:glowstone
setblock 274 133 286 minecraft:glowstone
setblock 274 133 288 minecraft:glowstone
setblock 274 133 290 minecraft:glowstone
setblock 275 133 281 minecraft:glowstone
setblock 275 133 283 minecraft:glowstone
setblock 275 133 285 minecraft:glowstone
setblock 275 133 287 minecraft:glowstone
setblock 275 133 289 minecraft:glowstone
setblock 275 133 291 minecraft:glowstone
setblock 276 133 282 minecraft:glowstone
setblock 276 133 284 minecraft:glowstone
setblock 276 133 286 minecraft:glowstone
setblock 276 133 288 minecraft:glowstone
setblock 276 133 290 minecraft:glowstone
fill 277 133 277 277 145 278 minecraft:sandstone
setblock 277 133 280 minecraft:lapis_block
fill 277 133 281 277 212 281 minecraft:sandstone
fill 277 133 289 277 139 290 minecraft:sandstone
fill 277 133 301 277 134 302 minecraft:sandstone
fill 277 133 313 277 138 314 minecraft:sandstone
fill 236 134 290 236 135 290 minecraft:cut_sandstone
fill 236 134 292 236 135 292 minecraft:cut_sandstone
fill 236 134 294 236 135 294 minecraft:cut_sandstone
fill 236 134 296 236 135 296 minecraft:cut_sandstone
fill 236 134 298 236 135 298 minecraft:cut_sandstone
fill 236 134 300 236 135 300 minecraft:cut_sandstone
fill 236 134 302 236 135 302 minecraft:cut_sandstone
fill 236 134 304 236 135 304 minecraft:cut_sandstone
fill 236 134 306 236 135 306 minecraft:cut_sandstone
fill 236 134 308 236 135 308 minecraft:cut_sandstone
fill 237 134 291 237 135 291 minecraft:cut_sandstone
fill 237 134 293 237 135 293 minecraft:cut_sandstone
fill 237 134 295 237 135 295 minecraft:cut_sandstone
fill 237 134 297 237 135 297 minecraft:cut_sandstone
fill 237 134 299 237 135 299 minecraft:cut_sandstone
fill 237 134 301 237 135 301 minecraft:cut_sandstone
fill 237 134 303 237 135 303 minecraft:cut_sandstone
fill 237 134 305 237 135 305 minecraft:cut_sandstone
fill 237 134 307 237 135 307 minecraft:cut_sandstone
fill 238 134 290 238 135 290 minecraft:cut_sandstone
fill 238 134 292 238 135 292 minecraft:cut_sandstone
fill 238 134 294 238 135 294 minecraft:cut_sandstone
fill 238 134 296 238 135 296 minecraft:cut_sandstone
fill 238 134 298 238 135 298 minecraft:cut_sandstone
fill 238 134 300 238 135 300 minecraft:cut_sandstone
fill 238 134 302 238 135 302 minecraft:cut_sandstone
fill 238 134 304 238 135 304 minecraft:cut_sandstone
fill 238 134 306 238 135 306 minecraft:cut_sandstone
fill 238 134 308 238 135 308 minecraft:cut_sandstone
fill 239 134 291 239 135 291 minecraft:cut_sandstone
fill 239 134 293 239 135 293 minecraft:cut_sandstone
fill 239 134 295 239 135 295 minecraft:cut_sandstone
fill 239 134 297 239 135 297 minecraft:cut_sandstone
fill 239 134 299 239 135 299 minecraft:cut_sandstone
fill 239 134 301 239 135 301 minecraft:cut_sandstone
fill 239 134 303 239 135 303 minecraft:cut_sandstone
fill 239 134 305 239 135 305 minecraft:cut_sandstone
fill 239 134 307 239 135 307 minecraft:cut_sandstone
fill 240 134 290 240 135 290 minecraft:cut_sandstone
fill 240 134 292 240 135 292 minecraft:cut_sandstone
fill 240 134 294 240 135 294 minecraft:cut_sandstone
fill 240 134 296 240 135 296 minecraft:cut_sandstone
fill 240 134 298 240 135 298 minecraft:cut_sandstone
fill 240 134 300 240 135 300 minecraft:cut_sandstone
fill 240 134 302 240 135 302 minecraft:cut_sandstone
fill 240 134 304 240 135 304 minecraft:cut_sandstone
fill 240 134 306 240 135 306 minecraft:cut_sandstone
fill 240 134 308 240 135 308 minecraft:cut_sandstone
fill 241 134 291 241 135 291 minecraft:cut_sandstone
fill 241 134 293 241 135 293 minecraft:cut_sandstone
fill 241 134 295 241 135 295 minecraft:cut_sandstone
fill 241 134 297 241 135 297 minecraft:cut_sandstone
fill 241 134 299 241 135 299 minecraft:cut_sandstone
fill 241 134 301 241 135 301 minecraft:cut_sandstone
fill 241 134 303 241 135 303 minecraft:cut_sandstone
fill 241 134 305 241 135 305 minecraft:cut_sandstone
fill 241 134 307 241 135 307 minecraft:cut_sandstone
setblock 241 134 317 minecraft:orange_terracotta
fill 242 134 290 242 135 290 minecraft:cut_sandstone
fill 242 134 292 242 135 292 minecraft:cut_sandstone
fill 242 134 294 242 135 294 minecraft:cut_sandstone
fill 242 134 296 242 135 296 minecraft:cut_sandstone
fill 242 134 298 242 135 298 minecraft:cut_sandstone
fill 242 134 300 242 135 300 minecraft:cut_sandstone
fill 242 134 302 242 135 302 minecraft:cut_sandstone
fill 242 134 304 242 135 304 minecraft:cut_sandstone
fill 242 134 306 242 135 306 minecraft:cut_sandstone
fill 242 134 308 242 135 308 minecraft:cut_sandstone
setblock 243 134 311 minecraft:cut_sandstone
setblock 246 134 311 minecraft:cut_sandstone
setblock 249 134 311 minecraft:cut_sandstone
fill 267 134 281 267 135 281 minecraft:cut_sandstone
fill 267 134 283 267 135 283 minecraft:cut_sandstone
fill 267 134 285 267 135 285 minecraft:cut_sandstone
fill 267 134 287 267 135 287 minecraft:cut_sandstone
fill 267 134 289 267 135 289 minecraft:cut_sandstone
fill 267 134 291 267 135 291 minecraft:cut_sandstone
fill 268 134 282 268 135 282 minecraft:cut_sandstone
fill 268 134 284 268 135 284 minecraft:cut_sandstone
fill 268 134 286 268 135 286 minecraft:cut_sandstone
fill 268 134 288 268 135 288 minecraft:cut_sandstone
fill 268 134 290 268 135 290 minecraft:cut_sandstone
fill 269 134 281 269 135 281 minecraft:cut_sandstone
fill 269 134 283 269 135 283 minecraft:cut_sandstone
fill 269 134 285 269 135 285 minecraft:cut_sandstone
fill 269 134 287 269 135 287 minecraft:cut_sandstone
fill 269 134 289 269 135 289 minecraft:cut_sandstone
fill 269 134 291 269 135 291 minecraft:cut_sandstone
setblock 269 134 317 minecraft:blue_terracotta
fill 270 134 282 270 135 282 minecraft:cut_sandstone
fill 270 134 284 270 135 284 minecraft:cut_sandstone
fill 270 134 286 270 135 286 minecraft:cut_sandstone
fill 270 134 288 270 135 288 minecraft:cut_sandstone
fill 270 134 290 270 135 290 minecraft:cut_sandstone
fill 270 134 317 270 214 317 minecraft:sandstone
fill 271 134 281 271 135 281 minecraft:cut_sandstone
fill 271 134 283 271 135 283 minecraft:cut_sandstone
fill 271 134 285 271 135 285 minecraft:cut_sandstone
fill 271 134 287 271 135 287 minecraft:cut_sandstone
fill 271 134 289 271 135 289 minecraft:cut_sandstone
fill 271 134 291 271 135 291 minecraft:cut_sandstone
fill 272 134 282 272 135 282 minecraft:cut_sandstone
fill 272 134 284 272 135 284 minecraft:cut_sandstone
fill 272 134 286 272 135 286 minecraft:cut_sandstone
fill 272 134 288 272 135 288 minecraft:cut_sandstone
fill 272 134 290 272 135 290 minecraft:cut_sandstone
fill 273 134 281 273 135 281 minecraft:cut_sandstone
fill 273 134 283 273 135 283 minecraft:cut_sandstone
fill 273 134 285 273 135 285 minecraft:cut_sandstone
fill 273 134 287 273 135 287 minecraft:cut_sandstone
fill 273 134 289 273 135 289 minecraft:cut_sandstone
fill 273 134 291 273 135 291 minecraft:cut_sandstone
fill 274 134 282 274 135 282 minecraft:cut_sandstone
fill 274 134 284 274 135 284 minecraft:cut_sandstone
fill 274 134 286 274 135 286 minecraft:cut_sandstone
fill 274 134 288 274 135 288 minecraft:cut_sandstone
fill 274 134 290 274 135 290 minecraft:cut_sandstone
fill 275 134 281 275 135 281 minecraft:cut_sandstone
fill 275 134 283 275 135 283 minecraft:cut_sandstone
fill 275 134 285 275 135 285 minecraft:cut_sandstone
fill 275 134 287 275 135 287 minecraft:cut_sandstone
fill 275 134 289 275 135 289 minecraft:cut_sandstone
fill 275 134 291 275 135 291 minecraft:cut_sandstone
fill 276 134 282 276 135 282 minecraft:cut_sandstone
fill 276 134 284 276 135 284 minecraft:cut_sandstone
fill 276 134 286 276 135 286 minecraft:cut_sandstone
fill 276 134 288 276 135 288 minecraft:cut_sandstone
fill 276 134 290 276 135 290 minecraft:cut_sandstone
fill 277 134 280 277 186 280 minecraft:sandstone
setblock 235 135 289 minecraft:lapis_block
fill 235 135 290 235 162 291 minecraft:sandstone
fill 235 135 301 235 162 301 minecraft:sandstone
setblock 235 135 302 minecraft:orange_terracotta
fill 235 135 306 235 145 306 minecraft:sandstone
setblock 235 135 307 minecraft:orange_terracotta
fill 241 135 317 241 212 317 minecraft:sandstone
fill 269 135 317 269 173 317 minecraft:sandstone
setblock 277 135 301 minecraft:orange_terracotta
fill 277 135 302 277 145 302 minecraft:sandstone
setblock 277 135 303 minecraft:black_terracotta
fill 235 136 289 235 138 289 minecraft:sandstone
fill 235 136 302 235 157 302 minecraft:sandstone
fill 235 136 307 235 145 307 minecraft:sandstone
setblock 236 136 290 minecraft:glowstone
setblock 236 136 292 minecraft:glowstone
setblock 236 136 294 minecraft:glowstone
setblock 236 136 296 minecraft:glowstone
setblock 236 136 298 minecraft:glowstone
setblock 236 136 300 minecraft:glowstone
setblock 236 136 302 minecraft:glowstone
setblock 236 136 304 minecraft:glowstone
setblock 236 136 306 minecraft:glowstone
setblock 236 136 308 minecraft:glowstone
setblock 237 136 291 minecraft:glowstone
setblock 237 136 293 minecraft:glowstone
setblock 237 136 295 minecraft:glowstone
setblock 237 136 297 minecraft:glowstone
setblock 237 136 299 minecraft:glowstone
setblock 237 136 301 minecraft:glowstone
setblock 237 136 303 minecraft:glowstone
setblock 237 136 305 minecraft:glowstone
setblock 237 136 307 minecraft:glowstone
setblock 238 136 278 minecraft:light[level=12]
setblock 238 136 285 minecraft:light[level=12]
setblock 238 136 290 minecraft:glowstone
setblock 238 136 292 minecraft:glowstone
setblock 238 136 294 minecraft:glowstone
setblock 238 136 296 minecraft:glowstone
setblock 238 136 298 minecraft:glowstone
setblock 238 136 300 minecraft:glowstone
setblock 238 136 302 minecraft:glowstone
setblock 238 136 304 minecraft:glowstone
setblock 238 136 306 minecraft:glowstone
setblock 238 136 308 minecraft:glowstone
setblock 238 136 313 minecraft:light[level=12]
setblock 239 136 291 minecraft:glowstone
setblock 239 136 293 minecraft:glowstone
setblock 239 136 295 minecraft:glowstone
setblock 239 136 297 minecraft:glowstone
setblock 239 136 299 minecraft:glowstone
setblock 239 136 301 minecraft:glowstone
setblock 239 136 303 minecraft:glowstone
setblock 239 136 305 minecraft:glowstone
setblock 239 136 307 minecraft:glowstone
setblock 240 136 290 minecraft:glowstone
setblock 240 136 292 minecraft:glowstone
setblock 240 136 294 minecraft:glowstone
setblock 240 136 296 minecraft:glowstone
setblock 240 136 298 minecraft:glowstone
setblock 240 136 300 minecraft:glowstone
setblock 240 136 302 minecraft:glowstone
setblock 240 136 304 minecraft:glowstone
setblock 240 136 306 minecraft:glowstone
setblock 240 136 308 minecraft:glowstone
setblock 241 136 291 minecraft:glowstone
setblock 241 136 293 minecraft:glowstone
setblock 241 136 295 minecraft:glowstone
setblock 241 136 297 minecraft:glowstone
setblock 241 136 299 minecraft:glowstone
setblock 241 136 301 minecraft:glowstone
setblock 241 136 303 minecraft:glowstone
setblock 241 136 305 minecraft:glowstone
setblock 241 136 307 minecraft:glowstone
setblock 242 136 290 minecraft:glowstone
setblock 242 136 292 minecraft:glowstone
setblock 242 136 294 minecraft:glowstone
setblock 242 136 296 minecraft:glowstone
setblock 242 136 298 minecraft:glowstone
setblock 242 136 300 minecraft:glowstone
setblock 242 136 302 minecraft:glowstone
setblock 242 136 304 minecraft:glowstone
setblock 242 136 306 minecraft:glowstone
setblock 242 136 308 minecraft:glowstone
fill 243 136 275 243 145 275 minecraft:sandstone
setblock 244 136 275 minecraft:blue_terracotta
setblock 245 136 278 minecraft:light[level=12]
setblock 245 136 285 minecraft:light[level=12]
setblock 245 136 292 minecraft:light[level=12]
setblock 245 136 299 minecraft:light[level=12]
setblock 245 136 306 minecraft:light[level=12]
setblock 245 136 313 minecraft:light[level=12]
setblock 252 136 278 minecraft:light[level=12]
setblock 252 136 285 minecraft:light[level=12]
setblock 252 136 292 minecraft:light[level=12]
setblock 252 136 299 minecraft:light[level=12]
setblock 252 136 306 minecraft:light[level=12]
setblock 252 136 313 minecraft:light[level=12]
setblock 259 136 278 minecraft:light[level=12]
setblock 259 136 285 minecraft:light[level=12]
setblock 259 136 292 minecraft:light[level=12]
setblock 259 136 299 minecraft:light[level=12]
setblock 259 136 306 minecraft:light[level=12]
setblock 259 136 313 minecraft:light[level=12]
setblock 266 136 278 minecraft:light[level=12]
setblock 266 136 285 minecraft:light[level=12]
setblock 266 136 292 minecraft:light[level=12]
setblock 266 136 299 minecraft:light[level=12]
setblock 266 136 306 minecraft:light[level=12]
setblock 266 136 313 minecraft:light[level=12]
fill 266 136 317 267 213 317 minecraft:sandstone
setblock 267 136 281 minecraft:glowstone
setblock 267 136 283 minecraft:glowstone
setblock 267 136 285 minecraft:glowstone
setblock 267 136 287 minecraft:glowstone
setblock 267 136 289 minecraft:glowstone
setblock 267 136 291 minecraft:glowstone
setblock 268 136 282 minecraft:glowstone
setblock 268 136 284 minecraft:glowstone
setblock 268 136 286 minecraft:glowstone
setblock 268 136 288 minecraft:glowstone
setblock 268 136 290 minecraft:glowstone
setblock 268 136 317 minecraft:black_terracotta
setblock 269 136 281 minecraft:glowstone
setblock 269 136 283 minecraft:glowstone
setblock 269 136 285 minecraft:glowstone
setblock 269 136 287 minecraft:glowstone
setblock 269 136 289 minecraft:glowstone
setblock 269 136 291 minecraft:glowstone
setblock 270 136 282 minecraft:glowstone
setblock 270 136 284 minecraft:glowstone
setblock 270 136 286 minecraft:glowstone
setblock 270 136 288 minecraft:glowstone
setblock 270 136 290 minecraft:glowstone
setblock 271 136 281 minecraft:glowstone
setblock 271 136 283 minecraft:glowstone
setblock 271 136 285 minecraft:glowstone
setblock 271 136 287 minecraft:glowstone
setblock 271 136 289 minecraft:glowstone
setblock 271 136 291 minecraft:glowstone
setblock 272 136 282 minecraft:glowstone
setblock 272 136 284 minecraft:glowstone
setblock 272 136 286 minecraft:glowstone
setblock 272 136 288 minecraft:glowstone
setblock 272 136 290 minecraft:glowstone
setblock 273 136 278 minecraft:light[level=12]
setblock 273 136 281 minecraft:glowstone
setblock 273 136 283 minecraft:glowstone
setblock 273 136 285 minecraft:glowstone
setblock 273 136 287 minecraft:glowstone
setblock 273 136 289 minecraft:glowstone
setblock 273 136 291 minecraft:glowstone
setblock 273 136 292 minecraft:light[level=12]
setblock 273 136 299 minecraft:light[level=12]
setblock 273 136 306 minecraft:light[level=12]
setblock 273 136 313 minecraft:light[level=12]
setblock 274 136 282 minecraft:glowstone
setblock 274 136 284 minecraft:glowstone
setblock 274 136 286 minecraft:glowstone
setblock 274 136 288 minecraft:glowstone
setblock 274 136 290 minecraft:glowstone
setblock 275 136 281 minecraft:glowstone
setblock 275 136 283 minecraft:glowstone
setblock 275 136 285 minecraft:glowstone
setblock 275 136 287 minecraft:glowstone
setblock 275 136 289 minecraft:glowstone
setblock 275 136 291 minecraft:glowstone
setblock 276 136 282 minecraft:glowstone
setblock 276 136 284 minecraft:glowstone
setblock 276 136 286 minecraft:glowstone
setblock 276 136 288 minecraft:glowstone
setblock 276 136 290 minecraft:glowstone
setblock 277 136 279 minecraft:black_terracotta
fill 277 136 301 277 145 301 minecraft:sandstone
fill 277 136 303 277 145 303 minecraft:sandstone
fill 236 137 290 236 138 290 minecraft:cut_sandstone
fill 236 137 292 236 138 292 minecraft:cut_sandstone
fill 236 137 294 236 138 294 minecraft:cut_sandstone
fill 236 137 296 236 138 296 minecraft:cut_sandstone
fill 236 137 298 236 138 298 minecraft:cut_sandstone
fill 236 137 300 236 138 300 minecraft:cut_sandstone
fill 236 137 302 236 138 302 minecraft:cut_sandstone
fill 236 137 304 236 138 304 minecraft:cut_sandstone
fill 236 137 306 236 138 306 minecraft:cut_sandstone
fill 236 137 308 236 138 308 minecraft:cut_sandstone
fill 237 137 291 237 138 291 minecraft:cut_sandstone
fill 237 137 293 237 138 293 minecraft:cut_sandstone
fill 237 137 295 237 138 295 minecraft:cut_sandstone
fill 237 137 297 237 138 297 minecraft:cut_sandstone
fill 237 137 299 237 138 299 minecraft:cut_sandstone
fill 237 137 301 237 138 301 minecraft:cut_sandstone
fill 237 137 303 237 138 303 minecraft:cut_sandstone
fill 237 137 305 237 138 305 minecraft:cut_sandstone
fill 237 137 307 237 138 307 minecraft:cut_sandstone
fill 237 137 309 237 139 309 minecraft:blue_wool
fill 238 137 290 238 138 290 minecraft:cut_sandstone
fill 238 137 292 238 138 292 minecraft:cut_sandstone
fill 238 137 294 238 138 294 minecraft:cut_sandstone
fill 238 137 296 238 138 296 minecraft:cut_sandstone
fill 238 137 298 238 138 298 minecraft:cut_sandstone
fill 238 137 300 238 138 300 minecraft:cut_sandstone
fill 238 137 302 238 138 302 minecraft:cut_sandstone
fill 238 137 304 238 138 304 minecraft:cut_sandstone
fill 238 137 306 238 138 306 minecraft:cut_sandstone
fill 238 137 308 238 138 308 minecraft:cut_sandstone
fill 239 137 291 239 138 291 minecraft:cut_sandstone
fill 239 137 293 239 138 293 minecraft:cut_sandstone
fill 239 137 295 239 138 295 minecraft:cut_sandstone
fill 239 137 297 239 138 297 minecraft:cut_sandstone
fill 239 137 299 239 138 299 minecraft:cut_sandstone
fill 239 137 301 239 138 301 minecraft:cut_sandstone
fill 239 137 303 239 138 303 minecraft:cut_sandstone
fill 239 137 305 239 138 305 minecraft:cut_sandstone
fill 239 137 307 239 138 307 minecraft:cut_sandstone
fill 240 137 290 240 138 290 minecraft:cut_sandstone
fill 240 137 292 240 138 292 minecraft:cut_sandstone
fill 240 137 294 240 138 294 minecraft:cut_sandstone
fill 240 137 296 240 138 296 minecraft:cut_sandstone
fill 240 137 298 240 138 298 minecraft:cut_sandstone
fill 240 137 300 240 138 300 minecraft:cut_sandstone
fill 240 137 302 240 138 302 minecraft:cut_sandstone
fill 240 137 304 240 138 304 minecraft:cut_sandstone
fill 240 137 306 240 138 306 minecraft:cut_sandstone
fill 240 137 308 240 138 308 minecraft:cut_sandstone
fill 241 137 291 241 138 291 minecraft:cut_sandstone
fill 241 137 293 241 138 293 minecraft:cut_sandstone
fill 241 137 295 241 138 295 minecraft:cut_sandstone
fill 241 137 297 241 138 297 minecraft:cut_sandstone
fill 241 137 299 241 138 299 minecraft:cut_sandstone
fill 241 137 301 241 138 301 minecraft:cut_sandstone
fill 241 137 303 241 138 303 minecraft:cut_sandstone
fill 241 137 305 241 138 305 minecraft:cut_sandstone
fill 241 137 307 241 138 307 minecraft:cut_sandstone
fill 242 137 290 242 138 290 minecraft:cut_sandstone
fill 242 137 292 242 138 292 minecraft:cut_sandstone
fill 242 137 294 242 138 294 minecraft:cut_sandstone
fill 242 137 296 242 138 296 minecraft:cut_sandstone
fill 242 137 298 242 138 298 minecraft:cut_sandstone
fill 242 137 300 242 138 300 minecraft:cut_sandstone
fill 242 137 302 242 138 302 minecraft:cut_sandstone
fill 242 137 304 242 138 304 minecraft:cut_sandstone
fill 242 137 306 242 138 306 minecraft:cut_sandstone
fill 242 137 308 242 138 308 minecraft:cut_sandstone
fill 244 137 275 244 145 275 minecraft:sandstone
fill 244 137 314 244 147 314 minecraft:blue_wool
fill 267 137 281 267 139 281 minecraft:cut_sandstone
fill 267 137 283 267 139 283 minecraft:cut_sandstone
fill 267 137 285 267 139 285 minecraft:cut_sandstone
fill 267 137 287 267 139 287 minecraft:cut_sandstone
fill 267 137 289 267 139 289 minecraft:cut_sandstone
fill 267 137 291 267 139 291 minecraft:cut_sandstone
fill 268 137 282 268 139 282 minecraft:cut_sandstone
fill 268 137 284 268 139 284 minecraft:cut_sandstone
fill 268 137 286 268 139 286 minecraft:cut_sandstone
fill 268 137 288 268 139 288 minecraft:cut_sandstone
fill 268 137 290 268 139 290 minecraft:cut_sandstone
fill 268 137 317 268 185 317 minecraft:sandstone
fill 269 137 281 269 139 281 minecraft:cut_sandstone
fill 269 137 283 269 139 283 minecraft:cut_sandstone
fill 269 137 285 269 139 285 minecraft:cut_sandstone
fill 269 137 287 269 139 287 minecraft:cut_sandstone
fill 269 137 289 269 139 289 minecraft:cut_sandstone
fill 269 137 291 269 139 291 minecraft:cut_sandstone
fill 270 137 282 270 139 282 minecraft:cut_sandstone
fill 270 137 284 270 139 284 minecraft:cut_sandstone
fill 270 137 286 270 139 286 minecraft:cut_sandstone
fill 270 137 288 270 139 288 minecraft:cut_sandstone
fill 270 137 290 270 139 290 minecraft:cut_sandstone
fill 271 137 281 271 139 281 minecraft:cut_sandstone
fill 271 137 283 271 139 283 minecraft:cut_sandstone
fill 271 137 285 271 139 285 minecraft:cut_sandstone
fill 271 137 287 271 139 287 minecraft:cut_sandstone
fill 271 137 289 271 139 289 minecraft:cut_sandstone
fill 271 137 291 271 139 291 minecraft:cut_sandstone
fill 272 137 282 272 139 282 minecraft:cut_sandstone
fill 272 137 284 272 139 284 minecraft:cut_sandstone
fill 272 137 286 272 139 286 minecraft:cut_sandstone
fill 272 137 288 272 139 288 minecraft:cut_sandstone
fill 272 137 290 272 139 290 minecraft:cut_sandstone
fill 273 137 281 273 139 281 minecraft:cut_sandstone
fill 273 137 283 273 139 283 minecraft:cut_sandstone
fill 273 137 285 273 139 285 minecraft:cut_sandstone
fill 273 137 287 273 139 287 minecraft:cut_sandstone
fill 273 137 289 273 139 289 minecraft:cut_sandstone
fill 273 137 291 273 139 291 minecraft:cut_sandstone
fill 274 137 282 274 139 282 minecraft:cut_sandstone
fill 274 137 284 274 139 284 minecraft:cut_sandstone
fill 274 137 286 274 139 286 minecraft:cut_sandstone
fill 274 137 288 274 139 288 minecraft:cut_sandstone
fill 274 137 290 274 139 290 minecraft:cut_sandstone
fill 275 137 281 275 139 281 minecraft:cut_sandstone
fill 275 137 283 275 139 283 minecraft:cut_sandstone
fill 275 137 285 275 145 285 minecraft:cut_sandstone
fill 275 137 287 275 145 287 minecraft:cut_sandstone
fill 275 137 289 275 139 289 minecraft:cut_sandstone
fill 275 137 291 275 139 291 minecraft:cut_sandstone
fill 276 137 282 276 139 282 minecraft:cut_sandstone
fill 276 137 284 276 203 284 minecraft:cut_sandstone
fill 276 137 286 276 203 286 minecraft:cut_sandstone
fill 276 137 288 276 139 288 minecraft:cut_sandstone
fill 276 137 290 276 139 290 minecraft:cut_sandstone
fill 277 137 279 277 141 279 minecraft:sandstone
fill 237 138 310 237 139 311 minecraft:blue_wool
setblock 238 138 278 minecraft:light[level=15]
setblock 238 138 286 minecraft:light[level=15]
setblock 238 138 310 minecraft:light[level=15]
fill 242 138 314 243 149 314 minecraft:blue_wool
fill 245 138 314 246 147 314 minecraft:blue_wool
setblock 246 138 278 minecraft:light[level=15]
setblock 246 138 286 minecraft:light[level=15]
setblock 246 138 294 minecraft:light[level=15]
setblock 246 138 302 minecraft:light[level=15]
setblock 246 138 310 minecraft:light[level=15]
setblock 254 138 278 minecraft:light[level=15]
setblock 254 138 286 minecraft:light[level=15]
setblock 254 138 294 minecraft:light[level=15]
setblock 254 138 302 minecraft:light[level=15]
setblock 254 138 310 minecraft:light[level=15]
setblock 262 138 278 minecraft:light[level=15]
setblock 262 138 286 minecraft:light[level=15]
setblock 262 138 294 minecraft:light[level=15]
setblock 262 138 302 minecraft:light[level=15]
setblock 262 138 310 minecraft:light[level=15]
setblock 270 138 278 minecraft:light[level=15]
setblock 270 138 294 minecraft:light[level=15]
setblock 270 138 302 minecraft:light[level=15]
setblock 270 138 310 minecraft:light[level=15]
setblock 277 138 282 minecraft:black_terracotta
setblock 235 139 289 minecraft:black_terracotta
setblock 235 139 300 minecraft:orange_terracotta
setblock 236 139 290 minecraft:glowstone
setblock 236 139 292 minecraft:glowstone
setblock 236 139 294 minecraft:glowstone
setblock 236 139 296 minecraft:glowstone
setblock 236 139 298 minecraft:glowstone
setblock 236 139 300 minecraft:glowstone
setblock 236 139 302 minecraft:glowstone
setblock 236 139 304 minecraft:glowstone
setblock 236 139 306 minecraft:glowstone
setblock 236 139 308 minecraft:glowstone
setblock 237 139 291 minecraft:glowstone
setblock 237 139 293 minecraft:glowstone
setblock 237 139 295 minecraft:glowstone
setblock 237 139 297 minecraft:glowstone
setblock 237 139 299 minecraft:glowstone
setblock 237 139 301 minecraft:glowstone
setblock 237 139 303 minecraft:glowstone
setblock 237 139 305 minecraft:glowstone
setblock 237 139 307 minecraft:glowstone
setblock 238 139 290 minecraft:glowstone
setblock 238 139 292 minecraft:glowstone
setblock 238 139 294 minecraft:glowstone
setblock 238 139 296 minecraft:glowstone
setblock 238 139 298 minecraft:glowstone
setblock 238 139 300 minecraft:glowstone
setblock 238 139 302 minecraft:glowstone
setblock 238 139 304 minecraft:glowstone
setblock 238 139 306 minecraft:glowstone
setblock 238 139 308 minecraft:glowstone
setblock 239 139 291 minecraft:glowstone
setblock 239 139 293 minecraft:glowstone
setblock 239 139 295 minecraft:glowstone
setblock 239 139 297 minecraft:glowstone
setblock 239 139 299 minecraft:glowstone
setblock 239 139 301 minecraft:glowstone
setblock 239 139 303 minecraft:glowstone
setblock 239 139 305 minecraft:glowstone
setblock 239 139 307 minecraft:glowstone
setblock 240 139 290 minecraft:glowstone
setblock 240 139 292 minecraft:glowstone
setblock 240 139 294 minecraft:glowstone
setblock 240 139 296 minecraft:glowstone
setblock 240 139 298 minecraft:glowstone
setblock 240 139 300 minecraft:glowstone
setblock 240 139 302 minecraft:glowstone
setblock 240 139 304 minecraft:glowstone
setblock 240 139 306 minecraft:glowstone
setblock 240 139 308 minecraft:glowstone
setblock 241 139 291 minecraft:glowstone
setblock 241 139 293 minecraft:glowstone
setblock 241 139 295 minecraft:glowstone
setblock 241 139 297 minecraft:glowstone
setblock 241 139 299 minecraft:glowstone
setblock 241 139 301 minecraft:glowstone
setblock 241 139 303 minecraft:glowstone
setblock 241 139 305 minecraft:glowstone
setblock 241 139 307 minecraft:glowstone
setblock 242 139 290 minecraft:glowstone
setblock 242 139 292 minecraft:glowstone
setblock 242 139 294 minecraft:glowstone
setblock 242 139 296 minecraft:glowstone
setblock 242 139 298 minecraft:glowstone
setblock 242 139 300 minecraft:glowstone
setblock 242 139 302 minecraft:glowstone
setblock 242 139 304 minecraft:glowstone
setblock 242 139 306 minecraft:glowstone
setblock 242 139 308 minecraft:glowstone
fill 277 139 282 277 140 282 minecraft:sandstone
fill 277 139 313 277 145 313 minecraft:sandstone
fill 277 139 314 277 140 314 minecraft:blue_terracotta
fill 235 140 276 235 169 276 minecraft:sandstone
setblock 235 140 277 minecraft:blue_terracotta
fill 235 140 278 235 216 278 minecraft:sandstone
fill 235 140 289 235 143 289 minecraft:sandstone
fill 235 140 300 235 147 300 minecraft:sandstone
fill 236 140 290 236 141 290 minecraft:cut_sandstone
fill 236 140 292 236 141 292 minecraft:cut_sandstone
fill 236 140 294 236 141 294 minecraft:cut_sandstone
fill 236 140 296 236 141 296 minecraft:cut_sandstone
fill 236 140 298 236 141 298 minecraft:cut_sandstone
fill 236 140 300 236 141 300 minecraft:cut_sandstone
fill 236 140 302 236 141 302 minecraft:cut_sandstone
fill 236 140 304 236 141 304 minecraft:cut_sandstone
fill 236 140 306 236 141 306 minecraft:cut_sandstone
fill 236 140 308 236 141 308 minecraft:cut_sandstone
fill 237 140 285 237 145 287 minecraft:cut_sandstone
fill 237 140 291 237 141 291 minecraft:cut_sandstone
fill 237 140 293 237 141 293 minecraft:cut_sandstone
fill 237 140 295 237 141 295 minecraft:cut_sandstone
fill 237 140 297 237 141 297 minecraft:cut_sandstone
fill 237 140 299 237 141 299 minecraft:cut_sandstone
fill 237 140 301 237 141 301 minecraft:cut_sandstone
fill 237 140 303 237 141 303 minecraft:cut_sandstone
fill 237 140 305 237 141 305 minecraft:cut_sandstone
fill 237 140 307 237 141 307 minecraft:cut_sandstone
fill 237 140 309 237 145 311 minecraft:cut_sandstone
fill 238 140 290 238 141 290 minecraft:cut_sandstone
fill 238 140 292 238 141 292 minecraft:cut_sandstone
fill 238 140 294 238 141 294 minecraft:cut_sandstone
fill 238 140 296 238 141 296 minecraft:cut_sandstone
fill 238 140 298 238 141 298 minecraft:cut_sandstone
fill 238 140 300 238 141 300 minecraft:cut_sandstone
fill 238 140 302 238 141 302 minecraft:cut_sandstone
fill 238 140 304 238 141 304 minecraft:cut_sandstone
fill 238 140 306 238 141 306 minecraft:cut_sandstone
fill 238 140 308 238 141 308 minecraft:cut_sandstone
fill 239 140 291 239 141 291 minecraft:cut_sandstone
fill 239 140 293 239 141 293 minecraft:cut_sandstone
fill 239 140 295 239 141 295 minecraft:cut_sandstone
fill 239 140 297 239 141 297 minecraft:cut_sandstone
fill 239 140 299 239 141 299 minecraft:cut_sandstone
fill 239 140 301 239 141 301 minecraft:cut_sandstone
fill 239 140 303 239 141 303 minecraft:cut_sandstone
fill 239 140 305 239 141 305 minecraft:cut_sandstone
fill 239 140 307 239 141 307 minecraft:cut_sandstone
fill 240 140 290 240 141 290 minecraft:cut_sandstone
fill 240 140 292 240 141 292 minecraft:cut_sandstone
fill 240 140 294 240 141 294 minecraft:cut_sandstone
fill 240 140 296 240 141 296 minecraft:cut_sandstone
fill 240 140 298 240 141 298 minecraft:cut_sandstone
fill 240 140 300 240 141 300 minecraft:cut_sandstone
fill 240 140 302 240 141 302 minecraft:cut_sandstone
fill 240 140 304 240 141 304 minecraft:cut_sandstone
fill 240 140 306 240 141 306 minecraft:cut_sandstone
fill 240 140 308 240 141 308 minecraft:cut_sandstone
fill 241 140 291 241 141 291 minecraft:cut_sandstone
fill 241 140 293 241 141 293 minecraft:cut_sandstone
fill 241 140 295 241 141 295 minecraft:cut_sandstone
fill 241 140 297 241 141 297 minecraft:cut_sandstone
fill 241 140 299 241 141 299 minecraft:cut_sandstone
fill 241 140 301 241 141 301 minecraft:cut_sandstone
fill 241 140 303 241 141 303 minecraft:cut_sandstone
fill 241 140 305 241 141 305 minecraft:cut_sandstone
fill 241 140 307 241 141 307 minecraft:cut_sandstone
fill 242 140 290 242 141 290 minecraft:cut_sandstone
fill 242 140 292 242 141 292 minecraft:cut_sandstone
fill 242 140 294 242 141 294 minecraft:cut_sandstone
fill 242 140 296 242 141 296 minecraft:cut_sandstone
fill 242 140 298 242 141 298 minecraft:cut_sandstone
fill 242 140 300 242 141 300 minecraft:cut_sandstone
fill 242 140 302 242 141 302 minecraft:cut_sandstone
fill 242 140 304 242 141 304 minecraft:cut_sandstone
fill 242 140 306 242 141 306 minecraft:cut_sandstone
fill 242 140 308 242 141 308 minecraft:cut_sandstone
fill 243 140 315 245 145 315 minecraft:cut_sandstone
fill 247 140 277 249 145 277 minecraft:cut_sandstone
fill 255 140 315 257 145 315 minecraft:cut_sandstone
fill 259 140 277 261 145 277 minecraft:cut_sandstone
fill 267 140 315 269 145 315 minecraft:cut_sandstone
fill 268 140 282 274 140 290 minecraft:lapis_block
fill 271 140 277 273 145 277 minecraft:cut_sandstone
fill 275 140 282 275 140 284 minecraft:lapis_block
fill 275 140 288 275 140 290 minecraft:lapis_block
fill 275 140 297 275 145 299 minecraft:cut_sandstone
fill 275 140 309 275 145 311 minecraft:cut_sandstone
setblock 277 140 289 minecraft:black_terracotta
fill 277 140 290 277 145 290 minecraft:sandstone
fill 235 141 277 235 216 277 minecraft:sandstone
fill 241 141 314 241 149 314 minecraft:blue_wool
setblock 245 141 317 minecraft:orange_terracotta
fill 246 141 317 246 213 317 minecraft:sandstone
fill 254 141 317 254 208 317 minecraft:sandstone
setblock 255 141 317 minecraft:orange_terracotta
fill 256 141 317 256 154 317 minecraft:sandstone
setblock 259 141 317 minecraft:black_terracotta
fill 269 141 283 274 141 289 minecraft:lapis_block
setblock 277 141 282 minecraft:orange_terracotta
fill 277 141 289 277 145 289 minecraft:sandstone
fill 277 141 314 277 145 314 minecraft:sandstone
setblock 236 142 290 minecraft:glowstone
setblock 236 142 292 minecraft:glowstone
setblock 236 142 294 minecraft:glowstone
setblock 236 142 296 minecraft:glowstone
setblock 236 142 298 minecraft:glowstone
setblock 236 142 300 minecraft:glowstone
setblock 236 142 302 minecraft:glowstone
setblock 236 142 304 minecraft:glowstone
setblock 236 142 306 minecraft:glowstone
setblock 236 142 308 minecraft:glowstone
setblock 237 142 291 minecraft:glowstone
setblock 237 142 293 minecraft:glowstone
setblock 237 142 295 minecraft:glowstone
setblock 237 142 297 minecraft:glowstone
setblock 237 142 299 minecraft:glowstone
setblock 237 142 301 minecraft:glowstone
setblock 237 142 303 minecraft:glowstone
setblock 237 142 305 minecraft:glowstone
setblock 237 142 307 minecraft:glowstone
setblock 238 142 278 minecraft:light[level=12]
setblock 238 142 285 minecraft:light[level=12]
setblock 238 142 290 minecraft:glowstone
setblock 238 142 292 minecraft:glowstone
setblock 238 142 294 minecraft:glowstone
setblock 238 142 296 minecraft:glowstone
setblock 238 142 298 minecraft:glowstone
setblock 238 142 300 minecraft:glowstone
setblock 238 142 302 minecraft:glowstone
setblock 238 142 304 minecraft:glowstone
setblock 238 142 306 minecraft:glowstone
setblock 238 142 308 minecraft:glowstone
setblock 238 142 313 minecraft:light[level=12]
setblock 239 142 291 minecraft:glowstone
setblock 239 142 293 minecraft:glowstone
setblock 239 142 295 minecraft:glowstone
setblock 239 142 297 minecraft:glowstone
setblock 239 142 299 minecraft:glowstone
setblock 239 142 301 minecraft:glowstone
setblock 239 142 303 minecraft:glowstone
setblock 239 142 305 minecraft:glowstone
setblock 239 142 307 minecraft:glowstone
fill 239 142 314 240 149 314 minecraft:blue_wool
setblock 240 142 290 minecraft:glowstone
setblock 240 142 292 minecraft:glowstone
setblock 240 142 294 minecraft:glowstone
setblock 240 142 296 minecraft:glowstone
setblock 240 142 298 minecraft:glowstone
setblock 240 142 300 minecraft:glowstone
setblock 240 142 302 minecraft:glowstone
setblock 240 142 304 minecraft:glowstone
setblock 240 142 306 minecraft:glowstone
setblock 240 142 308 minecraft:glowstone
setblock 241 142 291 minecraft:glowstone
setblock 241 142 293 minecraft:glowstone
setblock 241 142 295 minecraft:glowstone
setblock 241 142 297 minecraft:glowstone
setblock 241 142 299 minecraft:glowstone
setblock 241 142 301 minecraft:glowstone
setblock 241 142 303 minecraft:glowstone
setblock 241 142 305 minecraft:glowstone
setblock 241 142 307 minecraft:glowstone
setblock 242 142 290 minecraft:glowstone
setblock 242 142 292 minecraft:glowstone
setblock 242 142 294 minecraft:glowstone
setblock 242 142 296 minecraft:glowstone
setblock 242 142 298 minecraft:glowstone
setblock 242 142 300 minecraft:glowstone
setblock 242 142 302 minecraft:glowstone
setblock 242 142 304 minecraft:glowstone
setblock 242 142 306 minecraft:glowstone
setblock 242 142 308 minecraft:glowstone
setblock 245 142 278 minecraft:light[level=12]
setblock 245 142 285 minecraft:light[level=12]
setblock 245 142 292 minecraft:light[level=12]
setblock 245 142 299 minecraft:light[level=12]
setblock 245 142 306 minecraft:light[level=12]
setblock 245 142 313 minecraft:light[level=12]
fill 245 142 317 245 210 317 minecraft:sandstone
setblock 252 142 278 minecraft:light[level=12]
setblock 252 142 285 minecraft:light[level=12]
setblock 252 142 292 minecraft:light[level=12]
setblock 252 142 299 minecraft:light[level=12]
setblock 252 142 306 minecraft:light[level=12]
setblock 252 142 313 minecraft:light[level=12]
fill 255 142 283 257 143 283 minecraft:smooth_sandstone
fill 255 142 317 255 212 317 minecraft:sandstone
fill 256 142 282 256 143 282 minecraft:smooth_sandstone
fill 256 142 284 256 143 284 minecraft:smooth_sandstone
setblock 259 142 278 minecraft:light[level=12]
fill 259 142 281 259 144 281 minecraft:shroomlight
setblock 259 142 285 minecraft:light[level=12]
setblock 259 142 292 minecraft:light[level=12]
setblock 259 142 299 minecraft:light[level=12]
setblock 259 142 306 minecraft:light[level=12]
setblock 259 142 313 minecraft:light[level=12]
fill 259 142 317 259 145 317 minecraft:sandstone
setblock 266 142 278 minecraft:light[level=12]
setblock 266 142 285 minecraft:light[level=12]
setblock 266 142 292 minecraft:light[level=12]
setblock 266 142 299 minecraft:light[level=12]
setblock 266 142 306 minecraft:light[level=12]
setblock 266 142 313 minecraft:light[level=12]
fill 270 142 284 273 142 288 minecraft:lapis_block
setblock 273 142 278 minecraft:light[level=12]
setblock 273 142 292 minecraft:light[level=12]
setblock 273 142 299 minecraft:light[level=12]
setblock 273 142 306 minecraft:light[level=12]
setblock 273 142 313 minecraft:light[level=12]
setblock 277 142 279 minecraft:lapis_block
fill 277 142 282 277 216 282 minecraft:sandstone
fill 236 143 290 236 144 290 minecraft:cut_sandstone
fill 236 143 292 236 144 292 minecraft:cut_sandstone
fill 236 143 294 236 144 294 minecraft:cut_sandstone
fill 236 143 296 236 144 296 minecraft:cut_sandstone
fill 236 143 298 236 144 298 minecraft:cut_sandstone
fill 236 143 300 236 144 300 minecraft:cut_sandstone
fill 236 143 302 236 144 302 minecraft:cut_sandstone
fill 236 143 304 236 144 304 minecraft:cut_sandstone
fill 236 143 306 236 144 306 minecraft:cut_sandstone
fill 236 143 308 236 144 308 minecraft:cut_sandstone
fill 237 143 291 237 144 291 minecraft:cut_sandstone
fill 237 143 293 237 144 293 minecraft:cut_sandstone
fill 237 143 295 237 144 295 minecraft:cut_sandstone
fill 237 143 297 237 144 297 minecraft:cut_sandstone
fill 237 143 299 237 144 299 minecraft:cut_sandstone
fill 237 143 301 237 144 301 minecraft:cut_sandstone
fill 237 143 303 237 144 303 minecraft:cut_sandstone
fill 237 143 305 237 144 305 minecraft:cut_sandstone
fill 237 143 307 237 144 307 minecraft:cut_sandstone
fill 238 143 290 238 144 290 minecraft:cut_sandstone
fill 238 143 292 238 144 292 minecraft:cut_sandstone
fill 238 143 294 238 144 294 minecraft:cut_sandstone
fill 238 143 296 238 144 296 minecraft:cut_sandstone
fill 238 143 298 238 144 298 minecraft:cut_sandstone
fill 238 143 300 238 144 300 minecraft:cut_sandstone
fill 238 143 302 238 144 302 minecraft:cut_sandstone
fill 238 143 304 238 144 304 minecraft:cut_sandstone
fill 238 143 306 238 144 306 minecraft:cut_sandstone
fill 238 143 308 238 144 308 minecraft:cut_sandstone
fill 239 143 291 239 144 291 minecraft:cut_sandstone
fill 239 143 293 239 144 293 minecraft:cut_sandstone
fill 239 143 295 239 144 295 minecraft:cut_sandstone
fill 239 143 297 239 144 297 minecraft:cut_sandstone
fill 239 143 299 239 144 299 minecraft:cut_sandstone
fill 239 143 301 239 144 301 minecraft:cut_sandstone
fill 239 143 303 239 144 303 minecraft:cut_sandstone
fill 239 143 305 239 144 305 minecraft:cut_sandstone
fill 239 143 307 239 144 307 minecraft:cut_sandstone
fill 240 143 290 240 144 290 minecraft:cut_sandstone
fill 240 143 292 240 144 292 minecraft:cut_sandstone
fill 240 143 294 240 144 294 minecraft:cut_sandstone
fill 240 143 296 240 144 296 minecraft:cut_sandstone
fill 240 143 298 240 144 298 minecraft:cut_sandstone
fill 240 143 300 240 144 300 minecraft:cut_sandstone
fill 240 143 302 240 144 302 minecraft:cut_sandstone
fill 240 143 304 240 144 304 minecraft:cut_sandstone
fill 240 143 306 240 144 306 minecraft:cut_sandstone
fill 240 143 308 240 144 308 minecraft:cut_sandstone
fill 241 143 291 241 144 291 minecraft:cut_sandstone
fill 241 143 293 241 144 293 minecraft:cut_sandstone
fill 241 143 295 241 144 295 minecraft:cut_sandstone
fill 241 143 297 241 144 297 minecraft:cut_sandstone
fill 241 143 299 241 144 299 minecraft:cut_sandstone
fill 241 143 301 241 144 301 minecraft:cut_sandstone
fill 241 143 303 241 144 303 minecraft:cut_sandstone
fill 241 143 305 241 144 305 minecraft:cut_sandstone
fill 241 143 307 241 144 307 minecraft:cut_sandstone
fill 242 143 290 242 144 290 minecraft:cut_sandstone
fill 242 143 292 242 144 292 minecraft:cut_sandstone
fill 242 143 294 242 144 294 minecraft:cut_sandstone
fill 242 143 296 242 144 296 minecraft:cut_sandstone
fill 242 143 298 242 144 298 minecraft:cut_sandstone
fill 242 143 300 242 144 300 minecraft:cut_sandstone
fill 242 143 302 242 144 302 minecraft:cut_sandstone
fill 242 143 304 242 144 304 minecraft:cut_sandstone
fill 242 143 306 242 144 306 minecraft:cut_sandstone
fill 242 143 308 242 144 308 minecraft:cut_sandstone
fill 271 143 285 272 143 287 minecraft:lapis_block
fill 277 143 279 277 145 279 minecraft:sandstone
setblock 235 144 289 minecraft:blue_terracotta
fill 262 144 280 262 147 280 minecraft:iron_block
setblock 270 144 275 minecraft:lapis_block
setblock 271 144 275 minecraft:blue_terracotta
fill 272 144 275 274 213 275 minecraft:sandstone
fill 235 145 289 235 147 289 minecraft:sandstone
fill 236 145 279 236 145 284 minecraft:chiseled_sandstone
setblock 236 145 290 minecraft:glowstone
setblock 236 145 291 minecraft:chiseled_sandstone
setblock 236 145 292 minecraft:glowstone
setblock 236 145 293 minecraft:chiseled_sandstone
setblock 236 145 294 minecraft:glowstone
setblock 236 145 295 minecraft:chiseled_sandstone
setblock 236 145 296 minecraft:glowstone
setblock 236 145 298 minecraft:glowstone
setblock 236 145 300 minecraft:glowstone
setblock 236 145 302 minecraft:glowstone
setblock 236 145 303 minecraft:chiseled_sandstone
setblock 236 145 304 minecraft:glowstone
setblock 236 145 305 minecraft:chiseled_sandstone
setblock 236 145 306 minecraft:glowstone
setblock 236 145 307 minecraft:chiseled_sandstone
setblock 236 145 308 minecraft:glowstone
fill 236 145 315 236 145 316 minecraft:chiseled_sandstone
setblock 237 145 291 minecraft:glowstone
setblock 237 145 293 minecraft:glowstone
setblock 237 145 295 minecraft:glowstone
setblock 237 145 297 minecraft:glowstone
setblock 237 145 299 minecraft:glowstone
setblock 237 145 301 minecraft:glowstone
setblock 237 145 303 minecraft:glowstone
setblock 237 145 305 minecraft:glowstone
setblock 237 145 307 minecraft:glowstone
fill 237 145 316 240 145 316 minecraft:chiseled_sandstone
setblock 238 145 290 minecraft:glowstone
setblock 238 145 292 minecraft:glowstone
setblock 238 145 294 minecraft:glowstone
setblock 238 145 296 minecraft:glowstone
setblock 238 145 298 minecraft:glowstone
setblock 238 145 300 minecraft:glowstone
setblock 238 145 302 minecraft:glowstone
setblock 238 145 304 minecraft:glowstone
setblock 238 145 306 minecraft:glowstone
setblock 238 145 308 minecraft:glowstone
setblock 239 145 291 minecraft:glowstone
setblock 239 145 293 minecraft:glowstone
setblock 239 145 295 minecraft:glowstone
setblock 239 145 297 minecraft:glowstone
setblock 239 145 299 minecraft:glowstone
setblock 239 145 301 minecraft:glowstone
setblock 239 145 303 minecraft:glowstone
setblock 239 145 305 minecraft:glowstone
setblock 239 145 307 minecraft:glowstone
fill 240 145 276 245 145 276 minecraft:chiseled_sandstone
setblock 240 145 290 minecraft:glowstone
setblock 240 145 292 minecraft:glowstone
setblock 240 145 294 minecraft:glowstone
setblock 240 145 296 minecraft:glowstone
setblock 240 145 298 minecraft:glowstone
setblock 240 145 300 minecraft:glowstone
setblock 240 145 302 minecraft:glowstone
setblock 240 145 304 minecraft:glowstone
setblock 240 145 306 minecraft:glowstone
setblock 240 145 308 minecraft:glowstone
setblock 241 145 291 minecraft:glowstone
setblock 241 145 293 minecraft:glowstone
setblock 241 145 295 minecraft:glowstone
setblock 241 145 297 minecraft:glowstone
setblock 241 145 299 minecraft:glowstone
setblock 241 145 301 minecraft:glowstone
setblock 241 145 303 minecraft:glowstone
setblock 241 145 305 minecraft:glowstone
setblock 241 145 307 minecraft:glowstone
setblock 242 145 290 minecraft:glowstone
setblock 242 145 292 minecraft:glowstone
setblock 242 145 294 minecraft:glowstone
setblock 242 145 296 minecraft:glowstone
setblock 242 145 298 minecraft:glowstone
setblock 242 145 300 minecraft:glowstone
setblock 242 145 302 minecraft:glowstone
setblock 242 145 304 minecraft:glowstone
setblock 242 145 306 minecraft:glowstone
setblock 242 145 308 minecraft:glowstone
fill 247 145 316 252 145 316 minecraft:chiseled_sandstone
fill 252 145 276 257 145 276 minecraft:chiseled_sandstone
fill 259 145 316 264 145 316 minecraft:chiseled_sandstone
fill 264 145 276 269 145 276 minecraft:chiseled_sandstone
fill 270 145 275 271 207 275 minecraft:sandstone
fill 271 145 316 276 145 316 minecraft:chiseled_sandstone
fill 276 145 276 276 145 281 minecraft:chiseled_sandstone
fill 276 145 288 276 145 293 minecraft:chiseled_sandstone
fill 276 145 300 276 145 305 minecraft:chiseled_sandstone
fill 276 145 312 276 145 315 minecraft:chiseled_sandstone
fill 235 146 281 235 151 284 minecraft:glowstone
fill 235 146 293 235 151 296 minecraft:glowstone
fill 235 146 305 235 151 308 minecraft:glowstone
fill 235 146 317 238 151 317 minecraft:glowstone
fill 236 146 290 236 147 296 minecraft:cut_sandstone
fill 236 146 298 236 203 298 minecraft:cut_sandstone
fill 236 146 300 236 203 300 minecraft:cut_sandstone
fill 236 146 302 236 148 308 minecraft:cut_sandstone
fill 237 146 291 237 147 291 minecraft:cut_sandstone
fill 237 146 293 237 147 293 minecraft:cut_sandstone
fill 237 146 295 237 147 295 minecraft:cut_sandstone
fill 237 146 297 237 148 297 minecraft:cut_sandstone
fill 237 146 299 237 148 299 minecraft:cut_sandstone
fill 237 146 301 237 148 301 minecraft:cut_sandstone
fill 237 146 303 237 148 303 minecraft:cut_sandstone
fill 237 146 305 237 148 305 minecraft:cut_sandstone
fill 237 146 307 237 148 307 minecraft:cut_sandstone
fill 237 146 309 237 147 311 minecraft:blue_wool
setblock 238 146 278 minecraft:light[level=15]
setblock 238 146 286 minecraft:light[level=15]
fill 238 146 290 238 147 290 minecraft:cut_sandstone
fill 238 146 292 238 147 292 minecraft:cut_sandstone
fill 238 146 294 238 147 294 minecraft:cut_sandstone
fill 238 146 296 238 148 296 minecraft:cut_sandstone
fill 238 146 298 238 148 298 minecraft:cut_sandstone
fill 238 146 300 238 148 300 minecraft:cut_sandstone
fill 238 146 302 238 148 302 minecraft:cut_sandstone
fill 238 146 304 238 148 304 minecraft:cut_sandstone
fill 238 146 306 238 148 306 minecraft:cut_sandstone
fill 238 146 308 238 148 308 minecraft:cut_sandstone
setblock 238 146 310 minecraft:light[level=15]
fill 239 146 291 239 147 291 minecraft:cut_sandstone
fill 239 146 293 239 147 293 minecraft:cut_sandstone
fill 239 146 295 239 147 295 minecraft:cut_sandstone
fill 239 146 297 239 148 297 minecraft:cut_sandstone
fill 239 146 299 239 148 299 minecraft:cut_sandstone
fill 239 146 301 239 148 301 minecraft:cut_sandstone
fill 239 146 303 239 148 303 minecraft:cut_sandstone
fill 239 146 305 239 148 305 minecraft:cut_sandstone
fill 239 146 307 239 148 307 minecraft:cut_sandstone
setblock 239 146 317 minecraft:lapis_block
fill 240 146 290 240 147 290 minecraft:cut_sandstone
fill 240 146 292 240 147 292 minecraft:cut_sandstone
fill 240 146 294 240 147 294 minecraft:cut_sandstone
fill 240 146 296 240 148 296 minecraft:cut_sandstone
fill 240 146 298 240 148 298 minecraft:cut_sandstone
fill 240 146 300 240 148 300 minecraft:cut_sandstone
fill 240 146 302 240 148 302 minecraft:cut_sandstone
fill 240 146 304 240 148 304 minecraft:cut_sandstone
fill 240 146 306 240 148 306 minecraft:cut_sandstone
fill 240 146 308 240 148 308 minecraft:cut_sandstone
fill 240 146 317 240 178 317 minecraft:sandstone
fill 241 146 291 241 147 291 minecraft:cut_sandstone
fill 241 146 293 241 147 293 minecraft:cut_sandstone
fill 241 146 295 241 147 295 minecraft:cut_sandstone
fill 241 146 297 241 148 297 minecraft:cut_sandstone
fill 241 146 299 241 148 299 minecraft:cut_sandstone
fill 241 146 301 241 148 301 minecraft:cut_sandstone
fill 241 146 303 241 148 303 minecraft:cut_sandstone
fill 241 146 305 241 148 305 minecraft:cut_sandstone
fill 241 146 307 241 148 307 minecraft:cut_sandstone
fill 242 146 275 245 151 275 minecraft:glowstone
fill 242 146 290 242 147 290 minecraft:cut_sandstone
fill 242 146 292 242 147 292 minecraft:cut_sandstone
fill 242 146 294 242 147 294 minecraft:cut_sandstone
fill 242 146 296 242 148 296 minecraft:cut_sandstone
fill 242 146 298 242 148 298 minecraft:cut_sandstone
fill 242 146 300 242 148 300 minecraft:cut_sandstone
fill 242 146 302 242 148 302 minecraft:cut_sandstone
fill 242 146 304 242 148 304 minecraft:cut_sandstone
fill 242 146 306 242 148 306 minecraft:cut_sandstone
fill 242 146 308 242 148 308 minecraft:cut_sandstone
setblock 246 146 278 minecraft:light[level=15]
setblock 246 146 286 minecraft:light[level=15]
setblock 246 146 294 minecraft:light[level=15]
setblock 246 146 302 minecraft:light[level=15]
setblock 246 146 310 minecraft:light[level=15]
fill 246 146 311 246 148 311 minecraft:shroomlight
fill 247 146 317 250 151 317 minecraft:glowstone
fill 254 146 275 257 151 275 minecraft:glowstone
setblock 254 146 278 minecraft:light[level=15]
setblock 254 146 286 minecraft:light[level=15]
setblock 254 146 294 minecraft:light[level=15]
setblock 254 146 302 minecraft:light[level=15]
setblock 254 146 310 minecraft:light[level=15]
fill 259 146 317 262 151 317 minecraft:glowstone
setblock 262 146 278 minecraft:light[level=15]
setblock 262 146 286 minecraft:light[level=15]
setblock 262 146 294 minecraft:light[level=15]
setblock 262 146 302 minecraft:light[level=15]
setblock 262 146 310 minecraft:light[level=15]
fill 266 146 275 269 151 275 minecraft:glowstone
setblock 270 146 278 minecraft:light[level=15]
setblock 270 146 286 minecraft:light[level=15]
setblock 270 146 294 minecraft:light[level=15]
setblock 270 146 302 minecraft:light[level=15]
setblock 270 146 310 minecraft:light[level=15]
fill 271 146 317 274 151 317 minecraft:glowstone
fill 277 146 276 277 151 279 minecraft:glowstone
fill 277 146 288 277 151 291 minecraft:glowstone
fill 277 146 300 277 151 303 minecraft:glowstone
fill 277 146 305 277 216 305 minecraft:sandstone
setblock 277 146 306 minecraft:black_terracotta
fill 277 146 312 277 151 315 minecraft:glowstone
fill 239 147 317 239 157 317 minecraft:sandstone
fill 277 147 306 277 158 306 minecraft:sandstone
setblock 277 147 308 minecraft:lapis_block
fill 277 147 309 277 151 311 minecraft:sandstone
setblock 235 148 289 minecraft:blue_terracotta
setblock 235 148 300 minecraft:black_terracotta
setblock 235 148 303 minecraft:orange_terracotta
setblock 236 148 296 minecraft:cut_sandstone
fill 237 148 291 241 148 295 minecraft:lapis_block
fill 237 148 309 237 149 312 minecraft:iron_block
setblock 238 148 278 minecraft:light[level=12]
setblock 238 148 285 minecraft:light[level=12]
setblock 238 148 313 minecraft:light[level=12]
fill 244 148 314 247 149 314 minecraft:iron_block
setblock 245 148 278 minecraft:light[level=12]
setblock 245 148 285 minecraft:light[level=12]
setblock 245 148 292 minecraft:light[level=12]
setblock 245 148 299 minecraft:light[level=12]
setblock 245 148 306 minecraft:light[level=12]
setblock 245 148 313 minecraft:light[level=12]
setblock 252 148 278 minecraft:light[level=12]
setblock 252 148 285 minecraft:light[level=12]
setblock 252 148 292 minecraft:light[level=12]
setblock 252 148 299 minecraft:light[level=12]
setblock 252 148 306 minecraft:light[level=12]
setblock 252 148 313 minecraft:light[level=12]
fill 257 148 276 259 148 280 minecraft:chiseled_sandstone
setblock 259 148 285 minecraft:light[level=12]
setblock 259 148 292 minecraft:light[level=12]
setblock 259 148 299 minecraft:light[level=12]
setblock 259 148 306 minecraft:light[level=12]
setblock 259 148 313 minecraft:light[level=12]
fill 260 148 277 267 148 280 minecraft:chiseled_sandstone
fill 263 148 276 267 148 276 minecraft:chiseled_sandstone
setblock 266 148 285 minecraft:light[level=12]
setblock 266 148 292 minecraft:light[level=12]
setblock 266 148 299 minecraft:light[level=12]
setblock 266 148 306 minecraft:light[level=12]
setblock 266 148 313 minecraft:light[level=12]
setblock 273 148 278 minecraft:light[level=12]
setblock 273 148 285 minecraft:light[level=12]
setblock 273 148 292 minecraft:light[level=12]
setblock 273 148 299 minecraft:light[level=12]
setblock 273 148 306 minecraft:light[level=12]
setblock 273 148 313 minecraft:light[level=12]
fill 277 148 308 277 173 308 minecraft:sandstone
fill 235 149 289 235 212 289 minecraft:sandstone
fill 235 149 300 235 216 300 minecraft:sandstone
fill 235 149 303 235 193 303 minecraft:sandstone
fill 237 149 297 241 149 307 minecraft:lapis_block
setblock 237 149 308 minecraft:iron_block
fill 238 149 292 240 149 296 minecraft:lapis_block
setblock 253 149 317 minecraft:blue_terracotta
fill 257 149 276 259 149 280 minecraft:cut_sandstone
fill 260 149 277 267 149 280 minecraft:cut_sandstone
fill 263 149 276 267 149 276 minecraft:cut_sandstone
setblock 277 149 287 minecraft:black_terracotta
fill 238 150 298 240 150 306 minecraft:lapis_block
fill 238 150 314 244 151 314 minecraft:iron_block
fill 239 150 293 239 150 297 minecraft:lapis_block
fill 253 150 317 253 196 317 minecraft:sandstone
fill 257 150 280 267 150 280 minecraft:lapis_block
fill 261 150 275 263 153 275 minecraft:glowstone
fill 264 150 275 264 211 275 minecraft:sandstone
fill 277 150 287 277 153 287 minecraft:sandstone
fill 237 151 296 237 159 296 minecraft:blue_wool
fill 238 151 294 240 151 298 minecraft:lapis_block
fill 239 151 299 239 151 305 minecraft:lapis_block
setblock 257 151 280 minecraft:cut_sandstone
setblock 262 151 280 minecraft:cut_sandstone
setblock 267 151 280 minecraft:cut_sandstone
setblock 275 151 275 minecraft:lapis_block
fill 235 152 281 235 163 281 minecraft:sandstone
fill 235 152 282 235 152 283 minecraft:glowstone
fill 235 152 284 235 165 284 minecraft:sandstone
fill 235 152 293 235 165 293 minecraft:sandstone
fill 235 152 294 235 152 295 minecraft:glowstone
fill 235 152 296 235 165 296 minecraft:sandstone
fill 235 152 305 235 165 305 minecraft:sandstone
fill 235 152 306 235 152 307 minecraft:glowstone
fill 235 152 308 235 162 308 minecraft:sandstone
fill 235 152 317 235 165 317 minecraft:sandstone
fill 236 152 317 237 152 317 minecraft:glowstone
fill 237 152 294 237 159 295 minecraft:blue_wool
fill 237 152 297 237 159 298 minecraft:blue_wool
fill 238 152 300 240 152 304 minecraft:lapis_block
fill 238 152 317 238 165 317 minecraft:sandstone
fill 242 152 275 242 165 275 minecraft:sandstone
fill 243 152 275 244 152 275 minecraft:glowstone
fill 245 152 275 245 165 275 minecraft:sandstone
fill 247 152 317 247 165 317 minecraft:sandstone
fill 248 152 317 249 152 317 minecraft:glowstone
fill 250 152 317 251 165 317 minecraft:sandstone
setblock 252 152 317 minecraft:lapis_block
fill 254 152 275 254 165 275 minecraft:sandstone
fill 255 152 275 256 152 275 minecraft:glowstone
fill 257 152 275 257 165 275 minecraft:sandstone
fill 259 152 317 259 165 317 minecraft:sandstone
fill 260 152 317 261 152 317 minecraft:glowstone
fill 262 152 317 262 165 317 minecraft:sandstone
fill 266 152 275 266 165 275 minecraft:sandstone
fill 267 152 275 268 152 275 minecraft:glowstone
fill 269 152 275 269 165 275 minecraft:sandstone
fill 271 152 317 271 165 317 minecraft:sandstone
fill 272 152 317 273 152 317 minecraft:glowstone
fill 274 152 317 274 165 317 minecraft:sandstone
fill 275 152 275 275 160 275 minecraft:sandstone
fill 277 152 276 277 165 276 minecraft:sandstone
fill 277 152 277 277 152 278 minecraft:glowstone
fill 277 152 279 277 157 279 minecraft:sandstone
fill 277 152 288 277 165 288 minecraft:sandstone
fill 277 152 289 277 152 290 minecraft:glowstone
fill 277 152 291 277 165 291 minecraft:sandstone
fill 277 152 300 277 165 300 minecraft:sandstone
fill 277 152 301 277 152 302 minecraft:glowstone
fill 277 152 303 277 165 303 minecraft:sandstone
fill 277 152 309 277 159 310 minecraft:sandstone
setblock 277 152 311 minecraft:orange_terracotta
fill 277 152 312 277 165 312 minecraft:sandstone
fill 277 152 313 277 152 314 minecraft:glowstone
fill 277 152 315 277 165 315 minecraft:sandstone
fill 235 153 282 235 165 283 minecraft:sandstone
fill 235 153 294 235 165 295 minecraft:sandstone
fill 235 153 306 235 165 307 minecraft:sandstone
fill 236 153 317 237 157 317 minecraft:sandstone
fill 243 153 275 244 155 275 minecraft:sandstone
fill 245 153 310 246 154 310 minecraft:smooth_sandstone
fill 248 153 317 249 165 317 minecraft:sandstone
fill 252 153 317 252 162 317 minecraft:sandstone
fill 255 153 275 256 165 275 minecraft:sandstone
fill 257 153 307 261 174 311 minecraft:cut_sandstone
fill 260 153 317 261 159 317 minecraft:sandstone
fill 267 153 275 268 161 275 minecraft:sandstone
fill 272 153 317 273 160 317 minecraft:sandstone
fill 277 153 277 277 157 278 minecraft:sandstone
fill 277 153 289 277 163 290 minecraft:sandstone
fill 277 153 301 277 165 302 minecraft:sandstone
fill 277 153 311 277 216 311 minecraft:sandstone
fill 277 153 313 277 165 314 minecraft:sandstone
setblock 238 154 278 minecraft:light[level=15]
setblock 238 154 285 minecraft:light[level=12]
setblock 238 154 286 minecraft:light[level=15]
setblock 238 154 292 minecraft:light[level=12]
setblock 238 154 294 minecraft:light[level=15]
setblock 238 154 299 minecraft:light[level=12]
setblock 238 154 302 minecraft:light[level=15]
setblock 238 154 306 minecraft:light[level=12]
setblock 238 154 310 minecraft:light[level=15]
setblock 238 154 313 minecraft:light[level=12]
setblock 245 154 278 minecraft:light[level=12]
setblock 245 154 285 minecraft:light[level=12]
setblock 245 154 292 minecraft:light[level=12]
setblock 245 154 299 minecraft:light[level=12]
setblock 245 154 306 minecraft:light[level=12]
setblock 245 154 313 minecraft:light[level=12]
setblock 246 154 278 minecraft:light[level=15]
setblock 246 154 286 minecraft:light[level=15]
setblock 246 154 294 minecraft:light[level=15]
setblock 246 154 302 minecraft:light[level=15]
setblock 252 154 278 minecraft:light[level=12]
setblock 252 154 285 minecraft:light[level=12]
setblock 252 154 292 minecraft:light[level=12]
setblock 252 154 299 minecraft:light[level=12]
setblock 252 154 306 minecraft:light[level=12]
setblock 252 154 313 minecraft:light[level=12]
setblock 254 154 278 minecraft:light[level=15]
setblock 254 154 286 minecraft:light[level=15]
setblock 254 154 294 minecraft:light[level=15]
setblock 254 154 302 minecraft:light[level=15]
fill 254 154 309 256 173 309 minecraft:cut_sandstone
setblock 254 154 310 minecraft:light[level=15]
fill 255 154 306 256 173 308 minecraft:cut_sandstone
fill 255 154 310 256 173 312 minecraft:cut_sandstone
fill 256 154 305 262 173 305 minecraft:cut_sandstone
fill 256 154 313 262 173 313 minecraft:cut_sandstone
fill 257 154 306 263 173 306 minecraft:cut_sandstone
fill 257 154 312 263 173 312 minecraft:cut_sandstone
setblock 259 154 278 minecraft:light[level=12]
setblock 259 154 285 minecraft:light[level=12]
setblock 259 154 292 minecraft:light[level=12]
setblock 259 154 299 minecraft:light[level=12]
fill 259 154 304 259 173 304 minecraft:cut_sandstone
fill 259 154 314 259 173 314 minecraft:cut_sandstone
fill 261 154 275 263 186 275 minecraft:sandstone
setblock 262 154 278 minecraft:light[level=15]
setblock 262 154 286 minecraft:light[level=15]
setblock 262 154 294 minecraft:light[level=15]
setblock 262 154 302 minecraft:light[level=15]
fill 262 154 307 263 173 311 minecraft:cut_sandstone
fill 264 154 309 264 173 309 minecraft:cut_sandstone
setblock 266 154 278 minecraft:light[level=12]
setblock 266 154 285 minecraft:light[level=12]
setblock 266 154 292 minecraft:light[level=12]
setblock 266 154 299 minecraft:light[level=12]
setblock 266 154 306 minecraft:light[level=12]
setblock 266 154 313 minecraft:light[level=12]
setblock 270 154 278 minecraft:light[level=15]
setblock 270 154 286 minecraft:light[level=15]
setblock 270 154 294 minecraft:light[level=15]
setblock 270 154 302 minecraft:light[level=15]
setblock 270 154 310 minecraft:light[level=15]
setblock 273 154 278 minecraft:light[level=12]
setblock 273 154 285 minecraft:light[level=12]
setblock 273 154 292 minecraft:light[level=12]
setblock 273 154 299 minecraft:light[level=12]
setblock 273 154 306 minecraft:light[level=12]
setblock 273 154 313 minecraft:light[level=12]
setblock 277 154 287 minecraft:black_terracotta
fill 246 155 275 246 169 275 minecraft:sandstone
setblock 247 155 275 minecraft:blue_terracotta
fill 248 155 275 248 176 275 minecraft:sandstone
fill 253 155 307 253 172 311 minecraft:cut_sandstone
fill 254 155 306 254 172 308 minecraft:cut_sandstone
fill 254 155 310 254 172 312 minecraft:cut_sandstone
fill 255 155 305 255 172 305 minecraft:cut_sandstone
fill 255 155 313 255 172 313 minecraft:cut_sandstone
fill 256 155 304 258 172 304 minecraft:cut_sandstone
fill 256 155 314 258 172 314 minecraft:cut_sandstone
setblock 256 155 317 minecraft:orange_terracotta
fill 257 155 303 261 172 303 minecraft:cut_sandstone
fill 257 155 315 261 172 315 minecraft:cut_sandstone
fill 260 155 304 262 172 304 minecraft:cut_sandstone
fill 260 155 314 262 172 314 minecraft:cut_sandstone
fill 263 155 305 263 172 305 minecraft:cut_sandstone
fill 263 155 313 263 172 313 minecraft:cut_sandstone
fill 264 155 306 264 172 308 minecraft:cut_sandstone
fill 264 155 310 264 172 312 minecraft:cut_sandstone
fill 265 155 307 265 172 311 minecraft:cut_sandstone
fill 277 155 283 277 159 284 minecraft:sandstone
setblock 277 155 285 minecraft:black_terracotta
fill 277 155 286 277 171 287 minecraft:sandstone
setblock 243 156 275 minecraft:black_terracotta
fill 244 156 275 244 165 275 minecraft:sandstone
fill 247 156 275 247 160 275 minecraft:sandstone
fill 252 156 307 252 171 311 minecraft:cut_sandstone
fill 253 156 305 253 171 306 minecraft:cut_sandstone
fill 253 156 312 253 171 313 minecraft:cut_sandstone
fill 254 156 304 254 171 305 minecraft:cut_sandstone
fill 254 156 313 254 171 314 minecraft:cut_sandstone
fill 255 156 303 255 171 304 minecraft:cut_sandstone
fill 255 156 314 255 171 315 minecraft:cut_sandstone
fill 256 156 303 256 171 303 minecraft:cut_sandstone
fill 256 156 315 256 171 315 minecraft:cut_sandstone
fill 256 156 317 256 216 317 minecraft:sandstone
fill 257 156 302 261 171 302 minecraft:cut_sandstone
fill 257 156 316 261 164 316 minecraft:cut_sandstone
fill 262 156 303 263 171 303 minecraft:cut_sandstone
fill 262 156 315 263 171 315 minecraft:cut_sandstone
fill 263 156 304 264 171 304 minecraft:cut_sandstone
fill 263 156 314 264 171 314 minecraft:cut_sandstone
fill 264 156 305 265 171 305 minecraft:cut_sandstone
fill 264 156 313 265 171 313 minecraft:cut_sandstone
fill 265 156 306 265 171 306 minecraft:cut_sandstone
fill 265 156 312 265 171 312 minecraft:cut_sandstone
fill 266 156 307 266 171 311 minecraft:cut_sandstone
fill 277 156 285 277 216 285 minecraft:sandstone
fill 243 157 275 243 165 275 minecraft:sandstone
fill 251 157 308 251 170 310 minecraft:cut_sandstone
fill 252 157 305 252 170 306 minecraft:cut_sandstone
fill 252 157 312 252 170 313 minecraft:cut_sandstone
fill 253 157 304 253 170 304 minecraft:cut_sandstone
fill 253 157 314 253 170 314 minecraft:cut_sandstone
fill 254 157 303 254 170 303 minecraft:cut_sandstone
fill 254 157 315 254 170 315 minecraft:cut_sandstone
fill 255 157 302 256 170 302 minecraft:cut_sandstone
fill 258 157 301 260 170 301 minecraft:cut_sandstone
fill 262 157 302 263 170 302 minecraft:cut_sandstone
fill 262 157 316 263 164 316 minecraft:cut_sandstone
fill 264 157 303 264 170 303 minecraft:cut_sandstone
fill 264 157 315 264 170 315 minecraft:cut_sandstone
fill 265 157 304 265 170 304 minecraft:cut_sandstone
fill 265 157 314 265 170 314 minecraft:cut_sandstone
fill 266 157 305 266 170 306 minecraft:cut_sandstone
fill 266 157 312 266 170 313 minecraft:cut_sandstone
fill 267 157 308 267 170 310 minecraft:cut_sandstone
setblock 235 158 280 minecraft:lapis_block
setblock 235 158 302 minecraft:orange_terracotta
fill 236 158 317 236 165 317 minecraft:sandstone
setblock 237 158 317 minecraft:orange_terracotta
setblock 239 158 317 minecraft:lapis_block
fill 243 158 287 244 159 287 minecraft:sandstone
fill 251 158 306 251 169 307 minecraft:cut_sandstone
fill 251 158 311 251 169 312 minecraft:cut_sandstone
fill 252 158 304 252 169 304 minecraft:cut_sandstone
fill 252 158 314 252 169 314 minecraft:cut_sandstone
fill 253 158 303 253 169 303 minecraft:cut_sandstone
fill 253 158 315 253 169 315 minecraft:cut_sandstone
fill 254 158 302 254 169 302 minecraft:cut_sandstone
fill 256 158 301 257 169 301 minecraft:cut_sandstone
fill 261 158 301 262 169 301 minecraft:cut_sandstone
fill 264 158 302 264 169 302 minecraft:cut_sandstone
fill 264 158 316 264 164 316 minecraft:cut_sandstone
fill 265 158 303 265 169 303 minecraft:cut_sandstone
fill 265 158 315 265 169 315 minecraft:cut_sandstone
fill 266 158 304 266 169 304 minecraft:cut_sandstone
fill 266 158 314 266 169 314 minecraft:cut_sandstone
fill 267 158 306 267 169 307 minecraft:cut_sandstone
fill 267 158 311 267 169 312 minecraft:cut_sandstone
setblock 277 158 277 minecraft:black_terracotta
fill 277 158 278 277 165 278 minecraft:sandstone
setblock 277 158 279 minecraft:blue_terracotta
setblock 235 159 279 minecraft:black_terracotta
fill 235 159 280 235 161 280 minecraft:sandstone
fill 235 159 302 235 179 302 minecraft:sandstone
fill 237 159 317 237 165 317 minecraft:sandstone
fill 239 159 317 239 160 317 minecraft:sandstone
fill 250 159 308 250 168 310 minecraft:cut_sandstone
fill 251 159 305 251 168 305 minecraft:cut_sandstone
fill 251 159 313 251 168 313 minecraft:cut_sandstone
fill 255 159 301 255 168 301 minecraft:cut_sandstone
fill 256 159 300 257 159 300 minecraft:chiseled_sandstone
fill 258 159 300 260 168 300 minecraft:cut_sandstone
fill 261 159 300 262 159 300 minecraft:chiseled_sandstone
fill 263 159 301 263 168 301 minecraft:cut_sandstone
fill 267 159 305 267 168 305 minecraft:cut_sandstone
fill 267 159 313 267 168 313 minecraft:cut_sandstone
fill 268 159 308 268 168 310 minecraft:cut_sandstone
fill 277 159 277 277 165 277 minecraft:sandstone
fill 277 159 279 277 165 279 minecraft:sandstone
setblock 277 159 306 minecraft:black_terracotta
fill 235 160 279 235 216 279 minecraft:sandstone
fill 237 160 285 237 165 287 minecraft:cut_sandstone
fill 237 160 293 237 161 296 minecraft:iron_block
fill 237 160 297 237 165 299 minecraft:cut_sandstone
fill 237 160 309 237 165 311 minecraft:cut_sandstone
setblock 238 160 278 minecraft:light[level=12]
setblock 238 160 285 minecraft:light[level=12]
setblock 238 160 292 minecraft:light[level=12]
setblock 238 160 299 minecraft:light[level=12]
setblock 238 160 306 minecraft:light[level=12]
setblock 238 160 313 minecraft:light[level=12]
fill 239 160 275 239 164 275 minecraft:sandstone
setblock 240 160 275 minecraft:blue_terracotta
fill 241 160 275 241 176 275 minecraft:sandstone
fill 243 160 315 245 165 315 minecraft:cut_sandstone
setblock 245 160 278 minecraft:light[level=12]
setblock 245 160 285 minecraft:light[level=12]
setblock 245 160 292 minecraft:light[level=12]
setblock 245 160 299 minecraft:light[level=12]
setblock 245 160 306 minecraft:light[level=12]
setblock 245 160 313 minecraft:light[level=12]
fill 247 160 277 249 165 277 minecraft:cut_sandstone
fill 250 160 307 250 167 307 minecraft:cut_sandstone
fill 250 160 311 250 167 311 minecraft:cut_sandstone
fill 251 160 304 251 167 304 minecraft:cut_sandstone
fill 251 160 314 251 167 314 minecraft:cut_sandstone
setblock 252 160 278 minecraft:light[level=12]
setblock 252 160 285 minecraft:light[level=12]
setblock 252 160 292 minecraft:light[level=12]
setblock 252 160 299 minecraft:light[level=12]
fill 252 160 303 252 167 303 minecraft:cut_sandstone
fill 252 160 315 252 167 315 minecraft:cut_sandstone
fill 253 160 302 253 167 302 minecraft:cut_sandstone
fill 253 160 316 253 167 316 minecraft:cut_sandstone
fill 254 160 301 254 167 301 minecraft:cut_sandstone
setblock 256 160 300 minecraft:chiseled_sandstone
fill 257 160 300 257 167 300 minecraft:cut_sandstone
fill 259 160 277 261 165 277 minecraft:cut_sandstone
setblock 259 160 278 minecraft:light[level=12]
setblock 259 160 285 minecraft:light[level=12]
setblock 259 160 292 minecraft:light[level=12]
setblock 259 160 299 minecraft:light[level=12]
fill 260 160 317 260 165 317 minecraft:sandstone
fill 261 160 300 261 167 300 minecraft:cut_sandstone
setblock 261 160 317 minecraft:lapis_block
setblock 262 160 300 minecraft:chiseled_sandstone
fill 264 160 301 264 167 301 minecraft:cut_sandstone
fill 265 160 302 265 167 302 minecraft:cut_sandstone
fill 265 160 316 265 167 316 minecraft:cut_sandstone
setblock 266 160 278 minecraft:light[level=12]
setblock 266 160 285 minecraft:light[level=12]
setblock 266 160 292 minecraft:light[level=12]
setblock 266 160 299 minecraft:light[level=12]
fill 266 160 303 266 167 303 minecraft:cut_sandstone
fill 266 160 315 269 165 315 minecraft:cut_sandstone
fill 267 160 278 267 162 278 minecraft:shroomlight
fill 267 160 304 267 167 304 minecraft:cut_sandstone
fill 267 160 314 267 167 314 minecraft:cut_sandstone
fill 268 160 307 268 167 307 minecraft:cut_sandstone
fill 268 160 311 268 167 311 minecraft:cut_sandstone
fill 271 160 277 273 165 277 minecraft:cut_sandstone
setblock 273 160 278 minecraft:light[level=12]
setblock 273 160 285 minecraft:light[level=12]
setblock 273 160 292 minecraft:light[level=12]
setblock 273 160 299 minecraft:light[level=12]
setblock 273 160 306 minecraft:light[level=12]
setblock 273 160 313 minecraft:light[level=12]
fill 275 160 285 275 165 287 minecraft:cut_sandstone
fill 275 160 297 275 165 299 minecraft:cut_sandstone
fill 275 160 309 275 165 311 minecraft:cut_sandstone
fill 277 160 283 277 206 283 minecraft:sandstone
setblock 277 160 284 minecraft:orange_terracotta
fill 277 160 306 277 163 306 minecraft:sandstone
setblock 277 160 309 minecraft:blue_terracotta
fill 277 160 310 277 176 310 minecraft:sandstone
setblock 235 161 315 minecraft:lapis_block
setblock 239 161 317 minecraft:orange_terracotta
fill 240 161 275 240 217 275 minecraft:sandstone
setblock 247 161 275 minecraft:orange_terracotta
fill 250 161 306 250 166 306 minecraft:cut_sandstone
fill 250 161 312 250 166 312 minecraft:cut_sandstone
fill 256 161 300 256 166 300 minecraft:cut_sandstone
fill 257 161 317 257 216 317 minecraft:sandstone
setblock 258 161 317 minecraft:orange_terracotta
fill 261 161 317 261 165 317 minecraft:sandstone
fill 262 161 300 262 166 300 minecraft:cut_sandstone
fill 268 161 306 268 166 306 minecraft:cut_sandstone
fill 268 161 312 268 166 312 minecraft:cut_sandstone
fill 271 161 297 272 162 298 minecraft:sandstone
fill 272 161 317 272 165 317 minecraft:sandstone
setblock 273 161 317 minecraft:blue_terracotta
setblock 275 161 275 minecraft:orange_terracotta
fill 277 161 284 277 217 284 minecraft:sandstone
fill 277 161 309 277 201 309 minecraft:sandstone
setblock 235 162 280 minecraft:black_terracotta
fill 235 162 315 235 214 315 minecraft:sandstone
setblock 238 162 278 minecraft:light[level=15]
setblock 238 162 286 minecraft:light[level=15]
setblock 238 162 294 minecraft:light[level=15]
setblock 238 162 302 minecraft:light[level=15]
setblock 238 162 310 minecraft:light[level=15]
fill 239 162 317 239 214 317 minecraft:sandstone
setblock 246 162 278 minecraft:light[level=15]
setblock 246 162 286 minecraft:light[level=15]
setblock 246 162 294 minecraft:light[level=15]
setblock 246 162 302 minecraft:light[level=15]
setblock 246 162 310 minecraft:light[level=15]
fill 247 162 275 247 213 275 minecraft:sandstone
fill 250 162 305 250 165 305 minecraft:cut_sandstone
fill 250 162 313 250 165 313 minecraft:cut_sandstone
fill 252 162 302 252 165 302 minecraft:cut_sandstone
fill 252 162 316 252 164 316 minecraft:cut_sandstone
setblock 254 162 278 minecraft:light[level=15]
setblock 254 162 286 minecraft:light[level=15]
setblock 254 162 294 minecraft:light[level=15]
fill 255 162 300 255 165 300 minecraft:cut_sandstone
fill 258 162 317 258 196 317 minecraft:sandstone
setblock 262 162 278 minecraft:light[level=15]
setblock 262 162 286 minecraft:light[level=15]
setblock 262 162 294 minecraft:light[level=15]
fill 263 162 300 263 165 300 minecraft:cut_sandstone
fill 266 162 302 266 165 302 minecraft:cut_sandstone
setblock 267 162 275 minecraft:blue_terracotta
fill 268 162 275 268 163 275 minecraft:sandstone
fill 268 162 305 268 165 305 minecraft:cut_sandstone
fill 268 162 313 268 165 313 minecraft:cut_sandstone
setblock 270 162 278 minecraft:light[level=15]
setblock 270 162 286 minecraft:light[level=15]
setblock 270 162 294 minecraft:light[level=15]
setblock 270 162 302 minecraft:light[level=15]
setblock 270 162 310 minecraft:light[level=15]
fill 273 162 317 273 165 317 minecraft:sandstone
fill 275 162 275 275 213 275 minecraft:sandstone
fill 235 163 280 235 212 280 minecraft:sandstone
setblock 235 163 290 minecraft:black_terracotta
fill 235 163 291 235 216 291 minecraft:sandstone
setblock 235 163 301 minecraft:blue_terracotta
setblock 235 163 308 minecraft:blue_terracotta
fill 248 163 312 249 164 313 minecraft:sandstone
setblock 252 163 317 minecraft:lapis_block
fill 267 163 275 267 165 275 minecraft:sandstone
setblock 235 164 281 minecraft:orange_terracotta
fill 235 164 290 235 170 290 minecraft:sandstone
fill 235 164 301 235 216 301 minecraft:sandstone
fill 235 164 308 235 165 308 minecraft:sandstone
fill 252 164 317 252 216 317 minecraft:sandstone
fill 254 164 300 254 167 300 minecraft:glowstone
fill 264 164 300 264 167 300 minecraft:glowstone
setblock 268 164 275 minecraft:lapis_block
fill 272 164 301 272 167 301 minecraft:iron_block
setblock 277 164 289 minecraft:orange_terracotta
fill 277 164 290 277 165 290 minecraft:sandstone
setblock 277 164 306 minecraft:blue_terracotta
setblock 235 165 281 minecraft:sandstone
fill 236 165 279 236 165 284 minecraft:chiseled_sandstone
fill 236 165 291 236 165 296 minecraft:chiseled_sandstone
fill 236 165 303 236 165 308 minecraft:chiseled_sandstone
fill 236 165 315 236 165 316 minecraft:chiseled_sandstone
fill 237 165 316 240 165 316 minecraft:chiseled_sandstone
setblock 239 165 275 minecraft:blue_terracotta
fill 240 165 276 245 165 276 minecraft:chiseled_sandstone
fill 247 165 316 252 165 316 minecraft:chiseled_sandstone
fill 252 165 276 257 165 276 minecraft:chiseled_sandstone
fill 255 165 299 255 166 299 minecraft:glowstone
fill 257 165 316 258 171 316 minecraft:cut_sandstone
fill 259 165 316 264 165 316 minecraft:chiseled_sandstone
fill 263 165 299 263 166 299 minecraft:glowstone
fill 264 165 276 269 165 276 minecraft:chiseled_sandstone
setblock 268 165 275 minecraft:sandstone
fill 271 165 316 276 165 316 minecraft:chiseled_sandstone
fill 276 165 276 276 165 281 minecraft:chiseled_sandstone
fill 276 165 288 276 165 293 minecraft:chiseled_sandstone
fill 276 165 300 276 165 305 minecraft:chiseled_sandstone
fill 276 165 312 276 165 315 minecraft:chiseled_sandstone
setblock 277 165 289 minecraft:sandstone
fill 277 165 306 277 190 306 minecraft:sandstone
fill 235 166 281 235 171 284 minecraft:glowstone
fill 235 166 293 235 171 296 minecraft:glowstone
fill 235 166 305 235 171 308 minecraft:glowstone
fill 235 166 317 238 171 317 minecraft:glowstone
setblock 238 166 278 minecraft:light[level=12]
setblock 238 166 285 minecraft:light[level=12]
setblock 238 166 292 minecraft:light[level=12]
setblock 238 166 299 minecraft:light[level=12]
setblock 238 166 306 minecraft:light[level=12]
setblock 238 166 313 minecraft:light[level=12]
fill 239 166 275 239 187 275 minecraft:sandstone
fill 242 166 275 245 171 275 minecraft:glowstone
setblock 245 166 278 minecraft:light[level=12]
setblock 245 166 285 minecraft:light[level=12]
setblock 245 166 292 minecraft:light[level=12]
setblock 245 166 299 minecraft:light[level=12]
setblock 245 166 306 minecraft:light[level=12]
setblock 245 166 313 minecraft:light[level=12]
fill 247 166 317 250 171 317 minecraft:glowstone
fill 251 166 317 251 216 317 minecraft:sandstone
setblock 252 166 278 minecraft:light[level=12]
setblock 252 166 285 minecraft:light[level=12]
setblock 252 166 292 minecraft:light[level=12]
setblock 252 166 299 minecraft:light[level=12]
fill 254 166 275 257 171 275 minecraft:glowstone
fill 255 166 300 255 167 300 minecraft:glowstone
setblock 259 166 278 minecraft:light[level=12]
setblock 259 166 285 minecraft:light[level=12]
setblock 259 166 292 minecraft:light[level=12]
setblock 259 166 299 minecraft:light[level=12]
fill 259 166 316 264 169 316 minecraft:cut_sandstone
fill 259 166 317 262 171 317 minecraft:glowstone
fill 263 166 300 263 167 300 minecraft:glowstone
fill 266 166 275 269 171 275 minecraft:glowstone
setblock 266 166 278 minecraft:light[level=12]
setblock 266 166 285 minecraft:light[level=12]
setblock 266 166 292 minecraft:light[level=12]
setblock 266 166 299 minecraft:light[level=12]
fill 266 166 315 266 167 315 minecraft:cut_sandstone
fill 271 166 317 274 171 317 minecraft:glowstone
setblock 273 166 278 minecraft:light[level=12]
setblock 273 166 285 minecraft:light[level=12]
setblock 273 166 292 minecraft:light[level=12]
setblock 273 166 299 minecraft:light[level=12]
setblock 273 166 306 minecraft:light[level=12]
setblock 273 166 313 minecraft:light[level=12]
fill 277 166 276 277 171 279 minecraft:glowstone
fill 277 166 288 277 171 291 minecraft:glowstone
setblock 277 166 299 minecraft:lapis_block
fill 277 166 300 277 171 303 minecraft:glowstone
fill 277 166 312 277 171 315 minecraft:glowstone
setblock 256 167 300 minecraft:glowstone
setblock 262 167 300 minecraft:glowstone
fill 277 167 299 277 216 299 minecraft:sandstone
fill 272 168 296 275 168 306 minecraft:chiseled_sandstone
setblock 277 168 292 minecraft:lapis_block
fill 277 168 293 277 186 297 minecraft:sandstone
fill 272 169 296 275 169 306 minecraft:cut_sandstone
setblock 276 169 317 minecraft:black_terracotta
fill 277 169 292 277 216 292 minecraft:sandstone
setblock 235 170 276 minecraft:lapis_block
setblock 238 170 278 minecraft:light[level=15]
setblock 238 170 286 minecraft:light[level=15]
setblock 238 170 294 minecraft:light[level=15]
setblock 238 170 302 minecraft:light[level=15]
setblock 238 170 310 minecraft:light[level=15]
setblock 246 170 275 minecraft:orange_terracotta
setblock 246 170 278 minecraft:light[level=15]
setblock 246 170 286 minecraft:light[level=15]
setblock 246 170 294 minecraft:light[level=15]
setblock 246 170 302 minecraft:light[level=15]
setblock 246 170 310 minecraft:light[level=15]
setblock 254 170 278 minecraft:light[level=15]
setblock 254 170 286 minecraft:light[level=15]
setblock 254 170 294 minecraft:light[level=15]
setblock 254 170 302 minecraft:light[level=15]
fill 259 170 316 263 170 316 minecraft:cut_sandstone
setblock 262 170 278 minecraft:light[level=15]
setblock 262 170 286 minecraft:light[level=15]
setblock 262 170 294 minecraft:light[level=15]
setblock 270 170 278 minecraft:light[level=15]
setblock 270 170 286 minecraft:light[level=15]
setblock 270 170 294 minecraft:light[level=15]
setblock 270 170 302 minecraft:light[level=15]
setblock 270 170 310 minecraft:light[level=15]
fill 272 170 296 272 170 306 minecraft:lapis_block
fill 276 170 300 276 173 302 minecraft:glowstone
fill 276 170 317 276 216 317 minecraft:sandstone
fill 235 171 276 235 216 276 minecraft:sandstone
setblock 235 171 290 minecraft:orange_terracotta
fill 246 171 275 246 216 275 minecraft:sandstone
setblock 258 171 275 minecraft:orange_terracotta
fill 259 171 275 260 182 275 minecraft:sandstone
fill 259 171 316 261 171 316 minecraft:cut_sandstone
setblock 272 171 296 minecraft:cut_sandstone
setblock 272 171 301 minecraft:cut_sandstone
setblock 272 171 306 minecraft:cut_sandstone
fill 235 172 281 235 185 281 minecraft:sandstone
fill 235 172 282 235 172 283 minecraft:glowstone
fill 235 172 284 235 185 284 minecraft:sandstone
fill 235 172 290 235 181 290 minecraft:sandstone
fill 235 172 293 235 173 293 minecraft:sandstone
fill 235 172 294 235 172 295 minecraft:glowstone
fill 235 172 296 235 179 296 minecraft:sandstone
fill 235 172 305 235 178 305 minecraft:sandstone
fill 235 172 306 235 172 307 minecraft:glowstone
fill 235 172 308 235 185 308 minecraft:sandstone
fill 235 172 317 235 185 317 minecraft:sandstone
fill 236 172 317 237 172 317 minecraft:glowstone
setblock 238 172 278 minecraft:light[level=12]
setblock 238 172 285 minecraft:light[level=12]
setblock 238 172 292 minecraft:light[level=12]
setblock 238 172 299 minecraft:light[level=12]
setblock 238 172 306 minecraft:light[level=12]
setblock 238 172 313 minecraft:light[level=12]
fill 238 172 317 238 185 317 minecraft:sandstone
fill 242 172 275 242 185 275 minecraft:sandstone
fill 243 172 275 244 172 275 minecraft:glowstone
fill 245 172 275 245 185 275 minecraft:sandstone
setblock 245 172 278 minecraft:light[level=12]
setblock 245 172 285 minecraft:light[level=12]
setblock 245 172 292 minecraft:light[level=12]
setblock 245 172 299 minecraft:light[level=12]
setblock 245 172 306 minecraft:light[level=12]
setblock 245 172 313 minecraft:light[level=12]
fill 247 172 317 247 185 317 minecraft:sandstone
fill 248 172 317 249 172 317 minecraft:glowstone
fill 250 172 317 250 185 317 minecraft:sandstone
setblock 252 172 278 minecraft:light[level=12]
setblock 252 172 285 minecraft:light[level=12]
setblock 252 172 292 minecraft:light[level=12]
setblock 252 172 299 minecraft:light[level=12]
setblock 252 172 306 minecraft:light[level=12]
setblock 252 172 313 minecraft:light[level=12]
fill 254 172 275 254 185 275 minecraft:sandstone
fill 255 172 275 256 172 275 minecraft:glowstone
fill 257 172 275 258 183 275 minecraft:sandstone
setblock 259 172 278 minecraft:light[level=12]
setblock 259 172 285 minecraft:light[level=12]
setblock 259 172 292 minecraft:light[level=12]
setblock 259 172 299 minecraft:light[level=12]
fill 259 172 317 259 185 317 minecraft:sandstone
fill 260 172 317 261 172 317 minecraft:glowstone
fill 262 172 317 262 185 317 minecraft:sandstone
fill 266 172 275 266 185 275 minecraft:sandstone
setblock 266 172 278 minecraft:light[level=12]
setblock 266 172 285 minecraft:light[level=12]
setblock 266 172 292 minecraft:light[level=12]
setblock 266 172 299 minecraft:light[level=12]
setblock 266 172 306 minecraft:light[level=12]
setblock 266 172 313 minecraft:light[level=12]
fill 267 172 275 268 172 275 minecraft:glowstone
fill 269 172 275 269 185 275 minecraft:sandstone
setblock 271 172 317 minecraft:sandstone
fill 272 172 317 273 172 317 minecraft:glowstone
setblock 273 172 278 minecraft:light[level=12]
setblock 273 172 285 minecraft:light[level=12]
setblock 273 172 292 minecraft:light[level=12]
setblock 273 172 299 minecraft:light[level=12]
setblock 273 172 306 minecraft:light[level=12]
setblock 273 172 313 minecraft:light[level=12]
fill 274 172 317 274 185 317 minecraft:sandstone
fill 277 172 276 277 185 276 minecraft:sandstone
fill 277 172 277 277 172 278 minecraft:glowstone
fill 277 172 279 277 185 279 minecraft:sandstone
fill 277 172 286 277 205 286 minecraft:sandstone
setblock 277 172 287 minecraft:lapis_block
fill 277 172 288 277 177 288 minecraft:sandstone
fill 277 172 289 277 172 290 minecraft:glowstone
fill 277 172 291 277 185 291 minecraft:sandstone
fill 277 172 300 277 185 300 minecraft:sandstone
fill 277 172 301 277 172 302 minecraft:glowstone
fill 277 172 303 277 185 303 minecraft:sandstone
fill 277 172 312 277 185 312 minecraft:sandstone
fill 277 172 313 277 172 314 minecraft:glowstone
fill 277 172 315 277 185 315 minecraft:sandstone
setblock 235 173 282 minecraft:black_terracotta
fill 235 173 283 235 185 283 minecraft:sandstone
fill 235 173 294 235 185 295 minecraft:sandstone
fill 235 173 306 235 178 307 minecraft:sandstone
fill 236 173 317 237 178 317 minecraft:sandstone
fill 240 173 305 240 176 305 minecraft:iron_block
fill 243 173 275 244 185 275 minecraft:sandstone
fill 248 173 317 249 174 317 minecraft:sandstone
fill 255 173 275 256 185 275 minecraft:sandstone
fill 260 173 317 261 176 317 minecraft:sandstone
fill 267 173 275 268 173 275 minecraft:sandstone
fill 271 173 317 271 174 317 minecraft:blue_terracotta
fill 272 173 317 273 185 317 minecraft:sandstone
fill 277 173 277 277 185 278 minecraft:sandstone
fill 277 173 287 277 213 287 minecraft:sandstone
fill 277 173 289 277 181 290 minecraft:sandstone
fill 277 173 301 277 182 302 minecraft:sandstone
fill 277 173 313 277 185 314 minecraft:sandstone
fill 235 174 282 235 185 282 minecraft:sandstone
setblock 235 174 293 minecraft:black_terracotta
fill 267 174 275 267 185 275 minecraft:sandstone
setblock 268 174 275 minecraft:blue_terracotta
setblock 269 174 317 minecraft:blue_terracotta
setblock 277 174 308 minecraft:orange_terracotta
fill 235 175 293 235 185 293 minecraft:sandstone
fill 235 175 297 235 212 298 minecraft:sandstone
setblock 235 175 299 minecraft:blue_terracotta
fill 248 175 317 248 185 317 minecraft:sandstone
setblock 249 175 317 minecraft:orange_terracotta
fill 268 175 275 268 185 275 minecraft:sandstone
fill 269 175 317 269 219 317 minecraft:sandstone
fill 271 175 317 271 185 317 minecraft:sandstone
fill 277 175 308 277 216 308 minecraft:sandstone
fill 235 176 299 235 214 299 minecraft:sandstone
setblock 238 176 275 minecraft:lapis_block
fill 249 176 317 249 182 317 minecraft:sandstone
fill 263 176 317 263 217 317 minecraft:sandstone
setblock 264 176 317 minecraft:blue_terracotta
fill 236 177 301 240 177 309 minecraft:chiseled_sandstone
fill 238 177 275 238 216 275 minecraft:sandstone
setblock 241 177 275 minecraft:lapis_block
setblock 248 177 275 minecraft:blue_terracotta
fill 251 177 279 251 178 280 minecraft:sandstone
fill 260 177 317 260 185 317 minecraft:sandstone
setblock 261 177 317 minecraft:black_terracotta
fill 264 177 317 264 216 317 minecraft:sandstone
fill 277 177 310 277 178 310 minecraft:orange_terracotta
fill 236 178 301 240 178 309 minecraft:cut_sandstone
setblock 238 178 278 minecraft:light[level=15]
setblock 238 178 285 minecraft:light[level=12]
setblock 238 178 286 minecraft:light[level=15]
setblock 238 178 292 minecraft:light[level=12]
setblock 238 178 294 minecraft:light[level=15]
setblock 238 178 299 minecraft:light[level=12]
setblock 238 178 310 minecraft:light[level=15]
setblock 238 178 313 minecraft:light[level=12]
fill 241 178 275 241 216 275 minecraft:sandstone
setblock 245 178 278 minecraft:light[level=12]
setblock 245 178 285 minecraft:light[level=12]
setblock 245 178 292 minecraft:light[level=12]
setblock 245 178 299 minecraft:light[level=12]
setblock 245 178 306 minecraft:light[level=12]
setblock 245 178 313 minecraft:light[level=12]
setblock 246 178 278 minecraft:light[level=15]
setblock 246 178 286 minecraft:light[level=15]
setblock 246 178 294 minecraft:light[level=15]
setblock 246 178 302 minecraft:light[level=15]
setblock 246 178 310 minecraft:light[level=15]
fill 248 178 275 248 186 275 minecraft:sandstone
setblock 252 178 278 minecraft:light[level=12]
setblock 252 178 285 minecraft:light[level=12]
setblock 252 178 292 minecraft:light[level=12]
setblock 252 178 299 minecraft:light[level=12]
setblock 252 178 306 minecraft:light[level=12]
setblock 252 178 313 minecraft:light[level=12]
setblock 254 178 278 minecraft:light[level=15]
setblock 254 178 286 minecraft:light[level=15]
setblock 254 178 294 minecraft:light[level=15]
setblock 254 178 302 minecraft:light[level=15]
setblock 254 178 310 minecraft:light[level=15]
setblock 259 178 278 minecraft:light[level=12]
setblock 259 178 285 minecraft:light[level=12]
setblock 259 178 292 minecraft:light[level=12]
setblock 259 178 299 minecraft:light[level=12]
setblock 259 178 306 minecraft:light[level=12]
setblock 259 178 313 minecraft:light[level=12]
fill 261 178 317 261 182 317 minecraft:sandstone
setblock 262 178 278 minecraft:light[level=15]
setblock 262 178 286 minecraft:light[level=15]
setblock 262 178 294 minecraft:light[level=15]
setblock 262 178 302 minecraft:light[level=15]
setblock 262 178 310 minecraft:light[level=15]
setblock 266 178 278 minecraft:light[level=12]
setblock 266 178 285 minecraft:light[level=12]
setblock 266 178 292 minecraft:light[level=12]
setblock 266 178 299 minecraft:light[level=12]
setblock 266 178 306 minecraft:light[level=12]
setblock 266 178 313 minecraft:light[level=12]
setblock 270 178 278 minecraft:light[level=15]
setblock 270 178 286 minecraft:light[level=15]
setblock 270 178 294 minecraft:light[level=15]
setblock 270 178 302 minecraft:light[level=15]
setblock 270 178 310 minecraft:light[level=15]
setblock 273 178 278 minecraft:light[level=12]
setblock 273 178 285 minecraft:light[level=12]
setblock 273 178 292 minecraft:light[level=12]
setblock 273 178 299 minecraft:light[level=12]
setblock 273 178 306 minecraft:light[level=12]
setblock 273 178 313 minecraft:light[level=12]
setblock 277 178 288 minecraft:black_terracotta
fill 235 179 304 235 182 306 minecraft:glowstone
fill 235 179 307 235 185 307 minecraft:sandstone
setblock 236 179 317 minecraft:blue_terracotta
fill 237 179 317 237 185 317 minecraft:sandstone
fill 240 179 301 240 179 309 minecraft:lapis_block
setblock 240 179 317 minecraft:lapis_block
fill 277 179 288 277 185 288 minecraft:sandstone
fill 277 179 310 277 208 310 minecraft:sandstone
setblock 235 180 296 minecraft:black_terracotta
setblock 235 180 302 minecraft:lapis_block
fill 236 180 317 236 185 317 minecraft:sandstone
fill 237 180 285 237 185 287 minecraft:cut_sandstone
fill 237 180 297 237 185 299 minecraft:cut_sandstone
fill 237 180 309 237 185 311 minecraft:cut_sandstone
setblock 240 180 301 minecraft:cut_sandstone
setblock 240 180 305 minecraft:cut_sandstone
setblock 240 180 309 minecraft:cut_sandstone
fill 240 180 317 240 212 317 minecraft:sandstone
fill 243 180 315 245 185 315 minecraft:cut_sandstone
fill 247 180 277 249 185 277 minecraft:cut_sandstone
fill 255 180 315 257 185 315 minecraft:cut_sandstone
fill 259 180 277 261 185 277 minecraft:cut_sandstone
fill 267 180 315 269 185 315 minecraft:cut_sandstone
fill 271 180 277 273 185 277 minecraft:cut_sandstone
fill 275 180 285 275 185 287 minecraft:cut_sandstone
fill 275 180 297 275 185 299 minecraft:cut_sandstone
fill 275 180 309 275 185 311 minecraft:cut_sandstone
fill 235 181 296 235 185 296 minecraft:sandstone
fill 235 181 302 235 216 302 minecraft:sandstone
setblock 235 181 316 minecraft:lapis_block
setblock 235 182 290 minecraft:orange_terracotta
fill 235 182 316 235 187 316 minecraft:sandstone
setblock 277 182 289 minecraft:blue_terracotta
fill 277 182 290 277 185 290 minecraft:sandstone
fill 235 183 290 235 216 290 minecraft:sandstone
fill 235 183 304 235 185 306 minecraft:sandstone
fill 245 183 310 247 184 310 minecraft:smooth_sandstone
fill 246 183 309 246 184 309 minecraft:smooth_sandstone
fill 246 183 311 246 184 311 minecraft:smooth_sandstone
setblock 249 183 317 minecraft:blue_terracotta
fill 259 183 275 259 209 275 minecraft:sandstone
setblock 260 183 275 minecraft:lapis_block
setblock 261 183 317 minecraft:lapis_block
fill 277 183 289 277 185 289 minecraft:sandstone
fill 277 183 301 277 185 301 minecraft:sandstone
setblock 277 183 302 minecraft:blue_terracotta
setblock 277 183 307 minecraft:black_terracotta
setblock 238 184 278 minecraft:light[level=12]
setblock 238 184 285 minecraft:light[level=12]
setblock 238 184 292 minecraft:light[level=12]
setblock 238 184 299 minecraft:light[level=12]
setblock 238 184 306 minecraft:light[level=12]
setblock 238 184 313 minecraft:light[level=12]
setblock 245 184 278 minecraft:light[level=12]
setblock 245 184 285 minecraft:light[level=12]
setblock 245 184 292 minecraft:light[level=12]
setblock 245 184 299 minecraft:light[level=12]
setblock 245 184 306 minecraft:light[level=12]
setblock 245 184 313 minecraft:light[level=12]
fill 249 184 317 249 185 317 minecraft:sandstone
setblock 252 184 278 minecraft:light[level=12]
setblock 252 184 285 minecraft:light[level=12]
setblock 252 184 292 minecraft:light[level=12]
setblock 252 184 299 minecraft:light[level=12]
setblock 252 184 306 minecraft:light[level=12]
setblock 252 184 313 minecraft:light[level=12]
fill 257 184 275 257 185 275 minecraft:sandstone
setblock 258 184 275 minecraft:lapis_block
setblock 259 184 278 minecraft:light[level=12]
setblock 259 184 285 minecraft:light[level=12]
setblock 259 184 292 minecraft:light[level=12]
setblock 259 184 299 minecraft:light[level=12]
setblock 259 184 306 minecraft:light[level=12]
setblock 259 184 313 minecraft:light[level=12]
fill 260 184 275 260 216 275 minecraft:sandstone
fill 261 184 317 261 185 317 minecraft:sandstone
setblock 266 184 278 minecraft:light[level=12]
setblock 266 184 285 minecraft:light[level=12]
setblock 266 184 292 minecraft:light[level=12]
setblock 266 184 299 minecraft:light[level=12]
setblock 266 184 306 minecraft:light[level=12]
setblock 266 184 313 minecraft:light[level=12]
setblock 273 184 278 minecraft:light[level=12]
setblock 273 184 285 minecraft:light[level=12]
setblock 273 184 292 minecraft:light[level=12]
setblock 273 184 299 minecraft:light[level=12]
setblock 273 184 306 minecraft:light[level=12]
setblock 273 184 313 minecraft:light[level=12]
fill 277 184 302 277 185 302 minecraft:sandstone
fill 277 184 307 277 213 307 minecraft:sandstone
fill 236 185 279 236 185 284 minecraft:chiseled_sandstone
fill 236 185 291 236 185 296 minecraft:chiseled_sandstone
fill 236 185 303 236 185 308 minecraft:chiseled_sandstone
fill 236 185 315 236 185 316 minecraft:chiseled_sandstone
fill 237 185 316 240 185 316 minecraft:chiseled_sandstone
fill 240 185 276 245 185 276 minecraft:chiseled_sandstone
fill 247 185 316 252 185 316 minecraft:chiseled_sandstone
fill 252 185 276 257 185 276 minecraft:chiseled_sandstone
fill 258 185 275 258 189 275 minecraft:sandstone
fill 259 185 316 264 185 316 minecraft:chiseled_sandstone
fill 264 185 276 269 185 276 minecraft:chiseled_sandstone
fill 271 185 316 276 185 316 minecraft:chiseled_sandstone
fill 276 185 276 276 185 281 minecraft:chiseled_sandstone
fill 276 185 288 276 185 293 minecraft:chiseled_sandstone
fill 276 185 300 276 185 305 minecraft:chiseled_sandstone
fill 276 185 312 276 185 315 minecraft:chiseled_sandstone
fill 235 186 281 235 191 284 minecraft:glowstone
fill 235 186 287 235 192 287 minecraft:sandstone
setblock 235 186 288 minecraft:lapis_block
fill 235 186 293 235 191 296 minecraft:glowstone
setblock 235 186 304 minecraft:sandstone
fill 235 186 305 235 191 308 minecraft:glowstone
fill 235 186 317 238 191 317 minecraft:glowstone
fill 237 186 298 242 186 298 minecraft:chiseled_sandstone
setblock 238 186 278 minecraft:light[level=15]
setblock 238 186 286 minecraft:light[level=15]
setblock 238 186 294 minecraft:light[level=15]
fill 238 186 296 242 187 297 minecraft:chiseled_sandstone
fill 238 186 299 242 187 300 minecraft:chiseled_sandstone
setblock 238 186 302 minecraft:light[level=15]
setblock 238 186 310 minecraft:light[level=15]
fill 242 186 275 245 191 275 minecraft:glowstone
setblock 246 186 278 minecraft:light[level=15]
setblock 246 186 286 minecraft:light[level=15]
setblock 246 186 294 minecraft:light[level=15]
setblock 246 186 302 minecraft:light[level=15]
setblock 246 186 310 minecraft:light[level=15]
fill 247 186 317 250 191 317 minecraft:glowstone
fill 248 186 309 252 187 313 minecraft:chiseled_sandstone
fill 250 186 314 250 186 315 minecraft:chiseled_sandstone
fill 254 186 275 257 191 275 minecraft:glowstone
setblock 254 186 278 minecraft:light[level=15]
setblock 254 186 286 minecraft:light[level=15]
setblock 254 186 294 minecraft:light[level=15]
setblock 254 186 302 minecraft:light[level=15]
setblock 254 186 310 minecraft:light[level=15]
fill 259 186 317 262 191 317 minecraft:glowstone
setblock 262 186 278 minecraft:light[level=15]
setblock 262 186 286 minecraft:light[level=15]
setblock 262 186 294 minecraft:light[level=15]
setblock 262 186 302 minecraft:light[level=15]
setblock 262 186 310 minecraft:light[level=15]
fill 266 186 275 269 191 275 minecraft:glowstone
setblock 268 186 317 minecraft:lapis_block
setblock 270 186 278 minecraft:light[level=15]
setblock 270 186 286 minecraft:light[level=15]
schedule function dropper:buildpart/65_3 1t
