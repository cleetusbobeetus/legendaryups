setblock 85 168 353 minecraft:light[level=12]
fill 85 168 354 85 169 354 minecraft:dark_oak_planks
setblock 85 168 360 minecraft:light[level=12]
fill 87 168 364 87 216 364 minecraft:spruce_planks
setblock 88 168 364 minecraft:red_concrete
fill 89 168 364 89 215 364 minecraft:spruce_planks
fill 48 169 329 48 170 329 minecraft:stripped_dark_oak_log
fill 48 169 336 48 170 336 minecraft:stripped_dark_oak_log
fill 48 169 343 48 170 343 minecraft:stripped_dark_oak_log
fill 48 169 350 48 170 350 minecraft:stripped_dark_oak_log
fill 48 169 357 48 170 357 minecraft:stripped_dark_oak_log
fill 49 169 323 49 170 323 minecraft:stripped_dark_oak_log
fill 49 169 329 49 170 329 minecraft:dark_oak_planks
fill 49 169 363 49 170 363 minecraft:stripped_dark_oak_log
fill 56 169 323 56 170 323 minecraft:stripped_dark_oak_log
fill 56 169 363 56 170 363 minecraft:stripped_dark_oak_log
fill 63 169 323 63 170 323 minecraft:stripped_dark_oak_log
fill 63 169 363 63 170 363 minecraft:stripped_dark_oak_log
fill 70 169 323 70 170 323 minecraft:stripped_dark_oak_log
fill 70 169 363 70 170 363 minecraft:stripped_dark_oak_log
fill 76 169 361 76 170 361 minecraft:dark_oak_planks
fill 77 169 323 77 170 323 minecraft:stripped_dark_oak_log
fill 77 169 363 77 170 363 minecraft:stripped_dark_oak_log
fill 84 169 323 84 170 323 minecraft:stripped_dark_oak_log
fill 84 169 363 84 170 363 minecraft:stripped_dark_oak_log
fill 86 169 349 86 170 349 minecraft:dark_oak_planks
fill 86 169 354 86 170 354 minecraft:dark_oak_planks
fill 88 169 326 88 170 326 minecraft:stripped_dark_oak_log
fill 88 169 333 88 170 333 minecraft:stripped_dark_oak_log
fill 88 169 340 88 170 340 minecraft:stripped_dark_oak_log
fill 88 169 347 88 170 347 minecraft:stripped_dark_oak_log
fill 88 169 354 88 170 354 minecraft:stripped_dark_oak_log
fill 88 169 361 88 170 361 minecraft:stripped_dark_oak_log
fill 88 169 364 88 219 364 minecraft:spruce_planks
fill 48 170 323 48 170 327 minecraft:stripped_dark_oak_log
fill 48 170 330 48 170 334 minecraft:stripped_dark_oak_log
fill 48 170 337 48 170 341 minecraft:stripped_dark_oak_log
fill 48 170 344 48 170 348 minecraft:stripped_dark_oak_log
fill 48 170 351 48 170 355 minecraft:stripped_dark_oak_log
fill 48 170 358 48 170 362 minecraft:stripped_dark_oak_log
setblock 50 170 325 minecraft:light[level=15]
setblock 50 170 333 minecraft:light[level=15]
setblock 50 170 341 minecraft:light[level=15]
setblock 50 170 349 minecraft:light[level=15]
setblock 50 170 357 minecraft:light[level=15]
fill 50 170 363 54 170 363 minecraft:stripped_dark_oak_log
fill 51 170 323 55 170 323 minecraft:stripped_dark_oak_log
fill 57 170 363 61 170 363 minecraft:stripped_dark_oak_log
fill 58 170 323 62 170 323 minecraft:stripped_dark_oak_log
setblock 58 170 325 minecraft:light[level=15]
setblock 58 170 333 minecraft:light[level=15]
setblock 58 170 341 minecraft:light[level=15]
setblock 58 170 349 minecraft:light[level=15]
setblock 58 170 357 minecraft:light[level=15]
fill 60 170 351 60 171 351 minecraft:shroomlight
fill 64 170 363 68 170 363 minecraft:stripped_dark_oak_log
fill 65 170 323 69 170 323 minecraft:stripped_dark_oak_log
setblock 66 170 325 minecraft:light[level=15]
setblock 66 170 333 minecraft:light[level=15]
setblock 66 170 341 minecraft:light[level=15]
setblock 66 170 349 minecraft:light[level=15]
setblock 66 170 357 minecraft:light[level=15]
fill 71 170 363 75 170 363 minecraft:stripped_dark_oak_log
fill 72 170 323 76 170 323 minecraft:stripped_dark_oak_log
setblock 74 170 325 minecraft:light[level=15]
setblock 74 170 333 minecraft:light[level=15]
setblock 74 170 341 minecraft:light[level=15]
setblock 74 170 349 minecraft:light[level=15]
setblock 74 170 357 minecraft:light[level=15]
fill 76 170 362 76 171 362 minecraft:dark_oak_planks
fill 78 170 363 82 170 363 minecraft:stripped_dark_oak_log
fill 79 170 323 83 170 323 minecraft:stripped_dark_oak_log
setblock 82 170 325 minecraft:light[level=15]
setblock 82 170 333 minecraft:light[level=15]
setblock 82 170 341 minecraft:light[level=15]
setblock 82 170 349 minecraft:light[level=15]
setblock 82 170 357 minecraft:light[level=15]
fill 85 170 363 88 170 363 minecraft:stripped_dark_oak_log
fill 86 170 323 88 170 323 minecraft:stripped_dark_oak_log
fill 87 170 349 87 171 349 minecraft:dark_oak_planks
fill 87 170 354 87 171 354 minecraft:dark_oak_planks
fill 88 170 324 88 170 325 minecraft:stripped_dark_oak_log
fill 88 170 328 88 170 332 minecraft:stripped_dark_oak_log
fill 88 170 335 88 170 339 minecraft:stripped_dark_oak_log
fill 88 170 342 88 170 346 minecraft:stripped_dark_oak_log
fill 88 170 349 88 170 353 minecraft:stripped_dark_oak_log
fill 88 170 356 88 170 360 minecraft:stripped_dark_oak_log
fill 48 171 324 48 172 324 minecraft:stripped_dark_oak_log
setblock 48 171 329 minecraft:dark_oak_planks
fill 48 171 331 48 172 331 minecraft:stripped_dark_oak_log
fill 48 171 338 48 172 338 minecraft:stripped_dark_oak_log
fill 48 171 345 48 172 345 minecraft:stripped_dark_oak_log
fill 48 171 352 48 172 352 minecraft:stripped_dark_oak_log
fill 48 171 359 48 172 359 minecraft:stripped_dark_oak_log
fill 51 171 363 51 172 363 minecraft:stripped_dark_oak_log
setblock 53 171 328 minecraft:shroomlight
setblock 53 171 334 minecraft:shroomlight
setblock 53 171 340 minecraft:shroomlight
setblock 53 171 346 minecraft:shroomlight
setblock 53 171 352 minecraft:shroomlight
setblock 53 171 358 minecraft:shroomlight
fill 54 171 323 54 172 323 minecraft:stripped_dark_oak_log
fill 58 171 363 58 172 363 minecraft:stripped_dark_oak_log
setblock 59 171 328 minecraft:shroomlight
setblock 59 171 358 minecraft:shroomlight
fill 61 171 323 61 172 323 minecraft:stripped_dark_oak_log
setblock 65 171 328 minecraft:shroomlight
setblock 65 171 358 minecraft:shroomlight
fill 65 171 363 65 172 363 minecraft:stripped_dark_oak_log
fill 68 171 323 68 172 323 minecraft:stripped_dark_oak_log
setblock 70 171 364 minecraft:red_concrete
setblock 71 171 328 minecraft:shroomlight
setblock 71 171 358 minecraft:shroomlight
fill 72 171 363 72 172 363 minecraft:stripped_dark_oak_log
fill 75 171 323 75 172 323 minecraft:stripped_dark_oak_log
setblock 77 171 328 minecraft:shroomlight
setblock 77 171 358 minecraft:shroomlight
fill 79 171 363 79 172 363 minecraft:stripped_dark_oak_log
fill 82 171 323 82 172 323 minecraft:stripped_dark_oak_log
setblock 83 171 328 minecraft:shroomlight
setblock 83 171 334 minecraft:shroomlight
setblock 83 171 340 minecraft:shroomlight
setblock 83 171 346 minecraft:shroomlight
setblock 83 171 352 minecraft:shroomlight
setblock 83 171 358 minecraft:shroomlight
fill 86 171 363 86 172 363 minecraft:stripped_dark_oak_log
fill 88 171 324 88 172 324 minecraft:stripped_dark_oak_log
fill 88 171 331 88 172 331 minecraft:stripped_dark_oak_log
fill 88 171 338 88 172 338 minecraft:stripped_dark_oak_log
fill 88 171 345 88 172 345 minecraft:stripped_dark_oak_log
fill 88 171 352 88 172 352 minecraft:stripped_dark_oak_log
fill 88 171 359 88 172 359 minecraft:stripped_dark_oak_log
fill 48 172 323 49 172 323 minecraft:stripped_dark_oak_log
fill 48 172 325 87 172 327 minecraft:stripped_dark_oak_log
fill 48 172 329 53 172 330 minecraft:stripped_dark_oak_log
fill 48 172 332 53 172 334 minecraft:stripped_dark_oak_log
fill 48 172 336 53 172 337 minecraft:stripped_dark_oak_log
fill 48 172 339 53 172 341 minecraft:stripped_dark_oak_log
fill 48 172 343 53 172 344 minecraft:stripped_dark_oak_log
fill 48 172 346 53 172 348 minecraft:stripped_dark_oak_log
fill 48 172 350 53 172 351 minecraft:stripped_dark_oak_log
fill 48 172 353 53 172 355 minecraft:stripped_dark_oak_log
fill 48 172 357 53 172 358 minecraft:stripped_dark_oak_log
fill 48 172 360 87 172 362 minecraft:stripped_dark_oak_log
fill 49 172 324 87 172 324 minecraft:stripped_dark_oak_log
fill 49 172 328 88 172 328 minecraft:stripped_dark_oak_log
fill 49 172 331 53 172 331 minecraft:stripped_dark_oak_log
fill 49 172 335 53 172 335 minecraft:stripped_dark_oak_log
fill 49 172 338 53 172 338 minecraft:stripped_dark_oak_log
fill 49 172 342 53 172 342 minecraft:stripped_dark_oak_log
fill 49 172 345 53 172 345 minecraft:stripped_dark_oak_log
fill 49 172 349 53 172 349 minecraft:stripped_dark_oak_log
fill 49 172 352 53 172 352 minecraft:stripped_dark_oak_log
fill 49 172 356 53 172 356 minecraft:stripped_dark_oak_log
fill 49 172 359 87 172 359 minecraft:stripped_dark_oak_log
fill 49 172 363 50 172 363 minecraft:stripped_dark_oak_log
fill 51 172 323 53 172 323 minecraft:stripped_dark_oak_log
fill 52 172 363 54 172 363 minecraft:stripped_dark_oak_log
fill 54 172 358 88 172 358 minecraft:stripped_dark_oak_log
fill 55 172 323 56 172 323 minecraft:stripped_dark_oak_log
fill 56 172 363 57 172 363 minecraft:stripped_dark_oak_log
fill 58 172 323 60 172 323 minecraft:stripped_dark_oak_log
fill 59 172 363 61 172 363 minecraft:stripped_dark_oak_log
fill 60 172 351 60 180 351 minecraft:dark_oak_planks
fill 62 172 323 63 172 323 minecraft:stripped_dark_oak_log
fill 63 172 363 64 172 363 minecraft:stripped_dark_oak_log
fill 65 172 323 67 172 323 minecraft:stripped_dark_oak_log
fill 66 172 363 68 172 363 minecraft:stripped_dark_oak_log
fill 69 172 323 70 172 323 minecraft:stripped_dark_oak_log
fill 70 172 363 71 172 363 minecraft:stripped_dark_oak_log
fill 70 172 364 70 217 364 minecraft:spruce_planks
fill 72 172 323 74 172 323 minecraft:stripped_dark_oak_log
fill 73 172 363 75 172 363 minecraft:stripped_dark_oak_log
fill 76 172 323 77 172 323 minecraft:stripped_dark_oak_log
fill 77 172 363 78 172 363 minecraft:stripped_dark_oak_log
fill 79 172 323 81 172 323 minecraft:stripped_dark_oak_log
fill 80 172 363 82 172 363 minecraft:stripped_dark_oak_log
fill 83 172 323 84 172 323 minecraft:stripped_dark_oak_log
fill 83 172 329 87 172 357 minecraft:stripped_dark_oak_log
fill 84 172 363 85 172 363 minecraft:stripped_dark_oak_log
fill 86 172 323 88 172 323 minecraft:stripped_dark_oak_log
fill 87 172 363 88 172 363 minecraft:stripped_dark_oak_log
fill 88 172 325 88 172 326 minecraft:stripped_dark_oak_log
fill 88 172 329 88 172 330 minecraft:stripped_dark_oak_log
fill 88 172 332 88 172 333 minecraft:stripped_dark_oak_log
fill 88 172 335 88 172 337 minecraft:stripped_dark_oak_log
fill 88 172 339 88 172 340 minecraft:stripped_dark_oak_log
fill 88 172 342 88 172 344 minecraft:stripped_dark_oak_log
fill 88 172 346 88 172 347 minecraft:stripped_dark_oak_log
fill 88 172 349 88 172 351 minecraft:stripped_dark_oak_log
fill 88 172 353 88 172 354 minecraft:stripped_dark_oak_log
fill 88 172 356 88 172 357 minecraft:stripped_dark_oak_log
fill 88 172 360 88 172 361 minecraft:stripped_dark_oak_log
setblock 48 173 326 minecraft:stripped_dark_oak_log
setblock 48 173 333 minecraft:stripped_dark_oak_log
setblock 48 173 340 minecraft:stripped_dark_oak_log
setblock 48 173 347 minecraft:stripped_dark_oak_log
setblock 48 173 354 minecraft:stripped_dark_oak_log
setblock 48 173 361 minecraft:stripped_dark_oak_log
setblock 52 173 323 minecraft:stripped_dark_oak_log
fill 53 173 328 53 173 358 minecraft:red_concrete
setblock 53 173 363 minecraft:stripped_dark_oak_log
fill 54 173 328 83 173 328 minecraft:red_concrete
fill 54 173 358 83 173 358 minecraft:red_concrete
setblock 59 173 323 minecraft:stripped_dark_oak_log
fill 60 173 352 60 180 352 minecraft:dark_oak_planks
setblock 60 173 363 minecraft:stripped_dark_oak_log
setblock 66 173 323 minecraft:stripped_dark_oak_log
setblock 67 173 363 minecraft:stripped_dark_oak_log
setblock 73 173 323 minecraft:stripped_dark_oak_log
setblock 74 173 363 minecraft:stripped_dark_oak_log
setblock 80 173 323 minecraft:stripped_dark_oak_log
setblock 81 173 363 minecraft:stripped_dark_oak_log
fill 83 173 329 83 173 357 minecraft:red_concrete
setblock 87 173 323 minecraft:stripped_dark_oak_log
setblock 88 173 329 minecraft:stripped_dark_oak_log
setblock 88 173 336 minecraft:stripped_dark_oak_log
setblock 88 173 343 minecraft:stripped_dark_oak_log
setblock 88 173 350 minecraft:stripped_dark_oak_log
setblock 88 173 357 minecraft:stripped_dark_oak_log
setblock 88 173 363 minecraft:stripped_dark_oak_log
setblock 48 174 327 minecraft:stripped_dark_oak_log
setblock 48 174 334 minecraft:stripped_dark_oak_log
setblock 48 174 341 minecraft:stripped_dark_oak_log
setblock 48 174 348 minecraft:stripped_dark_oak_log
setblock 48 174 355 minecraft:stripped_dark_oak_log
setblock 48 174 362 minecraft:stripped_dark_oak_log
setblock 50 174 325 minecraft:light[level=12]
setblock 50 174 332 minecraft:light[level=12]
setblock 50 174 339 minecraft:light[level=12]
setblock 50 174 346 minecraft:light[level=12]
setblock 50 174 353 minecraft:light[level=12]
setblock 50 174 360 minecraft:light[level=12]
setblock 51 174 323 minecraft:stripped_dark_oak_log
fill 53 174 360 53 175 362 minecraft:iron_bars
setblock 54 174 363 minecraft:stripped_dark_oak_log
setblock 57 174 325 minecraft:light[level=12]
setblock 57 174 332 minecraft:light[level=12]
setblock 57 174 339 minecraft:light[level=12]
setblock 57 174 346 minecraft:light[level=12]
setblock 57 174 353 minecraft:light[level=12]
setblock 57 174 360 minecraft:light[level=12]
setblock 58 174 323 minecraft:stripped_dark_oak_log
fill 59 174 351 59 180 352 minecraft:dark_oak_planks
fill 60 174 350 60 180 350 minecraft:dark_oak_planks
fill 61 174 351 61 180 352 minecraft:dark_oak_planks
setblock 61 174 363 minecraft:stripped_dark_oak_log
setblock 64 174 325 minecraft:light[level=12]
setblock 64 174 332 minecraft:light[level=12]
setblock 64 174 339 minecraft:light[level=12]
setblock 64 174 346 minecraft:light[level=12]
setblock 64 174 353 minecraft:light[level=12]
setblock 64 174 360 minecraft:light[level=12]
setblock 65 174 323 minecraft:stripped_dark_oak_log
setblock 68 174 363 minecraft:stripped_dark_oak_log
setblock 71 174 325 minecraft:light[level=12]
setblock 71 174 332 minecraft:light[level=12]
setblock 71 174 339 minecraft:light[level=12]
setblock 71 174 346 minecraft:light[level=12]
setblock 71 174 353 minecraft:light[level=12]
setblock 71 174 360 minecraft:light[level=12]
setblock 72 174 323 minecraft:stripped_dark_oak_log
setblock 75 174 363 minecraft:stripped_dark_oak_log
setblock 78 174 325 minecraft:light[level=12]
setblock 78 174 332 minecraft:light[level=12]
setblock 78 174 339 minecraft:light[level=12]
setblock 78 174 346 minecraft:light[level=12]
setblock 78 174 353 minecraft:light[level=12]
setblock 78 174 360 minecraft:light[level=12]
setblock 79 174 323 minecraft:stripped_dark_oak_log
setblock 82 174 363 minecraft:stripped_dark_oak_log
setblock 85 174 325 minecraft:light[level=12]
setblock 85 174 332 minecraft:light[level=12]
setblock 85 174 339 minecraft:light[level=12]
setblock 85 174 346 minecraft:light[level=12]
setblock 85 174 353 minecraft:light[level=12]
setblock 85 174 360 minecraft:light[level=12]
setblock 86 174 323 minecraft:stripped_dark_oak_log
setblock 88 174 328 minecraft:stripped_dark_oak_log
setblock 88 174 335 minecraft:stripped_dark_oak_log
setblock 88 174 342 minecraft:stripped_dark_oak_log
setblock 88 174 349 minecraft:stripped_dark_oak_log
setblock 88 174 356 minecraft:stripped_dark_oak_log
fill 59 175 350 59 180 350 minecraft:dark_oak_planks
fill 60 175 353 60 180 353 minecraft:dark_oak_planks
fill 61 175 350 61 180 350 minecraft:dark_oak_planks
setblock 48 176 329 minecraft:stripped_dark_oak_log
setblock 48 176 336 minecraft:stripped_dark_oak_log
setblock 48 176 343 minecraft:stripped_dark_oak_log
setblock 48 176 350 minecraft:stripped_dark_oak_log
setblock 48 176 357 minecraft:stripped_dark_oak_log
setblock 49 176 323 minecraft:stripped_dark_oak_log
setblock 49 176 363 minecraft:stripped_dark_oak_log
setblock 56 176 323 minecraft:stripped_dark_oak_log
setblock 56 176 363 minecraft:stripped_dark_oak_log
fill 58 176 350 58 180 352 minecraft:dark_oak_planks
fill 59 176 353 59 180 353 minecraft:dark_oak_planks
fill 60 176 349 60 180 349 minecraft:dark_oak_planks
fill 61 176 353 61 180 353 minecraft:dark_oak_planks
fill 62 176 350 62 180 352 minecraft:dark_oak_planks
setblock 63 176 323 minecraft:stripped_dark_oak_log
setblock 63 176 363 minecraft:stripped_dark_oak_log
setblock 70 176 323 minecraft:stripped_dark_oak_log
setblock 70 176 363 minecraft:stripped_dark_oak_log
setblock 77 176 323 minecraft:stripped_dark_oak_log
setblock 77 176 363 minecraft:stripped_dark_oak_log
setblock 84 176 323 minecraft:stripped_dark_oak_log
setblock 84 176 363 minecraft:stripped_dark_oak_log
setblock 88 176 326 minecraft:stripped_dark_oak_log
setblock 88 176 333 minecraft:stripped_dark_oak_log
setblock 88 176 340 minecraft:stripped_dark_oak_log
setblock 88 176 347 minecraft:stripped_dark_oak_log
setblock 88 176 354 minecraft:stripped_dark_oak_log
setblock 88 176 361 minecraft:stripped_dark_oak_log
setblock 48 177 323 minecraft:stripped_dark_oak_log
setblock 48 177 330 minecraft:stripped_dark_oak_log
setblock 48 177 337 minecraft:stripped_dark_oak_log
setblock 48 177 344 minecraft:stripped_dark_oak_log
setblock 48 177 351 minecraft:stripped_dark_oak_log
setblock 48 177 358 minecraft:stripped_dark_oak_log
setblock 50 177 363 minecraft:stripped_dark_oak_log
setblock 55 177 323 minecraft:stripped_dark_oak_log
setblock 57 177 363 minecraft:stripped_dark_oak_log
fill 58 177 353 58 180 353 minecraft:dark_oak_planks
fill 59 177 349 59 180 349 minecraft:dark_oak_planks
fill 60 177 354 60 180 354 minecraft:dark_oak_planks
fill 61 177 349 61 180 349 minecraft:dark_oak_planks
setblock 62 177 323 minecraft:stripped_dark_oak_log
fill 62 177 353 62 180 353 minecraft:dark_oak_planks
setblock 64 177 363 minecraft:stripped_dark_oak_log
setblock 69 177 323 minecraft:stripped_dark_oak_log
setblock 71 177 363 minecraft:stripped_dark_oak_log
setblock 76 177 323 minecraft:stripped_dark_oak_log
setblock 78 177 363 minecraft:stripped_dark_oak_log
setblock 83 177 323 minecraft:stripped_dark_oak_log
setblock 85 177 363 minecraft:stripped_dark_oak_log
setblock 88 177 325 minecraft:stripped_dark_oak_log
setblock 88 177 332 minecraft:stripped_dark_oak_log
setblock 88 177 339 minecraft:stripped_dark_oak_log
setblock 88 177 346 minecraft:stripped_dark_oak_log
setblock 88 177 353 minecraft:stripped_dark_oak_log
setblock 88 177 360 minecraft:stripped_dark_oak_log
setblock 48 178 324 minecraft:stripped_dark_oak_log
setblock 48 178 331 minecraft:stripped_dark_oak_log
setblock 48 178 338 minecraft:stripped_dark_oak_log
setblock 48 178 345 minecraft:stripped_dark_oak_log
setblock 48 178 352 minecraft:stripped_dark_oak_log
setblock 48 178 359 minecraft:stripped_dark_oak_log
setblock 50 178 325 minecraft:light[level=15]
setblock 50 178 333 minecraft:light[level=15]
setblock 50 178 341 minecraft:light[level=15]
setblock 50 178 349 minecraft:light[level=15]
setblock 50 178 357 minecraft:light[level=15]
setblock 51 178 363 minecraft:stripped_dark_oak_log
setblock 54 178 323 minecraft:stripped_dark_oak_log
fill 57 178 350 57 180 352 minecraft:dark_oak_planks
setblock 58 178 325 minecraft:light[level=15]
setblock 58 178 333 minecraft:light[level=15]
setblock 58 178 341 minecraft:light[level=15]
fill 58 178 349 58 180 349 minecraft:dark_oak_planks
setblock 58 178 357 minecraft:light[level=15]
setblock 58 178 363 minecraft:stripped_dark_oak_log
fill 59 178 354 59 180 354 minecraft:dark_oak_planks
fill 60 178 348 60 180 348 minecraft:dark_oak_planks
setblock 61 178 323 minecraft:stripped_dark_oak_log
fill 61 178 354 61 180 354 minecraft:dark_oak_planks
fill 62 178 349 62 180 349 minecraft:dark_oak_planks
fill 63 178 350 63 180 352 minecraft:dark_oak_planks
setblock 65 178 363 minecraft:stripped_dark_oak_log
setblock 66 178 325 minecraft:light[level=15]
setblock 66 178 333 minecraft:light[level=15]
setblock 66 178 341 minecraft:light[level=15]
setblock 66 178 349 minecraft:light[level=15]
setblock 66 178 357 minecraft:light[level=15]
setblock 68 178 323 minecraft:stripped_dark_oak_log
setblock 72 178 363 minecraft:stripped_dark_oak_log
setblock 74 178 325 minecraft:light[level=15]
setblock 74 178 333 minecraft:light[level=15]
setblock 74 178 341 minecraft:light[level=15]
setblock 74 178 349 minecraft:light[level=15]
setblock 74 178 357 minecraft:light[level=15]
setblock 75 178 323 minecraft:stripped_dark_oak_log
setblock 79 178 363 minecraft:stripped_dark_oak_log
fill 80 178 341 82 180 341 minecraft:cherry_leaves[persistent=true]
fill 81 178 342 83 180 343 minecraft:cherry_leaves[persistent=true]
setblock 82 178 323 minecraft:stripped_dark_oak_log
setblock 82 178 325 minecraft:light[level=15]
setblock 82 178 333 minecraft:light[level=15]
setblock 82 178 349 minecraft:light[level=15]
setblock 82 178 357 minecraft:light[level=15]
setblock 86 178 363 minecraft:stripped_dark_oak_log
setblock 88 178 324 minecraft:stripped_dark_oak_log
setblock 88 178 331 minecraft:stripped_dark_oak_log
setblock 88 178 338 minecraft:stripped_dark_oak_log
setblock 88 178 345 minecraft:stripped_dark_oak_log
setblock 88 178 352 minecraft:stripped_dark_oak_log
setblock 88 178 359 minecraft:stripped_dark_oak_log
fill 48 179 325 48 180 325 minecraft:stripped_dark_oak_log
fill 48 179 332 48 180 332 minecraft:stripped_dark_oak_log
fill 48 179 339 48 180 339 minecraft:stripped_dark_oak_log
fill 48 179 346 48 180 346 minecraft:stripped_dark_oak_log
fill 48 179 353 48 180 353 minecraft:stripped_dark_oak_log
fill 48 179 360 48 180 360 minecraft:stripped_dark_oak_log
fill 52 179 363 52 180 363 minecraft:stripped_dark_oak_log
fill 53 179 323 53 180 323 minecraft:stripped_dark_oak_log
fill 57 179 349 57 180 349 minecraft:dark_oak_planks
fill 57 179 353 57 180 353 minecraft:dark_oak_planks
fill 58 179 348 59 180 348 minecraft:dark_oak_planks
fill 58 179 354 58 180 354 minecraft:dark_oak_planks
fill 59 179 363 59 180 363 minecraft:stripped_dark_oak_log
fill 60 179 323 60 180 323 minecraft:stripped_dark_oak_log
fill 60 179 355 60 180 355 minecraft:dark_oak_planks
fill 61 179 348 62 180 348 minecraft:dark_oak_planks
fill 62 179 354 62 180 354 minecraft:dark_oak_planks
fill 63 179 349 63 180 349 minecraft:dark_oak_planks
fill 63 179 353 63 180 353 minecraft:dark_oak_planks
fill 66 179 363 66 180 363 minecraft:stripped_dark_oak_log
fill 67 179 323 67 180 323 minecraft:stripped_dark_oak_log
fill 73 179 363 73 180 363 minecraft:stripped_dark_oak_log
fill 74 179 323 74 180 323 minecraft:stripped_dark_oak_log
fill 80 179 342 80 181 343 minecraft:cherry_leaves[persistent=true]
fill 80 179 363 80 180 363 minecraft:stripped_dark_oak_log
fill 81 179 323 81 180 323 minecraft:stripped_dark_oak_log
fill 81 179 340 82 180 340 minecraft:cherry_leaves[persistent=true]
fill 81 179 344 82 180 344 minecraft:cherry_leaves[persistent=true]
fill 87 179 363 87 180 363 minecraft:stripped_dark_oak_log
fill 88 179 323 88 180 323 minecraft:stripped_dark_oak_log
fill 88 179 330 88 180 330 minecraft:stripped_dark_oak_log
fill 88 179 337 88 180 337 minecraft:stripped_dark_oak_log
fill 88 179 344 88 180 344 minecraft:stripped_dark_oak_log
fill 88 179 351 88 180 351 minecraft:stripped_dark_oak_log
fill 88 179 358 88 180 358 minecraft:stripped_dark_oak_log
fill 48 180 323 48 180 324 minecraft:stripped_dark_oak_log
fill 48 180 326 48 180 327 minecraft:stripped_dark_oak_log
fill 48 180 329 48 180 331 minecraft:stripped_dark_oak_log
fill 48 180 333 48 180 334 minecraft:stripped_dark_oak_log
fill 48 180 336 48 180 338 minecraft:stripped_dark_oak_log
fill 48 180 340 48 180 341 minecraft:stripped_dark_oak_log
fill 48 180 343 48 180 345 minecraft:stripped_dark_oak_log
fill 48 180 347 48 180 348 minecraft:stripped_dark_oak_log
fill 48 180 350 48 180 352 minecraft:stripped_dark_oak_log
fill 48 180 354 48 180 355 minecraft:stripped_dark_oak_log
fill 48 180 357 48 180 359 minecraft:stripped_dark_oak_log
fill 48 180 361 48 180 362 minecraft:stripped_dark_oak_log
setblock 49 180 323 minecraft:stripped_dark_oak_log
fill 49 180 363 51 180 363 minecraft:stripped_dark_oak_log
setblock 50 180 325 minecraft:light[level=12]
setblock 50 180 332 minecraft:light[level=12]
setblock 50 180 339 minecraft:light[level=12]
setblock 50 180 346 minecraft:light[level=12]
setblock 50 180 353 minecraft:light[level=12]
setblock 50 180 360 minecraft:light[level=12]
fill 51 180 323 52 180 323 minecraft:stripped_dark_oak_log
fill 53 180 363 54 180 363 minecraft:stripped_dark_oak_log
fill 54 180 323 56 180 323 minecraft:stripped_dark_oak_log
fill 56 180 350 56 180 352 minecraft:dark_oak_planks
fill 56 180 363 58 180 363 minecraft:stripped_dark_oak_log
setblock 57 180 325 minecraft:light[level=12]
setblock 57 180 332 minecraft:light[level=12]
setblock 57 180 339 minecraft:light[level=12]
setblock 57 180 346 minecraft:light[level=12]
setblock 57 180 354 minecraft:dark_oak_planks
setblock 57 180 360 minecraft:light[level=12]
fill 58 180 323 59 180 323 minecraft:stripped_dark_oak_log
setblock 59 180 355 minecraft:dark_oak_planks
setblock 60 180 347 minecraft:dark_oak_planks
fill 60 180 363 61 180 363 minecraft:stripped_dark_oak_log
fill 61 180 323 63 180 323 minecraft:stripped_dark_oak_log
fill 61 180 355 62 180 355 minecraft:dark_oak_planks
setblock 63 180 354 minecraft:dark_oak_planks
fill 63 180 363 65 180 363 minecraft:stripped_dark_oak_log
setblock 64 180 325 minecraft:light[level=12]
setblock 64 180 332 minecraft:light[level=12]
setblock 64 180 339 minecraft:light[level=12]
setblock 64 180 346 minecraft:light[level=12]
fill 64 180 350 64 180 352 minecraft:dark_oak_planks
setblock 64 180 353 minecraft:light[level=12]
setblock 64 180 360 minecraft:light[level=12]
fill 65 180 323 66 180 323 minecraft:stripped_dark_oak_log
fill 67 180 363 68 180 363 minecraft:stripped_dark_oak_log
fill 68 180 323 70 180 323 minecraft:stripped_dark_oak_log
fill 70 180 363 72 180 363 minecraft:stripped_dark_oak_log
setblock 71 180 325 minecraft:light[level=12]
setblock 71 180 332 minecraft:light[level=12]
setblock 71 180 339 minecraft:light[level=12]
setblock 71 180 346 minecraft:light[level=12]
setblock 71 180 353 minecraft:light[level=12]
setblock 71 180 360 minecraft:light[level=12]
fill 72 180 323 73 180 323 minecraft:stripped_dark_oak_log
fill 74 180 363 75 180 363 minecraft:stripped_dark_oak_log
fill 75 180 323 77 180 323 minecraft:stripped_dark_oak_log
fill 77 180 363 79 180 363 minecraft:stripped_dark_oak_log
setblock 78 180 325 minecraft:light[level=12]
setblock 78 180 332 minecraft:light[level=12]
setblock 78 180 339 minecraft:light[level=12]
setblock 78 180 346 minecraft:light[level=12]
setblock 78 180 353 minecraft:light[level=12]
setblock 78 180 360 minecraft:light[level=12]
fill 79 180 323 80 180 323 minecraft:stripped_dark_oak_log
fill 81 180 363 82 180 363 minecraft:stripped_dark_oak_log
fill 82 180 323 84 180 323 minecraft:stripped_dark_oak_log
fill 83 180 341 83 181 341 minecraft:cherry_leaves[persistent=true]
fill 84 180 363 86 180 363 minecraft:stripped_dark_oak_log
setblock 85 180 325 minecraft:light[level=12]
setblock 85 180 332 minecraft:light[level=12]
setblock 85 180 339 minecraft:light[level=12]
setblock 85 180 346 minecraft:light[level=12]
setblock 85 180 353 minecraft:light[level=12]
setblock 85 180 360 minecraft:light[level=12]
fill 86 180 323 87 180 323 minecraft:stripped_dark_oak_log
fill 88 180 324 88 180 326 minecraft:stripped_dark_oak_log
fill 88 180 328 88 180 329 minecraft:stripped_dark_oak_log
fill 88 180 331 88 180 333 minecraft:stripped_dark_oak_log
fill 88 180 335 88 180 336 minecraft:stripped_dark_oak_log
fill 88 180 338 88 180 340 minecraft:stripped_dark_oak_log
fill 88 180 342 88 180 343 minecraft:stripped_dark_oak_log
fill 88 180 345 88 180 347 minecraft:stripped_dark_oak_log
fill 88 180 349 88 180 350 minecraft:stripped_dark_oak_log
fill 88 180 352 88 180 354 minecraft:stripped_dark_oak_log
fill 88 180 356 88 180 357 minecraft:stripped_dark_oak_log
fill 88 180 359 88 180 361 minecraft:stripped_dark_oak_log
setblock 88 180 363 minecraft:stripped_dark_oak_log
setblock 48 181 327 minecraft:stripped_dark_oak_log
setblock 48 181 334 minecraft:stripped_dark_oak_log
setblock 48 181 341 minecraft:stripped_dark_oak_log
setblock 48 181 348 minecraft:stripped_dark_oak_log
setblock 48 181 355 minecraft:stripped_dark_oak_log
setblock 48 181 362 minecraft:stripped_dark_oak_log
setblock 51 181 323 minecraft:stripped_dark_oak_log
setblock 54 181 363 minecraft:stripped_dark_oak_log
setblock 58 181 323 minecraft:stripped_dark_oak_log
fill 60 181 351 60 184 351 minecraft:stripped_dark_oak_log
setblock 61 181 363 minecraft:stripped_dark_oak_log
setblock 65 181 323 minecraft:stripped_dark_oak_log
setblock 68 181 363 minecraft:stripped_dark_oak_log
setblock 72 181 323 minecraft:stripped_dark_oak_log
setblock 75 181 363 minecraft:stripped_dark_oak_log
setblock 79 181 323 minecraft:stripped_dark_oak_log
fill 81 181 341 81 181 343 minecraft:cherry_leaves[persistent=true]
fill 82 181 341 82 181 342 minecraft:cherry_leaves[persistent=true]
setblock 82 181 363 minecraft:stripped_dark_oak_log
setblock 83 181 342 minecraft:cherry_leaves[persistent=true]
setblock 86 181 323 minecraft:stripped_dark_oak_log
setblock 88 181 328 minecraft:stripped_dark_oak_log
setblock 88 181 335 minecraft:stripped_dark_oak_log
setblock 88 181 342 minecraft:stripped_dark_oak_log
setblock 88 181 349 minecraft:stripped_dark_oak_log
setblock 88 181 356 minecraft:stripped_dark_oak_log
setblock 66 182 322 minecraft:red_concrete
setblock 48 183 329 minecraft:stripped_dark_oak_log
setblock 48 183 336 minecraft:stripped_dark_oak_log
setblock 48 183 343 minecraft:stripped_dark_oak_log
setblock 48 183 350 minecraft:stripped_dark_oak_log
setblock 48 183 357 minecraft:stripped_dark_oak_log
setblock 49 183 323 minecraft:stripped_dark_oak_log
setblock 49 183 363 minecraft:stripped_dark_oak_log
setblock 56 183 323 minecraft:stripped_dark_oak_log
setblock 56 183 363 minecraft:stripped_dark_oak_log
setblock 63 183 323 minecraft:stripped_dark_oak_log
setblock 63 183 363 minecraft:stripped_dark_oak_log
fill 66 183 322 66 187 322 minecraft:spruce_planks
setblock 70 183 323 minecraft:stripped_dark_oak_log
setblock 70 183 363 minecraft:stripped_dark_oak_log
setblock 77 183 323 minecraft:stripped_dark_oak_log
setblock 77 183 363 minecraft:stripped_dark_oak_log
setblock 84 183 323 minecraft:stripped_dark_oak_log
setblock 84 183 363 minecraft:stripped_dark_oak_log
setblock 88 183 326 minecraft:stripped_dark_oak_log
setblock 88 183 333 minecraft:stripped_dark_oak_log
setblock 88 183 340 minecraft:stripped_dark_oak_log
setblock 88 183 347 minecraft:stripped_dark_oak_log
setblock 88 183 354 minecraft:stripped_dark_oak_log
setblock 88 183 361 minecraft:stripped_dark_oak_log
setblock 48 184 323 minecraft:stripped_dark_oak_log
setblock 48 184 330 minecraft:stripped_dark_oak_log
setblock 48 184 337 minecraft:stripped_dark_oak_log
setblock 48 184 344 minecraft:stripped_dark_oak_log
setblock 48 184 351 minecraft:stripped_dark_oak_log
setblock 48 184 358 minecraft:stripped_dark_oak_log
setblock 50 184 363 minecraft:stripped_dark_oak_log
fill 52 184 322 53 219 322 minecraft:spruce_planks
setblock 54 184 322 minecraft:red_concrete
fill 55 184 322 55 219 322 minecraft:spruce_planks
setblock 55 184 323 minecraft:stripped_dark_oak_log
setblock 57 184 363 minecraft:stripped_dark_oak_log
fill 59 184 350 59 186 352 minecraft:cherry_leaves[persistent=true]
fill 60 184 350 61 186 350 minecraft:cherry_leaves[persistent=true]
fill 60 184 352 60 186 353 minecraft:cherry_leaves[persistent=true]
fill 61 184 351 61 186 352 minecraft:cherry_leaves[persistent=true]
setblock 62 184 323 minecraft:stripped_dark_oak_log
fill 62 184 351 62 186 351 minecraft:cherry_leaves[persistent=true]
setblock 64 184 363 minecraft:stripped_dark_oak_log
setblock 69 184 323 minecraft:stripped_dark_oak_log
setblock 71 184 363 minecraft:stripped_dark_oak_log
setblock 76 184 323 minecraft:stripped_dark_oak_log
setblock 78 184 363 minecraft:stripped_dark_oak_log
setblock 83 184 323 minecraft:stripped_dark_oak_log
setblock 85 184 363 minecraft:stripped_dark_oak_log
setblock 88 184 325 minecraft:stripped_dark_oak_log
setblock 88 184 332 minecraft:stripped_dark_oak_log
setblock 88 184 339 minecraft:stripped_dark_oak_log
setblock 88 184 346 minecraft:stripped_dark_oak_log
setblock 88 184 353 minecraft:stripped_dark_oak_log
setblock 88 184 360 minecraft:stripped_dark_oak_log
setblock 89 184 328 minecraft:red_concrete
fill 89 184 360 89 210 360 minecraft:spruce_planks
setblock 89 184 361 minecraft:red_concrete
fill 89 184 362 89 215 362 minecraft:spruce_planks
setblock 48 185 324 minecraft:stripped_dark_oak_log
setblock 48 185 331 minecraft:stripped_dark_oak_log
setblock 48 185 338 minecraft:stripped_dark_oak_log
setblock 48 185 345 minecraft:stripped_dark_oak_log
setblock 48 185 352 minecraft:stripped_dark_oak_log
setblock 48 185 359 minecraft:stripped_dark_oak_log
setblock 51 185 363 minecraft:stripped_dark_oak_log
fill 54 185 322 54 219 322 minecraft:spruce_planks
setblock 54 185 323 minecraft:stripped_dark_oak_log
fill 58 185 350 58 185 352 minecraft:cherry_leaves[persistent=true]
setblock 58 185 363 minecraft:stripped_dark_oak_log
setblock 59 185 353 minecraft:cherry_leaves[persistent=true]
setblock 60 185 349 minecraft:cherry_leaves[persistent=true]
fill 60 185 351 60 186 351 minecraft:cherry_leaves[persistent=true]
setblock 61 185 323 minecraft:stripped_dark_oak_log
setblock 61 185 353 minecraft:cherry_leaves[persistent=true]
setblock 62 185 350 minecraft:cherry_leaves[persistent=true]
setblock 62 185 352 minecraft:cherry_leaves[persistent=true]
setblock 65 185 363 minecraft:stripped_dark_oak_log
setblock 68 185 323 minecraft:stripped_dark_oak_log
setblock 72 185 363 minecraft:stripped_dark_oak_log
setblock 75 185 323 minecraft:stripped_dark_oak_log
setblock 79 185 363 minecraft:stripped_dark_oak_log
setblock 82 185 323 minecraft:stripped_dark_oak_log
setblock 86 185 363 minecraft:stripped_dark_oak_log
setblock 88 185 324 minecraft:stripped_dark_oak_log
setblock 88 185 331 minecraft:stripped_dark_oak_log
setblock 88 185 338 minecraft:stripped_dark_oak_log
setblock 88 185 345 minecraft:stripped_dark_oak_log
setblock 88 185 352 minecraft:stripped_dark_oak_log
setblock 88 185 359 minecraft:stripped_dark_oak_log
fill 89 185 328 89 209 328 minecraft:spruce_planks
fill 89 185 361 89 219 361 minecraft:spruce_planks
setblock 48 186 325 minecraft:stripped_dark_oak_log
setblock 48 186 332 minecraft:stripped_dark_oak_log
setblock 48 186 339 minecraft:stripped_dark_oak_log
setblock 48 186 346 minecraft:stripped_dark_oak_log
setblock 48 186 353 minecraft:stripped_dark_oak_log
setblock 48 186 360 minecraft:stripped_dark_oak_log
setblock 50 186 325 minecraft:light[level=15]
setblock 50 186 332 minecraft:light[level=12]
setblock 50 186 333 minecraft:light[level=15]
setblock 50 186 339 minecraft:light[level=12]
setblock 50 186 341 minecraft:light[level=15]
setblock 50 186 346 minecraft:light[level=12]
setblock 50 186 349 minecraft:light[level=15]
setblock 50 186 353 minecraft:light[level=12]
setblock 50 186 357 minecraft:light[level=15]
setblock 50 186 360 minecraft:light[level=12]
setblock 52 186 363 minecraft:stripped_dark_oak_log
setblock 53 186 323 minecraft:stripped_dark_oak_log
setblock 57 186 325 minecraft:light[level=12]
setblock 57 186 332 minecraft:light[level=12]
setblock 57 186 339 minecraft:light[level=12]
setblock 57 186 346 minecraft:light[level=12]
setblock 57 186 353 minecraft:light[level=12]
setblock 57 186 360 minecraft:light[level=12]
setblock 58 186 325 minecraft:light[level=15]
setblock 58 186 333 minecraft:light[level=15]
setblock 58 186 341 minecraft:light[level=15]
setblock 58 186 349 minecraft:light[level=15]
setblock 58 186 357 minecraft:light[level=15]
setblock 59 186 363 minecraft:stripped_dark_oak_log
setblock 60 186 323 minecraft:stripped_dark_oak_log
setblock 64 186 325 minecraft:light[level=12]
setblock 64 186 332 minecraft:light[level=12]
setblock 64 186 339 minecraft:light[level=12]
setblock 64 186 346 minecraft:light[level=12]
setblock 64 186 353 minecraft:light[level=12]
setblock 64 186 360 minecraft:light[level=12]
setblock 66 186 325 minecraft:light[level=15]
setblock 66 186 333 minecraft:light[level=15]
setblock 66 186 341 minecraft:light[level=15]
setblock 66 186 349 minecraft:light[level=15]
setblock 66 186 357 minecraft:light[level=15]
setblock 66 186 363 minecraft:stripped_dark_oak_log
setblock 67 186 323 minecraft:stripped_dark_oak_log
setblock 71 186 325 minecraft:light[level=12]
setblock 71 186 332 minecraft:light[level=12]
setblock 71 186 339 minecraft:light[level=12]
setblock 71 186 346 minecraft:light[level=12]
setblock 71 186 353 minecraft:light[level=12]
setblock 71 186 360 minecraft:light[level=12]
setblock 73 186 363 minecraft:stripped_dark_oak_log
setblock 74 186 323 minecraft:stripped_dark_oak_log
setblock 74 186 325 minecraft:light[level=15]
setblock 74 186 333 minecraft:light[level=15]
setblock 74 186 341 minecraft:light[level=15]
setblock 74 186 349 minecraft:light[level=15]
setblock 74 186 357 minecraft:light[level=15]
setblock 78 186 325 minecraft:light[level=12]
setblock 78 186 332 minecraft:light[level=12]
setblock 78 186 339 minecraft:light[level=12]
setblock 78 186 346 minecraft:light[level=12]
setblock 78 186 353 minecraft:light[level=12]
setblock 78 186 360 minecraft:light[level=12]
fill 79 186 364 79 217 364 minecraft:spruce_planks
setblock 80 186 363 minecraft:stripped_dark_oak_log
setblock 80 186 364 minecraft:red_concrete
setblock 81 186 323 minecraft:stripped_dark_oak_log
setblock 82 186 325 minecraft:light[level=15]
setblock 82 186 333 minecraft:light[level=15]
setblock 82 186 341 minecraft:light[level=15]
setblock 82 186 349 minecraft:light[level=15]
setblock 82 186 357 minecraft:light[level=15]
setblock 85 186 325 minecraft:light[level=12]
setblock 85 186 332 minecraft:light[level=12]
setblock 85 186 339 minecraft:light[level=12]
setblock 85 186 346 minecraft:light[level=12]
setblock 85 186 353 minecraft:light[level=12]
setblock 85 186 360 minecraft:light[level=12]
setblock 87 186 363 minecraft:stripped_dark_oak_log
setblock 88 186 323 minecraft:stripped_dark_oak_log
setblock 88 186 330 minecraft:stripped_dark_oak_log
setblock 88 186 337 minecraft:stripped_dark_oak_log
setblock 88 186 344 minecraft:stripped_dark_oak_log
setblock 88 186 351 minecraft:stripped_dark_oak_log
setblock 88 186 358 minecraft:stripped_dark_oak_log
setblock 47 187 358 minecraft:red_concrete
fill 47 187 359 47 202 360 minecraft:spruce_planks
setblock 48 187 326 minecraft:stripped_dark_oak_log
setblock 48 187 333 minecraft:stripped_dark_oak_log
setblock 48 187 340 minecraft:stripped_dark_oak_log
setblock 48 187 347 minecraft:stripped_dark_oak_log
setblock 48 187 354 minecraft:stripped_dark_oak_log
setblock 48 187 361 minecraft:stripped_dark_oak_log
setblock 52 187 323 minecraft:stripped_dark_oak_log
setblock 53 187 363 minecraft:stripped_dark_oak_log
setblock 59 187 323 minecraft:stripped_dark_oak_log
setblock 60 187 363 minecraft:stripped_dark_oak_log
setblock 66 187 323 minecraft:stripped_dark_oak_log
setblock 67 187 363 minecraft:stripped_dark_oak_log
setblock 73 187 323 minecraft:stripped_dark_oak_log
setblock 74 187 363 minecraft:stripped_dark_oak_log
setblock 80 187 323 minecraft:stripped_dark_oak_log
fill 80 187 364 80 220 364 minecraft:spruce_planks
setblock 81 187 363 minecraft:stripped_dark_oak_log
setblock 87 187 323 minecraft:stripped_dark_oak_log
setblock 88 187 329 minecraft:stripped_dark_oak_log
setblock 88 187 336 minecraft:stripped_dark_oak_log
setblock 88 187 343 minecraft:stripped_dark_oak_log
setblock 88 187 350 minecraft:stripped_dark_oak_log
setblock 88 187 357 minecraft:stripped_dark_oak_log
setblock 88 187 363 minecraft:stripped_dark_oak_log
fill 47 188 358 47 219 358 minecraft:spruce_planks
setblock 48 188 327 minecraft:stripped_dark_oak_log
setblock 48 188 334 minecraft:stripped_dark_oak_log
setblock 48 188 341 minecraft:stripped_dark_oak_log
setblock 48 188 348 minecraft:stripped_dark_oak_log
setblock 48 188 355 minecraft:stripped_dark_oak_log
setblock 48 188 362 minecraft:stripped_dark_oak_log
setblock 51 188 323 minecraft:stripped_dark_oak_log
setblock 54 188 363 minecraft:stripped_dark_oak_log
setblock 58 188 323 minecraft:stripped_dark_oak_log
setblock 61 188 363 minecraft:stripped_dark_oak_log
setblock 65 188 323 minecraft:stripped_dark_oak_log
setblock 66 188 322 minecraft:red_concrete
setblock 68 188 363 minecraft:stripped_dark_oak_log
setblock 72 188 323 minecraft:stripped_dark_oak_log
setblock 75 188 363 minecraft:stripped_dark_oak_log
setblock 79 188 323 minecraft:stripped_dark_oak_log
setblock 82 188 363 minecraft:stripped_dark_oak_log
setblock 86 188 323 minecraft:stripped_dark_oak_log
setblock 88 188 328 minecraft:stripped_dark_oak_log
setblock 88 188 335 minecraft:stripped_dark_oak_log
setblock 88 188 342 minecraft:stripped_dark_oak_log
setblock 88 188 349 minecraft:stripped_dark_oak_log
setblock 88 188 356 minecraft:stripped_dark_oak_log
setblock 89 188 353 minecraft:red_concrete
fill 89 188 354 89 217 354 minecraft:spruce_planks
fill 57 189 360 57 190 362 minecraft:iron_bars
fill 66 189 322 66 219 322 minecraft:spruce_planks
fill 83 189 326 83 194 326 minecraft:red_concrete
fill 89 189 353 89 219 353 minecraft:spruce_planks
fill 48 190 323 48 190 327 minecraft:stripped_dark_oak_log
fill 48 190 329 48 190 334 minecraft:stripped_dark_oak_log
fill 48 190 336 48 190 341 minecraft:stripped_dark_oak_log
fill 48 190 343 48 190 348 minecraft:stripped_dark_oak_log
fill 48 190 350 48 190 355 minecraft:stripped_dark_oak_log
fill 48 190 357 48 190 362 minecraft:stripped_dark_oak_log
setblock 49 190 323 minecraft:stripped_dark_oak_log
fill 49 190 363 54 190 363 minecraft:stripped_dark_oak_log
fill 51 190 323 56 190 323 minecraft:stripped_dark_oak_log
fill 56 190 363 61 190 363 minecraft:stripped_dark_oak_log
fill 58 190 323 63 190 323 minecraft:stripped_dark_oak_log
fill 63 190 363 68 190 363 minecraft:stripped_dark_oak_log
fill 65 190 323 70 190 323 minecraft:stripped_dark_oak_log
fill 70 190 363 75 190 363 minecraft:stripped_dark_oak_log
fill 72 190 323 77 190 323 minecraft:stripped_dark_oak_log
fill 77 190 363 82 190 363 minecraft:stripped_dark_oak_log
fill 79 190 323 84 190 323 minecraft:stripped_dark_oak_log
fill 84 190 363 88 190 363 minecraft:stripped_dark_oak_log
fill 86 190 323 88 190 323 minecraft:stripped_dark_oak_log
fill 88 190 324 88 190 326 minecraft:stripped_dark_oak_log
fill 88 190 328 88 190 333 minecraft:stripped_dark_oak_log
fill 88 190 335 88 190 340 minecraft:stripped_dark_oak_log
fill 88 190 342 88 190 347 minecraft:stripped_dark_oak_log
fill 88 190 349 88 190 354 minecraft:stripped_dark_oak_log
fill 88 190 356 88 190 361 minecraft:stripped_dark_oak_log
setblock 89 190 329 minecraft:red_concrete
setblock 48 191 323 minecraft:stripped_dark_oak_log
setblock 48 191 330 minecraft:stripped_dark_oak_log
setblock 48 191 337 minecraft:stripped_dark_oak_log
setblock 48 191 344 minecraft:stripped_dark_oak_log
setblock 48 191 351 minecraft:stripped_dark_oak_log
setblock 48 191 358 minecraft:stripped_dark_oak_log
setblock 50 191 363 minecraft:stripped_dark_oak_log
setblock 55 191 323 minecraft:stripped_dark_oak_log
setblock 57 191 363 minecraft:stripped_dark_oak_log
setblock 62 191 323 minecraft:stripped_dark_oak_log
setblock 64 191 363 minecraft:stripped_dark_oak_log
setblock 69 191 323 minecraft:stripped_dark_oak_log
setblock 71 191 363 minecraft:stripped_dark_oak_log
setblock 74 191 322 minecraft:red_concrete
setblock 76 191 323 minecraft:stripped_dark_oak_log
fill 76 191 364 76 219 364 minecraft:spruce_planks
setblock 77 191 364 minecraft:red_concrete
setblock 78 191 363 minecraft:stripped_dark_oak_log
setblock 81 191 322 minecraft:red_concrete
fill 82 191 322 84 216 322 minecraft:spruce_planks
fill 82 191 326 82 194 326 minecraft:red_concrete
setblock 83 191 323 minecraft:stripped_dark_oak_log
fill 83 191 325 83 194 325 minecraft:red_concrete
fill 84 191 326 84 194 326 minecraft:red_concrete
setblock 85 191 363 minecraft:stripped_dark_oak_log
setblock 88 191 325 minecraft:stripped_dark_oak_log
setblock 88 191 332 minecraft:stripped_dark_oak_log
setblock 88 191 339 minecraft:stripped_dark_oak_log
setblock 88 191 346 minecraft:stripped_dark_oak_log
setblock 88 191 353 minecraft:stripped_dark_oak_log
setblock 88 191 360 minecraft:stripped_dark_oak_log
fill 89 191 329 89 219 329 minecraft:spruce_planks
setblock 48 192 324 minecraft:stripped_dark_oak_log
setblock 48 192 331 minecraft:stripped_dark_oak_log
setblock 48 192 338 minecraft:stripped_dark_oak_log
setblock 48 192 345 minecraft:stripped_dark_oak_log
setblock 48 192 352 minecraft:stripped_dark_oak_log
setblock 48 192 359 minecraft:stripped_dark_oak_log
setblock 50 192 325 minecraft:light[level=12]
setblock 50 192 332 minecraft:light[level=12]
setblock 50 192 339 minecraft:light[level=12]
setblock 50 192 346 minecraft:light[level=12]
setblock 50 192 353 minecraft:light[level=12]
setblock 50 192 360 minecraft:light[level=12]
setblock 51 192 363 minecraft:stripped_dark_oak_log
setblock 54 192 323 minecraft:stripped_dark_oak_log
setblock 57 192 325 minecraft:light[level=12]
setblock 57 192 332 minecraft:light[level=12]
setblock 57 192 339 minecraft:light[level=12]
setblock 57 192 346 minecraft:light[level=12]
setblock 57 192 353 minecraft:light[level=12]
setblock 57 192 360 minecraft:light[level=12]
setblock 58 192 363 minecraft:stripped_dark_oak_log
setblock 61 192 323 minecraft:stripped_dark_oak_log
setblock 64 192 325 minecraft:light[level=12]
setblock 64 192 332 minecraft:light[level=12]
setblock 64 192 339 minecraft:light[level=12]
setblock 64 192 346 minecraft:light[level=12]
setblock 64 192 353 minecraft:light[level=12]
setblock 64 192 360 minecraft:light[level=12]
setblock 65 192 363 minecraft:stripped_dark_oak_log
setblock 68 192 323 minecraft:stripped_dark_oak_log
setblock 71 192 325 minecraft:light[level=12]
setblock 71 192 332 minecraft:light[level=12]
setblock 71 192 339 minecraft:light[level=12]
setblock 71 192 346 minecraft:light[level=12]
setblock 71 192 353 minecraft:light[level=12]
setblock 71 192 360 minecraft:light[level=12]
setblock 72 192 363 minecraft:stripped_dark_oak_log
fill 74 192 322 74 219 322 minecraft:spruce_planks
setblock 75 192 323 minecraft:stripped_dark_oak_log
fill 77 192 364 77 219 364 minecraft:spruce_planks
setblock 78 192 325 minecraft:light[level=12]
setblock 78 192 332 minecraft:light[level=12]
setblock 78 192 339 minecraft:light[level=12]
setblock 78 192 346 minecraft:light[level=12]
setblock 78 192 353 minecraft:light[level=12]
setblock 78 192 360 minecraft:light[level=12]
setblock 79 192 363 minecraft:stripped_dark_oak_log
fill 81 192 322 81 219 322 minecraft:spruce_planks
setblock 82 192 323 minecraft:stripped_dark_oak_log
fill 82 192 325 82 194 325 minecraft:red_concrete
fill 82 192 327 84 194 327 minecraft:red_concrete
fill 84 192 325 84 194 325 minecraft:red_concrete
setblock 85 192 325 minecraft:light[level=12]
setblock 85 192 332 minecraft:light[level=12]
setblock 85 192 339 minecraft:light[level=12]
setblock 85 192 346 minecraft:light[level=12]
setblock 85 192 353 minecraft:light[level=12]
setblock 85 192 360 minecraft:light[level=12]
setblock 86 192 363 minecraft:stripped_dark_oak_log
setblock 88 192 324 minecraft:stripped_dark_oak_log
setblock 88 192 331 minecraft:stripped_dark_oak_log
setblock 88 192 338 minecraft:stripped_dark_oak_log
setblock 88 192 345 minecraft:stripped_dark_oak_log
setblock 88 192 352 minecraft:stripped_dark_oak_log
setblock 88 192 359 minecraft:stripped_dark_oak_log
fill 47 193 361 47 216 362 minecraft:spruce_planks
setblock 47 193 363 minecraft:red_concrete
setblock 48 193 325 minecraft:stripped_dark_oak_log
setblock 48 193 332 minecraft:stripped_dark_oak_log
setblock 48 193 339 minecraft:stripped_dark_oak_log
setblock 48 193 346 minecraft:stripped_dark_oak_log
setblock 48 193 353 minecraft:stripped_dark_oak_log
setblock 48 193 360 minecraft:stripped_dark_oak_log
setblock 52 193 363 minecraft:stripped_dark_oak_log
setblock 53 193 323 minecraft:stripped_dark_oak_log
setblock 59 193 363 minecraft:stripped_dark_oak_log
setblock 60 193 323 minecraft:stripped_dark_oak_log
setblock 66 193 363 minecraft:stripped_dark_oak_log
setblock 67 193 323 minecraft:stripped_dark_oak_log
setblock 73 193 363 minecraft:stripped_dark_oak_log
setblock 74 193 323 minecraft:stripped_dark_oak_log
setblock 77 193 322 minecraft:red_concrete
fill 78 193 322 79 194 322 minecraft:spruce_planks
setblock 80 193 363 minecraft:stripped_dark_oak_log
setblock 81 193 323 minecraft:stripped_dark_oak_log
fill 81 193 326 81 194 326 minecraft:red_concrete
fill 82 193 324 84 194 324 minecraft:red_concrete
fill 85 193 326 85 194 326 minecraft:red_concrete
setblock 87 193 363 minecraft:stripped_dark_oak_log
setblock 88 193 323 minecraft:stripped_dark_oak_log
setblock 88 193 330 minecraft:stripped_dark_oak_log
setblock 88 193 337 minecraft:stripped_dark_oak_log
setblock 88 193 344 minecraft:stripped_dark_oak_log
setblock 88 193 351 minecraft:stripped_dark_oak_log
setblock 88 193 358 minecraft:stripped_dark_oak_log
fill 47 194 363 47 202 363 minecraft:spruce_planks
setblock 48 194 326 minecraft:stripped_dark_oak_log
setblock 48 194 333 minecraft:stripped_dark_oak_log
setblock 48 194 340 minecraft:stripped_dark_oak_log
setblock 48 194 347 minecraft:stripped_dark_oak_log
setblock 48 194 354 minecraft:stripped_dark_oak_log
setblock 48 194 361 minecraft:stripped_dark_oak_log
setblock 50 194 325 minecraft:light[level=15]
setblock 50 194 333 minecraft:light[level=15]
setblock 50 194 341 minecraft:light[level=15]
setblock 50 194 349 minecraft:light[level=15]
setblock 50 194 357 minecraft:light[level=15]
setblock 52 194 323 minecraft:stripped_dark_oak_log
setblock 53 194 363 minecraft:stripped_dark_oak_log
setblock 58 194 325 minecraft:light[level=15]
setblock 58 194 333 minecraft:light[level=15]
setblock 58 194 341 minecraft:light[level=15]
setblock 58 194 349 minecraft:light[level=15]
setblock 58 194 357 minecraft:light[level=15]
setblock 59 194 323 minecraft:stripped_dark_oak_log
setblock 60 194 363 minecraft:stripped_dark_oak_log
setblock 66 194 323 minecraft:stripped_dark_oak_log
setblock 66 194 325 minecraft:light[level=15]
setblock 66 194 333 minecraft:light[level=15]
setblock 66 194 341 minecraft:light[level=15]
setblock 66 194 349 minecraft:light[level=15]
setblock 66 194 357 minecraft:light[level=15]
setblock 67 194 363 minecraft:stripped_dark_oak_log
setblock 73 194 323 minecraft:stripped_dark_oak_log
setblock 74 194 325 minecraft:light[level=15]
setblock 74 194 333 minecraft:light[level=15]
setblock 74 194 341 minecraft:light[level=15]
setblock 74 194 349 minecraft:light[level=15]
setblock 74 194 357 minecraft:light[level=15]
setblock 74 194 363 minecraft:stripped_dark_oak_log
fill 77 194 322 77 219 322 minecraft:spruce_planks
fill 80 194 323 80 195 323 minecraft:stripped_dark_oak_log
setblock 81 194 325 minecraft:red_concrete
setblock 81 194 327 minecraft:red_concrete
setblock 81 194 363 minecraft:stripped_dark_oak_log
fill 82 194 328 84 194 328 minecraft:red_concrete
setblock 82 194 333 minecraft:light[level=15]
setblock 82 194 341 minecraft:light[level=15]
setblock 82 194 349 minecraft:light[level=15]
setblock 82 194 357 minecraft:light[level=15]
setblock 85 194 325 minecraft:red_concrete
setblock 85 194 327 minecraft:red_concrete
setblock 87 194 323 minecraft:stripped_dark_oak_log
setblock 88 194 329 minecraft:stripped_dark_oak_log
setblock 88 194 336 minecraft:stripped_dark_oak_log
setblock 88 194 343 minecraft:stripped_dark_oak_log
setblock 88 194 350 minecraft:stripped_dark_oak_log
setblock 88 194 357 minecraft:stripped_dark_oak_log
setblock 88 194 363 minecraft:stripped_dark_oak_log
setblock 48 195 327 minecraft:stripped_dark_oak_log
setblock 48 195 334 minecraft:stripped_dark_oak_log
setblock 48 195 341 minecraft:stripped_dark_oak_log
setblock 48 195 348 minecraft:stripped_dark_oak_log
setblock 48 195 355 minecraft:stripped_dark_oak_log
setblock 48 195 362 minecraft:stripped_dark_oak_log
setblock 51 195 323 minecraft:stripped_dark_oak_log
setblock 54 195 363 minecraft:stripped_dark_oak_log
setblock 58 195 323 minecraft:stripped_dark_oak_log
setblock 61 195 363 minecraft:stripped_dark_oak_log
setblock 65 195 323 minecraft:stripped_dark_oak_log
setblock 68 195 363 minecraft:stripped_dark_oak_log
setblock 72 195 323 minecraft:stripped_dark_oak_log
setblock 75 195 363 minecraft:stripped_dark_oak_log
fill 78 195 322 78 220 322 minecraft:spruce_planks
setblock 79 195 322 minecraft:red_concrete
setblock 79 195 323 minecraft:stripped_dark_oak_log
fill 80 195 324 86 195 329 minecraft:stripped_dark_oak_log
fill 81 195 323 84 195 323 minecraft:stripped_dark_oak_log
setblock 82 195 363 minecraft:stripped_dark_oak_log
setblock 86 195 323 minecraft:stripped_dark_oak_log
setblock 88 195 328 minecraft:stripped_dark_oak_log
setblock 88 195 335 minecraft:stripped_dark_oak_log
setblock 88 195 342 minecraft:stripped_dark_oak_log
setblock 88 195 349 minecraft:stripped_dark_oak_log
setblock 88 195 356 minecraft:stripped_dark_oak_log
fill 79 196 322 79 219 322 minecraft:spruce_planks
setblock 80 196 323 minecraft:shroomlight
fill 80 196 324 80 205 324 minecraft:stripped_dark_oak_log
setblock 80 196 325 minecraft:shroomlight
fill 80 196 326 80 205 326 minecraft:stripped_dark_oak_log
setblock 80 196 327 minecraft:shroomlight
fill 80 196 328 80 205 328 minecraft:stripped_dark_oak_log
setblock 80 196 329 minecraft:shroomlight
fill 81 196 323 81 205 323 minecraft:stripped_dark_oak_log
setblock 81 196 324 minecraft:shroomlight
fill 81 196 325 81 205 325 minecraft:stripped_dark_oak_log
setblock 81 196 326 minecraft:shroomlight
fill 81 196 327 81 205 327 minecraft:stripped_dark_oak_log
setblock 81 196 328 minecraft:shroomlight
fill 81 196 329 81 205 329 minecraft:stripped_dark_oak_log
setblock 82 196 323 minecraft:shroomlight
fill 82 196 324 82 205 324 minecraft:stripped_dark_oak_log
setblock 82 196 325 minecraft:shroomlight
fill 82 196 326 82 205 326 minecraft:stripped_dark_oak_log
setblock 82 196 327 minecraft:shroomlight
fill 82 196 328 82 205 328 minecraft:stripped_dark_oak_log
setblock 82 196 329 minecraft:shroomlight
fill 83 196 323 83 205 323 minecraft:stripped_dark_oak_log
setblock 83 196 324 minecraft:shroomlight
fill 83 196 325 83 205 325 minecraft:stripped_dark_oak_log
setblock 83 196 326 minecraft:shroomlight
fill 83 196 327 83 205 327 minecraft:stripped_dark_oak_log
setblock 83 196 328 minecraft:shroomlight
fill 83 196 329 83 205 329 minecraft:stripped_dark_oak_log
setblock 84 196 323 minecraft:shroomlight
fill 84 196 324 84 205 324 minecraft:stripped_dark_oak_log
setblock 84 196 325 minecraft:shroomlight
fill 84 196 326 84 205 326 minecraft:stripped_dark_oak_log
setblock 84 196 327 minecraft:shroomlight
fill 84 196 328 84 205 328 minecraft:stripped_dark_oak_log
setblock 84 196 329 minecraft:shroomlight
setblock 85 196 324 minecraft:shroomlight
fill 85 196 325 85 205 325 minecraft:stripped_dark_oak_log
setblock 85 196 326 minecraft:shroomlight
fill 85 196 327 85 205 327 minecraft:stripped_dark_oak_log
setblock 85 196 328 minecraft:shroomlight
fill 85 196 329 85 205 329 minecraft:stripped_dark_oak_log
setblock 86 196 323 minecraft:shroomlight
fill 86 196 324 86 205 324 minecraft:stripped_dark_oak_log
setblock 86 196 325 minecraft:shroomlight
fill 86 196 326 86 205 326 minecraft:stripped_dark_oak_log
setblock 86 196 327 minecraft:shroomlight
fill 86 196 328 86 205 328 minecraft:stripped_dark_oak_log
setblock 86 196 329 minecraft:shroomlight
setblock 48 197 329 minecraft:stripped_dark_oak_log
setblock 48 197 336 minecraft:stripped_dark_oak_log
setblock 48 197 343 minecraft:stripped_dark_oak_log
setblock 48 197 350 minecraft:stripped_dark_oak_log
setblock 48 197 357 minecraft:stripped_dark_oak_log
setblock 49 197 323 minecraft:stripped_dark_oak_log
setblock 49 197 363 minecraft:stripped_dark_oak_log
setblock 56 197 323 minecraft:stripped_dark_oak_log
setblock 56 197 363 minecraft:stripped_dark_oak_log
setblock 63 197 323 minecraft:stripped_dark_oak_log
fill 63 197 357 64 200 359 minecraft:cherry_leaves[persistent=true]
setblock 63 197 363 minecraft:stripped_dark_oak_log
fill 64 197 356 64 199 356 minecraft:cherry_leaves[persistent=true]
fill 65 197 357 65 199 358 minecraft:cherry_leaves[persistent=true]
setblock 70 197 323 minecraft:stripped_dark_oak_log
setblock 70 197 363 minecraft:stripped_dark_oak_log
fill 71 197 364 73 218 364 minecraft:spruce_planks
setblock 74 197 364 minecraft:red_concrete
setblock 77 197 323 minecraft:stripped_dark_oak_log
setblock 77 197 363 minecraft:stripped_dark_oak_log
setblock 78 197 364 minecraft:red_concrete
fill 80 197 323 80 198 323 minecraft:stripped_dark_oak_log
fill 80 197 325 80 198 325 minecraft:stripped_dark_oak_log
fill 80 197 327 80 198 327 minecraft:stripped_dark_oak_log
fill 80 197 329 80 198 329 minecraft:stripped_dark_oak_log
fill 81 197 324 81 198 324 minecraft:stripped_dark_oak_log
fill 81 197 326 81 198 326 minecraft:stripped_dark_oak_log
fill 81 197 328 81 198 328 minecraft:stripped_dark_oak_log
fill 82 197 323 82 198 323 minecraft:stripped_dark_oak_log
fill 82 197 325 82 198 325 minecraft:stripped_dark_oak_log
fill 82 197 327 82 198 327 minecraft:stripped_dark_oak_log
fill 82 197 329 82 198 329 minecraft:stripped_dark_oak_log
fill 83 197 324 83 198 324 minecraft:stripped_dark_oak_log
fill 83 197 326 83 198 326 minecraft:stripped_dark_oak_log
fill 83 197 328 83 198 328 minecraft:stripped_dark_oak_log
fill 84 197 323 84 198 323 minecraft:stripped_dark_oak_log
fill 84 197 325 84 198 325 minecraft:stripped_dark_oak_log
fill 84 197 327 84 198 327 minecraft:stripped_dark_oak_log
fill 84 197 329 84 198 329 minecraft:stripped_dark_oak_log
setblock 84 197 363 minecraft:stripped_dark_oak_log
fill 85 197 324 85 198 324 minecraft:stripped_dark_oak_log
fill 85 197 326 85 198 326 minecraft:stripped_dark_oak_log
fill 85 197 328 85 198 328 minecraft:stripped_dark_oak_log
fill 86 197 323 86 198 323 minecraft:stripped_dark_oak_log
fill 86 197 325 86 198 325 minecraft:stripped_dark_oak_log
fill 86 197 327 86 198 327 minecraft:stripped_dark_oak_log
fill 86 197 329 86 198 329 minecraft:stripped_dark_oak_log
setblock 88 197 326 minecraft:stripped_dark_oak_log
setblock 88 197 333 minecraft:stripped_dark_oak_log
setblock 88 197 340 minecraft:stripped_dark_oak_log
setblock 88 197 347 minecraft:stripped_dark_oak_log
setblock 88 197 354 minecraft:stripped_dark_oak_log
setblock 88 197 361 minecraft:stripped_dark_oak_log
setblock 48 198 323 minecraft:stripped_dark_oak_log
setblock 48 198 330 minecraft:stripped_dark_oak_log
setblock 48 198 337 minecraft:stripped_dark_oak_log
setblock 48 198 344 minecraft:stripped_dark_oak_log
setblock 48 198 351 minecraft:stripped_dark_oak_log
setblock 48 198 358 minecraft:stripped_dark_oak_log
setblock 50 198 325 minecraft:light[level=12]
setblock 50 198 332 minecraft:light[level=12]
setblock 50 198 339 minecraft:light[level=12]
setblock 50 198 346 minecraft:light[level=12]
setblock 50 198 353 minecraft:light[level=12]
setblock 50 198 360 minecraft:light[level=12]
setblock 50 198 363 minecraft:stripped_dark_oak_log
setblock 55 198 323 minecraft:stripped_dark_oak_log
setblock 57 198 325 minecraft:light[level=12]
setblock 57 198 332 minecraft:light[level=12]
setblock 57 198 339 minecraft:light[level=12]
setblock 57 198 346 minecraft:light[level=12]
setblock 57 198 353 minecraft:light[level=12]
setblock 57 198 360 minecraft:light[level=12]
setblock 57 198 363 minecraft:stripped_dark_oak_log
setblock 62 198 323 minecraft:stripped_dark_oak_log
fill 62 198 357 62 199 358 minecraft:cherry_leaves[persistent=true]
fill 63 198 356 63 199 356 minecraft:cherry_leaves[persistent=true]
setblock 64 198 325 minecraft:light[level=12]
setblock 64 198 332 minecraft:light[level=12]
setblock 64 198 339 minecraft:light[level=12]
setblock 64 198 346 minecraft:light[level=12]
setblock 64 198 353 minecraft:light[level=12]
fill 64 198 360 64 199 360 minecraft:cherry_leaves[persistent=true]
setblock 64 198 363 minecraft:stripped_dark_oak_log
setblock 65 198 356 minecraft:cherry_leaves[persistent=true]
fill 65 198 359 65 200 359 minecraft:cherry_leaves[persistent=true]
setblock 69 198 323 minecraft:stripped_dark_oak_log
setblock 71 198 325 minecraft:light[level=12]
setblock 71 198 332 minecraft:light[level=12]
setblock 71 198 339 minecraft:light[level=12]
setblock 71 198 346 minecraft:light[level=12]
setblock 71 198 353 minecraft:light[level=12]
setblock 71 198 360 minecraft:light[level=12]
setblock 71 198 363 minecraft:stripped_dark_oak_log
fill 74 198 364 74 220 364 minecraft:spruce_planks
setblock 76 198 323 minecraft:stripped_dark_oak_log
setblock 78 198 325 minecraft:light[level=12]
setblock 78 198 332 minecraft:light[level=12]
setblock 78 198 339 minecraft:light[level=12]
setblock 78 198 346 minecraft:light[level=12]
setblock 78 198 353 minecraft:light[level=12]
setblock 78 198 360 minecraft:light[level=12]
setblock 78 198 363 minecraft:stripped_dark_oak_log
fill 78 198 364 78 219 364 minecraft:spruce_planks
setblock 85 198 332 minecraft:light[level=12]
setblock 85 198 339 minecraft:light[level=12]
setblock 85 198 346 minecraft:light[level=12]
setblock 85 198 353 minecraft:light[level=12]
setblock 85 198 360 minecraft:light[level=12]
setblock 85 198 363 minecraft:stripped_dark_oak_log
setblock 88 198 325 minecraft:stripped_dark_oak_log
setblock 88 198 332 minecraft:stripped_dark_oak_log
setblock 88 198 339 minecraft:stripped_dark_oak_log
setblock 88 198 346 minecraft:stripped_dark_oak_log
setblock 88 198 353 minecraft:stripped_dark_oak_log
setblock 88 198 360 minecraft:stripped_dark_oak_log
fill 48 199 324 48 200 324 minecraft:stripped_dark_oak_log
fill 48 199 331 48 200 331 minecraft:stripped_dark_oak_log
fill 48 199 338 48 200 338 minecraft:stripped_dark_oak_log
fill 48 199 345 48 200 345 minecraft:stripped_dark_oak_log
fill 48 199 352 48 200 352 minecraft:stripped_dark_oak_log
fill 48 199 359 48 200 359 minecraft:stripped_dark_oak_log
fill 51 199 363 51 200 363 minecraft:stripped_dark_oak_log
fill 54 199 323 54 200 323 minecraft:stripped_dark_oak_log
fill 58 199 363 58 200 363 minecraft:stripped_dark_oak_log
fill 61 199 323 61 200 323 minecraft:stripped_dark_oak_log
setblock 62 199 359 minecraft:cherry_leaves[persistent=true]
fill 65 199 363 65 200 363 minecraft:stripped_dark_oak_log
fill 68 199 323 68 200 323 minecraft:stripped_dark_oak_log
fill 72 199 363 72 200 363 minecraft:stripped_dark_oak_log
fill 75 199 323 75 200 323 minecraft:stripped_dark_oak_log
fill 79 199 363 79 200 363 minecraft:stripped_dark_oak_log
setblock 80 199 323 minecraft:shroomlight
setblock 80 199 325 minecraft:shroomlight
setblock 80 199 327 minecraft:shroomlight
setblock 80 199 329 minecraft:shroomlight
setblock 81 199 324 minecraft:shroomlight
setblock 81 199 326 minecraft:shroomlight
setblock 81 199 328 minecraft:shroomlight
setblock 82 199 323 minecraft:shroomlight
setblock 82 199 325 minecraft:shroomlight
setblock 82 199 327 minecraft:shroomlight
setblock 82 199 329 minecraft:shroomlight
setblock 83 199 324 minecraft:shroomlight
setblock 83 199 326 minecraft:shroomlight
setblock 83 199 328 minecraft:shroomlight
setblock 84 199 323 minecraft:shroomlight
setblock 84 199 325 minecraft:shroomlight
setblock 84 199 327 minecraft:shroomlight
setblock 84 199 329 minecraft:shroomlight
setblock 85 199 324 minecraft:shroomlight
setblock 85 199 326 minecraft:shroomlight
setblock 85 199 328 minecraft:shroomlight
setblock 86 199 323 minecraft:shroomlight
setblock 86 199 325 minecraft:shroomlight
setblock 86 199 327 minecraft:shroomlight
setblock 86 199 329 minecraft:shroomlight
fill 86 199 363 86 200 363 minecraft:stripped_dark_oak_log
fill 88 199 324 88 200 324 minecraft:stripped_dark_oak_log
fill 88 199 331 88 200 331 minecraft:stripped_dark_oak_log
fill 88 199 338 88 200 338 minecraft:stripped_dark_oak_log
fill 88 199 345 88 200 345 minecraft:stripped_dark_oak_log
fill 88 199 352 88 200 352 minecraft:stripped_dark_oak_log
fill 88 199 359 88 200 359 minecraft:stripped_dark_oak_log
setblock 89 199 359 minecraft:red_concrete
fill 48 200 323 49 200 323 minecraft:stripped_dark_oak_log
fill 48 200 325 48 200 327 minecraft:stripped_dark_oak_log
fill 48 200 329 48 200 330 minecraft:stripped_dark_oak_log
fill 48 200 332 48 200 334 minecraft:stripped_dark_oak_log
fill 48 200 336 48 200 337 minecraft:stripped_dark_oak_log
fill 48 200 339 48 200 341 minecraft:stripped_dark_oak_log
fill 48 200 343 48 200 344 minecraft:stripped_dark_oak_log
fill 48 200 346 48 200 348 minecraft:stripped_dark_oak_log
fill 48 200 350 48 200 351 minecraft:stripped_dark_oak_log
fill 48 200 353 48 200 355 minecraft:stripped_dark_oak_log
fill 48 200 357 48 200 358 minecraft:stripped_dark_oak_log
fill 48 200 360 48 200 362 minecraft:stripped_dark_oak_log
fill 49 200 363 50 200 363 minecraft:stripped_dark_oak_log
fill 51 200 323 53 200 323 minecraft:stripped_dark_oak_log
fill 52 200 363 54 200 363 minecraft:stripped_dark_oak_log
fill 55 200 323 56 200 323 minecraft:stripped_dark_oak_log
fill 56 200 363 57 200 363 minecraft:stripped_dark_oak_log
fill 58 200 323 60 200 323 minecraft:stripped_dark_oak_log
fill 59 200 363 61 200 363 minecraft:stripped_dark_oak_log
fill 62 200 323 63 200 323 minecraft:stripped_dark_oak_log
setblock 62 200 357 minecraft:cherry_leaves[persistent=true]
fill 63 200 363 64 200 363 minecraft:stripped_dark_oak_log
fill 65 200 323 67 200 323 minecraft:stripped_dark_oak_log
setblock 65 200 358 minecraft:cherry_leaves[persistent=true]
fill 66 200 363 68 200 363 minecraft:stripped_dark_oak_log
fill 69 200 323 70 200 323 minecraft:stripped_dark_oak_log
fill 70 200 363 71 200 363 minecraft:stripped_dark_oak_log
fill 72 200 323 74 200 323 minecraft:stripped_dark_oak_log
fill 73 200 363 75 200 363 minecraft:stripped_dark_oak_log
fill 76 200 323 77 200 323 minecraft:stripped_dark_oak_log
fill 77 200 363 78 200 363 minecraft:stripped_dark_oak_log
fill 79 200 323 80 200 323 minecraft:stripped_dark_oak_log
fill 80 200 325 80 201 325 minecraft:stripped_dark_oak_log
fill 80 200 327 80 201 327 minecraft:stripped_dark_oak_log
fill 80 200 329 80 201 329 minecraft:stripped_dark_oak_log
fill 80 200 363 82 200 363 minecraft:stripped_dark_oak_log
fill 81 200 324 81 201 324 minecraft:stripped_dark_oak_log
fill 81 200 326 81 201 326 minecraft:stripped_dark_oak_log
fill 81 200 328 81 201 328 minecraft:stripped_dark_oak_log
fill 82 200 323 82 201 323 minecraft:stripped_dark_oak_log
fill 82 200 325 82 201 325 minecraft:stripped_dark_oak_log
fill 82 200 327 82 201 327 minecraft:stripped_dark_oak_log
fill 82 200 329 82 201 329 minecraft:stripped_dark_oak_log
fill 83 200 324 83 201 324 minecraft:stripped_dark_oak_log
fill 83 200 326 83 201 326 minecraft:stripped_dark_oak_log
fill 83 200 328 83 201 328 minecraft:stripped_dark_oak_log
fill 84 200 323 84 201 323 minecraft:stripped_dark_oak_log
fill 84 200 325 84 201 325 minecraft:stripped_dark_oak_log
fill 84 200 327 84 201 327 minecraft:stripped_dark_oak_log
fill 84 200 329 84 201 329 minecraft:stripped_dark_oak_log
fill 84 200 363 85 200 363 minecraft:stripped_dark_oak_log
fill 85 200 324 85 201 324 minecraft:stripped_dark_oak_log
fill 85 200 326 85 201 326 minecraft:stripped_dark_oak_log
fill 85 200 328 85 201 328 minecraft:stripped_dark_oak_log
fill 86 200 323 88 200 323 minecraft:stripped_dark_oak_log
fill 86 200 325 86 201 325 minecraft:stripped_dark_oak_log
fill 86 200 327 86 201 327 minecraft:stripped_dark_oak_log
fill 86 200 329 86 201 329 minecraft:stripped_dark_oak_log
fill 87 200 363 88 200 363 minecraft:stripped_dark_oak_log
fill 88 200 325 88 200 326 minecraft:stripped_dark_oak_log
fill 88 200 328 88 200 330 minecraft:stripped_dark_oak_log
fill 88 200 332 88 200 333 minecraft:stripped_dark_oak_log
fill 88 200 335 88 200 337 minecraft:stripped_dark_oak_log
fill 88 200 339 88 200 340 minecraft:stripped_dark_oak_log
fill 88 200 342 88 200 344 minecraft:stripped_dark_oak_log
fill 88 200 346 88 200 347 minecraft:stripped_dark_oak_log
fill 88 200 349 88 200 351 minecraft:stripped_dark_oak_log
fill 88 200 353 88 200 354 minecraft:stripped_dark_oak_log
fill 88 200 356 88 200 358 minecraft:stripped_dark_oak_log
fill 88 200 360 88 200 361 minecraft:stripped_dark_oak_log
fill 89 200 359 89 219 359 minecraft:spruce_planks
setblock 48 201 326 minecraft:stripped_dark_oak_log
setblock 48 201 333 minecraft:stripped_dark_oak_log
setblock 48 201 340 minecraft:stripped_dark_oak_log
setblock 48 201 347 minecraft:stripped_dark_oak_log
setblock 48 201 354 minecraft:stripped_dark_oak_log
setblock 48 201 361 minecraft:stripped_dark_oak_log
setblock 52 201 323 minecraft:stripped_dark_oak_log
setblock 53 201 363 minecraft:stripped_dark_oak_log
setblock 59 201 323 minecraft:stripped_dark_oak_log
setblock 60 201 363 minecraft:stripped_dark_oak_log
setblock 66 201 323 minecraft:stripped_dark_oak_log
setblock 67 201 363 minecraft:stripped_dark_oak_log
setblock 73 201 323 minecraft:stripped_dark_oak_log
setblock 74 201 363 minecraft:stripped_dark_oak_log
setblock 80 201 323 minecraft:stripped_dark_oak_log
setblock 81 201 363 minecraft:stripped_dark_oak_log
setblock 84 201 364 minecraft:red_concrete
fill 86 201 323 87 201 323 minecraft:stripped_dark_oak_log
setblock 88 201 329 minecraft:stripped_dark_oak_log
setblock 88 201 336 minecraft:stripped_dark_oak_log
setblock 88 201 343 minecraft:stripped_dark_oak_log
setblock 88 201 350 minecraft:stripped_dark_oak_log
setblock 88 201 357 minecraft:stripped_dark_oak_log
setblock 88 201 363 minecraft:stripped_dark_oak_log
setblock 48 202 327 minecraft:stripped_dark_oak_log
setblock 48 202 334 minecraft:stripped_dark_oak_log
setblock 48 202 341 minecraft:stripped_dark_oak_log
setblock 48 202 348 minecraft:stripped_dark_oak_log
setblock 48 202 355 minecraft:stripped_dark_oak_log
setblock 48 202 362 minecraft:stripped_dark_oak_log
setblock 50 202 325 minecraft:light[level=15]
setblock 50 202 333 minecraft:light[level=15]
setblock 50 202 341 minecraft:light[level=15]
setblock 50 202 349 minecraft:light[level=15]
setblock 50 202 357 minecraft:light[level=15]
setblock 51 202 323 minecraft:stripped_dark_oak_log
setblock 54 202 363 minecraft:stripped_dark_oak_log
setblock 58 202 323 minecraft:stripped_dark_oak_log
setblock 58 202 325 minecraft:light[level=15]
setblock 58 202 333 minecraft:light[level=15]
setblock 58 202 341 minecraft:light[level=15]
setblock 58 202 349 minecraft:light[level=15]
setblock 58 202 357 minecraft:light[level=15]
setblock 61 202 363 minecraft:stripped_dark_oak_log
setblock 65 202 323 minecraft:stripped_dark_oak_log
setblock 66 202 325 minecraft:light[level=15]
setblock 66 202 333 minecraft:light[level=15]
setblock 66 202 341 minecraft:light[level=15]
setblock 66 202 349 minecraft:light[level=15]
setblock 66 202 357 minecraft:light[level=15]
setblock 68 202 363 minecraft:stripped_dark_oak_log
setblock 72 202 323 minecraft:stripped_dark_oak_log
setblock 74 202 325 minecraft:light[level=15]
setblock 74 202 333 minecraft:light[level=15]
setblock 74 202 341 minecraft:light[level=15]
setblock 74 202 349 minecraft:light[level=15]
setblock 74 202 357 minecraft:light[level=15]
setblock 75 202 363 minecraft:stripped_dark_oak_log
setblock 79 202 323 minecraft:stripped_dark_oak_log
setblock 80 202 323 minecraft:shroomlight
setblock 80 202 325 minecraft:shroomlight
setblock 80 202 327 minecraft:shroomlight
setblock 80 202 329 minecraft:shroomlight
setblock 81 202 324 minecraft:shroomlight
setblock 81 202 326 minecraft:shroomlight
setblock 81 202 328 minecraft:shroomlight
setblock 82 202 323 minecraft:shroomlight
setblock 82 202 325 minecraft:shroomlight
setblock 82 202 327 minecraft:shroomlight
setblock 82 202 329 minecraft:shroomlight
setblock 82 202 333 minecraft:light[level=15]
setblock 82 202 341 minecraft:light[level=15]
setblock 82 202 349 minecraft:light[level=15]
setblock 82 202 357 minecraft:light[level=15]
setblock 82 202 363 minecraft:stripped_dark_oak_log
setblock 83 202 324 minecraft:shroomlight
setblock 83 202 326 minecraft:shroomlight
setblock 83 202 328 minecraft:shroomlight
setblock 84 202 323 minecraft:shroomlight
setblock 84 202 325 minecraft:shroomlight
setblock 84 202 327 minecraft:shroomlight
setblock 84 202 329 minecraft:shroomlight
fill 84 202 364 84 217 364 minecraft:spruce_planks
setblock 85 202 324 minecraft:shroomlight
setblock 85 202 326 minecraft:shroomlight
setblock 85 202 328 minecraft:shroomlight
setblock 86 202 323 minecraft:shroomlight
setblock 86 202 325 minecraft:shroomlight
setblock 86 202 327 minecraft:shroomlight
setblock 86 202 329 minecraft:shroomlight
setblock 88 202 328 minecraft:stripped_dark_oak_log
setblock 88 202 335 minecraft:stripped_dark_oak_log
setblock 88 202 342 minecraft:stripped_dark_oak_log
setblock 88 202 349 minecraft:stripped_dark_oak_log
setblock 88 202 356 minecraft:stripped_dark_oak_log
fill 47 203 350 47 216 350 minecraft:spruce_planks
setblock 47 203 351 minecraft:red_concrete
fill 47 203 352 47 215 356 minecraft:spruce_planks
setblock 47 203 359 minecraft:red_concrete
fill 47 203 360 47 219 360 minecraft:spruce_planks
setblock 47 203 363 minecraft:red_concrete
fill 80 203 323 80 205 323 minecraft:stripped_dark_oak_log
fill 80 203 325 80 205 325 minecraft:stripped_dark_oak_log
fill 80 203 327 80 205 327 minecraft:stripped_dark_oak_log
fill 80 203 329 80 205 329 minecraft:stripped_dark_oak_log
fill 81 203 324 81 205 324 minecraft:stripped_dark_oak_log
fill 81 203 326 81 205 326 minecraft:stripped_dark_oak_log
fill 81 203 328 81 205 328 minecraft:stripped_dark_oak_log
fill 82 203 323 82 205 323 minecraft:stripped_dark_oak_log
fill 82 203 325 82 205 325 minecraft:stripped_dark_oak_log
fill 82 203 327 82 205 327 minecraft:stripped_dark_oak_log
fill 82 203 329 82 205 329 minecraft:stripped_dark_oak_log
fill 83 203 324 83 205 324 minecraft:stripped_dark_oak_log
fill 83 203 326 83 205 326 minecraft:stripped_dark_oak_log
fill 83 203 328 83 205 328 minecraft:stripped_dark_oak_log
fill 84 203 323 84 205 323 minecraft:stripped_dark_oak_log
fill 84 203 325 84 205 325 minecraft:stripped_dark_oak_log
fill 84 203 327 84 205 327 minecraft:stripped_dark_oak_log
fill 84 203 329 84 205 329 minecraft:stripped_dark_oak_log
fill 85 203 324 85 205 324 minecraft:stripped_dark_oak_log
fill 85 203 326 85 205 326 minecraft:stripped_dark_oak_log
fill 85 203 328 85 205 328 minecraft:stripped_dark_oak_log
fill 86 203 323 86 205 323 minecraft:stripped_dark_oak_log
fill 86 203 325 86 205 325 minecraft:stripped_dark_oak_log
fill 86 203 327 86 205 327 minecraft:stripped_dark_oak_log
fill 86 203 329 86 205 329 minecraft:stripped_dark_oak_log
fill 47 204 351 47 219 351 minecraft:spruce_planks
fill 47 204 359 47 217 359 minecraft:spruce_planks
fill 47 204 363 47 217 363 minecraft:spruce_planks
setblock 48 204 329 minecraft:stripped_dark_oak_log
setblock 48 204 336 minecraft:stripped_dark_oak_log
setblock 48 204 343 minecraft:stripped_dark_oak_log
setblock 48 204 350 minecraft:stripped_dark_oak_log
setblock 48 204 357 minecraft:stripped_dark_oak_log
setblock 49 204 323 minecraft:stripped_dark_oak_log
setblock 49 204 363 minecraft:stripped_dark_oak_log
setblock 50 204 325 minecraft:light[level=12]
setblock 50 204 332 minecraft:light[level=12]
setblock 50 204 339 minecraft:red_concrete
setblock 50 204 346 minecraft:light[level=12]
setblock 50 204 353 minecraft:light[level=12]
setblock 50 204 360 minecraft:light[level=12]
setblock 56 204 323 minecraft:stripped_dark_oak_log
setblock 56 204 363 minecraft:stripped_dark_oak_log
setblock 57 204 322 minecraft:red_concrete
setblock 57 204 325 minecraft:light[level=12]
setblock 57 204 332 minecraft:light[level=12]
setblock 57 204 339 minecraft:light[level=12]
setblock 57 204 346 minecraft:light[level=12]
setblock 57 204 353 minecraft:light[level=12]
setblock 57 204 360 minecraft:light[level=12]
fill 58 204 322 59 217 322 minecraft:spruce_planks
setblock 61 204 364 minecraft:red_concrete
fill 62 204 364 62 219 364 minecraft:spruce_planks
setblock 63 204 323 minecraft:stripped_dark_oak_log
setblock 63 204 363 minecraft:stripped_dark_oak_log
setblock 64 204 325 minecraft:light[level=12]
setblock 64 204 332 minecraft:light[level=12]
setblock 64 204 339 minecraft:light[level=12]
setblock 64 204 346 minecraft:light[level=12]
setblock 64 204 353 minecraft:light[level=12]
setblock 64 204 360 minecraft:light[level=12]
setblock 70 204 323 minecraft:stripped_dark_oak_log
setblock 70 204 363 minecraft:stripped_dark_oak_log
setblock 71 204 325 minecraft:light[level=12]
setblock 71 204 332 minecraft:light[level=12]
setblock 71 204 339 minecraft:light[level=12]
setblock 71 204 346 minecraft:light[level=12]
setblock 71 204 353 minecraft:light[level=12]
setblock 71 204 360 minecraft:light[level=12]
setblock 77 204 323 minecraft:stripped_dark_oak_log
setblock 77 204 363 minecraft:stripped_dark_oak_log
setblock 78 204 325 minecraft:light[level=12]
setblock 78 204 332 minecraft:light[level=12]
setblock 78 204 339 minecraft:light[level=12]
setblock 78 204 346 minecraft:light[level=12]
setblock 78 204 353 minecraft:light[level=12]
setblock 78 204 360 minecraft:light[level=12]
setblock 84 204 363 minecraft:stripped_dark_oak_log
setblock 85 204 332 minecraft:light[level=12]
setblock 85 204 339 minecraft:light[level=12]
setblock 85 204 346 minecraft:light[level=12]
setblock 85 204 353 minecraft:light[level=12]
setblock 85 204 360 minecraft:light[level=12]
setblock 88 204 326 minecraft:stripped_dark_oak_log
setblock 88 204 333 minecraft:stripped_dark_oak_log
setblock 88 204 340 minecraft:stripped_dark_oak_log
setblock 88 204 347 minecraft:stripped_dark_oak_log
setblock 88 204 354 minecraft:stripped_dark_oak_log
setblock 88 204 361 minecraft:stripped_dark_oak_log
setblock 48 205 323 minecraft:stripped_dark_oak_log
setblock 48 205 330 minecraft:stripped_dark_oak_log
setblock 48 205 337 minecraft:stripped_dark_oak_log
setblock 48 205 344 minecraft:stripped_dark_oak_log
setblock 48 205 351 minecraft:stripped_dark_oak_log
setblock 48 205 358 minecraft:stripped_dark_oak_log
fill 50 205 339 50 206 339 minecraft:shroomlight
setblock 50 205 363 minecraft:stripped_dark_oak_log
setblock 54 205 361 minecraft:red_concrete
setblock 55 205 323 minecraft:stripped_dark_oak_log
fill 57 205 322 57 219 322 minecraft:spruce_planks
setblock 57 205 363 minecraft:stripped_dark_oak_log
fill 61 205 364 61 219 364 minecraft:spruce_planks
setblock 62 205 323 minecraft:stripped_dark_oak_log
setblock 64 205 363 minecraft:stripped_dark_oak_log
setblock 69 205 323 minecraft:stripped_dark_oak_log
setblock 71 205 363 minecraft:stripped_dark_oak_log
setblock 76 205 323 minecraft:stripped_dark_oak_log
setblock 78 205 363 minecraft:stripped_dark_oak_log
setblock 85 205 363 minecraft:stripped_dark_oak_log
setblock 88 205 325 minecraft:stripped_dark_oak_log
setblock 88 205 332 minecraft:stripped_dark_oak_log
setblock 88 205 339 minecraft:stripped_dark_oak_log
setblock 88 205 346 minecraft:stripped_dark_oak_log
setblock 88 205 353 minecraft:stripped_dark_oak_log
setblock 88 205 360 minecraft:stripped_dark_oak_log
fill 54 206 361 54 207 361 minecraft:shroomlight
fill 61 206 322 62 219 322 minecraft:spruce_planks
setblock 63 206 322 minecraft:red_concrete
fill 64 206 322 64 219 322 minecraft:spruce_planks
setblock 50 207 339 minecraft:red_concrete
fill 63 207 322 63 219 322 minecraft:spruce_planks
setblock 54 208 361 minecraft:red_concrete
setblock 51 209 364 minecraft:red_concrete
fill 52 209 364 53 217 364 minecraft:spruce_planks
setblock 50 210 325 minecraft:light[level=15]
setblock 50 210 332 minecraft:light[level=12]
setblock 50 210 333 minecraft:light[level=15]
setblock 50 210 339 minecraft:light[level=12]
setblock 50 210 341 minecraft:light[level=15]
setblock 50 210 346 minecraft:light[level=12]
setblock 50 210 349 minecraft:light[level=15]
setblock 50 210 353 minecraft:light[level=12]
setblock 50 210 357 minecraft:light[level=15]
setblock 50 210 360 minecraft:light[level=12]
fill 51 210 364 51 215 364 minecraft:spruce_planks
setblock 57 210 325 minecraft:light[level=12]
setblock 57 210 332 minecraft:light[level=12]
setblock 57 210 339 minecraft:light[level=12]
setblock 57 210 346 minecraft:light[level=12]
setblock 57 210 353 minecraft:light[level=12]
setblock 57 210 360 minecraft:light[level=12]
setblock 58 210 325 minecraft:light[level=15]
setblock 58 210 333 minecraft:light[level=15]
setblock 58 210 341 minecraft:light[level=15]
setblock 58 210 349 minecraft:light[level=15]
setblock 58 210 357 minecraft:light[level=15]
setblock 64 210 325 minecraft:light[level=12]
setblock 64 210 332 minecraft:light[level=12]
setblock 64 210 339 minecraft:light[level=12]
setblock 64 210 346 minecraft:light[level=12]
setblock 64 210 353 minecraft:light[level=12]
setblock 64 210 360 minecraft:light[level=12]
setblock 66 210 325 minecraft:light[level=15]
setblock 66 210 333 minecraft:light[level=15]
setblock 66 210 341 minecraft:light[level=15]
setblock 66 210 349 minecraft:light[level=15]
setblock 66 210 357 minecraft:light[level=15]
setblock 71 210 325 minecraft:light[level=12]
setblock 71 210 332 minecraft:light[level=12]
setblock 71 210 339 minecraft:light[level=12]
setblock 71 210 346 minecraft:light[level=12]
setblock 71 210 353 minecraft:light[level=12]
setblock 71 210 360 minecraft:light[level=12]
setblock 74 210 325 minecraft:light[level=15]
setblock 74 210 333 minecraft:light[level=15]
setblock 74 210 341 minecraft:light[level=15]
setblock 74 210 349 minecraft:light[level=15]
setblock 74 210 357 minecraft:light[level=15]
setblock 78 210 325 minecraft:light[level=12]
setblock 78 210 332 minecraft:light[level=12]
setblock 78 210 339 minecraft:light[level=12]
setblock 78 210 346 minecraft:light[level=12]
setblock 78 210 353 minecraft:light[level=12]
setblock 78 210 360 minecraft:light[level=12]
setblock 82 210 325 minecraft:light[level=15]
setblock 82 210 333 minecraft:light[level=15]
setblock 82 210 341 minecraft:light[level=15]
setblock 82 210 349 minecraft:light[level=15]
setblock 82 210 357 minecraft:light[level=15]
setblock 85 210 325 minecraft:light[level=12]
setblock 85 210 332 minecraft:light[level=12]
setblock 85 210 339 minecraft:light[level=12]
setblock 85 210 346 minecraft:light[level=12]
setblock 85 210 353 minecraft:light[level=12]
setblock 85 210 360 minecraft:light[level=12]
setblock 89 210 328 minecraft:red_concrete
fill 48 211 323 49 212 363 minecraft:hay_block
fill 50 211 323 52 212 324 minecraft:hay_block
fill 50 211 325 50 212 325 minecraft:dark_oak_planks
fill 50 211 326 52 212 327 minecraft:hay_block
fill 50 211 328 50 212 328 minecraft:dark_oak_planks
fill 50 211 329 52 212 330 minecraft:hay_block
fill 50 211 331 50 212 331 minecraft:dark_oak_planks
fill 50 211 332 52 212 333 minecraft:hay_block
fill 50 211 334 50 212 334 minecraft:dark_oak_planks
fill 50 211 335 52 212 336 minecraft:hay_block
fill 50 211 337 50 212 337 minecraft:dark_oak_planks
fill 50 211 338 52 212 339 minecraft:hay_block
fill 50 211 340 50 212 340 minecraft:dark_oak_planks
fill 50 211 341 52 212 342 minecraft:hay_block
fill 50 211 343 50 212 343 minecraft:dark_oak_planks
fill 50 211 344 52 212 345 minecraft:hay_block
fill 50 211 346 50 212 346 minecraft:dark_oak_planks
fill 50 211 347 52 212 348 minecraft:hay_block
fill 50 211 349 50 212 349 minecraft:dark_oak_planks
fill 50 211 350 52 212 351 minecraft:hay_block
fill 50 211 352 50 212 352 minecraft:dark_oak_planks
fill 50 211 353 52 212 354 minecraft:hay_block
fill 50 211 355 50 212 355 minecraft:dark_oak_planks
fill 50 211 356 52 212 357 minecraft:hay_block
fill 50 211 358 50 212 358 minecraft:dark_oak_planks
fill 50 211 359 52 212 360 minecraft:hay_block
fill 50 211 361 50 212 361 minecraft:dark_oak_planks
fill 50 211 362 52 212 363 minecraft:hay_block
fill 51 211 325 52 212 325 minecraft:hay_block
fill 51 211 328 52 212 328 minecraft:hay_block
fill 51 211 331 52 212 331 minecraft:hay_block
fill 51 211 334 52 212 334 minecraft:hay_block
fill 51 211 337 52 212 337 minecraft:hay_block
fill 51 211 340 52 212 340 minecraft:hay_block
fill 51 211 343 52 212 343 minecraft:hay_block
fill 51 211 346 52 212 346 minecraft:hay_block
fill 51 211 349 52 212 349 minecraft:hay_block
fill 51 211 352 52 212 352 minecraft:hay_block
fill 51 211 355 52 212 355 minecraft:hay_block
fill 51 211 358 52 212 358 minecraft:hay_block
fill 51 211 361 52 212 361 minecraft:hay_block
fill 53 211 323 53 212 363 minecraft:dark_oak_planks
fill 54 211 323 55 212 363 minecraft:hay_block
fill 56 211 323 58 212 324 minecraft:hay_block
fill 56 211 325 56 212 325 minecraft:dark_oak_planks
fill 56 211 326 58 212 327 minecraft:hay_block
fill 56 211 328 56 212 328 minecraft:dark_oak_planks
fill 56 211 329 58 212 330 minecraft:hay_block
fill 56 211 331 56 212 331 minecraft:dark_oak_planks
fill 56 211 332 58 212 333 minecraft:hay_block
fill 56 211 334 56 212 334 minecraft:dark_oak_planks
fill 56 211 335 58 212 336 minecraft:hay_block
fill 56 211 337 56 212 337 minecraft:dark_oak_planks
fill 56 211 338 58 212 339 minecraft:hay_block
fill 56 211 340 56 212 340 minecraft:dark_oak_planks
fill 56 211 341 58 212 342 minecraft:hay_block
fill 56 211 343 56 212 343 minecraft:dark_oak_planks
fill 56 211 344 58 212 345 minecraft:hay_block
fill 56 211 346 56 212 346 minecraft:dark_oak_planks
fill 56 211 347 58 212 348 minecraft:hay_block
fill 56 211 349 56 212 349 minecraft:dark_oak_planks
fill 56 211 350 58 212 351 minecraft:hay_block
fill 56 211 352 56 212 352 minecraft:dark_oak_planks
fill 56 211 353 58 212 354 minecraft:hay_block
fill 56 211 355 56 212 355 minecraft:dark_oak_planks
fill 56 211 356 58 212 357 minecraft:hay_block
fill 56 211 358 56 212 358 minecraft:dark_oak_planks
fill 56 211 359 58 212 360 minecraft:hay_block
fill 56 211 361 56 212 361 minecraft:dark_oak_planks
fill 56 211 362 58 212 363 minecraft:hay_block
fill 57 211 325 58 212 325 minecraft:hay_block
fill 57 211 328 58 212 328 minecraft:hay_block
fill 57 211 331 58 212 331 minecraft:hay_block
fill 57 211 334 58 212 334 minecraft:hay_block
fill 57 211 337 58 212 337 minecraft:hay_block
fill 57 211 340 58 212 340 minecraft:hay_block
fill 57 211 343 58 212 343 minecraft:hay_block
fill 57 211 346 58 212 346 minecraft:hay_block
fill 57 211 349 58 212 349 minecraft:hay_block
fill 57 211 352 58 212 352 minecraft:hay_block
fill 57 211 355 58 212 355 minecraft:hay_block
fill 57 211 358 58 212 358 minecraft:hay_block
fill 57 211 361 58 212 361 minecraft:hay_block
fill 59 211 323 59 212 363 minecraft:dark_oak_planks
fill 60 211 323 61 212 363 minecraft:hay_block
fill 62 211 323 64 212 324 minecraft:hay_block
fill 62 211 325 62 212 325 minecraft:dark_oak_planks
fill 62 211 326 64 212 327 minecraft:hay_block
fill 62 211 328 62 212 328 minecraft:dark_oak_planks
fill 62 211 329 64 212 330 minecraft:hay_block
fill 62 211 331 62 212 331 minecraft:dark_oak_planks
fill 62 211 332 64 212 333 minecraft:hay_block
fill 62 211 334 62 212 334 minecraft:dark_oak_planks
fill 62 211 335 64 212 336 minecraft:hay_block
fill 62 211 337 62 212 337 minecraft:dark_oak_planks
fill 62 211 338 64 212 339 minecraft:hay_block
fill 62 211 340 62 212 340 minecraft:dark_oak_planks
fill 62 211 341 64 211 342 minecraft:hay_block
fill 62 211 343 62 213 343 minecraft:dark_oak_planks
fill 62 211 344 64 211 345 minecraft:hay_block
fill 62 211 346 62 213 346 minecraft:dark_oak_planks
fill 62 211 347 64 212 348 minecraft:hay_block
fill 62 211 349 62 212 349 minecraft:dark_oak_planks
fill 62 211 350 64 212 351 minecraft:hay_block
fill 62 211 352 62 212 352 minecraft:dark_oak_planks
fill 62 211 353 64 212 354 minecraft:hay_block
fill 62 211 355 62 212 355 minecraft:dark_oak_planks
fill 62 211 356 64 212 357 minecraft:hay_block
fill 62 211 358 62 212 358 minecraft:dark_oak_planks
fill 62 211 359 64 212 360 minecraft:hay_block
fill 62 211 361 62 212 361 minecraft:dark_oak_planks
fill 62 211 362 64 212 363 minecraft:hay_block
fill 63 211 325 64 212 325 minecraft:hay_block
fill 63 211 328 64 212 328 minecraft:hay_block
fill 63 211 331 64 212 331 minecraft:hay_block
fill 63 211 334 64 212 334 minecraft:hay_block
fill 63 211 337 64 212 337 minecraft:hay_block
fill 63 211 340 64 212 340 minecraft:hay_block
fill 63 211 343 64 211 343 minecraft:hay_block
fill 63 211 346 64 211 346 minecraft:hay_block
fill 63 211 349 64 212 349 minecraft:hay_block
fill 63 211 352 64 212 352 minecraft:hay_block
fill 63 211 355 64 212 355 minecraft:hay_block
fill 63 211 358 64 212 358 minecraft:hay_block
fill 63 211 361 64 212 361 minecraft:hay_block
fill 65 211 323 65 212 363 minecraft:dark_oak_planks
fill 66 211 323 66 211 363 minecraft:hay_block
fill 67 211 323 67 211 343 minecraft:hay_block
fill 67 211 344 70 211 344 minecraft:dark_oak_planks
fill 67 211 345 67 211 363 minecraft:hay_block
fill 68 211 323 70 212 324 minecraft:hay_block
fill 68 211 325 68 212 325 minecraft:dark_oak_planks
fill 68 211 326 70 212 327 minecraft:hay_block
fill 68 211 328 68 212 328 minecraft:dark_oak_planks
fill 68 211 329 70 212 330 minecraft:hay_block
fill 68 211 331 68 212 331 minecraft:dark_oak_planks
fill 68 211 332 70 212 333 minecraft:hay_block
fill 68 211 334 68 212 334 minecraft:dark_oak_planks
fill 68 211 335 70 212 336 minecraft:hay_block
fill 68 211 337 68 212 337 minecraft:dark_oak_planks
fill 68 211 338 70 212 339 minecraft:hay_block
fill 68 211 340 68 212 340 minecraft:dark_oak_planks
fill 68 211 341 68 211 342 minecraft:hay_block
fill 68 211 343 70 211 343 minecraft:dark_oak_planks
fill 68 211 345 70 211 346 minecraft:dark_oak_planks
fill 68 211 347 70 211 348 minecraft:hay_block
fill 68 211 349 68 213 349 minecraft:dark_oak_planks
fill 68 211 350 70 212 351 minecraft:hay_block
fill 68 211 352 68 212 352 minecraft:dark_oak_planks
fill 68 211 353 70 212 354 minecraft:hay_block
fill 68 211 355 68 212 355 minecraft:dark_oak_planks
fill 68 211 356 70 212 357 minecraft:hay_block
fill 68 211 358 68 212 358 minecraft:dark_oak_planks
fill 68 211 359 70 212 360 minecraft:hay_block
fill 68 211 361 68 212 361 minecraft:dark_oak_planks
fill 68 211 362 70 212 363 minecraft:hay_block
fill 69 211 325 70 212 325 minecraft:hay_block
fill 69 211 328 70 212 328 minecraft:hay_block
fill 69 211 331 70 212 331 minecraft:hay_block
fill 69 211 334 70 212 334 minecraft:hay_block
fill 69 211 337 70 212 337 minecraft:hay_block
fill 69 211 340 70 211 341 minecraft:hay_block
fill 69 211 342 71 211 342 minecraft:dark_oak_planks
fill 69 211 349 70 212 349 minecraft:hay_block
fill 69 211 352 70 212 352 minecraft:hay_block
fill 69 211 355 70 212 355 minecraft:hay_block
fill 69 211 358 70 212 358 minecraft:hay_block
fill 69 211 361 70 212 361 minecraft:hay_block
fill 71 211 323 71 212 341 minecraft:dark_oak_planks
fill 71 211 346 71 211 363 minecraft:dark_oak_planks
fill 72 211 323 73 211 340 minecraft:hay_block
fill 72 211 341 74 211 341 minecraft:dark_oak_planks
fill 72 211 347 74 211 347 minecraft:dark_oak_planks
fill 72 211 348 73 211 363 minecraft:hay_block
fill 74 211 323 76 212 324 minecraft:hay_block
fill 74 211 325 74 212 325 minecraft:dark_oak_planks
fill 74 211 326 76 212 327 minecraft:hay_block
fill 74 211 328 74 212 328 minecraft:dark_oak_planks
fill 74 211 329 76 212 330 minecraft:hay_block
fill 74 211 331 74 212 331 minecraft:dark_oak_planks
fill 74 211 332 76 212 333 minecraft:hay_block
fill 74 211 334 74 212 334 minecraft:dark_oak_planks
fill 74 211 335 76 212 336 minecraft:hay_block
fill 74 211 337 74 212 337 minecraft:dark_oak_planks
fill 74 211 338 76 212 339 minecraft:hay_block
fill 74 211 340 74 212 340 minecraft:dark_oak_planks
fill 74 211 348 76 211 348 minecraft:hay_block
fill 74 211 349 74 213 349 minecraft:dark_oak_planks
fill 74 211 350 76 212 351 minecraft:hay_block
fill 74 211 352 74 212 352 minecraft:dark_oak_planks
fill 74 211 353 76 212 354 minecraft:hay_block
fill 74 211 355 74 212 355 minecraft:dark_oak_planks
fill 74 211 356 76 212 357 minecraft:hay_block
fill 74 211 358 74 212 358 minecraft:dark_oak_planks
fill 74 211 359 76 212 360 minecraft:hay_block
fill 74 211 361 74 212 361 minecraft:dark_oak_planks
fill 74 211 362 76 212 363 minecraft:hay_block
fill 75 211 325 76 212 325 minecraft:hay_block
fill 75 211 328 76 212 328 minecraft:hay_block
fill 75 211 331 76 212 331 minecraft:hay_block
fill 75 211 334 76 212 334 minecraft:hay_block
fill 75 211 337 76 212 337 minecraft:hay_block
fill 75 211 340 76 211 341 minecraft:hay_block
fill 75 211 342 77 211 342 minecraft:dark_oak_planks
fill 75 211 346 77 211 346 minecraft:dark_oak_planks
fill 75 211 347 76 211 347 minecraft:hay_block
fill 75 211 349 76 212 349 minecraft:hay_block
fill 75 211 352 76 212 352 minecraft:hay_block
fill 75 211 355 76 212 355 minecraft:hay_block
fill 75 211 358 76 212 358 minecraft:hay_block
fill 75 211 361 76 212 361 minecraft:hay_block
fill 76 211 343 78 211 345 minecraft:dark_oak_planks
fill 77 211 323 77 212 341 minecraft:dark_oak_planks
fill 77 211 347 77 212 363 minecraft:dark_oak_planks
fill 78 211 323 79 211 342 minecraft:hay_block
fill 78 211 346 79 211 363 minecraft:hay_block
setblock 79 211 343 minecraft:hay_block
fill 79 211 344 79 212 344 minecraft:dark_oak_planks
fill 79 211 345 82 211 345 minecraft:hay_block
fill 80 211 323 82 212 324 minecraft:hay_block
fill 80 211 325 80 212 325 minecraft:dark_oak_planks
fill 80 211 326 82 212 327 minecraft:hay_block
fill 80 211 328 80 212 328 minecraft:dark_oak_planks
fill 80 211 329 82 212 330 minecraft:hay_block
fill 80 211 331 80 212 331 minecraft:dark_oak_planks
fill 80 211 332 82 212 333 minecraft:hay_block
fill 80 211 334 80 212 334 minecraft:dark_oak_planks
fill 80 211 335 82 212 336 minecraft:hay_block
fill 80 211 337 80 212 337 minecraft:dark_oak_planks
fill 80 211 338 82 212 339 minecraft:hay_block
fill 80 211 340 80 213 340 minecraft:dark_oak_planks
fill 80 211 341 82 211 342 minecraft:hay_block
fill 80 211 343 80 212 343 minecraft:dark_oak_planks
fill 80 211 344 82 211 344 minecraft:hay_block
fill 80 211 346 80 212 346 minecraft:dark_oak_planks
fill 80 211 347 82 211 348 minecraft:hay_block
fill 80 211 349 80 212 349 minecraft:dark_oak_planks
fill 80 211 350 82 212 351 minecraft:hay_block
fill 80 211 352 80 212 352 minecraft:dark_oak_planks
fill 80 211 353 82 212 354 minecraft:hay_block
fill 80 211 355 80 212 355 minecraft:dark_oak_planks
fill 80 211 356 82 212 357 minecraft:hay_block
fill 80 211 358 80 212 358 minecraft:dark_oak_planks
fill 80 211 359 82 212 360 minecraft:hay_block
fill 80 211 361 80 212 361 minecraft:dark_oak_planks
fill 80 211 362 82 212 363 minecraft:hay_block
fill 81 211 325 82 212 325 minecraft:hay_block
fill 81 211 328 82 212 328 minecraft:hay_block
fill 81 211 331 82 212 331 minecraft:hay_block
fill 81 211 334 82 212 334 minecraft:hay_block
fill 81 211 337 82 212 337 minecraft:hay_block
fill 81 211 340 82 212 340 minecraft:hay_block
fill 81 211 343 82 211 343 minecraft:hay_block
fill 81 211 346 82 211 346 minecraft:hay_block
fill 81 211 349 82 212 349 minecraft:hay_block
fill 81 211 352 82 212 352 minecraft:hay_block
fill 81 211 355 82 212 355 minecraft:hay_block
fill 81 211 358 82 212 358 minecraft:hay_block
fill 81 211 361 82 212 361 minecraft:hay_block
fill 83 211 323 83 212 363 minecraft:dark_oak_planks
fill 84 211 323 85 212 363 minecraft:hay_block
fill 86 211 323 88 212 324 minecraft:hay_block
fill 86 211 325 86 212 325 minecraft:dark_oak_planks
fill 86 211 326 88 212 327 minecraft:hay_block
fill 86 211 328 86 212 328 minecraft:dark_oak_planks
fill 86 211 329 88 212 330 minecraft:hay_block
fill 86 211 331 86 212 331 minecraft:dark_oak_planks
fill 86 211 332 88 212 333 minecraft:hay_block
fill 86 211 334 86 212 334 minecraft:dark_oak_planks
fill 86 211 335 88 212 336 minecraft:hay_block
fill 86 211 337 86 212 337 minecraft:dark_oak_planks
fill 86 211 338 88 212 339 minecraft:hay_block
fill 86 211 340 86 212 340 minecraft:dark_oak_planks
fill 86 211 341 88 212 342 minecraft:hay_block
fill 86 211 343 86 212 343 minecraft:dark_oak_planks
fill 86 211 344 88 212 345 minecraft:hay_block
fill 86 211 346 86 212 346 minecraft:dark_oak_planks
fill 86 211 347 88 212 348 minecraft:hay_block
fill 86 211 349 86 212 349 minecraft:dark_oak_planks
fill 86 211 350 88 212 351 minecraft:hay_block
fill 86 211 352 86 212 352 minecraft:dark_oak_planks
fill 86 211 353 88 212 354 minecraft:hay_block
fill 86 211 355 86 212 355 minecraft:dark_oak_planks
fill 86 211 356 88 212 357 minecraft:hay_block
fill 86 211 358 86 212 358 minecraft:dark_oak_planks
fill 86 211 359 88 212 360 minecraft:hay_block
fill 86 211 361 86 212 361 minecraft:dark_oak_planks
fill 86 211 362 88 212 363 minecraft:hay_block
fill 87 211 325 88 212 325 minecraft:hay_block
fill 87 211 328 88 212 328 minecraft:hay_block
fill 87 211 331 88 212 331 minecraft:hay_block
fill 87 211 334 88 212 334 minecraft:hay_block
fill 87 211 337 88 212 337 minecraft:hay_block
fill 87 211 340 88 212 340 minecraft:hay_block
fill 87 211 343 88 212 343 minecraft:hay_block
fill 87 211 346 88 212 346 minecraft:hay_block
fill 87 211 349 88 212 349 minecraft:hay_block
fill 87 211 352 88 212 352 minecraft:hay_block
fill 87 211 355 88 212 355 minecraft:hay_block
fill 87 211 358 88 212 358 minecraft:hay_block
fill 87 211 361 88 212 361 minecraft:hay_block
fill 89 211 328 89 215 328 minecraft:spruce_planks
setblock 89 211 360 minecraft:red_concrete
setblock 47 212 328 minecraft:red_concrete
fill 47 212 329 47 216 329 minecraft:spruce_planks
fill 62 212 341 63 212 342 minecraft:hay_block
fill 62 212 344 63 212 345 minecraft:hay_block
setblock 63 212 343 minecraft:hay_block
setblock 63 212 346 minecraft:hay_block
setblock 64 212 341 minecraft:hay_block
fill 64 212 342 64 212 346 minecraft:dark_oak_planks
fill 66 212 323 67 212 340 minecraft:hay_block
fill 66 212 341 69 212 347 minecraft:dark_oak_planks
fill 66 212 348 67 212 363 minecraft:hay_block
fill 68 212 348 76 212 348 minecraft:dark_oak_planks
fill 69 212 340 70 212 340 minecraft:dark_oak_planks
fill 70 212 341 70 212 342 minecraft:dark_oak_planks
fill 70 212 343 70 212 345 minecraft:sea_lantern
fill 70 212 346 70 212 347 minecraft:dark_oak_planks
setblock 71 212 342 minecraft:sea_lantern
setblock 71 212 346 minecraft:sea_lantern
setblock 71 212 347 minecraft:dark_oak_planks
fill 71 212 349 71 212 363 minecraft:dark_oak_planks
fill 72 212 323 73 212 339 minecraft:hay_block
fill 72 212 340 73 212 340 minecraft:dark_oak_planks
fill 72 212 341 74 212 341 minecraft:sea_lantern
fill 72 212 347 74 212 347 minecraft:sea_lantern
fill 72 212 349 73 212 363 minecraft:hay_block
fill 75 212 340 76 212 341 minecraft:dark_oak_planks
setblock 75 212 342 minecraft:sea_lantern
setblock 75 212 346 minecraft:sea_lantern
fill 75 212 347 76 212 347 minecraft:dark_oak_planks
fill 76 212 342 82 212 342 minecraft:dark_oak_planks
fill 76 212 343 76 212 345 minecraft:sea_lantern
fill 76 212 346 79 212 346 minecraft:dark_oak_planks
fill 77 212 343 78 212 345 minecraft:dark_oak_planks
fill 78 212 323 79 212 339 minecraft:hay_block
fill 78 212 340 78 212 341 minecraft:dark_oak_planks
fill 78 212 347 78 212 348 minecraft:dark_oak_planks
fill 78 212 349 79 212 363 minecraft:hay_block
setblock 79 212 340 minecraft:hay_block
fill 79 212 341 80 212 341 minecraft:dark_oak_planks
setblock 79 212 343 minecraft:dark_oak_planks
fill 79 212 345 82 212 345 minecraft:dark_oak_planks
fill 79 212 347 80 212 347 minecraft:dark_oak_planks
fill 79 212 348 82 212 348 minecraft:hay_block
fill 80 212 344 82 212 344 minecraft:dark_oak_planks
fill 81 212 341 82 212 341 minecraft:hay_block
fill 81 212 343 82 212 343 minecraft:dark_oak_planks
fill 81 212 346 82 212 346 minecraft:dark_oak_planks
fill 81 212 347 82 212 347 minecraft:hay_block
fill 89 212 360 89 219 360 minecraft:spruce_planks
fill 47 213 328 47 215 328 minecraft:spruce_planks
fill 61 213 344 63 213 344 minecraft:dark_oak_planks
fill 62 213 342 63 213 342 minecraft:dark_oak_planks
fill 62 213 345 63 213 345 minecraft:dark_oak_planks
fill 63 213 341 65 213 341 minecraft:dark_oak_planks
setblock 63 213 343 minecraft:dark_oak_planks
fill 63 213 346 63 213 347 minecraft:dark_oak_planks
fill 64 213 340 67 213 340 minecraft:dark_oak_planks
fill 64 213 347 65 213 348 minecraft:dark_oak_planks
fill 66 213 348 67 213 348 minecraft:dark_oak_planks
fill 67 213 339 79 213 339 minecraft:dark_oak_planks
fill 67 213 349 67 214 349 minecraft:dark_oak_planks
fill 69 213 349 73 213 349 minecraft:dark_oak_planks
fill 72 213 338 74 215 338 minecraft:dark_oak_planks
fill 72 213 350 74 215 350 minecraft:dark_oak_planks
fill 75 213 349 79 213 349 minecraft:dark_oak_planks
setblock 79 213 340 minecraft:dark_oak_planks
fill 79 213 348 82 213 348 minecraft:dark_oak_planks
fill 81 213 340 82 213 341 minecraft:dark_oak_planks
fill 81 213 347 83 213 347 minecraft:dark_oak_planks
fill 83 213 341 83 213 346 minecraft:dark_oak_planks
fill 84 213 342 84 213 346 minecraft:dark_oak_planks
setblock 85 213 344 minecraft:dark_oak_planks
fill 60 214 343 60 215 345 minecraft:dark_oak_planks
fill 61 214 342 61 214 343 minecraft:dark_oak_planks
fill 61 214 345 61 214 346 minecraft:dark_oak_planks
setblock 62 214 341 minecraft:dark_oak_planks
setblock 62 214 347 minecraft:dark_oak_planks
fill 63 214 340 64 214 340 minecraft:dark_oak_planks
fill 63 214 348 64 214 348 minecraft:dark_oak_planks
fill 65 214 339 67 214 339 minecraft:dark_oak_planks
fill 65 214 349 66 214 349 minecraft:dark_oak_planks
fill 68 214 338 71 215 338 minecraft:dark_oak_planks
fill 68 214 350 71 215 350 minecraft:dark_oak_planks
fill 75 214 338 78 215 338 minecraft:dark_oak_planks
fill 75 214 350 78 215 350 minecraft:dark_oak_planks
fill 79 214 339 81 214 339 minecraft:dark_oak_planks
fill 79 214 349 81 214 349 minecraft:dark_oak_planks
fill 82 214 340 83 214 340 minecraft:dark_oak_planks
fill 82 214 348 83 214 348 minecraft:dark_oak_planks
setblock 84 214 341 minecraft:dark_oak_planks
setblock 84 214 347 minecraft:dark_oak_planks
fill 85 214 342 85 214 343 minecraft:dark_oak_planks
fill 85 214 345 85 214 346 minecraft:dark_oak_planks
fill 86 214 343 86 215 345 minecraft:dark_oak_planks
setblock 60 215 342 minecraft:dark_oak_planks
setblock 60 215 346 minecraft:dark_oak_planks
setblock 61 215 341 minecraft:dark_oak_planks
setblock 61 215 347 minecraft:dark_oak_planks
fill 62 215 340 63 215 340 minecraft:dark_oak_planks
fill 62 215 348 63 215 348 minecraft:dark_oak_planks
fill 64 215 339 65 215 339 minecraft:dark_oak_planks
fill 64 215 349 65 215 349 minecraft:dark_oak_planks
fill 66 215 338 67 215 338 minecraft:dark_oak_planks
fill 66 215 350 67 215 350 minecraft:dark_oak_planks
fill 79 215 338 80 215 338 minecraft:dark_oak_planks
fill 79 215 350 80 215 350 minecraft:dark_oak_planks
fill 81 215 339 82 215 339 minecraft:dark_oak_planks
fill 81 215 349 82 215 349 minecraft:dark_oak_planks
fill 83 215 340 84 215 340 minecraft:dark_oak_planks
fill 83 215 348 84 215 348 minecraft:dark_oak_planks
setblock 85 215 341 minecraft:dark_oak_planks
setblock 85 215 347 minecraft:dark_oak_planks
setblock 86 215 342 minecraft:dark_oak_planks
setblock 86 215 346 minecraft:dark_oak_planks
setblock 47 216 324 minecraft:dark_oak_planks
fill 47 216 328 47 217 328 minecraft:dark_oak_planks
fill 47 216 330 47 219 330 minecraft:spruce_planks
fill 47 216 331 47 216 332 minecraft:dark_oak_planks
fill 47 216 333 47 216 334 minecraft:spruce_planks
fill 47 216 338 47 217 338 minecraft:dark_oak_planks
setblock 47 216 347 minecraft:dark_oak_planks
fill 47 216 348 47 219 348 minecraft:spruce_planks
fill 47 216 352 47 219 355 minecraft:spruce_planks
setblock 47 216 356 minecraft:dark_oak_planks
fill 48 216 327 48 216 328 minecraft:stripped_dark_oak_log
fill 48 216 334 48 216 335 minecraft:stripped_dark_oak_log
fill 48 216 341 48 216 342 minecraft:stripped_dark_oak_log
fill 48 216 348 48 216 349 minecraft:stripped_dark_oak_log
fill 48 216 355 48 216 356 minecraft:stripped_dark_oak_log
fill 48 216 362 48 216 363 minecraft:stripped_dark_oak_log
fill 50 216 323 51 216 323 minecraft:stripped_dark_oak_log
setblock 50 216 325 minecraft:light[level=12]
setblock 50 216 332 minecraft:light[level=12]
setblock 50 216 339 minecraft:light[level=12]
setblock 50 216 346 minecraft:light[level=12]
setblock 50 216 353 minecraft:light[level=12]
fill 50 216 358 50 216 361 minecraft:dark_oak_planks
fill 51 216 340 51 219 340 minecraft:iron_bars
fill 51 216 357 52 216 357 minecraft:dark_oak_planks
fill 51 216 358 52 269 360 minecraft:stripped_dark_oak_log
setblock 51 216 361 minecraft:dark_oak_planks
setblock 51 216 364 minecraft:red_concrete
fill 52 216 361 52 269 361 minecraft:stripped_dark_oak_log
fill 53 216 358 54 216 358 minecraft:dark_oak_planks
fill 53 216 359 53 269 360 minecraft:stripped_dark_oak_log
setblock 53 216 361 minecraft:dark_oak_planks
fill 54 216 359 54 216 360 minecraft:dark_oak_planks
fill 54 216 363 55 216 363 minecraft:stripped_dark_oak_log
fill 57 216 323 58 216 323 minecraft:stripped_dark_oak_log
setblock 57 216 325 minecraft:light[level=12]
setblock 57 216 332 minecraft:light[level=12]
setblock 57 216 339 minecraft:light[level=12]
setblock 57 216 346 minecraft:light[level=12]
setblock 57 216 353 minecraft:light[level=12]
setblock 57 216 360 minecraft:light[level=12]
fill 60 216 342 68 216 346 minecraft:spruce_planks
fill 61 216 323 69 216 331 minecraft:stripped_dark_oak_log
fill 61 216 341 69 216 341 minecraft:spruce_planks
fill 61 216 347 69 216 347 minecraft:spruce_planks
fill 61 216 363 62 216 363 minecraft:stripped_dark_oak_log
fill 62 216 340 71 216 340 minecraft:spruce_planks
fill 62 216 348 71 216 348 minecraft:spruce_planks
setblock 64 216 332 minecraft:light[level=12]
fill 64 216 339 82 216 339 minecraft:spruce_planks
fill 64 216 349 82 216 349 minecraft:spruce_planks
setblock 64 216 353 minecraft:light[level=12]
setblock 64 216 360 minecraft:light[level=12]
fill 66 216 338 80 216 338 minecraft:spruce_planks
fill 66 216 350 80 216 350 minecraft:spruce_planks
fill 68 216 322 68 217 322 minecraft:dark_oak_planks
fill 68 216 363 69 216 363 minecraft:stripped_dark_oak_log
setblock 69 216 342 minecraft:spruce_planks
setblock 69 216 346 minecraft:spruce_planks
setblock 69 216 364 minecraft:dark_oak_planks
setblock 70 216 322 minecraft:dark_oak_planks
fill 71 216 322 72 217 322 minecraft:spruce_planks
fill 71 216 323 72 216 323 minecraft:stripped_dark_oak_log
setblock 71 216 325 minecraft:light[level=12]
setblock 71 216 332 minecraft:light[level=12]
setblock 71 216 353 minecraft:light[level=12]
setblock 71 216 360 minecraft:light[level=12]
fill 75 216 340 84 216 340 minecraft:spruce_planks
fill 75 216 348 84 216 348 minecraft:spruce_planks
fill 75 216 363 76 216 363 minecraft:stripped_dark_oak_log
fill 77 216 341 85 216 342 minecraft:spruce_planks
fill 77 216 346 85 216 347 minecraft:spruce_planks
fill 78 216 323 79 216 323 minecraft:stripped_dark_oak_log
setblock 78 216 325 minecraft:light[level=12]
setblock 78 216 332 minecraft:light[level=12]
fill 78 216 343 86 216 345 minecraft:spruce_planks
setblock 78 216 353 minecraft:light[level=12]
setblock 78 216 360 minecraft:light[level=12]
fill 79 216 327 88 216 337 minecraft:stripped_dark_oak_log
fill 80 216 351 88 232 352 minecraft:stripped_dark_oak_log
fill 81 216 350 88 232 350 minecraft:stripped_dark_oak_log
fill 82 216 363 83 216 363 minecraft:stripped_dark_oak_log
setblock 83 216 326 minecraft:dark_oak_planks
fill 83 216 349 88 232 349 minecraft:stripped_dark_oak_log
fill 84 216 325 85 216 325 minecraft:dark_oak_planks
fill 84 216 326 85 269 326 minecraft:stripped_dark_oak_log
fill 85 216 322 88 217 322 minecraft:spruce_planks
fill 85 216 323 86 216 323 minecraft:stripped_dark_oak_log
setblock 85 216 339 minecraft:light[level=12]
fill 85 216 348 88 232 348 minecraft:stripped_dark_oak_log
setblock 85 216 353 minecraft:light[level=12]
setblock 85 216 360 minecraft:light[level=12]
setblock 86 216 326 minecraft:dark_oak_planks
setblock 86 216 342 minecraft:spruce_planks
setblock 86 216 346 minecraft:spruce_planks
fill 86 216 347 88 232 347 minecraft:stripped_dark_oak_log
fill 87 216 346 88 232 346 minecraft:stripped_dark_oak_log
fill 88 216 341 88 216 342 minecraft:stripped_dark_oak_log
fill 88 216 355 88 216 356 minecraft:stripped_dark_oak_log
fill 88 216 362 88 269 362 minecraft:stripped_dark_oak_log
fill 89 216 322 89 217 323 minecraft:dark_oak_planks
fill 89 216 324 89 216 327 minecraft:spruce_planks
setblock 89 216 328 minecraft:dark_oak_planks
fill 89 216 333 89 219 337 minecraft:spruce_planks
setblock 89 216 338 minecraft:dark_oak_planks
fill 89 216 339 89 219 339 minecraft:spruce_planks
setblock 89 216 341 minecraft:dark_oak_planks
fill 89 216 345 89 216 346 minecraft:dark_oak_planks
fill 89 216 347 89 216 350 minecraft:spruce_planks
setblock 89 216 362 minecraft:red_concrete
setblock 89 216 364 minecraft:dark_oak_planks
fill 47 217 324 47 219 324 minecraft:spruce_planks
setblock 47 217 329 minecraft:dark_oak_planks
fill 47 217 331 47 217 333 minecraft:spruce_planks
setblock 47 217 334 minecraft:dark_oak_planks
setblock 47 217 336 minecraft:dark_oak_planks
fill 47 217 339 47 219 340 minecraft:spruce_planks
setblock 47 217 341 minecraft:dark_oak_planks
setblock 47 217 346 minecraft:dark_oak_planks
fill 47 217 347 47 219 347 minecraft:spruce_planks
setblock 47 217 350 minecraft:dark_oak_planks
fill 47 217 356 47 219 356 minecraft:spruce_planks
setblock 47 217 361 minecraft:dark_oak_planks
fill 47 217 362 47 220 362 minecraft:spruce_planks
fill 48 217 328 48 269 328 minecraft:stripped_dark_oak_log
fill 48 217 335 48 252 335 minecraft:stripped_dark_oak_log
fill 48 217 342 48 269 342 minecraft:stripped_dark_oak_log
fill 48 217 349 48 269 349 minecraft:stripped_dark_oak_log
fill 48 217 356 48 269 356 minecraft:stripped_dark_oak_log
fill 48 217 363 48 269 363 minecraft:stripped_dark_oak_log
fill 50 217 323 50 269 323 minecraft:stripped_dark_oak_log
fill 51 217 364 51 219 364 minecraft:spruce_planks
fill 55 217 363 55 269 363 minecraft:stripped_dark_oak_log
fill 57 217 323 57 269 323 minecraft:stripped_dark_oak_log
setblock 57 217 364 minecraft:spruce_planks
setblock 58 217 364 minecraft:dark_oak_planks
fill 61 217 323 61 237 323 minecraft:stripped_dark_oak_log
setblock 61 217 324 minecraft:shroomlight
fill 61 217 325 61 237 325 minecraft:stripped_dark_oak_log
setblock 61 217 326 minecraft:shroomlight
fill 61 217 327 61 237 327 minecraft:stripped_dark_oak_log
setblock 61 217 328 minecraft:shroomlight
fill 61 217 329 61 237 329 minecraft:stripped_dark_oak_log
setblock 61 217 330 minecraft:shroomlight
fill 61 217 331 61 237 331 minecraft:stripped_dark_oak_log
setblock 62 217 323 minecraft:shroomlight
fill 62 217 324 62 237 324 minecraft:stripped_dark_oak_log
setblock 62 217 325 minecraft:shroomlight
fill 62 217 326 62 237 326 minecraft:stripped_dark_oak_log
setblock 62 217 327 minecraft:shroomlight
fill 62 217 328 62 237 328 minecraft:stripped_dark_oak_log
setblock 62 217 329 minecraft:shroomlight
fill 62 217 330 62 237 330 minecraft:stripped_dark_oak_log
setblock 62 217 331 minecraft:shroomlight
fill 62 217 363 62 269 363 minecraft:stripped_dark_oak_log
fill 63 217 323 63 237 323 minecraft:stripped_dark_oak_log
setblock 63 217 324 minecraft:shroomlight
fill 63 217 325 63 237 325 minecraft:stripped_dark_oak_log
setblock 63 217 326 minecraft:shroomlight
fill 63 217 327 63 237 327 minecraft:stripped_dark_oak_log
setblock 63 217 328 minecraft:shroomlight
fill 63 217 329 63 237 329 minecraft:stripped_dark_oak_log
setblock 63 217 330 minecraft:shroomlight
fill 63 217 331 63 237 331 minecraft:stripped_dark_oak_log
setblock 64 217 323 minecraft:shroomlight
fill 64 217 324 64 237 324 minecraft:stripped_dark_oak_log
setblock 64 217 325 minecraft:shroomlight
fill 64 217 326 64 237 326 minecraft:stripped_dark_oak_log
setblock 64 217 327 minecraft:shroomlight
fill 64 217 328 64 237 328 minecraft:stripped_dark_oak_log
setblock 64 217 329 minecraft:shroomlight
fill 64 217 330 64 237 330 minecraft:stripped_dark_oak_log
setblock 64 217 331 minecraft:shroomlight
fill 65 217 323 65 237 323 minecraft:stripped_dark_oak_log
setblock 65 217 324 minecraft:shroomlight
fill 65 217 325 65 237 325 minecraft:stripped_dark_oak_log
setblock 65 217 326 minecraft:shroomlight
fill 65 217 327 65 237 327 minecraft:stripped_dark_oak_log
setblock 65 217 328 minecraft:shroomlight
fill 65 217 329 65 237 329 minecraft:stripped_dark_oak_log
setblock 65 217 330 minecraft:shroomlight
fill 65 217 331 65 237 331 minecraft:stripped_dark_oak_log
setblock 65 217 364 minecraft:dark_oak_planks
setblock 66 217 323 minecraft:shroomlight
fill 66 217 324 66 237 324 minecraft:stripped_dark_oak_log
setblock 66 217 325 minecraft:shroomlight
fill 66 217 326 66 237 326 minecraft:stripped_dark_oak_log
setblock 66 217 327 minecraft:shroomlight
fill 66 217 328 66 237 328 minecraft:stripped_dark_oak_log
setblock 66 217 329 minecraft:shroomlight
fill 66 217 330 66 237 330 minecraft:stripped_dark_oak_log
setblock 66 217 331 minecraft:shroomlight
fill 67 217 323 67 237 323 minecraft:stripped_dark_oak_log
setblock 67 217 324 minecraft:shroomlight
fill 67 217 325 67 237 325 minecraft:stripped_dark_oak_log
setblock 67 217 326 minecraft:shroomlight
fill 67 217 327 67 237 327 minecraft:stripped_dark_oak_log
setblock 67 217 328 minecraft:shroomlight
fill 67 217 329 67 237 329 minecraft:stripped_dark_oak_log
setblock 67 217 330 minecraft:shroomlight
fill 67 217 331 67 237 331 minecraft:stripped_dark_oak_log
setblock 68 217 323 minecraft:shroomlight
fill 68 217 324 68 237 324 minecraft:stripped_dark_oak_log
setblock 68 217 325 minecraft:shroomlight
fill 68 217 326 68 237 326 minecraft:stripped_dark_oak_log
setblock 68 217 327 minecraft:shroomlight
fill 68 217 328 68 237 328 minecraft:stripped_dark_oak_log
setblock 68 217 329 minecraft:shroomlight
fill 68 217 330 68 237 330 minecraft:stripped_dark_oak_log
setblock 68 217 331 minecraft:shroomlight
fill 69 217 323 69 237 323 minecraft:stripped_dark_oak_log
setblock 69 217 324 minecraft:shroomlight
fill 69 217 325 69 237 325 minecraft:stripped_dark_oak_log
setblock 69 217 326 minecraft:shroomlight
fill 69 217 327 69 237 327 minecraft:stripped_dark_oak_log
setblock 69 217 328 minecraft:shroomlight
fill 69 217 329 69 237 329 minecraft:stripped_dark_oak_log
setblock 69 217 330 minecraft:shroomlight
fill 69 217 331 69 237 331 minecraft:stripped_dark_oak_log
fill 69 217 363 69 269 363 minecraft:stripped_dark_oak_log
fill 69 217 364 69 219 364 minecraft:spruce_planks
fill 70 217 322 70 219 322 minecraft:spruce_planks
fill 71 217 323 71 269 323 minecraft:stripped_dark_oak_log
fill 76 217 363 76 269 363 minecraft:stripped_dark_oak_log
fill 78 217 323 78 269 323 minecraft:stripped_dark_oak_log
fill 79 217 327 79 232 327 minecraft:stripped_dark_oak_log
setblock 79 217 328 minecraft:shroomlight
fill 79 217 329 79 232 329 minecraft:stripped_dark_oak_log
setblock 79 217 330 minecraft:shroomlight
fill 79 217 331 79 232 331 minecraft:stripped_dark_oak_log
setblock 79 217 332 minecraft:shroomlight
fill 79 217 333 79 232 333 minecraft:stripped_dark_oak_log
setblock 79 217 334 minecraft:shroomlight
fill 79 217 335 79 232 335 minecraft:stripped_dark_oak_log
setblock 79 217 336 minecraft:shroomlight
fill 79 217 337 79 232 337 minecraft:stripped_dark_oak_log
setblock 80 217 327 minecraft:shroomlight
fill 80 217 328 80 232 328 minecraft:stripped_dark_oak_log
setblock 80 217 329 minecraft:shroomlight
fill 80 217 330 80 232 330 minecraft:stripped_dark_oak_log
setblock 80 217 331 minecraft:shroomlight
fill 80 217 332 80 232 332 minecraft:stripped_dark_oak_log
setblock 80 217 333 minecraft:shroomlight
fill 80 217 334 80 232 334 minecraft:stripped_dark_oak_log
setblock 80 217 335 minecraft:shroomlight
fill 80 217 336 80 232 336 minecraft:stripped_dark_oak_log
setblock 80 217 337 minecraft:shroomlight
fill 80 217 344 80 220 344 minecraft:stripped_dark_oak_log
fill 80 217 346 80 220 350 minecraft:stripped_dark_oak_log
fill 81 217 327 81 232 327 minecraft:stripped_dark_oak_log
setblock 81 217 328 minecraft:shroomlight
fill 81 217 329 81 232 329 minecraft:stripped_dark_oak_log
setblock 81 217 330 minecraft:shroomlight
fill 81 217 331 81 232 331 minecraft:stripped_dark_oak_log
setblock 81 217 332 minecraft:shroomlight
fill 81 217 333 81 232 333 minecraft:stripped_dark_oak_log
setblock 81 217 334 minecraft:shroomlight
fill 81 217 335 81 232 335 minecraft:stripped_dark_oak_log
setblock 81 217 336 minecraft:shroomlight
fill 81 217 337 81 232 337 minecraft:stripped_dark_oak_log
fill 81 217 346 82 232 349 minecraft:stripped_dark_oak_log
setblock 82 217 322 minecraft:spruce_planks
setblock 82 217 327 minecraft:shroomlight
fill 82 217 328 82 232 328 minecraft:stripped_dark_oak_log
setblock 82 217 329 minecraft:shroomlight
fill 82 217 330 82 232 330 minecraft:stripped_dark_oak_log
setblock 82 217 331 minecraft:shroomlight
fill 82 217 332 82 232 332 minecraft:stripped_dark_oak_log
setblock 82 217 333 minecraft:shroomlight
fill 82 217 334 82 232 334 minecraft:stripped_dark_oak_log
setblock 82 217 335 minecraft:shroomlight
fill 82 217 336 82 232 336 minecraft:stripped_dark_oak_log
setblock 82 217 337 minecraft:shroomlight
setblock 83 217 322 minecraft:dark_oak_planks
fill 83 217 327 83 269 327 minecraft:stripped_dark_oak_log
setblock 83 217 328 minecraft:shroomlight
fill 83 217 329 83 232 329 minecraft:stripped_dark_oak_log
setblock 83 217 330 minecraft:shroomlight
fill 83 217 331 83 232 331 minecraft:stripped_dark_oak_log
setblock 83 217 332 minecraft:shroomlight
fill 83 217 333 83 232 333 minecraft:stripped_dark_oak_log
setblock 83 217 334 minecraft:shroomlight
fill 83 217 335 83 232 335 minecraft:stripped_dark_oak_log
setblock 83 217 336 minecraft:shroomlight
fill 83 217 337 83 232 337 minecraft:stripped_dark_oak_log
fill 83 217 346 84 232 348 minecraft:stripped_dark_oak_log
fill 83 217 363 83 269 363 minecraft:stripped_dark_oak_log
fill 84 217 322 84 219 322 minecraft:spruce_planks
setblock 84 217 327 minecraft:shroomlight
fill 84 217 328 84 232 328 minecraft:stripped_dark_oak_log
setblock 84 217 329 minecraft:shroomlight
fill 84 217 330 84 232 330 minecraft:stripped_dark_oak_log
setblock 84 217 331 minecraft:shroomlight
fill 84 217 332 84 232 332 minecraft:stripped_dark_oak_log
setblock 84 217 333 minecraft:shroomlight
fill 84 217 334 84 232 334 minecraft:stripped_dark_oak_log
setblock 84 217 335 minecraft:shroomlight
fill 84 217 336 84 232 336 minecraft:stripped_dark_oak_log
setblock 84 217 337 minecraft:shroomlight
fill 85 217 323 85 269 323 minecraft:stripped_dark_oak_log
fill 85 217 327 85 269 327 minecraft:stripped_dark_oak_log
setblock 85 217 328 minecraft:shroomlight
fill 85 217 329 85 232 329 minecraft:stripped_dark_oak_log
setblock 85 217 330 minecraft:shroomlight
fill 85 217 331 85 232 331 minecraft:stripped_dark_oak_log
setblock 85 217 332 minecraft:shroomlight
fill 85 217 333 85 232 333 minecraft:stripped_dark_oak_log
setblock 85 217 334 minecraft:shroomlight
fill 85 217 335 85 232 335 minecraft:stripped_dark_oak_log
setblock 85 217 336 minecraft:shroomlight
fill 85 217 337 85 232 337 minecraft:stripped_dark_oak_log
fill 85 217 346 85 232 347 minecraft:stripped_dark_oak_log
setblock 86 217 327 minecraft:shroomlight
fill 86 217 328 86 232 328 minecraft:stripped_dark_oak_log
setblock 86 217 329 minecraft:shroomlight
fill 86 217 330 86 232 330 minecraft:stripped_dark_oak_log
setblock 86 217 331 minecraft:shroomlight
fill 86 217 332 86 232 332 minecraft:stripped_dark_oak_log
setblock 86 217 333 minecraft:shroomlight
fill 86 217 334 86 232 334 minecraft:stripped_dark_oak_log
setblock 86 217 335 minecraft:shroomlight
fill 86 217 336 86 232 336 minecraft:stripped_dark_oak_log
setblock 86 217 337 minecraft:shroomlight
fill 86 217 346 86 232 346 minecraft:stripped_dark_oak_log
fill 87 217 327 87 232 327 minecraft:stripped_dark_oak_log
setblock 87 217 328 minecraft:shroomlight
fill 87 217 329 87 232 329 minecraft:stripped_dark_oak_log
setblock 87 217 330 minecraft:shroomlight
fill 87 217 331 87 232 331 minecraft:stripped_dark_oak_log
setblock 87 217 332 minecraft:shroomlight
fill 87 217 333 87 232 333 minecraft:stripped_dark_oak_log
setblock 87 217 334 minecraft:shroomlight
fill 87 217 335 87 232 335 minecraft:stripped_dark_oak_log
setblock 87 217 336 minecraft:shroomlight
fill 87 217 337 87 232 337 minecraft:stripped_dark_oak_log
setblock 87 217 364 minecraft:dark_oak_planks
setblock 88 217 327 minecraft:shroomlight
fill 88 217 328 88 232 328 minecraft:stripped_dark_oak_log
setblock 88 217 329 minecraft:shroomlight
fill 88 217 330 88 232 330 minecraft:stripped_dark_oak_log
setblock 88 217 331 minecraft:shroomlight
fill 88 217 332 88 233 332 minecraft:stripped_dark_oak_log
setblock 88 217 333 minecraft:shroomlight
fill 88 217 334 88 269 334 minecraft:stripped_dark_oak_log
setblock 88 217 335 minecraft:shroomlight
fill 88 217 336 88 232 336 minecraft:stripped_dark_oak_log
setblock 88 217 337 minecraft:shroomlight
fill 88 217 341 88 269 341 minecraft:stripped_dark_oak_log
fill 88 217 355 88 269 355 minecraft:stripped_dark_oak_log
fill 89 217 324 89 219 325 minecraft:spruce_planks
setblock 89 217 326 minecraft:dark_oak_planks
fill 89 217 327 89 219 328 minecraft:spruce_planks
setblock 89 217 338 minecraft:spruce_planks
fill 89 217 341 89 219 341 minecraft:spruce_planks
fill 89 217 345 89 217 348 minecraft:spruce_planks
setblock 89 217 349 minecraft:dark_oak_planks
fill 89 217 350 89 219 350 minecraft:spruce_planks
fill 89 217 362 89 219 362 minecraft:spruce_planks
setblock 89 217 363 minecraft:dark_oak_planks
fill 89 217 364 89 219 364 minecraft:spruce_planks
fill 47 218 328 47 219 329 minecraft:spruce_planks
fill 47 218 331 47 219 332 minecraft:spruce_planks
setblock 47 218 333 minecraft:dark_oak_planks
fill 47 218 334 47 219 334 minecraft:spruce_planks
fill 47 218 336 47 219 336 minecraft:spruce_planks
fill 47 218 338 47 220 338 minecraft:spruce_planks
fill 47 218 341 47 219 341 minecraft:spruce_planks
fill 47 218 344 47 219 344 minecraft:spruce_planks
setblock 47 218 345 minecraft:dark_oak_planks
fill 47 218 346 47 219 346 minecraft:spruce_planks
fill 47 218 350 47 220 350 minecraft:spruce_planks
setblock 47 218 359 minecraft:dark_oak_planks
fill 47 218 361 47 219 361 minecraft:spruce_planks
setblock 47 218 363 minecraft:red_concrete
fill 48 218 322 48 219 322 minecraft:spruce_planks
setblock 48 218 329 minecraft:stripped_dark_oak_log
setblock 48 218 336 minecraft:stripped_dark_oak_log
setblock 48 218 343 minecraft:stripped_dark_oak_log
setblock 48 218 350 minecraft:stripped_dark_oak_log
setblock 48 218 357 minecraft:stripped_dark_oak_log
setblock 48 218 364 minecraft:dark_oak_planks
setblock 49 218 322 minecraft:dark_oak_planks
setblock 49 218 323 minecraft:stripped_dark_oak_log
setblock 49 218 363 minecraft:stripped_dark_oak_log
fill 49 218 364 49 220 364 minecraft:spruce_planks
fill 50 218 322 51 219 322 minecraft:spruce_planks
setblock 50 218 325 minecraft:light[level=15]
setblock 50 218 333 minecraft:light[level=15]
setblock 50 218 341 minecraft:light[level=15]
setblock 50 218 349 minecraft:light[level=15]
setblock 50 218 357 minecraft:light[level=15]
fill 52 218 364 53 218 364 minecraft:dark_oak_planks
setblock 56 218 323 minecraft:stripped_dark_oak_log
setblock 56 218 363 minecraft:stripped_dark_oak_log
setblock 57 218 364 minecraft:dark_oak_planks
fill 58 218 322 58 219 322 minecraft:spruce_planks
setblock 58 218 325 minecraft:light[level=15]
setblock 58 218 333 minecraft:light[level=15]
setblock 58 218 341 minecraft:light[level=15]
setblock 58 218 349 minecraft:light[level=15]
setblock 58 218 357 minecraft:light[level=15]
fill 58 218 364 58 219 364 minecraft:spruce_planks
setblock 59 218 322 minecraft:dark_oak_planks
fill 61 218 324 61 219 324 minecraft:stripped_dark_oak_log
fill 61 218 326 61 219 326 minecraft:stripped_dark_oak_log
fill 61 218 328 61 219 328 minecraft:stripped_dark_oak_log
fill 61 218 330 61 219 330 minecraft:stripped_dark_oak_log
fill 62 218 323 62 219 323 minecraft:stripped_dark_oak_log
fill 62 218 325 62 219 325 minecraft:stripped_dark_oak_log
fill 62 218 327 62 219 327 minecraft:stripped_dark_oak_log
fill 62 218 329 62 219 329 minecraft:stripped_dark_oak_log
fill 62 218 331 62 219 331 minecraft:stripped_dark_oak_log
fill 63 218 324 63 219 324 minecraft:stripped_dark_oak_log
fill 63 218 326 63 219 326 minecraft:stripped_dark_oak_log
fill 63 218 328 63 219 328 minecraft:stripped_dark_oak_log
fill 63 218 330 63 219 330 minecraft:stripped_dark_oak_log
setblock 63 218 363 minecraft:stripped_dark_oak_log
fill 64 218 323 64 219 323 minecraft:stripped_dark_oak_log
fill 64 218 325 64 219 325 minecraft:stripped_dark_oak_log
fill 64 218 327 64 219 327 minecraft:stripped_dark_oak_log
fill 64 218 329 64 219 329 minecraft:stripped_dark_oak_log
fill 64 218 331 64 219 331 minecraft:stripped_dark_oak_log
fill 65 218 324 65 219 324 minecraft:stripped_dark_oak_log
fill 65 218 326 65 219 326 minecraft:stripped_dark_oak_log
fill 65 218 328 65 219 328 minecraft:stripped_dark_oak_log
fill 65 218 330 65 219 330 minecraft:stripped_dark_oak_log
fill 65 218 364 65 220 364 minecraft:spruce_planks
fill 66 218 323 66 219 323 minecraft:stripped_dark_oak_log
fill 66 218 325 66 219 325 minecraft:stripped_dark_oak_log
fill 66 218 327 66 219 327 minecraft:stripped_dark_oak_log
fill 66 218 329 66 219 329 minecraft:stripped_dark_oak_log
fill 66 218 331 66 219 331 minecraft:stripped_dark_oak_log
setblock 66 218 333 minecraft:light[level=15]
setblock 66 218 341 minecraft:light[level=15]
setblock 66 218 349 minecraft:light[level=15]
setblock 66 218 357 minecraft:light[level=15]
fill 67 218 324 67 219 324 minecraft:stripped_dark_oak_log
fill 67 218 326 67 219 326 minecraft:stripped_dark_oak_log
fill 67 218 328 67 219 328 minecraft:stripped_dark_oak_log
fill 67 218 330 67 219 330 minecraft:stripped_dark_oak_log
fill 68 218 322 68 221 322 minecraft:spruce_planks
fill 68 218 323 68 219 323 minecraft:stripped_dark_oak_log
fill 68 218 325 68 219 325 minecraft:stripped_dark_oak_log
fill 68 218 327 68 219 327 minecraft:stripped_dark_oak_log
fill 68 218 329 68 219 329 minecraft:stripped_dark_oak_log
fill 68 218 331 68 219 331 minecraft:stripped_dark_oak_log
fill 69 218 324 69 219 324 minecraft:stripped_dark_oak_log
fill 69 218 326 69 219 326 minecraft:stripped_dark_oak_log
fill 69 218 328 69 219 328 minecraft:stripped_dark_oak_log
fill 69 218 330 69 219 330 minecraft:stripped_dark_oak_log
setblock 70 218 323 minecraft:stripped_dark_oak_log
setblock 70 218 363 minecraft:stripped_dark_oak_log
setblock 70 218 364 minecraft:dark_oak_planks
fill 71 218 322 71 219 322 minecraft:spruce_planks
setblock 72 218 322 minecraft:dark_oak_planks
setblock 74 218 325 minecraft:light[level=15]
setblock 74 218 333 minecraft:light[level=15]
setblock 74 218 341 minecraft:light[level=15]
setblock 74 218 349 minecraft:light[level=15]
setblock 74 218 357 minecraft:light[level=15]
fill 75 218 322 76 218 322 minecraft:dark_oak_planks
setblock 77 218 323 minecraft:stripped_dark_oak_log
setblock 77 218 363 minecraft:stripped_dark_oak_log
fill 79 218 328 79 219 328 minecraft:stripped_dark_oak_log
fill 79 218 330 79 219 330 minecraft:stripped_dark_oak_log
fill 79 218 332 79 219 332 minecraft:stripped_dark_oak_log
fill 79 218 334 79 219 334 minecraft:stripped_dark_oak_log
fill 79 218 336 79 219 336 minecraft:stripped_dark_oak_log
setblock 79 218 364 minecraft:dark_oak_planks
fill 80 218 327 80 219 327 minecraft:stripped_dark_oak_log
fill 80 218 329 80 219 329 minecraft:stripped_dark_oak_log
fill 80 218 331 80 219 331 minecraft:stripped_dark_oak_log
fill 80 218 333 80 219 333 minecraft:stripped_dark_oak_log
fill 80 218 335 80 219 335 minecraft:stripped_dark_oak_log
fill 80 218 337 80 219 337 minecraft:stripped_dark_oak_log
fill 81 218 328 81 219 328 minecraft:stripped_dark_oak_log
fill 81 218 330 81 219 330 minecraft:stripped_dark_oak_log
fill 81 218 332 81 219 332 minecraft:stripped_dark_oak_log
fill 81 218 334 81 219 334 minecraft:stripped_dark_oak_log
fill 81 218 336 81 219 336 minecraft:stripped_dark_oak_log
setblock 82 218 322 minecraft:dark_oak_planks
setblock 82 218 325 minecraft:light[level=15]
fill 82 218 327 82 219 327 minecraft:stripped_dark_oak_log
fill 82 218 329 82 219 329 minecraft:stripped_dark_oak_log
fill 82 218 331 82 219 331 minecraft:stripped_dark_oak_log
fill 82 218 333 82 219 333 minecraft:stripped_dark_oak_log
fill 82 218 335 82 219 335 minecraft:stripped_dark_oak_log
fill 82 218 337 82 219 337 minecraft:stripped_dark_oak_log
setblock 82 218 341 minecraft:light[level=15]
setblock 82 218 357 minecraft:light[level=15]
fill 83 218 322 83 219 322 minecraft:spruce_planks
fill 83 218 328 83 219 328 minecraft:stripped_dark_oak_log
fill 83 218 330 83 219 330 minecraft:stripped_dark_oak_log
fill 83 218 332 83 219 332 minecraft:stripped_dark_oak_log
fill 83 218 334 83 219 334 minecraft:stripped_dark_oak_log
fill 83 218 336 83 219 336 minecraft:stripped_dark_oak_log
schedule function dropper:buildpart/73_4 1t
