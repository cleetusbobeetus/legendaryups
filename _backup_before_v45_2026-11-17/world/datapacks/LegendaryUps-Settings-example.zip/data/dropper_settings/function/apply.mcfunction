scoreboard players set #hudmode dp_cfg 0
scoreboard players set #hudrate dp_cfg 10
scoreboard players set #hudtheme dp_cfg 0
scoreboard players set #hud_level dp_cfg 1
scoreboard players set #hud_stage dp_cfg 0
scoreboard players set #hud_deaths dp_cfg 1
scoreboard players set #hud_diff dp_cfg 0
scoreboard players set #hud_time dp_cfg 0
scoreboard players set #notify dp_cfg 1
scoreboard players set #notifyticks dp_cfg 30
scoreboard players set #bosstitles dp_cfg 0
scoreboard players set #milestones dp_cfg 1
scoreboard players set #attrib dp_cfg 1
scoreboard players set #evchat dp_cfg 0
scoreboard players set #startlevel dp_cfg 1
scoreboard players set #unlock dp_cfg 103
scoreboard players set #order dp_cfg 0
scoreboard players set #practice dp_cfg 0
scoreboard players set #aftermode dp_cfg 1
scoreboard players set #hardcore dp_cfg 0
scoreboard players set #failpenalty dp_cfg 0
scoreboard players set #cpmode dp_cfg 0
scoreboard players set #allowskip dp_cfg 1
scoreboard players set #negative dp_cfg 1
scoreboard players set #negmin dp_cfg -50
scoreboard players set #speedrun dp_cfg 0
scoreboard players set #events dp_cfg 1
scoreboard players set #evmax dp_cfg 6
scoreboard players set #evlock dp_cfg 20
scoreboard players set #clearfx dp_cfg 1
scoreboard players set #deathfx dp_cfg 1
scoreboard players set #like_goal dp_cfg 500
scoreboard players set #combo_min dp_cfg 10
scoreboard players set #hazards dp_cfg 1
scoreboard players set #hz_fan dp_cfg 1
scoreboard players set #hz_ring dp_cfg 1
scoreboard players set #hz_slider dp_cfg 1
scoreboard players set #hz_deco dp_cfg 1
scoreboard players set #hzslow dp_cfg 1
scoreboard players set #bossmode dp_cfg 0
scoreboard players set #respawn dp_cfg 0
scoreboard players set #particles dp_cfg 2
scoreboard players set #streakmsg dp_cfg 1
scoreboard players set #milestonefx dp_cfg 1
scoreboard players set #perfsafe dp_cfg 0
scoreboard players set #platform dp_cfg 0
scoreboard players set #platlast dp_cfg 1
scoreboard players set #plat_w dp_cfg 9
scoreboard players set #plat_d dp_cfg 5
scoreboard players set #plat_mat dp_cfg 0
scoreboard players set #plat_rail dp_cfg 1
scoreboard players set #plat_light dp_cfg 1
scoreboard players set #platcount dp_cfg 1
scoreboard players set #platjumpfx dp_cfg 1
scoreboard players set #chat dp_cfg 1
scoreboard players set #chatlines dp_cfg 8
scoreboard players set #chatmax dp_cfg 60
scoreboard players set #chatscale dp_cfg 12
scoreboard players set #chatwidth dp_cfg 260
scoreboard players set #chatbg dp_cfg 160
scoreboard players set #chatalign dp_cfg 0
scoreboard players set #chatface dp_cfg 0
scoreboard players set #chaty dp_cfg 0
scoreboard players set #chatrate dp_cfg 10
scoreboard players set #chatgifts dp_cfg 1
scoreboard players set #chatfollows dp_cfg 1
scoreboard players set #chatsubs dp_cfg 1
scoreboard players set #chatonly dp_cfg 0
scoreboard players set #chatticker dp_cfg 1
scoreboard players set #chattheme dp_cfg 0
scoreboard players set #chathud dp_cfg 0
scoreboard players set #chathudlines dp_cfg 5
scoreboard players set #chathudsec dp_cfg 8
scoreboard players set #chathudcolor dp_cfg 0
scoreboard players set #chatfont dp_cfg 0
scoreboard players set #chatshadow dp_cfg 1
scoreboard players set #hz_pendulum dp_cfg 1
scoreboard players set #hz_crusher dp_cfg 1
scoreboard players set #hz_piston dp_cfg 1
scoreboard players set #hz_gear dp_cfg 1
data modify storage dropper:events follow set value {on:1,n:1,dur:3,cd:20,prio:1,max:3,notify:1,act:"fireworks",msg:""}
data modify storage dropper:events share set value {on:1,n:1,dur:3,cd:40,prio:2,max:2,notify:1,act:"down",msg:""}
data modify storage dropper:events sub set value {on:1,n:1,dur:5,cd:100,prio:6,max:1,notify:1,act:"boss",msg:""}
data modify storage dropper:events like_goal set value {on:1,n:1,dur:8,cd:0,prio:2,max:1,notify:1,act:"assist",msg:""}
data modify storage dropper:events combo set value {on:1,n:5,dur:5,cd:60,prio:5,max:1,notify:1,act:"down",msg:""}
data modify storage dropper:events gift_small set value {on:1,n:1,dur:2,cd:0,prio:2,max:10,notify:1,act:"down",msg:""}
data modify storage dropper:events gift_medium set value {on:1,n:3,dur:3,cd:0,prio:3,max:5,notify:1,act:"down",msg:""}
data modify storage dropper:events gift_large set value {on:1,n:1,dur:5,cd:100,prio:7,max:1,notify:1,act:"abyss",msg:""}
data modify storage dropper:events gift_huge set value {on:1,n:1,dur:60,cd:200,prio:8,max:1,notify:1,act:"hardcore",msg:""}
data modify storage dropper:events gift_help set value {on:1,n:1,dur:3,cd:20,prio:4,max:3,notify:1,act:"up",msg:""}
data modify storage dropper:events chat_up set value {on:0,n:1,dur:2,cd:200,prio:1,max:1,notify:1,act:"up",msg:""}
data modify storage dropper:events chat_down set value {on:0,n:1,dur:2,cd:200,prio:1,max:1,notify:1,act:"down",msg:""}
data modify storage dropper:events chat_storm set value {on:0,n:1,dur:2,cd:100,prio:1,max:1,notify:1,act:"lightning",msg:""}
data modify storage dropper:events custom1 set value {on:1,n:1,dur:6,cd:0,prio:3,max:2,notify:1,act:"slow",msg:""}
data modify storage dropper:events custom2 set value {on:1,n:1,dur:6,cd:0,prio:4,max:1,notify:1,act:"heavy",msg:""}
data modify storage dropper:events custom3 set value {on:1,n:1,dur:6,cd:0,prio:3,max:1,notify:1,act:"darkness",msg:""}
data modify storage dropper:events custom4 set value {on:1,n:1,dur:3,cd:60,prio:5,max:1,notify:1,act:"random",msg:""}
data modify storage dropper:events custom5 set value {on:1,n:1,dur:3,cd:60,prio:5,max:1,notify:1,act:"checkpoint",msg:""}
data modify storage dropper:events custom6 set value {on:1,n:1,dur:2,cd:0,prio:2,max:2,notify:1,act:"updraft",msg:""}
data modify storage dropper:events custom7 set value {on:1,n:1,dur:8,cd:0,prio:2,max:1,notify:1,act:"nausea",msg:""}
data modify storage dropper:events custom8 set value {on:1,n:1,dur:3,cd:0,prio:1,max:3,notify:1,act:"announce",msg:"Thank you for the support!"}
