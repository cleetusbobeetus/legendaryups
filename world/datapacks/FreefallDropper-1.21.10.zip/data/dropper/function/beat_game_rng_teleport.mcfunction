execute as @a[scores={dp_level=103}] in minecraft:dropperrng_room run teleport @s 100.5 70 100.5 facing 0 0 0
execute as @a[scores={dp_level=103}] run function dropper:beat_game_rng_stats
