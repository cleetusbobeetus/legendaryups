$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
execute as @a[tag=dp_play] at @s run particle minecraft:firework ~ ~1 ~ 2 2 2 0.2 50 force
execute as @a[tag=dp_play] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.8 1
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 run scoreboard players set @a[tag=dp_play,tag=!dp_no_fireworks] dp_notek 122
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 as @a[tag=dp_play,tag=!dp_no_fireworks] run function dropper:hud/notify
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 1 run function dropper:note/act_fireworks
