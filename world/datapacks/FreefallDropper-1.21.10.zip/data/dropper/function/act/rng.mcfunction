$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
execute as @a[tag=dp_play,tag=!dp_no_rng] at @s run function dropper:act/do_rng
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 run scoreboard players set @a[tag=dp_play,tag=!dp_no_rng] dp_notek 126
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 as @a[tag=dp_play,tag=!dp_no_rng] run function dropper:hud/notify
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 1 run function dropper:note/act_rng
