$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
execute as @a[tag=dp_play] at @s run particle minecraft:electric_spark ~ ~1 ~ 2 2 2 0.5 60 force
execute as @a[tag=dp_play] at @s run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.7 1.2
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 run scoreboard players set @a[tag=dp_play,tag=!dp_no_lightning] dp_notek 121
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 as @a[tag=dp_play,tag=!dp_no_lightning] run function dropper:hud/notify
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 1 run function dropper:note/act_lightning
