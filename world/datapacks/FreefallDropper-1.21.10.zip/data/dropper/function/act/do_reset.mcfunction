scoreboard players operation @s dp_plevel = @s dp_level
scoreboard players operation @s dp_level = #startlevel dp_cfg
scoreboard players set @s dp_dir -1
function dropper:move/apply
