$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
execute unless score #hc_temp dp_ev matches 1 run scoreboard players operation #hc_saved dp_ev = #hardcore dp_cfg
scoreboard players set #hc_temp dp_ev 1
scoreboard players set #hardcore dp_cfg 1
$schedule function dropper:act/hardcore_end $(dur)s
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 run scoreboard players set @a[tag=dp_play,tag=!dp_no_hardcore] dp_notek 123
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 as @a[tag=dp_play,tag=!dp_no_hardcore] run function dropper:hud/notify
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 1 run function dropper:note/act_hardcore
