$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
$execute if score #arg_n dp_ev matches ..1 run effect give @a[tag=dp_play] minecraft:speed $(dur) 0 true
$execute if score #arg_n dp_ev matches 2 run effect give @a[tag=dp_play] minecraft:speed $(dur) 1 true
$execute if score #arg_n dp_ev matches 3.. run effect give @a[tag=dp_play] minecraft:speed $(dur) 2 true
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 run scoreboard players set @a[tag=dp_play,tag=!dp_no_speed] dp_notek 115
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 0 as @a[tag=dp_play,tag=!dp_no_speed] run function dropper:hud/notify
execute if score #evnotify dp_ev matches 1 if score #notestyle dp_cfg matches 1 run function dropper:note/act_speed
