execute if score #particles dp_cfg matches 1 run particle minecraft:poof ~ ~1 ~ 0.6 0.6 0.6 0.05 8 force
execute if score #particles dp_cfg matches 2 run particle minecraft:poof ~ ~1 ~ 1 1 1 0.05 20 force
execute if score #particles dp_cfg matches 3 run particle minecraft:poof ~ ~1 ~ 1 1 1 0.08 40 force
execute if score #particles dp_cfg matches 3 run particle minecraft:electric_spark ~ ~1 ~ 1 1 1 0.3 20 force
playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
