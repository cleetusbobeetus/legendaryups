fill 88 279 503 88 280 504 minecraft:white_concrete
setblock 64 280 479 minecraft:white_concrete
fill 64 280 480 64 280 484 minecraft:sea_lantern
fill 64 280 485 64 280 487 minecraft:white_concrete
fill 65 280 479 65 280 480 minecraft:sea_lantern
fill 65 280 484 65 280 485 minecraft:sea_lantern
fill 65 280 486 66 280 487 minecraft:white_concrete
fill 66 280 479 69 280 479 minecraft:sea_lantern
fill 66 280 485 69 280 485 minecraft:sea_lantern
fill 67 280 486 69 280 487 minecraft:quartz_block
fill 69 280 480 70 280 480 minecraft:sea_lantern
fill 69 280 484 70 280 484 minecraft:sea_lantern
fill 70 280 479 72 280 479 minecraft:white_concrete
fill 70 280 481 70 280 483 minecraft:sea_lantern
fill 71 280 480 72 280 481 minecraft:white_concrete
fill 71 280 482 72 280 484 minecraft:quartz_block
fill 47 284 468 47 289 468 minecraft:sea_lantern
fill 47 284 476 47 289 476 minecraft:sea_lantern
fill 47 284 484 47 289 484 minecraft:sea_lantern
fill 47 284 492 47 289 492 minecraft:sea_lantern
fill 47 284 500 47 289 500 minecraft:sea_lantern
fill 48 284 470 48 300 471 minecraft:quartz_block
fill 48 284 478 48 300 479 minecraft:quartz_block
fill 48 284 486 48 300 487 minecraft:quartz_block
fill 48 284 494 48 300 495 minecraft:quartz_block
fill 48 284 502 48 300 503 minecraft:quartz_block
fill 49 284 464 50 300 464 minecraft:quartz_block
fill 50 284 505 50 289 505 minecraft:sea_lantern
fill 54 284 463 54 289 463 minecraft:sea_lantern
fill 54 284 504 55 300 504 minecraft:quartz_block
fill 57 284 464 58 300 464 minecraft:quartz_block
fill 58 284 505 58 289 505 minecraft:sea_lantern
fill 62 284 463 62 289 463 minecraft:sea_lantern
fill 62 284 504 63 300 504 minecraft:quartz_block
fill 65 284 464 66 300 464 minecraft:quartz_block
fill 66 284 505 66 289 505 minecraft:sea_lantern
fill 70 284 463 70 289 463 minecraft:sea_lantern
fill 70 284 504 71 300 504 minecraft:quartz_block
fill 73 284 464 74 300 464 minecraft:quartz_block
fill 74 284 505 74 289 505 minecraft:sea_lantern
fill 78 284 463 78 289 463 minecraft:sea_lantern
fill 78 284 504 79 300 504 minecraft:quartz_block
fill 81 284 464 82 300 464 minecraft:quartz_block
fill 82 284 505 82 289 505 minecraft:sea_lantern
fill 83 284 473 83 284 479 minecraft:black_concrete
setblock 83 284 499 minecraft:gray_concrete
fill 83 284 500 86 300 500 minecraft:quartz_block
fill 83 284 501 83 284 502 minecraft:gray_concrete
fill 84 284 480 88 284 485 minecraft:quartz_block
fill 84 284 498 86 284 498 minecraft:gray_concrete
fill 84 284 499 86 300 499 minecraft:quartz_block
fill 84 284 501 86 300 501 minecraft:quartz_block
fill 84 284 502 86 284 502 minecraft:gray_concrete
fill 85 284 486 88 285 486 minecraft:quartz_block
fill 86 284 463 86 289 463 minecraft:sea_lantern
fill 86 284 504 87 300 504 minecraft:quartz_block
fill 87 284 479 88 284 479 minecraft:quartz_block
fill 87 284 499 87 284 501 minecraft:gray_concrete
fill 88 284 465 88 300 466 minecraft:quartz_block
fill 88 284 473 88 300 474 minecraft:quartz_block
fill 88 284 489 88 300 490 minecraft:quartz_block
fill 88 284 497 88 300 498 minecraft:quartz_block
fill 89 284 468 89 289 468 minecraft:sea_lantern
fill 89 284 476 89 289 476 minecraft:sea_lantern
fill 89 284 484 89 289 484 minecraft:sea_lantern
fill 89 284 492 89 289 492 minecraft:sea_lantern
fill 89 284 500 89 289 500 minecraft:sea_lantern
fill 83 285 478 83 285 483 minecraft:black_concrete
fill 84 285 484 84 285 490 minecraft:quartz_block
fill 85 285 484 88 285 485 minecraft:quartz_block
fill 85 285 487 87 285 490 minecraft:quartz_block
fill 87 285 491 88 286 491 minecraft:quartz_block
fill 88 285 481 88 300 482 minecraft:quartz_block
fill 88 285 487 88 285 488 minecraft:quartz_block
fill 83 286 482 83 286 487 minecraft:black_concrete
fill 84 286 488 86 286 495 minecraft:quartz_block
fill 86 286 496 88 287 496 minecraft:quartz_block
fill 87 286 489 87 286 490 minecraft:quartz_block
fill 87 286 492 88 286 495 minecraft:quartz_block
fill 87 286 497 87 287 497 minecraft:quartz_block
setblock 50 287 466 minecraft:light[level=14]
setblock 50 287 474 minecraft:light[level=14]
setblock 50 287 482 minecraft:light[level=14]
setblock 50 287 490 minecraft:light[level=14]
setblock 50 287 498 minecraft:light[level=14]
setblock 58 287 466 minecraft:light[level=14]
setblock 58 287 474 minecraft:light[level=14]
setblock 58 287 482 minecraft:light[level=14]
setblock 58 287 490 minecraft:light[level=14]
setblock 58 287 498 minecraft:light[level=14]
setblock 66 287 466 minecraft:light[level=14]
setblock 66 287 474 minecraft:light[level=14]
setblock 66 287 490 minecraft:light[level=14]
setblock 66 287 498 minecraft:light[level=14]
fill 72 287 501 72 288 503 minecraft:iron_block
setblock 74 287 466 minecraft:light[level=14]
setblock 74 287 474 minecraft:light[level=14]
setblock 74 287 482 minecraft:light[level=14]
setblock 74 287 490 minecraft:light[level=14]
setblock 74 287 498 minecraft:light[level=14]
setblock 82 287 466 minecraft:light[level=14]
setblock 82 287 474 minecraft:light[level=14]
setblock 82 287 482 minecraft:light[level=14]
setblock 82 287 490 minecraft:light[level=14]
setblock 82 287 498 minecraft:light[level=14]
fill 83 287 486 83 287 491 minecraft:black_concrete
fill 84 287 492 84 287 498 minecraft:quartz_block
fill 84 287 502 88 288 502 minecraft:quartz_block
fill 85 287 493 85 287 498 minecraft:quartz_block
fill 85 287 503 88 288 503 minecraft:quartz_block
fill 86 287 493 86 287 495 minecraft:quartz_block
fill 86 287 497 86 287 498 minecraft:quartz_block
fill 87 287 494 88 287 495 minecraft:quartz_block
fill 87 287 498 87 287 501 minecraft:quartz_block
fill 88 287 499 88 287 501 minecraft:quartz_block
fill 88 287 504 88 288 504 minecraft:quartz_block
fill 77 288 500 82 288 501 minecraft:quartz_block
fill 78 288 502 83 288 503 minecraft:quartz_block
fill 80 288 504 85 288 504 minecraft:quartz_block
fill 83 288 489 83 288 496 minecraft:black_concrete
setblock 83 288 501 minecraft:quartz_block
setblock 84 288 498 minecraft:quartz_block
setblock 84 288 503 minecraft:quartz_block
fill 87 288 501 88 288 501 minecraft:quartz_block
fill 72 289 500 79 289 500 minecraft:quartz_block
fill 73 289 501 77 289 504 minecraft:quartz_block
fill 78 289 501 80 289 503 minecraft:quartz_block
fill 79 289 499 83 289 499 minecraft:black_concrete
fill 80 289 504 82 289 504 minecraft:quartz_block
fill 81 289 502 81 289 503 minecraft:quartz_block
fill 83 289 494 83 289 498 minecraft:black_concrete
fill 47 290 468 47 297 468 minecraft:white_concrete
fill 47 290 476 47 297 476 minecraft:white_concrete
fill 47 290 484 47 297 484 minecraft:white_concrete
fill 47 290 492 47 297 492 minecraft:white_concrete
fill 47 290 500 47 297 500 minecraft:white_concrete
fill 50 290 505 50 297 505 minecraft:white_concrete
fill 54 290 463 54 297 463 minecraft:white_concrete
fill 58 290 505 58 297 505 minecraft:white_concrete
fill 62 290 463 62 297 463 minecraft:white_concrete
fill 66 290 505 66 297 505 minecraft:white_concrete
fill 68 290 500 69 291 504 minecraft:quartz_block
fill 70 290 463 70 297 463 minecraft:white_concrete
fill 70 290 500 74 290 503 minecraft:quartz_block
fill 72 290 504 76 290 504 minecraft:quartz_block
fill 74 290 505 74 297 505 minecraft:white_concrete
fill 75 290 499 82 290 499 minecraft:black_concrete
fill 75 290 502 75 290 503 minecraft:quartz_block
fill 78 290 463 78 297 463 minecraft:white_concrete
fill 82 290 505 82 297 505 minecraft:white_concrete
fill 86 290 463 86 297 463 minecraft:white_concrete
fill 89 290 468 89 297 468 minecraft:white_concrete
fill 89 290 476 89 297 476 minecraft:white_concrete
fill 89 290 484 89 297 484 minecraft:white_concrete
fill 89 290 492 89 297 492 minecraft:white_concrete
fill 89 290 500 89 297 500 minecraft:white_concrete
fill 64 291 501 67 291 504 minecraft:quartz_block
fill 65 291 500 67 291 500 minecraft:quartz_block
fill 70 291 500 70 291 503 minecraft:quartz_block
fill 71 291 499 76 291 499 minecraft:black_concrete
fill 58 292 504 61 292 504 minecraft:quartz_block
fill 59 292 502 66 292 503 minecraft:quartz_block
fill 60 292 500 66 292 501 minecraft:quartz_block
fill 64 292 504 66 292 504 minecraft:quartz_block
fill 67 292 499 72 292 499 minecraft:black_concrete
setblock 83 292 499 minecraft:gray_concrete
fill 83 292 501 83 292 502 minecraft:gray_concrete
fill 84 292 498 86 292 498 minecraft:gray_concrete
fill 84 292 502 86 292 502 minecraft:gray_concrete
fill 87 292 499 87 292 501 minecraft:gray_concrete
fill 51 293 504 53 295 504 minecraft:quartz_block
fill 52 293 503 61 294 503 minecraft:quartz_block
fill 53 293 501 61 293 502 minecraft:quartz_block
fill 54 293 500 62 293 500 minecraft:quartz_block
fill 56 293 504 60 295 504 minecraft:quartz_block
setblock 62 293 501 minecraft:quartz_block
fill 63 293 499 68 293 499 minecraft:black_concrete
fill 81 293 503 83 294 504 minecraft:quartz_block
fill 83 293 464 83 295 464 minecraft:quartz_block
fill 48 294 464 48 295 469 minecraft:quartz_block
fill 48 294 472 49 294 477 minecraft:quartz_block
fill 48 294 480 49 294 485 minecraft:quartz_block
fill 48 294 488 49 294 493 minecraft:quartz_block
fill 48 294 496 49 295 501 minecraft:quartz_block
fill 48 294 504 50 295 504 minecraft:quartz_block
fill 49 294 465 49 294 471 minecraft:quartz_block
fill 49 294 478 49 294 479 minecraft:quartz_block
fill 49 294 486 49 294 487 minecraft:quartz_block
fill 49 294 494 49 295 495 minecraft:quartz_block
fill 49 294 502 51 294 503 minecraft:quartz_block
fill 50 294 465 87 294 465 minecraft:quartz_block
fill 50 294 497 52 294 501 minecraft:quartz_block
fill 51 294 464 56 295 464 minecraft:quartz_block
fill 51 294 496 52 295 496 minecraft:quartz_block
fill 52 294 502 56 294 502 minecraft:quartz_block
fill 53 294 500 56 294 501 minecraft:quartz_block
setblock 57 294 500 minecraft:quartz_block
fill 59 294 464 64 295 464 minecraft:quartz_block
fill 59 294 499 65 294 499 minecraft:black_concrete
fill 61 294 504 61 295 504 minecraft:quartz_block
fill 62 294 503 80 294 503 minecraft:quartz_block
fill 64 294 504 69 295 504 minecraft:quartz_block
fill 67 294 464 72 295 464 minecraft:quartz_block
fill 72 294 504 77 295 504 minecraft:quartz_block
fill 75 294 464 80 295 464 minecraft:quartz_block
fill 80 294 504 80 295 504 minecraft:quartz_block
fill 81 294 502 83 295 502 minecraft:quartz_block
fill 82 294 466 82 296 466 minecraft:quartz_block
fill 82 294 501 82 296 501 minecraft:quartz_block
fill 84 294 464 88 295 464 minecraft:quartz_block
fill 84 294 503 85 294 504 minecraft:quartz_block
fill 86 294 503 88 294 503 minecraft:quartz_block
fill 87 294 466 87 294 502 minecraft:quartz_block
fill 88 294 467 88 295 472 minecraft:quartz_block
fill 88 294 475 88 295 480 minecraft:quartz_block
fill 88 294 483 88 295 488 minecraft:quartz_block
fill 88 294 491 88 295 496 minecraft:quartz_block
fill 88 294 499 88 295 502 minecraft:quartz_block
fill 88 294 504 88 295 504 minecraft:quartz_block
fill 48 295 472 48 295 477 minecraft:quartz_block
fill 48 295 480 48 295 485 minecraft:quartz_block
fill 48 295 488 48 296 493 minecraft:quartz_block
fill 49 295 492 52 295 493 minecraft:quartz_block
setblock 50 295 466 minecraft:light[level=14]
setblock 50 295 474 minecraft:light[level=14]
setblock 50 295 482 minecraft:light[level=14]
setblock 50 295 490 minecraft:light[level=14]
fill 50 295 491 52 296 491 minecraft:quartz_block
fill 50 295 494 50 295 500 minecraft:quartz_block
fill 51 295 494 52 295 495 minecraft:quartz_block
fill 51 295 497 51 295 499 minecraft:quartz_block
fill 52 295 497 52 295 498 minecraft:quartz_block
fill 53 295 498 53 296 499 minecraft:black_concrete
fill 54 295 499 61 295 499 minecraft:black_concrete
setblock 58 295 466 minecraft:light[level=14]
setblock 58 295 474 minecraft:light[level=14]
setblock 58 295 482 minecraft:light[level=14]
setblock 58 295 490 minecraft:light[level=14]
setblock 58 295 498 minecraft:light[level=14]
setblock 66 295 466 minecraft:light[level=14]
setblock 66 295 474 minecraft:light[level=14]
setblock 66 295 482 minecraft:light[level=14]
setblock 66 295 490 minecraft:light[level=14]
setblock 66 295 498 minecraft:light[level=14]
setblock 74 295 466 minecraft:light[level=14]
setblock 74 295 474 minecraft:light[level=14]
setblock 74 295 482 minecraft:light[level=14]
setblock 74 295 490 minecraft:light[level=14]
setblock 74 295 498 minecraft:light[level=14]
fill 81 295 465 81 295 466 minecraft:quartz_block
fill 81 295 501 81 296 501 minecraft:quartz_block
fill 81 295 504 85 295 504 minecraft:quartz_block
fill 82 295 465 83 295 465 minecraft:quartz_block
fill 82 295 467 82 297 467 minecraft:quartz_block
setblock 82 295 474 minecraft:light[level=14]
setblock 82 295 482 minecraft:light[level=14]
setblock 82 295 490 minecraft:light[level=14]
setblock 82 295 498 minecraft:light[level=14]
fill 82 295 500 82 297 500 minecraft:quartz_block
setblock 82 295 503 minecraft:quartz_block
fill 83 295 466 83 296 466 minecraft:quartz_block
fill 83 295 501 83 296 501 minecraft:quartz_block
setblock 88 295 503 minecraft:quartz_block
fill 49 296 487 49 296 494 minecraft:quartz_block
fill 50 296 487 52 296 490 minecraft:quartz_block
fill 50 296 492 50 296 494 minecraft:quartz_block
fill 51 296 492 51 296 493 minecraft:quartz_block
fill 52 296 486 52 297 486 minecraft:quartz_block
setblock 52 296 492 minecraft:quartz_block
fill 53 296 493 53 296 497 minecraft:black_concrete
fill 54 296 499 55 296 499 minecraft:black_concrete
fill 81 296 466 81 296 468 minecraft:quartz_block
fill 81 296 499 81 297 500 minecraft:quartz_block
setblock 82 296 465 minecraft:quartz_block
fill 82 296 468 83 297 468 minecraft:quartz_block
fill 82 296 499 83 297 499 minecraft:quartz_block
setblock 82 296 502 minecraft:quartz_block
setblock 82 296 503 minecraft:black_concrete
fill 83 296 467 83 297 467 minecraft:quartz_block
fill 48 297 482 51 297 485 minecraft:quartz_block
fill 48 297 488 49 297 489 minecraft:quartz_block
fill 49 297 486 51 297 487 minecraft:quartz_block
fill 50 297 488 52 297 488 minecraft:quartz_block
fill 52 297 483 52 297 485 minecraft:quartz_block
setblock 52 297 487 minecraft:quartz_block
fill 53 297 489 53 297 495 minecraft:black_concrete
fill 81 297 467 81 297 469 minecraft:quartz_block
fill 81 297 498 83 298 498 minecraft:quartz_block
setblock 82 297 466 minecraft:black_concrete
fill 82 297 469 82 299 470 minecraft:quartz_block
fill 82 297 497 82 299 497 minecraft:quartz_block
setblock 82 297 501 minecraft:black_concrete
fill 83 297 469 83 298 469 minecraft:quartz_block
fill 47 298 468 47 300 468 minecraft:sea_lantern
fill 47 298 476 47 300 476 minecraft:sea_lantern
fill 47 298 484 47 300 484 minecraft:sea_lantern
fill 47 298 492 47 300 492 minecraft:sea_lantern
fill 47 298 500 47 300 500 minecraft:sea_lantern
fill 48 298 477 49 299 477 minecraft:quartz_block
fill 48 298 480 52 298 484 minecraft:quartz_block
fill 49 298 478 52 299 479 minecraft:quartz_block
fill 50 298 505 50 300 505 minecraft:sea_lantern
fill 53 298 485 53 298 490 minecraft:black_concrete
fill 54 298 463 54 300 463 minecraft:sea_lantern
fill 58 298 505 58 300 505 minecraft:sea_lantern
fill 62 298 463 62 300 463 minecraft:sea_lantern
fill 66 298 505 66 300 505 minecraft:sea_lantern
fill 70 298 463 70 300 463 minecraft:sea_lantern
fill 74 298 505 74 300 505 minecraft:sea_lantern
fill 78 298 463 78 300 463 minecraft:sea_lantern
fill 81 298 469 81 298 470 minecraft:quartz_block
fill 81 298 497 81 299 497 minecraft:quartz_block
setblock 82 298 467 minecraft:black_concrete
setblock 82 298 468 minecraft:quartz_block
fill 82 298 471 82 300 471 minecraft:quartz_block
fill 82 298 496 82 300 496 minecraft:quartz_block
setblock 82 298 499 minecraft:quartz_block
setblock 82 298 500 minecraft:black_concrete
fill 82 298 505 82 300 505 minecraft:sea_lantern
fill 83 298 470 83 299 470 minecraft:quartz_block
fill 83 298 497 83 299 497 minecraft:quartz_block
fill 86 298 463 86 300 463 minecraft:sea_lantern
fill 89 298 468 89 300 468 minecraft:sea_lantern
fill 89 298 476 89 300 476 minecraft:sea_lantern
fill 89 298 484 89 300 484 minecraft:sea_lantern
fill 89 298 492 89 300 492 minecraft:sea_lantern
fill 89 298 500 89 300 500 minecraft:sea_lantern
fill 48 299 472 50 299 476 minecraft:quartz_block
fill 49 299 471 49 300 471 minecraft:quartz_block
fill 50 299 477 52 299 477 minecraft:quartz_block
fill 50 299 480 52 299 480 minecraft:quartz_block
fill 51 299 473 52 299 476 minecraft:quartz_block
fill 53 299 481 53 299 486 minecraft:black_concrete
fill 81 299 470 81 299 472 minecraft:quartz_block
fill 81 299 495 81 299 496 minecraft:quartz_block
setblock 82 299 468 minecraft:black_concrete
fill 82 299 472 82 300 473 minecraft:quartz_block
fill 82 299 494 82 300 495 minecraft:quartz_block
setblock 82 299 498 minecraft:quartz_block
fill 82 299 499 83 299 499 minecraft:black_concrete
fill 83 299 471 83 299 472 minecraft:quartz_block
fill 83 299 495 83 299 496 minecraft:quartz_block
fill 83 299 501 83 300 501 minecraft:black_concrete
fill 84 299 498 85 300 498 minecraft:black_concrete
fill 84 299 502 86 300 502 minecraft:black_concrete
fill 87 299 500 87 300 500 minecraft:black_concrete
fill 48 300 464 48 300 469 minecraft:quartz_block
fill 48 300 472 52 300 474 minecraft:quartz_block
fill 49 300 465 51 300 470 minecraft:quartz_block
fill 50 300 471 52 300 471 minecraft:quartz_block
fill 50 300 475 52 300 475 minecraft:quartz_block
fill 52 300 466 52 300 470 minecraft:quartz_block
setblock 52 300 476 minecraft:quartz_block
setblock 53 300 468 minecraft:quartz_block
fill 53 300 477 53 300 482 minecraft:black_concrete
fill 81 300 472 81 300 474 minecraft:quartz_block
fill 81 300 493 81 300 495 minecraft:quartz_block
setblock 82 300 470 minecraft:black_concrete
fill 82 300 474 82 300 475 minecraft:quartz_block
fill 82 300 492 82 300 493 minecraft:quartz_block
setblock 82 300 497 minecraft:black_concrete
fill 83 300 472 83 300 474 minecraft:quartz_block
fill 83 300 493 83 300 495 minecraft:quartz_block
setblock 83 300 499 minecraft:black_concrete
fill 47 301 468 47 307 468 minecraft:white_concrete
fill 47 301 476 47 307 476 minecraft:white_concrete
fill 47 301 484 47 307 484 minecraft:white_concrete
fill 47 301 492 47 307 492 minecraft:white_concrete
fill 47 301 500 47 307 500 minecraft:white_concrete
fill 50 301 505 50 307 505 minecraft:white_concrete
fill 54 301 463 54 307 463 minecraft:white_concrete
fill 58 301 505 58 307 505 minecraft:white_concrete
fill 62 301 463 62 307 463 minecraft:white_concrete
fill 66 301 505 66 307 505 minecraft:white_concrete
fill 70 301 463 70 307 463 minecraft:white_concrete
fill 74 301 505 74 307 505 minecraft:white_concrete
fill 78 301 463 78 307 463 minecraft:white_concrete
fill 82 301 505 82 307 505 minecraft:white_concrete
fill 86 301 463 86 307 463 minecraft:white_concrete
fill 89 301 468 89 307 468 minecraft:white_concrete
fill 89 301 476 89 307 476 minecraft:white_concrete
fill 89 301 484 89 307 484 minecraft:white_concrete
fill 89 301 492 89 307 492 minecraft:white_concrete
fill 89 301 500 89 307 500 minecraft:white_concrete
setblock 50 303 466 minecraft:light[level=14]
setblock 50 303 474 minecraft:light[level=14]
setblock 50 303 482 minecraft:light[level=14]
setblock 50 303 490 minecraft:light[level=14]
setblock 50 303 498 minecraft:light[level=14]
setblock 58 303 466 minecraft:light[level=14]
setblock 58 303 474 minecraft:light[level=14]
setblock 58 303 482 minecraft:light[level=14]
setblock 58 303 490 minecraft:light[level=14]
setblock 58 303 498 minecraft:light[level=14]
setblock 66 303 466 minecraft:light[level=14]
setblock 66 303 474 minecraft:light[level=14]
setblock 66 303 482 minecraft:light[level=14]
setblock 66 303 490 minecraft:light[level=14]
setblock 66 303 498 minecraft:light[level=14]
setblock 74 303 466 minecraft:light[level=14]
setblock 74 303 474 minecraft:light[level=14]
setblock 74 303 482 minecraft:light[level=14]
setblock 74 303 490 minecraft:light[level=14]
setblock 74 303 498 minecraft:light[level=14]
setblock 82 303 466 minecraft:light[level=14]
setblock 82 303 474 minecraft:light[level=14]
setblock 82 303 482 minecraft:light[level=14]
setblock 82 303 490 minecraft:light[level=14]
setblock 82 303 498 minecraft:light[level=14]
