fill 415 169 565 417 170 565 minecraft:purple_terracotta
fill 415 169 566 415 170 566 minecraft:black_concrete
fill 415 169 567 417 170 568 minecraft:purple_terracotta
fill 415 169 581 415 170 582 minecraft:black_concrete
fill 415 169 583 417 170 584 minecraft:purple_terracotta
fill 415 169 597 415 170 598 minecraft:black_concrete
fill 416 169 564 416 170 564 minecraft:black_concrete
fill 416 169 566 417 170 566 minecraft:purple_terracotta
fill 416 169 580 416 170 580 minecraft:black_concrete
fill 416 169 581 417 170 582 minecraft:purple_terracotta
fill 416 169 595 416 170 596 minecraft:black_concrete
fill 416 169 597 417 170 598 minecraft:purple_terracotta
fill 417 169 562 417 170 563 minecraft:black_concrete
fill 417 169 564 417 170 564 minecraft:purple_terracotta
fill 417 169 578 417 170 578 minecraft:black_concrete
fill 417 169 580 417 170 580 minecraft:purple_terracotta
fill 417 169 594 417 170 594 minecraft:black_concrete
fill 417 169 595 417 170 596 minecraft:purple_terracotta
fill 390 170 580 395 170 580 minecraft:purple_terracotta
fill 391 170 578 394 170 579 minecraft:purple_terracotta
fill 392 170 576 393 170 577 minecraft:purple_terracotta
fill 393 170 574 393 170 575 minecraft:purple_terracotta
fill 394 170 573 397 170 577 minecraft:mossy_stone_bricks
fill 395 170 571 405 170 572 minecraft:mossy_stone_bricks
fill 395 170 578 405 170 579 minecraft:mossy_stone_bricks
fill 396 170 569 397 170 569 minecraft:purple_terracotta
fill 396 170 570 404 170 570 minecraft:mossy_stone_bricks
fill 396 170 580 404 170 580 minecraft:mossy_stone_bricks
fill 398 170 569 402 170 569 minecraft:mossy_stone_bricks
fill 398 170 573 398 170 574 minecraft:mossy_stone_bricks
fill 398 170 576 398 170 577 minecraft:mossy_stone_bricks
fill 398 170 581 402 170 581 minecraft:mossy_stone_bricks
fill 398 170 582 405 170 582 minecraft:purple_terracotta
setblock 399 170 573 minecraft:mossy_stone_bricks
setblock 399 170 577 minecraft:mossy_stone_bricks
fill 401 170 573 406 170 573 minecraft:mossy_stone_bricks
fill 401 170 577 406 170 577 minecraft:mossy_stone_bricks
fill 402 170 574 406 170 574 minecraft:mossy_stone_bricks
fill 402 170 576 406 170 576 minecraft:mossy_stone_bricks
setblock 403 170 569 minecraft:purple_terracotta
fill 403 170 575 406 170 575 minecraft:mossy_stone_bricks
fill 403 170 581 405 170 581 minecraft:purple_terracotta
setblock 404 170 569 minecraft:black_concrete
fill 405 170 580 406 170 580 minecraft:purple_terracotta
fill 406 170 571 410 170 572 minecraft:purple_terracotta
fill 406 170 578 406 170 579 minecraft:purple_terracotta
fill 407 170 573 407 170 578 minecraft:purple_terracotta
fill 408 170 573 408 170 577 minecraft:purple_terracotta
fill 409 170 573 409 170 575 minecraft:purple_terracotta
setblock 410 170 573 minecraft:purple_terracotta
setblock 411 170 571 minecraft:purple_terracotta
fill 392 171 573 393 180 577 minecraft:stone_bricks
fill 393 171 568 395 183 571 minecraft:cobblestone
fill 393 171 572 394 180 572 minecraft:stone_bricks
fill 393 171 578 394 181 578 minecraft:stone_bricks
fill 393 171 579 395 183 582 minecraft:cobblestone
fill 396 171 568 396 183 570 minecraft:cobblestone
fill 396 171 580 396 183 582 minecraft:cobblestone
fill 397 171 568 397 180 569 minecraft:stone_bricks
fill 397 171 581 397 180 582 minecraft:stone_bricks
fill 398 171 567 402 180 568 minecraft:stone_bricks
fill 398 171 582 402 180 583 minecraft:stone_bricks
fill 403 171 568 403 180 569 minecraft:stone_bricks
fill 403 171 581 403 181 582 minecraft:stone_bricks
fill 404 171 568 407 183 570 minecraft:cobblestone
fill 404 171 580 407 183 582 minecraft:cobblestone
fill 405 171 571 407 183 571 minecraft:cobblestone
fill 405 171 579 407 183 579 minecraft:cobblestone
fill 406 171 572 407 181 572 minecraft:stone_bricks
fill 406 171 578 407 180 578 minecraft:stone_bricks
fill 407 171 573 408 180 577 minecraft:stone_bricks
setblock 379 173 560 minecraft:light[level=12]
setblock 379 173 568 minecraft:light[level=12]
setblock 379 173 576 minecraft:light[level=12]
setblock 379 173 584 minecraft:light[level=12]
setblock 379 173 592 minecraft:light[level=12]
setblock 387 173 560 minecraft:light[level=12]
setblock 387 173 568 minecraft:light[level=12]
setblock 387 173 576 minecraft:light[level=12]
setblock 387 173 584 minecraft:light[level=12]
setblock 387 173 592 minecraft:light[level=12]
setblock 395 173 560 minecraft:light[level=12]
setblock 395 173 576 minecraft:light[level=12]
setblock 395 173 584 minecraft:light[level=12]
setblock 395 173 592 minecraft:light[level=12]
setblock 403 173 560 minecraft:light[level=12]
setblock 403 173 576 minecraft:light[level=12]
setblock 403 173 584 minecraft:light[level=12]
setblock 403 173 592 minecraft:light[level=12]
setblock 411 173 560 minecraft:light[level=12]
setblock 411 173 568 minecraft:light[level=12]
setblock 411 173 576 minecraft:light[level=12]
setblock 411 173 584 minecraft:light[level=12]
setblock 411 173 592 minecraft:light[level=12]
fill 376 174 559 376 175 560 minecraft:purple_concrete
fill 376 174 568 376 175 568 minecraft:purple_concrete
fill 376 174 571 376 174 572 minecraft:purple_concrete
fill 376 174 579 376 175 580 minecraft:purple_concrete
fill 376 174 591 376 174 592 minecraft:purple_concrete
fill 377 174 557 378 175 557 minecraft:purple_concrete
fill 377 174 558 379 174 558 minecraft:obsidian
fill 377 174 560 377 174 562 minecraft:obsidian
fill 377 174 564 377 174 566 minecraft:obsidian
fill 377 174 568 377 174 570 minecraft:obsidian
fill 377 174 572 377 174 574 minecraft:obsidian
fill 377 174 576 377 174 578 minecraft:obsidian
fill 377 174 580 377 174 582 minecraft:obsidian
fill 377 174 584 377 174 586 minecraft:obsidian
fill 377 174 588 377 174 590 minecraft:obsidian
fill 377 174 592 377 174 594 minecraft:obsidian
fill 377 174 596 377 174 598 minecraft:obsidian
fill 377 174 599 377 175 599 minecraft:purple_concrete
fill 379 174 598 381 174 598 minecraft:obsidian
setblock 380 174 599 minecraft:purple_concrete
fill 381 174 558 383 174 558 minecraft:obsidian
fill 381 174 599 381 177 599 minecraft:purple_terracotta
fill 383 174 598 385 174 598 minecraft:obsidian
fill 385 174 557 385 177 557 minecraft:purple_terracotta
fill 385 174 558 387 174 558 minecraft:obsidian
setblock 386 174 557 minecraft:purple_concrete
fill 387 174 598 389 174 598 minecraft:obsidian
fill 388 174 599 389 175 599 minecraft:purple_concrete
fill 389 174 557 390 175 557 minecraft:purple_concrete
fill 389 174 558 391 174 558 minecraft:obsidian
fill 391 174 598 393 174 598 minecraft:obsidian
fill 393 174 558 395 174 558 minecraft:obsidian
fill 395 174 598 397 174 598 minecraft:obsidian
fill 396 174 564 397 174 567 minecraft:obsidian
fill 397 174 557 398 174 557 minecraft:purple_concrete
fill 397 174 558 399 174 558 minecraft:obsidian
fill 397 174 563 401 174 563 minecraft:obsidian
fill 398 174 562 400 174 562 minecraft:obsidian
fill 398 174 564 402 174 566 minecraft:obsidian
setblock 399 174 569 minecraft:obsidian
fill 399 174 598 401 174 598 minecraft:obsidian
fill 400 174 599 401 174 599 minecraft:purple_concrete
fill 401 174 557 401 175 557 minecraft:purple_concrete
fill 401 174 558 403 174 558 minecraft:obsidian
setblock 402 174 557 minecraft:purple_terracotta
fill 402 174 590 404 174 593 minecraft:black_concrete
fill 403 174 594 405 174 594 minecraft:black_concrete
fill 403 174 598 405 174 598 minecraft:obsidian
fill 404 174 589 404 176 589 minecraft:black_concrete
fill 405 174 558 407 174 558 minecraft:obsidian
fill 405 174 589 408 177 592 minecraft:purple_concrete
fill 405 174 593 407 174 593 minecraft:black_concrete
fill 406 174 588 407 179 588 minecraft:purple_concrete
fill 407 174 598 409 174 598 minecraft:obsidian
fill 408 174 599 409 175 599 minecraft:purple_concrete
fill 409 174 557 410 175 557 minecraft:purple_concrete
fill 409 174 558 411 174 558 minecraft:obsidian
fill 411 174 598 413 174 598 minecraft:obsidian
setblock 412 174 599 minecraft:purple_concrete
fill 413 174 558 415 174 558 minecraft:obsidian
fill 413 174 599 413 177 599 minecraft:purple_terracotta
fill 415 174 598 417 174 598 minecraft:obsidian
fill 417 174 557 417 177 557 minecraft:purple_terracotta
fill 417 174 558 417 174 560 minecraft:obsidian
fill 417 174 562 417 174 564 minecraft:obsidian
fill 417 174 566 417 174 568 minecraft:obsidian
fill 417 174 570 417 174 572 minecraft:obsidian
fill 417 174 574 417 174 576 minecraft:obsidian
fill 417 174 578 417 174 580 minecraft:obsidian
fill 417 174 582 417 174 584 minecraft:obsidian
fill 417 174 586 417 174 588 minecraft:obsidian
fill 417 174 590 417 174 592 minecraft:obsidian
fill 417 174 594 417 174 596 minecraft:obsidian
setblock 418 174 557 minecraft:purple_concrete
fill 418 174 560 418 175 560 minecraft:purple_concrete
fill 418 174 568 418 174 569 minecraft:purple_concrete
fill 418 174 580 418 175 581 minecraft:purple_concrete
fill 418 174 588 418 174 589 minecraft:purple_concrete
fill 418 174 592 418 175 592 minecraft:purple_concrete
setblock 376 175 567 minecraft:purple_concrete
fill 376 175 571 376 178 572 minecraft:purple_terracotta
fill 376 175 587 376 177 587 minecraft:purple_terracotta
setblock 376 175 588 minecraft:purple_concrete
setblock 376 175 591 minecraft:purple_concrete
fill 376 175 592 376 178 592 minecraft:purple_terracotta
setblock 376 175 599 minecraft:purple_concrete
fill 380 175 599 380 178 599 minecraft:purple_terracotta
setblock 381 175 557 minecraft:purple_concrete
fill 382 175 557 382 177 557 minecraft:purple_terracotta
fill 386 175 557 386 177 557 minecraft:purple_terracotta
fill 396 175 599 397 175 599 minecraft:purple_concrete
fill 397 175 557 397 178 557 minecraft:purple_terracotta
setblock 398 175 557 minecraft:purple_concrete
fill 398 175 565 400 175 566 minecraft:amethyst_block
setblock 400 175 599 minecraft:purple_concrete
fill 401 175 599 401 178 599 minecraft:purple_terracotta
setblock 402 175 557 minecraft:purple_concrete
fill 403 175 590 403 175 593 minecraft:black_concrete
fill 404 175 590 404 176 591 minecraft:purple_concrete
fill 404 175 592 404 175 593 minecraft:black_concrete
fill 405 175 588 405 177 588 minecraft:purple_concrete
fill 405 175 593 405 176 593 minecraft:black_concrete
fill 406 175 593 406 176 593 minecraft:purple_concrete
fill 407 175 593 407 176 593 minecraft:black_concrete
fill 407 175 594 407 176 594 minecraft:obsidian
fill 408 175 588 409 181 588 minecraft:purple_concrete
fill 409 175 589 409 178 591 minecraft:purple_concrete
fill 412 175 599 412 178 599 minecraft:purple_terracotta
fill 416 175 599 416 177 599 minecraft:purple_terracotta
setblock 417 175 599 minecraft:purple_concrete
fill 418 175 557 418 178 557 minecraft:purple_terracotta
setblock 418 175 561 minecraft:purple_concrete
fill 418 175 568 418 178 568 minecraft:purple_terracotta
setblock 418 175 569 minecraft:purple_concrete
setblock 418 175 572 minecraft:purple_concrete
fill 418 175 573 418 177 573 minecraft:purple_terracotta
fill 418 175 588 418 178 589 minecraft:purple_terracotta
setblock 418 175 593 minecraft:purple_concrete
fill 376 176 557 376 176 558 minecraft:purple_concrete
fill 376 176 559 376 181 560 minecraft:purple_terracotta
fill 376 176 565 376 177 566 minecraft:purple_concrete
fill 376 176 567 376 181 568 minecraft:purple_terracotta
setblock 376 176 569 minecraft:purple_concrete
fill 376 176 570 376 179 570 minecraft:purple_terracotta
fill 376 176 577 376 177 578 minecraft:purple_concrete
fill 376 176 579 376 181 580 minecraft:purple_terracotta
setblock 376 176 585 minecraft:purple_terracotta
fill 376 176 586 376 177 586 minecraft:purple_concrete
fill 376 176 588 376 181 588 minecraft:purple_terracotta
fill 376 176 589 376 176 590 minecraft:purple_concrete
fill 376 176 591 376 181 591 minecraft:purple_terracotta
fill 376 176 597 376 177 598 minecraft:purple_concrete
fill 376 176 599 377 181 599 minecraft:purple_terracotta
fill 377 176 557 378 178 557 minecraft:purple_terracotta
fill 379 176 557 380 176 557 minecraft:purple_concrete
fill 381 176 557 381 181 557 minecraft:purple_terracotta
fill 383 176 557 383 177 557 minecraft:purple_concrete
setblock 384 176 557 minecraft:purple_terracotta
fill 386 176 599 387 176 599 minecraft:purple_concrete
fill 388 176 599 389 181 599 minecraft:purple_terracotta
fill 389 176 557 390 181 557 minecraft:purple_terracotta
fill 391 176 557 392 177 557 minecraft:purple_concrete
setblock 394 176 599 minecraft:purple_terracotta
fill 395 176 599 395 177 599 minecraft:purple_concrete
fill 396 176 599 397 181 599 minecraft:purple_terracotta
fill 398 176 557 399 178 557 minecraft:purple_terracotta
setblock 398 176 599 minecraft:purple_concrete
fill 399 176 565 399 177 566 minecraft:amethyst_block
fill 399 176 599 400 179 599 minecraft:purple_terracotta
setblock 400 176 557 minecraft:purple_concrete
setblock 400 176 565 minecraft:amethyst_block
fill 401 176 557 402 181 557 minecraft:purple_terracotta
fill 403 176 557 404 177 557 minecraft:purple_concrete
setblock 403 176 591 minecraft:black_concrete
setblock 404 176 592 minecraft:black_concrete
fill 406 176 587 409 178 587 minecraft:purple_concrete
fill 406 176 599 407 177 599 minecraft:purple_concrete
fill 408 176 599 409 181 599 minecraft:purple_terracotta
fill 409 176 557 410 181 557 minecraft:purple_terracotta
fill 410 176 588 410 179 590 minecraft:purple_concrete
fill 411 176 557 412 176 557 minecraft:purple_concrete
fill 417 176 599 417 181 599 minecraft:purple_terracotta
fill 418 176 560 418 181 561 minecraft:purple_terracotta
fill 418 176 562 418 177 563 minecraft:purple_concrete
fill 418 176 569 418 181 569 minecraft:purple_terracotta
fill 418 176 570 418 176 571 minecraft:purple_concrete
fill 418 176 572 418 181 572 minecraft:purple_terracotta
fill 418 176 574 418 177 574 minecraft:purple_concrete
setblock 418 176 575 minecraft:purple_terracotta
fill 418 176 580 418 181 581 minecraft:purple_terracotta
fill 418 176 582 418 177 583 minecraft:purple_concrete
fill 418 176 590 418 179 590 minecraft:purple_terracotta
setblock 418 176 591 minecraft:purple_concrete
fill 418 176 592 418 181 593 minecraft:purple_terracotta
fill 418 176 594 418 177 595 minecraft:purple_concrete
fill 418 176 599 418 177 599 minecraft:purple_concrete
setblock 376 177 557 minecraft:purple_concrete
fill 376 177 558 376 180 558 minecraft:purple_terracotta
fill 376 177 569 376 180 569 minecraft:purple_terracotta
fill 376 177 573 376 179 573 minecraft:purple_terracotta
setblock 376 177 574 minecraft:purple_concrete
setblock 376 177 585 minecraft:purple_concrete
fill 376 177 589 376 180 590 minecraft:purple_terracotta
fill 379 177 557 379 180 557 minecraft:purple_terracotta
setblock 380 177 557 minecraft:purple_concrete
fill 382 177 599 382 179 599 minecraft:purple_terracotta
setblock 383 177 599 minecraft:purple_concrete
setblock 384 177 557 minecraft:purple_concrete
setblock 386 177 599 minecraft:purple_concrete
fill 387 177 599 387 180 599 minecraft:purple_terracotta
setblock 394 177 599 minecraft:purple_concrete
setblock 395 177 557 minecraft:purple_concrete
fill 396 177 557 396 179 557 minecraft:purple_terracotta
fill 398 177 599 398 180 599 minecraft:purple_terracotta
fill 400 177 557 400 180 557 minecraft:purple_terracotta
fill 408 177 586 410 182 586 minecraft:purple_concrete
fill 410 177 587 411 183 587 minecraft:purple_concrete
fill 411 177 557 411 180 557 minecraft:purple_terracotta
fill 411 177 588 411 182 588 minecraft:purple_concrete
setblock 412 177 557 minecraft:purple_concrete
fill 414 177 599 415 177 599 minecraft:purple_concrete
setblock 415 177 557 minecraft:purple_concrete
fill 416 177 557 416 179 557 minecraft:purple_terracotta
fill 418 177 570 418 180 571 minecraft:purple_terracotta
setblock 418 177 575 minecraft:purple_concrete
setblock 418 177 586 minecraft:purple_concrete
fill 418 177 587 418 179 587 minecraft:purple_terracotta
fill 418 177 591 418 180 591 minecraft:purple_terracotta
fill 376 178 557 376 183 557 minecraft:purple_terracotta
fill 376 178 563 376 179 564 minecraft:purple_concrete
fill 376 178 565 376 183 566 minecraft:purple_terracotta
fill 376 178 574 376 183 574 minecraft:purple_terracotta
fill 376 178 575 376 178 576 minecraft:purple_concrete
fill 376 178 577 376 183 578 minecraft:purple_terracotta
fill 376 178 583 376 179 584 minecraft:purple_concrete
fill 376 178 585 376 183 586 minecraft:purple_terracotta
setblock 376 178 587 minecraft:purple_concrete
fill 376 178 595 376 179 596 minecraft:purple_concrete
fill 376 178 597 376 183 598 minecraft:purple_terracotta
fill 380 178 557 380 180 557 minecraft:purple_terracotta
fill 381 178 599 381 179 599 minecraft:purple_concrete
setblock 382 178 557 minecraft:purple_concrete
fill 383 178 557 384 183 557 minecraft:purple_terracotta
fill 383 178 579 384 179 580 minecraft:obsidian
fill 383 178 599 383 183 599 minecraft:purple_terracotta
fill 384 178 599 385 178 599 minecraft:purple_concrete
fill 385 178 557 386 179 557 minecraft:purple_concrete
fill 386 178 599 386 183 599 minecraft:purple_terracotta
fill 391 178 557 392 183 557 minecraft:purple_terracotta
fill 392 178 599 393 179 599 minecraft:purple_concrete
fill 393 178 557 394 178 557 minecraft:purple_concrete
fill 394 178 599 395 183 599 minecraft:purple_terracotta
fill 395 178 557 395 179 557 minecraft:purple_terracotta
fill 398 178 596 399 179 597 minecraft:amethyst_block
setblock 399 178 565 minecraft:amethyst_block
fill 403 178 557 404 183 557 minecraft:purple_terracotta
fill 404 178 599 405 178 599 minecraft:purple_concrete
fill 405 178 557 406 179 557 minecraft:purple_concrete
fill 405 178 589 408 178 590 minecraft:purple_concrete
fill 406 178 591 408 178 591 minecraft:purple_concrete
fill 406 178 599 407 183 599 minecraft:purple_terracotta
fill 407 178 586 407 180 586 minecraft:purple_concrete
fill 409 178 585 410 183 585 minecraft:purple_concrete
fill 411 178 586 411 184 586 minecraft:purple_concrete
fill 411 178 589 411 180 589 minecraft:purple_concrete
fill 412 178 557 412 183 557 minecraft:purple_terracotta
fill 413 178 557 414 178 557 minecraft:purple_concrete
fill 413 178 599 413 179 599 minecraft:purple_concrete
fill 414 178 599 415 183 599 minecraft:purple_terracotta
fill 415 178 557 415 183 557 minecraft:purple_terracotta
setblock 416 178 599 minecraft:purple_concrete
fill 417 178 557 417 179 557 minecraft:purple_concrete
fill 418 178 562 418 183 563 minecraft:purple_terracotta
fill 418 178 564 418 179 565 minecraft:purple_concrete
setblock 418 178 573 minecraft:purple_concrete
fill 418 178 574 418 183 575 minecraft:purple_terracotta
fill 418 178 576 418 179 577 minecraft:purple_concrete
fill 418 178 582 418 183 583 minecraft:purple_terracotta
fill 418 178 584 418 178 585 minecraft:purple_concrete
fill 418 178 586 418 183 586 minecraft:purple_terracotta
fill 418 178 594 418 183 595 minecraft:purple_terracotta
fill 418 178 596 418 179 597 minecraft:purple_concrete
fill 418 178 599 418 183 599 minecraft:purple_terracotta
fill 376 179 571 376 179 572 minecraft:purple_concrete
setblock 376 179 575 minecraft:purple_concrete
fill 376 179 576 376 182 576 minecraft:purple_terracotta
fill 376 179 587 376 182 587 minecraft:purple_terracotta
setblock 376 179 592 minecraft:purple_concrete
setblock 377 179 557 minecraft:purple_concrete
fill 378 179 557 378 181 557 minecraft:purple_terracotta
setblock 380 179 599 minecraft:purple_concrete
fill 382 179 557 382 182 557 minecraft:purple_terracotta
fill 384 179 599 385 182 599 minecraft:purple_terracotta
fill 393 179 557 393 182 557 minecraft:purple_terracotta
setblock 394 179 557 minecraft:purple_concrete
fill 397 179 557 398 179 557 minecraft:purple_concrete
setblock 399 179 557 minecraft:purple_terracotta
setblock 401 179 599 minecraft:purple_concrete
setblock 404 179 599 minecraft:purple_concrete
fill 405 179 599 405 182 599 minecraft:purple_terracotta
fill 406 179 589 409 179 590 minecraft:purple_concrete
fill 406 179 591 406 181 591 minecraft:amethyst_block
fill 407 179 587 409 180 587 minecraft:purple_concrete
fill 408 179 585 408 182 585 minecraft:purple_concrete
setblock 408 179 591 minecraft:purple_concrete
fill 409 179 584 411 181 584 minecraft:purple_concrete
fill 411 179 585 412 182 585 minecraft:purple_concrete
fill 412 179 586 412 181 588 minecraft:purple_concrete
setblock 412 179 599 minecraft:purple_concrete
fill 413 179 557 414 181 557 minecraft:purple_terracotta
fill 416 179 599 416 182 599 minecraft:purple_terracotta
setblock 418 179 557 minecraft:purple_concrete
setblock 418 179 568 minecraft:purple_concrete
fill 418 179 573 418 182 573 minecraft:purple_terracotta
fill 418 179 584 418 182 584 minecraft:purple_terracotta
setblock 418 179 585 minecraft:purple_concrete
fill 418 179 588 418 179 589 minecraft:purple_concrete
fill 376 180 561 376 180 562 minecraft:purple_concrete
fill 376 180 563 376 185 564 minecraft:purple_terracotta
fill 376 180 570 376 181 570 minecraft:purple_concrete
fill 376 180 571 376 185 572 minecraft:purple_terracotta
setblock 376 180 573 minecraft:purple_concrete
fill 376 180 575 376 185 575 minecraft:purple_terracotta
fill 376 180 581 376 181 582 minecraft:purple_concrete
fill 376 180 583 376 185 584 minecraft:purple_terracotta
fill 376 180 592 376 185 592 minecraft:purple_terracotta
fill 376 180 593 376 180 594 minecraft:purple_concrete
fill 376 180 595 376 185 596 minecraft:purple_terracotta
fill 377 180 557 377 185 557 minecraft:purple_terracotta
fill 377 180 558 379 180 558 minecraft:obsidian
fill 377 180 560 377 180 562 minecraft:obsidian
fill 377 180 564 377 180 566 minecraft:obsidian
fill 377 180 568 377 180 570 minecraft:obsidian
fill 377 180 572 377 180 574 minecraft:obsidian
fill 377 180 576 377 180 578 minecraft:obsidian
fill 377 180 580 377 180 582 minecraft:obsidian
fill 377 180 584 377 180 586 minecraft:obsidian
fill 377 180 588 377 180 590 minecraft:obsidian
fill 377 180 592 377 180 594 minecraft:obsidian
fill 377 180 596 377 180 598 minecraft:obsidian
fill 378 180 599 379 181 599 minecraft:purple_concrete
fill 379 180 598 381 180 598 minecraft:obsidian
fill 380 180 599 381 185 599 minecraft:purple_terracotta
fill 381 180 558 383 180 558 minecraft:obsidian
setblock 382 180 599 minecraft:purple_concrete
fill 383 180 598 385 180 598 minecraft:obsidian
fill 385 180 557 386 185 557 minecraft:purple_terracotta
fill 385 180 558 387 180 558 minecraft:obsidian
fill 387 180 557 388 181 557 minecraft:purple_concrete
fill 387 180 598 389 180 598 minecraft:obsidian
fill 389 180 558 391 180 558 minecraft:obsidian
fill 390 180 599 391 181 599 minecraft:purple_concrete
fill 391 180 598 393 180 598 minecraft:obsidian
fill 392 180 599 393 185 599 minecraft:purple_terracotta
fill 393 180 558 395 180 558 minecraft:obsidian
fill 394 180 557 394 185 557 minecraft:purple_terracotta
fill 395 180 557 396 180 557 minecraft:purple_concrete
fill 395 180 598 397 180 598 minecraft:obsidian
fill 397 180 557 398 181 557 minecraft:purple_terracotta
fill 397 180 558 399 180 558 minecraft:obsidian
fill 399 180 557 399 181 557 minecraft:purple_concrete
fill 399 180 598 401 180 598 minecraft:obsidian
fill 399 180 599 399 181 599 minecraft:purple_concrete
fill 400 180 599 401 181 599 minecraft:purple_terracotta
fill 401 180 558 403 180 558 minecraft:obsidian
fill 402 180 599 403 180 599 minecraft:purple_concrete
fill 403 180 598 405 180 598 minecraft:obsidian
fill 404 180 599 404 185 599 minecraft:purple_terracotta
fill 405 180 557 406 185 557 minecraft:purple_terracotta
fill 405 180 558 407 180 558 minecraft:obsidian
fill 406 180 590 407 182 590 minecraft:amethyst_block
fill 407 180 557 408 181 557 minecraft:purple_concrete
fill 407 180 588 407 180 589 minecraft:purple_concrete
fill 407 180 598 409 180 598 minecraft:obsidian
fill 408 180 589 409 180 590 minecraft:purple_concrete
fill 409 180 558 411 180 558 minecraft:obsidian
fill 410 180 583 412 180 583 minecraft:purple_concrete
fill 410 180 588 410 181 589 minecraft:purple_concrete
fill 410 180 599 411 181 599 minecraft:purple_concrete
fill 411 180 598 413 180 598 minecraft:obsidian
fill 412 180 584 412 181 584 minecraft:purple_concrete
fill 412 180 599 413 185 599 minecraft:purple_terracotta
fill 413 180 558 415 180 558 minecraft:obsidian
fill 415 180 598 417 180 598 minecraft:obsidian
setblock 416 180 557 minecraft:purple_concrete
fill 417 180 557 418 185 557 minecraft:purple_terracotta
fill 417 180 558 417 180 560 minecraft:obsidian
fill 417 180 562 417 180 564 minecraft:obsidian
fill 417 180 566 417 180 568 minecraft:obsidian
fill 417 180 570 417 180 572 minecraft:obsidian
fill 417 180 574 417 180 576 minecraft:obsidian
fill 417 180 578 417 180 580 minecraft:obsidian
fill 417 180 582 417 180 584 minecraft:obsidian
fill 417 180 586 417 180 588 minecraft:obsidian
fill 417 180 590 417 180 592 minecraft:obsidian
fill 417 180 594 417 180 596 minecraft:obsidian
fill 418 180 558 418 181 559 minecraft:purple_concrete
fill 418 180 564 418 185 565 minecraft:purple_terracotta
fill 418 180 566 418 180 567 minecraft:purple_concrete
fill 418 180 568 418 185 568 minecraft:purple_terracotta
fill 418 180 576 418 185 577 minecraft:purple_terracotta
fill 418 180 578 418 181 579 minecraft:purple_concrete
fill 418 180 585 418 185 585 minecraft:purple_terracotta
setblock 418 180 587 minecraft:purple_concrete
fill 418 180 588 418 185 589 minecraft:purple_terracotta
fill 418 180 590 418 181 590 minecraft:purple_concrete
fill 418 180 596 418 185 597 minecraft:purple_terracotta
setblock 418 180 598 minecraft:purple_concrete
setblock 376 181 558 minecraft:purple_concrete
setblock 376 181 561 minecraft:purple_concrete
fill 376 181 562 376 184 562 minecraft:purple_terracotta
setblock 376 181 569 minecraft:purple_concrete
fill 376 181 573 376 184 573 minecraft:purple_terracotta
fill 376 181 589 376 181 590 minecraft:purple_concrete
setblock 376 181 593 minecraft:purple_concrete
fill 376 181 594 376 184 594 minecraft:purple_terracotta
fill 379 181 557 380 181 557 minecraft:purple_concrete
setblock 379 181 560 minecraft:light[level=12]
setblock 379 181 568 minecraft:light[level=12]
setblock 379 181 576 minecraft:light[level=12]
setblock 379 181 584 minecraft:light[level=12]
setblock 379 181 592 minecraft:light[level=12]
fill 382 181 599 382 184 599 minecraft:purple_terracotta
setblock 387 181 560 minecraft:light[level=12]
setblock 387 181 568 minecraft:light[level=12]
setblock 387 181 576 minecraft:light[level=12]
setblock 387 181 584 minecraft:light[level=12]
setblock 387 181 592 minecraft:light[level=12]
setblock 387 181 599 minecraft:purple_concrete
fill 392 181 573 393 181 573 minecraft:stone_bricks
fill 392 181 575 392 181 576 minecraft:stone_bricks
fill 393 181 574 393 181 575 minecraft:stone_bricks
fill 395 181 557 396 183 557 minecraft:purple_terracotta
setblock 395 181 560 minecraft:light[level=12]
setblock 395 181 576 minecraft:light[level=12]
setblock 395 181 584 minecraft:light[level=12]
setblock 395 181 592 minecraft:light[level=12]
fill 397 181 568 398 181 568 minecraft:stone_bricks
setblock 397 181 581 minecraft:stone_bricks
setblock 398 181 567 minecraft:stone_bricks
setblock 398 181 599 minecraft:purple_concrete
fill 399 181 582 400 181 583 minecraft:stone_bricks
setblock 400 181 557 minecraft:purple_concrete
fill 401 181 567 402 181 568 minecraft:stone_bricks
fill 402 181 599 403 184 599 minecraft:purple_terracotta
setblock 403 181 560 minecraft:light[level=12]
setblock 403 181 568 minecraft:light[level=12]
setblock 403 181 576 minecraft:light[level=12]
setblock 403 181 584 minecraft:light[level=12]
setblock 403 181 592 minecraft:light[level=12]
setblock 407 181 573 minecraft:stone_bricks
fill 407 181 575 408 181 576 minecraft:stone_bricks
setblock 408 181 577 minecraft:stone_bricks
fill 408 181 587 409 182 587 minecraft:purple_concrete
fill 408 181 589 409 181 589 minecraft:purple_concrete
fill 409 181 583 411 181 583 minecraft:purple_concrete
fill 410 181 582 412 181 582 minecraft:purple_concrete
setblock 411 181 557 minecraft:purple_concrete
setblock 411 181 560 minecraft:light[level=12]
setblock 411 181 568 minecraft:light[level=12]
setblock 411 181 576 minecraft:light[level=12]
setblock 411 181 592 minecraft:light[level=12]
fill 412 181 583 412 187 583 minecraft:black_concrete
fill 413 181 583 413 181 586 minecraft:purple_concrete
fill 416 181 557 416 183 557 minecraft:purple_terracotta
fill 418 181 566 418 184 566 minecraft:purple_terracotta
setblock 418 181 567 minecraft:purple_concrete
fill 418 181 570 418 181 571 minecraft:purple_concrete
fill 418 181 587 418 184 587 minecraft:purple_terracotta
setblock 418 181 591 minecraft:purple_concrete
fill 418 181 598 418 184 598 minecraft:purple_terracotta
fill 376 182 558 376 187 558 minecraft:purple_terracotta
fill 376 182 559 376 182 560 minecraft:purple_concrete
fill 376 182 561 376 187 561 minecraft:purple_terracotta
fill 376 182 567 376 183 568 minecraft:purple_concrete
fill 376 182 569 376 187 570 minecraft:purple_terracotta
fill 376 182 579 376 182 580 minecraft:purple_concrete
fill 376 182 581 376 187 582 minecraft:purple_terracotta
fill 376 182 588 376 183 588 minecraft:purple_concrete
fill 376 182 589 376 187 590 minecraft:purple_terracotta
setblock 376 182 591 minecraft:purple_concrete
fill 376 182 593 376 187 593 minecraft:purple_terracotta
fill 376 182 599 377 183 599 minecraft:purple_concrete
setblock 378 182 557 minecraft:purple_concrete
fill 378 182 599 379 187 599 minecraft:purple_terracotta
fill 379 182 557 380 187 557 minecraft:purple_terracotta
fill 381 182 557 381 183 557 minecraft:purple_concrete
fill 387 182 557 388 187 557 minecraft:purple_terracotta
fill 387 182 599 387 187 599 minecraft:purple_terracotta
fill 388 182 599 389 182 599 minecraft:purple_concrete
fill 389 182 557 390 183 557 minecraft:purple_concrete
fill 390 182 599 391 187 599 minecraft:purple_terracotta
fill 396 182 599 397 183 599 minecraft:purple_concrete
fill 397 182 557 397 185 557 minecraft:purple_terracotta
setblock 398 182 557 minecraft:purple_concrete
fill 398 182 599 399 187 599 minecraft:purple_terracotta
fill 399 182 557 400 187 557 minecraft:purple_terracotta
setblock 400 182 599 minecraft:purple_concrete
fill 401 182 557 402 183 557 minecraft:purple_concrete
fill 401 182 599 401 185 599 minecraft:purple_terracotta
fill 407 182 557 408 184 557 minecraft:purple_terracotta
fill 408 182 599 409 183 599 minecraft:purple_concrete
fill 409 182 557 410 182 557 minecraft:purple_concrete
fill 409 182 583 409 183 584 minecraft:purple_concrete
fill 409 182 588 410 182 588 minecraft:purple_concrete
fill 410 182 582 411 185 584 minecraft:black_concrete
fill 410 182 599 411 187 599 minecraft:purple_terracotta
fill 411 182 557 411 187 557 minecraft:purple_terracotta
fill 411 182 581 412 187 581 minecraft:black_concrete
fill 412 182 582 413 188 582 minecraft:black_concrete
fill 412 182 584 413 186 584 minecraft:black_concrete
fill 412 182 586 412 182 587 minecraft:purple_concrete
fill 413 182 557 413 183 557 minecraft:purple_concrete
fill 413 182 583 413 187 583 minecraft:black_concrete
fill 413 182 585 413 182 586 minecraft:purple_concrete
setblock 414 182 557 minecraft:purple_terracotta
fill 417 182 599 417 183 599 minecraft:purple_concrete
fill 418 182 558 418 187 559 minecraft:purple_terracotta
fill 418 182 560 418 183 561 minecraft:purple_concrete
fill 418 182 567 418 187 567 minecraft:purple_terracotta
setblock 418 182 569 minecraft:purple_concrete
fill 418 182 570 418 187 571 minecraft:purple_terracotta
fill 418 182 572 418 183 572 minecraft:purple_concrete
fill 418 182 578 418 187 579 minecraft:purple_terracotta
fill 418 182 580 418 182 581 minecraft:purple_concrete
fill 418 182 590 418 187 591 minecraft:purple_terracotta
fill 418 182 592 418 183 593 minecraft:purple_concrete
fill 376 183 559 376 186 560 minecraft:purple_terracotta
setblock 376 183 576 minecraft:purple_concrete
setblock 376 183 579 minecraft:purple_concrete
fill 376 183 580 376 186 580 minecraft:purple_terracotta
setblock 376 183 587 minecraft:purple_concrete
fill 376 183 591 376 186 591 minecraft:purple_terracotta
fill 378 183 557 378 186 557 minecraft:purple_terracotta
setblock 382 183 557 minecraft:purple_concrete
fill 384 183 599 385 183 599 minecraft:purple_concrete
setblock 388 183 599 minecraft:purple_concrete
fill 389 183 599 389 186 599 minecraft:purple_terracotta
setblock 393 183 557 minecraft:purple_concrete
fill 398 183 557 398 185 557 minecraft:purple_terracotta
fill 400 183 599 400 186 599 minecraft:purple_terracotta
setblock 405 183 599 minecraft:purple_concrete
fill 409 183 557 409 186 557 minecraft:purple_terracotta
fill 409 183 586 409 183 587 minecraft:purple_concrete
setblock 410 183 557 minecraft:purple_concrete
fill 410 183 581 410 187 581 minecraft:black_concrete
fill 410 183 586 410 184 586 minecraft:purple_concrete
fill 411 183 580 413 185 580 minecraft:black_concrete
fill 411 183 585 413 184 585 minecraft:black_concrete
fill 412 183 586 413 183 586 minecraft:purple_concrete
fill 413 183 581 414 187 581 minecraft:black_concrete
setblock 414 183 557 minecraft:purple_concrete
fill 414 183 582 414 184 584 minecraft:black_concrete
setblock 416 183 599 minecraft:purple_concrete
fill 418 183 569 418 186 569 minecraft:purple_terracotta
setblock 418 183 573 minecraft:purple_concrete
fill 418 183 580 418 186 580 minecraft:purple_terracotta
setblock 418 183 581 minecraft:purple_concrete
setblock 418 183 584 minecraft:purple_concrete
setblock 376 184 557 minecraft:purple_concrete
fill 376 184 565 376 185 566 minecraft:purple_concrete
fill 376 184 567 376 189 568 minecraft:purple_terracotta
fill 376 184 574 376 185 574 minecraft:purple_concrete
fill 376 184 576 376 189 576 minecraft:purple_terracotta
fill 376 184 577 376 184 578 minecraft:purple_concrete
fill 376 184 579 376 189 579 minecraft:purple_terracotta
fill 376 184 585 376 185 586 minecraft:purple_concrete
fill 376 184 587 376 189 588 minecraft:purple_terracotta
fill 376 184 597 376 184 598 minecraft:purple_concrete
fill 376 184 599 377 189 599 minecraft:purple_terracotta
fill 381 184 557 382 189 557 minecraft:purple_terracotta
fill 383 184 557 384 185 557 minecraft:purple_concrete
fill 383 184 599 383 185 599 minecraft:purple_concrete
fill 384 184 599 385 189 599 minecraft:purple_terracotta
setblock 386 184 599 minecraft:purple_concrete
fill 388 184 599 388 189 599 minecraft:purple_terracotta
fill 389 184 557 390 186 557 minecraft:purple_terracotta
fill 391 184 557 392 184 557 minecraft:purple_concrete
fill 392 184 569 396 184 570 minecraft:dark_oak_planks
fill 392 184 580 396 184 581 minecraft:dark_oak_planks
fill 393 184 557 393 189 557 minecraft:purple_terracotta
fill 393 184 568 396 184 568 minecraft:dark_oak_planks
fill 393 184 571 396 184 571 minecraft:dark_oak_planks
fill 393 184 579 396 184 579 minecraft:dark_oak_planks
fill 393 184 582 396 184 582 minecraft:dark_oak_planks
fill 394 184 567 395 184 567 minecraft:dark_oak_planks
fill 394 184 583 395 184 583 minecraft:dark_oak_planks
fill 394 184 599 395 185 599 minecraft:purple_concrete
fill 395 184 557 395 185 557 minecraft:purple_concrete
setblock 396 184 557 minecraft:purple_terracotta
fill 396 184 599 397 189 599 minecraft:purple_terracotta
fill 401 184 557 402 189 557 minecraft:purple_terracotta
fill 403 184 557 404 185 557 minecraft:purple_concrete
fill 404 184 568 407 184 571 minecraft:dark_oak_planks
fill 404 184 579 407 184 582 minecraft:dark_oak_planks
fill 405 184 567 406 184 567 minecraft:dark_oak_planks
fill 405 184 583 406 184 583 minecraft:dark_oak_planks
fill 405 184 599 405 189 599 minecraft:purple_terracotta
fill 406 184 599 407 184 599 minecraft:purple_concrete
fill 408 184 569 408 184 570 minecraft:dark_oak_planks
fill 408 184 580 408 184 581 minecraft:dark_oak_planks
fill 408 184 599 409 189 599 minecraft:purple_terracotta
setblock 409 184 583 minecraft:black_concrete
fill 409 184 584 409 184 585 minecraft:purple_concrete
fill 410 184 557 410 186 557 minecraft:purple_terracotta
fill 410 184 580 410 188 580 minecraft:black_concrete
setblock 410 184 585 minecraft:black_concrete
fill 411 184 579 413 185 579 minecraft:black_concrete
setblock 412 184 557 minecraft:purple_concrete
setblock 412 184 586 minecraft:purple_concrete
fill 413 184 557 414 189 557 minecraft:purple_terracotta
fill 414 184 580 414 186 580 minecraft:black_concrete
fill 414 184 599 415 185 599 minecraft:purple_concrete
fill 415 184 557 416 185 557 minecraft:purple_concrete
fill 416 184 599 417 189 599 minecraft:purple_terracotta
fill 418 184 560 418 189 561 minecraft:purple_terracotta
fill 418 184 562 418 184 563 minecraft:purple_concrete
fill 418 184 572 418 189 573 minecraft:purple_terracotta
fill 418 184 574 418 185 575 minecraft:purple_concrete
fill 418 184 581 418 189 581 minecraft:purple_terracotta
fill 418 184 582 418 184 583 minecraft:purple_concrete
fill 418 184 584 418 189 584 minecraft:purple_terracotta
fill 418 184 586 418 185 586 minecraft:purple_concrete
fill 418 184 592 418 189 593 minecraft:purple_terracotta
fill 418 184 594 418 185 595 minecraft:purple_concrete
setblock 418 184 599 minecraft:purple_concrete
fill 376 185 557 376 188 557 minecraft:purple_terracotta
setblock 376 185 562 minecraft:purple_concrete
setblock 376 185 573 minecraft:purple_concrete
fill 376 185 577 376 188 578 minecraft:purple_terracotta
setblock 376 185 594 minecraft:purple_concrete
setblock 376 185 597 minecraft:purple_concrete
fill 376 185 598 376 188 598 minecraft:purple_terracotta
setblock 382 185 599 minecraft:purple_concrete
fill 386 185 599 386 188 599 minecraft:purple_terracotta
fill 391 185 557 391 188 557 minecraft:purple_terracotta
setblock 392 185 557 minecraft:purple_concrete
fill 393 185 568 395 185 570 minecraft:dark_oak_planks
fill 393 185 580 395 185 582 minecraft:dark_oak_planks
fill 394 185 571 395 185 571 minecraft:dark_oak_planks
fill 394 185 579 395 185 579 minecraft:dark_oak_planks
setblock 396 185 557 minecraft:purple_concrete
fill 396 185 569 396 185 570 minecraft:dark_oak_planks
fill 396 185 580 396 185 581 minecraft:dark_oak_planks
fill 402 185 599 403 185 599 minecraft:purple_concrete
fill 404 185 569 407 185 570 minecraft:dark_oak_planks
fill 404 185 580 407 185 581 minecraft:dark_oak_planks
fill 405 185 568 407 185 568 minecraft:dark_oak_planks
fill 405 185 571 406 185 571 minecraft:dark_oak_planks
fill 405 185 579 406 185 579 minecraft:dark_oak_planks
fill 405 185 582 407 185 582 minecraft:dark_oak_planks
setblock 406 185 599 minecraft:purple_concrete
setblock 407 185 557 minecraft:purple_concrete
fill 407 185 599 407 188 599 minecraft:purple_terracotta
fill 408 185 557 408 187 557 minecraft:purple_terracotta
fill 410 185 579 410 186 579 minecraft:black_concrete
setblock 410 185 585 minecraft:purple_concrete
fill 411 185 578 413 185 578 minecraft:black_concrete
fill 411 185 585 412 185 585 minecraft:black_concrete
fill 412 185 557 412 188 557 minecraft:purple_terracotta
setblock 414 185 579 minecraft:black_concrete
fill 414 185 582 414 186 583 minecraft:black_concrete
fill 418 185 562 418 188 562 minecraft:purple_terracotta
setblock 418 185 563 minecraft:purple_concrete
setblock 418 185 566 minecraft:purple_concrete
fill 418 185 582 418 188 583 minecraft:purple_terracotta
setblock 418 185 587 minecraft:purple_concrete
setblock 418 185 598 minecraft:purple_concrete
fill 418 185 599 418 188 599 minecraft:purple_terracotta
fill 376 186 562 376 191 562 minecraft:purple_terracotta
fill 376 186 563 376 186 564 minecraft:purple_concrete
fill 376 186 565 376 191 566 minecraft:purple_terracotta
fill 376 186 571 376 187 572 minecraft:purple_concrete
fill 376 186 573 376 191 574 minecraft:purple_terracotta
setblock 376 186 575 minecraft:purple_concrete
fill 376 186 583 376 187 584 minecraft:purple_concrete
fill 376 186 585 376 191 586 minecraft:purple_terracotta
fill 376 186 592 376 187 592 minecraft:purple_concrete
fill 376 186 594 376 191 594 minecraft:purple_terracotta
fill 376 186 595 376 186 596 minecraft:purple_concrete
fill 376 186 597 376 191 597 minecraft:purple_terracotta
fill 377 186 557 377 187 557 minecraft:purple_concrete
fill 377 186 558 379 186 558 minecraft:obsidian
fill 377 186 560 377 186 562 minecraft:obsidian
fill 377 186 564 377 186 566 minecraft:obsidian
fill 377 186 568 377 186 570 minecraft:obsidian
fill 377 186 572 377 186 574 minecraft:obsidian
fill 377 186 576 377 186 578 minecraft:obsidian
fill 377 186 580 377 186 582 minecraft:obsidian
fill 377 186 584 377 186 586 minecraft:obsidian
fill 377 186 588 377 186 590 minecraft:obsidian
fill 377 186 592 377 186 594 minecraft:obsidian
fill 377 186 596 377 186 598 minecraft:obsidian
fill 379 186 598 381 186 598 minecraft:obsidian
fill 380 186 599 381 187 599 minecraft:purple_concrete
fill 381 186 558 383 186 558 minecraft:obsidian
fill 382 186 599 383 191 599 minecraft:purple_terracotta
fill 383 186 557 384 191 557 minecraft:purple_terracotta
fill 383 186 598 385 186 598 minecraft:obsidian
fill 385 186 557 386 187 557 minecraft:purple_concrete
fill 385 186 558 387 186 558 minecraft:obsidian
fill 387 186 598 389 186 598 minecraft:obsidian
fill 389 186 558 391 186 558 minecraft:obsidian
fill 391 186 598 393 186 598 minecraft:obsidian
fill 392 186 557 392 188 557 minecraft:purple_terracotta
fill 392 186 599 393 186 599 minecraft:purple_concrete
fill 393 186 558 395 186 558 minecraft:obsidian
fill 393 186 569 395 186 570 minecraft:dark_oak_planks
fill 393 186 580 395 186 581 minecraft:dark_oak_planks
setblock 394 186 557 minecraft:purple_concrete
fill 394 186 568 395 186 568 minecraft:dark_oak_planks
fill 394 186 582 395 186 582 minecraft:dark_oak_planks
fill 394 186 599 395 191 599 minecraft:purple_terracotta
fill 395 186 557 396 191 557 minecraft:purple_terracotta
fill 395 186 598 397 186 598 minecraft:obsidian
fill 397 186 557 398 187 557 minecraft:purple_concrete
fill 397 186 558 399 186 558 minecraft:obsidian
fill 399 186 598 401 186 598 minecraft:obsidian
fill 401 186 558 403 186 558 minecraft:obsidian
fill 401 186 599 401 187 599 minecraft:purple_concrete
fill 402 186 599 403 191 599 minecraft:purple_terracotta
fill 403 186 557 404 191 557 minecraft:purple_terracotta
fill 403 186 598 405 186 598 minecraft:obsidian
setblock 404 186 599 minecraft:purple_concrete
fill 405 186 557 406 186 557 minecraft:purple_concrete
fill 405 186 558 407 186 558 minecraft:obsidian
fill 405 186 568 406 186 570 minecraft:dark_oak_planks
fill 405 186 580 406 186 582 minecraft:dark_oak_planks
fill 406 186 599 406 191 599 minecraft:purple_terracotta
fill 407 186 557 407 187 557 minecraft:purple_terracotta
fill 407 186 569 407 186 570 minecraft:dark_oak_planks
fill 407 186 580 407 186 581 minecraft:dark_oak_planks
fill 407 186 598 409 186 598 minecraft:obsidian
fill 409 186 558 411 186 558 minecraft:obsidian
fill 410 186 582 411 186 583 minecraft:black_concrete
fill 411 186 577 414 190 579 minecraft:purple_concrete
setblock 411 186 580 minecraft:black_concrete
setblock 411 186 584 minecraft:black_concrete
fill 411 186 598 413 186 598 minecraft:obsidian
fill 412 186 580 413 190 580 minecraft:purple_concrete
fill 412 186 599 413 187 599 minecraft:purple_concrete
fill 413 186 558 415 186 558 minecraft:obsidian
fill 414 186 599 415 191 599 minecraft:purple_terracotta
fill 415 186 557 416 191 557 minecraft:purple_terracotta
fill 415 186 598 417 186 598 minecraft:obsidian
fill 417 186 557 418 187 557 minecraft:purple_concrete
fill 417 186 558 417 186 560 minecraft:obsidian
fill 417 186 562 417 186 564 minecraft:obsidian
fill 417 186 566 417 186 568 minecraft:obsidian
fill 417 186 570 417 186 572 minecraft:obsidian
fill 417 186 574 417 186 576 minecraft:obsidian
fill 417 186 578 417 186 580 minecraft:obsidian
fill 417 186 582 417 186 584 minecraft:obsidian
fill 417 186 586 417 186 588 minecraft:obsidian
fill 417 186 590 417 186 592 minecraft:obsidian
fill 417 186 594 417 186 596 minecraft:obsidian
fill 418 186 563 418 191 563 minecraft:purple_terracotta
fill 418 186 564 418 186 565 minecraft:purple_concrete
fill 418 186 566 418 191 566 minecraft:purple_terracotta
fill 418 186 568 418 187 568 minecraft:purple_concrete
fill 418 186 574 418 191 575 minecraft:purple_terracotta
fill 418 186 576 418 187 577 minecraft:purple_concrete
setblock 418 186 585 minecraft:purple_concrete
fill 418 186 586 418 191 587 minecraft:purple_terracotta
fill 418 186 588 418 187 589 minecraft:purple_concrete
fill 418 186 594 418 191 595 minecraft:purple_terracotta
fill 418 186 596 418 186 597 minecraft:purple_concrete
fill 418 186 598 418 191 598 minecraft:purple_terracotta
fill 376 187 559 376 187 560 minecraft:purple_concrete
setblock 376 187 563 minecraft:purple_concrete
fill 376 187 564 376 190 564 minecraft:purple_terracotta
fill 376 187 575 376 190 575 minecraft:purple_terracotta
setblock 376 187 580 minecraft:purple_concrete
setblock 376 187 591 minecraft:purple_concrete
fill 376 187 595 376 190 596 minecraft:purple_terracotta
setblock 378 187 557 minecraft:purple_concrete
setblock 389 187 557 minecraft:purple_concrete
setblock 389 187 599 minecraft:purple_concrete
fill 390 187 557 390 189 557 minecraft:purple_terracotta
setblock 392 187 599 minecraft:purple_concrete
fill 393 187 599 393 190 599 minecraft:purple_terracotta
fill 394 187 557 394 190 557 minecraft:purple_terracotta
fill 394 187 569 395 187 570 minecraft:dark_oak_planks
fill 394 187 580 395 187 581 minecraft:dark_oak_planks
setblock 400 187 599 minecraft:purple_concrete
fill 404 187 599 404 190 599 minecraft:purple_terracotta
fill 405 187 557 405 190 557 minecraft:purple_terracotta
fill 405 187 569 406 187 570 minecraft:dark_oak_planks
fill 405 187 580 406 187 581 minecraft:dark_oak_planks
setblock 406 187 557 minecraft:purple_concrete
fill 409 187 557 410 187 557 minecraft:purple_concrete
fill 410 187 578 410 188 579 minecraft:purple_concrete
fill 410 187 582 411 187 582 minecraft:black_concrete
fill 411 187 576 414 192 576 minecraft:purple_concrete
fill 411 187 580 411 189 580 minecraft:purple_concrete
setblock 411 187 583 minecraft:black_concrete
fill 414 187 580 414 189 580 minecraft:purple_concrete
setblock 414 187 582 minecraft:black_concrete
fill 415 187 578 415 188 579 minecraft:purple_concrete
setblock 415 187 580 minecraft:black_concrete
fill 418 187 564 418 189 565 minecraft:purple_terracotta
setblock 418 187 569 minecraft:purple_concrete
setblock 418 187 580 minecraft:purple_concrete
fill 418 187 585 418 190 585 minecraft:purple_terracotta
fill 418 187 596 418 190 596 minecraft:purple_terracotta
setblock 418 187 597 minecraft:purple_concrete
fill 376 188 558 376 189 558 minecraft:purple_concrete
fill 376 188 559 376 193 560 minecraft:purple_terracotta
setblock 376 188 561 minecraft:purple_concrete
fill 376 188 563 376 193 563 minecraft:purple_terracotta
fill 376 188 569 376 189 570 minecraft:purple_concrete
fill 376 188 571 376 193 572 minecraft:purple_terracotta
fill 376 188 580 376 193 580 minecraft:purple_terracotta
fill 376 188 581 376 188 582 minecraft:purple_concrete
fill 376 188 583 376 193 584 minecraft:purple_terracotta
fill 376 188 589 376 189 590 minecraft:purple_concrete
fill 376 188 591 376 193 592 minecraft:purple_terracotta
setblock 376 188 593 minecraft:purple_concrete
fill 377 188 557 378 193 557 minecraft:purple_terracotta
fill 378 188 599 379 189 599 minecraft:purple_concrete
fill 379 188 557 380 189 557 minecraft:purple_concrete
fill 380 188 599 381 193 599 minecraft:purple_terracotta
fill 385 188 557 386 193 557 minecraft:purple_terracotta
fill 387 188 557 388 188 557 minecraft:purple_concrete
fill 387 188 599 387 189 599 minecraft:purple_concrete
fill 389 188 557 389 193 557 minecraft:purple_terracotta
fill 389 188 599 389 193 599 minecraft:purple_terracotta
fill 390 188 599 391 188 599 minecraft:purple_concrete
fill 392 188 599 392 193 599 minecraft:purple_terracotta
setblock 394 188 569 minecraft:dark_oak_planks
setblock 394 188 581 minecraft:dark_oak_planks
fill 397 188 557 398 193 557 minecraft:purple_terracotta
fill 398 188 599 399 189 599 minecraft:purple_concrete
fill 399 188 557 400 189 557 minecraft:purple_concrete
fill 400 188 599 401 193 599 minecraft:purple_terracotta
fill 406 188 557 406 193 557 minecraft:purple_terracotta
setblock 406 188 569 minecraft:dark_oak_planks
setblock 406 188 581 minecraft:dark_oak_planks
fill 407 188 557 408 188 557 minecraft:purple_concrete
fill 409 188 557 410 189 557 minecraft:purple_terracotta
fill 410 188 576 410 191 577 minecraft:purple_concrete
fill 410 188 599 411 188 599 minecraft:purple_concrete
fill 411 188 557 411 189 557 minecraft:purple_concrete
fill 411 188 575 414 193 575 minecraft:purple_concrete
setblock 411 188 581 minecraft:black_concrete
fill 412 188 574 412 195 574 minecraft:purple_concrete
fill 412 188 581 413 188 581 minecraft:purple_concrete
fill 412 188 599 413 193 599 minecraft:purple_terracotta
setblock 414 188 581 minecraft:black_concrete
fill 415 188 577 415 189 577 minecraft:purple_concrete
fill 417 188 557 418 193 557 minecraft:purple_terracotta
fill 418 188 558 418 189 559 minecraft:purple_concrete
setblock 418 188 567 minecraft:purple_concrete
fill 418 188 568 418 193 569 minecraft:purple_terracotta
fill 418 188 570 418 189 571 minecraft:purple_concrete
fill 418 188 576 418 193 577 minecraft:purple_terracotta
fill 418 188 578 418 188 579 minecraft:purple_concrete
fill 418 188 580 418 193 580 minecraft:purple_terracotta
fill 418 188 588 418 193 589 minecraft:purple_terracotta
fill 418 188 590 418 189 591 minecraft:purple_concrete
fill 418 188 597 418 193 597 minecraft:purple_terracotta
setblock 376 189 557 minecraft:purple_concrete
fill 376 189 561 376 192 561 minecraft:purple_terracotta
fill 376 189 577 376 189 578 minecraft:purple_concrete
setblock 376 189 581 minecraft:purple_concrete
fill 376 189 582 376 192 582 minecraft:purple_terracotta
fill 376 189 593 376 192 593 minecraft:purple_terracotta
setblock 376 189 598 minecraft:purple_concrete
setblock 379 189 560 minecraft:light[level=12]
setblock 379 189 568 minecraft:light[level=12]
setblock 379 189 576 minecraft:light[level=12]
setblock 379 189 584 minecraft:light[level=12]
setblock 379 189 592 minecraft:light[level=12]
setblock 386 189 599 minecraft:purple_concrete
fill 387 189 557 387 192 557 minecraft:purple_terracotta
setblock 387 189 560 minecraft:light[level=12]
setblock 387 189 568 minecraft:light[level=12]
setblock 387 189 576 minecraft:light[level=12]
setblock 387 189 584 minecraft:light[level=12]
setblock 387 189 592 minecraft:light[level=12]
setblock 388 189 557 minecraft:purple_concrete
fill 390 189 599 391 192 599 minecraft:purple_terracotta
fill 391 189 557 392 189 557 minecraft:purple_concrete
setblock 395 189 560 minecraft:light[level=12]
setblock 395 189 568 minecraft:light[level=12]
setblock 395 189 576 minecraft:light[level=12]
setblock 395 189 584 minecraft:light[level=12]
setblock 395 189 592 minecraft:light[level=12]
setblock 403 189 560 minecraft:light[level=12]
setblock 403 189 568 minecraft:light[level=12]
setblock 403 189 576 minecraft:light[level=12]
setblock 403 189 584 minecraft:light[level=12]
setblock 403 189 592 minecraft:light[level=12]
fill 407 189 557 408 191 557 minecraft:purple_terracotta
setblock 407 189 599 minecraft:purple_concrete
fill 410 189 575 410 193 575 minecraft:purple_concrete
fill 410 189 578 410 190 578 minecraft:purple_concrete
setblock 410 189 599 minecraft:purple_concrete
setblock 411 189 560 minecraft:light[level=12]
setblock 411 189 568 minecraft:light[level=12]
fill 411 189 574 411 195 574 minecraft:purple_concrete
setblock 411 189 584 minecraft:light[level=12]
setblock 411 189 592 minecraft:light[level=12]
fill 411 189 599 411 192 599 minecraft:purple_terracotta
setblock 412 189 557 minecraft:purple_concrete
fill 412 189 573 412 196 573 minecraft:purple_concrete
fill 412 189 581 413 189 581 minecraft:black_concrete
fill 413 189 574 414 193 574 minecraft:purple_concrete
setblock 415 189 578 minecraft:purple_concrete
setblock 418 189 562 minecraft:purple_concrete
fill 418 189 567 418 191 567 minecraft:purple_terracotta
fill 418 189 578 418 192 578 minecraft:purple_terracotta
setblock 418 189 579 minecraft:purple_concrete
fill 418 189 582 418 189 583 minecraft:purple_concrete
setblock 418 189 599 minecraft:purple_concrete
fill 376 190 557 376 195 558 minecraft:purple_terracotta
fill 376 190 567 376 190 568 minecraft:purple_concrete
fill 376 190 569 376 195 570 minecraft:purple_terracotta
fill 376 190 576 376 191 576 minecraft:purple_concrete
fill 376 190 577 376 195 578 minecraft:purple_terracotta
setblock 376 190 579 minecraft:purple_concrete
fill 376 190 581 376 195 581 minecraft:purple_terracotta
fill 376 190 587 376 191 588 minecraft:purple_concrete
fill 376 190 589 376 195 590 minecraft:purple_terracotta
fill 376 190 598 376 195 598 minecraft:purple_terracotta
fill 376 190 599 377 190 599 minecraft:purple_concrete
fill 378 190 599 379 195 599 minecraft:purple_terracotta
fill 379 190 557 380 195 557 minecraft:purple_terracotta
fill 381 190 557 382 191 557 minecraft:purple_concrete
fill 384 190 599 385 191 599 minecraft:purple_concrete
fill 386 190 599 387 195 599 minecraft:purple_terracotta
fill 388 190 557 388 195 557 minecraft:purple_terracotta
setblock 388 190 599 minecraft:purple_concrete
setblock 390 190 557 minecraft:purple_concrete
fill 391 190 557 392 195 557 minecraft:purple_terracotta
fill 393 190 557 393 191 557 minecraft:purple_concrete
fill 396 190 599 397 191 599 minecraft:purple_concrete
fill 398 190 599 399 195 599 minecraft:purple_terracotta
fill 399 190 557 400 195 557 minecraft:purple_terracotta
fill 401 190 557 402 191 557 minecraft:purple_concrete
fill 405 190 599 405 191 599 minecraft:purple_concrete
fill 407 190 599 407 195 599 minecraft:purple_terracotta
fill 408 190 599 409 190 599 minecraft:purple_concrete
fill 409 190 557 409 193 557 minecraft:purple_terracotta
setblock 410 190 557 minecraft:purple_concrete
fill 410 190 573 410 195 574 minecraft:purple_concrete
fill 410 190 599 410 195 599 minecraft:purple_terracotta
fill 411 190 557 412 195 557 minecraft:purple_terracotta
fill 411 190 572 411 195 573 minecraft:purple_concrete
fill 412 190 572 412 196 572 minecraft:purple_concrete
fill 413 190 557 414 191 557 minecraft:purple_concrete
fill 413 190 573 414 194 573 minecraft:purple_concrete
setblock 415 190 576 minecraft:purple_concrete
fill 416 190 599 417 191 599 minecraft:purple_concrete
fill 418 190 558 418 192 559 minecraft:purple_terracotta
fill 418 190 560 418 190 561 minecraft:purple_concrete
fill 418 190 562 418 195 562 minecraft:purple_terracotta
fill 418 190 564 418 191 564 minecraft:purple_concrete
setblock 418 190 565 minecraft:purple_terracotta
fill 418 190 570 418 195 571 minecraft:purple_terracotta
fill 418 190 572 418 191 573 minecraft:purple_concrete
fill 418 190 579 418 195 579 minecraft:purple_terracotta
setblock 418 190 581 minecraft:purple_concrete
fill 418 190 582 418 195 583 minecraft:purple_terracotta
fill 418 190 584 418 191 584 minecraft:purple_concrete
fill 418 190 590 418 195 591 minecraft:purple_terracotta
fill 418 190 592 418 190 593 minecraft:purple_concrete
fill 418 190 599 418 195 599 minecraft:purple_terracotta
setblock 376 191 564 minecraft:purple_concrete
setblock 376 191 567 minecraft:purple_concrete
fill 376 191 568 376 194 568 minecraft:purple_terracotta
setblock 376 191 575 minecraft:purple_concrete
fill 376 191 579 376 194 579 minecraft:purple_terracotta
fill 376 191 595 376 191 596 minecraft:purple_concrete
setblock 376 191 599 minecraft:purple_concrete
fill 377 191 599 377 194 599 minecraft:purple_terracotta
fill 388 191 599 388 194 599 minecraft:purple_terracotta
fill 390 191 557 390 194 557 minecraft:purple_terracotta
setblock 393 191 599 minecraft:purple_concrete
setblock 394 191 557 minecraft:purple_concrete
setblock 404 191 599 minecraft:purple_concrete
setblock 405 191 557 minecraft:purple_concrete
fill 408 191 599 409 194 599 minecraft:purple_terracotta
fill 410 191 557 410 193 557 minecraft:purple_terracotta
fill 410 191 572 410 194 572 minecraft:purple_concrete
fill 411 191 571 412 194 571 minecraft:purple_concrete
fill 411 191 577 414 191 578 minecraft:purple_concrete
fill 412 191 579 413 193 579 minecraft:amethyst_block
fill 413 191 572 413 195 572 minecraft:purple_concrete
fill 418 191 560 418 194 560 minecraft:purple_terracotta
setblock 418 191 561 minecraft:purple_concrete
setblock 418 191 565 minecraft:purple_concrete
fill 418 191 581 418 194 581 minecraft:purple_terracotta
setblock 418 191 585 minecraft:purple_concrete
fill 418 191 592 418 194 592 minecraft:purple_terracotta
setblock 418 191 593 minecraft:purple_concrete
setblock 418 191 596 minecraft:purple_concrete
fill 376 192 562 376 193 562 minecraft:purple_concrete
fill 376 192 564 376 197 564 minecraft:purple_terracotta
fill 376 192 565 376 192 566 minecraft:purple_concrete
fill 376 192 567 376 197 567 minecraft:purple_terracotta
fill 376 192 573 376 193 574 minecraft:purple_concrete
fill 376 192 575 376 197 576 minecraft:purple_terracotta
fill 376 192 585 376 192 586 minecraft:purple_concrete
fill 376 192 587 376 197 588 minecraft:purple_terracotta
fill 376 192 594 376 193 594 minecraft:purple_concrete
fill 376 192 595 376 197 596 minecraft:purple_terracotta
setblock 376 192 597 minecraft:purple_concrete
fill 376 192 599 376 197 599 minecraft:purple_terracotta
fill 377 192 558 379 192 558 minecraft:obsidian
fill 377 192 560 377 192 562 minecraft:obsidian
fill 377 192 564 377 192 566 minecraft:obsidian
fill 377 192 568 377 192 570 minecraft:obsidian
fill 377 192 572 377 192 574 minecraft:obsidian
fill 377 192 576 377 192 578 minecraft:obsidian
fill 377 192 580 377 192 582 minecraft:obsidian
fill 377 192 584 377 192 586 minecraft:obsidian
fill 377 192 588 377 192 590 minecraft:obsidian
fill 377 192 592 377 192 594 minecraft:obsidian
fill 377 192 596 377 192 598 minecraft:obsidian
fill 379 192 598 381 192 598 minecraft:obsidian
fill 381 192 557 382 197 557 minecraft:purple_terracotta
fill 381 192 558 383 192 558 minecraft:obsidian
fill 382 192 599 383 193 599 minecraft:purple_concrete
fill 383 192 557 384 192 557 minecraft:purple_concrete
fill 383 192 598 385 192 598 minecraft:obsidian
fill 384 192 599 385 197 599 minecraft:purple_terracotta
fill 385 192 558 387 192 558 minecraft:obsidian
fill 387 192 598 389 192 598 minecraft:obsidian
fill 389 192 558 391 192 558 minecraft:obsidian
fill 391 192 598 393 192 598 minecraft:obsidian
fill 393 192 557 394 197 557 minecraft:purple_terracotta
fill 393 192 558 395 192 558 minecraft:obsidian
fill 393 192 599 393 197 599 minecraft:purple_terracotta
fill 394 192 599 395 192 599 minecraft:purple_concrete
fill 395 192 557 396 193 557 minecraft:purple_concrete
fill 395 192 598 397 192 598 minecraft:obsidian
fill 396 192 599 397 197 599 minecraft:purple_terracotta
fill 397 192 558 399 192 558 minecraft:obsidian
fill 399 192 598 401 192 598 minecraft:obsidian
fill 401 192 557 402 194 557 minecraft:purple_terracotta
fill 401 192 558 403 192 558 minecraft:obsidian
fill 402 192 599 403 193 599 minecraft:purple_concrete
fill 403 192 557 404 192 557 minecraft:purple_concrete
fill 403 192 598 405 192 598 minecraft:obsidian
fill 404 192 599 405 197 599 minecraft:purple_terracotta
fill 405 192 557 405 197 557 minecraft:purple_terracotta
fill 405 192 558 407 192 558 minecraft:obsidian
setblock 406 192 599 minecraft:purple_concrete
fill 407 192 557 407 193 557 minecraft:purple_concrete
fill 407 192 598 409 192 598 minecraft:obsidian
setblock 408 192 557 minecraft:purple_terracotta
fill 409 192 558 411 192 558 minecraft:obsidian
fill 409 192 572 409 195 573 minecraft:purple_concrete
fill 410 192 570 410 193 571 minecraft:purple_concrete
setblock 410 192 576 minecraft:purple_concrete
fill 411 192 570 412 193 570 minecraft:purple_concrete
fill 411 192 577 413 192 577 minecraft:purple_concrete
fill 411 192 598 413 192 598 minecraft:obsidian
fill 412 192 578 413 194 578 minecraft:amethyst_block
fill 413 192 557 414 197 557 minecraft:purple_terracotta
fill 413 192 558 415 192 558 minecraft:obsidian
fill 413 192 571 413 196 571 minecraft:purple_concrete
fill 414 192 572 414 193 572 minecraft:purple_concrete
fill 414 192 599 415 193 599 minecraft:purple_concrete
fill 415 192 557 416 193 557 minecraft:purple_concrete
fill 415 192 598 417 192 598 minecraft:obsidian
fill 416 192 599 417 197 599 minecraft:purple_terracotta
fill 417 192 558 417 192 560 minecraft:obsidian
fill 417 192 562 417 192 564 minecraft:obsidian
fill 417 192 566 417 192 568 minecraft:obsidian
fill 417 192 570 417 192 572 minecraft:obsidian
fill 417 192 574 417 192 576 minecraft:obsidian
fill 417 192 578 417 192 580 minecraft:obsidian
fill 417 192 582 417 192 584 minecraft:obsidian
fill 417 192 586 417 192 588 minecraft:obsidian
fill 417 192 590 417 192 592 minecraft:obsidian
fill 417 192 594 417 192 596 minecraft:obsidian
fill 418 192 561 418 194 561 minecraft:purple_terracotta
setblock 418 192 563 minecraft:purple_concrete
fill 418 192 564 418 197 565 minecraft:purple_terracotta
fill 418 192 566 418 193 567 minecraft:purple_concrete
fill 418 192 572 418 197 573 minecraft:purple_terracotta
fill 418 192 574 418 192 575 minecraft:purple_concrete
fill 418 192 584 418 197 585 minecraft:purple_terracotta
fill 418 192 586 418 193 587 minecraft:purple_concrete
fill 418 192 593 418 197 593 minecraft:purple_terracotta
fill 418 192 594 418 192 595 minecraft:purple_concrete
fill 418 192 596 418 197 596 minecraft:purple_terracotta
fill 418 192 598 418 193 598 minecraft:purple_concrete
setblock 376 193 561 minecraft:purple_concrete
fill 376 193 565 376 196 566 minecraft:purple_terracotta
setblock 376 193 582 minecraft:purple_concrete
setblock 376 193 585 minecraft:purple_concrete
fill 376 193 586 376 196 586 minecraft:purple_terracotta
setblock 376 193 593 minecraft:purple_concrete
fill 376 193 597 376 196 597 minecraft:purple_terracotta
fill 383 193 557 383 196 557 minecraft:purple_terracotta
setblock 384 193 557 minecraft:purple_concrete
setblock 387 193 557 minecraft:purple_concrete
fill 390 193 599 391 193 599 minecraft:purple_concrete
setblock 394 193 599 minecraft:purple_concrete
fill 395 193 599 395 196 599 minecraft:purple_terracotta
fill 403 193 557 403 196 557 minecraft:purple_terracotta
setblock 404 193 557 minecraft:purple_concrete
fill 406 193 599 406 196 599 minecraft:purple_terracotta
setblock 408 193 557 minecraft:purple_concrete
fill 409 193 570 409 193 571 minecraft:purple_concrete
setblock 409 193 574 minecraft:purple_concrete
fill 410 193 569 411 193 569 minecraft:purple_concrete
fill 411 193 576 413 193 576 minecraft:purple_concrete
setblock 411 193 599 minecraft:purple_concrete
setblock 418 193 558 minecraft:purple_concrete
fill 418 193 559 418 195 559 minecraft:purple_terracotta
fill 418 193 563 418 196 563 minecraft:purple_terracotta
fill 418 193 574 418 196 574 minecraft:purple_terracotta
setblock 418 193 575 minecraft:purple_concrete
setblock 418 193 578 minecraft:purple_concrete
fill 418 193 594 418 196 595 minecraft:purple_terracotta
fill 376 194 559 376 195 560 minecraft:purple_concrete
fill 376 194 561 376 199 562 minecraft:purple_terracotta
setblock 376 194 563 minecraft:purple_concrete
fill 376 194 571 376 195 572 minecraft:purple_concrete
fill 376 194 573 376 199 574 minecraft:purple_terracotta
fill 376 194 580 376 195 580 minecraft:purple_concrete
fill 376 194 582 376 199 582 minecraft:purple_terracotta
fill 376 194 583 376 194 584 minecraft:purple_concrete
fill 376 194 585 376 199 585 minecraft:purple_terracotta
fill 376 194 591 376 195 592 minecraft:purple_concrete
fill 376 194 593 376 199 594 minecraft:purple_terracotta
fill 377 194 557 378 195 557 minecraft:purple_concrete
fill 380 194 599 381 194 599 minecraft:purple_concrete
fill 382 194 599 383 199 599 minecraft:purple_terracotta
fill 384 194 557 384 199 557 minecraft:purple_terracotta
fill 385 194 557 386 194 557 minecraft:purple_concrete
fill 387 194 557 387 199 557 minecraft:purple_terracotta
fill 389 194 557 389 195 557 minecraft:purple_concrete
fill 389 194 599 389 195 599 minecraft:purple_concrete
fill 390 194 599 391 199 599 minecraft:purple_terracotta
setblock 392 194 599 minecraft:purple_concrete
fill 394 194 599 394 199 599 minecraft:purple_terracotta
fill 395 194 557 396 199 557 minecraft:purple_terracotta
fill 397 194 557 398 195 557 minecraft:purple_concrete
fill 400 194 599 401 195 599 minecraft:purple_concrete
fill 401 194 586 401 195 587 minecraft:amethyst_block
fill 402 194 599 403 199 599 minecraft:purple_terracotta
fill 404 194 557 404 196 557 minecraft:purple_terracotta
setblock 406 194 557 minecraft:purple_concrete
fill 407 194 557 408 199 557 minecraft:purple_terracotta
fill 408 194 570 408 194 571 minecraft:purple_concrete
fill 409 194 557 410 195 557 minecraft:purple_concrete
fill 409 194 568 410 198 571 minecraft:black_concrete
fill 411 194 568 411 198 570 minecraft:black_concrete
fill 411 194 575 413 194 575 minecraft:purple_concrete
fill 411 194 599 411 199 599 minecraft:purple_terracotta
fill 412 194 569 412 194 570 minecraft:purple_concrete
fill 412 194 599 413 194 599 minecraft:purple_concrete
fill 413 194 570 413 196 570 minecraft:purple_concrete
setblock 413 194 574 minecraft:purple_concrete
fill 414 194 599 415 199 599 minecraft:purple_terracotta
fill 415 194 557 416 199 557 minecraft:purple_terracotta
fill 417 194 557 418 194 557 minecraft:purple_concrete
fill 418 194 558 418 195 558 minecraft:purple_terracotta
fill 418 194 566 418 199 567 minecraft:purple_terracotta
fill 418 194 568 418 195 569 minecraft:purple_concrete
fill 418 194 575 418 199 575 minecraft:purple_terracotta
fill 418 194 576 418 194 577 minecraft:purple_concrete
fill 418 194 578 418 199 578 minecraft:purple_terracotta
fill 418 194 580 418 195 580 minecraft:purple_concrete
fill 418 194 586 418 199 587 minecraft:purple_terracotta
fill 418 194 588 418 195 589 minecraft:purple_concrete
setblock 418 194 597 minecraft:purple_concrete
fill 418 194 598 418 199 598 minecraft:purple_terracotta
fill 376 195 563 376 198 563 minecraft:purple_terracotta
setblock 376 195 568 minecraft:purple_concrete
setblock 376 195 579 minecraft:purple_concrete
fill 376 195 583 376 198 584 minecraft:purple_terracotta
setblock 377 195 599 minecraft:purple_concrete
setblock 380 195 599 minecraft:purple_concrete
fill 381 195 599 381 198 599 minecraft:purple_terracotta
fill 385 195 557 386 198 557 minecraft:purple_terracotta
setblock 388 195 599 minecraft:purple_concrete
setblock 390 195 557 minecraft:purple_concrete
fill 392 195 599 392 198 599 minecraft:purple_terracotta
setblock 401 195 557 minecraft:purple_concrete
fill 402 195 557 402 197 557 minecraft:purple_terracotta
fill 406 195 557 406 198 557 minecraft:purple_terracotta
fill 408 195 568 408 198 571 minecraft:black_concrete
fill 408 195 599 409 195 599 minecraft:purple_concrete
fill 409 195 567 410 198 567 minecraft:black_concrete
fill 410 195 572 410 197 572 minecraft:black_concrete
fill 411 195 571 411 198 571 minecraft:black_concrete
fill 412 195 568 412 197 570 minecraft:black_concrete
setblock 412 195 571 minecraft:purple_concrete
setblock 412 195 599 minecraft:purple_concrete
setblock 413 195 573 minecraft:purple_concrete
fill 413 195 599 413 198 599 minecraft:purple_terracotta
fill 417 195 557 417 198 557 minecraft:purple_terracotta
setblock 418 195 557 minecraft:purple_concrete
fill 418 195 560 418 195 561 minecraft:purple_concrete
fill 418 195 576 418 197 577 minecraft:purple_terracotta
setblock 418 195 581 minecraft:purple_concrete
setblock 418 195 592 minecraft:purple_concrete
fill 418 195 597 418 198 597 minecraft:purple_terracotta
fill 376 196 557 376 197 558 minecraft:purple_concrete
fill 376 196 559 376 201 560 minecraft:purple_terracotta
fill 376 196 568 376 201 568 minecraft:purple_terracotta
fill 376 196 569 376 196 570 minecraft:purple_concrete
fill 376 196 571 376 201 572 minecraft:purple_terracotta
fill 376 196 577 376 197 578 minecraft:purple_concrete
fill 376 196 579 376 201 580 minecraft:purple_terracotta
setblock 376 196 581 minecraft:purple_concrete
fill 376 196 589 376 197 590 minecraft:purple_concrete
fill 376 196 591 376 201 592 minecraft:purple_terracotta
fill 376 196 598 376 197 598 minecraft:purple_concrete
fill 377 196 557 378 201 557 minecraft:purple_terracotta
fill 377 196 599 377 201 599 minecraft:purple_terracotta
fill 378 196 599 379 196 599 minecraft:purple_concrete
fill 379 196 557 380 197 557 minecraft:purple_concrete
fill 380 196 599 380 201 599 minecraft:purple_terracotta
fill 386 196 599 387 197 599 minecraft:purple_concrete
setblock 388 196 557 minecraft:purple_concrete
fill 388 196 599 389 201 599 minecraft:purple_terracotta
fill 389 196 557 390 201 557 minecraft:purple_terracotta
fill 391 196 557 392 197 557 minecraft:purple_concrete
fill 397 196 557 398 201 557 minecraft:purple_terracotta
fill 398 196 599 399 196 599 minecraft:purple_concrete
fill 399 196 557 400 196 557 minecraft:purple_concrete
fill 400 196 599 401 201 599 minecraft:purple_terracotta
fill 401 196 557 401 201 557 minecraft:purple_terracotta
fill 407 196 567 407 197 570 minecraft:black_concrete
fill 407 196 599 407 197 599 minecraft:purple_concrete
fill 408 196 567 408 197 567 minecraft:black_concrete
fill 408 196 599 409 201 599 minecraft:purple_terracotta
fill 409 196 557 410 201 557 minecraft:purple_terracotta
fill 409 196 566 409 198 566 minecraft:black_concrete
setblock 409 196 572 minecraft:black_concrete
fill 410 196 573 411 196 573 minecraft:purple_concrete
setblock 410 196 599 minecraft:purple_concrete
fill 411 196 557 412 197 557 minecraft:purple_concrete
fill 411 196 567 411 198 567 minecraft:black_concrete
setblock 411 196 572 minecraft:black_concrete
fill 412 196 571 412 197 571 minecraft:black_concrete
fill 412 196 599 412 201 599 minecraft:purple_terracotta
fill 418 196 557 418 201 557 minecraft:purple_terracotta
fill 418 196 558 418 196 559 minecraft:purple_concrete
fill 418 196 560 418 197 561 minecraft:purple_terracotta
fill 418 196 562 418 197 562 minecraft:purple_concrete
fill 418 196 568 418 201 569 minecraft:purple_terracotta
fill 418 196 570 418 197 571 minecraft:purple_concrete
setblock 418 196 579 minecraft:purple_concrete
fill 418 196 580 418 201 581 minecraft:purple_terracotta
fill 418 196 582 418 197 583 minecraft:purple_concrete
fill 418 196 588 418 201 589 minecraft:purple_terracotta
fill 418 196 590 418 196 591 minecraft:purple_concrete
fill 418 196 592 418 201 592 minecraft:purple_terracotta
fill 418 196 599 418 197 599 minecraft:purple_concrete
fill 376 197 565 376 197 566 minecraft:purple_concrete
setblock 376 197 569 minecraft:purple_concrete
fill 376 197 570 376 200 570 minecraft:purple_terracotta
fill 376 197 581 376 200 581 minecraft:purple_terracotta
setblock 376 197 586 minecraft:purple_concrete
setblock 376 197 597 minecraft:purple_concrete
fill 378 197 599 379 200 599 minecraft:purple_terracotta
setblock 379 197 560 minecraft:light[level=12]
setblock 379 197 568 minecraft:light[level=12]
setblock 379 197 576 minecraft:light[level=12]
setblock 379 197 584 minecraft:light[level=12]
setblock 379 197 592 minecraft:light[level=12]
setblock 383 197 557 minecraft:purple_concrete
setblock 387 197 560 minecraft:light[level=12]
setblock 387 197 568 minecraft:light[level=12]
setblock 387 197 576 minecraft:light[level=12]
setblock 387 197 584 minecraft:light[level=12]
setblock 387 197 592 minecraft:light[level=12]
fill 388 197 557 388 200 557 minecraft:purple_terracotta
setblock 395 197 560 minecraft:light[level=12]
setblock 395 197 568 minecraft:light[level=12]
setblock 395 197 576 minecraft:light[level=12]
setblock 395 197 584 minecraft:light[level=12]
setblock 395 197 592 minecraft:light[level=12]
setblock 395 197 599 minecraft:purple_concrete
setblock 398 197 599 minecraft:purple_concrete
fill 399 197 557 399 200 557 minecraft:purple_terracotta
fill 399 197 599 399 200 599 minecraft:purple_terracotta
setblock 400 197 557 minecraft:purple_concrete
fill 403 197 557 404 197 557 minecraft:purple_concrete
setblock 403 197 560 minecraft:light[level=12]
setblock 403 197 568 minecraft:light[level=12]
setblock 403 197 576 minecraft:light[level=12]
setblock 403 197 584 minecraft:light[level=12]
setblock 403 197 592 minecraft:light[level=12]
fill 406 197 567 406 197 568 minecraft:black_concrete
setblock 406 197 599 minecraft:purple_concrete
fill 407 197 566 408 197 566 minecraft:black_concrete
setblock 409 197 572 minecraft:purple_concrete
fill 410 197 566 410 200 566 minecraft:black_concrete
fill 410 197 599 410 200 599 minecraft:purple_terracotta
setblock 411 197 560 minecraft:light[level=12]
setblock 411 197 572 minecraft:purple_concrete
setblock 411 197 576 minecraft:light[level=12]
setblock 411 197 584 minecraft:light[level=12]
setblock 411 197 592 minecraft:light[level=12]
fill 418 197 558 418 199 559 minecraft:purple_terracotta
setblock 418 197 563 minecraft:purple_concrete
setblock 418 197 574 minecraft:purple_concrete
fill 418 197 579 418 199 579 minecraft:purple_terracotta
fill 418 197 590 418 200 590 minecraft:purple_terracotta
setblock 418 197 591 minecraft:purple_concrete
fill 418 197 594 418 197 595 minecraft:purple_concrete
fill 376 198 557 376 203 558 minecraft:purple_terracotta
fill 376 198 564 376 199 564 minecraft:purple_concrete
fill 376 198 565 376 203 566 minecraft:purple_terracotta
setblock 376 198 567 minecraft:purple_concrete
fill 376 198 569 376 203 569 minecraft:purple_terracotta
fill 376 198 575 376 199 576 minecraft:purple_concrete
fill 376 198 577 376 203 578 minecraft:purple_terracotta
fill 376 198 586 376 203 586 minecraft:purple_terracotta
fill 376 198 587 376 198 588 minecraft:purple_concrete
fill 376 198 589 376 203 590 minecraft:purple_terracotta
fill 376 198 595 376 199 596 minecraft:purple_concrete
fill 376 198 597 376 203 598 minecraft:purple_terracotta
setblock 376 198 599 minecraft:purple_concrete
fill 377 198 558 379 198 558 minecraft:obsidian
fill 377 198 560 377 198 562 minecraft:obsidian
fill 377 198 564 377 198 566 minecraft:obsidian
fill 377 198 568 377 198 570 minecraft:obsidian
fill 377 198 572 377 198 574 minecraft:obsidian
fill 377 198 576 377 198 578 minecraft:obsidian
fill 377 198 580 377 198 582 minecraft:obsidian
fill 377 198 584 377 198 586 minecraft:obsidian
fill 377 198 588 377 198 590 minecraft:obsidian
fill 377 198 592 377 198 594 minecraft:obsidian
fill 377 198 596 377 198 598 minecraft:obsidian
fill 379 198 557 380 203 557 minecraft:purple_terracotta
fill 379 198 598 381 198 598 minecraft:obsidian
fill 381 198 557 382 198 557 minecraft:purple_concrete
fill 381 198 558 383 198 558 minecraft:obsidian
fill 383 198 557 383 203 557 minecraft:purple_terracotta
fill 383 198 598 385 198 598 minecraft:obsidian
fill 384 198 599 385 199 599 minecraft:purple_concrete
fill 385 198 558 387 198 558 minecraft:obsidian
fill 386 198 599 387 203 599 minecraft:purple_terracotta
fill 387 198 598 389 198 598 minecraft:obsidian
fill 389 198 558 391 198 558 minecraft:obsidian
fill 391 198 557 392 203 557 minecraft:purple_terracotta
fill 391 198 598 393 198 598 minecraft:obsidian
fill 393 198 557 394 199 557 minecraft:purple_concrete
fill 393 198 558 395 198 558 minecraft:obsidian
fill 393 198 599 393 199 599 minecraft:purple_concrete
fill 395 198 598 397 198 598 minecraft:obsidian
fill 395 198 599 395 203 599 minecraft:purple_terracotta
fill 396 198 599 397 198 599 minecraft:purple_concrete
fill 397 198 558 399 198 558 minecraft:obsidian
fill 398 198 599 398 203 599 minecraft:purple_terracotta
fill 399 198 598 401 198 598 minecraft:obsidian
fill 400 198 557 400 203 557 minecraft:purple_terracotta
fill 401 198 558 403 198 558 minecraft:obsidian
setblock 402 198 557 minecraft:purple_concrete
fill 403 198 557 404 203 557 minecraft:purple_terracotta
fill 403 198 598 405 198 598 minecraft:obsidian
fill 404 198 599 405 199 599 minecraft:purple_concrete
fill 405 198 557 405 199 557 minecraft:purple_concrete
fill 405 198 558 407 198 558 minecraft:obsidian
fill 406 198 565 408 202 567 minecraft:purple_concrete
fill 406 198 568 407 198 569 minecraft:black_concrete
fill 406 198 599 407 203 599 minecraft:purple_terracotta
fill 407 198 570 407 199 570 minecraft:black_concrete
fill 407 198 598 409 198 598 minecraft:obsidian
fill 409 198 558 411 198 558 minecraft:obsidian
setblock 409 198 565 minecraft:black_concrete
fill 411 198 557 412 203 557 minecraft:purple_terracotta
fill 411 198 598 413 198 598 minecraft:obsidian
setblock 412 198 569 minecraft:black_concrete
fill 413 198 557 414 199 557 minecraft:purple_concrete
fill 413 198 558 415 198 558 minecraft:obsidian
fill 415 198 598 417 198 598 minecraft:obsidian
fill 416 198 599 417 198 599 minecraft:purple_concrete
fill 417 198 558 417 198 560 minecraft:obsidian
fill 417 198 562 417 198 564 minecraft:obsidian
fill 417 198 566 417 198 568 minecraft:obsidian
fill 417 198 570 417 198 572 minecraft:obsidian
fill 417 198 574 417 198 576 minecraft:obsidian
fill 417 198 578 417 198 580 minecraft:obsidian
fill 417 198 582 417 198 584 minecraft:obsidian
fill 417 198 586 417 198 588 minecraft:obsidian
fill 417 198 590 417 198 592 minecraft:obsidian
fill 417 198 594 417 198 596 minecraft:obsidian
fill 418 198 560 418 201 560 minecraft:purple_terracotta
setblock 418 198 561 minecraft:purple_concrete
fill 418 198 562 418 203 563 minecraft:purple_terracotta
fill 418 198 564 418 199 565 minecraft:purple_concrete
fill 418 198 570 418 200 571 minecraft:purple_terracotta
fill 418 198 572 418 198 573 minecraft:purple_concrete
fill 418 198 574 418 203 574 minecraft:purple_terracotta
fill 418 198 576 418 199 576 minecraft:purple_concrete
setblock 418 198 577 minecraft:purple_terracotta
fill 418 198 582 418 203 583 minecraft:purple_terracotta
fill 418 198 584 418 199 585 minecraft:purple_concrete
fill 418 198 591 418 203 591 minecraft:purple_terracotta
setblock 418 198 593 minecraft:purple_concrete
fill 418 198 594 418 203 595 minecraft:purple_terracotta
fill 418 198 596 418 199 596 minecraft:purple_concrete
fill 418 198 599 418 203 599 minecraft:purple_terracotta
setblock 376 199 563 minecraft:purple_concrete
fill 376 199 567 376 202 567 minecraft:purple_terracotta
fill 376 199 583 376 199 584 minecraft:purple_concrete
setblock 376 199 587 minecraft:purple_concrete
fill 376 199 588 376 202 588 minecraft:purple_terracotta
fill 376 199 599 376 202 599 minecraft:purple_terracotta
fill 381 199 557 381 202 557 minecraft:purple_terracotta
setblock 381 199 599 minecraft:purple_concrete
setblock 382 199 557 minecraft:purple_concrete
fill 385 199 557 386 199 557 minecraft:purple_concrete
setblock 392 199 599 minecraft:purple_concrete
fill 396 199 599 397 202 599 minecraft:purple_terracotta
fill 402 199 557 402 202 557 minecraft:purple_terracotta
fill 405 199 564 405 204 567 minecraft:purple_concrete
setblock 405 199 568 minecraft:black_concrete
setblock 406 199 557 minecraft:purple_concrete
fill 406 199 564 408 202 564 minecraft:purple_concrete
fill 406 199 568 408 201 568 minecraft:purple_concrete
fill 406 199 569 411 199 569 minecraft:black_concrete
fill 408 199 570 410 199 570 minecraft:black_concrete
fill 409 199 565 409 201 567 minecraft:purple_concrete
fill 409 199 568 411 199 568 minecraft:black_concrete
fill 410 199 567 410 200 567 minecraft:black_concrete
setblock 413 199 599 minecraft:purple_concrete
setblock 416 199 599 minecraft:purple_concrete
setblock 417 199 557 minecraft:purple_concrete
fill 417 199 599 417 202 599 minecraft:purple_terracotta
fill 418 199 561 418 201 561 minecraft:purple_terracotta
fill 418 199 572 418 202 572 minecraft:purple_terracotta
setblock 418 199 573 minecraft:purple_concrete
setblock 418 199 577 minecraft:purple_concrete
fill 418 199 593 418 202 593 minecraft:purple_terracotta
setblock 418 199 597 minecraft:purple_concrete
fill 376 200 561 376 201 562 minecraft:purple_concrete
fill 376 200 563 376 205 564 minecraft:purple_terracotta
fill 376 200 573 376 200 574 minecraft:purple_concrete
fill 376 200 575 376 205 576 minecraft:purple_terracotta
fill 376 200 582 376 201 582 minecraft:purple_concrete
fill 376 200 583 376 205 584 minecraft:purple_terracotta
setblock 376 200 585 minecraft:purple_concrete
fill 376 200 587 376 205 587 minecraft:purple_terracotta
fill 376 200 593 376 201 594 minecraft:purple_concrete
fill 376 200 595 376 205 596 minecraft:purple_terracotta
fill 381 200 599 381 205 599 minecraft:purple_terracotta
fill 382 200 557 382 205 557 minecraft:purple_terracotta
fill 382 200 599 383 200 599 minecraft:purple_concrete
setblock 384 200 557 minecraft:purple_concrete
fill 384 200 599 385 205 599 minecraft:purple_terracotta
fill 385 200 557 386 205 557 minecraft:purple_terracotta
fill 387 200 557 387 201 557 minecraft:purple_concrete
fill 387 200 589 387 201 589 minecraft:amethyst_block
fill 390 200 599 391 201 599 minecraft:purple_concrete
fill 392 200 599 393 205 599 minecraft:purple_terracotta
fill 393 200 557 394 205 557 minecraft:purple_terracotta
setblock 394 200 599 minecraft:purple_concrete
fill 395 200 557 396 200 557 minecraft:purple_concrete
fill 402 200 599 403 201 599 minecraft:purple_concrete
fill 404 200 564 404 204 567 minecraft:purple_concrete
fill 404 200 599 405 205 599 minecraft:purple_terracotta
fill 405 200 557 406 205 557 minecraft:purple_terracotta
fill 405 200 568 405 202 568 minecraft:purple_concrete
fill 406 200 563 406 204 563 minecraft:purple_concrete
fill 406 200 569 410 200 569 minecraft:black_concrete
fill 407 200 557 408 201 557 minecraft:purple_concrete
fill 409 200 568 410 200 568 minecraft:black_concrete
fill 411 200 599 411 201 599 minecraft:purple_concrete
fill 412 200 567 412 201 567 minecraft:obsidian
fill 413 200 557 414 202 557 minecraft:purple_terracotta
fill 413 200 599 413 205 599 minecraft:purple_terracotta
fill 414 200 599 415 200 599 minecraft:purple_concrete
fill 415 200 557 416 200 557 minecraft:purple_concrete
fill 416 200 599 416 205 599 minecraft:purple_terracotta
fill 417 200 557 417 205 557 minecraft:purple_terracotta
fill 418 200 558 418 201 558 minecraft:purple_concrete
setblock 418 200 559 minecraft:purple_terracotta
fill 418 200 564 418 205 565 minecraft:purple_terracotta
fill 418 200 566 418 201 567 minecraft:purple_concrete
fill 418 200 573 418 202 573 minecraft:purple_terracotta
setblock 418 200 575 minecraft:purple_concrete
fill 418 200 576 418 205 577 minecraft:purple_terracotta
fill 418 200 578 418 201 579 minecraft:purple_concrete
fill 418 200 584 418 205 585 minecraft:purple_terracotta
fill 418 200 586 418 200 587 minecraft:purple_concrete
fill 418 200 596 418 205 597 minecraft:purple_terracotta
fill 418 200 598 418 201 598 minecraft:purple_concrete
setblock 376 201 570 minecraft:purple_concrete
setblock 376 201 573 minecraft:purple_concrete
fill 376 201 574 376 204 574 minecraft:purple_terracotta
setblock 376 201 581 minecraft:purple_concrete
fill 376 201 585 376 204 585 minecraft:purple_terracotta
fill 378 201 599 379 201 599 minecraft:purple_concrete
setblock 382 201 599 minecraft:purple_concrete
fill 383 201 599 383 204 599 minecraft:purple_terracotta
fill 384 201 557 384 204 557 minecraft:purple_terracotta
setblock 388 201 557 minecraft:purple_concrete
fill 394 201 599 394 204 599 minecraft:purple_terracotta
fill 395 201 557 395 204 557 minecraft:purple_terracotta
setblock 396 201 557 minecraft:purple_concrete
setblock 399 201 557 minecraft:purple_concrete
setblock 399 201 599 minecraft:purple_concrete
fill 403 201 563 403 205 566 minecraft:purple_concrete
fill 404 201 563 405 206 563 minecraft:purple_concrete
fill 407 201 563 407 202 563 minecraft:purple_concrete
setblock 408 201 569 minecraft:black_concrete
setblock 409 201 568 minecraft:black_concrete
setblock 410 201 599 minecraft:purple_concrete
fill 414 201 599 415 204 599 minecraft:purple_terracotta
fill 415 201 557 415 204 557 minecraft:purple_terracotta
setblock 416 201 557 minecraft:purple_concrete
setblock 418 201 559 minecraft:purple_concrete
setblock 418 201 570 minecraft:purple_concrete
fill 418 201 571 418 203 571 minecraft:purple_terracotta
fill 418 201 575 418 204 575 minecraft:purple_terracotta
fill 418 201 586 418 204 586 minecraft:purple_terracotta
setblock 418 201 587 minecraft:purple_concrete
setblock 418 201 590 minecraft:purple_concrete
fill 376 202 559 376 203 560 minecraft:purple_concrete
fill 376 202 561 376 207 562 minecraft:purple_terracotta
fill 376 202 568 376 203 568 minecraft:purple_concrete
fill 376 202 570 376 207 570 minecraft:purple_terracotta
fill 376 202 571 376 202 572 minecraft:purple_concrete
fill 376 202 573 376 207 573 minecraft:purple_terracotta
fill 376 202 579 376 203 580 minecraft:purple_concrete
fill 376 202 581 376 207 582 minecraft:purple_terracotta
fill 376 202 591 376 202 592 minecraft:purple_concrete
fill 376 202 593 376 207 594 minecraft:purple_terracotta
fill 377 202 557 378 202 557 minecraft:purple_concrete
fill 377 202 599 377 203 599 minecraft:purple_concrete
fill 378 202 599 379 207 599 minecraft:purple_terracotta
setblock 380 202 599 minecraft:purple_concrete
fill 382 202 599 382 207 599 minecraft:purple_terracotta
fill 387 202 557 388 207 557 minecraft:purple_terracotta
fill 387 202 589 387 211 589 minecraft:obsidian
fill 388 202 599 389 203 599 minecraft:purple_concrete
fill 389 202 557 390 203 557 minecraft:purple_concrete
fill 390 202 599 391 207 599 minecraft:purple_terracotta
fill 396 202 557 396 207 557 minecraft:purple_terracotta
fill 397 202 557 398 202 557 minecraft:purple_concrete
fill 399 202 557 399 207 557 minecraft:purple_terracotta
fill 399 202 599 399 207 599 minecraft:purple_terracotta
fill 400 202 599 401 202 599 minecraft:purple_concrete
fill 401 202 557 401 203 557 minecraft:purple_concrete
fill 402 202 563 402 207 565 minecraft:purple_concrete
fill 402 202 599 403 207 599 minecraft:purple_terracotta
fill 403 202 562 405 205 562 minecraft:purple_concrete
fill 406 202 568 407 202 568 minecraft:purple_concrete
fill 407 202 557 408 207 557 minecraft:purple_terracotta
fill 408 202 599 409 203 599 minecraft:purple_concrete
fill 409 202 557 410 203 557 minecraft:purple_concrete
setblock 409 202 566 minecraft:purple_concrete
fill 410 202 599 411 207 599 minecraft:purple_terracotta
setblock 412 202 599 minecraft:purple_concrete
fill 416 202 557 416 204 557 minecraft:purple_terracotta
setblock 418 202 557 minecraft:purple_concrete
fill 418 202 558 418 207 559 minecraft:purple_terracotta
fill 418 202 560 418 203 561 minecraft:purple_concrete
fill 418 202 566 418 207 567 minecraft:purple_terracotta
fill 418 202 568 418 202 569 minecraft:purple_concrete
fill 418 202 570 418 203 570 minecraft:purple_terracotta
fill 418 202 578 418 207 579 minecraft:purple_terracotta
fill 418 202 580 418 203 581 minecraft:purple_concrete
fill 418 202 587 418 207 587 minecraft:purple_terracotta
fill 418 202 588 418 202 589 minecraft:purple_concrete
fill 418 202 590 418 207 590 minecraft:purple_terracotta
fill 418 202 592 418 203 592 minecraft:purple_concrete
fill 418 202 598 418 207 598 minecraft:purple_terracotta
setblock 376 203 567 minecraft:purple_concrete
fill 376 203 571 376 206 572 minecraft:purple_terracotta
setblock 376 203 588 minecraft:purple_concrete
setblock 376 203 591 minecraft:purple_concrete
fill 376 203 592 376 206 592 minecraft:purple_terracotta
setblock 376 203 599 minecraft:purple_concrete
fill 377 203 557 377 206 557 minecraft:purple_terracotta
setblock 378 203 557 minecraft:purple_concrete
fill 380 203 599 380 206 599 minecraft:purple_terracotta
setblock 381 203 557 minecraft:purple_concrete
fill 396 203 599 397 203 599 minecraft:purple_concrete
fill 397 203 557 398 206 557 minecraft:purple_terracotta
setblock 400 203 599 minecraft:purple_concrete
fill 401 203 562 401 207 565 minecraft:purple_concrete
fill 401 203 599 401 206 599 minecraft:purple_terracotta
setblock 402 203 557 minecraft:purple_concrete
fill 402 203 562 402 208 562 minecraft:purple_concrete
fill 402 203 566 402 206 566 minecraft:purple_concrete
fill 406 203 564 407 203 567 minecraft:purple_concrete
fill 408 203 565 408 203 566 minecraft:purple_concrete
fill 412 203 599 412 206 599 minecraft:purple_terracotta
setblock 413 203 557 minecraft:purple_concrete
fill 414 203 557 414 205 557 minecraft:purple_terracotta
setblock 417 203 599 minecraft:purple_concrete
fill 418 203 557 418 206 557 minecraft:purple_terracotta
fill 418 203 568 418 206 568 minecraft:purple_terracotta
setblock 418 203 569 minecraft:purple_concrete
fill 418 203 572 418 203 573 minecraft:purple_concrete
fill 418 203 588 418 205 589 minecraft:purple_terracotta
setblock 418 203 593 minecraft:purple_concrete
fill 376 204 557 376 204 558 minecraft:purple_concrete
fill 376 204 559 376 209 560 minecraft:purple_terracotta
fill 376 204 565 376 205 566 minecraft:purple_concrete
fill 376 204 567 376 209 568 minecraft:purple_terracotta
setblock 376 204 569 minecraft:purple_concrete
fill 376 204 577 376 205 578 minecraft:purple_concrete
fill 376 204 579 376 207 580 minecraft:purple_terracotta
fill 376 204 586 376 205 586 minecraft:purple_concrete
fill 376 204 588 376 209 588 minecraft:purple_terracotta
fill 376 204 589 376 204 590 minecraft:purple_concrete
fill 376 204 591 376 209 591 minecraft:purple_terracotta
fill 376 204 597 376 205 598 minecraft:purple_concrete
fill 376 204 599 377 209 599 minecraft:purple_terracotta
fill 377 204 558 379 204 558 minecraft:obsidian
fill 377 204 560 377 204 562 minecraft:obsidian
fill 377 204 564 377 204 566 minecraft:obsidian
fill 377 204 568 377 204 570 minecraft:obsidian
fill 377 204 572 377 204 574 minecraft:obsidian
fill 377 204 576 377 204 578 minecraft:obsidian
fill 377 204 580 377 204 582 minecraft:obsidian
fill 377 204 584 377 204 586 minecraft:obsidian
fill 377 204 588 377 204 590 minecraft:obsidian
fill 377 204 592 377 204 594 minecraft:obsidian
fill 377 204 596 377 204 598 minecraft:obsidian
fill 378 204 557 378 208 557 minecraft:purple_terracotta
fill 379 204 557 380 204 557 minecraft:purple_concrete
fill 379 204 598 381 204 598 minecraft:obsidian
fill 381 204 557 381 209 557 minecraft:purple_terracotta
fill 381 204 558 383 204 558 minecraft:obsidian
fill 383 204 557 383 205 557 minecraft:purple_concrete
fill 383 204 598 385 204 598 minecraft:obsidian
fill 385 204 558 387 204 558 minecraft:obsidian
fill 386 204 589 386 211 590 minecraft:obsidian
fill 386 204 599 387 204 599 minecraft:purple_concrete
fill 387 204 588 387 211 588 minecraft:obsidian
fill 387 204 590 387 211 590 minecraft:obsidian
fill 387 204 598 389 204 598 minecraft:obsidian
fill 388 204 589 388 211 589 minecraft:obsidian
fill 388 204 599 389 207 599 minecraft:purple_terracotta
fill 389 204 557 390 209 557 minecraft:purple_terracotta
fill 389 204 558 391 204 558 minecraft:obsidian
fill 391 204 557 392 205 557 minecraft:purple_concrete
fill 391 204 598 393 204 598 minecraft:obsidian
fill 393 204 558 395 204 558 minecraft:obsidian
fill 395 204 598 397 204 598 minecraft:obsidian
fill 395 204 599 395 205 599 minecraft:purple_concrete
fill 396 204 599 397 209 599 minecraft:purple_terracotta
fill 397 204 558 399 204 558 minecraft:obsidian
setblock 398 204 599 minecraft:purple_concrete
fill 399 204 598 401 204 598 minecraft:obsidian
setblock 400 204 557 minecraft:purple_concrete
fill 400 204 562 400 206 565 minecraft:purple_concrete
fill 400 204 599 400 209 599 minecraft:purple_terracotta
fill 401 204 557 402 207 557 minecraft:purple_terracotta
fill 401 204 558 403 204 558 minecraft:obsidian
fill 402 204 561 403 206 561 minecraft:purple_concrete
fill 403 204 557 404 205 557 minecraft:purple_concrete
fill 403 204 598 405 204 598 minecraft:obsidian
fill 405 204 558 407 204 558 minecraft:obsidian
fill 406 204 564 406 204 566 minecraft:purple_concrete
fill 406 204 599 407 205 599 minecraft:purple_concrete
setblock 407 204 565 minecraft:purple_concrete
fill 407 204 566 407 207 566 minecraft:amethyst_block
fill 407 204 598 409 204 598 minecraft:obsidian
fill 408 204 599 409 209 599 minecraft:purple_terracotta
fill 409 204 557 410 209 557 minecraft:purple_terracotta
fill 409 204 558 411 204 558 minecraft:obsidian
fill 411 204 557 412 204 557 minecraft:purple_concrete
fill 411 204 598 413 204 598 minecraft:obsidian
fill 413 204 557 413 209 557 minecraft:purple_terracotta
fill 413 204 558 415 204 558 minecraft:obsidian
fill 415 204 598 417 204 598 minecraft:obsidian
fill 417 204 558 417 204 560 minecraft:obsidian
fill 417 204 562 417 204 564 minecraft:obsidian
fill 417 204 566 417 204 568 minecraft:obsidian
fill 417 204 570 417 204 572 minecraft:obsidian
fill 417 204 574 417 204 576 minecraft:obsidian
fill 417 204 578 417 204 580 minecraft:obsidian
fill 417 204 582 417 204 584 minecraft:obsidian
fill 417 204 586 417 204 588 minecraft:obsidian
fill 417 204 590 417 204 592 minecraft:obsidian
fill 417 204 594 417 204 596 minecraft:obsidian
fill 417 204 599 417 209 599 minecraft:purple_terracotta
fill 418 204 560 418 209 561 minecraft:purple_terracotta
fill 418 204 562 418 205 563 minecraft:purple_concrete
fill 418 204 569 418 208 569 minecraft:purple_terracotta
fill 418 204 570 418 204 571 minecraft:purple_concrete
fill 418 204 572 418 205 573 minecraft:purple_terracotta
fill 418 204 574 418 205 574 minecraft:purple_concrete
fill 418 204 580 418 207 581 minecraft:purple_terracotta
fill 418 204 582 418 205 583 minecraft:purple_concrete
setblock 418 204 591 minecraft:purple_concrete
fill 418 204 592 418 209 593 minecraft:purple_terracotta
fill 418 204 594 418 205 595 minecraft:purple_concrete
fill 418 204 599 418 205 599 minecraft:purple_concrete
setblock 376 205 557 minecraft:purple_concrete
fill 376 205 558 376 208 558 minecraft:purple_terracotta
fill 376 205 569 376 208 569 minecraft:purple_terracotta
setblock 376 205 574 minecraft:purple_concrete
setblock 376 205 585 minecraft:purple_concrete
fill 376 205 589 376 208 590 minecraft:purple_terracotta
fill 379 205 557 380 208 557 minecraft:purple_terracotta
setblock 379 205 560 minecraft:light[level=12]
setblock 379 205 568 minecraft:light[level=12]
setblock 379 205 576 minecraft:light[level=12]
setblock 379 205 584 minecraft:light[level=12]
setblock 379 205 592 minecraft:light[level=12]
setblock 383 205 599 minecraft:purple_concrete
setblock 384 205 557 minecraft:purple_concrete
fill 386 205 588 386 211 588 minecraft:obsidian
setblock 386 205 599 minecraft:purple_concrete
setblock 387 205 560 minecraft:light[level=12]
setblock 387 205 568 minecraft:light[level=12]
setblock 387 205 576 minecraft:light[level=12]
setblock 387 205 584 minecraft:light[level=12]
setblock 387 205 592 minecraft:light[level=12]
fill 387 205 599 387 208 599 minecraft:purple_terracotta
fill 388 205 588 388 211 588 minecraft:obsidian
fill 388 205 590 388 211 590 minecraft:obsidian
setblock 394 205 599 minecraft:purple_concrete
setblock 395 205 557 minecraft:purple_concrete
setblock 395 205 560 minecraft:light[level=12]
setblock 395 205 568 minecraft:light[level=12]
setblock 395 205 576 minecraft:light[level=12]
setblock 395 205 584 minecraft:light[level=12]
setblock 395 205 592 minecraft:light[level=12]
fill 398 205 599 398 208 599 minecraft:purple_terracotta
fill 399 205 562 399 205 564 minecraft:purple_concrete
fill 400 205 557 400 208 557 minecraft:purple_terracotta
fill 400 205 561 401 206 561 minecraft:purple_concrete
fill 401 205 566 401 206 566 minecraft:purple_concrete
setblock 403 205 560 minecraft:light[level=12]
setblock 403 205 568 minecraft:light[level=12]
setblock 403 205 576 minecraft:light[level=12]
setblock 403 205 584 minecraft:light[level=12]
setblock 403 205 592 minecraft:light[level=12]
fill 404 205 564 405 205 566 minecraft:purple_concrete
fill 406 205 564 406 205 565 minecraft:purple_concrete
fill 406 205 566 406 206 566 minecraft:amethyst_block
fill 411 205 557 411 208 557 minecraft:purple_terracotta
setblock 411 205 560 minecraft:light[level=12]
setblock 411 205 568 minecraft:light[level=12]
setblock 411 205 576 minecraft:light[level=12]
setblock 411 205 584 minecraft:light[level=12]
setblock 411 205 592 minecraft:light[level=12]
setblock 412 205 557 minecraft:purple_concrete
fill 414 205 599 415 205 599 minecraft:purple_concrete
fill 415 205 557 416 205 557 minecraft:purple_concrete
fill 418 205 570 418 207 571 minecraft:purple_terracotta
setblock 418 205 575 minecraft:purple_concrete
setblock 418 205 586 minecraft:purple_concrete
fill 418 205 591 418 207 591 minecraft:purple_terracotta
fill 376 206 557 376 209 557 minecraft:purple_terracotta
fill 376 206 563 376 207 564 minecraft:purple_concrete
fill 376 206 565 376 207 566 minecraft:purple_terracotta
fill 376 206 574 376 211 574 minecraft:purple_terracotta
fill 376 206 575 376 206 576 minecraft:purple_concrete
fill 376 206 577 376 211 578 minecraft:purple_terracotta
fill 376 206 583 376 207 584 minecraft:purple_concrete
fill 376 206 585 376 209 586 minecraft:purple_terracotta
setblock 376 206 587 minecraft:purple_concrete
fill 376 206 595 376 207 596 minecraft:purple_concrete
fill 376 206 597 376 208 598 minecraft:purple_terracotta
fill 381 206 599 381 207 599 minecraft:purple_concrete
setblock 382 206 557 minecraft:purple_concrete
fill 383 206 557 384 209 557 minecraft:purple_terracotta
fill 383 206 599 383 211 599 minecraft:purple_terracotta
fill 384 206 599 385 206 599 minecraft:purple_concrete
fill 385 206 557 386 207 557 minecraft:purple_concrete
fill 385 206 589 385 211 590 minecraft:obsidian
fill 386 206 591 388 211 591 minecraft:obsidian
fill 386 206 599 386 211 599 minecraft:purple_terracotta
fill 387 206 587 387 211 587 minecraft:obsidian
fill 389 206 589 389 211 590 minecraft:obsidian
fill 391 206 557 392 209 557 minecraft:purple_terracotta
fill 392 206 599 393 207 599 minecraft:purple_concrete
fill 393 206 557 394 206 557 minecraft:purple_concrete
fill 394 206 599 395 209 599 minecraft:purple_terracotta
fill 395 206 557 395 209 557 minecraft:purple_terracotta
setblock 397 206 563 minecraft:purple_concrete
fill 398 206 561 399 206 561 minecraft:purple_concrete
fill 398 206 562 399 211 563 minecraft:black_concrete
fill 398 206 564 399 206 564 minecraft:purple_concrete
fill 399 206 565 399 207 565 minecraft:purple_concrete
fill 403 206 557 404 211 557 minecraft:purple_terracotta
fill 403 206 562 403 207 565 minecraft:purple_concrete
setblock 404 206 562 minecraft:purple_concrete
fill 404 206 564 404 206 565 minecraft:purple_concrete
fill 404 206 599 405 206 599 minecraft:purple_concrete
fill 405 206 557 406 207 557 minecraft:purple_concrete
setblock 405 206 564 minecraft:purple_concrete
fill 406 206 599 407 211 599 minecraft:purple_terracotta
fill 412 206 557 412 207 557 minecraft:purple_terracotta
fill 413 206 599 413 207 599 minecraft:purple_concrete
setblock 414 206 557 minecraft:purple_concrete
fill 414 206 599 415 209 599 minecraft:purple_terracotta
fill 415 206 557 416 211 557 minecraft:purple_terracotta
setblock 416 206 599 minecraft:purple_concrete
fill 417 206 557 417 207 557 minecraft:purple_concrete
fill 418 206 562 418 211 563 minecraft:purple_terracotta
fill 418 206 564 418 207 565 minecraft:purple_concrete
fill 418 206 572 418 208 572 minecraft:purple_terracotta
setblock 418 206 573 minecraft:purple_concrete
fill 418 206 574 418 208 575 minecraft:purple_terracotta
fill 418 206 576 418 207 577 minecraft:purple_concrete
fill 418 206 582 418 208 583 minecraft:purple_terracotta
fill 418 206 584 418 206 585 minecraft:purple_concrete
fill 418 206 586 418 211 586 minecraft:purple_terracotta
fill 418 206 588 418 207 588 minecraft:purple_concrete
setblock 418 206 589 minecraft:purple_terracotta
fill 418 206 594 418 209 595 minecraft:purple_terracotta
fill 418 206 596 418 207 597 minecraft:purple_concrete
fill 418 206 599 418 208 599 minecraft:purple_terracotta
fill 376 207 571 376 207 572 minecraft:purple_concrete
setblock 376 207 575 minecraft:purple_concrete
fill 376 207 576 376 210 576 minecraft:purple_terracotta
fill 376 207 587 376 210 587 minecraft:purple_terracotta
setblock 376 207 592 minecraft:purple_concrete
setblock 377 207 557 minecraft:purple_concrete
setblock 380 207 599 minecraft:purple_concrete
fill 382 207 557 382 210 557 minecraft:purple_terracotta
fill 384 207 599 385 209 599 minecraft:purple_terracotta
fill 385 207 588 385 211 588 minecraft:obsidian
fill 385 207 591 385 211 591 minecraft:obsidian
fill 386 207 587 386 211 587 minecraft:obsidian
fill 388 207 587 388 211 587 minecraft:obsidian
fill 389 207 588 389 211 588 minecraft:obsidian
fill 393 207 557 393 210 557 minecraft:purple_terracotta
setblock 394 207 557 minecraft:purple_concrete
fill 396 207 562 397 210 563 minecraft:black_concrete
fill 397 207 557 398 207 557 minecraft:purple_concrete
fill 397 207 561 400 210 561 minecraft:black_concrete
fill 397 207 564 400 210 564 minecraft:black_concrete
setblock 398 207 565 minecraft:purple_concrete
fill 400 207 562 400 210 563 minecraft:black_concrete
fill 400 207 565 400 209 565 minecraft:purple_concrete
fill 401 207 561 402 207 561 minecraft:purple_concrete
setblock 401 207 599 minecraft:purple_concrete
fill 404 207 563 404 207 564 minecraft:purple_concrete
setblock 404 207 599 minecraft:purple_concrete
fill 405 207 599 405 210 599 minecraft:purple_terracotta
setblock 412 207 599 minecraft:purple_concrete
fill 414 207 557 414 210 557 minecraft:purple_terracotta
fill 416 207 599 416 210 599 minecraft:purple_terracotta
setblock 418 207 557 minecraft:purple_concrete
setblock 418 207 568 minecraft:purple_concrete
setblock 418 207 573 minecraft:purple_terracotta
fill 418 207 584 418 210 584 minecraft:purple_terracotta
setblock 418 207 585 minecraft:purple_concrete
setblock 418 207 589 minecraft:purple_concrete
fill 376 208 561 376 208 562 minecraft:purple_concrete
fill 376 208 563 376 208 564 minecraft:purple_terracotta
setblock 376 208 565 minecraft:black_concrete
fill 376 208 566 376 211 566 minecraft:purple_terracotta
fill 376 208 570 376 209 570 minecraft:purple_concrete
fill 376 208 571 376 211 571 minecraft:purple_terracotta
setblock 376 208 572 minecraft:black_concrete
setblock 376 208 573 minecraft:purple_concrete
fill 376 208 575 376 211 575 minecraft:purple_terracotta
fill 376 208 579 376 209 579 minecraft:purple_terracotta
setblock 376 208 580 minecraft:black_concrete
fill 376 208 581 376 209 582 minecraft:purple_concrete
fill 376 208 583 376 211 584 minecraft:purple_terracotta
fill 376 208 592 376 211 592 minecraft:purple_terracotta
fill 376 208 593 376 208 594 minecraft:purple_concrete
fill 376 208 595 376 209 596 minecraft:purple_terracotta
fill 377 208 557 377 211 557 minecraft:purple_terracotta
fill 378 208 599 379 209 599 minecraft:purple_concrete
fill 380 208 599 381 211 599 minecraft:purple_terracotta
setblock 382 208 599 minecraft:purple_concrete
fill 384 208 588 384 211 590 minecraft:obsidian
fill 385 208 557 385 213 557 minecraft:purple_terracotta
fill 385 208 587 385 211 587 minecraft:obsidian
setblock 386 208 557 minecraft:black_concrete
fill 386 208 592 388 211 592 minecraft:obsidian
fill 387 208 557 388 209 557 minecraft:purple_concrete
fill 388 208 599 388 209 599 minecraft:purple_terracotta
fill 389 208 587 389 211 587 minecraft:obsidian
fill 389 208 591 389 211 591 minecraft:obsidian
setblock 389 208 599 minecraft:black_concrete
fill 390 208 589 390 211 590 minecraft:obsidian
fill 390 208 599 391 209 599 minecraft:purple_concrete
fill 392 208 599 393 211 599 minecraft:purple_terracotta
fill 394 208 557 394 211 557 minecraft:purple_terracotta
fill 395 208 562 395 210 563 minecraft:black_concrete
setblock 396 208 557 minecraft:purple_concrete
fill 396 208 561 396 213 561 minecraft:black_concrete
fill 396 208 564 396 211 564 minecraft:black_concrete
fill 397 208 557 398 208 557 minecraft:purple_terracotta
fill 397 208 565 399 209 565 minecraft:black_concrete
fill 398 208 560 399 209 560 minecraft:black_concrete
fill 399 208 557 399 209 557 minecraft:purple_concrete
fill 399 208 599 399 209 599 minecraft:purple_concrete
setblock 401 208 557 minecraft:black_concrete
setblock 401 208 561 minecraft:purple_concrete
fill 401 208 562 401 209 563 minecraft:black_concrete
fill 401 208 564 401 208 565 minecraft:purple_concrete
fill 401 208 599 401 209 599 minecraft:purple_terracotta
fill 402 208 557 402 209 557 minecraft:purple_terracotta
fill 402 208 563 402 208 564 minecraft:purple_concrete
fill 402 208 599 403 208 599 minecraft:purple_concrete
setblock 403 208 563 minecraft:purple_concrete
fill 404 208 599 404 211 599 minecraft:purple_terracotta
fill 405 208 557 406 211 557 minecraft:purple_terracotta
fill 407 208 557 408 208 557 minecraft:purple_concrete
fill 410 208 599 411 209 599 minecraft:purple_concrete
setblock 412 208 557 minecraft:black_concrete
fill 412 208 599 413 211 599 minecraft:purple_terracotta
fill 417 208 557 418 208 557 minecraft:black_concrete
fill 418 208 558 418 209 559 minecraft:purple_concrete
fill 418 208 564 418 210 565 minecraft:purple_terracotta
fill 418 208 566 418 208 567 minecraft:purple_concrete
fill 418 208 568 418 209 568 minecraft:purple_terracotta
fill 418 208 570 418 209 570 minecraft:purple_concrete
setblock 418 208 571 minecraft:purple_terracotta
setblock 418 208 573 minecraft:black_concrete
fill 418 208 576 418 208 577 minecraft:purple_terracotta
fill 418 208 578 418 209 579 minecraft:purple_concrete
setblock 418 208 580 minecraft:black_concrete
fill 418 208 581 418 209 581 minecraft:purple_terracotta
setblock 418 208 585 minecraft:black_concrete
setblock 418 208 587 minecraft:purple_concrete
setblock 418 208 588 minecraft:black_concrete
setblock 418 208 589 minecraft:purple_terracotta
fill 418 208 590 418 209 591 minecraft:purple_concrete
fill 418 208 596 418 211 597 minecraft:purple_terracotta
setblock 418 208 598 minecraft:purple_concrete
setblock 376 209 558 minecraft:purple_concrete
setblock 376 209 561 minecraft:purple_concrete
fill 376 209 562 376 211 563 minecraft:purple_terracotta
setblock 376 209 564 minecraft:black_concrete
fill 376 209 565 376 211 565 minecraft:purple_terracotta
setblock 376 209 569 minecraft:purple_concrete
fill 376 209 572 376 211 573 minecraft:purple_terracotta
setblock 376 209 580 minecraft:purple_terracotta
fill 376 209 589 376 209 590 minecraft:purple_concrete
setblock 376 209 593 minecraft:purple_concrete
setblock 376 209 594 minecraft:purple_terracotta
fill 376 209 597 376 211 597 minecraft:purple_terracotta
fill 376 209 598 376 210 598 minecraft:black_concrete
setblock 378 209 557 minecraft:black_concrete
fill 379 209 557 380 209 557 minecraft:purple_concrete
fill 382 209 599 382 211 599 minecraft:purple_terracotta
fill 384 209 587 384 211 587 minecraft:obsidian
fill 384 209 591 384 211 591 minecraft:obsidian
fill 385 209 592 385 211 592 minecraft:obsidian
setblock 386 209 557 minecraft:purple_terracotta
fill 386 209 586 388 211 586 minecraft:obsidian
setblock 387 209 599 minecraft:purple_concrete
fill 389 209 592 389 211 592 minecraft:obsidian
setblock 389 209 599 minecraft:purple_terracotta
fill 390 209 588 390 211 588 minecraft:obsidian
fill 390 209 591 390 211 591 minecraft:obsidian
fill 394 209 562 394 209 563 minecraft:black_concrete
fill 395 209 561 395 210 561 minecraft:black_concrete
fill 395 209 564 395 210 564 minecraft:black_concrete
setblock 396 209 557 minecraft:purple_terracotta
fill 396 209 565 396 212 565 minecraft:black_concrete
setblock 397 209 557 minecraft:black_concrete
fill 397 209 560 397 210 560 minecraft:black_concrete
fill 398 209 557 398 211 557 minecraft:purple_terracotta
setblock 398 209 599 minecraft:purple_concrete
setblock 400 209 557 minecraft:purple_concrete
setblock 401 209 557 minecraft:purple_terracotta
setblock 401 209 564 minecraft:purple_concrete
setblock 402 209 599 minecraft:black_concrete
fill 403 209 599 403 211 599 minecraft:purple_terracotta
fill 407 209 557 407 211 557 minecraft:purple_terracotta
setblock 408 209 557 minecraft:purple_concrete
setblock 411 209 557 minecraft:purple_concrete
fill 412 209 557 412 211 557 minecraft:purple_terracotta
fill 417 209 557 417 211 557 minecraft:purple_terracotta
setblock 418 209 557 minecraft:black_concrete
fill 418 209 566 418 211 566 minecraft:purple_terracotta
setblock 418 209 567 minecraft:purple_concrete
setblock 418 209 569 minecraft:black_concrete
setblock 418 209 571 minecraft:purple_concrete
setblock 418 209 572 minecraft:black_concrete
fill 418 209 573 418 209 574 minecraft:purple_terracotta
setblock 418 209 575 minecraft:black_concrete
fill 418 209 576 418 211 576 minecraft:purple_terracotta
setblock 418 209 577 minecraft:black_concrete
setblock 418 209 580 minecraft:purple_terracotta
setblock 418 209 582 minecraft:purple_concrete
fill 418 209 583 418 211 583 minecraft:purple_terracotta
fill 418 209 585 418 210 585 minecraft:purple_terracotta
fill 418 209 587 418 211 588 minecraft:purple_terracotta
fill 418 209 589 418 210 589 minecraft:black_concrete
fill 418 209 598 418 212 598 minecraft:purple_terracotta
setblock 418 209 599 minecraft:black_concrete
setblock 376 210 557 minecraft:black_concrete
fill 376 210 558 376 211 558 minecraft:purple_terracotta
fill 376 210 559 376 210 560 minecraft:purple_concrete
fill 376 210 561 376 211 561 minecraft:purple_terracotta
fill 376 210 564 376 211 564 minecraft:purple_terracotta
fill 376 210 567 376 211 568 minecraft:purple_concrete
fill 376 210 569 376 211 570 minecraft:purple_terracotta
fill 376 210 579 376 210 580 minecraft:purple_concrete
fill 376 210 581 376 211 582 minecraft:purple_terracotta
fill 376 210 585 376 211 585 minecraft:purple_terracotta
setblock 376 210 586 minecraft:black_concrete
fill 376 210 588 376 211 588 minecraft:purple_concrete
fill 376 210 589 376 211 590 minecraft:purple_terracotta
setblock 376 210 591 minecraft:purple_concrete
fill 376 210 593 376 211 593 minecraft:purple_terracotta
setblock 376 210 594 minecraft:black_concrete
fill 376 210 595 376 211 595 minecraft:purple_terracotta
setblock 376 210 596 minecraft:black_concrete
fill 376 210 599 377 211 599 minecraft:purple_concrete
fill 377 210 558 379 210 558 minecraft:obsidian
fill 377 210 560 377 210 562 minecraft:obsidian
fill 377 210 564 377 210 566 minecraft:obsidian
fill 377 210 568 377 210 570 minecraft:obsidian
fill 377 210 572 377 210 574 minecraft:obsidian
fill 377 210 576 377 210 578 minecraft:obsidian
fill 377 210 580 377 210 582 minecraft:obsidian
fill 377 210 584 377 210 586 minecraft:obsidian
fill 377 210 588 377 210 590 minecraft:obsidian
fill 377 210 592 377 210 594 minecraft:obsidian
fill 377 210 596 377 210 598 minecraft:obsidian
setblock 378 210 557 minecraft:purple_concrete
fill 378 210 599 379 211 599 minecraft:purple_terracotta
fill 379 210 557 380 211 557 minecraft:purple_terracotta
fill 379 210 598 381 210 598 minecraft:obsidian
fill 381 210 557 381 211 557 minecraft:purple_concrete
fill 381 210 558 383 210 558 minecraft:obsidian
fill 383 210 557 383 211 557 minecraft:purple_terracotta
fill 383 210 588 383 211 590 minecraft:obsidian
fill 383 210 598 385 210 598 minecraft:obsidian
setblock 384 210 557 minecraft:black_concrete
fill 384 210 592 384 211 592 minecraft:obsidian
setblock 384 210 599 minecraft:black_concrete
fill 385 210 558 387 210 558 minecraft:obsidian
fill 385 210 586 385 211 586 minecraft:obsidian
setblock 385 210 599 minecraft:purple_terracotta
setblock 386 210 557 minecraft:black_concrete
fill 386 210 593 388 211 593 minecraft:obsidian
fill 387 210 557 388 211 557 minecraft:purple_terracotta
fill 387 210 598 389 210 598 minecraft:obsidian
fill 387 210 599 387 211 599 minecraft:purple_terracotta
fill 388 210 599 389 210 599 minecraft:purple_concrete
fill 389 210 557 390 210 557 minecraft:purple_concrete
fill 389 210 558 391 210 558 minecraft:obsidian
fill 389 210 586 389 211 586 minecraft:obsidian
fill 390 210 587 390 211 587 minecraft:obsidian
fill 390 210 592 390 211 592 minecraft:obsidian
setblock 390 210 599 minecraft:black_concrete
setblock 391 210 557 minecraft:black_concrete
fill 391 210 589 391 211 590 minecraft:obsidian
fill 391 210 598 393 210 598 minecraft:obsidian
fill 391 210 599 391 212 599 minecraft:purple_terracotta
fill 392 210 557 392 211 557 minecraft:purple_terracotta
fill 393 210 558 395 210 558 minecraft:obsidian
setblock 393 210 562 minecraft:black_concrete
fill 393 210 563 394 216 563 minecraft:purple_concrete
fill 393 210 564 394 210 564 minecraft:black_concrete
setblock 394 210 561 minecraft:black_concrete
fill 394 210 562 394 215 562 minecraft:purple_concrete
setblock 394 210 599 minecraft:black_concrete
fill 395 210 557 396 210 557 minecraft:black_concrete
fill 395 210 565 395 211 565 minecraft:black_concrete
fill 395 210 598 397 210 598 minecraft:obsidian
fill 395 210 599 395 211 599 minecraft:purple_terracotta
fill 396 210 560 396 211 560 minecraft:black_concrete
fill 396 210 599 397 211 599 minecraft:purple_concrete
fill 397 210 557 397 211 557 minecraft:purple_terracotta
fill 397 210 558 399 210 558 minecraft:obsidian
fill 397 210 565 398 210 565 minecraft:black_concrete
setblock 398 210 560 minecraft:black_concrete
setblock 398 210 599 minecraft:black_concrete
fill 399 210 557 400 211 557 minecraft:purple_terracotta
fill 399 210 598 401 210 598 minecraft:obsidian
fill 399 210 599 399 211 599 minecraft:purple_terracotta
setblock 400 210 599 minecraft:purple_concrete
fill 401 210 557 402 211 557 minecraft:purple_concrete
fill 401 210 558 403 210 558 minecraft:obsidian
setblock 401 210 599 minecraft:black_concrete
fill 402 210 599 402 211 599 minecraft:purple_terracotta
fill 403 210 598 405 210 598 minecraft:obsidian
fill 405 210 558 407 210 558 minecraft:obsidian
fill 407 210 598 409 210 598 minecraft:obsidian
fill 408 210 557 408 211 557 minecraft:purple_terracotta
fill 408 210 599 409 211 599 minecraft:purple_concrete
fill 409 210 557 410 210 557 minecraft:purple_concrete
fill 409 210 558 411 210 558 minecraft:obsidian
setblock 410 210 599 minecraft:black_concrete
setblock 411 210 557 minecraft:black_concrete
fill 411 210 598 413 210 598 minecraft:obsidian
fill 411 210 599 411 211 599 minecraft:purple_terracotta
fill 413 210 557 413 211 557 minecraft:purple_concrete
fill 413 210 558 415 210 558 minecraft:obsidian
setblock 414 210 599 minecraft:black_concrete
fill 415 210 598 417 210 598 minecraft:obsidian
fill 415 210 599 415 211 599 minecraft:purple_terracotta
fill 417 210 558 417 210 560 minecraft:obsidian
fill 417 210 562 417 210 564 minecraft:obsidian
fill 417 210 566 417 210 568 minecraft:obsidian
fill 417 210 570 417 210 572 minecraft:obsidian
fill 417 210 574 417 210 576 minecraft:obsidian
fill 417 210 578 417 210 580 minecraft:obsidian
fill 417 210 582 417 210 584 minecraft:obsidian
fill 417 210 586 417 210 588 minecraft:obsidian
fill 417 210 590 417 210 592 minecraft:obsidian
fill 417 210 594 417 210 596 minecraft:obsidian
fill 417 210 599 417 211 599 minecraft:purple_concrete
fill 418 210 557 418 211 559 minecraft:purple_terracotta
fill 418 210 560 418 211 561 minecraft:purple_concrete
fill 418 210 567 418 211 567 minecraft:purple_terracotta
setblock 418 210 568 minecraft:black_concrete
setblock 418 210 569 minecraft:purple_concrete
fill 418 210 570 418 211 571 minecraft:purple_terracotta
fill 418 210 572 418 211 573 minecraft:purple_concrete
fill 418 210 574 418 211 575 minecraft:purple_terracotta
fill 418 210 577 418 211 579 minecraft:purple_terracotta
fill 418 210 580 418 210 581 minecraft:purple_concrete
fill 418 210 582 418 211 582 minecraft:purple_terracotta
fill 418 210 590 418 211 591 minecraft:purple_terracotta
fill 418 210 592 418 211 593 minecraft:purple_concrete
setblock 418 210 594 minecraft:black_concrete
fill 418 210 595 418 211 595 minecraft:purple_terracotta
fill 418 210 599 418 211 599 minecraft:purple_terracotta
setblock 376 211 557 minecraft:purple_terracotta
fill 376 211 559 376 211 560 minecraft:purple_terracotta
setblock 376 211 576 minecraft:purple_concrete
setblock 376 211 579 minecraft:purple_concrete
setblock 376 211 580 minecraft:purple_terracotta
setblock 376 211 586 minecraft:purple_terracotta
setblock 376 211 587 minecraft:purple_concrete
setblock 376 211 591 minecraft:purple_terracotta
setblock 376 211 594 minecraft:purple_terracotta
setblock 376 211 596 minecraft:purple_terracotta
setblock 376 211 598 minecraft:purple_terracotta
setblock 378 211 557 minecraft:purple_terracotta
setblock 382 211 557 minecraft:purple_concrete
setblock 383 211 587 minecraft:obsidian
setblock 383 211 591 minecraft:obsidian
setblock 384 211 557 minecraft:purple_terracotta
setblock 384 211 586 minecraft:obsidian
fill 384 211 599 385 211 599 minecraft:purple_concrete
fill 385 211 585 388 211 585 minecraft:obsidian
setblock 385 211 593 minecraft:obsidian
setblock 386 211 557 minecraft:purple_terracotta
setblock 388 211 599 minecraft:purple_concrete
setblock 389 211 557 minecraft:purple_terracotta
setblock 389 211 593 minecraft:obsidian
fill 389 211 599 390 211 599 minecraft:purple_terracotta
setblock 390 211 557 minecraft:purple_concrete
setblock 390 211 586 minecraft:obsidian
setblock 391 211 557 minecraft:purple_terracotta
fill 391 211 587 391 211 588 minecraft:obsidian
setblock 391 211 591 minecraft:obsidian
fill 392 211 562 392 217 564 minecraft:purple_concrete
setblock 393 211 557 minecraft:purple_concrete
fill 393 211 561 393 215 562 minecraft:purple_concrete
fill 393 211 564 394 215 565 minecraft:purple_concrete
fill 394 211 561 395 214 561 minecraft:purple_concrete
setblock 394 211 599 minecraft:purple_terracotta
fill 395 211 557 396 211 557 minecraft:purple_terracotta
setblock 395 211 560 minecraft:black_concrete
fill 395 211 562 395 215 564 minecraft:purple_concrete
fill 396 211 562 397 211 562 minecraft:black_concrete
fill 396 211 563 396 214 563 minecraft:purple_concrete
fill 397 211 561 398 211 561 minecraft:black_concrete
fill 397 211 563 397 211 565 minecraft:black_concrete
fill 398 211 564 399 211 564 minecraft:black_concrete
fill 398 211 599 398 212 599 minecraft:purple_terracotta
fill 400 211 599 401 211 599 minecraft:purple_terracotta
setblock 405 211 599 minecraft:purple_concrete
fill 409 211 557 411 211 557 minecraft:purple_terracotta
setblock 410 211 599 minecraft:purple_terracotta
setblock 414 211 557 minecraft:purple_concrete
setblock 414 211 599 minecraft:purple_terracotta
setblock 416 211 599 minecraft:purple_concrete
setblock 418 211 564 minecraft:purple_concrete
setblock 418 211 565 minecraft:purple_terracotta
fill 418 211 568 418 212 569 minecraft:purple_terracotta
fill 418 211 580 418 212 580 minecraft:purple_terracotta
setblock 418 211 581 minecraft:purple_concrete
fill 418 211 584 418 211 585 minecraft:purple_concrete
fill 418 211 589 418 212 589 minecraft:purple_terracotta
setblock 418 211 594 minecraft:purple_terracotta
setblock 376 212 557 minecraft:purple_concrete
fill 376 212 558 376 212 564 minecraft:black_concrete
fill 376 212 565 376 213 566 minecraft:purple_concrete
fill 376 212 567 376 213 569 minecraft:black_concrete
setblock 376 212 570 minecraft:purple_terracotta
fill 376 212 571 376 212 573 minecraft:black_concrete
fill 376 212 574 376 213 574 minecraft:purple_concrete
fill 376 212 575 376 213 576 minecraft:black_concrete
fill 376 212 577 376 212 578 minecraft:purple_concrete
fill 376 212 579 376 213 584 minecraft:black_concrete
fill 376 212 585 376 213 586 minecraft:purple_concrete
fill 376 212 587 376 212 588 minecraft:purple_terracotta
fill 376 212 589 376 212 596 minecraft:black_concrete
fill 376 212 597 376 212 598 minecraft:purple_concrete
fill 376 212 599 382 212 599 minecraft:black_concrete
fill 377 212 557 382 213 557 minecraft:black_concrete
fill 383 212 557 384 213 557 minecraft:purple_concrete
fill 383 212 599 383 213 599 minecraft:purple_concrete
fill 384 212 599 385 212 599 minecraft:black_concrete
fill 386 212 557 390 213 557 minecraft:black_concrete
fill 386 212 589 387 212 590 minecraft:amethyst_block
setblock 386 212 599 minecraft:purple_concrete
setblock 387 212 588 minecraft:amethyst_block
fill 387 212 599 390 212 599 minecraft:black_concrete
setblock 388 212 589 minecraft:amethyst_block
fill 391 212 557 392 212 557 minecraft:purple_concrete
fill 391 212 562 391 217 564 minecraft:purple_concrete
fill 392 212 561 392 215 561 minecraft:purple_concrete
fill 392 212 565 392 217 565 minecraft:purple_concrete
fill 392 212 599 393 213 599 minecraft:black_concrete
fill 393 212 557 394 213 557 minecraft:black_concrete
fill 394 212 599 395 213 599 minecraft:purple_concrete
fill 395 212 557 395 213 557 minecraft:purple_concrete
fill 395 212 565 395 214 565 minecraft:purple_concrete
fill 396 212 557 401 212 557 minecraft:black_concrete
fill 396 212 562 396 214 562 minecraft:purple_concrete
fill 396 212 564 396 213 564 minecraft:purple_concrete
fill 396 212 599 397 217 599 minecraft:black_concrete
fill 397 212 561 397 212 564 minecraft:black_concrete
fill 398 212 562 398 212 564 minecraft:black_concrete
fill 399 212 599 405 212 599 minecraft:black_concrete
setblock 402 212 557 minecraft:purple_terracotta
fill 403 212 557 404 213 557 minecraft:purple_concrete
fill 405 212 557 411 212 557 minecraft:black_concrete
fill 406 212 599 407 212 599 minecraft:purple_concrete
fill 408 212 599 413 213 599 minecraft:black_concrete
setblock 412 212 557 minecraft:purple_concrete
fill 413 212 557 414 217 557 minecraft:black_concrete
fill 414 212 599 415 213 599 minecraft:purple_concrete
fill 415 212 557 416 213 557 minecraft:purple_concrete
fill 416 212 599 416 217 599 minecraft:black_concrete
fill 417 212 557 418 212 557 minecraft:black_concrete
setblock 417 212 599 minecraft:purple_terracotta
fill 418 212 558 418 212 561 minecraft:black_concrete
fill 418 212 562 418 212 563 minecraft:purple_concrete
fill 418 212 564 418 212 567 minecraft:black_concrete
fill 418 212 570 418 215 572 minecraft:black_concrete
setblock 418 212 573 minecraft:purple_terracotta
fill 418 212 574 418 213 575 minecraft:purple_concrete
fill 418 212 576 418 213 579 minecraft:black_concrete
fill 418 212 581 418 217 581 minecraft:black_concrete
fill 418 212 582 418 212 583 minecraft:purple_concrete
fill 418 212 584 418 213 585 minecraft:black_concrete
fill 418 212 586 418 213 586 minecraft:purple_concrete
fill 418 212 587 418 212 588 minecraft:black_concrete
fill 418 212 590 418 215 593 minecraft:black_concrete
fill 418 212 594 418 213 595 minecraft:purple_concrete
fill 418 212 596 418 213 597 minecraft:black_concrete
setblock 418 212 599 minecraft:purple_concrete
fill 376 213 557 376 214 561 minecraft:black_concrete
setblock 376 213 562 minecraft:purple_concrete
fill 376 213 563 376 213 564 minecraft:black_concrete
fill 376 213 570 376 213 572 minecraft:black_concrete
setblock 376 213 573 minecraft:purple_concrete
fill 376 213 577 376 216 578 minecraft:black_concrete
fill 376 213 587 376 213 591 minecraft:black_concrete
setblock 376 213 592 minecraft:purple_terracotta
fill 376 213 593 376 215 593 minecraft:black_concrete
setblock 376 213 594 minecraft:purple_concrete
fill 376 213 595 376 213 596 minecraft:black_concrete
setblock 376 213 597 minecraft:purple_concrete
fill 376 213 598 376 216 598 minecraft:black_concrete
fill 376 213 599 376 214 599 minecraft:purple_terracotta
fill 377 213 599 381 213 599 minecraft:black_concrete
setblock 379 213 560 minecraft:light[level=12]
setblock 379 213 568 minecraft:light[level=12]
setblock 379 213 576 minecraft:light[level=12]
setblock 379 213 584 minecraft:light[level=12]
setblock 379 213 592 minecraft:light[level=12]
setblock 382 213 599 minecraft:purple_concrete
fill 384 213 599 384 217 599 minecraft:black_concrete
setblock 385 213 599 minecraft:purple_terracotta
fill 386 213 589 387 213 589 minecraft:amethyst_block
fill 386 213 599 388 215 599 minecraft:black_concrete
setblock 387 213 560 minecraft:light[level=12]
setblock 387 213 568 minecraft:light[level=12]
setblock 387 213 576 minecraft:light[level=12]
setblock 387 213 584 minecraft:light[level=12]
setblock 387 213 590 minecraft:amethyst_block
setblock 387 213 592 minecraft:light[level=12]
setblock 389 213 599 minecraft:purple_terracotta
fill 390 213 563 390 219 565 minecraft:purple_concrete
fill 390 213 599 391 213 599 minecraft:black_concrete
fill 391 213 557 392 213 557 minecraft:black_concrete
fill 391 213 565 391 219 565 minecraft:purple_concrete
fill 392 213 566 392 217 566 minecraft:purple_concrete
setblock 395 213 560 minecraft:light[level=12]
setblock 395 213 568 minecraft:light[level=12]
setblock 395 213 576 minecraft:light[level=12]
setblock 395 213 584 minecraft:light[level=12]
setblock 395 213 592 minecraft:light[level=12]
setblock 396 213 557 minecraft:purple_concrete
fill 397 213 557 398 213 557 minecraft:black_concrete
fill 397 213 562 397 213 564 minecraft:black_concrete
fill 398 213 599 399 213 599 minecraft:black_concrete
setblock 399 213 557 minecraft:purple_terracotta
fill 400 213 557 402 215 557 minecraft:black_concrete
setblock 400 213 599 minecraft:purple_terracotta
setblock 401 213 599 minecraft:black_concrete
fill 402 213 599 403 213 599 minecraft:purple_concrete
setblock 403 213 560 minecraft:light[level=12]
setblock 403 213 568 minecraft:light[level=12]
setblock 403 213 576 minecraft:light[level=12]
setblock 403 213 584 minecraft:light[level=12]
setblock 403 213 592 minecraft:light[level=12]
fill 404 213 599 405 213 599 minecraft:black_concrete
fill 405 213 557 406 213 557 minecraft:black_concrete
setblock 406 213 599 minecraft:purple_concrete
setblock 407 213 557 minecraft:purple_concrete
fill 407 213 599 407 216 599 minecraft:black_concrete
fill 408 213 557 412 214 557 minecraft:black_concrete
setblock 411 213 560 minecraft:light[level=12]
setblock 411 213 568 minecraft:light[level=12]
setblock 411 213 576 minecraft:light[level=12]
setblock 411 213 584 minecraft:light[level=12]
setblock 411 213 592 minecraft:light[level=12]
setblock 417 213 557 minecraft:purple_terracotta
fill 417 213 599 418 213 599 minecraft:black_concrete
fill 418 213 557 418 213 559 minecraft:black_concrete
setblock 418 213 560 minecraft:purple_terracotta
fill 418 213 561 418 216 562 minecraft:black_concrete
setblock 418 213 563 minecraft:purple_concrete
fill 418 213 564 418 213 565 minecraft:black_concrete
fill 418 213 566 418 213 567 minecraft:purple_concrete
fill 418 213 568 418 213 569 minecraft:black_concrete
fill 418 213 573 418 217 573 minecraft:black_concrete
setblock 418 213 580 minecraft:black_concrete
fill 418 213 582 418 215 583 minecraft:black_concrete
setblock 418 213 587 minecraft:purple_concrete
fill 418 213 588 418 213 589 minecraft:black_concrete
setblock 418 213 598 minecraft:purple_concrete
fill 376 214 562 376 219 562 minecraft:black_concrete
fill 376 214 563 376 214 564 minecraft:purple_concrete
fill 376 214 565 376 219 566 minecraft:black_concrete
setblock 376 214 567 minecraft:purple_terracotta
fill 376 214 568 376 215 570 minecraft:black_concrete
fill 376 214 571 376 215 572 minecraft:purple_concrete
fill 376 214 573 376 219 574 minecraft:black_concrete
setblock 376 214 575 minecraft:purple_concrete
fill 376 214 576 376 217 576 minecraft:black_concrete
fill 376 214 579 376 214 581 minecraft:black_concrete
setblock 376 214 582 minecraft:purple_terracotta
fill 376 214 583 376 215 584 minecraft:purple_concrete
fill 376 214 585 376 219 586 minecraft:black_concrete
setblock 376 214 587 minecraft:purple_terracotta
fill 376 214 588 376 214 591 minecraft:black_concrete
fill 376 214 592 376 215 592 minecraft:purple_concrete
setblock 376 214 594 minecraft:purple_terracotta
fill 376 214 595 376 214 596 minecraft:purple_concrete
fill 376 214 597 376 219 597 minecraft:black_concrete
fill 377 214 557 377 215 557 minecraft:purple_concrete
fill 377 214 599 379 215 599 minecraft:black_concrete
fill 378 214 557 381 214 557 minecraft:black_concrete
fill 380 214 599 381 215 599 minecraft:purple_concrete
setblock 382 214 557 minecraft:purple_terracotta
fill 382 214 599 383 219 599 minecraft:black_concrete
fill 383 214 557 384 219 557 minecraft:black_concrete
fill 385 214 557 386 215 557 minecraft:purple_concrete
fill 385 214 599 385 217 599 minecraft:black_concrete
fill 387 214 557 390 214 557 minecraft:black_concrete
fill 387 214 589 387 216 589 minecraft:amethyst_block
fill 389 214 563 389 219 565 minecraft:purple_concrete
setblock 389 214 599 minecraft:black_concrete
fill 390 214 562 390 217 562 minecraft:purple_concrete
fill 390 214 566 391 218 566 minecraft:purple_concrete
setblock 390 214 599 minecraft:purple_terracotta
setblock 391 214 557 minecraft:purple_terracotta
fill 391 214 561 391 215 561 minecraft:purple_concrete
fill 391 214 599 391 215 599 minecraft:black_concrete
fill 392 214 557 393 216 557 minecraft:black_concrete
fill 392 214 599 393 214 599 minecraft:purple_concrete
fill 393 214 566 393 215 566 minecraft:purple_concrete
setblock 394 214 557 minecraft:purple_concrete
fill 394 214 599 395 219 599 minecraft:black_concrete
fill 395 214 557 396 219 557 minecraft:black_concrete
setblock 396 214 564 minecraft:black_concrete
fill 397 214 557 398 215 557 minecraft:purple_concrete
fill 398 214 599 398 215 599 minecraft:black_concrete
fill 399 214 557 399 215 557 minecraft:black_concrete
setblock 399 214 599 minecraft:purple_terracotta
setblock 400 214 599 minecraft:black_concrete
fill 401 214 599 401 215 599 minecraft:purple_concrete
fill 402 214 599 403 219 599 minecraft:black_concrete
fill 403 214 557 404 219 557 minecraft:black_concrete
setblock 404 214 599 minecraft:purple_concrete
fill 405 214 557 406 214 557 minecraft:purple_concrete
fill 405 214 599 406 217 599 minecraft:black_concrete
fill 407 214 557 407 219 557 minecraft:black_concrete
fill 408 214 599 408 217 599 minecraft:black_concrete
setblock 409 214 599 minecraft:purple_terracotta
fill 410 214 599 411 215 599 minecraft:black_concrete
fill 412 214 599 413 215 599 minecraft:purple_concrete
fill 414 214 599 415 219 599 minecraft:black_concrete
fill 415 214 557 416 219 557 minecraft:black_concrete
fill 417 214 557 418 215 557 minecraft:purple_concrete
fill 417 214 599 418 214 599 minecraft:purple_terracotta
fill 418 214 558 418 215 560 minecraft:black_concrete
fill 418 214 563 418 217 564 minecraft:black_concrete
setblock 418 214 565 minecraft:purple_concrete
fill 418 214 566 418 219 567 minecraft:black_concrete
fill 418 214 568 418 215 568 minecraft:purple_concrete
setblock 418 214 569 minecraft:black_concrete
fill 418 214 574 418 219 575 minecraft:black_concrete
fill 418 214 576 418 215 577 minecraft:purple_concrete
fill 418 214 578 418 215 579 minecraft:black_concrete
setblock 418 214 580 minecraft:purple_terracotta
fill 418 214 584 418 217 584 minecraft:black_concrete
setblock 418 214 585 minecraft:purple_concrete
fill 418 214 586 418 219 587 minecraft:black_concrete
fill 418 214 588 418 215 589 minecraft:purple_concrete
fill 418 214 594 418 216 595 minecraft:black_concrete
fill 418 214 596 418 214 597 minecraft:purple_concrete
fill 418 214 598 418 219 598 minecraft:black_concrete
fill 376 215 557 376 215 558 minecraft:black_concrete
fill 376 215 559 376 215 560 minecraft:purple_concrete
setblock 376 215 561 minecraft:black_concrete
setblock 376 215 563 minecraft:purple_concrete
fill 376 215 564 376 218 564 minecraft:black_concrete
fill 376 215 567 376 217 567 minecraft:black_concrete
fill 376 215 575 376 218 575 minecraft:black_concrete
fill 376 215 579 376 217 579 minecraft:black_concrete
setblock 376 215 580 minecraft:purple_concrete
fill 376 215 581 376 215 582 minecraft:black_concrete
fill 376 215 587 376 215 590 minecraft:black_concrete
setblock 376 215 591 minecraft:purple_concrete
schedule function dropper:buildpart/140_4 1t
