fill 145 264 510 145 269 510 minecraft:obsidian
fill 155 264 552 155 269 552 minecraft:obsidian
setblock 156 264 552 minecraft:crying_obsidian
fill 161 264 510 161 269 510 minecraft:obsidian
fill 171 264 552 171 269 552 minecraft:obsidian
fill 177 264 510 177 269 510 minecraft:obsidian
setblock 177 264 524 minecraft:amethyst_block
setblock 178 264 510 minecraft:white_concrete
fill 183 264 520 183 269 520 minecraft:obsidian
fill 183 264 523 183 304 523 minecraft:obsidian
fill 183 264 536 183 268 536 minecraft:obsidian
fill 183 264 545 183 307 545 minecraft:obsidian
fill 141 265 513 141 307 513 minecraft:obsidian
fill 156 265 552 156 294 552 minecraft:obsidian
fill 178 265 510 178 307 510 minecraft:obsidian
setblock 141 266 533 minecraft:white_concrete
setblock 144 266 510 minecraft:white_concrete
setblock 152 266 510 minecraft:white_concrete
fill 161 266 515 161 267 517 minecraft:crying_obsidian
fill 162 266 515 162 267 516 minecraft:crying_obsidian
setblock 183 266 511 minecraft:white_concrete
setblock 141 267 521 minecraft:white_concrete
fill 141 267 533 141 307 533 minecraft:obsidian
setblock 141 267 546 minecraft:crying_obsidian
fill 144 267 510 144 282 510 minecraft:obsidian
fill 152 267 510 152 307 510 minecraft:obsidian
setblock 155 267 510 minecraft:white_concrete
setblock 161 267 552 minecraft:white_concrete
fill 183 267 511 183 289 511 minecraft:obsidian
fill 141 268 521 141 280 521 minecraft:obsidian
setblock 141 268 538 minecraft:white_concrete
fill 141 268 546 141 307 546 minecraft:obsidian
fill 155 268 510 155 307 510 minecraft:obsidian
fill 161 268 552 161 307 552 minecraft:obsidian
fill 141 269 538 141 290 538 minecraft:obsidian
fill 180 269 510 181 269 510 minecraft:crying_obsidian
setblock 180 269 552 minecraft:amethyst_block
setblock 183 269 536 minecraft:crying_obsidian
fill 141 270 518 141 272 518 minecraft:purple_stained_glass
fill 141 270 519 141 291 519 minecraft:obsidian
fill 141 270 534 141 272 534 minecraft:purple_stained_glass
fill 141 270 550 141 272 550 minecraft:purple_stained_glass
fill 145 270 510 145 272 510 minecraft:purple_stained_glass
fill 155 270 552 155 272 552 minecraft:purple_stained_glass
fill 158 270 520 159 271 521 minecraft:crying_obsidian
fill 161 270 510 161 272 510 minecraft:purple_stained_glass
fill 171 270 552 171 272 552 minecraft:purple_stained_glass
setblock 172 270 552 minecraft:crying_obsidian
fill 177 270 510 177 272 510 minecraft:purple_stained_glass
setblock 177 270 552 minecraft:crying_obsidian
fill 180 270 510 181 299 510 minecraft:obsidian
fill 180 270 552 180 288 552 minecraft:obsidian
fill 183 270 520 183 272 520 minecraft:purple_stained_glass
fill 183 270 536 183 272 536 minecraft:purple_stained_glass
setblock 183 270 550 minecraft:white_concrete
setblock 144 271 513 minecraft:light[level=12]
setblock 144 271 521 minecraft:light[level=12]
setblock 144 271 529 minecraft:light[level=12]
setblock 144 271 537 minecraft:light[level=12]
setblock 144 271 545 minecraft:light[level=12]
setblock 152 271 513 minecraft:light[level=12]
setblock 152 271 521 minecraft:light[level=12]
setblock 152 271 529 minecraft:light[level=12]
setblock 152 271 537 minecraft:light[level=12]
setblock 152 271 545 minecraft:light[level=12]
setblock 160 271 513 minecraft:light[level=12]
setblock 160 271 521 minecraft:light[level=12]
setblock 160 271 529 minecraft:light[level=12]
setblock 160 271 537 minecraft:light[level=12]
setblock 160 271 545 minecraft:light[level=12]
setblock 168 271 513 minecraft:light[level=12]
setblock 168 271 521 minecraft:light[level=12]
setblock 168 271 529 minecraft:light[level=12]
setblock 168 271 537 minecraft:light[level=12]
setblock 168 271 545 minecraft:light[level=12]
fill 172 271 552 172 281 552 minecraft:obsidian
setblock 176 271 513 minecraft:light[level=12]
setblock 176 271 521 minecraft:light[level=12]
setblock 176 271 529 minecraft:light[level=12]
setblock 176 271 537 minecraft:light[level=12]
setblock 176 271 545 minecraft:light[level=12]
fill 177 271 552 177 299 552 minecraft:obsidian
setblock 183 271 549 minecraft:white_concrete
fill 183 271 550 183 284 550 minecraft:obsidian
setblock 149 272 510 minecraft:crying_obsidian
setblock 168 272 552 minecraft:amethyst_block
fill 183 272 549 183 279 549 minecraft:obsidian
fill 141 273 518 141 287 518 minecraft:obsidian
fill 141 273 534 141 287 534 minecraft:obsidian
fill 141 273 550 141 287 550 minecraft:obsidian
fill 145 273 510 145 287 510 minecraft:obsidian
setblock 146 273 510 minecraft:amethyst_block
fill 149 273 510 149 307 510 minecraft:obsidian
fill 155 273 552 155 287 552 minecraft:obsidian
setblock 157 273 510 minecraft:amethyst_block
fill 161 273 510 161 287 510 minecraft:obsidian
fill 168 273 552 168 307 552 minecraft:obsidian
fill 171 273 552 171 287 552 minecraft:obsidian
fill 177 273 510 177 287 510 minecraft:obsidian
fill 183 273 520 183 287 520 minecraft:obsidian
fill 183 273 536 183 287 536 minecraft:obsidian
fill 146 274 510 146 293 510 minecraft:obsidian
setblock 150 274 510 minecraft:amethyst_block
setblock 151 274 510 minecraft:white_concrete
fill 157 274 510 157 295 510 minecraft:obsidian
setblock 160 274 510 minecraft:amethyst_block
setblock 183 274 518 minecraft:amethyst_block
fill 150 275 510 151 303 510 minecraft:obsidian
fill 160 275 510 160 307 510 minecraft:obsidian
setblock 167 275 510 minecraft:crying_obsidian
setblock 179 275 510 minecraft:amethyst_block
setblock 183 275 512 minecraft:amethyst_block
fill 183 275 518 183 291 518 minecraft:obsidian
setblock 141 276 514 minecraft:crying_obsidian
fill 167 276 510 167 307 510 minecraft:obsidian
setblock 173 276 552 minecraft:amethyst_block
fill 179 276 510 179 303 510 minecraft:obsidian
fill 183 276 512 183 307 512 minecraft:obsidian
fill 141 277 514 141 307 514 minecraft:obsidian
setblock 141 277 520 minecraft:crying_obsidian
setblock 141 277 531 minecraft:crying_obsidian
setblock 142 277 552 minecraft:amethyst_block
fill 143 277 552 144 282 552 minecraft:obsidian
setblock 145 277 552 minecraft:crying_obsidian
setblock 163 277 552 minecraft:crying_obsidian
fill 173 277 552 173 307 552 minecraft:obsidian
fill 141 278 520 141 307 520 minecraft:obsidian
fill 141 278 525 141 307 525 minecraft:obsidian
setblock 141 278 526 minecraft:amethyst_block
fill 141 278 527 141 284 527 minecraft:obsidian
fill 141 278 531 141 307 531 minecraft:obsidian
setblock 141 278 536 minecraft:white_concrete
fill 142 278 552 142 279 552 minecraft:obsidian
fill 145 278 552 145 307 552 minecraft:obsidian
setblock 150 278 552 minecraft:crying_obsidian
fill 163 278 552 163 286 552 minecraft:obsidian
setblock 164 278 510 minecraft:crying_obsidian
fill 141 279 526 141 286 526 minecraft:obsidian
fill 141 279 536 141 307 536 minecraft:obsidian
setblock 144 279 513 minecraft:light[level=12]
setblock 144 279 521 minecraft:light[level=12]
setblock 144 279 529 minecraft:light[level=12]
setblock 144 279 537 minecraft:light[level=12]
setblock 144 279 545 minecraft:light[level=12]
fill 146 279 519 147 279 545 minecraft:obsidian
fill 148 279 519 172 279 520 minecraft:obsidian
fill 148 279 521 156 279 543 minecraft:purple_stained_glass
fill 148 279 544 172 279 545 minecraft:obsidian
fill 150 279 552 150 299 552 minecraft:obsidian
setblock 152 279 513 minecraft:light[level=12]
fill 157 279 521 157 279 531 minecraft:purple_stained_glass
fill 157 279 533 157 279 543 minecraft:purple_stained_glass
fill 158 279 521 158 279 530 minecraft:purple_stained_glass
fill 158 279 534 158 279 543 minecraft:purple_stained_glass
fill 159 279 521 170 279 529 minecraft:purple_stained_glass
fill 159 279 535 170 279 543 minecraft:purple_stained_glass
setblock 160 279 513 minecraft:light[level=12]
fill 160 279 530 170 279 530 minecraft:purple_stained_glass
fill 160 279 534 170 279 534 minecraft:purple_stained_glass
fill 161 279 531 170 279 531 minecraft:purple_stained_glass
fill 161 279 533 170 279 533 minecraft:purple_stained_glass
fill 162 279 532 170 279 532 minecraft:purple_stained_glass
fill 164 279 510 164 307 510 minecraft:obsidian
setblock 168 279 513 minecraft:light[level=12]
fill 171 279 521 172 279 543 minecraft:obsidian
setblock 176 279 513 minecraft:light[level=12]
setblock 176 279 521 minecraft:light[level=12]
setblock 176 279 529 minecraft:light[level=12]
setblock 176 279 537 minecraft:light[level=12]
setblock 176 279 545 minecraft:light[level=12]
setblock 141 280 512 minecraft:crying_obsidian
fill 142 280 511 145 280 551 minecraft:obsidian
setblock 142 280 552 minecraft:amethyst_block
fill 146 280 511 146 280 520 minecraft:obsidian
setblock 146 280 521 minecraft:crying_obsidian
fill 146 280 522 146 280 524 minecraft:obsidian
setblock 146 280 525 minecraft:crying_obsidian
fill 146 280 526 146 280 528 minecraft:obsidian
setblock 146 280 529 minecraft:crying_obsidian
fill 146 280 530 146 280 532 minecraft:obsidian
setblock 146 280 533 minecraft:crying_obsidian
fill 146 280 534 146 280 536 minecraft:obsidian
setblock 146 280 537 minecraft:crying_obsidian
fill 146 280 538 146 280 540 minecraft:obsidian
setblock 146 280 541 minecraft:crying_obsidian
fill 146 280 542 146 280 544 minecraft:obsidian
setblock 146 280 545 minecraft:crying_obsidian
fill 146 280 546 182 280 551 minecraft:obsidian
fill 147 280 511 147 280 519 minecraft:obsidian
setblock 147 280 520 minecraft:crying_obsidian
fill 147 280 521 147 280 523 minecraft:obsidian
setblock 147 280 524 minecraft:crying_obsidian
fill 147 280 525 147 280 527 minecraft:obsidian
setblock 147 280 528 minecraft:crying_obsidian
fill 147 280 529 147 280 531 minecraft:obsidian
setblock 147 280 532 minecraft:crying_obsidian
fill 147 280 533 147 280 535 minecraft:obsidian
setblock 147 280 536 minecraft:crying_obsidian
fill 147 280 537 147 280 539 minecraft:obsidian
setblock 147 280 540 minecraft:crying_obsidian
fill 147 280 541 147 280 543 minecraft:obsidian
setblock 147 280 544 minecraft:crying_obsidian
fill 147 280 545 149 280 545 minecraft:obsidian
fill 148 280 511 182 280 518 minecraft:obsidian
setblock 148 280 519 minecraft:crying_obsidian
fill 148 280 520 150 280 520 minecraft:obsidian
fill 148 280 521 155 280 543 minecraft:purple_stained_glass
fill 148 280 544 150 280 544 minecraft:obsidian
fill 149 280 519 151 280 519 minecraft:obsidian
setblock 150 280 545 minecraft:crying_obsidian
setblock 151 280 520 minecraft:crying_obsidian
setblock 151 280 544 minecraft:crying_obsidian
fill 151 280 545 153 280 545 minecraft:obsidian
setblock 152 280 519 minecraft:crying_obsidian
fill 152 280 520 154 280 520 minecraft:obsidian
fill 152 280 544 154 280 544 minecraft:obsidian
fill 153 280 519 155 280 519 minecraft:obsidian
setblock 154 280 545 minecraft:crying_obsidian
setblock 155 280 520 minecraft:crying_obsidian
setblock 155 280 544 minecraft:crying_obsidian
fill 155 280 545 157 280 545 minecraft:obsidian
setblock 156 280 519 minecraft:crying_obsidian
fill 156 280 520 158 280 520 minecraft:obsidian
fill 156 280 521 156 280 530 minecraft:purple_stained_glass
fill 156 280 531 156 280 533 minecraft:crying_obsidian
fill 156 280 534 156 280 543 minecraft:purple_stained_glass
fill 156 280 544 158 280 544 minecraft:obsidian
fill 157 280 519 159 280 519 minecraft:obsidian
fill 157 280 521 157 280 529 minecraft:purple_stained_glass
fill 157 280 530 157 280 531 minecraft:crying_obsidian
fill 157 280 533 157 280 534 minecraft:crying_obsidian
fill 157 280 535 157 280 543 minecraft:purple_stained_glass
fill 158 280 521 170 280 528 minecraft:purple_stained_glass
fill 158 280 529 158 280 530 minecraft:crying_obsidian
fill 158 280 534 158 280 535 minecraft:crying_obsidian
fill 158 280 536 170 280 543 minecraft:purple_stained_glass
setblock 158 280 545 minecraft:crying_obsidian
setblock 159 280 520 minecraft:crying_obsidian
fill 159 280 529 160 280 529 minecraft:crying_obsidian
fill 159 280 535 160 280 535 minecraft:crying_obsidian
setblock 159 280 544 minecraft:crying_obsidian
fill 159 280 545 161 280 545 minecraft:obsidian
setblock 160 280 519 minecraft:crying_obsidian
fill 160 280 520 162 280 520 minecraft:obsidian
fill 160 280 530 161 280 530 minecraft:crying_obsidian
fill 160 280 534 161 280 534 minecraft:crying_obsidian
fill 160 280 544 162 280 544 minecraft:obsidian
fill 161 280 519 163 280 519 minecraft:obsidian
fill 161 280 529 170 280 529 minecraft:purple_stained_glass
fill 161 280 531 162 280 531 minecraft:crying_obsidian
fill 161 280 533 162 280 533 minecraft:crying_obsidian
fill 161 280 535 170 280 535 minecraft:purple_stained_glass
fill 162 280 530 170 280 530 minecraft:purple_stained_glass
setblock 162 280 532 minecraft:crying_obsidian
fill 162 280 534 170 280 534 minecraft:purple_stained_glass
setblock 162 280 545 minecraft:crying_obsidian
setblock 163 280 520 minecraft:crying_obsidian
fill 163 280 531 170 280 533 minecraft:purple_stained_glass
setblock 163 280 544 minecraft:crying_obsidian
fill 163 280 545 165 280 545 minecraft:obsidian
setblock 164 280 519 minecraft:crying_obsidian
fill 164 280 520 166 280 520 minecraft:obsidian
fill 164 280 544 166 280 544 minecraft:obsidian
fill 164 280 552 164 307 552 minecraft:obsidian
fill 165 280 519 167 280 519 minecraft:obsidian
setblock 165 280 552 minecraft:crying_obsidian
setblock 166 280 510 minecraft:crying_obsidian
setblock 166 280 545 minecraft:crying_obsidian
setblock 167 280 520 minecraft:crying_obsidian
setblock 167 280 544 minecraft:crying_obsidian
fill 167 280 545 169 280 545 minecraft:obsidian
setblock 168 280 519 minecraft:crying_obsidian
fill 168 280 520 170 280 520 minecraft:obsidian
fill 168 280 544 170 280 544 minecraft:obsidian
fill 169 280 519 171 280 519 minecraft:obsidian
setblock 170 280 545 minecraft:crying_obsidian
setblock 171 280 520 minecraft:crying_obsidian
fill 171 280 521 171 280 523 minecraft:obsidian
setblock 171 280 524 minecraft:crying_obsidian
fill 171 280 525 171 280 527 minecraft:obsidian
setblock 171 280 528 minecraft:crying_obsidian
fill 171 280 529 171 280 531 minecraft:obsidian
setblock 171 280 532 minecraft:crying_obsidian
fill 171 280 533 171 280 535 minecraft:obsidian
setblock 171 280 536 minecraft:crying_obsidian
fill 171 280 537 171 280 539 minecraft:obsidian
setblock 171 280 540 minecraft:crying_obsidian
fill 171 280 541 171 280 543 minecraft:obsidian
setblock 171 280 544 minecraft:crying_obsidian
fill 171 280 545 182 280 545 minecraft:obsidian
setblock 172 280 519 minecraft:crying_obsidian
fill 172 280 520 182 280 522 minecraft:obsidian
setblock 172 280 523 minecraft:crying_obsidian
fill 172 280 524 182 280 526 minecraft:obsidian
setblock 172 280 527 minecraft:crying_obsidian
fill 172 280 528 182 280 530 minecraft:obsidian
setblock 172 280 531 minecraft:crying_obsidian
fill 172 280 532 182 280 534 minecraft:obsidian
setblock 172 280 535 minecraft:crying_obsidian
fill 172 280 536 182 280 538 minecraft:obsidian
setblock 172 280 539 minecraft:crying_obsidian
fill 172 280 540 182 280 542 minecraft:obsidian
setblock 172 280 543 minecraft:crying_obsidian
fill 172 280 544 182 280 544 minecraft:obsidian
fill 173 280 519 182 280 519 minecraft:obsidian
fill 173 280 523 182 280 523 minecraft:obsidian
fill 173 280 527 182 280 527 minecraft:obsidian
fill 173 280 531 182 280 531 minecraft:obsidian
fill 173 280 535 182 280 535 minecraft:obsidian
fill 173 280 539 182 280 539 minecraft:obsidian
fill 173 280 543 182 280 543 minecraft:obsidian
setblock 183 280 549 minecraft:amethyst_block
fill 141 281 512 141 282 512 minecraft:obsidian
setblock 141 281 521 minecraft:amethyst_block
fill 142 281 552 142 290 552 minecraft:obsidian
fill 146 281 520 148 284 520 minecraft:obsidian
fill 146 281 544 148 284 544 minecraft:obsidian
fill 147 281 519 147 284 519 minecraft:obsidian
fill 147 281 521 147 284 521 minecraft:obsidian
fill 147 281 543 147 284 543 minecraft:obsidian
fill 147 281 545 147 284 545 minecraft:obsidian
fill 165 281 552 165 307 552 minecraft:obsidian
fill 166 281 510 166 307 510 minecraft:obsidian
fill 170 281 520 172 284 520 minecraft:obsidian
fill 170 281 544 172 284 544 minecraft:obsidian
fill 171 281 519 171 284 519 minecraft:obsidian
fill 171 281 521 171 284 521 minecraft:obsidian
fill 171 281 543 171 284 543 minecraft:obsidian
fill 171 281 545 171 284 545 minecraft:obsidian
fill 183 281 549 183 290 549 minecraft:obsidian
fill 141 282 521 141 307 521 minecraft:obsidian
setblock 143 282 510 minecraft:crying_obsidian
setblock 153 282 552 minecraft:white_concrete
setblock 162 282 510 minecraft:crying_obsidian
setblock 172 282 552 minecraft:crying_obsidian
setblock 183 282 548 minecraft:crying_obsidian
setblock 141 283 512 minecraft:white_concrete
setblock 141 283 523 minecraft:white_concrete
fill 143 283 510 143 305 510 minecraft:obsidian
setblock 143 283 552 minecraft:white_concrete
setblock 144 283 510 minecraft:white_concrete
fill 144 283 552 144 287 552 minecraft:obsidian
fill 153 283 552 153 295 552 minecraft:obsidian
fill 162 283 510 162 307 510 minecraft:obsidian
fill 172 283 552 172 296 552 minecraft:obsidian
setblock 183 283 538 minecraft:white_concrete
fill 183 283 548 183 307 548 minecraft:obsidian
fill 141 284 512 141 307 512 minecraft:obsidian
fill 141 284 523 141 285 523 minecraft:obsidian
setblock 141 284 529 minecraft:white_concrete
fill 143 284 552 143 288 552 minecraft:obsidian
fill 144 284 510 144 289 510 minecraft:obsidian
fill 150 284 530 151 284 530 minecraft:obsidian
setblock 168 284 510 minecraft:white_concrete
setblock 183 284 526 minecraft:amethyst_block
setblock 183 284 532 minecraft:white_concrete
fill 183 284 538 183 307 538 minecraft:obsidian
setblock 141 285 527 minecraft:white_concrete
fill 141 285 529 141 292 529 minecraft:obsidian
fill 168 285 510 168 307 510 minecraft:obsidian
fill 183 285 526 183 307 526 minecraft:obsidian
setblock 183 285 532 minecraft:amethyst_block
setblock 183 285 550 minecraft:amethyst_block
setblock 141 286 523 minecraft:white_concrete
fill 141 286 527 141 307 527 minecraft:obsidian
setblock 165 286 510 minecraft:white_concrete
fill 183 286 532 183 307 532 minecraft:obsidian
setblock 183 286 550 minecraft:obsidian
fill 141 287 523 141 307 523 minecraft:obsidian
setblock 141 287 526 minecraft:crying_obsidian
setblock 144 287 513 minecraft:light[level=12]
setblock 144 287 521 minecraft:light[level=12]
fill 144 287 527 145 288 535 minecraft:obsidian
setblock 144 287 537 minecraft:light[level=12]
setblock 144 287 545 minecraft:light[level=12]
fill 145 287 524 146 288 526 minecraft:obsidian
fill 145 287 536 146 288 538 minecraft:obsidian
fill 146 287 522 147 288 523 minecraft:obsidian
fill 146 287 539 147 288 540 minecraft:obsidian
fill 147 287 521 148 288 521 minecraft:obsidian
fill 147 287 524 147 288 524 minecraft:obsidian
fill 147 287 538 147 288 538 minecraft:obsidian
fill 147 287 541 148 288 541 minecraft:obsidian
fill 148 287 519 149 288 520 minecraft:obsidian
fill 148 287 522 148 288 522 minecraft:obsidian
fill 148 287 540 148 288 540 minecraft:obsidian
fill 148 287 542 149 288 543 minecraft:obsidian
fill 149 287 518 151 288 518 minecraft:obsidian
fill 149 287 544 151 288 544 minecraft:obsidian
fill 150 287 517 153 288 517 minecraft:obsidian
fill 150 287 519 150 288 519 minecraft:obsidian
fill 150 287 543 150 288 543 minecraft:obsidian
fill 150 287 545 153 288 545 minecraft:obsidian
setblock 152 287 513 minecraft:light[level=12]
fill 152 287 516 155 288 516 minecraft:obsidian
setblock 152 287 521 minecraft:light[level=12]
setblock 152 287 529 minecraft:light[level=12]
setblock 152 287 537 minecraft:light[level=12]
fill 152 287 546 155 288 546 minecraft:obsidian
fill 153 287 515 157 288 515 minecraft:obsidian
fill 153 287 547 157 288 547 minecraft:obsidian
fill 155 287 514 169 288 514 minecraft:obsidian
fill 155 287 548 169 288 548 minecraft:obsidian
fill 158 287 513 166 288 513 minecraft:obsidian
fill 158 287 549 166 288 549 minecraft:obsidian
setblock 160 287 521 minecraft:light[level=12]
setblock 160 287 529 minecraft:light[level=12]
setblock 160 287 537 minecraft:light[level=12]
setblock 160 287 545 minecraft:light[level=12]
setblock 163 287 552 minecraft:crying_obsidian
fill 165 287 510 165 307 510 minecraft:obsidian
fill 167 287 515 171 288 515 minecraft:obsidian
fill 167 287 547 171 288 547 minecraft:obsidian
setblock 168 287 513 minecraft:light[level=12]
setblock 168 287 521 minecraft:light[level=12]
setblock 168 287 529 minecraft:light[level=12]
setblock 168 287 537 minecraft:light[level=12]
setblock 168 287 545 minecraft:light[level=12]
fill 169 287 516 172 288 516 minecraft:obsidian
fill 169 287 546 172 288 546 minecraft:obsidian
fill 171 287 517 174 288 517 minecraft:obsidian
fill 171 287 545 174 288 545 minecraft:obsidian
fill 173 287 518 175 288 518 minecraft:obsidian
fill 173 287 544 175 288 544 minecraft:obsidian
fill 174 287 519 176 288 519 minecraft:obsidian
fill 174 287 543 176 288 543 minecraft:obsidian
fill 175 287 520 176 288 520 minecraft:obsidian
fill 175 287 542 176 288 542 minecraft:obsidian
setblock 176 287 513 minecraft:light[level=12]
fill 176 287 521 177 288 522 minecraft:obsidian
setblock 176 287 529 minecraft:light[level=12]
setblock 176 287 537 minecraft:light[level=12]
fill 176 287 540 177 288 541 minecraft:obsidian
setblock 176 287 545 minecraft:light[level=12]
fill 177 287 523 178 288 524 minecraft:obsidian
fill 177 287 538 178 288 539 minecraft:obsidian
fill 178 287 522 178 288 522 minecraft:obsidian
fill 178 287 525 179 288 526 minecraft:obsidian
fill 178 287 536 179 288 537 minecraft:obsidian
fill 178 287 540 178 288 540 minecraft:obsidian
fill 179 287 524 179 288 524 minecraft:obsidian
fill 179 287 527 180 288 535 minecraft:obsidian
fill 179 287 538 179 288 538 minecraft:obsidian
setblock 183 287 521 minecraft:crying_obsidian
setblock 183 287 544 minecraft:amethyst_block
setblock 183 287 550 minecraft:crying_obsidian
fill 141 288 518 141 290 518 minecraft:purple_stained_glass
fill 141 288 526 141 307 526 minecraft:obsidian
fill 141 288 534 141 290 534 minecraft:purple_stained_glass
fill 141 288 550 141 290 550 minecraft:purple_stained_glass
setblock 144 288 552 minecraft:white_concrete
fill 145 288 510 145 290 510 minecraft:purple_stained_glass
fill 155 288 552 155 290 552 minecraft:purple_stained_glass
fill 161 288 510 161 290 510 minecraft:purple_stained_glass
fill 163 288 552 163 292 552 minecraft:obsidian
fill 171 288 552 171 290 552 minecraft:purple_stained_glass
fill 177 288 510 177 290 510 minecraft:purple_stained_glass
setblock 183 288 514 minecraft:white_concrete
fill 183 288 515 183 307 515 minecraft:obsidian
fill 183 288 520 183 290 520 minecraft:purple_stained_glass
fill 183 288 521 183 297 521 minecraft:obsidian
fill 183 288 536 183 290 536 minecraft:purple_stained_glass
fill 183 288 544 183 307 544 minecraft:obsidian
fill 183 288 550 183 307 550 minecraft:obsidian
setblock 141 289 516 minecraft:crying_obsidian
setblock 143 289 552 minecraft:amethyst_block
fill 144 289 552 144 307 552 minecraft:obsidian
fill 145 289 536 145 289 538 minecraft:crying_obsidian
fill 146 289 539 146 289 540 minecraft:crying_obsidian
setblock 147 289 541 minecraft:crying_obsidian
fill 148 289 542 148 289 543 minecraft:crying_obsidian
fill 149 289 543 149 289 544 minecraft:crying_obsidian
fill 150 289 544 150 289 545 minecraft:crying_obsidian
setblock 151 289 545 minecraft:crying_obsidian
setblock 152 289 516 minecraft:crying_obsidian
setblock 152 289 546 minecraft:crying_obsidian
fill 153 289 515 154 289 515 minecraft:crying_obsidian
fill 153 289 547 154 289 547 minecraft:crying_obsidian
fill 155 289 514 157 289 514 minecraft:crying_obsidian
fill 155 289 548 157 289 548 minecraft:crying_obsidian
fill 158 289 513 166 289 513 minecraft:crying_obsidian
fill 158 289 549 166 289 549 minecraft:crying_obsidian
setblock 159 289 552 minecraft:white_concrete
fill 167 289 514 169 289 514 minecraft:crying_obsidian
fill 167 289 548 169 289 548 minecraft:crying_obsidian
fill 170 289 515 171 289 515 minecraft:crying_obsidian
fill 170 289 547 171 289 547 minecraft:crying_obsidian
setblock 172 289 516 minecraft:crying_obsidian
setblock 172 289 546 minecraft:crying_obsidian
fill 173 289 517 174 289 517 minecraft:crying_obsidian
fill 173 289 545 174 289 545 minecraft:crying_obsidian
fill 174 289 518 175 289 518 minecraft:crying_obsidian
fill 174 289 544 175 289 544 minecraft:crying_obsidian
fill 175 289 519 176 289 519 minecraft:crying_obsidian
fill 175 289 543 176 289 543 minecraft:crying_obsidian
setblock 176 289 520 minecraft:crying_obsidian
setblock 176 289 542 minecraft:crying_obsidian
setblock 177 289 521 minecraft:crying_obsidian
setblock 177 289 541 minecraft:crying_obsidian
fill 178 289 522 178 289 523 minecraft:crying_obsidian
fill 178 289 539 178 289 540 minecraft:crying_obsidian
fill 179 289 524 179 289 526 minecraft:crying_obsidian
fill 179 289 536 179 289 538 minecraft:crying_obsidian
fill 180 289 527 180 289 535 minecraft:crying_obsidian
setblock 180 289 552 minecraft:crying_obsidian
fill 183 289 514 183 307 514 minecraft:obsidian
fill 141 290 516 141 294 516 minecraft:obsidian
fill 143 290 552 143 296 552 minecraft:obsidian
setblock 144 290 510 minecraft:amethyst_block
fill 147 290 536 148 291 537 minecraft:obsidian
fill 159 290 552 159 307 552 minecraft:obsidian
fill 180 290 552 180 307 552 minecraft:obsidian
setblock 183 290 511 minecraft:white_concrete
fill 141 291 518 141 296 518 minecraft:obsidian
fill 141 291 534 141 296 534 minecraft:obsidian
setblock 141 291 538 minecraft:amethyst_block
fill 141 291 550 141 296 550 minecraft:obsidian
setblock 142 291 552 minecraft:crying_obsidian
fill 144 291 510 145 296 510 minecraft:obsidian
fill 155 291 552 155 296 552 minecraft:obsidian
fill 161 291 510 161 296 510 minecraft:obsidian
fill 171 291 552 171 294 552 minecraft:obsidian
fill 177 291 510 177 296 510 minecraft:obsidian
fill 183 291 511 183 298 511 minecraft:obsidian
fill 183 291 520 183 296 520 minecraft:obsidian
fill 183 291 536 183 294 536 minecraft:obsidian
setblock 183 291 549 minecraft:white_concrete
setblock 141 292 519 minecraft:amethyst_block
fill 141 292 538 141 302 538 minecraft:obsidian
fill 142 292 552 142 307 552 minecraft:obsidian
setblock 183 292 516 minecraft:amethyst_block
setblock 183 292 518 minecraft:white_concrete
fill 183 292 549 183 307 549 minecraft:obsidian
fill 141 293 519 141 307 519 minecraft:obsidian
setblock 141 293 529 minecraft:amethyst_block
fill 142 293 534 143 296 536 minecraft:amethyst_block
setblock 163 293 552 minecraft:white_concrete
setblock 169 293 510 minecraft:white_concrete
setblock 178 293 552 minecraft:crying_obsidian
fill 183 293 516 183 307 516 minecraft:obsidian
fill 183 293 518 183 295 518 minecraft:obsidian
fill 141 294 529 141 307 529 minecraft:obsidian
setblock 141 294 545 minecraft:white_concrete
fill 142 294 533 142 295 533 minecraft:amethyst_block
fill 142 294 537 142 295 537 minecraft:amethyst_block
fill 144 294 534 144 296 536 minecraft:amethyst_block
setblock 146 294 510 minecraft:amethyst_block
fill 163 294 552 163 303 552 minecraft:obsidian
fill 169 294 510 169 307 510 minecraft:obsidian
fill 178 294 552 178 307 552 minecraft:obsidian
setblock 141 295 516 minecraft:crying_obsidian
setblock 141 295 530 minecraft:amethyst_block
fill 141 295 545 141 307 545 minecraft:obsidian
setblock 141 295 548 minecraft:crying_obsidian
setblock 144 295 513 minecraft:light[level=12]
setblock 144 295 521 minecraft:light[level=12]
setblock 144 295 529 minecraft:light[level=12]
setblock 144 295 537 minecraft:light[level=12]
setblock 144 295 545 minecraft:light[level=12]
fill 145 295 535 145 297 535 minecraft:amethyst_block
fill 146 295 510 146 306 510 minecraft:obsidian
setblock 152 295 513 minecraft:light[level=12]
setblock 152 295 521 minecraft:light[level=12]
setblock 152 295 529 minecraft:light[level=12]
setblock 152 295 537 minecraft:light[level=12]
setblock 152 295 545 minecraft:light[level=12]
setblock 156 295 552 minecraft:crying_obsidian
setblock 160 295 513 minecraft:light[level=12]
setblock 160 295 521 minecraft:light[level=12]
setblock 160 295 529 minecraft:light[level=12]
setblock 160 295 537 minecraft:light[level=12]
setblock 160 295 545 minecraft:light[level=12]
setblock 168 295 513 minecraft:light[level=12]
setblock 168 295 521 minecraft:light[level=12]
setblock 168 295 529 minecraft:light[level=12]
setblock 168 295 537 minecraft:light[level=12]
setblock 168 295 545 minecraft:light[level=12]
setblock 171 295 552 minecraft:amethyst_block
setblock 176 295 513 minecraft:light[level=12]
setblock 176 295 521 minecraft:light[level=12]
setblock 176 295 529 minecraft:light[level=12]
setblock 176 295 537 minecraft:light[level=12]
setblock 176 295 545 minecraft:light[level=12]
setblock 183 295 536 minecraft:crying_obsidian
fill 141 296 516 141 307 516 minecraft:obsidian
fill 141 296 530 141 307 530 minecraft:obsidian
fill 141 296 548 141 307 548 minecraft:obsidian
setblock 145 296 534 minecraft:amethyst_block
setblock 145 296 536 minecraft:amethyst_block
fill 146 296 535 146 297 535 minecraft:amethyst_block
setblock 153 296 552 minecraft:crying_obsidian
fill 156 296 552 156 307 552 minecraft:obsidian
setblock 157 296 510 minecraft:white_concrete
setblock 171 296 552 minecraft:obsidian
setblock 183 296 518 minecraft:amethyst_block
setblock 183 296 536 minecraft:obsidian
fill 141 297 518 141 299 518 minecraft:purple_stained_glass
fill 141 297 534 141 299 534 minecraft:purple_stained_glass
fill 141 297 550 141 299 550 minecraft:purple_stained_glass
setblock 143 297 552 minecraft:crying_obsidian
fill 144 297 510 144 307 510 minecraft:obsidian
fill 145 297 510 145 299 510 minecraft:purple_stained_glass
setblock 153 297 552 minecraft:obsidian
fill 155 297 552 155 299 552 minecraft:purple_stained_glass
fill 157 297 510 157 306 510 minecraft:obsidian
fill 161 297 510 161 299 510 minecraft:purple_stained_glass
fill 171 297 552 171 299 552 minecraft:purple_stained_glass
setblock 172 297 552 minecraft:white_concrete
fill 177 297 510 177 299 510 minecraft:purple_stained_glass
fill 183 297 518 183 307 518 minecraft:obsidian
fill 183 297 520 183 299 520 minecraft:purple_stained_glass
setblock 183 297 530 minecraft:white_concrete
fill 183 297 536 183 299 536 minecraft:purple_stained_glass
setblock 141 298 511 minecraft:crying_obsidian
setblock 141 298 535 minecraft:white_concrete
fill 143 298 552 143 307 552 minecraft:obsidian
setblock 153 298 552 minecraft:white_concrete
fill 172 298 552 172 307 552 minecraft:obsidian
setblock 176 298 510 minecraft:white_concrete
setblock 183 298 521 minecraft:white_concrete
fill 183 298 530 183 307 530 minecraft:obsidian
fill 141 299 511 141 307 511 minecraft:obsidian
fill 141 299 535 141 307 535 minecraft:obsidian
fill 146 299 533 146 300 534 minecraft:obsidian
fill 153 299 552 153 307 552 minecraft:obsidian
fill 176 299 510 176 307 510 minecraft:obsidian
setblock 183 299 511 minecraft:crying_obsidian
fill 183 299 521 183 307 521 minecraft:obsidian
fill 141 300 518 141 307 518 minecraft:obsidian
fill 141 300 534 141 307 534 minecraft:obsidian
fill 141 300 550 141 307 550 minecraft:obsidian
fill 145 300 510 145 307 510 minecraft:obsidian
setblock 150 300 552 minecraft:white_concrete
fill 155 300 552 155 307 552 minecraft:obsidian
fill 161 300 510 161 307 510 minecraft:obsidian
fill 171 300 552 171 304 552 minecraft:obsidian
fill 177 300 510 177 307 510 minecraft:obsidian
setblock 177 300 552 minecraft:amethyst_block
setblock 180 300 510 minecraft:crying_obsidian
fill 181 300 510 181 307 510 minecraft:obsidian
fill 183 300 511 183 307 511 minecraft:obsidian
fill 183 300 520 183 301 520 minecraft:obsidian
fill 183 300 536 183 307 536 minecraft:obsidian
fill 150 301 552 150 307 552 minecraft:obsidian
fill 177 301 552 177 303 552 minecraft:obsidian
fill 180 301 510 180 307 510 minecraft:obsidian
setblock 183 302 520 minecraft:crying_obsidian
setblock 183 302 539 minecraft:white_concrete
setblock 141 303 538 minecraft:crying_obsidian
setblock 141 303 540 minecraft:crying_obsidian
setblock 144 303 513 minecraft:light[level=12]
setblock 144 303 521 minecraft:light[level=12]
setblock 144 303 529 minecraft:light[level=12]
setblock 144 303 537 minecraft:light[level=12]
setblock 144 303 545 minecraft:light[level=12]
setblock 152 303 513 minecraft:light[level=12]
setblock 152 303 521 minecraft:light[level=12]
setblock 152 303 529 minecraft:light[level=12]
setblock 152 303 537 minecraft:light[level=12]
setblock 152 303 545 minecraft:light[level=12]
setblock 160 303 513 minecraft:light[level=12]
setblock 160 303 521 minecraft:light[level=12]
setblock 160 303 529 minecraft:light[level=12]
setblock 160 303 537 minecraft:light[level=12]
setblock 160 303 545 minecraft:light[level=12]
setblock 168 303 513 minecraft:light[level=12]
setblock 168 303 521 minecraft:light[level=12]
setblock 168 303 529 minecraft:light[level=12]
setblock 168 303 537 minecraft:light[level=12]
setblock 168 303 545 minecraft:light[level=12]
setblock 176 303 513 minecraft:light[level=12]
setblock 176 303 521 minecraft:light[level=12]
setblock 176 303 529 minecraft:light[level=12]
setblock 176 303 537 minecraft:light[level=12]
setblock 176 303 545 minecraft:light[level=12]
fill 183 303 520 183 307 520 minecraft:obsidian
fill 183 303 539 183 307 539 minecraft:obsidian
fill 141 304 538 141 307 538 minecraft:obsidian
fill 141 304 540 141 307 540 minecraft:obsidian
fill 150 304 510 150 307 510 minecraft:obsidian
setblock 151 304 510 minecraft:white_concrete
setblock 156 304 510 minecraft:amethyst_block
setblock 163 304 552 minecraft:amethyst_block
setblock 177 304 552 minecraft:white_concrete
setblock 179 304 510 minecraft:amethyst_block
fill 151 305 510 151 307 510 minecraft:obsidian
fill 156 305 510 156 307 510 minecraft:obsidian
fill 163 305 552 163 307 552 minecraft:obsidian
setblock 171 305 552 minecraft:amethyst_block
fill 177 305 552 177 307 552 minecraft:obsidian
fill 179 305 510 179 307 510 minecraft:obsidian
setblock 183 305 513 minecraft:amethyst_block
setblock 183 305 523 minecraft:crying_obsidian
setblock 141 306 532 minecraft:white_concrete
setblock 143 306 510 minecraft:white_concrete
setblock 148 306 552 minecraft:crying_obsidian
fill 149 306 552 149 307 552 minecraft:obsidian
setblock 159 306 510 minecraft:crying_obsidian
fill 171 306 552 171 307 552 minecraft:obsidian
setblock 175 306 552 minecraft:white_concrete
setblock 181 306 552 minecraft:amethyst_block
fill 183 306 513 183 307 513 minecraft:obsidian
fill 183 306 523 183 307 523 minecraft:obsidian
setblock 141 307 532 minecraft:obsidian
setblock 143 307 510 minecraft:obsidian
setblock 146 307 510 minecraft:white_concrete
setblock 148 307 552 minecraft:obsidian
setblock 157 307 510 minecraft:amethyst_block
setblock 159 307 510 minecraft:obsidian
setblock 175 307 552 minecraft:obsidian
setblock 181 307 552 minecraft:obsidian
setblock 183 307 528 minecraft:amethyst_block
