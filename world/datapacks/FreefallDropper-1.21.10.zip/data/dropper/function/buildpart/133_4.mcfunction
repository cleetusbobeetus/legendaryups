fill 48 98 578 48 100 579 minecraft:cobbled_deepslate
setblock 48 98 587 minecraft:calcite
fill 48 98 588 48 101 588 minecraft:cobbled_deepslate
setblock 48 98 592 minecraft:calcite
fill 48 98 593 48 101 593 minecraft:cobbled_deepslate
setblock 48 98 596 minecraft:cobbled_deepslate
setblock 48 98 597 minecraft:calcite
fill 48 98 598 48 101 598 minecraft:cobbled_deepslate
fill 49 98 572 49 101 572 minecraft:cobbled_deepslate
setblock 49 98 575 minecraft:cobbled_deepslate
setblock 49 98 576 minecraft:calcite
setblock 49 98 587 minecraft:cobbled_deepslate
setblock 49 98 591 minecraft:calcite
fill 49 98 592 49 101 592 minecraft:cobbled_deepslate
setblock 49 98 596 minecraft:calcite
fill 49 98 597 49 101 597 minecraft:cobbled_deepslate
setblock 50 98 590 minecraft:calcite
fill 50 98 591 50 99 591 minecraft:cobbled_deepslate
setblock 50 98 595 minecraft:calcite
fill 50 98 596 50 101 596 minecraft:cobbled_deepslate
setblock 52 98 598 minecraft:calcite
setblock 53 98 597 minecraft:calcite
fill 53 98 598 53 101 598 minecraft:cobbled_deepslate
setblock 54 98 596 minecraft:calcite
fill 54 98 597 54 101 597 minecraft:cobbled_deepslate
setblock 55 98 596 minecraft:cobbled_deepslate
setblock 57 98 598 minecraft:calcite
fill 58 98 598 58 99 598 minecraft:cobbled_deepslate
fill 59 98 588 59 100 589 minecraft:deepslate
fill 60 98 587 60 100 587 minecraft:deepslate
fill 61 98 591 62 100 591 minecraft:deepslate
fill 63 98 587 63 100 587 minecraft:deepslate
fill 69 98 558 71 98 558 minecraft:cobbled_deepslate
fill 69 98 598 71 98 598 minecraft:cobbled_deepslate
fill 71 98 594 71 103 594 minecraft:deepslate
fill 71 98 597 72 98 597 minecraft:cobbled_deepslate
setblock 72 98 558 minecraft:calcite
fill 72 98 559 72 101 559 minecraft:cobbled_deepslate
setblock 72 98 598 minecraft:calcite
fill 73 98 558 73 101 558 minecraft:cobbled_deepslate
setblock 73 98 597 minecraft:calcite
fill 73 98 598 73 101 598 minecraft:cobbled_deepslate
fill 74 98 597 74 101 597 minecraft:cobbled_deepslate
setblock 75 98 596 minecraft:cobbled_deepslate
setblock 76 98 559 minecraft:calcite
setblock 77 98 558 minecraft:calcite
fill 77 98 559 77 101 559 minecraft:cobbled_deepslate
setblock 77 98 598 minecraft:calcite
fill 78 98 558 78 101 558 minecraft:cobbled_deepslate
setblock 78 98 597 minecraft:calcite
fill 78 98 598 81 98 598 minecraft:cobbled_deepslate
fill 79 98 597 79 101 597 minecraft:cobbled_deepslate
fill 82 98 557 82 199 557 minecraft:cobbled_deepslate
setblock 82 98 598 minecraft:calcite
fill 83 98 598 83 101 598 minecraft:cobbled_deepslate
setblock 87 98 593 minecraft:calcite
fill 87 98 594 87 101 594 minecraft:cobbled_deepslate
setblock 87 98 598 minecraft:calcite
setblock 88 98 572 minecraft:calcite
fill 88 98 573 88 101 573 minecraft:cobbled_deepslate
fill 88 98 588 88 99 588 minecraft:cobbled_deepslate
setblock 88 98 592 minecraft:calcite
fill 88 98 593 88 101 593 minecraft:cobbled_deepslate
setblock 88 98 597 minecraft:calcite
fill 88 98 598 88 101 598 minecraft:cobbled_deepslate
setblock 48 99 571 minecraft:calcite
fill 48 99 572 48 102 572 minecraft:cobbled_deepslate
setblock 48 99 575 minecraft:cobbled_deepslate
setblock 48 99 576 minecraft:calcite
fill 48 99 577 49 101 577 minecraft:cobbled_deepslate
setblock 48 99 580 minecraft:cobbled_deepslate
setblock 48 99 581 minecraft:calcite
fill 48 99 584 48 100 584 minecraft:cobbled_deepslate
setblock 48 99 586 minecraft:calcite
fill 48 99 587 48 102 587 minecraft:cobbled_deepslate
setblock 48 99 591 minecraft:calcite
fill 48 99 592 48 102 592 minecraft:cobbled_deepslate
setblock 48 99 596 minecraft:calcite
fill 48 99 597 48 102 597 minecraft:cobbled_deepslate
setblock 49 99 575 minecraft:calcite
fill 49 99 576 49 102 576 minecraft:cobbled_deepslate
fill 49 99 578 49 100 578 minecraft:cobbled_deepslate
setblock 49 99 590 minecraft:calcite
fill 49 99 591 49 102 591 minecraft:cobbled_deepslate
setblock 49 99 595 minecraft:calcite
fill 49 99 596 49 102 596 minecraft:cobbled_deepslate
setblock 50 99 590 minecraft:cobbled_deepslate
setblock 50 99 594 minecraft:calcite
fill 50 99 595 50 102 595 minecraft:cobbled_deepslate
setblock 51 99 598 minecraft:calcite
setblock 52 99 597 minecraft:calcite
fill 52 99 598 52 102 598 minecraft:cobbled_deepslate
setblock 53 99 596 minecraft:calcite
fill 53 99 597 53 102 597 minecraft:cobbled_deepslate
setblock 54 99 596 minecraft:cobbled_deepslate
setblock 56 99 598 minecraft:calcite
fill 57 99 598 57 102 598 minecraft:cobbled_deepslate
fill 59 99 587 59 100 587 minecraft:deepslate
fill 59 99 590 59 100 590 minecraft:deepslate
fill 60 99 591 60 100 591 minecraft:deepslate
fill 61 99 586 62 100 586 minecraft:deepslate
fill 63 99 567 66 151 569 minecraft:calcite
fill 63 99 591 63 100 591 minecraft:deepslate
fill 64 99 566 66 151 566 minecraft:calcite
fill 64 99 588 64 100 590 minecraft:deepslate
fill 69 99 558 70 99 558 minecraft:cobbled_deepslate
fill 69 99 598 70 99 598 minecraft:cobbled_deepslate
setblock 71 99 558 minecraft:calcite
fill 71 99 559 71 102 559 minecraft:cobbled_deepslate
setblock 71 99 597 minecraft:cobbled_deepslate
setblock 71 99 598 minecraft:calcite
fill 72 99 558 72 102 558 minecraft:cobbled_deepslate
setblock 72 99 597 minecraft:calcite
fill 72 99 598 72 102 598 minecraft:cobbled_deepslate
fill 73 99 597 73 102 597 minecraft:cobbled_deepslate
setblock 75 99 559 minecraft:calcite
setblock 76 99 558 minecraft:calcite
fill 76 99 559 76 102 559 minecraft:cobbled_deepslate
setblock 76 99 598 minecraft:calcite
fill 77 99 558 77 102 558 minecraft:cobbled_deepslate
setblock 77 99 597 minecraft:calcite
fill 77 99 598 80 99 598 minecraft:cobbled_deepslate
fill 78 99 597 78 102 597 minecraft:cobbled_deepslate
setblock 81 99 558 minecraft:calcite
setblock 81 99 598 minecraft:calcite
fill 82 99 598 82 102 598 minecraft:cobbled_deepslate
setblock 86 99 598 minecraft:calcite
setblock 87 99 592 minecraft:calcite
fill 87 99 593 87 102 593 minecraft:cobbled_deepslate
setblock 87 99 597 minecraft:calcite
fill 87 99 598 87 102 598 minecraft:cobbled_deepslate
fill 88 99 558 88 101 558 minecraft:cobbled_deepslate
setblock 88 99 591 minecraft:calcite
fill 88 99 592 88 102 592 minecraft:cobbled_deepslate
setblock 88 99 596 minecraft:calcite
fill 88 99 597 88 102 597 minecraft:cobbled_deepslate
fill 48 100 571 48 103 571 minecraft:cobbled_deepslate
setblock 48 100 574 minecraft:cobbled_deepslate
setblock 48 100 575 minecraft:calcite
fill 48 100 576 48 103 576 minecraft:cobbled_deepslate
setblock 48 100 580 minecraft:calcite
fill 48 100 581 48 101 583 minecraft:cobbled_deepslate
setblock 48 100 585 minecraft:calcite
fill 48 100 586 48 103 586 minecraft:cobbled_deepslate
setblock 48 100 590 minecraft:calcite
fill 48 100 591 48 103 591 minecraft:cobbled_deepslate
setblock 48 100 595 minecraft:calcite
fill 48 100 596 48 103 596 minecraft:cobbled_deepslate
setblock 49 100 574 minecraft:calcite
fill 49 100 575 50 102 575 minecraft:cobbled_deepslate
setblock 49 100 579 minecraft:calcite
fill 49 100 580 49 103 580 minecraft:cobbled_deepslate
setblock 49 100 589 minecraft:calcite
fill 49 100 590 49 103 590 minecraft:cobbled_deepslate
setblock 49 100 594 minecraft:calcite
fill 49 100 595 49 103 595 minecraft:cobbled_deepslate
fill 50 100 576 50 101 576 minecraft:cobbled_deepslate
setblock 50 100 593 minecraft:calcite
fill 50 100 594 50 103 594 minecraft:cobbled_deepslate
setblock 50 100 598 minecraft:calcite
setblock 51 100 597 minecraft:calcite
fill 51 100 598 51 103 598 minecraft:cobbled_deepslate
setblock 52 100 596 minecraft:calcite
fill 52 100 597 52 103 597 minecraft:cobbled_deepslate
setblock 53 100 596 minecraft:cobbled_deepslate
setblock 55 100 598 minecraft:calcite
fill 56 100 598 56 103 598 minecraft:cobbled_deepslate
setblock 58 100 589 minecraft:deepslate
setblock 59 100 591 minecraft:deepslate
setblock 60 100 586 minecraft:deepslate
fill 61 100 592 62 100 592 minecraft:deepslate
fill 62 100 566 62 101 569 minecraft:deepslate
fill 63 100 565 63 101 566 minecraft:deepslate
fill 63 100 570 66 101 570 minecraft:deepslate
setblock 63 100 586 minecraft:deepslate
fill 64 100 565 66 101 565 minecraft:deepslate
setblock 64 100 587 minecraft:deepslate
setblock 64 100 591 minecraft:deepslate
fill 67 100 566 67 101 569 minecraft:deepslate
fill 68 100 558 69 100 558 minecraft:cobbled_deepslate
fill 68 100 598 69 100 598 minecraft:cobbled_deepslate
setblock 70 100 558 minecraft:calcite
fill 70 100 559 70 103 559 minecraft:cobbled_deepslate
setblock 70 100 597 minecraft:cobbled_deepslate
setblock 70 100 598 minecraft:calcite
fill 71 100 558 71 103 558 minecraft:cobbled_deepslate
setblock 71 100 597 minecraft:calcite
fill 71 100 598 71 103 598 minecraft:cobbled_deepslate
fill 72 100 597 72 103 597 minecraft:cobbled_deepslate
setblock 74 100 559 minecraft:calcite
setblock 75 100 558 minecraft:calcite
fill 75 100 559 75 103 559 minecraft:cobbled_deepslate
setblock 75 100 598 minecraft:calcite
fill 76 100 558 76 103 558 minecraft:cobbled_deepslate
setblock 76 100 597 minecraft:calcite
fill 76 100 598 79 100 598 minecraft:cobbled_deepslate
fill 77 100 597 77 103 597 minecraft:cobbled_deepslate
setblock 80 100 558 minecraft:calcite
setblock 80 100 598 minecraft:calcite
fill 81 100 558 81 103 558 minecraft:cobbled_deepslate
fill 81 100 598 81 103 598 minecraft:cobbled_deepslate
fill 84 100 597 84 101 597 minecraft:cobbled_deepslate
setblock 85 100 598 minecraft:calcite
setblock 86 100 597 minecraft:calcite
fill 86 100 598 86 103 598 minecraft:cobbled_deepslate
fill 87 100 592 87 103 592 minecraft:cobbled_deepslate
setblock 87 100 596 minecraft:calcite
fill 87 100 597 87 103 597 minecraft:cobbled_deepslate
setblock 88 100 574 minecraft:cobbled_deepslate
setblock 88 100 575 minecraft:calcite
fill 88 100 576 88 103 576 minecraft:cobbled_deepslate
setblock 88 100 590 minecraft:calcite
fill 88 100 591 88 103 591 minecraft:cobbled_deepslate
setblock 88 100 595 minecraft:calcite
fill 88 100 596 88 103 596 minecraft:cobbled_deepslate
setblock 48 101 574 minecraft:calcite
fill 48 101 575 48 104 575 minecraft:cobbled_deepslate
setblock 48 101 578 minecraft:cobbled_deepslate
setblock 48 101 579 minecraft:calcite
fill 48 101 580 48 104 580 minecraft:cobbled_deepslate
setblock 48 101 584 minecraft:calcite
fill 48 101 585 48 104 585 minecraft:cobbled_deepslate
setblock 48 101 589 minecraft:calcite
fill 48 101 590 48 104 590 minecraft:cobbled_deepslate
setblock 48 101 594 minecraft:calcite
fill 48 101 595 48 104 595 minecraft:cobbled_deepslate
setblock 49 101 573 minecraft:calcite
fill 49 101 574 50 103 574 minecraft:cobbled_deepslate
setblock 49 101 578 minecraft:calcite
fill 49 101 579 50 103 579 minecraft:cobbled_deepslate
fill 49 101 581 49 101 582 minecraft:cobbled_deepslate
fill 49 101 589 49 104 589 minecraft:cobbled_deepslate
setblock 49 101 593 minecraft:calcite
fill 49 101 594 49 104 594 minecraft:cobbled_deepslate
setblock 49 101 598 minecraft:calcite
fill 50 101 558 53 101 558 minecraft:cobbled_deepslate
setblock 50 101 577 minecraft:calcite
fill 50 101 578 50 104 578 minecraft:cobbled_deepslate
fill 50 101 593 50 102 593 minecraft:cobbled_deepslate
setblock 50 101 597 minecraft:calcite
fill 50 101 598 50 104 598 minecraft:cobbled_deepslate
setblock 51 101 596 minecraft:calcite
fill 51 101 597 51 104 597 minecraft:cobbled_deepslate
fill 52 101 596 52 102 596 minecraft:cobbled_deepslate
setblock 54 101 598 minecraft:calcite
setblock 55 101 597 minecraft:calcite
fill 55 101 598 55 104 598 minecraft:cobbled_deepslate
fill 61 101 566 61 101 569 minecraft:deepslate
fill 61 101 588 62 102 589 minecraft:light_blue_stained_glass
setblock 62 101 565 minecraft:deepslate
setblock 62 101 570 minecraft:deepslate
fill 63 101 564 66 101 564 minecraft:deepslate
fill 63 101 571 67 101 571 minecraft:deepslate
fill 67 101 558 68 101 558 minecraft:cobbled_deepslate
setblock 67 101 565 minecraft:deepslate
fill 67 101 570 68 101 570 minecraft:deepslate
fill 67 101 598 68 101 598 minecraft:cobbled_deepslate
fill 68 101 566 68 101 569 minecraft:deepslate
setblock 69 101 558 minecraft:calcite
fill 69 101 559 69 104 559 minecraft:cobbled_deepslate
setblock 69 101 598 minecraft:calcite
fill 70 101 558 70 104 558 minecraft:cobbled_deepslate
fill 70 101 594 70 103 594 minecraft:deepslate
setblock 70 101 597 minecraft:calcite
fill 70 101 598 70 104 598 minecraft:cobbled_deepslate
fill 71 101 593 71 103 593 minecraft:deepslate
fill 71 101 595 71 103 595 minecraft:deepslate
fill 71 101 597 71 104 597 minecraft:cobbled_deepslate
fill 72 101 594 72 103 594 minecraft:deepslate
setblock 73 101 559 minecraft:calcite
setblock 74 101 558 minecraft:calcite
fill 74 101 559 74 104 559 minecraft:cobbled_deepslate
setblock 74 101 598 minecraft:calcite
fill 75 101 558 75 104 558 minecraft:cobbled_deepslate
setblock 75 101 597 minecraft:calcite
fill 75 101 598 78 101 598 minecraft:cobbled_deepslate
fill 76 101 597 76 104 597 minecraft:cobbled_deepslate
setblock 79 101 558 minecraft:calcite
setblock 79 101 598 minecraft:calcite
fill 80 101 558 80 104 558 minecraft:cobbled_deepslate
setblock 80 101 597 minecraft:calcite
fill 80 101 598 80 104 598 minecraft:cobbled_deepslate
fill 83 101 597 83 102 597 minecraft:cobbled_deepslate
setblock 84 101 598 minecraft:calcite
setblock 85 101 597 minecraft:calcite
fill 85 101 598 85 104 598 minecraft:cobbled_deepslate
fill 86 101 558 87 102 558 minecraft:cobbled_deepslate
fill 86 101 597 86 104 597 minecraft:cobbled_deepslate
setblock 87 101 595 minecraft:calcite
fill 87 101 596 87 104 596 minecraft:cobbled_deepslate
setblock 88 101 559 minecraft:calcite
setblock 88 101 574 minecraft:calcite
fill 88 101 575 88 104 575 minecraft:cobbled_deepslate
fill 88 101 577 88 101 578 minecraft:cobbled_deepslate
setblock 88 101 588 minecraft:cobbled_deepslate
setblock 88 101 589 minecraft:calcite
fill 88 101 590 88 104 590 minecraft:cobbled_deepslate
setblock 88 101 594 minecraft:calcite
fill 88 101 595 88 104 595 minecraft:cobbled_deepslate
setblock 48 102 558 minecraft:calcite
fill 48 102 570 48 104 570 minecraft:cobbled_deepslate
setblock 48 102 573 minecraft:calcite
fill 48 102 574 48 105 574 minecraft:cobbled_deepslate
setblock 48 102 577 minecraft:cobbled_deepslate
setblock 48 102 578 minecraft:calcite
fill 48 102 579 48 105 579 minecraft:cobbled_deepslate
fill 48 102 581 48 102 582 minecraft:cobbled_deepslate
setblock 48 102 583 minecraft:calcite
fill 48 102 584 49 104 584 minecraft:cobbled_deepslate
setblock 48 102 588 minecraft:calcite
fill 48 102 589 48 105 589 minecraft:cobbled_deepslate
setblock 48 102 593 minecraft:calcite
fill 48 102 594 48 105 594 minecraft:cobbled_deepslate
setblock 48 102 598 minecraft:calcite
fill 49 102 558 52 102 558 minecraft:cobbled_deepslate
setblock 49 102 572 minecraft:calcite
fill 49 102 573 50 104 573 minecraft:cobbled_deepslate
setblock 49 102 577 minecraft:calcite
fill 49 102 578 49 105 578 minecraft:cobbled_deepslate
setblock 49 102 581 minecraft:cobbled_deepslate
setblock 49 102 582 minecraft:calcite
fill 49 102 583 49 105 583 minecraft:cobbled_deepslate
setblock 49 102 592 minecraft:calcite
fill 49 102 593 49 105 593 minecraft:cobbled_deepslate
setblock 49 102 597 minecraft:calcite
fill 49 102 598 49 105 598 minecraft:cobbled_deepslate
setblock 50 102 576 minecraft:calcite
fill 50 102 577 50 105 577 minecraft:cobbled_deepslate
setblock 50 102 580 minecraft:cobbled_deepslate
setblock 50 102 581 minecraft:calcite
setblock 50 102 596 minecraft:calcite
fill 50 102 597 50 105 597 minecraft:cobbled_deepslate
fill 51 102 596 51 105 596 minecraft:cobbled_deepslate
setblock 53 102 558 minecraft:calcite
setblock 53 102 598 minecraft:calcite
fill 54 102 558 54 105 558 minecraft:cobbled_deepslate
setblock 54 102 597 minecraft:calcite
fill 54 102 598 54 105 598 minecraft:cobbled_deepslate
setblock 55 102 597 minecraft:cobbled_deepslate
fill 65 102 558 67 102 558 minecraft:cobbled_deepslate
fill 66 102 598 67 102 598 minecraft:cobbled_deepslate
setblock 68 102 558 minecraft:calcite
fill 68 102 559 68 105 559 minecraft:cobbled_deepslate
setblock 68 102 598 minecraft:calcite
fill 69 102 558 69 105 558 minecraft:cobbled_deepslate
setblock 69 102 597 minecraft:calcite
fill 69 102 598 69 105 598 minecraft:cobbled_deepslate
fill 70 102 593 70 103 593 minecraft:deepslate
fill 70 102 595 70 103 595 minecraft:deepslate
fill 70 102 597 70 105 597 minecraft:cobbled_deepslate
setblock 72 102 559 minecraft:calcite
fill 72 102 593 72 103 593 minecraft:deepslate
fill 72 102 595 72 103 595 minecraft:deepslate
setblock 73 102 558 minecraft:calcite
fill 73 102 559 73 105 559 minecraft:cobbled_deepslate
setblock 73 102 598 minecraft:calcite
fill 74 102 558 74 105 558 minecraft:cobbled_deepslate
setblock 74 102 597 minecraft:calcite
fill 74 102 598 77 102 598 minecraft:cobbled_deepslate
fill 75 102 597 75 105 597 minecraft:cobbled_deepslate
setblock 77 102 559 minecraft:calcite
setblock 78 102 558 minecraft:calcite
setblock 78 102 598 minecraft:calcite
fill 79 102 558 79 105 558 minecraft:cobbled_deepslate
setblock 79 102 597 minecraft:calcite
fill 79 102 598 79 105 598 minecraft:cobbled_deepslate
fill 80 102 597 82 103 597 minecraft:cobbled_deepslate
setblock 82 102 558 minecraft:cobbled_deepslate
setblock 83 102 558 minecraft:calcite
setblock 83 102 598 minecraft:calcite
fill 84 102 558 85 104 558 minecraft:cobbled_deepslate
setblock 84 102 597 minecraft:calcite
fill 84 102 598 84 105 598 minecraft:cobbled_deepslate
fill 85 102 597 85 105 597 minecraft:cobbled_deepslate
setblock 87 102 594 minecraft:calcite
fill 87 102 595 87 105 595 minecraft:cobbled_deepslate
setblock 88 102 558 minecraft:calcite
fill 88 102 559 88 105 559 minecraft:cobbled_deepslate
setblock 88 102 572 minecraft:cobbled_deepslate
setblock 88 102 573 minecraft:calcite
fill 88 102 574 88 105 574 minecraft:cobbled_deepslate
setblock 88 102 577 minecraft:cobbled_deepslate
setblock 88 102 578 minecraft:calcite
fill 88 102 579 88 103 581 minecraft:cobbled_deepslate
setblock 88 102 588 minecraft:calcite
fill 88 102 589 88 105 589 minecraft:cobbled_deepslate
setblock 88 102 593 minecraft:calcite
fill 88 102 594 88 105 594 minecraft:cobbled_deepslate
setblock 88 102 598 minecraft:calcite
fill 48 103 558 48 105 559 minecraft:cobbled_deepslate
setblock 48 103 572 minecraft:calcite
fill 48 103 573 48 106 573 minecraft:cobbled_deepslate
setblock 48 103 577 minecraft:calcite
fill 48 103 578 48 106 578 minecraft:cobbled_deepslate
setblock 48 103 581 minecraft:cobbled_deepslate
setblock 48 103 582 minecraft:calcite
fill 48 103 583 48 106 583 minecraft:cobbled_deepslate
setblock 48 103 587 minecraft:calcite
fill 48 103 588 49 105 588 minecraft:cobbled_deepslate
setblock 48 103 592 minecraft:calcite
fill 48 103 593 48 106 593 minecraft:cobbled_deepslate
setblock 48 103 597 minecraft:calcite
fill 48 103 598 48 106 598 minecraft:cobbled_deepslate
fill 49 103 558 51 103 558 minecraft:cobbled_deepslate
setblock 49 103 571 minecraft:calcite
fill 49 103 572 49 106 572 minecraft:cobbled_deepslate
setblock 49 103 575 minecraft:cobbled_deepslate
setblock 49 103 576 minecraft:calcite
fill 49 103 577 49 106 577 minecraft:cobbled_deepslate
setblock 49 103 581 minecraft:calcite
fill 49 103 582 50 105 582 minecraft:cobbled_deepslate
setblock 49 103 585 minecraft:cobbled_deepslate
setblock 49 103 586 minecraft:calcite
fill 49 103 587 49 106 587 minecraft:cobbled_deepslate
setblock 49 103 591 minecraft:calcite
fill 49 103 592 49 106 592 minecraft:cobbled_deepslate
setblock 49 103 596 minecraft:calcite
fill 49 103 597 49 106 597 minecraft:cobbled_deepslate
setblock 50 103 575 minecraft:calcite
fill 50 103 576 51 105 576 minecraft:cobbled_deepslate
setblock 50 103 580 minecraft:calcite
fill 50 103 581 50 106 581 minecraft:cobbled_deepslate
setblock 50 103 595 minecraft:calcite
fill 50 103 596 50 106 596 minecraft:cobbled_deepslate
fill 51 103 575 51 106 575 minecraft:cobbled_deepslate
fill 51 103 577 51 103 578 minecraft:cobbled_deepslate
setblock 51 103 579 minecraft:calcite
setblock 52 103 558 minecraft:calcite
setblock 52 103 598 minecraft:calcite
fill 53 103 558 53 106 558 minecraft:cobbled_deepslate
setblock 53 103 597 minecraft:calcite
fill 53 103 598 53 106 598 minecraft:cobbled_deepslate
fill 54 103 597 54 105 597 minecraft:cobbled_deepslate
fill 55 103 558 55 104 558 minecraft:cobbled_deepslate
setblock 57 103 598 minecraft:calcite
fill 61 103 589 62 103 589 minecraft:light_blue_stained_glass
fill 64 103 558 66 103 558 minecraft:cobbled_deepslate
fill 65 103 598 66 103 598 minecraft:cobbled_deepslate
setblock 67 103 558 minecraft:calcite
fill 67 103 559 67 106 559 minecraft:cobbled_deepslate
setblock 67 103 598 minecraft:calcite
fill 68 103 558 68 106 558 minecraft:cobbled_deepslate
setblock 68 103 597 minecraft:calcite
fill 68 103 598 68 106 598 minecraft:cobbled_deepslate
setblock 69 103 594 minecraft:deepslate
fill 69 103 597 69 106 597 minecraft:cobbled_deepslate
setblock 70 103 560 minecraft:calcite
setblock 71 103 559 minecraft:calcite
fill 71 103 560 74 103 560 minecraft:cobbled_deepslate
setblock 71 103 592 minecraft:deepslate
setblock 71 103 596 minecraft:deepslate
setblock 72 103 558 minecraft:calcite
fill 72 103 559 72 106 559 minecraft:cobbled_deepslate
fill 72 103 596 73 103 596 minecraft:cobbled_deepslate
setblock 72 103 598 minecraft:calcite
fill 73 103 558 73 106 558 minecraft:cobbled_deepslate
setblock 73 103 594 minecraft:deepslate
setblock 73 103 597 minecraft:calcite
fill 73 103 598 76 103 598 minecraft:cobbled_deepslate
fill 74 103 597 74 106 597 minecraft:cobbled_deepslate
setblock 76 103 559 minecraft:calcite
setblock 77 103 558 minecraft:calcite
fill 77 103 559 77 106 559 minecraft:cobbled_deepslate
setblock 77 103 598 minecraft:calcite
fill 78 103 558 78 106 558 minecraft:cobbled_deepslate
setblock 78 103 597 minecraft:calcite
fill 78 103 598 78 106 598 minecraft:cobbled_deepslate
fill 79 103 597 79 106 597 minecraft:cobbled_deepslate
setblock 82 103 558 minecraft:calcite
setblock 82 103 598 minecraft:calcite
fill 83 103 558 83 106 558 minecraft:cobbled_deepslate
setblock 83 103 597 minecraft:calcite
fill 83 103 598 83 106 598 minecraft:cobbled_deepslate
fill 84 103 597 84 106 597 minecraft:cobbled_deepslate
fill 85 103 562 85 108 562 minecraft:deepslate
setblock 86 103 558 minecraft:cobbled_deepslate
fill 86 103 595 86 105 596 minecraft:cobbled_deepslate
setblock 87 103 558 minecraft:calcite
fill 87 103 591 87 104 591 minecraft:cobbled_deepslate
setblock 87 103 593 minecraft:calcite
fill 87 103 594 87 106 594 minecraft:cobbled_deepslate
setblock 87 103 598 minecraft:calcite
fill 88 103 558 88 106 558 minecraft:cobbled_deepslate
fill 88 103 560 88 104 560 minecraft:cobbled_deepslate
setblock 88 103 572 minecraft:calcite
fill 88 103 573 88 106 573 minecraft:cobbled_deepslate
setblock 88 103 577 minecraft:calcite
fill 88 103 578 88 106 578 minecraft:cobbled_deepslate
setblock 88 103 582 minecraft:calcite
fill 88 103 583 88 103 586 minecraft:cobbled_deepslate
setblock 88 103 587 minecraft:calcite
fill 88 103 588 88 106 588 minecraft:cobbled_deepslate
setblock 88 103 592 minecraft:calcite
fill 88 103 593 88 106 593 minecraft:cobbled_deepslate
setblock 88 103 597 minecraft:calcite
fill 88 103 598 88 106 598 minecraft:cobbled_deepslate
setblock 48 104 560 minecraft:cobbled_deepslate
setblock 48 104 561 minecraft:calcite
fill 48 104 569 48 105 569 minecraft:cobbled_deepslate
setblock 48 104 571 minecraft:calcite
fill 48 104 572 48 107 572 minecraft:cobbled_deepslate
setblock 48 104 576 minecraft:calcite
fill 48 104 577 48 107 577 minecraft:cobbled_deepslate
setblock 48 104 581 minecraft:calcite
fill 48 104 582 48 107 582 minecraft:cobbled_deepslate
setblock 48 104 586 minecraft:calcite
fill 48 104 587 48 107 587 minecraft:cobbled_deepslate
setblock 48 104 591 minecraft:calcite
fill 48 104 592 48 107 592 minecraft:cobbled_deepslate
setblock 48 104 596 minecraft:calcite
fill 48 104 597 48 107 597 minecraft:cobbled_deepslate
fill 49 104 558 50 104 558 minecraft:cobbled_deepslate
fill 49 104 571 49 107 571 minecraft:cobbled_deepslate
setblock 49 104 574 minecraft:cobbled_deepslate
setblock 49 104 575 minecraft:calcite
fill 49 104 576 49 107 576 minecraft:cobbled_deepslate
setblock 49 104 579 minecraft:cobbled_deepslate
setblock 49 104 580 minecraft:calcite
fill 49 104 581 49 107 581 minecraft:cobbled_deepslate
setblock 49 104 585 minecraft:calcite
fill 49 104 586 49 107 586 minecraft:cobbled_deepslate
setblock 49 104 590 minecraft:calcite
fill 49 104 591 49 107 591 minecraft:cobbled_deepslate
setblock 49 104 595 minecraft:calcite
fill 49 104 596 49 107 596 minecraft:cobbled_deepslate
setblock 50 104 560 minecraft:light[level=14]
setblock 50 104 568 minecraft:light[level=14]
setblock 50 104 574 minecraft:calcite
fill 50 104 575 50 107 575 minecraft:cobbled_deepslate
setblock 50 104 579 minecraft:calcite
fill 50 104 580 51 106 580 minecraft:cobbled_deepslate
setblock 50 104 583 minecraft:cobbled_deepslate
setblock 50 104 584 minecraft:calcite
setblock 50 104 592 minecraft:light[level=14]
setblock 50 104 594 minecraft:calcite
fill 50 104 595 50 105 595 minecraft:cobbled_deepslate
setblock 51 104 558 minecraft:calcite
setblock 51 104 577 minecraft:cobbled_deepslate
setblock 51 104 578 minecraft:calcite
fill 51 104 579 51 107 579 minecraft:cobbled_deepslate
fill 51 104 581 51 105 581 minecraft:cobbled_deepslate
setblock 51 104 598 minecraft:calcite
fill 52 104 558 52 107 558 minecraft:cobbled_deepslate
setblock 52 104 597 minecraft:calcite
fill 52 104 598 52 107 598 minecraft:cobbled_deepslate
fill 53 104 597 53 107 597 minecraft:cobbled_deepslate
setblock 56 104 558 minecraft:calcite
setblock 56 104 598 minecraft:calcite
fill 57 104 598 57 105 598 minecraft:cobbled_deepslate
setblock 58 104 560 minecraft:light[level=14]
setblock 58 104 568 minecraft:light[level=14]
setblock 58 104 576 minecraft:light[level=14]
setblock 58 104 584 minecraft:light[level=14]
setblock 58 104 592 minecraft:light[level=14]
fill 62 104 558 65 104 558 minecraft:cobbled_deepslate
fill 64 104 598 65 104 598 minecraft:cobbled_deepslate
setblock 65 104 559 minecraft:calcite
setblock 66 104 558 minecraft:calcite
fill 66 104 559 66 107 559 minecraft:cobbled_deepslate
setblock 66 104 560 minecraft:light[level=14]
setblock 66 104 576 minecraft:light[level=14]
setblock 66 104 584 minecraft:light[level=14]
setblock 66 104 592 minecraft:light[level=14]
setblock 66 104 598 minecraft:calcite
fill 67 104 558 67 107 558 minecraft:cobbled_deepslate
setblock 67 104 597 minecraft:calcite
fill 67 104 598 67 107 598 minecraft:cobbled_deepslate
setblock 68 104 560 minecraft:cobbled_deepslate
fill 68 104 597 68 107 597 minecraft:cobbled_deepslate
setblock 69 104 560 minecraft:calcite
setblock 70 104 559 minecraft:calcite
fill 70 104 560 73 104 560 minecraft:cobbled_deepslate
setblock 71 104 558 minecraft:calcite
fill 71 104 559 71 107 559 minecraft:cobbled_deepslate
fill 71 104 596 72 104 596 minecraft:cobbled_deepslate
setblock 71 104 598 minecraft:calcite
fill 72 104 558 72 107 558 minecraft:cobbled_deepslate
setblock 72 104 597 minecraft:calcite
fill 72 104 598 75 104 598 minecraft:cobbled_deepslate
setblock 73 104 596 minecraft:calcite
fill 73 104 597 73 107 597 minecraft:cobbled_deepslate
setblock 74 104 560 minecraft:calcite
setblock 74 104 568 minecraft:light[level=14]
setblock 74 104 576 minecraft:light[level=14]
setblock 74 104 584 minecraft:light[level=14]
setblock 74 104 592 minecraft:light[level=14]
fill 74 104 596 74 105 596 minecraft:cobbled_deepslate
setblock 75 104 559 minecraft:calcite
setblock 76 104 558 minecraft:calcite
fill 76 104 559 76 107 559 minecraft:cobbled_deepslate
setblock 76 104 598 minecraft:calcite
fill 77 104 558 77 107 558 minecraft:cobbled_deepslate
setblock 77 104 597 minecraft:calcite
fill 77 104 598 77 107 598 minecraft:cobbled_deepslate
fill 78 104 559 78 105 559 minecraft:cobbled_deepslate
fill 78 104 597 78 107 597 minecraft:cobbled_deepslate
fill 80 104 597 81 104 597 minecraft:cobbled_deepslate
setblock 81 104 558 minecraft:calcite
setblock 81 104 598 minecraft:calcite
fill 82 104 558 82 107 558 minecraft:cobbled_deepslate
setblock 82 104 560 minecraft:light[level=14]
setblock 82 104 568 minecraft:light[level=14]
setblock 82 104 576 minecraft:light[level=14]
setblock 82 104 584 minecraft:light[level=14]
setblock 82 104 592 minecraft:light[level=14]
setblock 82 104 597 minecraft:calcite
fill 82 104 598 82 107 598 minecraft:cobbled_deepslate
fill 83 104 597 83 107 597 minecraft:cobbled_deepslate
fill 85 104 596 85 106 596 minecraft:cobbled_deepslate
setblock 86 104 558 minecraft:calcite
fill 86 104 559 87 106 559 minecraft:cobbled_deepslate
setblock 86 104 598 minecraft:calcite
fill 87 104 558 87 107 558 minecraft:cobbled_deepslate
setblock 87 104 576 minecraft:cobbled_deepslate
setblock 87 104 577 minecraft:calcite
fill 87 104 578 87 104 581 minecraft:cobbled_deepslate
setblock 87 104 592 minecraft:calcite
fill 87 104 593 87 107 593 minecraft:cobbled_deepslate
setblock 87 104 597 minecraft:calcite
fill 87 104 598 87 107 598 minecraft:cobbled_deepslate
setblock 88 104 561 minecraft:calcite
fill 88 104 562 88 107 562 minecraft:cobbled_deepslate
fill 88 104 572 88 107 572 minecraft:cobbled_deepslate
setblock 88 104 576 minecraft:calcite
fill 88 104 577 88 107 577 minecraft:cobbled_deepslate
fill 88 104 579 88 104 580 minecraft:cobbled_deepslate
setblock 88 104 581 minecraft:calcite
fill 88 104 582 88 104 585 minecraft:cobbled_deepslate
setblock 88 104 586 minecraft:calcite
fill 88 104 587 88 107 587 minecraft:cobbled_deepslate
setblock 88 104 591 minecraft:calcite
fill 88 104 592 88 107 592 minecraft:cobbled_deepslate
setblock 88 104 596 minecraft:calcite
fill 88 104 597 88 107 597 minecraft:cobbled_deepslate
setblock 48 105 560 minecraft:calcite
fill 48 105 561 48 106 563 minecraft:cobbled_deepslate
fill 48 105 568 48 106 568 minecraft:cobbled_deepslate
setblock 48 105 570 minecraft:calcite
fill 48 105 571 48 108 571 minecraft:cobbled_deepslate
setblock 48 105 575 minecraft:calcite
fill 48 105 576 48 108 576 minecraft:cobbled_deepslate
setblock 48 105 580 minecraft:calcite
fill 48 105 581 48 108 581 minecraft:cobbled_deepslate
setblock 48 105 584 minecraft:cobbled_deepslate
setblock 48 105 585 minecraft:calcite
fill 48 105 586 48 108 586 minecraft:cobbled_deepslate
setblock 48 105 590 minecraft:calcite
fill 48 105 591 48 108 591 minecraft:cobbled_deepslate
setblock 48 105 595 minecraft:calcite
fill 48 105 596 48 108 596 minecraft:cobbled_deepslate
setblock 49 105 558 minecraft:cobbled_deepslate
setblock 49 105 559 minecraft:calcite
fill 49 105 560 49 108 560 minecraft:cobbled_deepslate
setblock 49 105 573 minecraft:cobbled_deepslate
setblock 49 105 574 minecraft:calcite
fill 49 105 575 49 108 575 minecraft:cobbled_deepslate
setblock 49 105 579 minecraft:calcite
fill 49 105 580 49 108 580 minecraft:cobbled_deepslate
setblock 49 105 584 minecraft:calcite
fill 49 105 585 50 107 585 minecraft:cobbled_deepslate
setblock 49 105 589 minecraft:calcite
fill 49 105 590 49 108 590 minecraft:cobbled_deepslate
setblock 49 105 594 minecraft:calcite
fill 49 105 595 49 108 595 minecraft:cobbled_deepslate
setblock 50 105 558 minecraft:calcite
fill 50 105 559 53 105 559 minecraft:cobbled_deepslate
setblock 50 105 572 minecraft:cobbled_deepslate
setblock 50 105 573 minecraft:calcite
fill 50 105 574 50 108 574 minecraft:cobbled_deepslate
setblock 50 105 578 minecraft:calcite
fill 50 105 579 50 108 579 minecraft:cobbled_deepslate
setblock 50 105 583 minecraft:calcite
fill 50 105 584 50 108 584 minecraft:cobbled_deepslate
setblock 50 105 598 minecraft:calcite
fill 51 105 558 51 108 558 minecraft:cobbled_deepslate
setblock 51 105 577 minecraft:calcite
fill 51 105 578 51 108 578 minecraft:cobbled_deepslate
setblock 51 105 582 minecraft:calcite
setblock 51 105 597 minecraft:calcite
fill 51 105 598 51 108 598 minecraft:cobbled_deepslate
fill 52 105 597 52 108 597 minecraft:cobbled_deepslate
setblock 55 105 558 minecraft:calcite
setblock 55 105 598 minecraft:calcite
fill 56 105 558 59 105 558 minecraft:cobbled_deepslate
fill 56 105 598 56 107 598 minecraft:cobbled_deepslate
setblock 60 105 558 minecraft:calcite
fill 61 105 558 64 105 558 minecraft:cobbled_deepslate
fill 63 105 598 64 105 598 minecraft:cobbled_deepslate
setblock 64 105 559 minecraft:calcite
setblock 65 105 558 minecraft:calcite
fill 65 105 559 65 108 559 minecraft:cobbled_deepslate
setblock 65 105 598 minecraft:calcite
fill 66 105 558 66 108 558 minecraft:cobbled_deepslate
fill 66 105 560 67 105 560 minecraft:cobbled_deepslate
setblock 66 105 597 minecraft:calcite
fill 66 105 598 66 108 598 minecraft:cobbled_deepslate
fill 67 105 597 67 108 597 minecraft:cobbled_deepslate
setblock 68 105 560 minecraft:calcite
setblock 69 105 559 minecraft:calcite
fill 69 105 560 72 105 560 minecraft:cobbled_deepslate
setblock 70 105 558 minecraft:calcite
fill 70 105 559 70 108 559 minecraft:cobbled_deepslate
fill 70 105 596 71 105 596 minecraft:cobbled_deepslate
setblock 70 105 598 minecraft:calcite
fill 71 105 558 71 108 558 minecraft:cobbled_deepslate
setblock 71 105 597 minecraft:calcite
fill 71 105 598 74 105 598 minecraft:cobbled_deepslate
setblock 72 105 596 minecraft:calcite
fill 72 105 597 72 108 597 minecraft:cobbled_deepslate
setblock 73 105 560 minecraft:calcite
fill 73 105 596 73 106 596 minecraft:cobbled_deepslate
setblock 74 105 559 minecraft:calcite
fill 74 105 560 75 107 560 minecraft:cobbled_deepslate
setblock 75 105 558 minecraft:calcite
fill 75 105 559 75 108 559 minecraft:cobbled_deepslate
setblock 75 105 598 minecraft:calcite
fill 76 105 558 76 108 558 minecraft:cobbled_deepslate
setblock 76 105 597 minecraft:calcite
fill 76 105 598 76 108 598 minecraft:cobbled_deepslate
fill 77 105 597 77 108 597 minecraft:cobbled_deepslate
setblock 79 105 559 minecraft:calcite
setblock 80 105 558 minecraft:calcite
setblock 80 105 597 minecraft:cobbled_deepslate
setblock 80 105 598 minecraft:calcite
fill 81 105 558 81 108 558 minecraft:cobbled_deepslate
setblock 81 105 597 minecraft:calcite
fill 81 105 598 81 108 598 minecraft:cobbled_deepslate
fill 82 105 597 82 108 597 minecraft:cobbled_deepslate
setblock 84 105 558 minecraft:cobbled_deepslate
setblock 84 105 559 minecraft:calcite
fill 84 105 596 84 107 596 minecraft:cobbled_deepslate
setblock 85 105 558 minecraft:calcite
fill 85 105 559 85 108 559 minecraft:cobbled_deepslate
setblock 85 105 598 minecraft:calcite
fill 86 105 558 86 108 558 minecraft:cobbled_deepslate
fill 86 105 594 86 107 594 minecraft:cobbled_deepslate
setblock 86 105 597 minecraft:calcite
fill 86 105 598 86 108 598 minecraft:cobbled_deepslate
setblock 87 105 560 minecraft:cobbled_deepslate
setblock 87 105 575 minecraft:cobbled_deepslate
setblock 87 105 576 minecraft:calcite
fill 87 105 577 87 105 580 minecraft:cobbled_deepslate
setblock 87 105 581 minecraft:calcite
fill 87 105 582 87 105 585 minecraft:cobbled_deepslate
setblock 87 105 586 minecraft:calcite
fill 87 105 589 87 105 590 minecraft:cobbled_deepslate
setblock 87 105 591 minecraft:calcite
fill 87 105 592 87 108 592 minecraft:cobbled_deepslate
setblock 87 105 596 minecraft:calcite
fill 87 105 597 87 108 597 minecraft:cobbled_deepslate
setblock 88 105 560 minecraft:calcite
fill 88 105 561 88 108 561 minecraft:cobbled_deepslate
fill 88 105 563 88 106 563 minecraft:cobbled_deepslate
fill 88 105 571 88 108 571 minecraft:cobbled_deepslate
setblock 88 105 575 minecraft:calcite
fill 88 105 576 88 108 576 minecraft:cobbled_deepslate
setblock 88 105 579 minecraft:cobbled_deepslate
setblock 88 105 580 minecraft:calcite
fill 88 105 581 88 105 584 minecraft:cobbled_deepslate
setblock 88 105 585 minecraft:calcite
fill 88 105 586 88 108 586 minecraft:cobbled_deepslate
setblock 88 105 590 minecraft:calcite
fill 88 105 591 88 108 591 minecraft:cobbled_deepslate
setblock 88 105 595 minecraft:calcite
fill 88 105 596 88 108 596 minecraft:cobbled_deepslate
setblock 48 106 558 minecraft:cobbled_deepslate
setblock 48 106 559 minecraft:calcite
fill 48 106 560 48 109 560 minecraft:cobbled_deepslate
setblock 48 106 564 minecraft:calcite
fill 48 106 565 48 107 567 minecraft:cobbled_deepslate
setblock 48 106 569 minecraft:calcite
fill 48 106 570 49 108 570 minecraft:cobbled_deepslate
setblock 48 106 574 minecraft:calcite
fill 48 106 575 48 109 575 minecraft:cobbled_deepslate
setblock 48 106 579 minecraft:calcite
fill 48 106 580 48 109 580 minecraft:cobbled_deepslate
setblock 48 106 584 minecraft:calcite
fill 48 106 585 48 109 585 minecraft:cobbled_deepslate
setblock 48 106 588 minecraft:cobbled_deepslate
setblock 48 106 589 minecraft:calcite
fill 48 106 590 48 109 590 minecraft:cobbled_deepslate
setblock 48 106 594 minecraft:calcite
fill 48 106 595 48 109 595 minecraft:cobbled_deepslate
setblock 49 106 558 minecraft:calcite
fill 49 106 559 52 106 559 minecraft:cobbled_deepslate
fill 49 106 561 49 106 562 minecraft:cobbled_deepslate
setblock 49 106 573 minecraft:calcite
fill 49 106 574 49 109 574 minecraft:cobbled_deepslate
setblock 49 106 578 minecraft:calcite
fill 49 106 579 49 109 579 minecraft:cobbled_deepslate
setblock 49 106 582 minecraft:cobbled_deepslate
setblock 49 106 583 minecraft:calcite
fill 49 106 584 49 109 584 minecraft:cobbled_deepslate
setblock 49 106 588 minecraft:calcite
fill 49 106 589 49 109 589 minecraft:cobbled_deepslate
setblock 49 106 593 minecraft:calcite
fill 49 106 594 49 109 594 minecraft:cobbled_deepslate
setblock 49 106 598 minecraft:calcite
fill 50 106 558 50 109 558 minecraft:cobbled_deepslate
setblock 50 106 572 minecraft:calcite
fill 50 106 573 50 109 573 minecraft:cobbled_deepslate
setblock 50 106 576 minecraft:cobbled_deepslate
setblock 50 106 577 minecraft:calcite
fill 50 106 578 50 109 578 minecraft:cobbled_deepslate
setblock 50 106 582 minecraft:calcite
fill 50 106 583 51 108 583 minecraft:cobbled_deepslate
setblock 50 106 586 minecraft:cobbled_deepslate
setblock 50 106 597 minecraft:calcite
fill 50 106 598 50 109 598 minecraft:cobbled_deepslate
setblock 51 106 576 minecraft:calcite
fill 51 106 577 51 109 577 minecraft:cobbled_deepslate
setblock 51 106 581 minecraft:calcite
fill 51 106 582 51 109 582 minecraft:cobbled_deepslate
fill 51 106 597 51 108 597 minecraft:cobbled_deepslate
setblock 53 106 559 minecraft:calcite
setblock 54 106 558 minecraft:calcite
fill 54 106 559 54 109 559 minecraft:cobbled_deepslate
setblock 54 106 598 minecraft:calcite
fill 55 106 558 58 106 558 minecraft:cobbled_deepslate
fill 55 106 598 55 108 598 minecraft:cobbled_deepslate
setblock 59 106 558 minecraft:calcite
fill 60 106 558 63 106 558 minecraft:cobbled_deepslate
setblock 62 106 559 minecraft:cobbled_deepslate
fill 62 106 598 63 106 598 minecraft:cobbled_deepslate
setblock 63 106 559 minecraft:calcite
setblock 64 106 558 minecraft:calcite
fill 64 106 559 64 109 559 minecraft:cobbled_deepslate
setblock 64 106 598 minecraft:calcite
fill 65 106 558 65 109 558 minecraft:cobbled_deepslate
fill 65 106 560 66 106 560 minecraft:cobbled_deepslate
setblock 65 106 597 minecraft:calcite
fill 65 106 598 65 109 598 minecraft:cobbled_deepslate
fill 66 106 597 66 109 597 minecraft:cobbled_deepslate
setblock 67 106 560 minecraft:calcite
setblock 68 106 559 minecraft:calcite
fill 68 106 560 70 106 561 minecraft:cobbled_deepslate
setblock 69 106 558 minecraft:calcite
fill 69 106 559 69 109 559 minecraft:cobbled_deepslate
fill 69 106 596 70 106 596 minecraft:cobbled_deepslate
setblock 69 106 598 minecraft:calcite
fill 70 106 558 70 109 558 minecraft:cobbled_deepslate
setblock 70 106 597 minecraft:calcite
fill 70 106 598 73 106 598 minecraft:cobbled_deepslate
setblock 71 106 560 minecraft:cobbled_deepslate
setblock 71 106 561 minecraft:calcite
setblock 71 106 596 minecraft:calcite
fill 71 106 597 71 109 597 minecraft:cobbled_deepslate
setblock 72 106 560 minecraft:calcite
fill 72 106 561 72 109 561 minecraft:cobbled_deepslate
fill 72 106 596 72 107 596 minecraft:cobbled_deepslate
setblock 73 106 559 minecraft:calcite
fill 73 106 560 73 109 560 minecraft:cobbled_deepslate
setblock 74 106 558 minecraft:calcite
fill 74 106 559 74 109 559 minecraft:cobbled_deepslate
setblock 74 106 598 minecraft:calcite
fill 75 106 558 75 109 558 minecraft:cobbled_deepslate
setblock 75 106 597 minecraft:calcite
fill 75 106 598 75 109 598 minecraft:cobbled_deepslate
setblock 76 106 560 minecraft:cobbled_deepslate
fill 76 106 597 76 109 597 minecraft:cobbled_deepslate
setblock 78 106 559 minecraft:calcite
setblock 79 106 558 minecraft:calcite
fill 79 106 559 82 106 559 minecraft:cobbled_deepslate
setblock 79 106 598 minecraft:calcite
fill 80 106 558 80 109 558 minecraft:cobbled_deepslate
setblock 80 106 597 minecraft:calcite
fill 80 106 598 80 109 598 minecraft:cobbled_deepslate
fill 81 106 597 81 109 597 minecraft:cobbled_deepslate
setblock 83 106 559 minecraft:calcite
setblock 84 106 558 minecraft:calcite
fill 84 106 559 84 109 559 minecraft:cobbled_deepslate
fill 84 106 562 84 108 562 minecraft:deepslate
setblock 84 106 598 minecraft:calcite
fill 85 106 558 85 109 558 minecraft:cobbled_deepslate
fill 85 106 561 85 108 561 minecraft:deepslate
fill 85 106 563 85 108 563 minecraft:deepslate
setblock 85 106 597 minecraft:calcite
fill 85 106 598 85 109 598 minecraft:cobbled_deepslate
fill 86 106 562 86 108 562 minecraft:deepslate
fill 86 106 579 86 106 580 minecraft:cobbled_deepslate
setblock 86 106 595 minecraft:cobbled_deepslate
setblock 86 106 596 minecraft:calcite
fill 86 106 597 86 109 597 minecraft:cobbled_deepslate
setblock 87 106 560 minecraft:calcite
fill 87 106 561 87 109 561 minecraft:cobbled_deepslate
setblock 87 106 574 minecraft:cobbled_deepslate
setblock 87 106 575 minecraft:calcite
fill 87 106 576 87 106 579 minecraft:cobbled_deepslate
setblock 87 106 580 minecraft:calcite
fill 87 106 581 87 106 584 minecraft:cobbled_deepslate
setblock 87 106 585 minecraft:calcite
fill 87 106 586 87 106 589 minecraft:cobbled_deepslate
setblock 87 106 590 minecraft:calcite
fill 87 106 591 87 109 591 minecraft:cobbled_deepslate
setblock 87 106 595 minecraft:calcite
fill 87 106 596 87 109 596 minecraft:cobbled_deepslate
setblock 88 106 559 minecraft:calcite
fill 88 106 560 88 109 560 minecraft:cobbled_deepslate
setblock 88 106 564 minecraft:calcite
fill 88 106 570 88 109 570 minecraft:cobbled_deepslate
setblock 88 106 574 minecraft:calcite
fill 88 106 575 88 109 575 minecraft:cobbled_deepslate
setblock 88 106 579 minecraft:calcite
fill 88 106 580 88 106 583 minecraft:cobbled_deepslate
setblock 88 106 584 minecraft:calcite
fill 88 106 585 88 109 585 minecraft:cobbled_deepslate
setblock 88 106 589 minecraft:calcite
fill 88 106 590 88 109 590 minecraft:cobbled_deepslate
setblock 88 106 594 minecraft:calcite
fill 88 106 595 88 109 595 minecraft:cobbled_deepslate
setblock 48 107 558 minecraft:calcite
fill 48 107 559 51 107 559 minecraft:cobbled_deepslate
fill 48 107 561 48 107 562 minecraft:cobbled_deepslate
setblock 48 107 563 minecraft:calcite
fill 48 107 564 49 109 564 minecraft:cobbled_deepslate
setblock 48 107 568 minecraft:calcite
fill 48 107 569 49 109 569 minecraft:cobbled_deepslate
setblock 48 107 573 minecraft:calcite
fill 48 107 574 48 110 574 minecraft:cobbled_deepslate
setblock 48 107 578 minecraft:calcite
fill 48 107 579 48 110 579 minecraft:cobbled_deepslate
setblock 48 107 583 minecraft:calcite
fill 48 107 584 48 110 584 minecraft:cobbled_deepslate
setblock 48 107 588 minecraft:calcite
fill 48 107 589 48 110 589 minecraft:cobbled_deepslate
setblock 48 107 593 minecraft:calcite
fill 48 107 594 48 110 594 minecraft:cobbled_deepslate
setblock 48 107 598 minecraft:calcite
fill 49 107 558 49 110 558 minecraft:cobbled_deepslate
setblock 49 107 561 minecraft:cobbled_deepslate
setblock 49 107 562 minecraft:calcite
fill 49 107 563 49 110 563 minecraft:cobbled_deepslate
setblock 49 107 572 minecraft:calcite
fill 49 107 573 49 110 573 minecraft:cobbled_deepslate
setblock 49 107 577 minecraft:calcite
fill 49 107 578 49 110 578 minecraft:cobbled_deepslate
setblock 49 107 582 minecraft:calcite
fill 49 107 583 49 110 583 minecraft:cobbled_deepslate
setblock 49 107 587 minecraft:calcite
fill 49 107 588 49 110 588 minecraft:cobbled_deepslate
setblock 49 107 592 minecraft:calcite
fill 49 107 593 49 109 593 minecraft:cobbled_deepslate
setblock 49 107 597 minecraft:calcite
fill 49 107 598 49 110 598 minecraft:cobbled_deepslate
setblock 50 107 572 minecraft:cobbled_deepslate
setblock 50 107 576 minecraft:calcite
fill 50 107 577 50 110 577 minecraft:cobbled_deepslate
setblock 50 107 580 minecraft:cobbled_deepslate
setblock 50 107 581 minecraft:calcite
fill 50 107 582 50 110 582 minecraft:cobbled_deepslate
setblock 50 107 586 minecraft:calcite
fill 50 107 587 50 110 587 minecraft:cobbled_deepslate
fill 50 107 597 50 109 597 minecraft:cobbled_deepslate
setblock 51 107 575 minecraft:calcite
fill 51 107 576 51 109 576 minecraft:cobbled_deepslate
setblock 51 107 580 minecraft:calcite
fill 51 107 581 51 110 581 minecraft:cobbled_deepslate
setblock 52 107 559 minecraft:calcite
setblock 53 107 558 minecraft:calcite
fill 53 107 559 53 110 559 minecraft:cobbled_deepslate
setblock 53 107 598 minecraft:calcite
fill 54 107 558 57 107 558 minecraft:cobbled_deepslate
fill 54 107 598 54 109 598 minecraft:cobbled_deepslate
fill 55 107 559 55 108 559 minecraft:cobbled_deepslate
setblock 58 107 558 minecraft:calcite
fill 59 107 558 62 107 558 minecraft:cobbled_deepslate
fill 60 107 559 61 107 559 minecraft:cobbled_deepslate
fill 61 107 598 62 107 598 minecraft:cobbled_deepslate
setblock 62 107 559 minecraft:calcite
setblock 63 107 558 minecraft:calcite
fill 63 107 559 63 109 560 minecraft:cobbled_deepslate
setblock 63 107 598 minecraft:calcite
fill 64 107 558 64 110 558 minecraft:cobbled_deepslate
fill 64 107 560 65 107 560 minecraft:cobbled_deepslate
fill 64 107 598 64 110 598 minecraft:cobbled_deepslate
fill 65 107 597 65 110 597 minecraft:cobbled_deepslate
setblock 66 107 560 minecraft:calcite
fill 66 107 561 69 107 561 minecraft:cobbled_deepslate
setblock 67 107 559 minecraft:calcite
fill 67 107 560 70 107 560 minecraft:cobbled_deepslate
setblock 68 107 558 minecraft:calcite
fill 68 107 559 68 110 559 minecraft:cobbled_deepslate
setblock 68 107 598 minecraft:calcite
fill 69 107 558 69 110 558 minecraft:cobbled_deepslate
setblock 69 107 596 minecraft:cobbled_deepslate
setblock 69 107 597 minecraft:calcite
fill 69 107 598 72 107 598 minecraft:cobbled_deepslate
setblock 70 107 561 minecraft:calcite
setblock 70 107 596 minecraft:calcite
fill 70 107 597 70 110 597 minecraft:cobbled_deepslate
setblock 71 107 560 minecraft:calcite
fill 71 107 561 71 110 561 minecraft:cobbled_deepslate
fill 71 107 596 71 108 596 minecraft:cobbled_deepslate
setblock 72 107 559 minecraft:calcite
fill 72 107 560 72 110 560 minecraft:cobbled_deepslate
setblock 73 107 558 minecraft:calcite
fill 73 107 559 73 110 559 minecraft:cobbled_deepslate
setblock 73 107 598 minecraft:calcite
fill 74 107 558 74 110 558 minecraft:cobbled_deepslate
setblock 74 107 597 minecraft:calcite
fill 74 107 598 74 110 598 minecraft:cobbled_deepslate
fill 75 107 597 75 109 597 minecraft:cobbled_deepslate
setblock 76 107 560 minecraft:calcite
setblock 77 107 559 minecraft:calcite
setblock 78 107 558 minecraft:calcite
fill 78 107 559 81 107 559 minecraft:cobbled_deepslate
setblock 78 107 598 minecraft:calcite
fill 79 107 558 79 110 558 minecraft:cobbled_deepslate
setblock 79 107 597 minecraft:calcite
fill 79 107 598 79 110 598 minecraft:cobbled_deepslate
fill 80 107 597 80 110 597 minecraft:cobbled_deepslate
setblock 82 107 559 minecraft:calcite
setblock 83 107 558 minecraft:calcite
fill 83 107 559 83 110 559 minecraft:cobbled_deepslate
fill 83 107 596 83 108 596 minecraft:cobbled_deepslate
setblock 83 107 598 minecraft:calcite
fill 84 107 558 84 110 558 minecraft:cobbled_deepslate
setblock 84 107 597 minecraft:calcite
fill 84 107 598 84 110 598 minecraft:cobbled_deepslate
setblock 85 107 596 minecraft:calcite
fill 85 107 597 85 110 597 minecraft:cobbled_deepslate
setblock 86 107 559 minecraft:cobbled_deepslate
setblock 86 107 560 minecraft:calcite
fill 86 107 577 86 107 579 minecraft:cobbled_deepslate
setblock 86 107 580 minecraft:calcite
fill 86 107 581 86 107 584 minecraft:cobbled_deepslate
fill 86 107 593 86 108 593 minecraft:cobbled_deepslate
setblock 86 107 595 minecraft:calcite
fill 86 107 596 86 110 596 minecraft:cobbled_deepslate
setblock 87 107 559 minecraft:calcite
fill 87 107 560 87 110 560 minecraft:cobbled_deepslate
fill 87 107 562 87 108 562 minecraft:cobbled_deepslate
setblock 87 107 574 minecraft:calcite
fill 87 107 575 87 107 578 minecraft:cobbled_deepslate
setblock 87 107 579 minecraft:calcite
fill 87 107 580 87 107 583 minecraft:cobbled_deepslate
setblock 87 107 584 minecraft:calcite
fill 87 107 585 87 107 588 minecraft:cobbled_deepslate
setblock 87 107 589 minecraft:calcite
fill 87 107 590 87 110 590 minecraft:cobbled_deepslate
setblock 87 107 594 minecraft:calcite
fill 87 107 595 87 110 595 minecraft:cobbled_deepslate
setblock 88 107 558 minecraft:calcite
fill 88 107 559 88 110 559 minecraft:cobbled_deepslate
setblock 88 107 563 minecraft:calcite
fill 88 107 564 88 108 566 minecraft:cobbled_deepslate
setblock 88 107 573 minecraft:calcite
fill 88 107 574 88 110 574 minecraft:cobbled_deepslate
setblock 88 107 578 minecraft:calcite
fill 88 107 579 88 107 582 minecraft:cobbled_deepslate
setblock 88 107 583 minecraft:calcite
fill 88 107 584 88 110 584 minecraft:cobbled_deepslate
setblock 88 107 588 minecraft:calcite
fill 88 107 589 88 110 589 minecraft:cobbled_deepslate
setblock 88 107 593 minecraft:calcite
fill 88 107 594 88 110 594 minecraft:cobbled_deepslate
setblock 88 107 598 minecraft:calcite
fill 48 108 558 48 110 559 minecraft:cobbled_deepslate
setblock 48 108 561 minecraft:cobbled_deepslate
setblock 48 108 562 minecraft:calcite
fill 48 108 563 48 111 563 minecraft:cobbled_deepslate
fill 48 108 565 48 108 566 minecraft:cobbled_deepslate
setblock 48 108 567 minecraft:calcite
fill 48 108 568 48 111 568 minecraft:cobbled_deepslate
setblock 48 108 572 minecraft:calcite
fill 48 108 573 48 111 573 minecraft:cobbled_deepslate
setblock 48 108 577 minecraft:calcite
fill 48 108 578 48 111 578 minecraft:cobbled_deepslate
setblock 48 108 582 minecraft:calcite
fill 48 108 583 48 111 583 minecraft:cobbled_deepslate
setblock 48 108 587 minecraft:calcite
fill 48 108 588 48 111 588 minecraft:cobbled_deepslate
setblock 48 108 592 minecraft:calcite
fill 48 108 593 48 111 593 minecraft:cobbled_deepslate
setblock 48 108 597 minecraft:calcite
fill 48 108 598 48 111 598 minecraft:cobbled_deepslate
fill 49 108 559 50 108 559 minecraft:cobbled_deepslate
setblock 49 108 561 minecraft:calcite
fill 49 108 562 49 111 562 minecraft:cobbled_deepslate
setblock 49 108 565 minecraft:cobbled_deepslate
setblock 49 108 566 minecraft:calcite
setblock 49 108 571 minecraft:calcite
fill 49 108 572 49 111 572 minecraft:cobbled_deepslate
setblock 49 108 576 minecraft:calcite
fill 49 108 577 49 111 577 minecraft:cobbled_deepslate
setblock 49 108 581 minecraft:calcite
fill 49 108 582 49 111 582 minecraft:cobbled_deepslate
setblock 49 108 585 minecraft:cobbled_deepslate
setblock 49 108 586 minecraft:calcite
fill 49 108 587 49 111 587 minecraft:cobbled_deepslate
setblock 49 108 591 minecraft:calcite
fill 49 108 592 49 109 592 minecraft:cobbled_deepslate
setblock 49 108 596 minecraft:calcite
fill 49 108 597 49 110 597 minecraft:cobbled_deepslate
setblock 50 108 560 minecraft:calcite
setblock 50 108 575 minecraft:calcite
fill 50 108 576 50 111 576 minecraft:cobbled_deepslate
setblock 50 108 580 minecraft:calcite
fill 50 108 581 50 111 581 minecraft:cobbled_deepslate
setblock 50 108 585 minecraft:calcite
fill 50 108 586 50 111 586 minecraft:cobbled_deepslate
setblock 51 108 559 minecraft:calcite
setblock 51 108 575 minecraft:cobbled_deepslate
setblock 51 108 579 minecraft:calcite
fill 51 108 580 51 110 580 minecraft:cobbled_deepslate
setblock 51 108 584 minecraft:calcite
setblock 52 108 558 minecraft:calcite
fill 52 108 559 52 111 559 minecraft:cobbled_deepslate
setblock 52 108 598 minecraft:calcite
fill 53 108 558 56 108 558 minecraft:cobbled_deepslate
fill 53 108 598 53 109 598 minecraft:cobbled_deepslate
setblock 57 108 558 minecraft:calcite
fill 58 108 558 61 108 558 minecraft:cobbled_deepslate
fill 59 108 559 60 108 559 minecraft:cobbled_deepslate
setblock 61 108 559 minecraft:calcite
setblock 61 108 598 minecraft:cobbled_deepslate
setblock 62 108 558 minecraft:calcite
fill 62 108 559 62 110 560 minecraft:cobbled_deepslate
setblock 62 108 598 minecraft:calcite
fill 63 108 558 63 111 558 minecraft:cobbled_deepslate
fill 63 108 598 63 111 598 minecraft:cobbled_deepslate
setblock 64 108 560 minecraft:cobbled_deepslate
setblock 65 108 560 minecraft:calcite
fill 65 108 561 68 108 561 minecraft:cobbled_deepslate
setblock 66 108 559 minecraft:calcite
fill 66 108 560 69 108 560 minecraft:cobbled_deepslate
setblock 67 108 558 minecraft:calcite
fill 67 108 559 67 111 559 minecraft:cobbled_deepslate
setblock 67 108 598 minecraft:calcite
fill 68 108 558 68 111 558 minecraft:cobbled_deepslate
setblock 68 108 597 minecraft:calcite
fill 68 108 598 71 108 598 minecraft:cobbled_deepslate
setblock 69 108 561 minecraft:calcite
setblock 69 108 596 minecraft:calcite
fill 69 108 597 69 111 597 minecraft:cobbled_deepslate
setblock 70 108 560 minecraft:calcite
fill 70 108 561 70 111 561 minecraft:cobbled_deepslate
setblock 70 108 596 minecraft:cobbled_deepslate
setblock 71 108 559 minecraft:calcite
fill 71 108 560 71 111 560 minecraft:cobbled_deepslate
setblock 72 108 558 minecraft:calcite
fill 72 108 559 72 111 559 minecraft:cobbled_deepslate
setblock 72 108 598 minecraft:calcite
fill 73 108 558 73 111 558 minecraft:cobbled_deepslate
setblock 73 108 561 minecraft:cobbled_deepslate
setblock 73 108 597 minecraft:calcite
fill 73 108 598 73 111 598 minecraft:cobbled_deepslate
setblock 74 108 560 minecraft:cobbled_deepslate
fill 74 108 597 74 110 597 minecraft:cobbled_deepslate
setblock 75 108 560 minecraft:calcite
setblock 76 108 559 minecraft:calcite
setblock 76 108 560 minecraft:cobbled_deepslate
setblock 77 108 558 minecraft:calcite
fill 77 108 559 80 108 559 minecraft:cobbled_deepslate
setblock 77 108 598 minecraft:calcite
fill 78 108 558 78 111 558 minecraft:cobbled_deepslate
setblock 78 108 597 minecraft:calcite
fill 78 108 598 78 111 598 minecraft:cobbled_deepslate
fill 79 108 597 79 109 597 minecraft:cobbled_deepslate
setblock 81 108 559 minecraft:calcite
setblock 82 108 558 minecraft:calcite
fill 82 108 559 82 111 559 minecraft:cobbled_deepslate
setblock 82 108 598 minecraft:calcite
fill 83 108 558 83 111 558 minecraft:cobbled_deepslate
setblock 83 108 597 minecraft:calcite
fill 83 108 598 83 111 598 minecraft:cobbled_deepslate
setblock 84 108 561 minecraft:deepslate
setblock 84 108 563 minecraft:deepslate
setblock 84 108 596 minecraft:calcite
fill 84 108 597 84 111 597 minecraft:cobbled_deepslate
setblock 85 108 560 minecraft:calcite
fill 85 108 596 85 110 596 minecraft:cobbled_deepslate
setblock 86 108 559 minecraft:calcite
fill 86 108 560 86 111 560 minecraft:cobbled_deepslate
setblock 86 108 561 minecraft:deepslate
setblock 86 108 563 minecraft:deepslate
fill 86 108 577 86 108 578 minecraft:cobbled_deepslate
setblock 86 108 579 minecraft:calcite
fill 86 108 580 86 108 583 minecraft:cobbled_deepslate
setblock 86 108 584 minecraft:calcite
fill 86 108 585 87 108 587 minecraft:cobbled_deepslate
setblock 86 108 594 minecraft:calcite
fill 86 108 595 86 110 595 minecraft:cobbled_deepslate
setblock 87 108 558 minecraft:calcite
fill 87 108 559 87 111 559 minecraft:cobbled_deepslate
setblock 87 108 563 minecraft:calcite
fill 87 108 574 87 108 577 minecraft:cobbled_deepslate
setblock 87 108 578 minecraft:calcite
fill 87 108 579 87 108 582 minecraft:cobbled_deepslate
setblock 87 108 583 minecraft:calcite
fill 87 108 584 87 111 584 minecraft:cobbled_deepslate
setblock 87 108 588 minecraft:calcite
fill 87 108 589 87 111 589 minecraft:cobbled_deepslate
setblock 87 108 593 minecraft:calcite
fill 87 108 594 87 111 594 minecraft:cobbled_deepslate
setblock 87 108 598 minecraft:calcite
fill 88 108 558 88 111 558 minecraft:cobbled_deepslate
setblock 88 108 562 minecraft:calcite
fill 88 108 563 88 111 563 minecraft:cobbled_deepslate
setblock 88 108 567 minecraft:calcite
fill 88 108 568 88 110 569 minecraft:cobbled_deepslate
setblock 88 108 572 minecraft:calcite
fill 88 108 573 88 111 573 minecraft:cobbled_deepslate
setblock 88 108 577 minecraft:calcite
fill 88 108 578 88 108 581 minecraft:cobbled_deepslate
setblock 88 108 582 minecraft:calcite
fill 88 108 583 88 111 583 minecraft:cobbled_deepslate
setblock 88 108 587 minecraft:calcite
fill 88 108 588 88 111 588 minecraft:cobbled_deepslate
setblock 88 108 592 minecraft:calcite
fill 88 108 593 88 111 593 minecraft:cobbled_deepslate
setblock 88 108 597 minecraft:calcite
fill 88 108 598 88 111 598 minecraft:cobbled_deepslate
setblock 48 109 561 minecraft:calcite
fill 48 109 562 48 112 562 minecraft:cobbled_deepslate
setblock 48 109 565 minecraft:cobbled_deepslate
setblock 48 109 566 minecraft:calcite
fill 48 109 567 49 111 567 minecraft:cobbled_deepslate
setblock 48 109 570 minecraft:cobbled_deepslate
setblock 48 109 571 minecraft:calcite
fill 48 109 572 48 112 572 minecraft:cobbled_deepslate
setblock 48 109 576 minecraft:calcite
fill 48 109 577 48 112 577 minecraft:cobbled_deepslate
setblock 48 109 581 minecraft:calcite
fill 48 109 582 48 112 582 minecraft:cobbled_deepslate
setblock 48 109 586 minecraft:calcite
fill 48 109 587 48 112 587 minecraft:cobbled_deepslate
setblock 48 109 591 minecraft:calcite
fill 48 109 592 48 112 592 minecraft:cobbled_deepslate
setblock 48 109 596 minecraft:calcite
fill 48 109 597 48 112 597 minecraft:cobbled_deepslate
setblock 49 109 559 minecraft:cobbled_deepslate
setblock 49 109 560 minecraft:calcite
fill 49 109 561 49 112 561 minecraft:cobbled_deepslate
setblock 49 109 565 minecraft:calcite
fill 49 109 566 49 112 566 minecraft:cobbled_deepslate
fill 49 109 568 49 110 568 minecraft:cobbled_deepslate
setblock 49 109 570 minecraft:calcite
fill 49 109 571 49 111 571 minecraft:cobbled_deepslate
setblock 49 109 575 minecraft:calcite
fill 49 109 576 49 112 576 minecraft:cobbled_deepslate
setblock 49 109 580 minecraft:calcite
fill 49 109 581 49 112 581 minecraft:cobbled_deepslate
setblock 49 109 585 minecraft:calcite
fill 49 109 586 49 112 586 minecraft:cobbled_deepslate
setblock 49 109 590 minecraft:calcite
setblock 49 109 591 minecraft:cobbled_deepslate
setblock 49 109 595 minecraft:calcite
setblock 49 109 596 minecraft:cobbled_deepslate
setblock 50 109 559 minecraft:calcite
setblock 50 109 560 minecraft:cobbled_deepslate
setblock 50 109 574 minecraft:calcite
fill 50 109 575 50 110 575 minecraft:cobbled_deepslate
setblock 50 109 579 minecraft:calcite
fill 50 109 580 50 112 580 minecraft:cobbled_deepslate
setblock 50 109 583 minecraft:cobbled_deepslate
setblock 50 109 584 minecraft:calcite
fill 50 109 585 50 112 585 minecraft:cobbled_deepslate
setblock 51 109 558 minecraft:calcite
fill 51 109 559 51 111 559 minecraft:cobbled_deepslate
setblock 51 109 578 minecraft:calcite
fill 51 109 579 51 110 579 minecraft:cobbled_deepslate
setblock 51 109 583 minecraft:calcite
setblock 51 109 584 minecraft:cobbled_deepslate
setblock 51 109 598 minecraft:calcite
fill 52 109 558 55 109 558 minecraft:cobbled_deepslate
fill 52 109 598 52 110 598 minecraft:cobbled_deepslate
setblock 55 109 559 minecraft:calcite
setblock 56 109 558 minecraft:calcite
fill 57 109 558 60 109 558 minecraft:cobbled_deepslate
fill 58 109 559 59 109 559 minecraft:cobbled_deepslate
setblock 60 109 559 minecraft:calcite
setblock 61 109 558 minecraft:calcite
fill 61 109 559 61 111 560 minecraft:cobbled_deepslate
setblock 61 109 598 minecraft:calcite
fill 62 109 558 62 112 558 minecraft:cobbled_deepslate
fill 62 109 598 62 112 598 minecraft:cobbled_deepslate
setblock 64 109 560 minecraft:calcite
fill 64 109 561 67 109 561 minecraft:cobbled_deepslate
setblock 65 109 559 minecraft:calcite
fill 65 109 560 68 109 560 minecraft:cobbled_deepslate
setblock 66 109 558 minecraft:calcite
fill 66 109 559 66 112 559 minecraft:cobbled_deepslate
setblock 66 109 598 minecraft:calcite
fill 67 109 558 67 112 558 minecraft:cobbled_deepslate
setblock 67 109 597 minecraft:calcite
fill 67 109 598 70 109 598 minecraft:cobbled_deepslate
setblock 68 109 561 minecraft:calcite
fill 68 109 597 68 112 597 minecraft:cobbled_deepslate
setblock 69 109 560 minecraft:calcite
fill 69 109 561 69 112 561 minecraft:cobbled_deepslate
setblock 70 109 559 minecraft:calcite
fill 70 109 560 70 112 560 minecraft:cobbled_deepslate
setblock 71 109 558 minecraft:calcite
fill 71 109 559 71 112 559 minecraft:cobbled_deepslate
setblock 71 109 598 minecraft:calcite
fill 72 109 558 72 112 558 minecraft:cobbled_deepslate
setblock 72 109 597 minecraft:calcite
fill 72 109 598 72 112 598 minecraft:cobbled_deepslate
fill 73 109 597 73 110 597 minecraft:cobbled_deepslate
setblock 74 109 560 minecraft:calcite
setblock 75 109 559 minecraft:calcite
fill 75 109 560 75 110 560 minecraft:cobbled_deepslate
setblock 76 109 558 minecraft:calcite
fill 76 109 559 79 109 559 minecraft:cobbled_deepslate
setblock 76 109 598 minecraft:calcite
fill 77 109 558 77 112 558 minecraft:cobbled_deepslate
setblock 77 109 597 minecraft:calcite
fill 77 109 598 77 112 598 minecraft:cobbled_deepslate
setblock 78 109 597 minecraft:cobbled_deepslate
setblock 80 109 559 minecraft:calcite
setblock 81 109 558 minecraft:calcite
fill 81 109 559 81 112 559 minecraft:cobbled_deepslate
setblock 81 109 598 minecraft:calcite
fill 82 109 558 82 112 558 minecraft:cobbled_deepslate
setblock 82 109 597 minecraft:calcite
fill 82 109 598 82 112 598 minecraft:cobbled_deepslate
fill 83 109 597 83 112 597 minecraft:cobbled_deepslate
setblock 84 109 560 minecraft:calcite
fill 84 109 596 84 110 596 minecraft:cobbled_deepslate
setblock 85 109 559 minecraft:calcite
fill 85 109 560 85 111 560 minecraft:cobbled_deepslate
setblock 86 109 558 minecraft:calcite
fill 86 109 559 86 112 559 minecraft:cobbled_deepslate
fill 86 109 561 86 110 561 minecraft:cobbled_deepslate
setblock 86 109 577 minecraft:cobbled_deepslate
setblock 86 109 578 minecraft:calcite
fill 86 109 579 86 109 582 minecraft:cobbled_deepslate
setblock 86 109 583 minecraft:calcite
fill 86 109 584 86 109 587 minecraft:cobbled_deepslate
setblock 86 109 588 minecraft:calcite
fill 86 109 589 86 111 590 minecraft:cobbled_deepslate
setblock 86 109 593 minecraft:calcite
fill 86 109 594 86 110 594 minecraft:cobbled_deepslate
setblock 86 109 598 minecraft:calcite
fill 87 109 558 87 112 558 minecraft:cobbled_deepslate
setblock 87 109 562 minecraft:calcite
fill 87 109 563 87 111 564 minecraft:cobbled_deepslate
fill 87 109 574 87 109 576 minecraft:cobbled_deepslate
setblock 87 109 577 minecraft:calcite
fill 87 109 578 87 109 581 minecraft:cobbled_deepslate
setblock 87 109 582 minecraft:calcite
fill 87 109 583 87 112 583 minecraft:cobbled_deepslate
fill 87 109 585 87 109 586 minecraft:cobbled_deepslate
setblock 87 109 587 minecraft:calcite
fill 87 109 588 87 112 588 minecraft:cobbled_deepslate
setblock 87 109 592 minecraft:calcite
fill 87 109 593 87 112 593 minecraft:cobbled_deepslate
setblock 87 109 597 minecraft:calcite
fill 87 109 598 87 112 598 minecraft:cobbled_deepslate
setblock 88 109 561 minecraft:calcite
fill 88 109 562 88 112 562 minecraft:cobbled_deepslate
fill 88 109 564 88 109 565 minecraft:cobbled_deepslate
setblock 88 109 566 minecraft:calcite
fill 88 109 567 88 112 567 minecraft:cobbled_deepslate
setblock 88 109 571 minecraft:calcite
fill 88 109 572 88 111 572 minecraft:cobbled_deepslate
setblock 88 109 576 minecraft:calcite
fill 88 109 577 88 109 580 minecraft:cobbled_deepslate
setblock 88 109 581 minecraft:calcite
fill 88 109 582 88 112 582 minecraft:cobbled_deepslate
setblock 88 109 586 minecraft:calcite
fill 88 109 587 88 112 587 minecraft:cobbled_deepslate
setblock 88 109 591 minecraft:calcite
fill 88 109 592 88 112 592 minecraft:cobbled_deepslate
setblock 88 109 596 minecraft:calcite
fill 88 109 597 88 112 597 minecraft:cobbled_deepslate
setblock 48 110 560 minecraft:calcite
fill 48 110 561 48 113 561 minecraft:cobbled_deepslate
setblock 48 110 564 minecraft:cobbled_deepslate
setblock 48 110 565 minecraft:calcite
fill 48 110 566 48 113 566 minecraft:cobbled_deepslate
setblock 48 110 569 minecraft:cobbled_deepslate
setblock 48 110 570 minecraft:calcite
fill 48 110 571 48 113 571 minecraft:cobbled_deepslate
setblock 48 110 575 minecraft:calcite
fill 48 110 576 48 113 576 minecraft:cobbled_deepslate
setblock 48 110 580 minecraft:calcite
fill 48 110 581 48 113 581 minecraft:cobbled_deepslate
setblock 48 110 585 minecraft:calcite
fill 48 110 586 48 113 586 minecraft:cobbled_deepslate
setblock 48 110 590 minecraft:calcite
fill 48 110 591 48 113 591 minecraft:cobbled_deepslate
setblock 48 110 595 minecraft:calcite
fill 48 110 596 48 112 596 minecraft:cobbled_deepslate
setblock 49 110 559 minecraft:calcite
fill 49 110 560 49 113 560 minecraft:cobbled_deepslate
setblock 49 110 564 minecraft:calcite
fill 49 110 565 49 113 565 minecraft:cobbled_deepslate
setblock 49 110 569 minecraft:calcite
setblock 49 110 570 minecraft:cobbled_deepslate
setblock 49 110 574 minecraft:calcite
fill 49 110 575 49 113 575 minecraft:cobbled_deepslate
setblock 49 110 579 minecraft:calcite
fill 49 110 580 49 113 580 minecraft:cobbled_deepslate
setblock 49 110 584 minecraft:calcite
fill 49 110 585 49 113 585 minecraft:cobbled_deepslate
setblock 49 110 589 minecraft:calcite
setblock 49 110 590 minecraft:cobbled_deepslate
setblock 50 110 558 minecraft:calcite
fill 50 110 559 50 112 559 minecraft:cobbled_deepslate
setblock 50 110 574 minecraft:cobbled_deepslate
setblock 50 110 578 minecraft:calcite
fill 50 110 579 50 112 579 minecraft:cobbled_deepslate
setblock 50 110 583 minecraft:calcite
fill 50 110 584 50 113 584 minecraft:cobbled_deepslate
setblock 50 110 598 minecraft:calcite
fill 51 110 558 54 110 558 minecraft:cobbled_deepslate
setblock 51 110 578 minecraft:cobbled_deepslate
setblock 51 110 582 minecraft:calcite
setblock 51 110 583 minecraft:cobbled_deepslate
setblock 51 110 598 minecraft:cobbled_deepslate
setblock 55 110 558 minecraft:calcite
fill 56 110 558 59 110 558 minecraft:cobbled_deepslate
setblock 58 110 559 minecraft:cobbled_deepslate
setblock 59 110 559 minecraft:calcite
setblock 60 110 558 minecraft:calcite
fill 60 110 559 60 113 559 minecraft:cobbled_deepslate
fill 61 110 558 61 113 558 minecraft:cobbled_deepslate
setblock 63 110 559 minecraft:cobbled_deepslate
setblock 63 110 560 minecraft:calcite
fill 63 110 561 66 110 561 minecraft:cobbled_deepslate
setblock 64 110 559 minecraft:calcite
fill 64 110 560 67 110 560 minecraft:cobbled_deepslate
setblock 65 110 558 minecraft:calcite
fill 65 110 559 65 113 559 minecraft:cobbled_deepslate
setblock 65 110 598 minecraft:calcite
fill 66 110 558 66 113 558 minecraft:cobbled_deepslate
setblock 66 110 597 minecraft:calcite
fill 66 110 598 69 110 598 minecraft:cobbled_deepslate
setblock 67 110 561 minecraft:calcite
fill 67 110 597 67 112 597 minecraft:cobbled_deepslate
setblock 68 110 560 minecraft:calcite
fill 68 110 561 68 113 561 minecraft:cobbled_deepslate
setblock 69 110 559 minecraft:calcite
fill 69 110 560 69 113 560 minecraft:cobbled_deepslate
setblock 70 110 558 minecraft:calcite
fill 70 110 559 70 113 559 minecraft:cobbled_deepslate
setblock 70 110 598 minecraft:calcite
fill 71 110 558 71 113 558 minecraft:cobbled_deepslate
setblock 71 110 597 minecraft:calcite
fill 71 110 598 71 113 598 minecraft:cobbled_deepslate
setblock 72 110 561 minecraft:calcite
fill 72 110 597 72 111 597 minecraft:cobbled_deepslate
setblock 73 110 560 minecraft:calcite
setblock 74 110 559 minecraft:calcite
fill 74 110 560 74 111 560 minecraft:cobbled_deepslate
setblock 75 110 558 minecraft:calcite
fill 75 110 559 78 110 559 minecraft:cobbled_deepslate
setblock 75 110 598 minecraft:calcite
fill 76 110 558 76 113 558 minecraft:cobbled_deepslate
fill 76 110 598 76 112 598 minecraft:cobbled_deepslate
setblock 79 110 559 minecraft:calcite
setblock 80 110 558 minecraft:calcite
fill 80 110 559 80 112 559 minecraft:cobbled_deepslate
setblock 80 110 598 minecraft:calcite
fill 81 110 558 81 113 558 minecraft:cobbled_deepslate
setblock 81 110 597 minecraft:calcite
fill 81 110 598 81 113 598 minecraft:cobbled_deepslate
fill 82 110 597 82 112 597 minecraft:cobbled_deepslate
setblock 84 110 559 minecraft:calcite
setblock 84 110 560 minecraft:cobbled_deepslate
setblock 85 110 558 minecraft:calcite
fill 85 110 559 85 113 559 minecraft:cobbled_deepslate
setblock 85 110 582 minecraft:cobbled_deepslate
setblock 85 110 583 minecraft:calcite
fill 85 110 584 86 112 584 minecraft:cobbled_deepslate
setblock 85 110 598 minecraft:calcite
fill 86 110 558 86 113 558 minecraft:cobbled_deepslate
setblock 86 110 577 minecraft:calcite
fill 86 110 578 86 110 581 minecraft:cobbled_deepslate
setblock 86 110 582 minecraft:calcite
fill 86 110 583 86 113 583 minecraft:cobbled_deepslate
fill 86 110 585 86 110 586 minecraft:cobbled_deepslate
setblock 86 110 587 minecraft:calcite
fill 86 110 588 86 113 588 minecraft:cobbled_deepslate
setblock 86 110 597 minecraft:calcite
fill 86 110 598 86 113 598 minecraft:cobbled_deepslate
setblock 87 110 561 minecraft:calcite
fill 87 110 562 87 113 562 minecraft:cobbled_deepslate
setblock 87 110 575 minecraft:cobbled_deepslate
setblock 87 110 576 minecraft:calcite
fill 87 110 577 87 110 580 minecraft:cobbled_deepslate
setblock 87 110 581 minecraft:calcite
fill 87 110 582 87 113 582 minecraft:cobbled_deepslate
setblock 87 110 585 minecraft:cobbled_deepslate
setblock 87 110 586 minecraft:calcite
fill 87 110 587 87 113 587 minecraft:cobbled_deepslate
setblock 87 110 591 minecraft:calcite
fill 87 110 592 87 113 592 minecraft:cobbled_deepslate
setblock 87 110 596 minecraft:calcite
fill 87 110 597 87 113 597 minecraft:cobbled_deepslate
setblock 88 110 560 minecraft:calcite
fill 88 110 561 88 113 561 minecraft:cobbled_deepslate
setblock 88 110 564 minecraft:cobbled_deepslate
setblock 88 110 565 minecraft:calcite
fill 88 110 566 88 113 566 minecraft:cobbled_deepslate
setblock 88 110 570 minecraft:calcite
fill 88 110 571 88 111 571 minecraft:cobbled_deepslate
setblock 88 110 575 minecraft:calcite
fill 88 110 576 88 110 579 minecraft:cobbled_deepslate
setblock 88 110 580 minecraft:calcite
fill 88 110 581 88 113 581 minecraft:cobbled_deepslate
setblock 88 110 585 minecraft:calcite
fill 88 110 586 88 113 586 minecraft:cobbled_deepslate
setblock 88 110 590 minecraft:calcite
fill 88 110 591 88 113 591 minecraft:cobbled_deepslate
setblock 88 110 595 minecraft:calcite
fill 88 110 596 88 113 596 minecraft:cobbled_deepslate
setblock 48 111 558 minecraft:cobbled_deepslate
setblock 48 111 559 minecraft:calcite
fill 48 111 560 48 114 560 minecraft:cobbled_deepslate
setblock 48 111 564 minecraft:calcite
fill 48 111 565 48 114 565 minecraft:cobbled_deepslate
setblock 48 111 569 minecraft:calcite
fill 48 111 570 48 114 570 minecraft:cobbled_deepslate
setblock 48 111 574 minecraft:calcite
fill 48 111 575 48 114 575 minecraft:cobbled_deepslate
setblock 48 111 579 minecraft:calcite
fill 48 111 580 48 114 580 minecraft:cobbled_deepslate
setblock 48 111 584 minecraft:calcite
fill 48 111 585 48 114 585 minecraft:cobbled_deepslate
setblock 48 111 589 minecraft:calcite
fill 48 111 590 48 114 590 minecraft:cobbled_deepslate
setblock 48 111 594 minecraft:calcite
setblock 48 111 595 minecraft:cobbled_deepslate
setblock 49 111 558 minecraft:calcite
fill 49 111 559 49 112 559 minecraft:cobbled_deepslate
setblock 49 111 563 minecraft:calcite
fill 49 111 564 49 114 564 minecraft:cobbled_deepslate
setblock 49 111 568 minecraft:calcite
setblock 49 111 573 minecraft:calcite
fill 49 111 574 49 112 574 minecraft:cobbled_deepslate
setblock 49 111 578 minecraft:calcite
fill 49 111 579 49 114 579 minecraft:cobbled_deepslate
setblock 49 111 583 minecraft:calcite
fill 49 111 584 49 114 584 minecraft:cobbled_deepslate
setblock 49 111 588 minecraft:calcite
fill 49 111 589 49 112 589 minecraft:cobbled_deepslate
setblock 49 111 598 minecraft:calcite
fill 50 111 558 53 111 558 minecraft:cobbled_deepslate
setblock 50 111 577 minecraft:calcite
fill 50 111 578 50 112 578 minecraft:cobbled_deepslate
setblock 50 111 582 minecraft:calcite
fill 50 111 583 50 113 583 minecraft:cobbled_deepslate
setblock 50 111 598 minecraft:cobbled_deepslate
setblock 51 111 581 minecraft:calcite
setblock 54 111 558 minecraft:calcite
fill 55 111 558 58 111 558 minecraft:cobbled_deepslate
setblock 59 111 558 minecraft:calcite
fill 59 111 559 59 113 559 minecraft:cobbled_deepslate
fill 60 111 558 60 114 558 minecraft:cobbled_deepslate
setblock 62 111 559 minecraft:cobbled_deepslate
setblock 62 111 560 minecraft:calcite
setblock 63 111 559 minecraft:calcite
fill 63 111 560 65 111 561 minecraft:cobbled_deepslate
setblock 64 111 558 minecraft:calcite
fill 64 111 559 64 114 559 minecraft:cobbled_deepslate
setblock 64 111 598 minecraft:calcite
fill 65 111 558 65 114 558 minecraft:cobbled_deepslate
setblock 65 111 597 minecraft:calcite
fill 65 111 598 68 111 598 minecraft:cobbled_deepslate
setblock 66 111 560 minecraft:cobbled_deepslate
setblock 66 111 561 minecraft:calcite
setblock 66 111 597 minecraft:cobbled_deepslate
setblock 67 111 560 minecraft:calcite
fill 67 111 561 67 114 561 minecraft:cobbled_deepslate
setblock 68 111 559 minecraft:calcite
fill 68 111 560 68 114 560 minecraft:cobbled_deepslate
setblock 69 111 558 minecraft:calcite
fill 69 111 559 69 114 559 minecraft:cobbled_deepslate
setblock 69 111 598 minecraft:calcite
fill 70 111 558 70 114 558 minecraft:cobbled_deepslate
setblock 70 111 597 minecraft:calcite
fill 70 111 598 70 114 598 minecraft:cobbled_deepslate
setblock 71 111 561 minecraft:calcite
setblock 71 111 597 minecraft:cobbled_deepslate
setblock 72 111 560 minecraft:calcite
setblock 73 111 559 minecraft:calcite
setblock 73 111 560 minecraft:cobbled_deepslate
setblock 74 111 558 minecraft:calcite
fill 74 111 559 77 111 559 minecraft:cobbled_deepslate
setblock 74 111 598 minecraft:calcite
fill 75 111 558 75 114 558 minecraft:cobbled_deepslate
fill 75 111 598 75 112 598 minecraft:cobbled_deepslate
setblock 78 111 559 minecraft:calcite
setblock 79 111 558 minecraft:calcite
setblock 79 111 559 minecraft:cobbled_deepslate
setblock 79 111 598 minecraft:calcite
fill 80 111 558 80 114 558 minecraft:cobbled_deepslate
fill 80 111 598 80 114 598 minecraft:cobbled_deepslate
setblock 81 111 597 minecraft:cobbled_deepslate
setblock 83 111 559 minecraft:calcite
setblock 84 111 558 minecraft:calcite
fill 84 111 559 84 114 559 minecraft:cobbled_deepslate
setblock 84 111 598 minecraft:calcite
fill 85 111 558 85 114 558 minecraft:cobbled_deepslate
setblock 85 111 582 minecraft:calcite
fill 85 111 583 85 114 583 minecraft:cobbled_deepslate
fill 85 111 585 86 111 585 minecraft:cobbled_deepslate
setblock 85 111 597 minecraft:calcite
fill 85 111 598 85 114 598 minecraft:cobbled_deepslate
setblock 86 111 561 minecraft:calcite
fill 86 111 578 86 111 580 minecraft:cobbled_deepslate
setblock 86 111 581 minecraft:calcite
fill 86 111 582 86 114 582 minecraft:cobbled_deepslate
setblock 86 111 586 minecraft:calcite
fill 86 111 587 86 114 587 minecraft:cobbled_deepslate
setblock 86 111 596 minecraft:calcite
fill 86 111 597 86 113 597 minecraft:cobbled_deepslate
setblock 87 111 560 minecraft:calcite
fill 87 111 561 87 114 561 minecraft:cobbled_deepslate
setblock 87 111 575 minecraft:calcite
fill 87 111 576 87 111 579 minecraft:cobbled_deepslate
setblock 87 111 580 minecraft:calcite
fill 87 111 581 87 114 581 minecraft:cobbled_deepslate
setblock 87 111 585 minecraft:calcite
fill 87 111 586 87 114 586 minecraft:cobbled_deepslate
setblock 87 111 590 minecraft:calcite
fill 87 111 591 87 114 591 minecraft:cobbled_deepslate
setblock 87 111 595 minecraft:calcite
fill 87 111 596 87 112 596 minecraft:cobbled_deepslate
setblock 88 111 559 minecraft:calcite
fill 88 111 560 88 114 560 minecraft:cobbled_deepslate
setblock 88 111 564 minecraft:calcite
fill 88 111 565 88 114 565 minecraft:cobbled_deepslate
setblock 88 111 568 minecraft:cobbled_deepslate
setblock 88 111 569 minecraft:calcite
setblock 88 111 574 minecraft:calcite
fill 88 111 575 88 111 578 minecraft:cobbled_deepslate
setblock 88 111 579 minecraft:calcite
fill 88 111 580 88 114 580 minecraft:cobbled_deepslate
setblock 88 111 584 minecraft:calcite
fill 88 111 585 88 114 585 minecraft:cobbled_deepslate
setblock 88 111 589 minecraft:calcite
fill 88 111 590 88 114 590 minecraft:cobbled_deepslate
setblock 88 111 594 minecraft:calcite
fill 88 111 595 88 114 595 minecraft:cobbled_deepslate
setblock 48 112 558 minecraft:calcite
fill 48 112 559 48 115 559 minecraft:cobbled_deepslate
setblock 48 112 563 minecraft:calcite
fill 48 112 564 48 115 564 minecraft:cobbled_deepslate
setblock 48 112 567 minecraft:cobbled_deepslate
setblock 48 112 568 minecraft:calcite
fill 48 112 569 48 115 569 minecraft:cobbled_deepslate
setblock 48 112 573 minecraft:calcite
fill 48 112 574 48 115 574 minecraft:cobbled_deepslate
setblock 48 112 578 minecraft:calcite
fill 48 112 579 48 115 579 minecraft:cobbled_deepslate
setblock 48 112 583 minecraft:calcite
fill 48 112 584 48 115 584 minecraft:cobbled_deepslate
setblock 48 112 588 minecraft:calcite
fill 48 112 589 48 115 589 minecraft:cobbled_deepslate
setblock 48 112 593 minecraft:calcite
setblock 48 112 594 minecraft:cobbled_deepslate
setblock 48 112 598 minecraft:calcite
fill 49 112 558 52 112 558 minecraft:cobbled_deepslate
setblock 49 112 562 minecraft:calcite
fill 49 112 563 49 115 563 minecraft:cobbled_deepslate
setblock 49 112 567 minecraft:calcite
setblock 49 112 573 minecraft:cobbled_deepslate
setblock 49 112 577 minecraft:calcite
fill 49 112 578 49 114 578 minecraft:cobbled_deepslate
setblock 49 112 582 minecraft:calcite
fill 49 112 583 49 115 583 minecraft:cobbled_deepslate
setblock 49 112 587 minecraft:calcite
fill 49 112 588 49 114 588 minecraft:cobbled_deepslate
setblock 49 112 598 minecraft:cobbled_deepslate
setblock 50 112 560 minecraft:light[level=14]
setblock 50 112 568 minecraft:light[level=14]
setblock 50 112 576 minecraft:light[level=14]
setblock 50 112 581 minecraft:calcite
fill 50 112 582 50 113 582 minecraft:cobbled_deepslate
setblock 50 112 592 minecraft:light[level=14]
setblock 53 112 558 minecraft:calcite
setblock 57 112 558 minecraft:cobbled_deepslate
setblock 58 112 558 minecraft:calcite
setblock 58 112 560 minecraft:light[level=14]
setblock 58 112 568 minecraft:light[level=14]
setblock 58 112 576 minecraft:light[level=14]
setblock 58 112 584 minecraft:light[level=14]
setblock 58 112 592 minecraft:light[level=14]
fill 59 112 558 59 115 558 minecraft:cobbled_deepslate
setblock 61 112 559 minecraft:cobbled_deepslate
setblock 61 112 560 minecraft:calcite
setblock 62 112 559 minecraft:calcite
fill 62 112 560 65 112 560 minecraft:cobbled_deepslate
setblock 63 112 558 minecraft:calcite
fill 63 112 559 63 115 559 minecraft:cobbled_deepslate
fill 63 112 561 64 112 561 minecraft:cobbled_deepslate
setblock 63 112 598 minecraft:calcite
fill 64 112 558 64 115 558 minecraft:cobbled_deepslate
fill 64 112 598 67 112 598 minecraft:cobbled_deepslate
setblock 65 112 561 minecraft:calcite
setblock 66 112 560 minecraft:calcite
fill 66 112 561 66 115 561 minecraft:cobbled_deepslate
setblock 66 112 576 minecraft:light[level=14]
setblock 66 112 584 minecraft:light[level=14]
setblock 66 112 592 minecraft:light[level=14]
setblock 67 112 559 minecraft:calcite
fill 67 112 560 67 115 560 minecraft:cobbled_deepslate
setblock 68 112 558 minecraft:calcite
fill 68 112 559 68 115 559 minecraft:cobbled_deepslate
setblock 68 112 598 minecraft:calcite
fill 69 112 558 69 115 558 minecraft:cobbled_deepslate
setblock 69 112 597 minecraft:calcite
fill 69 112 598 69 115 598 minecraft:cobbled_deepslate
setblock 70 112 561 minecraft:calcite
setblock 71 112 560 minecraft:calcite
setblock 72 112 559 minecraft:calcite
setblock 72 112 560 minecraft:cobbled_deepslate
setblock 73 112 558 minecraft:calcite
fill 73 112 559 76 112 559 minecraft:cobbled_deepslate
setblock 73 112 598 minecraft:calcite
fill 74 112 558 74 114 558 minecraft:cobbled_deepslate
setblock 74 112 560 minecraft:light[level=14]
setblock 74 112 568 minecraft:light[level=14]
setblock 74 112 576 minecraft:light[level=14]
setblock 74 112 584 minecraft:light[level=14]
setblock 74 112 592 minecraft:light[level=14]
setblock 74 112 598 minecraft:cobbled_deepslate
setblock 78 112 558 minecraft:calcite
setblock 78 112 598 minecraft:calcite
fill 79 112 558 79 114 558 minecraft:cobbled_deepslate
fill 79 112 598 79 114 598 minecraft:cobbled_deepslate
setblock 82 112 559 minecraft:calcite
setblock 82 112 560 minecraft:light[level=14]
setblock 82 112 568 minecraft:light[level=14]
setblock 82 112 576 minecraft:light[level=14]
setblock 82 112 584 minecraft:light[level=14]
setblock 82 112 592 minecraft:light[level=14]
setblock 83 112 558 minecraft:calcite
fill 83 112 559 83 114 559 minecraft:cobbled_deepslate
setblock 83 112 598 minecraft:calcite
fill 84 112 558 84 115 558 minecraft:cobbled_deepslate
setblock 84 112 597 minecraft:calcite
fill 84 112 598 84 115 598 minecraft:cobbled_deepslate
setblock 85 112 582 minecraft:cobbled_deepslate
setblock 85 112 585 minecraft:cobbled_deepslate
setblock 85 112 586 minecraft:calcite
fill 85 112 597 85 113 597 minecraft:cobbled_deepslate
setblock 86 112 579 minecraft:cobbled_deepslate
setblock 86 112 580 minecraft:calcite
fill 86 112 581 86 115 581 minecraft:cobbled_deepslate
setblock 86 112 585 minecraft:calcite
fill 86 112 586 86 115 586 minecraft:cobbled_deepslate
setblock 86 112 589 minecraft:cobbled_deepslate
setblock 86 112 590 minecraft:calcite
setblock 87 112 559 minecraft:calcite
fill 87 112 560 87 113 560 minecraft:cobbled_deepslate
setblock 87 112 563 minecraft:cobbled_deepslate
setblock 87 112 564 minecraft:calcite
fill 87 112 576 87 112 578 minecraft:cobbled_deepslate
setblock 87 112 579 minecraft:calcite
fill 87 112 580 87 115 580 minecraft:cobbled_deepslate
setblock 87 112 584 minecraft:calcite
fill 87 112 585 87 115 585 minecraft:cobbled_deepslate
setblock 87 112 589 minecraft:calcite
fill 87 112 590 87 115 590 minecraft:cobbled_deepslate
setblock 87 112 594 minecraft:calcite
setblock 87 112 595 minecraft:cobbled_deepslate
setblock 88 112 558 minecraft:calcite
fill 88 112 559 88 115 559 minecraft:cobbled_deepslate
setblock 88 112 563 minecraft:calcite
fill 88 112 564 88 115 564 minecraft:cobbled_deepslate
setblock 88 112 568 minecraft:calcite
setblock 88 112 573 minecraft:calcite
fill 88 112 574 88 112 577 minecraft:cobbled_deepslate
setblock 88 112 578 minecraft:calcite
fill 88 112 579 88 115 579 minecraft:cobbled_deepslate
setblock 88 112 583 minecraft:calcite
fill 88 112 584 88 115 584 minecraft:cobbled_deepslate
setblock 88 112 588 minecraft:calcite
fill 88 112 589 88 115 589 minecraft:cobbled_deepslate
setblock 88 112 593 minecraft:calcite
fill 88 112 594 88 115 594 minecraft:cobbled_deepslate
setblock 88 112 598 minecraft:calcite
fill 48 113 558 50 113 558 minecraft:cobbled_deepslate
setblock 48 113 562 minecraft:calcite
fill 48 113 563 48 116 563 minecraft:cobbled_deepslate
setblock 48 113 567 minecraft:calcite
fill 48 113 568 48 116 568 minecraft:cobbled_deepslate
setblock 48 113 572 minecraft:calcite
fill 48 113 573 48 116 573 minecraft:cobbled_deepslate
setblock 48 113 577 minecraft:calcite
fill 48 113 578 48 116 578 minecraft:cobbled_deepslate
setblock 48 113 582 minecraft:calcite
fill 48 113 583 48 116 583 minecraft:cobbled_deepslate
setblock 48 113 587 minecraft:calcite
fill 48 113 588 48 116 588 minecraft:cobbled_deepslate
setblock 48 113 592 minecraft:calcite
setblock 49 113 561 minecraft:calcite
fill 49 113 562 49 114 562 minecraft:cobbled_deepslate
setblock 49 113 566 minecraft:calcite
fill 49 113 567 49 116 567 minecraft:cobbled_deepslate
setblock 49 113 576 minecraft:calcite
fill 49 113 577 49 114 577 minecraft:cobbled_deepslate
setblock 49 113 581 minecraft:calcite
fill 49 113 582 49 116 582 minecraft:cobbled_deepslate
setblock 49 113 586 minecraft:calcite
fill 49 113 587 49 116 587 minecraft:cobbled_deepslate
setblock 50 113 580 minecraft:calcite
setblock 50 113 581 minecraft:cobbled_deepslate
fill 58 113 558 58 116 558 minecraft:cobbled_deepslate
setblock 61 113 559 minecraft:calcite
fill 61 113 560 64 113 560 minecraft:cobbled_deepslate
setblock 62 113 558 minecraft:calcite
fill 62 113 559 62 116 559 minecraft:cobbled_deepslate
fill 63 113 558 63 116 558 minecraft:cobbled_deepslate
setblock 63 113 561 minecraft:cobbled_deepslate
fill 63 113 598 66 113 598 minecraft:cobbled_deepslate
setblock 64 113 561 minecraft:calcite
setblock 65 113 560 minecraft:calcite
fill 65 113 561 65 115 561 minecraft:cobbled_deepslate
setblock 66 113 559 minecraft:calcite
fill 66 113 560 66 116 560 minecraft:cobbled_deepslate
setblock 67 113 558 minecraft:calcite
fill 67 113 559 67 116 559 minecraft:cobbled_deepslate
setblock 67 113 598 minecraft:calcite
fill 68 113 558 68 116 558 minecraft:cobbled_deepslate
fill 68 113 598 68 116 598 minecraft:cobbled_deepslate
setblock 70 113 560 minecraft:calcite
setblock 71 113 559 minecraft:calcite
setblock 71 113 560 minecraft:cobbled_deepslate
setblock 72 113 558 minecraft:calcite
fill 72 113 559 73 113 559 minecraft:cobbled_deepslate
setblock 72 113 598 minecraft:calcite
fill 73 113 558 73 115 558 minecraft:cobbled_deepslate
setblock 73 113 598 minecraft:cobbled_deepslate
setblock 77 113 558 minecraft:calcite
fill 78 113 558 78 114 558 minecraft:cobbled_deepslate
setblock 78 113 598 minecraft:cobbled_deepslate
setblock 82 113 558 minecraft:calcite
setblock 82 113 559 minecraft:cobbled_deepslate
setblock 82 113 598 minecraft:calcite
fill 83 113 558 83 116 558 minecraft:cobbled_deepslate
setblock 83 113 597 minecraft:calcite
fill 83 113 598 83 116 598 minecraft:cobbled_deepslate
setblock 84 113 597 minecraft:cobbled_deepslate
setblock 85 113 584 minecraft:cobbled_deepslate
setblock 85 113 585 minecraft:calcite
fill 85 113 586 85 116 586 minecraft:cobbled_deepslate
setblock 86 113 559 minecraft:calcite
setblock 86 113 579 minecraft:calcite
fill 86 113 580 86 114 580 minecraft:cobbled_deepslate
setblock 86 113 584 minecraft:calcite
fill 86 113 585 86 116 585 minecraft:cobbled_deepslate
setblock 86 113 589 minecraft:calcite
fill 86 113 590 86 116 590 minecraft:cobbled_deepslate
setblock 87 113 558 minecraft:calcite
setblock 87 113 559 minecraft:cobbled_deepslate
setblock 87 113 563 minecraft:calcite
fill 87 113 564 87 114 564 minecraft:cobbled_deepslate
setblock 87 113 577 minecraft:cobbled_deepslate
setblock 87 113 578 minecraft:calcite
fill 87 113 579 87 116 579 minecraft:cobbled_deepslate
setblock 87 113 583 minecraft:calcite
fill 87 113 584 87 116 584 minecraft:cobbled_deepslate
setblock 87 113 588 minecraft:calcite
fill 87 113 589 87 116 589 minecraft:cobbled_deepslate
setblock 87 113 593 minecraft:calcite
setblock 87 113 594 minecraft:cobbled_deepslate
setblock 87 113 598 minecraft:calcite
fill 88 113 558 88 114 558 minecraft:cobbled_deepslate
setblock 88 113 562 minecraft:calcite
fill 88 113 563 88 116 563 minecraft:cobbled_deepslate
setblock 88 113 567 minecraft:calcite
fill 88 113 568 88 116 568 minecraft:cobbled_deepslate
fill 88 113 574 88 113 576 minecraft:cobbled_deepslate
setblock 88 113 577 minecraft:calcite
fill 88 113 578 88 116 578 minecraft:cobbled_deepslate
setblock 88 113 582 minecraft:calcite
fill 88 113 583 88 116 583 minecraft:cobbled_deepslate
setblock 88 113 587 minecraft:calcite
fill 88 113 588 88 116 588 minecraft:cobbled_deepslate
setblock 88 113 592 minecraft:calcite
fill 88 113 593 88 116 593 minecraft:cobbled_deepslate
setblock 88 113 597 minecraft:calcite
fill 88 113 598 88 114 598 minecraft:cobbled_deepslate
setblock 48 114 558 minecraft:cobbled_deepslate
setblock 48 114 561 minecraft:calcite
fill 48 114 562 48 117 562 minecraft:cobbled_deepslate
setblock 48 114 566 minecraft:calcite
fill 48 114 567 48 117 567 minecraft:cobbled_deepslate
setblock 48 114 571 minecraft:calcite
fill 48 114 572 48 117 572 minecraft:cobbled_deepslate
setblock 48 114 576 minecraft:calcite
fill 48 114 577 48 117 577 minecraft:cobbled_deepslate
setblock 48 114 581 minecraft:calcite
fill 48 114 582 48 117 582 minecraft:cobbled_deepslate
setblock 48 114 586 minecraft:calcite
fill 48 114 587 48 117 587 minecraft:cobbled_deepslate
setblock 48 114 591 minecraft:calcite
setblock 49 114 565 minecraft:calcite
fill 49 114 566 49 117 566 minecraft:cobbled_deepslate
setblock 49 114 580 minecraft:calcite
fill 49 114 581 49 116 581 minecraft:cobbled_deepslate
setblock 49 114 585 minecraft:calcite
fill 49 114 586 49 117 586 minecraft:cobbled_deepslate
setblock 60 114 559 minecraft:calcite
setblock 61 114 558 minecraft:calcite
fill 61 114 559 61 116 560 minecraft:cobbled_deepslate
fill 62 114 558 62 117 558 minecraft:cobbled_deepslate
fill 62 114 560 63 114 560 minecraft:cobbled_deepslate
setblock 63 114 561 minecraft:calcite
fill 63 114 598 65 114 598 minecraft:cobbled_deepslate
setblock 64 114 560 minecraft:calcite
fill 64 114 561 64 116 561 minecraft:cobbled_deepslate
setblock 65 114 559 minecraft:calcite
fill 65 114 560 65 117 560 minecraft:cobbled_deepslate
setblock 66 114 558 minecraft:calcite
fill 66 114 559 66 117 559 minecraft:cobbled_deepslate
setblock 66 114 598 minecraft:calcite
fill 67 114 558 67 117 558 minecraft:cobbled_deepslate
fill 67 114 598 67 117 598 minecraft:cobbled_deepslate
setblock 69 114 560 minecraft:calcite
setblock 70 114 559 minecraft:calcite
setblock 70 114 560 minecraft:cobbled_deepslate
setblock 71 114 558 minecraft:calcite
fill 71 114 559 72 114 559 minecraft:cobbled_deepslate
setblock 71 114 598 minecraft:calcite
fill 72 114 558 72 115 558 minecraft:cobbled_deepslate
setblock 81 114 558 minecraft:calcite
setblock 81 114 598 minecraft:calcite
fill 82 114 558 82 117 558 minecraft:cobbled_deepslate
fill 82 114 598 82 117 598 minecraft:cobbled_deepslate
setblock 85 114 559 minecraft:calcite
setblock 85 114 584 minecraft:calcite
fill 85 114 585 85 117 585 minecraft:cobbled_deepslate
setblock 86 114 558 minecraft:calcite
setblock 86 114 559 minecraft:cobbled_deepslate
setblock 86 114 583 minecraft:calcite
fill 86 114 584 86 117 584 minecraft:cobbled_deepslate
setblock 86 114 588 minecraft:calcite
fill 86 114 589 86 117 589 minecraft:cobbled_deepslate
setblock 86 114 598 minecraft:calcite
fill 87 114 558 87 115 558 minecraft:cobbled_deepslate
setblock 87 114 562 minecraft:calcite
setblock 87 114 563 minecraft:cobbled_deepslate
setblock 87 114 578 minecraft:cobbled_deepslate
setblock 87 114 582 minecraft:calcite
fill 87 114 583 87 117 583 minecraft:cobbled_deepslate
setblock 87 114 587 minecraft:calcite
fill 87 114 588 87 117 588 minecraft:cobbled_deepslate
setblock 87 114 592 minecraft:calcite
fill 87 114 598 87 115 598 minecraft:cobbled_deepslate
setblock 88 114 561 minecraft:calcite
fill 88 114 562 88 117 562 minecraft:cobbled_deepslate
setblock 88 114 566 minecraft:calcite
fill 88 114 567 88 117 567 minecraft:cobbled_deepslate
setblock 88 114 575 minecraft:cobbled_deepslate
setblock 88 114 576 minecraft:calcite
fill 88 114 577 88 117 577 minecraft:cobbled_deepslate
setblock 88 114 581 minecraft:calcite
fill 88 114 582 88 117 582 minecraft:cobbled_deepslate
setblock 88 114 586 minecraft:calcite
fill 88 114 587 88 117 587 minecraft:cobbled_deepslate
setblock 88 114 591 minecraft:calcite
fill 88 114 592 88 117 592 minecraft:cobbled_deepslate
setblock 88 114 596 minecraft:calcite
setblock 88 114 597 minecraft:cobbled_deepslate
setblock 48 115 560 minecraft:calcite
fill 48 115 561 48 118 561 minecraft:cobbled_deepslate
setblock 48 115 565 minecraft:calcite
fill 48 115 566 48 118 566 minecraft:cobbled_deepslate
setblock 48 115 570 minecraft:calcite
fill 48 115 571 48 118 571 minecraft:cobbled_deepslate
setblock 48 115 575 minecraft:calcite
fill 48 115 576 48 118 576 minecraft:cobbled_deepslate
setblock 48 115 580 minecraft:calcite
fill 48 115 581 48 118 581 minecraft:cobbled_deepslate
setblock 48 115 585 minecraft:calcite
fill 48 115 586 48 118 586 minecraft:cobbled_deepslate
setblock 48 115 590 minecraft:calcite
fill 48 115 591 48 118 591 minecraft:cobbled_deepslate
setblock 49 115 564 minecraft:calcite
fill 49 115 565 49 118 565 minecraft:cobbled_deepslate
setblock 49 115 579 minecraft:calcite
setblock 49 115 580 minecraft:cobbled_deepslate
setblock 49 115 584 minecraft:calcite
fill 49 115 585 49 118 585 minecraft:cobbled_deepslate
setblock 60 115 558 minecraft:calcite
fill 60 115 559 60 118 559 minecraft:cobbled_deepslate
fill 61 115 558 61 118 558 minecraft:cobbled_deepslate
setblock 62 115 560 minecraft:cobbled_deepslate
setblock 63 115 560 minecraft:calcite
setblock 63 115 561 minecraft:cobbled_deepslate
fill 63 115 598 64 115 598 minecraft:cobbled_deepslate
setblock 64 115 559 minecraft:calcite
fill 64 115 560 64 118 560 minecraft:cobbled_deepslate
setblock 65 115 558 minecraft:calcite
fill 65 115 559 65 118 559 minecraft:cobbled_deepslate
setblock 65 115 598 minecraft:calcite
fill 66 115 558 66 118 558 minecraft:cobbled_deepslate
fill 66 115 598 66 118 598 minecraft:cobbled_deepslate
setblock 68 115 560 minecraft:calcite
setblock 69 115 559 minecraft:calcite
setblock 70 115 558 minecraft:calcite
setblock 70 115 559 minecraft:cobbled_deepslate
fill 71 115 558 71 116 558 minecraft:cobbled_deepslate
setblock 80 115 558 minecraft:calcite
setblock 80 115 598 minecraft:calcite
fill 81 115 558 81 118 558 minecraft:cobbled_deepslate
fill 81 115 598 81 118 598 minecraft:cobbled_deepslate
setblock 85 115 558 minecraft:calcite
fill 85 115 584 85 118 584 minecraft:cobbled_deepslate
setblock 85 115 587 minecraft:cobbled_deepslate
setblock 85 115 598 minecraft:calcite
fill 86 115 558 86 116 558 minecraft:cobbled_deepslate
setblock 86 115 582 minecraft:calcite
fill 86 115 583 86 118 583 minecraft:cobbled_deepslate
setblock 86 115 587 minecraft:calcite
fill 86 115 588 86 118 588 minecraft:cobbled_deepslate
fill 86 115 598 86 117 598 minecraft:cobbled_deepslate
setblock 87 115 581 minecraft:calcite
fill 87 115 582 87 118 582 minecraft:cobbled_deepslate
setblock 87 115 586 minecraft:calcite
fill 87 115 587 87 118 587 minecraft:cobbled_deepslate
setblock 87 115 591 minecraft:calcite
fill 87 115 592 87 118 592 minecraft:cobbled_deepslate
setblock 88 115 560 minecraft:calcite
fill 88 115 561 88 116 561 minecraft:cobbled_deepslate
setblock 88 115 565 minecraft:calcite
fill 88 115 566 88 118 566 minecraft:cobbled_deepslate
setblock 88 115 576 minecraft:cobbled_deepslate
setblock 88 115 580 minecraft:calcite
fill 88 115 581 88 118 581 minecraft:cobbled_deepslate
setblock 88 115 585 minecraft:calcite
fill 88 115 586 88 118 586 minecraft:cobbled_deepslate
setblock 88 115 590 minecraft:calcite
fill 88 115 591 88 118 591 minecraft:cobbled_deepslate
fill 48 116 560 48 117 560 minecraft:cobbled_deepslate
setblock 48 116 564 minecraft:calcite
fill 48 116 565 48 119 565 minecraft:cobbled_deepslate
setblock 48 116 569 minecraft:calcite
fill 48 116 570 48 119 570 minecraft:cobbled_deepslate
setblock 48 116 574 minecraft:calcite
fill 48 116 575 48 119 575 minecraft:cobbled_deepslate
setblock 48 116 579 minecraft:calcite
fill 48 116 580 48 119 580 minecraft:cobbled_deepslate
setblock 48 116 584 minecraft:calcite
fill 48 116 585 48 119 585 minecraft:cobbled_deepslate
setblock 48 116 589 minecraft:calcite
fill 48 116 590 48 119 590 minecraft:cobbled_deepslate
setblock 49 116 563 minecraft:calcite
fill 49 116 564 49 119 564 minecraft:cobbled_deepslate
setblock 49 116 568 minecraft:calcite
setblock 49 116 583 minecraft:calcite
fill 49 116 584 49 118 584 minecraft:cobbled_deepslate
setblock 59 116 558 minecraft:calcite
fill 60 116 558 60 119 558 minecraft:cobbled_deepslate
setblock 62 116 560 minecraft:calcite
setblock 63 116 559 minecraft:calcite
fill 63 116 560 63 119 560 minecraft:cobbled_deepslate
setblock 63 116 598 minecraft:cobbled_deepslate
setblock 64 116 558 minecraft:calcite
fill 64 116 559 64 119 559 minecraft:cobbled_deepslate
setblock 64 116 598 minecraft:calcite
fill 65 116 558 65 119 558 minecraft:cobbled_deepslate
fill 65 116 598 65 119 598 minecraft:cobbled_deepslate
setblock 67 116 560 minecraft:calcite
setblock 68 116 559 minecraft:calcite
setblock 69 116 558 minecraft:calcite
setblock 69 116 559 minecraft:cobbled_deepslate
fill 70 116 558 70 118 558 minecraft:cobbled_deepslate
setblock 80 116 558 minecraft:cobbled_deepslate
fill 80 116 598 80 119 598 minecraft:cobbled_deepslate
setblock 84 116 558 minecraft:calcite
setblock 84 116 598 minecraft:calcite
setblock 85 116 558 minecraft:cobbled_deepslate
setblock 85 116 587 minecraft:calcite
fill 85 116 588 85 119 588 minecraft:cobbled_deepslate
fill 85 116 598 85 119 598 minecraft:cobbled_deepslate
setblock 86 116 581 minecraft:calcite
fill 86 116 582 86 119 582 minecraft:cobbled_deepslate
setblock 86 116 586 minecraft:calcite
fill 86 116 587 86 119 587 minecraft:cobbled_deepslate
setblock 87 116 580 minecraft:calcite
fill 87 116 581 87 119 581 minecraft:cobbled_deepslate
setblock 87 116 585 minecraft:calcite
fill 87 116 586 87 119 586 minecraft:cobbled_deepslate
setblock 87 116 590 minecraft:calcite
fill 87 116 591 87 119 591 minecraft:cobbled_deepslate
setblock 88 116 564 minecraft:calcite
fill 88 116 565 88 119 565 minecraft:cobbled_deepslate
setblock 88 116 569 minecraft:calcite
setblock 88 116 579 minecraft:calcite
fill 88 116 580 88 119 580 minecraft:cobbled_deepslate
setblock 88 116 584 minecraft:calcite
fill 88 116 585 88 119 585 minecraft:cobbled_deepslate
setblock 88 116 589 minecraft:calcite
fill 88 116 590 88 119 590 minecraft:cobbled_deepslate
setblock 88 116 594 minecraft:calcite
setblock 48 117 563 minecraft:calcite
fill 48 117 564 48 120 564 minecraft:cobbled_deepslate
setblock 48 117 568 minecraft:calcite
fill 48 117 569 49 119 569 minecraft:cobbled_deepslate
setblock 48 117 573 minecraft:calcite
fill 48 117 574 48 120 574 minecraft:cobbled_deepslate
setblock 48 117 578 minecraft:calcite
fill 48 117 579 48 120 579 minecraft:cobbled_deepslate
setblock 48 117 583 minecraft:calcite
fill 48 117 584 48 120 584 minecraft:cobbled_deepslate
setblock 48 117 588 minecraft:calcite
fill 48 117 589 48 120 589 minecraft:cobbled_deepslate
setblock 49 117 567 minecraft:calcite
fill 49 117 568 49 120 568 minecraft:cobbled_deepslate
setblock 49 117 582 minecraft:calcite
setblock 49 117 583 minecraft:cobbled_deepslate
setblock 49 117 587 minecraft:calcite
setblock 58 117 558 minecraft:calcite
fill 59 117 558 59 119 559 minecraft:cobbled_deepslate
setblock 61 117 559 minecraft:cobbled_deepslate
setblock 61 117 560 minecraft:calcite
setblock 62 117 559 minecraft:calcite
fill 62 117 560 62 120 560 minecraft:cobbled_deepslate
setblock 62 117 598 minecraft:cobbled_deepslate
setblock 63 117 558 minecraft:calcite
fill 63 117 559 63 120 559 minecraft:cobbled_deepslate
setblock 63 117 598 minecraft:calcite
fill 64 117 558 64 120 558 minecraft:cobbled_deepslate
fill 64 117 598 64 120 598 minecraft:cobbled_deepslate
setblock 66 117 560 minecraft:calcite
setblock 67 117 559 minecraft:calcite
setblock 68 117 558 minecraft:calcite
fill 68 117 559 68 118 559 minecraft:cobbled_deepslate
setblock 68 117 598 minecraft:calcite
fill 69 117 558 69 120 558 minecraft:cobbled_deepslate
fill 79 117 598 79 120 598 minecraft:cobbled_deepslate
setblock 83 117 558 minecraft:calcite
setblock 83 117 598 minecraft:calcite
fill 84 117 558 84 118 558 minecraft:cobbled_deepslate
fill 84 117 598 84 120 598 minecraft:cobbled_deepslate
setblock 85 117 586 minecraft:calcite
fill 85 117 587 85 120 587 minecraft:cobbled_deepslate
fill 85 117 589 85 118 589 minecraft:cobbled_deepslate
setblock 86 117 585 minecraft:calcite
fill 86 117 586 86 120 586 minecraft:cobbled_deepslate
setblock 86 117 590 minecraft:calcite
fill 86 117 591 86 120 591 minecraft:cobbled_deepslate
fill 87 117 580 87 120 580 minecraft:cobbled_deepslate
setblock 87 117 584 minecraft:calcite
fill 87 117 585 87 120 585 minecraft:cobbled_deepslate
setblock 87 117 589 minecraft:calcite
fill 87 117 590 87 120 590 minecraft:cobbled_deepslate
setblock 88 117 563 minecraft:calcite
fill 88 117 564 88 120 564 minecraft:cobbled_deepslate
setblock 88 117 568 minecraft:calcite
fill 88 117 569 88 119 570 minecraft:cobbled_deepslate
setblock 88 117 578 minecraft:calcite
fill 88 117 579 88 120 579 minecraft:cobbled_deepslate
setblock 88 117 583 minecraft:calcite
fill 88 117 584 88 120 584 minecraft:cobbled_deepslate
setblock 88 117 588 minecraft:calcite
fill 88 117 589 88 120 589 minecraft:cobbled_deepslate
setblock 88 117 593 minecraft:calcite
fill 88 117 594 88 120 594 minecraft:cobbled_deepslate
setblock 48 118 562 minecraft:calcite
fill 48 118 563 48 121 563 minecraft:cobbled_deepslate
setblock 48 118 567 minecraft:calcite
fill 48 118 568 48 121 568 minecraft:cobbled_deepslate
setblock 48 118 572 minecraft:calcite
fill 48 118 573 48 121 573 minecraft:cobbled_deepslate
setblock 48 118 577 minecraft:calcite
fill 48 118 578 48 121 578 minecraft:cobbled_deepslate
setblock 48 118 582 minecraft:calcite
fill 48 118 583 48 121 583 minecraft:cobbled_deepslate
setblock 48 118 587 minecraft:calcite
fill 48 118 588 48 121 588 minecraft:cobbled_deepslate
setblock 49 118 566 minecraft:calcite
fill 49 118 567 49 121 567 minecraft:cobbled_deepslate
setblock 49 118 570 minecraft:cobbled_deepslate
setblock 49 118 586 minecraft:calcite
setblock 57 118 558 minecraft:calcite
fill 58 118 558 58 121 558 minecraft:cobbled_deepslate
setblock 60 118 560 minecraft:calcite
setblock 61 118 559 minecraft:calcite
fill 61 118 560 61 121 560 minecraft:cobbled_deepslate
setblock 61 118 598 minecraft:cobbled_deepslate
setblock 62 118 558 minecraft:calcite
fill 62 118 559 62 121 559 minecraft:cobbled_deepslate
setblock 62 118 598 minecraft:calcite
fill 63 118 558 63 121 558 minecraft:cobbled_deepslate
fill 63 118 598 63 121 598 minecraft:cobbled_deepslate
setblock 65 118 560 minecraft:calcite
setblock 66 118 559 minecraft:calcite
setblock 66 118 560 minecraft:cobbled_deepslate
setblock 67 118 558 minecraft:calcite
fill 67 118 559 67 120 559 minecraft:cobbled_deepslate
setblock 67 118 598 minecraft:calcite
fill 68 118 558 68 121 558 minecraft:cobbled_deepslate
fill 68 118 598 68 121 598 minecraft:cobbled_deepslate
fill 78 118 598 78 121 598 minecraft:cobbled_deepslate
fill 80 118 558 80 119 558 minecraft:cobbled_deepslate
setblock 82 118 558 minecraft:calcite
setblock 82 118 598 minecraft:calcite
fill 83 118 558 83 121 558 minecraft:cobbled_deepslate
fill 83 118 598 83 121 598 minecraft:cobbled_deepslate
setblock 85 118 585 minecraft:calcite
fill 85 118 586 85 121 586 minecraft:cobbled_deepslate
setblock 86 118 584 minecraft:calcite
fill 86 118 585 86 121 585 minecraft:cobbled_deepslate
setblock 86 118 589 minecraft:calcite
fill 86 118 590 86 121 590 minecraft:cobbled_deepslate
fill 87 118 566 87 118 567 minecraft:cobbled_deepslate
setblock 87 118 583 minecraft:calcite
fill 87 118 584 87 121 584 minecraft:cobbled_deepslate
setblock 87 118 588 minecraft:calcite
fill 87 118 589 87 121 589 minecraft:cobbled_deepslate
setblock 87 118 593 minecraft:calcite
setblock 88 118 562 minecraft:calcite
fill 88 118 563 88 121 563 minecraft:cobbled_deepslate
setblock 88 118 567 minecraft:calcite
fill 88 118 568 88 121 568 minecraft:cobbled_deepslate
setblock 88 118 571 minecraft:cobbled_deepslate
setblock 88 118 572 minecraft:calcite
setblock 88 118 577 minecraft:calcite
fill 88 118 578 88 121 578 minecraft:cobbled_deepslate
setblock 88 118 582 minecraft:calcite
fill 88 118 583 88 121 583 minecraft:cobbled_deepslate
setblock 88 118 587 minecraft:calcite
fill 88 118 588 88 121 588 minecraft:cobbled_deepslate
setblock 88 118 592 minecraft:calcite
fill 88 118 593 88 121 593 minecraft:cobbled_deepslate
setblock 48 119 561 minecraft:calcite
fill 48 119 562 48 122 562 minecraft:cobbled_deepslate
setblock 48 119 566 minecraft:calcite
fill 48 119 567 48 122 567 minecraft:cobbled_deepslate
setblock 48 119 571 minecraft:calcite
fill 48 119 572 48 122 572 minecraft:cobbled_deepslate
setblock 48 119 576 minecraft:calcite
fill 48 119 577 48 122 577 minecraft:cobbled_deepslate
setblock 48 119 581 minecraft:calcite
fill 48 119 582 48 122 582 minecraft:cobbled_deepslate
setblock 48 119 586 minecraft:calcite
fill 48 119 587 48 122 587 minecraft:cobbled_deepslate
setblock 48 119 591 minecraft:calcite
setblock 49 119 565 minecraft:calcite
fill 49 119 566 49 122 566 minecraft:cobbled_deepslate
setblock 49 119 570 minecraft:calcite
fill 49 119 571 49 122 571 minecraft:cobbled_deepslate
fill 57 119 558 57 122 558 minecraft:cobbled_deepslate
fill 58 119 559 58 120 559 minecraft:cobbled_deepslate
setblock 60 119 559 minecraft:calcite
fill 60 119 560 60 122 560 minecraft:cobbled_deepslate
setblock 60 119 598 minecraft:cobbled_deepslate
setblock 61 119 558 minecraft:calcite
fill 61 119 559 61 122 559 minecraft:cobbled_deepslate
setblock 61 119 598 minecraft:calcite
fill 62 119 558 62 122 558 minecraft:cobbled_deepslate
fill 62 119 598 62 122 598 minecraft:cobbled_deepslate
setblock 64 119 560 minecraft:calcite
setblock 65 119 559 minecraft:calcite
fill 65 119 560 65 120 560 minecraft:cobbled_deepslate
setblock 66 119 558 minecraft:calcite
fill 66 119 559 66 122 559 minecraft:cobbled_deepslate
setblock 66 119 598 minecraft:calcite
fill 67 119 558 67 122 558 minecraft:cobbled_deepslate
fill 67 119 598 67 122 598 minecraft:cobbled_deepslate
fill 77 119 598 77 122 598 minecraft:cobbled_deepslate
fill 80 119 597 81 119 597 minecraft:cobbled_deepslate
setblock 81 119 558 minecraft:calcite
setblock 81 119 598 minecraft:calcite
fill 82 119 558 82 122 558 minecraft:cobbled_deepslate
setblock 82 119 597 minecraft:calcite
fill 82 119 598 82 122 598 minecraft:cobbled_deepslate
fill 83 119 597 83 122 597 minecraft:cobbled_deepslate
setblock 85 119 584 minecraft:calcite
fill 85 119 585 85 121 585 minecraft:cobbled_deepslate
setblock 85 119 589 minecraft:calcite
fill 85 119 590 85 122 590 minecraft:cobbled_deepslate
setblock 86 119 583 minecraft:calcite
fill 86 119 584 86 122 584 minecraft:cobbled_deepslate
setblock 86 119 588 minecraft:calcite
fill 86 119 589 86 122 589 minecraft:cobbled_deepslate
setblock 86 119 592 minecraft:cobbled_deepslate
fill 87 119 565 87 119 566 minecraft:cobbled_deepslate
setblock 87 119 567 minecraft:calcite
fill 87 119 568 87 120 570 minecraft:cobbled_deepslate
setblock 87 119 582 minecraft:calcite
fill 87 119 583 87 122 583 minecraft:cobbled_deepslate
setblock 87 119 587 minecraft:calcite
fill 87 119 588 87 122 588 minecraft:cobbled_deepslate
setblock 87 119 592 minecraft:calcite
fill 87 119 593 87 122 593 minecraft:cobbled_deepslate
setblock 88 119 566 minecraft:calcite
fill 88 119 567 88 122 567 minecraft:cobbled_deepslate
setblock 88 119 571 minecraft:calcite
fill 88 119 572 88 119 575 minecraft:cobbled_deepslate
setblock 88 119 576 minecraft:calcite
fill 88 119 577 88 122 577 minecraft:cobbled_deepslate
setblock 88 119 581 minecraft:calcite
fill 88 119 582 88 122 582 minecraft:cobbled_deepslate
setblock 88 119 586 minecraft:calcite
fill 88 119 587 88 122 587 minecraft:cobbled_deepslate
setblock 88 119 591 minecraft:calcite
fill 88 119 592 88 122 592 minecraft:cobbled_deepslate
fill 48 120 561 48 121 561 minecraft:cobbled_deepslate
setblock 48 120 565 minecraft:calcite
fill 48 120 566 48 123 566 minecraft:cobbled_deepslate
setblock 48 120 569 minecraft:cobbled_deepslate
setblock 48 120 570 minecraft:calcite
fill 48 120 571 48 123 571 minecraft:cobbled_deepslate
setblock 48 120 575 minecraft:calcite
fill 48 120 576 48 123 576 minecraft:cobbled_deepslate
setblock 48 120 580 minecraft:calcite
fill 48 120 581 48 121 581 minecraft:cobbled_deepslate
setblock 48 120 585 minecraft:calcite
fill 48 120 586 48 123 586 minecraft:cobbled_deepslate
setblock 48 120 590 minecraft:calcite
fill 48 120 591 48 122 592 minecraft:cobbled_deepslate
setblock 49 120 564 minecraft:calcite
fill 49 120 565 49 123 565 minecraft:cobbled_deepslate
setblock 49 120 569 minecraft:calcite
fill 49 120 570 49 123 570 minecraft:cobbled_deepslate
fill 49 120 572 49 121 572 minecraft:cobbled_deepslate
setblock 50 120 560 minecraft:light[level=14]
setblock 50 120 568 minecraft:light[level=14]
setblock 50 120 576 minecraft:light[level=14]
setblock 50 120 584 minecraft:light[level=14]
setblock 50 120 592 minecraft:light[level=14]
fill 56 120 558 56 123 558 minecraft:cobbled_deepslate
setblock 58 120 560 minecraft:light[level=14]
setblock 58 120 568 minecraft:light[level=14]
setblock 58 120 576 minecraft:light[level=14]
setblock 58 120 584 minecraft:light[level=14]
setblock 58 120 592 minecraft:light[level=14]
setblock 59 120 558 minecraft:cobbled_deepslate
setblock 59 120 559 minecraft:calcite
fill 59 120 560 59 123 560 minecraft:cobbled_deepslate
setblock 59 120 598 minecraft:cobbled_deepslate
setblock 60 120 558 minecraft:calcite
fill 60 120 559 60 123 559 minecraft:cobbled_deepslate
setblock 60 120 598 minecraft:calcite
fill 61 120 558 61 123 558 minecraft:cobbled_deepslate
fill 61 120 598 61 123 598 minecraft:cobbled_deepslate
fill 62 120 597 65 120 597 minecraft:cobbled_deepslate
setblock 63 120 560 minecraft:calcite
setblock 64 120 559 minecraft:calcite
fill 64 120 560 64 121 560 minecraft:cobbled_deepslate
setblock 65 120 558 minecraft:calcite
fill 65 120 559 65 123 559 minecraft:cobbled_deepslate
setblock 65 120 598 minecraft:calcite
fill 66 120 558 66 123 558 minecraft:cobbled_deepslate
setblock 66 120 560 minecraft:light[level=14]
setblock 66 120 576 minecraft:light[level=14]
setblock 66 120 584 minecraft:light[level=14]
setblock 66 120 592 minecraft:light[level=14]
fill 66 120 598 66 123 598 minecraft:cobbled_deepslate
setblock 69 120 598 minecraft:cobbled_deepslate
setblock 74 120 560 minecraft:light[level=14]
setblock 74 120 568 minecraft:light[level=14]
setblock 74 120 576 minecraft:light[level=14]
setblock 74 120 584 minecraft:light[level=14]
setblock 74 120 592 minecraft:light[level=14]
setblock 75 120 598 minecraft:calcite
fill 76 120 598 76 123 598 minecraft:cobbled_deepslate
fill 78 120 597 80 120 597 minecraft:cobbled_deepslate
setblock 79 120 558 minecraft:cobbled_deepslate
setblock 80 120 558 minecraft:calcite
setblock 80 120 598 minecraft:calcite
fill 81 120 558 81 123 558 minecraft:cobbled_deepslate
setblock 81 120 597 minecraft:calcite
fill 81 120 598 81 123 598 minecraft:cobbled_deepslate
setblock 82 120 560 minecraft:light[level=14]
setblock 82 120 568 minecraft:light[level=14]
setblock 82 120 576 minecraft:light[level=14]
setblock 82 120 584 minecraft:light[level=14]
setblock 82 120 592 minecraft:light[level=14]
fill 82 120 597 82 123 597 minecraft:cobbled_deepslate
fill 84 120 597 84 121 597 minecraft:cobbled_deepslate
setblock 85 120 588 minecraft:calcite
fill 85 120 589 85 123 589 minecraft:cobbled_deepslate
fill 85 120 591 85 121 591 minecraft:cobbled_deepslate
setblock 85 120 598 minecraft:calcite
fill 86 120 583 86 121 583 minecraft:cobbled_deepslate
setblock 86 120 587 minecraft:calcite
fill 86 120 588 86 123 588 minecraft:cobbled_deepslate
setblock 86 120 592 minecraft:calcite
setblock 87 120 565 minecraft:cobbled_deepslate
setblock 87 120 566 minecraft:calcite
fill 87 120 567 87 123 567 minecraft:cobbled_deepslate
setblock 87 120 571 minecraft:calcite
fill 87 120 572 88 122 572 minecraft:cobbled_deepslate
setblock 87 120 581 minecraft:calcite
fill 87 120 582 87 122 582 minecraft:cobbled_deepslate
setblock 87 120 586 minecraft:calcite
fill 87 120 587 87 123 587 minecraft:cobbled_deepslate
setblock 87 120 591 minecraft:calcite
fill 87 120 592 87 123 592 minecraft:cobbled_deepslate
fill 87 120 594 87 121 594 minecraft:cobbled_deepslate
setblock 88 120 565 minecraft:calcite
fill 88 120 566 88 123 566 minecraft:cobbled_deepslate
setblock 88 120 569 minecraft:cobbled_deepslate
setblock 88 120 570 minecraft:calcite
fill 88 120 571 88 123 571 minecraft:cobbled_deepslate
fill 88 120 573 88 120 574 minecraft:cobbled_deepslate
setblock 88 120 575 minecraft:calcite
fill 88 120 576 88 123 576 minecraft:cobbled_deepslate
setblock 88 120 580 minecraft:calcite
fill 88 120 581 88 123 581 minecraft:cobbled_deepslate
setblock 88 120 585 minecraft:calcite
fill 88 120 586 88 123 586 minecraft:cobbled_deepslate
setblock 88 120 590 minecraft:calcite
fill 88 120 591 88 123 591 minecraft:cobbled_deepslate
setblock 88 120 595 minecraft:calcite
setblock 48 121 564 minecraft:calcite
fill 48 121 565 48 124 565 minecraft:cobbled_deepslate
setblock 48 121 569 minecraft:calcite
fill 48 121 570 48 124 570 minecraft:cobbled_deepslate
setblock 48 121 574 minecraft:calcite
fill 48 121 575 48 124 575 minecraft:cobbled_deepslate
setblock 48 121 579 minecraft:calcite
setblock 48 121 580 minecraft:cobbled_deepslate
setblock 48 121 584 minecraft:calcite
fill 48 121 585 48 123 585 minecraft:cobbled_deepslate
setblock 48 121 589 minecraft:calcite
fill 48 121 590 48 124 590 minecraft:cobbled_deepslate
fill 49 121 564 49 122 564 minecraft:cobbled_deepslate
setblock 49 121 568 minecraft:calcite
fill 49 121 569 50 123 569 minecraft:cobbled_deepslate
setblock 49 121 573 minecraft:calcite
setblock 50 121 567 minecraft:calcite
fill 50 121 568 50 124 568 minecraft:cobbled_deepslate
fill 55 121 558 55 124 558 minecraft:cobbled_deepslate
setblock 57 121 559 minecraft:cobbled_deepslate
setblock 58 121 559 minecraft:calcite
setblock 58 121 598 minecraft:cobbled_deepslate
setblock 59 121 558 minecraft:calcite
fill 59 121 559 59 124 559 minecraft:cobbled_deepslate
setblock 59 121 598 minecraft:calcite
fill 60 121 558 60 124 558 minecraft:cobbled_deepslate
setblock 60 121 597 minecraft:calcite
fill 60 121 598 60 124 598 minecraft:cobbled_deepslate
fill 61 121 597 64 121 597 minecraft:cobbled_deepslate
setblock 62 121 560 minecraft:calcite
setblock 63 121 559 minecraft:calcite
fill 63 121 560 63 122 560 minecraft:cobbled_deepslate
setblock 64 121 558 minecraft:calcite
fill 64 121 559 64 124 559 minecraft:cobbled_deepslate
setblock 64 121 598 minecraft:calcite
fill 65 121 558 65 124 558 minecraft:cobbled_deepslate
setblock 65 121 597 minecraft:calcite
fill 65 121 598 65 124 598 minecraft:cobbled_deepslate
fill 66 121 597 66 124 597 minecraft:cobbled_deepslate
setblock 69 121 558 minecraft:calcite
setblock 69 121 598 minecraft:calcite
fill 70 121 598 73 121 598 minecraft:cobbled_deepslate
setblock 74 121 598 minecraft:calcite
fill 75 121 598 75 124 598 minecraft:cobbled_deepslate
fill 76 121 597 79 121 597 minecraft:cobbled_deepslate
setblock 78 121 558 minecraft:cobbled_deepslate
setblock 79 121 558 minecraft:calcite
fill 79 121 596 80 121 596 minecraft:cobbled_deepslate
setblock 79 121 598 minecraft:calcite
fill 80 121 558 80 124 558 minecraft:cobbled_deepslate
setblock 80 121 597 minecraft:calcite
fill 80 121 598 80 124 598 minecraft:cobbled_deepslate
setblock 81 121 596 minecraft:calcite
fill 81 121 597 81 124 597 minecraft:cobbled_deepslate
fill 82 121 596 82 124 596 minecraft:cobbled_deepslate
setblock 84 121 598 minecraft:calcite
setblock 85 121 587 minecraft:calcite
fill 85 121 588 85 123 588 minecraft:cobbled_deepslate
fill 85 121 598 85 124 598 minecraft:cobbled_deepslate
setblock 86 121 586 minecraft:calcite
fill 86 121 587 86 123 587 minecraft:cobbled_deepslate
setblock 86 121 591 minecraft:calcite
fill 86 121 592 86 123 593 minecraft:cobbled_deepslate
setblock 87 121 565 minecraft:calcite
fill 87 121 566 87 122 566 minecraft:cobbled_deepslate
fill 87 121 568 87 121 569 minecraft:cobbled_deepslate
setblock 87 121 570 minecraft:calcite
fill 87 121 571 87 124 571 minecraft:cobbled_deepslate
fill 87 121 573 87 121 574 minecraft:cobbled_deepslate
fill 87 121 581 87 122 581 minecraft:cobbled_deepslate
setblock 87 121 585 minecraft:calcite
fill 87 121 586 87 124 586 minecraft:cobbled_deepslate
setblock 87 121 590 minecraft:calcite
fill 87 121 591 87 124 591 minecraft:cobbled_deepslate
setblock 88 121 564 minecraft:calcite
fill 88 121 565 88 124 565 minecraft:cobbled_deepslate
setblock 88 121 569 minecraft:calcite
fill 88 121 570 88 124 570 minecraft:cobbled_deepslate
setblock 88 121 573 minecraft:cobbled_deepslate
setblock 88 121 574 minecraft:calcite
fill 88 121 575 88 124 575 minecraft:cobbled_deepslate
setblock 88 121 579 minecraft:calcite
fill 88 121 580 88 124 580 minecraft:cobbled_deepslate
setblock 88 121 584 minecraft:calcite
fill 88 121 585 88 124 585 minecraft:cobbled_deepslate
setblock 88 121 589 minecraft:calcite
fill 88 121 590 88 124 590 minecraft:cobbled_deepslate
setblock 88 121 594 minecraft:calcite
fill 88 121 595 88 124 595 minecraft:cobbled_deepslate
setblock 48 122 563 minecraft:calcite
fill 48 122 564 48 125 564 minecraft:cobbled_deepslate
setblock 48 122 568 minecraft:calcite
fill 48 122 569 48 125 569 minecraft:cobbled_deepslate
setblock 48 122 573 minecraft:calcite
schedule function dropper:buildpart/133_5 1t
