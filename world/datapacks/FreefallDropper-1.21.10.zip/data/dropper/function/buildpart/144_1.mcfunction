fill 0 74 625 0 80 625 minecraft:black_concrete
setblock 7 74 604 minecraft:white_concrete
fill 9 74 604 9 128 604 minecraft:black_concrete
fill 17 74 646 18 109 646 minecraft:black_concrete
setblock 19 74 646 minecraft:glowstone
fill 41 74 646 41 128 646 minecraft:black_concrete
fill 0 75 612 0 81 612 minecraft:black_concrete
fill 0 75 628 0 81 628 minecraft:black_concrete
fill 0 75 644 0 81 644 minecraft:black_concrete
fill 4 75 604 4 78 604 minecraft:black_concrete
fill 7 75 604 7 124 604 minecraft:black_concrete
fill 14 75 646 14 81 646 minecraft:black_concrete
fill 19 75 646 19 128 646 minecraft:black_concrete
fill 20 75 604 20 81 604 minecraft:black_concrete
fill 30 75 646 30 76 646 minecraft:black_concrete
fill 36 75 604 36 81 604 minecraft:black_concrete
fill 42 75 614 42 77 614 minecraft:black_concrete
fill 42 75 630 42 81 630 minecraft:black_concrete
setblock 42 76 610 minecraft:white_concrete
fill 42 76 611 42 96 612 minecraft:black_concrete
setblock 42 76 644 minecraft:diamond_block
fill 42 76 645 42 101 645 minecraft:black_concrete
setblock 0 77 640 minecraft:glowstone
setblock 2 77 646 minecraft:white_concrete
fill 3 77 646 4 108 646 minecraft:black_concrete
setblock 30 77 646 minecraft:glowstone
setblock 37 77 646 minecraft:glowstone
setblock 38 77 646 minecraft:black_concrete
fill 42 77 610 42 78 610 minecraft:black_concrete
fill 42 77 644 42 96 644 minecraft:black_concrete
fill 0 78 640 0 129 640 minecraft:black_concrete
fill 2 78 646 2 128 646 minecraft:black_concrete
fill 30 78 646 30 81 646 minecraft:black_concrete
fill 37 78 646 37 126 646 minecraft:black_concrete
setblock 38 78 646 minecraft:glowstone
setblock 42 78 614 minecraft:diamond_block
setblock 0 79 622 minecraft:glowstone
setblock 4 79 604 minecraft:diamond_block
fill 38 79 646 38 91 646 minecraft:black_concrete
setblock 42 79 610 minecraft:diamond_block
fill 42 79 614 42 81 614 minecraft:black_concrete
fill 0 80 622 0 87 622 minecraft:black_concrete
setblock 3 80 607 minecraft:light[level=14]
setblock 3 80 615 minecraft:light[level=14]
setblock 3 80 623 minecraft:light[level=14]
setblock 3 80 631 minecraft:light[level=14]
setblock 3 80 639 minecraft:light[level=14]
fill 4 80 604 4 81 604 minecraft:black_concrete
setblock 11 80 607 minecraft:light[level=14]
setblock 11 80 615 minecraft:light[level=14]
fill 11 80 616 12 81 617 minecraft:moss_block
setblock 11 80 623 minecraft:light[level=14]
setblock 11 80 631 minecraft:light[level=14]
setblock 11 80 639 minecraft:light[level=14]
setblock 19 80 607 minecraft:light[level=14]
setblock 19 80 615 minecraft:light[level=14]
setblock 19 80 623 minecraft:light[level=14]
setblock 19 80 631 minecraft:light[level=14]
setblock 19 80 639 minecraft:light[level=14]
setblock 27 80 607 minecraft:light[level=14]
setblock 27 80 615 minecraft:light[level=14]
setblock 27 80 623 minecraft:light[level=14]
setblock 27 80 631 minecraft:light[level=14]
setblock 27 80 639 minecraft:light[level=14]
setblock 35 80 607 minecraft:light[level=14]
setblock 35 80 615 minecraft:light[level=14]
setblock 35 80 623 minecraft:light[level=14]
setblock 35 80 631 minecraft:light[level=14]
setblock 35 80 639 minecraft:light[level=14]
fill 42 80 610 42 120 610 minecraft:black_concrete
setblock 0 81 625 minecraft:white_concrete
setblock 22 81 646 minecraft:diamond_block
fill 23 81 646 24 104 646 minecraft:black_concrete
setblock 36 81 646 minecraft:glowstone
fill 42 81 624 42 86 625 minecraft:black_concrete
setblock 42 81 626 minecraft:white_concrete
fill 0 82 612 0 83 612 minecraft:moss_block
fill 0 82 625 0 93 625 minecraft:black_concrete
fill 0 82 628 0 83 628 minecraft:moss_block
fill 0 82 644 0 83 644 minecraft:moss_block
fill 4 82 604 4 83 604 minecraft:moss_block
fill 5 82 604 5 112 604 minecraft:black_concrete
setblock 6 82 604 minecraft:glowstone
setblock 12 82 646 minecraft:diamond_block
fill 14 82 646 14 83 646 minecraft:moss_block
fill 20 82 604 20 83 604 minecraft:moss_block
fill 22 82 646 22 128 646 minecraft:black_concrete
fill 30 82 646 30 83 646 minecraft:moss_block
fill 36 82 604 36 83 604 minecraft:moss_block
fill 36 82 646 36 124 646 minecraft:black_concrete
fill 40 82 604 40 84 604 minecraft:black_concrete
fill 41 82 604 41 83 604 minecraft:diamond_block
fill 42 82 614 42 83 614 minecraft:moss_block
fill 42 82 626 42 128 626 minecraft:black_concrete
fill 42 82 630 42 83 630 minecraft:moss_block
fill 6 83 604 6 128 604 minecraft:black_concrete
fill 12 83 646 12 128 646 minecraft:black_concrete
setblock 42 83 608 minecraft:glowstone
fill 0 84 612 0 90 612 minecraft:black_concrete
setblock 0 84 617 minecraft:white_concrete
fill 0 84 628 0 90 628 minecraft:black_concrete
setblock 0 84 634 minecraft:glowstone
fill 0 84 635 0 128 635 minecraft:black_concrete
fill 0 84 644 0 90 644 minecraft:black_concrete
fill 4 84 604 4 90 604 minecraft:black_concrete
fill 14 84 646 14 90 646 minecraft:black_concrete
fill 15 84 612 15 85 612 minecraft:gold_block
fill 20 84 604 20 90 604 minecraft:black_concrete
setblock 30 84 646 minecraft:black_concrete
fill 36 84 604 36 90 604 minecraft:black_concrete
setblock 41 84 604 minecraft:black_concrete
fill 42 84 608 42 99 608 minecraft:black_concrete
fill 42 84 614 42 90 614 minecraft:black_concrete
fill 42 84 630 42 90 630 minecraft:black_concrete
setblock 0 85 610 minecraft:white_concrete
fill 0 85 617 0 125 617 minecraft:black_concrete
fill 0 85 634 0 124 634 minecraft:black_concrete
setblock 10 85 604 minecraft:glowstone
fill 11 85 604 13 94 604 minecraft:black_concrete
setblock 30 85 646 minecraft:white_concrete
setblock 40 85 604 minecraft:diamond_block
setblock 41 85 604 minecraft:white_concrete
fill 0 86 610 0 125 610 minecraft:black_concrete
fill 10 86 604 10 128 604 minecraft:black_concrete
fill 30 86 646 30 90 646 minecraft:black_concrete
fill 40 86 604 41 99 604 minecraft:black_concrete
setblock 42 86 617 minecraft:white_concrete
fill 42 87 615 42 128 615 minecraft:black_concrete
setblock 42 87 616 minecraft:diamond_block
fill 42 87 617 42 128 617 minecraft:black_concrete
setblock 42 87 620 minecraft:diamond_block
setblock 42 87 624 minecraft:diamond_block
fill 42 87 625 42 115 625 minecraft:black_concrete
setblock 0 88 622 minecraft:diamond_block
setblock 3 88 607 minecraft:light[level=14]
setblock 3 88 615 minecraft:light[level=14]
setblock 3 88 623 minecraft:light[level=14]
setblock 3 88 631 minecraft:light[level=14]
setblock 3 88 639 minecraft:light[level=14]
setblock 11 88 607 minecraft:light[level=14]
setblock 11 88 615 minecraft:light[level=14]
setblock 11 88 623 minecraft:light[level=14]
setblock 11 88 631 minecraft:light[level=14]
setblock 11 88 639 minecraft:light[level=14]
setblock 19 88 607 minecraft:light[level=14]
setblock 19 88 615 minecraft:light[level=14]
setblock 19 88 623 minecraft:light[level=14]
setblock 19 88 631 minecraft:light[level=14]
setblock 19 88 639 minecraft:light[level=14]
setblock 24 88 604 minecraft:diamond_block
setblock 27 88 607 minecraft:light[level=14]
setblock 27 88 615 minecraft:light[level=14]
setblock 27 88 623 minecraft:light[level=14]
setblock 27 88 631 minecraft:light[level=14]
setblock 27 88 639 minecraft:light[level=14]
setblock 35 88 607 minecraft:light[level=14]
setblock 35 88 615 minecraft:light[level=14]
setblock 35 88 623 minecraft:light[level=14]
setblock 35 88 631 minecraft:light[level=14]
setblock 35 88 639 minecraft:light[level=14]
fill 42 88 616 42 126 616 minecraft:black_concrete
fill 42 88 620 42 127 620 minecraft:black_concrete
fill 42 88 624 42 93 624 minecraft:black_concrete
fill 0 89 622 0 128 622 minecraft:black_concrete
fill 24 89 604 24 128 604 minecraft:black_concrete
setblock 31 89 646 minecraft:diamond_block
setblock 42 89 619 minecraft:glowstone
fill 31 90 646 31 128 646 minecraft:black_concrete
fill 42 90 619 42 128 619 minecraft:black_concrete
setblock 42 90 634 minecraft:white_concrete
fill 0 91 612 0 92 612 minecraft:moss_block
fill 0 91 628 0 92 628 minecraft:moss_block
setblock 0 91 639 minecraft:diamond_block
fill 0 91 644 0 92 644 minecraft:moss_block
fill 4 91 604 4 92 604 minecraft:moss_block
fill 14 91 646 14 92 646 minecraft:moss_block
fill 20 91 604 20 92 604 minecraft:moss_block
fill 30 91 646 30 92 646 minecraft:moss_block
fill 36 91 604 36 92 604 minecraft:moss_block
fill 42 91 614 42 92 614 minecraft:moss_block
fill 42 91 630 42 92 630 minecraft:moss_block
setblock 42 91 634 minecraft:black_concrete
fill 0 92 639 0 105 639 minecraft:black_concrete
setblock 38 92 646 minecraft:white_concrete
setblock 42 92 633 minecraft:diamond_block
setblock 42 92 634 minecraft:white_concrete
setblock 42 92 635 minecraft:diamond_block
fill 0 93 612 0 99 612 minecraft:black_concrete
fill 0 93 628 0 99 628 minecraft:black_concrete
setblock 0 93 644 minecraft:white_concrete
fill 4 93 604 4 99 604 minecraft:black_concrete
fill 14 93 646 14 99 646 minecraft:black_concrete
fill 20 93 604 20 94 604 minecraft:black_concrete
fill 30 93 646 30 99 646 minecraft:black_concrete
fill 36 93 604 36 99 604 minecraft:black_concrete
setblock 37 93 604 minecraft:diamond_block
fill 38 93 646 38 128 646 minecraft:black_concrete
fill 42 93 614 42 99 614 minecraft:black_concrete
fill 42 93 630 42 99 630 minecraft:black_concrete
fill 42 93 633 42 105 635 minecraft:black_concrete
setblock 0 94 625 minecraft:glowstone
fill 0 94 644 0 99 644 minecraft:black_concrete
setblock 1 94 646 minecraft:glowstone
fill 37 94 604 37 113 604 minecraft:black_concrete
setblock 42 94 624 minecraft:glowstone
setblock 42 94 627 minecraft:glowstone
fill 0 95 625 0 105 625 minecraft:black_concrete
fill 1 95 646 1 128 646 minecraft:black_concrete
setblock 11 95 604 minecraft:glowstone
fill 12 95 604 13 99 604 minecraft:black_concrete
setblock 15 95 604 minecraft:diamond_block
setblock 19 95 604 minecraft:glowstone
setblock 20 95 604 minecraft:white_concrete
fill 42 95 624 42 128 624 minecraft:black_concrete
fill 42 95 627 42 124 627 minecraft:black_concrete
fill 0 96 604 0 128 604 minecraft:black_concrete
setblock 0 96 605 minecraft:white_concrete
setblock 3 96 607 minecraft:light[level=14]
setblock 3 96 615 minecraft:light[level=14]
setblock 3 96 623 minecraft:light[level=14]
setblock 3 96 631 minecraft:light[level=14]
setblock 3 96 639 minecraft:light[level=14]
fill 11 96 604 11 125 604 minecraft:black_concrete
setblock 11 96 607 minecraft:light[level=14]
setblock 11 96 615 minecraft:light[level=14]
setblock 11 96 623 minecraft:light[level=14]
setblock 11 96 631 minecraft:light[level=14]
setblock 11 96 639 minecraft:light[level=14]
fill 15 96 604 15 128 604 minecraft:black_concrete
fill 19 96 604 20 99 604 minecraft:black_concrete
setblock 19 96 607 minecraft:light[level=14]
setblock 19 96 615 minecraft:light[level=14]
setblock 19 96 623 minecraft:light[level=14]
setblock 19 96 631 minecraft:light[level=14]
setblock 19 96 639 minecraft:light[level=14]
setblock 27 96 607 minecraft:light[level=14]
setblock 27 96 615 minecraft:light[level=14]
setblock 27 96 623 minecraft:light[level=14]
setblock 27 96 631 minecraft:light[level=14]
setblock 27 96 639 minecraft:light[level=14]
setblock 35 96 607 minecraft:light[level=14]
setblock 35 96 615 minecraft:light[level=14]
setblock 35 96 623 minecraft:light[level=14]
setblock 35 96 631 minecraft:light[level=14]
setblock 35 96 639 minecraft:light[level=14]
fill 0 97 605 0 104 605 minecraft:black_concrete
setblock 17 97 604 minecraft:white_concrete
setblock 40 97 646 minecraft:glowstone
setblock 42 97 611 minecraft:white_concrete
fill 42 97 612 42 128 612 minecraft:black_concrete
setblock 42 97 644 minecraft:diamond_block
setblock 0 98 641 minecraft:glowstone
fill 17 98 604 17 128 604 minecraft:black_concrete
setblock 35 98 604 minecraft:glowstone
fill 40 98 646 40 128 646 minecraft:black_concrete
fill 42 98 611 42 128 611 minecraft:black_concrete
fill 42 98 644 42 124 644 minecraft:black_concrete
fill 0 99 641 0 128 641 minecraft:black_concrete
setblock 32 99 604 minecraft:diamond_block
setblock 33 99 646 minecraft:white_concrete
fill 35 99 604 35 128 604 minecraft:black_concrete
setblock 0 100 611 minecraft:glowstone
fill 0 100 612 0 101 612 minecraft:moss_block
fill 0 100 628 0 101 628 minecraft:moss_block
fill 0 100 644 0 101 644 minecraft:moss_block
fill 4 100 604 4 101 604 minecraft:moss_block
fill 12 100 604 12 126 604 minecraft:black_concrete
fill 13 100 604 13 101 604 minecraft:white_concrete
fill 14 100 646 14 101 646 minecraft:moss_block
fill 16 100 618 16 101 618 minecraft:moss_block
fill 19 100 604 19 106 604 minecraft:black_concrete
fill 20 100 604 20 101 604 minecraft:moss_block
fill 30 100 646 30 101 646 minecraft:moss_block
fill 32 100 604 32 128 604 minecraft:black_concrete
fill 33 100 646 33 128 646 minecraft:black_concrete
fill 36 100 604 36 101 604 minecraft:moss_block
fill 40 100 604 40 128 604 minecraft:black_concrete
setblock 41 100 604 minecraft:white_concrete
setblock 42 100 608 minecraft:glowstone
fill 42 100 614 42 101 614 minecraft:moss_block
fill 42 100 630 42 101 630 minecraft:moss_block
fill 0 101 611 0 124 611 minecraft:black_concrete
setblock 25 101 646 minecraft:white_concrete
fill 41 101 604 41 103 604 minecraft:black_concrete
fill 42 101 608 42 124 608 minecraft:black_concrete
fill 0 102 612 0 108 612 minecraft:black_concrete
fill 0 102 628 0 108 628 minecraft:black_concrete
fill 0 102 644 0 108 644 minecraft:black_concrete
fill 4 102 604 4 103 604 minecraft:black_concrete
fill 13 102 604 13 128 604 minecraft:black_concrete
fill 14 102 646 14 104 646 minecraft:black_concrete
fill 20 102 604 20 108 604 minecraft:black_concrete
fill 25 102 646 25 128 646 minecraft:black_concrete
fill 30 102 646 30 108 646 minecraft:black_concrete
fill 36 102 604 36 108 604 minecraft:black_concrete
fill 42 102 614 42 105 614 minecraft:black_concrete
fill 42 102 630 42 108 630 minecraft:black_concrete
setblock 42 102 645 minecraft:glowstone
setblock 0 103 615 minecraft:diamond_block
setblock 0 103 630 minecraft:white_concrete
setblock 42 103 638 minecraft:glowstone
fill 42 103 645 42 121 645 minecraft:black_concrete
fill 0 104 615 0 119 615 minecraft:black_concrete
fill 0 104 630 0 107 630 minecraft:black_concrete
setblock 3 104 607 minecraft:light[level=14]
setblock 3 104 615 minecraft:light[level=14]
setblock 3 104 623 minecraft:light[level=14]
setblock 3 104 631 minecraft:light[level=14]
setblock 3 104 639 minecraft:light[level=14]
setblock 4 104 604 minecraft:glowstone
setblock 11 104 607 minecraft:light[level=14]
setblock 11 104 615 minecraft:light[level=14]
setblock 11 104 623 minecraft:light[level=14]
setblock 11 104 631 minecraft:light[level=14]
setblock 11 104 639 minecraft:light[level=14]
setblock 19 104 607 minecraft:light[level=14]
setblock 19 104 615 minecraft:light[level=14]
setblock 19 104 623 minecraft:light[level=14]
setblock 19 104 631 minecraft:light[level=14]
setblock 19 104 639 minecraft:light[level=14]
setblock 27 104 607 minecraft:light[level=14]
setblock 27 104 615 minecraft:light[level=14]
setblock 27 104 623 minecraft:light[level=14]
setblock 27 104 631 minecraft:light[level=14]
setblock 27 104 639 minecraft:light[level=14]
setblock 31 104 604 minecraft:glowstone
setblock 35 104 607 minecraft:light[level=14]
setblock 35 104 615 minecraft:light[level=14]
setblock 35 104 623 minecraft:light[level=14]
setblock 35 104 631 minecraft:light[level=14]
setblock 35 104 639 minecraft:light[level=14]
setblock 39 104 646 minecraft:diamond_block
setblock 41 104 604 minecraft:diamond_block
fill 42 104 638 42 126 638 minecraft:black_concrete
setblock 0 105 605 minecraft:white_concrete
fill 4 105 604 4 108 604 minecraft:black_concrete
setblock 8 105 646 minecraft:diamond_block
setblock 14 105 646 minecraft:white_concrete
setblock 23 105 646 minecraft:glowstone
fill 24 105 646 24 124 646 minecraft:black_concrete
fill 31 105 604 31 128 604 minecraft:black_concrete
fill 39 105 646 39 128 646 minecraft:black_concrete
fill 41 105 604 41 125 604 minecraft:black_concrete
setblock 42 105 642 minecraft:diamond_block
fill 0 106 605 0 128 605 minecraft:black_concrete
setblock 0 106 618 minecraft:glowstone
setblock 0 106 625 minecraft:white_concrete
setblock 0 106 639 minecraft:white_concrete
fill 8 106 646 8 128 646 minecraft:black_concrete
fill 14 106 646 14 108 646 minecraft:black_concrete
fill 21 106 604 21 128 604 minecraft:black_concrete
setblock 22 106 604 minecraft:white_concrete
fill 23 106 646 23 122 646 minecraft:black_concrete
setblock 42 106 614 minecraft:white_concrete
fill 42 106 633 42 111 634 minecraft:black_concrete
setblock 42 106 635 minecraft:white_concrete
fill 42 106 642 42 128 642 minecraft:black_concrete
fill 0 107 618 0 125 618 minecraft:black_concrete
fill 0 107 625 0 109 626 minecraft:black_concrete
setblock 0 107 627 minecraft:white_concrete
fill 0 107 639 0 118 639 minecraft:black_concrete
setblock 1 107 604 minecraft:diamond_block
fill 2 107 604 2 126 604 minecraft:black_concrete
setblock 19 107 604 minecraft:glowstone
fill 22 107 604 22 128 604 minecraft:black_concrete
fill 42 107 614 42 108 614 minecraft:black_concrete
setblock 42 107 623 minecraft:white_concrete
fill 42 107 635 42 110 635 minecraft:black_concrete
fill 0 108 627 0 128 627 minecraft:black_concrete
setblock 0 108 630 minecraft:glowstone
fill 1 108 604 1 128 604 minecraft:black_concrete
fill 19 108 604 19 128 604 minecraft:black_concrete
fill 42 108 623 42 123 623 minecraft:black_concrete
fill 0 109 612 0 110 612 minecraft:moss_block
fill 0 109 628 0 110 628 minecraft:moss_block
fill 0 109 630 0 128 630 minecraft:black_concrete
fill 0 109 644 0 110 644 minecraft:moss_block
fill 3 109 646 3 128 646 minecraft:black_concrete
fill 4 109 604 4 110 604 minecraft:moss_block
setblock 4 109 646 minecraft:white_concrete
fill 14 109 646 14 110 646 minecraft:moss_block
fill 20 109 604 20 110 604 minecraft:moss_block
fill 30 109 646 30 110 646 minecraft:moss_block
fill 36 109 604 36 110 604 minecraft:moss_block
fill 42 109 614 42 110 614 minecraft:moss_block
fill 42 109 630 42 110 630 minecraft:moss_block
setblock 0 110 625 minecraft:glowstone
fill 0 110 626 0 128 626 minecraft:black_concrete
fill 4 110 646 4 125 646 minecraft:black_concrete
fill 17 110 646 17 128 646 minecraft:black_concrete
setblock 18 110 646 minecraft:white_concrete
setblock 21 110 646 minecraft:glowstone
fill 0 111 612 0 115 612 minecraft:black_concrete
fill 0 111 625 0 116 625 minecraft:black_concrete
fill 0 111 628 0 117 628 minecraft:black_concrete
fill 0 111 644 0 112 644 minecraft:black_concrete
fill 4 111 604 4 117 604 minecraft:black_concrete
fill 14 111 646 14 114 646 minecraft:black_concrete
fill 18 111 646 18 125 646 minecraft:black_concrete
fill 20 111 604 20 117 604 minecraft:black_concrete
fill 21 111 646 21 124 646 minecraft:black_concrete
fill 30 111 646 30 112 646 minecraft:black_concrete
fill 36 111 604 36 114 604 minecraft:black_concrete
fill 42 111 614 42 117 614 minecraft:black_concrete
fill 42 111 630 42 117 630 minecraft:black_concrete
setblock 42 111 635 minecraft:white_concrete
setblock 3 112 607 minecraft:light[level=14]
setblock 3 112 615 minecraft:light[level=14]
setblock 3 112 623 minecraft:light[level=14]
setblock 3 112 631 minecraft:light[level=14]
setblock 3 112 639 minecraft:light[level=14]
setblock 11 112 607 minecraft:light[level=14]
setblock 11 112 615 minecraft:light[level=14]
setblock 11 112 623 minecraft:light[level=14]
setblock 11 112 631 minecraft:light[level=14]
setblock 11 112 639 minecraft:light[level=14]
setblock 19 112 607 minecraft:light[level=14]
setblock 19 112 615 minecraft:light[level=14]
setblock 19 112 623 minecraft:light[level=14]
setblock 19 112 631 minecraft:light[level=14]
setblock 19 112 639 minecraft:light[level=14]
setblock 27 112 607 minecraft:light[level=14]
setblock 27 112 615 minecraft:light[level=14]
setblock 27 112 623 minecraft:light[level=14]
setblock 27 112 631 minecraft:light[level=14]
setblock 27 112 639 minecraft:light[level=14]
setblock 35 112 607 minecraft:light[level=14]
setblock 35 112 615 minecraft:light[level=14]
setblock 35 112 623 minecraft:light[level=14]
setblock 35 112 631 minecraft:light[level=14]
setblock 35 112 639 minecraft:light[level=14]
fill 42 112 631 42 117 631 minecraft:black_concrete
setblock 42 112 632 minecraft:glowstone
fill 42 112 633 42 114 633 minecraft:black_concrete
setblock 42 112 634 minecraft:glowstone
fill 42 112 635 42 113 635 minecraft:black_concrete
setblock 0 113 638 minecraft:glowstone
setblock 0 113 644 minecraft:diamond_block
setblock 3 113 604 minecraft:diamond_block
setblock 5 113 604 minecraft:glowstone
setblock 30 113 646 minecraft:white_concrete
fill 42 113 632 42 125 632 minecraft:black_concrete
fill 42 113 634 42 125 634 minecraft:black_concrete
fill 0 114 638 0 124 638 minecraft:black_concrete
fill 0 114 644 0 117 644 minecraft:black_concrete
fill 3 114 604 3 128 604 minecraft:black_concrete
fill 5 114 604 5 128 604 minecraft:black_concrete
fill 30 114 646 30 117 646 minecraft:black_concrete
setblock 37 114 604 minecraft:diamond_block
setblock 42 114 635 minecraft:glowstone
setblock 14 115 646 minecraft:glowstone
setblock 36 115 604 minecraft:white_concrete
fill 37 115 604 37 128 604 minecraft:black_concrete
setblock 42 115 633 minecraft:white_concrete
fill 42 115 635 42 128 635 minecraft:black_concrete
setblock 0 116 612 minecraft:diamond_block
fill 14 116 646 14 117 646 minecraft:black_concrete
fill 36 116 604 36 117 604 minecraft:black_concrete
setblock 42 116 625 minecraft:glowstone
fill 42 116 633 42 128 633 minecraft:black_concrete
setblock 0 117 612 minecraft:black_concrete
setblock 0 117 625 minecraft:white_concrete
fill 42 117 625 42 126 625 minecraft:black_concrete
fill 42 117 640 42 126 640 minecraft:black_concrete
setblock 42 117 641 minecraft:white_concrete
fill 0 118 612 0 119 612 minecraft:moss_block
fill 0 118 625 0 121 625 minecraft:black_concrete
fill 0 118 628 0 119 628 minecraft:moss_block
fill 0 118 644 0 119 644 minecraft:moss_block
fill 4 118 604 4 119 604 minecraft:moss_block
fill 14 118 646 14 119 646 minecraft:moss_block
fill 20 118 604 20 119 604 minecraft:moss_block
fill 30 118 646 30 119 646 minecraft:moss_block
fill 36 118 604 36 119 604 minecraft:moss_block
fill 42 118 614 42 119 614 minecraft:moss_block
fill 42 118 630 42 119 630 minecraft:moss_block
setblock 42 118 631 minecraft:diamond_block
fill 42 118 641 42 124 641 minecraft:black_concrete
setblock 0 119 639 minecraft:white_concrete
fill 42 119 631 42 128 631 minecraft:black_concrete
fill 0 120 612 0 124 612 minecraft:black_concrete
setblock 0 120 615 minecraft:white_concrete
fill 0 120 628 0 126 628 minecraft:black_concrete
fill 0 120 639 0 128 639 minecraft:black_concrete
fill 0 120 644 0 126 644 minecraft:black_concrete
setblock 3 120 607 minecraft:light[level=14]
setblock 3 120 615 minecraft:light[level=14]
setblock 3 120 623 minecraft:light[level=14]
setblock 3 120 631 minecraft:light[level=14]
setblock 3 120 639 minecraft:light[level=14]
fill 4 120 604 4 124 604 minecraft:black_concrete
setblock 11 120 607 minecraft:light[level=14]
setblock 11 120 615 minecraft:light[level=14]
setblock 11 120 623 minecraft:light[level=14]
setblock 11 120 631 minecraft:light[level=14]
setblock 11 120 639 minecraft:light[level=14]
fill 12 120 624 12 121 624 minecraft:gold_block
fill 14 120 646 14 126 646 minecraft:black_concrete
setblock 19 120 607 minecraft:light[level=14]
setblock 19 120 615 minecraft:light[level=14]
setblock 19 120 623 minecraft:light[level=14]
setblock 19 120 631 minecraft:light[level=14]
setblock 19 120 639 minecraft:light[level=14]
fill 20 120 604 20 126 604 minecraft:black_concrete
setblock 27 120 607 minecraft:light[level=14]
setblock 27 120 615 minecraft:light[level=14]
setblock 27 120 623 minecraft:light[level=14]
setblock 27 120 631 minecraft:light[level=14]
setblock 27 120 639 minecraft:light[level=14]
fill 30 120 646 30 126 646 minecraft:black_concrete
setblock 35 120 607 minecraft:light[level=14]
setblock 35 120 615 minecraft:light[level=14]
setblock 35 120 623 minecraft:light[level=14]
setblock 35 120 631 minecraft:light[level=14]
setblock 35 120 639 minecraft:light[level=14]
fill 36 120 604 36 126 604 minecraft:black_concrete
setblock 42 120 614 minecraft:black_concrete
fill 42 120 630 42 126 630 minecraft:black_concrete
setblock 0 121 614 minecraft:glowstone
fill 0 121 615 0 124 615 minecraft:black_concrete
setblock 0 121 623 minecraft:glowstone
setblock 42 121 610 minecraft:glowstone
setblock 42 121 614 minecraft:glowstone
fill 0 122 614 0 124 614 minecraft:black_concrete
fill 0 122 623 0 128 623 minecraft:black_concrete
setblock 0 122 625 minecraft:diamond_block
setblock 15 122 646 minecraft:diamond_block
fill 42 122 610 42 125 610 minecraft:black_concrete
fill 42 122 614 42 126 614 minecraft:black_concrete
setblock 42 122 645 minecraft:diamond_block
fill 0 123 625 0 124 625 minecraft:black_concrete
fill 15 123 646 15 129 646 minecraft:black_concrete
setblock 23 123 646 minecraft:glowstone
fill 42 123 645 42 128 645 minecraft:black_concrete
setblock 13 124 646 minecraft:white_concrete
fill 23 124 646 23 128 646 minecraft:black_concrete
setblock 42 124 623 minecraft:white_concrete
fill 0 125 611 0 125 612 minecraft:blue_concrete
fill 0 125 614 0 125 615 minecraft:blue_concrete
setblock 0 125 625 minecraft:blue_concrete
setblock 0 125 634 minecraft:blue_concrete
fill 0 125 636 0 125 638 minecraft:blue_concrete
setblock 4 125 604 minecraft:blue_concrete
setblock 5 125 646 minecraft:blue_concrete
setblock 6 125 646 minecraft:glowstone
setblock 7 125 604 minecraft:blue_concrete
setblock 7 125 646 minecraft:blue_concrete
fill 13 125 646 13 128 646 minecraft:black_concrete
fill 20 125 646 21 125 646 minecraft:blue_concrete
fill 24 125 646 24 126 646 minecraft:blue_concrete
setblock 26 125 604 minecraft:blue_concrete
setblock 36 125 646 minecraft:blue_concrete
setblock 42 125 608 minecraft:blue_concrete
fill 42 125 623 42 128 623 minecraft:black_concrete
setblock 42 125 627 minecraft:diamond_block
setblock 42 125 629 minecraft:blue_concrete
setblock 42 125 636 minecraft:blue_concrete
setblock 42 125 637 minecraft:black_concrete
setblock 42 125 641 minecraft:glowstone
setblock 42 125 644 minecraft:blue_concrete
setblock 42 125 646 minecraft:blue_concrete
setblock 0 126 610 minecraft:blue_concrete
fill 0 126 611 0 128 611 minecraft:black_concrete
setblock 0 126 612 minecraft:blue_concrete
fill 0 126 614 0 128 615 minecraft:black_concrete
fill 0 126 617 0 126 618 minecraft:blue_concrete
setblock 0 126 624 minecraft:blue_concrete
fill 0 126 625 0 128 625 minecraft:black_concrete
setblock 0 126 631 minecraft:blue_concrete
fill 0 126 632 0 128 632 minecraft:black_concrete
setblock 0 126 634 minecraft:black_concrete
fill 0 126 636 0 128 637 minecraft:black_concrete
setblock 0 126 638 minecraft:blue_concrete
setblock 4 126 604 minecraft:black_concrete
setblock 4 126 646 minecraft:blue_concrete
fill 5 126 646 7 126 646 minecraft:black_concrete
fill 7 126 604 7 129 604 minecraft:black_concrete
setblock 11 126 604 minecraft:blue_concrete
setblock 18 126 646 minecraft:blue_concrete
fill 20 126 646 21 128 646 minecraft:black_concrete
fill 26 126 604 26 128 604 minecraft:black_concrete
setblock 27 126 604 minecraft:white_concrete
setblock 34 126 646 minecraft:blue_concrete
setblock 36 126 646 minecraft:black_concrete
setblock 41 126 604 minecraft:blue_concrete
fill 42 126 608 42 128 608 minecraft:black_concrete
fill 42 126 610 42 127 610 minecraft:blue_concrete
setblock 42 126 613 minecraft:blue_concrete
setblock 42 126 622 minecraft:blue_concrete
fill 42 126 627 42 129 627 minecraft:black_concrete
setblock 42 126 629 minecraft:black_concrete
setblock 42 126 632 minecraft:blue_concrete
setblock 42 126 634 minecraft:blue_concrete
fill 42 126 636 42 128 636 minecraft:black_concrete
setblock 42 126 637 minecraft:diamond_block
fill 42 126 641 42 128 641 minecraft:black_concrete
fill 42 126 644 42 128 644 minecraft:black_concrete
setblock 42 126 646 minecraft:black_concrete
fill 0 127 610 0 128 610 minecraft:black_concrete
fill 0 127 612 0 128 612 minecraft:moss_block
setblock 0 127 613 minecraft:blue_concrete
fill 0 127 617 0 128 618 minecraft:black_concrete
setblock 0 127 620 minecraft:blue_concrete
fill 0 127 624 0 128 624 minecraft:black_concrete
fill 0 127 628 0 128 628 minecraft:moss_block
fill 0 127 631 0 128 631 minecraft:black_concrete
setblock 0 127 634 minecraft:blue_concrete
fill 0 127 638 0 128 638 minecraft:black_concrete
fill 0 127 644 0 128 644 minecraft:moss_block
setblock 2 127 604 minecraft:blue_concrete
fill 4 127 604 4 128 604 minecraft:moss_block
fill 4 127 646 4 128 646 minecraft:black_concrete
setblock 5 127 646 minecraft:blue_concrete
fill 6 127 646 6 128 646 minecraft:black_concrete
setblock 7 127 646 minecraft:blue_concrete
fill 10 127 646 11 127 646 minecraft:blue_concrete
fill 11 127 604 11 128 604 minecraft:black_concrete
setblock 12 127 604 minecraft:blue_concrete
fill 14 127 646 14 128 646 minecraft:moss_block
fill 18 127 646 18 128 646 minecraft:black_concrete
fill 20 127 604 20 128 604 minecraft:moss_block
fill 24 127 646 24 128 646 minecraft:black_concrete
fill 27 127 604 27 128 604 minecraft:black_concrete
setblock 30 127 604 minecraft:white_concrete
fill 30 127 646 30 128 646 minecraft:moss_block
fill 34 127 646 34 128 646 minecraft:black_concrete
fill 35 127 646 36 127 646 minecraft:blue_concrete
fill 36 127 604 36 128 604 minecraft:moss_block
setblock 37 127 646 minecraft:diamond_block
fill 41 127 604 41 128 604 minecraft:black_concrete
setblock 42 127 604 minecraft:blue_concrete
fill 42 127 605 42 128 606 minecraft:black_concrete
fill 42 127 613 42 128 613 minecraft:black_concrete
fill 42 127 614 42 128 614 minecraft:moss_block
setblock 42 127 616 minecraft:blue_concrete
fill 42 127 622 42 129 622 minecraft:black_concrete
setblock 42 127 625 minecraft:blue_concrete
setblock 42 127 629 minecraft:blue_concrete
fill 42 127 630 42 128 630 minecraft:moss_block
fill 42 127 632 42 128 632 minecraft:black_concrete
fill 42 127 634 42 128 634 minecraft:black_concrete
fill 42 127 637 42 128 637 minecraft:black_concrete
setblock 42 127 638 minecraft:blue_concrete
setblock 42 127 640 minecraft:blue_concrete
setblock 42 127 646 minecraft:blue_concrete
setblock 0 128 608 minecraft:glowstone
setblock 0 128 609 minecraft:black_concrete
setblock 0 128 613 minecraft:black_concrete
setblock 0 128 620 minecraft:black_concrete
setblock 0 128 634 minecraft:black_concrete
setblock 2 128 604 minecraft:black_concrete
setblock 3 128 607 minecraft:light[level=14]
setblock 3 128 615 minecraft:light[level=14]
setblock 3 128 623 minecraft:light[level=14]
setblock 3 128 631 minecraft:light[level=14]
setblock 3 128 639 minecraft:light[level=14]
setblock 5 128 646 minecraft:black_concrete
setblock 7 128 646 minecraft:black_concrete
fill 10 128 646 11 128 646 minecraft:black_concrete
setblock 11 128 607 minecraft:light[level=14]
setblock 11 128 615 minecraft:light[level=14]
setblock 11 128 623 minecraft:light[level=14]
setblock 11 128 631 minecraft:light[level=14]
setblock 11 128 639 minecraft:light[level=14]
setblock 12 128 604 minecraft:black_concrete
setblock 19 128 607 minecraft:light[level=14]
setblock 19 128 615 minecraft:light[level=14]
setblock 19 128 623 minecraft:light[level=14]
setblock 19 128 631 minecraft:light[level=14]
setblock 19 128 639 minecraft:light[level=14]
setblock 27 128 607 minecraft:light[level=14]
setblock 27 128 615 minecraft:light[level=14]
setblock 27 128 623 minecraft:light[level=14]
setblock 27 128 631 minecraft:light[level=14]
setblock 27 128 639 minecraft:light[level=14]
setblock 30 128 604 minecraft:black_concrete
setblock 35 128 607 minecraft:light[level=14]
setblock 35 128 615 minecraft:light[level=14]
setblock 35 128 623 minecraft:light[level=14]
setblock 35 128 631 minecraft:light[level=14]
setblock 35 128 639 minecraft:light[level=14]
fill 35 128 646 37 128 646 minecraft:black_concrete
setblock 42 128 604 minecraft:black_concrete
setblock 42 128 610 minecraft:black_concrete
setblock 42 128 616 minecraft:black_concrete
setblock 42 128 620 minecraft:diamond_block
setblock 42 128 625 minecraft:black_concrete
setblock 42 128 629 minecraft:black_concrete
setblock 42 128 638 minecraft:black_concrete
setblock 42 128 640 minecraft:black_concrete
fill 42 128 646 42 129 646 minecraft:black_concrete
fill 0 129 604 0 129 636 minecraft:blue_concrete
setblock 0 129 637 minecraft:black_concrete
fill 0 129 638 0 209 639 minecraft:blue_concrete
fill 0 129 641 0 129 646 minecraft:blue_concrete
fill 1 129 604 6 145 604 minecraft:blue_concrete
fill 1 129 646 10 129 646 minecraft:blue_concrete
fill 9 129 604 22 129 604 minecraft:blue_concrete
setblock 11 129 646 minecraft:black_concrete
fill 12 129 646 14 129 646 minecraft:blue_concrete
fill 16 129 646 25 130 646 minecraft:blue_concrete
fill 24 129 604 38 129 604 minecraft:blue_concrete
fill 26 129 618 26 130 618 minecraft:raw_iron_block
setblock 26 129 646 minecraft:glowstone
fill 27 129 646 34 130 646 minecraft:blue_concrete
setblock 35 129 646 minecraft:black_concrete
fill 36 129 646 41 129 646 minecraft:blue_concrete
fill 40 129 604 42 137 604 minecraft:blue_concrete
fill 42 129 605 42 129 619 minecraft:blue_concrete
setblock 42 129 620 minecraft:black_concrete
fill 42 129 623 42 145 626 minecraft:blue_concrete
fill 42 129 628 42 129 638 minecraft:blue_concrete
fill 42 129 640 42 131 645 minecraft:blue_concrete
fill 0 130 604 0 136 609 minecraft:blue_concrete
fill 0 130 610 0 131 610 minecraft:black_concrete
fill 0 130 611 0 130 627 minecraft:blue_concrete
setblock 0 130 628 minecraft:black_concrete
fill 0 130 629 0 130 637 minecraft:blue_concrete
fill 0 130 640 0 159 640 minecraft:blue_concrete
setblock 0 130 641 minecraft:black_concrete
fill 0 130 642 0 130 646 minecraft:blue_concrete
fill 1 130 646 3 130 646 minecraft:blue_concrete
setblock 4 130 646 minecraft:black_concrete
fill 5 130 646 8 130 646 minecraft:blue_concrete
fill 7 130 604 7 218 604 minecraft:blue_concrete
fill 9 130 604 10 150 604 minecraft:blue_concrete
setblock 9 130 646 minecraft:black_concrete
fill 10 130 646 12 137 646 minecraft:blue_concrete
setblock 11 130 604 minecraft:black_concrete
fill 12 130 604 16 134 604 minecraft:blue_concrete
setblock 13 130 646 minecraft:diamond_block
setblock 14 130 646 minecraft:blue_concrete
setblock 15 130 646 minecraft:glowstone
setblock 17 130 604 minecraft:black_concrete
fill 18 130 604 24 130 604 minecraft:blue_concrete
setblock 25 130 604 minecraft:black_concrete
fill 26 130 604 29 140 604 minecraft:blue_concrete
fill 26 130 646 26 216 646 minecraft:blue_concrete
setblock 30 130 604 minecraft:diamond_block
setblock 31 130 604 minecraft:black_concrete
fill 32 130 604 32 218 604 minecraft:blue_concrete
setblock 33 130 604 minecraft:white_concrete
fill 34 130 604 39 130 604 minecraft:blue_concrete
fill 35 130 646 36 135 646 minecraft:blue_concrete
setblock 37 130 646 minecraft:black_concrete
fill 38 130 646 42 133 646 minecraft:blue_concrete
fill 42 130 605 42 130 612 minecraft:blue_concrete
setblock 42 130 613 minecraft:black_concrete
fill 42 130 614 42 132 616 minecraft:blue_concrete
setblock 42 130 617 minecraft:white_concrete
fill 42 130 618 42 163 618 minecraft:blue_concrete
setblock 42 130 619 minecraft:black_concrete
fill 42 130 620 42 130 622 minecraft:blue_concrete
fill 42 130 627 42 130 633 minecraft:blue_concrete
setblock 42 130 634 minecraft:black_concrete
fill 42 130 635 42 134 636 minecraft:blue_concrete
fill 42 130 637 42 131 637 minecraft:glowstone
fill 42 130 638 42 213 639 minecraft:blue_concrete
fill 0 131 611 0 138 615 minecraft:blue_concrete
setblock 0 131 616 minecraft:black_concrete
fill 0 131 617 0 136 624 minecraft:blue_concrete
setblock 0 131 625 minecraft:black_concrete
fill 0 131 626 0 203 626 minecraft:blue_concrete
setblock 0 131 627 minecraft:black_concrete
fill 0 131 628 0 140 633 minecraft:blue_concrete
setblock 0 131 634 minecraft:black_concrete
fill 0 131 635 0 157 637 minecraft:blue_concrete
fill 0 131 641 0 172 641 minecraft:blue_concrete
setblock 0 131 642 minecraft:black_concrete
fill 0 131 643 0 145 646 minecraft:blue_concrete
fill 1 131 646 1 201 646 minecraft:blue_concrete
setblock 2 131 646 minecraft:black_concrete
fill 3 131 646 7 155 646 minecraft:blue_concrete
fill 8 131 604 8 153 604 minecraft:blue_concrete
setblock 8 131 646 minecraft:black_concrete
fill 9 131 646 9 155 646 minecraft:blue_concrete
fill 11 131 604 11 216 604 minecraft:blue_concrete
fill 13 131 646 13 146 646 minecraft:blue_concrete
setblock 14 131 646 minecraft:black_concrete
fill 15 131 646 17 136 646 minecraft:blue_concrete
fill 17 131 604 20 145 604 minecraft:blue_concrete
setblock 18 131 646 minecraft:black_concrete
fill 19 131 646 25 150 646 minecraft:blue_concrete
setblock 21 131 604 minecraft:black_concrete
fill 22 131 604 25 131 604 minecraft:blue_concrete
fill 27 131 634 29 132 634 minecraft:moss_block
setblock 27 131 646 minecraft:black_concrete
fill 28 131 635 28 132 635 minecraft:moss_block
fill 28 131 646 30 145 646 minecraft:blue_concrete
fill 30 131 604 31 215 604 minecraft:blue_concrete
setblock 31 131 646 minecraft:black_concrete
fill 32 131 646 34 156 646 minecraft:blue_concrete
fill 33 131 604 36 145 604 minecraft:blue_concrete
fill 37 131 604 38 131 604 minecraft:black_concrete
fill 37 131 646 37 137 646 minecraft:blue_concrete
fill 39 131 604 39 144 604 minecraft:blue_concrete
setblock 42 131 605 minecraft:diamond_block
fill 42 131 606 42 133 613 minecraft:blue_concrete
fill 42 131 617 42 215 617 minecraft:blue_concrete
fill 42 131 619 42 218 620 minecraft:blue_concrete
setblock 42 131 621 minecraft:black_concrete
fill 42 131 622 42 202 622 minecraft:blue_concrete
setblock 42 131 627 minecraft:black_concrete
fill 42 131 628 42 133 634 minecraft:blue_concrete
fill 0 132 610 0 211 610 minecraft:blue_concrete
fill 0 132 616 0 145 616 minecraft:blue_concrete
fill 0 132 625 0 134 625 minecraft:blue_concrete
fill 0 132 627 0 218 627 minecraft:blue_concrete
fill 0 132 634 0 218 634 minecraft:blue_concrete
fill 0 132 642 0 136 642 minecraft:blue_concrete
fill 2 132 646 2 141 646 minecraft:blue_concrete
fill 8 132 646 8 150 646 minecraft:blue_concrete
fill 14 132 646 14 145 646 minecraft:blue_concrete
fill 18 132 646 18 218 646 minecraft:blue_concrete
fill 21 132 604 22 148 604 minecraft:blue_concrete
setblock 23 132 604 minecraft:white_concrete
fill 24 132 604 25 145 604 minecraft:blue_concrete
fill 27 132 646 27 170 646 minecraft:blue_concrete
fill 31 132 646 31 219 646 minecraft:blue_concrete
fill 37 132 604 38 132 604 minecraft:blue_concrete
fill 42 132 605 42 218 605 minecraft:blue_concrete
setblock 42 132 621 minecraft:white_concrete
fill 42 132 627 42 218 627 minecraft:blue_concrete
fill 42 132 637 42 218 637 minecraft:blue_concrete
fill 42 132 640 42 218 640 minecraft:blue_concrete
setblock 42 132 641 minecraft:diamond_block
fill 42 132 642 42 140 645 minecraft:blue_concrete
fill 10 133 612 11 134 613 minecraft:stone
fill 23 133 604 23 192 604 minecraft:blue_concrete
fill 37 133 604 37 218 604 minecraft:blue_concrete
setblock 38 133 604 minecraft:glowstone
setblock 42 133 614 minecraft:white_concrete
fill 42 133 615 42 145 616 minecraft:blue_concrete
fill 42 133 621 42 147 621 minecraft:blue_concrete
fill 42 133 641 42 215 641 minecraft:blue_concrete
fill 38 134 604 38 181 604 minecraft:blue_concrete
fill 38 134 646 39 209 646 minecraft:blue_concrete
setblock 40 134 646 minecraft:white_concrete
fill 41 134 646 42 156 646 minecraft:blue_concrete
fill 42 134 606 42 134 612 minecraft:blue_concrete
setblock 42 134 613 minecraft:glowstone
fill 42 134 614 42 145 614 minecraft:blue_concrete
fill 42 134 628 42 146 628 minecraft:blue_concrete
setblock 42 134 629 minecraft:glowstone
fill 42 134 630 42 145 634 minecraft:blue_concrete
setblock 0 135 625 minecraft:diamond_block
fill 12 135 604 13 140 604 minecraft:blue_concrete
setblock 14 135 604 minecraft:glowstone
fill 15 135 604 16 218 604 minecraft:blue_concrete
fill 40 135 646 40 171 646 minecraft:blue_concrete
fill 42 135 606 42 145 606 minecraft:blue_concrete
setblock 42 135 607 minecraft:white_concrete
fill 42 135 608 42 142 613 minecraft:blue_concrete
fill 42 135 629 42 172 629 minecraft:blue_concrete
fill 42 135 635 42 189 635 minecraft:blue_concrete
setblock 42 135 636 minecraft:glowstone
fill 0 136 625 0 167 625 minecraft:blue_concrete
setblock 3 136 607 minecraft:light[level=14]
setblock 3 136 615 minecraft:light[level=14]
setblock 3 136 623 minecraft:light[level=14]
setblock 3 136 631 minecraft:light[level=14]
setblock 3 136 639 minecraft:light[level=14]
setblock 11 136 607 minecraft:light[level=14]
setblock 11 136 615 minecraft:light[level=14]
setblock 11 136 623 minecraft:light[level=14]
setblock 11 136 631 minecraft:light[level=14]
setblock 11 136 639 minecraft:light[level=14]
fill 14 136 604 14 218 604 minecraft:blue_concrete
setblock 19 136 607 minecraft:light[level=14]
setblock 19 136 615 minecraft:light[level=14]
setblock 19 136 623 minecraft:light[level=14]
setblock 19 136 631 minecraft:light[level=14]
setblock 19 136 639 minecraft:light[level=14]
setblock 27 136 607 minecraft:light[level=14]
setblock 27 136 615 minecraft:light[level=14]
setblock 27 136 623 minecraft:light[level=14]
setblock 27 136 631 minecraft:light[level=14]
setblock 27 136 639 minecraft:light[level=14]
setblock 35 136 607 minecraft:light[level=14]
setblock 35 136 615 minecraft:light[level=14]
setblock 35 136 623 minecraft:light[level=14]
setblock 35 136 631 minecraft:light[level=14]
setblock 35 136 639 minecraft:light[level=14]
setblock 35 136 646 minecraft:diamond_block
fill 36 136 646 36 192 646 minecraft:blue_concrete
fill 42 136 607 42 157 607 minecraft:blue_concrete
fill 42 136 636 42 218 636 minecraft:blue_concrete
fill 0 137 604 0 215 605 minecraft:blue_concrete
setblock 0 137 606 minecraft:diamond_block
fill 0 137 607 0 191 609 minecraft:blue_concrete
fill 0 137 617 0 152 617 minecraft:blue_concrete
setblock 0 137 618 minecraft:white_concrete
fill 0 137 619 0 142 624 minecraft:blue_concrete
setblock 0 137 642 minecraft:white_concrete
setblock 15 137 646 minecraft:diamond_block
fill 16 137 646 17 150 646 minecraft:blue_concrete
fill 35 137 646 35 170 646 minecraft:blue_concrete
fill 0 138 606 0 161 606 minecraft:blue_concrete
fill 0 138 618 0 166 618 minecraft:blue_concrete
fill 0 138 642 0 218 642 minecraft:blue_concrete
fill 10 138 646 10 150 646 minecraft:blue_concrete
setblock 11 138 646 minecraft:diamond_block
fill 12 138 646 12 145 646 minecraft:blue_concrete
fill 15 138 646 15 143 646 minecraft:blue_concrete
setblock 37 138 646 minecraft:white_concrete
fill 40 138 604 40 140 604 minecraft:blue_concrete
setblock 41 138 604 minecraft:white_concrete
fill 42 138 604 42 219 604 minecraft:blue_concrete
fill 0 139 611 0 140 614 minecraft:blue_concrete
setblock 0 139 615 minecraft:glowstone
fill 11 139 646 11 160 646 minecraft:blue_concrete
fill 37 139 646 37 214 646 minecraft:blue_concrete
setblock 41 139 604 minecraft:blue_concrete
fill 0 140 615 0 164 615 minecraft:blue_concrete
fill 18 140 622 20 140 624 minecraft:redstone_block
fill 18 140 628 20 140 630 minecraft:redstone_block
fill 26 140 622 28 140 624 minecraft:redstone_block
fill 26 140 628 28 140 630 minecraft:redstone_block
setblock 41 140 604 minecraft:glowstone
fill 0 141 611 0 163 611 minecraft:blue_concrete
setblock 0 141 612 minecraft:white_concrete
fill 0 141 613 0 159 614 minecraft:blue_concrete
fill 0 141 628 0 145 632 minecraft:blue_concrete
setblock 0 141 633 minecraft:white_concrete
fill 1 141 605 1 141 607 minecraft:stone
fill 1 141 608 1 141 610 minecraft:deepslate
fill 1 141 611 1 141 613 minecraft:stone
fill 1 141 614 1 141 616 minecraft:deepslate
fill 1 141 617 1 141 619 minecraft:stone
fill 1 141 620 1 141 622 minecraft:deepslate
fill 1 141 623 1 141 625 minecraft:stone
fill 1 141 626 1 141 628 minecraft:deepslate
fill 1 141 629 1 141 631 minecraft:stone
fill 1 141 632 1 141 634 minecraft:deepslate
fill 1 141 635 1 141 637 minecraft:stone
fill 1 141 638 1 141 640 minecraft:deepslate
fill 1 141 641 1 141 643 minecraft:stone
fill 1 141 644 1 141 645 minecraft:deepslate
fill 2 141 605 4 141 607 minecraft:deepslate
fill 2 141 608 4 141 610 minecraft:stone
fill 2 141 611 4 141 613 minecraft:deepslate
fill 2 141 614 4 141 616 minecraft:stone
fill 2 141 617 4 141 619 minecraft:deepslate
fill 2 141 620 4 141 622 minecraft:stone
fill 2 141 623 4 141 625 minecraft:deepslate
fill 2 141 626 4 141 628 minecraft:stone
fill 2 141 629 4 141 631 minecraft:deepslate
fill 2 141 632 4 141 634 minecraft:stone
fill 2 141 635 4 141 637 minecraft:deepslate
fill 2 141 638 4 141 640 minecraft:stone
fill 2 141 641 4 141 643 minecraft:deepslate
fill 2 141 644 4 141 645 minecraft:stone
fill 5 141 605 7 141 607 minecraft:stone
fill 5 141 608 7 141 610 minecraft:deepslate
fill 5 141 611 7 141 613 minecraft:stone
fill 5 141 614 7 141 616 minecraft:deepslate
fill 5 141 617 7 141 619 minecraft:stone
fill 5 141 620 7 141 622 minecraft:deepslate
fill 5 141 623 7 141 625 minecraft:stone
fill 5 141 626 7 141 628 minecraft:deepslate
fill 5 141 629 7 141 631 minecraft:stone
fill 5 141 632 7 141 634 minecraft:deepslate
fill 5 141 635 7 141 637 minecraft:stone
fill 5 141 638 7 141 640 minecraft:deepslate
fill 5 141 641 7 141 643 minecraft:stone
fill 5 141 644 7 141 645 minecraft:deepslate
fill 8 141 605 10 141 607 minecraft:deepslate
fill 8 141 608 10 141 610 minecraft:stone
fill 8 141 611 10 141 613 minecraft:deepslate
fill 8 141 614 10 141 616 minecraft:stone
fill 8 141 617 10 141 619 minecraft:deepslate
fill 8 141 620 10 141 622 minecraft:stone
fill 8 141 623 10 141 625 minecraft:deepslate
fill 8 141 626 10 141 628 minecraft:stone
fill 8 141 629 10 141 631 minecraft:deepslate
fill 8 141 632 10 141 634 minecraft:stone
fill 8 141 635 10 141 637 minecraft:deepslate
fill 8 141 638 10 141 640 minecraft:stone
fill 8 141 641 10 141 643 minecraft:deepslate
fill 8 141 644 10 141 645 minecraft:stone
fill 11 141 605 13 141 607 minecraft:stone
fill 11 141 608 13 141 610 minecraft:deepslate
fill 11 141 611 13 141 613 minecraft:stone
fill 11 141 614 13 141 616 minecraft:deepslate
fill 11 141 617 13 141 619 minecraft:stone
fill 11 141 620 13 141 622 minecraft:deepslate
fill 11 141 623 13 141 625 minecraft:stone
fill 11 141 626 13 141 628 minecraft:deepslate
fill 11 141 629 13 141 631 minecraft:stone
fill 11 141 632 13 141 634 minecraft:deepslate
fill 11 141 635 13 141 637 minecraft:stone
fill 11 141 638 13 141 640 minecraft:deepslate
fill 11 141 641 13 141 643 minecraft:stone
fill 11 141 644 13 141 645 minecraft:deepslate
fill 12 141 604 12 202 604 minecraft:blue_concrete
setblock 13 141 604 minecraft:white_concrete
fill 14 141 605 16 141 607 minecraft:deepslate
fill 14 141 608 16 141 610 minecraft:stone
fill 14 141 611 16 141 613 minecraft:deepslate
fill 14 141 614 16 141 616 minecraft:stone
fill 14 141 617 16 141 619 minecraft:deepslate
fill 14 141 620 16 141 622 minecraft:stone
fill 14 141 623 16 141 625 minecraft:deepslate
fill 14 141 626 16 141 628 minecraft:stone
fill 14 141 629 16 141 631 minecraft:deepslate
fill 14 141 632 16 141 634 minecraft:stone
fill 14 141 635 16 141 637 minecraft:deepslate
fill 14 141 638 16 141 640 minecraft:stone
fill 14 141 641 16 141 643 minecraft:deepslate
fill 14 141 644 16 141 645 minecraft:stone
fill 17 141 605 19 141 607 minecraft:stone
fill 17 141 608 19 141 610 minecraft:deepslate
fill 17 141 611 19 141 613 minecraft:stone
fill 17 141 614 19 141 616 minecraft:deepslate
fill 17 141 617 19 141 619 minecraft:stone
fill 17 141 620 17 141 622 minecraft:deepslate
fill 17 141 623 17 141 625 minecraft:stone
fill 17 141 626 17 141 628 minecraft:deepslate
fill 17 141 629 17 141 631 minecraft:stone
fill 17 141 632 19 141 634 minecraft:deepslate
fill 17 141 635 19 141 637 minecraft:stone
fill 17 141 638 19 141 640 minecraft:deepslate
fill 17 141 641 19 141 643 minecraft:stone
fill 17 141 644 19 141 645 minecraft:deepslate
fill 18 141 620 19 141 621 minecraft:deepslate
fill 18 141 625 19 141 625 minecraft:stone
fill 18 141 626 19 141 627 minecraft:deepslate
fill 18 141 631 19 141 631 minecraft:stone
fill 20 141 605 22 141 607 minecraft:deepslate
fill 20 141 608 22 141 610 minecraft:stone
fill 20 141 611 22 141 613 minecraft:deepslate
fill 20 141 614 22 141 616 minecraft:stone
fill 20 141 617 22 141 619 minecraft:deepslate
fill 20 141 620 22 141 621 minecraft:stone
fill 20 141 625 21 141 625 minecraft:deepslate
fill 20 141 626 21 141 627 minecraft:stone
fill 20 141 631 22 141 631 minecraft:deepslate
fill 20 141 632 22 141 634 minecraft:stone
fill 20 141 635 22 141 637 minecraft:deepslate
fill 20 141 638 22 141 640 minecraft:stone
fill 20 141 641 22 141 643 minecraft:deepslate
fill 20 141 644 22 141 645 minecraft:stone
fill 21 141 622 22 141 622 minecraft:stone
fill 21 141 623 22 141 624 minecraft:deepslate
fill 21 141 628 22 141 628 minecraft:stone
fill 21 141 629 22 141 630 minecraft:deepslate
fill 23 141 605 25 141 607 minecraft:stone
fill 23 141 608 25 141 610 minecraft:deepslate
fill 23 141 611 25 141 613 minecraft:stone
fill 23 141 614 25 141 616 minecraft:deepslate
fill 23 141 617 25 141 619 minecraft:stone
fill 23 141 620 25 141 622 minecraft:deepslate
fill 23 141 623 25 141 624 minecraft:stone
fill 23 141 628 25 141 628 minecraft:deepslate
fill 23 141 629 25 141 631 minecraft:stone
fill 23 141 632 25 141 634 minecraft:deepslate
fill 23 141 635 25 141 637 minecraft:stone
fill 23 141 638 25 141 640 minecraft:deepslate
fill 23 141 641 25 141 643 minecraft:stone
fill 23 141 644 25 141 645 minecraft:deepslate
setblock 25 141 625 minecraft:stone
fill 25 141 626 25 141 627 minecraft:deepslate
setblock 26 141 604 minecraft:glowstone
fill 26 141 605 28 141 607 minecraft:deepslate
fill 26 141 608 28 141 610 minecraft:stone
fill 26 141 611 28 141 613 minecraft:deepslate
fill 26 141 614 28 141 616 minecraft:stone
fill 26 141 617 28 141 619 minecraft:deepslate
fill 26 141 620 28 141 621 minecraft:stone
fill 26 141 625 28 141 625 minecraft:deepslate
fill 26 141 626 28 141 627 minecraft:stone
fill 26 141 631 28 141 631 minecraft:deepslate
fill 26 141 632 28 141 634 minecraft:stone
fill 26 141 635 28 141 637 minecraft:deepslate
fill 26 141 638 28 141 640 minecraft:stone
fill 26 141 641 28 141 643 minecraft:deepslate
fill 26 141 644 28 141 645 minecraft:stone
fill 27 141 604 29 141 604 minecraft:blue_concrete
fill 29 141 605 31 141 607 minecraft:stone
fill 29 141 608 31 141 610 minecraft:deepslate
fill 29 141 611 31 141 613 minecraft:stone
fill 29 141 614 31 141 616 minecraft:deepslate
fill 29 141 617 31 141 619 minecraft:stone
fill 29 141 620 31 141 622 minecraft:deepslate
fill 29 141 623 31 141 625 minecraft:stone
fill 29 141 626 31 141 628 minecraft:deepslate
fill 29 141 629 31 141 631 minecraft:stone
fill 29 141 632 31 141 634 minecraft:deepslate
fill 29 141 635 31 141 637 minecraft:stone
fill 29 141 638 31 141 640 minecraft:deepslate
fill 29 141 641 31 141 643 minecraft:stone
fill 29 141 644 31 141 645 minecraft:deepslate
fill 32 141 605 34 141 607 minecraft:deepslate
fill 32 141 608 34 141 610 minecraft:stone
fill 32 141 611 34 141 613 minecraft:deepslate
fill 32 141 614 34 141 616 minecraft:stone
fill 32 141 617 34 141 619 minecraft:deepslate
fill 32 141 620 34 141 622 minecraft:stone
fill 32 141 623 34 141 625 minecraft:deepslate
fill 32 141 626 34 141 628 minecraft:stone
fill 32 141 629 34 141 631 minecraft:deepslate
fill 32 141 632 34 141 634 minecraft:stone
fill 32 141 635 34 141 637 minecraft:deepslate
fill 32 141 638 34 141 640 minecraft:stone
fill 32 141 641 34 141 643 minecraft:deepslate
fill 32 141 644 34 141 645 minecraft:stone
fill 35 141 605 37 141 607 minecraft:stone
fill 35 141 608 37 141 610 minecraft:deepslate
fill 35 141 611 37 141 613 minecraft:stone
fill 35 141 614 37 141 616 minecraft:deepslate
fill 35 141 617 37 141 619 minecraft:stone
fill 35 141 620 37 141 622 minecraft:deepslate
fill 35 141 623 37 141 625 minecraft:stone
fill 35 141 626 37 141 628 minecraft:deepslate
fill 35 141 629 37 141 631 minecraft:stone
fill 35 141 632 37 141 634 minecraft:deepslate
fill 35 141 635 37 141 637 minecraft:stone
fill 35 141 638 37 141 640 minecraft:deepslate
fill 35 141 641 37 141 643 minecraft:stone
fill 35 141 644 37 141 645 minecraft:deepslate
fill 38 141 605 40 141 607 minecraft:deepslate
fill 38 141 608 40 141 610 minecraft:stone
fill 38 141 611 40 141 613 minecraft:deepslate
fill 38 141 614 40 141 616 minecraft:stone
fill 38 141 617 40 141 619 minecraft:deepslate
fill 38 141 620 40 141 622 minecraft:stone
fill 38 141 623 40 141 625 minecraft:deepslate
fill 38 141 626 40 141 628 minecraft:stone
fill 38 141 629 40 141 631 minecraft:deepslate
fill 38 141 632 40 141 634 minecraft:stone
fill 38 141 635 40 141 637 minecraft:deepslate
fill 38 141 638 40 141 640 minecraft:stone
fill 38 141 641 40 141 643 minecraft:deepslate
fill 38 141 644 40 141 645 minecraft:stone
setblock 40 141 604 minecraft:white_concrete
fill 41 141 604 41 216 604 minecraft:blue_concrete
fill 41 141 605 41 141 607 minecraft:stone
fill 41 141 608 41 141 610 minecraft:deepslate
fill 41 141 611 41 141 613 minecraft:stone
fill 41 141 614 41 141 616 minecraft:deepslate
fill 41 141 617 41 141 619 minecraft:stone
fill 41 141 620 41 141 622 minecraft:deepslate
fill 41 141 623 41 141 625 minecraft:stone
fill 41 141 626 41 141 628 minecraft:deepslate
fill 41 141 629 41 141 631 minecraft:stone
fill 41 141 632 41 141 634 minecraft:deepslate
fill 41 141 635 41 141 637 minecraft:stone
fill 41 141 638 41 141 640 minecraft:deepslate
fill 41 141 641 41 141 643 minecraft:stone
fill 41 141 644 41 141 645 minecraft:deepslate
setblock 42 141 642 minecraft:blue_concrete
setblock 42 141 643 minecraft:diamond_block
fill 42 141 644 42 199 645 minecraft:blue_concrete
fill 0 142 612 0 145 612 minecraft:blue_concrete
fill 0 142 633 0 168 633 minecraft:blue_concrete
fill 1 142 605 41 142 605 minecraft:diamond_block
fill 1 142 606 1 142 607 minecraft:stone
fill 1 142 608 41 142 608 minecraft:diamond_block
fill 1 142 609 1 142 610 minecraft:deepslate
fill 1 142 611 41 142 611 minecraft:diamond_block
fill 1 142 612 1 142 613 minecraft:stone
fill 1 142 614 41 142 614 minecraft:diamond_block
fill 1 142 615 1 142 616 minecraft:deepslate
fill 1 142 617 41 142 617 minecraft:diamond_block
fill 1 142 618 1 142 619 minecraft:stone
fill 1 142 620 41 142 620 minecraft:diamond_block
fill 1 142 621 1 142 622 minecraft:deepslate
fill 1 142 623 16 142 623 minecraft:diamond_block
fill 1 142 624 1 142 625 minecraft:stone
fill 1 142 626 19 142 626 minecraft:diamond_block
fill 1 142 627 1 142 628 minecraft:deepslate
fill 1 142 629 16 142 629 minecraft:diamond_block
fill 1 142 630 1 142 631 minecraft:stone
fill 1 142 632 41 142 632 minecraft:diamond_block
fill 1 142 633 1 142 634 minecraft:deepslate
fill 1 142 635 41 142 635 minecraft:diamond_block
fill 1 142 636 1 142 637 minecraft:stone
fill 1 142 638 41 142 638 minecraft:diamond_block
fill 1 142 639 1 142 640 minecraft:deepslate
fill 1 142 641 41 142 641 minecraft:diamond_block
fill 1 142 642 1 142 643 minecraft:stone
fill 1 142 644 41 142 644 minecraft:diamond_block
setblock 1 142 645 minecraft:deepslate
fill 2 142 606 2 142 607 minecraft:diamond_block
fill 2 142 609 2 142 610 minecraft:diamond_block
fill 2 142 612 2 142 613 minecraft:diamond_block
fill 2 142 615 2 142 616 minecraft:diamond_block
fill 2 142 618 2 142 619 minecraft:diamond_block
fill 2 142 621 2 142 622 minecraft:diamond_block
fill 2 142 624 2 142 625 minecraft:diamond_block
fill 2 142 627 2 142 628 minecraft:diamond_block
fill 2 142 630 2 142 631 minecraft:diamond_block
fill 2 142 633 2 142 634 minecraft:diamond_block
fill 2 142 636 2 142 637 minecraft:diamond_block
fill 2 142 639 2 142 640 minecraft:diamond_block
fill 2 142 642 2 142 643 minecraft:diamond_block
fill 2 142 645 2 142 646 minecraft:diamond_block
fill 3 142 606 4 142 607 minecraft:deepslate
fill 3 142 609 4 142 610 minecraft:stone
fill 3 142 612 4 142 613 minecraft:deepslate
fill 3 142 615 4 142 616 minecraft:stone
fill 3 142 618 4 142 619 minecraft:deepslate
fill 3 142 621 4 142 622 minecraft:stone
fill 3 142 624 4 142 625 minecraft:deepslate
fill 3 142 627 4 142 628 minecraft:stone
fill 3 142 630 4 142 631 minecraft:deepslate
fill 3 142 633 4 142 634 minecraft:stone
fill 3 142 636 4 142 637 minecraft:deepslate
fill 3 142 639 4 142 640 minecraft:stone
fill 3 142 642 4 142 643 minecraft:deepslate
fill 3 142 645 4 142 645 minecraft:stone
fill 5 142 606 5 142 607 minecraft:diamond_block
fill 5 142 609 5 142 610 minecraft:diamond_block
fill 5 142 612 5 142 613 minecraft:diamond_block
fill 5 142 615 5 142 616 minecraft:diamond_block
fill 5 142 618 5 142 619 minecraft:diamond_block
fill 5 142 621 5 142 622 minecraft:diamond_block
fill 5 142 624 5 142 625 minecraft:diamond_block
fill 5 142 627 5 142 628 minecraft:diamond_block
fill 5 142 630 5 142 631 minecraft:diamond_block
fill 5 142 633 5 142 634 minecraft:diamond_block
fill 5 142 636 5 142 637 minecraft:diamond_block
fill 5 142 639 5 142 640 minecraft:diamond_block
fill 5 142 642 5 142 643 minecraft:diamond_block
setblock 5 142 645 minecraft:diamond_block
fill 6 142 606 7 142 607 minecraft:stone
fill 6 142 609 7 142 610 minecraft:deepslate
fill 6 142 612 7 142 613 minecraft:stone
fill 6 142 615 7 142 616 minecraft:deepslate
fill 6 142 618 7 142 619 minecraft:stone
fill 6 142 621 7 142 622 minecraft:deepslate
fill 6 142 624 7 142 625 minecraft:stone
fill 6 142 627 7 142 628 minecraft:deepslate
fill 6 142 630 7 142 631 minecraft:stone
fill 6 142 633 7 142 634 minecraft:deepslate
fill 6 142 636 7 142 637 minecraft:stone
fill 6 142 639 7 142 640 minecraft:deepslate
fill 6 142 642 7 142 643 minecraft:stone
fill 6 142 645 7 142 645 minecraft:deepslate
fill 8 142 606 8 142 607 minecraft:diamond_block
fill 8 142 609 8 142 610 minecraft:diamond_block
fill 8 142 612 8 142 613 minecraft:diamond_block
fill 8 142 615 8 142 616 minecraft:diamond_block
fill 8 142 618 8 142 619 minecraft:diamond_block
fill 8 142 621 8 142 622 minecraft:diamond_block
fill 8 142 624 8 142 625 minecraft:diamond_block
fill 8 142 627 8 142 628 minecraft:diamond_block
fill 8 142 630 8 142 631 minecraft:diamond_block
fill 8 142 633 8 142 634 minecraft:diamond_block
fill 8 142 636 8 142 637 minecraft:diamond_block
fill 8 142 639 8 142 640 minecraft:diamond_block
fill 8 142 642 8 142 643 minecraft:diamond_block
setblock 8 142 645 minecraft:diamond_block
fill 9 142 606 10 142 607 minecraft:deepslate
fill 9 142 609 10 142 610 minecraft:stone
fill 9 142 612 10 142 613 minecraft:deepslate
fill 9 142 615 10 142 616 minecraft:stone
fill 9 142 618 10 142 619 minecraft:deepslate
fill 9 142 621 10 142 622 minecraft:stone
fill 9 142 624 10 142 625 minecraft:deepslate
fill 9 142 627 10 142 628 minecraft:stone
fill 9 142 630 10 142 631 minecraft:deepslate
fill 9 142 633 10 142 634 minecraft:stone
fill 9 142 636 10 142 637 minecraft:deepslate
fill 9 142 639 10 142 640 minecraft:stone
fill 9 142 642 10 142 643 minecraft:deepslate
fill 9 142 645 10 142 645 minecraft:stone
fill 11 142 606 11 142 607 minecraft:diamond_block
fill 11 142 609 11 142 610 minecraft:diamond_block
fill 11 142 612 11 142 613 minecraft:diamond_block
fill 11 142 615 11 142 616 minecraft:diamond_block
fill 11 142 618 11 142 619 minecraft:diamond_block
fill 11 142 621 11 142 622 minecraft:diamond_block
fill 11 142 624 11 142 625 minecraft:diamond_block
fill 11 142 627 11 142 628 minecraft:diamond_block
fill 11 142 630 11 142 631 minecraft:diamond_block
fill 11 142 633 11 142 634 minecraft:diamond_block
fill 11 142 636 11 142 637 minecraft:diamond_block
fill 11 142 639 11 142 640 minecraft:diamond_block
fill 11 142 642 11 142 643 minecraft:diamond_block
setblock 11 142 645 minecraft:diamond_block
fill 12 142 606 13 142 607 minecraft:stone
fill 12 142 609 13 142 610 minecraft:deepslate
fill 12 142 612 13 142 613 minecraft:stone
fill 12 142 615 13 142 616 minecraft:deepslate
fill 12 142 618 13 142 619 minecraft:stone
fill 12 142 621 13 142 622 minecraft:deepslate
fill 12 142 624 13 142 625 minecraft:stone
fill 12 142 627 13 142 628 minecraft:deepslate
fill 12 142 630 13 142 631 minecraft:stone
fill 12 142 633 13 142 634 minecraft:deepslate
fill 12 142 636 13 142 637 minecraft:stone
fill 12 142 639 13 142 640 minecraft:deepslate
fill 12 142 642 13 142 643 minecraft:stone
fill 12 142 645 13 142 645 minecraft:deepslate
fill 13 142 604 13 218 604 minecraft:blue_concrete
fill 14 142 606 14 142 607 minecraft:diamond_block
fill 14 142 609 14 142 610 minecraft:diamond_block
fill 14 142 612 14 142 613 minecraft:diamond_block
fill 14 142 615 14 142 616 minecraft:diamond_block
fill 14 142 618 14 142 619 minecraft:diamond_block
fill 14 142 621 14 142 622 minecraft:diamond_block
fill 14 142 624 14 142 625 minecraft:diamond_block
fill 14 142 627 14 142 628 minecraft:diamond_block
fill 14 142 630 14 142 631 minecraft:diamond_block
fill 14 142 633 14 142 634 minecraft:diamond_block
fill 14 142 636 14 142 637 minecraft:diamond_block
fill 14 142 639 14 142 640 minecraft:diamond_block
fill 14 142 642 14 142 643 minecraft:diamond_block
setblock 14 142 645 minecraft:diamond_block
fill 15 142 606 16 142 607 minecraft:deepslate
fill 15 142 609 16 142 610 minecraft:stone
fill 15 142 612 16 142 613 minecraft:deepslate
fill 15 142 615 16 142 616 minecraft:stone
fill 15 142 618 16 142 619 minecraft:deepslate
fill 15 142 621 16 142 622 minecraft:stone
fill 15 142 624 16 142 625 minecraft:deepslate
fill 15 142 627 16 142 628 minecraft:stone
fill 15 142 630 16 142 631 minecraft:deepslate
fill 15 142 633 16 142 634 minecraft:stone
fill 15 142 636 16 142 637 minecraft:deepslate
fill 15 142 639 16 142 640 minecraft:stone
fill 15 142 642 16 142 643 minecraft:deepslate
fill 15 142 645 16 142 645 minecraft:stone
fill 17 142 606 17 142 607 minecraft:diamond_block
fill 17 142 609 17 142 610 minecraft:diamond_block
fill 17 142 612 17 142 613 minecraft:diamond_block
fill 17 142 615 17 142 616 minecraft:diamond_block
fill 17 142 618 17 142 619 minecraft:diamond_block
fill 17 142 621 17 142 625 minecraft:glowstone
fill 17 142 627 17 142 631 minecraft:glowstone
fill 17 142 633 17 142 634 minecraft:diamond_block
fill 17 142 636 17 142 637 minecraft:diamond_block
fill 17 142 639 17 142 640 minecraft:diamond_block
fill 17 142 642 17 142 643 minecraft:diamond_block
setblock 17 142 645 minecraft:diamond_block
fill 18 142 606 19 142 607 minecraft:stone
fill 18 142 609 19 142 610 minecraft:deepslate
fill 18 142 612 19 142 613 minecraft:stone
fill 18 142 615 19 142 616 minecraft:deepslate
fill 18 142 618 19 142 619 minecraft:stone
fill 18 142 621 21 142 621 minecraft:glowstone
fill 18 142 622 20 142 624 minecraft:stone
fill 18 142 625 19 142 625 minecraft:glowstone
fill 18 142 627 19 142 627 minecraft:glowstone
fill 18 142 628 20 142 630 minecraft:stone
fill 18 142 631 21 142 631 minecraft:glowstone
fill 18 142 633 19 142 634 minecraft:deepslate
fill 18 142 636 19 142 637 minecraft:stone
fill 18 142 639 19 142 640 minecraft:deepslate
fill 18 142 642 19 142 643 minecraft:stone
fill 18 142 645 19 142 645 minecraft:deepslate
fill 20 142 606 20 142 607 minecraft:diamond_block
fill 20 142 609 20 142 610 minecraft:diamond_block
fill 20 142 612 20 142 613 minecraft:diamond_block
fill 20 142 615 20 142 616 minecraft:diamond_block
fill 20 142 618 20 142 619 minecraft:diamond_block
fill 20 142 625 20 142 627 minecraft:red_nether_bricks
fill 20 142 633 20 142 634 minecraft:diamond_block
fill 20 142 636 20 142 637 minecraft:diamond_block
fill 20 142 639 20 142 640 minecraft:diamond_block
fill 20 142 642 20 142 643 minecraft:diamond_block
setblock 20 142 645 minecraft:diamond_block
fill 21 142 606 22 142 607 minecraft:deepslate
fill 21 142 609 22 142 610 minecraft:stone
fill 21 142 612 22 142 613 minecraft:deepslate
fill 21 142 615 22 142 616 minecraft:stone
fill 21 142 618 22 142 619 minecraft:deepslate
fill 21 142 622 21 142 623 minecraft:glowstone
setblock 21 142 624 minecraft:red_nether_bricks
fill 21 142 625 21 142 627 minecraft:shroomlight
setblock 21 142 628 minecraft:red_nether_bricks
fill 21 142 629 21 142 630 minecraft:glowstone
fill 21 142 633 22 142 634 minecraft:stone
fill 21 142 636 22 142 637 minecraft:deepslate
fill 21 142 639 22 142 640 minecraft:stone
fill 21 142 642 22 142 643 minecraft:deepslate
fill 21 142 645 22 142 645 minecraft:stone
fill 22 142 621 22 142 622 minecraft:stone
fill 22 142 623 24 142 623 minecraft:diamond_block
fill 22 142 624 24 142 624 minecraft:shroomlight
fill 22 142 628 24 142 628 minecraft:shroomlight
fill 22 142 629 24 142 629 minecraft:diamond_block
fill 22 142 630 22 142 631 minecraft:deepslate
fill 23 142 606 23 142 607 minecraft:diamond_block
fill 23 142 609 23 142 610 minecraft:diamond_block
fill 23 142 612 23 142 613 minecraft:diamond_block
fill 23 142 615 23 142 616 minecraft:diamond_block
fill 23 142 618 23 142 619 minecraft:diamond_block
fill 23 142 621 23 142 622 minecraft:diamond_block
fill 23 142 630 23 142 631 minecraft:diamond_block
fill 23 142 633 23 142 634 minecraft:diamond_block
fill 23 142 636 23 142 637 minecraft:diamond_block
fill 23 142 639 23 142 640 minecraft:diamond_block
fill 23 142 642 23 142 643 minecraft:diamond_block
setblock 23 142 645 minecraft:diamond_block
fill 24 142 606 25 142 607 minecraft:stone
fill 24 142 609 25 142 610 minecraft:deepslate
fill 24 142 612 25 142 613 minecraft:stone
fill 24 142 615 25 142 616 minecraft:deepslate
fill 24 142 618 25 142 619 minecraft:stone
fill 24 142 621 24 142 622 minecraft:deepslate
fill 24 142 630 24 142 631 minecraft:stone
fill 24 142 633 25 142 634 minecraft:deepslate
fill 24 142 636 25 142 637 minecraft:stone
fill 24 142 639 25 142 640 minecraft:deepslate
fill 24 142 642 25 142 643 minecraft:stone
fill 24 142 645 25 142 645 minecraft:deepslate
fill 25 142 621 25 142 623 minecraft:glowstone
setblock 25 142 624 minecraft:red_nether_bricks
fill 25 142 625 25 142 627 minecraft:shroomlight
setblock 25 142 628 minecraft:red_nether_bricks
fill 25 142 629 25 142 631 minecraft:glowstone
fill 26 142 604 27 145 604 minecraft:blue_concrete
fill 26 142 606 26 142 607 minecraft:diamond_block
fill 26 142 609 26 142 610 minecraft:diamond_block
fill 26 142 612 26 142 613 minecraft:diamond_block
fill 26 142 615 26 142 616 minecraft:diamond_block
fill 26 142 618 26 142 619 minecraft:diamond_block
fill 26 142 621 29 142 621 minecraft:glowstone
fill 26 142 622 28 142 624 minecraft:stone
fill 26 142 625 26 142 627 minecraft:red_nether_bricks
fill 26 142 628 28 142 630 minecraft:stone
fill 26 142 631 29 142 631 minecraft:glowstone
fill 26 142 633 26 142 634 minecraft:diamond_block
fill 26 142 636 26 142 637 minecraft:diamond_block
fill 26 142 639 26 142 640 minecraft:diamond_block
fill 26 142 642 26 142 643 minecraft:diamond_block
setblock 26 142 645 minecraft:diamond_block
fill 27 142 606 28 142 607 minecraft:deepslate
fill 27 142 609 28 142 610 minecraft:stone
fill 27 142 612 28 142 613 minecraft:deepslate
fill 27 142 615 28 142 616 minecraft:stone
fill 27 142 618 28 142 619 minecraft:deepslate
fill 27 142 625 29 142 625 minecraft:glowstone
fill 27 142 626 41 142 626 minecraft:diamond_block
fill 27 142 627 29 142 627 minecraft:glowstone
fill 27 142 633 28 142 634 minecraft:stone
fill 27 142 636 28 142 637 minecraft:deepslate
fill 27 142 639 28 142 640 minecraft:stone
fill 27 142 642 28 142 643 minecraft:deepslate
fill 27 142 645 28 142 645 minecraft:stone
setblock 28 142 604 minecraft:glowstone
fill 29 142 604 29 148 604 minecraft:blue_concrete
fill 29 142 606 29 142 607 minecraft:diamond_block
fill 29 142 609 29 142 610 minecraft:diamond_block
fill 29 142 612 29 142 613 minecraft:diamond_block
fill 29 142 615 29 142 616 minecraft:diamond_block
fill 29 142 618 29 142 619 minecraft:diamond_block
fill 29 142 622 29 142 624 minecraft:glowstone
fill 29 142 628 29 142 630 minecraft:glowstone
fill 29 142 633 29 142 634 minecraft:diamond_block
fill 29 142 636 29 142 637 minecraft:diamond_block
fill 29 142 639 29 142 640 minecraft:diamond_block
fill 29 142 642 29 142 643 minecraft:diamond_block
setblock 29 142 645 minecraft:diamond_block
fill 30 142 606 31 142 607 minecraft:stone
fill 30 142 609 31 142 610 minecraft:deepslate
fill 30 142 612 31 142 613 minecraft:stone
fill 30 142 615 31 142 616 minecraft:deepslate
fill 30 142 618 31 142 619 minecraft:stone
fill 30 142 621 31 142 622 minecraft:deepslate
fill 30 142 623 41 142 623 minecraft:diamond_block
fill 30 142 624 31 142 625 minecraft:stone
fill 30 142 627 31 142 628 minecraft:deepslate
fill 30 142 629 41 142 629 minecraft:diamond_block
fill 30 142 630 31 142 631 minecraft:stone
fill 30 142 633 31 142 634 minecraft:deepslate
fill 30 142 636 31 142 637 minecraft:stone
fill 30 142 639 31 142 640 minecraft:deepslate
fill 30 142 642 31 142 643 minecraft:stone
fill 30 142 645 31 142 645 minecraft:deepslate
fill 32 142 606 32 142 607 minecraft:diamond_block
fill 32 142 609 32 142 610 minecraft:diamond_block
fill 32 142 612 32 142 613 minecraft:diamond_block
fill 32 142 615 32 142 616 minecraft:diamond_block
fill 32 142 618 32 142 619 minecraft:diamond_block
fill 32 142 621 32 142 622 minecraft:diamond_block
fill 32 142 624 32 142 625 minecraft:diamond_block
fill 32 142 627 32 142 628 minecraft:diamond_block
fill 32 142 630 32 142 631 minecraft:diamond_block
fill 32 142 633 32 142 634 minecraft:diamond_block
fill 32 142 636 32 142 637 minecraft:diamond_block
fill 32 142 639 32 142 640 minecraft:diamond_block
fill 32 142 642 32 142 643 minecraft:diamond_block
setblock 32 142 645 minecraft:diamond_block
fill 33 142 606 34 142 607 minecraft:deepslate
fill 33 142 609 34 142 610 minecraft:stone
fill 33 142 612 34 142 613 minecraft:deepslate
fill 33 142 615 34 142 616 minecraft:stone
fill 33 142 618 34 142 619 minecraft:deepslate
fill 33 142 621 34 142 622 minecraft:stone
fill 33 142 624 34 142 625 minecraft:deepslate
fill 33 142 627 34 142 628 minecraft:stone
fill 33 142 630 34 142 631 minecraft:deepslate
fill 33 142 633 34 142 634 minecraft:stone
fill 33 142 636 34 142 637 minecraft:deepslate
fill 33 142 639 34 142 640 minecraft:stone
fill 33 142 642 34 142 643 minecraft:deepslate
fill 33 142 645 34 142 645 minecraft:stone
fill 35 142 606 35 142 607 minecraft:diamond_block
fill 35 142 609 35 142 610 minecraft:diamond_block
fill 35 142 612 35 142 613 minecraft:diamond_block
fill 35 142 615 35 142 616 minecraft:diamond_block
fill 35 142 618 35 142 619 minecraft:diamond_block
fill 35 142 621 35 142 622 minecraft:diamond_block
fill 35 142 624 35 142 625 minecraft:diamond_block
fill 35 142 627 35 142 628 minecraft:diamond_block
fill 35 142 630 35 142 631 minecraft:diamond_block
fill 35 142 633 35 142 634 minecraft:diamond_block
fill 35 142 636 35 142 637 minecraft:diamond_block
fill 35 142 639 35 142 640 minecraft:diamond_block
fill 35 142 642 35 142 643 minecraft:diamond_block
setblock 35 142 645 minecraft:diamond_block
fill 36 142 606 37 142 607 minecraft:stone
fill 36 142 609 37 142 610 minecraft:deepslate
fill 36 142 612 37 142 613 minecraft:stone
fill 36 142 615 37 142 616 minecraft:deepslate
fill 36 142 618 37 142 619 minecraft:stone
fill 36 142 621 37 142 622 minecraft:deepslate
fill 36 142 624 37 142 625 minecraft:stone
fill 36 142 627 37 142 628 minecraft:deepslate
fill 36 142 630 37 142 631 minecraft:stone
fill 36 142 633 37 142 634 minecraft:deepslate
fill 36 142 636 37 142 637 minecraft:stone
fill 36 142 639 37 142 640 minecraft:deepslate
fill 36 142 642 37 142 643 minecraft:stone
fill 36 142 645 37 142 645 minecraft:deepslate
fill 38 142 606 38 142 607 minecraft:diamond_block
fill 38 142 609 38 142 610 minecraft:diamond_block
fill 38 142 612 38 142 613 minecraft:diamond_block
fill 38 142 615 38 142 616 minecraft:diamond_block
fill 38 142 618 38 142 619 minecraft:diamond_block
fill 38 142 621 38 142 622 minecraft:diamond_block
fill 38 142 624 38 142 625 minecraft:diamond_block
fill 38 142 627 38 142 628 minecraft:diamond_block
fill 38 142 630 38 142 631 minecraft:diamond_block
fill 38 142 633 38 142 634 minecraft:diamond_block
fill 38 142 636 38 142 637 minecraft:diamond_block
fill 38 142 639 38 142 640 minecraft:diamond_block
fill 38 142 642 38 142 643 minecraft:diamond_block
setblock 38 142 645 minecraft:diamond_block
fill 39 142 606 40 142 607 minecraft:deepslate
fill 39 142 609 40 142 610 minecraft:stone
fill 39 142 612 40 142 613 minecraft:deepslate
fill 39 142 615 40 142 616 minecraft:stone
fill 39 142 618 40 142 619 minecraft:deepslate
fill 39 142 621 40 142 622 minecraft:stone
fill 39 142 624 40 142 625 minecraft:deepslate
fill 39 142 627 40 142 628 minecraft:stone
fill 39 142 630 40 142 631 minecraft:deepslate
fill 39 142 633 40 142 634 minecraft:stone
fill 39 142 636 40 142 637 minecraft:deepslate
fill 39 142 639 40 142 640 minecraft:stone
fill 39 142 642 40 142 643 minecraft:deepslate
fill 39 142 645 40 142 645 minecraft:stone
fill 40 142 604 40 145 604 minecraft:blue_concrete
fill 41 142 606 41 142 607 minecraft:diamond_block
fill 41 142 609 41 142 610 minecraft:diamond_block
fill 41 142 612 41 142 613 minecraft:diamond_block
fill 41 142 615 41 142 616 minecraft:diamond_block
fill 41 142 618 41 142 619 minecraft:diamond_block
fill 41 142 621 41 142 622 minecraft:diamond_block
fill 41 142 624 41 142 625 minecraft:diamond_block
fill 41 142 627 41 142 628 minecraft:diamond_block
fill 41 142 630 41 142 631 minecraft:diamond_block
fill 41 142 633 41 142 634 minecraft:diamond_block
fill 41 142 636 41 142 637 minecraft:diamond_block
fill 41 142 639 41 142 640 minecraft:diamond_block
fill 41 142 642 41 142 643 minecraft:diamond_block
setblock 41 142 645 minecraft:diamond_block
setblock 42 142 642 minecraft:diamond_block
fill 42 142 643 42 163 643 minecraft:blue_concrete
fill 0 143 619 0 186 619 minecraft:blue_concrete
setblock 0 143 620 minecraft:white_concrete
fill 0 143 621 0 151 624 minecraft:blue_concrete
fill 2 143 646 2 218 646 minecraft:blue_concrete
fill 17 143 626 19 143 626 minecraft:red_nether_bricks
fill 18 143 624 20 143 625 minecraft:red_nether_bricks
fill 18 143 627 20 143 628 minecraft:red_nether_bricks
fill 19 143 623 22 143 623 minecraft:red_nether_bricks
fill 19 143 629 22 143 629 minecraft:red_nether_bricks
fill 20 143 622 26 143 622 minecraft:red_nether_bricks
fill 20 143 626 21 143 626 minecraft:quartz_block
fill 20 143 630 26 143 630 minecraft:red_nether_bricks
fill 21 143 624 21 144 625 minecraft:quartz_block
fill 21 143 627 21 144 628 minecraft:quartz_block
fill 22 143 624 25 143 624 minecraft:quartz_block
fill 22 143 628 25 143 628 minecraft:quartz_block
fill 23 143 623 23 144 623 minecraft:quartz_block
fill 23 143 629 23 144 629 minecraft:quartz_block
fill 24 143 623 27 143 623 minecraft:red_nether_bricks
fill 24 143 629 27 143 629 minecraft:red_nether_bricks
fill 25 143 625 25 143 627 minecraft:quartz_block
fill 26 143 624 28 143 625 minecraft:red_nether_bricks
fill 26 143 626 26 144 626 minecraft:quartz_block
fill 26 143 627 28 143 628 minecraft:red_nether_bricks
fill 27 143 626 29 143 626 minecraft:red_nether_bricks
fill 28 143 604 28 177 604 minecraft:blue_concrete
fill 42 143 608 42 162 612 minecraft:blue_concrete
setblock 42 143 613 minecraft:glowstone
fill 42 143 642 42 217 642 minecraft:blue_concrete
fill 0 144 620 0 185 620 minecraft:blue_concrete
setblock 3 144 607 minecraft:light[level=14]
setblock 3 144 615 minecraft:light[level=14]
setblock 3 144 623 minecraft:light[level=14]
setblock 3 144 631 minecraft:light[level=14]
setblock 3 144 639 minecraft:light[level=14]
setblock 11 144 607 minecraft:light[level=14]
setblock 11 144 615 minecraft:light[level=14]
setblock 11 144 623 minecraft:light[level=14]
setblock 11 144 631 minecraft:light[level=14]
setblock 11 144 639 minecraft:light[level=14]
fill 12 144 625 18 150 627 minecraft:nether_bricks
fill 13 144 624 17 150 624 minecraft:nether_bricks
fill 13 144 628 17 150 628 minecraft:nether_bricks
setblock 15 144 646 minecraft:diamond_block
fill 17 144 623 20 144 623 minecraft:red_nether_bricks
fill 17 144 629 20 144 629 minecraft:red_nether_bricks
fill 18 144 622 22 149 622 minecraft:red_nether_bricks
fill 18 144 624 19 144 624 minecraft:red_nether_bricks
fill 18 144 628 19 144 628 minecraft:red_nether_bricks
fill 18 144 630 22 149 630 minecraft:red_nether_bricks
setblock 19 144 607 minecraft:light[level=14]
setblock 19 144 615 minecraft:light[level=14]
fill 19 144 621 27 151 621 minecraft:red_nether_bricks
setblock 19 144 625 minecraft:red_nether_bricks
fill 19 144 626 20 144 626 minecraft:quartz_block
setblock 19 144 627 minecraft:red_nether_bricks
fill 19 144 631 27 151 631 minecraft:red_nether_bricks
setblock 19 144 639 minecraft:light[level=14]
fill 20 144 624 20 144 625 minecraft:quartz_block
fill 20 144 627 20 144 628 minecraft:quartz_block
fill 21 144 623 22 144 623 minecraft:quartz_block
fill 21 144 629 22 144 629 minecraft:quartz_block
fill 22 144 620 24 153 620 minecraft:red_nether_bricks
setblock 22 144 624 minecraft:quartz_block
setblock 22 144 628 minecraft:quartz_block
fill 22 144 632 24 153 632 minecraft:red_nether_bricks
setblock 23 144 622 minecraft:quartz_block
setblock 23 144 630 minecraft:quartz_block
fill 24 144 622 28 149 622 minecraft:red_nether_bricks
fill 24 144 623 25 144 624 minecraft:quartz_block
fill 24 144 628 25 144 629 minecraft:quartz_block
fill 24 144 630 28 149 630 minecraft:red_nether_bricks
fill 25 144 625 26 144 625 minecraft:quartz_block
fill 25 144 627 26 144 627 minecraft:quartz_block
fill 26 144 623 29 150 623 minecraft:red_nether_bricks
setblock 26 144 624 minecraft:quartz_block
setblock 26 144 628 minecraft:quartz_block
fill 26 144 629 29 150 629 minecraft:red_nether_bricks
setblock 27 144 607 minecraft:light[level=14]
setblock 27 144 615 minecraft:light[level=14]
fill 27 144 624 30 149 625 minecraft:red_nether_bricks
setblock 27 144 626 minecraft:quartz_block
fill 27 144 627 30 149 628 minecraft:red_nether_bricks
setblock 27 144 639 minecraft:light[level=14]
fill 28 144 626 30 152 626 minecraft:red_nether_bricks
setblock 35 144 607 minecraft:light[level=14]
setblock 35 144 615 minecraft:light[level=14]
setblock 35 144 623 minecraft:light[level=14]
setblock 35 144 631 minecraft:light[level=14]
setblock 35 144 639 minecraft:light[level=14]
fill 42 144 613 42 154 613 minecraft:blue_concrete
fill 10 145 626 11 149 626 minecraft:nether_bricks
fill 11 145 624 11 147 625 minecraft:nether_bricks
fill 11 145 627 11 147 628 minecraft:nether_bricks
fill 12 145 623 12 149 624 minecraft:nether_bricks
fill 12 145 628 12 149 629 minecraft:nether_bricks
fill 13 145 623 18 149 623 minecraft:nether_bricks
fill 13 145 629 18 149 629 minecraft:nether_bricks
fill 15 145 646 15 164 646 minecraft:blue_concrete
setblock 17 145 622 minecraft:red_nether_bricks
setblock 17 145 630 minecraft:red_nether_bricks
fill 18 145 621 18 153 621 minecraft:red_nether_bricks
fill 18 145 624 19 149 624 minecraft:nether_bricks
fill 18 145 628 19 149 628 minecraft:nether_bricks
fill 18 145 631 18 153 631 minecraft:red_nether_bricks
fill 19 145 620 21 152 620 minecraft:red_nether_bricks
fill 19 145 623 25 145 623 minecraft:red_nether_bricks
fill 19 145 625 19 149 627 minecraft:nether_bricks
fill 19 145 629 25 145 629 minecraft:red_nether_bricks
fill 19 145 632 21 152 632 minecraft:red_nether_bricks
fill 20 145 624 20 145 625 minecraft:red_nether_bricks
fill 20 145 626 20 146 626 minecraft:nether_bricks
fill 20 145 627 20 145 628 minecraft:red_nether_bricks
setblock 21 145 624 minecraft:red_nether_bricks
setblock 21 145 628 minecraft:red_nether_bricks
fill 23 145 622 23 149 622 minecraft:red_nether_bricks
fill 23 145 630 23 149 630 minecraft:red_nether_bricks
fill 25 145 620 27 152 620 minecraft:red_nether_bricks
fill 25 145 624 26 145 624 minecraft:red_nether_bricks
fill 25 145 628 26 145 628 minecraft:red_nether_bricks
fill 25 145 632 27 152 632 minecraft:red_nether_bricks
fill 26 145 625 26 146 627 minecraft:red_nether_bricks
fill 27 145 626 27 149 626 minecraft:red_nether_bricks
fill 28 145 621 28 153 621 minecraft:red_nether_bricks
fill 28 145 631 28 153 631 minecraft:red_nether_bricks
fill 29 145 622 29 153 622 minecraft:red_nether_bricks
fill 29 145 630 29 153 630 minecraft:red_nether_bricks
fill 30 145 623 30 153 623 minecraft:red_nether_bricks
fill 30 145 629 30 153 629 minecraft:red_nether_bricks
fill 31 145 624 31 152 628 minecraft:red_nether_bricks
setblock 39 145 604 minecraft:white_concrete
setblock 0 146 612 minecraft:moss_block
setblock 0 146 616 minecraft:diamond_block
setblock 0 146 628 minecraft:moss_block
fill 0 146 629 0 158 632 minecraft:blue_concrete
fill 0 146 643 0 161 643 minecraft:blue_concrete
setblock 0 146 644 minecraft:moss_block
fill 0 146 645 0 185 646 minecraft:blue_concrete
fill 1 146 604 3 160 604 minecraft:blue_concrete
setblock 4 146 604 minecraft:moss_block
fill 5 146 604 6 157 604 minecraft:blue_concrete
fill 10 146 624 10 148 625 minecraft:nether_bricks
fill 10 146 627 10 148 628 minecraft:nether_bricks
fill 11 146 623 11 148 623 minecraft:nether_bricks
fill 11 146 629 11 148 629 minecraft:nether_bricks
setblock 12 146 646 minecraft:diamond_block
fill 13 146 622 17 148 622 minecraft:nether_bricks
fill 13 146 630 17 148 630 minecraft:nether_bricks
setblock 14 146 646 minecraft:moss_block
fill 17 146 604 19 156 604 minecraft:blue_concrete
fill 17 146 621 17 152 621 minecraft:red_nether_bricks
fill 17 146 631 17 152 631 minecraft:red_nether_bricks
fill 18 146 620 18 151 620 minecraft:red_nether_bricks
fill 18 146 632 18 151 632 minecraft:red_nether_bricks
fill 19 146 623 19 148 623 minecraft:nether_bricks
fill 19 146 629 19 148 629 minecraft:nether_bricks
setblock 20 146 604 minecraft:moss_block
fill 20 146 619 26 150 619 minecraft:red_nether_bricks
fill 20 146 623 25 146 623 minecraft:red_nether_bricks
fill 20 146 624 20 146 625 minecraft:nether_bricks
fill 20 146 627 20 146 628 minecraft:nether_bricks
fill 20 146 629 25 146 629 minecraft:red_nether_bricks
fill 20 146 633 26 150 633 minecraft:red_nether_bricks
fill 24 146 604 24 158 604 minecraft:blue_concrete
setblock 25 146 604 minecraft:white_concrete
setblock 26 146 604 minecraft:glowstone
fill 26 146 624 26 148 624 minecraft:red_nether_bricks
fill 26 146 628 26 148 628 minecraft:red_nether_bricks
fill 27 146 604 27 206 604 minecraft:blue_concrete
fill 28 146 620 28 151 620 minecraft:red_nether_bricks
fill 28 146 632 28 151 632 minecraft:red_nether_bricks
fill 28 146 646 29 218 646 minecraft:blue_concrete
fill 29 146 621 29 152 621 minecraft:red_nether_bricks
fill 29 146 631 29 152 631 minecraft:red_nether_bricks
fill 30 146 622 30 152 622 minecraft:red_nether_bricks
fill 30 146 630 30 152 630 minecraft:red_nether_bricks
setblock 30 146 646 minecraft:moss_block
fill 31 146 623 31 152 623 minecraft:red_nether_bricks
fill 31 146 629 31 152 629 minecraft:red_nether_bricks
fill 32 146 625 32 151 627 minecraft:red_nether_bricks
fill 33 146 604 35 149 604 minecraft:blue_concrete
setblock 36 146 604 minecraft:moss_block
fill 39 146 604 39 150 604 minecraft:blue_concrete
setblock 40 146 604 minecraft:glowstone
setblock 42 146 606 minecraft:diamond_block
setblock 42 146 614 minecraft:moss_block
setblock 42 146 615 minecraft:white_concrete
fill 42 146 616 42 218 616 minecraft:blue_concrete
fill 42 146 623 42 165 625 minecraft:blue_concrete
setblock 42 146 626 minecraft:white_concrete
setblock 42 146 630 minecraft:moss_block
fill 42 146 631 42 206 634 minecraft:blue_concrete
fill 0 147 612 0 153 612 minecraft:blue_concrete
fill 0 147 616 0 218 616 minecraft:blue_concrete
fill 0 147 628 0 153 628 minecraft:blue_concrete
fill 0 147 644 0 153 644 minecraft:blue_concrete
fill 4 147 604 4 153 604 minecraft:blue_concrete
fill 12 147 646 12 180 646 minecraft:blue_concrete
setblock 13 147 646 minecraft:glowstone
fill 14 147 646 14 153 646 minecraft:blue_concrete
fill 16 147 621 16 151 621 minecraft:red_nether_bricks
fill 16 147 631 16 151 631 minecraft:red_nether_bricks
fill 17 147 620 17 150 620 minecraft:red_nether_bricks
fill 17 147 632 17 150 632 minecraft:red_nether_bricks
fill 19 147 619 19 150 619 minecraft:red_nether_bricks
fill 19 147 633 19 150 633 minecraft:red_nether_bricks
fill 20 147 604 20 149 604 minecraft:blue_concrete
fill 20 147 623 21 148 623 minecraft:red_nether_bricks
fill 20 147 624 20 148 624 minecraft:nether_bricks
fill 20 147 628 20 148 628 minecraft:nether_bricks
fill 20 147 629 21 148 629 minecraft:red_nether_bricks
fill 25 147 604 26 186 604 minecraft:blue_concrete
fill 25 147 623 25 148 623 minecraft:red_nether_bricks
fill 25 147 629 25 148 629 minecraft:red_nether_bricks
fill 27 147 619 27 150 619 minecraft:red_nether_bricks
fill 27 147 633 27 150 633 minecraft:red_nether_bricks
fill 29 147 620 29 150 620 minecraft:red_nether_bricks
fill 29 147 632 29 150 632 minecraft:red_nether_bricks
fill 30 147 621 30 151 621 minecraft:red_nether_bricks
fill 30 147 631 30 151 631 minecraft:red_nether_bricks
fill 30 147 646 30 153 646 minecraft:blue_concrete
fill 31 147 622 31 151 622 minecraft:red_nether_bricks
fill 31 147 630 31 151 630 minecraft:red_nether_bricks
fill 32 147 624 32 151 624 minecraft:red_nether_bricks
fill 32 147 628 32 151 628 minecraft:red_nether_bricks
fill 36 147 604 36 153 604 minecraft:blue_concrete
fill 40 147 604 40 167 604 minecraft:blue_concrete
fill 42 147 606 42 215 606 minecraft:blue_concrete
fill 42 147 614 42 153 615 minecraft:blue_concrete
fill 42 147 626 42 157 626 minecraft:blue_concrete
setblock 42 147 628 minecraft:glowstone
fill 42 147 630 42 153 630 minecraft:blue_concrete
fill 11 148 624 11 149 624 minecraft:black_concrete
fill 11 148 625 11 149 625 minecraft:nether_bricks
fill 11 148 627 11 149 627 minecraft:nether_bricks
fill 11 148 628 11 149 628 minecraft:black_concrete
fill 13 148 646 13 218 646 minecraft:blue_concrete
fill 32 148 623 32 150 623 minecraft:red_nether_bricks
fill 32 148 629 32 150 629 minecraft:red_nether_bricks
setblock 42 148 621 minecraft:diamond_block
fill 42 148 628 42 218 628 minecraft:blue_concrete
setblock 10 149 625 minecraft:nether_bricks
setblock 10 149 627 minecraft:nether_bricks
fill 15 149 622 17 151 622 minecraft:red_nether_bricks
fill 15 149 630 17 151 630 minecraft:red_nether_bricks
fill 19 149 623 20 150 623 minecraft:red_nether_bricks
fill 19 149 629 20 150 629 minecraft:red_nether_bricks
setblock 21 149 604 minecraft:white_concrete
fill 22 149 604 22 215 604 minecraft:blue_concrete
setblock 29 149 604 minecraft:glowstone
fill 42 149 621 42 216 621 minecraft:blue_concrete
setblock 11 150 626 minecraft:nether_bricks
setblock 12 150 624 minecraft:nether_bricks
setblock 12 150 628 minecraft:nether_bricks
fill 14 150 623 16 150 623 minecraft:nether_bricks
fill 14 150 629 16 150 629 minecraft:nether_bricks
fill 17 150 623 18 153 623 minecraft:red_nether_bricks
fill 17 150 629 18 153 629 minecraft:red_nether_bricks
fill 18 150 622 21 151 622 minecraft:red_nether_bricks
setblock 18 150 624 minecraft:nether_bricks
setblock 18 150 628 minecraft:nether_bricks
fill 18 150 630 21 151 630 minecraft:red_nether_bricks
fill 19 150 624 19 151 624 minecraft:red_nether_bricks
fill 19 150 628 19 151 628 minecraft:red_nether_bricks
setblock 20 150 604 minecraft:glowstone
fill 21 150 604 21 218 604 minecraft:blue_concrete
fill 25 150 622 28 151 622 minecraft:red_nether_bricks
fill 25 150 630 28 151 630 minecraft:red_nether_bricks
fill 27 150 624 30 151 624 minecraft:red_nether_bricks
fill 27 150 628 30 151 628 minecraft:red_nether_bricks
fill 28 150 625 30 153 625 minecraft:red_nether_bricks
fill 28 150 627 30 153 627 minecraft:red_nether_bricks
fill 29 150 604 29 154 604 minecraft:blue_concrete
fill 33 150 604 33 215 604 minecraft:blue_concrete
setblock 34 150 604 minecraft:diamond_block
fill 35 150 604 35 205 604 minecraft:blue_concrete
setblock 8 151 646 minecraft:white_concrete
fill 9 151 604 9 218 604 minecraft:blue_concrete
setblock 10 151 604 minecraft:white_concrete
setblock 10 151 646 minecraft:white_concrete
fill 13 151 628 13 152 628 minecraft:coal_block
fill 14 151 624 18 151 625 minecraft:red_nether_bricks
fill 14 151 626 16 151 626 minecraft:nether_bricks
fill 14 151 627 18 151 628 minecraft:red_nether_bricks
fill 15 151 623 16 152 623 minecraft:red_nether_bricks
fill 15 151 629 16 152 629 minecraft:red_nether_bricks
setblock 16 151 646 minecraft:white_concrete
fill 17 151 626 18 152 626 minecraft:red_nether_bricks
fill 17 151 646 17 160 646 minecraft:blue_concrete
fill 19 151 623 19 152 623 minecraft:red_nether_bricks
fill 19 151 629 19 152 629 minecraft:red_nether_bricks
fill 19 151 646 24 158 646 minecraft:blue_concrete
fill 20 151 604 20 153 604 minecraft:blue_concrete
fill 20 151 619 24 151 619 minecraft:red_nether_bricks
fill 20 151 633 24 151 633 minecraft:red_nether_bricks
setblock 25 151 619 minecraft:black_concrete
setblock 25 151 633 minecraft:black_concrete
setblock 25 151 646 minecraft:white_concrete
setblock 26 151 619 minecraft:red_nether_bricks
setblock 26 151 633 minecraft:red_nether_bricks
fill 27 151 623 29 152 623 minecraft:red_nether_bricks
fill 27 151 629 29 152 629 minecraft:red_nether_bricks
fill 34 151 604 34 174 604 minecraft:blue_concrete
setblock 39 151 604 minecraft:diamond_block
fill 0 152 621 0 170 623 minecraft:blue_concrete
setblock 0 152 624 minecraft:glowstone
setblock 3 152 607 minecraft:light[level=14]
setblock 3 152 615 minecraft:light[level=14]
setblock 3 152 623 minecraft:light[level=14]
setblock 3 152 631 minecraft:light[level=14]
setblock 3 152 639 minecraft:light[level=14]
fill 8 152 646 8 218 646 minecraft:blue_concrete
fill 10 152 604 10 218 604 minecraft:blue_concrete
fill 10 152 646 10 218 646 minecraft:blue_concrete
setblock 11 152 607 minecraft:light[level=14]
setblock 11 152 615 minecraft:light[level=14]
setblock 11 152 623 minecraft:light[level=14]
setblock 11 152 631 minecraft:light[level=14]
setblock 11 152 639 minecraft:light[level=14]
setblock 14 152 628 minecraft:coal_block
fill 15 152 624 16 152 628 minecraft:red_nether_bricks
fill 16 152 622 19 152 622 minecraft:red_nether_bricks
fill 16 152 630 19 152 630 minecraft:red_nether_bricks
fill 16 152 646 16 213 646 minecraft:blue_concrete
fill 17 152 624 18 153 625 minecraft:red_nether_bricks
fill 17 152 627 18 153 628 minecraft:red_nether_bricks
setblock 19 152 607 minecraft:light[level=14]
setblock 19 152 615 minecraft:light[level=14]
setblock 19 152 621 minecraft:red_nether_bricks
setblock 19 152 631 minecraft:red_nether_bricks
setblock 19 152 639 minecraft:light[level=14]
fill 20 152 621 20 152 622 minecraft:shroomlight
fill 20 152 630 20 152 631 minecraft:shroomlight
fill 21 152 621 27 152 621 minecraft:red_nether_bricks
fill 21 152 631 27 152 631 minecraft:red_nether_bricks
fill 22 152 619 24 152 619 minecraft:red_nether_bricks
fill 22 152 633 24 152 633 minecraft:red_nether_bricks
fill 25 152 618 28 152 618 minecraft:black_concrete
fill 25 152 634 28 152 634 minecraft:black_concrete
fill 25 152 646 25 175 646 minecraft:blue_concrete
fill 26 152 622 28 152 622 minecraft:red_nether_bricks
fill 26 152 630 28 152 630 minecraft:red_nether_bricks
setblock 27 152 607 minecraft:light[level=14]
setblock 27 152 615 minecraft:light[level=14]
setblock 27 152 639 minecraft:light[level=14]
fill 28 152 624 30 153 624 minecraft:red_nether_bricks
fill 28 152 628 30 153 628 minecraft:red_nether_bricks
setblock 35 152 607 minecraft:light[level=14]
setblock 35 152 615 minecraft:light[level=14]
setblock 35 152 623 minecraft:light[level=14]
setblock 35 152 631 minecraft:light[level=14]
setblock 35 152 639 minecraft:light[level=14]
fill 39 152 604 39 168 604 minecraft:blue_concrete
setblock 0 153 617 minecraft:diamond_block
fill 0 153 624 0 176 624 minecraft:blue_concrete
fill 15 153 626 17 153 626 minecraft:red_nether_bricks
fill 16 153 623 16 153 625 minecraft:red_nether_bricks
fill 16 153 627 16 153 629 minecraft:red_nether_bricks
fill 17 153 622 18 153 622 minecraft:red_nether_bricks
fill 17 153 630 18 153 630 minecraft:red_nether_bricks
fill 19 153 621 19 153 622 minecraft:shroomlight
fill 19 153 630 19 153 631 minecraft:shroomlight
fill 20 153 621 21 153 621 minecraft:shroomlight
fill 20 153 631 21 153 631 minecraft:shroomlight
setblock 21 153 620 minecraft:red_nether_bricks
setblock 21 153 632 minecraft:red_nether_bricks
setblock 22 153 621 minecraft:red_nether_bricks
setblock 22 153 631 minecraft:red_nether_bricks
fill 24 153 621 27 153 621 minecraft:red_nether_bricks
fill 24 153 631 27 153 631 minecraft:red_nether_bricks
setblock 25 153 618 minecraft:black_concrete
setblock 25 153 620 minecraft:red_nether_bricks
setblock 25 153 632 minecraft:red_nether_bricks
setblock 25 153 634 minecraft:black_concrete
fill 26 153 617 30 153 617 minecraft:black_concrete
fill 26 153 635 30 153 635 minecraft:black_concrete
fill 27 153 622 28 153 622 minecraft:red_nether_bricks
fill 27 153 630 28 153 630 minecraft:red_nether_bricks
fill 28 153 623 29 153 623 minecraft:red_nether_bricks
fill 28 153 629 29 153 629 minecraft:red_nether_bricks
fill 29 153 616 31 153 616 minecraft:black_concrete
fill 29 153 626 31 153 626 minecraft:red_nether_bricks
fill 29 153 636 31 153 636 minecraft:black_concrete
fill 0 154 612 0 155 612 minecraft:moss_block
fill 0 154 617 0 169 617 minecraft:blue_concrete
fill 0 154 628 0 155 628 minecraft:moss_block
fill 0 154 644 0 155 644 minecraft:moss_block
fill 4 154 604 4 155 604 minecraft:moss_block
setblock 8 154 604 minecraft:diamond_block
fill 13 154 639 13 155 639 minecraft:diamond_block
fill 14 154 646 14 155 646 minecraft:moss_block
fill 17 154 624 17 154 628 minecraft:red_nether_bricks
fill 18 154 623 18 154 624 minecraft:red_nether_bricks
fill 18 154 628 18 154 629 minecraft:red_nether_bricks
setblock 19 154 622 minecraft:red_nether_bricks
setblock 19 154 630 minecraft:red_nether_bricks
fill 20 154 604 20 155 604 minecraft:moss_block
setblock 21 154 621 minecraft:red_nether_bricks
setblock 21 154 631 minecraft:red_nether_bricks
setblock 25 154 617 minecraft:black_concrete
setblock 25 154 621 minecraft:red_nether_bricks
setblock 25 154 631 minecraft:red_nether_bricks
setblock 25 154 635 minecraft:black_concrete
setblock 26 154 616 minecraft:black_concrete
fill 26 154 621 26 155 621 minecraft:blackstone
fill 26 154 631 26 155 631 minecraft:blackstone
setblock 26 154 636 minecraft:black_concrete
fill 27 154 622 27 155 622 minecraft:blackstone
fill 27 154 630 27 155 630 minecraft:blackstone
fill 28 154 616 29 154 616 minecraft:black_concrete
fill 28 154 623 28 154 624 minecraft:red_nether_bricks
fill 28 154 628 28 154 629 minecraft:red_nether_bricks
fill 28 154 636 29 154 636 minecraft:black_concrete
fill 29 154 624 29 154 628 minecraft:red_nether_bricks
setblock 30 154 615 minecraft:black_concrete
setblock 30 154 637 minecraft:black_concrete
fill 30 154 646 30 155 646 minecraft:moss_block
setblock 33 154 615 minecraft:black_concrete
setblock 33 154 637 minecraft:black_concrete
fill 36 154 604 36 155 604 minecraft:moss_block
fill 42 154 614 42 155 614 minecraft:moss_block
fill 42 154 615 42 175 615 minecraft:blue_concrete
fill 42 154 630 42 155 630 minecraft:moss_block
fill 8 155 604 8 197 604 minecraft:blue_concrete
fill 25 155 616 25 156 616 minecraft:black_concrete
fill 25 155 636 25 156 636 minecraft:black_concrete
fill 27 155 615 27 156 615 minecraft:black_concrete
fill 27 155 621 27 157 621 minecraft:blackstone
fill 27 155 631 27 157 631 minecraft:blackstone
fill 27 155 637 27 156 637 minecraft:black_concrete
setblock 29 155 604 minecraft:white_concrete
setblock 29 155 615 minecraft:black_concrete
setblock 29 155 637 minecraft:black_concrete
fill 31 155 614 32 155 614 minecraft:black_concrete
fill 31 155 638 32 155 638 minecraft:black_concrete
fill 35 155 614 36 155 614 minecraft:black_concrete
fill 35 155 638 36 155 638 minecraft:black_concrete
fill 36 155 613 37 155 613 minecraft:black_concrete
fill 36 155 639 37 155 639 minecraft:black_concrete
setblock 42 155 613 minecraft:diamond_block
fill 0 156 612 0 161 612 minecraft:blue_concrete
fill 0 156 628 0 161 628 minecraft:blue_concrete
fill 0 156 644 0 161 644 minecraft:blue_concrete
fill 3 156 646 6 183 646 minecraft:blue_concrete
fill 4 156 604 4 161 604 minecraft:blue_concrete
setblock 7 156 646 minecraft:white_concrete
setblock 9 156 646 minecraft:white_concrete
fill 13 156 639 13 165 639 minecraft:dirt
fill 14 156 646 14 161 646 minecraft:blue_concrete
fill 20 156 604 20 161 604 minecraft:blue_concrete
fill 25 156 615 25 157 615 minecraft:black_concrete
fill 25 156 637 25 157 637 minecraft:black_concrete
fill 27 156 614 27 157 614 minecraft:black_concrete
fill 27 156 620 28 157 620 minecraft:blackstone
fill 27 156 632 28 157 632 minecraft:blackstone
fill 27 156 638 27 157 638 minecraft:black_concrete
fill 28 156 621 28 158 621 minecraft:blackstone
fill 28 156 631 28 158 631 minecraft:blackstone
fill 29 156 604 29 182 604 minecraft:blue_concrete
fill 30 156 614 30 157 614 minecraft:black_concrete
fill 30 156 638 30 157 638 minecraft:black_concrete
fill 30 156 646 30 161 646 minecraft:blue_concrete
setblock 33 156 613 minecraft:black_concrete
setblock 33 156 639 minecraft:black_concrete
fill 34 156 612 34 157 612 minecraft:black_concrete
fill 34 156 640 34 157 640 minecraft:black_concrete
fill 36 156 604 36 161 604 minecraft:blue_concrete
setblock 37 156 613 minecraft:black_concrete
setblock 37 156 639 minecraft:black_concrete
fill 42 156 613 42 161 614 minecraft:blue_concrete
fill 42 156 630 42 161 630 minecraft:blue_concrete
fill 7 157 646 7 218 646 minecraft:blue_concrete
fill 9 157 646 9 218 646 minecraft:blue_concrete
fill 14 157 639 14 165 639 minecraft:dirt
fill 17 157 604 17 180 604 minecraft:blue_concrete
setblock 18 157 604 minecraft:glowstone
fill 19 157 604 19 172 604 minecraft:blue_concrete
fill 29 157 620 29 159 620 minecraft:blackstone
fill 29 157 632 29 159 632 minecraft:blackstone
fill 31 157 613 31 158 613 minecraft:black_concrete
fill 31 157 639 31 158 639 minecraft:black_concrete
setblock 32 157 646 minecraft:diamond_block
fill 33 157 646 34 214 646 minecraft:blue_concrete
setblock 41 157 646 minecraft:diamond_block
fill 42 157 646 42 218 646 minecraft:blue_concrete
fill 0 158 635 0 218 635 minecraft:blue_concrete
setblock 0 158 636 minecraft:white_concrete
fill 0 158 637 0 182 637 minecraft:blue_concrete
setblock 5 158 604 minecraft:white_concrete
fill 6 158 604 6 218 604 minecraft:blue_concrete
fill 13 158 638 14 165 638 minecraft:dirt
fill 14 158 614 14 159 614 minecraft:diamond_block
fill 18 158 604 18 218 604 minecraft:blue_concrete
setblock 25 158 614 minecraft:black_concrete
setblock 25 158 638 minecraft:black_concrete
fill 28 158 612 28 158 613 minecraft:black_concrete
fill 28 158 619 28 158 620 minecraft:blackstone
fill 28 158 632 28 158 633 minecraft:blackstone
fill 28 158 639 28 158 640 minecraft:black_concrete
fill 29 158 619 29 160 619 minecraft:blackstone
fill 29 158 633 29 160 633 minecraft:blackstone
fill 32 158 646 32 218 646 minecraft:blue_concrete
setblock 41 158 646 minecraft:blue_concrete
setblock 42 158 607 minecraft:white_concrete
setblock 42 158 626 minecraft:diamond_block
fill 0 159 629 0 182 630 minecraft:blue_concrete
setblock 0 159 631 minecraft:glowstone
fill 0 159 632 0 219 632 minecraft:blue_concrete
fill 0 159 636 0 209 636 minecraft:blue_concrete
fill 5 159 604 5 191 604 minecraft:blue_concrete
fill 12 159 638 12 165 639 minecraft:dirt
fill 13 159 640 14 165 640 minecraft:dirt
fill 15 159 639 15 165 639 minecraft:dirt
fill 19 159 646 23 161 646 minecraft:blue_concrete
setblock 24 159 604 minecraft:glowstone
setblock 24 159 646 minecraft:white_concrete
fill 25 159 613 25 160 613 minecraft:black_concrete
fill 25 159 639 25 160 639 minecraft:black_concrete
setblock 28 159 612 minecraft:black_concrete
setblock 28 159 620 minecraft:blackstone
setblock 28 159 632 minecraft:blackstone
setblock 28 159 640 minecraft:black_concrete
fill 30 159 619 30 160 620 minecraft:blackstone
fill 30 159 632 30 160 633 minecraft:blackstone
setblock 41 159 646 minecraft:glowstone
fill 42 159 607 42 218 607 minecraft:blue_concrete
fill 42 159 626 42 163 626 minecraft:blue_concrete
setblock 0 160 613 minecraft:diamond_block
fill 0 160 614 0 218 614 minecraft:blue_concrete
fill 0 160 631 0 168 631 minecraft:blue_concrete
setblock 0 160 640 minecraft:glowstone
setblock 3 160 607 minecraft:light[level=14]
setblock 3 160 615 minecraft:light[level=14]
setblock 3 160 623 minecraft:light[level=14]
setblock 3 160 631 minecraft:light[level=14]
setblock 3 160 639 minecraft:light[level=14]
setblock 11 160 607 minecraft:light[level=14]
setblock 11 160 615 minecraft:light[level=14]
setblock 11 160 623 minecraft:light[level=14]
setblock 11 160 631 minecraft:light[level=14]
setblock 11 160 639 minecraft:light[level=14]
fill 12 160 640 12 165 640 minecraft:dirt
fill 13 160 618 14 161 618 minecraft:stone
fill 13 160 637 14 165 637 minecraft:dirt
fill 14 160 614 14 169 614 minecraft:dirt
fill 14 160 617 14 161 617 minecraft:stone
fill 15 160 638 15 165 638 minecraft:dirt
fill 15 160 640 15 165 640 minecraft:dirt
setblock 19 160 607 minecraft:light[level=14]
setblock 19 160 615 minecraft:light[level=14]
setblock 19 160 623 minecraft:light[level=14]
setblock 19 160 631 minecraft:light[level=14]
setblock 19 160 639 minecraft:light[level=14]
fill 24 160 604 24 171 604 minecraft:blue_concrete
fill 24 160 646 24 215 646 minecraft:blue_concrete
setblock 27 160 607 minecraft:light[level=14]
setblock 27 160 615 minecraft:light[level=14]
setblock 27 160 623 minecraft:light[level=14]
setblock 27 160 631 minecraft:light[level=14]
setblock 27 160 639 minecraft:light[level=14]
fill 30 160 618 31 161 618 minecraft:blackstone
fill 30 160 634 31 161 634 minecraft:blackstone
fill 31 160 619 31 161 619 minecraft:blackstone
fill 31 160 633 31 161 633 minecraft:blackstone
setblock 35 160 607 minecraft:light[level=14]
setblock 35 160 615 minecraft:light[level=14]
setblock 35 160 623 minecraft:light[level=14]
setblock 35 160 631 minecraft:light[level=14]
setblock 35 160 639 minecraft:light[level=14]
fill 41 160 646 41 178 646 minecraft:blue_concrete
fill 0 161 613 0 199 613 minecraft:blue_concrete
fill 0 161 640 0 214 640 minecraft:blue_concrete
fill 1 161 604 1 164 604 minecraft:blue_concrete
setblock 2 161 604 minecraft:white_concrete
fill 3 161 604 3 173 604 minecraft:blue_concrete
fill 6 161 605 6 164 605 minecraft:diamond_block
fill 11 161 638 11 165 639 minecraft:dirt
setblock 11 161 646 minecraft:glowstone
fill 12 161 637 12 165 637 minecraft:dirt
fill 12 161 641 14 165 641 minecraft:dirt
fill 15 161 605 17 164 605 minecraft:diamond_block
fill 15 161 637 15 165 637 minecraft:dirt
fill 16 161 606 16 164 606 minecraft:diamond_block
fill 16 161 639 16 165 639 minecraft:dirt
setblock 17 161 646 minecraft:diamond_block
setblock 30 161 619 minecraft:blackstone
setblock 30 161 633 minecraft:blackstone
setblock 0 162 606 minecraft:glowstone
fill 0 162 612 0 164 612 minecraft:moss_block
fill 0 162 628 0 164 628 minecraft:moss_block
setblock 0 162 643 minecraft:diamond_block
fill 0 162 644 0 164 644 minecraft:moss_block
fill 2 162 604 2 218 604 minecraft:blue_concrete
fill 4 162 604 4 164 604 minecraft:moss_block
fill 5 162 605 5 163 606 minecraft:diamond_block
fill 6 162 606 6 163 608 minecraft:diamond_block
fill 7 162 605 7 163 606 minecraft:diamond_block
fill 11 162 637 11 165 637 minecraft:dirt
fill 11 162 640 11 165 640 minecraft:dirt
fill 11 162 646 11 218 646 minecraft:blue_concrete
fill 12 162 636 14 165 636 minecraft:dirt
fill 13 162 614 13 169 614 minecraft:dirt
fill 14 162 613 15 169 613 minecraft:dirt
fill 14 162 615 14 169 615 minecraft:dirt
fill 14 162 646 14 164 646 minecraft:moss_block
fill 15 162 606 15 164 606 minecraft:diamond_block
fill 15 162 614 15 169 614 minecraft:dirt
fill 15 162 641 15 165 641 minecraft:dirt
fill 16 162 607 16 164 607 minecraft:diamond_block
fill 16 162 638 16 165 638 minecraft:dirt
fill 16 162 640 16 165 640 minecraft:dirt
fill 17 162 606 17 164 606 minecraft:diamond_block
fill 17 162 646 17 218 646 minecraft:blue_concrete
fill 19 162 646 21 168 646 minecraft:blue_concrete
fill 20 162 604 20 164 604 minecraft:moss_block
setblock 22 162 646 minecraft:diamond_block
fill 23 162 646 23 218 646 minecraft:blue_concrete
fill 30 162 646 30 164 646 minecraft:moss_block
setblock 31 162 618 minecraft:blackstone
setblock 31 162 634 minecraft:blackstone
fill 36 162 604 36 164 604 minecraft:moss_block
fill 42 162 613 42 167 613 minecraft:blue_concrete
fill 42 162 614 42 164 614 minecraft:moss_block
fill 42 162 630 42 164 630 minecraft:moss_block
fill 0 163 606 0 216 606 minecraft:blue_concrete
fill 0 163 643 0 171 643 minecraft:blue_concrete
setblock 5 163 607 minecraft:diamond_block
setblock 6 163 609 minecraft:diamond_block
setblock 7 163 607 minecraft:diamond_block
fill 10 163 638 10 165 640 minecraft:dirt
fill 11 163 636 11 165 636 minecraft:dirt
fill 11 163 641 11 165 641 minecraft:dirt
fill 12 163 642 14 165 642 minecraft:dirt
fill 13 163 613 13 169 613 minecraft:dirt
fill 13 163 615 13 169 615 minecraft:dirt
fill 15 163 607 15 164 607 minecraft:diamond_block
fill 15 163 615 15 169 615 minecraft:dirt
fill 15 163 636 15 165 636 minecraft:dirt
fill 16 163 608 16 164 608 minecraft:diamond_block
fill 16 163 637 16 165 637 minecraft:dirt
fill 16 163 641 16 165 641 minecraft:dirt
fill 17 163 607 17 164 607 minecraft:diamond_block
fill 22 163 646 22 189 646 minecraft:blue_concrete
fill 42 163 608 42 177 609 minecraft:blue_concrete
setblock 42 163 610 minecraft:glowstone
fill 42 163 611 42 166 612 minecraft:blue_concrete
setblock 0 164 611 minecraft:diamond_block
fill 10 164 637 10 165 637 minecraft:dirt
fill 10 164 641 10 165 641 minecraft:dirt
fill 11 164 642 11 165 642 minecraft:dirt
fill 12 164 613 12 169 614 minecraft:dirt
fill 12 164 635 15 165 635 minecraft:dirt
fill 13 164 612 15 169 612 minecraft:dirt
fill 14 164 616 14 169 616 minecraft:dirt
fill 15 164 642 15 165 642 minecraft:dirt
fill 16 164 613 16 169 615 minecraft:dirt
fill 16 164 636 16 165 636 minecraft:dirt
fill 17 164 637 17 165 640 minecraft:dirt
fill 42 164 610 42 193 610 minecraft:blue_concrete
setblock 42 164 618 minecraft:diamond_block
setblock 42 164 626 minecraft:white_concrete
setblock 42 164 643 minecraft:glowstone
fill 0 165 611 0 166 612 minecraft:blue_concrete
setblock 0 165 615 minecraft:diamond_block
fill 0 165 628 0 170 628 minecraft:blue_concrete
fill 0 165 644 0 170 644 minecraft:blue_concrete
setblock 1 165 604 minecraft:diamond_block
fill 4 165 604 4 170 604 minecraft:blue_concrete
fill 9 165 638 9 165 640 minecraft:dirt
setblock 10 165 636 minecraft:dirt
setblock 11 165 635 minecraft:dirt
fill 12 165 615 12 169 615 minecraft:dirt
fill 12 165 643 15 165 643 minecraft:dirt
fill 13 165 616 13 169 616 minecraft:dirt
fill 14 165 646 14 170 646 minecraft:blue_concrete
fill 15 165 616 15 169 616 minecraft:dirt
setblock 15 165 646 minecraft:white_concrete
fill 16 165 612 16 169 612 minecraft:dirt
setblock 16 165 635 minecraft:dirt
setblock 16 165 642 minecraft:dirt
setblock 17 165 636 minecraft:dirt
setblock 17 165 641 minecraft:dirt
fill 20 165 604 20 170 604 minecraft:blue_concrete
fill 30 165 646 30 170 646 minecraft:blue_concrete
fill 36 165 604 36 170 604 minecraft:blue_concrete
fill 42 165 614 42 170 614 minecraft:blue_concrete
fill 42 165 618 42 206 618 minecraft:blue_concrete
fill 42 165 626 42 218 626 minecraft:blue_concrete
fill 42 165 630 42 167 630 minecraft:blue_concrete
fill 42 165 643 42 201 643 minecraft:blue_concrete
fill 0 166 615 0 218 615 minecraft:blue_concrete
fill 1 166 604 1 176 604 minecraft:blue_concrete
fill 11 166 613 11 169 614 minecraft:dirt
fill 12 166 612 12 169 612 minecraft:dirt
fill 12 166 616 12 169 616 minecraft:dirt
fill 13 166 611 15 169 611 minecraft:dirt
fill 13 166 639 13 168 639 minecraft:stone
fill 14 166 617 15 169 617 minecraft:dirt
fill 15 166 646 15 171 646 minecraft:blue_concrete
fill 16 166 616 16 169 616 minecraft:dirt
fill 17 166 613 17 169 615 minecraft:dirt
fill 42 166 623 42 202 624 minecraft:blue_concrete
setblock 42 166 625 minecraft:diamond_block
setblock 0 167 611 minecraft:glowstone
fill 0 167 612 0 170 612 minecraft:blue_concrete
setblock 0 167 618 minecraft:diamond_block
fill 11 167 612 11 169 612 minecraft:dirt
fill 11 167 615 11 169 615 minecraft:dirt
fill 12 167 611 12 169 611 minecraft:dirt
fill 13 167 617 13 169 617 minecraft:dirt
fill 16 167 611 16 169 611 minecraft:dirt
fill 16 167 617 16 169 617 minecraft:dirt
fill 17 167 612 17 169 612 minecraft:dirt
fill 17 167 616 17 169 616 minecraft:dirt
fill 42 167 611 42 182 611 minecraft:blue_concrete
setblock 42 167 612 minecraft:diamond_block
fill 42 167 625 42 185 625 minecraft:blue_concrete
fill 0 168 611 0 218 611 minecraft:blue_concrete
fill 0 168 618 0 201 618 minecraft:blue_concrete
setblock 0 168 625 minecraft:white_concrete
setblock 3 168 607 minecraft:light[level=14]
setblock 3 168 615 minecraft:light[level=14]
setblock 3 168 623 minecraft:light[level=14]
setblock 3 168 631 minecraft:light[level=14]
setblock 3 168 639 minecraft:light[level=14]
fill 8 168 612 9 169 612 minecraft:coal_block
fill 10 168 613 10 169 614 minecraft:dirt
setblock 11 168 607 minecraft:light[level=14]
fill 11 168 611 11 169 611 minecraft:dirt
fill 11 168 616 11 169 616 minecraft:dirt
setblock 11 168 623 minecraft:light[level=14]
setblock 11 168 631 minecraft:light[level=14]
setblock 11 168 639 minecraft:light[level=14]
fill 12 168 617 12 169 617 minecraft:dirt
fill 13 168 610 15 169 610 minecraft:dirt
fill 14 168 618 15 169 618 minecraft:dirt
fill 17 168 611 17 169 611 minecraft:dirt
fill 18 168 613 18 169 615 minecraft:dirt
setblock 19 168 607 minecraft:light[level=14]
setblock 19 168 615 minecraft:light[level=14]
setblock 19 168 623 minecraft:light[level=14]
setblock 19 168 631 minecraft:light[level=14]
setblock 19 168 639 minecraft:light[level=14]
setblock 27 168 607 minecraft:light[level=14]
setblock 27 168 615 minecraft:light[level=14]
setblock 27 168 623 minecraft:light[level=14]
setblock 27 168 631 minecraft:light[level=14]
setblock 27 168 639 minecraft:light[level=14]
setblock 35 168 607 minecraft:light[level=14]
setblock 35 168 615 minecraft:light[level=14]
setblock 35 168 623 minecraft:light[level=14]
setblock 35 168 631 minecraft:light[level=14]
setblock 35 168 639 minecraft:light[level=14]
setblock 40 168 604 minecraft:diamond_block
fill 42 168 612 42 180 612 minecraft:blue_concrete
setblock 42 168 613 minecraft:white_concrete
setblock 42 168 630 minecraft:glowstone
fill 0 169 625 0 218 625 minecraft:blue_concrete
setblock 0 169 631 minecraft:glowstone
setblock 0 169 633 minecraft:white_concrete
setblock 10 169 612 minecraft:dirt
fill 10 169 615 10 169 616 minecraft:dirt
setblock 11 169 617 minecraft:dirt
setblock 12 169 610 minecraft:dirt
fill 12 169 618 13 169 618 minecraft:dirt
fill 12 169 638 14 171 640 minecraft:oak_leaves[persistent=true]
fill 13 169 637 14 171 637 minecraft:oak_leaves[persistent=true]
fill 15 169 638 15 171 639 minecraft:oak_leaves[persistent=true]
setblock 16 169 610 minecraft:dirt
setblock 16 169 618 minecraft:dirt
setblock 17 169 617 minecraft:dirt
setblock 18 169 612 minecraft:dirt
setblock 18 169 616 minecraft:dirt
fill 19 169 646 20 215 646 minecraft:blue_concrete
setblock 21 169 646 minecraft:diamond_block
setblock 39 169 604 minecraft:glowstone
fill 40 169 604 40 206 604 minecraft:blue_concrete
fill 42 169 613 42 216 613 minecraft:blue_concrete
fill 42 169 630 42 170 630 minecraft:blue_concrete
setblock 0 170 617 minecraft:white_concrete
fill 0 170 631 0 172 631 minecraft:blue_concrete
fill 0 170 633 0 218 633 minecraft:blue_concrete
setblock 11 170 639 minecraft:oak_leaves[persistent=true]
setblock 12 170 637 minecraft:oak_leaves[persistent=true]
fill 13 170 641 14 170 641 minecraft:oak_leaves[persistent=true]
fill 14 170 614 14 173 614 minecraft:stone
setblock 15 170 637 minecraft:oak_leaves[persistent=true]
setblock 15 170 640 minecraft:oak_leaves[persistent=true]
fill 21 170 646 21 218 646 minecraft:blue_concrete
fill 39 170 604 39 194 604 minecraft:blue_concrete
fill 0 171 612 0 173 612 minecraft:moss_block
fill 0 171 617 0 187 617 minecraft:blue_concrete
fill 0 171 621 0 211 621 minecraft:blue_concrete
setblock 0 171 622 minecraft:white_concrete
fill 0 171 623 0 220 623 minecraft:blue_concrete
fill 0 171 628 0 173 628 minecraft:moss_block
fill 0 171 644 0 173 644 minecraft:moss_block
fill 4 171 604 4 173 604 minecraft:moss_block
fill 14 171 646 14 173 646 minecraft:moss_block
fill 20 171 604 20 173 604 minecraft:moss_block
setblock 27 171 646 minecraft:diamond_block
fill 30 171 646 30 173 646 minecraft:moss_block
setblock 35 171 646 minecraft:white_concrete
fill 36 171 604 36 173 604 minecraft:moss_block
fill 42 171 614 42 173 614 minecraft:moss_block
fill 42 171 630 42 173 630 minecraft:moss_block
fill 0 172 622 0 218 622 minecraft:blue_concrete
setblock 0 172 643 minecraft:diamond_block
setblock 15 172 646 minecraft:diamond_block
setblock 24 172 604 minecraft:diamond_block
fill 27 172 646 27 215 646 minecraft:blue_concrete
fill 35 172 646 35 194 646 minecraft:blue_concrete
setblock 40 172 646 minecraft:diamond_block
setblock 0 173 631 minecraft:diamond_block
setblock 0 173 641 minecraft:glowstone
fill 0 173 643 0 189 643 minecraft:blue_concrete
fill 13 173 613 13 175 615 minecraft:oak_leaves[persistent=true]
fill 14 173 612 14 175 613 minecraft:oak_leaves[persistent=true]
fill 14 173 615 15 175 615 minecraft:oak_leaves[persistent=true]
fill 15 173 613 15 175 614 minecraft:oak_leaves[persistent=true]
fill 15 173 646 15 181 646 minecraft:blue_concrete
fill 16 173 614 16 175 614 minecraft:oak_leaves[persistent=true]
setblock 19 173 604 minecraft:diamond_block
fill 24 173 604 24 182 604 minecraft:blue_concrete
fill 40 173 646 40 185 646 minecraft:blue_concrete
setblock 42 173 629 minecraft:white_concrete
fill 0 174 612 0 179 612 minecraft:blue_concrete
fill 0 174 628 0 175 628 minecraft:blue_concrete
fill 0 174 631 0 216 631 minecraft:blue_concrete
fill 0 174 641 0 192 641 minecraft:blue_concrete
fill 0 174 644 0 179 644 minecraft:blue_concrete
setblock 3 174 604 minecraft:diamond_block
fill 4 174 604 4 179 604 minecraft:blue_concrete
fill 12 174 613 12 174 614 minecraft:oak_leaves[persistent=true]
setblock 13 174 612 minecraft:oak_leaves[persistent=true]
fill 14 174 614 14 175 614 minecraft:oak_leaves[persistent=true]
fill 14 174 616 15 174 616 minecraft:oak_leaves[persistent=true]
fill 14 174 646 14 179 646 minecraft:blue_concrete
setblock 15 174 612 minecraft:oak_leaves[persistent=true]
setblock 16 174 613 minecraft:oak_leaves[persistent=true]
setblock 16 174 615 minecraft:oak_leaves[persistent=true]
fill 19 174 604 20 179 604 minecraft:blue_concrete
fill 30 174 646 30 179 646 minecraft:blue_concrete
fill 36 174 604 36 179 604 minecraft:blue_concrete
fill 42 174 614 42 179 614 minecraft:blue_concrete
fill 42 174 629 42 218 629 minecraft:blue_concrete
setblock 42 174 630 minecraft:white_concrete
fill 3 175 604 3 190 604 minecraft:blue_concrete
setblock 34 175 604 minecraft:white_concrete
fill 42 175 630 42 179 630 minecraft:blue_concrete
setblock 0 176 628 minecraft:diamond_block
setblock 3 176 607 minecraft:light[level=14]
setblock 3 176 615 minecraft:light[level=14]
setblock 3 176 623 minecraft:light[level=14]
setblock 3 176 631 minecraft:light[level=14]
setblock 3 176 639 minecraft:light[level=14]
setblock 11 176 607 minecraft:light[level=14]
setblock 11 176 615 minecraft:light[level=14]
setblock 11 176 623 minecraft:light[level=14]
setblock 11 176 631 minecraft:light[level=14]
setblock 11 176 639 minecraft:light[level=14]
setblock 19 176 607 minecraft:light[level=14]
setblock 19 176 615 minecraft:light[level=14]
setblock 19 176 623 minecraft:light[level=14]
setblock 19 176 631 minecraft:light[level=14]
setblock 19 176 639 minecraft:light[level=14]
setblock 25 176 646 minecraft:glowstone
setblock 27 176 607 minecraft:light[level=14]
setblock 27 176 615 minecraft:light[level=14]
setblock 27 176 623 minecraft:light[level=14]
setblock 27 176 631 minecraft:light[level=14]
setblock 27 176 639 minecraft:light[level=14]
fill 34 176 604 34 196 604 minecraft:blue_concrete
setblock 35 176 607 minecraft:light[level=14]
setblock 35 176 615 minecraft:light[level=14]
setblock 35 176 623 minecraft:light[level=14]
setblock 35 176 631 minecraft:light[level=14]
setblock 35 176 639 minecraft:light[level=14]
setblock 42 176 615 minecraft:glowstone
setblock 0 177 624 minecraft:diamond_block
fill 0 177 628 0 179 628 minecraft:blue_concrete
setblock 1 177 604 minecraft:glowstone
fill 25 177 646 25 205 646 minecraft:blue_concrete
fill 42 177 615 42 218 615 minecraft:blue_concrete
fill 0 178 624 0 218 624 minecraft:blue_concrete
fill 1 178 604 1 218 604 minecraft:blue_concrete
setblock 28 178 604 minecraft:white_concrete
setblock 42 178 608 minecraft:diamond_block
fill 42 178 609 42 211 609 minecraft:blue_concrete
fill 28 179 604 28 181 604 minecraft:blue_concrete
setblock 41 179 646 minecraft:diamond_block
fill 42 179 608 42 218 608 minecraft:blue_concrete
fill 0 180 612 0 182 612 minecraft:moss_block
fill 0 180 628 0 182 628 minecraft:moss_block
fill 0 180 644 0 182 644 minecraft:moss_block
fill 2 180 627 2 181 627 minecraft:coal_block
fill 4 180 604 4 182 604 minecraft:moss_block
fill 14 180 646 14 182 646 minecraft:moss_block
fill 19 180 604 19 193 604 minecraft:blue_concrete
fill 20 180 604 20 182 604 minecraft:moss_block
fill 30 180 646 30 182 646 minecraft:moss_block
fill 36 180 604 36 182 604 minecraft:moss_block
setblock 41 180 646 minecraft:blue_concrete
fill 42 180 614 42 182 614 minecraft:moss_block
fill 42 180 630 42 182 630 minecraft:moss_block
setblock 12 181 646 minecraft:glowstone
setblock 17 181 604 minecraft:diamond_block
setblock 41 181 646 minecraft:glowstone
setblock 42 181 612 minecraft:white_concrete
fill 12 182 646 12 219 646 minecraft:blue_concrete
setblock 15 182 646 minecraft:white_concrete
fill 17 182 604 17 194 604 minecraft:blue_concrete
setblock 28 182 604 minecraft:white_concrete
setblock 38 182 604 minecraft:diamond_block
fill 41 182 646 41 218 646 minecraft:blue_concrete
fill 42 182 612 42 190 612 minecraft:blue_concrete
fill 0 183 612 0 188 612 minecraft:blue_concrete
fill 0 183 628 0 188 628 minecraft:blue_concrete
setblock 0 183 629 minecraft:white_concrete
fill 0 183 630 0 216 630 minecraft:blue_concrete
setblock 0 183 637 minecraft:diamond_block
fill 0 183 644 0 188 644 minecraft:blue_concrete
fill 4 183 604 4 188 604 minecraft:blue_concrete
fill 14 183 646 15 185 646 minecraft:blue_concrete
fill 17 183 633 18 184 634 minecraft:coal_block
fill 20 183 604 20 188 604 minecraft:blue_concrete
setblock 24 183 604 minecraft:white_concrete
schedule function dropper:buildpart/144_2 1t
