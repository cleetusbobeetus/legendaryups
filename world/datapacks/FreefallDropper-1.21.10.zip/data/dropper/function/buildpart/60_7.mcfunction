setblock 37 283 279 minecraft:cobbled_deepslate
setblock 37 283 282 minecraft:blackstone
setblock 37 283 283 minecraft:cobbled_deepslate
setblock 37 283 286 minecraft:blackstone
setblock 37 283 287 minecraft:cobbled_deepslate
setblock 37 283 290 minecraft:blackstone
setblock 37 283 291 minecraft:cobbled_deepslate
setblock 37 283 294 minecraft:blackstone
setblock 37 283 295 minecraft:cobbled_deepslate
setblock 37 283 298 minecraft:blackstone
setblock 37 283 299 minecraft:cobbled_deepslate
setblock 37 283 302 minecraft:blackstone
setblock 37 283 303 minecraft:cobbled_deepslate
setblock 37 283 306 minecraft:blackstone
setblock 37 283 307 minecraft:cobbled_deepslate
fill 37 283 310 38 283 310 minecraft:blackstone
setblock 37 283 311 minecraft:cobbled_deepslate
fill 37 283 314 39 283 314 minecraft:blackstone
setblock 37 283 315 minecraft:cobbled_deepslate
setblock 38 283 276 minecraft:cobbled_deepslate
setblock 38 283 279 minecraft:blackstone
setblock 38 283 280 minecraft:cobbled_deepslate
setblock 38 283 283 minecraft:blackstone
setblock 38 283 284 minecraft:cobbled_deepslate
setblock 38 283 287 minecraft:blackstone
setblock 38 283 288 minecraft:cobbled_deepslate
setblock 38 283 291 minecraft:blackstone
setblock 38 283 292 minecraft:cobbled_deepslate
setblock 38 283 295 minecraft:blackstone
setblock 38 283 296 minecraft:cobbled_deepslate
setblock 38 283 299 minecraft:blackstone
setblock 38 283 300 minecraft:cobbled_deepslate
setblock 38 283 303 minecraft:blackstone
setblock 38 283 304 minecraft:cobbled_deepslate
setblock 38 283 307 minecraft:blackstone
setblock 38 283 308 minecraft:cobbled_deepslate
setblock 38 283 311 minecraft:blackstone
setblock 38 283 312 minecraft:cobbled_deepslate
setblock 38 283 315 minecraft:blackstone
setblock 38 283 316 minecraft:cobbled_deepslate
setblock 39 283 276 minecraft:blackstone
setblock 39 283 277 minecraft:cobbled_deepslate
setblock 39 283 280 minecraft:blackstone
setblock 39 283 281 minecraft:cobbled_deepslate
setblock 39 283 284 minecraft:blackstone
setblock 39 283 285 minecraft:cobbled_deepslate
setblock 39 283 288 minecraft:blackstone
setblock 39 283 289 minecraft:cobbled_deepslate
setblock 39 283 292 minecraft:blackstone
setblock 39 283 293 minecraft:cobbled_deepslate
setblock 39 283 296 minecraft:blackstone
setblock 39 283 297 minecraft:cobbled_deepslate
setblock 39 283 300 minecraft:blackstone
setblock 39 283 301 minecraft:cobbled_deepslate
setblock 39 283 304 minecraft:blackstone
setblock 39 283 305 minecraft:cobbled_deepslate
setblock 39 283 308 minecraft:blackstone
setblock 39 283 309 minecraft:cobbled_deepslate
setblock 39 283 312 minecraft:blackstone
setblock 39 283 313 minecraft:cobbled_deepslate
setblock 39 283 316 minecraft:blackstone
setblock 40 283 277 minecraft:blackstone
setblock 40 283 278 minecraft:cobbled_deepslate
setblock 40 283 281 minecraft:blackstone
setblock 40 283 282 minecraft:cobbled_deepslate
setblock 40 283 285 minecraft:blackstone
setblock 40 283 286 minecraft:cobbled_deepslate
setblock 40 283 289 minecraft:blackstone
setblock 40 283 290 minecraft:cobbled_deepslate
setblock 40 283 293 minecraft:blackstone
setblock 40 283 294 minecraft:cobbled_deepslate
setblock 40 283 297 minecraft:blackstone
setblock 40 283 298 minecraft:cobbled_deepslate
setblock 40 283 301 minecraft:blackstone
setblock 40 283 302 minecraft:cobbled_deepslate
setblock 40 283 305 minecraft:blackstone
setblock 40 283 306 minecraft:cobbled_deepslate
setblock 40 283 309 minecraft:blackstone
setblock 40 283 310 minecraft:cobbled_deepslate
setblock 40 283 313 minecraft:blackstone
setblock 40 283 314 minecraft:cobbled_deepslate
setblock 41 283 278 minecraft:blackstone
setblock 41 283 279 minecraft:cobbled_deepslate
setblock 41 283 282 minecraft:blackstone
setblock 41 283 283 minecraft:cobbled_deepslate
setblock 41 283 286 minecraft:blackstone
setblock 41 283 287 minecraft:cobbled_deepslate
setblock 41 283 290 minecraft:blackstone
setblock 41 283 291 minecraft:cobbled_deepslate
setblock 41 283 294 minecraft:blackstone
setblock 41 283 295 minecraft:cobbled_deepslate
setblock 41 283 298 minecraft:blackstone
setblock 41 283 299 minecraft:cobbled_deepslate
setblock 41 283 302 minecraft:blackstone
setblock 41 283 303 minecraft:cobbled_deepslate
setblock 41 283 306 minecraft:blackstone
setblock 41 283 307 minecraft:cobbled_deepslate
setblock 41 283 310 minecraft:blackstone
setblock 41 283 311 minecraft:cobbled_deepslate
setblock 41 283 314 minecraft:blackstone
setblock 41 283 315 minecraft:cobbled_deepslate
fill 42 283 301 42 308 301 minecraft:deepslate_tiles
fill 1 284 275 1 286 275 minecraft:deepslate_tiles
fill 2 284 297 4 284 299 minecraft:dripstone_block
fill 2 284 309 5 284 309 minecraft:dripstone_block
fill 3 284 308 4 284 308 minecraft:dripstone_block
fill 3 284 310 4 285 310 minecraft:dripstone_block
fill 4 284 294 5 284 296 minecraft:dripstone_block
fill 5 284 285 8 284 286 minecraft:dripstone_block
fill 6 284 284 9 284 284 minecraft:dripstone_block
fill 6 284 294 6 284 295 minecraft:dripstone_block
fill 7 284 282 9 284 283 minecraft:dripstone_block
fill 7 284 287 8 284 288 minecraft:dripstone_block
fill 8 284 290 10 284 291 minecraft:dripstone_block
fill 9 284 286 9 284 287 minecraft:dripstone_block
setblock 9 284 289 minecraft:dripstone_block
setblock 9 284 292 minecraft:dripstone_block
fill 9 284 313 12 284 313 minecraft:dripstone_block
fill 10 284 303 12 284 304 minecraft:dripstone_block
fill 10 284 312 11 284 312 minecraft:dripstone_block
fill 10 284 314 11 284 314 minecraft:dripstone_block
fill 11 284 275 11 308 275 minecraft:deepslate_tiles
fill 11 284 305 15 284 305 minecraft:dripstone_block
fill 13 284 304 17 284 304 minecraft:dripstone_block
fill 14 284 303 17 284 303 minecraft:dripstone_block
fill 15 284 292 17 284 293 minecraft:dripstone_block
fill 15 284 300 17 284 302 minecraft:dripstone_block
fill 16 284 283 18 284 284 minecraft:dripstone_block
fill 16 284 294 17 284 294 minecraft:dripstone_block
fill 16 284 296 17 284 297 minecraft:dripstone_block
fill 17 284 275 17 289 275 minecraft:deepslate_tiles
fill 17 284 282 18 284 282 minecraft:dripstone_block
fill 17 284 298 19 284 298 minecraft:dripstone_block
fill 19 284 288 20 284 290 minecraft:dripstone_block
setblock 20 284 299 minecraft:dripstone_block
fill 21 284 280 23 284 281 minecraft:dripstone_block
fill 21 284 289 21 284 290 minecraft:dripstone_block
fill 21 284 298 21 285 298 minecraft:dripstone_block
setblock 22 284 282 minecraft:dripstone_block
fill 22 284 286 28 284 286 minecraft:dripstone_block
fill 23 284 285 28 284 285 minecraft:dripstone_block
fill 23 284 287 25 284 287 minecraft:dripstone_block
fill 23 284 296 23 284 297 minecraft:dripstone_block
fill 24 284 284 27 284 284 minecraft:dripstone_block
setblock 24 284 296 minecraft:dripstone_block
fill 24 284 306 30 284 306 minecraft:dripstone_block
setblock 25 284 283 minecraft:dripstone_block
fill 25 284 299 27 284 300 minecraft:dripstone_block
fill 25 284 302 26 284 305 minecraft:dripstone_block
fill 25 284 307 26 284 310 minecraft:dripstone_block
fill 26 284 301 27 284 301 minecraft:dripstone_block
fill 26 284 312 28 284 313 minecraft:dripstone_block
fill 27 284 287 29 284 288 minecraft:dripstone_block
fill 27 284 303 27 284 304 minecraft:dripstone_block
setblock 27 284 309 minecraft:dripstone_block
setblock 27 284 311 minecraft:dripstone_block
setblock 27 284 314 minecraft:dripstone_block
fill 28 284 289 29 284 289 minecraft:dripstone_block
fill 28 284 304 30 284 305 minecraft:dripstone_block
fill 28 284 315 31 284 315 minecraft:dripstone_block
fill 29 284 308 32 284 308 minecraft:dripstone_block
fill 29 284 314 30 284 314 minecraft:dripstone_block
fill 29 284 316 30 285 316 minecraft:dripstone_block
fill 30 284 307 31 285 307 minecraft:dripstone_block
fill 30 284 309 31 284 309 minecraft:dripstone_block
fill 31 284 299 33 284 300 minecraft:dripstone_block
fill 32 284 291 34 285 292 minecraft:dripstone_block
fill 32 284 298 36 284 298 minecraft:dripstone_block
setblock 33 284 290 minecraft:dripstone_block
setblock 33 284 293 minecraft:dripstone_block
fill 34 284 287 36 284 289 minecraft:dripstone_block
fill 34 284 299 36 284 299 minecraft:dripstone_block
fill 35 284 297 36 284 297 minecraft:dripstone_block
fill 35 284 314 38 284 315 minecraft:dripstone_block
fill 36 284 313 38 284 313 minecraft:dripstone_block
setblock 36 284 316 minecraft:dripstone_block
fill 38 284 282 40 284 283 minecraft:dripstone_block
setblock 38 284 317 minecraft:crying_obsidian
fill 39 284 284 40 284 284 minecraft:dripstone_block
fill 2 285 298 4 285 298 minecraft:dripstone_block
setblock 3 285 297 minecraft:dripstone_block
fill 3 285 299 4 285 299 minecraft:dripstone_block
fill 3 285 309 4 286 309 minecraft:dripstone_block
fill 5 285 294 5 285 295 minecraft:dripstone_block
fill 6 285 285 7 285 286 minecraft:dripstone_block
fill 7 285 283 8 285 284 minecraft:dripstone_block
fill 7 285 287 9 285 287 minecraft:dripstone_block
fill 8 285 282 9 285 282 minecraft:dripstone_block
fill 8 285 286 8 286 286 minecraft:dripstone_block
fill 8 285 290 9 285 291 minecraft:dripstone_block
fill 9 285 283 9 286 283 minecraft:dripstone_block
fill 10 285 313 11 285 313 minecraft:dripstone_block
fill 11 285 303 12 285 304 minecraft:dripstone_block
fill 14 285 304 14 285 305 minecraft:dripstone_block
fill 15 285 301 17 285 301 minecraft:dripstone_block
fill 15 285 304 16 285 304 minecraft:dripstone_block
fill 16 285 292 17 286 293 minecraft:dripstone_block
fill 16 285 297 17 285 297 minecraft:dripstone_block
setblock 16 285 300 minecraft:dripstone_block
fill 16 285 302 17 285 303 minecraft:dripstone_block
fill 17 285 283 18 285 284 minecraft:dripstone_block
setblock 17 285 294 minecraft:dripstone_block
fill 17 285 296 17 286 296 minecraft:dripstone_block
setblock 17 285 298 minecraft:dripstone_block
fill 19 285 289 20 285 290 minecraft:dripstone_block
fill 19 285 298 19 286 298 minecraft:dripstone_block
fill 21 285 281 23 285 281 minecraft:dripstone_block
fill 22 285 280 22 286 280 minecraft:dripstone_block
fill 23 285 286 24 286 287 minecraft:dripstone_block
setblock 23 285 296 minecraft:dripstone_block
fill 25 285 284 26 285 285 minecraft:dripstone_block
fill 25 285 303 26 285 303 minecraft:dripstone_block
fill 25 285 305 26 285 306 minecraft:dripstone_block
fill 25 285 308 26 285 310 minecraft:dripstone_block
setblock 26 285 300 minecraft:dripstone_block
setblock 26 285 304 minecraft:dripstone_block
fill 27 285 285 27 285 286 minecraft:dripstone_block
fill 27 285 312 28 285 313 minecraft:dripstone_block
setblock 28 285 285 minecraft:dripstone_block
fill 28 285 288 29 285 288 minecraft:dripstone_block
fill 28 285 305 30 285 305 minecraft:dripstone_block
setblock 29 285 304 minecraft:dripstone_block
fill 29 285 306 30 285 306 minecraft:dripstone_block
fill 29 285 315 30 285 315 minecraft:dripstone_block
fill 30 285 308 31 286 308 minecraft:dripstone_block
fill 32 285 298 32 285 300 minecraft:dripstone_block
fill 33 285 299 33 285 300 minecraft:dripstone_block
fill 34 285 288 35 286 288 minecraft:dripstone_block
fill 34 285 298 36 285 298 minecraft:dripstone_block
setblock 35 285 287 minecraft:dripstone_block
setblock 35 285 289 minecraft:dripstone_block
fill 35 285 299 36 285 299 minecraft:dripstone_block
fill 35 285 315 37 285 315 minecraft:dripstone_block
fill 36 285 314 38 286 314 minecraft:dripstone_block
fill 37 285 313 38 285 313 minecraft:dripstone_block
fill 38 285 317 38 308 317 minecraft:deepslate_tiles
fill 39 285 282 40 285 283 minecraft:dripstone_block
setblock 40 285 317 minecraft:purple_concrete
setblock 0 286 278 minecraft:magma_block
fill 0 286 279 0 308 280 minecraft:deepslate_tiles
setblock 0 286 296 minecraft:crying_obsidian
fill 3 286 298 3 286 299 minecraft:dripstone_block
setblock 4 286 298 minecraft:dripstone_block
fill 8 286 282 8 286 283 minecraft:dripstone_block
fill 8 286 287 8 287 287 minecraft:dripstone_block
fill 11 286 303 11 286 304 minecraft:dripstone_block
setblock 12 286 304 minecraft:dripstone_block
fill 16 286 301 16 286 303 minecraft:dripstone_block
fill 17 286 283 18 286 283 minecraft:dripstone_block
fill 17 286 297 18 286 297 minecraft:dripstone_block
setblock 17 286 301 minecraft:dripstone_block
setblock 18 286 294 minecraft:dripstone_block
fill 19 286 289 20 286 289 minecraft:dripstone_block
setblock 20 286 290 minecraft:dripstone_block
fill 20 286 297 20 287 298 minecraft:dripstone_block
fill 22 286 281 22 287 281 minecraft:dripstone_block
setblock 25 286 284 minecraft:dripstone_block
fill 25 286 309 26 287 309 minecraft:dripstone_block
setblock 26 286 303 minecraft:dripstone_block
setblock 26 286 308 minecraft:dripstone_block
setblock 27 286 285 minecraft:dripstone_block
setblock 27 286 312 minecraft:dripstone_block
fill 29 286 305 29 286 306 minecraft:dripstone_block
setblock 29 286 315 minecraft:dripstone_block
setblock 30 286 305 minecraft:dripstone_block
fill 32 286 291 33 286 292 minecraft:dripstone_block
fill 32 286 299 33 286 299 minecraft:dripstone_block
fill 35 286 298 35 287 299 minecraft:dripstone_block
setblock 36 286 298 minecraft:dripstone_block
fill 36 286 315 36 287 315 minecraft:dripstone_block
setblock 39 286 283 minecraft:dripstone_block
fill 40 286 317 40 308 317 minecraft:deepslate_tiles
fill 0 287 278 0 308 278 minecraft:deepslate_tiles
fill 0 287 296 0 308 296 minecraft:deepslate_tiles
setblock 1 287 275 minecraft:amethyst_block
fill 3 287 298 3 289 298 minecraft:dripstone_block
setblock 8 287 283 minecraft:dripstone_block
fill 16 287 292 16 287 293 minecraft:dripstone_block
fill 16 287 301 16 289 301 minecraft:dripstone_block
setblock 17 287 283 minecraft:dripstone_block
setblock 17 287 293 minecraft:dripstone_block
fill 17 287 297 17 289 297 minecraft:dripstone_block
fill 20 287 289 20 288 289 minecraft:dripstone_block
fill 23 287 286 24 287 286 minecraft:dripstone_block
setblock 24 287 287 minecraft:dripstone_block
fill 29 287 305 29 288 305 minecraft:dripstone_block
fill 32 287 299 32 288 299 minecraft:dripstone_block
fill 33 287 291 33 288 292 minecraft:dripstone_block
setblock 35 287 288 minecraft:dripstone_block
setblock 37 287 314 minecraft:dripstone_block
fill 1 288 275 1 308 275 minecraft:deepslate_tiles
setblock 3 288 278 minecraft:light[level=12]
fill 3 288 285 3 288 286 minecraft:light[level=12]
setblock 3 288 292 minecraft:light[level=12]
setblock 3 288 294 minecraft:light[level=12]
setblock 3 288 299 minecraft:light[level=12]
setblock 3 288 302 minecraft:light[level=12]
setblock 3 288 306 minecraft:light[level=12]
setblock 3 288 310 minecraft:light[level=12]
setblock 3 288 313 minecraft:light[level=12]
fill 10 288 278 11 288 278 minecraft:light[level=12]
setblock 10 288 285 minecraft:light[level=12]
setblock 10 288 292 minecraft:light[level=12]
setblock 10 288 299 minecraft:light[level=12]
setblock 10 288 306 minecraft:light[level=12]
setblock 10 288 313 minecraft:light[level=12]
setblock 11 288 286 minecraft:light[level=12]
setblock 11 288 294 minecraft:light[level=12]
setblock 11 288 302 minecraft:light[level=12]
setblock 11 288 310 minecraft:light[level=12]
fill 16 288 293 16 289 293 minecraft:dripstone_block
setblock 17 288 278 minecraft:light[level=12]
setblock 17 288 285 minecraft:light[level=12]
setblock 17 288 292 minecraft:light[level=12]
setblock 17 288 299 minecraft:light[level=12]
setblock 17 288 306 minecraft:light[level=12]
setblock 17 288 313 minecraft:light[level=12]
setblock 19 288 278 minecraft:light[level=12]
setblock 19 288 286 minecraft:light[level=12]
setblock 19 288 294 minecraft:light[level=12]
setblock 19 288 302 minecraft:light[level=12]
setblock 19 288 310 minecraft:light[level=12]
fill 20 288 298 20 289 298 minecraft:dripstone_block
setblock 24 288 278 minecraft:light[level=12]
setblock 24 288 285 minecraft:light[level=12]
setblock 24 288 292 minecraft:light[level=12]
setblock 24 288 299 minecraft:light[level=12]
setblock 24 288 306 minecraft:light[level=12]
setblock 24 288 313 minecraft:light[level=12]
fill 26 288 309 26 289 309 minecraft:dripstone_block
setblock 27 288 278 minecraft:light[level=12]
setblock 27 288 286 minecraft:light[level=12]
setblock 27 288 294 minecraft:light[level=12]
setblock 27 288 302 minecraft:light[level=12]
setblock 27 288 310 minecraft:light[level=12]
setblock 31 288 278 minecraft:light[level=12]
setblock 31 288 285 minecraft:light[level=12]
setblock 31 288 292 minecraft:light[level=12]
setblock 31 288 299 minecraft:light[level=12]
setblock 31 288 306 minecraft:light[level=12]
setblock 31 288 313 minecraft:light[level=12]
setblock 35 288 278 minecraft:light[level=12]
setblock 35 288 286 minecraft:light[level=12]
setblock 35 288 294 minecraft:light[level=12]
fill 35 288 298 35 289 298 minecraft:dripstone_block
setblock 35 288 302 minecraft:light[level=12]
setblock 35 288 310 minecraft:light[level=12]
setblock 38 288 278 minecraft:light[level=12]
setblock 38 288 285 minecraft:light[level=12]
setblock 38 288 292 minecraft:light[level=12]
setblock 38 288 299 minecraft:light[level=12]
setblock 38 288 306 minecraft:light[level=12]
setblock 38 288 313 minecraft:light[level=12]
setblock 33 289 291 minecraft:dripstone_block
setblock 17 290 275 minecraft:purple_concrete
fill 19 290 277 19 295 277 minecraft:blackstone
setblock 0 291 305 minecraft:purple_concrete
fill 0 291 308 0 308 308 minecraft:deepslate_tiles
setblock 0 291 309 minecraft:magma_block
fill 0 291 310 0 308 313 minecraft:deepslate_tiles
fill 17 291 275 17 308 275 minecraft:deepslate_tiles
fill 0 292 305 0 308 305 minecraft:deepslate_tiles
fill 0 292 309 0 308 309 minecraft:deepslate_tiles
fill 15 292 286 15 293 286 minecraft:amethyst_block
fill 42 292 275 42 308 276 minecraft:deepslate_tiles
setblock 42 292 277 minecraft:magma_block
fill 42 292 278 42 308 278 minecraft:deepslate_tiles
setblock 5 293 275 minecraft:amethyst_block
fill 18 293 277 18 295 277 minecraft:blackstone
fill 19 293 276 19 295 276 minecraft:blackstone
fill 19 293 278 19 295 278 minecraft:blackstone
fill 20 293 277 20 295 277 minecraft:blackstone
fill 35 293 304 35 294 304 minecraft:gold_block
fill 42 293 277 42 308 277 minecraft:deepslate_tiles
fill 3 294 278 3 295 278 minecraft:light[level=12]
setblock 3 294 285 minecraft:light[level=12]
setblock 3 294 292 minecraft:light[level=12]
setblock 3 294 299 minecraft:light[level=12]
setblock 3 294 306 minecraft:light[level=12]
setblock 3 294 313 minecraft:light[level=12]
fill 5 294 275 5 307 275 minecraft:deepslate_tiles
setblock 10 294 278 minecraft:light[level=12]
setblock 10 294 285 minecraft:light[level=12]
setblock 10 294 292 minecraft:light[level=12]
setblock 10 294 299 minecraft:light[level=12]
setblock 10 294 306 minecraft:light[level=12]
setblock 10 294 313 minecraft:light[level=12]
fill 15 294 286 15 300 286 minecraft:blackstone
setblock 17 294 278 minecraft:light[level=12]
setblock 17 294 285 minecraft:light[level=12]
setblock 17 294 292 minecraft:light[level=12]
setblock 17 294 299 minecraft:light[level=12]
setblock 17 294 306 minecraft:light[level=12]
setblock 17 294 313 minecraft:light[level=12]
fill 18 294 276 18 295 276 minecraft:blackstone
fill 18 294 278 18 295 278 minecraft:blackstone
fill 20 294 276 20 295 276 minecraft:blackstone
fill 20 294 278 20 295 278 minecraft:blackstone
setblock 24 294 278 minecraft:light[level=12]
setblock 24 294 285 minecraft:light[level=12]
setblock 24 294 292 minecraft:light[level=12]
setblock 24 294 299 minecraft:light[level=12]
setblock 24 294 306 minecraft:light[level=12]
setblock 24 294 313 minecraft:light[level=12]
setblock 31 294 278 minecraft:light[level=12]
setblock 31 294 285 minecraft:light[level=12]
setblock 31 294 292 minecraft:light[level=12]
setblock 31 294 299 minecraft:light[level=12]
setblock 31 294 306 minecraft:light[level=12]
setblock 31 294 313 minecraft:light[level=12]
setblock 38 294 278 minecraft:light[level=12]
setblock 38 294 285 minecraft:light[level=12]
setblock 38 294 292 minecraft:light[level=12]
setblock 38 294 299 minecraft:light[level=12]
setblock 38 294 306 minecraft:light[level=12]
setblock 38 294 313 minecraft:light[level=12]
setblock 3 295 286 minecraft:light[level=12]
setblock 3 295 294 minecraft:light[level=12]
setblock 3 295 302 minecraft:light[level=12]
setblock 3 295 310 minecraft:light[level=12]
setblock 11 295 278 minecraft:light[level=12]
setblock 11 295 286 minecraft:light[level=12]
setblock 11 295 294 minecraft:light[level=12]
setblock 11 295 302 minecraft:light[level=12]
setblock 11 295 310 minecraft:light[level=12]
fill 15 295 287 15 300 287 minecraft:blackstone
fill 16 295 286 16 300 286 minecraft:blackstone
setblock 17 295 277 minecraft:blackstone
setblock 19 295 279 minecraft:blackstone
setblock 19 295 286 minecraft:light[level=12]
setblock 19 295 294 minecraft:light[level=12]
setblock 19 295 302 minecraft:light[level=12]
setblock 19 295 310 minecraft:light[level=12]
setblock 21 295 277 minecraft:blackstone
setblock 27 295 278 minecraft:light[level=12]
setblock 27 295 286 minecraft:light[level=12]
setblock 27 295 294 minecraft:light[level=12]
setblock 27 295 302 minecraft:light[level=12]
setblock 27 295 310 minecraft:light[level=12]
setblock 35 295 278 minecraft:light[level=12]
setblock 35 295 286 minecraft:light[level=12]
setblock 35 295 294 minecraft:light[level=12]
setblock 35 295 302 minecraft:light[level=12]
setblock 35 295 310 minecraft:light[level=12]
fill 0 296 282 0 308 282 minecraft:deepslate_tiles
setblock 0 296 283 minecraft:magma_block
fill 0 296 284 0 308 285 minecraft:deepslate_tiles
fill 16 296 287 16 300 287 minecraft:blackstone
fill 0 297 283 0 308 283 minecraft:deepslate_tiles
fill 14 297 286 14 300 287 minecraft:blackstone
fill 15 297 285 16 300 285 minecraft:blackstone
fill 14 298 285 14 300 285 minecraft:blackstone
fill 15 298 288 16 300 288 minecraft:blackstone
fill 17 298 285 17 300 287 minecraft:blackstone
fill 13 299 286 13 300 287 minecraft:blackstone
fill 14 299 288 14 300 288 minecraft:blackstone
fill 15 299 284 16 300 284 minecraft:blackstone
fill 17 299 288 17 300 288 minecraft:blackstone
fill 0 300 275 0 308 275 minecraft:deepslate_tiles
setblock 0 300 276 minecraft:magma_block
setblock 3 300 278 minecraft:light[level=12]
setblock 3 300 285 minecraft:light[level=12]
setblock 3 300 292 minecraft:light[level=12]
setblock 3 300 299 minecraft:light[level=12]
setblock 3 300 306 minecraft:light[level=12]
setblock 3 300 313 minecraft:light[level=12]
setblock 10 300 278 minecraft:light[level=12]
setblock 10 300 285 minecraft:light[level=12]
setblock 10 300 292 minecraft:light[level=12]
setblock 10 300 299 minecraft:light[level=12]
setblock 10 300 306 minecraft:light[level=12]
setblock 10 300 313 minecraft:light[level=12]
setblock 13 300 285 minecraft:blackstone
setblock 13 300 288 minecraft:blackstone
setblock 14 300 284 minecraft:blackstone
fill 15 300 289 16 300 289 minecraft:blackstone
setblock 17 300 278 minecraft:light[level=12]
setblock 17 300 284 minecraft:blackstone
setblock 17 300 292 minecraft:light[level=12]
setblock 17 300 299 minecraft:light[level=12]
setblock 17 300 306 minecraft:light[level=12]
setblock 17 300 313 minecraft:light[level=12]
fill 18 300 285 18 300 287 minecraft:blackstone
setblock 22 300 275 minecraft:amethyst_block
setblock 24 300 278 minecraft:light[level=12]
setblock 24 300 285 minecraft:light[level=12]
setblock 24 300 292 minecraft:light[level=12]
setblock 24 300 299 minecraft:light[level=12]
setblock 24 300 306 minecraft:light[level=12]
setblock 24 300 313 minecraft:light[level=12]
setblock 31 300 278 minecraft:light[level=12]
setblock 31 300 285 minecraft:light[level=12]
setblock 31 300 292 minecraft:light[level=12]
setblock 31 300 299 minecraft:light[level=12]
setblock 31 300 306 minecraft:light[level=12]
setblock 31 300 313 minecraft:light[level=12]
setblock 38 300 278 minecraft:light[level=12]
setblock 38 300 285 minecraft:light[level=12]
setblock 38 300 292 minecraft:light[level=12]
setblock 38 300 299 minecraft:light[level=12]
setblock 38 300 306 minecraft:light[level=12]
setblock 38 300 313 minecraft:light[level=12]
setblock 42 300 290 minecraft:amethyst_block
fill 42 300 291 42 308 292 minecraft:deepslate_tiles
fill 42 300 303 42 308 303 minecraft:deepslate_tiles
setblock 42 300 304 minecraft:magma_block
fill 0 301 276 0 308 276 minecraft:deepslate_tiles
fill 22 301 275 22 308 275 minecraft:deepslate_tiles
fill 42 301 290 42 308 290 minecraft:deepslate_tiles
fill 42 301 304 42 308 304 minecraft:deepslate_tiles
setblock 0 302 288 minecraft:crying_obsidian
setblock 3 302 278 minecraft:light[level=12]
setblock 3 302 286 minecraft:light[level=12]
setblock 3 302 294 minecraft:light[level=12]
setblock 3 302 302 minecraft:light[level=12]
setblock 3 302 310 minecraft:light[level=12]
setblock 11 302 278 minecraft:light[level=12]
setblock 11 302 286 minecraft:light[level=12]
setblock 11 302 294 minecraft:light[level=12]
setblock 11 302 302 minecraft:light[level=12]
setblock 11 302 310 minecraft:light[level=12]
setblock 19 302 278 minecraft:light[level=12]
setblock 19 302 286 minecraft:light[level=12]
setblock 19 302 294 minecraft:light[level=12]
setblock 19 302 302 minecraft:light[level=12]
setblock 19 302 310 minecraft:light[level=12]
setblock 27 302 278 minecraft:light[level=12]
setblock 27 302 286 minecraft:light[level=12]
setblock 27 302 294 minecraft:light[level=12]
setblock 27 302 302 minecraft:light[level=12]
setblock 27 302 310 minecraft:light[level=12]
setblock 35 302 278 minecraft:light[level=12]
setblock 35 302 286 minecraft:light[level=12]
setblock 35 302 294 minecraft:light[level=12]
setblock 35 302 302 minecraft:light[level=12]
setblock 35 302 310 minecraft:light[level=12]
fill 0 303 288 0 308 288 minecraft:deepslate_tiles
fill 42 304 305 42 308 308 minecraft:deepslate_tiles
setblock 42 304 309 minecraft:crying_obsidian
setblock 0 305 299 minecraft:crying_obsidian
setblock 26 305 317 minecraft:purple_concrete
fill 42 305 309 42 308 309 minecraft:deepslate_tiles
fill 0 306 299 0 308 299 minecraft:deepslate_tiles
fill 26 306 317 26 308 317 minecraft:deepslate_tiles
setblock 0 307 303 minecraft:crying_obsidian
setblock 4 307 275 minecraft:magma_block
setblock 0 308 303 minecraft:deepslate_tiles
setblock 4 308 275 minecraft:deepslate_tiles
setblock 5 308 275 minecraft:amethyst_block
setblock 8 308 317 minecraft:amethyst_block
setblock 9 308 317 minecraft:deepslate_tiles
