fill 341 106 245 345 107 245 minecraft:iron_block
setblock 341 106 246 minecraft:black_concrete
fill 341 106 247 343 107 248 minecraft:iron_block
fill 341 106 249 342 106 249 minecraft:black_concrete
fill 341 106 251 342 106 251 minecraft:black_concrete
fill 341 106 252 343 107 253 minecraft:iron_block
setblock 341 106 254 minecraft:black_concrete
fill 341 106 255 345 107 255 minecraft:iron_block
fill 341 106 260 344 106 260 minecraft:iron_block
fill 342 106 242 342 106 243 minecraft:black_concrete
fill 342 106 246 352 106 246 minecraft:iron_block
fill 342 106 254 352 106 254 minecraft:iron_block
fill 342 106 257 342 106 258 minecraft:black_concrete
fill 343 106 242 351 107 243 minecraft:iron_block
setblock 343 106 244 minecraft:black_concrete
fill 343 106 249 344 106 249 minecraft:iron_block
fill 343 106 251 344 106 251 minecraft:iron_block
setblock 343 106 256 minecraft:black_concrete
fill 343 106 257 351 107 258 minecraft:iron_block
fill 344 106 244 345 107 244 minecraft:iron_block
setblock 344 106 247 minecraft:iron_block
setblock 344 106 248 minecraft:black_concrete
setblock 344 106 252 minecraft:black_concrete
setblock 344 106 253 minecraft:iron_block
fill 344 106 256 345 107 256 minecraft:iron_block
fill 345 106 240 345 106 241 minecraft:black_concrete
setblock 345 106 247 minecraft:black_concrete
setblock 345 106 253 minecraft:black_concrete
fill 345 106 259 345 106 260 minecraft:black_concrete
fill 346 106 240 348 107 241 minecraft:iron_block
fill 346 106 244 346 106 245 minecraft:black_concrete
setblock 346 106 247 minecraft:iron_block
setblock 346 106 253 minecraft:iron_block
fill 346 106 255 346 106 256 minecraft:black_concrete
fill 346 106 259 348 107 260 minecraft:iron_block
fill 347 106 244 347 107 245 minecraft:iron_block
fill 347 106 255 347 107 256 minecraft:iron_block
fill 348 106 244 348 106 245 minecraft:black_concrete
setblock 348 106 247 minecraft:iron_block
setblock 348 106 253 minecraft:iron_block
fill 348 106 255 348 106 256 minecraft:black_concrete
fill 349 106 240 349 106 241 minecraft:black_concrete
fill 349 106 244 350 107 245 minecraft:iron_block
setblock 349 106 247 minecraft:black_concrete
setblock 349 106 253 minecraft:black_concrete
fill 349 106 255 350 107 256 minecraft:iron_block
fill 349 106 259 349 106 260 minecraft:black_concrete
fill 350 106 240 353 106 241 minecraft:iron_block
fill 350 106 247 358 106 247 minecraft:iron_block
setblock 350 106 248 minecraft:black_concrete
fill 350 106 249 351 106 249 minecraft:iron_block
fill 350 106 251 351 106 251 minecraft:iron_block
setblock 350 106 252 minecraft:black_concrete
fill 350 106 253 358 106 253 minecraft:iron_block
fill 350 106 259 353 106 260 minecraft:iron_block
setblock 351 106 244 minecraft:black_concrete
fill 351 106 245 353 107 245 minecraft:iron_block
fill 351 106 248 355 107 248 minecraft:iron_block
fill 351 106 252 355 107 252 minecraft:iron_block
fill 351 106 255 353 107 255 minecraft:iron_block
setblock 351 106 256 minecraft:black_concrete
fill 352 106 242 352 106 243 minecraft:black_concrete
fill 352 106 244 357 106 244 minecraft:iron_block
fill 352 106 249 353 106 249 minecraft:black_concrete
fill 352 106 251 353 106 251 minecraft:black_concrete
fill 352 106 256 357 106 256 minecraft:iron_block
fill 352 106 257 352 106 258 minecraft:black_concrete
fill 353 106 242 355 106 243 minecraft:iron_block
setblock 353 106 246 minecraft:black_concrete
setblock 353 106 254 minecraft:black_concrete
fill 353 106 257 355 106 258 minecraft:iron_block
setblock 354 106 241 minecraft:iron_block
fill 354 106 245 355 106 245 minecraft:black_concrete
fill 354 106 246 358 106 246 minecraft:iron_block
fill 354 106 249 358 106 249 minecraft:iron_block
fill 354 106 251 358 106 251 minecraft:iron_block
fill 354 106 254 358 106 254 minecraft:iron_block
fill 354 106 255 355 106 255 minecraft:black_concrete
setblock 354 106 259 minecraft:iron_block
setblock 356 106 243 minecraft:iron_block
fill 356 106 245 357 106 245 minecraft:iron_block
fill 356 106 248 357 106 248 minecraft:black_concrete
fill 356 106 252 357 106 252 minecraft:black_concrete
fill 356 106 255 357 106 255 minecraft:iron_block
setblock 356 106 257 minecraft:iron_block
setblock 358 106 248 minecraft:iron_block
setblock 358 106 252 minecraft:iron_block
fill 359 106 228 359 280 228 minecraft:stone_bricks
fill 370 106 228 370 120 228 minecraft:stone_bricks
setblock 371 106 268 minecraft:cobblestone
setblock 330 107 229 minecraft:lime_terracotta
setblock 330 107 230 minecraft:stone_bricks
setblock 330 107 231 minecraft:mossy_cobblestone
fill 330 107 232 330 107 234 minecraft:stone_bricks
setblock 330 107 235 minecraft:mossy_cobblestone
fill 330 107 236 330 107 238 minecraft:stone_bricks
setblock 330 107 239 minecraft:mossy_cobblestone
fill 330 107 240 330 107 242 minecraft:stone_bricks
setblock 330 107 243 minecraft:mossy_cobblestone
fill 330 107 244 330 107 246 minecraft:stone_bricks
setblock 330 107 247 minecraft:mossy_cobblestone
fill 330 107 248 330 107 250 minecraft:stone_bricks
setblock 330 107 251 minecraft:mossy_cobblestone
fill 330 107 252 330 107 254 minecraft:stone_bricks
setblock 330 107 255 minecraft:mossy_cobblestone
fill 330 107 256 330 107 258 minecraft:stone_bricks
setblock 330 107 259 minecraft:mossy_cobblestone
fill 330 107 260 330 107 262 minecraft:stone_bricks
setblock 330 107 263 minecraft:mossy_cobblestone
fill 330 107 264 330 107 266 minecraft:stone_bricks
setblock 330 107 267 minecraft:mossy_cobblestone
fill 330 107 268 331 107 269 minecraft:stone_bricks
setblock 331 107 229 minecraft:stone_bricks
setblock 331 107 230 minecraft:mossy_cobblestone
fill 331 107 231 331 107 233 minecraft:stone_bricks
setblock 331 107 234 minecraft:mossy_cobblestone
fill 331 107 235 331 107 237 minecraft:stone_bricks
setblock 331 107 238 minecraft:mossy_cobblestone
fill 331 107 239 331 107 241 minecraft:stone_bricks
setblock 331 107 242 minecraft:mossy_cobblestone
fill 331 107 243 331 107 245 minecraft:stone_bricks
setblock 331 107 246 minecraft:mossy_cobblestone
fill 331 107 247 331 107 249 minecraft:stone_bricks
setblock 331 107 250 minecraft:mossy_cobblestone
fill 331 107 251 331 107 253 minecraft:stone_bricks
setblock 331 107 254 minecraft:mossy_cobblestone
fill 331 107 255 331 107 257 minecraft:stone_bricks
setblock 331 107 258 minecraft:mossy_cobblestone
fill 331 107 259 331 107 261 minecraft:stone_bricks
setblock 331 107 262 minecraft:mossy_cobblestone
fill 331 107 263 331 107 265 minecraft:stone_bricks
setblock 331 107 266 minecraft:mossy_cobblestone
fill 331 107 267 333 107 267 minecraft:stone_bricks
setblock 332 107 229 minecraft:mossy_cobblestone
fill 332 107 230 332 107 232 minecraft:stone_bricks
setblock 332 107 233 minecraft:mossy_cobblestone
fill 332 107 234 332 107 236 minecraft:stone_bricks
setblock 332 107 237 minecraft:mossy_cobblestone
fill 332 107 238 332 107 240 minecraft:stone_bricks
setblock 332 107 241 minecraft:mossy_cobblestone
fill 332 107 242 332 107 244 minecraft:stone_bricks
setblock 332 107 245 minecraft:mossy_cobblestone
fill 332 107 246 332 107 248 minecraft:stone_bricks
setblock 332 107 249 minecraft:mossy_cobblestone
fill 332 107 250 332 107 252 minecraft:stone_bricks
setblock 332 107 253 minecraft:mossy_cobblestone
fill 332 107 254 332 107 256 minecraft:stone_bricks
setblock 332 107 257 minecraft:mossy_cobblestone
fill 332 107 258 332 107 260 minecraft:stone_bricks
setblock 332 107 261 minecraft:mossy_cobblestone
fill 332 107 262 332 107 264 minecraft:stone_bricks
setblock 332 107 265 minecraft:mossy_cobblestone
fill 332 107 266 334 107 266 minecraft:stone_bricks
setblock 332 107 268 minecraft:stone_bricks
setblock 332 107 269 minecraft:mossy_cobblestone
fill 333 107 229 333 107 231 minecraft:stone_bricks
setblock 333 107 232 minecraft:mossy_cobblestone
fill 333 107 233 333 107 235 minecraft:stone_bricks
setblock 333 107 236 minecraft:mossy_cobblestone
fill 333 107 237 333 107 239 minecraft:stone_bricks
setblock 333 107 240 minecraft:mossy_cobblestone
fill 333 107 241 333 107 243 minecraft:stone_bricks
setblock 333 107 244 minecraft:mossy_cobblestone
fill 333 107 245 333 107 247 minecraft:stone_bricks
setblock 333 107 248 minecraft:mossy_cobblestone
fill 333 107 249 333 107 251 minecraft:stone_bricks
setblock 333 107 252 minecraft:mossy_cobblestone
fill 333 107 253 333 107 255 minecraft:stone_bricks
setblock 333 107 256 minecraft:mossy_cobblestone
fill 333 107 257 333 107 259 minecraft:stone_bricks
setblock 333 107 260 minecraft:mossy_cobblestone
fill 333 107 261 333 107 263 minecraft:stone_bricks
setblock 333 107 264 minecraft:mossy_cobblestone
fill 333 107 265 335 107 265 minecraft:stone_bricks
setblock 333 107 268 minecraft:mossy_cobblestone
fill 333 107 269 335 107 269 minecraft:stone_bricks
fill 334 107 229 334 107 230 minecraft:stone_bricks
setblock 334 107 231 minecraft:mossy_cobblestone
fill 334 107 232 334 107 234 minecraft:stone_bricks
setblock 334 107 235 minecraft:mossy_cobblestone
fill 334 107 236 334 107 238 minecraft:stone_bricks
setblock 334 107 239 minecraft:mossy_cobblestone
fill 334 107 240 334 107 242 minecraft:stone_bricks
setblock 334 107 243 minecraft:mossy_cobblestone
fill 334 107 244 334 107 246 minecraft:stone_bricks
setblock 334 107 247 minecraft:mossy_cobblestone
fill 334 107 248 334 107 250 minecraft:stone_bricks
setblock 334 107 251 minecraft:mossy_cobblestone
fill 334 107 252 334 107 254 minecraft:stone_bricks
setblock 334 107 255 minecraft:mossy_cobblestone
fill 334 107 256 334 107 258 minecraft:stone_bricks
setblock 334 107 259 minecraft:mossy_cobblestone
fill 334 107 260 334 107 262 minecraft:stone_bricks
setblock 334 107 263 minecraft:mossy_cobblestone
fill 334 107 264 336 107 264 minecraft:stone_bricks
setblock 334 107 267 minecraft:mossy_cobblestone
fill 334 107 268 336 107 268 minecraft:stone_bricks
setblock 335 107 229 minecraft:stone_bricks
setblock 335 107 230 minecraft:mossy_cobblestone
fill 335 107 231 335 107 233 minecraft:stone_bricks
setblock 335 107 234 minecraft:mossy_cobblestone
fill 335 107 235 335 107 237 minecraft:stone_bricks
setblock 335 107 238 minecraft:mossy_cobblestone
fill 335 107 239 335 107 241 minecraft:stone_bricks
setblock 335 107 242 minecraft:mossy_cobblestone
fill 335 107 243 335 107 245 minecraft:stone_bricks
setblock 335 107 246 minecraft:mossy_cobblestone
fill 335 107 247 335 107 249 minecraft:stone_bricks
fill 335 107 250 335 108 250 minecraft:gray_concrete
fill 335 107 251 335 107 253 minecraft:stone_bricks
setblock 335 107 254 minecraft:mossy_cobblestone
fill 335 107 255 335 107 257 minecraft:stone_bricks
setblock 335 107 258 minecraft:mossy_cobblestone
fill 335 107 259 335 107 261 minecraft:stone_bricks
setblock 335 107 262 minecraft:mossy_cobblestone
fill 335 107 263 337 107 263 minecraft:stone_bricks
setblock 335 107 266 minecraft:mossy_cobblestone
fill 335 107 267 337 107 267 minecraft:stone_bricks
setblock 336 107 229 minecraft:mossy_cobblestone
fill 336 107 230 336 107 232 minecraft:stone_bricks
setblock 336 107 233 minecraft:mossy_cobblestone
fill 336 107 234 336 107 236 minecraft:stone_bricks
setblock 336 107 237 minecraft:mossy_cobblestone
fill 336 107 238 336 107 240 minecraft:stone_bricks
setblock 336 107 241 minecraft:mossy_cobblestone
fill 336 107 242 336 107 244 minecraft:stone_bricks
setblock 336 107 245 minecraft:mossy_cobblestone
fill 336 107 246 336 108 249 minecraft:gray_concrete
fill 336 107 250 342 107 250 minecraft:iron_block
fill 336 107 251 336 108 254 minecraft:gray_concrete
fill 336 107 255 336 107 256 minecraft:stone_bricks
setblock 336 107 257 minecraft:mossy_cobblestone
fill 336 107 258 336 107 260 minecraft:stone_bricks
setblock 336 107 261 minecraft:mossy_cobblestone
fill 336 107 262 338 107 262 minecraft:stone_bricks
setblock 336 107 265 minecraft:mossy_cobblestone
fill 336 107 266 338 107 266 minecraft:stone_bricks
setblock 336 107 269 minecraft:mossy_cobblestone
fill 337 107 229 337 107 231 minecraft:stone_bricks
setblock 337 107 232 minecraft:mossy_cobblestone
fill 337 107 233 337 107 235 minecraft:stone_bricks
setblock 337 107 236 minecraft:mossy_cobblestone
fill 337 107 237 337 107 239 minecraft:stone_bricks
setblock 337 107 240 minecraft:mossy_cobblestone
fill 337 107 241 337 107 243 minecraft:stone_bricks
fill 337 107 244 337 108 245 minecraft:gray_concrete
fill 337 107 246 338 107 247 minecraft:iron_block
setblock 337 107 248 minecraft:mossy_cobblestone
setblock 337 107 252 minecraft:mossy_cobblestone
fill 337 107 253 338 107 254 minecraft:iron_block
fill 337 107 255 337 108 256 minecraft:gray_concrete
fill 337 107 257 337 107 259 minecraft:stone_bricks
setblock 337 107 260 minecraft:mossy_cobblestone
fill 337 107 261 339 107 261 minecraft:stone_bricks
setblock 337 107 264 minecraft:mossy_cobblestone
fill 337 107 265 339 107 265 minecraft:stone_bricks
setblock 337 107 268 minecraft:mossy_cobblestone
fill 337 107 269 339 107 269 minecraft:stone_bricks
fill 338 107 229 338 107 230 minecraft:stone_bricks
setblock 338 107 231 minecraft:mossy_cobblestone
fill 338 107 232 338 107 234 minecraft:stone_bricks
setblock 338 107 235 minecraft:mossy_cobblestone
fill 338 107 236 338 107 238 minecraft:stone_bricks
setblock 338 107 239 minecraft:mossy_cobblestone
fill 338 107 240 338 107 242 minecraft:stone_bricks
fill 338 107 243 338 108 243 minecraft:gray_concrete
fill 338 107 244 338 107 245 minecraft:iron_block
setblock 338 107 248 minecraft:stone_bricks
setblock 338 107 252 minecraft:stone_bricks
fill 338 107 255 338 107 256 minecraft:iron_block
fill 338 107 257 338 108 257 minecraft:gray_concrete
setblock 338 107 258 minecraft:stone_bricks
setblock 338 107 259 minecraft:mossy_cobblestone
fill 338 107 260 340 107 260 minecraft:stone_bricks
setblock 338 107 263 minecraft:mossy_cobblestone
fill 338 107 264 340 107 264 minecraft:stone_bricks
setblock 338 107 267 minecraft:mossy_cobblestone
fill 338 107 268 340 107 268 minecraft:stone_bricks
setblock 339 107 229 minecraft:stone_bricks
setblock 339 107 230 minecraft:mossy_cobblestone
fill 339 107 231 339 107 233 minecraft:stone_bricks
setblock 339 107 234 minecraft:mossy_cobblestone
fill 339 107 235 339 107 237 minecraft:stone_bricks
setblock 339 107 238 minecraft:mossy_cobblestone
fill 339 107 239 339 107 241 minecraft:stone_bricks
fill 339 107 242 339 108 242 minecraft:gray_concrete
fill 339 107 243 341 107 243 minecraft:iron_block
setblock 339 107 245 minecraft:stone_bricks
fill 339 107 255 340 107 255 minecraft:stone_bricks
fill 339 107 257 341 107 257 minecraft:iron_block
fill 339 107 258 339 108 258 minecraft:gray_concrete
setblock 339 107 259 minecraft:stone_bricks
setblock 339 107 262 minecraft:mossy_cobblestone
fill 339 107 263 341 107 263 minecraft:stone_bricks
setblock 339 107 266 minecraft:mossy_cobblestone
fill 339 107 267 341 107 267 minecraft:stone_bricks
setblock 340 107 229 minecraft:mossy_cobblestone
fill 340 107 230 340 107 232 minecraft:stone_bricks
setblock 340 107 233 minecraft:mossy_cobblestone
fill 340 107 234 340 107 236 minecraft:stone_bricks
setblock 340 107 237 minecraft:mossy_cobblestone
fill 340 107 238 340 107 240 minecraft:stone_bricks
fill 340 107 241 340 108 241 minecraft:gray_concrete
fill 340 107 242 341 107 242 minecraft:iron_block
setblock 340 107 245 minecraft:mossy_cobblestone
fill 340 107 258 341 107 258 minecraft:iron_block
fill 340 107 259 340 108 259 minecraft:gray_concrete
setblock 340 107 261 minecraft:mossy_cobblestone
fill 340 107 262 342 107 262 minecraft:stone_bricks
setblock 340 107 265 minecraft:mossy_cobblestone
fill 340 107 266 342 107 266 minecraft:stone_bricks
setblock 340 107 269 minecraft:mossy_cobblestone
fill 341 107 229 341 107 231 minecraft:stone_bricks
setblock 341 107 232 minecraft:mossy_cobblestone
fill 341 107 233 341 107 235 minecraft:stone_bricks
setblock 341 107 236 minecraft:mossy_cobblestone
fill 341 107 237 341 107 239 minecraft:stone_bricks
fill 341 107 240 342 108 240 minecraft:gray_concrete
fill 341 107 241 344 107 241 minecraft:iron_block
setblock 341 107 246 minecraft:stone_bricks
fill 341 107 249 342 107 249 minecraft:stone_bricks
setblock 341 107 251 minecraft:stone_bricks
setblock 341 107 254 minecraft:stone_bricks
fill 341 107 259 344 107 259 minecraft:iron_block
fill 341 107 260 342 108 260 minecraft:gray_concrete
fill 341 107 261 342 107 261 minecraft:stone_bricks
setblock 341 107 264 minecraft:mossy_cobblestone
fill 341 107 265 343 107 265 minecraft:stone_bricks
setblock 341 107 268 minecraft:mossy_cobblestone
fill 341 107 269 343 107 269 minecraft:stone_bricks
fill 342 107 229 342 107 230 minecraft:stone_bricks
setblock 342 107 231 minecraft:mossy_cobblestone
fill 342 107 232 342 107 234 minecraft:stone_bricks
setblock 342 107 235 minecraft:mossy_cobblestone
fill 342 107 236 342 107 238 minecraft:stone_bricks
setblock 342 107 239 minecraft:mossy_cobblestone
setblock 342 107 242 minecraft:stone_bricks
setblock 342 107 243 minecraft:mossy_cobblestone
fill 342 107 246 345 107 246 minecraft:iron_block
setblock 342 107 251 minecraft:mossy_cobblestone
fill 342 107 254 345 107 254 minecraft:iron_block
fill 342 107 257 342 107 258 minecraft:stone_bricks
setblock 342 107 263 minecraft:mossy_cobblestone
fill 342 107 264 344 107 264 minecraft:stone_bricks
setblock 342 107 267 minecraft:mossy_cobblestone
fill 342 107 268 344 107 268 minecraft:stone_bricks
setblock 343 107 229 minecraft:stone_bricks
setblock 343 107 230 minecraft:mossy_cobblestone
fill 343 107 231 343 107 233 minecraft:stone_bricks
setblock 343 107 234 minecraft:mossy_cobblestone
fill 343 107 235 343 107 237 minecraft:stone_bricks
setblock 343 107 238 minecraft:mossy_cobblestone
fill 343 107 239 346 108 239 minecraft:gray_concrete
fill 343 107 240 344 107 240 minecraft:iron_block
setblock 343 107 244 minecraft:stone_bricks
fill 343 107 249 343 107 251 minecraft:sea_lantern
setblock 343 107 256 minecraft:stone_bricks
fill 343 107 260 344 107 260 minecraft:iron_block
fill 343 107 261 346 108 261 minecraft:gray_concrete
setblock 343 107 262 minecraft:mossy_cobblestone
fill 343 107 263 345 107 263 minecraft:stone_bricks
setblock 343 107 266 minecraft:mossy_cobblestone
fill 343 107 267 345 107 267 minecraft:stone_bricks
setblock 344 107 229 minecraft:mossy_cobblestone
fill 344 107 230 344 107 232 minecraft:stone_bricks
setblock 344 107 233 minecraft:mossy_cobblestone
fill 344 107 234 344 107 236 minecraft:stone_bricks
setblock 344 107 237 minecraft:mossy_cobblestone
fill 344 107 238 346 107 238 minecraft:stone_bricks
fill 344 107 247 344 107 249 minecraft:sea_lantern
fill 344 107 251 344 107 253 minecraft:sea_lantern
fill 344 107 262 346 107 262 minecraft:stone_bricks
setblock 344 107 265 minecraft:mossy_cobblestone
fill 344 107 266 346 107 266 minecraft:stone_bricks
setblock 344 107 269 minecraft:mossy_cobblestone
fill 345 107 229 345 107 231 minecraft:stone_bricks
setblock 345 107 232 minecraft:mossy_cobblestone
fill 345 107 233 345 107 235 minecraft:stone_bricks
setblock 345 107 236 minecraft:mossy_cobblestone
fill 345 107 237 347 107 237 minecraft:stone_bricks
setblock 345 107 240 minecraft:mossy_cobblestone
setblock 345 107 241 minecraft:stone_bricks
fill 345 107 247 346 107 247 minecraft:sea_lantern
fill 345 107 253 346 107 253 minecraft:sea_lantern
setblock 345 107 259 minecraft:stone_bricks
setblock 345 107 260 minecraft:mossy_cobblestone
setblock 345 107 264 minecraft:mossy_cobblestone
fill 345 107 265 347 107 265 minecraft:stone_bricks
setblock 345 107 268 minecraft:mossy_cobblestone
fill 345 107 269 347 107 269 minecraft:stone_bricks
fill 346 107 229 346 107 230 minecraft:stone_bricks
setblock 346 107 231 minecraft:mossy_cobblestone
fill 346 107 232 346 107 234 minecraft:stone_bricks
setblock 346 107 235 minecraft:mossy_cobblestone
fill 346 107 236 348 107 236 minecraft:stone_bricks
fill 346 107 244 346 107 245 minecraft:stone_bricks
fill 346 107 246 348 107 246 minecraft:sea_lantern
fill 346 107 254 348 107 254 minecraft:sea_lantern
setblock 346 107 255 minecraft:mossy_cobblestone
setblock 346 107 256 minecraft:stone_bricks
setblock 346 107 263 minecraft:mossy_cobblestone
fill 346 107 264 348 107 264 minecraft:stone_bricks
setblock 346 107 267 minecraft:mossy_cobblestone
fill 346 107 268 348 107 268 minecraft:stone_bricks
setblock 347 107 229 minecraft:stone_bricks
setblock 347 107 230 minecraft:mossy_cobblestone
fill 347 107 231 347 107 233 minecraft:stone_bricks
setblock 347 107 234 minecraft:mossy_cobblestone
fill 347 107 235 349 107 235 minecraft:stone_bricks
fill 347 107 238 347 108 238 minecraft:gray_concrete
setblock 347 107 239 minecraft:iron_block
setblock 347 107 261 minecraft:iron_block
fill 347 107 262 347 108 262 minecraft:gray_concrete
fill 347 107 263 349 107 263 minecraft:stone_bricks
setblock 347 107 266 minecraft:mossy_cobblestone
fill 347 107 267 349 107 267 minecraft:stone_bricks
setblock 348 107 229 minecraft:mossy_cobblestone
fill 348 107 230 348 107 232 minecraft:stone_bricks
setblock 348 107 233 minecraft:mossy_cobblestone
fill 348 107 234 350 107 234 minecraft:stone_bricks
setblock 348 107 237 minecraft:mossy_cobblestone
fill 348 107 238 350 107 238 minecraft:stone_bricks
fill 348 107 239 351 108 239 minecraft:gray_concrete
setblock 348 107 244 minecraft:stone_bricks
setblock 348 107 245 minecraft:mossy_cobblestone
fill 348 107 247 350 107 247 minecraft:sea_lantern
fill 348 107 253 350 107 253 minecraft:sea_lantern
fill 348 107 255 348 107 256 minecraft:stone_bricks
fill 348 107 261 351 108 261 minecraft:gray_concrete
fill 348 107 262 350 107 262 minecraft:stone_bricks
setblock 348 107 265 minecraft:mossy_cobblestone
fill 348 107 266 350 107 266 minecraft:stone_bricks
setblock 348 107 269 minecraft:mossy_cobblestone
fill 349 107 229 349 107 231 minecraft:stone_bricks
setblock 349 107 232 minecraft:mossy_cobblestone
fill 349 107 233 351 107 233 minecraft:stone_bricks
setblock 349 107 236 minecraft:mossy_cobblestone
fill 349 107 237 351 107 237 minecraft:stone_bricks
setblock 349 107 240 minecraft:mossy_cobblestone
setblock 349 107 241 minecraft:stone_bricks
fill 349 107 246 352 107 246 minecraft:iron_block
fill 349 107 254 352 107 254 minecraft:iron_block
setblock 349 107 259 minecraft:stone_bricks
setblock 349 107 260 minecraft:mossy_cobblestone
setblock 349 107 264 minecraft:mossy_cobblestone
fill 349 107 265 351 107 265 minecraft:stone_bricks
setblock 349 107 268 minecraft:mossy_cobblestone
fill 349 107 269 351 107 269 minecraft:stone_bricks
fill 350 107 229 350 107 230 minecraft:stone_bricks
setblock 350 107 231 minecraft:mossy_cobblestone
fill 350 107 232 352 107 232 minecraft:stone_bricks
setblock 350 107 235 minecraft:mossy_cobblestone
fill 350 107 236 352 107 236 minecraft:stone_bricks
fill 350 107 240 351 107 241 minecraft:iron_block
fill 350 107 248 350 107 249 minecraft:sea_lantern
fill 350 107 251 350 107 252 minecraft:sea_lantern
fill 350 107 259 351 107 260 minecraft:iron_block
setblock 350 107 263 minecraft:mossy_cobblestone
fill 350 107 264 352 107 264 minecraft:stone_bricks
setblock 350 107 267 minecraft:mossy_cobblestone
fill 350 107 268 352 107 268 minecraft:stone_bricks
setblock 351 107 229 minecraft:stone_bricks
setblock 351 107 230 minecraft:mossy_cobblestone
fill 351 107 231 353 107 231 minecraft:stone_bricks
setblock 351 107 234 minecraft:mossy_cobblestone
fill 351 107 235 353 107 235 minecraft:stone_bricks
setblock 351 107 238 minecraft:mossy_cobblestone
setblock 351 107 244 minecraft:stone_bricks
fill 351 107 247 357 107 247 minecraft:iron_block
fill 351 107 249 351 107 251 minecraft:sea_lantern
fill 351 107 253 357 107 253 minecraft:iron_block
setblock 351 107 256 minecraft:stone_bricks
setblock 351 107 262 minecraft:mossy_cobblestone
fill 351 107 263 353 107 263 minecraft:stone_bricks
setblock 351 107 266 minecraft:mossy_cobblestone
fill 351 107 267 353 107 267 minecraft:stone_bricks
setblock 352 107 229 minecraft:mossy_cobblestone
fill 352 107 230 354 107 230 minecraft:stone_bricks
setblock 352 107 233 minecraft:mossy_cobblestone
fill 352 107 234 354 107 234 minecraft:stone_bricks
setblock 352 107 237 minecraft:mossy_cobblestone
fill 352 107 238 353 107 239 minecraft:stone_bricks
fill 352 107 240 353 108 240 minecraft:gray_concrete
fill 352 107 241 353 107 241 minecraft:iron_block
fill 352 107 242 352 107 243 minecraft:stone_bricks
fill 352 107 244 356 107 244 minecraft:iron_block
setblock 352 107 249 minecraft:mossy_cobblestone
fill 352 107 250 358 107 250 minecraft:iron_block
fill 352 107 251 353 107 251 minecraft:stone_bricks
fill 352 107 256 356 107 256 minecraft:iron_block
setblock 352 107 257 minecraft:mossy_cobblestone
setblock 352 107 258 minecraft:stone_bricks
fill 352 107 259 353 107 259 minecraft:iron_block
fill 352 107 260 353 108 260 minecraft:gray_concrete
setblock 352 107 261 minecraft:mossy_cobblestone
fill 352 107 262 354 107 262 minecraft:stone_bricks
setblock 352 107 265 minecraft:mossy_cobblestone
fill 352 107 266 354 107 266 minecraft:stone_bricks
setblock 352 107 269 minecraft:mossy_cobblestone
fill 353 107 229 355 107 229 minecraft:stone_bricks
setblock 353 107 232 minecraft:mossy_cobblestone
fill 353 107 233 355 107 233 minecraft:stone_bricks
setblock 353 107 236 minecraft:mossy_cobblestone
fill 353 107 237 355 107 237 minecraft:stone_bricks
fill 353 107 242 354 107 243 minecraft:iron_block
setblock 353 107 246 minecraft:stone_bricks
setblock 353 107 249 minecraft:stone_bricks
setblock 353 107 254 minecraft:stone_bricks
fill 353 107 257 354 107 258 minecraft:iron_block
fill 353 107 261 355 107 261 minecraft:stone_bricks
setblock 353 107 264 minecraft:mossy_cobblestone
fill 353 107 265 355 107 265 minecraft:stone_bricks
setblock 353 107 268 minecraft:mossy_cobblestone
fill 353 107 269 355 107 269 minecraft:stone_bricks
setblock 354 107 231 minecraft:mossy_cobblestone
fill 354 107 232 356 107 232 minecraft:stone_bricks
setblock 354 107 235 minecraft:mossy_cobblestone
fill 354 107 236 356 107 236 minecraft:stone_bricks
setblock 354 107 238 minecraft:stone_bricks
setblock 354 107 239 minecraft:mossy_cobblestone
fill 354 107 240 356 107 240 minecraft:stone_bricks
fill 354 107 241 354 108 241 minecraft:gray_concrete
fill 354 107 245 355 107 245 minecraft:stone_bricks
fill 354 107 246 357 107 246 minecraft:iron_block
fill 354 107 249 357 107 249 minecraft:iron_block
fill 354 107 251 357 107 251 minecraft:iron_block
fill 354 107 254 357 107 254 minecraft:iron_block
setblock 354 107 255 minecraft:mossy_cobblestone
fill 354 107 259 354 108 259 minecraft:gray_concrete
fill 354 107 260 356 107 260 minecraft:stone_bricks
setblock 354 107 263 minecraft:mossy_cobblestone
fill 354 107 264 356 107 264 minecraft:stone_bricks
setblock 354 107 267 minecraft:mossy_cobblestone
fill 354 107 268 356 107 268 minecraft:stone_bricks
setblock 355 107 230 minecraft:mossy_cobblestone
fill 355 107 231 357 107 231 minecraft:stone_bricks
setblock 355 107 234 minecraft:mossy_cobblestone
fill 355 107 235 357 107 235 minecraft:stone_bricks
setblock 355 107 238 minecraft:mossy_cobblestone
fill 355 107 239 357 107 239 minecraft:stone_bricks
setblock 355 107 241 minecraft:stone_bricks
fill 355 107 242 355 108 242 minecraft:gray_concrete
setblock 355 107 243 minecraft:iron_block
setblock 355 107 255 minecraft:stone_bricks
setblock 355 107 257 minecraft:iron_block
fill 355 107 258 355 108 258 minecraft:gray_concrete
fill 355 107 259 357 107 259 minecraft:stone_bricks
setblock 355 107 262 minecraft:mossy_cobblestone
fill 355 107 263 357 107 263 minecraft:stone_bricks
setblock 355 107 266 minecraft:mossy_cobblestone
fill 355 107 267 357 107 267 minecraft:stone_bricks
setblock 355 107 270 minecraft:cobblestone
setblock 356 107 229 minecraft:mossy_cobblestone
fill 356 107 230 358 107 230 minecraft:stone_bricks
setblock 356 107 233 minecraft:mossy_cobblestone
fill 356 107 234 358 107 234 minecraft:stone_bricks
setblock 356 107 237 minecraft:mossy_cobblestone
fill 356 107 238 358 107 238 minecraft:stone_bricks
setblock 356 107 241 minecraft:mossy_cobblestone
fill 356 107 242 358 107 242 minecraft:stone_bricks
fill 356 107 243 356 108 243 minecraft:gray_concrete
setblock 356 107 245 minecraft:iron_block
setblock 356 107 248 minecraft:stone_bricks
setblock 356 107 252 minecraft:stone_bricks
setblock 356 107 255 minecraft:iron_block
fill 356 107 257 356 108 257 minecraft:gray_concrete
fill 356 107 258 358 107 258 minecraft:stone_bricks
setblock 356 107 261 minecraft:mossy_cobblestone
fill 356 107 262 358 107 262 minecraft:stone_bricks
setblock 356 107 265 minecraft:mossy_cobblestone
fill 356 107 266 358 107 266 minecraft:stone_bricks
setblock 356 107 269 minecraft:mossy_cobblestone
fill 357 107 229 359 107 229 minecraft:stone_bricks
setblock 357 107 232 minecraft:mossy_cobblestone
fill 357 107 233 359 107 233 minecraft:stone_bricks
setblock 357 107 236 minecraft:mossy_cobblestone
fill 357 107 237 359 107 237 minecraft:stone_bricks
setblock 357 107 240 minecraft:mossy_cobblestone
fill 357 107 241 359 107 241 minecraft:stone_bricks
setblock 357 107 243 minecraft:stone_bricks
fill 357 107 244 357 108 245 minecraft:gray_concrete
setblock 357 107 248 minecraft:mossy_cobblestone
setblock 357 107 252 minecraft:mossy_cobblestone
fill 357 107 255 357 108 256 minecraft:gray_concrete
fill 357 107 257 359 107 257 minecraft:stone_bricks
setblock 357 107 260 minecraft:mossy_cobblestone
fill 357 107 261 359 107 261 minecraft:stone_bricks
setblock 357 107 264 minecraft:mossy_cobblestone
fill 357 107 265 359 107 265 minecraft:stone_bricks
setblock 357 107 268 minecraft:mossy_cobblestone
fill 357 107 269 359 107 269 minecraft:stone_bricks
setblock 358 107 231 minecraft:mossy_cobblestone
fill 358 107 232 360 107 232 minecraft:stone_bricks
setblock 358 107 235 minecraft:mossy_cobblestone
fill 358 107 236 360 107 236 minecraft:stone_bricks
setblock 358 107 239 minecraft:mossy_cobblestone
fill 358 107 240 360 107 240 minecraft:stone_bricks
setblock 358 107 243 minecraft:mossy_cobblestone
fill 358 107 244 359 107 245 minecraft:stone_bricks
fill 358 107 246 358 108 249 minecraft:gray_concrete
fill 358 107 251 358 108 254 minecraft:gray_concrete
setblock 358 107 255 minecraft:mossy_cobblestone
fill 358 107 256 360 107 256 minecraft:stone_bricks
setblock 358 107 259 minecraft:mossy_cobblestone
fill 358 107 260 360 107 260 minecraft:stone_bricks
setblock 358 107 263 minecraft:mossy_cobblestone
fill 358 107 264 360 107 264 minecraft:stone_bricks
setblock 358 107 267 minecraft:mossy_cobblestone
fill 358 107 268 360 107 268 minecraft:stone_bricks
setblock 359 107 230 minecraft:mossy_cobblestone
fill 359 107 231 361 107 231 minecraft:stone_bricks
setblock 359 107 234 minecraft:mossy_cobblestone
fill 359 107 235 361 107 235 minecraft:stone_bricks
setblock 359 107 238 minecraft:mossy_cobblestone
fill 359 107 239 361 107 239 minecraft:stone_bricks
setblock 359 107 242 minecraft:mossy_cobblestone
fill 359 107 243 361 107 243 minecraft:stone_bricks
setblock 359 107 246 minecraft:mossy_cobblestone
fill 359 107 247 359 107 249 minecraft:stone_bricks
fill 359 107 250 359 108 250 minecraft:gray_concrete
fill 359 107 251 359 107 253 minecraft:stone_bricks
setblock 359 107 254 minecraft:mossy_cobblestone
fill 359 107 255 361 107 255 minecraft:stone_bricks
setblock 359 107 258 minecraft:mossy_cobblestone
fill 359 107 259 361 107 259 minecraft:stone_bricks
setblock 359 107 262 minecraft:mossy_cobblestone
fill 359 107 263 361 107 263 minecraft:stone_bricks
setblock 359 107 266 minecraft:mossy_cobblestone
fill 359 107 267 361 107 267 minecraft:stone_bricks
setblock 360 107 229 minecraft:mossy_cobblestone
fill 360 107 230 362 107 230 minecraft:stone_bricks
setblock 360 107 233 minecraft:mossy_cobblestone
fill 360 107 234 362 107 234 minecraft:stone_bricks
setblock 360 107 237 minecraft:mossy_cobblestone
fill 360 107 238 362 107 238 minecraft:stone_bricks
setblock 360 107 241 minecraft:mossy_cobblestone
fill 360 107 242 362 107 242 minecraft:stone_bricks
setblock 360 107 244 minecraft:stone_bricks
setblock 360 107 245 minecraft:mossy_cobblestone
fill 360 107 246 360 107 248 minecraft:stone_bricks
setblock 360 107 249 minecraft:mossy_cobblestone
fill 360 107 250 360 107 252 minecraft:stone_bricks
setblock 360 107 253 minecraft:mossy_cobblestone
fill 360 107 254 362 107 254 minecraft:stone_bricks
setblock 360 107 257 minecraft:mossy_cobblestone
fill 360 107 258 362 107 258 minecraft:stone_bricks
setblock 360 107 261 minecraft:mossy_cobblestone
fill 360 107 262 362 107 262 minecraft:stone_bricks
setblock 360 107 265 minecraft:mossy_cobblestone
fill 360 107 266 362 107 266 minecraft:stone_bricks
setblock 360 107 269 minecraft:mossy_cobblestone
fill 361 107 229 363 107 229 minecraft:stone_bricks
setblock 361 107 232 minecraft:mossy_cobblestone
fill 361 107 233 363 107 233 minecraft:stone_bricks
setblock 361 107 236 minecraft:mossy_cobblestone
fill 361 107 237 363 107 237 minecraft:stone_bricks
setblock 361 107 240 minecraft:mossy_cobblestone
fill 361 107 241 363 107 241 minecraft:stone_bricks
setblock 361 107 244 minecraft:mossy_cobblestone
fill 361 107 245 361 107 247 minecraft:stone_bricks
setblock 361 107 248 minecraft:mossy_cobblestone
fill 361 107 249 361 107 251 minecraft:stone_bricks
setblock 361 107 252 minecraft:mossy_cobblestone
fill 361 107 253 363 107 253 minecraft:stone_bricks
setblock 361 107 256 minecraft:mossy_cobblestone
fill 361 107 257 363 107 257 minecraft:stone_bricks
setblock 361 107 260 minecraft:mossy_cobblestone
fill 361 107 261 363 107 261 minecraft:stone_bricks
setblock 361 107 264 minecraft:mossy_cobblestone
fill 361 107 265 363 107 265 minecraft:stone_bricks
setblock 361 107 268 minecraft:mossy_cobblestone
fill 361 107 269 363 107 269 minecraft:stone_bricks
setblock 362 107 231 minecraft:mossy_cobblestone
fill 362 107 232 364 107 232 minecraft:stone_bricks
setblock 362 107 235 minecraft:mossy_cobblestone
fill 362 107 236 364 107 236 minecraft:stone_bricks
setblock 362 107 239 minecraft:mossy_cobblestone
fill 362 107 240 364 107 240 minecraft:stone_bricks
setblock 362 107 243 minecraft:mossy_cobblestone
fill 362 107 244 362 107 246 minecraft:stone_bricks
setblock 362 107 247 minecraft:mossy_cobblestone
fill 362 107 248 362 107 250 minecraft:stone_bricks
setblock 362 107 251 minecraft:mossy_cobblestone
fill 362 107 252 364 107 252 minecraft:stone_bricks
setblock 362 107 255 minecraft:mossy_cobblestone
fill 362 107 256 364 107 256 minecraft:stone_bricks
setblock 362 107 259 minecraft:mossy_cobblestone
fill 362 107 260 364 107 260 minecraft:stone_bricks
setblock 362 107 263 minecraft:mossy_cobblestone
fill 362 107 264 364 107 264 minecraft:stone_bricks
setblock 362 107 267 minecraft:mossy_cobblestone
fill 362 107 268 364 107 268 minecraft:stone_bricks
setblock 363 107 230 minecraft:mossy_cobblestone
fill 363 107 231 365 107 231 minecraft:stone_bricks
setblock 363 107 234 minecraft:mossy_cobblestone
fill 363 107 235 365 107 235 minecraft:stone_bricks
setblock 363 107 238 minecraft:mossy_cobblestone
fill 363 107 239 365 107 239 minecraft:stone_bricks
setblock 363 107 242 minecraft:mossy_cobblestone
fill 363 107 243 363 107 245 minecraft:stone_bricks
setblock 363 107 246 minecraft:mossy_cobblestone
fill 363 107 247 363 107 249 minecraft:stone_bricks
setblock 363 107 250 minecraft:mossy_cobblestone
fill 363 107 251 365 107 251 minecraft:stone_bricks
setblock 363 107 254 minecraft:mossy_cobblestone
fill 363 107 255 365 107 255 minecraft:stone_bricks
setblock 363 107 258 minecraft:mossy_cobblestone
fill 363 107 259 365 107 259 minecraft:stone_bricks
setblock 363 107 262 minecraft:mossy_cobblestone
fill 363 107 263 365 107 263 minecraft:stone_bricks
setblock 363 107 266 minecraft:mossy_cobblestone
fill 363 107 267 365 107 267 minecraft:stone_bricks
setblock 364 107 229 minecraft:mossy_cobblestone
fill 364 107 230 366 107 230 minecraft:stone_bricks
setblock 364 107 233 minecraft:mossy_cobblestone
fill 364 107 234 366 107 234 minecraft:stone_bricks
setblock 364 107 237 minecraft:mossy_cobblestone
fill 364 107 238 366 107 238 minecraft:stone_bricks
setblock 364 107 241 minecraft:mossy_cobblestone
fill 364 107 242 364 107 244 minecraft:stone_bricks
setblock 364 107 245 minecraft:mossy_cobblestone
fill 364 107 246 364 107 248 minecraft:stone_bricks
setblock 364 107 249 minecraft:mossy_cobblestone
fill 364 107 250 366 107 250 minecraft:stone_bricks
setblock 364 107 253 minecraft:mossy_cobblestone
fill 364 107 254 366 107 254 minecraft:stone_bricks
setblock 364 107 257 minecraft:mossy_cobblestone
fill 364 107 258 366 107 258 minecraft:stone_bricks
setblock 364 107 261 minecraft:mossy_cobblestone
fill 364 107 262 366 107 262 minecraft:stone_bricks
setblock 364 107 265 minecraft:mossy_cobblestone
fill 364 107 266 366 107 266 minecraft:stone_bricks
setblock 364 107 269 minecraft:mossy_cobblestone
fill 365 107 229 367 107 229 minecraft:stone_bricks
setblock 365 107 232 minecraft:mossy_cobblestone
fill 365 107 233 367 107 233 minecraft:stone_bricks
setblock 365 107 236 minecraft:mossy_cobblestone
fill 365 107 237 367 107 237 minecraft:stone_bricks
setblock 365 107 240 minecraft:mossy_cobblestone
fill 365 107 241 365 107 243 minecraft:stone_bricks
setblock 365 107 244 minecraft:mossy_cobblestone
fill 365 107 245 365 107 247 minecraft:stone_bricks
setblock 365 107 248 minecraft:mossy_cobblestone
fill 365 107 249 367 107 249 minecraft:stone_bricks
setblock 365 107 252 minecraft:mossy_cobblestone
fill 365 107 253 367 107 253 minecraft:stone_bricks
setblock 365 107 256 minecraft:mossy_cobblestone
fill 365 107 257 367 107 257 minecraft:stone_bricks
setblock 365 107 260 minecraft:mossy_cobblestone
fill 365 107 261 367 107 261 minecraft:stone_bricks
setblock 365 107 264 minecraft:mossy_cobblestone
fill 365 107 265 367 107 265 minecraft:stone_bricks
setblock 365 107 268 minecraft:mossy_cobblestone
fill 365 107 269 367 107 269 minecraft:stone_bricks
setblock 366 107 231 minecraft:mossy_cobblestone
fill 366 107 232 368 107 232 minecraft:stone_bricks
setblock 366 107 235 minecraft:mossy_cobblestone
fill 366 107 236 368 107 236 minecraft:stone_bricks
setblock 366 107 239 minecraft:mossy_cobblestone
fill 366 107 240 366 107 242 minecraft:stone_bricks
setblock 366 107 243 minecraft:mossy_cobblestone
fill 366 107 244 366 107 246 minecraft:stone_bricks
setblock 366 107 247 minecraft:mossy_cobblestone
fill 366 107 248 368 107 248 minecraft:stone_bricks
setblock 366 107 251 minecraft:mossy_cobblestone
fill 366 107 252 368 107 252 minecraft:stone_bricks
setblock 366 107 255 minecraft:mossy_cobblestone
fill 366 107 256 368 107 256 minecraft:stone_bricks
setblock 366 107 259 minecraft:mossy_cobblestone
fill 366 107 260 368 107 260 minecraft:stone_bricks
setblock 366 107 263 minecraft:mossy_cobblestone
fill 366 107 264 368 107 264 minecraft:stone_bricks
setblock 366 107 267 minecraft:mossy_cobblestone
fill 366 107 268 368 107 268 minecraft:stone_bricks
setblock 367 107 230 minecraft:mossy_cobblestone
fill 367 107 231 369 107 231 minecraft:stone_bricks
setblock 367 107 234 minecraft:mossy_cobblestone
fill 367 107 235 369 107 235 minecraft:stone_bricks
setblock 367 107 238 minecraft:mossy_cobblestone
fill 367 107 239 367 107 241 minecraft:stone_bricks
setblock 367 107 242 minecraft:mossy_cobblestone
fill 367 107 243 367 107 245 minecraft:stone_bricks
setblock 367 107 246 minecraft:mossy_cobblestone
fill 367 107 247 369 107 247 minecraft:stone_bricks
setblock 367 107 250 minecraft:mossy_cobblestone
fill 367 107 251 369 107 251 minecraft:stone_bricks
setblock 367 107 254 minecraft:mossy_cobblestone
fill 367 107 255 369 107 255 minecraft:stone_bricks
setblock 367 107 258 minecraft:mossy_cobblestone
fill 367 107 259 369 107 259 minecraft:stone_bricks
setblock 367 107 262 minecraft:mossy_cobblestone
fill 367 107 263 369 107 263 minecraft:stone_bricks
setblock 367 107 266 minecraft:mossy_cobblestone
fill 367 107 267 369 107 267 minecraft:stone_bricks
setblock 368 107 229 minecraft:mossy_cobblestone
fill 368 107 230 370 107 230 minecraft:stone_bricks
setblock 368 107 233 minecraft:mossy_cobblestone
fill 368 107 234 370 107 234 minecraft:stone_bricks
setblock 368 107 237 minecraft:mossy_cobblestone
fill 368 107 238 368 107 240 minecraft:stone_bricks
setblock 368 107 241 minecraft:mossy_cobblestone
fill 368 107 242 368 107 244 minecraft:stone_bricks
setblock 368 107 245 minecraft:mossy_cobblestone
fill 368 107 246 370 107 246 minecraft:stone_bricks
setblock 368 107 249 minecraft:mossy_cobblestone
fill 368 107 250 370 107 250 minecraft:stone_bricks
setblock 368 107 253 minecraft:mossy_cobblestone
fill 368 107 254 370 107 254 minecraft:stone_bricks
setblock 368 107 257 minecraft:mossy_cobblestone
fill 368 107 258 370 107 258 minecraft:stone_bricks
setblock 368 107 261 minecraft:mossy_cobblestone
fill 368 107 262 370 107 262 minecraft:stone_bricks
setblock 368 107 265 minecraft:mossy_cobblestone
fill 368 107 266 370 107 266 minecraft:stone_bricks
setblock 368 107 269 minecraft:mossy_cobblestone
fill 369 107 229 370 107 229 minecraft:stone_bricks
setblock 369 107 232 minecraft:mossy_cobblestone
fill 369 107 233 370 107 233 minecraft:stone_bricks
setblock 369 107 236 minecraft:mossy_cobblestone
fill 369 107 237 369 107 239 minecraft:stone_bricks
setblock 369 107 240 minecraft:mossy_cobblestone
fill 369 107 241 369 107 243 minecraft:stone_bricks
setblock 369 107 244 minecraft:mossy_cobblestone
fill 369 107 245 370 107 245 minecraft:stone_bricks
setblock 369 107 248 minecraft:mossy_cobblestone
fill 369 107 249 370 107 249 minecraft:stone_bricks
setblock 369 107 252 minecraft:mossy_cobblestone
fill 369 107 253 370 107 253 minecraft:stone_bricks
setblock 369 107 256 minecraft:mossy_cobblestone
fill 369 107 257 370 107 257 minecraft:stone_bricks
setblock 369 107 260 minecraft:mossy_cobblestone
fill 369 107 261 370 107 261 minecraft:stone_bricks
setblock 369 107 264 minecraft:mossy_cobblestone
fill 369 107 265 370 107 265 minecraft:stone_bricks
setblock 369 107 268 minecraft:mossy_cobblestone
fill 369 107 269 370 107 269 minecraft:stone_bricks
setblock 370 107 231 minecraft:mossy_cobblestone
setblock 370 107 232 minecraft:stone_bricks
setblock 370 107 235 minecraft:mossy_cobblestone
fill 370 107 236 370 107 238 minecraft:stone_bricks
setblock 370 107 239 minecraft:mossy_cobblestone
fill 370 107 240 370 107 242 minecraft:stone_bricks
setblock 370 107 243 minecraft:mossy_cobblestone
setblock 370 107 244 minecraft:stone_bricks
setblock 370 107 247 minecraft:mossy_cobblestone
setblock 370 107 248 minecraft:stone_bricks
setblock 370 107 251 minecraft:mossy_cobblestone
setblock 370 107 252 minecraft:stone_bricks
setblock 370 107 255 minecraft:mossy_cobblestone
setblock 370 107 256 minecraft:stone_bricks
setblock 370 107 259 minecraft:mossy_cobblestone
setblock 370 107 260 minecraft:stone_bricks
setblock 370 107 263 minecraft:mossy_cobblestone
setblock 370 107 264 minecraft:stone_bricks
setblock 370 107 267 minecraft:mossy_cobblestone
fill 370 107 268 371 107 268 minecraft:stone_bricks
setblock 371 107 253 minecraft:cobblestone
setblock 345 108 228 minecraft:cobblestone
fill 355 108 270 355 110 270 minecraft:stone_bricks
fill 371 108 253 371 246 253 minecraft:stone_bricks
fill 371 108 268 371 204 268 minecraft:stone_bricks
setblock 329 109 235 minecraft:cobblestone
setblock 329 109 254 minecraft:mossy_stone_bricks
setblock 332 109 231 minecraft:light[level=12]
setblock 332 109 238 minecraft:light[level=12]
setblock 332 109 245 minecraft:light[level=12]
setblock 332 109 252 minecraft:light[level=12]
setblock 332 109 259 minecraft:light[level=12]
setblock 332 109 266 minecraft:light[level=12]
fill 338 109 270 341 133 270 minecraft:stone_bricks
setblock 339 109 231 minecraft:light[level=12]
setblock 339 109 238 minecraft:light[level=12]
setblock 339 109 245 minecraft:light[level=12]
setblock 339 109 252 minecraft:light[level=12]
setblock 339 109 259 minecraft:light[level=12]
setblock 339 109 266 minecraft:light[level=12]
setblock 342 109 270 minecraft:mossy_cobblestone
fill 345 109 228 345 174 228 minecraft:stone_bricks
setblock 346 109 231 minecraft:light[level=12]
setblock 346 109 238 minecraft:light[level=12]
setblock 346 109 245 minecraft:light[level=12]
setblock 346 109 259 minecraft:light[level=12]
setblock 346 109 266 minecraft:light[level=12]
setblock 353 109 231 minecraft:light[level=12]
setblock 353 109 238 minecraft:light[level=12]
setblock 353 109 245 minecraft:light[level=12]
setblock 353 109 252 minecraft:light[level=12]
setblock 353 109 259 minecraft:light[level=12]
setblock 353 109 266 minecraft:light[level=12]
setblock 360 109 231 minecraft:light[level=12]
setblock 360 109 238 minecraft:light[level=12]
setblock 360 109 245 minecraft:light[level=12]
setblock 360 109 252 minecraft:light[level=12]
setblock 360 109 259 minecraft:light[level=12]
setblock 360 109 266 minecraft:light[level=12]
setblock 367 109 231 minecraft:light[level=12]
setblock 367 109 238 minecraft:light[level=12]
setblock 367 109 245 minecraft:light[level=12]
setblock 367 109 252 minecraft:light[level=12]
setblock 367 109 259 minecraft:light[level=12]
setblock 367 109 266 minecraft:light[level=12]
fill 329 110 235 329 117 235 minecraft:stone_bricks
fill 329 110 254 329 273 254 minecraft:stone_bricks
setblock 330 110 237 minecraft:green_concrete
fill 342 110 270 342 199 270 minecraft:stone_bricks
setblock 329 111 255 minecraft:mossy_cobblestone
setblock 332 111 231 minecraft:light[level=15]
setblock 332 111 239 minecraft:light[level=15]
setblock 332 111 247 minecraft:light[level=15]
setblock 332 111 255 minecraft:light[level=15]
setblock 332 111 263 minecraft:light[level=15]
fill 333 111 238 334 111 238 minecraft:gray_concrete
fill 335 111 264 335 111 265 minecraft:gray_concrete
setblock 336 111 229 minecraft:lime_concrete
fill 337 111 232 337 111 233 minecraft:gray_concrete
fill 337 111 264 337 111 265 minecraft:gray_concrete
fill 338 111 245 339 112 246 minecraft:white_stained_glass
setblock 340 111 231 minecraft:light[level=15]
setblock 340 111 239 minecraft:light[level=15]
setblock 340 111 247 minecraft:light[level=15]
setblock 340 111 255 minecraft:light[level=15]
setblock 340 111 263 minecraft:light[level=15]
fill 347 111 266 347 175 266 minecraft:iron_block
setblock 348 111 231 minecraft:light[level=15]
setblock 348 111 239 minecraft:light[level=15]
setblock 348 111 247 minecraft:light[level=15]
setblock 348 111 255 minecraft:light[level=15]
setblock 348 111 263 minecraft:light[level=15]
fill 351 111 232 351 111 233 minecraft:gray_concrete
setblock 355 111 270 minecraft:mossy_stone_bricks
setblock 356 111 231 minecraft:light[level=15]
setblock 356 111 239 minecraft:light[level=15]
setblock 356 111 247 minecraft:light[level=15]
setblock 356 111 255 minecraft:light[level=15]
setblock 356 111 263 minecraft:light[level=15]
setblock 356 111 270 minecraft:cobblestone
fill 357 111 270 357 163 270 minecraft:stone_bricks
setblock 364 111 231 minecraft:light[level=15]
setblock 364 111 239 minecraft:light[level=15]
setblock 364 111 247 minecraft:light[level=15]
setblock 364 111 255 minecraft:light[level=15]
setblock 364 111 263 minecraft:light[level=15]
fill 365 111 251 366 111 251 minecraft:gray_concrete
fill 366 111 240 368 118 242 minecraft:iron_block
fill 366 111 263 368 119 265 minecraft:iron_block
fill 329 112 255 329 218 255 minecraft:stone_bricks
fill 332 112 238 333 112 238 minecraft:gray_concrete
fill 335 112 265 335 112 266 minecraft:gray_concrete
fill 337 112 231 337 112 232 minecraft:gray_concrete
fill 337 112 265 337 112 266 minecraft:gray_concrete
fill 351 112 231 351 112 232 minecraft:gray_concrete
fill 355 112 270 356 124 270 minecraft:stone_bricks
fill 366 112 251 367 112 251 minecraft:gray_concrete
fill 331 113 238 332 113 238 minecraft:gray_concrete
fill 335 113 266 335 113 267 minecraft:gray_concrete
fill 337 113 230 337 113 231 minecraft:gray_concrete
fill 337 113 266 337 113 267 minecraft:gray_concrete
fill 346 113 265 346 113 267 minecraft:light_gray_concrete
fill 347 113 265 348 113 265 minecraft:light_gray_concrete
fill 347 113 267 348 113 267 minecraft:light_gray_concrete
setblock 348 113 266 minecraft:light_gray_concrete
fill 351 113 230 351 113 231 minecraft:gray_concrete
fill 365 113 240 365 113 242 minecraft:light_gray_concrete
fill 365 113 263 365 113 265 minecraft:light_gray_concrete
fill 366 113 239 368 113 239 minecraft:light_gray_concrete
fill 366 113 243 368 113 243 minecraft:light_gray_concrete
fill 366 113 262 368 113 262 minecraft:light_gray_concrete
fill 366 113 266 368 113 266 minecraft:light_gray_concrete
fill 367 113 251 368 113 251 minecraft:gray_concrete
fill 369 113 240 369 113 242 minecraft:light_gray_concrete
fill 369 113 263 369 113 265 minecraft:light_gray_concrete
fill 330 114 238 331 114 238 minecraft:gray_concrete
fill 335 114 267 335 114 268 minecraft:gray_concrete
fill 337 114 229 337 114 230 minecraft:gray_concrete
fill 337 114 267 337 114 268 minecraft:gray_concrete
setblock 348 114 229 minecraft:lime_concrete
fill 351 114 229 351 114 230 minecraft:gray_concrete
fill 368 114 251 369 114 251 minecraft:gray_concrete
setblock 369 114 270 minecraft:mossy_cobblestone
setblock 330 115 238 minecraft:gray_concrete
setblock 332 115 231 minecraft:light[level=12]
setblock 332 115 238 minecraft:light[level=12]
setblock 332 115 245 minecraft:light[level=12]
setblock 332 115 252 minecraft:light[level=12]
setblock 332 115 259 minecraft:light[level=12]
setblock 332 115 266 minecraft:light[level=12]
setblock 335 115 268 minecraft:gray_concrete
setblock 337 115 229 minecraft:gray_concrete
setblock 337 115 238 minecraft:sea_lantern
setblock 337 115 244 minecraft:sea_lantern
setblock 337 115 250 minecraft:sea_lantern
setblock 337 115 256 minecraft:sea_lantern
setblock 337 115 262 minecraft:sea_lantern
setblock 337 115 268 minecraft:gray_concrete
setblock 339 115 231 minecraft:light[level=12]
setblock 339 115 236 minecraft:sea_lantern
setblock 339 115 238 minecraft:light[level=12]
setblock 339 115 245 minecraft:light[level=12]
setblock 339 115 252 minecraft:light[level=12]
setblock 339 115 259 minecraft:light[level=12]
setblock 339 115 266 minecraft:light[level=12]
setblock 343 115 262 minecraft:sea_lantern
fill 343 115 270 345 150 270 minecraft:stone_bricks
setblock 345 115 236 minecraft:sea_lantern
setblock 346 115 231 minecraft:light[level=12]
setblock 346 115 238 minecraft:light[level=12]
setblock 346 115 245 minecraft:light[level=12]
setblock 346 115 252 minecraft:light[level=12]
setblock 346 115 259 minecraft:light[level=12]
setblock 346 115 266 minecraft:light[level=12]
setblock 346 115 270 minecraft:mossy_stone_bricks
setblock 349 115 262 minecraft:sea_lantern
setblock 351 115 229 minecraft:gray_concrete
setblock 351 115 236 minecraft:sea_lantern
setblock 353 115 231 minecraft:light[level=12]
setblock 353 115 238 minecraft:light[level=12]
setblock 353 115 245 minecraft:light[level=12]
setblock 353 115 252 minecraft:light[level=12]
setblock 353 115 259 minecraft:light[level=12]
setblock 353 115 266 minecraft:light[level=12]
setblock 355 115 262 minecraft:sea_lantern
setblock 357 115 236 minecraft:sea_lantern
setblock 360 115 231 minecraft:light[level=12]
setblock 360 115 238 minecraft:light[level=12]
setblock 360 115 245 minecraft:light[level=12]
setblock 360 115 252 minecraft:light[level=12]
setblock 360 115 259 minecraft:light[level=12]
setblock 360 115 266 minecraft:light[level=12]
setblock 361 115 262 minecraft:sea_lantern
setblock 363 115 236 minecraft:sea_lantern
setblock 363 115 242 minecraft:sea_lantern
setblock 363 115 248 minecraft:sea_lantern
setblock 363 115 254 minecraft:sea_lantern
setblock 363 115 260 minecraft:sea_lantern
setblock 367 115 231 minecraft:light[level=12]
setblock 367 115 238 minecraft:light[level=12]
setblock 367 115 245 minecraft:light[level=12]
setblock 367 115 252 minecraft:light[level=12]
setblock 367 115 259 minecraft:light[level=12]
setblock 367 115 266 minecraft:light[level=12]
setblock 369 115 251 minecraft:gray_concrete
setblock 369 115 270 minecraft:cobblestone
setblock 329 116 268 minecraft:mossy_stone_bricks
setblock 330 116 229 minecraft:light_gray_concrete
fill 330 116 231 330 116 232 minecraft:light_gray_concrete
fill 330 116 234 330 116 235 minecraft:light_gray_concrete
fill 330 116 237 330 116 238 minecraft:light_gray_concrete
fill 330 116 240 330 116 241 minecraft:light_gray_concrete
fill 330 116 243 330 116 244 minecraft:light_gray_concrete
fill 330 116 246 330 116 247 minecraft:light_gray_concrete
fill 330 116 249 330 116 250 minecraft:light_gray_concrete
fill 330 116 252 330 116 253 minecraft:light_gray_concrete
fill 330 116 255 330 116 256 minecraft:light_gray_concrete
fill 330 116 258 330 116 259 minecraft:light_gray_concrete
fill 330 116 261 330 116 262 minecraft:light_gray_concrete
fill 330 116 264 330 116 265 minecraft:light_gray_concrete
fill 330 116 267 330 116 268 minecraft:light_gray_concrete
fill 331 116 230 331 116 231 minecraft:light_gray_concrete
fill 331 116 233 331 116 234 minecraft:light_gray_concrete
fill 331 116 236 331 116 237 minecraft:light_gray_concrete
fill 331 116 239 331 116 240 minecraft:light_gray_concrete
fill 331 116 242 331 116 243 minecraft:light_gray_concrete
fill 331 116 245 331 116 246 minecraft:light_gray_concrete
fill 331 116 248 331 116 249 minecraft:light_gray_concrete
fill 331 116 251 331 116 252 minecraft:light_gray_concrete
fill 331 116 254 331 116 255 minecraft:light_gray_concrete
fill 331 116 257 331 116 258 minecraft:light_gray_concrete
fill 331 116 260 331 116 261 minecraft:light_gray_concrete
fill 331 116 263 331 116 264 minecraft:light_gray_concrete
fill 331 116 266 331 116 267 minecraft:light_gray_concrete
fill 331 116 269 332 116 269 minecraft:light_gray_concrete
fill 332 116 229 332 116 230 minecraft:light_gray_concrete
fill 332 116 232 332 116 233 minecraft:light_gray_concrete
fill 332 116 235 332 116 236 minecraft:light_gray_concrete
fill 332 116 238 332 116 239 minecraft:light_gray_concrete
fill 332 116 241 332 116 242 minecraft:light_gray_concrete
fill 332 116 244 332 116 245 minecraft:light_gray_concrete
fill 332 116 247 332 116 248 minecraft:light_gray_concrete
fill 332 116 250 332 116 251 minecraft:light_gray_concrete
fill 332 116 253 332 116 254 minecraft:light_gray_concrete
fill 332 116 256 332 116 257 minecraft:light_gray_concrete
fill 332 116 259 332 116 260 minecraft:light_gray_concrete
fill 332 116 262 332 116 263 minecraft:light_gray_concrete
fill 332 116 265 332 116 266 minecraft:light_gray_concrete
fill 332 116 268 333 116 268 minecraft:light_gray_concrete
setblock 333 116 229 minecraft:light_gray_concrete
fill 333 116 231 333 116 232 minecraft:light_gray_concrete
fill 333 116 234 333 116 235 minecraft:light_gray_concrete
fill 333 116 237 333 116 238 minecraft:light_gray_concrete
fill 333 116 240 333 116 241 minecraft:light_gray_concrete
fill 333 116 243 333 116 244 minecraft:light_gray_concrete
fill 333 116 246 333 116 247 minecraft:light_gray_concrete
fill 333 116 249 333 116 250 minecraft:light_gray_concrete
fill 333 116 252 333 116 253 minecraft:light_gray_concrete
fill 333 116 255 333 116 256 minecraft:light_gray_concrete
fill 333 116 258 333 116 259 minecraft:light_gray_concrete
fill 333 116 261 333 116 262 minecraft:light_gray_concrete
fill 333 116 264 333 116 265 minecraft:light_gray_concrete
fill 333 116 267 334 116 267 minecraft:light_gray_concrete
fill 334 116 230 334 116 231 minecraft:light_gray_concrete
fill 334 116 233 334 116 234 minecraft:light_gray_concrete
fill 334 116 236 334 116 237 minecraft:light_gray_concrete
fill 334 116 239 334 116 240 minecraft:light_gray_concrete
fill 334 116 242 334 116 243 minecraft:light_gray_concrete
fill 334 116 245 334 116 246 minecraft:light_gray_concrete
fill 334 116 248 334 116 249 minecraft:light_gray_concrete
fill 334 116 251 334 116 252 minecraft:light_gray_concrete
fill 334 116 254 334 116 255 minecraft:light_gray_concrete
fill 334 116 257 334 116 258 minecraft:light_gray_concrete
fill 334 116 260 334 116 261 minecraft:light_gray_concrete
fill 334 116 263 334 116 264 minecraft:light_gray_concrete
fill 334 116 266 335 116 266 minecraft:light_gray_concrete
fill 334 116 269 335 116 269 minecraft:light_gray_concrete
fill 335 116 229 335 116 230 minecraft:light_gray_concrete
fill 335 116 232 335 116 233 minecraft:light_gray_concrete
fill 335 116 235 335 116 236 minecraft:light_gray_concrete
fill 335 116 238 335 116 239 minecraft:light_gray_concrete
fill 335 116 241 335 116 242 minecraft:light_gray_concrete
fill 335 116 244 335 116 245 minecraft:light_gray_concrete
fill 335 116 247 335 116 248 minecraft:light_gray_concrete
fill 335 116 250 335 116 251 minecraft:light_gray_concrete
fill 335 116 253 335 116 254 minecraft:light_gray_concrete
fill 335 116 256 335 116 257 minecraft:light_gray_concrete
fill 335 116 259 335 116 260 minecraft:light_gray_concrete
fill 335 116 262 335 116 263 minecraft:light_gray_concrete
fill 335 116 265 336 116 265 minecraft:light_gray_concrete
fill 335 116 268 336 116 268 minecraft:light_gray_concrete
setblock 336 116 229 minecraft:light_gray_concrete
fill 336 116 231 336 116 232 minecraft:light_gray_concrete
fill 336 116 234 336 116 235 minecraft:light_gray_concrete
fill 336 116 237 336 116 238 minecraft:light_gray_concrete
fill 336 116 240 336 116 241 minecraft:light_gray_concrete
fill 336 116 243 336 116 244 minecraft:light_gray_concrete
fill 336 116 246 336 116 247 minecraft:light_gray_concrete
fill 336 116 249 336 116 250 minecraft:light_gray_concrete
fill 336 116 252 336 116 253 minecraft:light_gray_concrete
fill 336 116 255 336 116 256 minecraft:light_gray_concrete
fill 336 116 258 336 116 259 minecraft:light_gray_concrete
fill 336 116 261 336 116 262 minecraft:light_gray_concrete
fill 336 116 264 337 116 264 minecraft:light_gray_concrete
fill 336 116 267 337 116 267 minecraft:light_gray_concrete
fill 337 116 230 337 116 231 minecraft:light_gray_concrete
fill 337 116 233 337 116 234 minecraft:light_gray_concrete
fill 337 116 236 337 116 237 minecraft:light_gray_concrete
fill 337 116 239 337 116 240 minecraft:light_gray_concrete
fill 337 116 242 337 116 243 minecraft:light_gray_concrete
fill 337 116 245 337 116 246 minecraft:light_gray_concrete
fill 337 116 248 337 116 249 minecraft:light_gray_concrete
fill 337 116 251 337 116 252 minecraft:light_gray_concrete
fill 337 116 254 337 116 255 minecraft:light_gray_concrete
fill 337 116 257 337 116 258 minecraft:light_gray_concrete
fill 337 116 260 337 116 261 minecraft:light_gray_concrete
fill 337 116 263 338 116 263 minecraft:light_gray_concrete
fill 337 116 266 338 116 266 minecraft:light_gray_concrete
fill 337 116 269 338 116 269 minecraft:light_gray_concrete
fill 338 116 229 338 116 230 minecraft:light_gray_concrete
fill 338 116 232 338 116 233 minecraft:light_gray_concrete
fill 338 116 235 338 116 236 minecraft:light_gray_concrete
fill 338 116 262 339 116 262 minecraft:light_gray_concrete
fill 338 116 265 339 116 265 minecraft:light_gray_concrete
fill 338 116 268 339 116 268 minecraft:light_gray_concrete
setblock 339 116 229 minecraft:light_gray_concrete
fill 339 116 231 339 116 232 minecraft:light_gray_concrete
fill 339 116 234 339 116 235 minecraft:light_gray_concrete
fill 339 116 264 340 116 264 minecraft:light_gray_concrete
fill 339 116 267 340 116 267 minecraft:light_gray_concrete
fill 340 116 230 340 116 231 minecraft:light_gray_concrete
fill 340 116 233 340 116 234 minecraft:light_gray_concrete
fill 340 116 236 341 116 236 minecraft:light_gray_concrete
fill 340 116 263 341 116 263 minecraft:light_gray_concrete
fill 340 116 266 341 116 266 minecraft:light_gray_concrete
fill 340 116 269 341 116 269 minecraft:light_gray_concrete
fill 341 116 229 341 116 230 minecraft:light_gray_concrete
fill 341 116 232 341 116 233 minecraft:light_gray_concrete
fill 341 116 235 342 116 235 minecraft:light_gray_concrete
fill 341 116 262 342 116 262 minecraft:light_gray_concrete
fill 341 116 265 342 116 265 minecraft:light_gray_concrete
fill 341 116 268 342 116 268 minecraft:light_gray_concrete
setblock 342 116 229 minecraft:light_gray_concrete
fill 342 116 231 342 116 232 minecraft:light_gray_concrete
fill 342 116 234 343 116 234 minecraft:light_gray_concrete
fill 342 116 264 343 116 264 minecraft:light_gray_concrete
fill 342 116 267 343 116 267 minecraft:light_gray_concrete
fill 343 116 230 343 116 231 minecraft:light_gray_concrete
fill 343 116 233 344 116 233 minecraft:light_gray_concrete
fill 343 116 236 344 116 236 minecraft:light_gray_concrete
fill 343 116 263 344 116 263 minecraft:light_gray_concrete
fill 343 116 266 344 116 266 minecraft:light_gray_concrete
fill 343 116 269 344 116 269 minecraft:light_gray_concrete
fill 344 116 229 344 116 230 minecraft:light_gray_concrete
fill 344 116 232 345 116 232 minecraft:light_gray_concrete
fill 344 116 235 345 116 235 minecraft:light_gray_concrete
fill 344 116 262 345 116 262 minecraft:light_gray_concrete
fill 344 116 265 345 116 265 minecraft:light_gray_concrete
fill 344 116 268 345 116 268 minecraft:light_gray_concrete
setblock 345 116 229 minecraft:light_gray_concrete
fill 345 116 231 346 116 231 minecraft:light_gray_concrete
fill 345 116 234 346 116 234 minecraft:light_gray_concrete
fill 345 116 264 346 116 264 minecraft:light_gray_concrete
fill 345 116 267 346 116 267 minecraft:light_gray_concrete
fill 346 116 230 347 116 230 minecraft:light_gray_concrete
fill 346 116 233 347 116 233 minecraft:light_gray_concrete
fill 346 116 236 347 116 236 minecraft:light_gray_concrete
fill 346 116 263 347 116 263 minecraft:light_gray_concrete
setblock 346 116 266 minecraft:light_gray_concrete
fill 346 116 269 347 116 269 minecraft:light_gray_concrete
fill 346 116 270 346 122 270 minecraft:stone_bricks
fill 347 116 229 348 116 229 minecraft:light_gray_concrete
fill 347 116 232 348 116 232 minecraft:light_gray_concrete
fill 347 116 235 348 116 235 minecraft:light_gray_concrete
fill 347 116 262 348 116 262 minecraft:light_gray_concrete
fill 347 116 265 348 116 265 minecraft:light_gray_concrete
fill 347 116 268 348 116 268 minecraft:light_gray_concrete
fill 348 116 231 349 116 231 minecraft:light_gray_concrete
fill 348 116 234 349 116 234 minecraft:light_gray_concrete
fill 348 116 264 349 116 264 minecraft:light_gray_concrete
fill 348 116 267 349 116 267 minecraft:light_gray_concrete
fill 349 116 230 350 116 230 minecraft:light_gray_concrete
fill 349 116 233 350 116 233 minecraft:light_gray_concrete
fill 349 116 236 350 116 236 minecraft:light_gray_concrete
fill 349 116 263 350 116 263 minecraft:light_gray_concrete
fill 349 116 266 350 116 266 minecraft:light_gray_concrete
fill 349 116 269 350 116 269 minecraft:light_gray_concrete
fill 350 116 229 351 116 229 minecraft:light_gray_concrete
fill 350 116 232 351 116 232 minecraft:light_gray_concrete
fill 350 116 235 351 116 235 minecraft:light_gray_concrete
fill 350 116 262 351 116 262 minecraft:light_gray_concrete
fill 350 116 265 351 116 265 minecraft:light_gray_concrete
fill 350 116 268 351 116 268 minecraft:light_gray_concrete
fill 351 116 231 352 116 231 minecraft:light_gray_concrete
fill 351 116 234 352 116 234 minecraft:light_gray_concrete
fill 351 116 264 352 116 264 minecraft:light_gray_concrete
fill 351 116 267 352 116 267 minecraft:light_gray_concrete
fill 352 116 230 353 116 230 minecraft:light_gray_concrete
fill 352 116 233 353 116 233 minecraft:light_gray_concrete
fill 352 116 236 353 116 236 minecraft:light_gray_concrete
fill 352 116 263 353 116 263 minecraft:light_gray_concrete
fill 352 116 266 353 116 266 minecraft:light_gray_concrete
fill 352 116 269 353 116 269 minecraft:light_gray_concrete
fill 353 116 229 354 116 229 minecraft:light_gray_concrete
fill 353 116 232 354 116 232 minecraft:light_gray_concrete
fill 353 116 235 354 116 235 minecraft:light_gray_concrete
fill 353 116 262 354 116 262 minecraft:light_gray_concrete
fill 353 116 265 354 116 265 minecraft:light_gray_concrete
fill 353 116 268 354 116 268 minecraft:light_gray_concrete
fill 354 116 231 355 116 231 minecraft:light_gray_concrete
fill 354 116 234 355 116 234 minecraft:light_gray_concrete
fill 354 116 264 355 116 264 minecraft:light_gray_concrete
fill 354 116 267 355 116 267 minecraft:light_gray_concrete
fill 355 116 230 356 116 230 minecraft:light_gray_concrete
fill 355 116 233 356 116 233 minecraft:light_gray_concrete
fill 355 116 236 356 116 236 minecraft:light_gray_concrete
fill 355 116 263 356 116 263 minecraft:light_gray_concrete
fill 355 116 266 356 116 266 minecraft:light_gray_concrete
fill 355 116 269 356 116 269 minecraft:light_gray_concrete
fill 356 116 229 357 116 229 minecraft:light_gray_concrete
fill 356 116 232 357 116 232 minecraft:light_gray_concrete
fill 356 116 235 357 116 235 minecraft:light_gray_concrete
fill 356 116 262 357 116 262 minecraft:light_gray_concrete
fill 356 116 265 357 116 265 minecraft:light_gray_concrete
fill 356 116 268 357 116 268 minecraft:light_gray_concrete
fill 357 116 231 358 116 231 minecraft:light_gray_concrete
fill 357 116 234 358 116 234 minecraft:light_gray_concrete
fill 357 116 264 358 116 264 minecraft:light_gray_concrete
fill 357 116 267 358 116 267 minecraft:light_gray_concrete
fill 358 116 230 359 116 230 minecraft:light_gray_concrete
fill 358 116 233 359 116 233 minecraft:light_gray_concrete
fill 358 116 236 359 116 236 minecraft:light_gray_concrete
fill 358 116 263 359 116 263 minecraft:light_gray_concrete
fill 358 116 266 359 116 266 minecraft:light_gray_concrete
fill 358 116 269 359 116 269 minecraft:light_gray_concrete
fill 359 116 229 360 116 229 minecraft:light_gray_concrete
fill 359 116 232 360 116 232 minecraft:light_gray_concrete
fill 359 116 235 360 116 235 minecraft:light_gray_concrete
fill 359 116 262 360 116 262 minecraft:light_gray_concrete
fill 359 116 265 360 116 265 minecraft:light_gray_concrete
fill 359 116 268 360 116 268 minecraft:light_gray_concrete
fill 360 116 231 361 116 231 minecraft:light_gray_concrete
fill 360 116 234 361 116 234 minecraft:light_gray_concrete
fill 360 116 264 361 116 264 minecraft:light_gray_concrete
fill 360 116 267 361 116 267 minecraft:light_gray_concrete
fill 361 116 230 362 116 230 minecraft:light_gray_concrete
fill 361 116 233 362 116 233 minecraft:light_gray_concrete
fill 361 116 236 362 116 236 minecraft:light_gray_concrete
fill 361 116 263 362 116 263 minecraft:light_gray_concrete
fill 361 116 266 362 116 266 minecraft:light_gray_concrete
fill 361 116 269 362 116 269 minecraft:light_gray_concrete
fill 362 116 229 363 116 229 minecraft:light_gray_concrete
fill 362 116 232 363 116 232 minecraft:light_gray_concrete
fill 362 116 235 363 116 235 minecraft:light_gray_concrete
fill 362 116 262 363 116 262 minecraft:light_gray_concrete
fill 362 116 265 363 116 265 minecraft:light_gray_concrete
fill 362 116 268 363 116 268 minecraft:light_gray_concrete
fill 363 116 231 364 116 231 minecraft:light_gray_concrete
fill 363 116 234 364 116 234 minecraft:light_gray_concrete
fill 363 116 237 363 116 238 minecraft:light_gray_concrete
fill 363 116 240 363 116 241 minecraft:light_gray_concrete
fill 363 116 243 363 116 244 minecraft:light_gray_concrete
fill 363 116 246 363 116 247 minecraft:light_gray_concrete
fill 363 116 249 363 116 250 minecraft:light_gray_concrete
fill 363 116 252 363 116 253 minecraft:light_gray_concrete
fill 363 116 255 363 116 256 minecraft:light_gray_concrete
fill 363 116 258 363 116 259 minecraft:light_gray_concrete
fill 363 116 261 364 116 261 minecraft:light_gray_concrete
fill 363 116 264 364 116 264 minecraft:light_gray_concrete
fill 363 116 267 364 116 267 minecraft:light_gray_concrete
fill 364 116 230 365 116 230 minecraft:light_gray_concrete
fill 364 116 233 365 116 233 minecraft:light_gray_concrete
fill 364 116 236 364 116 237 minecraft:light_gray_concrete
fill 364 116 239 364 116 240 minecraft:light_gray_concrete
fill 364 116 242 364 116 243 minecraft:light_gray_concrete
fill 364 116 245 364 116 246 minecraft:light_gray_concrete
fill 364 116 248 364 116 249 minecraft:light_gray_concrete
fill 364 116 251 364 116 252 minecraft:light_gray_concrete
fill 364 116 254 364 116 255 minecraft:light_gray_concrete
fill 364 116 257 364 116 258 minecraft:light_gray_concrete
fill 364 116 260 365 116 260 minecraft:light_gray_concrete
fill 364 116 263 365 116 263 minecraft:light_gray_concrete
fill 364 116 266 365 116 266 minecraft:light_gray_concrete
fill 364 116 269 365 116 269 minecraft:light_gray_concrete
fill 365 116 229 366 116 229 minecraft:light_gray_concrete
fill 365 116 232 366 116 232 minecraft:light_gray_concrete
fill 365 116 235 365 116 236 minecraft:light_gray_concrete
fill 365 116 238 365 116 239 minecraft:light_gray_concrete
fill 365 116 241 365 116 242 minecraft:light_gray_concrete
fill 365 116 244 365 116 245 minecraft:light_gray_concrete
fill 365 116 247 365 116 248 minecraft:light_gray_concrete
fill 365 116 250 365 116 251 minecraft:light_gray_concrete
fill 365 116 253 365 116 254 minecraft:light_gray_concrete
fill 365 116 256 365 116 257 minecraft:light_gray_concrete
fill 365 116 259 366 116 259 minecraft:light_gray_concrete
fill 365 116 262 366 116 262 minecraft:light_gray_concrete
setblock 365 116 265 minecraft:light_gray_concrete
fill 365 116 268 366 116 268 minecraft:light_gray_concrete
fill 366 116 231 367 116 231 minecraft:light_gray_concrete
fill 366 116 234 366 116 235 minecraft:light_gray_concrete
fill 366 116 237 366 116 238 minecraft:light_gray_concrete
fill 366 116 243 366 116 244 minecraft:light_gray_concrete
fill 366 116 246 366 116 247 minecraft:light_gray_concrete
fill 366 116 249 366 116 250 minecraft:light_gray_concrete
fill 366 116 252 366 116 253 minecraft:light_gray_concrete
fill 366 116 255 366 116 256 minecraft:light_gray_concrete
fill 366 116 258 367 116 258 minecraft:light_gray_concrete
fill 366 116 261 367 116 261 minecraft:light_gray_concrete
fill 366 116 267 367 116 267 minecraft:light_gray_concrete
fill 367 116 230 368 116 230 minecraft:light_gray_concrete
fill 367 116 233 367 116 234 minecraft:light_gray_concrete
fill 367 116 236 367 116 237 minecraft:light_gray_concrete
fill 367 116 239 368 116 239 minecraft:light_gray_concrete
setblock 367 116 243 minecraft:light_gray_concrete
fill 367 116 245 367 116 246 minecraft:light_gray_concrete
fill 367 116 248 367 116 249 minecraft:light_gray_concrete
fill 367 116 251 367 116 252 minecraft:light_gray_concrete
fill 367 116 254 367 116 255 minecraft:light_gray_concrete
fill 367 116 257 368 116 257 minecraft:light_gray_concrete
fill 367 116 260 368 116 260 minecraft:light_gray_concrete
fill 367 116 266 368 116 266 minecraft:light_gray_concrete
fill 367 116 269 368 116 269 minecraft:light_gray_concrete
fill 368 116 229 369 116 229 minecraft:light_gray_concrete
fill 368 116 232 368 116 233 minecraft:light_gray_concrete
fill 368 116 235 368 116 236 minecraft:light_gray_concrete
fill 368 116 238 369 116 238 minecraft:light_gray_concrete
fill 368 116 244 368 116 245 minecraft:light_gray_concrete
fill 368 116 247 368 116 248 minecraft:light_gray_concrete
fill 368 116 250 368 116 251 minecraft:light_gray_concrete
fill 368 116 253 368 116 254 minecraft:light_gray_concrete
fill 368 116 256 369 116 256 minecraft:light_gray_concrete
fill 368 116 259 369 116 259 minecraft:light_gray_concrete
fill 368 116 262 369 116 262 minecraft:light_gray_concrete
fill 368 116 268 369 116 268 minecraft:light_gray_concrete
fill 369 116 231 369 116 232 minecraft:light_gray_concrete
fill 369 116 234 369 116 235 minecraft:light_gray_concrete
fill 369 116 237 370 116 237 minecraft:light_gray_concrete
fill 369 116 240 369 116 241 minecraft:light_gray_concrete
fill 369 116 243 369 116 244 minecraft:light_gray_concrete
fill 369 116 246 369 116 247 minecraft:light_gray_concrete
fill 369 116 249 369 116 250 minecraft:light_gray_concrete
fill 369 116 252 369 116 253 minecraft:light_gray_concrete
fill 369 116 255 370 116 255 minecraft:light_gray_concrete
fill 369 116 258 370 116 258 minecraft:light_gray_concrete
fill 369 116 261 370 116 261 minecraft:light_gray_concrete
fill 369 116 264 369 116 265 minecraft:light_gray_concrete
fill 369 116 267 370 116 267 minecraft:light_gray_concrete
fill 369 116 270 369 120 270 minecraft:stone_bricks
fill 370 116 230 370 116 231 minecraft:light_gray_concrete
fill 370 116 233 370 116 234 minecraft:light_gray_concrete
setblock 370 116 236 minecraft:light_gray_concrete
fill 370 116 239 370 116 240 minecraft:light_gray_concrete
fill 370 116 242 370 116 243 minecraft:light_gray_concrete
fill 370 116 245 370 116 246 minecraft:light_gray_concrete
fill 370 116 248 370 116 249 minecraft:light_gray_concrete
fill 370 116 251 370 116 252 minecraft:light_gray_concrete
setblock 370 116 254 minecraft:light_gray_concrete
setblock 370 116 257 minecraft:light_gray_concrete
setblock 370 116 260 minecraft:light_gray_concrete
setblock 370 116 263 minecraft:lime_terracotta
setblock 370 116 264 minecraft:light_gray_concrete
setblock 370 116 266 minecraft:light_gray_concrete
setblock 370 116 269 minecraft:light_gray_concrete
fill 329 117 268 329 173 268 minecraft:stone_bricks
setblock 331 117 269 minecraft:lime_terracotta
fill 337 117 236 337 117 262 minecraft:light_blue_concrete
fill 338 117 236 363 117 236 minecraft:light_blue_concrete
fill 338 117 262 363 117 262 minecraft:light_blue_concrete
fill 363 117 237 363 117 261 minecraft:light_blue_concrete
setblock 371 117 256 minecraft:mossy_cobblestone
setblock 371 117 266 minecraft:mossy_stone_bricks
setblock 329 118 235 minecraft:mossy_cobblestone
setblock 329 118 258 minecraft:mossy_cobblestone
setblock 332 118 231 minecraft:light[level=15]
setblock 332 118 239 minecraft:light[level=15]
setblock 332 118 247 minecraft:light[level=15]
setblock 332 118 255 minecraft:light[level=15]
setblock 332 118 263 minecraft:light[level=15]
setblock 340 118 231 minecraft:light[level=15]
setblock 340 118 239 minecraft:light[level=15]
setblock 340 118 247 minecraft:light[level=15]
setblock 340 118 255 minecraft:light[level=15]
setblock 340 118 263 minecraft:light[level=15]
setblock 348 118 231 minecraft:light[level=15]
setblock 348 118 239 minecraft:light[level=15]
setblock 348 118 247 minecraft:light[level=15]
setblock 348 118 255 minecraft:light[level=15]
setblock 348 118 263 minecraft:light[level=15]
setblock 348 118 270 minecraft:cobblestone
setblock 356 118 231 minecraft:light[level=15]
setblock 356 118 239 minecraft:light[level=15]
setblock 356 118 247 minecraft:light[level=15]
setblock 356 118 255 minecraft:light[level=15]
setblock 356 118 263 minecraft:light[level=15]
setblock 364 118 231 minecraft:light[level=15]
setblock 364 118 239 minecraft:light[level=15]
setblock 364 118 247 minecraft:light[level=15]
setblock 364 118 255 minecraft:light[level=15]
setblock 364 118 263 minecraft:light[level=15]
fill 365 118 263 365 118 265 minecraft:light_gray_concrete
fill 366 118 262 368 118 262 minecraft:light_gray_concrete
fill 366 118 266 368 118 266 minecraft:light_gray_concrete
fill 369 118 263 369 118 265 minecraft:light_gray_concrete
fill 371 118 256 371 183 256 minecraft:stone_bricks
fill 371 118 266 371 141 266 minecraft:stone_bricks
fill 329 119 235 329 172 235 minecraft:stone_bricks
fill 329 119 258 329 280 258 minecraft:stone_bricks
fill 348 119 270 348 147 270 minecraft:stone_bricks
setblock 361 119 228 minecraft:mossy_cobblestone
fill 366 119 240 366 119 242 minecraft:iron_block
fill 367 119 232 369 124 233 minecraft:gray_concrete
fill 367 119 239 369 124 240 minecraft:gray_concrete
fill 367 119 241 367 119 242 minecraft:iron_block
fill 367 119 246 369 124 247 minecraft:gray_concrete
fill 367 119 253 369 124 254 minecraft:gray_concrete
fill 367 119 260 369 124 261 minecraft:gray_concrete
fill 368 119 231 368 124 231 minecraft:gray_concrete
fill 368 119 234 368 124 234 minecraft:gray_concrete
fill 368 119 238 368 124 238 minecraft:gray_concrete
fill 368 119 241 368 124 241 minecraft:gray_concrete
setblock 368 119 242 minecraft:iron_block
fill 368 119 245 368 124 245 minecraft:gray_concrete
fill 368 119 248 368 124 248 minecraft:gray_concrete
fill 368 119 252 368 124 252 minecraft:gray_concrete
fill 368 119 255 368 124 255 minecraft:gray_concrete
fill 368 119 259 368 124 259 minecraft:gray_concrete
fill 368 119 262 368 124 262 minecraft:gray_concrete
setblock 329 120 231 minecraft:cobblestone
fill 337 120 228 337 151 228 minecraft:stone_bricks
setblock 338 120 228 minecraft:mossy_stone_bricks
fill 346 120 265 346 120 267 minecraft:light_gray_concrete
fill 347 120 265 348 120 265 minecraft:light_gray_concrete
fill 347 120 267 348 120 267 minecraft:light_gray_concrete
setblock 348 120 266 minecraft:light_gray_concrete
setblock 350 120 228 minecraft:mossy_cobblestone
fill 361 120 228 361 154 228 minecraft:stone_bricks
fill 366 120 231 366 123 234 minecraft:gray_concrete
fill 366 120 238 366 123 241 minecraft:gray_concrete
fill 366 120 242 366 159 242 minecraft:iron_block
fill 366 120 245 366 123 248 minecraft:gray_concrete
fill 366 120 252 366 123 255 minecraft:gray_concrete
fill 366 120 259 366 123 262 minecraft:gray_concrete
fill 366 120 263 366 159 265 minecraft:iron_block
fill 367 120 228 369 123 229 minecraft:iron_block
fill 367 120 230 367 123 231 minecraft:gray_concrete
fill 367 120 234 367 123 235 minecraft:gray_concrete
fill 367 120 236 369 123 236 minecraft:iron_block
fill 367 120 237 367 123 238 minecraft:gray_concrete
fill 367 120 241 367 123 242 minecraft:gray_concrete
fill 367 120 243 369 123 243 minecraft:iron_block
fill 367 120 244 367 123 245 minecraft:gray_concrete
fill 367 120 248 367 123 249 minecraft:gray_concrete
fill 367 120 250 369 123 250 minecraft:iron_block
fill 367 120 251 367 123 252 minecraft:gray_concrete
fill 367 120 255 367 123 256 minecraft:gray_concrete
fill 367 120 257 369 123 257 minecraft:iron_block
fill 367 120 258 367 123 259 minecraft:gray_concrete
fill 367 120 262 367 123 263 minecraft:gray_concrete
fill 367 120 264 369 123 269 minecraft:iron_block
fill 368 120 230 369 123 230 minecraft:gray_concrete
fill 368 120 235 369 123 235 minecraft:gray_concrete
fill 368 120 237 369 123 237 minecraft:gray_concrete
fill 368 120 242 369 123 242 minecraft:gray_concrete
fill 368 120 244 369 123 244 minecraft:gray_concrete
fill 368 120 249 369 123 249 minecraft:gray_concrete
fill 368 120 251 369 123 251 minecraft:gray_concrete
fill 368 120 256 369 123 256 minecraft:gray_concrete
fill 368 120 258 369 123 258 minecraft:gray_concrete
fill 368 120 263 369 123 263 minecraft:gray_concrete
fill 368 120 270 368 123 270 minecraft:iron_block
fill 369 120 231 370 123 231 minecraft:gray_concrete
fill 369 120 234 370 123 234 minecraft:gray_concrete
fill 369 120 238 370 123 238 minecraft:gray_concrete
fill 369 120 241 370 123 241 minecraft:gray_concrete
fill 369 120 245 370 123 245 minecraft:gray_concrete
fill 369 120 248 370 123 248 minecraft:gray_concrete
fill 369 120 252 370 123 252 minecraft:gray_concrete
fill 369 120 255 370 123 255 minecraft:gray_concrete
fill 369 120 259 370 123 259 minecraft:gray_concrete
fill 369 120 262 370 123 262 minecraft:gray_concrete
fill 370 120 232 370 123 233 minecraft:gray_concrete
fill 370 120 239 370 123 240 minecraft:gray_concrete
fill 370 120 246 370 123 247 minecraft:gray_concrete
fill 370 120 253 370 123 254 minecraft:gray_concrete
fill 370 120 260 370 123 261 minecraft:gray_concrete
fill 329 121 231 329 280 231 minecraft:stone_bricks
setblock 329 121 239 minecraft:cobblestone
setblock 332 121 231 minecraft:light[level=12]
setblock 332 121 238 minecraft:light[level=12]
setblock 332 121 245 minecraft:light[level=12]
setblock 332 121 252 minecraft:light[level=12]
setblock 332 121 259 minecraft:light[level=12]
setblock 332 121 266 minecraft:light[level=12]
fill 338 121 228 338 227 228 minecraft:stone_bricks
setblock 339 121 231 minecraft:light[level=12]
setblock 339 121 238 minecraft:light[level=12]
setblock 339 121 245 minecraft:light[level=12]
setblock 339 121 252 minecraft:light[level=12]
setblock 339 121 259 minecraft:light[level=12]
setblock 339 121 266 minecraft:light[level=12]
setblock 346 121 231 minecraft:light[level=12]
setblock 346 121 238 minecraft:light[level=12]
setblock 346 121 245 minecraft:light[level=12]
setblock 346 121 252 minecraft:light[level=12]
setblock 346 121 259 minecraft:light[level=12]
setblock 346 121 266 minecraft:light[level=12]
fill 350 121 228 350 233 228 minecraft:stone_bricks
setblock 353 121 231 minecraft:light[level=12]
setblock 353 121 238 minecraft:light[level=12]
setblock 353 121 245 minecraft:light[level=12]
setblock 353 121 252 minecraft:light[level=12]
setblock 353 121 259 minecraft:light[level=12]
setblock 353 121 266 minecraft:light[level=12]
setblock 356 121 229 minecraft:green_concrete
setblock 360 121 231 minecraft:light[level=12]
setblock 360 121 238 minecraft:light[level=12]
setblock 360 121 245 minecraft:light[level=12]
setblock 360 121 252 minecraft:light[level=12]
setblock 360 121 259 minecraft:light[level=12]
setblock 360 121 266 minecraft:light[level=12]
fill 365 121 240 365 121 242 minecraft:light_gray_concrete
fill 366 121 228 366 122 230 minecraft:iron_block
fill 366 121 235 366 122 237 minecraft:iron_block
fill 366 121 243 366 122 244 minecraft:iron_block
fill 366 121 249 366 122 251 minecraft:iron_block
fill 366 121 256 366 122 258 minecraft:iron_block
fill 366 121 266 366 122 269 minecraft:iron_block
fill 366 121 270 366 160 270 minecraft:stone_bricks
fill 367 121 270 367 122 270 minecraft:iron_block
fill 369 121 270 369 122 270 minecraft:iron_block
fill 370 121 228 370 122 230 minecraft:iron_block
fill 370 121 235 370 122 237 minecraft:iron_block
fill 370 121 242 370 122 244 minecraft:iron_block
fill 370 121 249 370 122 251 minecraft:iron_block
fill 370 121 256 370 122 258 minecraft:iron_block
fill 370 121 263 370 122 269 minecraft:iron_block
fill 329 122 239 329 184 239 minecraft:stone_bricks
setblock 346 123 270 minecraft:cobblestone
setblock 363 123 270 minecraft:mossy_cobblestone
fill 365 123 263 365 123 265 minecraft:light_gray_concrete
fill 366 123 228 366 124 228 minecraft:stone_bricks
setblock 366 123 266 minecraft:light_gray_concrete
fill 367 123 270 367 159 270 minecraft:stone_bricks
fill 369 123 270 369 280 270 minecraft:stone_bricks
fill 370 123 228 370 124 228 minecraft:stone_bricks
setblock 330 124 250 minecraft:lime_terracotta
fill 346 124 270 346 151 270 minecraft:stone_bricks
fill 363 124 270 363 205 270 minecraft:stone_bricks
fill 366 124 240 366 158 241 minecraft:iron_block
fill 367 124 228 369 128 228 minecraft:stone_bricks
fill 367 124 241 367 158 242 minecraft:iron_block
fill 367 124 263 368 159 265 minecraft:iron_block
fill 368 124 242 368 159 242 minecraft:iron_block
fill 368 124 270 368 160 270 minecraft:stone_bricks
setblock 329 125 238 minecraft:mossy_stone_bricks
setblock 329 125 246 minecraft:mossy_cobblestone
fill 329 125 247 329 244 248 minecraft:stone_bricks
setblock 332 125 231 minecraft:light[level=15]
setblock 332 125 239 minecraft:light[level=15]
setblock 332 125 247 minecraft:light[level=15]
setblock 332 125 255 minecraft:light[level=15]
setblock 332 125 263 minecraft:light[level=15]
setblock 340 125 231 minecraft:light[level=15]
setblock 340 125 239 minecraft:light[level=15]
setblock 340 125 247 minecraft:light[level=15]
setblock 340 125 255 minecraft:light[level=15]
setblock 340 125 263 minecraft:light[level=15]
setblock 348 125 231 minecraft:light[level=15]
setblock 348 125 239 minecraft:light[level=15]
setblock 348 125 247 minecraft:light[level=15]
setblock 348 125 255 minecraft:light[level=15]
setblock 348 125 263 minecraft:light[level=15]
setblock 351 125 228 minecraft:mossy_cobblestone
fill 355 125 270 355 142 270 minecraft:stone_bricks
setblock 356 125 231 minecraft:light[level=15]
setblock 356 125 239 minecraft:light[level=15]
setblock 356 125 247 minecraft:light[level=15]
setblock 356 125 255 minecraft:light[level=15]
setblock 356 125 263 minecraft:light[level=15]
setblock 356 125 270 minecraft:mossy_stone_bricks
setblock 364 125 231 minecraft:light[level=15]
setblock 364 125 239 minecraft:light[level=15]
setblock 364 125 247 minecraft:light[level=15]
setblock 364 125 255 minecraft:light[level=15]
setblock 364 125 263 minecraft:light[level=15]
setblock 364 125 269 minecraft:lime_terracotta
setblock 366 125 228 minecraft:cobblestone
fill 367 125 240 368 158 240 minecraft:iron_block
fill 368 125 241 368 159 241 minecraft:iron_block
setblock 370 125 228 minecraft:mossy_cobblestone
setblock 329 126 232 minecraft:cobblestone
fill 329 126 238 329 280 238 minecraft:stone_bricks
fill 329 126 246 329 280 246 minecraft:stone_bricks
fill 351 126 228 351 254 228 minecraft:stone_bricks
fill 356 126 270 356 222 270 minecraft:stone_bricks
setblock 359 126 269 minecraft:lime_terracotta
fill 360 126 249 361 127 249 minecraft:light_blue_stained_glass
fill 366 126 228 366 159 228 minecraft:stone_bricks
fill 370 126 228 370 206 228 minecraft:stone_bricks
setblock 371 126 232 minecraft:mossy_cobblestone
fill 371 126 233 371 130 235 minecraft:stone_bricks
fill 329 127 232 329 143 232 minecraft:stone_bricks
setblock 332 127 228 minecraft:cobblestone
setblock 332 127 231 minecraft:light[level=12]
setblock 332 127 238 minecraft:light[level=12]
setblock 332 127 245 minecraft:light[level=12]
setblock 332 127 252 minecraft:light[level=12]
setblock 332 127 259 minecraft:light[level=12]
setblock 332 127 266 minecraft:light[level=12]
setblock 339 127 231 minecraft:light[level=12]
setblock 339 127 238 minecraft:light[level=12]
setblock 339 127 245 minecraft:light[level=12]
setblock 339 127 252 minecraft:light[level=12]
setblock 339 127 259 minecraft:light[level=12]
setblock 339 127 266 minecraft:light[level=12]
setblock 346 127 231 minecraft:light[level=12]
setblock 346 127 238 minecraft:light[level=12]
setblock 346 127 245 minecraft:light[level=12]
setblock 346 127 252 minecraft:light[level=12]
setblock 346 127 259 minecraft:light[level=12]
fill 346 127 265 346 127 267 minecraft:light_gray_concrete
fill 347 127 265 348 127 265 minecraft:light_gray_concrete
fill 347 127 267 348 127 267 minecraft:light_gray_concrete
setblock 348 127 266 minecraft:light_gray_concrete
setblock 353 127 231 minecraft:light[level=12]
setblock 353 127 238 minecraft:light[level=12]
setblock 353 127 245 minecraft:light[level=12]
setblock 353 127 252 minecraft:light[level=12]
setblock 353 127 259 minecraft:light[level=12]
setblock 353 127 266 minecraft:light[level=12]
fill 359 127 233 359 128 233 minecraft:white_stained_glass
setblock 360 127 231 minecraft:light[level=12]
setblock 360 127 238 minecraft:light[level=12]
setblock 360 127 245 minecraft:light[level=12]
setblock 360 127 252 minecraft:light[level=12]
setblock 360 127 259 minecraft:light[level=12]
setblock 360 127 266 minecraft:light[level=12]
setblock 367 127 231 minecraft:light[level=12]
setblock 367 127 238 minecraft:light[level=12]
setblock 367 127 245 minecraft:light[level=12]
setblock 367 127 252 minecraft:light[level=12]
setblock 367 127 259 minecraft:light[level=12]
setblock 367 127 266 minecraft:light[level=12]
fill 371 127 232 371 138 232 minecraft:stone_bricks
fill 332 128 228 332 232 228 minecraft:stone_bricks
setblock 337 128 270 minecraft:mossy_cobblestone
setblock 350 128 269 minecraft:green_concrete
fill 365 128 263 365 128 265 minecraft:light_gray_concrete
fill 366 128 262 368 128 262 minecraft:light_gray_concrete
fill 366 128 266 368 128 266 minecraft:light_gray_concrete
fill 369 128 263 369 128 265 minecraft:light_gray_concrete
setblock 370 128 235 minecraft:lime_concrete
setblock 329 129 251 minecraft:cobblestone
setblock 330 129 235 minecraft:green_concrete
setblock 334 129 228 minecraft:cobblestone
fill 337 129 270 337 166 270 minecraft:stone_bricks
setblock 364 129 270 minecraft:cobblestone
fill 365 129 240 365 129 242 minecraft:light_gray_concrete
fill 366 129 239 368 129 239 minecraft:light_gray_concrete
fill 366 129 243 368 129 243 minecraft:light_gray_concrete
fill 367 129 228 367 159 228 minecraft:stone_bricks
setblock 367 129 269 minecraft:lime_concrete
setblock 368 129 228 minecraft:mossy_stone_bricks
fill 369 129 228 369 160 228 minecraft:stone_bricks
fill 369 129 240 369 129 242 minecraft:light_gray_concrete
fill 329 130 251 329 219 251 minecraft:stone_bricks
setblock 329 130 263 minecraft:mossy_stone_bricks
fill 334 130 228 334 244 228 minecraft:stone_bricks
setblock 336 130 229 minecraft:lime_terracotta
setblock 358 130 270 minecraft:mossy_cobblestone
fill 364 130 270 364 220 270 minecraft:stone_bricks
fill 368 130 228 368 159 228 minecraft:stone_bricks
setblock 371 130 229 minecraft:mossy_stone_bricks
setblock 371 130 269 minecraft:cobblestone
fill 329 131 263 329 167 263 minecraft:stone_bricks
fill 358 131 270 358 250 270 minecraft:stone_bricks
fill 366 131 257 366 132 258 minecraft:white_stained_glass
fill 371 131 229 371 195 229 minecraft:stone_bricks
setblock 371 131 233 minecraft:cobblestone
fill 371 131 234 371 155 235 minecraft:stone_bricks
setblock 371 131 241 minecraft:mossy_cobblestone
fill 371 131 269 371 280 269 minecraft:stone_bricks
setblock 332 132 231 minecraft:light[level=15]
setblock 332 132 239 minecraft:light[level=15]
setblock 332 132 247 minecraft:light[level=15]
setblock 332 132 255 minecraft:light[level=15]
setblock 332 132 263 minecraft:light[level=15]
setblock 340 132 231 minecraft:light[level=15]
setblock 340 132 239 minecraft:light[level=15]
setblock 340 132 247 minecraft:light[level=15]
setblock 340 132 255 minecraft:light[level=15]
setblock 340 132 263 minecraft:light[level=15]
setblock 348 132 231 minecraft:light[level=15]
setblock 348 132 239 minecraft:light[level=15]
setblock 348 132 247 minecraft:light[level=15]
setblock 348 132 255 minecraft:light[level=15]
setblock 348 132 263 minecraft:light[level=15]
setblock 352 132 270 minecraft:mossy_stone_bricks
setblock 356 132 231 minecraft:light[level=15]
setblock 356 132 239 minecraft:light[level=15]
setblock 356 132 247 minecraft:light[level=15]
setblock 356 132 255 minecraft:light[level=15]
setblock 356 132 263 minecraft:light[level=15]
setblock 364 132 231 minecraft:light[level=15]
setblock 364 132 239 minecraft:light[level=15]
setblock 364 132 247 minecraft:light[level=15]
setblock 364 132 255 minecraft:light[level=15]
setblock 364 132 263 minecraft:light[level=15]
fill 371 132 233 371 182 233 minecraft:stone_bricks
fill 371 132 241 371 144 241 minecraft:stone_bricks
setblock 329 133 249 minecraft:mossy_cobblestone
setblock 332 133 231 minecraft:light[level=12]
setblock 332 133 238 minecraft:light[level=12]
setblock 332 133 245 minecraft:light[level=12]
setblock 332 133 252 minecraft:light[level=12]
setblock 332 133 259 minecraft:light[level=12]
setblock 332 133 266 minecraft:light[level=12]
setblock 339 133 231 minecraft:light[level=12]
setblock 339 133 238 minecraft:light[level=12]
setblock 339 133 245 minecraft:light[level=12]
setblock 339 133 252 minecraft:light[level=12]
setblock 339 133 259 minecraft:light[level=12]
setblock 339 133 266 minecraft:light[level=12]
setblock 346 133 231 minecraft:light[level=12]
setblock 346 133 238 minecraft:light[level=12]
setblock 346 133 245 minecraft:light[level=12]
setblock 346 133 252 minecraft:light[level=12]
setblock 346 133 259 minecraft:light[level=12]
setblock 346 133 266 minecraft:light[level=12]
fill 352 133 270 352 280 270 minecraft:stone_bricks
setblock 353 133 231 minecraft:light[level=12]
setblock 353 133 238 minecraft:light[level=12]
setblock 353 133 245 minecraft:light[level=12]
setblock 353 133 252 minecraft:light[level=12]
setblock 353 133 259 minecraft:light[level=12]
setblock 353 133 266 minecraft:light[level=12]
setblock 360 133 231 minecraft:light[level=12]
setblock 360 133 238 minecraft:light[level=12]
setblock 360 133 245 minecraft:light[level=12]
setblock 360 133 252 minecraft:light[level=12]
setblock 360 133 259 minecraft:light[level=12]
setblock 360 133 266 minecraft:light[level=12]
fill 365 133 263 365 133 265 minecraft:light_gray_concrete
fill 366 133 262 368 133 262 minecraft:light_gray_concrete
fill 366 133 266 368 133 266 minecraft:light_gray_concrete
setblock 367 133 231 minecraft:light[level=12]
setblock 367 133 238 minecraft:light[level=12]
setblock 367 133 245 minecraft:light[level=12]
setblock 367 133 252 minecraft:light[level=12]
setblock 367 133 259 minecraft:light[level=12]
fill 369 133 263 369 133 265 minecraft:light_gray_concrete
fill 329 134 249 329 280 249 minecraft:stone_bricks
setblock 338 134 270 minecraft:cobblestone
fill 339 134 270 341 152 270 minecraft:stone_bricks
setblock 343 134 228 minecraft:cobblestone
fill 346 134 265 346 134 267 minecraft:light_gray_concrete
fill 347 134 265 348 134 265 minecraft:light_gray_concrete
fill 347 134 267 348 134 267 minecraft:light_gray_concrete
setblock 348 134 266 minecraft:light_gray_concrete
setblock 329 135 257 minecraft:cobblestone
setblock 330 135 234 minecraft:lime_terracotta
fill 338 135 270 338 138 270 minecraft:stone_bricks
fill 343 135 228 343 254 228 minecraft:stone_bricks
fill 355 135 228 355 152 228 minecraft:stone_bricks
setblock 356 135 228 minecraft:cobblestone
fill 329 136 257 329 154 257 minecraft:stone_bricks
fill 356 136 228 356 206 228 minecraft:stone_bricks
setblock 371 136 255 minecraft:mossy_stone_bricks
setblock 361 137 270 minecraft:mossy_stone_bricks
fill 365 137 240 365 137 242 minecraft:light_gray_concrete
fill 366 137 239 368 137 239 minecraft:light_gray_concrete
fill 366 137 243 368 137 243 minecraft:light_gray_concrete
fill 369 137 240 369 137 242 minecraft:light_gray_concrete
fill 371 137 255 371 280 255 minecraft:stone_bricks
setblock 371 137 259 minecraft:cobblestone
setblock 329 138 229 minecraft:mossy_cobblestone
setblock 349 138 229 minecraft:lime_concrete
fill 357 138 253 358 139 253 minecraft:white_stained_glass
setblock 358 138 229 minecraft:lime_concrete
fill 358 138 254 358 139 254 minecraft:white_stained_glass
fill 361 138 270 361 208 270 minecraft:stone_bricks
fill 365 138 263 365 138 265 minecraft:light_gray_concrete
fill 366 138 262 368 138 262 minecraft:light_gray_concrete
fill 366 138 266 368 138 266 minecraft:light_gray_concrete
fill 369 138 263 369 138 265 minecraft:light_gray_concrete
fill 371 138 259 371 269 259 minecraft:stone_bricks
fill 329 139 229 329 168 229 minecraft:stone_bricks
setblock 332 139 231 minecraft:light[level=15]
setblock 332 139 238 minecraft:light[level=12]
setblock 332 139 239 minecraft:light[level=15]
setblock 332 139 245 minecraft:light[level=12]
setblock 332 139 247 minecraft:light[level=15]
setblock 332 139 252 minecraft:light[level=12]
setblock 332 139 255 minecraft:light[level=15]
setblock 332 139 259 minecraft:light[level=12]
setblock 332 139 263 minecraft:light[level=15]
setblock 332 139 266 minecraft:light[level=12]
setblock 338 139 270 minecraft:mossy_cobblestone
setblock 339 139 231 minecraft:light[level=12]
setblock 339 139 238 minecraft:light[level=12]
setblock 339 139 245 minecraft:light[level=12]
setblock 339 139 252 minecraft:light[level=12]
setblock 339 139 259 minecraft:light[level=12]
setblock 339 139 266 minecraft:light[level=12]
setblock 340 139 231 minecraft:light[level=15]
setblock 340 139 239 minecraft:light[level=15]
setblock 340 139 247 minecraft:light[level=15]
setblock 340 139 255 minecraft:light[level=15]
setblock 340 139 263 minecraft:light[level=15]
setblock 346 139 231 minecraft:light[level=12]
setblock 346 139 238 minecraft:light[level=12]
setblock 346 139 245 minecraft:light[level=12]
setblock 346 139 252 minecraft:light[level=12]
setblock 346 139 259 minecraft:light[level=12]
setblock 346 139 266 minecraft:light[level=12]
setblock 348 139 231 minecraft:light[level=15]
setblock 348 139 239 minecraft:light[level=15]
setblock 348 139 247 minecraft:light[level=15]
setblock 348 139 255 minecraft:light[level=15]
setblock 348 139 263 minecraft:light[level=15]
setblock 353 139 231 minecraft:light[level=12]
fill 353 139 238 353 140 238 minecraft:light_blue_stained_glass
setblock 353 139 245 minecraft:light[level=12]
setblock 353 139 252 minecraft:light[level=12]
setblock 353 139 259 minecraft:light[level=12]
setblock 353 139 266 minecraft:light[level=12]
setblock 356 139 231 minecraft:light[level=15]
setblock 356 139 239 minecraft:light[level=15]
setblock 356 139 247 minecraft:light[level=15]
setblock 356 139 255 minecraft:light[level=15]
setblock 356 139 263 minecraft:light[level=15]
setblock 360 139 231 minecraft:light[level=12]
setblock 360 139 238 minecraft:light[level=12]
setblock 360 139 245 minecraft:light[level=12]
setblock 360 139 252 minecraft:light[level=12]
setblock 360 139 259 minecraft:light[level=12]
setblock 360 139 266 minecraft:light[level=12]
setblock 362 139 270 minecraft:cobblestone
setblock 364 139 231 minecraft:light[level=15]
setblock 364 139 239 minecraft:light[level=15]
setblock 364 139 247 minecraft:light[level=15]
setblock 364 139 255 minecraft:light[level=15]
setblock 364 139 263 minecraft:light[level=15]
setblock 367 139 231 minecraft:light[level=12]
setblock 367 139 238 minecraft:light[level=12]
setblock 367 139 245 minecraft:light[level=12]
setblock 367 139 252 minecraft:light[level=12]
setblock 367 139 259 minecraft:light[level=12]
setblock 367 139 266 minecraft:light[level=12]
setblock 371 139 232 minecraft:cobblestone
fill 338 140 270 338 162 270 minecraft:stone_bricks
fill 362 140 270 362 181 270 minecraft:stone_bricks
fill 371 140 232 371 252 232 minecraft:stone_bricks
fill 346 141 265 346 141 267 minecraft:light_gray_concrete
fill 347 141 265 348 141 265 minecraft:light_gray_concrete
fill 347 141 267 348 141 267 minecraft:light_gray_concrete
setblock 348 141 266 minecraft:light_gray_concrete
setblock 329 142 262 minecraft:mossy_cobblestone
setblock 330 142 229 minecraft:lime_concrete
setblock 352 142 228 minecraft:mossy_cobblestone
setblock 371 142 266 minecraft:mossy_cobblestone
fill 329 143 262 329 160 262 minecraft:stone_bricks
fill 352 143 228 352 153 228 minecraft:stone_bricks
setblock 355 143 270 minecraft:cobblestone
fill 365 143 263 365 143 265 minecraft:light_gray_concrete
fill 366 143 262 368 143 262 minecraft:light_gray_concrete
fill 366 143 266 368 143 266 minecraft:light_gray_concrete
fill 369 143 263 369 143 265 minecraft:light_gray_concrete
fill 371 143 266 371 148 266 minecraft:stone_bricks
setblock 329 144 232 minecraft:mossy_stone_bricks
setblock 329 144 256 minecraft:cobblestone
fill 355 144 270 355 178 270 minecraft:stone_bricks
fill 329 145 232 329 149 232 minecraft:stone_bricks
fill 329 145 256 329 280 256 minecraft:stone_bricks
setblock 332 145 231 minecraft:light[level=12]
setblock 332 145 238 minecraft:light[level=12]
setblock 332 145 245 minecraft:light[level=12]
setblock 332 145 252 minecraft:light[level=12]
setblock 332 145 259 minecraft:light[level=12]
setblock 332 145 266 minecraft:light[level=12]
setblock 339 145 231 minecraft:light[level=12]
setblock 339 145 238 minecraft:light[level=12]
setblock 339 145 245 minecraft:light[level=12]
setblock 339 145 252 minecraft:light[level=12]
setblock 339 145 259 minecraft:light[level=12]
setblock 339 145 266 minecraft:light[level=12]
setblock 346 145 231 minecraft:light[level=12]
setblock 346 145 238 minecraft:light[level=12]
setblock 346 145 245 minecraft:light[level=12]
setblock 346 145 252 minecraft:light[level=12]
setblock 346 145 259 minecraft:light[level=12]
setblock 346 145 266 minecraft:light[level=12]
setblock 353 145 231 minecraft:light[level=12]
setblock 353 145 238 minecraft:light[level=12]
setblock 353 145 245 minecraft:light[level=12]
setblock 353 145 252 minecraft:light[level=12]
setblock 353 145 259 minecraft:light[level=12]
setblock 353 145 266 minecraft:light[level=12]
setblock 360 145 228 minecraft:cobblestone
setblock 360 145 231 minecraft:light[level=12]
setblock 360 145 238 minecraft:light[level=12]
setblock 360 145 245 minecraft:light[level=12]
setblock 360 145 252 minecraft:light[level=12]
setblock 360 145 259 minecraft:light[level=12]
setblock 360 145 266 minecraft:light[level=12]
fill 365 145 240 365 145 242 minecraft:light_gray_concrete
fill 366 145 239 368 145 239 minecraft:light_gray_concrete
fill 366 145 243 368 145 243 minecraft:light_gray_concrete
setblock 367 145 231 minecraft:light[level=12]
setblock 367 145 238 minecraft:light[level=12]
setblock 367 145 245 minecraft:light[level=12]
setblock 367 145 252 minecraft:light[level=12]
setblock 367 145 259 minecraft:light[level=12]
setblock 367 145 266 minecraft:light[level=12]
fill 369 145 240 369 145 242 minecraft:light_gray_concrete
setblock 371 145 241 minecraft:mossy_cobblestone
fill 371 145 245 371 157 246 minecraft:stone_bricks
setblock 371 145 247 minecraft:mossy_stone_bricks
setblock 329 146 252 minecraft:mossy_cobblestone
setblock 332 146 231 minecraft:light[level=15]
setblock 332 146 239 minecraft:light[level=15]
setblock 332 146 247 minecraft:light[level=15]
setblock 332 146 255 minecraft:light[level=15]
setblock 332 146 263 minecraft:light[level=15]
setblock 336 146 270 minecraft:mossy_stone_bricks
setblock 340 146 231 minecraft:light[level=15]
setblock 340 146 239 minecraft:light[level=15]
setblock 340 146 247 minecraft:light[level=15]
setblock 340 146 255 minecraft:light[level=15]
setblock 340 146 263 minecraft:light[level=15]
setblock 348 146 231 minecraft:light[level=15]
setblock 348 146 239 minecraft:light[level=15]
setblock 348 146 247 minecraft:light[level=15]
setblock 348 146 255 minecraft:light[level=15]
setblock 348 146 263 minecraft:light[level=15]
setblock 356 146 231 minecraft:light[level=15]
setblock 356 146 239 minecraft:light[level=15]
setblock 356 146 247 minecraft:light[level=15]
setblock 356 146 255 minecraft:light[level=15]
setblock 356 146 263 minecraft:light[level=15]
fill 360 146 228 360 176 228 minecraft:stone_bricks
setblock 364 146 231 minecraft:light[level=15]
setblock 364 146 239 minecraft:light[level=15]
setblock 364 146 247 minecraft:light[level=15]
setblock 364 146 255 minecraft:light[level=15]
setblock 364 146 263 minecraft:light[level=15]
fill 371 146 241 371 280 241 minecraft:stone_bricks
fill 371 146 247 371 280 247 minecraft:stone_bricks
setblock 371 146 257 minecraft:cobblestone
fill 329 147 252 329 219 252 minecraft:stone_bricks
setblock 330 147 269 minecraft:lime_terracotta
fill 336 147 270 336 200 270 minecraft:stone_bricks
fill 371 147 257 371 278 257 minecraft:stone_bricks
fill 346 148 265 346 148 267 minecraft:light_gray_concrete
fill 347 148 265 348 148 265 minecraft:light_gray_concrete
fill 347 148 267 348 148 267 minecraft:light_gray_concrete
setblock 348 148 266 minecraft:light_gray_concrete
setblock 348 148 270 minecraft:mossy_cobblestone
setblock 351 148 269 minecraft:lime_terracotta
setblock 353 148 228 minecraft:cobblestone
fill 354 148 228 354 195 228 minecraft:stone_bricks
fill 363 148 241 365 149 241 minecraft:light_blue_stained_glass
fill 364 148 240 365 149 240 minecraft:light_blue_stained_glass
fill 365 148 263 365 148 265 minecraft:light_gray_concrete
fill 366 148 262 368 148 262 minecraft:light_gray_concrete
fill 366 148 266 368 148 266 minecraft:light_gray_concrete
fill 369 148 263 369 148 265 minecraft:light_gray_concrete
fill 347 149 267 347 150 269 minecraft:iron_block
fill 348 149 270 348 151 270 minecraft:stone_bricks
fill 353 149 228 353 280 228 minecraft:stone_bricks
setblock 370 149 241 minecraft:lime_terracotta
setblock 371 149 266 minecraft:mossy_cobblestone
setblock 329 150 230 minecraft:mossy_cobblestone
setblock 329 150 232 minecraft:mossy_stone_bricks
setblock 329 150 264 minecraft:mossy_cobblestone
setblock 341 150 228 minecraft:mossy_stone_bricks
setblock 344 150 228 minecraft:mossy_stone_bricks
setblock 347 150 265 minecraft:sea_lantern
fill 371 150 266 371 162 266 minecraft:stone_bricks
fill 329 151 230 329 180 230 minecraft:stone_bricks
fill 329 151 232 329 203 232 minecraft:stone_bricks
fill 329 151 264 329 166 264 minecraft:stone_bricks
setblock 332 151 231 minecraft:light[level=12]
setblock 332 151 238 minecraft:light[level=12]
setblock 332 151 245 minecraft:light[level=12]
setblock 332 151 252 minecraft:light[level=12]
setblock 332 151 259 minecraft:light[level=12]
setblock 332 151 266 minecraft:light[level=12]
setblock 339 151 231 minecraft:light[level=12]
setblock 339 151 238 minecraft:light[level=12]
setblock 339 151 245 minecraft:light[level=12]
setblock 339 151 252 minecraft:light[level=12]
setblock 339 151 259 minecraft:light[level=12]
setblock 339 151 266 minecraft:light[level=12]
fill 341 151 228 341 194 228 minecraft:stone_bricks
setblock 343 151 270 minecraft:cobblestone
fill 344 151 228 344 246 228 minecraft:stone_bricks
fill 344 151 270 345 280 270 minecraft:stone_bricks
setblock 346 151 231 minecraft:light[level=12]
setblock 346 151 238 minecraft:light[level=12]
setblock 346 151 245 minecraft:light[level=12]
setblock 346 151 252 minecraft:light[level=12]
setblock 346 151 259 minecraft:light[level=12]
setblock 346 151 266 minecraft:light[level=12]
setblock 353 151 231 minecraft:light[level=12]
setblock 353 151 238 minecraft:light[level=12]
setblock 353 151 245 minecraft:light[level=12]
setblock 353 151 252 minecraft:light[level=12]
setblock 353 151 259 minecraft:light[level=12]
setblock 353 151 266 minecraft:light[level=12]
setblock 360 151 231 minecraft:light[level=12]
setblock 360 151 238 minecraft:light[level=12]
setblock 360 151 245 minecraft:light[level=12]
setblock 360 151 252 minecraft:light[level=12]
setblock 360 151 259 minecraft:light[level=12]
setblock 360 151 266 minecraft:light[level=12]
fill 363 151 228 363 152 228 minecraft:mossy_stone_bricks
setblock 367 151 231 minecraft:light[level=12]
setblock 367 151 238 minecraft:light[level=12]
setblock 367 151 245 minecraft:light[level=12]
setblock 367 151 252 minecraft:light[level=12]
setblock 367 151 259 minecraft:light[level=12]
setblock 367 151 266 minecraft:light[level=12]
setblock 371 151 243 minecraft:mossy_stone_bricks
setblock 330 152 243 minecraft:green_concrete
setblock 337 152 228 minecraft:mossy_cobblestone
fill 343 152 270 343 159 270 minecraft:stone_bricks
setblock 346 152 270 minecraft:cobblestone
setblock 348 152 270 minecraft:mossy_stone_bricks
setblock 371 152 240 minecraft:cobblestone
fill 371 152 243 371 184 243 minecraft:stone_bricks
setblock 332 153 231 minecraft:light[level=15]
setblock 332 153 239 minecraft:light[level=15]
setblock 332 153 247 minecraft:light[level=15]
setblock 332 153 255 minecraft:light[level=15]
setblock 332 153 263 minecraft:light[level=15]
fill 337 153 228 337 195 228 minecraft:stone_bricks
fill 339 153 270 340 177 270 minecraft:stone_bricks
setblock 340 153 231 minecraft:light[level=15]
setblock 340 153 239 minecraft:light[level=15]
setblock 340 153 247 minecraft:light[level=15]
setblock 340 153 255 minecraft:light[level=15]
setblock 340 153 263 minecraft:light[level=15]
setblock 341 153 270 minecraft:mossy_stone_bricks
fill 346 153 270 346 224 270 minecraft:stone_bricks
setblock 348 153 231 minecraft:light[level=15]
setblock 348 153 239 minecraft:light[level=15]
setblock 348 153 247 minecraft:light[level=15]
setblock 348 153 255 minecraft:light[level=15]
setblock 348 153 263 minecraft:light[level=15]
fill 348 153 270 348 183 270 minecraft:stone_bricks
setblock 355 153 228 minecraft:mossy_cobblestone
setblock 356 153 231 minecraft:light[level=15]
setblock 356 153 239 minecraft:light[level=15]
setblock 356 153 247 minecraft:light[level=15]
setblock 356 153 255 minecraft:light[level=15]
setblock 356 153 263 minecraft:light[level=15]
setblock 357 153 229 minecraft:green_concrete
fill 363 153 228 363 171 228 minecraft:stone_bricks
setblock 364 153 231 minecraft:light[level=15]
setblock 364 153 239 minecraft:light[level=15]
setblock 364 153 247 minecraft:light[level=15]
setblock 364 153 255 minecraft:light[level=15]
setblock 364 153 263 minecraft:light[level=15]
fill 365 153 240 365 153 242 minecraft:light_gray_concrete
fill 365 153 263 365 153 265 minecraft:light_gray_concrete
fill 366 153 239 368 153 239 minecraft:light_gray_concrete
fill 366 153 243 368 153 243 minecraft:light_gray_concrete
fill 366 153 262 368 153 262 minecraft:light_gray_concrete
fill 366 153 266 368 153 266 minecraft:light_gray_concrete
fill 369 153 240 369 153 242 minecraft:light_gray_concrete
fill 369 153 263 369 153 265 minecraft:light_gray_concrete
fill 371 153 240 371 249 240 minecraft:stone_bricks
setblock 371 153 248 minecraft:mossy_cobblestone
setblock 371 153 263 minecraft:mossy_cobblestone
setblock 330 154 270 minecraft:mossy_stone_bricks
fill 341 154 270 341 241 270 minecraft:stone_bricks
fill 346 154 228 346 173 228 minecraft:stone_bricks
setblock 347 154 228 minecraft:mossy_cobblestone
fill 347 154 270 347 155 270 minecraft:mossy_stone_bricks
setblock 349 154 270 minecraft:cobblestone
setblock 352 154 228 minecraft:cobblestone
fill 355 154 228 355 226 228 minecraft:stone_bricks
fill 371 154 248 371 269 248 minecraft:stone_bricks
fill 371 154 263 371 168 263 minecraft:stone_bricks
setblock 329 155 257 minecraft:mossy_stone_bricks
fill 330 155 270 330 190 270 minecraft:stone_bricks
fill 346 155 265 346 155 267 minecraft:light_gray_concrete
fill 347 155 228 347 278 228 minecraft:stone_bricks
fill 347 155 265 348 155 265 minecraft:light_gray_concrete
fill 347 155 267 348 155 267 minecraft:light_gray_concrete
setblock 348 155 266 minecraft:light_gray_concrete
setblock 349 155 269 minecraft:green_concrete
fill 349 155 270 349 177 270 minecraft:stone_bricks
fill 352 155 228 352 187 228 minecraft:stone_bricks
setblock 357 155 228 minecraft:mossy_cobblestone
setblock 359 155 270 minecraft:mossy_cobblestone
setblock 361 155 228 minecraft:mossy_cobblestone
fill 329 156 257 329 197 257 minecraft:stone_bricks
setblock 334 156 270 minecraft:cobblestone
fill 347 156 270 347 164 270 minecraft:stone_bricks
fill 357 156 228 357 280 228 minecraft:stone_bricks
fill 359 156 270 359 280 270 minecraft:stone_bricks
fill 361 156 228 361 223 228 minecraft:stone_bricks
fill 371 156 234 371 171 234 minecraft:stone_bricks
setblock 371 156 235 minecraft:cobblestone
setblock 371 156 237 minecraft:mossy_cobblestone
fill 371 156 238 371 165 239 minecraft:stone_bricks
setblock 332 157 231 minecraft:light[level=12]
setblock 332 157 238 minecraft:light[level=12]
setblock 332 157 245 minecraft:light[level=12]
setblock 332 157 252 minecraft:light[level=12]
setblock 332 157 259 minecraft:light[level=12]
setblock 332 157 266 minecraft:light[level=12]
fill 334 157 270 334 186 270 minecraft:stone_bricks
setblock 339 157 231 minecraft:light[level=12]
setblock 339 157 238 minecraft:light[level=12]
setblock 339 157 245 minecraft:light[level=12]
setblock 339 157 252 minecraft:light[level=12]
setblock 339 157 259 minecraft:light[level=12]
setblock 339 157 266 minecraft:light[level=12]
setblock 346 157 231 minecraft:light[level=12]
setblock 346 157 238 minecraft:light[level=12]
setblock 346 157 245 minecraft:light[level=12]
setblock 346 157 252 minecraft:light[level=12]
setblock 346 157 259 minecraft:light[level=12]
setblock 346 157 266 minecraft:light[level=12]
setblock 348 157 228 minecraft:cobblestone
setblock 353 157 231 minecraft:light[level=12]
setblock 353 157 238 minecraft:light[level=12]
setblock 353 157 245 minecraft:light[level=12]
setblock 353 157 252 minecraft:light[level=12]
setblock 353 157 259 minecraft:light[level=12]
setblock 353 157 266 minecraft:light[level=12]
setblock 360 157 231 minecraft:light[level=12]
setblock 360 157 238 minecraft:light[level=12]
setblock 360 157 245 minecraft:light[level=12]
setblock 360 157 252 minecraft:light[level=12]
setblock 360 157 259 minecraft:light[level=12]
setblock 360 157 266 minecraft:light[level=12]
setblock 367 157 231 minecraft:light[level=12]
setblock 367 157 238 minecraft:light[level=12]
setblock 367 157 245 minecraft:light[level=12]
setblock 367 157 252 minecraft:light[level=12]
setblock 367 157 259 minecraft:light[level=12]
setblock 367 157 266 minecraft:light[level=12]
fill 371 157 235 371 202 235 minecraft:stone_bricks
fill 371 157 237 371 245 237 minecraft:stone_bricks
setblock 329 158 253 minecraft:mossy_stone_bricks
fill 348 158 228 348 184 228 minecraft:stone_bricks
fill 365 158 263 365 158 265 minecraft:light_gray_concrete
fill 366 158 262 368 158 262 minecraft:light_gray_concrete
fill 366 158 266 368 158 266 minecraft:light_gray_concrete
fill 369 158 263 369 158 265 minecraft:light_gray_concrete
setblock 371 158 245 minecraft:cobblestone
fill 371 158 246 371 280 246 minecraft:stone_bricks
fill 329 159 253 329 280 253 minecraft:stone_bricks
fill 366 159 232 368 164 233 minecraft:gray_concrete
fill 366 159 239 368 164 240 minecraft:gray_concrete
setblock 366 159 241 minecraft:iron_block
fill 366 159 246 368 164 247 minecraft:gray_concrete
fill 366 159 253 368 164 254 minecraft:gray_concrete
fill 366 159 260 368 164 261 minecraft:gray_concrete
fill 367 159 231 367 164 231 minecraft:gray_concrete
fill 367 159 234 367 164 234 minecraft:gray_concrete
fill 367 159 238 367 164 238 minecraft:gray_concrete
fill 367 159 241 367 164 241 minecraft:gray_concrete
setblock 367 159 242 minecraft:iron_block
fill 367 159 245 367 164 245 minecraft:gray_concrete
fill 367 159 248 367 164 248 minecraft:gray_concrete
fill 367 159 252 367 164 252 minecraft:gray_concrete
fill 367 159 255 367 164 255 minecraft:gray_concrete
fill 367 159 259 367 164 259 minecraft:gray_concrete
fill 367 159 262 367 164 262 minecraft:gray_concrete
setblock 370 159 250 minecraft:lime_concrete
fill 371 159 245 371 189 245 minecraft:stone_bricks
setblock 332 160 231 minecraft:light[level=15]
setblock 332 160 239 minecraft:light[level=15]
setblock 332 160 247 minecraft:light[level=15]
setblock 332 160 255 minecraft:light[level=15]
setblock 332 160 263 minecraft:light[level=15]
setblock 340 160 231 minecraft:light[level=15]
setblock 340 160 239 minecraft:light[level=15]
setblock 340 160 247 minecraft:light[level=15]
setblock 340 160 255 minecraft:light[level=15]
setblock 340 160 263 minecraft:light[level=15]
setblock 343 160 270 minecraft:mossy_stone_bricks
setblock 348 160 231 minecraft:light[level=15]
setblock 348 160 239 minecraft:light[level=15]
setblock 348 160 247 minecraft:light[level=15]
setblock 348 160 255 minecraft:light[level=15]
setblock 348 160 263 minecraft:light[level=15]
setblock 356 160 231 minecraft:light[level=15]
setblock 356 160 239 minecraft:light[level=15]
setblock 356 160 247 minecraft:light[level=15]
setblock 356 160 255 minecraft:light[level=15]
setblock 356 160 263 minecraft:light[level=15]
setblock 364 160 231 minecraft:light[level=15]
setblock 364 160 239 minecraft:light[level=15]
setblock 364 160 247 minecraft:light[level=15]
setblock 364 160 255 minecraft:light[level=15]
setblock 364 160 263 minecraft:light[level=15]
fill 365 160 231 365 163 234 minecraft:gray_concrete
fill 365 160 238 365 163 241 minecraft:gray_concrete
fill 365 160 245 365 163 248 minecraft:gray_concrete
fill 365 160 252 365 163 255 minecraft:gray_concrete
fill 365 160 259 365 163 262 minecraft:gray_concrete
fill 366 160 228 368 163 229 minecraft:iron_block
fill 366 160 230 366 163 231 minecraft:gray_concrete
fill 366 160 234 366 163 235 minecraft:gray_concrete
fill 366 160 236 368 163 236 minecraft:iron_block
fill 366 160 237 366 163 238 minecraft:gray_concrete
fill 366 160 241 366 163 242 minecraft:gray_concrete
fill 366 160 243 368 163 243 minecraft:iron_block
fill 366 160 244 366 163 245 minecraft:gray_concrete
fill 366 160 248 366 163 249 minecraft:gray_concrete
fill 366 160 250 368 163 250 minecraft:iron_block
fill 366 160 251 366 163 252 minecraft:gray_concrete
fill 366 160 255 366 163 256 minecraft:gray_concrete
fill 366 160 257 368 163 257 minecraft:iron_block
fill 366 160 258 366 163 259 minecraft:gray_concrete
fill 366 160 262 366 163 263 minecraft:gray_concrete
fill 366 160 264 368 163 269 minecraft:iron_block
fill 367 160 230 368 163 230 minecraft:gray_concrete
fill 367 160 235 368 163 235 minecraft:gray_concrete
fill 367 160 237 368 163 237 minecraft:gray_concrete
fill 367 160 242 368 163 242 minecraft:gray_concrete
fill 367 160 244 368 163 244 minecraft:gray_concrete
fill 367 160 249 368 163 249 minecraft:gray_concrete
fill 367 160 251 368 163 251 minecraft:gray_concrete
fill 367 160 256 368 163 256 minecraft:gray_concrete
fill 367 160 258 368 163 258 minecraft:gray_concrete
fill 367 160 263 368 163 263 minecraft:gray_concrete
fill 367 160 270 367 163 270 minecraft:iron_block
fill 368 160 231 369 163 231 minecraft:gray_concrete
fill 368 160 234 369 163 234 minecraft:gray_concrete
fill 368 160 238 369 163 238 minecraft:gray_concrete
fill 368 160 241 369 163 241 minecraft:gray_concrete
fill 368 160 245 369 163 245 minecraft:gray_concrete
fill 368 160 248 369 163 248 minecraft:gray_concrete
fill 368 160 252 369 163 252 minecraft:gray_concrete
fill 368 160 255 369 163 255 minecraft:gray_concrete
fill 368 160 259 369 163 259 minecraft:gray_concrete
fill 368 160 262 369 163 262 minecraft:gray_concrete
fill 369 160 232 369 163 233 minecraft:gray_concrete
fill 369 160 239 369 163 240 minecraft:gray_concrete
fill 369 160 246 369 163 247 minecraft:gray_concrete
fill 369 160 253 369 163 254 minecraft:gray_concrete
fill 369 160 260 369 163 261 minecraft:gray_concrete
fill 369 160 263 370 161 265 minecraft:iron_block
setblock 329 161 262 minecraft:cobblestone
fill 343 161 270 343 276 270 minecraft:stone_bricks
fill 365 161 228 365 162 230 minecraft:iron_block
fill 365 161 235 365 162 237 minecraft:iron_block
fill 365 161 242 365 162 244 minecraft:iron_block
fill 365 161 249 365 162 251 minecraft:iron_block
fill 365 161 256 365 162 258 minecraft:iron_block
fill 365 161 263 365 162 269 minecraft:iron_block
fill 366 161 270 366 162 270 minecraft:iron_block
fill 368 161 270 368 162 270 minecraft:iron_block
fill 369 161 228 369 162 228 minecraft:iron_block
setblock 369 161 229 minecraft:lime_concrete
fill 369 161 230 369 162 230 minecraft:iron_block
fill 369 161 235 369 162 237 minecraft:iron_block
fill 369 161 242 369 162 244 minecraft:iron_block
fill 369 161 249 369 162 251 minecraft:iron_block
fill 369 161 256 369 162 258 minecraft:iron_block
fill 369 161 266 369 162 269 minecraft:iron_block
setblock 329 162 241 minecraft:mossy_stone_bricks
fill 329 162 262 329 167 262 minecraft:stone_bricks
fill 346 162 265 346 162 267 minecraft:light_gray_concrete
fill 347 162 265 348 162 265 minecraft:light_gray_concrete
fill 347 162 267 348 162 267 minecraft:light_gray_concrete
setblock 348 162 266 minecraft:light_gray_concrete
setblock 369 162 229 minecraft:iron_block
fill 369 162 263 369 162 265 minecraft:iron_block
fill 329 163 241 329 280 241 minecraft:stone_bricks
setblock 332 163 231 minecraft:light[level=12]
setblock 332 163 238 minecraft:light[level=12]
setblock 332 163 245 minecraft:light[level=12]
setblock 332 163 252 minecraft:light[level=12]
setblock 332 163 259 minecraft:light[level=12]
setblock 332 163 266 minecraft:light[level=12]
setblock 338 163 270 minecraft:cobblestone
setblock 339 163 231 minecraft:light[level=12]
setblock 339 163 238 minecraft:light[level=12]
setblock 339 163 245 minecraft:light[level=12]
setblock 339 163 252 minecraft:light[level=12]
setblock 339 163 259 minecraft:light[level=12]
setblock 339 163 266 minecraft:light[level=12]
setblock 340 163 228 minecraft:mossy_cobblestone
setblock 346 163 231 minecraft:light[level=12]
setblock 346 163 238 minecraft:light[level=12]
setblock 346 163 245 minecraft:light[level=12]
setblock 346 163 252 minecraft:light[level=12]
setblock 346 163 259 minecraft:light[level=12]
setblock 346 163 266 minecraft:light[level=12]
setblock 353 163 231 minecraft:light[level=12]
setblock 353 163 238 minecraft:light[level=12]
setblock 353 163 245 minecraft:light[level=12]
setblock 353 163 252 minecraft:light[level=12]
setblock 353 163 259 minecraft:light[level=12]
setblock 353 163 266 minecraft:light[level=12]
setblock 360 163 231 minecraft:light[level=12]
setblock 360 163 238 minecraft:light[level=12]
setblock 360 163 245 minecraft:light[level=12]
setblock 360 163 252 minecraft:light[level=12]
setblock 360 163 259 minecraft:light[level=12]
setblock 360 163 266 minecraft:light[level=12]
fill 365 163 228 365 280 228 minecraft:stone_bricks
fill 365 163 263 365 163 265 minecraft:light_gray_concrete
fill 366 163 270 366 206 270 minecraft:stone_bricks
fill 368 163 270 368 187 270 minecraft:stone_bricks
fill 369 163 228 369 187 228 minecraft:stone_bricks
fill 369 163 263 369 163 265 minecraft:light_gray_concrete
setblock 371 163 266 minecraft:mossy_cobblestone
fill 338 164 270 338 280 270 minecraft:stone_bricks
fill 340 164 228 340 280 228 minecraft:stone_bricks
setblock 357 164 270 minecraft:cobblestone
fill 366 164 228 368 177 228 minecraft:stone_bricks
fill 366 164 241 366 187 242 minecraft:iron_block
fill 366 164 263 368 167 265 minecraft:iron_block
fill 367 164 242 368 187 242 minecraft:iron_block
fill 367 164 270 367 280 270 minecraft:stone_bricks
fill 368 164 241 368 186 241 minecraft:iron_block
setblock 370 164 229 minecraft:lime_concrete
setblock 370 164 249 minecraft:green_concrete
fill 371 164 266 371 176 266 minecraft:stone_bricks
setblock 347 165 270 minecraft:cobblestone
fill 357 165 270 357 185 270 minecraft:stone_bricks
fill 366 165 240 368 186 240 minecraft:iron_block
fill 367 165 241 367 186 241 minecraft:iron_block
fill 347 166 270 347 217 270 minecraft:stone_bricks
setblock 371 166 238 minecraft:mossy_stone_bricks
fill 371 166 239 371 280 239 minecraft:stone_bricks
setblock 329 167 264 minecraft:mossy_cobblestone
setblock 332 167 231 minecraft:light[level=15]
setblock 332 167 239 minecraft:light[level=15]
setblock 332 167 247 minecraft:light[level=15]
setblock 332 167 255 minecraft:light[level=15]
fill 332 167 263 335 172 263 minecraft:gray_concrete
fill 333 167 262 334 172 262 minecraft:gray_concrete
fill 333 167 264 334 172 264 minecraft:gray_concrete
setblock 337 167 270 minecraft:mossy_stone_bricks
fill 339 167 263 342 172 263 minecraft:gray_concrete
setblock 340 167 231 minecraft:light[level=15]
setblock 340 167 239 minecraft:light[level=15]
setblock 340 167 247 minecraft:light[level=15]
setblock 340 167 255 minecraft:light[level=15]
fill 340 167 262 341 172 262 minecraft:gray_concrete
fill 340 167 264 341 172 264 minecraft:gray_concrete
fill 346 167 263 349 172 263 minecraft:gray_concrete
fill 347 167 262 348 172 262 minecraft:gray_concrete
fill 347 167 264 348 172 264 minecraft:gray_concrete
setblock 348 167 231 minecraft:light[level=15]
setblock 348 167 239 minecraft:light[level=15]
setblock 348 167 247 minecraft:light[level=15]
setblock 348 167 255 minecraft:light[level=15]
fill 353 167 263 356 172 263 minecraft:gray_concrete
fill 354 167 262 355 172 262 minecraft:gray_concrete
fill 354 167 264 355 172 264 minecraft:gray_concrete
setblock 356 167 231 minecraft:light[level=15]
setblock 356 167 239 minecraft:light[level=15]
setblock 356 167 247 minecraft:light[level=15]
setblock 356 167 255 minecraft:light[level=15]
fill 360 167 263 363 172 263 minecraft:gray_concrete
fill 361 167 262 362 172 262 minecraft:gray_concrete
fill 361 167 264 362 172 264 minecraft:gray_concrete
setblock 364 167 231 minecraft:light[level=15]
setblock 364 167 239 minecraft:light[level=15]
setblock 364 167 247 minecraft:light[level=15]
setblock 364 167 255 minecraft:light[level=15]
setblock 364 167 263 minecraft:light[level=15]
fill 371 167 238 371 280 238 minecraft:stone_bricks
fill 329 168 262 330 171 264 minecraft:waxed_oxidized_copper
setblock 330 168 244 minecraft:lime_concrete
fill 331 168 262 331 171 264 minecraft:gray_concrete
fill 332 168 261 332 171 262 minecraft:gray_concrete
fill 332 168 264 332 171 265 minecraft:gray_concrete
fill 333 168 261 335 171 261 minecraft:gray_concrete
fill 333 168 265 335 171 265 minecraft:gray_concrete
fill 335 168 262 336 171 262 minecraft:gray_concrete
fill 335 168 264 336 171 264 minecraft:gray_concrete
fill 336 168 263 336 171 263 minecraft:gray_concrete
fill 337 168 262 337 171 264 minecraft:waxed_oxidized_copper
fill 337 168 270 337 280 270 minecraft:stone_bricks
fill 338 168 262 338 171 264 minecraft:gray_concrete
fill 339 168 261 339 171 262 minecraft:gray_concrete
fill 339 168 264 339 171 265 minecraft:gray_concrete
fill 340 168 261 342 171 261 minecraft:gray_concrete
fill 340 168 265 342 171 265 minecraft:gray_concrete
fill 342 168 262 343 171 262 minecraft:gray_concrete
fill 342 168 264 343 171 264 minecraft:gray_concrete
fill 343 168 263 343 171 263 minecraft:gray_concrete
fill 344 168 262 344 171 264 minecraft:waxed_oxidized_copper
fill 345 168 262 345 171 264 minecraft:gray_concrete
fill 346 168 261 346 171 262 minecraft:gray_concrete
fill 346 168 264 346 171 265 minecraft:gray_concrete
fill 347 168 261 349 171 261 minecraft:gray_concrete
fill 347 168 265 349 171 265 minecraft:gray_concrete
fill 349 168 262 350 171 262 minecraft:gray_concrete
fill 349 168 264 350 171 264 minecraft:gray_concrete
fill 350 168 263 350 171 263 minecraft:gray_concrete
fill 351 168 262 351 171 264 minecraft:waxed_oxidized_copper
fill 352 168 262 352 171 264 minecraft:gray_concrete
fill 353 168 261 353 171 262 minecraft:gray_concrete
fill 353 168 264 353 171 265 minecraft:gray_concrete
fill 354 168 261 356 171 261 minecraft:gray_concrete
fill 354 168 265 356 171 265 minecraft:gray_concrete
fill 356 168 262 357 171 262 minecraft:gray_concrete
fill 356 168 264 357 171 264 minecraft:gray_concrete
fill 357 168 263 357 171 263 minecraft:gray_concrete
fill 358 168 262 358 171 264 minecraft:waxed_oxidized_copper
fill 359 168 262 359 171 264 minecraft:gray_concrete
fill 360 168 261 360 171 262 minecraft:gray_concrete
fill 360 168 264 360 171 265 minecraft:gray_concrete
fill 361 168 261 363 171 261 minecraft:gray_concrete
fill 361 168 265 363 171 265 minecraft:gray_concrete
fill 363 168 262 364 171 262 minecraft:gray_concrete
fill 363 168 264 364 171 264 minecraft:gray_concrete
fill 364 168 263 364 171 263 minecraft:gray_concrete
fill 365 168 262 370 171 264 minecraft:waxed_oxidized_copper
setblock 365 168 265 minecraft:light_gray_concrete
fill 366 168 265 368 168 265 minecraft:iron_block
fill 366 168 266 368 168 266 minecraft:light_gray_concrete
setblock 369 168 265 minecraft:light_gray_concrete
setblock 329 169 229 minecraft:cobblestone
fill 330 169 261 331 170 261 minecraft:waxed_oxidized_copper
fill 330 169 265 331 170 265 minecraft:waxed_oxidized_copper
setblock 332 169 231 minecraft:light[level=12]
setblock 332 169 238 minecraft:light[level=12]
setblock 332 169 245 minecraft:light[level=12]
setblock 332 169 252 minecraft:light[level=12]
setblock 332 169 259 minecraft:light[level=12]
setblock 332 169 266 minecraft:light[level=12]
fill 336 169 261 338 170 261 minecraft:waxed_oxidized_copper
fill 336 169 265 338 170 265 minecraft:waxed_oxidized_copper
setblock 339 169 231 minecraft:light[level=12]
setblock 339 169 238 minecraft:light[level=12]
setblock 339 169 245 minecraft:light[level=12]
setblock 339 169 252 minecraft:light[level=12]
setblock 339 169 259 minecraft:light[level=12]
setblock 339 169 266 minecraft:light[level=12]
fill 343 169 261 345 170 261 minecraft:waxed_oxidized_copper
fill 343 169 265 345 170 265 minecraft:waxed_oxidized_copper
setblock 346 169 231 minecraft:light[level=12]
setblock 346 169 238 minecraft:light[level=12]
setblock 346 169 245 minecraft:light[level=12]
setblock 346 169 252 minecraft:light[level=12]
setblock 346 169 259 minecraft:light[level=12]
fill 346 169 266 346 169 267 minecraft:light_gray_concrete
fill 347 169 267 348 169 267 minecraft:light_gray_concrete
setblock 348 169 266 minecraft:light_gray_concrete
fill 350 169 261 352 170 261 minecraft:waxed_oxidized_copper
fill 350 169 265 352 170 265 minecraft:waxed_oxidized_copper
setblock 353 169 231 minecraft:light[level=12]
setblock 353 169 238 minecraft:light[level=12]
setblock 353 169 245 minecraft:light[level=12]
setblock 353 169 252 minecraft:light[level=12]
setblock 353 169 259 minecraft:light[level=12]
setblock 353 169 266 minecraft:light[level=12]
fill 357 169 261 359 170 261 minecraft:waxed_oxidized_copper
fill 357 169 265 359 170 265 minecraft:waxed_oxidized_copper
setblock 360 169 231 minecraft:light[level=12]
schedule function dropper:buildpart/55_2 1t
