setblock 335 103 457 minecraft:red_concrete
setblock 341 103 417 minecraft:red_concrete
setblock 342 103 457 minecraft:red_concrete
setblock 348 103 417 minecraft:red_concrete
setblock 349 103 457 minecraft:red_concrete
setblock 355 103 417 minecraft:red_concrete
setblock 356 103 457 minecraft:red_concrete
setblock 362 103 417 minecraft:red_concrete
setblock 363 103 457 minecraft:red_concrete
setblock 369 103 417 minecraft:red_concrete
setblock 370 103 423 minecraft:red_concrete
setblock 370 103 430 minecraft:red_concrete
setblock 370 103 437 minecraft:red_concrete
setblock 370 103 444 minecraft:red_concrete
setblock 370 103 451 minecraft:red_concrete
setblock 370 103 457 minecraft:red_concrete
setblock 330 104 421 minecraft:red_concrete
setblock 330 104 428 minecraft:red_concrete
setblock 330 104 435 minecraft:red_concrete
setblock 330 104 442 minecraft:red_concrete
setblock 330 104 449 minecraft:red_concrete
setblock 330 104 456 minecraft:red_concrete
setblock 332 104 419 minecraft:light[level=12]
setblock 332 104 427 minecraft:light[level=12]
setblock 332 104 435 minecraft:light[level=12]
setblock 332 104 443 minecraft:light[level=12]
setblock 332 104 451 minecraft:light[level=12]
setblock 333 104 417 minecraft:red_concrete
setblock 336 104 457 minecraft:red_concrete
setblock 340 104 417 minecraft:red_concrete
setblock 340 104 419 minecraft:light[level=12]
setblock 340 104 427 minecraft:light[level=12]
setblock 340 104 435 minecraft:light[level=12]
setblock 340 104 443 minecraft:light[level=12]
setblock 340 104 451 minecraft:light[level=12]
setblock 343 104 457 minecraft:red_concrete
setblock 347 104 417 minecraft:red_concrete
setblock 348 104 419 minecraft:light[level=12]
setblock 348 104 427 minecraft:light[level=12]
setblock 348 104 435 minecraft:light[level=12]
setblock 348 104 443 minecraft:light[level=12]
setblock 348 104 451 minecraft:light[level=12]
setblock 350 104 457 minecraft:red_concrete
setblock 354 104 417 minecraft:red_concrete
setblock 356 104 419 minecraft:light[level=12]
setblock 356 104 427 minecraft:light[level=12]
setblock 356 104 435 minecraft:light[level=12]
setblock 356 104 443 minecraft:light[level=12]
setblock 356 104 451 minecraft:light[level=12]
setblock 357 104 457 minecraft:red_concrete
setblock 361 104 417 minecraft:red_concrete
setblock 364 104 419 minecraft:light[level=12]
setblock 364 104 427 minecraft:light[level=12]
setblock 364 104 435 minecraft:light[level=12]
setblock 364 104 443 minecraft:light[level=12]
setblock 364 104 451 minecraft:light[level=12]
setblock 364 104 457 minecraft:red_concrete
setblock 368 104 417 minecraft:red_concrete
setblock 370 104 422 minecraft:red_concrete
setblock 370 104 429 minecraft:red_concrete
setblock 370 104 436 minecraft:red_concrete
setblock 370 104 443 minecraft:red_concrete
setblock 370 104 450 minecraft:red_concrete
fill 335 105 418 341 106 418 minecraft:gray_concrete
fill 368 105 422 368 113 422 minecraft:red_wool
setblock 330 106 423 minecraft:red_concrete
setblock 330 106 430 minecraft:red_concrete
setblock 330 106 437 minecraft:red_concrete
setblock 330 106 444 minecraft:red_concrete
setblock 330 106 451 minecraft:red_concrete
setblock 331 106 417 minecraft:red_concrete
setblock 331 106 457 minecraft:red_concrete
setblock 338 106 417 minecraft:red_concrete
setblock 338 106 457 minecraft:red_concrete
setblock 345 106 417 minecraft:red_concrete
setblock 345 106 457 minecraft:red_concrete
setblock 352 106 417 minecraft:red_concrete
setblock 352 106 457 minecraft:red_concrete
setblock 359 106 417 minecraft:red_concrete
setblock 359 106 457 minecraft:red_concrete
setblock 366 106 417 minecraft:red_concrete
setblock 366 106 457 minecraft:red_concrete
fill 368 106 420 368 113 421 minecraft:red_wool
fill 368 106 423 368 113 424 minecraft:red_wool
setblock 370 106 420 minecraft:red_concrete
setblock 370 106 427 minecraft:red_concrete
setblock 370 106 434 minecraft:red_concrete
setblock 370 106 441 minecraft:red_concrete
setblock 370 106 448 minecraft:red_concrete
setblock 370 106 455 minecraft:red_concrete
setblock 330 107 417 minecraft:red_concrete
setblock 330 107 424 minecraft:red_concrete
setblock 330 107 431 minecraft:red_concrete
setblock 330 107 438 minecraft:red_concrete
setblock 330 107 445 minecraft:red_concrete
setblock 330 107 452 minecraft:red_concrete
setblock 332 107 457 minecraft:red_concrete
setblock 337 107 417 minecraft:red_concrete
setblock 339 107 457 minecraft:red_concrete
setblock 344 107 417 minecraft:red_concrete
setblock 346 107 457 minecraft:red_concrete
setblock 351 107 417 minecraft:red_concrete
setblock 353 107 457 minecraft:red_concrete
setblock 358 107 417 minecraft:red_concrete
setblock 360 107 457 minecraft:red_concrete
setblock 365 107 417 minecraft:red_concrete
setblock 367 107 457 minecraft:red_concrete
setblock 370 107 419 minecraft:red_concrete
setblock 370 107 426 minecraft:red_concrete
setblock 370 107 433 minecraft:red_concrete
setblock 370 107 440 minecraft:red_concrete
setblock 370 107 447 minecraft:red_concrete
setblock 370 107 454 minecraft:red_concrete
setblock 330 108 418 minecraft:red_concrete
setblock 330 108 425 minecraft:red_concrete
setblock 330 108 432 minecraft:red_concrete
setblock 330 108 439 minecraft:red_concrete
setblock 330 108 446 minecraft:red_concrete
setblock 330 108 453 minecraft:red_concrete
setblock 333 108 457 minecraft:red_concrete
setblock 336 108 417 minecraft:red_concrete
setblock 340 108 457 minecraft:red_concrete
setblock 343 108 417 minecraft:red_concrete
setblock 347 108 457 minecraft:red_concrete
setblock 350 108 417 minecraft:red_concrete
setblock 354 108 457 minecraft:red_concrete
setblock 357 108 417 minecraft:red_concrete
setblock 361 108 457 minecraft:red_concrete
fill 362 108 442 366 127 444 minecraft:red_concrete
fill 363 108 441 365 127 441 minecraft:red_concrete
fill 363 108 445 365 127 445 minecraft:red_concrete
setblock 364 108 417 minecraft:red_concrete
setblock 368 108 457 minecraft:red_concrete
setblock 370 108 418 minecraft:red_concrete
setblock 370 108 425 minecraft:red_concrete
setblock 370 108 432 minecraft:red_concrete
setblock 370 108 439 minecraft:red_concrete
setblock 370 108 446 minecraft:red_concrete
setblock 370 108 453 minecraft:red_concrete
fill 330 109 419 330 110 419 minecraft:red_concrete
fill 330 109 426 330 110 426 minecraft:red_concrete
fill 330 109 433 330 110 433 minecraft:red_concrete
fill 330 109 440 330 110 440 minecraft:red_concrete
fill 330 109 447 330 110 447 minecraft:red_concrete
fill 330 109 454 330 110 454 minecraft:red_concrete
fill 331 109 432 331 110 438 minecraft:gray_concrete
fill 334 109 457 334 110 457 minecraft:red_concrete
fill 335 109 417 335 110 417 minecraft:red_concrete
fill 341 109 457 341 110 457 minecraft:red_concrete
fill 342 109 417 342 110 417 minecraft:red_concrete
fill 348 109 457 348 110 457 minecraft:red_concrete
fill 349 109 417 349 110 417 minecraft:red_concrete
fill 355 109 457 355 110 457 minecraft:red_concrete
fill 356 109 417 356 110 417 minecraft:red_concrete
fill 360 109 441 361 126 445 minecraft:red_concrete
fill 361 109 440 367 126 440 minecraft:red_concrete
fill 361 109 446 367 126 446 minecraft:red_concrete
fill 362 109 439 366 126 439 minecraft:red_concrete
fill 362 109 441 362 126 441 minecraft:red_concrete
fill 362 109 445 362 126 445 minecraft:red_concrete
fill 362 109 447 366 126 447 minecraft:red_concrete
fill 362 109 457 362 110 457 minecraft:red_concrete
fill 363 109 417 363 110 417 minecraft:red_concrete
fill 366 109 441 368 126 441 minecraft:red_concrete
fill 366 109 445 368 126 445 minecraft:red_concrete
fill 367 109 442 368 126 444 minecraft:red_concrete
fill 369 109 457 369 110 457 minecraft:red_concrete
fill 370 109 417 370 110 417 minecraft:red_concrete
fill 370 109 424 370 110 424 minecraft:red_concrete
fill 370 109 431 370 110 431 minecraft:red_concrete
fill 370 109 438 370 110 438 minecraft:red_concrete
fill 370 109 445 370 124 445 minecraft:red_concrete
fill 370 109 452 370 110 452 minecraft:red_concrete
fill 330 110 417 330 110 418 minecraft:red_concrete
fill 330 110 420 330 110 421 minecraft:red_concrete
fill 330 110 423 330 110 425 minecraft:red_concrete
fill 330 110 427 330 110 428 minecraft:red_concrete
fill 330 110 430 330 110 432 minecraft:red_concrete
fill 330 110 434 330 110 435 minecraft:red_concrete
fill 330 110 437 330 110 439 minecraft:red_concrete
fill 330 110 441 330 110 442 minecraft:red_concrete
fill 330 110 444 330 110 446 minecraft:red_concrete
fill 330 110 448 330 110 449 minecraft:red_concrete
fill 330 110 451 330 110 453 minecraft:red_concrete
fill 330 110 455 330 110 456 minecraft:red_concrete
setblock 331 110 417 minecraft:red_concrete
fill 331 110 457 333 110 457 minecraft:red_concrete
fill 333 110 417 334 110 417 minecraft:red_concrete
fill 335 110 457 336 110 457 minecraft:red_concrete
fill 336 110 417 338 110 417 minecraft:red_concrete
fill 338 110 457 340 110 457 minecraft:red_concrete
fill 340 110 417 341 110 417 minecraft:red_concrete
fill 342 110 457 343 110 457 minecraft:red_concrete
fill 343 110 417 345 110 417 minecraft:red_concrete
fill 345 110 457 347 110 457 minecraft:red_concrete
fill 347 110 417 348 110 417 minecraft:red_concrete
fill 349 110 457 350 110 457 minecraft:red_concrete
fill 350 110 417 352 110 417 minecraft:red_concrete
fill 352 110 457 354 110 457 minecraft:red_concrete
fill 354 110 417 355 110 417 minecraft:red_concrete
fill 356 110 457 357 110 457 minecraft:red_concrete
fill 357 110 417 359 110 417 minecraft:red_concrete
fill 359 110 440 359 125 446 minecraft:red_concrete
fill 359 110 457 361 110 457 minecraft:red_concrete
fill 360 110 439 360 125 440 minecraft:red_concrete
fill 360 110 446 360 125 447 minecraft:red_concrete
fill 361 110 417 362 110 417 minecraft:red_concrete
fill 361 110 438 361 125 439 minecraft:red_concrete
fill 361 110 447 361 125 448 minecraft:red_concrete
fill 362 110 438 367 125 438 minecraft:red_concrete
fill 362 110 448 367 125 448 minecraft:red_concrete
fill 363 110 457 364 110 457 minecraft:red_concrete
fill 364 110 417 366 110 417 minecraft:red_concrete
fill 366 110 457 368 110 457 minecraft:red_concrete
fill 367 110 439 368 125 439 minecraft:red_concrete
fill 367 110 447 368 125 447 minecraft:red_concrete
fill 368 110 417 369 110 417 minecraft:red_concrete
fill 368 110 440 370 124 440 minecraft:red_concrete
fill 368 110 446 370 124 446 minecraft:red_concrete
fill 369 110 441 369 125 445 minecraft:red_concrete
fill 370 110 418 370 110 420 minecraft:red_concrete
fill 370 110 422 370 110 423 minecraft:red_concrete
fill 370 110 425 370 110 427 minecraft:red_concrete
fill 370 110 429 370 110 430 minecraft:red_concrete
fill 370 110 432 370 110 434 minecraft:red_concrete
fill 370 110 436 370 110 437 minecraft:red_concrete
setblock 370 110 439 minecraft:red_concrete
fill 370 110 441 370 124 441 minecraft:red_concrete
fill 370 110 443 370 124 444 minecraft:red_concrete
fill 370 110 447 370 110 448 minecraft:red_concrete
fill 370 110 450 370 110 451 minecraft:red_concrete
fill 370 110 453 370 110 455 minecraft:red_concrete
setblock 370 110 457 minecraft:red_concrete
setblock 330 111 421 minecraft:red_concrete
setblock 330 111 428 minecraft:red_concrete
setblock 330 111 435 minecraft:red_concrete
setblock 330 111 442 minecraft:red_concrete
setblock 330 111 449 minecraft:red_concrete
setblock 330 111 456 minecraft:red_concrete
setblock 333 111 417 minecraft:red_concrete
setblock 336 111 457 minecraft:red_concrete
setblock 340 111 417 minecraft:red_concrete
setblock 343 111 457 minecraft:red_concrete
setblock 347 111 417 minecraft:red_concrete
setblock 350 111 457 minecraft:red_concrete
setblock 354 111 417 minecraft:red_concrete
setblock 357 111 457 minecraft:red_concrete
fill 358 111 440 358 124 446 minecraft:red_concrete
fill 359 111 439 359 124 439 minecraft:red_concrete
fill 359 111 447 359 124 447 minecraft:red_concrete
fill 360 111 438 360 124 438 minecraft:red_concrete
fill 360 111 448 360 124 448 minecraft:red_concrete
setblock 361 111 417 minecraft:red_concrete
fill 361 111 437 367 124 437 minecraft:red_concrete
fill 361 111 449 367 124 449 minecraft:red_concrete
setblock 364 111 457 minecraft:red_concrete
setblock 368 111 417 minecraft:red_concrete
fill 368 111 438 368 124 438 minecraft:red_concrete
fill 368 111 448 368 124 448 minecraft:red_concrete
fill 369 111 439 369 124 439 minecraft:red_concrete
fill 369 111 447 369 124 447 minecraft:red_concrete
setblock 370 111 422 minecraft:red_concrete
setblock 370 111 429 minecraft:red_concrete
setblock 370 111 436 minecraft:red_concrete
setblock 370 111 450 minecraft:red_concrete
setblock 332 112 419 minecraft:light[level=12]
setblock 332 112 427 minecraft:light[level=12]
setblock 332 112 435 minecraft:light[level=12]
setblock 332 112 443 minecraft:light[level=12]
setblock 332 112 451 minecraft:light[level=12]
setblock 340 112 419 minecraft:light[level=12]
setblock 340 112 427 minecraft:light[level=12]
setblock 340 112 435 minecraft:light[level=12]
setblock 340 112 443 minecraft:light[level=12]
setblock 340 112 451 minecraft:light[level=12]
setblock 348 112 419 minecraft:light[level=12]
setblock 348 112 427 minecraft:light[level=12]
setblock 348 112 435 minecraft:light[level=12]
setblock 348 112 443 minecraft:light[level=12]
setblock 348 112 451 minecraft:light[level=12]
setblock 356 112 419 minecraft:light[level=12]
setblock 356 112 427 minecraft:light[level=12]
setblock 356 112 435 minecraft:light[level=12]
setblock 356 112 443 minecraft:light[level=12]
setblock 356 112 451 minecraft:light[level=12]
fill 357 112 441 357 123 445 minecraft:red_concrete
fill 358 112 439 358 123 439 minecraft:red_concrete
fill 358 112 447 358 123 447 minecraft:red_concrete
fill 359 112 438 359 123 438 minecraft:red_concrete
fill 359 112 448 359 123 448 minecraft:red_concrete
fill 360 112 437 360 123 437 minecraft:red_concrete
fill 360 112 449 360 123 449 minecraft:red_concrete
fill 362 112 436 366 123 436 minecraft:red_concrete
fill 362 112 450 366 123 450 minecraft:red_concrete
setblock 364 112 419 minecraft:light[level=12]
setblock 364 112 427 minecraft:light[level=12]
setblock 364 112 435 minecraft:light[level=12]
setblock 364 112 451 minecraft:light[level=12]
fill 368 112 437 368 123 437 minecraft:red_concrete
fill 368 112 449 368 123 449 minecraft:red_concrete
fill 369 112 438 369 123 438 minecraft:red_concrete
fill 369 112 448 369 123 448 minecraft:red_concrete
fill 370 112 439 370 123 439 minecraft:red_concrete
fill 370 112 447 370 123 447 minecraft:red_concrete
setblock 330 113 423 minecraft:red_concrete
setblock 330 113 430 minecraft:red_concrete
setblock 330 113 437 minecraft:red_concrete
setblock 330 113 444 minecraft:red_concrete
setblock 330 113 451 minecraft:red_concrete
setblock 331 113 417 minecraft:red_concrete
setblock 331 113 457 minecraft:red_concrete
setblock 338 113 417 minecraft:red_concrete
setblock 338 113 457 minecraft:red_concrete
setblock 345 113 417 minecraft:red_concrete
setblock 345 113 457 minecraft:red_concrete
setblock 352 113 417 minecraft:red_concrete
setblock 352 113 457 minecraft:red_concrete
fill 356 113 440 356 113 442 minecraft:black_concrete
fill 356 113 443 356 122 443 minecraft:red_concrete
fill 356 113 444 356 113 446 minecraft:black_concrete
fill 357 113 440 357 122 440 minecraft:red_concrete
fill 357 113 446 357 122 446 minecraft:red_concrete
fill 358 113 438 358 122 438 minecraft:red_concrete
fill 358 113 448 358 122 448 minecraft:red_concrete
setblock 359 113 417 minecraft:red_concrete
fill 359 113 437 359 122 437 minecraft:red_concrete
fill 359 113 449 359 122 449 minecraft:red_concrete
setblock 359 113 457 minecraft:red_concrete
fill 361 113 436 361 122 436 minecraft:red_concrete
fill 361 113 450 361 122 450 minecraft:red_concrete
fill 364 113 435 364 122 435 minecraft:red_concrete
fill 364 113 451 364 122 451 minecraft:red_concrete
setblock 366 113 417 minecraft:red_concrete
setblock 366 113 457 minecraft:red_concrete
fill 367 113 436 367 122 436 minecraft:red_concrete
fill 367 113 450 367 122 450 minecraft:red_concrete
fill 369 113 437 369 122 437 minecraft:red_concrete
fill 369 113 449 369 122 449 minecraft:red_concrete
setblock 370 113 420 minecraft:red_concrete
setblock 370 113 427 minecraft:red_concrete
setblock 370 113 434 minecraft:red_concrete
fill 370 113 438 370 123 438 minecraft:red_concrete
fill 370 113 448 370 122 448 minecraft:red_concrete
setblock 370 113 455 minecraft:red_concrete
setblock 330 114 417 minecraft:red_concrete
setblock 330 114 424 minecraft:red_concrete
setblock 330 114 431 minecraft:red_concrete
setblock 330 114 438 minecraft:red_concrete
setblock 330 114 445 minecraft:red_concrete
setblock 330 114 452 minecraft:red_concrete
setblock 332 114 457 minecraft:red_concrete
setblock 337 114 417 minecraft:red_concrete
setblock 339 114 457 minecraft:red_concrete
setblock 344 114 417 minecraft:red_concrete
setblock 346 114 457 minecraft:red_concrete
setblock 351 114 417 minecraft:red_concrete
setblock 353 114 457 minecraft:red_concrete
setblock 356 114 440 minecraft:black_concrete
fill 356 114 441 356 121 442 minecraft:red_concrete
fill 356 114 444 356 121 445 minecraft:red_concrete
setblock 356 114 446 minecraft:black_concrete
fill 357 114 439 357 121 439 minecraft:red_concrete
fill 357 114 447 357 121 447 minecraft:red_concrete
setblock 358 114 417 minecraft:red_concrete
fill 360 114 436 360 121 436 minecraft:red_concrete
fill 360 114 450 360 121 450 minecraft:red_concrete
setblock 360 114 457 minecraft:red_concrete
fill 362 114 435 363 121 435 minecraft:red_concrete
fill 362 114 451 363 121 451 minecraft:red_concrete
setblock 365 114 417 minecraft:red_concrete
fill 365 114 435 366 121 435 minecraft:red_concrete
fill 365 114 451 366 121 451 minecraft:red_concrete
setblock 367 114 457 minecraft:red_concrete
fill 368 114 419 368 115 425 minecraft:gray_concrete
fill 368 114 436 368 121 436 minecraft:red_concrete
fill 368 114 450 368 121 450 minecraft:red_concrete
setblock 370 114 419 minecraft:red_concrete
setblock 370 114 426 minecraft:red_concrete
setblock 370 114 433 minecraft:red_concrete
setblock 370 114 454 minecraft:red_concrete
setblock 330 115 418 minecraft:red_concrete
setblock 330 115 425 minecraft:red_concrete
setblock 330 115 432 minecraft:red_concrete
setblock 330 115 439 minecraft:red_concrete
setblock 330 115 446 minecraft:red_concrete
setblock 330 115 453 minecraft:red_concrete
setblock 333 115 457 minecraft:red_concrete
setblock 336 115 417 minecraft:red_concrete
setblock 340 115 457 minecraft:red_concrete
setblock 343 115 417 minecraft:red_concrete
setblock 347 115 457 minecraft:red_concrete
setblock 350 115 417 minecraft:red_concrete
setblock 354 115 457 minecraft:red_concrete
fill 356 115 440 356 120 440 minecraft:red_concrete
fill 356 115 446 356 120 446 minecraft:red_concrete
setblock 357 115 417 minecraft:red_concrete
fill 357 115 438 357 120 438 minecraft:red_concrete
fill 357 115 448 357 120 448 minecraft:red_concrete
fill 358 115 437 358 120 437 minecraft:red_concrete
fill 358 115 449 358 120 449 minecraft:red_concrete
fill 359 115 436 359 120 436 minecraft:red_concrete
fill 359 115 450 359 120 450 minecraft:red_concrete
fill 361 115 435 361 120 435 minecraft:red_concrete
fill 361 115 451 361 120 451 minecraft:red_concrete
setblock 361 115 457 minecraft:red_concrete
setblock 364 115 417 minecraft:red_concrete
fill 367 115 435 367 120 435 minecraft:red_concrete
fill 367 115 451 367 120 451 minecraft:red_concrete
setblock 368 115 457 minecraft:red_concrete
fill 369 115 436 369 120 436 minecraft:red_concrete
fill 369 115 450 369 120 450 minecraft:red_concrete
setblock 370 115 418 minecraft:red_concrete
setblock 370 115 425 minecraft:red_concrete
setblock 370 115 432 minecraft:red_concrete
fill 370 115 437 370 120 437 minecraft:red_concrete
setblock 370 115 453 minecraft:red_concrete
setblock 330 116 419 minecraft:red_concrete
setblock 330 116 426 minecraft:red_concrete
setblock 330 116 433 minecraft:red_concrete
setblock 330 116 440 minecraft:red_concrete
setblock 330 116 447 minecraft:red_concrete
setblock 330 116 454 minecraft:red_concrete
setblock 334 116 457 minecraft:red_concrete
setblock 335 116 417 minecraft:red_concrete
setblock 341 116 457 minecraft:red_concrete
setblock 342 116 417 minecraft:red_concrete
setblock 348 116 457 minecraft:red_concrete
setblock 349 116 417 minecraft:red_concrete
setblock 355 116 457 minecraft:red_concrete
setblock 356 116 417 minecraft:red_concrete
setblock 362 116 457 minecraft:red_concrete
setblock 363 116 417 minecraft:red_concrete
setblock 369 116 457 minecraft:red_concrete
setblock 370 116 417 minecraft:red_concrete
setblock 370 116 424 minecraft:red_concrete
setblock 370 116 431 minecraft:red_concrete
setblock 370 116 452 minecraft:red_concrete
setblock 330 117 420 minecraft:red_concrete
setblock 330 117 427 minecraft:red_concrete
setblock 330 117 434 minecraft:red_concrete
setblock 330 117 441 minecraft:red_concrete
setblock 330 117 448 minecraft:red_concrete
setblock 330 117 455 minecraft:red_concrete
setblock 334 117 417 minecraft:red_concrete
setblock 335 117 457 minecraft:red_concrete
setblock 341 117 417 minecraft:red_concrete
setblock 342 117 457 minecraft:red_concrete
setblock 348 117 417 minecraft:red_concrete
setblock 349 117 457 minecraft:red_concrete
setblock 355 117 417 minecraft:red_concrete
fill 356 117 439 356 118 439 minecraft:red_concrete
fill 356 117 447 356 118 447 minecraft:red_concrete
setblock 356 117 457 minecraft:red_concrete
fill 360 117 435 360 118 435 minecraft:red_concrete
fill 360 117 451 360 118 451 minecraft:red_concrete
setblock 362 117 417 minecraft:red_concrete
setblock 363 117 457 minecraft:red_concrete
fill 368 117 435 368 118 435 minecraft:red_concrete
fill 368 117 451 368 118 451 minecraft:red_concrete
setblock 369 117 417 minecraft:red_concrete
setblock 370 117 423 minecraft:red_concrete
setblock 370 117 430 minecraft:red_concrete
setblock 370 117 451 minecraft:red_concrete
setblock 370 117 457 minecraft:red_concrete
setblock 330 118 421 minecraft:red_concrete
setblock 330 118 428 minecraft:red_concrete
setblock 330 118 435 minecraft:red_concrete
setblock 330 118 442 minecraft:red_concrete
setblock 330 118 449 minecraft:red_concrete
setblock 330 118 456 minecraft:red_concrete
setblock 333 118 417 minecraft:red_concrete
setblock 336 118 457 minecraft:red_concrete
setblock 340 118 417 minecraft:red_concrete
setblock 343 118 457 minecraft:red_concrete
setblock 347 118 417 minecraft:red_concrete
setblock 350 118 457 minecraft:red_concrete
setblock 354 118 417 minecraft:red_concrete
setblock 357 118 457 minecraft:red_concrete
setblock 361 118 417 minecraft:red_concrete
setblock 364 118 457 minecraft:red_concrete
setblock 368 118 417 minecraft:red_concrete
setblock 370 118 422 minecraft:red_concrete
setblock 370 118 429 minecraft:red_concrete
setblock 370 118 436 minecraft:red_concrete
setblock 370 118 450 minecraft:red_concrete
fill 355 119 439 355 119 440 minecraft:jack_o_lantern
fill 355 119 446 355 119 447 minecraft:jack_o_lantern
fill 356 119 438 356 120 439 minecraft:jack_o_lantern
fill 356 119 447 356 120 448 minecraft:jack_o_lantern
fill 330 120 417 330 120 421 minecraft:red_concrete
fill 330 120 423 330 120 428 minecraft:red_concrete
fill 330 120 430 330 120 435 minecraft:red_concrete
fill 330 120 437 330 120 442 minecraft:red_concrete
fill 330 120 444 330 120 449 minecraft:red_concrete
fill 330 120 451 330 120 456 minecraft:red_concrete
setblock 331 120 417 minecraft:red_concrete
fill 331 120 457 336 120 457 minecraft:red_concrete
setblock 332 120 419 minecraft:light[level=12]
setblock 332 120 427 minecraft:light[level=12]
setblock 332 120 435 minecraft:light[level=12]
setblock 332 120 443 minecraft:light[level=12]
setblock 332 120 451 minecraft:light[level=12]
fill 333 120 417 338 120 417 minecraft:red_concrete
fill 338 120 457 343 120 457 minecraft:red_concrete
fill 340 120 417 345 120 417 minecraft:red_concrete
setblock 340 120 419 minecraft:light[level=12]
setblock 340 120 427 minecraft:light[level=12]
setblock 340 120 435 minecraft:light[level=12]
setblock 340 120 443 minecraft:light[level=12]
setblock 340 120 451 minecraft:light[level=12]
fill 345 120 457 350 120 457 minecraft:red_concrete
fill 347 120 417 352 120 417 minecraft:red_concrete
setblock 348 120 419 minecraft:light[level=12]
setblock 348 120 427 minecraft:light[level=12]
setblock 348 120 435 minecraft:light[level=12]
setblock 348 120 443 minecraft:light[level=12]
setblock 348 120 451 minecraft:light[level=12]
fill 352 120 457 357 120 457 minecraft:red_concrete
fill 354 120 417 359 120 417 minecraft:red_concrete
setblock 355 120 440 minecraft:jack_o_lantern
setblock 355 120 446 minecraft:jack_o_lantern
setblock 356 120 419 minecraft:light[level=12]
setblock 356 120 427 minecraft:light[level=12]
setblock 356 120 435 minecraft:light[level=12]
setblock 356 120 451 minecraft:light[level=12]
fill 359 120 457 364 120 457 minecraft:red_concrete
fill 361 120 417 366 120 417 minecraft:red_concrete
setblock 364 120 419 minecraft:light[level=12]
setblock 364 120 427 minecraft:light[level=12]
fill 366 120 457 370 120 457 minecraft:red_concrete
fill 368 120 417 370 120 417 minecraft:red_concrete
fill 370 120 418 370 120 420 minecraft:red_concrete
fill 370 120 422 370 120 427 minecraft:red_concrete
fill 370 120 429 370 120 434 minecraft:red_concrete
setblock 370 120 436 minecraft:red_concrete
fill 370 120 450 370 120 455 minecraft:red_concrete
setblock 330 121 417 minecraft:red_concrete
setblock 330 121 424 minecraft:red_concrete
setblock 330 121 431 minecraft:red_concrete
setblock 330 121 438 minecraft:red_concrete
setblock 330 121 445 minecraft:red_concrete
setblock 330 121 452 minecraft:red_concrete
setblock 332 121 457 minecraft:red_concrete
setblock 337 121 417 minecraft:red_concrete
setblock 339 121 457 minecraft:red_concrete
setblock 344 121 417 minecraft:red_concrete
setblock 346 121 457 minecraft:red_concrete
setblock 351 121 417 minecraft:red_concrete
setblock 353 121 457 minecraft:red_concrete
fill 355 121 450 356 122 450 minecraft:white_wool
fill 356 121 439 356 121 440 minecraft:jack_o_lantern
fill 356 121 446 356 121 447 minecraft:jack_o_lantern
setblock 358 121 417 minecraft:red_concrete
setblock 360 121 457 minecraft:red_concrete
setblock 365 121 417 minecraft:red_concrete
setblock 367 121 457 minecraft:red_concrete
setblock 370 121 419 minecraft:red_concrete
setblock 370 121 426 minecraft:red_concrete
setblock 370 121 433 minecraft:red_concrete
setblock 370 121 454 minecraft:red_concrete
setblock 330 122 418 minecraft:red_concrete
setblock 330 122 425 minecraft:red_concrete
setblock 330 122 432 minecraft:red_concrete
setblock 330 122 439 minecraft:red_concrete
setblock 330 122 446 minecraft:red_concrete
setblock 330 122 453 minecraft:red_concrete
setblock 333 122 457 minecraft:red_concrete
setblock 336 122 417 minecraft:red_concrete
setblock 340 122 457 minecraft:red_concrete
setblock 343 122 417 minecraft:red_concrete
setblock 347 122 457 minecraft:red_concrete
setblock 350 122 417 minecraft:red_concrete
setblock 354 122 457 minecraft:red_concrete
setblock 357 122 417 minecraft:red_concrete
setblock 361 122 457 minecraft:red_concrete
setblock 364 122 417 minecraft:red_concrete
setblock 368 122 457 minecraft:red_concrete
setblock 370 122 418 minecraft:red_concrete
setblock 370 122 425 minecraft:red_concrete
setblock 370 122 432 minecraft:red_concrete
setblock 370 122 453 minecraft:red_concrete
setblock 330 123 419 minecraft:red_concrete
setblock 330 123 426 minecraft:red_concrete
setblock 330 123 433 minecraft:red_concrete
setblock 330 123 440 minecraft:red_concrete
setblock 330 123 447 minecraft:red_concrete
setblock 330 123 454 minecraft:red_concrete
setblock 334 123 457 minecraft:red_concrete
setblock 335 123 417 minecraft:red_concrete
setblock 341 123 457 minecraft:red_concrete
setblock 342 123 417 minecraft:red_concrete
setblock 348 123 457 minecraft:red_concrete
setblock 349 123 417 minecraft:red_concrete
setblock 355 123 457 minecraft:red_concrete
setblock 356 123 417 minecraft:red_concrete
setblock 362 123 457 minecraft:red_concrete
setblock 363 123 417 minecraft:red_concrete
setblock 369 123 457 minecraft:red_concrete
setblock 370 123 417 minecraft:red_concrete
setblock 370 123 424 minecraft:red_concrete
setblock 370 123 431 minecraft:red_concrete
setblock 370 123 452 minecraft:red_concrete
setblock 330 124 420 minecraft:red_concrete
setblock 330 124 427 minecraft:red_concrete
setblock 330 124 434 minecraft:red_concrete
setblock 330 124 441 minecraft:red_concrete
setblock 330 124 448 minecraft:red_concrete
setblock 330 124 455 minecraft:red_concrete
setblock 334 124 417 minecraft:red_concrete
setblock 335 124 457 minecraft:red_concrete
setblock 341 124 417 minecraft:red_concrete
setblock 342 124 457 minecraft:red_concrete
setblock 348 124 417 minecraft:red_concrete
setblock 349 124 457 minecraft:red_concrete
setblock 355 124 417 minecraft:red_concrete
setblock 356 124 457 minecraft:red_concrete
setblock 362 124 417 minecraft:red_concrete
setblock 363 124 457 minecraft:red_concrete
setblock 369 124 417 minecraft:red_concrete
setblock 370 124 423 minecraft:red_concrete
setblock 370 124 430 minecraft:red_concrete
setblock 370 124 437 minecraft:red_concrete
setblock 370 124 451 minecraft:red_concrete
setblock 370 124 457 minecraft:red_concrete
setblock 330 125 421 minecraft:red_concrete
setblock 330 125 428 minecraft:red_concrete
setblock 330 125 435 minecraft:red_concrete
setblock 330 125 442 minecraft:red_concrete
setblock 330 125 449 minecraft:red_concrete
setblock 330 125 456 minecraft:red_concrete
setblock 333 125 417 minecraft:red_concrete
setblock 336 125 457 minecraft:red_concrete
setblock 340 125 417 minecraft:red_concrete
setblock 343 125 457 minecraft:red_concrete
setblock 347 125 417 minecraft:red_concrete
setblock 350 125 457 minecraft:red_concrete
setblock 354 125 417 minecraft:red_concrete
setblock 357 125 457 minecraft:red_concrete
setblock 361 125 417 minecraft:red_concrete
setblock 364 125 457 minecraft:red_concrete
setblock 368 125 417 minecraft:red_concrete
fill 368 125 440 369 125 440 minecraft:red_concrete
fill 368 125 446 369 125 446 minecraft:red_concrete
setblock 370 125 422 minecraft:red_concrete
setblock 370 125 429 minecraft:red_concrete
setblock 370 125 436 minecraft:red_concrete
setblock 370 125 443 minecraft:red_concrete
setblock 370 125 450 minecraft:red_concrete
setblock 330 127 423 minecraft:red_concrete
setblock 330 127 430 minecraft:red_concrete
setblock 330 127 437 minecraft:red_concrete
setblock 330 127 444 minecraft:red_concrete
setblock 330 127 451 minecraft:red_concrete
setblock 331 127 417 minecraft:red_concrete
setblock 331 127 457 minecraft:red_concrete
setblock 338 127 417 minecraft:red_concrete
setblock 338 127 457 minecraft:red_concrete
setblock 345 127 417 minecraft:red_concrete
setblock 345 127 457 minecraft:red_concrete
setblock 352 127 417 minecraft:red_concrete
setblock 352 127 457 minecraft:red_concrete
setblock 359 127 417 minecraft:red_concrete
setblock 359 127 457 minecraft:red_concrete
setblock 366 127 417 minecraft:red_concrete
setblock 366 127 457 minecraft:red_concrete
setblock 370 127 420 minecraft:red_concrete
setblock 370 127 427 minecraft:red_concrete
setblock 370 127 434 minecraft:red_concrete
setblock 370 127 441 minecraft:red_concrete
setblock 370 127 448 minecraft:red_concrete
setblock 370 127 455 minecraft:red_concrete
setblock 330 128 417 minecraft:red_concrete
setblock 330 128 424 minecraft:red_concrete
setblock 330 128 431 minecraft:red_concrete
setblock 330 128 438 minecraft:red_concrete
setblock 330 128 445 minecraft:red_concrete
setblock 330 128 452 minecraft:red_concrete
setblock 332 128 419 minecraft:light[level=12]
setblock 332 128 427 minecraft:light[level=12]
setblock 332 128 435 minecraft:light[level=12]
setblock 332 128 443 minecraft:light[level=12]
setblock 332 128 451 minecraft:light[level=12]
setblock 332 128 457 minecraft:red_concrete
setblock 337 128 417 minecraft:red_concrete
setblock 339 128 457 minecraft:red_concrete
setblock 340 128 419 minecraft:light[level=12]
setblock 340 128 427 minecraft:light[level=12]
setblock 340 128 435 minecraft:light[level=12]
setblock 340 128 443 minecraft:light[level=12]
setblock 340 128 451 minecraft:light[level=12]
setblock 344 128 417 minecraft:red_concrete
setblock 346 128 457 minecraft:red_concrete
setblock 348 128 419 minecraft:light[level=12]
setblock 348 128 427 minecraft:light[level=12]
setblock 348 128 435 minecraft:light[level=12]
setblock 348 128 443 minecraft:light[level=12]
setblock 348 128 451 minecraft:light[level=12]
setblock 351 128 417 minecraft:red_concrete
setblock 353 128 457 minecraft:red_concrete
setblock 356 128 419 minecraft:light[level=12]
setblock 356 128 427 minecraft:light[level=12]
setblock 356 128 435 minecraft:light[level=12]
setblock 356 128 443 minecraft:light[level=12]
setblock 356 128 451 minecraft:light[level=12]
setblock 358 128 417 minecraft:red_concrete
setblock 360 128 457 minecraft:red_concrete
setblock 364 128 419 minecraft:light[level=12]
setblock 364 128 427 minecraft:light[level=12]
setblock 364 128 435 minecraft:light[level=12]
setblock 364 128 443 minecraft:light[level=12]
setblock 364 128 451 minecraft:light[level=12]
setblock 365 128 417 minecraft:red_concrete
setblock 367 128 457 minecraft:red_concrete
setblock 370 128 419 minecraft:red_concrete
setblock 370 128 426 minecraft:red_concrete
setblock 370 128 433 minecraft:red_concrete
setblock 370 128 440 minecraft:red_concrete
setblock 370 128 447 minecraft:red_concrete
setblock 370 128 454 minecraft:red_concrete
fill 330 129 418 330 130 418 minecraft:red_concrete
fill 330 129 425 330 130 425 minecraft:red_concrete
fill 330 129 432 330 130 432 minecraft:red_concrete
fill 330 129 439 330 130 439 minecraft:red_concrete
fill 330 129 446 330 130 446 minecraft:red_concrete
fill 330 129 453 330 130 453 minecraft:red_concrete
fill 333 129 457 333 130 457 minecraft:red_concrete
fill 336 129 417 336 130 417 minecraft:red_concrete
fill 340 129 457 340 130 457 minecraft:red_concrete
fill 343 129 417 343 130 417 minecraft:red_concrete
fill 347 129 457 347 130 457 minecraft:red_concrete
fill 350 129 417 350 130 417 minecraft:red_concrete
fill 354 129 457 354 130 457 minecraft:red_concrete
fill 357 129 417 357 130 417 minecraft:red_concrete
fill 361 129 457 361 130 457 minecraft:red_concrete
fill 364 129 417 364 130 417 minecraft:red_concrete
fill 368 129 457 368 130 457 minecraft:red_concrete
fill 370 129 418 370 130 418 minecraft:red_concrete
fill 370 129 425 370 130 425 minecraft:red_concrete
fill 370 129 432 370 130 432 minecraft:red_concrete
fill 370 129 439 370 130 439 minecraft:red_concrete
fill 370 129 446 370 130 446 minecraft:red_concrete
fill 370 129 453 370 130 453 minecraft:red_concrete
fill 330 130 417 331 130 417 minecraft:red_concrete
fill 330 130 419 330 130 421 minecraft:red_concrete
fill 330 130 423 330 130 424 minecraft:red_concrete
fill 330 130 426 330 130 428 minecraft:red_concrete
fill 330 130 430 330 130 431 minecraft:red_concrete
fill 330 130 433 330 130 435 minecraft:red_concrete
fill 330 130 437 330 130 438 minecraft:red_concrete
fill 330 130 440 330 130 442 minecraft:red_concrete
fill 330 130 444 330 130 445 minecraft:red_concrete
fill 330 130 447 330 130 449 minecraft:red_concrete
fill 330 130 451 330 130 452 minecraft:red_concrete
fill 330 130 454 330 130 456 minecraft:red_concrete
fill 331 130 457 332 130 457 minecraft:red_concrete
fill 333 130 417 335 130 417 minecraft:red_concrete
fill 334 130 457 336 130 457 minecraft:red_concrete
fill 337 130 417 338 130 417 minecraft:red_concrete
fill 338 130 457 339 130 457 minecraft:red_concrete
fill 340 130 417 342 130 417 minecraft:red_concrete
fill 341 130 457 343 130 457 minecraft:red_concrete
fill 344 130 417 345 130 417 minecraft:red_concrete
fill 345 130 457 346 130 457 minecraft:red_concrete
fill 347 130 417 349 130 417 minecraft:red_concrete
fill 348 130 457 350 130 457 minecraft:red_concrete
fill 351 130 417 352 130 417 minecraft:red_concrete
fill 352 130 457 353 130 457 minecraft:red_concrete
fill 354 130 417 356 130 417 minecraft:red_concrete
fill 355 130 457 357 130 457 minecraft:red_concrete
fill 358 130 417 359 130 417 minecraft:red_concrete
fill 359 130 457 360 130 457 minecraft:red_concrete
fill 361 130 417 363 130 417 minecraft:red_concrete
fill 362 130 457 364 130 457 minecraft:red_concrete
fill 365 130 417 366 130 417 minecraft:red_concrete
fill 366 130 457 367 130 457 minecraft:red_concrete
fill 368 130 417 370 130 417 minecraft:red_concrete
fill 369 130 457 370 130 457 minecraft:red_concrete
fill 370 130 419 370 130 420 minecraft:red_concrete
fill 370 130 422 370 130 424 minecraft:red_concrete
fill 370 130 426 370 130 427 minecraft:red_concrete
fill 370 130 429 370 130 431 minecraft:red_concrete
fill 370 130 433 370 130 434 minecraft:red_concrete
fill 370 130 436 370 130 438 minecraft:red_concrete
fill 370 130 440 370 130 441 minecraft:red_concrete
fill 370 130 443 370 130 445 minecraft:red_concrete
fill 370 130 447 370 130 448 minecraft:red_concrete
fill 370 130 450 370 130 452 minecraft:red_concrete
fill 370 130 454 370 130 455 minecraft:red_concrete
setblock 330 131 420 minecraft:red_concrete
setblock 330 131 427 minecraft:red_concrete
setblock 330 131 434 minecraft:red_concrete
setblock 330 131 441 minecraft:red_concrete
setblock 330 131 448 minecraft:red_concrete
setblock 330 131 455 minecraft:red_concrete
setblock 334 131 417 minecraft:red_concrete
setblock 335 131 457 minecraft:red_concrete
setblock 341 131 417 minecraft:red_concrete
setblock 342 131 457 minecraft:red_concrete
setblock 348 131 417 minecraft:red_concrete
setblock 349 131 457 minecraft:red_concrete
setblock 355 131 417 minecraft:red_concrete
setblock 356 131 457 minecraft:red_concrete
setblock 362 131 417 minecraft:red_concrete
setblock 363 131 457 minecraft:red_concrete
setblock 369 131 417 minecraft:red_concrete
setblock 370 131 423 minecraft:red_concrete
setblock 370 131 430 minecraft:red_concrete
setblock 370 131 437 minecraft:red_concrete
setblock 370 131 444 minecraft:red_concrete
setblock 370 131 451 minecraft:red_concrete
setblock 370 131 457 minecraft:red_concrete
setblock 330 132 421 minecraft:red_concrete
setblock 330 132 428 minecraft:red_concrete
setblock 330 132 435 minecraft:red_concrete
setblock 330 132 442 minecraft:red_concrete
setblock 330 132 449 minecraft:red_concrete
setblock 330 132 456 minecraft:red_concrete
setblock 333 132 417 minecraft:red_concrete
setblock 336 132 457 minecraft:red_concrete
setblock 340 132 417 minecraft:red_concrete
setblock 343 132 457 minecraft:red_concrete
setblock 347 132 417 minecraft:red_concrete
setblock 350 132 457 minecraft:red_concrete
setblock 354 132 417 minecraft:red_concrete
setblock 357 132 457 minecraft:red_concrete
setblock 361 132 417 minecraft:red_concrete
setblock 364 132 457 minecraft:red_concrete
setblock 368 132 417 minecraft:red_concrete
setblock 370 132 422 minecraft:red_concrete
setblock 370 132 429 minecraft:red_concrete
setblock 370 132 436 minecraft:red_concrete
setblock 370 132 443 minecraft:red_concrete
setblock 370 132 450 minecraft:red_concrete
setblock 330 134 423 minecraft:red_concrete
setblock 330 134 430 minecraft:red_concrete
setblock 330 134 437 minecraft:red_concrete
setblock 330 134 444 minecraft:red_concrete
setblock 330 134 451 minecraft:red_concrete
setblock 331 134 417 minecraft:red_concrete
setblock 331 134 457 minecraft:red_concrete
setblock 338 134 417 minecraft:red_concrete
setblock 338 134 457 minecraft:red_concrete
setblock 345 134 417 minecraft:red_concrete
setblock 345 134 457 minecraft:red_concrete
setblock 352 134 417 minecraft:red_concrete
setblock 352 134 457 minecraft:red_concrete
setblock 359 134 417 minecraft:red_concrete
setblock 359 134 457 minecraft:red_concrete
setblock 366 134 417 minecraft:red_concrete
setblock 366 134 457 minecraft:red_concrete
setblock 370 134 420 minecraft:red_concrete
setblock 370 134 427 minecraft:red_concrete
setblock 370 134 434 minecraft:red_concrete
setblock 370 134 441 minecraft:red_concrete
setblock 370 134 448 minecraft:red_concrete
setblock 370 134 455 minecraft:red_concrete
setblock 330 135 417 minecraft:red_concrete
setblock 330 135 424 minecraft:red_concrete
setblock 330 135 431 minecraft:red_concrete
setblock 330 135 438 minecraft:red_concrete
setblock 330 135 445 minecraft:red_concrete
setblock 330 135 452 minecraft:red_concrete
setblock 332 135 457 minecraft:red_concrete
setblock 337 135 417 minecraft:red_concrete
setblock 339 135 457 minecraft:red_concrete
setblock 344 135 417 minecraft:red_concrete
setblock 346 135 457 minecraft:red_concrete
setblock 351 135 417 minecraft:red_concrete
setblock 353 135 457 minecraft:red_concrete
setblock 358 135 417 minecraft:red_concrete
setblock 360 135 457 minecraft:red_concrete
setblock 365 135 417 minecraft:red_concrete
setblock 367 135 457 minecraft:red_concrete
setblock 370 135 419 minecraft:red_concrete
setblock 370 135 426 minecraft:red_concrete
setblock 370 135 433 minecraft:red_concrete
setblock 370 135 440 minecraft:red_concrete
setblock 370 135 447 minecraft:red_concrete
setblock 370 135 454 minecraft:red_concrete
setblock 330 136 418 minecraft:red_concrete
setblock 330 136 425 minecraft:red_concrete
setblock 330 136 432 minecraft:red_concrete
setblock 330 136 439 minecraft:red_concrete
setblock 330 136 446 minecraft:red_concrete
setblock 330 136 453 minecraft:red_concrete
setblock 332 136 419 minecraft:light[level=12]
setblock 332 136 427 minecraft:light[level=12]
setblock 332 136 435 minecraft:light[level=12]
setblock 332 136 443 minecraft:light[level=12]
setblock 332 136 451 minecraft:light[level=12]
setblock 333 136 457 minecraft:red_concrete
setblock 336 136 417 minecraft:red_concrete
setblock 340 136 419 minecraft:light[level=12]
setblock 340 136 427 minecraft:light[level=12]
setblock 340 136 435 minecraft:light[level=12]
setblock 340 136 443 minecraft:light[level=12]
setblock 340 136 451 minecraft:light[level=12]
setblock 340 136 457 minecraft:red_concrete
setblock 343 136 417 minecraft:red_concrete
setblock 347 136 457 minecraft:red_concrete
setblock 348 136 419 minecraft:light[level=12]
setblock 348 136 427 minecraft:light[level=12]
setblock 348 136 435 minecraft:light[level=12]
setblock 348 136 443 minecraft:light[level=12]
setblock 348 136 451 minecraft:light[level=12]
setblock 350 136 417 minecraft:red_concrete
setblock 354 136 457 minecraft:red_concrete
setblock 356 136 419 minecraft:light[level=12]
setblock 356 136 427 minecraft:light[level=12]
setblock 356 136 435 minecraft:light[level=12]
setblock 356 136 443 minecraft:light[level=12]
setblock 356 136 451 minecraft:light[level=12]
setblock 357 136 417 minecraft:red_concrete
setblock 361 136 457 minecraft:red_concrete
setblock 364 136 417 minecraft:red_concrete
setblock 364 136 419 minecraft:light[level=12]
setblock 364 136 427 minecraft:light[level=12]
setblock 364 136 435 minecraft:light[level=12]
setblock 364 136 443 minecraft:light[level=12]
setblock 364 136 451 minecraft:light[level=12]
setblock 368 136 457 minecraft:red_concrete
setblock 370 136 418 minecraft:red_concrete
setblock 370 136 425 minecraft:red_concrete
setblock 370 136 432 minecraft:red_concrete
setblock 370 136 439 minecraft:red_concrete
setblock 370 136 446 minecraft:red_concrete
setblock 370 136 453 minecraft:red_concrete
setblock 330 137 419 minecraft:red_concrete
setblock 330 137 426 minecraft:red_concrete
setblock 330 137 433 minecraft:red_concrete
setblock 330 137 440 minecraft:red_concrete
setblock 330 137 447 minecraft:red_concrete
setblock 330 137 454 minecraft:red_concrete
setblock 334 137 457 minecraft:red_concrete
setblock 335 137 417 minecraft:red_concrete
setblock 341 137 457 minecraft:red_concrete
setblock 342 137 417 minecraft:red_concrete
setblock 348 137 457 minecraft:red_concrete
setblock 349 137 417 minecraft:red_concrete
setblock 355 137 457 minecraft:red_concrete
setblock 356 137 417 minecraft:red_concrete
setblock 362 137 457 minecraft:red_concrete
setblock 363 137 417 minecraft:red_concrete
setblock 369 137 457 minecraft:red_concrete
setblock 370 137 417 minecraft:red_concrete
setblock 370 137 424 minecraft:red_concrete
setblock 370 137 431 minecraft:red_concrete
setblock 370 137 438 minecraft:red_concrete
setblock 370 137 445 minecraft:red_concrete
setblock 370 137 452 minecraft:red_concrete
setblock 330 138 420 minecraft:red_concrete
setblock 330 138 427 minecraft:red_concrete
setblock 330 138 434 minecraft:red_concrete
setblock 330 138 441 minecraft:red_concrete
setblock 330 138 448 minecraft:red_concrete
setblock 330 138 455 minecraft:red_concrete
setblock 334 138 417 minecraft:red_concrete
setblock 335 138 457 minecraft:red_concrete
setblock 341 138 417 minecraft:red_concrete
setblock 342 138 457 minecraft:red_concrete
setblock 348 138 417 minecraft:red_concrete
setblock 349 138 457 minecraft:red_concrete
setblock 355 138 417 minecraft:red_concrete
setblock 356 138 457 minecraft:red_concrete
setblock 362 138 417 minecraft:red_concrete
setblock 363 138 457 minecraft:red_concrete
setblock 369 138 417 minecraft:red_concrete
setblock 370 138 423 minecraft:red_concrete
setblock 370 138 430 minecraft:red_concrete
setblock 370 138 437 minecraft:red_concrete
setblock 370 138 444 minecraft:red_concrete
setblock 370 138 451 minecraft:red_concrete
setblock 370 138 457 minecraft:red_concrete
fill 330 139 421 330 140 421 minecraft:red_concrete
fill 330 139 428 330 140 428 minecraft:red_concrete
fill 330 139 435 330 140 435 minecraft:red_concrete
fill 330 139 442 330 140 442 minecraft:red_concrete
fill 330 139 449 330 140 449 minecraft:red_concrete
fill 330 139 456 330 140 456 minecraft:red_concrete
fill 333 139 417 333 140 417 minecraft:red_concrete
fill 336 139 457 336 140 457 minecraft:red_concrete
fill 340 139 417 340 140 417 minecraft:red_concrete
fill 343 139 457 343 140 457 minecraft:red_concrete
fill 347 139 417 347 140 417 minecraft:red_concrete
fill 350 139 457 350 140 457 minecraft:red_concrete
fill 354 139 417 354 140 417 minecraft:red_concrete
fill 357 139 457 357 140 457 minecraft:red_concrete
fill 361 139 417 361 140 417 minecraft:red_concrete
fill 364 139 457 364 140 457 minecraft:red_concrete
fill 368 139 417 368 140 417 minecraft:red_concrete
fill 370 139 422 370 140 422 minecraft:red_concrete
fill 370 139 429 370 140 429 minecraft:red_concrete
fill 370 139 436 370 140 436 minecraft:red_concrete
fill 370 139 443 370 140 443 minecraft:red_concrete
fill 370 139 450 370 140 450 minecraft:red_concrete
fill 330 140 417 330 140 420 minecraft:red_concrete
fill 330 140 423 330 140 427 minecraft:red_concrete
fill 330 140 430 330 140 434 minecraft:red_concrete
fill 330 140 437 330 140 441 minecraft:red_concrete
fill 330 140 444 330 140 448 minecraft:red_concrete
fill 330 140 451 330 140 455 minecraft:red_concrete
fill 331 140 417 331 141 417 minecraft:red_concrete
fill 331 140 457 335 140 457 minecraft:red_concrete
fill 334 140 417 338 140 417 minecraft:red_concrete
fill 338 140 457 342 140 457 minecraft:red_concrete
fill 341 140 417 345 140 417 minecraft:red_concrete
fill 345 140 457 349 140 457 minecraft:red_concrete
fill 348 140 417 352 140 417 minecraft:red_concrete
fill 352 140 457 356 140 457 minecraft:red_concrete
fill 355 140 417 359 140 417 minecraft:red_concrete
fill 359 140 457 363 140 457 minecraft:red_concrete
fill 362 140 417 366 140 417 minecraft:red_concrete
fill 366 140 457 370 140 457 minecraft:red_concrete
fill 369 140 417 370 140 417 minecraft:red_concrete
fill 370 140 418 370 140 420 minecraft:red_concrete
fill 370 140 423 370 140 427 minecraft:red_concrete
fill 370 140 430 370 140 434 minecraft:red_concrete
fill 370 140 437 370 140 441 minecraft:red_concrete
fill 370 140 444 370 140 448 minecraft:red_concrete
fill 370 140 451 370 140 455 minecraft:red_concrete
setblock 330 141 423 minecraft:red_concrete
setblock 330 141 430 minecraft:red_concrete
setblock 330 141 437 minecraft:red_concrete
setblock 330 141 444 minecraft:red_concrete
setblock 330 141 451 minecraft:red_concrete
setblock 331 141 457 minecraft:red_concrete
setblock 338 141 417 minecraft:red_concrete
setblock 338 141 457 minecraft:red_concrete
setblock 345 141 417 minecraft:red_concrete
setblock 345 141 457 minecraft:red_concrete
setblock 352 141 417 minecraft:red_concrete
setblock 352 141 457 minecraft:red_concrete
setblock 359 141 417 minecraft:red_concrete
setblock 359 141 457 minecraft:red_concrete
setblock 366 141 417 minecraft:red_concrete
setblock 366 141 457 minecraft:red_concrete
setblock 370 141 420 minecraft:red_concrete
setblock 370 141 427 minecraft:red_concrete
setblock 370 141 434 minecraft:red_concrete
setblock 370 141 441 minecraft:red_concrete
setblock 370 141 448 minecraft:red_concrete
setblock 370 141 455 minecraft:red_concrete
setblock 330 142 417 minecraft:red_concrete
setblock 330 142 424 minecraft:red_concrete
setblock 330 142 431 minecraft:red_concrete
setblock 330 142 438 minecraft:red_concrete
setblock 330 142 445 minecraft:red_concrete
setblock 330 142 452 minecraft:red_concrete
setblock 332 142 457 minecraft:red_concrete
setblock 337 142 417 minecraft:red_concrete
setblock 339 142 457 minecraft:red_concrete
setblock 344 142 417 minecraft:red_concrete
setblock 346 142 457 minecraft:red_concrete
setblock 351 142 417 minecraft:red_concrete
setblock 353 142 457 minecraft:red_concrete
setblock 358 142 417 minecraft:red_concrete
setblock 360 142 457 minecraft:red_concrete
setblock 365 142 417 minecraft:red_concrete
setblock 367 142 457 minecraft:red_concrete
setblock 370 142 419 minecraft:red_concrete
setblock 370 142 426 minecraft:red_concrete
setblock 370 142 433 minecraft:red_concrete
setblock 370 142 440 minecraft:red_concrete
setblock 370 142 447 minecraft:red_concrete
setblock 370 142 454 minecraft:red_concrete
setblock 330 143 418 minecraft:red_concrete
setblock 330 143 425 minecraft:red_concrete
setblock 330 143 432 minecraft:red_concrete
setblock 330 143 439 minecraft:red_concrete
setblock 330 143 446 minecraft:red_concrete
setblock 330 143 453 minecraft:red_concrete
setblock 333 143 457 minecraft:red_concrete
setblock 336 143 417 minecraft:red_concrete
setblock 340 143 457 minecraft:red_concrete
setblock 343 143 417 minecraft:red_concrete
setblock 347 143 457 minecraft:red_concrete
setblock 350 143 417 minecraft:red_concrete
setblock 354 143 457 minecraft:red_concrete
setblock 357 143 417 minecraft:red_concrete
setblock 361 143 457 minecraft:red_concrete
setblock 364 143 417 minecraft:red_concrete
setblock 368 143 457 minecraft:red_concrete
setblock 370 143 418 minecraft:red_concrete
setblock 370 143 425 minecraft:red_concrete
setblock 370 143 432 minecraft:red_concrete
setblock 370 143 439 minecraft:red_concrete
setblock 370 143 446 minecraft:red_concrete
setblock 370 143 453 minecraft:red_concrete
setblock 330 144 419 minecraft:red_concrete
setblock 330 144 426 minecraft:red_concrete
setblock 330 144 433 minecraft:red_concrete
setblock 330 144 440 minecraft:red_concrete
setblock 330 144 447 minecraft:red_concrete
setblock 330 144 454 minecraft:red_concrete
setblock 332 144 419 minecraft:light[level=12]
setblock 332 144 427 minecraft:light[level=12]
setblock 332 144 435 minecraft:light[level=12]
setblock 332 144 443 minecraft:light[level=12]
setblock 332 144 451 minecraft:light[level=12]
setblock 334 144 457 minecraft:red_concrete
setblock 335 144 417 minecraft:red_concrete
setblock 340 144 419 minecraft:light[level=12]
setblock 340 144 427 minecraft:light[level=12]
setblock 340 144 435 minecraft:light[level=12]
setblock 340 144 443 minecraft:light[level=12]
setblock 340 144 451 minecraft:light[level=12]
setblock 341 144 457 minecraft:red_concrete
setblock 342 144 417 minecraft:red_concrete
setblock 348 144 419 minecraft:light[level=12]
setblock 348 144 427 minecraft:light[level=12]
setblock 348 144 435 minecraft:light[level=12]
setblock 348 144 443 minecraft:light[level=12]
setblock 348 144 451 minecraft:light[level=12]
setblock 348 144 457 minecraft:red_concrete
setblock 349 144 417 minecraft:red_concrete
setblock 355 144 457 minecraft:red_concrete
setblock 356 144 417 minecraft:red_concrete
setblock 356 144 419 minecraft:light[level=12]
setblock 356 144 427 minecraft:light[level=12]
setblock 356 144 435 minecraft:light[level=12]
setblock 356 144 443 minecraft:light[level=12]
setblock 356 144 451 minecraft:light[level=12]
setblock 362 144 457 minecraft:red_concrete
setblock 363 144 417 minecraft:red_concrete
setblock 364 144 419 minecraft:light[level=12]
setblock 364 144 427 minecraft:light[level=12]
setblock 364 144 435 minecraft:light[level=12]
setblock 364 144 443 minecraft:light[level=12]
setblock 364 144 451 minecraft:light[level=12]
setblock 369 144 457 minecraft:red_concrete
setblock 370 144 417 minecraft:red_concrete
setblock 370 144 424 minecraft:red_concrete
setblock 370 144 431 minecraft:red_concrete
setblock 370 144 438 minecraft:red_concrete
setblock 370 144 445 minecraft:red_concrete
setblock 370 144 452 minecraft:red_concrete
setblock 330 145 420 minecraft:red_concrete
setblock 330 145 427 minecraft:red_concrete
setblock 330 145 434 minecraft:red_concrete
setblock 330 145 441 minecraft:red_concrete
setblock 330 145 448 minecraft:red_concrete
setblock 330 145 455 minecraft:red_concrete
setblock 334 145 417 minecraft:red_concrete
setblock 335 145 457 minecraft:red_concrete
setblock 341 145 417 minecraft:red_concrete
setblock 342 145 457 minecraft:red_concrete
setblock 348 145 417 minecraft:red_concrete
setblock 349 145 457 minecraft:red_concrete
setblock 355 145 417 minecraft:red_concrete
setblock 356 145 457 minecraft:red_concrete
setblock 362 145 417 minecraft:red_concrete
setblock 363 145 457 minecraft:red_concrete
setblock 369 145 417 minecraft:red_concrete
setblock 370 145 423 minecraft:red_concrete
setblock 370 145 430 minecraft:red_concrete
setblock 370 145 437 minecraft:red_concrete
setblock 370 145 444 minecraft:red_concrete
setblock 370 145 451 minecraft:red_concrete
setblock 370 145 457 minecraft:red_concrete
setblock 330 146 421 minecraft:red_concrete
setblock 330 146 428 minecraft:red_concrete
setblock 330 146 435 minecraft:red_concrete
setblock 330 146 442 minecraft:red_concrete
setblock 330 146 449 minecraft:red_concrete
setblock 330 146 456 minecraft:red_concrete
setblock 333 146 417 minecraft:red_concrete
setblock 336 146 457 minecraft:red_concrete
setblock 340 146 417 minecraft:red_concrete
setblock 343 146 457 minecraft:red_concrete
setblock 347 146 417 minecraft:red_concrete
setblock 350 146 457 minecraft:red_concrete
setblock 354 146 417 minecraft:red_concrete
setblock 357 146 457 minecraft:red_concrete
setblock 361 146 417 minecraft:red_concrete
setblock 364 146 457 minecraft:red_concrete
setblock 368 146 417 minecraft:red_concrete
setblock 370 146 422 minecraft:red_concrete
setblock 370 146 429 minecraft:red_concrete
setblock 370 146 436 minecraft:red_concrete
setblock 370 146 443 minecraft:red_concrete
setblock 370 146 450 minecraft:red_concrete
fill 359 147 449 361 148 449 minecraft:red_wool
fill 360 147 450 361 148 450 minecraft:red_wool
setblock 330 148 423 minecraft:red_concrete
setblock 330 148 430 minecraft:red_concrete
setblock 330 148 437 minecraft:red_concrete
setblock 330 148 444 minecraft:red_concrete
setblock 330 148 451 minecraft:red_concrete
setblock 331 148 417 minecraft:red_concrete
setblock 331 148 457 minecraft:red_concrete
setblock 338 148 417 minecraft:red_concrete
setblock 338 148 457 minecraft:red_concrete
setblock 345 148 417 minecraft:red_concrete
setblock 345 148 457 minecraft:red_concrete
setblock 352 148 417 minecraft:red_concrete
setblock 352 148 457 minecraft:red_concrete
setblock 359 148 417 minecraft:red_concrete
setblock 359 148 457 minecraft:red_concrete
setblock 366 148 417 minecraft:red_concrete
setblock 366 148 457 minecraft:red_concrete
setblock 370 148 420 minecraft:red_concrete
setblock 370 148 427 minecraft:red_concrete
setblock 370 148 434 minecraft:red_concrete
setblock 370 148 441 minecraft:red_concrete
setblock 370 148 448 minecraft:red_concrete
setblock 370 148 455 minecraft:red_concrete
fill 330 149 417 330 150 417 minecraft:red_concrete
fill 330 149 424 330 150 424 minecraft:red_concrete
fill 330 149 431 330 150 431 minecraft:red_concrete
fill 330 149 438 330 150 438 minecraft:red_concrete
fill 330 149 445 330 150 445 minecraft:red_concrete
fill 330 149 452 330 150 452 minecraft:red_concrete
fill 332 149 457 332 150 457 minecraft:red_concrete
fill 337 149 417 337 150 417 minecraft:red_concrete
fill 339 149 457 339 150 457 minecraft:red_concrete
fill 344 149 417 344 150 417 minecraft:red_concrete
fill 346 149 449 347 150 449 minecraft:red_wool
fill 346 149 457 346 150 457 minecraft:red_concrete
fill 351 149 417 351 150 417 minecraft:red_concrete
fill 353 149 457 353 150 457 minecraft:red_concrete
fill 358 149 417 358 150 417 minecraft:red_concrete
fill 360 149 457 360 150 457 minecraft:red_concrete
fill 365 149 417 365 150 417 minecraft:red_concrete
fill 367 149 457 367 150 457 minecraft:red_concrete
fill 370 149 419 370 150 419 minecraft:red_concrete
fill 370 149 426 370 150 426 minecraft:red_concrete
fill 370 149 433 370 150 433 minecraft:red_concrete
fill 370 149 440 370 150 440 minecraft:red_concrete
fill 370 149 447 370 150 447 minecraft:red_concrete
fill 370 149 454 370 150 454 minecraft:red_concrete
fill 330 150 418 330 150 421 minecraft:red_concrete
setblock 330 150 423 minecraft:red_concrete
fill 330 150 425 330 150 428 minecraft:red_concrete
setblock 330 150 430 minecraft:red_concrete
fill 330 150 432 330 150 435 minecraft:red_concrete
setblock 330 150 437 minecraft:red_concrete
fill 330 150 439 330 150 442 minecraft:red_concrete
setblock 330 150 444 minecraft:red_concrete
fill 330 150 446 330 150 449 minecraft:red_concrete
setblock 330 150 451 minecraft:red_concrete
fill 330 150 453 330 150 456 minecraft:red_concrete
setblock 331 150 417 minecraft:red_concrete
setblock 331 150 457 minecraft:red_concrete
fill 333 150 417 336 150 417 minecraft:red_concrete
fill 333 150 457 336 150 457 minecraft:red_concrete
setblock 338 150 417 minecraft:red_concrete
setblock 338 150 457 minecraft:red_concrete
fill 340 150 417 343 150 417 minecraft:red_concrete
fill 340 150 457 343 150 457 minecraft:red_concrete
setblock 345 150 417 minecraft:red_concrete
setblock 345 150 457 minecraft:red_concrete
fill 347 150 417 350 150 417 minecraft:red_concrete
fill 347 150 457 350 150 457 minecraft:red_concrete
setblock 352 150 417 minecraft:red_concrete
setblock 352 150 457 minecraft:red_concrete
fill 354 150 417 357 150 417 minecraft:red_concrete
fill 354 150 457 357 150 457 minecraft:red_concrete
setblock 359 150 417 minecraft:red_concrete
setblock 359 150 457 minecraft:red_concrete
fill 361 150 417 364 150 417 minecraft:red_concrete
fill 361 150 457 364 150 457 minecraft:red_concrete
setblock 366 150 417 minecraft:red_concrete
setblock 366 150 457 minecraft:red_concrete
fill 368 150 417 370 150 417 minecraft:red_concrete
fill 368 150 457 370 150 457 minecraft:red_concrete
setblock 370 150 418 minecraft:red_concrete
setblock 370 150 420 minecraft:red_concrete
fill 370 150 422 370 150 425 minecraft:red_concrete
setblock 370 150 427 minecraft:red_concrete
fill 370 150 429 370 150 432 minecraft:red_concrete
setblock 370 150 434 minecraft:red_concrete
fill 370 150 436 370 150 439 minecraft:red_concrete
setblock 370 150 441 minecraft:red_concrete
fill 370 150 443 370 150 446 minecraft:red_concrete
setblock 370 150 448 minecraft:red_concrete
fill 370 150 450 370 150 453 minecraft:red_concrete
setblock 370 150 455 minecraft:red_concrete
setblock 330 151 419 minecraft:red_concrete
setblock 330 151 426 minecraft:red_concrete
setblock 330 151 433 minecraft:red_concrete
setblock 330 151 440 minecraft:red_concrete
setblock 330 151 447 minecraft:red_concrete
setblock 330 151 454 minecraft:red_concrete
setblock 334 151 457 minecraft:red_concrete
setblock 335 151 417 minecraft:red_concrete
setblock 341 151 457 minecraft:red_concrete
setblock 342 151 417 minecraft:red_concrete
setblock 348 151 457 minecraft:red_concrete
setblock 349 151 417 minecraft:red_concrete
setblock 355 151 457 minecraft:red_concrete
setblock 356 151 417 minecraft:red_concrete
setblock 362 151 457 minecraft:red_concrete
setblock 363 151 417 minecraft:red_concrete
setblock 369 151 457 minecraft:red_concrete
setblock 370 151 417 minecraft:red_concrete
setblock 370 151 424 minecraft:red_concrete
setblock 370 151 431 minecraft:red_concrete
setblock 370 151 438 minecraft:red_concrete
setblock 370 151 445 minecraft:red_concrete
setblock 370 151 452 minecraft:red_concrete
setblock 330 152 420 minecraft:red_concrete
setblock 330 152 427 minecraft:red_concrete
setblock 330 152 434 minecraft:red_concrete
setblock 330 152 441 minecraft:red_concrete
setblock 330 152 448 minecraft:red_concrete
setblock 330 152 455 minecraft:red_concrete
setblock 332 152 419 minecraft:light[level=12]
setblock 332 152 427 minecraft:light[level=12]
setblock 332 152 435 minecraft:light[level=12]
setblock 332 152 443 minecraft:light[level=12]
setblock 332 152 451 minecraft:light[level=12]
setblock 334 152 417 minecraft:red_concrete
setblock 335 152 457 minecraft:red_concrete
setblock 340 152 419 minecraft:light[level=12]
setblock 340 152 427 minecraft:light[level=12]
setblock 340 152 435 minecraft:light[level=12]
setblock 340 152 443 minecraft:light[level=12]
setblock 340 152 451 minecraft:light[level=12]
setblock 341 152 417 minecraft:red_concrete
setblock 342 152 457 minecraft:red_concrete
setblock 348 152 417 minecraft:red_concrete
setblock 348 152 419 minecraft:light[level=12]
setblock 348 152 427 minecraft:light[level=12]
setblock 348 152 435 minecraft:light[level=12]
setblock 348 152 443 minecraft:light[level=12]
setblock 348 152 451 minecraft:light[level=12]
setblock 349 152 457 minecraft:red_concrete
setblock 355 152 417 minecraft:red_concrete
setblock 356 152 419 minecraft:light[level=12]
setblock 356 152 427 minecraft:light[level=12]
setblock 356 152 435 minecraft:light[level=12]
setblock 356 152 443 minecraft:light[level=12]
setblock 356 152 451 minecraft:light[level=12]
setblock 356 152 457 minecraft:red_concrete
setblock 362 152 417 minecraft:red_concrete
setblock 363 152 457 minecraft:red_concrete
setblock 364 152 419 minecraft:light[level=12]
setblock 364 152 427 minecraft:light[level=12]
setblock 364 152 435 minecraft:light[level=12]
setblock 364 152 443 minecraft:light[level=12]
setblock 364 152 451 minecraft:light[level=12]
setblock 369 152 417 minecraft:red_concrete
setblock 370 152 423 minecraft:red_concrete
setblock 370 152 430 minecraft:red_concrete
setblock 370 152 437 minecraft:red_concrete
setblock 370 152 444 minecraft:red_concrete
setblock 370 152 451 minecraft:red_concrete
setblock 370 152 457 minecraft:red_concrete
setblock 330 153 421 minecraft:red_concrete
setblock 330 153 428 minecraft:red_concrete
setblock 330 153 435 minecraft:red_concrete
setblock 330 153 442 minecraft:red_concrete
setblock 330 153 449 minecraft:red_concrete
setblock 330 153 456 minecraft:red_concrete
setblock 333 153 417 minecraft:red_concrete
setblock 336 153 457 minecraft:red_concrete
setblock 340 153 417 minecraft:red_concrete
setblock 343 153 457 minecraft:red_concrete
setblock 347 153 417 minecraft:red_concrete
setblock 350 153 457 minecraft:red_concrete
setblock 354 153 417 minecraft:red_concrete
setblock 357 153 457 minecraft:red_concrete
setblock 361 153 417 minecraft:red_concrete
setblock 364 153 457 minecraft:red_concrete
setblock 368 153 417 minecraft:red_concrete
setblock 370 153 422 minecraft:red_concrete
setblock 370 153 429 minecraft:red_concrete
setblock 370 153 436 minecraft:red_concrete
setblock 370 153 443 minecraft:red_concrete
setblock 370 153 450 minecraft:red_concrete
fill 341 154 431 342 155 432 minecraft:white_wool
setblock 330 155 423 minecraft:red_concrete
setblock 330 155 430 minecraft:red_concrete
setblock 330 155 437 minecraft:red_concrete
setblock 330 155 444 minecraft:red_concrete
setblock 330 155 451 minecraft:red_concrete
setblock 331 155 417 minecraft:red_concrete
setblock 331 155 457 minecraft:red_concrete
setblock 338 155 417 minecraft:red_concrete
setblock 338 155 457 minecraft:red_concrete
setblock 345 155 417 minecraft:red_concrete
setblock 345 155 457 minecraft:red_concrete
setblock 352 155 417 minecraft:red_concrete
setblock 352 155 457 minecraft:red_concrete
setblock 359 155 417 minecraft:red_concrete
setblock 359 155 457 minecraft:red_concrete
setblock 366 155 417 minecraft:red_concrete
setblock 366 155 457 minecraft:red_concrete
setblock 370 155 420 minecraft:red_concrete
setblock 370 155 427 minecraft:red_concrete
setblock 370 155 434 minecraft:red_concrete
setblock 370 155 441 minecraft:red_concrete
setblock 370 155 448 minecraft:red_concrete
setblock 370 155 455 minecraft:red_concrete
setblock 330 156 417 minecraft:red_concrete
setblock 330 156 424 minecraft:red_concrete
setblock 330 156 431 minecraft:red_concrete
setblock 330 156 438 minecraft:red_concrete
setblock 330 156 445 minecraft:red_concrete
setblock 330 156 452 minecraft:red_concrete
setblock 332 156 457 minecraft:red_concrete
setblock 337 156 417 minecraft:red_concrete
setblock 339 156 457 minecraft:red_concrete
setblock 344 156 417 minecraft:red_concrete
setblock 346 156 457 minecraft:red_concrete
setblock 351 156 417 minecraft:red_concrete
setblock 353 156 457 minecraft:red_concrete
setblock 358 156 417 minecraft:red_concrete
setblock 360 156 457 minecraft:red_concrete
setblock 365 156 417 minecraft:red_concrete
setblock 367 156 457 minecraft:red_concrete
setblock 370 156 419 minecraft:red_concrete
setblock 370 156 426 minecraft:red_concrete
setblock 370 156 433 minecraft:red_concrete
setblock 370 156 440 minecraft:red_concrete
setblock 370 156 447 minecraft:red_concrete
setblock 370 156 454 minecraft:red_concrete
setblock 330 157 418 minecraft:red_concrete
setblock 330 157 425 minecraft:red_concrete
setblock 330 157 432 minecraft:red_concrete
setblock 330 157 439 minecraft:red_concrete
setblock 330 157 446 minecraft:red_concrete
setblock 330 157 453 minecraft:red_concrete
setblock 333 157 457 minecraft:red_concrete
setblock 336 157 417 minecraft:red_concrete
setblock 340 157 457 minecraft:red_concrete
setblock 343 157 417 minecraft:red_concrete
setblock 347 157 457 minecraft:red_concrete
setblock 350 157 417 minecraft:red_concrete
setblock 354 157 457 minecraft:red_concrete
setblock 357 157 417 minecraft:red_concrete
setblock 361 157 457 minecraft:red_concrete
setblock 364 157 417 minecraft:red_concrete
setblock 368 157 457 minecraft:red_concrete
setblock 370 157 418 minecraft:red_concrete
setblock 370 157 425 minecraft:red_concrete
setblock 370 157 432 minecraft:red_concrete
setblock 370 157 439 minecraft:red_concrete
setblock 370 157 446 minecraft:red_concrete
setblock 370 157 453 minecraft:red_concrete
setblock 330 158 419 minecraft:red_concrete
setblock 330 158 426 minecraft:red_concrete
setblock 330 158 433 minecraft:red_concrete
setblock 330 158 440 minecraft:red_concrete
setblock 330 158 447 minecraft:red_concrete
setblock 330 158 454 minecraft:red_concrete
setblock 334 158 457 minecraft:red_concrete
setblock 335 158 417 minecraft:red_concrete
setblock 341 158 457 minecraft:red_concrete
setblock 342 158 417 minecraft:red_concrete
setblock 348 158 457 minecraft:red_concrete
setblock 349 158 417 minecraft:red_concrete
setblock 355 158 457 minecraft:red_concrete
setblock 356 158 417 minecraft:red_concrete
setblock 362 158 457 minecraft:red_concrete
setblock 363 158 417 minecraft:red_concrete
setblock 369 158 457 minecraft:red_concrete
setblock 370 158 417 minecraft:red_concrete
setblock 370 158 424 minecraft:red_concrete
setblock 370 158 431 minecraft:red_concrete
setblock 370 158 438 minecraft:red_concrete
setblock 370 158 445 minecraft:red_concrete
setblock 370 158 452 minecraft:red_concrete
fill 330 159 420 330 160 420 minecraft:red_concrete
fill 330 159 427 330 160 427 minecraft:red_concrete
fill 330 159 434 330 160 434 minecraft:red_concrete
fill 330 159 441 330 160 441 minecraft:red_concrete
fill 330 159 448 330 160 448 minecraft:red_concrete
fill 330 159 455 330 160 455 minecraft:red_concrete
fill 331 159 435 332 160 435 minecraft:yellow_wool
fill 334 159 417 334 160 417 minecraft:red_concrete
fill 335 159 457 335 160 457 minecraft:red_concrete
fill 341 159 417 341 160 417 minecraft:red_concrete
fill 342 159 457 342 160 457 minecraft:red_concrete
fill 348 159 417 348 160 417 minecraft:red_concrete
fill 349 159 457 349 160 457 minecraft:red_concrete
fill 355 159 417 355 160 417 minecraft:red_concrete
fill 356 159 457 356 160 457 minecraft:red_concrete
fill 362 159 417 362 160 417 minecraft:red_concrete
fill 363 159 457 363 160 457 minecraft:red_concrete
fill 369 159 417 369 160 417 minecraft:red_concrete
fill 370 159 423 370 160 423 minecraft:red_concrete
fill 370 159 430 370 160 430 minecraft:red_concrete
fill 370 159 437 370 160 437 minecraft:red_concrete
fill 370 159 444 370 160 444 minecraft:red_concrete
fill 370 159 451 370 160 451 minecraft:red_concrete
fill 370 159 457 370 160 457 minecraft:red_concrete
fill 330 160 417 330 160 419 minecraft:red_concrete
setblock 330 160 421 minecraft:red_concrete
fill 330 160 423 330 160 426 minecraft:red_concrete
setblock 330 160 428 minecraft:red_concrete
fill 330 160 430 330 160 433 minecraft:red_concrete
setblock 330 160 435 minecraft:red_concrete
fill 330 160 437 330 160 440 minecraft:red_concrete
setblock 330 160 442 minecraft:red_concrete
fill 330 160 444 330 160 447 minecraft:red_concrete
setblock 330 160 449 minecraft:red_concrete
fill 330 160 451 330 160 454 minecraft:red_concrete
setblock 330 160 456 minecraft:red_concrete
setblock 331 160 417 minecraft:red_concrete
fill 331 160 457 334 160 457 minecraft:red_concrete
setblock 332 160 419 minecraft:light[level=12]
setblock 332 160 427 minecraft:light[level=12]
setblock 332 160 443 minecraft:light[level=12]
setblock 332 160 451 minecraft:light[level=12]
setblock 333 160 417 minecraft:red_concrete
fill 335 160 417 338 160 417 minecraft:red_concrete
setblock 336 160 457 minecraft:red_concrete
fill 338 160 457 341 160 457 minecraft:red_concrete
setblock 340 160 417 minecraft:red_concrete
setblock 340 160 419 minecraft:light[level=12]
setblock 340 160 427 minecraft:light[level=12]
setblock 340 160 435 minecraft:light[level=12]
setblock 340 160 443 minecraft:light[level=12]
setblock 340 160 451 minecraft:light[level=12]
fill 342 160 417 345 160 417 minecraft:red_concrete
setblock 343 160 457 minecraft:red_concrete
fill 345 160 457 348 160 457 minecraft:red_concrete
setblock 347 160 417 minecraft:red_concrete
setblock 348 160 419 minecraft:light[level=12]
setblock 348 160 427 minecraft:light[level=12]
setblock 348 160 435 minecraft:light[level=12]
setblock 348 160 443 minecraft:light[level=12]
setblock 348 160 451 minecraft:light[level=12]
fill 349 160 417 352 160 417 minecraft:red_concrete
setblock 350 160 457 minecraft:red_concrete
fill 352 160 457 355 160 457 minecraft:red_concrete
setblock 354 160 417 minecraft:red_concrete
fill 356 160 417 359 160 417 minecraft:red_concrete
setblock 356 160 419 minecraft:light[level=12]
setblock 356 160 427 minecraft:light[level=12]
setblock 356 160 435 minecraft:light[level=12]
setblock 356 160 443 minecraft:light[level=12]
setblock 356 160 451 minecraft:light[level=12]
setblock 357 160 457 minecraft:red_concrete
fill 359 160 457 362 160 457 minecraft:red_concrete
setblock 361 160 417 minecraft:red_concrete
fill 363 160 417 366 160 417 minecraft:red_concrete
setblock 364 160 419 minecraft:light[level=12]
setblock 364 160 427 minecraft:light[level=12]
setblock 364 160 435 minecraft:light[level=12]
setblock 364 160 443 minecraft:light[level=12]
setblock 364 160 451 minecraft:light[level=12]
setblock 364 160 457 minecraft:red_concrete
fill 366 160 457 369 160 457 minecraft:red_concrete
setblock 368 160 417 minecraft:red_concrete
fill 370 160 417 370 160 420 minecraft:red_concrete
setblock 370 160 422 minecraft:red_concrete
fill 370 160 424 370 160 427 minecraft:red_concrete
setblock 370 160 429 minecraft:red_concrete
fill 370 160 431 370 160 434 minecraft:red_concrete
setblock 370 160 436 minecraft:red_concrete
fill 370 160 438 370 160 441 minecraft:red_concrete
setblock 370 160 443 minecraft:red_concrete
fill 370 160 445 370 160 448 minecraft:red_concrete
setblock 370 160 450 minecraft:red_concrete
fill 370 160 452 370 160 455 minecraft:red_concrete
setblock 330 162 423 minecraft:red_concrete
setblock 330 162 430 minecraft:red_concrete
setblock 330 162 437 minecraft:red_concrete
setblock 330 162 444 minecraft:red_concrete
setblock 330 162 451 minecraft:red_concrete
setblock 331 162 417 minecraft:red_concrete
setblock 331 162 457 minecraft:red_concrete
setblock 338 162 417 minecraft:red_concrete
setblock 338 162 457 minecraft:red_concrete
setblock 345 162 417 minecraft:red_concrete
setblock 345 162 457 minecraft:red_concrete
setblock 352 162 417 minecraft:red_concrete
setblock 352 162 457 minecraft:red_concrete
setblock 359 162 417 minecraft:red_concrete
setblock 359 162 457 minecraft:red_concrete
setblock 366 162 417 minecraft:red_concrete
setblock 366 162 457 minecraft:red_concrete
setblock 370 162 420 minecraft:red_concrete
setblock 370 162 427 minecraft:red_concrete
setblock 370 162 434 minecraft:red_concrete
setblock 370 162 441 minecraft:red_concrete
setblock 370 162 448 minecraft:red_concrete
setblock 370 162 455 minecraft:red_concrete
setblock 330 163 417 minecraft:red_concrete
setblock 330 163 424 minecraft:red_concrete
setblock 330 163 431 minecraft:red_concrete
setblock 330 163 438 minecraft:red_concrete
setblock 330 163 445 minecraft:red_concrete
setblock 330 163 452 minecraft:red_concrete
setblock 332 163 457 minecraft:red_concrete
setblock 337 163 417 minecraft:red_concrete
setblock 339 163 457 minecraft:red_concrete
setblock 344 163 417 minecraft:red_concrete
setblock 346 163 457 minecraft:red_concrete
setblock 351 163 417 minecraft:red_concrete
setblock 353 163 457 minecraft:red_concrete
setblock 358 163 417 minecraft:red_concrete
setblock 360 163 457 minecraft:red_concrete
setblock 365 163 417 minecraft:red_concrete
setblock 367 163 457 minecraft:red_concrete
setblock 370 163 419 minecraft:red_concrete
setblock 370 163 426 minecraft:red_concrete
setblock 370 163 433 minecraft:red_concrete
setblock 370 163 440 minecraft:red_concrete
setblock 370 163 447 minecraft:red_concrete
setblock 370 163 454 minecraft:red_concrete
setblock 330 164 418 minecraft:red_concrete
setblock 330 164 425 minecraft:red_concrete
setblock 330 164 432 minecraft:red_concrete
setblock 330 164 439 minecraft:red_concrete
setblock 330 164 446 minecraft:red_concrete
setblock 330 164 453 minecraft:red_concrete
setblock 333 164 457 minecraft:red_concrete
setblock 336 164 417 minecraft:red_concrete
setblock 340 164 457 minecraft:red_concrete
setblock 343 164 417 minecraft:red_concrete
setblock 347 164 457 minecraft:red_concrete
setblock 350 164 417 minecraft:red_concrete
setblock 354 164 457 minecraft:red_concrete
setblock 357 164 417 minecraft:red_concrete
setblock 361 164 457 minecraft:red_concrete
setblock 364 164 417 minecraft:red_concrete
setblock 368 164 457 minecraft:red_concrete
setblock 370 164 418 minecraft:red_concrete
setblock 370 164 425 minecraft:red_concrete
setblock 370 164 432 minecraft:red_concrete
setblock 370 164 439 minecraft:red_concrete
setblock 370 164 446 minecraft:red_concrete
setblock 370 164 453 minecraft:red_concrete
setblock 330 165 419 minecraft:red_concrete
setblock 330 165 426 minecraft:red_concrete
setblock 330 165 433 minecraft:red_concrete
setblock 330 165 440 minecraft:red_concrete
setblock 330 165 447 minecraft:red_concrete
setblock 330 165 454 minecraft:red_concrete
setblock 334 165 457 minecraft:red_concrete
setblock 335 165 417 minecraft:red_concrete
setblock 341 165 457 minecraft:red_concrete
setblock 342 165 417 minecraft:red_concrete
setblock 348 165 457 minecraft:red_concrete
setblock 349 165 417 minecraft:red_concrete
setblock 355 165 457 minecraft:red_concrete
setblock 356 165 417 minecraft:red_concrete
setblock 362 165 457 minecraft:red_concrete
setblock 363 165 417 minecraft:red_concrete
setblock 369 165 457 minecraft:red_concrete
setblock 370 165 417 minecraft:red_concrete
setblock 370 165 424 minecraft:red_concrete
setblock 370 165 431 minecraft:red_concrete
setblock 370 165 438 minecraft:red_concrete
setblock 370 165 445 minecraft:red_concrete
setblock 370 165 452 minecraft:red_concrete
setblock 332 168 419 minecraft:light[level=12]
setblock 332 168 427 minecraft:light[level=12]
setblock 332 168 435 minecraft:light[level=12]
setblock 332 168 443 minecraft:light[level=12]
setblock 332 168 451 minecraft:light[level=12]
setblock 340 168 419 minecraft:light[level=12]
setblock 340 168 427 minecraft:light[level=12]
setblock 340 168 435 minecraft:light[level=12]
setblock 340 168 443 minecraft:light[level=12]
setblock 340 168 451 minecraft:light[level=12]
setblock 348 168 419 minecraft:light[level=12]
setblock 348 168 427 minecraft:light[level=12]
setblock 348 168 435 minecraft:light[level=12]
setblock 348 168 443 minecraft:light[level=12]
setblock 348 168 451 minecraft:light[level=12]
setblock 356 168 419 minecraft:light[level=12]
setblock 356 168 427 minecraft:light[level=12]
setblock 356 168 435 minecraft:light[level=12]
setblock 356 168 443 minecraft:light[level=12]
setblock 356 168 451 minecraft:light[level=12]
setblock 364 168 419 minecraft:light[level=12]
setblock 364 168 427 minecraft:light[level=12]
setblock 364 168 435 minecraft:light[level=12]
setblock 364 168 443 minecraft:light[level=12]
setblock 364 168 451 minecraft:light[level=12]
fill 331 171 433 350 171 441 minecraft:white_concrete
fill 332 171 430 368 171 432 minecraft:white_concrete
fill 332 171 442 368 171 444 minecraft:white_concrete
fill 333 171 428 367 171 429 minecraft:white_concrete
fill 333 171 445 367 171 446 minecraft:white_concrete
fill 334 171 426 366 171 427 minecraft:white_concrete
fill 334 171 447 366 171 448 minecraft:white_concrete
fill 335 171 425 365 171 425 minecraft:white_concrete
fill 335 171 449 365 171 449 minecraft:white_concrete
fill 336 171 424 364 171 424 minecraft:white_concrete
fill 336 171 450 364 171 450 minecraft:white_concrete
fill 337 171 423 363 171 423 minecraft:white_concrete
fill 337 171 451 363 171 451 minecraft:white_concrete
fill 338 171 422 362 171 422 minecraft:white_concrete
fill 338 171 452 362 171 452 minecraft:white_concrete
fill 339 171 421 361 171 421 minecraft:white_concrete
fill 339 171 453 361 171 453 minecraft:white_concrete
fill 341 171 420 359 171 420 minecraft:white_concrete
fill 341 171 454 359 171 454 minecraft:white_concrete
fill 343 171 419 357 171 419 minecraft:white_concrete
fill 343 171 455 357 171 455 minecraft:white_concrete
fill 346 171 418 354 171 418 minecraft:white_concrete
fill 346 171 456 354 171 456 minecraft:white_concrete
fill 351 171 433 351 171 437 minecraft:white_concrete
setblock 351 171 438 minecraft:red_concrete
fill 351 171 439 351 171 441 minecraft:white_concrete
fill 352 171 433 369 171 435 minecraft:white_concrete
fill 352 171 436 352 171 437 minecraft:red_concrete
fill 352 171 439 352 171 440 minecraft:red_concrete
fill 352 171 441 369 171 441 minecraft:white_concrete
setblock 353 171 436 minecraft:red_concrete
setblock 353 171 440 minecraft:red_concrete
setblock 355 171 436 minecraft:red_concrete
setblock 355 171 440 minecraft:red_concrete
fill 356 171 436 369 171 436 minecraft:white_concrete
setblock 356 171 437 minecraft:red_concrete
setblock 356 171 439 minecraft:red_concrete
fill 356 171 440 369 171 440 minecraft:white_concrete
fill 357 171 437 369 171 439 minecraft:white_concrete
fill 330 172 417 330 172 421 minecraft:orange_terracotta
setblock 330 172 422 minecraft:white_concrete
fill 330 172 423 330 172 429 minecraft:orange_terracotta
setblock 330 172 430 minecraft:white_concrete
fill 330 172 431 330 172 437 minecraft:orange_terracotta
setblock 330 172 438 minecraft:white_concrete
fill 330 172 439 330 172 445 minecraft:orange_terracotta
setblock 330 172 446 minecraft:white_concrete
fill 330 172 447 330 172 453 minecraft:orange_terracotta
setblock 330 172 454 minecraft:white_concrete
fill 330 172 455 334 172 457 minecraft:orange_terracotta
fill 331 172 417 331 172 420 minecraft:orange_terracotta
setblock 331 172 421 minecraft:white_concrete
fill 331 172 422 331 172 428 minecraft:orange_terracotta
setblock 331 172 429 minecraft:white_concrete
fill 331 172 430 331 172 436 minecraft:orange_terracotta
setblock 331 172 437 minecraft:white_concrete
fill 331 172 438 331 172 444 minecraft:orange_terracotta
setblock 331 172 445 minecraft:white_concrete
fill 331 172 446 331 172 452 minecraft:orange_terracotta
setblock 331 172 453 minecraft:white_concrete
fill 331 172 454 337 172 454 minecraft:orange_terracotta
fill 332 172 417 332 172 419 minecraft:orange_terracotta
setblock 332 172 420 minecraft:white_concrete
fill 332 172 421 332 172 427 minecraft:orange_terracotta
setblock 332 172 428 minecraft:white_concrete
fill 332 172 429 332 172 435 minecraft:orange_terracotta
fill 332 172 436 332 173 436 minecraft:white_concrete
fill 332 172 437 332 172 443 minecraft:orange_terracotta
setblock 332 172 444 minecraft:white_concrete
fill 332 172 445 332 172 451 minecraft:orange_terracotta
setblock 332 172 452 minecraft:white_concrete
fill 332 172 453 338 172 453 minecraft:orange_terracotta
fill 333 172 417 333 172 418 minecraft:orange_terracotta
setblock 333 172 419 minecraft:white_concrete
fill 333 172 420 333 172 426 minecraft:orange_terracotta
setblock 333 172 427 minecraft:white_concrete
fill 333 172 428 333 172 434 minecraft:orange_terracotta
fill 333 172 435 333 174 435 minecraft:white_concrete
fill 333 172 436 333 172 442 minecraft:orange_terracotta
fill 333 172 443 333 173 443 minecraft:white_concrete
fill 333 172 444 333 172 450 minecraft:orange_terracotta
setblock 333 172 451 minecraft:white_concrete
fill 333 172 452 339 172 452 minecraft:orange_terracotta
setblock 334 172 417 minecraft:orange_terracotta
setblock 334 172 418 minecraft:white_concrete
fill 334 172 419 334 172 425 minecraft:orange_terracotta
setblock 334 172 426 minecraft:white_concrete
fill 334 172 427 334 172 433 minecraft:orange_terracotta
fill 334 172 434 334 175 434 minecraft:white_concrete
fill 334 172 435 334 172 441 minecraft:orange_terracotta
fill 334 172 442 334 175 442 minecraft:white_concrete
fill 334 172 443 334 172 449 minecraft:orange_terracotta
setblock 334 172 450 minecraft:white_concrete
fill 334 172 451 340 172 451 minecraft:orange_terracotta
setblock 335 172 417 minecraft:white_concrete
fill 335 172 418 335 172 424 minecraft:orange_terracotta
setblock 335 172 425 minecraft:white_concrete
fill 335 172 426 335 172 432 minecraft:orange_terracotta
fill 335 172 433 335 176 433 minecraft:white_concrete
fill 335 172 434 335 172 440 minecraft:orange_terracotta
fill 335 172 441 335 176 441 minecraft:white_concrete
fill 335 172 442 335 172 448 minecraft:orange_terracotta
setblock 335 172 449 minecraft:white_concrete
fill 335 172 450 341 172 450 minecraft:orange_terracotta
fill 335 172 455 335 172 456 minecraft:orange_terracotta
setblock 335 172 457 minecraft:white_concrete
fill 336 172 417 336 172 423 minecraft:orange_terracotta
setblock 336 172 424 minecraft:white_concrete
fill 336 172 425 336 172 431 minecraft:orange_terracotta
fill 336 172 432 336 176 432 minecraft:white_concrete
fill 336 172 433 336 172 439 minecraft:orange_terracotta
fill 336 172 440 336 177 440 minecraft:white_concrete
fill 336 172 441 336 172 447 minecraft:orange_terracotta
fill 336 172 448 336 173 448 minecraft:white_concrete
fill 336 172 449 342 172 449 minecraft:orange_terracotta
setblock 336 172 455 minecraft:orange_terracotta
setblock 336 172 456 minecraft:white_concrete
fill 336 172 457 342 172 457 minecraft:orange_terracotta
fill 337 172 417 337 172 422 minecraft:orange_terracotta
setblock 337 172 423 minecraft:white_concrete
fill 337 172 424 337 172 430 minecraft:orange_terracotta
fill 337 172 431 337 177 431 minecraft:white_concrete
fill 337 172 432 337 172 438 minecraft:orange_terracotta
fill 337 172 439 337 178 439 minecraft:white_concrete
fill 337 172 440 337 172 446 minecraft:orange_terracotta
fill 337 172 447 337 175 447 minecraft:white_concrete
fill 337 172 448 343 172 448 minecraft:orange_terracotta
setblock 337 172 455 minecraft:white_concrete
fill 337 172 456 343 172 456 minecraft:orange_terracotta
fill 338 172 417 338 172 421 minecraft:orange_terracotta
setblock 338 172 422 minecraft:white_concrete
fill 338 172 423 338 172 429 minecraft:orange_terracotta
fill 338 172 430 338 177 430 minecraft:white_concrete
fill 338 172 431 338 172 437 minecraft:orange_terracotta
fill 338 172 438 338 178 438 minecraft:white_concrete
fill 338 172 439 338 172 445 minecraft:orange_terracotta
fill 338 172 446 338 176 446 minecraft:white_concrete
fill 338 172 447 344 172 447 minecraft:orange_terracotta
setblock 338 172 454 minecraft:white_concrete
fill 338 172 455 344 172 455 minecraft:orange_terracotta
fill 339 172 417 339 172 420 minecraft:orange_terracotta
setblock 339 172 421 minecraft:white_concrete
fill 339 172 422 339 172 428 minecraft:orange_terracotta
fill 339 172 429 339 177 429 minecraft:white_concrete
fill 339 172 430 339 172 436 minecraft:orange_terracotta
fill 339 172 437 339 178 437 minecraft:white_concrete
fill 339 172 438 339 172 444 minecraft:orange_terracotta
fill 339 172 445 339 177 445 minecraft:white_concrete
fill 339 172 446 345 172 446 minecraft:orange_terracotta
setblock 339 172 453 minecraft:white_concrete
fill 339 172 454 345 172 454 minecraft:orange_terracotta
fill 340 172 417 340 172 419 minecraft:orange_terracotta
setblock 340 172 420 minecraft:white_concrete
fill 340 172 421 340 172 427 minecraft:orange_terracotta
fill 340 172 428 340 177 428 minecraft:white_concrete
fill 340 172 429 340 172 435 minecraft:orange_terracotta
fill 340 172 436 340 177 436 minecraft:white_concrete
fill 340 172 437 340 172 443 minecraft:orange_terracotta
fill 340 172 444 340 178 444 minecraft:white_concrete
fill 340 172 445 346 172 445 minecraft:orange_terracotta
fill 340 172 452 340 173 452 minecraft:white_concrete
fill 340 172 453 346 172 453 minecraft:orange_terracotta
fill 341 172 417 341 172 418 minecraft:orange_terracotta
setblock 341 172 419 minecraft:white_concrete
fill 341 172 420 341 172 426 minecraft:orange_terracotta
fill 341 172 427 341 177 427 minecraft:white_concrete
fill 341 172 428 341 172 434 minecraft:orange_terracotta
fill 341 172 435 341 177 435 minecraft:white_concrete
fill 341 172 436 341 172 442 minecraft:orange_terracotta
fill 341 172 443 341 178 443 minecraft:white_concrete
fill 341 172 444 347 172 444 minecraft:orange_terracotta
fill 341 172 451 341 175 451 minecraft:white_concrete
fill 341 172 452 347 172 452 minecraft:orange_terracotta
setblock 342 172 417 minecraft:orange_terracotta
setblock 342 172 418 minecraft:white_concrete
fill 342 172 419 342 172 425 minecraft:orange_terracotta
fill 342 172 426 342 177 426 minecraft:white_concrete
fill 342 172 427 342 172 433 minecraft:orange_terracotta
fill 342 172 434 342 176 434 minecraft:white_concrete
fill 342 172 435 342 172 441 minecraft:orange_terracotta
fill 342 172 442 342 177 442 minecraft:white_concrete
fill 342 172 443 348 172 443 minecraft:orange_terracotta
fill 342 172 450 342 176 450 minecraft:white_concrete
fill 342 172 451 348 172 451 minecraft:orange_terracotta
setblock 343 172 417 minecraft:white_concrete
fill 343 172 418 343 172 424 minecraft:orange_terracotta
fill 343 172 425 343 177 425 minecraft:white_concrete
fill 343 172 426 343 172 432 minecraft:orange_terracotta
fill 343 172 433 343 176 433 minecraft:white_concrete
fill 343 172 434 343 172 440 minecraft:orange_terracotta
fill 343 172 441 343 176 441 minecraft:white_concrete
fill 343 172 442 349 172 442 minecraft:orange_terracotta
fill 343 172 449 343 177 449 minecraft:white_concrete
fill 343 172 450 349 172 450 minecraft:orange_terracotta
setblock 343 172 457 minecraft:white_concrete
fill 344 172 417 344 172 423 minecraft:orange_terracotta
fill 344 172 424 344 177 424 minecraft:white_concrete
fill 344 172 425 344 172 431 minecraft:orange_terracotta
fill 344 172 432 344 175 432 minecraft:white_concrete
fill 344 172 433 344 172 439 minecraft:orange_terracotta
fill 344 172 440 344 175 440 minecraft:white_concrete
fill 344 172 441 350 172 441 minecraft:orange_terracotta
fill 344 172 448 344 178 448 minecraft:white_concrete
fill 344 172 449 350 172 449 minecraft:orange_terracotta
setblock 344 172 456 minecraft:white_concrete
fill 344 172 457 350 172 457 minecraft:orange_terracotta
fill 345 172 417 345 172 422 minecraft:orange_terracotta
fill 345 172 423 345 176 423 minecraft:white_concrete
fill 345 172 424 345 172 430 minecraft:orange_terracotta
fill 345 172 431 345 176 431 minecraft:white_concrete
fill 345 172 432 345 172 438 minecraft:orange_terracotta
fill 345 172 439 345 174 439 minecraft:white_concrete
fill 345 172 440 351 172 440 minecraft:orange_terracotta
fill 345 172 447 345 178 447 minecraft:white_concrete
fill 345 172 448 351 172 448 minecraft:orange_terracotta
setblock 345 172 455 minecraft:white_concrete
fill 345 172 456 351 172 456 minecraft:orange_terracotta
fill 346 172 417 346 172 421 minecraft:orange_terracotta
fill 346 172 422 346 176 422 minecraft:white_concrete
fill 346 172 423 346 172 429 minecraft:orange_terracotta
fill 346 172 430 346 176 430 minecraft:white_concrete
fill 346 172 431 346 172 437 minecraft:orange_terracotta
fill 346 172 438 346 173 438 minecraft:white_concrete
fill 346 172 439 351 172 439 minecraft:orange_terracotta
fill 346 172 446 346 177 446 minecraft:white_concrete
fill 346 172 447 352 172 447 minecraft:orange_terracotta
fill 346 172 454 346 174 454 minecraft:white_concrete
fill 346 172 455 352 172 455 minecraft:orange_terracotta
fill 347 172 417 347 172 420 minecraft:orange_terracotta
fill 347 172 421 347 175 421 minecraft:white_concrete
fill 347 172 422 347 172 428 minecraft:orange_terracotta
fill 347 172 429 347 176 429 minecraft:white_concrete
fill 347 172 430 347 172 436 minecraft:orange_terracotta
fill 347 172 437 347 173 437 minecraft:white_concrete
fill 347 172 438 351 172 438 minecraft:orange_terracotta
fill 347 172 445 347 176 445 minecraft:white_concrete
fill 347 172 446 353 172 446 minecraft:orange_terracotta
fill 347 172 453 347 175 453 minecraft:white_concrete
fill 347 172 454 353 172 454 minecraft:orange_terracotta
fill 348 172 417 348 172 419 minecraft:orange_terracotta
fill 348 172 420 348 174 420 minecraft:white_concrete
fill 348 172 421 348 172 427 minecraft:orange_terracotta
fill 348 172 428 348 176 428 minecraft:white_concrete
fill 348 172 429 348 172 435 minecraft:orange_terracotta
setblock 348 172 436 minecraft:white_concrete
fill 348 172 437 351 172 437 minecraft:orange_terracotta
fill 348 172 444 348 175 444 minecraft:white_concrete
fill 348 172 445 354 172 445 minecraft:orange_terracotta
fill 348 172 452 348 176 452 minecraft:white_concrete
fill 348 172 453 354 172 453 minecraft:orange_terracotta
fill 349 172 417 349 172 418 minecraft:orange_terracotta
fill 349 172 419 349 173 419 minecraft:white_concrete
fill 349 172 420 349 172 426 minecraft:orange_terracotta
fill 349 172 427 349 177 427 minecraft:white_concrete
fill 349 172 428 349 172 434 minecraft:orange_terracotta
setblock 349 172 435 minecraft:white_concrete
fill 349 172 436 351 172 436 minecraft:orange_terracotta
fill 349 172 443 349 174 443 minecraft:white_concrete
fill 349 172 444 355 172 444 minecraft:orange_terracotta
fill 349 172 451 349 177 451 minecraft:white_concrete
fill 349 172 452 355 172 452 minecraft:orange_terracotta
setblock 350 172 417 minecraft:orange_terracotta
setblock 350 172 418 minecraft:white_concrete
fill 350 172 419 350 172 425 minecraft:orange_terracotta
fill 350 172 426 350 178 426 minecraft:white_concrete
fill 350 172 427 350 172 433 minecraft:orange_terracotta
fill 350 172 434 350 179 434 minecraft:white_concrete
fill 350 172 435 356 172 435 minecraft:orange_terracotta
fill 350 172 442 350 179 442 minecraft:white_concrete
fill 350 172 443 356 172 443 minecraft:orange_terracotta
fill 350 172 450 350 178 450 minecraft:white_concrete
fill 350 172 451 356 172 451 minecraft:orange_terracotta
setblock 351 172 417 minecraft:white_concrete
fill 351 172 418 351 172 424 minecraft:orange_terracotta
fill 351 172 425 351 178 425 minecraft:white_concrete
fill 351 172 426 351 172 432 minecraft:orange_terracotta
setblock 351 172 433 minecraft:white_concrete
fill 351 172 434 357 172 434 minecraft:orange_terracotta
setblock 351 172 441 minecraft:white_concrete
fill 351 172 442 357 172 442 minecraft:orange_terracotta
fill 351 172 449 351 178 449 minecraft:white_concrete
fill 351 172 450 357 172 450 minecraft:orange_terracotta
setblock 351 172 457 minecraft:white_concrete
fill 352 172 417 352 172 423 minecraft:orange_terracotta
fill 352 172 424 352 178 424 minecraft:white_concrete
fill 352 172 425 352 172 431 minecraft:orange_terracotta
fill 352 172 432 352 173 432 minecraft:white_concrete
fill 352 172 433 358 172 433 minecraft:orange_terracotta
fill 352 172 436 352 173 437 minecraft:orange_concrete
fill 352 172 439 352 173 440 minecraft:orange_concrete
fill 352 172 441 358 172 441 minecraft:orange_terracotta
fill 352 172 448 352 178 448 minecraft:white_concrete
fill 352 172 449 358 172 449 minecraft:orange_terracotta
setblock 352 172 456 minecraft:white_concrete
fill 352 172 457 358 172 457 minecraft:orange_terracotta
fill 353 172 417 353 172 422 minecraft:orange_terracotta
fill 353 172 423 353 177 423 minecraft:white_concrete
fill 353 172 424 353 172 430 minecraft:orange_terracotta
fill 353 172 431 353 174 431 minecraft:white_concrete
fill 353 172 432 359 172 432 minecraft:orange_terracotta
fill 353 172 436 353 173 436 minecraft:orange_concrete
fill 353 172 440 353 173 440 minecraft:orange_concrete
fill 353 172 447 353 177 447 minecraft:white_concrete
fill 353 172 448 359 172 448 minecraft:orange_terracotta
fill 353 172 455 353 173 455 minecraft:white_concrete
fill 353 172 456 359 172 456 minecraft:orange_terracotta
fill 354 172 417 354 172 421 minecraft:orange_terracotta
fill 354 172 422 354 176 422 minecraft:white_concrete
fill 354 172 423 354 172 429 minecraft:orange_terracotta
fill 354 172 430 354 175 430 minecraft:white_concrete
fill 354 172 431 360 172 431 minecraft:orange_terracotta
fill 354 172 446 354 177 446 minecraft:white_concrete
fill 354 172 447 360 172 447 minecraft:orange_terracotta
fill 354 172 454 354 174 454 minecraft:white_concrete
fill 354 172 455 360 172 455 minecraft:orange_terracotta
fill 355 172 417 355 172 420 minecraft:orange_terracotta
fill 355 172 421 355 175 421 minecraft:white_concrete
fill 355 172 422 355 172 428 minecraft:orange_terracotta
fill 355 172 429 355 176 429 minecraft:white_concrete
fill 355 172 430 361 172 430 minecraft:orange_terracotta
fill 355 172 436 356 172 436 minecraft:orange_concrete
fill 355 172 440 356 173 440 minecraft:orange_concrete
fill 355 172 445 355 176 445 minecraft:white_concrete
fill 355 172 446 361 172 446 minecraft:orange_terracotta
fill 355 172 453 355 175 453 minecraft:white_concrete
fill 355 172 454 361 172 454 minecraft:orange_terracotta
fill 356 172 417 356 172 419 minecraft:orange_terracotta
fill 356 172 420 356 173 420 minecraft:white_concrete
fill 356 172 421 356 172 427 minecraft:orange_terracotta
fill 356 172 428 356 178 428 minecraft:white_concrete
fill 356 172 429 362 172 429 minecraft:orange_terracotta
fill 356 172 437 356 173 437 minecraft:orange_concrete
fill 356 172 439 356 173 439 minecraft:orange_concrete
fill 356 172 444 356 176 444 minecraft:white_concrete
fill 356 172 445 362 172 445 minecraft:orange_terracotta
fill 356 172 452 356 175 452 minecraft:white_concrete
fill 356 172 453 362 172 453 minecraft:orange_terracotta
fill 357 172 417 357 172 418 minecraft:orange_terracotta
setblock 357 172 419 minecraft:white_concrete
fill 357 172 420 357 172 426 minecraft:orange_terracotta
fill 357 172 427 357 178 427 minecraft:white_concrete
fill 357 172 428 363 172 428 minecraft:orange_terracotta
fill 357 172 435 357 173 435 minecraft:white_concrete
fill 357 172 436 359 172 440 minecraft:orange_terracotta
fill 357 172 443 357 176 443 minecraft:white_concrete
fill 357 172 444 363 172 444 minecraft:orange_terracotta
fill 357 172 451 357 176 451 minecraft:white_concrete
fill 357 172 452 363 172 452 minecraft:orange_terracotta
setblock 358 172 417 minecraft:orange_terracotta
setblock 358 172 418 minecraft:white_concrete
fill 358 172 419 358 172 425 minecraft:orange_terracotta
fill 358 172 426 358 177 426 minecraft:white_concrete
fill 358 172 427 364 172 427 minecraft:orange_terracotta
fill 358 172 434 358 175 434 minecraft:white_concrete
fill 358 172 435 364 172 435 minecraft:orange_terracotta
fill 358 172 442 358 176 442 minecraft:white_concrete
fill 358 172 443 364 172 443 minecraft:orange_terracotta
fill 358 172 450 358 176 450 minecraft:white_concrete
fill 358 172 451 364 172 451 minecraft:orange_terracotta
setblock 359 172 417 minecraft:white_concrete
fill 359 172 418 359 172 424 minecraft:orange_terracotta
fill 359 172 425 359 176 425 minecraft:white_concrete
fill 359 172 426 365 172 426 minecraft:orange_terracotta
fill 359 172 433 359 176 433 minecraft:white_concrete
fill 359 172 434 365 172 434 minecraft:orange_terracotta
fill 359 172 441 359 176 441 minecraft:white_concrete
fill 359 172 442 365 172 442 minecraft:orange_terracotta
fill 359 172 449 359 176 449 minecraft:white_concrete
fill 359 172 450 365 172 450 minecraft:orange_terracotta
setblock 359 172 457 minecraft:white_concrete
fill 360 172 417 360 172 423 minecraft:orange_terracotta
fill 360 172 424 360 175 424 minecraft:white_concrete
fill 360 172 425 366 172 425 minecraft:orange_terracotta
fill 360 172 432 360 178 432 minecraft:white_concrete
fill 360 172 433 366 172 433 minecraft:orange_terracotta
fill 360 172 436 360 172 439 minecraft:orange_terracotta
fill 360 172 440 360 177 440 minecraft:white_concrete
fill 360 172 441 366 172 441 minecraft:orange_terracotta
fill 360 172 448 360 176 448 minecraft:white_concrete
fill 360 172 449 366 172 449 minecraft:orange_terracotta
setblock 360 172 456 minecraft:white_concrete
fill 360 172 457 366 172 457 minecraft:orange_terracotta
fill 361 172 417 361 172 422 minecraft:orange_terracotta
fill 361 172 423 361 173 423 minecraft:white_concrete
fill 361 172 424 367 172 424 minecraft:orange_terracotta
fill 361 172 431 361 178 431 minecraft:white_concrete
fill 361 172 432 367 172 432 minecraft:orange_terracotta
fill 361 172 436 361 172 438 minecraft:orange_terracotta
fill 361 172 439 361 178 439 minecraft:white_concrete
fill 361 172 440 367 172 440 minecraft:orange_terracotta
fill 361 172 447 361 176 447 minecraft:white_concrete
fill 361 172 448 367 172 448 minecraft:orange_terracotta
setblock 361 172 455 minecraft:white_concrete
fill 361 172 456 367 172 456 minecraft:orange_terracotta
fill 362 172 417 362 172 421 minecraft:orange_terracotta
setblock 362 172 422 minecraft:white_concrete
fill 362 172 423 368 172 423 minecraft:orange_terracotta
fill 362 172 430 362 177 430 minecraft:white_concrete
fill 362 172 431 368 172 431 minecraft:orange_terracotta
fill 362 172 436 362 172 437 minecraft:orange_terracotta
fill 362 172 438 362 178 438 minecraft:white_concrete
fill 362 172 439 368 172 439 minecraft:orange_terracotta
fill 362 172 446 362 176 446 minecraft:white_concrete
fill 362 172 447 368 172 447 minecraft:orange_terracotta
setblock 362 172 454 minecraft:white_concrete
fill 362 172 455 368 172 455 minecraft:orange_terracotta
fill 363 172 417 363 172 420 minecraft:orange_terracotta
setblock 363 172 421 minecraft:white_concrete
fill 363 172 422 369 172 422 minecraft:orange_terracotta
fill 363 172 429 363 176 429 minecraft:white_concrete
fill 363 172 430 369 172 430 minecraft:orange_terracotta
setblock 363 172 436 minecraft:orange_terracotta
fill 363 172 437 363 178 437 minecraft:white_concrete
fill 363 172 438 369 172 438 minecraft:orange_terracotta
fill 363 172 445 363 176 445 minecraft:white_concrete
fill 363 172 446 369 172 446 minecraft:orange_terracotta
setblock 363 172 453 minecraft:white_concrete
fill 363 172 454 369 172 454 minecraft:orange_terracotta
fill 364 172 417 364 172 419 minecraft:orange_terracotta
setblock 364 172 420 minecraft:white_concrete
fill 364 172 421 370 172 421 minecraft:orange_terracotta
fill 364 172 428 364 175 428 minecraft:white_concrete
fill 364 172 429 370 172 429 minecraft:orange_terracotta
fill 364 172 436 364 177 436 minecraft:white_concrete
fill 364 172 437 370 172 437 minecraft:orange_terracotta
fill 364 172 444 364 176 444 minecraft:white_concrete
fill 364 172 445 370 172 445 minecraft:orange_terracotta
setblock 364 172 452 minecraft:white_concrete
fill 364 172 453 370 172 453 minecraft:orange_terracotta
fill 365 172 417 365 172 418 minecraft:orange_terracotta
setblock 365 172 419 minecraft:white_concrete
fill 365 172 420 370 172 420 minecraft:orange_terracotta
fill 365 172 427 365 173 427 minecraft:white_concrete
fill 365 172 428 370 172 428 minecraft:orange_terracotta
fill 365 172 435 365 176 435 minecraft:white_concrete
fill 365 172 436 370 172 436 minecraft:orange_terracotta
fill 365 172 443 365 175 443 minecraft:white_concrete
fill 365 172 444 370 172 444 minecraft:orange_terracotta
setblock 365 172 451 minecraft:white_concrete
fill 365 172 452 370 172 452 minecraft:orange_terracotta
setblock 366 172 417 minecraft:orange_terracotta
setblock 366 172 418 minecraft:white_concrete
fill 366 172 419 370 172 419 minecraft:orange_terracotta
setblock 366 172 426 minecraft:white_concrete
fill 366 172 427 370 172 427 minecraft:orange_terracotta
fill 366 172 434 366 175 434 minecraft:white_concrete
fill 366 172 435 370 172 435 minecraft:orange_terracotta
fill 366 172 442 366 175 442 minecraft:white_concrete
fill 366 172 443 370 172 443 minecraft:orange_terracotta
setblock 366 172 450 minecraft:white_concrete
fill 366 172 451 370 172 451 minecraft:orange_terracotta
setblock 367 172 417 minecraft:white_concrete
fill 367 172 418 370 172 418 minecraft:orange_terracotta
setblock 367 172 425 minecraft:white_concrete
fill 367 172 426 370 172 426 minecraft:orange_terracotta
fill 367 172 433 367 174 433 minecraft:white_concrete
fill 367 172 434 370 172 434 minecraft:orange_terracotta
fill 367 172 441 367 174 441 minecraft:white_concrete
fill 367 172 442 370 172 442 minecraft:orange_terracotta
setblock 367 172 449 minecraft:white_concrete
fill 367 172 450 370 172 450 minecraft:orange_terracotta
setblock 367 172 457 minecraft:white_concrete
fill 368 172 417 370 172 417 minecraft:orange_terracotta
setblock 368 172 424 minecraft:white_concrete
fill 368 172 425 370 172 425 minecraft:orange_terracotta
setblock 368 172 432 minecraft:white_concrete
fill 368 172 433 370 172 433 minecraft:orange_terracotta
fill 368 172 440 368 173 440 minecraft:white_concrete
fill 368 172 441 370 172 441 minecraft:orange_terracotta
setblock 368 172 448 minecraft:white_concrete
fill 368 172 449 370 172 449 minecraft:orange_terracotta
setblock 368 172 456 minecraft:white_concrete
fill 368 172 457 370 172 457 minecraft:orange_terracotta
setblock 369 172 423 minecraft:white_concrete
fill 369 172 424 370 172 424 minecraft:orange_terracotta
setblock 369 172 431 minecraft:white_concrete
fill 369 172 432 370 172 432 minecraft:orange_terracotta
setblock 369 172 439 minecraft:white_concrete
fill 369 172 440 370 172 440 minecraft:orange_terracotta
setblock 369 172 447 minecraft:white_concrete
fill 369 172 448 370 172 448 minecraft:orange_terracotta
setblock 369 172 455 minecraft:white_concrete
fill 369 172 456 370 172 456 minecraft:orange_terracotta
setblock 370 172 422 minecraft:white_concrete
setblock 370 172 423 minecraft:orange_terracotta
setblock 370 172 430 minecraft:white_concrete
setblock 370 172 431 minecraft:orange_terracotta
setblock 370 172 438 minecraft:white_concrete
setblock 370 172 439 minecraft:orange_terracotta
setblock 370 172 446 minecraft:white_concrete
setblock 370 172 447 minecraft:orange_terracotta
setblock 370 172 454 minecraft:white_concrete
setblock 370 172 455 minecraft:orange_terracotta
fill 332 173 434 332 173 435 minecraft:white_concrete
fill 332 173 437 335 173 440 minecraft:white_concrete
fill 333 173 431 333 173 434 minecraft:white_concrete
fill 333 173 436 339 174 436 minecraft:white_concrete
fill 333 173 441 333 173 442 minecraft:white_concrete
fill 334 173 429 334 173 433 minecraft:white_concrete
fill 334 173 435 340 175 435 minecraft:white_concrete
fill 334 173 441 334 175 441 minecraft:white_concrete
fill 334 173 443 338 173 445 minecraft:white_concrete
fill 335 173 427 335 173 432 minecraft:white_concrete
fill 335 173 434 341 176 434 minecraft:white_concrete
fill 335 173 442 341 176 442 minecraft:white_concrete
fill 335 173 446 336 173 447 minecraft:white_concrete
fill 336 173 426 336 173 431 minecraft:white_concrete
fill 336 173 433 342 176 433 minecraft:white_concrete
fill 336 173 437 336 177 439 minecraft:white_concrete
fill 336 173 441 342 176 441 minecraft:white_concrete
fill 337 173 425 337 173 430 minecraft:white_concrete
fill 337 173 432 343 176 432 minecraft:white_concrete
fill 337 173 437 337 178 438 minecraft:white_concrete
fill 337 173 440 343 175 440 minecraft:white_concrete
fill 337 173 446 337 176 446 minecraft:white_concrete
fill 337 173 448 342 173 449 minecraft:white_concrete
fill 338 173 424 338 173 429 minecraft:white_concrete
fill 338 173 431 344 176 431 minecraft:white_concrete
fill 338 173 437 338 178 437 minecraft:white_concrete
fill 338 173 439 344 175 439 minecraft:white_concrete
fill 338 173 447 344 176 447 minecraft:white_concrete
fill 338 173 450 341 173 450 minecraft:white_concrete
fill 339 173 423 339 173 428 minecraft:white_concrete
fill 339 173 430 345 176 430 minecraft:white_concrete
fill 339 173 438 345 174 438 minecraft:white_concrete
fill 339 173 443 339 178 444 minecraft:white_concrete
fill 339 173 446 345 177 446 minecraft:white_concrete
fill 339 173 451 340 173 451 minecraft:white_concrete
fill 340 173 422 340 173 427 minecraft:white_concrete
fill 340 173 429 346 176 429 minecraft:white_concrete
fill 340 173 437 346 173 437 minecraft:white_concrete
fill 340 173 443 340 178 443 minecraft:white_concrete
fill 340 173 445 346 176 445 minecraft:white_concrete
fill 341 173 422 341 174 426 minecraft:white_concrete
fill 341 173 428 347 177 428 minecraft:white_concrete
fill 341 173 436 347 173 436 minecraft:white_concrete
fill 341 173 444 347 175 444 minecraft:white_concrete
fill 341 173 452 347 174 452 minecraft:white_concrete
fill 342 173 421 342 173 425 minecraft:white_concrete
fill 342 173 427 348 177 427 minecraft:white_concrete
fill 342 173 435 348 173 435 minecraft:white_concrete
fill 342 173 443 348 174 443 minecraft:white_concrete
fill 342 173 451 348 175 451 minecraft:white_concrete
fill 342 173 453 346 173 453 minecraft:white_concrete
fill 343 173 421 343 174 424 minecraft:white_concrete
fill 343 173 426 349 178 426 minecraft:white_concrete
fill 343 173 434 349 173 434 minecraft:white_concrete
fill 343 173 442 349 173 442 minecraft:white_concrete
fill 343 173 448 343 178 448 minecraft:white_concrete
fill 343 173 450 349 177 450 minecraft:white_concrete
fill 344 173 420 344 173 423 minecraft:white_concrete
fill 344 173 425 350 177 425 minecraft:white_concrete
fill 344 173 433 350 173 433 minecraft:white_concrete
fill 344 173 441 348 173 441 minecraft:white_concrete
fill 344 173 449 350 177 449 minecraft:white_concrete
fill 344 173 454 345 173 454 minecraft:white_concrete
fill 345 173 420 345 173 422 minecraft:white_concrete
fill 345 173 424 351 177 424 minecraft:white_concrete
fill 345 173 432 351 173 432 minecraft:white_concrete
fill 345 173 440 348 173 440 minecraft:white_concrete
fill 345 173 448 351 178 448 minecraft:white_concrete
fill 346 173 420 346 174 421 minecraft:white_concrete
fill 346 173 423 352 177 423 minecraft:white_concrete
fill 346 173 431 352 174 431 minecraft:white_concrete
fill 346 173 439 347 173 439 minecraft:white_concrete
fill 346 173 447 352 177 447 minecraft:white_concrete
fill 347 173 419 347 173 420 minecraft:white_concrete
fill 347 173 422 353 176 422 minecraft:white_concrete
fill 347 173 430 353 175 430 minecraft:white_concrete
setblock 347 173 438 minecraft:white_concrete
fill 347 173 446 353 176 446 minecraft:white_concrete
fill 347 173 454 352 173 455 minecraft:white_concrete
setblock 348 173 419 minecraft:white_concrete
fill 348 173 421 354 175 421 minecraft:white_concrete
fill 348 173 429 354 175 429 minecraft:white_concrete
fill 348 173 436 349 173 439 minecraft:red_concrete
fill 348 173 445 354 175 445 minecraft:white_concrete
fill 348 173 453 354 175 453 minecraft:white_concrete
fill 349 173 420 355 173 420 minecraft:white_concrete
fill 349 173 428 355 176 428 minecraft:white_concrete
setblock 349 173 435 minecraft:red_concrete
fill 349 173 440 349 173 441 minecraft:red_concrete
fill 349 173 444 355 174 444 minecraft:white_concrete
fill 349 173 452 355 176 452 minecraft:white_concrete
fill 350 173 419 353 173 419 minecraft:white_concrete
fill 350 173 427 356 177 427 minecraft:white_concrete
fill 350 173 435 350 173 441 minecraft:white_concrete
fill 350 173 443 356 173 443 minecraft:white_concrete
fill 350 173 451 356 176 451 minecraft:white_concrete
fill 351 173 426 357 178 426 minecraft:white_concrete
fill 351 173 433 352 173 434 minecraft:red_concrete
fill 351 173 442 355 173 442 minecraft:red_concrete
fill 351 173 450 357 177 450 minecraft:white_concrete
fill 352 173 425 358 177 425 minecraft:white_concrete
fill 352 173 449 358 177 449 minecraft:white_concrete
fill 353 173 424 359 176 424 minecraft:white_concrete
fill 353 173 432 359 173 432 minecraft:white_concrete
fill 353 173 433 354 173 433 minecraft:red_concrete
fill 353 173 448 359 177 448 minecraft:white_concrete
fill 353 173 454 353 174 454 minecraft:white_concrete
fill 354 173 423 360 174 423 minecraft:white_concrete
fill 354 173 431 360 174 431 minecraft:white_concrete
fill 354 173 434 355 173 434 minecraft:red_concrete
fill 354 173 447 360 177 447 minecraft:white_concrete
fill 355 173 422 360 173 422 minecraft:white_concrete
fill 355 173 430 361 175 430 minecraft:white_concrete
fill 355 173 433 358 173 433 minecraft:white_concrete
fill 355 173 446 361 177 446 minecraft:white_concrete
fill 355 173 454 356 173 454 minecraft:white_concrete
fill 356 173 421 358 173 421 minecraft:white_concrete
fill 356 173 429 362 177 429 minecraft:white_concrete
fill 356 173 434 357 173 434 minecraft:white_concrete
setblock 356 173 435 minecraft:red_concrete
setblock 356 173 436 minecraft:orange_concrete
setblock 356 173 441 minecraft:red_concrete
fill 356 173 442 357 173 442 minecraft:white_concrete
fill 356 173 445 362 177 445 minecraft:white_concrete
fill 356 173 453 358 173 453 minecraft:white_concrete
fill 357 173 428 363 176 428 minecraft:white_concrete
fill 357 173 436 357 173 437 minecraft:red_concrete
fill 357 173 439 357 173 440 minecraft:red_concrete
fill 357 173 441 358 173 441 minecraft:white_concrete
fill 357 173 444 363 177 444 minecraft:white_concrete
fill 357 173 452 360 173 452 minecraft:white_concrete
fill 358 173 427 364 174 427 minecraft:white_concrete
fill 358 173 435 362 173 437 minecraft:white_concrete
fill 358 173 438 358 174 438 minecraft:red_concrete
fill 358 173 439 359 173 440 minecraft:white_concrete
fill 358 173 443 364 176 443 minecraft:white_concrete
fill 358 173 451 361 173 451 minecraft:white_concrete
fill 359 173 426 364 173 426 minecraft:white_concrete
fill 359 173 434 365 176 434 minecraft:white_concrete
fill 359 173 438 361 174 438 minecraft:white_concrete
fill 359 173 442 365 176 442 minecraft:white_concrete
fill 359 173 450 362 173 450 minecraft:white_concrete
fill 360 173 425 363 173 425 minecraft:white_concrete
fill 360 173 433 366 175 433 minecraft:white_concrete
fill 360 173 439 360 177 439 minecraft:white_concrete
fill 360 173 441 366 175 441 minecraft:white_concrete
fill 360 173 449 363 173 449 minecraft:white_concrete
fill 361 173 424 362 173 424 minecraft:white_concrete
fill 361 173 432 367 173 432 minecraft:white_concrete
fill 361 173 440 367 174 440 minecraft:white_concrete
fill 361 173 448 364 173 448 minecraft:white_concrete
fill 362 173 431 367 173 431 minecraft:white_concrete
fill 362 173 439 368 173 439 minecraft:white_concrete
fill 362 173 447 365 173 447 minecraft:white_concrete
fill 363 173 430 366 174 430 minecraft:white_concrete
fill 363 173 435 363 178 436 minecraft:white_concrete
fill 363 173 438 368 173 438 minecraft:white_concrete
fill 363 173 446 365 174 446 minecraft:white_concrete
fill 364 173 429 366 173 429 minecraft:white_concrete
fill 364 173 435 364 177 435 minecraft:white_concrete
fill 364 173 437 368 173 437 minecraft:white_concrete
fill 364 173 445 366 173 445 minecraft:white_concrete
fill 365 173 428 365 174 428 minecraft:white_concrete
fill 365 173 436 368 173 436 minecraft:white_concrete
fill 365 173 444 366 174 444 minecraft:white_concrete
fill 366 173 435 368 173 435 minecraft:white_concrete
fill 366 173 443 367 173 443 minecraft:white_concrete
fill 367 173 434 368 173 434 minecraft:white_concrete
setblock 367 173 442 minecraft:white_concrete
fill 333 174 433 333 174 434 minecraft:white_concrete
fill 333 174 437 333 174 441 minecraft:white_concrete
fill 334 174 430 334 174 433 minecraft:white_concrete
fill 334 174 437 335 175 440 minecraft:white_concrete
fill 334 174 443 338 174 444 minecraft:white_concrete
fill 335 174 428 335 174 432 minecraft:white_concrete
fill 335 174 445 336 174 446 minecraft:white_concrete
fill 336 174 427 336 174 431 minecraft:white_concrete
setblock 336 174 447 minecraft:white_concrete
fill 337 174 426 337 174 430 minecraft:white_concrete
fill 337 174 445 338 176 445 minecraft:white_concrete
fill 337 174 448 342 174 448 minecraft:white_concrete
fill 338 174 425 338 174 429 minecraft:white_concrete
fill 338 174 449 342 174 449 minecraft:white_concrete
fill 339 174 424 339 174 428 minecraft:white_concrete
fill 339 174 450 341 174 450 minecraft:white_concrete
fill 340 174 423 340 174 427 minecraft:white_concrete
fill 340 174 437 345 174 437 minecraft:white_concrete
setblock 340 174 451 minecraft:white_concrete
fill 341 174 436 346 174 436 minecraft:white_concrete
fill 342 174 422 342 174 425 minecraft:white_concrete
fill 342 174 435 346 174 435 minecraft:white_concrete
fill 343 174 434 347 174 434 minecraft:white_concrete
fill 343 174 442 347 174 442 minecraft:white_concrete
fill 343 174 453 346 174 453 minecraft:white_concrete
fill 344 174 421 344 174 423 minecraft:white_concrete
fill 344 174 433 347 174 433 minecraft:white_concrete
fill 344 174 441 347 174 441 minecraft:white_concrete
fill 345 174 421 345 175 422 minecraft:white_concrete
fill 345 174 432 349 174 432 minecraft:white_concrete
fill 345 174 440 346 174 440 minecraft:white_concrete
fill 346 174 437 347 174 438 minecraft:red_concrete
setblock 346 174 439 minecraft:white_concrete
setblock 347 174 420 minecraft:white_concrete
fill 347 174 435 347 174 436 minecraft:red_concrete
fill 347 174 439 347 174 440 minecraft:red_concrete
fill 347 174 454 352 174 454 minecraft:white_concrete
fill 348 174 433 348 174 435 minecraft:red_concrete
fill 348 174 440 348 174 442 minecraft:red_concrete
fill 349 174 420 354 174 420 minecraft:white_concrete
fill 349 174 433 349 174 434 minecraft:red_concrete
setblock 349 174 442 minecraft:red_concrete
fill 350 174 432 354 174 432 minecraft:red_concrete
fill 350 174 433 350 179 433 minecraft:white_concrete
fill 350 174 435 350 179 435 minecraft:white_concrete
fill 350 174 436 350 177 440 minecraft:red_concrete
fill 350 174 441 350 179 441 minecraft:white_concrete
fill 350 174 443 350 179 443 minecraft:white_concrete
fill 351 174 443 354 174 443 minecraft:red_concrete
fill 355 174 422 359 174 422 minecraft:white_concrete
fill 355 174 432 359 174 432 minecraft:white_concrete
fill 355 174 433 356 174 433 minecraft:red_concrete
fill 355 174 442 356 174 442 minecraft:red_concrete
fill 355 174 443 356 174 443 minecraft:white_concrete
fill 356 174 421 357 174 421 minecraft:white_concrete
setblock 356 174 434 minecraft:red_concrete
fill 356 174 453 357 174 453 minecraft:white_concrete
fill 357 174 433 357 174 434 minecraft:white_concrete
setblock 357 174 435 minecraft:red_concrete
fill 357 174 440 357 174 441 minecraft:red_concrete
setblock 357 174 442 minecraft:white_concrete
fill 357 174 452 359 174 452 minecraft:white_concrete
fill 358 174 433 358 175 433 minecraft:white_concrete
fill 358 174 435 362 174 435 minecraft:white_concrete
fill 358 174 436 358 174 437 minecraft:red_concrete
fill 358 174 439 358 175 439 minecraft:red_concrete
fill 358 174 440 358 174 441 minecraft:white_concrete
fill 358 174 451 360 174 451 minecraft:white_concrete
fill 359 174 426 363 174 426 minecraft:white_concrete
fill 359 174 436 362 174 437 minecraft:white_concrete
fill 359 174 439 359 175 440 minecraft:white_concrete
fill 359 174 450 361 174 450 minecraft:white_concrete
fill 360 174 425 362 174 425 minecraft:white_concrete
fill 360 174 449 362 174 449 minecraft:white_concrete
setblock 361 174 424 minecraft:white_concrete
fill 361 174 432 366 175 432 minecraft:white_concrete
fill 361 174 448 363 174 448 minecraft:white_concrete
fill 362 174 431 366 174 431 minecraft:white_concrete
fill 362 174 439 367 174 439 minecraft:white_concrete
fill 362 174 447 364 174 447 minecraft:white_concrete
fill 363 174 438 367 174 438 minecraft:white_concrete
fill 364 174 429 365 174 429 minecraft:white_concrete
fill 364 174 437 367 174 437 minecraft:white_concrete
fill 364 174 445 365 174 445 minecraft:white_concrete
fill 365 174 436 367 174 436 minecraft:white_concrete
fill 366 174 435 367 174 435 minecraft:white_concrete
setblock 366 174 443 minecraft:white_concrete
setblock 367 174 434 minecraft:white_concrete
fill 334 175 432 334 175 433 minecraft:white_concrete
fill 334 175 436 339 175 436 minecraft:white_concrete
fill 335 175 430 335 175 432 minecraft:white_concrete
fill 335 175 443 338 175 444 minecraft:white_concrete
fill 336 175 428 336 175 431 minecraft:white_concrete
fill 336 175 445 336 175 446 minecraft:white_concrete
fill 337 175 427 337 175 430 minecraft:white_concrete
fill 338 175 426 338 175 429 minecraft:white_concrete
fill 338 175 448 342 175 448 minecraft:white_concrete
fill 339 175 425 339 175 428 minecraft:white_concrete
fill 339 175 438 344 175 438 minecraft:white_concrete
fill 339 175 449 342 175 449 minecraft:white_concrete
fill 340 175 424 340 175 427 minecraft:white_concrete
fill 340 175 437 344 175 437 minecraft:white_concrete
fill 340 175 450 341 175 450 minecraft:white_concrete
fill 341 175 423 341 175 426 minecraft:white_concrete
fill 341 175 436 344 175 436 minecraft:white_concrete
fill 342 175 423 342 175 425 minecraft:white_concrete
fill 342 175 435 344 175 435 minecraft:white_concrete
fill 342 175 443 346 175 443 minecraft:white_concrete
fill 343 175 422 343 175 424 minecraft:white_concrete
fill 343 175 434 345 175 434 minecraft:white_concrete
fill 343 175 442 345 175 442 minecraft:white_concrete
fill 343 175 452 347 175 452 minecraft:white_concrete
fill 344 175 422 344 175 423 minecraft:white_concrete
fill 344 175 433 345 175 433 minecraft:white_concrete
fill 344 175 441 345 175 441 minecraft:white_concrete
fill 345 175 432 346 175 432 minecraft:white_concrete
fill 345 175 435 345 175 440 minecraft:red_concrete
fill 345 175 453 346 175 453 minecraft:white_concrete
setblock 346 175 421 minecraft:white_concrete
fill 346 175 431 348 175 431 minecraft:white_concrete
fill 346 175 433 346 175 436 minecraft:red_concrete
fill 346 175 439 346 175 442 minecraft:red_concrete
fill 347 175 432 347 175 434 minecraft:red_concrete
fill 347 175 441 347 175 443 minecraft:red_concrete
fill 348 175 432 349 175 432 minecraft:red_concrete
fill 348 175 443 349 175 443 minecraft:red_concrete
fill 349 175 431 354 175 431 minecraft:red_concrete
fill 349 175 444 354 175 444 minecraft:red_concrete
fill 354 175 423 359 175 423 minecraft:white_concrete
fill 355 175 422 357 175 422 minecraft:white_concrete
fill 355 175 431 360 175 431 minecraft:white_concrete
fill 355 175 432 356 175 432 minecraft:red_concrete
fill 355 175 443 356 175 443 minecraft:red_concrete
setblock 355 175 444 minecraft:white_concrete
fill 357 175 432 359 175 432 minecraft:white_concrete
fill 357 175 433 357 175 434 minecraft:red_concrete
fill 357 175 441 357 175 442 minecraft:red_concrete
setblock 357 175 452 minecraft:white_concrete
fill 358 175 427 363 175 427 minecraft:white_concrete
fill 358 175 435 358 175 436 minecraft:red_concrete
setblock 358 175 440 minecraft:red_concrete
setblock 358 175 441 minecraft:white_concrete
fill 358 175 451 359 175 451 minecraft:white_concrete
fill 359 175 426 362 175 426 minecraft:white_concrete
fill 359 175 435 362 175 436 minecraft:white_concrete
fill 359 175 437 359 176 438 minecraft:red_concrete
fill 359 175 450 360 175 450 minecraft:white_concrete
fill 360 175 425 361 175 425 minecraft:white_concrete
fill 360 175 437 361 176 438 minecraft:white_concrete
fill 360 175 449 361 175 449 minecraft:white_concrete
fill 361 175 440 366 175 440 minecraft:white_concrete
fill 361 175 448 362 175 448 minecraft:white_concrete
fill 362 175 431 365 175 431 minecraft:white_concrete
fill 362 175 437 362 178 437 minecraft:white_concrete
fill 362 175 439 366 175 439 minecraft:white_concrete
fill 362 175 447 363 175 447 minecraft:white_concrete
fill 363 175 430 365 175 430 minecraft:white_concrete
fill 363 175 438 366 175 438 minecraft:white_concrete
fill 363 175 446 364 175 446 minecraft:white_concrete
setblock 364 175 429 minecraft:white_concrete
fill 364 175 437 366 175 437 minecraft:white_concrete
setblock 364 175 445 minecraft:white_concrete
fill 365 175 436 366 175 436 minecraft:white_concrete
setblock 365 175 444 minecraft:white_concrete
schedule function dropper:buildpart/103_3 1t
