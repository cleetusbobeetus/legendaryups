fill 94 258 307 94 259 308 minecraft:white_concrete
fill 94 258 309 94 259 310 minecraft:red_concrete
fill 94 258 311 94 259 311 minecraft:white_concrete
fill 94 258 313 94 259 314 minecraft:red_concrete
fill 94 258 315 94 259 316 minecraft:white_concrete
fill 95 258 275 95 259 275 minecraft:white_concrete
fill 95 258 317 95 259 317 minecraft:white_concrete
fill 96 258 275 97 259 275 minecraft:red_concrete
fill 96 258 317 96 259 317 minecraft:red_concrete
setblock 97 258 278 minecraft:light[level=15]
setblock 97 258 286 minecraft:light[level=15]
setblock 97 258 294 minecraft:light[level=15]
setblock 97 258 302 minecraft:light[level=15]
setblock 97 258 310 minecraft:light[level=15]
fill 98 258 275 99 259 275 minecraft:white_concrete
fill 98 258 317 99 259 317 minecraft:white_concrete
fill 100 258 275 100 259 275 minecraft:red_concrete
fill 100 258 317 101 259 317 minecraft:red_concrete
fill 102 258 275 103 259 275 minecraft:white_concrete
fill 102 258 317 103 259 317 minecraft:white_concrete
fill 104 258 275 105 259 275 minecraft:red_concrete
fill 104 258 317 104 259 317 minecraft:red_concrete
setblock 105 258 278 minecraft:light[level=15]
setblock 105 258 286 minecraft:light[level=15]
setblock 105 258 294 minecraft:light[level=15]
setblock 105 258 302 minecraft:light[level=15]
setblock 105 258 310 minecraft:light[level=15]
fill 106 258 275 107 259 275 minecraft:white_concrete
fill 106 258 317 107 259 317 minecraft:white_concrete
fill 108 258 275 108 259 275 minecraft:red_concrete
fill 108 258 317 109 259 317 minecraft:red_concrete
fill 110 258 275 111 259 275 minecraft:white_concrete
setblock 110 258 278 minecraft:iron_block
fill 110 258 317 111 259 317 minecraft:white_concrete
setblock 111 258 277 minecraft:iron_block
fill 111 258 278 113 258 278 minecraft:black_concrete
setblock 111 258 279 minecraft:iron_block
fill 112 258 275 113 259 275 minecraft:red_concrete
setblock 112 258 276 minecraft:iron_block
setblock 112 258 277 minecraft:black_concrete
setblock 112 258 279 minecraft:black_concrete
setblock 112 258 280 minecraft:iron_block
fill 112 258 317 112 259 317 minecraft:red_concrete
fill 113 258 276 113 272 276 minecraft:red_terracotta
setblock 113 258 277 minecraft:iron_block
setblock 113 258 279 minecraft:iron_block
setblock 113 258 286 minecraft:light[level=15]
setblock 113 258 294 minecraft:light[level=15]
setblock 113 258 302 minecraft:light[level=15]
setblock 113 258 310 minecraft:light[level=15]
fill 114 258 275 115 259 275 minecraft:white_concrete
setblock 114 258 278 minecraft:iron_block
fill 114 258 317 115 259 317 minecraft:white_concrete
fill 116 258 275 116 259 275 minecraft:red_concrete
fill 116 258 317 117 259 317 minecraft:red_concrete
fill 118 258 275 119 259 275 minecraft:white_concrete
fill 118 258 317 119 259 317 minecraft:white_concrete
fill 120 258 275 121 259 275 minecraft:red_concrete
fill 120 258 317 120 259 317 minecraft:red_concrete
setblock 121 258 278 minecraft:light[level=15]
setblock 121 258 286 minecraft:light[level=15]
setblock 121 258 294 minecraft:light[level=15]
setblock 121 258 302 minecraft:light[level=15]
setblock 121 258 310 minecraft:light[level=15]
fill 122 258 275 123 259 275 minecraft:white_concrete
fill 122 258 317 123 259 317 minecraft:white_concrete
fill 124 258 275 124 259 275 minecraft:red_concrete
fill 124 258 317 125 259 317 minecraft:red_concrete
fill 126 258 275 127 259 275 minecraft:white_concrete
fill 126 258 317 127 259 317 minecraft:white_concrete
fill 128 258 275 129 259 275 minecraft:red_concrete
fill 128 258 317 128 259 317 minecraft:red_concrete
setblock 129 258 278 minecraft:light[level=15]
setblock 129 258 286 minecraft:light[level=15]
setblock 129 258 294 minecraft:light[level=15]
setblock 129 258 302 minecraft:light[level=15]
setblock 129 258 310 minecraft:light[level=15]
fill 130 258 275 131 259 275 minecraft:white_concrete
fill 130 258 317 131 259 317 minecraft:white_concrete
fill 131 258 294 131 258 302 minecraft:yellow_concrete
fill 132 258 275 132 259 275 minecraft:red_concrete
fill 132 258 317 133 259 317 minecraft:red_concrete
fill 134 258 275 135 259 275 minecraft:white_concrete
fill 134 258 317 135 259 317 minecraft:white_concrete
fill 135 258 297 135 261 299 minecraft:shroomlight
fill 136 258 276 136 259 276 minecraft:white_concrete
fill 136 258 277 136 259 278 minecraft:red_concrete
fill 136 258 279 136 259 279 minecraft:white_concrete
fill 136 258 281 136 259 282 minecraft:red_concrete
fill 136 258 283 136 259 284 minecraft:white_concrete
fill 136 258 285 136 259 286 minecraft:red_concrete
fill 136 258 287 136 259 287 minecraft:white_concrete
fill 136 258 289 136 259 290 minecraft:red_concrete
fill 136 258 291 136 259 292 minecraft:white_concrete
fill 136 258 293 136 259 294 minecraft:red_concrete
fill 136 258 295 136 259 295 minecraft:white_concrete
fill 136 258 297 136 259 298 minecraft:red_concrete
fill 136 258 299 136 259 300 minecraft:white_concrete
fill 136 258 301 136 259 302 minecraft:red_concrete
fill 136 258 303 136 259 303 minecraft:white_concrete
fill 136 258 305 136 259 306 minecraft:red_concrete
fill 136 258 307 136 259 308 minecraft:white_concrete
fill 136 258 309 136 259 310 minecraft:red_concrete
fill 136 258 311 136 259 311 minecraft:white_concrete
fill 136 258 313 136 259 314 minecraft:red_concrete
fill 136 258 315 136 259 316 minecraft:white_concrete
fill 136 258 317 136 259 317 minecraft:red_concrete
fill 112 259 276 112 272 276 minecraft:red_terracotta
setblock 131 259 294 minecraft:red_terracotta
setblock 131 259 298 minecraft:red_terracotta
setblock 131 259 302 minecraft:red_terracotta
fill 94 260 275 94 261 276 minecraft:red_concrete
fill 94 260 277 94 261 278 minecraft:white_concrete
fill 94 260 279 94 261 279 minecraft:red_concrete
fill 94 260 281 94 261 282 minecraft:white_concrete
fill 94 260 283 94 261 284 minecraft:red_concrete
fill 94 260 285 94 261 286 minecraft:white_concrete
fill 94 260 287 94 261 287 minecraft:red_concrete
fill 94 260 289 94 261 290 minecraft:white_concrete
fill 94 260 291 94 261 292 minecraft:red_concrete
fill 94 260 293 94 261 294 minecraft:white_concrete
fill 94 260 295 94 261 295 minecraft:red_concrete
fill 94 260 297 94 261 298 minecraft:white_concrete
fill 94 260 299 94 261 300 minecraft:red_concrete
fill 94 260 301 94 261 302 minecraft:white_concrete
fill 94 260 303 94 261 303 minecraft:red_concrete
fill 94 260 305 94 261 306 minecraft:white_concrete
fill 94 260 307 94 261 308 minecraft:red_concrete
fill 94 260 309 94 261 310 minecraft:white_concrete
fill 94 260 311 94 261 311 minecraft:red_concrete
fill 94 260 313 94 261 314 minecraft:white_concrete
fill 94 260 315 94 261 316 minecraft:red_concrete
fill 95 260 275 95 261 275 minecraft:red_concrete
fill 95 260 317 95 261 317 minecraft:red_concrete
fill 96 260 275 97 261 275 minecraft:white_concrete
fill 96 260 317 96 261 317 minecraft:white_concrete
setblock 97 260 278 minecraft:light[level=12]
setblock 97 260 285 minecraft:light[level=12]
setblock 97 260 292 minecraft:light[level=12]
setblock 97 260 299 minecraft:light[level=12]
setblock 97 260 306 minecraft:light[level=12]
setblock 97 260 313 minecraft:light[level=12]
fill 98 260 275 99 261 275 minecraft:red_concrete
fill 98 260 317 99 261 317 minecraft:red_concrete
fill 100 260 275 100 261 275 minecraft:white_concrete
fill 100 260 317 101 261 317 minecraft:white_concrete
fill 102 260 275 103 261 275 minecraft:red_concrete
fill 102 260 317 103 261 317 minecraft:red_concrete
fill 104 260 275 105 261 275 minecraft:white_concrete
setblock 104 260 278 minecraft:light[level=12]
setblock 104 260 285 minecraft:light[level=12]
setblock 104 260 292 minecraft:light[level=12]
setblock 104 260 299 minecraft:light[level=12]
setblock 104 260 306 minecraft:light[level=12]
setblock 104 260 313 minecraft:light[level=12]
fill 104 260 317 104 261 317 minecraft:white_concrete
fill 106 260 275 107 261 275 minecraft:red_concrete
fill 106 260 317 107 261 317 minecraft:red_concrete
fill 108 260 275 108 261 275 minecraft:white_concrete
fill 108 260 317 109 261 317 minecraft:white_concrete
fill 110 260 275 111 261 275 minecraft:red_concrete
fill 110 260 317 111 261 317 minecraft:red_concrete
setblock 111 260 278 minecraft:light[level=12]
setblock 111 260 285 minecraft:light[level=12]
setblock 111 260 292 minecraft:light[level=12]
setblock 111 260 299 minecraft:light[level=12]
setblock 111 260 306 minecraft:light[level=12]
setblock 111 260 313 minecraft:light[level=12]
fill 112 260 275 113 261 275 minecraft:white_concrete
fill 112 260 317 112 261 317 minecraft:white_concrete
fill 114 260 275 115 261 275 minecraft:red_concrete
fill 114 260 317 115 261 317 minecraft:red_concrete
fill 116 260 275 116 261 275 minecraft:white_concrete
fill 116 260 317 117 261 317 minecraft:white_concrete
fill 118 260 275 119 261 275 minecraft:red_concrete
setblock 118 260 278 minecraft:light[level=12]
setblock 118 260 285 minecraft:light[level=12]
setblock 118 260 292 minecraft:light[level=12]
setblock 118 260 299 minecraft:light[level=12]
setblock 118 260 306 minecraft:light[level=12]
setblock 118 260 313 minecraft:light[level=12]
fill 118 260 317 119 261 317 minecraft:red_concrete
fill 119 260 296 119 272 296 minecraft:red_terracotta
fill 120 260 275 121 261 275 minecraft:white_concrete
fill 120 260 317 120 261 317 minecraft:white_concrete
fill 122 260 275 123 261 275 minecraft:red_concrete
fill 122 260 317 123 261 317 minecraft:red_concrete
fill 124 260 275 124 261 275 minecraft:white_concrete
fill 124 260 317 125 261 317 minecraft:white_concrete
setblock 125 260 278 minecraft:light[level=12]
setblock 125 260 285 minecraft:light[level=12]
setblock 125 260 292 minecraft:light[level=12]
setblock 125 260 299 minecraft:light[level=12]
setblock 125 260 306 minecraft:light[level=12]
setblock 125 260 313 minecraft:light[level=12]
fill 126 260 275 127 261 275 minecraft:red_concrete
fill 126 260 317 127 261 317 minecraft:red_concrete
fill 128 260 275 129 261 275 minecraft:white_concrete
fill 128 260 317 128 261 317 minecraft:white_concrete
fill 130 260 275 131 261 275 minecraft:red_concrete
fill 130 260 317 131 261 317 minecraft:red_concrete
fill 132 260 275 132 261 275 minecraft:white_concrete
setblock 132 260 278 minecraft:light[level=12]
setblock 132 260 285 minecraft:light[level=12]
setblock 132 260 292 minecraft:light[level=12]
setblock 132 260 299 minecraft:light[level=12]
setblock 132 260 306 minecraft:light[level=12]
setblock 132 260 313 minecraft:light[level=12]
fill 132 260 317 133 261 317 minecraft:white_concrete
fill 134 260 275 135 261 275 minecraft:red_concrete
fill 134 260 317 135 261 317 minecraft:red_concrete
fill 136 260 276 136 261 276 minecraft:red_concrete
fill 136 260 277 136 261 278 minecraft:white_concrete
fill 136 260 279 136 261 279 minecraft:red_concrete
fill 136 260 281 136 261 282 minecraft:white_concrete
fill 136 260 283 136 261 284 minecraft:red_concrete
fill 136 260 285 136 261 286 minecraft:white_concrete
fill 136 260 287 136 261 287 minecraft:red_concrete
fill 136 260 289 136 261 290 minecraft:white_concrete
fill 136 260 291 136 261 292 minecraft:red_concrete
fill 136 260 293 136 261 294 minecraft:white_concrete
fill 136 260 295 136 261 295 minecraft:red_concrete
fill 136 260 297 136 261 298 minecraft:white_concrete
fill 136 260 299 136 261 300 minecraft:red_concrete
fill 136 260 301 136 261 302 minecraft:white_concrete
fill 136 260 303 136 261 303 minecraft:red_concrete
fill 136 260 305 136 261 306 minecraft:white_concrete
fill 136 260 307 136 261 308 minecraft:red_concrete
fill 136 260 309 136 261 310 minecraft:white_concrete
fill 136 260 311 136 261 311 minecraft:red_concrete
fill 136 260 313 136 261 314 minecraft:white_concrete
fill 136 260 315 136 261 316 minecraft:red_concrete
fill 136 260 317 136 261 317 minecraft:white_concrete
fill 95 261 304 101 261 304 minecraft:brown_terracotta
fill 97 261 302 101 262 303 minecraft:brown_terracotta
fill 97 261 305 101 262 306 minecraft:brown_terracotta
fill 119 261 295 119 272 295 minecraft:red_terracotta
fill 94 262 275 94 263 276 minecraft:white_concrete
fill 94 262 277 94 263 278 minecraft:red_concrete
fill 94 262 279 94 263 280 minecraft:white_concrete
fill 94 262 281 94 263 282 minecraft:red_concrete
fill 94 262 283 94 263 284 minecraft:white_concrete
fill 94 262 285 94 263 286 minecraft:red_concrete
fill 94 262 287 94 263 288 minecraft:white_concrete
fill 94 262 289 94 263 290 minecraft:red_concrete
fill 94 262 291 94 263 292 minecraft:white_concrete
fill 94 262 293 94 263 294 minecraft:red_concrete
fill 94 262 295 94 263 296 minecraft:white_concrete
fill 94 262 297 94 263 298 minecraft:red_concrete
fill 94 262 299 94 263 300 minecraft:white_concrete
fill 94 262 301 94 263 302 minecraft:red_concrete
fill 94 262 303 94 263 304 minecraft:white_concrete
fill 94 262 305 94 263 306 minecraft:red_concrete
fill 94 262 307 94 263 308 minecraft:white_concrete
fill 94 262 309 94 263 310 minecraft:red_concrete
fill 94 262 311 94 263 312 minecraft:white_concrete
fill 94 262 313 94 263 314 minecraft:red_concrete
fill 94 262 315 94 263 316 minecraft:white_concrete
fill 95 262 275 95 263 275 minecraft:white_concrete
fill 95 262 317 95 263 317 minecraft:white_concrete
fill 96 262 275 97 263 275 minecraft:red_concrete
fill 96 262 317 97 263 317 minecraft:red_concrete
fill 97 262 304 101 262 304 minecraft:brown_terracotta
fill 98 262 275 99 263 275 minecraft:white_concrete
fill 98 262 317 99 263 317 minecraft:white_concrete
fill 100 262 275 101 263 275 minecraft:red_concrete
fill 100 262 317 101 263 317 minecraft:red_concrete
fill 102 262 275 103 263 275 minecraft:white_concrete
fill 102 262 317 103 263 317 minecraft:white_concrete
fill 104 262 275 105 263 275 minecraft:red_concrete
fill 104 262 317 105 263 317 minecraft:red_concrete
fill 106 262 275 107 263 275 minecraft:white_concrete
fill 106 262 317 107 263 317 minecraft:white_concrete
fill 108 262 275 109 263 275 minecraft:red_concrete
fill 108 262 317 109 263 317 minecraft:red_concrete
fill 110 262 275 111 263 275 minecraft:white_concrete
fill 110 262 317 111 263 317 minecraft:white_concrete
fill 112 262 275 113 263 275 minecraft:red_concrete
fill 112 262 317 113 263 317 minecraft:red_concrete
fill 114 262 275 115 263 275 minecraft:white_concrete
fill 114 262 317 115 263 317 minecraft:white_concrete
fill 116 262 275 117 263 275 minecraft:red_concrete
fill 116 262 317 117 263 317 minecraft:red_concrete
fill 118 262 275 119 263 275 minecraft:white_concrete
fill 118 262 317 119 263 317 minecraft:white_concrete
fill 120 262 275 121 263 275 minecraft:red_concrete
fill 120 262 317 121 263 317 minecraft:red_concrete
fill 122 262 275 123 263 275 minecraft:white_concrete
fill 122 262 317 123 263 317 minecraft:white_concrete
fill 124 262 275 125 263 275 minecraft:red_concrete
fill 124 262 317 125 263 317 minecraft:red_concrete
fill 126 262 275 127 263 275 minecraft:white_concrete
fill 126 262 317 127 263 317 minecraft:white_concrete
fill 128 262 275 129 263 275 minecraft:red_concrete
fill 128 262 317 129 263 317 minecraft:red_concrete
fill 130 262 275 131 263 275 minecraft:white_concrete
fill 130 262 317 131 263 317 minecraft:white_concrete
setblock 131 262 302 minecraft:iron_block
fill 132 262 275 133 263 275 minecraft:red_concrete
setblock 132 262 301 minecraft:iron_block
fill 132 262 302 134 262 302 minecraft:black_concrete
setblock 132 262 303 minecraft:iron_block
fill 132 262 317 133 263 317 minecraft:red_concrete
setblock 133 262 300 minecraft:iron_block
setblock 133 262 301 minecraft:black_concrete
setblock 133 262 303 minecraft:black_concrete
setblock 133 262 304 minecraft:iron_block
fill 134 262 275 135 263 275 minecraft:white_concrete
setblock 134 262 301 minecraft:iron_block
setblock 134 262 303 minecraft:iron_block
fill 134 262 317 135 263 317 minecraft:white_concrete
fill 135 262 301 135 272 301 minecraft:red_terracotta
setblock 135 262 302 minecraft:iron_block
fill 136 262 276 136 263 276 minecraft:white_concrete
fill 136 262 277 136 263 278 minecraft:red_concrete
fill 136 262 279 136 263 280 minecraft:white_concrete
fill 136 262 281 136 263 282 minecraft:red_concrete
fill 136 262 283 136 263 284 minecraft:white_concrete
fill 136 262 285 136 263 286 minecraft:red_concrete
fill 136 262 287 136 263 288 minecraft:white_concrete
fill 136 262 289 136 263 290 minecraft:red_concrete
fill 136 262 291 136 263 292 minecraft:white_concrete
fill 136 262 293 136 263 294 minecraft:red_concrete
fill 136 262 295 136 263 296 minecraft:white_concrete
fill 136 262 297 136 263 298 minecraft:red_concrete
fill 136 262 299 136 263 300 minecraft:white_concrete
fill 136 262 301 136 263 302 minecraft:red_concrete
fill 136 262 303 136 263 304 minecraft:white_concrete
fill 136 262 305 136 263 306 minecraft:red_concrete
fill 136 262 307 136 263 308 minecraft:white_concrete
fill 136 262 309 136 263 310 minecraft:red_concrete
fill 136 262 311 136 263 312 minecraft:white_concrete
fill 136 262 313 136 263 314 minecraft:red_concrete
fill 136 262 315 136 263 316 minecraft:white_concrete
fill 136 262 317 136 263 317 minecraft:red_concrete
fill 99 263 304 99 266 304 minecraft:red_terracotta
fill 135 263 302 135 272 302 minecraft:red_terracotta
fill 94 264 275 94 265 276 minecraft:red_concrete
fill 94 264 277 94 265 278 minecraft:white_concrete
fill 94 264 279 94 265 280 minecraft:red_concrete
fill 94 264 281 94 265 282 minecraft:white_concrete
fill 94 264 283 94 265 284 minecraft:red_concrete
fill 94 264 285 94 265 286 minecraft:white_concrete
fill 94 264 287 94 265 288 minecraft:red_concrete
fill 94 264 289 94 265 290 minecraft:white_concrete
fill 94 264 291 94 265 292 minecraft:red_concrete
fill 94 264 293 94 265 294 minecraft:white_concrete
fill 94 264 295 94 265 296 minecraft:red_concrete
fill 94 264 297 94 265 298 minecraft:white_concrete
fill 94 264 299 94 265 300 minecraft:red_concrete
fill 94 264 301 94 265 302 minecraft:white_concrete
fill 94 264 303 94 265 304 minecraft:red_concrete
fill 94 264 305 94 265 306 minecraft:white_concrete
fill 94 264 307 94 265 308 minecraft:red_concrete
fill 94 264 309 94 265 310 minecraft:white_concrete
fill 94 264 311 94 265 312 minecraft:red_concrete
fill 94 264 313 94 265 314 minecraft:white_concrete
fill 94 264 315 94 265 316 minecraft:red_concrete
fill 95 264 275 95 265 275 minecraft:red_concrete
fill 95 264 317 95 265 317 minecraft:red_concrete
fill 96 264 275 97 265 275 minecraft:white_concrete
fill 96 264 317 97 265 317 minecraft:white_concrete
fill 98 264 275 99 265 275 minecraft:red_concrete
fill 98 264 317 99 265 317 minecraft:red_concrete
fill 100 264 275 101 265 275 minecraft:white_concrete
fill 100 264 317 101 265 317 minecraft:white_concrete
fill 102 264 275 103 265 275 minecraft:red_concrete
fill 102 264 317 103 265 317 minecraft:red_concrete
fill 104 264 275 105 265 275 minecraft:white_concrete
fill 104 264 317 105 265 317 minecraft:white_concrete
fill 106 264 275 107 265 275 minecraft:red_concrete
fill 106 264 317 107 265 317 minecraft:red_concrete
fill 108 264 275 109 265 275 minecraft:white_concrete
fill 108 264 317 109 265 317 minecraft:white_concrete
fill 110 264 275 111 265 275 minecraft:red_concrete
fill 110 264 317 111 265 317 minecraft:red_concrete
fill 112 264 275 113 265 275 minecraft:white_concrete
fill 112 264 317 113 265 317 minecraft:white_concrete
fill 114 264 275 115 265 275 minecraft:red_concrete
fill 114 264 317 115 265 317 minecraft:red_concrete
fill 116 264 275 117 265 275 minecraft:white_concrete
fill 116 264 317 117 265 317 minecraft:white_concrete
fill 118 264 275 119 265 275 minecraft:red_concrete
fill 118 264 317 119 265 317 minecraft:red_concrete
fill 120 264 275 121 265 275 minecraft:white_concrete
fill 120 264 317 121 265 317 minecraft:white_concrete
fill 122 264 275 123 265 275 minecraft:red_concrete
fill 122 264 317 123 265 317 minecraft:red_concrete
fill 124 264 275 125 265 275 minecraft:white_concrete
fill 124 264 317 125 265 317 minecraft:white_concrete
fill 126 264 275 127 265 275 minecraft:red_concrete
fill 126 264 317 127 265 317 minecraft:red_concrete
fill 128 264 275 129 265 275 minecraft:white_concrete
fill 128 264 317 129 265 317 minecraft:white_concrete
fill 130 264 275 131 265 275 minecraft:red_concrete
fill 130 264 317 131 265 317 minecraft:red_concrete
fill 132 264 275 133 265 275 minecraft:white_concrete
fill 132 264 317 133 265 317 minecraft:white_concrete
fill 134 264 275 135 265 275 minecraft:red_concrete
fill 134 264 317 135 265 317 minecraft:red_concrete
fill 136 264 276 136 265 276 minecraft:red_concrete
fill 136 264 277 136 265 278 minecraft:white_concrete
fill 136 264 279 136 265 280 minecraft:red_concrete
fill 136 264 281 136 265 282 minecraft:white_concrete
fill 136 264 283 136 265 284 minecraft:red_concrete
fill 136 264 285 136 265 286 minecraft:white_concrete
fill 136 264 287 136 265 288 minecraft:red_concrete
fill 136 264 289 136 265 290 minecraft:white_concrete
fill 136 264 291 136 265 292 minecraft:red_concrete
fill 136 264 293 136 265 294 minecraft:white_concrete
fill 136 264 295 136 265 296 minecraft:red_concrete
fill 136 264 297 136 265 298 minecraft:white_concrete
fill 136 264 299 136 265 300 minecraft:red_concrete
fill 136 264 301 136 265 302 minecraft:white_concrete
fill 136 264 303 136 265 304 minecraft:red_concrete
fill 136 264 305 136 265 306 minecraft:white_concrete
fill 136 264 307 136 265 308 minecraft:red_concrete
fill 136 264 309 136 265 310 minecraft:white_concrete
fill 136 264 311 136 265 312 minecraft:red_concrete
fill 136 264 313 136 265 314 minecraft:white_concrete
fill 136 264 315 136 265 316 minecraft:red_concrete
fill 136 264 317 136 265 317 minecraft:white_concrete
fill 109 265 284 109 266 284 minecraft:yellow_wool
fill 94 266 275 94 267 276 minecraft:white_concrete
fill 94 266 277 94 267 278 minecraft:red_concrete
fill 94 266 279 94 267 280 minecraft:white_concrete
fill 94 266 281 94 267 282 minecraft:red_concrete
fill 94 266 283 94 267 284 minecraft:white_concrete
fill 94 266 285 94 267 286 minecraft:red_concrete
fill 94 266 287 94 267 288 minecraft:white_concrete
fill 94 266 289 94 267 290 minecraft:red_concrete
fill 94 266 291 94 267 292 minecraft:white_concrete
fill 94 266 293 94 267 294 minecraft:red_concrete
fill 94 266 295 94 267 296 minecraft:white_concrete
fill 94 266 297 94 267 298 minecraft:red_concrete
fill 94 266 299 94 267 300 minecraft:white_concrete
fill 94 266 301 94 267 302 minecraft:red_concrete
fill 94 266 303 94 267 304 minecraft:white_concrete
fill 94 266 305 94 267 306 minecraft:red_concrete
fill 94 266 307 94 267 308 minecraft:white_concrete
fill 94 266 309 94 267 310 minecraft:red_concrete
fill 94 266 311 94 267 312 minecraft:white_concrete
fill 94 266 313 94 267 314 minecraft:red_concrete
fill 94 266 315 94 267 316 minecraft:white_concrete
fill 95 266 275 95 267 275 minecraft:white_concrete
fill 95 266 276 95 267 281 minecraft:red_terracotta
fill 95 266 284 96 266 289 minecraft:red_terracotta
fill 95 266 292 96 266 297 minecraft:red_terracotta
fill 95 266 300 96 266 305 minecraft:red_terracotta
fill 95 266 308 96 266 313 minecraft:red_terracotta
fill 95 266 316 100 267 316 minecraft:red_terracotta
fill 95 266 317 95 267 317 minecraft:white_concrete
fill 96 266 275 97 267 275 minecraft:red_concrete
fill 96 266 277 96 266 283 minecraft:red_terracotta
fill 96 266 290 96 266 291 minecraft:red_terracotta
fill 96 266 298 96 266 299 minecraft:red_terracotta
fill 96 266 306 96 266 307 minecraft:red_terracotta
fill 96 266 314 96 266 315 minecraft:red_terracotta
fill 96 266 317 97 267 317 minecraft:red_concrete
fill 97 266 277 134 266 277 minecraft:red_terracotta
setblock 97 266 278 minecraft:light[level=15]
setblock 97 266 285 minecraft:light[level=12]
setblock 97 266 286 minecraft:light[level=15]
setblock 97 266 292 minecraft:light[level=12]
setblock 97 266 294 minecraft:light[level=15]
setblock 97 266 299 minecraft:light[level=12]
setblock 97 266 302 minecraft:light[level=15]
setblock 97 266 306 minecraft:light[level=12]
setblock 97 266 310 minecraft:light[level=15]
setblock 97 266 313 minecraft:light[level=12]
fill 97 266 315 135 266 315 minecraft:red_terracotta
fill 98 266 275 99 267 275 minecraft:white_concrete
fill 98 266 276 103 267 276 minecraft:red_terracotta
fill 98 266 317 99 267 317 minecraft:white_concrete
fill 100 266 275 101 267 275 minecraft:red_concrete
fill 100 266 317 101 267 317 minecraft:red_concrete
fill 102 266 275 103 267 275 minecraft:white_concrete
fill 102 266 317 103 267 317 minecraft:white_concrete
fill 103 266 316 108 267 316 minecraft:red_terracotta
fill 104 266 275 105 267 275 minecraft:red_concrete
setblock 104 266 278 minecraft:light[level=12]
setblock 104 266 285 minecraft:light[level=12]
setblock 104 266 292 minecraft:light[level=12]
setblock 104 266 299 minecraft:light[level=12]
setblock 104 266 306 minecraft:light[level=12]
setblock 104 266 313 minecraft:light[level=12]
fill 104 266 317 105 267 317 minecraft:red_concrete
setblock 105 266 278 minecraft:light[level=15]
setblock 105 266 286 minecraft:light[level=15]
setblock 105 266 294 minecraft:light[level=15]
setblock 105 266 302 minecraft:light[level=15]
setblock 105 266 310 minecraft:light[level=15]
fill 106 266 275 107 267 275 minecraft:white_concrete
fill 106 266 276 111 267 276 minecraft:red_terracotta
fill 106 266 317 107 267 317 minecraft:white_concrete
fill 108 266 275 109 267 275 minecraft:red_concrete
fill 108 266 317 109 267 317 minecraft:red_concrete
fill 110 266 275 111 267 275 minecraft:white_concrete
fill 110 266 317 111 267 317 minecraft:white_concrete
setblock 111 266 278 minecraft:light[level=12]
setblock 111 266 285 minecraft:light[level=12]
setblock 111 266 292 minecraft:light[level=12]
setblock 111 266 299 minecraft:light[level=12]
setblock 111 266 306 minecraft:light[level=12]
setblock 111 266 313 minecraft:light[level=12]
fill 111 266 316 116 267 316 minecraft:red_terracotta
fill 112 266 275 113 267 275 minecraft:red_concrete
fill 112 266 317 113 267 317 minecraft:red_concrete
setblock 113 266 278 minecraft:light[level=15]
setblock 113 266 286 minecraft:light[level=15]
setblock 113 266 294 minecraft:light[level=15]
setblock 113 266 302 minecraft:light[level=15]
setblock 113 266 310 minecraft:light[level=15]
fill 114 266 275 115 267 275 minecraft:white_concrete
fill 114 266 276 119 267 276 minecraft:red_terracotta
fill 114 266 317 115 267 317 minecraft:white_concrete
fill 116 266 275 117 267 275 minecraft:red_concrete
fill 116 266 317 117 267 317 minecraft:red_concrete
fill 118 266 275 119 267 275 minecraft:white_concrete
setblock 118 266 278 minecraft:light[level=12]
setblock 118 266 285 minecraft:light[level=12]
setblock 118 266 292 minecraft:light[level=12]
setblock 118 266 299 minecraft:light[level=12]
setblock 118 266 306 minecraft:light[level=12]
setblock 118 266 313 minecraft:light[level=12]
fill 118 266 317 119 267 317 minecraft:white_concrete
fill 119 266 316 124 267 316 minecraft:red_terracotta
fill 120 266 275 121 267 275 minecraft:red_concrete
fill 120 266 317 121 267 317 minecraft:red_concrete
setblock 121 266 278 minecraft:light[level=15]
setblock 121 266 286 minecraft:light[level=15]
setblock 121 266 294 minecraft:light[level=15]
setblock 121 266 302 minecraft:light[level=15]
setblock 121 266 310 minecraft:light[level=15]
fill 122 266 275 123 267 275 minecraft:white_concrete
fill 122 266 276 127 267 276 minecraft:red_terracotta
fill 122 266 317 123 267 317 minecraft:white_concrete
fill 124 266 275 125 267 275 minecraft:red_concrete
fill 124 266 317 125 267 317 minecraft:red_concrete
setblock 125 266 278 minecraft:light[level=12]
setblock 125 266 285 minecraft:light[level=12]
setblock 125 266 292 minecraft:light[level=12]
setblock 125 266 299 minecraft:light[level=12]
setblock 125 266 306 minecraft:light[level=12]
setblock 125 266 313 minecraft:light[level=12]
fill 126 266 275 127 267 275 minecraft:white_concrete
fill 126 266 317 127 267 317 minecraft:white_concrete
fill 127 266 316 132 267 316 minecraft:red_terracotta
fill 128 266 275 129 267 275 minecraft:red_concrete
fill 128 266 317 129 267 317 minecraft:red_concrete
setblock 129 266 278 minecraft:light[level=15]
setblock 129 266 286 minecraft:light[level=15]
setblock 129 266 294 minecraft:light[level=15]
setblock 129 266 302 minecraft:light[level=15]
setblock 129 266 310 minecraft:light[level=15]
fill 130 266 275 131 267 275 minecraft:white_concrete
fill 130 266 276 135 267 276 minecraft:red_terracotta
fill 130 266 317 131 267 317 minecraft:white_concrete
fill 132 266 275 133 267 275 minecraft:red_concrete
setblock 132 266 278 minecraft:light[level=12]
setblock 132 266 285 minecraft:light[level=12]
setblock 132 266 292 minecraft:light[level=12]
setblock 132 266 299 minecraft:light[level=12]
setblock 132 266 306 minecraft:light[level=12]
setblock 132 266 313 minecraft:light[level=12]
fill 132 266 317 133 267 317 minecraft:red_concrete
fill 134 266 275 135 267 275 minecraft:white_concrete
fill 134 266 278 134 266 314 minecraft:red_terracotta
fill 134 266 317 135 267 317 minecraft:white_concrete
fill 135 266 279 135 267 284 minecraft:red_terracotta
fill 135 266 287 135 267 292 minecraft:red_terracotta
fill 135 266 295 135 267 300 minecraft:red_terracotta
fill 135 266 303 135 267 308 minecraft:red_terracotta
fill 135 266 311 135 267 314 minecraft:red_terracotta
fill 135 266 316 135 267 316 minecraft:red_terracotta
fill 136 266 276 136 267 276 minecraft:white_concrete
fill 136 266 277 136 267 278 minecraft:red_concrete
fill 136 266 279 136 267 280 minecraft:white_concrete
fill 136 266 281 136 267 282 minecraft:red_concrete
fill 136 266 283 136 267 284 minecraft:white_concrete
fill 136 266 285 136 267 286 minecraft:red_concrete
fill 136 266 287 136 267 288 minecraft:white_concrete
fill 136 266 289 136 267 290 minecraft:red_concrete
fill 136 266 291 136 267 292 minecraft:white_concrete
fill 136 266 293 136 267 294 minecraft:red_concrete
fill 136 266 295 136 267 296 minecraft:white_concrete
fill 136 266 297 136 267 298 minecraft:red_concrete
fill 136 266 299 136 267 300 minecraft:white_concrete
fill 136 266 301 136 267 302 minecraft:red_concrete
fill 136 266 303 136 267 304 minecraft:white_concrete
fill 136 266 305 136 267 306 minecraft:red_concrete
fill 136 266 307 136 267 308 minecraft:white_concrete
fill 136 266 309 136 267 310 minecraft:red_concrete
fill 136 266 311 136 267 312 minecraft:white_concrete
fill 136 266 313 136 267 314 minecraft:red_concrete
fill 136 266 315 136 267 316 minecraft:white_concrete
fill 136 266 317 136 267 317 minecraft:red_concrete
fill 95 267 284 95 267 289 minecraft:red_terracotta
fill 95 267 292 95 267 297 minecraft:red_terracotta
fill 95 267 300 95 267 305 minecraft:red_terracotta
fill 95 267 308 95 267 313 minecraft:red_terracotta
fill 97 267 304 101 270 304 minecraft:yellow_concrete
fill 98 267 303 100 270 303 minecraft:yellow_concrete
fill 98 267 305 100 270 305 minecraft:yellow_concrete
fill 99 267 302 99 270 302 minecraft:yellow_concrete
fill 99 267 306 99 270 306 minecraft:yellow_concrete
setblock 135 267 315 minecraft:red_terracotta
fill 94 268 275 94 269 276 minecraft:red_concrete
fill 94 268 277 94 269 278 minecraft:white_concrete
fill 94 268 279 94 269 280 minecraft:red_concrete
fill 94 268 281 94 269 282 minecraft:white_concrete
fill 94 268 283 94 269 284 minecraft:red_concrete
fill 94 268 285 94 269 286 minecraft:white_concrete
fill 94 268 287 94 269 288 minecraft:red_concrete
fill 94 268 289 94 269 290 minecraft:white_concrete
fill 94 268 291 94 269 292 minecraft:red_concrete
fill 94 268 293 94 269 294 minecraft:white_concrete
fill 94 268 295 94 269 296 minecraft:red_concrete
fill 94 268 297 94 269 298 minecraft:white_concrete
fill 94 268 299 94 269 300 minecraft:red_concrete
fill 94 268 301 94 269 302 minecraft:white_concrete
fill 94 268 303 94 269 304 minecraft:red_concrete
fill 94 268 305 94 269 306 minecraft:white_concrete
fill 94 268 307 94 269 308 minecraft:red_concrete
fill 94 268 309 94 269 310 minecraft:white_concrete
fill 94 268 311 94 269 312 minecraft:red_concrete
fill 94 268 313 94 269 314 minecraft:white_concrete
fill 94 268 315 94 269 316 minecraft:red_concrete
fill 95 268 275 95 269 275 minecraft:red_concrete
fill 95 268 317 95 269 317 minecraft:red_concrete
fill 96 268 275 97 269 275 minecraft:white_concrete
fill 96 268 317 97 269 317 minecraft:white_concrete
fill 97 268 303 97 269 303 minecraft:yellow_concrete
fill 97 268 305 97 269 305 minecraft:yellow_concrete
fill 98 268 275 99 269 275 minecraft:red_concrete
fill 98 268 302 98 269 302 minecraft:yellow_concrete
fill 98 268 306 98 269 306 minecraft:yellow_concrete
fill 98 268 317 99 269 317 minecraft:red_concrete
fill 100 268 275 101 269 275 minecraft:white_concrete
fill 100 268 302 100 269 302 minecraft:yellow_concrete
fill 100 268 306 100 269 306 minecraft:yellow_concrete
fill 100 268 317 101 269 317 minecraft:white_concrete
fill 101 268 303 101 269 303 minecraft:yellow_concrete
fill 101 268 305 101 269 305 minecraft:yellow_concrete
fill 102 268 275 103 269 275 minecraft:red_concrete
fill 102 268 304 104 269 304 minecraft:brown_terracotta
fill 102 268 317 103 269 317 minecraft:red_concrete
fill 103 268 305 104 269 305 minecraft:brown_terracotta
fill 104 268 275 105 269 275 minecraft:white_concrete
fill 104 268 317 105 269 317 minecraft:white_concrete
fill 106 268 275 107 269 275 minecraft:red_concrete
fill 106 268 317 107 269 317 minecraft:red_concrete
fill 108 268 275 109 269 275 minecraft:white_concrete
fill 108 268 317 109 269 317 minecraft:white_concrete
fill 110 268 275 111 269 275 minecraft:red_concrete
fill 110 268 317 111 269 317 minecraft:red_concrete
fill 112 268 275 113 269 275 minecraft:white_concrete
fill 112 268 317 113 269 317 minecraft:white_concrete
fill 114 268 275 115 269 275 minecraft:red_concrete
fill 114 268 317 115 269 317 minecraft:red_concrete
fill 116 268 275 117 269 275 minecraft:white_concrete
fill 116 268 317 117 269 317 minecraft:white_concrete
fill 118 268 275 119 269 275 minecraft:red_concrete
fill 118 268 317 119 269 317 minecraft:red_concrete
fill 120 268 275 121 269 275 minecraft:white_concrete
fill 120 268 317 121 269 317 minecraft:white_concrete
fill 122 268 275 123 269 275 minecraft:red_concrete
fill 122 268 317 123 269 317 minecraft:red_concrete
fill 124 268 275 125 269 275 minecraft:white_concrete
fill 124 268 317 125 269 317 minecraft:white_concrete
fill 126 268 275 127 269 275 minecraft:red_concrete
fill 126 268 285 126 269 285 minecraft:red_concrete
fill 126 268 317 127 269 317 minecraft:red_concrete
fill 128 268 275 129 269 275 minecraft:white_concrete
fill 128 268 317 129 269 317 minecraft:white_concrete
fill 130 268 275 131 269 275 minecraft:red_concrete
fill 130 268 317 131 269 317 minecraft:red_concrete
fill 132 268 275 133 269 275 minecraft:white_concrete
fill 132 268 317 133 269 317 minecraft:white_concrete
fill 134 268 275 135 269 275 minecraft:red_concrete
fill 134 268 317 135 269 317 minecraft:red_concrete
fill 136 268 276 136 269 276 minecraft:red_concrete
fill 136 268 277 136 269 278 minecraft:white_concrete
fill 136 268 279 136 269 280 minecraft:red_concrete
fill 136 268 281 136 269 282 minecraft:white_concrete
fill 136 268 283 136 269 284 minecraft:red_concrete
fill 136 268 285 136 269 286 minecraft:white_concrete
fill 136 268 287 136 269 288 minecraft:red_concrete
fill 136 268 289 136 269 290 minecraft:white_concrete
fill 136 268 291 136 269 292 minecraft:red_concrete
fill 136 268 293 136 269 294 minecraft:white_concrete
fill 136 268 295 136 269 296 minecraft:red_concrete
fill 136 268 297 136 269 298 minecraft:white_concrete
fill 136 268 299 136 269 300 minecraft:red_concrete
fill 136 268 301 136 269 302 minecraft:white_concrete
fill 136 268 303 136 269 304 minecraft:red_concrete
fill 136 268 305 136 269 306 minecraft:white_concrete
fill 136 268 307 136 269 308 minecraft:red_concrete
fill 136 268 309 136 269 310 minecraft:white_concrete
fill 136 268 311 136 269 312 minecraft:red_concrete
fill 136 268 313 136 269 314 minecraft:white_concrete
fill 136 268 315 136 269 316 minecraft:red_concrete
fill 136 268 317 136 269 317 minecraft:white_concrete
fill 99 269 310 99 269 313 minecraft:yellow_concrete
fill 100 269 309 100 269 310 minecraft:yellow_concrete
fill 100 269 313 100 269 314 minecraft:yellow_concrete
fill 101 269 309 102 269 309 minecraft:yellow_concrete
fill 101 269 314 102 269 314 minecraft:yellow_concrete
fill 102 269 310 103 270 310 minecraft:yellow_concrete
fill 102 269 313 103 270 313 minecraft:yellow_concrete
fill 103 269 311 104 269 312 minecraft:yellow_concrete
fill 117 269 294 120 270 294 minecraft:yellow_concrete
fill 118 269 293 119 269 293 minecraft:yellow_concrete
fill 120 269 295 120 269 298 minecraft:yellow_concrete
fill 121 269 295 121 269 296 minecraft:yellow_concrete
fill 94 270 275 94 271 276 minecraft:white_concrete
fill 94 270 277 94 271 278 minecraft:red_concrete
fill 94 270 279 94 271 279 minecraft:white_concrete
fill 94 270 280 94 272 280 minecraft:shroomlight
fill 94 270 281 94 271 282 minecraft:red_concrete
fill 94 270 283 94 271 284 minecraft:white_concrete
fill 94 270 285 94 271 286 minecraft:red_concrete
fill 94 270 287 94 271 287 minecraft:white_concrete
fill 94 270 288 94 272 288 minecraft:shroomlight
fill 94 270 289 94 271 290 minecraft:red_concrete
fill 94 270 291 94 271 292 minecraft:white_concrete
fill 94 270 293 94 271 294 minecraft:red_concrete
fill 94 270 295 94 271 295 minecraft:white_concrete
fill 94 270 296 94 272 296 minecraft:shroomlight
fill 94 270 297 94 271 298 minecraft:red_concrete
fill 94 270 299 94 271 300 minecraft:white_concrete
fill 94 270 301 94 271 302 minecraft:red_concrete
fill 94 270 303 94 271 303 minecraft:white_concrete
fill 94 270 304 94 272 304 minecraft:shroomlight
fill 94 270 305 94 271 306 minecraft:red_concrete
fill 94 270 307 94 271 308 minecraft:white_concrete
fill 94 270 309 94 271 310 minecraft:red_concrete
fill 94 270 311 94 271 311 minecraft:white_concrete
fill 94 270 312 94 272 312 minecraft:shroomlight
fill 94 270 313 94 271 314 minecraft:red_concrete
fill 94 270 315 94 271 316 minecraft:white_concrete
fill 95 270 275 95 271 275 minecraft:white_concrete
fill 95 270 317 95 271 317 minecraft:white_concrete
fill 96 270 275 97 271 275 minecraft:red_concrete
fill 96 270 317 96 271 317 minecraft:red_concrete
fill 97 270 317 97 272 317 minecraft:shroomlight
fill 98 270 275 99 271 275 minecraft:white_concrete
fill 98 270 317 99 271 317 minecraft:white_concrete
fill 99 270 311 99 270 312 minecraft:yellow_concrete
fill 100 270 275 100 271 275 minecraft:red_concrete
fill 100 270 310 100 271 310 minecraft:yellow_concrete
fill 100 270 313 100 271 313 minecraft:yellow_concrete
fill 100 270 317 101 271 317 minecraft:red_concrete
fill 101 270 275 101 272 275 minecraft:shroomlight
setblock 101 270 309 minecraft:yellow_concrete
setblock 101 270 314 minecraft:yellow_concrete
fill 102 270 275 103 271 275 minecraft:white_concrete
fill 102 270 317 103 271 317 minecraft:white_concrete
fill 103 270 311 103 271 312 minecraft:yellow_concrete
fill 104 270 275 105 271 275 minecraft:red_concrete
fill 104 270 317 104 271 317 minecraft:red_concrete
fill 105 270 317 105 272 317 minecraft:shroomlight
fill 106 270 275 107 271 275 minecraft:white_concrete
fill 106 270 317 107 271 317 minecraft:white_concrete
fill 108 270 275 108 271 275 minecraft:red_concrete
fill 108 270 317 109 271 317 minecraft:red_concrete
fill 109 270 275 109 272 275 minecraft:shroomlight
fill 110 270 275 111 271 275 minecraft:white_concrete
fill 110 270 317 111 271 317 minecraft:white_concrete
fill 112 270 275 113 271 275 minecraft:red_concrete
fill 112 270 317 112 271 317 minecraft:red_concrete
fill 113 270 317 113 272 317 minecraft:shroomlight
fill 114 270 275 115 271 275 minecraft:white_concrete
fill 114 270 317 115 271 317 minecraft:white_concrete
fill 116 270 275 116 271 275 minecraft:red_concrete
fill 116 270 317 117 271 317 minecraft:red_concrete
fill 117 270 275 117 272 275 minecraft:shroomlight
fill 118 270 275 119 271 275 minecraft:white_concrete
fill 118 270 317 119 271 317 minecraft:white_concrete
fill 120 270 275 121 271 275 minecraft:red_concrete
fill 120 270 295 120 270 297 minecraft:yellow_concrete
fill 120 270 317 120 271 317 minecraft:red_concrete
fill 121 270 317 121 272 317 minecraft:shroomlight
fill 122 270 275 123 271 275 minecraft:white_concrete
fill 122 270 317 123 271 317 minecraft:white_concrete
fill 124 270 275 124 271 275 minecraft:red_concrete
fill 124 270 317 125 271 317 minecraft:red_concrete
fill 125 270 275 125 272 275 minecraft:shroomlight
fill 126 270 275 127 271 275 minecraft:white_concrete
fill 126 270 317 127 271 317 minecraft:white_concrete
fill 128 270 275 129 271 275 minecraft:red_concrete
fill 128 270 317 128 271 317 minecraft:red_concrete
fill 129 270 317 129 272 317 minecraft:shroomlight
fill 130 270 275 131 271 275 minecraft:white_concrete
fill 130 270 317 131 271 317 minecraft:white_concrete
fill 132 270 275 132 271 275 minecraft:red_concrete
fill 132 270 317 133 271 317 minecraft:red_concrete
fill 133 270 275 133 272 275 minecraft:shroomlight
fill 134 270 275 135 271 275 minecraft:white_concrete
fill 134 270 317 135 271 317 minecraft:white_concrete
fill 136 270 276 136 271 276 minecraft:white_concrete
fill 136 270 277 136 271 278 minecraft:red_concrete
fill 136 270 279 136 271 279 minecraft:white_concrete
fill 136 270 280 136 272 280 minecraft:shroomlight
fill 136 270 281 136 271 282 minecraft:red_concrete
fill 136 270 283 136 271 284 minecraft:white_concrete
fill 136 270 285 136 271 286 minecraft:red_concrete
fill 136 270 287 136 271 287 minecraft:white_concrete
fill 136 270 288 136 272 288 minecraft:shroomlight
fill 136 270 289 136 271 290 minecraft:red_concrete
fill 136 270 291 136 271 292 minecraft:white_concrete
fill 136 270 293 136 271 294 minecraft:red_concrete
fill 136 270 295 136 271 295 minecraft:white_concrete
fill 136 270 296 136 272 296 minecraft:shroomlight
fill 136 270 297 136 271 298 minecraft:red_concrete
fill 136 270 299 136 271 300 minecraft:white_concrete
fill 136 270 301 136 271 302 minecraft:red_concrete
fill 136 270 303 136 271 303 minecraft:white_concrete
fill 136 270 304 136 272 304 minecraft:shroomlight
fill 136 270 305 136 271 306 minecraft:red_concrete
fill 136 270 307 136 271 308 minecraft:white_concrete
fill 136 270 309 136 271 310 minecraft:red_concrete
fill 136 270 311 136 271 311 minecraft:white_concrete
fill 136 270 312 136 272 312 minecraft:shroomlight
fill 136 270 313 136 271 314 minecraft:red_concrete
fill 136 270 315 136 271 316 minecraft:white_concrete
fill 136 270 317 136 271 317 minecraft:red_concrete
setblock 99 271 304 minecraft:yellow_concrete
setblock 102 271 310 minecraft:yellow_concrete
setblock 102 271 313 minecraft:yellow_concrete
fill 118 271 294 119 271 294 minecraft:yellow_concrete
fill 120 271 295 120 271 296 minecraft:yellow_concrete
fill 94 272 275 94 273 276 minecraft:red_concrete
fill 94 272 277 94 273 278 minecraft:white_concrete
fill 94 272 279 94 273 279 minecraft:red_concrete
fill 94 272 281 94 273 282 minecraft:white_concrete
fill 94 272 283 94 273 284 minecraft:red_concrete
fill 94 272 285 94 273 286 minecraft:white_concrete
fill 94 272 287 94 273 287 minecraft:red_concrete
fill 94 272 289 94 273 290 minecraft:white_concrete
fill 94 272 291 94 273 292 minecraft:red_concrete
fill 94 272 293 94 273 294 minecraft:white_concrete
fill 94 272 295 94 273 295 minecraft:red_concrete
fill 94 272 297 94 273 298 minecraft:white_concrete
fill 94 272 299 94 273 300 minecraft:red_concrete
fill 94 272 301 94 273 302 minecraft:white_concrete
fill 94 272 303 94 273 303 minecraft:red_concrete
fill 94 272 305 94 273 306 minecraft:white_concrete
fill 94 272 307 94 273 308 minecraft:red_concrete
fill 94 272 309 94 273 310 minecraft:white_concrete
fill 94 272 311 94 273 311 minecraft:red_concrete
fill 94 272 313 94 273 314 minecraft:white_concrete
fill 94 272 315 94 273 316 minecraft:red_concrete
fill 95 272 275 95 273 275 minecraft:red_concrete
fill 95 272 317 95 273 317 minecraft:red_concrete
fill 96 272 275 97 273 275 minecraft:white_concrete
fill 96 272 317 96 273 317 minecraft:white_concrete
setblock 97 272 278 minecraft:light[level=12]
setblock 97 272 285 minecraft:light[level=12]
setblock 97 272 292 minecraft:light[level=12]
setblock 97 272 299 minecraft:light[level=12]
setblock 97 272 306 minecraft:light[level=12]
setblock 97 272 313 minecraft:light[level=12]
fill 98 272 275 99 273 275 minecraft:red_concrete
fill 98 272 317 99 273 317 minecraft:red_concrete
fill 100 272 275 100 273 275 minecraft:white_concrete
fill 100 272 317 101 273 317 minecraft:white_concrete
fill 102 272 275 103 273 275 minecraft:red_concrete
fill 102 272 317 103 273 317 minecraft:red_concrete
fill 104 272 275 105 273 275 minecraft:white_concrete
setblock 104 272 278 minecraft:light[level=12]
setblock 104 272 285 minecraft:light[level=12]
setblock 104 272 292 minecraft:light[level=12]
setblock 104 272 299 minecraft:light[level=12]
setblock 104 272 306 minecraft:light[level=12]
setblock 104 272 313 minecraft:light[level=12]
fill 104 272 317 104 273 317 minecraft:white_concrete
fill 106 272 275 107 273 275 minecraft:red_concrete
fill 106 272 317 107 273 317 minecraft:red_concrete
fill 108 272 275 108 273 275 minecraft:white_concrete
fill 108 272 317 109 273 317 minecraft:white_concrete
fill 110 272 275 111 273 275 minecraft:red_concrete
fill 110 272 317 111 273 317 minecraft:red_concrete
setblock 111 272 278 minecraft:light[level=12]
setblock 111 272 285 minecraft:light[level=12]
setblock 111 272 292 minecraft:light[level=12]
setblock 111 272 299 minecraft:light[level=12]
setblock 111 272 306 minecraft:light[level=12]
setblock 111 272 313 minecraft:light[level=12]
fill 112 272 275 113 273 275 minecraft:white_concrete
fill 112 272 317 112 273 317 minecraft:white_concrete
fill 114 272 275 115 273 275 minecraft:red_concrete
fill 114 272 317 115 273 317 minecraft:red_concrete
fill 116 272 275 116 273 275 minecraft:white_concrete
fill 116 272 317 117 273 317 minecraft:white_concrete
fill 118 272 275 119 273 275 minecraft:red_concrete
setblock 118 272 278 minecraft:light[level=12]
setblock 118 272 285 minecraft:light[level=12]
setblock 118 272 292 minecraft:light[level=12]
setblock 118 272 299 minecraft:light[level=12]
setblock 118 272 306 minecraft:light[level=12]
setblock 118 272 313 minecraft:light[level=12]
fill 118 272 317 119 273 317 minecraft:red_concrete
fill 120 272 275 121 273 275 minecraft:white_concrete
fill 120 272 317 120 273 317 minecraft:white_concrete
fill 122 272 275 123 273 275 minecraft:red_concrete
fill 122 272 317 123 273 317 minecraft:red_concrete
fill 124 272 275 124 273 275 minecraft:white_concrete
fill 124 272 317 125 273 317 minecraft:white_concrete
setblock 125 272 278 minecraft:light[level=12]
setblock 125 272 285 minecraft:light[level=12]
setblock 125 272 292 minecraft:light[level=12]
setblock 125 272 299 minecraft:light[level=12]
setblock 125 272 306 minecraft:light[level=12]
setblock 125 272 313 minecraft:light[level=12]
fill 126 272 275 127 273 275 minecraft:red_concrete
fill 126 272 317 127 273 317 minecraft:red_concrete
fill 128 272 275 129 273 275 minecraft:white_concrete
fill 128 272 317 128 273 317 minecraft:white_concrete
fill 130 272 275 131 273 275 minecraft:red_concrete
fill 130 272 317 131 273 317 minecraft:red_concrete
fill 132 272 275 132 273 275 minecraft:white_concrete
setblock 132 272 278 minecraft:light[level=12]
setblock 132 272 285 minecraft:light[level=12]
setblock 132 272 292 minecraft:light[level=12]
setblock 132 272 299 minecraft:light[level=12]
setblock 132 272 306 minecraft:light[level=12]
setblock 132 272 313 minecraft:light[level=12]
fill 132 272 317 133 273 317 minecraft:white_concrete
fill 134 272 275 135 273 275 minecraft:red_concrete
fill 134 272 317 135 273 317 minecraft:red_concrete
fill 136 272 276 136 273 276 minecraft:red_concrete
fill 136 272 277 136 273 278 minecraft:white_concrete
fill 136 272 279 136 273 279 minecraft:red_concrete
fill 136 272 281 136 273 282 minecraft:white_concrete
fill 136 272 283 136 273 284 minecraft:red_concrete
fill 136 272 285 136 273 286 minecraft:white_concrete
fill 136 272 287 136 273 287 minecraft:red_concrete
fill 136 272 289 136 273 290 minecraft:white_concrete
fill 136 272 291 136 273 292 minecraft:red_concrete
fill 136 272 293 136 273 294 minecraft:white_concrete
fill 136 272 295 136 273 295 minecraft:red_concrete
fill 136 272 297 136 273 298 minecraft:white_concrete
fill 136 272 299 136 273 300 minecraft:red_concrete
fill 136 272 301 136 273 302 minecraft:white_concrete
fill 136 272 303 136 273 303 minecraft:red_concrete
fill 136 272 305 136 273 306 minecraft:white_concrete
fill 136 272 307 136 273 308 minecraft:red_concrete
fill 136 272 309 136 273 310 minecraft:white_concrete
fill 136 272 311 136 273 311 minecraft:red_concrete
fill 136 272 313 136 273 314 minecraft:white_concrete
fill 136 272 315 136 273 316 minecraft:red_concrete
fill 136 272 317 136 273 317 minecraft:white_concrete
setblock 94 273 280 minecraft:red_concrete
setblock 94 273 288 minecraft:red_concrete
setblock 94 273 296 minecraft:red_concrete
setblock 94 273 304 minecraft:red_concrete
setblock 94 273 312 minecraft:red_concrete
setblock 97 273 317 minecraft:white_concrete
setblock 101 273 275 minecraft:white_concrete
setblock 105 273 317 minecraft:white_concrete
setblock 109 273 275 minecraft:white_concrete
setblock 113 273 317 minecraft:white_concrete
setblock 117 273 275 minecraft:white_concrete
setblock 121 273 317 minecraft:white_concrete
setblock 125 273 275 minecraft:white_concrete
setblock 129 273 317 minecraft:white_concrete
setblock 133 273 275 minecraft:white_concrete
setblock 136 273 280 minecraft:red_concrete
setblock 136 273 288 minecraft:red_concrete
setblock 136 273 296 minecraft:red_concrete
setblock 136 273 304 minecraft:red_concrete
setblock 136 273 312 minecraft:red_concrete
fill 94 274 275 94 275 276 minecraft:white_concrete
fill 94 274 277 94 275 278 minecraft:red_concrete
fill 94 274 279 94 275 280 minecraft:white_concrete
fill 94 274 281 94 275 282 minecraft:red_concrete
fill 94 274 283 94 275 284 minecraft:white_concrete
fill 94 274 285 94 275 286 minecraft:red_concrete
fill 94 274 287 94 275 288 minecraft:white_concrete
fill 94 274 289 94 275 290 minecraft:red_concrete
fill 94 274 291 94 275 292 minecraft:white_concrete
fill 94 274 293 94 275 294 minecraft:red_concrete
fill 94 274 295 94 275 296 minecraft:white_concrete
fill 94 274 297 94 275 298 minecraft:red_concrete
fill 94 274 299 94 275 300 minecraft:white_concrete
fill 94 274 301 94 275 302 minecraft:red_concrete
fill 94 274 303 94 275 304 minecraft:white_concrete
fill 94 274 305 94 275 306 minecraft:red_concrete
fill 94 274 307 94 275 308 minecraft:white_concrete
fill 94 274 309 94 275 310 minecraft:red_concrete
fill 94 274 311 94 275 312 minecraft:white_concrete
fill 94 274 313 94 275 314 minecraft:red_concrete
fill 94 274 315 94 275 316 minecraft:white_concrete
fill 95 274 275 95 275 275 minecraft:white_concrete
fill 95 274 317 95 275 317 minecraft:white_concrete
fill 96 274 275 97 275 275 minecraft:red_concrete
fill 96 274 317 97 275 317 minecraft:red_concrete
setblock 97 274 278 minecraft:light[level=15]
setblock 97 274 286 minecraft:light[level=15]
setblock 97 274 294 minecraft:light[level=15]
setblock 97 274 302 minecraft:light[level=15]
setblock 97 274 310 minecraft:light[level=15]
fill 98 274 275 99 275 275 minecraft:white_concrete
fill 98 274 317 99 275 317 minecraft:white_concrete
fill 100 274 275 101 275 275 minecraft:red_concrete
fill 100 274 317 101 275 317 minecraft:red_concrete
fill 102 274 275 103 275 275 minecraft:white_concrete
fill 102 274 317 103 275 317 minecraft:white_concrete
fill 104 274 275 105 275 275 minecraft:red_concrete
fill 104 274 317 105 275 317 minecraft:red_concrete
setblock 105 274 278 minecraft:light[level=15]
setblock 105 274 286 minecraft:light[level=15]
setblock 105 274 294 minecraft:light[level=15]
setblock 105 274 302 minecraft:light[level=15]
setblock 105 274 310 minecraft:light[level=15]
fill 106 274 275 107 275 275 minecraft:white_concrete
fill 106 274 317 107 275 317 minecraft:white_concrete
fill 108 274 275 109 275 275 minecraft:red_concrete
fill 108 274 317 109 275 317 minecraft:red_concrete
fill 110 274 275 111 275 275 minecraft:white_concrete
fill 110 274 317 111 275 317 minecraft:white_concrete
fill 112 274 275 113 275 275 minecraft:red_concrete
fill 112 274 317 113 275 317 minecraft:red_concrete
setblock 113 274 278 minecraft:light[level=15]
setblock 113 274 286 minecraft:light[level=15]
setblock 113 274 294 minecraft:light[level=15]
setblock 113 274 302 minecraft:light[level=15]
setblock 113 274 310 minecraft:light[level=15]
fill 114 274 275 115 275 275 minecraft:white_concrete
fill 114 274 317 115 275 317 minecraft:white_concrete
fill 116 274 275 117 275 275 minecraft:red_concrete
fill 116 274 317 117 275 317 minecraft:red_concrete
fill 118 274 275 119 275 275 minecraft:white_concrete
fill 118 274 317 119 275 317 minecraft:white_concrete
fill 120 274 275 121 275 275 minecraft:red_concrete
fill 120 274 317 121 275 317 minecraft:red_concrete
setblock 121 274 278 minecraft:light[level=15]
setblock 121 274 286 minecraft:light[level=15]
setblock 121 274 294 minecraft:light[level=15]
setblock 121 274 302 minecraft:light[level=15]
setblock 121 274 310 minecraft:light[level=15]
fill 122 274 275 123 275 275 minecraft:white_concrete
fill 122 274 317 123 275 317 minecraft:white_concrete
fill 124 274 275 125 275 275 minecraft:red_concrete
fill 124 274 317 125 275 317 minecraft:red_concrete
fill 126 274 275 127 275 275 minecraft:white_concrete
fill 126 274 317 127 275 317 minecraft:white_concrete
fill 128 274 275 129 275 275 minecraft:red_concrete
fill 128 274 317 129 275 317 minecraft:red_concrete
setblock 129 274 278 minecraft:light[level=15]
setblock 129 274 286 minecraft:light[level=15]
setblock 129 274 294 minecraft:light[level=15]
setblock 129 274 302 minecraft:light[level=15]
setblock 129 274 310 minecraft:light[level=15]
fill 130 274 275 131 275 275 minecraft:white_concrete
fill 130 274 317 131 275 317 minecraft:white_concrete
fill 132 274 275 133 275 275 minecraft:red_concrete
fill 132 274 317 133 275 317 minecraft:red_concrete
fill 134 274 275 135 275 275 minecraft:white_concrete
fill 134 274 317 135 275 317 minecraft:white_concrete
fill 136 274 276 136 275 276 minecraft:white_concrete
fill 136 274 277 136 275 278 minecraft:red_concrete
fill 136 274 279 136 275 280 minecraft:white_concrete
fill 136 274 281 136 275 282 minecraft:red_concrete
fill 136 274 283 136 275 284 minecraft:white_concrete
fill 136 274 285 136 275 286 minecraft:red_concrete
fill 136 274 287 136 275 288 minecraft:white_concrete
fill 136 274 289 136 275 290 minecraft:red_concrete
fill 136 274 291 136 275 292 minecraft:white_concrete
fill 136 274 293 136 275 294 minecraft:red_concrete
fill 136 274 295 136 275 296 minecraft:white_concrete
fill 136 274 297 136 275 298 minecraft:red_concrete
fill 136 274 299 136 275 300 minecraft:white_concrete
fill 136 274 301 136 275 302 minecraft:red_concrete
fill 136 274 303 136 275 304 minecraft:white_concrete
fill 136 274 305 136 275 306 minecraft:red_concrete
fill 136 274 307 136 275 308 minecraft:white_concrete
fill 136 274 309 136 275 310 minecraft:red_concrete
fill 136 274 311 136 275 312 minecraft:white_concrete
fill 136 274 313 136 275 314 minecraft:red_concrete
fill 136 274 315 136 275 316 minecraft:white_concrete
fill 136 274 317 136 275 317 minecraft:red_concrete
fill 94 276 275 94 277 276 minecraft:red_concrete
fill 94 276 277 94 277 278 minecraft:white_concrete
fill 94 276 279 94 277 280 minecraft:red_concrete
fill 94 276 281 94 277 282 minecraft:white_concrete
fill 94 276 283 94 277 284 minecraft:red_concrete
fill 94 276 285 94 277 286 minecraft:white_concrete
fill 94 276 287 94 277 288 minecraft:red_concrete
fill 94 276 289 94 277 290 minecraft:white_concrete
fill 94 276 291 94 277 292 minecraft:red_concrete
fill 94 276 293 94 277 294 minecraft:white_concrete
fill 94 276 295 94 277 296 minecraft:red_concrete
fill 94 276 297 94 277 298 minecraft:white_concrete
fill 94 276 299 94 277 300 minecraft:red_concrete
fill 94 276 301 94 277 302 minecraft:white_concrete
fill 94 276 303 94 277 304 minecraft:red_concrete
fill 94 276 305 94 277 306 minecraft:white_concrete
fill 94 276 307 94 277 308 minecraft:red_concrete
fill 94 276 309 94 277 310 minecraft:white_concrete
fill 94 276 311 94 277 312 minecraft:red_concrete
fill 94 276 313 94 277 314 minecraft:white_concrete
fill 94 276 315 94 277 316 minecraft:red_concrete
fill 95 276 275 95 277 275 minecraft:red_concrete
fill 95 276 317 95 277 317 minecraft:red_concrete
fill 96 276 275 97 277 275 minecraft:white_concrete
fill 96 276 317 97 277 317 minecraft:white_concrete
fill 98 276 275 99 277 275 minecraft:red_concrete
fill 98 276 317 99 277 317 minecraft:red_concrete
fill 100 276 275 101 277 275 minecraft:white_concrete
fill 100 276 317 101 277 317 minecraft:white_concrete
fill 102 276 275 103 277 275 minecraft:red_concrete
fill 102 276 317 103 277 317 minecraft:red_concrete
fill 104 276 275 105 277 275 minecraft:white_concrete
fill 104 276 317 105 277 317 minecraft:white_concrete
fill 106 276 275 107 277 275 minecraft:red_concrete
fill 106 276 317 107 277 317 minecraft:red_concrete
fill 108 276 275 109 277 275 minecraft:white_concrete
fill 108 276 317 109 277 317 minecraft:white_concrete
fill 110 276 275 111 277 275 minecraft:red_concrete
fill 110 276 317 111 277 317 minecraft:red_concrete
fill 112 276 275 113 277 275 minecraft:white_concrete
fill 112 276 317 113 277 317 minecraft:white_concrete
fill 114 276 275 115 277 275 minecraft:red_concrete
fill 114 276 317 115 277 317 minecraft:red_concrete
fill 116 276 275 117 277 275 minecraft:white_concrete
fill 116 276 317 117 277 317 minecraft:white_concrete
fill 118 276 275 119 277 275 minecraft:red_concrete
fill 118 276 317 119 277 317 minecraft:red_concrete
fill 120 276 275 121 277 275 minecraft:white_concrete
fill 120 276 317 121 277 317 minecraft:white_concrete
fill 122 276 275 123 277 275 minecraft:red_concrete
fill 122 276 317 123 277 317 minecraft:red_concrete
fill 124 276 275 125 277 275 minecraft:white_concrete
fill 124 276 317 125 277 317 minecraft:white_concrete
fill 126 276 275 127 277 275 minecraft:red_concrete
fill 126 276 317 127 277 317 minecraft:red_concrete
fill 128 276 275 129 277 275 minecraft:white_concrete
fill 128 276 317 129 277 317 minecraft:white_concrete
fill 130 276 275 131 277 275 minecraft:red_concrete
fill 130 276 317 131 277 317 minecraft:red_concrete
fill 132 276 275 133 277 275 minecraft:white_concrete
fill 132 276 317 133 277 317 minecraft:white_concrete
fill 134 276 275 135 277 275 minecraft:red_concrete
fill 134 276 317 135 277 317 minecraft:red_concrete
fill 136 276 276 136 277 276 minecraft:red_concrete
fill 136 276 277 136 277 278 minecraft:white_concrete
fill 136 276 279 136 277 280 minecraft:red_concrete
fill 136 276 281 136 277 282 minecraft:white_concrete
fill 136 276 283 136 277 284 minecraft:red_concrete
fill 136 276 285 136 277 286 minecraft:white_concrete
fill 136 276 287 136 277 288 minecraft:red_concrete
fill 136 276 289 136 277 290 minecraft:white_concrete
fill 136 276 291 136 277 292 minecraft:red_concrete
fill 136 276 293 136 277 294 minecraft:white_concrete
fill 136 276 295 136 277 296 minecraft:red_concrete
fill 136 276 297 136 277 298 minecraft:white_concrete
fill 136 276 299 136 277 300 minecraft:red_concrete
fill 136 276 301 136 277 302 minecraft:white_concrete
fill 136 276 303 136 277 304 minecraft:red_concrete
fill 136 276 305 136 277 306 minecraft:white_concrete
fill 136 276 307 136 277 308 minecraft:red_concrete
fill 136 276 309 136 277 310 minecraft:white_concrete
fill 136 276 311 136 277 312 minecraft:red_concrete
fill 136 276 313 136 277 314 minecraft:white_concrete
fill 136 276 315 136 277 316 minecraft:red_concrete
fill 136 276 317 136 277 317 minecraft:white_concrete
fill 94 278 275 94 279 276 minecraft:white_concrete
fill 94 278 277 94 279 278 minecraft:red_concrete
fill 94 278 279 94 279 280 minecraft:white_concrete
fill 94 278 281 94 279 282 minecraft:red_concrete
fill 94 278 283 94 279 284 minecraft:white_concrete
fill 94 278 285 94 279 286 minecraft:red_concrete
fill 94 278 287 94 279 288 minecraft:white_concrete
fill 94 278 289 94 279 290 minecraft:red_concrete
fill 94 278 291 94 279 292 minecraft:white_concrete
fill 94 278 293 94 279 294 minecraft:red_concrete
fill 94 278 295 94 279 296 minecraft:white_concrete
fill 94 278 297 94 279 298 minecraft:red_concrete
fill 94 278 299 94 279 300 minecraft:white_concrete
fill 94 278 301 94 279 302 minecraft:red_concrete
fill 94 278 303 94 279 304 minecraft:white_concrete
fill 94 278 305 94 279 306 minecraft:red_concrete
fill 94 278 307 94 279 308 minecraft:white_concrete
fill 94 278 309 94 279 310 minecraft:red_concrete
fill 94 278 311 94 279 312 minecraft:white_concrete
fill 94 278 313 94 279 314 minecraft:red_concrete
fill 94 278 315 94 279 316 minecraft:white_concrete
fill 95 278 275 95 279 275 minecraft:white_concrete
fill 95 278 317 95 279 317 minecraft:white_concrete
fill 96 278 275 97 279 275 minecraft:red_concrete
fill 96 278 317 97 279 317 minecraft:red_concrete
setblock 97 278 278 minecraft:light[level=12]
setblock 97 278 285 minecraft:light[level=12]
setblock 97 278 292 minecraft:light[level=12]
setblock 97 278 299 minecraft:light[level=12]
setblock 97 278 306 minecraft:light[level=12]
setblock 97 278 313 minecraft:light[level=12]
fill 98 278 275 99 279 275 minecraft:white_concrete
fill 98 278 317 99 279 317 minecraft:white_concrete
fill 100 278 275 101 279 275 minecraft:red_concrete
fill 100 278 317 101 279 317 minecraft:red_concrete
fill 102 278 275 103 279 275 minecraft:white_concrete
fill 102 278 317 103 279 317 minecraft:white_concrete
fill 103 278 298 112 278 298 minecraft:orange_terracotta
fill 104 278 275 105 279 275 minecraft:red_concrete
setblock 104 278 278 minecraft:light[level=12]
setblock 104 278 285 minecraft:light[level=12]
setblock 104 278 292 minecraft:light[level=12]
fill 104 278 293 113 278 297 minecraft:orange_terracotta
fill 104 278 299 113 278 303 minecraft:orange_terracotta
setblock 104 278 306 minecraft:light[level=12]
setblock 104 278 313 minecraft:light[level=12]
fill 104 278 317 105 279 317 minecraft:red_concrete
fill 105 278 292 127 278 292 minecraft:orange_terracotta
fill 105 278 304 127 278 304 minecraft:orange_terracotta
fill 106 278 275 107 279 275 minecraft:white_concrete
fill 106 278 290 126 278 291 minecraft:orange_terracotta
fill 106 278 305 126 278 306 minecraft:orange_terracotta
fill 106 278 317 107 279 317 minecraft:white_concrete
fill 107 278 289 125 278 289 minecraft:orange_terracotta
fill 107 278 307 125 278 307 minecraft:orange_terracotta
fill 108 278 275 109 279 275 minecraft:red_concrete
fill 108 278 288 124 278 288 minecraft:orange_terracotta
fill 108 278 308 124 278 308 minecraft:orange_terracotta
fill 108 278 317 109 279 317 minecraft:red_concrete
fill 110 278 275 111 279 275 minecraft:white_concrete
fill 110 278 287 122 278 287 minecraft:orange_terracotta
fill 110 278 309 122 278 309 minecraft:orange_terracotta
fill 110 278 317 111 279 317 minecraft:white_concrete
setblock 111 278 278 minecraft:light[level=12]
setblock 111 278 285 minecraft:light[level=12]
fill 111 278 286 121 278 286 minecraft:orange_terracotta
fill 111 278 310 121 278 310 minecraft:orange_terracotta
setblock 111 278 313 minecraft:light[level=12]
fill 112 278 275 113 279 275 minecraft:red_concrete
fill 112 278 317 113 279 317 minecraft:red_concrete
fill 114 278 275 115 279 275 minecraft:white_concrete
fill 114 278 293 115 278 295 minecraft:orange_terracotta
fill 114 278 301 115 278 303 minecraft:orange_terracotta
fill 114 278 317 115 279 317 minecraft:white_concrete
fill 116 278 275 117 279 275 minecraft:red_concrete
fill 116 278 285 116 279 285 minecraft:orange_terracotta
fill 116 278 293 128 278 294 minecraft:orange_terracotta
fill 116 278 302 128 278 303 minecraft:orange_terracotta
fill 116 278 311 116 279 311 minecraft:orange_terracotta
fill 116 278 317 117 279 317 minecraft:red_concrete
fill 117 278 295 128 278 295 minecraft:orange_terracotta
fill 117 278 301 128 278 301 minecraft:orange_terracotta
fill 118 278 275 119 279 275 minecraft:white_concrete
setblock 118 278 278 minecraft:light[level=12]
setblock 118 278 285 minecraft:light[level=12]
setblock 118 278 313 minecraft:light[level=12]
fill 118 278 317 119 279 317 minecraft:white_concrete
fill 119 278 296 128 278 297 minecraft:orange_terracotta
fill 119 278 299 128 278 300 minecraft:orange_terracotta
fill 120 278 275 121 279 275 minecraft:red_concrete
fill 120 278 298 129 278 298 minecraft:orange_terracotta
fill 120 278 317 121 279 317 minecraft:red_concrete
fill 122 278 275 123 279 275 minecraft:white_concrete
fill 122 278 317 123 279 317 minecraft:white_concrete
fill 124 278 275 125 279 275 minecraft:red_concrete
fill 124 278 317 125 279 317 minecraft:red_concrete
setblock 125 278 278 minecraft:light[level=12]
setblock 125 278 285 minecraft:light[level=12]
setblock 125 278 313 minecraft:light[level=12]
fill 126 278 275 127 279 275 minecraft:white_concrete
fill 126 278 317 127 279 317 minecraft:white_concrete
fill 128 278 275 129 279 275 minecraft:red_concrete
fill 128 278 317 129 279 317 minecraft:red_concrete
fill 130 278 275 131 279 275 minecraft:white_concrete
fill 130 278 317 131 279 317 minecraft:white_concrete
fill 132 278 275 133 279 275 minecraft:red_concrete
setblock 132 278 278 minecraft:light[level=12]
setblock 132 278 285 minecraft:light[level=12]
setblock 132 278 292 minecraft:light[level=12]
setblock 132 278 299 minecraft:light[level=12]
setblock 132 278 306 minecraft:light[level=12]
setblock 132 278 313 minecraft:light[level=12]
fill 132 278 317 133 279 317 minecraft:red_concrete
fill 134 278 275 135 279 275 minecraft:white_concrete
fill 134 278 317 135 279 317 minecraft:white_concrete
fill 136 278 276 136 279 276 minecraft:white_concrete
fill 136 278 277 136 279 278 minecraft:red_concrete
fill 136 278 279 136 279 280 minecraft:white_concrete
fill 136 278 281 136 279 282 minecraft:red_concrete
fill 136 278 283 136 279 284 minecraft:white_concrete
fill 136 278 285 136 279 286 minecraft:red_concrete
fill 136 278 287 136 279 288 minecraft:white_concrete
fill 136 278 289 136 279 290 minecraft:red_concrete
fill 136 278 291 136 279 292 minecraft:white_concrete
fill 136 278 293 136 279 294 minecraft:red_concrete
fill 136 278 295 136 279 296 minecraft:white_concrete
fill 136 278 297 136 279 298 minecraft:red_concrete
fill 136 278 299 136 279 300 minecraft:white_concrete
fill 136 278 301 136 279 302 minecraft:red_concrete
fill 136 278 303 136 279 304 minecraft:white_concrete
fill 136 278 305 136 279 306 minecraft:red_concrete
fill 136 278 307 136 279 308 minecraft:white_concrete
fill 136 278 309 136 279 310 minecraft:red_concrete
fill 136 278 311 136 279 312 minecraft:white_concrete
fill 136 278 313 136 279 314 minecraft:red_concrete
fill 136 278 315 136 279 316 minecraft:white_concrete
fill 136 278 317 136 279 317 minecraft:red_concrete
fill 95 279 276 95 279 277 minecraft:light_gray_concrete
setblock 95 279 278 minecraft:white_concrete
fill 95 279 279 95 279 281 minecraft:light_gray_concrete
setblock 95 279 282 minecraft:white_concrete
fill 95 279 283 95 279 285 minecraft:light_gray_concrete
setblock 95 279 286 minecraft:white_concrete
fill 95 279 287 95 279 289 minecraft:light_gray_concrete
setblock 95 279 290 minecraft:white_concrete
fill 95 279 291 95 279 293 minecraft:light_gray_concrete
setblock 95 279 294 minecraft:white_concrete
fill 95 279 295 95 279 297 minecraft:light_gray_concrete
setblock 95 279 298 minecraft:white_concrete
fill 95 279 299 95 279 301 minecraft:light_gray_concrete
setblock 95 279 302 minecraft:white_concrete
fill 95 279 303 95 279 305 minecraft:light_gray_concrete
setblock 95 279 306 minecraft:white_concrete
fill 95 279 307 95 279 309 minecraft:light_gray_concrete
setblock 95 279 310 minecraft:white_concrete
fill 95 279 311 95 279 313 minecraft:light_gray_concrete
setblock 95 279 314 minecraft:white_concrete
fill 95 279 315 96 279 316 minecraft:light_gray_concrete
setblock 96 279 276 minecraft:light_gray_concrete
setblock 96 279 277 minecraft:white_concrete
fill 96 279 278 96 279 280 minecraft:light_gray_concrete
setblock 96 279 281 minecraft:white_concrete
fill 96 279 282 96 279 284 minecraft:light_gray_concrete
setblock 96 279 285 minecraft:white_concrete
fill 96 279 286 96 279 288 minecraft:light_gray_concrete
setblock 96 279 289 minecraft:white_concrete
fill 96 279 290 96 279 292 minecraft:light_gray_concrete
setblock 96 279 293 minecraft:white_concrete
fill 96 279 294 96 279 296 minecraft:light_gray_concrete
setblock 96 279 297 minecraft:white_concrete
fill 96 279 298 96 279 300 minecraft:light_gray_concrete
setblock 96 279 301 minecraft:white_concrete
fill 96 279 302 96 279 304 minecraft:light_gray_concrete
setblock 96 279 305 minecraft:white_concrete
fill 96 279 306 96 279 308 minecraft:light_gray_concrete
setblock 96 279 309 minecraft:white_concrete
fill 96 279 310 96 279 312 minecraft:light_gray_concrete
setblock 96 279 313 minecraft:white_concrete
fill 96 279 314 98 279 314 minecraft:light_gray_concrete
setblock 97 279 276 minecraft:white_concrete
fill 97 279 277 97 279 279 minecraft:light_gray_concrete
setblock 97 279 280 minecraft:white_concrete
fill 97 279 281 97 279 283 minecraft:light_gray_concrete
setblock 97 279 284 minecraft:white_concrete
fill 97 279 285 97 279 287 minecraft:light_gray_concrete
setblock 97 279 288 minecraft:white_concrete
fill 97 279 289 97 279 291 minecraft:light_gray_concrete
setblock 97 279 292 minecraft:white_concrete
fill 97 279 293 97 279 295 minecraft:light_gray_concrete
setblock 97 279 296 minecraft:white_concrete
fill 97 279 297 97 279 299 minecraft:light_gray_concrete
setblock 97 279 300 minecraft:white_concrete
fill 97 279 301 97 279 303 minecraft:light_gray_concrete
setblock 97 279 304 minecraft:white_concrete
fill 97 279 305 97 279 307 minecraft:light_gray_concrete
setblock 97 279 308 minecraft:white_concrete
fill 97 279 309 97 279 311 minecraft:light_gray_concrete
setblock 97 279 312 minecraft:white_concrete
fill 97 279 313 99 279 313 minecraft:light_gray_concrete
setblock 97 279 315 minecraft:light_gray_concrete
setblock 97 279 316 minecraft:white_concrete
fill 98 279 276 98 279 278 minecraft:light_gray_concrete
setblock 98 279 279 minecraft:white_concrete
fill 98 279 280 98 279 282 minecraft:light_gray_concrete
setblock 98 279 283 minecraft:white_concrete
fill 98 279 284 98 279 286 minecraft:light_gray_concrete
setblock 98 279 287 minecraft:white_concrete
fill 98 279 288 98 279 290 minecraft:light_gray_concrete
setblock 98 279 291 minecraft:white_concrete
fill 98 279 292 98 279 294 minecraft:light_gray_concrete
setblock 98 279 295 minecraft:white_concrete
fill 98 279 296 98 279 298 minecraft:light_gray_concrete
setblock 98 279 299 minecraft:white_concrete
fill 98 279 300 98 279 302 minecraft:light_gray_concrete
setblock 98 279 303 minecraft:white_concrete
fill 98 279 304 98 279 306 minecraft:light_gray_concrete
setblock 98 279 307 minecraft:white_concrete
fill 98 279 308 98 279 310 minecraft:light_gray_concrete
setblock 98 279 311 minecraft:white_concrete
fill 98 279 312 100 279 312 minecraft:light_gray_concrete
setblock 98 279 315 minecraft:white_concrete
fill 98 279 316 100 279 316 minecraft:light_gray_concrete
fill 99 279 276 99 279 277 minecraft:light_gray_concrete
setblock 99 279 278 minecraft:white_concrete
fill 99 279 279 99 279 281 minecraft:light_gray_concrete
setblock 99 279 282 minecraft:white_concrete
fill 99 279 283 99 279 285 minecraft:light_gray_concrete
setblock 99 279 286 minecraft:white_concrete
fill 99 279 287 99 279 289 minecraft:light_gray_concrete
setblock 99 279 290 minecraft:white_concrete
fill 99 279 291 99 279 293 minecraft:light_gray_concrete
setblock 99 279 294 minecraft:white_concrete
fill 99 279 295 99 279 297 minecraft:light_gray_concrete
setblock 99 279 298 minecraft:white_concrete
fill 99 279 299 99 279 301 minecraft:light_gray_concrete
setblock 99 279 302 minecraft:white_concrete
fill 99 279 303 99 279 305 minecraft:light_gray_concrete
setblock 99 279 306 minecraft:white_concrete
fill 99 279 307 99 279 309 minecraft:light_gray_concrete
setblock 99 279 310 minecraft:white_concrete
fill 99 279 311 101 279 311 minecraft:light_gray_concrete
setblock 99 279 314 minecraft:white_concrete
fill 99 279 315 101 279 315 minecraft:light_gray_concrete
setblock 100 279 276 minecraft:light_gray_concrete
setblock 100 279 277 minecraft:white_concrete
fill 100 279 278 100 279 280 minecraft:light_gray_concrete
setblock 100 279 281 minecraft:white_concrete
fill 100 279 282 100 279 284 minecraft:light_gray_concrete
setblock 100 279 285 minecraft:white_concrete
fill 100 279 286 100 279 288 minecraft:light_gray_concrete
setblock 100 279 289 minecraft:white_concrete
fill 100 279 290 100 279 292 minecraft:light_gray_concrete
setblock 100 279 293 minecraft:white_concrete
fill 100 279 294 100 279 296 minecraft:light_gray_concrete
setblock 100 279 297 minecraft:white_concrete
fill 100 279 298 100 279 300 minecraft:light_gray_concrete
setblock 100 279 301 minecraft:white_concrete
fill 100 279 302 100 279 304 minecraft:light_gray_concrete
setblock 100 279 305 minecraft:white_concrete
fill 100 279 306 100 279 308 minecraft:light_gray_concrete
setblock 100 279 309 minecraft:white_concrete
fill 100 279 310 102 279 310 minecraft:light_gray_concrete
setblock 100 279 313 minecraft:white_concrete
fill 100 279 314 102 279 314 minecraft:light_gray_concrete
setblock 101 279 276 minecraft:white_concrete
fill 101 279 277 101 279 279 minecraft:light_gray_concrete
setblock 101 279 280 minecraft:white_concrete
fill 101 279 281 101 279 283 minecraft:light_gray_concrete
setblock 101 279 284 minecraft:white_concrete
fill 101 279 285 101 279 287 minecraft:light_gray_concrete
setblock 101 279 288 minecraft:white_concrete
fill 101 279 289 101 279 291 minecraft:light_gray_concrete
setblock 101 279 292 minecraft:white_concrete
fill 101 279 293 101 279 295 minecraft:light_gray_concrete
setblock 101 279 296 minecraft:white_concrete
fill 101 279 297 101 279 299 minecraft:light_gray_concrete
setblock 101 279 300 minecraft:white_concrete
fill 101 279 301 101 279 303 minecraft:light_gray_concrete
setblock 101 279 304 minecraft:white_concrete
fill 101 279 305 101 279 307 minecraft:light_gray_concrete
setblock 101 279 308 minecraft:white_concrete
fill 101 279 309 103 279 309 minecraft:light_gray_concrete
setblock 101 279 312 minecraft:white_concrete
fill 101 279 313 103 279 313 minecraft:light_gray_concrete
setblock 101 279 316 minecraft:white_concrete
fill 102 279 276 102 279 278 minecraft:light_gray_concrete
setblock 102 279 279 minecraft:white_concrete
fill 102 279 280 102 279 282 minecraft:light_gray_concrete
setblock 102 279 283 minecraft:white_concrete
fill 102 279 284 102 279 286 minecraft:light_gray_concrete
setblock 102 279 287 minecraft:white_concrete
fill 102 279 288 102 279 290 minecraft:light_gray_concrete
setblock 102 279 291 minecraft:white_concrete
fill 102 279 292 102 279 294 minecraft:light_gray_concrete
setblock 102 279 295 minecraft:white_concrete
fill 102 279 296 102 279 298 minecraft:light_gray_concrete
setblock 102 279 299 minecraft:white_concrete
fill 102 279 300 102 279 302 minecraft:light_gray_concrete
setblock 102 279 303 minecraft:white_concrete
fill 102 279 304 102 279 306 minecraft:light_gray_concrete
setblock 102 279 307 minecraft:white_concrete
fill 102 279 308 104 279 308 minecraft:light_gray_concrete
setblock 102 279 311 minecraft:white_concrete
fill 102 279 312 104 279 312 minecraft:light_gray_concrete
setblock 102 279 315 minecraft:white_concrete
fill 102 279 316 104 279 316 minecraft:light_gray_concrete
fill 103 279 276 103 279 277 minecraft:light_gray_concrete
setblock 103 279 278 minecraft:white_concrete
fill 103 279 279 103 279 281 minecraft:light_gray_concrete
setblock 103 279 282 minecraft:white_concrete
fill 103 279 283 103 279 285 minecraft:light_gray_concrete
setblock 103 279 286 minecraft:white_concrete
fill 103 279 287 103 279 289 minecraft:light_gray_concrete
setblock 103 279 290 minecraft:white_concrete
fill 103 279 291 103 279 293 minecraft:light_gray_concrete
setblock 103 279 294 minecraft:white_concrete
fill 103 279 295 103 279 297 minecraft:light_gray_concrete
fill 103 279 298 104 279 298 minecraft:orange_terracotta
fill 103 279 299 103 279 301 minecraft:light_gray_concrete
setblock 103 279 302 minecraft:white_concrete
fill 103 279 303 103 279 305 minecraft:light_gray_concrete
setblock 103 279 306 minecraft:white_concrete
fill 103 279 307 105 279 307 minecraft:light_gray_concrete
setblock 103 279 310 minecraft:white_concrete
fill 103 279 311 105 279 311 minecraft:light_gray_concrete
setblock 103 279 314 minecraft:white_concrete
fill 103 279 315 105 279 315 minecraft:light_gray_concrete
setblock 104 279 276 minecraft:light_gray_concrete
setblock 104 279 277 minecraft:white_concrete
fill 104 279 278 104 279 280 minecraft:light_gray_concrete
setblock 104 279 281 minecraft:white_concrete
fill 104 279 282 104 279 284 minecraft:light_gray_concrete
setblock 104 279 285 minecraft:white_concrete
fill 104 279 286 104 279 288 minecraft:light_gray_concrete
setblock 104 279 289 minecraft:white_concrete
fill 104 279 290 104 279 292 minecraft:light_gray_concrete
setblock 104 279 293 minecraft:brown_terracotta
fill 104 279 294 104 279 297 minecraft:orange_terracotta
fill 104 279 299 104 279 302 minecraft:orange_terracotta
setblock 104 279 303 minecraft:brown_terracotta
setblock 104 279 304 minecraft:light_gray_concrete
setblock 104 279 305 minecraft:white_concrete
fill 104 279 306 105 279 306 minecraft:light_gray_concrete
setblock 104 279 309 minecraft:white_concrete
fill 104 279 310 106 279 310 minecraft:light_gray_concrete
setblock 104 279 313 minecraft:white_concrete
fill 104 279 314 106 279 314 minecraft:light_gray_concrete
setblock 105 279 276 minecraft:white_concrete
fill 105 279 277 105 279 279 minecraft:light_gray_concrete
setblock 105 279 280 minecraft:white_concrete
fill 105 279 281 105 279 283 minecraft:light_gray_concrete
setblock 105 279 284 minecraft:white_concrete
fill 105 279 285 105 279 287 minecraft:light_gray_concrete
setblock 105 279 288 minecraft:white_concrete
fill 105 279 289 105 279 291 minecraft:light_gray_concrete
fill 105 279 292 105 279 294 minecraft:orange_terracotta
fill 105 279 295 105 279 296 minecraft:red_concrete
fill 105 279 297 105 279 298 minecraft:yellow_wool
fill 105 279 299 105 279 301 minecraft:red_concrete
fill 105 279 302 105 279 304 minecraft:orange_terracotta
setblock 105 279 305 minecraft:light_gray_concrete
setblock 105 279 308 minecraft:white_concrete
fill 105 279 309 107 279 309 minecraft:light_gray_concrete
setblock 105 279 312 minecraft:white_concrete
fill 105 279 313 107 279 313 minecraft:light_gray_concrete
setblock 105 279 316 minecraft:white_concrete
fill 106 279 276 106 279 278 minecraft:light_gray_concrete
setblock 106 279 279 minecraft:white_concrete
fill 106 279 280 106 279 282 minecraft:light_gray_concrete
setblock 106 279 283 minecraft:white_concrete
fill 106 279 284 106 279 286 minecraft:light_gray_concrete
setblock 106 279 287 minecraft:white_concrete
fill 106 279 288 106 279 289 minecraft:light_gray_concrete
fill 106 279 290 106 279 291 minecraft:orange_terracotta
fill 106 279 292 108 279 293 minecraft:red_concrete
fill 106 279 294 107 279 294 minecraft:brown_terracotta
setblock 106 279 295 minecraft:yellow_wool
fill 106 279 296 106 279 299 minecraft:red_concrete
fill 106 279 300 107 279 301 minecraft:yellow_wool
fill 106 279 302 107 279 302 minecraft:brown_terracotta
fill 106 279 303 108 279 304 minecraft:red_concrete
fill 106 279 305 106 279 306 minecraft:orange_terracotta
setblock 106 279 307 minecraft:white_concrete
fill 106 279 308 107 279 308 minecraft:light_gray_concrete
setblock 106 279 311 minecraft:white_concrete
fill 106 279 312 108 279 312 minecraft:light_gray_concrete
setblock 106 279 315 minecraft:white_concrete
fill 106 279 316 108 279 316 minecraft:light_gray_concrete
fill 107 279 276 107 279 277 minecraft:light_gray_concrete
setblock 107 279 278 minecraft:white_concrete
fill 107 279 279 107 279 281 minecraft:light_gray_concrete
setblock 107 279 282 minecraft:white_concrete
fill 107 279 283 107 279 285 minecraft:light_gray_concrete
setblock 107 279 286 minecraft:white_concrete
fill 107 279 287 107 279 288 minecraft:light_gray_concrete
fill 107 279 289 107 279 290 minecraft:orange_terracotta
fill 107 279 291 108 279 291 minecraft:red_concrete
fill 107 279 295 108 279 297 minecraft:red_terracotta
fill 107 279 298 108 279 298 minecraft:red_concrete
setblock 107 279 299 minecraft:yellow_wool
setblock 107 279 305 minecraft:yellow_wool
fill 107 279 306 107 279 307 minecraft:orange_terracotta
setblock 107 279 310 minecraft:white_concrete
fill 107 279 311 109 279 311 minecraft:light_gray_concrete
setblock 107 279 314 minecraft:white_concrete
fill 107 279 315 109 279 315 minecraft:light_gray_concrete
setblock 108 279 276 minecraft:light_gray_concrete
setblock 108 279 277 minecraft:white_concrete
fill 108 279 278 108 279 280 minecraft:light_gray_concrete
setblock 108 279 281 minecraft:white_concrete
fill 108 279 282 108 279 284 minecraft:light_gray_concrete
setblock 108 279 285 minecraft:white_concrete
fill 108 279 286 109 279 287 minecraft:light_gray_concrete
fill 108 279 288 108 279 289 minecraft:orange_terracotta
fill 108 279 290 110 279 290 minecraft:red_concrete
fill 108 279 294 110 279 294 minecraft:red_concrete
fill 108 279 299 108 279 302 minecraft:red_concrete
fill 108 279 305 110 279 305 minecraft:red_terracotta
setblock 108 279 306 minecraft:red_concrete
fill 108 279 307 108 279 308 minecraft:orange_terracotta
setblock 108 279 309 minecraft:white_concrete
fill 108 279 310 110 279 310 minecraft:light_gray_concrete
setblock 108 279 313 minecraft:white_concrete
fill 108 279 314 110 279 314 minecraft:light_gray_concrete
setblock 109 279 276 minecraft:white_concrete
fill 109 279 277 109 279 279 minecraft:light_gray_concrete
setblock 109 279 280 minecraft:white_concrete
fill 109 279 281 109 279 283 minecraft:light_gray_concrete
setblock 109 279 284 minecraft:white_concrete
fill 109 279 285 111 279 285 minecraft:light_gray_concrete
setblock 109 279 288 minecraft:orange_terracotta
fill 109 279 289 110 279 289 minecraft:red_concrete
fill 109 279 291 110 279 292 minecraft:yellow_wool
fill 109 279 293 111 279 293 minecraft:red_concrete
setblock 109 279 295 minecraft:brown_terracotta
fill 109 279 296 110 279 296 minecraft:red_concrete
fill 109 279 297 110 279 298 minecraft:yellow_wool
fill 109 279 299 110 279 300 minecraft:red_concrete
setblock 109 279 301 minecraft:brown_terracotta
setblock 109 279 302 minecraft:yellow_wool
fill 109 279 303 111 279 304 minecraft:red_terracotta
fill 109 279 306 110 279 306 minecraft:red_terracotta
fill 109 279 307 110 279 307 minecraft:red_concrete
setblock 109 279 308 minecraft:orange_terracotta
setblock 109 279 309 minecraft:light_gray_concrete
setblock 109 279 312 minecraft:white_concrete
fill 109 279 313 111 279 313 minecraft:light_gray_concrete
setblock 109 279 316 minecraft:white_concrete
fill 110 279 276 110 279 278 minecraft:light_gray_concrete
setblock 110 279 279 minecraft:white_concrete
fill 110 279 280 110 279 282 minecraft:light_gray_concrete
setblock 110 279 283 minecraft:white_concrete
fill 110 279 284 112 279 284 minecraft:light_gray_concrete
setblock 110 279 286 minecraft:light_gray_concrete
fill 110 279 287 112 279 287 minecraft:orange_terracotta
setblock 110 279 288 minecraft:red_concrete
setblock 110 279 295 minecraft:red_concrete
setblock 110 279 301 minecraft:red_concrete
setblock 110 279 302 minecraft:red_terracotta
fill 110 279 308 111 279 308 minecraft:red_concrete
fill 110 279 309 112 279 309 minecraft:orange_terracotta
setblock 110 279 311 minecraft:white_concrete
fill 110 279 312 112 279 312 minecraft:light_gray_concrete
setblock 110 279 315 minecraft:white_concrete
fill 110 279 316 112 279 316 minecraft:light_gray_concrete
fill 111 279 276 111 279 277 minecraft:light_gray_concrete
setblock 111 279 278 minecraft:white_concrete
fill 111 279 279 111 279 281 minecraft:light_gray_concrete
setblock 111 279 282 minecraft:white_concrete
fill 111 279 283 113 279 283 minecraft:light_gray_concrete
setblock 111 279 286 minecraft:brown_terracotta
fill 111 279 288 111 279 290 minecraft:yellow_wool
setblock 111 279 291 minecraft:red_concrete
fill 111 279 292 113 279 292 minecraft:red_terracotta
fill 111 279 294 112 279 295 minecraft:yellow_wool
setblock 111 279 296 minecraft:brown_terracotta
setblock 111 279 297 minecraft:red_terracotta
setblock 111 279 298 minecraft:red_concrete
setblock 111 279 299 minecraft:yellow_wool
setblock 111 279 300 minecraft:brown_terracotta
fill 111 279 301 112 279 301 minecraft:yellow_wool
fill 111 279 302 113 279 302 minecraft:red_concrete
fill 111 279 305 111 279 307 minecraft:yellow_wool
setblock 111 279 310 minecraft:brown_terracotta
fill 111 279 311 113 279 311 minecraft:light_gray_concrete
setblock 111 279 314 minecraft:white_concrete
fill 111 279 315 113 279 315 minecraft:light_gray_concrete
setblock 112 279 276 minecraft:light_gray_concrete
setblock 112 279 277 minecraft:white_concrete
fill 112 279 278 112 279 280 minecraft:light_gray_concrete
setblock 112 279 281 minecraft:white_concrete
fill 112 279 282 114 279 282 minecraft:light_gray_concrete
setblock 112 279 285 minecraft:white_concrete
fill 112 279 286 120 279 286 minecraft:orange_terracotta
fill 112 279 288 112 279 289 minecraft:brown_terracotta
fill 112 279 290 112 279 291 minecraft:red_terracotta
setblock 112 279 293 minecraft:red_terracotta
setblock 112 279 296 minecraft:red_terracotta
fill 112 279 297 112 279 299 minecraft:white_concrete
setblock 112 279 300 minecraft:yellow_wool
fill 112 279 303 112 279 304 minecraft:red_concrete
fill 112 279 305 112 279 306 minecraft:yellow_wool
fill 112 279 307 112 279 308 minecraft:brown_terracotta
fill 112 279 310 120 279 310 minecraft:orange_terracotta
setblock 112 279 313 minecraft:white_concrete
fill 112 279 314 114 279 314 minecraft:light_gray_concrete
setblock 113 279 276 minecraft:white_concrete
fill 113 279 277 113 279 279 minecraft:light_gray_concrete
setblock 113 279 280 minecraft:white_concrete
fill 113 279 281 115 279 281 minecraft:light_gray_concrete
setblock 113 279 284 minecraft:white_concrete
fill 113 279 285 115 279 285 minecraft:light_gray_concrete
fill 113 279 287 113 279 288 minecraft:red_concrete
fill 113 279 289 113 279 290 minecraft:red_terracotta
setblock 113 279 291 minecraft:brown_terracotta
fill 113 279 293 113 279 294 minecraft:red_concrete
fill 113 279 295 113 279 297 minecraft:white_concrete
fill 113 279 299 113 279 301 minecraft:white_concrete
setblock 113 279 303 minecraft:yellow_wool
setblock 113 279 304 minecraft:red_concrete
setblock 113 279 305 minecraft:brown_terracotta
fill 113 279 306 115 279 306 minecraft:red_concrete
fill 113 279 307 114 279 308 minecraft:red_terracotta
fill 113 279 309 115 279 309 minecraft:yellow_wool
setblock 113 279 312 minecraft:white_concrete
fill 113 279 313 115 279 313 minecraft:light_gray_concrete
setblock 113 279 316 minecraft:white_concrete
fill 114 279 276 114 279 278 minecraft:light_gray_concrete
setblock 114 279 279 minecraft:white_concrete
fill 114 279 280 116 279 280 minecraft:light_gray_concrete
setblock 114 279 283 minecraft:white_concrete
fill 114 279 284 116 279 284 minecraft:light_gray_concrete
setblock 114 279 287 minecraft:yellow_wool
fill 114 279 288 115 279 289 minecraft:red_concrete
setblock 114 279 290 minecraft:red_terracotta
fill 114 279 291 114 279 292 minecraft:yellow_wool
setblock 114 279 293 minecraft:brown_terracotta
setblock 114 279 294 minecraft:red_concrete
fill 114 279 295 115 279 295 minecraft:white_concrete
fill 114 279 301 115 279 301 minecraft:white_concrete
setblock 114 279 302 minecraft:yellow_wool
setblock 114 279 303 minecraft:brown_terracotta
fill 114 279 304 115 279 304 minecraft:yellow_wool
fill 114 279 305 115 279 305 minecraft:red_concrete
setblock 114 279 311 minecraft:white_concrete
fill 114 279 312 116 279 312 minecraft:light_gray_concrete
setblock 114 279 315 minecraft:white_concrete
fill 114 279 316 116 279 316 minecraft:light_gray_concrete
fill 115 279 276 115 279 277 minecraft:light_gray_concrete
setblock 115 279 278 minecraft:white_concrete
fill 115 279 279 117 279 279 minecraft:light_gray_concrete
setblock 115 279 282 minecraft:white_concrete
fill 115 279 283 117 279 283 minecraft:light_gray_concrete
fill 115 279 287 117 279 287 minecraft:red_concrete
setblock 115 279 290 minecraft:red_concrete
fill 115 279 291 116 279 293 minecraft:red_terracotta
fill 115 279 294 117 279 294 minecraft:white_concrete
fill 115 279 302 117 279 302 minecraft:white_concrete
setblock 115 279 303 minecraft:yellow_wool
setblock 115 279 307 minecraft:red_concrete
setblock 115 279 308 minecraft:yellow_wool
setblock 115 279 311 minecraft:light_gray_concrete
setblock 115 279 314 minecraft:white_concrete
fill 115 279 315 117 279 315 minecraft:light_gray_concrete
setblock 116 279 276 minecraft:light_gray_concrete
setblock 116 279 277 minecraft:white_concrete
fill 116 279 278 118 279 278 minecraft:light_gray_concrete
setblock 116 279 281 minecraft:white_concrete
fill 116 279 282 118 279 282 minecraft:light_gray_concrete
fill 116 279 288 118 279 289 minecraft:red_terracotta
fill 116 279 290 117 279 290 minecraft:yellow_wool
fill 116 279 303 117 279 304 minecraft:red_concrete
fill 116 279 305 117 279 307 minecraft:yellow_wool
fill 116 279 308 117 279 309 minecraft:red_concrete
setblock 116 279 313 minecraft:white_concrete
fill 116 279 314 118 279 314 minecraft:light_gray_concrete
setblock 117 279 276 minecraft:white_concrete
fill 117 279 277 119 279 277 minecraft:light_gray_concrete
setblock 117 279 280 minecraft:white_concrete
fill 117 279 281 119 279 281 minecraft:light_gray_concrete
setblock 117 279 284 minecraft:white_concrete
fill 117 279 285 119 279 285 minecraft:light_gray_concrete
setblock 117 279 291 minecraft:red_concrete
setblock 117 279 292 minecraft:red_terracotta
setblock 117 279 293 minecraft:red_concrete
fill 117 279 295 119 279 295 minecraft:white_concrete
fill 117 279 301 119 279 301 minecraft:white_concrete
setblock 117 279 311 minecraft:light_gray_concrete
setblock 117 279 312 minecraft:white_concrete
fill 117 279 313 119 279 313 minecraft:light_gray_concrete
setblock 117 279 316 minecraft:white_concrete
fill 118 279 276 120 279 276 minecraft:light_gray_concrete
setblock 118 279 279 minecraft:white_concrete
fill 118 279 280 120 279 280 minecraft:light_gray_concrete
setblock 118 279 283 minecraft:white_concrete
fill 118 279 284 120 279 284 minecraft:light_gray_concrete
fill 118 279 287 119 279 287 minecraft:yellow_wool
setblock 118 279 290 minecraft:red_concrete
fill 118 279 291 118 279 292 minecraft:yellow_wool
setblock 118 279 293 minecraft:brown_terracotta
fill 118 279 294 120 279 294 minecraft:red_concrete
fill 118 279 302 119 279 302 minecraft:yellow_wool
setblock 118 279 303 minecraft:brown_terracotta
fill 118 279 304 119 279 304 minecraft:yellow_wool
fill 118 279 305 118 279 307 minecraft:red_concrete
fill 118 279 308 119 279 309 minecraft:yellow_wool
setblock 118 279 311 minecraft:white_concrete
fill 118 279 312 120 279 312 minecraft:light_gray_concrete
setblock 118 279 315 minecraft:white_concrete
fill 118 279 316 120 279 316 minecraft:light_gray_concrete
setblock 119 279 278 minecraft:white_concrete
fill 119 279 279 121 279 279 minecraft:light_gray_concrete
setblock 119 279 282 minecraft:white_concrete
fill 119 279 283 121 279 283 minecraft:light_gray_concrete
fill 119 279 288 119 279 289 minecraft:red_concrete
fill 119 279 290 121 279 290 minecraft:red_terracotta
setblock 119 279 291 minecraft:brown_terracotta
setblock 119 279 292 minecraft:yellow_wool
fill 119 279 293 126 279 293 minecraft:red_concrete
fill 119 279 296 119 279 297 minecraft:white_concrete
fill 119 279 299 119 279 300 minecraft:white_concrete
setblock 119 279 303 minecraft:yellow_wool
setblock 119 279 305 minecraft:brown_terracotta
fill 119 279 306 119 279 307 minecraft:red_concrete
fill 119 279 311 121 279 311 minecraft:light_gray_concrete
setblock 119 279 314 minecraft:white_concrete
fill 119 279 315 121 279 315 minecraft:light_gray_concrete
setblock 120 279 277 minecraft:white_concrete
fill 120 279 278 122 279 278 minecraft:light_gray_concrete
setblock 120 279 281 minecraft:white_concrete
fill 120 279 282 122 279 282 minecraft:light_gray_concrete
setblock 120 279 285 minecraft:white_concrete
fill 120 279 287 122 279 287 minecraft:orange_terracotta
fill 120 279 288 120 279 289 minecraft:brown_terracotta
fill 120 279 291 121 279 291 minecraft:red_terracotta
fill 120 279 292 122 279 292 minecraft:red_concrete
fill 120 279 295 120 279 296 minecraft:red_concrete
fill 120 279 297 120 279 299 minecraft:white_concrete
fill 120 279 300 120 279 306 minecraft:red_concrete
fill 120 279 307 120 279 308 minecraft:brown_terracotta
fill 120 279 309 122 279 309 minecraft:orange_terracotta
setblock 120 279 313 minecraft:white_concrete
fill 120 279 314 122 279 314 minecraft:light_gray_concrete
setblock 121 279 276 minecraft:white_concrete
fill 121 279 277 123 279 277 minecraft:light_gray_concrete
setblock 121 279 280 minecraft:white_concrete
fill 121 279 281 123 279 281 minecraft:light_gray_concrete
setblock 121 279 284 minecraft:white_concrete
fill 121 279 285 123 279 285 minecraft:light_gray_concrete
setblock 121 279 286 minecraft:brown_terracotta
fill 121 279 288 121 279 289 minecraft:yellow_wool
fill 121 279 294 122 279 295 minecraft:yellow_wool
setblock 121 279 296 minecraft:brown_terracotta
fill 121 279 297 122 279 298 minecraft:red_concrete
setblock 121 279 299 minecraft:yellow_wool
setblock 121 279 300 minecraft:brown_terracotta
setblock 121 279 301 minecraft:yellow_wool
fill 121 279 302 122 279 304 minecraft:red_concrete
fill 121 279 305 122 279 307 minecraft:yellow_wool
fill 121 279 308 122 279 308 minecraft:red_concrete
setblock 121 279 310 minecraft:brown_terracotta
setblock 121 279 312 minecraft:white_concrete
fill 121 279 313 123 279 313 minecraft:light_gray_concrete
setblock 121 279 316 minecraft:white_concrete
fill 122 279 276 124 279 276 minecraft:light_gray_concrete
setblock 122 279 279 minecraft:white_concrete
fill 122 279 280 124 279 280 minecraft:light_gray_concrete
setblock 122 279 283 minecraft:white_concrete
fill 122 279 284 124 279 284 minecraft:light_gray_concrete
setblock 122 279 286 minecraft:light_gray_concrete
setblock 122 279 288 minecraft:red_concrete
setblock 122 279 289 minecraft:yellow_wool
fill 122 279 290 122 279 291 minecraft:red_concrete
setblock 122 279 296 minecraft:red_concrete
setblock 122 279 299 minecraft:red_concrete
fill 122 279 300 122 279 301 minecraft:red_terracotta
setblock 122 279 310 minecraft:light_gray_concrete
setblock 122 279 311 minecraft:white_concrete
fill 122 279 312 124 279 312 minecraft:light_gray_concrete
setblock 122 279 315 minecraft:white_concrete
fill 122 279 316 124 279 316 minecraft:light_gray_concrete
setblock 123 279 278 minecraft:white_concrete
fill 123 279 279 125 279 279 minecraft:light_gray_concrete
setblock 123 279 282 minecraft:white_concrete
fill 123 279 283 125 279 283 minecraft:light_gray_concrete
setblock 123 279 286 minecraft:white_concrete
fill 123 279 287 125 279 287 minecraft:light_gray_concrete
fill 123 279 288 124 279 288 minecraft:orange_terracotta
fill 123 279 289 123 279 290 minecraft:red_concrete
fill 123 279 291 124 279 292 minecraft:yellow_wool
setblock 123 279 294 minecraft:red_concrete
setblock 123 279 295 minecraft:brown_terracotta
fill 123 279 296 124 279 296 minecraft:red_terracotta
fill 123 279 297 124 279 298 minecraft:yellow_wool
fill 123 279 299 123 279 300 minecraft:red_terracotta
setblock 123 279 301 minecraft:brown_terracotta
fill 123 279 302 124 279 304 minecraft:yellow_wool
fill 123 279 305 123 279 307 minecraft:red_concrete
fill 123 279 308 124 279 308 minecraft:orange_terracotta
setblock 123 279 309 minecraft:light_gray_concrete
setblock 123 279 310 minecraft:white_concrete
fill 123 279 311 125 279 311 minecraft:light_gray_concrete
setblock 123 279 314 minecraft:white_concrete
fill 123 279 315 125 279 315 minecraft:light_gray_concrete
setblock 124 279 277 minecraft:white_concrete
fill 124 279 278 126 279 278 minecraft:light_gray_concrete
setblock 124 279 281 minecraft:white_concrete
fill 124 279 282 126 279 282 minecraft:light_gray_concrete
setblock 124 279 285 minecraft:white_concrete
fill 124 279 286 126 279 286 minecraft:light_gray_concrete
fill 124 279 289 125 279 289 minecraft:orange_terracotta
setblock 124 279 290 minecraft:red_concrete
fill 124 279 294 124 279 295 minecraft:red_terracotta
fill 124 279 299 125 279 299 minecraft:red_concrete
fill 124 279 300 124 279 301 minecraft:red_terracotta
fill 124 279 305 124 279 306 minecraft:red_concrete
fill 124 279 307 125 279 307 minecraft:orange_terracotta
setblock 124 279 309 minecraft:white_concrete
fill 124 279 310 126 279 310 minecraft:light_gray_concrete
setblock 124 279 313 minecraft:white_concrete
fill 124 279 314 126 279 314 minecraft:light_gray_concrete
setblock 125 279 276 minecraft:white_concrete
fill 125 279 277 127 279 277 minecraft:light_gray_concrete
setblock 125 279 280 minecraft:white_concrete
fill 125 279 281 127 279 281 minecraft:light_gray_concrete
setblock 125 279 284 minecraft:white_concrete
fill 125 279 285 127 279 285 minecraft:light_gray_concrete
setblock 125 279 288 minecraft:white_concrete
fill 125 279 290 126 279 290 minecraft:orange_terracotta
fill 125 279 291 125 279 292 minecraft:red_concrete
fill 125 279 294 126 279 294 minecraft:brown_terracotta
setblock 125 279 295 minecraft:red_terracotta
fill 125 279 296 127 279 298 minecraft:red_concrete
fill 125 279 300 125 279 301 minecraft:red_concrete
fill 125 279 302 126 279 302 minecraft:brown_terracotta
fill 125 279 303 125 279 305 minecraft:red_concrete
fill 125 279 306 126 279 306 minecraft:orange_terracotta
setblock 125 279 308 minecraft:white_concrete
fill 125 279 309 127 279 309 minecraft:light_gray_concrete
setblock 125 279 312 minecraft:white_concrete
fill 125 279 313 127 279 313 minecraft:light_gray_concrete
setblock 125 279 316 minecraft:white_concrete
fill 126 279 276 128 279 276 minecraft:light_gray_concrete
setblock 126 279 279 minecraft:white_concrete
fill 126 279 280 128 279 280 minecraft:light_gray_concrete
setblock 126 279 283 minecraft:white_concrete
fill 126 279 284 128 279 284 minecraft:light_gray_concrete
setblock 126 279 287 minecraft:white_concrete
fill 126 279 288 127 279 289 minecraft:light_gray_concrete
setblock 126 279 291 minecraft:orange_terracotta
setblock 126 279 292 minecraft:red_concrete
fill 126 279 295 127 279 295 minecraft:yellow_wool
fill 126 279 299 126 279 301 minecraft:yellow_wool
fill 126 279 303 126 279 304 minecraft:red_concrete
setblock 126 279 305 minecraft:orange_terracotta
setblock 126 279 307 minecraft:white_concrete
fill 126 279 308 128 279 308 minecraft:light_gray_concrete
setblock 126 279 311 minecraft:white_concrete
fill 126 279 312 128 279 312 minecraft:light_gray_concrete
setblock 126 279 315 minecraft:white_concrete
fill 126 279 316 128 279 316 minecraft:light_gray_concrete
setblock 127 279 278 minecraft:white_concrete
fill 127 279 279 129 279 279 minecraft:light_gray_concrete
setblock 127 279 282 minecraft:white_concrete
fill 127 279 283 129 279 283 minecraft:light_gray_concrete
setblock 127 279 286 minecraft:white_concrete
fill 127 279 287 129 279 287 minecraft:light_gray_concrete
setblock 127 279 290 minecraft:white_concrete
fill 127 279 291 129 279 291 minecraft:light_gray_concrete
fill 127 279 292 127 279 294 minecraft:orange_terracotta
setblock 127 279 299 minecraft:red_concrete
fill 127 279 300 127 279 301 minecraft:yellow_wool
fill 127 279 302 127 279 304 minecraft:orange_terracotta
setblock 127 279 305 minecraft:light_gray_concrete
setblock 127 279 306 minecraft:white_concrete
fill 127 279 307 129 279 307 minecraft:light_gray_concrete
setblock 127 279 310 minecraft:white_concrete
fill 127 279 311 129 279 311 minecraft:light_gray_concrete
setblock 127 279 314 minecraft:white_concrete
fill 127 279 315 129 279 315 minecraft:light_gray_concrete
setblock 128 279 277 minecraft:white_concrete
fill 128 279 278 130 279 278 minecraft:light_gray_concrete
setblock 128 279 281 minecraft:white_concrete
fill 128 279 282 130 279 282 minecraft:light_gray_concrete
setblock 128 279 285 minecraft:white_concrete
fill 128 279 286 130 279 286 minecraft:light_gray_concrete
setblock 128 279 288 minecraft:light_gray_concrete
setblock 128 279 289 minecraft:white_concrete
fill 128 279 290 130 279 290 minecraft:light_gray_concrete
setblock 128 279 292 minecraft:light_gray_concrete
setblock 128 279 293 minecraft:brown_terracotta
fill 128 279 294 128 279 302 minecraft:orange_terracotta
setblock 128 279 303 minecraft:brown_terracotta
setblock 128 279 304 minecraft:light_gray_concrete
setblock 128 279 305 minecraft:white_concrete
fill 128 279 306 130 279 306 minecraft:light_gray_concrete
setblock 128 279 309 minecraft:white_concrete
fill 128 279 310 130 279 310 minecraft:light_gray_concrete
setblock 128 279 313 minecraft:white_concrete
fill 128 279 314 130 279 314 minecraft:light_gray_concrete
setblock 129 279 276 minecraft:white_concrete
fill 129 279 277 131 279 277 minecraft:light_gray_concrete
setblock 129 279 280 minecraft:white_concrete
fill 129 279 281 131 279 281 minecraft:light_gray_concrete
setblock 129 279 284 minecraft:white_concrete
fill 129 279 285 131 279 285 minecraft:light_gray_concrete
setblock 129 279 288 minecraft:white_concrete
fill 129 279 289 131 279 289 minecraft:light_gray_concrete
setblock 129 279 292 minecraft:white_concrete
fill 129 279 293 129 279 295 minecraft:light_gray_concrete
setblock 129 279 296 minecraft:white_concrete
fill 129 279 297 131 279 297 minecraft:light_gray_concrete
setblock 129 279 298 minecraft:orange_terracotta
setblock 129 279 299 minecraft:light_gray_concrete
setblock 129 279 300 minecraft:white_concrete
fill 129 279 301 129 279 303 minecraft:light_gray_concrete
setblock 129 279 304 minecraft:white_concrete
fill 129 279 305 131 279 305 minecraft:light_gray_concrete
setblock 129 279 308 minecraft:white_concrete
fill 129 279 309 131 279 309 minecraft:light_gray_concrete
setblock 129 279 312 minecraft:white_concrete
fill 129 279 313 131 279 313 minecraft:light_gray_concrete
setblock 129 279 316 minecraft:white_concrete
fill 130 279 276 132 279 276 minecraft:light_gray_concrete
setblock 130 279 279 minecraft:white_concrete
fill 130 279 280 132 279 280 minecraft:light_gray_concrete
setblock 130 279 283 minecraft:white_concrete
fill 130 279 284 132 279 284 minecraft:light_gray_concrete
setblock 130 279 287 minecraft:white_concrete
fill 130 279 288 132 279 288 minecraft:light_gray_concrete
setblock 130 279 291 minecraft:white_concrete
fill 130 279 292 130 279 294 minecraft:light_gray_concrete
setblock 130 279 295 minecraft:white_concrete
fill 130 279 296 132 279 296 minecraft:light_gray_concrete
setblock 130 279 298 minecraft:light_gray_concrete
setblock 130 279 299 minecraft:white_concrete
fill 130 279 300 130 279 302 minecraft:light_gray_concrete
setblock 130 279 303 minecraft:white_concrete
fill 130 279 304 132 279 304 minecraft:light_gray_concrete
setblock 130 279 307 minecraft:white_concrete
fill 130 279 308 132 279 308 minecraft:light_gray_concrete
setblock 130 279 311 minecraft:white_concrete
fill 130 279 312 132 279 312 minecraft:light_gray_concrete
setblock 130 279 315 minecraft:white_concrete
fill 130 279 316 132 279 316 minecraft:light_gray_concrete
setblock 131 279 278 minecraft:white_concrete
fill 131 279 279 133 279 279 minecraft:light_gray_concrete
setblock 131 279 282 minecraft:white_concrete
fill 131 279 283 133 279 283 minecraft:light_gray_concrete
setblock 131 279 286 minecraft:white_concrete
fill 131 279 287 133 279 287 minecraft:light_gray_concrete
setblock 131 279 290 minecraft:white_concrete
fill 131 279 291 131 279 293 minecraft:light_gray_concrete
setblock 131 279 294 minecraft:white_concrete
fill 131 279 295 133 279 295 minecraft:light_gray_concrete
setblock 131 279 298 minecraft:white_concrete
fill 131 279 299 131 279 301 minecraft:light_gray_concrete
setblock 131 279 302 minecraft:white_concrete
fill 131 279 303 133 279 303 minecraft:light_gray_concrete
setblock 131 279 306 minecraft:white_concrete
fill 131 279 307 133 279 307 minecraft:light_gray_concrete
setblock 131 279 310 minecraft:white_concrete
fill 131 279 311 133 279 311 minecraft:light_gray_concrete
setblock 131 279 314 minecraft:white_concrete
fill 131 279 315 133 279 315 minecraft:light_gray_concrete
setblock 132 279 277 minecraft:white_concrete
fill 132 279 278 134 279 278 minecraft:light_gray_concrete
setblock 132 279 281 minecraft:white_concrete
fill 132 279 282 134 279 282 minecraft:light_gray_concrete
setblock 132 279 285 minecraft:white_concrete
fill 132 279 286 134 279 286 minecraft:light_gray_concrete
setblock 132 279 289 minecraft:white_concrete
fill 132 279 290 132 279 292 minecraft:light_gray_concrete
setblock 132 279 293 minecraft:white_concrete
fill 132 279 294 134 279 294 minecraft:light_gray_concrete
setblock 132 279 297 minecraft:white_concrete
fill 132 279 298 132 279 300 minecraft:light_gray_concrete
setblock 132 279 301 minecraft:white_concrete
fill 132 279 302 134 279 302 minecraft:light_gray_concrete
setblock 132 279 305 minecraft:white_concrete
fill 132 279 306 134 279 306 minecraft:light_gray_concrete
setblock 132 279 309 minecraft:white_concrete
fill 132 279 310 134 279 310 minecraft:light_gray_concrete
setblock 132 279 313 minecraft:white_concrete
fill 132 279 314 134 279 314 minecraft:light_gray_concrete
setblock 133 279 276 minecraft:white_concrete
fill 133 279 277 135 279 277 minecraft:light_gray_concrete
setblock 133 279 280 minecraft:white_concrete
fill 133 279 281 135 279 281 minecraft:light_gray_concrete
setblock 133 279 284 minecraft:white_concrete
fill 133 279 285 135 279 285 minecraft:light_gray_concrete
setblock 133 279 288 minecraft:white_concrete
fill 133 279 289 133 279 291 minecraft:light_gray_concrete
setblock 133 279 292 minecraft:white_concrete
fill 133 279 293 135 279 293 minecraft:light_gray_concrete
setblock 133 279 296 minecraft:white_concrete
fill 133 279 297 133 279 299 minecraft:light_gray_concrete
setblock 133 279 300 minecraft:white_concrete
fill 133 279 301 135 279 301 minecraft:light_gray_concrete
setblock 133 279 304 minecraft:white_concrete
fill 133 279 305 135 279 305 minecraft:light_gray_concrete
setblock 133 279 308 minecraft:white_concrete
fill 133 279 309 135 279 309 minecraft:light_gray_concrete
setblock 133 279 312 minecraft:white_concrete
fill 133 279 313 135 279 313 minecraft:light_gray_concrete
setblock 133 279 316 minecraft:white_concrete
fill 134 279 276 135 279 276 minecraft:light_gray_concrete
setblock 134 279 279 minecraft:white_concrete
fill 134 279 280 135 279 280 minecraft:light_gray_concrete
setblock 134 279 283 minecraft:white_concrete
fill 134 279 284 135 279 284 minecraft:light_gray_concrete
setblock 134 279 287 minecraft:white_concrete
fill 134 279 288 134 279 290 minecraft:light_gray_concrete
setblock 134 279 291 minecraft:white_concrete
fill 134 279 292 135 279 292 minecraft:light_gray_concrete
setblock 134 279 295 minecraft:white_concrete
fill 134 279 296 134 279 298 minecraft:light_gray_concrete
setblock 134 279 299 minecraft:white_concrete
fill 134 279 300 135 279 300 minecraft:light_gray_concrete
setblock 134 279 303 minecraft:white_concrete
fill 134 279 304 135 279 304 minecraft:light_gray_concrete
setblock 134 279 307 minecraft:white_concrete
fill 134 279 308 135 279 308 minecraft:light_gray_concrete
setblock 134 279 311 minecraft:white_concrete
fill 134 279 312 135 279 312 minecraft:light_gray_concrete
setblock 134 279 315 minecraft:white_concrete
fill 134 279 316 135 279 316 minecraft:light_gray_concrete
setblock 135 279 278 minecraft:white_concrete
setblock 135 279 279 minecraft:light_gray_concrete
setblock 135 279 282 minecraft:white_concrete
setblock 135 279 283 minecraft:light_gray_concrete
setblock 135 279 286 minecraft:white_concrete
fill 135 279 287 135 279 289 minecraft:light_gray_concrete
setblock 135 279 290 minecraft:white_concrete
setblock 135 279 291 minecraft:light_gray_concrete
setblock 135 279 294 minecraft:white_concrete
fill 135 279 295 135 279 297 minecraft:light_gray_concrete
setblock 135 279 298 minecraft:white_concrete
setblock 135 279 299 minecraft:light_gray_concrete
setblock 135 279 302 minecraft:white_concrete
setblock 135 279 303 minecraft:light_gray_concrete
setblock 135 279 306 minecraft:white_concrete
setblock 135 279 307 minecraft:light_gray_concrete
setblock 135 279 310 minecraft:white_concrete
setblock 135 279 311 minecraft:light_gray_concrete
setblock 135 279 314 minecraft:white_concrete
setblock 135 279 315 minecraft:light_gray_concrete
fill 94 280 275 94 281 276 minecraft:red_concrete
fill 94 280 277 94 281 278 minecraft:white_concrete
fill 94 280 279 94 281 280 minecraft:red_concrete
fill 94 280 281 94 281 282 minecraft:white_concrete
fill 94 280 283 94 281 284 minecraft:red_concrete
fill 94 280 285 94 281 286 minecraft:white_concrete
fill 94 280 287 94 281 288 minecraft:red_concrete
fill 94 280 289 94 281 290 minecraft:white_concrete
fill 94 280 291 94 281 292 minecraft:red_concrete
fill 94 280 293 94 281 294 minecraft:white_concrete
fill 94 280 295 94 281 296 minecraft:red_concrete
fill 94 280 297 94 281 298 minecraft:white_concrete
fill 94 280 299 94 281 300 minecraft:red_concrete
fill 94 280 301 94 281 302 minecraft:white_concrete
fill 94 280 303 94 281 304 minecraft:red_concrete
fill 94 280 305 94 281 306 minecraft:white_concrete
fill 94 280 307 94 281 308 minecraft:red_concrete
fill 94 280 309 94 281 310 minecraft:white_concrete
fill 94 280 311 94 281 312 minecraft:red_concrete
fill 94 280 313 94 281 314 minecraft:white_concrete
fill 94 280 315 94 281 316 minecraft:red_concrete
fill 95 280 275 95 281 275 minecraft:red_concrete
fill 95 280 317 95 281 317 minecraft:red_concrete
fill 96 280 275 97 281 275 minecraft:white_concrete
fill 96 280 317 97 281 317 minecraft:white_concrete
fill 98 280 275 99 281 275 minecraft:red_concrete
fill 98 280 317 99 281 317 minecraft:red_concrete
fill 100 280 275 101 281 275 minecraft:white_concrete
fill 100 280 317 101 281 317 minecraft:white_concrete
fill 102 280 275 103 281 275 minecraft:red_concrete
fill 102 280 317 103 281 317 minecraft:red_concrete
fill 104 280 275 105 281 275 minecraft:white_concrete
fill 104 280 317 105 281 317 minecraft:white_concrete
fill 106 280 275 107 281 275 minecraft:red_concrete
fill 106 280 317 107 281 317 minecraft:red_concrete
fill 108 280 275 109 281 275 minecraft:white_concrete
fill 108 280 317 109 281 317 minecraft:white_concrete
fill 110 280 275 111 281 275 minecraft:red_concrete
fill 110 280 317 111 281 317 minecraft:red_concrete
fill 112 280 275 113 281 275 minecraft:white_concrete
fill 112 280 317 113 281 317 minecraft:white_concrete
fill 114 280 275 115 281 275 minecraft:red_concrete
fill 114 280 317 115 281 317 minecraft:red_concrete
fill 116 280 275 117 281 275 minecraft:white_concrete
fill 116 280 317 117 281 317 minecraft:white_concrete
fill 118 280 275 119 281 275 minecraft:red_concrete
fill 118 280 317 119 281 317 minecraft:red_concrete
fill 120 280 275 121 281 275 minecraft:white_concrete
fill 120 280 317 121 281 317 minecraft:white_concrete
fill 122 280 275 123 281 275 minecraft:red_concrete
fill 122 280 317 123 281 317 minecraft:red_concrete
fill 124 280 275 125 281 275 minecraft:white_concrete
fill 124 280 317 125 281 317 minecraft:white_concrete
fill 126 280 275 127 281 275 minecraft:red_concrete
fill 126 280 317 127 281 317 minecraft:red_concrete
fill 128 280 275 129 281 275 minecraft:white_concrete
fill 128 280 317 129 281 317 minecraft:white_concrete
fill 130 280 275 131 281 275 minecraft:red_concrete
fill 130 280 317 131 281 317 minecraft:red_concrete
fill 132 280 275 133 281 275 minecraft:white_concrete
fill 132 280 317 133 281 317 minecraft:white_concrete
fill 134 280 275 135 281 275 minecraft:red_concrete
fill 134 280 317 135 281 317 minecraft:red_concrete
fill 136 280 276 136 281 276 minecraft:red_concrete
fill 136 280 277 136 281 278 minecraft:white_concrete
fill 136 280 279 136 281 280 minecraft:red_concrete
fill 136 280 281 136 281 282 minecraft:white_concrete
fill 136 280 283 136 281 284 minecraft:red_concrete
fill 136 280 285 136 281 286 minecraft:white_concrete
fill 136 280 287 136 281 288 minecraft:red_concrete
fill 136 280 289 136 281 290 minecraft:white_concrete
fill 136 280 291 136 281 292 minecraft:red_concrete
fill 136 280 293 136 281 294 minecraft:white_concrete
fill 136 280 295 136 281 296 minecraft:red_concrete
fill 136 280 297 136 281 298 minecraft:white_concrete
fill 136 280 299 136 281 300 minecraft:red_concrete
fill 136 280 301 136 281 302 minecraft:white_concrete
fill 136 280 303 136 281 304 minecraft:red_concrete
fill 136 280 305 136 281 306 minecraft:white_concrete
fill 136 280 307 136 281 308 minecraft:red_concrete
fill 136 280 309 136 281 310 minecraft:white_concrete
fill 136 280 311 136 281 312 minecraft:red_concrete
fill 136 280 313 136 281 314 minecraft:white_concrete
fill 136 280 315 136 281 316 minecraft:red_concrete
fill 136 280 317 136 281 317 minecraft:white_concrete
fill 94 282 275 94 283 276 minecraft:white_concrete
fill 94 282 277 94 283 278 minecraft:red_concrete
fill 94 282 279 94 283 280 minecraft:white_concrete
fill 94 282 281 94 283 282 minecraft:red_concrete
fill 94 282 283 94 283 284 minecraft:white_concrete
fill 94 282 285 94 283 286 minecraft:red_concrete
fill 94 282 287 94 283 288 minecraft:white_concrete
fill 94 282 289 94 283 290 minecraft:red_concrete
fill 94 282 291 94 283 292 minecraft:white_concrete
fill 94 282 293 94 283 294 minecraft:red_concrete
fill 94 282 295 94 283 296 minecraft:white_concrete
fill 94 282 297 94 283 298 minecraft:red_concrete
fill 94 282 299 94 283 300 minecraft:white_concrete
fill 94 282 301 94 283 302 minecraft:red_concrete
fill 94 282 303 94 283 304 minecraft:white_concrete
fill 94 282 305 94 283 306 minecraft:red_concrete
fill 94 282 307 94 283 308 minecraft:white_concrete
fill 94 282 309 94 283 310 minecraft:red_concrete
fill 94 282 311 94 283 312 minecraft:white_concrete
fill 94 282 313 94 283 314 minecraft:red_concrete
fill 94 282 315 94 283 316 minecraft:white_concrete
fill 95 282 275 95 283 275 minecraft:white_concrete
fill 95 282 317 95 283 317 minecraft:white_concrete
fill 96 282 275 97 283 275 minecraft:red_concrete
fill 96 282 317 97 283 317 minecraft:red_concrete
setblock 97 282 278 minecraft:light[level=15]
setblock 97 282 286 minecraft:light[level=15]
setblock 97 282 294 minecraft:light[level=15]
setblock 97 282 302 minecraft:light[level=15]
setblock 97 282 310 minecraft:light[level=15]
fill 98 282 275 99 283 275 minecraft:white_concrete
fill 98 282 317 99 283 317 minecraft:white_concrete
fill 100 282 275 101 283 275 minecraft:red_concrete
fill 100 282 317 101 283 317 minecraft:red_concrete
fill 102 282 275 103 283 275 minecraft:white_concrete
fill 102 282 317 103 283 317 minecraft:white_concrete
fill 104 282 275 105 283 275 minecraft:red_concrete
fill 104 282 317 105 283 317 minecraft:red_concrete
setblock 105 282 278 minecraft:light[level=15]
setblock 105 282 286 minecraft:light[level=15]
setblock 105 282 294 minecraft:light[level=15]
setblock 105 282 302 minecraft:light[level=15]
setblock 105 282 310 minecraft:light[level=15]
fill 106 282 275 107 283 275 minecraft:white_concrete
fill 106 282 317 107 283 317 minecraft:white_concrete
fill 108 282 275 109 283 275 minecraft:red_concrete
fill 108 282 317 109 283 317 minecraft:red_concrete
fill 110 282 275 111 283 275 minecraft:white_concrete
fill 110 282 317 111 283 317 minecraft:white_concrete
fill 112 282 275 113 283 275 minecraft:red_concrete
fill 112 282 317 113 283 317 minecraft:red_concrete
setblock 113 282 278 minecraft:light[level=15]
setblock 113 282 286 minecraft:light[level=15]
setblock 113 282 294 minecraft:light[level=15]
setblock 113 282 302 minecraft:light[level=15]
setblock 113 282 310 minecraft:light[level=15]
fill 114 282 275 115 283 275 minecraft:white_concrete
fill 114 282 317 115 283 317 minecraft:white_concrete
fill 116 282 275 117 283 275 minecraft:red_concrete
fill 116 282 317 117 283 317 minecraft:red_concrete
fill 118 282 275 119 283 275 minecraft:white_concrete
fill 118 282 317 119 283 317 minecraft:white_concrete
fill 120 282 275 121 283 275 minecraft:red_concrete
fill 120 282 317 121 283 317 minecraft:red_concrete
setblock 121 282 278 minecraft:light[level=15]
setblock 121 282 286 minecraft:light[level=15]
setblock 121 282 294 minecraft:light[level=15]
setblock 121 282 302 minecraft:light[level=15]
setblock 121 282 310 minecraft:light[level=15]
fill 122 282 275 123 283 275 minecraft:white_concrete
fill 122 282 317 123 283 317 minecraft:white_concrete
fill 124 282 275 125 283 275 minecraft:red_concrete
fill 124 282 317 125 283 317 minecraft:red_concrete
fill 126 282 275 127 283 275 minecraft:white_concrete
fill 126 282 317 127 283 317 minecraft:white_concrete
fill 128 282 275 129 283 275 minecraft:red_concrete
fill 128 282 317 129 283 317 minecraft:red_concrete
setblock 129 282 278 minecraft:light[level=15]
setblock 129 282 286 minecraft:light[level=15]
setblock 129 282 294 minecraft:light[level=15]
setblock 129 282 302 minecraft:light[level=15]
setblock 129 282 310 minecraft:light[level=15]
fill 130 282 275 131 283 275 minecraft:white_concrete
fill 130 282 317 131 283 317 minecraft:white_concrete
fill 132 282 275 133 283 275 minecraft:red_concrete
fill 132 282 317 133 283 317 minecraft:red_concrete
fill 134 282 275 135 283 275 minecraft:white_concrete
fill 134 282 317 135 283 317 minecraft:white_concrete
fill 136 282 276 136 283 276 minecraft:white_concrete
fill 136 282 277 136 283 278 minecraft:red_concrete
fill 136 282 279 136 283 280 minecraft:white_concrete
fill 136 282 281 136 283 282 minecraft:red_concrete
fill 136 282 283 136 283 284 minecraft:white_concrete
fill 136 282 285 136 283 286 minecraft:red_concrete
fill 136 282 287 136 283 288 minecraft:white_concrete
fill 136 282 289 136 283 290 minecraft:red_concrete
fill 136 282 291 136 283 292 minecraft:white_concrete
fill 136 282 293 136 283 294 minecraft:red_concrete
fill 136 282 295 136 283 296 minecraft:white_concrete
fill 136 282 297 136 283 298 minecraft:red_concrete
fill 136 282 299 136 283 300 minecraft:white_concrete
fill 136 282 301 136 283 302 minecraft:red_concrete
fill 136 282 303 136 283 304 minecraft:white_concrete
fill 136 282 305 136 283 306 minecraft:red_concrete
fill 136 282 307 136 283 308 minecraft:white_concrete
fill 136 282 309 136 283 310 minecraft:red_concrete
fill 136 282 311 136 283 312 minecraft:white_concrete
fill 136 282 313 136 283 314 minecraft:red_concrete
fill 136 282 315 136 283 316 minecraft:white_concrete
fill 136 282 317 136 283 317 minecraft:red_concrete
fill 95 283 282 95 300 283 minecraft:red_terracotta
fill 95 283 290 95 300 291 minecraft:red_terracotta
fill 95 283 298 95 300 299 minecraft:red_terracotta
fill 95 283 306 95 300 307 minecraft:red_terracotta
fill 95 283 314 95 300 315 minecraft:red_terracotta
fill 96 283 276 97 300 276 minecraft:red_terracotta
fill 97 283 310 97 283 312 minecraft:brown_terracotta
fill 98 283 309 100 283 309 minecraft:brown_terracotta
fill 98 283 310 100 300 312 minecraft:red_terracotta
fill 98 283 313 101 283 313 minecraft:brown_terracotta
setblock 101 283 310 minecraft:brown_terracotta
fill 101 283 311 101 300 311 minecraft:red_terracotta
setblock 101 283 312 minecraft:brown_terracotta
fill 101 283 316 102 288 316 minecraft:red_terracotta
fill 103 283 285 104 300 286 minecraft:red_terracotta
fill 103 283 312 103 286 312 minecraft:iron_block
fill 104 283 276 105 300 276 minecraft:red_terracotta
fill 109 283 303 109 284 303 minecraft:brown_terracotta
fill 109 283 311 113 300 313 minecraft:red_terracotta
fill 109 283 316 110 300 316 minecraft:red_terracotta
fill 110 283 314 113 300 314 minecraft:red_terracotta
fill 111 283 310 111 300 310 minecraft:red_terracotta
fill 111 283 315 111 300 315 minecraft:red_terracotta
fill 112 283 276 113 300 276 minecraft:red_terracotta
fill 117 283 316 118 294 316 minecraft:red_terracotta
fill 120 283 276 121 300 276 minecraft:red_terracotta
fill 125 283 316 126 300 316 minecraft:red_terracotta
fill 128 283 276 129 300 276 minecraft:red_terracotta
fill 129 283 279 129 283 282 minecraft:brown_terracotta
setblock 130 283 279 minecraft:brown_terracotta
fill 130 283 280 131 300 282 minecraft:red_terracotta
fill 130 283 283 131 283 283 minecraft:brown_terracotta
fill 131 283 279 131 300 279 minecraft:red_terracotta
setblock 132 283 279 minecraft:brown_terracotta
fill 132 283 280 132 300 281 minecraft:red_terracotta
fill 132 283 282 133 283 282 minecraft:brown_terracotta
fill 133 283 280 133 283 281 minecraft:brown_terracotta
fill 133 283 316 134 300 316 minecraft:red_terracotta
fill 135 283 277 135 300 278 minecraft:red_terracotta
fill 135 283 285 135 300 286 minecraft:red_terracotta
fill 135 283 293 135 300 294 minecraft:red_terracotta
fill 135 283 301 135 300 302 minecraft:red_terracotta
fill 135 283 309 135 300 310 minecraft:red_terracotta
fill 94 284 275 94 285 276 minecraft:red_concrete
fill 94 284 277 94 285 278 minecraft:white_concrete
fill 94 284 279 94 285 279 minecraft:red_concrete
fill 94 284 280 94 289 280 minecraft:shroomlight
fill 94 284 281 94 285 282 minecraft:white_concrete
fill 94 284 283 94 285 284 minecraft:red_concrete
fill 94 284 285 94 285 286 minecraft:white_concrete
fill 94 284 287 94 285 287 minecraft:red_concrete
fill 94 284 288 94 289 288 minecraft:shroomlight
fill 94 284 289 94 285 290 minecraft:white_concrete
fill 94 284 291 94 285 292 minecraft:red_concrete
fill 94 284 293 94 285 294 minecraft:white_concrete
fill 94 284 295 94 285 295 minecraft:red_concrete
fill 94 284 296 94 289 296 minecraft:shroomlight
fill 94 284 297 94 285 298 minecraft:white_concrete
fill 94 284 299 94 285 300 minecraft:red_concrete
fill 94 284 301 94 285 302 minecraft:white_concrete
fill 94 284 303 94 285 303 minecraft:red_concrete
fill 94 284 304 94 289 304 minecraft:shroomlight
fill 94 284 305 94 285 306 minecraft:white_concrete
fill 94 284 307 94 285 308 minecraft:red_concrete
fill 94 284 309 94 285 310 minecraft:white_concrete
fill 94 284 311 94 285 311 minecraft:red_concrete
fill 94 284 312 94 289 312 minecraft:shroomlight
fill 94 284 313 94 285 314 minecraft:white_concrete
fill 94 284 315 94 285 316 minecraft:red_concrete
fill 95 284 275 95 285 275 minecraft:red_concrete
fill 95 284 317 95 285 317 minecraft:red_concrete
fill 96 284 275 97 285 275 minecraft:white_concrete
fill 96 284 317 96 285 317 minecraft:white_concrete
setblock 97 284 278 minecraft:light[level=12]
setblock 97 284 285 minecraft:light[level=12]
setblock 97 284 292 minecraft:light[level=12]
setblock 97 284 299 minecraft:light[level=12]
setblock 97 284 306 minecraft:light[level=12]
setblock 97 284 313 minecraft:light[level=12]
fill 97 284 317 97 289 317 minecraft:shroomlight
fill 98 284 275 99 285 275 minecraft:red_concrete
fill 98 284 317 99 285 317 minecraft:red_concrete
fill 100 284 275 100 285 275 minecraft:white_concrete
fill 100 284 317 101 285 317 minecraft:white_concrete
fill 101 284 275 101 289 275 minecraft:shroomlight
fill 102 284 275 103 285 275 minecraft:red_concrete
fill 102 284 317 103 285 317 minecraft:red_concrete
fill 103 284 287 104 285 287 minecraft:brown_terracotta
fill 104 284 275 105 285 275 minecraft:white_concrete
setblock 104 284 278 minecraft:light[level=12]
fill 104 284 284 104 285 284 minecraft:brown_terracotta
setblock 104 284 292 minecraft:light[level=12]
setblock 104 284 299 minecraft:light[level=12]
setblock 104 284 306 minecraft:light[level=12]
setblock 104 284 313 minecraft:light[level=12]
fill 104 284 317 104 285 317 minecraft:white_concrete
fill 105 284 285 105 285 286 minecraft:brown_terracotta
fill 105 284 317 105 289 317 minecraft:shroomlight
fill 106 284 275 107 285 275 minecraft:red_concrete
fill 106 284 317 107 285 317 minecraft:red_concrete
fill 108 284 275 108 285 275 minecraft:white_concrete
fill 108 284 311 108 285 314 minecraft:brown_terracotta
fill 108 284 317 109 285 317 minecraft:white_concrete
fill 109 284 275 109 289 275 minecraft:shroomlight
fill 109 284 310 110 285 310 minecraft:brown_terracotta
fill 109 284 314 109 285 315 minecraft:brown_terracotta
fill 110 284 275 111 285 275 minecraft:red_concrete
fill 110 284 315 110 285 315 minecraft:brown_terracotta
fill 110 284 317 111 285 317 minecraft:red_concrete
setblock 111 284 278 minecraft:light[level=12]
setblock 111 284 285 minecraft:light[level=12]
setblock 111 284 292 minecraft:light[level=12]
setblock 111 284 299 minecraft:light[level=12]
setblock 111 284 306 minecraft:light[level=12]
fill 111 284 309 112 285 309 minecraft:brown_terracotta
fill 111 284 316 111 285 316 minecraft:brown_terracotta
fill 112 284 275 113 285 275 minecraft:white_concrete
fill 112 284 310 113 285 310 minecraft:brown_terracotta
fill 112 284 315 113 285 315 minecraft:brown_terracotta
fill 112 284 317 112 285 317 minecraft:white_concrete
fill 113 284 317 113 289 317 minecraft:shroomlight
fill 114 284 275 115 285 275 minecraft:red_concrete
fill 114 284 311 114 286 314 minecraft:brown_terracotta
fill 114 284 317 115 285 317 minecraft:red_concrete
fill 115 284 312 118 284 314 minecraft:red_terracotta
fill 116 284 275 116 285 275 minecraft:white_concrete
fill 116 284 311 117 300 311 minecraft:red_terracotta
fill 116 284 315 117 294 315 minecraft:red_terracotta
fill 116 284 317 117 285 317 minecraft:white_concrete
fill 117 284 275 117 289 275 minecraft:shroomlight
fill 118 284 275 119 285 275 minecraft:red_concrete
setblock 118 284 278 minecraft:light[level=12]
setblock 118 284 285 minecraft:light[level=12]
setblock 118 284 292 minecraft:light[level=12]
setblock 118 284 299 minecraft:light[level=12]
setblock 118 284 306 minecraft:light[level=12]
fill 118 284 317 119 285 317 minecraft:red_concrete
fill 119 284 313 119 294 313 minecraft:red_terracotta
fill 120 284 275 121 285 275 minecraft:white_concrete
fill 120 284 317 120 285 317 minecraft:white_concrete
fill 121 284 317 121 289 317 minecraft:shroomlight
fill 122 284 275 123 285 275 minecraft:red_concrete
fill 122 284 317 123 285 317 minecraft:red_concrete
fill 124 284 275 124 285 275 minecraft:white_concrete
fill 124 284 317 125 285 317 minecraft:white_concrete
fill 125 284 275 125 289 275 minecraft:shroomlight
setblock 125 284 278 minecraft:light[level=12]
setblock 125 284 285 minecraft:light[level=12]
setblock 125 284 292 minecraft:light[level=12]
setblock 125 284 299 minecraft:light[level=12]
setblock 125 284 306 minecraft:light[level=12]
setblock 125 284 313 minecraft:light[level=12]
fill 126 284 275 127 285 275 minecraft:red_concrete
fill 126 284 317 127 285 317 minecraft:red_concrete
fill 128 284 275 129 285 275 minecraft:white_concrete
fill 128 284 317 128 285 317 minecraft:white_concrete
fill 129 284 317 129 289 317 minecraft:shroomlight
fill 130 284 275 131 285 275 minecraft:red_concrete
fill 130 284 317 131 285 317 minecraft:red_concrete
fill 132 284 275 132 285 275 minecraft:white_concrete
setblock 132 284 278 minecraft:light[level=12]
setblock 132 284 285 minecraft:light[level=12]
setblock 132 284 292 minecraft:light[level=12]
setblock 132 284 299 minecraft:light[level=12]
setblock 132 284 306 minecraft:light[level=12]
setblock 132 284 313 minecraft:light[level=12]
fill 132 284 317 133 285 317 minecraft:white_concrete
fill 133 284 275 133 289 275 minecraft:shroomlight
fill 134 284 275 135 285 275 minecraft:red_concrete
fill 134 284 317 135 285 317 minecraft:red_concrete
fill 136 284 276 136 285 276 minecraft:red_concrete
fill 136 284 277 136 285 278 minecraft:white_concrete
fill 136 284 279 136 285 279 minecraft:red_concrete
fill 136 284 280 136 289 280 minecraft:shroomlight
fill 136 284 281 136 285 282 minecraft:white_concrete
fill 136 284 283 136 285 284 minecraft:red_concrete
fill 136 284 285 136 285 286 minecraft:white_concrete
fill 136 284 287 136 285 287 minecraft:red_concrete
fill 136 284 288 136 289 288 minecraft:shroomlight
fill 136 284 289 136 285 290 minecraft:white_concrete
fill 136 284 291 136 285 292 minecraft:red_concrete
fill 136 284 293 136 285 294 minecraft:white_concrete
fill 136 284 295 136 285 295 minecraft:red_concrete
fill 136 284 296 136 289 296 minecraft:shroomlight
fill 136 284 297 136 285 298 minecraft:white_concrete
fill 136 284 299 136 285 300 minecraft:red_concrete
fill 136 284 301 136 285 302 minecraft:white_concrete
fill 136 284 303 136 285 303 minecraft:red_concrete
fill 136 284 304 136 289 304 minecraft:shroomlight
fill 136 284 305 136 285 306 minecraft:white_concrete
schedule function dropper:buildpart/62_7 1t
