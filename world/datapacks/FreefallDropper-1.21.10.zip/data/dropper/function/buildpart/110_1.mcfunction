setblock 105 133 466 minecraft:light[level=11]
setblock 105 133 474 minecraft:light[level=11]
setblock 105 133 482 minecraft:light[level=11]
setblock 105 133 490 minecraft:light[level=11]
setblock 105 133 498 minecraft:light[level=11]
fill 107 133 505 108 165 505 minecraft:sculk
setblock 113 133 466 minecraft:light[level=11]
setblock 113 133 474 minecraft:light[level=11]
setblock 113 133 482 minecraft:light[level=11]
setblock 113 133 490 minecraft:light[level=11]
setblock 113 133 498 minecraft:light[level=11]
fill 114 133 463 115 165 463 minecraft:sculk
fill 119 133 505 120 165 505 minecraft:sculk
setblock 121 133 466 minecraft:light[level=11]
setblock 121 133 474 minecraft:light[level=11]
setblock 121 133 482 minecraft:light[level=11]
setblock 121 133 490 minecraft:light[level=11]
setblock 121 133 498 minecraft:light[level=11]
fill 126 133 463 127 165 463 minecraft:sculk
setblock 129 133 466 minecraft:light[level=11]
setblock 129 133 474 minecraft:light[level=11]
setblock 129 133 482 minecraft:light[level=11]
setblock 129 133 490 minecraft:light[level=11]
setblock 129 133 498 minecraft:light[level=11]
fill 131 133 505 132 165 505 minecraft:sculk
fill 136 133 465 136 165 466 minecraft:sculk
fill 136 133 477 136 165 478 minecraft:sculk
fill 136 133 489 136 165 490 minecraft:sculk
fill 136 133 501 136 165 502 minecraft:sculk
fill 96 140 473 96 145 475 minecraft:deepslate_bricks
fill 96 140 485 96 145 487 minecraft:deepslate_bricks
fill 96 140 497 96 145 499 minecraft:deepslate_bricks
fill 102 140 503 104 145 503 minecraft:deepslate_bricks
fill 106 140 465 108 145 465 minecraft:deepslate_bricks
fill 114 140 503 116 145 503 minecraft:deepslate_bricks
fill 118 140 465 120 145 465 minecraft:deepslate_bricks
fill 126 140 503 128 145 503 minecraft:deepslate_bricks
fill 130 140 465 132 145 465 minecraft:deepslate_bricks
fill 134 140 473 134 145 475 minecraft:deepslate_bricks
fill 134 140 485 134 145 487 minecraft:deepslate_bricks
fill 134 140 497 134 145 499 minecraft:deepslate_bricks
setblock 97 141 466 minecraft:light[level=11]
setblock 97 141 474 minecraft:light[level=11]
setblock 97 141 482 minecraft:light[level=11]
setblock 97 141 490 minecraft:light[level=11]
setblock 97 141 498 minecraft:light[level=11]
setblock 105 141 466 minecraft:light[level=11]
setblock 105 141 474 minecraft:light[level=11]
setblock 105 141 482 minecraft:light[level=11]
setblock 105 141 490 minecraft:light[level=11]
setblock 105 141 498 minecraft:light[level=11]
setblock 113 141 466 minecraft:light[level=11]
setblock 113 141 474 minecraft:light[level=11]
setblock 113 141 482 minecraft:light[level=11]
setblock 113 141 490 minecraft:light[level=11]
setblock 113 141 498 minecraft:light[level=11]
setblock 121 141 466 minecraft:light[level=11]
setblock 121 141 474 minecraft:light[level=11]
setblock 121 141 482 minecraft:light[level=11]
setblock 121 141 490 minecraft:light[level=11]
setblock 121 141 498 minecraft:light[level=11]
setblock 129 141 466 minecraft:light[level=11]
setblock 129 141 474 minecraft:light[level=11]
setblock 129 141 482 minecraft:light[level=11]
setblock 129 141 490 minecraft:light[level=11]
setblock 129 141 498 minecraft:light[level=11]
fill 96 142 488 98 142 488 minecraft:cyan_concrete
fill 97 142 485 97 142 487 minecraft:cyan_concrete
fill 97 142 489 98 142 490 minecraft:cyan_concrete
fill 98 142 484 98 142 486 minecraft:cyan_concrete
fill 99 142 483 99 142 485 minecraft:cyan_concrete
fill 99 142 490 102 142 491 minecraft:cyan_concrete
fill 100 142 483 101 142 484 minecraft:cyan_concrete
fill 102 142 484 103 142 485 minecraft:cyan_concrete
fill 102 142 489 104 142 489 minecraft:cyan_concrete
fill 103 142 486 104 142 488 minecraft:cyan_concrete
setblock 103 142 490 minecraft:cyan_concrete
setblock 104 142 485 minecraft:cyan_concrete
fill 97 143 486 97 143 488 minecraft:cyan_concrete
fill 98 143 485 98 143 486 minecraft:cyan_concrete
fill 98 143 488 98 143 490 minecraft:cyan_concrete
fill 99 143 484 99 143 485 minecraft:cyan_concrete
fill 99 143 490 102 143 490 minecraft:cyan_concrete
fill 100 143 484 102 143 484 minecraft:cyan_concrete
fill 102 143 485 103 143 485 minecraft:cyan_concrete
fill 102 143 489 103 143 489 minecraft:cyan_concrete
fill 103 143 486 103 143 488 minecraft:cyan_concrete
setblock 98 144 486 minecraft:cyan_concrete
fill 98 144 488 98 144 489 minecraft:cyan_concrete
setblock 99 144 485 minecraft:cyan_concrete
fill 100 144 490 101 144 490 minecraft:cyan_concrete
setblock 102 144 485 minecraft:cyan_concrete
setblock 102 144 489 minecraft:cyan_concrete
fill 103 144 487 103 144 488 minecraft:cyan_concrete
fill 95 145 467 95 145 472 minecraft:sculk
fill 95 145 479 95 145 484 minecraft:sculk
fill 95 145 491 95 145 496 minecraft:sculk
fill 95 145 503 95 145 504 minecraft:sculk
fill 96 145 504 99 145 504 minecraft:sculk
fill 99 145 464 104 145 464 minecraft:sculk
fill 106 145 504 111 145 504 minecraft:sculk
fill 111 145 464 116 145 464 minecraft:sculk
fill 118 145 504 123 145 504 minecraft:sculk
fill 123 145 464 128 145 464 minecraft:sculk
fill 130 145 504 135 145 504 minecraft:sculk
fill 135 145 464 135 145 469 minecraft:sculk
fill 135 145 476 135 145 481 minecraft:sculk
fill 135 145 488 135 145 493 minecraft:sculk
fill 135 145 500 135 145 503 minecraft:sculk
setblock 97 149 466 minecraft:light[level=11]
setblock 97 149 474 minecraft:light[level=11]
setblock 97 149 482 minecraft:light[level=11]
setblock 97 149 490 minecraft:light[level=11]
setblock 97 149 498 minecraft:light[level=11]
setblock 105 149 466 minecraft:light[level=11]
setblock 105 149 474 minecraft:light[level=11]
setblock 105 149 482 minecraft:light[level=11]
setblock 105 149 490 minecraft:light[level=11]
setblock 105 149 498 minecraft:light[level=11]
setblock 113 149 466 minecraft:light[level=11]
setblock 113 149 474 minecraft:light[level=11]
setblock 113 149 482 minecraft:light[level=11]
setblock 113 149 490 minecraft:light[level=11]
setblock 113 149 498 minecraft:light[level=11]
setblock 121 149 466 minecraft:light[level=11]
setblock 121 149 474 minecraft:light[level=11]
setblock 121 149 482 minecraft:light[level=11]
setblock 121 149 490 minecraft:light[level=11]
setblock 121 149 498 minecraft:light[level=11]
setblock 129 149 466 minecraft:light[level=11]
setblock 129 149 474 minecraft:light[level=11]
setblock 129 149 482 minecraft:light[level=11]
setblock 129 149 490 minecraft:light[level=11]
setblock 129 149 498 minecraft:light[level=11]
fill 95 151 464 135 152 477 minecraft:sculk
fill 95 151 478 135 152 478 minecraft:cyan_terracotta
fill 95 151 479 135 152 481 minecraft:sculk
fill 95 151 482 135 151 482 minecraft:cyan_terracotta
fill 95 151 483 111 151 485 minecraft:sculk
fill 95 151 486 112 151 486 minecraft:cyan_terracotta
fill 95 151 487 113 151 489 minecraft:sculk
fill 95 151 490 135 152 490 minecraft:cyan_terracotta
fill 95 151 491 135 152 493 minecraft:sculk
fill 95 151 494 135 152 494 minecraft:cyan_terracotta
fill 95 151 495 135 152 497 minecraft:sculk
fill 95 151 498 135 152 498 minecraft:cyan_terracotta
fill 95 151 499 135 152 501 minecraft:sculk
fill 95 151 502 135 152 502 minecraft:cyan_terracotta
fill 95 151 503 135 152 504 minecraft:sculk
fill 112 151 483 112 151 484 minecraft:sculk
setblock 113 151 483 minecraft:sculk
fill 114 151 488 135 151 489 minecraft:sculk
fill 115 151 483 135 151 483 minecraft:sculk
fill 115 151 487 135 151 487 minecraft:sculk
fill 116 151 484 135 151 484 minecraft:sculk
fill 116 151 486 135 151 486 minecraft:cyan_terracotta
fill 117 151 485 135 151 485 minecraft:sculk
fill 95 152 482 112 152 482 minecraft:cyan_terracotta
fill 95 152 483 110 152 485 minecraft:sculk
fill 95 152 486 110 152 486 minecraft:cyan_terracotta
fill 95 152 487 111 152 489 minecraft:sculk
setblock 111 152 483 minecraft:sculk
fill 111 152 484 111 152 486 minecraft:sea_lantern
fill 112 152 483 112 152 484 minecraft:sea_lantern
fill 112 152 486 112 152 487 minecraft:sea_lantern
fill 112 152 488 112 152 489 minecraft:sculk
fill 113 152 482 113 152 483 minecraft:sea_lantern
fill 113 152 487 113 152 488 minecraft:sea_lantern
fill 113 152 489 135 152 489 minecraft:sculk
fill 114 152 482 115 152 482 minecraft:sea_lantern
fill 114 152 488 115 152 488 minecraft:sea_lantern
fill 115 152 483 116 152 483 minecraft:sea_lantern
fill 115 152 487 116 152 487 minecraft:sea_lantern
fill 116 152 482 135 152 482 minecraft:cyan_terracotta
fill 116 152 484 117 152 484 minecraft:sea_lantern
fill 116 152 486 117 152 486 minecraft:sea_lantern
fill 116 152 488 135 152 488 minecraft:sculk
fill 117 152 483 135 152 483 minecraft:sculk
setblock 117 152 485 minecraft:sea_lantern
fill 117 152 487 135 152 487 minecraft:sculk
fill 118 152 484 135 152 485 minecraft:sculk
fill 118 152 486 135 152 486 minecraft:cyan_terracotta
fill 107 153 478 110 154 493 minecraft:gray_concrete
fill 111 153 478 122 154 481 minecraft:gray_concrete
fill 111 153 490 122 154 493 minecraft:gray_concrete
fill 119 153 482 122 154 489 minecraft:gray_concrete
fill 107 155 478 107 167 478 minecraft:gray_concrete
setblock 107 155 479 minecraft:black_stained_glass
fill 107 155 480 122 168 480 minecraft:gray_concrete
setblock 107 155 481 minecraft:light_blue_stained_glass
fill 107 155 482 110 168 482 minecraft:gray_concrete
setblock 107 155 483 minecraft:sea_lantern
fill 107 155 484 110 168 484 minecraft:gray_concrete
setblock 107 155 485 minecraft:sea_lantern
fill 107 155 486 110 168 486 minecraft:gray_concrete
setblock 107 155 487 minecraft:light_blue_stained_glass
fill 107 155 488 110 168 488 minecraft:gray_concrete
setblock 107 155 489 minecraft:black_stained_glass
fill 107 155 490 122 168 490 minecraft:gray_concrete
setblock 107 155 491 minecraft:sea_lantern
fill 107 155 492 107 168 493 minecraft:gray_concrete
setblock 108 155 478 minecraft:light_blue_stained_glass
fill 108 155 479 121 168 479 minecraft:gray_concrete
fill 108 155 481 121 168 481 minecraft:gray_concrete
fill 108 155 483 110 168 483 minecraft:gray_concrete
fill 108 155 485 110 168 485 minecraft:gray_concrete
fill 108 155 487 110 168 487 minecraft:gray_concrete
fill 108 155 489 110 168 489 minecraft:gray_concrete
fill 108 155 491 121 168 492 minecraft:gray_concrete
setblock 108 155 493 minecraft:black_stained_glass
fill 109 155 478 109 167 478 minecraft:gray_concrete
fill 109 155 493 109 168 493 minecraft:gray_concrete
setblock 110 155 478 minecraft:black_stained_glass
setblock 110 155 493 minecraft:black_stained_glass
fill 111 155 478 111 167 478 minecraft:gray_concrete
fill 111 155 493 111 168 493 minecraft:gray_concrete
setblock 112 155 478 minecraft:light_blue_stained_glass
setblock 112 155 493 minecraft:black_stained_glass
fill 113 155 478 113 167 478 minecraft:gray_concrete
fill 113 155 493 113 168 493 minecraft:gray_concrete
setblock 114 155 478 minecraft:black_stained_glass
setblock 114 155 493 minecraft:black_stained_glass
fill 115 155 478 115 167 478 minecraft:gray_concrete
fill 115 155 493 115 168 493 minecraft:gray_concrete
setblock 116 155 478 minecraft:black_stained_glass
setblock 116 155 493 minecraft:sea_lantern
fill 117 155 478 117 167 478 minecraft:gray_concrete
fill 117 155 493 117 168 493 minecraft:gray_concrete
setblock 118 155 478 minecraft:black_stained_glass
setblock 118 155 493 minecraft:light_blue_stained_glass
fill 119 155 478 119 167 478 minecraft:gray_concrete
fill 119 155 482 121 168 489 minecraft:gray_concrete
fill 119 155 493 119 168 493 minecraft:gray_concrete
setblock 120 155 478 minecraft:light_blue_stained_glass
setblock 120 155 493 minecraft:black_stained_glass
fill 121 155 478 122 167 478 minecraft:gray_concrete
fill 121 155 493 122 168 493 minecraft:gray_concrete
setblock 122 155 479 minecraft:black_stained_glass
setblock 122 155 481 minecraft:light_blue_stained_glass
fill 122 155 482 122 168 482 minecraft:gray_concrete
setblock 122 155 483 minecraft:light_blue_stained_glass
fill 122 155 484 122 168 484 minecraft:gray_concrete
setblock 122 155 485 minecraft:light_blue_stained_glass
fill 122 155 486 122 168 486 minecraft:gray_concrete
setblock 122 155 487 minecraft:black_stained_glass
fill 122 155 488 122 168 488 minecraft:gray_concrete
setblock 122 155 489 minecraft:sea_lantern
setblock 122 155 491 minecraft:black_stained_glass
fill 122 155 492 122 168 492 minecraft:gray_concrete
fill 95 156 464 97 203 464 minecraft:deepslate_bricks
fill 95 156 474 95 203 476 minecraft:deepslate_bricks
fill 95 156 486 95 203 488 minecraft:deepslate_bricks
fill 95 156 498 95 203 500 minecraft:deepslate_bricks
fill 100 156 464 112 156 471 minecraft:deepslate_bricks
fill 101 156 504 103 203 504 minecraft:deepslate_bricks
fill 107 156 479 107 157 479 minecraft:gray_concrete
fill 107 156 481 107 157 481 minecraft:gray_concrete
fill 107 156 483 107 157 483 minecraft:gray_concrete
fill 107 156 485 107 157 485 minecraft:gray_concrete
fill 107 156 487 107 157 487 minecraft:gray_concrete
fill 107 156 489 107 157 489 minecraft:gray_concrete
fill 107 156 491 107 157 491 minecraft:gray_concrete
fill 108 156 478 108 157 478 minecraft:gray_concrete
fill 108 156 493 108 157 493 minecraft:gray_concrete
fill 110 156 478 110 157 478 minecraft:gray_concrete
fill 110 156 493 110 157 493 minecraft:gray_concrete
fill 112 156 478 112 157 478 minecraft:gray_concrete
fill 112 156 493 112 157 493 minecraft:gray_concrete
fill 113 156 504 115 203 504 minecraft:deepslate_bricks
fill 114 156 478 114 157 478 minecraft:gray_concrete
fill 114 156 493 114 157 493 minecraft:gray_concrete
fill 116 156 478 116 157 478 minecraft:gray_concrete
fill 116 156 493 116 157 493 minecraft:gray_concrete
fill 118 156 478 118 157 478 minecraft:gray_concrete
fill 118 156 493 118 157 493 minecraft:gray_concrete
fill 119 156 464 121 203 464 minecraft:deepslate_bricks
fill 120 156 478 120 157 478 minecraft:gray_concrete
fill 120 156 493 120 157 493 minecraft:gray_concrete
fill 122 156 479 122 157 479 minecraft:gray_concrete
fill 122 156 481 122 157 481 minecraft:gray_concrete
fill 122 156 483 122 157 483 minecraft:gray_concrete
fill 122 156 485 122 157 485 minecraft:gray_concrete
fill 122 156 487 122 157 487 minecraft:gray_concrete
fill 122 156 489 122 157 489 minecraft:gray_concrete
fill 122 156 491 122 157 491 minecraft:gray_concrete
fill 125 156 504 127 203 504 minecraft:deepslate_bricks
fill 131 156 464 133 203 464 minecraft:deepslate_bricks
fill 135 156 472 135 203 474 minecraft:deepslate_bricks
fill 135 156 484 135 203 486 minecraft:deepslate_bricks
fill 135 156 496 135 203 498 minecraft:deepslate_bricks
setblock 97 157 466 minecraft:light[level=11]
setblock 97 157 474 minecraft:light[level=11]
setblock 97 157 482 minecraft:light[level=11]
setblock 97 157 490 minecraft:light[level=11]
setblock 97 157 498 minecraft:light[level=11]
fill 98 157 480 99 158 488 minecraft:sculk
fill 99 157 477 100 158 479 minecraft:sculk
fill 99 157 489 100 158 491 minecraft:sculk
fill 100 157 464 103 164 471 minecraft:deepslate_bricks
fill 100 157 475 101 158 476 minecraft:sculk
fill 100 157 480 100 158 480 minecraft:sculk
fill 100 157 488 100 158 488 minecraft:sculk
fill 100 157 492 101 158 493 minecraft:sculk
fill 101 157 474 103 158 474 minecraft:sculk
fill 101 157 477 101 158 477 minecraft:sculk
fill 101 157 491 101 158 491 minecraft:sculk
fill 101 157 494 103 158 494 minecraft:sculk
fill 102 157 473 104 158 473 minecraft:sculk
fill 102 157 475 102 158 475 minecraft:sculk
fill 102 157 493 102 158 493 minecraft:sculk
fill 102 157 495 104 158 495 minecraft:sculk
fill 103 157 472 105 158 472 minecraft:sculk
fill 103 157 496 105 158 496 minecraft:sculk
fill 104 157 464 104 164 470 minecraft:deepslate_bricks
fill 104 157 471 106 158 471 minecraft:sculk
fill 104 157 497 106 158 497 minecraft:sculk
fill 105 157 464 105 180 469 minecraft:deepslate_bricks
fill 105 157 470 108 158 470 minecraft:sculk
setblock 105 157 474 minecraft:light[level=11]
setblock 105 157 482 minecraft:light[level=11]
setblock 105 157 490 minecraft:light[level=11]
fill 105 157 498 108 158 498 minecraft:sculk
fill 106 157 464 107 180 468 minecraft:deepslate_bricks
fill 106 157 469 111 158 469 minecraft:sculk
fill 106 157 499 111 158 499 minecraft:sculk
fill 107 157 471 112 180 471 minecraft:deepslate_bricks
fill 108 157 464 110 180 467 minecraft:deepslate_bricks
fill 108 157 468 122 158 468 minecraft:sculk
fill 108 157 500 122 158 500 minecraft:sculk
fill 109 157 470 112 180 470 minecraft:deepslate_bricks
fill 111 157 464 112 164 466 minecraft:deepslate_bricks
fill 111 157 467 119 158 467 minecraft:sculk
fill 111 157 501 119 158 501 minecraft:sculk
fill 112 157 469 112 180 469 minecraft:deepslate_bricks
setblock 113 157 466 minecraft:light[level=11]
setblock 113 157 474 minecraft:light[level=11]
setblock 113 157 498 minecraft:light[level=11]
fill 119 157 469 124 158 469 minecraft:sculk
fill 119 157 499 124 158 499 minecraft:sculk
setblock 121 157 466 minecraft:light[level=11]
setblock 121 157 474 minecraft:light[level=11]
setblock 121 157 498 minecraft:light[level=11]
fill 122 157 470 125 158 470 minecraft:sculk
fill 122 157 498 125 158 498 minecraft:sculk
fill 124 157 471 126 158 471 minecraft:sculk
fill 124 157 497 126 158 497 minecraft:sculk
fill 125 157 472 127 158 472 minecraft:sculk
fill 125 157 496 127 158 496 minecraft:sculk
fill 126 157 473 128 158 473 minecraft:sculk
fill 126 157 495 128 158 495 minecraft:sculk
fill 127 157 474 129 158 474 minecraft:sculk
fill 127 157 494 129 158 494 minecraft:sculk
fill 128 157 475 130 158 475 minecraft:sculk
fill 128 157 493 130 158 493 minecraft:sculk
setblock 129 157 466 minecraft:light[level=11]
fill 129 157 476 130 158 477 minecraft:sculk
setblock 129 157 482 minecraft:light[level=11]
setblock 129 157 490 minecraft:light[level=11]
fill 129 157 491 130 158 492 minecraft:sculk
setblock 129 157 498 minecraft:light[level=11]
fill 130 157 478 131 158 480 minecraft:sculk
fill 130 157 488 131 158 490 minecraft:sculk
fill 131 157 477 131 158 477 minecraft:sculk
fill 131 157 481 132 158 487 minecraft:sculk
fill 131 157 491 131 158 491 minecraft:sculk
fill 132 157 480 132 158 480 minecraft:sculk
fill 132 157 488 132 158 488 minecraft:sculk
setblock 107 158 479 minecraft:light_blue_stained_glass
setblock 107 158 481 minecraft:light_blue_stained_glass
setblock 107 158 483 minecraft:light_blue_stained_glass
setblock 107 158 485 minecraft:light_blue_stained_glass
setblock 107 158 487 minecraft:black_stained_glass
setblock 107 158 489 minecraft:black_stained_glass
setblock 107 158 491 minecraft:black_stained_glass
setblock 108 158 478 minecraft:black_stained_glass
setblock 108 158 493 minecraft:black_stained_glass
setblock 110 158 478 minecraft:sea_lantern
setblock 110 158 493 minecraft:light_blue_stained_glass
setblock 112 158 478 minecraft:black_stained_glass
setblock 112 158 493 minecraft:sea_lantern
setblock 114 158 478 minecraft:black_stained_glass
setblock 114 158 493 minecraft:black_stained_glass
setblock 116 158 478 minecraft:black_stained_glass
setblock 116 158 493 minecraft:light_blue_stained_glass
setblock 118 158 478 minecraft:sea_lantern
setblock 118 158 493 minecraft:black_stained_glass
setblock 120 158 478 minecraft:black_stained_glass
setblock 120 158 493 minecraft:black_stained_glass
setblock 122 158 479 minecraft:light_blue_stained_glass
setblock 122 158 481 minecraft:black_stained_glass
setblock 122 158 483 minecraft:light_blue_stained_glass
setblock 122 158 485 minecraft:sea_lantern
setblock 122 158 487 minecraft:sea_lantern
setblock 122 158 489 minecraft:black_stained_glass
setblock 122 158 491 minecraft:sea_lantern
fill 104 159 471 106 160 471 minecraft:deepslate_bricks
fill 105 159 470 108 160 470 minecraft:deepslate_bricks
fill 106 159 469 111 160 469 minecraft:deepslate_bricks
fill 107 159 479 107 160 479 minecraft:gray_concrete
fill 107 159 481 107 160 481 minecraft:gray_concrete
fill 107 159 483 107 160 483 minecraft:gray_concrete
fill 107 159 485 107 160 485 minecraft:gray_concrete
fill 107 159 487 107 160 487 minecraft:gray_concrete
fill 107 159 489 107 160 489 minecraft:gray_concrete
fill 107 159 491 107 160 491 minecraft:gray_concrete
fill 108 159 468 112 160 468 minecraft:deepslate_bricks
fill 108 159 478 108 160 478 minecraft:gray_concrete
fill 108 159 493 108 160 493 minecraft:gray_concrete
fill 110 159 478 110 160 478 minecraft:gray_concrete
fill 110 159 493 110 160 493 minecraft:gray_concrete
fill 111 159 467 112 160 467 minecraft:deepslate_bricks
fill 112 159 478 112 160 478 minecraft:gray_concrete
fill 112 159 493 112 160 493 minecraft:gray_concrete
fill 114 159 478 114 160 478 minecraft:gray_concrete
fill 114 159 493 114 160 493 minecraft:gray_concrete
fill 116 159 478 116 160 478 minecraft:gray_concrete
fill 116 159 493 116 160 493 minecraft:gray_concrete
fill 118 159 478 118 160 478 minecraft:gray_concrete
fill 118 159 493 118 160 493 minecraft:gray_concrete
fill 120 159 478 120 160 478 minecraft:gray_concrete
fill 120 159 493 120 160 493 minecraft:gray_concrete
fill 122 159 479 122 160 479 minecraft:gray_concrete
fill 122 159 481 122 160 481 minecraft:gray_concrete
fill 122 159 483 122 160 483 minecraft:gray_concrete
fill 122 159 485 122 160 485 minecraft:gray_concrete
fill 122 159 487 122 160 487 minecraft:gray_concrete
fill 122 159 489 122 160 489 minecraft:gray_concrete
fill 122 159 491 122 160 491 minecraft:gray_concrete
fill 96 160 473 96 165 475 minecraft:deepslate_bricks
fill 96 160 485 96 165 487 minecraft:deepslate_bricks
fill 96 160 497 96 165 499 minecraft:deepslate_bricks
fill 102 160 503 104 165 503 minecraft:deepslate_bricks
fill 114 160 503 116 165 503 minecraft:deepslate_bricks
fill 118 160 465 120 165 465 minecraft:deepslate_bricks
fill 126 160 503 128 165 503 minecraft:deepslate_bricks
fill 130 160 465 132 165 465 minecraft:deepslate_bricks
fill 134 160 473 134 165 475 minecraft:deepslate_bricks
fill 134 160 485 134 165 487 minecraft:deepslate_bricks
fill 134 160 497 134 165 499 minecraft:deepslate_bricks
fill 98 161 480 99 162 488 minecraft:sculk
fill 99 161 477 100 162 479 minecraft:sculk
fill 99 161 489 100 162 491 minecraft:sculk
fill 100 161 475 101 162 476 minecraft:sculk
fill 100 161 480 100 162 480 minecraft:sculk
fill 100 161 488 100 162 488 minecraft:sculk
fill 100 161 492 101 162 493 minecraft:sculk
fill 101 161 474 103 162 474 minecraft:sculk
fill 101 161 477 101 162 477 minecraft:sculk
fill 101 161 491 101 162 491 minecraft:sculk
fill 101 161 494 103 162 494 minecraft:sculk
fill 102 161 473 104 162 473 minecraft:sculk
fill 102 161 475 102 162 475 minecraft:sculk
fill 102 161 493 102 162 493 minecraft:sculk
fill 102 161 495 104 162 495 minecraft:sculk
fill 103 161 472 105 162 472 minecraft:sculk
fill 103 161 478 106 203 478 minecraft:deepslate_bricks
fill 103 161 496 105 162 496 minecraft:sculk
fill 104 161 471 106 162 471 minecraft:sculk
fill 104 161 477 105 203 477 minecraft:deepslate_bricks
fill 104 161 479 105 203 479 minecraft:deepslate_bricks
fill 104 161 497 106 162 497 minecraft:sculk
fill 105 161 470 108 162 470 minecraft:sculk
fill 105 161 498 108 162 498 minecraft:sculk
fill 106 161 469 111 162 469 minecraft:sculk
fill 106 161 499 111 162 499 minecraft:sculk
setblock 107 161 479 minecraft:light_blue_stained_glass
setblock 107 161 481 minecraft:sea_lantern
setblock 107 161 483 minecraft:black_stained_glass
setblock 107 161 485 minecraft:black_stained_glass
setblock 107 161 487 minecraft:black_stained_glass
setblock 107 161 489 minecraft:black_stained_glass
setblock 107 161 491 minecraft:light_blue_stained_glass
fill 108 161 468 122 162 468 minecraft:sculk
setblock 108 161 478 minecraft:sea_lantern
setblock 108 161 493 minecraft:black_stained_glass
fill 108 161 500 122 162 500 minecraft:sculk
setblock 110 161 478 minecraft:black_stained_glass
setblock 110 161 493 minecraft:black_stained_glass
fill 111 161 467 119 162 467 minecraft:sculk
fill 111 161 501 119 162 501 minecraft:sculk
setblock 112 161 478 minecraft:sea_lantern
setblock 112 161 493 minecraft:black_stained_glass
setblock 114 161 478 minecraft:sea_lantern
setblock 114 161 493 minecraft:sea_lantern
setblock 116 161 478 minecraft:black_stained_glass
setblock 116 161 493 minecraft:light_blue_stained_glass
setblock 118 161 478 minecraft:sea_lantern
setblock 118 161 493 minecraft:light_blue_stained_glass
fill 119 161 469 124 162 469 minecraft:sculk
fill 119 161 499 124 162 499 minecraft:sculk
setblock 120 161 478 minecraft:black_stained_glass
setblock 120 161 493 minecraft:black_stained_glass
fill 122 161 470 125 162 470 minecraft:sculk
setblock 122 161 479 minecraft:black_stained_glass
setblock 122 161 481 minecraft:light_blue_stained_glass
setblock 122 161 483 minecraft:light_blue_stained_glass
setblock 122 161 485 minecraft:sea_lantern
setblock 122 161 487 minecraft:sea_lantern
setblock 122 161 489 minecraft:black_stained_glass
setblock 122 161 491 minecraft:sea_lantern
fill 122 161 498 125 162 498 minecraft:sculk
fill 124 161 471 126 162 471 minecraft:sculk
fill 124 161 497 126 162 497 minecraft:sculk
fill 125 161 472 127 162 472 minecraft:sculk
fill 125 161 496 127 162 496 minecraft:sculk
fill 126 161 473 128 162 473 minecraft:sculk
fill 126 161 495 128 162 495 minecraft:sculk
fill 127 161 474 129 162 474 minecraft:sculk
fill 127 161 494 129 162 494 minecraft:sculk
fill 128 161 475 130 162 475 minecraft:sculk
fill 128 161 493 130 162 493 minecraft:sculk
fill 129 161 476 130 162 477 minecraft:sculk
fill 129 161 491 130 162 492 minecraft:sculk
fill 130 161 478 131 162 480 minecraft:sculk
fill 130 161 488 131 162 490 minecraft:sculk
fill 131 161 477 131 162 477 minecraft:sculk
fill 131 161 481 132 162 487 minecraft:sculk
fill 131 161 491 131 162 491 minecraft:sculk
fill 132 161 480 132 162 480 minecraft:sculk
fill 132 161 488 132 162 488 minecraft:sculk
fill 103 162 477 103 163 477 minecraft:sculk
fill 103 162 479 103 163 479 minecraft:sculk
fill 104 162 476 105 163 476 minecraft:sculk
fill 104 162 480 105 163 480 minecraft:sculk
fill 106 162 477 106 163 477 minecraft:sculk
fill 106 162 479 106 163 479 minecraft:sculk
fill 107 162 479 107 163 479 minecraft:gray_concrete
fill 107 162 481 107 163 481 minecraft:gray_concrete
fill 107 162 483 107 163 483 minecraft:gray_concrete
fill 107 162 485 107 163 485 minecraft:gray_concrete
fill 107 162 487 107 163 487 minecraft:gray_concrete
fill 107 162 489 107 163 489 minecraft:gray_concrete
fill 107 162 491 107 163 491 minecraft:gray_concrete
fill 108 162 478 108 163 478 minecraft:gray_concrete
fill 108 162 493 108 163 493 minecraft:gray_concrete
fill 110 162 478 110 163 478 minecraft:gray_concrete
fill 110 162 493 110 163 493 minecraft:gray_concrete
fill 112 162 478 112 163 478 minecraft:gray_concrete
fill 112 162 493 112 163 493 minecraft:gray_concrete
fill 114 162 478 114 163 478 minecraft:gray_concrete
fill 114 162 493 114 163 493 minecraft:gray_concrete
fill 116 162 478 116 163 478 minecraft:gray_concrete
fill 116 162 493 116 163 493 minecraft:gray_concrete
fill 118 162 478 118 163 478 minecraft:gray_concrete
fill 118 162 493 118 163 493 minecraft:gray_concrete
fill 120 162 478 120 163 478 minecraft:gray_concrete
fill 120 162 493 120 163 493 minecraft:gray_concrete
fill 122 162 479 122 163 479 minecraft:gray_concrete
fill 122 162 481 122 163 481 minecraft:gray_concrete
fill 122 162 483 122 163 483 minecraft:gray_concrete
fill 122 162 485 122 163 485 minecraft:gray_concrete
fill 122 162 487 122 163 487 minecraft:gray_concrete
fill 122 162 489 122 163 489 minecraft:gray_concrete
fill 122 162 491 122 163 491 minecraft:gray_concrete
fill 95 163 478 95 164 478 minecraft:cyan_concrete
fill 102 163 477 102 163 479 minecraft:sculk
setblock 103 163 476 minecraft:sculk
setblock 103 163 480 minecraft:sculk
fill 104 163 471 106 164 471 minecraft:deepslate_bricks
fill 105 163 470 108 164 470 minecraft:deepslate_bricks
fill 106 163 469 111 164 469 minecraft:deepslate_bricks
setblock 106 163 476 minecraft:sculk
setblock 106 163 480 minecraft:sculk
setblock 107 163 477 minecraft:sculk
fill 108 163 468 112 164 468 minecraft:deepslate_bricks
fill 111 163 467 112 164 467 minecraft:deepslate_bricks
fill 96 164 478 98 164 478 minecraft:cyan_concrete
setblock 107 164 479 minecraft:black_stained_glass
setblock 107 164 481 minecraft:sea_lantern
setblock 107 164 483 minecraft:black_stained_glass
setblock 107 164 485 minecraft:black_stained_glass
setblock 107 164 487 minecraft:light_blue_stained_glass
setblock 107 164 489 minecraft:light_blue_stained_glass
setblock 107 164 491 minecraft:sea_lantern
setblock 108 164 478 minecraft:black_stained_glass
setblock 108 164 493 minecraft:black_stained_glass
setblock 110 164 478 minecraft:black_stained_glass
setblock 110 164 493 minecraft:light_blue_stained_glass
setblock 112 164 478 minecraft:black_stained_glass
setblock 112 164 493 minecraft:black_stained_glass
setblock 114 164 478 minecraft:light_blue_stained_glass
setblock 114 164 493 minecraft:black_stained_glass
setblock 116 164 478 minecraft:black_stained_glass
setblock 116 164 493 minecraft:black_stained_glass
setblock 118 164 478 minecraft:light_blue_stained_glass
setblock 118 164 493 minecraft:light_blue_stained_glass
setblock 120 164 478 minecraft:black_stained_glass
setblock 120 164 493 minecraft:black_stained_glass
setblock 122 164 479 minecraft:light_blue_stained_glass
setblock 122 164 481 minecraft:light_blue_stained_glass
setblock 122 164 483 minecraft:black_stained_glass
setblock 122 164 485 minecraft:light_blue_stained_glass
setblock 122 164 487 minecraft:black_stained_glass
setblock 122 164 489 minecraft:light_blue_stained_glass
setblock 122 164 491 minecraft:black_stained_glass
fill 95 165 467 95 165 472 minecraft:sculk
fill 95 165 479 95 165 484 minecraft:sculk
fill 95 165 491 95 165 496 minecraft:sculk
fill 95 165 503 95 165 504 minecraft:sculk
fill 96 165 504 99 165 504 minecraft:sculk
setblock 97 165 466 minecraft:light[level=11]
setblock 97 165 474 minecraft:light[level=11]
fill 97 165 478 98 165 478 minecraft:cyan_concrete
setblock 97 165 482 minecraft:light[level=11]
setblock 97 165 490 minecraft:light[level=11]
setblock 97 165 498 minecraft:light[level=11]
fill 98 165 480 99 166 488 minecraft:sculk
fill 99 165 464 104 165 464 minecraft:sculk
fill 99 165 477 100 166 479 minecraft:sculk
fill 99 165 489 100 166 491 minecraft:sculk
fill 100 165 465 103 180 471 minecraft:deepslate_bricks
fill 100 165 475 101 166 476 minecraft:sculk
fill 100 165 480 100 166 480 minecraft:sculk
fill 100 165 488 100 166 488 minecraft:sculk
fill 100 165 492 101 166 493 minecraft:sculk
fill 101 165 474 103 166 474 minecraft:sculk
fill 101 165 477 101 166 477 minecraft:sculk
fill 101 165 491 101 166 491 minecraft:sculk
fill 101 165 494 103 166 494 minecraft:sculk
fill 102 165 473 104 166 473 minecraft:sculk
fill 102 165 475 102 166 475 minecraft:sculk
fill 102 165 493 102 166 493 minecraft:sculk
fill 102 165 495 104 166 495 minecraft:sculk
fill 103 165 472 105 166 472 minecraft:sculk
fill 103 165 496 105 166 496 minecraft:sculk
fill 104 165 465 104 180 470 minecraft:deepslate_bricks
fill 104 165 471 106 166 471 minecraft:sculk
fill 104 165 497 106 166 497 minecraft:sculk
fill 105 165 470 108 166 470 minecraft:sculk
setblock 105 165 474 minecraft:light[level=11]
setblock 105 165 482 minecraft:light[level=11]
setblock 105 165 490 minecraft:light[level=11]
fill 105 165 498 108 166 498 minecraft:sculk
fill 106 165 469 111 166 469 minecraft:sculk
fill 106 165 499 111 166 499 minecraft:sculk
fill 106 165 504 111 165 504 minecraft:sculk
fill 107 165 479 107 168 479 minecraft:gray_concrete
fill 107 165 481 107 168 481 minecraft:gray_concrete
fill 107 165 483 107 168 483 minecraft:gray_concrete
fill 107 165 485 107 168 485 minecraft:gray_concrete
fill 107 165 487 107 168 487 minecraft:gray_concrete
fill 107 165 489 107 168 489 minecraft:gray_concrete
fill 107 165 491 107 168 491 minecraft:gray_concrete
fill 108 165 468 122 166 468 minecraft:sculk
fill 108 165 478 108 167 478 minecraft:gray_concrete
fill 108 165 493 108 168 493 minecraft:gray_concrete
fill 108 165 500 122 166 500 minecraft:sculk
fill 110 165 478 110 167 478 minecraft:gray_concrete
fill 110 165 493 110 168 493 minecraft:gray_concrete
fill 111 165 464 116 165 464 minecraft:sculk
fill 111 165 465 112 180 466 minecraft:deepslate_bricks
fill 111 165 467 119 166 467 minecraft:sculk
fill 111 165 501 119 166 501 minecraft:sculk
fill 112 165 478 112 167 478 minecraft:gray_concrete
fill 112 165 493 112 168 493 minecraft:gray_concrete
setblock 113 165 466 minecraft:light[level=11]
setblock 113 165 474 minecraft:light[level=11]
setblock 113 165 498 minecraft:light[level=11]
fill 114 165 478 114 167 478 minecraft:gray_concrete
fill 114 165 493 114 168 493 minecraft:gray_concrete
fill 116 165 478 116 167 478 minecraft:gray_concrete
fill 116 165 493 116 168 493 minecraft:gray_concrete
fill 118 165 478 118 167 478 minecraft:gray_concrete
fill 118 165 493 118 168 493 minecraft:gray_concrete
fill 118 165 504 123 165 504 minecraft:sculk
fill 119 165 469 124 166 469 minecraft:sculk
fill 119 165 499 124 166 499 minecraft:sculk
fill 120 165 478 120 167 478 minecraft:gray_concrete
fill 120 165 493 120 168 493 minecraft:gray_concrete
setblock 121 165 466 minecraft:light[level=11]
setblock 121 165 474 minecraft:light[level=11]
setblock 121 165 498 minecraft:light[level=11]
fill 122 165 470 125 166 470 minecraft:sculk
fill 122 165 479 122 168 479 minecraft:gray_concrete
fill 122 165 481 122 168 481 minecraft:gray_concrete
fill 122 165 483 122 168 483 minecraft:gray_concrete
fill 122 165 485 122 168 485 minecraft:gray_concrete
fill 122 165 487 122 168 487 minecraft:gray_concrete
fill 122 165 489 122 168 489 minecraft:gray_concrete
fill 122 165 491 122 168 491 minecraft:gray_concrete
fill 122 165 498 125 166 498 minecraft:sculk
fill 123 165 464 128 165 464 minecraft:sculk
fill 124 165 471 126 166 471 minecraft:sculk
fill 124 165 497 126 166 497 minecraft:sculk
fill 125 165 472 127 166 472 minecraft:sculk
fill 125 165 496 127 166 496 minecraft:sculk
fill 126 165 473 128 166 473 minecraft:sculk
fill 126 165 495 128 166 495 minecraft:sculk
fill 127 165 474 129 166 474 minecraft:sculk
fill 127 165 494 129 166 494 minecraft:sculk
fill 128 165 475 130 166 475 minecraft:sculk
fill 128 165 493 130 166 493 minecraft:sculk
setblock 129 165 466 minecraft:light[level=11]
fill 129 165 476 130 166 477 minecraft:sculk
setblock 129 165 482 minecraft:light[level=11]
setblock 129 165 490 minecraft:light[level=11]
fill 129 165 491 130 166 492 minecraft:sculk
setblock 129 165 498 minecraft:light[level=11]
fill 130 165 478 131 166 480 minecraft:sculk
fill 130 165 488 131 166 490 minecraft:sculk
fill 130 165 504 135 165 504 minecraft:sculk
fill 131 165 477 131 166 477 minecraft:sculk
fill 131 165 481 132 166 487 minecraft:sculk
fill 131 165 491 131 166 491 minecraft:sculk
fill 132 165 480 132 166 480 minecraft:sculk
fill 132 165 488 132 166 488 minecraft:sculk
fill 135 165 464 135 165 469 minecraft:sculk
fill 135 165 476 135 165 481 minecraft:sculk
fill 135 165 488 135 165 493 minecraft:sculk
fill 135 165 500 135 165 503 minecraft:sculk
fill 94 166 469 94 171 472 minecraft:sea_lantern
fill 94 166 481 94 171 484 minecraft:sea_lantern
fill 94 166 493 94 171 496 minecraft:sea_lantern
fill 94 166 505 97 171 505 minecraft:sea_lantern
fill 100 166 464 104 180 464 minecraft:deepslate_bricks
fill 101 166 463 104 171 463 minecraft:sea_lantern
fill 106 166 488 106 166 490 minecraft:sculk
fill 106 166 505 109 171 505 minecraft:sea_lantern
fill 111 166 464 112 180 464 minecraft:deepslate_bricks
fill 113 166 463 116 171 463 minecraft:sea_lantern
fill 118 166 505 121 171 505 minecraft:sea_lantern
fill 125 166 463 128 171 463 minecraft:sea_lantern
fill 130 166 505 133 171 505 minecraft:sea_lantern
fill 136 166 464 136 171 467 minecraft:sea_lantern
fill 136 166 476 136 171 479 minecraft:sea_lantern
fill 136 166 488 136 171 491 minecraft:sea_lantern
fill 136 166 500 136 171 503 minecraft:sea_lantern
fill 104 167 471 106 168 471 minecraft:deepslate_bricks
fill 105 167 470 108 168 470 minecraft:deepslate_bricks
fill 106 167 469 111 168 469 minecraft:deepslate_bricks
fill 108 167 468 112 168 468 minecraft:deepslate_bricks
fill 111 167 467 112 168 467 minecraft:deepslate_bricks
fill 107 168 478 122 168 478 minecraft:yellow_concrete
fill 98 169 480 99 170 488 minecraft:sculk
fill 99 169 477 100 170 479 minecraft:sculk
fill 99 169 489 100 170 491 minecraft:sculk
fill 100 169 475 101 170 476 minecraft:sculk
fill 100 169 480 100 170 480 minecraft:sculk
fill 100 169 488 100 170 488 minecraft:sculk
fill 100 169 492 101 170 493 minecraft:sculk
fill 101 169 474 103 170 474 minecraft:sculk
fill 101 169 477 101 170 477 minecraft:sculk
fill 101 169 491 101 170 491 minecraft:sculk
fill 101 169 494 103 170 494 minecraft:sculk
fill 102 169 473 104 170 473 minecraft:sculk
fill 102 169 475 102 170 475 minecraft:sculk
fill 102 169 493 102 170 493 minecraft:sculk
fill 102 169 495 104 170 495 minecraft:sculk
fill 103 169 472 105 170 472 minecraft:sculk
fill 103 169 496 105 170 496 minecraft:sculk
fill 104 169 471 106 170 471 minecraft:sculk
fill 104 169 497 106 170 497 minecraft:sculk
fill 105 169 470 108 170 470 minecraft:sculk
fill 105 169 498 108 170 498 minecraft:sculk
fill 106 169 469 111 170 469 minecraft:sculk
fill 106 169 499 111 170 499 minecraft:sculk
fill 107 169 489 109 203 489 minecraft:deepslate_bricks
fill 108 169 468 122 170 468 minecraft:sculk
fill 108 169 488 109 203 488 minecraft:deepslate_bricks
fill 108 169 490 109 203 490 minecraft:deepslate_bricks
fill 108 169 500 122 170 500 minecraft:sculk
fill 111 169 467 119 170 467 minecraft:sculk
fill 111 169 501 119 170 501 minecraft:sculk
fill 119 169 469 124 170 469 minecraft:sculk
fill 119 169 499 124 170 499 minecraft:sculk
fill 122 169 470 125 170 470 minecraft:sculk
fill 122 169 498 125 170 498 minecraft:sculk
fill 124 169 471 126 170 471 minecraft:sculk
fill 124 169 497 126 170 497 minecraft:sculk
fill 125 169 472 127 170 472 minecraft:sculk
fill 125 169 496 127 170 496 minecraft:sculk
fill 126 169 473 128 170 473 minecraft:sculk
fill 126 169 495 128 170 495 minecraft:sculk
fill 127 169 474 129 170 474 minecraft:sculk
fill 127 169 494 129 170 494 minecraft:sculk
fill 128 169 475 130 170 475 minecraft:sculk
fill 128 169 493 130 170 493 minecraft:sculk
fill 129 169 476 130 170 477 minecraft:sculk
fill 129 169 491 130 170 492 minecraft:sculk
fill 130 169 478 131 170 480 minecraft:sculk
fill 130 169 488 131 170 490 minecraft:sculk
fill 131 169 477 131 170 477 minecraft:sculk
fill 131 169 481 132 170 487 minecraft:sculk
fill 131 169 491 131 170 491 minecraft:sculk
fill 132 169 480 132 170 480 minecraft:sculk
fill 132 169 488 132 170 488 minecraft:sculk
fill 104 171 471 106 172 471 minecraft:deepslate_bricks
fill 105 171 470 108 172 470 minecraft:deepslate_bricks
fill 106 171 469 111 172 469 minecraft:deepslate_bricks
fill 108 171 468 112 172 468 minecraft:deepslate_bricks
fill 111 171 467 112 172 467 minecraft:deepslate_bricks
fill 94 172 469 94 185 469 minecraft:sculk
fill 94 172 470 94 172 471 minecraft:sea_lantern
fill 94 172 472 94 185 472 minecraft:sculk
fill 94 172 481 94 185 481 minecraft:sculk
fill 94 172 482 94 172 483 minecraft:sea_lantern
fill 94 172 484 94 185 484 minecraft:sculk
fill 94 172 493 94 185 493 minecraft:sculk
fill 94 172 494 94 172 495 minecraft:sea_lantern
fill 94 172 496 94 185 496 minecraft:sculk
fill 94 172 505 94 185 505 minecraft:sculk
fill 95 172 505 96 172 505 minecraft:sea_lantern
fill 97 172 505 97 185 505 minecraft:sculk
fill 101 172 463 101 185 463 minecraft:sculk
fill 102 172 463 103 172 463 minecraft:sea_lantern
fill 104 172 463 104 185 463 minecraft:sculk
fill 106 172 505 106 185 505 minecraft:sculk
fill 107 172 505 108 172 505 minecraft:sea_lantern
fill 109 172 505 109 185 505 minecraft:sculk
fill 113 172 463 113 185 463 minecraft:sculk
fill 114 172 463 115 172 463 minecraft:sea_lantern
fill 116 172 463 116 185 463 minecraft:sculk
fill 118 172 505 118 185 505 minecraft:sculk
fill 119 172 505 120 172 505 minecraft:sea_lantern
fill 121 172 505 121 185 505 minecraft:sculk
fill 125 172 463 125 185 463 minecraft:sculk
fill 126 172 463 127 172 463 minecraft:sea_lantern
fill 128 172 463 128 185 463 minecraft:sculk
fill 130 172 505 130 185 505 minecraft:sculk
fill 131 172 505 132 172 505 minecraft:sea_lantern
fill 133 172 505 133 185 505 minecraft:sculk
fill 134 172 469 134 173 469 minecraft:cyan_concrete
fill 136 172 464 136 185 464 minecraft:sculk
fill 136 172 465 136 172 466 minecraft:sea_lantern
fill 136 172 467 136 185 467 minecraft:sculk
fill 136 172 476 136 185 476 minecraft:sculk
fill 136 172 477 136 172 478 minecraft:sea_lantern
fill 136 172 479 136 185 479 minecraft:sculk
fill 136 172 488 136 185 488 minecraft:sculk
fill 136 172 489 136 172 490 minecraft:sea_lantern
fill 136 172 491 136 185 491 minecraft:sculk
fill 136 172 500 136 185 500 minecraft:sculk
fill 136 172 501 136 172 502 minecraft:sea_lantern
fill 136 172 503 136 185 503 minecraft:sculk
fill 94 173 470 94 185 471 minecraft:sculk
fill 94 173 482 94 185 483 minecraft:sculk
fill 94 173 494 94 185 495 minecraft:sculk
fill 95 173 505 96 185 505 minecraft:sculk
setblock 97 173 466 minecraft:light[level=11]
setblock 97 173 474 minecraft:light[level=11]
setblock 97 173 482 minecraft:light[level=11]
setblock 97 173 490 minecraft:light[level=11]
setblock 97 173 498 minecraft:light[level=11]
fill 98 173 480 99 174 488 minecraft:sculk
fill 99 173 477 100 174 479 minecraft:sculk
fill 99 173 489 100 174 491 minecraft:sculk
fill 100 173 475 101 174 476 minecraft:sculk
fill 100 173 480 100 174 480 minecraft:sculk
fill 100 173 488 100 174 488 minecraft:sculk
fill 100 173 492 101 174 493 minecraft:sculk
fill 101 173 474 103 174 474 minecraft:sculk
fill 101 173 477 101 174 477 minecraft:sculk
fill 101 173 491 101 174 491 minecraft:sculk
fill 101 173 494 103 174 494 minecraft:sculk
fill 102 173 463 103 185 463 minecraft:sculk
fill 102 173 473 104 174 473 minecraft:sculk
fill 102 173 475 102 174 475 minecraft:sculk
fill 102 173 493 102 174 493 minecraft:sculk
fill 102 173 495 104 174 495 minecraft:sculk
fill 103 173 472 105 174 472 minecraft:sculk
fill 103 173 496 105 174 496 minecraft:sculk
fill 104 173 471 106 174 471 minecraft:sculk
fill 104 173 497 106 174 497 minecraft:sculk
fill 105 173 470 108 174 470 minecraft:sculk
setblock 105 173 474 minecraft:light[level=11]
setblock 105 173 482 minecraft:light[level=11]
setblock 105 173 490 minecraft:light[level=11]
fill 105 173 498 108 174 498 minecraft:sculk
fill 106 173 469 111 174 469 minecraft:sculk
fill 106 173 499 111 174 499 minecraft:sculk
fill 107 173 505 108 185 505 minecraft:sculk
fill 108 173 468 122 174 468 minecraft:sculk
fill 108 173 500 122 174 500 minecraft:sculk
fill 111 173 467 119 174 467 minecraft:sculk
fill 111 173 501 119 174 501 minecraft:sculk
setblock 113 173 466 minecraft:light[level=11]
setblock 113 173 474 minecraft:light[level=11]
setblock 113 173 482 minecraft:light[level=11]
setblock 113 173 490 minecraft:light[level=11]
setblock 113 173 498 minecraft:light[level=11]
fill 114 173 463 115 185 463 minecraft:sculk
fill 119 173 469 124 174 469 minecraft:sculk
fill 119 173 499 124 174 499 minecraft:sculk
fill 119 173 505 120 185 505 minecraft:sculk
setblock 121 173 466 minecraft:light[level=11]
setblock 121 173 474 minecraft:light[level=11]
setblock 121 173 482 minecraft:light[level=11]
setblock 121 173 490 minecraft:light[level=11]
setblock 121 173 498 minecraft:light[level=11]
fill 122 173 470 125 174 470 minecraft:sculk
fill 122 173 498 125 174 498 minecraft:sculk
fill 124 173 471 126 174 471 minecraft:sculk
fill 124 173 497 126 174 497 minecraft:sculk
fill 125 173 472 127 174 472 minecraft:sculk
fill 125 173 496 127 174 496 minecraft:sculk
fill 126 173 463 127 185 463 minecraft:sculk
fill 126 173 473 128 174 473 minecraft:sculk
fill 126 173 495 128 174 495 minecraft:sculk
fill 127 173 474 129 174 474 minecraft:sculk
fill 127 173 494 129 174 494 minecraft:sculk
fill 128 173 475 130 174 475 minecraft:sculk
fill 128 173 493 130 174 493 minecraft:sculk
setblock 129 173 466 minecraft:light[level=11]
fill 129 173 476 130 174 477 minecraft:sculk
setblock 129 173 482 minecraft:light[level=11]
setblock 129 173 490 minecraft:light[level=11]
fill 129 173 491 130 174 492 minecraft:sculk
setblock 129 173 498 minecraft:light[level=11]
fill 130 173 478 131 174 480 minecraft:sculk
fill 130 173 488 131 174 490 minecraft:sculk
fill 131 173 477 131 174 477 minecraft:sculk
fill 131 173 481 132 174 487 minecraft:sculk
fill 131 173 491 131 174 491 minecraft:sculk
fill 131 173 505 132 185 505 minecraft:sculk
fill 132 173 480 132 174 480 minecraft:sculk
fill 132 173 488 132 174 488 minecraft:sculk
fill 133 173 469 133 174 469 minecraft:cyan_concrete
fill 136 173 465 136 185 466 minecraft:sculk
fill 136 173 477 136 185 478 minecraft:sculk
fill 136 173 489 136 185 490 minecraft:sculk
fill 136 173 501 136 185 502 minecraft:sculk
fill 131 174 469 132 175 469 minecraft:cyan_concrete
fill 104 175 471 106 180 471 minecraft:deepslate_bricks
fill 105 175 470 108 180 470 minecraft:deepslate_bricks
fill 106 175 469 111 180 469 minecraft:deepslate_bricks
fill 108 175 468 112 180 468 minecraft:deepslate_bricks
fill 111 175 467 112 180 467 minecraft:deepslate_bricks
fill 130 175 469 130 176 469 minecraft:cyan_concrete
fill 129 176 469 129 177 469 minecraft:cyan_concrete
fill 96 180 473 96 185 475 minecraft:deepslate_bricks
fill 96 180 485 96 185 487 minecraft:deepslate_bricks
fill 96 180 497 96 185 499 minecraft:deepslate_bricks
fill 102 180 503 104 185 503 minecraft:deepslate_bricks
fill 114 180 503 116 185 503 minecraft:deepslate_bricks
fill 118 180 465 120 185 465 minecraft:deepslate_bricks
fill 126 180 503 128 185 503 minecraft:deepslate_bricks
fill 130 180 465 132 185 465 minecraft:deepslate_bricks
fill 134 180 473 134 185 475 minecraft:deepslate_bricks
fill 134 180 485 134 185 487 minecraft:deepslate_bricks
fill 134 180 497 134 185 499 minecraft:deepslate_bricks
setblock 97 181 466 minecraft:light[level=11]
setblock 97 181 474 minecraft:light[level=11]
setblock 97 181 482 minecraft:light[level=11]
setblock 97 181 490 minecraft:light[level=11]
setblock 97 181 498 minecraft:light[level=11]
fill 101 181 465 105 181 470 minecraft:cyan_concrete
setblock 105 181 474 minecraft:light[level=11]
setblock 105 181 482 minecraft:light[level=11]
setblock 105 181 490 minecraft:light[level=11]
setblock 105 181 498 minecraft:light[level=11]
fill 106 181 465 108 185 465 minecraft:deepslate_bricks
fill 106 181 466 111 181 470 minecraft:cyan_concrete
fill 107 181 464 109 203 464 minecraft:deepslate_bricks
fill 109 181 465 111 181 465 minecraft:cyan_concrete
setblock 113 181 466 minecraft:light[level=11]
setblock 113 181 474 minecraft:light[level=11]
setblock 113 181 482 minecraft:light[level=11]
setblock 113 181 490 minecraft:light[level=11]
setblock 113 181 498 minecraft:light[level=11]
setblock 121 181 466 minecraft:light[level=11]
setblock 121 181 474 minecraft:light[level=11]
setblock 121 181 482 minecraft:light[level=11]
setblock 121 181 490 minecraft:light[level=11]
setblock 121 181 498 minecraft:light[level=11]
setblock 129 181 466 minecraft:light[level=11]
setblock 129 181 474 minecraft:light[level=11]
setblock 129 181 482 minecraft:light[level=11]
setblock 129 181 490 minecraft:light[level=11]
setblock 129 181 498 minecraft:light[level=11]
fill 102 182 466 110 182 469 minecraft:cyan_concrete
fill 103 183 467 109 183 468 minecraft:cyan_concrete
fill 104 184 467 108 184 468 minecraft:cyan_concrete
fill 95 185 467 95 185 472 minecraft:sculk
fill 95 185 479 95 185 484 minecraft:sculk
fill 95 185 491 95 185 496 minecraft:sculk
fill 95 185 503 95 185 504 minecraft:sculk
fill 96 185 504 99 185 504 minecraft:sculk
fill 99 185 464 104 185 464 minecraft:sculk
fill 106 185 504 111 185 504 minecraft:sculk
fill 111 185 464 116 185 464 minecraft:sculk
fill 118 185 504 123 185 504 minecraft:sculk
fill 123 185 464 128 185 464 minecraft:sculk
fill 130 185 504 135 185 504 minecraft:sculk
fill 135 185 464 135 185 469 minecraft:sculk
fill 135 185 476 135 185 481 minecraft:sculk
fill 135 185 488 135 185 493 minecraft:sculk
fill 135 185 500 135 185 503 minecraft:sculk
fill 94 186 469 94 191 472 minecraft:sea_lantern
fill 94 186 481 94 191 484 minecraft:sea_lantern
fill 94 186 493 94 191 496 minecraft:sea_lantern
fill 94 186 505 97 191 505 minecraft:sea_lantern
fill 101 186 463 104 191 463 minecraft:sea_lantern
fill 106 186 505 109 191 505 minecraft:sea_lantern
fill 113 186 463 116 191 463 minecraft:sea_lantern
fill 118 186 505 121 191 505 minecraft:sea_lantern
fill 125 186 463 128 191 463 minecraft:sea_lantern
fill 130 186 505 133 191 505 minecraft:sea_lantern
fill 136 186 464 136 191 467 minecraft:sea_lantern
fill 136 186 476 136 191 479 minecraft:sea_lantern
fill 136 186 488 136 191 491 minecraft:sea_lantern
fill 136 186 500 136 191 503 minecraft:sea_lantern
setblock 97 189 466 minecraft:light[level=11]
setblock 97 189 474 minecraft:light[level=11]
setblock 97 189 482 minecraft:light[level=11]
setblock 97 189 490 minecraft:light[level=11]
setblock 97 189 498 minecraft:light[level=11]
setblock 105 189 466 minecraft:light[level=11]
setblock 105 189 474 minecraft:light[level=11]
setblock 105 189 482 minecraft:light[level=11]
setblock 105 189 490 minecraft:light[level=11]
setblock 105 189 498 minecraft:light[level=11]
setblock 113 189 466 minecraft:light[level=11]
setblock 113 189 474 minecraft:light[level=11]
setblock 113 189 482 minecraft:light[level=11]
setblock 113 189 490 minecraft:light[level=11]
setblock 113 189 498 minecraft:light[level=11]
setblock 121 189 466 minecraft:light[level=11]
setblock 121 189 474 minecraft:light[level=11]
setblock 121 189 482 minecraft:light[level=11]
setblock 121 189 490 minecraft:light[level=11]
setblock 121 189 498 minecraft:light[level=11]
setblock 129 189 466 minecraft:light[level=11]
setblock 129 189 474 minecraft:light[level=11]
setblock 129 189 482 minecraft:light[level=11]
setblock 129 189 490 minecraft:light[level=11]
setblock 129 189 498 minecraft:light[level=11]
fill 94 192 469 94 203 469 minecraft:sculk
fill 94 192 470 94 192 471 minecraft:sea_lantern
fill 94 192 472 94 201 472 minecraft:sculk
fill 94 192 481 94 199 481 minecraft:sculk
fill 94 192 482 94 192 483 minecraft:sea_lantern
fill 94 192 484 94 203 484 minecraft:sculk
fill 94 192 493 94 200 493 minecraft:sculk
fill 94 192 494 94 192 495 minecraft:sea_lantern
fill 94 192 496 94 203 496 minecraft:sculk
fill 94 192 505 94 204 505 minecraft:sculk
fill 95 192 505 96 192 505 minecraft:sea_lantern
fill 97 192 505 97 203 505 minecraft:sculk
fill 101 192 463 101 203 463 minecraft:sculk
fill 102 192 463 103 192 463 minecraft:sea_lantern
fill 104 192 463 104 203 463 minecraft:sculk
fill 106 192 505 106 204 505 minecraft:sculk
fill 107 192 505 108 192 505 minecraft:sea_lantern
fill 109 192 505 109 200 505 minecraft:sculk
fill 113 192 463 113 203 463 minecraft:sculk
fill 114 192 463 115 192 463 minecraft:sea_lantern
fill 116 192 463 116 201 463 minecraft:sculk
fill 118 192 505 118 199 505 minecraft:sculk
fill 119 192 505 120 192 505 minecraft:sea_lantern
fill 121 192 505 121 200 505 minecraft:sculk
fill 125 192 463 125 199 463 minecraft:sculk
fill 126 192 463 127 192 463 minecraft:sea_lantern
fill 128 192 463 128 203 463 minecraft:sculk
fill 130 192 505 130 203 505 minecraft:sculk
fill 131 192 505 132 192 505 minecraft:sea_lantern
fill 133 192 505 133 201 505 minecraft:sculk
fill 136 192 464 136 203 464 minecraft:sculk
fill 136 192 465 136 192 466 minecraft:sea_lantern
fill 136 192 467 136 203 467 minecraft:sculk
fill 136 192 476 136 203 476 minecraft:sculk
fill 136 192 477 136 192 478 minecraft:sea_lantern
fill 136 192 479 136 199 479 minecraft:sculk
fill 136 192 488 136 203 488 minecraft:sculk
fill 136 192 489 136 192 490 minecraft:sea_lantern
fill 136 192 491 136 200 491 minecraft:sculk
fill 136 192 500 136 203 500 minecraft:sculk
fill 136 192 501 136 192 502 minecraft:sea_lantern
fill 136 192 503 136 203 503 minecraft:sculk
fill 94 193 470 94 203 471 minecraft:sculk
fill 94 193 482 94 203 483 minecraft:sculk
fill 94 193 494 94 201 495 minecraft:sculk
fill 95 193 505 96 199 505 minecraft:sculk
fill 102 193 463 103 201 463 minecraft:sculk
fill 107 193 505 108 203 505 minecraft:sculk
fill 114 193 463 115 203 463 minecraft:sculk
fill 119 193 505 120 201 505 minecraft:sculk
fill 126 193 463 127 199 463 minecraft:sculk
fill 131 193 505 132 199 505 minecraft:sculk
fill 136 193 465 136 199 466 minecraft:sculk
fill 136 193 477 136 203 478 minecraft:sculk
fill 136 193 489 136 203 490 minecraft:sculk
fill 136 193 501 136 203 502 minecraft:sculk
fill 130 196 488 130 197 488 minecraft:cyan_stained_glass
setblock 97 197 466 minecraft:light[level=11]
setblock 97 197 474 minecraft:light[level=11]
setblock 97 197 482 minecraft:light[level=11]
setblock 97 197 490 minecraft:light[level=11]
setblock 97 197 498 minecraft:light[level=11]
setblock 105 197 466 minecraft:light[level=11]
setblock 105 197 474 minecraft:light[level=11]
setblock 105 197 482 minecraft:light[level=11]
setblock 105 197 490 minecraft:light[level=11]
setblock 105 197 498 minecraft:light[level=11]
setblock 113 197 466 minecraft:light[level=11]
setblock 113 197 474 minecraft:light[level=11]
setblock 113 197 482 minecraft:light[level=11]
setblock 113 197 490 minecraft:light[level=11]
setblock 113 197 498 minecraft:light[level=11]
setblock 121 197 466 minecraft:light[level=11]
setblock 121 197 474 minecraft:light[level=11]
setblock 121 197 482 minecraft:light[level=11]
setblock 121 197 490 minecraft:light[level=11]
setblock 121 197 498 minecraft:light[level=11]
setblock 129 197 466 minecraft:light[level=11]
setblock 129 197 474 minecraft:light[level=11]
setblock 129 197 482 minecraft:light[level=11]
setblock 129 197 490 minecraft:light[level=11]
setblock 129 197 498 minecraft:light[level=11]
fill 131 197 488 134 198 488 minecraft:cyan_stained_glass
fill 132 198 487 135 198 487 minecraft:cyan_stained_glass
fill 132 198 489 135 198 489 minecraft:cyan_stained_glass
fill 135 198 488 135 199 488 minecraft:cyan_stained_glass
fill 133 199 487 134 199 489 minecraft:cyan_stained_glass
setblock 135 199 487 minecraft:cyan_stained_glass
setblock 135 199 489 minecraft:cyan_stained_glass
fill 94 200 463 94 203 464 minecraft:sculk
fill 94 200 465 94 200 466 minecraft:deepslate_tiles
fill 94 200 467 94 203 467 minecraft:sculk
fill 94 200 476 94 204 476 minecraft:sculk
fill 94 200 477 94 201 477 minecraft:deepslate_tiles
setblock 94 200 481 minecraft:deepslate_tiles
fill 94 200 485 94 200 486 minecraft:deepslate_tiles
setblock 94 200 504 minecraft:deepslate_tiles
fill 95 200 505 95 203 505 minecraft:sculk
fill 96 200 473 96 203 475 minecraft:deepslate_bricks
fill 96 200 485 96 203 487 minecraft:deepslate_bricks
fill 96 200 497 96 203 499 minecraft:deepslate_bricks
setblock 96 200 505 minecraft:deepslate_tiles
fill 99 200 463 99 201 463 minecraft:deepslate_tiles
fill 102 200 476 102 200 479 minecraft:cyan_concrete
fill 102 200 503 104 203 503 minecraft:deepslate_bricks
setblock 102 200 505 minecraft:deepslate_tiles
fill 103 200 476 103 201 477 minecraft:cyan_concrete
fill 103 200 479 103 201 480 minecraft:cyan_concrete
fill 103 200 505 103 201 505 minecraft:sculk
fill 104 200 475 105 200 476 minecraft:cyan_concrete
fill 104 200 480 104 200 481 minecraft:cyan_concrete
setblock 104 200 505 minecraft:deepslate_tiles
fill 105 200 480 106 201 480 minecraft:cyan_concrete
fill 106 200 465 108 203 465 minecraft:deepslate_bricks
fill 106 200 476 106 201 477 minecraft:cyan_concrete
fill 106 200 479 107 200 479 minecraft:cyan_concrete
fill 106 200 488 106 200 490 minecraft:cyan_concrete
fill 107 200 477 107 200 478 minecraft:cyan_concrete
fill 107 200 487 107 201 488 minecraft:cyan_concrete
fill 107 200 490 107 200 491 minecraft:cyan_concrete
setblock 108 200 463 minecraft:deepslate_tiles
fill 108 200 486 108 200 487 minecraft:cyan_concrete
fill 108 200 491 110 200 491 minecraft:cyan_concrete
fill 109 200 463 109 204 463 minecraft:sculk
fill 109 200 487 110 201 487 minecraft:cyan_concrete
fill 110 200 488 111 200 490 minecraft:cyan_concrete
fill 111 200 505 112 200 505 minecraft:sculk
setblock 113 200 505 minecraft:deepslate_tiles
fill 114 200 503 116 203 503 minecraft:deepslate_bricks
fill 114 200 505 114 203 505 minecraft:sculk
setblock 117 200 463 minecraft:deepslate_tiles
fill 118 200 463 118 204 463 minecraft:sculk
fill 118 200 465 120 203 465 minecraft:deepslate_bricks
setblock 118 200 505 minecraft:deepslate_tiles
fill 119 200 463 119 202 463 minecraft:deepslate_tiles
fill 120 200 463 122 203 463 minecraft:sculk
fill 124 200 463 125 200 463 minecraft:deepslate_tiles
fill 126 200 463 126 203 463 minecraft:sculk
fill 126 200 503 128 203 503 minecraft:deepslate_bricks
setblock 127 200 463 minecraft:deepslate_tiles
fill 129 200 463 130 203 463 minecraft:sculk
fill 130 200 465 132 203 465 minecraft:deepslate_bricks
setblock 131 200 463 minecraft:deepslate_tiles
setblock 131 200 505 minecraft:deepslate_tiles
fill 132 200 463 132 203 463 minecraft:sculk
fill 132 200 505 132 203 505 minecraft:sculk
fill 134 200 463 134 203 463 minecraft:sculk
fill 134 200 473 134 203 475 minecraft:deepslate_bricks
fill 134 200 485 134 203 487 minecraft:deepslate_bricks
setblock 134 200 488 minecraft:cyan_stained_glass
fill 134 200 497 134 203 499 minecraft:deepslate_bricks
setblock 135 200 463 minecraft:deepslate_tiles
fill 136 200 465 136 203 465 minecraft:sculk
setblock 136 200 466 minecraft:deepslate_tiles
setblock 136 200 472 minecraft:deepslate_tiles
fill 136 200 473 136 203 473 minecraft:sculk
setblock 136 200 479 minecraft:deepslate_tiles
fill 94 201 465 94 201 466 minecraft:sculk
setblock 94 201 468 minecraft:deepslate_tiles
fill 94 201 481 94 203 481 minecraft:sculk
fill 94 201 485 94 203 486 minecraft:sculk
setblock 94 201 493 minecraft:deepslate_tiles
fill 94 201 504 94 203 504 minecraft:sculk
setblock 95 201 463 minecraft:deepslate_tiles
fill 96 201 463 98 203 463 minecraft:sculk
fill 96 201 505 96 203 505 minecraft:sculk
fill 102 201 477 102 201 478 minecraft:cyan_concrete
fill 102 201 505 102 203 505 minecraft:sculk
fill 104 201 476 105 202 476 minecraft:cyan_concrete
fill 104 201 480 104 202 480 minecraft:cyan_concrete
fill 104 201 505 104 204 505 minecraft:sculk
setblock 105 201 505 minecraft:deepslate_tiles
fill 106 201 479 106 202 479 minecraft:cyan_concrete
setblock 107 201 478 minecraft:cyan_concrete
fill 107 201 490 107 202 490 minecraft:cyan_concrete
setblock 108 201 463 minecraft:sculk
fill 108 201 487 108 202 487 minecraft:cyan_concrete
fill 108 201 491 109 201 491 minecraft:cyan_concrete
setblock 109 201 505 minecraft:deepslate_tiles
fill 110 201 488 110 202 490 minecraft:cyan_concrete
fill 111 201 505 111 203 505 minecraft:sculk
setblock 112 201 505 minecraft:deepslate_tiles
fill 113 201 505 113 203 505 minecraft:sculk
fill 116 201 505 116 203 505 minecraft:sculk
setblock 117 201 463 minecraft:sculk
setblock 117 201 505 minecraft:deepslate_tiles
fill 118 201 505 118 203 505 minecraft:sculk
setblock 121 201 505 minecraft:deepslate_tiles
fill 124 201 463 125 201 463 minecraft:sculk
setblock 124 201 505 minecraft:deepslate_tiles
setblock 127 201 463 minecraft:sculk
fill 131 201 463 131 203 463 minecraft:sculk
fill 131 201 505 131 203 505 minecraft:sculk
fill 135 201 463 135 203 463 minecraft:sculk
fill 136 201 466 136 204 466 minecraft:sculk
setblock 136 201 471 minecraft:deepslate_tiles
fill 136 201 472 136 203 472 minecraft:sculk
fill 136 201 479 136 203 479 minecraft:sculk
setblock 136 201 480 minecraft:deepslate_tiles
fill 136 201 481 136 201 485 minecraft:sculk
setblock 136 201 491 minecraft:deepslate_tiles
fill 136 201 495 136 203 495 minecraft:sculk
setblock 136 201 496 minecraft:deepslate_tiles
fill 136 201 497 136 203 499 minecraft:sculk
setblock 94 202 465 minecraft:deepslate_tiles
fill 94 202 466 94 204 466 minecraft:sculk
fill 94 202 468 94 203 468 minecraft:sculk
setblock 94 202 472 minecraft:deepslate_tiles
fill 94 202 477 94 203 477 minecraft:sculk
fill 94 202 493 94 203 494 minecraft:sculk
setblock 94 202 495 minecraft:deepslate_tiles
fill 94 202 497 94 202 498 minecraft:deepslate_tiles
setblock 94 202 501 minecraft:deepslate_tiles
fill 95 202 463 95 203 463 minecraft:sculk
fill 99 202 463 99 203 463 minecraft:sculk
setblock 100 202 463 minecraft:deepslate_tiles
setblock 102 202 463 minecraft:deepslate_tiles
fill 103 202 463 103 203 463 minecraft:sculk
setblock 103 202 477 minecraft:cyan_concrete
setblock 103 202 479 minecraft:cyan_concrete
setblock 103 202 505 minecraft:deepslate_tiles
fill 105 202 505 105 203 505 minecraft:sculk
fill 106 202 463 106 203 463 minecraft:sculk
setblock 106 202 477 minecraft:cyan_concrete
fill 107 202 463 108 202 463 minecraft:deepslate_tiles
setblock 107 202 488 minecraft:cyan_concrete
setblock 109 202 487 minecraft:cyan_concrete
fill 109 202 505 109 203 505 minecraft:sculk
setblock 110 202 463 minecraft:deepslate_tiles
fill 111 202 463 112 203 463 minecraft:sculk
fill 112 202 505 112 203 505 minecraft:sculk
fill 116 202 463 117 202 463 minecraft:deepslate_tiles
fill 117 202 505 117 203 505 minecraft:sculk
fill 119 202 505 119 203 505 minecraft:sculk
setblock 120 202 505 minecraft:deepslate_tiles
fill 121 202 505 121 203 505 minecraft:sculk
fill 124 202 463 124 203 463 minecraft:sculk
fill 124 202 505 124 203 505 minecraft:sculk
setblock 125 202 463 minecraft:deepslate_tiles
setblock 125 202 505 minecraft:deepslate_tiles
fill 126 202 505 126 203 505 minecraft:sculk
setblock 127 202 463 minecraft:deepslate_tiles
fill 133 202 505 134 202 505 minecraft:deepslate_tiles
fill 135 202 505 136 203 505 minecraft:sculk
fill 136 202 471 136 203 471 minecraft:sculk
setblock 136 202 475 minecraft:deepslate_tiles
fill 136 202 480 136 203 483 minecraft:sculk
setblock 136 202 484 minecraft:deepslate_tiles
fill 136 202 485 136 203 485 minecraft:sculk
fill 136 202 491 136 203 491 minecraft:sculk
fill 136 202 496 136 203 496 minecraft:sculk
setblock 94 203 465 minecraft:sculk
setblock 94 203 472 minecraft:sculk
setblock 94 203 495 minecraft:sculk
fill 94 203 497 94 203 498 minecraft:sculk
setblock 94 203 501 minecraft:sculk
setblock 100 203 463 minecraft:sculk
fill 102 203 463 102 205 463 minecraft:sculk
setblock 103 203 505 minecraft:sculk
fill 107 203 463 108 203 463 minecraft:sculk
setblock 110 203 463 minecraft:sculk
fill 116 203 463 117 203 463 minecraft:sculk
fill 119 203 463 119 204 463 minecraft:sculk
setblock 120 203 505 minecraft:sculk
setblock 125 203 463 minecraft:sculk
setblock 125 203 505 minecraft:sculk
setblock 127 203 463 minecraft:sculk
fill 133 203 505 134 203 505 minecraft:sculk
setblock 136 203 475 minecraft:sculk
setblock 136 203 484 minecraft:sculk
setblock 94 204 463 minecraft:sculk
fill 94 204 464 94 307 465 minecraft:deepslate_tiles
fill 94 204 467 94 225 473 minecraft:deepslate_tiles
fill 94 204 474 94 205 474 minecraft:sculk
fill 94 204 475 94 307 475 minecraft:deepslate_tiles
fill 94 204 477 94 204 501 minecraft:deepslate_tiles
setblock 94 204 502 minecraft:sculk
fill 94 204 503 94 307 504 minecraft:deepslate_tiles
fill 95 204 463 101 225 463 minecraft:deepslate_tiles
fill 95 204 505 97 225 505 minecraft:deepslate_tiles
setblock 98 204 505 minecraft:sculk
fill 99 204 505 103 204 505 minecraft:deepslate_tiles
fill 103 204 463 107 225 463 minecraft:deepslate_tiles
fill 105 204 505 105 307 505 minecraft:deepslate_tiles
setblock 107 204 505 minecraft:sculk
setblock 108 204 463 minecraft:sculk
fill 108 204 505 132 204 505 minecraft:deepslate_tiles
fill 110 204 463 116 225 463 minecraft:deepslate_tiles
setblock 117 204 463 minecraft:sculk
fill 120 204 463 121 204 463 minecraft:sculk
fill 122 204 463 129 225 463 minecraft:deepslate_tiles
setblock 130 204 463 minecraft:sculk
fill 131 204 463 136 307 463 minecraft:deepslate_tiles
setblock 133 204 505 minecraft:sculk
fill 134 204 505 136 307 505 minecraft:deepslate_tiles
fill 136 204 464 136 205 465 minecraft:deepslate_tiles
fill 136 204 467 136 204 500 minecraft:deepslate_tiles
setblock 136 204 501 minecraft:sculk
fill 136 204 502 136 205 504 minecraft:deepslate_tiles
fill 94 205 463 94 307 463 minecraft:deepslate_tiles
fill 94 205 466 94 307 466 minecraft:deepslate_tiles
fill 94 205 476 94 225 483 minecraft:deepslate_tiles
setblock 94 205 484 minecraft:sculk
fill 94 205 485 94 205 487 minecraft:deepslate_tiles
fill 94 205 488 94 205 489 minecraft:sculk
fill 94 205 490 94 307 492 minecraft:deepslate_tiles
setblock 94 205 493 minecraft:sculk
fill 94 205 494 94 205 502 minecraft:deepslate_tiles
fill 94 205 505 94 225 505 minecraft:deepslate_tiles
setblock 97 205 466 minecraft:light[level=11]
setblock 97 205 474 minecraft:light[level=11]
setblock 97 205 482 minecraft:light[level=11]
setblock 97 205 490 minecraft:light[level=11]
setblock 97 205 498 minecraft:light[level=11]
fill 98 205 505 99 307 505 minecraft:deepslate_tiles
setblock 100 205 505 minecraft:sculk
fill 101 205 505 101 307 505 minecraft:deepslate_tiles
setblock 102 205 505 minecraft:sculk
fill 103 205 505 104 307 505 minecraft:deepslate_tiles
setblock 105 205 466 minecraft:light[level=11]
setblock 105 205 474 minecraft:light[level=11]
setblock 105 205 482 minecraft:light[level=11]
setblock 105 205 490 minecraft:light[level=11]
setblock 105 205 498 minecraft:light[level=11]
fill 106 205 505 111 205 505 minecraft:deepslate_tiles
fill 108 205 463 109 307 463 minecraft:deepslate_tiles
setblock 112 205 505 minecraft:sculk
setblock 113 205 466 minecraft:light[level=11]
setblock 113 205 474 minecraft:light[level=11]
setblock 113 205 482 minecraft:light[level=11]
setblock 113 205 490 minecraft:light[level=11]
setblock 113 205 498 minecraft:light[level=11]
fill 113 205 505 118 225 505 minecraft:deepslate_tiles
fill 117 205 463 121 205 463 minecraft:deepslate_tiles
setblock 119 205 505 minecraft:sculk
fill 120 205 505 122 225 505 minecraft:deepslate_tiles
setblock 121 205 466 minecraft:light[level=11]
setblock 121 205 474 minecraft:light[level=11]
setblock 121 205 482 minecraft:light[level=11]
setblock 121 205 490 minecraft:light[level=11]
setblock 121 205 498 minecraft:light[level=11]
setblock 123 205 505 minecraft:sculk
fill 124 205 505 133 205 505 minecraft:deepslate_tiles
setblock 129 205 466 minecraft:light[level=11]
setblock 129 205 474 minecraft:light[level=11]
setblock 129 205 482 minecraft:light[level=11]
setblock 129 205 490 minecraft:light[level=11]
setblock 129 205 498 minecraft:light[level=11]
setblock 130 205 463 minecraft:deepslate_tiles
fill 136 205 466 136 225 471 minecraft:deepslate_tiles
setblock 136 205 472 minecraft:sculk
fill 136 205 473 136 307 474 minecraft:deepslate_tiles
setblock 136 205 475 minecraft:sculk
fill 136 205 476 136 205 482 minecraft:deepslate_tiles
setblock 136 205 483 minecraft:sculk
fill 136 205 484 136 225 490 minecraft:deepslate_tiles
setblock 136 205 491 minecraft:sculk
fill 136 205 492 136 205 501 minecraft:deepslate_tiles
fill 94 206 474 94 307 474 minecraft:deepslate_tiles
fill 94 206 484 94 225 485 minecraft:deepslate_tiles
setblock 94 206 486 minecraft:sculk
fill 94 206 487 94 307 488 minecraft:deepslate_tiles
setblock 94 206 489 minecraft:sculk
fill 94 206 493 94 225 495 minecraft:deepslate_tiles
fill 94 206 496 94 206 497 minecraft:sculk
fill 94 206 498 94 307 501 minecraft:deepslate_tiles
setblock 94 206 502 minecraft:sculk
fill 100 206 505 100 307 505 minecraft:deepslate_tiles
fill 102 206 463 102 225 463 minecraft:deepslate_tiles
fill 102 206 505 102 307 505 minecraft:deepslate_tiles
fill 106 206 505 109 225 505 minecraft:deepslate_tiles
setblock 110 206 505 minecraft:sculk
fill 111 206 505 112 307 505 minecraft:deepslate_tiles
fill 117 206 463 117 307 463 minecraft:deepslate_tiles
setblock 118 206 463 minecraft:sculk
fill 119 206 463 121 307 463 minecraft:deepslate_tiles
fill 119 206 505 119 225 505 minecraft:deepslate_tiles
fill 123 206 505 123 307 505 minecraft:deepslate_tiles
setblock 124 206 505 minecraft:sculk
fill 125 206 505 129 307 505 minecraft:deepslate_tiles
setblock 130 206 463 minecraft:sculk
setblock 130 206 505 minecraft:sculk
fill 131 206 505 131 225 505 minecraft:deepslate_tiles
setblock 132 206 505 minecraft:sculk
fill 133 206 505 133 225 505 minecraft:deepslate_tiles
fill 136 206 464 136 225 464 minecraft:deepslate_tiles
setblock 136 206 465 minecraft:sculk
fill 136 206 472 136 307 472 minecraft:deepslate_tiles
fill 136 206 475 136 225 476 minecraft:deepslate_tiles
setblock 136 206 477 minecraft:sculk
fill 136 206 478 136 225 483 minecraft:deepslate_tiles
fill 136 206 491 136 225 493 minecraft:deepslate_tiles
setblock 136 206 494 minecraft:sculk
fill 136 206 495 136 225 502 minecraft:deepslate_tiles
setblock 136 206 503 minecraft:sculk
fill 136 206 504 136 307 504 minecraft:deepslate_tiles
fill 94 207 486 94 307 486 minecraft:deepslate_tiles
fill 94 207 489 94 307 489 minecraft:deepslate_tiles
fill 94 207 496 94 225 497 minecraft:deepslate_tiles
fill 94 207 502 94 307 502 minecraft:deepslate_tiles
fill 110 207 505 110 307 505 minecraft:deepslate_tiles
fill 118 207 463 118 307 463 minecraft:deepslate_tiles
fill 124 207 505 124 307 505 minecraft:deepslate_tiles
fill 130 207 463 130 307 463 minecraft:deepslate_tiles
fill 130 207 505 130 225 505 minecraft:deepslate_tiles
fill 132 207 505 132 225 505 minecraft:deepslate_tiles
fill 136 207 465 136 225 465 minecraft:deepslate_tiles
fill 136 207 477 136 225 477 minecraft:deepslate_tiles
fill 136 207 494 136 307 494 minecraft:deepslate_tiles
fill 136 207 503 136 225 503 minecraft:deepslate_tiles
fill 103 209 487 113 209 487 minecraft:sculk
fill 105 209 486 114 209 486 minecraft:sculk
fill 105 209 488 114 209 488 minecraft:sculk
fill 106 209 485 115 209 485 minecraft:sculk
fill 106 209 489 115 209 489 minecraft:sculk
fill 110 209 476 110 210 482 minecraft:sculk
fill 110 209 492 110 210 498 minecraft:sculk
fill 111 209 477 112 209 484 minecraft:sculk
fill 111 209 490 112 209 497 minecraft:sculk
fill 113 209 478 113 209 484 minecraft:sculk
fill 113 209 490 113 209 496 minecraft:sculk
fill 114 209 479 114 209 484 minecraft:sculk
fill 114 209 490 114 209 495 minecraft:sculk
fill 115 209 480 115 209 484 minecraft:sculk
fill 115 209 490 115 209 494 minecraft:sculk
fill 116 209 482 121 209 484 minecraft:sculk
fill 116 209 490 121 209 492 minecraft:sculk
fill 117 209 480 122 209 481 minecraft:sculk
fill 117 209 485 126 209 485 minecraft:sculk
fill 117 209 489 126 209 489 minecraft:sculk
fill 117 209 493 122 209 494 minecraft:sculk
fill 118 209 479 122 210 479 minecraft:sculk
fill 118 209 486 127 209 486 minecraft:sculk
fill 118 209 488 127 209 488 minecraft:sculk
fill 118 209 495 122 210 495 minecraft:sculk
fill 119 209 478 122 210 478 minecraft:sculk
fill 119 209 487 129 209 487 minecraft:sculk
fill 119 209 496 122 210 496 minecraft:sculk
fill 120 209 477 122 210 477 minecraft:sculk
fill 120 209 497 122 210 497 minecraft:sculk
fill 122 209 476 122 210 476 minecraft:sculk
fill 122 209 482 122 210 482 minecraft:sculk
fill 122 209 492 122 210 492 minecraft:sculk
fill 122 209 498 122 210 498 minecraft:sculk
fill 95 210 464 106 210 504 minecraft:sculk
fill 107 210 464 108 210 486 minecraft:sculk
fill 107 210 487 111 210 487 minecraft:cyan_concrete
fill 107 210 488 108 210 504 minecraft:sculk
fill 109 210 464 109 210 485 minecraft:sculk
fill 109 210 486 112 210 486 minecraft:cyan_concrete
fill 109 210 488 112 210 488 minecraft:cyan_concrete
fill 109 210 489 109 210 504 minecraft:sculk
fill 110 210 464 135 210 475 minecraft:sculk
fill 110 210 483 110 210 485 minecraft:sculk
fill 110 210 489 110 210 491 minecraft:sculk
fill 110 210 499 135 210 504 minecraft:sculk
fill 111 210 476 111 210 484 minecraft:sculk
fill 111 210 485 112 210 485 minecraft:cyan_concrete
fill 111 210 489 112 210 489 minecraft:cyan_concrete
fill 111 210 490 111 210 498 minecraft:sculk
fill 112 210 476 117 210 479 minecraft:sculk
fill 112 210 480 113 210 484 minecraft:cyan_concrete
setblock 112 210 487 minecraft:bone_block
fill 112 210 490 113 210 494 minecraft:cyan_concrete
fill 112 210 495 117 210 498 minecraft:sculk
setblock 113 210 485 minecraft:bone_block
fill 113 210 486 113 210 488 minecraft:sea_lantern
setblock 113 210 489 minecraft:bone_block
fill 114 210 480 118 210 480 minecraft:sculk
fill 114 210 481 114 210 483 minecraft:cyan_concrete
setblock 114 210 484 minecraft:bone_block
fill 114 210 485 114 210 486 minecraft:shroomlight
fill 114 210 488 114 210 489 minecraft:shroomlight
setblock 114 210 490 minecraft:bone_block
fill 114 210 491 114 210 493 minecraft:cyan_concrete
fill 114 210 494 118 210 494 minecraft:sculk
fill 115 210 481 117 210 481 minecraft:sculk
fill 115 210 482 115 210 483 minecraft:cyan_concrete
fill 115 210 484 117 210 484 minecraft:sea_lantern
setblock 115 210 485 minecraft:shroomlight
setblock 115 210 489 minecraft:shroomlight
fill 115 210 490 117 210 490 minecraft:sea_lantern
fill 115 210 491 115 210 492 minecraft:cyan_concrete
fill 115 210 493 117 210 493 minecraft:sculk
setblock 116 210 482 minecraft:sculk
setblock 116 210 483 minecraft:bone_block
setblock 116 210 491 minecraft:bone_block
setblock 116 210 492 minecraft:sculk
fill 117 210 482 120 210 483 minecraft:cyan_concrete
fill 117 210 485 118 210 485 minecraft:shroomlight
fill 117 210 489 118 210 489 minecraft:shroomlight
fill 117 210 491 120 210 492 minecraft:cyan_concrete
fill 118 210 476 118 210 478 minecraft:sculk
fill 118 210 481 120 210 481 minecraft:cyan_concrete
setblock 118 210 484 minecraft:bone_block
setblock 118 210 486 minecraft:shroomlight
setblock 118 210 488 minecraft:shroomlight
setblock 118 210 490 minecraft:bone_block
fill 118 210 493 120 210 493 minecraft:cyan_concrete
fill 118 210 496 118 210 498 minecraft:sculk
fill 119 210 476 119 210 477 minecraft:sculk
fill 119 210 480 120 210 480 minecraft:cyan_concrete
fill 119 210 484 120 210 484 minecraft:cyan_concrete
setblock 119 210 485 minecraft:bone_block
fill 119 210 486 119 210 488 minecraft:sea_lantern
setblock 119 210 489 minecraft:bone_block
fill 119 210 490 120 210 490 minecraft:cyan_concrete
fill 119 210 494 120 210 494 minecraft:cyan_concrete
fill 119 210 497 119 210 498 minecraft:sculk
fill 120 210 476 121 210 476 minecraft:sculk
fill 120 210 485 121 210 486 minecraft:cyan_concrete
setblock 120 210 487 minecraft:bone_block
fill 120 210 488 121 210 489 minecraft:cyan_concrete
fill 120 210 498 121 210 498 minecraft:sculk
fill 121 210 480 121 210 484 minecraft:sculk
fill 121 210 487 125 210 487 minecraft:cyan_concrete
fill 121 210 490 121 210 494 minecraft:sculk
fill 122 210 480 135 210 481 minecraft:sculk
fill 122 210 483 135 210 485 minecraft:sculk
fill 122 210 486 123 210 486 minecraft:cyan_concrete
fill 122 210 488 123 210 488 minecraft:cyan_concrete
fill 122 210 489 135 210 491 minecraft:sculk
fill 122 210 493 135 210 494 minecraft:sculk
fill 123 210 476 135 210 479 minecraft:sculk
fill 123 210 482 135 210 482 minecraft:sculk
fill 123 210 492 135 210 492 minecraft:sculk
fill 123 210 495 135 210 498 minecraft:sculk
fill 124 210 486 135 210 486 minecraft:sculk
fill 124 210 488 135 210 488 minecraft:sculk
fill 126 210 487 135 210 487 minecraft:sculk
fill 95 211 477 96 211 497 minecraft:basalt
fill 96 211 475 99 211 476 minecraft:basalt
fill 96 211 498 96 211 499 minecraft:basalt
setblock 97 211 474 minecraft:magma_block
setblock 97 211 477 minecraft:magma_block
fill 97 211 478 99 213 479 minecraft:basalt
setblock 97 211 480 minecraft:magma_block
fill 97 211 481 99 215 482 minecraft:basalt
setblock 97 211 483 minecraft:magma_block
fill 97 211 484 99 215 485 minecraft:basalt
setblock 97 211 486 minecraft:magma_block
fill 97 211 487 99 216 488 minecraft:basalt
setblock 97 211 489 minecraft:magma_block
fill 97 211 490 99 215 491 minecraft:basalt
setblock 97 211 492 minecraft:magma_block
fill 97 211 493 99 213 494 minecraft:basalt
setblock 97 211 495 minecraft:magma_block
fill 97 211 496 99 213 497 minecraft:basalt
setblock 97 211 498 minecraft:magma_block
fill 97 211 499 99 211 500 minecraft:basalt
fill 98 211 472 99 211 474 minecraft:basalt
fill 98 211 477 105 214 477 minecraft:basalt
fill 98 211 480 103 215 480 minecraft:basalt
fill 98 211 483 101 216 483 minecraft:basalt
fill 98 211 486 101 217 486 minecraft:basalt
fill 98 211 489 101 217 489 minecraft:basalt
fill 98 211 492 102 211 492 minecraft:basalt
fill 98 211 495 103 215 495 minecraft:basalt
fill 98 211 498 105 212 498 minecraft:basalt
fill 98 211 501 102 211 502 minecraft:basalt
fill 99 211 471 105 211 471 minecraft:basalt
setblock 99 211 503 minecraft:basalt
setblock 100 211 470 minecraft:magma_block
fill 100 211 472 102 212 472 minecraft:basalt
setblock 100 211 473 minecraft:magma_block
fill 100 211 474 102 214 475 minecraft:basalt
setblock 100 211 476 minecraft:magma_block
fill 100 211 478 102 216 478 minecraft:basalt
setblock 100 211 479 minecraft:magma_block
fill 100 211 481 102 218 481 minecraft:basalt
setblock 100 211 482 minecraft:magma_block
fill 100 211 484 101 219 484 minecraft:basalt
setblock 100 211 485 minecraft:magma_block
fill 100 211 487 101 219 487 minecraft:basalt
setblock 100 211 488 minecraft:magma_block
fill 100 211 490 101 219 490 minecraft:basalt
setblock 100 211 491 minecraft:magma_block
fill 100 211 493 102 218 493 minecraft:basalt
setblock 100 211 494 minecraft:magma_block
fill 100 211 496 102 216 496 minecraft:basalt
setblock 100 211 497 minecraft:magma_block
fill 100 211 499 102 215 499 minecraft:basalt
setblock 100 211 500 minecraft:magma_block
setblock 100 211 503 minecraft:magma_block
fill 100 211 504 105 211 504 minecraft:basalt
fill 101 211 469 102 211 470 minecraft:basalt
fill 101 211 473 108 214 473 minecraft:basalt
fill 101 211 476 106 216 476 minecraft:basalt
fill 101 211 479 103 218 479 minecraft:basalt
fill 101 211 482 102 219 482 minecraft:basalt
fill 101 211 485 101 220 485 minecraft:basalt
fill 101 211 488 101 220 488 minecraft:basalt
fill 101 211 491 101 220 491 minecraft:basalt
fill 101 211 494 103 219 494 minecraft:basalt
fill 101 211 497 105 217 497 minecraft:basalt
fill 101 211 500 108 215 500 minecraft:basalt
fill 101 211 503 108 212 503 minecraft:basalt
fill 103 211 468 105 211 468 minecraft:basalt
setblock 103 211 469 minecraft:magma_block
fill 103 211 470 108 213 470 minecraft:basalt
setblock 103 211 472 minecraft:magma_block
fill 103 211 474 105 216 474 minecraft:basalt
setblock 103 211 475 minecraft:magma_block
setblock 103 211 478 minecraft:magma_block
setblock 103 211 496 minecraft:magma_block
setblock 103 211 499 minecraft:magma_block
fill 103 211 501 105 215 501 minecraft:basalt
setblock 103 211 502 minecraft:magma_block
fill 104 211 467 108 211 467 minecraft:basalt
fill 104 211 469 111 212 469 minecraft:basalt
fill 104 211 472 111 215 472 minecraft:basalt
fill 104 211 475 107 218 475 minecraft:basalt
fill 104 211 478 104 220 478 minecraft:basalt
fill 104 211 496 104 220 496 minecraft:basalt
fill 104 211 499 107 218 499 minecraft:basalt
fill 104 211 502 111 215 502 minecraft:basalt
fill 106 211 466 111 211 466 minecraft:basalt
setblock 106 211 468 minecraft:magma_block
setblock 106 211 471 minecraft:magma_block
setblock 106 211 474 minecraft:magma_block
setblock 106 211 498 minecraft:magma_block
setblock 106 211 501 minecraft:magma_block
setblock 106 211 504 minecraft:magma_block
fill 107 211 468 114 212 468 minecraft:basalt
fill 107 211 471 114 216 471 minecraft:basalt
fill 107 211 474 109 219 474 minecraft:basalt
fill 107 211 501 111 211 501 minecraft:basalt
fill 107 211 504 114 215 504 minecraft:basalt
fill 108 211 465 114 211 465 minecraft:basalt
setblock 109 211 467 minecraft:magma_block
setblock 109 211 470 minecraft:magma_block
setblock 109 211 473 minecraft:magma_block
setblock 109 211 500 minecraft:magma_block
setblock 109 211 503 minecraft:magma_block
fill 110 211 467 117 212 467 minecraft:basalt
fill 110 211 470 117 216 470 minecraft:basalt
fill 110 211 473 111 220 473 minecraft:basalt
fill 110 211 503 117 218 503 minecraft:basalt
fill 111 211 464 117 211 464 minecraft:basalt
setblock 112 211 466 minecraft:magma_block
setblock 112 211 469 minecraft:magma_block
setblock 112 211 472 minecraft:magma_block
setblock 112 211 502 minecraft:magma_block
fill 113 211 466 120 212 466 minecraft:basalt
fill 113 211 469 120 215 469 minecraft:basalt
fill 113 211 472 120 211 472 minecraft:basalt
fill 113 211 502 120 211 502 minecraft:basalt
setblock 115 211 465 minecraft:magma_block
setblock 115 211 468 minecraft:magma_block
setblock 115 211 471 minecraft:magma_block
setblock 115 211 504 minecraft:magma_block
fill 116 211 465 123 211 465 minecraft:basalt
fill 116 211 468 123 214 468 minecraft:basalt
fill 116 211 471 123 217 471 minecraft:basalt
fill 116 211 504 123 216 504 minecraft:basalt
setblock 118 211 464 minecraft:magma_block
setblock 118 211 467 minecraft:magma_block
setblock 118 211 470 minecraft:magma_block
setblock 118 211 503 minecraft:magma_block
fill 119 211 464 121 211 464 minecraft:basalt
fill 119 211 467 126 212 467 minecraft:basalt
fill 119 211 470 126 215 470 minecraft:basalt
fill 119 211 503 126 215 503 minecraft:basalt
setblock 121 211 466 minecraft:magma_block
setblock 121 211 469 minecraft:magma_block
setblock 121 211 472 minecraft:magma_block
fill 121 211 473 126 217 473 minecraft:basalt
fill 121 211 501 123 220 501 minecraft:basalt
setblock 121 211 502 minecraft:magma_block
fill 122 211 466 126 211 466 minecraft:basalt
fill 122 211 469 129 212 469 minecraft:basalt
fill 122 211 472 129 215 472 minecraft:basalt
fill 122 211 502 129 215 502 minecraft:basalt
fill 123 211 474 123 221 474 minecraft:basalt
fill 123 211 500 126 211 500 minecraft:basalt
setblock 124 211 465 minecraft:magma_block
setblock 124 211 468 minecraft:magma_block
setblock 124 211 471 minecraft:magma_block
setblock 124 211 474 minecraft:magma_block
setblock 124 211 501 minecraft:magma_block
setblock 124 211 504 minecraft:magma_block
fill 125 211 468 129 211 468 minecraft:basalt
fill 125 211 471 132 212 471 minecraft:basalt
fill 125 211 474 129 216 475 minecraft:basalt
fill 125 211 499 129 217 499 minecraft:basalt
fill 125 211 501 132 213 501 minecraft:basalt
fill 125 211 504 132 211 504 minecraft:basalt
fill 126 211 476 126 220 476 minecraft:basalt
fill 126 211 498 132 215 498 minecraft:basalt
setblock 127 211 467 minecraft:magma_block
setblock 127 211 470 minecraft:magma_block
setblock 127 211 473 minecraft:magma_block
setblock 127 211 476 minecraft:magma_block
fill 127 211 477 132 216 477 minecraft:basalt
setblock 127 211 497 minecraft:magma_block
setblock 127 211 500 minecraft:magma_block
setblock 127 211 503 minecraft:magma_block
setblock 128 211 467 minecraft:basalt
fill 128 211 470 132 211 470 minecraft:basalt
fill 128 211 473 134 211 473 minecraft:basalt
fill 128 211 476 135 212 476 minecraft:basalt
fill 128 211 478 129 219 478 minecraft:basalt
fill 128 211 496 129 219 497 minecraft:basalt
fill 128 211 500 135 211 500 minecraft:basalt
fill 128 211 503 133 211 503 minecraft:basalt
fill 129 211 479 132 211 480 minecraft:basalt
fill 129 211 494 132 217 495 minecraft:basalt
setblock 130 211 469 minecraft:magma_block
setblock 130 211 472 minecraft:magma_block
fill 130 211 474 132 214 474 minecraft:basalt
setblock 130 211 475 minecraft:magma_block
setblock 130 211 478 minecraft:magma_block
setblock 130 211 481 minecraft:magma_block
fill 130 211 482 135 215 482 minecraft:basalt
fill 130 211 492 132 217 492 minecraft:basalt
setblock 130 211 493 minecraft:magma_block
setblock 130 211 496 minecraft:magma_block
fill 130 211 497 135 213 497 minecraft:basalt
setblock 130 211 499 minecraft:magma_block
setblock 130 211 502 minecraft:magma_block
setblock 131 211 469 minecraft:basalt
fill 131 211 472 134 211 472 minecraft:basalt
fill 131 211 475 135 211 475 minecraft:basalt
fill 131 211 478 135 213 478 minecraft:basalt
fill 131 211 481 135 215 481 minecraft:basalt
fill 131 211 483 132 217 491 minecraft:basalt
fill 131 211 493 135 215 493 minecraft:basalt
fill 131 211 496 135 213 496 minecraft:basalt
fill 131 211 499 135 211 499 minecraft:basalt
fill 131 211 502 134 211 502 minecraft:basalt
setblock 133 211 471 minecraft:magma_block
setblock 133 211 474 minecraft:magma_block
setblock 133 211 477 minecraft:magma_block
fill 133 211 479 135 214 479 minecraft:basalt
setblock 133 211 480 minecraft:magma_block
setblock 133 211 483 minecraft:magma_block
fill 133 211 484 135 215 485 minecraft:basalt
setblock 133 211 486 minecraft:magma_block
fill 133 211 487 135 216 488 minecraft:basalt
setblock 133 211 489 minecraft:magma_block
fill 133 211 490 135 215 491 minecraft:basalt
setblock 133 211 492 minecraft:magma_block
fill 133 211 494 135 214 494 minecraft:basalt
setblock 133 211 495 minecraft:magma_block
setblock 133 211 498 minecraft:magma_block
setblock 133 211 501 minecraft:magma_block
fill 134 211 474 135 211 474 minecraft:basalt
fill 134 211 477 135 213 477 minecraft:basalt
fill 134 211 480 135 214 480 minecraft:basalt
fill 134 211 483 135 214 483 minecraft:basalt
fill 134 211 486 135 216 486 minecraft:basalt
fill 134 211 489 135 214 489 minecraft:basalt
fill 134 211 492 135 214 492 minecraft:basalt
fill 134 211 495 135 214 495 minecraft:basalt
fill 134 211 498 135 212 498 minecraft:basalt
setblock 134 211 501 minecraft:basalt
fill 95 212 479 96 212 495 minecraft:basalt
fill 96 212 477 96 212 478 minecraft:basalt
setblock 96 212 496 minecraft:basalt
setblock 96 212 497 minecraft:magma_block
fill 97 212 475 97 212 477 minecraft:basalt
fill 97 212 480 97 214 480 minecraft:basalt
fill 97 212 483 97 215 483 minecraft:basalt
fill 97 212 486 97 216 486 minecraft:basalt
fill 97 212 489 97 216 489 minecraft:basalt
fill 97 212 492 101 215 492 minecraft:basalt
fill 97 212 495 97 214 495 minecraft:basalt
fill 97 212 498 97 212 499 minecraft:basalt
fill 98 212 474 99 212 476 minecraft:basalt
fill 98 212 499 99 212 500 minecraft:basalt
setblock 99 212 472 minecraft:magma_block
fill 99 212 473 100 212 473 minecraft:basalt
fill 99 212 501 102 212 501 minecraft:basalt
setblock 99 212 502 minecraft:magma_block
fill 100 212 471 106 212 471 minecraft:basalt
fill 100 212 476 100 215 476 minecraft:basalt
fill 100 212 479 100 217 479 minecraft:basalt
fill 100 212 482 100 218 482 minecraft:basalt
fill 100 212 485 100 219 485 minecraft:basalt
fill 100 212 488 100 219 488 minecraft:basalt
fill 100 212 491 100 219 491 minecraft:basalt
fill 100 212 494 100 217 494 minecraft:basalt
fill 100 212 497 100 216 497 minecraft:basalt
fill 100 212 500 100 214 500 minecraft:basalt
fill 100 212 502 100 212 503 minecraft:basalt
fill 101 212 470 102 212 470 minecraft:basalt
fill 101 212 502 103 213 502 minecraft:basalt
setblock 101 212 504 minecraft:basalt
setblock 102 212 483 minecraft:magma_block
fill 102 212 484 102 221 485 minecraft:basalt
setblock 102 212 489 minecraft:magma_block
fill 102 212 490 102 221 491 minecraft:basalt
setblock 102 212 492 minecraft:magma_block
setblock 102 212 504 minecraft:magma_block
setblock 103 212 469 minecraft:basalt
fill 103 212 472 103 215 472 minecraft:basalt
fill 103 212 475 103 217 475 minecraft:basalt
fill 103 212 478 103 219 478 minecraft:basalt
fill 103 212 481 103 221 481 minecraft:basalt
fill 103 212 493 103 221 493 minecraft:basalt
fill 103 212 496 103 219 496 minecraft:basalt
fill 103 212 499 103 217 499 minecraft:basalt
fill 103 212 504 106 213 504 minecraft:basalt
fill 104 212 468 106 212 468 minecraft:basalt
fill 104 212 479 104 221 479 minecraft:basalt
fill 104 212 495 104 221 495 minecraft:basalt
fill 105 212 478 105 221 478 minecraft:basalt
fill 105 212 496 105 221 496 minecraft:basalt
fill 106 212 467 109 212 467 minecraft:basalt
fill 106 212 474 106 219 474 minecraft:basalt
fill 106 212 477 106 221 477 minecraft:basalt
fill 106 212 497 106 219 498 minecraft:basalt
fill 106 212 501 110 218 501 minecraft:basalt
fill 107 212 476 107 221 476 minecraft:basalt
fill 107 212 498 107 221 498 minecraft:basalt
setblock 108 212 466 minecraft:magma_block
setblock 108 212 475 minecraft:magma_block
setblock 108 212 499 minecraft:magma_block
fill 109 212 466 112 212 466 minecraft:basalt
fill 109 212 470 109 216 470 minecraft:basalt
fill 109 212 473 109 219 473 minecraft:basalt
fill 109 212 500 110 212 500 minecraft:basalt
fill 109 212 503 109 217 503 minecraft:basalt
fill 110 212 474 110 221 474 minecraft:basalt
setblock 111 212 465 minecraft:magma_block
setblock 111 212 501 minecraft:magma_block
fill 112 212 465 119 212 465 minecraft:basalt
fill 112 212 469 112 216 469 minecraft:basalt
fill 112 212 472 113 219 473 minecraft:basalt
fill 112 212 501 114 219 502 minecraft:basalt
fill 114 212 472 116 220 472 minecraft:basalt
setblock 114 212 473 minecraft:magma_block
fill 115 212 468 115 216 468 minecraft:basalt
fill 115 212 471 115 219 471 minecraft:basalt
fill 115 212 502 116 220 502 minecraft:basalt
fill 115 212 504 115 218 504 minecraft:basalt
setblock 117 212 472 minecraft:magma_block
setblock 117 212 502 minecraft:magma_block
fill 118 212 467 118 214 467 minecraft:basalt
fill 118 212 470 118 218 470 minecraft:basalt
fill 118 212 472 120 212 473 minecraft:basalt
fill 118 212 501 118 219 503 minecraft:basalt
fill 119 212 501 119 220 502 minecraft:basalt
setblock 120 212 465 minecraft:magma_block
setblock 120 212 501 minecraft:magma_block
fill 120 212 502 121 219 502 minecraft:basalt
fill 121 212 465 121 212 466 minecraft:basalt
fill 121 212 469 121 216 469 minecraft:basalt
fill 121 212 472 121 219 472 minecraft:basalt
fill 122 212 466 124 212 466 minecraft:basalt
fill 122 212 474 122 221 474 minecraft:basalt
fill 122 212 500 122 221 500 minecraft:basalt
setblock 123 212 500 minecraft:magma_block
fill 124 212 468 128 212 468 minecraft:basalt
fill 124 212 471 124 217 471 minecraft:basalt
fill 124 212 474 124 219 475 minecraft:basalt
fill 124 212 499 124 219 501 minecraft:basalt
fill 124 212 504 131 212 504 minecraft:basalt
fill 125 212 476 125 221 476 minecraft:basalt
fill 125 212 498 125 221 498 minecraft:basalt
fill 125 212 500 134 212 500 minecraft:basalt
fill 126 212 477 126 221 477 minecraft:basalt
fill 126 212 497 127 219 497 minecraft:basalt
fill 127 212 470 131 212 470 minecraft:basalt
fill 127 212 473 133 212 473 minecraft:basalt
fill 127 212 476 127 219 476 minecraft:basalt
fill 127 212 478 127 221 478 minecraft:basalt
fill 127 212 496 127 221 496 minecraft:basalt
fill 127 212 503 131 212 503 minecraft:basalt
fill 128 212 479 132 217 479 minecraft:basalt
fill 128 212 495 128 221 495 minecraft:basalt
setblock 129 212 480 minecraft:magma_block
fill 129 212 481 130 219 481 minecraft:basalt
fill 129 212 493 130 219 493 minecraft:basalt
fill 130 212 472 133 212 472 minecraft:basalt
fill 130 212 475 134 213 475 minecraft:basalt
fill 130 212 478 130 218 478 minecraft:basalt
fill 130 212 480 133 216 480 minecraft:basalt
fill 130 212 483 130 221 485 minecraft:basalt
fill 130 212 489 130 221 491 minecraft:basalt
fill 130 212 496 130 218 496 minecraft:basalt
fill 130 212 499 134 213 499 minecraft:basalt
fill 130 212 502 133 212 502 minecraft:basalt
setblock 132 212 503 minecraft:magma_block
fill 133 212 474 134 212 474 minecraft:basalt
fill 133 212 477 133 215 477 minecraft:basalt
fill 133 212 483 133 217 483 minecraft:basalt
fill 133 212 486 133 218 486 minecraft:basalt
fill 133 212 489 133 218 489 minecraft:basalt
fill 133 212 492 133 217 492 minecraft:basalt
fill 133 212 495 133 216 495 minecraft:basalt
fill 133 212 498 133 214 498 minecraft:basalt
setblock 133 212 501 minecraft:basalt
setblock 135 212 475 minecraft:magma_block
setblock 135 212 499 minecraft:magma_block
fill 95 213 482 96 213 483 minecraft:basalt
setblock 95 213 484 minecraft:magma_block
fill 95 213 485 96 213 486 minecraft:basalt
setblock 95 213 487 minecraft:magma_block
fill 95 213 488 96 213 489 minecraft:basalt
setblock 95 213 490 minecraft:magma_block
fill 95 213 491 96 213 492 minecraft:basalt
fill 96 213 479 96 213 481 minecraft:basalt
fill 96 213 484 96 214 484 minecraft:basalt
fill 96 213 487 96 214 487 minecraft:basalt
fill 96 213 490 96 214 490 minecraft:basalt
fill 96 213 493 96 213 495 minecraft:basalt
setblock 97 213 466 minecraft:light[level=11]
setblock 97 213 474 minecraft:light[level=11]
setblock 97 213 477 minecraft:basalt
setblock 97 213 498 minecraft:light[level=11]
fill 98 213 475 99 213 476 minecraft:basalt
setblock 98 213 498 minecraft:magma_block
fill 98 213 499 99 213 499 minecraft:basalt
setblock 99 213 474 minecraft:basalt
fill 99 213 498 105 214 498 minecraft:basalt
setblock 99 213 500 minecraft:basalt
setblock 100 213 473 minecraft:basalt
fill 100 213 501 102 213 501 minecraft:basalt
fill 101 213 472 102 213 472 minecraft:basalt
fill 102 213 471 106 213 471 minecraft:basalt
fill 102 213 483 103 213 483 minecraft:basalt
fill 102 213 486 102 220 489 minecraft:basalt
fill 102 213 492 103 220 492 minecraft:basalt
fill 102 213 503 108 213 503 minecraft:basalt
fill 103 213 482 103 222 482 minecraft:basalt
fill 103 213 491 103 222 491 minecraft:basalt
setblock 104 213 469 minecraft:magma_block
fill 104 213 480 104 222 480 minecraft:basalt
fill 104 213 494 104 222 494 minecraft:basalt
setblock 105 213 466 minecraft:light[level=11]
fill 105 213 469 111 213 469 minecraft:basalt
fill 105 213 479 105 222 479 minecraft:basalt
setblock 105 213 482 minecraft:light[level=11]
setblock 105 213 490 minecraft:light[level=11]
fill 105 213 495 105 222 495 minecraft:basalt
setblock 106 213 468 minecraft:basalt
fill 106 213 478 106 222 478 minecraft:basalt
fill 106 213 496 106 222 496 minecraft:basalt
setblock 107 213 468 minecraft:magma_block
setblock 107 213 477 minecraft:magma_block
fill 107 213 497 107 222 497 minecraft:basalt
fill 108 213 467 109 213 468 minecraft:basalt
fill 108 213 475 108 220 476 minecraft:basalt
fill 108 213 498 108 220 499 minecraft:basalt
fill 109 213 475 109 222 475 minecraft:basalt
fill 109 213 499 109 221 500 minecraft:basalt
setblock 110 213 467 minecraft:magma_block
fill 110 213 468 114 215 468 minecraft:basalt
setblock 110 213 500 minecraft:magma_block
fill 111 213 466 112 213 467 minecraft:basalt
fill 111 213 474 112 213 474 minecraft:basalt
fill 111 213 500 111 220 501 minecraft:basalt
fill 112 213 500 112 222 500 minecraft:basalt
setblock 113 213 466 minecraft:magma_block
fill 113 213 467 117 213 467 minecraft:basalt
setblock 113 213 474 minecraft:light[level=11]
setblock 113 213 482 minecraft:light[level=11]
setblock 113 213 490 minecraft:light[level=11]
setblock 113 213 498 minecraft:light[level=11]
fill 114 213 466 121 213 466 minecraft:basalt
fill 114 213 473 118 220 473 minecraft:basalt
fill 115 213 501 115 221 501 minecraft:basalt
setblock 116 213 501 minecraft:magma_block
fill 117 213 472 120 220 472 minecraft:basalt
fill 117 213 501 117 220 502 minecraft:basalt
fill 119 213 467 124 213 467 minecraft:basalt
setblock 119 213 473 minecraft:magma_block
fill 120 213 473 120 221 474 minecraft:basalt
fill 120 213 500 120 220 501 minecraft:basalt
fill 121 213 474 121 222 474 minecraft:basalt
setblock 121 213 482 minecraft:light[level=11]
setblock 121 213 490 minecraft:light[level=11]
setblock 121 213 498 minecraft:light[level=11]
fill 121 213 500 121 222 500 minecraft:basalt
fill 122 213 469 128 213 469 minecraft:basalt
fill 123 213 475 123 222 475 minecraft:basalt
fill 123 213 499 123 220 500 minecraft:basalt
fill 124 213 468 124 214 468 minecraft:basalt
setblock 124 213 476 minecraft:basalt
fill 124 213 498 124 222 498 minecraft:basalt
fill 124 213 504 129 213 504 minecraft:basalt
setblock 125 213 468 minecraft:magma_block
fill 125 213 471 130 213 471 minecraft:basalt
setblock 125 213 477 minecraft:magma_block
fill 125 213 497 125 222 497 minecraft:basalt
fill 125 213 500 133 213 500 minecraft:basalt
setblock 126 213 468 minecraft:basalt
fill 126 213 478 126 222 478 minecraft:basalt
fill 126 213 496 126 222 496 minecraft:basalt
fill 127 213 470 129 213 470 minecraft:basalt
fill 127 213 473 132 213 473 minecraft:basalt
fill 127 213 479 127 222 479 minecraft:basalt
fill 127 213 495 127 222 495 minecraft:basalt
fill 127 213 503 130 213 503 minecraft:basalt
fill 128 213 476 134 213 476 minecraft:basalt
fill 128 213 480 129 220 480 minecraft:basalt
setblock 128 213 494 minecraft:magma_block
setblock 129 213 466 minecraft:light[level=11]
fill 129 213 482 129 222 483 minecraft:basalt
setblock 129 213 490 minecraft:light[level=11]
fill 129 213 491 129 220 492 minecraft:basalt
fill 130 213 472 130 214 472 minecraft:basalt
fill 130 213 486 130 221 488 minecraft:basalt
fill 130 213 502 130 214 502 minecraft:basalt
setblock 131 213 472 minecraft:magma_block
setblock 131 213 502 minecraft:magma_block
setblock 133 213 474 minecraft:basalt
setblock 134 213 498 minecraft:magma_block
fill 95 214 464 97 273 464 minecraft:deepslate_bricks
fill 95 214 474 95 273 476 minecraft:deepslate_bricks
fill 95 214 486 95 273 488 minecraft:deepslate_bricks
fill 95 214 498 95 273 500 minecraft:deepslate_bricks
fill 96 214 481 96 214 483 minecraft:basalt
fill 96 214 485 96 214 486 minecraft:basalt
fill 96 214 488 96 214 489 minecraft:basalt
fill 96 214 491 96 214 493 minecraft:basalt
setblock 97 214 479 minecraft:magma_block
fill 97 214 493 99 215 493 minecraft:basalt
setblock 97 214 494 minecraft:magma_block
fill 98 214 478 99 214 479 minecraft:basalt
fill 98 214 494 99 215 494 minecraft:basalt
fill 98 214 496 99 214 497 minecraft:basalt
fill 99 214 475 99 214 476 minecraft:basalt
setblock 99 214 499 minecraft:basalt
fill 101 214 501 102 214 501 minecraft:basalt
fill 101 214 504 103 273 504 minecraft:deepslate_bricks
setblock 102 214 472 minecraft:basalt
fill 102 214 483 102 220 483 minecraft:basalt
fill 102 214 502 103 214 502 minecraft:basalt
fill 103 214 464 105 216 469 minecraft:deepslate_bricks
setblock 103 214 471 minecraft:magma_block
setblock 103 214 483 minecraft:magma_block
fill 103 214 484 103 222 485 minecraft:basalt
setblock 103 214 486 minecraft:magma_block
fill 103 214 487 103 223 488 minecraft:basalt
setblock 103 214 489 minecraft:magma_block
fill 103 214 490 103 222 490 minecraft:basalt
fill 103 214 503 108 214 503 minecraft:basalt
fill 104 214 470 106 214 471 minecraft:basalt
fill 104 214 481 104 221 482 minecraft:basalt
fill 104 214 492 104 221 493 minecraft:basalt
fill 104 214 504 106 214 504 minecraft:basalt
fill 105 214 480 105 223 480 minecraft:basalt
fill 105 214 494 105 223 494 minecraft:basalt
fill 106 214 464 107 216 468 minecraft:deepslate_bricks
fill 106 214 469 111 214 469 minecraft:basalt
fill 107 214 470 108 215 470 minecraft:basalt
fill 107 214 477 107 221 477 minecraft:basalt
fill 108 214 464 109 216 467 minecraft:deepslate_bricks
fill 108 214 468 109 214 468 minecraft:basalt
fill 109 214 476 109 223 476 minecraft:basalt
fill 109 214 498 109 223 498 minecraft:basalt
fill 110 214 464 115 216 466 minecraft:deepslate_bricks
fill 110 214 467 114 214 467 minecraft:basalt
fill 110 214 475 111 222 475 minecraft:basalt
fill 110 214 499 110 221 500 minecraft:basalt
fill 111 214 474 111 220 474 minecraft:basalt
fill 111 214 499 111 223 499 minecraft:basalt
setblock 112 214 474 minecraft:magma_block
fill 113 214 474 119 214 474 minecraft:basalt
fill 113 214 500 114 222 500 minecraft:basalt
fill 114 214 498 120 214 499 minecraft:deepslate_bricks
setblock 115 214 467 minecraft:magma_block
setblock 115 214 500 minecraft:magma_block
fill 116 214 467 117 215 467 minecraft:basalt
fill 116 214 500 116 221 501 minecraft:basalt
fill 117 214 500 119 221 500 minecraft:basalt
fill 119 214 464 121 273 464 minecraft:deepslate_bricks
fill 119 214 466 119 221 466 minecraft:reinforced_deepslate
fill 119 214 467 122 214 467 minecraft:basalt
fill 119 214 473 119 221 473 minecraft:basalt
fill 121 214 475 122 221 475 minecraft:basalt
fill 121 214 498 122 214 498 minecraft:deepslate_bricks
fill 121 214 499 122 221 499 minecraft:basalt
fill 122 214 469 126 214 469 minecraft:basalt
fill 123 214 476 123 223 476 minecraft:basalt
fill 123 214 498 123 223 498 minecraft:basalt
setblock 124 214 476 minecraft:magma_block
fill 124 214 504 128 214 504 minecraft:basalt
fill 125 214 471 129 214 471 minecraft:basalt
fill 125 214 477 125 221 477 minecraft:basalt
fill 125 214 500 131 214 501 minecraft:basalt
fill 127 214 470 128 214 470 minecraft:basalt
fill 127 214 473 131 214 473 minecraft:basalt
fill 127 214 480 127 223 480 minecraft:basalt
fill 127 214 494 128 221 494 minecraft:basalt
fill 127 214 503 129 214 503 minecraft:basalt
fill 128 214 476 132 215 476 minecraft:basalt
fill 128 214 481 128 222 482 minecraft:basalt
fill 128 214 492 128 222 493 minecraft:basalt
fill 129 214 484 129 214 490 minecraft:basalt
fill 130 214 475 133 214 475 minecraft:basalt
fill 130 214 497 134 214 497 minecraft:basalt
fill 130 214 499 133 214 499 minecraft:basalt
fill 131 214 464 133 273 464 minecraft:deepslate_bricks
fill 131 214 478 134 214 478 minecraft:basalt
fill 131 214 496 134 214 496 minecraft:basalt
setblock 132 214 500 minecraft:basalt
setblock 133 214 476 minecraft:magma_block
setblock 134 214 477 minecraft:basalt
fill 135 214 472 135 273 474 minecraft:deepslate_bricks
fill 135 214 496 135 273 498 minecraft:deepslate_bricks
setblock 96 215 486 minecraft:basalt
setblock 96 215 487 minecraft:magma_block
setblock 96 215 488 minecraft:basalt
fill 98 215 479 99 215 479 minecraft:basalt
setblock 99 215 477 minecraft:magma_block
setblock 99 215 478 minecraft:basalt
fill 99 215 496 99 215 497 minecraft:basalt
fill 100 215 475 102 215 475 minecraft:basalt
fill 100 215 477 105 216 477 minecraft:basalt
fill 100 215 498 105 215 498 minecraft:basalt
fill 101 215 474 102 215 474 minecraft:basalt
setblock 102 215 473 minecraft:magma_block
setblock 102 215 501 minecraft:basalt
fill 103 215 473 108 216 473 minecraft:basalt
fill 103 215 483 104 222 483 minecraft:basalt
fill 103 215 486 103 222 486 minecraft:basalt
fill 103 215 489 103 222 489 minecraft:basalt
setblock 103 215 502 minecraft:basalt
fill 104 215 471 106 215 471 minecraft:basalt
fill 104 215 484 104 223 484 minecraft:basalt
fill 104 215 490 104 223 491 minecraft:basalt
fill 104 215 503 108 215 503 minecraft:basalt
setblock 105 215 481 minecraft:magma_block
setblock 105 215 493 minecraft:magma_block
fill 106 215 469 107 216 469 minecraft:deepslate_bricks
setblock 106 215 470 minecraft:basalt
fill 106 215 479 106 222 480 minecraft:basalt
fill 106 215 494 106 222 495 minecraft:basalt
setblock 106 215 504 minecraft:basalt
fill 107 215 478 107 223 478 minecraft:basalt
fill 107 215 496 107 223 496 minecraft:basalt
fill 108 215 468 109 216 468 minecraft:deepslate_bricks
fill 108 215 469 111 215 469 minecraft:basalt
setblock 108 215 477 minecraft:magma_block
fill 108 215 497 109 223 497 minecraft:basalt
fill 109 215 477 109 223 477 minecraft:basalt
fill 110 215 467 114 216 467 minecraft:deepslate_bricks
fill 110 215 476 110 223 476 minecraft:basalt
fill 110 215 498 110 223 498 minecraft:basalt
fill 112 215 474 113 222 475 minecraft:basalt
fill 112 215 499 113 223 499 minecraft:basalt
fill 114 215 474 116 221 474 minecraft:basalt
fill 114 215 498 118 215 499 minecraft:deepslate_bricks
setblock 115 215 467 minecraft:basalt
fill 115 215 500 115 222 500 minecraft:basalt
fill 116 215 468 122 215 468 minecraft:basalt
setblock 117 215 474 minecraft:magma_block
fill 118 215 474 119 222 474 minecraft:basalt
fill 119 215 475 120 215 475 minecraft:basalt
fill 119 215 498 121 215 498 minecraft:deepslate_bricks
fill 119 215 499 120 215 499 minecraft:basalt
fill 122 215 469 122 216 469 minecraft:basalt
fill 122 215 476 122 223 476 minecraft:basalt
fill 122 215 498 122 223 498 minecraft:basalt
setblock 123 215 469 minecraft:magma_block
fill 123 215 477 124 223 477 minecraft:basalt
fill 123 215 497 124 222 497 minecraft:basalt
setblock 124 215 469 minecraft:basalt
fill 124 215 476 124 222 476 minecraft:basalt
fill 124 215 504 125 215 504 minecraft:basalt
fill 125 215 471 128 215 471 minecraft:basalt
fill 125 215 478 125 223 478 minecraft:basalt
fill 125 215 496 125 223 496 minecraft:basalt
fill 125 215 500 130 215 501 minecraft:basalt
fill 126 215 479 126 223 479 minecraft:basalt
setblock 126 215 480 minecraft:magma_block
fill 126 215 494 126 223 494 minecraft:basalt
setblock 126 215 495 minecraft:magma_block
setblock 126 215 504 minecraft:magma_block
fill 127 215 473 130 215 473 minecraft:basalt
fill 127 215 481 127 222 481 minecraft:basalt
fill 127 215 493 127 222 493 minecraft:basalt
fill 127 215 503 128 215 503 minecraft:basalt
fill 127 215 504 127 273 504 minecraft:deepslate_bricks
fill 128 215 483 128 215 484 minecraft:basalt
fill 128 215 490 128 215 491 minecraft:basalt
fill 129 215 484 129 222 484 minecraft:basalt
setblock 129 215 485 minecraft:magma_block
fill 129 215 486 129 223 487 minecraft:basalt
setblock 129 215 488 minecraft:magma_block
fill 129 215 489 129 222 490 minecraft:basalt
fill 130 215 474 131 215 475 minecraft:basalt
fill 130 215 497 133 215 497 minecraft:basalt
fill 130 215 499 131 215 499 minecraft:basalt
fill 131 215 478 133 215 478 minecraft:basalt
fill 131 215 496 133 215 496 minecraft:basalt
setblock 131 215 500 minecraft:basalt
setblock 132 215 475 minecraft:magma_block
setblock 132 215 499 minecraft:magma_block
fill 133 215 479 134 215 479 minecraft:basalt
fill 133 215 494 134 215 494 minecraft:basalt
setblock 134 215 480 minecraft:basalt
fill 134 215 483 134 216 483 minecraft:basalt
fill 134 215 489 134 217 489 minecraft:basalt
fill 134 215 492 134 216 492 minecraft:basalt
setblock 134 215 495 minecraft:basalt
setblock 135 215 483 minecraft:magma_block
setblock 135 215 489 minecraft:magma_block
setblock 135 215 492 minecraft:magma_block
fill 97 216 485 99 216 485 minecraft:basalt
fill 98 216 481 99 216 481 minecraft:basalt
setblock 98 216 482 minecraft:magma_block
fill 98 216 484 99 217 484 minecraft:basalt
fill 98 216 490 99 217 490 minecraft:basalt
setblock 98 216 491 minecraft:magma_block
fill 98 216 492 99 216 493 minecraft:basalt
fill 99 216 479 99 216 480 minecraft:basalt
fill 99 216 482 99 217 482 minecraft:basalt
fill 99 216 491 99 217 491 minecraft:basalt
fill 99 216 494 99 216 495 minecraft:basalt
fill 99 216 496 99 230 496 minecraft:reinforced_deepslate
fill 100 216 480 103 216 480 minecraft:basalt
fill 100 216 492 101 218 492 minecraft:basalt
fill 100 216 495 103 216 495 minecraft:basalt
fill 101 216 498 105 216 498 minecraft:basalt
fill 102 216 474 102 216 475 minecraft:basalt
fill 102 216 499 102 216 500 minecraft:basalt
fill 103 216 500 103 216 501 minecraft:basalt
fill 104 216 485 104 224 485 minecraft:basalt
setblock 104 216 486 minecraft:magma_block
fill 104 216 487 104 224 488 minecraft:basalt
setblock 104 216 489 minecraft:magma_block
fill 104 216 500 108 217 500 minecraft:basalt
setblock 104 216 501 minecraft:magma_block
fill 105 216 472 111 216 472 minecraft:basalt
fill 105 216 481 105 223 483 minecraft:basalt
fill 105 216 491 105 223 493 minecraft:basalt
fill 105 216 501 105 216 502 minecraft:basalt
setblock 106 216 471 minecraft:basalt
setblock 106 216 481 minecraft:basalt
setblock 106 216 493 minecraft:basalt
fill 106 216 502 106 216 503 minecraft:basalt
setblock 107 216 479 minecraft:magma_block
fill 107 216 495 107 224 495 minecraft:basalt
fill 107 216 502 111 217 502 minecraft:basalt
setblock 107 216 503 minecraft:magma_block
fill 108 216 469 109 216 469 minecraft:deepslate_bricks
setblock 108 216 470 minecraft:basalt
fill 108 216 477 108 223 478 minecraft:basalt
fill 108 216 496 108 224 496 minecraft:basalt
fill 108 216 503 108 216 504 minecraft:basalt
fill 109 216 504 114 216 504 minecraft:basalt
fill 110 216 468 113 216 468 minecraft:deepslate_bricks
setblock 110 216 469 minecraft:magma_block
fill 110 216 477 110 224 477 minecraft:basalt
fill 110 216 497 110 224 497 minecraft:basalt
setblock 111 216 469 minecraft:basalt
fill 111 216 476 112 216 476 minecraft:basalt
fill 111 216 498 112 224 498 minecraft:basalt
fill 113 216 469 118 216 469 minecraft:basalt
setblock 114 216 468 minecraft:basalt
fill 114 216 475 118 222 475 minecraft:basalt
fill 114 216 498 119 216 498 minecraft:deepslate_bricks
fill 114 216 499 118 222 499 minecraft:basalt
fill 115 216 467 115 229 467 minecraft:deepslate_bricks
fill 116 216 468 118 216 468 minecraft:basalt
fill 117 216 474 117 223 474 minecraft:basalt
setblock 119 216 469 minecraft:magma_block
fill 119 216 470 124 216 470 minecraft:basalt
setblock 119 216 475 minecraft:magma_block
setblock 119 216 499 minecraft:magma_block
fill 119 216 503 124 217 503 minecraft:basalt
setblock 120 216 469 minecraft:basalt
fill 120 216 475 120 223 476 minecraft:basalt
fill 120 216 498 120 223 499 minecraft:basalt
fill 121 216 476 121 224 476 minecraft:basalt
fill 121 216 498 121 224 498 minecraft:basalt
fill 122 216 472 127 216 472 minecraft:basalt
setblock 122 216 477 minecraft:magma_block
fill 122 216 497 122 224 497 minecraft:basalt
fill 122 216 502 127 216 502 minecraft:basalt
fill 124 216 478 124 224 478 minecraft:basalt
fill 124 216 496 124 224 496 minecraft:basalt
setblock 124 216 504 minecraft:basalt
fill 125 216 471 126 216 471 minecraft:basalt
setblock 125 216 479 minecraft:magma_block
fill 125 216 495 126 223 495 minecraft:basalt
fill 125 216 500 129 216 501 minecraft:basalt
setblock 125 216 503 minecraft:magma_block
fill 125 216 504 126 216 504 minecraft:deepslate_bricks
fill 126 216 480 126 223 481 minecraft:basalt
fill 126 216 493 126 224 493 minecraft:basalt
fill 126 216 498 130 217 498 minecraft:basalt
setblock 126 216 503 minecraft:basalt
fill 127 216 473 129 216 473 minecraft:basalt
fill 127 216 482 127 216 483 minecraft:basalt
fill 127 216 491 127 224 492 minecraft:basalt
fill 128 216 476 131 216 476 minecraft:basalt
fill 128 216 483 128 223 483 minecraft:basalt
setblock 128 216 484 minecraft:magma_block
fill 128 216 485 128 224 486 minecraft:basalt
setblock 128 216 487 minecraft:magma_block
fill 128 216 488 128 224 489 minecraft:basalt
setblock 128 216 490 minecraft:magma_block
fill 128 216 491 128 223 491 minecraft:basalt
fill 129 216 485 129 222 485 minecraft:basalt
fill 129 216 488 129 223 488 minecraft:basalt
fill 130 216 474 130 216 475 minecraft:basalt
fill 130 216 482 133 217 482 minecraft:basalt
fill 130 216 497 132 216 497 minecraft:basalt
fill 130 216 499 130 216 500 minecraft:basalt
fill 131 216 478 132 216 478 minecraft:basalt
fill 131 216 481 134 216 481 minecraft:basalt
fill 131 216 493 134 216 493 minecraft:basalt
fill 131 216 496 132 216 496 minecraft:basalt
setblock 131 216 498 minecraft:magma_block
setblock 133 216 479 minecraft:basalt
fill 133 216 484 134 217 485 minecraft:basalt
fill 133 216 490 133 217 491 minecraft:basalt
setblock 133 216 494 minecraft:basalt
setblock 134 216 482 minecraft:magma_block
fill 134 216 490 134 217 490 minecraft:basalt
setblock 134 216 491 minecraft:magma_block
fill 135 216 484 135 273 484 minecraft:deepslate_bricks
setblock 135 216 485 minecraft:basalt
setblock 135 216 489 minecraft:basalt
fill 98 217 485 99 217 485 minecraft:basalt
fill 98 217 487 99 217 488 minecraft:basalt
setblock 99 217 481 minecraft:basalt
fill 99 217 483 101 217 483 minecraft:basalt
fill 99 217 492 99 217 493 minecraft:basalt
setblock 100 217 480 minecraft:magma_block
setblock 100 217 495 minecraft:magma_block
fill 101 217 477 102 217 478 minecraft:basalt
fill 101 217 480 103 218 480 minecraft:basalt
fill 101 217 495 102 217 496 minecraft:basalt
fill 102 217 476 106 217 476 minecraft:basalt
fill 102 217 498 105 217 498 minecraft:basalt
setblock 103 217 464 minecraft:sea_lantern
fill 103 217 465 103 229 465 minecraft:deepslate_bricks
setblock 103 217 466 minecraft:sea_lantern
fill 103 217 467 103 229 467 minecraft:deepslate_bricks
setblock 103 217 468 minecraft:sea_lantern
fill 103 217 469 103 229 469 minecraft:deepslate_bricks
fill 103 217 477 105 219 477 minecraft:basalt
fill 103 217 495 103 220 495 minecraft:basalt
fill 104 217 464 104 224 464 minecraft:deepslate_bricks
setblock 104 217 465 minecraft:sea_lantern
fill 104 217 466 104 229 466 minecraft:deepslate_bricks
setblock 104 217 467 minecraft:sea_lantern
fill 104 217 468 104 229 468 minecraft:deepslate_bricks
setblock 104 217 469 minecraft:sea_lantern
fill 104 217 474 105 217 474 minecraft:basalt
fill 104 217 486 105 217 486 minecraft:basalt
fill 104 217 489 105 217 489 minecraft:basalt
setblock 105 217 464 minecraft:sea_lantern
fill 105 217 465 105 229 465 minecraft:deepslate_bricks
setblock 105 217 466 minecraft:sea_lantern
fill 105 217 467 105 229 467 minecraft:deepslate_bricks
setblock 105 217 468 minecraft:sea_lantern
fill 105 217 469 105 229 469 minecraft:deepslate_bricks
fill 105 217 473 108 217 473 minecraft:basalt
fill 105 217 484 105 223 485 minecraft:basalt
fill 105 217 487 105 225 488 minecraft:basalt
fill 105 217 490 105 223 490 minecraft:basalt
setblock 105 217 501 minecraft:basalt
fill 106 217 464 106 229 464 minecraft:deepslate_bricks
setblock 106 217 465 minecraft:sea_lantern
fill 106 217 466 106 229 466 minecraft:deepslate_bricks
setblock 106 217 467 minecraft:sea_lantern
fill 106 217 468 106 229 468 minecraft:deepslate_bricks
setblock 106 217 469 minecraft:sea_lantern
setblock 106 217 472 minecraft:magma_block
setblock 106 217 481 minecraft:magma_block
fill 106 217 482 106 225 482 minecraft:basalt
fill 106 217 492 106 225 492 minecraft:basalt
setblock 106 217 493 minecraft:magma_block
setblock 106 217 502 minecraft:magma_block
setblock 107 217 464 minecraft:sea_lantern
fill 107 217 465 107 229 465 minecraft:deepslate_bricks
setblock 107 217 466 minecraft:sea_lantern
fill 107 217 467 107 229 467 minecraft:deepslate_bricks
setblock 107 217 468 minecraft:sea_lantern
fill 107 217 469 107 229 469 minecraft:deepslate_bricks
fill 107 217 472 111 217 472 minecraft:basalt
fill 107 217 479 107 224 480 minecraft:basalt
fill 107 217 494 107 224 494 minecraft:basalt
fill 108 217 464 108 273 464 minecraft:deepslate_bricks
setblock 108 217 465 minecraft:sea_lantern
fill 108 217 466 108 229 466 minecraft:deepslate_bricks
setblock 108 217 467 minecraft:sea_lantern
fill 108 217 468 108 229 468 minecraft:deepslate_bricks
setblock 108 217 469 minecraft:sea_lantern
setblock 108 217 471 minecraft:basalt
fill 108 217 479 108 224 479 minecraft:basalt
fill 108 217 495 108 223 495 minecraft:basalt
setblock 108 217 503 minecraft:basalt
setblock 109 217 464 minecraft:sea_lantern
fill 109 217 465 109 229 465 minecraft:deepslate_bricks
setblock 109 217 466 minecraft:sea_lantern
fill 109 217 467 109 229 467 minecraft:deepslate_bricks
setblock 109 217 468 minecraft:sea_lantern
fill 109 217 469 109 229 469 minecraft:deepslate_bricks
setblock 109 217 471 minecraft:magma_block
fill 109 217 478 109 224 478 minecraft:basalt
fill 109 217 496 109 224 496 minecraft:basalt
fill 110 217 464 110 229 464 minecraft:deepslate_bricks
setblock 110 217 465 minecraft:sea_lantern
fill 110 217 466 110 229 466 minecraft:deepslate_bricks
setblock 110 217 467 minecraft:sea_lantern
fill 110 217 468 110 229 468 minecraft:deepslate_bricks
setblock 110 217 469 minecraft:sea_lantern
fill 110 217 470 111 217 471 minecraft:basalt
fill 110 217 504 114 217 504 minecraft:basalt
setblock 111 217 464 minecraft:sea_lantern
fill 111 217 465 111 229 465 minecraft:deepslate_bricks
setblock 111 217 466 minecraft:sea_lantern
fill 111 217 467 111 229 467 minecraft:deepslate_bricks
setblock 111 217 468 minecraft:sea_lantern
fill 111 217 469 111 229 469 minecraft:deepslate_bricks
fill 111 217 476 111 223 477 minecraft:basalt
fill 111 217 497 111 225 497 minecraft:basalt
fill 112 217 464 112 224 464 minecraft:deepslate_bricks
setblock 112 217 465 minecraft:sea_lantern
fill 112 217 466 112 229 466 minecraft:deepslate_bricks
setblock 112 217 467 minecraft:sea_lantern
fill 112 217 468 112 229 468 minecraft:deepslate_bricks
setblock 112 217 469 minecraft:sea_lantern
setblock 112 217 470 minecraft:magma_block
fill 112 217 471 114 219 471 minecraft:basalt
setblock 112 217 476 minecraft:magma_block
setblock 113 217 464 minecraft:sea_lantern
fill 113 217 465 113 229 465 minecraft:deepslate_bricks
setblock 113 217 466 minecraft:sea_lantern
fill 113 217 467 113 229 467 minecraft:deepslate_bricks
setblock 113 217 468 minecraft:sea_lantern
fill 113 217 469 114 217 470 minecraft:basalt
fill 113 217 476 119 217 476 minecraft:basalt
fill 113 217 498 117 217 498 minecraft:basalt
fill 114 217 464 114 224 464 minecraft:deepslate_bricks
setblock 114 217 465 minecraft:sea_lantern
fill 114 217 466 114 229 466 minecraft:deepslate_bricks
setblock 114 217 467 minecraft:sea_lantern
fill 114 217 468 114 229 468 minecraft:deepslate_bricks
setblock 115 217 464 minecraft:sea_lantern
fill 115 217 465 115 229 465 minecraft:deepslate_bricks
setblock 115 217 466 minecraft:sea_lantern
setblock 115 217 468 minecraft:sea_lantern
setblock 115 217 469 minecraft:magma_block
fill 115 217 470 117 217 470 minecraft:basalt
fill 116 217 469 119 217 469 minecraft:basalt
fill 116 217 504 122 217 504 minecraft:basalt
setblock 118 217 498 minecraft:magma_block
fill 119 217 470 120 217 470 minecraft:basalt
fill 119 217 475 119 223 475 minecraft:basalt
fill 119 217 498 119 223 499 minecraft:basalt
setblock 121 217 470 minecraft:magma_block
fill 121 217 477 122 224 477 minecraft:basalt
setblock 121 217 497 minecraft:magma_block
setblock 122 217 470 minecraft:basalt
fill 122 217 472 126 217 472 minecraft:basalt
fill 122 217 502 126 217 502 minecraft:basalt
fill 123 217 478 123 223 478 minecraft:basalt
fill 123 217 496 123 223 496 minecraft:basalt
setblock 123 217 504 minecraft:sea_lantern
fill 124 217 479 125 224 479 minecraft:basalt
fill 124 217 495 124 224 495 minecraft:basalt
fill 124 217 504 124 230 504 minecraft:deepslate_bricks
fill 125 217 474 128 217 475 minecraft:basalt
fill 125 217 480 125 224 480 minecraft:basalt
fill 125 217 494 125 224 494 minecraft:basalt
fill 125 217 500 126 218 501 minecraft:basalt
fill 125 217 503 125 230 503 minecraft:deepslate_bricks
setblock 125 217 504 minecraft:sea_lantern
fill 126 217 482 127 217 482 minecraft:basalt
fill 126 217 492 126 225 492 minecraft:basalt
setblock 126 217 503 minecraft:sea_lantern
fill 126 217 504 126 273 504 minecraft:deepslate_bricks
setblock 127 217 473 minecraft:basalt
fill 127 217 477 131 217 477 minecraft:basalt
setblock 127 217 483 minecraft:magma_block
schedule function dropper:buildpart/110_2 1t
