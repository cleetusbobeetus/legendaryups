setblock 192 109 630 minecraft:sea_lantern
setblock 192 109 632 minecraft:sea_lantern
setblock 192 109 634 minecraft:sea_lantern
setblock 192 109 636 minecraft:sea_lantern
setblock 192 109 638 minecraft:sea_lantern
fill 216 109 617 217 110 617 minecraft:yellow_concrete
setblock 220 109 638 minecraft:sea_lantern
setblock 220 109 640 minecraft:sea_lantern
setblock 220 109 642 minecraft:sea_lantern
setblock 220 109 644 minecraft:sea_lantern
setblock 221 109 637 minecraft:sea_lantern
setblock 221 109 639 minecraft:sea_lantern
setblock 221 109 641 minecraft:sea_lantern
setblock 221 109 643 minecraft:sea_lantern
setblock 221 109 645 minecraft:sea_lantern
setblock 222 109 638 minecraft:sea_lantern
setblock 222 109 640 minecraft:sea_lantern
setblock 222 109 642 minecraft:sea_lantern
setblock 222 109 644 minecraft:sea_lantern
setblock 223 109 637 minecraft:sea_lantern
setblock 223 109 639 minecraft:sea_lantern
setblock 223 109 641 minecraft:sea_lantern
setblock 223 109 643 minecraft:sea_lantern
setblock 223 109 645 minecraft:sea_lantern
setblock 224 109 638 minecraft:sea_lantern
setblock 224 109 640 minecraft:sea_lantern
setblock 224 109 642 minecraft:sea_lantern
setblock 224 109 644 minecraft:sea_lantern
setblock 225 109 637 minecraft:sea_lantern
setblock 225 109 639 minecraft:sea_lantern
setblock 225 109 641 minecraft:sea_lantern
setblock 225 109 643 minecraft:sea_lantern
setblock 225 109 645 minecraft:sea_lantern
setblock 226 109 638 minecraft:sea_lantern
setblock 226 109 640 minecraft:sea_lantern
setblock 226 109 642 minecraft:sea_lantern
setblock 226 109 644 minecraft:sea_lantern
setblock 227 109 637 minecraft:sea_lantern
setblock 227 109 639 minecraft:sea_lantern
setblock 227 109 641 minecraft:sea_lantern
setblock 227 109 643 minecraft:sea_lantern
setblock 227 109 645 minecraft:sea_lantern
setblock 228 109 638 minecraft:sea_lantern
setblock 228 109 640 minecraft:sea_lantern
setblock 228 109 642 minecraft:sea_lantern
setblock 228 109 644 minecraft:sea_lantern
fill 189 110 627 189 111 627 minecraft:black_concrete
fill 189 110 629 189 111 629 minecraft:black_concrete
fill 189 110 631 189 111 631 minecraft:black_concrete
fill 189 110 633 189 111 633 minecraft:black_concrete
fill 189 110 635 189 111 635 minecraft:black_concrete
fill 189 110 637 189 111 637 minecraft:black_concrete
fill 189 110 639 189 111 639 minecraft:black_concrete
fill 190 110 628 190 111 628 minecraft:black_concrete
fill 190 110 630 190 111 630 minecraft:black_concrete
fill 190 110 632 190 111 632 minecraft:black_concrete
fill 190 110 634 190 111 634 minecraft:black_concrete
fill 190 110 636 190 111 636 minecraft:black_concrete
fill 190 110 638 190 111 638 minecraft:black_concrete
setblock 191 110 607 minecraft:light[level=14]
setblock 191 110 615 minecraft:light[level=14]
setblock 191 110 623 minecraft:light[level=14]
fill 191 110 627 191 111 627 minecraft:black_concrete
fill 191 110 629 191 111 629 minecraft:black_concrete
fill 191 110 631 191 111 631 minecraft:black_concrete
fill 191 110 633 191 111 633 minecraft:black_concrete
fill 191 110 635 191 111 635 minecraft:black_concrete
fill 191 110 637 191 111 637 minecraft:black_concrete
fill 191 110 639 191 111 639 minecraft:black_concrete
fill 192 110 628 192 111 628 minecraft:black_concrete
fill 192 110 630 192 111 630 minecraft:black_concrete
fill 192 110 632 192 111 632 minecraft:black_concrete
fill 192 110 634 192 111 634 minecraft:black_concrete
fill 192 110 636 192 111 636 minecraft:black_concrete
fill 192 110 638 192 111 638 minecraft:black_concrete
setblock 199 110 607 minecraft:light[level=14]
setblock 199 110 615 minecraft:light[level=14]
setblock 199 110 623 minecraft:light[level=14]
setblock 199 110 631 minecraft:light[level=14]
setblock 199 110 639 minecraft:light[level=14]
setblock 207 110 607 minecraft:light[level=14]
setblock 207 110 615 minecraft:light[level=14]
setblock 207 110 623 minecraft:light[level=14]
setblock 207 110 631 minecraft:light[level=14]
setblock 207 110 639 minecraft:light[level=14]
setblock 215 110 607 minecraft:light[level=14]
setblock 215 110 615 minecraft:light[level=14]
setblock 215 110 623 minecraft:light[level=14]
setblock 215 110 631 minecraft:light[level=14]
fill 220 110 638 220 111 638 minecraft:black_concrete
fill 220 110 640 220 111 640 minecraft:black_concrete
fill 220 110 642 220 111 642 minecraft:black_concrete
fill 220 110 644 220 111 644 minecraft:black_concrete
fill 221 110 637 221 111 637 minecraft:black_concrete
fill 221 110 639 221 111 639 minecraft:black_concrete
fill 221 110 641 221 111 641 minecraft:black_concrete
fill 221 110 643 221 111 643 minecraft:black_concrete
fill 221 110 645 221 111 645 minecraft:black_concrete
fill 222 110 638 222 111 638 minecraft:black_concrete
fill 222 110 640 222 111 640 minecraft:black_concrete
fill 222 110 642 222 111 642 minecraft:black_concrete
fill 222 110 644 222 111 644 minecraft:black_concrete
setblock 223 110 607 minecraft:light[level=14]
setblock 223 110 615 minecraft:light[level=14]
setblock 223 110 623 minecraft:light[level=14]
setblock 223 110 631 minecraft:light[level=14]
fill 223 110 637 223 111 637 minecraft:black_concrete
fill 223 110 639 223 111 639 minecraft:black_concrete
fill 223 110 641 223 111 641 minecraft:black_concrete
fill 223 110 643 223 111 643 minecraft:black_concrete
fill 223 110 645 223 111 645 minecraft:black_concrete
fill 224 110 638 224 111 638 minecraft:black_concrete
fill 224 110 640 224 111 640 minecraft:black_concrete
fill 224 110 642 224 111 642 minecraft:black_concrete
fill 224 110 644 224 111 644 minecraft:black_concrete
fill 225 110 637 225 111 637 minecraft:black_concrete
fill 225 110 639 225 111 639 minecraft:black_concrete
fill 225 110 641 225 111 641 minecraft:black_concrete
fill 225 110 643 225 111 643 minecraft:black_concrete
fill 225 110 645 225 111 645 minecraft:black_concrete
fill 226 110 638 226 111 638 minecraft:black_concrete
fill 226 110 640 226 111 640 minecraft:black_concrete
fill 226 110 642 226 111 642 minecraft:black_concrete
fill 226 110 644 226 111 644 minecraft:black_concrete
fill 227 110 637 227 111 637 minecraft:black_concrete
fill 227 110 639 227 111 639 minecraft:black_concrete
fill 227 110 641 227 111 641 minecraft:black_concrete
fill 227 110 643 227 111 643 minecraft:black_concrete
fill 227 110 645 227 111 645 minecraft:black_concrete
fill 228 110 638 228 111 638 minecraft:black_concrete
fill 228 110 640 228 111 640 minecraft:black_concrete
fill 228 110 642 228 111 642 minecraft:black_concrete
fill 228 110 644 228 111 644 minecraft:black_concrete
fill 189 112 605 189 113 610 minecraft:black_concrete
fill 189 112 613 190 112 618 minecraft:black_concrete
fill 189 112 621 190 112 626 minecraft:black_concrete
setblock 189 112 627 minecraft:sea_lantern
setblock 189 112 629 minecraft:sea_lantern
setblock 189 112 631 minecraft:sea_lantern
setblock 189 112 633 minecraft:sea_lantern
setblock 189 112 635 minecraft:sea_lantern
setblock 189 112 637 minecraft:sea_lantern
setblock 189 112 639 minecraft:sea_lantern
fill 189 112 640 190 112 642 minecraft:black_concrete
fill 189 112 645 194 113 645 minecraft:black_concrete
fill 190 112 606 190 112 612 minecraft:black_concrete
fill 190 112 619 190 112 620 minecraft:black_concrete
setblock 190 112 628 minecraft:sea_lantern
setblock 190 112 630 minecraft:sea_lantern
setblock 190 112 632 minecraft:sea_lantern
setblock 190 112 634 minecraft:sea_lantern
setblock 190 112 636 minecraft:sea_lantern
setblock 190 112 638 minecraft:sea_lantern
fill 190 112 643 190 112 644 minecraft:black_concrete
fill 191 112 606 228 112 606 minecraft:black_concrete
setblock 191 112 627 minecraft:sea_lantern
setblock 191 112 629 minecraft:sea_lantern
setblock 191 112 631 minecraft:sea_lantern
setblock 191 112 633 minecraft:sea_lantern
setblock 191 112 635 minecraft:sea_lantern
setblock 191 112 637 minecraft:sea_lantern
setblock 191 112 639 minecraft:sea_lantern
fill 191 112 644 212 112 644 minecraft:black_concrete
fill 192 112 605 197 113 605 minecraft:black_concrete
setblock 192 112 628 minecraft:sea_lantern
setblock 192 112 630 minecraft:sea_lantern
setblock 192 112 632 minecraft:sea_lantern
setblock 192 112 634 minecraft:sea_lantern
setblock 192 112 636 minecraft:sea_lantern
setblock 192 112 638 minecraft:sea_lantern
fill 197 112 645 202 113 645 minecraft:black_concrete
fill 200 112 605 205 113 605 minecraft:black_concrete
fill 205 112 645 210 113 645 minecraft:black_concrete
fill 208 112 605 213 113 605 minecraft:black_concrete
fill 216 112 605 221 113 605 minecraft:black_concrete
setblock 220 112 638 minecraft:sea_lantern
setblock 220 112 640 minecraft:sea_lantern
setblock 220 112 642 minecraft:sea_lantern
setblock 220 112 644 minecraft:sea_lantern
setblock 221 112 637 minecraft:sea_lantern
setblock 221 112 639 minecraft:sea_lantern
setblock 221 112 641 minecraft:sea_lantern
setblock 221 112 643 minecraft:sea_lantern
setblock 221 112 645 minecraft:sea_lantern
setblock 222 112 638 minecraft:sea_lantern
setblock 222 112 640 minecraft:sea_lantern
setblock 222 112 642 minecraft:sea_lantern
setblock 222 112 644 minecraft:sea_lantern
setblock 223 112 637 minecraft:sea_lantern
setblock 223 112 639 minecraft:sea_lantern
setblock 223 112 641 minecraft:sea_lantern
setblock 223 112 643 minecraft:sea_lantern
setblock 223 112 645 minecraft:sea_lantern
fill 224 112 605 229 113 605 minecraft:black_concrete
setblock 224 112 638 minecraft:sea_lantern
setblock 224 112 640 minecraft:sea_lantern
setblock 224 112 642 minecraft:sea_lantern
setblock 224 112 644 minecraft:sea_lantern
setblock 225 112 637 minecraft:sea_lantern
setblock 225 112 639 minecraft:sea_lantern
setblock 225 112 641 minecraft:sea_lantern
setblock 225 112 643 minecraft:sea_lantern
setblock 225 112 645 minecraft:sea_lantern
setblock 226 112 638 minecraft:sea_lantern
setblock 226 112 640 minecraft:sea_lantern
setblock 226 112 642 minecraft:sea_lantern
setblock 226 112 644 minecraft:sea_lantern
setblock 227 112 637 minecraft:sea_lantern
setblock 227 112 639 minecraft:sea_lantern
setblock 227 112 641 minecraft:sea_lantern
setblock 227 112 643 minecraft:sea_lantern
setblock 227 112 645 minecraft:sea_lantern
fill 228 112 607 228 112 636 minecraft:black_concrete
setblock 228 112 638 minecraft:sea_lantern
setblock 228 112 640 minecraft:sea_lantern
setblock 228 112 642 minecraft:sea_lantern
setblock 228 112 644 minecraft:sea_lantern
fill 229 112 608 229 113 613 minecraft:black_concrete
fill 229 112 616 229 113 621 minecraft:black_concrete
fill 229 112 624 229 113 629 minecraft:black_concrete
fill 229 112 632 229 113 637 minecraft:black_concrete
fill 229 112 640 229 113 645 minecraft:black_concrete
fill 189 113 613 189 113 618 minecraft:black_concrete
fill 189 113 621 189 113 627 minecraft:black_concrete
fill 189 113 629 189 114 629 minecraft:black_concrete
fill 189 113 631 189 114 631 minecraft:black_concrete
fill 189 113 633 189 114 633 minecraft:black_concrete
fill 189 113 635 189 114 635 minecraft:black_concrete
fill 189 113 637 189 114 637 minecraft:black_concrete
fill 189 113 639 189 113 642 minecraft:black_concrete
fill 190 113 628 190 114 628 minecraft:black_concrete
fill 190 113 630 190 114 630 minecraft:black_concrete
fill 190 113 632 190 114 632 minecraft:black_concrete
fill 190 113 634 190 114 634 minecraft:black_concrete
fill 190 113 636 190 114 636 minecraft:black_concrete
fill 190 113 638 190 114 638 minecraft:black_concrete
fill 191 113 627 191 114 627 minecraft:black_concrete
fill 191 113 629 191 114 629 minecraft:black_concrete
fill 191 113 631 191 114 631 minecraft:black_concrete
fill 191 113 633 191 114 633 minecraft:black_concrete
fill 191 113 635 191 114 635 minecraft:black_concrete
fill 191 113 637 191 114 637 minecraft:black_concrete
fill 191 113 639 191 114 639 minecraft:black_concrete
fill 192 113 628 192 114 628 minecraft:black_concrete
fill 192 113 630 192 114 630 minecraft:black_concrete
fill 192 113 632 192 114 632 minecraft:black_concrete
fill 192 113 634 192 114 634 minecraft:black_concrete
fill 192 113 636 192 114 636 minecraft:black_concrete
fill 192 113 638 192 114 638 minecraft:black_concrete
fill 220 113 638 220 114 638 minecraft:black_concrete
fill 220 113 640 220 114 640 minecraft:black_concrete
fill 220 113 642 220 114 642 minecraft:black_concrete
fill 220 113 644 220 114 644 minecraft:black_concrete
fill 221 113 637 221 114 637 minecraft:black_concrete
fill 221 113 639 221 114 639 minecraft:black_concrete
fill 221 113 641 221 114 641 minecraft:black_concrete
fill 221 113 643 221 114 643 minecraft:black_concrete
fill 221 113 645 221 114 645 minecraft:black_concrete
fill 222 113 638 222 114 638 minecraft:black_concrete
fill 222 113 640 222 114 640 minecraft:black_concrete
fill 222 113 642 222 114 642 minecraft:black_concrete
fill 222 113 644 222 114 644 minecraft:black_concrete
fill 223 113 637 223 114 637 minecraft:black_concrete
fill 223 113 639 223 114 639 minecraft:black_concrete
fill 223 113 641 223 114 641 minecraft:black_concrete
fill 223 113 643 223 114 643 minecraft:black_concrete
fill 223 113 645 223 114 645 minecraft:black_concrete
fill 224 113 638 224 114 638 minecraft:black_concrete
fill 224 113 640 224 114 640 minecraft:black_concrete
fill 224 113 642 224 114 642 minecraft:black_concrete
fill 224 113 644 224 114 644 minecraft:black_concrete
fill 225 113 637 225 114 637 minecraft:black_concrete
fill 225 113 639 225 114 639 minecraft:black_concrete
fill 225 113 641 225 114 641 minecraft:black_concrete
fill 225 113 643 225 114 643 minecraft:black_concrete
fill 225 113 645 225 114 645 minecraft:black_concrete
fill 226 113 638 226 114 638 minecraft:black_concrete
fill 226 113 640 226 114 640 minecraft:black_concrete
fill 226 113 642 226 114 642 minecraft:black_concrete
fill 226 113 644 226 114 644 minecraft:black_concrete
fill 227 113 637 227 114 637 minecraft:black_concrete
fill 227 113 639 227 114 639 minecraft:black_concrete
fill 227 113 641 227 114 641 minecraft:black_concrete
fill 227 113 643 227 114 643 minecraft:black_concrete
fill 227 113 645 227 114 645 minecraft:black_concrete
fill 228 113 638 228 114 638 minecraft:black_concrete
fill 228 113 640 228 114 640 minecraft:black_concrete
fill 228 113 642 228 114 642 minecraft:black_concrete
fill 228 113 644 228 114 644 minecraft:black_concrete
setblock 189 114 627 minecraft:black_concrete
setblock 189 114 639 minecraft:black_concrete
setblock 189 115 627 minecraft:sea_lantern
setblock 189 115 629 minecraft:sea_lantern
setblock 189 115 631 minecraft:sea_lantern
setblock 189 115 633 minecraft:sea_lantern
setblock 189 115 635 minecraft:sea_lantern
setblock 189 115 637 minecraft:sea_lantern
setblock 189 115 639 minecraft:sea_lantern
setblock 190 115 628 minecraft:sea_lantern
setblock 190 115 630 minecraft:sea_lantern
setblock 190 115 632 minecraft:sea_lantern
setblock 190 115 634 minecraft:sea_lantern
setblock 190 115 636 minecraft:sea_lantern
setblock 190 115 638 minecraft:sea_lantern
setblock 191 115 627 minecraft:sea_lantern
setblock 191 115 629 minecraft:sea_lantern
setblock 191 115 631 minecraft:sea_lantern
setblock 191 115 633 minecraft:sea_lantern
setblock 191 115 635 minecraft:sea_lantern
setblock 191 115 637 minecraft:sea_lantern
setblock 191 115 639 minecraft:sea_lantern
setblock 192 115 628 minecraft:sea_lantern
setblock 192 115 630 minecraft:sea_lantern
setblock 192 115 632 minecraft:sea_lantern
setblock 192 115 634 minecraft:sea_lantern
setblock 192 115 636 minecraft:sea_lantern
setblock 192 115 638 minecraft:sea_lantern
setblock 220 115 638 minecraft:sea_lantern
setblock 220 115 640 minecraft:sea_lantern
setblock 220 115 642 minecraft:sea_lantern
setblock 220 115 644 minecraft:sea_lantern
setblock 221 115 637 minecraft:sea_lantern
setblock 221 115 639 minecraft:sea_lantern
setblock 221 115 641 minecraft:sea_lantern
setblock 221 115 643 minecraft:sea_lantern
setblock 221 115 645 minecraft:sea_lantern
setblock 222 115 638 minecraft:sea_lantern
setblock 222 115 640 minecraft:sea_lantern
setblock 222 115 642 minecraft:sea_lantern
setblock 222 115 644 minecraft:sea_lantern
setblock 223 115 637 minecraft:sea_lantern
setblock 223 115 639 minecraft:sea_lantern
setblock 223 115 641 minecraft:sea_lantern
setblock 223 115 643 minecraft:sea_lantern
setblock 223 115 645 minecraft:sea_lantern
setblock 224 115 638 minecraft:sea_lantern
setblock 224 115 640 minecraft:sea_lantern
setblock 224 115 642 minecraft:sea_lantern
setblock 224 115 644 minecraft:sea_lantern
setblock 225 115 637 minecraft:sea_lantern
setblock 225 115 639 minecraft:sea_lantern
setblock 225 115 641 minecraft:sea_lantern
setblock 225 115 643 minecraft:sea_lantern
setblock 225 115 645 minecraft:sea_lantern
setblock 226 115 638 minecraft:sea_lantern
setblock 226 115 640 minecraft:sea_lantern
setblock 226 115 642 minecraft:sea_lantern
setblock 226 115 644 minecraft:sea_lantern
setblock 227 115 637 minecraft:sea_lantern
setblock 227 115 639 minecraft:sea_lantern
setblock 227 115 641 minecraft:sea_lantern
setblock 227 115 643 minecraft:sea_lantern
setblock 227 115 645 minecraft:sea_lantern
setblock 228 115 638 minecraft:sea_lantern
setblock 228 115 640 minecraft:sea_lantern
setblock 228 115 642 minecraft:sea_lantern
setblock 228 115 644 minecraft:sea_lantern
fill 188 116 609 188 117 609 minecraft:sea_lantern
fill 188 116 617 188 117 617 minecraft:sea_lantern
fill 188 116 625 188 117 625 minecraft:sea_lantern
fill 188 116 633 188 117 633 minecraft:sea_lantern
fill 188 116 641 188 117 641 minecraft:sea_lantern
fill 189 116 627 189 117 627 minecraft:black_concrete
fill 189 116 629 189 117 629 minecraft:black_concrete
fill 189 116 631 189 117 631 minecraft:black_concrete
fill 189 116 633 189 117 633 minecraft:black_concrete
fill 189 116 635 189 117 635 minecraft:black_concrete
fill 189 116 637 189 117 637 minecraft:black_concrete
fill 189 116 639 189 117 639 minecraft:black_concrete
fill 190 116 628 190 117 628 minecraft:black_concrete
fill 190 116 630 190 117 630 minecraft:black_concrete
fill 190 116 632 190 117 632 minecraft:black_concrete
fill 190 116 634 190 117 634 minecraft:black_concrete
fill 190 116 636 190 117 636 minecraft:black_concrete
fill 190 116 638 190 117 638 minecraft:black_concrete
fill 191 116 627 191 117 627 minecraft:black_concrete
fill 191 116 629 191 117 629 minecraft:black_concrete
fill 191 116 631 191 117 631 minecraft:black_concrete
fill 191 116 633 191 117 633 minecraft:black_concrete
fill 191 116 635 191 117 635 minecraft:black_concrete
fill 191 116 637 191 117 637 minecraft:black_concrete
fill 191 116 639 191 117 639 minecraft:black_concrete
fill 191 116 646 191 117 646 minecraft:sea_lantern
fill 192 116 628 192 117 628 minecraft:black_concrete
fill 192 116 630 192 117 630 minecraft:black_concrete
fill 192 116 632 192 117 632 minecraft:black_concrete
fill 192 116 634 192 117 634 minecraft:black_concrete
fill 192 116 636 192 117 636 minecraft:black_concrete
fill 192 116 638 192 117 638 minecraft:black_concrete
fill 195 116 604 195 117 604 minecraft:sea_lantern
fill 199 116 646 199 117 646 minecraft:sea_lantern
fill 203 116 604 203 117 604 minecraft:sea_lantern
fill 207 116 646 207 117 646 minecraft:sea_lantern
fill 211 116 604 211 117 604 minecraft:sea_lantern
fill 215 116 646 215 117 646 minecraft:sea_lantern
fill 219 116 604 219 117 604 minecraft:sea_lantern
fill 220 116 638 220 117 638 minecraft:black_concrete
fill 220 116 640 220 117 640 minecraft:black_concrete
fill 220 116 642 220 117 642 minecraft:black_concrete
fill 220 116 644 220 117 644 minecraft:black_concrete
fill 221 116 637 221 117 637 minecraft:black_concrete
fill 221 116 639 221 117 639 minecraft:black_concrete
fill 221 116 641 221 117 641 minecraft:black_concrete
fill 221 116 643 221 117 643 minecraft:black_concrete
fill 221 116 645 221 117 645 minecraft:black_concrete
fill 222 116 638 222 117 638 minecraft:black_concrete
fill 222 116 640 222 117 640 minecraft:black_concrete
fill 222 116 642 222 117 642 minecraft:black_concrete
fill 222 116 644 222 117 644 minecraft:black_concrete
fill 223 116 637 223 117 637 minecraft:black_concrete
fill 223 116 639 223 117 639 minecraft:black_concrete
fill 223 116 641 223 117 641 minecraft:black_concrete
fill 223 116 643 223 117 643 minecraft:black_concrete
fill 223 116 645 223 117 645 minecraft:black_concrete
fill 223 116 646 223 117 646 minecraft:sea_lantern
fill 224 116 638 224 117 638 minecraft:black_concrete
fill 224 116 640 224 117 640 minecraft:black_concrete
fill 224 116 642 224 117 642 minecraft:black_concrete
fill 224 116 644 224 117 644 minecraft:black_concrete
fill 225 116 637 225 117 637 minecraft:black_concrete
fill 225 116 639 225 117 639 minecraft:black_concrete
fill 225 116 641 225 117 641 minecraft:black_concrete
fill 225 116 643 225 117 643 minecraft:black_concrete
fill 225 116 645 225 117 645 minecraft:black_concrete
fill 226 116 638 226 117 638 minecraft:black_concrete
fill 226 116 640 226 117 640 minecraft:black_concrete
fill 226 116 642 226 117 642 minecraft:black_concrete
fill 226 116 644 226 117 644 minecraft:black_concrete
fill 227 116 604 227 117 604 minecraft:sea_lantern
fill 227 116 637 227 117 637 minecraft:black_concrete
fill 227 116 639 227 117 639 minecraft:black_concrete
fill 227 116 641 227 117 641 minecraft:black_concrete
fill 227 116 643 227 117 643 minecraft:black_concrete
fill 227 116 645 227 117 645 minecraft:black_concrete
fill 228 116 638 228 117 638 minecraft:black_concrete
fill 228 116 640 228 117 640 minecraft:black_concrete
fill 228 116 642 228 117 642 minecraft:black_concrete
fill 228 116 644 228 117 644 minecraft:black_concrete
fill 230 116 609 230 117 609 minecraft:sea_lantern
fill 230 116 617 230 117 617 minecraft:sea_lantern
fill 230 116 625 230 117 625 minecraft:sea_lantern
fill 230 116 633 230 117 633 minecraft:sea_lantern
fill 230 116 641 230 117 641 minecraft:sea_lantern
fill 188 118 609 188 129 609 minecraft:cyan_concrete
fill 188 118 617 188 129 617 minecraft:cyan_concrete
fill 188 118 625 188 129 625 minecraft:cyan_concrete
fill 188 118 633 188 129 633 minecraft:cyan_concrete
fill 188 118 641 188 129 641 minecraft:cyan_concrete
setblock 191 118 607 minecraft:light[level=14]
setblock 191 118 615 minecraft:light[level=14]
setblock 191 118 623 minecraft:light[level=14]
setblock 191 118 631 minecraft:light[level=14]
setblock 191 118 639 minecraft:light[level=14]
fill 191 118 646 191 129 646 minecraft:cyan_concrete
fill 195 118 604 195 129 604 minecraft:cyan_concrete
setblock 199 118 607 minecraft:light[level=14]
setblock 199 118 615 minecraft:light[level=14]
setblock 199 118 623 minecraft:light[level=14]
setblock 199 118 631 minecraft:light[level=14]
setblock 199 118 639 minecraft:light[level=14]
fill 199 118 646 199 129 646 minecraft:cyan_concrete
fill 203 118 604 203 129 604 minecraft:cyan_concrete
setblock 207 118 607 minecraft:light[level=14]
setblock 207 118 615 minecraft:light[level=14]
setblock 207 118 623 minecraft:light[level=14]
setblock 207 118 631 minecraft:light[level=14]
setblock 207 118 639 minecraft:light[level=14]
fill 207 118 646 207 129 646 minecraft:cyan_concrete
fill 211 118 604 211 129 604 minecraft:cyan_concrete
setblock 215 118 607 minecraft:light[level=14]
setblock 215 118 615 minecraft:light[level=14]
setblock 215 118 623 minecraft:light[level=14]
setblock 215 118 631 minecraft:light[level=14]
setblock 215 118 639 minecraft:light[level=14]
fill 215 118 646 215 129 646 minecraft:cyan_concrete
fill 219 118 604 219 129 604 minecraft:cyan_concrete
setblock 223 118 607 minecraft:light[level=14]
setblock 223 118 615 minecraft:light[level=14]
setblock 223 118 623 minecraft:light[level=14]
setblock 223 118 631 minecraft:light[level=14]
setblock 223 118 639 minecraft:light[level=14]
fill 223 118 646 223 129 646 minecraft:cyan_concrete
fill 227 118 604 227 129 604 minecraft:cyan_concrete
fill 230 118 609 230 129 609 minecraft:cyan_concrete
fill 230 118 617 230 129 617 minecraft:cyan_concrete
fill 230 118 625 230 129 625 minecraft:cyan_concrete
fill 230 118 633 230 129 633 minecraft:cyan_concrete
fill 230 118 641 230 129 641 minecraft:cyan_concrete
fill 206 122 620 208 122 622 minecraft:redstone_block
fill 210 122 628 212 122 630 minecraft:redstone_block
fill 215 122 624 217 122 626 minecraft:redstone_block
fill 199 123 620 205 123 620 minecraft:yellow_concrete
fill 199 123 628 209 123 628 minecraft:yellow_concrete
fill 200 123 619 202 124 619 minecraft:yellow_concrete
fill 200 123 621 205 123 621 minecraft:yellow_concrete
fill 200 123 627 217 123 627 minecraft:yellow_concrete
fill 200 123 629 202 124 629 minecraft:yellow_concrete
fill 201 123 622 205 123 622 minecraft:yellow_concrete
fill 201 123 626 214 123 626 minecraft:yellow_concrete
fill 203 123 623 209 123 623 minecraft:yellow_concrete
fill 203 123 625 209 123 625 minecraft:yellow_concrete
fill 204 123 612 204 124 613 minecraft:yellow_concrete
fill 204 123 635 204 124 636 minecraft:yellow_concrete
fill 205 123 613 205 124 617 minecraft:yellow_concrete
fill 205 123 624 209 123 624 minecraft:yellow_concrete
fill 205 123 631 205 124 635 minecraft:yellow_concrete
fill 206 123 614 207 123 619 minecraft:yellow_concrete
fill 206 123 629 207 123 634 minecraft:yellow_concrete
fill 208 123 615 208 123 619 minecraft:yellow_concrete
fill 208 123 629 208 123 633 minecraft:yellow_concrete
fill 209 123 617 209 123 622 minecraft:yellow_concrete
fill 209 123 629 209 123 631 minecraft:yellow_concrete
fill 210 123 618 217 123 622 minecraft:yellow_concrete
fill 211 123 614 214 123 617 minecraft:yellow_concrete
fill 211 123 631 214 123 634 minecraft:yellow_concrete
fill 212 123 613 214 124 613 minecraft:yellow_concrete
fill 212 123 635 214 124 635 minecraft:yellow_concrete
fill 213 123 611 213 124 612 minecraft:yellow_concrete
fill 213 123 623 214 123 625 minecraft:yellow_concrete
fill 213 123 628 218 123 630 minecraft:yellow_concrete
fill 213 123 636 213 124 637 minecraft:yellow_concrete
fill 214 123 612 214 124 612 minecraft:yellow_concrete
fill 214 123 636 214 124 636 minecraft:yellow_concrete
fill 215 123 623 223 123 623 minecraft:yellow_concrete
fill 217 123 617 220 124 617 minecraft:yellow_concrete
fill 217 123 631 220 124 631 minecraft:yellow_concrete
fill 218 123 618 218 123 620 minecraft:yellow_concrete
fill 218 123 622 219 124 622 minecraft:yellow_concrete
fill 218 123 624 219 123 626 minecraft:yellow_concrete
fill 219 123 616 221 124 616 minecraft:yellow_concrete
fill 219 123 618 219 124 619 minecraft:yellow_concrete
fill 219 123 629 219 124 630 minecraft:yellow_concrete
fill 219 123 632 221 124 632 minecraft:yellow_concrete
fill 220 123 618 220 124 618 minecraft:yellow_concrete
fill 220 123 624 223 123 625 minecraft:yellow_concrete
fill 220 123 630 220 124 630 minecraft:yellow_concrete
fill 224 123 624 225 124 624 minecraft:yellow_concrete
fill 189 124 605 198 124 645 minecraft:black_concrete
fill 199 124 605 199 124 619 minecraft:black_concrete
fill 199 124 620 204 124 620 minecraft:yellow_concrete
fill 199 124 621 199 124 627 minecraft:black_concrete
fill 199 124 628 206 124 628 minecraft:yellow_concrete
fill 199 124 629 199 124 645 minecraft:black_concrete
fill 200 124 605 203 124 618 minecraft:black_concrete
fill 200 124 621 202 124 621 minecraft:yellow_concrete
fill 200 124 622 200 124 626 minecraft:black_concrete
fill 200 124 627 202 124 627 minecraft:yellow_concrete
fill 200 124 630 203 124 645 minecraft:black_concrete
fill 201 124 622 203 124 622 minecraft:yellow_concrete
fill 201 124 623 202 124 625 minecraft:black_concrete
fill 201 124 626 203 124 626 minecraft:yellow_concrete
fill 203 124 619 204 124 619 minecraft:black_concrete
fill 203 124 621 204 124 621 minecraft:black_concrete
fill 203 124 623 204 124 623 minecraft:yellow_concrete
fill 203 124 624 204 124 624 minecraft:black_concrete
fill 203 124 625 204 124 625 minecraft:yellow_concrete
fill 203 124 627 208 124 627 minecraft:black_concrete
fill 203 124 629 205 124 629 minecraft:black_concrete
fill 204 124 605 212 124 611 minecraft:black_concrete
fill 204 124 614 204 124 618 minecraft:black_concrete
setblock 204 124 622 minecraft:black_concrete
fill 204 124 626 207 124 626 minecraft:black_concrete
fill 204 124 630 204 124 634 minecraft:black_concrete
fill 204 124 637 212 124 645 minecraft:black_concrete
fill 205 124 612 212 124 612 minecraft:black_concrete
setblock 205 124 618 minecraft:black_concrete
fill 205 124 619 205 124 623 minecraft:sea_lantern
fill 205 124 624 206 124 624 minecraft:yellow_concrete
fill 205 124 625 207 124 625 minecraft:black_concrete
setblock 205 124 630 minecraft:black_concrete
fill 205 124 636 212 124 636 minecraft:black_concrete
fill 206 124 613 211 124 613 minecraft:black_concrete
fill 206 124 614 206 124 618 minecraft:yellow_concrete
fill 206 124 619 209 124 619 minecraft:sea_lantern
fill 206 124 620 208 124 622 minecraft:black_concrete
fill 206 124 623 209 124 623 minecraft:sea_lantern
fill 206 124 629 206 124 634 minecraft:yellow_concrete
fill 206 124 635 211 124 635 minecraft:black_concrete
fill 207 124 614 207 124 616 minecraft:yellow_concrete
fill 207 124 617 208 124 618 minecraft:black_concrete
fill 207 124 624 208 124 624 minecraft:white_concrete
fill 207 124 628 208 124 631 minecraft:black_concrete
fill 207 124 632 207 124 634 minecraft:yellow_concrete
fill 208 124 614 210 124 614 minecraft:black_concrete
fill 208 124 615 208 124 616 minecraft:yellow_concrete
fill 208 124 625 208 124 626 minecraft:white_concrete
fill 208 124 632 208 124 633 minecraft:yellow_concrete
fill 208 124 634 210 124 634 minecraft:black_concrete
fill 209 124 615 210 124 616 minecraft:black_concrete
setblock 209 124 617 minecraft:yellow_concrete
setblock 209 124 618 minecraft:black_concrete
fill 209 124 620 209 124 622 minecraft:sea_lantern
fill 209 124 624 209 124 631 minecraft:sea_lantern
fill 209 124 632 210 124 633 minecraft:black_concrete
fill 210 124 617 213 124 617 minecraft:black_concrete
fill 210 124 618 210 124 619 minecraft:yellow_concrete
setblock 210 124 620 minecraft:black_concrete
fill 210 124 621 213 124 621 minecraft:white_concrete
fill 210 124 622 213 124 622 minecraft:sea_lantern
fill 210 124 626 214 124 627 minecraft:sea_lantern
fill 210 124 628 212 124 630 minecraft:black_concrete
fill 210 124 631 213 124 631 minecraft:sea_lantern
fill 211 124 614 211 124 616 minecraft:yellow_concrete
fill 211 124 618 213 124 619 minecraft:black_concrete
setblock 211 124 620 minecraft:white_concrete
fill 211 124 632 211 124 634 minecraft:yellow_concrete
fill 212 124 614 214 124 615 minecraft:yellow_concrete
fill 212 124 616 213 124 616 minecraft:black_concrete
fill 212 124 620 217 124 620 minecraft:black_concrete
fill 212 124 632 213 124 632 minecraft:black_concrete
fill 212 124 633 214 124 634 minecraft:yellow_concrete
fill 213 124 605 229 124 610 minecraft:black_concrete
fill 213 124 623 214 124 625 minecraft:sea_lantern
fill 213 124 628 213 124 630 minecraft:sea_lantern
fill 213 124 638 229 124 645 minecraft:black_concrete
fill 214 124 611 229 124 611 minecraft:black_concrete
fill 214 124 616 214 124 619 minecraft:yellow_concrete
fill 214 124 621 216 124 621 minecraft:black_concrete
setblock 214 124 622 minecraft:white_concrete
fill 214 124 628 217 124 628 minecraft:black_concrete
fill 214 124 629 214 124 632 minecraft:yellow_concrete
fill 214 124 637 229 124 637 minecraft:black_concrete
fill 215 124 612 216 124 617 minecraft:black_concrete
fill 215 124 618 217 124 618 minecraft:yellow_concrete
fill 215 124 619 217 124 619 minecraft:black_concrete
setblock 215 124 622 minecraft:black_concrete
fill 215 124 623 218 124 623 minecraft:sea_lantern
fill 215 124 624 217 124 626 minecraft:black_concrete
fill 215 124 627 218 124 627 minecraft:sea_lantern
fill 215 124 629 217 124 629 minecraft:black_concrete
fill 215 124 630 217 124 630 minecraft:yellow_concrete
fill 215 124 631 216 124 636 minecraft:black_concrete
fill 216 124 622 217 124 622 minecraft:yellow_concrete
fill 217 124 612 218 124 616 minecraft:black_concrete
setblock 217 124 621 minecraft:yellow_concrete
fill 217 124 632 218 124 636 minecraft:black_concrete
setblock 218 124 618 minecraft:black_concrete
fill 218 124 619 218 124 620 minecraft:yellow_concrete
fill 218 124 621 229 124 621 minecraft:black_concrete
fill 218 124 624 218 124 626 minecraft:sea_lantern
fill 218 124 628 218 124 629 minecraft:yellow_concrete
setblock 218 124 630 minecraft:black_concrete
fill 219 124 612 229 124 615 minecraft:black_concrete
fill 219 124 620 229 124 620 minecraft:black_concrete
fill 219 124 623 223 124 623 minecraft:yellow_concrete
fill 219 124 624 220 124 624 minecraft:black_concrete
fill 219 124 625 219 124 626 minecraft:yellow_concrete
fill 219 124 627 229 124 628 minecraft:black_concrete
fill 219 124 633 229 124 636 minecraft:black_concrete
fill 220 124 619 229 124 619 minecraft:black_concrete
fill 220 124 622 229 124 622 minecraft:black_concrete
fill 220 124 625 223 124 625 minecraft:yellow_concrete
fill 220 124 626 229 124 626 minecraft:black_concrete
fill 220 124 629 229 124 629 minecraft:black_concrete
fill 221 124 617 229 124 618 minecraft:black_concrete
fill 221 124 624 223 124 624 minecraft:yellow_concrete
fill 221 124 630 229 124 631 minecraft:black_concrete
fill 222 124 616 229 124 616 minecraft:black_concrete
fill 222 124 632 229 124 632 minecraft:black_concrete
fill 224 124 623 229 124 623 minecraft:black_concrete
fill 224 124 625 229 124 625 minecraft:black_concrete
fill 226 124 624 229 124 624 minecraft:black_concrete
setblock 191 126 607 minecraft:light[level=14]
setblock 191 126 615 minecraft:light[level=14]
setblock 191 126 623 minecraft:light[level=14]
setblock 191 126 631 minecraft:light[level=14]
setblock 191 126 639 minecraft:light[level=14]
setblock 199 126 607 minecraft:light[level=14]
setblock 199 126 615 minecraft:light[level=14]
setblock 199 126 623 minecraft:light[level=14]
setblock 199 126 631 minecraft:light[level=14]
setblock 199 126 639 minecraft:light[level=14]
setblock 207 126 607 minecraft:light[level=14]
setblock 207 126 615 minecraft:light[level=14]
setblock 207 126 623 minecraft:light[level=14]
setblock 207 126 631 minecraft:light[level=14]
setblock 207 126 639 minecraft:light[level=14]
setblock 215 126 607 minecraft:light[level=14]
setblock 215 126 615 minecraft:light[level=14]
setblock 215 126 623 minecraft:light[level=14]
setblock 215 126 631 minecraft:light[level=14]
setblock 215 126 639 minecraft:light[level=14]
setblock 223 126 607 minecraft:light[level=14]
setblock 223 126 615 minecraft:light[level=14]
setblock 223 126 623 minecraft:light[level=14]
setblock 223 126 631 minecraft:light[level=14]
setblock 223 126 639 minecraft:light[level=14]
fill 189 128 611 189 178 612 minecraft:black_concrete
fill 189 128 619 189 178 620 minecraft:black_concrete
fill 189 128 627 189 178 628 minecraft:black_concrete
fill 189 128 635 189 178 636 minecraft:black_concrete
fill 189 128 643 189 178 644 minecraft:black_concrete
fill 190 128 605 191 178 605 minecraft:black_concrete
fill 195 128 645 196 178 645 minecraft:black_concrete
fill 198 128 605 199 178 605 minecraft:black_concrete
fill 203 128 645 204 178 645 minecraft:black_concrete
fill 206 128 605 207 178 605 minecraft:black_concrete
fill 211 128 645 212 178 645 minecraft:black_concrete
fill 214 128 605 215 159 605 minecraft:black_concrete
fill 219 128 645 220 178 645 minecraft:black_concrete
fill 222 128 605 223 178 605 minecraft:black_concrete
fill 227 128 645 228 178 645 minecraft:black_concrete
fill 229 128 606 229 178 607 minecraft:black_concrete
fill 229 128 614 229 178 615 minecraft:black_concrete
fill 229 128 622 229 178 623 minecraft:black_concrete
fill 229 128 630 229 178 631 minecraft:black_concrete
fill 229 128 638 229 178 639 minecraft:black_concrete
fill 203 129 633 203 130 634 minecraft:cyan_concrete
fill 211 129 616 211 130 617 minecraft:lime_concrete
fill 188 130 609 188 135 609 minecraft:sea_lantern
fill 188 130 617 188 135 617 minecraft:sea_lantern
fill 188 130 625 188 135 625 minecraft:sea_lantern
fill 188 130 633 188 135 633 minecraft:sea_lantern
fill 188 130 641 188 135 641 minecraft:sea_lantern
fill 191 130 646 191 135 646 minecraft:sea_lantern
fill 195 130 604 195 135 604 minecraft:sea_lantern
fill 199 130 646 199 135 646 minecraft:sea_lantern
fill 203 130 604 203 135 604 minecraft:sea_lantern
fill 207 130 646 207 135 646 minecraft:sea_lantern
fill 211 130 604 211 135 604 minecraft:sea_lantern
fill 215 130 646 215 135 646 minecraft:sea_lantern
fill 219 130 604 219 135 604 minecraft:sea_lantern
fill 223 130 646 223 135 646 minecraft:sea_lantern
fill 227 130 604 227 135 604 minecraft:sea_lantern
fill 230 130 609 230 135 609 minecraft:sea_lantern
fill 230 130 617 230 135 617 minecraft:sea_lantern
fill 230 130 625 230 135 625 minecraft:sea_lantern
fill 230 130 633 230 135 633 minecraft:sea_lantern
fill 230 130 641 230 135 641 minecraft:sea_lantern
fill 210 131 615 210 132 615 minecraft:magenta_concrete
fill 218 132 613 218 133 613 minecraft:white_stained_glass
setblock 191 134 607 minecraft:light[level=14]
setblock 191 134 615 minecraft:light[level=14]
setblock 191 134 623 minecraft:light[level=14]
setblock 191 134 631 minecraft:light[level=14]
setblock 191 134 639 minecraft:light[level=14]
fill 198 134 628 198 135 628 minecraft:lime_concrete
setblock 199 134 607 minecraft:light[level=14]
setblock 199 134 615 minecraft:light[level=14]
setblock 199 134 623 minecraft:light[level=14]
setblock 199 134 631 minecraft:light[level=14]
setblock 199 134 639 minecraft:light[level=14]
setblock 207 134 607 minecraft:light[level=14]
setblock 207 134 615 minecraft:light[level=14]
setblock 207 134 623 minecraft:light[level=14]
setblock 207 134 631 minecraft:light[level=14]
setblock 207 134 639 minecraft:light[level=14]
setblock 215 134 607 minecraft:light[level=14]
setblock 215 134 615 minecraft:light[level=14]
setblock 215 134 623 minecraft:light[level=14]
setblock 215 134 631 minecraft:light[level=14]
setblock 215 134 639 minecraft:light[level=14]
fill 218 134 613 218 142 613 minecraft:black_concrete
setblock 223 134 607 minecraft:light[level=14]
setblock 223 134 615 minecraft:light[level=14]
setblock 223 134 623 minecraft:light[level=14]
setblock 223 134 631 minecraft:light[level=14]
setblock 223 134 639 minecraft:light[level=14]
fill 217 135 613 217 142 613 minecraft:black_concrete
fill 188 136 609 188 143 609 minecraft:cyan_concrete
fill 188 136 617 188 143 617 minecraft:cyan_concrete
fill 188 136 625 188 143 625 minecraft:cyan_concrete
fill 188 136 633 188 143 633 minecraft:cyan_concrete
fill 188 136 641 188 143 641 minecraft:cyan_concrete
fill 191 136 646 191 143 646 minecraft:cyan_concrete
fill 195 136 604 195 143 604 minecraft:cyan_concrete
fill 199 136 646 199 143 646 minecraft:cyan_concrete
fill 203 136 604 203 143 604 minecraft:cyan_concrete
fill 207 136 646 207 143 646 minecraft:cyan_concrete
fill 211 136 604 211 143 604 minecraft:cyan_concrete
fill 215 136 646 215 143 646 minecraft:cyan_concrete
fill 217 136 612 218 142 612 minecraft:black_concrete
fill 219 136 604 219 143 604 minecraft:cyan_concrete
fill 223 136 646 223 143 646 minecraft:cyan_concrete
fill 227 136 604 227 143 604 minecraft:cyan_concrete
fill 230 136 609 230 143 609 minecraft:cyan_concrete
fill 230 136 617 230 143 617 minecraft:cyan_concrete
fill 230 136 625 230 143 625 minecraft:cyan_concrete
fill 230 136 633 230 143 633 minecraft:cyan_concrete
fill 230 136 641 230 143 641 minecraft:cyan_concrete
fill 216 137 613 216 142 613 minecraft:black_concrete
fill 217 137 614 218 142 614 minecraft:black_concrete
fill 219 137 612 219 142 613 minecraft:black_concrete
fill 192 138 622 192 139 622 minecraft:lime_concrete
fill 216 138 612 216 142 612 minecraft:black_concrete
fill 216 138 614 216 142 614 minecraft:black_concrete
fill 217 138 611 218 142 611 minecraft:black_concrete
fill 218 138 626 219 139 627 minecraft:yellow_concrete
fill 219 138 614 219 142 614 minecraft:black_concrete
fill 215 139 613 215 142 613 minecraft:black_concrete
fill 216 139 611 216 142 611 minecraft:black_concrete
fill 217 139 615 219 142 615 minecraft:black_concrete
fill 219 139 611 219 142 611 minecraft:black_concrete
fill 220 139 612 220 142 613 minecraft:black_concrete
fill 189 140 605 189 141 610 minecraft:black_concrete
fill 189 140 613 190 140 618 minecraft:black_concrete
fill 189 140 621 190 140 626 minecraft:black_concrete
fill 189 140 629 190 140 634 minecraft:black_concrete
fill 189 140 637 190 140 642 minecraft:black_concrete
fill 189 140 645 194 141 645 minecraft:black_concrete
fill 190 140 606 190 140 612 minecraft:black_concrete
fill 190 140 619 190 140 620 minecraft:black_concrete
fill 190 140 627 190 140 628 minecraft:black_concrete
fill 190 140 635 190 140 636 minecraft:black_concrete
fill 190 140 643 190 140 644 minecraft:black_concrete
fill 191 140 606 228 140 606 minecraft:black_concrete
fill 191 140 644 229 140 644 minecraft:black_concrete
fill 192 140 605 197 141 605 minecraft:black_concrete
fill 197 140 645 202 141 645 minecraft:black_concrete
fill 200 140 605 205 141 605 minecraft:black_concrete
fill 205 140 645 210 141 645 minecraft:black_concrete
fill 208 140 605 213 141 605 minecraft:black_concrete
fill 213 140 634 213 141 634 minecraft:lime_concrete
fill 213 140 645 218 141 645 minecraft:black_concrete
fill 215 140 611 215 142 612 minecraft:black_concrete
fill 215 140 614 215 142 614 minecraft:black_concrete
fill 216 140 605 221 141 605 minecraft:black_concrete
fill 216 140 615 216 142 615 minecraft:black_concrete
fill 217 140 610 219 142 610 minecraft:black_concrete
fill 220 140 611 220 142 611 minecraft:black_concrete
fill 220 140 614 220 142 614 minecraft:black_concrete
fill 221 140 645 226 141 645 minecraft:black_concrete
fill 224 140 605 229 141 605 minecraft:black_concrete
fill 228 140 607 228 140 643 minecraft:black_concrete
fill 229 140 608 229 141 613 minecraft:black_concrete
fill 229 140 616 229 141 621 minecraft:black_concrete
fill 229 140 624 229 141 629 minecraft:black_concrete
fill 229 140 632 229 141 637 minecraft:black_concrete
fill 229 140 640 229 141 643 minecraft:black_concrete
fill 229 140 645 229 141 645 minecraft:black_concrete
fill 189 141 613 189 141 618 minecraft:black_concrete
fill 189 141 621 189 141 626 minecraft:black_concrete
fill 189 141 629 189 141 634 minecraft:black_concrete
fill 189 141 637 189 141 642 minecraft:black_concrete
fill 214 141 613 214 142 613 minecraft:black_concrete
fill 215 141 615 215 142 615 minecraft:black_concrete
fill 216 141 610 216 142 610 minecraft:black_concrete
fill 216 141 616 219 142 616 minecraft:black_concrete
fill 220 141 615 220 142 615 minecraft:black_concrete
fill 221 141 612 221 142 614 minecraft:black_concrete
setblock 229 141 644 minecraft:black_concrete
setblock 191 142 607 minecraft:light[level=14]
setblock 191 142 615 minecraft:light[level=14]
setblock 191 142 623 minecraft:light[level=14]
setblock 191 142 631 minecraft:light[level=14]
setblock 191 142 639 minecraft:light[level=14]
setblock 199 142 607 minecraft:light[level=14]
setblock 199 142 615 minecraft:light[level=14]
setblock 199 142 623 minecraft:light[level=14]
setblock 199 142 631 minecraft:light[level=14]
setblock 199 142 639 minecraft:light[level=14]
setblock 207 142 607 minecraft:light[level=14]
setblock 207 142 615 minecraft:light[level=14]
setblock 207 142 623 minecraft:light[level=14]
setblock 207 142 631 minecraft:light[level=14]
setblock 207 142 639 minecraft:light[level=14]
fill 214 142 611 214 142 612 minecraft:black_concrete
setblock 214 142 614 minecraft:black_concrete
setblock 215 142 607 minecraft:light[level=14]
setblock 215 142 610 minecraft:black_concrete
setblock 215 142 623 minecraft:light[level=14]
setblock 215 142 631 minecraft:light[level=14]
setblock 215 142 639 minecraft:light[level=14]
fill 216 142 609 219 142 609 minecraft:black_concrete
setblock 220 142 610 minecraft:black_concrete
setblock 220 142 616 minecraft:black_concrete
setblock 221 142 611 minecraft:black_concrete
setblock 221 142 615 minecraft:black_concrete
setblock 223 142 607 minecraft:light[level=14]
setblock 223 142 615 minecraft:light[level=14]
setblock 223 142 623 minecraft:light[level=14]
setblock 223 142 631 minecraft:light[level=14]
setblock 223 142 639 minecraft:light[level=14]
fill 217 143 612 218 144 613 minecraft:white_stained_glass
setblock 218 143 614 minecraft:white_stained_glass
fill 188 144 609 188 149 609 minecraft:sea_lantern
fill 188 144 617 188 149 617 minecraft:sea_lantern
fill 188 144 625 188 149 625 minecraft:sea_lantern
fill 188 144 633 188 149 633 minecraft:sea_lantern
fill 188 144 641 188 149 641 minecraft:sea_lantern
fill 191 144 646 191 149 646 minecraft:sea_lantern
fill 195 144 604 195 149 604 minecraft:sea_lantern
fill 196 144 614 197 145 615 minecraft:yellow_concrete
fill 199 144 646 199 149 646 minecraft:sea_lantern
fill 203 144 604 203 149 604 minecraft:sea_lantern
fill 207 144 646 207 149 646 minecraft:sea_lantern
fill 211 144 604 211 149 604 minecraft:sea_lantern
fill 215 144 646 215 149 646 minecraft:sea_lantern
fill 219 144 604 219 149 604 minecraft:sea_lantern
fill 223 144 646 223 149 646 minecraft:sea_lantern
fill 227 144 604 227 149 604 minecraft:sea_lantern
fill 230 144 609 230 149 609 minecraft:sea_lantern
fill 230 144 617 230 149 617 minecraft:sea_lantern
fill 230 144 625 230 149 625 minecraft:sea_lantern
fill 230 144 633 230 149 633 minecraft:sea_lantern
fill 230 144 641 230 149 641 minecraft:sea_lantern
fill 217 145 613 218 145 613 minecraft:white_stained_glass
setblock 218 146 613 minecraft:white_stained_glass
fill 203 149 618 205 150 618 minecraft:yellow_concrete
fill 204 149 617 204 150 617 minecraft:yellow_concrete
fill 204 149 619 204 150 619 minecraft:yellow_concrete
fill 188 150 609 188 157 609 minecraft:cyan_concrete
fill 188 150 617 188 157 617 minecraft:cyan_concrete
fill 188 150 625 188 157 625 minecraft:cyan_concrete
fill 188 150 633 188 157 633 minecraft:cyan_concrete
fill 188 150 641 188 157 641 minecraft:cyan_concrete
setblock 191 150 607 minecraft:light[level=14]
setblock 191 150 615 minecraft:light[level=14]
setblock 191 150 623 minecraft:light[level=14]
setblock 191 150 631 minecraft:light[level=14]
setblock 191 150 639 minecraft:light[level=14]
fill 191 150 646 191 157 646 minecraft:cyan_concrete
fill 195 150 604 195 157 604 minecraft:cyan_concrete
setblock 199 150 607 minecraft:light[level=14]
setblock 199 150 615 minecraft:light[level=14]
setblock 199 150 623 minecraft:light[level=14]
setblock 199 150 631 minecraft:light[level=14]
setblock 199 150 639 minecraft:light[level=14]
fill 199 150 646 199 157 646 minecraft:cyan_concrete
fill 203 150 604 203 157 604 minecraft:cyan_concrete
setblock 207 150 607 minecraft:light[level=14]
setblock 207 150 615 minecraft:light[level=14]
setblock 207 150 623 minecraft:light[level=14]
setblock 207 150 631 minecraft:light[level=14]
setblock 207 150 639 minecraft:light[level=14]
fill 207 150 646 207 157 646 minecraft:cyan_concrete
fill 211 150 604 211 157 604 minecraft:cyan_concrete
fill 213 150 612 214 151 613 minecraft:cyan_concrete
setblock 215 150 607 minecraft:light[level=14]
setblock 215 150 615 minecraft:light[level=14]
setblock 215 150 623 minecraft:light[level=14]
setblock 215 150 631 minecraft:light[level=14]
setblock 215 150 639 minecraft:light[level=14]
fill 215 150 646 215 157 646 minecraft:cyan_concrete
fill 219 150 604 219 157 604 minecraft:cyan_concrete
setblock 223 150 607 minecraft:light[level=14]
setblock 223 150 615 minecraft:light[level=14]
setblock 223 150 623 minecraft:light[level=14]
setblock 223 150 631 minecraft:light[level=14]
setblock 223 150 639 minecraft:light[level=14]
fill 223 150 646 223 157 646 minecraft:cyan_concrete
fill 227 150 604 227 157 604 minecraft:cyan_concrete
fill 230 150 609 230 157 609 minecraft:cyan_concrete
fill 230 150 617 230 157 617 minecraft:cyan_concrete
fill 230 150 625 230 157 625 minecraft:cyan_concrete
fill 230 150 633 230 157 633 minecraft:cyan_concrete
fill 230 150 641 230 157 641 minecraft:cyan_concrete
fill 216 152 607 216 157 607 minecraft:white_concrete
fill 189 154 605 189 155 610 minecraft:black_concrete
fill 189 154 613 190 154 618 minecraft:black_concrete
fill 189 154 621 190 154 626 minecraft:black_concrete
fill 189 154 629 190 154 634 minecraft:black_concrete
fill 189 154 637 190 154 642 minecraft:black_concrete
fill 189 154 645 194 155 645 minecraft:black_concrete
fill 190 154 606 190 154 612 minecraft:black_concrete
fill 190 154 619 190 154 620 minecraft:black_concrete
fill 190 154 627 190 154 628 minecraft:black_concrete
fill 190 154 635 190 154 636 minecraft:black_concrete
fill 190 154 643 190 154 644 minecraft:black_concrete
fill 191 154 606 228 154 606 minecraft:black_concrete
fill 191 154 644 229 154 644 minecraft:black_concrete
fill 192 154 605 197 155 605 minecraft:black_concrete
fill 197 154 645 202 155 645 minecraft:black_concrete
fill 200 154 605 205 155 605 minecraft:black_concrete
fill 205 154 645 210 155 645 minecraft:black_concrete
fill 208 154 605 213 155 605 minecraft:black_concrete
fill 213 154 645 218 155 645 minecraft:black_concrete
fill 216 154 605 221 155 605 minecraft:black_concrete
fill 221 154 645 226 155 645 minecraft:black_concrete
fill 224 154 605 229 155 605 minecraft:black_concrete
fill 228 154 607 228 154 643 minecraft:black_concrete
fill 229 154 608 229 155 613 minecraft:black_concrete
fill 229 154 616 229 155 621 minecraft:black_concrete
fill 229 154 624 229 155 629 minecraft:black_concrete
fill 229 154 632 229 155 637 minecraft:black_concrete
fill 229 154 640 229 155 643 minecraft:black_concrete
fill 229 154 645 229 155 645 minecraft:black_concrete
fill 189 155 613 189 155 618 minecraft:black_concrete
fill 189 155 621 189 155 626 minecraft:black_concrete
fill 189 155 629 189 155 634 minecraft:black_concrete
fill 189 155 637 189 155 642 minecraft:black_concrete
fill 215 155 606 215 157 607 minecraft:white_concrete
fill 216 155 606 217 157 606 minecraft:white_concrete
fill 216 155 608 216 157 608 minecraft:white_concrete
fill 217 155 607 217 157 607 minecraft:white_concrete
setblock 229 155 644 minecraft:black_concrete
setblock 215 157 608 minecraft:white_concrete
setblock 216 157 605 minecraft:white_concrete
setblock 217 157 608 minecraft:white_concrete
fill 188 158 609 188 163 609 minecraft:sea_lantern
fill 188 158 617 188 163 617 minecraft:sea_lantern
fill 188 158 625 188 163 625 minecraft:sea_lantern
fill 188 158 633 188 163 633 minecraft:sea_lantern
fill 188 158 641 188 163 641 minecraft:sea_lantern
setblock 191 158 607 minecraft:light[level=14]
setblock 191 158 615 minecraft:light[level=14]
setblock 191 158 623 minecraft:light[level=14]
setblock 191 158 631 minecraft:light[level=14]
setblock 191 158 639 minecraft:light[level=14]
fill 191 158 646 191 163 646 minecraft:sea_lantern
fill 195 158 604 195 163 604 minecraft:sea_lantern
setblock 199 158 607 minecraft:light[level=14]
setblock 199 158 615 minecraft:light[level=14]
setblock 199 158 623 minecraft:light[level=14]
setblock 199 158 631 minecraft:light[level=14]
setblock 199 158 639 minecraft:light[level=14]
fill 199 158 646 199 163 646 minecraft:sea_lantern
fill 203 158 604 203 163 604 minecraft:sea_lantern
setblock 207 158 607 minecraft:light[level=14]
setblock 207 158 615 minecraft:light[level=14]
setblock 207 158 623 minecraft:light[level=14]
setblock 207 158 631 minecraft:light[level=14]
setblock 207 158 639 minecraft:light[level=14]
fill 207 158 646 207 163 646 minecraft:sea_lantern
fill 211 158 604 211 163 604 minecraft:sea_lantern
fill 212 158 605 213 159 609 minecraft:black_concrete
fill 214 158 606 220 159 609 minecraft:black_concrete
setblock 215 158 615 minecraft:light[level=14]
setblock 215 158 623 minecraft:light[level=14]
setblock 215 158 631 minecraft:light[level=14]
setblock 215 158 639 minecraft:light[level=14]
fill 215 158 646 215 163 646 minecraft:sea_lantern
fill 216 158 605 220 159 605 minecraft:black_concrete
fill 219 158 604 219 163 604 minecraft:sea_lantern
setblock 223 158 607 minecraft:light[level=14]
setblock 223 158 615 minecraft:light[level=14]
setblock 223 158 623 minecraft:light[level=14]
setblock 223 158 631 minecraft:light[level=14]
setblock 223 158 639 minecraft:light[level=14]
fill 223 158 646 223 163 646 minecraft:sea_lantern
fill 227 158 604 227 163 604 minecraft:sea_lantern
fill 230 158 609 230 163 609 minecraft:sea_lantern
fill 230 158 617 230 163 617 minecraft:sea_lantern
fill 230 158 625 230 163 625 minecraft:sea_lantern
fill 230 158 633 230 163 633 minecraft:sea_lantern
fill 230 158 641 230 163 641 minecraft:sea_lantern
fill 212 160 605 212 178 605 minecraft:black_concrete
setblock 212 160 606 minecraft:sea_lantern
fill 212 160 607 212 178 607 minecraft:black_concrete
setblock 212 160 608 minecraft:sea_lantern
fill 212 160 609 212 178 609 minecraft:black_concrete
setblock 213 160 605 minecraft:sea_lantern
fill 213 160 606 213 178 606 minecraft:black_concrete
setblock 213 160 607 minecraft:sea_lantern
fill 213 160 608 213 178 608 minecraft:black_concrete
setblock 213 160 609 minecraft:sea_lantern
fill 214 160 605 214 178 605 minecraft:black_concrete
setblock 214 160 606 minecraft:sea_lantern
fill 214 160 607 214 178 607 minecraft:black_concrete
setblock 214 160 608 minecraft:sea_lantern
fill 214 160 609 214 178 609 minecraft:black_concrete
setblock 215 160 605 minecraft:sea_lantern
fill 215 160 606 215 178 606 minecraft:black_concrete
setblock 215 160 607 minecraft:sea_lantern
fill 215 160 608 215 178 608 minecraft:black_concrete
setblock 215 160 609 minecraft:sea_lantern
fill 216 160 605 216 178 605 minecraft:black_concrete
setblock 216 160 606 minecraft:sea_lantern
fill 216 160 607 216 178 607 minecraft:black_concrete
setblock 216 160 608 minecraft:sea_lantern
fill 216 160 609 216 178 609 minecraft:black_concrete
setblock 217 160 605 minecraft:sea_lantern
fill 217 160 606 217 178 606 minecraft:black_concrete
setblock 217 160 607 minecraft:sea_lantern
fill 217 160 608 217 178 608 minecraft:black_concrete
setblock 217 160 609 minecraft:sea_lantern
fill 218 160 605 218 178 605 minecraft:black_concrete
setblock 218 160 606 minecraft:sea_lantern
fill 218 160 607 218 178 607 minecraft:black_concrete
setblock 218 160 608 minecraft:sea_lantern
fill 218 160 609 218 178 609 minecraft:black_concrete
setblock 219 160 605 minecraft:sea_lantern
fill 219 160 606 219 178 606 minecraft:black_concrete
setblock 219 160 607 minecraft:sea_lantern
fill 219 160 608 219 178 608 minecraft:black_concrete
setblock 219 160 609 minecraft:sea_lantern
fill 220 160 605 220 178 605 minecraft:black_concrete
setblock 220 160 606 minecraft:sea_lantern
fill 220 160 607 220 178 607 minecraft:black_concrete
setblock 220 160 608 minecraft:sea_lantern
fill 220 160 609 220 178 609 minecraft:black_concrete
fill 212 161 606 212 162 606 minecraft:black_concrete
fill 212 161 608 212 162 608 minecraft:black_concrete
fill 213 161 605 213 162 605 minecraft:black_concrete
fill 213 161 607 213 162 607 minecraft:black_concrete
fill 213 161 609 213 162 609 minecraft:black_concrete
fill 214 161 606 214 162 606 minecraft:black_concrete
fill 214 161 608 214 162 608 minecraft:black_concrete
fill 215 161 605 215 162 605 minecraft:black_concrete
fill 215 161 607 215 162 607 minecraft:black_concrete
fill 215 161 609 215 162 609 minecraft:black_concrete
fill 216 161 606 216 162 606 minecraft:black_concrete
fill 216 161 608 216 162 608 minecraft:black_concrete
fill 217 161 605 217 162 605 minecraft:black_concrete
fill 217 161 607 217 162 607 minecraft:black_concrete
fill 217 161 609 217 162 609 minecraft:black_concrete
fill 218 161 606 218 162 606 minecraft:black_concrete
fill 218 161 608 218 162 608 minecraft:black_concrete
fill 219 161 605 219 162 605 minecraft:black_concrete
fill 219 161 607 219 162 607 minecraft:black_concrete
fill 219 161 609 219 162 609 minecraft:black_concrete
fill 220 161 606 220 162 606 minecraft:black_concrete
fill 220 161 608 220 162 608 minecraft:black_concrete
fill 203 163 643 204 164 643 minecraft:yellow_concrete
setblock 212 163 606 minecraft:sea_lantern
setblock 212 163 608 minecraft:sea_lantern
setblock 213 163 605 minecraft:sea_lantern
setblock 213 163 607 minecraft:sea_lantern
setblock 213 163 609 minecraft:sea_lantern
setblock 214 163 606 minecraft:sea_lantern
setblock 214 163 608 minecraft:sea_lantern
setblock 215 163 605 minecraft:sea_lantern
setblock 215 163 607 minecraft:sea_lantern
setblock 215 163 609 minecraft:sea_lantern
setblock 216 163 606 minecraft:sea_lantern
setblock 216 163 608 minecraft:sea_lantern
setblock 217 163 605 minecraft:sea_lantern
setblock 217 163 607 minecraft:sea_lantern
setblock 217 163 609 minecraft:sea_lantern
setblock 218 163 606 minecraft:sea_lantern
setblock 218 163 608 minecraft:sea_lantern
setblock 219 163 605 minecraft:sea_lantern
setblock 219 163 607 minecraft:sea_lantern
setblock 219 163 609 minecraft:sea_lantern
setblock 220 163 606 minecraft:sea_lantern
setblock 220 163 608 minecraft:sea_lantern
fill 222 163 630 222 164 630 minecraft:white_stained_glass
fill 188 164 609 188 167 609 minecraft:cyan_concrete
fill 188 164 617 188 167 617 minecraft:cyan_concrete
setblock 188 164 624 minecraft:magenta_concrete
fill 188 164 625 188 167 625 minecraft:cyan_concrete
setblock 188 164 626 minecraft:magenta_concrete
fill 188 164 627 188 165 627 minecraft:cyan_concrete
setblock 188 164 628 minecraft:magenta_concrete
fill 188 164 633 188 167 633 minecraft:cyan_concrete
fill 188 164 641 188 167 641 minecraft:cyan_concrete
fill 188 164 644 188 164 645 minecraft:magenta_concrete
fill 188 164 646 188 168 646 minecraft:cyan_concrete
setblock 189 164 646 minecraft:magenta_concrete
fill 191 164 646 191 168 646 minecraft:cyan_concrete
setblock 192 164 646 minecraft:magenta_concrete
setblock 195 164 604 minecraft:cyan_concrete
fill 196 164 646 196 167 646 minecraft:cyan_concrete
setblock 197 164 646 minecraft:magenta_concrete
fill 198 164 646 199 167 646 minecraft:cyan_concrete
fill 203 164 604 203 169 604 minecraft:cyan_concrete
setblock 205 164 604 minecraft:magenta_concrete
fill 207 164 646 207 165 646 minecraft:cyan_concrete
fill 211 164 604 211 165 604 minecraft:magenta_concrete
fill 212 164 606 212 165 606 minecraft:black_concrete
fill 212 164 608 212 165 608 minecraft:black_concrete
fill 213 164 605 213 165 605 minecraft:black_concrete
fill 213 164 607 213 165 607 minecraft:black_concrete
fill 213 164 609 213 165 609 minecraft:black_concrete
setblock 214 164 604 minecraft:magenta_concrete
fill 214 164 606 214 165 606 minecraft:black_concrete
fill 214 164 608 214 165 608 minecraft:black_concrete
fill 215 164 604 218 167 604 minecraft:cyan_concrete
fill 215 164 605 215 165 605 minecraft:black_concrete
fill 215 164 607 215 165 607 minecraft:black_concrete
fill 215 164 609 215 165 609 minecraft:black_concrete
fill 215 164 646 215 167 646 minecraft:cyan_concrete
fill 216 164 606 216 165 606 minecraft:black_concrete
fill 216 164 608 216 165 608 minecraft:black_concrete
fill 217 164 605 217 165 605 minecraft:black_concrete
fill 217 164 607 217 165 607 minecraft:black_concrete
fill 217 164 609 217 165 609 minecraft:black_concrete
fill 218 164 606 218 165 606 minecraft:black_concrete
fill 218 164 608 218 165 608 minecraft:black_concrete
setblock 219 164 604 minecraft:magenta_concrete
fill 219 164 605 219 165 605 minecraft:black_concrete
fill 219 164 607 219 165 607 minecraft:black_concrete
fill 219 164 609 219 165 609 minecraft:black_concrete
fill 220 164 606 220 165 606 minecraft:black_concrete
fill 220 164 608 220 165 608 minecraft:black_concrete
fill 220 164 627 221 165 628 minecraft:cyan_concrete
fill 223 164 646 223 167 646 minecraft:cyan_concrete
fill 227 164 604 227 168 604 minecraft:cyan_concrete
setblock 230 164 609 minecraft:cyan_concrete
setblock 230 164 615 minecraft:magenta_concrete
fill 230 164 616 230 167 617 minecraft:cyan_concrete
fill 230 164 625 230 167 625 minecraft:cyan_concrete
setblock 230 164 632 minecraft:magenta_concrete
fill 230 164 633 230 165 633 minecraft:cyan_concrete
fill 230 164 641 230 167 643 minecraft:cyan_concrete
setblock 230 164 644 minecraft:magenta_concrete
fill 230 164 645 230 167 645 minecraft:cyan_concrete
setblock 188 165 620 minecraft:magenta_concrete
setblock 188 165 624 minecraft:cyan_concrete
fill 188 165 626 188 167 626 minecraft:cyan_concrete
fill 188 165 628 188 167 628 minecraft:cyan_concrete
fill 188 165 635 188 166 635 minecraft:magenta_concrete
fill 188 165 644 188 165 645 minecraft:cyan_concrete
fill 189 165 646 189 170 646 minecraft:cyan_concrete
setblock 191 165 604 minecraft:magenta_concrete
fill 192 165 604 192 167 604 minecraft:cyan_concrete
fill 192 165 646 192 167 646 minecraft:cyan_concrete
setblock 193 165 604 minecraft:magenta_concrete
fill 194 165 604 194 168 604 minecraft:cyan_concrete
setblock 195 165 604 minecraft:magenta_concrete
fill 196 165 604 197 167 604 minecraft:cyan_concrete
fill 197 165 646 197 167 646 minecraft:cyan_concrete
fill 198 165 604 198 166 604 minecraft:magenta_concrete
fill 199 165 604 200 167 604 minecraft:cyan_concrete
setblock 205 165 604 minecraft:cyan_concrete
fill 214 165 604 214 167 604 minecraft:cyan_concrete
fill 216 165 646 216 167 646 minecraft:cyan_concrete
setblock 217 165 646 minecraft:magenta_concrete
fill 218 165 646 218 167 646 minecraft:cyan_concrete
fill 219 165 604 220 167 604 minecraft:cyan_concrete
setblock 221 165 604 minecraft:magenta_concrete
fill 222 165 630 222 172 630 minecraft:black_concrete
fill 223 165 627 224 166 628 minecraft:lime_concrete
setblock 230 165 609 minecraft:magenta_concrete
fill 230 165 610 230 167 610 minecraft:cyan_concrete
setblock 230 165 611 minecraft:magenta_concrete
fill 230 165 615 230 167 615 minecraft:cyan_concrete
fill 230 165 632 230 167 632 minecraft:cyan_concrete
fill 230 165 634 230 165 635 minecraft:magenta_concrete
fill 230 165 636 230 167 638 minecraft:cyan_concrete
fill 230 165 644 230 167 644 minecraft:cyan_concrete
setblock 188 166 605 minecraft:magenta_concrete
fill 188 166 618 188 167 618 minecraft:cyan_concrete
setblock 188 166 619 minecraft:magenta_concrete
fill 188 166 620 188 167 620 minecraft:cyan_concrete
setblock 188 166 622 minecraft:magenta_concrete
fill 188 166 623 188 167 623 minecraft:cyan_concrete
setblock 188 166 624 minecraft:magenta_concrete
setblock 188 166 627 minecraft:magenta_concrete
fill 188 166 636 188 167 636 minecraft:cyan_concrete
setblock 188 166 637 minecraft:magenta_concrete
fill 188 166 638 188 167 638 minecraft:cyan_concrete
fill 188 166 644 188 167 644 minecraft:cyan_concrete
setblock 188 166 645 minecraft:magenta_concrete
setblock 189 166 604 minecraft:magenta_concrete
fill 190 166 604 191 167 604 minecraft:cyan_concrete
setblock 191 166 607 minecraft:light[level=14]
setblock 191 166 615 minecraft:light[level=14]
setblock 191 166 623 minecraft:light[level=14]
setblock 191 166 631 minecraft:light[level=14]
setblock 191 166 639 minecraft:light[level=14]
fill 193 166 604 193 168 604 minecraft:cyan_concrete
fill 195 166 604 195 167 604 minecraft:cyan_concrete
setblock 199 166 607 minecraft:light[level=14]
setblock 199 166 615 minecraft:light[level=14]
setblock 199 166 623 minecraft:light[level=14]
setblock 199 166 631 minecraft:light[level=14]
setblock 199 166 639 minecraft:light[level=14]
fill 201 166 604 202 166 604 minecraft:magenta_concrete
setblock 205 166 604 minecraft:magenta_concrete
fill 207 166 604 208 166 604 minecraft:magenta_concrete
setblock 207 166 607 minecraft:light[level=14]
setblock 207 166 615 minecraft:light[level=14]
setblock 207 166 623 minecraft:light[level=14]
setblock 207 166 631 minecraft:light[level=14]
setblock 207 166 639 minecraft:light[level=14]
setblock 207 166 646 minecraft:magenta_concrete
fill 209 166 604 211 167 604 minecraft:cyan_concrete
fill 209 166 646 211 167 646 minecraft:cyan_concrete
setblock 212 166 606 minecraft:sea_lantern
setblock 212 166 608 minecraft:sea_lantern
setblock 212 166 646 minecraft:magenta_concrete
setblock 213 166 605 minecraft:sea_lantern
setblock 213 166 607 minecraft:sea_lantern
setblock 213 166 609 minecraft:sea_lantern
fill 213 166 646 213 168 646 minecraft:cyan_concrete
setblock 214 166 606 minecraft:sea_lantern
setblock 214 166 608 minecraft:sea_lantern
setblock 215 166 605 minecraft:sea_lantern
setblock 215 166 607 minecraft:sea_lantern
setblock 215 166 609 minecraft:sea_lantern
setblock 215 166 615 minecraft:light[level=14]
setblock 215 166 623 minecraft:light[level=14]
setblock 215 166 631 minecraft:light[level=14]
setblock 215 166 639 minecraft:light[level=14]
setblock 216 166 606 minecraft:sea_lantern
setblock 216 166 608 minecraft:sea_lantern
setblock 217 166 605 minecraft:sea_lantern
setblock 217 166 607 minecraft:sea_lantern
setblock 217 166 609 minecraft:sea_lantern
fill 217 166 646 217 167 646 minecraft:cyan_concrete
setblock 218 166 606 minecraft:sea_lantern
setblock 218 166 608 minecraft:sea_lantern
setblock 219 166 605 minecraft:sea_lantern
setblock 219 166 607 minecraft:sea_lantern
setblock 219 166 609 minecraft:sea_lantern
setblock 220 166 606 minecraft:sea_lantern
setblock 220 166 608 minecraft:sea_lantern
fill 221 166 604 221 167 604 minecraft:cyan_concrete
setblock 223 166 607 minecraft:light[level=14]
setblock 223 166 615 minecraft:light[level=14]
setblock 223 166 623 minecraft:light[level=14]
setblock 223 166 631 minecraft:light[level=14]
setblock 223 166 639 minecraft:light[level=14]
setblock 226 166 604 minecraft:magenta_concrete
fill 229 166 604 229 167 604 minecraft:cyan_concrete
setblock 230 166 604 minecraft:magenta_concrete
fill 230 166 609 230 168 609 minecraft:cyan_concrete
fill 230 166 611 230 168 611 minecraft:cyan_concrete
fill 230 166 629 230 167 630 minecraft:cyan_concrete
setblock 230 166 631 minecraft:magenta_concrete
setblock 230 166 633 minecraft:magenta_concrete
fill 230 166 634 230 167 635 minecraft:cyan_concrete
setblock 188 167 605 minecraft:cyan_concrete
setblock 188 167 619 minecraft:cyan_concrete
setblock 188 167 622 minecraft:cyan_concrete
setblock 188 167 624 minecraft:cyan_concrete
setblock 188 167 627 minecraft:cyan_concrete
setblock 188 167 635 minecraft:cyan_concrete
setblock 188 167 637 minecraft:cyan_concrete
setblock 188 167 645 minecraft:cyan_concrete
setblock 189 167 604 minecraft:cyan_concrete
setblock 198 167 604 minecraft:cyan_concrete
fill 201 167 604 202 167 604 minecraft:cyan_concrete
setblock 205 167 604 minecraft:cyan_concrete
fill 207 167 604 208 167 604 minecraft:cyan_concrete
setblock 207 167 646 minecraft:cyan_concrete
fill 212 167 606 212 168 606 minecraft:black_concrete
fill 212 167 608 212 168 608 minecraft:black_concrete
setblock 212 167 646 minecraft:cyan_concrete
fill 213 167 605 213 168 605 minecraft:black_concrete
fill 213 167 607 213 168 607 minecraft:black_concrete
fill 213 167 609 213 168 609 minecraft:black_concrete
fill 214 167 606 214 168 606 minecraft:black_concrete
fill 214 167 608 214 168 608 minecraft:black_concrete
fill 215 167 605 215 168 605 minecraft:black_concrete
fill 215 167 607 215 168 607 minecraft:black_concrete
fill 215 167 609 215 168 609 minecraft:black_concrete
fill 216 167 606 216 168 606 minecraft:black_concrete
fill 216 167 608 216 168 608 minecraft:black_concrete
fill 217 167 605 217 168 605 minecraft:black_concrete
fill 217 167 607 217 168 607 minecraft:black_concrete
fill 217 167 609 217 168 609 minecraft:black_concrete
fill 218 167 606 218 168 606 minecraft:black_concrete
fill 218 167 608 218 168 608 minecraft:black_concrete
fill 219 167 605 219 168 605 minecraft:black_concrete
fill 219 167 607 219 168 607 minecraft:black_concrete
fill 219 167 609 219 168 609 minecraft:black_concrete
fill 220 167 606 220 168 606 minecraft:black_concrete
fill 220 167 608 220 168 608 minecraft:black_concrete
fill 221 167 630 221 172 631 minecraft:black_concrete
fill 222 167 631 222 172 631 minecraft:black_concrete
setblock 226 167 604 minecraft:cyan_concrete
setblock 230 167 604 minecraft:cyan_concrete
setblock 230 167 631 minecraft:cyan_concrete
setblock 230 167 633 minecraft:cyan_concrete
fill 188 168 604 188 168 609 minecraft:magenta_concrete
setblock 188 168 610 minecraft:cyan_concrete
setblock 188 168 611 minecraft:magenta_concrete
setblock 188 168 612 minecraft:cyan_concrete
fill 188 168 613 188 237 613 minecraft:magenta_concrete
setblock 188 168 614 minecraft:cyan_concrete
fill 188 168 615 188 168 645 minecraft:magenta_concrete
fill 189 168 604 192 234 604 minecraft:magenta_concrete
fill 189 168 605 189 169 610 minecraft:black_concrete
fill 189 168 613 190 168 618 minecraft:black_concrete
fill 189 168 621 190 168 626 minecraft:black_concrete
fill 189 168 629 190 168 634 minecraft:black_concrete
fill 189 168 637 190 168 642 minecraft:black_concrete
fill 189 168 645 194 169 645 minecraft:black_concrete
fill 190 168 606 190 168 612 minecraft:black_concrete
fill 190 168 619 190 168 620 minecraft:black_concrete
fill 190 168 627 190 168 628 minecraft:black_concrete
fill 190 168 635 190 168 636 minecraft:black_concrete
fill 190 168 643 190 168 644 minecraft:black_concrete
fill 190 168 646 190 237 646 minecraft:magenta_concrete
fill 191 168 606 211 168 606 minecraft:black_concrete
fill 191 168 644 229 168 644 minecraft:black_concrete
fill 192 168 605 197 169 605 minecraft:black_concrete
fill 192 168 646 212 168 646 minecraft:magenta_concrete
fill 195 168 604 199 171 604 minecraft:magenta_concrete
fill 197 168 626 198 169 626 minecraft:lime_concrete
fill 197 168 645 202 169 645 minecraft:black_concrete
setblock 200 168 604 minecraft:cyan_concrete
fill 200 168 605 205 169 605 minecraft:black_concrete
fill 201 168 604 202 237 604 minecraft:magenta_concrete
fill 204 168 604 205 234 604 minecraft:magenta_concrete
fill 205 168 645 210 169 645 minecraft:black_concrete
fill 207 168 604 214 169 604 minecraft:magenta_concrete
fill 208 168 605 211 169 605 minecraft:black_concrete
fill 213 168 645 218 169 645 minecraft:black_concrete
fill 214 168 646 226 171 646 minecraft:magenta_concrete
setblock 215 168 604 minecraft:cyan_concrete
fill 216 168 604 217 237 604 minecraft:magenta_concrete
setblock 218 168 604 minecraft:cyan_concrete
fill 219 168 604 221 171 604 minecraft:magenta_concrete
fill 221 168 605 221 168 606 minecraft:black_concrete
fill 221 168 645 226 169 645 minecraft:black_concrete
fill 222 168 606 228 168 606 minecraft:black_concrete
fill 222 168 629 222 172 629 minecraft:black_concrete
fill 223 168 604 226 237 604 minecraft:magenta_concrete
fill 223 168 630 223 172 631 minecraft:black_concrete
fill 224 168 605 229 169 605 minecraft:black_concrete
fill 228 168 604 230 235 604 minecraft:magenta_concrete
fill 228 168 607 228 168 643 minecraft:black_concrete
fill 228 168 646 228 237 646 minecraft:magenta_concrete
fill 229 168 608 229 169 613 minecraft:black_concrete
fill 229 168 616 229 169 621 minecraft:black_concrete
fill 229 168 624 229 169 629 minecraft:black_concrete
fill 229 168 632 229 169 637 minecraft:black_concrete
fill 229 168 640 229 169 643 minecraft:black_concrete
fill 229 168 645 229 169 645 minecraft:black_concrete
fill 230 168 605 230 169 608 minecraft:magenta_concrete
fill 230 168 610 230 237 610 minecraft:magenta_concrete
fill 230 168 612 230 168 616 minecraft:magenta_concrete
setblock 230 168 617 minecraft:cyan_concrete
fill 230 168 618 230 168 646 minecraft:magenta_concrete
fill 188 169 604 188 233 607 minecraft:magenta_concrete
setblock 188 169 608 minecraft:cyan_concrete
fill 188 169 609 188 171 610 minecraft:magenta_concrete
setblock 188 169 611 minecraft:cyan_concrete
fill 188 169 612 188 237 612 minecraft:magenta_concrete
fill 188 169 614 188 171 623 minecraft:magenta_concrete
setblock 188 169 624 minecraft:cyan_concrete
fill 188 169 625 188 171 628 minecraft:magenta_concrete
fill 188 169 629 188 170 629 minecraft:cyan_concrete
setblock 188 169 630 minecraft:magenta_concrete
setblock 188 169 631 minecraft:cyan_concrete
fill 188 169 632 188 169 636 minecraft:magenta_concrete
setblock 188 169 637 minecraft:cyan_concrete
fill 188 169 638 188 169 642 minecraft:magenta_concrete
setblock 188 169 643 minecraft:cyan_concrete
fill 188 169 644 188 237 644 minecraft:magenta_concrete
setblock 188 169 645 minecraft:cyan_concrete
fill 188 169 646 188 237 646 minecraft:magenta_concrete
fill 189 169 613 189 169 618 minecraft:black_concrete
fill 189 169 621 189 169 626 minecraft:black_concrete
fill 189 169 629 189 169 634 minecraft:black_concrete
fill 189 169 637 189 169 642 minecraft:black_concrete
fill 191 169 646 198 169 646 minecraft:magenta_concrete
fill 193 169 604 194 233 604 minecraft:magenta_concrete
setblock 199 169 646 minecraft:cyan_concrete
fill 200 169 604 200 234 604 minecraft:magenta_concrete
fill 200 169 646 213 171 646 minecraft:magenta_concrete
fill 206 169 604 206 235 604 minecraft:magenta_concrete
setblock 212 169 606 minecraft:sea_lantern
setblock 212 169 608 minecraft:sea_lantern
setblock 213 169 605 minecraft:sea_lantern
setblock 213 169 607 minecraft:sea_lantern
setblock 213 169 609 minecraft:sea_lantern
setblock 214 169 606 minecraft:sea_lantern
setblock 214 169 608 minecraft:sea_lantern
fill 215 169 604 215 235 604 minecraft:magenta_concrete
setblock 215 169 605 minecraft:sea_lantern
setblock 215 169 607 minecraft:sea_lantern
setblock 215 169 609 minecraft:sea_lantern
setblock 216 169 606 minecraft:sea_lantern
setblock 216 169 608 minecraft:sea_lantern
setblock 217 169 605 minecraft:sea_lantern
setblock 217 169 607 minecraft:sea_lantern
setblock 217 169 609 minecraft:sea_lantern
fill 218 169 604 218 233 604 minecraft:magenta_concrete
setblock 218 169 606 minecraft:sea_lantern
setblock 218 169 608 minecraft:sea_lantern
setblock 219 169 605 minecraft:sea_lantern
setblock 219 169 607 minecraft:sea_lantern
setblock 219 169 609 minecraft:sea_lantern
setblock 220 169 606 minecraft:sea_lantern
setblock 220 169 608 minecraft:sea_lantern
fill 220 169 630 220 172 631 minecraft:black_concrete
setblock 221 169 605 minecraft:black_concrete
fill 221 169 629 221 172 629 minecraft:black_concrete
fill 221 169 632 222 172 632 minecraft:black_concrete
setblock 222 169 604 minecraft:magenta_concrete
fill 223 169 629 223 172 629 minecraft:black_concrete
fill 227 169 604 227 171 604 minecraft:magenta_concrete
setblock 229 169 644 minecraft:black_concrete
fill 229 169 646 230 169 646 minecraft:magenta_concrete
fill 230 169 609 230 171 609 minecraft:magenta_concrete
fill 230 169 611 230 169 612 minecraft:magenta_concrete
fill 230 169 613 230 169 614 minecraft:cyan_concrete
fill 230 169 615 230 169 619 minecraft:magenta_concrete
setblock 230 169 620 minecraft:cyan_concrete
fill 230 169 621 230 169 630 minecraft:magenta_concrete
setblock 230 169 631 minecraft:cyan_concrete
fill 230 169 632 230 169 638 minecraft:magenta_concrete
fill 230 169 639 230 169 640 minecraft:cyan_concrete
fill 230 169 641 230 171 641 minecraft:magenta_concrete
setblock 230 169 642 minecraft:cyan_concrete
fill 230 169 643 230 237 645 minecraft:magenta_concrete
fill 188 170 608 188 233 608 minecraft:magenta_concrete
fill 188 170 611 188 233 611 minecraft:magenta_concrete
fill 188 170 624 188 237 624 minecraft:magenta_concrete
setblock 188 170 630 minecraft:cyan_concrete
fill 188 170 631 188 235 632 minecraft:magenta_concrete
fill 188 170 633 188 170 634 minecraft:cyan_concrete
fill 188 170 635 188 235 637 minecraft:magenta_concrete
setblock 188 170 638 minecraft:cyan_concrete
fill 188 170 639 188 171 643 minecraft:magenta_concrete
fill 188 170 645 188 237 645 minecraft:magenta_concrete
setblock 191 170 646 minecraft:cyan_concrete
fill 192 170 646 199 171 646 minecraft:magenta_concrete
fill 203 170 604 203 171 604 minecraft:magenta_concrete
fill 207 170 604 212 171 604 minecraft:magenta_concrete
fill 207 170 635 208 171 636 minecraft:cyan_concrete
fill 212 170 606 212 171 606 minecraft:black_concrete
fill 212 170 608 212 171 608 minecraft:black_concrete
setblock 213 170 604 minecraft:cyan_concrete
fill 213 170 605 213 171 605 minecraft:black_concrete
fill 213 170 607 213 171 607 minecraft:black_concrete
fill 213 170 609 213 171 609 minecraft:black_concrete
fill 214 170 604 214 234 604 minecraft:magenta_concrete
fill 214 170 606 214 171 606 minecraft:black_concrete
fill 214 170 608 214 171 608 minecraft:black_concrete
fill 215 170 605 215 171 605 minecraft:black_concrete
fill 215 170 607 215 171 607 minecraft:black_concrete
fill 215 170 609 215 171 609 minecraft:black_concrete
fill 216 170 606 216 171 606 minecraft:black_concrete
fill 216 170 608 216 171 608 minecraft:black_concrete
fill 217 170 605 217 171 605 minecraft:black_concrete
fill 217 170 607 217 171 607 minecraft:black_concrete
fill 217 170 609 217 171 609 minecraft:black_concrete
fill 218 170 606 218 171 606 minecraft:black_concrete
fill 218 170 608 218 171 608 minecraft:black_concrete
fill 219 170 605 219 171 605 minecraft:black_concrete
fill 219 170 607 219 171 607 minecraft:black_concrete
fill 219 170 609 219 171 609 minecraft:black_concrete
fill 220 170 606 220 171 606 minecraft:black_concrete
fill 220 170 608 220 171 608 minecraft:black_concrete
fill 220 170 629 220 172 629 minecraft:black_concrete
fill 220 170 632 220 172 632 minecraft:black_concrete
setblock 222 170 604 minecraft:cyan_concrete
fill 222 170 628 222 172 628 minecraft:black_concrete
fill 223 170 632 223 172 632 minecraft:black_concrete
fill 224 170 630 224 172 631 minecraft:black_concrete
fill 227 170 646 227 233 646 minecraft:magenta_concrete
setblock 229 170 646 minecraft:cyan_concrete
setblock 230 170 605 minecraft:cyan_concrete
fill 230 170 606 230 234 608 minecraft:magenta_concrete
setblock 230 170 611 minecraft:cyan_concrete
fill 230 170 612 230 237 612 minecraft:magenta_concrete
setblock 230 170 613 minecraft:cyan_concrete
fill 230 170 614 230 237 614 minecraft:magenta_concrete
setblock 230 170 615 minecraft:cyan_concrete
fill 230 170 616 230 171 620 minecraft:magenta_concrete
setblock 230 170 621 minecraft:cyan_concrete
fill 230 170 622 230 171 629 minecraft:magenta_concrete
setblock 230 170 630 minecraft:cyan_concrete
fill 230 170 631 230 237 631 minecraft:magenta_concrete
setblock 230 170 632 minecraft:cyan_concrete
fill 230 170 633 230 171 634 minecraft:magenta_concrete
setblock 230 170 635 minecraft:cyan_concrete
fill 230 170 636 230 234 640 minecraft:magenta_concrete
fill 230 170 642 230 237 642 minecraft:magenta_concrete
fill 230 170 646 230 235 646 minecraft:magenta_concrete
fill 188 171 629 188 233 630 minecraft:magenta_concrete
fill 188 171 633 188 171 634 minecraft:magenta_concrete
fill 188 171 638 188 237 638 minecraft:magenta_concrete
fill 189 171 646 189 237 646 minecraft:magenta_concrete
setblock 191 171 646 minecraft:magenta_concrete
fill 213 171 604 213 237 604 minecraft:magenta_concrete
fill 219 171 630 219 172 631 minecraft:black_concrete
fill 221 171 628 221 172 628 minecraft:black_concrete
fill 221 171 633 223 172 633 minecraft:black_concrete
fill 222 171 604 222 237 604 minecraft:magenta_concrete
fill 223 171 628 223 172 628 minecraft:black_concrete
fill 224 171 629 224 172 629 minecraft:black_concrete
fill 224 171 632 224 172 632 minecraft:black_concrete
fill 229 171 646 229 237 646 minecraft:magenta_concrete
fill 230 171 605 230 238 605 minecraft:magenta_concrete
fill 230 171 611 230 237 611 minecraft:magenta_concrete
fill 230 171 613 230 237 613 minecraft:magenta_concrete
fill 230 171 615 230 234 615 minecraft:magenta_concrete
fill 230 171 621 230 237 621 minecraft:magenta_concrete
fill 230 171 630 230 237 630 minecraft:magenta_concrete
fill 230 171 632 230 238 632 minecraft:magenta_concrete
fill 230 171 635 230 237 635 minecraft:magenta_concrete
fill 188 172 609 188 177 609 minecraft:sea_lantern
fill 188 172 610 188 237 610 minecraft:magenta_concrete
fill 188 172 614 188 233 616 minecraft:magenta_concrete
fill 188 172 617 188 177 617 minecraft:sea_lantern
fill 188 172 618 188 233 623 minecraft:magenta_concrete
fill 188 172 625 188 177 625 minecraft:sea_lantern
fill 188 172 626 188 233 628 minecraft:magenta_concrete
fill 188 172 633 188 177 633 minecraft:sea_lantern
fill 188 172 634 188 233 634 minecraft:magenta_concrete
fill 188 172 639 188 237 640 minecraft:magenta_concrete
fill 188 172 641 188 177 641 minecraft:sea_lantern
fill 188 172 642 188 237 643 minecraft:magenta_concrete
fill 191 172 646 191 177 646 minecraft:sea_lantern
fill 192 172 646 198 233 646 minecraft:magenta_concrete
fill 195 172 604 195 177 604 minecraft:sea_lantern
fill 196 172 604 199 234 604 minecraft:magenta_concrete
fill 199 172 646 199 177 646 minecraft:sea_lantern
fill 200 172 646 206 237 646 minecraft:magenta_concrete
fill 203 172 604 203 177 604 minecraft:sea_lantern
fill 207 172 604 210 233 604 minecraft:magenta_concrete
fill 207 172 646 207 177 646 minecraft:sea_lantern
fill 208 172 646 214 233 646 minecraft:magenta_concrete
fill 211 172 604 211 177 604 minecraft:sea_lantern
fill 212 172 604 212 237 604 minecraft:magenta_concrete
setblock 212 172 606 minecraft:sea_lantern
setblock 212 172 608 minecraft:sea_lantern
setblock 213 172 605 minecraft:sea_lantern
setblock 213 172 607 minecraft:sea_lantern
setblock 213 172 609 minecraft:sea_lantern
setblock 214 172 606 minecraft:sea_lantern
setblock 214 172 608 minecraft:sea_lantern
setblock 215 172 605 minecraft:sea_lantern
setblock 215 172 607 minecraft:sea_lantern
setblock 215 172 609 minecraft:sea_lantern
fill 215 172 646 215 177 646 minecraft:sea_lantern
setblock 216 172 606 minecraft:sea_lantern
setblock 216 172 608 minecraft:sea_lantern
fill 216 172 646 222 234 646 minecraft:magenta_concrete
setblock 217 172 605 minecraft:sea_lantern
setblock 217 172 607 minecraft:sea_lantern
setblock 217 172 609 minecraft:sea_lantern
setblock 218 172 606 minecraft:sea_lantern
setblock 218 172 608 minecraft:sea_lantern
fill 219 172 604 219 172 605 minecraft:sea_lantern
setblock 219 172 607 minecraft:sea_lantern
setblock 219 172 609 minecraft:sea_lantern
setblock 219 172 629 minecraft:black_concrete
setblock 219 172 632 minecraft:black_concrete
fill 220 172 604 221 233 604 minecraft:magenta_concrete
setblock 220 172 606 minecraft:sea_lantern
setblock 220 172 608 minecraft:sea_lantern
setblock 220 172 628 minecraft:black_concrete
setblock 220 172 633 minecraft:black_concrete
fill 223 172 646 223 177 646 minecraft:sea_lantern
setblock 224 172 628 minecraft:black_concrete
fill 224 172 646 226 233 646 minecraft:magenta_concrete
fill 225 172 630 225 172 631 minecraft:black_concrete
fill 227 172 604 227 177 604 minecraft:sea_lantern
fill 230 172 609 230 177 609 minecraft:sea_lantern
fill 230 172 616 230 237 616 minecraft:magenta_concrete
fill 230 172 617 230 177 617 minecraft:sea_lantern
fill 230 172 618 230 233 620 minecraft:magenta_concrete
fill 230 172 622 230 235 624 minecraft:magenta_concrete
fill 230 172 625 230 177 625 minecraft:sea_lantern
fill 230 172 626 230 234 629 minecraft:magenta_concrete
fill 230 172 633 230 177 633 minecraft:sea_lantern
fill 230 172 634 230 237 634 minecraft:magenta_concrete
fill 230 172 641 230 177 641 minecraft:sea_lantern
fill 212 173 606 212 174 606 minecraft:black_concrete
fill 212 173 608 212 174 608 minecraft:black_concrete
fill 213 173 605 213 174 605 minecraft:black_concrete
fill 213 173 607 213 174 607 minecraft:black_concrete
fill 213 173 609 213 174 609 minecraft:black_concrete
fill 214 173 606 214 174 606 minecraft:black_concrete
fill 214 173 608 214 174 608 minecraft:black_concrete
fill 215 173 605 215 174 605 minecraft:black_concrete
fill 215 173 607 215 174 607 minecraft:black_concrete
fill 215 173 609 215 174 609 minecraft:black_concrete
fill 216 173 606 216 174 606 minecraft:black_concrete
fill 216 173 608 216 174 608 minecraft:black_concrete
fill 217 173 605 217 174 605 minecraft:black_concrete
fill 217 173 607 217 174 607 minecraft:black_concrete
fill 217 173 609 217 174 609 minecraft:black_concrete
fill 218 173 606 218 174 606 minecraft:black_concrete
fill 218 173 608 218 174 608 minecraft:black_concrete
fill 219 173 604 219 177 604 minecraft:sea_lantern
fill 219 173 605 219 174 605 minecraft:black_concrete
fill 219 173 607 219 174 607 minecraft:black_concrete
fill 219 173 609 219 174 609 minecraft:black_concrete
fill 220 173 606 220 174 606 minecraft:black_concrete
fill 220 173 608 220 174 608 minecraft:black_concrete
fill 221 173 630 222 174 631 minecraft:white_stained_glass
fill 226 173 622 227 174 622 minecraft:magenta_concrete
setblock 191 174 607 minecraft:light[level=14]
setblock 191 174 615 minecraft:light[level=14]
setblock 191 174 623 minecraft:light[level=14]
setblock 191 174 631 minecraft:light[level=14]
setblock 191 174 639 minecraft:light[level=14]
setblock 199 174 607 minecraft:light[level=14]
setblock 199 174 615 minecraft:light[level=14]
setblock 199 174 623 minecraft:light[level=14]
setblock 199 174 631 minecraft:light[level=14]
setblock 199 174 639 minecraft:light[level=14]
setblock 207 174 607 minecraft:light[level=14]
setblock 207 174 615 minecraft:light[level=14]
setblock 207 174 623 minecraft:light[level=14]
setblock 207 174 631 minecraft:light[level=14]
setblock 207 174 639 minecraft:light[level=14]
setblock 215 174 615 minecraft:light[level=14]
setblock 215 174 623 minecraft:light[level=14]
setblock 215 174 631 minecraft:light[level=14]
setblock 215 174 639 minecraft:light[level=14]
setblock 223 174 607 minecraft:light[level=14]
setblock 223 174 615 minecraft:light[level=14]
setblock 223 174 623 minecraft:light[level=14]
setblock 223 174 631 minecraft:light[level=14]
setblock 223 174 639 minecraft:light[level=14]
setblock 212 175 606 minecraft:sea_lantern
setblock 212 175 608 minecraft:sea_lantern
setblock 213 175 605 minecraft:sea_lantern
setblock 213 175 607 minecraft:sea_lantern
setblock 213 175 609 minecraft:sea_lantern
setblock 214 175 606 minecraft:sea_lantern
setblock 214 175 608 minecraft:sea_lantern
setblock 215 175 605 minecraft:sea_lantern
setblock 215 175 607 minecraft:sea_lantern
setblock 215 175 609 minecraft:sea_lantern
setblock 216 175 606 minecraft:sea_lantern
setblock 216 175 608 minecraft:sea_lantern
setblock 217 175 605 minecraft:sea_lantern
setblock 217 175 607 minecraft:sea_lantern
setblock 217 175 609 minecraft:sea_lantern
setblock 218 175 606 minecraft:sea_lantern
setblock 218 175 608 minecraft:sea_lantern
setblock 219 175 605 minecraft:sea_lantern
setblock 219 175 607 minecraft:sea_lantern
setblock 219 175 609 minecraft:sea_lantern
setblock 220 175 606 minecraft:sea_lantern
setblock 220 175 608 minecraft:sea_lantern
fill 221 175 630 222 175 630 minecraft:white_stained_glass
setblock 222 175 631 minecraft:white_stained_glass
fill 212 176 606 212 178 606 minecraft:black_concrete
fill 212 176 608 212 178 608 minecraft:black_concrete
fill 213 176 605 213 178 605 minecraft:black_concrete
fill 213 176 607 213 178 607 minecraft:black_concrete
fill 213 176 609 213 178 609 minecraft:black_concrete
fill 213 176 637 215 177 637 minecraft:magenta_concrete
fill 214 176 606 214 178 606 minecraft:black_concrete
fill 214 176 608 214 178 608 minecraft:black_concrete
fill 214 176 636 215 177 636 minecraft:magenta_concrete
fill 215 176 605 215 178 605 minecraft:black_concrete
fill 215 176 607 215 178 607 minecraft:black_concrete
fill 215 176 609 215 178 609 minecraft:black_concrete
fill 216 176 606 216 178 606 minecraft:black_concrete
fill 216 176 608 216 178 608 minecraft:black_concrete
fill 217 176 605 217 178 605 minecraft:black_concrete
fill 217 176 607 217 178 607 minecraft:black_concrete
fill 217 176 609 217 178 609 minecraft:black_concrete
fill 218 176 606 218 178 606 minecraft:black_concrete
fill 218 176 608 218 178 608 minecraft:black_concrete
fill 219 176 605 219 178 605 minecraft:black_concrete
fill 219 176 607 219 178 607 minecraft:black_concrete
fill 219 176 609 219 178 609 minecraft:black_concrete
fill 220 176 606 220 178 606 minecraft:black_concrete
fill 220 176 608 220 178 608 minecraft:black_concrete
setblock 222 176 630 minecraft:white_stained_glass
fill 188 178 609 188 188 609 minecraft:magenta_concrete
fill 188 178 617 188 188 617 minecraft:magenta_concrete
fill 188 178 625 188 188 625 minecraft:magenta_concrete
fill 188 178 633 188 188 633 minecraft:magenta_concrete
fill 188 178 641 188 188 641 minecraft:magenta_concrete
fill 191 178 646 191 188 646 minecraft:magenta_concrete
fill 195 178 604 195 188 604 minecraft:magenta_concrete
fill 199 178 646 199 188 646 minecraft:magenta_concrete
fill 203 178 604 203 188 604 minecraft:magenta_concrete
fill 207 178 646 207 188 646 minecraft:magenta_concrete
fill 211 178 604 211 188 604 minecraft:magenta_concrete
fill 215 178 646 215 188 646 minecraft:magenta_concrete
fill 219 178 604 219 188 604 minecraft:magenta_concrete
fill 223 178 646 223 188 646 minecraft:magenta_concrete
fill 227 178 604 227 188 604 minecraft:magenta_concrete
fill 230 178 609 230 188 609 minecraft:magenta_concrete
fill 230 178 617 230 188 617 minecraft:magenta_concrete
fill 230 178 625 230 188 625 minecraft:magenta_concrete
fill 230 178 633 230 188 633 minecraft:magenta_concrete
fill 230 178 641 230 188 641 minecraft:magenta_concrete
setblock 191 182 607 minecraft:light[level=14]
setblock 191 182 615 minecraft:light[level=14]
setblock 191 182 623 minecraft:light[level=14]
setblock 191 182 631 minecraft:light[level=14]
setblock 191 182 639 minecraft:light[level=14]
setblock 199 182 607 minecraft:light[level=14]
setblock 199 182 615 minecraft:light[level=14]
setblock 199 182 623 minecraft:light[level=14]
setblock 199 182 631 minecraft:light[level=14]
setblock 199 182 639 minecraft:light[level=14]
setblock 207 182 607 minecraft:light[level=14]
setblock 207 182 615 minecraft:light[level=14]
setblock 207 182 623 minecraft:light[level=14]
setblock 207 182 631 minecraft:light[level=14]
setblock 207 182 639 minecraft:light[level=14]
setblock 215 182 607 minecraft:light[level=14]
setblock 215 182 615 minecraft:light[level=14]
setblock 215 182 623 minecraft:light[level=14]
setblock 215 182 631 minecraft:light[level=14]
setblock 215 182 639 minecraft:light[level=14]
setblock 223 182 607 minecraft:light[level=14]
setblock 223 182 615 minecraft:light[level=14]
setblock 223 182 623 minecraft:light[level=14]
setblock 223 182 631 minecraft:light[level=14]
setblock 223 182 639 minecraft:light[level=14]
fill 205 183 621 207 183 623 minecraft:redstone_block
fill 209 183 626 211 183 628 minecraft:redstone_block
fill 213 183 617 215 183 619 minecraft:redstone_block
fill 214 183 624 216 183 626 minecraft:redstone_block
fill 195 184 622 200 185 622 minecraft:cyan_concrete
fill 196 184 617 196 185 618 minecraft:black_concrete
fill 196 184 619 201 185 621 minecraft:cyan_concrete
fill 196 184 623 197 185 627 minecraft:cyan_concrete
fill 197 184 615 197 185 617 minecraft:black_concrete
fill 197 184 618 210 185 618 minecraft:cyan_concrete
fill 197 184 628 197 185 629 minecraft:cyan_concrete
fill 198 184 613 198 185 616 minecraft:black_concrete
fill 198 184 617 210 185 617 minecraft:cyan_concrete
fill 198 184 623 198 185 626 minecraft:cyan_concrete
fill 198 184 627 201 185 631 minecraft:black_concrete
fill 199 184 612 200 185 615 minecraft:black_concrete
fill 199 184 616 209 185 616 minecraft:cyan_concrete
fill 199 184 623 199 185 623 minecraft:cyan_concrete
fill 199 184 624 201 185 626 minecraft:black_concrete
fill 199 184 632 201 185 632 minecraft:black_concrete
fill 200 184 611 202 185 611 minecraft:cyan_concrete
fill 200 184 623 203 185 623 minecraft:black_concrete
fill 200 184 633 201 185 633 minecraft:black_concrete
fill 201 184 610 214 185 610 minecraft:cyan_concrete
fill 201 184 612 208 185 614 minecraft:black_concrete
fill 201 184 615 207 185 615 minecraft:cyan_concrete
fill 201 184 622 204 184 622 minecraft:black_concrete
fill 201 184 634 202 185 634 minecraft:black_concrete
fill 202 184 609 213 185 609 minecraft:cyan_concrete
fill 202 184 619 202 185 620 minecraft:cyan_concrete
fill 202 184 621 204 184 621 minecraft:black_concrete
fill 202 184 624 202 185 625 minecraft:black_concrete
fill 202 184 626 206 185 633 minecraft:cyan_concrete
fill 202 184 635 202 185 635 minecraft:black_concrete
fill 203 184 611 204 185 611 minecraft:black_concrete
fill 203 184 619 205 185 619 minecraft:cyan_concrete
fill 203 184 620 209 184 620 minecraft:black_concrete
fill 203 184 624 206 184 625 minecraft:cyan_concrete
fill 203 184 634 209 185 635 minecraft:cyan_concrete
fill 204 184 608 212 185 608 minecraft:cyan_concrete
setblock 204 184 623 minecraft:cyan_concrete
fill 204 184 636 211 185 636 minecraft:cyan_concrete
fill 205 184 611 215 185 611 minecraft:cyan_concrete
fill 206 184 607 210 185 607 minecraft:cyan_concrete
fill 206 184 619 206 185 619 minecraft:black_concrete
fill 206 184 637 213 185 637 minecraft:cyan_concrete
fill 207 184 619 211 185 619 minecraft:cyan_concrete
setblock 207 184 624 minecraft:cyan_concrete
fill 207 184 625 208 184 630 minecraft:black_concrete
fill 207 184 631 207 185 633 minecraft:cyan_concrete
fill 208 184 615 211 185 615 minecraft:black_concrete
fill 208 184 621 208 184 623 minecraft:cyan_concrete
fill 208 184 624 209 184 624 minecraft:black_concrete
fill 208 184 631 210 185 632 minecraft:black_concrete
fill 208 184 633 208 185 633 minecraft:cyan_concrete
fill 209 184 612 215 185 612 minecraft:cyan_concrete
fill 209 184 613 209 185 614 minecraft:black_concrete
setblock 209 184 621 minecraft:black_concrete
setblock 209 184 622 minecraft:cyan_concrete
setblock 209 184 623 minecraft:black_concrete
fill 209 184 625 211 184 625 minecraft:cyan_concrete
fill 209 184 629 209 184 630 minecraft:black_concrete
fill 209 184 633 213 185 633 minecraft:black_concrete
fill 210 184 613 216 185 613 minecraft:cyan_concrete
fill 210 184 614 210 185 614 minecraft:black_concrete
fill 210 184 616 212 184 616 minecraft:black_concrete
fill 210 184 620 211 184 620 minecraft:cyan_concrete
setblock 210 184 624 minecraft:cyan_concrete
fill 210 184 629 224 184 630 minecraft:cyan_concrete
fill 210 184 634 216 185 634 minecraft:black_concrete
fill 210 184 635 210 185 635 minecraft:cyan_concrete
fill 211 184 606 211 185 607 minecraft:black_concrete
fill 211 184 614 216 185 614 minecraft:cyan_concrete
fill 211 184 617 212 184 618 minecraft:black_concrete
fill 211 184 624 212 184 624 minecraft:black_concrete
fill 211 184 631 224 185 631 minecraft:cyan_concrete
fill 211 184 632 211 185 632 minecraft:black_concrete
fill 211 184 635 220 185 635 minecraft:black_concrete
fill 211 184 638 211 185 638 minecraft:cyan_concrete
fill 212 184 607 216 185 607 minecraft:black_concrete
fill 212 184 615 216 185 615 minecraft:cyan_concrete
fill 212 184 619 212 184 620 minecraft:black_concrete
fill 212 184 625 213 184 626 minecraft:black_concrete
fill 212 184 627 212 184 628 minecraft:cyan_concrete
fill 212 184 632 223 185 632 minecraft:cyan_concrete
fill 212 184 636 218 185 636 minecraft:black_concrete
fill 213 184 608 217 185 608 minecraft:black_concrete
fill 213 184 616 216 184 616 minecraft:cyan_concrete
fill 213 184 620 214 184 621 minecraft:cyan_concrete
fill 213 184 622 216 184 622 minecraft:black_concrete
fill 213 184 623 213 184 624 minecraft:cyan_concrete
fill 213 184 627 222 184 627 minecraft:black_concrete
fill 213 184 628 214 185 628 minecraft:cyan_concrete
fill 214 184 609 218 185 609 minecraft:black_concrete
fill 214 184 623 222 184 623 minecraft:cyan_concrete
fill 214 184 633 222 185 633 minecraft:cyan_concrete
fill 214 184 637 216 185 637 minecraft:black_concrete
fill 215 184 610 218 185 610 minecraft:black_concrete
setblock 215 184 620 minecraft:cyan_concrete
fill 215 184 621 217 185 621 minecraft:black_concrete
fill 215 184 628 220 185 628 minecraft:black_concrete
fill 216 184 611 219 185 612 minecraft:black_concrete
fill 216 184 617 216 184 618 minecraft:cyan_concrete
fill 216 184 619 218 184 620 minecraft:black_concrete
fill 217 184 613 219 185 618 minecraft:black_concrete
fill 217 184 622 223 185 622 minecraft:cyan_concrete
fill 217 184 624 219 184 625 minecraft:cyan_concrete
fill 217 184 626 224 184 626 minecraft:black_concrete
fill 217 184 634 220 185 634 minecraft:cyan_concrete
fill 218 184 608 218 185 608 minecraft:cyan_concrete
fill 218 184 621 223 185 621 minecraft:cyan_concrete
fill 219 184 609 220 185 610 minecraft:cyan_concrete
fill 219 184 619 224 185 620 minecraft:cyan_concrete
fill 220 184 611 222 185 618 minecraft:cyan_concrete
fill 220 184 624 221 185 624 minecraft:cyan_concrete
fill 220 184 625 225 185 625 minecraft:black_concrete
fill 221 184 610 221 185 610 minecraft:cyan_concrete
fill 221 184 628 225 185 628 minecraft:cyan_concrete
fill 221 184 634 221 185 634 minecraft:black_concrete
fill 222 184 624 226 185 624 minecraft:black_concrete
fill 223 184 612 223 185 618 minecraft:cyan_concrete
fill 223 184 623 226 185 623 minecraft:black_concrete
fill 223 184 627 226 185 627 minecraft:cyan_concrete
fill 224 184 613 224 185 618 minecraft:cyan_concrete
fill 224 184 621 226 185 622 minecraft:black_concrete
fill 225 184 615 225 185 618 minecraft:cyan_concrete
fill 225 184 619 226 185 620 minecraft:black_concrete
fill 225 184 626 226 185 626 minecraft:cyan_concrete
fill 225 184 629 225 185 629 minecraft:cyan_concrete
fill 226 184 617 226 185 618 minecraft:black_concrete
fill 226 184 625 226 185 625 minecraft:cyan_concrete
fill 227 184 622 227 185 622 minecraft:black_concrete
fill 189 185 605 194 185 645 minecraft:cyan_concrete
fill 195 185 605 195 185 621 minecraft:cyan_concrete
fill 195 185 623 195 185 645 minecraft:cyan_concrete
fill 196 185 605 196 185 616 minecraft:cyan_concrete
fill 196 185 628 196 185 645 minecraft:cyan_concrete
fill 197 185 605 197 185 614 minecraft:cyan_concrete
fill 197 185 630 197 185 645 minecraft:cyan_concrete
fill 198 185 605 198 185 612 minecraft:cyan_concrete
fill 198 185 632 198 185 645 minecraft:cyan_concrete
fill 199 185 605 199 185 611 minecraft:cyan_concrete
fill 199 185 633 199 185 645 minecraft:cyan_concrete
fill 200 185 605 200 185 610 minecraft:cyan_concrete
fill 200 185 634 200 185 645 minecraft:cyan_concrete
fill 201 185 605 201 185 609 minecraft:cyan_concrete
fill 201 185 622 203 185 622 minecraft:black_concrete
fill 201 185 635 201 185 645 minecraft:cyan_concrete
fill 202 185 605 203 185 608 minecraft:cyan_concrete
fill 202 185 621 203 185 621 minecraft:black_concrete
fill 202 185 636 203 185 645 minecraft:cyan_concrete
setblock 203 185 620 minecraft:black_concrete
fill 203 185 624 203 185 625 minecraft:cyan_concrete
fill 204 185 605 205 185 607 minecraft:cyan_concrete
fill 204 185 620 204 185 624 minecraft:sea_lantern
fill 204 185 625 206 185 625 minecraft:cyan_concrete
fill 204 185 637 205 185 645 minecraft:cyan_concrete
fill 205 185 620 216 185 620 minecraft:sea_lantern
fill 205 185 621 207 185 623 minecraft:cyan_concrete
fill 205 185 624 213 185 624 minecraft:sea_lantern
fill 206 185 605 210 185 606 minecraft:cyan_concrete
fill 206 185 638 210 185 645 minecraft:cyan_concrete
fill 207 185 625 207 185 630 minecraft:black_concrete
fill 208 185 621 209 185 623 minecraft:sea_lantern
fill 208 185 625 208 185 629 minecraft:sea_lantern
fill 208 185 630 209 185 630 minecraft:black_concrete
fill 209 185 625 213 185 625 minecraft:sea_lantern
fill 209 185 626 211 185 628 minecraft:cyan_concrete
fill 209 185 629 212 185 629 minecraft:sea_lantern
fill 210 185 616 211 185 616 minecraft:black_concrete
fill 210 185 630 229 185 630 minecraft:cyan_concrete
fill 211 185 605 229 185 605 minecraft:cyan_concrete
fill 211 185 617 211 185 618 minecraft:black_concrete
fill 211 185 639 229 185 645 minecraft:cyan_concrete
fill 212 185 606 229 185 606 minecraft:cyan_concrete
fill 212 185 616 212 185 619 minecraft:sea_lantern
fill 212 185 626 212 185 628 minecraft:sea_lantern
fill 212 185 638 229 185 638 minecraft:cyan_concrete
fill 213 185 616 216 185 616 minecraft:sea_lantern
fill 213 185 617 215 185 619 minecraft:cyan_concrete
fill 213 185 621 213 185 623 minecraft:sea_lantern
fill 213 185 626 213 185 627 minecraft:sea_lantern
fill 213 185 629 224 185 629 minecraft:cyan_concrete
setblock 214 185 621 minecraft:cyan_concrete
fill 214 185 622 216 185 622 minecraft:black_concrete
fill 214 185 623 217 185 623 minecraft:sea_lantern
fill 214 185 624 216 185 626 minecraft:cyan_concrete
fill 214 185 627 217 185 627 minecraft:sea_lantern
fill 216 185 617 216 185 619 minecraft:sea_lantern
fill 217 185 607 229 185 607 minecraft:cyan_concrete
fill 217 185 619 218 185 620 minecraft:black_concrete
fill 217 185 624 217 185 626 minecraft:sea_lantern
fill 217 185 637 229 185 637 minecraft:cyan_concrete
fill 218 185 623 219 185 625 minecraft:cyan_concrete
fill 218 185 626 222 185 627 minecraft:black_concrete
fill 219 185 608 229 185 608 minecraft:cyan_concrete
fill 219 185 636 229 185 636 minecraft:cyan_concrete
fill 220 185 623 222 185 623 minecraft:cyan_concrete
fill 221 185 609 229 185 609 minecraft:cyan_concrete
fill 221 185 635 229 185 635 minecraft:cyan_concrete
fill 222 185 610 229 185 610 minecraft:cyan_concrete
fill 222 185 634 229 185 634 minecraft:cyan_concrete
fill 223 185 611 229 185 611 minecraft:cyan_concrete
fill 223 185 626 224 185 626 minecraft:black_concrete
fill 223 185 633 229 185 633 minecraft:cyan_concrete
fill 224 185 612 229 185 612 minecraft:cyan_concrete
fill 224 185 632 229 185 632 minecraft:cyan_concrete
fill 225 185 613 229 185 614 minecraft:cyan_concrete
fill 225 185 631 229 185 631 minecraft:cyan_concrete
fill 226 185 615 229 185 616 minecraft:cyan_concrete
fill 226 185 628 229 185 629 minecraft:cyan_concrete
fill 227 185 617 229 185 621 minecraft:cyan_concrete
fill 227 185 623 229 185 627 minecraft:cyan_concrete
fill 228 185 622 229 185 622 minecraft:cyan_concrete
fill 197 186 622 199 200 622 minecraft:pink_concrete
fill 198 186 621 198 200 621 minecraft:pink_concrete
fill 198 186 623 198 200 623 minecraft:pink_concrete
fill 201 186 612 202 200 613 minecraft:light_blue_concrete
fill 201 186 631 202 200 632 minecraft:light_blue_concrete
fill 210 186 609 212 200 609 minecraft:pink_concrete
fill 210 186 635 212 200 635 minecraft:pink_concrete
fill 211 186 608 211 200 608 minecraft:pink_concrete
fill 211 186 610 211 200 610 minecraft:pink_concrete
fill 211 186 634 211 200 634 minecraft:pink_concrete
fill 211 186 636 211 200 636 minecraft:pink_concrete
fill 220 186 612 221 200 613 minecraft:light_blue_concrete
fill 220 186 631 221 200 632 minecraft:light_blue_concrete
fill 223 186 622 225 200 622 minecraft:pink_concrete
fill 224 186 621 224 200 621 minecraft:pink_concrete
fill 224 186 623 224 200 623 minecraft:pink_concrete
fill 205 187 621 206 188 623 minecraft:magenta_concrete
fill 206 187 619 206 188 620 minecraft:magenta_concrete
fill 206 187 624 206 188 625 minecraft:magenta_concrete
fill 207 187 618 207 188 619 minecraft:magenta_concrete
fill 207 187 625 207 188 626 minecraft:magenta_concrete
fill 208 187 617 208 188 618 minecraft:magenta_concrete
fill 208 187 626 208 188 627 minecraft:magenta_concrete
fill 209 187 617 214 188 617 minecraft:magenta_concrete
fill 209 187 627 214 188 627 minecraft:magenta_concrete
fill 210 187 616 212 188 616 minecraft:magenta_concrete
fill 210 187 628 212 188 628 minecraft:magenta_concrete
fill 214 187 618 215 188 618 minecraft:magenta_concrete
fill 214 187 626 215 188 626 minecraft:magenta_concrete
fill 215 187 619 216 188 619 minecraft:magenta_concrete
fill 215 187 625 216 188 625 minecraft:magenta_concrete
fill 216 187 620 216 188 624 minecraft:magenta_concrete
fill 217 187 621 217 188 623 minecraft:magenta_concrete
fill 188 189 609 188 191 609 minecraft:sea_lantern
fill 188 189 617 188 191 617 minecraft:sea_lantern
fill 188 189 625 188 191 625 minecraft:sea_lantern
fill 188 189 633 188 191 633 minecraft:sea_lantern
fill 188 189 641 188 191 641 minecraft:sea_lantern
fill 189 189 611 189 232 612 minecraft:black_concrete
fill 189 189 619 189 232 620 minecraft:black_concrete
fill 189 189 627 189 232 628 minecraft:black_concrete
fill 189 189 635 189 232 636 minecraft:black_concrete
fill 189 189 643 189 232 644 minecraft:black_concrete
fill 190 189 605 191 232 605 minecraft:black_concrete
fill 191 189 646 191 191 646 minecraft:sea_lantern
fill 195 189 604 195 191 604 minecraft:sea_lantern
fill 195 189 645 196 232 645 minecraft:black_concrete
fill 198 189 605 199 232 605 minecraft:black_concrete
fill 199 189 646 199 191 646 minecraft:sea_lantern
fill 201 189 639 203 194 639 minecraft:black_concrete
fill 202 189 638 203 194 638 minecraft:black_concrete
fill 202 189 640 203 194 640 minecraft:black_concrete
fill 203 189 604 203 191 604 minecraft:sea_lantern
fill 203 189 645 204 232 645 minecraft:black_concrete
fill 206 189 605 207 232 605 minecraft:black_concrete
fill 207 189 646 207 191 646 minecraft:sea_lantern
fill 211 189 604 211 191 604 minecraft:sea_lantern
fill 211 189 645 212 232 645 minecraft:black_concrete
fill 214 189 605 215 232 605 minecraft:black_concrete
fill 215 189 646 215 191 646 minecraft:sea_lantern
fill 219 189 604 219 191 604 minecraft:sea_lantern
fill 219 189 645 220 232 645 minecraft:black_concrete
fill 222 189 605 223 232 605 minecraft:black_concrete
setblock 223 189 624 minecraft:white_stained_glass
fill 223 189 646 223 191 646 minecraft:sea_lantern
fill 227 189 604 227 191 604 minecraft:sea_lantern
fill 227 189 645 228 232 645 minecraft:black_concrete
fill 229 189 606 229 232 607 minecraft:black_concrete
fill 229 189 614 229 232 615 minecraft:black_concrete
fill 229 189 622 229 232 623 minecraft:black_concrete
fill 229 189 630 229 232 631 minecraft:black_concrete
fill 229 189 638 229 232 639 minecraft:black_concrete
fill 230 189 609 230 191 609 minecraft:sea_lantern
fill 230 189 617 230 191 617 minecraft:sea_lantern
fill 230 189 625 230 191 625 minecraft:sea_lantern
fill 230 189 633 230 191 633 minecraft:sea_lantern
fill 230 189 641 230 191 641 minecraft:sea_lantern
setblock 191 190 607 minecraft:light[level=14]
setblock 191 190 615 minecraft:light[level=14]
setblock 191 190 623 minecraft:light[level=14]
setblock 191 190 631 minecraft:light[level=14]
setblock 191 190 639 minecraft:light[level=14]
setblock 199 190 607 minecraft:light[level=14]
setblock 199 190 615 minecraft:light[level=14]
setblock 199 190 623 minecraft:light[level=14]
setblock 199 190 631 minecraft:light[level=14]
setblock 199 190 639 minecraft:light[level=14]
fill 201 190 638 201 194 638 minecraft:black_concrete
fill 201 190 640 201 194 640 minecraft:black_concrete
fill 202 190 637 202 194 637 minecraft:black_concrete
fill 204 190 639 204 194 639 minecraft:black_concrete
setblock 207 190 607 minecraft:light[level=14]
setblock 207 190 615 minecraft:light[level=14]
setblock 207 190 623 minecraft:light[level=14]
setblock 207 190 631 minecraft:light[level=14]
setblock 207 190 639 minecraft:light[level=14]
setblock 215 190 607 minecraft:light[level=14]
setblock 215 190 615 minecraft:light[level=14]
setblock 215 190 623 minecraft:light[level=14]
setblock 215 190 631 minecraft:light[level=14]
setblock 215 190 639 minecraft:light[level=14]
setblock 223 190 607 minecraft:light[level=14]
setblock 223 190 615 minecraft:light[level=14]
setblock 223 190 623 minecraft:light[level=14]
fill 223 190 624 223 200 624 minecraft:black_concrete
setblock 223 190 631 minecraft:light[level=14]
setblock 223 190 639 minecraft:light[level=14]
fill 200 191 638 200 194 639 minecraft:black_concrete
fill 201 191 637 201 194 637 minecraft:black_concrete
fill 202 191 641 203 194 641 minecraft:black_concrete
fill 203 191 621 204 192 623 minecraft:cyan_concrete
fill 203 191 637 203 194 637 minecraft:black_concrete
fill 204 191 618 204 192 620 minecraft:cyan_concrete
fill 204 191 624 204 192 626 minecraft:cyan_concrete
fill 204 191 638 204 194 638 minecraft:black_concrete
fill 204 191 640 204 194 640 minecraft:black_concrete
fill 205 191 617 205 192 618 minecraft:cyan_concrete
fill 205 191 626 205 192 627 minecraft:cyan_concrete
fill 206 191 616 206 192 617 minecraft:cyan_concrete
fill 206 191 627 206 192 628 minecraft:cyan_concrete
fill 207 191 615 207 192 616 minecraft:cyan_concrete
fill 207 191 628 207 192 629 minecraft:cyan_concrete
fill 208 191 615 215 192 615 minecraft:cyan_concrete
fill 208 191 629 215 192 629 minecraft:cyan_concrete
fill 210 191 614 212 192 614 minecraft:cyan_concrete
fill 210 191 630 212 192 630 minecraft:cyan_concrete
fill 215 191 616 216 192 616 minecraft:cyan_concrete
fill 215 191 628 216 192 628 minecraft:cyan_concrete
fill 216 191 617 217 192 617 minecraft:cyan_concrete
fill 216 191 627 217 192 627 minecraft:cyan_concrete
fill 217 191 618 218 192 618 minecraft:cyan_concrete
fill 217 191 626 218 192 626 minecraft:cyan_concrete
fill 218 191 619 218 192 625 minecraft:cyan_concrete
fill 219 191 621 219 192 623 minecraft:cyan_concrete
fill 223 191 623 223 200 623 minecraft:black_concrete
fill 188 192 609 188 199 609 minecraft:magenta_concrete
fill 188 192 617 188 199 617 minecraft:magenta_concrete
fill 188 192 625 188 199 625 minecraft:magenta_concrete
fill 188 192 633 188 199 633 minecraft:magenta_concrete
fill 188 192 641 188 199 641 minecraft:magenta_concrete
fill 191 192 646 191 199 646 minecraft:magenta_concrete
fill 195 192 604 195 199 604 minecraft:magenta_concrete
fill 199 192 646 199 199 646 minecraft:magenta_concrete
fill 200 192 640 200 194 640 minecraft:black_concrete
fill 201 192 641 201 194 641 minecraft:black_concrete
fill 202 192 636 202 194 636 minecraft:black_concrete
fill 203 192 604 203 199 604 minecraft:magenta_concrete
fill 204 192 637 204 194 637 minecraft:black_concrete
fill 204 192 641 204 194 641 minecraft:black_concrete
fill 205 192 639 205 194 639 minecraft:black_concrete
fill 207 192 646 207 199 646 minecraft:magenta_concrete
fill 211 192 604 211 199 604 minecraft:magenta_concrete
fill 213 192 611 213 193 611 minecraft:lime_concrete
fill 215 192 646 215 199 646 minecraft:magenta_concrete
fill 219 192 604 219 199 604 minecraft:magenta_concrete
fill 222 192 624 222 200 624 minecraft:black_concrete
fill 223 192 646 223 199 646 minecraft:magenta_concrete
fill 224 192 624 224 200 624 minecraft:black_concrete
fill 227 192 604 227 199 604 minecraft:magenta_concrete
fill 230 192 609 230 199 609 minecraft:magenta_concrete
fill 230 192 617 230 199 617 minecraft:magenta_concrete
fill 230 192 625 230 199 625 minecraft:magenta_concrete
fill 230 192 633 230 199 633 minecraft:magenta_concrete
fill 230 192 641 230 199 641 minecraft:magenta_concrete
fill 199 193 638 199 194 639 minecraft:black_concrete
fill 200 193 637 200 194 637 minecraft:black_concrete
fill 200 193 641 200 194 641 minecraft:black_concrete
fill 201 193 636 201 194 636 minecraft:black_concrete
fill 202 193 642 203 194 642 minecraft:black_concrete
fill 203 193 636 203 194 636 minecraft:black_concrete
fill 205 193 637 205 194 638 minecraft:black_concrete
fill 205 193 640 205 194 640 minecraft:black_concrete
fill 222 193 623 222 200 623 minecraft:black_concrete
fill 223 193 625 224 200 625 minecraft:black_concrete
setblock 199 194 637 minecraft:black_concrete
setblock 199 194 640 minecraft:black_concrete
setblock 200 194 636 minecraft:black_concrete
setblock 201 194 642 minecraft:black_concrete
setblock 204 194 636 minecraft:black_concrete
setblock 204 194 642 minecraft:black_concrete
setblock 205 194 641 minecraft:black_concrete
setblock 206 194 639 minecraft:black_concrete
fill 221 194 623 221 194 624 minecraft:black_concrete
fill 222 194 622 222 200 622 minecraft:black_concrete
fill 222 194 625 222 200 625 minecraft:black_concrete
fill 225 194 623 225 200 625 minecraft:black_concrete
fill 201 195 621 202 196 623 minecraft:lime_concrete
fill 201 195 639 203 195 639 minecraft:white_stained_glass
fill 202 195 618 202 196 620 minecraft:lime_concrete
fill 202 195 624 202 196 626 minecraft:lime_concrete
fill 202 195 638 203 195 638 minecraft:white_stained_glass
setblock 202 195 640 minecraft:white_stained_glass
fill 203 195 616 203 196 618 minecraft:lime_concrete
fill 203 195 626 203 196 628 minecraft:lime_concrete
fill 204 195 615 204 196 616 minecraft:lime_concrete
fill 204 195 628 204 196 629 minecraft:lime_concrete
fill 205 195 614 205 196 615 minecraft:lime_concrete
fill 205 195 629 205 196 630 minecraft:lime_concrete
fill 206 195 614 207 196 614 minecraft:lime_concrete
fill 206 195 630 207 196 630 minecraft:lime_concrete
fill 207 195 613 215 196 613 minecraft:lime_concrete
fill 207 195 631 215 196 631 minecraft:lime_concrete
fill 210 195 612 212 196 612 minecraft:lime_concrete
fill 210 195 632 212 196 632 minecraft:lime_concrete
fill 213 195 634 214 196 634 minecraft:yellow_concrete
fill 215 195 614 217 196 614 minecraft:lime_concrete
fill 215 195 630 217 196 630 minecraft:lime_concrete
fill 217 195 615 218 196 615 minecraft:lime_concrete
fill 217 195 629 218 196 629 minecraft:lime_concrete
fill 218 195 616 219 196 616 minecraft:lime_concrete
fill 218 195 628 219 196 628 minecraft:lime_concrete
fill 219 195 617 219 196 618 minecraft:lime_concrete
fill 219 195 626 219 196 627 minecraft:lime_concrete
fill 220 195 618 220 196 626 minecraft:lime_concrete
fill 221 195 621 221 196 623 minecraft:lime_concrete
fill 221 195 624 221 200 625 minecraft:black_concrete
fill 222 195 626 224 200 626 minecraft:black_concrete
fill 223 195 621 223 200 621 minecraft:black_concrete
fill 189 196 605 189 197 610 minecraft:black_concrete
fill 189 196 613 190 196 618 minecraft:black_concrete
fill 189 196 621 190 196 626 minecraft:black_concrete
fill 189 196 629 190 196 634 minecraft:black_concrete
fill 189 196 637 190 196 642 minecraft:black_concrete
fill 189 196 645 194 197 645 minecraft:black_concrete
fill 190 196 606 190 196 612 minecraft:black_concrete
fill 190 196 619 190 196 620 minecraft:black_concrete
fill 190 196 627 190 196 628 minecraft:black_concrete
fill 190 196 635 190 196 636 minecraft:black_concrete
fill 190 196 643 190 196 644 minecraft:black_concrete
fill 191 196 606 228 196 606 minecraft:black_concrete
fill 191 196 644 229 196 644 minecraft:black_concrete
fill 192 196 605 197 197 605 minecraft:black_concrete
fill 197 196 645 202 197 645 minecraft:black_concrete
fill 200 196 605 205 197 605 minecraft:black_concrete
fill 202 196 638 202 196 639 minecraft:white_stained_glass
setblock 203 196 639 minecraft:white_stained_glass
fill 205 196 645 210 197 645 minecraft:black_concrete
fill 208 196 605 213 197 605 minecraft:black_concrete
fill 213 196 645 218 197 645 minecraft:black_concrete
fill 216 196 605 221 197 605 minecraft:black_concrete
fill 221 196 645 226 197 645 minecraft:black_concrete
fill 222 196 621 222 200 621 minecraft:black_concrete
fill 224 196 605 229 197 605 minecraft:black_concrete
fill 225 196 621 225 200 621 minecraft:black_concrete
fill 225 196 626 225 200 626 minecraft:black_concrete
fill 226 196 622 226 200 625 minecraft:black_concrete
fill 228 196 607 228 196 643 minecraft:black_concrete
fill 229 196 608 229 197 613 minecraft:black_concrete
fill 229 196 616 229 197 621 minecraft:black_concrete
fill 229 196 624 229 197 629 minecraft:black_concrete
fill 229 196 632 229 197 637 minecraft:black_concrete
fill 229 196 640 229 197 643 minecraft:black_concrete
fill 229 196 645 229 197 645 minecraft:black_concrete
fill 189 197 613 189 197 618 minecraft:black_concrete
fill 189 197 621 189 197 626 minecraft:black_concrete
fill 189 197 629 189 197 634 minecraft:black_concrete
fill 189 197 637 189 197 642 minecraft:black_concrete
fill 196 197 622 196 205 622 minecraft:black_concrete
fill 197 197 621 197 205 621 minecraft:black_concrete
fill 197 197 623 197 205 623 minecraft:black_concrete
fill 202 197 639 202 199 639 minecraft:white_stained_glass
fill 220 197 622 220 200 625 minecraft:black_concrete
fill 221 197 621 221 200 623 minecraft:black_concrete
fill 221 197 626 221 200 626 minecraft:black_concrete
fill 222 197 620 224 200 620 minecraft:black_concrete
fill 222 197 627 224 200 627 minecraft:black_concrete
fill 226 197 621 226 200 621 minecraft:black_concrete
fill 226 197 626 226 200 626 minecraft:black_concrete
setblock 229 197 644 minecraft:black_concrete
setblock 191 198 607 minecraft:light[level=14]
setblock 191 198 615 minecraft:light[level=14]
setblock 191 198 623 minecraft:light[level=14]
setblock 191 198 631 minecraft:light[level=14]
setblock 191 198 639 minecraft:light[level=14]
fill 196 198 621 196 205 621 minecraft:black_concrete
fill 196 198 623 196 205 623 minecraft:black_concrete
setblock 199 198 607 minecraft:light[level=14]
setblock 199 198 615 minecraft:light[level=14]
setblock 199 198 623 minecraft:light[level=14]
setblock 199 198 631 minecraft:light[level=14]
setblock 199 198 639 minecraft:light[level=14]
setblock 207 198 607 minecraft:light[level=14]
setblock 207 198 615 minecraft:light[level=14]
setblock 207 198 623 minecraft:light[level=14]
setblock 207 198 631 minecraft:light[level=14]
setblock 207 198 639 minecraft:light[level=14]
setblock 215 198 607 minecraft:light[level=14]
setblock 215 198 615 minecraft:light[level=14]
setblock 215 198 623 minecraft:light[level=14]
setblock 215 198 631 minecraft:light[level=14]
setblock 215 198 639 minecraft:light[level=14]
fill 219 198 623 219 200 624 minecraft:black_concrete
fill 220 198 621 220 200 621 minecraft:black_concrete
fill 220 198 626 220 200 626 minecraft:black_concrete
fill 221 198 620 221 200 620 minecraft:black_concrete
fill 221 198 627 221 200 627 minecraft:black_concrete
setblock 223 198 607 minecraft:light[level=14]
setblock 223 198 615 minecraft:light[level=14]
setblock 223 198 631 minecraft:light[level=14]
setblock 223 198 639 minecraft:light[level=14]
fill 225 198 620 225 200 620 minecraft:black_concrete
fill 225 198 627 225 200 627 minecraft:black_concrete
fill 227 198 622 227 200 625 minecraft:black_concrete
fill 195 199 621 195 205 622 minecraft:black_concrete
fill 196 199 620 197 205 620 minecraft:black_concrete
fill 197 199 624 197 205 624 minecraft:black_concrete
fill 219 199 622 219 200 622 minecraft:black_concrete
fill 219 199 625 219 200 625 minecraft:black_concrete
fill 220 199 627 220 200 627 minecraft:black_concrete
fill 222 199 619 224 200 619 minecraft:black_concrete
fill 222 199 628 224 200 628 minecraft:black_concrete
fill 226 199 620 226 200 620 minecraft:black_concrete
fill 226 199 627 226 200 627 minecraft:black_concrete
fill 227 199 621 227 200 621 minecraft:black_concrete
fill 227 199 626 227 200 626 minecraft:black_concrete
fill 188 200 609 188 205 609 minecraft:sea_lantern
fill 188 200 617 188 205 617 minecraft:sea_lantern
fill 188 200 625 188 205 625 minecraft:sea_lantern
fill 188 200 633 188 205 633 minecraft:sea_lantern
fill 188 200 641 188 205 641 minecraft:sea_lantern
fill 191 200 646 191 205 646 minecraft:sea_lantern
fill 195 200 604 195 205 604 minecraft:sea_lantern
fill 195 200 623 195 205 623 minecraft:black_concrete
fill 196 200 624 196 205 624 minecraft:black_concrete
fill 198 200 620 198 205 620 minecraft:black_concrete
fill 198 200 624 198 205 624 minecraft:black_concrete
fill 199 200 621 199 205 621 minecraft:black_concrete
fill 199 200 623 199 205 623 minecraft:black_concrete
fill 199 200 646 199 205 646 minecraft:sea_lantern
fill 203 200 604 203 205 604 minecraft:sea_lantern
fill 207 200 646 207 205 646 minecraft:sea_lantern
fill 211 200 604 211 205 604 minecraft:sea_lantern
fill 215 200 646 215 205 646 minecraft:sea_lantern
setblock 218 200 624 minecraft:black_concrete
fill 219 200 604 219 205 604 minecraft:sea_lantern
setblock 219 200 621 minecraft:black_concrete
setblock 219 200 626 minecraft:black_concrete
setblock 220 200 620 minecraft:black_concrete
setblock 221 200 619 minecraft:black_concrete
setblock 221 200 628 minecraft:black_concrete
fill 223 200 646 223 205 646 minecraft:sea_lantern
setblock 225 200 619 minecraft:black_concrete
fill 225 200 628 226 200 628 minecraft:black_concrete
fill 227 200 604 227 205 604 minecraft:sea_lantern
setblock 227 200 620 minecraft:black_concrete
setblock 227 200 627 minecraft:black_concrete
fill 228 200 622 228 200 625 minecraft:black_concrete
fill 230 200 609 230 205 609 minecraft:sea_lantern
fill 230 200 617 230 205 617 minecraft:sea_lantern
fill 230 200 625 230 205 625 minecraft:sea_lantern
fill 230 200 633 230 205 633 minecraft:sea_lantern
fill 230 200 641 230 205 641 minecraft:sea_lantern
fill 194 201 621 194 205 623 minecraft:black_concrete
fill 195 201 620 195 205 620 minecraft:black_concrete
fill 195 201 624 195 205 624 minecraft:black_concrete
fill 196 201 619 197 205 619 minecraft:black_concrete
fill 197 201 622 199 201 622 minecraft:glowstone
setblock 198 201 621 minecraft:glowstone
setblock 198 201 623 minecraft:glowstone
fill 199 201 620 199 205 620 minecraft:black_concrete
fill 199 201 624 199 205 624 minecraft:black_concrete
fill 201 201 612 202 201 613 minecraft:glowstone
fill 201 201 631 202 201 632 minecraft:glowstone
setblock 202 201 614 minecraft:glowstone
setblock 202 201 630 minecraft:glowstone
setblock 203 201 613 minecraft:glowstone
setblock 203 201 631 minecraft:glowstone
fill 210 201 609 212 201 609 minecraft:glowstone
fill 210 201 635 212 201 635 minecraft:glowstone
setblock 211 201 608 minecraft:glowstone
setblock 211 201 610 minecraft:glowstone
setblock 211 201 634 minecraft:glowstone
setblock 211 201 636 minecraft:glowstone
fill 216 201 618 216 202 619 minecraft:magenta_concrete
fill 219 201 613 221 201 613 minecraft:glowstone
fill 219 201 631 221 201 631 minecraft:glowstone
fill 220 201 612 221 201 612 minecraft:glowstone
setblock 220 201 614 minecraft:glowstone
fill 220 201 625 220 202 625 minecraft:lime_concrete
setblock 220 201 630 minecraft:glowstone
fill 220 201 632 221 201 632 minecraft:glowstone
fill 223 201 622 225 201 622 minecraft:glowstone
fill 223 201 623 223 203 624 minecraft:white_stained_glass
setblock 224 201 621 minecraft:glowstone
setblock 224 201 623 minecraft:glowstone
fill 224 201 624 224 202 624 minecraft:white_stained_glass
fill 194 202 620 194 205 620 minecraft:black_concrete
fill 194 202 624 194 205 624 minecraft:black_concrete
fill 195 202 619 195 205 619 minecraft:black_concrete
fill 196 202 625 198 205 625 minecraft:black_concrete
fill 197 202 622 200 205 622 minecraft:black_concrete
fill 198 202 619 198 205 619 minecraft:black_concrete
fill 198 202 621 198 205 621 minecraft:black_concrete
fill 198 202 623 198 205 623 minecraft:black_concrete
fill 200 202 621 200 205 621 minecraft:black_concrete
fill 200 202 623 200 205 623 minecraft:black_concrete
setblock 224 202 623 minecraft:white_stained_glass
fill 193 203 621 193 205 623 minecraft:black_concrete
fill 194 203 619 194 205 619 minecraft:black_concrete
fill 195 203 625 195 205 625 minecraft:black_concrete
fill 196 203 618 198 205 618 minecraft:black_concrete
fill 199 203 619 199 205 619 minecraft:black_concrete
fill 199 203 625 199 205 625 minecraft:black_concrete
fill 200 203 620 200 205 620 minecraft:black_concrete
fill 200 203 624 200 205 624 minecraft:black_concrete
fill 193 204 620 193 205 620 minecraft:black_concrete
fill 193 204 624 193 205 624 minecraft:black_concrete
fill 194 204 625 194 205 625 minecraft:black_concrete
fill 195 204 618 195 205 618 minecraft:black_concrete
fill 195 204 626 198 205 626 minecraft:black_concrete
fill 199 204 618 199 205 618 minecraft:black_concrete
fill 200 204 619 200 205 619 minecraft:black_concrete
fill 200 204 625 200 205 625 minecraft:black_concrete
fill 201 204 621 201 205 623 minecraft:black_concrete
setblock 223 204 624 minecraft:white_stained_glass
fill 192 205 621 192 205 623 minecraft:black_concrete
setblock 193 205 619 minecraft:black_concrete
setblock 193 205 625 minecraft:black_concrete
setblock 194 205 618 minecraft:black_concrete
setblock 194 205 626 minecraft:black_concrete
fill 196 205 617 198 205 617 minecraft:black_concrete
setblock 199 205 626 minecraft:black_concrete
setblock 200 205 618 minecraft:black_concrete
setblock 201 205 620 minecraft:black_concrete
setblock 201 205 624 minecraft:black_concrete
fill 188 206 609 188 213 609 minecraft:magenta_concrete
fill 188 206 617 188 213 617 minecraft:magenta_concrete
fill 188 206 625 188 213 625 minecraft:magenta_concrete
fill 188 206 633 188 213 633 minecraft:magenta_concrete
fill 188 206 641 188 213 641 minecraft:magenta_concrete
setblock 191 206 607 minecraft:light[level=14]
setblock 191 206 615 minecraft:light[level=14]
setblock 191 206 623 minecraft:light[level=14]
setblock 191 206 631 minecraft:light[level=14]
setblock 191 206 639 minecraft:light[level=14]
fill 191 206 646 191 213 646 minecraft:magenta_concrete
fill 195 206 604 195 213 604 minecraft:magenta_concrete
fill 195 206 635 196 207 636 minecraft:lime_concrete
fill 196 206 621 197 206 622 minecraft:white_stained_glass
setblock 197 206 623 minecraft:white_stained_glass
setblock 198 206 622 minecraft:white_stained_glass
setblock 199 206 607 minecraft:light[level=14]
setblock 199 206 615 minecraft:light[level=14]
setblock 199 206 623 minecraft:light[level=14]
setblock 199 206 631 minecraft:light[level=14]
setblock 199 206 639 minecraft:light[level=14]
fill 199 206 646 199 213 646 minecraft:magenta_concrete
fill 203 206 604 203 213 604 minecraft:magenta_concrete
setblock 207 206 607 minecraft:light[level=14]
setblock 207 206 615 minecraft:light[level=14]
setblock 207 206 623 minecraft:light[level=14]
setblock 207 206 631 minecraft:light[level=14]
setblock 207 206 639 minecraft:light[level=14]
fill 207 206 646 207 213 646 minecraft:magenta_concrete
fill 211 206 604 211 213 604 minecraft:magenta_concrete
setblock 215 206 607 minecraft:light[level=14]
setblock 215 206 615 minecraft:light[level=14]
setblock 215 206 623 minecraft:light[level=14]
setblock 215 206 631 minecraft:light[level=14]
setblock 215 206 639 minecraft:light[level=14]
fill 215 206 646 215 213 646 minecraft:magenta_concrete
fill 219 206 604 219 213 604 minecraft:magenta_concrete
setblock 223 206 607 minecraft:light[level=14]
setblock 223 206 615 minecraft:light[level=14]
setblock 223 206 623 minecraft:light[level=14]
setblock 223 206 631 minecraft:light[level=14]
setblock 223 206 639 minecraft:light[level=14]
fill 223 206 646 223 213 646 minecraft:magenta_concrete
fill 227 206 604 227 213 604 minecraft:magenta_concrete
fill 230 206 609 230 213 609 minecraft:magenta_concrete
fill 230 206 617 230 213 617 minecraft:magenta_concrete
fill 230 206 625 230 213 625 minecraft:magenta_concrete
fill 230 206 633 230 213 633 minecraft:magenta_concrete
fill 230 206 641 230 213 641 minecraft:magenta_concrete
fill 196 207 622 197 207 622 minecraft:white_stained_glass
setblock 197 207 621 minecraft:white_stained_glass
fill 197 208 622 197 210 622 minecraft:white_stained_glass
fill 189 210 605 189 211 610 minecraft:black_concrete
fill 189 210 613 190 210 618 minecraft:black_concrete
fill 189 210 621 190 210 626 minecraft:black_concrete
fill 189 210 629 190 210 634 minecraft:black_concrete
fill 189 210 637 190 210 642 minecraft:black_concrete
fill 189 210 645 194 211 645 minecraft:black_concrete
fill 190 210 606 190 210 612 minecraft:black_concrete
fill 190 210 619 190 210 620 minecraft:black_concrete
fill 190 210 627 190 210 628 minecraft:black_concrete
fill 190 210 635 190 210 636 minecraft:black_concrete
fill 190 210 643 190 210 644 minecraft:black_concrete
fill 191 210 606 228 210 606 minecraft:black_concrete
fill 191 210 644 229 210 644 minecraft:black_concrete
fill 192 210 605 197 211 605 minecraft:black_concrete
fill 197 210 645 202 211 645 minecraft:black_concrete
fill 200 210 605 205 211 605 minecraft:black_concrete
fill 205 210 645 210 211 645 minecraft:black_concrete
fill 208 210 605 213 211 605 minecraft:black_concrete
fill 213 210 645 218 211 645 minecraft:black_concrete
fill 216 210 605 221 211 605 minecraft:black_concrete
fill 221 210 645 226 211 645 minecraft:black_concrete
fill 224 210 605 229 211 605 minecraft:black_concrete
fill 228 210 607 228 210 643 minecraft:black_concrete
fill 229 210 608 229 211 613 minecraft:black_concrete
fill 229 210 616 229 211 621 minecraft:black_concrete
fill 229 210 624 229 211 629 minecraft:black_concrete
fill 229 210 632 229 211 637 minecraft:black_concrete
fill 229 210 640 229 211 643 minecraft:black_concrete
fill 229 210 645 229 211 645 minecraft:black_concrete
fill 189 211 613 189 211 618 minecraft:black_concrete
fill 189 211 621 189 211 626 minecraft:black_concrete
schedule function dropper:buildpart/148_2 1t
