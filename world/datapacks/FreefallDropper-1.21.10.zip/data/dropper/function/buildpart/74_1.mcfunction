setblock 135 64 344 minecraft:stone
setblock 135 64 361 minecraft:stripped_spruce_log
setblock 135 64 362 minecraft:stone
fill 136 64 359 136 104 359 minecraft:cobbled_deepslate
fill 95 65 323 95 65 363 minecraft:spruce_planks
fill 96 65 323 135 65 323 minecraft:spruce_planks
fill 96 65 325 96 65 342 minecraft:spruce_planks
fill 96 65 344 96 65 361 minecraft:spruce_planks
fill 96 65 363 135 65 363 minecraft:spruce_planks
fill 97 65 324 114 65 324 minecraft:spruce_planks
fill 97 65 362 114 65 362 minecraft:spruce_planks
fill 100 65 361 100 66 361 minecraft:stone
setblock 104 65 361 minecraft:stripped_spruce_log
fill 105 65 361 105 67 361 minecraft:stone
fill 116 65 324 133 65 324 minecraft:spruce_planks
fill 116 65 362 133 65 362 minecraft:spruce_planks
fill 118 65 364 124 90 364 minecraft:cobbled_deepslate
fill 121 65 325 121 68 325 minecraft:stone
setblock 124 65 325 minecraft:stone
setblock 124 65 326 minecraft:stripped_spruce_log
setblock 125 65 325 minecraft:stripped_spruce_log
fill 125 65 326 125 68 326 minecraft:stone
fill 125 65 361 125 66 361 minecraft:stone
setblock 125 65 364 minecraft:raw_iron_block
setblock 126 65 322 minecraft:raw_gold_block
fill 126 65 325 126 68 325 minecraft:stone
fill 126 65 364 127 67 364 minecraft:cobbled_deepslate
setblock 129 65 326 minecraft:stripped_spruce_log
setblock 129 65 361 minecraft:stripped_spruce_log
fill 130 65 322 130 107 322 minecraft:cobbled_deepslate
setblock 130 65 325 minecraft:stripped_spruce_log
setblock 130 65 361 minecraft:stone
fill 131 65 325 131 68 325 minecraft:stone
setblock 133 65 325 minecraft:stone
fill 134 65 325 135 65 342 minecraft:spruce_planks
fill 134 65 344 135 65 361 minecraft:spruce_planks
setblock 135 65 324 minecraft:spruce_planks
setblock 135 65 343 minecraft:spruce_planks
setblock 135 65 362 minecraft:spruce_planks
fill 136 65 328 136 66 331 minecraft:cobbled_deepslate
setblock 136 65 332 minecraft:gold_block
setblock 94 66 348 minecraft:raw_iron_block
setblock 95 66 323 minecraft:stone
setblock 95 66 324 minecraft:stripped_spruce_log
fill 95 66 325 95 68 325 minecraft:stone
fill 95 66 341 95 66 343 minecraft:stone
setblock 95 66 344 minecraft:stripped_spruce_log
fill 95 66 345 95 66 348 minecraft:stone
setblock 95 66 349 minecraft:stripped_spruce_log
fill 95 66 350 95 69 350 minecraft:stone
fill 95 66 356 95 66 358 minecraft:stone
setblock 95 66 359 minecraft:stripped_spruce_log
fill 95 66 360 95 66 363 minecraft:stone
setblock 96 66 323 minecraft:stripped_spruce_log
fill 96 66 360 96 66 362 minecraft:stone
setblock 96 66 363 minecraft:stripped_spruce_log
fill 97 66 323 100 66 323 minecraft:stone
setblock 97 66 325 minecraft:light[level=15]
setblock 97 66 332 minecraft:light[level=12]
setblock 97 66 333 minecraft:light[level=15]
setblock 97 66 339 minecraft:light[level=12]
setblock 97 66 341 minecraft:light[level=15]
setblock 97 66 346 minecraft:light[level=12]
setblock 97 66 349 minecraft:light[level=15]
setblock 97 66 353 minecraft:light[level=12]
setblock 97 66 357 minecraft:light[level=15]
setblock 97 66 360 minecraft:light[level=12]
setblock 97 66 362 minecraft:stripped_spruce_log
fill 97 66 363 100 66 363 minecraft:stone
fill 98 66 362 101 66 362 minecraft:stone
setblock 100 66 324 minecraft:stripped_spruce_log
setblock 101 66 323 minecraft:stripped_spruce_log
fill 101 66 324 104 66 324 minecraft:stone
setblock 101 66 363 minecraft:stripped_spruce_log
fill 102 66 323 105 66 323 minecraft:stone
setblock 102 66 362 minecraft:stripped_spruce_log
fill 102 66 363 105 66 363 minecraft:stone
setblock 103 66 361 minecraft:stripped_spruce_log
fill 103 66 362 106 66 362 minecraft:stone
setblock 104 66 325 minecraft:light[level=12]
setblock 104 66 332 minecraft:light[level=12]
setblock 104 66 339 minecraft:light[level=12]
setblock 104 66 346 minecraft:light[level=12]
setblock 104 66 353 minecraft:light[level=12]
setblock 104 66 360 minecraft:light[level=12]
fill 104 66 361 104 67 361 minecraft:stone
setblock 105 66 324 minecraft:stripped_spruce_log
setblock 105 66 325 minecraft:light[level=15]
setblock 105 66 333 minecraft:light[level=15]
setblock 105 66 341 minecraft:light[level=15]
setblock 105 66 349 minecraft:light[level=15]
setblock 105 66 357 minecraft:light[level=15]
setblock 106 66 323 minecraft:stripped_spruce_log
fill 106 66 324 109 66 324 minecraft:stone
setblock 106 66 363 minecraft:stripped_spruce_log
fill 107 66 323 110 66 323 minecraft:stone
setblock 107 66 362 minecraft:stripped_spruce_log
fill 107 66 363 110 66 363 minecraft:stone
fill 108 66 362 110 66 362 minecraft:stone
setblock 110 66 324 minecraft:stripped_spruce_log
setblock 111 66 323 minecraft:stripped_spruce_log
setblock 111 66 325 minecraft:light[level=12]
setblock 111 66 332 minecraft:light[level=12]
setblock 111 66 339 minecraft:light[level=12]
setblock 111 66 346 minecraft:light[level=12]
setblock 111 66 353 minecraft:light[level=12]
setblock 111 66 360 minecraft:light[level=12]
setblock 111 66 363 minecraft:stripped_spruce_log
fill 112 66 323 115 66 323 minecraft:stone
fill 112 66 363 113 66 363 minecraft:stone
setblock 113 66 325 minecraft:light[level=15]
setblock 113 66 333 minecraft:light[level=15]
setblock 113 66 341 minecraft:light[level=15]
setblock 113 66 349 minecraft:light[level=15]
setblock 113 66 357 minecraft:light[level=15]
setblock 116 66 323 minecraft:stripped_spruce_log
fill 117 66 323 120 66 323 minecraft:stone
fill 118 66 324 119 66 324 minecraft:stone
setblock 118 66 325 minecraft:light[level=12]
setblock 118 66 332 minecraft:light[level=12]
setblock 118 66 339 minecraft:light[level=12]
setblock 118 66 346 minecraft:light[level=12]
setblock 118 66 353 minecraft:light[level=12]
setblock 118 66 360 minecraft:light[level=12]
fill 118 66 363 120 66 363 minecraft:stone
setblock 120 66 324 minecraft:stripped_spruce_log
fill 120 66 325 120 69 325 minecraft:stone
setblock 121 66 323 minecraft:stripped_spruce_log
fill 121 66 324 124 66 324 minecraft:stone
setblock 121 66 333 minecraft:light[level=15]
setblock 121 66 341 minecraft:light[level=15]
setblock 121 66 349 minecraft:light[level=15]
setblock 121 66 357 minecraft:light[level=15]
setblock 121 66 362 minecraft:stone
setblock 121 66 363 minecraft:stripped_spruce_log
fill 122 66 323 125 66 323 minecraft:stone
setblock 122 66 362 minecraft:stripped_spruce_log
fill 122 66 363 125 66 363 minecraft:stone
setblock 123 66 326 minecraft:stripped_spruce_log
fill 123 66 362 126 66 362 minecraft:stone
setblock 124 66 325 minecraft:stripped_spruce_log
fill 124 66 326 124 69 326 minecraft:stone
setblock 125 66 324 minecraft:stripped_spruce_log
fill 125 66 325 125 69 325 minecraft:stone
setblock 125 66 332 minecraft:light[level=12]
setblock 125 66 339 minecraft:light[level=12]
setblock 125 66 346 minecraft:light[level=12]
setblock 125 66 353 minecraft:light[level=12]
setblock 125 66 360 minecraft:light[level=12]
fill 125 66 364 125 91 364 minecraft:cobbled_deepslate
fill 126 66 322 126 83 322 minecraft:cobbled_deepslate
setblock 126 66 323 minecraft:stripped_spruce_log
fill 126 66 324 129 66 324 minecraft:stone
fill 126 66 326 127 66 326 minecraft:stone
setblock 126 66 363 minecraft:stripped_spruce_log
fill 127 66 323 130 66 323 minecraft:stone
setblock 127 66 362 minecraft:stripped_spruce_log
fill 127 66 363 130 66 363 minecraft:stone
setblock 128 66 326 minecraft:stripped_spruce_log
setblock 128 66 361 minecraft:stripped_spruce_log
fill 128 66 362 131 66 362 minecraft:stone
setblock 129 66 325 minecraft:stripped_spruce_log
setblock 129 66 326 minecraft:stone
setblock 129 66 333 minecraft:light[level=15]
setblock 129 66 341 minecraft:light[level=15]
setblock 129 66 349 minecraft:light[level=15]
setblock 129 66 357 minecraft:light[level=15]
setblock 129 66 361 minecraft:stone
setblock 130 66 324 minecraft:stripped_spruce_log
fill 130 66 325 130 69 325 minecraft:stone
setblock 131 66 323 minecraft:stripped_spruce_log
fill 131 66 324 134 66 324 minecraft:stone
setblock 131 66 363 minecraft:stripped_spruce_log
fill 132 66 323 135 66 323 minecraft:stone
setblock 132 66 332 minecraft:light[level=12]
setblock 132 66 339 minecraft:light[level=12]
setblock 132 66 346 minecraft:light[level=12]
setblock 132 66 353 minecraft:light[level=12]
setblock 132 66 360 minecraft:light[level=12]
setblock 132 66 362 minecraft:stripped_spruce_log
fill 132 66 363 135 66 363 minecraft:stone
fill 133 66 362 135 67 362 minecraft:stone
setblock 134 66 325 minecraft:stripped_spruce_log
fill 134 66 326 135 67 326 minecraft:stone
fill 134 66 361 135 66 361 minecraft:stone
setblock 135 66 324 minecraft:stripped_spruce_log
fill 135 66 325 135 69 325 minecraft:stone
fill 135 66 327 135 66 328 minecraft:stone
setblock 135 66 344 minecraft:stripped_spruce_log
setblock 135 66 359 minecraft:stripped_spruce_log
fill 135 66 360 135 68 360 minecraft:stone
fill 136 66 332 136 73 332 minecraft:cobbled_deepslate
fill 94 67 348 94 108 348 minecraft:cobbled_deepslate
setblock 95 67 323 minecraft:stripped_spruce_log
fill 95 67 324 95 69 324 minecraft:stone
setblock 95 67 342 minecraft:stone
setblock 95 67 343 minecraft:stripped_spruce_log
fill 95 67 344 95 67 347 minecraft:stone
setblock 95 67 348 minecraft:stripped_spruce_log
fill 95 67 349 95 70 349 minecraft:stone
fill 95 67 351 95 68 351 minecraft:stone
setblock 95 67 358 minecraft:stripped_spruce_log
fill 95 67 359 95 67 362 minecraft:stone
setblock 95 67 363 minecraft:stripped_spruce_log
fill 96 67 323 99 67 323 minecraft:stone
fill 96 67 345 96 67 346 minecraft:stone
setblock 96 67 361 minecraft:stone
setblock 96 67 362 minecraft:stripped_spruce_log
fill 96 67 363 99 67 363 minecraft:stone
fill 97 67 362 100 67 362 minecraft:stone
setblock 100 67 323 minecraft:stripped_spruce_log
fill 100 67 324 103 67 324 minecraft:stone
setblock 100 67 363 minecraft:stripped_spruce_log
fill 101 67 323 104 67 323 minecraft:stone
setblock 101 67 362 minecraft:stripped_spruce_log
fill 101 67 363 104 67 363 minecraft:stone
setblock 102 67 361 minecraft:stripped_spruce_log
fill 102 67 362 105 67 362 minecraft:stone
setblock 103 67 361 minecraft:stone
setblock 104 67 324 minecraft:stripped_spruce_log
setblock 105 67 323 minecraft:stripped_spruce_log
fill 105 67 324 108 67 324 minecraft:stone
setblock 105 67 363 minecraft:stripped_spruce_log
fill 106 67 323 109 67 323 minecraft:stone
setblock 106 67 362 minecraft:stripped_spruce_log
fill 106 67 363 109 67 363 minecraft:stone
fill 107 67 362 108 67 362 minecraft:stone
setblock 109 67 324 minecraft:stripped_spruce_log
setblock 110 67 323 minecraft:stripped_spruce_log
setblock 110 67 324 minecraft:stone
setblock 110 67 363 minecraft:stripped_spruce_log
fill 111 67 323 114 67 323 minecraft:stone
setblock 111 67 363 minecraft:stone
setblock 115 67 323 minecraft:stripped_spruce_log
fill 116 67 323 119 67 323 minecraft:stone
fill 117 67 324 118 67 324 minecraft:stone
fill 118 67 363 119 67 363 minecraft:stone
setblock 119 67 324 minecraft:stripped_spruce_log
setblock 120 67 323 minecraft:stripped_spruce_log
fill 120 67 324 123 67 324 minecraft:stone
setblock 120 67 363 minecraft:stripped_spruce_log
fill 121 67 323 124 67 323 minecraft:stone
fill 121 67 363 124 67 363 minecraft:stone
setblock 122 67 325 minecraft:stone
setblock 122 67 326 minecraft:stripped_spruce_log
fill 122 67 362 125 67 362 minecraft:stone
setblock 123 67 325 minecraft:stripped_spruce_log
fill 123 67 326 123 70 326 minecraft:stone
setblock 124 67 324 minecraft:stripped_spruce_log
fill 124 67 325 124 70 325 minecraft:stone
setblock 125 67 323 minecraft:stripped_spruce_log
fill 125 67 324 128 67 324 minecraft:stone
setblock 125 67 363 minecraft:stripped_spruce_log
fill 126 67 323 129 67 323 minecraft:stone
setblock 126 67 326 minecraft:stone
setblock 126 67 362 minecraft:stripped_spruce_log
fill 126 67 363 129 67 363 minecraft:stone
setblock 127 67 326 minecraft:stripped_spruce_log
fill 127 67 362 130 67 362 minecraft:stone
setblock 128 67 325 minecraft:stripped_spruce_log
fill 128 67 326 128 68 326 minecraft:stone
setblock 129 67 324 minecraft:stripped_spruce_log
fill 129 67 325 129 70 325 minecraft:stone
setblock 130 67 323 minecraft:stripped_spruce_log
fill 130 67 324 133 67 324 minecraft:stone
setblock 130 67 363 minecraft:stripped_spruce_log
fill 131 67 323 134 67 323 minecraft:stone
setblock 131 67 362 minecraft:stripped_spruce_log
fill 131 67 363 134 67 363 minecraft:stone
setblock 132 67 362 minecraft:stone
setblock 134 67 324 minecraft:stripped_spruce_log
fill 134 67 325 134 69 325 minecraft:stone
setblock 135 67 323 minecraft:stripped_spruce_log
fill 135 67 324 135 70 324 minecraft:stone
setblock 135 67 327 minecraft:stone
setblock 135 67 328 minecraft:stripped_spruce_log
setblock 135 67 359 minecraft:stone
fill 135 67 361 135 68 361 minecraft:stone
setblock 135 67 363 minecraft:stripped_spruce_log
fill 136 67 328 136 75 328 minecraft:cobbled_deepslate
setblock 136 67 329 minecraft:raw_gold_block
fill 136 67 330 136 88 331 minecraft:cobbled_deepslate
setblock 94 68 337 minecraft:raw_iron_block
setblock 94 68 356 minecraft:diamond_block
fill 94 68 357 94 89 359 minecraft:cobbled_deepslate
fill 95 68 323 98 68 323 minecraft:stone
fill 95 68 343 95 68 346 minecraft:stone
setblock 95 68 347 minecraft:stripped_spruce_log
fill 95 68 348 96 70 348 minecraft:stone
fill 95 68 359 95 68 361 minecraft:stone
setblock 95 68 362 minecraft:stripped_spruce_log
fill 95 68 363 98 68 363 minecraft:stone
setblock 96 68 345 minecraft:stone
setblock 96 68 346 minecraft:stripped_spruce_log
fill 96 68 347 96 71 347 minecraft:stone
fill 97 68 362 99 68 362 minecraft:stone
setblock 99 68 323 minecraft:stripped_spruce_log
setblock 99 68 363 minecraft:stripped_spruce_log
fill 100 68 323 102 68 324 minecraft:stone
setblock 100 68 362 minecraft:stripped_spruce_log
fill 100 68 363 103 68 363 minecraft:stone
fill 101 68 362 104 68 362 minecraft:stone
setblock 103 68 323 minecraft:stone
setblock 103 68 324 minecraft:stripped_spruce_log
setblock 104 68 323 minecraft:stripped_spruce_log
fill 104 68 324 107 68 324 minecraft:stone
setblock 104 68 363 minecraft:stripped_spruce_log
fill 105 68 323 108 68 323 minecraft:stone
setblock 105 68 362 minecraft:stripped_spruce_log
fill 105 68 363 108 68 363 minecraft:stone
fill 106 68 362 107 68 362 minecraft:stone
setblock 108 68 324 minecraft:stripped_spruce_log
setblock 109 68 323 minecraft:stripped_spruce_log
setblock 109 68 363 minecraft:stripped_spruce_log
fill 110 68 323 113 68 323 minecraft:stone
setblock 110 68 363 minecraft:stone
setblock 114 68 323 minecraft:stripped_spruce_log
fill 115 68 323 118 68 323 minecraft:stone
setblock 117 68 324 minecraft:stone
setblock 118 68 324 minecraft:stripped_spruce_log
setblock 119 68 323 minecraft:stripped_spruce_log
fill 119 68 324 119 70 325 minecraft:stone
setblock 119 68 363 minecraft:stripped_spruce_log
fill 120 68 323 122 68 324 minecraft:stone
fill 120 68 363 123 68 363 minecraft:stone
setblock 122 68 325 minecraft:stripped_spruce_log
fill 122 68 326 122 71 326 minecraft:stone
fill 122 68 362 124 68 362 minecraft:stone
setblock 123 68 323 minecraft:stone
setblock 123 68 324 minecraft:stripped_spruce_log
fill 123 68 325 123 71 325 minecraft:stone
setblock 124 68 323 minecraft:stripped_spruce_log
fill 124 68 324 127 68 324 minecraft:stone
setblock 124 68 363 minecraft:stripped_spruce_log
fill 125 68 323 128 68 323 minecraft:stone
setblock 125 68 362 minecraft:stripped_spruce_log
fill 125 68 363 128 68 363 minecraft:stone
setblock 126 68 326 minecraft:stripped_spruce_log
fill 126 68 362 129 68 362 minecraft:stone
fill 126 68 364 126 104 364 minecraft:cobbled_deepslate
setblock 127 68 325 minecraft:stripped_spruce_log
fill 127 68 326 127 69 326 minecraft:stone
setblock 127 68 364 minecraft:raw_iron_block
setblock 128 68 324 minecraft:stripped_spruce_log
fill 128 68 325 128 71 325 minecraft:stone
setblock 129 68 323 minecraft:stripped_spruce_log
fill 129 68 324 132 68 324 minecraft:stone
setblock 129 68 363 minecraft:stripped_spruce_log
fill 130 68 323 133 68 323 minecraft:stone
setblock 130 68 362 minecraft:stripped_spruce_log
fill 130 68 363 133 68 363 minecraft:stone
setblock 131 68 362 minecraft:stone
setblock 133 68 324 minecraft:stripped_spruce_log
setblock 134 68 323 minecraft:stripped_spruce_log
fill 134 68 324 134 69 324 minecraft:stone
setblock 134 68 363 minecraft:stripped_spruce_log
fill 135 68 323 135 71 323 minecraft:stone
setblock 135 68 326 minecraft:stone
setblock 135 68 327 minecraft:stripped_spruce_log
setblock 135 68 328 minecraft:stone
setblock 135 68 362 minecraft:stripped_spruce_log
fill 135 68 363 135 71 363 minecraft:stone
fill 136 68 329 136 80 329 minecraft:cobbled_deepslate
fill 94 69 337 94 81 337 minecraft:cobbled_deepslate
fill 94 69 356 94 107 356 minecraft:cobbled_deepslate
fill 95 69 322 95 90 322 minecraft:cobbled_deepslate
fill 95 69 323 97 69 323 minecraft:stone
fill 95 69 343 95 69 345 minecraft:stone
setblock 95 69 346 minecraft:stripped_spruce_log
fill 95 69 347 95 72 347 minecraft:stone
setblock 95 69 351 minecraft:stripped_spruce_log
fill 95 69 352 95 72 352 minecraft:stone
setblock 95 69 361 minecraft:stripped_spruce_log
fill 95 69 362 95 69 363 minecraft:stone
setblock 96 69 322 minecraft:raw_iron_block
fill 96 69 346 96 72 346 minecraft:stone
setblock 96 69 349 minecraft:stone
fill 96 69 363 97 69 363 minecraft:stone
fill 97 69 322 97 75 322 minecraft:cobbled_deepslate
setblock 98 69 323 minecraft:stripped_spruce_log
setblock 98 69 363 minecraft:stripped_spruce_log
fill 99 69 323 102 69 323 minecraft:stone
setblock 99 69 362 minecraft:stripped_spruce_log
fill 99 69 363 102 69 363 minecraft:stone
fill 100 69 324 101 69 324 minecraft:stone
fill 100 69 362 103 69 362 minecraft:stone
setblock 102 69 324 minecraft:stripped_spruce_log
setblock 103 69 323 minecraft:stripped_spruce_log
fill 103 69 324 106 69 324 minecraft:stone
fill 103 69 356 104 70 361 minecraft:stripped_spruce_log
setblock 103 69 363 minecraft:stripped_spruce_log
fill 104 69 323 107 69 323 minecraft:stone
fill 104 69 354 104 70 355 minecraft:stripped_spruce_log
fill 104 69 362 104 70 362 minecraft:stripped_spruce_log
fill 104 69 363 107 69 363 minecraft:stone
setblock 105 69 362 minecraft:stone
setblock 107 69 324 minecraft:stripped_spruce_log
setblock 108 69 323 minecraft:stripped_spruce_log
setblock 108 69 363 minecraft:stripped_spruce_log
fill 109 69 323 111 69 323 minecraft:stone
fill 114 69 323 117 69 323 minecraft:stone
setblock 117 69 324 minecraft:stripped_spruce_log
setblock 118 69 323 minecraft:stripped_spruce_log
fill 118 69 324 118 72 324 minecraft:stone
fill 119 69 323 122 69 323 minecraft:stone
fill 119 69 363 122 69 363 minecraft:stone
fill 120 69 324 121 69 324 minecraft:stone
setblock 121 69 325 minecraft:stripped_spruce_log
setblock 122 69 324 minecraft:stripped_spruce_log
fill 122 69 325 122 72 325 minecraft:stone
setblock 123 69 323 minecraft:stripped_spruce_log
fill 123 69 324 126 69 324 minecraft:stone
setblock 123 69 362 minecraft:stone
setblock 123 69 363 minecraft:stripped_spruce_log
fill 124 69 323 127 69 323 minecraft:stone
setblock 124 69 362 minecraft:stripped_spruce_log
fill 124 69 363 127 69 363 minecraft:stone
setblock 125 69 326 minecraft:stripped_spruce_log
fill 125 69 362 128 69 362 minecraft:stone
setblock 126 69 325 minecraft:stripped_spruce_log
fill 126 69 326 126 70 326 minecraft:stone
setblock 127 69 324 minecraft:stripped_spruce_log
fill 127 69 325 127 72 325 minecraft:stone
fill 127 69 364 127 71 364 minecraft:cobbled_deepslate
setblock 128 69 323 minecraft:stripped_spruce_log
fill 128 69 324 131 69 324 minecraft:stone
setblock 128 69 363 minecraft:stripped_spruce_log
fill 129 69 323 132 69 323 minecraft:stone
fill 129 69 363 132 69 363 minecraft:stone
setblock 132 69 324 minecraft:stripped_spruce_log
setblock 133 69 323 minecraft:stripped_spruce_log
fill 133 69 324 133 70 324 minecraft:stone
setblock 133 69 363 minecraft:stripped_spruce_log
fill 134 69 323 134 72 323 minecraft:stone
fill 134 69 363 134 71 363 minecraft:stone
setblock 135 69 326 minecraft:stripped_spruce_log
fill 135 69 327 135 72 327 minecraft:stone
setblock 135 69 361 minecraft:stripped_spruce_log
fill 135 69 362 135 70 362 minecraft:stone
setblock 95 70 344 minecraft:stone
setblock 95 70 345 minecraft:stripped_spruce_log
fill 95 70 346 95 73 346 minecraft:stone
setblock 95 70 350 minecraft:stripped_spruce_log
fill 95 70 351 95 73 351 minecraft:stone
fill 95 70 353 95 71 353 minecraft:stone
fill 95 70 363 96 70 363 minecraft:stone
fill 96 70 322 96 100 322 minecraft:cobbled_deepslate
setblock 96 70 349 minecraft:stripped_spruce_log
fill 96 70 350 96 73 350 minecraft:stone
setblock 97 70 323 minecraft:stripped_spruce_log
fill 97 70 358 97 74 358 minecraft:cobbled_deepslate
setblock 97 70 363 minecraft:stripped_spruce_log
fill 98 70 323 101 70 323 minecraft:stone
fill 98 70 363 101 70 363 minecraft:stone
setblock 101 70 324 minecraft:stripped_spruce_log
setblock 102 70 323 minecraft:stripped_spruce_log
fill 102 70 324 105 70 324 minecraft:stone
setblock 102 70 363 minecraft:stripped_spruce_log
fill 103 70 323 106 70 323 minecraft:stone
fill 103 70 346 103 70 355 minecraft:stripped_spruce_log
setblock 103 70 362 minecraft:stripped_spruce_log
fill 103 70 363 106 70 363 minecraft:stone
fill 104 70 335 104 70 353 minecraft:stripped_spruce_log
setblock 106 70 324 minecraft:stripped_spruce_log
setblock 107 70 323 minecraft:stripped_spruce_log
fill 108 70 323 109 70 323 minecraft:stone
fill 115 70 323 116 70 323 minecraft:stone
setblock 117 70 323 minecraft:stripped_spruce_log
fill 117 70 324 117 73 324 minecraft:stone
fill 118 70 323 121 70 323 minecraft:stone
setblock 120 70 324 minecraft:stone
setblock 120 70 325 minecraft:stripped_spruce_log
fill 120 70 363 121 70 363 minecraft:stone
setblock 121 70 324 minecraft:stripped_spruce_log
fill 121 70 325 121 72 326 minecraft:stone
setblock 122 70 323 minecraft:stripped_spruce_log
fill 122 70 324 125 70 324 minecraft:stone
setblock 122 70 363 minecraft:stripped_spruce_log
fill 123 70 323 126 70 323 minecraft:stone
fill 123 70 363 126 70 363 minecraft:stone
setblock 124 70 326 minecraft:stripped_spruce_log
setblock 125 70 325 minecraft:stripped_spruce_log
fill 125 70 326 125 71 326 minecraft:stone
setblock 125 70 362 minecraft:stone
setblock 126 70 324 minecraft:stripped_spruce_log
fill 126 70 325 126 73 325 minecraft:stone
setblock 127 70 323 minecraft:stripped_spruce_log
fill 127 70 324 130 70 324 minecraft:stone
setblock 127 70 363 minecraft:stripped_spruce_log
fill 128 70 323 131 70 323 minecraft:stone
fill 128 70 363 131 70 363 minecraft:stone
setblock 131 70 324 minecraft:stripped_spruce_log
setblock 132 70 323 minecraft:stripped_spruce_log
setblock 132 70 324 minecraft:stone
setblock 132 70 363 minecraft:stripped_spruce_log
fill 133 70 323 133 73 323 minecraft:stone
setblock 133 70 363 minecraft:stone
setblock 135 70 325 minecraft:stripped_spruce_log
fill 135 70 326 135 73 326 minecraft:stone
setblock 95 71 344 minecraft:stripped_spruce_log
fill 95 71 345 95 74 345 minecraft:stone
setblock 95 71 348 minecraft:stone
setblock 95 71 349 minecraft:stripped_spruce_log
fill 95 71 350 95 74 350 minecraft:stone
setblock 96 71 348 minecraft:stripped_spruce_log
fill 96 71 349 96 74 349 minecraft:stone
fill 96 71 351 96 72 351 minecraft:stone
fill 97 71 323 100 71 323 minecraft:stone
fill 97 71 363 100 71 363 minecraft:stone
fill 99 71 330 99 81 330 minecraft:cobbled_deepslate
setblock 101 71 323 minecraft:stripped_spruce_log
fill 101 71 324 104 71 324 minecraft:stone
setblock 101 71 363 minecraft:stripped_spruce_log
fill 102 71 323 105 71 323 minecraft:stone
fill 102 71 363 105 71 363 minecraft:stone
fill 103 71 357 103 71 362 minecraft:stripped_dark_oak_log
fill 104 71 325 104 71 351 minecraft:stripped_spruce_log
fill 104 71 352 104 71 358 minecraft:stripped_dark_oak_log
fill 105 71 324 105 71 341 minecraft:stripped_spruce_log
setblock 106 71 323 minecraft:stripped_spruce_log
setblock 107 71 323 minecraft:stone
setblock 111 71 322 minecraft:diamond_block
fill 112 71 322 114 72 322 minecraft:cobbled_deepslate
setblock 115 71 323 minecraft:stone
setblock 116 71 323 minecraft:stripped_spruce_log
fill 117 71 323 120 71 323 minecraft:stone
setblock 119 71 324 minecraft:stone
setblock 119 71 325 minecraft:stripped_spruce_log
setblock 120 71 324 minecraft:stripped_spruce_log
fill 120 71 325 120 74 325 minecraft:stone
setblock 120 71 363 minecraft:stone
setblock 121 71 323 minecraft:stripped_spruce_log
fill 121 71 324 124 71 324 minecraft:stone
setblock 121 71 363 minecraft:stripped_spruce_log
fill 122 71 323 125 71 323 minecraft:stone
fill 122 71 363 125 71 363 minecraft:stone
setblock 123 71 326 minecraft:stripped_spruce_log
setblock 124 71 325 minecraft:stripped_spruce_log
fill 124 71 326 124 73 326 minecraft:stone
setblock 125 71 324 minecraft:stripped_spruce_log
fill 125 71 325 125 74 325 minecraft:stone
setblock 126 71 323 minecraft:stripped_spruce_log
fill 126 71 324 129 71 324 minecraft:stone
setblock 126 71 363 minecraft:stripped_spruce_log
fill 127 71 323 130 71 323 minecraft:stone
fill 127 71 363 130 71 363 minecraft:stone
setblock 130 71 324 minecraft:stripped_spruce_log
setblock 131 71 323 minecraft:stripped_spruce_log
setblock 131 71 324 minecraft:stone
setblock 131 71 363 minecraft:stripped_spruce_log
fill 132 71 323 132 74 323 minecraft:stone
setblock 135 71 324 minecraft:stripped_spruce_log
fill 135 71 325 135 74 325 minecraft:stone
fill 95 72 344 95 75 344 minecraft:stone
setblock 95 72 348 minecraft:stripped_spruce_log
fill 95 72 349 95 75 349 minecraft:stone
setblock 95 72 353 minecraft:stripped_spruce_log
fill 95 72 354 95 75 354 minecraft:stone
setblock 96 72 347 minecraft:stripped_spruce_log
fill 96 72 348 97 74 348 minecraft:stone
setblock 96 72 352 minecraft:stripped_spruce_log
setblock 97 72 325 minecraft:light[level=12]
setblock 97 72 332 minecraft:light[level=12]
setblock 97 72 339 minecraft:light[level=12]
setblock 97 72 346 minecraft:light[level=12]
fill 97 72 349 97 73 349 minecraft:stone
setblock 97 72 353 minecraft:light[level=12]
setblock 97 72 360 minecraft:light[level=12]
fill 98 72 323 99 72 323 minecraft:stone
fill 98 72 363 99 72 363 minecraft:stone
setblock 100 72 323 minecraft:stripped_spruce_log
setblock 100 72 363 minecraft:stripped_spruce_log
fill 101 72 323 104 72 323 minecraft:stone
fill 101 72 363 103 72 363 minecraft:stone
fill 104 72 324 105 72 328 minecraft:stripped_spruce_log
setblock 104 72 332 minecraft:light[level=12]
fill 104 72 334 104 72 350 minecraft:stripped_dark_oak_log
setblock 104 72 353 minecraft:light[level=12]
setblock 104 72 360 minecraft:light[level=12]
setblock 105 72 323 minecraft:stripped_spruce_log
fill 105 72 329 105 72 330 minecraft:stripped_spruce_log
setblock 106 72 323 minecraft:stone
fill 111 72 322 111 103 322 minecraft:cobbled_deepslate
setblock 111 72 325 minecraft:light[level=12]
setblock 111 72 332 minecraft:light[level=12]
setblock 111 72 339 minecraft:light[level=12]
setblock 111 72 346 minecraft:light[level=12]
setblock 111 72 353 minecraft:light[level=12]
setblock 111 72 360 minecraft:light[level=12]
fill 112 72 364 112 107 364 minecraft:cobbled_deepslate
setblock 113 72 364 minecraft:raw_iron_block
fill 114 72 364 114 103 364 minecraft:cobbled_deepslate
setblock 115 72 323 minecraft:stripped_spruce_log
fill 116 72 323 119 72 323 minecraft:stone
setblock 118 72 325 minecraft:stripped_spruce_log
setblock 118 72 332 minecraft:light[level=12]
setblock 118 72 339 minecraft:light[level=12]
setblock 118 72 346 minecraft:light[level=12]
setblock 118 72 353 minecraft:light[level=12]
setblock 118 72 360 minecraft:light[level=12]
setblock 119 72 324 minecraft:stripped_spruce_log
fill 119 72 325 119 75 325 minecraft:stone
setblock 120 72 323 minecraft:stripped_spruce_log
fill 120 72 324 123 72 324 minecraft:stone
setblock 120 72 363 minecraft:stripped_spruce_log
fill 121 72 323 124 72 323 minecraft:stone
fill 121 72 363 124 72 363 minecraft:stone
setblock 122 72 326 minecraft:stripped_spruce_log
setblock 123 72 325 minecraft:stripped_spruce_log
fill 123 72 326 123 75 326 minecraft:stone
setblock 124 72 324 minecraft:stripped_spruce_log
fill 124 72 325 124 75 325 minecraft:stone
setblock 125 72 323 minecraft:stripped_spruce_log
fill 125 72 324 128 72 324 minecraft:stone
setblock 125 72 332 minecraft:light[level=12]
setblock 125 72 339 minecraft:light[level=12]
setblock 125 72 346 minecraft:light[level=12]
setblock 125 72 353 minecraft:light[level=12]
setblock 125 72 360 minecraft:light[level=12]
setblock 125 72 363 minecraft:stripped_spruce_log
fill 126 72 323 129 72 323 minecraft:stone
fill 126 72 363 128 72 363 minecraft:stone
setblock 127 72 364 minecraft:diamond_block
setblock 129 72 324 minecraft:stripped_spruce_log
setblock 130 72 323 minecraft:stripped_spruce_log
setblock 130 72 324 minecraft:stone
fill 131 72 323 131 75 323 minecraft:stone
setblock 132 72 325 minecraft:light[level=12]
setblock 132 72 332 minecraft:light[level=12]
setblock 132 72 339 minecraft:light[level=12]
setblock 132 72 346 minecraft:light[level=12]
setblock 132 72 353 minecraft:light[level=12]
setblock 132 72 360 minecraft:light[level=12]
setblock 135 72 323 minecraft:stripped_spruce_log
fill 135 72 324 135 75 324 minecraft:stone
setblock 135 72 328 minecraft:stripped_spruce_log
fill 135 72 349 135 74 350 minecraft:stone
setblock 135 72 363 minecraft:stripped_spruce_log
setblock 95 73 347 minecraft:stripped_spruce_log
fill 95 73 348 95 76 348 minecraft:stone
setblock 95 73 352 minecraft:stripped_spruce_log
fill 95 73 353 96 75 353 minecraft:stone
fill 95 73 355 95 73 356 minecraft:stone
fill 95 73 364 95 107 364 minecraft:cobbled_deepslate
setblock 96 73 345 minecraft:stone
setblock 96 73 346 minecraft:stripped_spruce_log
fill 96 73 347 97 75 347 minecraft:stone
setblock 96 73 351 minecraft:stripped_spruce_log
fill 96 73 352 96 76 352 minecraft:stone
fill 96 73 354 96 74 354 minecraft:stone
fill 96 73 358 96 74 358 minecraft:cobbled_deepslate
setblock 96 73 364 minecraft:raw_gold_block
setblock 97 73 350 minecraft:stripped_spruce_log
fill 97 73 351 97 76 351 minecraft:stone
fill 97 73 357 97 74 357 minecraft:cobbled_deepslate
fill 97 73 359 97 74 359 minecraft:cobbled_deepslate
fill 97 73 364 98 80 364 minecraft:cobbled_deepslate
setblock 98 73 323 minecraft:stone
fill 98 73 358 98 74 358 minecraft:cobbled_deepslate
setblock 98 73 363 minecraft:stone
setblock 99 73 323 minecraft:stripped_spruce_log
setblock 99 73 363 minecraft:stripped_spruce_log
fill 100 73 323 103 73 323 minecraft:stone
fill 100 73 363 102 73 363 minecraft:stone
setblock 104 73 323 minecraft:stripped_spruce_log
setblock 105 73 323 minecraft:stone
fill 105 73 324 105 73 328 minecraft:stripped_dark_oak_log
fill 112 73 322 113 96 322 minecraft:cobbled_deepslate
fill 113 73 364 113 108 364 minecraft:cobbled_deepslate
setblock 114 73 322 minecraft:diamond_block
fill 115 73 323 118 73 323 minecraft:stone
setblock 115 73 364 minecraft:raw_gold_block
fill 116 73 324 116 74 324 minecraft:stone
setblock 118 73 324 minecraft:stripped_spruce_log
fill 118 73 325 118 76 325 minecraft:stone
setblock 119 73 323 minecraft:stripped_spruce_log
fill 119 73 324 122 73 324 minecraft:stone
fill 120 73 323 123 73 323 minecraft:stone
setblock 120 73 326 minecraft:stone
fill 120 73 363 123 73 363 minecraft:stone
setblock 121 73 325 minecraft:stone
setblock 121 73 326 minecraft:stripped_spruce_log
setblock 122 73 325 minecraft:stripped_spruce_log
fill 122 73 326 122 76 326 minecraft:stone
setblock 123 73 324 minecraft:stripped_spruce_log
fill 123 73 325 123 76 325 minecraft:stone
setblock 124 73 323 minecraft:stripped_spruce_log
fill 124 73 324 127 73 324 minecraft:stone
setblock 124 73 363 minecraft:stripped_spruce_log
fill 125 73 323 128 73 323 minecraft:stone
fill 125 73 363 127 73 363 minecraft:stone
fill 127 73 364 127 107 364 minecraft:cobbled_deepslate
setblock 128 73 324 minecraft:stripped_spruce_log
setblock 129 73 323 minecraft:stripped_spruce_log
setblock 129 73 324 minecraft:stone
fill 130 73 323 130 76 323 minecraft:stone
setblock 134 73 323 minecraft:stripped_spruce_log
fill 135 73 323 135 76 323 minecraft:stone
setblock 135 73 327 minecraft:stripped_spruce_log
fill 135 73 328 135 76 328 minecraft:stone
setblock 135 73 347 minecraft:stripped_spruce_log
fill 135 73 348 135 76 348 minecraft:stone
setblock 135 73 351 minecraft:stone
setblock 135 73 352 minecraft:stripped_spruce_log
fill 135 73 353 135 76 353 minecraft:stone
fill 135 73 363 135 76 363 minecraft:stone
setblock 95 74 346 minecraft:stripped_spruce_log
fill 95 74 347 95 77 347 minecraft:stone
setblock 95 74 351 minecraft:stripped_spruce_log
fill 95 74 352 95 77 352 minecraft:stone
setblock 95 74 355 minecraft:stone
setblock 95 74 356 minecraft:stripped_spruce_log
fill 95 74 357 95 77 357 minecraft:stone
setblock 96 74 345 minecraft:stripped_spruce_log
fill 96 74 346 97 76 346 minecraft:stone
setblock 96 74 350 minecraft:stripped_spruce_log
fill 96 74 351 96 77 351 minecraft:stone
setblock 96 74 355 minecraft:stripped_spruce_log
setblock 96 74 357 minecraft:cobbled_deepslate
setblock 96 74 359 minecraft:cobbled_deepslate
fill 96 74 364 96 107 364 minecraft:cobbled_deepslate
setblock 97 74 325 minecraft:light[level=15]
setblock 97 74 333 minecraft:light[level=15]
setblock 97 74 341 minecraft:light[level=15]
setblock 97 74 349 minecraft:stripped_spruce_log
fill 97 74 350 98 76 350 minecraft:stone
fill 97 74 352 97 74 353 minecraft:stone
setblock 98 74 323 minecraft:stripped_spruce_log
fill 98 74 349 98 77 349 minecraft:stone
setblock 98 74 357 minecraft:cobbled_deepslate
setblock 98 74 359 minecraft:cobbled_deepslate
setblock 98 74 363 minecraft:stripped_spruce_log
fill 99 74 323 102 74 323 minecraft:stone
fill 99 74 363 101 75 363 minecraft:stone
setblock 103 74 323 minecraft:stripped_spruce_log
setblock 104 74 323 minecraft:stone
setblock 105 74 325 minecraft:light[level=15]
setblock 105 74 333 minecraft:light[level=15]
setblock 105 74 341 minecraft:light[level=15]
setblock 105 74 349 minecraft:light[level=15]
setblock 105 74 357 minecraft:light[level=15]
setblock 110 74 322 minecraft:raw_gold_block
setblock 113 74 325 minecraft:light[level=15]
setblock 113 74 333 minecraft:light[level=15]
setblock 113 74 341 minecraft:light[level=15]
setblock 113 74 349 minecraft:light[level=15]
setblock 113 74 357 minecraft:light[level=15]
fill 114 74 322 114 93 322 minecraft:cobbled_deepslate
fill 115 74 323 117 74 323 minecraft:stone
fill 115 74 364 115 105 364 minecraft:cobbled_deepslate
setblock 117 74 324 minecraft:stripped_spruce_log
fill 117 74 325 117 77 325 minecraft:stone
setblock 118 74 323 minecraft:stripped_spruce_log
fill 118 74 324 121 74 324 minecraft:stone
fill 119 74 323 122 74 323 minecraft:stone
setblock 119 74 326 minecraft:stone
fill 119 74 363 122 74 363 minecraft:stone
setblock 120 74 326 minecraft:stripped_spruce_log
setblock 121 74 325 minecraft:stripped_spruce_log
fill 121 74 326 121 77 326 minecraft:stone
setblock 121 74 333 minecraft:light[level=15]
setblock 121 74 341 minecraft:light[level=15]
setblock 121 74 349 minecraft:light[level=15]
setblock 121 74 357 minecraft:light[level=15]
setblock 122 74 324 minecraft:stripped_spruce_log
fill 122 74 325 122 77 325 minecraft:stone
setblock 123 74 323 minecraft:stripped_spruce_log
fill 123 74 324 126 74 324 minecraft:stone
setblock 123 74 363 minecraft:stripped_spruce_log
fill 124 74 323 127 74 323 minecraft:stone
fill 124 74 363 126 75 363 minecraft:stone
setblock 126 74 325 minecraft:stripped_spruce_log
setblock 127 74 324 minecraft:stripped_spruce_log
setblock 128 74 323 minecraft:stripped_spruce_log
setblock 128 74 324 minecraft:stone
fill 129 74 323 129 77 323 minecraft:stone
setblock 129 74 325 minecraft:light[level=15]
setblock 129 74 333 minecraft:light[level=15]
setblock 129 74 341 minecraft:light[level=15]
setblock 129 74 349 minecraft:light[level=15]
setblock 129 74 357 minecraft:light[level=15]
setblock 133 74 323 minecraft:stripped_spruce_log
fill 134 74 323 134 77 323 minecraft:stone
setblock 135 74 326 minecraft:stripped_spruce_log
fill 135 74 327 135 77 327 minecraft:stone
fill 135 74 329 135 75 329 minecraft:stone
fill 135 74 347 135 77 347 minecraft:stone
setblock 135 74 351 minecraft:stripped_spruce_log
fill 135 74 352 135 77 352 minecraft:stone
fill 135 74 354 135 74 355 minecraft:stone
setblock 135 74 356 minecraft:stripped_spruce_log
setblock 136 74 332 minecraft:raw_iron_block
fill 94 75 350 94 100 351 minecraft:cobbled_deepslate
setblock 94 75 352 minecraft:raw_iron_block
fill 94 75 353 94 80 354 minecraft:cobbled_deepslate
fill 95 75 326 95 75 329 minecraft:stone
setblock 95 75 330 minecraft:stripped_spruce_log
fill 95 75 331 95 78 331 minecraft:stone
fill 95 75 343 95 76 343 minecraft:stone
setblock 95 75 345 minecraft:stripped_spruce_log
fill 95 75 346 95 78 346 minecraft:stone
setblock 95 75 350 minecraft:stripped_spruce_log
fill 95 75 351 95 78 351 minecraft:stone
setblock 95 75 355 minecraft:stripped_spruce_log
fill 95 75 356 96 77 356 minecraft:stone
fill 95 75 358 95 75 359 minecraft:stone
fill 96 75 324 96 78 324 minecraft:spruce_log
fill 96 75 343 96 78 343 minecraft:spruce_log
setblock 96 75 344 minecraft:stripped_spruce_log
fill 96 75 345 96 78 345 minecraft:stone
setblock 96 75 348 minecraft:stone
setblock 96 75 349 minecraft:stripped_spruce_log
fill 96 75 350 96 78 350 minecraft:stone
setblock 96 75 354 minecraft:stripped_spruce_log
fill 96 75 355 97 77 355 minecraft:stone
fill 96 75 360 96 76 361 minecraft:iron_bars
fill 96 75 362 96 78 362 minecraft:spruce_log
setblock 97 75 323 minecraft:stripped_spruce_log
setblock 97 75 348 minecraft:stripped_spruce_log
fill 97 75 349 97 78 349 minecraft:stone
setblock 97 75 352 minecraft:stone
setblock 97 75 353 minecraft:stripped_spruce_log
fill 97 75 354 97 78 354 minecraft:stone
setblock 97 75 363 minecraft:stripped_spruce_log
fill 98 75 323 101 75 323 minecraft:stone
fill 98 75 348 98 78 348 minecraft:stone
setblock 98 75 351 minecraft:stone
setblock 98 75 352 minecraft:stripped_spruce_log
fill 98 75 363 98 78 363 minecraft:stone
setblock 102 75 323 minecraft:stripped_spruce_log
fill 103 75 323 103 76 323 minecraft:stone
fill 110 75 322 110 107 322 minecraft:cobbled_deepslate
fill 114 75 323 116 75 323 minecraft:stone
fill 115 75 324 115 78 324 minecraft:spruce_log
fill 115 75 362 115 78 362 minecraft:spruce_log
setblock 116 75 324 minecraft:stripped_spruce_log
setblock 117 75 323 minecraft:stripped_spruce_log
fill 117 75 324 120 75 324 minecraft:stone
fill 118 75 323 121 75 323 minecraft:stone
setblock 118 75 326 minecraft:stone
setblock 119 75 326 minecraft:stripped_spruce_log
fill 119 75 363 121 75 363 minecraft:stone
setblock 120 75 325 minecraft:stripped_spruce_log
fill 120 75 326 120 78 326 minecraft:stone
setblock 121 75 324 minecraft:stripped_spruce_log
fill 121 75 325 121 78 325 minecraft:stone
setblock 122 75 323 minecraft:stripped_spruce_log
fill 122 75 324 125 75 324 minecraft:stone
setblock 122 75 363 minecraft:stripped_spruce_log
fill 123 75 323 126 75 323 minecraft:stone
fill 123 75 363 123 78 363 minecraft:stone
setblock 125 75 325 minecraft:stripped_spruce_log
setblock 126 75 324 minecraft:stripped_spruce_log
setblock 127 75 323 minecraft:stripped_spruce_log
fill 127 75 324 127 76 324 minecraft:stone
fill 128 75 323 128 78 323 minecraft:stone
setblock 132 75 323 minecraft:stripped_spruce_log
fill 133 75 323 133 78 323 minecraft:stone
fill 134 75 324 134 78 324 minecraft:spruce_log
fill 134 75 343 134 78 343 minecraft:spruce_log
setblock 134 75 351 minecraft:stripped_spruce_log
fill 134 75 352 134 78 352 minecraft:stone
fill 134 75 362 134 78 362 minecraft:spruce_log
fill 134 75 363 134 77 363 minecraft:stone
setblock 135 75 325 minecraft:stripped_spruce_log
fill 135 75 326 135 78 326 minecraft:stone
setblock 135 75 330 minecraft:stripped_spruce_log
fill 135 75 331 135 78 331 minecraft:stone
fill 135 75 346 135 78 346 minecraft:stone
setblock 135 75 349 minecraft:stone
setblock 135 75 350 minecraft:stripped_spruce_log
fill 135 75 351 135 78 351 minecraft:stone
setblock 135 75 354 minecraft:stone
setblock 135 75 355 minecraft:stripped_spruce_log
fill 135 75 356 135 75 359 minecraft:stone
setblock 135 75 360 minecraft:stripped_spruce_log
fill 135 75 361 135 77 362 minecraft:stone
fill 136 75 332 136 90 332 minecraft:cobbled_deepslate
fill 136 75 334 136 108 334 minecraft:cobbled_deepslate
setblock 136 75 335 minecraft:gold_block
fill 136 75 336 136 77 349 minecraft:cobbled_deepslate
setblock 94 76 338 minecraft:raw_iron_block
fill 94 76 352 94 107 352 minecraft:cobbled_deepslate
fill 95 76 325 95 76 328 minecraft:stone
setblock 95 76 329 minecraft:stripped_spruce_log
fill 95 76 330 96 78 330 minecraft:stone
fill 95 76 332 95 76 333 minecraft:stone
setblock 95 76 334 minecraft:stripped_spruce_log
fill 95 76 342 95 77 342 minecraft:stone
setblock 95 76 344 minecraft:stripped_spruce_log
fill 95 76 345 95 79 345 minecraft:stone
setblock 95 76 349 minecraft:stripped_spruce_log
fill 95 76 350 95 79 350 minecraft:stone
setblock 95 76 353 minecraft:stone
setblock 95 76 354 minecraft:stripped_spruce_log
fill 95 76 355 95 79 355 minecraft:stone
setblock 95 76 358 minecraft:stone
setblock 95 76 359 minecraft:stripped_spruce_log
fill 95 76 360 95 78 361 minecraft:stone
setblock 96 76 328 minecraft:stripped_spruce_log
fill 96 76 329 96 79 329 minecraft:stone
fill 96 76 331 96 77 331 minecraft:stone
fill 96 76 344 96 79 344 minecraft:stone
setblock 96 76 347 minecraft:stone
setblock 96 76 348 minecraft:stripped_spruce_log
fill 96 76 349 96 79 349 minecraft:stone
setblock 96 76 353 minecraft:stripped_spruce_log
fill 96 76 354 96 79 354 minecraft:stone
setblock 96 76 357 minecraft:stone
setblock 96 76 358 minecraft:stripped_spruce_log
setblock 96 76 363 minecraft:stripped_spruce_log
setblock 97 76 322 minecraft:gold_block
fill 97 76 323 100 76 323 minecraft:stone
fill 97 76 345 97 77 345 minecraft:stone
setblock 97 76 347 minecraft:stripped_spruce_log
fill 97 76 348 97 79 348 minecraft:stone
setblock 97 76 352 minecraft:stripped_spruce_log
fill 97 76 353 98 78 353 minecraft:stone
setblock 97 76 356 minecraft:stone
fill 97 76 363 97 79 363 minecraft:stone
fill 98 76 330 98 81 330 minecraft:cobbled_deepslate
fill 98 76 347 98 79 347 minecraft:stone
setblock 98 76 351 minecraft:stripped_spruce_log
fill 98 76 352 98 79 352 minecraft:stone
fill 98 76 354 98 77 354 minecraft:stone
fill 99 76 331 99 81 331 minecraft:cobbled_deepslate
fill 99 76 363 100 76 363 minecraft:stone
setblock 99 76 364 minecraft:diamond_block
fill 100 76 330 100 81 330 minecraft:cobbled_deepslate
setblock 101 76 323 minecraft:stripped_spruce_log
fill 102 76 323 102 78 323 minecraft:stone
fill 114 76 323 115 76 323 minecraft:stone
setblock 116 76 323 minecraft:stripped_spruce_log
fill 116 76 324 116 78 325 minecraft:stone
fill 117 76 323 119 76 324 minecraft:stone
setblock 118 76 326 minecraft:stripped_spruce_log
fill 118 76 363 120 76 363 minecraft:stone
setblock 119 76 325 minecraft:stripped_spruce_log
fill 119 76 326 119 79 326 minecraft:stone
setblock 120 76 323 minecraft:stone
setblock 120 76 324 minecraft:stripped_spruce_log
fill 120 76 325 120 79 325 minecraft:stone
setblock 121 76 323 minecraft:stripped_spruce_log
fill 121 76 324 124 76 324 minecraft:stone
setblock 121 76 363 minecraft:stripped_spruce_log
fill 122 76 323 125 76 323 minecraft:stone
fill 122 76 363 122 79 363 minecraft:stone
setblock 123 76 326 minecraft:stripped_spruce_log
setblock 124 76 325 minecraft:stripped_spruce_log
fill 124 76 363 125 76 363 minecraft:stone
setblock 125 76 324 minecraft:stripped_spruce_log
setblock 125 76 325 minecraft:stone
setblock 126 76 323 minecraft:stripped_spruce_log
fill 126 76 324 126 77 324 minecraft:stone
setblock 126 76 363 minecraft:stripped_spruce_log
fill 127 76 323 127 79 323 minecraft:stone
setblock 131 76 323 minecraft:stripped_spruce_log
fill 132 76 323 132 79 323 minecraft:stone
setblock 133 76 322 minecraft:raw_gold_block
fill 133 76 363 133 78 363 minecraft:stone
fill 134 76 322 134 107 322 minecraft:cobbled_deepslate
setblock 134 76 349 minecraft:stone
setblock 134 76 350 minecraft:stripped_spruce_log
fill 134 76 351 134 79 351 minecraft:stone
fill 134 76 353 134 76 354 minecraft:stone
setblock 134 76 355 minecraft:stripped_spruce_log
fill 134 76 356 135 78 356 minecraft:stone
setblock 135 76 324 minecraft:stripped_spruce_log
fill 135 76 325 135 79 325 minecraft:stone
setblock 135 76 329 minecraft:stripped_spruce_log
fill 135 76 330 135 79 330 minecraft:stone
fill 135 76 332 135 77 332 minecraft:stone
fill 135 76 345 135 79 345 minecraft:stone
setblock 135 76 349 minecraft:stripped_spruce_log
fill 135 76 350 135 79 350 minecraft:stone
setblock 135 76 354 minecraft:stripped_spruce_log
fill 135 76 355 135 79 355 minecraft:stone
fill 135 76 357 135 76 358 minecraft:stone
setblock 135 76 359 minecraft:stripped_spruce_log
fill 135 76 360 135 79 360 minecraft:stone
setblock 136 76 328 minecraft:raw_iron_block
fill 136 76 335 136 107 335 minecraft:cobbled_deepslate
fill 94 77 338 94 107 338 minecraft:cobbled_deepslate
fill 95 77 324 95 77 327 minecraft:stone
setblock 95 77 328 minecraft:stripped_spruce_log
fill 95 77 329 95 80 329 minecraft:stone
setblock 95 77 332 minecraft:stone
setblock 95 77 333 minecraft:stripped_spruce_log
fill 95 77 334 95 77 337 minecraft:stone
setblock 95 77 338 minecraft:stripped_spruce_log
fill 95 77 339 95 78 341 minecraft:stone
setblock 95 77 343 minecraft:stripped_spruce_log
fill 95 77 344 95 80 344 minecraft:stone
setblock 95 77 348 minecraft:stripped_spruce_log
fill 95 77 349 95 80 349 minecraft:stone
setblock 95 77 353 minecraft:stripped_spruce_log
fill 95 77 354 95 80 354 minecraft:stone
setblock 95 77 358 minecraft:stripped_spruce_log
fill 95 77 359 96 79 359 minecraft:stone
setblock 95 77 362 minecraft:stone
setblock 95 77 363 minecraft:stripped_spruce_log
fill 96 77 323 99 77 323 minecraft:stone
setblock 96 77 327 minecraft:stripped_spruce_log
fill 96 77 328 96 80 328 minecraft:stone
setblock 96 77 332 minecraft:stripped_spruce_log
fill 96 77 333 96 78 335 minecraft:stone
setblock 96 77 346 minecraft:stone
setblock 96 77 347 minecraft:stripped_spruce_log
fill 96 77 348 96 80 348 minecraft:stone
setblock 96 77 352 minecraft:stripped_spruce_log
fill 96 77 353 96 80 353 minecraft:stone
setblock 96 77 357 minecraft:stripped_spruce_log
fill 96 77 358 96 80 358 minecraft:stone
fill 96 77 363 96 80 363 minecraft:stone
fill 97 77 322 97 104 322 minecraft:cobbled_deepslate
setblock 97 77 346 minecraft:stripped_spruce_log
fill 97 77 347 97 80 347 minecraft:stone
setblock 97 77 350 minecraft:stone
setblock 97 77 351 minecraft:stripped_spruce_log
fill 97 77 352 97 80 352 minecraft:stone
setblock 97 77 356 minecraft:stripped_spruce_log
fill 97 77 357 97 80 357 minecraft:stone
setblock 98 77 350 minecraft:stripped_spruce_log
fill 98 77 351 99 78 351 minecraft:stone
setblock 98 77 355 minecraft:stripped_spruce_log
fill 99 77 329 99 81 329 minecraft:cobbled_deepslate
fill 99 77 350 99 78 350 minecraft:stone
setblock 99 77 363 minecraft:stone
fill 99 77 364 99 103 364 minecraft:cobbled_deepslate
setblock 100 77 323 minecraft:stripped_spruce_log
setblock 100 77 363 minecraft:stripped_spruce_log
fill 101 77 323 101 79 323 minecraft:stone
fill 113 77 323 114 77 323 minecraft:stone
setblock 114 77 324 minecraft:stripped_spruce_log
setblock 115 77 323 minecraft:stripped_spruce_log
fill 115 77 325 115 79 325 minecraft:stone
fill 116 77 323 119 77 323 minecraft:stone
fill 117 77 324 118 77 324 minecraft:stone
setblock 117 77 326 minecraft:stripped_spruce_log
fill 117 77 363 119 77 363 minecraft:stone
setblock 118 77 325 minecraft:stripped_spruce_log
fill 118 77 326 118 80 326 minecraft:stone
setblock 119 77 324 minecraft:stripped_spruce_log
fill 119 77 325 119 80 325 minecraft:stone
setblock 120 77 323 minecraft:stripped_spruce_log
fill 120 77 324 123 77 324 minecraft:stone
setblock 120 77 363 minecraft:stripped_spruce_log
fill 121 77 323 124 77 323 minecraft:stone
fill 121 77 363 121 80 363 minecraft:stone
setblock 122 77 326 minecraft:stripped_spruce_log
setblock 123 77 325 minecraft:stripped_spruce_log
setblock 124 77 324 minecraft:stripped_spruce_log
fill 124 77 325 124 78 325 minecraft:stone
setblock 124 77 363 minecraft:stone
setblock 125 77 323 minecraft:stripped_spruce_log
fill 125 77 324 125 79 324 minecraft:stone
setblock 125 77 363 minecraft:stripped_spruce_log
fill 126 77 323 126 80 323 minecraft:stone
fill 126 77 363 126 80 363 minecraft:stone
setblock 130 77 323 minecraft:stripped_spruce_log
setblock 131 77 323 minecraft:stone
fill 132 77 363 132 79 363 minecraft:stone
fill 133 77 322 133 104 322 minecraft:cobbled_deepslate
setblock 134 77 328 minecraft:stone
setblock 134 77 329 minecraft:stripped_spruce_log
setblock 134 77 348 minecraft:stone
setblock 134 77 349 minecraft:stripped_spruce_log
fill 134 77 350 134 80 350 minecraft:stone
setblock 134 77 353 minecraft:stone
setblock 134 77 354 minecraft:stripped_spruce_log
fill 134 77 355 134 80 355 minecraft:stone
fill 134 77 357 134 77 358 minecraft:stone
setblock 134 77 359 minecraft:stripped_spruce_log
setblock 135 77 323 minecraft:stripped_spruce_log
fill 135 77 324 135 80 324 minecraft:stone
setblock 135 77 328 minecraft:stripped_spruce_log
fill 135 77 329 135 80 329 minecraft:stone
setblock 135 77 333 minecraft:stripped_spruce_log
fill 135 77 334 135 80 334 minecraft:stone
setblock 135 77 348 minecraft:stripped_spruce_log
fill 135 77 349 135 80 349 minecraft:stone
setblock 135 77 353 minecraft:stripped_spruce_log
fill 135 77 354 135 80 354 minecraft:stone
setblock 135 77 357 minecraft:stone
setblock 135 77 358 minecraft:stripped_spruce_log
fill 135 77 359 135 80 359 minecraft:stone
setblock 135 77 363 minecraft:stripped_spruce_log
fill 136 77 328 136 107 328 minecraft:cobbled_deepslate
fill 95 78 324 95 78 326 minecraft:stone
setblock 95 78 327 minecraft:stripped_spruce_log
fill 95 78 328 95 80 328 minecraft:stone
setblock 95 78 332 minecraft:stripped_spruce_log
fill 95 78 333 95 78 336 minecraft:stone
setblock 95 78 337 minecraft:stripped_spruce_log
fill 95 78 338 96 80 338 minecraft:stone
setblock 95 78 342 minecraft:stripped_spruce_log
fill 95 78 343 95 80 343 minecraft:stone
setblock 95 78 347 minecraft:stripped_spruce_log
fill 95 78 348 95 80 348 minecraft:stone
setblock 95 78 352 minecraft:stripped_spruce_log
fill 95 78 353 95 80 353 minecraft:stone
setblock 95 78 356 minecraft:stone
setblock 95 78 357 minecraft:stripped_spruce_log
fill 95 78 358 95 80 358 minecraft:stone
setblock 95 78 362 minecraft:stripped_spruce_log
fill 95 78 363 95 80 363 minecraft:stone
fill 96 78 323 98 78 323 minecraft:stone
fill 96 78 327 96 80 327 minecraft:stone
setblock 96 78 331 minecraft:stripped_spruce_log
fill 96 78 332 97 80 332 minecraft:stone
setblock 96 78 336 minecraft:stripped_spruce_log
fill 96 78 337 96 80 337 minecraft:stone
fill 96 78 339 96 78 340 minecraft:stone
setblock 96 78 341 minecraft:stripped_spruce_log
fill 96 78 342 96 80 342 minecraft:stone
setblock 96 78 346 minecraft:stripped_spruce_log
fill 96 78 347 96 80 347 minecraft:stone
setblock 96 78 351 minecraft:stripped_spruce_log
fill 96 78 352 96 80 352 minecraft:stone
setblock 96 78 355 minecraft:stone
setblock 96 78 356 minecraft:stripped_spruce_log
fill 96 78 357 96 80 357 minecraft:stone
setblock 96 78 360 minecraft:stone
setblock 97 78 325 minecraft:light[level=12]
setblock 97 78 329 minecraft:stone
setblock 97 78 330 minecraft:stripped_spruce_log
fill 97 78 331 97 81 331 minecraft:stone
fill 97 78 333 97 78 334 minecraft:stone
setblock 97 78 335 minecraft:stripped_spruce_log
setblock 97 78 339 minecraft:light[level=12]
setblock 97 78 344 minecraft:stone
setblock 97 78 345 minecraft:stripped_spruce_log
fill 97 78 346 97 81 346 minecraft:stone
setblock 97 78 350 minecraft:stripped_spruce_log
fill 97 78 351 97 81 351 minecraft:stone
setblock 97 78 355 minecraft:stripped_spruce_log
fill 97 78 356 98 80 356 minecraft:stone
fill 97 78 358 97 79 358 minecraft:stone
setblock 97 78 360 minecraft:light[level=12]
fill 98 78 329 98 81 329 minecraft:cobbled_deepslate
fill 98 78 331 98 81 331 minecraft:cobbled_deepslate
setblock 98 78 349 minecraft:stripped_spruce_log
fill 98 78 350 98 81 350 minecraft:stone
setblock 98 78 354 minecraft:stripped_spruce_log
fill 98 78 355 98 81 355 minecraft:stone
setblock 99 78 323 minecraft:stripped_spruce_log
setblock 99 78 352 minecraft:stone
setblock 99 78 363 minecraft:stripped_spruce_log
fill 100 78 323 100 80 323 minecraft:stone
fill 100 78 329 100 81 329 minecraft:cobbled_deepslate
fill 100 78 331 100 81 331 minecraft:cobbled_deepslate
fill 100 78 363 100 80 363 minecraft:stone
setblock 104 78 325 minecraft:light[level=12]
setblock 104 78 332 minecraft:light[level=12]
setblock 104 78 339 minecraft:light[level=12]
setblock 104 78 346 minecraft:light[level=12]
setblock 104 78 353 minecraft:light[level=12]
setblock 104 78 360 minecraft:light[level=12]
setblock 111 78 325 minecraft:light[level=12]
setblock 111 78 332 minecraft:light[level=12]
setblock 111 78 339 minecraft:light[level=12]
setblock 111 78 346 minecraft:light[level=12]
setblock 111 78 353 minecraft:light[level=12]
setblock 111 78 360 minecraft:light[level=12]
fill 112 78 323 113 78 323 minecraft:stone
setblock 114 78 323 minecraft:stripped_spruce_log
fill 114 78 324 114 80 324 minecraft:stone
fill 115 78 323 118 78 323 minecraft:stone
fill 116 78 363 118 78 363 minecraft:stone
setblock 117 78 324 minecraft:stone
setblock 117 78 325 minecraft:stripped_spruce_log
fill 117 78 326 117 80 326 minecraft:stone
setblock 118 78 324 minecraft:stripped_spruce_log
fill 118 78 325 118 81 325 minecraft:stone
setblock 118 78 332 minecraft:light[level=12]
setblock 118 78 339 minecraft:light[level=12]
setblock 118 78 346 minecraft:light[level=12]
setblock 118 78 353 minecraft:light[level=12]
setblock 118 78 360 minecraft:light[level=12]
setblock 119 78 323 minecraft:stripped_spruce_log
fill 119 78 324 122 78 324 minecraft:stone
setblock 119 78 362 minecraft:stone
setblock 119 78 363 minecraft:stripped_spruce_log
fill 120 78 323 123 78 323 minecraft:stone
setblock 120 78 362 minecraft:stripped_spruce_log
fill 120 78 363 120 80 363 minecraft:stone
setblock 121 78 326 minecraft:stripped_spruce_log
fill 121 78 362 121 80 362 minecraft:stone
setblock 122 78 325 minecraft:stripped_spruce_log
setblock 122 78 326 minecraft:stone
setblock 123 78 324 minecraft:stripped_spruce_log
fill 123 78 325 123 79 325 minecraft:stone
setblock 124 78 323 minecraft:stripped_spruce_log
fill 124 78 324 124 80 324 minecraft:stone
setblock 124 78 363 minecraft:stripped_spruce_log
fill 125 78 323 125 80 323 minecraft:stone
setblock 125 78 325 minecraft:light[level=12]
setblock 125 78 332 minecraft:light[level=12]
setblock 125 78 339 minecraft:light[level=12]
setblock 125 78 346 minecraft:light[level=12]
setblock 125 78 353 minecraft:light[level=12]
setblock 125 78 360 minecraft:light[level=12]
fill 125 78 363 125 80 363 minecraft:stone
fill 127 78 363 127 79 363 minecraft:stone
setblock 129 78 323 minecraft:stripped_spruce_log
fill 131 78 363 131 80 363 minecraft:stone
setblock 132 78 325 minecraft:light[level=12]
setblock 132 78 332 minecraft:light[level=12]
setblock 132 78 339 minecraft:light[level=12]
setblock 132 78 346 minecraft:light[level=12]
setblock 132 78 353 minecraft:light[level=12]
setblock 132 78 360 minecraft:light[level=12]
fill 133 78 351 133 78 353 minecraft:stone
setblock 133 78 354 minecraft:stripped_spruce_log
fill 133 78 355 133 80 356 minecraft:stone
setblock 134 78 323 minecraft:stripped_spruce_log
setblock 134 78 327 minecraft:stone
setblock 134 78 328 minecraft:stripped_spruce_log
fill 134 78 329 134 79 331 minecraft:stone
setblock 134 78 348 minecraft:stripped_spruce_log
fill 134 78 349 134 80 349 minecraft:stone
setblock 134 78 353 minecraft:stripped_spruce_log
fill 134 78 354 134 80 354 minecraft:stone
setblock 134 78 357 minecraft:stone
setblock 134 78 358 minecraft:stripped_spruce_log
fill 134 78 359 134 79 361 minecraft:stone
setblock 134 78 363 minecraft:stripped_spruce_log
fill 135 78 323 135 80 323 minecraft:stone
setblock 135 78 327 minecraft:stripped_spruce_log
fill 135 78 328 135 80 328 minecraft:stone
setblock 135 78 332 minecraft:stripped_spruce_log
fill 135 78 333 135 80 333 minecraft:stone
fill 135 78 335 135 78 336 minecraft:stone
fill 135 78 344 135 80 344 minecraft:stone
setblock 135 78 347 minecraft:stripped_spruce_log
fill 135 78 348 135 80 348 minecraft:stone
setblock 135 78 352 minecraft:stripped_spruce_log
fill 135 78 353 135 80 353 minecraft:stone
setblock 135 78 357 minecraft:stripped_spruce_log
fill 135 78 358 135 80 358 minecraft:stone
setblock 135 78 361 minecraft:stone
setblock 135 78 362 minecraft:stripped_spruce_log
fill 135 78 363 135 80 363 minecraft:stone
fill 136 78 336 136 79 342 minecraft:cobbled_deepslate
setblock 136 78 343 minecraft:raw_gold_block
fill 136 78 344 136 78 349 minecraft:cobbled_deepslate
fill 95 79 324 95 79 325 minecraft:stone
setblock 95 79 326 minecraft:stripped_spruce_log
fill 95 79 327 95 80 327 minecraft:stone
setblock 95 79 330 minecraft:stone
setblock 95 79 331 minecraft:stripped_spruce_log
fill 95 79 332 95 79 335 minecraft:stone
setblock 95 79 336 minecraft:stripped_spruce_log
fill 95 79 337 95 80 337 minecraft:stone
fill 95 79 339 95 79 340 minecraft:stone
setblock 95 79 341 minecraft:stripped_spruce_log
fill 95 79 342 95 80 342 minecraft:stone
setblock 95 79 346 minecraft:stripped_spruce_log
fill 95 79 347 95 80 347 minecraft:stone
setblock 95 79 351 minecraft:stripped_spruce_log
fill 95 79 352 95 80 352 minecraft:stone
setblock 95 79 356 minecraft:stripped_spruce_log
fill 95 79 357 95 80 357 minecraft:stone
setblock 95 79 360 minecraft:stone
setblock 95 79 361 minecraft:stripped_spruce_log
fill 95 79 362 95 80 362 minecraft:stone
fill 96 79 323 97 79 323 minecraft:stone
setblock 96 79 324 minecraft:glowstone
setblock 96 79 330 minecraft:stripped_spruce_log
fill 96 79 331 96 80 331 minecraft:stone
fill 96 79 333 96 79 334 minecraft:stone
setblock 96 79 335 minecraft:stripped_spruce_log
fill 96 79 336 97 80 336 minecraft:stone
setblock 96 79 339 minecraft:stone
setblock 96 79 340 minecraft:stripped_spruce_log
fill 96 79 341 96 80 341 minecraft:stone
setblock 96 79 343 minecraft:glowstone
setblock 96 79 345 minecraft:stripped_spruce_log
fill 96 79 346 96 80 346 minecraft:stone
setblock 96 79 350 minecraft:stripped_spruce_log
fill 96 79 351 96 80 351 minecraft:stone
setblock 96 79 355 minecraft:stripped_spruce_log
fill 96 79 356 96 80 356 minecraft:stone
setblock 96 79 360 minecraft:stripped_spruce_log
fill 96 79 361 96 80 361 minecraft:stone
setblock 96 79 362 minecraft:glowstone
setblock 97 79 329 minecraft:stripped_spruce_log
fill 97 79 330 97 82 330 minecraft:stone
setblock 97 79 333 minecraft:stone
setblock 97 79 334 minecraft:stripped_spruce_log
fill 97 79 335 97 82 335 minecraft:stone
fill 97 79 337 97 79 338 minecraft:stone
setblock 97 79 343 minecraft:stone
setblock 97 79 344 minecraft:stripped_spruce_log
fill 97 79 345 97 81 345 minecraft:stone
setblock 97 79 349 minecraft:stripped_spruce_log
fill 97 79 350 97 82 350 minecraft:stone
setblock 97 79 353 minecraft:stone
setblock 97 79 354 minecraft:stripped_spruce_log
fill 97 79 355 97 82 355 minecraft:stone
setblock 97 79 359 minecraft:stripped_spruce_log
setblock 98 79 323 minecraft:stripped_spruce_log
setblock 98 79 348 minecraft:stripped_spruce_log
fill 98 79 349 98 81 349 minecraft:stone
fill 98 79 351 98 80 351 minecraft:stone
setblock 98 79 353 minecraft:stripped_spruce_log
fill 98 79 354 98 82 354 minecraft:stone
setblock 98 79 363 minecraft:stripped_spruce_log
fill 99 79 323 99 80 323 minecraft:stone
setblock 99 79 352 minecraft:stripped_spruce_log
fill 99 79 363 99 80 363 minecraft:stone
fill 106 79 325 106 89 325 minecraft:cobbled_deepslate
setblock 112 79 323 minecraft:stone
setblock 113 79 323 minecraft:stripped_spruce_log
fill 113 79 324 113 80 324 minecraft:stone
fill 114 79 323 117 79 323 minecraft:stone
setblock 115 79 324 minecraft:glowstone
setblock 115 79 362 minecraft:glowstone
fill 115 79 363 117 79 363 minecraft:stone
setblock 116 79 324 minecraft:stone
setblock 116 79 325 minecraft:stripped_spruce_log
setblock 116 79 326 minecraft:stone
setblock 117 79 324 minecraft:stripped_spruce_log
fill 117 79 325 117 82 325 minecraft:stone
setblock 118 79 323 minecraft:stripped_spruce_log
fill 118 79 324 121 79 324 minecraft:stone
setblock 118 79 362 minecraft:stone
setblock 118 79 363 minecraft:stripped_spruce_log
fill 119 79 323 122 79 323 minecraft:stone
setblock 119 79 362 minecraft:stripped_spruce_log
fill 119 79 363 119 80 363 minecraft:stone
setblock 120 79 326 minecraft:stripped_spruce_log
fill 120 79 362 120 80 362 minecraft:stone
setblock 121 79 325 minecraft:stripped_spruce_log
setblock 121 79 326 minecraft:stone
setblock 122 79 324 minecraft:stripped_spruce_log
fill 122 79 325 122 80 325 minecraft:stone
fill 122 79 362 122 80 362 minecraft:stone
setblock 123 79 323 minecraft:stripped_spruce_log
fill 123 79 324 123 80 324 minecraft:stone
setblock 123 79 363 minecraft:stripped_spruce_log
fill 124 79 323 124 80 323 minecraft:stone
fill 124 79 363 124 80 363 minecraft:stone
setblock 128 79 323 minecraft:stripped_spruce_log
setblock 128 79 363 minecraft:stripped_spruce_log
fill 129 79 363 130 80 363 minecraft:stone
setblock 133 79 323 minecraft:stripped_spruce_log
fill 133 79 351 133 79 352 minecraft:stone
setblock 133 79 353 minecraft:stripped_spruce_log
fill 133 79 354 133 82 354 minecraft:stone
setblock 133 79 357 minecraft:stone
setblock 133 79 358 minecraft:stripped_spruce_log
setblock 133 79 362 minecraft:stone
setblock 133 79 363 minecraft:stripped_spruce_log
fill 134 79 323 134 80 323 minecraft:stone
setblock 134 79 324 minecraft:glowstone
setblock 134 79 327 minecraft:stripped_spruce_log
fill 134 79 328 134 80 328 minecraft:stone
setblock 134 79 332 minecraft:stripped_spruce_log
fill 134 79 333 134 80 333 minecraft:stone
setblock 134 79 343 minecraft:glowstone
setblock 134 79 347 minecraft:stripped_spruce_log
fill 134 79 348 134 80 348 minecraft:stone
setblock 134 79 352 minecraft:stripped_spruce_log
fill 134 79 353 134 80 353 minecraft:stone
setblock 134 79 356 minecraft:stone
setblock 134 79 357 minecraft:stripped_spruce_log
fill 134 79 358 134 80 358 minecraft:stone
setblock 134 79 362 minecraft:glowstone
fill 134 79 363 134 80 363 minecraft:stone
setblock 135 79 326 minecraft:stripped_spruce_log
fill 135 79 327 135 80 327 minecraft:stone
setblock 135 79 331 minecraft:stripped_spruce_log
fill 135 79 332 135 80 332 minecraft:stone
setblock 135 79 335 minecraft:stone
setblock 135 79 336 minecraft:stripped_spruce_log
fill 135 79 337 135 80 339 minecraft:stone
fill 135 79 343 135 80 343 minecraft:stone
setblock 135 79 346 minecraft:stripped_spruce_log
fill 135 79 347 135 80 347 minecraft:stone
setblock 135 79 351 minecraft:stripped_spruce_log
fill 135 79 352 135 80 352 minecraft:stone
setblock 135 79 356 minecraft:stripped_spruce_log
fill 135 79 357 135 80 357 minecraft:stone
setblock 135 79 361 minecraft:stripped_spruce_log
fill 135 79 362 135 80 362 minecraft:stone
fill 136 79 323 136 105 323 minecraft:cobbled_deepslate
setblock 136 79 324 minecraft:raw_gold_block
fill 136 79 343 136 82 347 minecraft:cobbled_deepslate
setblock 136 79 348 minecraft:raw_gold_block
fill 136 79 349 136 85 349 minecraft:cobbled_deepslate
setblock 95 80 324 minecraft:stone
setblock 95 80 325 minecraft:stripped_spruce_log
setblock 95 80 326 minecraft:stone
setblock 95 80 330 minecraft:stripped_spruce_log
fill 95 80 331 95 80 334 minecraft:stone
setblock 95 80 335 minecraft:stripped_spruce_log
setblock 95 80 336 minecraft:stone
setblock 95 80 339 minecraft:stone
setblock 95 80 340 minecraft:stripped_spruce_log
setblock 95 80 341 minecraft:stone
setblock 95 80 345 minecraft:stripped_spruce_log
setblock 95 80 346 minecraft:stone
setblock 95 80 350 minecraft:stripped_spruce_log
setblock 95 80 351 minecraft:stone
setblock 95 80 355 minecraft:stripped_spruce_log
setblock 95 80 356 minecraft:stone
setblock 95 80 359 minecraft:stone
setblock 95 80 360 minecraft:stripped_spruce_log
setblock 95 80 361 minecraft:stone
setblock 96 80 323 minecraft:stone
fill 96 80 324 96 81 324 minecraft:spruce_log
setblock 96 80 329 minecraft:stripped_spruce_log
setblock 96 80 330 minecraft:stone
setblock 96 80 333 minecraft:stone
setblock 96 80 334 minecraft:stripped_spruce_log
setblock 96 80 335 minecraft:stone
setblock 96 80 339 minecraft:stripped_spruce_log
fill 96 80 340 97 80 340 minecraft:stone
fill 96 80 343 96 81 343 minecraft:spruce_log
setblock 96 80 344 minecraft:stripped_spruce_log
setblock 96 80 345 minecraft:stone
setblock 96 80 349 minecraft:stripped_spruce_log
setblock 96 80 350 minecraft:stone
setblock 96 80 354 minecraft:stripped_spruce_log
setblock 96 80 355 minecraft:stone
setblock 96 80 359 minecraft:stripped_spruce_log
setblock 96 80 360 minecraft:stone
fill 96 80 362 96 81 362 minecraft:spruce_log
setblock 97 80 323 minecraft:stripped_spruce_log
setblock 97 80 329 minecraft:stone
setblock 97 80 333 minecraft:stripped_spruce_log
fill 97 80 334 98 82 334 minecraft:stone
setblock 97 80 337 minecraft:stone
setblock 97 80 338 minecraft:stripped_spruce_log
fill 97 80 339 97 83 339 minecraft:stone
fill 97 80 341 97 80 342 minecraft:stone
setblock 97 80 343 minecraft:stripped_spruce_log
fill 97 80 344 97 81 344 minecraft:stone
setblock 97 80 348 minecraft:stripped_spruce_log
fill 97 80 349 97 83 349 minecraft:stone
setblock 97 80 353 minecraft:stripped_spruce_log
fill 97 80 354 97 83 354 minecraft:stone
setblock 97 80 358 minecraft:stripped_spruce_log
fill 97 80 359 97 83 359 minecraft:stone
setblock 97 80 363 minecraft:stripped_spruce_log
setblock 98 80 323 minecraft:stone
setblock 98 80 332 minecraft:stripped_spruce_log
fill 98 80 333 98 81 333 minecraft:stone
fill 98 80 335 98 81 335 minecraft:stone
setblock 98 80 348 minecraft:stone
setblock 98 80 352 minecraft:stripped_spruce_log
fill 98 80 353 98 82 353 minecraft:stone
setblock 98 80 363 minecraft:stone
setblock 112 80 323 minecraft:stripped_spruce_log
fill 113 80 323 116 80 323 minecraft:stone
fill 114 80 363 116 80 363 minecraft:stone
fill 115 80 324 115 81 324 minecraft:spruce_log
setblock 115 80 325 minecraft:stripped_spruce_log
fill 115 80 362 115 81 362 minecraft:spruce_log
setblock 116 80 324 minecraft:stripped_spruce_log
fill 116 80 325 116 82 325 minecraft:stone
setblock 117 80 323 minecraft:stripped_spruce_log
fill 117 80 324 120 80 324 minecraft:stone
setblock 117 80 362 minecraft:stone
setblock 117 80 363 minecraft:stripped_spruce_log
fill 118 80 323 121 80 323 minecraft:stone
setblock 118 80 362 minecraft:stripped_spruce_log
setblock 118 80 363 minecraft:stone
setblock 119 80 326 minecraft:stripped_spruce_log
setblock 119 80 362 minecraft:stone
setblock 120 80 325 minecraft:stripped_spruce_log
setblock 121 80 324 minecraft:stripped_spruce_log
setblock 121 80 325 minecraft:stone
setblock 122 80 323 minecraft:stripped_spruce_log
setblock 122 80 324 minecraft:stone
setblock 122 80 363 minecraft:stripped_spruce_log
setblock 123 80 323 minecraft:stone
setblock 123 80 363 minecraft:stone
setblock 127 80 363 minecraft:stripped_spruce_log
setblock 128 80 363 minecraft:stone
setblock 132 80 362 minecraft:stone
setblock 132 80 363 minecraft:stripped_spruce_log
setblock 133 80 323 minecraft:stone
fill 133 80 350 133 80 351 minecraft:stone
setblock 133 80 352 minecraft:stripped_spruce_log
fill 133 80 353 133 83 353 minecraft:stone
setblock 133 80 357 minecraft:stripped_spruce_log
fill 133 80 358 133 82 359 minecraft:stone
setblock 133 80 362 minecraft:stripped_spruce_log
setblock 133 80 363 minecraft:stone
fill 134 80 324 134 81 324 minecraft:spruce_log
fill 134 80 329 134 80 330 minecraft:stone
setblock 134 80 331 minecraft:stripped_spruce_log
setblock 134 80 332 minecraft:stone
fill 134 80 334 134 80 335 minecraft:stone
fill 134 80 343 134 81 343 minecraft:spruce_log
setblock 134 80 347 minecraft:stone
setblock 134 80 351 minecraft:stripped_spruce_log
setblock 134 80 352 minecraft:stone
setblock 134 80 356 minecraft:stripped_spruce_log
setblock 134 80 357 minecraft:stone
fill 134 80 359 134 80 360 minecraft:stone
setblock 134 80 361 minecraft:stripped_spruce_log
fill 134 80 362 134 81 362 minecraft:spruce_log
setblock 135 80 325 minecraft:stripped_spruce_log
setblock 135 80 326 minecraft:stone
setblock 135 80 330 minecraft:stripped_spruce_log
setblock 135 80 331 minecraft:stone
setblock 135 80 335 minecraft:stripped_spruce_log
setblock 135 80 336 minecraft:stone
setblock 135 80 340 minecraft:stripped_spruce_log
fill 135 80 341 135 80 342 minecraft:stone
setblock 135 80 345 minecraft:stripped_spruce_log
setblock 135 80 346 minecraft:stone
setblock 135 80 350 minecraft:stripped_spruce_log
setblock 135 80 351 minecraft:stone
setblock 135 80 355 minecraft:stripped_spruce_log
setblock 135 80 356 minecraft:stone
setblock 135 80 360 minecraft:stripped_spruce_log
setblock 135 80 361 minecraft:stone
fill 136 80 324 136 100 324 minecraft:cobbled_deepslate
fill 136 80 336 136 90 340 minecraft:cobbled_deepslate
setblock 136 80 341 minecraft:diamond_block
fill 136 80 342 136 103 342 minecraft:cobbled_deepslate
fill 136 80 348 136 107 348 minecraft:cobbled_deepslate
fill 94 81 353 94 95 353 minecraft:cobbled_deepslate
setblock 94 81 354 minecraft:raw_gold_block
fill 95 81 323 95 81 363 minecraft:spruce_planks
fill 96 81 323 135 81 323 minecraft:spruce_planks
fill 96 81 325 96 81 342 minecraft:spruce_planks
fill 96 81 344 96 81 361 minecraft:spruce_planks
fill 96 81 363 135 81 363 minecraft:spruce_planks
fill 97 81 324 114 81 324 minecraft:spruce_planks
setblock 97 81 332 minecraft:stripped_spruce_log
fill 97 81 333 97 84 333 minecraft:stone
setblock 97 81 336 minecraft:stone
setblock 97 81 337 minecraft:stripped_spruce_log
fill 97 81 338 97 84 338 minecraft:stone
fill 97 81 340 97 81 341 minecraft:stone
setblock 97 81 342 minecraft:stripped_spruce_log
setblock 97 81 343 minecraft:stone
setblock 97 81 347 minecraft:stripped_spruce_log
fill 97 81 348 97 82 348 minecraft:stone
setblock 97 81 352 minecraft:stripped_spruce_log
fill 97 81 353 97 84 353 minecraft:stone
setblock 97 81 356 minecraft:stone
setblock 97 81 357 minecraft:stripped_spruce_log
fill 97 81 358 97 84 358 minecraft:stone
fill 97 81 362 114 81 362 minecraft:spruce_planks
fill 97 81 364 97 100 364 minecraft:cobbled_deepslate
setblock 98 81 336 minecraft:stripped_spruce_log
setblock 98 81 351 minecraft:stripped_spruce_log
fill 98 81 352 98 82 352 minecraft:stone
setblock 98 81 356 minecraft:stripped_spruce_log
setblock 98 81 364 minecraft:raw_iron_block
setblock 99 81 328 minecraft:cobbled_deepslate
setblock 99 81 332 minecraft:cobbled_deepslate
setblock 101 81 330 minecraft:cobbled_deepslate
setblock 115 81 325 minecraft:stone
fill 116 81 322 121 99 322 minecraft:cobbled_deepslate
fill 116 81 324 133 81 324 minecraft:spruce_planks
fill 116 81 362 133 81 362 minecraft:spruce_planks
setblock 119 81 325 minecraft:stripped_spruce_log
setblock 120 81 325 minecraft:stone
setblock 122 81 322 minecraft:raw_iron_block
fill 123 81 322 124 86 322 minecraft:cobbled_deepslate
setblock 133 81 351 minecraft:stripped_spruce_log
fill 133 81 352 133 84 352 minecraft:stone
setblock 133 81 355 minecraft:stone
setblock 133 81 356 minecraft:stripped_spruce_log
fill 133 81 357 133 84 357 minecraft:stone
setblock 133 81 360 minecraft:stone
fill 134 81 325 135 81 342 minecraft:spruce_planks
fill 134 81 344 135 81 361 minecraft:spruce_planks
setblock 135 81 324 minecraft:spruce_planks
setblock 135 81 343 minecraft:spruce_planks
setblock 135 81 362 minecraft:spruce_planks
setblock 136 81 329 minecraft:raw_iron_block
fill 136 81 341 136 103 341 minecraft:cobbled_deepslate
setblock 94 82 326 minecraft:raw_gold_block
fill 94 82 327 94 82 328 minecraft:cobbled_deepslate
setblock 94 82 337 minecraft:raw_iron_block
fill 94 82 354 94 108 354 minecraft:cobbled_deepslate
fill 95 82 326 95 82 327 minecraft:stone
setblock 95 82 328 minecraft:stripped_spruce_log
fill 95 82 329 95 82 332 minecraft:stone
setblock 95 82 333 minecraft:stripped_spruce_log
fill 95 82 334 95 82 337 minecraft:stone
setblock 95 82 338 minecraft:stripped_spruce_log
fill 95 82 339 95 82 342 minecraft:stone
setblock 95 82 343 minecraft:stripped_spruce_log
fill 95 82 344 95 82 347 minecraft:stone
setblock 95 82 348 minecraft:stripped_spruce_log
fill 95 82 349 95 82 352 minecraft:stone
setblock 95 82 353 minecraft:stripped_spruce_log
fill 95 82 354 95 82 357 minecraft:stone
setblock 95 82 358 minecraft:stripped_spruce_log
fill 95 82 359 95 82 362 minecraft:stone
setblock 95 82 363 minecraft:stripped_spruce_log
fill 96 82 328 96 82 331 minecraft:stone
setblock 96 82 332 minecraft:stripped_spruce_log
fill 96 82 333 96 82 336 minecraft:stone
setblock 96 82 337 minecraft:stripped_spruce_log
fill 96 82 338 96 82 341 minecraft:stone
setblock 96 82 342 minecraft:stripped_spruce_log
fill 96 82 343 96 82 346 minecraft:stone
setblock 96 82 347 minecraft:stripped_spruce_log
fill 96 82 348 96 82 351 minecraft:stone
setblock 96 82 352 minecraft:stripped_spruce_log
fill 96 82 353 96 82 356 minecraft:stone
setblock 96 82 357 minecraft:stripped_spruce_log
fill 96 82 358 96 82 361 minecraft:stone
setblock 96 82 362 minecraft:stripped_spruce_log
fill 96 82 363 99 82 363 minecraft:stone
setblock 97 82 325 minecraft:light[level=15]
setblock 97 82 331 minecraft:stripped_spruce_log
fill 97 82 332 97 84 332 minecraft:stone
setblock 97 82 336 minecraft:stripped_spruce_log
fill 97 82 337 97 85 337 minecraft:stone
setblock 97 82 340 minecraft:stone
setblock 97 82 341 minecraft:stripped_spruce_log
setblock 97 82 342 minecraft:stone
setblock 97 82 346 minecraft:stripped_spruce_log
setblock 97 82 347 minecraft:stone
setblock 97 82 351 minecraft:stripped_spruce_log
fill 97 82 352 97 84 352 minecraft:stone
setblock 97 82 356 minecraft:stripped_spruce_log
fill 97 82 357 97 84 357 minecraft:stone
setblock 98 82 335 minecraft:stripped_spruce_log
fill 98 82 336 98 83 336 minecraft:stone
setblock 98 82 355 minecraft:stripped_spruce_log
fill 98 82 364 98 107 364 minecraft:cobbled_deepslate
fill 101 82 322 101 107 322 minecraft:cobbled_deepslate
setblock 102 82 322 minecraft:raw_gold_block
fill 103 82 322 104 107 322 minecraft:cobbled_deepslate
setblock 105 82 325 minecraft:light[level=15]
setblock 105 82 333 minecraft:light[level=15]
setblock 105 82 341 minecraft:light[level=15]
setblock 105 82 349 minecraft:light[level=15]
setblock 105 82 357 minecraft:light[level=15]
setblock 108 82 322 minecraft:raw_iron_block
fill 112 82 323 114 82 323 minecraft:stone
setblock 113 82 324 minecraft:stone
setblock 113 82 325 minecraft:light[level=15]
setblock 113 82 333 minecraft:light[level=15]
setblock 113 82 341 minecraft:light[level=15]
setblock 113 82 349 minecraft:light[level=15]
setblock 113 82 357 minecraft:light[level=15]
fill 113 82 363 114 82 363 minecraft:stone
setblock 114 82 324 minecraft:stripped_spruce_log
setblock 115 82 323 minecraft:stripped_spruce_log
fill 115 82 324 118 82 324 minecraft:stone
setblock 115 82 362 minecraft:stone
setblock 115 82 363 minecraft:stripped_spruce_log
fill 116 82 323 119 82 323 minecraft:stone
setblock 116 82 362 minecraft:stripped_spruce_log
fill 116 82 363 119 82 363 minecraft:stone
fill 117 82 362 120 82 362 minecraft:stone
setblock 118 82 325 minecraft:stripped_spruce_log
setblock 119 82 324 minecraft:stripped_spruce_log
setblock 120 82 323 minecraft:stripped_spruce_log
fill 120 82 324 121 82 324 minecraft:stone
setblock 120 82 363 minecraft:stripped_spruce_log
fill 121 82 323 124 82 323 minecraft:stone
setblock 121 82 325 minecraft:light[level=15]
setblock 121 82 333 minecraft:light[level=15]
setblock 121 82 341 minecraft:light[level=15]
setblock 121 82 349 minecraft:light[level=15]
setblock 121 82 357 minecraft:light[level=15]
setblock 121 82 362 minecraft:stripped_spruce_log
fill 121 82 363 124 82 363 minecraft:stone
fill 122 82 322 122 107 322 minecraft:cobbled_deepslate
setblock 122 82 362 minecraft:stone
setblock 125 82 363 minecraft:stripped_spruce_log
fill 126 82 363 129 82 363 minecraft:stone
setblock 129 82 325 minecraft:light[level=15]
setblock 129 82 333 minecraft:light[level=15]
setblock 129 82 341 minecraft:light[level=15]
setblock 129 82 349 minecraft:light[level=15]
setblock 129 82 357 minecraft:light[level=15]
setblock 130 82 363 minecraft:stripped_spruce_log
setblock 131 82 362 minecraft:stripped_spruce_log
fill 131 82 363 134 82 363 minecraft:stone
fill 131 82 364 132 104 364 minecraft:cobbled_deepslate
fill 132 82 362 135 82 362 minecraft:stone
fill 133 82 351 135 83 351 minecraft:stone
setblock 133 82 355 minecraft:stripped_spruce_log
fill 133 82 356 135 83 356 minecraft:stone
setblock 133 82 360 minecraft:stripped_spruce_log
fill 133 82 361 135 83 361 minecraft:stone
setblock 133 82 364 minecraft:gold_block
setblock 134 82 323 minecraft:stone
fill 134 82 330 134 82 333 minecraft:stone
setblock 134 82 334 minecraft:stripped_spruce_log
fill 134 82 335 135 82 337 minecraft:stone
fill 134 82 347 134 82 348 minecraft:stone
setblock 134 82 349 minecraft:stripped_spruce_log
fill 134 82 350 135 84 350 minecraft:stone
fill 134 82 352 134 82 353 minecraft:stone
setblock 134 82 354 minecraft:stripped_spruce_log
fill 134 82 355 135 84 355 minecraft:stone
fill 134 82 357 134 82 358 minecraft:stone
setblock 134 82 359 minecraft:stripped_spruce_log
fill 134 82 360 135 84 360 minecraft:stone
fill 134 82 364 136 100 364 minecraft:cobbled_deepslate
setblock 135 82 323 minecraft:stripped_spruce_log
fill 135 82 324 135 82 327 minecraft:stone
setblock 135 82 328 minecraft:stripped_spruce_log
fill 135 82 329 135 82 332 minecraft:stone
setblock 135 82 333 minecraft:stripped_spruce_log
fill 135 82 334 135 85 334 minecraft:stone
setblock 135 82 338 minecraft:stripped_spruce_log
fill 135 82 339 135 82 342 minecraft:stone
setblock 135 82 343 minecraft:stripped_spruce_log
fill 135 82 344 135 82 347 minecraft:stone
setblock 135 82 348 minecraft:stripped_spruce_log
fill 135 82 349 135 85 349 minecraft:stone
setblock 135 82 352 minecraft:stone
setblock 135 82 353 minecraft:stripped_spruce_log
fill 135 82 354 135 85 354 minecraft:stone
setblock 135 82 357 minecraft:stone
setblock 135 82 358 minecraft:stripped_spruce_log
fill 135 82 359 135 85 359 minecraft:stone
setblock 135 82 363 minecraft:stripped_spruce_log
fill 136 82 329 136 107 329 minecraft:cobbled_deepslate
fill 94 83 326 94 104 327 minecraft:cobbled_deepslate
setblock 94 83 328 minecraft:diamond_block
fill 94 83 337 94 91 337 minecraft:cobbled_deepslate
setblock 95 83 327 minecraft:stripped_spruce_log
fill 95 83 328 95 83 331 minecraft:stone
setblock 95 83 332 minecraft:stripped_spruce_log
fill 95 83 333 95 83 336 minecraft:stone
setblock 95 83 337 minecraft:stripped_spruce_log
fill 95 83 338 95 83 341 minecraft:stone
setblock 95 83 342 minecraft:stripped_spruce_log
fill 95 83 343 95 83 346 minecraft:stone
setblock 95 83 347 minecraft:stripped_spruce_log
fill 95 83 348 95 83 351 minecraft:stone
setblock 95 83 352 minecraft:stripped_spruce_log
fill 95 83 353 95 83 356 minecraft:stone
setblock 95 83 357 minecraft:stripped_spruce_log
fill 95 83 358 95 83 361 minecraft:stone
setblock 95 83 362 minecraft:stripped_spruce_log
fill 95 83 363 98 83 363 minecraft:stone
fill 96 83 329 96 83 330 minecraft:stone
setblock 96 83 331 minecraft:stripped_spruce_log
fill 96 83 332 96 83 335 minecraft:stone
setblock 96 83 336 minecraft:stripped_spruce_log
fill 96 83 337 96 83 340 minecraft:stone
setblock 96 83 341 minecraft:stripped_spruce_log
fill 96 83 342 96 83 345 minecraft:stone
setblock 96 83 346 minecraft:stripped_spruce_log
fill 96 83 347 96 83 350 minecraft:stone
setblock 96 83 351 minecraft:stripped_spruce_log
fill 96 83 352 96 83 355 minecraft:stone
setblock 96 83 356 minecraft:stripped_spruce_log
fill 96 83 357 96 83 360 minecraft:stone
setblock 96 83 361 minecraft:stripped_spruce_log
setblock 97 83 331 minecraft:stone
setblock 97 83 334 minecraft:stone
setblock 97 83 335 minecraft:stripped_spruce_log
fill 97 83 336 97 86 336 minecraft:stone
setblock 97 83 340 minecraft:stripped_spruce_log
fill 97 83 341 97 86 341 minecraft:stone
setblock 97 83 350 minecraft:stripped_spruce_log
fill 97 83 351 97 84 351 minecraft:stone
setblock 97 83 355 minecraft:stripped_spruce_log
fill 97 83 356 97 85 356 minecraft:stone
setblock 98 83 335 minecraft:stone
fill 102 83 322 102 107 322 minecraft:cobbled_deepslate
fill 108 83 322 108 107 322 minecraft:cobbled_deepslate
fill 111 83 323 113 83 323 minecraft:stone
setblock 113 83 324 minecraft:stripped_spruce_log
setblock 113 83 363 minecraft:stone
setblock 114 83 323 minecraft:stripped_spruce_log
fill 114 83 324 117 83 324 minecraft:stone
setblock 114 83 363 minecraft:stripped_spruce_log
fill 115 83 323 118 83 323 minecraft:stone
setblock 115 83 362 minecraft:stripped_spruce_log
fill 115 83 363 118 83 363 minecraft:stone
fill 116 83 362 119 83 362 minecraft:stone
setblock 118 83 324 minecraft:stripped_spruce_log
setblock 119 83 323 minecraft:stripped_spruce_log
fill 119 83 324 120 83 324 minecraft:stone
setblock 119 83 363 minecraft:stripped_spruce_log
fill 120 83 323 122 83 323 minecraft:stone
setblock 120 83 362 minecraft:stripped_spruce_log
fill 120 83 363 123 83 363 minecraft:stone
fill 121 83 362 121 84 362 minecraft:stone
setblock 124 83 363 minecraft:stripped_spruce_log
fill 125 83 363 128 83 363 minecraft:stone
setblock 129 83 363 minecraft:stripped_spruce_log
fill 130 83 363 133 83 363 minecraft:stone
fill 131 83 362 134 83 362 minecraft:stone
setblock 133 83 354 minecraft:stripped_spruce_log
fill 133 83 355 133 86 355 minecraft:stone
setblock 133 83 358 minecraft:stone
setblock 133 83 359 minecraft:stripped_spruce_log
fill 133 83 360 133 86 360 minecraft:stone
fill 133 83 364 133 101 364 minecraft:cobbled_deepslate
setblock 134 83 332 minecraft:stone
setblock 134 83 333 minecraft:stripped_spruce_log
fill 134 83 334 134 83 337 minecraft:stone
setblock 134 83 338 minecraft:stripped_spruce_log
setblock 134 83 348 minecraft:stripped_spruce_log
fill 134 83 349 134 86 349 minecraft:stone
setblock 134 83 352 minecraft:stone
setblock 134 83 353 minecraft:stripped_spruce_log
fill 134 83 354 134 86 354 minecraft:stone
setblock 134 83 357 minecraft:stone
setblock 134 83 358 minecraft:stripped_spruce_log
fill 134 83 359 134 86 359 minecraft:stone
setblock 134 83 363 minecraft:stripped_spruce_log
setblock 135 83 327 minecraft:stripped_spruce_log
fill 135 83 328 135 83 331 minecraft:stone
setblock 135 83 332 minecraft:stripped_spruce_log
fill 135 83 333 135 86 333 minecraft:stone
fill 135 83 335 135 83 336 minecraft:stone
setblock 135 83 337 minecraft:stripped_spruce_log
fill 135 83 338 135 83 341 minecraft:stone
setblock 135 83 342 minecraft:stripped_spruce_log
fill 135 83 343 135 83 346 minecraft:stone
setblock 135 83 347 minecraft:stripped_spruce_log
fill 135 83 348 135 86 348 minecraft:stone
setblock 135 83 352 minecraft:stripped_spruce_log
fill 135 83 353 135 86 353 minecraft:stone
setblock 135 83 357 minecraft:stripped_spruce_log
fill 135 83 358 135 86 358 minecraft:stone
setblock 135 83 362 minecraft:stripped_spruce_log
fill 135 83 363 135 86 363 minecraft:stone
fill 136 83 343 136 107 343 minecraft:cobbled_deepslate
setblock 136 83 344 minecraft:gold_block
fill 136 83 345 136 95 347 minecraft:cobbled_deepslate
fill 94 84 328 94 107 328 minecraft:cobbled_deepslate
setblock 94 84 346 minecraft:gold_block
fill 94 84 347 94 107 347 minecraft:cobbled_deepslate
fill 95 84 328 95 84 330 minecraft:stone
setblock 95 84 331 minecraft:stripped_spruce_log
fill 95 84 332 95 84 335 minecraft:stone
setblock 95 84 336 minecraft:stripped_spruce_log
fill 95 84 337 95 84 340 minecraft:stone
setblock 95 84 341 minecraft:stripped_spruce_log
fill 95 84 342 95 84 345 minecraft:stone
setblock 95 84 346 minecraft:stripped_spruce_log
fill 95 84 347 95 84 350 minecraft:stone
setblock 95 84 351 minecraft:stripped_spruce_log
fill 95 84 352 95 84 355 minecraft:stone
setblock 95 84 356 minecraft:stripped_spruce_log
fill 95 84 357 95 84 360 minecraft:stone
setblock 95 84 361 minecraft:stripped_spruce_log
fill 95 84 362 95 86 363 minecraft:stone
setblock 96 84 330 minecraft:stripped_spruce_log
fill 96 84 331 96 84 334 minecraft:stone
setblock 96 84 335 minecraft:stripped_spruce_log
fill 96 84 336 96 84 339 minecraft:stone
setblock 96 84 340 minecraft:stripped_spruce_log
fill 96 84 341 96 84 344 minecraft:stone
setblock 96 84 345 minecraft:stripped_spruce_log
fill 96 84 346 96 84 349 minecraft:stone
setblock 96 84 350 minecraft:stripped_spruce_log
fill 96 84 351 96 84 354 minecraft:stone
setblock 96 84 355 minecraft:stripped_spruce_log
fill 96 84 356 96 84 359 minecraft:stone
setblock 96 84 360 minecraft:stripped_spruce_log
fill 96 84 361 96 87 361 minecraft:stone
fill 96 84 363 97 84 363 minecraft:stone
setblock 97 84 325 minecraft:light[level=12]
setblock 97 84 334 minecraft:stripped_spruce_log
fill 97 84 335 97 87 335 minecraft:stone
setblock 97 84 339 minecraft:stripped_spruce_log
fill 97 84 340 97 87 340 minecraft:stone
setblock 97 84 346 minecraft:light[level=12]
setblock 97 84 354 minecraft:stripped_spruce_log
fill 97 84 355 97 85 355 minecraft:stone
setblock 97 84 360 minecraft:light[level=12]
fill 103 84 323 103 85 325 minecraft:iron_bars
setblock 104 84 325 minecraft:light[level=12]
setblock 104 84 332 minecraft:light[level=12]
setblock 104 84 339 minecraft:light[level=12]
setblock 104 84 346 minecraft:light[level=12]
setblock 104 84 353 minecraft:light[level=12]
setblock 104 84 360 minecraft:light[level=12]
fill 111 84 323 112 84 323 minecraft:stone
setblock 111 84 325 minecraft:light[level=12]
setblock 111 84 332 minecraft:light[level=12]
setblock 111 84 339 minecraft:light[level=12]
setblock 111 84 346 minecraft:light[level=12]
setblock 111 84 353 minecraft:light[level=12]
setblock 111 84 360 minecraft:light[level=12]
setblock 112 84 363 minecraft:stone
setblock 113 84 323 minecraft:stripped_spruce_log
setblock 113 84 363 minecraft:stripped_spruce_log
fill 114 84 323 116 84 324 minecraft:stone
setblock 114 84 362 minecraft:stripped_spruce_log
fill 114 84 363 117 84 363 minecraft:stone
fill 115 84 362 118 84 362 minecraft:stone
setblock 117 84 323 minecraft:stone
setblock 117 84 324 minecraft:stripped_spruce_log
setblock 118 84 323 minecraft:stripped_spruce_log
setblock 118 84 324 minecraft:stone
setblock 118 84 325 minecraft:light[level=12]
setblock 118 84 332 minecraft:light[level=12]
setblock 118 84 339 minecraft:light[level=12]
setblock 118 84 346 minecraft:light[level=12]
setblock 118 84 353 minecraft:light[level=12]
setblock 118 84 360 minecraft:light[level=12]
setblock 118 84 363 minecraft:stripped_spruce_log
fill 119 84 323 121 84 323 minecraft:stone
setblock 119 84 362 minecraft:stripped_spruce_log
fill 119 84 363 122 84 363 minecraft:stone
fill 120 84 362 120 87 362 minecraft:stone
setblock 123 84 363 minecraft:stripped_spruce_log
fill 124 84 363 127 84 363 minecraft:stone
setblock 125 84 325 minecraft:light[level=12]
setblock 125 84 332 minecraft:light[level=12]
setblock 125 84 339 minecraft:light[level=12]
setblock 125 84 346 minecraft:light[level=12]
setblock 125 84 353 minecraft:light[level=12]
setblock 125 84 360 minecraft:light[level=12]
setblock 126 84 322 minecraft:raw_iron_block
setblock 128 84 363 minecraft:stripped_spruce_log
fill 129 84 363 132 84 363 minecraft:stone
fill 130 84 362 133 84 362 minecraft:stone
setblock 132 84 325 minecraft:light[level=12]
setblock 132 84 332 minecraft:light[level=12]
setblock 132 84 339 minecraft:light[level=12]
setblock 132 84 346 minecraft:light[level=12]
setblock 132 84 353 minecraft:light[level=12]
setblock 132 84 360 minecraft:light[level=12]
fill 132 84 361 134 84 361 minecraft:stone
setblock 133 84 353 minecraft:stripped_spruce_log
fill 133 84 354 133 87 354 minecraft:stone
fill 133 84 356 134 84 356 minecraft:stone
setblock 133 84 358 minecraft:stripped_spruce_log
fill 133 84 359 133 87 359 minecraft:stone
setblock 133 84 363 minecraft:stripped_spruce_log
fill 134 84 333 134 84 336 minecraft:stone
setblock 134 84 337 minecraft:stripped_spruce_log
fill 134 84 338 135 85 339 minecraft:stone
setblock 134 84 348 minecraft:stone
setblock 134 84 351 minecraft:stone
setblock 134 84 352 minecraft:stripped_spruce_log
fill 134 84 353 134 87 353 minecraft:stone
setblock 134 84 357 minecraft:stripped_spruce_log
fill 134 84 358 134 87 358 minecraft:stone
setblock 134 84 362 minecraft:stripped_spruce_log
fill 134 84 363 134 87 363 minecraft:stone
fill 135 84 329 135 84 330 minecraft:stone
setblock 135 84 331 minecraft:stripped_spruce_log
fill 135 84 332 135 87 332 minecraft:stone
setblock 135 84 335 minecraft:stone
setblock 135 84 336 minecraft:stripped_spruce_log
fill 135 84 337 135 87 337 minecraft:stone
setblock 135 84 340 minecraft:stone
setblock 135 84 341 minecraft:stripped_spruce_log
fill 135 84 342 135 84 345 minecraft:stone
setblock 135 84 346 minecraft:stripped_spruce_log
fill 135 84 347 135 87 347 minecraft:stone
setblock 135 84 351 minecraft:stripped_spruce_log
fill 135 84 352 135 87 352 minecraft:stone
setblock 135 84 356 minecraft:stripped_spruce_log
fill 135 84 357 135 87 357 minecraft:stone
setblock 135 84 361 minecraft:stripped_spruce_log
fill 135 84 362 135 87 362 minecraft:stone
fill 136 84 344 136 99 344 minecraft:cobbled_deepslate
fill 94 85 346 94 105 346 minecraft:cobbled_deepslate
setblock 95 85 329 minecraft:stone
setblock 95 85 330 minecraft:stripped_spruce_log
fill 95 85 331 95 85 334 minecraft:stone
setblock 95 85 335 minecraft:stripped_spruce_log
fill 95 85 336 95 85 339 minecraft:stone
setblock 95 85 340 minecraft:stripped_spruce_log
fill 95 85 341 95 85 344 minecraft:stone
setblock 95 85 345 minecraft:stripped_spruce_log
fill 95 85 346 95 85 349 minecraft:stone
setblock 95 85 350 minecraft:stripped_spruce_log
fill 95 85 351 95 85 354 minecraft:stone
setblock 95 85 355 minecraft:stripped_spruce_log
fill 95 85 356 95 85 359 minecraft:stone
setblock 95 85 360 minecraft:stripped_spruce_log
fill 95 85 361 95 88 361 minecraft:stone
fill 96 85 331 96 85 333 minecraft:stone
setblock 96 85 334 minecraft:stripped_spruce_log
fill 96 85 335 96 85 338 minecraft:stone
setblock 96 85 339 minecraft:stripped_spruce_log
fill 96 85 340 96 85 343 minecraft:stone
setblock 96 85 344 minecraft:stripped_spruce_log
fill 96 85 345 96 85 348 minecraft:stone
setblock 96 85 349 minecraft:stripped_spruce_log
fill 96 85 350 96 85 353 minecraft:stone
setblock 96 85 354 minecraft:stripped_spruce_log
fill 96 85 355 96 85 358 minecraft:stone
setblock 96 85 359 minecraft:stripped_spruce_log
fill 96 85 360 96 88 360 minecraft:stone
setblock 96 85 363 minecraft:stone
setblock 97 85 333 minecraft:stripped_spruce_log
fill 97 85 334 97 86 334 minecraft:stone
setblock 97 85 338 minecraft:stripped_spruce_log
fill 97 85 339 97 88 339 minecraft:stone
setblock 97 85 363 minecraft:stripped_spruce_log
fill 101 85 360 101 92 360 minecraft:cobbled_deepslate
fill 105 85 325 105 89 325 minecraft:cobbled_deepslate
fill 106 85 324 106 89 324 minecraft:cobbled_deepslate
fill 106 85 326 106 89 326 minecraft:cobbled_deepslate
fill 107 85 325 107 89 325 minecraft:cobbled_deepslate
setblock 111 85 323 minecraft:stone
setblock 112 85 323 minecraft:stripped_spruce_log
setblock 112 85 363 minecraft:stripped_spruce_log
fill 113 85 323 116 85 323 minecraft:stone
setblock 113 85 362 minecraft:stripped_spruce_log
fill 113 85 363 116 85 363 minecraft:stone
fill 114 85 324 115 85 324 minecraft:stone
fill 114 85 362 117 85 362 minecraft:stone
setblock 116 85 324 minecraft:stripped_spruce_log
setblock 117 85 323 minecraft:stripped_spruce_log
setblock 117 85 324 minecraft:stone
setblock 117 85 363 minecraft:stripped_spruce_log
fill 118 85 323 120 86 323 minecraft:stone
setblock 118 85 362 minecraft:stripped_spruce_log
fill 118 85 363 121 85 363 minecraft:stone
fill 119 85 362 119 88 362 minecraft:stone
setblock 122 85 363 minecraft:stripped_spruce_log
fill 123 85 363 126 85 363 minecraft:stone
fill 126 85 322 126 107 322 minecraft:cobbled_deepslate
setblock 127 85 363 minecraft:stripped_spruce_log
fill 128 85 363 131 85 363 minecraft:stone
fill 129 85 362 132 85 362 minecraft:stone
fill 132 85 361 133 85 361 minecraft:stone
setblock 132 85 363 minecraft:stripped_spruce_log
setblock 133 85 352 minecraft:stripped_spruce_log
fill 133 85 353 133 87 353 minecraft:stone
setblock 133 85 356 minecraft:stone
setblock 133 85 357 minecraft:stripped_spruce_log
fill 133 85 358 133 88 358 minecraft:stone
setblock 133 85 362 minecraft:stripped_spruce_log
fill 133 85 363 133 88 363 minecraft:stone
fill 134 85 334 134 85 335 minecraft:stone
setblock 134 85 336 minecraft:stripped_spruce_log
fill 134 85 337 134 88 337 minecraft:stone
setblock 134 85 340 minecraft:stone
setblock 134 85 350 minecraft:stone
setblock 134 85 351 minecraft:stripped_spruce_log
fill 134 85 352 134 88 352 minecraft:stone
setblock 134 85 355 minecraft:stone
setblock 134 85 356 minecraft:stripped_spruce_log
fill 134 85 357 134 88 357 minecraft:stone
setblock 134 85 360 minecraft:stone
setblock 134 85 361 minecraft:stripped_spruce_log
fill 134 85 362 134 88 362 minecraft:stone
setblock 135 85 330 minecraft:stripped_spruce_log
fill 135 85 331 135 86 331 minecraft:stone
setblock 135 85 335 minecraft:stripped_spruce_log
fill 135 85 336 135 88 336 minecraft:stone
setblock 135 85 340 minecraft:stripped_spruce_log
fill 135 85 341 135 85 344 minecraft:stone
setblock 135 85 345 minecraft:stripped_spruce_log
fill 135 85 346 135 88 346 minecraft:stone
setblock 135 85 350 minecraft:stripped_spruce_log
fill 135 85 351 135 88 351 minecraft:stone
setblock 135 85 355 minecraft:stripped_spruce_log
fill 135 85 356 135 88 356 minecraft:stone
setblock 135 85 360 minecraft:stripped_spruce_log
fill 135 85 361 135 88 361 minecraft:stone
setblock 95 86 329 minecraft:stripped_spruce_log
fill 95 86 330 95 86 333 minecraft:stone
setblock 95 86 334 minecraft:stripped_spruce_log
fill 95 86 335 95 86 338 minecraft:stone
setblock 95 86 339 minecraft:stripped_spruce_log
fill 95 86 340 95 86 343 minecraft:stone
setblock 95 86 344 minecraft:stripped_spruce_log
fill 95 86 345 95 86 348 minecraft:stone
setblock 95 86 349 minecraft:stripped_spruce_log
fill 95 86 350 95 86 353 minecraft:stone
setblock 95 86 354 minecraft:stripped_spruce_log
fill 95 86 355 95 86 358 minecraft:stone
setblock 95 86 359 minecraft:stripped_spruce_log
fill 95 86 360 95 89 360 minecraft:stone
setblock 96 86 332 minecraft:stone
setblock 96 86 333 minecraft:stripped_spruce_log
fill 96 86 334 96 86 337 minecraft:stone
setblock 96 86 338 minecraft:stripped_spruce_log
fill 96 86 339 96 86 342 minecraft:stone
setblock 96 86 343 minecraft:stripped_spruce_log
fill 96 86 344 96 86 346 minecraft:stone
fill 96 86 350 96 86 352 minecraft:stone
setblock 96 86 353 minecraft:stripped_spruce_log
fill 96 86 354 96 86 357 minecraft:stone
setblock 96 86 358 minecraft:stripped_spruce_log
fill 96 86 359 96 89 359 minecraft:stone
setblock 96 86 363 minecraft:stripped_spruce_log
setblock 97 86 337 minecraft:stripped_spruce_log
fill 97 86 338 97 89 338 minecraft:stone
setblock 110 86 323 minecraft:stone
setblock 111 86 323 minecraft:stripped_spruce_log
setblock 111 86 363 minecraft:stripped_spruce_log
fill 112 86 323 115 86 323 minecraft:stone
fill 112 86 363 115 86 363 minecraft:stone
fill 113 86 324 114 86 324 minecraft:stone
fill 113 86 362 116 86 362 minecraft:stone
setblock 115 86 324 minecraft:stripped_spruce_log
setblock 116 86 323 minecraft:stripped_spruce_log
fill 116 86 324 116 89 324 minecraft:stone
setblock 116 86 363 minecraft:stripped_spruce_log
fill 117 86 323 117 89 323 minecraft:stone
setblock 117 86 362 minecraft:stripped_spruce_log
fill 117 86 363 120 86 363 minecraft:stone
fill 118 86 362 118 89 362 minecraft:stone
setblock 121 86 363 minecraft:stripped_spruce_log
fill 122 86 363 125 86 363 minecraft:stone
setblock 126 86 363 minecraft:stripped_spruce_log
fill 127 86 363 130 86 363 minecraft:stone
fill 129 86 362 131 86 362 minecraft:stone
fill 131 86 361 132 86 361 minecraft:stone
setblock 131 86 363 minecraft:stripped_spruce_log
setblock 132 86 362 minecraft:stripped_spruce_log
fill 132 86 363 132 89 363 minecraft:stone
setblock 133 86 356 minecraft:stripped_spruce_log
fill 133 86 357 133 89 357 minecraft:stone
setblock 133 86 361 minecraft:stripped_spruce_log
fill 133 86 362 133 89 362 minecraft:stone
setblock 134 86 334 minecraft:stone
setblock 134 86 335 minecraft:stripped_spruce_log
fill 134 86 336 134 89 336 minecraft:stone
fill 134 86 338 134 86 339 minecraft:stone
setblock 134 86 340 minecraft:stripped_spruce_log
fill 134 86 341 135 87 342 minecraft:stone
setblock 134 86 350 minecraft:stripped_spruce_log
fill 134 86 351 134 89 351 minecraft:stone
setblock 134 86 355 minecraft:stripped_spruce_log
fill 134 86 356 134 89 356 minecraft:stone
setblock 134 86 360 minecraft:stripped_spruce_log
fill 134 86 361 134 89 361 minecraft:stone
setblock 135 86 334 minecraft:stripped_spruce_log
fill 135 86 335 135 89 335 minecraft:stone
setblock 135 86 338 minecraft:stone
setblock 135 86 339 minecraft:stripped_spruce_log
fill 135 86 340 135 89 340 minecraft:stone
setblock 135 86 343 minecraft:stone
setblock 135 86 344 minecraft:stripped_spruce_log
fill 135 86 345 135 89 345 minecraft:stone
setblock 135 86 349 minecraft:stripped_spruce_log
fill 135 86 350 135 89 350 minecraft:stone
setblock 135 86 354 minecraft:stripped_spruce_log
fill 135 86 355 135 89 355 minecraft:stone
setblock 135 86 359 minecraft:stripped_spruce_log
fill 135 86 360 135 89 360 minecraft:stone
setblock 136 86 349 minecraft:gold_block
fill 95 87 330 95 87 332 minecraft:stone
setblock 95 87 333 minecraft:stripped_spruce_log
fill 95 87 334 95 87 337 minecraft:stone
setblock 95 87 338 minecraft:stripped_spruce_log
fill 95 87 339 95 87 342 minecraft:stone
setblock 95 87 343 minecraft:stripped_spruce_log
fill 95 87 344 95 87 347 minecraft:stone
setblock 95 87 348 minecraft:stripped_spruce_log
fill 95 87 349 95 87 352 minecraft:stone
setblock 95 87 353 minecraft:stripped_spruce_log
fill 95 87 354 95 87 357 minecraft:stone
setblock 95 87 358 minecraft:stripped_spruce_log
fill 95 87 359 95 90 359 minecraft:stone
setblock 95 87 362 minecraft:stone
setblock 95 87 363 minecraft:stripped_spruce_log
setblock 96 87 332 minecraft:stripped_spruce_log
fill 96 87 333 96 87 336 minecraft:stone
setblock 96 87 337 minecraft:stripped_spruce_log
fill 96 87 338 96 87 341 minecraft:stone
setblock 96 87 342 minecraft:stripped_spruce_log
fill 96 87 343 96 88 345 minecraft:stone
fill 96 87 347 97 88 347 minecraft:iron_bars
fill 96 87 353 96 87 356 minecraft:stone
setblock 96 87 357 minecraft:stripped_spruce_log
fill 96 87 358 96 90 358 minecraft:stone
fill 96 87 363 97 89 363 minecraft:stone
setblock 97 87 336 minecraft:stripped_spruce_log
fill 97 87 337 97 90 337 minecraft:stone
setblock 97 87 341 minecraft:stripped_spruce_log
setblock 109 87 323 minecraft:stone
setblock 110 87 323 minecraft:stripped_spruce_log
setblock 110 87 363 minecraft:stripped_spruce_log
fill 111 87 323 114 87 323 minecraft:stone
fill 111 87 363 114 87 363 minecraft:stone
fill 112 87 324 113 87 324 minecraft:stone
fill 112 87 362 115 87 362 minecraft:stone
setblock 114 87 324 minecraft:stripped_spruce_log
setblock 115 87 323 minecraft:stripped_spruce_log
fill 115 87 324 115 90 324 minecraft:stone
fill 115 87 361 116 87 361 minecraft:stone
setblock 115 87 363 minecraft:stripped_spruce_log
fill 116 87 323 116 90 323 minecraft:stone
setblock 116 87 362 minecraft:stripped_spruce_log
fill 116 87 363 119 87 363 minecraft:stone
fill 117 87 362 117 90 362 minecraft:stone
fill 118 87 323 119 87 323 minecraft:stone
setblock 120 87 323 minecraft:stripped_spruce_log
setblock 120 87 363 minecraft:stripped_spruce_log
fill 121 87 363 124 87 363 minecraft:stone
fill 123 87 322 123 103 322 minecraft:cobbled_deepslate
setblock 124 87 322 minecraft:gold_block
setblock 125 87 363 minecraft:stripped_spruce_log
fill 126 87 363 129 87 363 minecraft:stone
fill 127 87 362 130 87 362 minecraft:stone
fill 130 87 361 131 87 361 minecraft:stone
setblock 130 87 363 minecraft:stripped_spruce_log
setblock 131 87 362 minecraft:stripped_spruce_log
fill 131 87 363 131 90 363 minecraft:stone
fill 132 87 358 132 89 358 minecraft:stone
setblock 132 87 361 minecraft:stripped_spruce_log
fill 132 87 362 132 90 362 minecraft:stone
setblock 133 87 355 minecraft:stripped_spruce_log
fill 133 87 356 133 90 356 minecraft:stone
setblock 133 87 360 minecraft:stripped_spruce_log
fill 133 87 361 133 90 361 minecraft:stone
fill 134 87 335 134 90 335 minecraft:stone
setblock 134 87 338 minecraft:stone
setblock 134 87 339 minecraft:stripped_spruce_log
fill 134 87 340 134 90 340 minecraft:stone
setblock 134 87 343 minecraft:stone
setblock 134 87 344 minecraft:stripped_spruce_log
setblock 134 87 349 minecraft:stripped_spruce_log
fill 134 87 350 134 90 350 minecraft:stone
setblock 134 87 354 minecraft:stripped_spruce_log
fill 134 87 355 134 90 355 minecraft:stone
setblock 134 87 359 minecraft:stripped_spruce_log
fill 134 87 360 134 90 360 minecraft:stone
setblock 135 87 322 minecraft:gold_block
setblock 135 87 333 minecraft:stripped_spruce_log
fill 135 87 334 135 90 334 minecraft:stone
setblock 135 87 338 minecraft:stripped_spruce_log
fill 135 87 339 135 90 339 minecraft:stone
setblock 135 87 343 minecraft:stripped_spruce_log
fill 135 87 344 135 90 344 minecraft:stone
setblock 135 87 348 minecraft:stripped_spruce_log
fill 135 87 349 135 90 349 minecraft:stone
setblock 135 87 353 minecraft:stripped_spruce_log
fill 135 87 354 135 90 354 minecraft:stone
setblock 135 87 358 minecraft:stripped_spruce_log
fill 135 87 359 135 90 359 minecraft:stone
setblock 135 87 363 minecraft:stripped_spruce_log
fill 136 87 349 136 104 349 minecraft:cobbled_deepslate
fill 95 88 330 95 88 331 minecraft:stone
setblock 95 88 332 minecraft:stripped_spruce_log
fill 95 88 333 95 88 336 minecraft:stone
setblock 95 88 337 minecraft:stripped_spruce_log
fill 95 88 338 95 88 341 minecraft:stone
setblock 95 88 342 minecraft:stripped_spruce_log
fill 95 88 343 95 88 346 minecraft:stone
setblock 95 88 347 minecraft:stripped_spruce_log
fill 95 88 348 95 88 351 minecraft:stone
setblock 95 88 352 minecraft:stripped_spruce_log
fill 95 88 353 95 88 356 minecraft:stone
setblock 95 88 357 minecraft:stripped_spruce_log
fill 95 88 358 95 91 358 minecraft:stone
setblock 95 88 362 minecraft:stripped_spruce_log
fill 95 88 363 95 91 363 minecraft:stone
fill 96 88 333 96 88 335 minecraft:stone
setblock 96 88 336 minecraft:stripped_spruce_log
fill 96 88 337 96 88 340 minecraft:stone
setblock 96 88 341 minecraft:stripped_spruce_log
fill 96 88 342 97 90 342 minecraft:stone
setblock 96 88 346 minecraft:stripped_spruce_log
setblock 96 88 355 minecraft:stone
setblock 96 88 356 minecraft:stripped_spruce_log
fill 96 88 357 96 89 357 minecraft:stone
setblock 96 88 361 minecraft:stripped_spruce_log
setblock 97 88 335 minecraft:stripped_spruce_log
fill 97 88 336 97 91 336 minecraft:stone
setblock 97 88 340 minecraft:stripped_spruce_log
fill 97 88 341 97 91 341 minecraft:stone
setblock 108 88 323 minecraft:stone
setblock 108 88 363 minecraft:stone
setblock 109 88 323 minecraft:stripped_spruce_log
setblock 109 88 363 minecraft:stripped_spruce_log
fill 110 88 323 113 88 323 minecraft:stone
setblock 110 88 362 minecraft:stripped_spruce_log
fill 110 88 363 113 88 363 minecraft:stone
fill 111 88 324 112 88 324 minecraft:stone
fill 111 88 362 114 88 362 minecraft:stone
setblock 113 88 324 minecraft:stripped_spruce_log
fill 113 88 361 115 88 361 minecraft:stone
setblock 114 88 323 minecraft:stripped_spruce_log
fill 114 88 324 114 91 324 minecraft:stone
setblock 114 88 363 minecraft:stripped_spruce_log
fill 115 88 323 115 91 323 minecraft:stone
setblock 115 88 362 minecraft:stripped_spruce_log
fill 115 88 363 118 88 363 minecraft:stone
setblock 116 88 361 minecraft:stripped_spruce_log
fill 116 88 362 116 91 362 minecraft:stone
fill 117 88 361 117 91 361 minecraft:stone
setblock 118 88 323 minecraft:stone
setblock 119 88 323 minecraft:stripped_spruce_log
setblock 119 88 363 minecraft:stripped_spruce_log
fill 120 88 323 120 91 323 minecraft:stone
setblock 120 88 362 minecraft:stripped_spruce_log
fill 120 88 363 123 88 363 minecraft:stone
fill 121 88 362 122 90 362 minecraft:stone
fill 124 88 322 124 97 322 minecraft:cobbled_deepslate
setblock 124 88 363 minecraft:stripped_spruce_log
setblock 125 88 362 minecraft:stripped_spruce_log
fill 125 88 363 128 88 363 minecraft:stone
fill 126 88 362 129 88 362 minecraft:stone
fill 129 88 361 130 88 361 minecraft:stone
setblock 129 88 363 minecraft:stripped_spruce_log
setblock 130 88 362 minecraft:stripped_spruce_log
fill 130 88 363 130 91 363 minecraft:stone
setblock 131 88 361 minecraft:stripped_spruce_log
fill 131 88 362 131 91 362 minecraft:stone
fill 132 88 323 133 88 323 minecraft:stone
setblock 132 88 359 minecraft:stone
setblock 132 88 360 minecraft:stripped_spruce_log
fill 132 88 361 132 91 361 minecraft:stone
setblock 133 88 354 minecraft:stripped_spruce_log
fill 133 88 355 133 91 355 minecraft:stone
setblock 133 88 359 minecraft:stripped_spruce_log
fill 133 88 360 133 91 360 minecraft:stone
setblock 134 88 338 minecraft:stripped_spruce_log
fill 134 88 339 134 91 339 minecraft:stone
fill 134 88 341 134 88 342 minecraft:stone
setblock 134 88 343 minecraft:stripped_spruce_log
fill 134 88 344 134 88 347 minecraft:stone
setblock 134 88 348 minecraft:stripped_spruce_log
fill 134 88 349 134 91 349 minecraft:stone
setblock 134 88 353 minecraft:stripped_spruce_log
fill 134 88 354 134 91 354 minecraft:stone
setblock 134 88 358 minecraft:stripped_spruce_log
fill 134 88 359 134 91 359 minecraft:stone
setblock 134 88 363 minecraft:stripped_spruce_log
fill 135 88 322 135 104 322 minecraft:cobbled_deepslate
setblock 135 88 332 minecraft:stripped_spruce_log
fill 135 88 333 135 91 333 minecraft:stone
setblock 135 88 337 minecraft:stripped_spruce_log
fill 135 88 338 135 91 338 minecraft:stone
setblock 135 88 341 minecraft:stone
setblock 135 88 342 minecraft:stripped_spruce_log
fill 135 88 343 135 91 343 minecraft:stone
setblock 135 88 347 minecraft:stripped_spruce_log
fill 135 88 348 135 91 348 minecraft:stone
setblock 135 88 352 minecraft:stripped_spruce_log
fill 135 88 353 135 91 353 minecraft:stone
setblock 135 88 357 minecraft:stripped_spruce_log
fill 135 88 358 135 91 358 minecraft:stone
setblock 135 88 362 minecraft:stripped_spruce_log
fill 135 88 363 135 91 363 minecraft:stone
setblock 95 89 330 minecraft:stone
setblock 95 89 331 minecraft:stripped_spruce_log
fill 95 89 332 95 89 335 minecraft:stone
setblock 95 89 336 minecraft:stripped_spruce_log
fill 95 89 337 95 89 340 minecraft:stone
setblock 95 89 341 minecraft:stripped_spruce_log
fill 95 89 342 95 89 345 minecraft:stone
setblock 95 89 346 minecraft:stripped_spruce_log
fill 95 89 347 95 89 350 minecraft:stone
setblock 95 89 351 minecraft:stripped_spruce_log
fill 95 89 352 95 89 355 minecraft:stone
setblock 95 89 356 minecraft:stripped_spruce_log
fill 95 89 357 95 92 357 minecraft:stone
setblock 95 89 361 minecraft:stripped_spruce_log
fill 95 89 362 95 92 362 minecraft:stone
fill 96 89 333 96 89 334 minecraft:stone
setblock 96 89 335 minecraft:stripped_spruce_log
fill 96 89 336 96 89 339 minecraft:stone
setblock 96 89 340 minecraft:stripped_spruce_log
fill 96 89 341 96 92 341 minecraft:stone
fill 96 89 343 96 89 344 minecraft:stone
setblock 96 89 345 minecraft:stripped_spruce_log
fill 96 89 346 96 92 346 minecraft:stone
setblock 96 89 360 minecraft:stripped_spruce_log
fill 96 89 361 96 91 361 minecraft:stone
setblock 97 89 339 minecraft:stripped_spruce_log
fill 97 89 340 97 92 340 minecraft:stone
fill 100 89 360 100 92 360 minecraft:cobbled_deepslate
fill 101 89 359 101 92 359 minecraft:cobbled_deepslate
fill 101 89 361 101 92 361 minecraft:cobbled_deepslate
fill 102 89 360 102 92 360 minecraft:cobbled_deepslate
setblock 105 89 324 minecraft:cobbled_deepslate
setblock 105 89 326 minecraft:cobbled_deepslate
setblock 107 89 323 minecraft:stone
setblock 107 89 324 minecraft:cobbled_deepslate
setblock 107 89 326 minecraft:cobbled_deepslate
setblock 107 89 363 minecraft:stone
setblock 108 89 323 minecraft:stripped_spruce_log
setblock 108 89 363 minecraft:stripped_spruce_log
fill 109 89 323 111 89 324 minecraft:stone
setblock 109 89 362 minecraft:stripped_spruce_log
fill 109 89 363 112 89 363 minecraft:stone
fill 110 89 362 113 89 362 minecraft:stone
setblock 112 89 323 minecraft:stone
setblock 112 89 324 minecraft:stripped_spruce_log
fill 112 89 361 114 89 361 minecraft:stone
setblock 113 89 323 minecraft:stripped_spruce_log
fill 113 89 324 113 92 324 minecraft:stone
setblock 113 89 363 minecraft:stripped_spruce_log
fill 114 89 323 114 92 323 minecraft:stone
setblock 114 89 362 minecraft:stripped_spruce_log
fill 114 89 363 117 89 363 minecraft:stone
setblock 115 89 361 minecraft:stripped_spruce_log
fill 115 89 362 115 90 362 minecraft:stone
fill 116 89 361 116 92 361 minecraft:stone
setblock 117 89 324 minecraft:stripped_spruce_log
setblock 118 89 323 minecraft:stripped_spruce_log
fill 118 89 361 118 90 361 minecraft:stone
setblock 118 89 363 minecraft:stripped_spruce_log
fill 119 89 323 119 92 323 minecraft:stone
setblock 119 89 362 minecraft:stripped_spruce_log
fill 119 89 363 122 89 363 minecraft:stone
fill 120 89 362 120 92 362 minecraft:stone
setblock 123 89 362 minecraft:stone
setblock 123 89 363 minecraft:stripped_spruce_log
setblock 124 89 362 minecraft:stripped_spruce_log
fill 124 89 363 127 89 363 minecraft:stone
fill 125 89 362 128 89 362 minecraft:stone
fill 127 89 361 129 89 361 minecraft:stone
setblock 128 89 363 minecraft:stripped_spruce_log
fill 129 89 323 132 89 323 minecraft:stone
setblock 129 89 362 minecraft:stripped_spruce_log
fill 129 89 363 129 92 363 minecraft:stone
setblock 130 89 361 minecraft:stripped_spruce_log
fill 130 89 362 130 92 362 minecraft:stone
setblock 131 89 360 minecraft:stripped_spruce_log
fill 131 89 361 131 92 361 minecraft:stone
fill 132 89 357 132 90 357 minecraft:stone
setblock 132 89 359 minecraft:stripped_spruce_log
fill 132 89 360 132 92 360 minecraft:stone
setblock 133 89 323 minecraft:stripped_spruce_log
setblock 133 89 338 minecraft:stripped_spruce_log
fill 133 89 339 133 89 342 minecraft:stone
fill 133 89 354 133 92 354 minecraft:stone
setblock 133 89 358 minecraft:stripped_spruce_log
fill 133 89 359 133 92 359 minecraft:stone
setblock 133 89 363 minecraft:stripped_spruce_log
fill 134 89 323 135 91 323 minecraft:stone
setblock 134 89 337 minecraft:stripped_spruce_log
fill 134 89 338 134 92 338 minecraft:stone
setblock 134 89 341 minecraft:stone
setblock 134 89 342 minecraft:stripped_spruce_log
fill 134 89 343 134 89 346 minecraft:stone
setblock 134 89 347 minecraft:stripped_spruce_log
fill 134 89 348 134 92 348 minecraft:stone
setblock 134 89 352 minecraft:stripped_spruce_log
fill 134 89 353 134 92 353 minecraft:stone
setblock 134 89 357 minecraft:stripped_spruce_log
fill 134 89 358 134 92 358 minecraft:stone
setblock 134 89 362 minecraft:stripped_spruce_log
fill 134 89 363 134 92 363 minecraft:stone
setblock 135 89 332 minecraft:stone
setblock 135 89 336 minecraft:stripped_spruce_log
fill 135 89 337 135 92 337 minecraft:stone
setblock 135 89 341 minecraft:stripped_spruce_log
fill 135 89 342 135 92 342 minecraft:stone
setblock 135 89 346 minecraft:stripped_spruce_log
fill 135 89 347 135 92 347 minecraft:stone
setblock 135 89 351 minecraft:stripped_spruce_log
fill 135 89 352 135 92 352 minecraft:stone
setblock 135 89 356 minecraft:stripped_spruce_log
fill 135 89 357 135 92 357 minecraft:stone
setblock 135 89 361 minecraft:stripped_spruce_log
fill 135 89 362 135 92 362 minecraft:stone
fill 136 89 330 136 107 330 minecraft:cobbled_deepslate
setblock 136 89 331 minecraft:diamond_block
setblock 136 89 356 minecraft:raw_iron_block
fill 94 90 357 94 107 357 minecraft:cobbled_deepslate
setblock 94 90 358 minecraft:gold_block
fill 94 90 359 94 107 359 minecraft:cobbled_deepslate
fill 95 90 323 95 90 324 minecraft:stone
setblock 95 90 330 minecraft:stripped_spruce_log
fill 95 90 331 95 90 334 minecraft:stone
setblock 95 90 335 minecraft:stripped_spruce_log
fill 95 90 336 95 90 339 minecraft:stone
setblock 95 90 340 minecraft:stripped_spruce_log
fill 95 90 341 95 90 344 minecraft:stone
setblock 95 90 345 minecraft:stripped_spruce_log
fill 95 90 346 95 90 349 minecraft:stone
setblock 95 90 350 minecraft:stripped_spruce_log
fill 95 90 351 95 90 354 minecraft:stone
setblock 95 90 355 minecraft:stripped_spruce_log
fill 95 90 356 95 93 356 minecraft:stone
setblock 95 90 360 minecraft:stripped_spruce_log
fill 95 90 361 95 93 361 minecraft:stone
setblock 96 90 323 minecraft:stone
setblock 96 90 333 minecraft:stone
setblock 96 90 334 minecraft:stripped_spruce_log
fill 96 90 335 96 90 338 minecraft:stone
setblock 96 90 339 minecraft:stripped_spruce_log
fill 96 90 340 96 93 340 minecraft:stone
setblock 96 90 343 minecraft:stone
setblock 96 90 344 minecraft:stripped_spruce_log
fill 96 90 345 96 93 345 minecraft:stone
fill 96 90 347 96 91 347 minecraft:stone
setblock 96 90 359 minecraft:stripped_spruce_log
fill 96 90 360 96 91 360 minecraft:stone
setblock 96 90 363 minecraft:stone
setblock 97 90 325 minecraft:light[level=15]
setblock 97 90 332 minecraft:light[level=12]
setblock 97 90 333 minecraft:light[level=15]
setblock 97 90 338 minecraft:stripped_spruce_log
fill 97 90 339 97 93 339 minecraft:stone
setblock 97 90 343 minecraft:stripped_spruce_log
setblock 97 90 346 minecraft:light[level=12]
setblock 97 90 349 minecraft:light[level=15]
setblock 97 90 353 minecraft:light[level=12]
schedule function dropper:buildpart/74_2 1t
