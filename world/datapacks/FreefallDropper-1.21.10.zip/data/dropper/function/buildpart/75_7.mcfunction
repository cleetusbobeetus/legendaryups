setblock 171 123 323 minecraft:dark_prismarine
fill 171 123 324 171 126 324 minecraft:blue_terracotta
setblock 171 123 363 minecraft:dark_prismarine
fill 172 123 323 172 126 323 minecraft:blue_terracotta
setblock 172 123 362 minecraft:dark_prismarine
fill 172 123 363 172 126 363 minecraft:blue_terracotta
setblock 173 123 361 minecraft:dark_prismarine
fill 173 123 362 173 126 362 minecraft:blue_terracotta
fill 174 123 361 175 125 361 minecraft:blue_terracotta
setblock 175 123 324 minecraft:dark_prismarine
setblock 176 123 323 minecraft:dark_prismarine
setblock 176 123 363 minecraft:dark_prismarine
fill 177 123 323 177 126 323 minecraft:blue_terracotta
fill 177 123 328 177 124 330 minecraft:black_concrete
setblock 177 123 362 minecraft:dark_prismarine
fill 177 123 363 177 126 363 minecraft:blue_terracotta
fill 178 123 327 180 124 327 minecraft:black_concrete
fill 178 123 331 180 124 331 minecraft:black_concrete
fill 178 123 362 181 123 362 minecraft:blue_terracotta
fill 181 123 328 181 124 330 minecraft:black_concrete
fill 181 123 356 181 123 357 minecraft:blue_terracotta
setblock 181 123 358 minecraft:dark_prismarine
fill 181 123 359 181 126 359 minecraft:blue_terracotta
fill 181 123 361 182 123 361 minecraft:blue_terracotta
setblock 181 123 363 minecraft:dark_prismarine
setblock 182 123 333 minecraft:purple_concrete
fill 182 123 353 182 126 353 minecraft:blue_terracotta
setblock 182 123 357 minecraft:dark_prismarine
fill 182 123 358 182 126 358 minecraft:blue_terracotta
fill 182 123 360 182 124 360 minecraft:blue_terracotta
setblock 182 123 362 minecraft:dark_prismarine
fill 182 123 363 182 126 363 minecraft:blue_terracotta
fill 141 124 333 141 131 333 minecraft:black_concrete
fill 141 124 358 141 131 358 minecraft:black_concrete
setblock 142 124 334 minecraft:purple_concrete
setblock 142 124 335 minecraft:blue_terracotta
setblock 142 124 336 minecraft:dark_prismarine
fill 142 124 337 142 124 340 minecraft:blue_terracotta
setblock 142 124 341 minecraft:dark_prismarine
setblock 142 124 350 minecraft:blue_terracotta
setblock 142 124 351 minecraft:dark_prismarine
fill 142 124 352 143 126 352 minecraft:blue_terracotta
setblock 142 124 356 minecraft:dark_prismarine
fill 142 124 357 142 127 357 minecraft:blue_terracotta
setblock 142 124 360 minecraft:blue_terracotta
setblock 142 124 361 minecraft:dark_prismarine
fill 142 124 362 144 124 363 minecraft:blue_terracotta
setblock 143 124 355 minecraft:dark_prismarine
fill 143 124 356 143 127 356 minecraft:blue_terracotta
setblock 143 124 360 minecraft:dark_prismarine
fill 143 124 361 143 127 361 minecraft:blue_terracotta
setblock 144 124 354 minecraft:dark_prismarine
fill 144 124 355 144 127 355 minecraft:blue_terracotta
setblock 144 124 359 minecraft:dark_prismarine
fill 144 124 360 144 127 360 minecraft:blue_terracotta
setblock 145 124 362 minecraft:blue_terracotta
setblock 145 124 363 minecraft:dark_prismarine
setblock 146 124 361 minecraft:blue_terracotta
setblock 146 124 362 minecraft:dark_prismarine
fill 146 124 363 146 127 363 minecraft:blue_terracotta
setblock 147 124 361 minecraft:dark_prismarine
fill 147 124 362 150 124 362 minecraft:blue_terracotta
fill 148 124 361 148 127 361 minecraft:blue_terracotta
setblock 149 124 323 minecraft:blue_terracotta
setblock 150 124 323 minecraft:dark_prismarine
setblock 150 124 363 minecraft:dark_prismarine
fill 151 124 323 153 125 323 minecraft:blue_terracotta
setblock 151 124 362 minecraft:dark_prismarine
fill 151 124 363 151 127 363 minecraft:blue_terracotta
setblock 152 124 361 minecraft:dark_prismarine
fill 152 124 362 152 127 362 minecraft:blue_terracotta
fill 154 124 362 154 125 362 minecraft:blue_terracotta
setblock 155 124 336 minecraft:dark_oak_planks
setblock 155 124 348 minecraft:dark_oak_planks
setblock 155 124 363 minecraft:dark_prismarine
setblock 157 124 363 minecraft:purple_concrete
fill 161 124 323 161 125 323 minecraft:purple_concrete
setblock 165 124 323 minecraft:dark_prismarine
setblock 165 124 363 minecraft:dark_prismarine
fill 166 124 323 166 127 323 minecraft:blue_terracotta
fill 166 124 363 166 127 363 minecraft:blue_terracotta
fill 167 124 324 168 124 324 minecraft:blue_terracotta
setblock 167 124 336 minecraft:dark_oak_planks
setblock 167 124 348 minecraft:dark_oak_planks
fill 167 124 362 170 124 362 minecraft:blue_terracotta
setblock 169 124 324 minecraft:dark_prismarine
fill 169 124 361 171 124 361 minecraft:blue_terracotta
setblock 170 124 323 minecraft:dark_prismarine
fill 170 124 324 170 126 325 minecraft:blue_terracotta
setblock 170 124 363 minecraft:dark_prismarine
fill 171 124 323 171 127 323 minecraft:blue_terracotta
fill 171 124 325 172 124 325 minecraft:blue_terracotta
setblock 171 124 362 minecraft:dark_prismarine
fill 171 124 363 171 127 363 minecraft:blue_terracotta
setblock 172 124 361 minecraft:dark_prismarine
fill 172 124 362 172 127 362 minecraft:blue_terracotta
fill 173 124 347 174 162 348 minecraft:dark_prismarine
fill 173 124 361 173 127 361 minecraft:blue_terracotta
setblock 174 124 324 minecraft:dark_prismarine
fill 174 124 346 174 162 346 minecraft:dark_prismarine
setblock 175 124 323 minecraft:dark_prismarine
fill 175 124 324 175 127 324 minecraft:blue_terracotta
fill 175 124 347 175 162 347 minecraft:dark_prismarine
setblock 175 124 362 minecraft:blue_terracotta
setblock 175 124 363 minecraft:dark_prismarine
fill 176 124 323 176 127 323 minecraft:blue_terracotta
fill 176 124 328 176 124 330 minecraft:black_concrete
setblock 176 124 361 minecraft:blue_terracotta
setblock 176 124 362 minecraft:dark_prismarine
fill 176 124 363 176 127 363 minecraft:blue_terracotta
setblock 177 124 327 minecraft:black_concrete
setblock 177 124 331 minecraft:black_concrete
setblock 177 124 361 minecraft:dark_prismarine
fill 177 124 362 180 124 362 minecraft:blue_terracotta
fill 178 124 326 180 124 326 minecraft:black_concrete
setblock 179 124 323 minecraft:blue_terracotta
setblock 179 124 332 minecraft:black_concrete
setblock 179 124 363 minecraft:blue_terracotta
setblock 180 124 363 minecraft:dark_prismarine
setblock 181 124 327 minecraft:black_concrete
setblock 181 124 331 minecraft:black_concrete
fill 181 124 355 181 124 356 minecraft:blue_terracotta
setblock 181 124 357 minecraft:dark_prismarine
fill 181 124 358 181 127 358 minecraft:blue_terracotta
setblock 181 124 361 minecraft:blue_terracotta
setblock 181 124 362 minecraft:dark_prismarine
fill 181 124 363 181 127 363 minecraft:blue_terracotta
setblock 182 124 327 minecraft:purple_concrete
fill 182 124 328 182 124 330 minecraft:black_concrete
setblock 182 124 336 minecraft:dark_prismarine
setblock 182 124 352 minecraft:purple_concrete
setblock 182 124 356 minecraft:dark_prismarine
fill 182 124 357 182 127 357 minecraft:blue_terracotta
setblock 182 124 361 minecraft:dark_prismarine
fill 182 124 362 182 127 362 minecraft:blue_terracotta
setblock 142 125 335 minecraft:dark_prismarine
fill 142 125 336 142 125 339 minecraft:blue_terracotta
setblock 142 125 340 minecraft:dark_prismarine
fill 142 125 341 142 125 344 minecraft:blue_terracotta
setblock 142 125 349 minecraft:blue_terracotta
setblock 142 125 350 minecraft:dark_prismarine
fill 142 125 351 142 128 351 minecraft:blue_terracotta
setblock 142 125 355 minecraft:dark_prismarine
fill 142 125 356 142 128 356 minecraft:blue_terracotta
setblock 142 125 360 minecraft:dark_prismarine
fill 142 125 361 142 126 363 minecraft:blue_terracotta
fill 143 125 337 143 125 338 minecraft:blue_terracotta
setblock 143 125 339 minecraft:dark_prismarine
fill 143 125 340 143 127 341 minecraft:blue_terracotta
setblock 143 125 354 minecraft:dark_prismarine
fill 143 125 355 143 128 355 minecraft:blue_terracotta
setblock 143 125 359 minecraft:dark_prismarine
fill 143 125 360 143 128 360 minecraft:blue_terracotta
fill 143 125 362 143 125 363 minecraft:blue_terracotta
setblock 144 125 325 minecraft:light[level=13]
setblock 144 125 332 minecraft:light[level=12]
setblock 144 125 333 minecraft:light[level=13]
setblock 144 125 339 minecraft:light[level=12]
setblock 144 125 341 minecraft:light[level=13]
setblock 144 125 346 minecraft:light[level=12]
setblock 144 125 349 minecraft:light[level=13]
setblock 144 125 353 minecraft:light[level=12]
setblock 144 125 354 minecraft:blue_terracotta
setblock 144 125 358 minecraft:dark_prismarine
fill 144 125 359 144 128 359 minecraft:blue_terracotta
fill 144 125 361 144 125 362 minecraft:blue_terracotta
setblock 144 125 363 minecraft:dark_prismarine
setblock 145 125 361 minecraft:blue_terracotta
setblock 145 125 362 minecraft:dark_prismarine
fill 145 125 363 145 128 363 minecraft:blue_terracotta
setblock 146 125 361 minecraft:dark_prismarine
fill 146 125 362 149 125 362 minecraft:blue_terracotta
fill 147 125 323 148 125 323 minecraft:blue_terracotta
fill 147 125 361 147 128 361 minecraft:blue_terracotta
fill 148 125 360 149 126 360 minecraft:blue_terracotta
setblock 149 125 323 minecraft:dark_prismarine
fill 149 125 361 150 125 361 minecraft:blue_terracotta
setblock 149 125 363 minecraft:dark_prismarine
fill 150 125 323 150 128 323 minecraft:blue_terracotta
setblock 150 125 362 minecraft:dark_prismarine
fill 150 125 363 150 128 363 minecraft:blue_terracotta
setblock 151 125 325 minecraft:light[level=12]
setblock 151 125 332 minecraft:light[level=12]
setblock 151 125 346 minecraft:light[level=12]
setblock 151 125 353 minecraft:light[level=12]
setblock 151 125 360 minecraft:light[level=12]
setblock 151 125 361 minecraft:dark_prismarine
fill 151 125 362 151 128 362 minecraft:blue_terracotta
setblock 152 125 325 minecraft:light[level=13]
setblock 152 125 333 minecraft:light[level=13]
setblock 152 125 349 minecraft:light[level=13]
setblock 152 125 357 minecraft:light[level=13]
fill 152 125 361 152 126 361 minecraft:blue_terracotta
setblock 153 125 363 minecraft:blue_terracotta
setblock 154 125 323 minecraft:dark_prismarine
setblock 154 125 363 minecraft:dark_prismarine
setblock 155 125 323 minecraft:purple_concrete
fill 155 125 363 156 127 363 minecraft:blue_terracotta
fill 157 125 358 157 193 358 minecraft:magenta_terracotta
setblock 158 125 325 minecraft:light[level=12]
setblock 158 125 332 minecraft:light[level=12]
setblock 158 125 339 minecraft:light[level=12]
setblock 158 125 346 minecraft:light[level=12]
setblock 158 125 353 minecraft:light[level=12]
setblock 158 125 360 minecraft:light[level=12]
setblock 160 125 325 minecraft:light[level=13]
setblock 160 125 333 minecraft:light[level=13]
setblock 160 125 341 minecraft:light[level=13]
setblock 160 125 349 minecraft:light[level=13]
setblock 160 125 357 minecraft:light[level=13]
setblock 163 125 323 minecraft:blue_terracotta
setblock 163 125 363 minecraft:blue_terracotta
setblock 164 125 323 minecraft:dark_prismarine
setblock 164 125 363 minecraft:dark_prismarine
fill 165 125 323 165 128 323 minecraft:blue_terracotta
setblock 165 125 325 minecraft:light[level=12]
fill 165 125 329 166 135 330 minecraft:magenta_terracotta
setblock 165 125 332 minecraft:light[level=12]
setblock 165 125 339 minecraft:light[level=12]
setblock 165 125 346 minecraft:light[level=12]
setblock 165 125 353 minecraft:light[level=12]
setblock 165 125 360 minecraft:light[level=12]
setblock 165 125 362 minecraft:dark_prismarine
fill 165 125 363 165 128 363 minecraft:blue_terracotta
fill 166 125 324 167 125 324 minecraft:blue_terracotta
fill 166 125 362 169 125 362 minecraft:blue_terracotta
fill 167 125 361 170 125 361 minecraft:blue_terracotta
setblock 168 125 324 minecraft:dark_prismarine
setblock 168 125 325 minecraft:light[level=13]
setblock 168 125 333 minecraft:light[level=13]
setblock 168 125 341 minecraft:light[level=13]
setblock 168 125 349 minecraft:light[level=13]
setblock 168 125 357 minecraft:light[level=13]
setblock 168 125 363 minecraft:blue_terracotta
setblock 169 125 323 minecraft:dark_prismarine
fill 169 125 324 169 127 325 minecraft:blue_terracotta
setblock 169 125 363 minecraft:dark_prismarine
fill 170 125 323 170 128 323 minecraft:blue_terracotta
setblock 170 125 362 minecraft:dark_prismarine
fill 170 125 363 170 128 363 minecraft:blue_terracotta
setblock 171 125 325 minecraft:blue_terracotta
setblock 171 125 360 minecraft:blue_terracotta
setblock 171 125 361 minecraft:dark_prismarine
fill 171 125 362 171 128 362 minecraft:blue_terracotta
setblock 172 125 325 minecraft:dark_prismarine
setblock 172 125 332 minecraft:light[level=12]
setblock 172 125 339 minecraft:light[level=12]
setblock 172 125 346 minecraft:light[level=12]
fill 172 125 347 172 126 347 minecraft:black_concrete
fill 172 125 351 172 168 351 minecraft:magenta_terracotta
setblock 172 125 353 minecraft:light[level=12]
setblock 172 125 360 minecraft:dark_prismarine
fill 172 125 361 172 128 361 minecraft:blue_terracotta
setblock 173 125 324 minecraft:dark_prismarine
fill 173 125 346 173 126 346 minecraft:black_concrete
fill 173 125 360 173 126 360 minecraft:blue_terracotta
setblock 174 125 323 minecraft:dark_prismarine
fill 174 125 324 174 128 324 minecraft:blue_terracotta
setblock 174 125 363 minecraft:dark_prismarine
fill 175 125 323 175 128 323 minecraft:blue_terracotta
fill 175 125 346 175 126 346 minecraft:black_concrete
fill 175 125 348 175 126 348 minecraft:black_concrete
setblock 175 125 362 minecraft:dark_prismarine
fill 175 125 363 175 128 363 minecraft:blue_terracotta
setblock 176 125 325 minecraft:light[level=13]
setblock 176 125 333 minecraft:light[level=13]
setblock 176 125 341 minecraft:light[level=13]
setblock 176 125 349 minecraft:light[level=13]
setblock 176 125 357 minecraft:light[level=13]
setblock 176 125 361 minecraft:dark_prismarine
fill 176 125 362 179 125 362 minecraft:blue_terracotta
fill 177 125 361 178 127 361 minecraft:blue_terracotta
fill 178 125 326 178 137 326 minecraft:green_terracotta
setblock 179 125 323 minecraft:dark_prismarine
setblock 179 125 325 minecraft:light[level=12]
setblock 179 125 332 minecraft:light[level=12]
setblock 179 125 339 minecraft:light[level=12]
setblock 179 125 346 minecraft:light[level=12]
setblock 179 125 353 minecraft:light[level=12]
setblock 179 125 360 minecraft:light[level=12]
setblock 179 125 363 minecraft:dark_prismarine
fill 180 125 323 180 128 323 minecraft:blue_terracotta
fill 180 125 360 180 126 360 minecraft:blue_terracotta
setblock 180 125 362 minecraft:dark_prismarine
fill 180 125 363 180 128 363 minecraft:blue_terracotta
setblock 181 125 355 minecraft:blue_terracotta
setblock 181 125 356 minecraft:dark_prismarine
fill 181 125 357 181 128 357 minecraft:blue_terracotta
setblock 181 125 361 minecraft:dark_prismarine
fill 181 125 362 181 128 362 minecraft:blue_terracotta
setblock 182 125 335 minecraft:dark_prismarine
fill 182 125 336 182 125 339 minecraft:blue_terracotta
setblock 182 125 340 minecraft:purple_concrete
setblock 182 125 346 minecraft:purple_concrete
setblock 182 125 355 minecraft:dark_prismarine
fill 182 125 356 182 128 356 minecraft:blue_terracotta
setblock 182 125 360 minecraft:dark_prismarine
fill 182 125 361 182 128 361 minecraft:blue_terracotta
setblock 142 126 327 minecraft:purple_concrete
fill 142 126 335 142 126 338 minecraft:blue_terracotta
setblock 142 126 339 minecraft:dark_prismarine
fill 142 126 340 142 126 343 minecraft:blue_terracotta
setblock 142 126 344 minecraft:dark_prismarine
fill 142 126 345 142 126 348 minecraft:blue_terracotta
setblock 142 126 349 minecraft:dark_prismarine
fill 142 126 350 142 129 350 minecraft:blue_terracotta
setblock 142 126 354 minecraft:dark_prismarine
fill 142 126 355 142 129 355 minecraft:blue_terracotta
setblock 142 126 359 minecraft:dark_prismarine
fill 142 126 360 142 129 360 minecraft:blue_terracotta
fill 143 126 336 143 126 337 minecraft:blue_terracotta
setblock 143 126 338 minecraft:dark_prismarine
fill 143 126 339 144 128 339 minecraft:blue_terracotta
setblock 143 126 342 minecraft:blue_terracotta
setblock 143 126 343 minecraft:dark_prismarine
fill 143 126 344 143 129 344 minecraft:blue_terracotta
setblock 143 126 353 minecraft:dark_prismarine
fill 143 126 354 143 129 354 minecraft:blue_terracotta
setblock 143 126 357 minecraft:blue_terracotta
setblock 143 126 358 minecraft:dark_prismarine
fill 143 126 359 143 129 359 minecraft:blue_terracotta
setblock 143 126 362 minecraft:blue_terracotta
setblock 143 126 363 minecraft:dark_prismarine
fill 144 126 340 144 127 340 minecraft:blue_terracotta
setblock 144 126 357 minecraft:dark_prismarine
fill 144 126 358 144 129 358 minecraft:blue_terracotta
setblock 144 126 361 minecraft:blue_terracotta
setblock 144 126 362 minecraft:dark_prismarine
fill 144 126 363 144 129 363 minecraft:blue_terracotta
setblock 145 126 361 minecraft:dark_prismarine
fill 145 126 362 148 126 362 minecraft:blue_terracotta
fill 146 126 323 147 126 323 minecraft:blue_terracotta
fill 146 126 361 146 129 361 minecraft:blue_terracotta
fill 147 126 360 147 127 360 minecraft:blue_terracotta
setblock 148 126 323 minecraft:dark_prismarine
setblock 148 126 363 minecraft:dark_prismarine
fill 149 126 323 149 129 323 minecraft:blue_terracotta
setblock 149 126 361 minecraft:blue_terracotta
setblock 149 126 362 minecraft:dark_prismarine
fill 149 126 363 149 129 363 minecraft:blue_terracotta
setblock 150 126 361 minecraft:dark_prismarine
fill 150 126 362 150 129 362 minecraft:blue_terracotta
fill 151 126 323 152 126 323 minecraft:blue_terracotta
fill 151 126 361 151 127 361 minecraft:blue_terracotta
setblock 153 126 323 minecraft:dark_prismarine
setblock 153 126 363 minecraft:dark_prismarine
fill 154 126 323 154 129 323 minecraft:blue_terracotta
setblock 154 126 362 minecraft:dark_prismarine
fill 154 126 363 154 129 363 minecraft:blue_terracotta
setblock 162 126 323 minecraft:blue_terracotta
setblock 162 126 363 minecraft:blue_terracotta
setblock 163 126 323 minecraft:dark_prismarine
setblock 163 126 363 minecraft:dark_prismarine
fill 164 126 323 164 129 323 minecraft:blue_terracotta
setblock 164 126 362 minecraft:dark_prismarine
fill 164 126 363 164 129 363 minecraft:blue_terracotta
fill 165 126 324 166 126 324 minecraft:blue_terracotta
fill 165 126 362 168 126 362 minecraft:blue_terracotta
fill 166 126 361 169 126 361 minecraft:blue_terracotta
setblock 167 126 324 minecraft:dark_prismarine
setblock 168 126 323 minecraft:dark_prismarine
fill 168 126 324 168 128 325 minecraft:blue_terracotta
setblock 168 126 363 minecraft:dark_prismarine
fill 169 126 323 169 129 323 minecraft:blue_terracotta
setblock 169 126 362 minecraft:dark_prismarine
fill 169 126 363 169 129 363 minecraft:blue_terracotta
setblock 170 126 360 minecraft:blue_terracotta
setblock 170 126 361 minecraft:dark_prismarine
fill 170 126 362 170 129 362 minecraft:blue_terracotta
setblock 171 126 325 minecraft:dark_prismarine
setblock 171 126 360 minecraft:dark_prismarine
fill 171 126 361 171 129 361 minecraft:blue_terracotta
setblock 172 126 324 minecraft:dark_prismarine
fill 172 126 325 172 127 325 minecraft:blue_terracotta
setblock 172 126 346 minecraft:black_concrete
setblock 172 126 348 minecraft:black_concrete
fill 172 126 360 172 127 360 minecraft:blue_terracotta
setblock 173 126 323 minecraft:dark_prismarine
fill 173 126 324 173 129 324 minecraft:blue_terracotta
fill 173 126 345 175 126 345 minecraft:black_concrete
setblock 173 126 349 minecraft:black_concrete
setblock 173 126 363 minecraft:dark_prismarine
fill 174 126 323 174 129 323 minecraft:blue_terracotta
setblock 174 126 361 minecraft:blue_terracotta
setblock 174 126 362 minecraft:dark_prismarine
fill 174 126 363 174 129 363 minecraft:blue_terracotta
setblock 175 126 349 minecraft:black_concrete
setblock 175 126 361 minecraft:dark_prismarine
fill 175 126 362 178 126 362 minecraft:blue_terracotta
fill 176 126 346 176 126 348 minecraft:black_concrete
fill 176 126 361 176 128 361 minecraft:blue_terracotta
setblock 178 126 323 minecraft:dark_prismarine
setblock 178 126 363 minecraft:dark_prismarine
fill 179 126 323 179 129 323 minecraft:blue_terracotta
setblock 179 126 361 minecraft:blue_terracotta
setblock 179 126 362 minecraft:dark_prismarine
fill 179 126 363 179 129 363 minecraft:blue_terracotta
setblock 180 126 359 minecraft:blue_terracotta
setblock 180 126 361 minecraft:dark_prismarine
fill 180 126 362 180 129 362 minecraft:blue_terracotta
fill 181 126 323 182 126 323 minecraft:blue_terracotta
fill 181 126 356 181 128 356 minecraft:blue_terracotta
setblock 181 126 360 minecraft:dark_prismarine
fill 181 126 361 181 129 361 minecraft:blue_terracotta
setblock 182 126 334 minecraft:purple_concrete
fill 182 126 336 182 126 338 minecraft:blue_terracotta
setblock 182 126 339 minecraft:dark_prismarine
fill 182 126 340 182 129 340 minecraft:blue_terracotta
setblock 182 126 354 minecraft:dark_prismarine
fill 182 126 355 182 129 355 minecraft:blue_terracotta
setblock 182 126 359 minecraft:dark_prismarine
fill 182 126 360 182 129 360 minecraft:blue_terracotta
setblock 183 126 340 minecraft:light_blue_wool
setblock 142 127 333 minecraft:purple_concrete
fill 142 127 335 142 127 337 minecraft:blue_terracotta
setblock 142 127 338 minecraft:dark_prismarine
fill 142 127 339 142 127 342 minecraft:blue_terracotta
setblock 142 127 343 minecraft:dark_prismarine
fill 142 127 344 142 127 347 minecraft:blue_terracotta
setblock 142 127 348 minecraft:dark_prismarine
fill 142 127 349 142 130 349 minecraft:blue_terracotta
setblock 142 127 352 minecraft:blue_terracotta
setblock 142 127 353 minecraft:dark_prismarine
fill 142 127 354 142 130 354 minecraft:blue_terracotta
setblock 142 127 358 minecraft:dark_prismarine
fill 142 127 359 142 130 359 minecraft:blue_terracotta
fill 142 127 361 142 127 362 minecraft:blue_terracotta
setblock 142 127 363 minecraft:dark_prismarine
setblock 143 127 323 minecraft:purple_concrete
setblock 143 127 336 minecraft:blue_terracotta
setblock 143 127 337 minecraft:dark_prismarine
fill 143 127 338 144 129 338 minecraft:blue_terracotta
setblock 143 127 342 minecraft:dark_prismarine
fill 143 127 343 144 129 343 minecraft:blue_terracotta
fill 143 127 345 143 127 346 minecraft:blue_terracotta
setblock 143 127 352 minecraft:dark_prismarine
fill 143 127 353 143 128 353 minecraft:blue_terracotta
setblock 143 127 357 minecraft:dark_prismarine
fill 143 127 358 143 130 358 minecraft:blue_terracotta
setblock 143 127 362 minecraft:dark_prismarine
fill 143 127 363 143 130 363 minecraft:blue_terracotta
setblock 144 127 341 minecraft:dark_prismarine
fill 144 127 342 144 130 342 minecraft:blue_terracotta
setblock 144 127 356 minecraft:dark_prismarine
fill 144 127 357 144 128 357 minecraft:blue_terracotta
setblock 144 127 361 minecraft:dark_prismarine
fill 144 127 362 147 127 362 minecraft:blue_terracotta
fill 145 127 323 146 127 323 minecraft:blue_terracotta
fill 145 127 361 145 130 361 minecraft:blue_terracotta
setblock 147 127 323 minecraft:dark_prismarine
setblock 147 127 363 minecraft:dark_prismarine
fill 148 127 323 148 130 323 minecraft:blue_terracotta
setblock 148 127 360 minecraft:blue_terracotta
setblock 148 127 362 minecraft:dark_prismarine
fill 148 127 363 148 130 363 minecraft:blue_terracotta
setblock 149 127 361 minecraft:dark_prismarine
fill 149 127 362 149 130 362 minecraft:blue_terracotta
fill 150 127 361 150 128 361 minecraft:blue_terracotta
setblock 151 127 323 minecraft:blue_terracotta
setblock 152 127 323 minecraft:dark_prismarine
setblock 152 127 363 minecraft:dark_prismarine
fill 153 127 323 153 130 323 minecraft:blue_terracotta
setblock 153 127 362 minecraft:dark_prismarine
fill 153 127 363 153 130 363 minecraft:blue_terracotta
fill 158 127 356 158 148 356 minecraft:magenta_terracotta
setblock 161 127 323 minecraft:blue_terracotta
setblock 161 127 363 minecraft:blue_terracotta
setblock 162 127 323 minecraft:dark_prismarine
setblock 162 127 363 minecraft:dark_prismarine
fill 163 127 323 163 130 323 minecraft:blue_terracotta
fill 163 127 363 163 130 363 minecraft:blue_terracotta
fill 164 127 324 165 127 324 minecraft:blue_terracotta
fill 164 127 362 167 127 362 minecraft:blue_terracotta
setblock 166 127 324 minecraft:dark_prismarine
fill 166 127 331 166 134 331 minecraft:magenta_terracotta
fill 166 127 361 168 127 361 minecraft:blue_terracotta
setblock 167 127 323 minecraft:dark_prismarine
fill 167 127 324 167 129 325 minecraft:blue_terracotta
setblock 167 127 363 minecraft:dark_prismarine
fill 168 127 323 168 130 323 minecraft:blue_terracotta
setblock 168 127 362 minecraft:dark_prismarine
fill 168 127 363 168 130 363 minecraft:blue_terracotta
setblock 169 127 360 minecraft:blue_terracotta
setblock 169 127 361 minecraft:dark_prismarine
fill 169 127 362 169 130 362 minecraft:blue_terracotta
setblock 170 127 324 minecraft:blue_terracotta
setblock 170 127 325 minecraft:dark_prismarine
setblock 170 127 360 minecraft:dark_prismarine
fill 170 127 361 170 130 361 minecraft:blue_terracotta
setblock 171 127 324 minecraft:dark_prismarine
fill 171 127 325 171 129 325 minecraft:blue_terracotta
setblock 171 127 360 minecraft:blue_terracotta
setblock 172 127 323 minecraft:dark_prismarine
fill 172 127 324 172 130 324 minecraft:blue_terracotta
setblock 172 127 363 minecraft:dark_prismarine
fill 173 127 323 173 130 323 minecraft:blue_terracotta
setblock 173 127 362 minecraft:dark_prismarine
fill 173 127 363 173 130 363 minecraft:blue_terracotta
setblock 174 127 361 minecraft:dark_prismarine
fill 174 127 362 177 127 362 minecraft:blue_terracotta
fill 175 127 361 175 128 361 minecraft:blue_terracotta
setblock 177 127 323 minecraft:dark_prismarine
setblock 177 127 363 minecraft:dark_prismarine
fill 178 127 323 178 130 323 minecraft:blue_terracotta
setblock 178 127 362 minecraft:dark_prismarine
fill 178 127 363 178 130 363 minecraft:blue_terracotta
setblock 179 127 361 minecraft:dark_prismarine
fill 179 127 362 179 130 362 minecraft:blue_terracotta
setblock 180 127 360 minecraft:dark_prismarine
fill 180 127 361 180 128 361 minecraft:blue_terracotta
setblock 181 127 323 minecraft:blue_terracotta
setblock 181 127 359 minecraft:dark_prismarine
fill 181 127 360 181 130 360 minecraft:blue_terracotta
setblock 182 127 323 minecraft:dark_prismarine
setblock 182 127 328 minecraft:purple_concrete
fill 182 127 336 182 127 337 minecraft:blue_terracotta
setblock 182 127 338 minecraft:dark_prismarine
fill 182 127 339 182 130 339 minecraft:blue_terracotta
fill 182 127 341 182 127 342 minecraft:blue_terracotta
setblock 182 127 353 minecraft:dark_prismarine
fill 182 127 354 182 130 354 minecraft:blue_terracotta
setblock 182 127 358 minecraft:dark_prismarine
fill 182 127 359 182 130 359 minecraft:blue_terracotta
setblock 182 127 363 minecraft:dark_prismarine
fill 183 127 340 183 131 340 minecraft:black_concrete
fill 141 128 322 141 129 322 minecraft:blue_terracotta
fill 141 128 323 141 131 323 minecraft:black_concrete
fill 141 128 348 142 128 348 minecraft:blue_terracotta
fill 141 128 349 141 131 349 minecraft:black_concrete
setblock 141 128 350 minecraft:light_blue_wool
setblock 141 128 364 minecraft:blue_terracotta
fill 142 128 335 142 128 336 minecraft:blue_terracotta
setblock 142 128 337 minecraft:dark_prismarine
fill 142 128 338 142 128 341 minecraft:blue_terracotta
setblock 142 128 342 minecraft:dark_prismarine
fill 142 128 343 142 128 346 minecraft:blue_terracotta
setblock 142 128 347 minecraft:dark_prismarine
setblock 142 128 352 minecraft:dark_prismarine
fill 142 128 353 142 131 353 minecraft:blue_terracotta
setblock 142 128 357 minecraft:dark_prismarine
fill 142 128 358 142 131 358 minecraft:blue_terracotta
setblock 142 128 361 minecraft:blue_terracotta
setblock 142 128 362 minecraft:dark_prismarine
fill 142 128 363 142 131 363 minecraft:blue_terracotta
setblock 143 128 336 minecraft:dark_prismarine
fill 143 128 337 143 131 337 minecraft:blue_terracotta
setblock 143 128 340 minecraft:blue_terracotta
setblock 143 128 341 minecraft:dark_prismarine
fill 143 128 342 143 131 342 minecraft:blue_terracotta
setblock 143 128 345 minecraft:blue_terracotta
setblock 143 128 346 minecraft:dark_prismarine
fill 143 128 347 143 131 347 minecraft:blue_terracotta
setblock 143 128 356 minecraft:dark_prismarine
fill 143 128 357 143 130 357 minecraft:blue_terracotta
setblock 143 128 361 minecraft:dark_prismarine
fill 143 128 362 146 128 362 minecraft:blue_terracotta
fill 144 128 322 144 128 323 minecraft:blue_terracotta
setblock 144 128 340 minecraft:dark_prismarine
fill 144 128 341 145 130 341 minecraft:blue_terracotta
setblock 144 128 344 minecraft:blue_terracotta
setblock 144 128 356 minecraft:blue_terracotta
setblock 144 128 360 minecraft:dark_prismarine
fill 144 128 361 144 129 361 minecraft:blue_terracotta
setblock 144 128 364 minecraft:blue_terracotta
setblock 145 128 323 minecraft:blue_terracotta
setblock 146 128 323 minecraft:dark_prismarine
setblock 146 128 363 minecraft:dark_prismarine
fill 147 128 323 147 131 323 minecraft:blue_terracotta
setblock 147 128 362 minecraft:dark_prismarine
fill 147 128 363 147 131 363 minecraft:blue_terracotta
setblock 148 128 361 minecraft:dark_prismarine
fill 148 128 362 148 131 362 minecraft:blue_terracotta
setblock 149 128 322 minecraft:blue_terracotta
fill 149 128 361 149 129 361 minecraft:blue_terracotta
setblock 151 128 323 minecraft:dark_prismarine
setblock 151 128 363 minecraft:dark_prismarine
fill 152 128 323 152 131 323 minecraft:blue_terracotta
setblock 152 128 362 minecraft:dark_prismarine
fill 152 128 363 152 131 363 minecraft:blue_terracotta
setblock 153 128 362 minecraft:blue_terracotta
fill 154 128 322 157 128 322 minecraft:black_concrete
setblock 155 128 363 minecraft:blue_terracotta
setblock 156 128 364 minecraft:blue_terracotta
fill 158 128 322 158 129 322 minecraft:blue_terracotta
fill 159 128 322 159 131 322 minecraft:black_concrete
setblock 160 128 323 minecraft:blue_terracotta
setblock 161 128 322 minecraft:blue_terracotta
setblock 161 128 323 minecraft:dark_prismarine
setblock 161 128 363 minecraft:dark_prismarine
fill 162 128 323 162 131 323 minecraft:blue_terracotta
fill 162 128 363 162 131 363 minecraft:blue_terracotta
fill 163 128 324 164 128 324 minecraft:blue_terracotta
fill 163 128 362 166 128 362 minecraft:blue_terracotta
setblock 165 128 324 minecraft:dark_prismarine
setblock 166 128 323 minecraft:dark_prismarine
fill 166 128 324 166 130 325 minecraft:blue_terracotta
fill 166 128 361 167 128 361 minecraft:blue_terracotta
setblock 166 128 363 minecraft:dark_prismarine
fill 167 128 323 167 131 323 minecraft:blue_terracotta
setblock 167 128 362 minecraft:dark_prismarine
fill 167 128 363 167 128 364 minecraft:blue_terracotta
setblock 168 128 361 minecraft:dark_prismarine
fill 168 128 362 168 131 362 minecraft:blue_terracotta
setblock 169 128 324 minecraft:blue_terracotta
setblock 169 128 325 minecraft:dark_prismarine
fill 169 128 361 169 131 361 minecraft:blue_terracotta
setblock 170 128 324 minecraft:dark_prismarine
fill 170 128 325 170 130 325 minecraft:blue_terracotta
fill 170 128 364 171 128 364 minecraft:blue_terracotta
setblock 171 128 323 minecraft:dark_prismarine
fill 171 128 324 171 131 324 minecraft:blue_terracotta
setblock 171 128 363 minecraft:dark_prismarine
fill 172 128 323 172 131 323 minecraft:blue_terracotta
fill 172 128 350 172 152 350 minecraft:magenta_terracotta
setblock 172 128 362 minecraft:dark_prismarine
fill 172 128 363 172 131 363 minecraft:blue_terracotta
setblock 173 128 361 minecraft:dark_prismarine
fill 173 128 362 176 128 362 minecraft:blue_terracotta
setblock 174 128 322 minecraft:blue_terracotta
fill 174 128 361 174 129 361 minecraft:blue_terracotta
setblock 175 128 324 minecraft:dark_prismarine
setblock 176 128 323 minecraft:dark_prismarine
setblock 176 128 363 minecraft:dark_prismarine
setblock 176 128 364 minecraft:blue_terracotta
fill 177 128 323 177 131 323 minecraft:blue_terracotta
setblock 177 128 362 minecraft:dark_prismarine
fill 177 128 363 177 131 363 minecraft:blue_terracotta
fill 178 128 362 178 131 362 minecraft:blue_terracotta
setblock 181 128 323 minecraft:dark_prismarine
setblock 181 128 358 minecraft:dark_prismarine
fill 181 128 359 181 131 359 minecraft:blue_terracotta
setblock 181 128 363 minecraft:dark_prismarine
fill 182 128 323 182 130 324 minecraft:blue_terracotta
setblock 182 128 337 minecraft:dark_prismarine
fill 182 128 338 182 129 338 minecraft:blue_terracotta
setblock 182 128 341 minecraft:blue_terracotta
setblock 182 128 342 minecraft:dark_prismarine
fill 182 128 343 182 130 344 minecraft:blue_terracotta
setblock 182 128 347 minecraft:purple_concrete
fill 182 128 353 182 129 353 minecraft:blue_terracotta
setblock 182 128 357 minecraft:dark_prismarine
fill 182 128 358 182 131 358 minecraft:blue_terracotta
setblock 182 128 362 minecraft:dark_prismarine
fill 182 128 363 182 131 363 minecraft:blue_terracotta
setblock 183 128 334 minecraft:blue_terracotta
setblock 141 129 326 minecraft:blue_terracotta
setblock 141 129 332 minecraft:blue_terracotta
fill 141 129 338 142 129 338 minecraft:blue_terracotta
fill 141 129 346 141 130 346 minecraft:blue_terracotta
setblock 141 129 348 minecraft:black_concrete
fill 141 129 350 141 131 350 minecraft:black_concrete
fill 141 129 352 141 131 352 minecraft:black_concrete
setblock 141 129 353 minecraft:blue_terracotta
fill 141 129 354 141 131 354 minecraft:black_concrete
fill 141 129 364 141 131 364 minecraft:black_concrete
setblock 142 129 326 minecraft:purple_concrete
setblock 142 129 336 minecraft:dark_prismarine
fill 142 129 337 142 132 337 minecraft:blue_terracotta
fill 142 129 339 142 129 340 minecraft:blue_terracotta
setblock 142 129 341 minecraft:dark_prismarine
fill 142 129 342 142 129 345 minecraft:blue_terracotta
setblock 142 129 346 minecraft:dark_prismarine
fill 142 129 347 142 131 348 minecraft:blue_terracotta
setblock 142 129 351 minecraft:dark_prismarine
fill 142 129 352 142 132 352 minecraft:blue_terracotta
setblock 142 129 356 minecraft:dark_prismarine
fill 142 129 357 142 132 357 minecraft:blue_terracotta
setblock 142 129 361 minecraft:dark_prismarine
fill 142 129 362 145 129 362 minecraft:blue_terracotta
fill 143 129 323 144 129 323 minecraft:blue_terracotta
setblock 143 129 339 minecraft:blue_terracotta
setblock 143 129 340 minecraft:dark_prismarine
fill 143 129 341 143 132 341 minecraft:blue_terracotta
setblock 143 129 345 minecraft:dark_prismarine
fill 143 129 346 143 132 346 minecraft:blue_terracotta
fill 143 129 348 143 130 348 minecraft:blue_terracotta
setblock 143 129 355 minecraft:dark_prismarine
fill 143 129 356 143 130 356 minecraft:blue_terracotta
setblock 143 129 360 minecraft:dark_prismarine
fill 143 129 361 143 132 361 minecraft:blue_terracotta
fill 144 129 322 144 131 322 minecraft:black_concrete
setblock 144 129 339 minecraft:dark_prismarine
fill 144 129 340 145 129 340 minecraft:blue_terracotta
setblock 144 129 344 minecraft:dark_prismarine
fill 144 129 345 144 132 345 minecraft:blue_terracotta
setblock 144 129 359 minecraft:dark_prismarine
setblock 144 129 360 minecraft:blue_terracotta
fill 144 129 364 144 131 364 minecraft:black_concrete
setblock 145 129 323 minecraft:dark_prismarine
setblock 145 129 342 minecraft:blue_terracotta
setblock 145 129 363 minecraft:dark_prismarine
fill 146 129 323 146 132 323 minecraft:blue_terracotta
setblock 146 129 362 minecraft:dark_prismarine
fill 146 129 363 146 132 363 minecraft:blue_terracotta
setblock 147 129 361 minecraft:dark_prismarine
fill 147 129 362 147 132 362 minecraft:blue_terracotta
setblock 148 129 361 minecraft:blue_terracotta
fill 149 129 322 149 131 322 minecraft:black_concrete
setblock 150 129 323 minecraft:dark_prismarine
setblock 150 129 363 minecraft:dark_prismarine
fill 151 129 323 151 132 323 minecraft:blue_terracotta
setblock 151 129 362 minecraft:dark_prismarine
fill 151 129 363 151 132 363 minecraft:blue_terracotta
setblock 152 129 362 minecraft:blue_terracotta
fill 154 129 322 155 131 322 minecraft:black_concrete
setblock 156 129 322 minecraft:blue_terracotta
setblock 156 129 323 minecraft:purple_concrete
fill 156 129 364 156 132 364 minecraft:black_concrete
fill 157 129 322 157 131 322 minecraft:black_concrete
setblock 157 129 364 minecraft:light_blue_wool
setblock 159 129 323 minecraft:blue_terracotta
setblock 160 129 323 minecraft:dark_prismarine
setblock 160 129 363 minecraft:dark_prismarine
fill 160 129 364 160 132 364 minecraft:black_concrete
fill 161 129 322 161 131 322 minecraft:black_concrete
fill 161 129 323 161 132 323 minecraft:blue_terracotta
fill 161 129 363 161 129 364 minecraft:blue_terracotta
setblock 162 129 364 minecraft:blue_terracotta
setblock 163 129 324 minecraft:blue_terracotta
fill 163 129 362 165 129 362 minecraft:blue_terracotta
fill 163 129 364 164 131 364 minecraft:black_concrete
setblock 164 129 324 minecraft:dark_prismarine
setblock 165 129 323 minecraft:dark_prismarine
fill 165 129 324 165 132 324 minecraft:blue_terracotta
setblock 165 129 363 minecraft:dark_prismarine
fill 166 129 323 166 132 323 minecraft:blue_terracotta
setblock 166 129 361 minecraft:blue_terracotta
setblock 166 129 362 minecraft:dark_prismarine
fill 166 129 363 167 131 363 minecraft:blue_terracotta
setblock 167 129 361 minecraft:dark_prismarine
fill 167 129 362 167 132 362 minecraft:blue_terracotta
fill 167 129 364 167 131 364 minecraft:black_concrete
setblock 168 129 324 minecraft:blue_terracotta
setblock 168 129 325 minecraft:dark_prismarine
fill 168 129 361 168 132 361 minecraft:blue_terracotta
setblock 169 129 324 minecraft:dark_prismarine
fill 169 129 325 169 132 325 minecraft:blue_terracotta
setblock 170 129 323 minecraft:dark_prismarine
fill 170 129 324 170 132 324 minecraft:blue_terracotta
setblock 170 129 363 minecraft:dark_prismarine
fill 170 129 364 171 131 364 minecraft:black_concrete
fill 171 129 323 171 132 323 minecraft:blue_terracotta
setblock 171 129 362 minecraft:dark_prismarine
fill 171 129 363 171 132 363 minecraft:blue_terracotta
setblock 172 129 361 minecraft:dark_prismarine
fill 172 129 362 175 129 362 minecraft:blue_terracotta
setblock 173 129 361 minecraft:blue_terracotta
fill 174 129 322 174 131 322 minecraft:black_concrete
setblock 174 129 324 minecraft:dark_prismarine
setblock 175 129 323 minecraft:dark_prismarine
fill 175 129 351 175 132 351 minecraft:magenta_terracotta
setblock 175 129 363 minecraft:dark_prismarine
fill 176 129 323 176 132 323 minecraft:blue_terracotta
setblock 176 129 362 minecraft:dark_prismarine
fill 176 129 363 176 132 363 minecraft:blue_terracotta
fill 176 129 364 176 131 364 minecraft:black_concrete
fill 177 129 362 177 132 362 minecraft:blue_terracotta
fill 178 129 337 178 135 338 minecraft:magenta_terracotta
setblock 180 129 323 minecraft:dark_prismarine
setblock 180 129 363 minecraft:dark_prismarine
fill 181 129 323 181 132 323 minecraft:blue_terracotta
setblock 181 129 357 minecraft:dark_prismarine
fill 181 129 358 181 131 358 minecraft:blue_terracotta
setblock 181 129 362 minecraft:dark_prismarine
fill 181 129 363 181 132 363 minecraft:blue_terracotta
setblock 182 129 341 minecraft:dark_prismarine
fill 182 129 342 182 132 342 minecraft:blue_terracotta
setblock 182 129 345 minecraft:blue_terracotta
setblock 182 129 356 minecraft:dark_prismarine
fill 182 129 357 182 132 357 minecraft:blue_terracotta
setblock 182 129 361 minecraft:dark_prismarine
fill 182 129 362 182 132 362 minecraft:blue_terracotta
setblock 183 129 334 minecraft:black_concrete
setblock 183 129 341 minecraft:blue_terracotta
fill 183 129 342 183 131 342 minecraft:black_concrete
fill 141 130 322 141 132 322 minecraft:black_concrete
fill 141 130 326 141 132 326 minecraft:black_concrete
fill 141 130 332 141 131 332 minecraft:black_concrete
setblock 141 130 334 minecraft:blue_terracotta
fill 141 130 335 141 131 335 minecraft:black_concrete
fill 141 130 336 142 130 336 minecraft:blue_terracotta
fill 141 130 337 141 131 338 minecraft:black_concrete
fill 141 130 342 142 130 342 minecraft:blue_terracotta
setblock 141 130 348 minecraft:blue_terracotta
fill 141 130 353 141 131 353 minecraft:black_concrete
setblock 141 130 357 minecraft:blue_terracotta
setblock 141 130 363 minecraft:blue_terracotta
setblock 142 130 332 minecraft:purple_concrete
fill 142 130 338 142 130 339 minecraft:blue_terracotta
setblock 142 130 340 minecraft:dark_prismarine
fill 142 130 341 142 133 341 minecraft:blue_terracotta
fill 142 130 343 142 130 344 minecraft:blue_terracotta
setblock 142 130 345 minecraft:dark_prismarine
fill 142 130 346 142 133 346 minecraft:blue_terracotta
setblock 142 130 350 minecraft:dark_prismarine
fill 142 130 351 142 133 351 minecraft:blue_terracotta
setblock 142 130 355 minecraft:dark_prismarine
fill 142 130 356 142 133 356 minecraft:blue_terracotta
setblock 142 130 360 minecraft:dark_prismarine
fill 142 130 361 142 132 362 minecraft:blue_terracotta
setblock 143 130 323 minecraft:blue_terracotta
setblock 143 130 338 minecraft:blue_terracotta
setblock 143 130 339 minecraft:dark_prismarine
fill 143 130 340 144 132 340 minecraft:blue_terracotta
setblock 143 130 343 minecraft:blue_terracotta
setblock 143 130 344 minecraft:dark_prismarine
fill 143 130 345 143 133 345 minecraft:blue_terracotta
setblock 143 130 349 minecraft:dark_prismarine
setblock 143 130 359 minecraft:dark_prismarine
fill 143 130 360 143 132 360 minecraft:blue_terracotta
fill 143 130 362 144 130 362 minecraft:blue_terracotta
setblock 144 130 323 minecraft:dark_prismarine
setblock 144 130 338 minecraft:dark_prismarine
fill 144 130 339 144 133 339 minecraft:blue_terracotta
setblock 144 130 343 minecraft:dark_prismarine
fill 144 130 344 144 133 344 minecraft:blue_terracotta
fill 144 130 346 144 131 346 minecraft:blue_terracotta
fill 144 130 357 144 135 357 minecraft:purple_concrete
setblock 144 130 363 minecraft:dark_prismarine
fill 145 130 323 145 133 323 minecraft:blue_terracotta
setblock 145 130 342 minecraft:dark_prismarine
fill 145 130 343 145 133 343 minecraft:blue_terracotta
setblock 145 130 362 minecraft:dark_prismarine
fill 145 130 363 145 133 363 minecraft:blue_terracotta
setblock 146 130 361 minecraft:dark_prismarine
fill 146 130 362 146 133 362 minecraft:blue_terracotta
setblock 147 130 322 minecraft:blue_terracotta
setblock 147 130 361 minecraft:blue_terracotta
setblock 149 130 323 minecraft:dark_prismarine
setblock 149 130 363 minecraft:dark_prismarine
fill 150 130 323 150 133 323 minecraft:blue_terracotta
setblock 150 130 362 minecraft:dark_prismarine
fill 150 130 363 150 133 363 minecraft:blue_terracotta
fill 152 130 335 152 171 335 minecraft:magenta_terracotta
setblock 153 130 322 minecraft:blue_terracotta
setblock 155 130 363 minecraft:purple_concrete
fill 156 130 322 156 131 322 minecraft:black_concrete
setblock 157 130 364 minecraft:blue_terracotta
fill 158 130 322 158 131 322 minecraft:black_concrete
setblock 159 130 323 minecraft:dark_prismarine
fill 160 130 323 160 133 323 minecraft:blue_terracotta
fill 160 130 363 161 132 363 minecraft:blue_terracotta
fill 161 130 364 162 131 364 minecraft:black_concrete
setblock 162 130 324 minecraft:blue_terracotta
setblock 163 130 324 minecraft:dark_prismarine
fill 163 130 362 164 130 362 minecraft:blue_terracotta
setblock 164 130 323 minecraft:dark_prismarine
fill 164 130 324 164 133 324 minecraft:blue_terracotta
setblock 164 130 363 minecraft:dark_prismarine
fill 165 130 323 165 133 323 minecraft:blue_terracotta
fill 165 130 325 165 131 325 minecraft:blue_terracotta
setblock 165 130 362 minecraft:dark_prismarine
fill 165 130 363 165 133 363 minecraft:blue_terracotta
setblock 166 130 361 minecraft:dark_prismarine
fill 166 130 362 166 133 362 minecraft:blue_terracotta
setblock 166 130 364 minecraft:blue_terracotta
setblock 167 130 324 minecraft:blue_terracotta
setblock 167 130 325 minecraft:dark_prismarine
fill 167 130 361 167 131 361 minecraft:blue_terracotta
setblock 168 130 324 minecraft:dark_prismarine
fill 168 130 325 168 133 325 minecraft:blue_terracotta
setblock 169 130 323 minecraft:dark_prismarine
fill 169 130 324 169 133 324 minecraft:blue_terracotta
setblock 169 130 363 minecraft:dark_prismarine
fill 170 130 323 170 133 323 minecraft:blue_terracotta
setblock 170 130 362 minecraft:dark_prismarine
fill 170 130 363 170 133 363 minecraft:blue_terracotta
setblock 171 130 361 minecraft:dark_prismarine
fill 171 130 362 174 130 362 minecraft:blue_terracotta
setblock 172 130 361 minecraft:blue_terracotta
setblock 173 130 324 minecraft:dark_prismarine
setblock 174 130 323 minecraft:dark_prismarine
setblock 174 130 363 minecraft:dark_prismarine
setblock 174 130 364 minecraft:blue_terracotta
fill 175 130 323 175 133 323 minecraft:blue_terracotta
setblock 175 130 362 minecraft:dark_prismarine
fill 175 130 363 175 133 363 minecraft:blue_terracotta
fill 176 130 362 176 132 362 minecraft:blue_terracotta
setblock 179 130 322 minecraft:blue_terracotta
setblock 179 130 323 minecraft:dark_prismarine
setblock 179 130 363 minecraft:dark_prismarine
fill 180 130 323 180 133 323 minecraft:blue_terracotta
setblock 180 130 362 minecraft:dark_prismarine
fill 180 130 363 180 133 363 minecraft:blue_terracotta
setblock 181 130 322 minecraft:blue_terracotta
setblock 181 130 361 minecraft:dark_prismarine
fill 181 130 362 181 133 362 minecraft:blue_terracotta
setblock 182 130 322 minecraft:cyan_concrete
setblock 182 130 335 minecraft:purple_concrete
setblock 182 130 340 minecraft:dark_prismarine
fill 182 130 341 182 133 341 minecraft:blue_terracotta
setblock 182 130 345 minecraft:dark_prismarine
fill 182 130 346 182 132 347 minecraft:blue_terracotta
setblock 182 130 355 minecraft:dark_prismarine
fill 182 130 356 182 133 356 minecraft:blue_terracotta
setblock 182 130 360 minecraft:dark_prismarine
fill 182 130 361 182 133 361 minecraft:blue_terracotta
fill 183 130 322 183 131 322 minecraft:black_concrete
fill 183 130 334 183 130 335 minecraft:blue_terracotta
fill 183 130 341 183 131 341 minecraft:black_concrete
setblock 183 130 359 minecraft:light_blue_wool
setblock 141 131 334 minecraft:black_concrete
setblock 141 131 336 minecraft:black_concrete
setblock 141 131 342 minecraft:black_concrete
setblock 141 131 346 minecraft:black_concrete
fill 141 131 348 141 133 348 minecraft:black_concrete
setblock 141 131 357 minecraft:black_concrete
setblock 141 131 363 minecraft:black_concrete
setblock 142 131 323 minecraft:blue_terracotta
setblock 142 131 336 minecraft:blue_terracotta
setblock 142 131 338 minecraft:blue_terracotta
setblock 142 131 339 minecraft:dark_prismarine
fill 142 131 340 142 134 340 minecraft:blue_terracotta
fill 142 131 342 142 131 343 minecraft:blue_terracotta
setblock 142 131 344 minecraft:dark_prismarine
fill 142 131 345 142 134 345 minecraft:blue_terracotta
setblock 142 131 349 minecraft:dark_prismarine
fill 142 131 350 142 134 350 minecraft:blue_terracotta
setblock 142 131 354 minecraft:dark_prismarine
fill 142 131 355 142 134 355 minecraft:blue_terracotta
setblock 142 131 359 minecraft:dark_prismarine
fill 142 131 360 142 134 360 minecraft:blue_terracotta
setblock 143 131 323 minecraft:dark_prismarine
setblock 143 131 338 minecraft:dark_prismarine
fill 143 131 339 143 134 339 minecraft:blue_terracotta
setblock 143 131 343 minecraft:dark_prismarine
fill 143 131 344 143 134 344 minecraft:blue_terracotta
setblock 143 131 348 minecraft:dark_prismarine
fill 143 131 349 143 134 349 minecraft:blue_terracotta
setblock 143 131 358 minecraft:dark_prismarine
fill 143 131 359 143 132 359 minecraft:blue_terracotta
setblock 143 131 362 minecraft:blue_terracotta
setblock 143 131 363 minecraft:dark_prismarine
fill 144 131 323 144 134 323 minecraft:blue_terracotta
setblock 144 131 325 minecraft:light[level=12]
setblock 144 131 332 minecraft:light[level=12]
setblock 144 131 341 minecraft:blue_terracotta
setblock 144 131 342 minecraft:dark_prismarine
fill 144 131 343 144 134 343 minecraft:blue_terracotta
setblock 144 131 347 minecraft:dark_prismarine
setblock 144 131 353 minecraft:light[level=12]
setblock 144 131 360 minecraft:light[level=12]
setblock 144 131 362 minecraft:dark_prismarine
fill 144 131 363 144 134 363 minecraft:blue_terracotta
setblock 145 131 341 minecraft:dark_prismarine
fill 145 131 342 145 134 342 minecraft:blue_terracotta
fill 145 131 344 145 132 344 minecraft:blue_terracotta
fill 145 131 362 145 134 362 minecraft:blue_terracotta
setblock 147 131 322 minecraft:black_concrete
setblock 148 131 323 minecraft:dark_prismarine
setblock 148 131 363 minecraft:dark_prismarine
fill 149 131 323 149 134 323 minecraft:blue_terracotta
setblock 149 131 362 minecraft:dark_prismarine
fill 149 131 363 149 134 363 minecraft:blue_terracotta
setblock 151 131 325 minecraft:light[level=12]
setblock 151 131 332 minecraft:light[level=12]
setblock 151 131 346 minecraft:light[level=12]
setblock 151 131 353 minecraft:light[level=12]
setblock 151 131 360 minecraft:light[level=12]
setblock 153 131 322 minecraft:black_concrete
setblock 153 131 323 minecraft:dark_prismarine
setblock 157 131 364 minecraft:black_concrete
setblock 158 131 323 minecraft:dark_prismarine
setblock 158 131 325 minecraft:light[level=12]
setblock 158 131 332 minecraft:light[level=12]
setblock 158 131 339 minecraft:light[level=12]
setblock 158 131 346 minecraft:light[level=12]
setblock 158 131 353 minecraft:light[level=12]
setblock 158 131 360 minecraft:light[level=12]
fill 159 131 323 159 134 323 minecraft:blue_terracotta
setblock 161 131 324 minecraft:blue_terracotta
setblock 162 131 324 minecraft:dark_prismarine
setblock 163 131 323 minecraft:dark_prismarine
fill 163 131 324 163 134 324 minecraft:blue_terracotta
setblock 163 131 362 minecraft:blue_terracotta
setblock 163 131 363 minecraft:dark_prismarine
fill 164 131 323 164 134 323 minecraft:blue_terracotta
fill 164 131 325 164 132 325 minecraft:blue_terracotta
setblock 164 131 362 minecraft:dark_prismarine
fill 164 131 363 164 134 363 minecraft:blue_terracotta
setblock 165 131 332 minecraft:light[level=12]
setblock 165 131 339 minecraft:light[level=12]
setblock 165 131 346 minecraft:light[level=12]
setblock 165 131 353 minecraft:light[level=12]
setblock 165 131 360 minecraft:light[level=12]
fill 165 131 362 165 134 362 minecraft:blue_terracotta
setblock 166 131 324 minecraft:blue_terracotta
setblock 166 131 325 minecraft:dark_prismarine
setblock 166 131 361 minecraft:blue_terracotta
setblock 166 131 364 minecraft:black_concrete
setblock 167 131 324 minecraft:dark_prismarine
fill 167 131 325 167 134 325 minecraft:blue_terracotta
fill 167 131 328 167 188 328 minecraft:magenta_terracotta
setblock 168 131 323 minecraft:dark_prismarine
fill 168 131 324 168 134 324 minecraft:blue_terracotta
setblock 168 131 363 minecraft:dark_prismarine
fill 169 131 323 169 134 323 minecraft:blue_terracotta
setblock 169 131 362 minecraft:dark_prismarine
fill 169 131 363 169 134 363 minecraft:blue_terracotta
setblock 170 131 361 minecraft:dark_prismarine
fill 170 131 362 173 131 362 minecraft:blue_terracotta
setblock 171 131 361 minecraft:blue_terracotta
setblock 172 131 324 minecraft:dark_prismarine
setblock 172 131 325 minecraft:light[level=12]
setblock 172 131 332 minecraft:light[level=12]
setblock 172 131 339 minecraft:light[level=12]
setblock 172 131 346 minecraft:light[level=12]
setblock 172 131 353 minecraft:light[level=12]
setblock 172 131 360 minecraft:light[level=12]
setblock 173 131 323 minecraft:dark_prismarine
fill 173 131 324 173 132 324 minecraft:blue_terracotta
setblock 173 131 363 minecraft:dark_prismarine
fill 174 131 323 174 134 323 minecraft:blue_terracotta
setblock 174 131 362 minecraft:dark_prismarine
fill 174 131 363 174 134 363 minecraft:blue_terracotta
setblock 174 131 364 minecraft:black_concrete
fill 175 131 362 175 132 362 minecraft:blue_terracotta
setblock 178 131 323 minecraft:dark_prismarine
fill 178 131 339 178 137 339 minecraft:magenta_terracotta
setblock 178 131 363 minecraft:dark_prismarine
setblock 179 131 322 minecraft:black_concrete
fill 179 131 323 179 134 323 minecraft:blue_terracotta
setblock 179 131 325 minecraft:light[level=12]
setblock 179 131 332 minecraft:light[level=12]
setblock 179 131 339 minecraft:light[level=12]
setblock 179 131 346 minecraft:light[level=12]
setblock 179 131 353 minecraft:light[level=12]
setblock 179 131 360 minecraft:light[level=12]
setblock 179 131 362 minecraft:dark_prismarine
fill 179 131 363 179 134 363 minecraft:blue_terracotta
fill 180 131 362 180 134 362 minecraft:blue_terracotta
fill 181 131 322 182 131 322 minecraft:black_concrete
setblock 181 131 360 minecraft:dark_prismarine
fill 181 131 361 181 134 361 minecraft:blue_terracotta
setblock 182 131 323 minecraft:blue_terracotta
setblock 182 131 324 minecraft:dark_prismarine
setblock 182 131 329 minecraft:purple_concrete
setblock 182 131 339 minecraft:dark_prismarine
fill 182 131 340 182 134 340 minecraft:blue_terracotta
setblock 182 131 343 minecraft:blue_terracotta
setblock 182 131 344 minecraft:dark_prismarine
fill 182 131 345 182 134 345 minecraft:blue_terracotta
setblock 182 131 348 minecraft:blue_terracotta
setblock 182 131 354 minecraft:dark_prismarine
fill 182 131 355 182 134 355 minecraft:blue_terracotta
setblock 182 131 359 minecraft:dark_prismarine
fill 182 131 360 182 134 360 minecraft:blue_terracotta
fill 183 131 334 183 131 335 minecraft:black_concrete
setblock 183 131 344 minecraft:light_blue_wool
setblock 183 131 359 minecraft:black_concrete
fill 141 132 323 141 133 325 minecraft:blue_terracotta
fill 141 132 327 141 220 327 minecraft:blue_terracotta
fill 141 132 329 141 132 342 minecraft:blue_terracotta
fill 141 132 344 141 132 347 minecraft:blue_terracotta
fill 141 132 349 141 132 359 minecraft:blue_terracotta
setblock 141 132 360 minecraft:black_concrete
fill 141 132 361 141 133 364 minecraft:blue_terracotta
fill 142 132 322 149 132 322 minecraft:blue_terracotta
setblock 142 132 323 minecraft:dark_prismarine
setblock 142 132 338 minecraft:dark_prismarine
fill 142 132 339 142 135 339 minecraft:blue_terracotta
setblock 142 132 342 minecraft:blue_terracotta
setblock 142 132 343 minecraft:dark_prismarine
fill 142 132 344 142 135 344 minecraft:blue_terracotta
setblock 142 132 347 minecraft:blue_terracotta
setblock 142 132 348 minecraft:dark_prismarine
fill 142 132 349 142 135 349 minecraft:blue_terracotta
setblock 142 132 353 minecraft:dark_prismarine
fill 142 132 354 142 135 354 minecraft:blue_terracotta
setblock 142 132 358 minecraft:dark_prismarine
fill 142 132 359 142 135 359 minecraft:blue_terracotta
setblock 142 132 363 minecraft:dark_prismarine
fill 142 132 364 146 132 364 minecraft:blue_terracotta
fill 143 132 323 143 135 323 minecraft:blue_terracotta
fill 143 132 338 143 135 338 minecraft:blue_terracotta
setblock 143 132 342 minecraft:dark_prismarine
fill 143 132 343 143 135 343 minecraft:blue_terracotta
setblock 143 132 347 minecraft:dark_prismarine
fill 143 132 348 143 135 348 minecraft:blue_terracotta
fill 143 132 350 143 133 350 minecraft:blue_terracotta
fill 143 132 357 143 135 357 minecraft:purple_concrete
setblock 143 132 362 minecraft:dark_prismarine
fill 143 132 363 143 135 363 minecraft:blue_terracotta
setblock 144 132 341 minecraft:dark_prismarine
fill 144 132 342 144 135 342 minecraft:blue_terracotta
setblock 144 132 346 minecraft:dark_prismarine
fill 144 132 347 144 135 347 minecraft:blue_terracotta
fill 144 132 362 144 135 362 minecraft:blue_terracotta
setblock 145 132 341 minecraft:blue_terracotta
setblock 147 132 323 minecraft:dark_prismarine
setblock 147 132 363 minecraft:dark_prismarine
setblock 147 132 364 minecraft:light_blue_wool
fill 148 132 323 148 135 323 minecraft:blue_terracotta
setblock 148 132 362 minecraft:dark_prismarine
fill 148 132 363 148 133 364 minecraft:blue_terracotta
fill 149 132 364 155 132 364 minecraft:blue_terracotta
fill 151 132 322 161 132 322 minecraft:blue_terracotta
setblock 152 132 323 minecraft:dark_prismarine
setblock 157 132 323 minecraft:dark_prismarine
fill 157 132 364 159 133 364 minecraft:blue_terracotta
fill 158 132 323 158 135 323 minecraft:blue_terracotta
setblock 161 132 324 minecraft:dark_prismarine
fill 161 132 364 161 133 364 minecraft:black_concrete
setblock 162 132 323 minecraft:dark_prismarine
fill 162 132 324 162 135 324 minecraft:blue_terracotta
setblock 162 132 363 minecraft:dark_prismarine
fill 162 132 364 180 132 364 minecraft:blue_terracotta
fill 163 132 322 163 135 323 minecraft:blue_terracotta
setblock 163 132 362 minecraft:dark_prismarine
fill 163 132 363 163 135 363 minecraft:blue_terracotta
fill 164 132 322 183 132 322 minecraft:blue_terracotta
fill 164 132 362 164 135 362 minecraft:blue_terracotta
setblock 165 132 325 minecraft:dark_prismarine
setblock 166 132 324 minecraft:dark_prismarine
fill 166 132 325 166 135 325 minecraft:blue_terracotta
setblock 166 132 363 minecraft:blue_terracotta
setblock 167 132 323 minecraft:dark_prismarine
fill 167 132 324 167 135 324 minecraft:blue_terracotta
setblock 167 132 363 minecraft:dark_prismarine
fill 168 132 323 168 135 323 minecraft:blue_terracotta
setblock 168 132 362 minecraft:dark_prismarine
fill 168 132 363 168 135 363 minecraft:blue_terracotta
fill 169 132 362 172 132 362 minecraft:blue_terracotta
setblock 171 132 324 minecraft:dark_prismarine
setblock 172 132 323 minecraft:dark_prismarine
fill 172 132 324 172 135 324 minecraft:blue_terracotta
setblock 172 132 363 minecraft:dark_prismarine
fill 173 132 323 173 135 323 minecraft:blue_terracotta
setblock 173 132 362 minecraft:dark_prismarine
fill 173 132 363 173 135 363 minecraft:blue_terracotta
setblock 174 132 362 minecraft:blue_terracotta
setblock 177 132 323 minecraft:dark_prismarine
setblock 177 132 363 minecraft:dark_prismarine
fill 178 132 323 178 135 323 minecraft:blue_terracotta
setblock 178 132 362 minecraft:dark_prismarine
fill 178 132 363 178 135 363 minecraft:blue_terracotta
fill 179 132 362 179 135 362 minecraft:blue_terracotta
setblock 181 132 359 minecraft:dark_prismarine
fill 181 132 360 181 135 360 minecraft:blue_terracotta
setblock 182 132 323 minecraft:dark_prismarine
fill 182 132 324 182 134 325 minecraft:blue_terracotta
fill 182 132 339 183 135 339 minecraft:blue_terracotta
setblock 182 132 343 minecraft:dark_prismarine
fill 182 132 344 183 135 344 minecraft:blue_terracotta
setblock 182 132 348 minecraft:dark_prismarine
fill 182 132 349 183 132 352 minecraft:blue_terracotta
setblock 182 132 353 minecraft:dark_prismarine
fill 182 132 354 183 135 354 minecraft:blue_terracotta
setblock 182 132 358 minecraft:dark_prismarine
fill 182 132 359 183 135 359 minecraft:blue_terracotta
setblock 182 132 363 minecraft:dark_prismarine
fill 182 132 364 183 216 364 minecraft:blue_terracotta
fill 183 132 323 183 133 324 minecraft:blue_terracotta
fill 183 132 326 183 132 336 minecraft:blue_terracotta
fill 183 132 337 183 133 337 minecraft:black_concrete
fill 183 132 338 183 220 338 minecraft:blue_terracotta
fill 183 132 340 183 153 343 minecraft:blue_terracotta
fill 183 132 345 183 173 348 minecraft:blue_terracotta
fill 183 132 353 183 147 353 minecraft:blue_terracotta
fill 183 132 355 183 132 358 minecraft:blue_terracotta
fill 183 132 360 183 132 363 minecraft:blue_terracotta
fill 141 133 322 146 133 322 minecraft:blue_terracotta
fill 141 133 326 141 217 326 minecraft:blue_terracotta
fill 141 133 328 141 133 334 minecraft:blue_terracotta
setblock 141 133 335 minecraft:black_concrete
fill 141 133 336 141 158 338 minecraft:blue_terracotta
fill 141 133 339 141 133 341 minecraft:black_concrete
fill 141 133 342 141 133 343 minecraft:blue_terracotta
fill 141 133 344 141 134 344 minecraft:black_concrete
fill 141 133 345 141 133 347 minecraft:blue_terracotta
fill 141 133 349 141 141 356 minecraft:blue_terracotta
fill 141 133 357 141 133 358 minecraft:black_concrete
fill 141 133 359 141 133 360 minecraft:blue_terracotta
fill 142 133 323 142 135 324 minecraft:blue_terracotta
setblock 142 133 325 minecraft:purple_concrete
setblock 142 133 336 minecraft:blue_terracotta
setblock 142 133 337 minecraft:dark_prismarine
fill 142 133 338 142 136 338 minecraft:blue_terracotta
setblock 142 133 342 minecraft:dark_prismarine
fill 142 133 343 142 136 343 minecraft:blue_terracotta
setblock 142 133 347 minecraft:dark_prismarine
fill 142 133 348 142 136 348 minecraft:blue_terracotta
setblock 142 133 352 minecraft:dark_prismarine
fill 142 133 353 142 136 353 minecraft:blue_terracotta
setblock 142 133 357 minecraft:dark_prismarine
fill 142 133 358 142 136 358 minecraft:blue_terracotta
setblock 142 133 361 minecraft:blue_terracotta
setblock 142 133 362 minecraft:dark_prismarine
fill 142 133 363 142 136 363 minecraft:blue_terracotta
setblock 142 133 364 minecraft:black_concrete
setblock 143 133 340 minecraft:blue_terracotta
setblock 143 133 341 minecraft:dark_prismarine
fill 143 133 342 143 136 342 minecraft:blue_terracotta
setblock 143 133 346 minecraft:dark_prismarine
fill 143 133 347 143 136 347 minecraft:blue_terracotta
setblock 143 133 351 minecraft:dark_prismarine
fill 143 133 356 144 135 356 minecraft:purple_concrete
fill 143 133 358 144 135 358 minecraft:purple_concrete
setblock 143 133 361 minecraft:dark_prismarine
fill 143 133 362 143 136 362 minecraft:blue_terracotta
fill 143 133 364 147 164 364 minecraft:blue_terracotta
setblock 144 133 325 minecraft:light[level=13]
setblock 144 133 333 minecraft:light[level=13]
setblock 144 133 340 minecraft:dark_prismarine
fill 144 133 341 144 136 341 minecraft:blue_terracotta
setblock 144 133 345 minecraft:dark_prismarine
fill 144 133 346 144 136 346 minecraft:blue_terracotta
fill 144 133 348 144 134 348 minecraft:blue_terracotta
setblock 144 133 349 minecraft:light[level=13]
setblock 145 133 344 minecraft:dark_prismarine
fill 145 133 345 145 136 345 minecraft:blue_terracotta
fill 145 133 357 145 135 357 minecraft:purple_concrete
setblock 146 133 323 minecraft:dark_prismarine
setblock 146 133 363 minecraft:dark_prismarine
setblock 147 133 322 minecraft:black_concrete
fill 147 133 323 147 136 323 minecraft:blue_terracotta
setblock 147 133 362 minecraft:dark_prismarine
fill 147 133 363 147 136 363 minecraft:blue_terracotta
fill 148 133 322 151 133 322 minecraft:blue_terracotta
fill 149 133 335 149 136 335 minecraft:magenta_terracotta
fill 149 133 364 151 220 364 minecraft:blue_terracotta
setblock 151 133 323 minecraft:dark_prismarine
setblock 152 133 322 minecraft:black_concrete
fill 152 133 323 152 136 323 minecraft:blue_terracotta
setblock 152 133 325 minecraft:light[level=13]
setblock 152 133 333 minecraft:light[level=13]
setblock 152 133 349 minecraft:light[level=13]
setblock 152 133 357 minecraft:light[level=13]
setblock 152 133 364 minecraft:black_concrete
fill 153 133 322 156 134 322 minecraft:blue_terracotta
fill 153 133 364 156 171 364 minecraft:blue_terracotta
setblock 156 133 323 minecraft:dark_prismarine
setblock 157 133 322 minecraft:black_concrete
fill 157 133 323 157 136 323 minecraft:blue_terracotta
fill 158 133 322 162 176 322 minecraft:blue_terracotta
setblock 160 133 324 minecraft:dark_prismarine
setblock 160 133 325 minecraft:light[level=13]
setblock 160 133 333 minecraft:light[level=13]
setblock 160 133 341 minecraft:light[level=13]
setblock 160 133 349 minecraft:light[level=13]
setblock 160 133 357 minecraft:light[level=13]
fill 160 133 363 160 133 364 minecraft:blue_terracotta
setblock 161 133 323 minecraft:dark_prismarine
fill 161 133 324 161 136 324 minecraft:blue_terracotta
setblock 161 133 363 minecraft:dark_prismarine
fill 162 133 323 162 136 323 minecraft:blue_terracotta
fill 162 133 363 162 133 364 minecraft:blue_terracotta
setblock 163 133 325 minecraft:blue_terracotta
fill 163 133 362 163 136 362 minecraft:blue_terracotta
fill 163 133 364 163 220 364 minecraft:blue_terracotta
fill 164 133 322 168 133 322 minecraft:blue_terracotta
setblock 164 133 325 minecraft:dark_prismarine
setblock 164 133 364 minecraft:black_concrete
setblock 165 133 324 minecraft:dark_prismarine
fill 165 133 325 165 136 325 minecraft:blue_terracotta
fill 165 133 364 174 133 364 minecraft:blue_terracotta
setblock 166 133 323 minecraft:dark_prismarine
fill 166 133 324 166 136 324 minecraft:blue_terracotta
setblock 166 133 363 minecraft:dark_prismarine
fill 167 133 323 167 136 323 minecraft:blue_terracotta
setblock 167 133 362 minecraft:dark_prismarine
fill 167 133 363 167 136 363 minecraft:blue_terracotta
setblock 168 133 333 minecraft:light[level=13]
setblock 168 133 341 minecraft:light[level=13]
setblock 168 133 349 minecraft:light[level=13]
setblock 168 133 357 minecraft:light[level=13]
fill 168 133 362 171 133 362 minecraft:blue_terracotta
setblock 169 133 322 minecraft:black_concrete
setblock 169 133 325 minecraft:dark_prismarine
fill 170 133 322 175 162 322 minecraft:blue_terracotta
setblock 170 133 324 minecraft:dark_prismarine
setblock 171 133 323 minecraft:dark_prismarine
fill 171 133 324 171 136 324 minecraft:blue_terracotta
setblock 171 133 363 minecraft:dark_prismarine
fill 172 133 323 172 136 323 minecraft:blue_terracotta
fill 172 133 352 172 160 352 minecraft:magenta_terracotta
setblock 172 133 362 minecraft:dark_prismarine
fill 172 133 363 172 136 363 minecraft:blue_terracotta
setblock 173 133 362 minecraft:blue_terracotta
setblock 175 133 364 minecraft:black_concrete
setblock 176 133 322 minecraft:black_concrete
setblock 176 133 323 minecraft:dark_prismarine
setblock 176 133 325 minecraft:light[level=13]
setblock 176 133 333 minecraft:light[level=13]
setblock 176 133 341 minecraft:light[level=13]
setblock 176 133 349 minecraft:light[level=13]
setblock 176 133 357 minecraft:light[level=13]
setblock 176 133 363 minecraft:dark_prismarine
fill 176 133 364 177 133 364 minecraft:blue_terracotta
fill 177 133 322 177 136 323 minecraft:blue_terracotta
fill 177 133 363 177 136 363 minecraft:blue_terracotta
fill 178 133 322 178 220 322 minecraft:blue_terracotta
setblock 178 133 362 minecraft:blue_terracotta
setblock 178 133 364 minecraft:black_concrete
setblock 179 133 322 minecraft:black_concrete
fill 179 133 364 181 220 364 minecraft:blue_terracotta
fill 180 133 322 183 133 322 minecraft:blue_terracotta
setblock 181 133 323 minecraft:dark_prismarine
fill 181 133 359 181 136 359 minecraft:blue_terracotta
setblock 181 133 363 minecraft:dark_prismarine
fill 182 133 323 182 136 323 minecraft:blue_terracotta
setblock 182 133 336 minecraft:purple_concrete
setblock 182 133 342 minecraft:dark_prismarine
fill 182 133 343 182 136 343 minecraft:blue_terracotta
setblock 182 133 346 minecraft:blue_terracotta
setblock 182 133 347 minecraft:dark_prismarine
fill 182 133 348 182 133 351 minecraft:blue_terracotta
setblock 182 133 352 minecraft:dark_prismarine
fill 182 133 353 182 136 353 minecraft:blue_terracotta
setblock 182 133 357 minecraft:dark_prismarine
fill 182 133 358 183 136 358 minecraft:blue_terracotta
setblock 182 133 362 minecraft:dark_prismarine
fill 182 133 363 182 136 363 minecraft:blue_terracotta
setblock 183 133 325 minecraft:cyan_concrete
fill 183 133 326 183 133 331 minecraft:blue_terracotta
setblock 183 133 332 minecraft:black_concrete
fill 183 133 333 183 220 334 minecraft:blue_terracotta
setblock 183 133 335 minecraft:black_concrete
fill 183 133 336 183 216 336 minecraft:blue_terracotta
fill 183 133 349 183 171 349 minecraft:blue_terracotta
setblock 183 133 350 minecraft:black_concrete
fill 183 133 351 183 170 352 minecraft:blue_terracotta
fill 183 133 355 183 142 356 minecraft:blue_terracotta
setblock 183 133 357 minecraft:black_concrete
fill 183 133 360 183 181 362 minecraft:blue_terracotta
setblock 183 133 363 minecraft:black_concrete
fill 141 134 322 141 134 324 minecraft:black_concrete
fill 141 134 325 142 134 325 minecraft:blue_terracotta
fill 141 134 328 141 170 332 minecraft:blue_terracotta
setblock 141 134 333 minecraft:black_concrete
fill 141 134 334 141 217 335 minecraft:blue_terracotta
setblock 141 134 339 minecraft:black_concrete
fill 141 134 340 141 171 341 minecraft:blue_terracotta
setblock 141 134 342 minecraft:black_concrete
fill 141 134 343 141 168 343 minecraft:blue_terracotta
fill 141 134 345 141 161 345 minecraft:blue_terracotta
fill 141 134 346 141 134 347 minecraft:black_concrete
fill 141 134 348 141 216 348 minecraft:blue_terracotta
fill 141 134 357 141 213 358 minecraft:blue_terracotta
setblock 141 134 359 minecraft:black_concrete
fill 141 134 360 141 137 363 minecraft:blue_terracotta
setblock 141 134 364 minecraft:black_concrete
fill 142 134 322 147 143 322 minecraft:blue_terracotta
setblock 142 134 326 minecraft:dark_prismarine
setblock 142 134 331 minecraft:purple_concrete
setblock 142 134 336 minecraft:dark_prismarine
fill 142 134 337 142 137 337 minecraft:blue_terracotta
setblock 142 134 341 minecraft:dark_prismarine
fill 142 134 342 142 137 342 minecraft:blue_terracotta
setblock 142 134 346 minecraft:dark_prismarine
fill 142 134 347 142 137 347 minecraft:blue_terracotta
setblock 142 134 351 minecraft:dark_prismarine
fill 142 134 352 143 136 352 minecraft:blue_terracotta
setblock 142 134 356 minecraft:dark_prismarine
fill 142 134 357 142 137 357 minecraft:blue_terracotta
setblock 142 134 361 minecraft:dark_prismarine
fill 142 134 362 142 137 362 minecraft:blue_terracotta
fill 142 134 364 142 216 364 minecraft:blue_terracotta
setblock 143 134 340 minecraft:dark_prismarine
fill 143 134 341 143 137 341 minecraft:blue_terracotta
setblock 143 134 345 minecraft:dark_prismarine
fill 143 134 346 143 137 346 minecraft:blue_terracotta
setblock 143 134 350 minecraft:dark_prismarine
fill 143 134 351 143 137 351 minecraft:blue_terracotta
setblock 144 134 324 minecraft:dark_prismarine
setblock 144 134 339 minecraft:dark_prismarine
fill 144 134 340 144 137 340 minecraft:blue_terracotta
setblock 144 134 344 minecraft:dark_prismarine
fill 144 134 345 144 137 345 minecraft:blue_terracotta
setblock 144 134 349 minecraft:dark_prismarine
setblock 145 134 323 minecraft:dark_prismarine
fill 145 134 324 147 135 324 minecraft:blue_terracotta
setblock 145 134 343 minecraft:dark_prismarine
fill 145 134 344 145 137 344 minecraft:blue_terracotta
fill 145 134 346 145 135 346 minecraft:blue_terracotta
setblock 145 134 363 minecraft:dark_prismarine
fill 146 134 323 146 137 323 minecraft:blue_terracotta
fill 146 134 363 146 137 363 minecraft:blue_terracotta
setblock 148 134 322 minecraft:black_concrete
fill 148 134 363 148 135 363 minecraft:blue_terracotta
setblock 148 134 364 minecraft:black_concrete
fill 149 134 322 152 137 322 minecraft:blue_terracotta
setblock 150 134 323 minecraft:dark_prismarine
fill 151 134 323 151 137 323 minecraft:blue_terracotta
fill 152 134 364 152 209 364 minecraft:blue_terracotta
fill 153 134 323 154 134 323 minecraft:blue_terracotta
setblock 154 134 363 minecraft:purple_concrete
setblock 155 134 323 minecraft:dark_prismarine
fill 156 134 323 156 137 323 minecraft:blue_terracotta
fill 156 134 357 156 194 357 minecraft:magenta_terracotta
fill 157 134 322 157 216 322 minecraft:blue_terracotta
setblock 157 134 364 minecraft:black_concrete
fill 158 134 364 161 140 364 minecraft:blue_terracotta
setblock 159 134 324 minecraft:dark_prismarine
setblock 160 134 323 minecraft:dark_prismarine
fill 160 134 324 160 137 324 minecraft:blue_terracotta
setblock 160 134 363 minecraft:dark_prismarine
fill 161 134 323 161 137 323 minecraft:blue_terracotta
fill 161 134 325 162 134 325 minecraft:blue_terracotta
fill 161 134 363 162 136 363 minecraft:blue_terracotta
setblock 162 134 364 minecraft:black_concrete
setblock 163 134 325 minecraft:dark_prismarine
fill 164 134 322 164 216 322 minecraft:blue_terracotta
setblock 164 134 324 minecraft:dark_prismarine
fill 164 134 325 164 137 325 minecraft:blue_terracotta
fill 164 134 364 167 141 364 minecraft:blue_terracotta
fill 165 134 322 166 134 322 minecraft:black_concrete
setblock 165 134 323 minecraft:dark_prismarine
fill 165 134 324 165 137 324 minecraft:blue_terracotta
setblock 165 134 363 minecraft:dark_prismarine
fill 166 134 323 166 137 323 minecraft:blue_terracotta
setblock 166 134 362 minecraft:dark_prismarine
fill 166 134 363 166 137 363 minecraft:blue_terracotta
fill 167 134 322 169 141 322 minecraft:blue_terracotta
fill 167 134 362 170 134 362 minecraft:blue_terracotta
setblock 168 134 325 minecraft:dark_prismarine
fill 168 134 364 169 134 364 minecraft:black_concrete
setblock 169 134 324 minecraft:dark_prismarine
fill 169 134 325 169 137 325 minecraft:blue_terracotta
setblock 170 134 323 minecraft:dark_prismarine
fill 170 134 324 170 137 324 minecraft:blue_terracotta
setblock 170 134 363 minecraft:dark_prismarine
fill 170 134 364 170 166 364 minecraft:blue_terracotta
fill 171 134 323 171 137 323 minecraft:blue_terracotta
setblock 171 134 362 minecraft:dark_prismarine
fill 171 134 363 171 137 363 minecraft:blue_terracotta
setblock 171 134 364 minecraft:black_concrete
setblock 172 134 362 minecraft:blue_terracotta
fill 172 134 364 175 136 364 minecraft:blue_terracotta
setblock 175 134 323 minecraft:dark_prismarine
setblock 175 134 363 minecraft:dark_prismarine
fill 176 134 322 176 137 323 minecraft:blue_terracotta
fill 176 134 363 176 137 363 minecraft:blue_terracotta
fill 176 134 364 177 134 364 minecraft:black_concrete
fill 178 134 364 178 220 364 minecraft:blue_terracotta
fill 179 134 322 182 189 322 minecraft:blue_terracotta
setblock 180 134 323 minecraft:dark_prismarine
setblock 180 134 363 minecraft:dark_prismarine
fill 181 134 323 181 137 323 minecraft:blue_terracotta
fill 181 134 343 181 134 346 minecraft:blue_terracotta
setblock 181 134 347 minecraft:dark_prismarine
fill 181 134 348 182 136 348 minecraft:blue_terracotta
setblock 181 134 362 minecraft:dark_prismarine
fill 181 134 363 181 137 363 minecraft:blue_terracotta
setblock 182 134 326 minecraft:dark_prismarine
setblock 182 134 330 minecraft:purple_concrete
setblock 182 134 341 minecraft:dark_prismarine
fill 182 134 342 182 137 342 minecraft:blue_terracotta
setblock 182 134 346 minecraft:dark_prismarine
fill 182 134 347 182 137 347 minecraft:blue_terracotta
fill 182 134 349 182 134 350 minecraft:blue_terracotta
setblock 182 134 351 minecraft:dark_prismarine
fill 182 134 352 182 137 352 minecraft:blue_terracotta
setblock 182 134 356 minecraft:dark_prismarine
fill 182 134 357 183 137 357 minecraft:blue_terracotta
setblock 182 134 361 minecraft:dark_prismarine
fill 182 134 362 182 137 362 minecraft:blue_terracotta
fill 183 134 322 183 134 324 minecraft:black_concrete
fill 183 134 325 183 152 329 minecraft:blue_terracotta
fill 183 134 330 183 134 331 minecraft:black_concrete
fill 183 134 332 183 220 332 minecraft:blue_terracotta
fill 183 134 335 183 220 335 minecraft:blue_terracotta
fill 183 134 337 183 220 337 minecraft:blue_terracotta
fill 183 134 350 183 220 350 minecraft:blue_terracotta
fill 183 134 363 183 220 363 minecraft:blue_terracotta
fill 141 135 322 141 218 325 minecraft:blue_terracotta
fill 141 135 333 141 220 333 minecraft:blue_terracotta
fill 141 135 339 141 216 339 minecraft:blue_terracotta
fill 141 135 342 141 181 342 minecraft:blue_terracotta
fill 141 135 344 141 220 344 minecraft:blue_terracotta
fill 141 135 346 141 144 347 minecraft:blue_terracotta
fill 141 135 359 141 220 359 minecraft:blue_terracotta
fill 141 135 364 141 216 364 minecraft:blue_terracotta
setblock 142 135 325 minecraft:dark_prismarine
fill 142 135 326 142 135 329 minecraft:blue_terracotta
setblock 142 135 335 minecraft:dark_prismarine
fill 142 135 336 142 138 336 minecraft:blue_terracotta
setblock 142 135 340 minecraft:dark_prismarine
fill 142 135 341 142 138 341 minecraft:blue_terracotta
setblock 142 135 345 minecraft:dark_prismarine
fill 142 135 346 142 138 346 minecraft:blue_terracotta
setblock 142 135 350 minecraft:dark_prismarine
fill 142 135 351 142 138 351 minecraft:blue_terracotta
setblock 142 135 355 minecraft:dark_prismarine
fill 142 135 356 142 138 356 minecraft:blue_terracotta
setblock 142 135 360 minecraft:dark_prismarine
fill 142 135 361 142 138 361 minecraft:blue_terracotta
setblock 143 135 324 minecraft:dark_prismarine
fill 143 135 325 143 138 325 minecraft:blue_terracotta
fill 143 135 337 143 136 337 minecraft:blue_terracotta
setblock 143 135 339 minecraft:dark_prismarine
fill 143 135 340 143 138 340 minecraft:blue_terracotta
setblock 143 135 344 minecraft:dark_prismarine
fill 143 135 345 143 138 345 minecraft:blue_terracotta
setblock 143 135 349 minecraft:dark_prismarine
fill 143 135 350 144 137 350 minecraft:blue_terracotta
setblock 143 135 353 minecraft:blue_terracotta
setblock 144 135 323 minecraft:dark_prismarine
fill 144 135 324 144 138 324 minecraft:blue_terracotta
fill 144 135 339 144 138 339 minecraft:blue_terracotta
setblock 144 135 343 minecraft:dark_prismarine
fill 144 135 344 144 138 344 minecraft:blue_terracotta
setblock 144 135 348 minecraft:dark_prismarine
fill 144 135 349 144 138 349 minecraft:blue_terracotta
setblock 144 135 363 minecraft:dark_prismarine
fill 145 135 323 145 138 323 minecraft:blue_terracotta
setblock 145 135 342 minecraft:dark_prismarine
fill 145 135 343 145 138 343 minecraft:blue_terracotta
setblock 145 135 347 minecraft:dark_prismarine
setblock 145 135 356 minecraft:purple_concrete
setblock 145 135 358 minecraft:purple_concrete
fill 145 135 363 145 138 363 minecraft:blue_terracotta
fill 146 135 348 146 193 348 minecraft:magenta_terracotta
fill 146 135 349 146 136 349 minecraft:pink_terracotta
fill 148 135 322 148 158 322 minecraft:blue_terracotta
setblock 148 135 324 minecraft:dark_prismarine
fill 148 135 364 148 218 364 minecraft:blue_terracotta
setblock 149 135 323 minecraft:dark_prismarine
setblock 149 135 363 minecraft:dark_prismarine
fill 150 135 323 150 138 323 minecraft:blue_terracotta
fill 151 135 335 151 136 335 minecraft:pink_terracotta
fill 151 135 336 152 151 336 minecraft:magenta_terracotta
setblock 153 135 322 minecraft:cyan_concrete
setblock 153 135 323 minecraft:blue_terracotta
fill 154 135 322 156 189 322 minecraft:blue_terracotta
setblock 154 135 323 minecraft:dark_prismarine
fill 155 135 323 155 138 323 minecraft:blue_terracotta
setblock 157 135 324 minecraft:blue_terracotta
fill 157 135 364 157 221 364 minecraft:blue_terracotta
setblock 158 135 324 minecraft:dark_prismarine
setblock 159 135 323 minecraft:dark_prismarine
fill 159 135 324 159 138 324 minecraft:blue_terracotta
setblock 159 135 363 minecraft:dark_prismarine
fill 160 135 323 160 138 323 minecraft:blue_terracotta
fill 160 135 325 161 135 325 minecraft:blue_terracotta
fill 160 135 363 160 138 363 minecraft:blue_terracotta
setblock 162 135 325 minecraft:dark_prismarine
fill 162 135 362 162 137 362 minecraft:blue_terracotta
fill 162 135 364 162 220 364 minecraft:blue_terracotta
setblock 163 135 324 minecraft:dark_prismarine
fill 163 135 325 163 138 325 minecraft:blue_terracotta
setblock 164 135 323 minecraft:dark_prismarine
fill 164 135 324 164 138 324 minecraft:blue_terracotta
fill 164 135 326 165 135 326 minecraft:blue_terracotta
setblock 164 135 363 minecraft:dark_prismarine
fill 165 135 322 165 138 323 minecraft:blue_terracotta
setblock 165 135 362 minecraft:dark_prismarine
fill 165 135 363 165 138 363 minecraft:blue_terracotta
fill 166 135 322 166 217 322 minecraft:blue_terracotta
fill 166 135 362 169 135 362 minecraft:blue_terracotta
setblock 167 135 325 minecraft:dark_prismarine
setblock 168 135 324 minecraft:dark_prismarine
fill 168 135 325 168 138 325 minecraft:blue_terracotta
fill 168 135 364 169 220 364 minecraft:blue_terracotta
setblock 169 135 323 minecraft:dark_prismarine
fill 169 135 324 169 138 324 minecraft:blue_terracotta
setblock 169 135 363 minecraft:dark_prismarine
fill 170 135 323 170 138 323 minecraft:blue_terracotta
setblock 170 135 362 minecraft:dark_prismarine
fill 170 135 363 170 138 363 minecraft:blue_terracotta
fill 171 135 362 171 136 362 minecraft:blue_terracotta
fill 171 135 364 171 196 364 minecraft:blue_terracotta
fill 173 135 350 173 148 350 minecraft:magenta_terracotta
fill 173 135 351 173 136 351 minecraft:pink_terracotta
setblock 174 135 323 minecraft:dark_prismarine
setblock 174 135 363 minecraft:dark_prismarine
fill 175 135 323 175 138 323 minecraft:blue_terracotta
fill 175 135 363 175 138 363 minecraft:blue_terracotta
fill 176 135 364 177 217 364 minecraft:blue_terracotta
fill 178 135 362 178 136 362 minecraft:blue_terracotta
setblock 179 135 323 minecraft:dark_prismarine
setblock 179 135 363 minecraft:dark_prismarine
fill 180 135 323 180 138 323 minecraft:blue_terracotta
setblock 180 135 362 minecraft:dark_prismarine
fill 180 135 363 180 138 363 minecraft:blue_terracotta
fill 181 135 324 183 135 324 minecraft:blue_terracotta
fill 181 135 342 181 135 345 minecraft:blue_terracotta
setblock 181 135 346 minecraft:dark_prismarine
fill 181 135 347 181 138 347 minecraft:blue_terracotta
fill 181 135 349 181 135 350 minecraft:blue_terracotta
setblock 181 135 351 minecraft:dark_prismarine
setblock 181 135 361 minecraft:dark_prismarine
fill 181 135 362 181 138 362 minecraft:blue_terracotta
setblock 182 135 325 minecraft:dark_prismarine
fill 182 135 326 182 137 327 minecraft:blue_terracotta
setblock 182 135 340 minecraft:dark_prismarine
fill 182 135 341 182 138 341 minecraft:blue_terracotta
setblock 182 135 345 minecraft:dark_prismarine
fill 182 135 346 182 138 346 minecraft:blue_terracotta
setblock 182 135 349 minecraft:blue_terracotta
setblock 182 135 350 minecraft:dark_prismarine
fill 182 135 351 182 138 351 minecraft:blue_terracotta
setblock 182 135 355 minecraft:dark_prismarine
fill 182 135 356 182 138 356 minecraft:blue_terracotta
setblock 182 135 360 minecraft:dark_prismarine
fill 182 135 361 182 138 361 minecraft:blue_terracotta
fill 183 135 322 183 216 323 minecraft:blue_terracotta
fill 183 135 330 183 148 331 minecraft:blue_terracotta
setblock 142 136 323 minecraft:blue_terracotta
setblock 142 136 324 minecraft:dark_prismarine
fill 142 136 325 142 136 328 minecraft:blue_terracotta
setblock 142 136 329 minecraft:dark_prismarine
fill 142 136 330 142 136 333 minecraft:blue_terracotta
setblock 142 136 334 minecraft:dark_prismarine
fill 142 136 335 142 139 335 minecraft:blue_terracotta
setblock 142 136 339 minecraft:dark_prismarine
fill 142 136 340 142 139 340 minecraft:blue_terracotta
setblock 142 136 344 minecraft:dark_prismarine
fill 142 136 345 142 139 345 minecraft:blue_terracotta
setblock 142 136 349 minecraft:dark_prismarine
fill 142 136 350 142 139 350 minecraft:blue_terracotta
setblock 142 136 354 minecraft:dark_prismarine
fill 142 136 355 142 138 355 minecraft:blue_terracotta
fill 142 136 359 146 136 359 minecraft:dark_prismarine
fill 142 136 360 142 139 360 minecraft:blue_terracotta
setblock 143 136 323 minecraft:dark_prismarine
fill 143 136 324 143 139 324 minecraft:blue_terracotta
fill 143 136 326 143 136 327 minecraft:blue_terracotta
setblock 143 136 328 minecraft:dark_prismarine
setblock 143 136 338 minecraft:dark_prismarine
fill 143 136 339 143 139 339 minecraft:blue_terracotta
setblock 143 136 343 minecraft:dark_prismarine
fill 143 136 344 143 139 344 minecraft:blue_terracotta
setblock 143 136 348 minecraft:dark_prismarine
fill 143 136 349 143 139 349 minecraft:blue_terracotta
fill 143 136 353 146 136 353 minecraft:dark_prismarine
fill 143 136 354 143 138 354 minecraft:blue_terracotta
fill 143 136 355 146 136 358 minecraft:dark_prismarine
fill 143 136 360 146 138 361 minecraft:dark_prismarine
setblock 143 136 363 minecraft:dark_prismarine
fill 144 136 323 144 139 323 minecraft:blue_terracotta
setblock 144 136 342 minecraft:dark_prismarine
fill 144 136 343 144 139 343 minecraft:blue_terracotta
setblock 144 136 347 minecraft:dark_prismarine
fill 144 136 348 144 139 348 minecraft:blue_terracotta
setblock 144 136 351 minecraft:blue_terracotta
fill 144 136 354 146 138 354 minecraft:dark_prismarine
fill 144 136 363 144 139 363 minecraft:blue_terracotta
fill 145 136 324 146 136 324 minecraft:blue_terracotta
fill 145 136 342 145 138 342 minecraft:blue_terracotta
setblock 145 136 346 minecraft:dark_prismarine
fill 145 136 347 145 139 347 minecraft:blue_terracotta
setblock 147 136 324 minecraft:dark_prismarine
setblock 148 136 323 minecraft:dark_prismarine
fill 148 136 324 149 138 324 minecraft:blue_terracotta
setblock 148 136 363 minecraft:dark_prismarine
fill 149 136 323 149 139 323 minecraft:blue_terracotta
fill 152 136 334 152 160 334 minecraft:magenta_terracotta
fill 153 136 322 153 152 322 minecraft:blue_terracotta
setblock 153 136 323 minecraft:dark_prismarine
fill 154 136 323 154 139 323 minecraft:blue_terracotta
setblock 156 136 324 minecraft:blue_terracotta
setblock 157 136 324 minecraft:dark_prismarine
fill 157 136 356 157 158 356 minecraft:magenta_terracotta
fill 157 136 357 158 136 357 minecraft:pink_terracotta
setblock 158 136 323 minecraft:dark_prismarine
fill 158 136 324 158 139 324 minecraft:blue_terracotta
setblock 158 136 363 minecraft:dark_prismarine
fill 159 136 323 159 139 323 minecraft:blue_terracotta
fill 159 136 325 160 136 325 minecraft:blue_terracotta
fill 159 136 357 159 140 357 minecraft:magenta_terracotta
fill 159 136 363 159 139 363 minecraft:blue_terracotta
setblock 161 136 325 minecraft:dark_prismarine
setblock 162 136 324 minecraft:dark_prismarine
fill 162 136 325 162 138 326 minecraft:blue_terracotta
fill 163 136 322 163 216 322 minecraft:blue_terracotta
setblock 163 136 323 minecraft:dark_prismarine
fill 163 136 324 163 139 324 minecraft:blue_terracotta
fill 163 136 326 164 136 326 minecraft:blue_terracotta
setblock 163 136 363 minecraft:dark_prismarine
fill 164 136 323 164 139 323 minecraft:blue_terracotta
setblock 164 136 362 minecraft:dark_prismarine
fill 164 136 363 164 139 363 minecraft:blue_terracotta
setblock 165 136 326 minecraft:dark_prismarine
fill 165 136 329 165 138 330 minecraft:magenta_terracotta
fill 165 136 362 168 136 362 minecraft:blue_terracotta
setblock 166 136 325 minecraft:dark_prismarine
fill 166 136 326 166 139 326 minecraft:blue_terracotta
setblock 166 136 329 minecraft:pink_terracotta
fill 166 136 330 166 153 330 minecraft:magenta_terracotta
setblock 167 136 324 minecraft:dark_prismarine
fill 167 136 325 167 139 325 minecraft:blue_terracotta
setblock 168 136 323 minecraft:dark_prismarine
fill 168 136 324 168 139 324 minecraft:blue_terracotta
setblock 168 136 363 minecraft:dark_prismarine
fill 169 136 323 169 139 323 minecraft:blue_terracotta
setblock 169 136 362 minecraft:dark_prismarine
fill 169 136 363 169 139 363 minecraft:blue_terracotta
fill 170 136 362 170 138 362 minecraft:blue_terracotta
setblock 172 136 324 minecraft:dark_prismarine
setblock 173 136 323 minecraft:dark_prismarine
setblock 173 136 363 minecraft:dark_prismarine
fill 174 136 323 174 139 323 minecraft:blue_terracotta
fill 174 136 363 174 139 363 minecraft:blue_terracotta
setblock 178 136 323 minecraft:dark_prismarine
setblock 178 136 337 minecraft:pink_terracotta
fill 178 136 338 178 160 338 minecraft:magenta_terracotta
setblock 178 136 363 minecraft:dark_prismarine
fill 179 136 323 179 138 324 minecraft:blue_terracotta
setblock 179 136 362 minecraft:dark_prismarine
fill 179 136 363 179 139 363 minecraft:blue_terracotta
fill 180 136 324 181 136 324 minecraft:blue_terracotta
fill 180 136 362 180 139 362 minecraft:blue_terracotta
setblock 181 136 325 minecraft:dark_prismarine
fill 181 136 342 181 136 344 minecraft:blue_terracotta
setblock 181 136 345 minecraft:dark_prismarine
fill 181 136 346 181 139 346 minecraft:blue_terracotta
setblock 181 136 349 minecraft:blue_terracotta
setblock 181 136 350 minecraft:dark_prismarine
fill 181 136 351 181 136 354 minecraft:blue_terracotta
setblock 181 136 355 minecraft:dark_prismarine
fill 181 136 358 181 137 358 minecraft:blue_terracotta
setblock 181 136 360 minecraft:dark_prismarine
fill 181 136 361 181 139 361 minecraft:blue_terracotta
setblock 182 136 324 minecraft:dark_prismarine
fill 182 136 325 182 139 325 minecraft:blue_terracotta
setblock 182 136 328 minecraft:blue_terracotta
setblock 182 136 329 minecraft:dark_prismarine
setblock 182 136 337 minecraft:purple_concrete
setblock 182 136 338 minecraft:blue_terracotta
setblock 182 136 339 minecraft:dark_prismarine
fill 182 136 340 182 139 340 minecraft:blue_terracotta
setblock 182 136 344 minecraft:dark_prismarine
fill 182 136 345 182 139 345 minecraft:blue_terracotta
setblock 182 136 349 minecraft:dark_prismarine
fill 182 136 350 182 139 350 minecraft:blue_terracotta
setblock 182 136 354 minecraft:dark_prismarine
fill 182 136 355 182 139 355 minecraft:blue_terracotta
setblock 182 136 359 minecraft:dark_prismarine
fill 182 136 360 182 139 360 minecraft:blue_terracotta
fill 183 136 324 183 198 324 minecraft:blue_terracotta
fill 183 136 339 183 140 339 minecraft:blue_terracotta
fill 183 136 344 183 216 344 minecraft:blue_terracotta
fill 183 136 354 183 180 354 minecraft:blue_terracotta
fill 183 136 359 183 220 359 minecraft:blue_terracotta
setblock 142 137 323 minecraft:dark_prismarine
fill 142 137 324 142 137 327 minecraft:blue_terracotta
setblock 142 137 328 minecraft:dark_prismarine
fill 142 137 329 142 137 332 minecraft:blue_terracotta
setblock 142 137 333 minecraft:dark_prismarine
fill 142 137 334 142 140 334 minecraft:blue_terracotta
setblock 142 137 338 minecraft:dark_prismarine
fill 142 137 339 142 140 339 minecraft:blue_terracotta
setblock 142 137 343 minecraft:dark_prismarine
fill 142 137 344 142 140 344 minecraft:blue_terracotta
setblock 142 137 348 minecraft:dark_prismarine
fill 142 137 349 142 140 349 minecraft:blue_terracotta
setblock 142 137 352 minecraft:blue_terracotta
setblock 142 137 353 minecraft:dark_prismarine
fill 142 137 354 142 140 354 minecraft:blue_terracotta
fill 142 137 358 146 137 358 minecraft:dark_prismarine
fill 142 137 359 142 138 359 minecraft:blue_terracotta
setblock 142 137 363 minecraft:dark_prismarine
fill 143 137 323 143 140 323 minecraft:blue_terracotta
setblock 143 137 326 minecraft:blue_terracotta
setblock 143 137 327 minecraft:dark_prismarine
fill 143 137 328 143 137 331 minecraft:blue_terracotta
fill 143 137 335 143 137 336 minecraft:blue_terracotta
setblock 143 137 337 minecraft:dark_prismarine
fill 143 137 338 143 140 338 minecraft:blue_terracotta
setblock 143 137 342 minecraft:dark_prismarine
fill 143 137 343 143 140 343 minecraft:blue_terracotta
setblock 143 137 347 minecraft:dark_prismarine
fill 143 137 348 143 140 348 minecraft:blue_terracotta
setblock 143 137 352 minecraft:dark_prismarine
fill 143 137 353 143 140 353 minecraft:blue_terracotta
fill 143 137 355 143 138 355 minecraft:blue_terracotta
fill 143 137 356 146 138 357 minecraft:dark_prismarine
fill 143 137 359 146 138 359 minecraft:dark_prismarine
setblock 143 137 362 minecraft:dark_prismarine
fill 143 137 363 143 140 363 minecraft:blue_terracotta
setblock 144 137 325 minecraft:blue_terracotta
setblock 144 137 332 minecraft:light[level=12]
setblock 144 137 341 minecraft:dark_prismarine
fill 144 137 342 144 140 342 minecraft:blue_terracotta
setblock 144 137 346 minecraft:dark_prismarine
fill 144 137 347 144 140 347 minecraft:blue_terracotta
setblock 144 137 351 minecraft:dark_prismarine
fill 144 137 352 144 140 352 minecraft:blue_terracotta
fill 144 137 353 146 138 353 minecraft:dark_prismarine
fill 144 137 355 146 138 355 minecraft:dark_prismarine
setblock 145 137 324 minecraft:blue_terracotta
setblock 145 137 345 minecraft:dark_prismarine
fill 145 137 346 145 140 346 minecraft:blue_terracotta
setblock 146 137 324 minecraft:dark_prismarine
fill 146 137 340 147 138 340 minecraft:dark_prismarine
fill 146 137 349 146 181 349 minecraft:magenta_terracotta
setblock 147 137 323 minecraft:dark_prismarine
fill 147 137 324 147 140 324 minecraft:blue_terracotta
setblock 147 137 363 minecraft:dark_prismarine
fill 148 137 323 148 140 323 minecraft:blue_terracotta
setblock 148 137 363 minecraft:blue_terracotta
setblock 150 137 324 minecraft:blue_terracotta
setblock 151 137 325 minecraft:light[level=12]
setblock 151 137 332 minecraft:light[level=12]
fill 151 137 335 151 162 335 minecraft:magenta_terracotta
setblock 151 137 346 minecraft:light[level=12]
setblock 151 137 353 minecraft:light[level=12]
setblock 151 137 360 minecraft:light[level=12]
setblock 152 137 323 minecraft:dark_prismarine
fill 153 137 323 153 140 323 minecraft:blue_terracotta
setblock 153 137 363 minecraft:purple_concrete
fill 154 137 324 155 137 324 minecraft:blue_terracotta
setblock 156 137 324 minecraft:dark_prismarine
setblock 157 137 323 minecraft:dark_prismarine
fill 157 137 324 157 139 325 minecraft:blue_terracotta
fill 157 137 357 158 159 357 minecraft:magenta_terracotta
fill 158 137 323 158 140 323 minecraft:blue_terracotta
fill 158 137 325 159 137 325 minecraft:blue_terracotta
setblock 158 137 332 minecraft:light[level=12]
setblock 158 137 339 minecraft:light[level=12]
setblock 158 137 346 minecraft:light[level=12]
setblock 158 137 353 minecraft:light[level=12]
setblock 158 137 360 minecraft:light[level=12]
fill 158 137 363 158 140 363 minecraft:blue_terracotta
setblock 160 137 325 minecraft:dark_prismarine
fill 160 137 326 161 139 326 minecraft:blue_terracotta
setblock 161 137 324 minecraft:dark_prismarine
fill 161 137 325 161 140 325 minecraft:blue_terracotta
fill 161 137 362 161 137 363 minecraft:blue_terracotta
setblock 162 137 323 minecraft:dark_prismarine
fill 162 137 324 162 140 324 minecraft:blue_terracotta
setblock 162 137 363 minecraft:dark_prismarine
fill 163 137 323 163 140 323 minecraft:blue_terracotta
setblock 163 137 326 minecraft:blue_terracotta
setblock 163 137 362 minecraft:dark_prismarine
fill 163 137 363 163 140 363 minecraft:blue_terracotta
setblock 164 137 326 minecraft:dark_prismarine
fill 164 137 362 167 137 362 minecraft:blue_terracotta
setblock 165 137 325 minecraft:dark_prismarine
fill 165 137 326 165 140 326 minecraft:blue_terracotta
setblock 165 137 332 minecraft:light[level=12]
setblock 165 137 339 minecraft:light[level=12]
setblock 165 137 346 minecraft:light[level=12]
setblock 165 137 353 minecraft:light[level=12]
setblock 165 137 360 minecraft:light[level=12]
setblock 166 137 324 minecraft:dark_prismarine
fill 166 137 325 166 140 325 minecraft:blue_terracotta
fill 166 137 329 166 161 329 minecraft:magenta_terracotta
setblock 167 137 323 minecraft:dark_prismarine
fill 167 137 324 167 140 324 minecraft:blue_terracotta
fill 167 137 326 167 138 326 minecraft:blue_terracotta
setblock 167 137 363 minecraft:dark_prismarine
fill 168 137 323 168 140 323 minecraft:blue_terracotta
fill 168 137 329 168 160 329 minecraft:magenta_terracotta
setblock 168 137 362 minecraft:dark_prismarine
fill 168 137 363 168 140 363 minecraft:blue_terracotta
fill 169 137 362 169 139 362 minecraft:blue_terracotta
setblock 171 137 324 minecraft:dark_prismarine
setblock 172 137 323 minecraft:dark_prismarine
fill 172 137 324 173 139 324 minecraft:blue_terracotta
setblock 172 137 325 minecraft:light[level=12]
setblock 172 137 332 minecraft:light[level=12]
setblock 172 137 339 minecraft:light[level=12]
setblock 172 137 346 minecraft:light[level=12]
setblock 172 137 353 minecraft:light[level=12]
setblock 172 137 360 minecraft:light[level=12]
setblock 172 137 363 minecraft:dark_prismarine
fill 172 137 364 173 220 364 minecraft:blue_terracotta
fill 173 137 323 173 140 323 minecraft:blue_terracotta
fill 173 137 351 173 159 351 minecraft:magenta_terracotta
fill 173 137 363 173 140 363 minecraft:blue_terracotta
setblock 174 137 364 minecraft:cyan_concrete
fill 175 137 364 175 217 364 minecraft:blue_terracotta
fill 177 137 322 177 218 322 minecraft:blue_terracotta
setblock 177 137 323 minecraft:dark_prismarine
setblock 177 137 362 minecraft:blue_terracotta
setblock 177 137 363 minecraft:dark_prismarine
fill 178 137 323 178 139 324 minecraft:blue_terracotta
fill 178 137 337 178 185 337 minecraft:magenta_terracotta
setblock 178 137 362 minecraft:dark_prismarine
fill 178 137 363 178 140 363 minecraft:blue_terracotta
setblock 179 137 325 minecraft:light[level=12]
setblock 179 137 332 minecraft:light[level=12]
setblock 179 137 339 minecraft:light[level=12]
setblock 179 137 346 minecraft:light[level=12]
setblock 179 137 353 minecraft:light[level=12]
setblock 179 137 360 minecraft:light[level=12]
fill 179 137 362 179 140 362 minecraft:blue_terracotta
setblock 180 137 324 minecraft:blue_terracotta
setblock 180 137 344 minecraft:blue_terracotta
setblock 180 137 345 minecraft:dark_prismarine
fill 180 137 346 180 137 349 minecraft:blue_terracotta
setblock 180 137 350 minecraft:dark_prismarine
fill 180 137 351 181 139 351 minecraft:blue_terracotta
setblock 181 137 324 minecraft:dark_prismarine
fill 181 137 325 181 138 327 minecraft:blue_terracotta
fill 181 137 341 181 137 343 minecraft:blue_terracotta
setblock 181 137 344 minecraft:dark_prismarine
fill 181 137 345 181 140 345 minecraft:blue_terracotta
setblock 181 137 348 minecraft:blue_terracotta
setblock 181 137 349 minecraft:dark_prismarine
fill 181 137 350 181 140 350 minecraft:blue_terracotta
fill 181 137 352 181 137 353 minecraft:blue_terracotta
setblock 181 137 354 minecraft:dark_prismarine
fill 181 137 355 181 138 357 minecraft:blue_terracotta
setblock 181 137 359 minecraft:dark_prismarine
fill 181 137 360 181 140 360 minecraft:blue_terracotta
setblock 182 137 323 minecraft:dark_prismarine
fill 182 137 324 182 140 324 minecraft:blue_terracotta
setblock 182 137 328 minecraft:dark_prismarine
fill 182 137 329 182 138 331 minecraft:blue_terracotta
setblock 182 137 338 minecraft:dark_prismarine
fill 182 137 339 182 140 339 minecraft:blue_terracotta
setblock 182 137 343 minecraft:dark_prismarine
fill 182 137 344 182 140 344 minecraft:blue_terracotta
setblock 182 137 348 minecraft:dark_prismarine
fill 182 137 349 182 140 349 minecraft:blue_terracotta
setblock 182 137 353 minecraft:dark_prismarine
fill 182 137 354 182 140 354 minecraft:blue_terracotta
setblock 182 137 358 minecraft:dark_prismarine
fill 182 137 359 182 140 359 minecraft:blue_terracotta
setblock 182 137 363 minecraft:dark_prismarine
fill 183 137 358 183 220 358 minecraft:blue_terracotta
setblock 141 138 360 minecraft:light_blue_wool
fill 141 138 361 141 218 363 minecraft:blue_terracotta
fill 142 138 323 142 138 326 minecraft:blue_terracotta
setblock 142 138 327 minecraft:dark_prismarine
fill 142 138 328 142 138 331 minecraft:blue_terracotta
setblock 142 138 332 minecraft:dark_prismarine
fill 142 138 333 143 140 333 minecraft:blue_terracotta
setblock 142 138 337 minecraft:dark_prismarine
fill 142 138 338 142 141 338 minecraft:blue_terracotta
setblock 142 138 342 minecraft:dark_prismarine
fill 142 138 343 142 141 343 minecraft:blue_terracotta
setblock 142 138 347 minecraft:dark_prismarine
fill 142 138 348 142 141 348 minecraft:blue_terracotta
setblock 142 138 352 minecraft:dark_prismarine
setblock 142 138 353 minecraft:blue_terracotta
setblock 142 138 357 minecraft:dark_prismarine
fill 142 138 358 142 141 358 minecraft:blue_terracotta
setblock 142 138 362 minecraft:dark_prismarine
fill 142 138 363 142 141 363 minecraft:blue_terracotta
setblock 143 138 326 minecraft:dark_prismarine
fill 143 138 327 143 138 330 minecraft:blue_terracotta
setblock 143 138 331 minecraft:dark_prismarine
fill 143 138 332 143 141 332 minecraft:blue_terracotta
fill 143 138 334 143 138 335 minecraft:blue_terracotta
setblock 143 138 336 minecraft:dark_prismarine
fill 143 138 337 143 141 337 minecraft:blue_terracotta
setblock 143 138 341 minecraft:dark_prismarine
fill 143 138 342 143 141 342 minecraft:blue_terracotta
setblock 143 138 346 minecraft:dark_prismarine
fill 143 138 347 143 141 347 minecraft:blue_terracotta
setblock 143 138 350 minecraft:blue_terracotta
setblock 143 138 351 minecraft:dark_prismarine
fill 143 138 352 143 141 352 minecraft:blue_terracotta
fill 143 138 358 146 138 358 minecraft:dark_prismarine
setblock 144 138 325 minecraft:dark_prismarine
fill 144 138 326 144 138 329 minecraft:blue_terracotta
setblock 144 138 340 minecraft:dark_prismarine
fill 144 138 341 144 141 341 minecraft:blue_terracotta
setblock 144 138 345 minecraft:dark_prismarine
fill 144 138 346 144 141 346 minecraft:blue_terracotta
setblock 144 138 350 minecraft:dark_prismarine
fill 144 138 351 144 141 351 minecraft:blue_terracotta
setblock 145 138 324 minecraft:dark_prismarine
fill 145 138 325 146 140 325 minecraft:blue_terracotta
setblock 145 138 344 minecraft:dark_prismarine
fill 145 138 345 145 140 345 minecraft:blue_terracotta
setblock 146 138 323 minecraft:dark_prismarine
fill 146 138 324 146 141 324 minecraft:blue_terracotta
setblock 146 138 363 minecraft:dark_prismarine
fill 147 138 323 147 141 323 minecraft:blue_terracotta
setblock 147 138 363 minecraft:blue_terracotta
fill 149 138 322 150 217 322 minecraft:blue_terracotta
setblock 150 138 324 minecraft:dark_prismarine
setblock 151 138 322 minecraft:cyan_concrete
setblock 151 138 323 minecraft:dark_prismarine
fill 151 138 324 154 138 324 minecraft:blue_terracotta
fill 152 138 322 152 141 323 minecraft:blue_terracotta
setblock 155 138 324 minecraft:dark_prismarine
setblock 156 138 323 minecraft:dark_prismarine
fill 156 138 324 156 140 325 minecraft:blue_terracotta
fill 157 138 323 157 141 323 minecraft:blue_terracotta
fill 157 138 363 157 141 363 minecraft:blue_terracotta
setblock 158 138 325 minecraft:blue_terracotta
setblock 159 138 325 minecraft:dark_prismarine
fill 159 138 326 159 141 326 minecraft:blue_terracotta
setblock 160 138 324 minecraft:dark_prismarine
fill 160 138 325 160 141 325 minecraft:blue_terracotta
fill 160 138 362 161 138 362 minecraft:blue_terracotta
setblock 161 138 323 minecraft:dark_prismarine
fill 161 138 324 161 141 324 minecraft:blue_terracotta
setblock 161 138 363 minecraft:dark_prismarine
fill 162 138 323 162 141 323 minecraft:blue_terracotta
setblock 162 138 362 minecraft:dark_prismarine
fill 162 138 363 162 141 363 minecraft:blue_terracotta
setblock 163 138 326 minecraft:dark_prismarine
fill 163 138 362 166 138 362 minecraft:blue_terracotta
setblock 164 138 325 minecraft:dark_prismarine
fill 164 138 326 164 141 326 minecraft:blue_terracotta
setblock 165 138 324 minecraft:dark_prismarine
fill 165 138 325 165 141 325 minecraft:blue_terracotta
setblock 166 138 323 minecraft:dark_prismarine
fill 166 138 324 166 141 324 minecraft:blue_terracotta
setblock 166 138 363 minecraft:dark_prismarine
fill 167 138 323 167 141 323 minecraft:blue_terracotta
setblock 167 138 362 minecraft:dark_prismarine
fill 167 138 363 167 141 363 minecraft:blue_terracotta
fill 168 138 362 168 140 362 minecraft:blue_terracotta
setblock 169 138 325 minecraft:dark_prismarine
setblock 170 138 324 minecraft:dark_prismarine
setblock 171 138 323 minecraft:dark_prismarine
fill 171 138 324 171 141 324 minecraft:blue_terracotta
setblock 171 138 363 minecraft:dark_prismarine
fill 172 138 323 172 141 323 minecraft:blue_terracotta
fill 172 138 363 172 141 363 minecraft:blue_terracotta
setblock 174 138 324 minecraft:blue_terracotta
fill 174 138 364 174 168 364 minecraft:blue_terracotta
setblock 175 138 324 minecraft:dark_prismarine
fill 176 138 322 176 217 322 minecraft:blue_terracotta
setblock 176 138 323 minecraft:dark_prismarine
fill 176 138 324 177 140 324 minecraft:blue_terracotta
setblock 176 138 363 minecraft:dark_prismarine
fill 177 138 323 177 141 323 minecraft:blue_terracotta
setblock 177 138 362 minecraft:dark_prismarine
fill 177 138 363 177 141 363 minecraft:blue_terracotta
fill 178 138 362 178 141 362 minecraft:blue_terracotta
setblock 180 138 324 minecraft:dark_prismarine
setblock 180 138 344 minecraft:dark_prismarine
fill 180 138 345 180 138 348 minecraft:blue_terracotta
setblock 180 138 349 minecraft:dark_prismarine
fill 180 138 350 180 141 350 minecraft:blue_terracotta
fill 180 138 352 180 138 353 minecraft:blue_terracotta
setblock 181 138 323 minecraft:dark_prismarine
fill 181 138 324 181 141 324 minecraft:blue_terracotta
setblock 181 138 328 minecraft:dark_prismarine
fill 181 138 329 181 141 329 minecraft:blue_terracotta
fill 181 138 340 181 138 342 minecraft:blue_terracotta
setblock 181 138 343 minecraft:dark_prismarine
fill 181 138 344 181 141 344 minecraft:blue_terracotta
setblock 181 138 348 minecraft:dark_prismarine
fill 181 138 349 181 141 349 minecraft:blue_terracotta
setblock 181 138 352 minecraft:blue_terracotta
setblock 181 138 353 minecraft:dark_prismarine
fill 181 138 354 181 141 354 minecraft:blue_terracotta
setblock 181 138 358 minecraft:dark_prismarine
fill 181 138 359 181 141 359 minecraft:blue_terracotta
setblock 181 138 363 minecraft:dark_prismarine
fill 182 138 323 182 141 323 minecraft:blue_terracotta
setblock 182 138 326 minecraft:blue_terracotta
setblock 182 138 327 minecraft:dark_prismarine
fill 182 138 328 182 141 328 minecraft:blue_terracotta
setblock 182 138 332 minecraft:dark_prismarine
fill 182 138 333 182 138 336 minecraft:blue_terracotta
setblock 182 138 337 minecraft:dark_prismarine
fill 182 138 338 182 141 338 minecraft:blue_terracotta
setblock 182 138 342 minecraft:dark_prismarine
fill 182 138 343 182 141 343 minecraft:blue_terracotta
setblock 182 138 347 minecraft:dark_prismarine
fill 182 138 348 182 141 348 minecraft:blue_terracotta
setblock 182 138 352 minecraft:dark_prismarine
fill 182 138 353 182 141 353 minecraft:blue_terracotta
setblock 182 138 357 minecraft:dark_prismarine
fill 182 138 358 182 141 358 minecraft:blue_terracotta
setblock 182 138 362 minecraft:dark_prismarine
fill 182 138 363 182 141 363 minecraft:blue_terracotta
fill 183 138 357 183 220 357 minecraft:blue_terracotta
fill 141 139 360 141 221 360 minecraft:blue_terracotta
fill 142 139 323 142 139 325 minecraft:blue_terracotta
setblock 142 139 326 minecraft:dark_prismarine
fill 142 139 327 142 139 330 minecraft:blue_terracotta
setblock 142 139 331 minecraft:dark_prismarine
fill 142 139 332 142 142 332 minecraft:blue_terracotta
setblock 142 139 336 minecraft:dark_prismarine
fill 142 139 337 142 142 337 minecraft:blue_terracotta
setblock 142 139 341 minecraft:dark_prismarine
fill 142 139 342 142 142 342 minecraft:blue_terracotta
setblock 142 139 346 minecraft:dark_prismarine
fill 142 139 347 142 142 347 minecraft:blue_terracotta
setblock 142 139 351 minecraft:dark_prismarine
fill 142 139 352 142 142 352 minecraft:blue_terracotta
setblock 142 139 353 minecraft:sea_lantern
setblock 142 139 355 minecraft:sea_lantern
setblock 142 139 356 minecraft:dark_prismarine
setblock 142 139 357 minecraft:sea_lantern
setblock 142 139 359 minecraft:sea_lantern
setblock 142 139 361 minecraft:sea_lantern
fill 142 139 362 142 142 362 minecraft:blue_terracotta
setblock 143 139 325 minecraft:dark_prismarine
fill 143 139 326 143 139 329 minecraft:blue_terracotta
setblock 143 139 330 minecraft:dark_prismarine
fill 143 139 331 144 141 331 minecraft:blue_terracotta
setblock 143 139 334 minecraft:blue_terracotta
setblock 143 139 335 minecraft:dark_prismarine
fill 143 139 336 143 142 336 minecraft:blue_terracotta
setblock 143 139 340 minecraft:dark_prismarine
fill 143 139 341 143 142 341 minecraft:blue_terracotta
setblock 143 139 345 minecraft:dark_prismarine
fill 143 139 346 143 142 346 minecraft:blue_terracotta
setblock 143 139 350 minecraft:dark_prismarine
fill 143 139 351 143 142 351 minecraft:blue_terracotta
setblock 143 139 354 minecraft:sea_lantern
setblock 143 139 355 minecraft:dark_prismarine
setblock 143 139 356 minecraft:sea_lantern
fill 143 139 357 143 162 357 minecraft:dark_prismarine
setblock 143 139 358 minecraft:sea_lantern
fill 143 139 359 143 162 359 minecraft:dark_prismarine
setblock 143 139 360 minecraft:sea_lantern
fill 143 139 361 143 162 361 minecraft:dark_prismarine
setblock 144 139 324 minecraft:dark_prismarine
fill 144 139 325 144 139 328 minecraft:blue_terracotta
setblock 144 139 329 minecraft:dark_prismarine
fill 144 139 330 144 142 330 minecraft:blue_terracotta
setblock 144 139 339 minecraft:dark_prismarine
fill 144 139 340 144 141 340 minecraft:blue_terracotta
setblock 144 139 344 minecraft:dark_prismarine
fill 144 139 345 144 142 345 minecraft:blue_terracotta
setblock 144 139 349 minecraft:dark_prismarine
fill 144 139 350 145 140 350 minecraft:blue_terracotta
setblock 144 139 353 minecraft:sea_lantern
fill 144 139 354 144 162 354 minecraft:dark_prismarine
setblock 144 139 355 minecraft:sea_lantern
fill 144 139 356 144 162 356 minecraft:dark_prismarine
setblock 144 139 357 minecraft:sea_lantern
fill 144 139 358 144 162 358 minecraft:dark_prismarine
setblock 144 139 359 minecraft:sea_lantern
fill 144 139 360 144 162 360 minecraft:dark_prismarine
setblock 144 139 361 minecraft:sea_lantern
setblock 145 139 323 minecraft:dark_prismarine
fill 145 139 324 145 142 324 minecraft:blue_terracotta
setblock 145 139 343 minecraft:dark_prismarine
fill 145 139 344 145 140 344 minecraft:blue_terracotta
fill 145 139 353 145 162 353 minecraft:dark_prismarine
setblock 145 139 354 minecraft:sea_lantern
fill 145 139 355 145 162 355 minecraft:dark_prismarine
setblock 145 139 356 minecraft:sea_lantern
fill 145 139 357 145 162 357 minecraft:dark_prismarine
setblock 145 139 358 minecraft:sea_lantern
fill 145 139 359 145 162 359 minecraft:dark_prismarine
setblock 145 139 360 minecraft:sea_lantern
fill 145 139 361 145 162 361 minecraft:dark_prismarine
setblock 145 139 363 minecraft:dark_prismarine
fill 146 139 323 146 142 323 minecraft:blue_terracotta
setblock 146 139 353 minecraft:sea_lantern
fill 146 139 354 146 162 354 minecraft:dark_prismarine
setblock 146 139 355 minecraft:sea_lantern
fill 146 139 356 146 162 356 minecraft:dark_prismarine
setblock 146 139 357 minecraft:sea_lantern
fill 146 139 358 146 162 358 minecraft:dark_prismarine
setblock 146 139 359 minecraft:sea_lantern
fill 146 139 360 146 162 360 minecraft:dark_prismarine
setblock 146 139 361 minecraft:sea_lantern
setblock 146 139 363 minecraft:blue_terracotta
setblock 148 139 324 minecraft:blue_terracotta
setblock 149 139 324 minecraft:dark_prismarine
setblock 150 139 323 minecraft:dark_prismarine
fill 150 139 324 153 139 324 minecraft:blue_terracotta
fill 151 139 322 151 142 323 minecraft:blue_terracotta
setblock 154 139 324 minecraft:dark_prismarine
setblock 155 139 323 minecraft:dark_prismarine
fill 155 139 324 155 141 325 minecraft:blue_terracotta
fill 156 139 323 156 142 323 minecraft:blue_terracotta
setblock 158 139 325 minecraft:dark_prismarine
fill 158 139 326 158 142 326 minecraft:blue_terracotta
setblock 159 139 324 minecraft:dark_prismarine
fill 159 139 325 159 142 325 minecraft:blue_terracotta
setblock 160 139 323 minecraft:dark_prismarine
fill 160 139 324 160 142 324 minecraft:blue_terracotta
setblock 160 139 362 minecraft:blue_terracotta
setblock 160 139 363 minecraft:dark_prismarine
fill 161 139 323 161 142 323 minecraft:blue_terracotta
setblock 161 139 327 minecraft:dark_prismarine
setblock 161 139 362 minecraft:dark_prismarine
fill 161 139 363 161 142 363 minecraft:blue_terracotta
setblock 162 139 325 minecraft:blue_terracotta
setblock 162 139 326 minecraft:dark_prismarine
fill 162 139 327 163 141 327 minecraft:blue_terracotta
fill 162 139 362 165 139 362 minecraft:blue_terracotta
setblock 163 139 325 minecraft:dark_prismarine
fill 163 139 326 163 142 326 minecraft:blue_terracotta
setblock 164 139 324 minecraft:dark_prismarine
fill 164 139 325 164 142 325 minecraft:blue_terracotta
fill 165 139 322 165 220 322 minecraft:blue_terracotta
setblock 165 139 323 minecraft:dark_prismarine
fill 165 139 324 165 142 324 minecraft:blue_terracotta
fill 165 139 329 165 142 329 minecraft:magenta_terracotta
setblock 165 139 363 minecraft:dark_prismarine
fill 166 139 323 166 142 323 minecraft:blue_terracotta
setblock 166 139 362 minecraft:dark_prismarine
fill 166 139 363 166 142 363 minecraft:blue_terracotta
setblock 167 139 326 minecraft:dark_prismarine
fill 167 139 362 167 141 362 minecraft:blue_terracotta
setblock 168 139 325 minecraft:dark_prismarine
setblock 169 139 324 minecraft:dark_prismarine
fill 169 139 325 169 140 325 minecraft:blue_terracotta
setblock 170 139 323 minecraft:dark_prismarine
fill 170 139 324 170 141 324 minecraft:blue_terracotta
setblock 170 139 363 minecraft:dark_prismarine
fill 171 139 323 171 142 323 minecraft:blue_terracotta
fill 171 139 363 171 142 363 minecraft:blue_terracotta
setblock 174 139 324 minecraft:dark_prismarine
setblock 175 139 323 minecraft:dark_prismarine
fill 175 139 324 175 140 324 minecraft:blue_terracotta
setblock 175 139 363 minecraft:dark_prismarine
fill 176 139 323 176 142 323 minecraft:blue_terracotta
fill 176 139 363 176 142 363 minecraft:blue_terracotta
fill 177 139 362 177 142 362 minecraft:blue_terracotta
setblock 179 139 323 minecraft:blue_terracotta
setblock 179 139 324 minecraft:dark_prismarine
fill 179 139 347 179 139 348 minecraft:blue_terracotta
setblock 179 139 349 minecraft:dark_prismarine
fill 179 139 350 179 142 350 minecraft:blue_terracotta
setblock 180 139 323 minecraft:dark_prismarine
fill 180 139 324 180 141 325 minecraft:blue_terracotta
setblock 180 139 343 minecraft:dark_prismarine
fill 180 139 344 180 139 347 minecraft:blue_terracotta
setblock 180 139 348 minecraft:dark_prismarine
fill 180 139 349 180 142 349 minecraft:blue_terracotta
setblock 180 139 352 minecraft:blue_terracotta
setblock 180 139 353 minecraft:dark_prismarine
fill 180 139 354 180 141 355 minecraft:blue_terracotta
setblock 180 139 363 minecraft:dark_prismarine
fill 181 139 323 181 142 323 minecraft:blue_terracotta
fill 181 139 325 181 139 326 minecraft:blue_terracotta
setblock 181 139 327 minecraft:dark_prismarine
fill 181 139 328 181 142 328 minecraft:blue_terracotta
fill 181 139 330 182 139 330 minecraft:blue_terracotta
fill 181 139 340 181 139 341 minecraft:blue_terracotta
setblock 181 139 342 minecraft:dark_prismarine
fill 181 139 343 181 142 343 minecraft:blue_terracotta
setblock 181 139 347 minecraft:dark_prismarine
fill 181 139 348 181 142 348 minecraft:blue_terracotta
setblock 181 139 352 minecraft:dark_prismarine
fill 181 139 353 181 142 353 minecraft:blue_terracotta
fill 181 139 355 181 139 356 minecraft:blue_terracotta
setblock 181 139 357 minecraft:dark_prismarine
fill 181 139 358 181 142 358 minecraft:blue_terracotta
setblock 181 139 362 minecraft:dark_prismarine
fill 181 139 363 181 142 363 minecraft:blue_terracotta
setblock 182 139 326 minecraft:dark_prismarine
fill 182 139 327 182 142 327 minecraft:blue_terracotta
fill 182 139 329 182 140 329 minecraft:blue_terracotta
setblock 182 139 331 minecraft:dark_prismarine
fill 182 139 332 182 139 335 minecraft:blue_terracotta
setblock 182 139 336 minecraft:dark_prismarine
fill 182 139 337 182 142 337 minecraft:blue_terracotta
setblock 182 139 341 minecraft:dark_prismarine
fill 182 139 342 182 142 342 minecraft:blue_terracotta
setblock 182 139 346 minecraft:dark_prismarine
fill 182 139 347 182 142 347 minecraft:blue_terracotta
setblock 182 139 351 minecraft:dark_prismarine
fill 182 139 352 182 142 352 minecraft:blue_terracotta
setblock 182 139 356 minecraft:dark_prismarine
fill 182 139 357 182 142 357 minecraft:blue_terracotta
setblock 182 139 361 minecraft:dark_prismarine
fill 182 139 362 182 142 362 minecraft:blue_terracotta
fill 142 140 323 142 140 324 minecraft:blue_terracotta
setblock 142 140 325 minecraft:dark_prismarine
fill 142 140 326 142 140 329 minecraft:blue_terracotta
setblock 142 140 330 minecraft:dark_prismarine
fill 142 140 331 142 143 331 minecraft:blue_terracotta
setblock 142 140 335 minecraft:dark_prismarine
fill 142 140 336 142 143 336 minecraft:blue_terracotta
setblock 142 140 340 minecraft:dark_prismarine
fill 142 140 341 142 143 341 minecraft:blue_terracotta
setblock 142 140 345 minecraft:dark_prismarine
fill 142 140 346 142 143 346 minecraft:blue_terracotta
setblock 142 140 350 minecraft:dark_prismarine
fill 142 140 351 142 143 351 minecraft:blue_terracotta
fill 142 140 353 142 141 353 minecraft:blue_terracotta
setblock 142 140 355 minecraft:dark_prismarine
fill 142 140 356 142 141 357 minecraft:blue_terracotta
setblock 142 140 359 minecraft:blue_terracotta
fill 142 140 360 143 140 360 minecraft:dark_prismarine
fill 142 140 361 142 141 361 minecraft:blue_terracotta
setblock 143 140 324 minecraft:dark_prismarine
fill 143 140 325 143 140 328 minecraft:blue_terracotta
setblock 143 140 329 minecraft:dark_prismarine
fill 143 140 330 143 143 330 minecraft:blue_terracotta
setblock 143 140 334 minecraft:dark_prismarine
fill 143 140 335 143 143 335 minecraft:blue_terracotta
setblock 143 140 339 minecraft:dark_prismarine
fill 143 140 340 143 143 340 minecraft:blue_terracotta
setblock 143 140 344 minecraft:dark_prismarine
fill 143 140 345 143 143 345 minecraft:blue_terracotta
setblock 143 140 349 minecraft:dark_prismarine
fill 143 140 350 143 143 350 minecraft:blue_terracotta
setblock 143 140 354 minecraft:dark_prismarine
fill 143 140 355 143 141 356 minecraft:blue_terracotta
fill 143 140 358 143 141 358 minecraft:dark_prismarine
setblock 144 140 323 minecraft:dark_prismarine
fill 144 140 324 144 140 327 minecraft:blue_terracotta
setblock 144 140 328 minecraft:dark_prismarine
fill 144 140 329 144 143 329 minecraft:blue_terracotta
setblock 144 140 332 minecraft:blue_terracotta
setblock 144 140 333 minecraft:dark_prismarine
setblock 144 140 339 minecraft:blue_terracotta
setblock 144 140 343 minecraft:dark_prismarine
fill 144 140 344 144 142 344 minecraft:blue_terracotta
setblock 144 140 348 minecraft:dark_prismarine
fill 144 140 349 144 143 349 minecraft:blue_terracotta
setblock 144 140 353 minecraft:dark_prismarine
fill 144 140 355 144 141 355 minecraft:dark_prismarine
fill 144 140 357 144 141 357 minecraft:dark_prismarine
fill 144 140 359 144 141 359 minecraft:dark_prismarine
fill 144 140 361 144 141 361 minecraft:dark_prismarine
setblock 144 140 363 minecraft:dark_prismarine
fill 145 140 323 145 143 323 minecraft:blue_terracotta
setblock 145 140 347 minecraft:dark_prismarine
fill 145 140 354 145 141 354 minecraft:dark_prismarine
fill 145 140 356 145 141 356 minecraft:dark_prismarine
fill 145 140 358 145 141 358 minecraft:dark_prismarine
fill 145 140 360 145 141 360 minecraft:dark_prismarine
setblock 145 140 363 minecraft:blue_terracotta
fill 146 140 353 146 141 353 minecraft:dark_prismarine
fill 146 140 355 146 141 355 minecraft:dark_prismarine
fill 146 140 357 146 141 357 minecraft:dark_prismarine
fill 146 140 359 146 141 359 minecraft:dark_prismarine
fill 146 140 361 146 141 361 minecraft:dark_prismarine
setblock 148 140 324 minecraft:dark_prismarine
setblock 149 140 323 minecraft:dark_prismarine
fill 149 140 324 152 140 324 minecraft:blue_terracotta
fill 150 140 323 150 142 323 minecraft:blue_terracotta
setblock 152 140 363 minecraft:purple_concrete
setblock 153 140 324 minecraft:dark_prismarine
setblock 154 140 323 minecraft:dark_prismarine
fill 154 140 324 154 142 325 minecraft:blue_terracotta
fill 155 140 323 155 143 323 minecraft:blue_terracotta
fill 155 140 335 156 141 336 minecraft:dark_prismarine
fill 156 140 363 156 142 363 minecraft:blue_terracotta
setblock 157 140 324 minecraft:blue_terracotta
setblock 157 140 325 minecraft:dark_prismarine
fill 157 140 326 157 143 326 minecraft:blue_terracotta
setblock 158 140 324 minecraft:dark_prismarine
fill 158 140 325 158 143 325 minecraft:blue_terracotta
setblock 159 140 323 minecraft:dark_prismarine
fill 159 140 324 159 143 324 minecraft:blue_terracotta
setblock 159 140 363 minecraft:dark_prismarine
fill 160 140 323 160 143 323 minecraft:blue_terracotta
setblock 160 140 326 minecraft:blue_terracotta
setblock 160 140 327 minecraft:dark_prismarine
setblock 160 140 362 minecraft:dark_prismarine
fill 160 140 363 160 143 363 minecraft:blue_terracotta
setblock 161 140 326 minecraft:dark_prismarine
fill 161 140 327 161 142 327 minecraft:blue_terracotta
fill 161 140 362 164 140 362 minecraft:blue_terracotta
setblock 162 140 325 minecraft:dark_prismarine
fill 162 140 326 162 143 326 minecraft:blue_terracotta
setblock 163 140 324 minecraft:dark_prismarine
fill 163 140 325 163 143 325 minecraft:blue_terracotta
setblock 164 140 323 minecraft:dark_prismarine
fill 164 140 324 164 143 324 minecraft:blue_terracotta
setblock 164 140 363 minecraft:dark_prismarine
fill 165 140 323 165 143 323 minecraft:blue_terracotta
setblock 165 140 362 minecraft:dark_prismarine
fill 165 140 363 165 143 363 minecraft:blue_terracotta
setblock 166 140 326 minecraft:dark_prismarine
fill 166 140 362 166 141 362 minecraft:blue_terracotta
setblock 167 140 325 minecraft:dark_prismarine
setblock 168 140 324 minecraft:dark_prismarine
fill 168 140 325 168 141 325 minecraft:blue_terracotta
setblock 169 140 323 minecraft:dark_prismarine
fill 169 140 324 169 142 324 minecraft:blue_terracotta
setblock 169 140 363 minecraft:dark_prismarine
fill 170 140 323 170 143 323 minecraft:blue_terracotta
fill 170 140 363 170 142 363 minecraft:blue_terracotta
setblock 172 140 324 minecraft:blue_terracotta
setblock 173 140 324 minecraft:dark_prismarine
setblock 174 140 323 minecraft:dark_prismarine
setblock 174 140 324 minecraft:blue_terracotta
setblock 174 140 363 minecraft:dark_prismarine
fill 175 140 323 175 143 323 minecraft:blue_terracotta
fill 175 140 325 176 141 331 minecraft:dark_prismarine
fill 175 140 363 175 143 363 minecraft:blue_terracotta
fill 176 140 332 176 141 342 minecraft:dark_prismarine
setblock 176 140 362 minecraft:blue_terracotta
fill 177 140 335 177 141 335 minecraft:dark_prismarine
fill 177 140 339 177 141 354 minecraft:dark_prismarine
setblock 178 140 323 minecraft:blue_terracotta
setblock 178 140 324 minecraft:dark_prismarine
fill 178 140 346 178 141 361 minecraft:dark_prismarine
setblock 179 140 323 minecraft:dark_prismarine
fill 179 140 324 179 143 324 minecraft:blue_terracotta
fill 179 140 346 179 140 347 minecraft:blue_terracotta
setblock 179 140 348 minecraft:dark_prismarine
fill 179 140 349 179 143 349 minecraft:blue_terracotta
fill 179 140 351 179 140 352 minecraft:blue_terracotta
fill 179 140 357 179 141 361 minecraft:dark_prismarine
setblock 179 140 363 minecraft:dark_prismarine
fill 180 140 323 180 143 323 minecraft:blue_terracotta
setblock 180 140 326 minecraft:blue_terracotta
setblock 180 140 327 minecraft:dark_prismarine
fill 180 140 343 180 140 346 minecraft:blue_terracotta
setblock 180 140 347 minecraft:dark_prismarine
fill 180 140 348 180 143 348 minecraft:blue_terracotta
setblock 180 140 351 minecraft:blue_terracotta
setblock 180 140 352 minecraft:dark_prismarine
fill 180 140 353 180 143 353 minecraft:blue_terracotta
setblock 180 140 356 minecraft:blue_terracotta
setblock 180 140 357 minecraft:dark_prismarine
setblock 180 140 362 minecraft:dark_prismarine
fill 180 140 363 180 143 363 minecraft:blue_terracotta
setblock 181 140 325 minecraft:blue_terracotta
setblock 181 140 326 minecraft:dark_prismarine
fill 181 140 327 181 143 327 minecraft:blue_terracotta
setblock 181 140 330 minecraft:blue_terracotta
setblock 181 140 331 minecraft:dark_prismarine
fill 181 140 332 182 142 332 minecraft:blue_terracotta
setblock 181 140 340 minecraft:blue_terracotta
setblock 181 140 341 minecraft:dark_prismarine
fill 181 140 342 181 143 342 minecraft:blue_terracotta
setblock 181 140 346 minecraft:dark_prismarine
fill 181 140 347 181 143 347 minecraft:blue_terracotta
setblock 181 140 351 minecraft:dark_prismarine
fill 181 140 352 181 143 352 minecraft:blue_terracotta
setblock 181 140 355 minecraft:blue_terracotta
setblock 181 140 356 minecraft:dark_prismarine
fill 181 140 357 181 143 357 minecraft:blue_terracotta
setblock 181 140 361 minecraft:dark_prismarine
fill 181 140 362 181 142 362 minecraft:blue_terracotta
setblock 182 140 325 minecraft:dark_prismarine
fill 182 140 326 182 143 326 minecraft:blue_terracotta
setblock 182 140 330 minecraft:dark_prismarine
fill 182 140 331 182 143 331 minecraft:blue_terracotta
fill 182 140 333 182 140 334 minecraft:blue_terracotta
setblock 182 140 335 minecraft:dark_prismarine
fill 182 140 336 182 143 336 minecraft:blue_terracotta
setblock 182 140 340 minecraft:dark_prismarine
fill 182 140 341 182 143 341 minecraft:blue_terracotta
setblock 182 140 345 minecraft:dark_prismarine
fill 182 140 346 182 143 346 minecraft:blue_terracotta
setblock 182 140 350 minecraft:dark_prismarine
fill 182 140 351 182 143 351 minecraft:blue_terracotta
setblock 182 140 355 minecraft:dark_prismarine
fill 182 140 356 182 143 356 minecraft:blue_terracotta
setblock 182 140 360 minecraft:dark_prismarine
fill 182 140 361 182 143 361 minecraft:blue_terracotta
setblock 142 141 323 minecraft:blue_terracotta
setblock 142 141 324 minecraft:dark_prismarine
fill 142 141 325 142 141 328 minecraft:blue_terracotta
setblock 142 141 329 minecraft:dark_prismarine
fill 142 141 330 142 144 330 minecraft:blue_terracotta
setblock 142 141 333 minecraft:blue_terracotta
setblock 142 141 334 minecraft:dark_prismarine
fill 142 141 335 142 144 335 minecraft:blue_terracotta
setblock 142 141 339 minecraft:dark_prismarine
fill 142 141 340 142 144 340 minecraft:blue_terracotta
setblock 142 141 344 minecraft:dark_prismarine
fill 142 141 345 142 144 345 minecraft:blue_terracotta
setblock 142 141 349 minecraft:dark_prismarine
fill 142 141 350 142 144 350 minecraft:blue_terracotta
setblock 142 141 354 minecraft:dark_prismarine
setblock 142 141 355 minecraft:blue_terracotta
setblock 142 141 359 minecraft:dark_prismarine
fill 142 141 360 142 142 360 minecraft:blue_terracotta
setblock 143 141 323 minecraft:dark_prismarine
fill 143 141 324 143 141 327 minecraft:blue_terracotta
setblock 143 141 328 minecraft:dark_prismarine
fill 143 141 329 143 144 329 minecraft:blue_terracotta
setblock 143 141 333 minecraft:dark_prismarine
fill 143 141 334 144 143 334 minecraft:blue_terracotta
setblock 143 141 338 minecraft:dark_prismarine
fill 143 141 339 143 144 339 minecraft:blue_terracotta
setblock 143 141 343 minecraft:dark_prismarine
fill 143 141 344 143 144 344 minecraft:blue_terracotta
setblock 143 141 348 minecraft:dark_prismarine
fill 143 141 349 143 144 349 minecraft:blue_terracotta
setblock 143 141 353 minecraft:dark_prismarine
setblock 143 141 354 minecraft:blue_terracotta
setblock 143 141 360 minecraft:dark_prismarine
setblock 143 141 363 minecraft:dark_prismarine
fill 144 141 323 144 141 326 minecraft:blue_terracotta
setblock 144 141 327 minecraft:dark_prismarine
fill 144 141 328 144 144 328 minecraft:blue_terracotta
setblock 144 141 332 minecraft:dark_prismarine
fill 144 141 333 144 144 333 minecraft:blue_terracotta
setblock 144 141 342 minecraft:dark_prismarine
fill 144 141 343 144 142 343 minecraft:blue_terracotta
setblock 144 141 347 minecraft:dark_prismarine
fill 144 141 348 144 143 348 minecraft:blue_terracotta
fill 144 141 350 144 142 350 minecraft:blue_terracotta
setblock 144 141 352 minecraft:dark_prismarine
setblock 144 141 353 minecraft:blue_terracotta
setblock 144 141 363 minecraft:blue_terracotta
setblock 145 141 325 minecraft:blue_terracotta
setblock 145 141 346 minecraft:dark_prismarine
setblock 145 141 347 minecraft:blue_terracotta
setblock 147 141 324 minecraft:dark_prismarine
setblock 148 141 323 minecraft:dark_prismarine
fill 148 141 324 149 141 324 minecraft:blue_terracotta
fill 149 141 323 149 142 323 minecraft:blue_terracotta
setblock 151 141 324 minecraft:blue_terracotta
setblock 152 141 324 minecraft:dark_prismarine
setblock 152 141 325 minecraft:light[level=13]
setblock 152 141 333 minecraft:light[level=13]
setblock 152 141 349 minecraft:light[level=13]
setblock 152 141 357 minecraft:light[level=13]
setblock 153 141 323 minecraft:dark_prismarine
fill 153 141 324 153 143 324 minecraft:blue_terracotta
fill 154 141 323 154 144 323 minecraft:blue_terracotta
setblock 156 141 324 minecraft:blue_terracotta
setblock 156 141 325 minecraft:dark_prismarine
fill 156 141 326 156 142 326 minecraft:blue_terracotta
fill 156 141 358 156 160 358 minecraft:magenta_terracotta
setblock 157 141 324 minecraft:dark_prismarine
fill 157 141 325 157 144 325 minecraft:blue_terracotta
setblock 158 141 323 minecraft:dark_prismarine
fill 158 141 324 158 144 324 minecraft:blue_terracotta
schedule function dropper:buildpart/75_8 1t
