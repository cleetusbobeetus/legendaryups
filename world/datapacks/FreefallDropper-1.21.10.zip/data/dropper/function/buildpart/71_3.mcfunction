setblock 545 164 275 minecraft:white_concrete
setblock 545 164 317 minecraft:white_concrete
fill 546 164 275 546 171 275 minecraft:brown_terracotta
fill 546 164 310 546 164 316 minecraft:white_concrete
fill 546 164 317 546 171 317 minecraft:brown_terracotta
fill 548 164 275 548 165 275 minecraft:brown_terracotta
fill 548 164 317 548 171 317 minecraft:brown_terracotta
setblock 549 164 275 minecraft:white_concrete
setblock 549 164 317 minecraft:white_concrete
fill 550 164 275 550 165 275 minecraft:brown_terracotta
fill 550 164 317 550 171 317 minecraft:brown_terracotta
fill 552 164 275 552 171 275 minecraft:brown_terracotta
fill 552 164 317 552 171 317 minecraft:brown_terracotta
setblock 553 164 275 minecraft:white_concrete
setblock 553 164 317 minecraft:white_concrete
fill 554 164 275 554 171 275 minecraft:brown_terracotta
fill 554 164 317 554 165 317 minecraft:brown_terracotta
fill 556 164 275 556 171 275 minecraft:brown_terracotta
fill 556 164 317 556 165 317 minecraft:brown_terracotta
setblock 557 164 275 minecraft:white_concrete
setblock 557 164 317 minecraft:white_concrete
fill 558 164 275 558 171 275 minecraft:brown_terracotta
fill 558 164 308 558 218 308 minecraft:white_concrete
fill 558 164 317 558 171 317 minecraft:brown_terracotta
setblock 559 164 275 minecraft:white_concrete
fill 559 164 276 559 165 276 minecraft:brown_terracotta
fill 559 164 278 559 165 278 minecraft:brown_terracotta
setblock 559 164 279 minecraft:white_concrete
fill 559 164 280 559 171 280 minecraft:brown_terracotta
fill 559 164 282 559 171 282 minecraft:brown_terracotta
setblock 559 164 283 minecraft:white_concrete
fill 559 164 284 559 171 284 minecraft:brown_terracotta
fill 559 164 286 559 171 286 minecraft:brown_terracotta
setblock 559 164 287 minecraft:white_concrete
fill 559 164 288 559 165 288 minecraft:brown_terracotta
fill 559 164 290 559 165 290 minecraft:brown_terracotta
setblock 559 164 291 minecraft:white_concrete
fill 559 164 292 559 171 292 minecraft:brown_terracotta
fill 559 164 294 559 171 294 minecraft:brown_terracotta
setblock 559 164 295 minecraft:white_concrete
fill 559 164 296 559 171 296 minecraft:brown_terracotta
fill 559 164 298 559 171 298 minecraft:brown_terracotta
setblock 559 164 299 minecraft:white_concrete
fill 559 164 300 559 165 300 minecraft:brown_terracotta
fill 559 164 302 559 165 302 minecraft:brown_terracotta
setblock 559 164 303 minecraft:white_concrete
fill 559 164 304 559 171 304 minecraft:brown_terracotta
fill 559 164 306 559 171 306 minecraft:brown_terracotta
setblock 559 164 307 minecraft:white_concrete
fill 559 164 308 559 171 308 minecraft:brown_terracotta
fill 559 164 310 559 171 310 minecraft:brown_terracotta
setblock 559 164 311 minecraft:white_concrete
fill 559 164 312 559 165 312 minecraft:brown_terracotta
fill 559 164 314 559 165 314 minecraft:brown_terracotta
setblock 559 164 315 minecraft:white_concrete
fill 559 164 316 559 171 316 minecraft:brown_terracotta
fill 517 165 275 517 172 275 minecraft:brown_terracotta
fill 517 165 279 518 165 279 minecraft:brown_terracotta
fill 517 165 283 518 165 283 minecraft:brown_terracotta
fill 517 165 287 517 172 287 minecraft:brown_terracotta
fill 517 165 291 518 165 291 minecraft:brown_terracotta
fill 517 165 295 518 165 295 minecraft:brown_terracotta
fill 517 165 299 517 172 299 minecraft:brown_terracotta
fill 517 165 303 518 165 303 minecraft:brown_terracotta
fill 517 165 307 518 165 307 minecraft:brown_terracotta
fill 517 165 311 517 172 311 minecraft:brown_terracotta
fill 517 165 315 518 165 315 minecraft:brown_terracotta
setblock 517 165 317 minecraft:brown_terracotta
fill 518 165 280 518 165 282 minecraft:brown_terracotta
setblock 518 165 284 minecraft:brown_terracotta
fill 518 165 292 518 165 294 minecraft:brown_terracotta
setblock 518 165 296 minecraft:brown_terracotta
fill 518 165 304 518 165 306 minecraft:brown_terracotta
setblock 518 165 308 minecraft:brown_terracotta
fill 518 165 316 522 165 316 minecraft:brown_terracotta
setblock 520 165 278 minecraft:light[level=12]
setblock 520 165 285 minecraft:light[level=12]
setblock 520 165 292 minecraft:light[level=12]
setblock 520 165 299 minecraft:light[level=12]
setblock 520 165 306 minecraft:light[level=12]
setblock 520 165 313 minecraft:light[level=12]
fill 521 165 275 521 172 275 minecraft:brown_terracotta
fill 521 165 317 521 172 317 minecraft:brown_terracotta
fill 522 165 276 527 165 276 minecraft:brown_terracotta
setblock 525 165 275 minecraft:brown_terracotta
fill 525 165 317 525 172 317 minecraft:brown_terracotta
setblock 527 165 278 minecraft:light[level=12]
setblock 527 165 285 minecraft:light[level=12]
setblock 527 165 292 minecraft:light[level=12]
setblock 527 165 299 minecraft:light[level=12]
setblock 527 165 306 minecraft:light[level=12]
setblock 527 165 313 minecraft:light[level=12]
fill 529 165 275 529 172 275 minecraft:brown_terracotta
fill 529 165 316 529 165 317 minecraft:brown_terracotta
fill 530 165 316 534 165 316 minecraft:brown_terracotta
fill 533 165 275 533 172 275 minecraft:brown_terracotta
fill 533 165 317 533 172 317 minecraft:brown_terracotta
fill 534 165 276 539 165 276 minecraft:brown_terracotta
setblock 534 165 278 minecraft:light[level=12]
setblock 534 165 285 minecraft:light[level=12]
setblock 534 165 292 minecraft:light[level=12]
setblock 534 165 299 minecraft:light[level=12]
setblock 534 165 306 minecraft:light[level=12]
setblock 534 165 313 minecraft:light[level=12]
setblock 537 165 275 minecraft:brown_terracotta
fill 537 165 317 537 172 317 minecraft:brown_terracotta
fill 541 165 275 541 172 275 minecraft:brown_terracotta
setblock 541 165 278 minecraft:light[level=12]
setblock 541 165 285 minecraft:light[level=12]
setblock 541 165 292 minecraft:light[level=12]
setblock 541 165 299 minecraft:light[level=12]
setblock 541 165 306 minecraft:light[level=12]
setblock 541 165 313 minecraft:light[level=12]
fill 541 165 316 541 165 317 minecraft:brown_terracotta
fill 542 165 316 546 165 316 minecraft:brown_terracotta
fill 545 165 275 545 172 275 minecraft:brown_terracotta
fill 545 165 317 545 172 317 minecraft:brown_terracotta
fill 546 165 276 551 165 276 minecraft:brown_terracotta
fill 546 165 310 557 165 315 minecraft:white_concrete
fill 547 165 316 552 165 316 minecraft:white_concrete
setblock 548 165 278 minecraft:light[level=12]
setblock 548 165 285 minecraft:light[level=12]
setblock 548 165 292 minecraft:light[level=12]
setblock 548 165 299 minecraft:light[level=12]
setblock 548 165 306 minecraft:light[level=12]
setblock 549 165 275 minecraft:brown_terracotta
fill 549 165 317 549 172 317 minecraft:brown_terracotta
fill 551 165 277 557 165 286 minecraft:white_concrete
fill 552 165 276 557 165 276 minecraft:white_concrete
setblock 553 165 275 minecraft:brown_terracotta
fill 553 165 316 553 165 317 minecraft:brown_terracotta
fill 554 165 316 558 165 316 minecraft:brown_terracotta
setblock 555 165 292 minecraft:light[level=12]
setblock 555 165 299 minecraft:light[level=12]
setblock 555 165 306 minecraft:light[level=12]
setblock 557 165 275 minecraft:brown_terracotta
fill 557 165 317 557 172 317 minecraft:brown_terracotta
fill 558 165 276 558 165 281 minecraft:brown_terracotta
fill 558 165 282 558 165 286 minecraft:white_concrete
fill 558 165 288 558 165 293 minecraft:brown_terracotta
fill 558 165 300 558 165 305 minecraft:brown_terracotta
fill 558 165 310 558 165 311 minecraft:white_concrete
fill 558 165 312 558 165 315 minecraft:brown_terracotta
fill 559 165 275 559 170 275 minecraft:brown_terracotta
setblock 559 165 279 minecraft:brown_terracotta
fill 559 165 283 559 172 283 minecraft:brown_terracotta
fill 559 165 287 559 172 287 minecraft:brown_terracotta
setblock 559 165 291 minecraft:brown_terracotta
fill 559 165 295 559 172 295 minecraft:brown_terracotta
fill 559 165 299 559 172 299 minecraft:brown_terracotta
setblock 559 165 303 minecraft:brown_terracotta
fill 559 165 307 559 172 307 minecraft:brown_terracotta
fill 559 165 311 559 172 311 minecraft:brown_terracotta
setblock 559 165 315 minecraft:brown_terracotta
fill 517 166 279 517 172 279 minecraft:brown_terracotta
fill 517 166 281 517 171 284 minecraft:shroomlight
fill 517 166 291 517 172 291 minecraft:brown_terracotta
fill 517 166 293 517 171 296 minecraft:shroomlight
fill 517 166 303 517 172 303 minecraft:brown_terracotta
fill 517 166 305 517 171 308 minecraft:shroomlight
fill 517 166 315 517 172 315 minecraft:brown_terracotta
fill 517 166 317 520 171 317 minecraft:shroomlight
fill 518 166 286 518 206 287 minecraft:white_concrete
fill 518 166 298 518 186 299 minecraft:white_concrete
fill 518 166 310 518 218 311 minecraft:white_concrete
fill 524 166 275 527 171 275 minecraft:shroomlight
fill 525 166 316 526 218 316 minecraft:white_concrete
fill 529 166 317 532 171 317 minecraft:shroomlight
fill 536 166 275 539 171 275 minecraft:shroomlight
fill 537 166 316 538 218 316 minecraft:white_concrete
fill 541 166 317 544 171 317 minecraft:shroomlight
setblock 546 166 310 minecraft:shroomlight
fill 546 166 311 546 179 311 minecraft:white_concrete
setblock 546 166 312 minecraft:shroomlight
fill 546 166 313 546 179 313 minecraft:white_concrete
setblock 546 166 314 minecraft:shroomlight
fill 546 166 315 546 179 315 minecraft:white_concrete
setblock 546 166 316 minecraft:shroomlight
fill 547 166 310 547 179 310 minecraft:white_concrete
setblock 547 166 311 minecraft:shroomlight
fill 547 166 312 547 179 312 minecraft:white_concrete
setblock 547 166 313 minecraft:shroomlight
fill 547 166 314 547 179 314 minecraft:white_concrete
setblock 547 166 315 minecraft:shroomlight
fill 547 166 316 547 179 316 minecraft:white_concrete
fill 548 166 275 551 171 275 minecraft:shroomlight
setblock 548 166 310 minecraft:shroomlight
fill 548 166 311 548 179 311 minecraft:white_concrete
setblock 548 166 312 minecraft:shroomlight
fill 548 166 313 548 179 313 minecraft:white_concrete
setblock 548 166 314 minecraft:shroomlight
fill 548 166 315 548 179 315 minecraft:white_concrete
setblock 548 166 316 minecraft:shroomlight
fill 549 166 310 549 179 310 minecraft:white_concrete
setblock 549 166 311 minecraft:shroomlight
fill 549 166 312 549 179 312 minecraft:white_concrete
setblock 549 166 313 minecraft:shroomlight
fill 549 166 314 549 179 314 minecraft:white_concrete
setblock 549 166 315 minecraft:shroomlight
fill 549 166 316 549 218 316 minecraft:white_concrete
setblock 550 166 310 minecraft:shroomlight
fill 550 166 311 550 179 311 minecraft:white_concrete
setblock 550 166 312 minecraft:shroomlight
fill 550 166 313 550 179 313 minecraft:white_concrete
setblock 550 166 314 minecraft:shroomlight
fill 550 166 315 550 185 315 minecraft:white_concrete
setblock 550 166 316 minecraft:shroomlight
fill 551 166 276 551 184 276 minecraft:white_concrete
setblock 551 166 277 minecraft:shroomlight
fill 551 166 278 551 188 278 minecraft:white_concrete
setblock 551 166 279 minecraft:shroomlight
fill 551 166 280 551 188 280 minecraft:white_concrete
setblock 551 166 281 minecraft:shroomlight
fill 551 166 282 551 188 282 minecraft:white_concrete
setblock 551 166 283 minecraft:shroomlight
fill 551 166 284 551 188 284 minecraft:white_concrete
setblock 551 166 285 minecraft:shroomlight
fill 551 166 286 551 188 286 minecraft:white_concrete
fill 551 166 310 551 179 310 minecraft:white_concrete
setblock 551 166 311 minecraft:shroomlight
fill 551 166 312 551 179 312 minecraft:white_concrete
setblock 551 166 313 minecraft:shroomlight
fill 551 166 314 551 179 314 minecraft:white_concrete
setblock 551 166 315 minecraft:shroomlight
fill 551 166 316 551 179 316 minecraft:white_concrete
setblock 552 166 276 minecraft:shroomlight
fill 552 166 277 552 188 277 minecraft:white_concrete
setblock 552 166 278 minecraft:shroomlight
fill 552 166 279 552 188 279 minecraft:white_concrete
setblock 552 166 280 minecraft:shroomlight
fill 552 166 281 552 188 281 minecraft:white_concrete
setblock 552 166 282 minecraft:shroomlight
fill 552 166 283 552 188 283 minecraft:white_concrete
setblock 552 166 284 minecraft:shroomlight
fill 552 166 285 552 188 285 minecraft:white_concrete
setblock 552 166 286 minecraft:shroomlight
setblock 552 166 310 minecraft:shroomlight
fill 552 166 311 552 179 311 minecraft:white_concrete
setblock 552 166 312 minecraft:shroomlight
fill 552 166 313 552 179 313 minecraft:white_concrete
setblock 552 166 314 minecraft:shroomlight
fill 552 166 315 552 179 315 minecraft:white_concrete
setblock 552 166 316 minecraft:shroomlight
setblock 553 166 275 minecraft:shroomlight
fill 553 166 276 553 188 276 minecraft:white_concrete
setblock 553 166 277 minecraft:shroomlight
fill 553 166 278 553 188 278 minecraft:white_concrete
setblock 553 166 279 minecraft:shroomlight
fill 553 166 280 553 188 280 minecraft:white_concrete
setblock 553 166 281 minecraft:shroomlight
fill 553 166 282 553 188 282 minecraft:white_concrete
setblock 553 166 283 minecraft:shroomlight
fill 553 166 284 553 188 284 minecraft:white_concrete
setblock 553 166 285 minecraft:shroomlight
fill 553 166 286 553 188 286 minecraft:white_concrete
fill 553 166 310 553 179 310 minecraft:white_concrete
setblock 553 166 311 minecraft:shroomlight
fill 553 166 312 553 179 312 minecraft:white_concrete
setblock 553 166 313 minecraft:shroomlight
fill 553 166 314 553 179 314 minecraft:white_concrete
setblock 553 166 315 minecraft:shroomlight
fill 553 166 316 553 179 316 minecraft:white_concrete
fill 553 166 317 556 171 317 minecraft:shroomlight
setblock 554 166 276 minecraft:shroomlight
fill 554 166 277 554 188 277 minecraft:white_concrete
setblock 554 166 278 minecraft:shroomlight
fill 554 166 279 554 188 279 minecraft:white_concrete
setblock 554 166 280 minecraft:shroomlight
fill 554 166 281 554 188 281 minecraft:white_concrete
setblock 554 166 282 minecraft:shroomlight
fill 554 166 283 554 188 283 minecraft:white_concrete
setblock 554 166 284 minecraft:shroomlight
fill 554 166 285 554 188 285 minecraft:white_concrete
setblock 554 166 286 minecraft:shroomlight
setblock 554 166 310 minecraft:shroomlight
fill 554 166 311 554 179 311 minecraft:white_concrete
setblock 554 166 312 minecraft:shroomlight
fill 554 166 313 554 179 313 minecraft:white_concrete
setblock 554 166 314 minecraft:shroomlight
fill 554 166 315 554 179 315 minecraft:white_concrete
setblock 554 166 316 minecraft:shroomlight
setblock 555 166 275 minecraft:shroomlight
fill 555 166 276 555 218 276 minecraft:white_concrete
setblock 555 166 277 minecraft:shroomlight
fill 555 166 278 555 188 278 minecraft:white_concrete
setblock 555 166 279 minecraft:shroomlight
fill 555 166 280 555 188 280 minecraft:white_concrete
setblock 555 166 281 minecraft:shroomlight
fill 555 166 282 555 188 282 minecraft:white_concrete
setblock 555 166 283 minecraft:shroomlight
fill 555 166 284 555 188 284 minecraft:white_concrete
setblock 555 166 285 minecraft:shroomlight
fill 555 166 286 555 188 286 minecraft:white_concrete
fill 555 166 310 555 179 310 minecraft:white_concrete
setblock 555 166 311 minecraft:shroomlight
fill 555 166 312 555 179 312 minecraft:white_concrete
setblock 555 166 313 minecraft:shroomlight
fill 555 166 314 555 179 314 minecraft:white_concrete
setblock 555 166 315 minecraft:shroomlight
fill 555 166 316 555 179 316 minecraft:white_concrete
setblock 556 166 276 minecraft:shroomlight
fill 556 166 277 556 188 277 minecraft:white_concrete
setblock 556 166 278 minecraft:shroomlight
fill 556 166 279 556 188 279 minecraft:white_concrete
setblock 556 166 280 minecraft:shroomlight
fill 556 166 281 556 188 281 minecraft:white_concrete
setblock 556 166 282 minecraft:shroomlight
fill 556 166 283 556 188 283 minecraft:white_concrete
setblock 556 166 284 minecraft:shroomlight
fill 556 166 285 556 188 285 minecraft:white_concrete
setblock 556 166 286 minecraft:shroomlight
setblock 556 166 310 minecraft:shroomlight
fill 556 166 311 556 179 311 minecraft:white_concrete
setblock 556 166 312 minecraft:shroomlight
fill 556 166 313 556 179 313 minecraft:white_concrete
setblock 556 166 314 minecraft:shroomlight
fill 556 166 315 556 179 315 minecraft:white_concrete
setblock 556 166 316 minecraft:shroomlight
setblock 557 166 275 minecraft:shroomlight
fill 557 166 276 557 188 276 minecraft:white_concrete
setblock 557 166 277 minecraft:shroomlight
fill 557 166 278 557 188 278 minecraft:white_concrete
setblock 557 166 279 minecraft:shroomlight
fill 557 166 280 557 188 280 minecraft:white_concrete
setblock 557 166 281 minecraft:shroomlight
fill 557 166 282 557 188 282 minecraft:white_concrete
setblock 557 166 283 minecraft:shroomlight
fill 557 166 284 557 188 284 minecraft:white_concrete
setblock 557 166 285 minecraft:shroomlight
fill 557 166 286 557 188 286 minecraft:white_concrete
fill 557 166 310 557 185 310 minecraft:white_concrete
setblock 557 166 311 minecraft:shroomlight
fill 557 166 312 557 179 312 minecraft:white_concrete
setblock 557 166 313 minecraft:shroomlight
fill 557 166 314 557 179 314 minecraft:white_concrete
setblock 557 166 315 minecraft:shroomlight
fill 557 166 316 557 179 316 minecraft:white_concrete
fill 558 166 276 559 166 276 minecraft:shroomlight
fill 558 166 277 558 184 277 minecraft:white_concrete
fill 558 166 278 559 166 278 minecraft:shroomlight
fill 558 166 279 558 184 279 minecraft:white_concrete
setblock 558 166 280 minecraft:shroomlight
fill 558 166 281 558 184 281 minecraft:white_concrete
setblock 558 166 282 minecraft:shroomlight
fill 558 166 283 558 188 283 minecraft:white_concrete
setblock 558 166 284 minecraft:shroomlight
fill 558 166 285 558 218 285 minecraft:white_concrete
setblock 558 166 286 minecraft:shroomlight
fill 558 166 309 558 218 309 minecraft:white_concrete
setblock 558 166 310 minecraft:shroomlight
fill 558 166 311 558 179 311 minecraft:white_concrete
fill 558 166 312 559 166 312 minecraft:shroomlight
fill 558 166 313 558 179 313 minecraft:white_concrete
fill 558 166 314 559 166 314 minecraft:shroomlight
fill 558 166 315 558 179 315 minecraft:white_concrete
setblock 558 166 316 minecraft:shroomlight
fill 559 166 277 559 172 277 minecraft:shroomlight
fill 559 166 279 559 171 279 minecraft:shroomlight
fill 559 166 288 559 171 291 minecraft:shroomlight
fill 559 166 300 559 171 303 minecraft:shroomlight
fill 559 166 313 559 172 313 minecraft:shroomlight
fill 559 166 315 559 171 315 minecraft:shroomlight
fill 546 167 310 546 168 310 minecraft:white_concrete
fill 546 167 312 546 168 312 minecraft:white_concrete
fill 546 167 314 546 168 314 minecraft:white_concrete
fill 546 167 316 546 168 316 minecraft:white_concrete
fill 547 167 311 547 168 311 minecraft:white_concrete
fill 547 167 313 547 168 313 minecraft:white_concrete
fill 547 167 315 547 168 315 minecraft:white_concrete
fill 548 167 310 548 168 310 minecraft:white_concrete
fill 548 167 312 548 168 312 minecraft:white_concrete
fill 548 167 314 548 168 314 minecraft:white_concrete
fill 548 167 316 548 168 316 minecraft:white_concrete
fill 549 167 311 549 168 311 minecraft:white_concrete
fill 549 167 313 549 168 313 minecraft:white_concrete
fill 549 167 315 549 168 315 minecraft:white_concrete
fill 550 167 310 550 168 310 minecraft:white_concrete
fill 550 167 312 550 168 312 minecraft:white_concrete
fill 550 167 314 550 168 314 minecraft:white_concrete
fill 550 167 316 550 168 316 minecraft:white_concrete
fill 551 167 277 551 168 277 minecraft:white_concrete
fill 551 167 279 551 168 279 minecraft:white_concrete
fill 551 167 281 551 168 281 minecraft:white_concrete
fill 551 167 283 551 168 283 minecraft:white_concrete
fill 551 167 285 551 168 285 minecraft:white_concrete
fill 551 167 311 551 168 311 minecraft:white_concrete
fill 551 167 313 551 168 313 minecraft:white_concrete
fill 551 167 315 551 168 315 minecraft:white_concrete
fill 552 167 276 552 168 276 minecraft:white_concrete
fill 552 167 278 552 168 278 minecraft:white_concrete
fill 552 167 280 552 168 280 minecraft:white_concrete
fill 552 167 282 552 168 282 minecraft:white_concrete
fill 552 167 284 552 168 284 minecraft:white_concrete
fill 552 167 286 552 168 286 minecraft:white_concrete
fill 552 167 310 552 168 310 minecraft:white_concrete
fill 552 167 312 552 168 312 minecraft:white_concrete
fill 552 167 314 552 168 314 minecraft:white_concrete
fill 552 167 316 552 168 316 minecraft:white_concrete
fill 553 167 275 553 168 275 minecraft:brown_terracotta
fill 553 167 277 553 168 277 minecraft:white_concrete
fill 553 167 279 553 168 279 minecraft:white_concrete
fill 553 167 281 553 168 281 minecraft:white_concrete
fill 553 167 283 553 168 283 minecraft:white_concrete
fill 553 167 285 553 168 285 minecraft:white_concrete
fill 553 167 311 553 168 311 minecraft:white_concrete
fill 553 167 313 553 168 313 minecraft:white_concrete
fill 553 167 315 553 168 315 minecraft:white_concrete
fill 554 167 276 554 168 276 minecraft:white_concrete
fill 554 167 278 554 168 278 minecraft:white_concrete
fill 554 167 280 554 168 280 minecraft:white_concrete
fill 554 167 282 554 168 282 minecraft:white_concrete
fill 554 167 284 554 168 284 minecraft:white_concrete
fill 554 167 286 554 168 286 minecraft:white_concrete
fill 554 167 310 554 168 310 minecraft:white_concrete
fill 554 167 312 554 168 312 minecraft:white_concrete
fill 554 167 314 554 168 314 minecraft:white_concrete
fill 554 167 316 554 168 316 minecraft:white_concrete
fill 555 167 275 555 168 275 minecraft:brown_terracotta
fill 555 167 277 555 168 277 minecraft:white_concrete
fill 555 167 279 555 168 279 minecraft:white_concrete
fill 555 167 281 555 168 281 minecraft:white_concrete
fill 555 167 283 555 168 283 minecraft:white_concrete
fill 555 167 285 555 168 285 minecraft:white_concrete
fill 555 167 311 555 168 311 minecraft:white_concrete
fill 555 167 313 555 168 313 minecraft:white_concrete
fill 555 167 315 555 168 315 minecraft:white_concrete
fill 556 167 276 556 168 276 minecraft:white_concrete
fill 556 167 278 556 168 278 minecraft:white_concrete
fill 556 167 280 556 168 280 minecraft:white_concrete
fill 556 167 282 556 168 282 minecraft:white_concrete
fill 556 167 284 556 168 284 minecraft:white_concrete
fill 556 167 286 556 168 286 minecraft:white_concrete
fill 556 167 310 556 168 310 minecraft:white_concrete
fill 556 167 312 556 168 312 minecraft:white_concrete
fill 556 167 314 556 168 314 minecraft:white_concrete
fill 556 167 316 556 168 316 minecraft:white_concrete
fill 557 167 275 557 168 275 minecraft:brown_terracotta
fill 557 167 277 557 168 277 minecraft:white_concrete
fill 557 167 279 557 168 279 minecraft:white_concrete
fill 557 167 281 557 168 281 minecraft:white_concrete
fill 557 167 283 557 168 283 minecraft:white_concrete
fill 557 167 285 557 168 285 minecraft:white_concrete
fill 557 167 311 557 168 311 minecraft:white_concrete
fill 557 167 313 557 168 313 minecraft:white_concrete
fill 557 167 315 557 168 315 minecraft:white_concrete
fill 558 167 276 558 168 276 minecraft:white_concrete
fill 558 167 278 558 168 278 minecraft:white_concrete
fill 558 167 280 558 168 280 minecraft:white_concrete
fill 558 167 282 558 168 282 minecraft:white_concrete
fill 558 167 284 558 168 284 minecraft:white_concrete
fill 558 167 286 558 168 286 minecraft:white_concrete
fill 558 167 310 558 168 310 minecraft:white_concrete
fill 558 167 312 558 168 312 minecraft:white_concrete
fill 558 167 314 558 168 314 minecraft:white_concrete
fill 558 167 316 558 168 316 minecraft:white_concrete
fill 559 167 276 559 171 276 minecraft:shroomlight
fill 559 167 278 559 172 278 minecraft:shroomlight
fill 559 167 312 559 171 312 minecraft:shroomlight
fill 559 167 314 559 172 314 minecraft:shroomlight
fill 524 168 289 524 169 289 minecraft:shroomlight
fill 527 169 286 527 170 286 minecraft:lime_concrete
setblock 546 169 310 minecraft:shroomlight
setblock 546 169 312 minecraft:shroomlight
setblock 546 169 314 minecraft:shroomlight
setblock 546 169 316 minecraft:shroomlight
setblock 547 169 311 minecraft:shroomlight
setblock 547 169 313 minecraft:shroomlight
setblock 547 169 315 minecraft:shroomlight
setblock 548 169 310 minecraft:shroomlight
setblock 548 169 312 minecraft:shroomlight
setblock 548 169 314 minecraft:shroomlight
setblock 548 169 316 minecraft:shroomlight
setblock 549 169 311 minecraft:shroomlight
setblock 549 169 313 minecraft:shroomlight
setblock 549 169 315 minecraft:shroomlight
setblock 550 169 310 minecraft:shroomlight
setblock 550 169 312 minecraft:shroomlight
setblock 550 169 314 minecraft:shroomlight
setblock 550 169 316 minecraft:shroomlight
setblock 551 169 277 minecraft:shroomlight
setblock 551 169 279 minecraft:shroomlight
setblock 551 169 281 minecraft:shroomlight
setblock 551 169 283 minecraft:shroomlight
setblock 551 169 285 minecraft:shroomlight
setblock 551 169 311 minecraft:shroomlight
setblock 551 169 313 minecraft:shroomlight
setblock 551 169 315 minecraft:shroomlight
setblock 552 169 276 minecraft:shroomlight
setblock 552 169 278 minecraft:shroomlight
setblock 552 169 280 minecraft:shroomlight
setblock 552 169 282 minecraft:shroomlight
setblock 552 169 284 minecraft:shroomlight
setblock 552 169 286 minecraft:shroomlight
setblock 552 169 310 minecraft:shroomlight
setblock 552 169 312 minecraft:shroomlight
setblock 552 169 314 minecraft:shroomlight
setblock 552 169 316 minecraft:shroomlight
setblock 553 169 275 minecraft:shroomlight
setblock 553 169 277 minecraft:shroomlight
setblock 553 169 279 minecraft:shroomlight
setblock 553 169 281 minecraft:shroomlight
setblock 553 169 283 minecraft:shroomlight
setblock 553 169 285 minecraft:shroomlight
setblock 553 169 311 minecraft:shroomlight
setblock 553 169 313 minecraft:shroomlight
setblock 553 169 315 minecraft:shroomlight
setblock 554 169 276 minecraft:shroomlight
setblock 554 169 278 minecraft:shroomlight
setblock 554 169 280 minecraft:shroomlight
setblock 554 169 282 minecraft:shroomlight
setblock 554 169 284 minecraft:shroomlight
setblock 554 169 286 minecraft:shroomlight
setblock 554 169 310 minecraft:shroomlight
setblock 554 169 312 minecraft:shroomlight
setblock 554 169 314 minecraft:shroomlight
setblock 554 169 316 minecraft:shroomlight
setblock 555 169 275 minecraft:shroomlight
setblock 555 169 277 minecraft:shroomlight
setblock 555 169 279 minecraft:shroomlight
setblock 555 169 281 minecraft:shroomlight
setblock 555 169 283 minecraft:shroomlight
setblock 555 169 285 minecraft:shroomlight
setblock 555 169 311 minecraft:shroomlight
setblock 555 169 313 minecraft:shroomlight
setblock 555 169 315 minecraft:shroomlight
setblock 556 169 276 minecraft:shroomlight
setblock 556 169 278 minecraft:shroomlight
setblock 556 169 280 minecraft:shroomlight
setblock 556 169 282 minecraft:shroomlight
setblock 556 169 284 minecraft:shroomlight
setblock 556 169 286 minecraft:shroomlight
setblock 556 169 310 minecraft:shroomlight
setblock 556 169 312 minecraft:shroomlight
setblock 556 169 314 minecraft:shroomlight
setblock 556 169 316 minecraft:shroomlight
setblock 557 169 275 minecraft:shroomlight
setblock 557 169 277 minecraft:shroomlight
setblock 557 169 279 minecraft:shroomlight
setblock 557 169 281 minecraft:shroomlight
setblock 557 169 283 minecraft:shroomlight
setblock 557 169 285 minecraft:shroomlight
setblock 557 169 311 minecraft:shroomlight
setblock 557 169 313 minecraft:shroomlight
setblock 557 169 315 minecraft:shroomlight
setblock 558 169 276 minecraft:shroomlight
setblock 558 169 278 minecraft:shroomlight
setblock 558 169 280 minecraft:shroomlight
setblock 558 169 282 minecraft:shroomlight
setblock 558 169 284 minecraft:shroomlight
setblock 558 169 286 minecraft:shroomlight
setblock 558 169 310 minecraft:shroomlight
setblock 558 169 312 minecraft:shroomlight
setblock 558 169 314 minecraft:shroomlight
setblock 558 169 316 minecraft:shroomlight
fill 524 170 289 524 179 289 minecraft:brown_terracotta
fill 546 170 310 546 171 310 minecraft:white_concrete
fill 546 170 312 546 171 312 minecraft:white_concrete
fill 546 170 314 546 171 314 minecraft:white_concrete
fill 546 170 316 546 171 316 minecraft:white_concrete
fill 547 170 311 547 171 311 minecraft:white_concrete
fill 547 170 313 547 171 313 minecraft:white_concrete
fill 547 170 315 547 171 315 minecraft:white_concrete
fill 548 170 310 548 171 310 minecraft:white_concrete
fill 548 170 312 548 171 312 minecraft:white_concrete
fill 548 170 314 548 171 314 minecraft:white_concrete
fill 548 170 316 548 171 316 minecraft:white_concrete
fill 549 170 311 549 171 311 minecraft:white_concrete
fill 549 170 313 549 171 313 minecraft:white_concrete
fill 549 170 315 549 171 315 minecraft:white_concrete
fill 550 170 310 550 171 310 minecraft:white_concrete
fill 550 170 312 550 171 312 minecraft:white_concrete
fill 550 170 314 550 171 314 minecraft:white_concrete
fill 550 170 316 550 171 316 minecraft:white_concrete
fill 551 170 277 551 171 277 minecraft:white_concrete
fill 551 170 279 551 171 279 minecraft:white_concrete
fill 551 170 281 551 171 281 minecraft:white_concrete
fill 551 170 283 551 171 283 minecraft:white_concrete
fill 551 170 285 551 171 285 minecraft:white_concrete
fill 551 170 311 551 171 311 minecraft:white_concrete
fill 551 170 313 551 171 313 minecraft:white_concrete
fill 551 170 315 551 171 315 minecraft:white_concrete
fill 552 170 276 552 171 276 minecraft:white_concrete
fill 552 170 278 552 171 278 minecraft:white_concrete
fill 552 170 280 552 171 280 minecraft:white_concrete
fill 552 170 282 552 171 282 minecraft:white_concrete
fill 552 170 284 552 171 284 minecraft:white_concrete
fill 552 170 286 552 171 286 minecraft:white_concrete
fill 552 170 310 552 171 310 minecraft:white_concrete
fill 552 170 312 552 171 312 minecraft:white_concrete
fill 552 170 314 552 171 314 minecraft:white_concrete
fill 552 170 316 552 171 316 minecraft:white_concrete
fill 553 170 275 553 171 275 minecraft:brown_terracotta
fill 553 170 277 553 171 277 minecraft:white_concrete
fill 553 170 279 553 171 279 minecraft:white_concrete
fill 553 170 281 553 171 281 minecraft:white_concrete
fill 553 170 283 553 171 283 minecraft:white_concrete
fill 553 170 285 553 171 285 minecraft:white_concrete
fill 553 170 311 553 171 311 minecraft:white_concrete
fill 553 170 313 553 171 313 minecraft:white_concrete
fill 553 170 315 553 171 315 minecraft:white_concrete
fill 554 170 276 554 171 276 minecraft:white_concrete
fill 554 170 278 554 171 278 minecraft:white_concrete
fill 554 170 280 554 171 280 minecraft:white_concrete
fill 554 170 282 554 171 282 minecraft:white_concrete
fill 554 170 284 554 171 284 minecraft:white_concrete
fill 554 170 286 554 171 286 minecraft:white_concrete
fill 554 170 310 554 171 310 minecraft:white_concrete
fill 554 170 312 554 171 312 minecraft:white_concrete
fill 554 170 314 554 171 314 minecraft:white_concrete
fill 554 170 316 554 171 316 minecraft:white_concrete
setblock 555 170 275 minecraft:brown_terracotta
fill 555 170 277 555 171 277 minecraft:white_concrete
fill 555 170 279 555 171 279 minecraft:white_concrete
fill 555 170 281 555 171 281 minecraft:white_concrete
fill 555 170 283 555 171 283 minecraft:white_concrete
fill 555 170 285 555 171 285 minecraft:white_concrete
fill 555 170 311 555 171 311 minecraft:white_concrete
fill 555 170 313 555 171 313 minecraft:white_concrete
fill 555 170 315 555 171 315 minecraft:white_concrete
fill 556 170 276 556 171 276 minecraft:white_concrete
fill 556 170 278 556 171 278 minecraft:white_concrete
fill 556 170 280 556 171 280 minecraft:white_concrete
fill 556 170 282 556 171 282 minecraft:white_concrete
fill 556 170 284 556 171 284 minecraft:white_concrete
fill 556 170 286 556 171 286 minecraft:white_concrete
fill 556 170 310 556 171 310 minecraft:white_concrete
fill 556 170 312 556 171 312 minecraft:white_concrete
fill 556 170 314 556 171 314 minecraft:white_concrete
fill 556 170 316 556 171 316 minecraft:white_concrete
fill 557 170 275 557 171 275 minecraft:brown_terracotta
fill 557 170 277 557 171 277 minecraft:white_concrete
fill 557 170 279 557 171 279 minecraft:white_concrete
fill 557 170 281 557 171 281 minecraft:white_concrete
fill 557 170 283 557 171 283 minecraft:white_concrete
fill 557 170 285 557 171 285 minecraft:white_concrete
fill 557 170 311 557 171 311 minecraft:white_concrete
fill 557 170 313 557 171 313 minecraft:white_concrete
fill 557 170 315 557 171 315 minecraft:white_concrete
fill 558 170 276 558 171 276 minecraft:white_concrete
fill 558 170 278 558 171 278 minecraft:white_concrete
fill 558 170 280 558 171 280 minecraft:white_concrete
fill 558 170 282 558 171 282 minecraft:white_concrete
fill 558 170 284 558 171 284 minecraft:white_concrete
fill 558 170 286 558 171 286 minecraft:white_concrete
fill 558 170 310 558 171 310 minecraft:white_concrete
fill 558 170 312 558 171 312 minecraft:white_concrete
fill 558 170 314 558 171 314 minecraft:white_concrete
fill 558 170 316 558 171 316 minecraft:white_concrete
setblock 517 171 277 minecraft:white_concrete
setblock 517 171 285 minecraft:white_concrete
setblock 517 171 289 minecraft:white_concrete
setblock 517 171 297 minecraft:white_concrete
setblock 517 171 301 minecraft:white_concrete
setblock 517 171 309 minecraft:white_concrete
setblock 517 171 313 minecraft:white_concrete
setblock 519 171 275 minecraft:white_concrete
setblock 520 171 278 minecraft:light[level=15]
fill 520 171 279 520 171 281 minecraft:brown_terracotta
setblock 520 171 285 minecraft:light[level=12]
setblock 520 171 286 minecraft:light[level=15]
setblock 520 171 292 minecraft:light[level=12]
setblock 520 171 294 minecraft:light[level=15]
setblock 520 171 299 minecraft:light[level=12]
setblock 520 171 302 minecraft:light[level=15]
setblock 520 171 306 minecraft:light[level=12]
setblock 520 171 310 minecraft:light[level=15]
setblock 520 171 313 minecraft:light[level=12]
fill 521 171 278 523 171 278 minecraft:brown_terracotta
setblock 521 171 282 minecraft:brown_terracotta
setblock 523 171 275 minecraft:white_concrete
setblock 523 171 282 minecraft:brown_terracotta
setblock 523 171 317 minecraft:white_concrete
fill 524 171 279 524 171 281 minecraft:brown_terracotta
fill 524 171 288 524 179 288 minecraft:brown_terracotta
setblock 527 171 278 minecraft:light[level=12]
setblock 527 171 285 minecraft:light[level=12]
setblock 527 171 292 minecraft:light[level=12]
setblock 527 171 299 minecraft:light[level=12]
setblock 527 171 306 minecraft:light[level=12]
setblock 527 171 313 minecraft:light[level=12]
setblock 527 171 317 minecraft:white_concrete
setblock 528 171 278 minecraft:light[level=15]
setblock 528 171 286 minecraft:light[level=15]
setblock 528 171 294 minecraft:light[level=15]
setblock 528 171 302 minecraft:light[level=15]
setblock 528 171 310 minecraft:light[level=15]
setblock 531 171 275 minecraft:white_concrete
setblock 534 171 278 minecraft:light[level=12]
setblock 534 171 285 minecraft:light[level=12]
setblock 534 171 292 minecraft:light[level=12]
setblock 534 171 299 minecraft:light[level=12]
setblock 534 171 306 minecraft:light[level=12]
setblock 534 171 313 minecraft:light[level=12]
setblock 535 171 275 minecraft:white_concrete
setblock 535 171 317 minecraft:white_concrete
setblock 536 171 278 minecraft:light[level=15]
setblock 536 171 286 minecraft:light[level=15]
setblock 536 171 294 minecraft:light[level=15]
setblock 536 171 302 minecraft:light[level=15]
setblock 536 171 310 minecraft:light[level=15]
setblock 539 171 317 minecraft:white_concrete
setblock 541 171 278 minecraft:light[level=12]
setblock 541 171 285 minecraft:light[level=12]
setblock 541 171 292 minecraft:light[level=12]
setblock 541 171 299 minecraft:light[level=12]
setblock 541 171 306 minecraft:light[level=12]
setblock 541 171 313 minecraft:light[level=12]
setblock 543 171 275 minecraft:white_concrete
setblock 544 171 278 minecraft:light[level=15]
setblock 544 171 286 minecraft:light[level=15]
setblock 544 171 294 minecraft:light[level=15]
setblock 544 171 302 minecraft:light[level=15]
setblock 544 171 310 minecraft:light[level=15]
setblock 547 171 275 minecraft:white_concrete
setblock 547 171 317 minecraft:white_concrete
setblock 548 171 278 minecraft:light[level=12]
setblock 548 171 285 minecraft:light[level=12]
setblock 548 171 292 minecraft:light[level=12]
setblock 548 171 299 minecraft:light[level=12]
setblock 548 171 306 minecraft:light[level=12]
setblock 551 171 317 minecraft:white_concrete
setblock 552 171 294 minecraft:light[level=15]
setblock 552 171 302 minecraft:light[level=15]
setblock 555 171 275 minecraft:white_concrete
setblock 555 171 292 minecraft:light[level=12]
setblock 555 171 299 minecraft:light[level=12]
setblock 555 171 306 minecraft:light[level=12]
setblock 559 171 275 minecraft:white_concrete
setblock 559 171 281 minecraft:white_concrete
setblock 559 171 285 minecraft:white_concrete
setblock 559 171 293 minecraft:white_concrete
setblock 559 171 297 minecraft:white_concrete
setblock 559 171 305 minecraft:white_concrete
setblock 559 171 309 minecraft:white_concrete
setblock 559 171 317 minecraft:white_concrete
setblock 517 172 276 minecraft:white_concrete
fill 517 172 277 517 179 277 minecraft:brown_terracotta
setblock 517 172 278 minecraft:white_concrete
setblock 517 172 280 minecraft:white_concrete
fill 517 172 281 517 179 281 minecraft:brown_terracotta
fill 517 172 282 517 172 283 minecraft:shroomlight
setblock 517 172 284 minecraft:white_concrete
fill 517 172 285 517 179 285 minecraft:brown_terracotta
setblock 517 172 286 minecraft:white_concrete
setblock 517 172 288 minecraft:white_concrete
fill 517 172 289 517 179 289 minecraft:brown_terracotta
setblock 517 172 290 minecraft:white_concrete
setblock 517 172 292 minecraft:white_concrete
fill 517 172 293 517 179 293 minecraft:brown_terracotta
fill 517 172 294 517 172 295 minecraft:shroomlight
setblock 517 172 296 minecraft:white_concrete
fill 517 172 297 517 179 297 minecraft:brown_terracotta
setblock 517 172 298 minecraft:white_concrete
setblock 517 172 300 minecraft:white_concrete
fill 517 172 301 517 179 301 minecraft:brown_terracotta
setblock 517 172 302 minecraft:white_concrete
setblock 517 172 304 minecraft:white_concrete
fill 517 172 305 517 179 305 minecraft:brown_terracotta
fill 517 172 306 517 172 307 minecraft:shroomlight
setblock 517 172 308 minecraft:white_concrete
fill 517 172 309 517 179 309 minecraft:brown_terracotta
setblock 517 172 310 minecraft:white_concrete
setblock 517 172 312 minecraft:white_concrete
fill 517 172 313 517 179 313 minecraft:brown_terracotta
setblock 517 172 314 minecraft:white_concrete
setblock 517 172 316 minecraft:white_concrete
setblock 517 172 317 minecraft:brown_terracotta
setblock 518 172 275 minecraft:white_concrete
fill 518 172 317 519 172 317 minecraft:shroomlight
fill 519 172 275 519 179 275 minecraft:brown_terracotta
setblock 520 172 275 minecraft:white_concrete
setblock 520 172 317 minecraft:white_concrete
setblock 522 172 275 minecraft:white_concrete
setblock 522 172 317 minecraft:white_concrete
fill 523 172 275 523 179 275 minecraft:brown_terracotta
fill 523 172 317 523 179 317 minecraft:brown_terracotta
setblock 524 172 275 minecraft:white_concrete
setblock 524 172 317 minecraft:white_concrete
fill 525 172 275 526 172 275 minecraft:shroomlight
fill 525 172 288 525 179 289 minecraft:brown_terracotta
setblock 526 172 317 minecraft:white_concrete
fill 527 172 275 527 179 275 minecraft:brown_terracotta
fill 527 172 317 527 179 317 minecraft:brown_terracotta
setblock 528 172 275 minecraft:white_concrete
setblock 528 172 317 minecraft:white_concrete
setblock 529 172 317 minecraft:brown_terracotta
setblock 530 172 275 minecraft:white_concrete
fill 530 172 317 531 172 317 minecraft:shroomlight
fill 531 172 275 531 179 275 minecraft:brown_terracotta
setblock 532 172 275 minecraft:white_concrete
setblock 532 172 317 minecraft:white_concrete
setblock 534 172 275 minecraft:white_concrete
setblock 534 172 317 minecraft:white_concrete
fill 535 172 275 535 179 275 minecraft:brown_terracotta
fill 535 172 317 535 179 317 minecraft:brown_terracotta
setblock 536 172 275 minecraft:white_concrete
fill 536 172 287 537 173 288 minecraft:lime_concrete
setblock 536 172 317 minecraft:white_concrete
fill 537 172 275 538 172 275 minecraft:shroomlight
setblock 538 172 317 minecraft:white_concrete
fill 539 172 275 539 179 275 minecraft:brown_terracotta
fill 539 172 317 539 179 317 minecraft:brown_terracotta
setblock 540 172 275 minecraft:white_concrete
setblock 540 172 317 minecraft:white_concrete
setblock 541 172 317 minecraft:brown_terracotta
setblock 542 172 275 minecraft:white_concrete
fill 542 172 317 543 172 317 minecraft:shroomlight
fill 543 172 275 543 179 275 minecraft:brown_terracotta
setblock 544 172 275 minecraft:white_concrete
setblock 544 172 317 minecraft:white_concrete
setblock 546 172 275 minecraft:white_concrete
setblock 546 172 310 minecraft:shroomlight
setblock 546 172 312 minecraft:shroomlight
setblock 546 172 314 minecraft:shroomlight
setblock 546 172 316 minecraft:shroomlight
setblock 546 172 317 minecraft:white_concrete
fill 547 172 275 547 179 275 minecraft:brown_terracotta
setblock 547 172 311 minecraft:shroomlight
setblock 547 172 313 minecraft:shroomlight
setblock 547 172 315 minecraft:shroomlight
fill 547 172 317 547 179 317 minecraft:brown_terracotta
setblock 548 172 275 minecraft:white_concrete
setblock 548 172 310 minecraft:shroomlight
setblock 548 172 312 minecraft:shroomlight
setblock 548 172 314 minecraft:shroomlight
setblock 548 172 316 minecraft:shroomlight
setblock 548 172 317 minecraft:white_concrete
fill 549 172 275 551 172 275 minecraft:shroomlight
setblock 549 172 311 minecraft:shroomlight
setblock 549 172 313 minecraft:shroomlight
setblock 549 172 315 minecraft:shroomlight
setblock 550 172 310 minecraft:shroomlight
setblock 550 172 312 minecraft:shroomlight
setblock 550 172 314 minecraft:shroomlight
setblock 550 172 316 minecraft:shroomlight
setblock 550 172 317 minecraft:white_concrete
setblock 551 172 277 minecraft:shroomlight
setblock 551 172 279 minecraft:shroomlight
setblock 551 172 281 minecraft:shroomlight
setblock 551 172 283 minecraft:shroomlight
setblock 551 172 285 minecraft:shroomlight
setblock 551 172 311 minecraft:shroomlight
setblock 551 172 313 minecraft:shroomlight
setblock 551 172 315 minecraft:shroomlight
fill 551 172 317 551 179 317 minecraft:brown_terracotta
setblock 552 172 275 minecraft:white_concrete
setblock 552 172 276 minecraft:shroomlight
setblock 552 172 278 minecraft:shroomlight
setblock 552 172 280 minecraft:shroomlight
setblock 552 172 282 minecraft:shroomlight
setblock 552 172 284 minecraft:shroomlight
setblock 552 172 286 minecraft:shroomlight
setblock 552 172 310 minecraft:shroomlight
setblock 552 172 312 minecraft:shroomlight
setblock 552 172 314 minecraft:shroomlight
setblock 552 172 316 minecraft:shroomlight
setblock 552 172 317 minecraft:white_concrete
setblock 553 172 275 minecraft:shroomlight
setblock 553 172 277 minecraft:shroomlight
setblock 553 172 279 minecraft:shroomlight
setblock 553 172 281 minecraft:shroomlight
setblock 553 172 283 minecraft:shroomlight
setblock 553 172 285 minecraft:shroomlight
setblock 553 172 311 minecraft:shroomlight
setblock 553 172 313 minecraft:shroomlight
setblock 553 172 315 minecraft:shroomlight
setblock 553 172 317 minecraft:brown_terracotta
setblock 554 172 275 minecraft:white_concrete
setblock 554 172 276 minecraft:shroomlight
setblock 554 172 278 minecraft:shroomlight
setblock 554 172 280 minecraft:shroomlight
setblock 554 172 282 minecraft:shroomlight
setblock 554 172 284 minecraft:shroomlight
setblock 554 172 286 minecraft:shroomlight
setblock 554 172 310 minecraft:shroomlight
setblock 554 172 312 minecraft:shroomlight
setblock 554 172 314 minecraft:shroomlight
fill 554 172 316 554 172 317 minecraft:shroomlight
setblock 555 172 275 minecraft:shroomlight
setblock 555 172 277 minecraft:shroomlight
setblock 555 172 279 minecraft:shroomlight
setblock 555 172 281 minecraft:shroomlight
setblock 555 172 283 minecraft:shroomlight
setblock 555 172 285 minecraft:shroomlight
setblock 555 172 311 minecraft:shroomlight
setblock 555 172 313 minecraft:shroomlight
setblock 555 172 315 minecraft:shroomlight
setblock 555 172 317 minecraft:shroomlight
setblock 556 172 275 minecraft:white_concrete
setblock 556 172 276 minecraft:shroomlight
setblock 556 172 278 minecraft:shroomlight
setblock 556 172 280 minecraft:shroomlight
setblock 556 172 282 minecraft:shroomlight
setblock 556 172 284 minecraft:shroomlight
setblock 556 172 286 minecraft:shroomlight
setblock 556 172 310 minecraft:shroomlight
setblock 556 172 312 minecraft:shroomlight
setblock 556 172 314 minecraft:shroomlight
setblock 556 172 316 minecraft:shroomlight
setblock 556 172 317 minecraft:white_concrete
setblock 557 172 275 minecraft:shroomlight
setblock 557 172 277 minecraft:shroomlight
setblock 557 172 279 minecraft:shroomlight
setblock 557 172 281 minecraft:shroomlight
setblock 557 172 283 minecraft:shroomlight
setblock 557 172 285 minecraft:shroomlight
setblock 557 172 311 minecraft:shroomlight
setblock 557 172 313 minecraft:shroomlight
setblock 557 172 315 minecraft:shroomlight
setblock 558 172 275 minecraft:white_concrete
setblock 558 172 276 minecraft:shroomlight
setblock 558 172 278 minecraft:shroomlight
setblock 558 172 280 minecraft:shroomlight
setblock 558 172 282 minecraft:shroomlight
setblock 558 172 284 minecraft:shroomlight
setblock 558 172 286 minecraft:shroomlight
setblock 558 172 310 minecraft:shroomlight
setblock 558 172 312 minecraft:shroomlight
setblock 558 172 314 minecraft:shroomlight
setblock 558 172 316 minecraft:shroomlight
setblock 558 172 317 minecraft:white_concrete
setblock 559 172 275 minecraft:brown_terracotta
setblock 559 172 276 minecraft:white_concrete
setblock 559 172 279 minecraft:brown_terracotta
setblock 559 172 280 minecraft:white_concrete
fill 559 172 281 559 179 281 minecraft:brown_terracotta
setblock 559 172 282 minecraft:white_concrete
setblock 559 172 284 minecraft:white_concrete
fill 559 172 285 559 179 285 minecraft:brown_terracotta
setblock 559 172 286 minecraft:white_concrete
setblock 559 172 288 minecraft:white_concrete
fill 559 172 289 559 172 290 minecraft:shroomlight
setblock 559 172 291 minecraft:brown_terracotta
setblock 559 172 292 minecraft:white_concrete
fill 559 172 293 559 179 293 minecraft:brown_terracotta
setblock 559 172 294 minecraft:white_concrete
setblock 559 172 296 minecraft:white_concrete
fill 559 172 297 559 179 297 minecraft:brown_terracotta
setblock 559 172 298 minecraft:white_concrete
setblock 559 172 300 minecraft:white_concrete
fill 559 172 301 559 172 302 minecraft:shroomlight
setblock 559 172 303 minecraft:brown_terracotta
setblock 559 172 304 minecraft:white_concrete
fill 559 172 305 559 179 305 minecraft:brown_terracotta
setblock 559 172 306 minecraft:white_concrete
setblock 559 172 308 minecraft:white_concrete
fill 559 172 309 559 179 309 minecraft:brown_terracotta
setblock 559 172 310 minecraft:white_concrete
setblock 559 172 312 minecraft:white_concrete
setblock 559 172 315 minecraft:brown_terracotta
setblock 559 172 316 minecraft:white_concrete
fill 559 172 317 559 179 317 minecraft:brown_terracotta
setblock 517 173 275 minecraft:white_concrete
fill 517 173 276 517 180 276 minecraft:brown_terracotta
fill 517 173 278 517 180 278 minecraft:brown_terracotta
setblock 517 173 279 minecraft:white_concrete
fill 517 173 280 517 180 280 minecraft:brown_terracotta
fill 517 173 282 517 180 282 minecraft:brown_terracotta
setblock 517 173 283 minecraft:white_concrete
fill 517 173 284 517 180 284 minecraft:brown_terracotta
fill 517 173 286 517 180 286 minecraft:brown_terracotta
setblock 517 173 287 minecraft:white_concrete
fill 517 173 288 517 180 288 minecraft:brown_terracotta
fill 517 173 290 517 180 290 minecraft:brown_terracotta
setblock 517 173 291 minecraft:white_concrete
fill 517 173 292 517 180 292 minecraft:brown_terracotta
fill 517 173 294 517 180 294 minecraft:brown_terracotta
setblock 517 173 295 minecraft:white_concrete
fill 517 173 296 517 180 296 minecraft:brown_terracotta
fill 517 173 298 517 180 298 minecraft:brown_terracotta
setblock 517 173 299 minecraft:white_concrete
fill 517 173 300 517 180 300 minecraft:brown_terracotta
fill 517 173 302 517 180 302 minecraft:brown_terracotta
setblock 517 173 303 minecraft:white_concrete
fill 517 173 304 517 180 304 minecraft:brown_terracotta
fill 517 173 306 517 180 306 minecraft:brown_terracotta
setblock 517 173 307 minecraft:white_concrete
fill 517 173 308 517 180 308 minecraft:brown_terracotta
fill 517 173 310 517 180 310 minecraft:brown_terracotta
setblock 517 173 311 minecraft:white_concrete
fill 517 173 312 517 180 312 minecraft:brown_terracotta
fill 517 173 314 517 180 314 minecraft:brown_terracotta
setblock 517 173 315 minecraft:white_concrete
fill 517 173 316 517 180 316 minecraft:brown_terracotta
setblock 517 173 317 minecraft:white_concrete
fill 518 173 275 518 180 275 minecraft:brown_terracotta
fill 518 173 317 520 179 317 minecraft:brown_terracotta
fill 520 173 275 520 180 275 minecraft:brown_terracotta
setblock 521 173 275 minecraft:white_concrete
setblock 521 173 317 minecraft:white_concrete
fill 522 173 275 522 180 275 minecraft:brown_terracotta
fill 522 173 317 522 180 317 minecraft:brown_terracotta
fill 523 173 288 523 179 289 minecraft:brown_terracotta
fill 524 173 275 524 180 275 minecraft:brown_terracotta
fill 524 173 287 524 179 287 minecraft:brown_terracotta
fill 524 173 290 525 179 290 minecraft:brown_terracotta
fill 524 173 317 524 180 317 minecraft:brown_terracotta
setblock 525 173 275 minecraft:white_concrete
setblock 525 173 317 minecraft:white_concrete
fill 526 173 275 526 180 275 minecraft:brown_terracotta
fill 526 173 317 526 180 317 minecraft:brown_terracotta
fill 528 173 275 528 180 275 minecraft:brown_terracotta
fill 528 173 317 528 180 317 minecraft:brown_terracotta
setblock 529 173 275 minecraft:white_concrete
setblock 529 173 317 minecraft:white_concrete
fill 530 173 275 530 180 275 minecraft:brown_terracotta
fill 530 173 317 532 179 317 minecraft:brown_terracotta
fill 532 173 275 532 180 275 minecraft:brown_terracotta
setblock 533 173 275 minecraft:white_concrete
setblock 533 173 317 minecraft:white_concrete
fill 534 173 275 534 180 275 minecraft:brown_terracotta
fill 534 173 317 534 180 317 minecraft:brown_terracotta
fill 536 173 275 536 180 275 minecraft:brown_terracotta
fill 536 173 317 536 180 317 minecraft:brown_terracotta
setblock 537 173 275 minecraft:white_concrete
setblock 537 173 317 minecraft:white_concrete
fill 538 173 275 538 180 275 minecraft:brown_terracotta
fill 538 173 317 538 180 317 minecraft:brown_terracotta
fill 540 173 275 540 180 275 minecraft:brown_terracotta
fill 540 173 317 540 180 317 minecraft:brown_terracotta
setblock 541 173 275 minecraft:white_concrete
setblock 541 173 317 minecraft:white_concrete
fill 542 173 275 542 180 275 minecraft:brown_terracotta
fill 542 173 317 544 179 317 minecraft:brown_terracotta
fill 544 173 275 544 180 275 minecraft:brown_terracotta
setblock 545 173 275 minecraft:white_concrete
setblock 545 173 317 minecraft:white_concrete
fill 546 173 275 546 180 275 minecraft:brown_terracotta
fill 546 173 310 546 174 310 minecraft:white_concrete
fill 546 173 312 546 174 312 minecraft:white_concrete
fill 546 173 314 546 174 314 minecraft:white_concrete
fill 546 173 316 546 174 316 minecraft:white_concrete
fill 546 173 317 546 180 317 minecraft:brown_terracotta
fill 547 173 311 547 174 311 minecraft:white_concrete
fill 547 173 313 547 174 313 minecraft:white_concrete
fill 547 173 315 547 174 315 minecraft:white_concrete
fill 548 173 275 548 180 275 minecraft:brown_terracotta
fill 548 173 310 548 174 310 minecraft:white_concrete
fill 548 173 312 548 174 312 minecraft:white_concrete
fill 548 173 314 548 174 314 minecraft:white_concrete
fill 548 173 316 548 174 316 minecraft:white_concrete
fill 548 173 317 548 180 317 minecraft:brown_terracotta
setblock 549 173 275 minecraft:white_concrete
fill 549 173 311 549 174 311 minecraft:white_concrete
fill 549 173 313 549 174 313 minecraft:white_concrete
fill 549 173 315 549 174 315 minecraft:white_concrete
setblock 549 173 317 minecraft:white_concrete
fill 550 173 275 552 174 275 minecraft:brown_terracotta
fill 550 173 310 550 174 310 minecraft:white_concrete
fill 550 173 312 550 174 312 minecraft:white_concrete
fill 550 173 314 550 174 314 minecraft:white_concrete
fill 550 173 316 550 174 316 minecraft:white_concrete
fill 550 173 317 550 180 317 minecraft:brown_terracotta
fill 551 173 277 551 174 277 minecraft:white_concrete
fill 551 173 279 551 174 279 minecraft:white_concrete
fill 551 173 281 551 174 281 minecraft:white_concrete
fill 551 173 283 551 174 283 minecraft:white_concrete
fill 551 173 285 551 174 285 minecraft:white_concrete
fill 551 173 311 551 174 311 minecraft:white_concrete
fill 551 173 313 551 174 313 minecraft:white_concrete
fill 551 173 315 551 174 315 minecraft:white_concrete
fill 552 173 276 552 174 276 minecraft:white_concrete
fill 552 173 278 552 174 278 minecraft:white_concrete
fill 552 173 280 552 174 280 minecraft:white_concrete
fill 552 173 282 552 174 282 minecraft:white_concrete
fill 552 173 284 552 174 284 minecraft:white_concrete
fill 552 173 286 552 174 286 minecraft:white_concrete
fill 552 173 310 552 174 310 minecraft:white_concrete
fill 552 173 312 552 174 312 minecraft:white_concrete
fill 552 173 314 552 174 314 minecraft:white_concrete
fill 552 173 316 552 174 316 minecraft:white_concrete
fill 552 173 317 552 180 317 minecraft:brown_terracotta
setblock 553 173 275 minecraft:white_concrete
fill 553 173 277 553 174 277 minecraft:white_concrete
fill 553 173 279 553 174 279 minecraft:white_concrete
fill 553 173 281 553 174 281 minecraft:white_concrete
fill 553 173 283 553 174 283 minecraft:white_concrete
fill 553 173 285 553 174 285 minecraft:white_concrete
fill 553 173 311 553 174 311 minecraft:white_concrete
fill 553 173 313 553 174 313 minecraft:white_concrete
fill 553 173 315 553 174 315 minecraft:white_concrete
setblock 553 173 317 minecraft:white_concrete
fill 554 173 275 556 174 275 minecraft:brown_terracotta
fill 554 173 276 554 174 276 minecraft:white_concrete
fill 554 173 278 554 174 278 minecraft:white_concrete
fill 554 173 280 554 174 280 minecraft:white_concrete
fill 554 173 282 554 174 282 minecraft:white_concrete
fill 554 173 284 554 174 284 minecraft:white_concrete
fill 554 173 286 554 174 286 minecraft:white_concrete
fill 554 173 310 554 174 310 minecraft:white_concrete
fill 554 173 312 554 174 312 minecraft:white_concrete
fill 554 173 314 554 174 314 minecraft:white_concrete
fill 554 173 316 554 174 316 minecraft:white_concrete
fill 554 173 317 556 179 317 minecraft:brown_terracotta
fill 555 173 277 555 174 277 minecraft:white_concrete
fill 555 173 279 555 174 279 minecraft:white_concrete
fill 555 173 281 555 174 281 minecraft:white_concrete
fill 555 173 283 555 174 283 minecraft:white_concrete
fill 555 173 285 555 174 285 minecraft:white_concrete
fill 555 173 311 555 174 311 minecraft:white_concrete
fill 555 173 313 555 174 313 minecraft:white_concrete
fill 555 173 315 555 174 315 minecraft:white_concrete
fill 556 173 276 556 174 276 minecraft:white_concrete
fill 556 173 278 556 174 278 minecraft:white_concrete
fill 556 173 280 556 174 280 minecraft:white_concrete
fill 556 173 282 556 174 282 minecraft:white_concrete
fill 556 173 284 556 174 284 minecraft:white_concrete
fill 556 173 286 556 174 286 minecraft:white_concrete
fill 556 173 310 556 174 310 minecraft:white_concrete
fill 556 173 312 556 174 312 minecraft:white_concrete
fill 556 173 314 556 174 314 minecraft:white_concrete
fill 556 173 316 556 174 316 minecraft:white_concrete
setblock 557 173 275 minecraft:white_concrete
fill 557 173 277 557 174 277 minecraft:white_concrete
fill 557 173 279 557 174 279 minecraft:white_concrete
fill 557 173 281 557 174 281 minecraft:white_concrete
fill 557 173 283 557 174 283 minecraft:white_concrete
fill 557 173 285 557 174 285 minecraft:white_concrete
fill 557 173 311 557 174 311 minecraft:white_concrete
fill 557 173 313 557 174 313 minecraft:white_concrete
fill 557 173 315 557 174 315 minecraft:white_concrete
setblock 557 173 317 minecraft:white_concrete
fill 558 173 275 558 180 275 minecraft:brown_terracotta
fill 558 173 276 558 174 276 minecraft:white_concrete
fill 558 173 278 558 174 278 minecraft:white_concrete
fill 558 173 280 558 174 280 minecraft:white_concrete
fill 558 173 282 558 174 282 minecraft:white_concrete
fill 558 173 284 558 174 284 minecraft:white_concrete
fill 558 173 286 558 174 286 minecraft:white_concrete
fill 558 173 310 558 174 310 minecraft:white_concrete
fill 558 173 312 558 174 312 minecraft:white_concrete
fill 558 173 314 558 174 314 minecraft:white_concrete
fill 558 173 316 558 174 316 minecraft:white_concrete
fill 558 173 317 558 180 317 minecraft:brown_terracotta
setblock 559 173 275 minecraft:white_concrete
fill 559 173 276 559 179 278 minecraft:brown_terracotta
setblock 559 173 279 minecraft:white_concrete
fill 559 173 280 559 180 280 minecraft:brown_terracotta
fill 559 173 282 559 180 282 minecraft:brown_terracotta
setblock 559 173 283 minecraft:white_concrete
fill 559 173 284 559 180 284 minecraft:brown_terracotta
fill 559 173 286 559 180 286 minecraft:brown_terracotta
setblock 559 173 287 minecraft:white_concrete
fill 559 173 288 559 179 290 minecraft:brown_terracotta
setblock 559 173 291 minecraft:white_concrete
fill 559 173 292 559 180 292 minecraft:brown_terracotta
fill 559 173 294 559 180 294 minecraft:brown_terracotta
setblock 559 173 295 minecraft:white_concrete
fill 559 173 296 559 180 296 minecraft:brown_terracotta
fill 559 173 298 559 180 298 minecraft:brown_terracotta
setblock 559 173 299 minecraft:white_concrete
fill 559 173 300 559 179 302 minecraft:brown_terracotta
setblock 559 173 303 minecraft:white_concrete
fill 559 173 304 559 180 304 minecraft:brown_terracotta
fill 559 173 306 559 180 306 minecraft:brown_terracotta
setblock 559 173 307 minecraft:white_concrete
fill 559 173 308 559 180 308 minecraft:brown_terracotta
fill 559 173 310 559 180 310 minecraft:brown_terracotta
setblock 559 173 311 minecraft:white_concrete
fill 559 173 312 559 179 314 minecraft:brown_terracotta
setblock 559 173 315 minecraft:white_concrete
fill 559 173 316 559 180 316 minecraft:brown_terracotta
fill 517 174 275 517 181 275 minecraft:brown_terracotta
fill 517 174 279 517 181 279 minecraft:brown_terracotta
fill 517 174 283 517 181 283 minecraft:brown_terracotta
fill 517 174 287 517 181 287 minecraft:brown_terracotta
fill 517 174 291 517 181 291 minecraft:brown_terracotta
fill 517 174 295 517 181 295 minecraft:brown_terracotta
fill 517 174 299 517 181 299 minecraft:brown_terracotta
fill 517 174 303 517 181 303 minecraft:brown_terracotta
fill 517 174 307 517 181 307 minecraft:brown_terracotta
fill 517 174 311 517 181 311 minecraft:brown_terracotta
fill 517 174 315 517 181 315 minecraft:brown_terracotta
fill 517 174 317 517 179 317 minecraft:brown_terracotta
fill 521 174 275 521 181 275 minecraft:brown_terracotta
fill 521 174 317 521 181 317 minecraft:brown_terracotta
fill 523 174 287 523 179 287 minecraft:brown_terracotta
fill 523 174 290 523 179 290 minecraft:brown_terracotta
fill 525 174 275 525 181 275 minecraft:brown_terracotta
fill 525 174 287 525 179 287 minecraft:brown_terracotta
fill 525 174 317 525 181 317 minecraft:brown_terracotta
fill 526 174 288 526 179 289 minecraft:brown_terracotta
fill 529 174 275 529 181 275 minecraft:brown_terracotta
fill 529 174 317 529 181 317 minecraft:brown_terracotta
fill 533 174 275 533 181 275 minecraft:brown_terracotta
fill 533 174 317 533 181 317 minecraft:brown_terracotta
fill 537 174 275 537 181 275 minecraft:brown_terracotta
fill 537 174 317 537 181 317 minecraft:brown_terracotta
fill 541 174 275 541 181 275 minecraft:brown_terracotta
fill 541 174 317 541 181 317 minecraft:brown_terracotta
fill 545 174 275 545 181 275 minecraft:brown_terracotta
fill 545 174 317 545 181 317 minecraft:brown_terracotta
fill 549 174 275 549 181 275 minecraft:brown_terracotta
fill 549 174 317 549 181 317 minecraft:brown_terracotta
setblock 553 174 275 minecraft:brown_terracotta
fill 553 174 317 553 181 317 minecraft:brown_terracotta
setblock 557 174 275 minecraft:brown_terracotta
fill 557 174 317 557 181 317 minecraft:brown_terracotta
fill 559 174 275 559 179 275 minecraft:brown_terracotta
fill 559 174 279 559 181 279 minecraft:brown_terracotta
fill 559 174 283 559 181 283 minecraft:brown_terracotta
fill 559 174 287 559 181 287 minecraft:brown_terracotta
fill 559 174 291 559 181 291 minecraft:brown_terracotta
fill 559 174 295 559 181 295 minecraft:brown_terracotta
fill 559 174 299 559 181 299 minecraft:brown_terracotta
fill 559 174 303 559 181 303 minecraft:brown_terracotta
fill 559 174 307 559 181 307 minecraft:brown_terracotta
fill 559 174 311 559 181 311 minecraft:brown_terracotta
fill 559 174 315 559 181 315 minecraft:brown_terracotta
fill 520 175 281 524 175 285 minecraft:orange_terracotta
fill 521 175 279 523 218 280 minecraft:white_concrete
fill 522 175 288 522 179 289 minecraft:brown_terracotta
fill 524 175 291 525 179 291 minecraft:brown_terracotta
fill 526 175 287 526 179 287 minecraft:brown_terracotta
fill 526 175 290 526 179 290 minecraft:brown_terracotta
setblock 546 175 310 minecraft:shroomlight
setblock 546 175 312 minecraft:shroomlight
setblock 546 175 314 minecraft:shroomlight
setblock 546 175 316 minecraft:shroomlight
setblock 547 175 311 minecraft:shroomlight
setblock 547 175 313 minecraft:shroomlight
setblock 547 175 315 minecraft:shroomlight
setblock 548 175 310 minecraft:shroomlight
setblock 548 175 312 minecraft:shroomlight
setblock 548 175 314 minecraft:shroomlight
setblock 548 175 316 minecraft:shroomlight
setblock 549 175 311 minecraft:shroomlight
setblock 549 175 313 minecraft:shroomlight
setblock 549 175 315 minecraft:shroomlight
fill 550 175 275 550 180 275 minecraft:brown_terracotta
setblock 550 175 310 minecraft:shroomlight
setblock 550 175 312 minecraft:shroomlight
setblock 550 175 314 minecraft:shroomlight
setblock 550 175 316 minecraft:shroomlight
setblock 551 175 275 minecraft:shroomlight
setblock 551 175 277 minecraft:shroomlight
setblock 551 175 279 minecraft:shroomlight
setblock 551 175 281 minecraft:shroomlight
setblock 551 175 283 minecraft:shroomlight
setblock 551 175 285 minecraft:shroomlight
setblock 551 175 311 minecraft:shroomlight
setblock 551 175 313 minecraft:shroomlight
setblock 551 175 315 minecraft:shroomlight
fill 552 175 275 552 180 275 minecraft:brown_terracotta
setblock 552 175 276 minecraft:shroomlight
setblock 552 175 278 minecraft:shroomlight
setblock 552 175 280 minecraft:shroomlight
setblock 552 175 282 minecraft:shroomlight
setblock 552 175 284 minecraft:shroomlight
setblock 552 175 286 minecraft:shroomlight
setblock 552 175 310 minecraft:shroomlight
setblock 552 175 312 minecraft:shroomlight
setblock 552 175 314 minecraft:shroomlight
setblock 552 175 316 minecraft:shroomlight
setblock 553 175 275 minecraft:shroomlight
setblock 553 175 277 minecraft:shroomlight
setblock 553 175 279 minecraft:shroomlight
setblock 553 175 281 minecraft:shroomlight
setblock 553 175 283 minecraft:shroomlight
setblock 553 175 285 minecraft:shroomlight
setblock 553 175 311 minecraft:shroomlight
setblock 553 175 313 minecraft:shroomlight
setblock 553 175 315 minecraft:shroomlight
fill 554 175 275 554 180 275 minecraft:brown_terracotta
setblock 554 175 276 minecraft:shroomlight
setblock 554 175 278 minecraft:shroomlight
setblock 554 175 280 minecraft:shroomlight
setblock 554 175 282 minecraft:shroomlight
setblock 554 175 284 minecraft:shroomlight
setblock 554 175 286 minecraft:shroomlight
setblock 554 175 310 minecraft:shroomlight
setblock 554 175 312 minecraft:shroomlight
setblock 554 175 314 minecraft:shroomlight
setblock 554 175 316 minecraft:shroomlight
setblock 555 175 275 minecraft:shroomlight
setblock 555 175 277 minecraft:shroomlight
setblock 555 175 279 minecraft:shroomlight
setblock 555 175 281 minecraft:shroomlight
setblock 555 175 283 minecraft:shroomlight
setblock 555 175 285 minecraft:shroomlight
setblock 555 175 311 minecraft:shroomlight
setblock 555 175 313 minecraft:shroomlight
setblock 555 175 315 minecraft:shroomlight
fill 556 175 275 556 180 275 minecraft:brown_terracotta
setblock 556 175 276 minecraft:shroomlight
setblock 556 175 278 minecraft:shroomlight
setblock 556 175 280 minecraft:shroomlight
setblock 556 175 282 minecraft:shroomlight
setblock 556 175 284 minecraft:shroomlight
setblock 556 175 286 minecraft:shroomlight
setblock 556 175 310 minecraft:shroomlight
setblock 556 175 312 minecraft:shroomlight
setblock 556 175 314 minecraft:shroomlight
setblock 556 175 316 minecraft:shroomlight
setblock 557 175 275 minecraft:shroomlight
setblock 557 175 277 minecraft:shroomlight
setblock 557 175 279 minecraft:shroomlight
setblock 557 175 281 minecraft:shroomlight
setblock 557 175 283 minecraft:shroomlight
setblock 557 175 285 minecraft:shroomlight
setblock 557 175 311 minecraft:shroomlight
setblock 557 175 313 minecraft:shroomlight
setblock 557 175 315 minecraft:shroomlight
setblock 558 175 276 minecraft:shroomlight
setblock 558 175 278 minecraft:shroomlight
setblock 558 175 280 minecraft:shroomlight
setblock 558 175 282 minecraft:shroomlight
setblock 558 175 284 minecraft:shroomlight
setblock 558 175 286 minecraft:shroomlight
setblock 558 175 310 minecraft:shroomlight
setblock 558 175 312 minecraft:shroomlight
setblock 558 175 314 minecraft:shroomlight
setblock 558 175 316 minecraft:shroomlight
fill 520 176 281 521 179 285 minecraft:orange_terracotta
fill 522 176 281 524 179 282 minecraft:orange_terracotta
fill 522 176 283 522 177 283 minecraft:ochre_froglight
fill 522 176 284 524 179 285 minecraft:orange_terracotta
fill 522 176 287 522 179 287 minecraft:brown_terracotta
fill 522 176 290 522 179 290 minecraft:brown_terracotta
fill 523 176 283 524 179 283 minecraft:orange_terracotta
fill 523 176 286 525 179 286 minecraft:brown_terracotta
fill 523 176 291 523 179 291 minecraft:brown_terracotta
fill 526 176 291 526 179 291 minecraft:brown_terracotta
fill 527 176 288 527 179 290 minecraft:brown_terracotta
fill 531 176 282 531 177 282 minecraft:red_concrete
fill 546 176 310 546 177 310 minecraft:white_concrete
fill 546 176 312 546 177 312 minecraft:white_concrete
fill 546 176 314 546 177 314 minecraft:white_concrete
fill 546 176 316 546 177 316 minecraft:white_concrete
fill 547 176 311 547 177 311 minecraft:white_concrete
fill 547 176 313 547 177 313 minecraft:white_concrete
fill 547 176 315 547 177 315 minecraft:white_concrete
fill 548 176 296 548 177 296 minecraft:lime_concrete
fill 548 176 310 548 177 310 minecraft:white_concrete
fill 548 176 312 548 177 312 minecraft:white_concrete
fill 548 176 314 548 177 314 minecraft:white_concrete
fill 548 176 316 548 177 316 minecraft:white_concrete
fill 549 176 311 549 177 311 minecraft:white_concrete
fill 549 176 313 549 177 313 minecraft:white_concrete
fill 549 176 315 549 177 315 minecraft:white_concrete
fill 550 176 310 550 177 310 minecraft:white_concrete
fill 550 176 312 550 177 312 minecraft:white_concrete
fill 550 176 314 550 177 314 minecraft:white_concrete
fill 550 176 316 550 177 316 minecraft:white_concrete
fill 551 176 275 551 177 275 minecraft:brown_terracotta
fill 551 176 277 551 177 277 minecraft:white_concrete
fill 551 176 279 551 177 279 minecraft:white_concrete
fill 551 176 281 551 177 281 minecraft:white_concrete
fill 551 176 283 551 177 283 minecraft:white_concrete
fill 551 176 285 551 177 285 minecraft:white_concrete
fill 551 176 311 551 177 311 minecraft:white_concrete
fill 551 176 313 551 177 313 minecraft:white_concrete
fill 551 176 315 551 177 315 minecraft:white_concrete
fill 552 176 276 552 177 276 minecraft:white_concrete
fill 552 176 278 552 177 278 minecraft:white_concrete
fill 552 176 280 552 177 280 minecraft:white_concrete
fill 552 176 282 552 177 282 minecraft:white_concrete
fill 552 176 284 552 177 284 minecraft:white_concrete
fill 552 176 286 552 177 286 minecraft:white_concrete
fill 552 176 310 552 177 310 minecraft:white_concrete
fill 552 176 312 552 177 312 minecraft:white_concrete
fill 552 176 314 552 177 314 minecraft:white_concrete
fill 552 176 316 552 177 316 minecraft:white_concrete
fill 553 176 275 553 177 275 minecraft:brown_terracotta
fill 553 176 277 553 177 277 minecraft:white_concrete
fill 553 176 279 553 177 279 minecraft:white_concrete
fill 553 176 281 553 177 281 minecraft:white_concrete
fill 553 176 283 553 177 283 minecraft:white_concrete
fill 553 176 285 553 177 285 minecraft:white_concrete
fill 553 176 311 553 177 311 minecraft:white_concrete
fill 553 176 313 553 177 313 minecraft:white_concrete
fill 553 176 315 553 177 315 minecraft:white_concrete
fill 554 176 276 554 177 276 minecraft:white_concrete
fill 554 176 278 554 177 278 minecraft:white_concrete
fill 554 176 280 554 177 280 minecraft:white_concrete
fill 554 176 282 554 177 282 minecraft:white_concrete
fill 554 176 284 554 177 284 minecraft:white_concrete
fill 554 176 286 554 177 286 minecraft:white_concrete
fill 554 176 310 554 177 310 minecraft:white_concrete
fill 554 176 312 554 177 312 minecraft:white_concrete
fill 554 176 314 554 177 314 minecraft:white_concrete
fill 554 176 316 554 177 316 minecraft:white_concrete
fill 555 176 275 555 177 275 minecraft:brown_terracotta
fill 555 176 277 555 177 277 minecraft:white_concrete
fill 555 176 279 555 177 279 minecraft:white_concrete
fill 555 176 281 555 177 281 minecraft:white_concrete
fill 555 176 283 555 177 283 minecraft:white_concrete
fill 555 176 285 555 177 285 minecraft:white_concrete
fill 555 176 311 555 177 311 minecraft:white_concrete
fill 555 176 313 555 177 313 minecraft:white_concrete
fill 555 176 315 555 177 315 minecraft:white_concrete
fill 556 176 276 556 177 276 minecraft:white_concrete
fill 556 176 278 556 177 278 minecraft:white_concrete
fill 556 176 280 556 177 280 minecraft:white_concrete
fill 556 176 282 556 177 282 minecraft:white_concrete
fill 556 176 284 556 177 284 minecraft:white_concrete
fill 556 176 286 556 177 286 minecraft:white_concrete
fill 556 176 310 556 177 310 minecraft:white_concrete
fill 556 176 312 556 177 312 minecraft:white_concrete
fill 556 176 314 556 177 314 minecraft:white_concrete
fill 556 176 316 556 177 316 minecraft:white_concrete
fill 557 176 275 557 177 275 minecraft:brown_terracotta
fill 557 176 277 557 177 277 minecraft:white_concrete
fill 557 176 279 557 177 279 minecraft:white_concrete
fill 557 176 281 557 177 281 minecraft:white_concrete
fill 557 176 283 557 177 283 minecraft:white_concrete
fill 557 176 285 557 177 285 minecraft:white_concrete
fill 557 176 311 557 177 311 minecraft:white_concrete
fill 557 176 313 557 177 313 minecraft:white_concrete
fill 557 176 315 557 177 315 minecraft:white_concrete
fill 558 176 276 558 177 276 minecraft:white_concrete
fill 558 176 278 558 177 278 minecraft:white_concrete
fill 558 176 280 558 177 280 minecraft:white_concrete
fill 558 176 282 558 177 282 minecraft:white_concrete
fill 558 176 284 558 177 284 minecraft:white_concrete
fill 558 176 286 558 177 286 minecraft:white_concrete
fill 558 176 310 558 177 310 minecraft:white_concrete
fill 558 176 312 558 177 312 minecraft:white_concrete
fill 558 176 314 558 177 314 minecraft:white_concrete
fill 558 176 316 558 177 316 minecraft:white_concrete
setblock 520 177 278 minecraft:light[level=12]
setblock 520 177 292 minecraft:light[level=12]
setblock 520 177 299 minecraft:light[level=12]
setblock 520 177 306 minecraft:light[level=12]
setblock 520 177 313 minecraft:light[level=12]
fill 521 177 288 521 179 290 minecraft:brown_terracotta
fill 522 177 286 522 179 286 minecraft:brown_terracotta
fill 522 177 291 522 179 291 minecraft:brown_terracotta
fill 523 177 292 525 179 292 minecraft:brown_terracotta
fill 526 177 286 526 179 286 minecraft:brown_terracotta
setblock 527 177 278 minecraft:light[level=12]
setblock 527 177 285 minecraft:light[level=12]
fill 527 177 287 527 179 287 minecraft:brown_terracotta
fill 527 177 291 527 179 291 minecraft:brown_terracotta
setblock 527 177 292 minecraft:light[level=12]
setblock 527 177 299 minecraft:light[level=12]
setblock 527 177 306 minecraft:light[level=12]
setblock 527 177 313 minecraft:light[level=12]
setblock 534 177 278 minecraft:light[level=12]
setblock 534 177 285 minecraft:light[level=12]
setblock 534 177 292 minecraft:light[level=12]
setblock 534 177 299 minecraft:light[level=12]
setblock 534 177 306 minecraft:light[level=12]
setblock 534 177 313 minecraft:light[level=12]
setblock 541 177 278 minecraft:light[level=12]
setblock 541 177 285 minecraft:light[level=12]
setblock 541 177 292 minecraft:light[level=12]
setblock 541 177 299 minecraft:light[level=12]
setblock 541 177 306 minecraft:light[level=12]
setblock 541 177 313 minecraft:light[level=12]
setblock 548 177 278 minecraft:light[level=12]
setblock 548 177 285 minecraft:light[level=12]
setblock 548 177 292 minecraft:light[level=12]
setblock 548 177 299 minecraft:light[level=12]
setblock 548 177 306 minecraft:light[level=12]
setblock 555 177 292 minecraft:light[level=12]
setblock 555 177 299 minecraft:light[level=12]
setblock 555 177 306 minecraft:light[level=12]
fill 521 178 287 521 179 287 minecraft:brown_terracotta
fill 521 178 291 521 179 291 minecraft:brown_terracotta
fill 522 178 283 522 179 283 minecraft:orange_terracotta
fill 522 178 292 522 179 292 minecraft:brown_terracotta
fill 525 178 285 526 179 285 minecraft:brown_terracotta
fill 526 178 292 526 179 292 minecraft:brown_terracotta
fill 527 178 286 527 179 286 minecraft:brown_terracotta
fill 528 178 287 528 179 290 minecraft:brown_terracotta
setblock 546 178 310 minecraft:shroomlight
setblock 546 178 312 minecraft:shroomlight
setblock 546 178 314 minecraft:shroomlight
setblock 546 178 316 minecraft:shroomlight
setblock 547 178 311 minecraft:shroomlight
setblock 547 178 313 minecraft:shroomlight
setblock 547 178 315 minecraft:shroomlight
setblock 548 178 310 minecraft:shroomlight
setblock 548 178 312 minecraft:shroomlight
setblock 548 178 314 minecraft:shroomlight
setblock 548 178 316 minecraft:shroomlight
setblock 549 178 311 minecraft:shroomlight
setblock 549 178 313 minecraft:shroomlight
setblock 549 178 315 minecraft:shroomlight
setblock 550 178 310 minecraft:shroomlight
setblock 550 178 312 minecraft:shroomlight
setblock 550 178 314 minecraft:shroomlight
setblock 550 178 316 minecraft:shroomlight
setblock 551 178 275 minecraft:shroomlight
setblock 551 178 277 minecraft:shroomlight
setblock 551 178 279 minecraft:shroomlight
setblock 551 178 281 minecraft:shroomlight
setblock 551 178 283 minecraft:shroomlight
setblock 551 178 285 minecraft:shroomlight
setblock 551 178 311 minecraft:shroomlight
setblock 551 178 313 minecraft:shroomlight
setblock 551 178 315 minecraft:shroomlight
setblock 552 178 276 minecraft:shroomlight
setblock 552 178 278 minecraft:shroomlight
setblock 552 178 280 minecraft:shroomlight
setblock 552 178 282 minecraft:shroomlight
setblock 552 178 284 minecraft:shroomlight
setblock 552 178 286 minecraft:shroomlight
setblock 552 178 310 minecraft:shroomlight
setblock 552 178 312 minecraft:shroomlight
setblock 552 178 314 minecraft:shroomlight
setblock 552 178 316 minecraft:shroomlight
setblock 553 178 275 minecraft:shroomlight
setblock 553 178 277 minecraft:shroomlight
setblock 553 178 279 minecraft:shroomlight
setblock 553 178 281 minecraft:shroomlight
setblock 553 178 283 minecraft:shroomlight
setblock 553 178 285 minecraft:shroomlight
setblock 553 178 311 minecraft:shroomlight
setblock 553 178 313 minecraft:shroomlight
setblock 553 178 315 minecraft:shroomlight
setblock 554 178 276 minecraft:shroomlight
setblock 554 178 278 minecraft:shroomlight
setblock 554 178 280 minecraft:shroomlight
setblock 554 178 282 minecraft:shroomlight
setblock 554 178 284 minecraft:shroomlight
setblock 554 178 286 minecraft:shroomlight
setblock 554 178 310 minecraft:shroomlight
setblock 554 178 312 minecraft:shroomlight
setblock 554 178 314 minecraft:shroomlight
setblock 554 178 316 minecraft:shroomlight
setblock 555 178 275 minecraft:shroomlight
setblock 555 178 277 minecraft:shroomlight
setblock 555 178 279 minecraft:shroomlight
setblock 555 178 281 minecraft:shroomlight
setblock 555 178 283 minecraft:shroomlight
setblock 555 178 285 minecraft:shroomlight
setblock 555 178 311 minecraft:shroomlight
setblock 555 178 313 minecraft:shroomlight
setblock 555 178 315 minecraft:shroomlight
setblock 556 178 276 minecraft:shroomlight
setblock 556 178 278 minecraft:shroomlight
setblock 556 178 280 minecraft:shroomlight
setblock 556 178 282 minecraft:shroomlight
setblock 556 178 284 minecraft:shroomlight
setblock 556 178 286 minecraft:shroomlight
setblock 556 178 310 minecraft:shroomlight
setblock 556 178 312 minecraft:shroomlight
setblock 556 178 314 minecraft:shroomlight
setblock 556 178 316 minecraft:shroomlight
setblock 557 178 275 minecraft:shroomlight
setblock 557 178 277 minecraft:shroomlight
setblock 557 178 279 minecraft:shroomlight
setblock 557 178 281 minecraft:shroomlight
setblock 557 178 283 minecraft:shroomlight
setblock 557 178 285 minecraft:shroomlight
setblock 557 178 311 minecraft:shroomlight
setblock 557 178 313 minecraft:shroomlight
setblock 557 178 315 minecraft:shroomlight
setblock 558 178 276 minecraft:shroomlight
setblock 558 178 278 minecraft:shroomlight
setblock 558 178 280 minecraft:shroomlight
setblock 558 178 282 minecraft:shroomlight
setblock 558 178 284 minecraft:shroomlight
setblock 558 178 286 minecraft:shroomlight
setblock 558 178 310 minecraft:shroomlight
setblock 558 178 312 minecraft:shroomlight
setblock 558 178 314 minecraft:shroomlight
setblock 558 178 316 minecraft:shroomlight
setblock 520 179 278 minecraft:light[level=15]
fill 520 179 279 520 179 280 minecraft:brown_terracotta
setblock 520 179 286 minecraft:light[level=15]
fill 520 179 288 520 179 290 minecraft:brown_terracotta
setblock 520 179 294 minecraft:light[level=15]
setblock 520 179 302 minecraft:light[level=15]
setblock 520 179 310 minecraft:light[level=15]
fill 521 179 278 523 179 278 minecraft:brown_terracotta
setblock 521 179 286 minecraft:brown_terracotta
fill 523 179 293 525 179 293 minecraft:brown_terracotta
fill 524 179 279 524 179 280 minecraft:brown_terracotta
setblock 527 179 285 minecraft:brown_terracotta
setblock 527 179 292 minecraft:brown_terracotta
setblock 528 179 278 minecraft:light[level=15]
setblock 528 179 286 minecraft:brown_terracotta
setblock 528 179 291 minecraft:brown_terracotta
setblock 528 179 294 minecraft:light[level=15]
setblock 528 179 302 minecraft:light[level=15]
setblock 528 179 310 minecraft:light[level=15]
setblock 536 179 278 minecraft:light[level=15]
setblock 536 179 286 minecraft:light[level=15]
setblock 536 179 294 minecraft:light[level=15]
setblock 536 179 302 minecraft:light[level=15]
setblock 536 179 310 minecraft:light[level=15]
setblock 544 179 278 minecraft:light[level=15]
setblock 544 179 286 minecraft:light[level=15]
setblock 544 179 294 minecraft:light[level=15]
setblock 544 179 302 minecraft:light[level=15]
setblock 544 179 310 minecraft:light[level=15]
setblock 546 179 310 minecraft:white_concrete
setblock 546 179 312 minecraft:white_concrete
setblock 546 179 314 minecraft:white_concrete
setblock 546 179 316 minecraft:white_concrete
setblock 547 179 311 minecraft:white_concrete
setblock 547 179 313 minecraft:white_concrete
setblock 547 179 315 minecraft:white_concrete
setblock 548 179 310 minecraft:white_concrete
setblock 548 179 312 minecraft:white_concrete
setblock 548 179 314 minecraft:white_concrete
fill 548 179 316 548 218 316 minecraft:white_concrete
setblock 549 179 311 minecraft:white_concrete
setblock 549 179 313 minecraft:white_concrete
fill 549 179 315 549 185 315 minecraft:white_concrete
setblock 550 179 310 minecraft:white_concrete
setblock 550 179 312 minecraft:white_concrete
setblock 550 179 314 minecraft:white_concrete
fill 550 179 316 550 218 316 minecraft:white_concrete
setblock 551 179 275 minecraft:brown_terracotta
fill 551 179 277 551 180 277 minecraft:white_concrete
fill 551 179 279 551 180 279 minecraft:white_concrete
fill 551 179 281 551 180 281 minecraft:white_concrete
fill 551 179 283 551 180 283 minecraft:white_concrete
fill 551 179 285 551 180 285 minecraft:white_concrete
setblock 551 179 311 minecraft:white_concrete
setblock 551 179 313 minecraft:white_concrete
fill 551 179 315 551 185 315 minecraft:white_concrete
fill 552 179 276 552 180 276 minecraft:white_concrete
fill 552 179 278 552 180 278 minecraft:white_concrete
fill 552 179 280 552 180 280 minecraft:white_concrete
fill 552 179 282 552 180 282 minecraft:white_concrete
fill 552 179 284 552 180 284 minecraft:white_concrete
fill 552 179 286 552 180 286 minecraft:white_concrete
setblock 552 179 294 minecraft:light[level=15]
setblock 552 179 302 minecraft:light[level=15]
setblock 552 179 310 minecraft:white_concrete
setblock 552 179 312 minecraft:white_concrete
setblock 552 179 314 minecraft:white_concrete
setblock 552 179 316 minecraft:white_concrete
fill 553 179 275 553 180 275 minecraft:brown_terracotta
fill 553 179 277 553 180 277 minecraft:white_concrete
fill 553 179 279 553 180 279 minecraft:white_concrete
fill 553 179 281 553 180 281 minecraft:white_concrete
fill 553 179 283 553 180 283 minecraft:white_concrete
fill 553 179 285 553 180 285 minecraft:white_concrete
setblock 553 179 311 minecraft:white_concrete
setblock 553 179 313 minecraft:white_concrete
setblock 553 179 315 minecraft:white_concrete
fill 554 179 276 554 180 276 minecraft:white_concrete
fill 554 179 278 554 180 278 minecraft:white_concrete
fill 554 179 280 554 180 280 minecraft:white_concrete
fill 554 179 282 554 180 282 minecraft:white_concrete
fill 554 179 284 554 180 284 minecraft:white_concrete
fill 554 179 286 554 180 286 minecraft:white_concrete
setblock 554 179 310 minecraft:white_concrete
setblock 554 179 312 minecraft:white_concrete
setblock 554 179 314 minecraft:white_concrete
setblock 554 179 316 minecraft:white_concrete
setblock 555 179 275 minecraft:brown_terracotta
fill 555 179 277 555 180 277 minecraft:white_concrete
fill 555 179 279 555 180 279 minecraft:white_concrete
fill 555 179 281 555 180 281 minecraft:white_concrete
fill 555 179 283 555 180 283 minecraft:white_concrete
fill 555 179 285 555 180 285 minecraft:white_concrete
setblock 555 179 311 minecraft:white_concrete
setblock 555 179 313 minecraft:white_concrete
setblock 555 179 315 minecraft:white_concrete
fill 556 179 276 556 180 276 minecraft:white_concrete
fill 556 179 278 556 180 278 minecraft:white_concrete
fill 556 179 280 556 180 280 minecraft:white_concrete
fill 556 179 282 556 180 282 minecraft:white_concrete
fill 556 179 284 556 180 284 minecraft:white_concrete
fill 556 179 286 556 180 286 minecraft:white_concrete
setblock 556 179 310 minecraft:white_concrete
setblock 556 179 312 minecraft:white_concrete
setblock 556 179 314 minecraft:white_concrete
setblock 556 179 316 minecraft:white_concrete
fill 557 179 275 557 180 275 minecraft:brown_terracotta
fill 557 179 277 557 180 277 minecraft:white_concrete
fill 557 179 279 557 180 279 minecraft:white_concrete
fill 557 179 281 557 180 281 minecraft:white_concrete
fill 557 179 283 557 180 283 minecraft:white_concrete
fill 557 179 285 557 180 285 minecraft:white_concrete
fill 557 179 311 557 185 311 minecraft:white_concrete
setblock 557 179 313 minecraft:white_concrete
setblock 557 179 315 minecraft:white_concrete
fill 558 179 276 558 180 276 minecraft:white_concrete
fill 558 179 278 558 180 278 minecraft:white_concrete
fill 558 179 280 558 180 280 minecraft:white_concrete
fill 558 179 282 558 180 282 minecraft:white_concrete
fill 558 179 284 558 180 284 minecraft:white_concrete
fill 558 179 286 558 180 286 minecraft:white_concrete
fill 558 179 310 558 218 310 minecraft:white_concrete
setblock 558 179 312 minecraft:white_concrete
setblock 558 179 314 minecraft:white_concrete
setblock 558 179 316 minecraft:white_concrete
setblock 517 180 277 minecraft:white_concrete
setblock 517 180 281 minecraft:white_concrete
setblock 517 180 285 minecraft:white_concrete
setblock 517 180 289 minecraft:white_concrete
setblock 517 180 293 minecraft:white_concrete
setblock 517 180 297 minecraft:white_concrete
setblock 517 180 301 minecraft:white_concrete
setblock 517 180 305 minecraft:white_concrete
setblock 517 180 309 minecraft:white_concrete
setblock 517 180 313 minecraft:white_concrete
setblock 517 180 317 minecraft:white_concrete
setblock 518 180 317 minecraft:brown_terracotta
setblock 519 180 275 minecraft:white_concrete
fill 519 180 285 519 185 287 minecraft:white_concrete
fill 519 180 297 519 185 299 minecraft:white_concrete
fill 519 180 309 519 185 311 minecraft:white_concrete
setblock 519 180 317 minecraft:white_concrete
fill 520 180 281 524 180 285 minecraft:white_concrete
setblock 520 180 317 minecraft:brown_terracotta
setblock 523 180 275 minecraft:white_concrete
setblock 523 180 317 minecraft:white_concrete
fill 524 180 289 524 182 289 minecraft:white_concrete
fill 525 180 315 527 185 315 minecraft:white_concrete
setblock 527 180 275 minecraft:white_concrete
setblock 527 180 317 minecraft:white_concrete
fill 529 180 277 531 185 277 minecraft:white_concrete
setblock 530 180 317 minecraft:brown_terracotta
setblock 531 180 275 minecraft:white_concrete
setblock 531 180 317 minecraft:white_concrete
setblock 532 180 317 minecraft:brown_terracotta
setblock 535 180 275 minecraft:white_concrete
setblock 535 180 317 minecraft:white_concrete
fill 537 180 315 539 185 315 minecraft:white_concrete
setblock 539 180 275 minecraft:white_concrete
setblock 539 180 317 minecraft:white_concrete
fill 541 180 277 543 185 277 minecraft:white_concrete
setblock 542 180 317 minecraft:brown_terracotta
setblock 543 180 275 minecraft:white_concrete
setblock 543 180 317 minecraft:white_concrete
setblock 544 180 317 minecraft:brown_terracotta
setblock 547 180 275 minecraft:white_concrete
fill 547 180 311 548 180 315 minecraft:red_concrete
setblock 547 180 317 minecraft:white_concrete
fill 549 180 311 556 180 314 minecraft:red_concrete
setblock 551 180 275 minecraft:white_concrete
setblock 551 180 317 minecraft:white_concrete
fill 552 180 315 557 180 315 minecraft:red_concrete
setblock 554 180 317 minecraft:brown_terracotta
setblock 555 180 275 minecraft:white_concrete
setblock 555 180 317 minecraft:white_concrete
setblock 556 180 317 minecraft:brown_terracotta
fill 557 180 287 557 185 287 minecraft:white_concrete
fill 557 180 297 557 185 299 minecraft:white_concrete
fill 557 180 309 557 185 309 minecraft:white_concrete
fill 557 180 312 557 180 314 minecraft:red_concrete
setblock 559 180 275 minecraft:white_concrete
setblock 559 180 276 minecraft:brown_terracotta
setblock 559 180 277 minecraft:white_concrete
setblock 559 180 278 minecraft:brown_terracotta
setblock 559 180 281 minecraft:white_concrete
setblock 559 180 285 minecraft:white_concrete
setblock 559 180 288 minecraft:brown_terracotta
setblock 559 180 289 minecraft:white_concrete
setblock 559 180 290 minecraft:brown_terracotta
setblock 559 180 293 minecraft:white_concrete
setblock 559 180 297 minecraft:white_concrete
setblock 559 180 300 minecraft:brown_terracotta
setblock 559 180 301 minecraft:white_concrete
setblock 559 180 302 minecraft:brown_terracotta
setblock 559 180 305 minecraft:white_concrete
setblock 559 180 309 minecraft:white_concrete
setblock 559 180 312 minecraft:brown_terracotta
setblock 559 180 313 minecraft:white_concrete
setblock 559 180 314 minecraft:brown_terracotta
setblock 559 180 317 minecraft:white_concrete
setblock 517 181 276 minecraft:white_concrete
fill 517 181 277 517 188 277 minecraft:brown_terracotta
setblock 517 181 278 minecraft:white_concrete
setblock 517 181 280 minecraft:white_concrete
fill 517 181 281 517 185 281 minecraft:brown_terracotta
setblock 517 181 282 minecraft:white_concrete
setblock 517 181 284 minecraft:white_concrete
fill 517 181 285 517 188 285 minecraft:brown_terracotta
setblock 517 181 286 minecraft:white_concrete
setblock 517 181 288 minecraft:white_concrete
fill 517 181 289 517 188 289 minecraft:brown_terracotta
setblock 517 181 290 minecraft:white_concrete
setblock 517 181 292 minecraft:white_concrete
fill 517 181 293 517 185 293 minecraft:brown_terracotta
setblock 517 181 294 minecraft:white_concrete
setblock 517 181 296 minecraft:white_concrete
fill 517 181 297 517 188 297 minecraft:brown_terracotta
setblock 517 181 298 minecraft:white_concrete
setblock 517 181 300 minecraft:white_concrete
fill 517 181 301 517 188 301 minecraft:brown_terracotta
setblock 517 181 302 minecraft:white_concrete
setblock 517 181 304 minecraft:white_concrete
fill 517 181 305 517 185 305 minecraft:brown_terracotta
setblock 517 181 306 minecraft:white_concrete
setblock 517 181 308 minecraft:white_concrete
fill 517 181 309 517 188 309 minecraft:brown_terracotta
setblock 517 181 310 minecraft:white_concrete
setblock 517 181 312 minecraft:white_concrete
fill 517 181 313 517 188 313 minecraft:brown_terracotta
setblock 517 181 314 minecraft:white_concrete
setblock 517 181 316 minecraft:white_concrete
setblock 517 181 317 minecraft:brown_terracotta
setblock 518 181 275 minecraft:white_concrete
setblock 518 181 317 minecraft:white_concrete
fill 519 181 275 519 188 275 minecraft:brown_terracotta
fill 519 181 317 519 185 317 minecraft:brown_terracotta
setblock 520 181 275 minecraft:white_concrete
setblock 520 181 317 minecraft:white_concrete
fill 521 181 281 523 181 285 minecraft:white_concrete
setblock 522 181 275 minecraft:white_concrete
setblock 522 181 317 minecraft:white_concrete
fill 523 181 275 523 188 275 minecraft:brown_terracotta
fill 523 181 317 523 188 317 minecraft:brown_terracotta
setblock 524 181 275 minecraft:white_concrete
setblock 524 181 317 minecraft:white_concrete
setblock 526 181 275 minecraft:white_concrete
setblock 526 181 317 minecraft:white_concrete
fill 527 181 275 527 185 275 minecraft:brown_terracotta
fill 527 181 317 527 188 317 minecraft:brown_terracotta
setblock 528 181 275 minecraft:white_concrete
setblock 528 181 317 minecraft:white_concrete
setblock 530 181 275 minecraft:white_concrete
setblock 530 181 317 minecraft:white_concrete
fill 531 181 275 531 188 275 minecraft:brown_terracotta
fill 531 181 317 531 185 317 minecraft:brown_terracotta
setblock 532 181 275 minecraft:white_concrete
setblock 532 181 317 minecraft:white_concrete
setblock 534 181 275 minecraft:white_concrete
setblock 534 181 317 minecraft:white_concrete
fill 535 181 275 535 188 275 minecraft:brown_terracotta
fill 535 181 317 535 188 317 minecraft:brown_terracotta
setblock 536 181 275 minecraft:white_concrete
setblock 536 181 317 minecraft:white_concrete
setblock 538 181 275 minecraft:white_concrete
setblock 538 181 317 minecraft:white_concrete
fill 539 181 275 539 185 275 minecraft:brown_terracotta
fill 539 181 317 539 188 317 minecraft:brown_terracotta
setblock 540 181 275 minecraft:white_concrete
setblock 540 181 317 minecraft:white_concrete
setblock 542 181 275 minecraft:white_concrete
setblock 542 181 317 minecraft:white_concrete
fill 543 181 275 543 188 275 minecraft:brown_terracotta
fill 543 181 317 543 185 317 minecraft:brown_terracotta
setblock 544 181 275 minecraft:white_concrete
setblock 544 181 317 minecraft:white_concrete
setblock 546 181 275 minecraft:white_concrete
setblock 546 181 317 minecraft:white_concrete
fill 547 181 275 547 188 275 minecraft:brown_terracotta
fill 547 181 317 547 188 317 minecraft:brown_terracotta
setblock 548 181 275 minecraft:white_concrete
fill 548 181 312 556 181 314 minecraft:red_concrete
setblock 548 181 317 minecraft:white_concrete
setblock 550 181 275 minecraft:white_concrete
setblock 550 181 317 minecraft:white_concrete
setblock 551 181 275 minecraft:shroomlight
setblock 551 181 277 minecraft:shroomlight
setblock 551 181 279 minecraft:shroomlight
setblock 551 181 281 minecraft:shroomlight
setblock 551 181 283 minecraft:shroomlight
setblock 551 181 285 minecraft:shroomlight
fill 551 181 317 551 188 317 minecraft:brown_terracotta
setblock 552 181 275 minecraft:white_concrete
setblock 552 181 276 minecraft:shroomlight
setblock 552 181 278 minecraft:shroomlight
setblock 552 181 280 minecraft:shroomlight
setblock 552 181 282 minecraft:shroomlight
setblock 552 181 284 minecraft:shroomlight
setblock 552 181 286 minecraft:shroomlight
setblock 552 181 317 minecraft:white_concrete
setblock 553 181 275 minecraft:shroomlight
setblock 553 181 277 minecraft:shroomlight
setblock 553 181 279 minecraft:shroomlight
setblock 553 181 281 minecraft:shroomlight
setblock 553 181 283 minecraft:shroomlight
setblock 553 181 285 minecraft:shroomlight
setblock 554 181 275 minecraft:white_concrete
setblock 554 181 276 minecraft:shroomlight
setblock 554 181 278 minecraft:shroomlight
setblock 554 181 280 minecraft:shroomlight
setblock 554 181 282 minecraft:shroomlight
setblock 554 181 284 minecraft:shroomlight
setblock 554 181 286 minecraft:shroomlight
setblock 554 181 317 minecraft:white_concrete
setblock 555 181 275 minecraft:shroomlight
setblock 555 181 277 minecraft:shroomlight
setblock 555 181 279 minecraft:shroomlight
setblock 555 181 281 minecraft:shroomlight
setblock 555 181 283 minecraft:shroomlight
setblock 555 181 285 minecraft:shroomlight
fill 555 181 317 555 185 317 minecraft:brown_terracotta
setblock 556 181 275 minecraft:white_concrete
setblock 556 181 276 minecraft:shroomlight
setblock 556 181 278 minecraft:shroomlight
setblock 556 181 280 minecraft:shroomlight
setblock 556 181 282 minecraft:shroomlight
setblock 556 181 284 minecraft:shroomlight
setblock 556 181 286 minecraft:shroomlight
setblock 556 181 317 minecraft:white_concrete
setblock 557 181 275 minecraft:shroomlight
setblock 557 181 277 minecraft:shroomlight
setblock 557 181 279 minecraft:shroomlight
setblock 557 181 281 minecraft:shroomlight
setblock 557 181 283 minecraft:shroomlight
setblock 557 181 285 minecraft:shroomlight
setblock 558 181 275 minecraft:white_concrete
setblock 558 181 276 minecraft:shroomlight
setblock 558 181 278 minecraft:shroomlight
setblock 558 181 280 minecraft:shroomlight
setblock 558 181 282 minecraft:shroomlight
setblock 558 181 284 minecraft:shroomlight
setblock 558 181 286 minecraft:shroomlight
setblock 558 181 317 minecraft:white_concrete
setblock 559 181 275 minecraft:brown_terracotta
setblock 559 181 276 minecraft:white_concrete
fill 559 181 277 559 185 277 minecraft:brown_terracotta
setblock 559 181 278 minecraft:white_concrete
setblock 559 181 280 minecraft:white_concrete
fill 559 181 281 559 188 281 minecraft:brown_terracotta
setblock 559 181 282 minecraft:white_concrete
setblock 559 181 284 minecraft:white_concrete
fill 559 181 285 559 188 285 minecraft:brown_terracotta
setblock 559 181 286 minecraft:white_concrete
setblock 559 181 288 minecraft:white_concrete
fill 559 181 289 559 185 289 minecraft:brown_terracotta
setblock 559 181 290 minecraft:white_concrete
setblock 559 181 292 minecraft:white_concrete
fill 559 181 293 559 188 293 minecraft:brown_terracotta
setblock 559 181 294 minecraft:white_concrete
setblock 559 181 296 minecraft:white_concrete
fill 559 181 297 559 188 297 minecraft:brown_terracotta
setblock 559 181 298 minecraft:white_concrete
setblock 559 181 300 minecraft:white_concrete
fill 559 181 301 559 185 301 minecraft:brown_terracotta
setblock 559 181 302 minecraft:white_concrete
setblock 559 181 304 minecraft:white_concrete
fill 559 181 305 559 188 305 minecraft:brown_terracotta
setblock 559 181 306 minecraft:white_concrete
setblock 559 181 308 minecraft:white_concrete
fill 559 181 309 559 188 309 minecraft:brown_terracotta
setblock 559 181 310 minecraft:white_concrete
setblock 559 181 312 minecraft:white_concrete
fill 559 181 313 559 185 313 minecraft:brown_terracotta
setblock 559 181 314 minecraft:white_concrete
setblock 559 181 316 minecraft:white_concrete
fill 559 181 317 559 188 317 minecraft:brown_terracotta
setblock 517 182 275 minecraft:white_concrete
fill 517 182 276 517 189 276 minecraft:brown_terracotta
fill 517 182 278 517 189 278 minecraft:brown_terracotta
setblock 517 182 279 minecraft:white_concrete
fill 517 182 280 517 189 280 minecraft:brown_terracotta
fill 517 182 282 517 185 282 minecraft:brown_terracotta
setblock 517 182 283 minecraft:white_concrete
fill 517 182 284 517 185 284 minecraft:brown_terracotta
fill 517 182 286 517 189 286 minecraft:brown_terracotta
setblock 517 182 287 minecraft:white_concrete
fill 517 182 288 517 189 288 minecraft:brown_terracotta
fill 517 182 290 517 189 290 minecraft:brown_terracotta
setblock 517 182 291 minecraft:white_concrete
fill 517 182 292 517 189 292 minecraft:brown_terracotta
fill 517 182 294 517 185 294 minecraft:brown_terracotta
setblock 517 182 295 minecraft:white_concrete
fill 517 182 296 517 185 296 minecraft:brown_terracotta
fill 517 182 298 517 189 298 minecraft:brown_terracotta
setblock 517 182 299 minecraft:white_concrete
fill 517 182 300 517 189 300 minecraft:brown_terracotta
fill 517 182 302 517 189 302 minecraft:brown_terracotta
setblock 517 182 303 minecraft:white_concrete
fill 517 182 304 517 189 304 minecraft:brown_terracotta
fill 517 182 306 517 185 306 minecraft:brown_terracotta
setblock 517 182 307 minecraft:white_concrete
fill 517 182 308 517 185 308 minecraft:brown_terracotta
fill 517 182 310 517 189 310 minecraft:brown_terracotta
setblock 517 182 311 minecraft:white_concrete
fill 517 182 312 517 189 312 minecraft:brown_terracotta
fill 517 182 314 517 189 314 minecraft:brown_terracotta
setblock 517 182 315 minecraft:white_concrete
fill 517 182 316 517 189 316 minecraft:brown_terracotta
setblock 517 182 317 minecraft:white_concrete
fill 518 182 275 518 189 275 minecraft:brown_terracotta
fill 518 182 317 518 185 317 minecraft:brown_terracotta
fill 520 182 275 520 189 275 minecraft:brown_terracotta
fill 520 182 317 520 185 317 minecraft:brown_terracotta
setblock 521 182 275 minecraft:white_concrete
fill 521 182 281 523 218 281 minecraft:white_concrete
setblock 521 182 317 minecraft:white_concrete
fill 522 182 275 522 189 275 minecraft:brown_terracotta
fill 522 182 282 522 182 285 minecraft:white_concrete
fill 522 182 317 522 189 317 minecraft:brown_terracotta
fill 524 182 275 524 185 275 minecraft:brown_terracotta
fill 524 182 317 524 189 317 minecraft:brown_terracotta
setblock 525 182 275 minecraft:white_concrete
setblock 525 182 317 minecraft:white_concrete
fill 526 182 275 526 185 275 minecraft:brown_terracotta
fill 526 182 317 526 189 317 minecraft:brown_terracotta
fill 528 182 275 528 189 275 minecraft:brown_terracotta
fill 528 182 317 528 189 317 minecraft:brown_terracotta
setblock 529 182 275 minecraft:white_concrete
setblock 529 182 317 minecraft:white_concrete
fill 530 182 275 530 189 275 minecraft:brown_terracotta
fill 530 182 317 530 185 317 minecraft:brown_terracotta
fill 532 182 275 532 189 275 minecraft:brown_terracotta
fill 532 182 317 532 185 317 minecraft:brown_terracotta
setblock 533 182 275 minecraft:white_concrete
setblock 533 182 317 minecraft:white_concrete
fill 534 182 275 534 189 275 minecraft:brown_terracotta
fill 534 182 317 534 189 317 minecraft:brown_terracotta
fill 536 182 275 536 185 275 minecraft:brown_terracotta
fill 536 182 317 536 189 317 minecraft:brown_terracotta
setblock 537 182 275 minecraft:white_concrete
setblock 537 182 317 minecraft:white_concrete
fill 538 182 275 538 185 275 minecraft:brown_terracotta
fill 538 182 317 538 189 317 minecraft:brown_terracotta
fill 540 182 275 540 189 275 minecraft:brown_terracotta
fill 540 182 317 540 189 317 minecraft:brown_terracotta
setblock 541 182 275 minecraft:white_concrete
setblock 541 182 317 minecraft:white_concrete
fill 542 182 275 542 189 275 minecraft:brown_terracotta
fill 542 182 317 542 185 317 minecraft:brown_terracotta
fill 544 182 275 544 189 275 minecraft:brown_terracotta
fill 544 182 317 544 185 317 minecraft:brown_terracotta
setblock 545 182 275 minecraft:white_concrete
setblock 545 182 317 minecraft:white_concrete
fill 546 182 275 546 189 275 minecraft:brown_terracotta
fill 546 182 317 546 189 317 minecraft:brown_terracotta
fill 548 182 275 548 185 275 minecraft:brown_terracotta
fill 548 182 317 548 189 317 minecraft:brown_terracotta
setblock 549 182 275 minecraft:white_concrete
fill 549 182 313 555 182 313 minecraft:red_concrete
setblock 549 182 317 minecraft:white_concrete
fill 550 182 275 552 183 275 minecraft:brown_terracotta
fill 550 182 317 550 189 317 minecraft:brown_terracotta
fill 551 182 277 551 183 277 minecraft:white_concrete
fill 551 182 279 551 183 279 minecraft:white_concrete
fill 551 182 281 551 183 281 minecraft:white_concrete
fill 551 182 283 551 183 283 minecraft:white_concrete
fill 551 182 285 551 183 285 minecraft:white_concrete
fill 552 182 276 552 183 276 minecraft:white_concrete
fill 552 182 278 552 183 278 minecraft:white_concrete
fill 552 182 280 552 183 280 minecraft:white_concrete
fill 552 182 282 552 183 282 minecraft:white_concrete
fill 552 182 284 552 183 284 minecraft:white_concrete
fill 552 182 286 552 183 286 minecraft:white_concrete
fill 552 182 317 552 189 317 minecraft:brown_terracotta
setblock 553 182 275 minecraft:white_concrete
fill 553 182 277 553 183 277 minecraft:white_concrete
fill 553 182 279 553 183 279 minecraft:white_concrete
fill 553 182 281 553 183 281 minecraft:white_concrete
fill 553 182 283 553 183 283 minecraft:white_concrete
fill 553 182 285 553 183 285 minecraft:white_concrete
setblock 553 182 317 minecraft:white_concrete
fill 554 182 275 556 183 275 minecraft:brown_terracotta
fill 554 182 276 554 183 276 minecraft:white_concrete
fill 554 182 278 554 183 278 minecraft:white_concrete
fill 554 182 280 554 183 280 minecraft:white_concrete
fill 554 182 282 554 183 282 minecraft:white_concrete
fill 554 182 284 554 183 284 minecraft:white_concrete
fill 554 182 286 554 183 286 minecraft:white_concrete
fill 554 182 317 554 185 317 minecraft:brown_terracotta
fill 555 182 277 555 183 277 minecraft:white_concrete
fill 555 182 279 555 183 279 minecraft:white_concrete
fill 555 182 281 555 183 281 minecraft:white_concrete
fill 555 182 283 555 183 283 minecraft:white_concrete
fill 555 182 285 555 183 285 minecraft:white_concrete
fill 556 182 276 556 183 276 minecraft:white_concrete
fill 556 182 278 556 183 278 minecraft:white_concrete
fill 556 182 280 556 183 280 minecraft:white_concrete
fill 556 182 282 556 183 282 minecraft:white_concrete
fill 556 182 284 556 183 284 minecraft:white_concrete
fill 556 182 286 556 183 286 minecraft:white_concrete
fill 556 182 317 556 185 317 minecraft:brown_terracotta
setblock 557 182 275 minecraft:white_concrete
fill 557 182 277 557 183 277 minecraft:white_concrete
fill 557 182 279 557 183 279 minecraft:white_concrete
fill 557 182 281 557 183 281 minecraft:white_concrete
fill 557 182 283 557 183 283 minecraft:white_concrete
fill 557 182 285 557 183 285 minecraft:white_concrete
setblock 557 182 317 minecraft:white_concrete
fill 558 182 275 558 189 275 minecraft:brown_terracotta
fill 558 182 276 558 183 276 minecraft:white_concrete
fill 558 182 278 558 183 278 minecraft:white_concrete
fill 558 182 280 558 183 280 minecraft:white_concrete
fill 558 182 282 558 183 282 minecraft:white_concrete
fill 558 182 284 558 183 284 minecraft:white_concrete
fill 558 182 286 558 183 286 minecraft:white_concrete
fill 558 182 317 558 189 317 minecraft:brown_terracotta
setblock 559 182 275 minecraft:white_concrete
fill 559 182 276 559 185 276 minecraft:brown_terracotta
fill 559 182 278 559 185 278 minecraft:brown_terracotta
setblock 559 182 279 minecraft:white_concrete
fill 559 182 280 559 189 280 minecraft:brown_terracotta
fill 559 182 282 559 189 282 minecraft:brown_terracotta
setblock 559 182 283 minecraft:white_concrete
fill 559 182 284 559 189 284 minecraft:brown_terracotta
fill 559 182 286 559 189 286 minecraft:brown_terracotta
setblock 559 182 287 minecraft:white_concrete
fill 559 182 288 559 185 288 minecraft:brown_terracotta
fill 559 182 290 559 185 290 minecraft:brown_terracotta
setblock 559 182 291 minecraft:white_concrete
fill 559 182 292 559 189 292 minecraft:brown_terracotta
fill 559 182 294 559 189 294 minecraft:brown_terracotta
setblock 559 182 295 minecraft:white_concrete
fill 559 182 296 559 189 296 minecraft:brown_terracotta
fill 559 182 298 559 189 298 minecraft:brown_terracotta
setblock 559 182 299 minecraft:white_concrete
fill 559 182 300 559 185 300 minecraft:brown_terracotta
fill 559 182 302 559 185 302 minecraft:brown_terracotta
setblock 559 182 303 minecraft:white_concrete
fill 559 182 304 559 189 304 minecraft:brown_terracotta
fill 559 182 306 559 189 306 minecraft:brown_terracotta
setblock 559 182 307 minecraft:white_concrete
fill 559 182 308 559 189 308 minecraft:brown_terracotta
fill 559 182 310 559 189 310 minecraft:brown_terracotta
setblock 559 182 311 minecraft:white_concrete
fill 559 182 312 559 185 312 minecraft:brown_terracotta
fill 559 182 314 559 185 314 minecraft:brown_terracotta
setblock 559 182 315 minecraft:white_concrete
fill 559 182 316 559 189 316 minecraft:brown_terracotta
fill 517 183 275 517 190 275 minecraft:brown_terracotta
fill 517 183 279 517 190 279 minecraft:brown_terracotta
fill 517 183 283 517 185 283 minecraft:brown_terracotta
fill 517 183 287 517 190 287 minecraft:brown_terracotta
fill 517 183 291 517 190 291 minecraft:brown_terracotta
fill 517 183 295 517 185 295 minecraft:brown_terracotta
fill 517 183 299 517 190 299 minecraft:brown_terracotta
fill 517 183 303 517 190 303 minecraft:brown_terracotta
fill 517 183 307 517 185 307 minecraft:brown_terracotta
fill 517 183 311 517 190 311 minecraft:brown_terracotta
fill 517 183 315 517 190 315 minecraft:brown_terracotta
fill 517 183 317 517 185 317 minecraft:brown_terracotta
setblock 520 183 278 minecraft:light[level=12]
setblock 520 183 285 minecraft:light[level=12]
setblock 520 183 292 minecraft:light[level=12]
setblock 520 183 299 minecraft:light[level=12]
setblock 520 183 306 minecraft:light[level=12]
setblock 520 183 313 minecraft:light[level=12]
fill 521 183 275 521 190 275 minecraft:brown_terracotta
fill 521 183 317 521 190 317 minecraft:brown_terracotta
fill 522 183 282 522 218 282 minecraft:white_concrete
fill 523 183 288 525 185 290 minecraft:spruce_leaves[persistent=true]
fill 524 183 287 525 185 287 minecraft:spruce_leaves[persistent=true]
fill 525 183 275 525 185 275 minecraft:brown_terracotta
fill 525 183 317 525 190 317 minecraft:brown_terracotta
fill 526 183 288 526 185 289 minecraft:spruce_leaves[persistent=true]
setblock 527 183 278 minecraft:light[level=12]
setblock 527 183 285 minecraft:light[level=12]
setblock 527 183 292 minecraft:light[level=12]
setblock 527 183 299 minecraft:light[level=12]
setblock 527 183 306 minecraft:light[level=12]
setblock 527 183 313 minecraft:light[level=12]
fill 529 183 275 529 190 275 minecraft:brown_terracotta
fill 529 183 317 529 185 317 minecraft:brown_terracotta
fill 533 183 275 533 190 275 minecraft:brown_terracotta
fill 533 183 317 533 190 317 minecraft:brown_terracotta
setblock 534 183 278 minecraft:light[level=12]
setblock 534 183 285 minecraft:light[level=12]
setblock 534 183 292 minecraft:light[level=12]
setblock 534 183 299 minecraft:light[level=12]
setblock 534 183 306 minecraft:light[level=12]
setblock 534 183 313 minecraft:light[level=12]
fill 537 183 275 537 185 275 minecraft:brown_terracotta
fill 537 183 317 537 190 317 minecraft:brown_terracotta
fill 541 183 275 541 190 275 minecraft:brown_terracotta
setblock 541 183 278 minecraft:light[level=12]
setblock 541 183 285 minecraft:light[level=12]
setblock 541 183 292 minecraft:light[level=12]
setblock 541 183 299 minecraft:light[level=12]
setblock 541 183 306 minecraft:light[level=12]
setblock 541 183 313 minecraft:light[level=12]
fill 541 183 317 541 185 317 minecraft:brown_terracotta
fill 545 183 275 545 190 275 minecraft:brown_terracotta
fill 545 183 317 545 190 317 minecraft:brown_terracotta
setblock 548 183 278 minecraft:light[level=12]
setblock 548 183 285 minecraft:light[level=12]
setblock 548 183 292 minecraft:light[level=12]
setblock 548 183 299 minecraft:light[level=12]
setblock 548 183 306 minecraft:light[level=12]
setblock 548 183 313 minecraft:light[level=12]
fill 549 183 275 549 185 275 minecraft:brown_terracotta
fill 549 183 317 549 190 317 minecraft:brown_terracotta
fill 550 183 312 554 183 314 minecraft:red_concrete
setblock 553 183 275 minecraft:brown_terracotta
fill 553 183 317 553 185 317 minecraft:brown_terracotta
setblock 555 183 292 minecraft:light[level=12]
setblock 555 183 299 minecraft:light[level=12]
setblock 555 183 306 minecraft:light[level=12]
setblock 555 183 313 minecraft:light[level=12]
setblock 557 183 275 minecraft:brown_terracotta
fill 557 183 317 557 190 317 minecraft:brown_terracotta
fill 559 183 275 559 188 275 minecraft:brown_terracotta
fill 559 183 279 559 185 279 minecraft:brown_terracotta
fill 559 183 283 559 190 283 minecraft:brown_terracotta
fill 559 183 287 559 190 287 minecraft:brown_terracotta
fill 559 183 291 559 185 291 minecraft:brown_terracotta
fill 559 183 295 559 190 295 minecraft:brown_terracotta
fill 559 183 299 559 190 299 minecraft:brown_terracotta
fill 559 183 303 559 185 303 minecraft:brown_terracotta
fill 559 183 307 559 190 307 minecraft:brown_terracotta
fill 559 183 311 559 190 311 minecraft:brown_terracotta
fill 559 183 315 559 185 315 minecraft:brown_terracotta
fill 522 184 288 522 184 289 minecraft:spruce_leaves[persistent=true]
setblock 523 184 287 minecraft:spruce_leaves[persistent=true]
setblock 524 184 291 minecraft:spruce_leaves[persistent=true]
setblock 526 184 287 minecraft:spruce_leaves[persistent=true]
setblock 526 184 290 minecraft:spruce_leaves[persistent=true]
fill 550 184 275 550 185 275 minecraft:brown_terracotta
setblock 551 184 275 minecraft:shroomlight
setblock 551 184 277 minecraft:shroomlight
setblock 551 184 279 minecraft:shroomlight
setblock 551 184 281 minecraft:shroomlight
setblock 551 184 283 minecraft:shroomlight
setblock 551 184 285 minecraft:shroomlight
fill 552 184 275 552 189 275 minecraft:brown_terracotta
setblock 552 184 276 minecraft:shroomlight
setblock 552 184 278 minecraft:shroomlight
setblock 552 184 280 minecraft:shroomlight
setblock 552 184 282 minecraft:shroomlight
setblock 552 184 284 minecraft:shroomlight
setblock 552 184 286 minecraft:shroomlight
setblock 553 184 275 minecraft:shroomlight
setblock 553 184 277 minecraft:shroomlight
setblock 553 184 279 minecraft:shroomlight
setblock 553 184 281 minecraft:shroomlight
setblock 553 184 283 minecraft:shroomlight
setblock 553 184 285 minecraft:shroomlight
fill 554 184 275 554 189 275 minecraft:brown_terracotta
setblock 554 184 276 minecraft:shroomlight
setblock 554 184 278 minecraft:shroomlight
setblock 554 184 280 minecraft:shroomlight
setblock 554 184 282 minecraft:shroomlight
setblock 554 184 284 minecraft:shroomlight
setblock 554 184 286 minecraft:shroomlight
setblock 555 184 275 minecraft:shroomlight
setblock 555 184 277 minecraft:shroomlight
setblock 555 184 279 minecraft:shroomlight
setblock 555 184 281 minecraft:shroomlight
setblock 555 184 283 minecraft:shroomlight
setblock 555 184 285 minecraft:shroomlight
fill 556 184 275 556 189 275 minecraft:brown_terracotta
setblock 556 184 276 minecraft:shroomlight
setblock 556 184 278 minecraft:shroomlight
setblock 556 184 280 minecraft:shroomlight
setblock 556 184 282 minecraft:shroomlight
setblock 556 184 284 minecraft:shroomlight
setblock 556 184 286 minecraft:shroomlight
setblock 557 184 275 minecraft:shroomlight
setblock 557 184 277 minecraft:shroomlight
setblock 557 184 279 minecraft:shroomlight
setblock 557 184 281 minecraft:shroomlight
setblock 557 184 283 minecraft:shroomlight
setblock 557 184 285 minecraft:shroomlight
setblock 558 184 276 minecraft:shroomlight
setblock 558 184 278 minecraft:shroomlight
setblock 558 184 280 minecraft:shroomlight
setblock 558 184 282 minecraft:shroomlight
setblock 558 184 284 minecraft:shroomlight
setblock 558 184 286 minecraft:shroomlight
fill 518 185 279 518 185 284 minecraft:brown_terracotta
fill 518 185 291 518 185 296 minecraft:brown_terracotta
fill 518 185 303 518 185 308 minecraft:brown_terracotta
fill 518 185 315 518 185 316 minecraft:brown_terracotta
fill 519 185 316 522 185 316 minecraft:brown_terracotta
fill 522 185 276 527 185 276 minecraft:brown_terracotta
fill 529 185 316 534 185 316 minecraft:brown_terracotta
fill 534 185 276 539 185 276 minecraft:brown_terracotta
fill 541 185 316 546 185 316 minecraft:brown_terracotta
fill 546 185 276 551 185 276 minecraft:brown_terracotta
setblock 551 185 275 minecraft:brown_terracotta
fill 551 185 277 551 186 277 minecraft:white_concrete
fill 551 185 279 551 186 279 minecraft:white_concrete
fill 551 185 281 551 186 281 minecraft:white_concrete
fill 551 185 283 551 186 283 minecraft:white_concrete
fill 551 185 285 551 186 285 minecraft:white_concrete
fill 552 185 276 552 186 276 minecraft:white_concrete
fill 552 185 278 552 186 278 minecraft:white_concrete
fill 552 185 280 552 186 280 minecraft:white_concrete
fill 552 185 282 552 186 282 minecraft:white_concrete
fill 552 185 284 552 186 284 minecraft:white_concrete
fill 552 185 286 552 186 286 minecraft:white_concrete
fill 553 185 275 553 186 275 minecraft:brown_terracotta
fill 553 185 277 553 186 277 minecraft:white_concrete
fill 553 185 279 553 186 279 minecraft:white_concrete
fill 553 185 281 553 186 281 minecraft:white_concrete
fill 553 185 283 553 186 283 minecraft:white_concrete
fill 553 185 285 553 186 285 minecraft:white_concrete
fill 553 185 316 558 185 316 minecraft:brown_terracotta
fill 554 185 276 554 186 276 minecraft:white_concrete
fill 554 185 278 554 186 278 minecraft:white_concrete
fill 554 185 280 554 186 280 minecraft:white_concrete
fill 554 185 282 554 186 282 minecraft:white_concrete
fill 554 185 284 554 186 284 minecraft:white_concrete
fill 554 185 286 554 186 286 minecraft:white_concrete
fill 555 185 275 555 186 275 minecraft:brown_terracotta
fill 555 185 277 555 186 277 minecraft:white_concrete
fill 555 185 279 555 186 279 minecraft:white_concrete
fill 555 185 281 555 186 281 minecraft:white_concrete
fill 555 185 283 555 186 283 minecraft:white_concrete
fill 555 185 285 555 186 285 minecraft:white_concrete
fill 556 185 276 556 186 276 minecraft:white_concrete
fill 556 185 278 556 186 278 minecraft:white_concrete
fill 556 185 280 556 186 280 minecraft:white_concrete
fill 556 185 282 556 186 282 minecraft:white_concrete
fill 556 185 284 556 186 284 minecraft:white_concrete
fill 556 185 286 556 186 286 minecraft:white_concrete
fill 557 185 275 557 186 275 minecraft:brown_terracotta
fill 557 185 277 557 186 277 minecraft:white_concrete
fill 557 185 279 557 186 279 minecraft:white_concrete
fill 557 185 281 557 186 281 minecraft:white_concrete
fill 557 185 283 557 186 283 minecraft:white_concrete
fill 557 185 285 557 186 285 minecraft:white_concrete
fill 558 185 276 558 185 281 minecraft:brown_terracotta
fill 558 185 282 558 186 282 minecraft:white_concrete
fill 558 185 284 558 186 284 minecraft:white_concrete
fill 558 185 286 558 186 286 minecraft:white_concrete
fill 558 185 288 558 185 293 minecraft:brown_terracotta
fill 558 185 300 558 185 305 minecraft:brown_terracotta
fill 558 185 312 558 185 315 minecraft:brown_terracotta
fill 517 186 281 517 191 284 minecraft:shroomlight
fill 517 186 293 517 191 296 minecraft:shroomlight
fill 517 186 305 517 191 308 minecraft:shroomlight
fill 517 186 317 520 191 317 minecraft:shroomlight
fill 524 186 275 527 191 275 minecraft:shroomlight
fill 529 186 317 532 191 317 minecraft:shroomlight
fill 536 186 275 539 191 275 minecraft:shroomlight
fill 541 186 317 544 191 317 minecraft:shroomlight
fill 544 186 282 544 187 282 minecraft:shroomlight
fill 548 186 275 551 191 275 minecraft:shroomlight
fill 551 186 276 551 188 276 minecraft:white_concrete
fill 553 186 317 556 191 317 minecraft:shroomlight
fill 558 186 276 558 186 281 minecraft:white_concrete
fill 559 186 276 559 191 279 minecraft:shroomlight
fill 559 186 288 559 191 291 minecraft:shroomlight
fill 559 186 300 559 191 303 minecraft:shroomlight
fill 559 186 312 559 191 315 minecraft:shroomlight
fill 518 187 294 522 187 298 minecraft:orange_terracotta
fill 518 187 299 518 218 299 minecraft:white_concrete
setblock 520 187 278 minecraft:light[level=15]
fill 520 187 279 520 187 281 minecraft:brown_terracotta
setblock 520 187 286 minecraft:light[level=15]
setblock 520 187 302 minecraft:light[level=15]
setblock 520 187 310 minecraft:light[level=15]
fill 521 187 278 523 187 278 minecraft:brown_terracotta
setblock 521 187 282 minecraft:brown_terracotta
setblock 523 187 282 minecraft:brown_terracotta
fill 524 187 279 524 187 281 minecraft:brown_terracotta
setblock 528 187 278 minecraft:light[level=15]
fill 528 187 283 529 188 284 minecraft:lime_concrete
setblock 528 187 286 minecraft:light[level=15]
setblock 528 187 294 minecraft:light[level=15]
setblock 528 187 302 minecraft:light[level=15]
setblock 528 187 310 minecraft:light[level=15]
setblock 536 187 278 minecraft:light[level=15]
setblock 536 187 286 minecraft:light[level=15]
setblock 536 187 294 minecraft:light[level=15]
setblock 536 187 302 minecraft:light[level=15]
setblock 536 187 310 minecraft:light[level=15]
setblock 544 187 278 minecraft:light[level=15]
setblock 544 187 286 minecraft:light[level=15]
setblock 544 187 294 minecraft:light[level=15]
setblock 544 187 302 minecraft:light[level=15]
setblock 544 187 310 minecraft:light[level=15]
setblock 551 187 277 minecraft:shroomlight
setblock 551 187 279 minecraft:shroomlight
setblock 551 187 281 minecraft:shroomlight
setblock 551 187 283 minecraft:shroomlight
setblock 551 187 285 minecraft:shroomlight
setblock 552 187 276 minecraft:shroomlight
setblock 552 187 278 minecraft:shroomlight
setblock 552 187 280 minecraft:shroomlight
setblock 552 187 282 minecraft:shroomlight
setblock 552 187 284 minecraft:shroomlight
setblock 552 187 286 minecraft:shroomlight
setblock 552 187 294 minecraft:light[level=15]
setblock 552 187 302 minecraft:light[level=15]
setblock 552 187 310 minecraft:light[level=15]
setblock 553 187 275 minecraft:shroomlight
setblock 553 187 277 minecraft:shroomlight
setblock 553 187 279 minecraft:shroomlight
setblock 553 187 281 minecraft:shroomlight
setblock 553 187 283 minecraft:shroomlight
setblock 553 187 285 minecraft:shroomlight
setblock 554 187 276 minecraft:shroomlight
setblock 554 187 278 minecraft:shroomlight
setblock 554 187 280 minecraft:shroomlight
setblock 554 187 282 minecraft:shroomlight
setblock 554 187 284 minecraft:shroomlight
setblock 554 187 286 minecraft:shroomlight
setblock 555 187 275 minecraft:shroomlight
setblock 555 187 277 minecraft:shroomlight
setblock 555 187 279 minecraft:shroomlight
setblock 555 187 281 minecraft:shroomlight
setblock 555 187 283 minecraft:shroomlight
setblock 555 187 285 minecraft:shroomlight
setblock 556 187 276 minecraft:shroomlight
setblock 556 187 278 minecraft:shroomlight
setblock 556 187 280 minecraft:shroomlight
setblock 556 187 282 minecraft:shroomlight
setblock 556 187 284 minecraft:shroomlight
setblock 556 187 286 minecraft:shroomlight
setblock 557 187 275 minecraft:shroomlight
setblock 557 187 277 minecraft:shroomlight
setblock 557 187 279 minecraft:shroomlight
setblock 557 187 281 minecraft:shroomlight
setblock 557 187 283 minecraft:shroomlight
setblock 557 187 285 minecraft:shroomlight
setblock 558 187 276 minecraft:shroomlight
fill 558 187 277 558 188 277 minecraft:white_concrete
setblock 558 187 278 minecraft:shroomlight
fill 558 187 279 558 188 279 minecraft:white_concrete
setblock 558 187 280 minecraft:shroomlight
fill 558 187 281 558 188 281 minecraft:white_concrete
setblock 558 187 282 minecraft:shroomlight
setblock 558 187 284 minecraft:shroomlight
setblock 558 187 286 minecraft:shroomlight
fill 518 188 294 519 191 298 minecraft:orange_terracotta
fill 520 188 294 522 191 295 minecraft:orange_terracotta
fill 520 188 296 520 189 296 minecraft:ochre_froglight
fill 520 188 297 522 191 298 minecraft:orange_terracotta
fill 521 188 296 522 191 296 minecraft:orange_terracotta
fill 544 188 282 544 195 282 minecraft:brown_terracotta
setblock 551 188 277 minecraft:white_concrete
setblock 551 188 279 minecraft:white_concrete
setblock 551 188 281 minecraft:white_concrete
setblock 551 188 283 minecraft:white_concrete
setblock 551 188 285 minecraft:white_concrete
setblock 552 188 276 minecraft:white_concrete
setblock 552 188 278 minecraft:white_concrete
setblock 552 188 280 minecraft:white_concrete
setblock 552 188 282 minecraft:white_concrete
setblock 552 188 284 minecraft:white_concrete
setblock 552 188 286 minecraft:white_concrete
fill 553 188 275 553 190 275 minecraft:brown_terracotta
setblock 553 188 277 minecraft:white_concrete
setblock 553 188 279 minecraft:white_concrete
setblock 553 188 281 minecraft:white_concrete
setblock 553 188 283 minecraft:white_concrete
setblock 553 188 285 minecraft:white_concrete
fill 554 188 276 554 218 276 minecraft:white_concrete
setblock 554 188 278 minecraft:white_concrete
setblock 554 188 280 minecraft:white_concrete
setblock 554 188 282 minecraft:white_concrete
setblock 554 188 284 minecraft:white_concrete
setblock 554 188 286 minecraft:white_concrete
setblock 555 188 275 minecraft:brown_terracotta
setblock 555 188 277 minecraft:white_concrete
setblock 555 188 279 minecraft:white_concrete
setblock 555 188 281 minecraft:white_concrete
setblock 555 188 283 minecraft:white_concrete
setblock 555 188 285 minecraft:white_concrete
fill 556 188 276 556 218 276 minecraft:white_concrete
setblock 556 188 278 minecraft:white_concrete
setblock 556 188 280 minecraft:white_concrete
setblock 556 188 282 minecraft:white_concrete
setblock 556 188 284 minecraft:white_concrete
setblock 556 188 286 minecraft:white_concrete
fill 557 188 275 557 190 275 minecraft:brown_terracotta
setblock 557 188 277 minecraft:white_concrete
setblock 557 188 279 minecraft:white_concrete
setblock 557 188 281 minecraft:white_concrete
setblock 557 188 283 minecraft:white_concrete
setblock 557 188 285 minecraft:white_concrete
setblock 558 188 276 minecraft:white_concrete
setblock 558 188 278 minecraft:white_concrete
setblock 558 188 280 minecraft:white_concrete
setblock 558 188 282 minecraft:white_concrete
fill 558 188 284 558 218 284 minecraft:white_concrete
fill 558 188 286 558 218 286 minecraft:white_concrete
setblock 517 189 277 minecraft:white_concrete
setblock 517 189 285 minecraft:white_concrete
setblock 517 189 289 minecraft:white_concrete
setblock 517 189 297 minecraft:white_concrete
setblock 517 189 301 minecraft:white_concrete
setblock 517 189 309 minecraft:white_concrete
setblock 517 189 313 minecraft:white_concrete
setblock 519 189 275 minecraft:white_concrete
setblock 520 189 278 minecraft:light[level=12]
setblock 520 189 285 minecraft:light[level=12]
setblock 520 189 292 minecraft:light[level=12]
setblock 520 189 299 minecraft:light[level=12]
setblock 520 189 306 minecraft:light[level=12]
setblock 520 189 313 minecraft:light[level=12]
setblock 523 189 275 minecraft:white_concrete
setblock 523 189 317 minecraft:white_concrete
setblock 527 189 278 minecraft:light[level=12]
setblock 527 189 285 minecraft:light[level=12]
setblock 527 189 292 minecraft:light[level=12]
setblock 527 189 299 minecraft:light[level=12]
setblock 527 189 306 minecraft:light[level=12]
setblock 527 189 313 minecraft:light[level=12]
setblock 527 189 317 minecraft:white_concrete
setblock 531 189 275 minecraft:white_concrete
setblock 534 189 278 minecraft:light[level=12]
setblock 534 189 285 minecraft:light[level=12]
setblock 534 189 292 minecraft:light[level=12]
setblock 534 189 299 minecraft:light[level=12]
setblock 534 189 306 minecraft:light[level=12]
setblock 534 189 313 minecraft:light[level=12]
setblock 535 189 275 minecraft:white_concrete
setblock 535 189 317 minecraft:white_concrete
setblock 539 189 317 minecraft:white_concrete
setblock 541 189 278 minecraft:light[level=12]
setblock 541 189 285 minecraft:light[level=12]
setblock 541 189 292 minecraft:light[level=12]
setblock 541 189 299 minecraft:light[level=12]
setblock 541 189 306 minecraft:light[level=12]
setblock 541 189 313 minecraft:light[level=12]
setblock 543 189 275 minecraft:white_concrete
fill 543 189 282 543 195 282 minecraft:brown_terracotta
setblock 547 189 275 minecraft:white_concrete
setblock 547 189 317 minecraft:white_concrete
setblock 548 189 278 minecraft:light[level=12]
schedule function dropper:buildpart/71_4 1t
