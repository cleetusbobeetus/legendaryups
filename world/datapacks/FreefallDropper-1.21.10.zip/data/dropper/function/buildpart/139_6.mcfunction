setblock 332 199 584 minecraft:oak_log
fill 332 199 585 333 201 585 minecraft:green_terracotta
setblock 332 199 588 minecraft:green_terracotta
setblock 332 199 589 minecraft:oak_log
setblock 333 199 558 minecraft:oak_log
fill 333 199 559 333 202 559 minecraft:green_terracotta
setblock 333 199 582 minecraft:green_terracotta
setblock 333 199 583 minecraft:oak_log
fill 333 199 584 333 202 584 minecraft:green_terracotta
fill 333 199 586 333 200 586 minecraft:green_terracotta
setblock 333 199 597 minecraft:green_terracotta
setblock 333 199 598 minecraft:oak_log
fill 334 199 558 334 202 558 minecraft:green_terracotta
fill 334 199 579 336 199 579 minecraft:jungle_log
setblock 334 199 597 minecraft:oak_log
fill 334 199 598 337 199 598 minecraft:green_terracotta
fill 335 199 597 335 202 597 minecraft:green_terracotta
fill 336 199 578 336 200 578 minecraft:dark_oak_log
setblock 337 199 559 minecraft:oak_log
setblock 337 199 597 minecraft:green_terracotta
setblock 338 199 558 minecraft:oak_log
setblock 338 199 559 minecraft:green_terracotta
fill 338 199 572 338 199 573 minecraft:jungle_log
fill 338 199 576 338 200 576 minecraft:dark_oak_log
fill 338 199 580 338 200 580 minecraft:dark_oak_log
fill 338 199 585 338 199 586 minecraft:jungle_log
setblock 338 199 598 minecraft:oak_log
fill 339 199 558 339 201 558 minecraft:green_terracotta
fill 339 199 573 339 199 574 minecraft:jungle_log
fill 339 199 578 339 199 580 minecraft:jungle_log
fill 339 199 584 339 199 585 minecraft:jungle_log
fill 339 199 598 339 200 598 minecraft:green_terracotta
setblock 340 199 574 minecraft:dark_oak_log
setblock 340 199 577 minecraft:jungle_log
fill 340 199 578 347 199 580 minecraft:jungle_leaves[persistent=true]
setblock 340 199 581 minecraft:jungle_log
fill 341 199 576 344 199 577 minecraft:jungle_leaves[persistent=true]
fill 341 199 581 344 199 582 minecraft:jungle_leaves[persistent=true]
fill 342 199 574 344 199 575 minecraft:jungle_leaves[persistent=true]
fill 342 199 583 344 199 584 minecraft:jungle_leaves[persistent=true]
fill 343 199 573 344 204 573 minecraft:jungle_leaves[persistent=true]
fill 343 199 585 344 204 585 minecraft:jungle_leaves[persistent=true]
fill 345 199 572 345 204 572 minecraft:jungle_leaves[persistent=true]
fill 345 199 573 345 199 574 minecraft:jungle_log
fill 345 199 575 345 208 575 minecraft:jungle_leaves[persistent=true]
fill 345 199 583 345 208 583 minecraft:jungle_leaves[persistent=true]
fill 345 199 584 345 199 585 minecraft:jungle_log
fill 345 199 586 345 204 586 minecraft:jungle_leaves[persistent=true]
fill 346 199 572 346 199 573 minecraft:jungle_log
fill 346 199 574 347 204 574 minecraft:jungle_leaves[persistent=true]
fill 346 199 584 347 204 584 minecraft:jungle_leaves[persistent=true]
fill 346 199 585 346 199 586 minecraft:jungle_log
setblock 347 199 558 minecraft:green_terracotta
fill 347 199 571 353 204 573 minecraft:jungle_leaves[persistent=true]
fill 347 199 585 353 204 587 minecraft:jungle_leaves[persistent=true]
setblock 348 199 558 minecraft:oak_log
fill 348 199 578 349 201 578 minecraft:jungle_leaves[persistent=true]
fill 348 199 579 350 199 579 minecraft:jungle_log
fill 348 199 580 349 201 580 minecraft:jungle_leaves[persistent=true]
fill 349 199 558 351 199 559 minecraft:green_terracotta
setblock 350 199 560 minecraft:green_terracotta
fill 350 199 598 352 199 598 minecraft:green_terracotta
setblock 351 199 560 minecraft:oak_log
setblock 352 199 558 minecraft:green_terracotta
setblock 352 199 559 minecraft:oak_log
fill 352 199 560 352 201 561 minecraft:green_terracotta
setblock 353 199 558 minecraft:oak_log
fill 353 199 559 356 199 559 minecraft:green_terracotta
fill 353 199 561 354 199 561 minecraft:green_terracotta
fill 353 199 574 358 204 574 minecraft:jungle_leaves[persistent=true]
fill 353 199 584 358 204 584 minecraft:jungle_leaves[persistent=true]
setblock 353 199 598 minecraft:oak_log
fill 354 199 558 357 199 558 minecraft:green_terracotta
fill 354 199 572 355 204 573 minecraft:jungle_leaves[persistent=true]
fill 354 199 585 355 204 586 minecraft:jungle_leaves[persistent=true]
fill 354 199 598 357 199 598 minecraft:green_terracotta
setblock 355 199 561 minecraft:oak_log
fill 355 199 575 358 203 575 minecraft:jungle_leaves[persistent=true]
fill 355 199 583 358 203 583 minecraft:jungle_leaves[persistent=true]
setblock 356 199 560 minecraft:oak_log
fill 356 199 561 356 202 561 minecraft:green_terracotta
fill 356 199 573 357 204 573 minecraft:jungle_leaves[persistent=true]
fill 356 199 576 359 202 576 minecraft:jungle_leaves[persistent=true]
fill 356 199 582 359 202 582 minecraft:jungle_leaves[persistent=true]
fill 356 199 585 357 204 585 minecraft:jungle_leaves[persistent=true]
setblock 357 199 559 minecraft:oak_log
fill 357 199 560 357 202 560 minecraft:green_terracotta
fill 357 199 577 359 200 581 minecraft:jungle_leaves[persistent=true]
setblock 358 199 558 minecraft:oak_log
fill 358 199 559 358 202 559 minecraft:green_terracotta
fill 358 199 561 358 200 561 minecraft:green_terracotta
setblock 358 199 598 minecraft:oak_log
fill 359 199 558 359 202 558 minecraft:green_terracotta
fill 359 199 598 359 202 598 minecraft:green_terracotta
fill 360 199 578 360 204 580 minecraft:jungle_leaves[persistent=true]
setblock 361 199 560 minecraft:oak_log
setblock 362 199 559 minecraft:oak_log
fill 362 199 560 362 202 560 minecraft:green_terracotta
setblock 363 199 558 minecraft:oak_log
fill 363 199 559 363 202 559 minecraft:green_terracotta
setblock 363 199 598 minecraft:oak_log
fill 364 199 558 364 202 558 minecraft:green_terracotta
fill 364 199 598 364 202 598 minecraft:green_terracotta
setblock 367 199 559 minecraft:oak_log
fill 367 199 560 368 201 560 minecraft:green_terracotta
setblock 368 199 558 minecraft:oak_log
fill 368 199 559 368 202 559 minecraft:green_terracotta
fill 368 199 561 368 200 561 minecraft:green_terracotta
setblock 368 199 598 minecraft:oak_log
fill 369 199 558 369 202 558 minecraft:green_terracotta
setblock 369 199 562 minecraft:oak_log
fill 369 199 563 369 201 564 minecraft:green_terracotta
setblock 369 199 597 minecraft:oak_log
fill 369 199 598 369 202 598 minecraft:green_terracotta
setblock 370 199 561 minecraft:oak_log
fill 370 199 562 370 202 562 minecraft:green_terracotta
setblock 370 199 566 minecraft:oak_log
fill 370 199 567 370 202 567 minecraft:green_terracotta
setblock 370 199 572 minecraft:oak_leaves[persistent=true]
fill 370 199 577 370 199 580 minecraft:green_terracotta
setblock 370 199 581 minecraft:oak_log
fill 370 199 582 370 199 585 minecraft:green_terracotta
setblock 370 199 586 minecraft:oak_log
fill 370 199 587 370 199 590 minecraft:green_terracotta
setblock 370 199 591 minecraft:oak_log
fill 370 199 592 370 202 592 minecraft:green_terracotta
setblock 370 199 596 minecraft:oak_log
fill 370 199 597 370 202 597 minecraft:green_terracotta
fill 330 200 558 330 200 559 minecraft:green_terracotta
setblock 330 200 560 minecraft:oak_log
fill 330 200 561 330 203 561 minecraft:green_terracotta
setblock 330 200 565 minecraft:oak_log
fill 330 200 566 330 202 567 minecraft:green_terracotta
setblock 330 200 575 minecraft:oak_log
fill 330 200 576 331 202 576 minecraft:green_terracotta
setblock 330 200 580 minecraft:oak_log
fill 330 200 581 330 203 581 minecraft:green_terracotta
setblock 330 200 584 minecraft:green_terracotta
setblock 330 200 585 minecraft:oak_log
fill 330 200 586 330 200 589 minecraft:green_terracotta
setblock 330 200 590 minecraft:oak_log
fill 330 200 591 330 203 591 minecraft:green_terracotta
setblock 330 200 594 minecraft:green_terracotta
setblock 330 200 595 minecraft:oak_log
fill 330 200 596 330 201 598 minecraft:green_terracotta
setblock 331 200 558 minecraft:green_terracotta
setblock 331 200 559 minecraft:oak_log
fill 331 200 560 331 203 560 minecraft:green_terracotta
setblock 331 200 564 minecraft:oak_log
fill 331 200 565 331 203 565 minecraft:green_terracotta
setblock 331 200 579 minecraft:oak_log
fill 331 200 580 331 203 580 minecraft:green_terracotta
setblock 331 200 583 minecraft:green_terracotta
setblock 331 200 584 minecraft:oak_log
fill 331 200 585 331 200 588 minecraft:green_terracotta
setblock 331 200 589 minecraft:oak_log
fill 331 200 590 332 202 590 minecraft:green_terracotta
setblock 331 200 594 minecraft:oak_log
fill 331 200 595 331 203 595 minecraft:green_terracotta
fill 331 200 597 331 200 598 minecraft:green_terracotta
setblock 332 200 558 minecraft:oak_log
fill 332 200 559 332 203 559 minecraft:green_terracotta
fill 332 200 561 332 200 562 minecraft:green_terracotta
setblock 332 200 578 minecraft:oak_log
fill 332 200 579 332 203 579 minecraft:green_terracotta
setblock 332 200 583 minecraft:oak_log
fill 332 200 584 332 203 584 minecraft:green_terracotta
setblock 332 200 588 minecraft:oak_log
fill 332 200 589 332 203 589 minecraft:green_terracotta
fill 332 200 591 332 200 592 minecraft:green_terracotta
fill 332 200 596 332 200 597 minecraft:green_terracotta
setblock 332 200 598 minecraft:oak_log
fill 333 200 558 333 203 558 minecraft:green_terracotta
setblock 333 200 582 minecraft:oak_log
fill 333 200 583 333 203 583 minecraft:green_terracotta
setblock 333 200 587 minecraft:oak_log
fill 333 200 588 333 203 588 minecraft:green_terracotta
setblock 333 200 597 minecraft:oak_log
fill 333 200 598 336 200 598 minecraft:green_terracotta
fill 334 200 597 334 203 597 minecraft:green_terracotta
setblock 336 200 559 minecraft:oak_log
setblock 336 200 577 minecraft:dark_oak_log
fill 336 200 579 339 200 579 minecraft:jungle_log
setblock 337 200 558 minecraft:oak_log
fill 337 200 559 337 201 559 minecraft:green_terracotta
setblock 337 200 576 minecraft:dark_oak_log
fill 337 200 577 338 200 578 minecraft:oak_log
setblock 337 200 580 minecraft:dark_oak_log
setblock 337 200 598 minecraft:oak_log
fill 338 200 558 338 202 558 minecraft:green_terracotta
fill 338 200 573 339 204 573 minecraft:dark_oak_log
fill 338 200 598 338 201 598 minecraft:green_terracotta
fill 339 200 572 340 204 572 minecraft:dark_oak_log
setblock 339 200 574 minecraft:jungle_log
fill 339 200 575 339 203 578 minecraft:jungle_leaves[persistent=true]
fill 339 200 580 339 203 583 minecraft:jungle_leaves[persistent=true]
setblock 339 200 584 minecraft:jungle_log
fill 340 200 574 344 203 574 minecraft:jungle_leaves[persistent=true]
fill 340 200 575 340 200 576 minecraft:jungle_log
fill 340 200 577 344 200 581 minecraft:jungle_leaves[persistent=true]
fill 340 200 582 340 200 583 minecraft:jungle_log
fill 340 200 584 344 203 584 minecraft:jungle_leaves[persistent=true]
fill 341 200 573 342 203 573 minecraft:jungle_leaves[persistent=true]
fill 341 200 575 343 203 576 minecraft:jungle_leaves[persistent=true]
fill 341 200 582 343 203 583 minecraft:jungle_leaves[persistent=true]
fill 341 200 585 342 203 585 minecraft:jungle_leaves[persistent=true]
setblock 341 200 598 minecraft:oak_leaves[persistent=true]
fill 342 200 572 344 203 572 minecraft:jungle_leaves[persistent=true]
fill 342 200 586 344 203 586 minecraft:jungle_leaves[persistent=true]
fill 343 200 571 346 203 571 minecraft:jungle_leaves[persistent=true]
fill 343 200 587 346 203 587 minecraft:jungle_leaves[persistent=true]
fill 344 200 575 344 200 576 minecraft:jungle_log
fill 344 200 582 344 200 583 minecraft:jungle_log
fill 345 200 570 355 203 570 minecraft:jungle_leaves[persistent=true]
fill 345 200 573 346 204 573 minecraft:jungle_leaves[persistent=true]
setblock 345 200 574 minecraft:jungle_log
fill 345 200 578 347 208 578 minecraft:jungle_leaves[persistent=true]
fill 345 200 579 348 200 579 minecraft:jungle_log
fill 345 200 580 347 208 580 minecraft:jungle_leaves[persistent=true]
setblock 345 200 584 minecraft:jungle_log
fill 345 200 585 346 204 585 minecraft:jungle_leaves[persistent=true]
fill 345 200 588 355 203 588 minecraft:jungle_leaves[persistent=true]
setblock 346 200 558 minecraft:green_terracotta
fill 346 200 572 346 204 572 minecraft:jungle_leaves[persistent=true]
fill 346 200 586 346 204 586 minecraft:jungle_leaves[persistent=true]
setblock 347 200 558 minecraft:oak_log
fill 348 200 558 350 200 559 minecraft:green_terracotta
fill 348 200 569 352 203 569 minecraft:jungle_leaves[persistent=true]
fill 348 200 589 352 203 589 minecraft:jungle_leaves[persistent=true]
setblock 349 200 560 minecraft:green_terracotta
setblock 349 200 579 minecraft:jungle_leaves[persistent=true]
setblock 350 200 560 minecraft:oak_log
fill 350 200 598 351 200 598 minecraft:green_terracotta
setblock 351 200 558 minecraft:green_terracotta
setblock 351 200 559 minecraft:oak_log
fill 351 200 560 351 202 561 minecraft:green_terracotta
setblock 352 200 558 minecraft:oak_log
fill 352 200 559 355 200 559 minecraft:green_terracotta
setblock 352 200 598 minecraft:oak_log
fill 353 200 558 356 200 558 minecraft:green_terracotta
setblock 353 200 561 minecraft:green_terracotta
fill 353 200 598 356 200 598 minecraft:green_terracotta
setblock 354 200 561 minecraft:oak_log
fill 354 200 571 357 203 571 minecraft:jungle_leaves[persistent=true]
fill 354 200 587 357 203 587 minecraft:jungle_leaves[persistent=true]
setblock 355 200 560 minecraft:oak_log
fill 355 200 561 355 203 561 minecraft:green_terracotta
setblock 356 200 559 minecraft:oak_log
fill 356 200 560 356 203 560 minecraft:green_terracotta
fill 356 200 572 358 203 572 minecraft:jungle_leaves[persistent=true]
fill 356 200 586 358 203 586 minecraft:jungle_leaves[persistent=true]
setblock 357 200 558 minecraft:oak_log
fill 357 200 559 357 203 559 minecraft:green_terracotta
setblock 357 200 598 minecraft:oak_log
fill 358 200 558 358 203 558 minecraft:green_terracotta
fill 358 200 573 359 203 573 minecraft:jungle_leaves[persistent=true]
fill 358 200 585 359 203 585 minecraft:jungle_leaves[persistent=true]
fill 358 200 598 358 202 598 minecraft:green_terracotta
fill 359 200 574 360 203 575 minecraft:jungle_leaves[persistent=true]
fill 359 200 583 360 203 584 minecraft:jungle_leaves[persistent=true]
setblock 360 200 560 minecraft:oak_log
fill 360 200 576 361 203 577 minecraft:jungle_leaves[persistent=true]
fill 360 200 581 361 203 582 minecraft:jungle_leaves[persistent=true]
setblock 361 200 559 minecraft:oak_log
fill 361 200 560 361 202 560 minecraft:green_terracotta
fill 361 200 575 361 203 575 minecraft:jungle_leaves[persistent=true]
fill 361 200 578 361 203 580 minecraft:jungle_leaves[persistent=true]
fill 361 200 583 361 203 583 minecraft:jungle_leaves[persistent=true]
setblock 362 200 558 minecraft:oak_log
fill 362 200 559 362 203 559 minecraft:green_terracotta
fill 362 200 579 362 203 579 minecraft:jungle_leaves[persistent=true]
setblock 362 200 598 minecraft:oak_log
fill 363 200 558 363 203 558 minecraft:green_terracotta
fill 363 200 560 364 200 560 minecraft:green_terracotta
fill 363 200 598 363 201 598 minecraft:green_terracotta
setblock 365 200 560 minecraft:oak_log
setblock 366 200 559 minecraft:oak_log
fill 366 200 560 366 203 560 minecraft:green_terracotta
setblock 367 200 558 minecraft:oak_log
fill 367 200 559 367 203 559 minecraft:green_terracotta
setblock 367 200 598 minecraft:oak_log
fill 368 200 558 368 203 558 minecraft:green_terracotta
setblock 368 200 562 minecraft:oak_log
fill 368 200 563 368 203 563 minecraft:green_terracotta
setblock 368 200 597 minecraft:oak_log
fill 368 200 598 368 203 598 minecraft:green_terracotta
setblock 369 200 561 minecraft:oak_log
fill 369 200 562 369 203 562 minecraft:green_terracotta
setblock 369 200 565 minecraft:green_terracotta
setblock 369 200 566 minecraft:oak_log
setblock 369 200 581 minecraft:oak_log
fill 369 200 582 369 200 585 minecraft:green_terracotta
setblock 369 200 586 minecraft:oak_log
fill 369 200 587 370 202 587 minecraft:green_terracotta
setblock 369 200 596 minecraft:oak_log
fill 369 200 597 369 203 597 minecraft:green_terracotta
setblock 370 200 560 minecraft:oak_log
fill 370 200 561 370 203 561 minecraft:green_terracotta
setblock 370 200 564 minecraft:green_terracotta
setblock 370 200 565 minecraft:oak_log
fill 370 200 566 370 203 566 minecraft:green_terracotta
fill 370 200 568 370 201 568 minecraft:green_terracotta
fill 370 200 576 370 200 579 minecraft:green_terracotta
setblock 370 200 580 minecraft:oak_log
fill 370 200 581 370 200 584 minecraft:green_terracotta
setblock 370 200 585 minecraft:oak_log
fill 370 200 586 370 203 586 minecraft:green_terracotta
fill 370 200 588 370 200 589 minecraft:green_terracotta
setblock 370 200 590 minecraft:oak_log
fill 370 200 591 370 203 591 minecraft:green_terracotta
setblock 370 200 595 minecraft:oak_log
fill 370 200 596 370 203 596 minecraft:green_terracotta
setblock 330 201 558 minecraft:green_terracotta
setblock 330 201 559 minecraft:oak_log
fill 330 201 560 330 204 560 minecraft:green_terracotta
setblock 330 201 563 minecraft:green_terracotta
setblock 330 201 564 minecraft:oak_log
fill 330 201 565 330 204 565 minecraft:green_terracotta
setblock 330 201 568 minecraft:green_terracotta
setblock 330 201 569 minecraft:oak_log
setblock 330 201 571 minecraft:oak_leaves[persistent=true]
setblock 330 201 574 minecraft:oak_log
fill 330 201 575 330 204 575 minecraft:green_terracotta
setblock 330 201 579 minecraft:oak_log
fill 330 201 580 330 204 580 minecraft:green_terracotta
setblock 330 201 584 minecraft:oak_log
fill 330 201 585 330 201 588 minecraft:green_terracotta
setblock 330 201 589 minecraft:oak_log
fill 330 201 590 330 204 590 minecraft:green_terracotta
setblock 330 201 593 minecraft:green_terracotta
setblock 330 201 594 minecraft:oak_log
fill 330 201 595 330 204 595 minecraft:green_terracotta
setblock 331 201 558 minecraft:oak_log
fill 331 201 559 331 204 559 minecraft:green_terracotta
setblock 331 201 563 minecraft:oak_log
fill 331 201 564 331 204 564 minecraft:green_terracotta
fill 331 201 566 331 202 566 minecraft:green_terracotta
setblock 331 201 578 minecraft:oak_log
fill 331 201 579 331 204 579 minecraft:green_terracotta
setblock 331 201 583 minecraft:oak_log
fill 331 201 584 331 201 587 minecraft:green_terracotta
setblock 331 201 588 minecraft:oak_log
fill 331 201 589 331 204 589 minecraft:green_terracotta
setblock 331 201 593 minecraft:oak_log
fill 331 201 594 331 204 594 minecraft:green_terracotta
setblock 331 201 597 minecraft:green_terracotta
setblock 331 201 598 minecraft:oak_log
fill 332 201 558 332 204 558 minecraft:green_terracotta
fill 332 201 560 332 201 561 minecraft:green_terracotta
setblock 332 201 562 minecraft:oak_log
fill 332 201 563 332 203 563 minecraft:green_terracotta
setblock 332 201 568 minecraft:light[level=14]
setblock 332 201 576 minecraft:light[level=14]
fill 332 201 578 332 203 578 minecraft:green_terracotta
setblock 332 201 581 minecraft:green_terracotta
setblock 332 201 582 minecraft:oak_log
fill 332 201 583 332 204 583 minecraft:green_terracotta
setblock 332 201 586 minecraft:green_terracotta
setblock 332 201 587 minecraft:oak_log
fill 332 201 588 332 204 588 minecraft:green_terracotta
setblock 332 201 591 minecraft:green_terracotta
setblock 332 201 592 minecraft:oak_log
fill 332 201 593 332 204 593 minecraft:green_terracotta
setblock 332 201 597 minecraft:oak_log
fill 332 201 598 335 201 598 minecraft:green_terracotta
setblock 333 201 560 minecraft:green_terracotta
setblock 333 201 581 minecraft:oak_log
fill 333 201 582 333 204 582 minecraft:green_terracotta
setblock 333 201 586 minecraft:oak_log
fill 333 201 587 333 204 587 minecraft:green_terracotta
fill 333 201 589 333 202 589 minecraft:green_terracotta
fill 333 201 597 333 203 597 minecraft:green_terracotta
setblock 334 201 560 minecraft:oak_log
fill 334 201 583 334 201 584 minecraft:green_terracotta
setblock 334 201 585 minecraft:oak_log
setblock 335 201 559 minecraft:oak_log
setblock 336 201 558 minecraft:oak_log
fill 336 201 559 336 202 559 minecraft:green_terracotta
setblock 336 201 598 minecraft:oak_log
fill 337 201 558 337 203 558 minecraft:green_terracotta
fill 337 201 577 337 204 579 minecraft:oak_log
fill 337 201 598 337 202 598 minecraft:green_terracotta
fill 338 201 574 338 204 574 minecraft:dark_oak_log
fill 338 201 575 338 202 583 minecraft:jungle_leaves[persistent=true]
fill 339 201 574 339 202 574 minecraft:jungle_leaves[persistent=true]
fill 339 201 579 345 201 579 minecraft:jungle_log
fill 339 201 584 339 202 584 minecraft:jungle_leaves[persistent=true]
setblock 340 201 560 minecraft:light[level=14]
setblock 340 201 568 minecraft:light[level=14]
fill 340 201 573 340 202 573 minecraft:jungle_leaves[persistent=true]
fill 340 201 575 340 203 578 minecraft:jungle_leaves[persistent=true]
fill 340 201 580 340 203 583 minecraft:jungle_leaves[persistent=true]
fill 340 201 585 340 202 585 minecraft:jungle_leaves[persistent=true]
setblock 340 201 592 minecraft:light[level=14]
fill 341 201 572 341 202 572 minecraft:jungle_leaves[persistent=true]
fill 341 201 577 341 201 578 minecraft:jungle_log
fill 341 201 580 341 201 581 minecraft:jungle_log
fill 341 201 586 341 202 586 minecraft:jungle_leaves[persistent=true]
fill 342 201 571 342 202 571 minecraft:jungle_leaves[persistent=true]
fill 342 201 577 342 209 577 minecraft:jungle_leaves[persistent=true]
fill 342 201 578 343 201 578 minecraft:jungle_log
fill 342 201 580 343 201 580 minecraft:jungle_log
fill 342 201 581 342 209 581 minecraft:jungle_leaves[persistent=true]
fill 342 201 587 342 202 587 minecraft:jungle_leaves[persistent=true]
fill 343 201 570 344 202 570 minecraft:jungle_leaves[persistent=true]
setblock 343 201 577 minecraft:jungle_log
setblock 343 201 581 minecraft:jungle_log
fill 343 201 588 344 202 588 minecraft:jungle_leaves[persistent=true]
fill 344 201 575 344 208 578 minecraft:jungle_leaves[persistent=true]
fill 344 201 580 344 208 583 minecraft:jungle_leaves[persistent=true]
setblock 345 201 558 minecraft:green_terracotta
fill 345 201 569 347 202 569 minecraft:jungle_leaves[persistent=true]
fill 345 201 574 345 208 574 minecraft:jungle_leaves[persistent=true]
fill 345 201 584 345 208 584 minecraft:jungle_leaves[persistent=true]
fill 345 201 589 347 202 589 minecraft:jungle_leaves[persistent=true]
setblock 346 201 558 minecraft:oak_log
fill 346 201 575 352 201 575 minecraft:jungle_leaves[persistent=true]
fill 346 201 579 348 208 579 minecraft:jungle_leaves[persistent=true]
fill 346 201 583 352 201 583 minecraft:jungle_leaves[persistent=true]
fill 347 201 558 349 201 559 minecraft:green_terracotta
setblock 347 201 598 minecraft:oak_leaves[persistent=true]
setblock 348 201 560 minecraft:light[level=14]
setblock 348 201 568 minecraft:light[level=14]
setblock 348 201 592 minecraft:light[level=14]
setblock 349 201 560 minecraft:oak_log
setblock 350 201 558 minecraft:green_terracotta
setblock 350 201 559 minecraft:oak_log
fill 350 201 560 350 203 561 minecraft:green_terracotta
setblock 350 201 598 minecraft:green_terracotta
setblock 351 201 558 minecraft:oak_log
fill 351 201 559 354 201 559 minecraft:green_terracotta
setblock 351 201 598 minecraft:oak_log
fill 352 201 558 355 201 558 minecraft:green_terracotta
fill 352 201 598 355 201 598 minecraft:green_terracotta
setblock 353 201 561 minecraft:oak_log
fill 353 201 562 354 202 562 minecraft:green_terracotta
fill 353 201 569 355 202 569 minecraft:jungle_leaves[persistent=true]
fill 353 201 589 355 202 589 minecraft:jungle_leaves[persistent=true]
setblock 354 201 560 minecraft:oak_log
fill 354 201 561 354 204 561 minecraft:green_terracotta
setblock 354 201 575 minecraft:jungle_leaves[persistent=true]
setblock 354 201 583 minecraft:jungle_leaves[persistent=true]
setblock 355 201 559 minecraft:oak_log
fill 355 201 560 355 204 560 minecraft:green_terracotta
setblock 356 201 558 minecraft:oak_log
fill 356 201 559 356 204 559 minecraft:green_terracotta
setblock 356 201 568 minecraft:light[level=14]
fill 356 201 570 357 202 570 minecraft:jungle_leaves[persistent=true]
fill 356 201 588 357 202 588 minecraft:jungle_leaves[persistent=true]
setblock 356 201 592 minecraft:light[level=14]
setblock 356 201 598 minecraft:oak_log
fill 357 201 558 357 204 558 minecraft:green_terracotta
fill 357 201 577 359 201 578 minecraft:jungle_leaves[persistent=true]
fill 357 201 580 359 201 581 minecraft:jungle_leaves[persistent=true]
fill 357 201 598 357 203 598 minecraft:green_terracotta
setblock 358 201 561 minecraft:oak_log
fill 358 201 571 358 202 571 minecraft:jungle_leaves[persistent=true]
fill 358 201 579 359 204 579 minecraft:jungle_leaves[persistent=true]
fill 358 201 587 358 202 587 minecraft:jungle_leaves[persistent=true]
setblock 359 201 560 minecraft:oak_log
fill 359 201 572 359 202 572 minecraft:jungle_leaves[persistent=true]
fill 359 201 586 359 202 586 minecraft:jungle_leaves[persistent=true]
setblock 360 201 559 minecraft:oak_log
fill 360 201 560 360 203 560 minecraft:green_terracotta
fill 360 201 573 360 202 573 minecraft:jungle_leaves[persistent=true]
fill 360 201 585 360 202 585 minecraft:jungle_leaves[persistent=true]
setblock 361 201 558 minecraft:oak_log
fill 361 201 559 361 204 559 minecraft:green_terracotta
fill 361 201 574 361 202 574 minecraft:jungle_leaves[persistent=true]
fill 361 201 584 361 202 584 minecraft:jungle_leaves[persistent=true]
fill 362 201 558 362 204 558 minecraft:green_terracotta
fill 362 201 575 362 202 578 minecraft:jungle_leaves[persistent=true]
fill 362 201 580 362 202 583 minecraft:jungle_leaves[persistent=true]
setblock 363 201 560 minecraft:green_terracotta
setblock 364 201 560 minecraft:oak_log
setblock 364 201 568 minecraft:light[level=14]
setblock 364 201 576 minecraft:light[level=14]
setblock 364 201 584 minecraft:light[level=14]
setblock 364 201 592 minecraft:light[level=14]
setblock 365 201 559 minecraft:oak_log
fill 365 201 560 365 203 560 minecraft:green_terracotta
setblock 366 201 558 minecraft:oak_log
fill 366 201 559 366 204 559 minecraft:green_terracotta
setblock 366 201 598 minecraft:oak_log
fill 367 201 558 367 204 558 minecraft:green_terracotta
fill 367 201 598 367 204 598 minecraft:green_terracotta
setblock 368 201 561 minecraft:oak_log
fill 368 201 562 368 204 562 minecraft:green_terracotta
fill 368 201 564 368 202 564 minecraft:green_terracotta
fill 368 201 597 368 204 597 minecraft:green_terracotta
setblock 369 201 560 minecraft:oak_log
fill 369 201 561 369 204 561 minecraft:green_terracotta
setblock 369 201 565 minecraft:oak_log
fill 369 201 566 369 203 567 minecraft:green_terracotta
setblock 369 201 580 minecraft:oak_log
fill 369 201 581 369 201 584 minecraft:green_terracotta
setblock 369 201 585 minecraft:oak_log
fill 369 201 586 369 204 586 minecraft:green_terracotta
fill 369 201 588 369 201 589 minecraft:green_terracotta
setblock 369 201 590 minecraft:oak_log
fill 369 201 591 369 204 591 minecraft:green_terracotta
setblock 369 201 594 minecraft:green_terracotta
setblock 369 201 595 minecraft:oak_log
fill 369 201 596 369 204 596 minecraft:green_terracotta
setblock 370 201 559 minecraft:oak_log
fill 370 201 560 370 204 560 minecraft:green_terracotta
setblock 370 201 564 minecraft:oak_log
fill 370 201 565 370 204 565 minecraft:green_terracotta
setblock 370 201 569 minecraft:oak_log
fill 370 201 570 370 204 570 minecraft:green_terracotta
fill 370 201 576 370 201 578 minecraft:green_terracotta
setblock 370 201 579 minecraft:oak_log
fill 370 201 580 370 201 583 minecraft:green_terracotta
setblock 370 201 584 minecraft:oak_log
fill 370 201 585 370 204 585 minecraft:green_terracotta
setblock 370 201 588 minecraft:green_terracotta
setblock 370 201 589 minecraft:oak_log
fill 370 201 590 370 204 590 minecraft:green_terracotta
setblock 370 201 593 minecraft:green_terracotta
setblock 370 201 594 minecraft:oak_log
fill 370 201 595 370 204 595 minecraft:green_terracotta
setblock 330 202 558 minecraft:oak_log
fill 330 202 559 330 205 559 minecraft:green_terracotta
setblock 330 202 563 minecraft:oak_log
fill 330 202 564 330 205 564 minecraft:green_terracotta
setblock 330 202 568 minecraft:oak_log
fill 330 202 569 330 202 572 minecraft:green_terracotta
setblock 330 202 573 minecraft:oak_log
fill 330 202 574 330 205 574 minecraft:green_terracotta
setblock 330 202 578 minecraft:oak_log
fill 330 202 579 330 205 579 minecraft:green_terracotta
setblock 330 202 583 minecraft:oak_log
fill 330 202 584 330 202 587 minecraft:green_terracotta
setblock 330 202 588 minecraft:oak_log
fill 330 202 589 330 205 589 minecraft:green_terracotta
setblock 330 202 593 minecraft:oak_log
fill 330 202 594 330 205 594 minecraft:green_terracotta
fill 330 202 596 330 202 597 minecraft:green_terracotta
setblock 330 202 598 minecraft:oak_log
fill 331 202 558 331 205 558 minecraft:green_terracotta
setblock 331 202 562 minecraft:oak_log
fill 331 202 563 331 205 563 minecraft:green_terracotta
setblock 331 202 567 minecraft:oak_log
fill 331 202 568 331 205 568 minecraft:green_terracotta
setblock 331 202 577 minecraft:oak_log
fill 331 202 578 331 205 578 minecraft:green_terracotta
setblock 331 202 582 minecraft:oak_log
fill 331 202 583 331 202 586 minecraft:green_terracotta
setblock 331 202 587 minecraft:oak_log
fill 331 202 588 331 205 588 minecraft:green_terracotta
setblock 331 202 592 minecraft:oak_log
fill 331 202 593 331 205 593 minecraft:green_terracotta
setblock 331 202 597 minecraft:oak_log
fill 331 202 598 334 202 598 minecraft:green_terracotta
setblock 332 202 560 minecraft:green_terracotta
setblock 332 202 561 minecraft:oak_log
fill 332 202 562 332 203 562 minecraft:green_terracotta
fill 332 202 564 332 203 564 minecraft:green_terracotta
setblock 332 202 580 minecraft:green_terracotta
setblock 332 202 581 minecraft:oak_log
fill 332 202 582 332 205 582 minecraft:green_terracotta
setblock 332 202 585 minecraft:green_terracotta
setblock 332 202 586 minecraft:oak_log
fill 332 202 587 332 205 587 minecraft:green_terracotta
setblock 332 202 591 minecraft:oak_log
fill 332 202 592 332 205 592 minecraft:green_terracotta
setblock 332 202 594 minecraft:green_terracotta
fill 332 202 597 332 204 597 minecraft:green_terracotta
setblock 333 202 560 minecraft:oak_log
setblock 333 202 580 minecraft:oak_log
fill 333 202 581 333 204 581 minecraft:green_terracotta
setblock 333 202 585 minecraft:oak_log
fill 333 202 586 334 202 586 minecraft:green_terracotta
setblock 333 202 590 minecraft:oak_log
setblock 334 202 559 minecraft:oak_log
setblock 334 202 583 minecraft:green_terracotta
setblock 334 202 584 minecraft:oak_log
fill 334 202 585 334 203 585 minecraft:green_terracotta
setblock 335 202 558 minecraft:oak_log
fill 335 202 559 335 203 559 minecraft:green_terracotta
setblock 335 202 598 minecraft:oak_log
fill 336 202 558 336 203 558 minecraft:green_terracotta
fill 336 202 598 336 203 598 minecraft:green_terracotta
fill 338 202 572 338 204 572 minecraft:dark_oak_log
fill 339 202 571 340 204 571 minecraft:dark_oak_log
fill 339 202 579 341 209 579 minecraft:jungle_leaves[persistent=true]
fill 341 202 577 341 209 578 minecraft:jungle_leaves[persistent=true]
fill 341 202 580 341 209 581 minecraft:jungle_leaves[persistent=true]
fill 342 202 578 343 209 578 minecraft:jungle_leaves[persistent=true]
setblock 342 202 579 minecraft:jungle_log
fill 342 202 580 343 209 580 minecraft:jungle_leaves[persistent=true]
fill 343 202 577 343 209 577 minecraft:jungle_leaves[persistent=true]
fill 343 202 579 345 209 579 minecraft:jungle_leaves[persistent=true]
fill 343 202 581 343 209 581 minecraft:jungle_leaves[persistent=true]
setblock 345 202 558 minecraft:oak_log
fill 346 202 558 349 202 558 minecraft:green_terracotta
fill 346 202 575 351 203 575 minecraft:jungle_leaves[persistent=true]
fill 346 202 583 351 203 583 minecraft:jungle_leaves[persistent=true]
fill 347 202 559 348 202 559 minecraft:green_terracotta
setblock 348 202 560 minecraft:oak_log
fill 348 202 578 348 207 578 minecraft:jungle_leaves[persistent=true]
fill 348 202 580 348 207 580 minecraft:jungle_leaves[persistent=true]
setblock 349 202 559 minecraft:oak_log
fill 349 202 560 349 205 560 minecraft:green_terracotta
setblock 349 202 598 minecraft:green_terracotta
setblock 350 202 558 minecraft:oak_log
fill 350 202 559 353 202 559 minecraft:green_terracotta
setblock 350 202 598 minecraft:oak_log
fill 351 202 558 354 202 558 minecraft:green_terracotta
fill 351 202 598 354 202 598 minecraft:green_terracotta
setblock 352 202 560 minecraft:green_terracotta
setblock 352 202 561 minecraft:oak_log
fill 352 202 562 352 203 562 minecraft:green_terracotta
setblock 353 202 560 minecraft:oak_log
fill 353 202 561 353 205 561 minecraft:green_terracotta
setblock 354 202 559 minecraft:oak_log
fill 354 202 560 354 205 560 minecraft:green_terracotta
setblock 355 202 558 minecraft:oak_log
fill 355 202 559 355 205 559 minecraft:green_terracotta
setblock 355 202 598 minecraft:oak_log
fill 356 202 558 356 205 558 minecraft:green_terracotta
fill 356 202 598 356 203 598 minecraft:green_terracotta
setblock 357 202 561 minecraft:oak_log
fill 357 202 577 359 203 577 minecraft:jungle_leaves[persistent=true]
fill 357 202 581 359 203 581 minecraft:jungle_leaves[persistent=true]
setblock 358 202 560 minecraft:oak_log
setblock 358 202 561 minecraft:green_terracotta
fill 358 202 578 359 204 578 minecraft:jungle_leaves[persistent=true]
fill 358 202 580 359 204 580 minecraft:jungle_leaves[persistent=true]
setblock 359 202 559 minecraft:oak_log
fill 359 202 560 359 203 560 minecraft:green_terracotta
setblock 360 202 558 minecraft:oak_log
fill 360 202 559 360 204 559 minecraft:green_terracotta
fill 361 202 558 361 205 558 minecraft:green_terracotta
setblock 363 202 560 minecraft:oak_log
setblock 364 202 559 minecraft:oak_log
setblock 364 202 560 minecraft:green_terracotta
setblock 365 202 558 minecraft:oak_log
fill 365 202 559 365 205 559 minecraft:green_terracotta
setblock 365 202 598 minecraft:oak_log
fill 366 202 558 366 205 558 minecraft:green_terracotta
fill 366 202 598 366 205 598 minecraft:green_terracotta
setblock 367 202 560 minecraft:green_terracotta
setblock 368 202 560 minecraft:oak_log
fill 368 202 561 368 205 561 minecraft:green_terracotta
setblock 368 202 565 minecraft:oak_log
setblock 369 202 559 minecraft:oak_log
fill 369 202 560 369 205 560 minecraft:green_terracotta
setblock 369 202 563 minecraft:green_terracotta
setblock 369 202 564 minecraft:oak_log
fill 369 202 565 369 205 565 minecraft:green_terracotta
fill 369 202 580 369 202 583 minecraft:green_terracotta
setblock 369 202 584 minecraft:oak_log
fill 369 202 585 369 205 585 minecraft:green_terracotta
setblock 369 202 588 minecraft:green_terracotta
setblock 369 202 589 minecraft:oak_log
fill 369 202 590 369 205 590 minecraft:green_terracotta
fill 369 202 592 369 202 593 minecraft:green_terracotta
setblock 369 202 594 minecraft:oak_log
fill 369 202 595 369 205 595 minecraft:green_terracotta
setblock 370 202 558 minecraft:oak_log
fill 370 202 559 370 205 559 minecraft:green_terracotta
setblock 370 202 563 minecraft:oak_log
fill 370 202 564 370 205 564 minecraft:green_terracotta
setblock 370 202 568 minecraft:oak_log
fill 370 202 569 370 205 569 minecraft:green_terracotta
fill 370 202 571 370 203 571 minecraft:green_terracotta
fill 370 202 576 370 202 577 minecraft:green_terracotta
setblock 370 202 578 minecraft:oak_log
fill 370 202 579 370 202 582 minecraft:green_terracotta
setblock 370 202 583 minecraft:oak_log
fill 370 202 584 370 205 584 minecraft:green_terracotta
setblock 370 202 588 minecraft:oak_log
fill 370 202 589 370 205 589 minecraft:green_terracotta
setblock 370 202 593 minecraft:oak_log
fill 370 202 594 370 205 594 minecraft:green_terracotta
setblock 370 202 598 minecraft:oak_log
fill 330 203 558 330 206 558 minecraft:green_terracotta
setblock 330 203 562 minecraft:oak_log
fill 330 203 563 330 206 563 minecraft:green_terracotta
setblock 330 203 566 minecraft:green_terracotta
setblock 330 203 567 minecraft:oak_log
fill 330 203 568 330 203 571 minecraft:green_terracotta
setblock 330 203 572 minecraft:oak_log
fill 330 203 573 330 206 573 minecraft:green_terracotta
setblock 330 203 576 minecraft:green_terracotta
setblock 330 203 577 minecraft:oak_log
fill 330 203 578 330 206 578 minecraft:green_terracotta
setblock 330 203 582 minecraft:oak_log
fill 330 203 583 330 203 586 minecraft:green_terracotta
setblock 330 203 587 minecraft:oak_log
fill 330 203 588 330 206 588 minecraft:green_terracotta
setblock 330 203 592 minecraft:oak_log
fill 330 203 593 330 206 593 minecraft:green_terracotta
setblock 330 203 596 minecraft:green_terracotta
setblock 330 203 597 minecraft:oak_log
fill 330 203 598 333 203 598 minecraft:green_terracotta
setblock 331 203 561 minecraft:oak_log
fill 331 203 562 331 206 562 minecraft:green_terracotta
setblock 331 203 566 minecraft:oak_log
fill 331 203 567 331 206 567 minecraft:green_terracotta
fill 331 203 569 331 204 569 minecraft:green_terracotta
setblock 331 203 576 minecraft:oak_log
fill 331 203 577 331 205 577 minecraft:green_terracotta
setblock 331 203 581 minecraft:oak_log
fill 331 203 582 331 203 585 minecraft:green_terracotta
setblock 331 203 586 minecraft:oak_log
fill 331 203 587 331 206 587 minecraft:green_terracotta
setblock 331 203 590 minecraft:green_terracotta
setblock 331 203 591 minecraft:oak_log
fill 331 203 592 331 206 592 minecraft:green_terracotta
setblock 331 203 596 minecraft:oak_log
fill 331 203 597 331 205 597 minecraft:green_terracotta
setblock 332 203 561 minecraft:green_terracotta
setblock 332 203 580 minecraft:oak_log
fill 332 203 581 332 206 581 minecraft:green_terracotta
setblock 332 203 585 minecraft:oak_log
fill 332 203 586 333 205 586 minecraft:green_terracotta
setblock 332 203 590 minecraft:oak_log
fill 332 203 591 332 206 591 minecraft:green_terracotta
setblock 333 203 559 minecraft:oak_log
setblock 333 203 580 minecraft:green_terracotta
setblock 333 203 584 minecraft:oak_log
fill 333 203 585 333 206 585 minecraft:green_terracotta
setblock 333 203 589 minecraft:oak_log
fill 333 203 590 333 204 590 minecraft:green_terracotta
setblock 334 203 558 minecraft:oak_log
setblock 334 203 559 minecraft:green_terracotta
setblock 334 203 584 minecraft:green_terracotta
setblock 334 203 598 minecraft:oak_log
fill 335 203 558 335 204 558 minecraft:green_terracotta
fill 335 203 598 335 204 598 minecraft:green_terracotta
fill 336 203 560 339 222 563 minecraft:oak_log
fill 337 203 574 337 204 575 minecraft:dark_oak_log
fill 338 203 571 338 204 571 minecraft:dark_oak_log
fill 338 203 575 338 204 576 minecraft:dark_oak_log
fill 338 203 577 338 204 578 minecraft:oak_log
setblock 338 203 579 minecraft:jungle_leaves[persistent=true]
fill 339 203 574 339 204 574 minecraft:dark_oak_log
fill 340 203 561 340 225 562 minecraft:oak_log
fill 340 203 573 340 204 573 minecraft:dark_oak_log
setblock 340 203 598 minecraft:oak_leaves[persistent=true]
setblock 341 203 558 minecraft:oak_leaves[persistent=true]
fill 341 203 571 341 204 572 minecraft:dark_oak_log
fill 342 203 579 342 209 579 minecraft:jungle_leaves[persistent=true]
fill 345 203 558 348 203 558 minecraft:green_terracotta
setblock 347 203 559 minecraft:green_terracotta
setblock 348 203 559 minecraft:oak_log
fill 348 203 560 348 205 560 minecraft:green_terracotta
setblock 349 203 558 minecraft:oak_log
fill 349 203 559 352 203 559 minecraft:green_terracotta
setblock 349 203 561 minecraft:green_terracotta
fill 350 203 558 353 203 558 minecraft:green_terracotta
fill 350 203 598 353 203 598 minecraft:green_terracotta
setblock 351 203 560 minecraft:green_terracotta
setblock 351 203 561 minecraft:oak_log
setblock 352 203 560 minecraft:oak_log
fill 352 203 561 352 205 561 minecraft:green_terracotta
setblock 353 203 559 minecraft:oak_log
fill 353 203 560 353 206 560 minecraft:green_terracotta
setblock 353 203 562 minecraft:green_terracotta
setblock 354 203 558 minecraft:oak_log
fill 354 203 559 354 206 559 minecraft:green_terracotta
setblock 354 203 598 minecraft:oak_log
fill 355 203 558 355 206 558 minecraft:green_terracotta
fill 355 203 598 355 204 598 minecraft:green_terracotta
setblock 356 203 561 minecraft:oak_log
setblock 357 203 560 minecraft:oak_log
setblock 357 203 561 minecraft:green_terracotta
fill 357 203 576 359 204 576 minecraft:jungle_leaves[persistent=true]
fill 357 203 582 359 204 582 minecraft:jungle_leaves[persistent=true]
setblock 358 203 559 minecraft:oak_log
fill 358 203 560 358 204 560 minecraft:green_terracotta
setblock 359 203 558 minecraft:oak_log
fill 359 203 559 359 204 559 minecraft:green_terracotta
setblock 359 203 598 minecraft:oak_leaves[persistent=true]
fill 360 203 558 360 205 558 minecraft:green_terracotta
setblock 363 203 559 minecraft:oak_log
setblock 364 203 558 minecraft:oak_log
fill 364 203 559 364 205 559 minecraft:green_terracotta
setblock 364 203 598 minecraft:oak_log
fill 365 203 558 365 206 558 minecraft:green_terracotta
fill 365 203 598 365 206 598 minecraft:green_terracotta
setblock 367 203 560 minecraft:oak_log
fill 367 203 597 367 205 597 minecraft:green_terracotta
setblock 368 203 559 minecraft:oak_log
fill 368 203 560 368 205 560 minecraft:green_terracotta
setblock 368 203 564 minecraft:oak_log
fill 368 203 565 368 205 565 minecraft:green_terracotta
fill 368 203 585 368 204 587 minecraft:green_terracotta
setblock 369 203 558 minecraft:oak_log
fill 369 203 559 369 206 559 minecraft:green_terracotta
setblock 369 203 563 minecraft:oak_log
fill 369 203 564 369 206 564 minecraft:green_terracotta
setblock 369 203 568 minecraft:oak_log
fill 369 203 580 369 203 582 minecraft:green_terracotta
setblock 369 203 583 minecraft:oak_log
fill 369 203 584 369 206 584 minecraft:green_terracotta
setblock 369 203 587 minecraft:green_terracotta
setblock 369 203 588 minecraft:oak_log
fill 369 203 589 369 206 589 minecraft:green_terracotta
setblock 369 203 592 minecraft:green_terracotta
setblock 369 203 593 minecraft:oak_log
fill 369 203 594 369 206 594 minecraft:green_terracotta
setblock 369 203 598 minecraft:oak_log
fill 370 203 558 370 206 558 minecraft:green_terracotta
setblock 370 203 562 minecraft:oak_log
fill 370 203 563 370 206 563 minecraft:green_terracotta
setblock 370 203 567 minecraft:oak_log
fill 370 203 568 370 206 568 minecraft:green_terracotta
setblock 370 203 573 minecraft:oak_leaves[persistent=true]
setblock 370 203 576 minecraft:green_terracotta
setblock 370 203 577 minecraft:oak_log
fill 370 203 578 370 203 581 minecraft:green_terracotta
setblock 370 203 582 minecraft:oak_log
fill 370 203 583 370 206 583 minecraft:green_terracotta
setblock 370 203 587 minecraft:oak_log
fill 370 203 588 370 206 588 minecraft:green_terracotta
setblock 370 203 592 minecraft:oak_log
fill 370 203 593 370 206 593 minecraft:green_terracotta
setblock 370 203 597 minecraft:oak_log
fill 370 203 598 370 206 598 minecraft:green_terracotta
setblock 330 204 561 minecraft:oak_log
fill 330 204 562 330 207 562 minecraft:green_terracotta
setblock 330 204 566 minecraft:oak_log
fill 330 204 567 330 204 570 minecraft:green_terracotta
setblock 330 204 571 minecraft:oak_log
fill 330 204 572 330 207 572 minecraft:green_terracotta
setblock 330 204 576 minecraft:oak_log
fill 330 204 577 330 207 577 minecraft:green_terracotta
setblock 330 204 581 minecraft:oak_log
fill 330 204 582 330 204 585 minecraft:green_terracotta
setblock 330 204 586 minecraft:oak_log
fill 330 204 587 330 207 587 minecraft:green_terracotta
setblock 330 204 591 minecraft:oak_log
fill 330 204 592 330 207 592 minecraft:green_terracotta
setblock 330 204 596 minecraft:oak_log
fill 330 204 597 330 206 598 minecraft:green_terracotta
setblock 331 204 560 minecraft:oak_log
fill 331 204 561 331 205 561 minecraft:green_terracotta
setblock 331 204 565 minecraft:oak_log
fill 331 204 566 331 207 566 minecraft:green_terracotta
setblock 331 204 576 minecraft:green_terracotta
setblock 331 204 580 minecraft:oak_log
fill 331 204 581 331 204 584 minecraft:green_terracotta
setblock 331 204 585 minecraft:oak_log
fill 331 204 586 331 207 586 minecraft:green_terracotta
setblock 331 204 590 minecraft:oak_log
fill 331 204 591 331 207 591 minecraft:green_terracotta
setblock 331 204 595 minecraft:oak_log
fill 331 204 596 331 205 596 minecraft:green_terracotta
fill 331 204 598 332 204 598 minecraft:green_terracotta
setblock 332 204 559 minecraft:oak_log
fill 332 204 564 332 207 564 minecraft:oak_leaves[persistent=true]
setblock 332 204 579 minecraft:oak_log
fill 332 204 580 332 205 580 minecraft:green_terracotta
setblock 332 204 584 minecraft:oak_log
fill 332 204 585 332 207 585 minecraft:green_terracotta
setblock 332 204 589 minecraft:oak_log
fill 332 204 590 332 207 590 minecraft:green_terracotta
setblock 333 204 558 minecraft:oak_log
setblock 333 204 559 minecraft:green_terracotta
setblock 333 204 583 minecraft:oak_log
fill 333 204 584 333 205 584 minecraft:green_terracotta
setblock 333 204 588 minecraft:oak_log
fill 333 204 589 333 205 589 minecraft:green_terracotta
setblock 333 204 598 minecraft:oak_log
setblock 334 204 558 minecraft:green_terracotta
fill 334 204 598 334 205 598 minecraft:green_terracotta
fill 335 204 560 335 205 563 minecraft:dark_oak_log
fill 336 204 559 339 205 559 minecraft:dark_oak_log
fill 336 204 564 339 205 564 minecraft:dark_oak_log
setblock 338 204 579 minecraft:oak_log
fill 339 204 570 340 204 570 minecraft:dark_oak_log
fill 339 204 575 339 204 576 minecraft:dark_oak_log
fill 339 204 577 340 209 578 minecraft:jungle_leaves[persistent=true]
fill 339 204 580 340 209 581 minecraft:jungle_leaves[persistent=true]
fill 340 204 560 340 205 560 minecraft:dark_oak_log
fill 340 204 563 340 205 563 minecraft:dark_oak_log
fill 340 204 574 341 204 575 minecraft:dark_oak_log
fill 340 204 576 343 209 576 minecraft:jungle_leaves[persistent=true]
fill 340 204 582 343 209 582 minecraft:jungle_leaves[persistent=true]
fill 341 204 561 341 205 562 minecraft:dark_oak_log
fill 341 204 573 342 204 573 minecraft:dark_oak_log
fill 342 204 571 342 204 572 minecraft:dark_oak_log
fill 342 204 574 343 208 575 minecraft:jungle_leaves[persistent=true]
fill 342 204 583 343 208 584 minecraft:jungle_leaves[persistent=true]
fill 344 204 574 344 208 574 minecraft:jungle_leaves[persistent=true]
fill 344 204 584 344 208 584 minecraft:jungle_leaves[persistent=true]
fill 345 204 576 348 207 577 minecraft:jungle_leaves[persistent=true]
fill 345 204 581 348 207 582 minecraft:jungle_leaves[persistent=true]
fill 346 204 558 347 204 558 minecraft:green_terracotta
fill 346 204 575 350 205 575 minecraft:jungle_leaves[persistent=true]
fill 346 204 583 350 205 583 minecraft:jungle_leaves[persistent=true]
setblock 346 204 598 minecraft:oak_leaves[persistent=true]
setblock 347 204 559 minecraft:oak_log
setblock 348 204 558 minecraft:oak_log
fill 348 204 559 351 204 559 minecraft:green_terracotta
fill 349 204 558 352 204 558 minecraft:green_terracotta
fill 349 204 576 349 205 576 minecraft:jungle_leaves[persistent=true]
fill 349 204 582 349 205 582 minecraft:jungle_leaves[persistent=true]
setblock 350 204 560 minecraft:green_terracotta
setblock 350 204 561 minecraft:oak_log
fill 350 204 598 352 204 598 minecraft:green_terracotta
setblock 351 204 560 minecraft:oak_log
fill 351 204 561 351 205 561 minecraft:green_terracotta
setblock 352 204 559 minecraft:oak_log
fill 352 204 560 352 206 560 minecraft:green_terracotta
setblock 353 204 558 minecraft:oak_log
fill 353 204 559 353 207 559 minecraft:green_terracotta
setblock 353 204 598 minecraft:oak_log
fill 354 204 558 354 207 558 minecraft:green_terracotta
setblock 354 204 598 minecraft:green_terracotta
setblock 355 204 561 minecraft:oak_log
setblock 356 204 560 minecraft:oak_log
fill 356 204 575 358 204 575 minecraft:jungle_leaves[persistent=true]
fill 356 204 583 358 204 583 minecraft:jungle_leaves[persistent=true]
setblock 357 204 559 minecraft:oak_log
setblock 357 204 560 minecraft:green_terracotta
setblock 358 204 558 minecraft:oak_log
fill 358 204 559 358 205 559 minecraft:green_terracotta
fill 358 204 577 359 204 577 minecraft:jungle_leaves[persistent=true]
fill 358 204 581 359 204 581 minecraft:jungle_leaves[persistent=true]
fill 359 204 558 359 206 558 minecraft:green_terracotta
setblock 362 204 559 minecraft:oak_log
setblock 363 204 558 minecraft:oak_log
setblock 363 204 559 minecraft:green_terracotta
fill 364 204 558 364 207 558 minecraft:green_terracotta
setblock 364 204 598 minecraft:green_terracotta
setblock 366 204 560 minecraft:oak_log
setblock 367 204 559 minecraft:oak_log
setblock 367 204 560 minecraft:green_terracotta
setblock 368 204 558 minecraft:oak_log
fill 368 204 559 368 207 559 minecraft:green_terracotta
setblock 368 204 563 minecraft:oak_log
fill 368 204 564 368 206 564 minecraft:green_terracotta
setblock 368 204 588 minecraft:oak_log
fill 368 204 589 368 206 590 minecraft:green_terracotta
setblock 368 204 598 minecraft:oak_log
fill 369 204 558 369 207 558 minecraft:green_terracotta
setblock 369 204 562 minecraft:oak_log
fill 369 204 563 369 207 563 minecraft:green_terracotta
setblock 369 204 566 minecraft:green_terracotta
setblock 369 204 567 minecraft:oak_log
fill 369 204 568 369 207 568 minecraft:green_terracotta
setblock 369 204 581 minecraft:green_terracotta
setblock 369 204 582 minecraft:oak_log
fill 369 204 583 369 207 583 minecraft:green_terracotta
setblock 369 204 587 minecraft:oak_log
fill 369 204 588 369 207 588 minecraft:green_terracotta
setblock 369 204 592 minecraft:oak_log
fill 369 204 593 369 207 593 minecraft:green_terracotta
setblock 369 204 597 minecraft:oak_log
fill 369 204 598 369 207 598 minecraft:green_terracotta
setblock 370 204 561 minecraft:oak_log
fill 370 204 562 370 207 562 minecraft:green_terracotta
setblock 370 204 566 minecraft:oak_log
fill 370 204 567 370 207 567 minecraft:green_terracotta
setblock 370 204 571 minecraft:oak_log
fill 370 204 572 370 207 572 minecraft:green_terracotta
fill 370 204 577 370 204 580 minecraft:green_terracotta
setblock 370 204 581 minecraft:oak_log
fill 370 204 582 370 207 582 minecraft:green_terracotta
setblock 370 204 586 minecraft:oak_log
fill 370 204 587 370 207 587 minecraft:green_terracotta
setblock 370 204 591 minecraft:oak_log
fill 370 204 592 370 207 592 minecraft:green_terracotta
setblock 370 204 596 minecraft:oak_log
fill 370 204 597 370 207 597 minecraft:green_terracotta
setblock 330 205 560 minecraft:oak_log
fill 330 205 561 330 208 561 minecraft:green_terracotta
setblock 330 205 565 minecraft:oak_log
fill 330 205 566 330 205 569 minecraft:green_terracotta
setblock 330 205 570 minecraft:oak_log
fill 330 205 571 330 208 571 minecraft:green_terracotta
setblock 330 205 575 minecraft:oak_log
fill 330 205 576 330 208 576 minecraft:green_terracotta
setblock 330 205 580 minecraft:oak_log
fill 330 205 581 330 205 584 minecraft:green_terracotta
setblock 330 205 585 minecraft:oak_log
fill 330 205 586 330 208 586 minecraft:green_terracotta
setblock 330 205 590 minecraft:oak_log
fill 330 205 591 330 208 591 minecraft:green_terracotta
setblock 330 205 595 minecraft:oak_log
fill 330 205 596 330 208 596 minecraft:green_terracotta
setblock 331 205 560 minecraft:green_terracotta
setblock 331 205 564 minecraft:oak_log
fill 331 205 565 331 207 565 minecraft:green_terracotta
setblock 331 205 569 minecraft:oak_log
fill 331 205 570 331 208 570 minecraft:green_terracotta
setblock 331 205 579 minecraft:oak_log
fill 331 205 580 331 205 583 minecraft:green_terracotta
setblock 331 205 584 minecraft:oak_log
fill 331 205 585 331 208 585 minecraft:green_terracotta
setblock 331 205 589 minecraft:oak_log
fill 331 205 590 331 208 590 minecraft:green_terracotta
setblock 331 205 594 minecraft:oak_log
fill 331 205 595 331 207 595 minecraft:green_terracotta
setblock 331 205 598 minecraft:green_terracotta
setblock 332 205 558 minecraft:oak_log
setblock 332 205 583 minecraft:oak_log
fill 332 205 584 332 208 584 minecraft:green_terracotta
setblock 332 205 588 minecraft:oak_log
fill 332 205 589 332 208 589 minecraft:green_terracotta
setblock 332 205 598 minecraft:oak_log
setblock 333 205 558 minecraft:green_terracotta
setblock 333 205 583 minecraft:green_terracotta
setblock 333 205 587 minecraft:oak_log
fill 333 205 588 333 206 588 minecraft:green_terracotta
setblock 333 205 598 minecraft:green_terracotta
fill 334 205 560 334 205 563 minecraft:dark_oak_log
setblock 335 205 559 minecraft:dark_oak_log
setblock 335 205 564 minecraft:dark_oak_log
fill 336 205 558 340 205 558 minecraft:dark_oak_log
fill 336 205 565 340 205 565 minecraft:dark_oak_log
fill 336 205 579 338 208 579 minecraft:jungle_leaves[persistent=true]
fill 337 205 576 338 208 578 minecraft:jungle_leaves[persistent=true]
fill 337 205 580 338 208 582 minecraft:jungle_leaves[persistent=true]
fill 338 205 575 341 208 575 minecraft:jungle_leaves[persistent=true]
fill 338 205 583 341 208 583 minecraft:jungle_leaves[persistent=true]
fill 339 205 574 341 208 574 minecraft:jungle_leaves[persistent=true]
fill 339 205 576 339 208 576 minecraft:jungle_leaves[persistent=true]
fill 339 205 582 339 208 582 minecraft:jungle_leaves[persistent=true]
fill 339 205 584 341 208 584 minecraft:jungle_leaves[persistent=true]
fill 340 205 559 341 205 559 minecraft:dark_oak_log
fill 340 205 564 341 205 564 minecraft:dark_oak_log
setblock 340 205 573 minecraft:oak_log
setblock 341 205 560 minecraft:dark_oak_log
setblock 341 205 563 minecraft:dark_oak_log
fill 342 205 561 342 205 562 minecraft:dark_oak_log
fill 342 205 573 342 208 573 minecraft:jungle_leaves[persistent=true]
fill 342 205 585 342 208 585 minecraft:jungle_leaves[persistent=true]
setblock 346 205 558 minecraft:green_terracotta
setblock 347 205 558 minecraft:oak_log
fill 347 205 559 350 205 559 minecraft:green_terracotta
fill 348 205 558 351 205 558 minecraft:green_terracotta
setblock 350 205 560 minecraft:oak_log
setblock 350 205 561 minecraft:green_terracotta
setblock 351 205 559 minecraft:oak_log
fill 351 205 560 351 206 560 minecraft:green_terracotta
setblock 351 205 598 minecraft:green_terracotta
setblock 352 205 558 minecraft:oak_log
fill 352 205 559 352 207 559 minecraft:green_terracotta
setblock 352 205 598 minecraft:oak_log
fill 353 205 558 353 208 558 minecraft:green_terracotta
setblock 355 205 560 minecraft:oak_log
setblock 356 205 559 minecraft:oak_log
setblock 356 205 560 minecraft:green_terracotta
setblock 357 205 558 minecraft:oak_log
setblock 357 205 559 minecraft:green_terracotta
fill 358 205 558 358 206 558 minecraft:green_terracotta
setblock 362 205 558 minecraft:oak_log
fill 363 205 558 363 206 558 minecraft:green_terracotta
setblock 366 205 559 minecraft:oak_log
setblock 367 205 558 minecraft:oak_log
fill 367 205 559 367 207 559 minecraft:green_terracotta
fill 367 205 580 368 206 580 minecraft:oak_leaves[persistent=true]
setblock 367 205 598 minecraft:oak_log
fill 368 205 558 368 208 558 minecraft:green_terracotta
setblock 368 205 562 minecraft:oak_log
fill 368 205 563 368 206 563 minecraft:green_terracotta
fill 368 205 579 368 206 579 minecraft:oak_leaves[persistent=true]
fill 368 205 581 368 206 581 minecraft:oak_leaves[persistent=true]
fill 368 205 585 368 205 586 minecraft:green_terracotta
setblock 368 205 587 minecraft:oak_log
fill 368 205 588 368 208 588 minecraft:green_terracotta
setblock 368 205 591 minecraft:green_terracotta
setblock 368 205 597 minecraft:oak_log
fill 368 205 598 368 208 598 minecraft:green_terracotta
setblock 369 205 561 minecraft:oak_log
fill 369 205 562 369 208 562 minecraft:green_terracotta
setblock 369 205 566 minecraft:oak_log
fill 369 205 567 369 208 567 minecraft:green_terracotta
setblock 369 205 581 minecraft:oak_log
fill 369 205 582 369 206 582 minecraft:green_terracotta
setblock 369 205 586 minecraft:oak_log
fill 369 205 587 369 208 587 minecraft:green_terracotta
setblock 369 205 591 minecraft:oak_log
fill 369 205 592 369 208 592 minecraft:green_terracotta
setblock 369 205 596 minecraft:oak_log
fill 369 205 597 369 208 597 minecraft:green_terracotta
setblock 370 205 560 minecraft:oak_log
fill 370 205 561 370 208 561 minecraft:green_terracotta
setblock 370 205 565 minecraft:oak_log
fill 370 205 566 370 208 566 minecraft:green_terracotta
setblock 370 205 570 minecraft:oak_log
fill 370 205 571 370 208 571 minecraft:green_terracotta
fill 370 205 578 370 205 579 minecraft:green_terracotta
setblock 370 205 580 minecraft:oak_log
fill 370 205 581 370 208 581 minecraft:green_terracotta
setblock 370 205 585 minecraft:oak_log
fill 370 205 586 370 208 586 minecraft:green_terracotta
setblock 370 205 590 minecraft:oak_log
fill 370 205 591 370 208 591 minecraft:green_terracotta
setblock 370 205 595 minecraft:oak_log
fill 370 205 596 370 208 596 minecraft:green_terracotta
setblock 330 206 559 minecraft:oak_log
fill 330 206 560 330 207 560 minecraft:green_terracotta
setblock 330 206 564 minecraft:oak_log
fill 330 206 565 330 206 568 minecraft:green_terracotta
setblock 330 206 569 minecraft:oak_log
fill 330 206 570 330 209 570 minecraft:green_terracotta
setblock 330 206 574 minecraft:oak_log
fill 330 206 575 330 209 575 minecraft:green_terracotta
setblock 330 206 579 minecraft:oak_log
fill 330 206 580 330 206 583 minecraft:green_terracotta
setblock 330 206 584 minecraft:oak_log
fill 330 206 585 330 209 585 minecraft:green_terracotta
setblock 330 206 589 minecraft:oak_log
fill 330 206 590 330 209 590 minecraft:green_terracotta
setblock 330 206 594 minecraft:oak_log
fill 330 206 595 330 209 595 minecraft:green_terracotta
setblock 331 206 558 minecraft:oak_log
setblock 331 206 563 minecraft:oak_log
fill 331 206 564 331 207 564 minecraft:green_terracotta
setblock 331 206 568 minecraft:oak_log
fill 331 206 569 331 209 569 minecraft:green_terracotta
setblock 331 206 578 minecraft:oak_log
fill 331 206 579 331 206 582 minecraft:green_terracotta
setblock 331 206 583 minecraft:oak_log
fill 331 206 584 331 209 584 minecraft:green_terracotta
setblock 331 206 588 minecraft:oak_log
fill 331 206 589 331 209 589 minecraft:green_terracotta
setblock 331 206 593 minecraft:oak_log
fill 331 206 594 331 209 594 minecraft:green_terracotta
setblock 331 206 598 minecraft:oak_log
setblock 332 206 582 minecraft:oak_log
fill 332 206 583 332 207 583 minecraft:green_terracotta
setblock 332 206 586 minecraft:green_terracotta
setblock 332 206 587 minecraft:oak_log
fill 332 206 588 332 209 588 minecraft:green_terracotta
setblock 332 206 592 minecraft:oak_log
setblock 332 206 598 minecraft:green_terracotta
setblock 333 206 586 minecraft:oak_log
setblock 333 206 587 minecraft:green_terracotta
setblock 333 206 598 minecraft:oak_leaves[persistent=true]
fill 336 206 576 336 207 578 minecraft:jungle_leaves[persistent=true]
fill 336 206 580 336 207 582 minecraft:jungle_leaves[persistent=true]
fill 337 206 575 337 207 575 minecraft:jungle_leaves[persistent=true]
fill 337 206 583 337 207 583 minecraft:jungle_leaves[persistent=true]
fill 338 206 574 338 207 574 minecraft:jungle_leaves[persistent=true]
fill 338 206 584 338 207 584 minecraft:jungle_leaves[persistent=true]
fill 339 206 573 341 207 573 minecraft:jungle_leaves[persistent=true]
fill 339 206 585 341 207 585 minecraft:jungle_leaves[persistent=true]
fill 339 206 598 339 207 598 minecraft:oak_leaves[persistent=true]
fill 341 206 566 342 207 567 minecraft:oak_leaves[persistent=true]
setblock 342 206 558 minecraft:oak_leaves[persistent=true]
fill 343 206 573 345 207 573 minecraft:jungle_leaves[persistent=true]
fill 343 206 585 345 207 585 minecraft:jungle_leaves[persistent=true]
setblock 346 206 558 minecraft:oak_log
fill 346 206 574 346 207 575 minecraft:jungle_leaves[persistent=true]
fill 346 206 583 346 207 584 minecraft:jungle_leaves[persistent=true]
fill 347 206 558 350 206 558 minecraft:green_terracotta
fill 347 206 575 347 207 575 minecraft:jungle_leaves[persistent=true]
fill 347 206 583 347 207 583 minecraft:jungle_leaves[persistent=true]
fill 348 206 559 349 206 559 minecraft:green_terracotta
setblock 349 206 560 minecraft:oak_log
setblock 350 206 559 minecraft:oak_log
setblock 350 206 560 minecraft:green_terracotta
setblock 351 206 558 minecraft:oak_log
fill 351 206 559 351 208 559 minecraft:green_terracotta
fill 352 206 558 352 209 558 minecraft:green_terracotta
setblock 355 206 559 minecraft:oak_log
setblock 356 206 558 minecraft:oak_log
setblock 356 206 559 minecraft:green_terracotta
setblock 357 206 558 minecraft:green_terracotta
setblock 358 206 598 minecraft:oak_leaves[persistent=true]
setblock 361 206 558 minecraft:oak_log
setblock 362 206 558 minecraft:green_terracotta
setblock 366 206 558 minecraft:oak_log
setblock 366 206 559 minecraft:green_terracotta
setblock 366 206 598 minecraft:oak_log
fill 367 206 558 367 209 558 minecraft:green_terracotta
fill 367 206 598 367 209 598 minecraft:green_terracotta
setblock 368 206 585 minecraft:green_terracotta
setblock 368 206 586 minecraft:oak_log
fill 368 206 587 368 209 587 minecraft:green_terracotta
setblock 368 206 591 minecraft:oak_log
fill 368 206 592 368 209 592 minecraft:green_terracotta
fill 368 206 597 368 209 597 minecraft:green_terracotta
setblock 369 206 560 minecraft:oak_log
fill 369 206 561 369 207 561 minecraft:green_terracotta
setblock 369 206 565 minecraft:oak_log
fill 369 206 566 369 209 566 minecraft:green_terracotta
setblock 369 206 569 minecraft:green_terracotta
setblock 369 206 585 minecraft:oak_log
fill 369 206 586 369 209 586 minecraft:green_terracotta
setblock 369 206 590 minecraft:oak_log
fill 369 206 591 369 209 591 minecraft:green_terracotta
setblock 369 206 595 minecraft:oak_log
fill 369 206 596 369 209 596 minecraft:green_terracotta
setblock 370 206 559 minecraft:oak_log
fill 370 206 560 370 209 560 minecraft:green_terracotta
setblock 370 206 564 minecraft:oak_log
fill 370 206 565 370 209 565 minecraft:green_terracotta
setblock 370 206 569 minecraft:oak_log
fill 370 206 570 370 209 570 minecraft:green_terracotta
setblock 370 206 574 minecraft:oak_leaves[persistent=true]
setblock 370 206 579 minecraft:oak_log
fill 370 206 580 370 208 580 minecraft:green_terracotta
setblock 370 206 584 minecraft:oak_log
fill 370 206 585 370 209 585 minecraft:green_terracotta
setblock 370 206 589 minecraft:oak_log
fill 370 206 590 370 209 590 minecraft:green_terracotta
setblock 370 206 594 minecraft:oak_log
fill 370 206 595 370 209 595 minecraft:green_terracotta
setblock 330 207 563 minecraft:oak_log
fill 330 207 564 330 207 567 minecraft:green_terracotta
setblock 330 207 568 minecraft:oak_log
fill 330 207 569 330 210 569 minecraft:green_terracotta
setblock 330 207 573 minecraft:oak_log
fill 330 207 574 330 210 574 minecraft:green_terracotta
setblock 330 207 578 minecraft:oak_log
fill 330 207 579 330 207 582 minecraft:green_terracotta
setblock 330 207 583 minecraft:oak_log
fill 330 207 584 330 210 584 minecraft:green_terracotta
setblock 330 207 588 minecraft:oak_log
fill 330 207 589 330 210 589 minecraft:green_terracotta
setblock 330 207 593 minecraft:oak_log
fill 330 207 594 330 210 594 minecraft:green_terracotta
setblock 330 207 597 minecraft:green_terracotta
setblock 330 207 598 minecraft:oak_log
setblock 331 207 567 minecraft:oak_log
fill 331 207 568 331 210 568 minecraft:green_terracotta
fill 331 207 579 331 207 581 minecraft:green_terracotta
setblock 331 207 582 minecraft:oak_log
fill 331 207 583 331 210 583 minecraft:green_terracotta
setblock 331 207 587 minecraft:oak_log
fill 331 207 588 331 210 588 minecraft:green_terracotta
setblock 331 207 592 minecraft:oak_log
fill 331 207 593 331 210 593 minecraft:green_terracotta
setblock 331 207 598 minecraft:green_terracotta
setblock 332 207 582 minecraft:green_terracotta
setblock 332 207 586 minecraft:oak_log
fill 332 207 587 332 210 587 minecraft:green_terracotta
setblock 332 207 591 minecraft:oak_log
setblock 332 207 592 minecraft:green_terracotta
setblock 336 207 558 minecraft:oak_leaves[persistent=true]
setblock 345 207 598 minecraft:oak_leaves[persistent=true]
fill 347 207 558 349 207 558 minecraft:green_terracotta
setblock 348 207 559 minecraft:green_terracotta
setblock 349 207 559 minecraft:oak_log
setblock 350 207 558 minecraft:oak_log
fill 350 207 559 350 208 559 minecraft:green_terracotta
fill 351 207 558 351 210 558 minecraft:green_terracotta
setblock 354 207 559 minecraft:oak_log
setblock 355 207 558 minecraft:oak_log
setblock 356 207 558 minecraft:green_terracotta
setblock 364 207 598 minecraft:oak_leaves[persistent=true]
setblock 365 207 558 minecraft:oak_log
setblock 365 207 598 minecraft:oak_log
fill 366 207 558 366 210 558 minecraft:green_terracotta
fill 366 207 598 366 210 598 minecraft:green_terracotta
fill 367 207 597 367 210 597 minecraft:green_terracotta
fill 368 207 586 368 210 586 minecraft:green_terracotta
setblock 368 207 589 minecraft:green_terracotta
setblock 368 207 590 minecraft:oak_log
fill 368 207 591 368 210 591 minecraft:green_terracotta
fill 368 207 593 368 208 593 minecraft:green_terracotta
setblock 369 207 559 minecraft:oak_log
setblock 369 207 560 minecraft:green_terracotta
setblock 369 207 564 minecraft:oak_log
fill 369 207 565 369 210 565 minecraft:green_terracotta
setblock 369 207 569 minecraft:oak_log
setblock 369 207 584 minecraft:oak_log
fill 369 207 585 369 210 585 minecraft:green_terracotta
setblock 369 207 589 minecraft:oak_log
fill 369 207 590 369 210 590 minecraft:green_terracotta
setblock 369 207 594 minecraft:oak_log
fill 369 207 595 369 210 595 minecraft:green_terracotta
setblock 370 207 558 minecraft:oak_log
fill 370 207 559 370 209 559 minecraft:green_terracotta
setblock 370 207 563 minecraft:oak_log
fill 370 207 564 370 210 564 minecraft:green_terracotta
setblock 370 207 568 minecraft:oak_log
fill 370 207 569 370 210 569 minecraft:green_terracotta
setblock 370 207 583 minecraft:oak_log
fill 370 207 584 370 210 584 minecraft:green_terracotta
setblock 370 207 588 minecraft:oak_log
fill 370 207 589 370 210 589 minecraft:green_terracotta
setblock 370 207 593 minecraft:oak_log
fill 370 207 594 370 210 594 minecraft:green_terracotta
setblock 370 207 598 minecraft:oak_log
setblock 330 208 562 minecraft:oak_log
fill 330 208 563 330 208 566 minecraft:green_terracotta
setblock 330 208 567 minecraft:oak_log
fill 330 208 568 330 211 568 minecraft:green_terracotta
setblock 330 208 572 minecraft:oak_log
fill 330 208 573 330 211 573 minecraft:green_terracotta
setblock 330 208 577 minecraft:oak_log
fill 330 208 578 330 208 581 minecraft:green_terracotta
setblock 330 208 582 minecraft:oak_log
fill 330 208 583 330 211 583 minecraft:green_terracotta
setblock 330 208 587 minecraft:oak_log
fill 330 208 588 330 211 588 minecraft:green_terracotta
setblock 330 208 592 minecraft:oak_log
fill 330 208 593 330 211 593 minecraft:green_terracotta
setblock 330 208 597 minecraft:oak_log
fill 330 208 598 330 209 598 minecraft:green_terracotta
setblock 331 208 566 minecraft:oak_log
fill 331 208 567 331 210 567 minecraft:green_terracotta
setblock 331 208 580 minecraft:green_terracotta
setblock 331 208 581 minecraft:oak_log
fill 331 208 582 331 210 582 minecraft:green_terracotta
setblock 331 208 586 minecraft:oak_log
fill 331 208 587 331 211 587 minecraft:green_terracotta
setblock 331 208 591 minecraft:oak_log
fill 331 208 592 331 211 592 minecraft:green_terracotta
setblock 332 208 585 minecraft:oak_log
fill 332 208 586 332 209 586 minecraft:green_terracotta
setblock 332 208 590 minecraft:oak_log
fill 332 208 591 332 209 591 minecraft:green_terracotta
fill 338 208 573 338 210 574 minecraft:oak_leaves[persistent=true]
fill 339 208 572 341 210 573 minecraft:oak_leaves[persistent=true]
fill 345 208 576 347 208 577 minecraft:jungle_leaves[persistent=true]
fill 345 208 581 347 208 582 minecraft:jungle_leaves[persistent=true]
setblock 346 208 575 minecraft:jungle_leaves[persistent=true]
setblock 346 208 583 minecraft:jungle_leaves[persistent=true]
fill 347 208 558 348 208 558 minecraft:green_terracotta
setblock 349 208 558 minecraft:oak_log
setblock 349 208 559 minecraft:green_terracotta
fill 350 208 558 350 211 558 minecraft:green_terracotta
setblock 351 208 598 minecraft:oak_leaves[persistent=true]
setblock 354 208 558 minecraft:oak_log
setblock 364 208 558 minecraft:oak_log
setblock 364 208 598 minecraft:oak_log
fill 365 208 558 365 211 558 minecraft:green_terracotta
fill 365 208 598 365 211 598 minecraft:green_terracotta
setblock 368 208 589 minecraft:oak_log
fill 368 208 590 368 211 590 minecraft:green_terracotta
setblock 368 208 594 minecraft:oak_log
setblock 369 208 558 minecraft:oak_log
setblock 369 208 563 minecraft:oak_log
fill 369 208 564 369 209 564 minecraft:green_terracotta
setblock 369 208 568 minecraft:oak_log
fill 369 208 569 369 211 569 minecraft:green_terracotta
setblock 369 208 583 minecraft:oak_log
fill 369 208 584 369 211 584 minecraft:green_terracotta
setblock 369 208 588 minecraft:oak_log
fill 369 208 589 369 211 589 minecraft:green_terracotta
setblock 369 208 593 minecraft:oak_log
fill 369 208 594 369 211 594 minecraft:green_terracotta
setblock 369 208 598 minecraft:oak_log
fill 370 208 558 370 209 558 minecraft:green_terracotta
setblock 370 208 562 minecraft:oak_log
fill 370 208 563 370 211 563 minecraft:green_terracotta
setblock 370 208 567 minecraft:oak_log
fill 370 208 568 370 211 568 minecraft:green_terracotta
setblock 370 208 572 minecraft:oak_log
setblock 370 208 582 minecraft:oak_log
fill 370 208 583 370 211 583 minecraft:green_terracotta
setblock 370 208 587 minecraft:oak_log
fill 370 208 588 370 211 588 minecraft:green_terracotta
setblock 370 208 592 minecraft:oak_log
fill 370 208 593 370 211 593 minecraft:green_terracotta
setblock 370 208 597 minecraft:oak_log
fill 370 208 598 370 211 598 minecraft:green_terracotta
fill 330 209 563 330 209 565 minecraft:green_terracotta
setblock 330 209 566 minecraft:oak_log
fill 330 209 567 330 212 567 minecraft:green_terracotta
setblock 330 209 571 minecraft:oak_log
fill 330 209 572 330 212 572 minecraft:green_terracotta
setblock 330 209 576 minecraft:oak_log
fill 330 209 577 330 209 580 minecraft:green_terracotta
setblock 330 209 581 minecraft:oak_log
fill 330 209 582 330 212 582 minecraft:green_terracotta
setblock 330 209 586 minecraft:oak_log
fill 330 209 587 330 212 587 minecraft:green_terracotta
setblock 330 209 591 minecraft:oak_log
fill 330 209 592 330 212 592 minecraft:green_terracotta
setblock 330 209 596 minecraft:oak_log
fill 330 209 597 330 212 597 minecraft:green_terracotta
setblock 331 209 570 minecraft:oak_log
fill 331 209 571 331 212 571 minecraft:green_terracotta
setblock 331 209 581 minecraft:green_terracotta
setblock 331 209 585 minecraft:oak_log
fill 331 209 586 331 212 586 minecraft:green_terracotta
setblock 331 209 590 minecraft:oak_log
fill 331 209 591 331 212 591 minecraft:green_terracotta
setblock 332 209 560 minecraft:light[level=14]
setblock 332 209 568 minecraft:light[level=14]
setblock 332 209 576 minecraft:light[level=14]
setblock 332 209 584 minecraft:light[level=14]
setblock 332 209 585 minecraft:green_terracotta
setblock 332 209 589 minecraft:oak_log
fill 332 209 590 332 210 590 minecraft:green_terracotta
setblock 332 209 592 minecraft:light[level=14]
setblock 332 209 598 minecraft:oak_leaves[persistent=true]
fill 337 209 577 338 233 579 minecraft:oak_log
setblock 338 209 572 minecraft:oak_leaves[persistent=true]
fill 338 209 575 341 209 575 minecraft:oak_leaves[persistent=true]
fill 338 209 576 339 213 576 minecraft:dark_oak_log
fill 339 209 574 342 209 574 minecraft:oak_leaves[persistent=true]
setblock 340 209 560 minecraft:light[level=14]
setblock 340 209 568 minecraft:light[level=14]
setblock 340 209 584 minecraft:light[level=14]
setblock 340 209 592 minecraft:light[level=14]
setblock 342 209 573 minecraft:oak_leaves[persistent=true]
setblock 343 209 558 minecraft:oak_leaves[persistent=true]
fill 344 209 576 344 209 578 minecraft:jungle_leaves[persistent=true]
fill 344 209 580 344 209 582 minecraft:jungle_leaves[persistent=true]
fill 345 209 577 345 209 578 minecraft:jungle_leaves[persistent=true]
fill 345 209 580 345 209 581 minecraft:jungle_leaves[persistent=true]
setblock 347 209 558 minecraft:green_terracotta
setblock 348 209 558 minecraft:oak_log
setblock 348 209 560 minecraft:light[level=14]
setblock 348 209 568 minecraft:light[level=14]
setblock 348 209 576 minecraft:light[level=14]
setblock 348 209 584 minecraft:light[level=14]
setblock 348 209 592 minecraft:light[level=14]
fill 349 209 558 349 212 558 minecraft:green_terracotta
setblock 353 209 558 minecraft:oak_log
setblock 356 209 560 minecraft:light[level=14]
setblock 356 209 568 minecraft:light[level=14]
setblock 356 209 576 minecraft:light[level=14]
setblock 356 209 584 minecraft:light[level=14]
setblock 356 209 592 minecraft:light[level=14]
setblock 357 209 598 minecraft:oak_leaves[persistent=true]
setblock 364 209 560 minecraft:light[level=14]
setblock 364 209 568 minecraft:light[level=14]
setblock 364 209 576 minecraft:light[level=14]
setblock 364 209 584 minecraft:light[level=14]
setblock 364 209 592 minecraft:light[level=14]
fill 364 209 598 364 212 598 minecraft:green_terracotta
fill 366 209 597 366 211 597 minecraft:green_terracotta
setblock 368 209 558 minecraft:oak_log
setblock 368 209 588 minecraft:oak_log
fill 368 209 589 368 212 589 minecraft:green_terracotta
setblock 368 209 593 minecraft:oak_log
fill 368 209 594 368 212 594 minecraft:green_terracotta
setblock 368 209 598 minecraft:oak_log
fill 369 209 558 369 212 558 minecraft:green_terracotta
setblock 369 209 567 minecraft:oak_log
fill 369 209 568 369 212 568 minecraft:green_terracotta
setblock 369 209 587 minecraft:oak_log
fill 369 209 588 369 212 588 minecraft:green_terracotta
setblock 369 209 592 minecraft:oak_log
fill 369 209 593 369 212 593 minecraft:green_terracotta
setblock 369 209 597 minecraft:oak_log
fill 369 209 598 369 212 598 minecraft:green_terracotta
setblock 370 209 561 minecraft:oak_log
fill 370 209 562 370 210 562 minecraft:green_terracotta
setblock 370 209 566 minecraft:oak_log
fill 370 209 567 370 212 567 minecraft:green_terracotta
setblock 370 209 571 minecraft:oak_log
fill 370 209 572 370 212 572 minecraft:green_terracotta
setblock 370 209 575 minecraft:oak_leaves[persistent=true]
setblock 370 209 581 minecraft:oak_log
fill 370 209 582 370 212 582 minecraft:green_terracotta
setblock 370 209 586 minecraft:oak_log
fill 370 209 587 370 212 587 minecraft:green_terracotta
setblock 370 209 591 minecraft:oak_log
fill 370 209 592 370 212 592 minecraft:green_terracotta
setblock 370 209 596 minecraft:oak_log
fill 370 209 597 370 212 597 minecraft:green_terracotta
setblock 330 210 562 minecraft:oak_leaves[persistent=true]
setblock 330 210 564 minecraft:green_terracotta
setblock 330 210 565 minecraft:oak_log
fill 330 210 566 330 213 566 minecraft:green_terracotta
setblock 330 210 570 minecraft:oak_log
fill 330 210 571 330 213 571 minecraft:green_terracotta
setblock 330 210 575 minecraft:oak_log
fill 330 210 576 330 210 579 minecraft:green_terracotta
setblock 330 210 580 minecraft:oak_log
fill 330 210 581 330 213 581 minecraft:green_terracotta
setblock 330 210 585 minecraft:oak_log
fill 330 210 586 330 213 586 minecraft:green_terracotta
setblock 330 210 590 minecraft:oak_log
fill 330 210 591 330 213 591 minecraft:green_terracotta
setblock 330 210 595 minecraft:oak_log
fill 330 210 596 330 213 596 minecraft:green_terracotta
setblock 331 210 569 minecraft:oak_log
fill 331 210 570 331 213 570 minecraft:green_terracotta
fill 331 210 572 331 211 572 minecraft:green_terracotta
setblock 331 210 584 minecraft:oak_log
fill 331 210 585 331 213 585 minecraft:green_terracotta
setblock 331 210 589 minecraft:oak_log
fill 331 210 590 331 213 590 minecraft:green_terracotta
setblock 331 210 594 minecraft:oak_log
setblock 332 210 588 minecraft:oak_log
fill 332 210 589 332 211 589 minecraft:green_terracotta
setblock 337 210 558 minecraft:oak_leaves[persistent=true]
fill 337 210 575 337 213 576 minecraft:dark_oak_log
fill 338 210 575 338 213 575 minecraft:dark_oak_log
setblock 338 210 598 minecraft:oak_leaves[persistent=true]
fill 339 210 574 340 210 575 minecraft:oak_leaves[persistent=true]
fill 339 210 577 339 233 579 minecraft:oak_log
fill 340 210 576 340 213 577 minecraft:dark_oak_log
setblock 341 210 574 minecraft:oak_leaves[persistent=true]
fill 341 210 575 341 213 576 minecraft:dark_oak_log
setblock 346 210 558 minecraft:green_terracotta
setblock 347 210 558 minecraft:oak_log
fill 348 210 558 348 213 558 minecraft:green_terracotta
setblock 352 210 558 minecraft:oak_log
setblock 362 210 558 minecraft:oak_leaves[persistent=true]
fill 363 210 598 363 213 598 minecraft:green_terracotta
fill 365 210 597 365 212 597 minecraft:green_terracotta
setblock 367 210 558 minecraft:oak_log
setblock 367 210 598 minecraft:oak_log
fill 368 210 558 368 213 558 minecraft:green_terracotta
setblock 368 210 587 minecraft:oak_log
fill 368 210 588 368 213 588 minecraft:green_terracotta
setblock 368 210 592 minecraft:oak_log
fill 368 210 593 368 213 593 minecraft:green_terracotta
fill 368 210 595 368 211 595 minecraft:green_terracotta
setblock 368 210 597 minecraft:oak_log
fill 368 210 598 368 213 598 minecraft:green_terracotta
setblock 369 210 566 minecraft:oak_log
fill 369 210 567 369 213 567 minecraft:green_terracotta
setblock 369 210 586 minecraft:oak_log
fill 369 210 587 369 213 587 minecraft:green_terracotta
setblock 369 210 591 minecraft:oak_log
fill 369 210 592 369 213 592 minecraft:green_terracotta
setblock 369 210 596 minecraft:oak_log
fill 369 210 597 369 213 597 minecraft:green_terracotta
setblock 370 210 561 minecraft:green_terracotta
setblock 370 210 565 minecraft:oak_log
fill 370 210 566 370 213 566 minecraft:green_terracotta
setblock 370 210 570 minecraft:oak_log
fill 370 210 571 370 213 571 minecraft:green_terracotta
fill 370 210 573 370 211 573 minecraft:green_terracotta
fill 370 210 581 370 213 581 minecraft:green_terracotta
setblock 370 210 585 minecraft:oak_log
fill 370 210 586 370 213 586 minecraft:green_terracotta
setblock 370 210 590 minecraft:oak_log
fill 370 210 591 370 213 591 minecraft:green_terracotta
setblock 370 210 595 minecraft:oak_log
fill 370 210 596 370 213 596 minecraft:green_terracotta
setblock 330 211 564 minecraft:oak_log
fill 330 211 565 330 214 565 minecraft:green_terracotta
setblock 330 211 569 minecraft:oak_log
fill 330 211 570 330 214 570 minecraft:green_terracotta
setblock 330 211 574 minecraft:oak_log
fill 330 211 575 330 211 578 minecraft:green_terracotta
setblock 330 211 579 minecraft:oak_log
fill 330 211 580 330 214 580 minecraft:green_terracotta
setblock 330 211 584 minecraft:oak_log
fill 330 211 585 330 214 585 minecraft:green_terracotta
setblock 330 211 589 minecraft:oak_log
fill 330 211 590 330 214 590 minecraft:green_terracotta
setblock 330 211 594 minecraft:oak_log
fill 330 211 595 330 214 595 minecraft:green_terracotta
setblock 330 211 598 minecraft:green_terracotta
setblock 331 211 558 minecraft:oak_leaves[persistent=true]
setblock 331 211 568 minecraft:oak_log
fill 331 211 569 331 214 569 minecraft:green_terracotta
setblock 331 211 573 minecraft:oak_log
fill 331 211 574 331 214 574 minecraft:green_terracotta
setblock 331 211 583 minecraft:oak_log
fill 331 211 584 331 213 584 minecraft:green_terracotta
setblock 331 211 588 minecraft:oak_log
fill 331 211 589 331 214 589 minecraft:green_terracotta
setblock 331 211 593 minecraft:oak_log
fill 331 211 594 331 214 594 minecraft:green_terracotta
fill 337 211 574 341 213 574 minecraft:dark_oak_log
fill 338 211 573 340 213 573 minecraft:dark_oak_log
fill 339 211 575 340 213 575 minecraft:dark_oak_log
fill 341 211 577 341 213 577 minecraft:dark_oak_log
setblock 344 211 598 minecraft:oak_leaves[persistent=true]
setblock 346 211 558 minecraft:oak_log
fill 347 211 558 347 214 558 minecraft:green_terracotta
fill 349 211 593 349 212 593 minecraft:oak_leaves[persistent=true]
fill 349 211 598 349 212 598 minecraft:green_terracotta
setblock 351 211 558 minecraft:oak_log
fill 352 211 558 352 214 558 minecraft:green_terracotta
setblock 356 211 558 minecraft:oak_leaves[persistent=true]
fill 362 211 598 362 214 598 minecraft:green_terracotta
fill 364 211 558 364 212 558 minecraft:green_terracotta
fill 364 211 597 364 213 597 minecraft:green_terracotta
setblock 366 211 558 minecraft:oak_log
fill 366 211 596 367 211 596 minecraft:green_terracotta
setblock 366 211 598 minecraft:oak_log
fill 367 211 558 367 214 558 minecraft:green_terracotta
fill 367 211 590 367 211 591 minecraft:green_terracotta
setblock 367 211 592 minecraft:oak_log
fill 367 211 593 367 214 593 minecraft:green_terracotta
setblock 367 211 597 minecraft:oak_log
fill 367 211 598 367 214 598 minecraft:green_terracotta
setblock 368 211 586 minecraft:oak_log
fill 368 211 587 368 214 587 minecraft:green_terracotta
setblock 368 211 591 minecraft:oak_log
fill 368 211 592 368 214 592 minecraft:green_terracotta
setblock 368 211 596 minecraft:oak_log
fill 368 211 597 368 214 597 minecraft:green_terracotta
setblock 369 211 566 minecraft:green_terracotta
setblock 369 211 570 minecraft:oak_log
setblock 369 211 585 minecraft:oak_log
fill 369 211 586 369 214 586 minecraft:green_terracotta
setblock 369 211 590 minecraft:oak_log
fill 369 211 591 369 214 591 minecraft:green_terracotta
setblock 369 211 595 minecraft:oak_log
fill 369 211 596 369 214 596 minecraft:green_terracotta
setblock 370 211 564 minecraft:oak_log
fill 370 211 565 370 214 565 minecraft:green_terracotta
setblock 370 211 569 minecraft:oak_log
fill 370 211 570 370 214 570 minecraft:green_terracotta
setblock 370 211 574 minecraft:oak_log
fill 370 211 575 370 214 575 minecraft:green_terracotta
setblock 370 211 584 minecraft:oak_log
fill 370 211 585 370 214 585 minecraft:green_terracotta
setblock 370 211 589 minecraft:oak_log
fill 370 211 590 370 214 590 minecraft:green_terracotta
setblock 370 211 594 minecraft:oak_log
fill 370 211 595 370 214 595 minecraft:green_terracotta
setblock 330 212 564 minecraft:green_terracotta
setblock 330 212 568 minecraft:oak_log
fill 330 212 569 330 215 569 minecraft:green_terracotta
setblock 330 212 573 minecraft:oak_log
fill 330 212 574 330 212 577 minecraft:green_terracotta
setblock 330 212 578 minecraft:oak_log
fill 330 212 579 330 215 579 minecraft:green_terracotta
setblock 330 212 583 minecraft:oak_log
fill 330 212 584 330 215 584 minecraft:green_terracotta
setblock 330 212 588 minecraft:oak_log
fill 330 212 589 330 215 589 minecraft:green_terracotta
setblock 330 212 593 minecraft:oak_log
fill 330 212 594 330 215 594 minecraft:green_terracotta
setblock 330 212 598 minecraft:oak_log
fill 331 212 568 331 215 568 minecraft:green_terracotta
setblock 331 212 572 minecraft:oak_log
fill 331 212 573 331 215 573 minecraft:green_terracotta
fill 331 212 575 331 213 575 minecraft:green_terracotta
setblock 331 212 587 minecraft:oak_log
fill 331 212 588 331 215 588 minecraft:green_terracotta
setblock 331 212 592 minecraft:oak_log
fill 331 212 593 331 215 593 minecraft:green_terracotta
fill 331 212 595 331 213 595 minecraft:green_terracotta
setblock 331 212 598 minecraft:oak_leaves[persistent=true]
fill 336 212 575 336 213 576 minecraft:dark_oak_log
fill 340 212 578 340 213 578 minecraft:dark_oak_log
fill 341 212 573 341 213 573 minecraft:dark_oak_log
fill 342 212 575 342 213 576 minecraft:dark_oak_log
setblock 344 212 558 minecraft:green_terracotta
setblock 345 212 558 minecraft:oak_log
fill 346 212 558 346 215 558 minecraft:green_terracotta
fill 346 212 598 348 213 598 minecraft:green_terracotta
setblock 348 212 559 minecraft:green_terracotta
setblock 350 212 558 minecraft:oak_log
setblock 350 212 598 minecraft:oak_log
fill 351 212 558 351 215 558 minecraft:green_terracotta
fill 351 212 598 351 215 598 minecraft:green_terracotta
setblock 360 212 598 minecraft:oak_log
fill 361 212 598 361 215 598 minecraft:green_terracotta
fill 362 212 558 363 213 558 minecraft:green_terracotta
fill 362 212 597 363 214 597 minecraft:green_terracotta
fill 364 212 596 366 212 596 minecraft:green_terracotta
setblock 365 212 558 minecraft:oak_log
setblock 365 212 598 minecraft:oak_log
fill 366 212 558 366 215 558 minecraft:green_terracotta
setblock 366 212 597 minecraft:oak_log
fill 366 212 598 366 215 598 minecraft:green_terracotta
fill 367 212 589 367 212 590 minecraft:green_terracotta
setblock 367 212 591 minecraft:oak_log
fill 367 212 592 367 215 592 minecraft:green_terracotta
fill 367 212 594 367 212 595 minecraft:green_terracotta
setblock 367 212 596 minecraft:oak_log
fill 367 212 597 367 215 597 minecraft:green_terracotta
fill 368 212 586 368 215 586 minecraft:green_terracotta
setblock 368 212 590 minecraft:oak_log
fill 368 212 591 368 215 591 minecraft:green_terracotta
setblock 368 212 595 minecraft:oak_log
fill 368 212 596 368 215 596 minecraft:green_terracotta
setblock 369 212 569 minecraft:oak_log
fill 369 212 570 369 213 572 minecraft:green_terracotta
setblock 369 212 584 minecraft:oak_log
fill 369 212 585 369 215 585 minecraft:green_terracotta
setblock 369 212 589 minecraft:oak_log
fill 369 212 590 369 215 590 minecraft:green_terracotta
setblock 369 212 594 minecraft:oak_log
fill 369 212 595 369 215 595 minecraft:green_terracotta
setblock 370 212 564 minecraft:green_terracotta
setblock 370 212 568 minecraft:oak_log
fill 370 212 569 370 215 569 minecraft:green_terracotta
setblock 370 212 573 minecraft:oak_log
fill 370 212 574 370 215 574 minecraft:green_terracotta
fill 370 212 576 370 212 577 minecraft:green_terracotta
setblock 370 212 583 minecraft:oak_log
fill 370 212 584 370 215 584 minecraft:green_terracotta
setblock 370 212 588 minecraft:oak_log
fill 370 212 589 370 215 589 minecraft:green_terracotta
setblock 370 212 593 minecraft:oak_log
fill 370 212 594 370 215 594 minecraft:green_terracotta
setblock 370 212 598 minecraft:oak_log
setblock 330 213 561 minecraft:oak_leaves[persistent=true]
setblock 330 213 567 minecraft:oak_log
fill 330 213 568 330 216 568 minecraft:green_terracotta
setblock 330 213 572 minecraft:oak_log
fill 330 213 573 330 213 576 minecraft:green_terracotta
setblock 330 213 577 minecraft:oak_log
fill 330 213 578 330 216 578 minecraft:green_terracotta
setblock 330 213 582 minecraft:oak_log
fill 330 213 583 330 216 583 minecraft:green_terracotta
setblock 330 213 587 minecraft:oak_log
fill 330 213 588 330 216 588 minecraft:green_terracotta
setblock 330 213 592 minecraft:oak_log
fill 330 213 593 330 216 593 minecraft:green_terracotta
setblock 330 213 597 minecraft:oak_log
fill 330 213 598 330 216 598 minecraft:green_terracotta
setblock 331 213 571 minecraft:oak_log
fill 331 213 572 331 216 572 minecraft:green_terracotta
setblock 331 213 576 minecraft:oak_log
fill 331 213 577 331 216 577 minecraft:green_terracotta
setblock 331 213 586 minecraft:oak_log
fill 331 213 587 331 215 587 minecraft:green_terracotta
setblock 331 213 591 minecraft:oak_log
fill 331 213 592 331 216 592 minecraft:green_terracotta
setblock 336 213 577 minecraft:dark_oak_log
setblock 337 213 598 minecraft:oak_leaves[persistent=true]
fill 338 213 558 338 214 558 minecraft:oak_leaves[persistent=true]
fill 338 213 572 340 213 572 minecraft:dark_oak_log
setblock 341 213 578 minecraft:dark_oak_log
setblock 342 213 574 minecraft:dark_oak_log
setblock 342 213 577 minecraft:dark_oak_log
setblock 343 213 558 minecraft:green_terracotta
setblock 344 213 558 minecraft:oak_log
setblock 344 213 598 minecraft:oak_log
fill 345 213 558 345 216 558 minecraft:green_terracotta
fill 345 213 598 345 216 598 minecraft:green_terracotta
fill 346 213 559 347 213 559 minecraft:green_terracotta
fill 347 213 597 348 214 597 minecraft:green_terracotta
setblock 348 213 559 minecraft:oak_log
setblock 349 213 558 minecraft:oak_log
fill 349 213 559 349 216 559 minecraft:green_terracotta
setblock 349 213 598 minecraft:oak_log
fill 350 213 558 350 216 558 minecraft:green_terracotta
fill 350 213 598 350 216 598 minecraft:green_terracotta
fill 352 213 598 353 213 598 minecraft:green_terracotta
setblock 353 213 558 minecraft:green_terracotta
setblock 356 213 598 minecraft:oak_leaves[persistent=true]
fill 357 213 598 358 213 598 minecraft:green_terracotta
setblock 359 213 598 minecraft:oak_log
setblock 360 213 597 minecraft:oak_log
fill 360 213 598 360 216 598 minecraft:green_terracotta
fill 361 213 558 361 215 558 minecraft:green_terracotta
fill 361 213 597 361 216 597 minecraft:green_terracotta
fill 362 213 596 365 213 596 minecraft:green_terracotta
setblock 364 213 558 minecraft:oak_log
fill 364 213 595 366 213 595 minecraft:green_terracotta
setblock 364 213 598 minecraft:oak_log
fill 365 213 558 365 216 558 minecraft:green_terracotta
setblock 365 213 597 minecraft:oak_log
fill 365 213 598 365 216 598 minecraft:green_terracotta
setblock 366 213 596 minecraft:oak_log
fill 366 213 597 366 216 597 minecraft:green_terracotta
setblock 367 213 589 minecraft:green_terracotta
setblock 367 213 590 minecraft:oak_log
fill 367 213 591 367 216 591 minecraft:green_terracotta
setblock 367 213 594 minecraft:green_terracotta
setblock 367 213 595 minecraft:oak_log
fill 367 213 596 367 216 596 minecraft:green_terracotta
setblock 368 213 589 minecraft:oak_log
fill 368 213 590 368 216 590 minecraft:green_terracotta
setblock 368 213 594 minecraft:oak_log
fill 368 213 595 368 216 595 minecraft:green_terracotta
setblock 369 213 558 minecraft:oak_log
setblock 369 213 568 minecraft:oak_log
fill 369 213 569 369 216 569 minecraft:green_terracotta
setblock 369 213 573 minecraft:oak_log
fill 369 213 574 369 216 574 minecraft:green_terracotta
fill 369 213 584 369 216 584 minecraft:green_terracotta
setblock 369 213 588 minecraft:oak_log
fill 369 213 589 369 216 589 minecraft:green_terracotta
setblock 369 213 593 minecraft:oak_log
fill 369 213 594 369 216 594 minecraft:green_terracotta
setblock 369 213 598 minecraft:oak_log
setblock 370 213 567 minecraft:oak_log
fill 370 213 568 370 216 568 minecraft:green_terracotta
setblock 370 213 572 minecraft:oak_log
fill 370 213 573 370 216 573 minecraft:green_terracotta
setblock 370 213 576 minecraft:green_terracotta
setblock 370 213 577 minecraft:oak_log
fill 370 213 578 370 214 580 minecraft:green_terracotta
setblock 370 213 582 minecraft:oak_log
fill 370 213 583 370 216 583 minecraft:green_terracotta
setblock 370 213 587 minecraft:oak_log
fill 370 213 588 370 216 588 minecraft:green_terracotta
setblock 370 213 592 minecraft:oak_log
fill 370 213 593 370 216 593 minecraft:green_terracotta
setblock 370 213 597 minecraft:oak_log
fill 370 213 598 370 216 598 minecraft:green_terracotta
setblock 330 214 566 minecraft:oak_log
fill 330 214 567 330 217 567 minecraft:green_terracotta
setblock 330 214 571 minecraft:oak_log
fill 330 214 572 330 214 575 minecraft:green_terracotta
setblock 330 214 576 minecraft:oak_log
fill 330 214 577 330 217 577 minecraft:green_terracotta
setblock 330 214 581 minecraft:oak_log
fill 330 214 582 330 217 582 minecraft:green_terracotta
setblock 330 214 586 minecraft:oak_log
fill 330 214 587 330 217 587 minecraft:green_terracotta
setblock 330 214 591 minecraft:oak_log
fill 330 214 592 330 217 592 minecraft:green_terracotta
setblock 330 214 596 minecraft:oak_log
fill 330 214 597 330 217 597 minecraft:green_terracotta
setblock 331 214 570 minecraft:oak_log
fill 331 214 571 331 217 571 minecraft:green_terracotta
setblock 331 214 575 minecraft:oak_log
fill 331 214 576 331 217 576 minecraft:green_terracotta
fill 331 214 578 331 215 578 minecraft:green_terracotta
setblock 331 214 585 minecraft:oak_log
fill 331 214 586 331 215 586 minecraft:green_terracotta
setblock 331 214 590 minecraft:oak_log
fill 331 214 591 331 217 591 minecraft:green_terracotta
setblock 331 214 595 minecraft:oak_log
fill 331 214 598 331 215 598 minecraft:green_terracotta
setblock 332 214 558 minecraft:oak_leaves[persistent=true]
fill 339 214 575 339 216 575 minecraft:oak_log
setblock 342 214 558 minecraft:green_terracotta
setblock 342 214 598 minecraft:green_terracotta
setblock 343 214 558 minecraft:oak_log
setblock 343 214 598 minecraft:oak_log
fill 344 214 558 344 216 559 minecraft:green_terracotta
setblock 344 214 597 minecraft:oak_log
fill 344 214 598 344 217 598 minecraft:green_terracotta
fill 345 214 559 346 214 559 minecraft:green_terracotta
fill 345 214 597 346 216 597 minecraft:green_terracotta
fill 346 214 598 347 214 598 minecraft:green_terracotta
setblock 347 214 559 minecraft:oak_log
setblock 348 214 558 minecraft:oak_log
fill 348 214 559 348 217 559 minecraft:green_terracotta
setblock 348 214 598 minecraft:oak_log
fill 349 214 558 349 217 558 minecraft:green_terracotta
setblock 349 214 597 minecraft:oak_log
fill 349 214 598 349 217 598 minecraft:green_terracotta
fill 350 214 559 350 215 559 minecraft:green_terracotta
fill 350 214 597 351 216 597 minecraft:green_terracotta
setblock 352 214 598 minecraft:green_terracotta
setblock 353 214 558 minecraft:oak_log
setblock 353 214 598 minecraft:oak_log
fill 354 214 558 354 217 558 minecraft:green_terracotta
fill 354 214 598 357 214 598 minecraft:green_terracotta
setblock 357 214 558 minecraft:oak_leaves[persistent=true]
setblock 358 214 558 minecraft:oak_log
setblock 358 214 597 minecraft:green_terracotta
setblock 358 214 598 minecraft:oak_log
fill 359 214 558 360 216 558 minecraft:green_terracotta
setblock 359 214 597 minecraft:oak_log
fill 359 214 598 359 217 598 minecraft:green_terracotta
setblock 360 214 596 minecraft:oak_log
fill 360 214 597 360 217 597 minecraft:green_terracotta
fill 361 214 596 364 214 596 minecraft:green_terracotta
setblock 362 214 558 minecraft:green_terracotta
setblock 363 214 558 minecraft:oak_log
fill 363 214 595 365 214 595 minecraft:green_terracotta
setblock 363 214 598 minecraft:oak_log
fill 364 214 558 364 217 558 minecraft:green_terracotta
setblock 364 214 597 minecraft:oak_log
fill 364 214 598 364 217 598 minecraft:green_terracotta
setblock 365 214 596 minecraft:oak_log
fill 365 214 597 365 217 597 minecraft:green_terracotta
fill 366 214 592 366 214 594 minecraft:green_terracotta
setblock 366 214 595 minecraft:oak_log
fill 366 214 596 366 217 596 minecraft:green_terracotta
setblock 367 214 589 minecraft:oak_log
fill 367 214 590 367 217 590 minecraft:green_terracotta
setblock 367 214 594 minecraft:oak_log
fill 367 214 595 367 217 595 minecraft:green_terracotta
setblock 368 214 558 minecraft:oak_log
setblock 368 214 588 minecraft:oak_log
fill 368 214 589 368 217 589 minecraft:green_terracotta
setblock 368 214 593 minecraft:oak_log
fill 368 214 594 368 217 594 minecraft:green_terracotta
setblock 368 214 598 minecraft:oak_log
fill 369 214 558 369 217 558 minecraft:green_terracotta
fill 369 214 568 369 215 568 minecraft:green_terracotta
fill 369 214 570 369 214 571 minecraft:green_terracotta
setblock 369 214 572 minecraft:oak_log
fill 369 214 573 369 217 573 minecraft:green_terracotta
fill 369 214 575 369 214 576 minecraft:green_terracotta
setblock 369 214 587 minecraft:oak_log
fill 369 214 588 369 217 588 minecraft:green_terracotta
setblock 369 214 592 minecraft:oak_log
fill 369 214 593 369 217 593 minecraft:green_terracotta
setblock 369 214 597 minecraft:oak_log
fill 369 214 598 369 217 598 minecraft:green_terracotta
fill 370 214 564 370 215 564 minecraft:oak_leaves[persistent=true]
setblock 370 214 566 minecraft:oak_log
fill 370 214 567 370 216 567 minecraft:green_terracotta
setblock 370 214 571 minecraft:oak_log
fill 370 214 572 370 217 572 minecraft:green_terracotta
setblock 370 214 576 minecraft:oak_log
fill 370 214 577 370 217 577 minecraft:green_terracotta
setblock 370 214 581 minecraft:oak_log
fill 370 214 582 370 217 582 minecraft:green_terracotta
setblock 370 214 586 minecraft:oak_log
fill 370 214 587 370 217 587 minecraft:green_terracotta
setblock 370 214 591 minecraft:oak_log
fill 370 214 592 370 217 592 minecraft:green_terracotta
setblock 370 214 596 minecraft:oak_log
fill 370 214 597 370 217 597 minecraft:green_terracotta
setblock 330 215 565 minecraft:oak_log
fill 330 215 566 330 216 566 minecraft:green_terracotta
setblock 330 215 570 minecraft:oak_log
fill 330 215 571 330 215 574 minecraft:green_terracotta
setblock 330 215 575 minecraft:oak_log
fill 330 215 576 330 218 576 minecraft:green_terracotta
setblock 330 215 580 minecraft:oak_log
fill 330 215 581 330 218 581 minecraft:green_terracotta
setblock 330 215 585 minecraft:oak_log
fill 330 215 586 330 218 586 minecraft:green_terracotta
setblock 330 215 590 minecraft:oak_log
fill 330 215 591 330 218 591 minecraft:green_terracotta
setblock 330 215 595 minecraft:oak_log
fill 330 215 596 331 216 596 minecraft:green_terracotta
setblock 331 215 569 minecraft:oak_log
fill 331 215 570 331 218 570 minecraft:green_terracotta
setblock 331 215 574 minecraft:oak_log
fill 331 215 575 331 218 575 minecraft:green_terracotta
setblock 331 215 579 minecraft:oak_log
setblock 331 215 589 minecraft:oak_log
fill 331 215 590 331 216 590 minecraft:green_terracotta
setblock 331 215 594 minecraft:oak_log
fill 331 215 595 331 217 595 minecraft:green_terracotta
setblock 332 215 572 minecraft:green_terracotta
setblock 332 215 573 minecraft:oak_log
fill 332 215 574 332 218 574 minecraft:green_terracotta
fill 340 215 598 341 215 598 minecraft:green_terracotta
setblock 341 215 558 minecraft:green_terracotta
setblock 342 215 558 minecraft:oak_log
setblock 342 215 597 minecraft:green_terracotta
setblock 342 215 598 minecraft:oak_log
fill 343 215 558 343 217 559 minecraft:green_terracotta
setblock 343 215 597 minecraft:oak_log
fill 343 215 598 343 218 598 minecraft:green_terracotta
fill 344 215 597 344 218 597 minecraft:green_terracotta
setblock 345 215 559 minecraft:green_terracotta
fill 345 215 596 347 216 596 minecraft:green_terracotta
setblock 346 215 559 minecraft:oak_log
setblock 346 215 598 minecraft:green_terracotta
setblock 347 215 558 minecraft:oak_log
fill 347 215 559 347 218 559 minecraft:green_terracotta
setblock 347 215 597 minecraft:green_terracotta
setblock 347 215 598 minecraft:oak_log
fill 348 215 558 348 218 558 minecraft:green_terracotta
setblock 348 215 597 minecraft:oak_log
fill 348 215 598 348 218 598 minecraft:green_terracotta
fill 349 215 597 349 218 597 minecraft:green_terracotta
setblock 352 215 558 minecraft:oak_log
setblock 352 215 597 minecraft:green_terracotta
setblock 352 215 598 minecraft:oak_log
fill 353 215 558 353 218 558 minecraft:green_terracotta
fill 353 215 589 354 216 590 minecraft:oak_leaves[persistent=true]
setblock 353 215 597 minecraft:oak_log
fill 353 215 598 356 215 598 minecraft:green_terracotta
fill 355 215 558 356 215 558 minecraft:green_terracotta
fill 355 215 597 357 215 597 minecraft:green_terracotta
setblock 357 215 558 minecraft:oak_log
setblock 357 215 598 minecraft:oak_log
fill 358 215 558 358 218 558 minecraft:green_terracotta
setblock 358 215 597 minecraft:oak_log
fill 358 215 598 358 218 598 minecraft:green_terracotta
setblock 359 215 596 minecraft:oak_log
fill 359 215 597 359 218 597 minecraft:green_terracotta
fill 360 215 596 363 215 596 minecraft:green_terracotta
fill 361 215 595 364 215 595 minecraft:green_terracotta
setblock 362 215 558 minecraft:oak_log
setblock 362 215 597 minecraft:green_terracotta
setblock 362 215 598 minecraft:oak_log
fill 363 215 558 363 217 559 minecraft:green_terracotta
setblock 363 215 597 minecraft:oak_log
fill 363 215 598 363 218 598 minecraft:green_terracotta
fill 364 215 559 365 215 559 minecraft:green_terracotta
fill 364 215 594 365 215 594 minecraft:green_terracotta
setblock 364 215 596 minecraft:oak_log
fill 364 215 597 364 218 597 minecraft:green_terracotta
setblock 365 215 595 minecraft:oak_log
fill 365 215 596 365 218 596 minecraft:green_terracotta
fill 366 215 591 366 215 593 minecraft:green_terracotta
setblock 366 215 594 minecraft:oak_log
fill 366 215 595 366 218 595 minecraft:green_terracotta
setblock 367 215 558 minecraft:oak_log
fill 367 215 589 367 216 589 minecraft:green_terracotta
setblock 367 215 593 minecraft:oak_log
fill 367 215 594 367 218 594 minecraft:green_terracotta
setblock 367 215 598 minecraft:oak_log
fill 368 215 558 368 218 558 minecraft:green_terracotta
setblock 368 215 587 minecraft:oak_log
fill 368 215 588 368 217 588 minecraft:green_terracotta
setblock 368 215 592 minecraft:oak_log
fill 368 215 593 368 218 593 minecraft:green_terracotta
setblock 368 215 597 minecraft:oak_log
fill 368 215 598 368 218 598 minecraft:green_terracotta
setblock 369 215 570 minecraft:green_terracotta
setblock 369 215 571 minecraft:oak_log
fill 369 215 572 369 218 572 minecraft:green_terracotta
setblock 369 215 575 minecraft:green_terracotta
setblock 369 215 576 minecraft:oak_log
fill 369 215 577 369 217 578 minecraft:green_terracotta
fill 369 215 583 369 216 583 minecraft:green_terracotta
setblock 369 215 586 minecraft:oak_log
fill 369 215 587 369 218 587 minecraft:green_terracotta
setblock 369 215 591 minecraft:oak_log
fill 369 215 592 369 218 592 minecraft:green_terracotta
setblock 369 215 596 minecraft:oak_log
fill 369 215 597 369 218 597 minecraft:green_terracotta
setblock 370 215 558 minecraft:oak_leaves[persistent=true]
setblock 370 215 566 minecraft:green_terracotta
setblock 370 215 570 minecraft:oak_log
fill 370 215 571 370 218 571 minecraft:green_terracotta
setblock 370 215 575 minecraft:oak_log
fill 370 215 576 370 218 576 minecraft:green_terracotta
fill 370 215 578 370 215 579 minecraft:green_terracotta
setblock 370 215 580 minecraft:oak_log
fill 370 215 581 370 218 581 minecraft:green_terracotta
setblock 370 215 585 minecraft:oak_log
fill 370 215 586 370 218 586 minecraft:green_terracotta
setblock 370 215 590 minecraft:oak_log
fill 370 215 591 370 218 591 minecraft:green_terracotta
setblock 370 215 595 minecraft:oak_log
fill 370 215 596 370 218 596 minecraft:green_terracotta
setblock 330 216 569 minecraft:oak_log
fill 330 216 570 330 216 573 minecraft:green_terracotta
setblock 330 216 574 minecraft:oak_log
fill 330 216 575 330 219 575 minecraft:green_terracotta
setblock 330 216 579 minecraft:oak_log
fill 330 216 580 331 218 580 minecraft:green_terracotta
setblock 330 216 584 minecraft:oak_log
fill 330 216 585 330 218 585 minecraft:green_terracotta
setblock 330 216 589 minecraft:oak_log
fill 330 216 590 330 219 590 minecraft:green_terracotta
setblock 330 216 594 minecraft:oak_log
fill 330 216 595 330 219 595 minecraft:green_terracotta
fill 331 216 569 331 217 569 minecraft:green_terracotta
setblock 331 216 573 minecraft:oak_log
fill 331 216 574 331 219 574 minecraft:green_terracotta
setblock 331 216 578 minecraft:oak_log
fill 331 216 579 331 219 579 minecraft:green_terracotta
setblock 331 216 588 minecraft:oak_log
setblock 331 216 589 minecraft:green_terracotta
setblock 331 216 593 minecraft:oak_log
fill 331 216 594 331 217 594 minecraft:green_terracotta
setblock 331 216 598 minecraft:oak_log
setblock 332 216 572 minecraft:oak_log
fill 332 216 573 332 218 573 minecraft:green_terracotta
fill 332 216 575 332 217 575 minecraft:green_terracotta
fill 336 216 598 336 217 598 minecraft:oak_leaves[persistent=true]
fill 339 216 558 340 216 558 minecraft:green_terracotta
fill 339 216 598 340 216 598 minecraft:green_terracotta
setblock 341 216 558 minecraft:oak_log
setblock 341 216 597 minecraft:green_terracotta
setblock 341 216 598 minecraft:oak_log
fill 342 216 558 342 218 559 minecraft:green_terracotta
setblock 342 216 597 minecraft:oak_log
fill 342 216 598 342 219 598 minecraft:green_terracotta
setblock 343 216 596 minecraft:oak_log
fill 343 216 597 343 219 597 minecraft:green_terracotta
fill 344 216 596 344 219 596 minecraft:green_terracotta
setblock 345 216 559 minecraft:oak_log
fill 345 216 560 346 218 560 minecraft:green_terracotta
setblock 346 216 558 minecraft:oak_log
fill 346 216 559 346 219 559 minecraft:green_terracotta
setblock 346 216 598 minecraft:oak_log
fill 347 216 558 347 219 558 minecraft:green_terracotta
setblock 347 216 597 minecraft:oak_log
fill 347 216 598 347 219 598 minecraft:green_terracotta
setblock 348 216 596 minecraft:oak_log
fill 348 216 597 348 219 597 minecraft:green_terracotta
setblock 350 216 559 minecraft:oak_log
setblock 351 216 558 minecraft:oak_log
setblock 351 216 598 minecraft:oak_log
fill 352 216 558 352 219 558 minecraft:green_terracotta
setblock 352 216 597 minecraft:oak_log
fill 352 216 598 355 216 598 minecraft:green_terracotta
fill 353 216 597 356 216 597 minecraft:green_terracotta
setblock 355 216 558 minecraft:green_terracotta
setblock 356 216 558 minecraft:oak_log
setblock 356 216 598 minecraft:oak_log
fill 357 216 558 357 219 558 minecraft:green_terracotta
setblock 357 216 597 minecraft:oak_log
fill 357 216 598 357 219 598 minecraft:green_terracotta
setblock 358 216 596 minecraft:oak_log
fill 358 216 597 358 219 597 minecraft:green_terracotta
fill 359 216 596 362 216 596 minecraft:green_terracotta
fill 360 216 595 363 216 595 minecraft:green_terracotta
setblock 361 216 558 minecraft:oak_log
fill 361 216 559 362 218 559 minecraft:green_terracotta
setblock 361 216 598 minecraft:oak_log
fill 362 216 558 362 219 558 minecraft:green_terracotta
fill 362 216 568 363 217 569 minecraft:glowstone
setblock 362 216 597 minecraft:oak_log
fill 362 216 598 362 219 598 minecraft:green_terracotta
fill 363 216 594 364 216 594 minecraft:green_terracotta
setblock 363 216 596 minecraft:oak_log
fill 363 216 597 363 219 597 minecraft:green_terracotta
setblock 364 216 559 minecraft:green_terracotta
fill 364 216 569 364 217 569 minecraft:glowstone
setblock 364 216 595 minecraft:oak_log
fill 364 216 596 364 219 596 minecraft:green_terracotta
setblock 365 216 559 minecraft:oak_log
setblock 365 216 594 minecraft:oak_log
fill 365 216 595 365 219 595 minecraft:green_terracotta
setblock 366 216 558 minecraft:oak_log
fill 366 216 559 366 218 559 minecraft:green_terracotta
setblock 366 216 592 minecraft:green_terracotta
setblock 366 216 593 minecraft:oak_log
fill 366 216 594 366 217 594 minecraft:green_terracotta
setblock 366 216 598 minecraft:oak_log
fill 367 216 558 367 219 558 minecraft:green_terracotta
setblock 367 216 592 minecraft:oak_log
fill 367 216 593 367 219 593 minecraft:green_terracotta
setblock 367 216 597 minecraft:oak_log
fill 367 216 598 367 219 598 minecraft:green_terracotta
fill 368 216 573 368 216 574 minecraft:green_terracotta
setblock 368 216 587 minecraft:green_terracotta
setblock 368 216 591 minecraft:oak_log
fill 368 216 592 368 219 592 minecraft:green_terracotta
setblock 368 216 596 minecraft:oak_log
fill 368 216 597 368 219 597 minecraft:green_terracotta
setblock 369 216 570 minecraft:oak_log
fill 369 216 571 369 218 571 minecraft:green_terracotta
setblock 369 216 575 minecraft:oak_log
fill 369 216 576 369 219 576 minecraft:green_terracotta
setblock 369 216 579 minecraft:green_terracotta
setblock 369 216 580 minecraft:oak_log
setblock 369 216 585 minecraft:oak_log
fill 369 216 586 369 218 586 minecraft:green_terracotta
setblock 369 216 590 minecraft:oak_log
fill 369 216 591 369 219 591 minecraft:green_terracotta
setblock 369 216 595 minecraft:oak_log
fill 369 216 596 369 219 596 minecraft:green_terracotta
setblock 370 216 569 minecraft:oak_log
fill 370 216 570 370 218 570 minecraft:green_terracotta
setblock 370 216 574 minecraft:oak_log
fill 370 216 575 370 219 575 minecraft:green_terracotta
setblock 370 216 578 minecraft:green_terracotta
setblock 370 216 579 minecraft:oak_log
fill 370 216 580 370 219 580 minecraft:green_terracotta
setblock 370 216 584 minecraft:oak_log
fill 370 216 585 370 219 585 minecraft:green_terracotta
setblock 370 216 589 minecraft:oak_log
fill 370 216 590 370 219 590 minecraft:green_terracotta
setblock 370 216 594 minecraft:oak_log
fill 370 216 595 370 219 595 minecraft:green_terracotta
setblock 330 217 560 minecraft:oak_leaves[persistent=true]
fill 330 217 566 330 218 566 minecraft:oak_leaves[persistent=true]
setblock 330 217 568 minecraft:oak_log
fill 330 217 569 330 217 572 minecraft:green_terracotta
setblock 330 217 573 minecraft:oak_log
fill 330 217 574 330 220 574 minecraft:green_terracotta
setblock 330 217 578 minecraft:oak_log
fill 330 217 579 330 220 579 minecraft:green_terracotta
setblock 330 217 583 minecraft:oak_log
fill 330 217 584 330 219 584 minecraft:green_terracotta
setblock 330 217 588 minecraft:oak_log
fill 330 217 589 330 218 589 minecraft:green_terracotta
setblock 330 217 593 minecraft:oak_log
fill 330 217 594 330 220 594 minecraft:green_terracotta
fill 330 217 596 330 218 596 minecraft:green_terracotta
setblock 330 217 598 minecraft:oak_log
setblock 331 217 572 minecraft:oak_log
fill 331 217 573 331 220 573 minecraft:green_terracotta
setblock 331 217 577 minecraft:oak_log
fill 331 217 578 331 220 578 minecraft:green_terracotta
setblock 331 217 592 minecraft:oak_log
setblock 331 217 593 minecraft:green_terracotta
fill 331 217 598 331 218 598 minecraft:green_terracotta
setblock 332 217 560 minecraft:light[level=14]
setblock 332 217 568 minecraft:light[level=14]
setblock 332 217 572 minecraft:green_terracotta
setblock 332 217 576 minecraft:oak_log
setblock 332 217 584 minecraft:light[level=14]
setblock 332 217 592 minecraft:light[level=14]
fill 337 217 575 340 219 575 minecraft:oak_leaves[persistent=true]
fill 337 217 598 339 217 598 minecraft:green_terracotta
fill 338 217 558 339 217 558 minecraft:green_terracotta
fill 338 217 574 340 219 574 minecraft:oak_leaves[persistent=true]
fill 338 217 576 340 219 576 minecraft:oak_leaves[persistent=true]
setblock 340 217 558 minecraft:oak_log
setblock 340 217 560 minecraft:light[level=14]
setblock 340 217 568 minecraft:light[level=14]
fill 340 217 577 340 219 577 minecraft:oak_leaves[persistent=true]
setblock 340 217 584 minecraft:light[level=14]
setblock 340 217 592 minecraft:light[level=14]
setblock 340 217 597 minecraft:green_terracotta
setblock 340 217 598 minecraft:oak_log
fill 341 217 558 341 219 559 minecraft:green_terracotta
setblock 341 217 597 minecraft:oak_log
fill 341 217 598 341 220 598 minecraft:green_terracotta
setblock 342 217 596 minecraft:oak_log
fill 342 217 597 342 220 597 minecraft:green_terracotta
fill 343 217 596 343 220 596 minecraft:green_terracotta
setblock 344 217 558 minecraft:green_terracotta
setblock 344 217 559 minecraft:oak_log
fill 344 217 560 344 220 560 minecraft:green_terracotta
setblock 345 217 558 minecraft:oak_log
fill 345 217 559 345 220 559 minecraft:green_terracotta
fill 345 217 596 345 217 597 minecraft:green_terracotta
setblock 345 217 598 minecraft:oak_log
fill 346 217 558 346 220 558 minecraft:green_terracotta
setblock 346 217 596 minecraft:green_terracotta
setblock 346 217 597 minecraft:oak_log
fill 346 217 598 346 220 598 minecraft:green_terracotta
setblock 347 217 596 minecraft:oak_log
fill 347 217 597 347 220 597 minecraft:green_terracotta
setblock 348 217 560 minecraft:light[level=14]
setblock 348 217 568 minecraft:light[level=14]
setblock 348 217 576 minecraft:light[level=14]
setblock 348 217 584 minecraft:light[level=14]
setblock 348 217 592 minecraft:light[level=14]
fill 348 217 596 349 217 596 minecraft:green_terracotta
setblock 349 217 559 minecraft:oak_log
setblock 350 217 558 minecraft:oak_log
fill 350 217 559 351 217 559 minecraft:green_terracotta
setblock 350 217 597 minecraft:green_terracotta
setblock 350 217 598 minecraft:oak_log
fill 351 217 558 351 220 558 minecraft:green_terracotta
setblock 351 217 597 minecraft:oak_log
fill 351 217 598 354 217 598 minecraft:green_terracotta
fill 352 217 597 355 217 597 minecraft:green_terracotta
setblock 355 217 558 minecraft:oak_log
setblock 355 217 598 minecraft:oak_log
fill 356 217 558 356 220 558 minecraft:green_terracotta
setblock 356 217 560 minecraft:light[level=14]
setblock 356 217 568 minecraft:light[level=14]
setblock 356 217 576 minecraft:light[level=14]
setblock 356 217 584 minecraft:light[level=14]
setblock 356 217 592 minecraft:light[level=14]
setblock 356 217 597 minecraft:oak_log
fill 356 217 598 356 220 598 minecraft:green_terracotta
setblock 357 217 596 minecraft:oak_log
fill 357 217 597 357 220 597 minecraft:green_terracotta
fill 358 217 596 361 217 596 minecraft:green_terracotta
setblock 359 217 558 minecraft:green_terracotta
fill 359 217 595 362 217 595 minecraft:green_terracotta
setblock 360 217 558 minecraft:oak_log
fill 360 217 559 360 220 559 minecraft:green_terracotta
setblock 360 217 598 minecraft:oak_log
fill 361 217 558 361 220 558 minecraft:green_terracotta
setblock 361 217 597 minecraft:oak_log
fill 361 217 598 361 220 598 minecraft:green_terracotta
fill 362 217 594 363 217 594 minecraft:green_terracotta
setblock 362 217 596 minecraft:oak_log
fill 362 217 597 362 220 597 minecraft:green_terracotta
setblock 363 217 595 minecraft:oak_log
fill 363 217 596 363 220 596 minecraft:green_terracotta
setblock 364 217 559 minecraft:oak_log
setblock 364 217 560 minecraft:light[level=14]
setblock 364 217 568 minecraft:light[level=14]
setblock 364 217 576 minecraft:light[level=14]
setblock 364 217 584 minecraft:light[level=14]
setblock 364 217 592 minecraft:light[level=14]
setblock 364 217 594 minecraft:oak_log
fill 364 217 595 364 220 595 minecraft:green_terracotta
setblock 365 217 558 minecraft:oak_log
fill 365 217 559 365 219 559 minecraft:green_terracotta
fill 365 217 582 365 226 582 minecraft:iron_block
fill 365 217 594 365 218 594 minecraft:green_terracotta
setblock 365 217 598 minecraft:oak_log
fill 366 217 558 366 220 558 minecraft:green_terracotta
setblock 366 217 593 minecraft:green_terracotta
setblock 366 217 597 minecraft:oak_log
fill 366 217 598 366 220 598 minecraft:green_terracotta
setblock 367 217 591 minecraft:oak_log
fill 367 217 592 367 218 592 minecraft:green_terracotta
setblock 367 217 596 minecraft:oak_log
fill 367 217 597 367 220 597 minecraft:green_terracotta
setblock 368 217 574 minecraft:green_terracotta
setblock 368 217 575 minecraft:oak_log
setblock 368 217 590 minecraft:oak_log
fill 368 217 591 368 219 591 minecraft:green_terracotta
setblock 368 217 595 minecraft:oak_log
fill 368 217 596 368 220 596 minecraft:green_terracotta
setblock 369 217 570 minecraft:green_terracotta
setblock 369 217 574 minecraft:oak_log
fill 369 217 575 369 220 575 minecraft:green_terracotta
setblock 369 217 579 minecraft:oak_log
fill 369 217 580 369 218 581 minecraft:green_terracotta
setblock 369 217 584 minecraft:oak_log
setblock 369 217 585 minecraft:green_terracotta
setblock 369 217 589 minecraft:oak_log
fill 369 217 590 369 219 590 minecraft:green_terracotta
setblock 369 217 594 minecraft:oak_log
fill 369 217 595 369 220 595 minecraft:green_terracotta
setblock 370 217 568 minecraft:oak_log
fill 370 217 569 370 218 569 minecraft:green_terracotta
setblock 370 217 573 minecraft:oak_log
fill 370 217 574 370 220 574 minecraft:green_terracotta
setblock 370 217 578 minecraft:oak_log
fill 370 217 579 370 220 579 minecraft:green_terracotta
setblock 370 217 583 minecraft:oak_log
fill 370 217 584 370 220 584 minecraft:green_terracotta
setblock 370 217 588 minecraft:oak_log
fill 370 217 589 370 220 589 minecraft:green_terracotta
setblock 370 217 593 minecraft:oak_log
fill 370 217 594 370 220 594 minecraft:green_terracotta
setblock 370 217 598 minecraft:oak_log
setblock 330 218 567 minecraft:oak_log
fill 330 218 568 330 218 571 minecraft:green_terracotta
setblock 330 218 572 minecraft:oak_log
fill 330 218 573 330 221 573 minecraft:green_terracotta
setblock 330 218 577 minecraft:oak_log
fill 330 218 578 330 221 578 minecraft:green_terracotta
setblock 330 218 582 minecraft:oak_log
fill 330 218 583 330 220 583 minecraft:green_terracotta
setblock 330 218 587 minecraft:oak_log
setblock 330 218 588 minecraft:green_terracotta
setblock 330 218 592 minecraft:oak_log
fill 330 218 593 330 219 593 minecraft:green_terracotta
setblock 330 218 597 minecraft:oak_log
fill 330 218 598 330 219 598 minecraft:green_terracotta
setblock 331 218 571 minecraft:oak_log
fill 331 218 572 331 220 572 minecraft:green_terracotta
setblock 331 218 576 minecraft:oak_log
fill 331 218 577 331 221 577 minecraft:green_terracotta
setblock 332 218 575 minecraft:oak_log
setblock 332 218 576 minecraft:green_terracotta
setblock 333 218 558 minecraft:oak_leaves[persistent=true]
fill 337 218 558 338 218 558 minecraft:green_terracotta
setblock 337 218 574 minecraft:oak_leaves[persistent=true]
setblock 337 218 576 minecraft:oak_leaves[persistent=true]
fill 337 218 598 338 218 598 minecraft:green_terracotta
setblock 339 218 558 minecraft:oak_log
setblock 339 218 573 minecraft:oak_leaves[persistent=true]
setblock 339 218 597 minecraft:green_terracotta
setblock 339 218 598 minecraft:oak_log
fill 340 218 558 340 220 559 minecraft:green_terracotta
setblock 340 218 597 minecraft:oak_log
fill 340 218 598 340 221 598 minecraft:green_terracotta
fill 341 218 575 341 218 576 minecraft:oak_leaves[persistent=true]
fill 341 218 597 341 221 597 minecraft:green_terracotta
fill 342 218 596 342 219 596 minecraft:green_terracotta
setblock 343 218 558 minecraft:green_terracotta
setblock 343 218 559 minecraft:oak_log
fill 343 218 560 343 221 560 minecraft:green_terracotta
setblock 344 218 558 minecraft:oak_log
fill 344 218 559 344 221 559 minecraft:green_terracotta
setblock 344 218 598 minecraft:oak_log
fill 345 218 558 345 221 558 minecraft:green_terracotta
setblock 345 218 596 minecraft:green_terracotta
setblock 345 218 597 minecraft:oak_log
fill 345 218 598 345 221 598 minecraft:green_terracotta
setblock 346 218 596 minecraft:oak_log
fill 346 218 597 346 221 597 minecraft:green_terracotta
fill 347 218 596 348 218 596 minecraft:green_terracotta
setblock 348 218 559 minecraft:oak_log
setblock 349 218 558 minecraft:oak_log
fill 349 218 559 350 219 559 minecraft:green_terracotta
setblock 349 218 598 minecraft:oak_log
fill 350 218 558 350 221 558 minecraft:green_terracotta
setblock 350 218 597 minecraft:oak_log
fill 350 218 598 353 218 598 minecraft:green_terracotta
fill 351 218 597 354 218 597 minecraft:green_terracotta
setblock 354 218 558 minecraft:oak_log
setblock 354 218 598 minecraft:oak_log
fill 355 218 558 355 221 558 minecraft:green_terracotta
setblock 355 218 597 minecraft:oak_log
fill 355 218 598 355 221 598 minecraft:green_terracotta
setblock 356 218 596 minecraft:oak_log
fill 356 218 597 356 221 597 minecraft:green_terracotta
fill 357 218 596 360 218 596 minecraft:green_terracotta
setblock 359 218 558 minecraft:oak_log
fill 359 218 559 359 221 559 minecraft:green_terracotta
fill 359 218 595 361 218 595 minecraft:green_terracotta
setblock 359 218 598 minecraft:oak_log
fill 360 218 558 360 221 558 minecraft:green_terracotta
setblock 360 218 597 minecraft:oak_log
fill 360 218 598 360 221 598 minecraft:green_terracotta
setblock 361 218 596 minecraft:oak_log
fill 361 218 597 361 221 597 minecraft:green_terracotta
setblock 362 218 594 minecraft:green_terracotta
setblock 362 218 595 minecraft:oak_log
fill 362 218 596 362 221 596 minecraft:green_terracotta
setblock 363 218 558 minecraft:green_terracotta
setblock 363 218 559 minecraft:oak_log
setblock 363 218 594 minecraft:oak_log
fill 363 218 595 363 221 595 minecraft:green_terracotta
setblock 364 218 558 minecraft:oak_log
fill 364 218 559 364 221 559 minecraft:green_terracotta
fill 364 218 572 365 219 573 minecraft:glowstone
setblock 364 218 594 minecraft:green_terracotta
setblock 364 218 598 minecraft:oak_log
fill 365 218 558 365 221 558 minecraft:green_terracotta
setblock 365 218 597 minecraft:oak_log
fill 365 218 598 365 221 598 minecraft:green_terracotta
setblock 366 218 596 minecraft:oak_log
fill 366 218 597 366 221 597 minecraft:green_terracotta
setblock 367 218 591 minecraft:green_terracotta
setblock 367 218 595 minecraft:oak_log
fill 367 218 596 367 221 596 minecraft:green_terracotta
setblock 368 218 589 minecraft:oak_log
setblock 368 218 590 minecraft:green_terracotta
setblock 368 218 594 minecraft:oak_log
fill 368 218 595 368 220 595 minecraft:green_terracotta
setblock 369 218 558 minecraft:oak_log
setblock 369 218 573 minecraft:oak_log
fill 369 218 574 369 220 574 minecraft:green_terracotta
setblock 369 218 577 minecraft:green_terracotta
setblock 369 218 578 minecraft:oak_log
fill 369 218 579 369 221 579 minecraft:green_terracotta
setblock 369 218 588 minecraft:oak_log
fill 369 218 589 369 219 589 minecraft:green_terracotta
setblock 369 218 593 minecraft:oak_log
fill 369 218 594 369 221 594 minecraft:green_terracotta
setblock 369 218 598 minecraft:oak_log
setblock 370 218 565 minecraft:oak_leaves[persistent=true]
setblock 370 218 572 minecraft:oak_log
fill 370 218 573 370 221 573 minecraft:green_terracotta
setblock 370 218 577 minecraft:oak_log
fill 370 218 578 370 221 578 minecraft:green_terracotta
setblock 370 218 582 minecraft:oak_log
fill 370 218 583 370 221 583 minecraft:green_terracotta
setblock 370 218 587 minecraft:oak_log
fill 370 218 588 370 220 588 minecraft:green_terracotta
setblock 370 218 592 minecraft:oak_log
fill 370 218 593 370 221 593 minecraft:green_terracotta
setblock 370 218 597 minecraft:oak_log
fill 370 218 598 370 221 598 minecraft:green_terracotta
fill 330 219 568 330 219 570 minecraft:green_terracotta
setblock 330 219 571 minecraft:oak_log
fill 330 219 572 330 222 572 minecraft:green_terracotta
setblock 330 219 576 minecraft:oak_log
fill 330 219 577 330 222 577 minecraft:green_terracotta
setblock 330 219 580 minecraft:green_terracotta
setblock 330 219 581 minecraft:oak_log
fill 330 219 582 330 222 582 minecraft:green_terracotta
setblock 330 219 591 minecraft:oak_log
setblock 330 219 592 minecraft:green_terracotta
setblock 330 219 596 minecraft:oak_log
fill 330 219 597 330 220 597 minecraft:green_terracotta
setblock 331 219 571 minecraft:green_terracotta
setblock 331 219 575 minecraft:oak_log
fill 331 219 576 331 222 576 minecraft:green_terracotta
fill 336 219 598 337 219 598 minecraft:green_terracotta
setblock 337 219 558 minecraft:green_terracotta
setblock 338 219 558 minecraft:oak_log
setblock 338 219 598 minecraft:oak_log
fill 339 219 558 339 221 559 minecraft:green_terracotta
fill 339 219 564 340 220 564 minecraft:glowstone
setblock 339 219 597 minecraft:oak_log
fill 339 219 598 339 222 598 minecraft:green_terracotta
fill 340 219 597 340 222 597 minecraft:green_terracotta
setblock 342 219 558 minecraft:green_terracotta
setblock 342 219 559 minecraft:oak_log
fill 342 219 560 342 222 560 minecraft:green_terracotta
setblock 343 219 558 minecraft:oak_log
fill 343 219 559 343 222 559 minecraft:green_terracotta
setblock 343 219 598 minecraft:oak_log
fill 344 219 558 344 222 558 minecraft:green_terracotta
setblock 344 219 597 minecraft:oak_log
fill 344 219 598 344 222 598 minecraft:green_terracotta
setblock 345 219 560 minecraft:green_terracotta
setblock 345 219 596 minecraft:oak_log
fill 345 219 597 345 222 597 minecraft:green_terracotta
setblock 346 219 560 minecraft:oak_log
fill 346 219 596 347 219 596 minecraft:green_terracotta
setblock 347 219 559 minecraft:oak_log
setblock 348 219 558 minecraft:oak_log
fill 348 219 559 348 222 559 minecraft:green_terracotta
setblock 348 219 598 minecraft:oak_log
fill 349 219 558 349 222 558 minecraft:green_terracotta
setblock 349 219 597 minecraft:oak_log
fill 349 219 598 352 219 598 minecraft:green_terracotta
fill 350 219 597 353 219 597 minecraft:green_terracotta
setblock 353 219 558 minecraft:oak_log
setblock 353 219 598 minecraft:oak_log
fill 354 219 558 354 222 558 minecraft:green_terracotta
setblock 354 219 597 minecraft:oak_log
fill 354 219 598 354 222 598 minecraft:green_terracotta
fill 355 219 597 355 222 597 minecraft:green_terracotta
fill 356 219 596 359 219 596 minecraft:green_terracotta
setblock 358 219 558 minecraft:oak_log
fill 358 219 559 358 222 559 minecraft:green_terracotta
setblock 358 219 598 minecraft:oak_log
fill 359 219 558 359 222 558 minecraft:green_terracotta
fill 359 219 595 360 219 595 minecraft:green_terracotta
setblock 359 219 597 minecraft:oak_log
fill 359 219 598 359 222 598 minecraft:green_terracotta
setblock 360 219 596 minecraft:oak_log
fill 360 219 597 360 222 597 minecraft:green_terracotta
setblock 361 219 559 minecraft:green_terracotta
setblock 361 219 595 minecraft:oak_log
fill 361 219 596 361 222 596 minecraft:green_terracotta
setblock 362 219 559 minecraft:oak_log
fill 362 219 595 362 222 595 minecraft:green_terracotta
setblock 363 219 558 minecraft:oak_log
fill 363 219 559 363 222 559 minecraft:green_terracotta
setblock 363 219 598 minecraft:oak_log
fill 364 219 558 364 222 558 minecraft:green_terracotta
setblock 364 219 597 minecraft:oak_log
fill 364 219 598 364 222 598 minecraft:green_terracotta
fill 365 219 585 365 220 585 minecraft:glowstone
setblock 365 219 596 minecraft:oak_log
fill 365 219 597 365 222 597 minecraft:green_terracotta
setblock 366 219 595 minecraft:oak_log
fill 366 219 596 366 222 596 minecraft:green_terracotta
setblock 367 219 594 minecraft:oak_log
setblock 367 219 595 minecraft:green_terracotta
setblock 368 219 558 minecraft:oak_log
setblock 368 219 593 minecraft:oak_log
fill 368 219 594 368 220 594 minecraft:green_terracotta
setblock 368 219 598 minecraft:oak_log
setblock 369 219 573 minecraft:green_terracotta
setblock 369 219 577 minecraft:oak_log
fill 369 219 578 369 222 578 minecraft:green_terracotta
fill 369 219 580 369 220 580 minecraft:green_terracotta
setblock 369 219 592 minecraft:oak_log
fill 369 219 593 369 220 593 minecraft:green_terracotta
setblock 369 219 597 minecraft:oak_log
fill 369 219 598 369 222 598 minecraft:green_terracotta
setblock 370 219 559 minecraft:oak_leaves[persistent=true]
schedule function dropper:buildpart/139_7 1t
