setblock 142 97 333 minecraft:dark_prismarine
setblock 142 97 334 minecraft:blue_terracotta
setblock 142 97 338 minecraft:dark_prismarine
setblock 142 97 339 minecraft:blue_terracotta
setblock 142 97 342 minecraft:blue_terracotta
setblock 142 97 343 minecraft:dark_prismarine
fill 142 97 344 143 97 344 minecraft:blue_terracotta
setblock 142 97 346 minecraft:blue_terracotta
setblock 142 97 353 minecraft:dark_prismarine
setblock 142 97 354 minecraft:blue_terracotta
setblock 142 97 358 minecraft:dark_prismarine
fill 142 97 359 142 97 362 minecraft:blue_terracotta
setblock 142 97 363 minecraft:dark_prismarine
fill 143 97 323 146 97 323 minecraft:blue_terracotta
setblock 143 97 327 minecraft:dark_prismarine
setblock 143 97 328 minecraft:blue_terracotta
setblock 143 97 332 minecraft:dark_prismarine
setblock 143 97 333 minecraft:blue_terracotta
setblock 143 97 337 minecraft:dark_prismarine
setblock 143 97 338 minecraft:blue_terracotta
setblock 143 97 342 minecraft:dark_prismarine
setblock 143 97 343 minecraft:blue_terracotta
setblock 143 97 357 minecraft:dark_prismarine
setblock 143 97 358 minecraft:blue_terracotta
setblock 143 97 361 minecraft:blue_terracotta
setblock 143 97 362 minecraft:dark_prismarine
setblock 143 97 363 minecraft:blue_terracotta
setblock 144 97 325 minecraft:blue_terracotta
setblock 144 97 326 minecraft:dark_prismarine
setblock 144 97 327 minecraft:blue_terracotta
setblock 144 97 331 minecraft:dark_prismarine
setblock 144 97 332 minecraft:blue_terracotta
setblock 144 97 336 minecraft:dark_prismarine
setblock 144 97 337 minecraft:blue_terracotta
setblock 144 97 341 minecraft:dark_prismarine
setblock 144 97 356 minecraft:dark_prismarine
setblock 144 97 357 minecraft:blue_terracotta
setblock 144 97 361 minecraft:dark_prismarine
setblock 144 97 362 minecraft:blue_terracotta
setblock 145 97 325 minecraft:dark_prismarine
setblock 145 97 360 minecraft:dark_prismarine
setblock 145 97 361 minecraft:blue_terracotta
setblock 146 97 324 minecraft:dark_prismarine
setblock 146 97 325 minecraft:blue_terracotta
setblock 146 97 360 minecraft:blue_terracotta
setblock 147 97 323 minecraft:dark_prismarine
setblock 147 97 324 minecraft:blue_terracotta
setblock 147 97 363 minecraft:dark_prismarine
setblock 148 97 323 minecraft:blue_terracotta
setblock 148 97 362 minecraft:dark_prismarine
setblock 148 97 363 minecraft:blue_terracotta
setblock 149 97 360 minecraft:blue_terracotta
setblock 149 97 361 minecraft:dark_prismarine
setblock 149 97 362 minecraft:blue_terracotta
setblock 150 97 360 minecraft:dark_prismarine
setblock 150 97 361 minecraft:blue_terracotta
setblock 152 97 323 minecraft:dark_prismarine
setblock 152 97 363 minecraft:dark_prismarine
setblock 153 97 323 minecraft:blue_terracotta
setblock 153 97 362 minecraft:dark_prismarine
fill 153 97 363 156 97 363 minecraft:blue_terracotta
setblock 154 97 361 minecraft:dark_prismarine
fill 154 97 362 157 97 362 minecraft:blue_terracotta
fill 155 97 361 158 97 361 minecraft:blue_terracotta
setblock 157 97 363 minecraft:dark_prismarine
setblock 158 97 362 minecraft:dark_prismarine
setblock 158 97 363 minecraft:blue_terracotta
fill 159 97 323 161 97 323 minecraft:blue_terracotta
fill 159 97 358 159 102 358 minecraft:magenta_terracotta
setblock 159 97 361 minecraft:dark_prismarine
setblock 159 97 362 minecraft:blue_terracotta
setblock 160 97 360 minecraft:dark_prismarine
fill 160 97 361 163 97 361 minecraft:blue_terracotta
fill 161 97 360 164 97 360 minecraft:blue_terracotta
setblock 162 97 323 minecraft:dark_prismarine
setblock 162 97 363 minecraft:dark_prismarine
setblock 163 97 323 minecraft:blue_terracotta
setblock 163 97 362 minecraft:dark_prismarine
setblock 163 97 363 minecraft:blue_terracotta
setblock 164 97 361 minecraft:dark_prismarine
setblock 164 97 362 minecraft:blue_terracotta
setblock 165 97 360 minecraft:dark_prismarine
setblock 165 97 361 minecraft:blue_terracotta
setblock 166 97 323 minecraft:blue_terracotta
setblock 166 97 360 minecraft:blue_terracotta
setblock 167 97 323 minecraft:dark_prismarine
setblock 167 97 363 minecraft:dark_prismarine
setblock 168 97 323 minecraft:blue_terracotta
setblock 168 97 362 minecraft:dark_prismarine
setblock 168 97 363 minecraft:blue_terracotta
setblock 169 97 361 minecraft:dark_prismarine
setblock 169 97 362 minecraft:blue_terracotta
setblock 172 97 363 minecraft:dark_prismarine
setblock 173 97 363 minecraft:blue_terracotta
setblock 178 97 323 minecraft:purple_concrete
fill 178 97 363 179 97 363 minecraft:blue_terracotta
setblock 179 97 323 minecraft:blue_terracotta
setblock 180 97 334 minecraft:blue_terracotta
setblock 180 97 335 minecraft:dark_prismarine
setblock 180 97 336 minecraft:blue_terracotta
setblock 180 97 340 minecraft:dark_prismarine
fill 180 97 341 180 97 342 minecraft:blue_terracotta
setblock 181 97 323 minecraft:blue_terracotta
setblock 181 97 324 minecraft:dark_prismarine
setblock 181 97 329 minecraft:dark_prismarine
setblock 181 97 330 minecraft:blue_terracotta
setblock 181 97 334 minecraft:dark_prismarine
setblock 181 97 335 minecraft:blue_terracotta
setblock 181 97 339 minecraft:dark_prismarine
setblock 181 97 340 minecraft:blue_terracotta
setblock 181 97 344 minecraft:dark_prismarine
setblock 181 97 345 minecraft:blue_terracotta
setblock 181 97 358 minecraft:blue_terracotta
setblock 181 97 359 minecraft:dark_prismarine
setblock 181 97 360 minecraft:blue_terracotta
fill 181 97 362 181 97 363 minecraft:blue_terracotta
setblock 182 97 323 minecraft:dark_prismarine
setblock 182 97 324 minecraft:blue_terracotta
setblock 182 97 328 minecraft:dark_prismarine
setblock 182 97 329 minecraft:blue_terracotta
setblock 182 97 333 minecraft:dark_prismarine
setblock 182 97 334 minecraft:blue_terracotta
setblock 182 97 338 minecraft:dark_prismarine
setblock 182 97 339 minecraft:blue_terracotta
setblock 182 97 343 minecraft:dark_prismarine
setblock 182 97 344 minecraft:blue_terracotta
setblock 182 97 348 minecraft:dark_prismarine
setblock 182 97 349 minecraft:blue_terracotta
setblock 182 97 353 minecraft:dark_prismarine
setblock 182 97 354 minecraft:blue_terracotta
setblock 182 97 358 minecraft:dark_prismarine
setblock 182 97 359 minecraft:blue_terracotta
setblock 182 97 363 minecraft:dark_prismarine
fill 158 98 356 158 102 356 minecraft:magenta_terracotta
setblock 173 98 322 minecraft:cyan_concrete
fill 174 98 322 174 100 322 minecraft:black_concrete
fill 178 98 339 178 102 339 minecraft:magenta_terracotta
fill 158 99 357 158 102 357 minecraft:magenta_terracotta
fill 173 99 322 173 131 322 minecraft:black_concrete
fill 169 100 364 169 131 364 minecraft:black_concrete
setblock 170 100 364 minecraft:cyan_concrete
fill 171 100 364 171 127 364 minecraft:black_concrete
setblock 141 101 331 minecraft:light_blue_wool
setblock 144 101 325 minecraft:light[level=13]
setblock 144 101 332 minecraft:light[level=12]
setblock 144 101 333 minecraft:light[level=13]
setblock 144 101 339 minecraft:light[level=12]
setblock 144 101 341 minecraft:light[level=13]
setblock 144 101 346 minecraft:light[level=12]
setblock 144 101 349 minecraft:light[level=13]
setblock 144 101 353 minecraft:light[level=12]
setblock 144 101 357 minecraft:light[level=13]
setblock 144 101 360 minecraft:light[level=12]
fill 150 101 364 150 131 364 minecraft:black_concrete
setblock 151 101 325 minecraft:light[level=12]
setblock 151 101 332 minecraft:light[level=12]
setblock 151 101 339 minecraft:light[level=12]
setblock 151 101 346 minecraft:light[level=12]
setblock 151 101 353 minecraft:light[level=12]
setblock 151 101 360 minecraft:light[level=12]
setblock 151 101 364 minecraft:light_blue_wool
setblock 152 101 325 minecraft:light[level=13]
setblock 152 101 333 minecraft:light[level=13]
setblock 152 101 341 minecraft:light[level=13]
setblock 152 101 349 minecraft:light[level=13]
setblock 152 101 357 minecraft:light[level=13]
fill 152 101 364 153 131 364 minecraft:black_concrete
setblock 158 101 325 minecraft:light[level=12]
setblock 158 101 332 minecraft:light[level=12]
setblock 158 101 339 minecraft:light[level=12]
setblock 158 101 346 minecraft:light[level=12]
setblock 158 101 353 minecraft:light[level=12]
setblock 158 101 360 minecraft:light[level=12]
setblock 160 101 325 minecraft:light[level=13]
setblock 160 101 333 minecraft:light[level=13]
setblock 160 101 341 minecraft:light[level=13]
setblock 160 101 349 minecraft:light[level=13]
setblock 165 101 325 minecraft:light[level=12]
setblock 165 101 332 minecraft:light[level=12]
setblock 165 101 339 minecraft:light[level=12]
setblock 165 101 346 minecraft:light[level=12]
setblock 165 101 353 minecraft:light[level=12]
setblock 165 101 360 minecraft:light[level=12]
setblock 168 101 325 minecraft:light[level=13]
setblock 168 101 333 minecraft:light[level=13]
setblock 168 101 341 minecraft:light[level=13]
setblock 168 101 349 minecraft:light[level=13]
setblock 168 101 357 minecraft:light[level=13]
fill 170 101 364 170 127 364 minecraft:black_concrete
setblock 172 101 325 minecraft:light[level=12]
setblock 172 101 332 minecraft:light[level=12]
setblock 172 101 339 minecraft:light[level=12]
setblock 172 101 346 minecraft:light[level=12]
setblock 172 101 353 minecraft:light[level=12]
setblock 172 101 360 minecraft:light[level=12]
setblock 174 101 322 minecraft:light_blue_wool
setblock 176 101 325 minecraft:light[level=13]
setblock 176 101 333 minecraft:light[level=13]
setblock 176 101 341 minecraft:light[level=13]
setblock 176 101 357 minecraft:light[level=13]
setblock 179 101 325 minecraft:light[level=12]
setblock 179 101 332 minecraft:light[level=12]
setblock 179 101 339 minecraft:light[level=12]
setblock 179 101 346 minecraft:light[level=12]
setblock 179 101 353 minecraft:light[level=12]
setblock 179 101 360 minecraft:light[level=12]
setblock 141 102 329 minecraft:cyan_concrete
fill 141 102 331 141 131 331 minecraft:black_concrete
fill 148 102 322 148 131 322 minecraft:black_concrete
setblock 149 102 322 minecraft:cyan_concrete
setblock 150 102 337 minecraft:magenta_terracotta
fill 151 102 364 151 131 364 minecraft:black_concrete
setblock 166 102 330 minecraft:magenta_terracotta
fill 174 102 322 174 127 322 minecraft:black_concrete
fill 183 102 341 183 128 342 minecraft:black_concrete
setblock 183 102 343 minecraft:cyan_concrete
fill 183 102 344 183 130 344 minecraft:black_concrete
fill 141 103 329 141 131 329 minecraft:black_concrete
fill 142 103 332 158 103 354 minecraft:purple_terracotta
fill 143 103 331 181 103 331 minecraft:purple_terracotta
fill 143 103 355 181 103 355 minecraft:purple_terracotta
fill 144 103 329 180 103 330 minecraft:purple_terracotta
fill 144 103 356 180 103 357 minecraft:purple_terracotta
fill 145 103 328 179 103 328 minecraft:purple_terracotta
fill 145 103 358 179 103 358 minecraft:purple_terracotta
fill 146 103 327 178 103 327 minecraft:purple_terracotta
fill 146 103 359 178 103 359 minecraft:purple_terracotta
fill 147 103 326 177 103 326 minecraft:purple_terracotta
fill 147 103 360 177 103 360 minecraft:purple_terracotta
fill 148 103 325 176 103 325 minecraft:purple_terracotta
fill 148 103 361 176 103 361 minecraft:purple_terracotta
fill 149 103 322 149 127 322 minecraft:black_concrete
fill 150 103 324 174 103 324 minecraft:purple_terracotta
fill 150 103 362 174 103 362 minecraft:purple_terracotta
fill 151 103 323 173 103 323 minecraft:purple_terracotta
fill 151 103 363 173 103 363 minecraft:purple_terracotta
fill 159 103 332 159 103 340 minecraft:purple_terracotta
fill 159 103 344 159 103 354 minecraft:purple_terracotta
fill 160 103 332 182 103 339 minecraft:purple_terracotta
fill 160 103 345 182 103 354 minecraft:purple_terracotta
fill 163 103 340 182 103 340 minecraft:purple_terracotta
fill 163 103 344 182 103 344 minecraft:purple_terracotta
fill 164 103 341 182 103 343 minecraft:purple_terracotta
fill 183 103 343 183 131 343 minecraft:black_concrete
fill 142 104 333 142 104 353 minecraft:purple_terracotta
fill 143 104 331 143 104 332 minecraft:purple_terracotta
fill 143 104 333 158 104 353 minecraft:magenta_terracotta
fill 143 104 354 143 104 355 minecraft:purple_terracotta
setblock 144 104 330 minecraft:purple_terracotta
fill 144 104 331 180 104 332 minecraft:magenta_terracotta
fill 144 104 354 180 104 355 minecraft:magenta_terracotta
setblock 144 104 356 minecraft:purple_terracotta
fill 145 104 329 145 105 329 minecraft:purple_terracotta
fill 145 104 330 179 104 330 minecraft:magenta_terracotta
fill 145 104 356 179 104 356 minecraft:magenta_terracotta
fill 145 104 357 145 105 357 minecraft:purple_terracotta
fill 146 104 328 146 105 328 minecraft:purple_terracotta
fill 146 104 329 178 105 329 minecraft:magenta_terracotta
fill 146 104 357 178 105 357 minecraft:magenta_terracotta
fill 146 104 358 146 105 358 minecraft:purple_terracotta
fill 147 104 327 147 105 327 minecraft:purple_terracotta
fill 147 104 328 177 105 328 minecraft:magenta_terracotta
fill 147 104 358 177 105 358 minecraft:magenta_terracotta
fill 147 104 359 147 105 359 minecraft:purple_terracotta
fill 148 104 326 148 105 326 minecraft:purple_terracotta
fill 148 104 327 176 105 327 minecraft:magenta_terracotta
fill 148 104 359 176 105 359 minecraft:magenta_terracotta
fill 148 104 360 148 105 360 minecraft:purple_terracotta
setblock 149 104 325 minecraft:purple_terracotta
fill 149 104 326 175 104 326 minecraft:magenta_terracotta
fill 149 104 360 175 104 360 minecraft:magenta_terracotta
setblock 149 104 361 minecraft:purple_terracotta
fill 150 104 324 151 104 324 minecraft:purple_terracotta
fill 150 104 325 174 104 325 minecraft:magenta_terracotta
fill 150 104 361 174 104 361 minecraft:magenta_terracotta
fill 150 104 362 151 104 362 minecraft:purple_terracotta
fill 152 104 323 172 104 323 minecraft:purple_terracotta
fill 152 104 324 172 104 324 minecraft:magenta_terracotta
fill 152 104 362 172 104 362 minecraft:magenta_terracotta
fill 152 104 363 172 104 363 minecraft:purple_terracotta
fill 159 104 333 159 104 340 minecraft:magenta_terracotta
fill 159 104 344 159 104 353 minecraft:magenta_terracotta
fill 160 104 333 181 104 339 minecraft:magenta_terracotta
fill 160 104 345 181 104 353 minecraft:magenta_terracotta
fill 163 104 340 181 104 340 minecraft:magenta_terracotta
fill 163 104 344 181 104 344 minecraft:magenta_terracotta
fill 164 104 341 181 104 343 minecraft:magenta_terracotta
fill 173 104 324 174 104 324 minecraft:purple_terracotta
fill 173 104 362 174 104 362 minecraft:purple_terracotta
setblock 175 104 325 minecraft:purple_terracotta
setblock 175 104 361 minecraft:purple_terracotta
fill 176 104 326 176 105 326 minecraft:purple_terracotta
fill 176 104 360 176 105 360 minecraft:purple_terracotta
fill 177 104 327 177 105 327 minecraft:purple_terracotta
fill 177 104 359 177 105 359 minecraft:purple_terracotta
fill 178 104 328 178 105 328 minecraft:purple_terracotta
fill 178 104 358 178 105 358 minecraft:purple_terracotta
fill 179 104 329 179 105 329 minecraft:purple_terracotta
fill 179 104 357 179 105 357 minecraft:purple_terracotta
setblock 180 104 330 minecraft:purple_terracotta
setblock 180 104 356 minecraft:purple_terracotta
fill 181 104 331 181 104 332 minecraft:purple_terracotta
fill 181 104 354 181 104 355 minecraft:purple_terracotta
fill 182 104 333 182 104 353 minecraft:purple_terracotta
fill 142 105 334 142 105 352 minecraft:purple_terracotta
fill 143 105 332 143 105 333 minecraft:purple_terracotta
fill 143 105 334 157 105 352 minecraft:magenta_terracotta
fill 143 105 353 143 105 354 minecraft:purple_terracotta
fill 144 105 331 144 106 331 minecraft:purple_terracotta
fill 144 105 332 180 105 333 minecraft:magenta_terracotta
fill 144 105 353 180 105 354 minecraft:magenta_terracotta
fill 144 105 355 144 106 355 minecraft:purple_terracotta
fill 145 105 330 145 106 330 minecraft:purple_terracotta
fill 145 105 331 179 106 331 minecraft:magenta_terracotta
fill 145 105 355 179 106 355 minecraft:magenta_terracotta
fill 145 105 356 145 106 356 minecraft:purple_terracotta
fill 146 105 330 178 106 330 minecraft:magenta_terracotta
fill 146 105 356 178 106 356 minecraft:magenta_terracotta
fill 149 105 326 149 106 326 minecraft:purple_terracotta
fill 149 105 360 149 106 360 minecraft:purple_terracotta
fill 150 105 325 150 106 325 minecraft:purple_terracotta
fill 150 105 326 174 106 326 minecraft:magenta_terracotta
fill 150 105 360 174 106 360 minecraft:magenta_terracotta
fill 150 105 361 150 106 361 minecraft:purple_terracotta
fill 151 105 324 152 105 324 minecraft:purple_terracotta
fill 151 105 325 173 105 325 minecraft:magenta_terracotta
fill 151 105 361 173 105 361 minecraft:magenta_terracotta
fill 151 105 362 152 105 362 minecraft:purple_terracotta
fill 153 105 323 171 105 323 minecraft:purple_terracotta
fill 153 105 324 171 105 324 minecraft:magenta_terracotta
fill 153 105 362 171 105 362 minecraft:magenta_terracotta
fill 153 105 363 171 105 363 minecraft:purple_terracotta
fill 158 105 334 158 105 341 minecraft:magenta_terracotta
setblock 158 105 342 minecraft:gray_concrete
fill 158 105 343 158 105 352 minecraft:magenta_terracotta
fill 159 105 334 160 105 339 minecraft:magenta_terracotta
setblock 159 105 340 minecraft:gray_concrete
setblock 159 105 344 minecraft:gray_concrete
fill 159 105 345 160 105 352 minecraft:magenta_terracotta
fill 161 105 334 181 105 338 minecraft:magenta_terracotta
setblock 161 105 339 minecraft:gray_concrete
setblock 161 105 345 minecraft:gray_concrete
fill 161 105 346 181 105 352 minecraft:magenta_terracotta
fill 162 105 339 181 105 339 minecraft:magenta_terracotta
fill 162 105 345 181 105 345 minecraft:magenta_terracotta
setblock 163 105 340 minecraft:gray_concrete
setblock 163 105 344 minecraft:gray_concrete
fill 164 105 340 181 105 341 minecraft:magenta_terracotta
setblock 164 105 342 minecraft:gray_concrete
fill 164 105 343 181 105 344 minecraft:magenta_terracotta
fill 165 105 342 181 105 342 minecraft:magenta_terracotta
fill 172 105 324 173 105 324 minecraft:purple_terracotta
fill 172 105 362 173 105 362 minecraft:purple_terracotta
fill 174 105 325 174 106 325 minecraft:purple_terracotta
fill 174 105 361 174 106 361 minecraft:purple_terracotta
fill 175 105 326 175 106 326 minecraft:purple_terracotta
fill 175 105 360 175 106 360 minecraft:purple_terracotta
fill 179 105 330 179 106 330 minecraft:purple_terracotta
fill 179 105 356 179 106 356 minecraft:purple_terracotta
fill 180 105 331 180 106 331 minecraft:purple_terracotta
fill 180 105 355 180 106 355 minecraft:purple_terracotta
fill 181 105 332 181 105 333 minecraft:purple_terracotta
fill 181 105 353 181 105 354 minecraft:purple_terracotta
fill 182 105 334 182 105 352 minecraft:purple_terracotta
fill 142 106 323 142 106 334 minecraft:magenta_terracotta
fill 142 106 335 142 106 351 minecraft:purple_terracotta
fill 142 106 352 142 106 363 minecraft:magenta_terracotta
fill 143 106 323 143 106 332 minecraft:magenta_terracotta
fill 143 106 333 143 106 334 minecraft:purple_terracotta
fill 143 106 335 154 106 351 minecraft:magenta_terracotta
fill 143 106 352 143 106 353 minecraft:purple_terracotta
fill 143 106 354 143 106 363 minecraft:magenta_terracotta
fill 144 106 323 144 106 330 minecraft:magenta_terracotta
fill 144 106 332 144 107 332 minecraft:purple_terracotta
fill 144 106 333 180 106 334 minecraft:magenta_terracotta
fill 144 106 352 180 106 353 minecraft:magenta_terracotta
fill 144 106 354 144 107 354 minecraft:purple_terracotta
fill 144 106 356 144 106 363 minecraft:magenta_terracotta
fill 145 106 323 145 106 329 minecraft:magenta_terracotta
fill 145 106 332 179 107 332 minecraft:magenta_terracotta
fill 145 106 354 179 107 354 minecraft:magenta_terracotta
fill 145 106 357 145 106 363 minecraft:magenta_terracotta
fill 146 106 323 146 106 328 minecraft:magenta_terracotta
setblock 146 106 329 minecraft:purple_terracotta
setblock 146 106 357 minecraft:purple_terracotta
fill 146 106 358 146 106 363 minecraft:magenta_terracotta
fill 147 106 323 147 106 327 minecraft:magenta_terracotta
setblock 147 106 328 minecraft:purple_terracotta
fill 147 106 329 177 106 329 minecraft:magenta_terracotta
fill 147 106 357 177 106 357 minecraft:magenta_terracotta
setblock 147 106 358 minecraft:purple_terracotta
fill 147 106 359 147 106 363 minecraft:magenta_terracotta
fill 148 106 323 148 106 326 minecraft:magenta_terracotta
setblock 148 106 327 minecraft:purple_terracotta
fill 148 106 328 176 106 328 minecraft:magenta_terracotta
fill 148 106 358 176 106 358 minecraft:magenta_terracotta
setblock 148 106 359 minecraft:purple_terracotta
fill 148 106 360 148 106 363 minecraft:magenta_terracotta
fill 149 106 323 149 106 325 minecraft:magenta_terracotta
fill 149 106 327 175 106 327 minecraft:magenta_terracotta
fill 149 106 359 175 106 359 minecraft:magenta_terracotta
fill 149 106 361 149 106 363 minecraft:magenta_terracotta
fill 150 106 323 151 106 324 minecraft:magenta_terracotta
fill 150 106 362 151 106 363 minecraft:magenta_terracotta
fill 151 106 325 151 107 325 minecraft:purple_terracotta
fill 151 106 361 151 107 361 minecraft:purple_terracotta
fill 152 106 323 153 106 323 minecraft:magenta_terracotta
fill 152 106 324 153 106 324 minecraft:purple_terracotta
fill 152 106 325 172 106 325 minecraft:magenta_terracotta
fill 152 106 361 172 106 361 minecraft:magenta_terracotta
fill 152 106 362 153 106 362 minecraft:purple_terracotta
fill 152 106 363 153 106 363 minecraft:magenta_terracotta
fill 154 106 323 170 106 323 minecraft:purple_terracotta
fill 154 106 324 170 106 324 minecraft:magenta_terracotta
fill 154 106 362 170 106 362 minecraft:magenta_terracotta
fill 154 106 363 170 106 363 minecraft:purple_terracotta
fill 155 106 335 155 106 339 minecraft:magenta_terracotta
fill 155 106 340 158 106 344 minecraft:mossy_stone_bricks
fill 155 106 345 155 106 351 minecraft:magenta_terracotta
fill 156 106 335 156 106 337 minecraft:magenta_terracotta
fill 156 106 338 166 106 339 minecraft:mossy_stone_bricks
fill 156 106 345 166 106 346 minecraft:mossy_stone_bricks
fill 156 106 347 156 106 351 minecraft:magenta_terracotta
fill 157 106 335 158 106 336 minecraft:magenta_terracotta
fill 157 106 337 165 106 337 minecraft:mossy_stone_bricks
fill 157 106 347 165 106 347 minecraft:mossy_stone_bricks
fill 157 106 348 158 106 351 minecraft:magenta_terracotta
fill 159 106 335 181 106 335 minecraft:magenta_terracotta
fill 159 106 336 163 106 336 minecraft:mossy_stone_bricks
setblock 159 106 340 minecraft:mossy_stone_bricks
setblock 159 106 344 minecraft:mossy_stone_bricks
fill 159 106 348 163 106 348 minecraft:mossy_stone_bricks
fill 159 106 349 181 106 351 minecraft:magenta_terracotta
fill 163 106 322 164 131 322 minecraft:black_concrete
fill 163 106 340 167 106 340 minecraft:mossy_stone_bricks
fill 163 106 344 167 106 344 minecraft:mossy_stone_bricks
fill 164 106 336 181 106 336 minecraft:magenta_terracotta
fill 164 106 341 167 106 343 minecraft:mossy_stone_bricks
fill 164 106 348 181 106 348 minecraft:magenta_terracotta
setblock 165 106 322 minecraft:cyan_concrete
fill 166 106 337 181 106 337 minecraft:magenta_terracotta
fill 166 106 347 181 106 347 minecraft:magenta_terracotta
fill 167 106 338 181 106 339 minecraft:magenta_terracotta
fill 167 106 345 181 106 346 minecraft:magenta_terracotta
fill 168 106 340 181 106 344 minecraft:magenta_terracotta
fill 171 106 323 182 106 323 minecraft:magenta_terracotta
fill 171 106 324 172 106 324 minecraft:purple_terracotta
fill 171 106 362 172 106 362 minecraft:purple_terracotta
fill 171 106 363 182 106 363 minecraft:magenta_terracotta
fill 173 106 324 182 106 324 minecraft:magenta_terracotta
fill 173 106 325 173 107 325 minecraft:purple_terracotta
fill 173 106 361 173 107 361 minecraft:purple_terracotta
fill 173 106 362 182 106 362 minecraft:magenta_terracotta
fill 175 106 325 182 106 325 minecraft:magenta_terracotta
fill 175 106 361 182 106 361 minecraft:magenta_terracotta
fill 176 106 326 182 106 326 minecraft:magenta_terracotta
setblock 176 106 327 minecraft:purple_terracotta
setblock 176 106 359 minecraft:purple_terracotta
fill 176 106 360 182 106 360 minecraft:magenta_terracotta
fill 177 106 327 182 106 327 minecraft:magenta_terracotta
setblock 177 106 328 minecraft:purple_terracotta
setblock 177 106 358 minecraft:purple_terracotta
fill 177 106 359 182 106 359 minecraft:magenta_terracotta
fill 178 106 328 182 106 328 minecraft:magenta_terracotta
setblock 178 106 329 minecraft:purple_terracotta
setblock 178 106 357 minecraft:purple_terracotta
fill 178 106 358 182 106 358 minecraft:magenta_terracotta
fill 179 106 329 182 106 329 minecraft:magenta_terracotta
fill 179 106 357 182 106 357 minecraft:magenta_terracotta
fill 180 106 330 182 106 330 minecraft:magenta_terracotta
fill 180 106 332 180 107 332 minecraft:purple_terracotta
fill 180 106 354 180 107 354 minecraft:purple_terracotta
fill 180 106 356 182 106 356 minecraft:magenta_terracotta
fill 181 106 331 182 106 332 minecraft:magenta_terracotta
fill 181 106 333 181 106 334 minecraft:purple_terracotta
fill 181 106 352 181 106 353 minecraft:purple_terracotta
fill 181 106 354 182 106 355 minecraft:magenta_terracotta
fill 182 106 333 182 106 334 minecraft:magenta_terracotta
fill 182 106 335 182 106 351 minecraft:purple_terracotta
fill 182 106 352 182 106 353 minecraft:magenta_terracotta
fill 142 107 337 142 107 349 minecraft:purple_terracotta
fill 143 107 334 143 107 336 minecraft:purple_terracotta
fill 143 107 337 152 107 349 minecraft:magenta_terracotta
fill 143 107 350 143 107 352 minecraft:purple_terracotta
setblock 144 107 325 minecraft:light[level=12]
fill 144 107 333 144 108 333 minecraft:purple_terracotta
fill 144 107 334 153 107 336 minecraft:magenta_terracotta
fill 144 107 350 158 107 352 minecraft:magenta_terracotta
fill 144 107 353 144 108 353 minecraft:purple_terracotta
setblock 144 107 360 minecraft:light[level=12]
setblock 145 107 331 minecraft:purple_terracotta
fill 145 107 333 179 108 333 minecraft:magenta_terracotta
fill 145 107 353 179 108 353 minecraft:magenta_terracotta
setblock 145 107 355 minecraft:purple_terracotta
fill 146 107 330 146 108 330 minecraft:purple_terracotta
fill 146 107 331 178 107 331 minecraft:magenta_terracotta
fill 146 107 355 178 107 355 minecraft:magenta_terracotta
fill 146 107 356 146 108 356 minecraft:purple_terracotta
fill 147 107 329 147 108 329 minecraft:purple_terracotta
fill 147 107 330 177 108 330 minecraft:magenta_terracotta
fill 147 107 356 177 108 356 minecraft:magenta_terracotta
fill 147 107 357 147 108 357 minecraft:purple_terracotta
fill 148 107 328 148 108 328 minecraft:purple_terracotta
fill 148 107 329 176 108 329 minecraft:magenta_terracotta
fill 148 107 357 176 108 357 minecraft:magenta_terracotta
fill 148 107 358 148 108 358 minecraft:purple_terracotta
fill 149 107 327 149 108 327 minecraft:purple_terracotta
fill 149 107 328 175 108 328 minecraft:magenta_terracotta
fill 149 107 358 175 108 358 minecraft:magenta_terracotta
fill 149 107 359 149 108 359 minecraft:purple_terracotta
setblock 150 107 326 minecraft:purple_terracotta
fill 150 107 327 174 107 327 minecraft:magenta_terracotta
fill 150 107 359 174 107 359 minecraft:magenta_terracotta
setblock 150 107 360 minecraft:purple_terracotta
fill 151 107 326 173 107 326 minecraft:magenta_terracotta
fill 151 107 360 173 107 360 minecraft:magenta_terracotta
fill 152 107 325 152 108 325 minecraft:purple_terracotta
fill 152 107 361 152 108 361 minecraft:purple_terracotta
fill 153 107 324 155 107 324 minecraft:purple_terracotta
fill 153 107 325 171 107 325 minecraft:magenta_terracotta
fill 153 107 337 153 113 339 minecraft:magenta_terracotta
fill 153 107 340 154 116 344 minecraft:stone_bricks
fill 153 107 345 153 113 349 minecraft:magenta_terracotta
fill 153 107 361 171 107 361 minecraft:magenta_terracotta
fill 153 107 362 155 107 362 minecraft:purple_terracotta
fill 154 107 334 158 113 334 minecraft:magenta_terracotta
fill 154 107 335 156 119 338 minecraft:cobblestone
fill 154 107 339 155 116 339 minecraft:stone_bricks
fill 154 107 345 155 117 345 minecraft:stone_bricks
fill 154 107 346 156 119 349 minecraft:cobblestone
fill 155 107 340 156 107 344 minecraft:magenta_terracotta
fill 156 107 323 168 107 323 minecraft:purple_terracotta
fill 156 107 324 168 107 324 minecraft:magenta_terracotta
fill 156 107 339 158 107 339 minecraft:magenta_terracotta
fill 156 107 345 157 107 345 minecraft:magenta_terracotta
fill 156 107 362 168 107 362 minecraft:magenta_terracotta
fill 156 107 363 168 107 363 minecraft:purple_terracotta
fill 157 107 335 157 119 337 minecraft:cobblestone
fill 157 107 338 159 107 338 minecraft:magenta_terracotta
setblock 157 107 340 minecraft:magenta_terracotta
fill 157 107 341 157 107 344 minecraft:black_concrete
fill 157 107 346 158 107 346 minecraft:magenta_terracotta
fill 157 107 347 157 119 349 minecraft:cobblestone
fill 158 107 335 158 116 336 minecraft:stone_bricks
fill 158 107 337 164 107 337 minecraft:magenta_terracotta
setblock 158 107 340 minecraft:black_concrete
setblock 158 107 345 minecraft:black_concrete
fill 158 107 347 164 107 347 minecraft:magenta_terracotta
fill 158 107 348 158 116 349 minecraft:stone_bricks
fill 159 107 334 163 116 335 minecraft:stone_bricks
fill 159 107 336 163 109 336 minecraft:magenta_terracotta
setblock 159 107 339 minecraft:black_concrete
fill 159 107 346 163 107 346 minecraft:black_concrete
fill 159 107 348 163 108 348 minecraft:magenta_terracotta
fill 159 107 349 163 116 350 minecraft:stone_bricks
fill 159 107 351 180 107 352 minecraft:magenta_terracotta
fill 160 107 338 163 107 338 minecraft:black_concrete
fill 164 107 334 180 107 334 minecraft:magenta_terracotta
fill 164 107 335 164 116 336 minecraft:stone_bricks
fill 164 107 338 165 107 338 minecraft:magenta_terracotta
setblock 164 107 339 minecraft:black_concrete
setblock 164 107 345 minecraft:black_concrete
fill 164 107 346 165 107 346 minecraft:magenta_terracotta
fill 164 107 348 164 117 349 minecraft:stone_bricks
fill 164 107 350 180 108 350 minecraft:magenta_terracotta
fill 165 107 322 165 131 322 minecraft:black_concrete
fill 165 107 335 168 119 337 minecraft:cobblestone
fill 165 107 339 166 107 339 minecraft:magenta_terracotta
fill 165 107 340 165 107 344 minecraft:black_concrete
fill 165 107 345 166 107 345 minecraft:magenta_terracotta
fill 165 107 347 168 119 349 minecraft:cobblestone
fill 166 107 338 168 119 338 minecraft:cobblestone
fill 166 107 340 167 107 344 minecraft:magenta_terracotta
fill 166 107 346 168 119 346 minecraft:cobblestone
fill 167 107 339 168 117 339 minecraft:stone_bricks
fill 167 107 345 168 116 345 minecraft:stone_bricks
fill 168 107 340 169 116 344 minecraft:stone_bricks
fill 169 107 324 171 107 324 minecraft:purple_terracotta
fill 169 107 335 180 108 339 minecraft:magenta_terracotta
fill 169 107 345 181 107 349 minecraft:magenta_terracotta
fill 169 107 362 171 107 362 minecraft:purple_terracotta
fill 170 107 340 181 108 344 minecraft:magenta_terracotta
fill 172 107 325 172 108 325 minecraft:purple_terracotta
fill 172 107 361 172 108 361 minecraft:purple_terracotta
setblock 174 107 326 minecraft:purple_terracotta
setblock 174 107 360 minecraft:purple_terracotta
fill 175 107 327 175 108 327 minecraft:purple_terracotta
fill 175 107 359 175 108 359 minecraft:purple_terracotta
fill 176 107 328 176 108 328 minecraft:purple_terracotta
fill 176 107 358 176 108 358 minecraft:purple_terracotta
fill 177 107 329 177 108 329 minecraft:purple_terracotta
fill 177 107 357 177 108 357 minecraft:purple_terracotta
fill 178 107 330 178 108 330 minecraft:purple_terracotta
fill 178 107 356 178 108 356 minecraft:purple_terracotta
setblock 179 107 325 minecraft:light[level=12]
setblock 179 107 331 minecraft:purple_terracotta
setblock 179 107 355 minecraft:purple_terracotta
setblock 179 107 360 minecraft:light[level=12]
fill 180 107 333 180 108 333 minecraft:purple_terracotta
fill 180 107 353 180 108 353 minecraft:purple_terracotta
fill 181 107 334 181 107 336 minecraft:purple_terracotta
fill 181 107 337 181 107 339 minecraft:magenta_terracotta
fill 181 107 350 181 107 352 minecraft:purple_terracotta
fill 182 107 337 182 107 349 minecraft:purple_terracotta
setblock 182 107 364 minecraft:cyan_concrete
fill 183 107 364 183 131 364 minecraft:black_concrete
fill 142 108 338 142 108 348 minecraft:purple_terracotta
fill 143 108 335 143 108 337 minecraft:purple_terracotta
fill 143 108 338 152 108 348 minecraft:magenta_terracotta
fill 143 108 349 143 108 351 minecraft:purple_terracotta
setblock 144 108 334 minecraft:purple_terracotta
fill 144 108 335 152 108 337 minecraft:magenta_terracotta
fill 144 108 349 152 108 351 minecraft:magenta_terracotta
setblock 144 108 352 minecraft:purple_terracotta
setblock 145 108 332 minecraft:purple_terracotta
fill 145 108 334 153 108 334 minecraft:magenta_terracotta
fill 145 108 352 179 108 352 minecraft:magenta_terracotta
setblock 145 108 354 minecraft:purple_terracotta
fill 146 108 331 146 109 331 minecraft:purple_terracotta
fill 146 108 332 178 108 332 minecraft:magenta_terracotta
fill 146 108 354 178 108 354 minecraft:magenta_terracotta
fill 146 108 355 146 109 355 minecraft:purple_terracotta
fill 147 108 331 177 109 331 minecraft:magenta_terracotta
fill 147 108 355 177 109 355 minecraft:magenta_terracotta
fill 150 108 327 150 109 327 minecraft:purple_terracotta
fill 150 108 359 150 109 359 minecraft:purple_terracotta
setblock 151 108 326 minecraft:purple_terracotta
fill 151 108 327 173 108 327 minecraft:magenta_terracotta
fill 151 108 359 173 108 359 minecraft:magenta_terracotta
setblock 151 108 360 minecraft:purple_terracotta
fill 152 108 326 172 108 326 minecraft:magenta_terracotta
fill 152 108 360 172 108 360 minecraft:magenta_terracotta
setblock 153 108 325 minecraft:purple_terracotta
fill 153 108 335 153 115 336 minecraft:magenta_terracotta
fill 153 108 350 158 112 351 minecraft:magenta_terracotta
setblock 153 108 361 minecraft:purple_terracotta
fill 154 108 324 156 108 324 minecraft:purple_terracotta
fill 154 108 325 170 108 325 minecraft:magenta_terracotta
fill 154 108 361 170 108 361 minecraft:magenta_terracotta
fill 154 108 362 156 108 362 minecraft:purple_terracotta
fill 155 108 340 155 109 344 minecraft:magenta_terracotta
fill 156 108 339 156 108 340 minecraft:magenta_terracotta
fill 156 108 341 156 108 343 minecraft:gray_concrete
fill 156 108 344 156 108 345 minecraft:magenta_terracotta
fill 157 108 323 167 108 323 minecraft:purple_terracotta
fill 157 108 324 167 108 324 minecraft:magenta_terracotta
fill 157 108 338 157 108 339 minecraft:magenta_terracotta
setblock 157 108 340 minecraft:gray_concrete
fill 157 108 344 157 108 345 minecraft:gray_concrete
setblock 157 108 346 minecraft:magenta_terracotta
fill 157 108 362 167 108 362 minecraft:magenta_terracotta
fill 157 108 363 167 108 363 minecraft:purple_terracotta
fill 158 108 337 158 108 338 minecraft:magenta_terracotta
setblock 158 108 339 minecraft:gray_concrete
setblock 158 108 346 minecraft:gray_concrete
setblock 158 108 347 minecraft:magenta_terracotta
setblock 159 108 337 minecraft:magenta_terracotta
setblock 159 108 338 minecraft:gray_concrete
fill 159 108 347 163 108 347 minecraft:gray_concrete
fill 159 108 351 180 108 351 minecraft:magenta_terracotta
fill 160 108 337 162 108 337 minecraft:gray_concrete
fill 163 108 337 164 108 337 minecraft:magenta_terracotta
fill 163 108 338 164 108 338 minecraft:gray_concrete
fill 164 108 334 179 108 334 minecraft:magenta_terracotta
setblock 164 108 346 minecraft:gray_concrete
setblock 164 108 347 minecraft:magenta_terracotta
setblock 165 108 338 minecraft:magenta_terracotta
setblock 165 108 339 minecraft:gray_concrete
setblock 165 108 345 minecraft:gray_concrete
setblock 165 108 346 minecraft:magenta_terracotta
setblock 166 108 339 minecraft:magenta_terracotta
fill 166 108 340 166 108 344 minecraft:gray_concrete
setblock 166 108 345 minecraft:magenta_terracotta
fill 167 108 340 167 108 344 minecraft:magenta_terracotta
fill 168 108 324 170 108 324 minecraft:purple_terracotta
fill 168 108 362 170 108 362 minecraft:purple_terracotta
fill 169 108 345 180 109 349 minecraft:magenta_terracotta
setblock 171 108 325 minecraft:purple_terracotta
setblock 171 108 361 minecraft:purple_terracotta
setblock 173 108 326 minecraft:purple_terracotta
setblock 173 108 360 minecraft:purple_terracotta
fill 174 108 327 174 109 327 minecraft:purple_terracotta
fill 174 108 359 174 109 359 minecraft:purple_terracotta
fill 178 108 331 178 109 331 minecraft:purple_terracotta
fill 178 108 355 178 109 355 minecraft:purple_terracotta
setblock 179 108 332 minecraft:purple_terracotta
setblock 179 108 354 minecraft:purple_terracotta
setblock 180 108 334 minecraft:purple_terracotta
setblock 180 108 352 minecraft:purple_terracotta
fill 181 108 335 181 108 337 minecraft:purple_terracotta
fill 181 108 338 181 108 339 minecraft:magenta_terracotta
fill 181 108 345 181 108 348 minecraft:magenta_terracotta
fill 181 108 349 181 108 351 minecraft:purple_terracotta
fill 182 108 338 182 108 348 minecraft:purple_terracotta
fill 182 108 364 182 131 364 minecraft:black_concrete
fill 142 109 342 142 109 344 minecraft:purple_terracotta
fill 143 109 337 143 109 341 minecraft:purple_terracotta
fill 143 109 342 152 109 344 minecraft:magenta_terracotta
fill 143 109 345 143 109 349 minecraft:purple_terracotta
setblock 144 109 325 minecraft:light[level=13]
setblock 144 109 333 minecraft:light[level=13]
fill 144 109 335 144 109 336 minecraft:purple_terracotta
fill 144 109 337 152 109 341 minecraft:magenta_terracotta
fill 144 109 345 152 109 349 minecraft:magenta_terracotta
fill 144 109 350 144 109 351 minecraft:purple_terracotta
setblock 144 109 357 minecraft:light[level=13]
fill 145 109 333 145 109 334 minecraft:purple_terracotta
fill 145 109 335 152 109 336 minecraft:magenta_terracotta
fill 145 109 350 152 109 351 minecraft:magenta_terracotta
fill 145 109 352 145 109 353 minecraft:purple_terracotta
fill 146 109 332 146 110 332 minecraft:purple_terracotta
fill 146 109 333 153 109 334 minecraft:magenta_terracotta
fill 146 109 352 178 109 353 minecraft:magenta_terracotta
fill 146 109 354 146 110 354 minecraft:purple_terracotta
setblock 147 109 330 minecraft:purple_terracotta
fill 147 109 332 177 110 332 minecraft:magenta_terracotta
fill 147 109 354 177 110 354 minecraft:magenta_terracotta
setblock 147 109 356 minecraft:purple_terracotta
setblock 148 109 329 minecraft:purple_terracotta
fill 148 109 330 176 109 330 minecraft:magenta_terracotta
fill 148 109 356 176 109 356 minecraft:magenta_terracotta
setblock 148 109 357 minecraft:purple_terracotta
setblock 149 109 328 minecraft:purple_terracotta
fill 149 109 329 175 109 329 minecraft:magenta_terracotta
fill 149 109 357 175 109 357 minecraft:magenta_terracotta
setblock 149 109 358 minecraft:purple_terracotta
fill 150 109 328 174 109 328 minecraft:magenta_terracotta
fill 150 109 358 174 109 358 minecraft:magenta_terracotta
fill 151 109 327 151 110 327 minecraft:purple_terracotta
fill 151 109 359 151 110 359 minecraft:purple_terracotta
setblock 152 109 325 minecraft:light[level=13]
fill 152 109 326 153 109 326 minecraft:purple_terracotta
fill 152 109 327 172 109 327 minecraft:magenta_terracotta
fill 152 109 359 172 109 359 minecraft:magenta_terracotta
fill 152 109 360 153 109 360 minecraft:purple_terracotta
fill 154 109 325 155 109 325 minecraft:purple_terracotta
fill 154 109 326 170 109 326 minecraft:magenta_terracotta
fill 154 109 333 178 109 333 minecraft:magenta_terracotta
fill 154 109 360 170 109 360 minecraft:magenta_terracotta
fill 154 109 361 155 109 361 minecraft:purple_terracotta
fill 156 109 324 160 109 324 minecraft:purple_terracotta
fill 156 109 325 168 109 325 minecraft:magenta_terracotta
setblock 156 109 339 minecraft:magenta_terracotta
fill 156 109 340 156 109 345 minecraft:black_concrete
fill 156 109 361 168 109 361 minecraft:magenta_terracotta
fill 156 109 362 160 109 362 minecraft:purple_terracotta
setblock 157 109 338 minecraft:magenta_terracotta
setblock 157 109 339 minecraft:black_concrete
setblock 157 109 346 minecraft:black_concrete
setblock 158 109 337 minecraft:magenta_terracotta
setblock 158 109 338 minecraft:black_concrete
fill 158 109 347 159 109 347 minecraft:black_concrete
fill 159 109 337 164 109 337 minecraft:black_concrete
setblock 159 109 348 minecraft:magenta_terracotta
fill 159 109 351 179 109 351 minecraft:magenta_terracotta
setblock 160 109 341 minecraft:light[level=13]
fill 160 109 348 163 109 348 minecraft:black_concrete
fill 161 109 323 163 109 323 minecraft:purple_terracotta
fill 161 109 324 163 109 324 minecraft:magenta_terracotta
fill 161 109 362 163 109 362 minecraft:magenta_terracotta
fill 161 109 363 163 109 363 minecraft:purple_terracotta
fill 164 109 324 168 109 324 minecraft:purple_terracotta
fill 164 109 334 178 110 334 minecraft:magenta_terracotta
setblock 164 109 347 minecraft:black_concrete
fill 164 109 350 179 110 350 minecraft:magenta_terracotta
fill 164 109 362 168 109 362 minecraft:purple_terracotta
setblock 165 109 338 minecraft:black_concrete
setblock 165 109 346 minecraft:black_concrete
fill 166 109 339 166 109 340 minecraft:black_concrete
setblock 166 109 345 minecraft:black_concrete
setblock 167 109 340 minecraft:magenta_terracotta
fill 167 109 341 167 109 344 minecraft:black_concrete
fill 169 109 325 170 109 325 minecraft:purple_terracotta
fill 169 109 335 179 109 339 minecraft:magenta_terracotta
fill 169 109 361 170 109 361 minecraft:purple_terracotta
fill 170 109 340 180 110 344 minecraft:magenta_terracotta
fill 171 109 326 172 109 326 minecraft:purple_terracotta
fill 171 109 360 172 109 360 minecraft:purple_terracotta
fill 173 109 327 173 110 327 minecraft:purple_terracotta
fill 173 109 359 173 110 359 minecraft:purple_terracotta
setblock 175 109 328 minecraft:purple_terracotta
setblock 175 109 358 minecraft:purple_terracotta
setblock 176 109 325 minecraft:light[level=13]
setblock 176 109 329 minecraft:purple_terracotta
setblock 176 109 357 minecraft:purple_terracotta
setblock 177 109 330 minecraft:purple_terracotta
setblock 177 109 356 minecraft:purple_terracotta
fill 178 109 332 178 110 332 minecraft:purple_terracotta
fill 178 109 354 178 110 354 minecraft:purple_terracotta
fill 179 109 333 179 109 334 minecraft:purple_terracotta
fill 179 109 352 179 109 353 minecraft:purple_terracotta
fill 180 109 335 180 109 336 minecraft:purple_terracotta
fill 180 109 337 180 109 339 minecraft:magenta_terracotta
fill 180 109 350 180 109 351 minecraft:purple_terracotta
fill 181 109 337 181 109 341 minecraft:purple_terracotta
fill 181 109 342 181 109 344 minecraft:magenta_terracotta
fill 181 109 345 181 109 349 minecraft:purple_terracotta
fill 182 109 342 182 109 344 minecraft:purple_terracotta
setblock 141 110 347 minecraft:light_blue_wool
fill 141 110 348 141 127 349 minecraft:black_concrete
fill 142 110 323 142 110 324 minecraft:blue_terracotta
setblock 142 110 325 minecraft:dark_prismarine
fill 142 110 326 142 110 329 minecraft:blue_terracotta
setblock 142 110 330 minecraft:dark_prismarine
fill 142 110 331 142 111 333 minecraft:blue_terracotta
setblock 142 110 338 minecraft:purple_concrete
fill 142 110 342 142 110 344 minecraft:blue_terracotta
setblock 142 110 345 minecraft:dark_prismarine
fill 142 110 346 142 110 349 minecraft:blue_terracotta
setblock 142 110 350 minecraft:dark_prismarine
fill 142 110 351 142 110 354 minecraft:blue_terracotta
setblock 142 110 355 minecraft:dark_prismarine
fill 142 110 356 142 110 359 minecraft:blue_terracotta
setblock 142 110 360 minecraft:dark_prismarine
fill 142 110 361 143 110 363 minecraft:blue_terracotta
setblock 143 110 323 minecraft:blue_terracotta
setblock 143 110 324 minecraft:dark_prismarine
fill 143 110 325 143 110 328 minecraft:blue_terracotta
setblock 143 110 329 minecraft:dark_prismarine
fill 143 110 330 143 112 330 minecraft:blue_terracotta
fill 143 110 339 143 110 347 minecraft:purple_terracotta
setblock 143 110 348 minecraft:blue_terracotta
setblock 143 110 349 minecraft:dark_prismarine
fill 143 110 350 143 110 353 minecraft:blue_terracotta
setblock 143 110 354 minecraft:dark_prismarine
fill 143 110 355 143 113 355 minecraft:blue_terracotta
setblock 143 110 360 minecraft:blue_terracotta
setblock 144 110 323 minecraft:dark_prismarine
fill 144 110 324 146 110 324 minecraft:blue_terracotta
fill 144 110 336 144 110 338 minecraft:purple_terracotta
fill 144 110 339 152 110 347 minecraft:magenta_terracotta
fill 144 110 348 144 110 350 minecraft:purple_terracotta
setblock 144 110 362 minecraft:blue_terracotta
setblock 144 110 363 minecraft:dark_prismarine
fill 145 110 323 148 110 323 minecraft:blue_terracotta
fill 145 110 334 145 110 335 minecraft:purple_terracotta
fill 145 110 336 152 110 338 minecraft:magenta_terracotta
fill 145 110 348 152 110 350 minecraft:magenta_terracotta
fill 145 110 351 145 110 352 minecraft:purple_terracotta
fill 145 110 363 148 110 363 minecraft:blue_terracotta
setblock 146 110 333 minecraft:purple_terracotta
fill 146 110 334 152 110 335 minecraft:magenta_terracotta
fill 146 110 351 152 110 352 minecraft:magenta_terracotta
setblock 146 110 353 minecraft:purple_terracotta
setblock 147 110 331 minecraft:purple_terracotta
fill 147 110 333 177 110 333 minecraft:magenta_terracotta
fill 147 110 353 177 110 353 minecraft:magenta_terracotta
setblock 147 110 355 minecraft:purple_terracotta
setblock 148 110 330 minecraft:purple_terracotta
fill 148 110 331 176 110 331 minecraft:magenta_terracotta
fill 148 110 355 176 110 355 minecraft:magenta_terracotta
setblock 148 110 356 minecraft:purple_terracotta
setblock 149 110 323 minecraft:dark_prismarine
setblock 149 110 329 minecraft:purple_terracotta
fill 149 110 330 175 110 330 minecraft:magenta_terracotta
fill 149 110 356 175 110 356 minecraft:magenta_terracotta
setblock 149 110 357 minecraft:purple_terracotta
setblock 149 110 363 minecraft:dark_prismarine
fill 150 110 323 153 110 323 minecraft:blue_terracotta
setblock 150 110 328 minecraft:purple_terracotta
fill 150 110 329 174 110 329 minecraft:magenta_terracotta
fill 150 110 357 174 110 357 minecraft:magenta_terracotta
setblock 150 110 358 minecraft:purple_terracotta
fill 150 110 363 153 110 363 minecraft:blue_terracotta
fill 151 110 328 173 110 328 minecraft:magenta_terracotta
fill 151 110 358 173 110 358 minecraft:magenta_terracotta
setblock 152 110 327 minecraft:purple_terracotta
setblock 152 110 359 minecraft:purple_terracotta
setblock 153 110 324 minecraft:dark_prismarine
fill 153 110 326 154 110 326 minecraft:purple_terracotta
fill 153 110 327 171 110 327 minecraft:magenta_terracotta
fill 153 110 334 153 115 334 minecraft:magenta_terracotta
fill 153 110 352 178 110 352 minecraft:magenta_terracotta
fill 153 110 359 171 110 359 minecraft:magenta_terracotta
fill 153 110 360 154 110 360 minecraft:purple_terracotta
setblock 154 110 323 minecraft:dark_prismarine
fill 154 110 324 157 110 324 minecraft:blue_terracotta
setblock 154 110 362 minecraft:blue_terracotta
setblock 154 110 363 minecraft:dark_prismarine
fill 155 110 323 158 110 323 minecraft:blue_terracotta
fill 155 110 325 157 110 325 minecraft:purple_terracotta
fill 155 110 326 169 110 326 minecraft:magenta_terracotta
setblock 155 110 340 minecraft:magenta_terracotta
fill 155 110 341 155 110 344 minecraft:black_concrete
fill 155 110 360 169 110 360 minecraft:magenta_terracotta
fill 155 110 361 157 110 361 minecraft:purple_terracotta
setblock 155 110 362 minecraft:dark_prismarine
fill 155 110 363 158 110 363 minecraft:blue_terracotta
fill 156 110 339 156 110 340 minecraft:black_concrete
setblock 156 110 345 minecraft:black_concrete
fill 156 110 362 157 111 362 minecraft:blue_terracotta
setblock 157 110 338 minecraft:black_concrete
fill 158 110 324 166 110 324 minecraft:purple_terracotta
fill 158 110 325 166 110 325 minecraft:magenta_terracotta
fill 158 110 337 159 110 337 minecraft:black_concrete
fill 158 110 361 166 110 361 minecraft:magenta_terracotta
fill 158 110 362 166 110 362 minecraft:purple_terracotta
setblock 159 110 323 minecraft:dark_prismarine
setblock 159 110 336 minecraft:magenta_terracotta
setblock 159 110 348 minecraft:black_concrete
fill 159 110 351 178 111 351 minecraft:magenta_terracotta
setblock 159 110 363 minecraft:dark_prismarine
fill 160 110 323 163 110 323 minecraft:blue_terracotta
fill 160 110 336 163 110 336 minecraft:black_concrete
fill 160 110 363 162 110 363 minecraft:blue_terracotta
setblock 164 110 323 minecraft:dark_prismarine
setblock 164 110 337 minecraft:black_concrete
fill 165 110 323 168 110 323 minecraft:blue_terracotta
fill 167 110 325 169 110 325 minecraft:purple_terracotta
setblock 167 110 340 minecraft:black_concrete
fill 167 110 361 169 110 361 minecraft:purple_terracotta
setblock 169 110 323 minecraft:dark_prismarine
fill 169 110 335 178 111 339 minecraft:magenta_terracotta
fill 169 110 345 179 110 349 minecraft:magenta_terracotta
fill 170 110 323 173 110 323 minecraft:blue_terracotta
fill 170 110 326 171 110 326 minecraft:purple_terracotta
fill 170 110 360 171 110 360 minecraft:purple_terracotta
fill 171 110 324 172 110 324 minecraft:blue_terracotta
setblock 172 110 325 minecraft:dark_prismarine
setblock 172 110 327 minecraft:purple_terracotta
setblock 172 110 359 minecraft:purple_terracotta
setblock 173 110 324 minecraft:dark_prismarine
fill 173 110 325 176 110 325 minecraft:blue_terracotta
setblock 174 110 323 minecraft:dark_prismarine
fill 174 110 324 177 110 324 minecraft:blue_terracotta
fill 174 110 326 175 110 326 minecraft:blue_terracotta
setblock 174 110 328 minecraft:purple_terracotta
setblock 174 110 358 minecraft:purple_terracotta
setblock 174 110 363 minecraft:dark_prismarine
fill 175 110 323 178 110 323 minecraft:blue_terracotta
setblock 175 110 329 minecraft:purple_terracotta
setblock 175 110 357 minecraft:purple_terracotta
fill 175 110 363 178 110 363 minecraft:blue_terracotta
setblock 176 110 326 minecraft:dark_prismarine
setblock 176 110 330 minecraft:purple_terracotta
setblock 176 110 356 minecraft:purple_terracotta
setblock 177 110 325 minecraft:dark_prismarine
fill 177 110 326 179 110 327 minecraft:blue_terracotta
setblock 177 110 331 minecraft:purple_terracotta
setblock 177 110 355 minecraft:purple_terracotta
setblock 178 110 324 minecraft:dark_prismarine
fill 178 110 325 181 110 325 minecraft:blue_terracotta
setblock 178 110 328 minecraft:blue_terracotta
setblock 178 110 329 minecraft:dark_prismarine
setblock 178 110 333 minecraft:purple_terracotta
setblock 178 110 353 minecraft:purple_terracotta
fill 178 110 362 179 110 362 minecraft:blue_terracotta
setblock 179 110 323 minecraft:dark_prismarine
fill 179 110 324 182 110 324 minecraft:blue_terracotta
setblock 179 110 328 minecraft:dark_prismarine
fill 179 110 329 179 110 332 minecraft:blue_terracotta
fill 179 110 334 179 110 335 minecraft:purple_terracotta
fill 179 110 336 179 110 339 minecraft:magenta_terracotta
fill 179 110 351 179 110 352 minecraft:purple_terracotta
setblock 179 110 363 minecraft:dark_prismarine
fill 180 110 323 182 111 323 minecraft:blue_terracotta
setblock 180 110 326 minecraft:blue_terracotta
setblock 180 110 327 minecraft:dark_prismarine
fill 180 110 328 180 110 331 minecraft:blue_terracotta
setblock 180 110 332 minecraft:dark_prismarine
fill 180 110 333 182 110 334 minecraft:blue_terracotta
fill 180 110 336 180 110 338 minecraft:purple_terracotta
setblock 180 110 339 minecraft:magenta_terracotta
fill 180 110 345 180 110 347 minecraft:magenta_terracotta
fill 180 110 348 180 110 350 minecraft:purple_terracotta
setblock 180 110 362 minecraft:dark_prismarine
fill 180 110 363 182 111 363 minecraft:blue_terracotta
setblock 181 110 326 minecraft:dark_prismarine
fill 181 110 327 181 110 330 minecraft:blue_terracotta
setblock 181 110 331 minecraft:dark_prismarine
fill 181 110 332 182 112 332 minecraft:blue_terracotta
setblock 181 110 335 minecraft:blue_terracotta
setblock 181 110 336 minecraft:dark_prismarine
fill 181 110 339 181 110 347 minecraft:purple_terracotta
fill 181 110 348 181 110 350 minecraft:blue_terracotta
setblock 181 110 351 minecraft:dark_prismarine
fill 181 110 352 182 111 353 minecraft:blue_terracotta
fill 181 110 362 182 111 362 minecraft:blue_terracotta
setblock 182 110 325 minecraft:dark_prismarine
fill 182 110 326 182 110 329 minecraft:blue_terracotta
setblock 182 110 330 minecraft:dark_prismarine
fill 182 110 331 182 113 331 minecraft:blue_terracotta
setblock 182 110 335 minecraft:dark_prismarine
fill 182 110 336 182 110 339 minecraft:blue_terracotta
setblock 182 110 340 minecraft:dark_prismarine
fill 182 110 341 182 110 344 minecraft:blue_terracotta
setblock 182 110 345 minecraft:dark_prismarine
fill 182 110 346 182 110 349 minecraft:blue_terracotta
setblock 182 110 350 minecraft:dark_prismarine
fill 182 110 351 182 113 351 minecraft:blue_terracotta
setblock 182 110 354 minecraft:blue_terracotta
setblock 182 110 355 minecraft:dark_prismarine
fill 182 110 356 182 110 359 minecraft:blue_terracotta
setblock 182 110 360 minecraft:dark_prismarine
fill 182 110 361 182 113 361 minecraft:blue_terracotta
setblock 183 110 325 minecraft:light_blue_wool
fill 141 111 347 141 131 347 minecraft:black_concrete
setblock 142 111 323 minecraft:blue_terracotta
setblock 142 111 324 minecraft:dark_prismarine
fill 142 111 325 142 111 328 minecraft:blue_terracotta
setblock 142 111 329 minecraft:dark_prismarine
fill 142 111 330 142 114 330 minecraft:blue_terracotta
setblock 142 111 334 minecraft:dark_prismarine
setblock 142 111 343 minecraft:blue_terracotta
setblock 142 111 344 minecraft:dark_prismarine
fill 142 111 345 142 111 348 minecraft:blue_terracotta
setblock 142 111 349 minecraft:dark_prismarine
fill 142 111 350 142 111 353 minecraft:blue_terracotta
setblock 142 111 354 minecraft:dark_prismarine
fill 142 111 355 142 111 358 minecraft:blue_terracotta
setblock 142 111 359 minecraft:dark_prismarine
fill 142 111 360 142 111 363 minecraft:blue_terracotta
setblock 143 111 323 minecraft:dark_prismarine
fill 143 111 324 143 111 327 minecraft:blue_terracotta
setblock 143 111 328 minecraft:dark_prismarine
fill 143 111 329 143 112 329 minecraft:blue_terracotta
fill 143 111 345 143 118 345 minecraft:iron_bars
fill 143 111 346 143 111 347 minecraft:blue_terracotta
setblock 143 111 348 minecraft:dark_prismarine
fill 143 111 349 143 111 352 minecraft:blue_terracotta
setblock 143 111 353 minecraft:dark_prismarine
fill 143 111 354 143 114 354 minecraft:blue_terracotta
fill 143 111 356 143 112 356 minecraft:blue_terracotta
fill 143 111 361 143 111 362 minecraft:blue_terracotta
setblock 143 111 363 minecraft:dark_prismarine
fill 144 111 323 145 111 324 minecraft:blue_terracotta
fill 144 111 338 144 111 348 minecraft:purple_terracotta
fill 144 111 363 147 111 363 minecraft:blue_terracotta
fill 145 111 335 145 111 337 minecraft:purple_terracotta
fill 145 111 338 152 111 348 minecraft:magenta_terracotta
fill 145 111 349 145 111 351 minecraft:purple_terracotta
fill 146 111 323 147 111 323 minecraft:blue_terracotta
setblock 146 111 334 minecraft:purple_terracotta
fill 146 111 335 152 111 337 minecraft:magenta_terracotta
fill 146 111 349 152 111 351 minecraft:magenta_terracotta
setblock 146 111 352 minecraft:purple_terracotta
fill 147 111 332 147 111 333 minecraft:purple_terracotta
fill 147 111 334 152 111 334 minecraft:magenta_terracotta
fill 147 111 352 177 111 352 minecraft:magenta_terracotta
fill 147 111 353 147 111 354 minecraft:purple_terracotta
setblock 148 111 323 minecraft:dark_prismarine
setblock 148 111 331 minecraft:purple_terracotta
fill 148 111 332 176 111 333 minecraft:magenta_terracotta
fill 148 111 353 176 111 354 minecraft:magenta_terracotta
setblock 148 111 355 minecraft:purple_terracotta
setblock 148 111 363 minecraft:dark_prismarine
fill 149 111 323 152 111 323 minecraft:blue_terracotta
setblock 149 111 330 minecraft:purple_terracotta
fill 149 111 331 175 111 331 minecraft:magenta_terracotta
fill 149 111 355 175 111 355 minecraft:magenta_terracotta
setblock 149 111 356 minecraft:purple_terracotta
fill 149 111 363 152 111 363 minecraft:blue_terracotta
setblock 150 111 329 minecraft:purple_terracotta
fill 150 111 330 174 111 330 minecraft:magenta_terracotta
fill 150 111 356 174 111 356 minecraft:magenta_terracotta
setblock 150 111 357 minecraft:purple_terracotta
fill 151 111 328 152 111 328 minecraft:purple_terracotta
fill 151 111 329 173 111 329 minecraft:magenta_terracotta
fill 151 111 357 173 111 357 minecraft:magenta_terracotta
fill 151 111 358 152 111 358 minecraft:purple_terracotta
setblock 153 111 323 minecraft:dark_prismarine
fill 153 111 324 156 111 324 minecraft:blue_terracotta
setblock 153 111 327 minecraft:purple_terracotta
fill 153 111 328 171 111 328 minecraft:magenta_terracotta
fill 153 111 358 171 111 358 minecraft:magenta_terracotta
setblock 153 111 359 minecraft:purple_terracotta
setblock 153 111 363 minecraft:dark_prismarine
fill 154 111 323 157 111 323 minecraft:blue_terracotta
fill 154 111 326 156 111 326 minecraft:purple_terracotta
fill 154 111 327 170 111 327 minecraft:magenta_terracotta
fill 154 111 359 170 111 359 minecraft:magenta_terracotta
fill 154 111 360 156 111 360 minecraft:purple_terracotta
setblock 154 111 362 minecraft:dark_prismarine
fill 154 111 363 157 111 363 minecraft:blue_terracotta
fill 155 111 340 155 111 341 minecraft:gray_concrete
setblock 155 111 344 minecraft:gray_concrete
fill 155 111 362 155 112 362 minecraft:blue_terracotta
setblock 157 111 324 minecraft:dark_prismarine
fill 157 111 325 167 111 325 minecraft:purple_terracotta
fill 157 111 326 167 111 326 minecraft:magenta_terracotta
fill 157 111 360 167 111 360 minecraft:magenta_terracotta
fill 157 111 361 167 111 361 minecraft:purple_terracotta
setblock 158 111 323 minecraft:dark_prismarine
fill 158 111 324 161 111 324 minecraft:blue_terracotta
setblock 158 111 362 minecraft:blue_terracotta
setblock 158 111 363 minecraft:dark_prismarine
fill 159 111 323 162 111 323 minecraft:blue_terracotta
fill 159 111 336 160 111 336 minecraft:gray_concrete
fill 159 111 363 161 111 363 minecraft:blue_terracotta
setblock 162 111 324 minecraft:dark_prismarine
setblock 163 111 323 minecraft:dark_prismarine
setblock 163 111 336 minecraft:gray_concrete
fill 164 111 323 167 111 323 minecraft:blue_terracotta
fill 164 111 334 177 111 334 minecraft:magenta_terracotta
fill 164 111 350 178 111 350 minecraft:magenta_terracotta
setblock 167 111 363 minecraft:purple_concrete
setblock 168 111 323 minecraft:dark_prismarine
fill 168 111 326 170 111 326 minecraft:purple_terracotta
fill 168 111 360 170 111 360 minecraft:purple_terracotta
fill 169 111 323 172 111 323 minecraft:blue_terracotta
fill 169 111 345 178 111 349 minecraft:magenta_terracotta
fill 170 111 324 171 111 324 minecraft:blue_terracotta
fill 170 111 340 179 111 344 minecraft:magenta_terracotta
setblock 171 111 327 minecraft:purple_terracotta
setblock 171 111 359 minecraft:purple_terracotta
setblock 172 111 324 minecraft:dark_prismarine
fill 172 111 325 175 111 325 minecraft:blue_terracotta
fill 172 111 328 173 111 328 minecraft:purple_terracotta
fill 172 111 358 173 111 358 minecraft:purple_terracotta
setblock 173 111 323 minecraft:dark_prismarine
fill 173 111 324 176 111 324 minecraft:blue_terracotta
fill 174 111 323 177 111 323 minecraft:blue_terracotta
setblock 174 111 326 minecraft:blue_terracotta
setblock 174 111 329 minecraft:purple_terracotta
setblock 174 111 357 minecraft:purple_terracotta
fill 174 111 363 177 111 363 minecraft:blue_terracotta
setblock 175 111 326 minecraft:dark_prismarine
setblock 175 111 330 minecraft:purple_terracotta
setblock 175 111 356 minecraft:purple_terracotta
setblock 176 111 325 minecraft:dark_prismarine
fill 176 111 326 178 111 327 minecraft:blue_terracotta
setblock 176 111 331 minecraft:purple_terracotta
setblock 176 111 355 minecraft:purple_terracotta
setblock 177 111 324 minecraft:dark_prismarine
fill 177 111 325 180 111 325 minecraft:blue_terracotta
fill 177 111 332 177 111 333 minecraft:purple_terracotta
fill 177 111 353 177 111 354 minecraft:purple_terracotta
setblock 177 111 355 minecraft:black_concrete
setblock 178 111 323 minecraft:dark_prismarine
fill 178 111 324 181 111 324 minecraft:blue_terracotta
setblock 178 111 328 minecraft:dark_prismarine
fill 178 111 329 180 111 330 minecraft:blue_terracotta
setblock 178 111 334 minecraft:purple_terracotta
setblock 178 111 352 minecraft:purple_terracotta
fill 178 111 353 178 111 354 minecraft:black_concrete
setblock 178 111 362 minecraft:blue_terracotta
setblock 178 111 363 minecraft:dark_prismarine
fill 179 111 323 179 114 323 minecraft:blue_terracotta
setblock 179 111 326 minecraft:blue_terracotta
setblock 179 111 327 minecraft:dark_prismarine
fill 179 111 328 182 111 328 minecraft:blue_terracotta
setblock 179 111 331 minecraft:blue_terracotta
setblock 179 111 332 minecraft:dark_prismarine
fill 179 111 335 179 111 337 minecraft:purple_terracotta
fill 179 111 338 179 111 339 minecraft:magenta_terracotta
fill 179 111 345 179 111 348 minecraft:magenta_terracotta
fill 179 111 349 179 111 351 minecraft:purple_terracotta
setblock 179 111 362 minecraft:dark_prismarine
fill 179 111 363 179 114 363 minecraft:blue_terracotta
setblock 180 111 326 minecraft:dark_prismarine
fill 180 111 327 182 112 327 minecraft:blue_terracotta
setblock 180 111 331 minecraft:dark_prismarine
fill 180 111 332 180 112 334 minecraft:blue_terracotta
fill 180 111 338 180 111 348 minecraft:purple_terracotta
fill 180 111 349 181 111 349 minecraft:blue_terracotta
fill 180 111 362 180 112 362 minecraft:blue_terracotta
setblock 181 111 325 minecraft:dark_prismarine
fill 181 111 326 182 113 326 minecraft:blue_terracotta
setblock 181 111 329 minecraft:blue_terracotta
setblock 181 111 330 minecraft:dark_prismarine
fill 181 111 331 181 114 331 minecraft:blue_terracotta
fill 181 111 333 181 111 334 minecraft:blue_terracotta
setblock 181 111 335 minecraft:dark_prismarine
setblock 181 111 344 minecraft:blue_terracotta
setblock 181 111 345 minecraft:dark_prismarine
fill 181 111 346 182 111 348 minecraft:blue_terracotta
setblock 181 111 350 minecraft:dark_prismarine
fill 181 111 351 181 114 351 minecraft:blue_terracotta
setblock 182 111 324 minecraft:dark_prismarine
fill 182 111 325 182 114 325 minecraft:blue_terracotta
setblock 182 111 329 minecraft:dark_prismarine
fill 182 111 330 182 114 330 minecraft:blue_terracotta
setblock 182 111 333 minecraft:blue_terracotta
setblock 182 111 334 minecraft:dark_prismarine
fill 182 111 335 182 111 338 minecraft:blue_terracotta
fill 182 111 341 182 111 343 minecraft:blue_terracotta
setblock 182 111 344 minecraft:dark_prismarine
fill 182 111 345 182 112 345 minecraft:blue_terracotta
setblock 182 111 349 minecraft:dark_prismarine
fill 182 111 350 182 114 350 minecraft:blue_terracotta
setblock 182 111 354 minecraft:dark_prismarine
fill 182 111 355 182 111 358 minecraft:blue_terracotta
setblock 182 111 359 minecraft:dark_prismarine
fill 182 111 360 182 113 360 minecraft:blue_terracotta
fill 183 111 325 183 132 325 minecraft:black_concrete
setblock 141 112 351 minecraft:light_blue_wool
setblock 142 112 323 minecraft:dark_prismarine
fill 142 112 324 142 112 327 minecraft:blue_terracotta
setblock 142 112 328 minecraft:dark_prismarine
fill 142 112 329 142 115 329 minecraft:blue_terracotta
fill 142 112 331 142 112 332 minecraft:blue_terracotta
setblock 142 112 333 minecraft:dark_prismarine
fill 142 112 344 142 112 347 minecraft:blue_terracotta
setblock 142 112 348 minecraft:dark_prismarine
fill 142 112 349 142 112 352 minecraft:blue_terracotta
setblock 142 112 353 minecraft:dark_prismarine
fill 142 112 354 142 112 357 minecraft:blue_terracotta
setblock 142 112 358 minecraft:dark_prismarine
fill 142 112 359 142 112 362 minecraft:blue_terracotta
setblock 142 112 363 minecraft:dark_prismarine
fill 143 112 323 143 112 326 minecraft:blue_terracotta
setblock 143 112 327 minecraft:dark_prismarine
fill 143 112 328 143 113 328 minecraft:blue_terracotta
setblock 143 112 347 minecraft:dark_prismarine
fill 143 112 348 143 112 351 minecraft:blue_terracotta
setblock 143 112 352 minecraft:dark_prismarine
fill 143 112 353 143 115 353 minecraft:blue_terracotta
fill 143 112 363 146 112 363 minecraft:blue_terracotta
fill 144 112 323 144 112 324 minecraft:blue_terracotta
fill 144 112 341 144 112 345 minecraft:purple_terracotta
fill 145 112 323 146 112 323 minecraft:blue_terracotta
fill 145 112 337 145 112 340 minecraft:purple_terracotta
fill 145 112 341 152 112 345 minecraft:magenta_terracotta
fill 145 112 346 145 112 349 minecraft:purple_terracotta
fill 145 112 350 145 128 350 minecraft:magenta_terracotta
fill 146 112 335 146 112 336 minecraft:purple_terracotta
fill 146 112 337 152 112 340 minecraft:magenta_terracotta
fill 146 112 346 152 112 349 minecraft:magenta_terracotta
fill 146 112 350 146 112 351 minecraft:purple_terracotta
setblock 147 112 323 minecraft:dark_prismarine
fill 147 112 333 147 112 334 minecraft:purple_terracotta
fill 147 112 335 152 112 336 minecraft:magenta_terracotta
fill 147 112 350 152 112 351 minecraft:magenta_terracotta
fill 147 112 352 147 112 353 minecraft:purple_terracotta
setblock 147 112 363 minecraft:dark_prismarine
setblock 148 112 332 minecraft:purple_terracotta
fill 148 112 333 152 112 334 minecraft:magenta_terracotta
fill 148 112 352 176 112 353 minecraft:magenta_terracotta
setblock 148 112 354 minecraft:purple_terracotta
fill 148 112 363 151 112 363 minecraft:blue_terracotta
setblock 149 112 331 minecraft:purple_terracotta
fill 149 112 332 175 112 332 minecraft:magenta_terracotta
fill 149 112 354 175 112 354 minecraft:magenta_terracotta
setblock 149 112 355 minecraft:purple_terracotta
fill 150 112 323 151 112 323 minecraft:blue_terracotta
setblock 150 112 330 minecraft:purple_terracotta
fill 150 112 331 174 112 331 minecraft:magenta_terracotta
fill 150 112 355 174 112 355 minecraft:magenta_terracotta
setblock 150 112 356 minecraft:purple_terracotta
setblock 151 112 329 minecraft:purple_terracotta
fill 151 112 330 173 112 330 minecraft:magenta_terracotta
fill 151 112 356 173 112 356 minecraft:magenta_terracotta
setblock 151 112 357 minecraft:purple_terracotta
setblock 152 112 323 minecraft:dark_prismarine
fill 152 112 328 153 112 328 minecraft:purple_terracotta
fill 152 112 329 172 112 329 minecraft:magenta_terracotta
fill 152 112 357 172 112 357 minecraft:magenta_terracotta
fill 152 112 358 153 112 358 minecraft:purple_terracotta
setblock 152 112 363 minecraft:dark_prismarine
setblock 153 112 322 minecraft:cyan_concrete
fill 153 112 323 156 112 323 minecraft:blue_terracotta
fill 153 112 333 176 112 333 minecraft:magenta_terracotta
fill 153 112 363 156 112 363 minecraft:blue_terracotta
fill 154 112 324 155 112 324 minecraft:blue_terracotta
fill 154 112 327 155 112 327 minecraft:purple_terracotta
fill 154 112 328 170 112 328 minecraft:magenta_terracotta
fill 154 112 358 170 112 358 minecraft:magenta_terracotta
fill 154 112 359 155 112 359 minecraft:purple_terracotta
setblock 156 112 324 minecraft:dark_prismarine
fill 156 112 326 159 112 326 minecraft:purple_terracotta
fill 156 112 327 168 112 327 minecraft:magenta_terracotta
fill 156 112 359 168 112 359 minecraft:magenta_terracotta
fill 156 112 360 159 112 360 minecraft:purple_terracotta
setblock 156 112 362 minecraft:blue_terracotta
setblock 157 112 323 minecraft:dark_prismarine
fill 157 112 324 160 112 324 minecraft:blue_terracotta
setblock 157 112 363 minecraft:dark_prismarine
fill 158 112 323 161 112 323 minecraft:blue_terracotta
fill 158 112 363 160 112 363 minecraft:blue_terracotta
fill 159 112 351 177 112 351 minecraft:magenta_terracotta
fill 160 112 325 164 112 325 minecraft:purple_terracotta
fill 160 112 326 164 112 326 minecraft:magenta_terracotta
fill 160 112 360 164 112 360 minecraft:magenta_terracotta
fill 160 112 361 164 112 361 minecraft:purple_terracotta
setblock 161 112 324 minecraft:dark_prismarine
setblock 162 112 323 minecraft:dark_prismarine
setblock 163 112 323 minecraft:blue_terracotta
fill 164 112 334 176 112 334 minecraft:magenta_terracotta
fill 164 112 350 165 112 350 minecraft:black_concrete
fill 165 112 326 168 112 326 minecraft:purple_terracotta
fill 165 112 360 168 112 360 minecraft:purple_terracotta
fill 166 112 350 177 112 350 minecraft:magenta_terracotta
fill 169 112 323 171 112 323 minecraft:blue_terracotta
fill 169 112 327 170 112 327 minecraft:purple_terracotta
fill 169 112 335 177 112 339 minecraft:magenta_terracotta
fill 169 112 345 169 112 346 minecraft:black_concrete
fill 169 112 347 178 112 349 minecraft:magenta_terracotta
fill 169 112 359 170 112 359 minecraft:purple_terracotta
setblock 170 112 324 minecraft:blue_terracotta
fill 170 112 340 178 112 346 minecraft:magenta_terracotta
setblock 171 112 324 minecraft:dark_prismarine
fill 171 112 328 172 112 328 minecraft:purple_terracotta
fill 171 112 358 172 112 358 minecraft:purple_terracotta
setblock 172 112 323 minecraft:dark_prismarine
fill 172 112 324 174 112 325 minecraft:blue_terracotta
fill 173 112 323 176 112 323 minecraft:blue_terracotta
setblock 173 112 326 minecraft:blue_terracotta
setblock 173 112 329 minecraft:purple_terracotta
setblock 173 112 357 minecraft:purple_terracotta
setblock 173 112 363 minecraft:purple_concrete
setblock 174 112 326 minecraft:dark_prismarine
setblock 174 112 330 minecraft:purple_terracotta
setblock 174 112 356 minecraft:purple_terracotta
fill 174 112 363 176 112 363 minecraft:blue_terracotta
setblock 175 112 324 minecraft:blue_terracotta
setblock 175 112 325 minecraft:dark_prismarine
fill 175 112 326 177 112 327 minecraft:blue_terracotta
setblock 175 112 331 minecraft:purple_terracotta
setblock 175 112 355 minecraft:purple_terracotta
setblock 176 112 324 minecraft:dark_prismarine
fill 176 112 325 179 112 325 minecraft:blue_terracotta
setblock 176 112 332 minecraft:purple_terracotta
setblock 176 112 354 minecraft:purple_terracotta
setblock 177 112 323 minecraft:dark_prismarine
fill 177 112 324 180 112 324 minecraft:blue_terracotta
fill 177 112 333 177 112 334 minecraft:purple_terracotta
fill 177 112 352 177 112 353 minecraft:purple_terracotta
setblock 177 112 363 minecraft:dark_prismarine
fill 178 112 323 178 115 323 minecraft:blue_terracotta
setblock 178 112 326 minecraft:blue_terracotta
setblock 178 112 327 minecraft:dark_prismarine
fill 178 112 328 179 112 330 minecraft:blue_terracotta
fill 178 112 335 178 112 336 minecraft:purple_terracotta
fill 178 112 337 178 112 339 minecraft:magenta_terracotta
fill 178 112 350 178 112 351 minecraft:purple_terracotta
setblock 178 112 362 minecraft:dark_prismarine
fill 178 112 363 178 115 363 minecraft:blue_terracotta
setblock 179 112 326 minecraft:dark_prismarine
fill 179 112 327 179 114 327 minecraft:blue_terracotta
setblock 179 112 331 minecraft:dark_prismarine
fill 179 112 332 179 113 332 minecraft:blue_terracotta
fill 179 112 336 179 115 336 minecraft:black_concrete
fill 179 112 337 179 112 340 minecraft:purple_terracotta
fill 179 112 341 179 112 345 minecraft:magenta_terracotta
fill 179 112 346 179 112 349 minecraft:purple_terracotta
setblock 179 112 362 minecraft:blue_terracotta
fill 180 112 323 181 112 323 minecraft:blue_terracotta
setblock 180 112 325 minecraft:dark_prismarine
fill 180 112 326 180 115 326 minecraft:blue_terracotta
fill 180 112 328 180 112 329 minecraft:blue_terracotta
setblock 180 112 330 minecraft:dark_prismarine
fill 180 112 331 180 115 331 minecraft:blue_terracotta
fill 180 112 341 180 112 345 minecraft:purple_terracotta
fill 180 112 363 181 112 363 minecraft:blue_terracotta
setblock 181 112 324 minecraft:dark_prismarine
fill 181 112 325 181 115 325 minecraft:blue_terracotta
setblock 181 112 328 minecraft:blue_terracotta
setblock 181 112 329 minecraft:dark_prismarine
fill 181 112 330 181 115 330 minecraft:blue_terracotta
setblock 181 112 333 minecraft:blue_terracotta
setblock 181 112 334 minecraft:dark_prismarine
fill 181 112 335 182 112 335 minecraft:blue_terracotta
fill 181 112 346 181 112 348 minecraft:blue_terracotta
setblock 181 112 349 minecraft:dark_prismarine
fill 181 112 350 181 113 350 minecraft:blue_terracotta
fill 181 112 352 181 112 353 minecraft:blue_terracotta
setblock 181 112 354 minecraft:dark_prismarine
setblock 182 112 323 minecraft:dark_prismarine
fill 182 112 324 182 115 324 minecraft:blue_terracotta
setblock 182 112 328 minecraft:dark_prismarine
fill 182 112 329 182 115 329 minecraft:blue_terracotta
setblock 182 112 333 minecraft:dark_prismarine
fill 182 112 334 182 115 334 minecraft:blue_terracotta
fill 182 112 336 182 112 337 minecraft:blue_terracotta
setblock 182 112 344 minecraft:blue_terracotta
fill 182 112 346 182 112 347 minecraft:blue_terracotta
setblock 182 112 348 minecraft:dark_prismarine
fill 182 112 349 182 114 349 minecraft:blue_terracotta
setblock 182 112 352 minecraft:blue_terracotta
setblock 182 112 353 minecraft:dark_prismarine
fill 182 112 354 182 112 357 minecraft:blue_terracotta
setblock 182 112 358 minecraft:dark_prismarine
fill 182 112 359 182 113 359 minecraft:blue_terracotta
setblock 182 112 362 minecraft:blue_terracotta
setblock 182 112 363 minecraft:dark_prismarine
fill 141 113 351 141 131 351 minecraft:black_concrete
fill 142 113 323 142 113 326 minecraft:blue_terracotta
setblock 142 113 327 minecraft:dark_prismarine
fill 142 113 328 142 115 328 minecraft:blue_terracotta
setblock 142 113 331 minecraft:blue_terracotta
setblock 142 113 332 minecraft:dark_prismarine
setblock 142 113 333 minecraft:blue_terracotta
fill 142 113 345 142 113 346 minecraft:blue_terracotta
setblock 142 113 347 minecraft:dark_prismarine
fill 142 113 348 142 113 351 minecraft:blue_terracotta
setblock 142 113 352 minecraft:dark_prismarine
fill 142 113 353 142 113 356 minecraft:blue_terracotta
setblock 142 113 357 minecraft:dark_prismarine
fill 142 113 358 142 113 361 minecraft:blue_terracotta
setblock 142 113 362 minecraft:dark_prismarine
fill 142 113 363 145 113 363 minecraft:blue_terracotta
fill 143 113 323 144 113 323 minecraft:blue_terracotta
setblock 143 113 325 minecraft:blue_terracotta
setblock 143 113 326 minecraft:dark_prismarine
setblock 143 113 327 minecraft:blue_terracotta
fill 143 113 348 143 113 350 minecraft:blue_terracotta
setblock 143 113 351 minecraft:dark_prismarine
fill 143 113 352 143 116 352 minecraft:blue_terracotta
setblock 143 113 356 minecraft:dark_prismarine
setblock 144 113 325 minecraft:light[level=12]
setblock 144 113 332 minecraft:light[level=12]
setblock 144 113 339 minecraft:light[level=12]
setblock 144 113 346 minecraft:light[level=12]
setblock 144 113 353 minecraft:light[level=12]
setblock 144 113 360 minecraft:light[level=12]
setblock 145 113 323 minecraft:purple_concrete
fill 145 113 340 145 113 346 minecraft:purple_terracotta
fill 145 113 348 145 145 349 minecraft:magenta_terracotta
fill 146 113 337 146 113 339 minecraft:purple_terracotta
fill 146 113 340 152 113 346 minecraft:magenta_terracotta
fill 146 113 347 146 113 349 minecraft:purple_terracotta
fill 146 113 350 146 160 350 minecraft:magenta_terracotta
fill 147 113 335 147 113 336 minecraft:purple_terracotta
fill 147 113 337 152 113 339 minecraft:magenta_terracotta
fill 147 113 347 152 113 349 minecraft:magenta_terracotta
fill 147 113 350 147 113 351 minecraft:purple_terracotta
fill 148 113 333 148 113 334 minecraft:purple_terracotta
fill 148 113 335 152 113 336 minecraft:magenta_terracotta
fill 148 113 350 156 113 351 minecraft:magenta_terracotta
fill 148 113 352 148 113 353 minecraft:purple_terracotta
setblock 149 113 332 minecraft:purple_terracotta
fill 149 113 333 152 113 334 minecraft:magenta_terracotta
fill 149 113 352 175 113 353 minecraft:magenta_terracotta
setblock 149 113 354 minecraft:purple_terracotta
setblock 150 113 331 minecraft:purple_terracotta
fill 150 113 332 174 113 332 minecraft:magenta_terracotta
fill 150 113 354 174 113 354 minecraft:magenta_terracotta
setblock 150 113 355 minecraft:purple_terracotta
setblock 150 113 363 minecraft:blue_terracotta
setblock 151 113 323 minecraft:dark_prismarine
setblock 151 113 325 minecraft:light[level=12]
setblock 151 113 330 minecraft:purple_terracotta
fill 151 113 331 173 113 331 minecraft:magenta_terracotta
fill 151 113 355 173 113 355 minecraft:magenta_terracotta
setblock 151 113 356 minecraft:purple_terracotta
setblock 151 113 360 minecraft:light[level=12]
setblock 151 113 363 minecraft:dark_prismarine
fill 152 113 323 155 113 323 minecraft:blue_terracotta
fill 152 113 329 153 113 329 minecraft:purple_terracotta
fill 152 113 330 172 113 330 minecraft:magenta_terracotta
fill 152 113 356 172 113 356 minecraft:magenta_terracotta
fill 152 113 357 153 113 357 minecraft:purple_terracotta
fill 152 113 363 155 113 363 minecraft:blue_terracotta
fill 153 113 322 153 129 322 minecraft:black_concrete
fill 153 113 333 175 113 333 minecraft:magenta_terracotta
fill 154 113 328 155 113 328 minecraft:purple_terracotta
fill 154 113 329 170 113 329 minecraft:magenta_terracotta
fill 154 113 357 170 113 357 minecraft:magenta_terracotta
fill 154 113 358 155 113 358 minecraft:purple_terracotta
setblock 155 113 324 minecraft:dark_prismarine
setblock 156 113 323 minecraft:dark_prismarine
fill 156 113 324 159 113 324 minecraft:blue_terracotta
fill 156 113 327 158 113 327 minecraft:purple_terracotta
fill 156 113 328 168 113 328 minecraft:magenta_terracotta
fill 156 113 358 168 113 358 minecraft:magenta_terracotta
fill 156 113 359 158 113 359 minecraft:purple_terracotta
setblock 156 113 363 minecraft:dark_prismarine
fill 157 113 323 160 113 323 minecraft:blue_terracotta
fill 157 113 350 158 113 350 minecraft:black_concrete
fill 157 113 351 158 113 351 minecraft:magenta_terracotta
fill 157 113 363 159 113 363 minecraft:blue_terracotta
setblock 158 113 325 minecraft:light[level=12]
setblock 158 113 339 minecraft:light[level=12]
setblock 158 113 346 minecraft:light[level=12]
setblock 158 113 360 minecraft:light[level=12]
fill 159 113 326 165 113 326 minecraft:purple_terracotta
fill 159 113 327 165 113 327 minecraft:magenta_terracotta
fill 159 113 351 164 113 351 minecraft:black_concrete
fill 159 113 359 165 113 359 minecraft:magenta_terracotta
fill 159 113 360 165 113 360 minecraft:purple_terracotta
setblock 161 113 323 minecraft:dark_prismarine
fill 164 113 334 175 113 334 minecraft:magenta_terracotta
setblock 165 113 325 minecraft:light[level=12]
setblock 165 113 339 minecraft:light[level=12]
setblock 165 113 346 minecraft:light[level=12]
fill 165 113 350 166 113 350 minecraft:black_concrete
fill 165 113 351 176 113 351 minecraft:magenta_terracotta
fill 166 113 327 168 113 327 minecraft:purple_terracotta
fill 166 113 359 168 113 359 minecraft:purple_terracotta
fill 167 113 350 176 113 350 minecraft:magenta_terracotta
fill 169 113 323 170 113 323 minecraft:blue_terracotta
fill 169 113 328 170 113 328 minecraft:purple_terracotta
fill 169 113 335 176 113 337 minecraft:magenta_terracotta
fill 169 113 338 169 113 339 minecraft:black_concrete
fill 169 113 346 169 113 347 minecraft:black_concrete
fill 169 113 348 177 113 349 minecraft:magenta_terracotta
fill 169 113 358 170 113 358 minecraft:purple_terracotta
fill 170 113 338 177 113 339 minecraft:magenta_terracotta
fill 170 113 340 170 113 345 minecraft:black_concrete
fill 170 113 346 177 113 347 minecraft:magenta_terracotta
setblock 171 113 323 minecraft:dark_prismarine
fill 171 113 324 174 113 324 minecraft:blue_terracotta
fill 171 113 329 172 113 329 minecraft:purple_terracotta
fill 171 113 340 178 113 345 minecraft:magenta_terracotta
fill 171 113 357 172 113 357 minecraft:purple_terracotta
fill 172 113 323 175 113 323 minecraft:blue_terracotta
fill 172 113 325 173 113 325 minecraft:blue_terracotta
setblock 172 113 360 minecraft:light[level=12]
setblock 173 113 326 minecraft:dark_prismarine
setblock 173 113 330 minecraft:purple_terracotta
setblock 173 113 356 minecraft:purple_terracotta
setblock 174 113 325 minecraft:dark_prismarine
fill 174 113 326 177 113 326 minecraft:blue_terracotta
setblock 174 113 331 minecraft:purple_terracotta
setblock 174 113 355 minecraft:purple_terracotta
fill 174 113 363 175 113 363 minecraft:blue_terracotta
setblock 175 113 324 minecraft:dark_prismarine
fill 175 113 325 178 113 325 minecraft:blue_terracotta
setblock 175 113 332 minecraft:purple_terracotta
setblock 175 113 354 minecraft:purple_terracotta
setblock 176 113 323 minecraft:dark_prismarine
fill 176 113 324 179 113 324 minecraft:blue_terracotta
setblock 176 113 327 minecraft:blue_terracotta
fill 176 113 333 176 113 334 minecraft:purple_terracotta
fill 176 113 352 176 113 353 minecraft:purple_terracotta
setblock 176 113 363 minecraft:dark_prismarine
fill 177 113 323 177 116 323 minecraft:blue_terracotta
setblock 177 113 327 minecraft:dark_prismarine
fill 177 113 335 177 113 336 minecraft:purple_terracotta
setblock 177 113 337 minecraft:magenta_terracotta
fill 177 113 350 177 113 351 minecraft:purple_terracotta
fill 177 113 363 177 116 363 minecraft:blue_terracotta
setblock 178 113 326 minecraft:dark_prismarine
fill 178 113 327 178 113 329 minecraft:blue_terracotta
fill 178 113 336 178 156 336 minecraft:magenta_terracotta
fill 178 113 337 178 113 339 minecraft:purple_terracotta
setblock 178 113 346 minecraft:magenta_terracotta
fill 178 113 347 178 113 349 minecraft:purple_terracotta
setblock 179 113 325 minecraft:dark_prismarine
fill 179 113 326 179 114 326 minecraft:blue_terracotta
fill 179 113 328 179 113 329 minecraft:blue_terracotta
setblock 179 113 330 minecraft:dark_prismarine
fill 179 113 331 179 114 331 minecraft:blue_terracotta
fill 179 113 335 179 115 335 minecraft:black_concrete
fill 179 113 337 179 160 338 minecraft:magenta_terracotta
setblock 179 113 339 minecraft:light[level=12]
fill 179 113 340 179 113 346 minecraft:purple_terracotta
setblock 179 113 353 minecraft:light[level=12]
setblock 179 113 360 minecraft:light[level=12]
setblock 180 113 323 minecraft:blue_terracotta
setblock 180 113 324 minecraft:dark_prismarine
fill 180 113 325 180 115 325 minecraft:blue_terracotta
fill 180 113 327 180 113 328 minecraft:blue_terracotta
setblock 180 113 329 minecraft:dark_prismarine
fill 180 113 330 180 116 330 minecraft:blue_terracotta
fill 180 113 332 180 113 333 minecraft:blue_terracotta
fill 180 113 336 180 115 336 minecraft:black_concrete
setblock 180 113 363 minecraft:blue_terracotta
setblock 181 113 323 minecraft:dark_prismarine
fill 181 113 324 181 115 324 minecraft:blue_terracotta
setblock 181 113 327 minecraft:blue_terracotta
setblock 181 113 328 minecraft:dark_prismarine
fill 181 113 329 181 116 329 minecraft:blue_terracotta
setblock 181 113 332 minecraft:blue_terracotta
setblock 181 113 333 minecraft:dark_prismarine
fill 181 113 334 181 114 334 minecraft:blue_terracotta
setblock 181 113 348 minecraft:dark_prismarine
setblock 181 113 349 minecraft:blue_terracotta
setblock 181 113 352 minecraft:blue_terracotta
setblock 181 113 353 minecraft:dark_prismarine
fill 181 113 354 182 113 354 minecraft:blue_terracotta
setblock 181 113 363 minecraft:dark_prismarine
fill 182 113 323 182 116 323 minecraft:blue_terracotta
setblock 182 113 327 minecraft:dark_prismarine
fill 182 113 328 182 116 328 minecraft:blue_terracotta
setblock 182 113 332 minecraft:dark_prismarine
fill 182 113 333 182 116 333 minecraft:blue_terracotta
fill 182 113 335 182 113 336 minecraft:blue_terracotta
setblock 182 113 346 minecraft:blue_terracotta
setblock 182 113 347 minecraft:dark_prismarine
fill 182 113 348 182 114 348 minecraft:blue_terracotta
setblock 182 113 352 minecraft:dark_prismarine
fill 182 113 353 182 116 353 minecraft:blue_terracotta
fill 182 113 355 182 113 356 minecraft:blue_terracotta
setblock 182 113 357 minecraft:dark_prismarine
fill 182 113 358 182 114 358 minecraft:blue_terracotta
setblock 182 113 362 minecraft:dark_prismarine
fill 182 113 363 182 114 363 minecraft:blue_terracotta
fill 142 114 323 142 114 325 minecraft:blue_terracotta
setblock 142 114 326 minecraft:dark_prismarine
fill 142 114 327 142 115 327 minecraft:blue_terracotta
setblock 142 114 331 minecraft:dark_prismarine
setblock 142 114 332 minecraft:blue_terracotta
setblock 142 114 337 minecraft:purple_concrete
setblock 142 114 346 minecraft:dark_prismarine
fill 142 114 347 142 114 350 minecraft:blue_terracotta
setblock 142 114 351 minecraft:dark_prismarine
fill 142 114 352 142 114 355 minecraft:blue_terracotta
setblock 142 114 356 minecraft:dark_prismarine
fill 142 114 357 142 114 360 minecraft:blue_terracotta
setblock 142 114 361 minecraft:dark_prismarine
fill 142 114 362 142 114 363 minecraft:blue_terracotta
setblock 143 114 322 minecraft:cyan_concrete
setblock 143 114 323 minecraft:blue_terracotta
setblock 143 114 349 minecraft:blue_terracotta
setblock 143 114 350 minecraft:dark_prismarine
fill 143 114 351 143 115 351 minecraft:blue_terracotta
setblock 143 114 355 minecraft:dark_prismarine
fill 143 114 356 143 115 356 minecraft:blue_terracotta
setblock 143 114 363 minecraft:blue_terracotta
fill 146 114 340 146 114 346 minecraft:purple_terracotta
fill 146 114 348 146 134 349 minecraft:magenta_terracotta
fill 147 114 337 147 114 339 minecraft:purple_terracotta
fill 147 114 340 152 114 346 minecraft:magenta_terracotta
fill 147 114 347 147 114 349 minecraft:purple_terracotta
fill 147 114 350 147 164 350 minecraft:magenta_terracotta
fill 148 114 335 148 114 336 minecraft:purple_terracotta
fill 148 114 337 152 114 339 minecraft:magenta_terracotta
fill 148 114 347 153 114 349 minecraft:magenta_terracotta
fill 148 114 350 148 114 351 minecraft:purple_terracotta
fill 149 114 333 149 114 334 minecraft:purple_terracotta
fill 149 114 335 152 114 336 minecraft:magenta_terracotta
fill 149 114 350 155 114 351 minecraft:magenta_terracotta
fill 149 114 352 149 114 353 minecraft:purple_terracotta
fill 150 114 332 150 114 333 minecraft:purple_terracotta
fill 150 114 334 152 114 334 minecraft:magenta_terracotta
fill 150 114 352 158 114 352 minecraft:magenta_terracotta
fill 150 114 353 150 114 354 minecraft:purple_terracotta
fill 151 114 331 151 114 332 minecraft:purple_terracotta
fill 151 114 333 173 114 333 minecraft:magenta_terracotta
fill 151 114 353 173 114 353 minecraft:magenta_terracotta
fill 151 114 354 151 114 355 minecraft:purple_terracotta
fill 151 114 363 154 114 363 minecraft:blue_terracotta
fill 152 114 330 152 114 331 minecraft:purple_terracotta
fill 152 114 332 172 114 332 minecraft:magenta_terracotta
fill 152 114 354 172 114 354 minecraft:magenta_terracotta
fill 152 114 355 152 114 356 minecraft:purple_terracotta
fill 153 114 323 154 114 323 minecraft:blue_terracotta
setblock 153 114 330 minecraft:purple_terracotta
fill 153 114 331 171 114 331 minecraft:magenta_terracotta
fill 153 114 337 153 114 338 minecraft:magenta_terracotta
setblock 153 114 339 minecraft:gray_concrete
fill 153 114 345 153 114 346 minecraft:gray_concrete
fill 153 114 355 171 114 355 minecraft:magenta_terracotta
setblock 153 114 356 minecraft:purple_terracotta
fill 154 114 329 155 114 329 minecraft:purple_terracotta
fill 154 114 330 170 114 330 minecraft:magenta_terracotta
fill 154 114 334 157 114 334 minecraft:magenta_terracotta
fill 154 114 356 170 114 356 minecraft:magenta_terracotta
fill 154 114 357 155 114 357 minecraft:purple_terracotta
setblock 155 114 323 minecraft:dark_prismarine
setblock 155 114 341 minecraft:bone_block
setblock 155 114 363 minecraft:dark_prismarine
fill 156 114 323 159 114 323 minecraft:blue_terracotta
fill 156 114 328 158 114 328 minecraft:purple_terracotta
fill 156 114 329 168 114 329 minecraft:magenta_terracotta
setblock 156 114 339 minecraft:bone_block
setblock 156 114 350 minecraft:gray_concrete
setblock 156 114 351 minecraft:magenta_terracotta
fill 156 114 357 168 114 357 minecraft:magenta_terracotta
fill 156 114 358 158 114 358 minecraft:purple_terracotta
fill 156 114 363 157 114 363 minecraft:blue_terracotta
fill 157 114 351 158 114 351 minecraft:gray_concrete
setblock 158 114 334 minecraft:gray_concrete
fill 159 114 327 165 114 327 minecraft:purple_terracotta
fill 159 114 328 165 114 328 minecraft:magenta_terracotta
fill 159 114 336 159 115 336 minecraft:bone_block
fill 159 114 352 164 114 352 minecraft:gray_concrete
fill 159 114 358 165 114 358 minecraft:magenta_terracotta
fill 159 114 359 165 114 359 minecraft:purple_terracotta
setblock 160 114 363 minecraft:purple_concrete
setblock 161 114 336 minecraft:bone_block
fill 161 114 351 161 115 351 minecraft:bone_block
setblock 163 114 336 minecraft:bone_block
fill 163 114 351 163 115 351 minecraft:bone_block
setblock 164 114 323 minecraft:purple_concrete
fill 164 114 334 165 114 334 minecraft:gray_concrete
fill 165 114 350 165 115 350 minecraft:bone_block
fill 165 114 351 166 114 351 minecraft:gray_concrete
fill 165 114 352 174 114 352 minecraft:magenta_terracotta
fill 166 114 328 168 114 328 minecraft:purple_terracotta
fill 166 114 334 174 114 334 minecraft:magenta_terracotta
fill 166 114 358 168 114 358 minecraft:purple_terracotta
fill 167 114 350 168 114 350 minecraft:gray_concrete
fill 167 114 351 175 114 351 minecraft:magenta_terracotta
fill 169 114 329 170 114 329 minecraft:purple_terracotta
fill 169 114 335 175 114 336 minecraft:magenta_terracotta
setblock 169 114 337 minecraft:gray_concrete
fill 169 114 338 169 115 339 minecraft:bone_block
fill 169 114 345 170 114 345 minecraft:bone_block
fill 169 114 347 169 115 348 minecraft:bone_block
setblock 169 114 349 minecraft:gray_concrete
fill 169 114 350 175 114 350 minecraft:magenta_terracotta
fill 169 114 357 170 114 357 minecraft:purple_terracotta
setblock 170 114 323 minecraft:dark_prismarine
fill 170 114 337 176 114 337 minecraft:magenta_terracotta
fill 170 114 338 170 114 339 minecraft:gray_concrete
fill 170 114 341 170 116 341 minecraft:bone_block
fill 170 114 343 170 115 343 minecraft:bone_block
fill 170 114 346 170 114 347 minecraft:gray_concrete
fill 170 114 348 176 114 349 minecraft:magenta_terracotta
fill 171 114 323 173 114 324 minecraft:blue_terracotta
fill 171 114 330 172 114 330 minecraft:purple_terracotta
fill 171 114 338 176 114 339 minecraft:magenta_terracotta
fill 171 114 340 171 114 345 minecraft:gray_concrete
fill 171 114 346 176 114 347 minecraft:magenta_terracotta
fill 171 114 356 172 114 356 minecraft:purple_terracotta
setblock 172 114 325 minecraft:blue_terracotta
fill 172 114 328 172 122 328 minecraft:green_terracotta
fill 172 114 331 173 114 331 minecraft:purple_terracotta
fill 172 114 340 177 114 345 minecraft:magenta_terracotta
fill 172 114 355 173 114 355 minecraft:purple_terracotta
setblock 173 114 325 minecraft:dark_prismarine
fill 173 114 332 174 114 332 minecraft:purple_terracotta
fill 173 114 354 174 114 354 minecraft:purple_terracotta
setblock 174 114 323 minecraft:blue_terracotta
setblock 174 114 324 minecraft:dark_prismarine
fill 174 114 325 176 114 326 minecraft:blue_terracotta
fill 174 114 333 175 114 333 minecraft:purple_terracotta
fill 174 114 353 175 114 353 minecraft:purple_terracotta
setblock 174 114 363 minecraft:blue_terracotta
setblock 175 114 323 minecraft:dark_prismarine
fill 175 114 324 178 114 324 minecraft:blue_terracotta
setblock 175 114 334 minecraft:purple_terracotta
setblock 175 114 352 minecraft:purple_terracotta
setblock 175 114 363 minecraft:dark_prismarine
fill 176 114 323 176 117 323 minecraft:blue_terracotta
fill 176 114 335 176 114 336 minecraft:purple_terracotta
fill 176 114 350 176 114 351 minecraft:purple_terracotta
fill 176 114 353 176 115 353 minecraft:dark_prismarine
fill 176 114 363 176 117 363 minecraft:blue_terracotta
setblock 177 114 325 minecraft:blue_terracotta
setblock 177 114 326 minecraft:dark_prismarine
fill 177 114 336 177 153 336 minecraft:magenta_terracotta
fill 177 114 337 177 114 339 minecraft:purple_terracotta
setblock 177 114 346 minecraft:magenta_terracotta
fill 177 114 347 177 114 349 minecraft:purple_terracotta
setblock 178 114 325 minecraft:dark_prismarine
setblock 178 114 326 minecraft:blue_terracotta
fill 178 114 337 178 128 339 minecraft:magenta_terracotta
fill 178 114 340 178 114 346 minecraft:purple_terracotta
setblock 179 114 324 minecraft:dark_prismarine
fill 179 114 325 179 115 325 minecraft:blue_terracotta
setblock 179 114 328 minecraft:blue_terracotta
setblock 179 114 329 minecraft:dark_prismarine
setblock 179 114 330 minecraft:blue_terracotta
setblock 180 114 323 minecraft:dark_prismarine
fill 180 114 324 180 116 324 minecraft:blue_terracotta
setblock 180 114 327 minecraft:blue_terracotta
setblock 180 114 328 minecraft:dark_prismarine
fill 180 114 329 180 116 329 minecraft:blue_terracotta
setblock 180 114 332 minecraft:blue_terracotta
setblock 180 114 333 minecraft:dark_prismarine
setblock 180 114 363 minecraft:dark_prismarine
fill 181 114 323 181 116 323 minecraft:blue_terracotta
setblock 181 114 326 minecraft:blue_terracotta
setblock 181 114 327 minecraft:dark_prismarine
fill 181 114 328 181 116 328 minecraft:blue_terracotta
setblock 181 114 332 minecraft:dark_prismarine
fill 181 114 333 181 115 333 minecraft:blue_terracotta
setblock 181 114 352 minecraft:dark_prismarine
setblock 181 114 353 minecraft:blue_terracotta
fill 181 114 363 181 115 363 minecraft:blue_terracotta
setblock 182 114 326 minecraft:dark_prismarine
fill 182 114 327 182 117 327 minecraft:blue_terracotta
setblock 182 114 331 minecraft:dark_prismarine
fill 182 114 332 182 117 332 minecraft:blue_terracotta
setblock 182 114 335 minecraft:blue_terracotta
setblock 182 114 351 minecraft:dark_prismarine
fill 182 114 352 182 116 352 minecraft:blue_terracotta
fill 182 114 354 182 114 355 minecraft:blue_terracotta
setblock 182 114 356 minecraft:dark_prismarine
fill 182 114 357 182 117 357 minecraft:blue_terracotta
setblock 182 114 362 minecraft:blue_terracotta
setblock 142 115 324 minecraft:purple_concrete
setblock 142 115 325 minecraft:dark_prismarine
setblock 142 115 326 minecraft:blue_terracotta
setblock 142 115 330 minecraft:dark_prismarine
setblock 142 115 331 minecraft:blue_terracotta
setblock 142 115 343 minecraft:purple_concrete
fill 142 115 348 142 115 349 minecraft:blue_terracotta
setblock 142 115 350 minecraft:dark_prismarine
fill 142 115 351 142 115 354 minecraft:blue_terracotta
setblock 142 115 355 minecraft:dark_prismarine
fill 142 115 356 142 115 359 minecraft:blue_terracotta
setblock 142 115 360 minecraft:dark_prismarine
setblock 142 115 361 minecraft:blue_terracotta
fill 143 115 322 143 131 322 minecraft:black_concrete
setblock 143 115 350 minecraft:blue_terracotta
setblock 143 115 354 minecraft:dark_prismarine
fill 143 115 355 143 118 355 minecraft:blue_terracotta
fill 147 115 340 148 115 346 minecraft:purple_terracotta
fill 147 115 348 147 160 349 minecraft:magenta_terracotta
setblock 147 115 363 minecraft:purple_concrete
setblock 147 115 364 minecraft:light_blue_wool
fill 148 115 335 148 119 336 minecraft:magenta_terracotta
fill 148 115 337 148 115 339 minecraft:purple_terracotta
fill 148 115 347 148 115 349 minecraft:purple_terracotta
fill 149 115 334 149 128 334 minecraft:magenta_terracotta
fill 149 115 335 149 115 338 minecraft:purple_terracotta
fill 149 115 339 151 115 347 minecraft:magenta_terracotta
fill 149 115 348 149 115 351 minecraft:purple_terracotta
fill 150 115 334 150 115 336 minecraft:purple_terracotta
fill 150 115 337 152 115 338 minecraft:magenta_terracotta
fill 150 115 348 152 115 349 minecraft:magenta_terracotta
fill 150 115 350 150 115 352 minecraft:purple_terracotta
fill 151 115 333 151 115 334 minecraft:purple_terracotta
fill 151 115 335 152 115 336 minecraft:magenta_terracotta
fill 151 115 350 154 115 351 minecraft:magenta_terracotta
fill 151 115 352 151 115 353 minecraft:purple_terracotta
setblock 152 115 323 minecraft:purple_concrete
fill 152 115 332 152 115 333 minecraft:purple_terracotta
setblock 152 115 334 minecraft:magenta_terracotta
setblock 152 115 339 minecraft:magenta_terracotta
fill 152 115 340 152 115 346 minecraft:black_concrete
setblock 152 115 347 minecraft:magenta_terracotta
fill 152 115 352 157 115 352 minecraft:magenta_terracotta
fill 152 115 353 152 115 354 minecraft:purple_terracotta
fill 153 115 331 153 115 332 minecraft:purple_terracotta
fill 153 115 333 158 115 333 minecraft:magenta_terracotta
setblock 153 115 337 minecraft:magenta_terracotta
fill 153 115 338 153 115 339 minecraft:black_concrete
fill 153 115 345 153 117 345 minecraft:bone_block
fill 153 115 347 153 115 348 minecraft:black_concrete
setblock 153 115 349 minecraft:magenta_terracotta
fill 153 115 353 159 115 353 minecraft:magenta_terracotta
fill 153 115 354 153 115 355 minecraft:purple_terracotta
setblock 153 115 363 minecraft:blue_terracotta
fill 154 115 330 155 115 331 minecraft:purple_terracotta
fill 154 115 332 170 115 332 minecraft:magenta_terracotta
fill 154 115 334 156 115 334 minecraft:magenta_terracotta
fill 154 115 354 170 115 354 minecraft:magenta_terracotta
fill 154 115 355 155 115 356 minecraft:purple_terracotta
setblock 154 115 363 minecraft:dark_prismarine
fill 155 115 323 156 115 323 minecraft:blue_terracotta
setblock 155 115 350 minecraft:black_concrete
setblock 155 115 351 minecraft:magenta_terracotta
setblock 155 115 363 minecraft:blue_terracotta
setblock 155 115 364 minecraft:cyan_concrete
fill 156 115 329 157 115 330 minecraft:purple_terracotta
fill 156 115 331 168 115 331 minecraft:magenta_terracotta
fill 156 115 350 157 116 350 minecraft:bone_block
fill 156 115 351 157 115 351 minecraft:black_concrete
fill 156 115 355 168 115 355 minecraft:magenta_terracotta
fill 156 115 356 157 115 357 minecraft:purple_terracotta
fill 157 115 334 158 115 334 minecraft:black_concrete
setblock 158 115 323 minecraft:purple_concrete
fill 158 115 329 168 115 329 minecraft:purple_terracotta
fill 158 115 330 166 115 330 minecraft:magenta_terracotta
fill 158 115 351 159 116 351 minecraft:bone_block
fill 158 115 352 159 115 352 minecraft:black_concrete
fill 158 115 356 166 115 356 minecraft:magenta_terracotta
fill 158 115 357 168 115 357 minecraft:purple_terracotta
fill 158 115 358 158 160 358 minecraft:magenta_terracotta
fill 159 115 328 165 115 328 minecraft:purple_terracotta
fill 159 115 333 165 115 333 minecraft:black_concrete
fill 159 115 358 165 115 358 minecraft:purple_terracotta
fill 160 115 353 164 115 353 minecraft:black_concrete
fill 161 115 352 161 117 352 minecraft:bone_block
fill 163 115 352 163 117 352 minecraft:bone_block
fill 165 115 351 166 116 351 minecraft:bone_block
fill 165 115 352 166 115 352 minecraft:black_concrete
fill 165 115 353 171 115 353 minecraft:magenta_terracotta
fill 166 115 333 171 115 333 minecraft:magenta_terracotta
fill 166 115 334 167 115 334 minecraft:black_concrete
setblock 166 115 363 minecraft:purple_concrete
fill 167 115 330 170 115 330 minecraft:purple_terracotta
fill 167 115 350 168 116 350 minecraft:bone_block
fill 167 115 351 168 115 351 minecraft:black_concrete
fill 167 115 352 172 115 352 minecraft:magenta_terracotta
fill 167 115 356 170 115 356 minecraft:purple_terracotta
fill 168 115 334 172 115 334 minecraft:magenta_terracotta
fill 169 115 331 171 115 331 minecraft:purple_terracotta
fill 169 115 335 173 115 335 minecraft:magenta_terracotta
setblock 169 115 336 minecraft:black_concrete
setblock 169 115 350 minecraft:black_concrete
fill 169 115 351 173 115 351 minecraft:magenta_terracotta
fill 169 115 355 171 115 355 minecraft:purple_terracotta
fill 170 115 323 173 115 323 minecraft:blue_terracotta
fill 170 115 336 173 115 336 minecraft:magenta_terracotta
setblock 170 115 337 minecraft:black_concrete
fill 170 115 338 170 117 338 minecraft:bone_block
fill 170 115 340 170 116 340 minecraft:bone_block
fill 170 115 345 170 116 346 minecraft:bone_block
fill 170 115 348 170 117 348 minecraft:bone_block
setblock 170 115 349 minecraft:black_concrete
fill 170 115 350 173 115 350 minecraft:magenta_terracotta
fill 171 115 324 172 115 324 minecraft:blue_terracotta
fill 171 115 332 172 115 332 minecraft:purple_terracotta
fill 171 115 337 174 115 338 minecraft:magenta_terracotta
fill 171 115 339 171 115 340 minecraft:black_concrete
fill 171 115 341 171 117 341 minecraft:bone_block
fill 171 115 343 171 117 343 minecraft:bone_block
fill 171 115 345 171 117 345 minecraft:bone_block
fill 171 115 346 171 115 347 minecraft:black_concrete
fill 171 115 348 174 115 349 minecraft:magenta_terracotta
fill 171 115 354 172 115 354 minecraft:purple_terracotta
fill 172 115 333 173 115 333 minecraft:purple_terracotta
fill 172 115 339 175 115 340 minecraft:magenta_terracotta
fill 172 115 341 172 115 345 minecraft:black_concrete
fill 172 115 346 175 115 347 minecraft:magenta_terracotta
fill 172 115 353 173 115 353 minecraft:purple_terracotta
setblock 173 115 324 minecraft:dark_prismarine
fill 173 115 325 176 115 325 minecraft:blue_terracotta
fill 173 115 334 174 115 334 minecraft:purple_terracotta
fill 173 115 341 175 115 345 minecraft:magenta_terracotta
fill 173 115 352 174 115 352 minecraft:purple_terracotta
setblock 174 115 323 minecraft:dark_prismarine
fill 174 115 324 177 115 324 minecraft:blue_terracotta
fill 174 115 335 175 115 336 minecraft:purple_terracotta
fill 174 115 350 175 115 351 minecraft:purple_terracotta
setblock 174 115 363 minecraft:dark_prismarine
fill 175 115 323 175 118 323 minecraft:blue_terracotta
setblock 175 115 326 minecraft:blue_terracotta
fill 175 115 337 176 115 338 minecraft:purple_terracotta
fill 175 115 348 176 115 349 minecraft:purple_terracotta
fill 175 115 352 175 120 352 minecraft:magenta_terracotta
fill 175 115 363 175 118 363 minecraft:blue_terracotta
setblock 176 115 326 minecraft:dark_prismarine
fill 176 115 339 176 115 347 minecraft:purple_terracotta
fill 176 115 350 176 115 351 minecraft:magenta_terracotta
setblock 177 115 325 minecraft:dark_prismarine
setblock 177 115 326 minecraft:blue_terracotta
fill 177 115 337 177 160 338 minecraft:magenta_terracotta
fill 177 115 340 177 115 346 minecraft:purple_terracotta
setblock 178 115 324 minecraft:dark_prismarine
fill 178 115 325 178 116 325 minecraft:blue_terracotta
setblock 178 115 335 minecraft:black_concrete
setblock 179 115 323 minecraft:dark_prismarine
fill 179 115 324 179 116 324 minecraft:blue_terracotta
setblock 179 115 329 minecraft:blue_terracotta
setblock 179 115 363 minecraft:dark_prismarine
fill 180 115 323 180 117 323 minecraft:blue_terracotta
setblock 180 115 327 minecraft:dark_prismarine
setblock 180 115 328 minecraft:blue_terracotta
setblock 180 115 332 minecraft:dark_prismarine
setblock 180 115 335 minecraft:black_concrete
setblock 180 115 337 minecraft:black_concrete
setblock 180 115 363 minecraft:blue_terracotta
setblock 181 115 326 minecraft:dark_prismarine
fill 181 115 327 181 116 327 minecraft:blue_terracotta
setblock 181 115 331 minecraft:dark_prismarine
fill 181 115 332 181 116 332 minecraft:blue_terracotta
setblock 182 115 325 minecraft:dark_prismarine
fill 182 115 326 182 117 326 minecraft:blue_terracotta
setblock 182 115 330 minecraft:dark_prismarine
fill 182 115 331 182 118 331 minecraft:blue_terracotta
fill 182 115 337 182 116 337 minecraft:purple_concrete
setblock 182 115 343 minecraft:purple_concrete
setblock 182 115 350 minecraft:dark_prismarine
fill 182 115 351 182 116 351 minecraft:blue_terracotta
setblock 182 115 354 minecraft:blue_terracotta
setblock 182 115 355 minecraft:dark_prismarine
fill 182 115 356 182 118 356 minecraft:blue_terracotta
setblock 182 115 362 minecraft:purple_concrete
setblock 142 116 330 minecraft:purple_concrete
setblock 142 116 349 minecraft:dark_prismarine
fill 142 116 350 142 116 353 minecraft:blue_terracotta
setblock 142 116 354 minecraft:dark_prismarine
fill 142 116 355 142 116 358 minecraft:blue_terracotta
setblock 142 116 359 minecraft:dark_prismarine
setblock 142 116 360 minecraft:blue_terracotta
setblock 143 116 353 minecraft:dark_prismarine
fill 143 116 354 143 119 354 minecraft:blue_terracotta
setblock 146 116 323 minecraft:purple_concrete
fill 147 116 364 147 131 364 minecraft:black_concrete
fill 148 116 349 148 188 349 minecraft:magenta_terracotta
fill 149 116 335 149 120 337 minecraft:magenta_terracotta
fill 149 116 339 150 116 347 minecraft:purple_terracotta
fill 150 116 334 150 143 336 minecraft:magenta_terracotta
fill 150 116 337 152 116 338 minecraft:purple_terracotta
fill 150 116 348 152 116 349 minecraft:purple_terracotta
fill 151 116 335 153 116 336 minecraft:purple_terracotta
fill 151 116 339 151 116 340 minecraft:purple_terracotta
fill 151 116 341 151 116 344 minecraft:black_concrete
fill 151 116 345 151 116 347 minecraft:purple_terracotta
fill 151 116 350 153 116 351 minecraft:purple_terracotta
fill 152 116 334 155 116 334 minecraft:purple_terracotta
setblock 152 116 339 minecraft:black_concrete
fill 152 116 340 152 117 346 minecraft:bone_block
setblock 152 116 347 minecraft:black_concrete
fill 152 116 352 155 116 352 minecraft:purple_terracotta
fill 153 116 333 157 116 333 minecraft:purple_terracotta
fill 153 116 337 153 117 338 minecraft:bone_block
fill 153 116 346 153 117 346 minecraft:bone_block
fill 153 116 348 153 117 349 minecraft:bone_block
fill 153 116 353 157 116 353 minecraft:purple_terracotta
setblock 153 116 363 minecraft:purple_concrete
fill 154 116 332 159 116 332 minecraft:purple_terracotta
setblock 154 116 350 minecraft:black_concrete
setblock 154 116 351 minecraft:purple_terracotta
fill 154 116 354 160 116 354 minecraft:purple_terracotta
fill 155 116 350 155 117 351 minecraft:bone_block
fill 155 116 364 155 131 364 minecraft:black_concrete
fill 156 116 331 168 116 331 minecraft:purple_terracotta
setblock 156 116 334 minecraft:black_concrete
fill 156 116 351 156 117 351 minecraft:bone_block
setblock 156 116 352 minecraft:black_concrete
fill 156 116 355 168 116 355 minecraft:purple_terracotta
fill 157 116 334 158 117 334 minecraft:bone_block
fill 157 116 352 160 117 352 minecraft:bone_block
fill 157 116 356 157 135 357 minecraft:magenta_terracotta
fill 158 116 330 166 116 330 minecraft:purple_terracotta
fill 158 116 333 158 117 333 minecraft:bone_block
fill 158 116 353 158 117 353 minecraft:bone_block
fill 158 116 356 166 116 356 minecraft:purple_terracotta
fill 158 116 357 160 122 357 minecraft:magenta_terracotta
setblock 159 116 333 minecraft:black_concrete
setblock 159 116 353 minecraft:black_concrete
fill 159 116 358 159 132 358 minecraft:magenta_terracotta
fill 160 116 332 163 116 332 minecraft:black_concrete
fill 160 116 333 161 117 333 minecraft:bone_block
fill 160 116 353 161 117 353 minecraft:bone_block
fill 161 116 354 163 116 354 minecraft:black_concrete
fill 163 116 333 164 117 333 minecraft:bone_block
fill 163 116 353 164 117 353 minecraft:bone_block
fill 164 116 329 166 124 329 minecraft:magenta_terracotta
fill 164 116 332 170 116 332 minecraft:purple_terracotta
fill 164 116 334 167 117 334 minecraft:bone_block
fill 164 116 352 167 117 352 minecraft:bone_block
fill 164 116 354 170 116 354 minecraft:purple_terracotta
fill 165 116 328 165 129 328 minecraft:magenta_terracotta
setblock 165 116 333 minecraft:black_concrete
setblock 165 116 353 minecraft:black_concrete
fill 166 116 333 166 117 333 minecraft:bone_block
fill 166 116 353 166 117 353 minecraft:bone_block
fill 167 116 333 171 116 333 minecraft:purple_terracotta
fill 167 116 353 171 116 353 minecraft:purple_terracotta
setblock 168 116 334 minecraft:black_concrete
fill 168 116 351 169 117 351 minecraft:bone_block
setblock 168 116 352 minecraft:black_concrete
fill 169 116 334 172 116 334 minecraft:purple_terracotta
fill 169 116 335 169 117 336 minecraft:bone_block
fill 169 116 338 169 117 338 minecraft:bone_block
fill 169 116 348 169 117 348 minecraft:bone_block
fill 169 116 350 169 117 350 minecraft:bone_block
fill 169 116 352 172 116 352 minecraft:purple_terracotta
fill 170 116 323 172 116 323 minecraft:blue_terracotta
fill 170 116 335 173 116 335 minecraft:purple_terracotta
setblock 170 116 336 minecraft:black_concrete
fill 170 116 337 171 117 337 minecraft:bone_block
setblock 170 116 339 minecraft:bone_block
setblock 170 116 347 minecraft:bone_block
fill 170 116 349 171 117 349 minecraft:bone_block
setblock 170 116 350 minecraft:black_concrete
fill 170 116 351 173 116 351 minecraft:purple_terracotta
fill 171 116 336 173 116 336 minecraft:purple_terracotta
fill 171 116 338 171 117 338 minecraft:bone_block
fill 171 116 340 172 117 340 minecraft:bone_block
fill 171 116 342 172 117 342 minecraft:bone_block
fill 171 116 344 172 117 344 minecraft:bone_block
fill 171 116 346 172 117 346 minecraft:bone_block
fill 171 116 348 171 117 348 minecraft:bone_block
fill 171 116 350 173 116 350 minecraft:purple_terracotta
setblock 172 116 324 minecraft:dark_prismarine
fill 172 116 337 174 116 338 minecraft:purple_terracotta
setblock 172 116 339 minecraft:black_concrete
fill 172 116 341 172 117 341 minecraft:bone_block
fill 172 116 343 172 117 343 minecraft:bone_block
fill 172 116 345 172 117 345 minecraft:bone_block
setblock 172 116 347 minecraft:black_concrete
fill 172 116 348 174 116 349 minecraft:purple_terracotta
setblock 172 116 363 minecraft:purple_concrete
setblock 173 116 323 minecraft:dark_prismarine
fill 173 116 324 175 116 325 minecraft:blue_terracotta
fill 173 116 339 175 116 341 minecraft:purple_terracotta
fill 173 116 342 173 116 344 minecraft:black_concrete
fill 173 116 345 175 116 347 minecraft:purple_terracotta
fill 174 116 323 174 119 323 minecraft:blue_terracotta
fill 174 116 342 175 116 344 minecraft:purple_terracotta
fill 174 116 350 174 140 352 minecraft:magenta_terracotta
fill 174 116 363 174 119 363 minecraft:blue_terracotta
fill 175 116 349 175 118 351 minecraft:magenta_terracotta
setblock 176 116 324 minecraft:blue_terracotta
setblock 176 116 325 minecraft:dark_prismarine
fill 176 116 337 176 120 337 minecraft:magenta_terracotta
setblock 177 116 324 minecraft:dark_prismarine
setblock 177 116 325 minecraft:blue_terracotta
setblock 178 116 323 minecraft:dark_prismarine
fill 178 116 324 178 117 324 minecraft:blue_terracotta
setblock 178 116 363 minecraft:dark_prismarine
fill 179 116 323 179 118 323 minecraft:blue_terracotta
setblock 179 116 363 minecraft:blue_terracotta
setblock 181 116 326 minecraft:blue_terracotta
setblock 181 116 330 minecraft:dark_prismarine
fill 181 116 331 181 117 331 minecraft:blue_terracotta
setblock 182 116 324 minecraft:dark_prismarine
setblock 182 116 325 minecraft:blue_terracotta
setblock 182 116 329 minecraft:dark_prismarine
fill 182 116 330 182 118 330 minecraft:blue_terracotta
setblock 182 116 334 minecraft:dark_prismarine
setblock 182 116 354 minecraft:dark_prismarine
fill 182 116 355 182 119 355 minecraft:blue_terracotta
setblock 142 117 336 minecraft:purple_concrete
fill 142 117 350 142 117 352 minecraft:blue_terracotta
setblock 142 117 353 minecraft:dark_prismarine
fill 142 117 354 142 117 357 minecraft:blue_terracotta
setblock 142 117 358 minecraft:dark_prismarine
fill 142 117 359 142 120 359 minecraft:blue_terracotta
fill 142 117 361 142 118 361 minecraft:purple_concrete
setblock 143 117 353 minecraft:blue_terracotta
setblock 144 117 325 minecraft:light[level=13]
setblock 144 117 333 minecraft:light[level=13]
setblock 144 117 341 minecraft:light[level=13]
setblock 144 117 349 minecraft:light[level=13]
setblock 144 117 357 minecraft:light[level=13]
fill 150 117 337 150 126 337 minecraft:magenta_terracotta
fill 151 117 335 151 134 336 minecraft:magenta_terracotta
setblock 151 117 340 minecraft:bone_block
fill 151 117 342 151 117 344 minecraft:bone_block
setblock 151 117 346 minecraft:bone_block
setblock 152 117 325 minecraft:light[level=13]
setblock 152 117 333 minecraft:light[level=13]
fill 152 117 339 153 117 339 minecraft:bone_block
fill 152 117 347 153 117 347 minecraft:bone_block
setblock 152 117 349 minecraft:light[level=13]
setblock 152 117 357 minecraft:light[level=13]
fill 153 117 340 154 117 340 minecraft:stone_bricks
setblock 153 117 341 minecraft:bone_block
fill 153 117 342 153 117 343 minecraft:stone_bricks
setblock 153 117 344 minecraft:bone_block
fill 154 117 341 154 117 342 minecraft:stone_bricks
setblock 154 117 351 minecraft:bone_block
setblock 155 117 334 minecraft:bone_block
setblock 155 117 352 minecraft:bone_block
setblock 156 117 350 minecraft:bone_block
setblock 157 117 333 minecraft:bone_block
setblock 157 117 353 minecraft:bone_block
fill 158 117 335 159 117 335 minecraft:stone_bricks
setblock 158 117 348 minecraft:stone_bricks
setblock 158 117 351 minecraft:bone_block
fill 158 117 355 159 120 356 minecraft:magenta_terracotta
setblock 159 117 333 minecraft:bone_block
setblock 159 117 334 minecraft:stone_bricks
setblock 159 117 353 minecraft:bone_block
setblock 159 117 363 minecraft:purple_concrete
setblock 160 117 325 minecraft:light[level=13]
fill 160 117 332 161 117 332 minecraft:bone_block
fill 160 117 334 161 117 334 minecraft:bone_block
setblock 160 117 341 minecraft:light[level=13]
fill 160 117 349 161 117 350 minecraft:stone_bricks
fill 160 117 354 161 117 354 minecraft:bone_block
fill 160 117 356 160 121 356 minecraft:magenta_terracotta
fill 162 117 334 163 117 335 minecraft:stone_bricks
fill 163 117 332 164 117 332 minecraft:bone_block
fill 163 117 354 164 117 354 minecraft:bone_block
fill 164 117 330 166 124 330 minecraft:magenta_terracotta
setblock 165 117 323 minecraft:purple_concrete
fill 165 117 331 166 126 331 minecraft:magenta_terracotta
setblock 165 117 333 minecraft:bone_block
setblock 165 117 353 minecraft:bone_block
fill 166 117 328 166 157 328 minecraft:magenta_terracotta
setblock 166 117 351 minecraft:bone_block
setblock 167 117 333 minecraft:bone_block
setblock 167 117 353 minecraft:bone_block
setblock 168 117 325 minecraft:light[level=13]
setblock 168 117 333 minecraft:light[level=13]
setblock 168 117 340 minecraft:stone_bricks
setblock 168 117 341 minecraft:light[level=13]
fill 168 117 342 169 117 343 minecraft:stone_bricks
setblock 168 117 350 minecraft:bone_block
setblock 168 117 357 minecraft:light[level=13]
setblock 169 117 334 minecraft:bone_block
setblock 169 117 344 minecraft:stone_bricks
setblock 169 117 352 minecraft:bone_block
setblock 170 117 335 minecraft:bone_block
setblock 170 117 351 minecraft:bone_block
setblock 171 117 323 minecraft:blue_terracotta
fill 171 117 339 172 117 339 minecraft:bone_block
fill 171 117 347 172 117 347 minecraft:bone_block
setblock 172 117 323 minecraft:dark_prismarine
fill 172 117 324 175 117 324 minecraft:blue_terracotta
fill 173 117 323 173 120 323 minecraft:blue_terracotta
setblock 173 117 340 minecraft:bone_block
fill 173 117 342 173 117 344 minecraft:bone_block
setblock 173 117 346 minecraft:bone_block
fill 173 117 350 173 134 351 minecraft:magenta_terracotta
fill 174 117 349 174 126 349 minecraft:magenta_terracotta
setblock 175 117 325 minecraft:dark_prismarine
setblock 176 117 324 minecraft:dark_prismarine
setblock 176 117 325 minecraft:light[level=13]
setblock 176 117 333 minecraft:light[level=13]
setblock 176 117 341 minecraft:light[level=13]
setblock 176 117 349 minecraft:light[level=13]
setblock 176 117 357 minecraft:light[level=13]
setblock 177 117 323 minecraft:dark_prismarine
fill 177 117 324 177 118 324 minecraft:blue_terracotta
setblock 177 117 363 minecraft:dark_prismarine
fill 178 117 323 178 120 323 minecraft:blue_terracotta
fill 178 117 363 178 120 363 minecraft:blue_terracotta
setblock 181 117 329 minecraft:dark_prismarine
setblock 181 117 330 minecraft:blue_terracotta
setblock 182 117 325 minecraft:purple_concrete
setblock 182 117 328 minecraft:dark_prismarine
fill 182 117 329 182 118 329 minecraft:blue_terracotta
setblock 182 117 333 minecraft:dark_prismarine
setblock 182 117 350 minecraft:purple_concrete
setblock 182 117 353 minecraft:dark_prismarine
fill 182 117 354 182 120 354 minecraft:blue_terracotta
setblock 141 118 326 minecraft:light_blue_wool
fill 142 118 323 142 119 323 minecraft:purple_concrete
setblock 142 118 342 minecraft:purple_concrete
fill 142 118 350 142 118 351 minecraft:blue_terracotta
setblock 142 118 352 minecraft:dark_prismarine
fill 142 118 353 142 118 356 minecraft:blue_terracotta
setblock 142 118 357 minecraft:dark_prismarine
fill 142 118 358 142 121 358 minecraft:blue_terracotta
setblock 146 118 363 minecraft:purple_concrete
fill 151 118 339 152 162 341 minecraft:dark_prismarine
fill 153 118 340 153 162 340 minecraft:dark_prismarine
setblock 159 118 323 minecraft:purple_concrete
setblock 165 118 363 minecraft:purple_concrete
setblock 170 118 323 minecraft:blue_terracotta
setblock 171 118 323 minecraft:dark_prismarine
fill 172 118 323 172 120 324 minecraft:blue_terracotta
fill 173 118 324 174 118 324 minecraft:blue_terracotta
setblock 175 118 324 minecraft:dark_prismarine
setblock 176 118 323 minecraft:dark_prismarine
fill 176 118 324 176 119 324 minecraft:blue_terracotta
setblock 176 118 363 minecraft:dark_prismarine
fill 177 118 323 177 121 323 minecraft:blue_terracotta
fill 177 118 363 177 121 363 minecraft:blue_terracotta
setblock 182 118 328 minecraft:blue_terracotta
setblock 182 118 332 minecraft:dark_prismarine
setblock 182 118 344 minecraft:purple_concrete
setblock 182 118 357 minecraft:dark_prismarine
fill 182 118 358 182 121 358 minecraft:blue_terracotta
setblock 183 118 328 minecraft:light_blue_wool
fill 183 118 329 183 131 329 minecraft:black_concrete
setblock 183 118 334 minecraft:cyan_concrete
fill 141 119 326 141 128 326 minecraft:black_concrete
setblock 142 119 329 minecraft:purple_concrete
setblock 142 119 348 minecraft:purple_concrete
setblock 142 119 351 minecraft:dark_prismarine
fill 142 119 352 142 119 355 minecraft:blue_terracotta
setblock 142 119 356 minecraft:dark_prismarine
fill 142 119 357 142 122 357 minecraft:blue_terracotta
setblock 142 119 360 minecraft:blue_terracotta
setblock 143 119 355 minecraft:dark_prismarine
fill 143 119 356 143 122 356 minecraft:blue_terracotta
setblock 144 119 325 minecraft:light[level=12]
setblock 144 119 332 minecraft:light[level=12]
setblock 144 119 339 minecraft:light[level=12]
setblock 144 119 346 minecraft:light[level=12]
setblock 144 119 353 minecraft:light[level=12]
setblock 144 119 360 minecraft:light[level=12]
fill 150 119 339 150 120 340 minecraft:black_concrete
setblock 151 119 325 minecraft:light[level=12]
setblock 151 119 332 minecraft:light[level=12]
setblock 151 119 346 minecraft:light[level=12]
setblock 151 119 353 minecraft:light[level=12]
setblock 151 119 360 minecraft:light[level=12]
fill 152 119 338 152 120 338 minecraft:black_concrete
setblock 152 119 363 minecraft:purple_concrete
setblock 153 119 323 minecraft:purple_concrete
fill 153 119 339 153 120 339 minecraft:black_concrete
fill 153 119 341 153 120 341 minecraft:black_concrete
setblock 158 119 325 minecraft:light[level=12]
setblock 158 119 332 minecraft:light[level=12]
setblock 158 119 339 minecraft:light[level=12]
setblock 158 119 346 minecraft:light[level=12]
setblock 158 119 353 minecraft:light[level=12]
setblock 158 119 360 minecraft:light[level=12]
setblock 165 119 325 minecraft:light[level=12]
setblock 165 119 332 minecraft:light[level=12]
setblock 165 119 339 minecraft:light[level=12]
setblock 165 119 346 minecraft:light[level=12]
setblock 165 119 353 minecraft:light[level=12]
setblock 165 119 360 minecraft:light[level=12]
fill 167 119 329 167 160 330 minecraft:magenta_terracotta
setblock 170 119 323 minecraft:dark_prismarine
fill 171 119 323 171 122 323 minecraft:blue_terracotta
setblock 171 119 363 minecraft:purple_concrete
setblock 172 119 325 minecraft:light[level=12]
setblock 172 119 332 minecraft:light[level=12]
setblock 172 119 339 minecraft:light[level=12]
setblock 172 119 346 minecraft:light[level=12]
setblock 172 119 353 minecraft:light[level=12]
setblock 172 119 360 minecraft:light[level=12]
fill 172 119 363 173 120 363 minecraft:blue_terracotta
setblock 173 119 324 minecraft:blue_terracotta
setblock 174 119 324 minecraft:dark_prismarine
setblock 175 119 323 minecraft:dark_prismarine
fill 175 119 324 175 122 324 minecraft:blue_terracotta
fill 175 119 350 175 128 351 minecraft:magenta_terracotta
setblock 175 119 363 minecraft:dark_prismarine
fill 176 119 323 176 122 323 minecraft:blue_terracotta
fill 176 119 363 176 122 363 minecraft:blue_terracotta
setblock 179 119 325 minecraft:light[level=12]
setblock 179 119 332 minecraft:light[level=12]
setblock 179 119 339 minecraft:light[level=12]
setblock 179 119 346 minecraft:light[level=12]
setblock 179 119 353 minecraft:light[level=12]
setblock 179 119 360 minecraft:light[level=12]
setblock 182 119 338 minecraft:purple_concrete
setblock 182 119 356 minecraft:dark_prismarine
fill 182 119 357 182 122 357 minecraft:blue_terracotta
fill 182 119 359 182 120 359 minecraft:blue_terracotta
setblock 183 119 324 minecraft:cyan_concrete
fill 183 119 328 183 131 328 minecraft:black_concrete
fill 183 119 334 183 127 334 minecraft:black_concrete
setblock 142 120 335 minecraft:purple_concrete
fill 142 120 351 142 120 354 minecraft:blue_terracotta
setblock 142 120 355 minecraft:dark_prismarine
fill 142 120 356 142 123 356 minecraft:blue_terracotta
setblock 142 120 360 minecraft:dark_prismarine
setblock 143 120 354 minecraft:dark_prismarine
fill 143 120 355 143 123 355 minecraft:blue_terracotta
fill 143 120 357 143 121 357 minecraft:blue_terracotta
setblock 147 120 323 minecraft:purple_concrete
setblock 148 120 335 minecraft:magenta_terracotta
setblock 150 120 341 minecraft:black_concrete
fill 150 120 363 152 121 363 minecraft:blue_terracotta
setblock 151 120 338 minecraft:black_concrete
fill 151 120 342 153 120 342 minecraft:black_concrete
fill 153 120 336 157 120 337 minecraft:dark_oak_planks
setblock 153 120 338 minecraft:black_concrete
fill 153 120 347 157 120 348 minecraft:dark_oak_planks
fill 154 120 335 157 120 335 minecraft:dark_oak_planks
fill 154 120 338 157 120 338 minecraft:dark_oak_planks
fill 154 120 339 154 120 341 minecraft:black_concrete
fill 154 120 346 157 120 346 minecraft:dark_oak_planks
fill 154 120 349 157 120 349 minecraft:dark_oak_planks
fill 155 120 334 156 120 334 minecraft:dark_oak_planks
fill 155 120 350 156 120 350 minecraft:dark_oak_planks
setblock 158 120 363 minecraft:purple_concrete
fill 165 120 335 168 120 338 minecraft:dark_oak_planks
fill 165 120 346 168 120 349 minecraft:dark_oak_planks
setblock 166 120 323 minecraft:purple_concrete
fill 166 120 334 167 120 334 minecraft:dark_oak_planks
fill 166 120 350 167 120 350 minecraft:dark_oak_planks
setblock 166 120 364 minecraft:cyan_concrete
setblock 169 120 323 minecraft:dark_prismarine
fill 169 120 336 169 120 337 minecraft:dark_oak_planks
fill 169 120 347 169 120 348 minecraft:dark_oak_planks
fill 170 120 323 170 123 323 minecraft:blue_terracotta
fill 171 120 363 171 122 363 minecraft:blue_terracotta
setblock 173 120 324 minecraft:dark_prismarine
fill 173 120 352 173 164 352 minecraft:magenta_terracotta
setblock 174 120 323 minecraft:dark_prismarine
fill 174 120 324 174 123 324 minecraft:blue_terracotta
setblock 174 120 363 minecraft:dark_prismarine
fill 175 120 323 175 123 323 minecraft:blue_terracotta
fill 175 120 363 175 123 363 minecraft:blue_terracotta
setblock 182 120 332 minecraft:purple_concrete
setblock 182 120 351 minecraft:purple_concrete
setblock 182 120 355 minecraft:dark_prismarine
fill 182 120 356 182 123 356 minecraft:blue_terracotta
setblock 182 120 360 minecraft:dark_prismarine
fill 183 120 324 183 131 324 minecraft:black_concrete
setblock 142 121 341 minecraft:purple_concrete
fill 142 121 351 142 121 353 minecraft:blue_terracotta
setblock 142 121 354 minecraft:dark_prismarine
fill 142 121 355 142 124 355 minecraft:blue_terracotta
setblock 142 121 359 minecraft:dark_prismarine
fill 142 121 360 142 123 361 minecraft:blue_terracotta
setblock 143 121 353 minecraft:dark_prismarine
fill 143 121 354 143 124 354 minecraft:blue_terracotta
setblock 143 121 358 minecraft:dark_prismarine
fill 143 121 359 143 124 359 minecraft:blue_terracotta
setblock 148 121 363 minecraft:dark_prismarine
fill 149 121 335 149 132 336 minecraft:magenta_terracotta
fill 149 121 363 149 124 363 minecraft:blue_terracotta
setblock 153 121 363 minecraft:dark_prismarine
fill 154 121 335 156 121 337 minecraft:dark_oak_planks
fill 154 121 347 156 121 349 minecraft:dark_oak_planks
fill 155 121 338 156 121 338 minecraft:dark_oak_planks
fill 155 121 346 156 121 346 minecraft:dark_oak_planks
fill 157 121 336 157 121 337 minecraft:dark_oak_planks
fill 157 121 347 157 121 348 minecraft:dark_oak_planks
fill 158 121 355 158 126 356 minecraft:magenta_terracotta
fill 159 121 356 159 135 356 minecraft:magenta_terracotta
setblock 160 121 323 minecraft:purple_concrete
setblock 164 121 363 minecraft:purple_concrete
fill 165 121 336 168 121 337 minecraft:dark_oak_planks
fill 165 121 347 168 121 348 minecraft:dark_oak_planks
fill 166 121 335 168 121 335 minecraft:dark_oak_planks
fill 166 121 338 167 121 338 minecraft:dark_oak_planks
fill 166 121 346 167 121 346 minecraft:dark_oak_planks
fill 166 121 349 168 121 349 minecraft:dark_oak_planks
fill 166 121 364 166 129 364 minecraft:black_concrete
setblock 168 121 323 minecraft:dark_prismarine
fill 169 121 323 169 124 323 minecraft:blue_terracotta
fill 170 121 363 170 123 363 minecraft:blue_terracotta
setblock 171 121 324 minecraft:blue_terracotta
setblock 172 121 323 minecraft:blue_terracotta
setblock 172 121 324 minecraft:dark_prismarine
fill 172 121 362 172 121 363 minecraft:blue_terracotta
setblock 173 121 323 minecraft:dark_prismarine
fill 173 121 324 173 124 324 minecraft:blue_terracotta
setblock 173 121 362 minecraft:blue_terracotta
setblock 173 121 363 minecraft:dark_prismarine
fill 174 121 323 174 124 323 minecraft:blue_terracotta
setblock 174 121 362 minecraft:dark_prismarine
fill 174 121 363 174 124 363 minecraft:blue_terracotta
fill 175 121 362 176 123 362 minecraft:blue_terracotta
setblock 178 121 323 minecraft:dark_prismarine
setblock 178 121 363 minecraft:dark_prismarine
fill 179 121 363 180 123 363 minecraft:blue_terracotta
setblock 182 121 326 minecraft:purple_concrete
setblock 182 121 345 minecraft:purple_concrete
setblock 182 121 354 minecraft:dark_prismarine
fill 182 121 355 182 124 355 minecraft:blue_terracotta
setblock 182 121 359 minecraft:dark_prismarine
fill 182 121 360 182 122 362 minecraft:blue_terracotta
setblock 142 122 347 minecraft:purple_concrete
fill 142 122 351 142 122 352 minecraft:blue_terracotta
setblock 142 122 353 minecraft:dark_prismarine
fill 142 122 354 142 125 354 minecraft:blue_terracotta
setblock 142 122 358 minecraft:dark_prismarine
fill 142 122 359 142 125 359 minecraft:blue_terracotta
setblock 142 122 362 minecraft:blue_terracotta
fill 143 122 353 143 125 353 minecraft:blue_terracotta
setblock 143 122 357 minecraft:dark_prismarine
fill 143 122 358 143 125 358 minecraft:blue_terracotta
fill 143 122 360 143 123 360 minecraft:blue_terracotta
fill 145 122 363 146 122 363 minecraft:blue_terracotta
setblock 147 122 363 minecraft:dark_prismarine
setblock 148 122 362 minecraft:dark_prismarine
fill 148 122 363 148 125 363 minecraft:blue_terracotta
fill 149 122 362 152 122 362 minecraft:blue_terracotta
fill 150 122 363 151 122 363 minecraft:blue_terracotta
setblock 152 122 363 minecraft:dark_prismarine
fill 153 122 363 154 124 363 minecraft:blue_terracotta
setblock 154 122 323 minecraft:purple_concrete
fill 154 122 336 156 122 337 minecraft:dark_oak_planks
fill 154 122 347 156 122 348 minecraft:dark_oak_planks
fill 155 122 335 156 122 335 minecraft:dark_oak_planks
fill 155 122 349 156 122 349 minecraft:dark_oak_planks
fill 166 122 335 167 122 337 minecraft:dark_oak_planks
fill 166 122 347 167 122 349 minecraft:dark_oak_planks
setblock 167 122 323 minecraft:dark_prismarine
fill 168 122 323 168 125 323 minecraft:blue_terracotta
fill 168 122 336 168 122 337 minecraft:dark_oak_planks
fill 168 122 347 168 122 348 minecraft:dark_oak_planks
fill 168 122 363 169 124 363 minecraft:blue_terracotta
fill 169 122 324 170 122 324 minecraft:blue_terracotta
fill 170 122 362 172 122 362 minecraft:blue_terracotta
setblock 171 122 324 minecraft:dark_prismarine
setblock 172 122 323 minecraft:dark_prismarine
fill 172 122 324 172 125 324 minecraft:blue_terracotta
setblock 172 122 363 minecraft:dark_prismarine
fill 173 122 323 173 125 323 minecraft:blue_terracotta
setblock 173 122 362 minecraft:dark_prismarine
fill 173 122 363 173 125 363 minecraft:blue_terracotta
fill 174 122 362 174 125 362 minecraft:blue_terracotta
setblock 177 122 323 minecraft:dark_prismarine
setblock 177 122 362 minecraft:blue_terracotta
setblock 177 122 363 minecraft:dark_prismarine
fill 178 122 323 178 125 323 minecraft:blue_terracotta
fill 178 122 328 180 140 330 minecraft:dark_prismarine
setblock 178 122 362 minecraft:dark_prismarine
fill 178 122 363 178 125 363 minecraft:blue_terracotta
setblock 179 122 323 minecraft:purple_concrete
fill 181 122 357 181 122 358 minecraft:blue_terracotta
setblock 181 122 359 minecraft:dark_prismarine
fill 181 122 360 181 125 360 minecraft:blue_terracotta
setblock 181 122 363 minecraft:blue_terracotta
setblock 182 122 339 minecraft:purple_concrete
setblock 182 122 353 minecraft:dark_prismarine
fill 182 122 354 182 125 354 minecraft:blue_terracotta
setblock 182 122 358 minecraft:dark_prismarine
fill 182 122 359 182 125 359 minecraft:blue_terracotta
setblock 182 122 363 minecraft:dark_prismarine
setblock 141 123 333 minecraft:cyan_concrete
fill 141 123 334 141 129 337 minecraft:black_concrete
setblock 141 123 358 minecraft:light_blue_wool
setblock 142 123 328 minecraft:purple_concrete
setblock 142 123 337 minecraft:dark_prismarine
fill 142 123 350 142 123 351 minecraft:blue_terracotta
setblock 142 123 352 minecraft:dark_prismarine
fill 142 123 353 142 126 353 minecraft:blue_terracotta
setblock 142 123 357 minecraft:dark_prismarine
fill 142 123 358 142 126 358 minecraft:blue_terracotta
setblock 142 123 362 minecraft:dark_prismarine
fill 142 123 363 145 123 363 minecraft:blue_terracotta
setblock 143 123 356 minecraft:dark_prismarine
fill 143 123 357 144 125 357 minecraft:blue_terracotta
setblock 143 123 361 minecraft:dark_prismarine
setblock 144 123 355 minecraft:dark_prismarine
fill 144 123 356 144 126 356 minecraft:blue_terracotta
fill 144 123 358 144 124 358 minecraft:blue_terracotta
fill 145 123 362 146 123 362 minecraft:blue_terracotta
setblock 146 123 363 minecraft:dark_prismarine
setblock 147 123 362 minecraft:dark_prismarine
fill 147 123 363 147 126 363 minecraft:blue_terracotta
setblock 148 123 323 minecraft:purple_concrete
setblock 148 123 361 minecraft:dark_prismarine
fill 148 123 362 151 123 362 minecraft:blue_terracotta
fill 149 123 361 151 124 361 minecraft:blue_terracotta
setblock 150 123 363 minecraft:blue_terracotta
fill 151 123 334 151 168 334 minecraft:magenta_terracotta
setblock 151 123 363 minecraft:dark_prismarine
setblock 152 123 362 minecraft:dark_prismarine
fill 152 123 363 152 126 363 minecraft:blue_terracotta
fill 153 123 362 153 126 362 minecraft:blue_terracotta
fill 155 123 336 156 123 337 minecraft:dark_oak_planks
fill 155 123 347 156 123 348 minecraft:dark_oak_planks
setblock 155 123 363 minecraft:blue_terracotta
fill 158 123 357 159 135 357 minecraft:magenta_terracotta
setblock 166 123 323 minecraft:dark_prismarine
fill 166 123 336 167 123 337 minecraft:dark_oak_planks
fill 166 123 347 167 123 348 minecraft:dark_oak_planks
setblock 166 123 363 minecraft:dark_prismarine
fill 167 123 323 167 126 323 minecraft:blue_terracotta
fill 167 123 363 167 126 363 minecraft:blue_terracotta
fill 168 123 324 169 123 324 minecraft:blue_terracotta
fill 168 123 362 171 123 362 minecraft:blue_terracotta
setblock 170 123 324 minecraft:dark_prismarine
fill 170 123 361 172 123 361 minecraft:blue_terracotta
schedule function dropper:buildpart/75_7 1t
