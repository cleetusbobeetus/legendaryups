setblock 108 280 614 minecraft:crying_obsidian
fill 108 280 615 112 280 635 minecraft:purple_stained_glass
setblock 109 280 613 minecraft:crying_obsidian
fill 109 280 614 111 280 614 minecraft:obsidian
setblock 109 280 637 minecraft:crying_obsidian
fill 110 280 613 112 280 613 minecraft:obsidian
setblock 110 280 636 minecraft:crying_obsidian
fill 110 280 637 112 280 637 minecraft:obsidian
fill 111 280 636 113 280 636 minecraft:obsidian
setblock 112 280 614 minecraft:crying_obsidian
fill 112 280 646 112 289 646 minecraft:obsidian
setblock 113 280 613 minecraft:crying_obsidian
fill 113 280 614 115 280 614 minecraft:obsidian
fill 113 280 615 114 280 626 minecraft:purple_stained_glass
fill 113 280 627 113 280 631 minecraft:crying_obsidian
fill 113 280 632 128 280 635 minecraft:purple_stained_glass
setblock 113 280 637 minecraft:crying_obsidian
setblock 113 280 646 minecraft:amethyst_block
fill 114 280 613 116 280 613 minecraft:obsidian
fill 114 280 627 120 280 627 minecraft:crying_obsidian
fill 114 280 628 116 280 630 minecraft:netherrack
fill 114 280 631 117 280 631 minecraft:crying_obsidian
setblock 114 280 636 minecraft:crying_obsidian
fill 114 280 637 116 280 637 minecraft:obsidian
fill 115 280 615 128 280 617 minecraft:purple_stained_glass
fill 115 280 618 115 280 622 minecraft:crying_obsidian
fill 115 280 623 115 280 626 minecraft:purple_stained_glass
fill 115 280 636 117 280 636 minecraft:obsidian
setblock 116 280 614 minecraft:crying_obsidian
fill 116 280 618 119 280 618 minecraft:crying_obsidian
fill 116 280 619 118 280 621 minecraft:netherrack
fill 116 280 622 116 280 626 minecraft:crying_obsidian
setblock 117 280 613 minecraft:crying_obsidian
fill 117 280 614 119 280 614 minecraft:obsidian
fill 117 280 622 120 280 623 minecraft:crying_obsidian
fill 117 280 628 117 280 630 minecraft:crying_obsidian
setblock 117 280 637 minecraft:crying_obsidian
fill 118 280 613 120 280 613 minecraft:obsidian
fill 118 280 628 119 280 631 minecraft:purple_stained_glass
setblock 118 280 636 minecraft:crying_obsidian
fill 118 280 637 120 280 637 minecraft:obsidian
fill 119 280 619 119 280 621 minecraft:crying_obsidian
fill 119 280 636 121 280 636 minecraft:obsidian
setblock 120 280 614 minecraft:crying_obsidian
fill 120 280 618 128 280 619 minecraft:purple_stained_glass
fill 120 280 620 120 280 621 minecraft:crying_obsidian
fill 120 280 624 120 280 626 minecraft:crying_obsidian
fill 120 280 628 120 280 630 minecraft:crying_obsidian
fill 120 280 631 128 280 631 minecraft:purple_stained_glass
setblock 121 280 613 minecraft:crying_obsidian
fill 121 280 614 123 280 614 minecraft:obsidian
fill 121 280 620 124 280 620 minecraft:crying_obsidian
fill 121 280 621 123 280 623 minecraft:netherrack
fill 121 280 624 124 280 624 minecraft:crying_obsidian
fill 121 280 625 128 280 625 minecraft:purple_stained_glass
fill 121 280 626 124 280 626 minecraft:crying_obsidian
fill 121 280 627 123 280 629 minecraft:netherrack
fill 121 280 630 124 280 630 minecraft:crying_obsidian
setblock 121 280 637 minecraft:crying_obsidian
fill 122 280 613 124 280 613 minecraft:obsidian
setblock 122 280 636 minecraft:crying_obsidian
fill 122 280 637 124 280 637 minecraft:obsidian
fill 123 280 636 125 280 636 minecraft:obsidian
fill 123 280 646 123 307 646 minecraft:obsidian
setblock 124 280 614 minecraft:crying_obsidian
fill 124 280 621 124 280 623 minecraft:crying_obsidian
fill 124 280 627 124 280 629 minecraft:crying_obsidian
setblock 125 280 613 minecraft:crying_obsidian
fill 125 280 614 127 280 614 minecraft:obsidian
fill 125 280 620 128 280 624 minecraft:purple_stained_glass
fill 125 280 626 128 280 630 minecraft:purple_stained_glass
setblock 125 280 637 minecraft:crying_obsidian
fill 126 280 613 128 280 613 minecraft:obsidian
setblock 126 280 636 minecraft:crying_obsidian
fill 126 280 637 128 280 637 minecraft:obsidian
fill 127 280 636 129 280 636 minecraft:obsidian
setblock 128 280 614 minecraft:crying_obsidian
setblock 129 280 613 minecraft:crying_obsidian
fill 129 280 614 129 280 616 minecraft:obsidian
setblock 129 280 617 minecraft:crying_obsidian
fill 129 280 618 129 280 620 minecraft:obsidian
setblock 129 280 621 minecraft:crying_obsidian
fill 129 280 622 129 280 624 minecraft:obsidian
setblock 129 280 625 minecraft:crying_obsidian
fill 129 280 626 129 280 628 minecraft:obsidian
setblock 129 280 629 minecraft:crying_obsidian
fill 129 280 630 129 280 632 minecraft:obsidian
setblock 129 280 633 minecraft:crying_obsidian
fill 129 280 634 130 280 635 minecraft:obsidian
setblock 129 280 637 minecraft:crying_obsidian
fill 130 280 613 130 280 615 minecraft:obsidian
setblock 130 280 616 minecraft:crying_obsidian
fill 130 280 617 130 280 619 minecraft:obsidian
setblock 130 280 620 minecraft:crying_obsidian
fill 130 280 621 130 280 623 minecraft:obsidian
setblock 130 280 624 minecraft:crying_obsidian
fill 130 280 625 130 280 627 minecraft:obsidian
setblock 130 280 628 minecraft:crying_obsidian
fill 130 280 629 130 280 631 minecraft:obsidian
setblock 130 280 632 minecraft:crying_obsidian
setblock 130 280 633 minecraft:obsidian
setblock 130 280 636 minecraft:crying_obsidian
setblock 130 280 637 minecraft:obsidian
fill 131 280 613 135 280 637 minecraft:netherrack
setblock 136 280 606 minecraft:amethyst_block
setblock 136 280 623 minecraft:amethyst_block
setblock 136 280 628 minecraft:amethyst_block
setblock 94 281 609 minecraft:amethyst_block
fill 106 281 614 106 284 614 minecraft:obsidian
fill 106 281 636 108 284 636 minecraft:obsidian
fill 107 281 615 107 284 615 minecraft:obsidian
fill 107 281 635 107 284 635 minecraft:obsidian
fill 107 281 637 107 284 637 minecraft:obsidian
fill 108 281 614 108 284 614 minecraft:obsidian
setblock 113 281 604 minecraft:amethyst_block
fill 113 281 646 113 307 646 minecraft:obsidian
fill 128 281 614 130 284 614 minecraft:obsidian
fill 128 281 636 130 284 636 minecraft:obsidian
fill 129 281 604 129 307 604 minecraft:obsidian
fill 129 281 613 129 284 613 minecraft:obsidian
fill 129 281 615 129 284 615 minecraft:obsidian
fill 129 281 635 129 284 635 minecraft:obsidian
fill 129 281 637 129 284 637 minecraft:obsidian
setblock 130 281 604 minecraft:white_concrete
setblock 135 281 646 minecraft:amethyst_block
fill 136 281 606 136 291 606 minecraft:obsidian
fill 136 281 623 136 293 623 minecraft:obsidian
fill 136 281 628 136 307 628 minecraft:obsidian
fill 94 282 604 94 307 604 minecraft:obsidian
setblock 94 282 605 minecraft:white_concrete
fill 94 282 606 94 297 606 minecraft:obsidian
fill 94 282 609 94 307 609 minecraft:obsidian
setblock 97 282 607 minecraft:light[level=14]
setblock 97 282 615 minecraft:light[level=14]
setblock 97 282 623 minecraft:light[level=14]
setblock 97 282 631 minecraft:light[level=14]
setblock 97 282 639 minecraft:light[level=14]
setblock 105 282 607 minecraft:light[level=14]
setblock 105 282 615 minecraft:light[level=14]
setblock 105 282 623 minecraft:light[level=14]
setblock 105 282 631 minecraft:light[level=14]
setblock 105 282 639 minecraft:light[level=14]
fill 113 282 604 113 307 604 minecraft:obsidian
setblock 113 282 607 minecraft:light[level=14]
setblock 113 282 615 minecraft:light[level=14]
setblock 113 282 623 minecraft:light[level=14]
setblock 113 282 631 minecraft:light[level=14]
setblock 113 282 639 minecraft:light[level=14]
setblock 121 282 607 minecraft:light[level=14]
setblock 121 282 615 minecraft:light[level=14]
setblock 121 282 623 minecraft:light[level=14]
setblock 121 282 631 minecraft:light[level=14]
setblock 121 282 639 minecraft:light[level=14]
setblock 129 282 607 minecraft:light[level=14]
setblock 129 282 623 minecraft:light[level=14]
setblock 129 282 631 minecraft:light[level=14]
setblock 129 282 639 minecraft:light[level=14]
setblock 130 282 604 minecraft:amethyst_block
fill 135 282 646 135 307 646 minecraft:obsidian
fill 94 283 605 94 307 605 minecraft:obsidian
setblock 94 283 618 minecraft:white_concrete
setblock 94 283 621 minecraft:white_concrete
setblock 94 283 623 minecraft:crying_obsidian
setblock 94 283 643 minecraft:amethyst_block
fill 101 283 604 101 296 604 minecraft:obsidian
setblock 102 283 604 minecraft:crying_obsidian
fill 130 283 604 130 287 604 minecraft:obsidian
setblock 136 283 640 minecraft:white_concrete
setblock 94 284 610 minecraft:crying_obsidian
setblock 94 284 618 minecraft:obsidian
fill 94 284 621 94 307 621 minecraft:obsidian
fill 94 284 623 94 287 623 minecraft:obsidian
setblock 94 284 625 minecraft:amethyst_block
fill 94 284 643 94 307 643 minecraft:obsidian
fill 98 284 622 98 293 623 minecraft:obsidian
fill 99 284 622 99 293 622 minecraft:obsidian
fill 102 284 604 102 291 604 minecraft:obsidian
setblock 118 284 604 minecraft:white_concrete
setblock 125 284 646 minecraft:crying_obsidian
setblock 127 284 604 minecraft:amethyst_block
fill 136 284 640 136 307 640 minecraft:obsidian
fill 94 285 610 94 307 610 minecraft:obsidian
setblock 94 285 618 minecraft:crying_obsidian
fill 94 285 625 94 307 625 minecraft:obsidian
setblock 94 285 628 minecraft:amethyst_block
fill 97 285 622 97 293 622 minecraft:obsidian
fill 98 285 621 99 293 621 minecraft:obsidian
fill 99 285 623 99 293 623 minecraft:obsidian
fill 118 285 604 118 307 604 minecraft:obsidian
setblock 125 285 604 minecraft:crying_obsidian
fill 125 285 646 125 307 646 minecraft:obsidian
fill 127 285 604 127 307 604 minecraft:obsidian
setblock 133 285 604 minecraft:white_concrete
fill 136 285 611 136 285 612 minecraft:white_concrete
setblock 136 285 638 minecraft:crying_obsidian
fill 94 286 618 94 307 618 minecraft:obsidian
setblock 94 286 627 minecraft:amethyst_block
fill 94 286 628 94 287 628 minecraft:obsidian
fill 97 286 621 97 293 621 minecraft:obsidian
fill 97 286 623 97 293 623 minecraft:obsidian
fill 98 286 624 98 293 624 minecraft:obsidian
fill 100 286 622 100 293 622 minecraft:obsidian
setblock 101 286 646 minecraft:white_concrete
setblock 109 286 646 minecraft:white_concrete
fill 125 286 604 125 307 604 minecraft:obsidian
fill 133 286 604 133 307 604 minecraft:obsidian
fill 136 286 611 136 302 612 minecraft:obsidian
setblock 136 286 637 minecraft:white_concrete
fill 136 286 638 136 307 638 minecraft:obsidian
setblock 136 286 645 minecraft:amethyst_block
fill 94 287 627 94 288 627 minecraft:obsidian
setblock 94 287 631 minecraft:white_concrete
fill 96 287 622 96 293 622 minecraft:obsidian
fill 97 287 624 97 293 624 minecraft:obsidian
fill 98 287 620 99 293 620 minecraft:obsidian
fill 99 287 624 99 293 624 minecraft:obsidian
fill 100 287 621 100 293 621 minecraft:obsidian
fill 100 287 623 100 293 623 minecraft:obsidian
fill 101 287 646 101 307 646 minecraft:obsidian
fill 109 287 646 109 304 646 minecraft:obsidian
setblock 126 287 646 minecraft:amethyst_block
fill 136 287 637 136 306 637 minecraft:obsidian
fill 136 287 645 136 307 645 minecraft:obsidian
fill 94 288 612 94 290 612 minecraft:purple_stained_glass
setblock 94 288 623 minecraft:amethyst_block
fill 94 288 628 94 290 628 minecraft:purple_stained_glass
fill 94 288 631 94 307 631 minecraft:obsidian
fill 94 288 644 94 290 644 minecraft:purple_stained_glass
fill 96 288 621 96 293 621 minecraft:obsidian
fill 96 288 623 96 293 623 minecraft:obsidian
fill 97 288 620 97 293 620 minecraft:obsidian
fill 98 288 604 98 290 604 minecraft:purple_stained_glass
fill 98 288 625 98 293 625 minecraft:obsidian
fill 100 288 620 100 293 620 minecraft:obsidian
fill 100 288 624 100 293 624 minecraft:obsidian
fill 101 288 622 101 293 623 minecraft:obsidian
setblock 107 288 604 minecraft:white_concrete
fill 108 288 646 108 290 646 minecraft:purple_stained_glass
fill 114 288 604 114 290 604 minecraft:purple_stained_glass
fill 124 288 646 124 290 646 minecraft:purple_stained_glass
fill 126 288 646 126 307 646 minecraft:obsidian
fill 130 288 604 130 290 604 minecraft:purple_stained_glass
fill 136 288 614 136 290 614 minecraft:purple_stained_glass
fill 136 288 630 136 290 630 minecraft:purple_stained_glass
setblock 94 289 611 minecraft:amethyst_block
fill 94 289 623 95 293 623 minecraft:obsidian
setblock 94 289 627 minecraft:amethyst_block
fill 95 289 622 95 293 622 minecraft:obsidian
fill 96 289 620 96 293 620 minecraft:obsidian
fill 96 289 624 96 293 624 minecraft:obsidian
fill 97 289 625 97 293 625 minecraft:obsidian
fill 98 289 619 99 293 619 minecraft:obsidian
fill 99 289 625 100 293 625 minecraft:obsidian
fill 101 289 621 101 293 621 minecraft:obsidian
fill 101 289 624 101 293 624 minecraft:obsidian
fill 107 289 604 107 307 604 minecraft:obsidian
fill 94 290 611 94 297 611 minecraft:obsidian
fill 94 290 627 94 300 627 minecraft:obsidian
setblock 94 290 637 minecraft:crying_obsidian
fill 95 290 621 95 293 621 minecraft:obsidian
fill 95 290 624 95 293 624 minecraft:obsidian
fill 96 290 625 96 293 625 minecraft:obsidian
setblock 97 290 607 minecraft:light[level=14]
setblock 97 290 615 minecraft:light[level=14]
fill 97 290 619 97 293 619 minecraft:obsidian
setblock 97 290 631 minecraft:light[level=14]
setblock 97 290 639 minecraft:light[level=14]
fill 98 290 626 98 293 626 minecraft:obsidian
fill 100 290 619 100 293 619 minecraft:obsidian
fill 101 290 620 101 293 620 minecraft:obsidian
fill 102 290 622 102 293 623 minecraft:obsidian
setblock 105 290 607 minecraft:light[level=14]
setblock 105 290 615 minecraft:light[level=14]
setblock 105 290 623 minecraft:light[level=14]
setblock 105 290 631 minecraft:light[level=14]
setblock 105 290 639 minecraft:light[level=14]
setblock 112 290 646 minecraft:white_concrete
setblock 113 290 607 minecraft:light[level=14]
setblock 113 290 615 minecraft:light[level=14]
setblock 113 290 623 minecraft:light[level=14]
setblock 113 290 631 minecraft:light[level=14]
setblock 113 290 639 minecraft:light[level=14]
setblock 121 290 607 minecraft:light[level=14]
setblock 121 290 615 minecraft:light[level=14]
setblock 121 290 623 minecraft:light[level=14]
setblock 121 290 631 minecraft:light[level=14]
setblock 121 290 639 minecraft:light[level=14]
setblock 129 290 607 minecraft:light[level=14]
setblock 129 290 615 minecraft:light[level=14]
setblock 129 290 623 minecraft:light[level=14]
setblock 129 290 631 minecraft:light[level=14]
setblock 129 290 639 minecraft:light[level=14]
setblock 136 290 641 minecraft:crying_obsidian
fill 94 291 612 94 296 612 minecraft:obsidian
setblock 94 291 622 minecraft:white_concrete
fill 94 291 628 94 296 628 minecraft:obsidian
fill 94 291 637 94 307 637 minecraft:obsidian
fill 94 291 644 94 296 644 minecraft:obsidian
fill 95 291 620 95 293 620 minecraft:obsidian
fill 95 291 625 95 293 625 minecraft:obsidian
fill 96 291 619 96 293 619 minecraft:obsidian
fill 97 291 618 99 293 618 minecraft:obsidian
fill 97 291 626 97 293 626 minecraft:obsidian
fill 98 291 604 98 296 604 minecraft:obsidian
fill 99 291 626 100 293 626 minecraft:obsidian
fill 101 291 619 101 293 619 minecraft:obsidian
fill 101 291 625 101 293 625 minecraft:obsidian
fill 102 291 620 102 293 621 minecraft:obsidian
fill 102 291 624 102 293 624 minecraft:obsidian
setblock 108 291 604 minecraft:white_concrete
fill 108 291 646 108 296 646 minecraft:obsidian
fill 112 291 646 112 307 646 minecraft:obsidian
fill 114 291 604 114 296 604 minecraft:obsidian
fill 124 291 646 124 296 646 minecraft:obsidian
fill 130 291 604 130 296 604 minecraft:obsidian
setblock 130 291 646 minecraft:white_concrete
fill 136 291 614 136 296 614 minecraft:obsidian
fill 136 291 630 136 296 630 minecraft:obsidian
fill 136 291 641 136 307 641 minecraft:obsidian
fill 94 292 622 94 307 622 minecraft:obsidian
fill 95 292 619 95 293 619 minecraft:obsidian
fill 96 292 618 96 293 618 minecraft:obsidian
fill 96 292 626 96 293 626 minecraft:obsidian
fill 98 292 627 98 293 627 minecraft:obsidian
fill 100 292 618 100 293 618 minecraft:obsidian
fill 101 292 626 101 293 626 minecraft:obsidian
setblock 102 292 604 minecraft:white_concrete
fill 102 292 625 102 293 625 minecraft:obsidian
fill 103 292 622 103 293 623 minecraft:obsidian
fill 108 292 604 108 307 604 minecraft:obsidian
fill 127 292 605 129 295 605 minecraft:amethyst_block
fill 128 292 606 128 296 606 minecraft:amethyst_block
fill 130 292 646 130 295 646 minecraft:obsidian
setblock 136 292 606 minecraft:white_concrete
setblock 136 292 620 minecraft:white_concrete
setblock 95 293 618 minecraft:obsidian
setblock 95 293 626 minecraft:obsidian
fill 96 293 627 97 293 627 minecraft:obsidian
fill 97 293 617 99 293 617 minecraft:obsidian
fill 99 293 627 100 293 627 minecraft:obsidian
setblock 101 293 618 minecraft:obsidian
fill 102 293 604 102 300 604 minecraft:obsidian
setblock 102 293 619 minecraft:obsidian
fill 103 293 620 103 293 621 minecraft:obsidian
setblock 103 293 624 minecraft:obsidian
setblock 124 293 604 minecraft:amethyst_block
fill 127 293 606 127 295 606 minecraft:amethyst_block
fill 128 293 607 128 296 607 minecraft:amethyst_block
fill 129 293 606 129 295 606 minecraft:amethyst_block
fill 136 293 606 136 307 606 minecraft:obsidian
setblock 136 293 617 minecraft:amethyst_block
fill 136 293 620 136 307 620 minecraft:obsidian
fill 94 294 623 94 307 623 minecraft:obsidian
fill 97 294 622 99 294 622 minecraft:amethyst_block
setblock 98 294 621 minecraft:amethyst_block
fill 98 294 623 99 294 623 minecraft:amethyst_block
setblock 104 294 646 minecraft:crying_obsidian
setblock 111 294 646 minecraft:crying_obsidian
setblock 117 294 646 minecraft:amethyst_block
fill 124 294 604 124 307 604 minecraft:obsidian
fill 127 294 607 127 296 607 minecraft:amethyst_block
fill 129 294 607 129 296 607 minecraft:amethyst_block
fill 129 294 632 130 295 632 minecraft:end_stone
fill 136 294 617 136 307 617 minecraft:obsidian
fill 136 294 618 136 295 618 minecraft:white_concrete
setblock 136 294 623 minecraft:amethyst_block
fill 98 295 622 98 295 623 minecraft:amethyst_block
fill 99 295 622 99 296 622 minecraft:amethyst_block
fill 104 295 646 104 307 646 minecraft:obsidian
fill 111 295 646 111 307 646 minecraft:obsidian
fill 117 295 646 117 297 646 minecraft:obsidian
setblock 119 295 604 minecraft:amethyst_block
fill 128 295 608 128 297 608 minecraft:amethyst_block
fill 136 295 623 136 307 623 minecraft:obsidian
setblock 136 295 634 minecraft:amethyst_block
setblock 136 295 635 minecraft:crying_obsidian
setblock 95 296 604 minecraft:white_concrete
fill 98 296 622 98 297 622 minecraft:amethyst_block
setblock 103 296 646 minecraft:white_concrete
fill 119 296 604 119 307 604 minecraft:obsidian
fill 126 296 624 127 297 624 minecraft:end_stone
setblock 130 296 646 minecraft:white_concrete
fill 136 296 618 136 307 618 minecraft:obsidian
fill 136 296 634 136 307 635 minecraft:obsidian
fill 94 297 612 94 299 612 minecraft:purple_stained_glass
fill 94 297 628 94 299 628 minecraft:purple_stained_glass
fill 94 297 644 94 299 644 minecraft:purple_stained_glass
fill 95 297 604 95 307 604 minecraft:obsidian
fill 98 297 604 98 299 604 minecraft:purple_stained_glass
setblock 101 297 604 minecraft:amethyst_block
fill 103 297 646 103 307 646 minecraft:obsidian
fill 108 297 646 108 299 646 minecraft:purple_stained_glass
fill 114 297 604 114 299 604 minecraft:purple_stained_glass
fill 124 297 646 124 299 646 minecraft:purple_stained_glass
setblock 128 297 609 minecraft:amethyst_block
fill 130 297 604 130 299 604 minecraft:purple_stained_glass
fill 130 297 646 130 307 646 minecraft:obsidian
fill 136 297 614 136 299 614 minecraft:purple_stained_glass
fill 136 297 630 136 299 630 minecraft:purple_stained_glass
setblock 94 298 606 minecraft:crying_obsidian
setblock 94 298 611 minecraft:white_concrete
setblock 94 298 619 minecraft:amethyst_block
setblock 94 298 635 minecraft:amethyst_block
setblock 97 298 607 minecraft:light[level=14]
setblock 97 298 615 minecraft:light[level=14]
setblock 97 298 623 minecraft:light[level=14]
setblock 97 298 631 minecraft:light[level=14]
setblock 97 298 639 minecraft:light[level=14]
fill 101 298 604 101 307 604 minecraft:obsidian
setblock 105 298 607 minecraft:light[level=14]
setblock 105 298 615 minecraft:light[level=14]
setblock 105 298 623 minecraft:light[level=14]
setblock 105 298 631 minecraft:light[level=14]
setblock 105 298 639 minecraft:light[level=14]
setblock 113 298 607 minecraft:light[level=14]
setblock 113 298 615 minecraft:light[level=14]
setblock 113 298 623 minecraft:light[level=14]
setblock 113 298 631 minecraft:light[level=14]
setblock 113 298 639 minecraft:light[level=14]
setblock 117 298 646 minecraft:crying_obsidian
setblock 121 298 607 minecraft:light[level=14]
setblock 121 298 615 minecraft:light[level=14]
setblock 121 298 623 minecraft:light[level=14]
setblock 121 298 631 minecraft:light[level=14]
setblock 121 298 639 minecraft:light[level=14]
setblock 129 298 607 minecraft:light[level=14]
setblock 129 298 615 minecraft:light[level=14]
setblock 129 298 623 minecraft:light[level=14]
setblock 129 298 631 minecraft:light[level=14]
setblock 129 298 639 minecraft:light[level=14]
setblock 136 298 624 minecraft:crying_obsidian
fill 94 299 606 94 307 606 minecraft:obsidian
setblock 94 299 611 minecraft:crying_obsidian
fill 94 299 619 94 303 619 minecraft:obsidian
fill 94 299 635 94 307 635 minecraft:obsidian
fill 117 299 646 117 307 646 minecraft:obsidian
setblock 119 299 646 minecraft:amethyst_block
fill 136 299 624 136 306 624 minecraft:obsidian
fill 94 300 611 94 307 612 minecraft:obsidian
fill 94 300 628 94 306 628 minecraft:obsidian
setblock 94 300 630 minecraft:amethyst_block
setblock 94 300 644 minecraft:amethyst_block
fill 98 300 604 98 305 604 minecraft:obsidian
fill 108 300 646 108 307 646 minecraft:obsidian
setblock 111 300 604 minecraft:crying_obsidian
fill 114 300 604 114 307 604 minecraft:obsidian
fill 119 300 646 119 307 646 minecraft:obsidian
fill 124 300 646 124 302 646 minecraft:obsidian
fill 130 300 604 130 307 604 minecraft:obsidian
fill 136 300 614 136 307 614 minecraft:obsidian
setblock 136 300 616 minecraft:crying_obsidian
fill 136 300 630 136 307 630 minecraft:obsidian
setblock 94 301 627 minecraft:amethyst_block
fill 94 301 630 94 307 630 minecraft:obsidian
fill 94 301 644 94 307 644 minecraft:obsidian
setblock 100 301 604 minecraft:white_concrete
setblock 102 301 604 minecraft:crying_obsidian
fill 111 301 604 111 307 604 minecraft:obsidian
setblock 132 301 646 minecraft:amethyst_block
fill 136 301 616 136 307 616 minecraft:obsidian
setblock 94 302 627 minecraft:obsidian
fill 100 302 604 100 307 604 minecraft:obsidian
fill 102 302 604 102 307 604 minecraft:obsidian
setblock 117 302 604 minecraft:white_concrete
setblock 132 302 604 minecraft:crying_obsidian
fill 132 302 646 132 307 646 minecraft:obsidian
setblock 94 303 627 minecraft:crying_obsidian
setblock 94 303 642 minecraft:crying_obsidian
fill 117 303 604 117 307 604 minecraft:obsidian
setblock 124 303 646 minecraft:white_concrete
fill 132 303 604 132 307 604 minecraft:obsidian
setblock 136 303 611 minecraft:amethyst_block
fill 136 303 612 136 307 612 minecraft:obsidian
setblock 94 304 613 minecraft:white_concrete
setblock 94 304 619 minecraft:amethyst_block
fill 94 304 627 94 307 627 minecraft:obsidian
setblock 94 304 642 minecraft:amethyst_block
fill 124 304 646 124 307 646 minecraft:obsidian
fill 136 304 611 136 307 611 minecraft:obsidian
setblock 136 304 644 minecraft:crying_obsidian
fill 94 305 613 94 307 613 minecraft:obsidian
fill 94 305 619 94 307 619 minecraft:obsidian
fill 94 305 642 94 307 642 minecraft:obsidian
setblock 104 305 604 minecraft:amethyst_block
fill 105 305 604 105 307 604 minecraft:obsidian
setblock 109 305 646 minecraft:white_concrete
setblock 115 305 604 minecraft:amethyst_block
setblock 127 305 646 minecraft:crying_obsidian
fill 136 305 644 136 307 644 minecraft:obsidian
setblock 94 306 633 minecraft:white_concrete
setblock 98 306 604 minecraft:amethyst_block
fill 104 306 604 104 307 604 minecraft:obsidian
fill 109 306 646 109 307 646 minecraft:obsidian
fill 115 306 604 115 307 604 minecraft:obsidian
fill 127 306 646 127 307 646 minecraft:obsidian
setblock 94 307 615 minecraft:white_concrete
setblock 94 307 628 minecraft:white_concrete
setblock 94 307 633 minecraft:obsidian
setblock 98 307 604 minecraft:obsidian
setblock 103 307 604 minecraft:amethyst_block
setblock 106 307 604 minecraft:crying_obsidian
setblock 126 307 604 minecraft:white_concrete
setblock 136 307 624 minecraft:amethyst_block
setblock 136 307 637 minecraft:white_concrete
