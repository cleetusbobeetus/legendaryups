fill 86 167 310 86 168 310 minecraft:spruce_planks
fill 86 167 314 86 168 314 minecraft:spruce_planks
fill 86 167 316 86 168 316 minecraft:spruce_planks
fill 87 167 309 87 168 309 minecraft:spruce_planks
fill 87 167 311 87 168 311 minecraft:spruce_planks
fill 87 167 313 87 168 313 minecraft:spruce_planks
fill 87 167 315 87 168 315 minecraft:spruce_planks
setblock 88 167 281 minecraft:spruce_planks
setblock 88 167 288 minecraft:spruce_planks
setblock 88 167 295 minecraft:spruce_planks
setblock 88 167 302 minecraft:spruce_planks
fill 88 167 308 88 168 308 minecraft:spruce_planks
fill 88 167 310 88 168 310 minecraft:spruce_planks
fill 88 167 314 88 168 314 minecraft:spruce_planks
fill 88 167 316 88 168 316 minecraft:spruce_planks
fill 89 167 290 89 186 290 minecraft:blue_concrete
setblock 89 167 291 minecraft:light_blue_wool
fill 89 167 292 89 188 294 minecraft:blue_concrete
fill 89 167 313 89 181 313 minecraft:blue_concrete
setblock 47 168 282 minecraft:light_blue_wool
setblock 47 168 307 minecraft:white_wool
fill 47 168 310 47 190 310 minecraft:blue_concrete
setblock 50 168 317 minecraft:light_blue_wool
fill 51 168 280 53 183 280 minecraft:spruce_log
fill 55 168 276 56 168 279 minecraft:dark_oak_planks
fill 57 168 277 63 168 279 minecraft:dark_oak_planks
fill 57 168 285 57 168 288 minecraft:spruce_planks
fill 57 168 303 57 168 306 minecraft:spruce_planks
fill 58 168 276 63 168 276 minecraft:dark_oak_planks
fill 58 168 283 58 168 284 minecraft:dark_oak_planks
fill 58 168 285 59 168 285 minecraft:spruce_planks
fill 58 168 288 58 169 289 minecraft:spruce_planks
fill 58 168 302 58 170 303 minecraft:spruce_planks
setblock 58 168 308 minecraft:dark_oak_planks
fill 59 168 286 59 168 288 minecraft:spruce_planks
fill 59 168 303 59 168 306 minecraft:spruce_planks
fill 62 168 280 63 177 281 minecraft:dark_oak_planks
fill 66 168 317 66 190 317 minecraft:blue_concrete
fill 82 168 295 82 176 295 minecraft:iron_bars
fill 83 168 312 85 168 312 minecraft:spruce_log
fill 86 168 312 88 168 312 minecraft:spruce_planks
setblock 89 168 288 minecraft:light_blue_wool
fill 89 168 291 89 192 291 minecraft:blue_concrete
fill 47 169 282 47 187 282 minecraft:blue_concrete
fill 47 169 307 47 188 307 minecraft:blue_concrete
fill 48 169 282 48 170 282 minecraft:spruce_planks
fill 48 169 289 48 170 289 minecraft:spruce_planks
fill 48 169 296 48 170 296 minecraft:spruce_planks
fill 48 169 303 48 170 303 minecraft:spruce_planks
fill 48 169 310 48 170 310 minecraft:spruce_planks
fill 49 169 276 49 170 276 minecraft:spruce_planks
fill 49 169 316 49 170 316 minecraft:spruce_planks
fill 50 169 317 50 190 317 minecraft:blue_concrete
fill 55 169 276 56 169 279 minecraft:spruce_planks
fill 56 169 316 56 170 316 minecraft:spruce_planks
fill 57 169 277 63 169 279 minecraft:spruce_planks
fill 57 169 287 57 169 290 minecraft:spruce_planks
fill 57 169 301 57 169 304 minecraft:spruce_planks
fill 58 169 276 63 170 276 minecraft:spruce_planks
setblock 58 169 285 minecraft:dark_oak_planks
fill 58 169 290 58 170 293 minecraft:spruce_planks
fill 58 169 298 58 170 301 minecraft:spruce_planks
setblock 58 169 306 minecraft:dark_oak_planks
fill 59 169 287 59 169 290 minecraft:spruce_planks
fill 59 169 301 59 169 304 minecraft:spruce_planks
fill 60 169 275 62 169 275 minecraft:blue_concrete
fill 63 169 316 63 170 316 minecraft:spruce_planks
fill 70 169 276 70 170 276 minecraft:spruce_planks
fill 70 169 316 70 170 316 minecraft:spruce_planks
fill 77 169 276 77 170 276 minecraft:spruce_planks
fill 77 169 316 77 170 316 minecraft:spruce_planks
setblock 78 169 275 minecraft:white_wool
fill 81 169 279 81 169 280 minecraft:dark_oak_planks
setblock 82 169 278 minecraft:dark_oak_planks
setblock 82 169 281 minecraft:dark_oak_planks
fill 83 169 277 84 169 277 minecraft:dark_oak_planks
fill 83 169 312 83 183 312 minecraft:spruce_log
fill 84 169 276 84 170 276 minecraft:spruce_planks
fill 84 169 281 85 169 281 minecraft:dark_oak_planks
setblock 84 169 308 minecraft:shroomlight
setblock 84 169 310 minecraft:shroomlight
setblock 84 169 312 minecraft:shroomlight
setblock 84 169 314 minecraft:shroomlight
setblock 84 169 316 minecraft:shroomlight
setblock 85 169 278 minecraft:dark_oak_planks
setblock 85 169 280 minecraft:dark_oak_planks
setblock 85 169 309 minecraft:shroomlight
setblock 85 169 311 minecraft:shroomlight
fill 85 169 312 85 183 312 minecraft:spruce_log
setblock 85 169 313 minecraft:shroomlight
setblock 85 169 315 minecraft:shroomlight
setblock 86 169 308 minecraft:shroomlight
setblock 86 169 310 minecraft:shroomlight
setblock 86 169 312 minecraft:shroomlight
setblock 86 169 314 minecraft:shroomlight
setblock 86 169 316 minecraft:shroomlight
setblock 87 169 309 minecraft:shroomlight
setblock 87 169 311 minecraft:shroomlight
fill 87 169 312 87 183 312 minecraft:spruce_planks
setblock 87 169 313 minecraft:shroomlight
setblock 87 169 315 minecraft:shroomlight
fill 88 169 279 88 170 279 minecraft:spruce_planks
fill 88 169 286 88 170 286 minecraft:spruce_planks
fill 88 169 293 88 170 293 minecraft:spruce_planks
fill 88 169 300 88 170 300 minecraft:spruce_planks
fill 88 169 307 88 170 307 minecraft:spruce_planks
setblock 88 169 308 minecraft:shroomlight
setblock 88 169 310 minecraft:shroomlight
setblock 88 169 312 minecraft:shroomlight
setblock 88 169 314 minecraft:shroomlight
setblock 88 169 316 minecraft:shroomlight
fill 89 169 288 89 190 288 minecraft:blue_concrete
setblock 89 169 306 minecraft:white_wool
fill 48 170 276 48 170 280 minecraft:spruce_planks
fill 48 170 283 48 170 287 minecraft:spruce_planks
fill 48 170 290 48 170 294 minecraft:spruce_planks
fill 48 170 297 48 170 301 minecraft:spruce_planks
fill 48 170 304 48 170 308 minecraft:spruce_planks
fill 48 170 311 48 170 315 minecraft:spruce_planks
setblock 50 170 278 minecraft:light[level=15]
setblock 50 170 285 minecraft:light[level=12]
setblock 50 170 286 minecraft:light[level=15]
setblock 50 170 292 minecraft:light[level=12]
setblock 50 170 294 minecraft:light[level=15]
setblock 50 170 299 minecraft:light[level=12]
setblock 50 170 302 minecraft:light[level=15]
setblock 50 170 306 minecraft:light[level=12]
setblock 50 170 310 minecraft:light[level=15]
setblock 50 170 313 minecraft:light[level=12]
fill 50 170 316 54 170 316 minecraft:spruce_planks
fill 51 170 276 56 170 276 minecraft:spruce_planks
fill 52 170 313 53 171 315 minecraft:spruce_planks
fill 53 170 303 53 171 312 minecraft:spruce_planks
fill 54 170 296 54 171 306 minecraft:spruce_planks
fill 55 170 279 63 170 279 minecraft:dark_oak_planks
setblock 57 170 278 minecraft:light[level=12]
setblock 57 170 285 minecraft:light[level=12]
fill 57 170 290 57 170 301 minecraft:spruce_planks
setblock 57 170 306 minecraft:light[level=12]
setblock 57 170 313 minecraft:light[level=12]
fill 57 170 316 61 170 316 minecraft:spruce_planks
fill 58 170 275 60 173 275 minecraft:shroomlight
setblock 58 170 278 minecraft:light[level=15]
fill 58 170 286 58 170 288 minecraft:dark_oak_planks
setblock 58 170 289 minecraft:spruce_planks
fill 58 170 294 59 171 297 minecraft:spruce_planks
fill 58 170 304 58 170 305 minecraft:dark_oak_planks
setblock 58 170 310 minecraft:light[level=15]
fill 59 170 290 59 170 293 minecraft:spruce_planks
fill 59 170 298 59 170 301 minecraft:spruce_planks
fill 61 170 275 62 190 275 minecraft:blue_concrete
fill 61 170 280 61 177 281 minecraft:dark_oak_planks
fill 62 170 282 63 177 282 minecraft:dark_oak_planks
setblock 64 170 278 minecraft:light[level=12]
fill 64 170 280 64 177 281 minecraft:dark_oak_planks
setblock 64 170 285 minecraft:light[level=12]
setblock 64 170 292 minecraft:light[level=12]
setblock 64 170 299 minecraft:light[level=12]
setblock 64 170 306 minecraft:light[level=12]
setblock 64 170 313 minecraft:light[level=12]
fill 64 170 316 68 170 316 minecraft:spruce_planks
fill 65 170 276 69 170 276 minecraft:spruce_planks
setblock 66 170 278 minecraft:light[level=15]
setblock 66 170 286 minecraft:light[level=15]
setblock 66 170 294 minecraft:light[level=15]
setblock 66 170 302 minecraft:light[level=15]
setblock 66 170 310 minecraft:light[level=15]
setblock 71 170 275 minecraft:light_blue_wool
setblock 71 170 278 minecraft:light[level=12]
setblock 71 170 285 minecraft:light[level=12]
setblock 71 170 292 minecraft:light[level=12]
setblock 71 170 299 minecraft:light[level=12]
setblock 71 170 306 minecraft:light[level=12]
setblock 71 170 313 minecraft:light[level=12]
fill 71 170 316 75 170 316 minecraft:spruce_planks
fill 72 170 276 76 170 276 minecraft:spruce_planks
setblock 74 170 278 minecraft:light[level=15]
setblock 74 170 286 minecraft:light[level=15]
setblock 74 170 294 minecraft:light[level=15]
setblock 74 170 302 minecraft:light[level=15]
setblock 74 170 310 minecraft:light[level=15]
fill 78 170 275 78 190 275 minecraft:blue_concrete
setblock 78 170 278 minecraft:light[level=12]
setblock 78 170 285 minecraft:light[level=12]
setblock 78 170 292 minecraft:light[level=12]
setblock 78 170 299 minecraft:light[level=12]
setblock 78 170 306 minecraft:light[level=12]
setblock 78 170 313 minecraft:light[level=12]
fill 78 170 316 82 170 316 minecraft:spruce_planks
fill 79 170 276 83 170 276 minecraft:spruce_planks
setblock 82 170 278 minecraft:light[level=15]
setblock 82 170 286 minecraft:light[level=15]
setblock 82 170 294 minecraft:light[level=15]
setblock 82 170 302 minecraft:light[level=15]
setblock 82 170 310 minecraft:light[level=15]
fill 84 170 308 84 171 308 minecraft:spruce_planks
fill 84 170 310 84 171 310 minecraft:spruce_planks
fill 84 170 312 84 171 312 minecraft:spruce_log
fill 84 170 314 84 171 314 minecraft:spruce_planks
fill 84 170 316 84 171 316 minecraft:spruce_planks
setblock 85 170 278 minecraft:light[level=12]
setblock 85 170 285 minecraft:light[level=12]
setblock 85 170 292 minecraft:light[level=12]
setblock 85 170 299 minecraft:light[level=12]
setblock 85 170 306 minecraft:light[level=12]
fill 85 170 309 85 171 309 minecraft:spruce_planks
fill 85 170 311 85 171 311 minecraft:spruce_planks
fill 85 170 313 85 171 313 minecraft:spruce_planks
fill 85 170 315 85 171 315 minecraft:spruce_planks
fill 86 170 276 88 170 276 minecraft:spruce_planks
fill 86 170 308 86 171 308 minecraft:spruce_planks
fill 86 170 310 86 171 310 minecraft:spruce_planks
fill 86 170 312 86 171 312 minecraft:spruce_planks
fill 86 170 314 86 171 314 minecraft:spruce_planks
fill 86 170 316 86 171 316 minecraft:spruce_planks
fill 87 170 309 87 171 309 minecraft:spruce_planks
fill 87 170 311 87 171 311 minecraft:spruce_planks
fill 87 170 313 87 171 313 minecraft:spruce_planks
fill 87 170 315 87 171 315 minecraft:spruce_planks
fill 88 170 277 88 170 278 minecraft:spruce_planks
fill 88 170 281 88 170 285 minecraft:spruce_planks
fill 88 170 288 88 170 292 minecraft:spruce_planks
fill 88 170 295 88 170 299 minecraft:spruce_planks
fill 88 170 302 88 170 306 minecraft:spruce_planks
fill 88 170 308 88 171 308 minecraft:spruce_planks
fill 88 170 310 88 171 310 minecraft:spruce_planks
fill 88 170 312 88 171 312 minecraft:spruce_planks
fill 88 170 314 88 171 314 minecraft:spruce_planks
fill 88 170 316 88 171 316 minecraft:spruce_planks
fill 89 170 306 89 179 306 minecraft:blue_concrete
setblock 89 170 314 minecraft:white_wool
setblock 47 171 304 minecraft:white_wool
setblock 48 171 277 minecraft:spruce_planks
setblock 48 171 284 minecraft:spruce_planks
setblock 48 171 291 minecraft:spruce_planks
setblock 48 171 298 minecraft:spruce_planks
setblock 48 171 305 minecraft:spruce_planks
setblock 48 171 312 minecraft:spruce_planks
fill 51 171 316 53 171 316 minecraft:spruce_planks
setblock 52 171 312 minecraft:spruce_planks
fill 53 171 298 53 171 302 minecraft:spruce_planks
fill 54 171 276 56 171 276 minecraft:spruce_planks
fill 54 171 285 55 171 295 minecraft:spruce_planks
fill 54 171 307 54 171 309 minecraft:spruce_planks
fill 55 171 277 55 172 284 minecraft:spruce_planks
fill 55 171 296 55 171 297 minecraft:spruce_planks
fill 56 171 277 56 171 282 minecraft:spruce_planks
fill 57 171 294 57 171 297 minecraft:spruce_planks
fill 58 171 288 58 171 290 minecraft:dark_oak_planks
fill 58 171 291 58 171 293 minecraft:spruce_planks
fill 58 171 298 58 171 300 minecraft:spruce_planks
fill 58 171 301 58 171 303 minecraft:dark_oak_planks
setblock 58 171 316 minecraft:spruce_planks
setblock 59 171 279 minecraft:spruce_planks
setblock 61 171 276 minecraft:spruce_planks
fill 61 171 279 62 177 279 minecraft:dark_oak_planks
fill 61 171 282 61 177 282 minecraft:dark_oak_planks
setblock 63 171 279 minecraft:spruce_planks
fill 64 171 279 64 177 279 minecraft:dark_oak_planks
fill 64 171 282 64 177 282 minecraft:dark_oak_planks
setblock 65 171 316 minecraft:spruce_planks
setblock 68 171 276 minecraft:spruce_planks
fill 71 171 275 71 190 275 minecraft:blue_concrete
setblock 72 171 316 minecraft:spruce_planks
setblock 75 171 276 minecraft:spruce_planks
setblock 79 171 316 minecraft:spruce_planks
fill 80 171 317 80 190 317 minecraft:blue_concrete
setblock 81 171 317 minecraft:white_wool
setblock 82 171 276 minecraft:spruce_planks
fill 82 171 317 82 190 317 minecraft:blue_concrete
setblock 88 171 277 minecraft:spruce_planks
setblock 88 171 284 minecraft:spruce_planks
setblock 88 171 291 minecraft:spruce_planks
setblock 88 171 298 minecraft:spruce_planks
setblock 88 171 305 minecraft:spruce_planks
fill 89 171 314 89 172 314 minecraft:blue_concrete
fill 47 172 304 47 186 304 minecraft:blue_concrete
setblock 48 172 278 minecraft:spruce_planks
setblock 48 172 285 minecraft:spruce_planks
setblock 48 172 292 minecraft:spruce_planks
setblock 48 172 299 minecraft:spruce_planks
setblock 48 172 306 minecraft:spruce_planks
setblock 48 172 313 minecraft:spruce_planks
setblock 52 172 316 minecraft:spruce_planks
setblock 53 172 276 minecraft:spruce_planks
fill 53 172 304 53 172 315 minecraft:dark_oak_planks
fill 54 172 291 54 172 295 minecraft:spruce_planks
fill 54 172 296 54 172 304 minecraft:dark_oak_planks
fill 55 172 276 56 172 276 minecraft:spruce_planks
fill 55 172 285 55 172 290 minecraft:spruce_planks
fill 56 172 277 56 172 280 minecraft:spruce_planks
setblock 56 172 317 minecraft:light_blue_wool
fill 58 172 291 58 172 300 minecraft:dark_oak_planks
setblock 59 172 316 minecraft:spruce_planks
setblock 60 172 276 minecraft:spruce_planks
fill 60 172 279 60 177 282 minecraft:dark_oak_planks
fill 61 172 278 63 177 278 minecraft:dark_oak_planks
fill 61 172 283 63 177 283 minecraft:dark_oak_planks
fill 63 172 279 63 177 279 minecraft:dark_oak_planks
fill 65 172 280 65 177 281 minecraft:dark_oak_planks
setblock 66 172 316 minecraft:spruce_planks
setblock 67 172 276 minecraft:spruce_planks
fill 71 172 277 71 186 277 minecraft:white_wool
setblock 73 172 316 minecraft:spruce_planks
setblock 74 172 276 minecraft:spruce_planks
setblock 80 172 316 minecraft:spruce_planks
setblock 81 172 276 minecraft:spruce_planks
fill 81 172 317 81 190 317 minecraft:blue_concrete
fill 83 172 298 83 173 298 minecraft:shroomlight
setblock 84 172 308 minecraft:shroomlight
setblock 84 172 310 minecraft:shroomlight
setblock 84 172 312 minecraft:shroomlight
setblock 84 172 314 minecraft:shroomlight
setblock 84 172 316 minecraft:shroomlight
setblock 85 172 309 minecraft:shroomlight
setblock 85 172 311 minecraft:shroomlight
setblock 85 172 313 minecraft:shroomlight
setblock 85 172 315 minecraft:shroomlight
fill 86 172 284 86 172 285 minecraft:white_concrete
setblock 86 172 308 minecraft:shroomlight
setblock 86 172 310 minecraft:shroomlight
setblock 86 172 312 minecraft:shroomlight
setblock 86 172 314 minecraft:shroomlight
setblock 86 172 316 minecraft:shroomlight
setblock 87 172 309 minecraft:shroomlight
setblock 87 172 311 minecraft:shroomlight
setblock 87 172 313 minecraft:shroomlight
setblock 87 172 315 minecraft:shroomlight
setblock 88 172 276 minecraft:spruce_planks
setblock 88 172 283 minecraft:spruce_planks
setblock 88 172 290 minecraft:spruce_planks
setblock 88 172 297 minecraft:spruce_planks
setblock 88 172 304 minecraft:spruce_planks
setblock 88 172 308 minecraft:shroomlight
setblock 88 172 310 minecraft:shroomlight
setblock 88 172 312 minecraft:shroomlight
setblock 88 172 314 minecraft:shroomlight
setblock 88 172 316 minecraft:shroomlight
setblock 47 173 301 minecraft:white_wool
setblock 48 173 279 minecraft:spruce_planks
setblock 48 173 286 minecraft:spruce_planks
setblock 48 173 293 minecraft:spruce_planks
setblock 48 173 300 minecraft:spruce_planks
setblock 48 173 307 minecraft:spruce_planks
setblock 48 173 314 minecraft:spruce_planks
setblock 52 173 276 minecraft:spruce_planks
setblock 53 173 316 minecraft:spruce_planks
fill 54 173 298 54 180 298 minecraft:green_terracotta
fill 55 173 277 55 173 288 minecraft:dark_oak_planks
fill 56 173 276 56 173 277 minecraft:dark_oak_planks
fill 56 173 317 56 187 317 minecraft:blue_concrete
setblock 59 173 276 minecraft:spruce_planks
setblock 60 173 316 minecraft:spruce_planks
fill 64 173 278 64 177 278 minecraft:dark_oak_planks
fill 64 173 283 64 177 283 minecraft:dark_oak_planks
fill 65 173 279 65 177 279 minecraft:dark_oak_planks
fill 65 173 282 65 177 282 minecraft:dark_oak_planks
setblock 66 173 276 minecraft:spruce_planks
setblock 67 173 316 minecraft:spruce_planks
fill 69 173 277 70 186 277 minecraft:white_wool
fill 72 173 277 73 186 277 minecraft:white_wool
setblock 73 173 276 minecraft:spruce_planks
setblock 74 173 316 minecraft:spruce_planks
setblock 80 173 276 minecraft:spruce_planks
setblock 81 173 316 minecraft:spruce_planks
fill 84 173 308 84 174 308 minecraft:spruce_planks
fill 84 173 310 84 174 310 minecraft:spruce_planks
fill 84 173 312 84 174 312 minecraft:spruce_log
fill 84 173 314 84 174 314 minecraft:spruce_planks
fill 84 173 316 84 174 316 minecraft:spruce_planks
fill 85 173 309 85 174 309 minecraft:spruce_planks
fill 85 173 311 85 174 311 minecraft:spruce_planks
fill 85 173 313 85 174 313 minecraft:spruce_planks
fill 85 173 315 85 174 315 minecraft:spruce_planks
fill 86 173 308 86 174 308 minecraft:spruce_planks
fill 86 173 310 86 174 310 minecraft:spruce_planks
fill 86 173 312 86 174 312 minecraft:spruce_planks
fill 86 173 314 86 174 314 minecraft:spruce_planks
fill 86 173 316 86 174 316 minecraft:spruce_planks
setblock 87 173 276 minecraft:spruce_planks
fill 87 173 309 87 174 309 minecraft:spruce_planks
fill 87 173 311 87 174 311 minecraft:spruce_planks
fill 87 173 313 87 174 313 minecraft:spruce_planks
fill 87 173 315 87 174 315 minecraft:spruce_planks
setblock 88 173 282 minecraft:spruce_planks
setblock 88 173 289 minecraft:spruce_planks
setblock 88 173 296 minecraft:spruce_planks
setblock 88 173 303 minecraft:spruce_planks
fill 88 173 308 88 174 308 minecraft:spruce_planks
fill 88 173 310 88 174 310 minecraft:spruce_planks
fill 88 173 312 88 174 312 minecraft:spruce_planks
fill 88 173 314 88 174 314 minecraft:spruce_planks
fill 88 173 316 88 174 316 minecraft:spruce_planks
setblock 89 173 314 minecraft:white_wool
fill 47 174 301 47 191 301 minecraft:blue_concrete
setblock 48 174 280 minecraft:spruce_planks
setblock 48 174 287 minecraft:spruce_planks
setblock 48 174 294 minecraft:spruce_planks
setblock 48 174 301 minecraft:spruce_planks
setblock 48 174 308 minecraft:spruce_planks
setblock 48 174 315 minecraft:spruce_planks
setblock 51 174 276 minecraft:spruce_planks
setblock 54 174 316 minecraft:spruce_planks
fill 58 174 275 60 186 275 minecraft:blue_concrete
setblock 58 174 276 minecraft:spruce_planks
fill 59 174 279 59 177 282 minecraft:dark_oak_planks
fill 60 174 278 60 177 278 minecraft:dark_oak_planks
fill 60 174 283 60 177 283 minecraft:dark_oak_planks
fill 61 174 277 64 177 277 minecraft:dark_oak_planks
fill 61 174 284 64 177 284 minecraft:dark_oak_planks
setblock 61 174 316 minecraft:spruce_planks
setblock 64 174 275 minecraft:light_blue_wool
setblock 65 174 276 minecraft:spruce_planks
fill 65 174 278 65 177 278 minecraft:dark_oak_planks
fill 65 174 283 65 177 283 minecraft:dark_oak_planks
fill 66 174 280 66 177 281 minecraft:dark_oak_planks
setblock 68 174 316 minecraft:spruce_planks
setblock 72 174 276 minecraft:spruce_planks
setblock 75 174 316 minecraft:spruce_planks
setblock 79 174 276 minecraft:spruce_planks
setblock 82 174 316 minecraft:spruce_planks
fill 83 174 298 83 180 298 minecraft:dark_oak_planks
setblock 86 174 276 minecraft:spruce_planks
setblock 86 174 317 minecraft:white_wool
fill 87 174 317 87 190 317 minecraft:blue_concrete
setblock 88 174 281 minecraft:spruce_planks
setblock 88 174 288 minecraft:spruce_planks
setblock 88 174 295 minecraft:spruce_planks
setblock 88 174 302 minecraft:spruce_planks
fill 89 174 314 89 187 314 minecraft:blue_concrete
setblock 47 175 286 minecraft:white_wool
setblock 47 175 299 minecraft:white_wool
fill 59 175 278 59 177 278 minecraft:dark_oak_planks
fill 59 175 283 59 177 283 minecraft:dark_oak_planks
fill 60 175 277 60 177 277 minecraft:dark_oak_planks
fill 60 175 284 60 177 284 minecraft:dark_oak_planks
fill 64 175 275 64 190 275 minecraft:blue_concrete
fill 65 175 277 65 177 277 minecraft:dark_oak_planks
fill 66 175 279 66 177 279 minecraft:dark_oak_planks
fill 66 175 282 66 177 282 minecraft:dark_oak_planks
fill 83 175 297 83 180 297 minecraft:dark_oak_planks
fill 84 175 298 84 180 298 minecraft:dark_oak_planks
setblock 84 175 308 minecraft:shroomlight
setblock 84 175 310 minecraft:shroomlight
setblock 84 175 312 minecraft:shroomlight
setblock 84 175 314 minecraft:shroomlight
setblock 84 175 316 minecraft:shroomlight
setblock 85 175 309 minecraft:shroomlight
setblock 85 175 311 minecraft:shroomlight
setblock 85 175 313 minecraft:shroomlight
setblock 85 175 315 minecraft:shroomlight
setblock 86 175 308 minecraft:shroomlight
setblock 86 175 310 minecraft:shroomlight
setblock 86 175 312 minecraft:shroomlight
setblock 86 175 314 minecraft:shroomlight
setblock 86 175 316 minecraft:shroomlight
fill 86 175 317 86 187 317 minecraft:blue_concrete
setblock 87 175 309 minecraft:shroomlight
setblock 87 175 311 minecraft:shroomlight
setblock 87 175 313 minecraft:shroomlight
setblock 87 175 315 minecraft:shroomlight
setblock 88 175 308 minecraft:shroomlight
setblock 88 175 310 minecraft:shroomlight
setblock 88 175 312 minecraft:shroomlight
setblock 88 175 314 minecraft:shroomlight
setblock 88 175 316 minecraft:shroomlight
fill 47 176 286 47 187 286 minecraft:blue_concrete
fill 47 176 299 47 187 299 minecraft:blue_concrete
setblock 48 176 282 minecraft:spruce_planks
setblock 48 176 289 minecraft:spruce_planks
setblock 48 176 296 minecraft:spruce_planks
setblock 48 176 303 minecraft:spruce_planks
setblock 48 176 310 minecraft:spruce_planks
setblock 49 176 276 minecraft:spruce_planks
setblock 49 176 316 minecraft:spruce_planks
setblock 50 176 278 minecraft:light[level=12]
setblock 50 176 285 minecraft:light[level=12]
setblock 50 176 292 minecraft:light[level=12]
setblock 50 176 299 minecraft:light[level=12]
setblock 50 176 306 minecraft:light[level=12]
setblock 50 176 313 minecraft:light[level=12]
setblock 54 176 275 minecraft:white_wool
setblock 56 176 276 minecraft:spruce_planks
setblock 56 176 316 minecraft:spruce_planks
setblock 57 176 278 minecraft:light[level=12]
setblock 57 176 285 minecraft:light[level=12]
setblock 57 176 292 minecraft:light[level=12]
setblock 57 176 299 minecraft:light[level=12]
setblock 57 176 306 minecraft:light[level=12]
setblock 57 176 313 minecraft:light[level=12]
fill 58 176 279 58 177 282 minecraft:dark_oak_planks
fill 59 176 277 59 177 277 minecraft:dark_oak_planks
fill 61 176 276 62 176 276 minecraft:dark_oak_planks
fill 61 176 285 64 177 285 minecraft:dark_oak_planks
setblock 63 176 276 minecraft:spruce_planks
setblock 63 176 316 minecraft:spruce_planks
setblock 64 176 292 minecraft:light[level=12]
setblock 64 176 299 minecraft:light[level=12]
setblock 64 176 306 minecraft:light[level=12]
setblock 64 176 313 minecraft:light[level=12]
fill 65 176 284 65 177 284 minecraft:dark_oak_planks
fill 66 176 278 66 177 278 minecraft:dark_oak_planks
fill 66 176 283 66 177 283 minecraft:dark_oak_planks
fill 67 176 279 67 177 282 minecraft:dark_oak_planks
setblock 70 176 276 minecraft:spruce_planks
setblock 70 176 316 minecraft:spruce_planks
setblock 71 176 278 minecraft:light[level=12]
setblock 71 176 285 minecraft:light[level=12]
setblock 71 176 292 minecraft:light[level=12]
setblock 71 176 299 minecraft:light[level=12]
setblock 71 176 306 minecraft:light[level=12]
setblock 71 176 313 minecraft:light[level=12]
setblock 77 176 276 minecraft:spruce_planks
setblock 77 176 316 minecraft:spruce_planks
setblock 78 176 278 minecraft:light[level=12]
setblock 78 176 285 minecraft:light[level=12]
setblock 78 176 292 minecraft:light[level=12]
setblock 78 176 299 minecraft:light[level=12]
setblock 78 176 306 minecraft:light[level=12]
setblock 78 176 313 minecraft:light[level=12]
fill 82 176 297 82 180 298 minecraft:dark_oak_planks
fill 83 176 299 83 180 299 minecraft:dark_oak_planks
setblock 84 176 276 minecraft:spruce_planks
fill 84 176 297 84 180 297 minecraft:dark_oak_planks
fill 84 176 308 84 177 308 minecraft:spruce_planks
fill 84 176 310 84 177 310 minecraft:spruce_planks
fill 84 176 312 84 177 312 minecraft:spruce_log
fill 84 176 314 84 177 314 minecraft:spruce_planks
fill 84 176 316 84 177 316 minecraft:spruce_planks
setblock 85 176 278 minecraft:light[level=12]
setblock 85 176 285 minecraft:light[level=12]
setblock 85 176 292 minecraft:light[level=12]
setblock 85 176 299 minecraft:light[level=12]
setblock 85 176 306 minecraft:light[level=12]
fill 85 176 309 85 177 309 minecraft:spruce_planks
fill 85 176 311 85 177 311 minecraft:spruce_planks
fill 85 176 313 85 177 313 minecraft:spruce_planks
fill 85 176 315 85 177 315 minecraft:spruce_planks
fill 86 176 308 86 177 308 minecraft:spruce_planks
fill 86 176 310 86 177 310 minecraft:spruce_planks
fill 86 176 312 86 177 312 minecraft:spruce_planks
fill 86 176 314 86 177 314 minecraft:spruce_planks
fill 86 176 316 86 177 316 minecraft:spruce_planks
fill 87 176 309 87 177 309 minecraft:spruce_planks
fill 87 176 311 87 177 311 minecraft:spruce_planks
fill 87 176 313 87 177 313 minecraft:spruce_planks
fill 87 176 315 87 177 315 minecraft:spruce_planks
setblock 88 176 279 minecraft:spruce_planks
setblock 88 176 286 minecraft:spruce_planks
setblock 88 176 293 minecraft:spruce_planks
setblock 88 176 300 minecraft:spruce_planks
fill 88 176 307 88 176 308 minecraft:spruce_planks
fill 88 176 310 88 177 310 minecraft:spruce_planks
fill 88 176 312 88 177 312 minecraft:spruce_planks
fill 88 176 314 88 177 314 minecraft:spruce_planks
fill 88 176 316 88 177 316 minecraft:spruce_planks
setblock 47 177 303 minecraft:white_wool
setblock 48 177 276 minecraft:spruce_planks
setblock 48 177 283 minecraft:spruce_planks
setblock 48 177 290 minecraft:spruce_planks
setblock 48 177 297 minecraft:spruce_planks
setblock 48 177 304 minecraft:spruce_planks
setblock 48 177 311 minecraft:spruce_planks
setblock 50 177 316 minecraft:spruce_planks
fill 54 177 275 54 190 275 minecraft:blue_concrete
setblock 55 177 275 minecraft:white_wool
setblock 55 177 276 minecraft:spruce_planks
fill 56 177 275 56 190 275 minecraft:blue_concrete
setblock 57 177 316 minecraft:spruce_planks
setblock 58 177 278 minecraft:dark_oak_planks
setblock 58 177 283 minecraft:dark_oak_planks
setblock 59 177 284 minecraft:dark_oak_planks
fill 60 177 276 61 177 276 minecraft:dark_oak_planks
setblock 60 177 285 minecraft:dark_oak_planks
setblock 62 177 276 minecraft:spruce_planks
setblock 63 177 276 minecraft:dark_oak_planks
setblock 64 177 316 minecraft:spruce_planks
setblock 65 177 276 minecraft:dark_oak_planks
setblock 65 177 285 minecraft:dark_oak_planks
setblock 66 177 277 minecraft:dark_oak_planks
setblock 66 177 284 minecraft:dark_oak_planks
setblock 67 177 278 minecraft:dark_oak_planks
setblock 67 177 283 minecraft:dark_oak_planks
setblock 69 177 276 minecraft:spruce_planks
setblock 71 177 316 minecraft:spruce_planks
fill 75 177 314 76 177 314 minecraft:white_concrete
setblock 76 177 276 minecraft:spruce_planks
setblock 78 177 316 minecraft:spruce_planks
fill 81 177 279 81 177 280 minecraft:dark_oak_planks
setblock 82 177 278 minecraft:dark_oak_planks
setblock 82 177 281 minecraft:dark_oak_planks
fill 82 177 299 82 180 299 minecraft:dark_oak_planks
setblock 83 177 276 minecraft:spruce_planks
fill 83 177 277 84 177 277 minecraft:dark_oak_planks
fill 83 177 296 83 180 296 minecraft:dark_oak_planks
fill 84 177 281 85 177 281 minecraft:dark_oak_planks
fill 84 177 299 84 180 299 minecraft:dark_oak_planks
setblock 85 177 278 minecraft:dark_oak_planks
setblock 85 177 280 minecraft:dark_oak_planks
setblock 86 177 275 minecraft:white_wool
setblock 88 177 278 minecraft:spruce_planks
setblock 88 177 285 minecraft:spruce_planks
setblock 88 177 292 minecraft:spruce_planks
setblock 88 177 299 minecraft:spruce_planks
setblock 88 177 306 minecraft:spruce_planks
setblock 88 177 308 minecraft:spruce_planks
fill 47 178 303 47 190 303 minecraft:blue_concrete
setblock 48 178 277 minecraft:spruce_planks
setblock 48 178 284 minecraft:spruce_planks
setblock 48 178 291 minecraft:spruce_planks
setblock 48 178 298 minecraft:spruce_planks
setblock 48 178 305 minecraft:spruce_planks
setblock 48 178 312 minecraft:spruce_planks
setblock 50 178 278 minecraft:light[level=15]
setblock 50 178 286 minecraft:light[level=15]
setblock 50 178 294 minecraft:light[level=15]
setblock 50 178 302 minecraft:light[level=15]
setblock 50 178 310 minecraft:light[level=15]
setblock 51 178 316 minecraft:spruce_planks
setblock 54 178 276 minecraft:spruce_planks
fill 55 178 275 55 182 275 minecraft:blue_concrete
setblock 58 178 278 minecraft:light[level=15]
setblock 58 178 286 minecraft:light[level=15]
setblock 58 178 294 minecraft:light[level=15]
setblock 58 178 302 minecraft:light[level=15]
setblock 58 178 310 minecraft:light[level=15]
setblock 58 178 316 minecraft:spruce_planks
setblock 61 178 276 minecraft:spruce_planks
fill 61 178 282 61 182 282 minecraft:spruce_planks
fill 61 178 317 61 179 317 minecraft:light_blue_wool
fill 62 178 279 62 179 279 minecraft:spruce_planks
fill 64 178 281 64 181 281 minecraft:spruce_planks
setblock 65 178 316 minecraft:spruce_planks
setblock 66 178 278 minecraft:light[level=15]
setblock 66 178 286 minecraft:light[level=15]
setblock 66 178 294 minecraft:light[level=15]
setblock 66 178 302 minecraft:light[level=15]
setblock 66 178 310 minecraft:light[level=15]
setblock 68 178 276 minecraft:spruce_planks
setblock 72 178 316 minecraft:spruce_planks
setblock 74 178 278 minecraft:light[level=15]
setblock 74 178 286 minecraft:light[level=15]
setblock 74 178 294 minecraft:light[level=15]
setblock 74 178 302 minecraft:light[level=15]
setblock 74 178 310 minecraft:light[level=15]
setblock 75 178 276 minecraft:spruce_planks
setblock 79 178 316 minecraft:spruce_planks
fill 81 178 297 81 180 299 minecraft:dark_oak_planks
setblock 82 178 276 minecraft:spruce_planks
setblock 82 178 278 minecraft:light[level=15]
setblock 82 178 286 minecraft:light[level=15]
setblock 82 178 294 minecraft:light[level=15]
fill 82 178 296 82 180 296 minecraft:dark_oak_planks
fill 82 178 300 84 180 300 minecraft:dark_oak_planks
setblock 82 178 302 minecraft:light[level=15]
setblock 82 178 310 minecraft:light[level=15]
fill 84 178 296 84 180 296 minecraft:dark_oak_planks
setblock 84 178 308 minecraft:shroomlight
setblock 84 178 310 minecraft:shroomlight
setblock 84 178 312 minecraft:shroomlight
setblock 84 178 314 minecraft:shroomlight
setblock 84 178 316 minecraft:shroomlight
fill 85 178 297 85 180 299 minecraft:dark_oak_planks
setblock 85 178 309 minecraft:shroomlight
setblock 85 178 311 minecraft:shroomlight
setblock 85 178 313 minecraft:shroomlight
setblock 85 178 315 minecraft:shroomlight
fill 86 178 275 86 187 275 minecraft:blue_concrete
setblock 86 178 308 minecraft:shroomlight
setblock 86 178 310 minecraft:shroomlight
setblock 86 178 312 minecraft:shroomlight
setblock 86 178 314 minecraft:shroomlight
setblock 86 178 316 minecraft:shroomlight
setblock 87 178 309 minecraft:shroomlight
setblock 87 178 311 minecraft:shroomlight
setblock 87 178 313 minecraft:shroomlight
setblock 87 178 315 minecraft:shroomlight
setblock 88 178 277 minecraft:spruce_planks
setblock 88 178 284 minecraft:spruce_planks
setblock 88 178 291 minecraft:spruce_planks
setblock 88 178 298 minecraft:spruce_planks
setblock 88 178 305 minecraft:spruce_planks
setblock 88 178 308 minecraft:shroomlight
setblock 88 178 310 minecraft:shroomlight
setblock 88 178 312 minecraft:shroomlight
setblock 88 178 314 minecraft:shroomlight
setblock 88 178 316 minecraft:shroomlight
setblock 47 179 314 minecraft:white_wool
fill 47 179 315 47 190 316 minecraft:blue_concrete
fill 48 179 278 48 180 278 minecraft:spruce_planks
fill 48 179 285 48 180 285 minecraft:spruce_planks
fill 48 179 292 48 180 292 minecraft:spruce_planks
fill 48 179 299 48 180 299 minecraft:spruce_planks
fill 48 179 306 48 180 306 minecraft:spruce_planks
fill 48 179 313 48 180 313 minecraft:spruce_planks
fill 52 179 316 52 180 316 minecraft:spruce_planks
setblock 52 179 317 minecraft:white_wool
fill 53 179 276 53 180 276 minecraft:spruce_planks
fill 59 179 316 59 180 316 minecraft:spruce_planks
fill 60 179 276 60 180 276 minecraft:spruce_planks
fill 66 179 316 66 180 316 minecraft:spruce_planks
fill 67 179 276 67 180 276 minecraft:spruce_planks
fill 73 179 316 73 180 316 minecraft:spruce_planks
fill 74 179 276 74 180 276 minecraft:spruce_planks
fill 80 179 316 80 180 316 minecraft:spruce_planks
fill 81 179 276 81 180 276 minecraft:spruce_planks
fill 81 179 296 81 180 296 minecraft:dark_oak_planks
fill 83 179 295 83 180 295 minecraft:dark_oak_planks
fill 84 179 308 84 180 308 minecraft:spruce_planks
fill 84 179 310 84 180 310 minecraft:spruce_planks
fill 84 179 312 84 180 312 minecraft:spruce_log
fill 84 179 314 84 180 314 minecraft:spruce_planks
fill 84 179 316 84 180 316 minecraft:spruce_planks
fill 85 179 282 85 198 282 minecraft:green_terracotta
fill 85 179 296 85 180 296 minecraft:dark_oak_planks
fill 85 179 309 85 180 309 minecraft:spruce_planks
fill 85 179 311 85 180 311 minecraft:spruce_planks
fill 85 179 313 85 180 313 minecraft:spruce_planks
fill 85 179 315 85 180 315 minecraft:spruce_planks
fill 86 179 308 86 180 308 minecraft:spruce_planks
fill 86 179 310 86 180 310 minecraft:spruce_planks
fill 86 179 312 86 180 312 minecraft:spruce_planks
fill 86 179 314 86 180 314 minecraft:spruce_planks
fill 86 179 316 86 180 316 minecraft:spruce_planks
fill 87 179 309 87 180 309 minecraft:spruce_planks
fill 87 179 311 87 180 311 minecraft:spruce_planks
fill 87 179 313 87 180 313 minecraft:spruce_planks
fill 87 179 315 87 180 315 minecraft:spruce_planks
fill 88 179 276 88 180 276 minecraft:spruce_planks
fill 88 179 283 88 180 283 minecraft:spruce_planks
fill 88 179 290 88 180 290 minecraft:spruce_planks
fill 88 179 297 88 180 297 minecraft:spruce_planks
fill 88 179 304 88 180 304 minecraft:spruce_planks
fill 88 179 308 88 180 308 minecraft:spruce_planks
fill 88 179 310 88 180 310 minecraft:spruce_planks
fill 88 179 312 88 180 312 minecraft:spruce_planks
fill 88 179 314 88 180 314 minecraft:spruce_planks
fill 88 179 316 88 180 316 minecraft:spruce_planks
fill 47 180 314 47 190 314 minecraft:blue_concrete
setblock 48 180 275 minecraft:white_wool
fill 48 180 276 48 180 277 minecraft:spruce_planks
fill 48 180 279 48 180 280 minecraft:spruce_planks
fill 48 180 282 48 180 284 minecraft:spruce_planks
fill 48 180 286 48 180 287 minecraft:spruce_planks
fill 48 180 289 48 180 291 minecraft:spruce_planks
fill 48 180 293 48 180 294 minecraft:spruce_planks
fill 48 180 296 48 180 298 minecraft:spruce_planks
fill 48 180 300 48 180 301 minecraft:spruce_planks
fill 48 180 303 48 180 305 minecraft:spruce_planks
fill 48 180 307 48 180 308 minecraft:spruce_planks
fill 48 180 310 48 180 312 minecraft:spruce_planks
fill 48 180 314 48 180 315 minecraft:spruce_planks
fill 49 180 275 49 191 275 minecraft:blue_concrete
setblock 49 180 276 minecraft:spruce_planks
fill 49 180 316 51 180 316 minecraft:spruce_planks
fill 51 180 276 52 180 276 minecraft:spruce_planks
fill 52 180 317 52 190 317 minecraft:blue_concrete
fill 53 180 316 54 180 316 minecraft:spruce_planks
fill 54 180 276 56 180 276 minecraft:spruce_planks
fill 56 180 316 58 180 316 minecraft:spruce_planks
fill 58 180 276 59 180 276 minecraft:spruce_planks
fill 60 180 316 61 180 316 minecraft:spruce_planks
fill 61 180 276 63 180 276 minecraft:spruce_planks
fill 61 180 317 61 191 317 minecraft:blue_concrete
fill 63 180 316 65 180 316 minecraft:spruce_planks
setblock 63 180 317 minecraft:light_blue_wool
fill 64 180 317 64 191 317 minecraft:blue_concrete
fill 65 180 276 66 180 276 minecraft:spruce_planks
fill 67 180 316 68 180 316 minecraft:spruce_planks
fill 68 180 276 70 180 276 minecraft:spruce_planks
fill 70 180 316 72 180 316 minecraft:spruce_planks
fill 72 180 276 73 180 276 minecraft:spruce_planks
fill 74 180 316 75 180 316 minecraft:spruce_planks
fill 75 180 276 77 180 276 minecraft:spruce_planks
fill 77 180 316 79 180 316 minecraft:spruce_planks
fill 79 180 276 80 180 276 minecraft:spruce_planks
fill 80 180 297 80 180 299 minecraft:dark_oak_planks
setblock 81 180 300 minecraft:dark_oak_planks
fill 81 180 316 82 180 316 minecraft:spruce_planks
fill 82 180 276 84 180 276 minecraft:spruce_planks
setblock 82 180 295 minecraft:dark_oak_planks
fill 83 180 301 84 180 301 minecraft:dark_oak_planks
setblock 84 180 295 minecraft:dark_oak_planks
setblock 85 180 300 minecraft:dark_oak_planks
fill 86 180 276 87 180 276 minecraft:spruce_planks
fill 86 180 297 86 180 299 minecraft:dark_oak_planks
fill 88 180 277 88 180 279 minecraft:spruce_planks
fill 88 180 281 88 180 282 minecraft:spruce_planks
fill 88 180 284 88 180 286 minecraft:spruce_planks
fill 88 180 288 88 180 289 minecraft:spruce_planks
fill 88 180 291 88 180 293 minecraft:spruce_planks
fill 88 180 295 88 180 296 minecraft:spruce_planks
fill 88 180 298 88 180 300 minecraft:spruce_planks
fill 88 180 302 88 180 303 minecraft:spruce_planks
fill 88 180 305 88 180 307 minecraft:spruce_planks
setblock 89 180 306 minecraft:white_wool
fill 48 181 275 48 190 275 minecraft:blue_concrete
setblock 48 181 280 minecraft:spruce_planks
setblock 48 181 287 minecraft:spruce_planks
setblock 48 181 294 minecraft:spruce_planks
setblock 48 181 301 minecraft:spruce_planks
setblock 48 181 308 minecraft:spruce_planks
setblock 48 181 315 minecraft:spruce_planks
setblock 51 181 276 minecraft:spruce_planks
setblock 54 181 316 minecraft:spruce_planks
setblock 58 181 276 minecraft:spruce_planks
setblock 61 181 316 minecraft:spruce_planks
fill 63 181 317 63 188 317 minecraft:blue_concrete
setblock 65 181 276 minecraft:spruce_planks
setblock 68 181 316 minecraft:spruce_planks
setblock 72 181 276 minecraft:spruce_planks
setblock 75 181 316 minecraft:spruce_planks
setblock 77 181 317 minecraft:white_wool
setblock 79 181 276 minecraft:spruce_planks
fill 82 181 296 82 184 296 minecraft:spruce_planks
fill 82 181 299 82 182 299 minecraft:spruce_planks
setblock 82 181 316 minecraft:spruce_planks
setblock 84 181 308 minecraft:shroomlight
setblock 84 181 310 minecraft:shroomlight
setblock 84 181 312 minecraft:shroomlight
setblock 84 181 314 minecraft:shroomlight
setblock 84 181 316 minecraft:shroomlight
fill 85 181 298 85 182 298 minecraft:spruce_planks
setblock 85 181 309 minecraft:shroomlight
setblock 85 181 311 minecraft:shroomlight
setblock 85 181 313 minecraft:shroomlight
setblock 85 181 315 minecraft:shroomlight
setblock 86 181 276 minecraft:spruce_planks
setblock 86 181 308 minecraft:shroomlight
setblock 86 181 310 minecraft:shroomlight
setblock 86 181 312 minecraft:shroomlight
setblock 86 181 314 minecraft:shroomlight
setblock 86 181 316 minecraft:shroomlight
setblock 87 181 309 minecraft:shroomlight
setblock 87 181 311 minecraft:shroomlight
setblock 87 181 313 minecraft:shroomlight
setblock 87 181 315 minecraft:shroomlight
setblock 88 181 281 minecraft:spruce_planks
setblock 88 181 288 minecraft:spruce_planks
setblock 88 181 295 minecraft:spruce_planks
setblock 88 181 302 minecraft:spruce_planks
setblock 88 181 308 minecraft:shroomlight
setblock 88 181 310 minecraft:shroomlight
setblock 88 181 312 minecraft:shroomlight
setblock 88 181 314 minecraft:shroomlight
setblock 88 181 316 minecraft:shroomlight
fill 89 181 306 89 190 306 minecraft:blue_concrete
setblock 50 182 278 minecraft:light[level=12]
setblock 50 182 285 minecraft:light[level=12]
setblock 50 182 292 minecraft:light[level=12]
setblock 50 182 299 minecraft:light[level=12]
setblock 50 182 306 minecraft:light[level=12]
setblock 50 182 313 minecraft:light[level=12]
setblock 57 182 278 minecraft:light[level=12]
setblock 57 182 285 minecraft:light[level=12]
setblock 57 182 292 minecraft:light[level=12]
setblock 57 182 299 minecraft:light[level=12]
setblock 57 182 306 minecraft:light[level=12]
setblock 57 182 313 minecraft:light[level=12]
setblock 64 182 278 minecraft:light[level=12]
setblock 64 182 285 minecraft:light[level=12]
setblock 64 182 292 minecraft:light[level=12]
setblock 64 182 299 minecraft:light[level=12]
setblock 64 182 306 minecraft:light[level=12]
setblock 64 182 313 minecraft:light[level=12]
setblock 71 182 278 minecraft:light[level=12]
setblock 71 182 285 minecraft:light[level=12]
setblock 71 182 292 minecraft:light[level=12]
setblock 71 182 299 minecraft:light[level=12]
setblock 71 182 306 minecraft:light[level=12]
setblock 71 182 313 minecraft:light[level=12]
fill 77 182 317 77 190 317 minecraft:blue_concrete
setblock 78 182 278 minecraft:light[level=12]
setblock 78 182 285 minecraft:light[level=12]
setblock 78 182 292 minecraft:light[level=12]
setblock 78 182 299 minecraft:light[level=12]
setblock 78 182 306 minecraft:light[level=12]
setblock 78 182 313 minecraft:light[level=12]
fill 84 182 308 84 184 308 minecraft:spruce_planks
fill 84 182 310 84 184 310 minecraft:spruce_planks
fill 84 182 312 84 183 312 minecraft:spruce_log
fill 84 182 314 84 184 314 minecraft:spruce_planks
fill 84 182 316 84 184 316 minecraft:spruce_planks
setblock 85 182 278 minecraft:light[level=12]
setblock 85 182 285 minecraft:light[level=12]
fill 85 182 291 85 182 292 minecraft:white_concrete
setblock 85 182 299 minecraft:light[level=12]
setblock 85 182 306 minecraft:light[level=12]
fill 85 182 309 85 184 309 minecraft:spruce_planks
fill 85 182 311 85 184 311 minecraft:spruce_planks
fill 85 182 313 85 184 313 minecraft:spruce_planks
fill 85 182 315 85 184 315 minecraft:spruce_planks
fill 86 182 308 86 184 308 minecraft:spruce_planks
fill 86 182 310 86 184 310 minecraft:spruce_planks
fill 86 182 312 86 183 312 minecraft:spruce_planks
fill 86 182 314 86 184 314 minecraft:spruce_planks
fill 86 182 316 86 185 316 minecraft:spruce_planks
fill 87 182 309 87 184 309 minecraft:spruce_planks
fill 87 182 311 87 184 311 minecraft:spruce_planks
fill 87 182 313 87 184 313 minecraft:spruce_planks
fill 87 182 315 87 184 315 minecraft:spruce_planks
fill 88 182 308 88 219 308 minecraft:spruce_planks
fill 88 182 310 88 184 310 minecraft:spruce_planks
fill 88 182 312 88 183 312 minecraft:spruce_planks
fill 88 182 314 88 184 314 minecraft:spruce_planks
fill 88 182 316 88 184 316 minecraft:spruce_planks
fill 89 182 301 89 182 302 minecraft:light_blue_wool
setblock 89 182 313 minecraft:white_wool
setblock 47 183 308 minecraft:light_blue_wool
setblock 48 183 282 minecraft:spruce_planks
setblock 48 183 289 minecraft:spruce_planks
setblock 48 183 296 minecraft:spruce_planks
setblock 48 183 303 minecraft:spruce_planks
setblock 48 183 310 minecraft:spruce_planks
setblock 49 183 276 minecraft:spruce_planks
setblock 49 183 316 minecraft:spruce_planks
setblock 55 183 275 minecraft:light_blue_wool
setblock 56 183 276 minecraft:spruce_planks
setblock 56 183 316 minecraft:spruce_planks
setblock 63 183 276 minecraft:spruce_planks
setblock 63 183 316 minecraft:spruce_planks
setblock 70 183 276 minecraft:spruce_planks
setblock 70 183 316 minecraft:spruce_planks
setblock 77 183 276 minecraft:spruce_planks
setblock 77 183 316 minecraft:spruce_planks
fill 81 183 314 82 183 314 minecraft:white_concrete
setblock 84 183 276 minecraft:spruce_planks
setblock 88 183 279 minecraft:spruce_planks
setblock 88 183 286 minecraft:spruce_planks
setblock 88 183 293 minecraft:spruce_planks
setblock 88 183 300 minecraft:spruce_planks
setblock 88 183 307 minecraft:spruce_planks
setblock 89 183 281 minecraft:white_wool
setblock 89 183 297 minecraft:white_wool
fill 89 183 301 89 190 302 minecraft:blue_concrete
fill 89 183 313 89 186 313 minecraft:blue_concrete
setblock 47 184 295 minecraft:white_wool
fill 47 184 308 47 190 308 minecraft:blue_concrete
setblock 48 184 276 minecraft:spruce_planks
fill 48 184 280 56 190 280 minecraft:white_wool
setblock 48 184 283 minecraft:spruce_planks
setblock 48 184 290 minecraft:spruce_planks
setblock 48 184 297 minecraft:spruce_planks
setblock 48 184 304 minecraft:spruce_planks
setblock 48 184 311 minecraft:spruce_planks
setblock 50 184 316 minecraft:spruce_planks
fill 55 184 275 55 191 275 minecraft:blue_concrete
setblock 55 184 276 minecraft:spruce_planks
setblock 57 184 316 minecraft:spruce_planks
setblock 62 184 276 minecraft:spruce_planks
setblock 64 184 316 minecraft:spruce_planks
setblock 69 184 276 minecraft:spruce_planks
setblock 71 184 316 minecraft:spruce_planks
setblock 76 184 276 minecraft:spruce_planks
setblock 78 184 316 minecraft:spruce_planks
fill 80 184 312 88 190 312 minecraft:white_wool
setblock 83 184 276 minecraft:spruce_planks
setblock 88 184 278 minecraft:spruce_planks
setblock 88 184 285 minecraft:spruce_planks
setblock 88 184 292 minecraft:spruce_planks
setblock 88 184 299 minecraft:spruce_planks
setblock 88 184 306 minecraft:spruce_planks
fill 89 184 281 89 190 281 minecraft:blue_concrete
fill 89 184 297 89 190 297 minecraft:blue_concrete
fill 47 185 295 47 190 295 minecraft:blue_concrete
setblock 48 185 277 minecraft:spruce_planks
setblock 48 185 284 minecraft:spruce_planks
setblock 48 185 291 minecraft:spruce_planks
setblock 48 185 298 minecraft:spruce_planks
setblock 48 185 305 minecraft:spruce_planks
setblock 48 185 312 minecraft:spruce_planks
setblock 51 185 316 minecraft:spruce_planks
setblock 54 185 276 minecraft:spruce_planks
setblock 58 185 316 minecraft:spruce_planks
setblock 61 185 276 minecraft:spruce_planks
setblock 65 185 316 minecraft:spruce_planks
setblock 68 185 276 minecraft:spruce_planks
setblock 69 185 275 minecraft:light_blue_wool
setblock 72 185 316 minecraft:spruce_planks
setblock 75 185 276 minecraft:spruce_planks
setblock 79 185 316 minecraft:spruce_planks
fill 81 185 279 81 185 280 minecraft:dark_oak_planks
setblock 82 185 276 minecraft:spruce_planks
setblock 82 185 278 minecraft:dark_oak_planks
setblock 82 185 281 minecraft:dark_oak_planks
fill 83 185 277 84 185 277 minecraft:dark_oak_planks
fill 84 185 281 85 185 281 minecraft:dark_oak_planks
setblock 85 185 278 minecraft:dark_oak_planks
setblock 85 185 280 minecraft:dark_oak_planks
fill 85 185 305 87 186 305 minecraft:iron_bars
setblock 88 185 277 minecraft:spruce_planks
setblock 88 185 284 minecraft:spruce_planks
setblock 88 185 291 minecraft:spruce_planks
setblock 88 185 298 minecraft:spruce_planks
setblock 88 185 305 minecraft:spruce_planks
setblock 48 186 278 minecraft:spruce_planks
setblock 48 186 285 minecraft:spruce_planks
setblock 48 186 292 minecraft:spruce_planks
setblock 48 186 299 minecraft:spruce_planks
setblock 48 186 306 minecraft:spruce_planks
setblock 48 186 313 minecraft:spruce_planks
setblock 50 186 278 minecraft:light[level=15]
setblock 50 186 286 minecraft:light[level=15]
setblock 50 186 294 minecraft:light[level=15]
setblock 50 186 302 minecraft:light[level=15]
setblock 50 186 310 minecraft:light[level=15]
setblock 52 186 316 minecraft:spruce_planks
setblock 53 186 276 minecraft:spruce_planks
setblock 58 186 278 minecraft:light[level=15]
setblock 58 186 286 minecraft:light[level=15]
setblock 58 186 294 minecraft:light[level=15]
setblock 58 186 302 minecraft:light[level=15]
setblock 58 186 310 minecraft:light[level=15]
setblock 59 186 316 minecraft:spruce_planks
setblock 60 186 276 minecraft:spruce_planks
setblock 66 186 278 minecraft:light[level=15]
setblock 66 186 286 minecraft:light[level=15]
setblock 66 186 294 minecraft:light[level=15]
setblock 66 186 302 minecraft:light[level=15]
setblock 66 186 310 minecraft:light[level=15]
setblock 66 186 316 minecraft:spruce_planks
setblock 67 186 276 minecraft:spruce_planks
fill 69 186 275 69 190 275 minecraft:blue_concrete
setblock 73 186 316 minecraft:spruce_planks
setblock 74 186 276 minecraft:spruce_planks
setblock 74 186 278 minecraft:light[level=15]
setblock 74 186 286 minecraft:light[level=15]
setblock 74 186 294 minecraft:light[level=15]
setblock 74 186 302 minecraft:light[level=15]
setblock 74 186 310 minecraft:light[level=15]
setblock 76 186 317 minecraft:white_wool
setblock 80 186 316 minecraft:spruce_planks
setblock 81 186 276 minecraft:spruce_planks
setblock 82 186 278 minecraft:light[level=15]
setblock 82 186 286 minecraft:light[level=15]
setblock 82 186 294 minecraft:light[level=15]
setblock 82 186 302 minecraft:light[level=15]
setblock 82 186 310 minecraft:light[level=15]
setblock 87 186 316 minecraft:spruce_planks
setblock 88 186 276 minecraft:spruce_planks
setblock 88 186 283 minecraft:spruce_planks
setblock 88 186 290 minecraft:spruce_planks
setblock 88 186 297 minecraft:spruce_planks
setblock 88 186 304 minecraft:spruce_planks
setblock 88 186 311 minecraft:spruce_planks
setblock 47 187 275 minecraft:cyan_concrete
fill 47 187 276 47 190 277 minecraft:blue_concrete
setblock 47 187 283 minecraft:cyan_concrete
fill 47 187 284 47 187 285 minecraft:blue_concrete
setblock 47 187 300 minecraft:cyan_concrete
setblock 47 187 304 minecraft:cyan_concrete
setblock 47 187 317 minecraft:cyan_concrete
setblock 48 187 279 minecraft:spruce_planks
setblock 48 187 286 minecraft:spruce_planks
setblock 48 187 293 minecraft:spruce_planks
setblock 48 187 300 minecraft:spruce_planks
setblock 48 187 307 minecraft:spruce_planks
setblock 48 187 314 minecraft:spruce_planks
fill 50 187 275 50 190 275 minecraft:blue_concrete
setblock 51 187 275 minecraft:cyan_concrete
setblock 52 187 276 minecraft:spruce_planks
setblock 53 187 316 minecraft:spruce_planks
setblock 54 187 317 minecraft:cyan_concrete
fill 56 187 314 56 201 314 minecraft:white_wool
fill 58 187 275 58 190 275 minecraft:blue_concrete
setblock 58 187 317 minecraft:cyan_concrete
setblock 59 187 275 minecraft:cyan_concrete
setblock 59 187 276 minecraft:spruce_planks
fill 59 187 317 59 190 317 minecraft:blue_concrete
fill 60 187 275 60 191 275 minecraft:blue_concrete
setblock 60 187 316 minecraft:spruce_planks
setblock 66 187 276 minecraft:spruce_planks
setblock 67 187 316 minecraft:spruce_planks
setblock 68 187 275 minecraft:cyan_concrete
fill 68 187 277 74 188 277 minecraft:iron_bars
setblock 73 187 276 minecraft:spruce_planks
setblock 74 187 316 minecraft:spruce_planks
fill 76 187 317 76 190 317 minecraft:blue_concrete
setblock 79 187 317 minecraft:light_blue_wool
setblock 80 187 275 minecraft:light_blue_wool
setblock 80 187 276 minecraft:spruce_planks
setblock 81 187 316 minecraft:spruce_planks
setblock 83 187 317 minecraft:white_wool
setblock 84 187 275 minecraft:cyan_concrete
setblock 87 187 276 minecraft:spruce_planks
setblock 88 187 282 minecraft:spruce_planks
setblock 88 187 289 minecraft:spruce_planks
setblock 88 187 296 minecraft:spruce_planks
setblock 88 187 303 minecraft:spruce_planks
setblock 88 187 310 minecraft:spruce_planks
setblock 88 187 316 minecraft:spruce_planks
setblock 88 187 317 minecraft:cyan_concrete
setblock 89 187 283 minecraft:cyan_concrete
setblock 89 187 290 minecraft:cyan_concrete
setblock 89 187 295 minecraft:cyan_concrete
setblock 89 187 298 minecraft:cyan_concrete
setblock 89 187 300 minecraft:white_wool
setblock 89 187 310 minecraft:cyan_concrete
setblock 89 187 313 minecraft:cyan_concrete
fill 47 188 275 47 190 275 minecraft:blue_concrete
setblock 47 188 282 minecraft:light_blue_wool
fill 47 188 283 47 190 283 minecraft:blue_concrete
setblock 47 188 284 minecraft:cyan_concrete
fill 47 188 285 47 190 285 minecraft:blue_concrete
setblock 47 188 286 minecraft:cyan_concrete
setblock 47 188 290 minecraft:cyan_concrete
setblock 47 188 297 minecraft:cyan_concrete
setblock 47 188 299 minecraft:cyan_concrete
fill 47 188 300 47 190 300 minecraft:blue_concrete
setblock 47 188 302 minecraft:cyan_concrete
fill 47 188 304 47 190 304 minecraft:blue_concrete
setblock 47 188 305 minecraft:cyan_concrete
fill 47 188 309 47 189 309 minecraft:cyan_concrete
setblock 47 188 313 minecraft:cyan_concrete
fill 47 188 317 47 191 317 minecraft:blue_concrete
setblock 48 188 287 minecraft:spruce_planks
setblock 48 188 294 minecraft:spruce_planks
setblock 48 188 301 minecraft:spruce_planks
setblock 48 188 308 minecraft:spruce_planks
setblock 48 188 315 minecraft:spruce_planks
setblock 50 188 278 minecraft:light[level=12]
setblock 50 188 285 minecraft:light[level=12]
setblock 50 188 292 minecraft:light[level=12]
setblock 50 188 299 minecraft:light[level=12]
setblock 50 188 306 minecraft:light[level=12]
setblock 50 188 313 minecraft:light[level=12]
fill 51 188 275 51 191 275 minecraft:blue_concrete
setblock 51 188 276 minecraft:spruce_planks
fill 54 188 314 55 201 314 minecraft:white_wool
setblock 54 188 316 minecraft:spruce_planks
fill 54 188 317 54 190 317 minecraft:blue_concrete
setblock 56 188 317 minecraft:cyan_concrete
setblock 57 188 275 minecraft:cyan_concrete
setblock 57 188 278 minecraft:light[level=12]
fill 57 188 279 57 204 279 minecraft:iron_bars
setblock 57 188 285 minecraft:light[level=12]
setblock 57 188 292 minecraft:light[level=12]
setblock 57 188 299 minecraft:light[level=12]
setblock 57 188 306 minecraft:light[level=12]
setblock 57 188 313 minecraft:light[level=12]
fill 57 188 314 58 201 314 minecraft:white_wool
setblock 58 188 276 minecraft:spruce_planks
fill 58 188 317 58 190 317 minecraft:blue_concrete
fill 59 188 275 59 190 275 minecraft:blue_concrete
setblock 61 188 316 minecraft:spruce_planks
setblock 64 188 278 minecraft:light[level=12]
setblock 64 188 285 minecraft:light[level=12]
setblock 64 188 292 minecraft:light[level=12]
setblock 64 188 299 minecraft:light[level=12]
setblock 64 188 306 minecraft:light[level=12]
setblock 64 188 313 minecraft:light[level=12]
setblock 65 188 276 minecraft:spruce_planks
setblock 67 188 317 minecraft:cyan_concrete
setblock 68 188 275 minecraft:blue_concrete
setblock 68 188 316 minecraft:spruce_planks
fill 68 188 317 68 190 317 minecraft:blue_concrete
setblock 71 188 278 minecraft:light[level=12]
setblock 71 188 285 minecraft:light[level=12]
setblock 71 188 292 minecraft:light[level=12]
setblock 71 188 299 minecraft:light[level=12]
setblock 71 188 306 minecraft:light[level=12]
setblock 71 188 313 minecraft:light[level=12]
setblock 72 188 276 minecraft:spruce_planks
setblock 75 188 316 minecraft:spruce_planks
setblock 78 188 278 minecraft:light[level=12]
setblock 78 188 285 minecraft:light[level=12]
setblock 78 188 292 minecraft:light[level=12]
setblock 78 188 299 minecraft:light[level=12]
setblock 78 188 306 minecraft:light[level=12]
setblock 78 188 313 minecraft:light[level=12]
setblock 79 188 275 minecraft:cyan_concrete
setblock 79 188 276 minecraft:spruce_planks
setblock 79 188 317 minecraft:blue_concrete
fill 80 188 275 80 190 275 minecraft:blue_concrete
setblock 82 188 316 minecraft:spruce_planks
setblock 83 188 275 minecraft:cyan_concrete
setblock 83 188 317 minecraft:blue_concrete
fill 84 188 275 84 190 275 minecraft:blue_concrete
setblock 85 188 278 minecraft:light[level=12]
setblock 85 188 285 minecraft:light[level=12]
setblock 85 188 292 minecraft:light[level=12]
setblock 85 188 299 minecraft:light[level=12]
setblock 85 188 306 minecraft:light[level=12]
setblock 85 188 313 minecraft:light[level=12]
fill 86 188 275 87 188 275 minecraft:cyan_concrete
setblock 86 188 276 minecraft:spruce_planks
setblock 86 188 317 minecraft:cyan_concrete
setblock 88 188 281 minecraft:spruce_planks
setblock 88 188 288 minecraft:spruce_planks
setblock 88 188 295 minecraft:spruce_planks
setblock 88 188 302 minecraft:spruce_planks
setblock 88 188 309 minecraft:spruce_planks
fill 88 188 317 89 188 317 minecraft:blue_concrete
setblock 89 188 275 minecraft:cyan_concrete
setblock 89 188 276 minecraft:blue_concrete
setblock 89 188 282 minecraft:cyan_concrete
fill 89 188 283 89 190 283 minecraft:blue_concrete
setblock 89 188 284 minecraft:light_blue_wool
fill 89 188 285 89 190 286 minecraft:blue_concrete
fill 89 188 290 89 191 290 minecraft:blue_concrete
fill 89 188 295 89 190 295 minecraft:blue_concrete
fill 89 188 298 89 190 298 minecraft:blue_concrete
setblock 89 188 300 minecraft:cyan_concrete
fill 89 188 310 89 190 310 minecraft:blue_concrete
setblock 89 188 311 minecraft:white_wool
fill 89 188 312 89 189 313 minecraft:blue_concrete
setblock 89 188 314 minecraft:cyan_concrete
fill 89 188 315 89 190 315 minecraft:blue_concrete
setblock 89 188 316 minecraft:cyan_concrete
fill 47 189 282 47 190 282 minecraft:blue_concrete
fill 47 189 284 47 190 284 minecraft:blue_concrete
fill 47 189 286 47 190 286 minecraft:blue_concrete
setblock 47 189 287 minecraft:cyan_concrete
fill 47 189 288 47 190 290 minecraft:blue_concrete
fill 47 189 297 47 190 297 minecraft:blue_concrete
fill 47 189 299 47 190 299 minecraft:blue_concrete
fill 47 189 302 47 190 302 minecraft:blue_concrete
fill 47 189 305 47 191 305 minecraft:blue_concrete
setblock 47 189 307 minecraft:cyan_concrete
fill 47 189 313 47 191 313 minecraft:blue_concrete
setblock 49 189 317 minecraft:cyan_concrete
fill 52 189 275 52 190 275 minecraft:blue_concrete
setblock 53 189 275 minecraft:cyan_concrete
fill 56 189 317 56 190 317 minecraft:blue_concrete
fill 57 189 275 57 190 275 minecraft:blue_concrete
setblock 60 189 317 minecraft:cyan_concrete
fill 62 189 317 63 189 317 minecraft:cyan_concrete
fill 65 189 277 65 200 277 minecraft:iron_bars
fill 67 189 317 67 190 317 minecraft:blue_concrete
setblock 68 189 275 minecraft:cyan_concrete
setblock 70 189 275 minecraft:cyan_concrete
fill 79 189 275 79 190 275 minecraft:blue_concrete
setblock 79 189 317 minecraft:cyan_concrete
setblock 81 189 275 minecraft:cyan_concrete
fill 82 189 275 83 190 275 minecraft:blue_concrete
setblock 83 189 317 minecraft:cyan_concrete
setblock 86 189 275 minecraft:cyan_concrete
fill 86 189 317 86 190 317 minecraft:blue_concrete
fill 87 189 275 87 190 275 minecraft:blue_concrete
setblock 88 189 317 minecraft:white_wool
fill 89 189 275 89 190 275 minecraft:blue_concrete
setblock 89 189 276 minecraft:cyan_concrete
fill 89 189 282 89 190 282 minecraft:blue_concrete
setblock 89 189 284 minecraft:cyan_concrete
setblock 89 189 292 minecraft:cyan_concrete
fill 89 189 293 89 190 294 minecraft:blue_concrete
fill 89 189 300 89 190 300 minecraft:blue_concrete
setblock 89 189 308 minecraft:cyan_concrete
fill 89 189 311 89 190 311 minecraft:blue_concrete
fill 89 189 314 89 190 314 minecraft:blue_concrete
fill 89 189 316 89 190 317 minecraft:blue_concrete
setblock 47 190 287 minecraft:blue_concrete
setblock 47 190 307 minecraft:blue_concrete
setblock 47 190 309 minecraft:blue_concrete
fill 48 190 276 48 190 279 minecraft:spruce_planks
fill 48 190 282 48 190 287 minecraft:spruce_planks
fill 48 190 289 48 190 294 minecraft:spruce_planks
fill 48 190 296 48 190 301 minecraft:spruce_planks
fill 48 190 303 48 190 308 minecraft:spruce_planks
fill 48 190 310 48 190 315 minecraft:spruce_planks
setblock 49 190 276 minecraft:spruce_planks
fill 49 190 316 54 190 316 minecraft:spruce_planks
setblock 49 190 317 minecraft:blue_concrete
fill 51 190 276 56 190 276 minecraft:spruce_planks
setblock 53 190 275 minecraft:blue_concrete
fill 56 190 316 61 190 316 minecraft:spruce_planks
fill 58 190 276 63 190 276 minecraft:spruce_planks
setblock 60 190 317 minecraft:blue_concrete
fill 62 190 317 63 190 317 minecraft:blue_concrete
fill 63 190 316 68 190 316 minecraft:spruce_planks
fill 65 190 276 70 190 276 minecraft:spruce_planks
setblock 68 190 275 minecraft:blue_concrete
fill 70 190 275 70 191 275 minecraft:blue_concrete
fill 70 190 316 75 190 316 minecraft:spruce_planks
fill 72 190 276 77 190 276 minecraft:spruce_planks
fill 77 190 316 82 190 316 minecraft:spruce_planks
fill 79 190 276 84 190 276 minecraft:spruce_planks
setblock 79 190 317 minecraft:blue_concrete
fill 81 190 275 81 191 275 minecraft:blue_concrete
setblock 83 190 317 minecraft:blue_concrete
fill 84 190 316 88 190 316 minecraft:spruce_planks
setblock 86 190 275 minecraft:blue_concrete
fill 86 190 276 88 190 276 minecraft:spruce_planks
fill 88 190 277 88 190 279 minecraft:spruce_planks
fill 88 190 281 88 190 286 minecraft:spruce_planks
fill 88 190 288 88 190 293 minecraft:spruce_planks
fill 88 190 295 88 190 300 minecraft:spruce_planks
fill 88 190 302 88 190 307 minecraft:spruce_planks
fill 88 190 309 88 190 311 minecraft:spruce_planks
fill 88 190 313 88 190 314 minecraft:spruce_planks
setblock 88 190 317 minecraft:blue_concrete
setblock 89 190 276 minecraft:blue_concrete
setblock 89 190 277 minecraft:light_blue_wool
setblock 89 190 284 minecraft:blue_concrete
setblock 89 190 292 minecraft:blue_concrete
setblock 89 190 308 minecraft:blue_concrete
setblock 89 190 312 minecraft:white_wool
setblock 89 190 313 minecraft:blue_concrete
fill 47 191 275 47 191 300 minecraft:cyan_concrete
fill 47 191 302 47 191 304 minecraft:cyan_concrete
fill 47 191 306 47 192 312 minecraft:cyan_concrete
fill 47 191 314 47 192 316 minecraft:cyan_concrete
fill 48 191 275 48 195 275 minecraft:cyan_concrete
setblock 48 191 276 minecraft:spruce_planks
fill 48 191 280 56 191 280 minecraft:spruce_log
setblock 48 191 283 minecraft:spruce_planks
setblock 48 191 290 minecraft:spruce_planks
setblock 48 191 297 minecraft:spruce_planks
setblock 48 191 304 minecraft:spruce_planks
setblock 48 191 311 minecraft:spruce_planks
fill 48 191 317 60 192 317 minecraft:cyan_concrete
fill 50 191 275 50 192 275 minecraft:cyan_concrete
setblock 50 191 316 minecraft:spruce_planks
fill 52 191 275 54 209 275 minecraft:cyan_concrete
setblock 55 191 276 minecraft:spruce_planks
fill 56 191 275 59 191 275 minecraft:cyan_concrete
setblock 57 191 316 minecraft:spruce_planks
fill 61 191 275 69 191 275 minecraft:cyan_concrete
setblock 62 191 276 minecraft:spruce_planks
fill 62 191 317 63 249 317 minecraft:cyan_concrete
setblock 64 191 316 minecraft:spruce_planks
fill 66 191 317 72 213 317 minecraft:cyan_concrete
setblock 69 191 276 minecraft:spruce_planks
fill 71 191 275 80 191 275 minecraft:cyan_concrete
setblock 71 191 316 minecraft:spruce_planks
fill 74 191 317 89 191 317 minecraft:cyan_concrete
setblock 76 191 276 minecraft:spruce_planks
setblock 78 191 316 minecraft:spruce_planks
fill 80 191 312 88 191 312 minecraft:spruce_log
fill 82 191 275 82 249 275 minecraft:cyan_concrete
setblock 83 191 275 minecraft:blue_concrete
setblock 83 191 276 minecraft:spruce_planks
fill 84 191 275 84 210 275 minecraft:cyan_concrete
setblock 85 191 316 minecraft:spruce_planks
fill 86 191 275 87 206 275 minecraft:cyan_concrete
setblock 88 191 278 minecraft:spruce_planks
setblock 88 191 285 minecraft:spruce_planks
setblock 88 191 292 minecraft:spruce_planks
setblock 88 191 299 minecraft:spruce_planks
setblock 88 191 306 minecraft:spruce_planks
setblock 88 191 313 minecraft:spruce_planks
fill 89 191 275 89 191 286 minecraft:cyan_concrete
fill 89 191 288 89 209 289 minecraft:cyan_concrete
fill 89 191 292 89 215 292 minecraft:cyan_concrete
setblock 89 191 293 minecraft:blue_concrete
fill 89 191 294 89 191 316 minecraft:cyan_concrete
fill 47 192 275 47 194 277 minecraft:cyan_concrete
fill 47 192 278 47 192 280 minecraft:blue_concrete
fill 47 192 281 47 193 284 minecraft:cyan_concrete
setblock 47 192 285 minecraft:blue_concrete
fill 47 192 286 47 195 301 minecraft:cyan_concrete
setblock 47 192 302 minecraft:blue_concrete
fill 47 192 303 47 208 305 minecraft:cyan_concrete
fill 47 192 313 47 250 313 minecraft:cyan_concrete
fill 47 192 317 47 249 317 minecraft:cyan_concrete
setblock 48 192 277 minecraft:spruce_planks
setblock 48 192 284 minecraft:spruce_planks
setblock 48 192 291 minecraft:spruce_planks
setblock 48 192 298 minecraft:spruce_planks
setblock 48 192 305 minecraft:spruce_planks
setblock 48 192 312 minecraft:spruce_planks
fill 49 192 275 49 249 275 minecraft:cyan_concrete
setblock 51 192 275 minecraft:cyan_concrete
fill 51 192 280 53 207 280 minecraft:spruce_log
setblock 51 192 316 minecraft:spruce_planks
setblock 54 192 276 minecraft:spruce_planks
fill 55 192 275 57 192 275 minecraft:cyan_concrete
setblock 58 192 275 minecraft:blue_concrete
setblock 58 192 316 minecraft:spruce_planks
fill 59 192 275 62 192 275 minecraft:cyan_concrete
setblock 61 192 276 minecraft:spruce_planks
fill 61 192 317 61 229 317 minecraft:cyan_concrete
setblock 63 192 275 minecraft:blue_concrete
fill 64 192 275 76 192 275 minecraft:cyan_concrete
fill 64 192 317 65 198 317 minecraft:cyan_concrete
setblock 65 192 316 minecraft:spruce_planks
setblock 68 192 276 minecraft:spruce_planks
setblock 72 192 316 minecraft:spruce_planks
fill 73 192 317 84 192 317 minecraft:cyan_concrete
setblock 75 192 276 minecraft:spruce_planks
setblock 77 192 275 minecraft:blue_concrete
setblock 78 192 275 minecraft:cyan_concrete
setblock 79 192 275 minecraft:blue_concrete
setblock 79 192 316 minecraft:spruce_planks
fill 80 192 275 81 218 275 minecraft:cyan_concrete
setblock 82 192 276 minecraft:spruce_planks
fill 83 192 275 83 197 275 minecraft:cyan_concrete
fill 83 192 312 85 207 312 minecraft:spruce_log
setblock 85 192 317 minecraft:blue_concrete
setblock 86 192 316 minecraft:spruce_planks
fill 86 192 317 88 192 317 minecraft:cyan_concrete
fill 88 192 275 88 197 275 minecraft:cyan_concrete
setblock 88 192 277 minecraft:spruce_planks
setblock 88 192 284 minecraft:spruce_planks
setblock 88 192 291 minecraft:spruce_planks
setblock 88 192 298 minecraft:spruce_planks
setblock 88 192 305 minecraft:spruce_planks
setblock 88 192 312 minecraft:spruce_planks
fill 89 192 275 89 193 275 minecraft:blue_concrete
fill 89 192 276 89 242 278 minecraft:cyan_concrete
setblock 89 192 279 minecraft:blue_concrete
fill 89 192 280 89 192 287 minecraft:cyan_concrete
fill 89 192 290 89 250 290 minecraft:cyan_concrete
fill 89 192 293 89 192 308 minecraft:cyan_concrete
setblock 89 192 309 minecraft:blue_concrete
fill 89 192 310 89 249 310 minecraft:cyan_concrete
setblock 89 192 311 minecraft:blue_concrete
fill 89 192 312 89 192 316 minecraft:cyan_concrete
setblock 89 192 317 minecraft:blue_concrete
fill 47 193 278 47 216 278 minecraft:cyan_concrete
setblock 47 193 279 minecraft:blue_concrete
fill 47 193 280 47 249 280 minecraft:cyan_concrete
fill 47 193 285 47 249 285 minecraft:cyan_concrete
fill 47 193 302 47 247 302 minecraft:cyan_concrete
fill 47 193 306 47 203 309 minecraft:cyan_concrete
setblock 47 193 310 minecraft:white_wool
fill 47 193 311 47 209 312 minecraft:cyan_concrete
setblock 47 193 314 minecraft:blue_concrete
fill 47 193 315 47 199 316 minecraft:cyan_concrete
setblock 48 193 278 minecraft:spruce_planks
setblock 48 193 285 minecraft:spruce_planks
setblock 48 193 292 minecraft:spruce_planks
setblock 48 193 299 minecraft:spruce_planks
setblock 48 193 306 minecraft:spruce_planks
setblock 48 193 313 minecraft:spruce_planks
fill 48 193 317 50 201 317 minecraft:cyan_concrete
setblock 50 193 275 minecraft:blue_concrete
setblock 51 193 275 minecraft:light_blue_wool
setblock 51 193 317 minecraft:blue_concrete
setblock 52 193 316 minecraft:spruce_planks
fill 52 193 317 52 249 317 minecraft:cyan_concrete
setblock 53 193 276 minecraft:spruce_planks
setblock 53 193 317 minecraft:blue_concrete
fill 54 193 317 55 249 317 minecraft:cyan_concrete
fill 55 193 275 56 236 275 minecraft:cyan_concrete
setblock 56 193 317 minecraft:blue_concrete
setblock 57 193 275 minecraft:blue_concrete
fill 57 193 317 60 193 317 minecraft:cyan_concrete
fill 58 193 275 61 202 275 minecraft:cyan_concrete
setblock 59 193 316 minecraft:spruce_planks
setblock 60 193 276 minecraft:spruce_planks
setblock 62 193 275 minecraft:blue_concrete
fill 63 193 275 63 245 275 minecraft:cyan_concrete
setblock 64 193 275 minecraft:white_wool
fill 65 193 275 77 204 275 minecraft:cyan_concrete
setblock 66 193 316 minecraft:spruce_planks
setblock 67 193 276 minecraft:spruce_planks
setblock 73 193 316 minecraft:spruce_planks
fill 73 193 317 80 217 317 minecraft:cyan_concrete
setblock 74 193 276 minecraft:spruce_planks
setblock 78 193 275 minecraft:blue_concrete
fill 79 193 275 79 246 275 minecraft:cyan_concrete
setblock 80 193 316 minecraft:spruce_planks
setblock 81 193 276 minecraft:spruce_planks
fill 81 193 279 81 193 280 minecraft:dark_oak_planks
setblock 81 193 317 minecraft:blue_concrete
setblock 82 193 278 minecraft:dark_oak_planks
setblock 82 193 281 minecraft:dark_oak_planks
fill 82 193 317 87 197 317 minecraft:cyan_concrete
fill 83 193 277 84 193 277 minecraft:dark_oak_planks
fill 84 193 281 85 193 281 minecraft:dark_oak_planks
fill 85 193 275 85 245 275 minecraft:cyan_concrete
setblock 85 193 278 minecraft:dark_oak_planks
setblock 85 193 280 minecraft:dark_oak_planks
setblock 87 193 316 minecraft:spruce_planks
setblock 88 193 276 minecraft:spruce_planks
setblock 88 193 283 minecraft:spruce_planks
setblock 88 193 290 minecraft:spruce_planks
setblock 88 193 297 minecraft:spruce_planks
setblock 88 193 304 minecraft:spruce_planks
setblock 88 193 311 minecraft:spruce_planks
setblock 88 193 317 minecraft:blue_concrete
fill 89 193 279 89 244 282 minecraft:cyan_concrete
setblock 89 193 283 minecraft:blue_concrete
fill 89 193 284 89 225 287 minecraft:cyan_concrete
fill 89 193 291 89 245 291 minecraft:cyan_concrete
fill 89 193 293 89 205 295 minecraft:cyan_concrete
setblock 89 193 296 minecraft:blue_concrete
fill 89 193 297 89 193 309 minecraft:cyan_concrete
fill 89 193 311 89 193 313 minecraft:cyan_concrete
setblock 89 193 314 minecraft:blue_concrete
setblock 89 193 315 minecraft:light_blue_wool
fill 89 193 316 89 199 317 minecraft:cyan_concrete
fill 47 194 279 47 220 279 minecraft:cyan_concrete
fill 47 194 281 47 209 283 minecraft:cyan_concrete
setblock 47 194 284 minecraft:light_blue_wool
fill 47 194 310 47 209 310 minecraft:cyan_concrete
fill 47 194 314 47 249 314 minecraft:cyan_concrete
setblock 48 194 279 minecraft:spruce_planks
setblock 48 194 286 minecraft:spruce_planks
setblock 48 194 293 minecraft:spruce_planks
setblock 48 194 300 minecraft:spruce_planks
setblock 48 194 307 minecraft:spruce_planks
setblock 48 194 314 minecraft:spruce_planks
fill 50 194 275 51 232 275 minecraft:cyan_concrete
setblock 50 194 278 minecraft:light[level=15]
setblock 50 194 285 minecraft:light[level=12]
setblock 50 194 286 minecraft:light[level=15]
setblock 50 194 292 minecraft:light[level=12]
setblock 50 194 294 minecraft:light[level=15]
setblock 50 194 299 minecraft:light[level=12]
setblock 50 194 302 minecraft:light[level=15]
setblock 50 194 306 minecraft:light[level=12]
setblock 50 194 310 minecraft:light[level=15]
setblock 50 194 313 minecraft:light[level=12]
fill 51 194 317 51 249 317 minecraft:cyan_concrete
setblock 52 194 276 minecraft:spruce_planks
setblock 53 194 316 minecraft:spruce_planks
fill 53 194 317 53 245 317 minecraft:cyan_concrete
fill 56 194 317 56 222 317 minecraft:cyan_concrete
fill 57 194 275 57 249 275 minecraft:cyan_concrete
setblock 57 194 278 minecraft:light[level=12]
setblock 57 194 285 minecraft:light[level=12]
setblock 57 194 292 minecraft:light[level=12]
setblock 57 194 299 minecraft:light[level=12]
setblock 57 194 306 minecraft:light[level=12]
setblock 57 194 313 minecraft:light[level=12]
setblock 57 194 317 minecraft:white_wool
setblock 58 194 278 minecraft:light[level=15]
setblock 58 194 286 minecraft:light[level=15]
setblock 58 194 294 minecraft:light[level=15]
setblock 58 194 302 minecraft:light[level=15]
setblock 58 194 310 minecraft:light[level=15]
fill 58 194 317 60 214 317 minecraft:cyan_concrete
setblock 59 194 276 minecraft:spruce_planks
setblock 60 194 316 minecraft:spruce_planks
fill 62 194 275 62 249 275 minecraft:cyan_concrete
fill 64 194 275 64 249 275 minecraft:cyan_concrete
setblock 64 194 278 minecraft:light[level=12]
setblock 64 194 285 minecraft:light[level=12]
setblock 64 194 292 minecraft:light[level=12]
setblock 64 194 299 minecraft:light[level=12]
setblock 64 194 306 minecraft:light[level=12]
setblock 64 194 313 minecraft:light[level=12]
setblock 66 194 276 minecraft:spruce_planks
setblock 66 194 278 minecraft:light[level=15]
setblock 66 194 286 minecraft:light[level=15]
setblock 66 194 294 minecraft:light[level=15]
setblock 66 194 302 minecraft:light[level=15]
setblock 66 194 310 minecraft:light[level=15]
setblock 67 194 316 minecraft:spruce_planks
setblock 71 194 278 minecraft:light[level=12]
setblock 71 194 285 minecraft:light[level=12]
setblock 71 194 292 minecraft:light[level=12]
setblock 71 194 299 minecraft:light[level=12]
setblock 71 194 306 minecraft:light[level=12]
setblock 71 194 313 minecraft:light[level=12]
setblock 73 194 276 minecraft:spruce_planks
setblock 74 194 278 minecraft:light[level=15]
setblock 74 194 286 minecraft:light[level=15]
setblock 74 194 294 minecraft:light[level=15]
setblock 74 194 302 minecraft:light[level=15]
setblock 74 194 310 minecraft:light[level=15]
setblock 74 194 316 minecraft:spruce_planks
fill 78 194 275 78 242 275 minecraft:cyan_concrete
setblock 78 194 278 minecraft:light[level=12]
setblock 78 194 285 minecraft:light[level=12]
setblock 78 194 292 minecraft:light[level=12]
setblock 78 194 299 minecraft:light[level=12]
setblock 78 194 306 minecraft:light[level=12]
setblock 78 194 313 minecraft:light[level=12]
setblock 80 194 276 minecraft:spruce_planks
setblock 81 194 316 minecraft:spruce_planks
fill 81 194 317 81 249 317 minecraft:cyan_concrete
setblock 82 194 278 minecraft:light[level=15]
setblock 82 194 286 minecraft:light[level=15]
setblock 82 194 294 minecraft:light[level=15]
setblock 82 194 302 minecraft:light[level=15]
setblock 82 194 310 minecraft:light[level=15]
setblock 85 194 278 minecraft:light[level=12]
setblock 85 194 285 minecraft:light[level=12]
setblock 85 194 292 minecraft:light[level=12]
setblock 85 194 299 minecraft:light[level=12]
setblock 85 194 306 minecraft:light[level=12]
setblock 85 194 313 minecraft:light[level=12]
setblock 87 194 276 minecraft:spruce_planks
setblock 88 194 282 minecraft:spruce_planks
setblock 88 194 289 minecraft:spruce_planks
setblock 88 194 296 minecraft:spruce_planks
setblock 88 194 303 minecraft:spruce_planks
setblock 88 194 310 minecraft:spruce_planks
setblock 88 194 316 minecraft:spruce_planks
fill 88 194 317 88 249 317 minecraft:cyan_concrete
fill 89 194 275 89 246 275 minecraft:cyan_concrete
fill 89 194 283 89 245 283 minecraft:cyan_concrete
fill 89 194 296 89 194 307 minecraft:cyan_concrete
setblock 89 194 308 minecraft:white_wool
fill 89 194 309 89 247 309 minecraft:cyan_concrete
fill 89 194 311 89 203 311 minecraft:cyan_concrete
setblock 89 194 312 minecraft:white_wool
fill 89 194 313 89 203 315 minecraft:cyan_concrete
fill 47 195 275 47 225 276 minecraft:cyan_concrete
setblock 47 195 277 minecraft:white_wool
fill 47 195 284 47 245 284 minecraft:cyan_concrete
setblock 48 195 280 minecraft:spruce_planks
setblock 48 195 287 minecraft:spruce_planks
setblock 48 195 294 minecraft:spruce_planks
setblock 48 195 301 minecraft:spruce_planks
setblock 48 195 308 minecraft:spruce_planks
setblock 48 195 315 minecraft:spruce_planks
setblock 51 195 276 minecraft:spruce_planks
setblock 54 195 316 minecraft:spruce_planks
fill 57 195 317 57 206 317 minecraft:cyan_concrete
setblock 58 195 276 minecraft:spruce_planks
setblock 61 195 316 minecraft:spruce_planks
setblock 65 195 276 minecraft:spruce_planks
setblock 68 195 316 minecraft:spruce_planks
setblock 72 195 276 minecraft:spruce_planks
setblock 75 195 316 minecraft:spruce_planks
setblock 79 195 276 minecraft:spruce_planks
setblock 82 195 316 minecraft:spruce_planks
setblock 86 195 276 minecraft:spruce_planks
setblock 88 195 281 minecraft:spruce_planks
setblock 88 195 288 minecraft:spruce_planks
setblock 88 195 295 minecraft:spruce_planks
setblock 88 195 302 minecraft:spruce_planks
setblock 88 195 309 minecraft:spruce_planks
fill 89 195 296 89 195 306 minecraft:cyan_concrete
setblock 89 195 307 minecraft:white_wool
fill 89 195 308 89 234 308 minecraft:cyan_concrete
fill 89 195 312 89 220 312 minecraft:cyan_concrete
fill 47 196 277 47 249 277 minecraft:cyan_concrete
fill 47 196 286 47 196 297 minecraft:cyan_concrete
setblock 47 196 298 minecraft:light_blue_wool
fill 47 196 299 47 219 301 minecraft:cyan_concrete
setblock 48 196 275 minecraft:light_blue_wool
fill 89 196 296 89 219 298 minecraft:cyan_concrete
setblock 89 196 299 minecraft:white_wool
fill 89 196 300 89 214 307 minecraft:cyan_concrete
fill 47 197 286 47 237 286 minecraft:cyan_concrete
setblock 47 197 287 minecraft:white_wool
fill 47 197 288 47 204 298 minecraft:cyan_concrete
fill 48 197 275 48 245 275 minecraft:cyan_concrete
setblock 48 197 282 minecraft:spruce_planks
setblock 48 197 289 minecraft:spruce_planks
setblock 48 197 296 minecraft:spruce_planks
setblock 48 197 303 minecraft:spruce_planks
setblock 48 197 310 minecraft:spruce_planks
setblock 49 197 276 minecraft:spruce_planks
setblock 49 197 316 minecraft:spruce_planks
setblock 56 197 276 minecraft:spruce_planks
setblock 56 197 316 minecraft:spruce_planks
setblock 63 197 276 minecraft:spruce_planks
setblock 63 197 316 minecraft:spruce_planks
setblock 70 197 276 minecraft:spruce_planks
fill 70 197 311 70 200 311 minecraft:iron_bars
setblock 70 197 316 minecraft:spruce_planks
setblock 77 197 276 minecraft:spruce_planks
setblock 77 197 316 minecraft:spruce_planks
setblock 84 197 276 minecraft:spruce_planks
setblock 84 197 316 minecraft:spruce_planks
setblock 88 197 279 minecraft:spruce_planks
setblock 88 197 286 minecraft:spruce_planks
setblock 88 197 293 minecraft:spruce_planks
setblock 88 197 300 minecraft:spruce_planks
setblock 88 197 307 minecraft:spruce_planks
setblock 88 197 314 minecraft:spruce_planks
fill 89 197 299 89 231 299 minecraft:cyan_concrete
fill 47 198 287 47 205 287 minecraft:cyan_concrete
setblock 48 198 276 minecraft:spruce_planks
setblock 48 198 283 minecraft:spruce_planks
setblock 48 198 290 minecraft:spruce_planks
setblock 48 198 297 minecraft:spruce_planks
setblock 48 198 304 minecraft:spruce_planks
setblock 48 198 311 minecraft:spruce_planks
setblock 50 198 316 minecraft:spruce_planks
setblock 55 198 276 minecraft:spruce_planks
setblock 57 198 316 minecraft:spruce_planks
setblock 62 198 276 minecraft:spruce_planks
setblock 64 198 316 minecraft:spruce_planks
setblock 69 198 276 minecraft:spruce_planks
setblock 71 198 316 minecraft:spruce_planks
setblock 76 198 276 minecraft:spruce_planks
setblock 78 198 316 minecraft:spruce_planks
fill 82 198 317 82 204 317 minecraft:cyan_concrete
setblock 83 198 275 minecraft:white_wool
setblock 83 198 276 minecraft:spruce_planks
setblock 83 198 317 minecraft:white_wool
fill 84 198 317 87 198 317 minecraft:cyan_concrete
setblock 85 198 316 minecraft:spruce_planks
setblock 88 198 275 minecraft:light_blue_wool
setblock 88 198 278 minecraft:spruce_planks
setblock 88 198 285 minecraft:spruce_planks
setblock 88 198 292 minecraft:spruce_planks
setblock 88 198 299 minecraft:spruce_planks
setblock 88 198 306 minecraft:spruce_planks
setblock 88 198 313 minecraft:spruce_planks
fill 48 199 277 48 200 277 minecraft:spruce_planks
fill 48 199 284 48 200 284 minecraft:spruce_planks
fill 48 199 291 48 200 291 minecraft:spruce_planks
fill 48 199 298 48 200 298 minecraft:spruce_planks
fill 48 199 305 48 200 305 minecraft:spruce_planks
fill 48 199 312 48 200 312 minecraft:spruce_planks
fill 51 199 316 51 200 316 minecraft:spruce_planks
fill 54 199 276 54 200 276 minecraft:spruce_planks
fill 58 199 316 58 200 316 minecraft:spruce_planks
fill 61 199 276 61 200 276 minecraft:spruce_planks
setblock 64 199 317 minecraft:light_blue_wool
fill 65 199 316 65 200 316 minecraft:spruce_planks
fill 65 199 317 65 246 317 minecraft:cyan_concrete
fill 68 199 276 68 200 276 minecraft:spruce_planks
fill 72 199 316 72 200 316 minecraft:spruce_planks
fill 75 199 276 75 200 276 minecraft:spruce_planks
fill 79 199 316 79 200 316 minecraft:spruce_planks
fill 82 199 276 82 200 276 minecraft:spruce_planks
fill 83 199 275 83 249 275 minecraft:cyan_concrete
fill 83 199 317 83 227 317 minecraft:cyan_concrete
setblock 84 199 317 minecraft:white_wool
fill 85 199 317 87 227 317 minecraft:cyan_concrete
fill 86 199 316 86 200 316 minecraft:spruce_planks
fill 88 199 275 88 249 275 minecraft:cyan_concrete
fill 88 199 277 88 200 277 minecraft:spruce_planks
fill 88 199 284 88 200 284 minecraft:spruce_planks
fill 88 199 291 88 200 291 minecraft:spruce_planks
fill 88 199 298 88 200 298 minecraft:spruce_planks
fill 88 199 305 88 200 305 minecraft:spruce_planks
fill 88 199 312 88 200 312 minecraft:spruce_planks
fill 47 200 315 47 232 315 minecraft:cyan_concrete
setblock 47 200 316 minecraft:white_wool
fill 48 200 276 49 200 276 minecraft:spruce_planks
fill 48 200 278 48 200 280 minecraft:spruce_planks
fill 48 200 282 48 200 283 minecraft:spruce_planks
fill 48 200 285 48 200 287 minecraft:spruce_planks
fill 48 200 289 48 200 290 minecraft:spruce_planks
fill 48 200 292 48 200 294 minecraft:spruce_planks
fill 48 200 296 48 200 297 minecraft:spruce_planks
fill 48 200 299 48 200 301 minecraft:spruce_planks
fill 48 200 303 48 200 304 minecraft:spruce_planks
fill 48 200 306 48 200 308 minecraft:spruce_planks
fill 48 200 310 48 200 311 minecraft:spruce_planks
fill 48 200 313 48 200 315 minecraft:spruce_planks
fill 49 200 299 49 208 299 minecraft:white_wool
fill 49 200 316 50 200 316 minecraft:spruce_planks
setblock 50 200 278 minecraft:light[level=12]
setblock 50 200 285 minecraft:light[level=12]
setblock 50 200 292 minecraft:light[level=12]
setblock 50 200 299 minecraft:light[level=12]
setblock 50 200 306 minecraft:light[level=12]
setblock 50 200 313 minecraft:light[level=12]
fill 51 200 276 53 200 276 minecraft:spruce_planks
fill 52 200 316 54 200 316 minecraft:spruce_planks
fill 55 200 276 56 200 276 minecraft:spruce_planks
fill 56 200 316 57 200 316 minecraft:spruce_planks
setblock 57 200 278 minecraft:light[level=12]
setblock 57 200 285 minecraft:light[level=12]
setblock 57 200 292 minecraft:light[level=12]
setblock 57 200 299 minecraft:light[level=12]
setblock 57 200 306 minecraft:light[level=12]
setblock 57 200 313 minecraft:light[level=12]
fill 58 200 276 60 200 276 minecraft:spruce_planks
fill 59 200 316 61 200 316 minecraft:spruce_planks
fill 62 200 276 63 200 276 minecraft:spruce_planks
fill 63 200 316 64 200 316 minecraft:spruce_planks
setblock 64 200 278 minecraft:light[level=12]
setblock 64 200 285 minecraft:light[level=12]
setblock 64 200 292 minecraft:light[level=12]
setblock 64 200 299 minecraft:light[level=12]
setblock 64 200 306 minecraft:light[level=12]
setblock 64 200 313 minecraft:light[level=12]
fill 64 200 317 64 228 317 minecraft:cyan_concrete
fill 65 200 276 67 200 276 minecraft:spruce_planks
fill 66 200 316 68 200 316 minecraft:spruce_planks
fill 69 200 276 70 200 276 minecraft:spruce_planks
fill 70 200 316 71 200 316 minecraft:spruce_planks
setblock 71 200 278 minecraft:light[level=12]
setblock 71 200 285 minecraft:light[level=12]
setblock 71 200 292 minecraft:light[level=12]
setblock 71 200 299 minecraft:light[level=12]
setblock 71 200 306 minecraft:light[level=12]
setblock 71 200 313 minecraft:light[level=12]
fill 72 200 276 74 200 276 minecraft:spruce_planks
fill 73 200 316 75 200 316 minecraft:spruce_planks
fill 76 200 276 77 200 276 minecraft:spruce_planks
fill 77 200 316 78 200 316 minecraft:spruce_planks
setblock 78 200 278 minecraft:light[level=12]
setblock 78 200 285 minecraft:light[level=12]
setblock 78 200 292 minecraft:light[level=12]
setblock 78 200 299 minecraft:light[level=12]
setblock 78 200 306 minecraft:light[level=12]
setblock 78 200 313 minecraft:light[level=12]
fill 79 200 276 81 200 276 minecraft:spruce_planks
fill 80 200 316 82 200 316 minecraft:spruce_planks
fill 83 200 276 84 200 276 minecraft:spruce_planks
fill 84 200 316 85 200 316 minecraft:spruce_planks
fill 84 200 317 84 249 317 minecraft:cyan_concrete
setblock 85 200 278 minecraft:light[level=12]
setblock 85 200 285 minecraft:light[level=12]
setblock 85 200 292 minecraft:light[level=12]
setblock 85 200 299 minecraft:light[level=12]
setblock 85 200 306 minecraft:light[level=12]
setblock 85 200 313 minecraft:light[level=12]
fill 86 200 276 88 200 276 minecraft:spruce_planks
fill 87 200 316 88 200 316 minecraft:spruce_planks
fill 88 200 278 88 200 279 minecraft:spruce_planks
fill 88 200 281 88 200 283 minecraft:spruce_planks
fill 88 200 285 88 200 286 minecraft:spruce_planks
fill 88 200 288 88 200 290 minecraft:spruce_planks
fill 88 200 292 88 200 293 minecraft:spruce_planks
fill 88 200 295 88 200 297 minecraft:spruce_planks
fill 88 200 299 88 200 300 minecraft:spruce_planks
fill 88 200 302 88 200 304 minecraft:spruce_planks
fill 88 200 306 88 200 307 minecraft:spruce_planks
fill 88 200 309 88 200 311 minecraft:spruce_planks
fill 88 200 313 88 200 314 minecraft:spruce_planks
setblock 89 200 316 minecraft:light_blue_wool
fill 89 200 317 89 247 317 minecraft:cyan_concrete
fill 47 201 316 47 202 316 minecraft:cyan_concrete
setblock 48 201 279 minecraft:spruce_planks
setblock 48 201 286 minecraft:spruce_planks
setblock 48 201 293 minecraft:spruce_planks
setblock 48 201 300 minecraft:spruce_planks
setblock 48 201 307 minecraft:spruce_planks
setblock 48 201 314 minecraft:spruce_planks
fill 49 201 297 49 208 298 minecraft:white_wool
fill 49 201 300 49 208 301 minecraft:white_wool
setblock 52 201 276 minecraft:spruce_planks
setblock 53 201 316 minecraft:spruce_planks
setblock 59 201 276 minecraft:spruce_planks
setblock 60 201 316 minecraft:spruce_planks
setblock 66 201 276 minecraft:spruce_planks
fill 67 201 311 73 201 315 minecraft:dark_oak_planks
setblock 67 201 316 minecraft:spruce_planks
setblock 73 201 276 minecraft:spruce_planks
setblock 74 201 316 minecraft:spruce_planks
setblock 80 201 276 minecraft:spruce_planks
fill 81 201 279 81 201 280 minecraft:dark_oak_planks
setblock 81 201 316 minecraft:spruce_planks
setblock 82 201 278 minecraft:dark_oak_planks
setblock 82 201 281 minecraft:dark_oak_planks
fill 83 201 277 84 201 277 minecraft:dark_oak_planks
fill 84 201 281 85 201 281 minecraft:dark_oak_planks
setblock 85 201 278 minecraft:dark_oak_planks
setblock 85 201 280 minecraft:dark_oak_planks
setblock 87 201 276 minecraft:spruce_planks
setblock 88 201 282 minecraft:spruce_planks
setblock 88 201 289 minecraft:spruce_planks
setblock 88 201 296 minecraft:spruce_planks
setblock 88 201 303 minecraft:spruce_planks
setblock 88 201 310 minecraft:spruce_planks
setblock 88 201 316 minecraft:spruce_planks
fill 89 201 316 89 209 316 minecraft:cyan_concrete
setblock 48 202 280 minecraft:spruce_planks
setblock 48 202 287 minecraft:spruce_planks
setblock 48 202 294 minecraft:spruce_planks
setblock 48 202 301 minecraft:spruce_planks
setblock 48 202 308 minecraft:spruce_planks
setblock 48 202 315 minecraft:spruce_planks
fill 48 202 317 48 245 317 minecraft:cyan_concrete
setblock 49 202 317 minecraft:light_blue_wool
setblock 50 202 278 minecraft:light[level=15]
setblock 50 202 286 minecraft:light[level=15]
setblock 50 202 294 minecraft:light[level=15]
setblock 50 202 302 minecraft:light[level=15]
setblock 50 202 310 minecraft:light[level=15]
fill 50 202 317 50 246 317 minecraft:cyan_concrete
setblock 51 202 276 minecraft:spruce_planks
fill 53 202 314 59 203 314 minecraft:iron_bars
setblock 54 202 316 minecraft:spruce_planks
setblock 58 202 276 minecraft:spruce_planks
setblock 58 202 278 minecraft:light[level=15]
setblock 58 202 286 minecraft:light[level=15]
setblock 58 202 294 minecraft:light[level=15]
setblock 58 202 302 minecraft:light[level=15]
setblock 58 202 310 minecraft:light[level=15]
setblock 61 202 316 minecraft:spruce_planks
setblock 65 202 276 minecraft:spruce_planks
setblock 66 202 278 minecraft:light[level=15]
setblock 66 202 286 minecraft:light[level=15]
setblock 66 202 294 minecraft:light[level=15]
setblock 66 202 302 minecraft:light[level=15]
setblock 66 202 310 minecraft:light[level=15]
fill 67 202 311 73 202 315 minecraft:spruce_planks
setblock 68 202 316 minecraft:spruce_planks
setblock 72 202 276 minecraft:spruce_planks
setblock 74 202 278 minecraft:light[level=15]
setblock 74 202 286 minecraft:light[level=15]
setblock 74 202 294 minecraft:light[level=15]
setblock 74 202 302 minecraft:light[level=15]
setblock 74 202 310 minecraft:light[level=15]
setblock 75 202 316 minecraft:spruce_planks
setblock 79 202 276 minecraft:spruce_planks
setblock 82 202 278 minecraft:light[level=15]
setblock 82 202 286 minecraft:light[level=15]
setblock 82 202 294 minecraft:light[level=15]
setblock 82 202 302 minecraft:light[level=15]
setblock 82 202 310 minecraft:light[level=15]
setblock 82 202 316 minecraft:spruce_planks
setblock 86 202 276 minecraft:spruce_planks
setblock 88 202 281 minecraft:spruce_planks
setblock 88 202 288 minecraft:spruce_planks
setblock 88 202 295 minecraft:spruce_planks
setblock 88 202 302 minecraft:spruce_planks
setblock 88 202 309 minecraft:spruce_planks
setblock 47 203 316 minecraft:light_blue_wool
fill 49 203 317 49 240 317 minecraft:cyan_concrete
fill 58 203 275 59 209 275 minecraft:cyan_concrete
setblock 60 203 275 minecraft:white_wool
fill 61 203 275 61 205 275 minecraft:cyan_concrete
fill 67 203 311 73 203 311 minecraft:dark_oak_planks
fill 69 203 316 71 206 316 minecraft:shroomlight
fill 47 204 306 47 246 306 minecraft:cyan_concrete
setblock 47 204 307 minecraft:white_wool
fill 47 204 308 47 232 309 minecraft:cyan_concrete
fill 47 204 316 47 249 316 minecraft:cyan_concrete
setblock 48 204 282 minecraft:spruce_planks
setblock 48 204 289 minecraft:spruce_planks
setblock 48 204 296 minecraft:spruce_planks
setblock 48 204 303 minecraft:spruce_planks
setblock 48 204 310 minecraft:spruce_planks
setblock 49 204 276 minecraft:spruce_planks
setblock 49 204 316 minecraft:spruce_planks
setblock 56 204 276 minecraft:spruce_planks
setblock 56 204 316 minecraft:spruce_planks
fill 60 204 275 60 249 275 minecraft:cyan_concrete
setblock 63 204 276 minecraft:spruce_planks
setblock 63 204 316 minecraft:spruce_planks
setblock 67 204 311 minecraft:spruce_planks
setblock 70 204 276 minecraft:spruce_planks
setblock 70 204 311 minecraft:spruce_planks
setblock 73 204 311 minecraft:spruce_planks
setblock 77 204 276 minecraft:spruce_planks
setblock 77 204 316 minecraft:spruce_planks
setblock 84 204 276 minecraft:spruce_planks
setblock 84 204 316 minecraft:spruce_planks
setblock 88 204 279 minecraft:spruce_planks
setblock 88 204 286 minecraft:spruce_planks
setblock 88 204 293 minecraft:spruce_planks
setblock 88 204 300 minecraft:spruce_planks
setblock 88 204 307 minecraft:spruce_planks
setblock 88 204 314 minecraft:spruce_planks
setblock 89 204 311 minecraft:white_wool
setblock 89 204 313 minecraft:light_blue_wool
fill 89 204 314 89 249 315 minecraft:cyan_concrete
fill 47 205 288 47 212 292 minecraft:cyan_concrete
setblock 47 205 293 minecraft:white_wool
fill 47 205 294 47 208 298 minecraft:cyan_concrete
fill 47 205 307 47 249 307 minecraft:cyan_concrete
setblock 48 205 276 minecraft:spruce_planks
setblock 48 205 283 minecraft:spruce_planks
setblock 48 205 290 minecraft:spruce_planks
setblock 48 205 297 minecraft:spruce_planks
setblock 48 205 304 minecraft:spruce_planks
setblock 48 205 311 minecraft:spruce_planks
setblock 50 205 316 minecraft:spruce_planks
setblock 55 205 276 minecraft:spruce_planks
setblock 57 205 316 minecraft:spruce_planks
setblock 62 205 276 minecraft:spruce_planks
setblock 64 205 316 minecraft:spruce_planks
fill 65 205 275 67 205 275 minecraft:cyan_concrete
setblock 68 205 275 minecraft:light_blue_wool
fill 69 205 275 77 205 275 minecraft:cyan_concrete
setblock 69 205 276 minecraft:spruce_planks
setblock 76 205 276 minecraft:spruce_planks
setblock 78 205 316 minecraft:spruce_planks
setblock 82 205 317 minecraft:light_blue_wool
setblock 83 205 276 minecraft:spruce_planks
setblock 85 205 316 minecraft:spruce_planks
setblock 88 205 278 minecraft:spruce_planks
setblock 88 205 285 minecraft:spruce_planks
setblock 88 205 292 minecraft:spruce_planks
setblock 88 205 299 minecraft:spruce_planks
setblock 88 205 306 minecraft:spruce_planks
setblock 88 205 313 minecraft:spruce_planks
fill 89 205 311 89 214 311 minecraft:cyan_concrete
fill 89 205 313 89 245 313 minecraft:cyan_concrete
setblock 47 206 287 minecraft:white_wool
fill 47 206 293 47 249 293 minecraft:cyan_concrete
setblock 48 206 277 minecraft:spruce_planks
setblock 48 206 284 minecraft:spruce_planks
setblock 48 206 291 minecraft:spruce_planks
setblock 48 206 298 minecraft:spruce_planks
setblock 48 206 305 minecraft:spruce_planks
setblock 48 206 312 minecraft:spruce_planks
setblock 50 206 278 minecraft:light[level=12]
setblock 50 206 285 minecraft:light[level=12]
setblock 50 206 292 minecraft:light[level=12]
setblock 50 206 299 minecraft:light[level=12]
setblock 50 206 306 minecraft:light[level=12]
setblock 50 206 313 minecraft:light[level=12]
setblock 51 206 316 minecraft:spruce_planks
setblock 54 206 276 minecraft:spruce_planks
setblock 57 206 278 minecraft:light[level=12]
setblock 57 206 285 minecraft:light[level=12]
setblock 57 206 292 minecraft:light[level=12]
setblock 57 206 299 minecraft:light[level=12]
setblock 57 206 306 minecraft:light[level=12]
setblock 57 206 313 minecraft:light[level=12]
setblock 58 206 316 minecraft:spruce_planks
setblock 61 206 275 minecraft:white_wool
setblock 61 206 276 minecraft:spruce_planks
setblock 64 206 278 minecraft:light[level=12]
setblock 64 206 285 minecraft:light[level=12]
setblock 64 206 292 minecraft:light[level=12]
setblock 64 206 299 minecraft:light[level=12]
setblock 64 206 306 minecraft:light[level=12]
setblock 64 206 313 minecraft:light[level=12]
fill 65 206 275 65 249 275 minecraft:cyan_concrete
setblock 65 206 316 minecraft:spruce_planks
setblock 66 206 275 minecraft:light_blue_wool
fill 67 206 275 73 222 275 minecraft:cyan_concrete
setblock 68 206 276 minecraft:spruce_planks
setblock 71 206 278 minecraft:light[level=12]
setblock 71 206 285 minecraft:light[level=12]
setblock 71 206 292 minecraft:light[level=12]
setblock 71 206 299 minecraft:light[level=12]
setblock 71 206 306 minecraft:light[level=12]
setblock 71 206 313 minecraft:light[level=12]
setblock 72 206 316 minecraft:spruce_planks
setblock 74 206 275 minecraft:light_blue_wool
fill 75 206 275 77 231 275 minecraft:cyan_concrete
setblock 75 206 276 minecraft:spruce_planks
setblock 78 206 278 minecraft:light[level=12]
setblock 78 206 285 minecraft:light[level=12]
setblock 78 206 292 minecraft:light[level=12]
setblock 78 206 299 minecraft:light[level=12]
setblock 78 206 306 minecraft:light[level=12]
setblock 78 206 313 minecraft:light[level=12]
setblock 79 206 316 minecraft:spruce_planks
setblock 82 206 276 minecraft:spruce_planks
fill 82 206 317 82 211 317 minecraft:cyan_concrete
setblock 85 206 278 minecraft:light[level=12]
setblock 85 206 285 minecraft:light[level=12]
setblock 85 206 292 minecraft:light[level=12]
setblock 85 206 299 minecraft:light[level=12]
setblock 85 206 306 minecraft:light[level=12]
setblock 85 206 313 minecraft:light[level=12]
setblock 86 206 316 minecraft:spruce_planks
setblock 88 206 277 minecraft:spruce_planks
setblock 88 206 284 minecraft:spruce_planks
setblock 88 206 291 minecraft:spruce_planks
setblock 88 206 298 minecraft:spruce_planks
setblock 88 206 305 minecraft:spruce_planks
setblock 88 206 312 minecraft:spruce_planks
fill 89 206 293 89 218 294 minecraft:cyan_concrete
setblock 89 206 295 minecraft:white_wool
fill 47 207 287 47 247 287 minecraft:cyan_concrete
setblock 48 207 278 minecraft:spruce_planks
setblock 48 207 285 minecraft:spruce_planks
setblock 48 207 292 minecraft:spruce_planks
setblock 48 207 299 minecraft:spruce_planks
setblock 48 207 306 minecraft:spruce_planks
setblock 48 207 313 minecraft:spruce_planks
setblock 52 207 316 minecraft:spruce_planks
setblock 53 207 276 minecraft:spruce_planks
fill 54 207 312 54 216 312 minecraft:iron_bars
setblock 57 207 317 minecraft:light_blue_wool
setblock 59 207 316 minecraft:spruce_planks
setblock 60 207 276 minecraft:spruce_planks
fill 61 207 275 61 249 275 minecraft:cyan_concrete
fill 66 207 275 66 249 275 minecraft:cyan_concrete
setblock 66 207 316 minecraft:spruce_planks
setblock 67 207 276 minecraft:spruce_planks
fill 69 207 316 69 219 316 minecraft:spruce_planks
setblock 73 207 316 minecraft:spruce_planks
fill 74 207 275 74 210 275 minecraft:cyan_concrete
setblock 74 207 276 minecraft:spruce_planks
setblock 80 207 316 minecraft:spruce_planks
setblock 81 207 276 minecraft:spruce_planks
fill 86 207 275 86 245 275 minecraft:cyan_concrete
setblock 87 207 275 minecraft:light_blue_wool
setblock 87 207 316 minecraft:spruce_planks
setblock 88 207 276 minecraft:spruce_planks
setblock 88 207 283 minecraft:spruce_planks
setblock 88 207 290 minecraft:spruce_planks
setblock 88 207 297 minecraft:spruce_planks
setblock 88 207 304 minecraft:spruce_planks
setblock 88 207 311 minecraft:spruce_planks
fill 89 207 295 89 249 295 minecraft:cyan_concrete
setblock 48 208 279 minecraft:spruce_planks
fill 48 208 280 56 214 280 minecraft:white_wool
setblock 48 208 286 minecraft:spruce_planks
setblock 48 208 293 minecraft:spruce_planks
setblock 48 208 300 minecraft:spruce_planks
setblock 48 208 307 minecraft:spruce_planks
setblock 48 208 314 minecraft:spruce_planks
setblock 52 208 276 minecraft:spruce_planks
setblock 53 208 316 minecraft:spruce_planks
fill 57 208 317 57 238 317 minecraft:cyan_concrete
setblock 59 208 276 minecraft:spruce_planks
setblock 60 208 316 minecraft:spruce_planks
setblock 66 208 276 minecraft:spruce_planks
setblock 67 208 316 minecraft:spruce_planks
setblock 73 208 276 minecraft:spruce_planks
setblock 74 208 316 minecraft:spruce_planks
setblock 80 208 276 minecraft:spruce_planks
fill 80 208 312 88 214 312 minecraft:white_wool
setblock 81 208 316 minecraft:spruce_planks
fill 87 208 275 87 214 275 minecraft:cyan_concrete
setblock 87 208 276 minecraft:spruce_planks
setblock 88 208 282 minecraft:spruce_planks
setblock 88 208 289 minecraft:spruce_planks
setblock 88 208 296 minecraft:spruce_planks
setblock 88 208 303 minecraft:spruce_planks
setblock 88 208 310 minecraft:spruce_planks
setblock 88 208 316 minecraft:spruce_planks
fill 47 209 294 47 209 297 minecraft:cyan_concrete
setblock 47 209 298 minecraft:white_wool
fill 47 209 303 47 247 303 minecraft:cyan_concrete
setblock 47 209 304 minecraft:white_wool
fill 47 209 305 47 249 305 minecraft:cyan_concrete
fill 48 209 287 48 210 287 minecraft:spruce_planks
fill 48 209 294 48 210 294 minecraft:spruce_planks
fill 48 209 301 48 210 301 minecraft:spruce_planks
fill 48 209 308 48 210 308 minecraft:spruce_planks
fill 48 209 315 48 210 315 minecraft:spruce_planks
fill 49 209 296 49 210 302 minecraft:iron_bars
fill 51 209 276 51 210 276 minecraft:spruce_planks
fill 54 209 316 54 210 316 minecraft:spruce_planks
fill 58 209 276 58 210 276 minecraft:spruce_planks
fill 61 209 316 61 210 316 minecraft:spruce_planks
fill 62 209 280 63 209 280 minecraft:white_concrete
fill 65 209 276 65 210 276 minecraft:spruce_planks
fill 68 209 316 68 210 316 minecraft:spruce_planks
fill 72 209 276 72 210 276 minecraft:spruce_planks
fill 75 209 316 75 210 316 minecraft:spruce_planks
fill 79 209 276 79 210 276 minecraft:spruce_planks
fill 81 209 279 81 209 280 minecraft:dark_oak_planks
setblock 82 209 278 minecraft:dark_oak_planks
setblock 82 209 281 minecraft:dark_oak_planks
fill 82 209 316 82 210 316 minecraft:spruce_planks
fill 83 209 277 84 209 277 minecraft:dark_oak_planks
fill 84 209 281 85 209 281 minecraft:dark_oak_planks
setblock 85 209 278 minecraft:dark_oak_planks
setblock 85 209 280 minecraft:dark_oak_planks
fill 86 209 276 86 210 276 minecraft:spruce_planks
fill 88 209 281 88 210 281 minecraft:spruce_planks
fill 88 209 288 88 210 288 minecraft:spruce_planks
fill 88 209 295 88 210 295 minecraft:spruce_planks
fill 88 209 302 88 210 302 minecraft:spruce_planks
fill 88 209 309 88 210 309 minecraft:spruce_planks
setblock 47 210 281 minecraft:white_wool
fill 47 210 282 47 245 283 minecraft:cyan_concrete
fill 47 210 294 47 230 296 minecraft:cyan_concrete
setblock 47 210 297 minecraft:light_blue_wool
fill 47 210 298 47 231 298 minecraft:cyan_concrete
fill 47 210 304 47 249 304 minecraft:cyan_concrete
setblock 47 210 310 minecraft:white_wool
setblock 47 210 311 minecraft:light_blue_wool
fill 47 210 312 47 235 312 minecraft:cyan_concrete
fill 48 210 276 48 210 279 minecraft:spruce_planks
fill 48 210 282 48 210 286 minecraft:spruce_planks
fill 48 210 289 48 210 293 minecraft:spruce_planks
fill 48 210 296 48 210 300 minecraft:spruce_planks
fill 48 210 303 48 210 307 minecraft:spruce_planks
fill 48 210 310 48 210 314 minecraft:spruce_planks
fill 49 210 276 49 211 276 minecraft:spruce_planks
fill 49 210 316 53 210 316 minecraft:spruce_planks
setblock 50 210 278 minecraft:light[level=15]
setblock 50 210 286 minecraft:light[level=15]
setblock 50 210 294 minecraft:light[level=15]
setblock 50 210 302 minecraft:light[level=15]
setblock 50 210 310 minecraft:light[level=15]
fill 51 210 278 51 211 278 minecraft:dark_oak_planks
fill 51 210 292 51 211 292 minecraft:dark_oak_planks
fill 51 210 297 51 211 297 minecraft:dark_oak_planks
fill 52 210 275 52 249 275 minecraft:cyan_concrete
fill 52 210 276 56 210 276 minecraft:spruce_planks
setblock 53 210 275 minecraft:light_blue_wool
fill 54 210 275 54 249 275 minecraft:cyan_concrete
fill 56 210 316 60 210 316 minecraft:spruce_planks
fill 58 210 275 58 249 275 minecraft:cyan_concrete
setblock 58 210 278 minecraft:light[level=15]
setblock 58 210 286 minecraft:light[level=15]
setblock 58 210 294 minecraft:light[level=15]
setblock 58 210 302 minecraft:light[level=15]
setblock 58 210 310 minecraft:light[level=15]
setblock 59 210 275 minecraft:white_wool
fill 59 210 276 63 210 276 minecraft:spruce_planks
fill 63 210 316 67 210 316 minecraft:spruce_planks
fill 64 210 279 64 211 279 minecraft:dark_oak_planks
fill 66 210 276 70 210 276 minecraft:spruce_planks
setblock 66 210 278 minecraft:light[level=15]
setblock 66 210 286 minecraft:light[level=15]
setblock 66 210 294 minecraft:light[level=15]
setblock 66 210 302 minecraft:light[level=15]
setblock 66 210 310 minecraft:light[level=15]
fill 66 210 312 66 211 312 minecraft:dark_oak_planks
fill 70 210 316 74 210 316 minecraft:spruce_planks
fill 73 210 276 77 210 276 minecraft:spruce_planks
setblock 74 210 278 minecraft:light[level=15]
setblock 74 210 286 minecraft:light[level=15]
setblock 74 210 294 minecraft:light[level=15]
setblock 74 210 302 minecraft:light[level=15]
setblock 74 210 310 minecraft:light[level=15]
fill 77 210 316 81 210 316 minecraft:spruce_planks
fill 80 210 276 84 210 276 minecraft:spruce_planks
setblock 82 210 278 minecraft:light[level=15]
setblock 82 210 286 minecraft:light[level=15]
setblock 82 210 294 minecraft:light[level=15]
setblock 82 210 302 minecraft:light[level=15]
setblock 82 210 310 minecraft:light[level=15]
fill 84 210 285 84 211 285 minecraft:dark_oak_planks
fill 84 210 316 88 210 316 minecraft:spruce_planks
fill 87 210 276 88 210 276 minecraft:spruce_planks
fill 88 210 277 88 210 279 minecraft:spruce_planks
fill 88 210 282 88 210 286 minecraft:spruce_planks
fill 88 210 289 88 210 293 minecraft:spruce_planks
fill 88 210 296 88 210 300 minecraft:spruce_planks
fill 88 210 303 88 210 307 minecraft:spruce_planks
fill 88 210 310 88 210 311 minecraft:spruce_planks
fill 88 210 313 88 210 314 minecraft:spruce_planks
fill 89 210 288 89 217 288 minecraft:cyan_concrete
setblock 89 210 289 minecraft:light_blue_wool
setblock 89 210 316 minecraft:white_wool
fill 47 211 281 47 229 281 minecraft:cyan_concrete
fill 47 211 297 47 232 297 minecraft:cyan_concrete
fill 47 211 310 47 249 311 minecraft:cyan_concrete
setblock 48 211 282 minecraft:spruce_planks
setblock 48 211 289 minecraft:spruce_planks
setblock 48 211 296 minecraft:spruce_planks
setblock 48 211 303 minecraft:spruce_planks
setblock 48 211 310 minecraft:spruce_planks
setblock 49 211 316 minecraft:spruce_planks
fill 50 211 278 50 212 278 minecraft:dark_oak_planks
fill 50 211 292 50 212 292 minecraft:dark_oak_planks
fill 50 211 297 50 212 297 minecraft:dark_oak_planks
fill 53 211 275 53 238 275 minecraft:cyan_concrete
setblock 56 211 276 minecraft:spruce_planks
setblock 56 211 316 minecraft:spruce_planks
fill 59 211 275 59 249 275 minecraft:cyan_concrete
setblock 63 211 276 minecraft:spruce_planks
setblock 63 211 316 minecraft:spruce_planks
fill 64 211 278 64 212 278 minecraft:dark_oak_planks
fill 66 211 313 66 212 313 minecraft:dark_oak_planks
setblock 70 211 276 minecraft:spruce_planks
setblock 70 211 316 minecraft:spruce_planks
setblock 74 211 275 minecraft:white_wool
setblock 77 211 276 minecraft:spruce_planks
setblock 77 211 316 minecraft:spruce_planks
setblock 84 211 275 minecraft:light_blue_wool
setblock 84 211 276 minecraft:spruce_planks
setblock 84 211 316 minecraft:spruce_planks
fill 85 211 285 85 212 285 minecraft:dark_oak_planks
setblock 88 211 279 minecraft:spruce_planks
setblock 88 211 286 minecraft:spruce_planks
setblock 88 211 293 minecraft:spruce_planks
setblock 88 211 300 minecraft:spruce_planks
setblock 88 211 307 minecraft:spruce_planks
setblock 88 211 314 minecraft:spruce_planks
fill 89 211 289 89 246 289 minecraft:cyan_concrete
fill 89 211 316 89 246 316 minecraft:cyan_concrete
setblock 48 212 276 minecraft:spruce_planks
setblock 48 212 283 minecraft:spruce_planks
setblock 48 212 290 minecraft:spruce_planks
setblock 48 212 297 minecraft:spruce_planks
setblock 48 212 304 minecraft:spruce_planks
setblock 48 212 311 minecraft:spruce_planks
fill 49 212 278 49 213 278 minecraft:dark_oak_planks
fill 49 212 292 49 213 292 minecraft:dark_oak_planks
fill 49 212 297 49 213 297 minecraft:dark_oak_planks
setblock 50 212 285 minecraft:light[level=12]
setblock 50 212 299 minecraft:light[level=12]
setblock 50 212 306 minecraft:light[level=12]
setblock 50 212 313 minecraft:light[level=12]
setblock 50 212 316 minecraft:spruce_planks
setblock 55 212 276 minecraft:spruce_planks
setblock 57 212 278 minecraft:light[level=12]
setblock 57 212 285 minecraft:light[level=12]
setblock 57 212 292 minecraft:light[level=12]
setblock 57 212 299 minecraft:light[level=12]
setblock 57 212 306 minecraft:light[level=12]
setblock 57 212 313 minecraft:light[level=12]
setblock 57 212 316 minecraft:spruce_planks
setblock 62 212 276 minecraft:spruce_planks
fill 64 212 277 64 213 277 minecraft:dark_oak_planks
setblock 64 212 285 minecraft:light[level=12]
setblock 64 212 292 minecraft:light[level=12]
setblock 64 212 299 minecraft:light[level=12]
setblock 64 212 306 minecraft:light[level=12]
setblock 64 212 313 minecraft:light[level=12]
setblock 64 212 316 minecraft:spruce_planks
fill 66 212 314 66 213 314 minecraft:dark_oak_planks
setblock 69 212 276 minecraft:spruce_planks
setblock 71 212 278 minecraft:light[level=12]
setblock 71 212 285 minecraft:light[level=12]
setblock 71 212 292 minecraft:light[level=12]
setblock 71 212 299 minecraft:light[level=12]
setblock 71 212 306 minecraft:light[level=12]
setblock 71 212 313 minecraft:light[level=12]
setblock 71 212 316 minecraft:spruce_planks
fill 74 212 275 74 214 275 minecraft:cyan_concrete
setblock 76 212 276 minecraft:spruce_planks
setblock 78 212 278 minecraft:light[level=12]
setblock 78 212 285 minecraft:light[level=12]
setblock 78 212 292 minecraft:light[level=12]
setblock 78 212 299 minecraft:light[level=12]
setblock 78 212 306 minecraft:light[level=12]
setblock 78 212 313 minecraft:light[level=12]
setblock 78 212 316 minecraft:spruce_planks
setblock 82 212 317 minecraft:light_blue_wool
setblock 83 212 276 minecraft:spruce_planks
fill 84 212 275 84 249 275 minecraft:cyan_concrete
setblock 85 212 278 minecraft:light[level=12]
setblock 85 212 292 minecraft:light[level=12]
setblock 85 212 299 minecraft:light[level=12]
setblock 85 212 306 minecraft:light[level=12]
setblock 85 212 313 minecraft:light[level=12]
setblock 85 212 316 minecraft:spruce_planks
fill 86 212 285 86 213 285 minecraft:dark_oak_planks
setblock 88 212 278 minecraft:spruce_planks
setblock 88 212 285 minecraft:spruce_planks
setblock 88 212 292 minecraft:spruce_planks
setblock 88 212 299 minecraft:spruce_planks
setblock 88 212 306 minecraft:spruce_planks
setblock 88 212 313 minecraft:spruce_planks
fill 47 213 288 47 222 290 minecraft:cyan_concrete
setblock 47 213 291 minecraft:light_blue_wool
fill 47 213 292 47 246 292 minecraft:cyan_concrete
setblock 48 213 277 minecraft:spruce_planks
setblock 48 213 278 minecraft:dark_oak_planks
setblock 48 213 284 minecraft:spruce_planks
setblock 48 213 291 minecraft:spruce_planks
setblock 48 213 292 minecraft:dark_oak_planks
fill 48 213 297 48 214 297 minecraft:dark_oak_planks
setblock 48 213 298 minecraft:spruce_planks
setblock 48 213 305 minecraft:spruce_planks
setblock 48 213 312 minecraft:spruce_planks
setblock 51 213 316 minecraft:spruce_planks
setblock 54 213 276 minecraft:spruce_planks
setblock 58 213 316 minecraft:spruce_planks
setblock 61 213 276 minecraft:spruce_planks
setblock 65 213 316 minecraft:spruce_planks
fill 66 213 315 66 214 315 minecraft:dark_oak_planks
setblock 68 213 276 minecraft:spruce_planks
setblock 72 213 316 minecraft:spruce_planks
setblock 75 213 276 minecraft:spruce_planks
setblock 79 213 316 minecraft:spruce_planks
setblock 82 213 276 minecraft:spruce_planks
fill 82 213 317 82 230 317 minecraft:cyan_concrete
setblock 86 213 316 minecraft:spruce_planks
fill 87 213 285 87 214 285 minecraft:dark_oak_planks
setblock 88 213 277 minecraft:spruce_planks
setblock 88 213 284 minecraft:spruce_planks
setblock 88 213 291 minecraft:spruce_planks
setblock 88 213 298 minecraft:spruce_planks
setblock 88 213 305 minecraft:spruce_planks
fill 47 214 291 47 249 291 minecraft:cyan_concrete
fill 48 214 278 48 215 278 minecraft:spruce_planks
fill 48 214 285 48 215 285 minecraft:spruce_planks
fill 48 214 292 48 215 292 minecraft:spruce_planks
fill 48 214 299 48 215 299 minecraft:spruce_planks
fill 48 214 306 48 215 306 minecraft:spruce_planks
fill 48 214 313 48 215 313 minecraft:spruce_planks
setblock 51 214 283 minecraft:shroomlight
setblock 51 214 289 minecraft:shroomlight
setblock 51 214 295 minecraft:shroomlight
setblock 51 214 301 minecraft:shroomlight
setblock 51 214 307 minecraft:shroomlight
setblock 51 214 313 minecraft:shroomlight
fill 52 214 316 52 215 316 minecraft:spruce_planks
fill 53 214 276 53 215 276 minecraft:spruce_planks
setblock 55 214 279 minecraft:shroomlight
setblock 57 214 313 minecraft:shroomlight
fill 59 214 316 59 215 316 minecraft:spruce_planks
fill 60 214 276 60 215 276 minecraft:spruce_planks
setblock 61 214 279 minecraft:shroomlight
setblock 63 214 313 minecraft:shroomlight
fill 66 214 316 66 215 316 minecraft:spruce_planks
fill 66 214 317 66 225 317 minecraft:cyan_concrete
fill 67 214 276 67 215 276 minecraft:spruce_planks
setblock 67 214 279 minecraft:shroomlight
setblock 67 214 317 minecraft:white_wool
fill 68 214 317 72 221 317 minecraft:cyan_concrete
setblock 69 214 313 minecraft:shroomlight
setblock 73 214 279 minecraft:shroomlight
fill 73 214 316 73 215 316 minecraft:spruce_planks
fill 74 214 276 74 215 276 minecraft:spruce_planks
setblock 75 214 313 minecraft:shroomlight
setblock 79 214 279 minecraft:shroomlight
fill 80 214 316 80 215 316 minecraft:spruce_planks
fill 81 214 276 81 215 276 minecraft:spruce_planks
setblock 81 214 313 minecraft:shroomlight
setblock 85 214 279 minecraft:shroomlight
setblock 85 214 285 minecraft:shroomlight
setblock 85 214 291 minecraft:shroomlight
setblock 85 214 297 minecraft:shroomlight
setblock 85 214 303 minecraft:shroomlight
setblock 85 214 309 minecraft:shroomlight
fill 87 214 316 87 215 316 minecraft:spruce_planks
fill 88 214 276 88 215 276 minecraft:spruce_planks
fill 88 214 283 88 215 283 minecraft:spruce_planks
fill 88 214 290 88 215 290 minecraft:spruce_planks
fill 88 214 297 88 215 297 minecraft:spruce_planks
fill 88 214 304 88 215 304 minecraft:spruce_planks
fill 88 214 311 88 215 311 minecraft:spruce_planks
fill 48 215 276 49 215 277 minecraft:spruce_planks
fill 48 215 279 51 215 279 minecraft:spruce_planks
fill 48 215 280 56 215 280 minecraft:spruce_log
fill 48 215 282 51 215 284 minecraft:spruce_planks
fill 48 215 286 51 215 287 minecraft:spruce_planks
fill 48 215 289 51 215 291 minecraft:spruce_planks
fill 48 215 293 51 215 294 minecraft:spruce_planks
fill 48 215 296 51 215 298 minecraft:spruce_planks
fill 48 215 300 51 215 301 minecraft:spruce_planks
fill 48 215 303 51 215 305 minecraft:spruce_planks
fill 48 215 307 51 215 308 minecraft:spruce_planks
fill 48 215 310 51 215 312 minecraft:spruce_planks
fill 48 215 314 87 215 315 minecraft:spruce_planks
fill 49 215 278 82 215 278 minecraft:spruce_planks
fill 49 215 281 51 215 281 minecraft:spruce_planks
fill 49 215 285 51 215 285 minecraft:spruce_planks
fill 49 215 288 51 215 288 minecraft:spruce_planks
fill 49 215 292 51 215 292 minecraft:spruce_planks
fill 49 215 295 51 215 295 minecraft:spruce_planks
fill 49 215 299 51 215 299 minecraft:spruce_planks
fill 49 215 302 51 215 302 minecraft:spruce_planks
fill 49 215 306 51 215 306 minecraft:spruce_planks
fill 49 215 309 51 215 309 minecraft:spruce_planks
fill 49 215 313 83 215 313 minecraft:spruce_planks
fill 49 215 316 51 215 316 minecraft:spruce_planks
fill 50 215 277 88 215 277 minecraft:spruce_planks
fill 51 215 276 52 215 276 minecraft:spruce_planks
fill 53 215 279 81 215 279 minecraft:spruce_planks
fill 53 215 316 54 215 316 minecraft:spruce_planks
fill 54 215 276 56 215 276 minecraft:spruce_planks
fill 56 215 316 58 215 316 minecraft:spruce_planks
fill 58 215 276 59 215 276 minecraft:spruce_planks
fill 58 215 317 59 249 317 minecraft:cyan_concrete
fill 60 215 316 61 215 316 minecraft:spruce_planks
setblock 60 215 317 minecraft:white_wool
fill 61 215 276 63 215 276 minecraft:spruce_planks
fill 63 215 316 65 215 316 minecraft:spruce_planks
fill 65 215 276 66 215 276 minecraft:spruce_planks
fill 67 215 316 68 215 316 minecraft:spruce_planks
fill 67 215 317 67 249 317 minecraft:cyan_concrete
fill 68 215 276 70 215 276 minecraft:spruce_planks
fill 70 215 316 72 215 316 minecraft:spruce_planks
fill 72 215 276 73 215 276 minecraft:spruce_planks
setblock 74 215 275 minecraft:light_blue_wool
fill 74 215 316 75 215 316 minecraft:spruce_planks
fill 75 215 276 77 215 276 minecraft:spruce_planks
fill 77 215 316 79 215 316 minecraft:spruce_planks
fill 79 215 276 80 215 276 minecraft:spruce_planks
fill 80 215 312 88 215 312 minecraft:spruce_log
fill 81 215 316 82 215 316 minecraft:spruce_planks
fill 82 215 276 84 215 276 minecraft:spruce_planks
fill 84 215 316 86 215 316 minecraft:spruce_planks
fill 85 215 278 87 215 311 minecraft:spruce_planks
fill 85 215 313 88 215 313 minecraft:spruce_planks
fill 86 215 276 87 215 276 minecraft:spruce_planks
setblock 87 215 275 minecraft:white_wool
fill 88 215 278 88 215 279 minecraft:spruce_planks
fill 88 215 281 88 215 282 minecraft:spruce_planks
fill 88 215 284 88 215 286 minecraft:spruce_planks
fill 88 215 288 88 215 289 minecraft:spruce_planks
fill 88 215 291 88 215 293 minecraft:spruce_planks
fill 88 215 295 88 215 296 minecraft:spruce_planks
fill 88 215 298 88 215 300 minecraft:spruce_planks
fill 88 215 302 88 215 303 minecraft:spruce_planks
fill 88 215 305 88 215 307 minecraft:spruce_planks
fill 88 215 309 88 215 310 minecraft:spruce_planks
setblock 88 215 314 minecraft:spruce_planks
setblock 88 215 316 minecraft:spruce_planks
fill 89 215 300 89 221 304 minecraft:cyan_concrete
setblock 89 215 305 minecraft:light_blue_wool
fill 89 215 306 89 247 307 minecraft:cyan_concrete
setblock 89 215 311 minecraft:white_wool
setblock 48 216 280 minecraft:spruce_planks
setblock 48 216 287 minecraft:spruce_planks
setblock 48 216 294 minecraft:spruce_planks
setblock 48 216 301 minecraft:spruce_planks
setblock 48 216 308 minecraft:spruce_planks
setblock 48 216 315 minecraft:spruce_planks
setblock 51 216 276 minecraft:spruce_planks
setblock 51 216 279 minecraft:dark_oak_planks
fill 51 216 280 53 231 280 minecraft:spruce_log
fill 51 216 281 51 216 313 minecraft:dark_oak_planks
fill 52 216 313 83 216 313 minecraft:dark_oak_planks
fill 53 216 279 85 216 279 minecraft:dark_oak_planks
setblock 54 216 316 minecraft:spruce_planks
setblock 58 216 276 minecraft:spruce_planks
fill 60 216 317 60 249 317 minecraft:cyan_concrete
setblock 61 216 316 minecraft:spruce_planks
setblock 65 216 276 minecraft:spruce_planks
setblock 68 216 316 minecraft:spruce_planks
setblock 72 216 276 minecraft:spruce_planks
fill 74 216 275 74 249 275 minecraft:cyan_concrete
setblock 75 216 316 minecraft:spruce_planks
setblock 79 216 276 minecraft:spruce_planks
fill 82 216 280 84 219 280 minecraft:spruce_planks
setblock 82 216 316 minecraft:spruce_planks
fill 83 216 312 85 231 312 minecraft:spruce_log
fill 85 216 280 85 216 311 minecraft:dark_oak_planks
setblock 85 216 313 minecraft:dark_oak_planks
setblock 86 216 276 minecraft:spruce_planks
fill 87 216 275 87 249 275 minecraft:cyan_concrete
setblock 88 216 281 minecraft:spruce_planks
setblock 88 216 288 minecraft:spruce_planks
setblock 88 216 295 minecraft:spruce_planks
setblock 88 216 302 minecraft:spruce_planks
setblock 88 216 309 minecraft:spruce_planks
setblock 89 216 292 minecraft:white_wool
fill 89 216 305 89 249 305 minecraft:cyan_concrete
fill 89 216 311 89 242 311 minecraft:cyan_concrete
setblock 47 217 278 minecraft:white_wool
fill 81 217 279 81 217 280 minecraft:dark_oak_planks
fill 82 217 278 82 219 278 minecraft:dark_oak_planks
fill 82 217 279 85 219 279 minecraft:spruce_planks
fill 82 217 281 82 219 281 minecraft:dark_oak_planks
fill 83 217 277 84 217 277 minecraft:dark_oak_planks
schedule function dropper:buildpart/61_3 1t
