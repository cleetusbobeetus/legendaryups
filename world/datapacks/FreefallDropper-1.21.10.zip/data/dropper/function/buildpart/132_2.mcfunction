fill 18 280 582 18 280 593 minecraft:black_concrete
setblock 18 280 595 minecraft:sea_lantern
setblock 19 280 566 minecraft:sea_lantern
fill 19 280 567 19 280 577 minecraft:black_concrete
fill 19 280 578 19 280 579 minecraft:sea_lantern
fill 19 280 581 19 280 582 minecraft:sea_lantern
fill 19 280 583 19 280 593 minecraft:black_concrete
setblock 19 280 594 minecraft:sea_lantern
fill 19 280 595 21 280 595 minecraft:cyan_concrete
setblock 20 280 565 minecraft:sea_lantern
fill 20 280 566 22 280 566 minecraft:cyan_concrete
fill 20 280 567 34 280 576 minecraft:black_concrete
fill 20 280 577 20 280 578 minecraft:sea_lantern
fill 20 280 582 20 280 583 minecraft:sea_lantern
fill 20 280 584 34 280 593 minecraft:black_concrete
fill 20 280 594 22 280 594 minecraft:cyan_concrete
fill 21 280 565 23 280 565 minecraft:cyan_concrete
fill 21 280 577 22 280 577 minecraft:sea_lantern
fill 21 280 583 22 280 583 minecraft:sea_lantern
fill 22 280 578 23 280 578 minecraft:sea_lantern
fill 22 280 582 23 280 582 minecraft:sea_lantern
setblock 22 280 595 minecraft:sea_lantern
setblock 23 280 566 minecraft:sea_lantern
fill 23 280 577 34 280 577 minecraft:black_concrete
fill 23 280 579 24 280 579 minecraft:sea_lantern
fill 23 280 581 24 280 581 minecraft:sea_lantern
fill 23 280 583 34 280 583 minecraft:black_concrete
setblock 23 280 594 minecraft:sea_lantern
fill 23 280 595 25 280 595 minecraft:cyan_concrete
setblock 24 280 565 minecraft:sea_lantern
fill 24 280 566 26 280 566 minecraft:cyan_concrete
fill 24 280 578 34 280 578 minecraft:black_concrete
setblock 24 280 580 minecraft:sea_lantern
fill 24 280 582 34 280 582 minecraft:black_concrete
fill 24 280 594 26 280 594 minecraft:cyan_concrete
fill 25 280 565 27 280 565 minecraft:cyan_concrete
fill 25 280 579 34 280 581 minecraft:black_concrete
setblock 26 280 595 minecraft:sea_lantern
setblock 27 280 566 minecraft:sea_lantern
setblock 27 280 594 minecraft:sea_lantern
fill 27 280 595 29 280 595 minecraft:cyan_concrete
setblock 28 280 565 minecraft:sea_lantern
fill 28 280 566 30 280 566 minecraft:cyan_concrete
fill 28 280 594 30 280 594 minecraft:cyan_concrete
fill 29 280 565 31 280 565 minecraft:cyan_concrete
setblock 30 280 595 minecraft:sea_lantern
setblock 31 280 566 minecraft:sea_lantern
setblock 31 280 594 minecraft:sea_lantern
fill 31 280 595 33 280 595 minecraft:cyan_concrete
setblock 32 280 565 minecraft:sea_lantern
fill 32 280 566 34 280 566 minecraft:cyan_concrete
fill 32 280 594 34 280 594 minecraft:cyan_concrete
fill 33 280 565 35 280 565 minecraft:cyan_concrete
setblock 34 280 595 minecraft:sea_lantern
setblock 35 280 566 minecraft:sea_lantern
fill 35 280 567 35 280 569 minecraft:cyan_concrete
setblock 35 280 570 minecraft:sea_lantern
fill 35 280 571 35 280 573 minecraft:cyan_concrete
setblock 35 280 574 minecraft:sea_lantern
fill 35 280 575 35 280 577 minecraft:cyan_concrete
setblock 35 280 578 minecraft:sea_lantern
fill 35 280 579 35 280 581 minecraft:cyan_concrete
setblock 35 280 582 minecraft:sea_lantern
fill 35 280 583 35 280 585 minecraft:cyan_concrete
setblock 35 280 586 minecraft:sea_lantern
fill 35 280 587 35 280 589 minecraft:cyan_concrete
setblock 35 280 590 minecraft:sea_lantern
fill 35 280 591 35 280 593 minecraft:cyan_concrete
setblock 35 280 594 minecraft:sea_lantern
fill 35 280 595 36 280 595 minecraft:cyan_concrete
setblock 36 280 565 minecraft:sea_lantern
fill 36 280 566 36 280 568 minecraft:cyan_concrete
setblock 36 280 569 minecraft:sea_lantern
fill 36 280 570 36 280 572 minecraft:cyan_concrete
setblock 36 280 573 minecraft:sea_lantern
fill 36 280 574 36 280 576 minecraft:cyan_concrete
setblock 36 280 577 minecraft:sea_lantern
fill 36 280 578 36 280 580 minecraft:cyan_concrete
setblock 36 280 581 minecraft:sea_lantern
fill 36 280 582 36 280 584 minecraft:cyan_concrete
setblock 36 280 585 minecraft:sea_lantern
fill 36 280 586 36 280 588 minecraft:cyan_concrete
setblock 36 280 589 minecraft:sea_lantern
fill 36 280 590 36 280 592 minecraft:cyan_concrete
setblock 36 280 593 minecraft:sea_lantern
fill 36 280 594 36 284 594 minecraft:cyan_concrete
fill 37 280 565 41 280 595 minecraft:black_concrete
fill 6 281 566 8 284 566 minecraft:cyan_concrete
fill 6 281 594 8 284 594 minecraft:cyan_concrete
fill 7 281 567 7 284 567 minecraft:cyan_concrete
fill 7 281 593 7 284 593 minecraft:cyan_concrete
fill 7 281 595 7 284 595 minecraft:cyan_concrete
fill 34 281 566 36 284 566 minecraft:cyan_concrete
fill 34 281 594 35 284 594 minecraft:cyan_concrete
fill 35 281 565 35 284 565 minecraft:cyan_concrete
fill 35 281 567 35 284 567 minecraft:cyan_concrete
fill 35 281 593 35 284 593 minecraft:cyan_concrete
fill 35 281 595 35 284 595 minecraft:cyan_concrete
fill 1 284 559 1 300 559 minecraft:gray_concrete
fill 1 284 569 1 300 569 minecraft:gray_concrete
fill 1 284 579 1 300 579 minecraft:gray_concrete
fill 1 284 589 1 300 589 minecraft:gray_concrete
fill 2 284 598 2 300 598 minecraft:gray_concrete
setblock 3 284 560 minecraft:light[level=14]
setblock 3 284 568 minecraft:light[level=14]
setblock 3 284 576 minecraft:light[level=14]
setblock 3 284 584 minecraft:light[level=14]
setblock 3 284 592 minecraft:light[level=14]
fill 8 284 558 8 300 558 minecraft:gray_concrete
setblock 11 284 560 minecraft:light[level=14]
setblock 11 284 568 minecraft:light[level=14]
setblock 11 284 576 minecraft:light[level=14]
setblock 11 284 584 minecraft:light[level=14]
setblock 11 284 592 minecraft:light[level=14]
fill 12 284 598 12 300 598 minecraft:gray_concrete
fill 18 284 558 18 300 558 minecraft:gray_concrete
setblock 19 284 560 minecraft:light[level=14]
setblock 19 284 568 minecraft:light[level=14]
setblock 19 284 576 minecraft:light[level=14]
setblock 19 284 584 minecraft:light[level=14]
setblock 19 284 592 minecraft:light[level=14]
fill 22 284 598 22 300 598 minecraft:gray_concrete
setblock 27 284 560 minecraft:light[level=14]
setblock 27 284 568 minecraft:light[level=14]
setblock 27 284 576 minecraft:light[level=14]
setblock 27 284 584 minecraft:light[level=14]
setblock 27 284 592 minecraft:light[level=14]
fill 28 284 558 28 300 558 minecraft:gray_concrete
fill 32 284 598 32 300 598 minecraft:gray_concrete
setblock 35 284 560 minecraft:light[level=14]
setblock 35 284 568 minecraft:light[level=14]
setblock 35 284 576 minecraft:light[level=14]
setblock 35 284 584 minecraft:light[level=14]
setblock 35 284 592 minecraft:light[level=14]
fill 38 284 558 38 300 558 minecraft:gray_concrete
fill 41 284 565 41 300 565 minecraft:gray_concrete
fill 41 284 575 41 300 575 minecraft:gray_concrete
fill 41 284 585 41 300 585 minecraft:gray_concrete
fill 41 284 595 41 300 595 minecraft:gray_concrete
setblock 1 288 560 minecraft:black_concrete
fill 1 288 562 1 288 565 minecraft:black_concrete
setblock 1 288 570 minecraft:black_concrete
fill 1 288 572 1 288 575 minecraft:black_concrete
setblock 1 288 580 minecraft:black_concrete
fill 1 288 582 1 288 585 minecraft:black_concrete
setblock 1 288 590 minecraft:black_concrete
fill 1 288 592 1 288 595 minecraft:black_concrete
fill 2 288 558 5 288 558 minecraft:black_concrete
setblock 3 288 598 minecraft:black_concrete
fill 5 288 598 8 288 598 minecraft:black_concrete
setblock 7 288 558 minecraft:black_concrete
fill 12 288 558 15 288 558 minecraft:black_concrete
setblock 13 288 598 minecraft:black_concrete
fill 15 288 598 18 288 598 minecraft:black_concrete
setblock 17 288 558 minecraft:black_concrete
fill 22 288 558 25 288 558 minecraft:black_concrete
setblock 23 288 598 minecraft:black_concrete
fill 25 288 598 28 288 598 minecraft:black_concrete
setblock 27 288 558 minecraft:black_concrete
fill 32 288 558 35 288 558 minecraft:black_concrete
setblock 33 288 598 minecraft:black_concrete
fill 35 288 598 38 288 598 minecraft:black_concrete
setblock 37 288 558 minecraft:black_concrete
fill 41 288 559 41 288 562 minecraft:black_concrete
setblock 41 288 564 minecraft:black_concrete
fill 41 288 569 41 288 572 minecraft:black_concrete
setblock 41 288 574 minecraft:black_concrete
fill 41 288 579 41 288 582 minecraft:black_concrete
setblock 41 288 584 minecraft:black_concrete
fill 41 288 589 41 288 592 minecraft:black_concrete
setblock 41 288 594 minecraft:black_concrete
fill 0 292 563 0 292 566 minecraft:sea_lantern
fill 0 292 573 0 292 576 minecraft:sea_lantern
fill 0 292 583 0 292 586 minecraft:sea_lantern
fill 0 292 593 0 292 596 minecraft:sea_lantern
fill 3 292 557 6 292 557 minecraft:sea_lantern
setblock 3 292 560 minecraft:light[level=14]
setblock 3 292 568 minecraft:light[level=14]
setblock 3 292 576 minecraft:light[level=14]
setblock 3 292 584 minecraft:light[level=14]
setblock 3 292 592 minecraft:light[level=14]
fill 4 292 599 7 292 599 minecraft:sea_lantern
setblock 11 292 560 minecraft:light[level=14]
setblock 11 292 568 minecraft:light[level=14]
setblock 11 292 576 minecraft:light[level=14]
setblock 11 292 584 minecraft:light[level=14]
setblock 11 292 592 minecraft:light[level=14]
fill 13 292 557 16 292 557 minecraft:sea_lantern
fill 14 292 599 17 292 599 minecraft:sea_lantern
setblock 19 292 560 minecraft:light[level=14]
setblock 19 292 568 minecraft:light[level=14]
setblock 19 292 576 minecraft:light[level=14]
setblock 19 292 584 minecraft:light[level=14]
setblock 19 292 592 minecraft:light[level=14]
fill 23 292 557 26 292 557 minecraft:sea_lantern
fill 24 292 599 27 292 599 minecraft:sea_lantern
setblock 27 292 560 minecraft:light[level=14]
setblock 27 292 568 minecraft:light[level=14]
setblock 27 292 576 minecraft:light[level=14]
setblock 27 292 584 minecraft:light[level=14]
setblock 27 292 592 minecraft:light[level=14]
fill 33 292 557 36 292 557 minecraft:sea_lantern
fill 34 292 599 37 292 599 minecraft:sea_lantern
setblock 35 292 560 minecraft:light[level=14]
setblock 35 292 568 minecraft:light[level=14]
setblock 35 292 576 minecraft:light[level=14]
setblock 35 292 584 minecraft:light[level=14]
setblock 35 292 592 minecraft:light[level=14]
fill 42 292 558 42 292 561 minecraft:sea_lantern
fill 42 292 568 42 292 571 minecraft:sea_lantern
fill 42 292 578 42 292 581 minecraft:sea_lantern
fill 42 292 588 42 292 591 minecraft:sea_lantern
setblock 42 292 598 minecraft:sea_lantern
fill 0 293 563 0 307 566 minecraft:black_concrete
fill 0 293 573 0 307 576 minecraft:black_concrete
fill 0 293 583 0 307 586 minecraft:black_concrete
fill 0 293 593 0 307 596 minecraft:black_concrete
fill 3 293 557 6 307 557 minecraft:black_concrete
fill 4 293 599 7 307 599 minecraft:black_concrete
fill 13 293 557 16 307 557 minecraft:black_concrete
fill 14 293 599 17 307 599 minecraft:black_concrete
fill 23 293 557 26 307 557 minecraft:black_concrete
fill 24 293 599 27 307 599 minecraft:black_concrete
fill 33 293 557 36 307 557 minecraft:black_concrete
fill 34 293 599 37 307 599 minecraft:black_concrete
fill 42 293 558 42 307 561 minecraft:black_concrete
fill 42 293 568 42 307 571 minecraft:black_concrete
fill 42 293 578 42 307 581 minecraft:black_concrete
fill 42 293 588 42 307 591 minecraft:black_concrete
fill 42 293 598 42 307 598 minecraft:black_concrete
setblock 1 294 560 minecraft:black_concrete
setblock 1 294 570 minecraft:black_concrete
setblock 1 294 580 minecraft:black_concrete
setblock 1 294 590 minecraft:black_concrete
setblock 3 294 598 minecraft:black_concrete
setblock 7 294 558 minecraft:black_concrete
setblock 13 294 598 minecraft:black_concrete
setblock 17 294 558 minecraft:black_concrete
setblock 23 294 598 minecraft:black_concrete
setblock 27 294 558 minecraft:black_concrete
setblock 33 294 598 minecraft:black_concrete
setblock 37 294 558 minecraft:black_concrete
setblock 41 294 564 minecraft:black_concrete
setblock 41 294 574 minecraft:black_concrete
setblock 41 294 584 minecraft:black_concrete
setblock 41 294 594 minecraft:black_concrete
fill 1 297 562 1 297 565 minecraft:black_concrete
fill 1 297 572 1 297 575 minecraft:black_concrete
fill 1 297 582 1 297 585 minecraft:black_concrete
fill 1 297 592 1 297 595 minecraft:black_concrete
fill 2 297 558 5 297 558 minecraft:black_concrete
fill 5 297 598 8 297 598 minecraft:black_concrete
fill 12 297 558 15 297 558 minecraft:black_concrete
fill 15 297 598 18 297 598 minecraft:black_concrete
fill 22 297 558 25 297 558 minecraft:black_concrete
fill 25 297 598 28 297 598 minecraft:black_concrete
fill 32 297 558 35 297 558 minecraft:black_concrete
fill 35 297 598 38 297 598 minecraft:black_concrete
fill 41 297 559 41 297 562 minecraft:black_concrete
fill 41 297 569 41 297 572 minecraft:black_concrete
fill 41 297 579 41 297 582 minecraft:black_concrete
fill 41 297 589 41 297 592 minecraft:black_concrete
setblock 1 300 560 minecraft:black_concrete
setblock 1 300 570 minecraft:black_concrete
setblock 1 300 580 minecraft:black_concrete
setblock 1 300 590 minecraft:black_concrete
setblock 3 300 560 minecraft:light[level=14]
setblock 3 300 568 minecraft:light[level=14]
setblock 3 300 576 minecraft:light[level=14]
setblock 3 300 584 minecraft:light[level=14]
setblock 3 300 592 minecraft:light[level=14]
setblock 3 300 598 minecraft:black_concrete
setblock 7 300 558 minecraft:black_concrete
setblock 11 300 560 minecraft:light[level=14]
setblock 11 300 568 minecraft:light[level=14]
setblock 11 300 576 minecraft:light[level=14]
setblock 11 300 584 minecraft:light[level=14]
setblock 11 300 592 minecraft:light[level=14]
setblock 13 300 598 minecraft:black_concrete
setblock 17 300 558 minecraft:black_concrete
setblock 19 300 560 minecraft:light[level=14]
setblock 19 300 568 minecraft:light[level=14]
setblock 19 300 576 minecraft:light[level=14]
setblock 19 300 584 minecraft:light[level=14]
setblock 19 300 592 minecraft:light[level=14]
setblock 23 300 598 minecraft:black_concrete
setblock 27 300 558 minecraft:black_concrete
setblock 27 300 560 minecraft:light[level=14]
setblock 27 300 568 minecraft:light[level=14]
setblock 27 300 576 minecraft:light[level=14]
setblock 27 300 584 minecraft:light[level=14]
setblock 27 300 592 minecraft:light[level=14]
setblock 33 300 598 minecraft:black_concrete
setblock 35 300 560 minecraft:light[level=14]
setblock 35 300 568 minecraft:light[level=14]
setblock 35 300 576 minecraft:light[level=14]
setblock 35 300 584 minecraft:light[level=14]
setblock 35 300 592 minecraft:light[level=14]
setblock 37 300 558 minecraft:black_concrete
setblock 41 300 564 minecraft:black_concrete
setblock 41 300 574 minecraft:black_concrete
setblock 41 300 584 minecraft:black_concrete
setblock 41 300 594 minecraft:black_concrete
