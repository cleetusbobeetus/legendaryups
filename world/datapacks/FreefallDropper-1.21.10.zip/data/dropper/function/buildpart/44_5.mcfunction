fill 414 83 207 414 83 208 minecraft:mossy_cobblestone
fill 414 83 220 414 84 220 minecraft:mossy_cobblestone
setblock 415 83 183 minecraft:stone_bricks
setblock 415 83 198 minecraft:stone_bricks
fill 415 83 199 415 84 199 minecraft:mossy_cobblestone
setblock 415 83 203 minecraft:stone_bricks
fill 415 83 204 415 86 204 minecraft:mossy_cobblestone
setblock 415 83 207 minecraft:mossy_cobblestone
setblock 415 83 208 minecraft:stone_bricks
fill 415 83 209 415 86 209 minecraft:mossy_cobblestone
setblock 415 83 212 minecraft:mossy_cobblestone
setblock 415 83 213 minecraft:stone_bricks
setblock 415 83 214 minecraft:mossy_cobblestone
setblock 415 83 218 minecraft:stone_bricks
fill 415 83 219 415 84 219 minecraft:mossy_cobblestone
setblock 416 83 182 minecraft:stone_bricks
fill 416 83 183 416 86 183 minecraft:mossy_cobblestone
setblock 416 83 187 minecraft:stone_bricks
setblock 416 83 197 minecraft:stone_bricks
fill 416 83 198 416 86 198 minecraft:mossy_cobblestone
setblock 416 83 202 minecraft:stone_bricks
fill 416 83 203 416 86 203 minecraft:mossy_cobblestone
setblock 416 83 207 minecraft:stone_bricks
fill 416 83 208 416 86 208 minecraft:mossy_cobblestone
setblock 416 83 212 minecraft:stone_bricks
fill 416 83 213 416 86 213 minecraft:mossy_cobblestone
setblock 416 83 217 minecraft:stone_bricks
fill 416 83 218 416 85 218 minecraft:mossy_cobblestone
setblock 416 83 222 minecraft:stone_bricks
fill 417 83 182 417 86 182 minecraft:mossy_cobblestone
setblock 417 83 186 minecraft:stone_bricks
fill 417 83 187 417 86 187 minecraft:mossy_cobblestone
setblock 417 83 191 minecraft:stone_bricks
fill 417 83 192 417 86 192 minecraft:mossy_cobblestone
setblock 417 83 196 minecraft:stone_bricks
fill 417 83 197 417 86 197 minecraft:mossy_cobblestone
setblock 417 83 201 minecraft:stone_bricks
fill 417 83 202 417 86 202 minecraft:mossy_cobblestone
setblock 417 83 206 minecraft:stone_bricks
fill 417 83 207 417 86 207 minecraft:mossy_cobblestone
setblock 417 83 211 minecraft:stone_bricks
fill 417 83 212 417 86 212 minecraft:mossy_cobblestone
setblock 417 83 216 minecraft:stone_bricks
fill 417 83 217 417 86 217 minecraft:mossy_cobblestone
setblock 417 83 221 minecraft:stone_bricks
fill 417 83 222 417 86 222 minecraft:mossy_cobblestone
fill 377 84 182 377 84 184 minecraft:mossy_cobblestone
setblock 377 84 185 minecraft:stone_bricks
fill 377 84 186 377 87 186 minecraft:mossy_cobblestone
setblock 377 84 189 minecraft:mossy_cobblestone
setblock 377 84 190 minecraft:stone_bricks
fill 377 84 191 377 87 191 minecraft:mossy_cobblestone
setblock 377 84 195 minecraft:stone_bricks
fill 377 84 196 377 87 196 minecraft:mossy_cobblestone
setblock 377 84 200 minecraft:stone_bricks
fill 377 84 201 377 87 201 minecraft:mossy_cobblestone
setblock 377 84 205 minecraft:stone_bricks
fill 377 84 206 377 87 206 minecraft:mossy_cobblestone
setblock 377 84 210 minecraft:stone_bricks
fill 377 84 211 377 87 211 minecraft:mossy_cobblestone
setblock 377 84 215 minecraft:stone_bricks
setblock 377 84 216 minecraft:mossy_cobblestone
setblock 377 84 220 minecraft:stone_bricks
fill 377 84 221 377 85 221 minecraft:mossy_cobblestone
setblock 378 84 184 minecraft:stone_bricks
fill 378 84 185 378 87 185 minecraft:mossy_cobblestone
setblock 378 84 189 minecraft:stone_bricks
fill 378 84 190 378 87 190 minecraft:mossy_cobblestone
setblock 378 84 194 minecraft:stone_bricks
fill 378 84 195 378 85 195 minecraft:mossy_cobblestone
setblock 378 84 199 minecraft:stone_bricks
fill 378 84 200 378 87 200 minecraft:mossy_cobblestone
setblock 378 84 204 minecraft:stone_bricks
fill 378 84 205 378 87 205 minecraft:mossy_cobblestone
setblock 378 84 209 minecraft:stone_bricks
fill 378 84 210 378 86 210 minecraft:mossy_cobblestone
setblock 379 84 183 minecraft:stone_bricks
setblock 379 84 198 minecraft:stone_bricks
setblock 379 84 199 minecraft:mossy_cobblestone
setblock 379 84 203 minecraft:stone_bricks
fill 379 84 204 379 86 204 minecraft:mossy_cobblestone
setblock 380 84 182 minecraft:stone_bricks
fill 380 84 183 383 84 183 minecraft:mossy_cobblestone
setblock 380 84 222 minecraft:stone_bricks
fill 381 84 182 384 84 182 minecraft:mossy_cobblestone
setblock 381 84 222 minecraft:mossy_cobblestone
setblock 384 84 183 minecraft:stone_bricks
setblock 385 84 182 minecraft:stone_bricks
fill 385 84 183 385 86 183 minecraft:mossy_cobblestone
fill 386 84 182 386 87 182 minecraft:mossy_cobblestone
setblock 388 84 184 minecraft:stone_bricks
setblock 389 84 183 minecraft:stone_bricks
fill 389 84 184 389 87 184 minecraft:mossy_cobblestone
setblock 390 84 182 minecraft:stone_bricks
fill 390 84 183 390 87 183 minecraft:mossy_cobblestone
setblock 390 84 222 minecraft:stone_bricks
fill 391 84 182 391 87 182 minecraft:mossy_cobblestone
setblock 391 84 185 minecraft:mossy_cobblestone
setblock 391 84 221 minecraft:stone_bricks
fill 391 84 222 391 87 222 minecraft:mossy_cobblestone
setblock 392 84 185 minecraft:stone_bricks
fill 392 84 221 392 87 221 minecraft:mossy_cobblestone
setblock 393 84 184 minecraft:stone_bricks
fill 393 84 185 393 87 185 minecraft:mossy_cobblestone
setblock 394 84 183 minecraft:stone_bricks
fill 394 84 184 394 87 184 minecraft:mossy_cobblestone
setblock 395 84 182 minecraft:stone_bricks
fill 395 84 183 395 87 183 minecraft:mossy_cobblestone
setblock 395 84 222 minecraft:stone_bricks
fill 396 84 182 396 87 182 minecraft:mossy_cobblestone
setblock 396 84 221 minecraft:stone_bricks
fill 396 84 222 399 84 222 minecraft:mossy_cobblestone
setblock 397 84 185 minecraft:stone_bricks
setblock 397 84 220 minecraft:stone_bricks
fill 397 84 221 397 87 221 minecraft:mossy_cobblestone
setblock 398 84 184 minecraft:stone_bricks
setblock 398 84 185 minecraft:mossy_cobblestone
setblock 398 84 220 minecraft:mossy_cobblestone
setblock 399 84 183 minecraft:stone_bricks
fill 399 84 184 399 86 184 minecraft:mossy_cobblestone
setblock 400 84 182 minecraft:stone_bricks
fill 400 84 183 400 87 183 minecraft:mossy_cobblestone
setblock 400 84 222 minecraft:stone_bricks
fill 401 84 182 401 87 182 minecraft:mossy_cobblestone
setblock 401 84 221 minecraft:stone_bricks
fill 401 84 222 401 87 222 minecraft:mossy_cobblestone
fill 402 84 221 402 85 221 minecraft:mossy_cobblestone
setblock 404 84 183 minecraft:stone_bricks
setblock 405 84 182 minecraft:stone_bricks
setblock 405 84 183 minecraft:mossy_cobblestone
setblock 405 84 222 minecraft:stone_bricks
fill 406 84 182 409 84 182 minecraft:mossy_cobblestone
setblock 406 84 221 minecraft:stone_bricks
fill 406 84 222 406 87 222 minecraft:mossy_cobblestone
setblock 407 84 221 minecraft:mossy_cobblestone
setblock 408 84 183 minecraft:mossy_cobblestone
setblock 409 84 183 minecraft:stone_bricks
setblock 410 84 182 minecraft:stone_bricks
fill 410 84 183 410 86 183 minecraft:mossy_cobblestone
setblock 410 84 222 minecraft:stone_bricks
fill 411 84 182 411 87 182 minecraft:mossy_cobblestone
setblock 411 84 221 minecraft:stone_bricks
fill 411 84 222 411 87 222 minecraft:mossy_cobblestone
setblock 412 84 220 minecraft:stone_bricks
fill 412 84 221 412 87 221 minecraft:mossy_cobblestone
setblock 413 84 220 minecraft:mossy_cobblestone
setblock 414 84 183 minecraft:stone_bricks
setblock 414 84 202 minecraft:mossy_cobblestone
setblock 414 84 203 minecraft:stone_bricks
fill 414 84 204 414 87 204 minecraft:mossy_cobblestone
setblock 414 84 207 minecraft:mossy_cobblestone
setblock 414 84 208 minecraft:stone_bricks
fill 414 84 209 414 87 209 minecraft:mossy_cobblestone
setblock 415 84 182 minecraft:stone_bricks
fill 415 84 183 415 87 183 minecraft:mossy_cobblestone
setblock 415 84 202 minecraft:stone_bricks
fill 415 84 203 415 87 203 minecraft:mossy_cobblestone
setblock 415 84 207 minecraft:stone_bricks
fill 415 84 208 415 87 208 minecraft:mossy_cobblestone
setblock 415 84 212 minecraft:stone_bricks
setblock 415 84 213 minecraft:mossy_cobblestone
setblock 415 84 218 minecraft:mossy_cobblestone
setblock 415 84 222 minecraft:stone_bricks
fill 416 84 182 416 87 182 minecraft:mossy_cobblestone
setblock 416 84 186 minecraft:stone_bricks
fill 416 84 187 416 86 187 minecraft:mossy_cobblestone
setblock 416 84 196 minecraft:stone_bricks
fill 416 84 197 416 85 197 minecraft:mossy_cobblestone
setblock 416 84 201 minecraft:stone_bricks
fill 416 84 202 416 87 202 minecraft:mossy_cobblestone
setblock 416 84 206 minecraft:stone_bricks
fill 416 84 207 416 87 207 minecraft:mossy_cobblestone
setblock 416 84 211 minecraft:stone_bricks
fill 416 84 212 416 87 212 minecraft:mossy_cobblestone
setblock 416 84 216 minecraft:stone_bricks
fill 416 84 217 416 85 217 minecraft:mossy_cobblestone
setblock 416 84 221 minecraft:stone_bricks
fill 416 84 222 416 87 222 minecraft:mossy_cobblestone
setblock 417 84 185 minecraft:stone_bricks
fill 417 84 186 417 87 186 minecraft:mossy_cobblestone
setblock 417 84 189 minecraft:mossy_cobblestone
setblock 417 84 190 minecraft:stone_bricks
fill 417 84 191 417 87 191 minecraft:mossy_cobblestone
setblock 417 84 195 minecraft:stone_bricks
fill 417 84 196 417 87 196 minecraft:mossy_cobblestone
setblock 417 84 200 minecraft:stone_bricks
fill 417 84 201 417 87 201 minecraft:mossy_cobblestone
setblock 417 84 205 minecraft:stone_bricks
fill 417 84 206 417 87 206 minecraft:mossy_cobblestone
setblock 417 84 210 minecraft:stone_bricks
fill 417 84 211 417 87 211 minecraft:mossy_cobblestone
setblock 417 84 215 minecraft:stone_bricks
fill 417 84 216 417 87 216 minecraft:mossy_cobblestone
setblock 417 84 220 minecraft:stone_bricks
fill 417 84 221 417 87 221 minecraft:mossy_cobblestone
fill 377 85 182 377 85 183 minecraft:mossy_cobblestone
setblock 377 85 184 minecraft:stone_bricks
fill 377 85 185 377 88 185 minecraft:mossy_cobblestone
setblock 377 85 189 minecraft:stone_bricks
fill 377 85 190 377 88 190 minecraft:mossy_cobblestone
setblock 377 85 194 minecraft:stone_bricks
fill 377 85 195 377 88 195 minecraft:mossy_cobblestone
setblock 377 85 199 minecraft:stone_bricks
fill 377 85 200 377 88 200 minecraft:mossy_cobblestone
setblock 377 85 204 minecraft:stone_bricks
fill 377 85 205 377 88 205 minecraft:mossy_cobblestone
setblock 377 85 209 minecraft:stone_bricks
fill 377 85 210 377 88 210 minecraft:mossy_cobblestone
setblock 377 85 214 minecraft:stone_bricks
setblock 377 85 219 minecraft:stone_bricks
setblock 377 85 220 minecraft:mossy_cobblestone
setblock 378 85 183 minecraft:stone_bricks
fill 378 85 184 378 88 184 minecraft:mossy_cobblestone
setblock 378 85 188 minecraft:stone_bricks
fill 378 85 189 378 88 189 minecraft:mossy_cobblestone
setblock 378 85 194 minecraft:mossy_cobblestone
setblock 378 85 198 minecraft:stone_bricks
fill 378 85 199 378 86 199 minecraft:mossy_cobblestone
setblock 378 85 203 minecraft:stone_bricks
fill 378 85 204 378 88 204 minecraft:mossy_cobblestone
setblock 378 85 208 minecraft:stone_bricks
fill 378 85 209 378 87 209 minecraft:mossy_cobblestone
setblock 379 85 182 minecraft:stone_bricks
fill 379 85 183 382 85 183 minecraft:mossy_cobblestone
setblock 379 85 202 minecraft:stone_bricks
fill 379 85 203 379 86 203 minecraft:mossy_cobblestone
setblock 379 85 207 minecraft:stone_bricks
setblock 379 85 222 minecraft:stone_bricks
fill 380 85 182 383 85 182 minecraft:mossy_cobblestone
setblock 383 85 183 minecraft:stone_bricks
setblock 384 85 182 minecraft:stone_bricks
setblock 384 85 183 minecraft:mossy_cobblestone
fill 385 85 182 385 88 182 minecraft:mossy_cobblestone
setblock 388 85 183 minecraft:stone_bricks
fill 388 85 184 388 88 184 minecraft:mossy_cobblestone
setblock 389 85 182 minecraft:stone_bricks
fill 389 85 183 389 88 183 minecraft:mossy_cobblestone
setblock 389 85 222 minecraft:stone_bricks
fill 390 85 182 390 88 182 minecraft:mossy_cobblestone
fill 390 85 222 390 88 222 minecraft:mossy_cobblestone
setblock 391 85 185 minecraft:stone_bricks
setblock 391 85 221 minecraft:mossy_cobblestone
setblock 392 85 184 minecraft:stone_bricks
fill 392 85 185 392 88 185 minecraft:mossy_cobblestone
setblock 393 85 183 minecraft:stone_bricks
fill 393 85 184 393 88 184 minecraft:mossy_cobblestone
setblock 394 85 182 minecraft:stone_bricks
fill 394 85 183 394 88 183 minecraft:mossy_cobblestone
setblock 394 85 222 minecraft:stone_bricks
fill 395 85 182 395 88 182 minecraft:mossy_cobblestone
setblock 395 85 221 minecraft:stone_bricks
fill 395 85 222 398 85 222 minecraft:mossy_cobblestone
setblock 396 85 185 minecraft:stone_bricks
fill 396 85 221 396 88 221 minecraft:mossy_cobblestone
setblock 397 85 184 minecraft:stone_bricks
setblock 397 85 185 minecraft:mossy_cobblestone
setblock 398 85 183 minecraft:stone_bricks
fill 398 85 184 398 87 184 minecraft:mossy_cobblestone
setblock 399 85 182 minecraft:stone_bricks
fill 399 85 183 399 88 183 minecraft:mossy_cobblestone
setblock 399 85 222 minecraft:stone_bricks
fill 400 85 182 400 88 182 minecraft:mossy_cobblestone
setblock 400 85 221 minecraft:stone_bricks
fill 400 85 222 400 88 222 minecraft:mossy_cobblestone
setblock 401 85 221 minecraft:mossy_cobblestone
setblock 403 85 183 minecraft:stone_bricks
setblock 404 85 182 minecraft:stone_bricks
setblock 404 85 222 minecraft:stone_bricks
fill 405 85 182 408 85 182 minecraft:mossy_cobblestone
fill 405 85 222 405 87 222 minecraft:mossy_cobblestone
fill 407 85 206 413 86 206 minecraft:stone_bricks
setblock 409 85 182 minecraft:stone_bricks
setblock 409 85 183 minecraft:mossy_cobblestone
setblock 409 85 222 minecraft:stone_bricks
fill 410 85 182 410 88 182 minecraft:mossy_cobblestone
setblock 410 85 221 minecraft:stone_bricks
fill 410 85 222 410 88 222 minecraft:mossy_cobblestone
fill 411 85 205 413 86 205 minecraft:stone_bricks
fill 411 85 221 411 87 221 minecraft:mossy_cobblestone
setblock 413 85 183 minecraft:stone_bricks
setblock 414 85 182 minecraft:stone_bricks
fill 414 85 183 414 88 183 minecraft:mossy_cobblestone
setblock 414 85 202 minecraft:stone_bricks
fill 414 85 203 414 86 203 minecraft:mossy_cobblestone
setblock 414 85 207 minecraft:stone_bricks
fill 414 85 208 414 88 208 minecraft:mossy_cobblestone
setblock 414 85 222 minecraft:stone_bricks
fill 415 85 182 415 88 182 minecraft:mossy_cobblestone
setblock 415 85 201 minecraft:stone_bricks
fill 415 85 202 415 88 202 minecraft:mossy_cobblestone
setblock 415 85 206 minecraft:stone_bricks
fill 415 85 207 415 88 207 minecraft:mossy_cobblestone
setblock 415 85 211 minecraft:stone_bricks
fill 415 85 212 415 88 212 minecraft:mossy_cobblestone
setblock 415 85 221 minecraft:stone_bricks
fill 415 85 222 415 88 222 minecraft:mossy_cobblestone
setblock 416 85 185 minecraft:stone_bricks
fill 416 85 186 416 87 186 minecraft:mossy_cobblestone
setblock 416 85 200 minecraft:stone_bricks
fill 416 85 201 416 88 201 minecraft:mossy_cobblestone
setblock 416 85 205 minecraft:stone_bricks
fill 416 85 206 416 88 206 minecraft:mossy_cobblestone
setblock 416 85 210 minecraft:stone_bricks
fill 416 85 211 416 88 211 minecraft:mossy_cobblestone
setblock 416 85 215 minecraft:stone_bricks
setblock 416 85 216 minecraft:mossy_cobblestone
setblock 416 85 220 minecraft:stone_bricks
fill 416 85 221 416 86 221 minecraft:mossy_cobblestone
setblock 417 85 184 minecraft:stone_bricks
fill 417 85 185 417 88 185 minecraft:mossy_cobblestone
setblock 417 85 189 minecraft:stone_bricks
fill 417 85 190 417 88 190 minecraft:mossy_cobblestone
setblock 417 85 194 minecraft:stone_bricks
fill 417 85 195 417 86 195 minecraft:mossy_cobblestone
setblock 417 85 199 minecraft:stone_bricks
fill 417 85 200 417 88 200 minecraft:mossy_cobblestone
setblock 417 85 204 minecraft:stone_bricks
fill 417 85 205 417 88 205 minecraft:mossy_cobblestone
setblock 417 85 209 minecraft:stone_bricks
fill 417 85 210 417 88 210 minecraft:mossy_cobblestone
setblock 417 85 214 minecraft:stone_bricks
fill 417 85 215 417 88 215 minecraft:mossy_cobblestone
setblock 417 85 219 minecraft:stone_bricks
fill 417 85 220 417 87 220 minecraft:mossy_cobblestone
setblock 377 86 182 minecraft:mossy_cobblestone
setblock 377 86 183 minecraft:stone_bricks
fill 377 86 184 377 89 184 minecraft:mossy_cobblestone
setblock 377 86 188 minecraft:stone_bricks
fill 377 86 189 377 89 189 minecraft:mossy_cobblestone
setblock 377 86 193 minecraft:stone_bricks
fill 377 86 194 377 89 194 minecraft:mossy_cobblestone
setblock 377 86 198 minecraft:stone_bricks
fill 377 86 199 377 89 199 minecraft:mossy_cobblestone
setblock 377 86 203 minecraft:stone_bricks
fill 377 86 204 377 89 204 minecraft:mossy_cobblestone
setblock 377 86 208 minecraft:stone_bricks
fill 377 86 209 377 89 209 minecraft:mossy_cobblestone
setblock 377 86 213 minecraft:stone_bricks
setblock 378 86 182 minecraft:stone_bricks
fill 378 86 183 380 86 183 minecraft:mossy_cobblestone
setblock 378 86 187 minecraft:stone_bricks
fill 378 86 188 378 89 188 minecraft:mossy_cobblestone
setblock 378 86 197 minecraft:stone_bricks
setblock 378 86 198 minecraft:mossy_cobblestone
setblock 378 86 202 minecraft:stone_bricks
fill 378 86 203 378 88 203 minecraft:mossy_cobblestone
setblock 378 86 207 minecraft:stone_bricks
fill 378 86 208 378 88 208 minecraft:mossy_cobblestone
fill 379 86 182 382 86 182 minecraft:mossy_cobblestone
setblock 383 86 182 minecraft:stone_bricks
fill 384 86 182 384 89 182 minecraft:mossy_cobblestone
setblock 387 86 183 minecraft:stone_bricks
fill 387 86 209 390 87 209 minecraft:stone_bricks
setblock 388 86 182 minecraft:stone_bricks
fill 388 86 183 388 89 183 minecraft:mossy_cobblestone
setblock 388 86 222 minecraft:stone_bricks
fill 389 86 182 389 89 182 minecraft:mossy_cobblestone
fill 389 86 222 389 89 222 minecraft:mossy_cobblestone
fill 390 86 208 400 86 208 minecraft:stone_bricks
setblock 391 86 184 minecraft:stone_bricks
fill 391 86 185 391 89 185 minecraft:mossy_cobblestone
setblock 392 86 183 minecraft:stone_bricks
fill 392 86 184 392 89 184 minecraft:mossy_cobblestone
setblock 393 86 182 minecraft:stone_bricks
fill 393 86 183 393 89 183 minecraft:mossy_cobblestone
setblock 393 86 222 minecraft:stone_bricks
fill 394 86 182 394 89 182 minecraft:mossy_cobblestone
setblock 394 86 221 minecraft:stone_bricks
fill 394 86 222 397 86 222 minecraft:mossy_cobblestone
setblock 395 86 185 minecraft:stone_bricks
fill 395 86 207 408 86 207 minecraft:stone_bricks
fill 395 86 221 395 88 221 minecraft:mossy_cobblestone
setblock 396 86 184 minecraft:stone_bricks
setblock 396 86 185 minecraft:mossy_cobblestone
setblock 397 86 183 minecraft:stone_bricks
fill 397 86 184 397 88 184 minecraft:mossy_cobblestone
setblock 398 86 182 minecraft:stone_bricks
fill 398 86 183 398 89 183 minecraft:mossy_cobblestone
setblock 398 86 222 minecraft:stone_bricks
fill 399 86 182 399 89 182 minecraft:mossy_cobblestone
setblock 399 86 221 minecraft:stone_bricks
fill 399 86 222 399 89 222 minecraft:mossy_cobblestone
setblock 400 86 221 minecraft:mossy_cobblestone
setblock 402 86 183 minecraft:stone_bricks
setblock 403 86 182 minecraft:stone_bricks
setblock 403 86 222 minecraft:stone_bricks
fill 404 86 182 407 86 182 minecraft:mossy_cobblestone
fill 404 86 206 406 86 206 minecraft:stone_bricks
fill 404 86 222 404 87 222 minecraft:mossy_cobblestone
setblock 408 86 182 minecraft:stone_bricks
setblock 408 86 222 minecraft:stone_bricks
fill 409 86 182 409 89 182 minecraft:mossy_cobblestone
fill 409 86 205 410 86 205 minecraft:stone_bricks
fill 409 86 222 409 89 222 minecraft:mossy_cobblestone
setblock 410 86 221 minecraft:mossy_cobblestone
setblock 412 86 183 minecraft:stone_bricks
setblock 413 86 182 minecraft:stone_bricks
fill 413 86 183 413 88 183 minecraft:mossy_cobblestone
setblock 413 86 222 minecraft:stone_bricks
fill 414 86 182 414 89 182 minecraft:mossy_cobblestone
setblock 414 86 206 minecraft:stone_bricks
fill 414 86 207 414 89 207 minecraft:mossy_cobblestone
setblock 414 86 221 minecraft:stone_bricks
fill 414 86 222 414 89 222 minecraft:mossy_cobblestone
setblock 415 86 200 minecraft:stone_bricks
fill 415 86 201 415 87 201 minecraft:mossy_cobblestone
setblock 415 86 205 minecraft:stone_bricks
fill 415 86 206 415 89 206 minecraft:mossy_cobblestone
setblock 415 86 210 minecraft:stone_bricks
fill 415 86 211 415 89 211 minecraft:mossy_cobblestone
setblock 415 86 221 minecraft:mossy_cobblestone
setblock 416 86 184 minecraft:stone_bricks
fill 416 86 185 416 87 185 minecraft:mossy_cobblestone
setblock 416 86 199 minecraft:stone_bricks
fill 416 86 200 416 88 200 minecraft:mossy_cobblestone
setblock 416 86 204 minecraft:stone_bricks
fill 416 86 205 416 89 205 minecraft:mossy_cobblestone
setblock 416 86 209 minecraft:stone_bricks
fill 416 86 210 416 89 210 minecraft:mossy_cobblestone
setblock 416 86 214 minecraft:stone_bricks
setblock 416 86 215 minecraft:mossy_cobblestone
setblock 416 86 220 minecraft:mossy_cobblestone
setblock 417 86 183 minecraft:stone_bricks
fill 417 86 184 417 89 184 minecraft:mossy_cobblestone
setblock 417 86 188 minecraft:stone_bricks
fill 417 86 189 417 89 189 minecraft:mossy_cobblestone
setblock 417 86 194 minecraft:mossy_cobblestone
setblock 417 86 198 minecraft:stone_bricks
fill 417 86 199 417 89 199 minecraft:mossy_cobblestone
setblock 417 86 203 minecraft:stone_bricks
fill 417 86 204 417 89 204 minecraft:mossy_cobblestone
setblock 417 86 208 minecraft:stone_bricks
fill 417 86 209 417 89 209 minecraft:mossy_cobblestone
setblock 417 86 213 minecraft:stone_bricks
fill 417 86 214 417 89 214 minecraft:mossy_cobblestone
setblock 417 86 218 minecraft:stone_bricks
setblock 417 86 219 minecraft:mossy_cobblestone
setblock 377 87 182 minecraft:stone_bricks
fill 377 87 183 378 87 183 minecraft:mossy_cobblestone
setblock 377 87 187 minecraft:stone_bricks
fill 377 87 188 377 90 188 minecraft:mossy_cobblestone
setblock 377 87 192 minecraft:stone_bricks
fill 377 87 193 377 90 193 minecraft:mossy_cobblestone
setblock 377 87 197 minecraft:stone_bricks
fill 377 87 198 377 89 198 minecraft:mossy_cobblestone
setblock 377 87 202 minecraft:stone_bricks
fill 377 87 203 377 90 203 minecraft:mossy_cobblestone
setblock 377 87 207 minecraft:stone_bricks
fill 377 87 208 377 90 208 minecraft:mossy_cobblestone
setblock 377 87 212 minecraft:stone_bricks
fill 378 87 182 381 87 182 minecraft:mossy_cobblestone
setblock 378 87 186 minecraft:stone_bricks
fill 378 87 187 378 90 187 minecraft:mossy_cobblestone
setblock 378 87 201 minecraft:stone_bricks
fill 378 87 202 378 88 202 minecraft:mossy_cobblestone
setblock 378 87 206 minecraft:stone_bricks
fill 378 87 207 378 89 207 minecraft:mossy_cobblestone
fill 378 87 210 386 87 210 minecraft:stone_bricks
fill 380 87 209 386 87 209 minecraft:stone_bricks
setblock 382 87 182 minecraft:stone_bricks
fill 383 87 182 383 88 182 minecraft:mossy_cobblestone
setblock 386 87 183 minecraft:stone_bricks
fill 386 87 208 399 87 208 minecraft:stone_bricks
setblock 387 87 182 minecraft:stone_bricks
fill 387 87 183 387 90 183 minecraft:mossy_cobblestone
fill 388 87 182 388 90 182 minecraft:mossy_cobblestone
setblock 390 87 184 minecraft:stone_bricks
setblock 391 87 183 minecraft:stone_bricks
fill 391 87 184 391 90 184 minecraft:mossy_cobblestone
fill 391 87 209 393 87 209 minecraft:stone_bricks
setblock 392 87 182 minecraft:stone_bricks
fill 392 87 183 392 90 183 minecraft:mossy_cobblestone
setblock 392 87 222 minecraft:stone_bricks
fill 393 87 182 393 90 182 minecraft:mossy_cobblestone
setblock 393 87 221 minecraft:stone_bricks
fill 393 87 222 396 87 222 minecraft:mossy_cobblestone
setblock 394 87 185 minecraft:stone_bricks
fill 394 87 207 404 87 207 minecraft:stone_bricks
fill 394 87 221 394 88 221 minecraft:mossy_cobblestone
setblock 395 87 184 minecraft:stone_bricks
setblock 395 87 185 minecraft:mossy_cobblestone
setblock 396 87 183 minecraft:stone_bricks
fill 396 87 184 396 89 184 minecraft:mossy_cobblestone
setblock 397 87 182 minecraft:stone_bricks
fill 397 87 183 397 90 183 minecraft:mossy_cobblestone
setblock 397 87 222 minecraft:stone_bricks
fill 398 87 182 398 90 182 minecraft:mossy_cobblestone
setblock 398 87 221 minecraft:stone_bricks
fill 398 87 222 398 90 222 minecraft:mossy_cobblestone
setblock 401 87 183 minecraft:stone_bricks
setblock 402 87 182 minecraft:stone_bricks
setblock 402 87 222 minecraft:stone_bricks
fill 403 87 182 406 87 182 minecraft:mossy_cobblestone
setblock 403 87 222 minecraft:mossy_cobblestone
fill 406 87 206 412 87 206 minecraft:spruce_planks
setblock 407 87 182 minecraft:stone_bricks
setblock 407 87 222 minecraft:stone_bricks
fill 408 87 182 408 89 182 minecraft:mossy_cobblestone
fill 408 87 222 408 90 222 minecraft:mossy_cobblestone
setblock 411 87 183 minecraft:stone_bricks
setblock 412 87 182 minecraft:stone_bricks
fill 412 87 183 412 88 183 minecraft:mossy_cobblestone
fill 412 87 205 413 87 205 minecraft:spruce_planks
setblock 412 87 222 minecraft:stone_bricks
fill 413 87 182 413 90 182 minecraft:mossy_cobblestone
setblock 413 87 221 minecraft:stone_bricks
fill 413 87 222 413 90 222 minecraft:mossy_cobblestone
setblock 414 87 205 minecraft:stone_bricks
fill 414 87 206 414 89 206 minecraft:mossy_cobblestone
setblock 414 87 221 minecraft:mossy_cobblestone
setblock 415 87 204 minecraft:stone_bricks
fill 415 87 205 415 90 205 minecraft:mossy_cobblestone
setblock 415 87 209 minecraft:stone_bricks
fill 415 87 210 415 90 210 minecraft:mossy_cobblestone
setblock 416 87 183 minecraft:stone_bricks
setblock 416 87 184 minecraft:mossy_cobblestone
setblock 416 87 199 minecraft:mossy_cobblestone
setblock 416 87 203 minecraft:stone_bricks
fill 416 87 204 416 90 204 minecraft:mossy_cobblestone
setblock 416 87 208 minecraft:stone_bricks
fill 416 87 209 416 90 209 minecraft:mossy_cobblestone
setblock 416 87 213 minecraft:stone_bricks
setblock 416 87 214 minecraft:mossy_cobblestone
setblock 417 87 182 minecraft:stone_bricks
fill 417 87 183 417 89 183 minecraft:mossy_cobblestone
setblock 417 87 187 minecraft:stone_bricks
fill 417 87 188 417 90 188 minecraft:mossy_cobblestone
setblock 417 87 197 minecraft:stone_bricks
fill 417 87 198 417 89 198 minecraft:mossy_cobblestone
setblock 417 87 202 minecraft:stone_bricks
fill 417 87 203 417 90 203 minecraft:mossy_cobblestone
setblock 417 87 207 minecraft:stone_bricks
fill 417 87 208 417 90 208 minecraft:mossy_cobblestone
setblock 417 87 212 minecraft:stone_bricks
fill 417 87 213 417 90 213 minecraft:mossy_cobblestone
setblock 417 87 217 minecraft:stone_bricks
setblock 417 87 222 minecraft:stone_bricks
fill 377 88 182 377 90 183 minecraft:mossy_cobblestone
setblock 377 88 186 minecraft:stone_bricks
fill 377 88 187 377 91 187 minecraft:mossy_cobblestone
setblock 377 88 191 minecraft:stone_bricks
fill 377 88 192 377 91 192 minecraft:mossy_cobblestone
setblock 377 88 196 minecraft:stone_bricks
fill 377 88 197 377 89 197 minecraft:mossy_cobblestone
setblock 377 88 201 minecraft:stone_bricks
fill 377 88 202 377 91 202 minecraft:mossy_cobblestone
setblock 377 88 206 minecraft:stone_bricks
fill 377 88 207 377 91 207 minecraft:mossy_cobblestone
setblock 377 88 211 minecraft:stone_bricks
setblock 377 88 212 minecraft:mossy_cobblestone
fill 378 88 182 380 88 182 minecraft:mossy_cobblestone
setblock 378 88 185 minecraft:stone_bricks
fill 378 88 186 378 91 186 minecraft:mossy_cobblestone
setblock 378 88 205 minecraft:stone_bricks
fill 378 88 206 378 89 206 minecraft:mossy_cobblestone
fill 378 88 210 382 88 210 minecraft:stone_bricks
setblock 381 88 182 minecraft:stone_bricks
fill 381 88 209 386 88 209 minecraft:stone_bricks
setblock 382 88 182 minecraft:mossy_cobblestone
setblock 386 88 182 minecraft:stone_bricks
fill 386 88 183 386 91 183 minecraft:mossy_cobblestone
fill 387 88 182 387 91 182 minecraft:mossy_cobblestone
fill 387 88 209 389 88 209 minecraft:spruce_planks
setblock 389 88 184 minecraft:stone_bricks
setblock 390 88 183 minecraft:stone_bricks
fill 390 88 184 390 91 184 minecraft:mossy_cobblestone
fill 390 88 208 397 88 208 minecraft:spruce_planks
setblock 391 88 182 minecraft:stone_bricks
fill 391 88 183 391 91 183 minecraft:mossy_cobblestone
setblock 391 88 222 minecraft:stone_bricks
fill 392 88 182 392 91 182 minecraft:mossy_cobblestone
fill 392 88 222 395 88 222 minecraft:mossy_cobblestone
setblock 393 88 185 minecraft:stone_bricks
setblock 393 88 221 minecraft:mossy_cobblestone
setblock 394 88 184 minecraft:stone_bricks
setblock 394 88 185 minecraft:mossy_cobblestone
setblock 395 88 183 minecraft:stone_bricks
fill 395 88 184 395 91 184 minecraft:mossy_cobblestone
setblock 396 88 182 minecraft:stone_bricks
fill 396 88 183 396 91 183 minecraft:mossy_cobblestone
setblock 396 88 222 minecraft:stone_bricks
fill 397 88 182 397 91 182 minecraft:mossy_cobblestone
fill 397 88 207 403 88 207 minecraft:spruce_planks
fill 397 88 222 397 91 222 minecraft:mossy_cobblestone
setblock 401 88 182 minecraft:stone_bricks
setblock 401 88 222 minecraft:stone_bricks
setblock 402 88 182 minecraft:mossy_cobblestone
setblock 407 88 182 minecraft:mossy_cobblestone
setblock 407 88 222 minecraft:mossy_cobblestone
setblock 411 88 182 minecraft:stone_bricks
setblock 411 88 222 minecraft:stone_bricks
fill 412 88 182 412 91 182 minecraft:mossy_cobblestone
fill 412 88 222 412 91 222 minecraft:mossy_cobblestone
setblock 414 88 205 minecraft:mossy_cobblestone
setblock 414 88 209 minecraft:stone_bricks
setblock 415 88 203 minecraft:stone_bricks
fill 415 88 204 415 91 204 minecraft:mossy_cobblestone
setblock 415 88 208 minecraft:stone_bricks
fill 415 88 209 415 91 209 minecraft:mossy_cobblestone
setblock 416 88 182 minecraft:stone_bricks
setblock 416 88 202 minecraft:stone_bricks
fill 416 88 203 416 91 203 minecraft:mossy_cobblestone
setblock 416 88 207 minecraft:stone_bricks
fill 416 88 208 416 91 208 minecraft:mossy_cobblestone
setblock 416 88 212 minecraft:stone_bricks
fill 416 88 213 416 91 213 minecraft:mossy_cobblestone
setblock 416 88 222 minecraft:stone_bricks
setblock 417 88 182 minecraft:mossy_cobblestone
setblock 417 88 186 minecraft:stone_bricks
fill 417 88 187 417 91 187 minecraft:mossy_cobblestone
setblock 417 88 191 minecraft:stone_bricks
setblock 417 88 197 minecraft:mossy_cobblestone
setblock 417 88 201 minecraft:stone_bricks
fill 417 88 202 417 91 202 minecraft:mossy_cobblestone
setblock 417 88 206 minecraft:stone_bricks
fill 417 88 207 417 91 207 minecraft:mossy_cobblestone
setblock 417 88 211 minecraft:stone_bricks
fill 417 88 212 417 91 212 minecraft:mossy_cobblestone
setblock 377 89 185 minecraft:stone_bricks
fill 377 89 186 377 92 186 minecraft:mossy_cobblestone
setblock 377 89 190 minecraft:stone_bricks
fill 377 89 191 377 92 191 minecraft:mossy_cobblestone
setblock 377 89 195 minecraft:stone_bricks
fill 377 89 196 377 92 196 minecraft:mossy_cobblestone
setblock 377 89 200 minecraft:stone_bricks
fill 377 89 201 377 91 201 minecraft:mossy_cobblestone
setblock 377 89 205 minecraft:stone_bricks
fill 377 89 206 377 92 206 minecraft:mossy_cobblestone
setblock 377 89 210 minecraft:stone_bricks
fill 377 89 211 377 92 211 minecraft:mossy_cobblestone
setblock 378 89 182 minecraft:mossy_cobblestone
setblock 378 89 185 minecraft:mossy_cobblestone
setblock 378 89 189 minecraft:stone_bricks
fill 378 89 190 378 92 190 minecraft:mossy_cobblestone
setblock 378 89 205 minecraft:mossy_cobblestone
fill 378 89 210 381 89 210 minecraft:spruce_planks
setblock 379 89 184 minecraft:light[level=12]
setblock 379 89 192 minecraft:light[level=12]
setblock 379 89 200 minecraft:light[level=12]
setblock 379 89 208 minecraft:light[level=12]
setblock 379 89 216 minecraft:light[level=12]
setblock 385 89 182 minecraft:stone_bricks
setblock 385 89 209 minecraft:spruce_planks
fill 386 89 182 386 92 182 minecraft:mossy_cobblestone
setblock 387 89 184 minecraft:light[level=12]
setblock 387 89 192 minecraft:light[level=12]
setblock 387 89 200 minecraft:light[level=12]
setblock 387 89 208 minecraft:light[level=12]
setblock 387 89 216 minecraft:light[level=12]
setblock 388 89 184 minecraft:stone_bricks
setblock 389 89 183 minecraft:stone_bricks
fill 389 89 184 389 92 184 minecraft:mossy_cobblestone
setblock 390 89 182 minecraft:stone_bricks
fill 390 89 183 390 92 183 minecraft:mossy_cobblestone
setblock 390 89 222 minecraft:stone_bricks
fill 391 89 182 391 92 182 minecraft:mossy_cobblestone
fill 391 89 222 394 89 222 minecraft:mossy_cobblestone
setblock 392 89 185 minecraft:stone_bricks
setblock 393 89 184 minecraft:stone_bricks
setblock 393 89 185 minecraft:mossy_cobblestone
setblock 394 89 183 minecraft:stone_bricks
fill 394 89 184 394 92 184 minecraft:mossy_cobblestone
setblock 395 89 182 minecraft:stone_bricks
fill 395 89 183 395 92 183 minecraft:mossy_cobblestone
setblock 395 89 192 minecraft:light[level=12]
setblock 395 89 200 minecraft:light[level=12]
setblock 395 89 208 minecraft:light[level=12]
setblock 395 89 216 minecraft:light[level=12]
setblock 395 89 222 minecraft:stone_bricks
fill 396 89 182 396 92 182 minecraft:mossy_cobblestone
fill 396 89 222 396 92 222 minecraft:mossy_cobblestone
setblock 400 89 182 minecraft:stone_bricks
setblock 403 89 184 minecraft:light[level=12]
setblock 403 89 192 minecraft:light[level=12]
setblock 403 89 200 minecraft:light[level=12]
setblock 403 89 208 minecraft:light[level=12]
setblock 403 89 216 minecraft:light[level=12]
setblock 410 89 182 minecraft:stone_bricks
setblock 410 89 222 minecraft:stone_bricks
fill 411 89 182 411 92 182 minecraft:mossy_cobblestone
setblock 411 89 184 minecraft:light[level=12]
setblock 411 89 192 minecraft:light[level=12]
setblock 411 89 200 minecraft:light[level=12]
setblock 411 89 208 minecraft:light[level=12]
setblock 411 89 216 minecraft:light[level=12]
fill 411 89 222 411 92 222 minecraft:mossy_cobblestone
setblock 414 89 208 minecraft:stone_bricks
fill 414 89 209 414 92 209 minecraft:mossy_cobblestone
setblock 415 89 182 minecraft:stone_bricks
setblock 415 89 203 minecraft:mossy_cobblestone
setblock 415 89 207 minecraft:stone_bricks
fill 415 89 208 415 92 208 minecraft:mossy_cobblestone
setblock 415 89 212 minecraft:stone_bricks
setblock 416 89 182 minecraft:mossy_cobblestone
setblock 416 89 201 minecraft:stone_bricks
fill 416 89 202 416 91 202 minecraft:mossy_cobblestone
setblock 416 89 206 minecraft:stone_bricks
fill 416 89 207 416 92 207 minecraft:mossy_cobblestone
setblock 416 89 211 minecraft:stone_bricks
fill 416 89 212 416 92 212 minecraft:mossy_cobblestone
setblock 417 89 185 minecraft:stone_bricks
fill 417 89 186 417 92 186 minecraft:mossy_cobblestone
setblock 417 89 190 minecraft:stone_bricks
fill 417 89 191 417 92 191 minecraft:mossy_cobblestone
setblock 417 89 200 minecraft:stone_bricks
fill 417 89 201 417 92 201 minecraft:mossy_cobblestone
setblock 417 89 205 minecraft:stone_bricks
fill 417 89 206 417 92 206 minecraft:mossy_cobblestone
setblock 417 89 210 minecraft:stone_bricks
fill 417 89 211 417 92 211 minecraft:mossy_cobblestone
setblock 377 90 184 minecraft:stone_bricks
fill 377 90 185 377 93 185 minecraft:mossy_cobblestone
setblock 377 90 189 minecraft:stone_bricks
fill 377 90 190 377 93 190 minecraft:mossy_cobblestone
setblock 377 90 194 minecraft:stone_bricks
fill 377 90 195 377 93 195 minecraft:mossy_cobblestone
setblock 377 90 199 minecraft:stone_bricks
setblock 377 90 200 minecraft:mossy_cobblestone
setblock 377 90 204 minecraft:stone_bricks
fill 377 90 205 377 93 205 minecraft:mossy_cobblestone
setblock 377 90 209 minecraft:stone_bricks
fill 377 90 210 377 93 210 minecraft:mossy_cobblestone
setblock 378 90 188 minecraft:stone_bricks
fill 378 90 189 378 93 189 minecraft:mossy_cobblestone
setblock 384 90 182 minecraft:stone_bricks
fill 385 90 182 385 93 182 minecraft:mossy_cobblestone
setblock 388 90 183 minecraft:stone_bricks
fill 388 90 184 388 93 184 minecraft:mossy_cobblestone
setblock 389 90 182 minecraft:stone_bricks
fill 389 90 183 389 93 183 minecraft:mossy_cobblestone
setblock 389 90 222 minecraft:stone_bricks
fill 390 90 182 390 93 182 minecraft:mossy_cobblestone
setblock 390 90 185 minecraft:mossy_cobblestone
fill 390 90 222 393 90 222 minecraft:mossy_cobblestone
setblock 391 90 185 minecraft:stone_bricks
setblock 392 90 184 minecraft:stone_bricks
fill 392 90 185 392 91 185 minecraft:mossy_cobblestone
setblock 393 90 183 minecraft:stone_bricks
fill 393 90 184 393 93 184 minecraft:mossy_cobblestone
setblock 394 90 182 minecraft:stone_bricks
fill 394 90 183 394 93 183 minecraft:mossy_cobblestone
setblock 394 90 222 minecraft:stone_bricks
fill 395 90 182 395 93 182 minecraft:mossy_cobblestone
fill 395 90 222 395 93 222 minecraft:mossy_cobblestone
setblock 399 90 182 minecraft:stone_bricks
setblock 409 90 182 minecraft:stone_bricks
setblock 409 90 222 minecraft:stone_bricks
fill 410 90 182 410 93 182 minecraft:mossy_cobblestone
fill 410 90 222 410 93 222 minecraft:mossy_cobblestone
setblock 414 90 182 minecraft:stone_bricks
setblock 414 90 207 minecraft:stone_bricks
fill 414 90 208 414 93 208 minecraft:mossy_cobblestone
fill 414 90 210 414 91 210 minecraft:mossy_cobblestone
setblock 415 90 206 minecraft:stone_bricks
fill 415 90 207 415 93 207 minecraft:mossy_cobblestone
setblock 415 90 211 minecraft:stone_bricks
fill 415 90 212 415 93 212 minecraft:mossy_cobblestone
setblock 416 90 205 minecraft:stone_bricks
fill 416 90 206 416 93 206 minecraft:mossy_cobblestone
setblock 416 90 210 minecraft:stone_bricks
fill 416 90 211 416 93 211 minecraft:mossy_cobblestone
setblock 417 90 184 minecraft:stone_bricks
fill 417 90 185 417 93 185 minecraft:mossy_cobblestone
setblock 417 90 189 minecraft:stone_bricks
fill 417 90 190 417 93 190 minecraft:mossy_cobblestone
fill 417 90 192 417 91 192 minecraft:mossy_cobblestone
setblock 417 90 199 minecraft:stone_bricks
fill 417 90 200 417 93 200 minecraft:mossy_cobblestone
setblock 417 90 204 minecraft:stone_bricks
fill 417 90 205 417 93 205 minecraft:mossy_cobblestone
setblock 417 90 209 minecraft:stone_bricks
fill 417 90 210 417 93 210 minecraft:mossy_cobblestone
setblock 417 90 214 minecraft:stone_bricks
setblock 377 91 183 minecraft:stone_bricks
fill 377 91 184 377 94 184 minecraft:mossy_cobblestone
setblock 377 91 188 minecraft:stone_bricks
fill 377 91 189 377 94 189 minecraft:mossy_cobblestone
setblock 377 91 193 minecraft:stone_bricks
fill 377 91 194 377 94 194 minecraft:mossy_cobblestone
setblock 377 91 203 minecraft:stone_bricks
fill 377 91 204 377 92 204 minecraft:mossy_cobblestone
setblock 377 91 208 minecraft:stone_bricks
fill 377 91 209 377 94 209 minecraft:mossy_cobblestone
setblock 378 91 187 minecraft:stone_bricks
fill 378 91 188 378 94 188 minecraft:mossy_cobblestone
setblock 378 91 191 minecraft:mossy_cobblestone
fill 384 91 182 384 94 182 minecraft:mossy_cobblestone
fill 385 91 183 385 92 183 minecraft:mossy_cobblestone
setblock 387 91 183 minecraft:stone_bricks
fill 387 91 184 387 94 184 minecraft:mossy_cobblestone
setblock 388 91 182 minecraft:stone_bricks
fill 388 91 183 388 94 183 minecraft:mossy_cobblestone
setblock 388 91 222 minecraft:stone_bricks
fill 389 91 182 389 94 182 minecraft:mossy_cobblestone
fill 389 91 222 392 91 222 minecraft:mossy_cobblestone
setblock 390 91 185 minecraft:stone_bricks
setblock 391 91 184 minecraft:stone_bricks
fill 391 91 185 391 93 185 minecraft:mossy_cobblestone
setblock 392 91 183 minecraft:stone_bricks
fill 392 91 184 392 94 184 minecraft:mossy_cobblestone
setblock 393 91 182 minecraft:stone_bricks
fill 393 91 183 393 94 183 minecraft:mossy_cobblestone
setblock 393 91 222 minecraft:stone_bricks
fill 394 91 182 394 94 182 minecraft:mossy_cobblestone
fill 394 91 222 394 94 222 minecraft:mossy_cobblestone
setblock 398 91 182 minecraft:stone_bricks
setblock 408 91 222 minecraft:stone_bricks
fill 409 91 182 409 94 182 minecraft:mossy_cobblestone
fill 409 91 222 409 94 222 minecraft:mossy_cobblestone
setblock 413 91 182 minecraft:stone_bricks
setblock 413 91 222 minecraft:stone_bricks
setblock 414 91 207 minecraft:mossy_cobblestone
setblock 415 91 205 minecraft:stone_bricks
fill 415 91 206 415 94 206 minecraft:mossy_cobblestone
setblock 415 91 210 minecraft:stone_bricks
fill 415 91 211 415 94 211 minecraft:mossy_cobblestone
setblock 416 91 204 minecraft:stone_bricks
fill 416 91 205 416 94 205 minecraft:mossy_cobblestone
setblock 416 91 209 minecraft:stone_bricks
fill 416 91 210 416 94 210 minecraft:mossy_cobblestone
setblock 417 91 188 minecraft:stone_bricks
fill 417 91 189 417 94 189 minecraft:mossy_cobblestone
setblock 417 91 193 minecraft:stone_bricks
fill 417 91 194 417 94 194 minecraft:mossy_cobblestone
setblock 417 91 203 minecraft:stone_bricks
fill 417 91 204 417 94 204 minecraft:mossy_cobblestone
setblock 417 91 208 minecraft:stone_bricks
fill 417 91 209 417 94 209 minecraft:mossy_cobblestone
setblock 417 91 213 minecraft:stone_bricks
fill 417 91 214 417 94 214 minecraft:mossy_cobblestone
fill 377 92 183 377 94 183 minecraft:mossy_cobblestone
setblock 377 92 187 minecraft:stone_bricks
fill 377 92 188 377 95 188 minecraft:mossy_cobblestone
setblock 377 92 192 minecraft:stone_bricks
fill 377 92 193 377 95 193 minecraft:mossy_cobblestone
setblock 377 92 197 minecraft:stone_bricks
setblock 377 92 203 minecraft:mossy_cobblestone
setblock 377 92 207 minecraft:stone_bricks
fill 377 92 208 377 95 208 minecraft:mossy_cobblestone
setblock 377 92 212 minecraft:stone_bricks
setblock 378 92 186 minecraft:stone_bricks
fill 378 92 187 378 95 187 minecraft:mossy_cobblestone
setblock 378 92 191 minecraft:stone_bricks
fill 378 92 192 378 95 192 minecraft:mossy_cobblestone
fill 383 92 182 383 95 182 minecraft:mossy_cobblestone
setblock 386 92 183 minecraft:stone_bricks
setblock 387 92 182 minecraft:stone_bricks
fill 387 92 183 387 95 183 minecraft:mossy_cobblestone
fill 388 92 182 388 95 182 minecraft:mossy_cobblestone
fill 388 92 222 391 92 222 minecraft:mossy_cobblestone
setblock 389 92 185 minecraft:stone_bricks
setblock 390 92 184 minecraft:stone_bricks
fill 390 92 185 390 95 185 minecraft:mossy_cobblestone
setblock 391 92 183 minecraft:stone_bricks
fill 391 92 184 391 95 184 minecraft:mossy_cobblestone
setblock 392 92 182 minecraft:stone_bricks
fill 392 92 183 392 95 183 minecraft:mossy_cobblestone
setblock 392 92 221 minecraft:mossy_cobblestone
setblock 392 92 222 minecraft:stone_bricks
fill 393 92 182 393 95 182 minecraft:mossy_cobblestone
fill 393 92 222 393 95 222 minecraft:mossy_cobblestone
setblock 396 92 183 minecraft:stone_bricks
setblock 397 92 182 minecraft:stone_bricks
setblock 397 92 222 minecraft:stone_bricks
setblock 398 92 182 minecraft:mossy_cobblestone
setblock 407 92 222 minecraft:stone_bricks
fill 408 92 182 408 95 182 minecraft:mossy_cobblestone
fill 408 92 222 408 95 222 minecraft:mossy_cobblestone
setblock 412 92 182 minecraft:stone_bricks
setblock 412 92 222 minecraft:stone_bricks
setblock 413 92 182 minecraft:mossy_cobblestone
setblock 414 92 210 minecraft:stone_bricks
setblock 415 92 205 minecraft:mossy_cobblestone
setblock 415 92 209 minecraft:stone_bricks
fill 415 92 210 415 95 210 minecraft:mossy_cobblestone
setblock 416 92 188 minecraft:stone_bricks
fill 416 92 189 416 93 191 minecraft:mossy_cobblestone
setblock 416 92 203 minecraft:stone_bricks
fill 416 92 204 416 94 204 minecraft:mossy_cobblestone
setblock 416 92 208 minecraft:stone_bricks
fill 416 92 209 416 95 209 minecraft:mossy_cobblestone
setblock 416 92 213 minecraft:stone_bricks
fill 416 92 214 416 95 214 minecraft:mossy_cobblestone
setblock 417 92 187 minecraft:stone_bricks
fill 417 92 188 417 95 188 minecraft:mossy_cobblestone
setblock 417 92 192 minecraft:stone_bricks
fill 417 92 193 417 95 193 minecraft:mossy_cobblestone
fill 417 92 195 417 92 196 minecraft:mossy_cobblestone
setblock 417 92 202 minecraft:stone_bricks
fill 417 92 203 417 95 203 minecraft:mossy_cobblestone
setblock 417 92 207 minecraft:stone_bricks
fill 417 92 208 417 95 208 minecraft:mossy_cobblestone
setblock 417 92 212 minecraft:stone_bricks
fill 417 92 213 417 95 213 minecraft:mossy_cobblestone
fill 417 92 215 417 93 215 minecraft:mossy_cobblestone
setblock 377 93 186 minecraft:stone_bricks
fill 377 93 187 377 96 187 minecraft:mossy_cobblestone
setblock 377 93 191 minecraft:stone_bricks
fill 377 93 192 377 96 192 minecraft:mossy_cobblestone
setblock 377 93 196 minecraft:stone_bricks
fill 377 93 197 377 96 197 minecraft:mossy_cobblestone
setblock 377 93 206 minecraft:stone_bricks
fill 377 93 207 377 95 207 minecraft:mossy_cobblestone
setblock 377 93 211 minecraft:stone_bricks
fill 377 93 212 377 96 212 minecraft:mossy_cobblestone
fill 378 93 186 378 96 186 minecraft:mossy_cobblestone
setblock 378 93 190 minecraft:stone_bricks
fill 378 93 191 378 96 191 minecraft:mossy_cobblestone
fill 378 93 193 378 94 193 minecraft:mossy_cobblestone
setblock 384 93 183 minecraft:mossy_cobblestone
setblock 385 93 183 minecraft:stone_bricks
setblock 386 93 182 minecraft:stone_bricks
fill 386 93 183 386 95 184 minecraft:mossy_cobblestone
fill 387 93 182 387 96 182 minecraft:mossy_cobblestone
fill 387 93 222 390 93 222 minecraft:mossy_cobblestone
setblock 388 93 185 minecraft:stone_bricks
setblock 389 93 184 minecraft:stone_bricks
fill 389 93 185 389 95 185 minecraft:mossy_cobblestone
setblock 390 93 183 minecraft:stone_bricks
fill 390 93 184 390 96 184 minecraft:mossy_cobblestone
fill 390 93 221 391 93 221 minecraft:mossy_cobblestone
setblock 391 93 182 minecraft:stone_bricks
fill 391 93 183 391 96 183 minecraft:mossy_cobblestone
setblock 391 93 222 minecraft:stone_bricks
fill 392 93 182 392 96 182 minecraft:mossy_cobblestone
setblock 392 93 221 minecraft:stone_bricks
fill 392 93 222 392 96 222 minecraft:mossy_cobblestone
fill 393 93 221 393 96 221 minecraft:mossy_cobblestone
setblock 395 93 183 minecraft:stone_bricks
setblock 396 93 182 minecraft:stone_bricks
setblock 396 93 222 minecraft:stone_bricks
fill 397 93 182 397 94 182 minecraft:mossy_cobblestone
fill 397 93 222 397 96 222 minecraft:mossy_cobblestone
setblock 406 93 222 minecraft:stone_bricks
fill 407 93 222 407 96 222 minecraft:mossy_cobblestone
setblock 411 93 182 minecraft:stone_bricks
setblock 411 93 222 minecraft:stone_bricks
fill 412 93 182 412 94 182 minecraft:mossy_cobblestone
fill 412 93 222 412 96 222 minecraft:mossy_cobblestone
setblock 414 93 209 minecraft:stone_bricks
fill 414 93 210 414 94 211 minecraft:mossy_cobblestone
setblock 415 93 208 minecraft:stone_bricks
fill 415 93 209 415 96 209 minecraft:mossy_cobblestone
setblock 415 93 213 minecraft:stone_bricks
fill 416 93 188 416 96 188 minecraft:mossy_cobblestone
setblock 416 93 192 minecraft:stone_bricks
fill 416 93 193 416 96 193 minecraft:mossy_cobblestone
setblock 416 93 203 minecraft:mossy_cobblestone
setblock 416 93 207 minecraft:stone_bricks
fill 416 93 208 416 96 208 minecraft:mossy_cobblestone
setblock 416 93 212 minecraft:stone_bricks
fill 416 93 213 416 96 213 minecraft:mossy_cobblestone
setblock 417 93 186 minecraft:stone_bricks
fill 417 93 187 417 96 187 minecraft:mossy_cobblestone
setblock 417 93 191 minecraft:stone_bricks
fill 417 93 192 417 96 192 minecraft:mossy_cobblestone
setblock 417 93 195 minecraft:mossy_cobblestone
setblock 417 93 196 minecraft:stone_bricks
fill 417 93 197 417 94 199 minecraft:mossy_cobblestone
setblock 417 93 201 minecraft:stone_bricks
fill 417 93 202 417 96 202 minecraft:mossy_cobblestone
setblock 417 93 206 minecraft:stone_bricks
fill 417 93 207 417 96 207 minecraft:mossy_cobblestone
setblock 417 93 211 minecraft:stone_bricks
fill 417 93 212 417 96 212 minecraft:mossy_cobblestone
setblock 377 94 185 minecraft:stone_bricks
fill 377 94 186 377 97 186 minecraft:mossy_cobblestone
setblock 377 94 190 minecraft:stone_bricks
fill 377 94 191 377 97 191 minecraft:mossy_cobblestone
setblock 377 94 195 minecraft:stone_bricks
fill 377 94 196 377 97 196 minecraft:mossy_cobblestone
fill 377 94 198 377 95 198 minecraft:mossy_cobblestone
setblock 377 94 206 minecraft:mossy_cobblestone
setblock 377 94 210 minecraft:stone_bricks
fill 377 94 211 377 97 211 minecraft:mossy_cobblestone
fill 377 94 213 377 95 213 minecraft:mossy_cobblestone
setblock 378 94 189 minecraft:stone_bricks
fill 378 94 190 378 97 190 minecraft:mossy_cobblestone
setblock 378 94 194 minecraft:stone_bricks
fill 382 94 182 382 96 182 minecraft:mossy_cobblestone
setblock 384 94 183 minecraft:stone_bricks
setblock 385 94 182 minecraft:stone_bricks
fill 385 94 183 385 96 184 minecraft:mossy_cobblestone
fill 386 94 182 386 97 182 minecraft:mossy_cobblestone
fill 386 94 222 389 94 222 minecraft:mossy_cobblestone
setblock 388 94 184 minecraft:stone_bricks
fill 388 94 185 388 96 185 minecraft:mossy_cobblestone
fill 388 94 221 390 94 221 minecraft:mossy_cobblestone
setblock 389 94 183 minecraft:stone_bricks
fill 389 94 184 389 97 184 minecraft:mossy_cobblestone
setblock 390 94 182 minecraft:stone_bricks
fill 390 94 183 390 97 183 minecraft:mossy_cobblestone
setblock 390 94 222 minecraft:stone_bricks
fill 391 94 182 391 97 182 minecraft:mossy_cobblestone
setblock 391 94 221 minecraft:stone_bricks
fill 391 94 222 391 97 222 minecraft:mossy_cobblestone
fill 392 94 221 392 97 221 minecraft:mossy_cobblestone
setblock 393 94 184 minecraft:stone_bricks
setblock 394 94 183 minecraft:stone_bricks
fill 394 94 221 394 95 221 minecraft:mossy_cobblestone
setblock 395 94 182 minecraft:stone_bricks
setblock 395 94 183 minecraft:mossy_cobblestone
setblock 395 94 222 minecraft:stone_bricks
fill 396 94 182 396 95 182 minecraft:mossy_cobblestone
fill 396 94 222 396 97 222 minecraft:mossy_cobblestone
setblock 404 94 222 minecraft:mossy_cobblestone
setblock 405 94 222 minecraft:stone_bricks
fill 406 94 222 406 97 222 minecraft:mossy_cobblestone
fill 407 94 182 407 96 182 minecraft:mossy_cobblestone
setblock 410 94 182 minecraft:stone_bricks
setblock 410 94 222 minecraft:stone_bricks
fill 411 94 182 411 95 182 minecraft:mossy_cobblestone
fill 411 94 222 411 97 222 minecraft:mossy_cobblestone
setblock 414 94 209 minecraft:mossy_cobblestone
setblock 415 94 207 minecraft:stone_bricks
fill 415 94 208 415 95 208 minecraft:mossy_cobblestone
setblock 415 94 212 minecraft:stone_bricks
fill 415 94 213 415 96 213 minecraft:mossy_cobblestone
fill 416 94 189 416 94 190 minecraft:mossy_cobblestone
setblock 416 94 191 minecraft:stone_bricks
fill 416 94 192 416 97 192 minecraft:mossy_cobblestone
fill 416 94 194 416 94 195 minecraft:mossy_cobblestone
setblock 416 94 206 minecraft:stone_bricks
fill 416 94 207 416 96 207 minecraft:mossy_cobblestone
setblock 416 94 211 minecraft:stone_bricks
fill 416 94 212 416 97 212 minecraft:mossy_cobblestone
fill 417 94 186 417 96 186 minecraft:mossy_cobblestone
setblock 417 94 190 minecraft:stone_bricks
fill 417 94 191 417 97 191 minecraft:mossy_cobblestone
setblock 417 94 195 minecraft:stone_bricks
fill 417 94 196 417 97 196 minecraft:mossy_cobblestone
setblock 417 94 200 minecraft:stone_bricks
fill 417 94 201 417 97 201 minecraft:mossy_cobblestone
setblock 417 94 205 minecraft:stone_bricks
fill 417 94 206 417 97 206 minecraft:mossy_cobblestone
setblock 417 94 210 minecraft:stone_bricks
fill 417 94 211 417 97 211 minecraft:mossy_cobblestone
setblock 417 94 215 minecraft:stone_bricks
fill 417 94 216 417 97 216 minecraft:mossy_cobblestone
setblock 377 95 184 minecraft:stone_bricks
fill 377 95 185 377 98 185 minecraft:mossy_cobblestone
setblock 377 95 189 minecraft:stone_bricks
fill 377 95 190 377 98 190 minecraft:mossy_cobblestone
setblock 377 95 194 minecraft:stone_bricks
fill 377 95 195 378 97 195 minecraft:mossy_cobblestone
setblock 377 95 209 minecraft:stone_bricks
fill 377 95 210 377 96 210 minecraft:mossy_cobblestone
setblock 377 95 214 minecraft:stone_bricks
setblock 378 95 188 minecraft:stone_bricks
fill 378 95 189 379 96 189 minecraft:mossy_cobblestone
setblock 378 95 193 minecraft:stone_bricks
fill 378 95 194 378 98 194 minecraft:mossy_cobblestone
fill 379 95 190 379 95 191 minecraft:mossy_cobblestone
fill 381 95 182 381 97 182 minecraft:mossy_cobblestone
setblock 383 95 183 minecraft:stone_bricks
setblock 384 95 182 minecraft:stone_bricks
fill 384 95 183 384 98 183 minecraft:mossy_cobblestone
fill 385 95 182 385 98 182 minecraft:mossy_cobblestone
fill 385 95 222 388 95 222 minecraft:mossy_cobblestone
setblock 387 95 184 minecraft:stone_bricks
setblock 387 95 185 minecraft:mossy_cobblestone
fill 387 95 221 389 95 221 minecraft:mossy_cobblestone
setblock 388 95 183 minecraft:stone_bricks
fill 388 95 184 388 98 184 minecraft:mossy_cobblestone
setblock 389 95 182 minecraft:stone_bricks
fill 389 95 183 389 98 183 minecraft:mossy_cobblestone
setblock 389 95 222 minecraft:stone_bricks
fill 390 95 182 390 98 182 minecraft:mossy_cobblestone
setblock 390 95 221 minecraft:stone_bricks
fill 390 95 222 390 98 222 minecraft:mossy_cobblestone
fill 391 95 221 391 98 221 minecraft:mossy_cobblestone
setblock 392 95 184 minecraft:stone_bricks
setblock 393 95 183 minecraft:stone_bricks
setblock 394 95 182 minecraft:stone_bricks
setblock 394 95 183 minecraft:mossy_cobblestone
setblock 394 95 222 minecraft:stone_bricks
fill 395 95 182 395 96 182 minecraft:mossy_cobblestone
fill 395 95 222 395 98 222 minecraft:mossy_cobblestone
setblock 398 95 222 minecraft:mossy_cobblestone
setblock 403 95 222 minecraft:mossy_cobblestone
setblock 404 95 222 minecraft:stone_bricks
fill 405 95 222 405 98 222 minecraft:mossy_cobblestone
fill 407 95 221 409 95 221 minecraft:mossy_cobblestone
setblock 409 95 182 minecraft:stone_bricks
setblock 409 95 222 minecraft:stone_bricks
fill 410 95 182 410 96 182 minecraft:mossy_cobblestone
fill 410 95 222 410 98 222 minecraft:mossy_cobblestone
fill 415 95 192 415 97 192 minecraft:mossy_cobblestone
setblock 415 95 207 minecraft:mossy_cobblestone
setblock 415 95 211 minecraft:stone_bricks
fill 415 95 212 415 96 212 minecraft:mossy_cobblestone
setblock 416 95 189 minecraft:mossy_cobblestone
setblock 416 95 190 minecraft:stone_bricks
fill 416 95 191 416 98 191 minecraft:mossy_cobblestone
setblock 416 95 194 minecraft:mossy_cobblestone
setblock 416 95 195 minecraft:stone_bricks
fill 416 95 196 416 97 197 minecraft:mossy_cobblestone
setblock 416 95 205 minecraft:stone_bricks
fill 416 95 206 416 96 206 minecraft:mossy_cobblestone
setblock 416 95 210 minecraft:stone_bricks
fill 416 95 211 416 97 211 minecraft:mossy_cobblestone
setblock 416 95 215 minecraft:stone_bricks
setblock 417 95 189 minecraft:stone_bricks
fill 417 95 190 417 98 190 minecraft:mossy_cobblestone
setblock 417 95 194 minecraft:stone_bricks
fill 417 95 195 417 98 195 minecraft:mossy_cobblestone
fill 417 95 197 417 95 198 minecraft:mossy_cobblestone
setblock 417 95 199 minecraft:stone_bricks
fill 417 95 200 417 98 200 minecraft:mossy_cobblestone
setblock 417 95 204 minecraft:stone_bricks
fill 417 95 205 417 97 205 minecraft:mossy_cobblestone
setblock 417 95 209 minecraft:stone_bricks
fill 417 95 210 417 98 210 minecraft:mossy_cobblestone
setblock 417 95 214 minecraft:stone_bricks
fill 417 95 215 417 98 215 minecraft:mossy_cobblestone
fill 377 96 184 377 97 184 minecraft:mossy_cobblestone
setblock 377 96 188 minecraft:stone_bricks
fill 377 96 189 377 99 189 minecraft:mossy_cobblestone
setblock 377 96 193 minecraft:stone_bricks
fill 377 96 194 377 99 194 minecraft:mossy_cobblestone
setblock 377 96 198 minecraft:stone_bricks
fill 377 96 199 377 98 199 minecraft:mossy_cobblestone
setblock 377 96 209 minecraft:mossy_cobblestone
setblock 377 96 213 minecraft:stone_bricks
fill 377 96 214 377 97 214 minecraft:mossy_cobblestone
setblock 378 96 187 minecraft:stone_bricks
fill 378 96 188 378 99 188 minecraft:mossy_cobblestone
setblock 378 96 192 minecraft:stone_bricks
fill 378 96 193 378 99 193 minecraft:mossy_cobblestone
setblock 379 96 190 minecraft:mossy_cobblestone
setblock 379 96 191 minecraft:stone_bricks
fill 379 96 192 379 98 192 minecraft:mossy_cobblestone
setblock 383 96 182 minecraft:stone_bricks
fill 383 96 183 383 99 183 minecraft:mossy_cobblestone
fill 384 96 182 384 99 182 minecraft:mossy_cobblestone
fill 384 96 222 387 96 222 minecraft:mossy_cobblestone
setblock 386 96 183 minecraft:mossy_cobblestone
setblock 386 96 184 minecraft:stone_bricks
fill 386 96 221 388 96 221 minecraft:mossy_cobblestone
setblock 387 96 183 minecraft:stone_bricks
fill 387 96 184 387 98 184 minecraft:mossy_cobblestone
setblock 388 96 182 minecraft:stone_bricks
fill 388 96 183 388 99 183 minecraft:mossy_cobblestone
fill 388 96 220 389 96 220 minecraft:mossy_cobblestone
setblock 388 96 222 minecraft:stone_bricks
fill 389 96 182 389 99 182 minecraft:mossy_cobblestone
setblock 389 96 221 minecraft:stone_bricks
fill 389 96 222 389 99 222 minecraft:mossy_cobblestone
setblock 390 96 220 minecraft:stone_bricks
fill 390 96 221 390 99 221 minecraft:mossy_cobblestone
setblock 391 96 184 minecraft:stone_bricks
fill 391 96 220 391 99 220 minecraft:mossy_cobblestone
setblock 392 96 183 minecraft:stone_bricks
setblock 393 96 182 minecraft:stone_bricks
setblock 393 96 183 minecraft:mossy_cobblestone
setblock 393 96 222 minecraft:stone_bricks
fill 394 96 182 394 97 182 minecraft:mossy_cobblestone
setblock 394 96 221 minecraft:stone_bricks
fill 394 96 222 394 99 222 minecraft:mossy_cobblestone
setblock 398 96 222 minecraft:stone_bricks
fill 401 96 222 402 96 222 minecraft:mossy_cobblestone
setblock 403 96 222 minecraft:stone_bricks
fill 404 96 222 404 99 222 minecraft:mossy_cobblestone
fill 405 96 221 408 96 221 minecraft:mossy_cobblestone
setblock 406 96 182 minecraft:mossy_cobblestone
setblock 408 96 182 minecraft:stone_bricks
setblock 408 96 222 minecraft:stone_bricks
fill 409 96 182 409 97 182 minecraft:mossy_cobblestone
setblock 409 96 221 minecraft:stone_bricks
fill 409 96 222 409 99 222 minecraft:mossy_cobblestone
fill 410 96 221 410 97 221 minecraft:mossy_cobblestone
setblock 415 96 191 minecraft:mossy_cobblestone
fill 415 96 193 415 96 194 minecraft:mossy_cobblestone
setblock 415 96 210 minecraft:stone_bricks
setblock 415 96 211 minecraft:mossy_cobblestone
setblock 416 96 189 minecraft:stone_bricks
fill 416 96 190 416 99 190 minecraft:mossy_cobblestone
setblock 416 96 194 minecraft:stone_bricks
fill 416 96 195 416 99 195 minecraft:mossy_cobblestone
setblock 416 96 209 minecraft:stone_bricks
fill 416 96 210 416 97 210 minecraft:mossy_cobblestone
setblock 416 96 214 minecraft:stone_bricks
setblock 416 96 215 minecraft:mossy_cobblestone
setblock 417 96 188 minecraft:stone_bricks
fill 417 96 189 417 99 189 minecraft:mossy_cobblestone
setblock 417 96 193 minecraft:stone_bricks
fill 417 96 194 417 99 194 minecraft:mossy_cobblestone
setblock 417 96 197 minecraft:mossy_cobblestone
setblock 417 96 198 minecraft:stone_bricks
fill 417 96 199 417 99 199 minecraft:mossy_cobblestone
setblock 417 96 203 minecraft:stone_bricks
fill 417 96 204 417 97 204 minecraft:mossy_cobblestone
setblock 417 96 208 minecraft:stone_bricks
fill 417 96 209 417 98 209 minecraft:mossy_cobblestone
setblock 417 96 213 minecraft:stone_bricks
fill 417 96 214 417 99 214 minecraft:mossy_cobblestone
setblock 377 97 187 minecraft:stone_bricks
fill 377 97 188 377 100 188 minecraft:mossy_cobblestone
setblock 377 97 192 minecraft:stone_bricks
fill 377 97 193 377 100 193 minecraft:mossy_cobblestone
setblock 377 97 197 minecraft:stone_bricks
fill 377 97 198 377 100 198 minecraft:mossy_cobblestone
setblock 377 97 212 minecraft:stone_bricks
setblock 377 97 213 minecraft:mossy_cobblestone
fill 378 97 187 378 98 187 minecraft:mossy_cobblestone
fill 378 97 189 378 98 189 minecraft:mossy_cobblestone
setblock 378 97 191 minecraft:stone_bricks
fill 378 97 192 378 100 192 minecraft:mossy_cobblestone
setblock 378 97 196 minecraft:stone_bricks
setblock 379 97 184 minecraft:light[level=12]
setblock 379 97 190 minecraft:stone_bricks
fill 379 97 191 379 98 191 minecraft:mossy_cobblestone
fill 379 97 193 379 98 193 minecraft:mossy_cobblestone
setblock 379 97 200 minecraft:light[level=12]
setblock 379 97 208 minecraft:light[level=12]
setblock 379 97 216 minecraft:light[level=12]
setblock 382 97 182 minecraft:stone_bricks
fill 383 97 182 383 100 182 minecraft:mossy_cobblestone
fill 383 97 222 386 97 222 minecraft:mossy_cobblestone
setblock 385 97 183 minecraft:mossy_cobblestone
setblock 385 97 184 minecraft:stone_bricks
fill 385 97 221 387 97 221 minecraft:mossy_cobblestone
setblock 386 97 183 minecraft:stone_bricks
fill 386 97 184 386 98 184 minecraft:mossy_cobblestone
setblock 387 97 182 minecraft:stone_bricks
fill 387 97 183 387 100 183 minecraft:mossy_cobblestone
setblock 387 97 192 minecraft:light[level=12]
setblock 387 97 200 minecraft:light[level=12]
setblock 387 97 208 minecraft:light[level=12]
setblock 387 97 216 minecraft:light[level=12]
fill 387 97 220 388 97 220 minecraft:mossy_cobblestone
setblock 387 97 222 minecraft:stone_bricks
fill 388 97 182 388 100 182 minecraft:mossy_cobblestone
setblock 388 97 221 minecraft:stone_bricks
fill 388 97 222 388 100 222 minecraft:mossy_cobblestone
setblock 389 97 220 minecraft:stone_bricks
fill 389 97 221 389 100 221 minecraft:mossy_cobblestone
setblock 390 97 184 minecraft:stone_bricks
fill 390 97 220 390 100 220 minecraft:mossy_cobblestone
setblock 391 97 183 minecraft:stone_bricks
setblock 392 97 182 minecraft:stone_bricks
setblock 392 97 183 minecraft:mossy_cobblestone
fill 392 97 220 392 98 220 minecraft:mossy_cobblestone
setblock 392 97 222 minecraft:stone_bricks
fill 393 97 182 393 98 182 minecraft:mossy_cobblestone
setblock 393 97 221 minecraft:stone_bricks
fill 393 97 222 393 100 222 minecraft:mossy_cobblestone
fill 394 97 221 394 99 221 minecraft:mossy_cobblestone
setblock 395 97 184 minecraft:light[level=12]
setblock 395 97 192 minecraft:light[level=12]
setblock 395 97 200 minecraft:light[level=12]
setblock 395 97 208 minecraft:light[level=12]
setblock 395 97 216 minecraft:light[level=12]
setblock 397 97 222 minecraft:stone_bricks
fill 398 97 222 401 97 222 minecraft:mossy_cobblestone
setblock 402 97 222 minecraft:stone_bricks
setblock 403 97 184 minecraft:light[level=12]
setblock 403 97 192 minecraft:light[level=12]
setblock 403 97 200 minecraft:light[level=12]
setblock 403 97 208 minecraft:light[level=12]
setblock 403 97 216 minecraft:light[level=12]
fill 403 97 222 403 100 222 minecraft:mossy_cobblestone
fill 404 97 221 407 97 221 minecraft:mossy_cobblestone
setblock 407 97 182 minecraft:stone_bricks
setblock 407 97 222 minecraft:stone_bricks
setblock 408 97 182 minecraft:mossy_cobblestone
setblock 408 97 221 minecraft:stone_bricks
fill 408 97 222 408 100 222 minecraft:mossy_cobblestone
fill 409 97 221 409 99 221 minecraft:mossy_cobblestone
setblock 411 97 184 minecraft:light[level=12]
setblock 411 97 192 minecraft:light[level=12]
setblock 411 97 200 minecraft:light[level=12]
setblock 411 97 208 minecraft:light[level=12]
setblock 411 97 216 minecraft:light[level=12]
setblock 415 97 193 minecraft:mossy_cobblestone
setblock 415 97 194 minecraft:stone_bricks
setblock 416 97 189 minecraft:mossy_cobblestone
setblock 416 97 193 minecraft:stone_bricks
fill 416 97 194 416 100 194 minecraft:mossy_cobblestone
setblock 416 97 198 minecraft:stone_bricks
setblock 416 97 208 minecraft:stone_bricks
setblock 416 97 209 minecraft:mossy_cobblestone
setblock 416 97 213 minecraft:stone_bricks
setblock 416 97 214 minecraft:mossy_cobblestone
setblock 417 97 187 minecraft:stone_bricks
fill 417 97 188 417 99 188 minecraft:mossy_cobblestone
setblock 417 97 192 minecraft:stone_bricks
fill 417 97 193 417 100 193 minecraft:mossy_cobblestone
setblock 417 97 197 minecraft:stone_bricks
fill 417 97 198 417 100 198 minecraft:mossy_cobblestone
setblock 417 97 202 minecraft:stone_bricks
setblock 417 97 203 minecraft:mossy_cobblestone
setblock 417 97 207 minecraft:stone_bricks
fill 417 97 208 417 98 208 minecraft:mossy_cobblestone
setblock 417 97 212 minecraft:stone_bricks
fill 417 97 213 417 99 213 minecraft:mossy_cobblestone
setblock 377 98 186 minecraft:stone_bricks
fill 377 98 187 377 100 187 minecraft:mossy_cobblestone
setblock 377 98 191 minecraft:stone_bricks
fill 377 98 192 377 101 192 minecraft:mossy_cobblestone
setblock 377 98 195 minecraft:mossy_cobblestone
setblock 377 98 196 minecraft:stone_bricks
fill 377 98 197 377 101 197 minecraft:mossy_cobblestone
setblock 378 98 190 minecraft:stone_bricks
fill 378 98 191 378 101 191 minecraft:mossy_cobblestone
setblock 378 98 195 minecraft:stone_bricks
fill 378 98 196 378 101 196 minecraft:mossy_cobblestone
setblock 379 98 190 minecraft:mossy_cobblestone
setblock 380 98 182 minecraft:mossy_cobblestone
setblock 381 98 182 minecraft:stone_bricks
fill 382 98 182 382 101 182 minecraft:mossy_cobblestone
fill 382 98 222 385 98 222 minecraft:mossy_cobblestone
fill 384 98 221 386 98 221 minecraft:mossy_cobblestone
setblock 385 98 183 minecraft:stone_bricks
setblock 385 98 184 minecraft:mossy_cobblestone
setblock 386 98 182 minecraft:stone_bricks
fill 386 98 183 386 101 183 minecraft:mossy_cobblestone
fill 386 98 220 387 98 220 minecraft:mossy_cobblestone
setblock 386 98 222 minecraft:stone_bricks
fill 387 98 182 387 101 182 minecraft:mossy_cobblestone
setblock 387 98 221 minecraft:stone_bricks
fill 387 98 222 387 101 222 minecraft:mossy_cobblestone
setblock 388 98 220 minecraft:stone_bricks
fill 388 98 221 388 101 221 minecraft:mossy_cobblestone
setblock 389 98 184 minecraft:stone_bricks
fill 389 98 220 389 101 220 minecraft:mossy_cobblestone
setblock 390 98 183 minecraft:stone_bricks
setblock 391 98 182 minecraft:stone_bricks
setblock 391 98 183 minecraft:mossy_cobblestone
setblock 391 98 222 minecraft:stone_bricks
fill 392 98 182 392 99 182 minecraft:mossy_cobblestone
setblock 392 98 221 minecraft:stone_bricks
fill 392 98 222 392 101 222 minecraft:mossy_cobblestone
fill 393 98 221 393 101 221 minecraft:mossy_cobblestone
setblock 396 98 222 minecraft:stone_bricks
fill 397 98 222 400 98 222 minecraft:mossy_cobblestone
setblock 401 98 222 minecraft:stone_bricks
fill 402 98 222 402 101 222 minecraft:mossy_cobblestone
fill 403 98 221 406 98 221 minecraft:mossy_cobblestone
fill 406 98 220 407 98 220 minecraft:mossy_cobblestone
setblock 406 98 222 minecraft:stone_bricks
setblock 407 98 221 minecraft:stone_bricks
fill 407 98 222 407 101 222 minecraft:mossy_cobblestone
fill 408 98 221 408 101 221 minecraft:mossy_cobblestone
setblock 411 98 222 minecraft:stone_bricks
setblock 415 98 193 minecraft:stone_bricks
setblock 415 98 194 minecraft:mossy_cobblestone
setblock 416 98 192 minecraft:stone_bricks
fill 416 98 193 416 101 193 minecraft:mossy_cobblestone
setblock 416 98 196 minecraft:mossy_cobblestone
setblock 416 98 197 minecraft:stone_bricks
fill 416 98 198 416 100 198 minecraft:mossy_cobblestone
setblock 416 98 212 minecraft:stone_bricks
setblock 416 98 213 minecraft:mossy_cobblestone
setblock 417 98 187 minecraft:mossy_cobblestone
setblock 417 98 191 minecraft:stone_bricks
fill 417 98 192 417 101 192 minecraft:mossy_cobblestone
setblock 417 98 196 minecraft:stone_bricks
fill 417 98 197 417 101 197 minecraft:mossy_cobblestone
setblock 417 98 201 minecraft:stone_bricks
setblock 417 98 207 minecraft:mossy_cobblestone
setblock 417 98 211 minecraft:stone_bricks
fill 417 98 212 417 99 212 minecraft:mossy_cobblestone
setblock 417 98 216 minecraft:stone_bricks
setblock 377 99 186 minecraft:mossy_cobblestone
setblock 377 99 190 minecraft:stone_bricks
fill 377 99 191 377 102 191 minecraft:mossy_cobblestone
setblock 377 99 195 minecraft:stone_bricks
fill 377 99 196 377 102 196 minecraft:mossy_cobblestone
setblock 378 99 189 minecraft:stone_bricks
fill 378 99 190 378 100 190 minecraft:mossy_cobblestone
setblock 378 99 194 minecraft:stone_bricks
fill 378 99 195 378 102 195 minecraft:mossy_cobblestone
setblock 380 99 182 minecraft:stone_bricks
fill 381 99 182 381 102 182 minecraft:mossy_cobblestone
fill 382 99 222 384 99 222 minecraft:mossy_cobblestone
fill 383 99 221 385 99 221 minecraft:mossy_cobblestone
setblock 384 99 183 minecraft:stone_bricks
setblock 385 99 182 minecraft:stone_bricks
fill 385 99 183 385 102 183 minecraft:mossy_cobblestone
fill 385 99 220 386 99 220 minecraft:mossy_cobblestone
setblock 385 99 222 minecraft:stone_bricks
fill 386 99 182 386 102 182 minecraft:mossy_cobblestone
setblock 386 99 221 minecraft:stone_bricks
fill 386 99 222 386 102 222 minecraft:mossy_cobblestone
setblock 387 99 220 minecraft:stone_bricks
fill 387 99 221 387 102 221 minecraft:mossy_cobblestone
fill 388 99 220 388 102 220 minecraft:mossy_cobblestone
setblock 389 99 183 minecraft:stone_bricks
setblock 390 99 182 minecraft:stone_bricks
setblock 390 99 183 minecraft:mossy_cobblestone
setblock 390 99 222 minecraft:stone_bricks
fill 391 99 182 391 101 182 minecraft:mossy_cobblestone
setblock 391 99 221 minecraft:stone_bricks
fill 391 99 222 391 102 222 minecraft:mossy_cobblestone
fill 392 99 221 392 102 221 minecraft:mossy_cobblestone
setblock 395 99 222 minecraft:stone_bricks
fill 396 99 222 399 99 222 minecraft:mossy_cobblestone
setblock 400 99 222 minecraft:stone_bricks
fill 401 99 222 401 102 222 minecraft:mossy_cobblestone
fill 402 99 221 405 99 221 minecraft:mossy_cobblestone
fill 405 99 220 406 99 220 minecraft:mossy_cobblestone
setblock 405 99 222 minecraft:stone_bricks
setblock 406 99 221 minecraft:stone_bricks
fill 406 99 222 406 102 222 minecraft:mossy_cobblestone
setblock 407 99 220 minecraft:stone_bricks
fill 407 99 221 407 102 221 minecraft:mossy_cobblestone
setblock 410 99 222 minecraft:stone_bricks
setblock 416 99 191 minecraft:stone_bricks
fill 416 99 192 416 100 192 minecraft:mossy_cobblestone
setblock 416 99 196 minecraft:stone_bricks
fill 416 99 197 416 102 197 minecraft:mossy_cobblestone
setblock 417 99 190 minecraft:stone_bricks
fill 417 99 191 417 102 191 minecraft:mossy_cobblestone
setblock 417 99 195 minecraft:stone_bricks
fill 417 99 196 417 102 196 minecraft:mossy_cobblestone
setblock 417 99 200 minecraft:stone_bricks
setblock 417 99 201 minecraft:mossy_cobblestone
setblock 417 99 210 minecraft:stone_bricks
setblock 417 99 211 minecraft:mossy_cobblestone
setblock 417 99 215 minecraft:stone_bricks
setblock 417 99 216 minecraft:mossy_cobblestone
setblock 377 100 189 minecraft:stone_bricks
fill 377 100 190 377 103 190 minecraft:mossy_cobblestone
setblock 377 100 194 minecraft:stone_bricks
fill 377 100 195 377 103 195 minecraft:mossy_cobblestone
setblock 378 100 193 minecraft:stone_bricks
fill 378 100 194 378 102 194 minecraft:mossy_cobblestone
fill 380 100 182 380 103 182 minecraft:mossy_cobblestone
fill 381 100 222 383 100 222 minecraft:mossy_cobblestone
setblock 383 100 183 minecraft:stone_bricks
fill 383 100 221 384 100 221 minecraft:mossy_cobblestone
setblock 384 100 182 minecraft:stone_bricks
fill 384 100 183 384 103 183 minecraft:mossy_cobblestone
setblock 384 100 222 minecraft:stone_bricks
fill 385 100 182 385 103 182 minecraft:mossy_cobblestone
setblock 385 100 220 minecraft:mossy_cobblestone
setblock 385 100 221 minecraft:stone_bricks
fill 385 100 222 385 103 222 minecraft:mossy_cobblestone
setblock 386 100 220 minecraft:stone_bricks
fill 386 100 221 386 103 221 minecraft:mossy_cobblestone
fill 387 100 220 387 103 220 minecraft:mossy_cobblestone
setblock 388 100 183 minecraft:stone_bricks
setblock 389 100 182 minecraft:stone_bricks
setblock 389 100 183 minecraft:mossy_cobblestone
setblock 389 100 222 minecraft:stone_bricks
fill 390 100 182 390 102 182 minecraft:mossy_cobblestone
setblock 390 100 221 minecraft:stone_bricks
fill 390 100 222 390 103 222 minecraft:mossy_cobblestone
setblock 391 100 220 minecraft:stone_bricks
fill 391 100 221 391 103 221 minecraft:mossy_cobblestone
setblock 394 100 222 minecraft:stone_bricks
fill 395 100 222 398 100 222 minecraft:mossy_cobblestone
setblock 399 100 222 minecraft:stone_bricks
fill 400 100 222 400 103 222 minecraft:mossy_cobblestone
fill 402 100 221 404 100 221 minecraft:mossy_cobblestone
setblock 404 100 222 minecraft:stone_bricks
setblock 405 100 220 minecraft:mossy_cobblestone
setblock 405 100 221 minecraft:stone_bricks
fill 405 100 222 405 103 222 minecraft:mossy_cobblestone
setblock 406 100 220 minecraft:stone_bricks
fill 406 100 221 406 103 221 minecraft:mossy_cobblestone
setblock 409 100 222 minecraft:stone_bricks
setblock 410 100 222 minecraft:mossy_cobblestone
setblock 416 100 195 minecraft:stone_bricks
fill 416 100 196 416 103 196 minecraft:mossy_cobblestone
setblock 417 100 189 minecraft:stone_bricks
fill 417 100 190 417 102 190 minecraft:mossy_cobblestone
setblock 417 100 194 minecraft:stone_bricks
fill 417 100 195 417 103 195 minecraft:mossy_cobblestone
setblock 417 100 199 minecraft:stone_bricks
fill 417 100 200 417 103 200 minecraft:mossy_cobblestone
setblock 377 101 188 minecraft:stone_bricks
fill 377 101 189 377 102 189 minecraft:mossy_cobblestone
setblock 377 101 193 minecraft:stone_bricks
fill 377 101 194 377 104 194 minecraft:mossy_cobblestone
setblock 377 101 198 minecraft:stone_bricks
setblock 378 101 192 minecraft:stone_bricks
fill 378 101 193 378 102 193 minecraft:mossy_cobblestone
fill 380 101 222 382 101 222 minecraft:mossy_cobblestone
fill 382 101 221 383 101 221 minecraft:mossy_cobblestone
setblock 383 101 182 minecraft:stone_bricks
fill 383 101 183 383 104 183 minecraft:mossy_cobblestone
setblock 383 101 222 minecraft:stone_bricks
fill 384 101 182 384 104 182 minecraft:mossy_cobblestone
setblock 384 101 220 minecraft:mossy_cobblestone
setblock 384 101 221 minecraft:stone_bricks
fill 384 101 222 384 104 222 minecraft:mossy_cobblestone
setblock 385 101 220 minecraft:stone_bricks
fill 385 101 221 385 104 221 minecraft:mossy_cobblestone
fill 386 101 220 386 104 220 minecraft:mossy_cobblestone
setblock 387 101 183 minecraft:stone_bricks
setblock 388 101 182 minecraft:stone_bricks
setblock 388 101 183 minecraft:mossy_cobblestone
setblock 388 101 222 minecraft:stone_bricks
fill 389 101 182 389 104 182 minecraft:mossy_cobblestone
setblock 389 101 221 minecraft:stone_bricks
fill 389 101 222 389 104 222 minecraft:mossy_cobblestone
setblock 390 101 220 minecraft:stone_bricks
fill 390 101 221 390 104 221 minecraft:mossy_cobblestone
setblock 393 101 222 minecraft:stone_bricks
fill 394 101 222 397 101 222 minecraft:mossy_cobblestone
setblock 398 101 222 minecraft:stone_bricks
fill 399 101 222 399 104 222 minecraft:mossy_cobblestone
fill 401 101 221 403 101 221 minecraft:mossy_cobblestone
setblock 403 101 222 minecraft:stone_bricks
setblock 404 101 220 minecraft:mossy_cobblestone
setblock 404 101 221 minecraft:stone_bricks
fill 404 101 222 404 104 222 minecraft:mossy_cobblestone
setblock 405 101 220 minecraft:stone_bricks
fill 405 101 221 405 104 221 minecraft:mossy_cobblestone
setblock 408 101 222 minecraft:stone_bricks
fill 409 101 222 409 102 222 minecraft:mossy_cobblestone
setblock 416 101 194 minecraft:stone_bricks
fill 416 101 195 416 104 195 minecraft:mossy_cobblestone
setblock 417 101 193 minecraft:stone_bricks
fill 417 101 194 417 104 194 minecraft:mossy_cobblestone
setblock 417 101 198 minecraft:stone_bricks
fill 417 101 199 417 104 199 minecraft:mossy_cobblestone
setblock 377 102 192 minecraft:stone_bricks
fill 377 102 193 377 105 193 minecraft:mossy_cobblestone
setblock 377 102 197 minecraft:stone_bricks
fill 377 102 198 377 105 198 minecraft:mossy_cobblestone
fill 380 102 222 381 102 222 minecraft:mossy_cobblestone
fill 381 102 221 382 102 221 minecraft:mossy_cobblestone
setblock 382 102 182 minecraft:stone_bricks
setblock 382 102 222 minecraft:stone_bricks
fill 383 102 182 383 105 182 minecraft:mossy_cobblestone
setblock 383 102 220 minecraft:mossy_cobblestone
setblock 383 102 221 minecraft:stone_bricks
fill 383 102 222 383 105 222 minecraft:mossy_cobblestone
setblock 384 102 220 minecraft:stone_bricks
fill 384 102 221 384 105 221 minecraft:mossy_cobblestone
fill 385 102 220 385 105 220 minecraft:mossy_cobblestone
setblock 386 102 183 minecraft:stone_bricks
setblock 387 102 182 minecraft:stone_bricks
setblock 387 102 183 minecraft:mossy_cobblestone
setblock 387 102 222 minecraft:stone_bricks
fill 388 102 182 388 105 182 minecraft:mossy_cobblestone
setblock 388 102 221 minecraft:stone_bricks
fill 388 102 222 388 105 222 minecraft:mossy_cobblestone
setblock 389 102 220 minecraft:stone_bricks
fill 389 102 221 389 105 221 minecraft:mossy_cobblestone
setblock 390 102 220 minecraft:mossy_cobblestone
setblock 392 102 222 minecraft:stone_bricks
fill 393 102 222 396 102 222 minecraft:mossy_cobblestone
setblock 397 102 222 minecraft:stone_bricks
fill 398 102 222 398 105 222 minecraft:mossy_cobblestone
fill 401 102 221 402 102 221 minecraft:mossy_cobblestone
setblock 402 102 222 minecraft:stone_bricks
setblock 403 102 221 minecraft:stone_bricks
fill 403 102 222 403 105 222 minecraft:mossy_cobblestone
setblock 404 102 220 minecraft:stone_bricks
fill 404 102 221 404 105 221 minecraft:mossy_cobblestone
setblock 407 102 222 minecraft:stone_bricks
fill 408 102 222 408 105 222 minecraft:mossy_cobblestone
fill 416 102 194 416 103 194 minecraft:mossy_cobblestone
setblock 417 102 192 minecraft:stone_bricks
fill 417 102 193 417 105 193 minecraft:mossy_cobblestone
setblock 417 102 197 minecraft:stone_bricks
fill 417 102 198 417 105 198 minecraft:mossy_cobblestone
setblock 377 103 191 minecraft:stone_bricks
fill 377 103 192 377 106 192 minecraft:mossy_cobblestone
setblock 377 103 196 minecraft:stone_bricks
fill 377 103 197 377 106 197 minecraft:mossy_cobblestone
fill 379 103 182 379 104 182 minecraft:mossy_cobblestone
fill 379 103 222 380 103 222 minecraft:mossy_cobblestone
setblock 381 103 182 minecraft:stone_bricks
setblock 381 103 221 minecraft:mossy_cobblestone
setblock 381 103 222 minecraft:stone_bricks
fill 382 103 182 382 106 182 minecraft:mossy_cobblestone
setblock 382 103 221 minecraft:stone_bricks
fill 382 103 222 382 106 222 minecraft:mossy_cobblestone
setblock 383 103 220 minecraft:stone_bricks
fill 383 103 221 383 106 221 minecraft:mossy_cobblestone
fill 384 103 220 384 106 220 minecraft:mossy_cobblestone
setblock 385 103 183 minecraft:stone_bricks
setblock 386 103 182 minecraft:stone_bricks
fill 386 103 183 386 106 183 minecraft:mossy_cobblestone
setblock 386 103 222 minecraft:stone_bricks
fill 387 103 182 387 106 182 minecraft:mossy_cobblestone
setblock 387 103 221 minecraft:stone_bricks
fill 387 103 222 387 106 222 minecraft:mossy_cobblestone
setblock 388 103 220 minecraft:stone_bricks
fill 388 103 221 388 106 221 minecraft:mossy_cobblestone
fill 389 103 220 389 106 220 minecraft:mossy_cobblestone
setblock 391 103 222 minecraft:stone_bricks
setblock 392 103 221 minecraft:stone_bricks
fill 392 103 222 395 103 222 minecraft:mossy_cobblestone
setblock 396 103 222 minecraft:stone_bricks
fill 397 103 222 397 106 222 minecraft:mossy_cobblestone
fill 400 103 221 401 103 221 minecraft:mossy_cobblestone
setblock 401 103 222 minecraft:stone_bricks
setblock 402 103 221 minecraft:stone_bricks
fill 402 103 222 402 106 222 minecraft:mossy_cobblestone
setblock 403 103 220 minecraft:stone_bricks
fill 403 103 221 403 106 221 minecraft:mossy_cobblestone
fill 404 103 220 404 106 220 minecraft:mossy_cobblestone
setblock 406 103 222 minecraft:stone_bricks
setblock 407 103 221 minecraft:stone_bricks
fill 407 103 222 407 106 222 minecraft:mossy_cobblestone
setblock 416 103 197 minecraft:stone_bricks
setblock 417 103 191 minecraft:stone_bricks
fill 417 103 192 417 106 192 minecraft:mossy_cobblestone
setblock 417 103 196 minecraft:stone_bricks
fill 417 103 197 417 106 197 minecraft:mossy_cobblestone
setblock 417 103 201 minecraft:stone_bricks
fill 377 104 191 377 107 191 minecraft:mossy_cobblestone
setblock 377 104 195 minecraft:stone_bricks
fill 377 104 196 377 107 196 minecraft:mossy_cobblestone
setblock 377 104 199 minecraft:mossy_cobblestone
fill 378 104 182 378 105 182 minecraft:mossy_cobblestone
fill 378 104 222 379 104 222 minecraft:mossy_cobblestone
setblock 380 104 182 minecraft:stone_bricks
setblock 380 104 221 minecraft:mossy_cobblestone
setblock 380 104 222 minecraft:stone_bricks
fill 381 104 182 381 107 182 minecraft:mossy_cobblestone
setblock 381 104 221 minecraft:stone_bricks
fill 381 104 222 381 107 222 minecraft:mossy_cobblestone
fill 382 104 183 382 105 183 minecraft:mossy_cobblestone
setblock 382 104 220 minecraft:stone_bricks
fill 382 104 221 382 107 221 minecraft:mossy_cobblestone
fill 383 104 220 383 107 220 minecraft:mossy_cobblestone
setblock 384 104 183 minecraft:stone_bricks
setblock 385 104 182 minecraft:stone_bricks
fill 385 104 183 385 107 183 minecraft:mossy_cobblestone
setblock 385 104 222 minecraft:stone_bricks
fill 386 104 182 386 107 182 minecraft:mossy_cobblestone
setblock 386 104 221 minecraft:stone_bricks
fill 386 104 222 386 107 222 minecraft:mossy_cobblestone
setblock 387 104 220 minecraft:stone_bricks
fill 387 104 221 387 107 221 minecraft:mossy_cobblestone
fill 388 104 220 388 107 220 minecraft:mossy_cobblestone
setblock 390 104 222 minecraft:stone_bricks
setblock 391 104 221 minecraft:stone_bricks
fill 391 104 222 394 104 222 minecraft:mossy_cobblestone
fill 392 104 221 392 107 221 minecraft:mossy_cobblestone
setblock 395 104 222 minecraft:stone_bricks
fill 396 104 222 396 107 222 minecraft:mossy_cobblestone
fill 399 104 221 400 104 221 minecraft:mossy_cobblestone
setblock 400 104 222 minecraft:stone_bricks
setblock 401 104 221 minecraft:stone_bricks
fill 401 104 222 401 107 222 minecraft:mossy_cobblestone
setblock 402 104 220 minecraft:stone_bricks
fill 402 104 221 402 107 221 minecraft:mossy_cobblestone
fill 403 104 220 403 107 220 minecraft:mossy_cobblestone
setblock 405 104 222 minecraft:stone_bricks
setblock 406 104 221 minecraft:stone_bricks
fill 406 104 222 406 107 222 minecraft:mossy_cobblestone
fill 407 104 221 407 107 221 minecraft:mossy_cobblestone
setblock 416 104 196 minecraft:stone_bricks
fill 416 104 197 416 106 198 minecraft:mossy_cobblestone
fill 417 104 191 417 107 191 minecraft:mossy_cobblestone
setblock 417 104 195 minecraft:stone_bricks
fill 417 104 196 417 107 196 minecraft:mossy_cobblestone
setblock 417 104 200 minecraft:stone_bricks
fill 417 104 201 417 107 201 minecraft:mossy_cobblestone
fill 377 105 182 377 105 183 minecraft:mossy_cobblestone
setblock 377 105 194 minecraft:stone_bricks
fill 377 105 195 377 108 195 minecraft:mossy_cobblestone
setblock 377 105 199 minecraft:stone_bricks
fill 377 105 200 377 108 200 minecraft:mossy_cobblestone
fill 377 105 203 392 106 203 minecraft:stone_bricks
setblock 377 105 218 minecraft:mossy_cobblestone
setblock 377 105 219 minecraft:stone_bricks
fill 377 105 220 377 106 222 minecraft:mossy_cobblestone
setblock 378 105 222 minecraft:mossy_cobblestone
setblock 379 105 182 minecraft:stone_bricks
setblock 379 105 184 minecraft:light[level=12]
setblock 379 105 192 minecraft:light[level=12]
setblock 379 105 200 minecraft:light[level=12]
setblock 379 105 208 minecraft:light[level=12]
setblock 379 105 216 minecraft:light[level=12]
setblock 379 105 221 minecraft:mossy_cobblestone
setblock 379 105 222 minecraft:stone_bricks
fill 380 105 182 380 107 183 minecraft:mossy_cobblestone
setblock 380 105 221 minecraft:stone_bricks
fill 380 105 222 380 108 222 minecraft:mossy_cobblestone
fill 381 105 183 381 106 183 minecraft:mossy_cobblestone
setblock 381 105 220 minecraft:stone_bricks
fill 381 105 221 381 108 221 minecraft:mossy_cobblestone
fill 382 105 220 382 108 220 minecraft:mossy_cobblestone
setblock 383 105 183 minecraft:stone_bricks
setblock 384 105 182 minecraft:stone_bricks
fill 384 105 183 384 108 183 minecraft:mossy_cobblestone
setblock 384 105 222 minecraft:stone_bricks
fill 385 105 182 385 108 182 minecraft:mossy_cobblestone
setblock 385 105 221 minecraft:stone_bricks
fill 385 105 222 385 108 222 minecraft:mossy_cobblestone
setblock 386 105 220 minecraft:stone_bricks
fill 386 105 221 386 108 221 minecraft:mossy_cobblestone
setblock 387 105 184 minecraft:light[level=12]
setblock 387 105 192 minecraft:light[level=12]
setblock 387 105 200 minecraft:light[level=12]
setblock 387 105 208 minecraft:light[level=12]
setblock 387 105 216 minecraft:light[level=12]
fill 387 105 220 387 108 220 minecraft:mossy_cobblestone
setblock 389 105 182 minecraft:stone_bricks
setblock 389 105 222 minecraft:stone_bricks
setblock 390 105 221 minecraft:stone_bricks
fill 390 105 222 393 105 222 minecraft:mossy_cobblestone
fill 391 105 221 391 108 221 minecraft:mossy_cobblestone
setblock 394 105 222 minecraft:stone_bricks
setblock 395 105 184 minecraft:light[level=12]
setblock 395 105 192 minecraft:light[level=12]
setblock 395 105 200 minecraft:light[level=12]
setblock 395 105 208 minecraft:light[level=12]
setblock 395 105 216 minecraft:light[level=12]
fill 395 105 222 395 108 222 minecraft:mossy_cobblestone
fill 397 105 221 399 105 221 minecraft:mossy_cobblestone
setblock 399 105 222 minecraft:stone_bricks
setblock 400 105 221 minecraft:stone_bricks
fill 400 105 222 400 108 222 minecraft:mossy_cobblestone
setblock 401 105 220 minecraft:stone_bricks
fill 401 105 221 401 108 221 minecraft:mossy_cobblestone
fill 402 105 220 402 108 220 minecraft:mossy_cobblestone
setblock 403 105 184 minecraft:light[level=12]
setblock 403 105 192 minecraft:light[level=12]
setblock 403 105 200 minecraft:light[level=12]
setblock 403 105 208 minecraft:light[level=12]
setblock 403 105 216 minecraft:light[level=12]
setblock 404 105 222 minecraft:stone_bricks
setblock 405 105 221 minecraft:stone_bricks
fill 405 105 222 405 108 222 minecraft:mossy_cobblestone
fill 406 105 221 406 108 221 minecraft:mossy_cobblestone
setblock 411 105 184 minecraft:light[level=12]
setblock 411 105 192 minecraft:light[level=12]
setblock 411 105 200 minecraft:light[level=12]
setblock 411 105 208 minecraft:light[level=12]
setblock 411 105 216 minecraft:light[level=12]
setblock 416 105 195 minecraft:stone_bricks
fill 416 105 196 416 108 196 minecraft:mossy_cobblestone
setblock 416 105 199 minecraft:mossy_cobblestone
setblock 417 105 194 minecraft:stone_bricks
fill 417 105 195 417 108 195 minecraft:mossy_cobblestone
setblock 417 105 199 minecraft:stone_bricks
fill 417 105 200 417 108 200 minecraft:mossy_cobblestone
fill 417 105 202 417 106 202 minecraft:mossy_cobblestone
setblock 377 106 182 minecraft:mossy_cobblestone
setblock 377 106 183 minecraft:stone_bricks
fill 377 106 184 377 108 185 minecraft:mossy_cobblestone
setblock 377 106 193 minecraft:stone_bricks
fill 377 106 194 377 109 194 minecraft:mossy_cobblestone
setblock 377 106 198 minecraft:stone_bricks
fill 377 106 199 377 109 199 minecraft:mossy_cobblestone
fill 377 106 201 377 107 201 minecraft:mossy_cobblestone
setblock 377 106 217 minecraft:mossy_cobblestone
setblock 377 106 218 minecraft:stone_bricks
fill 377 106 219 378 108 219 minecraft:mossy_cobblestone
setblock 378 106 182 minecraft:stone_bricks
fill 378 106 195 378 106 196 minecraft:mossy_cobblestone
setblock 378 106 197 minecraft:stone_bricks
fill 378 106 198 378 109 198 minecraft:mossy_cobblestone
fill 378 106 220 378 106 221 minecraft:mossy_cobblestone
setblock 378 106 222 minecraft:stone_bricks
fill 379 106 182 379 108 183 minecraft:mossy_cobblestone
setblock 379 106 221 minecraft:stone_bricks
fill 379 106 222 379 109 222 minecraft:mossy_cobblestone
setblock 380 106 220 minecraft:stone_bricks
fill 380 106 221 380 109 221 minecraft:mossy_cobblestone
fill 381 106 220 381 109 220 minecraft:mossy_cobblestone
setblock 382 106 183 minecraft:stone_bricks
fill 382 106 204 398 106 204 minecraft:stone_bricks
setblock 383 106 182 minecraft:stone_bricks
fill 383 106 183 383 109 183 minecraft:mossy_cobblestone
setblock 383 106 222 minecraft:stone_bricks
fill 384 106 182 384 109 182 minecraft:mossy_cobblestone
fill 384 106 219 385 106 219 minecraft:mossy_cobblestone
setblock 384 106 221 minecraft:stone_bricks
fill 384 106 222 384 109 222 minecraft:mossy_cobblestone
setblock 385 106 220 minecraft:stone_bricks
fill 385 106 221 385 109 221 minecraft:mossy_cobblestone
fill 386 106 220 386 109 220 minecraft:mossy_cobblestone
setblock 388 106 182 minecraft:stone_bricks
setblock 388 106 222 minecraft:stone_bricks
fill 389 106 182 389 109 182 minecraft:mossy_cobblestone
setblock 389 106 221 minecraft:stone_bricks
fill 389 106 222 392 106 222 minecraft:mossy_cobblestone
fill 390 106 221 390 109 221 minecraft:mossy_cobblestone
fill 393 106 203 398 106 203 minecraft:stone_bricks
setblock 393 106 221 minecraft:mossy_cobblestone
setblock 393 106 222 minecraft:stone_bricks
setblock 394 106 221 minecraft:stone_bricks
fill 394 106 222 394 109 222 minecraft:mossy_cobblestone
fill 395 106 221 398 106 221 minecraft:mossy_cobblestone
setblock 398 106 222 minecraft:stone_bricks
setblock 399 106 220 minecraft:mossy_cobblestone
setblock 399 106 221 minecraft:stone_bricks
fill 399 106 222 399 109 222 minecraft:mossy_cobblestone
setblock 400 106 220 minecraft:stone_bricks
fill 400 106 221 400 109 221 minecraft:mossy_cobblestone
fill 401 106 182 402 106 182 minecraft:mossy_cobblestone
fill 401 106 220 401 109 220 minecraft:mossy_cobblestone
setblock 403 106 182 minecraft:stone_bricks
setblock 403 106 222 minecraft:stone_bricks
fill 404 106 182 405 108 182 minecraft:mossy_cobblestone
setblock 404 106 221 minecraft:stone_bricks
fill 404 106 222 404 109 222 minecraft:mossy_cobblestone
fill 405 106 204 417 106 204 minecraft:stone_bricks
fill 405 106 221 405 109 221 minecraft:mossy_cobblestone
fill 406 106 203 409 106 203 minecraft:stone_bricks
setblock 408 106 222 minecraft:stone_bricks
fill 415 106 205 416 106 205 minecraft:stone_bricks
fill 416 106 195 416 109 195 minecraft:mossy_cobblestone
setblock 416 106 199 minecraft:stone_bricks
fill 416 106 200 416 109 200 minecraft:mossy_cobblestone
setblock 417 106 193 minecraft:stone_bricks
fill 417 106 194 417 109 194 minecraft:mossy_cobblestone
setblock 417 106 198 minecraft:stone_bricks
fill 417 106 199 417 109 199 minecraft:mossy_cobblestone
setblock 417 106 203 minecraft:stone_bricks
setblock 377 107 182 minecraft:stone_bricks
fill 377 107 183 378 109 183 minecraft:mossy_cobblestone
setblock 377 107 186 minecraft:mossy_cobblestone
setblock 377 107 187 minecraft:stone_bricks
fill 377 107 188 377 108 190 minecraft:mossy_cobblestone
setblock 377 107 192 minecraft:stone_bricks
fill 377 107 193 377 110 193 minecraft:mossy_cobblestone
setblock 377 107 197 minecraft:stone_bricks
fill 377 107 198 377 110 198 minecraft:mossy_cobblestone
setblock 377 107 202 minecraft:stone_bricks
fill 377 107 203 393 107 203 minecraft:spruce_planks
setblock 377 107 217 minecraft:stone_bricks
fill 377 107 218 378 109 218 minecraft:mossy_cobblestone
fill 377 107 220 377 107 221 minecraft:mossy_cobblestone
setblock 377 107 222 minecraft:stone_bricks
fill 378 107 182 378 110 182 minecraft:mossy_cobblestone
fill 378 107 184 378 108 184 minecraft:mossy_cobblestone
setblock 378 107 195 minecraft:mossy_cobblestone
setblock 378 107 196 minecraft:stone_bricks
fill 378 107 197 378 110 197 minecraft:mossy_cobblestone
fill 378 107 199 378 107 200 minecraft:mossy_cobblestone
setblock 378 107 220 minecraft:mossy_cobblestone
setblock 378 107 221 minecraft:stone_bricks
fill 378 107 222 378 110 222 minecraft:mossy_cobblestone
setblock 379 107 219 minecraft:mossy_cobblestone
setblock 379 107 220 minecraft:stone_bricks
fill 379 107 221 379 110 221 minecraft:mossy_cobblestone
fill 380 107 220 380 110 220 minecraft:mossy_cobblestone
setblock 381 107 183 minecraft:stone_bricks
setblock 382 107 182 minecraft:stone_bricks
fill 382 107 183 382 109 184 minecraft:mossy_cobblestone
fill 382 107 219 384 107 219 minecraft:mossy_cobblestone
setblock 382 107 222 minecraft:stone_bricks
fill 383 107 182 383 110 182 minecraft:mossy_cobblestone
setblock 383 107 221 minecraft:stone_bricks
fill 383 107 222 383 110 222 minecraft:mossy_cobblestone
setblock 384 107 220 minecraft:stone_bricks
fill 384 107 221 384 110 221 minecraft:mossy_cobblestone
setblock 385 107 219 minecraft:stone_bricks
fill 385 107 220 385 110 220 minecraft:mossy_cobblestone
setblock 386 107 183 minecraft:stone_bricks
setblock 387 107 182 minecraft:stone_bricks
fill 387 107 183 387 110 183 minecraft:mossy_cobblestone
setblock 387 107 222 minecraft:stone_bricks
fill 388 107 182 388 110 182 minecraft:mossy_cobblestone
setblock 388 107 221 minecraft:stone_bricks
fill 388 107 222 391 107 222 minecraft:mossy_cobblestone
setblock 389 107 220 minecraft:stone_bricks
fill 389 107 221 389 110 221 minecraft:mossy_cobblestone
fill 390 107 182 390 108 182 minecraft:mossy_cobblestone
setblock 392 107 222 minecraft:stone_bricks
setblock 393 107 221 minecraft:stone_bricks
fill 393 107 222 393 110 222 minecraft:mossy_cobblestone
fill 394 107 221 397 107 221 minecraft:mossy_cobblestone
setblock 397 107 222 minecraft:stone_bricks
setblock 398 107 220 minecraft:mossy_cobblestone
setblock 398 107 221 minecraft:stone_bricks
fill 398 107 222 398 110 222 minecraft:mossy_cobblestone
fill 399 107 182 401 107 182 minecraft:mossy_cobblestone
setblock 399 107 220 minecraft:stone_bricks
fill 399 107 221 399 110 221 minecraft:mossy_cobblestone
fill 400 107 220 400 110 220 minecraft:mossy_cobblestone
setblock 402 107 182 minecraft:stone_bricks
setblock 402 107 222 minecraft:stone_bricks
fill 403 107 182 403 110 182 minecraft:mossy_cobblestone
setblock 403 107 221 minecraft:stone_bricks
fill 403 107 222 403 110 222 minecraft:mossy_cobblestone
setblock 404 107 220 minecraft:stone_bricks
fill 404 107 221 404 110 221 minecraft:mossy_cobblestone
fill 405 107 204 416 107 204 minecraft:stone_bricks
setblock 406 107 182 minecraft:mossy_cobblestone
setblock 407 107 182 minecraft:stone_bricks
setblock 407 107 222 minecraft:stone_bricks
fill 408 107 222 409 109 222 minecraft:mossy_cobblestone
setblock 416 107 182 minecraft:mossy_cobblestone
fill 416 107 194 416 110 194 minecraft:mossy_cobblestone
setblock 416 107 197 minecraft:mossy_cobblestone
setblock 416 107 198 minecraft:stone_bricks
fill 416 107 199 416 110 199 minecraft:mossy_cobblestone
fill 416 107 201 416 108 201 minecraft:mossy_cobblestone
setblock 416 107 205 minecraft:stone_bricks
setblock 417 107 182 minecraft:stone_bricks
fill 417 107 183 417 108 185 minecraft:mossy_cobblestone
fill 417 107 189 417 108 190 minecraft:mossy_cobblestone
setblock 417 107 192 minecraft:stone_bricks
fill 417 107 193 417 110 193 minecraft:mossy_cobblestone
setblock 417 107 197 minecraft:stone_bricks
fill 417 107 198 417 110 198 minecraft:mossy_cobblestone
setblock 417 107 202 minecraft:stone_bricks
fill 417 107 203 417 109 204 minecraft:mossy_cobblestone
fill 417 107 219 417 107 221 minecraft:mossy_cobblestone
setblock 417 107 222 minecraft:stone_bricks
fill 377 108 182 377 111 182 minecraft:mossy_cobblestone
setblock 377 108 186 minecraft:stone_bricks
fill 377 108 187 377 111 187 minecraft:mossy_cobblestone
setblock 377 108 191 minecraft:stone_bricks
fill 377 108 192 377 111 192 minecraft:mossy_cobblestone
setblock 377 108 196 minecraft:stone_bricks
fill 377 108 197 377 111 197 minecraft:mossy_cobblestone
setblock 377 108 201 minecraft:stone_bricks
fill 377 108 202 377 109 204 minecraft:mossy_cobblestone
setblock 377 108 216 minecraft:stone_bricks
fill 377 108 217 378 110 217 minecraft:mossy_cobblestone
setblock 377 108 220 minecraft:mossy_cobblestone
setblock 377 108 221 minecraft:stone_bricks
fill 377 108 222 377 111 222 minecraft:mossy_cobblestone
setblock 378 108 185 minecraft:stone_bricks
fill 378 108 186 378 111 186 minecraft:mossy_cobblestone
setblock 378 108 194 minecraft:mossy_cobblestone
setblock 378 108 195 minecraft:stone_bricks
fill 378 108 196 378 111 196 minecraft:mossy_cobblestone
setblock 378 108 199 minecraft:mossy_cobblestone
setblock 378 108 200 minecraft:stone_bricks
fill 378 108 201 378 111 201 minecraft:mossy_cobblestone
setblock 378 108 220 minecraft:stone_bricks
fill 378 108 221 378 111 221 minecraft:mossy_cobblestone
setblock 379 108 184 minecraft:stone_bricks
setblock 379 108 218 minecraft:mossy_cobblestone
setblock 379 108 219 minecraft:stone_bricks
fill 379 108 220 379 111 220 minecraft:mossy_cobblestone
setblock 380 108 182 minecraft:mossy_cobblestone
setblock 380 108 183 minecraft:stone_bricks
fill 380 108 184 381 110 184 minecraft:mossy_cobblestone
setblock 381 108 182 minecraft:stone_bricks
fill 381 108 183 381 111 183 minecraft:mossy_cobblestone
fill 381 108 219 383 108 219 minecraft:mossy_cobblestone
setblock 381 108 222 minecraft:stone_bricks
fill 382 108 182 382 111 182 minecraft:mossy_cobblestone
setblock 382 108 221 minecraft:stone_bricks
fill 382 108 222 382 111 222 minecraft:mossy_cobblestone
setblock 383 108 184 minecraft:mossy_cobblestone
setblock 383 108 220 minecraft:stone_bricks
fill 383 108 221 383 111 221 minecraft:mossy_cobblestone
setblock 384 108 184 minecraft:stone_bricks
setblock 384 108 219 minecraft:stone_bricks
fill 384 108 220 384 111 220 minecraft:mossy_cobblestone
setblock 385 108 183 minecraft:stone_bricks
fill 385 108 219 385 109 219 minecraft:mossy_cobblestone
setblock 386 108 182 minecraft:stone_bricks
fill 386 108 183 386 111 183 minecraft:mossy_cobblestone
setblock 386 108 222 minecraft:stone_bricks
fill 387 108 182 387 111 182 minecraft:mossy_cobblestone
setblock 387 108 221 minecraft:stone_bricks
fill 387 108 222 390 108 222 minecraft:mossy_cobblestone
setblock 388 108 220 minecraft:stone_bricks
fill 388 108 221 388 111 221 minecraft:mossy_cobblestone
fill 389 108 220 389 110 220 minecraft:mossy_cobblestone
setblock 391 108 182 minecraft:stone_bricks
setblock 391 108 222 minecraft:stone_bricks
setblock 392 108 221 minecraft:stone_bricks
fill 392 108 222 392 111 222 minecraft:mossy_cobblestone
fill 393 108 221 396 108 221 minecraft:mossy_cobblestone
setblock 396 108 222 minecraft:stone_bricks
fill 397 108 182 400 108 182 minecraft:mossy_cobblestone
setblock 397 108 220 minecraft:mossy_cobblestone
setblock 397 108 221 minecraft:stone_bricks
fill 397 108 222 397 111 222 minecraft:mossy_cobblestone
setblock 398 108 220 minecraft:stone_bricks
fill 398 108 221 398 111 221 minecraft:mossy_cobblestone
fill 399 108 220 399 111 220 minecraft:mossy_cobblestone
setblock 401 108 182 minecraft:stone_bricks
setblock 401 108 222 minecraft:stone_bricks
fill 402 108 182 402 111 182 minecraft:mossy_cobblestone
setblock 402 108 221 minecraft:stone_bricks
fill 402 108 222 402 111 222 minecraft:mossy_cobblestone
setblock 403 108 220 minecraft:stone_bricks
fill 403 108 221 403 111 221 minecraft:mossy_cobblestone
fill 404 108 220 404 109 220 minecraft:mossy_cobblestone
fill 405 108 204 416 108 204 minecraft:spruce_planks
setblock 406 108 182 minecraft:stone_bricks
setblock 406 108 222 minecraft:stone_bricks
fill 407 108 182 408 110 182 minecraft:mossy_cobblestone
setblock 407 108 221 minecraft:stone_bricks
fill 407 108 222 407 111 222 minecraft:mossy_cobblestone
fill 414 108 182 415 108 182 minecraft:mossy_cobblestone
setblock 415 108 222 minecraft:mossy_cobblestone
setblock 416 108 182 minecraft:stone_bricks
setblock 416 108 197 minecraft:stone_bricks
fill 416 108 198 416 111 198 minecraft:mossy_cobblestone
setblock 416 108 202 minecraft:stone_bricks
fill 416 108 203 416 111 203 minecraft:mossy_cobblestone
setblock 416 108 222 minecraft:stone_bricks
fill 417 108 182 417 111 182 minecraft:mossy_cobblestone
setblock 417 108 186 minecraft:stone_bricks
fill 417 108 187 417 110 188 minecraft:mossy_cobblestone
setblock 417 108 191 minecraft:stone_bricks
fill 417 108 192 417 111 192 minecraft:mossy_cobblestone
setblock 417 108 196 minecraft:stone_bricks
fill 417 108 197 417 111 197 minecraft:mossy_cobblestone
setblock 417 108 201 minecraft:stone_bricks
fill 417 108 202 417 111 202 minecraft:mossy_cobblestone
setblock 417 108 205 minecraft:mossy_cobblestone
fill 417 108 218 417 108 220 minecraft:mossy_cobblestone
setblock 417 108 221 minecraft:stone_bricks
fill 417 108 222 417 111 222 minecraft:mossy_cobblestone
setblock 377 109 184 minecraft:mossy_cobblestone
setblock 377 109 185 minecraft:stone_bricks
fill 377 109 186 377 112 186 minecraft:mossy_cobblestone
fill 377 109 188 377 109 189 minecraft:mossy_cobblestone
setblock 377 109 190 minecraft:stone_bricks
fill 377 109 191 377 112 191 minecraft:mossy_cobblestone
setblock 377 109 195 minecraft:stone_bricks
fill 377 109 196 377 112 196 minecraft:mossy_cobblestone
setblock 377 109 200 minecraft:stone_bricks
fill 377 109 201 377 112 201 minecraft:mossy_cobblestone
setblock 377 109 205 minecraft:stone_bricks
setblock 377 109 215 minecraft:stone_bricks
fill 377 109 216 377 112 216 minecraft:mossy_cobblestone
setblock 377 109 219 minecraft:mossy_cobblestone
setblock 377 109 220 minecraft:stone_bricks
fill 377 109 221 377 112 221 minecraft:mossy_cobblestone
setblock 378 109 184 minecraft:stone_bricks
fill 378 109 185 379 111 185 minecraft:mossy_cobblestone
fill 378 109 187 378 109 188 minecraft:mossy_cobblestone
setblock 378 109 194 minecraft:stone_bricks
fill 378 109 195 378 111 195 minecraft:mossy_cobblestone
setblock 378 109 199 minecraft:stone_bricks
fill 378 109 200 378 112 200 minecraft:mossy_cobblestone
fill 378 109 202 378 109 203 minecraft:mossy_cobblestone
setblock 378 109 219 minecraft:stone_bricks
fill 378 109 220 378 112 220 minecraft:mossy_cobblestone
setblock 379 109 182 minecraft:mossy_cobblestone
setblock 379 109 183 minecraft:stone_bricks
fill 379 109 184 379 112 184 minecraft:mossy_cobblestone
setblock 379 109 218 minecraft:stone_bricks
fill 379 109 219 382 109 219 minecraft:mossy_cobblestone
setblock 380 109 182 minecraft:stone_bricks
fill 380 109 183 380 112 183 minecraft:mossy_cobblestone
setblock 380 109 222 minecraft:stone_bricks
fill 381 109 182 381 112 182 minecraft:mossy_cobblestone
setblock 381 109 221 minecraft:stone_bricks
fill 381 109 222 381 112 222 minecraft:mossy_cobblestone
setblock 382 109 220 minecraft:stone_bricks
fill 382 109 221 382 112 221 minecraft:mossy_cobblestone
setblock 383 109 184 minecraft:stone_bricks
setblock 383 109 219 minecraft:stone_bricks
fill 383 109 220 383 112 220 minecraft:mossy_cobblestone
setblock 384 109 183 minecraft:stone_bricks
fill 384 109 184 384 112 184 minecraft:mossy_cobblestone
fill 384 109 219 384 110 219 minecraft:mossy_cobblestone
setblock 385 109 182 minecraft:stone_bricks
fill 385 109 183 385 112 183 minecraft:mossy_cobblestone
setblock 385 109 222 minecraft:stone_bricks
fill 386 109 182 386 112 182 minecraft:mossy_cobblestone
setblock 386 109 221 minecraft:stone_bricks
fill 386 109 222 389 109 222 minecraft:mossy_cobblestone
setblock 387 109 220 minecraft:stone_bricks
fill 387 109 221 387 112 221 minecraft:mossy_cobblestone
fill 388 109 220 388 111 220 minecraft:mossy_cobblestone
setblock 390 109 182 minecraft:stone_bricks
setblock 390 109 222 minecraft:stone_bricks
fill 391 109 182 394 109 182 minecraft:mossy_cobblestone
setblock 391 109 221 minecraft:stone_bricks
fill 391 109 222 391 112 222 minecraft:mossy_cobblestone
fill 392 109 221 395 109 221 minecraft:mossy_cobblestone
setblock 395 109 182 minecraft:stone_bricks
setblock 395 109 222 minecraft:stone_bricks
fill 396 109 182 399 109 182 minecraft:mossy_cobblestone
setblock 396 109 220 minecraft:mossy_cobblestone
setblock 396 109 221 minecraft:stone_bricks
fill 396 109 222 396 112 222 minecraft:mossy_cobblestone
setblock 397 109 220 minecraft:stone_bricks
fill 397 109 221 397 112 221 minecraft:mossy_cobblestone
fill 398 109 220 398 112 220 minecraft:mossy_cobblestone
setblock 400 109 182 minecraft:stone_bricks
fill 400 109 183 403 109 183 minecraft:mossy_cobblestone
setblock 400 109 222 minecraft:stone_bricks
fill 401 109 182 401 112 182 minecraft:mossy_cobblestone
setblock 401 109 221 minecraft:stone_bricks
fill 401 109 222 401 112 222 minecraft:mossy_cobblestone
setblock 402 109 220 minecraft:stone_bricks
fill 402 109 221 402 112 221 minecraft:mossy_cobblestone
fill 403 109 220 403 111 220 minecraft:mossy_cobblestone
setblock 404 109 182 minecraft:mossy_cobblestone
setblock 404 109 183 minecraft:stone_bricks
setblock 405 109 182 minecraft:stone_bricks
setblock 405 109 222 minecraft:stone_bricks
fill 406 109 182 406 112 182 minecraft:mossy_cobblestone
setblock 406 109 221 minecraft:stone_bricks
fill 406 109 222 406 112 222 minecraft:mossy_cobblestone
setblock 407 109 221 minecraft:mossy_cobblestone
setblock 409 109 182 minecraft:mossy_cobblestone
setblock 410 109 182 minecraft:stone_bricks
setblock 410 109 222 minecraft:stone_bricks
fill 411 109 182 414 109 182 minecraft:mossy_cobblestone
setblock 414 109 222 minecraft:mossy_cobblestone
setblock 415 109 182 minecraft:stone_bricks
fill 415 109 198 415 110 200 minecraft:mossy_cobblestone
setblock 415 109 222 minecraft:stone_bricks
fill 416 109 182 416 110 184 minecraft:mossy_cobblestone
fill 416 109 193 416 111 193 minecraft:mossy_cobblestone
setblock 416 109 196 minecraft:stone_bricks
fill 416 109 197 416 112 197 minecraft:mossy_cobblestone
setblock 416 109 201 minecraft:stone_bricks
fill 416 109 202 416 112 202 minecraft:mossy_cobblestone
fill 416 109 204 416 110 204 minecraft:mossy_cobblestone
fill 416 109 222 416 112 222 minecraft:mossy_cobblestone
fill 417 109 183 417 109 184 minecraft:mossy_cobblestone
setblock 417 109 185 minecraft:stone_bricks
fill 417 109 186 417 112 186 minecraft:mossy_cobblestone
setblock 417 109 189 minecraft:mossy_cobblestone
setblock 417 109 190 minecraft:stone_bricks
fill 417 109 191 417 112 191 minecraft:mossy_cobblestone
setblock 417 109 195 minecraft:stone_bricks
fill 417 109 196 417 112 196 minecraft:mossy_cobblestone
setblock 417 109 200 minecraft:stone_bricks
fill 417 109 201 417 112 201 minecraft:mossy_cobblestone
setblock 417 109 205 minecraft:stone_bricks
fill 417 109 206 417 112 206 minecraft:mossy_cobblestone
fill 417 109 217 417 109 219 minecraft:mossy_cobblestone
setblock 417 109 220 minecraft:stone_bricks
fill 417 109 221 417 112 221 minecraft:mossy_cobblestone
setblock 377 110 183 minecraft:mossy_cobblestone
setblock 377 110 184 minecraft:stone_bricks
fill 377 110 185 377 113 185 minecraft:mossy_cobblestone
setblock 377 110 188 minecraft:mossy_cobblestone
setblock 377 110 189 minecraft:stone_bricks
fill 377 110 190 378 112 190 minecraft:mossy_cobblestone
setblock 377 110 194 minecraft:stone_bricks
fill 377 110 195 377 113 195 minecraft:mossy_cobblestone
setblock 377 110 199 minecraft:stone_bricks
fill 377 110 200 377 113 200 minecraft:mossy_cobblestone
fill 377 110 202 377 110 203 minecraft:mossy_cobblestone
setblock 377 110 204 minecraft:stone_bricks
fill 377 110 205 377 111 207 minecraft:mossy_cobblestone
fill 377 110 215 377 113 215 minecraft:mossy_cobblestone
setblock 377 110 218 minecraft:mossy_cobblestone
setblock 377 110 219 minecraft:stone_bricks
fill 377 110 220 377 113 220 minecraft:mossy_cobblestone
setblock 378 110 183 minecraft:stone_bricks
fill 378 110 184 378 113 184 minecraft:mossy_cobblestone
setblock 378 110 187 minecraft:mossy_cobblestone
setblock 378 110 188 minecraft:stone_bricks
fill 378 110 189 378 113 189 minecraft:mossy_cobblestone
setblock 378 110 193 minecraft:stone_bricks
fill 378 110 194 378 111 194 minecraft:mossy_cobblestone
setblock 378 110 198 minecraft:stone_bricks
fill 378 110 199 379 111 199 minecraft:mossy_cobblestone
setblock 378 110 202 minecraft:mossy_cobblestone
setblock 378 110 203 minecraft:stone_bricks
fill 378 110 204 378 112 205 minecraft:mossy_cobblestone
fill 378 110 216 378 111 216 minecraft:mossy_cobblestone
setblock 378 110 218 minecraft:stone_bricks
fill 378 110 219 381 110 219 minecraft:mossy_cobblestone
setblock 379 110 182 minecraft:stone_bricks
fill 379 110 183 379 113 183 minecraft:mossy_cobblestone
setblock 379 110 186 minecraft:mossy_cobblestone
fill 379 110 200 379 110 201 minecraft:mossy_cobblestone
fill 379 110 218 379 113 218 minecraft:mossy_cobblestone
setblock 379 110 222 minecraft:stone_bricks
fill 380 110 182 380 113 182 minecraft:mossy_cobblestone
setblock 380 110 221 minecraft:stone_bricks
fill 380 110 222 380 113 222 minecraft:mossy_cobblestone
setblock 381 110 220 minecraft:stone_bricks
fill 381 110 221 381 113 221 minecraft:mossy_cobblestone
setblock 382 110 183 minecraft:mossy_cobblestone
setblock 382 110 184 minecraft:stone_bricks
setblock 382 110 219 minecraft:stone_bricks
fill 382 110 220 382 113 220 minecraft:mossy_cobblestone
setblock 383 110 183 minecraft:stone_bricks
fill 383 110 184 383 113 184 minecraft:mossy_cobblestone
fill 383 110 219 383 111 219 minecraft:mossy_cobblestone
setblock 384 110 182 minecraft:stone_bricks
fill 384 110 183 384 113 183 minecraft:mossy_cobblestone
setblock 384 110 222 minecraft:stone_bricks
fill 385 110 182 385 113 182 minecraft:mossy_cobblestone
setblock 385 110 221 minecraft:stone_bricks
fill 385 110 222 388 110 222 minecraft:mossy_cobblestone
setblock 386 110 220 minecraft:stone_bricks
fill 386 110 221 386 113 221 minecraft:mossy_cobblestone
fill 387 110 220 387 111 220 minecraft:mossy_cobblestone
setblock 388 110 183 minecraft:stone_bricks
setblock 389 110 182 minecraft:stone_bricks
setblock 389 110 222 minecraft:stone_bricks
fill 390 110 182 393 110 182 minecraft:mossy_cobblestone
setblock 390 110 221 minecraft:stone_bricks
fill 390 110 222 390 113 222 minecraft:mossy_cobblestone
fill 391 110 221 394 110 221 minecraft:mossy_cobblestone
setblock 394 110 182 minecraft:stone_bricks
setblock 394 110 222 minecraft:stone_bricks
fill 395 110 182 398 110 182 minecraft:mossy_cobblestone
setblock 395 110 220 minecraft:mossy_cobblestone
setblock 395 110 221 minecraft:stone_bricks
fill 395 110 222 395 113 222 minecraft:mossy_cobblestone
setblock 396 110 220 minecraft:stone_bricks
fill 396 110 221 396 113 221 minecraft:mossy_cobblestone
fill 397 110 220 397 112 220 minecraft:mossy_cobblestone
setblock 398 110 183 minecraft:stone_bricks
setblock 399 110 182 minecraft:stone_bricks
fill 399 110 183 402 110 183 minecraft:mossy_cobblestone
setblock 399 110 222 minecraft:stone_bricks
fill 400 110 182 400 113 182 minecraft:mossy_cobblestone
setblock 400 110 221 minecraft:stone_bricks
fill 400 110 222 400 113 222 minecraft:mossy_cobblestone
setblock 401 110 220 minecraft:stone_bricks
fill 401 110 221 401 113 221 minecraft:mossy_cobblestone
fill 402 110 220 402 111 220 minecraft:mossy_cobblestone
setblock 403 110 183 minecraft:stone_bricks
setblock 404 110 182 minecraft:stone_bricks
fill 404 110 183 405 112 183 minecraft:mossy_cobblestone
setblock 404 110 222 minecraft:stone_bricks
fill 405 110 182 405 113 182 minecraft:mossy_cobblestone
setblock 405 110 221 minecraft:stone_bricks
fill 405 110 222 405 113 222 minecraft:mossy_cobblestone
setblock 406 110 221 minecraft:mossy_cobblestone
setblock 408 110 222 minecraft:mossy_cobblestone
setblock 409 110 182 minecraft:stone_bricks
setblock 409 110 222 minecraft:stone_bricks
fill 410 110 182 413 110 182 minecraft:mossy_cobblestone
fill 410 110 222 410 111 222 minecraft:mossy_cobblestone
fill 412 110 222 413 110 222 minecraft:mossy_cobblestone
setblock 414 110 182 minecraft:stone_bricks
fill 414 110 183 415 112 183 minecraft:mossy_cobblestone
setblock 414 110 222 minecraft:stone_bricks
fill 415 110 182 415 113 182 minecraft:mossy_cobblestone
setblock 415 110 201 minecraft:stone_bricks
fill 415 110 202 415 113 202 minecraft:mossy_cobblestone
fill 415 110 222 415 113 222 minecraft:mossy_cobblestone
setblock 416 110 185 minecraft:stone_bricks
fill 416 110 186 416 111 188 minecraft:mossy_cobblestone
fill 416 110 192 416 112 192 minecraft:mossy_cobblestone
setblock 416 110 195 minecraft:stone_bricks
fill 416 110 196 416 113 196 minecraft:mossy_cobblestone
setblock 416 110 200 minecraft:stone_bricks
fill 416 110 201 416 113 201 minecraft:mossy_cobblestone
setblock 416 110 205 minecraft:stone_bricks
fill 416 110 221 416 113 221 minecraft:mossy_cobblestone
setblock 417 110 183 minecraft:mossy_cobblestone
setblock 417 110 184 minecraft:stone_bricks
fill 417 110 185 417 113 185 minecraft:mossy_cobblestone
setblock 417 110 189 minecraft:stone_bricks
fill 417 110 190 417 113 190 minecraft:mossy_cobblestone
setblock 417 110 194 minecraft:stone_bricks
fill 417 110 195 417 113 195 minecraft:mossy_cobblestone
setblock 417 110 199 minecraft:stone_bricks
fill 417 110 200 417 113 200 minecraft:mossy_cobblestone
setblock 417 110 203 minecraft:mossy_cobblestone
setblock 417 110 204 minecraft:stone_bricks
fill 417 110 205 417 113 205 minecraft:mossy_cobblestone
fill 417 110 207 417 110 208 minecraft:mossy_cobblestone
fill 417 110 217 417 110 218 minecraft:mossy_cobblestone
setblock 417 110 219 minecraft:stone_bricks
fill 417 110 220 417 113 220 minecraft:mossy_cobblestone
setblock 377 111 183 minecraft:stone_bricks
fill 377 111 184 377 114 184 minecraft:mossy_cobblestone
setblock 377 111 188 minecraft:stone_bricks
fill 377 111 189 377 114 189 minecraft:mossy_cobblestone
setblock 377 111 193 minecraft:stone_bricks
fill 377 111 194 377 114 194 minecraft:mossy_cobblestone
setblock 377 111 198 minecraft:stone_bricks
fill 377 111 199 377 114 199 minecraft:mossy_cobblestone
setblock 377 111 202 minecraft:mossy_cobblestone
setblock 377 111 203 minecraft:stone_bricks
fill 377 111 204 377 114 204 minecraft:mossy_cobblestone
setblock 377 111 208 minecraft:stone_bricks
fill 377 111 209 377 114 209 minecraft:mossy_cobblestone
fill 377 111 214 377 114 214 minecraft:mossy_cobblestone
setblock 377 111 217 minecraft:mossy_cobblestone
setblock 377 111 218 minecraft:stone_bricks
fill 377 111 219 380 111 219 minecraft:mossy_cobblestone
setblock 378 111 182 minecraft:stone_bricks
fill 378 111 183 378 114 183 minecraft:mossy_cobblestone
setblock 378 111 187 minecraft:stone_bricks
fill 378 111 188 378 114 188 minecraft:mossy_cobblestone
setblock 378 111 191 minecraft:mossy_cobblestone
setblock 378 111 197 minecraft:stone_bricks
fill 378 111 198 378 113 198 minecraft:mossy_cobblestone
setblock 378 111 202 minecraft:stone_bricks
fill 378 111 203 379 113 203 minecraft:mossy_cobblestone
setblock 378 111 206 minecraft:mossy_cobblestone
setblock 378 111 217 minecraft:stone_bricks
fill 378 111 218 378 114 218 minecraft:mossy_cobblestone
setblock 378 111 222 minecraft:stone_bricks
fill 379 111 182 379 114 182 minecraft:mossy_cobblestone
setblock 379 111 186 minecraft:stone_bricks
fill 379 111 187 379 114 187 minecraft:mossy_cobblestone
setblock 379 111 200 minecraft:mossy_cobblestone
setblock 379 111 201 minecraft:stone_bricks
fill 379 111 202 379 113 202 minecraft:mossy_cobblestone
setblock 379 111 217 minecraft:mossy_cobblestone
setblock 379 111 221 minecraft:stone_bricks
fill 379 111 222 379 114 222 minecraft:mossy_cobblestone
setblock 380 111 184 minecraft:mossy_cobblestone
setblock 380 111 185 minecraft:stone_bricks
setblock 380 111 220 minecraft:stone_bricks
fill 380 111 221 380 114 221 minecraft:mossy_cobblestone
setblock 381 111 184 minecraft:stone_bricks
setblock 381 111 219 minecraft:stone_bricks
fill 381 111 220 381 114 220 minecraft:mossy_cobblestone
setblock 382 111 183 minecraft:stone_bricks
fill 382 111 184 382 114 184 minecraft:mossy_cobblestone
setblock 382 111 219 minecraft:mossy_cobblestone
setblock 383 111 182 minecraft:stone_bricks
fill 383 111 183 383 114 183 minecraft:mossy_cobblestone
setblock 383 111 222 minecraft:stone_bricks
fill 384 111 182 384 114 182 minecraft:mossy_cobblestone
setblock 384 111 221 minecraft:stone_bricks
fill 384 111 222 387 111 222 minecraft:mossy_cobblestone
setblock 385 111 220 minecraft:stone_bricks
fill 385 111 221 385 114 221 minecraft:mossy_cobblestone
fill 386 111 220 386 112 220 minecraft:mossy_cobblestone
setblock 387 111 183 minecraft:stone_bricks
setblock 388 111 182 minecraft:stone_bricks
setblock 388 111 183 minecraft:mossy_cobblestone
setblock 388 111 222 minecraft:stone_bricks
fill 389 111 182 392 111 182 minecraft:mossy_cobblestone
setblock 389 111 221 minecraft:stone_bricks
fill 389 111 222 389 114 222 minecraft:mossy_cobblestone
fill 390 111 221 393 111 221 minecraft:mossy_cobblestone
setblock 393 111 182 minecraft:stone_bricks
setblock 393 111 222 minecraft:stone_bricks
fill 394 111 182 397 111 182 minecraft:mossy_cobblestone
setblock 394 111 221 minecraft:stone_bricks
fill 394 111 222 394 114 222 minecraft:mossy_cobblestone
setblock 395 111 220 minecraft:stone_bricks
fill 395 111 221 395 114 221 minecraft:mossy_cobblestone
setblock 396 111 183 minecraft:mossy_cobblestone
fill 396 111 220 396 112 220 minecraft:mossy_cobblestone
setblock 397 111 183 minecraft:stone_bricks
setblock 398 111 182 minecraft:stone_bricks
fill 398 111 183 401 111 183 minecraft:mossy_cobblestone
setblock 398 111 222 minecraft:stone_bricks
fill 399 111 182 399 114 182 minecraft:mossy_cobblestone
setblock 399 111 221 minecraft:stone_bricks
fill 399 111 222 399 114 222 minecraft:mossy_cobblestone
setblock 400 111 220 minecraft:stone_bricks
fill 400 111 221 400 114 221 minecraft:mossy_cobblestone
fill 401 111 220 401 112 220 minecraft:mossy_cobblestone
setblock 402 111 183 minecraft:stone_bricks
setblock 403 111 182 minecraft:stone_bricks
fill 403 111 183 403 114 183 minecraft:mossy_cobblestone
setblock 403 111 222 minecraft:stone_bricks
fill 404 111 182 404 114 182 minecraft:mossy_cobblestone
setblock 404 111 221 minecraft:stone_bricks
fill 404 111 222 404 114 222 minecraft:mossy_cobblestone
setblock 405 111 221 minecraft:mossy_cobblestone
setblock 406 111 183 minecraft:mossy_cobblestone
setblock 407 111 182 minecraft:mossy_cobblestone
setblock 408 111 182 minecraft:stone_bricks
setblock 408 111 222 minecraft:stone_bricks
fill 409 111 182 412 111 182 minecraft:mossy_cobblestone
setblock 409 111 222 minecraft:mossy_cobblestone
fill 411 111 222 412 111 222 minecraft:mossy_cobblestone
setblock 413 111 182 minecraft:stone_bricks
fill 413 111 183 413 114 183 minecraft:mossy_cobblestone
setblock 413 111 222 minecraft:stone_bricks
fill 414 111 182 414 114 182 minecraft:mossy_cobblestone
fill 414 111 222 414 114 222 minecraft:mossy_cobblestone
fill 415 111 198 415 111 199 minecraft:mossy_cobblestone
setblock 415 111 200 minecraft:stone_bricks
fill 415 111 201 415 113 201 minecraft:mossy_cobblestone
fill 416 111 182 416 111 183 minecraft:mossy_cobblestone
setblock 416 111 184 minecraft:stone_bricks
fill 416 111 185 416 114 185 minecraft:mossy_cobblestone
setblock 416 111 189 minecraft:stone_bricks
fill 416 111 190 416 113 191 minecraft:mossy_cobblestone
setblock 416 111 194 minecraft:stone_bricks
fill 416 111 195 416 114 195 minecraft:mossy_cobblestone
setblock 416 111 199 minecraft:stone_bricks
fill 416 111 200 416 114 200 minecraft:mossy_cobblestone
setblock 416 111 204 minecraft:stone_bricks
fill 416 111 205 416 113 206 minecraft:mossy_cobblestone
setblock 417 111 183 minecraft:stone_bricks
fill 417 111 184 417 114 184 minecraft:mossy_cobblestone
setblock 417 111 187 minecraft:mossy_cobblestone
setblock 417 111 188 minecraft:stone_bricks
fill 417 111 189 417 114 189 minecraft:mossy_cobblestone
setblock 417 111 193 minecraft:stone_bricks
fill 417 111 194 417 114 194 minecraft:mossy_cobblestone
setblock 417 111 198 minecraft:stone_bricks
fill 417 111 199 417 114 199 minecraft:mossy_cobblestone
setblock 417 111 203 minecraft:stone_bricks
fill 417 111 204 417 114 204 minecraft:mossy_cobblestone
setblock 417 111 207 minecraft:mossy_cobblestone
setblock 417 111 208 minecraft:stone_bricks
fill 417 111 209 417 114 209 minecraft:mossy_cobblestone
setblock 417 111 217 minecraft:mossy_cobblestone
setblock 417 111 218 minecraft:stone_bricks
fill 417 111 219 417 114 219 minecraft:mossy_cobblestone
setblock 377 112 182 minecraft:stone_bricks
fill 377 112 183 377 115 183 minecraft:mossy_cobblestone
setblock 377 112 187 minecraft:stone_bricks
fill 377 112 188 377 115 188 minecraft:mossy_cobblestone
setblock 377 112 192 minecraft:stone_bricks
fill 377 112 193 377 115 193 minecraft:mossy_cobblestone
setblock 377 112 197 minecraft:stone_bricks
fill 377 112 198 377 115 198 minecraft:mossy_cobblestone
setblock 377 112 202 minecraft:stone_bricks
fill 377 112 203 377 115 203 minecraft:mossy_cobblestone
fill 377 112 205 377 112 206 minecraft:mossy_cobblestone
setblock 377 112 207 minecraft:stone_bricks
fill 377 112 208 378 114 208 minecraft:mossy_cobblestone
fill 377 112 210 377 112 211 minecraft:mossy_cobblestone
setblock 377 112 212 minecraft:stone_bricks
fill 377 112 213 377 115 213 minecraft:mossy_cobblestone
setblock 377 112 217 minecraft:stone_bricks
fill 377 112 218 377 114 219 minecraft:mossy_cobblestone
setblock 377 112 222 minecraft:stone_bricks
fill 378 112 182 378 115 182 minecraft:mossy_cobblestone
setblock 378 112 185 minecraft:mossy_cobblestone
setblock 378 112 186 minecraft:stone_bricks
fill 378 112 187 378 115 187 minecraft:mossy_cobblestone
setblock 378 112 191 minecraft:stone_bricks
setblock 378 112 196 minecraft:stone_bricks
setblock 378 112 197 minecraft:mossy_cobblestone
fill 378 112 199 378 113 199 minecraft:mossy_cobblestone
setblock 378 112 201 minecraft:stone_bricks
fill 378 112 202 378 115 202 minecraft:mossy_cobblestone
setblock 378 112 206 minecraft:stone_bricks
fill 378 112 207 378 115 207 minecraft:mossy_cobblestone
setblock 378 112 216 minecraft:stone_bricks
fill 378 112 217 378 115 217 minecraft:mossy_cobblestone
fill 378 112 219 379 112 219 minecraft:mossy_cobblestone
setblock 378 112 221 minecraft:stone_bricks
fill 378 112 222 378 115 222 minecraft:mossy_cobblestone
setblock 379 112 185 minecraft:stone_bricks
fill 379 112 186 379 115 186 minecraft:mossy_cobblestone
fill 379 112 188 379 113 188 minecraft:mossy_cobblestone
setblock 379 112 201 minecraft:mossy_cobblestone
setblock 379 112 204 minecraft:mossy_cobblestone
setblock 379 112 220 minecraft:stone_bricks
fill 379 112 221 379 115 221 minecraft:mossy_cobblestone
setblock 380 112 184 minecraft:stone_bricks
fill 380 112 185 381 112 185 minecraft:mossy_cobblestone
fill 380 112 220 380 115 220 minecraft:mossy_cobblestone
setblock 381 112 183 minecraft:stone_bricks
fill 381 112 184 381 115 184 minecraft:mossy_cobblestone
setblock 381 112 219 minecraft:mossy_cobblestone
setblock 382 112 182 minecraft:stone_bricks
fill 382 112 183 382 115 183 minecraft:mossy_cobblestone
setblock 382 112 222 minecraft:stone_bricks
fill 383 112 182 383 115 182 minecraft:mossy_cobblestone
setblock 383 112 221 minecraft:stone_bricks
fill 383 112 222 386 112 222 minecraft:mossy_cobblestone
setblock 384 112 220 minecraft:stone_bricks
fill 384 112 221 384 115 221 minecraft:mossy_cobblestone
fill 385 112 220 385 113 220 minecraft:mossy_cobblestone
setblock 386 112 183 minecraft:stone_bricks
setblock 387 112 182 minecraft:stone_bricks
fill 387 112 183 387 113 183 minecraft:mossy_cobblestone
setblock 387 112 222 minecraft:stone_bricks
fill 388 112 182 391 112 182 minecraft:mossy_cobblestone
setblock 388 112 221 minecraft:stone_bricks
fill 388 112 222 388 115 222 minecraft:mossy_cobblestone
fill 389 112 221 392 112 221 minecraft:mossy_cobblestone
setblock 392 112 182 minecraft:stone_bricks
setblock 392 112 222 minecraft:stone_bricks
fill 393 112 182 396 112 182 minecraft:mossy_cobblestone
setblock 393 112 221 minecraft:stone_bricks
fill 393 112 222 393 115 222 minecraft:mossy_cobblestone
fill 394 112 221 394 114 221 minecraft:mossy_cobblestone
setblock 395 112 183 minecraft:mossy_cobblestone
setblock 396 112 183 minecraft:stone_bricks
setblock 397 112 182 minecraft:stone_bricks
fill 397 112 183 400 112 183 minecraft:mossy_cobblestone
setblock 397 112 222 minecraft:stone_bricks
fill 398 112 182 398 115 182 minecraft:mossy_cobblestone
setblock 398 112 221 minecraft:stone_bricks
fill 398 112 222 398 115 222 minecraft:mossy_cobblestone
setblock 399 112 220 minecraft:stone_bricks
fill 399 112 221 399 115 221 minecraft:mossy_cobblestone
setblock 400 112 220 minecraft:mossy_cobblestone
setblock 401 112 183 minecraft:stone_bricks
setblock 402 112 182 minecraft:stone_bricks
fill 402 112 183 402 115 183 minecraft:mossy_cobblestone
setblock 402 112 222 minecraft:stone_bricks
fill 403 112 182 403 115 182 minecraft:mossy_cobblestone
setblock 403 112 221 minecraft:stone_bricks
fill 403 112 222 403 115 222 minecraft:mossy_cobblestone
setblock 404 112 221 minecraft:mossy_cobblestone
setblock 406 112 183 minecraft:stone_bricks
setblock 407 112 182 minecraft:stone_bricks
setblock 407 112 222 minecraft:stone_bricks
fill 408 112 182 411 112 182 minecraft:mossy_cobblestone
setblock 408 112 222 minecraft:mossy_cobblestone
setblock 412 112 182 minecraft:stone_bricks
fill 412 112 183 412 115 183 minecraft:mossy_cobblestone
setblock 412 112 222 minecraft:stone_bricks
fill 413 112 182 413 115 182 minecraft:mossy_cobblestone
fill 413 112 222 413 114 222 minecraft:mossy_cobblestone
setblock 415 112 184 minecraft:stone_bricks
fill 415 112 185 415 115 185 minecraft:mossy_cobblestone
setblock 415 112 199 minecraft:stone_bricks
fill 415 112 200 415 113 200 minecraft:mossy_cobblestone
setblock 415 112 203 minecraft:mossy_cobblestone
setblock 416 112 182 minecraft:mossy_cobblestone
setblock 416 112 183 minecraft:stone_bricks
fill 416 112 184 416 115 184 minecraft:mossy_cobblestone
fill 416 112 186 416 112 187 minecraft:mossy_cobblestone
schedule function dropper:buildpart/44_6 1t
