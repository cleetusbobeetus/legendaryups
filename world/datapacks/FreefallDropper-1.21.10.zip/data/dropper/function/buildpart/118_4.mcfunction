setblock 511 107 499 minecraft:terracotta
fill 511 107 500 511 110 500 minecraft:red_terracotta
setblock 511 107 504 minecraft:terracotta
fill 471 108 464 471 108 467 minecraft:red_terracotta
setblock 471 108 468 minecraft:terracotta
fill 471 108 469 471 108 472 minecraft:red_terracotta
setblock 471 108 473 minecraft:terracotta
fill 471 108 474 471 108 477 minecraft:red_terracotta
setblock 471 108 478 minecraft:terracotta
fill 471 108 479 471 111 479 minecraft:red_terracotta
setblock 471 108 483 minecraft:terracotta
fill 471 108 484 471 111 484 minecraft:red_terracotta
setblock 471 108 488 minecraft:terracotta
fill 471 108 489 471 109 489 minecraft:red_terracotta
setblock 471 108 493 minecraft:terracotta
fill 471 108 494 471 109 494 minecraft:red_terracotta
setblock 471 108 498 minecraft:terracotta
fill 471 108 499 471 111 499 minecraft:red_terracotta
setblock 471 108 503 minecraft:terracotta
fill 471 108 504 471 111 504 minecraft:red_terracotta
setblock 472 108 467 minecraft:terracotta
fill 472 108 468 472 108 471 minecraft:red_terracotta
setblock 472 108 472 minecraft:terracotta
fill 472 108 473 472 108 476 minecraft:red_terracotta
setblock 472 108 477 minecraft:terracotta
fill 472 108 478 472 111 478 minecraft:red_terracotta
setblock 472 108 482 minecraft:terracotta
fill 472 108 483 472 111 483 minecraft:red_terracotta
fill 472 108 489 475 109 489 minecraft:brown_terracotta
setblock 472 108 497 minecraft:terracotta
setblock 472 108 498 minecraft:red_terracotta
setblock 472 108 502 minecraft:terracotta
setblock 473 108 472 minecraft:red_terracotta
setblock 473 108 476 minecraft:terracotta
fill 473 108 477 473 110 477 minecraft:red_terracotta
setblock 473 108 481 minecraft:terracotta
fill 473 108 485 473 109 485 minecraft:brown_terracotta
setblock 475 108 464 minecraft:terracotta
fill 475 108 485 475 109 485 minecraft:brown_terracotta
setblock 475 108 504 minecraft:terracotta
fill 476 108 464 476 109 464 minecraft:red_terracotta
fill 476 108 486 476 109 488 minecraft:brown_terracotta
setblock 479 108 464 minecraft:red_terracotta
setblock 479 108 504 minecraft:red_terracotta
setblock 480 108 464 minecraft:terracotta
setblock 480 108 504 minecraft:terracotta
fill 481 108 464 484 108 464 minecraft:red_terracotta
fill 481 108 504 484 108 504 minecraft:red_terracotta
fill 482 108 503 485 108 503 minecraft:red_terracotta
setblock 484 108 465 minecraft:terracotta
fill 484 108 502 486 108 502 minecraft:red_terracotta
setblock 485 108 464 minecraft:terracotta
fill 485 108 465 485 111 465 minecraft:red_terracotta
setblock 485 108 504 minecraft:terracotta
fill 486 108 464 489 108 464 minecraft:red_terracotta
fill 486 108 501 487 108 501 minecraft:red_terracotta
setblock 486 108 503 minecraft:terracotta
fill 486 108 504 489 108 504 minecraft:red_terracotta
setblock 487 108 502 minecraft:terracotta
fill 487 108 503 487 111 503 minecraft:red_terracotta
setblock 488 108 501 minecraft:terracotta
fill 488 108 502 488 111 502 minecraft:red_terracotta
setblock 489 108 465 minecraft:terracotta
fill 489 108 501 489 111 501 minecraft:red_terracotta
setblock 490 108 464 minecraft:terracotta
fill 490 108 465 490 109 465 minecraft:red_terracotta
setblock 490 108 504 minecraft:terracotta
fill 491 108 464 491 111 464 minecraft:red_terracotta
setblock 491 108 503 minecraft:terracotta
fill 491 108 504 491 111 504 minecraft:red_terracotta
setblock 492 108 501 minecraft:red_terracotta
setblock 492 108 502 minecraft:terracotta
fill 492 108 503 492 111 503 minecraft:red_terracotta
setblock 493 108 501 minecraft:terracotta
fill 493 108 502 493 111 502 minecraft:red_terracotta
setblock 495 108 504 minecraft:terracotta
setblock 496 108 503 minecraft:terracotta
fill 496 108 504 496 111 504 minecraft:red_terracotta
fill 497 108 503 497 110 503 minecraft:red_terracotta
setblock 499 108 504 minecraft:red_terracotta
setblock 500 108 504 minecraft:terracotta
fill 501 108 498 504 147 502 minecraft:terracotta
fill 501 108 504 504 108 504 minecraft:red_terracotta
fill 502 108 503 505 108 503 minecraft:red_terracotta
fill 505 108 498 505 157 501 minecraft:terracotta
fill 505 108 502 506 108 502 minecraft:red_terracotta
setblock 505 108 504 minecraft:terracotta
setblock 506 108 503 minecraft:terracotta
fill 506 108 504 506 111 504 minecraft:red_terracotta
setblock 507 108 502 minecraft:terracotta
fill 507 108 503 507 111 503 minecraft:red_terracotta
fill 508 108 464 509 108 464 minecraft:red_terracotta
setblock 508 108 476 minecraft:terracotta
fill 508 108 477 508 110 477 minecraft:red_terracotta
setblock 508 108 480 minecraft:red_terracotta
setblock 508 108 481 minecraft:terracotta
fill 508 108 482 509 110 482 minecraft:red_terracotta
setblock 508 108 496 minecraft:terracotta
setblock 508 108 497 minecraft:red_terracotta
fill 508 108 502 508 110 502 minecraft:red_terracotta
setblock 509 108 475 minecraft:terracotta
fill 509 108 476 509 111 476 minecraft:red_terracotta
setblock 509 108 480 minecraft:terracotta
fill 509 108 481 509 111 481 minecraft:red_terracotta
fill 509 108 483 509 108 484 minecraft:red_terracotta
setblock 509 108 485 minecraft:terracotta
fill 509 108 486 509 110 486 minecraft:red_terracotta
setblock 509 108 490 minecraft:terracotta
setblock 509 108 491 minecraft:red_terracotta
setblock 509 108 495 minecraft:terracotta
fill 509 108 496 509 110 496 minecraft:red_terracotta
setblock 509 108 500 minecraft:terracotta
fill 509 108 501 509 110 501 minecraft:red_terracotta
setblock 510 108 464 minecraft:terracotta
setblock 510 108 470 minecraft:red_terracotta
setblock 510 108 474 minecraft:terracotta
fill 510 108 475 510 111 475 minecraft:red_terracotta
setblock 510 108 479 minecraft:terracotta
fill 510 108 480 510 111 480 minecraft:red_terracotta
setblock 510 108 484 minecraft:terracotta
fill 510 108 485 510 111 485 minecraft:red_terracotta
setblock 510 108 489 minecraft:terracotta
fill 510 108 490 510 110 490 minecraft:red_terracotta
setblock 510 108 494 minecraft:terracotta
fill 510 108 495 510 110 495 minecraft:red_terracotta
setblock 510 108 499 minecraft:terracotta
fill 510 108 500 510 111 500 minecraft:red_terracotta
setblock 510 108 504 minecraft:terracotta
fill 511 108 464 511 109 464 minecraft:red_terracotta
setblock 511 108 468 minecraft:terracotta
fill 511 108 469 511 109 469 minecraft:red_terracotta
setblock 511 108 473 minecraft:terracotta
fill 511 108 474 511 111 474 minecraft:red_terracotta
setblock 511 108 478 minecraft:terracotta
fill 511 108 479 511 111 479 minecraft:red_terracotta
setblock 511 108 483 minecraft:terracotta
fill 511 108 484 511 111 484 minecraft:red_terracotta
setblock 511 108 488 minecraft:terracotta
fill 511 108 489 511 111 489 minecraft:red_terracotta
setblock 511 108 493 minecraft:terracotta
fill 511 108 494 511 111 494 minecraft:red_terracotta
setblock 511 108 498 minecraft:terracotta
fill 511 108 499 511 111 499 minecraft:red_terracotta
setblock 511 108 503 minecraft:terracotta
fill 511 108 504 511 111 504 minecraft:red_terracotta
fill 471 109 464 471 109 466 minecraft:red_terracotta
setblock 471 109 467 minecraft:terracotta
fill 471 109 468 471 109 471 minecraft:red_terracotta
setblock 471 109 472 minecraft:terracotta
fill 471 109 473 471 109 476 minecraft:red_terracotta
setblock 471 109 477 minecraft:terracotta
fill 471 109 478 471 112 478 minecraft:red_terracotta
setblock 471 109 482 minecraft:terracotta
fill 471 109 483 471 112 483 minecraft:red_terracotta
setblock 471 109 487 minecraft:terracotta
setblock 471 109 488 minecraft:red_terracotta
setblock 471 109 492 minecraft:terracotta
setblock 471 109 493 minecraft:red_terracotta
setblock 471 109 497 minecraft:terracotta
fill 471 109 498 471 111 498 minecraft:red_terracotta
setblock 471 109 502 minecraft:terracotta
fill 471 109 503 471 112 503 minecraft:red_terracotta
fill 472 109 469 472 109 470 minecraft:red_terracotta
setblock 472 109 471 minecraft:terracotta
fill 472 109 472 472 109 475 minecraft:red_terracotta
setblock 472 109 476 minecraft:terracotta
fill 472 109 477 472 112 477 minecraft:red_terracotta
setblock 472 109 481 minecraft:terracotta
fill 472 109 482 472 112 482 minecraft:red_terracotta
setblock 472 109 485 minecraft:brown_terracotta
fill 472 109 490 475 109 490 minecraft:brown_terracotta
setblock 472 109 501 minecraft:terracotta
setblock 472 109 502 minecraft:red_terracotta
setblock 473 109 475 minecraft:terracotta
fill 473 109 476 473 110 476 minecraft:red_terracotta
setblock 473 109 480 minecraft:terracotta
setblock 473 109 481 minecraft:red_terracotta
fill 473 109 484 475 109 484 minecraft:brown_terracotta
setblock 474 109 464 minecraft:terracotta
setblock 474 109 504 minecraft:terracotta
fill 475 109 464 475 112 464 minecraft:red_terracotta
setblock 475 109 504 minecraft:red_terracotta
setblock 476 109 485 minecraft:brown_terracotta
setblock 476 109 489 minecraft:brown_terracotta
fill 477 109 486 477 109 488 minecraft:brown_terracotta
setblock 478 109 504 minecraft:red_terracotta
setblock 479 109 464 minecraft:terracotta
setblock 479 109 504 minecraft:terracotta
fill 480 109 464 483 109 464 minecraft:red_terracotta
fill 480 109 504 483 109 504 minecraft:red_terracotta
fill 481 109 503 484 109 503 minecraft:red_terracotta
fill 483 109 493 483 110 493 minecraft:magma_block
fill 483 109 502 485 109 502 minecraft:red_terracotta
setblock 484 109 464 minecraft:terracotta
fill 484 109 465 484 112 465 minecraft:red_terracotta
setblock 484 109 504 minecraft:terracotta
fill 485 109 464 488 109 464 minecraft:red_terracotta
setblock 485 109 503 minecraft:terracotta
fill 485 109 504 488 109 504 minecraft:red_terracotta
setblock 486 109 501 minecraft:red_terracotta
setblock 486 109 502 minecraft:terracotta
fill 486 109 503 486 112 503 minecraft:red_terracotta
setblock 487 109 501 minecraft:terracotta
fill 487 109 502 487 112 502 minecraft:red_terracotta
setblock 488 109 465 minecraft:terracotta
fill 488 109 501 488 112 501 minecraft:red_terracotta
setblock 489 109 464 minecraft:terracotta
fill 489 109 465 489 111 465 minecraft:red_terracotta
setblock 489 109 504 minecraft:terracotta
fill 490 109 464 490 112 464 minecraft:red_terracotta
setblock 490 109 503 minecraft:terracotta
fill 490 109 504 490 112 504 minecraft:red_terracotta
setblock 491 109 502 minecraft:terracotta
fill 491 109 503 491 112 503 minecraft:red_terracotta
setblock 492 109 501 minecraft:terracotta
fill 492 109 502 492 112 502 minecraft:red_terracotta
setblock 494 109 504 minecraft:terracotta
setblock 495 109 503 minecraft:terracotta
fill 495 109 504 495 112 504 minecraft:red_terracotta
fill 496 109 503 496 111 503 minecraft:red_terracotta
fill 499 109 487 499 111 491 minecraft:terracotta
setblock 499 109 504 minecraft:terracotta
fill 500 109 476 500 110 486 minecraft:terracotta
fill 500 109 504 503 109 504 minecraft:red_terracotta
fill 501 109 466 501 110 480 minecraft:terracotta
fill 501 109 503 504 109 503 minecraft:red_terracotta
fill 502 109 464 502 110 474 minecraft:terracotta
fill 503 109 464 503 110 466 minecraft:terracotta
setblock 504 109 504 minecraft:terracotta
setblock 505 109 502 minecraft:red_terracotta
setblock 505 109 503 minecraft:terracotta
fill 505 109 504 505 112 504 minecraft:red_terracotta
setblock 506 109 502 minecraft:terracotta
fill 506 109 503 506 112 503 minecraft:red_terracotta
fill 507 109 464 508 109 464 minecraft:red_terracotta
fill 507 109 502 507 110 502 minecraft:red_terracotta
setblock 508 109 476 minecraft:red_terracotta
setblock 508 109 480 minecraft:terracotta
fill 508 109 481 508 112 481 minecraft:red_terracotta
fill 508 109 483 509 109 483 minecraft:red_terracotta
setblock 509 109 464 minecraft:terracotta
setblock 509 109 474 minecraft:terracotta
fill 509 109 475 509 111 475 minecraft:red_terracotta
setblock 509 109 479 minecraft:terracotta
fill 509 109 480 509 112 480 minecraft:red_terracotta
setblock 509 109 484 minecraft:terracotta
fill 509 109 485 509 112 485 minecraft:red_terracotta
setblock 509 109 494 minecraft:terracotta
setblock 509 109 495 minecraft:red_terracotta
setblock 509 109 499 minecraft:terracotta
fill 509 109 500 509 110 500 minecraft:red_terracotta
setblock 509 109 504 minecraft:terracotta
fill 510 109 464 510 110 464 minecraft:red_terracotta
setblock 510 109 473 minecraft:terracotta
fill 510 109 474 510 112 474 minecraft:red_terracotta
setblock 510 109 478 minecraft:terracotta
fill 510 109 479 510 112 479 minecraft:red_terracotta
setblock 510 109 483 minecraft:terracotta
fill 510 109 484 510 112 484 minecraft:red_terracotta
setblock 510 109 488 minecraft:terracotta
fill 510 109 489 510 110 489 minecraft:red_terracotta
setblock 510 109 493 minecraft:terracotta
fill 510 109 494 510 110 494 minecraft:red_terracotta
setblock 510 109 498 minecraft:terracotta
fill 510 109 499 510 111 499 minecraft:red_terracotta
setblock 510 109 503 minecraft:terracotta
fill 510 109 504 510 112 504 minecraft:red_terracotta
setblock 511 109 468 minecraft:red_terracotta
setblock 511 109 472 minecraft:terracotta
fill 511 109 473 511 112 473 minecraft:red_terracotta
setblock 511 109 477 minecraft:terracotta
fill 511 109 478 511 112 478 minecraft:red_terracotta
setblock 511 109 482 minecraft:terracotta
fill 511 109 483 511 112 483 minecraft:red_terracotta
setblock 511 109 487 minecraft:terracotta
fill 511 109 488 511 112 488 minecraft:red_terracotta
setblock 511 109 492 minecraft:terracotta
fill 511 109 493 511 111 493 minecraft:red_terracotta
setblock 511 109 497 minecraft:terracotta
fill 511 109 498 511 112 498 minecraft:red_terracotta
setblock 511 109 502 minecraft:terracotta
fill 511 109 503 511 112 503 minecraft:red_terracotta
fill 471 110 464 471 110 465 minecraft:red_terracotta
setblock 471 110 466 minecraft:terracotta
fill 471 110 467 471 110 470 minecraft:red_terracotta
setblock 471 110 471 minecraft:terracotta
fill 471 110 472 471 110 475 minecraft:red_terracotta
setblock 471 110 476 minecraft:terracotta
fill 471 110 477 471 113 477 minecraft:red_terracotta
setblock 471 110 481 minecraft:terracotta
fill 471 110 482 471 113 482 minecraft:red_terracotta
setblock 471 110 486 minecraft:terracotta
setblock 471 110 487 minecraft:red_terracotta
setblock 471 110 496 minecraft:terracotta
setblock 471 110 497 minecraft:red_terracotta
setblock 471 110 501 minecraft:terracotta
fill 471 110 502 471 113 502 minecraft:red_terracotta
fill 472 110 471 472 110 474 minecraft:red_terracotta
setblock 472 110 475 minecraft:terracotta
fill 472 110 476 472 112 476 minecraft:red_terracotta
setblock 472 110 480 minecraft:terracotta
fill 472 110 481 472 113 481 minecraft:red_terracotta
setblock 473 110 464 minecraft:terracotta
setblock 473 110 466 minecraft:light[level=14]
setblock 473 110 474 minecraft:light[level=14]
setblock 473 110 479 minecraft:terracotta
setblock 473 110 482 minecraft:light[level=14]
setblock 473 110 490 minecraft:light[level=14]
setblock 473 110 498 minecraft:light[level=14]
setblock 473 110 504 minecraft:terracotta
fill 474 110 464 474 113 464 minecraft:red_terracotta
fill 474 110 504 474 111 504 minecraft:red_terracotta
setblock 478 110 464 minecraft:terracotta
setblock 478 110 504 minecraft:terracotta
fill 479 110 464 482 110 464 minecraft:red_terracotta
fill 479 110 504 482 110 504 minecraft:red_terracotta
setblock 481 110 466 minecraft:light[level=14]
setblock 481 110 474 minecraft:light[level=14]
setblock 481 110 482 minecraft:light[level=14]
setblock 481 110 490 minecraft:light[level=14]
setblock 481 110 498 minecraft:light[level=14]
fill 481 110 503 483 110 503 minecraft:red_terracotta
setblock 483 110 464 minecraft:terracotta
fill 483 110 465 483 113 465 minecraft:red_terracotta
fill 483 110 502 484 110 502 minecraft:red_terracotta
setblock 483 110 504 minecraft:terracotta
fill 484 110 464 487 110 464 minecraft:red_terracotta
setblock 484 110 503 minecraft:terracotta
fill 484 110 504 487 110 504 minecraft:red_terracotta
setblock 485 110 501 minecraft:red_terracotta
setblock 485 110 502 minecraft:terracotta
fill 485 110 503 485 113 503 minecraft:red_terracotta
setblock 486 110 501 minecraft:terracotta
fill 486 110 502 486 113 502 minecraft:red_terracotta
setblock 487 110 465 minecraft:terracotta
fill 487 110 501 487 113 501 minecraft:red_terracotta
setblock 488 110 464 minecraft:terracotta
fill 488 110 465 488 113 465 minecraft:red_terracotta
setblock 488 110 504 minecraft:terracotta
fill 489 110 464 489 113 464 minecraft:red_terracotta
setblock 489 110 466 minecraft:light[level=14]
setblock 489 110 474 minecraft:light[level=14]
setblock 489 110 482 minecraft:light[level=14]
setblock 489 110 490 minecraft:light[level=14]
setblock 489 110 498 minecraft:light[level=14]
setblock 489 110 503 minecraft:terracotta
fill 489 110 504 489 113 504 minecraft:red_terracotta
setblock 490 110 502 minecraft:terracotta
fill 490 110 503 490 113 503 minecraft:red_terracotta
setblock 491 110 501 minecraft:terracotta
fill 491 110 502 491 113 502 minecraft:red_terracotta
setblock 493 110 464 minecraft:terracotta
setblock 493 110 504 minecraft:terracotta
setblock 494 110 503 minecraft:terracotta
fill 494 110 504 494 113 504 minecraft:red_terracotta
fill 495 110 503 495 112 503 minecraft:red_terracotta
setblock 497 110 466 minecraft:light[level=14]
setblock 497 110 474 minecraft:light[level=14]
setblock 497 110 482 minecraft:light[level=14]
setblock 497 110 490 minecraft:light[level=14]
fill 497 110 498 498 110 502 minecraft:terracotta
fill 498 110 490 498 110 497 minecraft:terracotta
fill 498 110 503 498 110 504 minecraft:terracotta
fill 499 110 481 499 110 486 minecraft:terracotta
fill 499 110 492 499 110 500 minecraft:terracotta
fill 499 110 504 502 110 504 minecraft:red_terracotta
fill 500 110 474 500 110 475 minecraft:terracotta
fill 500 110 487 500 110 492 minecraft:terracotta
fill 501 110 481 501 110 484 minecraft:terracotta
fill 501 110 503 503 110 503 minecraft:red_terracotta
fill 502 110 475 502 110 476 minecraft:terracotta
setblock 503 110 467 minecraft:terracotta
setblock 503 110 504 minecraft:terracotta
setblock 504 110 503 minecraft:terracotta
fill 504 110 504 504 113 504 minecraft:red_terracotta
setblock 505 110 466 minecraft:light[level=14]
setblock 505 110 474 minecraft:light[level=14]
setblock 505 110 482 minecraft:light[level=14]
setblock 505 110 490 minecraft:light[level=14]
fill 505 110 502 505 145 502 minecraft:terracotta
fill 505 110 503 505 113 503 minecraft:red_terracotta
setblock 506 110 502 minecraft:red_terracotta
setblock 507 110 464 minecraft:red_terracotta
setblock 508 110 464 minecraft:terracotta
setblock 508 110 479 minecraft:terracotta
fill 508 110 480 508 113 480 minecraft:red_terracotta
setblock 508 110 483 minecraft:red_terracotta
setblock 508 110 504 minecraft:terracotta
fill 509 110 464 509 113 464 minecraft:red_terracotta
setblock 509 110 474 minecraft:red_terracotta
setblock 509 110 478 minecraft:terracotta
fill 509 110 479 509 113 479 minecraft:red_terracotta
setblock 509 110 483 minecraft:terracotta
fill 509 110 484 509 113 484 minecraft:red_terracotta
setblock 509 110 498 minecraft:terracotta
setblock 509 110 499 minecraft:red_terracotta
setblock 509 110 503 minecraft:terracotta
fill 509 110 504 509 113 504 minecraft:red_terracotta
setblock 510 110 472 minecraft:terracotta
fill 510 110 473 510 111 473 minecraft:red_terracotta
setblock 510 110 477 minecraft:terracotta
fill 510 110 478 510 113 478 minecraft:red_terracotta
setblock 510 110 482 minecraft:terracotta
fill 510 110 483 510 113 483 minecraft:red_terracotta
setblock 510 110 487 minecraft:terracotta
fill 510 110 488 510 111 488 minecraft:red_terracotta
setblock 510 110 492 minecraft:terracotta
setblock 510 110 493 minecraft:red_terracotta
setblock 510 110 497 minecraft:terracotta
fill 510 110 498 510 111 498 minecraft:red_terracotta
setblock 510 110 502 minecraft:terracotta
fill 510 110 503 510 111 503 minecraft:red_terracotta
setblock 511 110 471 minecraft:terracotta
fill 511 110 472 511 112 472 minecraft:red_terracotta
setblock 511 110 476 minecraft:terracotta
fill 511 110 477 511 113 477 minecraft:red_terracotta
setblock 511 110 481 minecraft:terracotta
fill 511 110 482 511 113 482 minecraft:red_terracotta
setblock 511 110 486 minecraft:terracotta
fill 511 110 487 511 113 487 minecraft:red_terracotta
setblock 511 110 491 minecraft:terracotta
fill 511 110 492 511 111 492 minecraft:red_terracotta
setblock 511 110 496 minecraft:terracotta
fill 511 110 497 511 112 497 minecraft:red_terracotta
setblock 511 110 501 minecraft:terracotta
fill 511 110 502 511 113 502 minecraft:red_terracotta
setblock 471 111 464 minecraft:red_terracotta
setblock 471 111 465 minecraft:terracotta
fill 471 111 466 471 111 469 minecraft:red_terracotta
setblock 471 111 470 minecraft:terracotta
fill 471 111 471 471 111 474 minecraft:red_terracotta
setblock 471 111 475 minecraft:terracotta
fill 471 111 476 471 114 476 minecraft:red_terracotta
setblock 471 111 480 minecraft:terracotta
fill 471 111 481 471 114 481 minecraft:red_terracotta
setblock 471 111 485 minecraft:terracotta
setblock 471 111 486 minecraft:red_terracotta
setblock 471 111 500 minecraft:terracotta
fill 471 111 501 471 113 501 minecraft:red_terracotta
setblock 472 111 464 minecraft:terracotta
setblock 472 111 473 minecraft:red_terracotta
setblock 472 111 474 minecraft:terracotta
fill 472 111 475 472 112 475 minecraft:red_terracotta
setblock 472 111 479 minecraft:terracotta
fill 472 111 480 472 113 480 minecraft:red_terracotta
setblock 472 111 504 minecraft:terracotta
fill 473 111 464 473 114 464 minecraft:red_terracotta
fill 473 111 504 473 114 504 minecraft:red_terracotta
setblock 477 111 504 minecraft:terracotta
fill 478 111 464 481 111 464 minecraft:red_terracotta
fill 478 111 504 481 111 504 minecraft:red_terracotta
fill 481 111 503 482 111 503 minecraft:red_terracotta
setblock 482 111 464 minecraft:terracotta
setblock 482 111 504 minecraft:terracotta
fill 483 111 464 486 111 464 minecraft:red_terracotta
setblock 483 111 502 minecraft:red_terracotta
setblock 483 111 503 minecraft:terracotta
fill 483 111 504 486 111 504 minecraft:red_terracotta
setblock 484 111 502 minecraft:terracotta
fill 484 111 503 484 114 503 minecraft:red_terracotta
setblock 485 111 501 minecraft:terracotta
fill 485 111 502 485 114 502 minecraft:red_terracotta
setblock 486 111 465 minecraft:terracotta
fill 486 111 501 486 113 501 minecraft:red_terracotta
setblock 487 111 464 minecraft:terracotta
fill 487 111 465 487 114 465 minecraft:red_terracotta
setblock 487 111 504 minecraft:terracotta
fill 488 111 464 488 114 464 minecraft:red_terracotta
setblock 488 111 503 minecraft:terracotta
fill 488 111 504 488 114 504 minecraft:red_terracotta
setblock 489 111 502 minecraft:terracotta
fill 489 111 503 489 114 503 minecraft:red_terracotta
setblock 490 111 501 minecraft:terracotta
fill 490 111 502 490 114 502 minecraft:red_terracotta
setblock 492 111 464 minecraft:terracotta
setblock 492 111 504 minecraft:terracotta
setblock 493 111 503 minecraft:terracotta
fill 493 111 504 493 114 504 minecraft:red_terracotta
fill 494 111 503 494 113 503 minecraft:red_terracotta
fill 497 111 499 497 111 504 minecraft:terracotta
fill 498 111 492 498 111 503 minecraft:terracotta
fill 498 111 504 501 111 504 minecraft:red_terracotta
fill 499 111 485 500 111 486 minecraft:terracotta
fill 499 111 492 499 111 499 minecraft:terracotta
fill 500 111 479 500 111 484 minecraft:terracotta
fill 500 111 487 500 111 489 minecraft:terracotta
fill 501 111 471 501 111 477 minecraft:orange_concrete
fill 501 111 503 502 111 503 minecraft:red_terracotta
fill 502 111 464 502 111 470 minecraft:orange_concrete
setblock 502 111 504 minecraft:terracotta
setblock 503 111 503 minecraft:terracotta
fill 503 111 504 503 114 504 minecraft:red_terracotta
fill 504 111 503 504 114 503 minecraft:red_terracotta
setblock 506 111 464 minecraft:red_terracotta
setblock 507 111 464 minecraft:terracotta
setblock 507 111 504 minecraft:terracotta
fill 508 111 464 508 114 464 minecraft:red_terracotta
setblock 508 111 478 minecraft:terracotta
fill 508 111 479 508 112 479 minecraft:red_terracotta
setblock 508 111 482 minecraft:red_terracotta
setblock 508 111 483 minecraft:terracotta
setblock 508 111 503 minecraft:terracotta
fill 508 111 504 508 114 504 minecraft:red_terracotta
setblock 509 111 477 minecraft:terracotta
fill 509 111 478 509 114 478 minecraft:red_terracotta
setblock 509 111 482 minecraft:terracotta
fill 509 111 483 509 114 483 minecraft:red_terracotta
fill 509 111 503 509 112 503 minecraft:red_terracotta
setblock 510 111 476 minecraft:terracotta
fill 510 111 477 510 114 477 minecraft:red_terracotta
setblock 510 111 481 minecraft:terracotta
fill 510 111 482 510 114 482 minecraft:red_terracotta
setblock 510 111 486 minecraft:terracotta
fill 510 111 487 510 114 487 minecraft:red_terracotta
setblock 510 111 496 minecraft:terracotta
setblock 510 111 497 minecraft:red_terracotta
setblock 510 111 501 minecraft:terracotta
setblock 510 111 502 minecraft:red_terracotta
setblock 511 111 471 minecraft:red_terracotta
setblock 511 111 475 minecraft:terracotta
fill 511 111 476 511 114 476 minecraft:red_terracotta
setblock 511 111 480 minecraft:terracotta
fill 511 111 481 511 114 481 minecraft:red_terracotta
setblock 511 111 485 minecraft:terracotta
fill 511 111 486 511 114 486 minecraft:red_terracotta
setblock 511 111 490 minecraft:terracotta
setblock 511 111 491 minecraft:red_terracotta
setblock 511 111 495 minecraft:terracotta
setblock 511 111 496 minecraft:red_terracotta
setblock 511 111 500 minecraft:terracotta
fill 511 111 501 511 113 501 minecraft:red_terracotta
setblock 471 112 464 minecraft:terracotta
fill 471 112 465 471 112 468 minecraft:red_terracotta
setblock 471 112 469 minecraft:terracotta
fill 471 112 470 471 112 473 minecraft:red_terracotta
setblock 471 112 474 minecraft:terracotta
fill 471 112 475 471 115 475 minecraft:red_terracotta
setblock 471 112 479 minecraft:terracotta
fill 471 112 480 471 115 480 minecraft:red_terracotta
setblock 471 112 484 minecraft:terracotta
fill 471 112 485 471 115 485 minecraft:red_terracotta
setblock 471 112 500 minecraft:red_terracotta
setblock 471 112 504 minecraft:terracotta
fill 472 112 464 472 115 464 minecraft:red_terracotta
setblock 472 112 478 minecraft:terracotta
fill 472 112 479 472 113 479 minecraft:red_terracotta
fill 472 112 504 472 115 504 minecraft:red_terracotta
setblock 476 112 464 minecraft:terracotta
fill 477 112 464 480 112 464 minecraft:red_terracotta
fill 477 112 504 480 112 504 minecraft:red_terracotta
fill 480 112 503 481 112 503 minecraft:red_terracotta
setblock 481 112 464 minecraft:terracotta
setblock 481 112 504 minecraft:terracotta
fill 482 112 464 482 114 465 minecraft:red_terracotta
setblock 482 112 502 minecraft:red_terracotta
setblock 482 112 503 minecraft:terracotta
fill 482 112 504 485 112 504 minecraft:red_terracotta
fill 483 112 464 485 112 464 minecraft:red_terracotta
setblock 483 112 502 minecraft:terracotta
fill 483 112 503 483 115 503 minecraft:red_terracotta
fill 484 112 502 484 115 502 minecraft:red_terracotta
setblock 485 112 465 minecraft:terracotta
setblock 486 112 464 minecraft:terracotta
fill 486 112 465 486 115 465 minecraft:red_terracotta
setblock 486 112 504 minecraft:terracotta
fill 487 112 464 487 115 464 minecraft:red_terracotta
setblock 487 112 503 minecraft:terracotta
fill 487 112 504 487 115 504 minecraft:red_terracotta
setblock 488 112 502 minecraft:terracotta
fill 488 112 503 488 115 503 minecraft:red_terracotta
setblock 489 112 501 minecraft:terracotta
fill 489 112 502 489 115 502 minecraft:red_terracotta
setblock 491 112 464 minecraft:terracotta
setblock 491 112 504 minecraft:terracotta
fill 492 112 464 492 116 464 minecraft:magma_block
setblock 492 112 503 minecraft:terracotta
fill 492 112 504 492 115 504 minecraft:red_terracotta
fill 493 112 503 493 115 503 minecraft:red_terracotta
setblock 496 112 504 minecraft:terracotta
fill 497 112 503 498 112 503 minecraft:orange_concrete
fill 497 112 504 500 112 504 minecraft:red_terracotta
fill 498 112 495 498 112 502 minecraft:orange_concrete
fill 499 112 488 499 112 495 minecraft:orange_concrete
fill 500 112 481 500 112 486 minecraft:orange_concrete
setblock 501 112 503 minecraft:red_terracotta
setblock 501 112 504 minecraft:terracotta
setblock 502 112 503 minecraft:terracotta
fill 502 112 504 502 115 504 minecraft:red_terracotta
fill 503 112 503 503 115 503 minecraft:red_terracotta
setblock 506 112 464 minecraft:terracotta
setblock 506 112 504 minecraft:terracotta
fill 507 112 464 507 115 464 minecraft:red_terracotta
setblock 507 112 503 minecraft:terracotta
fill 507 112 504 507 115 504 minecraft:red_terracotta
setblock 508 112 482 minecraft:terracotta
setblock 508 112 483 minecraft:red_terracotta
fill 508 112 503 508 114 503 minecraft:red_terracotta
setblock 509 112 476 minecraft:terracotta
fill 509 112 477 509 113 477 minecraft:red_terracotta
setblock 509 112 481 minecraft:terracotta
fill 509 112 482 509 115 482 minecraft:red_terracotta
setblock 510 112 475 minecraft:terracotta
fill 510 112 476 510 114 476 minecraft:red_terracotta
setblock 510 112 480 minecraft:terracotta
fill 510 112 481 510 115 481 minecraft:red_terracotta
setblock 510 112 485 minecraft:terracotta
fill 510 112 486 510 115 486 minecraft:red_terracotta
setblock 511 112 474 minecraft:terracotta
fill 511 112 475 511 115 475 minecraft:red_terracotta
setblock 511 112 479 minecraft:terracotta
fill 511 112 480 511 115 480 minecraft:red_terracotta
setblock 511 112 484 minecraft:terracotta
fill 511 112 485 511 115 485 minecraft:red_terracotta
setblock 511 112 489 minecraft:terracotta
setblock 511 112 499 minecraft:terracotta
fill 511 112 500 511 113 500 minecraft:red_terracotta
setblock 511 112 504 minecraft:terracotta
fill 471 113 464 471 113 467 minecraft:red_terracotta
setblock 471 113 468 minecraft:terracotta
fill 471 113 471 471 113 472 minecraft:red_terracotta
setblock 471 113 473 minecraft:terracotta
fill 471 113 474 471 114 474 minecraft:red_terracotta
setblock 471 113 478 minecraft:terracotta
fill 471 113 479 471 116 479 minecraft:red_terracotta
setblock 471 113 483 minecraft:terracotta
fill 471 113 484 471 116 484 minecraft:red_terracotta
setblock 471 113 503 minecraft:terracotta
fill 471 113 504 471 116 504 minecraft:red_terracotta
setblock 472 113 478 minecraft:red_terracotta
setblock 475 113 464 minecraft:terracotta
fill 476 113 464 479 113 464 minecraft:red_terracotta
fill 476 113 504 479 113 504 minecraft:red_terracotta
setblock 480 113 464 minecraft:terracotta
setblock 480 113 503 minecraft:red_terracotta
setblock 480 113 504 minecraft:terracotta
fill 481 113 464 481 115 465 minecraft:red_terracotta
setblock 481 113 503 minecraft:terracotta
fill 481 113 504 484 113 504 minecraft:red_terracotta
setblock 482 113 502 minecraft:terracotta
fill 482 113 503 482 116 503 minecraft:red_terracotta
fill 483 113 464 484 113 464 minecraft:red_terracotta
fill 483 113 502 483 116 502 minecraft:red_terracotta
setblock 484 113 465 minecraft:terracotta
setblock 485 113 464 minecraft:terracotta
fill 485 113 465 485 116 465 minecraft:red_terracotta
setblock 485 113 504 minecraft:terracotta
fill 486 113 464 486 116 464 minecraft:red_terracotta
setblock 486 113 503 minecraft:terracotta
fill 486 113 504 486 116 504 minecraft:red_terracotta
setblock 487 113 502 minecraft:terracotta
fill 487 113 503 487 116 503 minecraft:red_terracotta
fill 488 113 502 488 116 502 minecraft:red_terracotta
setblock 490 113 464 minecraft:terracotta
setblock 490 113 504 minecraft:terracotta
fill 491 113 464 491 116 464 minecraft:red_terracotta
setblock 491 113 503 minecraft:terracotta
fill 491 113 504 491 116 504 minecraft:red_terracotta
fill 492 113 503 492 116 503 minecraft:red_terracotta
setblock 495 113 504 minecraft:terracotta
fill 496 113 504 499 113 504 minecraft:red_terracotta
setblock 500 113 504 minecraft:terracotta
setblock 501 113 503 minecraft:terracotta
fill 501 113 504 501 116 504 minecraft:red_terracotta
fill 502 113 464 503 113 473 minecraft:terracotta
fill 502 113 503 502 116 503 minecraft:red_terracotta
fill 503 113 474 504 114 486 minecraft:terracotta
setblock 504 113 464 minecraft:red_terracotta
fill 504 113 471 504 114 473 minecraft:terracotta
fill 504 113 487 505 114 496 minecraft:terracotta
setblock 505 113 464 minecraft:terracotta
fill 505 113 485 505 114 486 minecraft:terracotta
fill 505 113 497 505 114 497 minecraft:terracotta
setblock 505 113 504 minecraft:terracotta
fill 506 113 464 506 116 464 minecraft:red_terracotta
fill 506 113 498 506 114 498 minecraft:terracotta
fill 506 113 502 506 113 503 minecraft:terracotta
fill 506 113 504 506 116 504 minecraft:red_terracotta
fill 507 113 503 507 116 503 minecraft:red_terracotta
setblock 508 113 481 minecraft:terracotta
fill 508 113 482 508 116 482 minecraft:red_terracotta
setblock 509 113 480 minecraft:terracotta
fill 509 113 481 509 116 481 minecraft:red_terracotta
setblock 509 113 485 minecraft:terracotta
setblock 510 113 475 minecraft:red_terracotta
setblock 510 113 479 minecraft:terracotta
fill 510 113 480 510 116 480 minecraft:red_terracotta
setblock 510 113 484 minecraft:terracotta
fill 510 113 485 510 116 485 minecraft:red_terracotta
setblock 510 113 504 minecraft:terracotta
setblock 511 113 473 minecraft:terracotta
fill 511 113 474 511 114 474 minecraft:red_terracotta
setblock 511 113 478 minecraft:terracotta
fill 511 113 479 511 116 479 minecraft:red_terracotta
setblock 511 113 483 minecraft:terracotta
fill 511 113 484 511 116 484 minecraft:red_terracotta
setblock 511 113 488 minecraft:terracotta
setblock 511 113 503 minecraft:terracotta
setblock 511 113 504 minecraft:red_terracotta
fill 471 114 464 471 114 466 minecraft:red_terracotta
setblock 471 114 467 minecraft:terracotta
fill 471 114 468 471 117 468 minecraft:red_terracotta
setblock 471 114 477 minecraft:terracotta
fill 471 114 478 471 117 478 minecraft:red_terracotta
setblock 471 114 482 minecraft:terracotta
fill 471 114 483 471 117 483 minecraft:red_terracotta
setblock 471 114 502 minecraft:terracotta
fill 471 114 503 471 117 503 minecraft:red_terracotta
setblock 474 114 464 minecraft:terracotta
setblock 474 114 504 minecraft:terracotta
fill 475 114 464 478 114 464 minecraft:red_terracotta
fill 475 114 504 478 114 504 minecraft:red_terracotta
setblock 479 114 464 minecraft:terracotta
setblock 479 114 503 minecraft:red_terracotta
setblock 479 114 504 minecraft:terracotta
fill 480 114 464 480 116 465 minecraft:red_terracotta
setblock 480 114 503 minecraft:terracotta
fill 480 114 504 483 114 504 minecraft:red_terracotta
fill 481 114 503 481 117 503 minecraft:red_terracotta
fill 482 114 502 482 117 502 minecraft:red_terracotta
setblock 483 114 464 minecraft:red_terracotta
setblock 483 114 465 minecraft:terracotta
setblock 484 114 464 minecraft:terracotta
fill 484 114 465 484 117 465 minecraft:red_terracotta
setblock 484 114 504 minecraft:terracotta
fill 485 114 464 485 117 464 minecraft:red_terracotta
setblock 485 114 503 minecraft:terracotta
fill 485 114 504 485 117 504 minecraft:red_terracotta
setblock 486 114 502 minecraft:terracotta
fill 486 114 503 486 117 503 minecraft:red_terracotta
fill 487 114 502 487 117 502 minecraft:red_terracotta
setblock 488 114 465 minecraft:terracotta
setblock 489 114 464 minecraft:terracotta
setblock 489 114 504 minecraft:terracotta
fill 490 114 464 490 117 464 minecraft:red_terracotta
setblock 490 114 503 minecraft:terracotta
fill 490 114 504 490 117 504 minecraft:red_terracotta
fill 491 114 503 491 117 503 minecraft:red_terracotta
setblock 494 114 504 minecraft:terracotta
fill 495 114 504 498 114 504 minecraft:red_terracotta
setblock 499 114 504 minecraft:terracotta
fill 500 114 504 500 117 504 minecraft:red_terracotta
fill 501 114 503 501 117 503 minecraft:red_terracotta
fill 502 114 464 502 114 473 minecraft:terracotta
setblock 503 114 464 minecraft:red_terracotta
fill 503 114 465 503 114 473 minecraft:terracotta
setblock 504 114 464 minecraft:terracotta
setblock 504 114 504 minecraft:terracotta
fill 505 114 464 505 117 464 minecraft:red_terracotta
setblock 505 114 503 minecraft:terracotta
fill 505 114 504 505 117 504 minecraft:red_terracotta
setblock 506 114 502 minecraft:terracotta
fill 506 114 503 506 117 503 minecraft:red_terracotta
setblock 508 114 481 minecraft:red_terracotta
setblock 509 114 464 minecraft:terracotta
setblock 509 114 479 minecraft:terracotta
fill 509 114 480 509 117 480 minecraft:red_terracotta
setblock 509 114 484 minecraft:terracotta
fill 509 114 485 509 117 485 minecraft:red_terracotta
setblock 509 114 504 minecraft:terracotta
fill 510 114 464 510 117 464 minecraft:red_terracotta
setblock 510 114 478 minecraft:terracotta
fill 510 114 479 510 117 479 minecraft:red_terracotta
setblock 510 114 483 minecraft:terracotta
fill 510 114 484 510 117 484 minecraft:red_terracotta
fill 510 114 504 510 117 504 minecraft:red_terracotta
setblock 511 114 477 minecraft:terracotta
fill 511 114 478 511 117 478 minecraft:red_terracotta
setblock 511 114 482 minecraft:terracotta
fill 511 114 483 511 117 483 minecraft:red_terracotta
setblock 511 114 487 minecraft:terracotta
fill 511 114 488 511 117 488 minecraft:red_terracotta
fill 471 115 464 471 115 465 minecraft:red_terracotta
setblock 471 115 466 minecraft:terracotta
fill 471 115 467 471 118 467 minecraft:red_terracotta
setblock 471 115 476 minecraft:terracotta
fill 471 115 477 471 116 477 minecraft:red_terracotta
setblock 471 115 481 minecraft:terracotta
fill 471 115 482 471 118 482 minecraft:red_terracotta
setblock 473 115 464 minecraft:terracotta
setblock 473 115 504 minecraft:terracotta
fill 474 115 464 477 115 464 minecraft:red_terracotta
fill 474 115 504 477 115 504 minecraft:red_terracotta
setblock 478 115 464 minecraft:terracotta
fill 478 115 465 479 117 465 minecraft:red_terracotta
setblock 478 115 503 minecraft:red_terracotta
setblock 478 115 504 minecraft:terracotta
fill 479 115 464 479 118 464 minecraft:red_terracotta
setblock 479 115 503 minecraft:terracotta
fill 479 115 504 482 115 504 minecraft:red_terracotta
fill 480 115 503 480 118 503 minecraft:red_terracotta
fill 481 115 502 481 118 502 minecraft:red_terracotta
setblock 482 115 464 minecraft:red_terracotta
setblock 482 115 465 minecraft:terracotta
setblock 483 115 464 minecraft:terracotta
fill 483 115 465 483 118 465 minecraft:red_terracotta
setblock 483 115 504 minecraft:terracotta
fill 484 115 464 484 118 464 minecraft:red_terracotta
setblock 484 115 503 minecraft:terracotta
fill 484 115 504 484 118 504 minecraft:red_terracotta
setblock 485 115 502 minecraft:terracotta
fill 485 115 503 485 118 503 minecraft:red_terracotta
fill 486 115 502 486 118 502 minecraft:red_terracotta
setblock 487 115 465 minecraft:terracotta
setblock 488 115 464 minecraft:terracotta
fill 488 115 465 488 118 465 minecraft:red_terracotta
setblock 488 115 504 minecraft:terracotta
fill 489 115 464 489 118 464 minecraft:red_terracotta
setblock 489 115 503 minecraft:terracotta
fill 489 115 504 489 118 504 minecraft:red_terracotta
setblock 490 115 502 minecraft:terracotta
fill 490 115 503 490 118 503 minecraft:red_terracotta
setblock 493 115 504 minecraft:terracotta
fill 494 115 504 497 115 504 minecraft:red_terracotta
setblock 498 115 504 minecraft:terracotta
fill 499 115 504 499 118 504 minecraft:red_terracotta
fill 500 115 503 500 118 503 minecraft:red_terracotta
fill 501 115 464 502 115 464 minecraft:red_terracotta
fill 502 115 465 502 115 466 minecraft:orange_concrete
setblock 503 115 464 minecraft:terracotta
fill 503 115 466 503 115 479 minecraft:orange_concrete
setblock 503 115 504 minecraft:terracotta
fill 504 115 464 504 118 464 minecraft:red_terracotta
fill 504 115 479 504 115 492 minecraft:orange_concrete
setblock 504 115 503 minecraft:terracotta
fill 504 115 504 504 118 504 minecraft:red_terracotta
fill 505 115 492 505 115 497 minecraft:orange_concrete
fill 505 115 503 505 118 503 minecraft:red_terracotta
setblock 508 115 464 minecraft:terracotta
setblock 508 115 483 minecraft:red_terracotta
setblock 508 115 504 minecraft:terracotta
fill 509 115 464 509 118 464 minecraft:red_terracotta
fill 509 115 479 509 116 479 minecraft:red_terracotta
setblock 509 115 483 minecraft:terracotta
fill 509 115 484 509 118 484 minecraft:red_terracotta
fill 509 115 504 509 118 504 minecraft:red_terracotta
setblock 510 115 477 minecraft:terracotta
fill 510 115 478 510 118 478 minecraft:red_terracotta
setblock 510 115 482 minecraft:terracotta
fill 510 115 483 510 118 483 minecraft:red_terracotta
setblock 510 115 487 minecraft:terracotta
fill 511 115 464 511 116 464 minecraft:red_terracotta
setblock 511 115 476 minecraft:terracotta
fill 511 115 477 511 118 477 minecraft:red_terracotta
setblock 511 115 481 minecraft:terracotta
fill 511 115 482 511 118 482 minecraft:red_terracotta
setblock 511 115 486 minecraft:terracotta
fill 511 115 487 511 118 487 minecraft:red_terracotta
setblock 471 116 464 minecraft:red_terracotta
setblock 471 116 465 minecraft:terracotta
fill 471 116 466 471 119 466 minecraft:red_terracotta
setblock 471 116 469 minecraft:red_terracotta
setblock 471 116 480 minecraft:terracotta
fill 471 116 481 471 119 481 minecraft:red_terracotta
setblock 471 116 485 minecraft:terracotta
setblock 472 116 464 minecraft:terracotta
setblock 472 116 504 minecraft:terracotta
fill 473 116 464 476 116 464 minecraft:red_terracotta
fill 473 116 504 476 116 504 minecraft:red_terracotta
setblock 476 116 465 minecraft:terracotta
setblock 477 116 464 minecraft:terracotta
fill 477 116 465 477 119 465 minecraft:red_terracotta
setblock 477 116 504 minecraft:terracotta
fill 478 116 464 478 119 464 minecraft:red_terracotta
setblock 478 116 503 minecraft:terracotta
fill 478 116 504 481 116 504 minecraft:red_terracotta
fill 479 116 503 479 119 503 minecraft:red_terracotta
setblock 481 116 464 minecraft:red_terracotta
setblock 481 116 465 minecraft:terracotta
setblock 482 116 464 minecraft:terracotta
fill 482 116 465 482 118 466 minecraft:red_terracotta
setblock 482 116 504 minecraft:terracotta
fill 483 116 464 483 119 464 minecraft:red_terracotta
fill 483 116 466 484 116 466 minecraft:red_terracotta
setblock 483 116 503 minecraft:terracotta
fill 483 116 504 483 119 504 minecraft:red_terracotta
setblock 484 116 502 minecraft:terracotta
fill 484 116 503 484 119 503 minecraft:red_terracotta
fill 485 116 502 485 119 502 minecraft:red_terracotta
setblock 486 116 465 minecraft:terracotta
setblock 487 116 464 minecraft:terracotta
fill 487 116 465 487 119 465 minecraft:red_terracotta
setblock 487 116 504 minecraft:terracotta
fill 488 116 464 488 119 464 minecraft:red_terracotta
setblock 488 116 503 minecraft:terracotta
fill 488 116 504 488 119 504 minecraft:red_terracotta
setblock 489 116 502 minecraft:terracotta
fill 489 116 503 489 119 503 minecraft:red_terracotta
setblock 492 116 504 minecraft:terracotta
setblock 493 116 503 minecraft:terracotta
fill 493 116 504 496 116 504 minecraft:red_terracotta
setblock 497 116 504 minecraft:terracotta
fill 498 116 504 498 119 504 minecraft:red_terracotta
fill 499 116 503 499 119 503 minecraft:red_terracotta
fill 500 116 464 501 116 464 minecraft:red_terracotta
setblock 502 116 464 minecraft:terracotta
setblock 502 116 504 minecraft:terracotta
fill 503 116 464 503 119 464 minecraft:red_terracotta
setblock 503 116 503 minecraft:terracotta
fill 503 116 504 503 119 504 minecraft:red_terracotta
fill 504 116 503 504 119 503 minecraft:red_terracotta
setblock 505 116 465 minecraft:red_terracotta
setblock 506 116 465 minecraft:terracotta
setblock 507 116 464 minecraft:terracotta
setblock 507 116 504 minecraft:terracotta
fill 508 116 464 508 119 464 minecraft:red_terracotta
setblock 508 116 483 minecraft:terracotta
fill 508 116 504 508 119 504 minecraft:red_terracotta
setblock 509 116 482 minecraft:terracotta
fill 509 116 483 509 119 483 minecraft:red_terracotta
setblock 509 116 486 minecraft:red_terracotta
setblock 510 116 477 minecraft:red_terracotta
setblock 510 116 481 minecraft:terracotta
fill 510 116 482 510 119 482 minecraft:red_terracotta
setblock 510 116 486 minecraft:terracotta
fill 510 116 487 510 119 487 minecraft:red_terracotta
setblock 511 116 465 minecraft:terracotta
fill 511 116 466 511 119 466 minecraft:red_terracotta
setblock 511 116 475 minecraft:terracotta
fill 511 116 476 511 119 476 minecraft:red_terracotta
setblock 511 116 480 minecraft:terracotta
fill 511 116 481 511 119 481 minecraft:red_terracotta
setblock 511 116 485 minecraft:terracotta
fill 511 116 486 511 119 486 minecraft:red_terracotta
setblock 471 117 464 minecraft:terracotta
fill 471 117 465 474 117 465 minecraft:red_terracotta
setblock 471 117 469 minecraft:terracotta
fill 471 117 470 471 120 470 minecraft:red_terracotta
setblock 471 117 479 minecraft:terracotta
fill 471 117 480 471 119 480 minecraft:red_terracotta
setblock 471 117 484 minecraft:terracotta
fill 471 117 485 471 119 486 minecraft:red_terracotta
setblock 471 117 504 minecraft:terracotta
fill 472 117 464 475 117 464 minecraft:red_terracotta
fill 472 117 466 472 118 466 minecraft:red_terracotta
fill 472 117 504 475 117 504 minecraft:red_terracotta
setblock 475 117 465 minecraft:terracotta
setblock 476 117 464 minecraft:terracotta
fill 476 117 465 476 120 465 minecraft:red_terracotta
setblock 476 117 504 minecraft:terracotta
fill 477 117 464 477 120 464 minecraft:red_terracotta
setblock 477 117 503 minecraft:terracotta
fill 477 117 504 480 117 504 minecraft:red_terracotta
fill 478 117 503 478 120 503 minecraft:red_terracotta
setblock 479 117 466 minecraft:terracotta
setblock 480 117 464 minecraft:red_terracotta
setblock 480 117 465 minecraft:terracotta
fill 480 117 466 481 119 466 minecraft:red_terracotta
fill 480 117 502 480 119 502 minecraft:red_terracotta
setblock 481 117 464 minecraft:terracotta
fill 481 117 465 481 120 465 minecraft:red_terracotta
setblock 481 117 504 minecraft:terracotta
fill 482 117 464 482 120 464 minecraft:red_terracotta
setblock 482 117 503 minecraft:terracotta
fill 482 117 504 482 120 504 minecraft:red_terracotta
setblock 483 117 466 minecraft:red_terracotta
setblock 483 117 502 minecraft:terracotta
fill 483 117 503 483 120 503 minecraft:red_terracotta
setblock 484 117 466 minecraft:terracotta
fill 484 117 502 484 120 502 minecraft:red_terracotta
setblock 485 117 465 minecraft:terracotta
fill 485 117 466 485 120 466 minecraft:red_terracotta
setblock 486 117 464 minecraft:terracotta
fill 486 117 465 486 120 465 minecraft:red_terracotta
setblock 486 117 504 minecraft:terracotta
fill 487 117 464 487 120 464 minecraft:red_terracotta
setblock 487 117 503 minecraft:terracotta
fill 487 117 504 487 120 504 minecraft:red_terracotta
setblock 488 117 502 minecraft:terracotta
fill 488 117 503 488 120 503 minecraft:red_terracotta
setblock 489 117 465 minecraft:red_terracotta
setblock 489 117 502 minecraft:red_terracotta
setblock 491 117 464 minecraft:terracotta
setblock 491 117 504 minecraft:terracotta
fill 492 117 464 492 120 464 minecraft:red_terracotta
setblock 492 117 503 minecraft:terracotta
fill 492 117 504 495 117 504 minecraft:red_terracotta
setblock 496 117 504 minecraft:terracotta
fill 497 117 504 497 120 504 minecraft:red_terracotta
fill 498 117 464 500 117 464 minecraft:red_terracotta
fill 498 117 503 498 120 503 minecraft:red_terracotta
setblock 501 117 464 minecraft:terracotta
setblock 501 117 504 minecraft:terracotta
fill 502 117 464 502 119 465 minecraft:red_terracotta
setblock 502 117 503 minecraft:terracotta
fill 502 117 504 502 120 504 minecraft:red_terracotta
fill 503 117 465 504 117 465 minecraft:red_terracotta
fill 503 117 503 503 120 503 minecraft:red_terracotta
setblock 505 117 465 minecraft:terracotta
setblock 506 117 464 minecraft:terracotta
fill 506 117 465 508 118 465 minecraft:red_terracotta
setblock 506 117 504 minecraft:terracotta
fill 507 117 464 507 120 464 minecraft:red_terracotta
setblock 507 117 503 minecraft:terracotta
fill 507 117 504 507 120 504 minecraft:red_terracotta
fill 508 117 483 508 117 484 minecraft:red_terracotta
setblock 509 117 481 minecraft:terracotta
fill 509 117 482 509 119 482 minecraft:red_terracotta
setblock 509 117 486 minecraft:terracotta
setblock 510 117 480 minecraft:terracotta
fill 510 117 481 510 120 481 minecraft:red_terracotta
setblock 510 117 485 minecraft:terracotta
fill 510 117 486 510 120 486 minecraft:red_terracotta
fill 510 117 488 510 118 488 minecraft:red_terracotta
setblock 511 117 464 minecraft:terracotta
fill 511 117 465 511 120 465 minecraft:red_terracotta
fill 511 117 467 511 117 468 minecraft:red_terracotta
fill 511 117 475 511 120 475 minecraft:red_terracotta
setblock 511 117 479 minecraft:terracotta
fill 511 117 480 511 120 480 minecraft:red_terracotta
setblock 511 117 484 minecraft:terracotta
fill 511 117 485 511 120 485 minecraft:red_terracotta
setblock 511 117 489 minecraft:terracotta
fill 471 118 464 473 118 465 minecraft:red_terracotta
setblock 471 118 468 minecraft:terracotta
fill 471 118 469 471 121 469 minecraft:red_terracotta
fill 471 118 471 471 119 471 minecraft:red_terracotta
setblock 471 118 479 minecraft:red_terracotta
setblock 471 118 483 minecraft:terracotta
fill 471 118 484 471 121 484 minecraft:red_terracotta
setblock 471 118 503 minecraft:terracotta
fill 471 118 504 474 118 504 minecraft:red_terracotta
setblock 472 118 467 minecraft:terracotta
setblock 473 118 466 minecraft:light[level=14]
setblock 473 118 474 minecraft:light[level=14]
setblock 473 118 482 minecraft:light[level=14]
setblock 473 118 490 minecraft:light[level=14]
setblock 473 118 498 minecraft:light[level=14]
setblock 474 118 464 minecraft:red_terracotta
setblock 474 118 465 minecraft:terracotta
setblock 475 118 464 minecraft:terracotta
fill 475 118 465 475 121 465 minecraft:red_terracotta
setblock 475 118 504 minecraft:terracotta
fill 476 118 464 476 121 464 minecraft:red_terracotta
setblock 476 118 503 minecraft:terracotta
fill 476 118 504 479 118 504 minecraft:red_terracotta
setblock 477 118 466 minecraft:red_terracotta
fill 477 118 503 477 121 503 minecraft:red_terracotta
setblock 478 118 465 minecraft:red_terracotta
setblock 478 118 466 minecraft:terracotta
setblock 479 118 465 minecraft:terracotta
fill 479 118 466 479 121 466 minecraft:red_terracotta
fill 479 118 502 479 120 502 minecraft:red_terracotta
setblock 480 118 464 minecraft:terracotta
fill 480 118 465 480 121 465 minecraft:red_terracotta
setblock 480 118 504 minecraft:terracotta
fill 481 118 464 481 121 464 minecraft:red_terracotta
setblock 481 118 474 minecraft:light[level=14]
setblock 481 118 482 minecraft:light[level=14]
setblock 481 118 490 minecraft:light[level=14]
setblock 481 118 498 minecraft:light[level=14]
setblock 481 118 503 minecraft:terracotta
fill 481 118 504 481 121 504 minecraft:red_terracotta
setblock 482 118 502 minecraft:terracotta
fill 482 118 503 482 121 503 minecraft:red_terracotta
setblock 483 118 466 minecraft:terracotta
fill 483 118 502 483 121 502 minecraft:red_terracotta
setblock 484 118 465 minecraft:terracotta
fill 484 118 466 484 121 466 minecraft:red_terracotta
setblock 485 118 464 minecraft:terracotta
fill 485 118 465 485 121 465 minecraft:red_terracotta
setblock 485 118 504 minecraft:terracotta
fill 486 118 464 486 121 464 minecraft:red_terracotta
fill 486 118 466 486 119 466 minecraft:red_terracotta
setblock 486 118 503 minecraft:terracotta
fill 486 118 504 486 121 504 minecraft:red_terracotta
setblock 487 118 502 minecraft:terracotta
fill 487 118 503 487 121 503 minecraft:red_terracotta
fill 488 118 502 488 119 502 minecraft:red_terracotta
setblock 489 118 465 minecraft:terracotta
setblock 489 118 466 minecraft:light[level=14]
setblock 489 118 474 minecraft:light[level=14]
setblock 489 118 482 minecraft:light[level=14]
setblock 489 118 490 minecraft:light[level=14]
setblock 489 118 498 minecraft:light[level=14]
setblock 490 118 464 minecraft:terracotta
setblock 490 118 504 minecraft:terracotta
fill 491 118 464 491 121 464 minecraft:red_terracotta
setblock 491 118 503 minecraft:terracotta
fill 491 118 504 494 118 504 minecraft:red_terracotta
setblock 492 118 503 minecraft:red_terracotta
fill 493 118 464 493 119 464 minecraft:red_terracotta
setblock 495 118 504 minecraft:terracotta
fill 496 118 464 499 118 464 minecraft:red_terracotta
fill 496 118 504 496 121 504 minecraft:red_terracotta
setblock 497 118 466 minecraft:light[level=14]
setblock 497 118 474 minecraft:light[level=14]
setblock 497 118 482 minecraft:light[level=14]
setblock 497 118 490 minecraft:light[level=14]
setblock 497 118 498 minecraft:light[level=14]
fill 497 118 503 497 120 503 minecraft:red_terracotta
setblock 500 118 464 minecraft:terracotta
fill 500 118 465 501 120 465 minecraft:red_terracotta
setblock 500 118 504 minecraft:terracotta
fill 501 118 464 501 121 464 minecraft:red_terracotta
setblock 501 118 503 minecraft:terracotta
fill 501 118 504 501 121 504 minecraft:red_terracotta
fill 502 118 503 502 121 503 minecraft:red_terracotta
setblock 503 118 465 minecraft:red_terracotta
setblock 504 118 465 minecraft:terracotta
setblock 505 118 464 minecraft:terracotta
fill 505 118 465 505 121 465 minecraft:red_terracotta
setblock 505 118 466 minecraft:light[level=14]
setblock 505 118 474 minecraft:light[level=14]
setblock 505 118 482 minecraft:light[level=14]
setblock 505 118 490 minecraft:light[level=14]
setblock 505 118 504 minecraft:terracotta
fill 506 118 464 506 121 464 minecraft:red_terracotta
setblock 506 118 503 minecraft:terracotta
fill 506 118 504 506 121 504 minecraft:red_terracotta
setblock 508 118 484 minecraft:red_terracotta
setblock 509 118 465 minecraft:terracotta
fill 509 118 481 509 119 481 minecraft:red_terracotta
setblock 509 118 485 minecraft:terracotta
fill 509 118 486 509 120 487 minecraft:red_terracotta
setblock 510 118 464 minecraft:terracotta
fill 510 118 465 510 121 465 minecraft:red_terracotta
setblock 510 118 479 minecraft:terracotta
fill 510 118 480 510 120 480 minecraft:red_terracotta
setblock 510 118 484 minecraft:terracotta
fill 510 118 485 510 121 485 minecraft:red_terracotta
setblock 510 118 504 minecraft:terracotta
fill 511 118 464 511 121 464 minecraft:red_terracotta
setblock 511 118 467 minecraft:red_terracotta
setblock 511 118 468 minecraft:terracotta
fill 511 118 469 511 119 471 minecraft:red_terracotta
setblock 511 118 478 minecraft:terracotta
fill 511 118 479 511 121 479 minecraft:red_terracotta
setblock 511 118 483 minecraft:terracotta
fill 511 118 484 511 121 484 minecraft:red_terracotta
setblock 511 118 488 minecraft:terracotta
fill 511 118 489 511 121 489 minecraft:red_terracotta
fill 471 119 464 472 119 465 minecraft:red_terracotta
setblock 471 119 467 minecraft:terracotta
fill 471 119 468 472 121 468 minecraft:red_terracotta
setblock 471 119 472 minecraft:terracotta
fill 471 119 479 471 132 479 minecraft:magma_block
setblock 471 119 482 minecraft:terracotta
fill 471 119 483 471 121 483 minecraft:red_terracotta
setblock 471 119 487 minecraft:terracotta
fill 471 119 503 471 121 504 minecraft:red_terracotta
setblock 472 119 466 minecraft:terracotta
fill 472 119 467 472 122 467 minecraft:red_terracotta
fill 472 119 504 473 119 504 minecraft:red_terracotta
setblock 473 119 464 minecraft:red_terracotta
setblock 473 119 465 minecraft:terracotta
setblock 474 119 464 minecraft:terracotta
fill 474 119 465 474 122 465 minecraft:red_terracotta
setblock 474 119 504 minecraft:terracotta
fill 475 119 464 475 122 464 minecraft:red_terracotta
fill 475 119 466 476 119 466 minecraft:red_terracotta
setblock 475 119 503 minecraft:terracotta
fill 475 119 504 478 119 504 minecraft:red_terracotta
fill 476 119 503 476 122 503 minecraft:red_terracotta
setblock 477 119 466 minecraft:terracotta
setblock 478 119 465 minecraft:terracotta
fill 478 119 466 478 122 466 minecraft:red_terracotta
setblock 479 119 464 minecraft:terracotta
fill 479 119 465 479 122 465 minecraft:red_terracotta
setblock 479 119 504 minecraft:terracotta
fill 480 119 464 480 122 464 minecraft:red_terracotta
setblock 480 119 503 minecraft:terracotta
fill 480 119 504 480 122 504 minecraft:red_terracotta
setblock 481 119 502 minecraft:terracotta
fill 481 119 503 481 122 503 minecraft:red_terracotta
setblock 482 119 465 minecraft:red_terracotta
setblock 482 119 466 minecraft:terracotta
fill 482 119 502 482 122 502 minecraft:red_terracotta
setblock 483 119 465 minecraft:terracotta
fill 483 119 466 483 122 466 minecraft:red_terracotta
setblock 484 119 464 minecraft:terracotta
fill 484 119 465 484 122 465 minecraft:red_terracotta
setblock 484 119 504 minecraft:terracotta
fill 485 119 464 485 122 464 minecraft:red_terracotta
setblock 485 119 503 minecraft:terracotta
fill 485 119 504 485 122 504 minecraft:red_terracotta
setblock 486 119 502 minecraft:terracotta
fill 486 119 503 486 122 503 minecraft:red_terracotta
fill 487 119 502 487 120 502 minecraft:red_terracotta
setblock 488 119 465 minecraft:terracotta
setblock 489 119 464 minecraft:terracotta
fill 489 119 465 489 120 465 minecraft:red_terracotta
setblock 489 119 504 minecraft:terracotta
fill 490 119 464 490 122 464 minecraft:red_terracotta
setblock 490 119 503 minecraft:terracotta
fill 490 119 504 493 119 504 minecraft:red_terracotta
setblock 491 119 503 minecraft:red_terracotta
setblock 494 119 464 minecraft:terracotta
setblock 494 119 504 minecraft:terracotta
fill 495 119 464 498 119 464 minecraft:red_terracotta
fill 495 119 504 495 122 504 minecraft:red_terracotta
setblock 499 119 464 minecraft:terracotta
fill 499 119 465 499 122 465 minecraft:red_terracotta
fill 499 119 480 499 120 480 minecraft:orange_concrete
setblock 499 119 504 minecraft:terracotta
fill 500 119 464 500 122 464 minecraft:red_terracotta
setblock 500 119 503 minecraft:terracotta
fill 500 119 504 500 122 504 minecraft:red_terracotta
fill 501 119 503 501 122 503 minecraft:red_terracotta
setblock 503 119 465 minecraft:terracotta
fill 503 119 466 506 119 466 minecraft:red_terracotta
setblock 504 119 464 minecraft:terracotta
fill 504 119 465 504 122 465 minecraft:red_terracotta
setblock 504 119 504 minecraft:terracotta
fill 505 119 464 505 122 464 minecraft:red_terracotta
setblock 505 119 503 minecraft:terracotta
fill 505 119 504 505 122 504 minecraft:red_terracotta
fill 506 119 465 507 119 465 minecraft:red_terracotta
setblock 506 119 503 minecraft:red_terracotta
setblock 508 119 465 minecraft:terracotta
setblock 509 119 464 minecraft:terracotta
fill 509 119 465 509 122 465 minecraft:red_terracotta
setblock 509 119 484 minecraft:terracotta
fill 509 119 485 509 120 485 minecraft:red_terracotta
setblock 509 119 504 minecraft:terracotta
fill 510 119 464 510 122 464 minecraft:red_terracotta
fill 510 119 466 510 119 467 minecraft:red_terracotta
setblock 510 119 468 minecraft:terracotta
setblock 510 119 479 minecraft:red_terracotta
setblock 510 119 483 minecraft:terracotta
fill 510 119 484 510 122 484 minecraft:red_terracotta
setblock 510 119 488 minecraft:terracotta
setblock 510 119 504 minecraft:red_terracotta
setblock 511 119 467 minecraft:terracotta
fill 511 119 468 511 122 468 minecraft:red_terracotta
setblock 511 119 472 minecraft:terracotta
fill 511 119 473 511 121 474 minecraft:red_terracotta
setblock 511 119 477 minecraft:terracotta
fill 511 119 478 511 121 478 minecraft:red_terracotta
setblock 511 119 482 minecraft:terracotta
fill 511 119 483 511 122 483 minecraft:red_terracotta
setblock 511 119 487 minecraft:terracotta
fill 511 119 488 511 122 488 minecraft:red_terracotta
fill 511 119 490 511 120 490 minecraft:red_terracotta
fill 471 120 464 471 120 465 minecraft:red_terracotta
setblock 471 120 466 minecraft:terracotta
fill 471 120 467 471 123 467 minecraft:red_terracotta
setblock 471 120 471 minecraft:terracotta
fill 471 120 472 471 123 472 minecraft:red_terracotta
fill 471 120 480 471 133 480 minecraft:shroomlight
fill 471 120 481 471 133 481 minecraft:magma_block
setblock 471 120 482 minecraft:red_terracotta
setblock 471 120 485 minecraft:red_terracotta
setblock 471 120 486 minecraft:terracotta
fill 471 120 487 471 122 487 minecraft:red_terracotta
setblock 472 120 464 minecraft:red_terracotta
setblock 472 120 465 minecraft:terracotta
fill 472 120 466 475 120 466 minecraft:red_terracotta
setblock 472 120 469 minecraft:red_terracotta
setblock 472 120 504 minecraft:red_terracotta
setblock 473 120 464 minecraft:terracotta
fill 473 120 465 473 123 465 minecraft:red_terracotta
setblock 473 120 504 minecraft:terracotta
fill 474 120 464 474 123 464 minecraft:red_terracotta
fill 474 120 504 477 120 504 minecraft:red_terracotta
fill 475 120 503 475 123 503 minecraft:red_terracotta
setblock 476 120 466 minecraft:terracotta
setblock 477 120 465 minecraft:terracotta
fill 477 120 466 477 123 466 minecraft:red_terracotta
setblock 478 120 464 minecraft:terracotta
fill 478 120 465 478 123 465 minecraft:red_terracotta
fill 478 120 502 478 121 502 minecraft:red_terracotta
setblock 478 120 504 minecraft:terracotta
fill 479 120 464 479 123 464 minecraft:red_terracotta
setblock 479 120 467 minecraft:red_terracotta
setblock 479 120 503 minecraft:terracotta
fill 479 120 504 479 123 504 minecraft:red_terracotta
setblock 480 120 466 minecraft:red_terracotta
setblock 480 120 467 minecraft:terracotta
setblock 480 120 502 minecraft:terracotta
fill 480 120 503 480 123 503 minecraft:red_terracotta
setblock 481 120 466 minecraft:terracotta
fill 481 120 467 483 121 467 minecraft:red_terracotta
fill 481 120 502 481 123 502 minecraft:red_terracotta
setblock 482 120 465 minecraft:terracotta
fill 482 120 466 482 123 466 minecraft:red_terracotta
setblock 483 120 464 minecraft:terracotta
fill 483 120 465 483 123 465 minecraft:red_terracotta
setblock 483 120 504 minecraft:terracotta
fill 484 120 464 484 123 464 minecraft:red_terracotta
setblock 484 120 503 minecraft:terracotta
fill 484 120 504 484 123 504 minecraft:red_terracotta
setblock 485 120 502 minecraft:terracotta
fill 485 120 503 485 123 503 minecraft:red_terracotta
setblock 486 120 466 minecraft:terracotta
fill 486 120 502 486 121 502 minecraft:red_terracotta
setblock 487 120 465 minecraft:terracotta
setblock 488 120 464 minecraft:terracotta
fill 488 120 465 488 121 465 minecraft:red_terracotta
setblock 488 120 504 minecraft:terracotta
fill 489 120 464 489 123 464 minecraft:red_terracotta
setblock 489 120 503 minecraft:terracotta
fill 489 120 504 492 120 504 minecraft:red_terracotta
setblock 490 120 503 minecraft:red_terracotta
setblock 493 120 464 minecraft:terracotta
setblock 493 120 504 minecraft:terracotta
fill 494 120 464 497 120 464 minecraft:red_terracotta
fill 494 120 504 494 123 504 minecraft:red_terracotta
setblock 498 120 464 minecraft:terracotta
fill 498 120 465 498 123 465 minecraft:red_terracotta
setblock 498 120 504 minecraft:terracotta
fill 499 120 464 499 123 464 minecraft:red_terracotta
setblock 499 120 503 minecraft:terracotta
fill 499 120 504 499 123 504 minecraft:red_terracotta
fill 500 120 503 500 122 503 minecraft:red_terracotta
setblock 501 120 466 minecraft:terracotta
setblock 502 120 464 minecraft:red_terracotta
setblock 502 120 465 minecraft:terracotta
fill 502 120 466 505 120 466 minecraft:red_terracotta
setblock 503 120 464 minecraft:terracotta
fill 503 120 465 503 123 465 minecraft:red_terracotta
setblock 503 120 504 minecraft:terracotta
fill 504 120 464 504 123 464 minecraft:red_terracotta
setblock 504 120 503 minecraft:terracotta
fill 504 120 504 504 123 504 minecraft:red_terracotta
setblock 505 120 503 minecraft:red_terracotta
setblock 506 120 465 minecraft:red_terracotta
setblock 506 120 466 minecraft:terracotta
setblock 507 120 465 minecraft:terracotta
fill 507 120 466 507 121 466 minecraft:red_terracotta
setblock 508 120 464 minecraft:terracotta
fill 508 120 465 508 123 465 minecraft:red_terracotta
setblock 508 120 504 minecraft:terracotta
fill 509 120 464 509 123 464 minecraft:red_terracotta
setblock 509 120 483 minecraft:terracotta
setblock 509 120 484 minecraft:red_terracotta
setblock 509 120 504 minecraft:red_terracotta
setblock 510 120 466 minecraft:red_terracotta
setblock 510 120 467 minecraft:terracotta
fill 510 120 468 510 122 469 minecraft:red_terracotta
setblock 510 120 482 minecraft:terracotta
fill 510 120 483 510 121 483 minecraft:red_terracotta
setblock 510 120 487 minecraft:terracotta
fill 510 120 488 510 122 488 minecraft:red_terracotta
setblock 511 120 466 minecraft:terracotta
fill 511 120 467 511 123 467 minecraft:red_terracotta
fill 511 120 469 511 120 470 minecraft:red_terracotta
setblock 511 120 471 minecraft:terracotta
fill 511 120 472 511 123 472 minecraft:red_terracotta
setblock 511 120 476 minecraft:terracotta
fill 511 120 477 511 121 477 minecraft:red_terracotta
setblock 511 120 481 minecraft:terracotta
fill 511 120 482 511 123 482 minecraft:red_terracotta
setblock 511 120 486 minecraft:terracotta
fill 511 120 487 511 123 487 minecraft:red_terracotta
setblock 471 121 464 minecraft:red_terracotta
setblock 471 121 465 minecraft:terracotta
fill 471 121 466 474 121 466 minecraft:red_terracotta
setblock 471 121 470 minecraft:terracotta
fill 471 121 471 471 124 471 minecraft:red_terracotta
fill 471 121 473 471 122 473 minecraft:red_terracotta
setblock 471 121 485 minecraft:terracotta
fill 471 121 486 471 122 486 minecraft:red_terracotta
fill 471 121 488 471 122 488 minecraft:red_terracotta
setblock 472 121 464 minecraft:terracotta
fill 472 121 465 472 124 465 minecraft:red_terracotta
setblock 472 121 469 minecraft:terracotta
fill 472 121 470 472 124 470 minecraft:red_terracotta
setblock 472 121 504 minecraft:terracotta
fill 473 121 464 473 124 464 minecraft:red_terracotta
setblock 473 121 467 minecraft:red_terracotta
fill 473 121 504 476 121 504 minecraft:red_terracotta
setblock 475 121 466 minecraft:terracotta
setblock 476 121 465 minecraft:terracotta
fill 476 121 466 476 124 466 minecraft:red_terracotta
setblock 477 121 464 minecraft:terracotta
fill 477 121 465 477 124 465 minecraft:red_terracotta
setblock 477 121 504 minecraft:terracotta
fill 478 121 464 478 124 464 minecraft:red_terracotta
setblock 478 121 467 minecraft:red_terracotta
setblock 478 121 503 minecraft:terracotta
fill 478 121 504 478 124 504 minecraft:red_terracotta
setblock 479 121 467 minecraft:terracotta
setblock 479 121 502 minecraft:terracotta
fill 479 121 503 479 124 503 minecraft:red_terracotta
setblock 480 121 466 minecraft:terracotta
fill 480 121 467 480 124 467 minecraft:red_terracotta
fill 480 121 502 480 124 502 minecraft:red_terracotta
setblock 481 121 465 minecraft:terracotta
fill 481 121 466 481 124 466 minecraft:red_terracotta
setblock 482 121 464 minecraft:terracotta
fill 482 121 465 482 124 465 minecraft:red_terracotta
setblock 482 121 504 minecraft:terracotta
fill 483 121 464 483 124 464 minecraft:red_terracotta
setblock 483 121 503 minecraft:terracotta
fill 483 121 504 483 124 504 minecraft:red_terracotta
setblock 484 121 502 minecraft:terracotta
fill 484 121 503 484 124 503 minecraft:red_terracotta
setblock 485 121 466 minecraft:terracotta
fill 485 121 502 485 122 502 minecraft:red_terracotta
setblock 486 121 465 minecraft:terracotta
setblock 486 121 466 minecraft:red_terracotta
setblock 487 121 464 minecraft:terracotta
fill 487 121 465 487 122 465 minecraft:red_terracotta
setblock 487 121 504 minecraft:terracotta
fill 488 121 464 488 123 464 minecraft:red_terracotta
setblock 488 121 503 minecraft:terracotta
fill 488 121 504 491 121 504 minecraft:red_terracotta
setblock 489 121 503 minecraft:red_terracotta
setblock 492 121 464 minecraft:terracotta
setblock 492 121 504 minecraft:terracotta
fill 493 121 464 496 121 464 minecraft:red_terracotta
fill 493 121 504 493 122 504 minecraft:red_terracotta
setblock 497 121 464 minecraft:terracotta
fill 497 121 465 497 124 465 minecraft:red_terracotta
setblock 497 121 504 minecraft:terracotta
fill 498 121 464 498 124 464 minecraft:red_terracotta
setblock 498 121 503 minecraft:terracotta
fill 498 121 504 498 124 504 minecraft:red_terracotta
fill 499 121 503 499 122 503 minecraft:red_terracotta
setblock 500 121 465 minecraft:red_terracotta
setblock 500 121 466 minecraft:terracotta
setblock 501 121 465 minecraft:terracotta
fill 501 121 466 504 121 466 minecraft:red_terracotta
setblock 502 121 464 minecraft:terracotta
fill 502 121 465 502 124 465 minecraft:red_terracotta
setblock 502 121 504 minecraft:terracotta
fill 503 121 464 503 124 464 minecraft:red_terracotta
setblock 503 121 503 minecraft:terracotta
fill 503 121 504 503 123 504 minecraft:red_terracotta
setblock 504 121 503 minecraft:red_terracotta
setblock 505 121 466 minecraft:terracotta
setblock 506 121 465 minecraft:terracotta
fill 506 121 466 506 122 466 minecraft:red_terracotta
setblock 507 121 464 minecraft:terracotta
fill 507 121 465 507 124 465 minecraft:red_terracotta
setblock 507 121 504 minecraft:terracotta
fill 508 121 464 508 124 464 minecraft:red_terracotta
setblock 508 121 504 minecraft:red_terracotta
setblock 510 121 466 minecraft:terracotta
fill 510 121 467 510 124 467 minecraft:red_terracotta
setblock 510 121 470 minecraft:red_terracotta
setblock 510 121 481 minecraft:terracotta
setblock 510 121 482 minecraft:red_terracotta
setblock 510 121 486 minecraft:terracotta
fill 510 121 487 510 122 487 minecraft:red_terracotta
setblock 511 121 465 minecraft:terracotta
fill 511 121 466 511 124 466 minecraft:red_terracotta
setblock 511 121 469 minecraft:red_terracotta
setblock 511 121 470 minecraft:terracotta
fill 511 121 471 511 124 471 minecraft:red_terracotta
setblock 511 121 475 minecraft:terracotta
setblock 511 121 476 minecraft:red_terracotta
setblock 511 121 480 minecraft:terracotta
fill 511 121 481 511 122 481 minecraft:red_terracotta
setblock 511 121 485 minecraft:terracotta
fill 511 121 486 511 124 486 minecraft:red_terracotta
setblock 511 121 490 minecraft:terracotta
setblock 471 122 464 minecraft:terracotta
fill 471 122 465 471 124 466 minecraft:red_terracotta
setblock 471 122 468 minecraft:red_terracotta
setblock 471 122 469 minecraft:terracotta
fill 471 122 470 471 125 470 minecraft:red_terracotta
setblock 471 122 504 minecraft:terracotta
fill 472 122 464 472 125 464 minecraft:red_terracotta
fill 472 122 466 473 122 466 minecraft:red_terracotta
setblock 472 122 468 minecraft:terracotta
fill 472 122 469 472 125 469 minecraft:red_terracotta
fill 472 122 504 475 122 504 minecraft:red_terracotta
setblock 473 122 467 minecraft:terracotta
fill 473 122 468 473 124 468 minecraft:red_terracotta
setblock 474 122 466 minecraft:terracotta
setblock 475 122 465 minecraft:terracotta
fill 475 122 466 475 125 466 minecraft:red_terracotta
setblock 476 122 464 minecraft:terracotta
fill 476 122 465 476 125 465 minecraft:red_terracotta
setblock 476 122 504 minecraft:terracotta
fill 477 122 464 477 125 464 minecraft:red_terracotta
setblock 477 122 467 minecraft:red_terracotta
setblock 477 122 503 minecraft:terracotta
fill 477 122 504 477 125 504 minecraft:red_terracotta
setblock 478 122 467 minecraft:terracotta
setblock 478 122 502 minecraft:terracotta
fill 478 122 503 478 125 503 minecraft:red_terracotta
setblock 479 122 466 minecraft:terracotta
fill 479 122 467 479 124 467 minecraft:red_terracotta
fill 479 122 502 479 123 502 minecraft:red_terracotta
setblock 480 122 465 minecraft:terracotta
fill 480 122 466 480 125 466 minecraft:red_terracotta
setblock 481 122 464 minecraft:terracotta
fill 481 122 465 481 125 465 minecraft:red_terracotta
fill 481 122 467 482 122 467 minecraft:red_terracotta
setblock 481 122 504 minecraft:terracotta
fill 482 122 464 482 125 464 minecraft:red_terracotta
setblock 482 122 503 minecraft:terracotta
fill 482 122 504 482 125 504 minecraft:red_terracotta
setblock 483 122 502 minecraft:terracotta
fill 483 122 503 483 125 503 minecraft:red_terracotta
setblock 484 122 466 minecraft:terracotta
setblock 484 122 502 minecraft:red_terracotta
setblock 485 122 465 minecraft:terracotta
setblock 485 122 466 minecraft:red_terracotta
setblock 486 122 464 minecraft:terracotta
fill 486 122 465 486 123 465 minecraft:red_terracotta
setblock 486 122 504 minecraft:terracotta
fill 487 122 464 487 124 464 minecraft:red_terracotta
setblock 487 122 503 minecraft:terracotta
fill 487 122 504 490 122 504 minecraft:red_terracotta
setblock 488 122 503 minecraft:red_terracotta
setblock 491 122 464 minecraft:terracotta
setblock 491 122 504 minecraft:terracotta
fill 492 122 464 495 122 464 minecraft:red_terracotta
setblock 492 122 504 minecraft:red_terracotta
setblock 496 122 464 minecraft:terracotta
setblock 496 122 504 minecraft:terracotta
fill 497 122 464 497 125 464 minecraft:red_terracotta
fill 497 122 504 497 124 504 minecraft:red_terracotta
setblock 499 122 466 minecraft:terracotta
setblock 500 122 465 minecraft:terracotta
fill 500 122 466 503 122 466 minecraft:red_terracotta
setblock 501 122 464 minecraft:terracotta
fill 501 122 465 501 125 465 minecraft:red_terracotta
setblock 501 122 504 minecraft:terracotta
fill 502 122 464 502 125 464 minecraft:red_terracotta
setblock 502 122 503 minecraft:terracotta
fill 502 122 504 502 124 504 minecraft:red_terracotta
setblock 504 122 466 minecraft:terracotta
setblock 505 122 465 minecraft:terracotta
fill 505 122 466 505 123 466 minecraft:red_terracotta
setblock 506 122 464 minecraft:terracotta
fill 506 122 465 506 124 465 minecraft:red_terracotta
setblock 506 122 504 minecraft:terracotta
fill 507 122 464 507 125 464 minecraft:red_terracotta
setblock 510 122 465 minecraft:terracotta
fill 510 122 466 510 124 466 minecraft:red_terracotta
setblock 510 122 470 minecraft:terracotta
fill 510 122 471 510 125 471 minecraft:red_terracotta
setblock 510 122 485 minecraft:terracotta
setblock 510 122 486 minecraft:red_terracotta
setblock 511 122 464 minecraft:terracotta
fill 511 122 465 511 125 465 minecraft:red_terracotta
setblock 511 122 469 minecraft:terracotta
fill 511 122 470 511 125 470 minecraft:red_terracotta
setblock 511 122 473 minecraft:red_terracotta
setblock 511 122 474 minecraft:terracotta
fill 511 122 475 511 124 475 minecraft:red_terracotta
setblock 511 122 479 minecraft:terracotta
setblock 511 122 480 minecraft:red_terracotta
setblock 511 122 484 minecraft:terracotta
fill 511 122 485 511 124 485 minecraft:red_terracotta
setblock 511 122 489 minecraft:terracotta
fill 511 122 490 511 124 490 minecraft:red_terracotta
fill 471 123 464 471 126 464 minecraft:red_terracotta
setblock 471 123 468 minecraft:terracotta
fill 471 123 469 471 126 469 minecraft:red_terracotta
setblock 471 123 473 minecraft:terracotta
fill 471 123 504 474 123 504 minecraft:red_terracotta
setblock 472 123 466 minecraft:red_terracotta
setblock 472 123 467 minecraft:terracotta
fill 472 123 468 472 126 468 minecraft:red_terracotta
setblock 473 123 466 minecraft:terracotta
fill 473 123 467 473 124 467 minecraft:red_terracotta
setblock 474 123 465 minecraft:terracotta
fill 474 123 466 474 125 466 minecraft:red_terracotta
setblock 475 123 464 minecraft:terracotta
fill 475 123 465 475 126 465 minecraft:red_terracotta
setblock 475 123 504 minecraft:terracotta
fill 476 123 464 476 126 464 minecraft:red_terracotta
setblock 476 123 503 minecraft:terracotta
fill 476 123 504 476 126 504 minecraft:red_terracotta
setblock 477 123 467 minecraft:terracotta
fill 477 123 503 477 126 503 minecraft:red_terracotta
setblock 478 123 466 minecraft:terracotta
fill 478 123 467 478 124 467 minecraft:red_terracotta
setblock 479 123 465 minecraft:terracotta
fill 479 123 466 479 126 466 minecraft:red_terracotta
setblock 480 123 464 minecraft:terracotta
fill 480 123 465 480 126 465 minecraft:red_terracotta
setblock 480 123 504 minecraft:terracotta
fill 481 123 464 481 126 464 minecraft:red_terracotta
setblock 481 123 467 minecraft:red_terracotta
setblock 481 123 503 minecraft:terracotta
fill 481 123 504 481 126 504 minecraft:red_terracotta
setblock 482 123 502 minecraft:terracotta
fill 482 123 503 482 125 503 minecraft:red_terracotta
setblock 483 123 466 minecraft:terracotta
setblock 483 123 502 minecraft:red_terracotta
setblock 484 123 465 minecraft:terracotta
setblock 484 123 466 minecraft:red_terracotta
setblock 485 123 464 minecraft:terracotta
fill 485 123 465 485 124 465 minecraft:red_terracotta
setblock 485 123 504 minecraft:terracotta
fill 486 123 464 486 124 464 minecraft:red_terracotta
setblock 486 123 503 minecraft:terracotta
fill 486 123 504 489 123 504 minecraft:red_terracotta
fill 490 123 464 490 139 464 minecraft:magma_block
setblock 490 123 504 minecraft:terracotta
fill 491 123 464 491 136 464 minecraft:shroomlight
fill 492 123 464 492 135 464 minecraft:magma_block
setblock 494 123 464 minecraft:red_terracotta
setblock 495 123 464 minecraft:terracotta
setblock 495 123 504 minecraft:terracotta
fill 496 123 464 496 126 464 minecraft:red_terracotta
fill 496 123 504 496 124 504 minecraft:red_terracotta
setblock 499 123 465 minecraft:terracotta
fill 499 123 466 502 123 466 minecraft:red_terracotta
setblock 500 123 464 minecraft:terracotta
fill 500 123 465 500 126 465 minecraft:red_terracotta
setblock 500 123 504 minecraft:terracotta
fill 501 123 464 501 126 464 minecraft:red_terracotta
fill 501 123 504 501 124 504 minecraft:red_terracotta
setblock 503 123 466 minecraft:terracotta
setblock 504 123 465 minecraft:terracotta
setblock 504 123 466 minecraft:red_terracotta
setblock 505 123 464 minecraft:terracotta
fill 505 123 465 505 124 465 minecraft:red_terracotta
fill 506 123 464 506 125 464 minecraft:red_terracotta
setblock 509 123 465 minecraft:terracotta
setblock 510 123 464 minecraft:terracotta
setblock 510 123 465 minecraft:red_terracotta
setblock 510 123 468 minecraft:red_terracotta
setblock 510 123 469 minecraft:terracotta
fill 510 123 470 510 126 470 minecraft:red_terracotta
fill 511 123 464 511 126 464 minecraft:red_terracotta
setblock 511 123 468 minecraft:terracotta
fill 511 123 469 511 126 469 minecraft:red_terracotta
setblock 511 123 473 minecraft:terracotta
fill 511 123 474 511 126 474 minecraft:red_terracotta
setblock 511 123 483 minecraft:terracotta
setblock 511 123 484 minecraft:red_terracotta
setblock 511 123 488 minecraft:terracotta
fill 511 123 489 511 124 489 minecraft:red_terracotta
setblock 471 124 467 minecraft:terracotta
fill 471 124 468 471 127 468 minecraft:red_terracotta
setblock 471 124 472 minecraft:terracotta
fill 471 124 473 471 127 473 minecraft:red_terracotta
setblock 472 124 466 minecraft:terracotta
fill 472 124 467 472 127 467 minecraft:red_terracotta
fill 472 124 504 473 124 504 minecraft:red_terracotta
setblock 473 124 465 minecraft:terracotta
setblock 473 124 466 minecraft:red_terracotta
setblock 474 124 464 minecraft:terracotta
fill 474 124 465 474 127 465 minecraft:red_terracotta
setblock 474 124 504 minecraft:terracotta
fill 475 124 464 475 127 464 minecraft:red_terracotta
fill 475 124 504 475 127 504 minecraft:red_terracotta
fill 476 124 503 476 126 503 minecraft:red_terracotta
setblock 477 124 466 minecraft:terracotta
setblock 477 124 467 minecraft:red_terracotta
setblock 478 124 465 minecraft:terracotta
fill 478 124 466 478 127 466 minecraft:red_terracotta
setblock 479 124 464 minecraft:terracotta
fill 479 124 465 479 127 465 minecraft:red_terracotta
setblock 479 124 504 minecraft:terracotta
fill 480 124 464 480 127 464 minecraft:red_terracotta
setblock 480 124 503 minecraft:terracotta
fill 480 124 504 480 127 504 minecraft:red_terracotta
fill 481 124 503 481 126 503 minecraft:red_terracotta
setblock 482 124 466 minecraft:terracotta
setblock 483 124 465 minecraft:terracotta
setblock 483 124 466 minecraft:red_terracotta
setblock 484 124 464 minecraft:terracotta
fill 484 124 465 484 125 465 minecraft:red_terracotta
setblock 484 124 504 minecraft:terracotta
fill 485 124 464 485 125 464 minecraft:red_terracotta
setblock 485 124 503 minecraft:terracotta
fill 485 124 504 488 124 504 minecraft:red_terracotta
fill 495 124 464 495 125 464 minecraft:red_terracotta
setblock 498 124 465 minecraft:terracotta
setblock 499 124 464 minecraft:terracotta
fill 499 124 465 499 126 465 minecraft:red_terracotta
setblock 499 124 504 minecraft:terracotta
fill 500 124 464 500 127 464 minecraft:red_terracotta
fill 500 124 466 501 124 466 minecraft:red_terracotta
fill 500 124 504 500 125 504 minecraft:red_terracotta
setblock 502 124 466 minecraft:terracotta
setblock 503 124 465 minecraft:terracotta
setblock 503 124 466 minecraft:red_terracotta
setblock 504 124 464 minecraft:terracotta
fill 504 124 465 504 125 465 minecraft:red_terracotta
fill 505 124 464 505 126 464 minecraft:red_terracotta
setblock 509 124 464 minecraft:terracotta
fill 510 124 464 510 125 464 minecraft:red_terracotta
setblock 510 124 468 minecraft:terracotta
fill 510 124 469 510 127 469 minecraft:red_terracotta
setblock 511 124 467 minecraft:terracotta
fill 511 124 468 511 127 468 minecraft:red_terracotta
setblock 511 124 472 minecraft:terracotta
fill 511 124 473 511 127 473 minecraft:red_terracotta
setblock 511 124 487 minecraft:terracotta
setblock 511 124 488 minecraft:red_terracotta
setblock 471 125 465 minecraft:red_terracotta
setblock 471 125 466 minecraft:terracotta
fill 471 125 467 471 128 467 minecraft:red_terracotta
setblock 471 125 471 minecraft:terracotta
fill 471 125 472 471 128 472 minecraft:red_terracotta
setblock 472 125 465 minecraft:terracotta
fill 472 125 466 472 128 466 minecraft:red_terracotta
setblock 472 125 470 minecraft:terracotta
setblock 473 125 464 minecraft:terracotta
fill 473 125 465 473 128 465 minecraft:red_terracotta
setblock 473 125 504 minecraft:terracotta
fill 474 125 464 474 128 464 minecraft:red_terracotta
fill 474 125 504 474 128 504 minecraft:red_terracotta
setblock 476 125 466 minecraft:terracotta
setblock 477 125 465 minecraft:terracotta
fill 477 125 466 477 127 466 minecraft:red_terracotta
setblock 478 125 464 minecraft:terracotta
fill 478 125 465 478 128 465 minecraft:red_terracotta
setblock 478 125 504 minecraft:terracotta
fill 479 125 464 479 128 464 minecraft:red_terracotta
setblock 479 125 503 minecraft:terracotta
fill 479 125 504 479 128 504 minecraft:red_terracotta
fill 480 125 503 480 127 503 minecraft:red_terracotta
setblock 481 125 466 minecraft:terracotta
setblock 482 125 465 minecraft:terracotta
setblock 482 125 466 minecraft:red_terracotta
setblock 483 125 464 minecraft:terracotta
setblock 483 125 465 minecraft:red_terracotta
setblock 483 125 504 minecraft:terracotta
fill 484 125 464 484 126 464 minecraft:red_terracotta
fill 484 125 504 486 125 504 minecraft:red_terracotta
setblock 498 125 464 minecraft:terracotta
setblock 498 125 465 minecraft:red_terracotta
setblock 498 125 504 minecraft:terracotta
fill 499 125 464 499 128 464 minecraft:red_terracotta
setblock 499 125 504 minecraft:red_terracotta
setblock 502 125 465 minecraft:terracotta
setblock 503 125 464 minecraft:terracotta
setblock 503 125 465 minecraft:red_terracotta
fill 504 125 464 504 126 464 minecraft:red_terracotta
setblock 508 125 464 minecraft:terracotta
setblock 509 125 464 minecraft:red_terracotta
setblock 510 125 467 minecraft:terracotta
fill 510 125 468 510 128 468 minecraft:red_terracotta
setblock 511 125 466 minecraft:terracotta
fill 511 125 467 511 128 467 minecraft:red_terracotta
setblock 511 125 471 minecraft:terracotta
fill 511 125 472 511 128 472 minecraft:red_terracotta
setblock 471 126 465 minecraft:terracotta
fill 471 126 466 471 129 466 minecraft:red_terracotta
setblock 471 126 470 minecraft:terracotta
fill 471 126 471 472 128 471 minecraft:red_terracotta
setblock 472 126 464 minecraft:terracotta
fill 472 126 465 472 127 465 minecraft:red_terracotta
setblock 472 126 469 minecraft:terracotta
fill 472 126 470 472 129 470 minecraft:red_terracotta
fill 473 126 464 473 129 464 minecraft:red_terracotta
setblock 473 126 466 minecraft:light[level=14]
setblock 473 126 474 minecraft:light[level=14]
setblock 473 126 482 minecraft:light[level=14]
setblock 473 126 490 minecraft:light[level=14]
setblock 473 126 498 minecraft:light[level=14]
fill 473 126 504 473 129 504 minecraft:red_terracotta
setblock 475 126 466 minecraft:terracotta
setblock 476 126 465 minecraft:terracotta
fill 476 126 466 476 127 466 minecraft:red_terracotta
setblock 477 126 464 minecraft:terracotta
fill 477 126 465 477 129 465 minecraft:red_terracotta
setblock 477 126 504 minecraft:terracotta
fill 478 126 464 478 129 464 minecraft:red_terracotta
setblock 478 126 503 minecraft:terracotta
fill 478 126 504 478 129 504 minecraft:red_terracotta
fill 479 126 503 479 128 503 minecraft:red_terracotta
setblock 480 126 466 minecraft:terracotta
setblock 481 126 465 minecraft:terracotta
setblock 481 126 466 minecraft:light[level=14]
setblock 481 126 474 minecraft:light[level=14]
setblock 481 126 482 minecraft:light[level=14]
setblock 481 126 490 minecraft:light[level=14]
setblock 481 126 498 minecraft:light[level=14]
setblock 482 126 464 minecraft:terracotta
setblock 482 126 465 minecraft:red_terracotta
setblock 482 126 504 minecraft:terracotta
fill 483 126 464 483 127 464 minecraft:red_terracotta
fill 483 126 504 484 126 504 minecraft:red_terracotta
setblock 489 126 466 minecraft:light[level=14]
setblock 489 126 474 minecraft:light[level=14]
setblock 489 126 482 minecraft:light[level=14]
setblock 489 126 490 minecraft:light[level=14]
setblock 489 126 498 minecraft:light[level=14]
setblock 497 126 464 minecraft:terracotta
setblock 497 126 466 minecraft:light[level=14]
setblock 497 126 474 minecraft:light[level=14]
setblock 497 126 482 minecraft:light[level=14]
setblock 497 126 490 minecraft:light[level=14]
setblock 497 126 498 minecraft:light[level=14]
fill 498 126 464 498 128 464 minecraft:red_terracotta
setblock 501 126 465 minecraft:terracotta
setblock 502 126 464 minecraft:terracotta
setblock 502 126 465 minecraft:red_terracotta
setblock 503 126 464 minecraft:red_terracotta
setblock 505 126 466 minecraft:light[level=14]
setblock 505 126 474 minecraft:light[level=14]
setblock 505 126 482 minecraft:light[level=14]
setblock 505 126 490 minecraft:light[level=14]
setblock 510 126 467 minecraft:red_terracotta
setblock 510 126 471 minecraft:terracotta
setblock 511 126 465 minecraft:terracotta
fill 511 126 466 511 129 466 minecraft:red_terracotta
setblock 511 126 470 minecraft:terracotta
fill 511 126 471 511 129 471 minecraft:red_terracotta
setblock 511 126 475 minecraft:terracotta
setblock 471 127 464 minecraft:terracotta
fill 471 127 465 471 130 465 minecraft:red_terracotta
setblock 471 127 469 minecraft:terracotta
fill 471 127 470 471 130 470 minecraft:red_terracotta
fill 472 127 464 472 130 464 minecraft:red_terracotta
setblock 472 127 468 minecraft:terracotta
fill 472 127 469 472 130 469 minecraft:red_terracotta
setblock 475 127 465 minecraft:terracotta
setblock 476 127 464 minecraft:terracotta
fill 476 127 465 476 130 465 minecraft:red_terracotta
setblock 476 127 504 minecraft:terracotta
fill 477 127 464 477 130 464 minecraft:red_terracotta
setblock 477 127 503 minecraft:terracotta
fill 477 127 504 477 130 504 minecraft:red_terracotta
fill 478 127 503 478 130 503 minecraft:red_terracotta
setblock 480 127 465 minecraft:terracotta
setblock 481 127 464 minecraft:terracotta
setblock 481 127 465 minecraft:red_terracotta
setblock 481 127 504 minecraft:terracotta
setblock 482 127 464 minecraft:red_terracotta
fill 482 127 504 483 127 504 minecraft:red_terracotta
setblock 497 127 464 minecraft:red_terracotta
setblock 501 127 464 minecraft:terracotta
setblock 502 127 464 minecraft:red_terracotta
setblock 510 127 470 minecraft:terracotta
fill 510 127 471 510 129 472 minecraft:red_terracotta
setblock 511 127 464 minecraft:terracotta
fill 511 127 465 511 130 465 minecraft:red_terracotta
setblock 511 127 469 minecraft:terracotta
fill 511 127 470 511 130 470 minecraft:red_terracotta
setblock 511 127 474 minecraft:terracotta
fill 511 127 475 511 130 475 minecraft:red_terracotta
fill 471 128 464 471 131 464 minecraft:red_terracotta
setblock 471 128 468 minecraft:terracotta
fill 471 128 469 471 131 469 minecraft:red_terracotta
setblock 471 128 473 minecraft:terracotta
setblock 472 128 467 minecraft:terracotta
fill 472 128 468 472 131 468 minecraft:red_terracotta
setblock 474 128 465 minecraft:terracotta
setblock 475 128 464 minecraft:terracotta
fill 475 128 465 475 131 465 minecraft:red_terracotta
setblock 475 128 504 minecraft:terracotta
fill 476 128 464 476 131 464 minecraft:red_terracotta
fill 476 128 504 476 131 504 minecraft:red_terracotta
fill 477 128 503 477 131 503 minecraft:red_terracotta
setblock 479 128 465 minecraft:terracotta
setblock 480 128 464 minecraft:terracotta
setblock 480 128 504 minecraft:terracotta
setblock 481 128 464 minecraft:red_terracotta
fill 481 128 504 482 128 504 minecraft:red_terracotta
setblock 500 128 464 minecraft:terracotta
setblock 510 128 469 minecraft:terracotta
fill 510 128 470 510 131 470 minecraft:red_terracotta
setblock 511 128 468 minecraft:terracotta
fill 511 128 469 511 131 469 minecraft:red_terracotta
setblock 511 128 473 minecraft:terracotta
fill 511 128 474 511 131 474 minecraft:red_terracotta
setblock 471 129 467 minecraft:terracotta
fill 471 129 468 471 132 468 minecraft:red_terracotta
setblock 471 129 471 minecraft:red_terracotta
setblock 471 129 472 minecraft:terracotta
fill 471 129 473 471 131 474 minecraft:red_terracotta
setblock 471 129 492 minecraft:terracotta
fill 471 129 493 471 129 496 minecraft:red_terracotta
setblock 472 129 466 minecraft:terracotta
fill 472 129 467 472 132 467 minecraft:red_terracotta
setblock 472 129 471 minecraft:terracotta
fill 472 129 472 472 132 472 minecraft:red_terracotta
setblock 473 129 465 minecraft:terracotta
setblock 474 129 464 minecraft:terracotta
fill 474 129 465 474 132 465 minecraft:red_terracotta
setblock 474 129 504 minecraft:terracotta
fill 475 129 464 475 132 464 minecraft:red_terracotta
fill 475 129 504 475 132 504 minecraft:red_terracotta
fill 476 129 503 476 132 503 minecraft:red_terracotta
setblock 478 129 465 minecraft:terracotta
setblock 479 129 464 minecraft:terracotta
setblock 479 129 504 minecraft:terracotta
fill 480 129 464 480 130 464 minecraft:red_terracotta
fill 480 129 504 481 131 504 minecraft:red_terracotta
setblock 510 129 468 minecraft:terracotta
fill 510 129 469 510 132 469 minecraft:red_terracotta
setblock 510 129 473 minecraft:terracotta
setblock 511 129 467 minecraft:terracotta
fill 511 129 468 511 132 468 minecraft:red_terracotta
setblock 511 129 472 minecraft:terracotta
fill 511 129 473 511 132 473 minecraft:red_terracotta
setblock 511 129 476 minecraft:red_terracotta
setblock 471 130 466 minecraft:terracotta
fill 471 130 467 471 133 467 minecraft:red_terracotta
setblock 471 130 471 minecraft:terracotta
fill 471 130 472 471 133 472 minecraft:red_terracotta
setblock 471 130 475 minecraft:red_terracotta
setblock 471 130 491 minecraft:terracotta
fill 471 130 492 471 130 495 minecraft:red_terracotta
setblock 471 130 496 minecraft:terracotta
fill 471 130 497 471 130 500 minecraft:red_terracotta
fill 472 130 466 472 133 466 minecraft:red_terracotta
setblock 472 130 470 minecraft:terracotta
fill 472 130 471 472 133 471 minecraft:red_terracotta
fill 472 130 473 472 131 473 minecraft:red_terracotta
fill 472 130 493 472 130 494 minecraft:red_terracotta
setblock 472 130 495 minecraft:terracotta
fill 472 130 496 472 132 497 minecraft:red_terracotta
setblock 472 130 504 minecraft:red_terracotta
setblock 473 130 464 minecraft:terracotta
fill 473 130 465 473 133 465 minecraft:red_terracotta
setblock 473 130 504 minecraft:terracotta
fill 474 130 464 474 133 464 minecraft:red_terracotta
fill 474 130 504 474 133 504 minecraft:red_terracotta
fill 475 130 503 475 133 503 minecraft:red_terracotta
setblock 477 130 465 minecraft:terracotta
setblock 478 130 464 minecraft:terracotta
setblock 478 130 504 minecraft:terracotta
fill 479 130 464 479 132 464 minecraft:red_terracotta
setblock 479 130 503 minecraft:terracotta
fill 479 130 504 479 133 504 minecraft:red_terracotta
fill 510 130 468 510 133 468 minecraft:red_terracotta
setblock 510 130 471 minecraft:red_terracotta
setblock 510 130 472 minecraft:terracotta
fill 510 130 473 510 132 474 minecraft:red_terracotta
fill 511 130 464 511 131 464 minecraft:red_terracotta
setblock 511 130 466 minecraft:terracotta
fill 511 130 467 511 133 467 minecraft:red_terracotta
setblock 511 130 471 minecraft:terracotta
fill 511 130 472 511 133 472 minecraft:red_terracotta
setblock 511 130 476 minecraft:terracotta
fill 511 130 477 511 133 477 minecraft:red_terracotta
setblock 471 131 465 minecraft:terracotta
fill 471 131 466 471 134 466 minecraft:red_terracotta
setblock 471 131 470 minecraft:terracotta
fill 471 131 471 471 134 471 minecraft:red_terracotta
setblock 471 131 475 minecraft:terracotta
fill 471 131 476 471 134 476 minecraft:red_terracotta
setblock 471 131 490 minecraft:terracotta
fill 471 131 491 471 131 494 minecraft:red_terracotta
setblock 471 131 495 minecraft:terracotta
fill 471 131 496 471 131 499 minecraft:red_terracotta
setblock 471 131 500 minecraft:terracotta
fill 471 131 501 471 131 504 minecraft:red_terracotta
setblock 472 131 464 minecraft:terracotta
setblock 472 131 469 minecraft:terracotta
fill 472 131 470 472 134 470 minecraft:red_terracotta
setblock 472 131 474 minecraft:terracotta
fill 472 131 492 472 131 493 minecraft:red_terracotta
setblock 472 131 494 minecraft:terracotta
fill 472 131 495 473 133 495 minecraft:red_terracotta
setblock 472 131 498 minecraft:red_terracotta
setblock 472 131 499 minecraft:terracotta
fill 472 131 500 472 133 501 minecraft:red_terracotta
setblock 472 131 504 minecraft:terracotta
fill 473 131 464 473 134 464 minecraft:red_terracotta
fill 473 131 494 473 134 494 minecraft:red_terracotta
fill 473 131 496 473 131 497 minecraft:red_terracotta
setblock 473 131 498 minecraft:terracotta
setblock 473 131 503 minecraft:terracotta
fill 473 131 504 473 134 504 minecraft:red_terracotta
fill 474 131 503 474 134 503 minecraft:red_terracotta
setblock 476 131 465 minecraft:terracotta
setblock 477 131 464 minecraft:terracotta
setblock 477 131 465 minecraft:red_terracotta
setblock 477 131 504 minecraft:terracotta
fill 478 131 464 478 134 464 minecraft:red_terracotta
setblock 478 131 503 minecraft:terracotta
fill 478 131 504 478 134 504 minecraft:red_terracotta
fill 479 131 503 479 134 503 minecraft:red_terracotta
fill 510 131 467 510 134 467 minecraft:red_terracotta
setblock 510 131 471 minecraft:terracotta
fill 510 131 472 510 134 472 minecraft:red_terracotta
setblock 510 131 475 minecraft:red_terracotta
setblock 510 131 476 minecraft:terracotta
setblock 511 131 465 minecraft:terracotta
fill 511 131 466 511 134 466 minecraft:red_terracotta
setblock 511 131 470 minecraft:terracotta
fill 511 131 471 511 134 471 minecraft:red_terracotta
setblock 511 131 475 minecraft:terracotta
fill 511 131 476 511 134 476 minecraft:red_terracotta
fill 511 131 478 511 132 478 minecraft:red_terracotta
fill 511 131 492 511 131 494 minecraft:red_terracotta
setblock 511 131 495 minecraft:terracotta
fill 511 131 496 511 133 497 minecraft:red_terracotta
setblock 471 132 464 minecraft:terracotta
fill 471 132 465 472 134 465 minecraft:red_terracotta
setblock 471 132 469 minecraft:terracotta
fill 471 132 470 471 135 470 minecraft:red_terracotta
setblock 471 132 473 minecraft:red_terracotta
setblock 471 132 474 minecraft:terracotta
fill 471 132 475 472 134 475 minecraft:red_terracotta
fill 471 132 477 471 132 478 minecraft:red_terracotta
fill 471 132 490 471 132 493 minecraft:red_terracotta
setblock 471 132 494 minecraft:terracotta
fill 471 132 495 471 132 498 minecraft:red_terracotta
setblock 471 132 499 minecraft:terracotta
fill 471 132 500 471 132 503 minecraft:red_terracotta
setblock 471 132 504 minecraft:terracotta
fill 472 132 464 472 135 464 minecraft:red_terracotta
setblock 472 132 468 minecraft:terracotta
fill 472 132 469 472 135 469 minecraft:red_terracotta
setblock 472 132 473 minecraft:terracotta
fill 472 132 474 472 135 474 minecraft:red_terracotta
fill 472 132 476 472 133 476 minecraft:red_terracotta
fill 472 132 491 472 132 492 minecraft:red_terracotta
setblock 472 132 493 minecraft:terracotta
fill 472 132 494 472 135 494 minecraft:red_terracotta
setblock 472 132 498 minecraft:terracotta
fill 472 132 499 473 134 499 minecraft:red_terracotta
setblock 472 132 502 minecraft:red_terracotta
setblock 472 132 503 minecraft:terracotta
fill 472 132 504 472 135 504 minecraft:red_terracotta
fill 473 132 470 473 132 471 minecraft:red_terracotta
setblock 473 132 472 minecraft:terracotta
setblock 473 132 492 minecraft:terracotta
fill 473 132 493 473 135 493 minecraft:red_terracotta
setblock 473 132 496 minecraft:red_terracotta
setblock 473 132 497 minecraft:terracotta
fill 473 132 498 473 135 498 minecraft:red_terracotta
fill 473 132 500 473 132 501 minecraft:red_terracotta
fill 473 132 503 473 135 503 minecraft:red_terracotta
setblock 474 132 495 minecraft:red_terracotta
setblock 474 132 496 minecraft:terracotta
fill 474 132 497 474 135 497 minecraft:red_terracotta
fill 474 132 502 477 132 502 minecraft:red_terracotta
setblock 475 132 465 minecraft:terracotta
setblock 476 132 464 minecraft:terracotta
fill 476 132 465 476 133 465 minecraft:red_terracotta
setblock 476 132 504 minecraft:terracotta
fill 477 132 464 477 135 464 minecraft:red_terracotta
setblock 477 132 503 minecraft:terracotta
fill 477 132 504 477 135 504 minecraft:red_terracotta
fill 478 132 503 478 135 503 minecraft:red_terracotta
setblock 480 132 504 minecraft:red_terracotta
setblock 481 132 504 minecraft:terracotta
fill 497 132 464 497 135 464 minecraft:red_terracotta
setblock 509 132 471 minecraft:terracotta
fill 509 132 472 509 134 473 minecraft:red_terracotta
setblock 510 132 464 minecraft:red_terracotta
setblock 510 132 470 minecraft:terracotta
fill 510 132 471 510 135 471 minecraft:red_terracotta
setblock 510 132 475 minecraft:terracotta
fill 510 132 476 510 134 477 minecraft:red_terracotta
setblock 511 132 464 minecraft:terracotta
fill 511 132 465 511 135 465 minecraft:red_terracotta
setblock 511 132 469 minecraft:terracotta
fill 511 132 470 511 135 470 minecraft:red_terracotta
setblock 511 132 474 minecraft:terracotta
fill 511 132 475 511 135 475 minecraft:red_terracotta
setblock 511 132 479 minecraft:terracotta
fill 511 132 480 511 135 480 minecraft:red_terracotta
fill 511 132 491 511 132 493 minecraft:red_terracotta
setblock 511 132 494 minecraft:terracotta
fill 511 132 495 511 135 495 minecraft:red_terracotta
setblock 511 132 498 minecraft:red_terracotta
setblock 511 132 499 minecraft:terracotta
fill 511 132 500 511 135 500 minecraft:red_terracotta
fill 471 133 464 471 136 464 minecraft:red_terracotta
setblock 471 133 468 minecraft:terracotta
fill 471 133 469 471 136 469 minecraft:red_terracotta
setblock 471 133 473 minecraft:terracotta
fill 471 133 474 471 136 474 minecraft:red_terracotta
setblock 471 133 477 minecraft:red_terracotta
setblock 471 133 478 minecraft:terracotta
fill 471 133 479 471 136 479 minecraft:red_terracotta
fill 471 133 489 471 133 492 minecraft:red_terracotta
setblock 471 133 493 minecraft:terracotta
fill 471 133 494 471 133 497 minecraft:red_terracotta
setblock 471 133 498 minecraft:terracotta
fill 471 133 499 471 133 502 minecraft:red_terracotta
setblock 471 133 503 minecraft:terracotta
fill 471 133 504 471 136 504 minecraft:red_terracotta
setblock 472 133 467 minecraft:terracotta
fill 472 133 468 472 136 468 minecraft:red_terracotta
setblock 472 133 472 minecraft:terracotta
fill 472 133 473 473 135 473 minecraft:red_terracotta
setblock 472 133 477 minecraft:terracotta
fill 472 133 490 472 133 491 minecraft:red_terracotta
setblock 472 133 492 minecraft:terracotta
fill 472 133 493 472 136 493 minecraft:red_terracotta
setblock 472 133 496 minecraft:red_terracotta
setblock 472 133 497 minecraft:terracotta
fill 472 133 498 472 136 498 minecraft:red_terracotta
setblock 472 133 502 minecraft:terracotta
fill 472 133 503 472 136 503 minecraft:red_terracotta
setblock 473 133 470 minecraft:red_terracotta
setblock 473 133 471 minecraft:terracotta
fill 473 133 472 473 135 472 minecraft:red_terracotta
fill 473 133 474 473 134 474 minecraft:red_terracotta
fill 473 133 492 473 136 492 minecraft:red_terracotta
setblock 473 133 496 minecraft:terracotta
fill 473 133 497 473 136 497 minecraft:red_terracotta
setblock 473 133 500 minecraft:red_terracotta
setblock 473 133 501 minecraft:terracotta
fill 473 133 502 476 133 502 minecraft:red_terracotta
setblock 474 133 465 minecraft:terracotta
setblock 474 133 494 minecraft:red_terracotta
setblock 474 133 495 minecraft:terracotta
fill 474 133 496 474 136 496 minecraft:red_terracotta
fill 474 133 498 474 133 499 minecraft:red_terracotta
setblock 474 133 500 minecraft:terracotta
setblock 475 133 464 minecraft:terracotta
fill 475 133 465 475 135 465 minecraft:red_terracotta
setblock 475 133 504 minecraft:terracotta
fill 476 133 464 476 136 464 minecraft:red_terracotta
setblock 476 133 503 minecraft:terracotta
fill 476 133 504 476 136 504 minecraft:red_terracotta
setblock 477 133 502 minecraft:terracotta
fill 477 133 503 477 136 503 minecraft:red_terracotta
fill 478 133 502 478 136 502 minecraft:red_terracotta
setblock 480 133 503 minecraft:red_terracotta
setblock 480 133 504 minecraft:terracotta
fill 481 133 504 481 136 504 minecraft:red_terracotta
setblock 494 133 504 minecraft:red_terracotta
setblock 495 133 464 minecraft:terracotta
setblock 495 133 504 minecraft:terracotta
fill 496 133 464 496 136 464 minecraft:red_terracotta
fill 498 133 464 498 134 464 minecraft:red_terracotta
setblock 509 133 464 minecraft:red_terracotta
setblock 509 133 470 minecraft:terracotta
fill 509 133 471 509 136 471 minecraft:red_terracotta
setblock 509 133 474 minecraft:red_terracotta
setblock 509 133 475 minecraft:terracotta
setblock 510 133 464 minecraft:terracotta
fill 510 133 466 510 135 466 minecraft:red_terracotta
setblock 510 133 469 minecraft:terracotta
fill 510 133 470 510 136 470 minecraft:red_terracotta
setblock 510 133 473 minecraft:red_terracotta
setblock 510 133 474 minecraft:terracotta
fill 510 133 475 510 136 475 minecraft:red_terracotta
setblock 510 133 478 minecraft:red_terracotta
fill 511 133 464 511 136 464 minecraft:red_terracotta
setblock 511 133 468 minecraft:terracotta
fill 511 133 469 511 136 469 minecraft:red_terracotta
setblock 511 133 473 minecraft:terracotta
fill 511 133 474 511 136 474 minecraft:red_terracotta
setblock 511 133 478 minecraft:terracotta
fill 511 133 479 511 136 479 minecraft:red_terracotta
fill 511 133 481 511 134 481 minecraft:red_terracotta
fill 511 133 491 511 133 492 minecraft:red_terracotta
setblock 511 133 493 minecraft:terracotta
fill 511 133 494 511 136 494 minecraft:red_terracotta
setblock 511 133 498 minecraft:terracotta
fill 511 133 499 511 136 499 minecraft:red_terracotta
fill 511 133 501 511 133 502 minecraft:red_terracotta
setblock 511 133 503 minecraft:terracotta
fill 511 133 504 511 136 504 minecraft:red_terracotta
setblock 471 134 467 minecraft:terracotta
fill 471 134 468 471 137 468 minecraft:red_terracotta
setblock 471 134 472 minecraft:terracotta
fill 471 134 473 471 137 473 minecraft:red_terracotta
setblock 471 134 477 minecraft:terracotta
fill 471 134 478 472 136 478 minecraft:red_terracotta
fill 471 134 480 471 134 481 minecraft:red_terracotta
fill 471 134 488 471 134 491 minecraft:red_terracotta
setblock 471 134 492 minecraft:terracotta
fill 471 134 493 471 134 496 minecraft:red_terracotta
setblock 471 134 497 minecraft:terracotta
fill 471 134 498 471 134 501 minecraft:red_terracotta
setblock 471 134 502 minecraft:terracotta
fill 471 134 503 471 137 503 minecraft:red_terracotta
setblock 472 134 466 minecraft:terracotta
fill 472 134 467 472 137 467 minecraft:red_terracotta
setblock 472 134 471 minecraft:terracotta
fill 472 134 472 472 137 472 minecraft:red_terracotta
setblock 472 134 476 minecraft:terracotta
fill 472 134 477 472 137 477 minecraft:red_terracotta
fill 472 134 479 472 135 479 minecraft:red_terracotta
setblock 472 134 490 minecraft:red_terracotta
setblock 472 134 491 minecraft:terracotta
fill 472 134 492 472 137 492 minecraft:red_terracotta
setblock 472 134 495 minecraft:red_terracotta
setblock 472 134 496 minecraft:terracotta
fill 472 134 497 472 137 497 minecraft:red_terracotta
setblock 472 134 500 minecraft:red_terracotta
setblock 472 134 501 minecraft:terracotta
fill 472 134 502 475 134 502 minecraft:red_terracotta
setblock 473 134 465 minecraft:terracotta
setblock 473 134 466 minecraft:light[level=14]
setblock 473 134 470 minecraft:terracotta
fill 473 134 471 473 135 471 minecraft:red_terracotta
setblock 473 134 475 minecraft:terracotta
fill 473 134 476 473 137 476 minecraft:red_terracotta
setblock 473 134 482 minecraft:light[level=14]
setblock 473 134 490 minecraft:light[level=14]
fill 473 134 491 473 135 491 minecraft:red_terracotta
setblock 473 134 495 minecraft:terracotta
fill 473 134 496 473 137 496 minecraft:red_terracotta
setblock 473 134 500 minecraft:terracotta
fill 473 134 501 476 134 501 minecraft:red_terracotta
setblock 474 134 464 minecraft:terracotta
fill 474 134 465 474 136 465 minecraft:red_terracotta
setblock 474 134 493 minecraft:red_terracotta
setblock 474 134 494 minecraft:terracotta
fill 474 134 495 474 137 495 minecraft:red_terracotta
setblock 474 134 498 minecraft:red_terracotta
setblock 474 134 499 minecraft:terracotta
fill 474 134 500 474 137 500 minecraft:red_terracotta
setblock 474 134 504 minecraft:terracotta
fill 475 134 464 475 137 464 minecraft:red_terracotta
fill 475 134 496 475 134 497 minecraft:red_terracotta
setblock 475 134 498 minecraft:terracotta
setblock 475 134 503 minecraft:terracotta
fill 475 134 504 475 137 504 minecraft:red_terracotta
setblock 476 134 502 minecraft:terracotta
fill 476 134 503 476 137 503 minecraft:red_terracotta
setblock 477 134 501 minecraft:terracotta
fill 477 134 502 477 137 502 minecraft:red_terracotta
fill 479 134 502 479 135 502 minecraft:red_terracotta
setblock 479 134 504 minecraft:terracotta
setblock 480 134 503 minecraft:terracotta
fill 480 134 504 480 137 504 minecraft:red_terracotta
setblock 481 134 466 minecraft:light[level=14]
setblock 481 134 474 minecraft:light[level=14]
setblock 481 134 482 minecraft:light[level=14]
setblock 481 134 490 minecraft:light[level=14]
setblock 481 134 498 minecraft:light[level=14]
setblock 489 134 466 minecraft:light[level=14]
setblock 489 134 474 minecraft:light[level=14]
setblock 489 134 482 minecraft:light[level=14]
setblock 489 134 490 minecraft:light[level=14]
setblock 489 134 498 minecraft:light[level=14]
fill 491 134 504 493 134 504 minecraft:red_terracotta
setblock 494 134 464 minecraft:terracotta
setblock 494 134 504 minecraft:terracotta
fill 495 134 464 495 137 464 minecraft:red_terracotta
fill 495 134 504 497 135 504 minecraft:red_terracotta
setblock 497 134 466 minecraft:light[level=14]
setblock 497 134 474 minecraft:light[level=14]
setblock 497 134 482 minecraft:light[level=14]
setblock 497 134 490 minecraft:light[level=14]
setblock 497 134 498 minecraft:light[level=14]
setblock 505 134 466 minecraft:light[level=14]
setblock 505 134 474 minecraft:light[level=14]
setblock 505 134 482 minecraft:light[level=14]
setblock 505 134 490 minecraft:light[level=14]
setblock 508 134 464 minecraft:red_terracotta
setblock 509 134 464 minecraft:terracotta
fill 509 134 470 509 136 470 minecraft:red_terracotta
setblock 509 134 474 minecraft:terracotta
fill 509 134 475 509 136 476 minecraft:red_terracotta
fill 510 134 464 510 136 465 minecraft:red_terracotta
setblock 510 134 468 minecraft:terracotta
fill 510 134 469 510 137 469 minecraft:red_terracotta
setblock 510 134 473 minecraft:terracotta
fill 510 134 474 510 137 474 minecraft:red_terracotta
setblock 510 134 478 minecraft:terracotta
fill 510 134 479 510 137 479 minecraft:red_terracotta
fill 510 134 495 510 134 497 minecraft:red_terracotta
setblock 510 134 498 minecraft:terracotta
fill 510 134 499 510 136 500 minecraft:red_terracotta
fill 510 134 504 510 137 504 minecraft:red_terracotta
setblock 511 134 467 minecraft:terracotta
fill 511 134 468 511 137 468 minecraft:red_terracotta
setblock 511 134 472 minecraft:terracotta
fill 511 134 473 511 137 473 minecraft:red_terracotta
setblock 511 134 477 minecraft:terracotta
fill 511 134 478 511 137 478 minecraft:red_terracotta
setblock 511 134 482 minecraft:terracotta
fill 511 134 490 511 134 491 minecraft:red_terracotta
setblock 511 134 492 minecraft:terracotta
fill 511 134 493 511 137 493 minecraft:red_terracotta
setblock 511 134 496 minecraft:red_terracotta
setblock 511 134 497 minecraft:terracotta
fill 511 134 498 511 137 498 minecraft:red_terracotta
setblock 511 134 501 minecraft:red_terracotta
setblock 511 134 502 minecraft:terracotta
fill 511 134 503 511 137 503 minecraft:red_terracotta
setblock 471 135 465 minecraft:red_terracotta
setblock 471 135 466 minecraft:terracotta
fill 471 135 467 471 138 467 minecraft:red_terracotta
setblock 471 135 471 minecraft:terracotta
fill 471 135 472 471 138 472 minecraft:red_terracotta
setblock 471 135 475 minecraft:red_terracotta
setblock 471 135 476 minecraft:terracotta
fill 471 135 477 471 138 477 minecraft:red_terracotta
setblock 471 135 480 minecraft:red_terracotta
setblock 471 135 481 minecraft:terracotta
fill 471 135 482 471 137 483 minecraft:red_terracotta
fill 471 135 488 471 135 490 minecraft:red_terracotta
setblock 471 135 491 minecraft:terracotta
fill 471 135 492 471 135 495 minecraft:red_terracotta
setblock 471 135 496 minecraft:terracotta
fill 471 135 497 471 135 500 minecraft:red_terracotta
setblock 471 135 501 minecraft:terracotta
fill 471 135 502 474 135 502 minecraft:red_terracotta
setblock 472 135 465 minecraft:terracotta
fill 472 135 466 472 137 466 minecraft:red_terracotta
setblock 472 135 470 minecraft:terracotta
fill 472 135 471 472 137 471 minecraft:red_terracotta
setblock 472 135 475 minecraft:terracotta
fill 472 135 476 472 138 476 minecraft:red_terracotta
setblock 472 135 480 minecraft:terracotta
setblock 472 135 490 minecraft:terracotta
fill 472 135 491 472 138 491 minecraft:red_terracotta
setblock 472 135 495 minecraft:terracotta
fill 472 135 496 472 138 496 minecraft:red_terracotta
setblock 472 135 499 minecraft:red_terracotta
setblock 472 135 500 minecraft:terracotta
fill 472 135 501 475 135 501 minecraft:red_terracotta
setblock 473 135 464 minecraft:terracotta
fill 473 135 465 473 137 465 minecraft:red_terracotta
setblock 473 135 474 minecraft:terracotta
fill 473 135 475 473 137 475 minecraft:red_terracotta
fill 473 135 477 473 136 477 minecraft:red_terracotta
setblock 473 135 494 minecraft:terracotta
fill 473 135 495 473 138 495 minecraft:red_terracotta
setblock 473 135 499 minecraft:terracotta
fill 473 135 500 473 138 500 minecraft:red_terracotta
setblock 473 135 504 minecraft:terracotta
fill 474 135 464 474 138 464 minecraft:red_terracotta
setblock 474 135 493 minecraft:terracotta
fill 474 135 494 474 137 494 minecraft:red_terracotta
setblock 474 135 498 minecraft:terracotta
fill 474 135 499 475 137 499 minecraft:red_terracotta
setblock 474 135 503 minecraft:terracotta
fill 474 135 504 474 138 504 minecraft:red_terracotta
setblock 475 135 496 minecraft:red_terracotta
setblock 475 135 497 minecraft:terracotta
fill 475 135 498 475 137 498 minecraft:red_terracotta
setblock 475 135 502 minecraft:terracotta
fill 475 135 503 475 138 503 minecraft:red_terracotta
setblock 476 135 501 minecraft:terracotta
fill 476 135 502 476 138 502 minecraft:red_terracotta
fill 477 135 501 477 137 501 minecraft:red_terracotta
setblock 478 135 464 minecraft:terracotta
setblock 478 135 504 minecraft:terracotta
setblock 479 135 503 minecraft:terracotta
fill 479 135 504 479 138 504 minecraft:red_terracotta
fill 480 135 503 480 137 503 minecraft:red_terracotta
setblock 482 135 504 minecraft:red_terracotta
fill 490 135 504 492 135 504 minecraft:red_terracotta
setblock 493 135 464 minecraft:terracotta
setblock 493 135 503 minecraft:red_terracotta
setblock 493 135 504 minecraft:terracotta
fill 494 135 464 494 138 464 minecraft:red_terracotta
setblock 494 135 503 minecraft:terracotta
fill 494 135 504 494 138 504 minecraft:red_terracotta
setblock 498 135 464 minecraft:terracotta
setblock 507 135 464 minecraft:red_terracotta
setblock 508 135 464 minecraft:terracotta
setblock 508 135 504 minecraft:terracotta
fill 509 135 464 509 137 465 minecraft:red_terracotta
setblock 509 135 472 minecraft:red_terracotta
setblock 509 135 473 minecraft:terracotta
fill 509 135 474 509 138 474 minecraft:red_terracotta
setblock 509 135 477 minecraft:red_terracotta
fill 509 135 504 509 138 504 minecraft:red_terracotta
setblock 510 135 467 minecraft:terracotta
fill 510 135 468 510 138 468 minecraft:red_terracotta
setblock 510 135 472 minecraft:terracotta
fill 510 135 473 510 138 473 minecraft:red_terracotta
setblock 510 135 476 minecraft:red_terracotta
setblock 510 135 477 minecraft:terracotta
fill 510 135 478 510 138 478 minecraft:red_terracotta
fill 510 135 480 510 136 480 minecraft:red_terracotta
fill 510 135 494 510 135 496 minecraft:red_terracotta
setblock 510 135 497 minecraft:terracotta
fill 510 135 498 510 138 498 minecraft:red_terracotta
setblock 510 135 501 minecraft:red_terracotta
setblock 510 135 502 minecraft:terracotta
fill 510 135 503 510 138 503 minecraft:red_terracotta
setblock 511 135 466 minecraft:terracotta
fill 511 135 467 511 138 467 minecraft:red_terracotta
setblock 511 135 471 minecraft:terracotta
fill 511 135 472 511 138 472 minecraft:red_terracotta
setblock 511 135 476 minecraft:terracotta
fill 511 135 477 511 138 477 minecraft:red_terracotta
setblock 511 135 481 minecraft:terracotta
fill 511 135 482 511 137 483 minecraft:red_terracotta
setblock 511 135 490 minecraft:red_terracotta
setblock 511 135 491 minecraft:terracotta
fill 511 135 492 511 138 492 minecraft:red_terracotta
setblock 511 135 496 minecraft:terracotta
fill 511 135 497 511 138 497 minecraft:red_terracotta
setblock 511 135 501 minecraft:terracotta
fill 511 135 502 511 138 502 minecraft:red_terracotta
setblock 471 136 465 minecraft:terracotta
fill 471 136 466 471 139 466 minecraft:red_terracotta
setblock 471 136 470 minecraft:terracotta
fill 471 136 471 471 139 471 minecraft:red_terracotta
setblock 471 136 475 minecraft:terracotta
fill 471 136 476 471 139 476 minecraft:red_terracotta
setblock 471 136 480 minecraft:terracotta
fill 471 136 481 472 138 481 minecraft:red_terracotta
setblock 471 136 484 minecraft:red_terracotta
setblock 471 136 485 minecraft:terracotta
fill 471 136 486 471 136 489 minecraft:red_terracotta
setblock 471 136 490 minecraft:terracotta
fill 471 136 491 471 136 494 minecraft:red_terracotta
setblock 471 136 495 minecraft:terracotta
fill 471 136 496 471 136 499 minecraft:red_terracotta
setblock 471 136 500 minecraft:terracotta
fill 471 136 501 473 136 502 minecraft:red_terracotta
setblock 472 136 464 minecraft:terracotta
fill 472 136 465 472 138 465 minecraft:red_terracotta
setblock 472 136 469 minecraft:terracotta
fill 472 136 470 472 137 470 minecraft:red_terracotta
setblock 472 136 473 minecraft:red_terracotta
setblock 472 136 474 minecraft:terracotta
fill 472 136 475 472 139 475 minecraft:red_terracotta
setblock 472 136 479 minecraft:terracotta
fill 472 136 480 472 139 480 minecraft:red_terracotta
fill 472 136 490 472 137 490 minecraft:red_terracotta
setblock 472 136 494 minecraft:terracotta
fill 472 136 495 472 139 495 minecraft:red_terracotta
setblock 472 136 499 minecraft:terracotta
fill 472 136 500 472 139 500 minecraft:red_terracotta
setblock 472 136 504 minecraft:terracotta
fill 473 136 464 473 139 464 minecraft:red_terracotta
setblock 473 136 473 minecraft:terracotta
setblock 473 136 474 minecraft:red_terracotta
setblock 473 136 478 minecraft:terracotta
setblock 473 136 493 minecraft:terracotta
fill 473 136 494 473 139 494 minecraft:red_terracotta
setblock 473 136 498 minecraft:terracotta
fill 473 136 499 473 139 499 minecraft:red_terracotta
setblock 473 136 503 minecraft:terracotta
fill 473 136 504 473 139 504 minecraft:red_terracotta
setblock 474 136 497 minecraft:terracotta
fill 474 136 498 474 139 498 minecraft:red_terracotta
setblock 474 136 501 minecraft:red_terracotta
setblock 474 136 502 minecraft:terracotta
fill 474 136 503 474 139 503 minecraft:red_terracotta
setblock 475 136 497 minecraft:red_terracotta
setblock 475 136 500 minecraft:red_terracotta
setblock 475 136 501 minecraft:terracotta
fill 475 136 502 475 139 502 minecraft:red_terracotta
fill 476 136 501 476 138 501 minecraft:red_terracotta
setblock 477 136 464 minecraft:terracotta
setblock 477 136 504 minecraft:terracotta
setblock 478 136 503 minecraft:terracotta
fill 478 136 504 478 139 504 minecraft:red_terracotta
setblock 479 136 502 minecraft:terracotta
fill 479 136 503 479 139 503 minecraft:red_terracotta
setblock 482 136 504 minecraft:terracotta
fill 488 136 504 491 136 504 minecraft:red_terracotta
fill 491 136 503 492 136 503 minecraft:red_terracotta
setblock 492 136 464 minecraft:terracotta
setblock 492 136 504 minecraft:terracotta
fill 493 136 464 493 139 464 minecraft:red_terracotta
setblock 493 136 503 minecraft:terracotta
fill 493 136 504 493 139 504 minecraft:red_terracotta
fill 494 136 503 495 137 503 minecraft:red_terracotta
fill 495 136 504 496 136 504 minecraft:red_terracotta
setblock 497 136 464 minecraft:terracotta
setblock 497 136 504 minecraft:terracotta
fill 498 136 464 498 137 464 minecraft:red_terracotta
setblock 506 136 464 minecraft:red_terracotta
setblock 507 136 464 minecraft:terracotta
setblock 507 136 504 minecraft:terracotta
fill 508 136 464 508 139 464 minecraft:red_terracotta
fill 508 136 504 508 139 504 minecraft:red_terracotta
setblock 509 136 472 minecraft:terracotta
fill 509 136 473 509 138 473 minecraft:red_terracotta
setblock 509 136 477 minecraft:terracotta
fill 509 136 478 509 139 478 minecraft:red_terracotta
fill 509 136 503 509 139 503 minecraft:red_terracotta
setblock 510 136 466 minecraft:terracotta
fill 510 136 467 510 139 467 minecraft:red_terracotta
setblock 510 136 471 minecraft:terracotta
fill 510 136 472 510 139 472 minecraft:red_terracotta
setblock 510 136 476 minecraft:terracotta
fill 510 136 477 510 139 477 minecraft:red_terracotta
setblock 510 136 481 minecraft:terracotta
fill 510 136 494 510 136 495 minecraft:red_terracotta
setblock 510 136 496 minecraft:terracotta
fill 510 136 497 510 139 497 minecraft:red_terracotta
setblock 510 136 501 minecraft:terracotta
fill 510 136 502 510 139 502 minecraft:red_terracotta
setblock 511 136 465 minecraft:terracotta
fill 511 136 466 511 139 466 minecraft:red_terracotta
setblock 511 136 470 minecraft:terracotta
fill 511 136 471 511 139 471 minecraft:red_terracotta
setblock 511 136 475 minecraft:terracotta
fill 511 136 476 511 139 476 minecraft:red_terracotta
setblock 511 136 480 minecraft:terracotta
fill 511 136 481 511 139 481 minecraft:red_terracotta
setblock 511 136 484 minecraft:red_terracotta
setblock 511 136 490 minecraft:terracotta
fill 511 136 491 511 138 491 minecraft:red_terracotta
setblock 511 136 495 minecraft:terracotta
fill 511 136 496 511 139 496 minecraft:red_terracotta
setblock 511 136 500 minecraft:terracotta
fill 511 136 501 511 139 501 minecraft:red_terracotta
setblock 471 137 464 minecraft:terracotta
fill 471 137 465 471 140 465 minecraft:red_terracotta
setblock 471 137 469 minecraft:terracotta
fill 471 137 470 471 139 470 minecraft:red_terracotta
setblock 471 137 474 minecraft:terracotta
fill 471 137 475 471 140 475 minecraft:red_terracotta
setblock 471 137 478 minecraft:red_terracotta
setblock 471 137 479 minecraft:terracotta
fill 471 137 480 471 140 480 minecraft:red_terracotta
setblock 471 137 484 minecraft:terracotta
fill 471 137 485 471 137 488 minecraft:red_terracotta
setblock 471 137 489 minecraft:terracotta
fill 471 137 490 471 137 493 minecraft:red_terracotta
setblock 471 137 494 minecraft:terracotta
fill 471 137 495 471 137 498 minecraft:red_terracotta
setblock 471 137 499 minecraft:terracotta
fill 471 137 500 471 138 502 minecraft:red_terracotta
setblock 471 137 504 minecraft:terracotta
fill 472 137 464 472 140 464 minecraft:red_terracotta
setblock 472 137 468 minecraft:terracotta
setblock 472 137 469 minecraft:red_terracotta
setblock 472 137 473 minecraft:terracotta
fill 472 137 474 472 139 474 minecraft:red_terracotta
setblock 472 137 478 minecraft:terracotta
fill 472 137 479 472 140 479 minecraft:red_terracotta
setblock 472 137 482 minecraft:red_terracotta
schedule function dropper:buildpart/118_5 1t
