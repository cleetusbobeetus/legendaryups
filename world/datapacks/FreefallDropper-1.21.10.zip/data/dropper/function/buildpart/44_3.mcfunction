setblock 412 21 183 minecraft:stone_bricks
setblock 413 21 182 minecraft:stone_bricks
setblock 413 21 222 minecraft:stone_bricks
fill 414 21 182 414 24 182 minecraft:mossy_cobblestone
fill 414 21 202 414 23 203 minecraft:mossy_cobblestone
setblock 414 21 221 minecraft:stone_bricks
fill 414 21 222 414 24 222 minecraft:mossy_cobblestone
setblock 415 21 200 minecraft:stone_bricks
fill 415 21 201 415 24 201 minecraft:mossy_cobblestone
setblock 415 21 205 minecraft:stone_bricks
fill 415 21 206 415 24 206 minecraft:mossy_cobblestone
setblock 415 21 221 minecraft:mossy_cobblestone
setblock 416 21 199 minecraft:stone_bricks
fill 416 21 200 416 24 200 minecraft:mossy_cobblestone
setblock 416 21 204 minecraft:stone_bricks
fill 416 21 205 416 24 205 minecraft:mossy_cobblestone
setblock 416 21 208 minecraft:mossy_cobblestone
setblock 417 21 198 minecraft:stone_bricks
fill 417 21 199 417 24 199 minecraft:mossy_cobblestone
setblock 417 21 203 minecraft:stone_bricks
fill 417 21 204 417 24 204 minecraft:mossy_cobblestone
setblock 417 21 208 minecraft:stone_bricks
fill 417 21 209 417 23 210 minecraft:mossy_cobblestone
setblock 417 21 219 minecraft:mossy_cobblestone
setblock 377 22 182 minecraft:stone_bricks
fill 377 22 183 380 22 183 minecraft:mossy_cobblestone
setblock 377 22 187 minecraft:stone_bricks
fill 377 22 188 377 24 189 minecraft:mossy_cobblestone
setblock 377 22 192 minecraft:stone_bricks
fill 377 22 193 377 24 193 minecraft:mossy_cobblestone
setblock 377 22 197 minecraft:stone_bricks
fill 377 22 198 377 25 198 minecraft:mossy_cobblestone
setblock 377 22 202 minecraft:stone_bricks
fill 377 22 203 377 25 203 minecraft:mossy_cobblestone
setblock 377 22 207 minecraft:stone_bricks
fill 378 22 182 378 25 182 minecraft:mossy_cobblestone
setblock 378 22 197 minecraft:mossy_cobblestone
setblock 378 22 201 minecraft:stone_bricks
fill 378 22 202 378 25 202 minecraft:mossy_cobblestone
fill 379 22 222 379 24 222 minecraft:mossy_cobblestone
setblock 381 22 182 minecraft:mossy_cobblestone
setblock 381 22 183 minecraft:stone_bricks
setblock 382 22 182 minecraft:stone_bricks
fill 382 22 183 382 25 183 minecraft:mossy_cobblestone
setblock 382 22 222 minecraft:stone_bricks
fill 383 22 182 383 25 182 minecraft:mossy_cobblestone
fill 383 22 184 384 22 184 minecraft:mossy_cobblestone
setblock 383 22 221 minecraft:stone_bricks
fill 383 22 222 383 25 222 minecraft:mossy_cobblestone
fill 384 22 221 384 25 221 minecraft:mossy_cobblestone
setblock 385 22 184 minecraft:stone_bricks
setblock 386 22 183 minecraft:stone_bricks
fill 386 22 184 386 24 185 minecraft:mossy_cobblestone
setblock 387 22 182 minecraft:stone_bricks
fill 387 22 183 387 25 183 minecraft:mossy_cobblestone
fill 387 22 185 388 22 185 minecraft:mossy_cobblestone
setblock 387 22 222 minecraft:stone_bricks
fill 388 22 182 388 25 182 minecraft:mossy_cobblestone
setblock 388 22 221 minecraft:stone_bricks
fill 388 22 222 388 25 222 minecraft:mossy_cobblestone
setblock 389 22 185 minecraft:stone_bricks
setblock 389 22 220 minecraft:stone_bricks
fill 389 22 221 389 25 221 minecraft:mossy_cobblestone
setblock 390 22 184 minecraft:stone_bricks
fill 390 22 185 391 24 185 minecraft:mossy_cobblestone
fill 390 22 220 390 25 220 minecraft:mossy_cobblestone
setblock 391 22 183 minecraft:stone_bricks
fill 391 22 184 391 25 184 minecraft:mossy_cobblestone
setblock 392 22 182 minecraft:stone_bricks
fill 392 22 183 392 25 183 minecraft:mossy_cobblestone
setblock 392 22 222 minecraft:stone_bricks
fill 393 22 182 393 25 182 minecraft:mossy_cobblestone
setblock 393 22 221 minecraft:stone_bricks
fill 393 22 222 393 25 222 minecraft:mossy_cobblestone
setblock 394 22 220 minecraft:stone_bricks
fill 394 22 221 397 22 221 minecraft:mossy_cobblestone
setblock 396 22 183 minecraft:stone_bricks
setblock 397 22 182 minecraft:stone_bricks
fill 397 22 183 397 25 183 minecraft:mossy_cobblestone
setblock 397 22 222 minecraft:stone_bricks
fill 398 22 182 401 22 182 minecraft:mossy_cobblestone
setblock 398 22 221 minecraft:stone_bricks
fill 398 22 222 398 25 222 minecraft:mossy_cobblestone
fill 399 22 183 399 23 183 minecraft:mossy_cobblestone
fill 399 22 221 399 25 221 minecraft:mossy_cobblestone
setblock 402 22 182 minecraft:stone_bricks
fill 402 22 183 403 24 183 minecraft:mossy_cobblestone
setblock 402 22 222 minecraft:stone_bricks
fill 403 22 182 403 25 182 minecraft:mossy_cobblestone
setblock 403 22 221 minecraft:stone_bricks
fill 403 22 222 403 25 222 minecraft:mossy_cobblestone
setblock 404 22 220 minecraft:stone_bricks
fill 404 22 221 404 25 221 minecraft:mossy_cobblestone
setblock 405 22 183 minecraft:mossy_cobblestone
fill 405 22 220 405 25 220 minecraft:mossy_cobblestone
setblock 406 22 183 minecraft:stone_bricks
setblock 407 22 182 minecraft:stone_bricks
fill 407 22 183 407 25 183 minecraft:mossy_cobblestone
setblock 407 22 222 minecraft:stone_bricks
fill 408 22 182 408 25 182 minecraft:mossy_cobblestone
setblock 408 22 221 minecraft:stone_bricks
fill 408 22 222 408 25 222 minecraft:mossy_cobblestone
fill 409 22 183 410 22 183 minecraft:mossy_cobblestone
setblock 409 22 220 minecraft:stone_bricks
fill 409 22 221 409 25 221 minecraft:mossy_cobblestone
fill 410 22 220 410 24 220 minecraft:mossy_cobblestone
setblock 411 22 183 minecraft:stone_bricks
setblock 412 22 182 minecraft:stone_bricks
fill 412 22 183 413 24 183 minecraft:mossy_cobblestone
setblock 412 22 222 minecraft:stone_bricks
fill 413 22 182 413 25 182 minecraft:mossy_cobblestone
setblock 413 22 221 minecraft:stone_bricks
fill 413 22 222 413 25 222 minecraft:mossy_cobblestone
setblock 414 22 204 minecraft:mossy_cobblestone
fill 414 22 221 414 23 221 minecraft:mossy_cobblestone
setblock 415 22 199 minecraft:stone_bricks
fill 415 22 200 415 23 200 minecraft:mossy_cobblestone
setblock 415 22 203 minecraft:mossy_cobblestone
setblock 415 22 204 minecraft:stone_bricks
fill 415 22 205 415 25 205 minecraft:mossy_cobblestone
fill 415 22 207 415 23 207 minecraft:mossy_cobblestone
setblock 416 22 198 minecraft:stone_bricks
fill 416 22 199 416 25 199 minecraft:mossy_cobblestone
setblock 416 22 203 minecraft:stone_bricks
fill 416 22 204 416 25 204 minecraft:mossy_cobblestone
setblock 416 22 208 minecraft:stone_bricks
setblock 417 22 182 minecraft:stone_bricks
fill 417 22 183 417 25 183 minecraft:mossy_cobblestone
setblock 417 22 197 minecraft:stone_bricks
fill 417 22 198 417 25 198 minecraft:mossy_cobblestone
setblock 417 22 202 minecraft:stone_bricks
fill 417 22 203 417 25 203 minecraft:mossy_cobblestone
setblock 417 22 207 minecraft:stone_bricks
fill 417 22 208 417 25 208 minecraft:mossy_cobblestone
setblock 417 22 222 minecraft:stone_bricks
fill 377 23 182 377 23 185 minecraft:mossy_cobblestone
setblock 377 23 186 minecraft:stone_bricks
fill 377 23 187 377 26 187 minecraft:mossy_cobblestone
setblock 377 23 190 minecraft:mossy_cobblestone
setblock 377 23 191 minecraft:stone_bricks
fill 377 23 192 377 26 192 minecraft:mossy_cobblestone
setblock 377 23 196 minecraft:stone_bricks
fill 377 23 197 377 25 197 minecraft:mossy_cobblestone
setblock 377 23 201 minecraft:stone_bricks
fill 377 23 202 377 26 202 minecraft:mossy_cobblestone
setblock 377 23 206 minecraft:stone_bricks
fill 377 23 207 377 26 207 minecraft:mossy_cobblestone
fill 378 23 183 378 23 184 minecraft:mossy_cobblestone
setblock 378 23 185 minecraft:stone_bricks
setblock 378 23 200 minecraft:stone_bricks
fill 378 23 201 378 24 201 minecraft:mossy_cobblestone
setblock 379 23 183 minecraft:mossy_cobblestone
setblock 380 23 183 minecraft:stone_bricks
setblock 380 23 222 minecraft:mossy_cobblestone
setblock 381 23 182 minecraft:stone_bricks
fill 381 23 183 381 25 184 minecraft:mossy_cobblestone
setblock 381 23 222 minecraft:stone_bricks
fill 382 23 182 382 26 182 minecraft:mossy_cobblestone
fill 382 23 184 383 23 184 minecraft:mossy_cobblestone
fill 382 23 222 382 26 222 minecraft:mossy_cobblestone
fill 383 23 221 383 26 221 minecraft:mossy_cobblestone
setblock 384 23 184 minecraft:stone_bricks
fill 384 23 185 385 25 185 minecraft:mossy_cobblestone
setblock 385 23 183 minecraft:stone_bricks
fill 385 23 184 385 26 184 minecraft:mossy_cobblestone
setblock 386 23 182 minecraft:stone_bricks
fill 386 23 183 386 26 183 minecraft:mossy_cobblestone
fill 386 23 220 386 24 220 minecraft:mossy_cobblestone
setblock 386 23 222 minecraft:stone_bricks
fill 387 23 182 387 26 182 minecraft:mossy_cobblestone
setblock 387 23 185 minecraft:mossy_cobblestone
setblock 387 23 221 minecraft:stone_bricks
fill 387 23 222 387 26 222 minecraft:mossy_cobblestone
setblock 388 23 185 minecraft:stone_bricks
setblock 388 23 220 minecraft:stone_bricks
fill 388 23 221 388 26 221 minecraft:mossy_cobblestone
setblock 389 23 184 minecraft:stone_bricks
fill 389 23 185 389 26 185 minecraft:mossy_cobblestone
fill 389 23 220 389 25 220 minecraft:mossy_cobblestone
setblock 390 23 183 minecraft:stone_bricks
fill 390 23 184 390 26 184 minecraft:mossy_cobblestone
setblock 391 23 182 minecraft:stone_bricks
fill 391 23 183 391 26 183 minecraft:mossy_cobblestone
setblock 391 23 222 minecraft:stone_bricks
fill 392 23 182 392 26 182 minecraft:mossy_cobblestone
setblock 392 23 221 minecraft:stone_bricks
fill 392 23 222 392 26 222 minecraft:mossy_cobblestone
setblock 393 23 184 minecraft:mossy_cobblestone
setblock 393 23 220 minecraft:stone_bricks
fill 393 23 221 396 23 221 minecraft:mossy_cobblestone
setblock 394 23 184 minecraft:stone_bricks
setblock 395 23 183 minecraft:stone_bricks
setblock 396 23 182 minecraft:stone_bricks
fill 396 23 183 396 26 183 minecraft:mossy_cobblestone
setblock 396 23 222 minecraft:stone_bricks
fill 397 23 182 400 23 182 minecraft:mossy_cobblestone
setblock 397 23 221 minecraft:stone_bricks
fill 397 23 222 397 26 222 minecraft:mossy_cobblestone
fill 398 23 221 398 25 221 minecraft:mossy_cobblestone
setblock 400 23 183 minecraft:stone_bricks
setblock 401 23 182 minecraft:stone_bricks
fill 401 23 183 401 26 183 minecraft:mossy_cobblestone
setblock 401 23 222 minecraft:stone_bricks
fill 402 23 182 402 26 182 minecraft:mossy_cobblestone
setblock 402 23 221 minecraft:stone_bricks
fill 402 23 222 402 26 222 minecraft:mossy_cobblestone
setblock 403 23 220 minecraft:stone_bricks
fill 403 23 221 403 26 221 minecraft:mossy_cobblestone
fill 404 23 220 404 25 220 minecraft:mossy_cobblestone
setblock 405 23 183 minecraft:stone_bricks
setblock 406 23 182 minecraft:stone_bricks
fill 406 23 183 406 26 183 minecraft:mossy_cobblestone
setblock 406 23 222 minecraft:stone_bricks
fill 407 23 182 407 26 182 minecraft:mossy_cobblestone
setblock 407 23 221 minecraft:stone_bricks
fill 407 23 222 407 26 222 minecraft:mossy_cobblestone
setblock 408 23 184 minecraft:mossy_cobblestone
setblock 408 23 220 minecraft:stone_bricks
fill 408 23 221 408 26 221 minecraft:mossy_cobblestone
setblock 409 23 183 minecraft:mossy_cobblestone
fill 409 23 220 409 24 220 minecraft:mossy_cobblestone
setblock 410 23 183 minecraft:stone_bricks
setblock 411 23 182 minecraft:stone_bricks
fill 411 23 183 411 26 183 minecraft:mossy_cobblestone
setblock 411 23 222 minecraft:stone_bricks
fill 412 23 182 412 26 182 minecraft:mossy_cobblestone
setblock 412 23 221 minecraft:stone_bricks
fill 412 23 222 412 26 222 minecraft:mossy_cobblestone
setblock 413 23 221 minecraft:mossy_cobblestone
setblock 414 23 204 minecraft:stone_bricks
setblock 415 23 182 minecraft:mossy_cobblestone
setblock 415 23 203 minecraft:stone_bricks
fill 415 23 204 415 26 204 minecraft:mossy_cobblestone
setblock 416 23 182 minecraft:stone_bricks
fill 416 23 198 416 24 198 minecraft:mossy_cobblestone
setblock 416 23 202 minecraft:stone_bricks
fill 416 23 203 416 26 203 minecraft:mossy_cobblestone
setblock 416 23 206 minecraft:mossy_cobblestone
setblock 416 23 207 minecraft:stone_bricks
fill 416 23 208 416 26 208 minecraft:mossy_cobblestone
setblock 416 23 222 minecraft:stone_bricks
fill 417 23 182 417 25 182 minecraft:mossy_cobblestone
fill 417 23 184 417 23 185 minecraft:mossy_cobblestone
setblock 417 23 196 minecraft:stone_bricks
fill 417 23 197 417 25 197 minecraft:mossy_cobblestone
setblock 417 23 201 minecraft:stone_bricks
fill 417 23 202 417 26 202 minecraft:mossy_cobblestone
setblock 417 23 206 minecraft:stone_bricks
fill 417 23 207 417 26 207 minecraft:mossy_cobblestone
setblock 417 23 222 minecraft:mossy_cobblestone
fill 377 24 182 377 24 184 minecraft:mossy_cobblestone
setblock 377 24 185 minecraft:stone_bricks
fill 377 24 186 378 26 186 minecraft:mossy_cobblestone
setblock 377 24 190 minecraft:stone_bricks
fill 377 24 191 377 27 191 minecraft:mossy_cobblestone
setblock 377 24 195 minecraft:stone_bricks
fill 377 24 196 377 25 196 minecraft:mossy_cobblestone
setblock 377 24 200 minecraft:stone_bricks
fill 377 24 201 377 27 201 minecraft:mossy_cobblestone
setblock 377 24 204 minecraft:mossy_cobblestone
setblock 377 24 205 minecraft:stone_bricks
fill 377 24 206 377 27 206 minecraft:mossy_cobblestone
fill 377 24 208 377 25 208 minecraft:mossy_cobblestone
setblock 378 24 183 minecraft:mossy_cobblestone
setblock 378 24 184 minecraft:stone_bricks
fill 378 24 185 378 27 185 minecraft:mossy_cobblestone
fill 378 24 187 378 25 187 minecraft:mossy_cobblestone
setblock 378 24 200 minecraft:mossy_cobblestone
setblock 378 24 204 minecraft:stone_bricks
setblock 379 24 183 minecraft:stone_bricks
setblock 380 24 182 minecraft:stone_bricks
fill 380 24 183 380 26 184 minecraft:mossy_cobblestone
setblock 380 24 222 minecraft:stone_bricks
fill 381 24 182 381 27 182 minecraft:mossy_cobblestone
fill 381 24 222 381 27 222 minecraft:mossy_cobblestone
setblock 382 24 184 minecraft:mossy_cobblestone
setblock 383 24 184 minecraft:stone_bricks
fill 383 24 185 383 27 185 minecraft:mossy_cobblestone
setblock 384 24 183 minecraft:stone_bricks
fill 384 24 184 384 27 184 minecraft:mossy_cobblestone
setblock 385 24 182 minecraft:stone_bricks
fill 385 24 183 385 27 183 minecraft:mossy_cobblestone
setblock 385 24 222 minecraft:stone_bricks
fill 386 24 182 386 27 182 minecraft:mossy_cobblestone
setblock 386 24 221 minecraft:stone_bricks
fill 386 24 222 386 27 222 minecraft:mossy_cobblestone
setblock 387 24 185 minecraft:stone_bricks
setblock 387 24 220 minecraft:stone_bricks
fill 387 24 221 387 27 221 minecraft:mossy_cobblestone
setblock 388 24 184 minecraft:stone_bricks
fill 388 24 185 388 27 185 minecraft:mossy_cobblestone
fill 388 24 220 388 25 220 minecraft:mossy_cobblestone
setblock 389 24 183 minecraft:stone_bricks
fill 389 24 184 389 27 184 minecraft:mossy_cobblestone
setblock 390 24 182 minecraft:stone_bricks
fill 390 24 183 390 27 183 minecraft:mossy_cobblestone
setblock 390 24 222 minecraft:stone_bricks
fill 391 24 182 391 27 182 minecraft:mossy_cobblestone
setblock 391 24 221 minecraft:stone_bricks
fill 391 24 222 391 27 222 minecraft:mossy_cobblestone
setblock 392 24 220 minecraft:stone_bricks
fill 392 24 221 395 24 221 minecraft:mossy_cobblestone
setblock 393 24 184 minecraft:stone_bricks
setblock 394 24 183 minecraft:stone_bricks
setblock 394 24 184 minecraft:mossy_cobblestone
setblock 395 24 182 minecraft:stone_bricks
fill 395 24 183 395 26 183 minecraft:mossy_cobblestone
setblock 395 24 222 minecraft:stone_bricks
fill 396 24 182 399 24 182 minecraft:mossy_cobblestone
setblock 396 24 221 minecraft:stone_bricks
fill 396 24 222 396 27 222 minecraft:mossy_cobblestone
fill 397 24 221 397 25 221 minecraft:mossy_cobblestone
setblock 399 24 183 minecraft:stone_bricks
setblock 400 24 182 minecraft:stone_bricks
fill 400 24 183 400 26 183 minecraft:mossy_cobblestone
setblock 400 24 222 minecraft:stone_bricks
fill 401 24 182 401 27 182 minecraft:mossy_cobblestone
setblock 401 24 221 minecraft:stone_bricks
fill 401 24 222 401 27 222 minecraft:mossy_cobblestone
fill 402 24 221 402 27 221 minecraft:mossy_cobblestone
setblock 403 24 220 minecraft:mossy_cobblestone
setblock 404 24 182 minecraft:mossy_cobblestone
setblock 404 24 183 minecraft:stone_bricks
setblock 405 24 182 minecraft:stone_bricks
fill 405 24 183 405 27 183 minecraft:mossy_cobblestone
setblock 405 24 222 minecraft:stone_bricks
fill 406 24 182 406 27 182 minecraft:mossy_cobblestone
fill 406 24 184 407 24 184 minecraft:mossy_cobblestone
setblock 406 24 221 minecraft:stone_bricks
fill 406 24 222 406 27 222 minecraft:mossy_cobblestone
setblock 407 24 220 minecraft:stone_bricks
fill 407 24 221 407 27 221 minecraft:mossy_cobblestone
setblock 408 24 184 minecraft:stone_bricks
fill 408 24 220 408 25 220 minecraft:mossy_cobblestone
setblock 409 24 183 minecraft:stone_bricks
setblock 409 24 184 minecraft:mossy_cobblestone
setblock 410 24 182 minecraft:stone_bricks
fill 410 24 183 410 27 183 minecraft:mossy_cobblestone
setblock 410 24 222 minecraft:stone_bricks
fill 411 24 182 411 27 182 minecraft:mossy_cobblestone
setblock 411 24 221 minecraft:stone_bricks
fill 411 24 222 411 27 222 minecraft:mossy_cobblestone
setblock 412 24 221 minecraft:mossy_cobblestone
setblock 415 24 182 minecraft:stone_bricks
setblock 415 24 202 minecraft:stone_bricks
fill 415 24 203 415 25 203 minecraft:mossy_cobblestone
setblock 415 24 207 minecraft:stone_bricks
setblock 415 24 222 minecraft:stone_bricks
fill 416 24 182 416 25 182 minecraft:mossy_cobblestone
setblock 416 24 201 minecraft:stone_bricks
fill 416 24 202 416 27 202 minecraft:mossy_cobblestone
setblock 416 24 206 minecraft:stone_bricks
fill 416 24 207 416 27 207 minecraft:mossy_cobblestone
fill 416 24 209 417 24 209 minecraft:mossy_cobblestone
setblock 417 24 184 minecraft:mossy_cobblestone
setblock 417 24 185 minecraft:stone_bricks
fill 417 24 186 417 27 186 minecraft:mossy_cobblestone
setblock 417 24 196 minecraft:mossy_cobblestone
setblock 417 24 200 minecraft:stone_bricks
fill 417 24 201 417 27 201 minecraft:mossy_cobblestone
setblock 417 24 205 minecraft:stone_bricks
fill 417 24 206 417 27 206 minecraft:mossy_cobblestone
setblock 417 24 210 minecraft:stone_bricks
fill 377 25 182 377 25 183 minecraft:mossy_cobblestone
setblock 377 25 184 minecraft:stone_bricks
fill 377 25 185 377 28 185 minecraft:mossy_cobblestone
setblock 377 25 188 minecraft:mossy_cobblestone
setblock 377 25 189 minecraft:stone_bricks
fill 377 25 190 377 28 190 minecraft:mossy_cobblestone
setblock 377 25 199 minecraft:stone_bricks
fill 377 25 200 377 26 200 minecraft:mossy_cobblestone
setblock 377 25 204 minecraft:stone_bricks
fill 377 25 205 377 28 205 minecraft:mossy_cobblestone
setblock 378 25 183 minecraft:stone_bricks
fill 378 25 184 378 28 184 minecraft:mossy_cobblestone
setblock 378 25 188 minecraft:stone_bricks
setblock 378 25 203 minecraft:stone_bricks
setblock 378 25 204 minecraft:mossy_cobblestone
setblock 379 25 182 minecraft:stone_bricks
fill 379 25 183 379 28 183 minecraft:mossy_cobblestone
setblock 379 25 184 minecraft:light[level=12]
setblock 379 25 192 minecraft:light[level=12]
setblock 379 25 200 minecraft:light[level=12]
setblock 379 25 208 minecraft:light[level=12]
setblock 379 25 216 minecraft:light[level=12]
fill 380 25 182 380 28 182 minecraft:mossy_cobblestone
fill 380 25 222 380 26 222 minecraft:mossy_cobblestone
setblock 382 25 184 minecraft:stone_bricks
setblock 383 25 183 minecraft:stone_bricks
fill 383 25 184 383 28 184 minecraft:mossy_cobblestone
setblock 384 25 182 minecraft:stone_bricks
fill 384 25 183 384 28 183 minecraft:mossy_cobblestone
setblock 384 25 222 minecraft:stone_bricks
fill 385 25 182 385 28 182 minecraft:mossy_cobblestone
setblock 385 25 221 minecraft:stone_bricks
fill 385 25 222 385 28 222 minecraft:mossy_cobblestone
setblock 386 25 184 minecraft:mossy_cobblestone
setblock 386 25 185 minecraft:stone_bricks
fill 386 25 221 386 28 221 minecraft:mossy_cobblestone
setblock 387 25 184 minecraft:stone_bricks
fill 387 25 185 387 28 185 minecraft:mossy_cobblestone
setblock 387 25 192 minecraft:light[level=12]
setblock 387 25 200 minecraft:light[level=12]
setblock 387 25 208 minecraft:light[level=12]
setblock 387 25 216 minecraft:light[level=12]
setblock 387 25 220 minecraft:mossy_cobblestone
setblock 388 25 183 minecraft:stone_bricks
fill 388 25 184 388 28 184 minecraft:mossy_cobblestone
setblock 389 25 182 minecraft:stone_bricks
fill 389 25 183 389 28 183 minecraft:mossy_cobblestone
setblock 389 25 222 minecraft:stone_bricks
fill 390 25 182 390 28 182 minecraft:mossy_cobblestone
setblock 390 25 185 minecraft:mossy_cobblestone
setblock 390 25 221 minecraft:stone_bricks
fill 390 25 222 390 28 222 minecraft:mossy_cobblestone
setblock 391 25 185 minecraft:stone_bricks
fill 391 25 221 394 25 221 minecraft:mossy_cobblestone
setblock 392 25 184 minecraft:stone_bricks
setblock 393 25 183 minecraft:stone_bricks
fill 393 25 184 393 26 184 minecraft:mossy_cobblestone
setblock 394 25 182 minecraft:stone_bricks
fill 394 25 183 394 27 183 minecraft:mossy_cobblestone
setblock 394 25 222 minecraft:stone_bricks
fill 395 25 182 398 25 182 minecraft:mossy_cobblestone
setblock 395 25 184 minecraft:light[level=12]
setblock 395 25 192 minecraft:light[level=12]
setblock 395 25 200 minecraft:light[level=12]
setblock 395 25 208 minecraft:light[level=12]
setblock 395 25 216 minecraft:light[level=12]
setblock 395 25 221 minecraft:stone_bricks
fill 395 25 222 395 28 222 minecraft:mossy_cobblestone
setblock 396 25 221 minecraft:mossy_cobblestone
setblock 398 25 183 minecraft:stone_bricks
setblock 399 25 182 minecraft:stone_bricks
setblock 399 25 183 minecraft:mossy_cobblestone
setblock 399 25 222 minecraft:stone_bricks
fill 400 25 182 400 28 182 minecraft:mossy_cobblestone
setblock 400 25 221 minecraft:stone_bricks
fill 400 25 222 400 28 222 minecraft:mossy_cobblestone
fill 401 25 221 401 27 221 minecraft:mossy_cobblestone
setblock 402 25 183 minecraft:mossy_cobblestone
setblock 403 25 183 minecraft:stone_bricks
setblock 403 25 184 minecraft:light[level=12]
setblock 403 25 192 minecraft:light[level=12]
setblock 403 25 200 minecraft:light[level=12]
setblock 403 25 208 minecraft:light[level=12]
setblock 403 25 216 minecraft:light[level=12]
setblock 404 25 182 minecraft:stone_bricks
fill 404 25 183 404 28 183 minecraft:mossy_cobblestone
setblock 404 25 222 minecraft:stone_bricks
fill 405 25 182 405 28 182 minecraft:mossy_cobblestone
fill 405 25 184 406 25 184 minecraft:mossy_cobblestone
setblock 405 25 221 minecraft:stone_bricks
fill 405 25 222 405 28 222 minecraft:mossy_cobblestone
setblock 406 25 220 minecraft:stone_bricks
fill 406 25 221 406 28 221 minecraft:mossy_cobblestone
setblock 407 25 184 minecraft:stone_bricks
setblock 407 25 220 minecraft:mossy_cobblestone
setblock 408 25 183 minecraft:stone_bricks
setblock 408 25 184 minecraft:mossy_cobblestone
setblock 409 25 182 minecraft:stone_bricks
fill 409 25 183 409 27 183 minecraft:mossy_cobblestone
setblock 409 25 222 minecraft:stone_bricks
fill 410 25 182 410 28 182 minecraft:mossy_cobblestone
setblock 410 25 221 minecraft:stone_bricks
fill 410 25 222 410 27 222 minecraft:mossy_cobblestone
setblock 411 25 184 minecraft:light[level=12]
setblock 411 25 192 minecraft:light[level=12]
setblock 411 25 200 minecraft:light[level=12]
setblock 411 25 208 minecraft:light[level=12]
setblock 411 25 216 minecraft:light[level=12]
setblock 411 25 221 minecraft:mossy_cobblestone
setblock 412 25 183 minecraft:mossy_cobblestone
setblock 414 25 182 minecraft:stone_bricks
setblock 414 25 222 minecraft:stone_bricks
setblock 415 25 182 minecraft:mossy_cobblestone
setblock 415 25 202 minecraft:mossy_cobblestone
setblock 415 25 206 minecraft:stone_bricks
setblock 415 25 207 minecraft:mossy_cobblestone
setblock 416 25 200 minecraft:stone_bricks
fill 416 25 201 416 26 201 minecraft:mossy_cobblestone
setblock 416 25 205 minecraft:stone_bricks
fill 416 25 206 416 28 206 minecraft:mossy_cobblestone
setblock 417 25 184 minecraft:stone_bricks
fill 417 25 185 417 28 185 minecraft:mossy_cobblestone
fill 417 25 187 417 26 187 minecraft:mossy_cobblestone
setblock 417 25 199 minecraft:stone_bricks
fill 417 25 200 417 28 200 minecraft:mossy_cobblestone
setblock 417 25 204 minecraft:stone_bricks
fill 417 25 205 417 28 205 minecraft:mossy_cobblestone
setblock 417 25 209 minecraft:stone_bricks
fill 417 25 210 417 28 210 minecraft:mossy_cobblestone
setblock 377 26 182 minecraft:mossy_cobblestone
setblock 377 26 183 minecraft:stone_bricks
fill 377 26 184 377 29 184 minecraft:mossy_cobblestone
setblock 377 26 188 minecraft:stone_bricks
fill 377 26 189 377 29 189 minecraft:mossy_cobblestone
setblock 377 26 198 minecraft:stone_bricks
setblock 377 26 199 minecraft:mossy_cobblestone
setblock 377 26 203 minecraft:stone_bricks
fill 377 26 204 377 28 204 minecraft:mossy_cobblestone
setblock 378 26 182 minecraft:stone_bricks
fill 378 26 183 378 29 183 minecraft:mossy_cobblestone
setblock 378 26 187 minecraft:stone_bricks
fill 378 26 188 378 29 188 minecraft:mossy_cobblestone
fill 379 26 182 379 29 182 minecraft:mossy_cobblestone
setblock 381 26 183 minecraft:mossy_cobblestone
setblock 381 26 184 minecraft:stone_bricks
setblock 382 26 183 minecraft:stone_bricks
fill 382 26 184 382 28 185 minecraft:mossy_cobblestone
setblock 383 26 182 minecraft:stone_bricks
fill 383 26 183 383 29 183 minecraft:mossy_cobblestone
setblock 383 26 222 minecraft:stone_bricks
fill 384 26 182 384 29 182 minecraft:mossy_cobblestone
setblock 384 26 185 minecraft:mossy_cobblestone
setblock 384 26 221 minecraft:stone_bricks
fill 384 26 222 384 29 222 minecraft:mossy_cobblestone
setblock 385 26 185 minecraft:stone_bricks
fill 385 26 221 385 28 221 minecraft:mossy_cobblestone
setblock 386 26 184 minecraft:stone_bricks
fill 386 26 185 386 29 185 minecraft:mossy_cobblestone
setblock 387 26 183 minecraft:stone_bricks
fill 387 26 184 387 29 184 minecraft:mossy_cobblestone
setblock 388 26 182 minecraft:stone_bricks
fill 388 26 183 388 29 183 minecraft:mossy_cobblestone
setblock 388 26 222 minecraft:stone_bricks
fill 389 26 182 389 29 182 minecraft:mossy_cobblestone
setblock 389 26 221 minecraft:stone_bricks
fill 389 26 222 389 29 222 minecraft:mossy_cobblestone
setblock 390 26 185 minecraft:stone_bricks
fill 390 26 221 393 26 221 minecraft:mossy_cobblestone
setblock 391 26 184 minecraft:stone_bricks
setblock 392 26 183 minecraft:stone_bricks
setblock 392 26 184 minecraft:mossy_cobblestone
setblock 393 26 182 minecraft:stone_bricks
fill 393 26 183 393 28 183 minecraft:mossy_cobblestone
setblock 393 26 222 minecraft:stone_bricks
fill 394 26 182 397 26 182 minecraft:mossy_cobblestone
setblock 394 26 221 minecraft:stone_bricks
fill 394 26 222 394 28 222 minecraft:mossy_cobblestone
setblock 398 26 182 minecraft:stone_bricks
setblock 398 26 222 minecraft:stone_bricks
fill 399 26 182 399 29 182 minecraft:mossy_cobblestone
fill 399 26 222 399 29 222 minecraft:mossy_cobblestone
setblock 400 26 221 minecraft:mossy_cobblestone
setblock 402 26 183 minecraft:stone_bricks
setblock 403 26 182 minecraft:stone_bricks
fill 403 26 183 403 28 183 minecraft:mossy_cobblestone
setblock 403 26 222 minecraft:stone_bricks
fill 404 26 182 404 29 182 minecraft:mossy_cobblestone
setblock 404 26 221 minecraft:stone_bricks
fill 404 26 222 404 29 222 minecraft:mossy_cobblestone
fill 405 26 221 405 28 221 minecraft:mossy_cobblestone
setblock 406 26 184 minecraft:stone_bricks
setblock 407 26 183 minecraft:stone_bricks
setblock 408 26 182 minecraft:stone_bricks
fill 408 26 183 408 28 183 minecraft:mossy_cobblestone
setblock 408 26 222 minecraft:stone_bricks
fill 409 26 182 409 29 182 minecraft:mossy_cobblestone
setblock 409 26 221 minecraft:stone_bricks
fill 409 26 222 409 28 222 minecraft:mossy_cobblestone
setblock 410 26 221 minecraft:mossy_cobblestone
setblock 413 26 182 minecraft:stone_bricks
setblock 414 26 182 minecraft:mossy_cobblestone
setblock 415 26 205 minecraft:stone_bricks
setblock 416 26 204 minecraft:stone_bricks
fill 416 26 205 416 28 205 minecraft:mossy_cobblestone
setblock 417 26 183 minecraft:stone_bricks
fill 417 26 184 417 28 184 minecraft:mossy_cobblestone
setblock 417 26 188 minecraft:stone_bricks
setblock 417 26 198 minecraft:stone_bricks
fill 417 26 199 417 27 199 minecraft:mossy_cobblestone
setblock 417 26 203 minecraft:stone_bricks
fill 417 26 204 417 29 204 minecraft:mossy_cobblestone
setblock 417 26 208 minecraft:stone_bricks
fill 417 26 209 417 29 209 minecraft:mossy_cobblestone
setblock 377 27 182 minecraft:stone_bricks
fill 377 27 183 377 30 183 minecraft:mossy_cobblestone
setblock 377 27 186 minecraft:mossy_cobblestone
setblock 377 27 187 minecraft:stone_bricks
fill 377 27 188 377 30 188 minecraft:mossy_cobblestone
setblock 377 27 192 minecraft:stone_bricks
setblock 377 27 202 minecraft:stone_bricks
setblock 377 27 203 minecraft:mossy_cobblestone
setblock 377 27 207 minecraft:stone_bricks
fill 378 27 182 378 30 182 minecraft:mossy_cobblestone
setblock 378 27 186 minecraft:stone_bricks
fill 378 27 187 378 30 187 minecraft:mossy_cobblestone
fill 378 27 189 378 28 189 minecraft:mossy_cobblestone
setblock 379 27 185 minecraft:stone_bricks
setblock 380 27 183 minecraft:mossy_cobblestone
setblock 380 27 184 minecraft:stone_bricks
setblock 381 27 183 minecraft:stone_bricks
fill 381 27 184 381 30 184 minecraft:mossy_cobblestone
setblock 382 27 182 minecraft:stone_bricks
fill 382 27 183 382 30 183 minecraft:mossy_cobblestone
setblock 382 27 222 minecraft:stone_bricks
fill 383 27 182 383 30 182 minecraft:mossy_cobblestone
fill 383 27 222 383 30 222 minecraft:mossy_cobblestone
setblock 384 27 185 minecraft:stone_bricks
fill 384 27 221 384 28 221 minecraft:mossy_cobblestone
setblock 385 27 184 minecraft:stone_bricks
fill 385 27 185 385 30 185 minecraft:mossy_cobblestone
setblock 386 27 183 minecraft:stone_bricks
fill 386 27 184 386 30 184 minecraft:mossy_cobblestone
setblock 387 27 182 minecraft:stone_bricks
fill 387 27 183 387 30 183 minecraft:mossy_cobblestone
setblock 387 27 222 minecraft:stone_bricks
fill 388 27 182 388 30 182 minecraft:mossy_cobblestone
setblock 388 27 221 minecraft:stone_bricks
fill 388 27 222 388 30 222 minecraft:mossy_cobblestone
setblock 389 27 185 minecraft:stone_bricks
fill 389 27 221 391 27 221 minecraft:mossy_cobblestone
setblock 390 27 184 minecraft:stone_bricks
setblock 391 27 183 minecraft:stone_bricks
setblock 391 27 184 minecraft:mossy_cobblestone
setblock 392 27 182 minecraft:stone_bricks
fill 392 27 183 392 28 183 minecraft:mossy_cobblestone
setblock 392 27 222 minecraft:stone_bricks
fill 393 27 182 396 27 182 minecraft:mossy_cobblestone
fill 393 27 222 393 28 222 minecraft:mossy_cobblestone
setblock 397 27 182 minecraft:stone_bricks
setblock 397 27 222 minecraft:stone_bricks
fill 398 27 182 398 28 182 minecraft:mossy_cobblestone
fill 398 27 222 398 28 222 minecraft:mossy_cobblestone
setblock 401 27 183 minecraft:stone_bricks
setblock 402 27 182 minecraft:stone_bricks
fill 402 27 183 402 28 183 minecraft:mossy_cobblestone
setblock 402 27 222 minecraft:stone_bricks
fill 403 27 182 403 30 182 minecraft:mossy_cobblestone
setblock 403 27 221 minecraft:stone_bricks
fill 403 27 222 403 30 222 minecraft:mossy_cobblestone
fill 404 27 221 404 28 221 minecraft:mossy_cobblestone
setblock 406 27 183 minecraft:stone_bricks
setblock 407 27 182 minecraft:stone_bricks
fill 407 27 183 407 28 183 minecraft:mossy_cobblestone
setblock 407 27 222 minecraft:stone_bricks
fill 408 27 182 408 29 182 minecraft:mossy_cobblestone
setblock 408 27 221 minecraft:stone_bricks
fill 408 27 222 408 29 222 minecraft:mossy_cobblestone
setblock 412 27 182 minecraft:stone_bricks
setblock 416 27 203 minecraft:stone_bricks
fill 416 27 204 416 28 204 minecraft:mossy_cobblestone
setblock 416 27 208 minecraft:stone_bricks
setblock 417 27 187 minecraft:stone_bricks
fill 417 27 188 417 30 188 minecraft:mossy_cobblestone
setblock 417 27 202 minecraft:stone_bricks
fill 417 27 203 417 30 203 minecraft:mossy_cobblestone
setblock 417 27 207 minecraft:stone_bricks
fill 417 27 208 417 30 208 minecraft:mossy_cobblestone
fill 377 28 182 377 31 182 minecraft:mossy_cobblestone
setblock 377 28 186 minecraft:stone_bricks
fill 377 28 187 377 31 187 minecraft:mossy_cobblestone
setblock 377 28 191 minecraft:stone_bricks
fill 377 28 192 377 31 192 minecraft:mossy_cobblestone
setblock 377 28 206 minecraft:stone_bricks
setblock 378 28 185 minecraft:stone_bricks
fill 378 28 186 379 30 186 minecraft:mossy_cobblestone
fill 379 28 185 379 31 185 minecraft:mossy_cobblestone
setblock 380 28 183 minecraft:stone_bricks
fill 380 28 184 380 31 184 minecraft:mossy_cobblestone
setblock 381 28 182 minecraft:stone_bricks
fill 381 28 183 381 31 183 minecraft:mossy_cobblestone
setblock 381 28 222 minecraft:stone_bricks
fill 382 28 182 382 31 182 minecraft:mossy_cobblestone
fill 382 28 222 382 31 222 minecraft:mossy_cobblestone
setblock 383 28 185 minecraft:stone_bricks
setblock 384 28 184 minecraft:stone_bricks
fill 384 28 185 384 31 185 minecraft:mossy_cobblestone
setblock 385 28 183 minecraft:stone_bricks
fill 385 28 184 385 31 184 minecraft:mossy_cobblestone
setblock 386 28 182 minecraft:stone_bricks
fill 386 28 183 386 31 183 minecraft:mossy_cobblestone
setblock 386 28 222 minecraft:stone_bricks
fill 387 28 182 387 31 182 minecraft:mossy_cobblestone
setblock 387 28 221 minecraft:stone_bricks
fill 387 28 222 387 31 222 minecraft:mossy_cobblestone
setblock 388 28 185 minecraft:stone_bricks
fill 388 28 221 389 28 221 minecraft:mossy_cobblestone
setblock 389 28 184 minecraft:stone_bricks
setblock 390 28 183 minecraft:stone_bricks
setblock 390 28 184 minecraft:mossy_cobblestone
setblock 391 28 182 minecraft:stone_bricks
fill 391 28 183 391 29 183 minecraft:mossy_cobblestone
setblock 391 28 222 minecraft:stone_bricks
fill 392 28 182 395 28 182 minecraft:mossy_cobblestone
fill 392 28 222 392 29 222 minecraft:mossy_cobblestone
setblock 396 28 182 minecraft:stone_bricks
setblock 396 28 222 minecraft:stone_bricks
setblock 397 28 182 minecraft:mossy_cobblestone
setblock 397 28 222 minecraft:mossy_cobblestone
setblock 401 28 182 minecraft:stone_bricks
setblock 401 28 222 minecraft:stone_bricks
fill 402 28 182 402 31 182 minecraft:mossy_cobblestone
fill 402 28 222 402 31 222 minecraft:mossy_cobblestone
setblock 403 28 221 minecraft:mossy_cobblestone
setblock 405 28 183 minecraft:stone_bricks
setblock 406 28 182 minecraft:stone_bricks
setblock 406 28 183 minecraft:mossy_cobblestone
setblock 406 28 222 minecraft:stone_bricks
fill 407 28 182 407 30 182 minecraft:mossy_cobblestone
fill 407 28 222 407 29 222 minecraft:mossy_cobblestone
setblock 416 28 207 minecraft:stone_bricks
setblock 417 28 186 minecraft:stone_bricks
fill 417 28 187 417 31 187 minecraft:mossy_cobblestone
fill 417 28 189 417 29 189 minecraft:mossy_cobblestone
setblock 417 28 201 minecraft:stone_bricks
fill 417 28 202 417 29 202 minecraft:mossy_cobblestone
setblock 417 28 206 minecraft:stone_bricks
fill 417 28 207 417 31 207 minecraft:mossy_cobblestone
setblock 377 29 185 minecraft:stone_bricks
fill 377 29 186 377 32 186 minecraft:mossy_cobblestone
setblock 377 29 190 minecraft:stone_bricks
fill 377 29 191 377 32 191 minecraft:mossy_cobblestone
setblock 378 29 184 minecraft:stone_bricks
fill 378 29 185 378 32 185 minecraft:mossy_cobblestone
setblock 378 29 189 minecraft:stone_bricks
fill 378 29 190 378 32 190 minecraft:mossy_cobblestone
setblock 379 29 183 minecraft:stone_bricks
setblock 379 29 187 minecraft:mossy_cobblestone
setblock 380 29 182 minecraft:stone_bricks
fill 380 29 183 380 32 183 minecraft:mossy_cobblestone
fill 381 29 182 381 32 182 minecraft:mossy_cobblestone
fill 381 29 222 381 32 222 minecraft:mossy_cobblestone
setblock 382 29 184 minecraft:mossy_cobblestone
setblock 382 29 185 minecraft:stone_bricks
setblock 383 29 184 minecraft:stone_bricks
fill 383 29 185 383 31 185 minecraft:mossy_cobblestone
setblock 384 29 183 minecraft:stone_bricks
fill 384 29 184 384 32 184 minecraft:mossy_cobblestone
setblock 385 29 182 minecraft:stone_bricks
fill 385 29 183 385 32 183 minecraft:mossy_cobblestone
setblock 385 29 222 minecraft:stone_bricks
fill 386 29 182 386 32 182 minecraft:mossy_cobblestone
setblock 386 29 221 minecraft:stone_bricks
fill 386 29 222 386 32 222 minecraft:mossy_cobblestone
setblock 387 29 185 minecraft:stone_bricks
setblock 388 29 184 minecraft:stone_bricks
setblock 389 29 183 minecraft:stone_bricks
setblock 389 29 184 minecraft:mossy_cobblestone
setblock 390 29 182 minecraft:stone_bricks
fill 390 29 183 390 30 183 minecraft:mossy_cobblestone
setblock 390 29 222 minecraft:stone_bricks
fill 391 29 182 394 29 182 minecraft:mossy_cobblestone
setblock 391 29 222 minecraft:mossy_cobblestone
setblock 400 29 182 minecraft:stone_bricks
setblock 400 29 222 minecraft:stone_bricks
fill 401 29 182 401 31 182 minecraft:mossy_cobblestone
fill 401 29 222 401 32 222 minecraft:mossy_cobblestone
setblock 404 29 183 minecraft:stone_bricks
setblock 405 29 182 minecraft:stone_bricks
setblock 405 29 183 minecraft:mossy_cobblestone
setblock 405 29 222 minecraft:stone_bricks
fill 406 29 182 406 30 182 minecraft:mossy_cobblestone
fill 406 29 222 406 30 222 minecraft:mossy_cobblestone
setblock 417 29 185 minecraft:stone_bricks
fill 417 29 186 417 32 186 minecraft:mossy_cobblestone
setblock 417 29 190 minecraft:stone_bricks
setblock 417 29 205 minecraft:stone_bricks
fill 417 29 206 417 32 206 minecraft:mossy_cobblestone
setblock 417 29 210 minecraft:stone_bricks
setblock 377 30 184 minecraft:stone_bricks
fill 377 30 185 377 33 185 minecraft:mossy_cobblestone
setblock 377 30 189 minecraft:stone_bricks
fill 377 30 190 377 33 190 minecraft:mossy_cobblestone
setblock 378 30 183 minecraft:stone_bricks
fill 378 30 184 378 33 184 minecraft:mossy_cobblestone
setblock 378 30 188 minecraft:stone_bricks
fill 378 30 189 378 33 189 minecraft:mossy_cobblestone
setblock 379 30 182 minecraft:stone_bricks
fill 379 30 183 379 33 183 minecraft:mossy_cobblestone
setblock 379 30 187 minecraft:stone_bricks
fill 379 30 188 379 33 188 minecraft:mossy_cobblestone
fill 380 30 182 380 33 182 minecraft:mossy_cobblestone
setblock 382 30 184 minecraft:stone_bricks
setblock 382 30 185 minecraft:mossy_cobblestone
setblock 383 30 183 minecraft:stone_bricks
fill 383 30 184 383 33 184 minecraft:mossy_cobblestone
setblock 384 30 182 minecraft:stone_bricks
fill 384 30 183 384 33 183 minecraft:mossy_cobblestone
setblock 384 30 222 minecraft:stone_bricks
fill 385 30 182 385 33 182 minecraft:mossy_cobblestone
fill 385 30 222 385 33 222 minecraft:mossy_cobblestone
setblock 387 30 184 minecraft:stone_bricks
setblock 388 30 183 minecraft:stone_bricks
setblock 388 30 184 minecraft:mossy_cobblestone
setblock 389 30 182 minecraft:stone_bricks
fill 389 30 183 389 31 183 minecraft:mossy_cobblestone
setblock 389 30 222 minecraft:stone_bricks
fill 390 30 182 392 30 182 minecraft:mossy_cobblestone
setblock 390 30 222 minecraft:mossy_cobblestone
setblock 400 30 182 minecraft:mossy_cobblestone
fill 400 30 222 400 33 222 minecraft:mossy_cobblestone
setblock 404 30 182 minecraft:stone_bricks
setblock 404 30 222 minecraft:stone_bricks
fill 405 30 182 405 31 182 minecraft:mossy_cobblestone
fill 405 30 222 405 31 222 minecraft:mossy_cobblestone
fill 417 30 185 417 33 185 minecraft:mossy_cobblestone
setblock 417 30 189 minecraft:stone_bricks
fill 417 30 190 417 31 192 minecraft:mossy_cobblestone
setblock 417 30 204 minecraft:stone_bricks
fill 417 30 205 417 33 205 minecraft:mossy_cobblestone
setblock 417 30 209 minecraft:stone_bricks
fill 417 30 210 417 33 210 minecraft:mossy_cobblestone
setblock 377 31 183 minecraft:stone_bricks
fill 377 31 184 377 34 184 minecraft:mossy_cobblestone
setblock 377 31 188 minecraft:stone_bricks
fill 377 31 189 377 34 189 minecraft:mossy_cobblestone
setblock 377 31 193 minecraft:stone_bricks
setblock 378 31 182 minecraft:stone_bricks
fill 378 31 183 378 34 183 minecraft:mossy_cobblestone
setblock 378 31 186 minecraft:mossy_cobblestone
setblock 378 31 187 minecraft:stone_bricks
fill 378 31 188 378 34 188 minecraft:mossy_cobblestone
setblock 378 31 191 minecraft:mossy_cobblestone
fill 379 31 182 379 34 182 minecraft:mossy_cobblestone
setblock 379 31 186 minecraft:stone_bricks
fill 379 31 187 379 34 187 minecraft:mossy_cobblestone
fill 379 31 189 379 32 189 minecraft:mossy_cobblestone
setblock 381 31 184 minecraft:stone_bricks
setblock 382 31 183 minecraft:stone_bricks
fill 382 31 184 382 34 184 minecraft:mossy_cobblestone
setblock 383 31 182 minecraft:stone_bricks
fill 383 31 183 383 34 183 minecraft:mossy_cobblestone
setblock 383 31 222 minecraft:stone_bricks
fill 384 31 182 384 34 182 minecraft:mossy_cobblestone
fill 384 31 222 384 34 222 minecraft:mossy_cobblestone
setblock 386 31 184 minecraft:stone_bricks
fill 386 31 189 386 32 189 minecraft:lantern
setblock 387 31 183 minecraft:stone_bricks
setblock 387 31 184 minecraft:mossy_cobblestone
setblock 388 31 182 minecraft:stone_bricks
fill 388 31 183 388 32 183 minecraft:mossy_cobblestone
setblock 388 31 222 minecraft:stone_bricks
fill 389 31 182 391 31 182 minecraft:mossy_cobblestone
setblock 389 31 222 minecraft:mossy_cobblestone
setblock 403 31 182 minecraft:stone_bricks
setblock 403 31 222 minecraft:stone_bricks
fill 404 31 182 404 32 182 minecraft:mossy_cobblestone
fill 404 31 222 404 34 222 minecraft:mossy_cobblestone
setblock 417 31 188 minecraft:stone_bricks
fill 417 31 189 417 34 189 minecraft:mossy_cobblestone
setblock 417 31 193 minecraft:stone_bricks
fill 417 31 204 417 34 204 minecraft:mossy_cobblestone
setblock 417 31 208 minecraft:stone_bricks
fill 417 31 209 417 34 209 minecraft:mossy_cobblestone
setblock 377 32 182 minecraft:stone_bricks
fill 377 32 183 377 35 183 minecraft:mossy_cobblestone
setblock 377 32 187 minecraft:stone_bricks
fill 377 32 188 377 35 188 minecraft:mossy_cobblestone
setblock 377 32 192 minecraft:stone_bricks
fill 377 32 193 377 34 194 minecraft:mossy_cobblestone
fill 378 32 182 378 35 182 minecraft:mossy_cobblestone
setblock 378 32 186 minecraft:stone_bricks
fill 378 32 187 378 35 187 minecraft:mossy_cobblestone
setblock 378 32 191 minecraft:stone_bricks
fill 378 32 192 378 35 192 minecraft:mossy_cobblestone
setblock 379 32 185 minecraft:stone_bricks
fill 379 32 186 379 35 186 minecraft:mossy_cobblestone
setblock 379 32 190 minecraft:stone_bricks
setblock 380 32 184 minecraft:stone_bricks
setblock 381 32 183 minecraft:stone_bricks
fill 381 32 184 381 35 184 minecraft:mossy_cobblestone
setblock 382 32 182 minecraft:stone_bricks
fill 382 32 183 382 35 183 minecraft:mossy_cobblestone
setblock 382 32 222 minecraft:stone_bricks
fill 383 32 182 383 35 182 minecraft:mossy_cobblestone
fill 383 32 222 383 35 222 minecraft:mossy_cobblestone
setblock 385 32 184 minecraft:stone_bricks
setblock 386 32 183 minecraft:stone_bricks
setblock 386 32 184 minecraft:mossy_cobblestone
setblock 387 32 182 minecraft:stone_bricks
fill 387 32 183 387 33 183 minecraft:mossy_cobblestone
setblock 387 32 222 minecraft:stone_bricks
fill 388 32 182 390 32 182 minecraft:mossy_cobblestone
fill 388 32 222 388 35 222 minecraft:mossy_cobblestone
setblock 402 32 182 minecraft:stone_bricks
setblock 402 32 222 minecraft:stone_bricks
fill 403 32 182 403 33 182 minecraft:mossy_cobblestone
fill 403 32 222 403 35 222 minecraft:mossy_cobblestone
fill 417 32 184 417 34 184 minecraft:mossy_cobblestone
setblock 417 32 187 minecraft:stone_bricks
fill 417 32 188 417 35 188 minecraft:mossy_cobblestone
fill 417 32 190 417 32 191 minecraft:mossy_cobblestone
setblock 417 32 192 minecraft:stone_bricks
fill 417 32 193 417 33 195 minecraft:mossy_cobblestone
setblock 417 32 207 minecraft:stone_bricks
fill 417 32 208 417 35 208 minecraft:mossy_cobblestone
setblock 417 32 211 minecraft:mossy_cobblestone
fill 377 33 182 377 36 182 minecraft:mossy_cobblestone
setblock 377 33 186 minecraft:stone_bricks
fill 377 33 187 377 36 187 minecraft:mossy_cobblestone
setblock 377 33 191 minecraft:stone_bricks
fill 377 33 192 377 36 192 minecraft:mossy_cobblestone
setblock 377 33 195 minecraft:mossy_cobblestone
fill 377 33 209 377 33 210 minecraft:mossy_cobblestone
setblock 377 33 211 minecraft:stone_bricks
setblock 378 33 185 minecraft:stone_bricks
fill 378 33 186 378 36 186 minecraft:mossy_cobblestone
setblock 378 33 190 minecraft:stone_bricks
fill 378 33 191 379 35 191 minecraft:mossy_cobblestone
fill 378 33 193 378 34 193 minecraft:mossy_cobblestone
setblock 379 33 184 minecraft:stone_bricks
fill 379 33 185 379 36 185 minecraft:mossy_cobblestone
setblock 379 33 189 minecraft:stone_bricks
fill 379 33 190 379 36 190 minecraft:mossy_cobblestone
fill 379 33 192 379 34 192 minecraft:mossy_cobblestone
setblock 379 33 200 minecraft:light[level=12]
setblock 379 33 208 minecraft:light[level=12]
setblock 379 33 216 minecraft:light[level=12]
setblock 380 33 183 minecraft:stone_bricks
fill 380 33 184 380 36 184 minecraft:mossy_cobblestone
setblock 380 33 187 minecraft:mossy_cobblestone
setblock 380 33 188 minecraft:stone_bricks
setblock 380 33 222 minecraft:mossy_cobblestone
setblock 381 33 182 minecraft:stone_bricks
fill 381 33 183 381 36 183 minecraft:mossy_cobblestone
setblock 381 33 222 minecraft:stone_bricks
fill 382 33 182 382 36 182 minecraft:mossy_cobblestone
fill 382 33 222 382 36 222 minecraft:mossy_cobblestone
setblock 384 33 184 minecraft:stone_bricks
setblock 385 33 183 minecraft:stone_bricks
fill 385 33 184 385 34 184 minecraft:mossy_cobblestone
setblock 386 33 182 minecraft:stone_bricks
fill 386 33 183 386 35 183 minecraft:mossy_cobblestone
fill 386 33 189 386 42 189 minecraft:cobbled_deepslate
setblock 386 33 222 minecraft:stone_bricks
fill 387 33 182 389 33 182 minecraft:mossy_cobblestone
setblock 387 33 184 minecraft:light[level=12]
setblock 387 33 192 minecraft:light[level=12]
setblock 387 33 200 minecraft:light[level=12]
setblock 387 33 208 minecraft:light[level=12]
setblock 387 33 216 minecraft:light[level=12]
fill 387 33 222 387 36 222 minecraft:mossy_cobblestone
setblock 395 33 184 minecraft:light[level=12]
setblock 395 33 192 minecraft:light[level=12]
setblock 395 33 200 minecraft:light[level=12]
setblock 395 33 208 minecraft:light[level=12]
setblock 395 33 216 minecraft:light[level=12]
fill 399 33 222 399 34 222 minecraft:mossy_cobblestone
setblock 401 33 222 minecraft:stone_bricks
fill 402 33 182 402 36 182 minecraft:mossy_cobblestone
fill 402 33 222 402 36 222 minecraft:mossy_cobblestone
setblock 403 33 184 minecraft:light[level=12]
setblock 403 33 192 minecraft:light[level=12]
setblock 403 33 200 minecraft:light[level=12]
setblock 403 33 208 minecraft:light[level=12]
setblock 403 33 216 minecraft:light[level=12]
setblock 411 33 184 minecraft:light[level=12]
setblock 411 33 192 minecraft:light[level=12]
setblock 411 33 200 minecraft:light[level=12]
setblock 411 33 208 minecraft:light[level=12]
setblock 411 33 216 minecraft:light[level=12]
fill 416 33 188 416 33 191 minecraft:mossy_cobblestone
setblock 416 33 192 minecraft:stone_bricks
setblock 417 33 186 minecraft:stone_bricks
fill 417 33 187 417 36 187 minecraft:mossy_cobblestone
setblock 417 33 190 minecraft:mossy_cobblestone
setblock 417 33 191 minecraft:stone_bricks
fill 417 33 192 417 36 192 minecraft:mossy_cobblestone
setblock 417 33 196 minecraft:stone_bricks
fill 417 33 197 417 36 197 minecraft:mossy_cobblestone
setblock 417 33 206 minecraft:stone_bricks
fill 417 33 207 417 36 207 minecraft:mossy_cobblestone
setblock 417 33 211 minecraft:stone_bricks
fill 417 33 212 417 36 212 minecraft:mossy_cobblestone
setblock 377 34 185 minecraft:stone_bricks
fill 377 34 186 377 37 186 minecraft:mossy_cobblestone
setblock 377 34 190 minecraft:stone_bricks
fill 377 34 191 377 37 191 minecraft:mossy_cobblestone
setblock 377 34 195 minecraft:stone_bricks
fill 377 34 196 377 36 197 minecraft:mossy_cobblestone
fill 377 34 208 377 34 209 minecraft:mossy_cobblestone
setblock 377 34 210 minecraft:stone_bricks
fill 377 34 211 377 34 214 minecraft:mossy_cobblestone
setblock 378 34 184 minecraft:stone_bricks
fill 378 34 185 378 37 185 minecraft:mossy_cobblestone
setblock 378 34 189 minecraft:stone_bricks
fill 378 34 190 378 37 190 minecraft:mossy_cobblestone
setblock 378 34 194 minecraft:stone_bricks
fill 378 34 195 378 37 195 minecraft:mossy_cobblestone
setblock 379 34 183 minecraft:stone_bricks
fill 379 34 184 379 37 184 minecraft:mossy_cobblestone
setblock 379 34 188 minecraft:stone_bricks
fill 379 34 189 380 36 189 minecraft:mossy_cobblestone
setblock 379 34 193 minecraft:stone_bricks
setblock 379 34 222 minecraft:mossy_cobblestone
setblock 380 34 182 minecraft:stone_bricks
fill 380 34 183 380 37 183 minecraft:mossy_cobblestone
setblock 380 34 186 minecraft:mossy_cobblestone
setblock 380 34 187 minecraft:stone_bricks
fill 380 34 188 380 37 188 minecraft:mossy_cobblestone
fill 380 34 190 380 35 190 minecraft:mossy_cobblestone
setblock 380 34 222 minecraft:stone_bricks
fill 381 34 182 381 37 182 minecraft:mossy_cobblestone
fill 381 34 222 381 37 222 minecraft:mossy_cobblestone
setblock 383 34 184 minecraft:stone_bricks
fill 383 34 221 384 35 221 minecraft:mossy_cobblestone
setblock 384 34 183 minecraft:stone_bricks
fill 384 34 184 384 35 184 minecraft:mossy_cobblestone
setblock 385 34 182 minecraft:stone_bricks
fill 385 34 183 385 37 183 minecraft:mossy_cobblestone
setblock 385 34 222 minecraft:stone_bricks
fill 386 34 182 388 35 182 minecraft:mossy_cobblestone
fill 386 34 222 386 37 222 minecraft:mossy_cobblestone
fill 398 34 222 398 35 222 minecraft:mossy_cobblestone
setblock 400 34 222 minecraft:stone_bricks
fill 401 34 182 401 37 182 minecraft:mossy_cobblestone
fill 401 34 222 401 37 222 minecraft:mossy_cobblestone
fill 416 34 187 416 34 190 minecraft:mossy_cobblestone
setblock 416 34 191 minecraft:stone_bricks
fill 416 34 192 416 35 194 minecraft:mossy_cobblestone
fill 417 34 183 417 35 183 minecraft:mossy_cobblestone
setblock 417 34 185 minecraft:stone_bricks
fill 417 34 186 417 37 186 minecraft:mossy_cobblestone
setblock 417 34 190 minecraft:stone_bricks
fill 417 34 191 417 37 191 minecraft:mossy_cobblestone
fill 417 34 193 417 34 194 minecraft:mossy_cobblestone
setblock 417 34 195 minecraft:stone_bricks
fill 417 34 196 417 37 196 minecraft:mossy_cobblestone
fill 417 34 198 417 34 199 minecraft:mossy_cobblestone
setblock 417 34 200 minecraft:stone_bricks
fill 417 34 203 417 35 203 minecraft:mossy_cobblestone
setblock 417 34 205 minecraft:stone_bricks
fill 417 34 206 417 37 206 minecraft:mossy_cobblestone
setblock 417 34 210 minecraft:stone_bricks
fill 417 34 211 417 37 211 minecraft:mossy_cobblestone
fill 417 34 213 417 34 214 minecraft:mossy_cobblestone
setblock 377 35 184 minecraft:stone_bricks
fill 377 35 185 377 38 185 minecraft:mossy_cobblestone
setblock 377 35 189 minecraft:stone_bricks
fill 377 35 190 377 38 190 minecraft:mossy_cobblestone
setblock 377 35 193 minecraft:mossy_cobblestone
setblock 377 35 194 minecraft:stone_bricks
fill 377 35 195 377 38 195 minecraft:mossy_cobblestone
setblock 377 35 198 minecraft:mossy_cobblestone
fill 377 35 207 377 35 208 minecraft:mossy_cobblestone
setblock 377 35 209 minecraft:stone_bricks
fill 377 35 210 377 35 213 minecraft:mossy_cobblestone
setblock 377 35 214 minecraft:stone_bricks
fill 377 35 215 377 35 218 minecraft:mossy_cobblestone
setblock 378 35 183 minecraft:stone_bricks
fill 378 35 184 378 38 184 minecraft:mossy_cobblestone
setblock 378 35 188 minecraft:stone_bricks
fill 378 35 189 378 38 189 minecraft:mossy_cobblestone
setblock 378 35 193 minecraft:stone_bricks
fill 378 35 194 379 37 194 minecraft:mossy_cobblestone
fill 378 35 196 378 36 196 minecraft:mossy_cobblestone
fill 378 35 210 378 35 212 minecraft:mossy_cobblestone
setblock 378 35 213 minecraft:stone_bricks
fill 378 35 214 378 37 215 minecraft:mossy_cobblestone
setblock 378 35 222 minecraft:mossy_cobblestone
setblock 379 35 182 minecraft:stone_bricks
fill 379 35 183 379 38 183 minecraft:mossy_cobblestone
setblock 379 35 187 minecraft:stone_bricks
fill 379 35 188 379 38 188 minecraft:mossy_cobblestone
setblock 379 35 192 minecraft:stone_bricks
fill 379 35 193 379 38 193 minecraft:mossy_cobblestone
setblock 379 35 222 minecraft:stone_bricks
fill 380 35 182 380 38 182 minecraft:mossy_cobblestone
setblock 380 35 186 minecraft:stone_bricks
fill 380 35 187 380 38 187 minecraft:mossy_cobblestone
setblock 380 35 191 minecraft:stone_bricks
fill 380 35 192 380 38 192 minecraft:mossy_cobblestone
fill 380 35 222 380 38 222 minecraft:mossy_cobblestone
fill 381 35 221 382 37 221 minecraft:mossy_cobblestone
setblock 382 35 184 minecraft:stone_bricks
setblock 383 35 183 minecraft:stone_bricks
fill 383 35 184 383 37 184 minecraft:mossy_cobblestone
setblock 384 35 182 minecraft:stone_bricks
fill 384 35 183 384 38 183 minecraft:mossy_cobblestone
setblock 384 35 222 minecraft:stone_bricks
fill 385 35 182 385 38 182 minecraft:mossy_cobblestone
fill 385 35 189 385 42 189 minecraft:cobbled_deepslate
setblock 385 35 221 minecraft:stone_bricks
fill 385 35 222 385 38 222 minecraft:mossy_cobblestone
fill 386 35 188 386 42 188 minecraft:cobbled_deepslate
fill 386 35 190 386 42 190 minecraft:cobbled_deepslate
fill 387 35 189 387 42 189 minecraft:cobbled_deepslate
setblock 389 35 222 minecraft:stone_bricks
fill 396 35 222 397 36 222 minecraft:mossy_cobblestone
setblock 399 35 222 minecraft:stone_bricks
fill 400 35 182 400 38 182 minecraft:mossy_cobblestone
fill 400 35 222 400 38 222 minecraft:mossy_cobblestone
setblock 404 35 222 minecraft:stone_bricks
setblock 415 35 191 minecraft:stone_bricks
fill 416 35 186 416 35 189 minecraft:mossy_cobblestone
setblock 416 35 190 minecraft:stone_bricks
fill 416 35 191 416 38 191 minecraft:mossy_cobblestone
setblock 416 35 195 minecraft:stone_bricks
fill 416 35 196 416 38 196 minecraft:mossy_cobblestone
setblock 417 35 184 minecraft:stone_bricks
fill 417 35 185 417 38 185 minecraft:mossy_cobblestone
setblock 417 35 189 minecraft:stone_bricks
fill 417 35 190 417 38 190 minecraft:mossy_cobblestone
setblock 417 35 193 minecraft:mossy_cobblestone
setblock 417 35 194 minecraft:stone_bricks
fill 417 35 195 417 38 195 minecraft:mossy_cobblestone
setblock 417 35 198 minecraft:mossy_cobblestone
setblock 417 35 199 minecraft:stone_bricks
fill 417 35 200 417 36 202 minecraft:mossy_cobblestone
setblock 417 35 204 minecraft:stone_bricks
fill 417 35 205 417 38 205 minecraft:mossy_cobblestone
setblock 417 35 209 minecraft:stone_bricks
fill 417 35 210 417 38 210 minecraft:mossy_cobblestone
setblock 417 35 213 minecraft:mossy_cobblestone
setblock 417 35 214 minecraft:stone_bricks
fill 417 35 215 417 37 216 minecraft:mossy_cobblestone
setblock 377 36 183 minecraft:stone_bricks
fill 377 36 184 377 39 184 minecraft:mossy_cobblestone
setblock 377 36 188 minecraft:stone_bricks
fill 377 36 189 377 39 189 minecraft:mossy_cobblestone
setblock 377 36 193 minecraft:stone_bricks
fill 377 36 194 377 39 194 minecraft:mossy_cobblestone
setblock 377 36 198 minecraft:stone_bricks
fill 377 36 199 377 39 199 minecraft:mossy_cobblestone
setblock 377 36 207 minecraft:mossy_cobblestone
setblock 377 36 208 minecraft:stone_bricks
fill 377 36 209 377 36 212 minecraft:mossy_cobblestone
setblock 377 36 213 minecraft:stone_bricks
fill 377 36 214 377 36 217 minecraft:mossy_cobblestone
setblock 377 36 218 minecraft:stone_bricks
fill 377 36 219 377 36 222 minecraft:mossy_cobblestone
setblock 378 36 182 minecraft:stone_bricks
fill 378 36 183 378 39 183 minecraft:mossy_cobblestone
setblock 378 36 187 minecraft:stone_bricks
fill 378 36 188 378 39 188 minecraft:mossy_cobblestone
setblock 378 36 191 minecraft:mossy_cobblestone
setblock 378 36 192 minecraft:stone_bricks
fill 378 36 193 378 39 193 minecraft:mossy_cobblestone
setblock 378 36 197 minecraft:stone_bricks
fill 378 36 209 378 36 211 minecraft:mossy_cobblestone
setblock 378 36 212 minecraft:stone_bricks
fill 378 36 213 379 38 213 minecraft:mossy_cobblestone
setblock 378 36 216 minecraft:mossy_cobblestone
setblock 378 36 217 minecraft:stone_bricks
fill 378 36 218 378 38 219 minecraft:mossy_cobblestone
setblock 378 36 222 minecraft:stone_bricks
fill 379 36 182 379 39 182 minecraft:mossy_cobblestone
setblock 379 36 186 minecraft:stone_bricks
fill 379 36 187 379 39 187 minecraft:mossy_cobblestone
setblock 379 36 191 minecraft:stone_bricks
fill 379 36 192 379 39 192 minecraft:mossy_cobblestone
setblock 379 36 195 minecraft:mossy_cobblestone
fill 379 36 212 379 39 212 minecraft:mossy_cobblestone
fill 379 36 214 379 36 215 minecraft:mossy_cobblestone
setblock 379 36 221 minecraft:stone_bricks
fill 379 36 222 379 39 222 minecraft:mossy_cobblestone
fill 380 36 186 380 37 186 minecraft:mossy_cobblestone
setblock 380 36 190 minecraft:stone_bricks
fill 380 36 191 380 39 191 minecraft:mossy_cobblestone
fill 380 36 193 380 37 193 minecraft:mossy_cobblestone
fill 380 36 221 380 39 221 minecraft:mossy_cobblestone
setblock 381 36 184 minecraft:stone_bricks
setblock 382 36 183 minecraft:stone_bricks
fill 382 36 184 382 38 184 minecraft:mossy_cobblestone
setblock 383 36 182 minecraft:stone_bricks
fill 383 36 183 383 39 183 minecraft:mossy_cobblestone
setblock 383 36 221 minecraft:mossy_cobblestone
setblock 383 36 222 minecraft:stone_bricks
fill 384 36 182 384 39 182 minecraft:mossy_cobblestone
setblock 384 36 221 minecraft:stone_bricks
fill 384 36 222 384 39 222 minecraft:mossy_cobblestone
fill 385 36 188 385 42 188 minecraft:cobbled_deepslate
fill 385 36 190 385 42 190 minecraft:cobbled_deepslate
fill 385 36 221 386 38 221 minecraft:mossy_cobblestone
fill 386 36 182 387 36 182 minecraft:mossy_cobblestone
fill 387 36 188 387 42 188 minecraft:cobbled_deepslate
fill 387 36 190 387 42 190 minecraft:cobbled_deepslate
setblock 388 36 222 minecraft:stone_bricks
fill 389 36 222 389 39 222 minecraft:mossy_cobblestone
fill 394 36 222 395 38 222 minecraft:mossy_cobblestone
setblock 398 36 221 minecraft:mossy_cobblestone
setblock 398 36 222 minecraft:stone_bricks
fill 399 36 182 399 39 182 minecraft:mossy_cobblestone
setblock 399 36 221 minecraft:stone_bricks
fill 399 36 222 399 39 222 minecraft:mossy_cobblestone
fill 400 36 221 402 37 221 minecraft:mossy_cobblestone
setblock 403 36 222 minecraft:stone_bricks
fill 404 36 222 404 39 222 minecraft:mossy_cobblestone
setblock 415 36 189 minecraft:mossy_cobblestone
setblock 415 36 190 minecraft:stone_bricks
fill 415 36 191 415 36 194 minecraft:mossy_cobblestone
fill 416 36 185 416 36 188 minecraft:mossy_cobblestone
setblock 416 36 189 minecraft:stone_bricks
fill 416 36 190 416 39 190 minecraft:mossy_cobblestone
fill 416 36 192 416 36 193 minecraft:mossy_cobblestone
setblock 416 36 194 minecraft:stone_bricks
fill 416 36 195 416 39 195 minecraft:mossy_cobblestone
fill 416 36 197 416 36 198 minecraft:mossy_cobblestone
setblock 416 36 209 minecraft:stone_bricks
fill 416 36 210 416 36 213 minecraft:mossy_cobblestone
setblock 417 36 182 minecraft:mossy_cobblestone
setblock 417 36 183 minecraft:stone_bricks
fill 417 36 184 417 39 184 minecraft:mossy_cobblestone
setblock 417 36 188 minecraft:stone_bricks
fill 417 36 189 417 39 189 minecraft:mossy_cobblestone
setblock 417 36 193 minecraft:stone_bricks
fill 417 36 194 417 39 194 minecraft:mossy_cobblestone
setblock 417 36 198 minecraft:stone_bricks
fill 417 36 199 417 39 199 minecraft:mossy_cobblestone
setblock 417 36 203 minecraft:stone_bricks
fill 417 36 204 417 39 204 minecraft:mossy_cobblestone
setblock 417 36 208 minecraft:stone_bricks
fill 417 36 209 417 39 209 minecraft:mossy_cobblestone
setblock 417 36 213 minecraft:stone_bricks
fill 417 36 214 417 39 214 minecraft:mossy_cobblestone
setblock 417 36 217 minecraft:mossy_cobblestone
setblock 377 37 182 minecraft:stone_bricks
fill 377 37 183 377 40 183 minecraft:mossy_cobblestone
setblock 377 37 187 minecraft:stone_bricks
fill 377 37 188 377 40 188 minecraft:mossy_cobblestone
setblock 377 37 192 minecraft:stone_bricks
fill 377 37 193 377 40 193 minecraft:mossy_cobblestone
setblock 377 37 196 minecraft:mossy_cobblestone
setblock 377 37 197 minecraft:stone_bricks
fill 377 37 198 378 39 198 minecraft:mossy_cobblestone
fill 377 37 200 377 38 200 minecraft:mossy_cobblestone
setblock 377 37 206 minecraft:mossy_cobblestone
setblock 377 37 207 minecraft:stone_bricks
fill 377 37 208 377 37 211 minecraft:mossy_cobblestone
setblock 377 37 212 minecraft:stone_bricks
fill 377 37 213 377 37 216 minecraft:mossy_cobblestone
setblock 377 37 217 minecraft:stone_bricks
fill 377 37 218 377 37 221 minecraft:mossy_cobblestone
setblock 377 37 222 minecraft:stone_bricks
fill 378 37 182 378 40 182 minecraft:mossy_cobblestone
setblock 378 37 186 minecraft:stone_bricks
fill 378 37 187 378 40 187 minecraft:mossy_cobblestone
setblock 378 37 191 minecraft:stone_bricks
fill 378 37 192 378 40 192 minecraft:mossy_cobblestone
setblock 378 37 196 minecraft:stone_bricks
fill 378 37 197 378 40 197 minecraft:mossy_cobblestone
fill 378 37 209 378 37 210 minecraft:mossy_cobblestone
setblock 378 37 211 minecraft:stone_bricks
fill 378 37 212 378 40 212 minecraft:mossy_cobblestone
setblock 378 37 216 minecraft:stone_bricks
fill 378 37 217 379 39 217 minecraft:mossy_cobblestone
setblock 378 37 220 minecraft:mossy_cobblestone
setblock 378 37 221 minecraft:stone_bricks
fill 378 37 222 378 40 222 minecraft:mossy_cobblestone
setblock 379 37 185 minecraft:stone_bricks
fill 379 37 186 379 40 186 minecraft:mossy_cobblestone
setblock 379 37 189 minecraft:mossy_cobblestone
setblock 379 37 190 minecraft:stone_bricks
fill 379 37 191 379 40 191 minecraft:mossy_cobblestone
setblock 379 37 195 minecraft:stone_bricks
fill 379 37 196 379 40 196 minecraft:mossy_cobblestone
fill 379 37 211 379 38 211 minecraft:mossy_cobblestone
setblock 379 37 214 minecraft:mossy_cobblestone
setblock 379 37 215 minecraft:stone_bricks
fill 379 37 216 379 40 216 minecraft:mossy_cobblestone
fill 379 37 218 379 38 218 minecraft:mossy_cobblestone
fill 379 37 221 379 40 221 minecraft:mossy_cobblestone
setblock 380 37 184 minecraft:stone_bricks
setblock 380 37 189 minecraft:stone_bricks
fill 380 37 190 380 39 190 minecraft:mossy_cobblestone
fill 380 37 220 383 37 220 minecraft:mossy_cobblestone
setblock 381 37 183 minecraft:stone_bricks
fill 381 37 184 381 39 184 minecraft:mossy_cobblestone
setblock 382 37 182 minecraft:stone_bricks
fill 382 37 183 382 40 183 minecraft:mossy_cobblestone
setblock 382 37 222 minecraft:stone_bricks
fill 383 37 182 383 40 182 minecraft:mossy_cobblestone
setblock 383 37 221 minecraft:stone_bricks
fill 383 37 222 383 40 222 minecraft:mossy_cobblestone
fill 384 37 189 384 42 189 minecraft:cobbled_deepslate
fill 384 37 221 384 40 221 minecraft:mossy_cobblestone
setblock 386 37 182 minecraft:mossy_cobblestone
fill 386 37 187 386 42 187 minecraft:cobbled_deepslate
fill 386 37 191 387 42 191 minecraft:cobbled_deepslate
setblock 387 37 182 minecraft:stone_bricks
setblock 387 37 222 minecraft:stone_bricks
fill 388 37 189 388 42 190 minecraft:cobbled_deepslate
fill 388 37 222 388 40 222 minecraft:mossy_cobblestone
fill 390 37 222 391 37 222 minecraft:mossy_cobblestone
setblock 392 37 222 minecraft:stone_bricks
fill 393 37 222 393 40 222 minecraft:mossy_cobblestone
fill 396 37 221 396 37 222 minecraft:mossy_cobblestone
setblock 397 37 221 minecraft:mossy_cobblestone
setblock 397 37 222 minecraft:stone_bricks
setblock 398 37 221 minecraft:stone_bricks
fill 398 37 222 398 40 222 minecraft:mossy_cobblestone
fill 399 37 221 399 40 221 minecraft:mossy_cobblestone
setblock 402 37 182 minecraft:stone_bricks
setblock 402 37 222 minecraft:stone_bricks
fill 403 37 222 403 40 222 minecraft:mossy_cobblestone
setblock 415 37 188 minecraft:mossy_cobblestone
setblock 415 37 189 minecraft:stone_bricks
fill 415 37 190 415 37 193 minecraft:mossy_cobblestone
setblock 415 37 194 minecraft:stone_bricks
fill 415 37 195 415 39 196 minecraft:mossy_cobblestone
setblock 416 37 182 minecraft:mossy_cobblestone
fill 416 37 185 416 37 187 minecraft:mossy_cobblestone
setblock 416 37 188 minecraft:stone_bricks
fill 416 37 189 416 40 189 minecraft:mossy_cobblestone
setblock 416 37 192 minecraft:mossy_cobblestone
setblock 416 37 193 minecraft:stone_bricks
fill 416 37 194 416 40 194 minecraft:mossy_cobblestone
setblock 416 37 197 minecraft:mossy_cobblestone
setblock 416 37 198 minecraft:stone_bricks
fill 416 37 199 416 40 199 minecraft:mossy_cobblestone
fill 416 37 209 416 37 212 minecraft:mossy_cobblestone
setblock 416 37 213 minecraft:stone_bricks
fill 416 37 214 416 39 215 minecraft:mossy_cobblestone
setblock 417 37 182 minecraft:stone_bricks
fill 417 37 183 417 40 183 minecraft:mossy_cobblestone
setblock 417 37 187 minecraft:stone_bricks
fill 417 37 188 417 40 188 minecraft:mossy_cobblestone
setblock 417 37 192 minecraft:stone_bricks
fill 417 37 193 417 40 193 minecraft:mossy_cobblestone
setblock 417 37 197 minecraft:stone_bricks
fill 417 37 198 417 40 198 minecraft:mossy_cobblestone
fill 417 37 200 417 37 201 minecraft:mossy_cobblestone
setblock 417 37 202 minecraft:stone_bricks
fill 417 37 203 417 40 203 minecraft:mossy_cobblestone
setblock 417 37 207 minecraft:stone_bricks
fill 417 37 208 417 40 208 minecraft:mossy_cobblestone
setblock 417 37 212 minecraft:stone_bricks
fill 417 37 213 417 40 213 minecraft:mossy_cobblestone
setblock 417 37 217 minecraft:stone_bricks
fill 417 37 218 417 39 219 minecraft:mossy_cobblestone
fill 377 38 182 377 41 182 minecraft:mossy_cobblestone
setblock 377 38 186 minecraft:stone_bricks
fill 377 38 187 377 41 187 minecraft:mossy_cobblestone
setblock 377 38 191 minecraft:stone_bricks
fill 377 38 192 377 41 192 minecraft:mossy_cobblestone
setblock 377 38 196 minecraft:stone_bricks
fill 377 38 197 377 41 197 minecraft:mossy_cobblestone
setblock 377 38 201 minecraft:stone_bricks
setblock 377 38 206 minecraft:stone_bricks
fill 377 38 207 377 38 210 minecraft:mossy_cobblestone
setblock 377 38 211 minecraft:stone_bricks
fill 377 38 212 377 38 215 minecraft:mossy_cobblestone
setblock 377 38 216 minecraft:stone_bricks
fill 377 38 217 377 38 220 minecraft:mossy_cobblestone
setblock 377 38 221 minecraft:stone_bricks
fill 377 38 222 377 41 222 minecraft:mossy_cobblestone
setblock 378 38 185 minecraft:stone_bricks
fill 378 38 186 378 41 186 minecraft:mossy_cobblestone
setblock 378 38 190 minecraft:stone_bricks
fill 378 38 191 378 41 191 minecraft:mossy_cobblestone
setblock 378 38 194 minecraft:mossy_cobblestone
setblock 378 38 195 minecraft:stone_bricks
fill 378 38 196 378 41 196 minecraft:mossy_cobblestone
setblock 378 38 199 minecraft:mossy_cobblestone
setblock 378 38 209 minecraft:mossy_cobblestone
setblock 378 38 210 minecraft:stone_bricks
fill 378 38 211 378 41 211 minecraft:mossy_cobblestone
setblock 378 38 214 minecraft:mossy_cobblestone
setblock 378 38 215 minecraft:stone_bricks
fill 378 38 216 378 41 216 minecraft:mossy_cobblestone
setblock 378 38 220 minecraft:stone_bricks
fill 378 38 221 378 41 221 minecraft:mossy_cobblestone
setblock 379 38 184 minecraft:stone_bricks
fill 379 38 185 379 40 185 minecraft:mossy_cobblestone
setblock 379 38 189 minecraft:stone_bricks
fill 379 38 190 379 41 190 minecraft:mossy_cobblestone
setblock 379 38 194 minecraft:stone_bricks
fill 379 38 195 379 41 195 minecraft:mossy_cobblestone
setblock 379 38 214 minecraft:stone_bricks
fill 379 38 215 380 40 215 minecraft:mossy_cobblestone
setblock 379 38 219 minecraft:stone_bricks
fill 379 38 220 382 38 220 minecraft:mossy_cobblestone
setblock 380 38 183 minecraft:stone_bricks
fill 380 38 184 380 39 184 minecraft:mossy_cobblestone
setblock 380 38 188 minecraft:stone_bricks
fill 380 38 189 380 39 189 minecraft:mossy_cobblestone
setblock 380 38 193 minecraft:stone_bricks
setblock 380 38 194 minecraft:mossy_cobblestone
fill 380 38 216 380 39 216 minecraft:mossy_cobblestone
setblock 381 38 182 minecraft:stone_bricks
fill 381 38 183 381 41 183 minecraft:mossy_cobblestone
setblock 381 38 221 minecraft:mossy_cobblestone
setblock 381 38 222 minecraft:stone_bricks
fill 382 38 182 382 41 182 minecraft:mossy_cobblestone
setblock 382 38 221 minecraft:stone_bricks
fill 382 38 222 382 41 222 minecraft:mossy_cobblestone
setblock 383 38 220 minecraft:stone_bricks
fill 383 38 221 383 41 221 minecraft:mossy_cobblestone
fill 384 38 188 384 42 188 minecraft:cobbled_deepslate
fill 384 38 190 384 42 190 minecraft:cobbled_deepslate
fill 384 38 220 384 41 220 minecraft:mossy_cobblestone
fill 385 38 187 385 42 187 minecraft:cobbled_deepslate
fill 385 38 191 385 42 191 minecraft:cobbled_deepslate
setblock 386 38 182 minecraft:stone_bricks
setblock 386 38 222 minecraft:stone_bricks
fill 387 38 187 387 42 187 minecraft:cobbled_deepslate
setblock 387 38 221 minecraft:stone_bricks
fill 387 38 222 387 41 222 minecraft:mossy_cobblestone
fill 388 38 188 388 42 188 minecraft:cobbled_deepslate
setblock 390 38 222 minecraft:mossy_cobblestone
setblock 391 38 222 minecraft:stone_bricks
fill 392 38 222 392 41 222 minecraft:mossy_cobblestone
fill 394 38 221 396 38 221 minecraft:mossy_cobblestone
setblock 396 38 222 minecraft:stone_bricks
setblock 397 38 220 minecraft:mossy_cobblestone
setblock 397 38 221 minecraft:stone_bricks
fill 397 38 222 397 41 222 minecraft:mossy_cobblestone
fill 398 38 182 398 39 182 minecraft:mossy_cobblestone
setblock 398 38 220 minecraft:stone_bricks
fill 398 38 221 398 41 221 minecraft:mossy_cobblestone
fill 399 38 220 400 40 220 minecraft:mossy_cobblestone
fill 400 38 221 401 38 221 minecraft:mossy_cobblestone
setblock 401 38 182 minecraft:stone_bricks
setblock 401 38 222 minecraft:stone_bricks
setblock 402 38 221 minecraft:stone_bricks
fill 402 38 222 402 41 222 minecraft:mossy_cobblestone
setblock 415 38 188 minecraft:stone_bricks
fill 415 38 189 415 38 192 minecraft:mossy_cobblestone
setblock 415 38 193 minecraft:stone_bricks
fill 415 38 194 415 41 194 minecraft:mossy_cobblestone
setblock 415 38 197 minecraft:mossy_cobblestone
setblock 416 38 182 minecraft:stone_bricks
fill 416 38 185 416 38 186 minecraft:mossy_cobblestone
setblock 416 38 187 minecraft:stone_bricks
fill 416 38 188 416 41 188 minecraft:mossy_cobblestone
setblock 416 38 192 minecraft:stone_bricks
fill 416 38 193 416 41 193 minecraft:mossy_cobblestone
setblock 416 38 197 minecraft:stone_bricks
fill 416 38 198 416 41 198 minecraft:mossy_cobblestone
fill 416 38 200 417 38 200 minecraft:mossy_cobblestone
fill 416 38 210 416 38 211 minecraft:mossy_cobblestone
setblock 416 38 212 minecraft:stone_bricks
fill 416 38 213 416 41 213 minecraft:mossy_cobblestone
setblock 416 38 216 minecraft:mossy_cobblestone
fill 417 38 182 417 41 182 minecraft:mossy_cobblestone
setblock 417 38 186 minecraft:stone_bricks
fill 417 38 187 417 41 187 minecraft:mossy_cobblestone
setblock 417 38 191 minecraft:stone_bricks
fill 417 38 192 417 41 192 minecraft:mossy_cobblestone
setblock 417 38 196 minecraft:stone_bricks
fill 417 38 197 417 41 197 minecraft:mossy_cobblestone
setblock 417 38 201 minecraft:stone_bricks
fill 417 38 202 417 41 202 minecraft:mossy_cobblestone
setblock 417 38 206 minecraft:stone_bricks
fill 417 38 207 417 41 207 minecraft:mossy_cobblestone
setblock 417 38 211 minecraft:stone_bricks
fill 417 38 212 417 41 212 minecraft:mossy_cobblestone
setblock 417 38 215 minecraft:mossy_cobblestone
setblock 417 38 216 minecraft:stone_bricks
fill 417 38 217 417 41 217 minecraft:mossy_cobblestone
setblock 417 38 220 minecraft:mossy_cobblestone
setblock 417 38 221 minecraft:stone_bricks
fill 417 38 222 417 41 222 minecraft:mossy_cobblestone
setblock 377 39 185 minecraft:stone_bricks
fill 377 39 186 377 42 186 minecraft:mossy_cobblestone
setblock 377 39 190 minecraft:stone_bricks
fill 377 39 191 377 42 191 minecraft:mossy_cobblestone
setblock 377 39 195 minecraft:stone_bricks
fill 377 39 196 377 42 196 minecraft:mossy_cobblestone
setblock 377 39 200 minecraft:stone_bricks
fill 377 39 201 377 41 202 minecraft:mossy_cobblestone
fill 377 39 207 377 39 209 minecraft:mossy_cobblestone
setblock 377 39 210 minecraft:stone_bricks
fill 377 39 211 377 39 214 minecraft:mossy_cobblestone
setblock 377 39 215 minecraft:stone_bricks
fill 377 39 216 377 39 219 minecraft:mossy_cobblestone
setblock 377 39 220 minecraft:stone_bricks
fill 377 39 221 377 42 221 minecraft:mossy_cobblestone
setblock 378 39 184 minecraft:stone_bricks
fill 378 39 185 378 42 185 minecraft:mossy_cobblestone
setblock 378 39 189 minecraft:stone_bricks
fill 378 39 190 378 42 190 minecraft:mossy_cobblestone
setblock 378 39 194 minecraft:stone_bricks
fill 378 39 195 378 42 195 minecraft:mossy_cobblestone
setblock 378 39 199 minecraft:stone_bricks
setblock 378 39 209 minecraft:stone_bricks
fill 378 39 210 378 40 210 minecraft:mossy_cobblestone
setblock 378 39 213 minecraft:mossy_cobblestone
setblock 378 39 214 minecraft:stone_bricks
fill 378 39 215 378 42 215 minecraft:mossy_cobblestone
setblock 378 39 218 minecraft:mossy_cobblestone
setblock 378 39 219 minecraft:stone_bricks
fill 378 39 220 381 39 220 minecraft:mossy_cobblestone
setblock 379 39 183 minecraft:stone_bricks
fill 379 39 184 379 40 184 minecraft:mossy_cobblestone
setblock 379 39 188 minecraft:stone_bricks
fill 379 39 189 379 41 189 minecraft:mossy_cobblestone
setblock 379 39 193 minecraft:stone_bricks
fill 379 39 194 379 42 194 minecraft:mossy_cobblestone
setblock 379 39 197 minecraft:mossy_cobblestone
setblock 379 39 213 minecraft:stone_bricks
fill 379 39 214 379 42 214 minecraft:mossy_cobblestone
setblock 379 39 218 minecraft:stone_bricks
fill 379 39 219 379 42 219 minecraft:mossy_cobblestone
setblock 380 39 182 minecraft:stone_bricks
fill 380 39 183 380 42 183 minecraft:mossy_cobblestone
setblock 380 39 192 minecraft:stone_bricks
setblock 380 39 193 minecraft:mossy_cobblestone
setblock 380 39 217 minecraft:stone_bricks
fill 380 39 218 380 41 218 minecraft:mossy_cobblestone
setblock 380 39 222 minecraft:stone_bricks
fill 381 39 182 381 42 182 minecraft:mossy_cobblestone
setblock 381 39 221 minecraft:stone_bricks
fill 381 39 222 381 42 222 minecraft:mossy_cobblestone
setblock 382 39 220 minecraft:stone_bricks
fill 382 39 221 382 42 221 minecraft:mossy_cobblestone
fill 383 39 220 383 42 220 minecraft:mossy_cobblestone
fill 384 39 187 384 42 187 minecraft:cobbled_deepslate
fill 384 39 191 384 42 191 minecraft:cobbled_deepslate
setblock 385 39 182 minecraft:stone_bricks
fill 385 39 192 387 42 192 minecraft:cobbled_deepslate
setblock 385 39 221 minecraft:mossy_cobblestone
setblock 385 39 222 minecraft:stone_bricks
setblock 386 39 182 minecraft:mossy_cobblestone
setblock 386 39 221 minecraft:stone_bricks
fill 386 39 222 386 42 222 minecraft:mossy_cobblestone
fill 387 39 221 387 41 221 minecraft:mossy_cobblestone
fill 388 39 187 388 42 187 minecraft:cobbled_deepslate
fill 388 39 191 388 42 191 minecraft:cobbled_deepslate
fill 389 39 188 389 42 190 minecraft:cobbled_deepslate
setblock 390 39 222 minecraft:stone_bricks
fill 391 39 222 391 42 222 minecraft:mossy_cobblestone
fill 393 39 221 395 39 221 minecraft:mossy_cobblestone
setblock 394 39 222 minecraft:mossy_cobblestone
setblock 395 39 222 minecraft:stone_bricks
setblock 396 39 220 minecraft:mossy_cobblestone
setblock 396 39 221 minecraft:stone_bricks
fill 396 39 222 396 42 222 minecraft:mossy_cobblestone
setblock 397 39 220 minecraft:stone_bricks
fill 397 39 221 397 42 221 minecraft:mossy_cobblestone
fill 398 39 220 398 42 220 minecraft:mossy_cobblestone
setblock 400 39 182 minecraft:stone_bricks
setblock 400 39 221 minecraft:mossy_cobblestone
setblock 400 39 222 minecraft:stone_bricks
setblock 401 39 220 minecraft:mossy_cobblestone
setblock 401 39 221 minecraft:stone_bricks
fill 401 39 222 401 42 222 minecraft:mossy_cobblestone
fill 402 39 221 402 40 221 minecraft:mossy_cobblestone
setblock 414 39 193 minecraft:stone_bricks
setblock 415 39 182 minecraft:stone_bricks
fill 415 39 188 415 39 191 minecraft:mossy_cobblestone
setblock 415 39 192 minecraft:stone_bricks
fill 415 39 193 415 42 193 minecraft:mossy_cobblestone
setblock 415 39 197 minecraft:stone_bricks
fill 415 39 198 415 42 198 minecraft:mossy_cobblestone
fill 416 39 182 416 42 182 minecraft:mossy_cobblestone
fill 416 39 184 416 39 185 minecraft:mossy_cobblestone
setblock 416 39 186 minecraft:stone_bricks
fill 416 39 187 416 42 187 minecraft:mossy_cobblestone
setblock 416 39 191 minecraft:stone_bricks
fill 416 39 192 416 42 192 minecraft:mossy_cobblestone
setblock 416 39 196 minecraft:stone_bricks
fill 416 39 197 416 42 197 minecraft:mossy_cobblestone
setblock 416 39 200 minecraft:mossy_cobblestone
setblock 416 39 201 minecraft:stone_bricks
setblock 416 39 210 minecraft:mossy_cobblestone
setblock 416 39 211 minecraft:stone_bricks
fill 416 39 212 416 40 212 minecraft:mossy_cobblestone
setblock 416 39 216 minecraft:stone_bricks
fill 416 39 217 416 41 218 minecraft:mossy_cobblestone
fill 416 39 222 416 42 222 minecraft:mossy_cobblestone
setblock 417 39 185 minecraft:stone_bricks
fill 417 39 186 417 42 186 minecraft:mossy_cobblestone
setblock 417 39 190 minecraft:stone_bricks
fill 417 39 191 417 42 191 minecraft:mossy_cobblestone
setblock 417 39 195 minecraft:stone_bricks
fill 417 39 196 417 42 196 minecraft:mossy_cobblestone
setblock 417 39 200 minecraft:stone_bricks
fill 417 39 201 417 42 201 minecraft:mossy_cobblestone
setblock 417 39 205 minecraft:stone_bricks
fill 417 39 206 417 41 206 minecraft:mossy_cobblestone
setblock 417 39 210 minecraft:stone_bricks
fill 417 39 211 417 42 211 minecraft:mossy_cobblestone
setblock 417 39 215 minecraft:stone_bricks
fill 417 39 216 417 42 216 minecraft:mossy_cobblestone
setblock 417 39 220 minecraft:stone_bricks
fill 417 39 221 417 42 221 minecraft:mossy_cobblestone
setblock 377 40 184 minecraft:stone_bricks
fill 377 40 185 377 43 185 minecraft:mossy_cobblestone
setblock 377 40 189 minecraft:stone_bricks
fill 377 40 190 377 43 190 minecraft:mossy_cobblestone
setblock 377 40 194 minecraft:stone_bricks
fill 377 40 195 377 43 195 minecraft:mossy_cobblestone
setblock 377 40 198 minecraft:mossy_cobblestone
setblock 377 40 199 minecraft:stone_bricks
fill 377 40 200 377 43 200 minecraft:mossy_cobblestone
setblock 377 40 208 minecraft:mossy_cobblestone
setblock 377 40 209 minecraft:stone_bricks
fill 377 40 210 377 40 213 minecraft:mossy_cobblestone
setblock 377 40 214 minecraft:stone_bricks
fill 377 40 215 377 40 218 minecraft:mossy_cobblestone
setblock 377 40 219 minecraft:stone_bricks
fill 377 40 220 380 40 220 minecraft:mossy_cobblestone
setblock 378 40 183 minecraft:stone_bricks
fill 378 40 184 378 43 184 minecraft:mossy_cobblestone
setblock 378 40 188 minecraft:stone_bricks
fill 378 40 189 378 43 189 minecraft:mossy_cobblestone
setblock 378 40 193 minecraft:stone_bricks
fill 378 40 194 378 43 194 minecraft:mossy_cobblestone
setblock 378 40 198 minecraft:stone_bricks
fill 378 40 199 378 43 199 minecraft:mossy_cobblestone
setblock 378 40 213 minecraft:stone_bricks
fill 378 40 214 378 43 214 minecraft:mossy_cobblestone
setblock 378 40 217 minecraft:mossy_cobblestone
setblock 378 40 218 minecraft:stone_bricks
fill 378 40 219 378 43 219 minecraft:mossy_cobblestone
setblock 379 40 182 minecraft:stone_bricks
fill 379 40 183 379 43 183 minecraft:mossy_cobblestone
setblock 379 40 187 minecraft:stone_bricks
fill 379 40 188 379 41 188 minecraft:mossy_cobblestone
setblock 379 40 192 minecraft:stone_bricks
fill 379 40 193 379 42 193 minecraft:mossy_cobblestone
setblock 379 40 197 minecraft:stone_bricks
setblock 379 40 212 minecraft:stone_bricks
fill 379 40 213 379 41 213 minecraft:mossy_cobblestone
setblock 379 40 217 minecraft:stone_bricks
fill 379 40 218 379 43 218 minecraft:mossy_cobblestone
setblock 379 40 222 minecraft:stone_bricks
fill 380 40 182 380 43 182 minecraft:mossy_cobblestone
setblock 380 40 216 minecraft:stone_bricks
fill 380 40 217 380 41 217 minecraft:mossy_cobblestone
fill 380 40 219 380 41 219 minecraft:mossy_cobblestone
setblock 380 40 221 minecraft:stone_bricks
fill 380 40 222 380 43 222 minecraft:mossy_cobblestone
setblock 381 40 220 minecraft:stone_bricks
fill 381 40 221 381 43 221 minecraft:mossy_cobblestone
fill 382 40 220 382 43 220 minecraft:mossy_cobblestone
fill 383 40 188 383 42 190 minecraft:cobbled_deepslate
setblock 384 40 182 minecraft:stone_bricks
fill 384 40 192 384 42 192 minecraft:cobbled_deepslate
setblock 384 40 222 minecraft:stone_bricks
setblock 385 40 182 minecraft:mossy_cobblestone
fill 385 40 186 387 42 186 minecraft:cobbled_deepslate
setblock 385 40 221 minecraft:stone_bricks
fill 385 40 222 385 43 222 minecraft:mossy_cobblestone
fill 386 40 221 386 42 221 minecraft:mossy_cobblestone
fill 388 40 192 388 42 192 minecraft:cobbled_deepslate
fill 389 40 187 389 42 187 minecraft:cobbled_deepslate
fill 389 40 191 389 42 191 minecraft:cobbled_deepslate
setblock 389 40 222 minecraft:stone_bricks
fill 390 40 222 390 43 222 minecraft:mossy_cobblestone
fill 392 40 221 394 40 221 minecraft:mossy_cobblestone
setblock 394 40 222 minecraft:stone_bricks
setblock 395 40 220 minecraft:mossy_cobblestone
setblock 395 40 221 minecraft:stone_bricks
fill 395 40 222 395 43 222 minecraft:mossy_cobblestone
setblock 396 40 220 minecraft:stone_bricks
fill 396 40 221 396 43 221 minecraft:mossy_cobblestone
fill 397 40 220 397 43 220 minecraft:mossy_cobblestone
setblock 399 40 222 minecraft:stone_bricks
setblock 400 40 221 minecraft:stone_bricks
fill 400 40 222 400 43 222 minecraft:mossy_cobblestone
fill 401 40 221 401 42 221 minecraft:mossy_cobblestone
fill 414 40 193 414 40 194 minecraft:mossy_cobblestone
fill 415 40 182 415 43 182 minecraft:mossy_cobblestone
fill 415 40 188 415 40 190 minecraft:mossy_cobblestone
setblock 415 40 191 minecraft:stone_bricks
fill 415 40 192 415 43 192 minecraft:mossy_cobblestone
setblock 415 40 195 minecraft:mossy_cobblestone
setblock 415 40 196 minecraft:stone_bricks
fill 415 40 197 415 43 197 minecraft:mossy_cobblestone
setblock 416 40 184 minecraft:mossy_cobblestone
setblock 416 40 185 minecraft:stone_bricks
fill 416 40 186 416 43 186 minecraft:mossy_cobblestone
setblock 416 40 190 minecraft:stone_bricks
fill 416 40 191 416 43 191 minecraft:mossy_cobblestone
setblock 416 40 195 minecraft:stone_bricks
fill 416 40 196 416 43 196 minecraft:mossy_cobblestone
setblock 416 40 200 minecraft:stone_bricks
fill 416 40 201 416 43 201 minecraft:mossy_cobblestone
setblock 416 40 214 minecraft:mossy_cobblestone
setblock 416 40 215 minecraft:stone_bricks
fill 416 40 216 416 43 216 minecraft:mossy_cobblestone
setblock 416 40 219 minecraft:mossy_cobblestone
setblock 417 40 184 minecraft:stone_bricks
fill 417 40 185 417 43 185 minecraft:mossy_cobblestone
setblock 417 40 189 minecraft:stone_bricks
fill 417 40 190 417 43 190 minecraft:mossy_cobblestone
setblock 417 40 194 minecraft:stone_bricks
fill 417 40 195 417 43 195 minecraft:mossy_cobblestone
setblock 417 40 199 minecraft:stone_bricks
fill 417 40 200 417 43 200 minecraft:mossy_cobblestone
setblock 417 40 204 minecraft:stone_bricks
fill 417 40 205 417 41 205 minecraft:mossy_cobblestone
setblock 417 40 209 minecraft:stone_bricks
fill 417 40 210 417 42 210 minecraft:mossy_cobblestone
setblock 417 40 214 minecraft:stone_bricks
fill 417 40 215 417 43 215 minecraft:mossy_cobblestone
setblock 417 40 218 minecraft:mossy_cobblestone
setblock 417 40 219 minecraft:stone_bricks
fill 417 40 220 417 43 220 minecraft:mossy_cobblestone
setblock 377 41 183 minecraft:stone_bricks
fill 377 41 184 377 43 184 minecraft:mossy_cobblestone
setblock 377 41 188 minecraft:stone_bricks
fill 377 41 189 377 43 189 minecraft:mossy_cobblestone
setblock 377 41 193 minecraft:stone_bricks
fill 377 41 194 377 43 194 minecraft:mossy_cobblestone
setblock 377 41 198 minecraft:stone_bricks
fill 377 41 199 377 43 199 minecraft:mossy_cobblestone
fill 377 41 209 377 41 212 minecraft:mossy_cobblestone
setblock 377 41 213 minecraft:stone_bricks
fill 377 41 214 377 41 217 minecraft:mossy_cobblestone
setblock 377 41 218 minecraft:stone_bricks
fill 377 41 219 377 43 220 minecraft:mossy_cobblestone
setblock 378 41 182 minecraft:stone_bricks
fill 378 41 183 378 43 183 minecraft:mossy_cobblestone
setblock 378 41 187 minecraft:stone_bricks
fill 378 41 188 378 43 188 minecraft:mossy_cobblestone
setblock 378 41 192 minecraft:stone_bricks
fill 378 41 193 378 43 193 minecraft:mossy_cobblestone
setblock 378 41 197 minecraft:stone_bricks
fill 378 41 198 378 43 198 minecraft:mossy_cobblestone
setblock 378 41 212 minecraft:stone_bricks
fill 378 41 213 378 43 213 minecraft:mossy_cobblestone
setblock 378 41 217 minecraft:stone_bricks
fill 378 41 218 378 43 218 minecraft:mossy_cobblestone
fill 378 41 220 379 41 220 minecraft:mossy_cobblestone
setblock 378 41 222 minecraft:stone_bricks
fill 379 41 182 379 43 182 minecraft:mossy_cobblestone
setblock 379 41 184 minecraft:light[level=12]
setblock 379 41 191 minecraft:stone_bricks
fill 379 41 192 379 42 192 minecraft:mossy_cobblestone
setblock 379 41 196 minecraft:stone_bricks
setblock 379 41 200 minecraft:light[level=12]
setblock 379 41 208 minecraft:light[level=12]
setblock 379 41 215 minecraft:mossy_cobblestone
setblock 379 41 216 minecraft:stone_bricks
fill 379 41 217 379 43 217 minecraft:mossy_cobblestone
setblock 379 41 221 minecraft:stone_bricks
fill 379 41 222 379 43 222 minecraft:mossy_cobblestone
setblock 380 41 220 minecraft:stone_bricks
fill 380 41 221 380 43 221 minecraft:mossy_cobblestone
fill 381 41 220 381 43 220 minecraft:mossy_cobblestone
setblock 383 41 182 minecraft:stone_bricks
fill 383 41 187 383 42 187 minecraft:cobbled_deepslate
fill 383 41 191 383 42 191 minecraft:cobbled_deepslate
setblock 383 41 222 minecraft:stone_bricks
setblock 384 41 182 minecraft:mossy_cobblestone
fill 384 41 186 384 42 186 minecraft:cobbled_deepslate
setblock 384 41 221 minecraft:stone_bricks
fill 384 41 222 384 43 222 minecraft:mossy_cobblestone
fill 385 41 193 387 42 193 minecraft:cobbled_deepslate
fill 385 41 221 385 43 221 minecraft:mossy_cobblestone
setblock 387 41 184 minecraft:light[level=12]
setblock 387 41 200 minecraft:light[level=12]
setblock 387 41 208 minecraft:light[level=12]
setblock 387 41 216 minecraft:light[level=12]
fill 388 41 186 388 42 186 minecraft:cobbled_deepslate
setblock 388 41 222 minecraft:stone_bricks
fill 389 41 192 389 42 192 minecraft:cobbled_deepslate
fill 389 41 222 389 43 222 minecraft:mossy_cobblestone
fill 390 41 188 390 42 190 minecraft:cobbled_deepslate
fill 391 41 221 393 41 221 minecraft:mossy_cobblestone
setblock 393 41 222 minecraft:stone_bricks
setblock 394 41 220 minecraft:mossy_cobblestone
setblock 394 41 221 minecraft:stone_bricks
fill 394 41 222 394 43 222 minecraft:mossy_cobblestone
setblock 395 41 184 minecraft:light[level=12]
setblock 395 41 192 minecraft:light[level=12]
setblock 395 41 200 minecraft:light[level=12]
setblock 395 41 208 minecraft:light[level=12]
setblock 395 41 216 minecraft:light[level=12]
setblock 395 41 220 minecraft:stone_bricks
fill 395 41 221 395 43 221 minecraft:mossy_cobblestone
fill 396 41 220 396 43 220 minecraft:mossy_cobblestone
setblock 398 41 222 minecraft:stone_bricks
setblock 399 41 220 minecraft:mossy_cobblestone
setblock 399 41 221 minecraft:stone_bricks
fill 399 41 222 399 43 222 minecraft:mossy_cobblestone
setblock 400 41 220 minecraft:stone_bricks
fill 400 41 221 400 43 221 minecraft:mossy_cobblestone
setblock 403 41 184 minecraft:light[level=12]
setblock 403 41 192 minecraft:light[level=12]
setblock 403 41 200 minecraft:light[level=12]
setblock 403 41 208 minecraft:light[level=12]
setblock 403 41 216 minecraft:light[level=12]
setblock 403 41 222 minecraft:stone_bricks
setblock 411 41 184 minecraft:light[level=12]
setblock 411 41 192 minecraft:light[level=12]
setblock 411 41 200 minecraft:light[level=12]
setblock 411 41 208 minecraft:light[level=12]
setblock 411 41 216 minecraft:light[level=12]
fill 414 41 182 414 43 182 minecraft:mossy_cobblestone
setblock 414 41 194 minecraft:mossy_cobblestone
setblock 415 41 189 minecraft:mossy_cobblestone
setblock 415 41 190 minecraft:stone_bricks
fill 415 41 191 415 43 191 minecraft:mossy_cobblestone
setblock 415 41 195 minecraft:stone_bricks
fill 415 41 196 415 43 196 minecraft:mossy_cobblestone
setblock 415 41 199 minecraft:mossy_cobblestone
fill 415 41 222 415 43 222 minecraft:mossy_cobblestone
setblock 416 41 184 minecraft:stone_bricks
fill 416 41 185 416 43 185 minecraft:mossy_cobblestone
setblock 416 41 189 minecraft:stone_bricks
fill 416 41 190 416 43 190 minecraft:mossy_cobblestone
setblock 416 41 194 minecraft:stone_bricks
fill 416 41 195 416 43 195 minecraft:mossy_cobblestone
setblock 416 41 199 minecraft:stone_bricks
fill 416 41 200 416 43 200 minecraft:mossy_cobblestone
setblock 416 41 214 minecraft:stone_bricks
fill 416 41 215 416 43 215 minecraft:mossy_cobblestone
setblock 416 41 219 minecraft:stone_bricks
fill 416 41 220 416 43 220 minecraft:mossy_cobblestone
setblock 417 41 183 minecraft:stone_bricks
fill 417 41 184 417 43 184 minecraft:mossy_cobblestone
setblock 417 41 188 minecraft:stone_bricks
fill 417 41 189 417 43 189 minecraft:mossy_cobblestone
setblock 417 41 193 minecraft:stone_bricks
fill 417 41 194 417 43 194 minecraft:mossy_cobblestone
setblock 417 41 198 minecraft:stone_bricks
fill 417 41 199 417 43 199 minecraft:mossy_cobblestone
setblock 417 41 203 minecraft:stone_bricks
fill 417 41 204 417 43 204 minecraft:mossy_cobblestone
setblock 417 41 208 minecraft:stone_bricks
setblock 417 41 209 minecraft:mossy_cobblestone
setblock 417 41 213 minecraft:stone_bricks
fill 417 41 214 417 43 214 minecraft:mossy_cobblestone
setblock 417 41 218 minecraft:stone_bricks
fill 417 41 219 417 43 219 minecraft:mossy_cobblestone
setblock 377 42 182 minecraft:stone_bricks
fill 377 42 183 377 43 183 minecraft:mossy_cobblestone
setblock 377 42 187 minecraft:stone_bricks
fill 377 42 188 377 43 188 minecraft:mossy_cobblestone
setblock 377 42 192 minecraft:stone_bricks
fill 377 42 193 377 43 193 minecraft:mossy_cobblestone
setblock 377 42 197 minecraft:stone_bricks
fill 377 42 198 377 43 198 minecraft:mossy_cobblestone
setblock 377 42 201 minecraft:mossy_cobblestone
setblock 377 42 202 minecraft:stone_bricks
fill 377 42 210 377 42 211 minecraft:mossy_cobblestone
setblock 377 42 212 minecraft:stone_bricks
fill 377 42 213 377 42 216 minecraft:mossy_cobblestone
setblock 377 42 217 minecraft:stone_bricks
fill 377 42 218 377 43 218 minecraft:mossy_cobblestone
setblock 377 42 222 minecraft:stone_bricks
fill 378 42 182 378 43 182 minecraft:mossy_cobblestone
setblock 378 42 186 minecraft:stone_bricks
fill 378 42 187 378 43 187 minecraft:mossy_cobblestone
setblock 378 42 191 minecraft:stone_bricks
fill 378 42 192 378 43 192 minecraft:mossy_cobblestone
setblock 378 42 196 minecraft:stone_bricks
fill 378 42 197 378 43 197 minecraft:mossy_cobblestone
setblock 378 42 212 minecraft:mossy_cobblestone
setblock 378 42 216 minecraft:stone_bricks
fill 378 42 217 378 43 217 minecraft:mossy_cobblestone
setblock 378 42 220 minecraft:mossy_cobblestone
setblock 378 42 221 minecraft:stone_bricks
fill 378 42 222 378 43 222 minecraft:mossy_cobblestone
setblock 379 42 195 minecraft:stone_bricks
setblock 379 42 215 minecraft:stone_bricks
fill 379 42 216 379 43 216 minecraft:mossy_cobblestone
setblock 379 42 220 minecraft:stone_bricks
fill 379 42 221 379 43 221 minecraft:mossy_cobblestone
fill 380 42 220 380 43 220 minecraft:mossy_cobblestone
setblock 382 42 182 minecraft:stone_bricks
fill 382 42 188 382 42 191 minecraft:cobbled_deepslate
setblock 382 42 222 minecraft:stone_bricks
setblock 383 42 182 minecraft:mossy_cobblestone
setblock 383 42 186 minecraft:cobbled_deepslate
setblock 383 42 192 minecraft:cobbled_deepslate
setblock 383 42 221 minecraft:stone_bricks
fill 383 42 222 383 43 222 minecraft:mossy_cobblestone
setblock 384 42 193 minecraft:cobbled_deepslate
fill 384 42 221 384 43 221 minecraft:mossy_cobblestone
fill 385 42 185 388 42 185 minecraft:cobbled_deepslate
setblock 387 42 222 minecraft:stone_bricks
setblock 388 42 193 minecraft:cobbled_deepslate
fill 388 42 222 388 43 222 minecraft:mossy_cobblestone
setblock 389 42 186 minecraft:cobbled_deepslate
setblock 390 42 187 minecraft:cobbled_deepslate
setblock 390 42 191 minecraft:cobbled_deepslate
fill 391 42 221 392 42 221 minecraft:mossy_cobblestone
setblock 392 42 222 minecraft:stone_bricks
setblock 393 42 221 minecraft:stone_bricks
fill 393 42 222 393 43 222 minecraft:mossy_cobblestone
setblock 394 42 220 minecraft:stone_bricks
fill 394 42 221 394 43 221 minecraft:mossy_cobblestone
fill 395 42 220 395 43 220 minecraft:mossy_cobblestone
setblock 397 42 222 minecraft:stone_bricks
setblock 398 42 221 minecraft:stone_bricks
fill 398 42 222 398 43 222 minecraft:mossy_cobblestone
setblock 399 42 220 minecraft:stone_bricks
fill 399 42 221 399 43 221 minecraft:mossy_cobblestone
setblock 402 42 222 minecraft:stone_bricks
fill 414 42 222 414 43 222 minecraft:mossy_cobblestone
fill 415 42 190 415 43 190 minecraft:mossy_cobblestone
setblock 415 42 194 minecraft:stone_bricks
fill 415 42 195 415 43 195 minecraft:mossy_cobblestone
setblock 415 42 199 minecraft:stone_bricks
setblock 416 42 183 minecraft:stone_bricks
fill 416 42 184 416 43 184 minecraft:mossy_cobblestone
setblock 416 42 188 minecraft:stone_bricks
fill 416 42 189 416 43 189 minecraft:mossy_cobblestone
setblock 416 42 193 minecraft:stone_bricks
fill 416 42 194 416 43 194 minecraft:mossy_cobblestone
setblock 416 42 198 minecraft:stone_bricks
fill 416 42 199 416 43 199 minecraft:mossy_cobblestone
setblock 416 42 214 minecraft:mossy_cobblestone
setblock 416 42 217 minecraft:mossy_cobblestone
setblock 416 42 218 minecraft:stone_bricks
fill 416 42 219 416 43 219 minecraft:mossy_cobblestone
fill 416 42 221 416 43 221 minecraft:mossy_cobblestone
setblock 417 42 182 minecraft:stone_bricks
fill 417 42 183 417 43 183 minecraft:mossy_cobblestone
setblock 417 42 187 minecraft:stone_bricks
fill 417 42 188 417 43 188 minecraft:mossy_cobblestone
setblock 417 42 192 minecraft:stone_bricks
fill 417 42 193 417 43 193 minecraft:mossy_cobblestone
setblock 417 42 197 minecraft:stone_bricks
fill 417 42 198 417 43 198 minecraft:mossy_cobblestone
setblock 417 42 202 minecraft:stone_bricks
fill 417 42 203 417 43 203 minecraft:mossy_cobblestone
setblock 417 42 212 minecraft:stone_bricks
fill 417 42 213 417 43 213 minecraft:mossy_cobblestone
setblock 417 42 217 minecraft:stone_bricks
fill 417 42 218 417 43 218 minecraft:mossy_cobblestone
setblock 417 42 222 minecraft:stone_bricks
setblock 377 43 182 minecraft:mossy_cobblestone
setblock 377 43 186 minecraft:stone_bricks
setblock 377 43 187 minecraft:mossy_cobblestone
setblock 377 43 191 minecraft:stone_bricks
setblock 377 43 192 minecraft:mossy_cobblestone
setblock 377 43 196 minecraft:stone_bricks
setblock 377 43 197 minecraft:mossy_cobblestone
setblock 377 43 201 minecraft:stone_bricks
setblock 377 43 202 minecraft:mossy_cobblestone
setblock 377 43 211 minecraft:stone_bricks
fill 377 43 212 377 43 215 minecraft:mossy_cobblestone
setblock 377 43 216 minecraft:stone_bricks
setblock 377 43 217 minecraft:mossy_cobblestone
setblock 377 43 221 minecraft:stone_bricks
setblock 377 43 222 minecraft:mossy_cobblestone
setblock 378 43 185 minecraft:stone_bricks
setblock 378 43 186 minecraft:mossy_cobblestone
setblock 378 43 190 minecraft:stone_bricks
setblock 378 43 191 minecraft:mossy_cobblestone
setblock 378 43 195 minecraft:stone_bricks
setblock 378 43 196 minecraft:mossy_cobblestone
setblock 378 43 215 minecraft:stone_bricks
setblock 378 43 216 minecraft:mossy_cobblestone
setblock 378 43 220 minecraft:stone_bricks
setblock 378 43 221 minecraft:mossy_cobblestone
setblock 379 43 215 minecraft:mossy_cobblestone
setblock 379 43 219 minecraft:stone_bricks
setblock 379 43 220 minecraft:mossy_cobblestone
setblock 381 43 182 minecraft:stone_bricks
setblock 381 43 222 minecraft:stone_bricks
setblock 382 43 182 minecraft:mossy_cobblestone
setblock 382 43 221 minecraft:stone_bricks
setblock 382 43 222 minecraft:mossy_cobblestone
setblock 383 43 221 minecraft:mossy_cobblestone
fill 385 43 189 387 43 189 minecraft:lantern
setblock 386 43 188 minecraft:lantern
fill 386 43 190 387 43 190 minecraft:lantern
setblock 386 43 222 minecraft:stone_bricks
setblock 387 43 222 minecraft:mossy_cobblestone
setblock 391 43 221 minecraft:mossy_cobblestone
setblock 391 43 222 minecraft:stone_bricks
setblock 392 43 221 minecraft:stone_bricks
setblock 392 43 222 minecraft:mossy_cobblestone
setblock 393 43 221 minecraft:mossy_cobblestone
setblock 394 43 220 minecraft:mossy_cobblestone
setblock 396 43 222 minecraft:stone_bricks
setblock 397 43 221 minecraft:stone_bricks
setblock 397 43 222 minecraft:mossy_cobblestone
setblock 398 43 220 minecraft:stone_bricks
setblock 398 43 221 minecraft:mossy_cobblestone
setblock 401 43 222 minecraft:stone_bricks
setblock 415 43 193 minecraft:stone_bricks
setblock 415 43 194 minecraft:mossy_cobblestone
setblock 415 43 198 minecraft:stone_bricks
setblock 415 43 199 minecraft:mossy_cobblestone
setblock 416 43 182 minecraft:stone_bricks
setblock 416 43 183 minecraft:mossy_cobblestone
setblock 416 43 187 minecraft:stone_bricks
setblock 416 43 188 minecraft:mossy_cobblestone
setblock 416 43 192 minecraft:stone_bricks
setblock 416 43 193 minecraft:mossy_cobblestone
setblock 416 43 197 minecraft:stone_bricks
setblock 416 43 198 minecraft:mossy_cobblestone
setblock 416 43 217 minecraft:stone_bricks
setblock 416 43 218 minecraft:mossy_cobblestone
setblock 416 43 222 minecraft:stone_bricks
setblock 417 43 182 minecraft:mossy_cobblestone
setblock 417 43 186 minecraft:stone_bricks
setblock 417 43 187 minecraft:mossy_cobblestone
setblock 417 43 191 minecraft:stone_bricks
setblock 417 43 192 minecraft:mossy_cobblestone
setblock 417 43 196 minecraft:stone_bricks
setblock 417 43 197 minecraft:mossy_cobblestone
setblock 417 43 201 minecraft:stone_bricks
setblock 417 43 202 minecraft:mossy_cobblestone
setblock 417 43 212 minecraft:mossy_cobblestone
setblock 417 43 216 minecraft:stone_bricks
setblock 417 43 217 minecraft:mossy_cobblestone
setblock 417 43 221 minecraft:stone_bricks
setblock 417 43 222 minecraft:mossy_cobblestone
setblock 379 49 184 minecraft:light[level=12]
setblock 379 49 192 minecraft:light[level=12]
setblock 379 49 200 minecraft:light[level=12]
setblock 379 49 208 minecraft:light[level=12]
setblock 379 49 216 minecraft:light[level=12]
setblock 387 49 184 minecraft:light[level=12]
setblock 387 49 192 minecraft:light[level=12]
setblock 387 49 200 minecraft:light[level=12]
setblock 387 49 208 minecraft:light[level=12]
setblock 387 49 216 minecraft:light[level=12]
fill 388 49 202 396 49 208 minecraft:spruce_planks
setblock 395 49 184 minecraft:light[level=12]
setblock 395 49 192 minecraft:light[level=12]
setblock 395 49 200 minecraft:light[level=12]
setblock 395 49 216 minecraft:light[level=12]
fill 397 49 193 397 49 204 minecraft:spruce_planks
fill 397 49 206 397 49 217 minecraft:spruce_planks
fill 398 49 193 399 49 202 minecraft:spruce_planks
fill 398 49 208 399 49 217 minecraft:spruce_planks
fill 400 49 193 403 49 201 minecraft:spruce_planks
fill 400 49 209 403 49 217 minecraft:spruce_planks
fill 401 49 202 412 49 202 minecraft:spruce_planks
fill 401 49 208 412 49 208 minecraft:spruce_planks
setblock 403 49 184 minecraft:light[level=12]
setblock 403 49 192 minecraft:light[level=12]
fill 403 49 203 412 49 204 minecraft:spruce_planks
fill 403 49 206 412 49 207 minecraft:spruce_planks
fill 404 49 205 412 49 205 minecraft:spruce_planks
setblock 411 49 184 minecraft:light[level=12]
setblock 411 49 192 minecraft:light[level=12]
setblock 411 49 200 minecraft:light[level=12]
setblock 411 49 216 minecraft:light[level=12]
fill 377 50 182 387 50 222 minecraft:cobblestone
fill 388 50 182 396 50 201 minecraft:cobblestone
fill 388 50 202 396 50 202 minecraft:spruce_log
fill 388 50 203 395 50 207 minecraft:spruce_planks
fill 388 50 208 396 50 208 minecraft:spruce_log
fill 388 50 209 396 50 222 minecraft:cobblestone
setblock 396 50 203 minecraft:spruce_planks
fill 396 50 204 396 50 206 minecraft:lantern
setblock 396 50 207 minecraft:spruce_planks
fill 397 50 182 417 50 192 minecraft:cobblestone
fill 397 50 193 397 50 201 minecraft:spruce_log
fill 397 50 202 397 50 204 minecraft:lantern
fill 397 50 206 397 50 208 minecraft:lantern
fill 397 50 209 397 50 217 minecraft:spruce_log
fill 397 50 218 417 50 222 minecraft:cobblestone
fill 398 50 193 398 50 201 minecraft:spruce_planks
fill 398 50 202 399 50 202 minecraft:lantern
fill 398 50 208 399 50 208 minecraft:lantern
fill 398 50 209 398 50 217 minecraft:spruce_planks
fill 399 50 193 402 50 200 minecraft:spruce_planks
fill 399 50 201 401 50 201 minecraft:lantern
fill 399 50 209 401 50 209 minecraft:lantern
fill 399 50 210 402 50 217 minecraft:spruce_planks
fill 401 50 202 403 50 202 minecraft:lantern
fill 401 50 208 403 50 208 minecraft:lantern
setblock 402 50 201 minecraft:spruce_planks
setblock 402 50 209 minecraft:spruce_planks
fill 403 50 193 403 50 201 minecraft:spruce_log
fill 403 50 203 403 50 204 minecraft:lantern
fill 403 50 206 403 50 207 minecraft:lantern
fill 403 50 209 403 50 217 minecraft:spruce_log
fill 404 50 193 417 50 201 minecraft:cobblestone
fill 404 50 202 412 50 202 minecraft:spruce_log
fill 404 50 203 412 50 203 minecraft:spruce_planks
fill 404 50 204 404 50 206 minecraft:lantern
fill 404 50 207 412 50 207 minecraft:spruce_planks
fill 404 50 208 412 50 208 minecraft:spruce_log
fill 404 50 209 417 50 217 minecraft:cobblestone
fill 405 50 204 412 50 206 minecraft:spruce_planks
fill 413 50 202 417 50 208 minecraft:cobblestone
fill 377 54 182 377 54 184 minecraft:mossy_cobblestone
setblock 377 54 185 minecraft:stone_bricks
fill 377 54 186 377 54 188 minecraft:mossy_cobblestone
setblock 377 54 200 minecraft:stone_bricks
fill 377 54 201 377 54 204 minecraft:mossy_cobblestone
setblock 377 54 205 minecraft:stone_bricks
fill 377 54 206 377 54 209 minecraft:mossy_cobblestone
setblock 377 54 210 minecraft:stone_bricks
fill 377 54 211 377 54 214 minecraft:mossy_cobblestone
setblock 377 54 215 minecraft:stone_bricks
fill 377 54 216 377 54 219 minecraft:mossy_cobblestone
setblock 377 54 220 minecraft:stone_bricks
fill 377 54 221 379 54 222 minecraft:mossy_cobblestone
fill 378 54 182 378 54 183 minecraft:mossy_cobblestone
setblock 378 54 184 minecraft:stone_bricks
setblock 378 54 185 minecraft:mossy_cobblestone
setblock 378 54 204 minecraft:stone_bricks
fill 378 54 205 378 54 207 minecraft:mossy_cobblestone
setblock 378 54 219 minecraft:stone_bricks
fill 378 54 220 378 55 220 minecraft:mossy_cobblestone
setblock 379 54 182 minecraft:mossy_cobblestone
setblock 379 54 183 minecraft:stone_bricks
setblock 380 54 182 minecraft:stone_bricks
setblock 380 54 221 minecraft:mossy_cobblestone
setblock 380 54 222 minecraft:stone_bricks
fill 381 54 182 384 54 182 minecraft:mossy_cobblestone
setblock 381 54 221 minecraft:stone_bricks
fill 381 54 222 384 54 222 minecraft:mossy_cobblestone
fill 382 54 221 385 54 221 minecraft:mossy_cobblestone
setblock 385 54 182 minecraft:stone_bricks
setblock 385 54 222 minecraft:stone_bricks
fill 386 54 182 388 54 183 minecraft:mossy_cobblestone
setblock 386 54 221 minecraft:stone_bricks
fill 386 54 222 389 54 222 minecraft:mossy_cobblestone
fill 387 54 221 390 54 221 minecraft:mossy_cobblestone
setblock 389 54 182 minecraft:mossy_cobblestone
setblock 389 54 183 minecraft:stone_bricks
setblock 390 54 182 minecraft:stone_bricks
fill 390 54 183 393 54 183 minecraft:mossy_cobblestone
setblock 390 54 220 minecraft:mossy_cobblestone
setblock 390 54 222 minecraft:stone_bricks
fill 391 54 182 394 54 182 minecraft:mossy_cobblestone
fill 391 54 184 392 54 184 minecraft:mossy_cobblestone
setblock 391 54 221 minecraft:stone_bricks
fill 391 54 222 394 54 222 minecraft:mossy_cobblestone
fill 392 54 221 395 54 221 minecraft:mossy_cobblestone
setblock 394 54 183 minecraft:stone_bricks
setblock 395 54 182 minecraft:stone_bricks
fill 395 54 183 397 54 183 minecraft:mossy_cobblestone
setblock 395 54 222 minecraft:stone_bricks
fill 396 54 182 399 54 182 minecraft:mossy_cobblestone
fill 396 54 222 398 54 222 minecraft:mossy_cobblestone
setblock 400 54 182 minecraft:stone_bricks
fill 401 54 182 404 54 182 minecraft:mossy_cobblestone
setblock 403 54 183 minecraft:mossy_cobblestone
setblock 404 54 183 minecraft:stone_bricks
setblock 405 54 182 minecraft:stone_bricks
fill 405 54 183 408 54 183 minecraft:mossy_cobblestone
setblock 405 54 222 minecraft:stone_bricks
fill 406 54 182 409 54 182 minecraft:mossy_cobblestone
fill 406 54 184 407 54 184 minecraft:mossy_cobblestone
fill 406 54 222 409 54 222 minecraft:mossy_cobblestone
setblock 408 54 184 minecraft:stone_bricks
fill 408 54 185 411 54 185 minecraft:mossy_cobblestone
fill 408 54 221 410 54 221 minecraft:mossy_cobblestone
setblock 409 54 183 minecraft:stone_bricks
fill 409 54 184 412 54 184 minecraft:mossy_cobblestone
setblock 410 54 182 minecraft:stone_bricks
fill 410 54 183 413 54 183 minecraft:mossy_cobblestone
setblock 410 54 222 minecraft:stone_bricks
fill 411 54 182 414 54 182 minecraft:mossy_cobblestone
setblock 411 54 221 minecraft:stone_bricks
fill 411 54 222 414 54 222 minecraft:mossy_cobblestone
setblock 412 54 185 minecraft:stone_bricks
fill 412 54 221 415 54 221 minecraft:mossy_cobblestone
setblock 413 54 184 minecraft:stone_bricks
fill 413 54 185 416 54 185 minecraft:mossy_cobblestone
fill 413 54 215 413 57 215 minecraft:moss_block
setblock 414 54 183 minecraft:stone_bricks
fill 414 54 184 417 54 184 minecraft:mossy_cobblestone
fill 414 54 186 414 54 187 minecraft:mossy_cobblestone
setblock 415 54 182 minecraft:stone_bricks
fill 415 54 183 417 55 183 minecraft:mossy_cobblestone
setblock 415 54 186 minecraft:mossy_cobblestone
setblock 415 54 187 minecraft:stone_bricks
fill 415 54 188 417 55 188 minecraft:mossy_cobblestone
setblock 415 54 222 minecraft:stone_bricks
fill 416 54 182 417 56 182 minecraft:mossy_cobblestone
setblock 416 54 186 minecraft:stone_bricks
fill 416 54 187 417 56 187 minecraft:mossy_cobblestone
fill 416 54 189 416 54 190 minecraft:mossy_cobblestone
setblock 416 54 200 minecraft:mossy_cobblestone
setblock 416 54 201 minecraft:stone_bricks
fill 416 54 202 416 54 205 minecraft:mossy_cobblestone
setblock 416 54 206 minecraft:stone_bricks
fill 416 54 219 416 54 220 minecraft:mossy_cobblestone
setblock 416 54 221 minecraft:stone_bricks
fill 416 54 222 417 56 222 minecraft:mossy_cobblestone
setblock 417 54 185 minecraft:stone_bricks
fill 417 54 186 417 57 186 minecraft:mossy_cobblestone
setblock 417 54 189 minecraft:mossy_cobblestone
setblock 417 54 190 minecraft:stone_bricks
fill 417 54 191 417 54 192 minecraft:mossy_cobblestone
fill 417 54 197 417 54 199 minecraft:mossy_cobblestone
setblock 417 54 200 minecraft:stone_bricks
fill 417 54 201 417 54 204 minecraft:mossy_cobblestone
setblock 417 54 205 minecraft:stone_bricks
fill 417 54 206 417 54 209 minecraft:mossy_cobblestone
fill 417 54 217 417 54 219 minecraft:mossy_cobblestone
setblock 417 54 220 minecraft:stone_bricks
fill 417 54 221 417 57 221 minecraft:mossy_cobblestone
fill 377 55 182 377 55 183 minecraft:mossy_cobblestone
setblock 377 55 184 minecraft:stone_bricks
fill 377 55 185 377 56 187 minecraft:mossy_cobblestone
fill 377 55 201 377 55 203 minecraft:mossy_cobblestone
setblock 377 55 204 minecraft:stone_bricks
fill 377 55 205 377 55 208 minecraft:mossy_cobblestone
setblock 377 55 209 minecraft:stone_bricks
fill 377 55 210 377 55 213 minecraft:mossy_cobblestone
setblock 377 55 214 minecraft:stone_bricks
fill 377 55 215 377 55 218 minecraft:mossy_cobblestone
setblock 377 55 219 minecraft:stone_bricks
fill 377 55 220 377 56 222 minecraft:mossy_cobblestone
setblock 378 55 182 minecraft:mossy_cobblestone
setblock 378 55 183 minecraft:stone_bricks
setblock 378 55 184 minecraft:mossy_cobblestone
setblock 378 55 206 minecraft:mossy_cobblestone
fill 378 55 221 378 55 222 minecraft:mossy_cobblestone
setblock 379 55 182 minecraft:stone_bricks
setblock 379 55 221 minecraft:mossy_cobblestone
setblock 379 55 222 minecraft:stone_bricks
fill 380 55 182 383 55 182 minecraft:mossy_cobblestone
fill 380 55 222 383 55 222 minecraft:mossy_cobblestone
setblock 384 55 182 minecraft:stone_bricks
setblock 384 55 222 minecraft:stone_bricks
fill 385 55 182 388 55 182 minecraft:mossy_cobblestone
setblock 385 55 221 minecraft:stone_bricks
fill 385 55 222 388 55 222 minecraft:mossy_cobblestone
fill 386 55 183 387 55 183 minecraft:mossy_cobblestone
fill 386 55 221 389 55 221 minecraft:mossy_cobblestone
setblock 388 55 183 minecraft:stone_bricks
setblock 389 55 182 minecraft:stone_bricks
fill 389 55 183 392 55 183 minecraft:mossy_cobblestone
setblock 389 55 222 minecraft:stone_bricks
fill 390 55 182 393 55 182 minecraft:mossy_cobblestone
setblock 390 55 221 minecraft:stone_bricks
fill 390 55 222 393 55 222 minecraft:mossy_cobblestone
fill 391 55 221 393 55 221 minecraft:mossy_cobblestone
setblock 393 55 183 minecraft:stone_bricks
setblock 394 55 182 minecraft:stone_bricks
fill 394 55 183 396 55 183 minecraft:mossy_cobblestone
setblock 394 55 222 minecraft:stone_bricks
fill 395 55 182 398 55 182 minecraft:mossy_cobblestone
fill 395 55 222 396 55 222 minecraft:mossy_cobblestone
setblock 399 55 182 minecraft:stone_bricks
fill 400 55 182 403 55 182 minecraft:mossy_cobblestone
setblock 403 55 183 minecraft:stone_bricks
setblock 404 55 182 minecraft:stone_bricks
fill 404 55 183 407 55 183 minecraft:mossy_cobblestone
fill 405 55 182 408 55 182 minecraft:mossy_cobblestone
fill 405 55 184 406 55 184 minecraft:mossy_cobblestone
fill 405 55 222 408 55 222 minecraft:mossy_cobblestone
setblock 407 55 184 minecraft:stone_bricks
setblock 408 55 183 minecraft:stone_bricks
fill 408 55 184 410 55 185 minecraft:mossy_cobblestone
setblock 409 55 182 minecraft:stone_bricks
fill 409 55 183 412 55 183 minecraft:mossy_cobblestone
setblock 409 55 221 minecraft:mossy_cobblestone
setblock 409 55 222 minecraft:stone_bricks
fill 410 55 182 413 55 182 minecraft:mossy_cobblestone
setblock 410 55 221 minecraft:stone_bricks
fill 410 55 222 413 55 222 minecraft:mossy_cobblestone
setblock 411 55 184 minecraft:mossy_cobblestone
setblock 411 55 185 minecraft:stone_bricks
fill 411 55 221 414 55 221 minecraft:mossy_cobblestone
setblock 412 55 184 minecraft:stone_bricks
fill 412 55 185 415 55 185 minecraft:mossy_cobblestone
setblock 413 55 183 minecraft:stone_bricks
fill 413 55 184 416 55 184 minecraft:mossy_cobblestone
setblock 414 55 182 minecraft:stone_bricks
fill 414 55 183 414 58 183 minecraft:mossy_cobblestone
setblock 414 55 186 minecraft:mossy_cobblestone
setblock 414 55 222 minecraft:stone_bricks
fill 415 55 182 415 58 182 minecraft:mossy_cobblestone
setblock 415 55 186 minecraft:stone_bricks
fill 415 55 187 415 57 187 minecraft:mossy_cobblestone
setblock 415 55 221 minecraft:stone_bricks
fill 415 55 222 415 58 222 minecraft:mossy_cobblestone
setblock 416 55 185 minecraft:stone_bricks
fill 416 55 186 416 58 186 minecraft:mossy_cobblestone
setblock 416 55 189 minecraft:mossy_cobblestone
setblock 416 55 220 minecraft:stone_bricks
setblock 416 55 221 minecraft:mossy_cobblestone
setblock 417 55 184 minecraft:stone_bricks
fill 417 55 185 417 58 185 minecraft:mossy_cobblestone
setblock 417 55 189 minecraft:stone_bricks
fill 417 55 190 417 55 191 minecraft:mossy_cobblestone
fill 417 55 201 417 55 203 minecraft:mossy_cobblestone
setblock 417 55 204 minecraft:stone_bricks
fill 417 55 205 417 55 208 minecraft:mossy_cobblestone
setblock 417 55 209 minecraft:stone_bricks
setblock 417 55 218 minecraft:mossy_cobblestone
setblock 417 55 219 minecraft:stone_bricks
fill 417 55 220 417 56 220 minecraft:mossy_cobblestone
setblock 377 56 182 minecraft:mossy_cobblestone
setblock 377 56 183 minecraft:stone_bricks
fill 377 56 184 377 58 184 minecraft:mossy_cobblestone
setblock 377 56 202 minecraft:mossy_cobblestone
setblock 377 56 203 minecraft:stone_bricks
fill 377 56 204 377 56 207 minecraft:mossy_cobblestone
setblock 377 56 208 minecraft:stone_bricks
fill 377 56 209 377 56 212 minecraft:mossy_cobblestone
setblock 377 56 213 minecraft:stone_bricks
setblock 377 56 214 minecraft:mossy_cobblestone
setblock 377 56 217 minecraft:mossy_cobblestone
setblock 377 56 218 minecraft:stone_bricks
setblock 377 56 219 minecraft:mossy_cobblestone
setblock 378 56 182 minecraft:stone_bricks
setblock 378 56 222 minecraft:stone_bricks
fill 379 56 182 382 56 182 minecraft:mossy_cobblestone
fill 379 56 222 382 56 222 minecraft:mossy_cobblestone
setblock 383 56 182 minecraft:stone_bricks
setblock 383 56 222 minecraft:stone_bricks
fill 384 56 182 387 56 182 minecraft:mossy_cobblestone
fill 384 56 222 387 56 222 minecraft:mossy_cobblestone
setblock 386 56 183 minecraft:mossy_cobblestone
fill 386 56 221 388 56 221 minecraft:mossy_cobblestone
setblock 387 56 183 minecraft:stone_bricks
setblock 388 56 182 minecraft:stone_bricks
fill 388 56 183 391 56 183 minecraft:mossy_cobblestone
setblock 388 56 222 minecraft:stone_bricks
fill 389 56 182 392 56 182 minecraft:mossy_cobblestone
setblock 389 56 221 minecraft:stone_bricks
fill 389 56 222 392 56 222 minecraft:mossy_cobblestone
fill 390 56 221 391 56 221 minecraft:mossy_cobblestone
setblock 392 56 183 minecraft:stone_bricks
setblock 393 56 182 minecraft:stone_bricks
fill 393 56 183 395 56 183 minecraft:mossy_cobblestone
setblock 393 56 222 minecraft:stone_bricks
fill 394 56 182 397 56 182 minecraft:mossy_cobblestone
fill 394 56 222 395 56 222 minecraft:mossy_cobblestone
setblock 398 56 182 minecraft:stone_bricks
fill 399 56 182 402 56 182 minecraft:mossy_cobblestone
setblock 403 56 182 minecraft:stone_bricks
fill 403 56 183 406 56 183 minecraft:mossy_cobblestone
fill 404 56 182 407 56 182 minecraft:mossy_cobblestone
setblock 405 56 184 minecraft:mossy_cobblestone
setblock 406 56 184 minecraft:stone_bricks
fill 406 56 222 407 56 222 minecraft:mossy_cobblestone
setblock 407 56 183 minecraft:stone_bricks
fill 407 56 184 409 56 185 minecraft:mossy_cobblestone
setblock 408 56 182 minecraft:stone_bricks
fill 408 56 183 411 56 183 minecraft:mossy_cobblestone
setblock 408 56 222 minecraft:stone_bricks
fill 409 56 182 412 56 182 minecraft:mossy_cobblestone
setblock 409 56 221 minecraft:stone_bricks
fill 409 56 222 412 56 222 minecraft:mossy_cobblestone
setblock 410 56 184 minecraft:mossy_cobblestone
setblock 410 56 185 minecraft:stone_bricks
fill 410 56 221 413 56 221 minecraft:mossy_cobblestone
setblock 411 56 184 minecraft:stone_bricks
fill 411 56 185 414 56 185 minecraft:mossy_cobblestone
setblock 412 56 183 minecraft:stone_bricks
fill 412 56 184 415 56 184 minecraft:mossy_cobblestone
setblock 413 56 182 minecraft:stone_bricks
fill 413 56 183 413 59 183 minecraft:mossy_cobblestone
setblock 413 56 222 minecraft:stone_bricks
fill 414 56 182 414 59 182 minecraft:mossy_cobblestone
setblock 414 56 186 minecraft:stone_bricks
setblock 414 56 221 minecraft:stone_bricks
fill 414 56 222 414 59 222 minecraft:mossy_cobblestone
fill 415 56 183 416 56 183 minecraft:mossy_cobblestone
setblock 415 56 185 minecraft:stone_bricks
fill 415 56 186 415 57 186 minecraft:mossy_cobblestone
setblock 415 56 221 minecraft:mossy_cobblestone
setblock 416 56 184 minecraft:stone_bricks
fill 416 56 185 416 59 185 minecraft:mossy_cobblestone
setblock 416 56 188 minecraft:mossy_cobblestone
setblock 416 56 189 minecraft:stone_bricks
setblock 417 56 183 minecraft:stone_bricks
fill 417 56 184 417 59 184 minecraft:mossy_cobblestone
setblock 417 56 188 minecraft:stone_bricks
fill 417 56 189 417 56 190 minecraft:mossy_cobblestone
setblock 417 56 203 minecraft:stone_bricks
fill 417 56 204 417 56 207 minecraft:mossy_cobblestone
setblock 417 56 208 minecraft:stone_bricks
setblock 377 57 182 minecraft:stone_bricks
fill 377 57 183 377 58 183 minecraft:mossy_cobblestone
fill 377 57 185 377 57 186 minecraft:mossy_cobblestone
fill 377 57 204 377 57 206 minecraft:mossy_cobblestone
setblock 377 57 207 minecraft:stone_bricks
fill 377 57 208 377 57 211 minecraft:mossy_cobblestone
setblock 377 57 212 minecraft:stone_bricks
setblock 377 57 213 minecraft:mossy_cobblestone
fill 377 57 220 377 57 221 minecraft:mossy_cobblestone
setblock 377 57 222 minecraft:stone_bricks
fill 378 57 182 379 57 182 minecraft:mossy_cobblestone
fill 378 57 222 381 57 222 minecraft:mossy_cobblestone
setblock 379 57 184 minecraft:light[level=12]
setblock 379 57 192 minecraft:light[level=12]
setblock 379 57 200 minecraft:light[level=12]
setblock 379 57 208 minecraft:light[level=12]
setblock 379 57 216 minecraft:light[level=12]
setblock 382 57 222 minecraft:stone_bricks
fill 383 57 182 386 57 182 minecraft:mossy_cobblestone
fill 383 57 222 386 57 222 minecraft:mossy_cobblestone
setblock 387 57 182 minecraft:stone_bricks
fill 387 57 183 390 57 183 minecraft:mossy_cobblestone
setblock 387 57 184 minecraft:light[level=12]
setblock 387 57 192 minecraft:light[level=12]
setblock 387 57 200 minecraft:light[level=12]
setblock 387 57 208 minecraft:light[level=12]
setblock 387 57 216 minecraft:light[level=12]
setblock 387 57 222 minecraft:stone_bricks
fill 388 57 182 391 57 182 minecraft:mossy_cobblestone
fill 388 57 222 391 57 222 minecraft:mossy_cobblestone
setblock 391 57 183 minecraft:stone_bricks
setblock 392 57 182 minecraft:stone_bricks
fill 392 57 183 393 57 183 minecraft:mossy_cobblestone
setblock 392 57 222 minecraft:stone_bricks
fill 393 57 182 396 57 182 minecraft:mossy_cobblestone
setblock 393 57 222 minecraft:mossy_cobblestone
setblock 395 57 184 minecraft:light[level=12]
setblock 395 57 192 minecraft:light[level=12]
setblock 395 57 200 minecraft:light[level=12]
setblock 395 57 208 minecraft:light[level=12]
setblock 395 57 216 minecraft:light[level=12]
setblock 397 57 182 minecraft:stone_bricks
setblock 401 57 182 minecraft:mossy_cobblestone
setblock 402 57 182 minecraft:stone_bricks
fill 403 57 182 405 57 183 minecraft:mossy_cobblestone
setblock 403 57 184 minecraft:light[level=12]
setblock 403 57 192 minecraft:light[level=12]
setblock 403 57 200 minecraft:light[level=12]
setblock 403 57 208 minecraft:light[level=12]
setblock 403 57 216 minecraft:light[level=12]
setblock 405 57 184 minecraft:stone_bricks
setblock 406 57 182 minecraft:mossy_cobblestone
setblock 406 57 183 minecraft:stone_bricks
fill 406 57 184 409 57 184 minecraft:mossy_cobblestone
setblock 406 57 222 minecraft:mossy_cobblestone
setblock 407 57 182 minecraft:stone_bricks
fill 407 57 183 410 57 183 minecraft:mossy_cobblestone
fill 407 57 185 408 57 185 minecraft:mossy_cobblestone
setblock 407 57 222 minecraft:stone_bricks
fill 408 57 182 411 57 182 minecraft:mossy_cobblestone
fill 408 57 222 411 57 222 minecraft:mossy_cobblestone
setblock 409 57 185 minecraft:stone_bricks
setblock 410 57 184 minecraft:stone_bricks
fill 410 57 185 413 57 185 minecraft:mossy_cobblestone
fill 410 57 221 412 57 221 minecraft:mossy_cobblestone
setblock 411 57 183 minecraft:stone_bricks
fill 411 57 184 414 57 184 minecraft:mossy_cobblestone
setblock 411 57 192 minecraft:light[level=12]
setblock 411 57 200 minecraft:light[level=12]
setblock 411 57 208 minecraft:light[level=12]
setblock 411 57 216 minecraft:light[level=12]
setblock 412 57 182 minecraft:stone_bricks
fill 412 57 183 412 60 183 minecraft:mossy_cobblestone
setblock 412 57 222 minecraft:stone_bricks
fill 413 57 182 413 60 182 minecraft:mossy_cobblestone
setblock 413 57 221 minecraft:stone_bricks
fill 413 57 222 413 60 222 minecraft:mossy_cobblestone
setblock 415 57 183 minecraft:mossy_cobblestone
setblock 415 57 184 minecraft:stone_bricks
fill 415 57 185 415 58 185 minecraft:mossy_cobblestone
setblock 416 57 182 minecraft:mossy_cobblestone
setblock 416 57 183 minecraft:stone_bricks
fill 416 57 184 416 59 184 minecraft:mossy_cobblestone
setblock 416 57 187 minecraft:mossy_cobblestone
setblock 416 57 188 minecraft:stone_bricks
setblock 416 57 222 minecraft:mossy_cobblestone
setblock 417 57 182 minecraft:stone_bricks
fill 417 57 183 417 60 183 minecraft:mossy_cobblestone
setblock 417 57 187 minecraft:stone_bricks
fill 417 57 188 417 58 189 minecraft:mossy_cobblestone
setblock 417 57 222 minecraft:stone_bricks
setblock 377 58 182 minecraft:mossy_cobblestone
setblock 377 58 185 minecraft:mossy_cobblestone
setblock 377 58 205 minecraft:mossy_cobblestone
setblock 377 58 206 minecraft:stone_bricks
fill 377 58 207 377 58 210 minecraft:mossy_cobblestone
setblock 377 58 211 minecraft:stone_bricks
fill 377 58 212 377 61 212 minecraft:mossy_cobblestone
setblock 377 58 222 minecraft:mossy_cobblestone
fill 384 58 182 385 58 182 minecraft:mossy_cobblestone
fill 384 58 222 385 58 222 minecraft:mossy_cobblestone
setblock 386 58 182 minecraft:stone_bricks
setblock 386 58 222 minecraft:stone_bricks
fill 387 58 182 390 58 182 minecraft:mossy_cobblestone
fill 387 58 222 390 58 222 minecraft:mossy_cobblestone
fill 388 58 183 389 58 183 minecraft:mossy_cobblestone
setblock 390 58 183 minecraft:stone_bricks
setblock 391 58 182 minecraft:stone_bricks
setblock 391 58 183 minecraft:mossy_cobblestone
setblock 391 58 222 minecraft:stone_bricks
fill 392 58 182 394 58 182 minecraft:mossy_cobblestone
fill 402 58 182 405 58 182 minecraft:mossy_cobblestone
fill 403 58 183 404 58 183 minecraft:mossy_cobblestone
setblock 405 58 183 minecraft:stone_bricks
fill 405 58 184 408 58 184 minecraft:mossy_cobblestone
setblock 406 58 182 minecraft:stone_bricks
fill 406 58 183 409 58 183 minecraft:mossy_cobblestone
fill 407 58 182 410 58 182 minecraft:mossy_cobblestone
setblock 407 58 185 minecraft:mossy_cobblestone
fill 407 58 222 410 58 222 minecraft:mossy_cobblestone
setblock 408 58 185 minecraft:stone_bricks
setblock 409 58 184 minecraft:stone_bricks
fill 409 58 185 412 58 185 minecraft:mossy_cobblestone
setblock 410 58 183 minecraft:stone_bricks
fill 410 58 184 413 58 184 minecraft:mossy_cobblestone
setblock 411 58 182 minecraft:stone_bricks
fill 411 58 183 411 61 183 minecraft:mossy_cobblestone
setblock 411 58 222 minecraft:stone_bricks
fill 412 58 182 412 61 182 minecraft:mossy_cobblestone
fill 412 58 222 412 61 222 minecraft:mossy_cobblestone
setblock 414 58 184 minecraft:stone_bricks
setblock 415 58 183 minecraft:stone_bricks
setblock 415 58 184 minecraft:mossy_cobblestone
setblock 416 58 182 minecraft:stone_bricks
fill 416 58 183 416 59 183 minecraft:mossy_cobblestone
setblock 416 58 187 minecraft:stone_bricks
setblock 416 58 222 minecraft:stone_bricks
fill 417 58 182 417 60 182 minecraft:mossy_cobblestone
setblock 417 58 186 minecraft:stone_bricks
fill 417 58 187 417 61 187 minecraft:mossy_cobblestone
setblock 417 58 222 minecraft:mossy_cobblestone
fill 377 59 206 377 59 209 minecraft:mossy_cobblestone
setblock 377 59 210 minecraft:stone_bricks
fill 377 59 211 377 62 211 minecraft:mossy_cobblestone
setblock 385 59 182 minecraft:stone_bricks
fill 386 59 182 389 59 182 minecraft:mossy_cobblestone
fill 386 59 222 389 59 222 minecraft:mossy_cobblestone
setblock 390 59 182 minecraft:stone_bricks
fill 391 59 182 392 59 182 minecraft:mossy_cobblestone
fill 402 59 182 404 59 182 minecraft:mossy_cobblestone
setblock 403 59 183 minecraft:mossy_cobblestone
setblock 404 59 183 minecraft:stone_bricks
setblock 405 59 182 minecraft:stone_bricks
schedule function dropper:buildpart/44_4 1t
