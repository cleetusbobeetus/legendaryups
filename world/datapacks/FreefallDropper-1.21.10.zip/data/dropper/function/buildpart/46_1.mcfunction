fill 510 127 223 512 127 223 minecraft:polished_blackstone_bricks
fill 512 127 186 512 127 193 minecraft:polished_blackstone_bricks
fill 512 127 198 512 128 205 minecraft:polished_blackstone_bricks
fill 512 127 210 512 307 213 minecraft:polished_blackstone_bricks
setblock 512 127 214 minecraft:cracked_polished_blackstone_bricks
fill 512 127 215 512 307 217 minecraft:polished_blackstone_bricks
fill 512 127 222 512 307 222 minecraft:polished_blackstone_bricks
fill 470 128 192 470 307 192 minecraft:polished_blackstone_bricks
fill 470 128 195 470 128 196 minecraft:polished_blackstone_bricks
fill 470 128 197 470 128 198 minecraft:cracked_polished_blackstone_bricks
setblock 470 128 203 minecraft:cracked_polished_blackstone_bricks
fill 470 128 204 470 307 204 minecraft:polished_blackstone_bricks
setblock 470 128 215 minecraft:polished_blackstone_bricks
fill 474 128 223 475 307 223 minecraft:polished_blackstone_bricks
fill 476 128 223 476 129 223 minecraft:cracked_polished_blackstone_bricks
fill 477 128 223 478 307 223 minecraft:polished_blackstone_bricks
setblock 479 128 223 minecraft:cracked_polished_blackstone_bricks
fill 480 128 223 480 307 223 minecraft:polished_blackstone_bricks
fill 481 128 181 481 307 181 minecraft:polished_blackstone_bricks
fill 484 128 181 484 307 181 minecraft:polished_blackstone_bricks
setblock 486 128 223 minecraft:cracked_polished_blackstone_bricks
fill 487 128 223 489 307 223 minecraft:polished_blackstone_bricks
setblock 488 128 181 minecraft:polished_blackstone_bricks
fill 493 128 181 493 129 181 minecraft:cracked_polished_blackstone_bricks
fill 494 128 181 497 307 181 minecraft:polished_blackstone_bricks
setblock 498 128 181 minecraft:cracked_polished_blackstone_bricks
fill 498 128 223 499 307 223 minecraft:polished_blackstone_bricks
fill 499 128 181 500 307 181 minecraft:polished_blackstone_bricks
setblock 500 128 223 minecraft:cracked_polished_blackstone_bricks
fill 501 128 223 505 307 223 minecraft:polished_blackstone_bricks
fill 506 128 181 506 307 181 minecraft:polished_blackstone_bricks
fill 510 128 223 511 307 223 minecraft:polished_blackstone_bricks
fill 512 128 186 512 128 187 minecraft:polished_blackstone_bricks
setblock 512 128 188 minecraft:cracked_polished_blackstone_bricks
fill 512 128 189 512 307 189 minecraft:polished_blackstone_bricks
setblock 512 128 190 minecraft:cracked_polished_blackstone_bricks
fill 512 128 191 512 128 193 minecraft:polished_blackstone_bricks
fill 512 128 214 512 307 214 minecraft:polished_blackstone_bricks
setblock 512 128 223 minecraft:cracked_polished_blackstone_bricks
setblock 470 129 181 minecraft:cracked_polished_blackstone_bricks
fill 470 129 182 470 307 186 minecraft:polished_blackstone_bricks
setblock 470 129 195 minecraft:cracked_polished_blackstone_bricks
fill 470 129 196 470 307 198 minecraft:polished_blackstone_bricks
fill 470 129 203 470 307 203 minecraft:polished_blackstone_bricks
fill 470 129 205 470 307 208 minecraft:polished_blackstone_bricks
setblock 470 129 209 minecraft:cracked_polished_blackstone_bricks
fill 470 129 210 470 307 210 minecraft:polished_blackstone_bricks
setblock 470 129 215 minecraft:cracked_polished_blackstone_bricks
fill 470 129 216 470 307 218 minecraft:polished_blackstone_bricks
setblock 470 129 219 minecraft:cracked_polished_blackstone_bricks
fill 470 129 220 470 307 222 minecraft:polished_blackstone_bricks
fill 471 129 181 475 307 181 minecraft:polished_blackstone_bricks
setblock 476 129 181 minecraft:cracked_polished_blackstone_bricks
fill 479 129 223 479 307 223 minecraft:polished_blackstone_bricks
fill 486 129 223 486 307 223 minecraft:polished_blackstone_bricks
setblock 488 129 181 minecraft:cracked_polished_blackstone_bricks
fill 498 129 181 498 307 181 minecraft:polished_blackstone_bricks
fill 500 129 223 500 307 223 minecraft:polished_blackstone_bricks
fill 507 129 181 509 307 181 minecraft:polished_blackstone_bricks
setblock 510 129 181 minecraft:cracked_polished_blackstone_bricks
fill 511 129 181 512 307 181 minecraft:polished_blackstone_bricks
setblock 512 129 186 minecraft:cracked_polished_blackstone_bricks
fill 512 129 187 512 307 188 minecraft:polished_blackstone_bricks
fill 512 129 190 512 307 192 minecraft:polished_blackstone_bricks
setblock 512 129 193 minecraft:cracked_polished_blackstone_bricks
fill 512 129 198 512 307 200 minecraft:polished_blackstone_bricks
setblock 512 129 201 minecraft:cracked_polished_blackstone_bricks
fill 512 129 202 512 307 205 minecraft:polished_blackstone_bricks
fill 512 129 223 512 307 223 minecraft:polished_blackstone_bricks
fill 470 130 181 470 307 181 minecraft:polished_blackstone_bricks
fill 470 130 195 470 307 195 minecraft:polished_blackstone_bricks
fill 470 130 209 470 307 209 minecraft:polished_blackstone_bricks
fill 470 130 215 470 307 215 minecraft:polished_blackstone_bricks
fill 470 130 219 470 307 219 minecraft:polished_blackstone_bricks
fill 476 130 181 476 307 181 minecraft:polished_blackstone_bricks
fill 476 130 223 476 307 223 minecraft:polished_blackstone_bricks
fill 488 130 181 488 307 181 minecraft:polished_blackstone_bricks
fill 493 130 181 493 307 181 minecraft:polished_blackstone_bricks
fill 510 130 181 510 307 181 minecraft:polished_blackstone_bricks
fill 512 130 186 512 307 186 minecraft:polished_blackstone_bricks
fill 512 130 193 512 307 193 minecraft:polished_blackstone_bricks
fill 512 130 201 512 307 201 minecraft:polished_blackstone_bricks
setblock 473 131 184 minecraft:light[level=12]
setblock 473 131 192 minecraft:light[level=12]
setblock 473 131 200 minecraft:light[level=12]
setblock 473 131 208 minecraft:light[level=12]
setblock 473 131 216 minecraft:light[level=12]
setblock 481 131 184 minecraft:light[level=12]
setblock 481 131 192 minecraft:light[level=12]
setblock 481 131 200 minecraft:light[level=12]
setblock 481 131 208 minecraft:light[level=12]
setblock 481 131 216 minecraft:light[level=12]
setblock 489 131 184 minecraft:light[level=12]
setblock 489 131 192 minecraft:light[level=12]
setblock 489 131 200 minecraft:light[level=12]
setblock 489 131 208 minecraft:light[level=12]
setblock 489 131 216 minecraft:light[level=12]
setblock 497 131 184 minecraft:light[level=12]
setblock 497 131 192 minecraft:light[level=12]
setblock 497 131 200 minecraft:light[level=12]
setblock 497 131 208 minecraft:light[level=12]
setblock 497 131 216 minecraft:light[level=12]
setblock 505 131 184 minecraft:light[level=12]
setblock 505 131 192 minecraft:light[level=12]
setblock 505 131 200 minecraft:light[level=12]
setblock 505 131 208 minecraft:light[level=12]
setblock 505 131 216 minecraft:light[level=12]
fill 470 132 187 470 145 187 minecraft:polished_blackstone_bricks
fill 470 132 188 470 132 189 minecraft:soul_lantern
fill 470 132 190 470 145 190 minecraft:polished_blackstone_bricks
fill 470 132 199 470 145 199 minecraft:polished_blackstone_bricks
fill 470 132 200 470 132 201 minecraft:soul_lantern
fill 470 132 202 470 145 202 minecraft:polished_blackstone_bricks
fill 470 132 211 470 145 211 minecraft:polished_blackstone_bricks
fill 470 132 212 470 132 213 minecraft:soul_lantern
fill 470 132 214 470 145 214 minecraft:polished_blackstone_bricks
fill 470 132 223 470 145 223 minecraft:polished_blackstone_bricks
fill 471 132 223 472 132 223 minecraft:soul_lantern
fill 473 132 223 473 145 223 minecraft:polished_blackstone_bricks
fill 477 132 181 477 145 181 minecraft:polished_blackstone_bricks
fill 478 132 181 479 132 181 minecraft:soul_lantern
fill 480 132 181 480 145 181 minecraft:polished_blackstone_bricks
fill 482 132 223 482 145 223 minecraft:polished_blackstone_bricks
fill 483 132 223 484 132 223 minecraft:soul_lantern
fill 485 132 223 485 145 223 minecraft:polished_blackstone_bricks
fill 489 132 181 489 145 181 minecraft:polished_blackstone_bricks
fill 490 132 181 491 132 181 minecraft:soul_lantern
fill 492 132 181 492 145 181 minecraft:polished_blackstone_bricks
fill 494 132 223 494 145 223 minecraft:polished_blackstone_bricks
fill 495 132 223 496 132 223 minecraft:soul_lantern
fill 497 132 223 497 145 223 minecraft:polished_blackstone_bricks
fill 501 132 181 501 145 181 minecraft:polished_blackstone_bricks
fill 502 132 181 503 132 181 minecraft:soul_lantern
fill 504 132 181 504 145 181 minecraft:polished_blackstone_bricks
fill 506 132 223 506 145 223 minecraft:polished_blackstone_bricks
fill 507 132 223 508 132 223 minecraft:soul_lantern
fill 509 132 223 509 145 223 minecraft:polished_blackstone_bricks
fill 512 132 182 512 145 182 minecraft:polished_blackstone_bricks
fill 512 132 183 512 132 184 minecraft:soul_lantern
fill 512 132 185 512 145 185 minecraft:polished_blackstone_bricks
fill 512 132 194 512 145 194 minecraft:polished_blackstone_bricks
fill 512 132 195 512 132 196 minecraft:soul_lantern
fill 512 132 197 512 145 197 minecraft:polished_blackstone_bricks
fill 512 132 206 512 145 206 minecraft:polished_blackstone_bricks
fill 512 132 207 512 132 208 minecraft:soul_lantern
fill 512 132 209 512 145 209 minecraft:polished_blackstone_bricks
fill 512 132 218 512 145 218 minecraft:polished_blackstone_bricks
fill 512 132 219 512 132 220 minecraft:soul_lantern
fill 512 132 221 512 145 221 minecraft:polished_blackstone_bricks
fill 470 133 188 470 145 189 minecraft:polished_blackstone_bricks
fill 470 133 200 470 145 201 minecraft:polished_blackstone_bricks
fill 470 133 212 470 145 213 minecraft:polished_blackstone_bricks
fill 471 133 223 472 145 223 minecraft:polished_blackstone_bricks
fill 478 133 181 479 145 181 minecraft:polished_blackstone_bricks
fill 483 133 223 484 145 223 minecraft:polished_blackstone_bricks
fill 490 133 181 491 145 181 minecraft:polished_blackstone_bricks
fill 495 133 223 496 145 223 minecraft:polished_blackstone_bricks
fill 502 133 181 503 145 181 minecraft:polished_blackstone_bricks
fill 507 133 223 508 145 223 minecraft:polished_blackstone_bricks
fill 512 133 183 512 145 184 minecraft:polished_blackstone_bricks
fill 512 133 195 512 145 196 minecraft:polished_blackstone_bricks
fill 512 133 207 512 145 208 minecraft:polished_blackstone_bricks
fill 512 133 219 512 145 220 minecraft:polished_blackstone_bricks
setblock 473 139 184 minecraft:light[level=12]
setblock 473 139 192 minecraft:light[level=12]
setblock 473 139 200 minecraft:light[level=12]
setblock 473 139 208 minecraft:light[level=12]
setblock 473 139 216 minecraft:light[level=12]
setblock 481 139 184 minecraft:light[level=12]
setblock 481 139 192 minecraft:light[level=12]
setblock 481 139 200 minecraft:light[level=12]
setblock 481 139 208 minecraft:light[level=12]
setblock 481 139 216 minecraft:light[level=12]
setblock 489 139 184 minecraft:light[level=12]
setblock 489 139 192 minecraft:light[level=12]
setblock 489 139 200 minecraft:light[level=12]
setblock 489 139 208 minecraft:light[level=12]
setblock 489 139 216 minecraft:light[level=12]
setblock 497 139 184 minecraft:light[level=12]
setblock 497 139 192 minecraft:light[level=12]
setblock 497 139 200 minecraft:light[level=12]
setblock 497 139 208 minecraft:light[level=12]
setblock 497 139 216 minecraft:light[level=12]
setblock 505 139 184 minecraft:light[level=12]
setblock 505 139 192 minecraft:light[level=12]
setblock 505 139 200 minecraft:light[level=12]
setblock 505 139 208 minecraft:light[level=12]
setblock 505 139 216 minecraft:light[level=12]
fill 479 140 198 489 141 198 minecraft:iron_block
fill 480 140 194 480 142 197 minecraft:iron_block
fill 480 140 203 503 141 203 minecraft:iron_block
fill 481 140 195 490 141 197 minecraft:iron_block
fill 481 140 202 504 141 202 minecraft:iron_block
fill 481 140 204 502 141 205 minecraft:iron_block
fill 482 140 190 501 141 190 minecraft:iron_block
fill 482 140 194 505 141 194 minecraft:iron_block
fill 482 140 199 490 141 201 minecraft:iron_block
fill 483 140 189 500 141 189 minecraft:iron_block
fill 483 140 192 505 141 193 minecraft:iron_block
fill 484 140 188 485 142 188 minecraft:iron_block
fill 484 140 191 505 141 191 minecraft:iron_block
fill 485 140 187 485 142 187 minecraft:iron_block
fill 485 140 206 504 141 206 minecraft:iron_block
fill 486 140 207 489 142 210 minecraft:iron_block
fill 487 140 188 500 142 188 minecraft:iron_block
fill 488 140 211 488 142 211 minecraft:iron_block
fill 489 140 185 492 142 185 minecraft:iron_block
fill 489 140 187 500 142 187 minecraft:iron_block
fill 490 140 186 493 142 186 minecraft:iron_block
fill 490 140 207 497 142 209 minecraft:iron_block
fill 491 140 195 492 141 195 minecraft:iron_block
fill 491 140 201 492 141 201 minecraft:iron_block
fill 493 140 210 496 142 210 minecraft:iron_block
fill 494 140 195 504 141 195 minecraft:iron_block
fill 494 140 201 506 141 201 minecraft:iron_block
fill 494 140 211 497 142 211 minecraft:iron_block
fill 496 140 196 504 141 197 minecraft:iron_block
fill 496 140 199 506 141 200 minecraft:iron_block
fill 497 140 186 500 142 186 minecraft:iron_block
fill 497 140 198 507 141 198 minecraft:iron_block
fill 498 140 185 498 142 185 minecraft:iron_block
fill 498 140 207 499 142 208 minecraft:iron_block
fill 500 140 207 503 142 207 minecraft:iron_block
fill 501 140 208 501 142 209 minecraft:iron_block
fill 502 140 208 502 142 208 minecraft:iron_block
fill 503 140 204 503 142 204 minecraft:iron_block
fill 506 140 193 506 142 193 minecraft:iron_block
fill 506 140 202 506 142 202 minecraft:iron_block
fill 471 142 182 478 142 222 minecraft:blackstone
fill 479 142 182 479 142 197 minecraft:blackstone
fill 479 142 198 488 142 198 minecraft:iron_block
fill 479 142 199 479 142 222 minecraft:blackstone
fill 480 142 182 481 142 193 minecraft:blackstone
fill 480 142 199 480 142 202 minecraft:blackstone
fill 480 142 203 484 142 203 minecraft:iron_block
fill 480 142 204 480 142 222 minecraft:blackstone
setblock 481 142 194 minecraft:blackstone
fill 481 142 195 488 142 197 minecraft:iron_block
fill 481 142 199 481 142 201 minecraft:blackstone
fill 481 142 202 484 142 202 minecraft:iron_block
fill 481 142 204 485 142 205 minecraft:iron_block
fill 481 142 206 484 142 222 minecraft:blackstone
fill 482 142 182 482 142 189 minecraft:blackstone
fill 482 142 190 488 142 190 minecraft:iron_block
fill 482 142 191 482 142 193 minecraft:blackstone
fill 482 142 194 490 142 194 minecraft:iron_block
fill 482 142 199 483 142 201 minecraft:iron_block
fill 483 142 182 483 142 188 minecraft:blackstone
fill 483 142 189 489 142 189 minecraft:iron_block
setblock 483 142 191 minecraft:blackstone
fill 483 142 192 489 142 193 minecraft:iron_block
fill 484 142 182 484 142 187 minecraft:blackstone
fill 484 142 191 488 142 191 minecraft:iron_block
fill 484 142 199 488 142 201 minecraft:polished_blackstone
fill 485 142 182 488 142 186 minecraft:blackstone
fill 485 142 202 490 142 203 minecraft:polished_blackstone
fill 485 142 206 487 142 206 minecraft:iron_block
fill 485 142 207 485 142 222 minecraft:blackstone
fill 486 142 187 486 142 188 minecraft:blackstone
fill 486 142 204 489 142 204 minecraft:polished_blackstone
setblock 486 142 205 minecraft:iron_block
fill 486 142 211 487 142 222 minecraft:blackstone
fill 487 142 187 488 142 187 minecraft:blackstone
fill 487 142 205 488 142 205 minecraft:polished_blackstone
setblock 488 142 206 minecraft:polished_blackstone
fill 488 142 212 511 142 222 minecraft:blackstone
fill 489 142 182 511 142 184 minecraft:blackstone
setblock 489 142 186 minecraft:blackstone
fill 489 142 190 497 142 191 minecraft:polished_blackstone
fill 489 142 195 489 142 196 minecraft:iron_block
fill 489 142 197 489 142 199 minecraft:soul_lantern
fill 489 142 200 489 142 201 minecraft:polished_blackstone
fill 489 142 205 497 142 206 minecraft:iron_block
fill 489 142 211 493 142 211 minecraft:blackstone
fill 490 142 189 496 142 189 minecraft:polished_blackstone
fill 490 142 192 496 142 192 minecraft:polished_blackstone
setblock 490 142 193 minecraft:iron_block
fill 490 142 195 490 142 197 minecraft:soul_lantern
fill 490 142 199 490 142 201 minecraft:soul_lantern
fill 490 142 204 496 142 204 minecraft:iron_block
fill 490 142 210 492 142 210 minecraft:blackstone
fill 491 142 193 491 142 194 minecraft:polished_blackstone
fill 491 142 195 492 142 195 minecraft:soul_lantern
fill 491 142 201 492 142 201 minecraft:soul_lantern
fill 491 142 202 491 142 203 minecraft:iron_block
fill 492 142 193 495 142 193 minecraft:polished_blackstone
fill 492 142 194 494 142 194 minecraft:soul_lantern
fill 492 142 202 494 142 202 minecraft:soul_lantern
fill 492 142 203 495 142 203 minecraft:iron_block
fill 493 142 185 497 142 185 minecraft:blackstone
fill 494 142 186 496 142 186 minecraft:blackstone
fill 494 142 195 496 142 195 minecraft:soul_lantern
fill 494 142 201 496 142 201 minecraft:soul_lantern
setblock 495 142 194 minecraft:polished_blackstone
setblock 495 142 202 minecraft:iron_block
fill 496 142 193 505 142 194 minecraft:iron_block
fill 496 142 196 496 142 197 minecraft:soul_lantern
fill 496 142 199 496 142 200 minecraft:soul_lantern
fill 496 142 202 501 142 203 minecraft:polished_blackstone
fill 497 142 189 500 142 189 minecraft:iron_block
fill 497 142 192 505 142 192 minecraft:iron_block
fill 497 142 195 504 142 196 minecraft:iron_block
fill 497 142 197 497 142 199 minecraft:soul_lantern
fill 497 142 200 502 142 201 minecraft:polished_blackstone
fill 497 142 204 500 142 204 minecraft:polished_blackstone
fill 497 142 210 511 142 210 minecraft:blackstone
fill 498 142 190 501 142 191 minecraft:iron_block
fill 498 142 197 504 142 197 minecraft:iron_block
fill 498 142 198 502 142 199 minecraft:polished_blackstone
fill 498 142 205 498 142 206 minecraft:polished_blackstone
fill 498 142 209 500 142 209 minecraft:blackstone
fill 498 142 211 511 142 211 minecraft:blackstone
fill 499 142 185 511 142 185 minecraft:blackstone
setblock 499 142 205 minecraft:polished_blackstone
fill 499 142 206 504 142 206 minecraft:iron_block
fill 500 142 205 502 142 205 minecraft:iron_block
setblock 500 142 208 minecraft:blackstone
fill 501 142 186 511 142 189 minecraft:blackstone
fill 501 142 204 502 142 204 minecraft:iron_block
fill 502 142 190 511 142 190 minecraft:blackstone
fill 502 142 191 505 142 191 minecraft:iron_block
fill 502 142 202 503 142 203 minecraft:iron_block
fill 502 142 209 511 142 209 minecraft:blackstone
fill 503 142 198 506 142 201 minecraft:iron_block
fill 503 142 205 511 142 205 minecraft:blackstone
fill 503 142 208 511 142 208 minecraft:blackstone
setblock 504 142 202 minecraft:iron_block
fill 504 142 203 511 142 204 minecraft:blackstone
fill 504 142 207 511 142 207 minecraft:blackstone
fill 505 142 195 511 142 197 minecraft:blackstone
setblock 505 142 202 minecraft:blackstone
fill 505 142 206 511 142 206 minecraft:blackstone
fill 506 142 191 511 142 192 minecraft:blackstone
fill 506 142 194 511 142 194 minecraft:blackstone
fill 507 142 193 511 142 193 minecraft:blackstone
setblock 507 142 198 minecraft:iron_block
fill 507 142 199 511 142 202 minecraft:blackstone
fill 508 142 198 511 142 198 minecraft:blackstone
fill 470 146 187 470 151 190 minecraft:soul_lantern
fill 470 146 199 470 151 202 minecraft:soul_lantern
fill 470 146 211 470 151 214 minecraft:soul_lantern
fill 470 146 223 473 151 223 minecraft:soul_lantern
fill 471 146 182 473 212 182 minecraft:polished_blackstone
fill 471 146 192 471 212 194 minecraft:polished_blackstone
fill 471 146 204 471 212 206 minecraft:polished_blackstone
fill 471 146 216 471 212 218 minecraft:polished_blackstone
fill 477 146 181 480 151 181 minecraft:soul_lantern
fill 477 146 222 479 212 222 minecraft:polished_blackstone
fill 482 146 223 485 151 223 minecraft:soul_lantern
fill 483 146 182 485 212 182 minecraft:polished_blackstone
fill 487 146 188 487 160 188 minecraft:polished_blackstone
fill 489 146 181 492 151 181 minecraft:soul_lantern
fill 489 146 222 491 212 222 minecraft:polished_blackstone
fill 494 146 223 497 151 223 minecraft:soul_lantern
fill 495 146 182 497 212 182 minecraft:polished_blackstone
fill 501 146 181 504 151 181 minecraft:soul_lantern
fill 501 146 222 503 212 222 minecraft:polished_blackstone
fill 505 146 186 505 155 186 minecraft:polished_blackstone
fill 506 146 223 509 151 223 minecraft:soul_lantern
fill 507 146 182 509 212 182 minecraft:polished_blackstone
fill 511 146 190 511 212 192 minecraft:polished_blackstone
fill 511 146 202 511 212 204 minecraft:polished_blackstone
fill 511 146 214 511 212 216 minecraft:polished_blackstone
fill 512 146 182 512 151 185 minecraft:soul_lantern
fill 512 146 194 512 151 197 minecraft:soul_lantern
fill 512 146 206 512 151 209 minecraft:soul_lantern
fill 512 146 218 512 151 221 minecraft:soul_lantern
setblock 473 147 184 minecraft:light[level=12]
setblock 473 147 192 minecraft:light[level=12]
setblock 473 147 200 minecraft:light[level=12]
setblock 473 147 208 minecraft:light[level=12]
setblock 473 147 216 minecraft:light[level=12]
setblock 481 147 184 minecraft:light[level=12]
setblock 481 147 192 minecraft:light[level=12]
setblock 481 147 200 minecraft:light[level=12]
setblock 481 147 208 minecraft:light[level=12]
setblock 481 147 216 minecraft:light[level=12]
setblock 489 147 184 minecraft:light[level=12]
setblock 489 147 192 minecraft:light[level=12]
setblock 489 147 200 minecraft:light[level=12]
setblock 489 147 208 minecraft:light[level=12]
setblock 489 147 216 minecraft:light[level=12]
setblock 497 147 184 minecraft:light[level=12]
setblock 497 147 192 minecraft:light[level=12]
setblock 497 147 200 minecraft:light[level=12]
setblock 497 147 208 minecraft:light[level=12]
setblock 497 147 216 minecraft:light[level=12]
setblock 505 147 184 minecraft:light[level=12]
setblock 505 147 192 minecraft:light[level=12]
setblock 505 147 200 minecraft:light[level=12]
setblock 505 147 208 minecraft:light[level=12]
setblock 505 147 216 minecraft:light[level=12]
fill 504 151 208 510 152 208 minecraft:polished_blackstone
fill 510 151 198 510 152 198 minecraft:polished_blackstone
fill 470 152 187 470 165 187 minecraft:polished_blackstone_bricks
fill 470 152 188 470 152 189 minecraft:soul_lantern
fill 470 152 190 470 165 190 minecraft:polished_blackstone_bricks
fill 470 152 199 470 165 199 minecraft:polished_blackstone_bricks
fill 470 152 200 470 152 201 minecraft:soul_lantern
fill 470 152 202 470 165 202 minecraft:polished_blackstone_bricks
fill 470 152 211 470 165 211 minecraft:polished_blackstone_bricks
fill 470 152 212 470 152 213 minecraft:soul_lantern
fill 470 152 214 470 165 214 minecraft:polished_blackstone_bricks
fill 470 152 223 470 165 223 minecraft:polished_blackstone_bricks
fill 471 152 183 511 152 183 minecraft:polished_blackstone
fill 471 152 188 486 153 188 minecraft:polished_blackstone
fill 471 152 198 487 152 198 minecraft:polished_blackstone
fill 471 152 203 510 152 203 minecraft:polished_blackstone
fill 471 152 208 503 152 208 minecraft:polished_blackstone
fill 471 152 213 511 152 213 minecraft:polished_blackstone
fill 471 152 223 472 152 223 minecraft:soul_lantern
fill 472 152 193 474 153 193 minecraft:polished_blackstone
fill 472 152 218 474 152 218 minecraft:polished_blackstone
fill 473 152 223 473 165 223 minecraft:polished_blackstone_bricks
fill 477 152 181 477 165 181 minecraft:polished_blackstone_bricks
fill 478 152 181 479 152 181 minecraft:soul_lantern
fill 480 152 181 480 165 181 minecraft:polished_blackstone_bricks
fill 482 152 223 482 165 223 minecraft:polished_blackstone_bricks
fill 483 152 223 484 152 223 minecraft:soul_lantern
fill 485 152 223 485 165 223 minecraft:polished_blackstone_bricks
fill 488 152 188 510 153 188 minecraft:polished_blackstone
fill 489 152 181 489 165 181 minecraft:polished_blackstone_bricks
fill 490 152 181 491 152 181 minecraft:soul_lantern
fill 492 152 181 492 165 181 minecraft:polished_blackstone_bricks
fill 494 152 223 494 165 223 minecraft:polished_blackstone_bricks
fill 495 152 198 509 152 198 minecraft:polished_blackstone
fill 495 152 223 496 152 223 minecraft:soul_lantern
fill 497 152 223 497 165 223 minecraft:polished_blackstone_bricks
fill 501 152 181 501 165 181 minecraft:polished_blackstone_bricks
fill 502 152 181 503 152 181 minecraft:soul_lantern
fill 504 152 181 504 165 181 minecraft:polished_blackstone_bricks
fill 506 152 223 506 165 223 minecraft:polished_blackstone_bricks
fill 507 152 223 508 152 223 minecraft:soul_lantern
fill 509 152 223 509 165 223 minecraft:polished_blackstone_bricks
fill 512 152 182 512 165 182 minecraft:polished_blackstone_bricks
fill 512 152 183 512 152 184 minecraft:soul_lantern
fill 512 152 185 512 165 185 minecraft:polished_blackstone_bricks
fill 512 152 194 512 165 194 minecraft:polished_blackstone_bricks
fill 512 152 195 512 152 196 minecraft:soul_lantern
fill 512 152 197 512 165 197 minecraft:polished_blackstone_bricks
fill 512 152 206 512 165 206 minecraft:polished_blackstone_bricks
fill 512 152 207 512 152 208 minecraft:soul_lantern
fill 512 152 209 512 165 209 minecraft:polished_blackstone_bricks
fill 512 152 218 512 165 218 minecraft:polished_blackstone_bricks
fill 512 152 219 512 152 220 minecraft:soul_lantern
fill 512 152 221 512 165 221 minecraft:polished_blackstone_bricks
fill 470 153 188 470 165 189 minecraft:polished_blackstone_bricks
fill 470 153 200 470 165 201 minecraft:polished_blackstone_bricks
fill 470 153 212 470 165 213 minecraft:polished_blackstone_bricks
fill 471 153 183 489 153 183 minecraft:polished_blackstone
fill 471 153 198 474 153 198 minecraft:polished_blackstone
fill 471 153 203 484 153 203 minecraft:polished_blackstone
fill 471 153 208 474 153 208 minecraft:polished_blackstone
setblock 471 153 213 minecraft:polished_blackstone
fill 471 153 223 472 165 223 minecraft:polished_blackstone_bricks
fill 472 153 212 472 153 222 minecraft:iron_block
fill 473 153 213 481 153 213 minecraft:polished_blackstone
fill 473 153 218 501 153 218 minecraft:polished_blackstone
fill 475 153 193 510 153 193 minecraft:polished_blackstone
fill 478 153 181 479 165 181 minecraft:polished_blackstone_bricks
fill 483 153 223 484 165 223 minecraft:polished_blackstone_bricks
fill 490 153 181 491 165 181 minecraft:polished_blackstone_bricks
fill 495 153 223 496 165 223 minecraft:polished_blackstone_bricks
fill 502 153 181 503 165 181 minecraft:polished_blackstone_bricks
fill 502 153 207 502 153 221 minecraft:iron_block
fill 503 153 218 510 153 218 minecraft:polished_blackstone
fill 507 153 223 508 165 223 minecraft:polished_blackstone_bricks
fill 512 153 183 512 165 184 minecraft:polished_blackstone_bricks
fill 512 153 195 512 165 196 minecraft:polished_blackstone_bricks
fill 512 153 207 512 165 208 minecraft:polished_blackstone_bricks
fill 512 153 219 512 165 220 minecraft:polished_blackstone_bricks
fill 472 154 183 472 154 217 minecraft:iron_block
fill 477 154 182 477 155 221 minecraft:iron_block
fill 482 154 182 482 155 200 minecraft:iron_block
fill 487 154 182 487 155 185 minecraft:iron_block
fill 492 154 182 492 155 187 minecraft:iron_block
fill 497 154 183 497 155 184 minecraft:iron_block
fill 502 154 182 502 154 212 minecraft:iron_block
fill 507 154 183 507 155 191 minecraft:iron_block
fill 507 154 218 510 154 218 minecraft:polished_blackstone
setblock 510 154 193 minecraft:polished_blackstone
fill 472 155 183 472 155 184 minecraft:iron_block
setblock 473 155 184 minecraft:light[level=12]
setblock 473 155 192 minecraft:light[level=12]
setblock 473 155 200 minecraft:light[level=12]
setblock 473 155 208 minecraft:light[level=12]
setblock 473 155 216 minecraft:light[level=12]
setblock 481 155 184 minecraft:light[level=12]
setblock 481 155 192 minecraft:light[level=12]
setblock 481 155 200 minecraft:light[level=12]
setblock 481 155 208 minecraft:light[level=12]
setblock 481 155 216 minecraft:light[level=12]
fill 482 155 201 482 155 222 minecraft:iron_block
fill 487 155 186 487 155 187 minecraft:iron_block
fill 487 155 189 487 155 221 minecraft:iron_block
setblock 489 155 184 minecraft:light[level=12]
setblock 489 155 192 minecraft:light[level=12]
setblock 489 155 200 minecraft:light[level=12]
setblock 489 155 208 minecraft:light[level=12]
setblock 489 155 216 minecraft:light[level=12]
fill 492 155 188 492 155 195 minecraft:iron_block
fill 492 155 203 492 155 222 minecraft:iron_block
fill 497 155 185 497 155 212 minecraft:iron_block
setblock 497 155 216 minecraft:light[level=12]
fill 502 155 182 502 155 184 minecraft:iron_block
setblock 505 155 184 minecraft:light[level=12]
setblock 505 155 192 minecraft:light[level=12]
setblock 505 155 200 minecraft:light[level=12]
setblock 505 155 208 minecraft:light[level=12]
setblock 505 155 216 minecraft:light[level=12]
fill 507 155 192 507 155 222 minecraft:iron_block
fill 487 156 218 487 156 221 minecraft:iron_block
fill 497 156 208 497 156 222 minecraft:iron_block
fill 472 160 191 472 165 193 minecraft:polished_blackstone
fill 472 160 203 472 165 205 minecraft:polished_blackstone
fill 472 160 215 472 165 217 minecraft:polished_blackstone
fill 478 160 221 480 165 221 minecraft:polished_blackstone
fill 482 160 183 484 165 183 minecraft:polished_blackstone
fill 490 160 221 492 165 221 minecraft:polished_blackstone
fill 494 160 183 496 165 183 minecraft:polished_blackstone
fill 502 160 221 504 165 221 minecraft:polished_blackstone
fill 506 160 183 508 165 183 minecraft:polished_blackstone
fill 510 160 191 510 165 193 minecraft:polished_blackstone
fill 510 160 203 510 165 205 minecraft:polished_blackstone
fill 510 160 215 510 165 217 minecraft:polished_blackstone
setblock 473 163 184 minecraft:light[level=12]
setblock 473 163 192 minecraft:light[level=12]
setblock 473 163 200 minecraft:light[level=12]
setblock 473 163 208 minecraft:light[level=12]
setblock 473 163 216 minecraft:light[level=12]
setblock 481 163 184 minecraft:light[level=12]
setblock 481 163 192 minecraft:light[level=12]
setblock 481 163 200 minecraft:light[level=12]
setblock 481 163 208 minecraft:light[level=12]
setblock 481 163 216 minecraft:light[level=12]
setblock 489 163 184 minecraft:light[level=12]
setblock 489 163 192 minecraft:light[level=12]
setblock 489 163 200 minecraft:light[level=12]
setblock 489 163 208 minecraft:light[level=12]
setblock 489 163 216 minecraft:light[level=12]
setblock 497 163 184 minecraft:light[level=12]
setblock 497 163 192 minecraft:light[level=12]
setblock 497 163 200 minecraft:light[level=12]
setblock 497 163 208 minecraft:light[level=12]
setblock 497 163 216 minecraft:light[level=12]
setblock 505 163 184 minecraft:light[level=12]
setblock 505 163 192 minecraft:light[level=12]
setblock 505 163 200 minecraft:light[level=12]
setblock 505 163 208 minecraft:light[level=12]
setblock 505 163 216 minecraft:light[level=12]
fill 471 165 185 471 165 190 minecraft:blackstone
fill 471 165 197 471 165 202 minecraft:blackstone
fill 471 165 209 471 165 214 minecraft:blackstone
fill 471 165 221 471 165 222 minecraft:blackstone
fill 472 165 222 475 165 222 minecraft:blackstone
fill 475 165 182 480 165 182 minecraft:blackstone
fill 482 165 222 487 165 222 minecraft:blackstone
fill 487 165 182 492 165 182 minecraft:blackstone
fill 494 165 222 499 165 222 minecraft:blackstone
fill 499 165 182 504 165 182 minecraft:blackstone
fill 506 165 222 511 165 222 minecraft:blackstone
fill 511 165 182 511 165 187 minecraft:blackstone
fill 511 165 194 511 165 199 minecraft:blackstone
fill 511 165 206 511 165 211 minecraft:blackstone
fill 511 165 218 511 165 221 minecraft:blackstone
fill 470 166 187 470 171 190 minecraft:soul_lantern
fill 470 166 199 470 171 202 minecraft:soul_lantern
fill 470 166 211 470 171 214 minecraft:soul_lantern
fill 470 166 223 473 171 223 minecraft:soul_lantern
fill 477 166 181 480 171 181 minecraft:soul_lantern
fill 482 166 223 485 171 223 minecraft:soul_lantern
fill 489 166 181 492 171 181 minecraft:soul_lantern
fill 494 166 223 497 171 223 minecraft:soul_lantern
fill 501 166 181 504 171 181 minecraft:soul_lantern
fill 506 166 223 509 171 223 minecraft:soul_lantern
fill 508 166 204 508 186 204 minecraft:iron_block
fill 512 166 182 512 171 185 minecraft:soul_lantern
fill 512 166 194 512 171 197 minecraft:soul_lantern
fill 512 166 206 512 171 209 minecraft:soul_lantern
fill 512 166 218 512 171 221 minecraft:soul_lantern
fill 484 167 186 484 187 186 minecraft:polished_blackstone
setblock 473 171 184 minecraft:light[level=12]
setblock 473 171 192 minecraft:light[level=12]
setblock 473 171 200 minecraft:light[level=12]
setblock 473 171 208 minecraft:light[level=12]
setblock 473 171 216 minecraft:light[level=12]
setblock 481 171 184 minecraft:light[level=12]
setblock 481 171 192 minecraft:light[level=12]
setblock 481 171 200 minecraft:light[level=12]
setblock 481 171 208 minecraft:light[level=12]
setblock 481 171 216 minecraft:light[level=12]
setblock 489 171 184 minecraft:light[level=12]
setblock 489 171 192 minecraft:light[level=12]
setblock 489 171 200 minecraft:light[level=12]
setblock 489 171 208 minecraft:light[level=12]
setblock 489 171 216 minecraft:light[level=12]
setblock 497 171 184 minecraft:light[level=12]
setblock 497 171 192 minecraft:light[level=12]
setblock 497 171 200 minecraft:light[level=12]
setblock 497 171 208 minecraft:light[level=12]
setblock 497 171 216 minecraft:light[level=12]
setblock 505 171 184 minecraft:light[level=12]
setblock 505 171 192 minecraft:light[level=12]
setblock 505 171 200 minecraft:light[level=12]
setblock 505 171 208 minecraft:light[level=12]
setblock 505 171 216 minecraft:light[level=12]
fill 470 172 187 470 185 187 minecraft:polished_blackstone_bricks
fill 470 172 188 470 172 189 minecraft:soul_lantern
fill 470 172 190 470 185 190 minecraft:polished_blackstone_bricks
fill 470 172 199 470 185 199 minecraft:polished_blackstone_bricks
fill 470 172 200 470 172 201 minecraft:soul_lantern
fill 470 172 202 470 185 202 minecraft:polished_blackstone_bricks
fill 470 172 211 470 185 211 minecraft:polished_blackstone_bricks
fill 470 172 212 470 172 213 minecraft:soul_lantern
fill 470 172 214 470 185 214 minecraft:polished_blackstone_bricks
fill 470 172 223 470 185 223 minecraft:polished_blackstone_bricks
fill 471 172 223 472 172 223 minecraft:soul_lantern
fill 473 172 223 473 185 223 minecraft:polished_blackstone_bricks
fill 477 172 181 477 185 181 minecraft:polished_blackstone_bricks
fill 478 172 181 479 172 181 minecraft:soul_lantern
fill 480 172 181 480 185 181 minecraft:polished_blackstone_bricks
fill 482 172 223 482 185 223 minecraft:polished_blackstone_bricks
fill 483 172 223 484 172 223 minecraft:soul_lantern
fill 485 172 223 485 185 223 minecraft:polished_blackstone_bricks
fill 489 172 181 489 185 181 minecraft:polished_blackstone_bricks
fill 490 172 181 491 172 181 minecraft:soul_lantern
fill 492 172 181 492 185 181 minecraft:polished_blackstone_bricks
fill 494 172 223 494 185 223 minecraft:polished_blackstone_bricks
fill 495 172 223 496 172 223 minecraft:soul_lantern
fill 497 172 223 497 185 223 minecraft:polished_blackstone_bricks
fill 501 172 181 501 185 181 minecraft:polished_blackstone_bricks
fill 502 172 181 503 172 181 minecraft:soul_lantern
fill 504 172 181 504 185 181 minecraft:polished_blackstone_bricks
fill 506 172 223 506 185 223 minecraft:polished_blackstone_bricks
fill 507 172 223 508 172 223 minecraft:soul_lantern
fill 509 172 223 509 185 223 minecraft:polished_blackstone_bricks
fill 512 172 182 512 185 182 minecraft:polished_blackstone_bricks
fill 512 172 183 512 172 184 minecraft:soul_lantern
fill 512 172 185 512 185 185 minecraft:polished_blackstone_bricks
fill 512 172 194 512 185 194 minecraft:polished_blackstone_bricks
fill 512 172 195 512 172 196 minecraft:soul_lantern
fill 512 172 197 512 185 197 minecraft:polished_blackstone_bricks
fill 512 172 206 512 185 206 minecraft:polished_blackstone_bricks
fill 512 172 207 512 172 208 minecraft:soul_lantern
fill 512 172 209 512 185 209 minecraft:polished_blackstone_bricks
fill 512 172 218 512 185 218 minecraft:polished_blackstone_bricks
fill 512 172 219 512 172 220 minecraft:soul_lantern
fill 512 172 221 512 185 221 minecraft:polished_blackstone_bricks
fill 470 173 188 470 185 189 minecraft:polished_blackstone_bricks
fill 470 173 200 470 185 201 minecraft:polished_blackstone_bricks
fill 470 173 212 470 185 213 minecraft:polished_blackstone_bricks
fill 471 173 223 472 185 223 minecraft:polished_blackstone_bricks
fill 478 173 181 479 185 181 minecraft:polished_blackstone_bricks
fill 483 173 223 484 185 223 minecraft:polished_blackstone_bricks
fill 490 173 181 491 185 181 minecraft:polished_blackstone_bricks
fill 495 173 223 496 185 223 minecraft:polished_blackstone_bricks
fill 502 173 181 503 185 181 minecraft:polished_blackstone_bricks
fill 507 173 223 508 185 223 minecraft:polished_blackstone_bricks
fill 512 173 183 512 185 184 minecraft:polished_blackstone_bricks
fill 512 173 195 512 185 196 minecraft:polished_blackstone_bricks
fill 512 173 207 512 185 208 minecraft:polished_blackstone_bricks
fill 512 173 219 512 185 220 minecraft:polished_blackstone_bricks
setblock 473 179 184 minecraft:light[level=12]
setblock 473 179 192 minecraft:light[level=12]
setblock 473 179 200 minecraft:light[level=12]
setblock 473 179 208 minecraft:light[level=12]
setblock 473 179 216 minecraft:light[level=12]
setblock 481 179 184 minecraft:light[level=12]
setblock 481 179 192 minecraft:light[level=12]
setblock 481 179 200 minecraft:light[level=12]
setblock 481 179 208 minecraft:light[level=12]
setblock 481 179 216 minecraft:light[level=12]
setblock 489 179 184 minecraft:light[level=12]
setblock 489 179 192 minecraft:light[level=12]
setblock 489 179 208 minecraft:light[level=12]
setblock 489 179 216 minecraft:light[level=12]
setblock 497 179 184 minecraft:light[level=12]
setblock 497 179 192 minecraft:light[level=12]
setblock 497 179 200 minecraft:light[level=12]
setblock 497 179 208 minecraft:light[level=12]
setblock 497 179 216 minecraft:light[level=12]
setblock 505 179 184 minecraft:light[level=12]
setblock 505 179 192 minecraft:light[level=12]
setblock 505 179 200 minecraft:light[level=12]
setblock 505 179 208 minecraft:light[level=12]
setblock 505 179 216 minecraft:light[level=12]
fill 472 180 191 472 185 193 minecraft:polished_blackstone
fill 472 180 203 472 185 205 minecraft:polished_blackstone
fill 472 180 215 472 185 217 minecraft:polished_blackstone
fill 478 180 221 480 185 221 minecraft:polished_blackstone
fill 482 180 183 484 185 183 minecraft:polished_blackstone
fill 490 180 221 492 185 221 minecraft:polished_blackstone
fill 494 180 183 496 185 183 minecraft:polished_blackstone
fill 502 180 221 504 185 221 minecraft:polished_blackstone
fill 506 180 183 508 185 183 minecraft:polished_blackstone
fill 510 180 191 510 185 193 minecraft:polished_blackstone
fill 510 180 203 510 185 205 minecraft:polished_blackstone
fill 510 180 215 510 185 217 minecraft:polished_blackstone
fill 471 185 185 471 185 190 minecraft:blackstone
fill 471 185 197 471 185 202 minecraft:blackstone
fill 471 185 209 471 185 214 minecraft:blackstone
fill 471 185 221 471 185 222 minecraft:blackstone
fill 472 185 222 475 185 222 minecraft:blackstone
fill 475 185 182 480 185 182 minecraft:blackstone
fill 482 185 222 487 185 222 minecraft:blackstone
fill 487 185 182 492 185 182 minecraft:blackstone
fill 494 185 222 499 185 222 minecraft:blackstone
fill 499 185 182 504 185 182 minecraft:blackstone
fill 506 185 222 511 185 222 minecraft:blackstone
fill 511 185 182 511 185 187 minecraft:blackstone
fill 511 185 194 511 185 199 minecraft:blackstone
fill 511 185 206 511 185 211 minecraft:blackstone
fill 511 185 218 511 185 221 minecraft:blackstone
fill 470 186 187 470 191 190 minecraft:soul_lantern
fill 470 186 199 470 191 202 minecraft:soul_lantern
fill 470 186 211 470 191 214 minecraft:soul_lantern
fill 470 186 223 473 191 223 minecraft:soul_lantern
fill 477 186 181 480 191 181 minecraft:soul_lantern
fill 482 186 223 485 191 223 minecraft:soul_lantern
fill 489 186 181 492 191 181 minecraft:soul_lantern
fill 494 186 223 497 191 223 minecraft:soul_lantern
fill 501 186 181 504 191 181 minecraft:soul_lantern
fill 506 186 223 509 191 223 minecraft:soul_lantern
fill 512 186 182 512 191 185 minecraft:soul_lantern
fill 512 186 194 512 191 197 minecraft:soul_lantern
fill 512 186 206 512 191 209 minecraft:soul_lantern
fill 512 186 218 512 191 221 minecraft:soul_lantern
setblock 473 187 184 minecraft:light[level=12]
setblock 473 187 192 minecraft:light[level=12]
setblock 473 187 200 minecraft:light[level=12]
setblock 473 187 208 minecraft:light[level=12]
setblock 473 187 216 minecraft:light[level=12]
setblock 481 187 184 minecraft:light[level=12]
setblock 481 187 192 minecraft:light[level=12]
setblock 481 187 200 minecraft:light[level=12]
setblock 481 187 208 minecraft:light[level=12]
setblock 481 187 216 minecraft:light[level=12]
setblock 489 187 184 minecraft:light[level=12]
setblock 489 187 192 minecraft:light[level=12]
setblock 489 187 208 minecraft:light[level=12]
setblock 489 187 216 minecraft:light[level=12]
setblock 497 187 184 minecraft:light[level=12]
setblock 497 187 192 minecraft:light[level=12]
setblock 497 187 200 minecraft:light[level=12]
setblock 497 187 208 minecraft:light[level=12]
setblock 497 187 216 minecraft:light[level=12]
setblock 505 187 184 minecraft:light[level=12]
setblock 505 187 192 minecraft:light[level=12]
setblock 505 187 200 minecraft:light[level=12]
setblock 505 187 208 minecraft:light[level=12]
setblock 505 187 216 minecraft:light[level=12]
fill 506 187 218 506 202 218 minecraft:polished_blackstone
fill 470 192 187 470 205 187 minecraft:polished_blackstone_bricks
fill 470 192 188 470 192 189 minecraft:soul_lantern
fill 470 192 190 470 205 190 minecraft:polished_blackstone_bricks
fill 470 192 199 470 205 199 minecraft:polished_blackstone_bricks
fill 470 192 200 470 192 201 minecraft:soul_lantern
fill 470 192 202 470 205 202 minecraft:polished_blackstone_bricks
fill 470 192 211 470 205 211 minecraft:polished_blackstone_bricks
fill 470 192 212 470 192 213 minecraft:soul_lantern
fill 470 192 214 470 205 214 minecraft:polished_blackstone_bricks
fill 470 192 223 470 205 223 minecraft:polished_blackstone_bricks
fill 471 192 223 472 192 223 minecraft:soul_lantern
fill 473 192 223 473 205 223 minecraft:polished_blackstone_bricks
fill 477 192 181 477 205 181 minecraft:polished_blackstone_bricks
fill 478 192 181 479 192 181 minecraft:soul_lantern
fill 480 192 181 480 205 181 minecraft:polished_blackstone_bricks
fill 482 192 223 482 205 223 minecraft:polished_blackstone_bricks
fill 483 192 223 484 192 223 minecraft:soul_lantern
fill 485 192 223 485 205 223 minecraft:polished_blackstone_bricks
fill 489 192 181 489 205 181 minecraft:polished_blackstone_bricks
fill 490 192 181 491 192 181 minecraft:soul_lantern
fill 492 192 181 492 205 181 minecraft:polished_blackstone_bricks
fill 494 192 223 494 205 223 minecraft:polished_blackstone_bricks
fill 495 192 223 496 192 223 minecraft:soul_lantern
fill 497 192 223 497 205 223 minecraft:polished_blackstone_bricks
fill 501 192 181 501 205 181 minecraft:polished_blackstone_bricks
fill 502 192 181 503 192 181 minecraft:soul_lantern
fill 504 192 181 504 205 181 minecraft:polished_blackstone_bricks
fill 506 192 223 506 205 223 minecraft:polished_blackstone_bricks
fill 507 192 223 508 192 223 minecraft:soul_lantern
fill 509 192 223 509 205 223 minecraft:polished_blackstone_bricks
fill 512 192 182 512 205 182 minecraft:polished_blackstone_bricks
fill 512 192 183 512 192 184 minecraft:soul_lantern
fill 512 192 185 512 205 185 minecraft:polished_blackstone_bricks
fill 512 192 194 512 205 194 minecraft:polished_blackstone_bricks
fill 512 192 195 512 192 196 minecraft:soul_lantern
fill 512 192 197 512 205 197 minecraft:polished_blackstone_bricks
fill 512 192 206 512 205 206 minecraft:polished_blackstone_bricks
fill 512 192 207 512 192 208 minecraft:soul_lantern
fill 512 192 209 512 205 209 minecraft:polished_blackstone_bricks
fill 512 192 218 512 205 218 minecraft:polished_blackstone_bricks
fill 512 192 219 512 192 220 minecraft:soul_lantern
fill 512 192 221 512 205 221 minecraft:polished_blackstone_bricks
fill 470 193 188 470 205 189 minecraft:polished_blackstone_bricks
fill 470 193 200 470 205 201 minecraft:polished_blackstone_bricks
fill 470 193 212 470 205 213 minecraft:polished_blackstone_bricks
fill 471 193 223 472 205 223 minecraft:polished_blackstone_bricks
fill 478 193 181 479 205 181 minecraft:polished_blackstone_bricks
fill 483 193 223 484 205 223 minecraft:polished_blackstone_bricks
fill 490 193 181 491 205 181 minecraft:polished_blackstone_bricks
fill 495 193 223 496 205 223 minecraft:polished_blackstone_bricks
fill 502 193 181 503 205 181 minecraft:polished_blackstone_bricks
fill 507 193 223 508 205 223 minecraft:polished_blackstone_bricks
fill 512 193 183 512 205 184 minecraft:polished_blackstone_bricks
fill 512 193 195 512 205 196 minecraft:polished_blackstone_bricks
fill 512 193 207 512 205 208 minecraft:polished_blackstone_bricks
fill 512 193 219 512 205 220 minecraft:polished_blackstone_bricks
setblock 473 195 184 minecraft:light[level=12]
setblock 473 195 192 minecraft:light[level=12]
setblock 473 195 200 minecraft:light[level=12]
setblock 473 195 208 minecraft:light[level=12]
setblock 473 195 216 minecraft:light[level=12]
setblock 481 195 184 minecraft:light[level=12]
setblock 481 195 192 minecraft:light[level=12]
setblock 481 195 200 minecraft:light[level=12]
setblock 481 195 208 minecraft:light[level=12]
setblock 481 195 216 minecraft:light[level=12]
setblock 489 195 184 minecraft:light[level=12]
setblock 489 195 192 minecraft:light[level=12]
setblock 489 195 208 minecraft:light[level=12]
setblock 489 195 216 minecraft:light[level=12]
setblock 497 195 184 minecraft:light[level=12]
setblock 497 195 192 minecraft:light[level=12]
setblock 497 195 200 minecraft:light[level=12]
setblock 497 195 208 minecraft:light[level=12]
setblock 497 195 216 minecraft:light[level=12]
setblock 505 195 184 minecraft:light[level=12]
setblock 505 195 192 minecraft:light[level=12]
setblock 505 195 200 minecraft:light[level=12]
setblock 505 195 208 minecraft:light[level=12]
setblock 505 195 216 minecraft:light[level=12]
fill 472 200 191 472 205 193 minecraft:polished_blackstone
fill 472 200 203 472 205 205 minecraft:polished_blackstone
fill 472 200 215 472 205 217 minecraft:polished_blackstone
fill 478 200 221 480 205 221 minecraft:polished_blackstone
fill 482 200 183 484 205 183 minecraft:polished_blackstone
fill 490 200 221 492 205 221 minecraft:polished_blackstone
fill 494 200 183 496 205 183 minecraft:polished_blackstone
fill 502 200 221 504 205 221 minecraft:polished_blackstone
fill 506 200 183 508 205 183 minecraft:polished_blackstone
fill 510 200 191 510 205 193 minecraft:polished_blackstone
fill 510 200 203 510 205 205 minecraft:polished_blackstone
fill 510 200 215 510 205 217 minecraft:polished_blackstone
setblock 473 203 184 minecraft:light[level=12]
setblock 473 203 192 minecraft:light[level=12]
setblock 473 203 200 minecraft:light[level=12]
setblock 473 203 208 minecraft:light[level=12]
setblock 473 203 216 minecraft:light[level=12]
setblock 481 203 184 minecraft:light[level=12]
setblock 481 203 192 minecraft:light[level=12]
setblock 481 203 200 minecraft:light[level=12]
setblock 481 203 208 minecraft:light[level=12]
setblock 481 203 216 minecraft:light[level=12]
setblock 489 203 184 minecraft:light[level=12]
setblock 489 203 192 minecraft:light[level=12]
setblock 489 203 208 minecraft:light[level=12]
setblock 489 203 216 minecraft:light[level=12]
setblock 497 203 184 minecraft:light[level=12]
setblock 497 203 192 minecraft:light[level=12]
setblock 497 203 200 minecraft:light[level=12]
setblock 497 203 208 minecraft:light[level=12]
setblock 497 203 216 minecraft:light[level=12]
setblock 505 203 184 minecraft:light[level=12]
setblock 505 203 192 minecraft:light[level=12]
setblock 505 203 200 minecraft:light[level=12]
setblock 505 203 208 minecraft:light[level=12]
setblock 505 203 216 minecraft:light[level=12]
fill 471 205 185 471 205 190 minecraft:blackstone
fill 471 205 197 471 205 202 minecraft:blackstone
fill 471 205 209 471 205 214 minecraft:blackstone
fill 471 205 221 471 205 222 minecraft:blackstone
fill 472 205 222 475 205 222 minecraft:blackstone
fill 475 205 182 480 205 182 minecraft:blackstone
fill 482 205 222 487 205 222 minecraft:blackstone
fill 487 205 182 492 205 182 minecraft:blackstone
fill 494 205 222 499 205 222 minecraft:blackstone
fill 499 205 182 504 205 182 minecraft:blackstone
fill 506 205 222 511 205 222 minecraft:blackstone
fill 511 205 182 511 205 187 minecraft:blackstone
fill 511 205 194 511 205 199 minecraft:blackstone
fill 511 205 206 511 205 211 minecraft:blackstone
fill 511 205 218 511 205 221 minecraft:blackstone
fill 470 206 187 470 211 190 minecraft:soul_lantern
fill 470 206 199 470 211 202 minecraft:soul_lantern
fill 470 206 211 470 211 214 minecraft:soul_lantern
fill 470 206 223 473 211 223 minecraft:soul_lantern
fill 477 206 181 480 211 181 minecraft:soul_lantern
fill 482 206 223 485 211 223 minecraft:soul_lantern
fill 489 206 181 492 211 181 minecraft:soul_lantern
fill 494 206 223 497 211 223 minecraft:soul_lantern
fill 501 206 181 504 211 181 minecraft:soul_lantern
fill 506 206 223 509 211 223 minecraft:soul_lantern
fill 512 206 182 512 211 185 minecraft:soul_lantern
fill 512 206 194 512 211 197 minecraft:soul_lantern
fill 512 206 206 512 211 209 minecraft:soul_lantern
fill 512 206 218 512 211 221 minecraft:soul_lantern
setblock 473 211 184 minecraft:light[level=12]
setblock 473 211 192 minecraft:light[level=12]
setblock 473 211 200 minecraft:light[level=12]
setblock 473 211 208 minecraft:light[level=12]
setblock 473 211 216 minecraft:light[level=12]
setblock 481 211 184 minecraft:light[level=12]
setblock 481 211 192 minecraft:light[level=12]
setblock 481 211 200 minecraft:light[level=12]
setblock 481 211 208 minecraft:light[level=12]
setblock 481 211 216 minecraft:light[level=12]
setblock 489 211 184 minecraft:light[level=12]
setblock 489 211 192 minecraft:light[level=12]
setblock 489 211 208 minecraft:light[level=12]
setblock 489 211 216 minecraft:light[level=12]
setblock 497 211 184 minecraft:light[level=12]
setblock 497 211 192 minecraft:light[level=12]
setblock 497 211 200 minecraft:light[level=12]
setblock 497 211 208 minecraft:light[level=12]
setblock 497 211 216 minecraft:light[level=12]
setblock 505 211 184 minecraft:light[level=12]
setblock 505 211 192 minecraft:light[level=12]
setblock 505 211 200 minecraft:light[level=12]
setblock 505 211 208 minecraft:light[level=12]
setblock 505 211 216 minecraft:light[level=12]
fill 470 212 187 470 225 187 minecraft:polished_blackstone_bricks
fill 470 212 188 470 212 189 minecraft:soul_lantern
fill 470 212 190 470 225 190 minecraft:polished_blackstone_bricks
fill 470 212 199 470 225 199 minecraft:polished_blackstone_bricks
fill 470 212 200 470 212 201 minecraft:soul_lantern
fill 470 212 202 470 225 202 minecraft:polished_blackstone_bricks
fill 470 212 211 470 225 211 minecraft:polished_blackstone_bricks
fill 470 212 212 470 212 213 minecraft:soul_lantern
fill 470 212 214 470 225 214 minecraft:polished_blackstone_bricks
fill 470 212 223 470 225 223 minecraft:polished_blackstone_bricks
fill 471 212 223 472 212 223 minecraft:soul_lantern
fill 473 212 223 473 225 223 minecraft:polished_blackstone_bricks
fill 477 212 181 477 225 181 minecraft:polished_blackstone_bricks
fill 478 212 181 479 212 181 minecraft:soul_lantern
fill 480 212 181 480 225 181 minecraft:polished_blackstone_bricks
fill 482 212 223 482 225 223 minecraft:polished_blackstone_bricks
fill 483 212 223 484 212 223 minecraft:soul_lantern
fill 485 212 223 485 225 223 minecraft:polished_blackstone_bricks
fill 489 212 181 489 225 181 minecraft:polished_blackstone_bricks
fill 490 212 181 491 212 181 minecraft:soul_lantern
fill 492 212 181 492 225 181 minecraft:polished_blackstone_bricks
fill 494 212 223 494 225 223 minecraft:polished_blackstone_bricks
fill 495 212 223 496 212 223 minecraft:soul_lantern
fill 497 212 223 497 225 223 minecraft:polished_blackstone_bricks
fill 501 212 181 501 225 181 minecraft:polished_blackstone_bricks
fill 502 212 181 503 212 181 minecraft:soul_lantern
fill 504 212 181 504 225 181 minecraft:polished_blackstone_bricks
fill 506 212 223 506 225 223 minecraft:polished_blackstone_bricks
fill 507 212 223 508 212 223 minecraft:soul_lantern
fill 509 212 223 509 225 223 minecraft:polished_blackstone_bricks
fill 512 212 182 512 225 182 minecraft:polished_blackstone_bricks
fill 512 212 183 512 212 184 minecraft:soul_lantern
fill 512 212 185 512 225 185 minecraft:polished_blackstone_bricks
fill 512 212 194 512 225 194 minecraft:polished_blackstone_bricks
fill 512 212 195 512 212 196 minecraft:soul_lantern
fill 512 212 197 512 225 197 minecraft:polished_blackstone_bricks
fill 512 212 206 512 225 206 minecraft:polished_blackstone_bricks
fill 512 212 207 512 212 208 minecraft:soul_lantern
fill 512 212 209 512 225 209 minecraft:polished_blackstone_bricks
fill 512 212 218 512 225 218 minecraft:polished_blackstone_bricks
fill 512 212 219 512 212 220 minecraft:soul_lantern
fill 512 212 221 512 225 221 minecraft:polished_blackstone_bricks
fill 470 213 188 470 225 189 minecraft:polished_blackstone_bricks
fill 470 213 200 470 225 201 minecraft:polished_blackstone_bricks
fill 470 213 212 470 225 213 minecraft:polished_blackstone_bricks
fill 471 213 223 472 225 223 minecraft:polished_blackstone_bricks
fill 478 213 181 479 225 181 minecraft:polished_blackstone_bricks
fill 483 213 223 484 225 223 minecraft:polished_blackstone_bricks
fill 490 213 181 491 225 181 minecraft:polished_blackstone_bricks
fill 495 213 223 496 225 223 minecraft:polished_blackstone_bricks
fill 502 213 181 503 225 181 minecraft:polished_blackstone_bricks
fill 507 213 223 508 225 223 minecraft:polished_blackstone_bricks
fill 512 213 183 512 225 184 minecraft:polished_blackstone_bricks
fill 512 213 195 512 225 196 minecraft:polished_blackstone_bricks
fill 512 213 207 512 225 208 minecraft:polished_blackstone_bricks
fill 512 213 219 512 225 220 minecraft:polished_blackstone_bricks
fill 471 218 182 471 219 192 minecraft:polished_blackstone_bricks
fill 471 218 193 511 219 193 minecraft:polished_blackstone
fill 471 218 194 471 219 204 minecraft:polished_blackstone_bricks
fill 471 218 205 511 218 205 minecraft:polished_blackstone
fill 471 218 206 471 219 216 minecraft:polished_blackstone_bricks
fill 471 218 217 511 219 217 minecraft:polished_blackstone
fill 471 218 218 471 219 222 minecraft:polished_blackstone_bricks
fill 472 218 182 472 219 192 minecraft:iron_block
fill 472 218 194 472 219 204 minecraft:iron_block
fill 472 218 206 472 219 216 minecraft:iron_block
fill 472 218 218 472 219 222 minecraft:iron_block
fill 473 218 182 473 219 192 minecraft:polished_blackstone_bricks
fill 473 218 194 473 219 204 minecraft:polished_blackstone_bricks
fill 473 218 206 473 219 216 minecraft:polished_blackstone_bricks
fill 473 218 218 473 219 222 minecraft:polished_blackstone_bricks
fill 474 218 182 474 219 192 minecraft:iron_block
fill 474 218 194 474 219 204 minecraft:iron_block
fill 474 218 206 474 219 216 minecraft:iron_block
fill 474 218 218 474 219 222 minecraft:iron_block
fill 475 218 182 475 219 192 minecraft:polished_blackstone_bricks
fill 475 218 194 475 219 204 minecraft:polished_blackstone_bricks
fill 475 218 206 475 219 216 minecraft:polished_blackstone_bricks
fill 475 218 218 475 219 222 minecraft:polished_blackstone_bricks
fill 476 218 182 476 219 192 minecraft:iron_block
fill 476 218 194 476 219 204 minecraft:iron_block
fill 476 218 206 476 219 216 minecraft:iron_block
fill 476 218 218 476 219 222 minecraft:iron_block
fill 477 218 182 477 219 192 minecraft:polished_blackstone_bricks
fill 477 218 194 477 219 204 minecraft:polished_blackstone_bricks
fill 477 218 206 477 219 216 minecraft:polished_blackstone_bricks
fill 477 218 218 477 219 222 minecraft:polished_blackstone_bricks
fill 478 218 182 478 219 192 minecraft:iron_block
fill 478 218 194 478 219 204 minecraft:iron_block
fill 478 218 206 478 219 216 minecraft:iron_block
fill 478 218 218 478 219 222 minecraft:iron_block
fill 479 218 182 479 219 192 minecraft:polished_blackstone_bricks
fill 479 218 194 479 219 204 minecraft:polished_blackstone_bricks
fill 479 218 206 479 219 216 minecraft:polished_blackstone_bricks
fill 479 218 218 479 219 222 minecraft:polished_blackstone_bricks
fill 480 218 182 480 219 192 minecraft:iron_block
fill 480 218 194 480 219 204 minecraft:iron_block
fill 480 218 206 480 219 216 minecraft:iron_block
fill 480 218 218 480 219 222 minecraft:iron_block
fill 481 218 182 481 219 192 minecraft:polished_blackstone_bricks
fill 481 218 194 481 219 204 minecraft:polished_blackstone_bricks
fill 481 218 206 481 219 216 minecraft:polished_blackstone_bricks
fill 481 218 218 481 219 222 minecraft:polished_blackstone_bricks
fill 482 218 182 482 219 192 minecraft:iron_block
fill 482 218 194 482 219 204 minecraft:iron_block
fill 482 218 206 482 219 216 minecraft:iron_block
fill 482 218 218 482 219 222 minecraft:iron_block
fill 483 218 182 483 219 192 minecraft:polished_blackstone_bricks
fill 483 218 194 483 219 204 minecraft:polished_blackstone_bricks
fill 483 218 206 483 219 216 minecraft:polished_blackstone_bricks
fill 483 218 218 483 219 222 minecraft:polished_blackstone_bricks
fill 484 218 182 484 219 192 minecraft:iron_block
fill 484 218 194 484 219 204 minecraft:iron_block
fill 484 218 206 484 219 216 minecraft:iron_block
fill 484 218 218 484 219 222 minecraft:iron_block
fill 485 218 182 485 219 192 minecraft:polished_blackstone_bricks
fill 485 218 194 485 219 204 minecraft:polished_blackstone_bricks
fill 485 218 206 485 219 216 minecraft:polished_blackstone_bricks
fill 485 218 218 485 219 222 minecraft:polished_blackstone_bricks
fill 486 218 182 486 219 192 minecraft:iron_block
fill 486 218 194 486 218 204 minecraft:iron_block
fill 486 218 206 486 219 216 minecraft:iron_block
fill 486 218 218 486 219 222 minecraft:iron_block
fill 487 218 182 487 219 192 minecraft:polished_blackstone_bricks
fill 487 218 194 487 218 200 minecraft:polished_blackstone_bricks
fill 487 218 202 487 218 204 minecraft:polished_blackstone_bricks
fill 487 218 206 487 219 216 minecraft:polished_blackstone_bricks
fill 487 218 218 487 219 222 minecraft:polished_blackstone_bricks
fill 488 218 182 488 219 192 minecraft:iron_block
fill 488 218 194 488 218 198 minecraft:iron_block
setblock 488 218 204 minecraft:iron_block
fill 488 218 206 488 219 216 minecraft:iron_block
fill 488 218 218 488 219 222 minecraft:iron_block
fill 489 218 182 489 219 192 minecraft:polished_blackstone_bricks
fill 489 218 194 489 218 198 minecraft:polished_blackstone_bricks
setblock 489 218 204 minecraft:polished_blackstone_bricks
fill 489 218 206 489 219 216 minecraft:polished_blackstone_bricks
fill 489 218 218 489 219 222 minecraft:polished_blackstone_bricks
fill 490 218 182 490 219 192 minecraft:iron_block
fill 490 218 194 490 218 197 minecraft:iron_block
fill 490 218 206 490 219 216 minecraft:iron_block
fill 490 218 218 490 219 222 minecraft:iron_block
fill 491 218 182 491 219 192 minecraft:polished_blackstone_bricks
fill 491 218 194 491 218 198 minecraft:polished_blackstone_bricks
setblock 491 218 204 minecraft:polished_blackstone_bricks
fill 491 218 206 491 219 216 minecraft:polished_blackstone_bricks
fill 491 218 218 491 219 222 minecraft:polished_blackstone_bricks
fill 492 218 182 492 219 192 minecraft:iron_block
fill 492 218 194 492 218 198 minecraft:iron_block
setblock 492 218 204 minecraft:iron_block
fill 492 218 206 492 219 216 minecraft:iron_block
fill 492 218 218 492 219 222 minecraft:iron_block
fill 493 218 182 493 219 192 minecraft:polished_blackstone_bricks
fill 493 218 194 493 218 200 minecraft:polished_blackstone_bricks
fill 493 218 202 493 218 204 minecraft:polished_blackstone_bricks
fill 493 218 206 493 219 216 minecraft:polished_blackstone_bricks
fill 493 218 218 493 219 222 minecraft:polished_blackstone_bricks
fill 494 218 182 494 219 192 minecraft:iron_block
fill 494 218 194 494 218 204 minecraft:iron_block
fill 494 218 206 494 219 216 minecraft:iron_block
fill 494 218 218 494 219 222 minecraft:iron_block
fill 495 218 182 495 219 192 minecraft:polished_blackstone_bricks
fill 495 218 194 495 219 204 minecraft:polished_blackstone_bricks
fill 495 218 206 495 219 216 minecraft:polished_blackstone_bricks
fill 495 218 218 495 219 222 minecraft:polished_blackstone_bricks
fill 496 218 182 496 219 192 minecraft:iron_block
fill 496 218 194 496 219 204 minecraft:iron_block
fill 496 218 206 496 219 216 minecraft:iron_block
fill 496 218 218 496 219 222 minecraft:iron_block
fill 497 218 182 497 219 192 minecraft:polished_blackstone_bricks
fill 497 218 194 497 219 204 minecraft:polished_blackstone_bricks
fill 497 218 206 497 219 216 minecraft:polished_blackstone_bricks
fill 497 218 218 497 219 222 minecraft:polished_blackstone_bricks
fill 498 218 182 498 219 192 minecraft:iron_block
fill 498 218 194 498 219 204 minecraft:iron_block
fill 498 218 206 498 219 216 minecraft:iron_block
fill 498 218 218 498 219 222 minecraft:iron_block
fill 499 218 182 499 219 192 minecraft:polished_blackstone_bricks
fill 499 218 194 499 219 204 minecraft:polished_blackstone_bricks
fill 499 218 206 499 219 216 minecraft:polished_blackstone_bricks
fill 499 218 218 499 219 222 minecraft:polished_blackstone_bricks
fill 500 218 182 500 219 192 minecraft:iron_block
fill 500 218 194 500 219 204 minecraft:iron_block
fill 500 218 206 500 219 216 minecraft:iron_block
fill 500 218 218 500 219 222 minecraft:iron_block
fill 501 218 182 501 219 192 minecraft:polished_blackstone_bricks
fill 501 218 194 501 219 204 minecraft:polished_blackstone_bricks
fill 501 218 206 501 219 216 minecraft:polished_blackstone_bricks
fill 501 218 218 501 219 222 minecraft:polished_blackstone_bricks
fill 502 218 182 502 219 192 minecraft:iron_block
fill 502 218 194 502 219 204 minecraft:iron_block
fill 502 218 206 502 219 216 minecraft:iron_block
fill 502 218 218 502 219 222 minecraft:iron_block
fill 503 218 182 503 219 192 minecraft:polished_blackstone_bricks
fill 503 218 194 503 219 204 minecraft:polished_blackstone_bricks
fill 503 218 206 503 219 216 minecraft:polished_blackstone_bricks
fill 503 218 218 503 219 222 minecraft:polished_blackstone_bricks
fill 504 218 182 504 219 192 minecraft:iron_block
fill 504 218 194 504 219 204 minecraft:iron_block
fill 504 218 206 504 219 216 minecraft:iron_block
fill 504 218 218 504 219 222 minecraft:iron_block
fill 505 218 182 505 219 192 minecraft:polished_blackstone_bricks
fill 505 218 194 505 219 204 minecraft:polished_blackstone_bricks
fill 505 218 206 505 219 216 minecraft:polished_blackstone_bricks
fill 505 218 218 505 219 222 minecraft:polished_blackstone_bricks
fill 506 218 182 506 219 192 minecraft:iron_block
fill 506 218 194 506 219 204 minecraft:iron_block
fill 506 218 206 506 219 216 minecraft:iron_block
fill 506 218 218 506 219 222 minecraft:iron_block
fill 507 218 182 507 219 192 minecraft:polished_blackstone_bricks
fill 507 218 194 507 219 204 minecraft:polished_blackstone_bricks
fill 507 218 206 507 219 216 minecraft:polished_blackstone_bricks
fill 507 218 218 507 219 222 minecraft:polished_blackstone_bricks
fill 508 218 182 508 219 192 minecraft:iron_block
fill 508 218 194 508 219 204 minecraft:iron_block
fill 508 218 206 508 219 216 minecraft:iron_block
fill 508 218 218 508 219 222 minecraft:iron_block
fill 509 218 182 509 219 192 minecraft:polished_blackstone_bricks
fill 509 218 194 509 219 204 minecraft:polished_blackstone_bricks
fill 509 218 206 509 219 216 minecraft:polished_blackstone_bricks
fill 509 218 218 509 219 222 minecraft:polished_blackstone_bricks
fill 510 218 182 510 219 192 minecraft:iron_block
fill 510 218 194 510 219 204 minecraft:iron_block
fill 510 218 206 510 219 216 minecraft:iron_block
fill 510 218 218 510 219 222 minecraft:iron_block
fill 511 218 182 511 219 192 minecraft:polished_blackstone_bricks
fill 511 218 194 511 219 204 minecraft:polished_blackstone_bricks
fill 511 218 206 511 219 216 minecraft:polished_blackstone_bricks
fill 511 218 218 511 219 222 minecraft:polished_blackstone_bricks
fill 471 219 205 488 219 205 minecraft:polished_blackstone
fill 486 219 194 486 219 199 minecraft:iron_block
fill 486 219 200 486 219 202 minecraft:soul_lantern
fill 486 219 203 486 219 204 minecraft:iron_block
fill 487 219 194 487 219 197 minecraft:polished_blackstone_bricks
fill 487 219 198 487 219 200 minecraft:soul_lantern
fill 487 219 202 487 219 204 minecraft:soul_lantern
fill 488 219 194 488 219 197 minecraft:iron_block
fill 488 219 198 489 219 198 minecraft:soul_lantern
fill 488 219 204 489 219 204 minecraft:soul_lantern
fill 489 219 194 489 219 196 minecraft:polished_blackstone_bricks
fill 489 219 197 491 219 197 minecraft:soul_lantern
fill 489 219 205 491 219 205 minecraft:soul_lantern
fill 490 219 194 490 219 196 minecraft:iron_block
fill 491 219 194 491 219 196 minecraft:polished_blackstone_bricks
fill 491 219 198 493 219 198 minecraft:soul_lantern
fill 491 219 204 493 219 204 minecraft:soul_lantern
fill 492 219 194 492 219 197 minecraft:iron_block
fill 492 219 205 511 219 205 minecraft:polished_blackstone
fill 493 219 194 493 219 197 minecraft:polished_blackstone_bricks
fill 493 219 199 493 219 200 minecraft:soul_lantern
fill 493 219 202 493 219 203 minecraft:soul_lantern
fill 494 219 194 494 219 199 minecraft:iron_block
fill 494 219 200 494 219 202 minecraft:soul_lantern
fill 494 219 203 494 219 204 minecraft:iron_block
fill 471 223 182 473 272 182 minecraft:polished_blackstone
fill 471 223 192 471 272 194 minecraft:polished_blackstone
fill 471 223 204 471 272 206 minecraft:polished_blackstone
fill 471 223 216 471 272 218 minecraft:polished_blackstone
fill 472 223 191 472 225 193 minecraft:polished_blackstone
fill 472 223 203 472 225 205 minecraft:polished_blackstone
fill 472 223 215 472 225 217 minecraft:polished_blackstone
fill 477 223 222 479 272 222 minecraft:polished_blackstone
fill 478 223 221 480 225 221 minecraft:polished_blackstone
fill 482 223 183 484 225 183 minecraft:polished_blackstone
fill 483 223 182 485 272 182 minecraft:polished_blackstone
fill 489 223 222 491 272 222 minecraft:polished_blackstone
fill 490 223 221 492 225 221 minecraft:polished_blackstone
fill 494 223 183 496 225 183 minecraft:polished_blackstone
fill 495 223 182 497 272 182 minecraft:polished_blackstone
fill 501 223 222 503 272 222 minecraft:polished_blackstone
fill 502 223 221 504 225 221 minecraft:polished_blackstone
fill 506 223 183 508 225 183 minecraft:polished_blackstone
fill 507 223 182 509 272 182 minecraft:polished_blackstone
fill 510 223 191 510 225 193 minecraft:polished_blackstone
fill 510 223 203 510 225 205 minecraft:polished_blackstone
fill 510 223 215 510 225 217 minecraft:polished_blackstone
fill 511 223 190 511 272 192 minecraft:polished_blackstone
fill 511 223 202 511 272 204 minecraft:polished_blackstone
fill 511 223 214 511 272 216 minecraft:polished_blackstone
fill 471 225 185 471 225 190 minecraft:blackstone
fill 471 225 197 471 225 202 minecraft:blackstone
fill 471 225 209 471 225 214 minecraft:blackstone
fill 471 225 221 471 225 222 minecraft:blackstone
fill 472 225 222 475 225 222 minecraft:blackstone
fill 475 225 182 480 225 182 minecraft:blackstone
fill 482 225 222 487 225 222 minecraft:blackstone
fill 487 225 182 492 225 182 minecraft:blackstone
fill 494 225 222 499 225 222 minecraft:blackstone
fill 499 225 182 504 225 182 minecraft:blackstone
fill 506 225 222 511 225 222 minecraft:blackstone
fill 511 225 182 511 225 187 minecraft:blackstone
fill 511 225 194 511 225 199 minecraft:blackstone
fill 511 225 206 511 225 211 minecraft:blackstone
fill 511 225 218 511 225 221 minecraft:blackstone
fill 470 226 187 470 231 190 minecraft:soul_lantern
fill 470 226 199 470 231 202 minecraft:soul_lantern
fill 470 226 211 470 231 214 minecraft:soul_lantern
fill 470 226 223 473 231 223 minecraft:soul_lantern
fill 477 226 181 480 231 181 minecraft:soul_lantern
fill 482 226 223 485 231 223 minecraft:soul_lantern
fill 489 226 181 492 231 181 minecraft:soul_lantern
fill 494 226 223 497 231 223 minecraft:soul_lantern
fill 501 226 181 504 231 181 minecraft:soul_lantern
fill 506 226 223 509 231 223 minecraft:soul_lantern
fill 512 226 182 512 231 185 minecraft:soul_lantern
fill 512 226 194 512 231 197 minecraft:soul_lantern
fill 512 226 206 512 231 209 minecraft:soul_lantern
fill 512 226 218 512 231 221 minecraft:soul_lantern
setblock 473 227 184 minecraft:light[level=12]
setblock 473 227 192 minecraft:light[level=12]
setblock 473 227 200 minecraft:light[level=12]
setblock 473 227 208 minecraft:light[level=12]
setblock 473 227 216 minecraft:light[level=12]
setblock 481 227 184 minecraft:light[level=12]
setblock 481 227 192 minecraft:light[level=12]
setblock 481 227 200 minecraft:light[level=12]
setblock 481 227 208 minecraft:light[level=12]
setblock 481 227 216 minecraft:light[level=12]
setblock 489 227 184 minecraft:light[level=12]
setblock 489 227 192 minecraft:light[level=12]
setblock 489 227 200 minecraft:light[level=12]
setblock 489 227 208 minecraft:light[level=12]
setblock 489 227 216 minecraft:light[level=12]
setblock 497 227 184 minecraft:light[level=12]
setblock 497 227 192 minecraft:light[level=12]
setblock 497 227 200 minecraft:light[level=12]
setblock 497 227 208 minecraft:light[level=12]
setblock 497 227 216 minecraft:light[level=12]
setblock 505 227 184 minecraft:light[level=12]
setblock 505 227 192 minecraft:light[level=12]
setblock 505 227 200 minecraft:light[level=12]
setblock 505 227 208 minecraft:light[level=12]
setblock 505 227 216 minecraft:light[level=12]
fill 470 232 187 470 245 187 minecraft:polished_blackstone_bricks
fill 470 232 188 470 232 189 minecraft:soul_lantern
fill 470 232 190 470 245 190 minecraft:polished_blackstone_bricks
fill 470 232 199 470 245 199 minecraft:polished_blackstone_bricks
fill 470 232 200 470 232 201 minecraft:soul_lantern
fill 470 232 202 470 245 202 minecraft:polished_blackstone_bricks
fill 470 232 211 470 245 211 minecraft:polished_blackstone_bricks
fill 470 232 212 470 232 213 minecraft:soul_lantern
fill 470 232 214 470 245 214 minecraft:polished_blackstone_bricks
fill 470 232 223 470 245 223 minecraft:polished_blackstone_bricks
fill 471 232 223 472 232 223 minecraft:soul_lantern
fill 473 232 223 473 245 223 minecraft:polished_blackstone_bricks
fill 477 232 181 477 245 181 minecraft:polished_blackstone_bricks
fill 478 232 181 479 232 181 minecraft:soul_lantern
fill 480 232 181 480 245 181 minecraft:polished_blackstone_bricks
fill 482 232 223 482 245 223 minecraft:polished_blackstone_bricks
fill 483 232 223 484 232 223 minecraft:soul_lantern
fill 485 232 223 485 245 223 minecraft:polished_blackstone_bricks
fill 489 232 181 489 245 181 minecraft:polished_blackstone_bricks
fill 490 232 181 491 232 181 minecraft:soul_lantern
fill 492 232 181 492 245 181 minecraft:polished_blackstone_bricks
fill 494 232 223 494 245 223 minecraft:polished_blackstone_bricks
fill 495 232 223 496 232 223 minecraft:soul_lantern
fill 497 232 223 497 245 223 minecraft:polished_blackstone_bricks
fill 501 232 181 501 245 181 minecraft:polished_blackstone_bricks
fill 502 232 181 503 232 181 minecraft:soul_lantern
fill 504 232 181 504 245 181 minecraft:polished_blackstone_bricks
fill 506 232 223 506 245 223 minecraft:polished_blackstone_bricks
fill 507 232 223 508 232 223 minecraft:soul_lantern
fill 509 232 223 509 245 223 minecraft:polished_blackstone_bricks
fill 512 232 182 512 245 182 minecraft:polished_blackstone_bricks
fill 512 232 183 512 232 184 minecraft:soul_lantern
fill 512 232 185 512 245 185 minecraft:polished_blackstone_bricks
fill 512 232 194 512 245 194 minecraft:polished_blackstone_bricks
fill 512 232 195 512 232 196 minecraft:soul_lantern
fill 512 232 197 512 245 197 minecraft:polished_blackstone_bricks
fill 512 232 206 512 245 206 minecraft:polished_blackstone_bricks
fill 512 232 207 512 232 208 minecraft:soul_lantern
fill 512 232 209 512 245 209 minecraft:polished_blackstone_bricks
fill 512 232 218 512 245 218 minecraft:polished_blackstone_bricks
fill 512 232 219 512 232 220 minecraft:soul_lantern
fill 512 232 221 512 245 221 minecraft:polished_blackstone_bricks
fill 470 233 188 470 245 189 minecraft:polished_blackstone_bricks
fill 470 233 200 470 245 201 minecraft:polished_blackstone_bricks
fill 470 233 212 470 245 213 minecraft:polished_blackstone_bricks
fill 471 233 223 472 245 223 minecraft:polished_blackstone_bricks
fill 478 233 181 479 245 181 minecraft:polished_blackstone_bricks
fill 483 233 223 484 245 223 minecraft:polished_blackstone_bricks
fill 490 233 181 491 245 181 minecraft:polished_blackstone_bricks
fill 495 233 223 496 245 223 minecraft:polished_blackstone_bricks
fill 502 233 181 503 245 181 minecraft:polished_blackstone_bricks
fill 507 233 223 508 245 223 minecraft:polished_blackstone_bricks
fill 512 233 183 512 245 184 minecraft:polished_blackstone_bricks
fill 512 233 195 512 245 196 minecraft:polished_blackstone_bricks
fill 512 233 207 512 245 208 minecraft:polished_blackstone_bricks
fill 512 233 219 512 245 220 minecraft:polished_blackstone_bricks
setblock 473 235 184 minecraft:light[level=12]
setblock 473 235 192 minecraft:light[level=12]
setblock 473 235 200 minecraft:light[level=12]
setblock 473 235 208 minecraft:light[level=12]
setblock 473 235 216 minecraft:light[level=12]
setblock 481 235 184 minecraft:light[level=12]
setblock 481 235 192 minecraft:light[level=12]
setblock 481 235 200 minecraft:light[level=12]
setblock 481 235 208 minecraft:light[level=12]
setblock 481 235 216 minecraft:light[level=12]
setblock 489 235 184 minecraft:light[level=12]
setblock 489 235 192 minecraft:light[level=12]
setblock 489 235 200 minecraft:light[level=12]
setblock 489 235 208 minecraft:light[level=12]
setblock 489 235 216 minecraft:light[level=12]
setblock 497 235 184 minecraft:light[level=12]
setblock 497 235 192 minecraft:light[level=12]
setblock 497 235 200 minecraft:light[level=12]
setblock 497 235 208 minecraft:light[level=12]
setblock 497 235 216 minecraft:light[level=12]
setblock 505 235 184 minecraft:light[level=12]
setblock 505 235 192 minecraft:light[level=12]
setblock 505 235 200 minecraft:light[level=12]
setblock 505 235 208 minecraft:light[level=12]
setblock 505 235 216 minecraft:light[level=12]
fill 472 240 191 472 245 193 minecraft:polished_blackstone
fill 472 240 203 472 245 205 minecraft:polished_blackstone
fill 472 240 215 472 245 217 minecraft:polished_blackstone
fill 478 240 221 480 245 221 minecraft:polished_blackstone
fill 482 240 183 484 245 183 minecraft:polished_blackstone
fill 490 240 221 492 245 221 minecraft:polished_blackstone
fill 494 240 183 496 245 183 minecraft:polished_blackstone
fill 502 240 221 504 245 221 minecraft:polished_blackstone
fill 506 240 183 508 245 183 minecraft:polished_blackstone
fill 510 240 191 510 245 193 minecraft:polished_blackstone
fill 510 240 203 510 245 205 minecraft:polished_blackstone
fill 510 240 215 510 245 217 minecraft:polished_blackstone
setblock 473 243 184 minecraft:light[level=12]
setblock 473 243 192 minecraft:light[level=12]
setblock 473 243 200 minecraft:light[level=12]
setblock 473 243 208 minecraft:light[level=12]
setblock 473 243 216 minecraft:light[level=12]
setblock 481 243 184 minecraft:light[level=12]
setblock 481 243 192 minecraft:light[level=12]
setblock 481 243 200 minecraft:light[level=12]
setblock 481 243 208 minecraft:light[level=12]
setblock 481 243 216 minecraft:light[level=12]
setblock 489 243 184 minecraft:light[level=12]
setblock 489 243 192 minecraft:light[level=12]
setblock 489 243 200 minecraft:light[level=12]
setblock 489 243 208 minecraft:light[level=12]
setblock 489 243 216 minecraft:light[level=12]
setblock 497 243 184 minecraft:light[level=12]
setblock 497 243 192 minecraft:light[level=12]
setblock 497 243 200 minecraft:light[level=12]
setblock 497 243 208 minecraft:light[level=12]
setblock 497 243 216 minecraft:light[level=12]
setblock 505 243 184 minecraft:light[level=12]
setblock 505 243 192 minecraft:light[level=12]
setblock 505 243 200 minecraft:light[level=12]
setblock 505 243 208 minecraft:light[level=12]
setblock 505 243 216 minecraft:light[level=12]
fill 471 245 185 471 245 190 minecraft:blackstone
fill 471 245 197 471 245 202 minecraft:blackstone
fill 471 245 209 471 245 214 minecraft:blackstone
fill 471 245 221 471 245 222 minecraft:blackstone
fill 472 245 222 475 245 222 minecraft:blackstone
fill 475 245 182 480 245 182 minecraft:blackstone
fill 482 245 222 487 245 222 minecraft:blackstone
fill 487 245 182 492 245 182 minecraft:blackstone
fill 494 245 222 499 245 222 minecraft:blackstone
fill 499 245 182 504 245 182 minecraft:blackstone
fill 506 245 222 511 245 222 minecraft:blackstone
fill 511 245 182 511 245 187 minecraft:blackstone
fill 511 245 194 511 245 199 minecraft:blackstone
fill 511 245 206 511 245 211 minecraft:blackstone
fill 511 245 218 511 245 221 minecraft:blackstone
fill 470 246 187 470 251 190 minecraft:soul_lantern
fill 470 246 199 470 251 202 minecraft:soul_lantern
fill 470 246 211 470 251 214 minecraft:soul_lantern
fill 470 246 223 473 251 223 minecraft:soul_lantern
fill 477 246 181 480 251 181 minecraft:soul_lantern
fill 482 246 223 485 251 223 minecraft:soul_lantern
fill 489 246 181 492 251 181 minecraft:soul_lantern
fill 494 246 223 497 251 223 minecraft:soul_lantern
fill 501 246 181 504 251 181 minecraft:soul_lantern
fill 506 246 223 509 251 223 minecraft:soul_lantern
fill 512 246 182 512 251 185 minecraft:soul_lantern
fill 512 246 194 512 251 197 minecraft:soul_lantern
fill 512 246 206 512 251 209 minecraft:soul_lantern
fill 512 246 218 512 251 221 minecraft:soul_lantern
fill 479 247 183 479 268 183 minecraft:iron_block
setblock 473 251 184 minecraft:light[level=12]
setblock 473 251 192 minecraft:light[level=12]
setblock 473 251 200 minecraft:light[level=12]
setblock 473 251 208 minecraft:light[level=12]
setblock 473 251 216 minecraft:light[level=12]
setblock 481 251 184 minecraft:light[level=12]
setblock 481 251 192 minecraft:light[level=12]
setblock 481 251 200 minecraft:light[level=12]
setblock 481 251 208 minecraft:light[level=12]
setblock 481 251 216 minecraft:light[level=12]
setblock 489 251 184 minecraft:light[level=12]
setblock 489 251 192 minecraft:light[level=12]
setblock 489 251 200 minecraft:light[level=12]
setblock 489 251 208 minecraft:light[level=12]
setblock 489 251 216 minecraft:light[level=12]
setblock 497 251 184 minecraft:light[level=12]
setblock 497 251 192 minecraft:light[level=12]
setblock 497 251 200 minecraft:light[level=12]
setblock 497 251 208 minecraft:light[level=12]
setblock 497 251 216 minecraft:light[level=12]
setblock 505 251 184 minecraft:light[level=12]
setblock 505 251 192 minecraft:light[level=12]
setblock 505 251 200 minecraft:light[level=12]
setblock 505 251 208 minecraft:light[level=12]
setblock 505 251 216 minecraft:light[level=12]
fill 470 252 187 470 265 187 minecraft:polished_blackstone_bricks
fill 470 252 188 470 252 189 minecraft:soul_lantern
fill 470 252 190 470 265 190 minecraft:polished_blackstone_bricks
fill 470 252 199 470 265 199 minecraft:polished_blackstone_bricks
fill 470 252 200 470 252 201 minecraft:soul_lantern
fill 470 252 202 470 265 202 minecraft:polished_blackstone_bricks
fill 470 252 211 470 265 211 minecraft:polished_blackstone_bricks
fill 470 252 212 470 252 213 minecraft:soul_lantern
fill 470 252 214 470 265 214 minecraft:polished_blackstone_bricks
fill 470 252 223 470 265 223 minecraft:polished_blackstone_bricks
fill 471 252 223 472 252 223 minecraft:soul_lantern
fill 473 252 223 473 265 223 minecraft:polished_blackstone_bricks
fill 477 252 181 477 265 181 minecraft:polished_blackstone_bricks
fill 478 252 181 479 252 181 minecraft:soul_lantern
fill 480 252 181 480 265 181 minecraft:polished_blackstone_bricks
fill 482 252 223 482 265 223 minecraft:polished_blackstone_bricks
fill 483 252 223 484 252 223 minecraft:soul_lantern
fill 485 252 223 485 265 223 minecraft:polished_blackstone_bricks
fill 489 252 181 489 265 181 minecraft:polished_blackstone_bricks
fill 490 252 181 491 252 181 minecraft:soul_lantern
fill 492 252 181 492 265 181 minecraft:polished_blackstone_bricks
fill 494 252 223 494 265 223 minecraft:polished_blackstone_bricks
fill 495 252 223 496 252 223 minecraft:soul_lantern
fill 497 252 223 497 265 223 minecraft:polished_blackstone_bricks
fill 501 252 181 501 265 181 minecraft:polished_blackstone_bricks
fill 502 252 181 503 252 181 minecraft:soul_lantern
fill 504 252 181 504 265 181 minecraft:polished_blackstone_bricks
fill 506 252 223 506 265 223 minecraft:polished_blackstone_bricks
fill 507 252 223 508 252 223 minecraft:soul_lantern
fill 509 252 223 509 265 223 minecraft:polished_blackstone_bricks
fill 512 252 182 512 265 182 minecraft:polished_blackstone_bricks
fill 512 252 183 512 252 184 minecraft:soul_lantern
fill 512 252 185 512 265 185 minecraft:polished_blackstone_bricks
fill 512 252 194 512 265 194 minecraft:polished_blackstone_bricks
fill 512 252 195 512 252 196 minecraft:soul_lantern
fill 512 252 197 512 265 197 minecraft:polished_blackstone_bricks
fill 512 252 206 512 265 206 minecraft:polished_blackstone_bricks
fill 512 252 207 512 252 208 minecraft:soul_lantern
fill 512 252 209 512 265 209 minecraft:polished_blackstone_bricks
fill 512 252 218 512 265 218 minecraft:polished_blackstone_bricks
fill 512 252 219 512 252 220 minecraft:soul_lantern
fill 512 252 221 512 265 221 minecraft:polished_blackstone_bricks
fill 470 253 188 470 265 189 minecraft:polished_blackstone_bricks
fill 470 253 200 470 265 201 minecraft:polished_blackstone_bricks
fill 470 253 212 470 265 213 minecraft:polished_blackstone_bricks
fill 471 253 223 472 265 223 minecraft:polished_blackstone_bricks
fill 478 253 181 479 265 181 minecraft:polished_blackstone_bricks
fill 483 253 223 484 265 223 minecraft:polished_blackstone_bricks
fill 490 253 181 491 265 181 minecraft:polished_blackstone_bricks
fill 495 253 223 496 265 223 minecraft:polished_blackstone_bricks
fill 502 253 181 503 265 181 minecraft:polished_blackstone_bricks
fill 507 253 223 508 265 223 minecraft:polished_blackstone_bricks
fill 512 253 183 512 265 184 minecraft:polished_blackstone_bricks
fill 512 253 195 512 265 196 minecraft:polished_blackstone_bricks
fill 512 253 207 512 265 208 minecraft:polished_blackstone_bricks
fill 512 253 219 512 265 220 minecraft:polished_blackstone_bricks
setblock 473 259 184 minecraft:light[level=12]
setblock 473 259 192 minecraft:light[level=12]
setblock 473 259 200 minecraft:light[level=12]
setblock 473 259 208 minecraft:light[level=12]
setblock 473 259 216 minecraft:light[level=12]
setblock 481 259 184 minecraft:light[level=12]
setblock 481 259 192 minecraft:light[level=12]
setblock 481 259 200 minecraft:light[level=12]
setblock 481 259 208 minecraft:light[level=12]
setblock 481 259 216 minecraft:light[level=12]
setblock 489 259 184 minecraft:light[level=12]
setblock 489 259 192 minecraft:light[level=12]
setblock 489 259 200 minecraft:light[level=12]
setblock 489 259 208 minecraft:light[level=12]
setblock 489 259 216 minecraft:light[level=12]
setblock 497 259 184 minecraft:light[level=12]
setblock 497 259 192 minecraft:light[level=12]
setblock 497 259 200 minecraft:light[level=12]
setblock 497 259 208 minecraft:light[level=12]
setblock 497 259 216 minecraft:light[level=12]
setblock 505 259 184 minecraft:light[level=12]
setblock 505 259 192 minecraft:light[level=12]
setblock 505 259 200 minecraft:light[level=12]
setblock 505 259 208 minecraft:light[level=12]
setblock 505 259 216 minecraft:light[level=12]
fill 472 260 191 472 265 193 minecraft:polished_blackstone
fill 472 260 203 472 265 205 minecraft:polished_blackstone
fill 472 260 215 472 265 217 minecraft:polished_blackstone
fill 478 260 221 480 265 221 minecraft:polished_blackstone
fill 482 260 183 484 265 183 minecraft:polished_blackstone
fill 490 260 221 492 265 221 minecraft:polished_blackstone
fill 494 260 183 496 265 183 minecraft:polished_blackstone
fill 502 260 221 504 265 221 minecraft:polished_blackstone
fill 506 260 183 508 265 183 minecraft:polished_blackstone
fill 510 260 191 510 265 193 minecraft:polished_blackstone
fill 510 260 203 510 265 205 minecraft:polished_blackstone
fill 510 260 215 510 265 217 minecraft:polished_blackstone
fill 471 265 185 471 265 190 minecraft:blackstone
fill 471 265 197 471 265 202 minecraft:blackstone
fill 471 265 209 471 265 214 minecraft:blackstone
fill 471 265 221 471 265 222 minecraft:blackstone
fill 472 265 222 475 265 222 minecraft:blackstone
fill 475 265 182 480 265 182 minecraft:blackstone
fill 482 265 222 487 265 222 minecraft:blackstone
fill 487 265 182 492 265 182 minecraft:blackstone
fill 494 265 222 499 265 222 minecraft:blackstone
fill 499 265 182 504 265 182 minecraft:blackstone
fill 506 265 222 511 265 222 minecraft:blackstone
fill 511 265 182 511 265 187 minecraft:blackstone
fill 511 265 194 511 265 199 minecraft:blackstone
fill 511 265 206 511 265 211 minecraft:blackstone
fill 511 265 218 511 265 221 minecraft:blackstone
fill 470 266 187 470 271 190 minecraft:soul_lantern
fill 470 266 199 470 271 202 minecraft:soul_lantern
fill 470 266 211 470 271 214 minecraft:soul_lantern
fill 470 266 223 473 271 223 minecraft:soul_lantern
fill 477 266 181 480 271 181 minecraft:soul_lantern
fill 482 266 223 485 271 223 minecraft:soul_lantern
fill 489 266 181 492 271 181 minecraft:soul_lantern
fill 494 266 223 497 271 223 minecraft:soul_lantern
fill 501 266 181 504 271 181 minecraft:soul_lantern
fill 506 266 223 509 271 223 minecraft:soul_lantern
fill 512 266 182 512 271 185 minecraft:soul_lantern
fill 512 266 194 512 271 197 minecraft:soul_lantern
fill 512 266 206 512 271 209 minecraft:soul_lantern
fill 512 266 218 512 271 221 minecraft:soul_lantern
setblock 473 267 184 minecraft:light[level=12]
setblock 473 267 192 minecraft:light[level=12]
setblock 473 267 200 minecraft:light[level=12]
setblock 473 267 208 minecraft:light[level=12]
setblock 473 267 216 minecraft:light[level=12]
setblock 481 267 184 minecraft:light[level=12]
setblock 481 267 192 minecraft:light[level=12]
setblock 481 267 200 minecraft:light[level=12]
setblock 481 267 208 minecraft:light[level=12]
setblock 481 267 216 minecraft:light[level=12]
setblock 489 267 184 minecraft:light[level=12]
setblock 489 267 192 minecraft:light[level=12]
setblock 489 267 200 minecraft:light[level=12]
setblock 489 267 208 minecraft:light[level=12]
setblock 489 267 216 minecraft:light[level=12]
setblock 497 267 184 minecraft:light[level=12]
setblock 497 267 192 minecraft:light[level=12]
setblock 497 267 200 minecraft:light[level=12]
setblock 497 267 208 minecraft:light[level=12]
setblock 497 267 216 minecraft:light[level=12]
setblock 505 267 184 minecraft:light[level=12]
setblock 505 267 192 minecraft:light[level=12]
setblock 505 267 200 minecraft:light[level=12]
setblock 505 267 208 minecraft:light[level=12]
setblock 505 267 216 minecraft:light[level=12]
fill 470 272 187 470 285 187 minecraft:polished_blackstone_bricks
fill 470 272 188 470 272 189 minecraft:soul_lantern
fill 470 272 190 470 285 190 minecraft:polished_blackstone_bricks
fill 470 272 199 470 285 199 minecraft:polished_blackstone_bricks
fill 470 272 200 470 272 201 minecraft:soul_lantern
fill 470 272 202 470 285 202 minecraft:polished_blackstone_bricks
fill 470 272 211 470 285 211 minecraft:polished_blackstone_bricks
fill 470 272 212 470 272 213 minecraft:soul_lantern
fill 470 272 214 470 285 214 minecraft:polished_blackstone_bricks
fill 470 272 223 470 285 223 minecraft:polished_blackstone_bricks
fill 471 272 223 472 272 223 minecraft:soul_lantern
fill 473 272 223 473 285 223 minecraft:polished_blackstone_bricks
fill 477 272 181 477 285 181 minecraft:polished_blackstone_bricks
fill 478 272 181 479 272 181 minecraft:soul_lantern
fill 480 272 181 480 285 181 minecraft:polished_blackstone_bricks
fill 482 272 223 482 285 223 minecraft:polished_blackstone_bricks
fill 483 272 223 484 272 223 minecraft:soul_lantern
fill 485 272 223 485 285 223 minecraft:polished_blackstone_bricks
fill 489 272 181 489 285 181 minecraft:polished_blackstone_bricks
fill 490 272 181 491 272 181 minecraft:soul_lantern
fill 492 272 181 492 285 181 minecraft:polished_blackstone_bricks
fill 494 272 223 494 285 223 minecraft:polished_blackstone_bricks
fill 495 272 223 496 272 223 minecraft:soul_lantern
fill 497 272 223 497 285 223 minecraft:polished_blackstone_bricks
fill 501 272 181 501 285 181 minecraft:polished_blackstone_bricks
fill 502 272 181 503 272 181 minecraft:soul_lantern
fill 504 272 181 504 285 181 minecraft:polished_blackstone_bricks
fill 506 272 223 506 285 223 minecraft:polished_blackstone_bricks
fill 507 272 223 508 272 223 minecraft:soul_lantern
fill 509 272 223 509 285 223 minecraft:polished_blackstone_bricks
fill 512 272 182 512 285 182 minecraft:polished_blackstone_bricks
fill 512 272 183 512 272 184 minecraft:soul_lantern
fill 512 272 185 512 285 185 minecraft:polished_blackstone_bricks
fill 512 272 194 512 285 194 minecraft:polished_blackstone_bricks
fill 512 272 195 512 272 196 minecraft:soul_lantern
fill 512 272 197 512 285 197 minecraft:polished_blackstone_bricks
fill 512 272 206 512 285 206 minecraft:polished_blackstone_bricks
fill 512 272 207 512 272 208 minecraft:soul_lantern
fill 512 272 209 512 285 209 minecraft:polished_blackstone_bricks
fill 512 272 218 512 285 218 minecraft:polished_blackstone_bricks
fill 512 272 219 512 272 220 minecraft:soul_lantern
fill 512 272 221 512 285 221 minecraft:polished_blackstone_bricks
fill 470 273 188 470 285 189 minecraft:polished_blackstone_bricks
fill 470 273 200 470 285 201 minecraft:polished_blackstone_bricks
fill 470 273 212 470 285 213 minecraft:polished_blackstone_bricks
fill 471 273 223 472 285 223 minecraft:polished_blackstone_bricks
fill 478 273 181 479 285 181 minecraft:polished_blackstone_bricks
fill 483 273 223 484 285 223 minecraft:polished_blackstone_bricks
fill 490 273 181 491 285 181 minecraft:polished_blackstone_bricks
fill 495 273 223 496 285 223 minecraft:polished_blackstone_bricks
fill 502 273 181 503 285 181 minecraft:polished_blackstone_bricks
fill 507 273 223 508 285 223 minecraft:polished_blackstone_bricks
fill 512 273 183 512 285 184 minecraft:polished_blackstone_bricks
fill 512 273 195 512 285 196 minecraft:polished_blackstone_bricks
fill 512 273 207 512 285 208 minecraft:polished_blackstone_bricks
fill 512 273 219 512 285 220 minecraft:polished_blackstone_bricks
setblock 473 275 184 minecraft:light[level=12]
setblock 473 275 192 minecraft:light[level=12]
setblock 473 275 200 minecraft:light[level=12]
setblock 473 275 208 minecraft:light[level=12]
setblock 473 275 216 minecraft:light[level=12]
setblock 481 275 184 minecraft:light[level=12]
setblock 481 275 192 minecraft:light[level=12]
setblock 481 275 200 minecraft:light[level=12]
setblock 481 275 208 minecraft:light[level=12]
setblock 481 275 216 minecraft:light[level=12]
setblock 489 275 184 minecraft:light[level=12]
setblock 489 275 192 minecraft:light[level=12]
setblock 489 275 200 minecraft:light[level=12]
setblock 489 275 208 minecraft:light[level=12]
setblock 489 275 216 minecraft:light[level=12]
setblock 497 275 184 minecraft:light[level=12]
setblock 497 275 192 minecraft:light[level=12]
setblock 497 275 200 minecraft:light[level=12]
setblock 497 275 208 minecraft:light[level=12]
setblock 497 275 216 minecraft:light[level=12]
setblock 505 275 184 minecraft:light[level=12]
setblock 505 275 192 minecraft:light[level=12]
setblock 505 275 200 minecraft:light[level=12]
setblock 505 275 208 minecraft:light[level=12]
setblock 505 275 216 minecraft:light[level=12]
fill 481 277 202 481 281 202 minecraft:iron_block
fill 493 277 190 493 281 190 minecraft:polished_blackstone
fill 493 277 214 493 281 214 minecraft:polished_blackstone
fill 505 277 202 505 281 202 minecraft:iron_block
fill 480 278 198 480 280 202 minecraft:iron_block
fill 480 278 203 482 280 206 minecraft:polished_blackstone
fill 481 278 196 482 280 201 minecraft:iron_block
fill 481 278 207 484 280 208 minecraft:polished_blackstone
fill 482 278 194 485 280 195 minecraft:iron_block
fill 482 278 202 482 280 202 minecraft:iron_block
fill 482 278 209 485 280 210 minecraft:polished_blackstone
fill 483 278 193 488 280 193 minecraft:iron_block
fill 483 278 196 483 280 199 minecraft:iron_block
fill 483 278 205 483 280 206 minecraft:polished_blackstone
fill 483 278 211 488 280 211 minecraft:polished_blackstone
fill 484 278 192 490 280 192 minecraft:iron_block
fill 484 278 196 484 280 197 minecraft:iron_block
fill 484 278 212 490 280 212 minecraft:polished_blackstone
fill 485 278 191 492 280 191 minecraft:iron_block
fill 485 278 213 493 280 213 minecraft:polished_blackstone
fill 486 278 194 486 280 194 minecraft:iron_block
fill 486 278 210 486 280 210 minecraft:polished_blackstone
fill 487 278 190 492 280 190 minecraft:iron_block
fill 487 278 214 492 280 214 minecraft:polished_blackstone
fill 489 278 189 492 280 189 minecraft:iron_block
fill 489 278 215 493 280 215 minecraft:polished_blackstone
fill 493 278 189 497 280 189 minecraft:polished_blackstone
fill 493 278 191 501 280 191 minecraft:polished_blackstone
fill 494 278 190 499 280 190 minecraft:polished_blackstone
fill 494 278 213 497 280 215 minecraft:iron_block
fill 496 278 192 502 280 192 minecraft:polished_blackstone
fill 496 278 212 502 280 212 minecraft:iron_block
fill 498 278 193 503 280 193 minecraft:polished_blackstone
fill 498 278 211 503 280 211 minecraft:iron_block
fill 498 278 213 499 280 214 minecraft:iron_block
fill 500 278 194 504 280 194 minecraft:polished_blackstone
fill 500 278 210 504 280 210 minecraft:iron_block
fill 500 278 213 501 280 213 minecraft:iron_block
fill 501 278 195 504 280 195 minecraft:polished_blackstone
fill 501 278 209 504 280 209 minecraft:iron_block
fill 502 278 196 505 280 197 minecraft:polished_blackstone
fill 502 278 207 505 280 208 minecraft:iron_block
fill 503 278 198 506 280 199 minecraft:polished_blackstone
fill 503 278 205 506 280 206 minecraft:iron_block
fill 504 278 200 506 280 201 minecraft:polished_blackstone
fill 504 278 202 504 280 204 minecraft:iron_block
fill 505 278 203 506 280 204 minecraft:iron_block
fill 506 278 202 506 280 202 minecraft:iron_block
fill 471 279 182 478 279 222 minecraft:blackstone
fill 479 279 182 479 279 201 minecraft:blackstone
setblock 479 279 202 minecraft:iron_block
fill 479 279 203 479 279 222 minecraft:blackstone
fill 480 279 182 480 279 196 minecraft:blackstone
setblock 480 279 197 minecraft:iron_block
setblock 480 279 207 minecraft:polished_blackstone
fill 480 279 208 480 279 222 minecraft:blackstone
fill 481 279 182 481 279 194 minecraft:blackstone
setblock 481 279 195 minecraft:iron_block
setblock 481 279 209 minecraft:polished_blackstone
fill 481 279 210 481 279 222 minecraft:blackstone
fill 482 279 182 482 279 193 minecraft:blackstone
fill 482 279 211 482 279 222 minecraft:blackstone
fill 483 279 182 483 279 192 minecraft:blackstone
fill 483 279 200 483 279 202 minecraft:iron_block
fill 483 279 203 483 279 204 minecraft:polished_blackstone
fill 483 279 212 483 279 222 minecraft:blackstone
fill 484 279 182 484 279 191 minecraft:blackstone
fill 484 279 198 488 279 206 minecraft:blackstone
fill 484 279 213 484 279 222 minecraft:blackstone
fill 485 279 182 485 279 190 minecraft:blackstone
setblock 485 279 196 minecraft:iron_block
fill 485 279 197 501 279 197 minecraft:blackstone
fill 485 279 207 501 279 207 minecraft:blackstone
setblock 485 279 208 minecraft:polished_blackstone
fill 485 279 214 485 279 222 minecraft:blackstone
fill 486 279 182 487 279 189 minecraft:blackstone
setblock 486 279 190 minecraft:iron_block
fill 486 279 195 500 279 196 minecraft:blackstone
fill 486 279 208 500 279 209 minecraft:blackstone
setblock 486 279 214 minecraft:polished_blackstone
fill 486 279 215 487 279 222 minecraft:blackstone
setblock 487 279 194 minecraft:iron_block
setblock 487 279 210 minecraft:polished_blackstone
fill 488 279 182 492 279 188 minecraft:blackstone
setblock 488 279 189 minecraft:iron_block
fill 488 279 194 498 279 194 minecraft:blackstone
fill 488 279 210 498 279 210 minecraft:blackstone
setblock 488 279 215 minecraft:polished_blackstone
fill 488 279 216 492 279 222 minecraft:blackstone
fill 489 279 193 497 279 193 minecraft:blackstone
fill 489 279 198 489 279 200 minecraft:blackstone
fill 489 279 201 489 279 203 minecraft:soul_lantern
fill 489 279 204 489 279 206 minecraft:blackstone
fill 489 279 211 497 279 211 minecraft:blackstone
fill 490 279 198 491 279 198 minecraft:blackstone
fill 490 279 199 490 279 201 minecraft:soul_lantern
fill 490 279 203 490 279 205 minecraft:soul_lantern
fill 490 279 206 491 279 206 minecraft:blackstone
fill 491 279 192 492 279 192 minecraft:iron_block
fill 491 279 199 492 279 199 minecraft:soul_lantern
fill 491 279 205 492 279 205 minecraft:soul_lantern
fill 491 279 212 493 279 212 minecraft:polished_blackstone
fill 492 279 198 494 279 198 minecraft:soul_lantern
fill 492 279 206 494 279 206 minecraft:soul_lantern
fill 493 279 182 511 279 187 minecraft:blackstone
setblock 493 279 188 minecraft:polished_blackstone
fill 493 279 192 495 279 192 minecraft:polished_blackstone
setblock 493 279 216 minecraft:polished_blackstone
fill 493 279 217 511 279 222 minecraft:blackstone
fill 494 279 188 511 279 188 minecraft:blackstone
fill 494 279 199 496 279 199 minecraft:soul_lantern
fill 494 279 205 496 279 205 minecraft:soul_lantern
fill 494 279 212 495 279 212 minecraft:iron_block
fill 494 279 216 511 279 216 minecraft:blackstone
fill 495 279 198 502 279 198 minecraft:blackstone
fill 495 279 206 502 279 206 minecraft:blackstone
fill 496 279 200 496 279 201 minecraft:soul_lantern
fill 496 279 203 496 279 204 minecraft:soul_lantern
fill 497 279 199 502 279 200 minecraft:blackstone
fill 497 279 201 497 279 203 minecraft:soul_lantern
fill 497 279 204 502 279 205 minecraft:blackstone
setblock 498 279 189 minecraft:polished_blackstone
fill 498 279 201 502 279 203 minecraft:blackstone
setblock 498 279 215 minecraft:iron_block
fill 499 279 189 511 279 189 minecraft:blackstone
setblock 499 279 194 minecraft:polished_blackstone
setblock 499 279 210 minecraft:iron_block
fill 499 279 215 511 279 215 minecraft:blackstone
setblock 500 279 190 minecraft:polished_blackstone
setblock 500 279 214 minecraft:iron_block
fill 501 279 190 511 279 190 minecraft:blackstone
setblock 501 279 196 minecraft:polished_blackstone
setblock 501 279 208 minecraft:iron_block
fill 501 279 214 511 279 214 minecraft:blackstone
fill 502 279 191 511 279 191 minecraft:blackstone
fill 502 279 213 511 279 213 minecraft:blackstone
fill 503 279 192 511 279 192 minecraft:blackstone
fill 503 279 200 503 279 201 minecraft:polished_blackstone
fill 503 279 202 503 279 204 minecraft:iron_block
fill 503 279 212 511 279 212 minecraft:blackstone
fill 504 279 193 511 279 193 minecraft:blackstone
fill 504 279 211 511 279 211 minecraft:blackstone
fill 505 279 194 511 279 194 minecraft:blackstone
setblock 505 279 195 minecraft:polished_blackstone
setblock 505 279 209 minecraft:iron_block
fill 505 279 210 511 279 210 minecraft:blackstone
fill 506 279 195 511 279 196 minecraft:blackstone
setblock 506 279 197 minecraft:polished_blackstone
setblock 506 279 207 minecraft:iron_block
fill 506 279 208 511 279 209 minecraft:blackstone
fill 507 279 197 511 279 201 minecraft:blackstone
setblock 507 279 202 minecraft:iron_block
fill 507 279 203 511 279 207 minecraft:blackstone
fill 508 279 202 511 279 202 minecraft:blackstone
fill 471 283 182 473 300 182 minecraft:polished_blackstone
fill 471 283 192 471 300 194 minecraft:polished_blackstone
fill 471 283 204 471 300 206 minecraft:polished_blackstone
fill 471 283 216 471 300 218 minecraft:polished_blackstone
fill 472 283 191 472 285 193 minecraft:polished_blackstone
fill 472 283 203 472 285 205 minecraft:polished_blackstone
fill 472 283 215 472 285 217 minecraft:polished_blackstone
setblock 473 283 184 minecraft:light[level=12]
setblock 473 283 192 minecraft:light[level=12]
setblock 473 283 200 minecraft:light[level=12]
setblock 473 283 208 minecraft:light[level=12]
setblock 473 283 216 minecraft:light[level=12]
fill 477 283 222 479 300 222 minecraft:polished_blackstone
fill 478 283 221 480 285 221 minecraft:polished_blackstone
setblock 481 283 184 minecraft:light[level=12]
setblock 481 283 192 minecraft:light[level=12]
setblock 481 283 200 minecraft:light[level=12]
setblock 481 283 208 minecraft:light[level=12]
setblock 481 283 216 minecraft:light[level=12]
fill 482 283 183 484 285 183 minecraft:polished_blackstone
fill 483 283 182 485 300 182 minecraft:polished_blackstone
setblock 489 283 184 minecraft:light[level=12]
setblock 489 283 192 minecraft:light[level=12]
setblock 489 283 200 minecraft:light[level=12]
setblock 489 283 208 minecraft:light[level=12]
setblock 489 283 216 minecraft:light[level=12]
fill 489 283 222 491 300 222 minecraft:polished_blackstone
fill 490 283 221 492 285 221 minecraft:polished_blackstone
fill 494 283 183 496 285 183 minecraft:polished_blackstone
fill 495 283 182 497 300 182 minecraft:polished_blackstone
setblock 497 283 184 minecraft:light[level=12]
setblock 497 283 192 minecraft:light[level=12]
setblock 497 283 200 minecraft:light[level=12]
setblock 497 283 208 minecraft:light[level=12]
setblock 497 283 216 minecraft:light[level=12]
fill 501 283 222 503 300 222 minecraft:polished_blackstone
fill 502 283 221 504 285 221 minecraft:polished_blackstone
setblock 505 283 184 minecraft:light[level=12]
setblock 505 283 192 minecraft:light[level=12]
setblock 505 283 200 minecraft:light[level=12]
setblock 505 283 208 minecraft:light[level=12]
setblock 505 283 216 minecraft:light[level=12]
fill 506 283 183 508 285 183 minecraft:polished_blackstone
fill 507 283 182 509 300 182 minecraft:polished_blackstone
fill 510 283 191 510 285 193 minecraft:polished_blackstone
fill 510 283 203 510 285 205 minecraft:polished_blackstone
fill 510 283 215 510 285 217 minecraft:polished_blackstone
fill 511 283 190 511 300 192 minecraft:polished_blackstone
fill 511 283 202 511 300 204 minecraft:polished_blackstone
fill 511 283 214 511 300 216 minecraft:polished_blackstone
fill 471 285 185 471 285 190 minecraft:blackstone
fill 471 285 197 471 285 202 minecraft:blackstone
fill 471 285 209 471 285 214 minecraft:blackstone
fill 471 285 221 471 285 222 minecraft:blackstone
fill 472 285 222 475 285 222 minecraft:blackstone
fill 475 285 182 480 285 182 minecraft:blackstone
fill 482 285 222 487 285 222 minecraft:blackstone
fill 487 285 182 492 285 182 minecraft:blackstone
fill 494 285 222 499 285 222 minecraft:blackstone
fill 499 285 182 504 285 182 minecraft:blackstone
fill 499 285 215 509 285 215 minecraft:polished_blackstone
fill 500 285 205 509 285 205 minecraft:polished_blackstone
fill 506 285 222 511 285 222 minecraft:blackstone
fill 511 285 182 511 285 187 minecraft:blackstone
fill 511 285 194 511 285 199 minecraft:blackstone
setblock 511 285 205 minecraft:polished_blackstone
fill 511 285 206 511 285 211 minecraft:blackstone
fill 511 285 218 511 285 221 minecraft:blackstone
fill 470 286 187 470 291 190 minecraft:soul_lantern
fill 470 286 199 470 291 202 minecraft:soul_lantern
fill 470 286 211 470 291 214 minecraft:soul_lantern
fill 470 286 223 473 291 223 minecraft:soul_lantern
fill 471 286 185 493 287 185 minecraft:polished_blackstone
fill 471 286 190 473 287 190 minecraft:polished_blackstone
fill 471 286 195 510 287 195 minecraft:polished_blackstone
fill 471 286 200 473 287 200 minecraft:polished_blackstone
fill 471 286 210 511 286 210 minecraft:polished_blackstone
fill 471 286 215 504 286 215 minecraft:polished_blackstone
fill 471 286 220 473 287 220 minecraft:polished_blackstone
fill 472 286 205 491 286 205 minecraft:polished_blackstone
fill 477 286 181 480 291 181 minecraft:soul_lantern
fill 482 286 223 485 291 223 minecraft:soul_lantern
fill 489 286 181 492 291 181 minecraft:soul_lantern
fill 494 286 223 497 291 223 minecraft:soul_lantern
fill 495 286 205 505 286 205 minecraft:polished_blackstone
fill 501 286 181 504 291 181 minecraft:soul_lantern
fill 506 286 223 509 291 223 minecraft:soul_lantern
fill 512 286 182 512 291 185 minecraft:soul_lantern
fill 512 286 194 512 291 197 minecraft:soul_lantern
fill 512 286 206 512 291 209 minecraft:soul_lantern
fill 512 286 218 512 291 221 minecraft:soul_lantern
fill 471 287 210 476 287 210 minecraft:polished_blackstone
fill 471 287 215 473 287 215 minecraft:polished_blackstone
fill 472 287 205 473 287 205 minecraft:polished_blackstone
fill 474 287 190 502 287 190 minecraft:polished_blackstone
fill 474 287 200 490 287 200 minecraft:polished_blackstone
fill 474 287 218 474 288 221 minecraft:iron_block
fill 475 287 220 502 287 220 minecraft:polished_blackstone
fill 494 287 185 511 287 185 minecraft:polished_blackstone
fill 496 287 200 505 287 200 minecraft:polished_blackstone
fill 504 287 211 504 287 222 minecraft:iron_block
fill 474 288 182 474 288 217 minecraft:iron_block
fill 479 288 182 479 288 221 minecraft:iron_block
fill 484 288 183 484 288 222 minecraft:iron_block
fill 489 288 182 489 288 221 minecraft:iron_block
fill 494 288 182 494 288 198 minecraft:iron_block
fill 494 288 206 494 288 222 minecraft:iron_block
fill 497 288 190 510 288 190 minecraft:polished_blackstone
fill 497 288 220 498 288 220 minecraft:polished_blackstone
fill 499 288 182 499 288 189 minecraft:iron_block
fill 499 288 191 499 288 221 minecraft:iron_block
fill 500 288 200 511 288 200 minecraft:polished_blackstone
fill 500 288 220 511 288 220 minecraft:polished_blackstone
fill 504 288 182 504 288 189 minecraft:iron_block
fill 504 288 191 504 288 199 minecraft:iron_block
fill 504 288 201 504 288 216 minecraft:iron_block
fill 509 288 183 509 289 187 minecraft:iron_block
fill 474 289 182 474 289 185 minecraft:iron_block
fill 479 289 182 479 289 185 minecraft:iron_block
fill 484 289 183 484 289 193 minecraft:iron_block
fill 489 289 182 489 289 188 minecraft:iron_block
fill 494 289 182 494 289 188 minecraft:iron_block
fill 499 289 182 499 289 186 minecraft:iron_block
fill 504 289 182 504 289 184 minecraft:iron_block
fill 509 289 188 509 289 222 minecraft:iron_block
setblock 473 291 184 minecraft:light[level=12]
setblock 473 291 192 minecraft:light[level=12]
setblock 473 291 200 minecraft:light[level=12]
setblock 473 291 208 minecraft:light[level=12]
setblock 473 291 216 minecraft:light[level=12]
setblock 481 291 184 minecraft:light[level=12]
setblock 481 291 192 minecraft:light[level=12]
setblock 481 291 200 minecraft:light[level=12]
setblock 481 291 208 minecraft:light[level=12]
setblock 481 291 216 minecraft:light[level=12]
setblock 489 291 184 minecraft:light[level=12]
setblock 489 291 192 minecraft:light[level=12]
setblock 489 291 200 minecraft:light[level=12]
setblock 489 291 208 minecraft:light[level=12]
setblock 489 291 216 minecraft:light[level=12]
setblock 497 291 184 minecraft:light[level=12]
setblock 497 291 192 minecraft:light[level=12]
setblock 497 291 200 minecraft:light[level=12]
setblock 497 291 208 minecraft:light[level=12]
setblock 497 291 216 minecraft:light[level=12]
setblock 505 291 184 minecraft:light[level=12]
setblock 505 291 192 minecraft:light[level=12]
setblock 505 291 200 minecraft:light[level=12]
setblock 505 291 208 minecraft:light[level=12]
setblock 505 291 216 minecraft:light[level=12]
fill 470 292 187 470 307 187 minecraft:polished_blackstone_bricks
fill 470 292 188 470 292 189 minecraft:soul_lantern
fill 470 292 190 470 307 190 minecraft:polished_blackstone_bricks
fill 470 292 199 470 307 199 minecraft:polished_blackstone_bricks
fill 470 292 200 470 292 201 minecraft:soul_lantern
fill 470 292 202 470 307 202 minecraft:polished_blackstone_bricks
fill 470 292 211 470 307 211 minecraft:polished_blackstone_bricks
fill 470 292 212 470 292 213 minecraft:soul_lantern
fill 470 292 214 470 307 214 minecraft:polished_blackstone_bricks
fill 470 292 223 470 307 223 minecraft:polished_blackstone_bricks
fill 471 292 223 472 292 223 minecraft:soul_lantern
fill 473 292 223 473 307 223 minecraft:polished_blackstone_bricks
fill 477 292 181 477 307 181 minecraft:polished_blackstone_bricks
fill 478 292 181 479 292 181 minecraft:soul_lantern
fill 480 292 181 480 307 181 minecraft:polished_blackstone_bricks
fill 482 292 223 482 307 223 minecraft:polished_blackstone_bricks
fill 483 292 223 484 292 223 minecraft:soul_lantern
fill 485 292 223 485 307 223 minecraft:polished_blackstone_bricks
fill 489 292 181 489 307 181 minecraft:polished_blackstone_bricks
fill 490 292 181 491 292 181 minecraft:soul_lantern
fill 492 292 181 492 307 181 minecraft:polished_blackstone_bricks
fill 494 292 223 494 307 223 minecraft:polished_blackstone_bricks
fill 495 292 223 496 292 223 minecraft:soul_lantern
fill 497 292 223 497 307 223 minecraft:polished_blackstone_bricks
fill 501 292 181 501 307 181 minecraft:polished_blackstone_bricks
fill 502 292 181 503 292 181 minecraft:soul_lantern
fill 504 292 181 504 307 181 minecraft:polished_blackstone_bricks
fill 506 292 223 506 307 223 minecraft:polished_blackstone_bricks
fill 507 292 223 508 292 223 minecraft:soul_lantern
fill 509 292 223 509 307 223 minecraft:polished_blackstone_bricks
fill 512 292 182 512 307 182 minecraft:polished_blackstone_bricks
fill 512 292 183 512 292 184 minecraft:soul_lantern
fill 512 292 185 512 307 185 minecraft:polished_blackstone_bricks
fill 512 292 194 512 307 194 minecraft:polished_blackstone_bricks
fill 512 292 195 512 292 196 minecraft:soul_lantern
fill 512 292 197 512 307 197 minecraft:polished_blackstone_bricks
fill 512 292 206 512 307 206 minecraft:polished_blackstone_bricks
fill 512 292 207 512 292 208 minecraft:soul_lantern
fill 512 292 209 512 307 209 minecraft:polished_blackstone_bricks
fill 512 292 218 512 307 218 minecraft:polished_blackstone_bricks
fill 512 292 219 512 292 220 minecraft:soul_lantern
fill 512 292 221 512 307 221 minecraft:polished_blackstone_bricks
fill 470 293 188 470 307 189 minecraft:polished_blackstone_bricks
fill 470 293 200 470 307 201 minecraft:polished_blackstone_bricks
fill 470 293 212 470 307 213 minecraft:polished_blackstone_bricks
fill 471 293 223 472 307 223 minecraft:polished_blackstone_bricks
fill 478 293 181 479 307 181 minecraft:polished_blackstone_bricks
fill 483 293 223 484 307 223 minecraft:polished_blackstone_bricks
fill 490 293 181 491 307 181 minecraft:polished_blackstone_bricks
fill 495 293 223 496 307 223 minecraft:polished_blackstone_bricks
fill 502 293 181 503 307 181 minecraft:polished_blackstone_bricks
fill 507 293 223 508 307 223 minecraft:polished_blackstone_bricks
fill 512 293 183 512 307 184 minecraft:polished_blackstone_bricks
fill 512 293 195 512 307 196 minecraft:polished_blackstone_bricks
fill 512 293 207 512 307 208 minecraft:polished_blackstone_bricks
fill 512 293 219 512 307 220 minecraft:polished_blackstone_bricks
setblock 473 299 184 minecraft:light[level=12]
setblock 473 299 192 minecraft:light[level=12]
setblock 473 299 200 minecraft:light[level=12]
setblock 473 299 208 minecraft:light[level=12]
setblock 473 299 216 minecraft:light[level=12]
setblock 481 299 184 minecraft:light[level=12]
setblock 481 299 192 minecraft:light[level=12]
setblock 481 299 200 minecraft:light[level=12]
setblock 481 299 208 minecraft:light[level=12]
setblock 481 299 216 minecraft:light[level=12]
setblock 489 299 184 minecraft:light[level=12]
setblock 489 299 192 minecraft:light[level=12]
setblock 489 299 200 minecraft:light[level=12]
setblock 489 299 208 minecraft:light[level=12]
setblock 489 299 216 minecraft:light[level=12]
setblock 497 299 184 minecraft:light[level=12]
setblock 497 299 192 minecraft:light[level=12]
setblock 497 299 200 minecraft:light[level=12]
setblock 497 299 208 minecraft:light[level=12]
setblock 497 299 216 minecraft:light[level=12]
setblock 505 299 184 minecraft:light[level=12]
setblock 505 299 192 minecraft:light[level=12]
setblock 505 299 200 minecraft:light[level=12]
setblock 505 299 208 minecraft:light[level=12]
setblock 505 299 216 minecraft:light[level=12]
fill 472 300 191 472 300 193 minecraft:polished_blackstone
fill 472 300 203 472 300 205 minecraft:polished_blackstone
fill 472 300 215 472 300 217 minecraft:polished_blackstone
fill 478 300 221 480 300 221 minecraft:polished_blackstone
fill 482 300 183 484 300 183 minecraft:polished_blackstone
fill 490 300 221 492 300 221 minecraft:polished_blackstone
fill 494 300 183 496 300 183 minecraft:polished_blackstone
fill 502 300 221 504 300 221 minecraft:polished_blackstone
fill 506 300 183 508 300 183 minecraft:polished_blackstone
fill 510 300 191 510 300 193 minecraft:polished_blackstone
fill 510 300 203 510 300 205 minecraft:polished_blackstone
fill 510 300 215 510 300 217 minecraft:polished_blackstone
