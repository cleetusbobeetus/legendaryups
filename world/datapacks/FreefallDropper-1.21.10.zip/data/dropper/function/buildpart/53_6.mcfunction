fill 241 184 228 241 277 228 minecraft:black_concrete
fill 255 184 270 255 238 270 minecraft:black_concrete
setblock 260 184 228 minecraft:ochre_froglight
setblock 277 184 261 minecraft:verdant_froglight
fill 277 184 264 277 188 264 minecraft:black_concrete
setblock 236 185 230 minecraft:black_stained_glass
setblock 236 185 232 minecraft:ochre_froglight
setblock 236 185 234 minecraft:black_stained_glass
setblock 236 185 236 minecraft:magenta_stained_glass
fill 236 185 242 236 185 255 minecraft:pearlescent_froglight
setblock 236 185 262 minecraft:ochre_froglight
setblock 236 185 264 minecraft:magenta_stained_glass
setblock 236 185 266 minecraft:pearlescent_froglight
setblock 236 185 268 minecraft:magenta_stained_glass
setblock 237 185 229 minecraft:black_stained_glass
setblock 237 185 237 minecraft:black_stained_glass
fill 237 185 242 241 185 242 minecraft:pearlescent_froglight
fill 237 185 255 241 185 255 minecraft:pearlescent_froglight
setblock 237 185 261 minecraft:cyan_stained_glass
setblock 237 185 269 minecraft:pearlescent_froglight
setblock 238 185 239 minecraft:light[level=15]
setblock 238 185 247 minecraft:light[level=15]
fill 238 185 248 238 189 248 minecraft:iron_bars
fill 239 185 228 239 308 228 minecraft:black_concrete
setblock 239 185 229 minecraft:black_stained_glass
setblock 239 185 237 minecraft:pearlescent_froglight
setblock 239 185 261 minecraft:black_stained_glass
setblock 239 185 269 minecraft:black_stained_glass
fill 239 185 270 239 191 270 minecraft:black_concrete
setblock 241 185 229 minecraft:light_blue_stained_glass
setblock 241 185 237 minecraft:black_stained_glass
fill 241 185 243 241 185 254 minecraft:pearlescent_froglight
setblock 241 185 261 minecraft:black_stained_glass
setblock 241 185 269 minecraft:magenta_stained_glass
setblock 243 185 229 minecraft:light_blue_stained_glass
setblock 243 185 237 minecraft:black_stained_glass
setblock 243 185 261 minecraft:black_stained_glass
setblock 243 185 269 minecraft:light_blue_stained_glass
setblock 244 185 230 minecraft:ochre_froglight
setblock 244 185 232 minecraft:black_stained_glass
setblock 244 185 234 minecraft:ochre_froglight
setblock 244 185 236 minecraft:black_stained_glass
setblock 244 185 262 minecraft:pearlescent_froglight
setblock 244 185 264 minecraft:black_stained_glass
setblock 244 185 266 minecraft:cyan_stained_glass
setblock 244 185 268 minecraft:black_stained_glass
setblock 246 185 231 minecraft:light[level=15]
setblock 246 185 239 minecraft:light[level=15]
setblock 246 185 247 minecraft:light[level=15]
setblock 246 185 255 minecraft:light[level=15]
setblock 246 185 263 minecraft:light[level=15]
setblock 254 185 231 minecraft:light[level=15]
setblock 254 185 239 minecraft:light[level=15]
setblock 254 185 247 minecraft:light[level=15]
setblock 254 185 255 minecraft:light[level=15]
setblock 254 185 263 minecraft:light[level=15]
fill 260 185 228 260 283 228 minecraft:black_concrete
setblock 262 185 231 minecraft:light[level=15]
setblock 262 185 239 minecraft:light[level=15]
setblock 262 185 247 minecraft:light[level=15]
setblock 262 185 255 minecraft:light[level=15]
setblock 262 185 263 minecraft:light[level=15]
setblock 268 185 230 minecraft:sea_lantern
setblock 268 185 232 minecraft:ochre_froglight
setblock 268 185 234 minecraft:magenta_stained_glass
setblock 268 185 236 minecraft:magenta_stained_glass
setblock 268 185 262 minecraft:black_stained_glass
setblock 268 185 264 minecraft:light_blue_stained_glass
setblock 268 185 266 minecraft:light_blue_stained_glass
setblock 268 185 268 minecraft:black_stained_glass
setblock 269 185 229 minecraft:black_stained_glass
setblock 269 185 237 minecraft:black_stained_glass
setblock 269 185 261 minecraft:black_stained_glass
setblock 269 185 269 minecraft:black_stained_glass
setblock 270 185 239 minecraft:light[level=15]
setblock 270 185 247 minecraft:light[level=15]
setblock 270 185 255 minecraft:light[level=15]
setblock 271 185 229 minecraft:black_stained_glass
setblock 271 185 237 minecraft:magenta_stained_glass
setblock 271 185 243 minecraft:light_blue_stained_glass
setblock 271 185 245 minecraft:pearlescent_froglight
setblock 271 185 247 minecraft:pearlescent_froglight
setblock 271 185 249 minecraft:pearlescent_froglight
setblock 271 185 251 minecraft:black_stained_glass
setblock 271 185 253 minecraft:black_stained_glass
setblock 271 185 261 minecraft:ochre_froglight
setblock 271 185 269 minecraft:magenta_stained_glass
setblock 272 185 242 minecraft:black_stained_glass
setblock 272 185 255 minecraft:cyan_stained_glass
setblock 273 185 229 minecraft:magenta_stained_glass
setblock 273 185 237 minecraft:sea_lantern
setblock 273 185 261 minecraft:sea_lantern
setblock 273 185 269 minecraft:black_stained_glass
setblock 274 185 242 minecraft:black_stained_glass
setblock 274 185 255 minecraft:black_stained_glass
setblock 275 185 229 minecraft:magenta_stained_glass
setblock 275 185 237 minecraft:pearlescent_froglight
setblock 275 185 261 minecraft:cyan_stained_glass
setblock 275 185 269 minecraft:magenta_stained_glass
setblock 276 185 230 minecraft:black_stained_glass
setblock 276 185 232 minecraft:sea_lantern
setblock 276 185 234 minecraft:pearlescent_froglight
setblock 276 185 236 minecraft:pearlescent_froglight
setblock 276 185 243 minecraft:black_stained_glass
setblock 276 185 245 minecraft:black_stained_glass
setblock 276 185 247 minecraft:sea_lantern
setblock 276 185 249 minecraft:black_stained_glass
setblock 276 185 251 minecraft:black_stained_glass
setblock 276 185 253 minecraft:black_stained_glass
setblock 276 185 262 minecraft:cyan_stained_glass
setblock 276 185 264 minecraft:black_stained_glass
setblock 276 185 266 minecraft:magenta_stained_glass
setblock 276 185 268 minecraft:black_stained_glass
fill 277 185 261 277 230 261 minecraft:black_concrete
setblock 235 186 237 minecraft:ochre_froglight
setblock 235 186 267 minecraft:purple_concrete
fill 236 186 230 236 187 230 minecraft:light_gray_concrete
fill 236 186 232 236 187 232 minecraft:light_gray_concrete
fill 236 186 234 236 187 234 minecraft:light_gray_concrete
fill 236 186 236 236 187 236 minecraft:light_gray_concrete
fill 236 186 262 236 187 262 minecraft:cyan_terracotta
fill 236 186 264 236 187 264 minecraft:cyan_terracotta
fill 236 186 266 236 187 266 minecraft:cyan_terracotta
fill 236 186 268 236 187 268 minecraft:cyan_terracotta
fill 237 186 229 237 187 229 minecraft:light_gray_concrete
fill 237 186 237 237 187 237 minecraft:light_gray_concrete
fill 237 186 261 237 187 261 minecraft:cyan_terracotta
fill 237 186 269 237 187 269 minecraft:cyan_terracotta
fill 239 186 229 239 187 229 minecraft:light_gray_concrete
fill 239 186 237 239 187 237 minecraft:light_gray_concrete
fill 239 186 261 239 187 261 minecraft:cyan_terracotta
fill 239 186 269 239 187 269 minecraft:cyan_terracotta
fill 241 186 229 241 187 229 minecraft:light_gray_concrete
fill 241 186 237 241 187 237 minecraft:light_gray_concrete
fill 241 186 261 241 187 261 minecraft:cyan_terracotta
fill 241 186 269 241 187 269 minecraft:cyan_terracotta
fill 243 186 229 243 187 229 minecraft:light_gray_concrete
fill 243 186 237 243 187 237 minecraft:light_gray_concrete
fill 243 186 261 243 187 261 minecraft:cyan_terracotta
fill 243 186 269 243 187 269 minecraft:cyan_terracotta
fill 244 186 230 244 187 230 minecraft:light_gray_concrete
fill 244 186 232 244 187 232 minecraft:light_gray_concrete
fill 244 186 234 244 187 234 minecraft:light_gray_concrete
fill 244 186 236 244 187 236 minecraft:light_gray_concrete
fill 244 186 262 244 187 262 minecraft:cyan_terracotta
fill 244 186 264 244 187 264 minecraft:cyan_terracotta
fill 244 186 266 244 187 266 minecraft:cyan_terracotta
fill 244 186 268 244 187 268 minecraft:cyan_terracotta
setblock 264 186 228 minecraft:ochre_froglight
fill 268 186 230 268 187 230 minecraft:cyan_terracotta
fill 268 186 232 268 187 232 minecraft:cyan_terracotta
fill 268 186 234 268 187 234 minecraft:cyan_terracotta
fill 268 186 236 268 187 236 minecraft:cyan_terracotta
fill 268 186 262 268 187 262 minecraft:light_gray_concrete
fill 268 186 264 268 187 264 minecraft:light_gray_concrete
fill 268 186 266 268 187 266 minecraft:light_gray_concrete
fill 268 186 268 268 187 268 minecraft:light_gray_concrete
fill 269 186 229 269 187 229 minecraft:cyan_terracotta
fill 269 186 237 269 187 237 minecraft:cyan_terracotta
fill 269 186 261 269 187 261 minecraft:light_gray_concrete
fill 269 186 269 269 187 269 minecraft:light_gray_concrete
fill 271 186 229 271 187 229 minecraft:cyan_terracotta
fill 271 186 237 271 187 237 minecraft:cyan_terracotta
fill 271 186 243 271 187 243 minecraft:light_gray_concrete
fill 271 186 245 271 187 245 minecraft:light_gray_concrete
fill 271 186 247 271 187 247 minecraft:light_gray_concrete
fill 271 186 249 271 187 249 minecraft:light_gray_concrete
fill 271 186 251 271 187 251 minecraft:light_gray_concrete
fill 271 186 253 271 187 253 minecraft:light_gray_concrete
fill 271 186 261 271 187 261 minecraft:light_gray_concrete
fill 271 186 269 271 187 269 minecraft:light_gray_concrete
fill 272 186 242 272 187 242 minecraft:light_gray_concrete
fill 272 186 255 272 187 255 minecraft:light_gray_concrete
fill 273 186 229 273 187 229 minecraft:cyan_terracotta
fill 273 186 237 273 187 237 minecraft:cyan_terracotta
fill 273 186 261 273 187 261 minecraft:light_gray_concrete
fill 273 186 269 273 187 269 minecraft:light_gray_concrete
fill 274 186 242 274 187 242 minecraft:light_gray_concrete
fill 274 186 255 274 187 255 minecraft:light_gray_concrete
fill 275 186 229 275 187 229 minecraft:cyan_terracotta
fill 275 186 237 275 187 237 minecraft:cyan_terracotta
fill 275 186 261 275 187 261 minecraft:light_gray_concrete
fill 275 186 269 275 187 269 minecraft:light_gray_concrete
fill 276 186 230 276 187 230 minecraft:cyan_terracotta
fill 276 186 232 276 187 232 minecraft:cyan_terracotta
fill 276 186 234 276 187 234 minecraft:cyan_terracotta
fill 276 186 236 276 187 236 minecraft:cyan_terracotta
fill 276 186 243 276 187 243 minecraft:light_gray_concrete
fill 276 186 245 276 187 245 minecraft:light_gray_concrete
fill 276 186 247 276 187 247 minecraft:light_gray_concrete
fill 276 186 249 276 187 249 minecraft:light_gray_concrete
fill 276 186 251 276 187 251 minecraft:light_gray_concrete
fill 276 186 253 276 187 253 minecraft:light_gray_concrete
fill 276 186 262 276 187 262 minecraft:light_gray_concrete
fill 276 186 264 276 187 264 minecraft:light_gray_concrete
fill 276 186 266 276 187 266 minecraft:light_gray_concrete
fill 276 186 268 276 187 268 minecraft:light_gray_concrete
setblock 277 186 247 minecraft:blue_concrete
fill 235 187 237 235 308 237 minecraft:black_concrete
fill 235 187 267 235 212 267 minecraft:black_concrete
setblock 238 187 238 minecraft:light[level=12]
setblock 238 187 245 minecraft:light[level=12]
setblock 238 187 252 minecraft:light[level=12]
setblock 238 187 259 minecraft:light[level=12]
setblock 241 187 270 minecraft:ochre_froglight
setblock 245 187 231 minecraft:light[level=12]
setblock 245 187 238 minecraft:light[level=12]
setblock 245 187 245 minecraft:light[level=12]
setblock 245 187 252 minecraft:light[level=12]
setblock 245 187 259 minecraft:light[level=12]
setblock 245 187 266 minecraft:light[level=12]
setblock 247 187 228 minecraft:blue_concrete
setblock 252 187 231 minecraft:light[level=12]
setblock 252 187 238 minecraft:light[level=12]
setblock 252 187 245 minecraft:light[level=12]
setblock 252 187 252 minecraft:light[level=12]
setblock 252 187 259 minecraft:light[level=12]
setblock 252 187 266 minecraft:light[level=12]
setblock 259 187 231 minecraft:light[level=12]
setblock 259 187 238 minecraft:light[level=12]
setblock 259 187 245 minecraft:light[level=12]
setblock 259 187 252 minecraft:light[level=12]
setblock 259 187 259 minecraft:light[level=12]
setblock 259 187 266 minecraft:light[level=12]
fill 264 187 228 264 233 228 minecraft:black_concrete
setblock 266 187 231 minecraft:light[level=12]
setblock 266 187 238 minecraft:light[level=12]
setblock 266 187 245 minecraft:light[level=12]
setblock 266 187 252 minecraft:light[level=12]
setblock 266 187 259 minecraft:light[level=12]
setblock 266 187 266 minecraft:light[level=12]
setblock 273 187 238 minecraft:light[level=12]
setblock 273 187 259 minecraft:light[level=12]
fill 277 187 247 277 291 247 minecraft:black_concrete
setblock 277 187 255 minecraft:sea_lantern
setblock 236 188 230 minecraft:black_stained_glass
setblock 236 188 232 minecraft:ochre_froglight
setblock 236 188 234 minecraft:cyan_stained_glass
setblock 236 188 236 minecraft:ochre_froglight
setblock 236 188 262 minecraft:sea_lantern
setblock 236 188 264 minecraft:black_stained_glass
setblock 236 188 266 minecraft:black_stained_glass
setblock 236 188 268 minecraft:black_stained_glass
setblock 237 188 229 minecraft:ochre_froglight
setblock 237 188 237 minecraft:black_stained_glass
setblock 237 188 261 minecraft:black_stained_glass
setblock 237 188 269 minecraft:cyan_stained_glass
setblock 239 188 229 minecraft:sea_lantern
setblock 239 188 237 minecraft:black_stained_glass
setblock 239 188 261 minecraft:black_stained_glass
setblock 239 188 269 minecraft:cyan_stained_glass
setblock 241 188 229 minecraft:light_blue_stained_glass
setblock 241 188 237 minecraft:ochre_froglight
setblock 241 188 261 minecraft:light_blue_stained_glass
setblock 241 188 269 minecraft:black_stained_glass
fill 241 188 270 241 241 270 minecraft:black_concrete
setblock 243 188 229 minecraft:pearlescent_froglight
setblock 243 188 237 minecraft:black_stained_glass
setblock 243 188 261 minecraft:cyan_stained_glass
setblock 243 188 269 minecraft:black_stained_glass
setblock 244 188 230 minecraft:cyan_stained_glass
setblock 244 188 232 minecraft:black_stained_glass
setblock 244 188 234 minecraft:pearlescent_froglight
setblock 244 188 236 minecraft:sea_lantern
setblock 244 188 262 minecraft:light_blue_stained_glass
setblock 244 188 264 minecraft:black_stained_glass
setblock 244 188 266 minecraft:black_stained_glass
setblock 244 188 268 minecraft:magenta_stained_glass
fill 247 188 228 247 261 228 minecraft:black_concrete
setblock 255 188 231 minecraft:redstone_block
setblock 265 188 228 minecraft:blue_concrete
fill 266 188 228 266 218 228 minecraft:black_concrete
setblock 268 188 230 minecraft:magenta_stained_glass
setblock 268 188 232 minecraft:magenta_stained_glass
setblock 268 188 234 minecraft:black_stained_glass
setblock 268 188 236 minecraft:magenta_stained_glass
setblock 268 188 262 minecraft:pearlescent_froglight
setblock 268 188 264 minecraft:cyan_stained_glass
setblock 268 188 266 minecraft:black_stained_glass
setblock 268 188 268 minecraft:light_blue_stained_glass
setblock 269 188 229 minecraft:cyan_stained_glass
setblock 269 188 237 minecraft:black_stained_glass
setblock 269 188 261 minecraft:light_blue_stained_glass
setblock 269 188 269 minecraft:black_stained_glass
setblock 271 188 229 minecraft:black_stained_glass
setblock 271 188 237 minecraft:black_stained_glass
setblock 271 188 243 minecraft:black_stained_glass
setblock 271 188 245 minecraft:pearlescent_froglight
setblock 271 188 247 minecraft:light_blue_stained_glass
setblock 271 188 249 minecraft:ochre_froglight
setblock 271 188 251 minecraft:ochre_froglight
setblock 271 188 253 minecraft:black_stained_glass
setblock 271 188 261 minecraft:cyan_stained_glass
setblock 271 188 269 minecraft:cyan_stained_glass
setblock 272 188 242 minecraft:sea_lantern
setblock 272 188 255 minecraft:black_stained_glass
setblock 273 188 229 minecraft:pearlescent_froglight
setblock 273 188 237 minecraft:black_stained_glass
setblock 273 188 261 minecraft:magenta_stained_glass
setblock 273 188 269 minecraft:black_stained_glass
setblock 274 188 242 minecraft:black_stained_glass
setblock 274 188 255 minecraft:pearlescent_froglight
setblock 275 188 229 minecraft:black_stained_glass
setblock 275 188 237 minecraft:black_stained_glass
setblock 275 188 261 minecraft:magenta_stained_glass
setblock 275 188 269 minecraft:black_stained_glass
setblock 276 188 230 minecraft:light_blue_stained_glass
setblock 276 188 232 minecraft:black_stained_glass
setblock 276 188 234 minecraft:magenta_stained_glass
setblock 276 188 236 minecraft:black_stained_glass
setblock 276 188 243 minecraft:cyan_stained_glass
setblock 276 188 245 minecraft:sea_lantern
setblock 276 188 247 minecraft:magenta_stained_glass
setblock 276 188 249 minecraft:light_blue_stained_glass
setblock 276 188 251 minecraft:pearlescent_froglight
setblock 276 188 253 minecraft:ochre_froglight
setblock 276 188 262 minecraft:light_blue_stained_glass
setblock 276 188 264 minecraft:ochre_froglight
setblock 276 188 266 minecraft:cyan_stained_glass
setblock 276 188 268 minecraft:ochre_froglight
fill 277 188 255 277 199 255 minecraft:black_concrete
setblock 235 189 243 minecraft:cyan_concrete
fill 236 189 230 236 190 230 minecraft:light_gray_concrete
fill 236 189 232 236 190 232 minecraft:light_gray_concrete
fill 236 189 234 236 190 234 minecraft:light_gray_concrete
fill 236 189 236 236 190 236 minecraft:light_gray_concrete
fill 236 189 262 236 190 262 minecraft:cyan_terracotta
fill 236 189 264 236 190 264 minecraft:cyan_terracotta
fill 236 189 266 236 190 266 minecraft:cyan_terracotta
fill 236 189 268 236 190 268 minecraft:cyan_terracotta
fill 237 189 229 237 190 229 minecraft:light_gray_concrete
fill 237 189 237 237 190 237 minecraft:light_gray_concrete
fill 237 189 261 237 190 261 minecraft:cyan_terracotta
fill 237 189 269 237 190 269 minecraft:cyan_terracotta
fill 239 189 229 239 190 229 minecraft:light_gray_concrete
fill 239 189 237 239 190 237 minecraft:light_gray_concrete
fill 239 189 261 239 190 261 minecraft:cyan_terracotta
fill 239 189 269 239 190 269 minecraft:cyan_terracotta
fill 241 189 229 241 190 229 minecraft:light_gray_concrete
fill 241 189 237 241 190 237 minecraft:light_gray_concrete
fill 241 189 261 241 190 261 minecraft:cyan_terracotta
fill 241 189 269 241 190 269 minecraft:cyan_terracotta
fill 243 189 229 243 190 229 minecraft:light_gray_concrete
fill 243 189 237 243 190 237 minecraft:light_gray_concrete
fill 243 189 261 243 190 261 minecraft:cyan_terracotta
fill 243 189 269 243 190 269 minecraft:cyan_terracotta
fill 244 189 230 244 190 230 minecraft:light_gray_concrete
fill 244 189 232 244 190 232 minecraft:light_gray_concrete
fill 244 189 234 244 190 234 minecraft:light_gray_concrete
fill 244 189 236 244 190 236 minecraft:light_gray_concrete
fill 244 189 262 244 190 262 minecraft:cyan_terracotta
fill 244 189 264 244 190 264 minecraft:cyan_terracotta
fill 244 189 266 244 190 266 minecraft:cyan_terracotta
fill 244 189 268 244 190 268 minecraft:cyan_terracotta
setblock 254 189 270 minecraft:sea_lantern
fill 265 189 228 265 196 228 minecraft:black_concrete
fill 268 189 230 268 190 230 minecraft:cyan_terracotta
fill 268 189 232 268 190 232 minecraft:cyan_terracotta
fill 268 189 234 268 190 234 minecraft:cyan_terracotta
fill 268 189 236 268 190 236 minecraft:cyan_terracotta
fill 268 189 262 268 190 262 minecraft:light_gray_concrete
fill 268 189 264 268 190 264 minecraft:light_gray_concrete
fill 268 189 266 268 190 266 minecraft:light_gray_concrete
fill 268 189 268 268 190 268 minecraft:light_gray_concrete
fill 269 189 229 269 190 229 minecraft:cyan_terracotta
fill 269 189 237 269 190 237 minecraft:cyan_terracotta
fill 269 189 261 269 190 261 minecraft:light_gray_concrete
fill 269 189 269 269 190 269 minecraft:light_gray_concrete
fill 271 189 229 271 190 229 minecraft:cyan_terracotta
fill 271 189 237 271 190 237 minecraft:cyan_terracotta
fill 271 189 243 271 190 243 minecraft:light_gray_concrete
fill 271 189 245 271 190 245 minecraft:light_gray_concrete
fill 271 189 247 271 190 247 minecraft:light_gray_concrete
fill 271 189 249 271 190 249 minecraft:light_gray_concrete
fill 271 189 251 271 190 251 minecraft:light_gray_concrete
fill 271 189 253 271 190 253 minecraft:light_gray_concrete
fill 271 189 261 271 190 261 minecraft:light_gray_concrete
fill 271 189 269 271 190 269 minecraft:light_gray_concrete
setblock 271 189 270 minecraft:pearlescent_froglight
fill 272 189 242 272 190 242 minecraft:light_gray_concrete
fill 272 189 255 272 190 255 minecraft:light_gray_concrete
fill 273 189 229 273 190 229 minecraft:cyan_terracotta
fill 273 189 237 273 190 237 minecraft:cyan_terracotta
fill 273 189 261 273 190 261 minecraft:light_gray_concrete
fill 273 189 269 273 190 269 minecraft:light_gray_concrete
fill 274 189 242 274 190 242 minecraft:light_gray_concrete
fill 274 189 255 274 190 255 minecraft:light_gray_concrete
fill 275 189 229 275 190 229 minecraft:cyan_terracotta
fill 275 189 237 275 190 237 minecraft:cyan_terracotta
fill 275 189 261 275 190 261 minecraft:light_gray_concrete
fill 275 189 269 275 190 269 minecraft:light_gray_concrete
fill 276 189 230 276 190 230 minecraft:cyan_terracotta
fill 276 189 232 276 190 232 minecraft:cyan_terracotta
fill 276 189 234 276 190 234 minecraft:cyan_terracotta
fill 276 189 236 276 190 236 minecraft:cyan_terracotta
fill 276 189 243 276 190 243 minecraft:light_gray_concrete
fill 276 189 245 276 190 245 minecraft:light_gray_concrete
fill 276 189 247 276 190 247 minecraft:light_gray_concrete
fill 276 189 249 276 190 249 minecraft:light_gray_concrete
fill 276 189 251 276 190 251 minecraft:light_gray_concrete
fill 276 189 253 276 190 253 minecraft:light_gray_concrete
fill 276 189 262 276 190 262 minecraft:light_gray_concrete
fill 276 189 264 276 190 264 minecraft:light_gray_concrete
fill 276 189 266 276 190 266 minecraft:light_gray_concrete
fill 276 189 268 276 190 268 minecraft:light_gray_concrete
setblock 277 189 264 minecraft:ochre_froglight
fill 235 190 243 235 237 243 minecraft:black_concrete
fill 254 190 270 254 209 270 minecraft:black_concrete
fill 271 190 270 271 306 270 minecraft:black_concrete
fill 277 190 264 277 201 264 minecraft:black_concrete
setblock 277 190 266 minecraft:purple_concrete
setblock 235 191 254 minecraft:pearlescent_froglight
setblock 236 191 230 minecraft:black_stained_glass
setblock 236 191 232 minecraft:ochre_froglight
setblock 236 191 234 minecraft:black_stained_glass
setblock 236 191 236 minecraft:sea_lantern
setblock 236 191 262 minecraft:pearlescent_froglight
setblock 236 191 264 minecraft:sea_lantern
setblock 236 191 266 minecraft:black_stained_glass
setblock 236 191 268 minecraft:cyan_stained_glass
setblock 237 191 229 minecraft:pearlescent_froglight
setblock 237 191 237 minecraft:black_stained_glass
setblock 237 191 261 minecraft:pearlescent_froglight
setblock 237 191 269 minecraft:black_stained_glass
setblock 239 191 229 minecraft:light_blue_stained_glass
setblock 239 191 237 minecraft:black_stained_glass
setblock 239 191 261 minecraft:ochre_froglight
setblock 239 191 269 minecraft:magenta_stained_glass
setblock 241 191 229 minecraft:sea_lantern
setblock 241 191 237 minecraft:black_stained_glass
setblock 241 191 261 minecraft:black_stained_glass
setblock 241 191 269 minecraft:black_stained_glass
setblock 243 191 229 minecraft:black_stained_glass
setblock 243 191 237 minecraft:ochre_froglight
setblock 243 191 261 minecraft:black_stained_glass
setblock 243 191 269 minecraft:black_stained_glass
setblock 244 191 230 minecraft:black_stained_glass
setblock 244 191 232 minecraft:black_stained_glass
setblock 244 191 234 minecraft:cyan_stained_glass
setblock 244 191 236 minecraft:cyan_stained_glass
setblock 244 191 262 minecraft:cyan_stained_glass
setblock 244 191 264 minecraft:pearlescent_froglight
setblock 244 191 266 minecraft:ochre_froglight
setblock 244 191 268 minecraft:black_stained_glass
setblock 268 191 230 minecraft:pearlescent_froglight
setblock 268 191 232 minecraft:black_stained_glass
setblock 268 191 234 minecraft:light_blue_stained_glass
setblock 268 191 236 minecraft:cyan_stained_glass
fill 268 191 262 268 194 262 minecraft:magenta_stained_glass
setblock 268 191 264 minecraft:black_stained_glass
setblock 268 191 266 minecraft:sea_lantern
setblock 268 191 268 minecraft:pearlescent_froglight
setblock 269 191 229 minecraft:black_stained_glass
setblock 269 191 237 minecraft:ochre_froglight
setblock 269 191 261 minecraft:black_stained_glass
setblock 269 191 269 minecraft:ochre_froglight
setblock 271 191 229 minecraft:black_stained_glass
setblock 271 191 237 minecraft:black_stained_glass
setblock 271 191 243 minecraft:black_stained_glass
setblock 271 191 245 minecraft:black_stained_glass
setblock 271 191 247 minecraft:black_stained_glass
setblock 271 191 249 minecraft:pearlescent_froglight
setblock 271 191 251 minecraft:pearlescent_froglight
setblock 271 191 253 minecraft:black_stained_glass
setblock 271 191 261 minecraft:pearlescent_froglight
setblock 271 191 269 minecraft:light_blue_stained_glass
setblock 272 191 242 minecraft:black_stained_glass
setblock 272 191 255 minecraft:light_blue_stained_glass
setblock 273 191 229 minecraft:ochre_froglight
setblock 273 191 237 minecraft:black_stained_glass
setblock 273 191 261 minecraft:ochre_froglight
setblock 273 191 269 minecraft:light_blue_stained_glass
setblock 274 191 242 minecraft:sea_lantern
setblock 274 191 255 minecraft:black_stained_glass
setblock 275 191 229 minecraft:black_stained_glass
setblock 275 191 237 minecraft:black_stained_glass
setblock 275 191 261 minecraft:sea_lantern
setblock 275 191 269 minecraft:magenta_stained_glass
setblock 276 191 230 minecraft:magenta_stained_glass
setblock 276 191 232 minecraft:black_stained_glass
setblock 276 191 234 minecraft:magenta_stained_glass
setblock 276 191 236 minecraft:sea_lantern
setblock 276 191 243 minecraft:pearlescent_froglight
setblock 276 191 245 minecraft:ochre_froglight
setblock 276 191 247 minecraft:magenta_stained_glass
setblock 276 191 249 minecraft:black_stained_glass
setblock 276 191 251 minecraft:black_stained_glass
setblock 276 191 253 minecraft:magenta_stained_glass
setblock 276 191 262 minecraft:ochre_froglight
setblock 276 191 264 minecraft:black_stained_glass
setblock 276 191 266 minecraft:black_stained_glass
setblock 276 191 268 minecraft:sea_lantern
setblock 277 191 239 minecraft:blue_concrete
setblock 277 191 251 minecraft:verdant_froglight
fill 277 191 266 277 234 266 minecraft:black_concrete
fill 235 192 254 235 308 254 minecraft:black_concrete
setblock 235 192 264 minecraft:verdant_froglight
fill 236 192 230 236 193 230 minecraft:light_gray_concrete
fill 236 192 232 236 193 232 minecraft:light_gray_concrete
fill 236 192 234 236 193 234 minecraft:light_gray_concrete
fill 236 192 236 236 193 236 minecraft:light_gray_concrete
fill 236 192 262 236 193 262 minecraft:cyan_terracotta
fill 236 192 264 236 193 264 minecraft:cyan_terracotta
fill 236 192 266 236 193 266 minecraft:cyan_terracotta
fill 236 192 268 236 193 268 minecraft:cyan_terracotta
fill 237 192 229 237 193 229 minecraft:light_gray_concrete
fill 237 192 237 237 193 237 minecraft:light_gray_concrete
fill 237 192 261 237 193 261 minecraft:cyan_terracotta
fill 237 192 269 237 193 269 minecraft:cyan_terracotta
setblock 238 192 239 minecraft:light[level=15]
setblock 238 192 247 minecraft:light[level=15]
setblock 238 192 255 minecraft:light[level=15]
fill 239 192 229 239 193 229 minecraft:light_gray_concrete
fill 239 192 237 239 193 237 minecraft:light_gray_concrete
fill 239 192 261 239 193 261 minecraft:cyan_terracotta
fill 239 192 269 239 193 269 minecraft:cyan_terracotta
setblock 239 192 270 minecraft:ochre_froglight
fill 241 192 229 241 193 229 minecraft:light_gray_concrete
fill 241 192 237 241 193 237 minecraft:light_gray_concrete
fill 241 192 261 241 193 261 minecraft:cyan_terracotta
fill 241 192 269 241 193 269 minecraft:cyan_terracotta
fill 243 192 229 243 193 229 minecraft:light_gray_concrete
fill 243 192 237 243 193 237 minecraft:light_gray_concrete
fill 243 192 261 243 193 261 minecraft:cyan_terracotta
fill 243 192 269 243 193 269 minecraft:cyan_terracotta
fill 244 192 230 244 193 230 minecraft:light_gray_concrete
fill 244 192 232 244 193 232 minecraft:light_gray_concrete
fill 244 192 234 244 193 234 minecraft:light_gray_concrete
fill 244 192 236 244 193 236 minecraft:light_gray_concrete
fill 244 192 262 244 193 262 minecraft:cyan_terracotta
fill 244 192 264 244 193 264 minecraft:cyan_terracotta
fill 244 192 266 244 193 266 minecraft:cyan_terracotta
fill 244 192 268 244 193 268 minecraft:cyan_terracotta
setblock 246 192 231 minecraft:light[level=15]
setblock 246 192 239 minecraft:light[level=15]
setblock 246 192 247 minecraft:light[level=15]
setblock 246 192 255 minecraft:light[level=15]
setblock 246 192 263 minecraft:light[level=15]
setblock 254 192 231 minecraft:light[level=15]
setblock 254 192 239 minecraft:light[level=15]
setblock 254 192 247 minecraft:light[level=15]
setblock 254 192 255 minecraft:light[level=15]
setblock 254 192 263 minecraft:light[level=15]
setblock 262 192 231 minecraft:light[level=15]
setblock 262 192 239 minecraft:light[level=15]
setblock 262 192 247 minecraft:light[level=15]
fill 262 192 255 267 192 263 minecraft:magenta_stained_glass
fill 268 192 230 268 193 230 minecraft:cyan_terracotta
fill 268 192 232 268 193 232 minecraft:cyan_terracotta
fill 268 192 234 268 193 234 minecraft:cyan_terracotta
fill 268 192 236 268 193 236 minecraft:cyan_terracotta
fill 268 192 255 270 192 261 minecraft:magenta_stained_glass
fill 268 192 263 270 192 263 minecraft:magenta_stained_glass
fill 268 192 264 268 193 264 minecraft:light_gray_concrete
fill 268 192 266 268 193 266 minecraft:light_gray_concrete
fill 268 192 268 268 193 268 minecraft:light_gray_concrete
fill 269 192 229 269 193 229 minecraft:cyan_terracotta
fill 269 192 237 269 193 237 minecraft:cyan_terracotta
fill 269 192 262 270 192 262 minecraft:magenta_stained_glass
fill 269 192 269 269 193 269 minecraft:light_gray_concrete
setblock 269 192 270 minecraft:purple_concrete
setblock 270 192 239 minecraft:light[level=15]
setblock 270 192 247 minecraft:light[level=15]
fill 271 192 229 271 193 229 minecraft:cyan_terracotta
fill 271 192 237 271 193 237 minecraft:cyan_terracotta
fill 271 192 243 271 193 243 minecraft:light_gray_concrete
fill 271 192 245 271 193 245 minecraft:light_gray_concrete
fill 271 192 247 271 193 247 minecraft:light_gray_concrete
fill 271 192 249 271 193 249 minecraft:light_gray_concrete
fill 271 192 251 271 193 251 minecraft:light_gray_concrete
fill 271 192 253 271 193 253 minecraft:light_gray_concrete
fill 271 192 261 271 193 263 minecraft:light_gray_concrete
fill 271 192 269 271 193 269 minecraft:light_gray_concrete
fill 272 192 242 272 193 242 minecraft:light_gray_concrete
fill 272 192 255 272 193 255 minecraft:light_gray_concrete
fill 272 192 262 276 193 263 minecraft:light_gray_concrete
fill 273 192 229 273 193 229 minecraft:cyan_terracotta
fill 273 192 237 273 193 237 minecraft:cyan_terracotta
fill 273 192 261 273 193 261 minecraft:light_gray_concrete
fill 273 192 269 273 193 269 minecraft:light_gray_concrete
fill 274 192 242 274 193 242 minecraft:light_gray_concrete
fill 274 192 255 274 193 255 minecraft:light_gray_concrete
fill 275 192 229 275 193 229 minecraft:cyan_terracotta
fill 275 192 237 275 193 237 minecraft:cyan_terracotta
fill 275 192 261 275 193 261 minecraft:light_gray_concrete
fill 275 192 269 275 193 269 minecraft:light_gray_concrete
fill 276 192 230 276 193 230 minecraft:cyan_terracotta
fill 276 192 232 276 193 232 minecraft:cyan_terracotta
fill 276 192 234 276 193 234 minecraft:cyan_terracotta
fill 276 192 236 276 193 236 minecraft:cyan_terracotta
fill 276 192 243 276 193 243 minecraft:light_gray_concrete
fill 276 192 245 276 193 245 minecraft:light_gray_concrete
fill 276 192 247 276 193 247 minecraft:light_gray_concrete
fill 276 192 249 276 193 249 minecraft:light_gray_concrete
fill 276 192 251 276 193 251 minecraft:light_gray_concrete
fill 276 192 253 276 193 253 minecraft:light_gray_concrete
fill 276 192 264 276 193 264 minecraft:light_gray_concrete
fill 276 192 266 276 193 266 minecraft:light_gray_concrete
fill 276 192 268 276 193 268 minecraft:light_gray_concrete
fill 277 192 239 277 298 239 minecraft:black_concrete
fill 277 192 251 277 276 251 minecraft:black_concrete
fill 235 193 264 235 218 264 minecraft:black_concrete
setblock 238 193 238 minecraft:light[level=12]
setblock 238 193 245 minecraft:light[level=12]
setblock 238 193 252 minecraft:light[level=12]
setblock 238 193 259 minecraft:light[level=12]
fill 239 193 270 239 211 270 minecraft:black_concrete
setblock 245 193 231 minecraft:light[level=12]
setblock 245 193 238 minecraft:light[level=12]
setblock 245 193 245 minecraft:light[level=12]
setblock 245 193 252 minecraft:light[level=12]
setblock 245 193 259 minecraft:light[level=12]
setblock 245 193 266 minecraft:light[level=12]
setblock 252 193 231 minecraft:light[level=12]
setblock 252 193 238 minecraft:light[level=12]
setblock 252 193 245 minecraft:light[level=12]
setblock 252 193 252 minecraft:light[level=12]
setblock 252 193 259 minecraft:light[level=12]
setblock 252 193 266 minecraft:light[level=12]
setblock 259 193 231 minecraft:light[level=12]
setblock 259 193 238 minecraft:light[level=12]
setblock 259 193 245 minecraft:light[level=12]
setblock 259 193 252 minecraft:light[level=12]
setblock 259 193 259 minecraft:light[level=12]
setblock 259 193 266 minecraft:light[level=12]
fill 263 193 256 263 194 262 minecraft:magenta_stained_glass
fill 264 193 256 269 194 256 minecraft:magenta_stained_glass
fill 264 193 262 267 194 262 minecraft:magenta_stained_glass
setblock 266 193 231 minecraft:light[level=12]
setblock 266 193 238 minecraft:light[level=12]
setblock 266 193 245 minecraft:light[level=12]
setblock 266 193 252 minecraft:light[level=12]
setblock 266 193 259 minecraft:light[level=12]
setblock 266 193 266 minecraft:light[level=12]
fill 268 193 261 268 194 261 minecraft:light_gray_concrete
fill 268 193 263 270 237 263 minecraft:light_gray_concrete
fill 269 193 257 269 194 262 minecraft:magenta_stained_glass
fill 269 193 270 269 240 270 minecraft:black_concrete
fill 270 193 261 270 237 262 minecraft:light_gray_concrete
setblock 273 193 238 minecraft:light[level=12]
setblock 273 193 259 minecraft:light[level=12]
setblock 277 193 257 minecraft:blue_concrete
setblock 235 194 266 minecraft:purple_concrete
setblock 236 194 230 minecraft:pearlescent_froglight
setblock 236 194 232 minecraft:cyan_stained_glass
setblock 236 194 234 minecraft:cyan_stained_glass
setblock 236 194 236 minecraft:sea_lantern
setblock 236 194 262 minecraft:ochre_froglight
setblock 236 194 264 minecraft:black_stained_glass
setblock 236 194 266 minecraft:magenta_stained_glass
setblock 236 194 268 minecraft:black_stained_glass
setblock 237 194 229 minecraft:black_stained_glass
setblock 237 194 237 minecraft:black_stained_glass
setblock 237 194 261 minecraft:black_stained_glass
setblock 237 194 269 minecraft:black_stained_glass
setblock 239 194 229 minecraft:light_blue_stained_glass
setblock 239 194 237 minecraft:ochre_froglight
setblock 239 194 261 minecraft:cyan_stained_glass
setblock 239 194 269 minecraft:cyan_stained_glass
setblock 241 194 229 minecraft:pearlescent_froglight
setblock 241 194 237 minecraft:cyan_stained_glass
setblock 241 194 261 minecraft:black_stained_glass
setblock 241 194 269 minecraft:ochre_froglight
setblock 243 194 229 minecraft:black_stained_glass
setblock 243 194 237 minecraft:light_blue_stained_glass
setblock 243 194 261 minecraft:black_stained_glass
setblock 243 194 269 minecraft:cyan_stained_glass
setblock 244 194 230 minecraft:magenta_stained_glass
setblock 244 194 232 minecraft:black_stained_glass
setblock 244 194 234 minecraft:black_stained_glass
setblock 244 194 236 minecraft:black_stained_glass
setblock 244 194 262 minecraft:black_stained_glass
setblock 244 194 264 minecraft:light_blue_stained_glass
setblock 244 194 266 minecraft:ochre_froglight
setblock 244 194 268 minecraft:cyan_stained_glass
setblock 267 194 270 minecraft:blue_concrete
setblock 268 194 230 minecraft:black_stained_glass
setblock 268 194 232 minecraft:black_stained_glass
setblock 268 194 234 minecraft:sea_lantern
setblock 268 194 236 minecraft:black_stained_glass
setblock 268 194 264 minecraft:light_blue_stained_glass
setblock 268 194 266 minecraft:ochre_froglight
setblock 268 194 268 minecraft:black_stained_glass
setblock 269 194 229 minecraft:black_stained_glass
setblock 269 194 237 minecraft:cyan_stained_glass
setblock 269 194 269 minecraft:magenta_stained_glass
setblock 271 194 229 minecraft:sea_lantern
setblock 271 194 237 minecraft:black_stained_glass
setblock 271 194 243 minecraft:ochre_froglight
setblock 271 194 245 minecraft:black_stained_glass
setblock 271 194 247 minecraft:light_blue_stained_glass
setblock 271 194 249 minecraft:black_stained_glass
setblock 271 194 251 minecraft:black_stained_glass
setblock 271 194 253 minecraft:black_stained_glass
setblock 271 194 261 minecraft:sea_lantern
fill 271 194 262 275 229 263 minecraft:light_gray_concrete
setblock 271 194 269 minecraft:black_stained_glass
setblock 272 194 242 minecraft:sea_lantern
setblock 272 194 255 minecraft:pearlescent_froglight
setblock 273 194 229 minecraft:sea_lantern
setblock 273 194 237 minecraft:black_stained_glass
setblock 273 194 261 minecraft:pearlescent_froglight
setblock 273 194 269 minecraft:black_stained_glass
setblock 274 194 242 minecraft:black_stained_glass
setblock 274 194 255 minecraft:black_stained_glass
setblock 275 194 229 minecraft:light_blue_stained_glass
setblock 275 194 237 minecraft:black_stained_glass
setblock 275 194 261 minecraft:magenta_stained_glass
setblock 275 194 269 minecraft:black_stained_glass
setblock 276 194 230 minecraft:black_stained_glass
setblock 276 194 232 minecraft:light_blue_stained_glass
setblock 276 194 234 minecraft:pearlescent_froglight
setblock 276 194 236 minecraft:black_stained_glass
setblock 276 194 243 minecraft:black_stained_glass
setblock 276 194 245 minecraft:black_stained_glass
setblock 276 194 247 minecraft:black_stained_glass
setblock 276 194 249 minecraft:black_stained_glass
setblock 276 194 251 minecraft:cyan_stained_glass
setblock 276 194 253 minecraft:magenta_stained_glass
setblock 276 194 262 minecraft:sea_lantern
fill 276 194 263 276 237 263 minecraft:light_gray_concrete
setblock 276 194 264 minecraft:light_blue_stained_glass
setblock 276 194 266 minecraft:magenta_stained_glass
setblock 276 194 268 minecraft:magenta_stained_glass
fill 277 194 257 277 212 257 minecraft:black_concrete
setblock 235 195 236 minecraft:verdant_froglight
fill 235 195 266 235 209 266 minecraft:black_concrete
setblock 236 195 228 minecraft:purple_concrete
fill 236 195 230 236 196 230 minecraft:light_gray_concrete
fill 236 195 232 236 196 232 minecraft:light_gray_concrete
fill 236 195 234 236 196 234 minecraft:light_gray_concrete
fill 236 195 236 236 196 236 minecraft:light_gray_concrete
fill 236 195 262 236 196 262 minecraft:cyan_terracotta
fill 236 195 264 236 196 264 minecraft:cyan_terracotta
fill 236 195 266 236 196 266 minecraft:cyan_terracotta
fill 236 195 268 236 196 268 minecraft:cyan_terracotta
fill 237 195 229 237 196 229 minecraft:light_gray_concrete
fill 237 195 237 237 196 237 minecraft:light_gray_concrete
fill 237 195 261 237 196 261 minecraft:cyan_terracotta
fill 237 195 269 237 196 269 minecraft:cyan_terracotta
fill 239 195 229 239 196 229 minecraft:light_gray_concrete
fill 239 195 237 239 196 237 minecraft:light_gray_concrete
fill 239 195 261 239 196 261 minecraft:cyan_terracotta
fill 239 195 269 239 196 269 minecraft:cyan_terracotta
fill 241 195 229 241 196 229 minecraft:light_gray_concrete
fill 241 195 237 241 196 237 minecraft:light_gray_concrete
fill 241 195 261 241 196 261 minecraft:cyan_terracotta
fill 241 195 269 241 196 269 minecraft:cyan_terracotta
fill 243 195 229 243 196 229 minecraft:light_gray_concrete
fill 243 195 237 243 196 237 minecraft:light_gray_concrete
fill 243 195 261 243 196 261 minecraft:cyan_terracotta
fill 243 195 269 243 196 269 minecraft:cyan_terracotta
fill 244 195 230 244 196 230 minecraft:light_gray_concrete
fill 244 195 232 244 196 232 minecraft:light_gray_concrete
fill 244 195 234 244 196 234 minecraft:light_gray_concrete
fill 244 195 236 244 196 236 minecraft:light_gray_concrete
fill 244 195 262 244 196 262 minecraft:cyan_terracotta
fill 244 195 264 244 196 264 minecraft:cyan_terracotta
fill 244 195 266 244 196 266 minecraft:cyan_terracotta
fill 244 195 268 244 196 268 minecraft:cyan_terracotta
fill 264 195 257 264 196 261 minecraft:magenta_stained_glass
fill 265 195 257 268 196 257 minecraft:magenta_stained_glass
fill 265 195 261 268 196 261 minecraft:magenta_stained_glass
fill 267 195 270 267 308 270 minecraft:black_concrete
fill 268 195 230 268 196 230 minecraft:cyan_terracotta
fill 268 195 232 268 196 232 minecraft:cyan_terracotta
fill 268 195 234 268 196 234 minecraft:cyan_terracotta
fill 268 195 236 268 196 236 minecraft:cyan_terracotta
fill 268 195 258 268 196 260 minecraft:magenta_stained_glass
fill 268 195 262 269 196 262 minecraft:light_gray_concrete
fill 268 195 264 268 196 264 minecraft:light_gray_concrete
fill 268 195 266 268 196 266 minecraft:light_gray_concrete
fill 268 195 268 268 196 268 minecraft:light_gray_concrete
fill 269 195 229 269 196 229 minecraft:cyan_terracotta
fill 269 195 237 269 196 237 minecraft:cyan_terracotta
fill 269 195 261 269 196 261 minecraft:light_gray_concrete
fill 269 195 269 269 196 269 minecraft:light_gray_concrete
fill 271 195 229 271 196 229 minecraft:cyan_terracotta
fill 271 195 237 271 196 237 minecraft:cyan_terracotta
fill 271 195 243 271 196 243 minecraft:light_gray_concrete
fill 271 195 245 271 196 245 minecraft:light_gray_concrete
fill 271 195 247 271 196 247 minecraft:light_gray_concrete
fill 271 195 249 271 196 249 minecraft:light_gray_concrete
fill 271 195 251 271 196 251 minecraft:light_gray_concrete
fill 271 195 253 271 196 253 minecraft:light_gray_concrete
fill 271 195 261 271 196 261 minecraft:light_gray_concrete
fill 271 195 269 271 196 269 minecraft:light_gray_concrete
fill 272 195 242 272 196 242 minecraft:light_gray_concrete
fill 272 195 255 272 196 255 minecraft:light_gray_concrete
fill 273 195 229 273 196 229 minecraft:cyan_terracotta
fill 273 195 237 273 196 237 minecraft:cyan_terracotta
fill 273 195 261 273 196 261 minecraft:light_gray_concrete
fill 273 195 269 273 196 269 minecraft:light_gray_concrete
fill 274 195 242 274 196 242 minecraft:light_gray_concrete
fill 274 195 255 274 196 255 minecraft:light_gray_concrete
fill 275 195 229 275 196 229 minecraft:cyan_terracotta
fill 275 195 237 275 196 237 minecraft:cyan_terracotta
fill 275 195 261 275 196 261 minecraft:light_gray_concrete
fill 275 195 269 275 196 269 minecraft:light_gray_concrete
fill 276 195 230 276 196 230 minecraft:cyan_terracotta
fill 276 195 232 276 196 232 minecraft:cyan_terracotta
fill 276 195 234 276 196 234 minecraft:cyan_terracotta
fill 276 195 236 276 196 236 minecraft:cyan_terracotta
fill 276 195 243 276 196 243 minecraft:light_gray_concrete
fill 276 195 245 276 196 245 minecraft:light_gray_concrete
fill 276 195 247 276 196 247 minecraft:light_gray_concrete
fill 276 195 249 276 196 249 minecraft:light_gray_concrete
fill 276 195 251 276 196 251 minecraft:light_gray_concrete
fill 276 195 253 276 196 253 minecraft:light_gray_concrete
fill 276 195 262 276 196 262 minecraft:light_gray_concrete
fill 276 195 264 276 196 264 minecraft:light_gray_concrete
fill 276 195 266 276 196 266 minecraft:light_gray_concrete
fill 276 195 268 276 196 268 minecraft:light_gray_concrete
setblock 277 195 258 minecraft:verdant_froglight
setblock 277 195 269 minecraft:pearlescent_froglight
fill 235 196 236 235 308 236 minecraft:black_concrete
fill 235 196 257 235 197 257 minecraft:sea_lantern
fill 236 196 228 236 257 228 minecraft:black_concrete
setblock 238 196 248 minecraft:redstone_block
setblock 277 196 234 minecraft:blue_concrete
fill 277 196 258 277 308 258 minecraft:black_concrete
fill 277 196 269 277 200 269 minecraft:black_concrete
setblock 236 197 230 minecraft:black_stained_glass
setblock 236 197 232 minecraft:pearlescent_froglight
setblock 236 197 234 minecraft:black_stained_glass
setblock 236 197 236 minecraft:light_blue_stained_glass
setblock 236 197 262 minecraft:pearlescent_froglight
setblock 236 197 264 minecraft:magenta_stained_glass
setblock 236 197 266 minecraft:cyan_stained_glass
setblock 236 197 268 minecraft:ochre_froglight
setblock 237 197 229 minecraft:pearlescent_froglight
setblock 237 197 237 minecraft:ochre_froglight
setblock 237 197 261 minecraft:black_stained_glass
setblock 237 197 269 minecraft:pearlescent_froglight
setblock 239 197 229 minecraft:black_stained_glass
setblock 239 197 237 minecraft:sea_lantern
setblock 239 197 261 minecraft:sea_lantern
setblock 239 197 269 minecraft:black_stained_glass
setblock 241 197 229 minecraft:black_stained_glass
setblock 241 197 237 minecraft:ochre_froglight
setblock 241 197 261 minecraft:black_stained_glass
setblock 241 197 269 minecraft:light_blue_stained_glass
setblock 243 197 229 minecraft:magenta_stained_glass
setblock 243 197 237 minecraft:pearlescent_froglight
setblock 243 197 261 minecraft:black_stained_glass
setblock 243 197 269 minecraft:black_stained_glass
setblock 244 197 230 minecraft:sea_lantern
setblock 244 197 232 minecraft:black_stained_glass
setblock 244 197 234 minecraft:black_stained_glass
setblock 244 197 236 minecraft:magenta_stained_glass
setblock 244 197 262 minecraft:black_stained_glass
setblock 244 197 264 minecraft:black_stained_glass
setblock 244 197 266 minecraft:sea_lantern
setblock 244 197 268 minecraft:magenta_stained_glass
setblock 265 197 228 minecraft:ochre_froglight
fill 265 197 258 265 198 260 minecraft:magenta_stained_glass
fill 266 197 258 267 198 258 minecraft:magenta_stained_glass
fill 266 197 260 267 198 260 minecraft:magenta_stained_glass
fill 267 197 259 267 198 259 minecraft:magenta_stained_glass
setblock 268 197 230 minecraft:black_stained_glass
setblock 268 197 232 minecraft:magenta_stained_glass
setblock 268 197 234 minecraft:black_stained_glass
setblock 268 197 236 minecraft:cyan_stained_glass
fill 268 197 261 268 237 261 minecraft:light_gray_concrete
setblock 268 197 262 minecraft:black_stained_glass
setblock 268 197 264 minecraft:black_stained_glass
setblock 268 197 266 minecraft:cyan_stained_glass
setblock 268 197 268 minecraft:light_blue_stained_glass
setblock 269 197 229 minecraft:black_stained_glass
setblock 269 197 237 minecraft:black_stained_glass
setblock 269 197 261 minecraft:black_stained_glass
fill 269 197 262 269 237 262 minecraft:light_gray_concrete
setblock 269 197 269 minecraft:black_stained_glass
setblock 271 197 229 minecraft:ochre_froglight
setblock 271 197 237 minecraft:black_stained_glass
setblock 271 197 243 minecraft:black_stained_glass
setblock 271 197 245 minecraft:ochre_froglight
setblock 271 197 247 minecraft:light_blue_stained_glass
setblock 271 197 249 minecraft:cyan_stained_glass
setblock 271 197 251 minecraft:black_stained_glass
setblock 271 197 253 minecraft:black_stained_glass
setblock 271 197 261 minecraft:magenta_stained_glass
setblock 271 197 269 minecraft:cyan_stained_glass
setblock 272 197 242 minecraft:magenta_stained_glass
setblock 272 197 255 minecraft:light_blue_stained_glass
setblock 273 197 229 minecraft:black_stained_glass
setblock 273 197 237 minecraft:sea_lantern
setblock 273 197 261 minecraft:black_stained_glass
setblock 273 197 269 minecraft:black_stained_glass
setblock 274 197 242 minecraft:magenta_stained_glass
setblock 274 197 255 minecraft:black_stained_glass
setblock 275 197 229 minecraft:ochre_froglight
setblock 275 197 237 minecraft:black_stained_glass
setblock 275 197 261 minecraft:light_blue_stained_glass
setblock 275 197 269 minecraft:black_stained_glass
setblock 276 197 230 minecraft:black_stained_glass
setblock 276 197 232 minecraft:light_blue_stained_glass
setblock 276 197 234 minecraft:pearlescent_froglight
setblock 276 197 236 minecraft:black_stained_glass
setblock 276 197 243 minecraft:black_stained_glass
setblock 276 197 245 minecraft:light_blue_stained_glass
setblock 276 197 247 minecraft:black_stained_glass
setblock 276 197 249 minecraft:black_stained_glass
setblock 276 197 251 minecraft:magenta_stained_glass
setblock 276 197 253 minecraft:black_stained_glass
setblock 276 197 262 minecraft:pearlescent_froglight
setblock 276 197 264 minecraft:ochre_froglight
setblock 276 197 266 minecraft:black_stained_glass
setblock 276 197 268 minecraft:sea_lantern
fill 277 197 234 277 297 234 minecraft:black_concrete
fill 235 198 257 235 219 257 minecraft:black_concrete
fill 236 198 230 236 199 230 minecraft:light_gray_concrete
fill 236 198 232 236 199 232 minecraft:light_gray_concrete
fill 236 198 234 236 199 234 minecraft:light_gray_concrete
fill 236 198 236 236 199 236 minecraft:light_gray_concrete
setblock 236 198 262 minecraft:cyan_terracotta
setblock 236 198 264 minecraft:cyan_terracotta
setblock 236 198 266 minecraft:cyan_terracotta
setblock 236 198 268 minecraft:cyan_terracotta
fill 237 198 229 237 199 229 minecraft:light_gray_concrete
fill 237 198 237 237 199 237 minecraft:light_gray_concrete
setblock 237 198 261 minecraft:cyan_terracotta
setblock 237 198 269 minecraft:cyan_terracotta
fill 239 198 229 239 199 229 minecraft:light_gray_concrete
fill 239 198 237 239 199 237 minecraft:light_gray_concrete
setblock 239 198 261 minecraft:cyan_terracotta
setblock 239 198 269 minecraft:cyan_terracotta
fill 241 198 229 241 199 229 minecraft:light_gray_concrete
fill 241 198 237 241 199 237 minecraft:light_gray_concrete
setblock 241 198 261 minecraft:cyan_terracotta
setblock 241 198 269 minecraft:cyan_terracotta
fill 243 198 229 243 199 229 minecraft:light_gray_concrete
fill 243 198 237 243 199 237 minecraft:light_gray_concrete
setblock 243 198 261 minecraft:cyan_terracotta
setblock 243 198 269 minecraft:cyan_terracotta
fill 244 198 230 244 199 230 minecraft:light_gray_concrete
fill 244 198 232 244 199 232 minecraft:light_gray_concrete
fill 244 198 234 244 199 234 minecraft:light_gray_concrete
fill 244 198 236 244 199 236 minecraft:light_gray_concrete
setblock 244 198 262 minecraft:cyan_terracotta
setblock 244 198 264 minecraft:cyan_terracotta
setblock 244 198 266 minecraft:cyan_terracotta
setblock 244 198 268 minecraft:cyan_terracotta
fill 265 198 228 265 292 228 minecraft:black_concrete
fill 268 198 230 268 199 230 minecraft:cyan_terracotta
fill 268 198 232 268 199 232 minecraft:cyan_terracotta
fill 268 198 234 268 199 234 minecraft:cyan_terracotta
fill 268 198 236 268 199 236 minecraft:cyan_terracotta
fill 268 198 262 268 199 262 minecraft:light_gray_concrete
fill 268 198 264 268 199 264 minecraft:light_gray_concrete
fill 268 198 266 268 199 266 minecraft:light_gray_concrete
fill 268 198 268 268 199 268 minecraft:light_gray_concrete
fill 269 198 229 269 199 229 minecraft:cyan_terracotta
fill 269 198 237 269 199 237 minecraft:cyan_terracotta
fill 269 198 261 269 199 261 minecraft:light_gray_concrete
fill 269 198 269 269 199 269 minecraft:light_gray_concrete
fill 271 198 229 271 199 229 minecraft:cyan_terracotta
fill 271 198 237 271 199 237 minecraft:cyan_terracotta
fill 271 198 243 271 199 243 minecraft:light_gray_concrete
fill 271 198 245 271 199 245 minecraft:light_gray_concrete
fill 271 198 247 271 199 247 minecraft:light_gray_concrete
fill 271 198 249 271 199 249 minecraft:light_gray_concrete
fill 271 198 251 271 199 251 minecraft:light_gray_concrete
fill 271 198 253 271 199 253 minecraft:light_gray_concrete
fill 271 198 261 271 199 261 minecraft:light_gray_concrete
fill 271 198 269 271 199 269 minecraft:light_gray_concrete
fill 272 198 242 272 199 242 minecraft:light_gray_concrete
fill 272 198 255 272 199 255 minecraft:light_gray_concrete
fill 273 198 229 273 199 229 minecraft:cyan_terracotta
fill 273 198 237 273 199 237 minecraft:cyan_terracotta
fill 273 198 261 273 199 261 minecraft:light_gray_concrete
fill 273 198 269 273 199 269 minecraft:light_gray_concrete
fill 274 198 242 274 199 242 minecraft:light_gray_concrete
fill 274 198 255 274 199 255 minecraft:light_gray_concrete
fill 275 198 229 275 199 229 minecraft:cyan_terracotta
fill 275 198 237 275 199 237 minecraft:cyan_terracotta
fill 275 198 261 275 199 261 minecraft:light_gray_concrete
fill 275 198 269 275 199 269 minecraft:light_gray_concrete
fill 276 198 230 276 199 230 minecraft:cyan_terracotta
fill 276 198 232 276 199 232 minecraft:cyan_terracotta
fill 276 198 234 276 199 234 minecraft:cyan_terracotta
fill 276 198 236 276 199 236 minecraft:cyan_terracotta
fill 276 198 243 276 199 243 minecraft:light_gray_concrete
fill 276 198 245 276 199 245 minecraft:light_gray_concrete
fill 276 198 247 276 199 247 minecraft:light_gray_concrete
fill 276 198 249 276 199 249 minecraft:light_gray_concrete
fill 276 198 251 276 199 251 minecraft:light_gray_concrete
fill 276 198 253 276 199 253 minecraft:light_gray_concrete
fill 276 198 262 276 199 262 minecraft:light_gray_concrete
fill 276 198 264 276 199 264 minecraft:light_gray_concrete
fill 276 198 266 276 199 266 minecraft:light_gray_concrete
fill 276 198 268 276 199 268 minecraft:light_gray_concrete
fill 236 199 261 244 199 269 minecraft:black_concrete
setblock 238 199 238 minecraft:light[level=12]
setblock 238 199 239 minecraft:light[level=15]
setblock 238 199 245 minecraft:light[level=12]
setblock 238 199 247 minecraft:light[level=15]
setblock 238 199 252 minecraft:light[level=12]
setblock 238 199 255 minecraft:light[level=15]
setblock 238 199 259 minecraft:light[level=12]
setblock 245 199 231 minecraft:light[level=12]
setblock 245 199 238 minecraft:light[level=12]
setblock 245 199 245 minecraft:light[level=12]
setblock 245 199 252 minecraft:light[level=12]
setblock 245 199 259 minecraft:light[level=12]
setblock 245 199 266 minecraft:light[level=12]
setblock 246 199 231 minecraft:light[level=15]
setblock 246 199 239 minecraft:light[level=15]
setblock 246 199 247 minecraft:light[level=15]
setblock 246 199 255 minecraft:light[level=15]
setblock 246 199 263 minecraft:light[level=15]
setblock 252 199 231 minecraft:light[level=12]
setblock 252 199 238 minecraft:light[level=12]
setblock 252 199 245 minecraft:light[level=12]
setblock 252 199 252 minecraft:light[level=12]
setblock 252 199 259 minecraft:light[level=12]
setblock 252 199 266 minecraft:light[level=12]
setblock 254 199 231 minecraft:light[level=15]
setblock 254 199 239 minecraft:light[level=15]
setblock 254 199 247 minecraft:light[level=15]
setblock 254 199 255 minecraft:light[level=15]
setblock 254 199 263 minecraft:light[level=15]
setblock 259 199 231 minecraft:light[level=12]
setblock 259 199 238 minecraft:light[level=12]
setblock 259 199 245 minecraft:light[level=12]
setblock 259 199 252 minecraft:light[level=12]
setblock 259 199 259 minecraft:light[level=12]
setblock 259 199 266 minecraft:light[level=12]
setblock 262 199 231 minecraft:light[level=15]
setblock 262 199 239 minecraft:light[level=15]
setblock 262 199 247 minecraft:light[level=15]
setblock 262 199 255 minecraft:light[level=15]
setblock 262 199 263 minecraft:light[level=15]
setblock 266 199 231 minecraft:light[level=12]
setblock 266 199 238 minecraft:light[level=12]
setblock 266 199 245 minecraft:light[level=12]
setblock 266 199 252 minecraft:light[level=12]
fill 266 199 259 266 200 259 minecraft:magenta_stained_glass
setblock 266 199 266 minecraft:light[level=12]
fill 268 199 233 271 199 233 minecraft:cyan_terracotta
fill 270 199 234 271 199 234 minecraft:cyan_terracotta
setblock 270 199 239 minecraft:light[level=15]
setblock 270 199 247 minecraft:light[level=15]
setblock 270 199 255 minecraft:light[level=15]
fill 271 199 244 272 199 244 minecraft:light_gray_concrete
fill 271 199 246 272 222 246 minecraft:light_gray_concrete
fill 272 199 233 272 200 236 minecraft:sea_lantern
setblock 272 199 243 minecraft:light_gray_concrete
setblock 272 199 245 minecraft:light_gray_concrete
setblock 273 199 233 minecraft:cyan_terracotta
setblock 273 199 238 minecraft:light[level=12]
fill 273 199 240 273 200 246 minecraft:sea_lantern
setblock 273 199 259 minecraft:light[level=12]
fill 274 199 243 275 199 246 minecraft:light_gray_concrete
fill 276 199 244 276 225 244 minecraft:light_gray_concrete
fill 276 199 246 276 225 246 minecraft:light_gray_concrete
setblock 236 200 230 minecraft:black_stained_glass
setblock 236 200 232 minecraft:magenta_stained_glass
setblock 236 200 234 minecraft:black_stained_glass
setblock 236 200 236 minecraft:light_blue_stained_glass
fill 236 200 261 236 200 269 minecraft:verdant_froglight
setblock 237 200 228 minecraft:magenta_concrete
setblock 237 200 229 minecraft:magenta_stained_glass
setblock 237 200 237 minecraft:black_stained_glass
fill 237 200 261 244 200 261 minecraft:verdant_froglight
fill 237 200 269 244 200 269 minecraft:verdant_froglight
fill 238 200 263 242 201 267 minecraft:cyan_terracotta
setblock 239 200 229 minecraft:magenta_stained_glass
setblock 239 200 237 minecraft:pearlescent_froglight
setblock 241 200 229 minecraft:cyan_stained_glass
setblock 241 200 237 minecraft:pearlescent_froglight
setblock 243 200 229 minecraft:cyan_stained_glass
setblock 243 200 237 minecraft:black_stained_glass
setblock 244 200 230 minecraft:black_stained_glass
setblock 244 200 232 minecraft:ochre_froglight
setblock 244 200 234 minecraft:ochre_froglight
setblock 244 200 236 minecraft:black_stained_glass
fill 244 200 262 244 200 268 minecraft:verdant_froglight
setblock 268 200 230 minecraft:ochre_froglight
setblock 268 200 232 minecraft:black_stained_glass
fill 268 200 233 270 208 233 minecraft:cyan_terracotta
setblock 268 200 234 minecraft:magenta_stained_glass
setblock 268 200 236 minecraft:black_stained_glass
setblock 268 200 262 minecraft:black_stained_glass
setblock 268 200 264 minecraft:cyan_stained_glass
setblock 268 200 266 minecraft:black_stained_glass
setblock 268 200 268 minecraft:black_stained_glass
setblock 269 200 229 minecraft:black_stained_glass
fill 269 200 232 271 208 232 minecraft:cyan_terracotta
setblock 269 200 237 minecraft:black_stained_glass
setblock 269 200 261 minecraft:sea_lantern
setblock 269 200 269 minecraft:sea_lantern
fill 270 200 234 270 208 234 minecraft:cyan_terracotta
setblock 271 200 229 minecraft:black_stained_glass
fill 271 200 233 271 201 235 minecraft:light_blue_stained_glass
fill 271 200 237 273 200 237 minecraft:light_blue_stained_glass
fill 271 200 243 272 200 243 minecraft:light_blue_stained_glass
fill 271 200 244 271 222 244 minecraft:light_gray_concrete
setblock 271 200 245 minecraft:black_stained_glass
setblock 271 200 247 minecraft:cyan_stained_glass
fill 271 200 248 272 222 248 minecraft:light_gray_concrete
setblock 271 200 249 minecraft:black_stained_glass
setblock 271 200 251 minecraft:sea_lantern
setblock 271 200 253 minecraft:sea_lantern
setblock 271 200 261 minecraft:black_stained_glass
setblock 271 200 269 minecraft:cyan_stained_glass
fill 272 200 232 272 201 232 minecraft:light_blue_stained_glass
fill 272 200 238 272 201 242 minecraft:light_blue_stained_glass
fill 272 200 244 272 201 245 minecraft:light_blue_stained_glass
fill 272 200 247 272 222 247 minecraft:light_gray_concrete
fill 272 200 249 272 222 249 minecraft:light_gray_concrete
setblock 272 200 255 minecraft:light_blue_stained_glass
setblock 273 200 229 minecraft:light_blue_stained_glass
fill 273 200 233 273 201 236 minecraft:light_blue_stained_glass
fill 273 200 238 273 201 239 minecraft:light_blue_stained_glass
fill 273 200 247 274 201 249 minecraft:light_blue_stained_glass
setblock 273 200 261 minecraft:magenta_stained_glass
setblock 273 200 269 minecraft:black_stained_glass
fill 274 200 242 274 201 246 minecraft:light_blue_stained_glass
setblock 274 200 255 minecraft:cyan_stained_glass
setblock 275 200 229 minecraft:magenta_stained_glass
setblock 275 200 237 minecraft:sea_lantern
fill 275 200 243 275 225 249 minecraft:light_gray_concrete
setblock 275 200 261 minecraft:black_stained_glass
setblock 275 200 269 minecraft:cyan_stained_glass
setblock 276 200 230 minecraft:cyan_stained_glass
setblock 276 200 232 minecraft:pearlescent_froglight
setblock 276 200 234 minecraft:light_blue_stained_glass
setblock 276 200 236 minecraft:light_blue_stained_glass
setblock 276 200 243 minecraft:black_stained_glass
setblock 276 200 245 minecraft:black_stained_glass
setblock 276 200 247 minecraft:black_stained_glass
fill 276 200 248 276 225 248 minecraft:light_gray_concrete
setblock 276 200 249 minecraft:magenta_stained_glass
setblock 276 200 251 minecraft:magenta_stained_glass
setblock 276 200 253 minecraft:black_stained_glass
setblock 276 200 262 minecraft:light_blue_stained_glass
setblock 276 200 264 minecraft:cyan_stained_glass
setblock 276 200 266 minecraft:ochre_froglight
setblock 276 200 268 minecraft:sea_lantern
setblock 277 200 255 minecraft:cyan_concrete
setblock 235 201 240 minecraft:verdant_froglight
fill 236 201 230 236 202 230 minecraft:light_gray_concrete
fill 236 201 232 236 202 232 minecraft:light_gray_concrete
fill 236 201 234 236 202 234 minecraft:light_gray_concrete
fill 236 201 236 236 202 236 minecraft:light_gray_concrete
setblock 237 201 228 minecraft:sea_lantern
fill 237 201 229 237 202 229 minecraft:light_gray_concrete
fill 237 201 237 237 202 237 minecraft:light_gray_concrete
fill 239 201 229 239 202 229 minecraft:light_gray_concrete
fill 239 201 237 239 202 237 minecraft:light_gray_concrete
fill 241 201 229 241 202 229 minecraft:light_gray_concrete
fill 241 201 237 241 202 237 minecraft:light_gray_concrete
fill 243 201 229 243 202 229 minecraft:light_gray_concrete
fill 243 201 237 243 202 237 minecraft:light_gray_concrete
fill 244 201 230 244 202 230 minecraft:light_gray_concrete
fill 244 201 232 244 202 232 minecraft:light_gray_concrete
fill 244 201 234 244 202 234 minecraft:light_gray_concrete
fill 244 201 236 244 202 236 minecraft:light_gray_concrete
setblock 250 201 270 minecraft:purple_concrete
fill 268 201 230 268 202 230 minecraft:cyan_terracotta
fill 268 201 232 268 202 232 minecraft:cyan_terracotta
fill 268 201 234 268 202 234 minecraft:cyan_terracotta
fill 268 201 236 268 202 236 minecraft:cyan_terracotta
fill 268 201 262 268 202 262 minecraft:light_gray_concrete
fill 268 201 264 268 202 264 minecraft:light_gray_concrete
fill 268 201 266 268 202 266 minecraft:light_gray_concrete
fill 268 201 268 268 202 268 minecraft:light_gray_concrete
fill 269 201 229 269 202 229 minecraft:cyan_terracotta
fill 269 201 237 269 202 237 minecraft:cyan_terracotta
fill 269 201 261 269 202 261 minecraft:light_gray_concrete
fill 269 201 269 269 202 269 minecraft:light_gray_concrete
fill 271 201 229 271 202 229 minecraft:cyan_terracotta
fill 271 201 237 271 202 237 minecraft:cyan_terracotta
fill 271 201 243 271 202 243 minecraft:light_gray_concrete
fill 271 201 245 271 202 245 minecraft:light_gray_concrete
fill 271 201 247 271 202 247 minecraft:light_gray_concrete
fill 271 201 249 271 202 249 minecraft:light_gray_concrete
fill 271 201 251 271 202 251 minecraft:light_gray_concrete
fill 271 201 253 271 202 253 minecraft:light_gray_concrete
fill 271 201 261 271 202 261 minecraft:light_gray_concrete
fill 271 201 269 271 202 269 minecraft:light_gray_concrete
fill 272 201 233 272 201 237 minecraft:light_blue_stained_glass
fill 272 201 243 273 201 243 minecraft:light_blue_stained_glass
fill 272 201 255 272 202 255 minecraft:light_gray_concrete
fill 273 201 229 273 202 229 minecraft:cyan_terracotta
setblock 273 201 237 minecraft:light_blue_stained_glass
fill 273 201 240 273 201 242 minecraft:light_blue_stained_glass
fill 273 201 244 273 201 246 minecraft:light_blue_stained_glass
fill 273 201 261 273 202 261 minecraft:light_gray_concrete
fill 273 201 269 273 202 269 minecraft:light_gray_concrete
fill 274 201 255 274 202 255 minecraft:light_gray_concrete
fill 275 201 229 275 202 229 minecraft:cyan_terracotta
fill 275 201 237 275 202 237 minecraft:cyan_terracotta
fill 275 201 261 275 202 261 minecraft:light_gray_concrete
fill 275 201 269 275 202 269 minecraft:light_gray_concrete
setblock 275 201 270 minecraft:magenta_concrete
fill 276 201 230 276 202 230 minecraft:cyan_terracotta
fill 276 201 232 276 202 232 minecraft:cyan_terracotta
fill 276 201 234 276 202 234 minecraft:cyan_terracotta
fill 276 201 236 276 202 236 minecraft:cyan_terracotta
fill 276 201 243 276 202 243 minecraft:light_gray_concrete
fill 276 201 245 276 202 245 minecraft:light_gray_concrete
fill 276 201 247 276 202 247 minecraft:light_gray_concrete
fill 276 201 249 276 202 249 minecraft:light_gray_concrete
fill 276 201 251 276 202 251 minecraft:light_gray_concrete
fill 276 201 253 276 202 253 minecraft:light_gray_concrete
fill 276 201 262 276 202 262 minecraft:light_gray_concrete
fill 276 201 264 276 202 264 minecraft:light_gray_concrete
fill 276 201 266 276 202 266 minecraft:light_gray_concrete
fill 276 201 268 276 202 268 minecraft:light_gray_concrete
setblock 277 201 255 minecraft:ochre_froglight
setblock 277 201 269 minecraft:verdant_froglight
fill 235 202 240 235 264 240 minecraft:black_concrete
setblock 235 202 241 minecraft:ochre_froglight
fill 237 202 228 237 203 228 minecraft:black_concrete
fill 238 202 263 238 207 263 minecraft:cyan_terracotta
setblock 238 202 264 minecraft:black_stained_glass
fill 238 202 265 242 207 265 minecraft:cyan_terracotta
setblock 238 202 266 minecraft:ochre_froglight
fill 238 202 267 238 207 267 minecraft:cyan_terracotta
setblock 239 202 263 minecraft:light_blue_stained_glass
fill 239 202 264 241 207 264 minecraft:cyan_terracotta
fill 239 202 266 241 207 266 minecraft:cyan_terracotta
setblock 239 202 267 minecraft:magenta_stained_glass
fill 240 202 263 240 207 263 minecraft:cyan_terracotta
fill 240 202 267 240 207 267 minecraft:cyan_terracotta
setblock 241 202 263 minecraft:ochre_froglight
setblock 241 202 267 minecraft:sea_lantern
fill 242 202 263 242 207 263 minecraft:cyan_terracotta
setblock 242 202 264 minecraft:black_stained_glass
setblock 242 202 266 minecraft:black_stained_glass
fill 242 202 267 242 207 267 minecraft:cyan_terracotta
setblock 244 202 270 minecraft:verdant_froglight
fill 250 202 270 250 205 270 minecraft:black_concrete
fill 271 202 233 273 208 235 minecraft:cyan_terracotta
fill 272 202 232 272 208 232 minecraft:cyan_terracotta
fill 272 202 236 273 202 237 minecraft:cyan_terracotta
fill 272 202 242 274 202 245 minecraft:light_gray_concrete
fill 273 202 246 274 225 249 minecraft:light_gray_concrete
fill 275 202 270 275 308 270 minecraft:black_concrete
setblock 276 202 228 minecraft:magenta_concrete
fill 277 202 255 277 246 255 minecraft:black_concrete
setblock 277 202 264 minecraft:purple_concrete
fill 277 202 269 277 308 269 minecraft:black_concrete
fill 235 203 241 235 259 241 minecraft:black_concrete
setblock 235 203 265 minecraft:blue_concrete
setblock 236 203 230 minecraft:magenta_stained_glass
setblock 236 203 232 minecraft:black_stained_glass
setblock 236 203 234 minecraft:ochre_froglight
setblock 236 203 236 minecraft:black_stained_glass
setblock 237 203 229 minecraft:magenta_stained_glass
setblock 237 203 237 minecraft:pearlescent_froglight
fill 238 203 264 238 204 264 minecraft:cyan_terracotta
fill 238 203 266 238 204 266 minecraft:cyan_terracotta
setblock 239 203 229 minecraft:magenta_stained_glass
setblock 239 203 237 minecraft:magenta_stained_glass
fill 239 203 263 239 204 263 minecraft:cyan_terracotta
fill 239 203 267 239 204 267 minecraft:cyan_terracotta
setblock 241 203 229 minecraft:magenta_stained_glass
setblock 241 203 237 minecraft:light_blue_stained_glass
fill 241 203 263 241 204 263 minecraft:cyan_terracotta
fill 241 203 267 241 204 267 minecraft:cyan_terracotta
fill 242 203 264 242 204 264 minecraft:cyan_terracotta
fill 242 203 266 242 204 266 minecraft:cyan_terracotta
setblock 243 203 229 minecraft:black_stained_glass
setblock 243 203 237 minecraft:magenta_stained_glass
setblock 244 203 230 minecraft:sea_lantern
setblock 244 203 232 minecraft:cyan_stained_glass
setblock 244 203 234 minecraft:black_stained_glass
setblock 244 203 236 minecraft:pearlescent_froglight
fill 244 203 270 244 263 270 minecraft:black_concrete
setblock 268 203 230 minecraft:black_stained_glass
setblock 268 203 232 minecraft:pearlescent_froglight
setblock 268 203 234 minecraft:ochre_froglight
setblock 268 203 236 minecraft:black_stained_glass
setblock 268 203 262 minecraft:light_blue_stained_glass
setblock 268 203 264 minecraft:light_blue_stained_glass
setblock 268 203 266 minecraft:black_stained_glass
setblock 268 203 268 minecraft:cyan_stained_glass
setblock 269 203 229 minecraft:light_blue_stained_glass
setblock 269 203 237 minecraft:sea_lantern
setblock 269 203 261 minecraft:sea_lantern
setblock 269 203 269 minecraft:pearlescent_froglight
setblock 271 203 229 minecraft:black_stained_glass
setblock 271 203 237 minecraft:cyan_stained_glass
setblock 271 203 243 minecraft:black_stained_glass
setblock 271 203 245 minecraft:black_stained_glass
setblock 271 203 247 minecraft:black_stained_glass
setblock 271 203 249 minecraft:pearlescent_froglight
setblock 271 203 251 minecraft:sea_lantern
setblock 271 203 253 minecraft:black_stained_glass
setblock 271 203 261 minecraft:cyan_stained_glass
setblock 271 203 269 minecraft:cyan_stained_glass
fill 272 203 236 272 208 237 minecraft:cyan_terracotta
setblock 272 203 242 minecraft:cyan_stained_glass
fill 272 203 243 274 222 245 minecraft:light_gray_concrete
setblock 272 203 255 minecraft:cyan_stained_glass
setblock 273 203 229 minecraft:pearlescent_froglight
fill 273 203 236 273 208 236 minecraft:cyan_terracotta
setblock 273 203 237 minecraft:magenta_stained_glass
fill 273 203 242 273 225 242 minecraft:light_gray_concrete
setblock 273 203 261 minecraft:black_stained_glass
setblock 273 203 269 minecraft:black_stained_glass
setblock 274 203 242 minecraft:sea_lantern
setblock 274 203 255 minecraft:light_blue_stained_glass
setblock 275 203 229 minecraft:cyan_stained_glass
setblock 275 203 237 minecraft:light_blue_stained_glass
setblock 275 203 261 minecraft:black_stained_glass
setblock 275 203 269 minecraft:ochre_froglight
fill 276 203 228 276 268 228 minecraft:black_concrete
setblock 276 203 230 minecraft:black_stained_glass
setblock 276 203 232 minecraft:ochre_froglight
setblock 276 203 234 minecraft:ochre_froglight
setblock 276 203 236 minecraft:sea_lantern
setblock 276 203 243 minecraft:magenta_stained_glass
setblock 276 203 245 minecraft:sea_lantern
setblock 276 203 247 minecraft:black_stained_glass
setblock 276 203 249 minecraft:black_stained_glass
setblock 276 203 251 minecraft:black_stained_glass
setblock 276 203 253 minecraft:cyan_stained_glass
setblock 276 203 262 minecraft:light_blue_stained_glass
setblock 276 203 264 minecraft:pearlescent_froglight
setblock 276 203 266 minecraft:sea_lantern
setblock 276 203 268 minecraft:black_stained_glass
fill 277 203 264 277 214 264 minecraft:black_concrete
setblock 277 203 267 minecraft:pearlescent_froglight
fill 235 204 265 235 232 265 minecraft:black_concrete
fill 236 204 230 236 205 230 minecraft:light_gray_concrete
fill 236 204 232 236 205 232 minecraft:light_gray_concrete
fill 236 204 234 236 205 234 minecraft:light_gray_concrete
fill 236 204 236 236 205 236 minecraft:light_gray_concrete
setblock 237 204 228 minecraft:ochre_froglight
fill 237 204 229 237 205 229 minecraft:light_gray_concrete
fill 237 204 237 237 205 237 minecraft:light_gray_concrete
fill 239 204 229 239 205 229 minecraft:light_gray_concrete
fill 239 204 237 239 205 237 minecraft:light_gray_concrete
fill 241 204 229 241 205 229 minecraft:light_gray_concrete
fill 241 204 237 241 205 237 minecraft:light_gray_concrete
fill 243 204 229 243 205 229 minecraft:light_gray_concrete
fill 243 204 237 243 205 237 minecraft:light_gray_concrete
fill 244 204 230 244 205 230 minecraft:light_gray_concrete
fill 244 204 232 244 205 232 minecraft:light_gray_concrete
fill 244 204 234 244 205 234 minecraft:light_gray_concrete
fill 244 204 236 244 205 236 minecraft:light_gray_concrete
setblock 267 204 228 minecraft:blue_concrete
fill 268 204 230 268 205 230 minecraft:cyan_terracotta
fill 268 204 232 268 205 232 minecraft:cyan_terracotta
fill 268 204 234 268 205 234 minecraft:cyan_terracotta
fill 268 204 236 268 205 236 minecraft:cyan_terracotta
fill 268 204 262 268 205 262 minecraft:light_gray_concrete
fill 268 204 264 268 205 264 minecraft:light_gray_concrete
fill 268 204 266 268 205 266 minecraft:light_gray_concrete
fill 268 204 268 268 205 268 minecraft:light_gray_concrete
fill 269 204 229 269 205 229 minecraft:cyan_terracotta
fill 269 204 237 269 205 237 minecraft:cyan_terracotta
fill 269 204 261 269 205 261 minecraft:light_gray_concrete
fill 269 204 269 269 205 269 minecraft:light_gray_concrete
fill 271 204 229 271 205 229 minecraft:cyan_terracotta
fill 271 204 237 271 205 237 minecraft:cyan_terracotta
fill 271 204 243 271 205 243 minecraft:light_gray_concrete
fill 271 204 245 271 205 245 minecraft:light_gray_concrete
fill 271 204 247 271 205 247 minecraft:light_gray_concrete
fill 271 204 249 271 205 249 minecraft:light_gray_concrete
fill 271 204 251 271 205 251 minecraft:light_gray_concrete
fill 271 204 253 271 205 253 minecraft:light_gray_concrete
fill 271 204 261 271 205 261 minecraft:light_gray_concrete
fill 271 204 269 271 205 269 minecraft:light_gray_concrete
fill 272 204 242 272 205 242 minecraft:light_gray_concrete
fill 272 204 255 272 205 255 minecraft:light_gray_concrete
fill 273 204 229 273 205 229 minecraft:cyan_terracotta
fill 273 204 237 273 205 237 minecraft:cyan_terracotta
fill 273 204 261 273 205 261 minecraft:light_gray_concrete
fill 273 204 269 273 205 269 minecraft:light_gray_concrete
fill 274 204 242 274 205 242 minecraft:light_gray_concrete
fill 274 204 255 274 205 255 minecraft:light_gray_concrete
fill 275 204 229 275 205 229 minecraft:cyan_terracotta
fill 275 204 237 275 205 237 minecraft:cyan_terracotta
fill 275 204 261 275 205 261 minecraft:light_gray_concrete
fill 275 204 269 275 205 269 minecraft:light_gray_concrete
fill 276 204 230 276 205 230 minecraft:cyan_terracotta
fill 276 204 232 276 205 232 minecraft:cyan_terracotta
fill 276 204 234 276 205 234 minecraft:cyan_terracotta
fill 276 204 236 276 205 236 minecraft:cyan_terracotta
fill 276 204 243 276 205 243 minecraft:light_gray_concrete
fill 276 204 245 276 205 245 minecraft:light_gray_concrete
fill 276 204 247 276 205 247 minecraft:light_gray_concrete
fill 276 204 249 276 205 249 minecraft:light_gray_concrete
fill 276 204 251 276 205 251 minecraft:light_gray_concrete
fill 276 204 253 276 205 253 minecraft:light_gray_concrete
fill 276 204 262 276 205 262 minecraft:light_gray_concrete
fill 276 204 264 276 205 264 minecraft:light_gray_concrete
fill 276 204 266 276 205 266 minecraft:light_gray_concrete
fill 276 204 268 276 205 268 minecraft:light_gray_concrete
setblock 277 204 246 minecraft:sea_lantern
fill 277 204 267 277 308 267 minecraft:black_concrete
setblock 235 205 245 minecraft:purple_concrete
fill 237 205 228 237 250 228 minecraft:black_concrete
setblock 238 205 238 minecraft:light[level=12]
setblock 238 205 245 minecraft:light[level=12]
setblock 238 205 252 minecraft:light[level=12]
setblock 238 205 259 minecraft:light[level=12]
setblock 238 205 264 minecraft:magenta_stained_glass
setblock 238 205 266 minecraft:black_stained_glass
setblock 239 205 263 minecraft:magenta_stained_glass
setblock 239 205 267 minecraft:cyan_stained_glass
setblock 241 205 263 minecraft:black_stained_glass
setblock 241 205 267 minecraft:black_stained_glass
setblock 242 205 264 minecraft:cyan_stained_glass
setblock 242 205 266 minecraft:black_stained_glass
setblock 245 205 228 minecraft:verdant_froglight
setblock 245 205 231 minecraft:light[level=12]
setblock 245 205 238 minecraft:light[level=12]
setblock 245 205 245 minecraft:light[level=12]
setblock 245 205 252 minecraft:light[level=12]
setblock 245 205 259 minecraft:light[level=12]
setblock 245 205 266 minecraft:light[level=12]
setblock 252 205 231 minecraft:light[level=12]
setblock 252 205 238 minecraft:light[level=12]
setblock 252 205 245 minecraft:light[level=12]
setblock 252 205 252 minecraft:light[level=12]
setblock 252 205 259 minecraft:light[level=12]
setblock 252 205 266 minecraft:light[level=12]
setblock 259 205 231 minecraft:light[level=12]
setblock 259 205 238 minecraft:light[level=12]
setblock 259 205 245 minecraft:light[level=12]
setblock 259 205 252 minecraft:light[level=12]
setblock 259 205 259 minecraft:light[level=12]
setblock 259 205 266 minecraft:light[level=12]
setblock 266 205 231 minecraft:light[level=12]
setblock 266 205 238 minecraft:light[level=12]
setblock 266 205 245 minecraft:light[level=12]
setblock 266 205 252 minecraft:light[level=12]
setblock 266 205 259 minecraft:light[level=12]
setblock 266 205 266 minecraft:light[level=12]
fill 267 205 228 267 307 228 minecraft:black_concrete
setblock 273 205 238 minecraft:light[level=12]
setblock 273 205 259 minecraft:light[level=12]
fill 277 205 246 277 216 246 minecraft:black_concrete
setblock 277 205 259 minecraft:pearlescent_froglight
setblock 235 206 232 minecraft:cyan_concrete
setblock 235 206 233 minecraft:ochre_froglight
fill 235 206 245 235 230 245 minecraft:black_concrete
setblock 236 206 230 minecraft:sea_lantern
setblock 236 206 232 minecraft:sea_lantern
setblock 236 206 234 minecraft:sea_lantern
setblock 236 206 236 minecraft:ochre_froglight
setblock 237 206 229 minecraft:magenta_stained_glass
setblock 237 206 237 minecraft:black_stained_glass
setblock 238 206 239 minecraft:light[level=15]
setblock 238 206 247 minecraft:light[level=15]
setblock 238 206 255 minecraft:light[level=15]
fill 238 206 264 238 207 264 minecraft:cyan_terracotta
fill 238 206 266 238 207 266 minecraft:cyan_terracotta
setblock 239 206 229 minecraft:black_stained_glass
setblock 239 206 237 minecraft:black_stained_glass
fill 239 206 263 239 207 263 minecraft:cyan_terracotta
fill 239 206 267 239 207 267 minecraft:cyan_terracotta
setblock 241 206 229 minecraft:cyan_stained_glass
setblock 241 206 237 minecraft:black_stained_glass
fill 241 206 263 241 207 263 minecraft:cyan_terracotta
fill 241 206 267 241 207 267 minecraft:cyan_terracotta
fill 242 206 264 242 207 264 minecraft:cyan_terracotta
fill 242 206 266 242 207 266 minecraft:cyan_terracotta
setblock 243 206 229 minecraft:black_stained_glass
setblock 243 206 237 minecraft:black_stained_glass
setblock 244 206 230 minecraft:black_stained_glass
setblock 244 206 232 minecraft:sea_lantern
setblock 244 206 234 minecraft:black_stained_glass
setblock 244 206 236 minecraft:magenta_stained_glass
fill 245 206 228 245 208 228 minecraft:black_concrete
setblock 246 206 231 minecraft:light[level=15]
setblock 246 206 239 minecraft:light[level=15]
setblock 246 206 247 minecraft:light[level=15]
setblock 246 206 255 minecraft:light[level=15]
setblock 246 206 263 minecraft:light[level=15]
setblock 250 206 270 minecraft:purple_concrete
setblock 254 206 231 minecraft:light[level=15]
setblock 254 206 239 minecraft:light[level=15]
setblock 254 206 247 minecraft:light[level=15]
setblock 254 206 255 minecraft:light[level=15]
setblock 254 206 263 minecraft:light[level=15]
setblock 262 206 231 minecraft:light[level=15]
setblock 262 206 239 minecraft:light[level=15]
setblock 262 206 247 minecraft:light[level=15]
setblock 262 206 255 minecraft:light[level=15]
setblock 262 206 263 minecraft:light[level=15]
setblock 266 206 270 minecraft:sea_lantern
setblock 268 206 230 minecraft:magenta_stained_glass
setblock 268 206 232 minecraft:cyan_stained_glass
setblock 268 206 234 minecraft:black_stained_glass
setblock 268 206 236 minecraft:cyan_stained_glass
setblock 268 206 262 minecraft:black_stained_glass
setblock 268 206 264 minecraft:cyan_stained_glass
setblock 268 206 266 minecraft:black_stained_glass
setblock 268 206 268 minecraft:black_stained_glass
setblock 269 206 229 minecraft:light_blue_stained_glass
setblock 269 206 237 minecraft:light_blue_stained_glass
setblock 269 206 261 minecraft:cyan_stained_glass
setblock 269 206 269 minecraft:black_stained_glass
setblock 270 206 239 minecraft:light[level=15]
setblock 270 206 247 minecraft:light[level=15]
setblock 270 206 255 minecraft:light[level=15]
setblock 271 206 229 minecraft:black_stained_glass
setblock 271 206 237 minecraft:black_stained_glass
setblock 271 206 243 minecraft:black_stained_glass
setblock 271 206 245 minecraft:magenta_stained_glass
setblock 271 206 247 minecraft:light_blue_stained_glass
setblock 271 206 249 minecraft:light_blue_stained_glass
setblock 271 206 251 minecraft:black_stained_glass
setblock 271 206 253 minecraft:black_stained_glass
setblock 271 206 261 minecraft:pearlescent_froglight
setblock 271 206 269 minecraft:cyan_stained_glass
setblock 272 206 242 minecraft:ochre_froglight
setblock 272 206 255 minecraft:magenta_stained_glass
setblock 273 206 229 minecraft:black_stained_glass
setblock 273 206 237 minecraft:black_stained_glass
setblock 273 206 261 minecraft:black_stained_glass
setblock 273 206 269 minecraft:black_stained_glass
setblock 274 206 242 minecraft:light_blue_stained_glass
setblock 274 206 255 minecraft:black_stained_glass
setblock 275 206 228 minecraft:verdant_froglight
setblock 275 206 229 minecraft:black_stained_glass
setblock 275 206 237 minecraft:black_stained_glass
setblock 275 206 261 minecraft:black_stained_glass
setblock 275 206 269 minecraft:cyan_stained_glass
setblock 276 206 230 minecraft:sea_lantern
setblock 276 206 232 minecraft:black_stained_glass
setblock 276 206 234 minecraft:magenta_stained_glass
setblock 276 206 236 minecraft:black_stained_glass
setblock 276 206 243 minecraft:black_stained_glass
setblock 276 206 245 minecraft:black_stained_glass
setblock 276 206 247 minecraft:black_stained_glass
setblock 276 206 249 minecraft:black_stained_glass
setblock 276 206 251 minecraft:pearlescent_froglight
setblock 276 206 253 minecraft:black_stained_glass
setblock 276 206 262 minecraft:magenta_stained_glass
setblock 276 206 264 minecraft:sea_lantern
setblock 276 206 266 minecraft:magenta_stained_glass
setblock 276 206 268 minecraft:black_stained_glass
setblock 277 206 259 minecraft:ochre_froglight
setblock 235 207 230 minecraft:sea_lantern
fill 235 207 232 235 223 233 minecraft:black_concrete
fill 236 207 230 236 208 230 minecraft:light_gray_concrete
fill 236 207 232 236 208 232 minecraft:light_gray_concrete
fill 236 207 234 236 208 234 minecraft:light_gray_concrete
fill 236 207 236 236 208 236 minecraft:light_gray_concrete
fill 237 207 229 237 208 229 minecraft:light_gray_concrete
fill 237 207 237 237 208 237 minecraft:light_gray_concrete
fill 239 207 229 239 208 229 minecraft:light_gray_concrete
fill 239 207 237 239 208 237 minecraft:light_gray_concrete
fill 241 207 229 241 208 229 minecraft:light_gray_concrete
fill 241 207 237 241 208 237 minecraft:light_gray_concrete
fill 243 207 229 243 208 229 minecraft:light_gray_concrete
fill 243 207 237 243 208 237 minecraft:light_gray_concrete
fill 244 207 230 244 208 230 minecraft:light_gray_concrete
fill 244 207 232 244 208 232 minecraft:light_gray_concrete
fill 244 207 234 244 208 234 minecraft:light_gray_concrete
fill 244 207 236 244 208 236 minecraft:light_gray_concrete
fill 250 207 270 250 244 270 minecraft:black_concrete
fill 266 207 270 266 220 270 minecraft:black_concrete
fill 268 207 230 268 208 230 minecraft:cyan_terracotta
fill 268 207 232 268 208 232 minecraft:cyan_terracotta
fill 268 207 234 268 208 234 minecraft:cyan_terracotta
fill 268 207 236 268 208 236 minecraft:cyan_terracotta
fill 268 207 262 268 208 262 minecraft:light_gray_concrete
fill 268 207 264 268 208 264 minecraft:light_gray_concrete
fill 268 207 266 268 208 266 minecraft:light_gray_concrete
fill 268 207 268 268 208 268 minecraft:light_gray_concrete
setblock 269 207 228 minecraft:cyan_concrete
fill 269 207 229 269 208 229 minecraft:cyan_terracotta
fill 269 207 237 269 208 237 minecraft:cyan_terracotta
fill 269 207 261 269 208 261 minecraft:light_gray_concrete
fill 269 207 269 269 208 269 minecraft:light_gray_concrete
fill 271 207 229 271 208 229 minecraft:cyan_terracotta
fill 271 207 237 271 208 237 minecraft:cyan_terracotta
fill 271 207 243 271 208 243 minecraft:light_gray_concrete
fill 271 207 245 271 208 245 minecraft:light_gray_concrete
fill 271 207 247 271 208 247 minecraft:light_gray_concrete
fill 271 207 249 271 208 249 minecraft:light_gray_concrete
fill 271 207 251 271 208 251 minecraft:light_gray_concrete
fill 271 207 253 271 208 253 minecraft:light_gray_concrete
fill 271 207 261 271 208 261 minecraft:light_gray_concrete
fill 271 207 269 271 208 269 minecraft:light_gray_concrete
fill 272 207 242 272 208 242 minecraft:light_gray_concrete
fill 272 207 255 272 208 255 minecraft:light_gray_concrete
fill 273 207 229 273 208 229 minecraft:cyan_terracotta
fill 273 207 237 273 208 237 minecraft:cyan_terracotta
fill 273 207 260 275 208 260 minecraft:iron_block
fill 273 207 261 273 208 261 minecraft:light_gray_concrete
fill 273 207 269 273 208 269 minecraft:light_gray_concrete
fill 274 207 242 274 208 242 minecraft:light_gray_concrete
fill 274 207 255 274 208 255 minecraft:light_gray_concrete
fill 275 207 228 275 262 228 minecraft:black_concrete
fill 275 207 229 275 208 229 minecraft:cyan_terracotta
fill 275 207 237 275 208 237 minecraft:cyan_terracotta
fill 275 207 261 275 208 261 minecraft:light_gray_concrete
fill 275 207 269 275 208 269 minecraft:light_gray_concrete
fill 276 207 230 276 208 230 minecraft:cyan_terracotta
fill 276 207 232 276 208 232 minecraft:cyan_terracotta
fill 276 207 234 276 208 234 minecraft:cyan_terracotta
fill 276 207 236 276 208 236 minecraft:cyan_terracotta
fill 276 207 243 276 208 243 minecraft:light_gray_concrete
fill 276 207 245 276 208 245 minecraft:light_gray_concrete
fill 276 207 247 276 208 247 minecraft:light_gray_concrete
fill 276 207 249 276 208 249 minecraft:light_gray_concrete
fill 276 207 251 276 208 251 minecraft:light_gray_concrete
fill 276 207 253 276 208 253 minecraft:light_gray_concrete
fill 276 207 262 276 208 262 minecraft:light_gray_concrete
fill 276 207 264 276 208 264 minecraft:light_gray_concrete
fill 276 207 266 276 208 266 minecraft:light_gray_concrete
fill 276 207 268 276 208 268 minecraft:light_gray_concrete
fill 277 207 259 277 308 259 minecraft:black_concrete
fill 235 208 230 235 209 230 minecraft:black_concrete
fill 269 208 228 269 308 228 minecraft:black_concrete
setblock 277 208 248 minecraft:purple_concrete
setblock 235 209 261 minecraft:magenta_concrete
setblock 235 209 269 minecraft:sea_lantern
setblock 236 209 230 minecraft:cyan_stained_glass
setblock 236 209 232 minecraft:black_stained_glass
setblock 236 209 234 minecraft:sea_lantern
setblock 236 209 236 minecraft:cyan_stained_glass
setblock 237 209 229 minecraft:sea_lantern
setblock 237 209 237 minecraft:magenta_stained_glass
setblock 239 209 229 minecraft:black_stained_glass
setblock 239 209 237 minecraft:sea_lantern
setblock 241 209 229 minecraft:ochre_froglight
setblock 241 209 237 minecraft:black_stained_glass
setblock 243 209 229 minecraft:black_stained_glass
setblock 243 209 237 minecraft:black_stained_glass
setblock 244 209 230 minecraft:black_stained_glass
setblock 244 209 232 minecraft:black_stained_glass
setblock 244 209 234 minecraft:black_stained_glass
setblock 244 209 236 minecraft:magenta_stained_glass
setblock 245 209 228 minecraft:verdant_froglight
setblock 257 209 270 minecraft:purple_concrete
fill 268 209 229 276 209 237 minecraft:black_concrete
setblock 268 209 262 minecraft:light_blue_stained_glass
setblock 268 209 264 minecraft:magenta_stained_glass
setblock 268 209 266 minecraft:cyan_stained_glass
setblock 268 209 268 minecraft:black_stained_glass
setblock 269 209 261 minecraft:sea_lantern
setblock 269 209 269 minecraft:black_stained_glass
setblock 271 209 243 minecraft:magenta_stained_glass
setblock 271 209 245 minecraft:ochre_froglight
setblock 271 209 247 minecraft:magenta_stained_glass
setblock 271 209 249 minecraft:black_stained_glass
setblock 271 209 251 minecraft:black_stained_glass
setblock 271 209 253 minecraft:pearlescent_froglight
setblock 271 209 261 minecraft:black_stained_glass
setblock 271 209 269 minecraft:black_stained_glass
setblock 272 209 228 minecraft:sea_lantern
setblock 272 209 242 minecraft:sea_lantern
setblock 272 209 255 minecraft:ochre_froglight
setblock 273 209 261 minecraft:black_stained_glass
setblock 273 209 269 minecraft:black_stained_glass
setblock 274 209 242 minecraft:black_stained_glass
setblock 274 209 255 minecraft:pearlescent_froglight
setblock 275 209 261 minecraft:black_stained_glass
setblock 275 209 269 minecraft:black_stained_glass
setblock 276 209 243 minecraft:pearlescent_froglight
setblock 276 209 245 minecraft:cyan_stained_glass
setblock 276 209 247 minecraft:ochre_froglight
setblock 276 209 249 minecraft:black_stained_glass
setblock 276 209 251 minecraft:pearlescent_froglight
setblock 276 209 253 minecraft:black_stained_glass
setblock 276 209 262 minecraft:black_stained_glass
setblock 276 209 264 minecraft:light_blue_stained_glass
setblock 276 209 266 minecraft:light_blue_stained_glass
setblock 276 209 268 minecraft:pearlescent_froglight
fill 277 209 248 277 224 248 minecraft:black_concrete
setblock 235 210 230 minecraft:sea_lantern
fill 235 210 261 235 254 261 minecraft:black_concrete
setblock 235 210 266 minecraft:purple_concrete
fill 235 210 269 235 229 269 minecraft:black_concrete
fill 236 210 230 236 211 230 minecraft:light_gray_concrete
fill 236 210 232 236 211 232 minecraft:light_gray_concrete
fill 236 210 234 236 211 234 minecraft:light_gray_concrete
fill 236 210 236 236 211 236 minecraft:light_gray_concrete
fill 237 210 229 237 211 229 minecraft:light_gray_concrete
fill 237 210 237 237 211 237 minecraft:light_gray_concrete
fill 239 210 229 239 211 229 minecraft:light_gray_concrete
fill 239 210 237 239 211 237 minecraft:light_gray_concrete
fill 241 210 229 241 211 229 minecraft:light_gray_concrete
fill 241 210 237 241 211 237 minecraft:light_gray_concrete
fill 243 210 229 243 211 229 minecraft:light_gray_concrete
fill 243 210 237 243 211 237 minecraft:light_gray_concrete
fill 244 210 230 244 211 230 minecraft:light_gray_concrete
fill 244 210 232 244 211 232 minecraft:light_gray_concrete
fill 244 210 234 244 211 234 minecraft:light_gray_concrete
fill 244 210 236 244 211 236 minecraft:light_gray_concrete
fill 245 210 228 245 241 228 minecraft:black_concrete
setblock 254 210 270 minecraft:ochre_froglight
fill 257 210 270 257 214 270 minecraft:black_concrete
fill 268 210 229 268 210 237 minecraft:sea_lantern
fill 268 210 262 268 211 262 minecraft:light_gray_concrete
fill 268 210 264 268 211 264 minecraft:light_gray_concrete
fill 268 210 266 268 211 266 minecraft:light_gray_concrete
fill 268 210 268 268 211 268 minecraft:light_gray_concrete
fill 269 210 229 276 210 229 minecraft:sea_lantern
fill 269 210 237 276 210 237 minecraft:sea_lantern
fill 269 210 261 269 211 261 minecraft:light_gray_concrete
fill 269 210 269 269 211 269 minecraft:light_gray_concrete
fill 270 210 231 274 211 235 minecraft:cyan_terracotta
fill 271 210 243 271 211 243 minecraft:light_gray_concrete
fill 271 210 245 271 211 245 minecraft:light_gray_concrete
fill 271 210 247 271 211 247 minecraft:light_gray_concrete
fill 271 210 249 271 211 249 minecraft:light_gray_concrete
fill 271 210 251 271 211 251 minecraft:light_gray_concrete
fill 271 210 253 271 211 253 minecraft:light_gray_concrete
fill 271 210 261 271 211 261 minecraft:light_gray_concrete
fill 271 210 269 271 211 269 minecraft:light_gray_concrete
fill 272 210 228 272 223 228 minecraft:black_concrete
fill 272 210 242 272 211 242 minecraft:light_gray_concrete
fill 272 210 255 272 211 255 minecraft:light_gray_concrete
fill 273 210 261 273 211 261 minecraft:light_gray_concrete
fill 273 210 269 273 211 269 minecraft:light_gray_concrete
fill 274 210 242 274 211 242 minecraft:light_gray_concrete
fill 274 210 255 274 211 255 minecraft:light_gray_concrete
setblock 274 210 270 minecraft:verdant_froglight
fill 275 210 261 275 211 261 minecraft:light_gray_concrete
fill 275 210 269 275 211 269 minecraft:light_gray_concrete
fill 276 210 230 276 210 236 minecraft:sea_lantern
fill 276 210 243 276 211 243 minecraft:light_gray_concrete
fill 276 210 245 276 211 245 minecraft:light_gray_concrete
fill 276 210 247 276 211 247 minecraft:light_gray_concrete
fill 276 210 249 276 211 249 minecraft:light_gray_concrete
fill 276 210 251 276 211 251 minecraft:light_gray_concrete
fill 276 210 253 276 211 253 minecraft:light_gray_concrete
fill 276 210 262 276 211 262 minecraft:light_gray_concrete
fill 276 210 264 276 211 264 minecraft:light_gray_concrete
fill 276 210 266 276 211 266 minecraft:light_gray_concrete
fill 276 210 268 276 211 268 minecraft:light_gray_concrete
fill 235 211 230 235 217 230 minecraft:black_concrete
fill 235 211 266 235 282 266 minecraft:black_concrete
setblock 238 211 238 minecraft:light[level=12]
setblock 238 211 245 minecraft:light[level=12]
setblock 238 211 252 minecraft:light[level=12]
setblock 238 211 259 minecraft:light[level=12]
setblock 238 211 266 minecraft:light[level=12]
setblock 240 211 265 minecraft:redstone_block
setblock 245 211 231 minecraft:light[level=12]
setblock 245 211 238 minecraft:light[level=12]
setblock 245 211 245 minecraft:light[level=12]
setblock 245 211 252 minecraft:light[level=12]
setblock 245 211 259 minecraft:light[level=12]
setblock 245 211 266 minecraft:light[level=12]
setblock 252 211 231 minecraft:light[level=12]
setblock 252 211 238 minecraft:light[level=12]
setblock 252 211 245 minecraft:light[level=12]
setblock 252 211 252 minecraft:light[level=12]
setblock 252 211 259 minecraft:light[level=12]
setblock 252 211 266 minecraft:light[level=12]
fill 254 211 270 254 308 270 minecraft:black_concrete
setblock 259 211 231 minecraft:light[level=12]
setblock 259 211 238 minecraft:light[level=12]
setblock 259 211 245 minecraft:light[level=12]
setblock 259 211 252 minecraft:light[level=12]
setblock 259 211 259 minecraft:light[level=12]
setblock 259 211 266 minecraft:light[level=12]
setblock 266 211 231 minecraft:light[level=12]
setblock 266 211 238 minecraft:light[level=12]
setblock 266 211 245 minecraft:light[level=12]
setblock 266 211 252 minecraft:light[level=12]
setblock 266 211 259 minecraft:light[level=12]
setblock 266 211 266 minecraft:light[level=12]
setblock 273 211 238 minecraft:light[level=12]
setblock 273 211 259 minecraft:light[level=12]
fill 274 211 270 274 263 270 minecraft:black_concrete
setblock 277 211 241 minecraft:magenta_concrete
fill 235 212 228 235 308 228 minecraft:black_concrete
setblock 235 212 229 minecraft:magenta_concrete
setblock 236 212 230 minecraft:ochre_froglight
setblock 236 212 232 minecraft:pearlescent_froglight
setblock 236 212 234 minecraft:black_stained_glass
setblock 236 212 236 minecraft:black_stained_glass
setblock 237 212 229 minecraft:black_stained_glass
setblock 237 212 237 minecraft:black_stained_glass
setblock 239 212 229 minecraft:sea_lantern
setblock 239 212 237 minecraft:cyan_stained_glass
setblock 239 212 270 minecraft:blue_concrete
setblock 241 212 229 minecraft:ochre_froglight
setblock 241 212 237 minecraft:black_stained_glass
setblock 243 212 229 minecraft:black_stained_glass
setblock 243 212 237 minecraft:black_stained_glass
setblock 244 212 230 minecraft:ochre_froglight
setblock 244 212 232 minecraft:black_stained_glass
setblock 244 212 234 minecraft:pearlescent_froglight
setblock 244 212 236 minecraft:magenta_stained_glass
setblock 268 212 262 minecraft:ochre_froglight
setblock 268 212 264 minecraft:sea_lantern
setblock 268 212 266 minecraft:black_stained_glass
setblock 268 212 268 minecraft:black_stained_glass
fill 268 212 270 268 213 270 minecraft:verdant_froglight
setblock 269 212 261 minecraft:magenta_stained_glass
setblock 269 212 269 minecraft:pearlescent_froglight
fill 270 212 231 270 220 231 minecraft:cyan_terracotta
setblock 270 212 232 minecraft:black_stained_glass
fill 270 212 233 274 220 233 minecraft:cyan_terracotta
setblock 270 212 234 minecraft:black_stained_glass
fill 270 212 235 270 220 235 minecraft:cyan_terracotta
setblock 271 212 231 minecraft:light_blue_stained_glass
fill 271 212 232 273 220 232 minecraft:cyan_terracotta
fill 271 212 234 273 220 234 minecraft:cyan_terracotta
setblock 271 212 235 minecraft:black_stained_glass
setblock 271 212 243 minecraft:ochre_froglight
setblock 271 212 245 minecraft:black_stained_glass
setblock 271 212 247 minecraft:black_stained_glass
setblock 271 212 249 minecraft:pearlescent_froglight
setblock 271 212 251 minecraft:pearlescent_froglight
setblock 271 212 253 minecraft:black_stained_glass
setblock 271 212 261 minecraft:black_stained_glass
setblock 271 212 269 minecraft:black_stained_glass
fill 272 212 231 272 220 231 minecraft:cyan_terracotta
fill 272 212 235 272 220 235 minecraft:cyan_terracotta
setblock 272 212 242 minecraft:pearlescent_froglight
setblock 272 212 255 minecraft:black_stained_glass
setblock 273 212 231 minecraft:black_stained_glass
setblock 273 212 235 minecraft:magenta_stained_glass
setblock 273 212 261 minecraft:black_stained_glass
setblock 273 212 269 minecraft:black_stained_glass
fill 274 212 231 274 220 231 minecraft:cyan_terracotta
setblock 274 212 232 minecraft:light_blue_stained_glass
setblock 274 212 234 minecraft:pearlescent_froglight
fill 274 212 235 274 220 235 minecraft:cyan_terracotta
setblock 274 212 242 minecraft:black_stained_glass
setblock 274 212 255 minecraft:black_stained_glass
setblock 275 212 261 minecraft:sea_lantern
setblock 275 212 269 minecraft:sea_lantern
setblock 276 212 243 minecraft:black_stained_glass
setblock 276 212 245 minecraft:pearlescent_froglight
setblock 276 212 247 minecraft:black_stained_glass
setblock 276 212 249 minecraft:black_stained_glass
setblock 276 212 251 minecraft:pearlescent_froglight
setblock 276 212 253 minecraft:black_stained_glass
setblock 276 212 262 minecraft:magenta_stained_glass
setblock 276 212 264 minecraft:black_stained_glass
setblock 276 212 266 minecraft:ochre_froglight
setblock 276 212 268 minecraft:ochre_froglight
fill 277 212 241 277 219 241 minecraft:black_concrete
fill 235 213 229 235 224 229 minecraft:black_concrete
setblock 235 213 267 minecraft:pearlescent_froglight
fill 236 213 230 236 214 230 minecraft:light_gray_concrete
fill 236 213 232 236 214 232 minecraft:light_gray_concrete
fill 236 213 234 236 214 234 minecraft:light_gray_concrete
fill 236 213 236 236 214 236 minecraft:light_gray_concrete
fill 237 213 229 237 214 229 minecraft:light_gray_concrete
fill 237 213 237 237 214 237 minecraft:light_gray_concrete
setblock 238 213 239 minecraft:light[level=15]
setblock 238 213 247 minecraft:light[level=15]
setblock 238 213 255 minecraft:light[level=15]
setblock 238 213 263 minecraft:light[level=15]
fill 239 213 229 239 214 229 minecraft:light_gray_concrete
fill 239 213 237 239 214 237 minecraft:light_gray_concrete
fill 239 213 270 239 268 270 minecraft:black_concrete
fill 241 213 229 241 214 229 minecraft:light_gray_concrete
fill 241 213 237 241 214 237 minecraft:light_gray_concrete
fill 243 213 229 243 214 229 minecraft:light_gray_concrete
fill 243 213 237 243 214 237 minecraft:light_gray_concrete
fill 244 213 230 244 214 230 minecraft:light_gray_concrete
fill 244 213 232 244 214 232 minecraft:light_gray_concrete
fill 244 213 234 244 214 234 minecraft:light_gray_concrete
fill 244 213 236 244 214 236 minecraft:light_gray_concrete
setblock 246 213 231 minecraft:light[level=15]
setblock 246 213 239 minecraft:light[level=15]
setblock 246 213 247 minecraft:light[level=15]
setblock 246 213 255 minecraft:light[level=15]
setblock 246 213 263 minecraft:light[level=15]
setblock 254 213 231 minecraft:light[level=15]
setblock 254 213 239 minecraft:light[level=15]
setblock 254 213 247 minecraft:light[level=15]
setblock 254 213 255 minecraft:light[level=15]
setblock 254 213 263 minecraft:light[level=15]
setblock 262 213 231 minecraft:light[level=15]
setblock 262 213 239 minecraft:light[level=15]
setblock 262 213 247 minecraft:light[level=15]
setblock 262 213 255 minecraft:light[level=15]
setblock 262 213 263 minecraft:light[level=15]
fill 268 213 262 268 214 262 minecraft:light_gray_concrete
fill 268 213 264 268 214 264 minecraft:light_gray_concrete
fill 268 213 266 268 214 266 minecraft:light_gray_concrete
fill 268 213 268 268 214 268 minecraft:light_gray_concrete
fill 269 213 261 269 214 261 minecraft:light_gray_concrete
fill 269 213 269 269 214 269 minecraft:light_gray_concrete
fill 270 213 232 270 214 232 minecraft:cyan_terracotta
fill 270 213 234 270 214 234 minecraft:cyan_terracotta
setblock 270 213 239 minecraft:light[level=15]
setblock 270 213 247 minecraft:light[level=15]
setblock 270 213 255 minecraft:light[level=15]
fill 271 213 231 271 214 231 minecraft:cyan_terracotta
fill 271 213 235 271 214 235 minecraft:cyan_terracotta
fill 271 213 243 271 214 243 minecraft:light_gray_concrete
fill 271 213 245 271 214 245 minecraft:light_gray_concrete
fill 271 213 247 271 214 247 minecraft:light_gray_concrete
fill 271 213 249 271 214 249 minecraft:light_gray_concrete
fill 271 213 251 271 214 251 minecraft:light_gray_concrete
fill 271 213 253 271 214 253 minecraft:light_gray_concrete
fill 271 213 261 271 214 261 minecraft:light_gray_concrete
fill 271 213 269 271 214 269 minecraft:light_gray_concrete
fill 272 213 242 272 214 242 minecraft:light_gray_concrete
fill 272 213 255 272 214 255 minecraft:light_gray_concrete
fill 273 213 231 273 214 231 minecraft:cyan_terracotta
fill 273 213 235 273 214 235 minecraft:cyan_terracotta
fill 273 213 261 273 214 261 minecraft:light_gray_concrete
fill 273 213 269 273 214 269 minecraft:light_gray_concrete
fill 274 213 232 274 214 232 minecraft:cyan_terracotta
fill 274 213 234 274 214 234 minecraft:cyan_terracotta
fill 274 213 242 274 214 242 minecraft:light_gray_concrete
fill 274 213 255 274 214 255 minecraft:light_gray_concrete
fill 275 213 261 275 214 261 minecraft:light_gray_concrete
fill 275 213 269 275 214 269 minecraft:light_gray_concrete
fill 276 213 243 276 214 243 minecraft:light_gray_concrete
fill 276 213 245 276 214 245 minecraft:light_gray_concrete
fill 276 213 247 276 214 247 minecraft:light_gray_concrete
fill 276 213 249 276 214 249 minecraft:light_gray_concrete
fill 276 213 251 276 214 251 minecraft:light_gray_concrete
fill 276 213 253 276 214 253 minecraft:light_gray_concrete
fill 276 213 262 276 214 262 minecraft:light_gray_concrete
fill 276 213 264 276 214 264 minecraft:light_gray_concrete
fill 276 213 266 276 214 266 minecraft:light_gray_concrete
fill 276 213 268 276 214 268 minecraft:light_gray_concrete
setblock 277 213 233 minecraft:cyan_concrete
setblock 277 213 257 minecraft:ochre_froglight
fill 235 214 267 235 308 267 minecraft:black_concrete
fill 268 214 270 268 308 270 minecraft:black_concrete
fill 277 214 233 277 308 233 minecraft:black_concrete
fill 277 214 257 277 269 257 minecraft:black_concrete
setblock 236 215 230 minecraft:black_stained_glass
setblock 236 215 232 minecraft:magenta_stained_glass
setblock 236 215 234 minecraft:magenta_stained_glass
setblock 236 215 236 minecraft:cyan_stained_glass
setblock 237 215 229 minecraft:black_stained_glass
setblock 237 215 237 minecraft:pearlescent_froglight
setblock 239 215 229 minecraft:cyan_stained_glass
setblock 239 215 237 minecraft:pearlescent_froglight
setblock 241 215 229 minecraft:black_stained_glass
setblock 241 215 237 minecraft:cyan_stained_glass
setblock 243 215 229 minecraft:cyan_stained_glass
setblock 243 215 237 minecraft:pearlescent_froglight
setblock 244 215 230 minecraft:black_stained_glass
setblock 244 215 232 minecraft:black_stained_glass
setblock 244 215 234 minecraft:pearlescent_froglight
setblock 244 215 236 minecraft:ochre_froglight
setblock 257 215 270 minecraft:pearlescent_froglight
setblock 268 215 262 minecraft:black_stained_glass
setblock 268 215 264 minecraft:black_stained_glass
setblock 268 215 266 minecraft:black_stained_glass
setblock 268 215 268 minecraft:black_stained_glass
setblock 269 215 261 minecraft:pearlescent_froglight
setblock 269 215 269 minecraft:cyan_stained_glass
setblock 270 215 232 minecraft:black_stained_glass
setblock 270 215 234 minecraft:pearlescent_froglight
setblock 271 215 231 minecraft:black_stained_glass
setblock 271 215 235 minecraft:light_blue_stained_glass
setblock 271 215 243 minecraft:black_stained_glass
setblock 271 215 245 minecraft:ochre_froglight
setblock 271 215 247 minecraft:black_stained_glass
setblock 271 215 249 minecraft:sea_lantern
setblock 271 215 251 minecraft:pearlescent_froglight
setblock 271 215 253 minecraft:ochre_froglight
setblock 271 215 261 minecraft:ochre_froglight
setblock 271 215 269 minecraft:cyan_stained_glass
setblock 272 215 242 minecraft:cyan_stained_glass
setblock 272 215 255 minecraft:black_stained_glass
setblock 273 215 231 minecraft:sea_lantern
setblock 273 215 235 minecraft:ochre_froglight
setblock 273 215 261 minecraft:sea_lantern
setblock 273 215 269 minecraft:sea_lantern
setblock 274 215 232 minecraft:black_stained_glass
setblock 274 215 234 minecraft:sea_lantern
setblock 274 215 242 minecraft:black_stained_glass
setblock 274 215 255 minecraft:cyan_stained_glass
setblock 275 215 261 minecraft:pearlescent_froglight
setblock 275 215 269 minecraft:light_blue_stained_glass
setblock 276 215 243 minecraft:black_stained_glass
setblock 276 215 245 minecraft:magenta_stained_glass
setblock 276 215 247 minecraft:black_stained_glass
setblock 276 215 249 minecraft:ochre_froglight
setblock 276 215 251 minecraft:black_stained_glass
setblock 276 215 253 minecraft:black_stained_glass
setblock 276 215 262 minecraft:black_stained_glass
setblock 276 215 264 minecraft:black_stained_glass
setblock 276 215 266 minecraft:black_stained_glass
setblock 276 215 268 minecraft:black_stained_glass
setblock 277 215 264 minecraft:sea_lantern
fill 236 216 230 236 217 230 minecraft:light_gray_concrete
fill 236 216 232 236 217 232 minecraft:light_gray_concrete
fill 236 216 234 236 217 234 minecraft:light_gray_concrete
fill 236 216 236 236 217 236 minecraft:light_gray_concrete
fill 237 216 229 237 217 229 minecraft:light_gray_concrete
fill 237 216 237 237 217 237 minecraft:light_gray_concrete
fill 239 216 229 239 217 229 minecraft:light_gray_concrete
fill 239 216 237 239 217 237 minecraft:light_gray_concrete
fill 241 216 229 241 217 229 minecraft:light_gray_concrete
fill 241 216 237 241 217 237 minecraft:light_gray_concrete
fill 243 216 229 243 217 229 minecraft:light_gray_concrete
fill 243 216 237 243 217 237 minecraft:light_gray_concrete
fill 244 216 230 244 217 230 minecraft:light_gray_concrete
fill 244 216 232 244 217 232 minecraft:light_gray_concrete
fill 244 216 234 244 217 234 minecraft:light_gray_concrete
fill 244 216 236 244 217 236 minecraft:light_gray_concrete
setblock 251 216 228 minecraft:blue_concrete
fill 257 216 270 257 308 270 minecraft:black_concrete
setblock 258 216 228 minecraft:magenta_concrete
fill 268 216 262 268 217 262 minecraft:light_gray_concrete
fill 268 216 264 268 217 264 minecraft:light_gray_concrete
fill 268 216 266 268 217 266 minecraft:light_gray_concrete
fill 268 216 268 268 217 268 minecraft:light_gray_concrete
fill 269 216 261 269 217 261 minecraft:light_gray_concrete
fill 269 216 269 269 217 269 minecraft:light_gray_concrete
fill 270 216 232 270 217 232 minecraft:cyan_terracotta
fill 270 216 234 270 217 234 minecraft:cyan_terracotta
fill 271 216 231 271 217 231 minecraft:cyan_terracotta
fill 271 216 235 271 217 235 minecraft:cyan_terracotta
fill 271 216 243 271 217 243 minecraft:light_gray_concrete
fill 271 216 245 271 217 245 minecraft:light_gray_concrete
fill 271 216 247 271 217 247 minecraft:light_gray_concrete
fill 271 216 249 271 217 249 minecraft:light_gray_concrete
fill 271 216 251 271 217 251 minecraft:light_gray_concrete
fill 271 216 253 271 217 253 minecraft:light_gray_concrete
fill 271 216 261 271 217 261 minecraft:light_gray_concrete
fill 271 216 269 271 217 269 minecraft:light_gray_concrete
fill 272 216 242 272 217 242 minecraft:light_gray_concrete
fill 272 216 255 272 217 255 minecraft:light_gray_concrete
fill 273 216 231 273 217 231 minecraft:cyan_terracotta
fill 273 216 235 273 217 235 minecraft:cyan_terracotta
fill 273 216 261 273 217 261 minecraft:light_gray_concrete
fill 273 216 269 273 217 269 minecraft:light_gray_concrete
fill 274 216 232 274 217 232 minecraft:cyan_terracotta
fill 274 216 234 274 217 234 minecraft:cyan_terracotta
fill 274 216 242 274 217 242 minecraft:light_gray_concrete
fill 274 216 255 274 217 255 minecraft:light_gray_concrete
fill 275 216 261 275 217 261 minecraft:light_gray_concrete
fill 275 216 269 275 217 269 minecraft:light_gray_concrete
fill 276 216 243 276 217 243 minecraft:light_gray_concrete
fill 276 216 245 276 217 245 minecraft:light_gray_concrete
fill 276 216 247 276 217 247 minecraft:light_gray_concrete
fill 276 216 249 276 217 249 minecraft:light_gray_concrete
fill 276 216 251 276 217 251 minecraft:light_gray_concrete
fill 276 216 253 276 217 253 minecraft:light_gray_concrete
fill 276 216 262 276 217 262 minecraft:light_gray_concrete
fill 276 216 264 276 217 264 minecraft:light_gray_concrete
fill 276 216 266 276 217 266 minecraft:light_gray_concrete
fill 276 216 268 276 217 268 minecraft:light_gray_concrete
fill 277 216 264 277 277 264 minecraft:black_concrete
setblock 238 217 238 minecraft:light[level=12]
setblock 238 217 245 minecraft:light[level=12]
setblock 238 217 252 minecraft:light[level=12]
setblock 238 217 259 minecraft:light[level=12]
setblock 238 217 266 minecraft:light[level=12]
setblock 245 217 231 minecraft:light[level=12]
setblock 245 217 238 minecraft:light[level=12]
setblock 245 217 245 minecraft:light[level=12]
setblock 245 217 252 minecraft:light[level=12]
setblock 245 217 259 minecraft:light[level=12]
setblock 245 217 266 minecraft:light[level=12]
fill 251 217 228 251 288 228 minecraft:black_concrete
setblock 252 217 231 minecraft:light[level=12]
setblock 252 217 238 minecraft:light[level=12]
setblock 252 217 245 minecraft:light[level=12]
setblock 252 217 252 minecraft:light[level=12]
setblock 252 217 259 minecraft:light[level=12]
setblock 252 217 266 minecraft:light[level=12]
fill 258 217 228 258 308 228 minecraft:black_concrete
setblock 259 217 231 minecraft:light[level=12]
setblock 259 217 238 minecraft:light[level=12]
setblock 259 217 245 minecraft:light[level=12]
setblock 259 217 252 minecraft:light[level=12]
setblock 259 217 259 minecraft:light[level=12]
setblock 259 217 266 minecraft:light[level=12]
setblock 266 217 231 minecraft:light[level=12]
setblock 266 217 238 minecraft:light[level=12]
setblock 266 217 245 minecraft:light[level=12]
setblock 266 217 252 minecraft:light[level=12]
setblock 266 217 259 minecraft:light[level=12]
setblock 266 217 266 minecraft:light[level=12]
setblock 273 217 238 minecraft:light[level=12]
setblock 273 217 259 minecraft:light[level=12]
setblock 277 217 246 minecraft:magenta_concrete
setblock 235 218 230 minecraft:purple_concrete
setblock 236 218 230 minecraft:cyan_stained_glass
setblock 236 218 232 minecraft:black_stained_glass
setblock 236 218 234 minecraft:light_blue_stained_glass
setblock 236 218 236 minecraft:pearlescent_froglight
setblock 237 218 229 minecraft:black_stained_glass
setblock 237 218 237 minecraft:black_stained_glass
setblock 239 218 229 minecraft:magenta_stained_glass
setblock 239 218 237 minecraft:cyan_stained_glass
setblock 241 218 229 minecraft:ochre_froglight
setblock 241 218 237 minecraft:magenta_stained_glass
setblock 243 218 229 minecraft:sea_lantern
setblock 243 218 237 minecraft:black_stained_glass
setblock 244 218 230 minecraft:light_blue_stained_glass
setblock 244 218 232 minecraft:pearlescent_froglight
setblock 244 218 234 minecraft:black_stained_glass
setblock 244 218 236 minecraft:black_stained_glass
setblock 268 218 262 minecraft:black_stained_glass
setblock 268 218 264 minecraft:cyan_stained_glass
setblock 268 218 266 minecraft:black_stained_glass
setblock 268 218 268 minecraft:black_stained_glass
setblock 269 218 261 minecraft:black_stained_glass
setblock 269 218 269 minecraft:sea_lantern
setblock 270 218 232 minecraft:black_stained_glass
setblock 270 218 234 minecraft:ochre_froglight
setblock 271 218 231 minecraft:sea_lantern
setblock 271 218 235 minecraft:light_blue_stained_glass
setblock 271 218 243 minecraft:black_stained_glass
setblock 271 218 245 minecraft:cyan_stained_glass
setblock 271 218 247 minecraft:ochre_froglight
setblock 271 218 249 minecraft:light_blue_stained_glass
setblock 271 218 251 minecraft:black_stained_glass
setblock 271 218 253 minecraft:black_stained_glass
setblock 271 218 261 minecraft:light_blue_stained_glass
setblock 271 218 269 minecraft:magenta_stained_glass
setblock 272 218 242 minecraft:black_stained_glass
setblock 272 218 255 minecraft:pearlescent_froglight
setblock 273 218 231 minecraft:pearlescent_froglight
setblock 273 218 235 minecraft:black_stained_glass
setblock 273 218 261 minecraft:black_stained_glass
setblock 273 218 269 minecraft:magenta_stained_glass
setblock 274 218 232 minecraft:black_stained_glass
setblock 274 218 234 minecraft:black_stained_glass
setblock 274 218 242 minecraft:black_stained_glass
setblock 274 218 255 minecraft:black_stained_glass
setblock 275 218 261 minecraft:black_stained_glass
setblock 275 218 269 minecraft:pearlescent_froglight
setblock 276 218 243 minecraft:black_stained_glass
setblock 276 218 245 minecraft:black_stained_glass
setblock 276 218 247 minecraft:black_stained_glass
setblock 276 218 249 minecraft:pearlescent_froglight
setblock 276 218 251 minecraft:black_stained_glass
setblock 276 218 253 minecraft:black_stained_glass
setblock 276 218 262 minecraft:magenta_stained_glass
setblock 276 218 264 minecraft:ochre_froglight
setblock 276 218 266 minecraft:black_stained_glass
setblock 276 218 268 minecraft:pearlescent_froglight
fill 277 218 246 277 230 246 minecraft:black_concrete
fill 235 219 230 235 249 230 minecraft:black_concrete
setblock 235 219 264 minecraft:ochre_froglight
fill 236 219 230 236 220 230 minecraft:light_gray_concrete
fill 236 219 232 236 220 232 minecraft:light_gray_concrete
fill 236 219 234 236 220 234 minecraft:light_gray_concrete
fill 236 219 236 236 220 236 minecraft:light_gray_concrete
fill 237 219 229 237 220 229 minecraft:light_gray_concrete
fill 237 219 237 237 220 237 minecraft:light_gray_concrete
fill 239 219 229 239 220 229 minecraft:light_gray_concrete
fill 239 219 237 239 220 237 minecraft:light_gray_concrete
fill 241 219 229 241 220 229 minecraft:light_gray_concrete
fill 241 219 237 241 220 237 minecraft:light_gray_concrete
fill 243 219 229 243 220 229 minecraft:light_gray_concrete
fill 243 219 237 243 220 237 minecraft:light_gray_concrete
fill 244 219 230 244 220 230 minecraft:light_gray_concrete
fill 244 219 232 244 220 232 minecraft:light_gray_concrete
fill 244 219 234 244 220 234 minecraft:light_gray_concrete
fill 244 219 236 244 220 236 minecraft:light_gray_concrete
setblock 262 219 270 minecraft:cyan_concrete
setblock 266 219 228 minecraft:blue_concrete
fill 268 219 262 268 220 262 minecraft:light_gray_concrete
fill 268 219 264 268 220 264 minecraft:light_gray_concrete
fill 268 219 266 268 220 266 minecraft:light_gray_concrete
fill 268 219 268 268 220 268 minecraft:light_gray_concrete
fill 269 219 261 269 220 261 minecraft:light_gray_concrete
fill 269 219 269 269 220 269 minecraft:light_gray_concrete
fill 270 219 232 270 220 232 minecraft:cyan_terracotta
fill 270 219 234 270 220 234 minecraft:cyan_terracotta
fill 271 219 231 271 220 231 minecraft:cyan_terracotta
fill 271 219 235 271 220 235 minecraft:cyan_terracotta
fill 271 219 243 271 220 243 minecraft:light_gray_concrete
fill 271 219 245 271 220 245 minecraft:light_gray_concrete
fill 271 219 247 271 220 247 minecraft:light_gray_concrete
fill 271 219 249 271 220 249 minecraft:light_gray_concrete
fill 271 219 251 271 220 251 minecraft:light_gray_concrete
fill 271 219 253 271 220 253 minecraft:light_gray_concrete
fill 271 219 261 271 220 261 minecraft:light_gray_concrete
fill 271 219 269 271 220 269 minecraft:light_gray_concrete
fill 272 219 242 272 220 242 minecraft:light_gray_concrete
fill 272 219 255 272 220 255 minecraft:light_gray_concrete
fill 273 219 231 273 220 231 minecraft:cyan_terracotta
fill 273 219 235 273 220 235 minecraft:cyan_terracotta
fill 273 219 261 273 220 261 minecraft:light_gray_concrete
fill 273 219 269 273 220 269 minecraft:light_gray_concrete
fill 274 219 232 274 220 232 minecraft:cyan_terracotta
fill 274 219 234 274 220 234 minecraft:cyan_terracotta
fill 274 219 242 274 220 242 minecraft:light_gray_concrete
fill 274 219 255 274 220 255 minecraft:light_gray_concrete
fill 275 219 261 275 220 261 minecraft:light_gray_concrete
fill 275 219 269 275 220 269 minecraft:light_gray_concrete
fill 276 219 243 276 220 243 minecraft:light_gray_concrete
fill 276 219 245 276 220 245 minecraft:light_gray_concrete
fill 276 219 247 276 220 247 minecraft:light_gray_concrete
fill 276 219 249 276 220 249 minecraft:light_gray_concrete
fill 276 219 251 276 220 251 minecraft:light_gray_concrete
fill 276 219 253 276 220 253 minecraft:light_gray_concrete
fill 276 219 262 276 220 262 minecraft:light_gray_concrete
fill 276 219 264 276 220 264 minecraft:light_gray_concrete
fill 276 219 266 276 220 266 minecraft:light_gray_concrete
fill 276 219 268 276 220 268 minecraft:light_gray_concrete
setblock 235 220 257 minecraft:sea_lantern
fill 235 220 264 235 308 264 minecraft:black_concrete
setblock 238 220 239 minecraft:light[level=15]
setblock 238 220 247 minecraft:light[level=15]
setblock 238 220 255 minecraft:light[level=15]
setblock 238 220 263 minecraft:light[level=15]
setblock 246 220 231 minecraft:light[level=15]
setblock 246 220 239 minecraft:light[level=15]
setblock 246 220 247 minecraft:light[level=15]
setblock 246 220 255 minecraft:light[level=15]
setblock 246 220 263 minecraft:light[level=15]
setblock 254 220 231 minecraft:light[level=15]
setblock 254 220 239 minecraft:light[level=15]
setblock 254 220 247 minecraft:light[level=15]
setblock 254 220 255 minecraft:light[level=15]
setblock 254 220 263 minecraft:light[level=15]
setblock 262 220 231 minecraft:light[level=15]
setblock 262 220 239 minecraft:light[level=15]
setblock 262 220 247 minecraft:light[level=15]
setblock 262 220 255 minecraft:light[level=15]
setblock 262 220 263 minecraft:light[level=15]
fill 262 220 270 262 252 270 minecraft:black_concrete
fill 266 220 228 266 243 228 minecraft:black_concrete
setblock 268 220 228 minecraft:pearlescent_froglight
setblock 270 220 239 minecraft:light[level=15]
setblock 270 220 247 minecraft:light[level=15]
setblock 270 220 255 minecraft:light[level=15]
setblock 277 220 241 minecraft:purple_concrete
fill 235 221 257 235 237 257 minecraft:black_concrete
setblock 236 221 230 minecraft:magenta_stained_glass
setblock 236 221 232 minecraft:sea_lantern
setblock 236 221 234 minecraft:magenta_stained_glass
setblock 236 221 236 minecraft:light_blue_stained_glass
setblock 237 221 229 minecraft:black_stained_glass
setblock 237 221 237 minecraft:pearlescent_froglight
setblock 239 221 229 minecraft:pearlescent_froglight
setblock 239 221 237 minecraft:black_stained_glass
setblock 241 221 229 minecraft:sea_lantern
setblock 241 221 237 minecraft:light_blue_stained_glass
fill 242 221 248 243 221 250 minecraft:light_gray_concrete
setblock 243 221 229 minecraft:pearlescent_froglight
setblock 243 221 237 minecraft:black_stained_glass
fill 243 221 244 243 222 247 minecraft:light_gray_concrete
fill 243 221 251 243 222 254 minecraft:light_gray_concrete
setblock 244 221 230 minecraft:black_stained_glass
setblock 244 221 232 minecraft:ochre_froglight
setblock 244 221 234 minecraft:ochre_froglight
setblock 244 221 236 minecraft:pearlescent_froglight
fill 244 221 242 244 221 245 minecraft:light_gray_concrete
fill 244 221 254 244 221 256 minecraft:light_gray_concrete
fill 245 221 241 245 222 242 minecraft:light_gray_concrete
fill 245 221 245 245 221 246 minecraft:light_gray_concrete
fill 245 221 256 245 222 257 minecraft:light_gray_concrete
fill 246 221 240 246 222 240 minecraft:light_gray_concrete
fill 246 221 246 248 221 246 minecraft:light_gray_concrete
fill 246 221 258 247 221 258 minecraft:light_gray_concrete
fill 247 221 239 247 222 239 minecraft:light_gray_concrete
fill 247 221 257 248 221 257 minecraft:light_gray_concrete
fill 247 221 259 247 222 259 minecraft:light_gray_concrete
fill 248 221 238 249 222 238 minecraft:light_gray_concrete
fill 248 221 247 249 221 247 minecraft:light_gray_concrete
fill 248 221 256 249 221 256 minecraft:light_gray_concrete
fill 248 221 260 249 222 260 minecraft:light_gray_concrete
fill 249 221 237 251 221 237 minecraft:light_gray_concrete
fill 249 221 248 260 221 251 minecraft:gray_concrete
fill 249 221 255 250 221 255 minecraft:light_gray_concrete
fill 249 221 261 251 221 261 minecraft:light_gray_concrete
fill 250 221 245 262 221 247 minecraft:gray_concrete
fill 250 221 252 260 221 253 minecraft:gray_concrete
fill 250 221 254 251 221 254 minecraft:light_gray_concrete
fill 251 221 236 261 221 236 minecraft:light_gray_concrete
fill 251 221 244 260 221 244 minecraft:gray_concrete
fill 251 221 262 261 221 262 minecraft:light_gray_concrete
fill 252 221 243 260 221 243 minecraft:gray_concrete
fill 252 221 254 260 221 255 minecraft:gray_concrete
fill 253 221 237 253 221 238 minecraft:light_gray_concrete
fill 254 221 238 254 221 242 minecraft:light_gray_concrete
fill 254 221 256 256 221 256 minecraft:gray_concrete
fill 255 221 235 257 222 235 minecraft:light_gray_concrete
fill 255 221 242 255 223 242 minecraft:light_gray_concrete
fill 255 221 263 257 222 263 minecraft:light_gray_concrete
fill 256 221 242 258 221 242 minecraft:gray_concrete
fill 257 221 256 258 222 256 minecraft:light_gray_concrete
fill 258 221 257 258 221 260 minecraft:light_gray_concrete
fill 259 221 260 259 221 261 minecraft:light_gray_concrete
fill 261 221 237 263 221 237 minecraft:light_gray_concrete
fill 261 221 244 262 221 244 minecraft:light_gray_concrete
fill 261 221 248 261 221 249 minecraft:gray_concrete
fill 261 221 253 261 221 254 minecraft:gray_concrete
fill 261 221 261 263 221 261 minecraft:light_gray_concrete
fill 262 221 243 263 221 243 minecraft:light_gray_concrete
setblock 262 221 248 minecraft:gray_concrete
fill 263 221 238 264 222 238 minecraft:light_gray_concrete
fill 263 221 242 264 221 242 minecraft:light_gray_concrete
setblock 263 221 247 minecraft:gray_concrete
fill 263 221 260 264 222 260 minecraft:light_gray_concrete
fill 264 221 241 265 221 241 minecraft:light_gray_concrete
fill 265 221 239 265 221 240 minecraft:light_gray_concrete
fill 265 221 259 265 222 259 minecraft:light_gray_concrete
fill 266 221 240 266 223 240 minecraft:light_gray_concrete
fill 266 221 258 266 222 258 minecraft:light_gray_concrete
setblock 266 221 270 minecraft:purple_concrete
fill 267 221 241 267 222 242 minecraft:light_gray_concrete
fill 267 221 253 269 221 253 minecraft:light_gray_concrete
fill 267 221 256 267 222 257 minecraft:light_gray_concrete
fill 268 221 228 268 308 228 minecraft:black_concrete
fill 268 221 242 268 221 244 minecraft:light_gray_concrete
fill 268 221 254 268 221 256 minecraft:light_gray_concrete
setblock 268 221 262 minecraft:black_stained_glass
setblock 268 221 264 minecraft:ochre_froglight
setblock 268 221 266 minecraft:light_blue_stained_glass
setblock 268 221 268 minecraft:black_stained_glass
fill 269 221 244 269 221 252 minecraft:light_gray_concrete
fill 269 221 254 269 222 254 minecraft:light_gray_concrete
setblock 269 221 261 minecraft:black_stained_glass
setblock 269 221 269 minecraft:black_stained_glass
fill 270 221 248 270 222 250 minecraft:light_gray_concrete
setblock 271 221 243 minecraft:ochre_froglight
setblock 271 221 245 minecraft:ochre_froglight
setblock 271 221 247 minecraft:pearlescent_froglight
setblock 271 221 249 minecraft:light_blue_stained_glass
setblock 271 221 251 minecraft:black_stained_glass
setblock 271 221 253 minecraft:black_stained_glass
setblock 271 221 261 minecraft:sea_lantern
setblock 271 221 269 minecraft:black_stained_glass
setblock 272 221 233 minecraft:redstone_block
setblock 272 221 242 minecraft:black_stained_glass
setblock 272 221 255 minecraft:light_blue_stained_glass
setblock 273 221 261 minecraft:black_stained_glass
setblock 273 221 269 minecraft:magenta_stained_glass
setblock 274 221 242 minecraft:magenta_stained_glass
setblock 274 221 255 minecraft:cyan_stained_glass
setblock 275 221 261 minecraft:black_stained_glass
setblock 275 221 269 minecraft:black_stained_glass
setblock 276 221 243 minecraft:black_stained_glass
setblock 276 221 245 minecraft:black_stained_glass
setblock 276 221 247 minecraft:sea_lantern
setblock 276 221 249 minecraft:cyan_stained_glass
setblock 276 221 251 minecraft:black_stained_glass
setblock 276 221 253 minecraft:magenta_stained_glass
setblock 276 221 262 minecraft:pearlescent_froglight
setblock 276 221 264 minecraft:black_stained_glass
setblock 276 221 266 minecraft:light_blue_stained_glass
setblock 276 221 268 minecraft:ochre_froglight
fill 277 221 241 277 233 241 minecraft:black_concrete
fill 236 222 230 236 223 230 minecraft:light_gray_concrete
fill 236 222 232 236 223 232 minecraft:light_gray_concrete
fill 236 222 234 236 223 234 minecraft:light_gray_concrete
fill 236 222 236 236 223 236 minecraft:light_gray_concrete
fill 237 222 229 237 223 229 minecraft:light_gray_concrete
fill 237 222 237 237 223 237 minecraft:light_gray_concrete
fill 239 222 229 239 223 229 minecraft:light_gray_concrete
fill 239 222 237 239 223 237 minecraft:light_gray_concrete
fill 241 222 229 241 223 229 minecraft:light_gray_concrete
fill 241 222 237 241 223 237 minecraft:light_gray_concrete
fill 242 222 245 242 222 253 minecraft:light_gray_concrete
fill 243 222 229 243 223 229 minecraft:light_gray_concrete
fill 243 222 237 243 223 237 minecraft:light_gray_concrete
fill 243 222 243 244 222 243 minecraft:light_gray_concrete
setblock 243 222 248 minecraft:light_gray_concrete
fill 243 222 249 248 222 249 minecraft:gray_stained_glass
setblock 243 222 250 minecraft:light_gray_concrete
fill 243 222 255 244 222 255 minecraft:light_gray_concrete
fill 244 222 230 244 223 230 minecraft:light_gray_concrete
fill 244 222 232 244 223 232 minecraft:light_gray_concrete
fill 244 222 234 244 223 234 minecraft:light_gray_concrete
fill 244 222 236 244 223 236 minecraft:light_gray_concrete
fill 244 222 241 244 222 242 minecraft:light_gray_concrete
fill 244 222 244 247 222 245 minecraft:black_stained_glass
fill 244 222 246 244 222 248 minecraft:gray_stained_glass
fill 244 222 250 244 222 252 minecraft:black_stained_glass
fill 244 222 253 247 222 254 minecraft:gray_stained_glass
fill 244 222 256 244 222 257 minecraft:light_gray_concrete
setblock 245 222 240 minecraft:light_gray_concrete
setblock 245 222 243 minecraft:black_stained_glass
fill 245 222 246 249 222 246 minecraft:black_stained_glass
fill 245 222 247 248 222 248 minecraft:gray_stained_glass
fill 245 222 250 248 222 251 minecraft:black_stained_glass
fill 245 222 252 249 222 252 minecraft:gray_stained_glass
setblock 245 222 255 minecraft:gray_stained_glass
fill 245 222 258 246 222 258 minecraft:light_gray_concrete
setblock 246 222 239 minecraft:light_gray_concrete
fill 246 222 241 247 222 243 minecraft:gray_stained_glass
fill 246 222 255 248 222 257 minecraft:black_stained_glass
setblock 246 222 259 minecraft:light_gray_concrete
setblock 247 222 238 minecraft:light_gray_concrete
fill 247 222 240 250 222 240 minecraft:black_stained_glass
setblock 247 222 258 minecraft:black_stained_glass
setblock 247 222 260 minecraft:light_gray_concrete
fill 248 222 237 250 222 237 minecraft:light_gray_concrete
fill 248 222 239 250 222 239 minecraft:black_stained_glass
fill 248 222 241 251 222 241 minecraft:black_stained_glass
fill 248 222 242 248 222 244 minecraft:gray_stained_glass
fill 248 222 245 249 222 245 minecraft:black_stained_glass
fill 248 222 253 249 222 253 minecraft:gray_stained_glass
fill 248 222 254 250 222 254 minecraft:black_stained_glass
fill 248 222 258 250 222 259 minecraft:gray_stained_glass
fill 248 222 261 250 222 261 minecraft:light_gray_concrete
fill 249 222 242 251 222 242 minecraft:black_stained_glass
fill 249 222 243 249 222 244 minecraft:gray_stained_glass
fill 249 222 247 249 222 248 minecraft:light_gray_concrete
fill 249 222 249 249 222 251 minecraft:sea_lantern
fill 249 222 255 249 222 256 minecraft:black_stained_glass
fill 249 222 257 251 222 257 minecraft:gray_stained_glass
fill 250 222 236 255 222 236 minecraft:light_gray_concrete
fill 250 222 238 253 222 238 minecraft:gray_stained_glass
fill 250 222 243 251 222 243 minecraft:black_stained_glass
setblock 250 222 244 minecraft:gray_stained_glass
fill 250 222 245 251 222 245 minecraft:sea_lantern
fill 250 222 246 250 222 247 minecraft:light_gray_concrete
fill 250 222 248 259 222 251 minecraft:black_stained_glass
setblock 250 222 252 minecraft:sea_lantern
fill 250 222 253 251 222 253 minecraft:light_gray_concrete
setblock 250 222 255 minecraft:black_stained_glass
fill 250 222 256 251 222 256 minecraft:gray_stained_glass
fill 250 222 260 253 222 260 minecraft:black_stained_glass
fill 250 222 262 255 222 262 minecraft:light_gray_concrete
fill 251 222 237 252 222 237 minecraft:gray_stained_glass
fill 251 222 239 253 222 240 minecraft:gray_stained_glass
fill 251 222 244 252 222 244 minecraft:sea_lantern
fill 251 222 246 261 222 247 minecraft:black_stained_glass
fill 251 222 252 259 222 252 minecraft:black_stained_glass
fill 251 222 254 252 222 254 minecraft:light_gray_concrete
setblock 251 222 255 minecraft:gray_stained_glass
fill 251 222 258 253 222 259 minecraft:black_stained_glass
fill 251 222 261 252 222 261 minecraft:black_stained_glass
fill 252 222 235 254 222 235 minecraft:light_gray_concrete
fill 252 222 241 253 222 242 minecraft:gray_stained_glass
fill 252 222 243 253 222 243 minecraft:sea_lantern
fill 252 222 245 260 222 245 minecraft:black_stained_glass
fill 252 222 253 259 222 253 minecraft:black_stained_glass
fill 252 222 255 253 222 255 minecraft:sea_lantern
fill 252 222 256 253 222 257 minecraft:black_stained_glass
fill 252 222 263 254 222 263 minecraft:light_gray_concrete
fill 253 222 237 255 222 237 minecraft:black_stained_glass
fill 253 222 244 259 222 244 minecraft:black_stained_glass
fill 253 222 254 259 222 254 minecraft:black_stained_glass
fill 253 222 261 256 222 261 minecraft:gray_stained_glass
fill 254 222 238 255 222 241 minecraft:black_stained_glass
fill 254 222 242 254 222 243 minecraft:light_gray_concrete
fill 254 222 255 256 222 255 minecraft:black_stained_glass
fill 254 222 256 256 222 256 minecraft:sea_lantern
fill 254 222 257 256 222 260 minecraft:gray_stained_glass
setblock 255 222 243 minecraft:light_gray_concrete
fill 256 222 236 256 222 241 minecraft:gray_stained_glass
fill 256 222 242 258 222 242 minecraft:sea_lantern
fill 256 222 243 258 222 243 minecraft:black_stained_glass
setblock 256 222 262 minecraft:gray_stained_glass
fill 257 222 236 262 222 236 minecraft:light_gray_concrete
fill 257 222 237 258 222 241 minecraft:gray_stained_glass
fill 257 222 255 258 222 255 minecraft:light_gray_concrete
fill 257 222 257 258 222 261 minecraft:black_stained_glass
fill 257 222 262 262 222 262 minecraft:light_gray_concrete
fill 258 222 235 260 222 235 minecraft:light_gray_concrete
fill 258 222 263 260 222 263 minecraft:light_gray_concrete
setblock 259 222 237 minecraft:gray_stained_glass
fill 259 222 238 260 222 242 minecraft:black_stained_glass
fill 259 222 243 260 222 243 minecraft:sea_lantern
fill 259 222 255 260 222 255 minecraft:sea_lantern
fill 259 222 256 260 222 260 minecraft:gray_stained_glass
setblock 259 222 261 minecraft:black_stained_glass
fill 260 222 237 261 222 237 minecraft:black_stained_glass
fill 260 222 244 261 222 244 minecraft:light_gray_concrete
setblock 260 222 248 minecraft:black_stained_glass
fill 260 222 249 261 222 249 minecraft:pearlescent_froglight
fill 260 222 250 260 222 252 minecraft:sea_lantern
fill 260 222 253 261 222 253 minecraft:pearlescent_froglight
fill 260 222 254 261 222 254 minecraft:sea_lantern
fill 260 222 261 261 222 261 minecraft:gray_stained_glass
fill 261 222 238 261 222 240 minecraft:black_stained_glass
fill 261 222 241 261 222 243 minecraft:gray_stained_glass
fill 261 222 245 262 222 245 minecraft:light_gray_concrete
setblock 261 222 248 minecraft:sea_lantern
fill 261 222 255 261 222 257 minecraft:black_stained_glass
fill 261 222 258 261 222 260 minecraft:gray_stained_glass
fill 262 222 237 264 222 237 minecraft:light_gray_concrete
setblock 262 222 238 minecraft:black_stained_glass
fill 262 222 239 262 222 242 minecraft:gray_stained_glass
fill 262 222 243 264 222 244 minecraft:black_stained_glass
setblock 262 222 246 minecraft:sea_lantern
fill 262 222 247 262 222 248 minecraft:pearlescent_froglight
fill 262 222 254 262 222 255 minecraft:pearlescent_froglight
fill 262 222 256 263 222 259 minecraft:black_stained_glass
setblock 262 222 260 minecraft:gray_stained_glass
fill 262 222 261 264 222 261 minecraft:light_gray_concrete
fill 263 222 239 263 222 241 minecraft:gray_stained_glass
fill 263 222 242 266 222 242 minecraft:black_stained_glass
fill 263 222 245 267 222 246 minecraft:gray_stained_glass
fill 263 222 247 265 222 247 minecraft:sea_lantern
fill 263 222 255 265 222 255 minecraft:sea_lantern
fill 264 222 239 264 222 240 minecraft:gray_stained_glass
fill 264 222 241 266 222 241 minecraft:black_stained_glass
fill 264 222 256 266 222 256 minecraft:gray_stained_glass
fill 264 222 257 264 222 259 minecraft:black_stained_glass
fill 265 222 238 265 222 239 minecraft:light_gray_concrete
setblock 265 222 240 minecraft:black_stained_glass
fill 265 222 243 266 222 243 minecraft:black_stained_glass
fill 265 222 244 268 222 244 minecraft:gray_stained_glass
fill 265 222 257 266 222 257 minecraft:gray_stained_glass
setblock 265 222 258 minecraft:black_stained_glass
setblock 265 222 260 minecraft:light_gray_concrete
setblock 266 222 239 minecraft:light_gray_concrete
fill 266 222 247 266 222 248 minecraft:pearlescent_froglight
schedule function dropper:buildpart/53_7 1t
