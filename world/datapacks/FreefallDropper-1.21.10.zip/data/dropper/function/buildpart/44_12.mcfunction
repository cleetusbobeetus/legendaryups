fill 379 298 200 379 300 200 minecraft:mossy_cobblestone
setblock 379 298 204 minecraft:stone_bricks
fill 379 298 205 379 300 205 minecraft:mossy_cobblestone
setblock 379 298 209 minecraft:stone_bricks
fill 379 298 210 379 300 210 minecraft:mossy_cobblestone
setblock 380 298 183 minecraft:stone_bricks
fill 380 298 184 380 300 184 minecraft:mossy_cobblestone
setblock 380 298 188 minecraft:stone_bricks
fill 380 298 189 380 300 189 minecraft:mossy_cobblestone
setblock 381 298 182 minecraft:stone_bricks
fill 381 298 183 384 298 183 minecraft:mossy_cobblestone
setblock 381 298 222 minecraft:stone_bricks
fill 382 298 182 385 298 182 minecraft:mossy_cobblestone
fill 382 298 222 382 300 222 minecraft:mossy_cobblestone
setblock 383 298 185 minecraft:stone_bricks
setblock 384 298 184 minecraft:stone_bricks
setblock 385 298 183 minecraft:stone_bricks
fill 385 298 184 385 300 184 minecraft:mossy_cobblestone
setblock 386 298 182 minecraft:stone_bricks
fill 386 298 183 389 298 183 minecraft:mossy_cobblestone
fill 387 298 182 390 298 182 minecraft:mossy_cobblestone
setblock 390 298 183 minecraft:stone_bricks
setblock 391 298 182 minecraft:stone_bricks
fill 391 298 183 394 298 183 minecraft:mossy_cobblestone
fill 392 298 182 395 298 182 minecraft:mossy_cobblestone
fill 392 298 184 393 298 184 minecraft:mossy_cobblestone
fill 392 298 222 395 298 222 minecraft:mossy_cobblestone
setblock 394 298 184 minecraft:stone_bricks
setblock 395 298 183 minecraft:stone_bricks
fill 395 298 184 395 300 184 minecraft:mossy_cobblestone
setblock 396 298 182 minecraft:stone_bricks
fill 396 298 183 396 300 183 minecraft:mossy_cobblestone
setblock 396 298 221 minecraft:mossy_cobblestone
setblock 396 298 222 minecraft:stone_bricks
fill 397 298 182 397 300 182 minecraft:mossy_cobblestone
setblock 397 298 185 minecraft:mossy_cobblestone
setblock 397 298 221 minecraft:stone_bricks
fill 397 298 222 400 298 222 minecraft:mossy_cobblestone
setblock 398 298 185 minecraft:stone_bricks
fill 398 298 221 401 298 221 minecraft:mossy_cobblestone
setblock 399 298 184 minecraft:stone_bricks
fill 399 298 185 400 299 185 minecraft:mossy_cobblestone
setblock 400 298 183 minecraft:stone_bricks
fill 400 298 184 400 300 184 minecraft:mossy_cobblestone
setblock 401 298 182 minecraft:stone_bricks
fill 401 298 183 401 300 183 minecraft:mossy_cobblestone
setblock 401 298 222 minecraft:stone_bricks
fill 402 298 182 402 300 182 minecraft:mossy_cobblestone
setblock 402 298 221 minecraft:stone_bricks
fill 402 298 222 402 300 222 minecraft:mossy_cobblestone
fill 403 298 221 403 300 221 minecraft:mossy_cobblestone
setblock 405 298 183 minecraft:stone_bricks
setblock 406 298 182 minecraft:stone_bricks
setblock 406 298 222 minecraft:stone_bricks
setblock 407 298 182 minecraft:mossy_cobblestone
fill 407 298 222 407 299 222 minecraft:mossy_cobblestone
fill 414 298 182 415 298 182 minecraft:mossy_cobblestone
setblock 415 298 203 minecraft:stone_bricks
fill 415 298 204 415 300 204 minecraft:mossy_cobblestone
setblock 415 298 208 minecraft:stone_bricks
fill 415 298 209 415 300 209 minecraft:mossy_cobblestone
fill 415 298 211 415 299 211 minecraft:mossy_cobblestone
setblock 415 298 222 minecraft:mossy_cobblestone
setblock 416 298 182 minecraft:stone_bricks
fill 416 298 184 416 298 186 minecraft:mossy_cobblestone
setblock 416 298 187 minecraft:stone_bricks
fill 416 298 188 416 300 189 minecraft:mossy_cobblestone
fill 416 298 199 416 300 199 minecraft:mossy_cobblestone
setblock 416 298 202 minecraft:stone_bricks
fill 416 298 203 416 300 203 minecraft:mossy_cobblestone
setblock 416 298 207 minecraft:stone_bricks
fill 416 298 208 416 300 208 minecraft:mossy_cobblestone
setblock 416 298 212 minecraft:stone_bricks
fill 416 298 213 416 300 214 minecraft:mossy_cobblestone
setblock 416 298 222 minecraft:stone_bricks
fill 417 298 182 417 300 182 minecraft:mossy_cobblestone
setblock 417 298 185 minecraft:mossy_cobblestone
setblock 417 298 186 minecraft:stone_bricks
fill 417 298 187 417 300 187 minecraft:mossy_cobblestone
setblock 417 298 190 minecraft:mossy_cobblestone
setblock 417 298 191 minecraft:stone_bricks
fill 417 298 192 417 298 195 minecraft:mossy_cobblestone
setblock 417 298 196 minecraft:stone_bricks
fill 417 298 197 417 300 197 minecraft:mossy_cobblestone
setblock 417 298 201 minecraft:stone_bricks
fill 417 298 202 417 300 202 minecraft:mossy_cobblestone
setblock 417 298 206 minecraft:stone_bricks
fill 417 298 207 417 300 207 minecraft:mossy_cobblestone
setblock 417 298 211 minecraft:stone_bricks
fill 417 298 212 417 300 212 minecraft:mossy_cobblestone
setblock 417 298 216 minecraft:stone_bricks
fill 417 298 217 417 299 219 minecraft:mossy_cobblestone
setblock 417 298 221 minecraft:stone_bricks
fill 417 298 222 417 300 222 minecraft:mossy_cobblestone
setblock 377 299 185 minecraft:stone_bricks
fill 377 299 186 377 299 189 minecraft:mossy_cobblestone
setblock 377 299 190 minecraft:stone_bricks
fill 377 299 191 377 300 191 minecraft:mossy_cobblestone
setblock 377 299 194 minecraft:mossy_cobblestone
setblock 377 299 195 minecraft:stone_bricks
fill 377 299 196 377 300 196 minecraft:mossy_cobblestone
setblock 377 299 200 minecraft:stone_bricks
fill 377 299 201 377 300 201 minecraft:mossy_cobblestone
setblock 377 299 205 minecraft:stone_bricks
fill 377 299 206 377 300 206 minecraft:mossy_cobblestone
setblock 377 299 210 minecraft:stone_bricks
fill 377 299 211 377 300 211 minecraft:mossy_cobblestone
setblock 377 299 214 minecraft:mossy_cobblestone
setblock 377 299 215 minecraft:stone_bricks
fill 377 299 216 377 300 216 minecraft:mossy_cobblestone
setblock 378 299 184 minecraft:stone_bricks
fill 378 299 185 378 300 185 minecraft:mossy_cobblestone
setblock 378 299 188 minecraft:mossy_cobblestone
setblock 378 299 189 minecraft:stone_bricks
fill 378 299 190 378 300 190 minecraft:mossy_cobblestone
setblock 378 299 194 minecraft:stone_bricks
fill 378 299 195 379 300 195 minecraft:mossy_cobblestone
setblock 378 299 199 minecraft:stone_bricks
fill 378 299 200 378 300 200 minecraft:mossy_cobblestone
setblock 378 299 204 minecraft:stone_bricks
fill 378 299 205 378 300 205 minecraft:mossy_cobblestone
setblock 378 299 208 minecraft:mossy_cobblestone
setblock 378 299 209 minecraft:stone_bricks
fill 378 299 210 378 300 210 minecraft:mossy_cobblestone
setblock 378 299 213 minecraft:mossy_cobblestone
setblock 379 299 183 minecraft:stone_bricks
fill 379 299 184 379 300 184 minecraft:mossy_cobblestone
setblock 379 299 188 minecraft:stone_bricks
fill 379 299 189 379 300 189 minecraft:mossy_cobblestone
setblock 379 299 192 minecraft:mossy_cobblestone
setblock 379 299 193 minecraft:stone_bricks
fill 379 299 194 379 300 194 minecraft:mossy_cobblestone
fill 379 299 196 379 300 196 minecraft:mossy_cobblestone
setblock 379 299 199 minecraft:mossy_cobblestone
setblock 379 299 203 minecraft:stone_bricks
fill 379 299 204 379 300 204 minecraft:mossy_cobblestone
setblock 379 299 208 minecraft:stone_bricks
fill 379 299 209 379 300 209 minecraft:mossy_cobblestone
fill 379 299 211 379 300 211 minecraft:mossy_cobblestone
setblock 380 299 182 minecraft:stone_bricks
fill 380 299 183 383 299 183 minecraft:mossy_cobblestone
fill 380 299 185 381 299 185 minecraft:mossy_cobblestone
setblock 380 299 187 minecraft:stone_bricks
fill 380 299 188 380 300 188 minecraft:mossy_cobblestone
setblock 380 299 191 minecraft:mossy_cobblestone
setblock 380 299 222 minecraft:stone_bricks
fill 381 299 182 384 299 182 minecraft:mossy_cobblestone
fill 381 299 222 381 300 222 minecraft:mossy_cobblestone
setblock 382 299 185 minecraft:stone_bricks
setblock 383 299 184 minecraft:stone_bricks
fill 383 299 185 383 300 185 minecraft:mossy_cobblestone
setblock 384 299 183 minecraft:stone_bricks
fill 384 299 184 384 300 184 minecraft:mossy_cobblestone
setblock 385 299 182 minecraft:stone_bricks
fill 385 299 183 388 299 183 minecraft:mossy_cobblestone
fill 386 299 182 389 299 182 minecraft:mossy_cobblestone
setblock 389 299 183 minecraft:stone_bricks
setblock 390 299 182 minecraft:stone_bricks
fill 390 299 183 393 299 183 minecraft:mossy_cobblestone
fill 391 299 182 394 299 182 minecraft:mossy_cobblestone
fill 391 299 184 392 299 184 minecraft:mossy_cobblestone
fill 392 299 222 394 299 222 minecraft:mossy_cobblestone
setblock 393 299 184 minecraft:stone_bricks
setblock 394 299 183 minecraft:stone_bricks
fill 394 299 184 394 300 184 minecraft:mossy_cobblestone
setblock 395 299 182 minecraft:stone_bricks
fill 395 299 183 395 300 183 minecraft:mossy_cobblestone
fill 395 299 185 396 299 185 minecraft:mossy_cobblestone
setblock 395 299 221 minecraft:mossy_cobblestone
setblock 395 299 222 minecraft:stone_bricks
fill 396 299 182 396 300 182 minecraft:mossy_cobblestone
setblock 396 299 221 minecraft:stone_bricks
fill 396 299 222 399 299 222 minecraft:mossy_cobblestone
setblock 397 299 185 minecraft:stone_bricks
fill 397 299 221 400 299 221 minecraft:mossy_cobblestone
setblock 398 299 184 minecraft:stone_bricks
fill 398 299 185 398 300 185 minecraft:mossy_cobblestone
setblock 399 299 183 minecraft:stone_bricks
fill 399 299 184 399 300 184 minecraft:mossy_cobblestone
fill 399 299 220 400 300 220 minecraft:mossy_cobblestone
setblock 400 299 182 minecraft:stone_bricks
fill 400 299 183 400 300 183 minecraft:mossy_cobblestone
setblock 400 299 222 minecraft:stone_bricks
fill 401 299 182 401 300 182 minecraft:mossy_cobblestone
setblock 401 299 221 minecraft:stone_bricks
fill 401 299 222 401 300 222 minecraft:mossy_cobblestone
fill 402 299 221 402 300 221 minecraft:mossy_cobblestone
setblock 404 299 183 minecraft:stone_bricks
setblock 405 299 182 minecraft:stone_bricks
setblock 405 299 222 minecraft:stone_bricks
setblock 406 299 182 minecraft:mossy_cobblestone
fill 406 299 222 406 300 222 minecraft:mossy_cobblestone
setblock 414 299 182 minecraft:mossy_cobblestone
setblock 414 299 207 minecraft:mossy_cobblestone
setblock 414 299 208 minecraft:stone_bricks
fill 414 299 209 414 300 209 minecraft:mossy_cobblestone
setblock 415 299 182 minecraft:stone_bricks
fill 415 299 203 415 300 203 minecraft:mossy_cobblestone
setblock 415 299 206 minecraft:mossy_cobblestone
setblock 415 299 207 minecraft:stone_bricks
fill 415 299 208 415 300 208 minecraft:mossy_cobblestone
setblock 415 299 212 minecraft:stone_bricks
fill 415 299 213 415 300 213 minecraft:mossy_cobblestone
setblock 415 299 222 minecraft:stone_bricks
fill 416 299 182 416 299 185 minecraft:mossy_cobblestone
setblock 416 299 186 minecraft:stone_bricks
fill 416 299 187 416 300 187 minecraft:mossy_cobblestone
setblock 416 299 190 minecraft:mossy_cobblestone
setblock 416 299 191 minecraft:stone_bricks
fill 416 299 192 417 300 193 minecraft:mossy_cobblestone
fill 416 299 198 416 300 198 minecraft:mossy_cobblestone
setblock 416 299 201 minecraft:stone_bricks
fill 416 299 202 416 300 202 minecraft:mossy_cobblestone
setblock 416 299 206 minecraft:stone_bricks
fill 416 299 207 416 300 207 minecraft:mossy_cobblestone
setblock 416 299 210 minecraft:mossy_cobblestone
setblock 416 299 211 minecraft:stone_bricks
fill 416 299 212 416 300 212 minecraft:mossy_cobblestone
setblock 416 299 215 minecraft:mossy_cobblestone
fill 416 299 222 416 300 222 minecraft:mossy_cobblestone
setblock 417 299 185 minecraft:stone_bricks
fill 417 299 186 417 300 186 minecraft:mossy_cobblestone
setblock 417 299 190 minecraft:stone_bricks
fill 417 299 191 417 300 191 minecraft:mossy_cobblestone
setblock 417 299 194 minecraft:mossy_cobblestone
setblock 417 299 195 minecraft:stone_bricks
fill 417 299 196 417 300 196 minecraft:mossy_cobblestone
setblock 417 299 200 minecraft:stone_bricks
fill 417 299 201 417 300 201 minecraft:mossy_cobblestone
setblock 417 299 205 minecraft:stone_bricks
fill 417 299 206 417 300 206 minecraft:mossy_cobblestone
setblock 417 299 210 minecraft:stone_bricks
fill 417 299 211 417 300 211 minecraft:mossy_cobblestone
setblock 417 299 214 minecraft:mossy_cobblestone
setblock 417 299 215 minecraft:stone_bricks
fill 417 299 216 417 300 216 minecraft:mossy_cobblestone
setblock 417 299 220 minecraft:stone_bricks
fill 417 299 221 417 300 221 minecraft:mossy_cobblestone
setblock 377 300 184 minecraft:stone_bricks
fill 377 300 185 377 300 188 minecraft:mossy_cobblestone
setblock 377 300 189 minecraft:stone_bricks
setblock 377 300 190 minecraft:mossy_cobblestone
setblock 377 300 194 minecraft:stone_bricks
setblock 377 300 195 minecraft:mossy_cobblestone
setblock 377 300 199 minecraft:stone_bricks
setblock 377 300 200 minecraft:mossy_cobblestone
setblock 377 300 204 minecraft:stone_bricks
setblock 377 300 205 minecraft:mossy_cobblestone
setblock 377 300 209 minecraft:stone_bricks
setblock 377 300 210 minecraft:mossy_cobblestone
setblock 377 300 214 minecraft:stone_bricks
setblock 377 300 215 minecraft:mossy_cobblestone
fill 377 300 217 377 300 218 minecraft:mossy_cobblestone
setblock 377 300 221 minecraft:mossy_cobblestone
setblock 378 300 183 minecraft:stone_bricks
setblock 378 300 184 minecraft:mossy_cobblestone
setblock 378 300 188 minecraft:stone_bricks
setblock 378 300 189 minecraft:mossy_cobblestone
setblock 378 300 193 minecraft:stone_bricks
setblock 378 300 194 minecraft:mossy_cobblestone
setblock 378 300 198 minecraft:stone_bricks
setblock 378 300 199 minecraft:mossy_cobblestone
setblock 378 300 203 minecraft:stone_bricks
setblock 378 300 204 minecraft:mossy_cobblestone
setblock 378 300 208 minecraft:stone_bricks
setblock 378 300 209 minecraft:mossy_cobblestone
setblock 378 300 213 minecraft:stone_bricks
setblock 378 300 214 minecraft:mossy_cobblestone
setblock 379 300 182 minecraft:stone_bricks
fill 379 300 183 382 300 183 minecraft:mossy_cobblestone
setblock 379 300 186 minecraft:mossy_cobblestone
setblock 379 300 187 minecraft:stone_bricks
setblock 379 300 188 minecraft:mossy_cobblestone
setblock 379 300 192 minecraft:stone_bricks
setblock 379 300 193 minecraft:mossy_cobblestone
setblock 379 300 197 minecraft:stone_bricks
setblock 379 300 202 minecraft:stone_bricks
setblock 379 300 203 minecraft:mossy_cobblestone
setblock 379 300 207 minecraft:stone_bricks
setblock 379 300 208 minecraft:mossy_cobblestone
setblock 379 300 222 minecraft:stone_bricks
fill 380 300 182 383 300 182 minecraft:mossy_cobblestone
setblock 380 300 185 minecraft:mossy_cobblestone
setblock 380 300 186 minecraft:stone_bricks
setblock 380 300 187 minecraft:mossy_cobblestone
setblock 380 300 191 minecraft:stone_bricks
setblock 380 300 192 minecraft:mossy_cobblestone
setblock 380 300 222 minecraft:mossy_cobblestone
setblock 381 300 185 minecraft:stone_bricks
setblock 382 300 184 minecraft:stone_bricks
setblock 382 300 185 minecraft:mossy_cobblestone
setblock 383 300 183 minecraft:stone_bricks
setblock 383 300 184 minecraft:mossy_cobblestone
setblock 384 300 182 minecraft:stone_bricks
fill 384 300 183 387 300 183 minecraft:mossy_cobblestone
fill 385 300 182 388 300 182 minecraft:mossy_cobblestone
setblock 388 300 183 minecraft:stone_bricks
setblock 389 300 182 minecraft:stone_bricks
fill 389 300 183 392 300 183 minecraft:mossy_cobblestone
fill 390 300 182 393 300 182 minecraft:mossy_cobblestone
setblock 391 300 184 minecraft:mossy_cobblestone
fill 391 300 222 393 300 222 minecraft:mossy_cobblestone
setblock 392 300 184 minecraft:stone_bricks
setblock 393 300 183 minecraft:stone_bricks
setblock 393 300 184 minecraft:mossy_cobblestone
setblock 394 300 182 minecraft:stone_bricks
setblock 394 300 183 minecraft:mossy_cobblestone
setblock 394 300 221 minecraft:mossy_cobblestone
setblock 394 300 222 minecraft:stone_bricks
setblock 395 300 182 minecraft:mossy_cobblestone
setblock 395 300 185 minecraft:mossy_cobblestone
setblock 395 300 221 minecraft:stone_bricks
fill 395 300 222 398 300 222 minecraft:mossy_cobblestone
setblock 396 300 185 minecraft:stone_bricks
fill 396 300 221 399 300 221 minecraft:mossy_cobblestone
setblock 397 300 184 minecraft:stone_bricks
setblock 397 300 185 minecraft:mossy_cobblestone
setblock 398 300 183 minecraft:stone_bricks
setblock 398 300 184 minecraft:mossy_cobblestone
setblock 398 300 220 minecraft:mossy_cobblestone
setblock 399 300 182 minecraft:stone_bricks
setblock 399 300 183 minecraft:mossy_cobblestone
setblock 399 300 185 minecraft:mossy_cobblestone
setblock 399 300 222 minecraft:stone_bricks
setblock 400 300 182 minecraft:mossy_cobblestone
setblock 400 300 221 minecraft:stone_bricks
setblock 400 300 222 minecraft:mossy_cobblestone
setblock 401 300 221 minecraft:mossy_cobblestone
setblock 402 300 184 minecraft:stone_bricks
setblock 403 300 183 minecraft:stone_bricks
setblock 404 300 182 minecraft:stone_bricks
setblock 404 300 183 minecraft:mossy_cobblestone
setblock 404 300 222 minecraft:stone_bricks
setblock 405 300 182 minecraft:mossy_cobblestone
setblock 405 300 222 minecraft:mossy_cobblestone
setblock 414 300 182 minecraft:stone_bricks
setblock 414 300 206 minecraft:mossy_cobblestone
setblock 414 300 207 minecraft:stone_bricks
setblock 414 300 208 minecraft:mossy_cobblestone
fill 414 300 210 414 300 211 minecraft:mossy_cobblestone
fill 415 300 182 416 300 182 minecraft:mossy_cobblestone
setblock 415 300 202 minecraft:mossy_cobblestone
setblock 415 300 206 minecraft:stone_bricks
setblock 415 300 207 minecraft:mossy_cobblestone
setblock 415 300 211 minecraft:stone_bricks
setblock 415 300 212 minecraft:mossy_cobblestone
setblock 415 300 214 minecraft:mossy_cobblestone
setblock 415 300 222 minecraft:mossy_cobblestone
fill 416 300 183 416 300 184 minecraft:mossy_cobblestone
setblock 416 300 185 minecraft:stone_bricks
setblock 416 300 186 minecraft:mossy_cobblestone
setblock 416 300 190 minecraft:stone_bricks
setblock 416 300 191 minecraft:mossy_cobblestone
setblock 416 300 194 minecraft:mossy_cobblestone
setblock 416 300 195 minecraft:stone_bricks
fill 416 300 196 416 300 197 minecraft:mossy_cobblestone
setblock 416 300 200 minecraft:stone_bricks
setblock 416 300 201 minecraft:mossy_cobblestone
setblock 416 300 205 minecraft:stone_bricks
setblock 416 300 206 minecraft:mossy_cobblestone
setblock 416 300 210 minecraft:stone_bricks
setblock 416 300 211 minecraft:mossy_cobblestone
setblock 416 300 215 minecraft:stone_bricks
setblock 416 300 216 minecraft:mossy_cobblestone
setblock 417 300 184 minecraft:stone_bricks
setblock 417 300 185 minecraft:mossy_cobblestone
setblock 417 300 189 minecraft:stone_bricks
setblock 417 300 190 minecraft:mossy_cobblestone
setblock 417 300 194 minecraft:stone_bricks
setblock 417 300 195 minecraft:mossy_cobblestone
setblock 417 300 199 minecraft:stone_bricks
setblock 417 300 200 minecraft:mossy_cobblestone
setblock 417 300 204 minecraft:stone_bricks
setblock 417 300 205 minecraft:mossy_cobblestone
setblock 417 300 209 minecraft:stone_bricks
setblock 417 300 210 minecraft:mossy_cobblestone
setblock 417 300 214 minecraft:stone_bricks
setblock 417 300 215 minecraft:mossy_cobblestone
fill 417 300 217 417 300 218 minecraft:mossy_cobblestone
setblock 417 300 219 minecraft:stone_bricks
setblock 417 300 220 minecraft:mossy_cobblestone
