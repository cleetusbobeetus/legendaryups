setblock 489 33 276 minecraft:white_wool
setblock 490 33 276 minecraft:cobbled_deepslate
fill 490 33 277 492 34 277 minecraft:white_wool
fill 491 33 276 491 35 276 minecraft:deepslate_tiles
setblock 493 33 277 minecraft:deepslate_tiles
setblock 494 33 277 minecraft:cobbled_deepslate
setblock 495 33 276 minecraft:cobbled_deepslate
fill 495 33 277 498 33 277 minecraft:deepslate_tiles
setblock 495 33 316 minecraft:cobbled_deepslate
fill 496 33 276 496 36 276 minecraft:deepslate_tiles
fill 496 33 278 497 33 278 minecraft:deepslate_tiles
fill 496 33 316 496 36 316 minecraft:deepslate_tiles
setblock 497 33 315 minecraft:deepslate_tiles
setblock 498 33 278 minecraft:cobbled_deepslate
fill 498 33 279 498 35 279 minecraft:deepslate_tiles
setblock 499 33 277 minecraft:cobbled_deepslate
fill 499 33 278 499 36 278 minecraft:deepslate_tiles
setblock 500 33 276 minecraft:cobbled_deepslate
fill 500 33 277 500 36 277 minecraft:deepslate_tiles
setblock 500 33 316 minecraft:cobbled_deepslate
fill 501 33 276 501 36 276 minecraft:deepslate_tiles
setblock 501 33 315 minecraft:cobbled_deepslate
fill 501 33 316 501 35 316 minecraft:deepslate_tiles
setblock 502 33 279 minecraft:cobbled_deepslate
setblock 503 33 278 minecraft:cobbled_deepslate
setblock 504 33 277 minecraft:cobbled_deepslate
fill 504 33 278 504 35 278 minecraft:deepslate_tiles
setblock 505 33 276 minecraft:cobbled_deepslate
fill 505 33 277 505 36 277 minecraft:deepslate_tiles
setblock 505 33 316 minecraft:cobbled_deepslate
fill 506 33 276 506 36 276 minecraft:deepslate_tiles
fill 506 33 316 506 34 316 minecraft:deepslate_tiles
setblock 508 33 278 minecraft:cobbled_deepslate
setblock 509 33 277 minecraft:cobbled_deepslate
setblock 510 33 276 minecraft:cobbled_deepslate
fill 510 33 277 510 36 277 minecraft:deepslate_tiles
setblock 510 33 281 minecraft:cobbled_deepslate
setblock 510 33 316 minecraft:cobbled_deepslate
fill 511 33 276 511 36 276 minecraft:deepslate_tiles
setblock 511 33 280 minecraft:cobbled_deepslate
fill 511 33 281 511 36 281 minecraft:deepslate_tiles
setblock 511 33 295 minecraft:cobbled_deepslate
setblock 511 33 296 minecraft:deepslate_tiles
setblock 511 33 315 minecraft:cobbled_deepslate
fill 511 33 316 511 36 316 minecraft:deepslate_tiles
setblock 471 34 279 minecraft:cobbled_deepslate
fill 471 34 280 471 37 280 minecraft:deepslate_tiles
setblock 471 34 298 minecraft:deepslate_tiles
setblock 471 34 299 minecraft:cobbled_deepslate
fill 471 34 300 472 36 300 minecraft:deepslate_tiles
setblock 471 34 304 minecraft:cobbled_deepslate
fill 471 34 305 471 37 305 minecraft:deepslate_tiles
setblock 471 34 314 minecraft:cobbled_deepslate
fill 471 34 315 471 37 315 minecraft:deepslate_tiles
setblock 472 34 278 minecraft:cobbled_deepslate
fill 472 34 279 472 37 279 minecraft:deepslate_tiles
fill 472 34 301 472 35 301 minecraft:deepslate_tiles
setblock 472 34 314 minecraft:deepslate_tiles
setblock 473 34 277 minecraft:cobbled_deepslate
setblock 474 34 276 minecraft:cobbled_deepslate
fill 474 34 277 474 34 278 minecraft:deepslate_tiles
setblock 474 34 316 minecraft:cobbled_deepslate
fill 475 34 275 475 35 275 minecraft:cobbled_deepslate
fill 475 34 276 475 37 276 minecraft:deepslate_tiles
fill 475 34 278 476 34 278 minecraft:deepslate_tiles
setblock 475 34 315 minecraft:cobbled_deepslate
fill 475 34 316 475 37 316 minecraft:deepslate_tiles
setblock 476 34 314 minecraft:cobbled_deepslate
fill 476 34 315 476 37 315 minecraft:deepslate_tiles
setblock 477 34 278 minecraft:cobbled_deepslate
fill 477 34 314 477 35 314 minecraft:deepslate_tiles
setblock 478 34 277 minecraft:cobbled_deepslate
fill 478 34 278 478 35 278 minecraft:deepslate_tiles
setblock 479 34 276 minecraft:cobbled_deepslate
fill 479 34 277 479 36 277 minecraft:deepslate_tiles
setblock 479 34 316 minecraft:cobbled_deepslate
fill 480 34 276 480 37 276 minecraft:deepslate_tiles
setblock 480 34 315 minecraft:cobbled_deepslate
fill 480 34 316 480 37 316 minecraft:deepslate_tiles
fill 481 34 275 481 91 275 minecraft:cobbled_deepslate
fill 481 34 315 481 35 315 minecraft:deepslate_tiles
setblock 484 34 276 minecraft:cobbled_deepslate
setblock 484 34 316 minecraft:cobbled_deepslate
setblock 485 34 276 minecraft:deepslate_tiles
setblock 485 34 316 minecraft:deepslate_tiles
setblock 490 34 283 minecraft:white_wool
fill 491 34 283 492 37 284 minecraft:white_terracotta
setblock 493 34 277 minecraft:cobbled_deepslate
setblock 493 34 283 minecraft:white_wool
setblock 494 34 276 minecraft:cobbled_deepslate
fill 494 34 277 497 34 277 minecraft:deepslate_tiles
setblock 494 34 316 minecraft:cobbled_deepslate
fill 495 34 276 495 37 276 minecraft:deepslate_tiles
fill 495 34 278 496 34 278 minecraft:deepslate_tiles
fill 495 34 316 495 35 316 minecraft:deepslate_tiles
setblock 497 34 278 minecraft:cobbled_deepslate
setblock 498 34 277 minecraft:cobbled_deepslate
fill 498 34 278 498 37 278 minecraft:deepslate_tiles
setblock 499 34 276 minecraft:cobbled_deepslate
fill 499 34 277 499 37 277 minecraft:deepslate_tiles
setblock 499 34 316 minecraft:cobbled_deepslate
fill 500 34 276 500 37 276 minecraft:deepslate_tiles
fill 500 34 316 500 36 316 minecraft:deepslate_tiles
setblock 501 34 278 minecraft:deepslate_tiles
setblock 501 34 279 minecraft:cobbled_deepslate
setblock 502 34 278 minecraft:cobbled_deepslate
setblock 503 34 277 minecraft:cobbled_deepslate
fill 503 34 278 503 36 278 minecraft:deepslate_tiles
setblock 504 34 276 minecraft:cobbled_deepslate
fill 504 34 277 504 37 277 minecraft:deepslate_tiles
setblock 504 34 316 minecraft:cobbled_deepslate
fill 505 34 276 505 37 276 minecraft:deepslate_tiles
setblock 505 34 316 minecraft:deepslate_tiles
setblock 506 34 278 minecraft:deepslate_tiles
setblock 508 34 277 minecraft:cobbled_deepslate
setblock 509 34 276 minecraft:cobbled_deepslate
fill 509 34 277 509 37 277 minecraft:deepslate_tiles
setblock 509 34 316 minecraft:cobbled_deepslate
fill 510 34 276 510 37 276 minecraft:deepslate_tiles
setblock 510 34 280 minecraft:cobbled_deepslate
fill 510 34 281 510 37 281 minecraft:deepslate_tiles
fill 510 34 316 510 35 316 minecraft:deepslate_tiles
setblock 511 34 279 minecraft:cobbled_deepslate
fill 511 34 280 511 37 280 minecraft:deepslate_tiles
setblock 511 34 284 minecraft:cobbled_deepslate
setblock 511 34 299 minecraft:cobbled_deepslate
fill 511 34 315 511 35 315 minecraft:deepslate_tiles
fill 470 35 288 470 94 290 minecraft:cobbled_deepslate
setblock 470 35 291 minecraft:white_wool
fill 470 35 292 470 44 294 minecraft:cobbled_deepslate
fill 470 35 308 470 90 308 minecraft:cobbled_deepslate
setblock 470 35 309 minecraft:white_wool
fill 470 35 310 470 90 312 minecraft:cobbled_deepslate
setblock 471 35 278 minecraft:cobbled_deepslate
fill 471 35 279 471 38 279 minecraft:deepslate_tiles
setblock 471 35 298 minecraft:cobbled_deepslate
fill 471 35 299 472 35 299 minecraft:deepslate_tiles
fill 471 35 301 471 35 302 minecraft:deepslate_tiles
setblock 471 35 303 minecraft:cobbled_deepslate
fill 471 35 304 471 38 304 minecraft:deepslate_tiles
fill 471 35 306 471 36 306 minecraft:deepslate_tiles
setblock 471 35 313 minecraft:cobbled_deepslate
fill 471 35 314 471 38 314 minecraft:deepslate_tiles
setblock 472 35 277 minecraft:cobbled_deepslate
fill 472 35 278 472 38 278 minecraft:deepslate_tiles
setblock 472 35 302 minecraft:cobbled_deepslate
fill 472 35 303 472 38 303 minecraft:deepslate_tiles
setblock 473 35 276 minecraft:cobbled_deepslate
fill 473 35 277 474 37 277 minecraft:deepslate_tiles
setblock 473 35 316 minecraft:cobbled_deepslate
fill 474 35 276 474 38 276 minecraft:deepslate_tiles
setblock 474 35 315 minecraft:cobbled_deepslate
fill 474 35 316 474 38 316 minecraft:deepslate_tiles
setblock 475 35 278 minecraft:deepslate_tiles
fill 475 35 315 475 38 315 minecraft:deepslate_tiles
setblock 476 35 278 minecraft:cobbled_deepslate
setblock 477 35 277 minecraft:cobbled_deepslate
setblock 477 35 278 minecraft:deepslate_tiles
setblock 478 35 276 minecraft:cobbled_deepslate
fill 478 35 277 478 37 277 minecraft:deepslate_tiles
setblock 478 35 316 minecraft:cobbled_deepslate
fill 479 35 276 479 38 276 minecraft:deepslate_tiles
setblock 479 35 315 minecraft:cobbled_deepslate
fill 479 35 316 479 38 316 minecraft:deepslate_tiles
setblock 480 35 315 minecraft:deepslate_tiles
setblock 483 35 276 minecraft:cobbled_deepslate
setblock 483 35 316 minecraft:cobbled_deepslate
setblock 493 35 276 minecraft:cobbled_deepslate
fill 493 35 277 496 35 277 minecraft:deepslate_tiles
fill 494 35 276 494 38 276 minecraft:deepslate_tiles
setblock 495 35 278 minecraft:deepslate_tiles
setblock 496 35 278 minecraft:cobbled_deepslate
setblock 497 35 277 minecraft:cobbled_deepslate
fill 497 35 278 497 38 278 minecraft:deepslate_tiles
setblock 498 35 276 minecraft:cobbled_deepslate
fill 498 35 277 498 38 277 minecraft:deepslate_tiles
setblock 498 35 316 minecraft:cobbled_deepslate
fill 499 35 276 499 38 276 minecraft:deepslate_tiles
setblock 499 35 279 minecraft:deepslate_tiles
fill 499 35 316 499 36 316 minecraft:deepslate_tiles
setblock 500 35 279 minecraft:cobbled_deepslate
setblock 501 35 278 minecraft:cobbled_deepslate
setblock 502 35 277 minecraft:cobbled_deepslate
fill 502 35 278 502 36 278 minecraft:deepslate_tiles
setblock 503 35 276 minecraft:cobbled_deepslate
fill 503 35 277 503 38 277 minecraft:deepslate_tiles
fill 504 35 276 504 38 276 minecraft:deepslate_tiles
setblock 507 35 277 minecraft:cobbled_deepslate
setblock 508 35 276 minecraft:cobbled_deepslate
fill 508 35 277 508 37 277 minecraft:deepslate_tiles
fill 509 35 276 509 38 276 minecraft:deepslate_tiles
setblock 510 35 279 minecraft:cobbled_deepslate
fill 510 35 280 510 38 280 minecraft:deepslate_tiles
setblock 511 35 278 minecraft:cobbled_deepslate
fill 511 35 279 511 38 279 minecraft:deepslate_tiles
setblock 511 35 283 minecraft:cobbled_deepslate
fill 511 35 284 511 38 284 minecraft:deepslate_tiles
fill 470 36 291 470 94 291 minecraft:cobbled_deepslate
fill 470 36 309 470 69 309 minecraft:cobbled_deepslate
setblock 471 36 277 minecraft:cobbled_deepslate
fill 471 36 278 471 39 278 minecraft:deepslate_tiles
setblock 471 36 281 minecraft:deepslate_tiles
setblock 471 36 282 minecraft:cobbled_deepslate
fill 471 36 298 471 38 299 minecraft:deepslate_tiles
setblock 471 36 301 minecraft:deepslate_tiles
setblock 471 36 302 minecraft:cobbled_deepslate
fill 471 36 303 471 39 303 minecraft:deepslate_tiles
setblock 471 36 307 minecraft:cobbled_deepslate
fill 471 36 308 471 39 308 minecraft:deepslate_tiles
setblock 471 36 312 minecraft:cobbled_deepslate
fill 471 36 313 471 39 313 minecraft:deepslate_tiles
setblock 472 36 276 minecraft:cobbled_deepslate
fill 472 36 277 472 38 277 minecraft:deepslate_tiles
setblock 472 36 301 minecraft:cobbled_deepslate
fill 472 36 302 472 39 302 minecraft:deepslate_tiles
fill 472 36 304 472 36 305 minecraft:deepslate_tiles
setblock 472 36 316 minecraft:cobbled_deepslate
fill 473 36 276 473 39 276 minecraft:deepslate_tiles
setblock 473 36 315 minecraft:cobbled_deepslate
fill 473 36 316 473 39 316 minecraft:deepslate_tiles
fill 474 36 315 474 38 315 minecraft:deepslate_tiles
setblock 475 36 275 minecraft:white_wool
setblock 476 36 277 minecraft:cobbled_deepslate
setblock 477 36 276 minecraft:cobbled_deepslate
fill 477 36 277 477 38 277 minecraft:deepslate_tiles
setblock 477 36 316 minecraft:cobbled_deepslate
fill 478 36 276 478 39 276 minecraft:deepslate_tiles
setblock 478 36 315 minecraft:cobbled_deepslate
fill 478 36 316 478 39 316 minecraft:deepslate_tiles
setblock 479 36 315 minecraft:deepslate_tiles
setblock 482 36 276 minecraft:cobbled_deepslate
setblock 482 36 316 minecraft:cobbled_deepslate
setblock 492 36 276 minecraft:cobbled_deepslate
fill 493 36 276 493 38 277 minecraft:deepslate_tiles
fill 494 36 277 495 36 277 minecraft:deepslate_tiles
setblock 495 36 278 minecraft:cobbled_deepslate
setblock 496 36 277 minecraft:cobbled_deepslate
fill 496 36 278 496 39 278 minecraft:deepslate_tiles
setblock 497 36 276 minecraft:cobbled_deepslate
fill 497 36 277 497 39 277 minecraft:deepslate_tiles
setblock 497 36 316 minecraft:cobbled_deepslate
fill 498 36 276 498 39 276 minecraft:deepslate_tiles
setblock 498 36 316 minecraft:deepslate_tiles
setblock 500 36 278 minecraft:cobbled_deepslate
setblock 501 36 277 minecraft:cobbled_deepslate
fill 501 36 278 501 37 278 minecraft:deepslate_tiles
setblock 502 36 276 minecraft:cobbled_deepslate
fill 502 36 277 502 38 277 minecraft:deepslate_tiles
fill 503 36 276 503 39 276 minecraft:deepslate_tiles
setblock 506 36 277 minecraft:cobbled_deepslate
setblock 507 36 276 minecraft:cobbled_deepslate
setblock 507 36 277 minecraft:deepslate_tiles
fill 508 36 276 508 39 276 minecraft:deepslate_tiles
setblock 510 36 278 minecraft:cobbled_deepslate
fill 510 36 279 510 39 279 minecraft:deepslate_tiles
setblock 510 36 282 minecraft:deepslate_tiles
setblock 511 36 277 minecraft:cobbled_deepslate
fill 511 36 278 511 39 278 minecraft:deepslate_tiles
setblock 511 36 282 minecraft:cobbled_deepslate
fill 511 36 283 511 39 283 minecraft:deepslate_tiles
setblock 470 37 307 minecraft:white_wool
setblock 471 37 276 minecraft:cobbled_deepslate
fill 471 37 277 471 40 277 minecraft:deepslate_tiles
setblock 471 37 281 minecraft:cobbled_deepslate
fill 471 37 282 471 40 282 minecraft:deepslate_tiles
setblock 471 37 300 minecraft:deepslate_tiles
setblock 471 37 301 minecraft:cobbled_deepslate
fill 471 37 302 471 40 302 minecraft:deepslate_tiles
setblock 471 37 306 minecraft:cobbled_deepslate
fill 471 37 307 471 40 307 minecraft:deepslate_tiles
fill 471 37 309 471 37 310 minecraft:deepslate_tiles
fill 471 37 312 471 40 312 minecraft:deepslate_tiles
setblock 471 37 316 minecraft:cobbled_deepslate
fill 472 37 276 472 40 276 minecraft:deepslate_tiles
setblock 472 37 280 minecraft:cobbled_deepslate
setblock 472 37 300 minecraft:cobbled_deepslate
fill 472 37 301 472 40 301 minecraft:deepslate_tiles
setblock 472 37 304 minecraft:deepslate_tiles
setblock 472 37 305 minecraft:cobbled_deepslate
fill 472 37 306 472 40 306 minecraft:deepslate_tiles
fill 472 37 316 472 40 316 minecraft:deepslate_tiles
setblock 473 37 278 minecraft:light[level=13]
setblock 473 37 285 minecraft:light[level=12]
setblock 473 37 286 minecraft:light[level=13]
setblock 473 37 292 minecraft:light[level=12]
setblock 473 37 294 minecraft:light[level=13]
setblock 473 37 299 minecraft:light[level=12]
fill 473 37 302 473 37 303 minecraft:deepslate_tiles
setblock 473 37 306 minecraft:light[level=12]
setblock 473 37 310 minecraft:light[level=13]
setblock 473 37 313 minecraft:light[level=12]
setblock 473 37 315 minecraft:deepslate_tiles
fill 475 37 275 475 94 275 minecraft:cobbled_deepslate
setblock 475 37 277 minecraft:cobbled_deepslate
setblock 476 37 276 minecraft:cobbled_deepslate
fill 476 37 277 476 38 277 minecraft:deepslate_tiles
setblock 476 37 316 minecraft:cobbled_deepslate
fill 477 37 276 477 40 276 minecraft:deepslate_tiles
setblock 477 37 315 minecraft:cobbled_deepslate
fill 477 37 316 477 40 316 minecraft:deepslate_tiles
setblock 478 37 315 minecraft:deepslate_tiles
setblock 480 37 278 minecraft:light[level=12]
setblock 480 37 285 minecraft:light[level=12]
setblock 480 37 292 minecraft:light[level=12]
setblock 480 37 299 minecraft:light[level=12]
setblock 480 37 306 minecraft:light[level=12]
setblock 480 37 313 minecraft:light[level=12]
setblock 481 37 278 minecraft:light[level=13]
setblock 481 37 286 minecraft:light[level=13]
setblock 481 37 294 minecraft:light[level=13]
setblock 481 37 302 minecraft:light[level=13]
setblock 481 37 310 minecraft:light[level=13]
setblock 487 37 278 minecraft:light[level=12]
setblock 487 37 285 minecraft:light[level=12]
setblock 487 37 292 minecraft:light[level=12]
setblock 487 37 299 minecraft:light[level=12]
setblock 487 37 306 minecraft:light[level=12]
setblock 487 37 313 minecraft:light[level=12]
setblock 489 37 278 minecraft:light[level=13]
setblock 489 37 286 minecraft:light[level=13]
setblock 489 37 294 minecraft:light[level=13]
setblock 489 37 302 minecraft:light[level=13]
setblock 489 37 310 minecraft:light[level=13]
fill 492 37 276 492 40 276 minecraft:deepslate_tiles
fill 493 37 317 494 94 317 minecraft:cobbled_deepslate
setblock 494 37 277 minecraft:deepslate_tiles
setblock 494 37 278 minecraft:light[level=12]
setblock 494 37 285 minecraft:light[level=12]
setblock 494 37 292 minecraft:light[level=12]
setblock 494 37 299 minecraft:light[level=12]
setblock 494 37 306 minecraft:light[level=12]
setblock 494 37 313 minecraft:light[level=12]
setblock 495 37 277 minecraft:cobbled_deepslate
fill 495 37 278 495 40 278 minecraft:deepslate_tiles
setblock 495 37 317 minecraft:redstone_block
setblock 496 37 276 minecraft:cobbled_deepslate
fill 496 37 277 496 40 277 minecraft:deepslate_tiles
fill 496 37 317 497 94 317 minecraft:cobbled_deepslate
fill 497 37 276 497 40 276 minecraft:deepslate_tiles
setblock 497 37 286 minecraft:light[level=13]
setblock 497 37 294 minecraft:light[level=13]
setblock 497 37 302 minecraft:light[level=13]
setblock 497 37 310 minecraft:light[level=13]
setblock 499 37 278 minecraft:cobbled_deepslate
setblock 500 37 277 minecraft:cobbled_deepslate
fill 500 37 278 500 38 278 minecraft:deepslate_tiles
setblock 501 37 276 minecraft:cobbled_deepslate
fill 501 37 277 501 39 277 minecraft:deepslate_tiles
setblock 501 37 285 minecraft:light[level=12]
setblock 501 37 292 minecraft:light[level=12]
setblock 501 37 299 minecraft:light[level=12]
setblock 501 37 306 minecraft:light[level=12]
setblock 501 37 313 minecraft:light[level=12]
fill 502 37 276 502 40 276 minecraft:deepslate_tiles
setblock 505 37 277 minecraft:cobbled_deepslate
setblock 505 37 278 minecraft:light[level=13]
setblock 505 37 286 minecraft:light[level=13]
setblock 505 37 294 minecraft:light[level=13]
setblock 505 37 302 minecraft:light[level=13]
setblock 505 37 310 minecraft:light[level=13]
setblock 506 37 276 minecraft:cobbled_deepslate
fill 507 37 276 507 40 276 minecraft:deepslate_tiles
setblock 508 37 278 minecraft:light[level=12]
setblock 508 37 285 minecraft:light[level=12]
setblock 508 37 292 minecraft:light[level=12]
setblock 508 37 299 minecraft:light[level=12]
setblock 508 37 306 minecraft:light[level=12]
setblock 508 37 313 minecraft:light[level=12]
setblock 510 37 277 minecraft:cobbled_deepslate
fill 510 37 278 510 40 278 minecraft:deepslate_tiles
setblock 510 37 282 minecraft:cobbled_deepslate
setblock 511 37 276 minecraft:cobbled_deepslate
fill 511 37 277 511 40 277 minecraft:deepslate_tiles
setblock 511 37 281 minecraft:cobbled_deepslate
fill 511 37 282 511 40 282 minecraft:deepslate_tiles
setblock 511 37 285 minecraft:deepslate_tiles
setblock 511 37 316 minecraft:cobbled_deepslate
fill 470 38 307 470 94 307 minecraft:cobbled_deepslate
fill 471 38 276 471 41 276 minecraft:deepslate_tiles
setblock 471 38 280 minecraft:cobbled_deepslate
fill 471 38 281 471 41 281 minecraft:deepslate_tiles
fill 471 38 283 471 39 283 minecraft:deepslate_tiles
setblock 471 38 300 minecraft:cobbled_deepslate
fill 471 38 301 471 41 301 minecraft:deepslate_tiles
setblock 471 38 305 minecraft:cobbled_deepslate
fill 471 38 306 471 41 306 minecraft:deepslate_tiles
setblock 471 38 309 minecraft:deepslate_tiles
setblock 471 38 310 minecraft:cobbled_deepslate
fill 471 38 311 471 41 311 minecraft:deepslate_tiles
setblock 471 38 315 minecraft:cobbled_deepslate
fill 471 38 316 471 41 316 minecraft:deepslate_tiles
setblock 472 38 279 minecraft:cobbled_deepslate
fill 472 38 280 472 41 280 minecraft:deepslate_tiles
setblock 472 38 299 minecraft:cobbled_deepslate
fill 472 38 300 472 41 300 minecraft:deepslate_tiles
setblock 472 38 304 minecraft:cobbled_deepslate
fill 472 38 305 473 40 305 minecraft:deepslate_tiles
fill 472 38 307 472 38 308 minecraft:deepslate_tiles
setblock 473 38 277 minecraft:deepslate_tiles
fill 473 38 301 473 38 302 minecraft:deepslate_tiles
setblock 473 38 303 minecraft:cobbled_deepslate
fill 473 38 304 473 41 304 minecraft:deepslate_tiles
setblock 474 38 277 minecraft:cobbled_deepslate
setblock 475 38 276 minecraft:cobbled_deepslate
fill 475 38 277 475 39 277 minecraft:deepslate_tiles
setblock 475 38 316 minecraft:cobbled_deepslate
fill 476 38 276 476 41 276 minecraft:deepslate_tiles
setblock 476 38 315 minecraft:cobbled_deepslate
fill 476 38 316 476 41 316 minecraft:deepslate_tiles
setblock 494 38 277 minecraft:cobbled_deepslate
setblock 495 38 276 minecraft:cobbled_deepslate
fill 495 38 277 495 41 277 minecraft:deepslate_tiles
fill 495 38 317 495 94 317 minecraft:cobbled_deepslate
fill 496 38 276 496 41 276 minecraft:deepslate_tiles
setblock 498 38 278 minecraft:cobbled_deepslate
setblock 499 38 277 minecraft:cobbled_deepslate
fill 499 38 278 499 39 278 minecraft:deepslate_tiles
fill 499 38 317 504 54 317 minecraft:cobbled_deepslate
setblock 500 38 276 minecraft:cobbled_deepslate
fill 500 38 277 500 41 277 minecraft:deepslate_tiles
fill 501 38 276 501 41 276 minecraft:deepslate_tiles
setblock 505 38 276 minecraft:cobbled_deepslate
setblock 505 38 317 minecraft:white_wool
fill 506 38 276 506 41 276 minecraft:deepslate_tiles
fill 507 38 279 507 50 279 minecraft:white_wool
setblock 509 38 277 minecraft:cobbled_deepslate
setblock 510 38 276 minecraft:cobbled_deepslate
fill 510 38 277 510 41 277 minecraft:deepslate_tiles
setblock 510 38 281 minecraft:cobbled_deepslate
fill 510 38 282 510 41 282 minecraft:deepslate_tiles
fill 511 38 276 511 41 276 minecraft:deepslate_tiles
setblock 511 38 280 minecraft:cobbled_deepslate
fill 511 38 281 511 41 281 minecraft:deepslate_tiles
setblock 511 38 285 minecraft:cobbled_deepslate
fill 511 38 301 511 38 304 minecraft:deepslate_tiles
fill 511 38 316 511 41 316 minecraft:deepslate_tiles
setblock 471 39 279 minecraft:cobbled_deepslate
fill 471 39 280 471 42 280 minecraft:deepslate_tiles
setblock 471 39 284 minecraft:cobbled_deepslate
setblock 471 39 298 minecraft:deepslate_tiles
setblock 471 39 299 minecraft:cobbled_deepslate
fill 471 39 300 471 42 300 minecraft:deepslate_tiles
setblock 471 39 304 minecraft:cobbled_deepslate
fill 471 39 305 471 42 305 minecraft:deepslate_tiles
setblock 471 39 309 minecraft:cobbled_deepslate
fill 471 39 310 472 41 310 minecraft:deepslate_tiles
setblock 471 39 314 minecraft:cobbled_deepslate
fill 471 39 315 471 42 315 minecraft:deepslate_tiles
setblock 472 39 278 minecraft:cobbled_deepslate
fill 472 39 279 472 42 279 minecraft:deepslate_tiles
fill 472 39 281 472 40 281 minecraft:deepslate_tiles
fill 472 39 299 472 42 299 minecraft:deepslate_tiles
setblock 472 39 303 minecraft:cobbled_deepslate
fill 472 39 304 472 42 304 minecraft:deepslate_tiles
setblock 472 39 307 minecraft:deepslate_tiles
setblock 472 39 308 minecraft:cobbled_deepslate
fill 472 39 309 472 42 309 minecraft:deepslate_tiles
setblock 473 39 277 minecraft:cobbled_deepslate
setblock 473 39 301 minecraft:deepslate_tiles
setblock 473 39 302 minecraft:cobbled_deepslate
fill 473 39 303 473 42 303 minecraft:deepslate_tiles
setblock 473 39 306 minecraft:deepslate_tiles
setblock 473 39 307 minecraft:cobbled_deepslate
setblock 474 39 276 minecraft:cobbled_deepslate
setblock 474 39 277 minecraft:deepslate_tiles
setblock 474 39 316 minecraft:cobbled_deepslate
fill 475 39 276 475 42 276 minecraft:deepslate_tiles
fill 475 39 316 475 42 316 minecraft:deepslate_tiles
setblock 493 39 276 minecraft:deepslate_tiles
setblock 493 39 277 minecraft:cobbled_deepslate
setblock 494 39 276 minecraft:cobbled_deepslate
fill 494 39 277 494 42 277 minecraft:deepslate_tiles
fill 495 39 276 495 42 276 minecraft:deepslate_tiles
setblock 497 39 278 minecraft:cobbled_deepslate
setblock 498 39 277 minecraft:cobbled_deepslate
fill 498 39 278 498 40 278 minecraft:deepslate_tiles
setblock 499 39 276 minecraft:cobbled_deepslate
fill 499 39 277 499 42 277 minecraft:deepslate_tiles
fill 500 39 276 500 42 276 minecraft:deepslate_tiles
setblock 504 39 276 minecraft:cobbled_deepslate
fill 505 39 276 505 42 276 minecraft:deepslate_tiles
fill 505 39 317 505 92 317 minecraft:cobbled_deepslate
setblock 509 39 276 minecraft:cobbled_deepslate
fill 509 39 277 509 42 277 minecraft:deepslate_tiles
fill 510 39 276 510 42 276 minecraft:deepslate_tiles
setblock 510 39 280 minecraft:cobbled_deepslate
fill 510 39 281 510 42 281 minecraft:deepslate_tiles
fill 510 39 283 510 40 283 minecraft:deepslate_tiles
setblock 511 39 279 minecraft:cobbled_deepslate
fill 511 39 280 511 42 280 minecraft:deepslate_tiles
setblock 511 39 284 minecraft:cobbled_deepslate
fill 511 39 285 511 41 286 minecraft:deepslate_tiles
fill 511 39 301 511 39 303 minecraft:deepslate_tiles
setblock 511 39 304 minecraft:cobbled_deepslate
fill 511 39 305 511 40 307 minecraft:deepslate_tiles
setblock 471 40 278 minecraft:cobbled_deepslate
fill 471 40 279 471 43 279 minecraft:deepslate_tiles
setblock 471 40 283 minecraft:cobbled_deepslate
fill 471 40 284 471 42 285 minecraft:deepslate_tiles
setblock 471 40 298 minecraft:cobbled_deepslate
fill 471 40 299 471 43 299 minecraft:deepslate_tiles
setblock 471 40 303 minecraft:cobbled_deepslate
fill 471 40 304 471 43 304 minecraft:deepslate_tiles
setblock 471 40 308 minecraft:cobbled_deepslate
fill 471 40 309 471 43 309 minecraft:deepslate_tiles
setblock 471 40 313 minecraft:cobbled_deepslate
fill 471 40 314 471 43 314 minecraft:deepslate_tiles
fill 472 40 278 472 43 278 minecraft:deepslate_tiles
setblock 472 40 282 minecraft:cobbled_deepslate
setblock 472 40 302 minecraft:cobbled_deepslate
fill 472 40 303 472 43 303 minecraft:deepslate_tiles
setblock 472 40 307 minecraft:cobbled_deepslate
fill 472 40 308 473 42 308 minecraft:deepslate_tiles
setblock 472 40 311 minecraft:deepslate_tiles
setblock 472 40 312 minecraft:cobbled_deepslate
setblock 473 40 276 minecraft:cobbled_deepslate
setblock 473 40 301 minecraft:cobbled_deepslate
fill 473 40 302 473 43 302 minecraft:deepslate_tiles
setblock 473 40 306 minecraft:cobbled_deepslate
fill 473 40 307 473 43 307 minecraft:deepslate_tiles
fill 473 40 309 473 41 309 minecraft:deepslate_tiles
setblock 473 40 316 minecraft:cobbled_deepslate
fill 474 40 276 474 43 276 minecraft:deepslate_tiles
fill 474 40 303 474 40 304 minecraft:deepslate_tiles
setblock 474 40 305 minecraft:cobbled_deepslate
fill 474 40 316 474 43 316 minecraft:deepslate_tiles
fill 485 40 275 485 94 275 minecraft:cobbled_deepslate
setblock 486 40 275 minecraft:white_wool
setblock 493 40 276 minecraft:cobbled_deepslate
fill 493 40 277 493 43 277 minecraft:deepslate_tiles
fill 494 40 276 494 43 276 minecraft:deepslate_tiles
setblock 496 40 278 minecraft:cobbled_deepslate
setblock 497 40 277 minecraft:cobbled_deepslate
fill 497 40 278 497 41 278 minecraft:deepslate_tiles
setblock 498 40 276 minecraft:cobbled_deepslate
fill 498 40 277 498 43 277 minecraft:deepslate_tiles
fill 499 40 276 499 43 276 minecraft:deepslate_tiles
setblock 503 40 276 minecraft:cobbled_deepslate
setblock 504 40 276 minecraft:deepslate_tiles
setblock 508 40 276 minecraft:cobbled_deepslate
fill 509 40 276 509 43 276 minecraft:deepslate_tiles
setblock 510 40 279 minecraft:cobbled_deepslate
fill 510 40 280 510 43 280 minecraft:deepslate_tiles
setblock 510 40 284 minecraft:cobbled_deepslate
setblock 511 40 278 minecraft:cobbled_deepslate
fill 511 40 279 511 43 279 minecraft:deepslate_tiles
setblock 511 40 283 minecraft:cobbled_deepslate
fill 511 40 284 511 43 284 minecraft:deepslate_tiles
setblock 511 40 287 minecraft:deepslate_tiles
fill 511 40 300 511 40 302 minecraft:deepslate_tiles
setblock 511 40 303 minecraft:cobbled_deepslate
fill 511 40 304 511 43 304 minecraft:deepslate_tiles
setblock 511 40 308 minecraft:cobbled_deepslate
fill 511 40 309 511 41 311 minecraft:deepslate_tiles
fill 511 40 314 511 42 315 minecraft:deepslate_tiles
setblock 471 41 277 minecraft:cobbled_deepslate
fill 471 41 278 471 44 278 minecraft:deepslate_tiles
setblock 471 41 282 minecraft:cobbled_deepslate
fill 471 41 283 472 43 283 minecraft:deepslate_tiles
setblock 471 41 286 minecraft:deepslate_tiles
setblock 471 41 287 minecraft:cobbled_deepslate
setblock 471 41 297 minecraft:cobbled_deepslate
fill 471 41 298 471 44 298 minecraft:deepslate_tiles
setblock 471 41 302 minecraft:cobbled_deepslate
fill 471 41 303 471 44 303 minecraft:deepslate_tiles
setblock 471 41 307 minecraft:cobbled_deepslate
fill 471 41 308 471 44 308 minecraft:deepslate_tiles
setblock 471 41 312 minecraft:cobbled_deepslate
fill 471 41 313 472 43 313 minecraft:deepslate_tiles
setblock 472 41 276 minecraft:cobbled_deepslate
setblock 472 41 281 minecraft:cobbled_deepslate
fill 472 41 282 472 44 282 minecraft:deepslate_tiles
fill 472 41 284 472 42 284 minecraft:deepslate_tiles
setblock 472 41 301 minecraft:cobbled_deepslate
fill 472 41 302 472 44 302 minecraft:deepslate_tiles
setblock 472 41 305 minecraft:deepslate_tiles
setblock 472 41 306 minecraft:cobbled_deepslate
fill 472 41 307 472 44 307 minecraft:deepslate_tiles
setblock 472 41 311 minecraft:cobbled_deepslate
fill 472 41 312 472 44 312 minecraft:deepslate_tiles
fill 472 41 314 472 41 315 minecraft:deepslate_tiles
setblock 472 41 316 minecraft:cobbled_deepslate
fill 473 41 276 473 44 276 minecraft:deepslate_tiles
setblock 473 41 300 minecraft:cobbled_deepslate
fill 473 41 301 473 44 301 minecraft:deepslate_tiles
setblock 473 41 305 minecraft:cobbled_deepslate
fill 473 41 306 474 43 306 minecraft:deepslate_tiles
setblock 473 41 310 minecraft:cobbled_deepslate
setblock 473 41 315 minecraft:cobbled_deepslate
fill 473 41 316 473 44 316 minecraft:deepslate_tiles
fill 474 41 302 474 41 303 minecraft:deepslate_tiles
setblock 474 41 304 minecraft:cobbled_deepslate
fill 474 41 305 474 44 305 minecraft:deepslate_tiles
fill 474 41 307 474 42 307 minecraft:deepslate_tiles
fill 474 41 315 474 44 315 minecraft:deepslate_tiles
setblock 477 41 316 minecraft:cobbled_deepslate
fill 486 41 275 486 91 275 minecraft:cobbled_deepslate
fill 490 41 309 490 61 309 minecraft:white_wool
setblock 491 41 276 minecraft:deepslate_tiles
setblock 492 41 276 minecraft:cobbled_deepslate
fill 493 41 276 493 44 276 minecraft:deepslate_tiles
setblock 495 41 278 minecraft:cobbled_deepslate
setblock 496 41 277 minecraft:cobbled_deepslate
fill 496 41 278 496 43 278 minecraft:deepslate_tiles
setblock 497 41 276 minecraft:cobbled_deepslate
fill 497 41 277 497 44 277 minecraft:deepslate_tiles
fill 498 41 276 498 44 276 minecraft:deepslate_tiles
setblock 502 41 276 minecraft:cobbled_deepslate
fill 503 41 276 503 44 276 minecraft:deepslate_tiles
setblock 507 41 276 minecraft:cobbled_deepslate
fill 508 41 276 508 44 276 minecraft:deepslate_tiles
setblock 510 41 278 minecraft:cobbled_deepslate
fill 510 41 279 510 44 279 minecraft:deepslate_tiles
setblock 510 41 283 minecraft:cobbled_deepslate
fill 510 41 284 510 43 285 minecraft:deepslate_tiles
fill 510 41 316 510 42 316 minecraft:deepslate_tiles
setblock 511 41 277 minecraft:cobbled_deepslate
fill 511 41 278 511 44 278 minecraft:deepslate_tiles
setblock 511 41 282 minecraft:cobbled_deepslate
fill 511 41 283 511 44 283 minecraft:deepslate_tiles
setblock 511 41 287 minecraft:cobbled_deepslate
fill 511 41 288 511 44 288 minecraft:deepslate_tiles
fill 511 41 300 511 41 301 minecraft:deepslate_tiles
setblock 511 41 302 minecraft:cobbled_deepslate
fill 511 41 303 511 44 303 minecraft:deepslate_tiles
fill 511 41 305 511 41 306 minecraft:deepslate_tiles
setblock 511 41 307 minecraft:cobbled_deepslate
fill 511 41 308 511 44 308 minecraft:deepslate_tiles
setblock 511 41 312 minecraft:cobbled_deepslate
fill 511 41 313 511 44 313 minecraft:deepslate_tiles
fill 470 42 299 470 90 302 minecraft:cobbled_deepslate
setblock 470 42 303 minecraft:redstone_block
setblock 471 42 276 minecraft:cobbled_deepslate
fill 471 42 277 471 45 277 minecraft:deepslate_tiles
setblock 471 42 281 minecraft:cobbled_deepslate
fill 471 42 282 471 45 282 minecraft:deepslate_tiles
setblock 471 42 286 minecraft:cobbled_deepslate
fill 471 42 287 471 43 289 minecraft:deepslate_tiles
setblock 471 42 296 minecraft:cobbled_deepslate
fill 471 42 297 471 45 297 minecraft:deepslate_tiles
setblock 471 42 301 minecraft:cobbled_deepslate
fill 471 42 302 471 45 302 minecraft:deepslate_tiles
setblock 471 42 306 minecraft:cobbled_deepslate
fill 471 42 307 471 45 307 minecraft:deepslate_tiles
setblock 471 42 310 minecraft:deepslate_tiles
setblock 471 42 311 minecraft:cobbled_deepslate
fill 471 42 312 471 45 312 minecraft:deepslate_tiles
setblock 471 42 316 minecraft:cobbled_deepslate
fill 472 42 276 472 45 276 minecraft:deepslate_tiles
setblock 472 42 280 minecraft:cobbled_deepslate
fill 472 42 281 472 45 281 minecraft:deepslate_tiles
setblock 472 42 285 minecraft:cobbled_deepslate
fill 472 42 286 472 45 286 minecraft:deepslate_tiles
fill 472 42 298 472 43 298 minecraft:deepslate_tiles
setblock 472 42 300 minecraft:cobbled_deepslate
fill 472 42 301 472 45 301 minecraft:deepslate_tiles
setblock 472 42 305 minecraft:cobbled_deepslate
fill 472 42 306 472 45 306 minecraft:deepslate_tiles
setblock 472 42 310 minecraft:cobbled_deepslate
fill 472 42 311 473 44 311 minecraft:deepslate_tiles
setblock 472 42 314 minecraft:deepslate_tiles
setblock 472 42 315 minecraft:cobbled_deepslate
fill 472 42 316 472 45 316 minecraft:deepslate_tiles
fill 473 42 300 473 45 300 minecraft:deepslate_tiles
setblock 473 42 304 minecraft:cobbled_deepslate
fill 473 42 305 473 45 305 minecraft:deepslate_tiles
setblock 473 42 309 minecraft:cobbled_deepslate
fill 473 42 310 473 45 310 minecraft:deepslate_tiles
fill 473 42 312 473 43 312 minecraft:deepslate_tiles
fill 473 42 315 473 45 315 minecraft:deepslate_tiles
setblock 474 42 302 minecraft:deepslate_tiles
setblock 474 42 303 minecraft:cobbled_deepslate
fill 474 42 304 474 45 304 minecraft:deepslate_tiles
setblock 474 42 308 minecraft:cobbled_deepslate
fill 474 42 309 474 45 309 minecraft:deepslate_tiles
fill 475 42 315 475 43 315 minecraft:deepslate_tiles
setblock 476 42 276 minecraft:cobbled_deepslate
setblock 476 42 316 minecraft:cobbled_deepslate
fill 477 42 316 477 45 316 minecraft:deepslate_tiles
setblock 491 42 276 minecraft:cobbled_deepslate
fill 492 42 276 492 44 277 minecraft:deepslate_tiles
setblock 494 42 278 minecraft:cobbled_deepslate
setblock 495 42 277 minecraft:cobbled_deepslate
fill 495 42 278 495 44 278 minecraft:deepslate_tiles
setblock 496 42 276 minecraft:cobbled_deepslate
fill 496 42 277 496 45 277 minecraft:deepslate_tiles
fill 497 42 276 497 45 276 minecraft:deepslate_tiles
setblock 501 42 276 minecraft:cobbled_deepslate
fill 502 42 276 502 45 276 minecraft:deepslate_tiles
fill 504 42 276 504 43 276 minecraft:deepslate_tiles
setblock 506 42 276 minecraft:cobbled_deepslate
fill 507 42 276 507 45 276 minecraft:deepslate_tiles
fill 509 42 316 509 43 316 minecraft:deepslate_tiles
setblock 510 42 277 minecraft:cobbled_deepslate
fill 510 42 278 510 45 278 minecraft:deepslate_tiles
setblock 510 42 282 minecraft:cobbled_deepslate
fill 510 42 283 510 45 283 minecraft:deepslate_tiles
setblock 510 42 286 minecraft:deepslate_tiles
fill 510 42 303 510 42 306 minecraft:deepslate_tiles
setblock 510 42 307 minecraft:cobbled_deepslate
fill 510 42 308 510 43 310 minecraft:deepslate_tiles
setblock 511 42 276 minecraft:cobbled_deepslate
fill 511 42 277 511 45 277 minecraft:deepslate_tiles
setblock 511 42 281 minecraft:cobbled_deepslate
fill 511 42 282 511 45 282 minecraft:deepslate_tiles
setblock 511 42 285 minecraft:deepslate_tiles
setblock 511 42 286 minecraft:cobbled_deepslate
fill 511 42 287 511 45 287 minecraft:deepslate_tiles
fill 511 42 289 511 43 289 minecraft:deepslate_tiles
fill 511 42 299 511 42 300 minecraft:deepslate_tiles
setblock 511 42 301 minecraft:cobbled_deepslate
fill 511 42 302 511 45 302 minecraft:deepslate_tiles
setblock 511 42 305 minecraft:deepslate_tiles
setblock 511 42 306 minecraft:cobbled_deepslate
fill 511 42 307 511 45 307 minecraft:deepslate_tiles
fill 511 42 309 511 42 310 minecraft:deepslate_tiles
setblock 511 42 311 minecraft:cobbled_deepslate
fill 511 42 312 511 45 312 minecraft:deepslate_tiles
setblock 511 42 316 minecraft:cobbled_deepslate
fill 470 43 303 470 91 303 minecraft:cobbled_deepslate
fill 471 43 276 471 46 276 minecraft:deepslate_tiles
setblock 471 43 280 minecraft:cobbled_deepslate
fill 471 43 281 471 46 281 minecraft:deepslate_tiles
setblock 471 43 284 minecraft:deepslate_tiles
setblock 471 43 285 minecraft:cobbled_deepslate
fill 471 43 286 471 46 286 minecraft:deepslate_tiles
setblock 471 43 290 minecraft:cobbled_deepslate
fill 471 43 291 471 45 292 minecraft:deepslate_tiles
setblock 471 43 294 minecraft:deepslate_tiles
setblock 471 43 295 minecraft:cobbled_deepslate
fill 471 43 296 471 46 296 minecraft:deepslate_tiles
setblock 471 43 300 minecraft:cobbled_deepslate
fill 471 43 301 471 46 301 minecraft:deepslate_tiles
setblock 471 43 305 minecraft:cobbled_deepslate
fill 471 43 306 471 46 306 minecraft:deepslate_tiles
setblock 471 43 310 minecraft:cobbled_deepslate
fill 471 43 311 471 46 311 minecraft:deepslate_tiles
setblock 471 43 315 minecraft:cobbled_deepslate
fill 471 43 316 471 46 316 minecraft:deepslate_tiles
setblock 472 43 279 minecraft:cobbled_deepslate
fill 472 43 280 472 46 280 minecraft:deepslate_tiles
setblock 472 43 284 minecraft:cobbled_deepslate
fill 472 43 285 472 46 285 minecraft:deepslate_tiles
fill 472 43 287 472 43 288 minecraft:deepslate_tiles
setblock 472 43 299 minecraft:cobbled_deepslate
fill 472 43 300 472 46 300 minecraft:deepslate_tiles
setblock 472 43 304 minecraft:cobbled_deepslate
fill 472 43 305 472 46 305 minecraft:deepslate_tiles
setblock 472 43 308 minecraft:deepslate_tiles
setblock 472 43 309 minecraft:cobbled_deepslate
fill 472 43 310 472 46 310 minecraft:deepslate_tiles
setblock 472 43 314 minecraft:cobbled_deepslate
fill 472 43 315 472 46 315 minecraft:deepslate_tiles
setblock 473 43 278 minecraft:light[level=12]
setblock 473 43 285 minecraft:light[level=12]
setblock 473 43 292 minecraft:light[level=12]
setblock 473 43 299 minecraft:light[level=12]
setblock 473 43 303 minecraft:cobbled_deepslate
fill 473 43 304 473 46 304 minecraft:deepslate_tiles
setblock 473 43 308 minecraft:cobbled_deepslate
fill 473 43 309 473 46 309 minecraft:deepslate_tiles
setblock 473 43 313 minecraft:cobbled_deepslate
setblock 474 43 302 minecraft:cobbled_deepslate
fill 474 43 303 474 46 303 minecraft:deepslate_tiles
setblock 474 43 307 minecraft:cobbled_deepslate
fill 474 43 308 474 46 308 minecraft:deepslate_tiles
fill 474 43 310 474 44 310 minecraft:deepslate_tiles
setblock 475 43 276 minecraft:cobbled_deepslate
setblock 475 43 316 minecraft:cobbled_deepslate
fill 476 43 316 476 46 316 minecraft:deepslate_tiles
setblock 480 43 278 minecraft:light[level=12]
setblock 480 43 285 minecraft:light[level=12]
setblock 480 43 292 minecraft:light[level=12]
setblock 480 43 299 minecraft:light[level=12]
setblock 480 43 306 minecraft:light[level=12]
setblock 480 43 313 minecraft:light[level=12]
setblock 487 43 278 minecraft:light[level=12]
setblock 487 43 285 minecraft:light[level=12]
setblock 487 43 292 minecraft:light[level=12]
setblock 487 43 299 minecraft:light[level=12]
setblock 487 43 306 minecraft:light[level=12]
setblock 487 43 313 minecraft:light[level=12]
fill 488 43 275 489 81 275 minecraft:cobbled_deepslate
setblock 490 43 275 minecraft:redstone_block
setblock 490 43 276 minecraft:cobbled_deepslate
fill 491 43 275 495 47 275 minecraft:cobbled_deepslate
fill 491 43 276 491 45 277 minecraft:deepslate_tiles
setblock 493 43 278 minecraft:cobbled_deepslate
setblock 494 43 277 minecraft:cobbled_deepslate
fill 494 43 278 494 45 278 minecraft:deepslate_tiles
setblock 494 43 285 minecraft:light[level=12]
setblock 494 43 292 minecraft:light[level=12]
setblock 494 43 299 minecraft:light[level=12]
setblock 494 43 306 minecraft:light[level=12]
setblock 494 43 313 minecraft:light[level=12]
setblock 495 43 276 minecraft:cobbled_deepslate
fill 495 43 277 495 46 277 minecraft:deepslate_tiles
fill 496 43 276 496 46 276 minecraft:deepslate_tiles
setblock 499 43 277 minecraft:cobbled_deepslate
setblock 500 43 276 minecraft:cobbled_deepslate
fill 501 43 276 501 46 276 minecraft:deepslate_tiles
setblock 501 43 278 minecraft:light[level=12]
setblock 501 43 285 minecraft:light[level=12]
setblock 501 43 292 minecraft:light[level=12]
setblock 501 43 299 minecraft:light[level=12]
setblock 501 43 306 minecraft:light[level=12]
setblock 501 43 313 minecraft:light[level=12]
setblock 505 43 276 minecraft:cobbled_deepslate
fill 506 43 276 506 46 276 minecraft:deepslate_tiles
setblock 508 43 277 minecraft:deepslate_tiles
setblock 508 43 278 minecraft:light[level=12]
setblock 508 43 285 minecraft:light[level=12]
setblock 508 43 292 minecraft:light[level=12]
setblock 508 43 299 minecraft:light[level=12]
setblock 508 43 306 minecraft:light[level=12]
setblock 508 43 313 minecraft:light[level=12]
fill 508 43 316 508 44 316 minecraft:deepslate_tiles
setblock 509 43 277 minecraft:cobbled_deepslate
fill 509 43 280 509 43 281 minecraft:deepslate_tiles
setblock 509 43 282 minecraft:cobbled_deepslate
fill 509 43 283 509 45 284 minecraft:deepslate_tiles
setblock 510 43 276 minecraft:cobbled_deepslate
fill 510 43 277 510 46 277 minecraft:deepslate_tiles
setblock 510 43 281 minecraft:cobbled_deepslate
fill 510 43 282 510 46 282 minecraft:deepslate_tiles
setblock 510 43 286 minecraft:cobbled_deepslate
fill 510 43 287 510 45 288 minecraft:deepslate_tiles
fill 510 43 302 510 43 305 minecraft:deepslate_tiles
setblock 510 43 306 minecraft:cobbled_deepslate
fill 510 43 307 510 46 307 minecraft:deepslate_tiles
setblock 510 43 311 minecraft:cobbled_deepslate
fill 510 43 312 510 43 315 minecraft:deepslate_tiles
setblock 510 43 316 minecraft:cobbled_deepslate
fill 511 43 276 511 46 276 minecraft:deepslate_tiles
setblock 511 43 280 minecraft:cobbled_deepslate
fill 511 43 281 511 46 281 minecraft:deepslate_tiles
setblock 511 43 285 minecraft:cobbled_deepslate
fill 511 43 286 511 46 286 minecraft:deepslate_tiles
setblock 511 43 290 minecraft:cobbled_deepslate
setblock 511 43 299 minecraft:deepslate_tiles
setblock 511 43 300 minecraft:cobbled_deepslate
fill 511 43 301 511 46 301 minecraft:deepslate_tiles
setblock 511 43 305 minecraft:cobbled_deepslate
fill 511 43 306 511 46 306 minecraft:deepslate_tiles
setblock 511 43 309 minecraft:deepslate_tiles
setblock 511 43 310 minecraft:cobbled_deepslate
fill 511 43 311 511 46 311 minecraft:deepslate_tiles
setblock 511 43 314 minecraft:deepslate_tiles
setblock 511 43 315 minecraft:cobbled_deepslate
fill 511 43 316 511 46 316 minecraft:deepslate_tiles
setblock 471 44 279 minecraft:cobbled_deepslate
fill 471 44 280 471 47 280 minecraft:deepslate_tiles
setblock 471 44 283 minecraft:deepslate_tiles
setblock 471 44 284 minecraft:cobbled_deepslate
fill 471 44 285 471 47 285 minecraft:deepslate_tiles
fill 471 44 287 471 44 288 minecraft:deepslate_tiles
setblock 471 44 289 minecraft:cobbled_deepslate
fill 471 44 290 472 46 290 minecraft:deepslate_tiles
setblock 471 44 293 minecraft:deepslate_tiles
setblock 471 44 294 minecraft:cobbled_deepslate
fill 471 44 295 471 47 295 minecraft:deepslate_tiles
setblock 471 44 299 minecraft:cobbled_deepslate
fill 471 44 300 471 47 300 minecraft:deepslate_tiles
setblock 471 44 304 minecraft:cobbled_deepslate
fill 471 44 305 471 47 305 minecraft:deepslate_tiles
setblock 471 44 309 minecraft:cobbled_deepslate
fill 471 44 310 471 47 310 minecraft:deepslate_tiles
setblock 471 44 313 minecraft:deepslate_tiles
setblock 471 44 314 minecraft:cobbled_deepslate
fill 471 44 315 471 47 315 minecraft:deepslate_tiles
fill 471 44 317 477 73 317 minecraft:cobbled_deepslate
fill 472 44 279 472 45 279 minecraft:deepslate_tiles
setblock 472 44 283 minecraft:cobbled_deepslate
fill 472 44 284 473 45 284 minecraft:deepslate_tiles
setblock 472 44 287 minecraft:deepslate_tiles
setblock 472 44 288 minecraft:cobbled_deepslate
fill 472 44 289 472 47 289 minecraft:deepslate_tiles
fill 472 44 291 472 45 291 minecraft:deepslate_tiles
setblock 472 44 297 minecraft:deepslate_tiles
setblock 472 44 298 minecraft:cobbled_deepslate
fill 472 44 299 473 45 299 minecraft:deepslate_tiles
setblock 472 44 303 minecraft:cobbled_deepslate
fill 472 44 304 472 47 304 minecraft:deepslate_tiles
setblock 472 44 308 minecraft:cobbled_deepslate
fill 472 44 309 472 47 309 minecraft:deepslate_tiles
setblock 472 44 313 minecraft:cobbled_deepslate
fill 472 44 314 473 46 314 minecraft:deepslate_tiles
fill 473 44 285 473 44 286 minecraft:deepslate_tiles
setblock 473 44 302 minecraft:cobbled_deepslate
fill 473 44 303 473 47 303 minecraft:deepslate_tiles
setblock 473 44 306 minecraft:deepslate_tiles
setblock 473 44 307 minecraft:cobbled_deepslate
fill 473 44 308 473 47 308 minecraft:deepslate_tiles
setblock 473 44 312 minecraft:cobbled_deepslate
fill 473 44 313 473 47 313 minecraft:deepslate_tiles
setblock 474 44 276 minecraft:cobbled_deepslate
fill 474 44 302 474 45 302 minecraft:deepslate_tiles
setblock 474 44 306 minecraft:cobbled_deepslate
fill 474 44 307 474 47 307 minecraft:deepslate_tiles
setblock 474 44 311 minecraft:cobbled_deepslate
setblock 474 44 316 minecraft:cobbled_deepslate
setblock 475 44 276 minecraft:deepslate_tiles
setblock 475 44 315 minecraft:cobbled_deepslate
fill 475 44 316 475 47 316 minecraft:deepslate_tiles
setblock 478 44 317 minecraft:white_wool
fill 479 44 313 479 54 313 minecraft:black_concrete
fill 479 44 317 482 90 317 minecraft:cobbled_deepslate
setblock 489 44 276 minecraft:cobbled_deepslate
fill 490 44 275 490 94 275 minecraft:cobbled_deepslate
fill 490 44 276 490 47 276 minecraft:deepslate_tiles
setblock 492 44 317 minecraft:redstone_block
setblock 493 44 277 minecraft:cobbled_deepslate
fill 493 44 278 493 45 278 minecraft:deepslate_tiles
setblock 493 44 316 minecraft:deepslate_tiles
setblock 494 44 276 minecraft:cobbled_deepslate
fill 494 44 277 494 47 277 minecraft:deepslate_tiles
setblock 494 44 316 minecraft:cobbled_deepslate
fill 495 44 276 495 47 276 minecraft:deepslate_tiles
fill 495 44 316 495 47 316 minecraft:deepslate_tiles
setblock 498 44 277 minecraft:cobbled_deepslate
setblock 499 44 276 minecraft:cobbled_deepslate
fill 500 44 276 500 47 276 minecraft:deepslate_tiles
setblock 504 44 276 minecraft:cobbled_deepslate
fill 505 44 276 505 47 276 minecraft:deepslate_tiles
setblock 507 44 277 minecraft:deepslate_tiles
fill 507 44 316 507 45 316 minecraft:deepslate_tiles
setblock 508 44 277 minecraft:cobbled_deepslate
setblock 509 44 276 minecraft:cobbled_deepslate
fill 509 44 277 509 47 277 minecraft:deepslate_tiles
setblock 509 44 280 minecraft:deepslate_tiles
setblock 509 44 281 minecraft:cobbled_deepslate
fill 509 44 282 509 47 282 minecraft:deepslate_tiles
setblock 509 44 285 minecraft:deepslate_tiles
setblock 509 44 306 minecraft:cobbled_deepslate
fill 509 44 307 509 44 310 minecraft:deepslate_tiles
setblock 509 44 315 minecraft:deepslate_tiles
setblock 509 44 316 minecraft:cobbled_deepslate
fill 510 44 276 510 47 276 minecraft:deepslate_tiles
setblock 510 44 280 minecraft:cobbled_deepslate
fill 510 44 281 510 47 281 minecraft:deepslate_tiles
setblock 510 44 284 minecraft:deepslate_tiles
setblock 510 44 285 minecraft:cobbled_deepslate
fill 510 44 286 510 47 286 minecraft:deepslate_tiles
setblock 510 44 289 minecraft:deepslate_tiles
fill 510 44 302 510 44 304 minecraft:deepslate_tiles
setblock 510 44 305 minecraft:cobbled_deepslate
fill 510 44 306 510 47 306 minecraft:deepslate_tiles
fill 510 44 308 510 44 309 minecraft:deepslate_tiles
setblock 510 44 310 minecraft:cobbled_deepslate
fill 510 44 311 510 44 314 minecraft:deepslate_tiles
setblock 510 44 315 minecraft:cobbled_deepslate
fill 510 44 316 510 47 316 minecraft:deepslate_tiles
setblock 511 44 279 minecraft:cobbled_deepslate
fill 511 44 280 511 47 280 minecraft:deepslate_tiles
setblock 511 44 284 minecraft:cobbled_deepslate
fill 511 44 285 511 47 285 minecraft:deepslate_tiles
setblock 511 44 289 minecraft:cobbled_deepslate
fill 511 44 290 511 45 292 minecraft:deepslate_tiles
setblock 511 44 298 minecraft:deepslate_tiles
setblock 511 44 299 minecraft:cobbled_deepslate
fill 511 44 300 511 47 300 minecraft:deepslate_tiles
setblock 511 44 304 minecraft:cobbled_deepslate
fill 511 44 305 511 47 305 minecraft:deepslate_tiles
setblock 511 44 309 minecraft:cobbled_deepslate
fill 511 44 310 511 47 310 minecraft:deepslate_tiles
setblock 511 44 314 minecraft:cobbled_deepslate
fill 511 44 315 511 47 315 minecraft:deepslate_tiles
fill 470 45 292 470 52 293 minecraft:cobbled_deepslate
setblock 470 45 294 minecraft:white_wool
setblock 471 45 278 minecraft:cobbled_deepslate
fill 471 45 279 471 48 279 minecraft:deepslate_tiles
setblock 471 45 283 minecraft:cobbled_deepslate
fill 471 45 284 471 48 284 minecraft:deepslate_tiles
setblock 471 45 287 minecraft:deepslate_tiles
setblock 471 45 288 minecraft:cobbled_deepslate
fill 471 45 289 471 48 289 minecraft:deepslate_tiles
setblock 471 45 293 minecraft:cobbled_deepslate
fill 471 45 294 472 47 294 minecraft:deepslate_tiles
setblock 471 45 298 minecraft:cobbled_deepslate
fill 471 45 299 471 48 299 minecraft:deepslate_tiles
setblock 471 45 303 minecraft:cobbled_deepslate
fill 471 45 304 471 48 304 minecraft:deepslate_tiles
setblock 471 45 308 minecraft:cobbled_deepslate
fill 471 45 309 471 48 309 minecraft:deepslate_tiles
setblock 471 45 313 minecraft:cobbled_deepslate
fill 471 45 314 471 48 314 minecraft:deepslate_tiles
setblock 472 45 282 minecraft:cobbled_deepslate
fill 472 45 283 472 48 283 minecraft:deepslate_tiles
setblock 472 45 287 minecraft:cobbled_deepslate
fill 472 45 288 473 47 288 minecraft:deepslate_tiles
setblock 472 45 292 minecraft:cobbled_deepslate
fill 472 45 293 472 48 293 minecraft:deepslate_tiles
fill 472 45 295 472 45 296 minecraft:deepslate_tiles
setblock 472 45 297 minecraft:cobbled_deepslate
fill 472 45 298 472 48 298 minecraft:deepslate_tiles
setblock 472 45 302 minecraft:cobbled_deepslate
fill 472 45 303 472 48 303 minecraft:deepslate_tiles
setblock 472 45 307 minecraft:cobbled_deepslate
fill 472 45 308 472 48 308 minecraft:deepslate_tiles
setblock 472 45 311 minecraft:deepslate_tiles
setblock 472 45 312 minecraft:cobbled_deepslate
fill 472 45 313 472 48 313 minecraft:deepslate_tiles
setblock 473 45 276 minecraft:cobbled_deepslate
setblock 473 45 278 minecraft:light[level=13]
setblock 473 45 285 minecraft:deepslate_tiles
setblock 473 45 286 minecraft:cobbled_deepslate
fill 473 45 287 473 48 287 minecraft:deepslate_tiles
setblock 473 45 294 minecraft:light[level=13]
setblock 473 45 301 minecraft:cobbled_deepslate
fill 473 45 302 473 48 302 minecraft:deepslate_tiles
setblock 473 45 306 minecraft:cobbled_deepslate
fill 473 45 307 473 48 307 minecraft:deepslate_tiles
setblock 473 45 311 minecraft:cobbled_deepslate
fill 473 45 312 473 48 312 minecraft:deepslate_tiles
setblock 473 45 316 minecraft:cobbled_deepslate
setblock 474 45 276 minecraft:deepslate_tiles
setblock 474 45 305 minecraft:cobbled_deepslate
fill 474 45 306 474 48 306 minecraft:deepslate_tiles
setblock 474 45 310 minecraft:cobbled_deepslate
fill 474 45 311 474 47 311 minecraft:deepslate_tiles
setblock 474 45 314 minecraft:deepslate_tiles
setblock 474 45 315 minecraft:cobbled_deepslate
fill 474 45 316 474 48 316 minecraft:deepslate_tiles
fill 475 45 315 475 47 315 minecraft:deepslate_tiles
fill 478 45 317 478 94 317 minecraft:cobbled_deepslate
setblock 481 45 278 minecraft:light[level=13]
setblock 481 45 286 minecraft:light[level=13]
setblock 481 45 294 minecraft:light[level=13]
setblock 481 45 302 minecraft:light[level=13]
setblock 481 45 310 minecraft:light[level=13]
setblock 487 45 275 minecraft:white_wool
fill 489 45 276 489 48 276 minecraft:deepslate_tiles
setblock 489 45 278 minecraft:light[level=13]
setblock 489 45 286 minecraft:light[level=13]
setblock 489 45 294 minecraft:light[level=13]
setblock 489 45 302 minecraft:light[level=13]
setblock 489 45 310 minecraft:light[level=13]
fill 490 45 277 490 46 277 minecraft:deepslate_tiles
fill 491 45 316 492 45 316 minecraft:deepslate_tiles
setblock 492 45 276 minecraft:deepslate_tiles
setblock 492 45 277 minecraft:cobbled_deepslate
fill 492 45 317 492 92 317 minecraft:cobbled_deepslate
setblock 493 45 276 minecraft:cobbled_deepslate
fill 493 45 277 493 48 277 minecraft:deepslate_tiles
setblock 493 45 316 minecraft:cobbled_deepslate
fill 494 45 276 494 48 276 minecraft:deepslate_tiles
fill 494 45 316 494 48 316 minecraft:deepslate_tiles
fill 496 45 316 496 46 316 minecraft:deepslate_tiles
setblock 497 45 277 minecraft:cobbled_deepslate
setblock 497 45 278 minecraft:light[level=13]
setblock 497 45 286 minecraft:light[level=13]
setblock 497 45 294 minecraft:light[level=13]
setblock 497 45 302 minecraft:light[level=13]
setblock 497 45 310 minecraft:light[level=13]
setblock 498 45 276 minecraft:cobbled_deepslate
fill 499 45 276 499 47 276 minecraft:deepslate_tiles
setblock 503 45 276 minecraft:cobbled_deepslate
fill 504 45 276 504 48 276 minecraft:deepslate_tiles
setblock 505 45 278 minecraft:light[level=13]
setblock 505 45 286 minecraft:light[level=13]
setblock 505 45 294 minecraft:light[level=13]
setblock 505 45 302 minecraft:light[level=13]
setblock 505 45 310 minecraft:light[level=13]
fill 505 45 316 506 46 316 minecraft:deepslate_tiles
setblock 507 45 277 minecraft:cobbled_deepslate
setblock 508 45 276 minecraft:cobbled_deepslate
fill 508 45 277 508 48 277 minecraft:deepslate_tiles
setblock 508 45 315 minecraft:deepslate_tiles
setblock 508 45 316 minecraft:cobbled_deepslate
fill 509 45 276 509 48 276 minecraft:deepslate_tiles
setblock 509 45 280 minecraft:cobbled_deepslate
fill 509 45 281 509 46 281 minecraft:deepslate_tiles
setblock 509 45 285 minecraft:cobbled_deepslate
fill 509 45 286 509 47 287 minecraft:deepslate_tiles
setblock 509 45 305 minecraft:cobbled_deepslate
fill 509 45 306 509 45 309 minecraft:deepslate_tiles
setblock 509 45 310 minecraft:cobbled_deepslate
fill 509 45 311 510 45 313 minecraft:deepslate_tiles
setblock 509 45 315 minecraft:cobbled_deepslate
fill 509 45 316 509 48 316 minecraft:deepslate_tiles
setblock 510 45 279 minecraft:cobbled_deepslate
fill 510 45 280 510 48 280 minecraft:deepslate_tiles
setblock 510 45 284 minecraft:cobbled_deepslate
fill 510 45 285 510 48 285 minecraft:deepslate_tiles
setblock 510 45 289 minecraft:cobbled_deepslate
fill 510 45 290 510 48 290 minecraft:deepslate_tiles
fill 510 45 301 510 45 303 minecraft:deepslate_tiles
setblock 510 45 304 minecraft:cobbled_deepslate
fill 510 45 305 510 48 305 minecraft:deepslate_tiles
setblock 510 45 308 minecraft:deepslate_tiles
setblock 510 45 309 minecraft:cobbled_deepslate
fill 510 45 310 510 48 310 minecraft:deepslate_tiles
setblock 510 45 314 minecraft:cobbled_deepslate
fill 510 45 315 510 48 315 minecraft:deepslate_tiles
setblock 511 45 278 minecraft:cobbled_deepslate
fill 511 45 279 511 48 279 minecraft:deepslate_tiles
setblock 511 45 283 minecraft:cobbled_deepslate
fill 511 45 284 511 48 284 minecraft:deepslate_tiles
setblock 511 45 288 minecraft:cobbled_deepslate
fill 511 45 289 511 48 289 minecraft:deepslate_tiles
setblock 511 45 293 minecraft:cobbled_deepslate
fill 511 45 294 511 48 294 minecraft:deepslate_tiles
setblock 511 45 297 minecraft:deepslate_tiles
setblock 511 45 298 minecraft:cobbled_deepslate
fill 511 45 299 511 48 299 minecraft:deepslate_tiles
setblock 511 45 303 minecraft:cobbled_deepslate
fill 511 45 304 511 48 304 minecraft:deepslate_tiles
setblock 511 45 308 minecraft:cobbled_deepslate
fill 511 45 309 511 48 309 minecraft:deepslate_tiles
setblock 511 45 313 minecraft:cobbled_deepslate
fill 511 45 314 511 48 314 minecraft:deepslate_tiles
fill 470 46 294 470 90 294 minecraft:cobbled_deepslate
setblock 471 46 277 minecraft:cobbled_deepslate
fill 471 46 278 471 48 278 minecraft:deepslate_tiles
setblock 471 46 282 minecraft:cobbled_deepslate
fill 471 46 283 471 49 283 minecraft:deepslate_tiles
setblock 471 46 287 minecraft:cobbled_deepslate
fill 471 46 288 471 49 288 minecraft:deepslate_tiles
setblock 471 46 291 minecraft:deepslate_tiles
setblock 471 46 292 minecraft:cobbled_deepslate
fill 471 46 293 471 49 293 minecraft:deepslate_tiles
setblock 471 46 297 minecraft:cobbled_deepslate
fill 471 46 298 471 49 298 minecraft:deepslate_tiles
setblock 471 46 302 minecraft:cobbled_deepslate
fill 471 46 303 471 49 303 minecraft:deepslate_tiles
setblock 471 46 307 minecraft:cobbled_deepslate
fill 471 46 308 471 49 308 minecraft:deepslate_tiles
setblock 471 46 312 minecraft:cobbled_deepslate
fill 471 46 313 471 49 313 minecraft:deepslate_tiles
setblock 472 46 276 minecraft:cobbled_deepslate
setblock 472 46 281 minecraft:cobbled_deepslate
fill 472 46 282 472 47 282 minecraft:deepslate_tiles
fill 472 46 284 472 47 284 minecraft:deepslate_tiles
setblock 472 46 286 minecraft:cobbled_deepslate
fill 472 46 287 472 49 287 minecraft:deepslate_tiles
setblock 472 46 291 minecraft:cobbled_deepslate
fill 472 46 292 472 49 292 minecraft:deepslate_tiles
setblock 472 46 295 minecraft:deepslate_tiles
setblock 472 46 296 minecraft:cobbled_deepslate
fill 472 46 297 472 49 297 minecraft:deepslate_tiles
fill 472 46 299 472 47 299 minecraft:deepslate_tiles
setblock 472 46 301 minecraft:cobbled_deepslate
fill 472 46 302 472 49 302 minecraft:deepslate_tiles
setblock 472 46 306 minecraft:cobbled_deepslate
fill 472 46 307 472 49 307 minecraft:deepslate_tiles
setblock 472 46 311 minecraft:cobbled_deepslate
fill 472 46 312 472 49 312 minecraft:deepslate_tiles
setblock 472 46 316 minecraft:cobbled_deepslate
fill 473 46 276 473 47 276 minecraft:deepslate_tiles
setblock 473 46 285 minecraft:cobbled_deepslate
fill 473 46 286 473 47 286 minecraft:deepslate_tiles
setblock 473 46 289 minecraft:deepslate_tiles
setblock 473 46 300 minecraft:cobbled_deepslate
fill 473 46 301 473 47 301 minecraft:deepslate_tiles
setblock 473 46 305 minecraft:cobbled_deepslate
fill 473 46 306 473 49 306 minecraft:deepslate_tiles
setblock 473 46 310 minecraft:cobbled_deepslate
fill 473 46 311 473 49 311 minecraft:deepslate_tiles
setblock 473 46 315 minecraft:cobbled_deepslate
fill 473 46 316 473 49 316 minecraft:deepslate_tiles
setblock 474 46 304 minecraft:cobbled_deepslate
fill 474 46 305 474 47 305 minecraft:deepslate_tiles
setblock 474 46 309 minecraft:cobbled_deepslate
fill 474 46 310 474 48 310 minecraft:deepslate_tiles
setblock 474 46 314 minecraft:cobbled_deepslate
fill 474 46 315 474 49 315 minecraft:deepslate_tiles
fill 487 46 275 487 94 275 minecraft:cobbled_deepslate
fill 488 46 276 488 49 276 minecraft:deepslate_tiles
fill 490 46 316 491 46 316 minecraft:deepslate_tiles
setblock 491 46 276 minecraft:deepslate_tiles
setblock 491 46 277 minecraft:cobbled_deepslate
setblock 492 46 276 minecraft:cobbled_deepslate
fill 492 46 277 492 49 277 minecraft:deepslate_tiles
setblock 492 46 316 minecraft:cobbled_deepslate
fill 493 46 276 493 49 276 minecraft:deepslate_tiles
fill 493 46 316 493 49 316 minecraft:deepslate_tiles
setblock 496 46 277 minecraft:cobbled_deepslate
setblock 497 46 276 minecraft:cobbled_deepslate
fill 498 46 276 498 48 276 minecraft:deepslate_tiles
setblock 502 46 276 minecraft:cobbled_deepslate
fill 503 46 276 503 49 276 minecraft:deepslate_tiles
fill 504 46 288 505 49 289 minecraft:white_terracotta
fill 504 46 316 504 48 316 minecraft:deepslate_tiles
setblock 507 46 276 minecraft:cobbled_deepslate
fill 507 46 277 507 47 277 minecraft:deepslate_tiles
setblock 507 46 315 minecraft:deepslate_tiles
setblock 507 46 316 minecraft:cobbled_deepslate
fill 508 46 276 508 49 276 minecraft:deepslate_tiles
setblock 508 46 314 minecraft:deepslate_tiles
setblock 508 46 315 minecraft:cobbled_deepslate
fill 508 46 316 508 49 316 minecraft:deepslate_tiles
setblock 509 46 283 minecraft:deepslate_tiles
setblock 509 46 284 minecraft:cobbled_deepslate
fill 509 46 285 509 48 285 minecraft:deepslate_tiles
setblock 509 46 304 minecraft:cobbled_deepslate
fill 509 46 305 509 46 308 minecraft:deepslate_tiles
setblock 509 46 309 minecraft:cobbled_deepslate
fill 509 46 310 509 46 313 minecraft:deepslate_tiles
setblock 509 46 314 minecraft:cobbled_deepslate
fill 509 46 315 509 49 315 minecraft:deepslate_tiles
setblock 510 46 278 minecraft:cobbled_deepslate
fill 510 46 279 510 48 279 minecraft:deepslate_tiles
setblock 510 46 283 minecraft:cobbled_deepslate
fill 510 46 284 510 49 284 minecraft:deepslate_tiles
setblock 510 46 287 minecraft:deepslate_tiles
setblock 510 46 288 minecraft:cobbled_deepslate
fill 510 46 289 510 49 289 minecraft:deepslate_tiles
fill 510 46 291 511 46 291 minecraft:deepslate_tiles
fill 510 46 301 510 46 302 minecraft:deepslate_tiles
setblock 510 46 303 minecraft:cobbled_deepslate
fill 510 46 304 510 49 304 minecraft:deepslate_tiles
setblock 510 46 308 minecraft:cobbled_deepslate
fill 510 46 309 510 49 309 minecraft:deepslate_tiles
fill 510 46 311 510 46 312 minecraft:deepslate_tiles
setblock 510 46 313 minecraft:cobbled_deepslate
fill 510 46 314 510 49 314 minecraft:deepslate_tiles
setblock 511 46 277 minecraft:cobbled_deepslate
fill 511 46 278 511 49 278 minecraft:deepslate_tiles
setblock 511 46 282 minecraft:cobbled_deepslate
fill 511 46 283 511 49 283 minecraft:deepslate_tiles
setblock 511 46 287 minecraft:cobbled_deepslate
fill 511 46 288 511 49 288 minecraft:deepslate_tiles
fill 511 46 290 511 47 290 minecraft:deepslate_tiles
setblock 511 46 292 minecraft:cobbled_deepslate
fill 511 46 293 511 49 293 minecraft:deepslate_tiles
fill 511 46 295 511 46 296 minecraft:deepslate_tiles
setblock 511 46 297 minecraft:cobbled_deepslate
fill 511 46 298 511 49 298 minecraft:deepslate_tiles
setblock 511 46 302 minecraft:cobbled_deepslate
fill 511 46 303 511 49 303 minecraft:deepslate_tiles
setblock 511 46 307 minecraft:cobbled_deepslate
fill 511 46 308 511 49 308 minecraft:deepslate_tiles
setblock 511 46 312 minecraft:cobbled_deepslate
fill 511 46 313 511 49 313 minecraft:deepslate_tiles
setblock 471 47 276 minecraft:cobbled_deepslate
fill 471 47 277 471 48 277 minecraft:deepslate_tiles
setblock 471 47 281 minecraft:cobbled_deepslate
fill 471 47 282 471 49 282 minecraft:deepslate_tiles
setblock 471 47 286 minecraft:cobbled_deepslate
fill 471 47 287 471 50 287 minecraft:deepslate_tiles
setblock 471 47 290 minecraft:deepslate_tiles
setblock 471 47 291 minecraft:cobbled_deepslate
fill 471 47 292 471 50 292 minecraft:deepslate_tiles
setblock 471 47 296 minecraft:cobbled_deepslate
fill 471 47 297 471 50 297 minecraft:deepslate_tiles
setblock 471 47 301 minecraft:cobbled_deepslate
fill 471 47 302 471 50 302 minecraft:deepslate_tiles
setblock 471 47 306 minecraft:cobbled_deepslate
fill 471 47 307 471 50 307 minecraft:deepslate_tiles
setblock 471 47 311 minecraft:cobbled_deepslate
fill 471 47 312 471 50 312 minecraft:deepslate_tiles
setblock 471 47 316 minecraft:cobbled_deepslate
setblock 472 47 276 minecraft:deepslate_tiles
setblock 472 47 285 minecraft:cobbled_deepslate
fill 472 47 286 472 50 286 minecraft:deepslate_tiles
setblock 472 47 290 minecraft:cobbled_deepslate
fill 472 47 291 472 50 291 minecraft:deepslate_tiles
setblock 472 47 295 minecraft:cobbled_deepslate
fill 472 47 296 472 50 296 minecraft:deepslate_tiles
setblock 472 47 300 minecraft:cobbled_deepslate
fill 472 47 301 472 50 301 minecraft:deepslate_tiles
setblock 472 47 305 minecraft:cobbled_deepslate
fill 472 47 306 472 50 306 minecraft:deepslate_tiles
setblock 472 47 310 minecraft:cobbled_deepslate
fill 472 47 311 472 50 311 minecraft:deepslate_tiles
setblock 472 47 314 minecraft:deepslate_tiles
setblock 472 47 315 minecraft:cobbled_deepslate
fill 472 47 316 472 50 316 minecraft:deepslate_tiles
setblock 473 47 289 minecraft:cobbled_deepslate
fill 473 47 290 473 48 290 minecraft:deepslate_tiles
setblock 473 47 304 minecraft:cobbled_deepslate
fill 473 47 305 473 49 305 minecraft:deepslate_tiles
setblock 473 47 309 minecraft:cobbled_deepslate
fill 473 47 310 473 50 310 minecraft:deepslate_tiles
setblock 473 47 314 minecraft:cobbled_deepslate
fill 473 47 315 473 50 315 minecraft:deepslate_tiles
setblock 474 47 304 minecraft:deepslate_tiles
setblock 474 47 308 minecraft:cobbled_deepslate
fill 474 47 309 474 48 309 minecraft:deepslate_tiles
setblock 476 47 316 minecraft:cobbled_deepslate
fill 489 47 316 490 47 316 minecraft:deepslate_tiles
setblock 490 47 277 minecraft:cobbled_deepslate
setblock 491 47 276 minecraft:cobbled_deepslate
fill 491 47 277 491 49 277 minecraft:deepslate_tiles
setblock 491 47 316 minecraft:cobbled_deepslate
fill 492 47 276 492 50 276 minecraft:deepslate_tiles
fill 492 47 316 492 50 316 minecraft:deepslate_tiles
setblock 495 47 277 minecraft:cobbled_deepslate
setblock 496 47 276 minecraft:cobbled_deepslate
setblock 496 47 316 minecraft:cobbled_deepslate
fill 497 47 276 497 49 276 minecraft:deepslate_tiles
setblock 502 47 276 minecraft:deepslate_tiles
fill 503 47 316 503 49 316 minecraft:deepslate_tiles
fill 504 47 287 505 48 287 minecraft:white_terracotta
setblock 505 47 316 minecraft:deepslate_tiles
setblock 506 47 276 minecraft:cobbled_deepslate
setblock 506 47 315 minecraft:deepslate_tiles
setblock 506 47 316 minecraft:cobbled_deepslate
fill 507 47 276 507 50 276 minecraft:deepslate_tiles
setblock 507 47 314 minecraft:deepslate_tiles
setblock 507 47 315 minecraft:cobbled_deepslate
fill 507 47 316 507 50 316 minecraft:deepslate_tiles
setblock 508 47 309 minecraft:cobbled_deepslate
fill 508 47 310 509 49 310 minecraft:deepslate_tiles
setblock 508 47 314 minecraft:cobbled_deepslate
fill 508 47 315 508 50 315 minecraft:deepslate_tiles
setblock 509 47 283 minecraft:cobbled_deepslate
fill 509 47 284 509 48 284 minecraft:deepslate_tiles
setblock 509 47 288 minecraft:cobbled_deepslate
fill 509 47 305 509 47 307 minecraft:deepslate_tiles
setblock 509 47 308 minecraft:cobbled_deepslate
fill 509 47 309 509 50 309 minecraft:deepslate_tiles
fill 509 47 311 509 47 312 minecraft:deepslate_tiles
setblock 509 47 313 minecraft:cobbled_deepslate
fill 509 47 314 509 50 314 minecraft:deepslate_tiles
setblock 510 47 277 minecraft:cobbled_deepslate
fill 510 47 278 510 48 278 minecraft:deepslate_tiles
setblock 510 47 282 minecraft:cobbled_deepslate
fill 510 47 283 510 49 283 minecraft:deepslate_tiles
setblock 510 47 287 minecraft:cobbled_deepslate
fill 510 47 288 510 50 288 minecraft:deepslate_tiles
setblock 510 47 291 minecraft:deepslate_tiles
setblock 510 47 292 minecraft:cobbled_deepslate
setblock 510 47 302 minecraft:cobbled_deepslate
fill 510 47 303 510 50 303 minecraft:deepslate_tiles
setblock 510 47 307 minecraft:cobbled_deepslate
fill 510 47 308 510 50 308 minecraft:deepslate_tiles
setblock 510 47 311 minecraft:deepslate_tiles
setblock 510 47 312 minecraft:cobbled_deepslate
fill 510 47 313 510 50 313 minecraft:deepslate_tiles
setblock 511 47 276 minecraft:cobbled_deepslate
fill 511 47 277 511 50 277 minecraft:deepslate_tiles
setblock 511 47 281 minecraft:cobbled_deepslate
fill 511 47 282 511 50 282 minecraft:deepslate_tiles
setblock 511 47 286 minecraft:cobbled_deepslate
fill 511 47 287 511 50 287 minecraft:deepslate_tiles
setblock 511 47 291 minecraft:cobbled_deepslate
fill 511 47 292 511 50 292 minecraft:deepslate_tiles
setblock 511 47 295 minecraft:deepslate_tiles
setblock 511 47 296 minecraft:cobbled_deepslate
fill 511 47 297 511 50 297 minecraft:deepslate_tiles
setblock 511 47 301 minecraft:cobbled_deepslate
fill 511 47 302 511 50 302 minecraft:deepslate_tiles
setblock 511 47 306 minecraft:cobbled_deepslate
fill 511 47 307 511 50 307 minecraft:deepslate_tiles
setblock 511 47 311 minecraft:cobbled_deepslate
fill 511 47 312 511 50 312 minecraft:deepslate_tiles
setblock 511 47 316 minecraft:cobbled_deepslate
setblock 471 48 276 minecraft:deepslate_tiles
setblock 471 48 280 minecraft:cobbled_deepslate
fill 471 48 281 471 49 281 minecraft:deepslate_tiles
setblock 471 48 285 minecraft:cobbled_deepslate
fill 471 48 286 471 51 286 minecraft:deepslate_tiles
setblock 471 48 290 minecraft:cobbled_deepslate
fill 471 48 291 471 51 291 minecraft:deepslate_tiles
setblock 471 48 294 minecraft:deepslate_tiles
setblock 471 48 295 minecraft:cobbled_deepslate
fill 471 48 296 471 51 296 minecraft:deepslate_tiles
setblock 471 48 300 minecraft:cobbled_deepslate
fill 471 48 301 471 51 301 minecraft:deepslate_tiles
setblock 471 48 305 minecraft:cobbled_deepslate
fill 471 48 306 471 51 306 minecraft:deepslate_tiles
setblock 471 48 310 minecraft:cobbled_deepslate
fill 471 48 311 471 51 311 minecraft:deepslate_tiles
setblock 471 48 315 minecraft:cobbled_deepslate
fill 471 48 316 471 51 316 minecraft:deepslate_tiles
setblock 472 48 284 minecraft:cobbled_deepslate
fill 472 48 285 472 49 285 minecraft:deepslate_tiles
setblock 472 48 288 minecraft:deepslate_tiles
setblock 472 48 289 minecraft:cobbled_deepslate
fill 472 48 290 472 51 290 minecraft:deepslate_tiles
setblock 472 48 294 minecraft:cobbled_deepslate
fill 472 48 295 472 51 295 minecraft:deepslate_tiles
setblock 472 48 299 minecraft:cobbled_deepslate
fill 472 48 300 472 50 300 minecraft:deepslate_tiles
setblock 472 48 304 minecraft:cobbled_deepslate
fill 472 48 305 472 51 305 minecraft:deepslate_tiles
setblock 472 48 309 minecraft:cobbled_deepslate
fill 472 48 310 472 51 310 minecraft:deepslate_tiles
setblock 472 48 314 minecraft:cobbled_deepslate
fill 472 48 315 472 51 315 minecraft:deepslate_tiles
setblock 473 48 288 minecraft:cobbled_deepslate
setblock 473 48 289 minecraft:deepslate_tiles
setblock 473 48 303 minecraft:cobbled_deepslate
fill 473 48 304 473 49 304 minecraft:deepslate_tiles
setblock 473 48 308 minecraft:cobbled_deepslate
fill 473 48 309 473 51 309 minecraft:deepslate_tiles
setblock 473 48 313 minecraft:cobbled_deepslate
setblock 473 48 314 minecraft:deepslate_tiles
setblock 474 48 307 minecraft:cobbled_deepslate
setblock 474 48 308 minecraft:deepslate_tiles
setblock 475 48 316 minecraft:cobbled_deepslate
fill 488 48 316 489 48 316 minecraft:deepslate_tiles
setblock 490 48 276 minecraft:cobbled_deepslate
fill 490 48 277 490 49 277 minecraft:deepslate_tiles
setblock 490 48 316 minecraft:cobbled_deepslate
fill 491 48 275 491 94 275 minecraft:cobbled_deepslate
fill 491 48 276 491 51 276 minecraft:deepslate_tiles
fill 491 48 316 491 51 316 minecraft:deepslate_tiles
setblock 492 48 275 minecraft:white_wool
fill 493 48 275 495 77 275 minecraft:cobbled_deepslate
setblock 494 48 277 minecraft:cobbled_deepslate
setblock 495 48 276 minecraft:cobbled_deepslate
setblock 495 48 316 minecraft:cobbled_deepslate
fill 496 48 276 496 50 276 minecraft:deepslate_tiles
setblock 496 48 316 minecraft:deepslate_tiles
setblock 505 48 276 minecraft:cobbled_deepslate
setblock 505 48 315 minecraft:deepslate_tiles
setblock 505 48 316 minecraft:cobbled_deepslate
fill 506 48 276 506 51 276 minecraft:deepslate_tiles
setblock 506 48 315 minecraft:cobbled_deepslate
fill 506 48 316 506 51 316 minecraft:deepslate_tiles
setblock 507 48 314 minecraft:cobbled_deepslate
fill 507 48 315 507 51 315 minecraft:deepslate_tiles
fill 508 48 309 508 50 309 minecraft:deepslate_tiles
fill 508 48 311 508 48 312 minecraft:deepslate_tiles
fill 508 48 314 508 51 314 minecraft:deepslate_tiles
setblock 509 48 277 minecraft:cobbled_deepslate
setblock 509 48 286 minecraft:deepslate_tiles
setblock 509 48 287 minecraft:cobbled_deepslate
setblock 509 48 288 minecraft:deepslate_tiles
fill 509 48 305 509 48 306 minecraft:deepslate_tiles
setblock 509 48 307 minecraft:cobbled_deepslate
fill 509 48 308 509 51 308 minecraft:deepslate_tiles
setblock 509 48 311 minecraft:deepslate_tiles
setblock 509 48 312 minecraft:cobbled_deepslate
fill 509 48 313 509 51 313 minecraft:deepslate_tiles
setblock 510 48 276 minecraft:cobbled_deepslate
fill 510 48 277 510 49 277 minecraft:deepslate_tiles
setblock 510 48 281 minecraft:cobbled_deepslate
fill 510 48 282 510 49 282 minecraft:deepslate_tiles
setblock 510 48 286 minecraft:cobbled_deepslate
fill 510 48 287 510 51 287 minecraft:deepslate_tiles
setblock 510 48 291 minecraft:cobbled_deepslate
fill 510 48 292 510 51 292 minecraft:deepslate_tiles
setblock 510 48 302 minecraft:deepslate_tiles
setblock 510 48 306 minecraft:cobbled_deepslate
fill 510 48 307 510 51 307 minecraft:deepslate_tiles
setblock 510 48 311 minecraft:cobbled_deepslate
fill 510 48 312 510 51 312 minecraft:deepslate_tiles
setblock 510 48 316 minecraft:cobbled_deepslate
fill 511 48 276 511 51 276 minecraft:deepslate_tiles
setblock 511 48 280 minecraft:cobbled_deepslate
fill 511 48 281 511 50 281 minecraft:deepslate_tiles
setblock 511 48 285 minecraft:cobbled_deepslate
fill 511 48 286 511 51 286 minecraft:deepslate_tiles
setblock 511 48 290 minecraft:cobbled_deepslate
fill 511 48 291 511 51 291 minecraft:deepslate_tiles
setblock 511 48 295 minecraft:cobbled_deepslate
fill 511 48 296 511 51 296 minecraft:deepslate_tiles
setblock 511 48 300 minecraft:cobbled_deepslate
fill 511 48 301 511 51 301 minecraft:deepslate_tiles
setblock 511 48 305 minecraft:cobbled_deepslate
fill 511 48 306 511 51 306 minecraft:deepslate_tiles
setblock 511 48 310 minecraft:cobbled_deepslate
fill 511 48 311 511 51 311 minecraft:deepslate_tiles
setblock 511 48 315 minecraft:cobbled_deepslate
fill 511 48 316 511 51 316 minecraft:deepslate_tiles
setblock 471 49 284 minecraft:cobbled_deepslate
fill 471 49 285 471 51 285 minecraft:deepslate_tiles
setblock 471 49 289 minecraft:cobbled_deepslate
fill 471 49 290 471 52 290 minecraft:deepslate_tiles
setblock 471 49 294 minecraft:cobbled_deepslate
fill 471 49 295 471 52 295 minecraft:deepslate_tiles
setblock 471 49 299 minecraft:cobbled_deepslate
fill 471 49 300 471 52 300 minecraft:deepslate_tiles
setblock 471 49 304 minecraft:cobbled_deepslate
fill 471 49 305 471 52 305 minecraft:deepslate_tiles
setblock 471 49 309 minecraft:cobbled_deepslate
fill 471 49 310 471 52 310 minecraft:deepslate_tiles
setblock 471 49 314 minecraft:cobbled_deepslate
fill 471 49 315 471 52 315 minecraft:deepslate_tiles
setblock 472 49 288 minecraft:cobbled_deepslate
fill 472 49 289 472 52 289 minecraft:deepslate_tiles
setblock 472 49 293 minecraft:cobbled_deepslate
fill 472 49 294 472 52 294 minecraft:deepslate_tiles
setblock 472 49 298 minecraft:cobbled_deepslate
setblock 472 49 299 minecraft:deepslate_tiles
setblock 472 49 303 minecraft:cobbled_deepslate
fill 472 49 304 472 51 304 minecraft:deepslate_tiles
setblock 472 49 308 minecraft:cobbled_deepslate
fill 472 49 309 472 52 309 minecraft:deepslate_tiles
setblock 472 49 313 minecraft:cobbled_deepslate
fill 472 49 314 472 52 314 minecraft:deepslate_tiles
setblock 473 49 278 minecraft:light[level=12]
setblock 473 49 285 minecraft:light[level=12]
setblock 473 49 292 minecraft:light[level=12]
setblock 473 49 299 minecraft:light[level=12]
setblock 473 49 307 minecraft:cobbled_deepslate
fill 473 49 308 473 51 308 minecraft:deepslate_tiles
setblock 473 49 312 minecraft:cobbled_deepslate
fill 473 49 313 473 50 313 minecraft:deepslate_tiles
setblock 474 49 316 minecraft:cobbled_deepslate
setblock 475 49 316 minecraft:deepslate_tiles
fill 478 49 313 478 54 313 minecraft:black_concrete
fill 479 49 312 479 54 312 minecraft:black_concrete
fill 479 49 314 479 54 314 minecraft:black_concrete
setblock 480 49 278 minecraft:light[level=12]
setblock 480 49 285 minecraft:light[level=12]
setblock 480 49 292 minecraft:light[level=12]
setblock 480 49 299 minecraft:light[level=12]
setblock 480 49 306 minecraft:light[level=12]
fill 480 49 313 480 54 313 minecraft:black_concrete
fill 487 49 276 487 50 276 minecraft:deepslate_tiles
setblock 487 49 278 minecraft:light[level=12]
setblock 487 49 285 minecraft:light[level=12]
setblock 487 49 292 minecraft:light[level=12]
setblock 487 49 299 minecraft:light[level=12]
setblock 487 49 306 minecraft:light[level=12]
setblock 487 49 313 minecraft:light[level=12]
fill 487 49 316 488 49 316 minecraft:deepslate_tiles
setblock 489 49 276 minecraft:cobbled_deepslate
setblock 489 49 316 minecraft:cobbled_deepslate
fill 490 49 276 490 52 276 minecraft:deepslate_tiles
fill 490 49 316 490 52 316 minecraft:deepslate_tiles
fill 492 49 275 492 91 275 minecraft:cobbled_deepslate
setblock 494 49 276 minecraft:cobbled_deepslate
setblock 494 49 278 minecraft:light[level=12]
setblock 494 49 285 minecraft:light[level=12]
setblock 494 49 292 minecraft:light[level=12]
setblock 494 49 299 minecraft:light[level=12]
setblock 494 49 306 minecraft:light[level=12]
setblock 494 49 313 minecraft:light[level=12]
setblock 494 49 316 minecraft:cobbled_deepslate
fill 495 49 276 495 51 276 minecraft:deepslate_tiles
fill 495 49 316 495 52 316 minecraft:deepslate_tiles
setblock 501 49 278 minecraft:light[level=12]
setblock 501 49 285 minecraft:light[level=12]
setblock 501 49 292 minecraft:light[level=12]
setblock 501 49 299 minecraft:light[level=12]
setblock 501 49 306 minecraft:light[level=12]
setblock 501 49 313 minecraft:light[level=12]
fill 502 49 316 502 50 316 minecraft:deepslate_tiles
setblock 504 49 276 minecraft:cobbled_deepslate
setblock 504 49 315 minecraft:deepslate_tiles
setblock 504 49 316 minecraft:cobbled_deepslate
fill 505 49 276 505 52 276 minecraft:deepslate_tiles
setblock 505 49 315 minecraft:cobbled_deepslate
fill 505 49 316 505 52 316 minecraft:deepslate_tiles
setblock 506 49 314 minecraft:cobbled_deepslate
fill 506 49 315 506 52 315 minecraft:deepslate_tiles
fill 507 49 314 507 52 314 minecraft:deepslate_tiles
setblock 508 49 277 minecraft:cobbled_deepslate
setblock 508 49 278 minecraft:light[level=12]
setblock 508 49 285 minecraft:light[level=12]
setblock 508 49 292 minecraft:light[level=12]
setblock 508 49 299 minecraft:light[level=12]
setblock 508 49 306 minecraft:light[level=12]
setblock 508 49 311 minecraft:deepslate_tiles
setblock 508 49 312 minecraft:cobbled_deepslate
fill 508 49 313 508 52 313 minecraft:deepslate_tiles
setblock 509 49 276 minecraft:cobbled_deepslate
setblock 509 49 277 minecraft:deepslate_tiles
setblock 509 49 305 minecraft:deepslate_tiles
setblock 509 49 306 minecraft:cobbled_deepslate
fill 509 49 307 509 51 307 minecraft:deepslate_tiles
setblock 509 49 311 minecraft:cobbled_deepslate
fill 509 49 312 509 52 312 minecraft:deepslate_tiles
setblock 509 49 316 minecraft:cobbled_deepslate
fill 510 49 276 510 52 276 minecraft:deepslate_tiles
setblock 510 49 281 minecraft:deepslate_tiles
setblock 510 49 285 minecraft:cobbled_deepslate
fill 510 49 286 510 50 286 minecraft:deepslate_tiles
setblock 510 49 290 minecraft:cobbled_deepslate
fill 510 49 291 510 52 291 minecraft:deepslate_tiles
setblock 510 49 305 minecraft:cobbled_deepslate
fill 510 49 306 510 52 306 minecraft:deepslate_tiles
setblock 510 49 310 minecraft:cobbled_deepslate
fill 510 49 311 510 52 311 minecraft:deepslate_tiles
setblock 510 49 315 minecraft:cobbled_deepslate
fill 510 49 316 510 52 316 minecraft:deepslate_tiles
setblock 511 49 279 minecraft:cobbled_deepslate
fill 511 49 280 511 50 280 minecraft:deepslate_tiles
setblock 511 49 284 minecraft:cobbled_deepslate
fill 511 49 285 511 51 285 minecraft:deepslate_tiles
setblock 511 49 289 minecraft:cobbled_deepslate
fill 511 49 290 511 52 290 minecraft:deepslate_tiles
setblock 511 49 294 minecraft:cobbled_deepslate
fill 511 49 295 511 52 295 minecraft:deepslate_tiles
setblock 511 49 299 minecraft:cobbled_deepslate
fill 511 49 300 511 50 300 minecraft:deepslate_tiles
setblock 511 49 304 minecraft:cobbled_deepslate
fill 511 49 305 511 52 305 minecraft:deepslate_tiles
setblock 511 49 309 minecraft:cobbled_deepslate
fill 511 49 310 511 52 310 minecraft:deepslate_tiles
setblock 511 49 314 minecraft:cobbled_deepslate
fill 511 49 315 511 52 315 minecraft:deepslate_tiles
setblock 471 50 283 minecraft:cobbled_deepslate
fill 471 50 284 471 51 284 minecraft:deepslate_tiles
setblock 471 50 288 minecraft:cobbled_deepslate
fill 471 50 289 471 53 289 minecraft:deepslate_tiles
setblock 471 50 293 minecraft:cobbled_deepslate
fill 471 50 294 471 53 294 minecraft:deepslate_tiles
setblock 471 50 298 minecraft:cobbled_deepslate
fill 471 50 299 471 53 299 minecraft:deepslate_tiles
setblock 471 50 303 minecraft:cobbled_deepslate
fill 471 50 304 471 53 304 minecraft:deepslate_tiles
setblock 471 50 308 minecraft:cobbled_deepslate
fill 471 50 309 471 53 309 minecraft:deepslate_tiles
setblock 471 50 313 minecraft:cobbled_deepslate
fill 471 50 314 471 53 314 minecraft:deepslate_tiles
setblock 472 50 287 minecraft:cobbled_deepslate
fill 472 50 288 472 51 288 minecraft:deepslate_tiles
setblock 472 50 292 minecraft:cobbled_deepslate
fill 472 50 293 472 53 293 minecraft:deepslate_tiles
setblock 472 50 297 minecraft:cobbled_deepslate
setblock 472 50 302 minecraft:cobbled_deepslate
fill 472 50 303 472 51 303 minecraft:deepslate_tiles
setblock 472 50 307 minecraft:cobbled_deepslate
fill 472 50 308 472 53 308 minecraft:deepslate_tiles
setblock 472 50 312 minecraft:cobbled_deepslate
fill 472 50 313 472 53 313 minecraft:deepslate_tiles
setblock 473 50 306 minecraft:cobbled_deepslate
setblock 473 50 307 minecraft:deepslate_tiles
setblock 473 50 311 minecraft:cobbled_deepslate
setblock 473 50 312 minecraft:deepslate_tiles
setblock 473 50 316 minecraft:cobbled_deepslate
fill 474 50 316 474 51 316 minecraft:deepslate_tiles
setblock 487 50 316 minecraft:deepslate_tiles
setblock 488 50 276 minecraft:cobbled_deepslate
setblock 488 50 316 minecraft:cobbled_deepslate
fill 489 50 276 489 53 276 minecraft:deepslate_tiles
fill 489 50 316 489 53 316 minecraft:deepslate_tiles
setblock 493 50 276 minecraft:cobbled_deepslate
setblock 493 50 316 minecraft:cobbled_deepslate
fill 494 50 276 494 53 276 minecraft:deepslate_tiles
fill 494 50 316 494 53 316 minecraft:deepslate_tiles
fill 501 50 316 501 51 316 minecraft:deepslate_tiles
setblock 503 50 276 minecraft:cobbled_deepslate
setblock 503 50 316 minecraft:cobbled_deepslate
fill 504 50 276 504 53 276 minecraft:deepslate_tiles
setblock 504 50 315 minecraft:cobbled_deepslate
fill 504 50 316 504 53 316 minecraft:deepslate_tiles
fill 505 50 315 505 53 315 minecraft:deepslate_tiles
fill 506 50 314 506 53 314 minecraft:deepslate_tiles
setblock 508 50 276 minecraft:cobbled_deepslate
setblock 508 50 310 minecraft:deepslate_tiles
setblock 508 50 311 minecraft:cobbled_deepslate
fill 508 50 312 508 53 312 minecraft:deepslate_tiles
setblock 508 50 316 minecraft:cobbled_deepslate
fill 509 50 276 509 53 276 minecraft:deepslate_tiles
setblock 509 50 306 minecraft:deepslate_tiles
setblock 509 50 310 minecraft:cobbled_deepslate
fill 509 50 311 509 53 311 minecraft:deepslate_tiles
setblock 509 50 315 minecraft:cobbled_deepslate
fill 509 50 316 509 53 316 minecraft:deepslate_tiles
setblock 510 50 284 minecraft:cobbled_deepslate
setblock 510 50 285 minecraft:deepslate_tiles
setblock 510 50 289 minecraft:cobbled_deepslate
fill 510 50 290 510 52 290 minecraft:deepslate_tiles
setblock 510 50 304 minecraft:cobbled_deepslate
fill 510 50 305 510 52 305 minecraft:deepslate_tiles
setblock 510 50 309 minecraft:cobbled_deepslate
fill 510 50 310 510 53 310 minecraft:deepslate_tiles
setblock 510 50 314 minecraft:cobbled_deepslate
fill 510 50 315 510 53 315 minecraft:deepslate_tiles
setblock 511 50 278 minecraft:cobbled_deepslate
setblock 511 50 279 minecraft:deepslate_tiles
setblock 511 50 283 minecraft:cobbled_deepslate
fill 511 50 284 511 51 284 minecraft:deepslate_tiles
setblock 511 50 288 minecraft:cobbled_deepslate
fill 511 50 289 511 53 289 minecraft:deepslate_tiles
setblock 511 50 293 minecraft:cobbled_deepslate
fill 511 50 294 511 53 294 minecraft:deepslate_tiles
setblock 511 50 298 minecraft:cobbled_deepslate
setblock 511 50 299 minecraft:deepslate_tiles
setblock 511 50 303 minecraft:cobbled_deepslate
fill 511 50 304 511 53 304 minecraft:deepslate_tiles
setblock 511 50 308 minecraft:cobbled_deepslate
fill 511 50 309 511 53 309 minecraft:deepslate_tiles
setblock 511 50 313 minecraft:cobbled_deepslate
fill 511 50 314 511 53 314 minecraft:deepslate_tiles
setblock 471 51 287 minecraft:cobbled_deepslate
fill 471 51 288 471 54 288 minecraft:deepslate_tiles
setblock 471 51 292 minecraft:cobbled_deepslate
fill 471 51 293 471 54 293 minecraft:deepslate_tiles
setblock 471 51 297 minecraft:cobbled_deepslate
fill 471 51 298 471 54 298 minecraft:deepslate_tiles
setblock 471 51 302 minecraft:cobbled_deepslate
fill 471 51 303 471 54 303 minecraft:deepslate_tiles
setblock 471 51 307 minecraft:cobbled_deepslate
fill 471 51 308 471 54 308 minecraft:deepslate_tiles
setblock 471 51 312 minecraft:cobbled_deepslate
fill 471 51 313 471 54 313 minecraft:deepslate_tiles
setblock 472 51 287 minecraft:deepslate_tiles
setblock 472 51 291 minecraft:cobbled_deepslate
fill 472 51 292 472 54 292 minecraft:deepslate_tiles
setblock 472 51 296 minecraft:cobbled_deepslate
setblock 472 51 306 minecraft:cobbled_deepslate
fill 472 51 307 472 53 307 minecraft:deepslate_tiles
setblock 472 51 311 minecraft:cobbled_deepslate
fill 472 51 312 472 54 312 minecraft:deepslate_tiles
setblock 472 51 316 minecraft:cobbled_deepslate
setblock 473 51 310 minecraft:cobbled_deepslate
setblock 473 51 311 minecraft:deepslate_tiles
setblock 473 51 315 minecraft:cobbled_deepslate
fill 473 51 316 473 54 316 minecraft:deepslate_tiles
fill 478 51 312 478 54 312 minecraft:black_concrete
fill 478 51 314 478 54 314 minecraft:black_concrete
fill 480 51 312 480 54 312 minecraft:black_concrete
fill 480 51 314 480 54 314 minecraft:black_concrete
setblock 486 51 316 minecraft:deepslate_tiles
setblock 487 51 276 minecraft:cobbled_deepslate
setblock 487 51 316 minecraft:cobbled_deepslate
fill 488 51 276 488 54 276 minecraft:deepslate_tiles
fill 488 51 316 488 54 316 minecraft:deepslate_tiles
setblock 492 51 276 minecraft:cobbled_deepslate
setblock 492 51 316 minecraft:cobbled_deepslate
fill 493 51 276 493 54 276 minecraft:deepslate_tiles
fill 493 51 316 493 54 316 minecraft:deepslate_tiles
setblock 502 51 316 minecraft:cobbled_deepslate
fill 503 51 276 503 54 276 minecraft:deepslate_tiles
setblock 503 51 315 minecraft:cobbled_deepslate
fill 503 51 316 503 54 316 minecraft:deepslate_tiles
fill 504 51 315 504 54 315 minecraft:deepslate_tiles
fill 505 51 314 505 54 314 minecraft:deepslate_tiles
setblock 507 51 276 minecraft:cobbled_deepslate
fill 507 51 313 507 53 313 minecraft:deepslate_tiles
setblock 507 51 316 minecraft:cobbled_deepslate
fill 508 51 276 508 54 276 minecraft:deepslate_tiles
setblock 508 51 310 minecraft:cobbled_deepslate
fill 508 51 311 508 54 311 minecraft:deepslate_tiles
setblock 508 51 315 minecraft:cobbled_deepslate
fill 508 51 316 508 54 316 minecraft:deepslate_tiles
setblock 509 51 309 minecraft:cobbled_deepslate
fill 509 51 310 509 54 310 minecraft:deepslate_tiles
setblock 509 51 314 minecraft:cobbled_deepslate
fill 509 51 315 509 54 315 minecraft:deepslate_tiles
setblock 510 51 288 minecraft:cobbled_deepslate
fill 510 51 289 510 52 289 minecraft:deepslate_tiles
setblock 510 51 304 minecraft:deepslate_tiles
setblock 510 51 308 minecraft:cobbled_deepslate
fill 510 51 309 510 54 309 minecraft:deepslate_tiles
setblock 510 51 313 minecraft:cobbled_deepslate
fill 510 51 314 510 54 314 minecraft:deepslate_tiles
setblock 511 51 277 minecraft:cobbled_deepslate
setblock 511 51 283 minecraft:deepslate_tiles
setblock 511 51 287 minecraft:cobbled_deepslate
fill 511 51 288 511 54 288 minecraft:deepslate_tiles
setblock 511 51 292 minecraft:cobbled_deepslate
fill 511 51 293 511 54 293 minecraft:deepslate_tiles
setblock 511 51 297 minecraft:cobbled_deepslate
setblock 511 51 302 minecraft:cobbled_deepslate
fill 511 51 303 511 54 303 minecraft:deepslate_tiles
setblock 511 51 307 minecraft:cobbled_deepslate
fill 511 51 308 511 54 308 minecraft:deepslate_tiles
setblock 511 51 312 minecraft:cobbled_deepslate
fill 511 51 313 511 54 313 minecraft:deepslate_tiles
setblock 471 52 286 minecraft:cobbled_deepslate
fill 471 52 287 471 54 287 minecraft:deepslate_tiles
setblock 471 52 291 minecraft:cobbled_deepslate
fill 471 52 292 471 55 292 minecraft:deepslate_tiles
setblock 471 52 296 minecraft:cobbled_deepslate
fill 471 52 297 471 55 297 minecraft:deepslate_tiles
setblock 471 52 301 minecraft:cobbled_deepslate
fill 471 52 302 471 55 302 minecraft:deepslate_tiles
setblock 471 52 306 minecraft:cobbled_deepslate
fill 471 52 307 471 55 307 minecraft:deepslate_tiles
setblock 471 52 311 minecraft:cobbled_deepslate
fill 471 52 312 471 55 312 minecraft:deepslate_tiles
setblock 471 52 316 minecraft:cobbled_deepslate
setblock 472 52 290 minecraft:cobbled_deepslate
fill 472 52 291 472 55 291 minecraft:deepslate_tiles
setblock 472 52 295 minecraft:cobbled_deepslate
fill 472 52 296 472 55 296 minecraft:deepslate_tiles
setblock 472 52 305 minecraft:cobbled_deepslate
setblock 472 52 306 minecraft:deepslate_tiles
setblock 472 52 310 minecraft:cobbled_deepslate
fill 472 52 311 472 55 311 minecraft:deepslate_tiles
setblock 472 52 315 minecraft:cobbled_deepslate
fill 472 52 316 472 55 316 minecraft:deepslate_tiles
setblock 485 52 316 minecraft:deepslate_tiles
setblock 486 52 276 minecraft:cobbled_deepslate
setblock 486 52 316 minecraft:cobbled_deepslate
fill 487 52 276 487 55 276 minecraft:deepslate_tiles
fill 487 52 316 487 55 316 minecraft:deepslate_tiles
fill 489 52 315 489 54 315 minecraft:deepslate_tiles
setblock 491 52 276 minecraft:cobbled_deepslate
setblock 491 52 316 minecraft:cobbled_deepslate
fill 492 52 276 492 55 276 minecraft:deepslate_tiles
fill 492 52 316 492 55 316 minecraft:deepslate_tiles
setblock 500 52 316 minecraft:deepslate_tiles
setblock 501 52 316 minecraft:cobbled_deepslate
fill 502 52 276 502 55 276 minecraft:deepslate_tiles
setblock 502 52 315 minecraft:cobbled_deepslate
fill 502 52 316 502 55 316 minecraft:deepslate_tiles
fill 503 52 315 503 55 315 minecraft:deepslate_tiles
fill 504 52 314 504 55 314 minecraft:deepslate_tiles
setblock 506 52 276 minecraft:cobbled_deepslate
setblock 506 52 316 minecraft:cobbled_deepslate
fill 507 52 276 507 55 276 minecraft:deepslate_tiles
setblock 507 52 315 minecraft:cobbled_deepslate
fill 507 52 316 507 55 316 minecraft:deepslate_tiles
setblock 508 52 314 minecraft:cobbled_deepslate
fill 508 52 315 508 55 315 minecraft:deepslate_tiles
setblock 509 52 308 minecraft:cobbled_deepslate
fill 509 52 309 509 55 309 minecraft:deepslate_tiles
setblock 509 52 313 minecraft:cobbled_deepslate
fill 509 52 314 509 55 314 minecraft:deepslate_tiles
setblock 510 52 292 minecraft:cobbled_deepslate
setblock 510 52 307 minecraft:cobbled_deepslate
fill 510 52 308 510 55 308 minecraft:deepslate_tiles
setblock 510 52 312 minecraft:cobbled_deepslate
fill 510 52 313 510 55 313 minecraft:deepslate_tiles
setblock 511 52 276 minecraft:cobbled_deepslate
setblock 511 52 286 minecraft:cobbled_deepslate
fill 511 52 287 511 53 287 minecraft:deepslate_tiles
setblock 511 52 291 minecraft:cobbled_deepslate
fill 511 52 292 511 55 292 minecraft:deepslate_tiles
setblock 511 52 296 minecraft:cobbled_deepslate
fill 511 52 297 511 55 297 minecraft:deepslate_tiles
setblock 511 52 302 minecraft:deepslate_tiles
setblock 511 52 306 minecraft:cobbled_deepslate
fill 511 52 307 511 55 307 minecraft:deepslate_tiles
setblock 511 52 311 minecraft:cobbled_deepslate
fill 511 52 312 511 55 312 minecraft:deepslate_tiles
setblock 511 52 316 minecraft:cobbled_deepslate
fill 470 53 292 470 94 292 minecraft:cobbled_deepslate
setblock 470 53 293 minecraft:white_wool
setblock 471 53 286 minecraft:deepslate_tiles
setblock 471 53 290 minecraft:cobbled_deepslate
fill 471 53 291 471 56 291 minecraft:deepslate_tiles
setblock 471 53 295 minecraft:cobbled_deepslate
fill 471 53 296 471 56 296 minecraft:deepslate_tiles
setblock 471 53 300 minecraft:cobbled_deepslate
fill 471 53 301 471 56 301 minecraft:deepslate_tiles
setblock 471 53 305 minecraft:cobbled_deepslate
fill 471 53 306 471 56 306 minecraft:deepslate_tiles
setblock 471 53 310 minecraft:cobbled_deepslate
fill 471 53 311 471 56 311 minecraft:deepslate_tiles
setblock 471 53 315 minecraft:cobbled_deepslate
fill 471 53 316 471 56 316 minecraft:deepslate_tiles
setblock 472 53 289 minecraft:cobbled_deepslate
fill 472 53 290 472 56 290 minecraft:deepslate_tiles
setblock 472 53 294 minecraft:cobbled_deepslate
fill 472 53 295 472 56 295 minecraft:deepslate_tiles
setblock 472 53 309 minecraft:cobbled_deepslate
fill 472 53 310 472 54 310 minecraft:deepslate_tiles
setblock 472 53 314 minecraft:cobbled_deepslate
setblock 472 53 315 minecraft:deepslate_tiles
setblock 473 53 278 minecraft:light[level=13]
setblock 473 53 286 minecraft:light[level=13]
setblock 473 53 294 minecraft:light[level=13]
setblock 473 53 302 minecraft:light[level=13]
setblock 473 53 310 minecraft:light[level=13]
setblock 481 53 278 minecraft:light[level=13]
setblock 481 53 286 minecraft:light[level=13]
setblock 481 53 294 minecraft:light[level=13]
setblock 481 53 302 minecraft:light[level=13]
setblock 481 53 310 minecraft:light[level=13]
setblock 484 53 316 minecraft:deepslate_tiles
setblock 485 53 276 minecraft:cobbled_deepslate
setblock 485 53 316 minecraft:cobbled_deepslate
fill 486 53 276 486 56 276 minecraft:deepslate_tiles
fill 486 53 316 486 56 316 minecraft:deepslate_tiles
fill 488 53 315 488 55 315 minecraft:deepslate_tiles
setblock 489 53 278 minecraft:light[level=13]
setblock 489 53 286 minecraft:light[level=13]
setblock 489 53 294 minecraft:light[level=13]
setblock 489 53 302 minecraft:light[level=13]
setblock 489 53 310 minecraft:light[level=13]
setblock 490 53 276 minecraft:cobbled_deepslate
setblock 490 53 315 minecraft:deepslate_tiles
setblock 490 53 316 minecraft:cobbled_deepslate
fill 491 53 276 491 56 276 minecraft:deepslate_tiles
fill 491 53 316 491 56 316 minecraft:deepslate_tiles
setblock 495 53 276 minecraft:cobbled_deepslate
setblock 495 53 316 minecraft:cobbled_deepslate
setblock 497 53 278 minecraft:light[level=13]
setblock 497 53 286 minecraft:light[level=13]
setblock 497 53 294 minecraft:light[level=13]
setblock 497 53 302 minecraft:light[level=13]
setblock 497 53 310 minecraft:light[level=13]
fill 498 53 316 499 53 316 minecraft:deepslate_tiles
setblock 500 53 316 minecraft:cobbled_deepslate
fill 501 53 276 501 56 276 minecraft:deepslate_tiles
fill 501 53 316 501 56 316 minecraft:deepslate_tiles
fill 502 53 315 502 56 315 minecraft:deepslate_tiles
setblock 505 53 276 minecraft:cobbled_deepslate
setblock 505 53 278 minecraft:light[level=13]
setblock 505 53 286 minecraft:light[level=13]
setblock 505 53 294 minecraft:light[level=13]
setblock 505 53 302 minecraft:light[level=13]
setblock 505 53 310 minecraft:light[level=13]
setblock 505 53 316 minecraft:cobbled_deepslate
fill 506 53 276 506 56 276 minecraft:deepslate_tiles
setblock 506 53 315 minecraft:cobbled_deepslate
fill 506 53 316 506 56 316 minecraft:deepslate_tiles
setblock 507 53 314 minecraft:cobbled_deepslate
fill 507 53 315 507 56 315 minecraft:deepslate_tiles
setblock 508 53 313 minecraft:cobbled_deepslate
fill 508 53 314 508 56 314 minecraft:deepslate_tiles
setblock 509 53 308 minecraft:deepslate_tiles
setblock 509 53 312 minecraft:cobbled_deepslate
fill 509 53 313 509 56 313 minecraft:deepslate_tiles
setblock 510 53 276 minecraft:cobbled_deepslate
setblock 510 53 291 minecraft:cobbled_deepslate
fill 510 53 292 510 56 292 minecraft:deepslate_tiles
setblock 510 53 306 minecraft:cobbled_deepslate
fill 510 53 307 510 56 307 minecraft:deepslate_tiles
setblock 510 53 311 minecraft:cobbled_deepslate
fill 510 53 312 510 56 312 minecraft:deepslate_tiles
setblock 510 53 316 minecraft:cobbled_deepslate
fill 511 53 276 511 56 276 minecraft:deepslate_tiles
setblock 511 53 290 minecraft:cobbled_deepslate
fill 511 53 291 511 56 291 minecraft:deepslate_tiles
setblock 511 53 295 minecraft:cobbled_deepslate
fill 511 53 296 511 56 296 minecraft:deepslate_tiles
fill 511 53 298 511 54 298 minecraft:deepslate_tiles
setblock 511 53 305 minecraft:cobbled_deepslate
fill 511 53 306 511 56 306 minecraft:deepslate_tiles
setblock 511 53 310 minecraft:cobbled_deepslate
fill 511 53 311 511 56 311 minecraft:deepslate_tiles
setblock 511 53 315 minecraft:cobbled_deepslate
fill 511 53 316 511 56 316 minecraft:deepslate_tiles
fill 470 54 293 470 92 293 minecraft:cobbled_deepslate
setblock 471 54 289 minecraft:cobbled_deepslate
fill 471 54 290 471 57 290 minecraft:deepslate_tiles
setblock 471 54 294 minecraft:cobbled_deepslate
fill 471 54 295 471 57 295 minecraft:deepslate_tiles
setblock 471 54 299 minecraft:cobbled_deepslate
fill 471 54 300 471 57 300 minecraft:deepslate_tiles
setblock 471 54 304 minecraft:cobbled_deepslate
fill 471 54 305 471 57 305 minecraft:deepslate_tiles
setblock 471 54 309 minecraft:cobbled_deepslate
fill 471 54 310 471 57 310 minecraft:deepslate_tiles
setblock 471 54 314 minecraft:cobbled_deepslate
fill 471 54 315 471 57 315 minecraft:deepslate_tiles
setblock 472 54 293 minecraft:cobbled_deepslate
fill 472 54 294 472 57 294 minecraft:deepslate_tiles
setblock 472 54 297 minecraft:deepslate_tiles
setblock 472 54 309 minecraft:deepslate_tiles
setblock 472 54 313 minecraft:cobbled_deepslate
fill 472 54 314 472 55 314 minecraft:deepslate_tiles
setblock 477 54 313 minecraft:black_concrete
setblock 479 54 311 minecraft:black_concrete
setblock 479 54 315 minecraft:black_concrete
setblock 481 54 313 minecraft:black_concrete
setblock 483 54 316 minecraft:deepslate_tiles
setblock 484 54 276 minecraft:cobbled_deepslate
setblock 484 54 316 minecraft:cobbled_deepslate
fill 485 54 276 485 57 276 minecraft:deepslate_tiles
fill 485 54 316 485 57 316 minecraft:deepslate_tiles
fill 486 54 315 487 56 315 minecraft:deepslate_tiles
setblock 487 54 277 minecraft:deepslate_tiles
setblock 488 54 277 minecraft:cobbled_deepslate
setblock 489 54 276 minecraft:cobbled_deepslate
fill 489 54 277 490 56 277 minecraft:deepslate_tiles
setblock 489 54 316 minecraft:cobbled_deepslate
fill 490 54 276 490 57 276 minecraft:deepslate_tiles
setblock 490 54 315 minecraft:cobbled_deepslate
fill 490 54 316 490 57 316 minecraft:deepslate_tiles
fill 491 54 315 491 57 315 minecraft:deepslate_tiles
setblock 494 54 276 minecraft:cobbled_deepslate
setblock 494 54 316 minecraft:cobbled_deepslate
fill 495 54 276 496 56 276 minecraft:deepslate_tiles
fill 495 54 316 498 54 316 minecraft:deepslate_tiles
setblock 499 54 276 minecraft:cobbled_deepslate
setblock 499 54 316 minecraft:cobbled_deepslate
fill 500 54 276 500 57 276 minecraft:deepslate_tiles
fill 500 54 316 500 57 316 minecraft:deepslate_tiles
fill 501 54 315 501 57 315 minecraft:deepslate_tiles
fill 503 54 314 503 56 314 minecraft:deepslate_tiles
setblock 504 54 276 minecraft:cobbled_deepslate
setblock 504 54 316 minecraft:cobbled_deepslate
fill 505 54 276 505 57 276 minecraft:deepslate_tiles
setblock 505 54 315 minecraft:cobbled_deepslate
fill 505 54 316 505 57 316 minecraft:deepslate_tiles
setblock 506 54 313 minecraft:deepslate_tiles
setblock 506 54 314 minecraft:cobbled_deepslate
fill 506 54 315 506 57 315 minecraft:deepslate_tiles
setblock 507 54 313 minecraft:cobbled_deepslate
fill 507 54 314 507 57 314 minecraft:deepslate_tiles
setblock 508 54 312 minecraft:cobbled_deepslate
fill 508 54 313 508 57 313 minecraft:deepslate_tiles
setblock 509 54 276 minecraft:cobbled_deepslate
setblock 509 54 311 minecraft:cobbled_deepslate
fill 509 54 312 509 57 312 minecraft:deepslate_tiles
setblock 509 54 316 minecraft:cobbled_deepslate
fill 510 54 276 510 57 276 minecraft:deepslate_tiles
fill 510 54 293 510 54 294 minecraft:deepslate_tiles
setblock 510 54 306 minecraft:deepslate_tiles
setblock 510 54 310 minecraft:cobbled_deepslate
fill 510 54 311 510 57 311 minecraft:deepslate_tiles
setblock 510 54 315 minecraft:cobbled_deepslate
fill 510 54 316 510 57 316 minecraft:deepslate_tiles
setblock 511 54 289 minecraft:cobbled_deepslate
fill 511 54 290 511 57 290 minecraft:deepslate_tiles
setblock 511 54 294 minecraft:cobbled_deepslate
fill 511 54 295 511 57 295 minecraft:deepslate_tiles
setblock 511 54 299 minecraft:cobbled_deepslate
setblock 511 54 304 minecraft:cobbled_deepslate
fill 511 54 305 511 57 305 minecraft:deepslate_tiles
setblock 511 54 309 minecraft:cobbled_deepslate
fill 511 54 310 511 57 310 minecraft:deepslate_tiles
setblock 511 54 314 minecraft:cobbled_deepslate
fill 511 54 315 511 57 315 minecraft:deepslate_tiles
setblock 471 55 288 minecraft:cobbled_deepslate
fill 471 55 289 471 58 289 minecraft:deepslate_tiles
setblock 471 55 293 minecraft:cobbled_deepslate
fill 471 55 294 471 58 294 minecraft:deepslate_tiles
setblock 471 55 298 minecraft:cobbled_deepslate
fill 471 55 299 471 58 299 minecraft:deepslate_tiles
setblock 471 55 303 minecraft:cobbled_deepslate
fill 471 55 304 471 58 304 minecraft:deepslate_tiles
setblock 471 55 308 minecraft:cobbled_deepslate
fill 471 55 309 471 58 309 minecraft:deepslate_tiles
setblock 471 55 313 minecraft:cobbled_deepslate
fill 471 55 314 471 58 314 minecraft:deepslate_tiles
setblock 472 55 292 minecraft:cobbled_deepslate
fill 472 55 293 472 58 293 minecraft:deepslate_tiles
setblock 472 55 297 minecraft:cobbled_deepslate
fill 472 55 298 472 58 298 minecraft:deepslate_tiles
setblock 472 55 312 minecraft:cobbled_deepslate
setblock 472 55 313 minecraft:deepslate_tiles
setblock 473 55 278 minecraft:light[level=12]
setblock 473 55 285 minecraft:light[level=12]
setblock 473 55 292 minecraft:light[level=12]
setblock 473 55 299 minecraft:light[level=12]
setblock 473 55 306 minecraft:light[level=12]
setblock 473 55 313 minecraft:light[level=12]
setblock 473 55 316 minecraft:cobbled_deepslate
setblock 480 55 278 minecraft:light[level=12]
setblock 480 55 285 minecraft:light[level=12]
setblock 480 55 292 minecraft:light[level=12]
setblock 480 55 299 minecraft:light[level=12]
setblock 480 55 306 minecraft:light[level=12]
setblock 480 55 313 minecraft:light[level=12]
setblock 482 55 316 minecraft:deepslate_tiles
setblock 483 55 276 minecraft:cobbled_deepslate
setblock 483 55 316 minecraft:cobbled_deepslate
fill 484 55 276 484 58 276 minecraft:deepslate_tiles
fill 484 55 316 484 58 316 minecraft:deepslate_tiles
fill 485 55 277 486 55 277 minecraft:deepslate_tiles
fill 485 55 315 485 58 315 minecraft:deepslate_tiles
setblock 487 55 277 minecraft:cobbled_deepslate
setblock 487 55 278 minecraft:light[level=12]
setblock 487 55 285 minecraft:light[level=12]
setblock 487 55 292 minecraft:light[level=12]
setblock 487 55 299 minecraft:light[level=12]
setblock 487 55 306 minecraft:light[level=12]
setblock 487 55 313 minecraft:light[level=12]
setblock 488 55 276 minecraft:cobbled_deepslate
fill 488 55 277 488 58 277 minecraft:deepslate_tiles
setblock 488 55 316 minecraft:cobbled_deepslate
fill 489 55 276 489 58 276 minecraft:deepslate_tiles
setblock 489 55 315 minecraft:cobbled_deepslate
fill 489 55 316 489 58 316 minecraft:deepslate_tiles
fill 490 55 315 490 58 315 minecraft:deepslate_tiles
setblock 491 55 277 minecraft:deepslate_tiles
setblock 493 55 276 minecraft:cobbled_deepslate
setblock 493 55 316 minecraft:cobbled_deepslate
fill 494 55 276 494 58 276 minecraft:deepslate_tiles
setblock 494 55 278 minecraft:light[level=12]
setblock 494 55 285 minecraft:light[level=12]
setblock 494 55 292 minecraft:light[level=12]
setblock 494 55 299 minecraft:light[level=12]
setblock 494 55 306 minecraft:light[level=12]
setblock 494 55 313 minecraft:light[level=12]
fill 494 55 316 497 55 316 minecraft:deepslate_tiles
setblock 497 55 276 minecraft:deepslate_tiles
setblock 498 55 276 minecraft:cobbled_deepslate
setblock 498 55 316 minecraft:cobbled_deepslate
fill 499 55 276 499 58 276 minecraft:deepslate_tiles
setblock 499 55 315 minecraft:cobbled_deepslate
fill 499 55 316 499 58 316 minecraft:deepslate_tiles
fill 499 55 317 499 90 317 minecraft:cobbled_deepslate
fill 500 55 315 500 58 315 minecraft:deepslate_tiles
setblock 500 55 317 minecraft:redstone_block
setblock 501 55 278 minecraft:light[level=12]
setblock 501 55 285 minecraft:light[level=12]
setblock 501 55 292 minecraft:light[level=12]
setblock 501 55 299 minecraft:light[level=12]
setblock 501 55 306 minecraft:light[level=12]
setblock 501 55 313 minecraft:light[level=12]
fill 501 55 317 504 90 317 minecraft:cobbled_deepslate
fill 502 55 314 502 57 314 minecraft:deepslate_tiles
setblock 503 55 276 minecraft:cobbled_deepslate
setblock 503 55 316 minecraft:cobbled_deepslate
fill 504 55 276 504 57 277 minecraft:deepslate_tiles
setblock 504 55 315 minecraft:cobbled_deepslate
fill 504 55 316 504 58 316 minecraft:deepslate_tiles
fill 505 55 277 506 55 277 minecraft:deepslate_tiles
setblock 505 55 313 minecraft:deepslate_tiles
setblock 505 55 314 minecraft:cobbled_deepslate
fill 505 55 315 505 58 315 minecraft:deepslate_tiles
setblock 506 55 313 minecraft:cobbled_deepslate
fill 506 55 314 506 58 314 minecraft:deepslate_tiles
setblock 507 55 277 minecraft:cobbled_deepslate
fill 507 55 313 507 58 313 minecraft:deepslate_tiles
fill 507 55 317 509 90 317 minecraft:cobbled_deepslate
setblock 508 55 276 minecraft:cobbled_deepslate
fill 508 55 277 508 58 277 minecraft:deepslate_tiles
setblock 508 55 278 minecraft:light[level=12]
setblock 508 55 285 minecraft:light[level=12]
setblock 508 55 292 minecraft:light[level=12]
setblock 508 55 299 minecraft:light[level=12]
setblock 508 55 306 minecraft:light[level=12]
fill 508 55 312 508 58 312 minecraft:deepslate_tiles
setblock 508 55 316 minecraft:cobbled_deepslate
fill 509 55 276 509 58 276 minecraft:deepslate_tiles
setblock 509 55 310 minecraft:cobbled_deepslate
fill 509 55 311 509 58 311 minecraft:deepslate_tiles
setblock 509 55 315 minecraft:cobbled_deepslate
fill 509 55 316 509 58 316 minecraft:deepslate_tiles
setblock 510 55 293 minecraft:deepslate_tiles
setblock 510 55 294 minecraft:cobbled_deepslate
fill 510 55 295 510 57 296 minecraft:deepslate_tiles
setblock 510 55 309 minecraft:cobbled_deepslate
fill 510 55 310 510 58 310 minecraft:deepslate_tiles
setblock 510 55 314 minecraft:cobbled_deepslate
fill 510 55 315 510 58 315 minecraft:deepslate_tiles
setblock 510 55 317 minecraft:white_wool
fill 511 55 289 511 56 289 minecraft:deepslate_tiles
setblock 511 55 293 minecraft:cobbled_deepslate
fill 511 55 294 511 58 294 minecraft:deepslate_tiles
setblock 511 55 298 minecraft:cobbled_deepslate
fill 511 55 299 511 55 302 minecraft:deepslate_tiles
setblock 511 55 303 minecraft:cobbled_deepslate
fill 511 55 304 511 58 304 minecraft:deepslate_tiles
setblock 511 55 308 minecraft:cobbled_deepslate
fill 511 55 309 511 58 309 minecraft:deepslate_tiles
setblock 511 55 313 minecraft:cobbled_deepslate
fill 511 55 314 511 58 314 minecraft:deepslate_tiles
fill 511 55 317 512 63 317 minecraft:cobbled_deepslate
fill 471 56 288 471 59 288 minecraft:deepslate_tiles
setblock 471 56 292 minecraft:cobbled_deepslate
fill 471 56 293 471 59 293 minecraft:deepslate_tiles
setblock 471 56 297 minecraft:cobbled_deepslate
fill 471 56 298 471 59 298 minecraft:deepslate_tiles
setblock 471 56 302 minecraft:cobbled_deepslate
fill 471 56 303 471 59 303 minecraft:deepslate_tiles
setblock 471 56 307 minecraft:cobbled_deepslate
fill 471 56 308 471 59 308 minecraft:deepslate_tiles
setblock 471 56 312 minecraft:cobbled_deepslate
fill 471 56 313 471 59 313 minecraft:deepslate_tiles
setblock 472 56 291 minecraft:cobbled_deepslate
fill 472 56 292 472 59 292 minecraft:deepslate_tiles
setblock 472 56 296 minecraft:cobbled_deepslate
fill 472 56 297 472 59 297 minecraft:deepslate_tiles
fill 472 56 299 472 57 299 minecraft:deepslate_tiles
setblock 472 56 316 minecraft:cobbled_deepslate
fill 473 56 316 473 59 316 minecraft:deepslate_tiles
setblock 481 56 276 minecraft:deepslate_tiles
setblock 481 56 316 minecraft:deepslate_tiles
setblock 482 56 276 minecraft:cobbled_deepslate
setblock 482 56 316 minecraft:cobbled_deepslate
fill 483 56 276 483 59 276 minecraft:deepslate_tiles
setblock 483 56 315 minecraft:cobbled_deepslate
fill 483 56 316 483 59 316 minecraft:deepslate_tiles
fill 484 56 277 485 56 277 minecraft:deepslate_tiles
fill 484 56 315 484 59 315 minecraft:deepslate_tiles
setblock 486 56 277 minecraft:cobbled_deepslate
setblock 487 56 276 minecraft:cobbled_deepslate
fill 487 56 277 487 59 277 minecraft:deepslate_tiles
setblock 487 56 316 minecraft:cobbled_deepslate
fill 488 56 276 488 59 276 minecraft:deepslate_tiles
setblock 488 56 315 minecraft:cobbled_deepslate
fill 488 56 316 488 59 316 minecraft:deepslate_tiles
fill 489 56 315 489 59 315 minecraft:deepslate_tiles
setblock 491 56 277 minecraft:cobbled_deepslate
setblock 492 56 276 minecraft:cobbled_deepslate
fill 492 56 277 492 59 277 minecraft:deepslate_tiles
setblock 492 56 315 minecraft:deepslate_tiles
setblock 492 56 316 minecraft:cobbled_deepslate
fill 493 56 276 493 59 276 minecraft:deepslate_tiles
fill 493 56 316 496 56 316 minecraft:deepslate_tiles
setblock 497 56 276 minecraft:cobbled_deepslate
setblock 497 56 316 minecraft:cobbled_deepslate
fill 498 56 276 498 59 276 minecraft:deepslate_tiles
setblock 498 56 315 minecraft:cobbled_deepslate
fill 498 56 316 498 59 316 minecraft:deepslate_tiles
fill 499 56 315 499 59 315 minecraft:deepslate_tiles
fill 500 56 317 500 95 317 minecraft:cobbled_deepslate
setblock 501 56 277 minecraft:cobbled_deepslate
fill 501 56 314 501 58 314 minecraft:deepslate_tiles
setblock 502 56 276 minecraft:cobbled_deepslate
fill 502 56 277 503 58 277 minecraft:deepslate_tiles
setblock 502 56 316 minecraft:cobbled_deepslate
fill 503 56 276 503 59 276 minecraft:deepslate_tiles
setblock 503 56 315 minecraft:cobbled_deepslate
fill 503 56 316 503 59 316 minecraft:deepslate_tiles
setblock 504 56 313 minecraft:deepslate_tiles
setblock 504 56 314 minecraft:cobbled_deepslate
fill 504 56 315 504 59 315 minecraft:deepslate_tiles
setblock 505 56 277 minecraft:deepslate_tiles
setblock 505 56 313 minecraft:cobbled_deepslate
fill 505 56 314 505 59 314 minecraft:deepslate_tiles
setblock 506 56 277 minecraft:cobbled_deepslate
fill 506 56 313 506 59 313 minecraft:deepslate_tiles
fill 507 56 275 507 56 276 minecraft:cobbled_deepslate
fill 507 56 277 507 59 277 minecraft:deepslate_tiles
setblock 507 56 316 minecraft:cobbled_deepslate
fill 508 56 275 510 94 275 minecraft:cobbled_deepslate
fill 508 56 276 508 59 276 minecraft:deepslate_tiles
setblock 508 56 315 minecraft:cobbled_deepslate
fill 508 56 316 508 59 316 minecraft:deepslate_tiles
setblock 509 56 309 minecraft:cobbled_deepslate
fill 509 56 310 509 58 310 minecraft:deepslate_tiles
setblock 509 56 314 minecraft:cobbled_deepslate
fill 509 56 315 509 59 315 minecraft:deepslate_tiles
setblock 510 56 293 minecraft:cobbled_deepslate
fill 510 56 294 510 59 294 minecraft:deepslate_tiles
setblock 510 56 297 minecraft:deepslate_tiles
setblock 510 56 298 minecraft:cobbled_deepslate
setblock 510 56 308 minecraft:cobbled_deepslate
fill 510 56 309 510 59 309 minecraft:deepslate_tiles
setblock 510 56 313 minecraft:cobbled_deepslate
fill 510 56 314 510 59 314 minecraft:deepslate_tiles
fill 510 56 317 510 94 317 minecraft:cobbled_deepslate
setblock 511 56 275 minecraft:white_wool
setblock 511 56 277 minecraft:cobbled_deepslate
setblock 511 56 292 minecraft:cobbled_deepslate
fill 511 56 293 511 59 293 minecraft:deepslate_tiles
setblock 511 56 297 minecraft:cobbled_deepslate
fill 511 56 298 511 56 301 minecraft:deepslate_tiles
setblock 511 56 302 minecraft:cobbled_deepslate
fill 511 56 303 511 59 303 minecraft:deepslate_tiles
setblock 511 56 307 minecraft:cobbled_deepslate
fill 511 56 308 511 59 308 minecraft:deepslate_tiles
setblock 511 56 312 minecraft:cobbled_deepslate
fill 511 56 313 511 59 313 minecraft:deepslate_tiles
fill 512 56 275 512 90 275 minecraft:cobbled_deepslate
setblock 471 57 291 minecraft:cobbled_deepslate
fill 471 57 292 471 60 292 minecraft:deepslate_tiles
setblock 471 57 296 minecraft:cobbled_deepslate
fill 471 57 297 471 60 297 minecraft:deepslate_tiles
setblock 471 57 301 minecraft:cobbled_deepslate
fill 471 57 302 471 60 302 minecraft:deepslate_tiles
setblock 471 57 306 minecraft:cobbled_deepslate
fill 471 57 307 471 59 307 minecraft:deepslate_tiles
setblock 471 57 311 minecraft:cobbled_deepslate
fill 471 57 312 471 60 312 minecraft:deepslate_tiles
setblock 471 57 316 minecraft:cobbled_deepslate
fill 472 57 291 472 60 291 minecraft:deepslate_tiles
setblock 472 57 295 minecraft:cobbled_deepslate
fill 472 57 296 472 60 296 minecraft:deepslate_tiles
setblock 472 57 300 minecraft:cobbled_deepslate
fill 472 57 316 472 60 316 minecraft:deepslate_tiles
fill 479 57 276 480 57 276 minecraft:deepslate_tiles
fill 479 57 316 480 57 316 minecraft:deepslate_tiles
setblock 481 57 276 minecraft:cobbled_deepslate
setblock 481 57 316 minecraft:cobbled_deepslate
fill 482 57 276 482 59 277 minecraft:deepslate_tiles
setblock 482 57 315 minecraft:cobbled_deepslate
fill 482 57 316 482 60 316 minecraft:deepslate_tiles
fill 483 57 277 484 57 277 minecraft:deepslate_tiles
fill 483 57 315 483 60 315 minecraft:deepslate_tiles
setblock 485 57 277 minecraft:cobbled_deepslate
fill 485 57 278 488 57 278 minecraft:deepslate_tiles
setblock 486 57 276 minecraft:cobbled_deepslate
fill 486 57 277 486 60 277 minecraft:deepslate_tiles
setblock 486 57 315 minecraft:deepslate_tiles
setblock 486 57 316 minecraft:cobbled_deepslate
fill 487 57 276 487 60 276 minecraft:deepslate_tiles
setblock 487 57 315 minecraft:cobbled_deepslate
fill 487 57 316 487 60 316 minecraft:deepslate_tiles
fill 488 57 315 488 60 315 minecraft:deepslate_tiles
setblock 489 57 277 minecraft:deepslate_tiles
setblock 489 57 278 minecraft:cobbled_deepslate
setblock 490 57 277 minecraft:cobbled_deepslate
setblock 491 57 276 minecraft:cobbled_deepslate
fill 491 57 277 491 60 277 minecraft:deepslate_tiles
setblock 491 57 316 minecraft:cobbled_deepslate
fill 492 57 276 492 60 276 minecraft:deepslate_tiles
setblock 492 57 315 minecraft:cobbled_deepslate
fill 492 57 316 495 57 316 minecraft:deepslate_tiles
fill 493 57 277 494 57 277 minecraft:deepslate_tiles
fill 493 57 315 493 60 315 minecraft:deepslate_tiles
setblock 495 57 276 minecraft:deepslate_tiles
setblock 496 57 276 minecraft:cobbled_deepslate
setblock 496 57 315 minecraft:deepslate_tiles
setblock 496 57 316 minecraft:cobbled_deepslate
fill 497 57 276 497 60 276 minecraft:deepslate_tiles
setblock 497 57 315 minecraft:cobbled_deepslate
fill 497 57 316 497 60 316 minecraft:deepslate_tiles
fill 498 57 315 498 60 315 minecraft:deepslate_tiles
setblock 499 57 277 minecraft:deepslate_tiles
setblock 500 57 277 minecraft:cobbled_deepslate
fill 500 57 314 500 59 314 minecraft:deepslate_tiles
setblock 501 57 276 minecraft:cobbled_deepslate
fill 501 57 277 501 60 277 minecraft:deepslate_tiles
setblock 501 57 316 minecraft:cobbled_deepslate
fill 502 57 276 502 60 276 minecraft:deepslate_tiles
setblock 502 57 315 minecraft:cobbled_deepslate
fill 502 57 316 502 60 316 minecraft:deepslate_tiles
setblock 503 57 313 minecraft:deepslate_tiles
setblock 503 57 314 minecraft:cobbled_deepslate
fill 503 57 315 503 60 315 minecraft:deepslate_tiles
setblock 504 57 313 minecraft:cobbled_deepslate
fill 504 57 314 504 60 314 minecraft:deepslate_tiles
setblock 505 57 277 minecraft:cobbled_deepslate
fill 505 57 313 505 60 313 minecraft:deepslate_tiles
setblock 506 57 276 minecraft:cobbled_deepslate
fill 506 57 277 506 60 277 minecraft:deepslate_tiles
setblock 506 57 316 minecraft:cobbled_deepslate
fill 507 57 275 507 91 275 minecraft:cobbled_deepslate
fill 507 57 276 507 60 276 minecraft:deepslate_tiles
setblock 507 57 315 minecraft:cobbled_deepslate
fill 507 57 316 507 60 316 minecraft:deepslate_tiles
setblock 508 57 314 minecraft:cobbled_deepslate
fill 508 57 315 508 60 315 minecraft:deepslate_tiles
setblock 509 57 277 minecraft:deepslate_tiles
setblock 509 57 313 minecraft:cobbled_deepslate
fill 509 57 314 509 60 314 minecraft:deepslate_tiles
setblock 510 57 292 minecraft:cobbled_deepslate
fill 510 57 293 510 60 293 minecraft:deepslate_tiles
setblock 510 57 297 minecraft:cobbled_deepslate
fill 510 57 298 511 57 300 minecraft:deepslate_tiles
setblock 510 57 307 minecraft:cobbled_deepslate
fill 510 57 308 510 59 308 minecraft:deepslate_tiles
setblock 510 57 312 minecraft:cobbled_deepslate
fill 510 57 313 510 60 313 minecraft:deepslate_tiles
fill 511 57 275 511 57 276 minecraft:cobbled_deepslate
fill 511 57 277 511 60 277 minecraft:deepslate_tiles
setblock 511 57 291 minecraft:cobbled_deepslate
fill 511 57 292 511 60 292 minecraft:deepslate_tiles
setblock 511 57 296 minecraft:cobbled_deepslate
fill 511 57 297 511 60 297 minecraft:deepslate_tiles
setblock 511 57 301 minecraft:cobbled_deepslate
fill 511 57 302 511 60 302 minecraft:deepslate_tiles
setblock 511 57 306 minecraft:cobbled_deepslate
fill 511 57 307 511 60 307 minecraft:deepslate_tiles
setblock 511 57 311 minecraft:cobbled_deepslate
fill 511 57 312 511 60 312 minecraft:deepslate_tiles
setblock 511 57 316 minecraft:cobbled_deepslate
fill 471 58 276 471 61 276 minecraft:deepslate_tiles
setblock 471 58 290 minecraft:cobbled_deepslate
fill 471 58 291 471 61 291 minecraft:deepslate_tiles
setblock 471 58 295 minecraft:cobbled_deepslate
fill 471 58 296 471 61 296 minecraft:deepslate_tiles
setblock 471 58 300 minecraft:cobbled_deepslate
fill 471 58 301 471 61 301 minecraft:deepslate_tiles
setblock 471 58 305 minecraft:cobbled_deepslate
fill 471 58 306 471 60 306 minecraft:deepslate_tiles
setblock 471 58 310 minecraft:cobbled_deepslate
fill 471 58 311 471 59 311 minecraft:deepslate_tiles
setblock 471 58 315 minecraft:cobbled_deepslate
fill 471 58 316 471 61 316 minecraft:deepslate_tiles
setblock 472 58 294 minecraft:cobbled_deepslate
fill 472 58 295 473 60 295 minecraft:deepslate_tiles
setblock 472 58 299 minecraft:cobbled_deepslate
fill 472 58 300 472 61 300 minecraft:deepslate_tiles
fill 473 58 294 473 60 294 minecraft:deepslate_tiles
fill 473 58 296 473 59 296 minecraft:deepslate_tiles
setblock 474 58 316 minecraft:deepslate_tiles
fill 477 58 316 479 58 316 minecraft:deepslate_tiles
fill 478 58 276 479 58 276 minecraft:deepslate_tiles
setblock 480 58 276 minecraft:cobbled_deepslate
fill 480 58 277 481 60 277 minecraft:deepslate_tiles
setblock 480 58 316 minecraft:cobbled_deepslate
fill 481 58 276 481 61 276 minecraft:deepslate_tiles
setblock 481 58 315 minecraft:cobbled_deepslate
fill 481 58 316 481 61 316 minecraft:deepslate_tiles
fill 482 58 315 482 61 315 minecraft:deepslate_tiles
setblock 483 58 277 minecraft:deepslate_tiles
setblock 483 58 278 minecraft:cobbled_deepslate
setblock 484 58 277 minecraft:cobbled_deepslate
fill 484 58 278 487 58 278 minecraft:deepslate_tiles
setblock 485 58 276 minecraft:cobbled_deepslate
fill 485 58 277 485 61 277 minecraft:deepslate_tiles
setblock 485 58 316 minecraft:cobbled_deepslate
fill 486 58 276 486 61 276 minecraft:deepslate_tiles
setblock 486 58 315 minecraft:cobbled_deepslate
fill 486 58 316 486 61 316 minecraft:deepslate_tiles
fill 487 58 315 487 61 315 minecraft:deepslate_tiles
setblock 488 58 278 minecraft:cobbled_deepslate
setblock 489 58 277 minecraft:cobbled_deepslate
fill 489 58 278 490 60 278 minecraft:deepslate_tiles
setblock 490 58 276 minecraft:cobbled_deepslate
fill 490 58 277 490 61 277 minecraft:deepslate_tiles
setblock 490 58 316 minecraft:cobbled_deepslate
fill 491 58 276 491 61 276 minecraft:deepslate_tiles
setblock 491 58 315 minecraft:cobbled_deepslate
fill 491 58 316 494 58 316 minecraft:deepslate_tiles
fill 492 58 315 492 61 315 minecraft:deepslate_tiles
setblock 493 58 277 minecraft:deepslate_tiles
setblock 494 58 277 minecraft:cobbled_deepslate
fill 494 58 315 495 58 315 minecraft:deepslate_tiles
setblock 495 58 276 minecraft:cobbled_deepslate
fill 495 58 277 498 58 277 minecraft:deepslate_tiles
setblock 495 58 316 minecraft:cobbled_deepslate
fill 496 58 276 496 61 276 minecraft:deepslate_tiles
setblock 496 58 315 minecraft:cobbled_deepslate
fill 496 58 316 496 61 316 minecraft:deepslate_tiles
fill 497 58 315 497 61 315 minecraft:deepslate_tiles
setblock 499 58 277 minecraft:cobbled_deepslate
fill 499 58 314 499 60 314 minecraft:deepslate_tiles
setblock 500 58 276 minecraft:cobbled_deepslate
fill 500 58 277 500 61 277 minecraft:deepslate_tiles
setblock 500 58 316 minecraft:cobbled_deepslate
fill 501 58 276 501 61 276 minecraft:deepslate_tiles
setblock 501 58 315 minecraft:cobbled_deepslate
fill 501 58 316 501 61 316 minecraft:deepslate_tiles
setblock 502 58 314 minecraft:cobbled_deepslate
fill 502 58 315 502 61 315 minecraft:deepslate_tiles
setblock 503 58 278 minecraft:cobbled_deepslate
setblock 503 58 313 minecraft:cobbled_deepslate
fill 503 58 314 503 61 314 minecraft:deepslate_tiles
setblock 504 58 276 minecraft:deepslate_tiles
setblock 504 58 277 minecraft:cobbled_deepslate
fill 504 58 278 505 60 278 minecraft:deepslate_tiles
fill 504 58 313 504 61 313 minecraft:deepslate_tiles
setblock 505 58 276 minecraft:cobbled_deepslate
fill 505 58 277 505 61 277 minecraft:deepslate_tiles
setblock 505 58 316 minecraft:cobbled_deepslate
fill 506 58 276 506 61 276 minecraft:deepslate_tiles
setblock 506 58 315 minecraft:cobbled_deepslate
fill 506 58 316 506 61 316 minecraft:deepslate_tiles
setblock 507 58 314 minecraft:cobbled_deepslate
fill 507 58 315 507 61 315 minecraft:deepslate_tiles
setblock 508 58 313 minecraft:cobbled_deepslate
fill 508 58 314 508 61 314 minecraft:deepslate_tiles
setblock 509 58 277 minecraft:cobbled_deepslate
fill 509 58 295 509 58 296 minecraft:deepslate_tiles
setblock 509 58 297 minecraft:cobbled_deepslate
setblock 509 58 312 minecraft:cobbled_deepslate
fill 509 58 313 509 60 313 minecraft:deepslate_tiles
setblock 510 58 276 minecraft:cobbled_deepslate
fill 510 58 292 510 59 292 minecraft:deepslate_tiles
setblock 510 58 295 minecraft:deepslate_tiles
setblock 510 58 296 minecraft:cobbled_deepslate
fill 510 58 297 510 58 300 minecraft:deepslate_tiles
setblock 510 58 301 minecraft:cobbled_deepslate
fill 510 58 302 510 61 302 minecraft:deepslate_tiles
fill 510 58 307 510 59 307 minecraft:deepslate_tiles
setblock 510 58 311 minecraft:cobbled_deepslate
fill 510 58 312 510 61 312 minecraft:deepslate_tiles
setblock 510 58 316 minecraft:cobbled_deepslate
fill 511 58 275 511 92 275 minecraft:cobbled_deepslate
fill 511 58 276 511 61 276 minecraft:deepslate_tiles
fill 511 58 278 511 59 278 minecraft:deepslate_tiles
setblock 511 58 290 minecraft:cobbled_deepslate
fill 511 58 291 511 60 291 minecraft:deepslate_tiles
setblock 511 58 295 minecraft:cobbled_deepslate
fill 511 58 296 511 61 296 minecraft:deepslate_tiles
fill 511 58 298 511 58 299 minecraft:deepslate_tiles
setblock 511 58 300 minecraft:cobbled_deepslate
fill 511 58 301 511 61 301 minecraft:deepslate_tiles
setblock 511 58 305 minecraft:cobbled_deepslate
fill 511 58 306 511 61 306 minecraft:deepslate_tiles
setblock 511 58 310 minecraft:cobbled_deepslate
fill 511 58 311 511 61 311 minecraft:deepslate_tiles
setblock 511 58 315 minecraft:cobbled_deepslate
fill 511 58 316 511 61 316 minecraft:deepslate_tiles
fill 471 59 277 471 60 277 minecraft:deepslate_tiles
setblock 471 59 289 minecraft:cobbled_deepslate
fill 471 59 290 471 62 290 minecraft:deepslate_tiles
setblock 471 59 294 minecraft:cobbled_deepslate
fill 471 59 295 471 62 295 minecraft:deepslate_tiles
setblock 471 59 299 minecraft:cobbled_deepslate
fill 471 59 300 471 62 300 minecraft:deepslate_tiles
setblock 471 59 304 minecraft:cobbled_deepslate
fill 471 59 305 471 62 305 minecraft:deepslate_tiles
setblock 471 59 309 minecraft:cobbled_deepslate
setblock 471 59 310 minecraft:deepslate_tiles
setblock 471 59 314 minecraft:cobbled_deepslate
fill 471 59 315 471 61 315 minecraft:deepslate_tiles
fill 472 59 276 472 60 276 minecraft:deepslate_tiles
setblock 472 59 293 minecraft:cobbled_deepslate
fill 472 59 294 472 62 294 minecraft:deepslate_tiles
setblock 472 59 298 minecraft:cobbled_deepslate
fill 472 59 299 472 62 299 minecraft:deepslate_tiles
fill 472 59 301 472 60 301 minecraft:deepslate_tiles
setblock 473 59 297 minecraft:cobbled_deepslate
setblock 474 59 316 minecraft:cobbled_deepslate
fill 475 59 316 478 59 316 minecraft:deepslate_tiles
fill 476 59 275 478 94 275 minecraft:cobbled_deepslate
fill 476 59 276 478 59 276 minecraft:deepslate_tiles
setblock 479 59 275 minecraft:redstone_block
setblock 479 59 276 minecraft:cobbled_deepslate
fill 479 59 277 479 62 277 minecraft:deepslate_tiles
setblock 479 59 316 minecraft:cobbled_deepslate
fill 480 59 275 480 95 275 minecraft:cobbled_deepslate
fill 480 59 276 480 62 276 minecraft:deepslate_tiles
setblock 480 59 315 minecraft:cobbled_deepslate
fill 480 59 316 480 62 316 minecraft:deepslate_tiles
setblock 481 59 278 minecraft:deepslate_tiles
fill 481 59 315 481 62 315 minecraft:deepslate_tiles
setblock 482 59 278 minecraft:cobbled_deepslate
setblock 483 59 277 minecraft:cobbled_deepslate
fill 483 59 278 486 59 278 minecraft:deepslate_tiles
fill 483 59 306 484 60 307 minecraft:white_wool
setblock 484 59 276 minecraft:cobbled_deepslate
fill 484 59 277 484 62 277 minecraft:deepslate_tiles
fill 484 59 308 484 60 308 minecraft:white_wool
setblock 484 59 316 minecraft:cobbled_deepslate
fill 485 59 276 485 62 276 minecraft:deepslate_tiles
setblock 485 59 315 minecraft:cobbled_deepslate
fill 485 59 316 485 62 316 minecraft:deepslate_tiles
fill 486 59 315 486 62 315 minecraft:deepslate_tiles
setblock 487 59 278 minecraft:cobbled_deepslate
setblock 488 59 277 minecraft:cobbled_deepslate
fill 488 59 278 488 62 278 minecraft:deepslate_tiles
setblock 489 59 276 minecraft:cobbled_deepslate
fill 489 59 277 489 62 277 minecraft:deepslate_tiles
setblock 489 59 316 minecraft:cobbled_deepslate
fill 490 59 276 490 62 276 minecraft:deepslate_tiles
setblock 490 59 315 minecraft:cobbled_deepslate
fill 490 59 316 493 59 316 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_3 1t
