setblock 48 115 331 minecraft:stripped_dark_oak_log
setblock 48 115 338 minecraft:stripped_dark_oak_log
setblock 48 115 345 minecraft:stripped_dark_oak_log
setblock 48 115 352 minecraft:stripped_dark_oak_log
setblock 48 115 359 minecraft:stripped_dark_oak_log
setblock 51 115 335 minecraft:cherry_leaves[persistent=true]
fill 51 115 337 51 116 338 minecraft:cherry_leaves[persistent=true]
setblock 51 115 363 minecraft:stripped_dark_oak_log
fill 52 115 338 52 117 338 minecraft:cherry_leaves[persistent=true]
fill 53 115 335 53 117 335 minecraft:cherry_leaves[persistent=true]
setblock 54 115 323 minecraft:stripped_dark_oak_log
fill 54 115 336 54 117 336 minecraft:cherry_leaves[persistent=true]
setblock 58 115 363 minecraft:stripped_dark_oak_log
setblock 61 115 323 minecraft:stripped_dark_oak_log
setblock 65 115 363 minecraft:stripped_dark_oak_log
setblock 68 115 323 minecraft:stripped_dark_oak_log
fill 68 115 328 70 116 328 minecraft:cherry_leaves[persistent=true]
fill 68 115 331 70 116 331 minecraft:cherry_leaves[persistent=true]
fill 69 115 327 69 116 327 minecraft:cherry_leaves[persistent=true]
fill 71 115 329 71 115 330 minecraft:cherry_leaves[persistent=true]
setblock 72 115 363 minecraft:stripped_dark_oak_log
setblock 75 115 323 minecraft:stripped_dark_oak_log
setblock 79 115 363 minecraft:stripped_dark_oak_log
fill 81 115 348 81 118 348 minecraft:dark_oak_planks
fill 81 115 351 81 118 351 minecraft:dark_oak_planks
setblock 82 115 323 minecraft:stripped_dark_oak_log
fill 82 115 352 82 118 352 minecraft:dark_oak_planks
fill 83 115 347 84 118 347 minecraft:dark_oak_planks
fill 85 115 352 85 118 352 minecraft:dark_oak_planks
fill 86 115 349 86 118 350 minecraft:dark_oak_planks
setblock 86 115 363 minecraft:stripped_dark_oak_log
setblock 88 115 324 minecraft:stripped_dark_oak_log
setblock 88 115 331 minecraft:stripped_dark_oak_log
setblock 88 115 338 minecraft:stripped_dark_oak_log
setblock 88 115 345 minecraft:stripped_dark_oak_log
setblock 88 115 352 minecraft:stripped_dark_oak_log
setblock 88 115 359 minecraft:stripped_dark_oak_log
setblock 48 116 325 minecraft:stripped_dark_oak_log
setblock 48 116 332 minecraft:stripped_dark_oak_log
setblock 48 116 339 minecraft:stripped_dark_oak_log
setblock 48 116 346 minecraft:stripped_dark_oak_log
setblock 48 116 353 minecraft:stripped_dark_oak_log
setblock 48 116 360 minecraft:stripped_dark_oak_log
setblock 50 116 337 minecraft:cherry_leaves[persistent=true]
setblock 52 116 363 minecraft:stripped_dark_oak_log
setblock 53 116 323 minecraft:stripped_dark_oak_log
fill 54 116 335 54 117 335 minecraft:cherry_leaves[persistent=true]
setblock 59 116 363 minecraft:stripped_dark_oak_log
setblock 60 116 323 minecraft:stripped_dark_oak_log
setblock 66 116 363 minecraft:stripped_dark_oak_log
setblock 67 116 323 minecraft:stripped_dark_oak_log
setblock 71 116 330 minecraft:cherry_leaves[persistent=true]
setblock 73 116 363 minecraft:stripped_dark_oak_log
setblock 74 116 323 minecraft:stripped_dark_oak_log
fill 80 116 349 80 118 350 minecraft:dark_oak_planks
setblock 80 116 363 minecraft:stripped_dark_oak_log
setblock 81 116 323 minecraft:stripped_dark_oak_log
fill 81 116 352 81 118 352 minecraft:dark_oak_planks
fill 82 116 347 82 118 347 minecraft:dark_oak_planks
fill 82 116 357 82 116 358 minecraft:dark_oak_planks
setblock 82 116 360 minecraft:dark_oak_planks
fill 83 116 353 84 118 353 minecraft:dark_oak_planks
fill 83 116 357 85 116 357 minecraft:dark_oak_planks
fill 83 116 361 85 116 361 minecraft:dark_oak_planks
fill 85 116 347 85 118 347 minecraft:dark_oak_planks
fill 86 116 348 86 118 348 minecraft:dark_oak_planks
fill 86 116 351 86 118 351 minecraft:dark_oak_planks
fill 86 116 358 86 116 360 minecraft:dark_oak_planks
setblock 87 116 363 minecraft:stripped_dark_oak_log
setblock 88 116 323 minecraft:stripped_dark_oak_log
setblock 88 116 330 minecraft:stripped_dark_oak_log
setblock 88 116 337 minecraft:stripped_dark_oak_log
setblock 88 116 344 minecraft:stripped_dark_oak_log
setblock 88 116 351 minecraft:stripped_dark_oak_log
setblock 88 116 358 minecraft:stripped_dark_oak_log
setblock 89 116 332 minecraft:red_concrete
fill 89 116 333 89 142 336 minecraft:dark_oak_planks
setblock 48 117 326 minecraft:stripped_dark_oak_log
setblock 48 117 333 minecraft:stripped_dark_oak_log
setblock 48 117 340 minecraft:stripped_dark_oak_log
setblock 48 117 347 minecraft:stripped_dark_oak_log
setblock 48 117 354 minecraft:stripped_dark_oak_log
setblock 48 117 361 minecraft:stripped_dark_oak_log
fill 51 117 337 53 117 337 minecraft:cherry_leaves[persistent=true]
setblock 52 117 323 minecraft:stripped_dark_oak_log
setblock 53 117 363 minecraft:stripped_dark_oak_log
setblock 59 117 323 minecraft:stripped_dark_oak_log
setblock 60 117 363 minecraft:stripped_dark_oak_log
fill 63 117 327 63 122 327 minecraft:red_concrete
setblock 66 117 323 minecraft:stripped_dark_oak_log
setblock 67 117 363 minecraft:stripped_dark_oak_log
fill 69 117 328 70 117 328 minecraft:cherry_leaves[persistent=true]
fill 69 117 331 70 117 331 minecraft:cherry_leaves[persistent=true]
setblock 73 117 323 minecraft:stripped_dark_oak_log
setblock 74 117 363 minecraft:stripped_dark_oak_log
fill 79 117 364 79 142 364 minecraft:dark_oak_planks
setblock 80 117 323 minecraft:stripped_dark_oak_log
fill 80 117 348 80 118 348 minecraft:dark_oak_planks
fill 80 117 351 80 118 351 minecraft:dark_oak_planks
setblock 80 117 364 minecraft:red_concrete
fill 81 117 347 81 118 347 minecraft:dark_oak_planks
setblock 81 117 363 minecraft:stripped_dark_oak_log
fill 81 117 364 81 141 364 minecraft:dark_oak_planks
fill 82 117 346 84 118 346 minecraft:dark_oak_planks
fill 82 117 353 82 118 353 minecraft:dark_oak_planks
fill 85 117 353 85 118 353 minecraft:dark_oak_planks
fill 86 117 347 86 118 347 minecraft:dark_oak_planks
fill 86 117 352 86 118 352 minecraft:dark_oak_planks
setblock 87 117 323 minecraft:stripped_dark_oak_log
fill 87 117 349 87 118 350 minecraft:dark_oak_planks
setblock 88 117 329 minecraft:stripped_dark_oak_log
setblock 88 117 336 minecraft:stripped_dark_oak_log
setblock 88 117 343 minecraft:stripped_dark_oak_log
setblock 88 117 350 minecraft:stripped_dark_oak_log
setblock 88 117 357 minecraft:stripped_dark_oak_log
setblock 88 117 363 minecraft:stripped_dark_oak_log
fill 89 117 332 89 138 332 minecraft:dark_oak_planks
setblock 47 118 327 minecraft:red_concrete
setblock 48 118 327 minecraft:stripped_dark_oak_log
setblock 48 118 334 minecraft:stripped_dark_oak_log
setblock 48 118 341 minecraft:stripped_dark_oak_log
setblock 48 118 348 minecraft:stripped_dark_oak_log
setblock 48 118 355 minecraft:stripped_dark_oak_log
setblock 48 118 362 minecraft:stripped_dark_oak_log
setblock 50 118 325 minecraft:light[level=12]
setblock 50 118 332 minecraft:light[level=12]
setblock 50 118 339 minecraft:light[level=12]
setblock 50 118 346 minecraft:light[level=12]
setblock 50 118 353 minecraft:light[level=12]
setblock 50 118 360 minecraft:light[level=12]
setblock 51 118 323 minecraft:stripped_dark_oak_log
setblock 54 118 363 minecraft:stripped_dark_oak_log
setblock 57 118 325 minecraft:light[level=12]
setblock 57 118 332 minecraft:light[level=12]
setblock 57 118 339 minecraft:light[level=12]
setblock 57 118 346 minecraft:light[level=12]
setblock 57 118 353 minecraft:light[level=12]
setblock 57 118 360 minecraft:light[level=12]
setblock 58 118 323 minecraft:stripped_dark_oak_log
setblock 61 118 363 minecraft:stripped_dark_oak_log
fill 63 118 326 63 122 326 minecraft:red_concrete
setblock 64 118 325 minecraft:light[level=12]
setblock 64 118 332 minecraft:light[level=12]
setblock 64 118 339 minecraft:light[level=12]
setblock 64 118 346 minecraft:light[level=12]
setblock 64 118 353 minecraft:light[level=12]
setblock 64 118 360 minecraft:light[level=12]
setblock 65 118 323 minecraft:stripped_dark_oak_log
setblock 68 118 363 minecraft:stripped_dark_oak_log
setblock 71 118 325 minecraft:light[level=12]
setblock 71 118 332 minecraft:light[level=12]
setblock 71 118 339 minecraft:light[level=12]
setblock 71 118 346 minecraft:light[level=12]
setblock 71 118 353 minecraft:light[level=12]
setblock 71 118 360 minecraft:light[level=12]
setblock 72 118 323 minecraft:stripped_dark_oak_log
setblock 75 118 363 minecraft:stripped_dark_oak_log
setblock 78 118 325 minecraft:light[level=12]
setblock 78 118 332 minecraft:light[level=12]
setblock 78 118 339 minecraft:light[level=12]
setblock 78 118 346 minecraft:light[level=12]
setblock 78 118 353 minecraft:light[level=12]
setblock 78 118 360 minecraft:light[level=12]
setblock 79 118 323 minecraft:stripped_dark_oak_log
fill 79 118 349 79 118 350 minecraft:dark_oak_planks
setblock 80 118 347 minecraft:dark_oak_planks
setblock 80 118 352 minecraft:dark_oak_planks
fill 80 118 364 80 144 364 minecraft:dark_oak_planks
setblock 81 118 346 minecraft:dark_oak_planks
setblock 81 118 353 minecraft:dark_oak_planks
setblock 82 118 363 minecraft:stripped_dark_oak_log
setblock 83 118 354 minecraft:dark_oak_planks
setblock 85 118 325 minecraft:light[level=12]
setblock 85 118 332 minecraft:light[level=12]
setblock 85 118 339 minecraft:light[level=12]
setblock 85 118 346 minecraft:dark_oak_planks
setblock 86 118 323 minecraft:stripped_dark_oak_log
setblock 86 118 353 minecraft:dark_oak_planks
setblock 87 118 348 minecraft:dark_oak_planks
fill 87 118 351 87 118 352 minecraft:dark_oak_planks
setblock 88 118 328 minecraft:stripped_dark_oak_log
setblock 88 118 335 minecraft:stripped_dark_oak_log
setblock 88 118 342 minecraft:stripped_dark_oak_log
setblock 88 118 349 minecraft:stripped_dark_oak_log
setblock 88 118 356 minecraft:stripped_dark_oak_log
fill 47 119 327 47 141 327 minecraft:dark_oak_planks
fill 47 119 349 47 127 349 minecraft:dark_oak_planks
setblock 47 119 350 minecraft:red_concrete
fill 62 119 326 62 122 328 minecraft:red_concrete
fill 63 119 328 64 122 328 minecraft:red_concrete
fill 64 119 326 64 122 327 minecraft:red_concrete
fill 72 119 322 72 141 322 minecraft:dark_oak_planks
setblock 73 119 322 minecraft:red_concrete
fill 74 119 322 78 132 322 minecraft:dark_oak_planks
fill 83 119 350 83 121 350 minecraft:stripped_dark_oak_log
fill 47 120 350 47 145 350 minecraft:dark_oak_planks
fill 48 120 323 48 120 327 minecraft:stripped_dark_oak_log
fill 48 120 329 48 120 334 minecraft:stripped_dark_oak_log
fill 48 120 336 48 120 341 minecraft:stripped_dark_oak_log
fill 48 120 343 48 120 348 minecraft:stripped_dark_oak_log
fill 48 120 350 48 120 355 minecraft:stripped_dark_oak_log
fill 48 120 357 48 120 362 minecraft:stripped_dark_oak_log
setblock 49 120 323 minecraft:stripped_dark_oak_log
fill 49 120 363 54 120 363 minecraft:stripped_dark_oak_log
setblock 50 120 325 minecraft:light[level=15]
setblock 50 120 333 minecraft:light[level=15]
setblock 50 120 341 minecraft:light[level=15]
setblock 50 120 349 minecraft:light[level=15]
setblock 50 120 357 minecraft:light[level=15]
fill 51 120 323 56 120 323 minecraft:stripped_dark_oak_log
fill 53 120 364 58 121 364 minecraft:dark_oak_planks
fill 56 120 363 61 120 363 minecraft:stripped_dark_oak_log
fill 58 120 323 63 120 323 minecraft:stripped_dark_oak_log
setblock 58 120 325 minecraft:light[level=15]
setblock 58 120 333 minecraft:light[level=15]
setblock 58 120 341 minecraft:light[level=15]
setblock 58 120 349 minecraft:light[level=15]
setblock 58 120 357 minecraft:light[level=15]
setblock 59 120 364 minecraft:red_concrete
fill 60 120 364 62 140 364 minecraft:dark_oak_planks
fill 61 120 326 61 122 327 minecraft:red_concrete
fill 62 120 325 64 122 325 minecraft:red_concrete
fill 63 120 329 63 122 329 minecraft:red_concrete
fill 63 120 363 68 120 363 minecraft:stripped_dark_oak_log
fill 65 120 323 70 120 323 minecraft:stripped_dark_oak_log
fill 65 120 326 65 122 327 minecraft:red_concrete
setblock 66 120 325 minecraft:light[level=15]
setblock 66 120 333 minecraft:light[level=15]
setblock 66 120 341 minecraft:light[level=15]
setblock 66 120 349 minecraft:light[level=15]
setblock 66 120 357 minecraft:light[level=15]
fill 70 120 363 75 120 363 minecraft:stripped_dark_oak_log
fill 72 120 323 77 120 323 minecraft:stripped_dark_oak_log
fill 73 120 322 73 144 322 minecraft:dark_oak_planks
setblock 74 120 325 minecraft:light[level=15]
setblock 74 120 333 minecraft:light[level=15]
setblock 74 120 341 minecraft:light[level=15]
setblock 74 120 349 minecraft:light[level=15]
setblock 74 120 357 minecraft:light[level=15]
fill 77 120 363 82 120 363 minecraft:stripped_dark_oak_log
fill 79 120 323 84 120 323 minecraft:stripped_dark_oak_log
setblock 82 120 325 minecraft:light[level=15]
setblock 82 120 333 minecraft:light[level=15]
setblock 82 120 341 minecraft:light[level=15]
setblock 82 120 349 minecraft:light[level=15]
setblock 82 120 357 minecraft:light[level=15]
fill 84 120 363 88 120 363 minecraft:stripped_dark_oak_log
fill 86 120 323 88 120 323 minecraft:stripped_dark_oak_log
fill 88 120 324 88 120 326 minecraft:stripped_dark_oak_log
fill 88 120 328 88 120 333 minecraft:stripped_dark_oak_log
fill 88 120 335 88 120 340 minecraft:stripped_dark_oak_log
fill 88 120 342 88 120 347 minecraft:stripped_dark_oak_log
fill 88 120 349 88 120 354 minecraft:stripped_dark_oak_log
fill 88 120 356 88 120 361 minecraft:stripped_dark_oak_log
setblock 48 121 323 minecraft:stripped_dark_oak_log
setblock 48 121 330 minecraft:stripped_dark_oak_log
setblock 48 121 337 minecraft:stripped_dark_oak_log
setblock 48 121 344 minecraft:stripped_dark_oak_log
setblock 48 121 351 minecraft:stripped_dark_oak_log
setblock 48 121 358 minecraft:stripped_dark_oak_log
setblock 50 121 363 minecraft:stripped_dark_oak_log
setblock 55 121 323 minecraft:stripped_dark_oak_log
setblock 57 121 363 minecraft:stripped_dark_oak_log
fill 59 121 364 59 140 364 minecraft:dark_oak_planks
fill 61 121 325 61 122 325 minecraft:red_concrete
fill 61 121 328 61 122 328 minecraft:red_concrete
setblock 62 121 323 minecraft:stripped_dark_oak_log
fill 62 121 324 64 122 324 minecraft:red_concrete
fill 62 121 329 62 122 329 minecraft:red_concrete
fill 64 121 329 64 122 329 minecraft:red_concrete
setblock 64 121 363 minecraft:stripped_dark_oak_log
fill 65 121 325 65 122 325 minecraft:red_concrete
fill 65 121 328 65 122 328 minecraft:red_concrete
setblock 69 121 323 minecraft:stripped_dark_oak_log
setblock 71 121 363 minecraft:stripped_dark_oak_log
setblock 76 121 323 minecraft:stripped_dark_oak_log
setblock 78 121 363 minecraft:stripped_dark_oak_log
setblock 83 121 323 minecraft:stripped_dark_oak_log
setblock 85 121 363 minecraft:stripped_dark_oak_log
setblock 88 121 325 minecraft:stripped_dark_oak_log
setblock 88 121 332 minecraft:stripped_dark_oak_log
setblock 88 121 339 minecraft:stripped_dark_oak_log
setblock 88 121 346 minecraft:stripped_dark_oak_log
setblock 88 121 353 minecraft:stripped_dark_oak_log
setblock 88 121 360 minecraft:stripped_dark_oak_log
setblock 48 122 324 minecraft:stripped_dark_oak_log
setblock 48 122 331 minecraft:stripped_dark_oak_log
setblock 48 122 338 minecraft:stripped_dark_oak_log
setblock 48 122 345 minecraft:stripped_dark_oak_log
setblock 48 122 352 minecraft:stripped_dark_oak_log
setblock 48 122 359 minecraft:stripped_dark_oak_log
setblock 51 122 363 minecraft:stripped_dark_oak_log
fill 53 122 364 54 122 364 minecraft:dark_oak_planks
setblock 54 122 323 minecraft:stripped_dark_oak_log
setblock 55 122 364 minecraft:red_concrete
fill 56 122 364 58 141 364 minecraft:dark_oak_planks
setblock 58 122 363 minecraft:stripped_dark_oak_log
fill 60 122 325 60 122 328 minecraft:red_concrete
fill 61 122 323 61 142 323 minecraft:stripped_dark_oak_log
setblock 61 122 324 minecraft:red_concrete
setblock 61 122 329 minecraft:red_concrete
fill 62 122 330 64 122 330 minecraft:red_concrete
setblock 65 122 324 minecraft:red_concrete
setblock 65 122 329 minecraft:red_concrete
setblock 65 122 363 minecraft:stripped_dark_oak_log
fill 66 122 325 66 122 328 minecraft:red_concrete
fill 68 122 323 68 123 323 minecraft:stripped_dark_oak_log
setblock 72 122 363 minecraft:stripped_dark_oak_log
setblock 75 122 323 minecraft:stripped_dark_oak_log
setblock 79 122 363 minecraft:stripped_dark_oak_log
setblock 82 122 323 minecraft:stripped_dark_oak_log
fill 82 122 349 84 124 351 minecraft:cherry_leaves[persistent=true]
fill 83 122 348 84 124 348 minecraft:cherry_leaves[persistent=true]
fill 85 122 349 85 124 350 minecraft:cherry_leaves[persistent=true]
setblock 86 122 363 minecraft:stripped_dark_oak_log
setblock 88 122 324 minecraft:stripped_dark_oak_log
setblock 88 122 331 minecraft:stripped_dark_oak_log
setblock 88 122 338 minecraft:stripped_dark_oak_log
setblock 88 122 345 minecraft:stripped_dark_oak_log
setblock 88 122 352 minecraft:stripped_dark_oak_log
setblock 88 122 359 minecraft:stripped_dark_oak_log
setblock 48 123 325 minecraft:stripped_dark_oak_log
setblock 48 123 332 minecraft:stripped_dark_oak_log
setblock 48 123 339 minecraft:stripped_dark_oak_log
setblock 48 123 346 minecraft:stripped_dark_oak_log
setblock 48 123 353 minecraft:stripped_dark_oak_log
setblock 48 123 360 minecraft:stripped_dark_oak_log
setblock 52 123 363 minecraft:stripped_dark_oak_log
setblock 53 123 323 minecraft:stripped_dark_oak_log
fill 53 123 364 53 144 364 minecraft:dark_oak_planks
setblock 54 123 364 minecraft:red_concrete
fill 55 123 364 55 144 364 minecraft:dark_oak_planks
fill 58 123 323 60 123 331 minecraft:stripped_dark_oak_log
setblock 59 123 363 minecraft:stripped_dark_oak_log
fill 61 123 324 68 123 331 minecraft:stripped_dark_oak_log
fill 62 123 323 63 123 323 minecraft:stripped_dark_oak_log
fill 65 123 323 67 123 323 minecraft:stripped_dark_oak_log
setblock 66 123 363 minecraft:stripped_dark_oak_log
setblock 73 123 363 minecraft:stripped_dark_oak_log
setblock 74 123 323 minecraft:stripped_dark_oak_log
setblock 80 123 363 minecraft:stripped_dark_oak_log
setblock 81 123 323 minecraft:stripped_dark_oak_log
fill 81 123 349 81 123 350 minecraft:cherry_leaves[persistent=true]
setblock 82 123 348 minecraft:cherry_leaves[persistent=true]
setblock 83 123 352 minecraft:cherry_leaves[persistent=true]
setblock 85 123 348 minecraft:cherry_leaves[persistent=true]
setblock 85 123 351 minecraft:cherry_leaves[persistent=true]
setblock 87 123 363 minecraft:stripped_dark_oak_log
setblock 88 123 323 minecraft:stripped_dark_oak_log
setblock 88 123 330 minecraft:stripped_dark_oak_log
setblock 88 123 337 minecraft:stripped_dark_oak_log
setblock 88 123 344 minecraft:stripped_dark_oak_log
setblock 88 123 351 minecraft:stripped_dark_oak_log
setblock 88 123 358 minecraft:stripped_dark_oak_log
fill 47 124 352 47 144 352 minecraft:dark_oak_planks
setblock 47 124 353 minecraft:red_concrete
fill 47 124 354 47 140 354 minecraft:dark_oak_planks
setblock 48 124 326 minecraft:stripped_dark_oak_log
setblock 48 124 333 minecraft:stripped_dark_oak_log
setblock 48 124 340 minecraft:stripped_dark_oak_log
setblock 48 124 347 minecraft:stripped_dark_oak_log
setblock 48 124 354 minecraft:stripped_dark_oak_log
setblock 48 124 361 minecraft:stripped_dark_oak_log
setblock 50 124 325 minecraft:light[level=12]
setblock 50 124 332 minecraft:light[level=12]
setblock 50 124 339 minecraft:light[level=12]
setblock 50 124 346 minecraft:light[level=12]
setblock 50 124 353 minecraft:light[level=12]
setblock 50 124 360 minecraft:light[level=12]
fill 51 124 348 51 129 348 minecraft:red_concrete
setblock 52 124 323 minecraft:stripped_dark_oak_log
fill 53 124 358 53 129 358 minecraft:red_concrete
setblock 53 124 363 minecraft:stripped_dark_oak_log
fill 54 124 364 54 125 364 minecraft:dark_oak_planks
setblock 57 124 325 minecraft:light[level=12]
setblock 57 124 332 minecraft:light[level=12]
setblock 57 124 339 minecraft:light[level=12]
setblock 57 124 346 minecraft:light[level=12]
setblock 57 124 353 minecraft:light[level=12]
setblock 57 124 360 minecraft:light[level=12]
setblock 58 124 323 minecraft:shroomlight
fill 58 124 324 58 142 324 minecraft:stripped_dark_oak_log
setblock 58 124 325 minecraft:shroomlight
fill 58 124 326 58 142 326 minecraft:stripped_dark_oak_log
setblock 58 124 327 minecraft:shroomlight
fill 58 124 328 58 142 328 minecraft:stripped_dark_oak_log
setblock 58 124 329 minecraft:shroomlight
fill 58 124 330 58 142 330 minecraft:stripped_dark_oak_log
setblock 58 124 331 minecraft:shroomlight
fill 59 124 323 59 142 323 minecraft:stripped_dark_oak_log
setblock 59 124 324 minecraft:shroomlight
fill 59 124 325 59 142 325 minecraft:stripped_dark_oak_log
setblock 59 124 326 minecraft:shroomlight
fill 59 124 327 59 142 327 minecraft:stripped_dark_oak_log
setblock 59 124 328 minecraft:shroomlight
fill 59 124 329 59 142 329 minecraft:stripped_dark_oak_log
setblock 59 124 330 minecraft:shroomlight
fill 59 124 331 59 142 331 minecraft:stripped_dark_oak_log
setblock 60 124 323 minecraft:shroomlight
fill 60 124 324 60 142 324 minecraft:stripped_dark_oak_log
setblock 60 124 325 minecraft:shroomlight
fill 60 124 326 60 142 326 minecraft:stripped_dark_oak_log
setblock 60 124 327 minecraft:shroomlight
fill 60 124 328 60 142 328 minecraft:stripped_dark_oak_log
setblock 60 124 329 minecraft:shroomlight
fill 60 124 330 60 142 330 minecraft:stripped_dark_oak_log
setblock 60 124 331 minecraft:shroomlight
setblock 60 124 363 minecraft:stripped_dark_oak_log
setblock 61 124 324 minecraft:shroomlight
fill 61 124 325 61 142 325 minecraft:stripped_dark_oak_log
setblock 61 124 326 minecraft:shroomlight
fill 61 124 327 61 142 327 minecraft:stripped_dark_oak_log
setblock 61 124 328 minecraft:shroomlight
fill 61 124 329 61 142 329 minecraft:stripped_dark_oak_log
setblock 61 124 330 minecraft:shroomlight
fill 61 124 331 61 142 331 minecraft:stripped_dark_oak_log
fill 61 124 355 61 125 355 minecraft:shroomlight
setblock 62 124 323 minecraft:shroomlight
fill 62 124 324 62 142 324 minecraft:stripped_dark_oak_log
setblock 62 124 325 minecraft:shroomlight
fill 62 124 326 62 142 326 minecraft:stripped_dark_oak_log
setblock 62 124 327 minecraft:shroomlight
fill 62 124 328 62 142 328 minecraft:stripped_dark_oak_log
setblock 62 124 329 minecraft:shroomlight
fill 62 124 330 62 142 330 minecraft:stripped_dark_oak_log
setblock 62 124 331 minecraft:shroomlight
fill 63 124 323 63 142 323 minecraft:stripped_dark_oak_log
setblock 63 124 324 minecraft:shroomlight
fill 63 124 325 63 142 325 minecraft:stripped_dark_oak_log
setblock 63 124 326 minecraft:shroomlight
fill 63 124 327 63 142 327 minecraft:stripped_dark_oak_log
setblock 63 124 328 minecraft:shroomlight
fill 63 124 329 63 142 329 minecraft:stripped_dark_oak_log
setblock 63 124 330 minecraft:shroomlight
fill 63 124 331 63 142 331 minecraft:stripped_dark_oak_log
setblock 64 124 323 minecraft:shroomlight
fill 64 124 324 64 142 324 minecraft:stripped_dark_oak_log
setblock 64 124 325 minecraft:shroomlight
fill 64 124 326 64 142 326 minecraft:stripped_dark_oak_log
setblock 64 124 327 minecraft:shroomlight
fill 64 124 328 64 142 328 minecraft:stripped_dark_oak_log
setblock 64 124 329 minecraft:shroomlight
fill 64 124 330 64 142 330 minecraft:stripped_dark_oak_log
setblock 64 124 331 minecraft:shroomlight
setblock 64 124 332 minecraft:light[level=12]
setblock 64 124 339 minecraft:light[level=12]
setblock 64 124 346 minecraft:light[level=12]
setblock 64 124 353 minecraft:light[level=12]
setblock 64 124 360 minecraft:light[level=12]
fill 65 124 323 65 142 323 minecraft:stripped_dark_oak_log
setblock 65 124 324 minecraft:shroomlight
fill 65 124 325 65 142 325 minecraft:stripped_dark_oak_log
setblock 65 124 326 minecraft:shroomlight
fill 65 124 327 65 142 327 minecraft:stripped_dark_oak_log
setblock 65 124 328 minecraft:shroomlight
fill 65 124 329 65 142 329 minecraft:stripped_dark_oak_log
setblock 65 124 330 minecraft:shroomlight
fill 65 124 331 65 142 331 minecraft:stripped_dark_oak_log
setblock 66 124 323 minecraft:shroomlight
fill 66 124 324 66 142 324 minecraft:stripped_dark_oak_log
setblock 66 124 325 minecraft:shroomlight
fill 66 124 326 66 142 326 minecraft:stripped_dark_oak_log
setblock 66 124 327 minecraft:shroomlight
fill 66 124 328 66 142 328 minecraft:stripped_dark_oak_log
setblock 66 124 329 minecraft:shroomlight
fill 66 124 330 66 142 330 minecraft:stripped_dark_oak_log
setblock 66 124 331 minecraft:shroomlight
fill 67 124 323 67 142 323 minecraft:stripped_dark_oak_log
setblock 67 124 324 minecraft:shroomlight
fill 67 124 325 67 142 325 minecraft:stripped_dark_oak_log
setblock 67 124 326 minecraft:shroomlight
fill 67 124 327 67 142 327 minecraft:stripped_dark_oak_log
setblock 67 124 328 minecraft:shroomlight
fill 67 124 329 67 142 329 minecraft:stripped_dark_oak_log
setblock 67 124 330 minecraft:shroomlight
fill 67 124 331 67 142 331 minecraft:stripped_dark_oak_log
setblock 67 124 363 minecraft:stripped_dark_oak_log
setblock 68 124 323 minecraft:shroomlight
fill 68 124 324 68 142 324 minecraft:stripped_dark_oak_log
setblock 68 124 325 minecraft:shroomlight
fill 68 124 326 68 142 326 minecraft:stripped_dark_oak_log
setblock 68 124 327 minecraft:shroomlight
fill 68 124 328 68 142 328 minecraft:stripped_dark_oak_log
setblock 68 124 329 minecraft:shroomlight
fill 68 124 330 68 142 330 minecraft:stripped_dark_oak_log
setblock 68 124 331 minecraft:shroomlight
setblock 71 124 325 minecraft:light[level=12]
setblock 71 124 332 minecraft:light[level=12]
setblock 71 124 339 minecraft:light[level=12]
setblock 71 124 346 minecraft:light[level=12]
setblock 71 124 353 minecraft:light[level=12]
setblock 71 124 360 minecraft:light[level=12]
setblock 73 124 323 minecraft:stripped_dark_oak_log
setblock 74 124 363 minecraft:stripped_dark_oak_log
setblock 78 124 325 minecraft:light[level=12]
setblock 78 124 332 minecraft:light[level=12]
setblock 78 124 339 minecraft:light[level=12]
setblock 78 124 346 minecraft:light[level=12]
setblock 78 124 353 minecraft:light[level=12]
setblock 78 124 360 minecraft:light[level=12]
setblock 80 124 323 minecraft:stripped_dark_oak_log
setblock 81 124 363 minecraft:stripped_dark_oak_log
fill 82 124 357 82 124 358 minecraft:dark_oak_planks
setblock 82 124 360 minecraft:dark_oak_planks
fill 83 124 357 85 124 357 minecraft:dark_oak_planks
fill 83 124 361 85 124 361 minecraft:dark_oak_planks
setblock 85 124 325 minecraft:light[level=12]
setblock 85 124 332 minecraft:light[level=12]
setblock 85 124 339 minecraft:light[level=12]
setblock 85 124 346 minecraft:light[level=12]
setblock 85 124 353 minecraft:light[level=12]
fill 86 124 358 86 124 360 minecraft:dark_oak_planks
setblock 87 124 323 minecraft:stripped_dark_oak_log
setblock 88 124 329 minecraft:stripped_dark_oak_log
setblock 88 124 336 minecraft:stripped_dark_oak_log
setblock 88 124 343 minecraft:stripped_dark_oak_log
setblock 88 124 350 minecraft:stripped_dark_oak_log
setblock 88 124 357 minecraft:stripped_dark_oak_log
setblock 88 124 363 minecraft:stripped_dark_oak_log
fill 89 124 351 89 144 352 minecraft:dark_oak_planks
setblock 89 124 353 minecraft:red_concrete
fill 89 124 354 89 140 354 minecraft:dark_oak_planks
fill 47 125 353 47 133 353 minecraft:dark_oak_planks
setblock 48 125 327 minecraft:stripped_dark_oak_log
setblock 48 125 334 minecraft:stripped_dark_oak_log
setblock 48 125 341 minecraft:stripped_dark_oak_log
setblock 48 125 348 minecraft:stripped_dark_oak_log
setblock 48 125 355 minecraft:stripped_dark_oak_log
setblock 48 125 362 minecraft:stripped_dark_oak_log
fill 50 125 348 50 129 348 minecraft:red_concrete
setblock 51 125 323 minecraft:stripped_dark_oak_log
fill 53 125 359 53 129 359 minecraft:red_concrete
setblock 54 125 363 minecraft:stripped_dark_oak_log
fill 58 125 323 58 126 323 minecraft:stripped_dark_oak_log
fill 58 125 325 58 126 325 minecraft:stripped_dark_oak_log
fill 58 125 327 58 126 327 minecraft:stripped_dark_oak_log
fill 58 125 329 58 126 329 minecraft:stripped_dark_oak_log
fill 58 125 331 58 126 331 minecraft:stripped_dark_oak_log
fill 59 125 324 59 126 324 minecraft:stripped_dark_oak_log
fill 59 125 326 59 126 326 minecraft:stripped_dark_oak_log
fill 59 125 328 59 126 328 minecraft:stripped_dark_oak_log
fill 59 125 330 59 126 330 minecraft:stripped_dark_oak_log
fill 60 125 323 60 126 323 minecraft:stripped_dark_oak_log
fill 60 125 325 60 126 325 minecraft:stripped_dark_oak_log
fill 60 125 327 60 126 327 minecraft:stripped_dark_oak_log
fill 60 125 329 60 126 329 minecraft:stripped_dark_oak_log
fill 60 125 331 60 126 331 minecraft:stripped_dark_oak_log
fill 61 125 324 61 126 324 minecraft:stripped_dark_oak_log
fill 61 125 326 61 126 326 minecraft:stripped_dark_oak_log
fill 61 125 328 61 126 328 minecraft:stripped_dark_oak_log
fill 61 125 330 61 126 330 minecraft:stripped_dark_oak_log
setblock 61 125 363 minecraft:stripped_dark_oak_log
fill 62 125 323 62 126 323 minecraft:stripped_dark_oak_log
fill 62 125 325 62 126 325 minecraft:stripped_dark_oak_log
fill 62 125 327 62 126 327 minecraft:stripped_dark_oak_log
fill 62 125 329 62 126 329 minecraft:stripped_dark_oak_log
fill 62 125 331 62 126 331 minecraft:stripped_dark_oak_log
fill 63 125 324 63 126 324 minecraft:stripped_dark_oak_log
fill 63 125 326 63 126 326 minecraft:stripped_dark_oak_log
fill 63 125 328 63 126 328 minecraft:stripped_dark_oak_log
fill 63 125 330 63 126 330 minecraft:stripped_dark_oak_log
fill 64 125 323 64 126 323 minecraft:stripped_dark_oak_log
fill 64 125 325 64 126 325 minecraft:stripped_dark_oak_log
fill 64 125 327 64 126 327 minecraft:stripped_dark_oak_log
fill 64 125 329 64 126 329 minecraft:stripped_dark_oak_log
fill 64 125 331 64 126 331 minecraft:stripped_dark_oak_log
fill 65 125 324 65 126 324 minecraft:stripped_dark_oak_log
fill 65 125 326 65 126 326 minecraft:stripped_dark_oak_log
fill 65 125 328 65 126 328 minecraft:stripped_dark_oak_log
fill 65 125 330 65 126 330 minecraft:stripped_dark_oak_log
fill 66 125 323 66 126 323 minecraft:stripped_dark_oak_log
fill 66 125 325 66 126 325 minecraft:stripped_dark_oak_log
fill 66 125 327 66 126 327 minecraft:stripped_dark_oak_log
fill 66 125 329 66 126 329 minecraft:stripped_dark_oak_log
fill 66 125 331 66 126 331 minecraft:stripped_dark_oak_log
fill 67 125 324 67 126 324 minecraft:stripped_dark_oak_log
fill 67 125 326 67 126 326 minecraft:stripped_dark_oak_log
fill 67 125 328 67 126 328 minecraft:stripped_dark_oak_log
fill 67 125 330 67 126 330 minecraft:stripped_dark_oak_log
fill 68 125 323 68 126 323 minecraft:stripped_dark_oak_log
fill 68 125 325 68 126 325 minecraft:stripped_dark_oak_log
fill 68 125 327 68 126 327 minecraft:stripped_dark_oak_log
fill 68 125 329 68 126 329 minecraft:stripped_dark_oak_log
fill 68 125 331 68 126 331 minecraft:stripped_dark_oak_log
setblock 68 125 363 minecraft:stripped_dark_oak_log
setblock 72 125 323 minecraft:stripped_dark_oak_log
setblock 75 125 363 minecraft:stripped_dark_oak_log
setblock 79 125 323 minecraft:stripped_dark_oak_log
setblock 80 125 322 minecraft:red_concrete
fill 81 125 322 89 131 322 minecraft:dark_oak_planks
setblock 82 125 363 minecraft:stripped_dark_oak_log
setblock 86 125 323 minecraft:stripped_dark_oak_log
fill 86 125 364 87 144 364 minecraft:dark_oak_planks
setblock 88 125 328 minecraft:stripped_dark_oak_log
setblock 88 125 335 minecraft:stripped_dark_oak_log
setblock 88 125 342 minecraft:stripped_dark_oak_log
setblock 88 125 349 minecraft:stripped_dark_oak_log
setblock 88 125 356 minecraft:stripped_dark_oak_log
setblock 88 125 364 minecraft:red_concrete
fill 89 125 353 89 140 353 minecraft:dark_oak_planks
fill 89 125 364 89 141 364 minecraft:dark_oak_planks
setblock 49 126 356 minecraft:red_concrete
fill 50 126 347 51 129 347 minecraft:red_concrete
fill 50 126 349 51 129 349 minecraft:red_concrete
fill 52 126 348 52 129 348 minecraft:red_concrete
fill 52 126 357 52 129 359 minecraft:red_concrete
fill 53 126 357 54 129 357 minecraft:red_concrete
fill 54 126 358 54 129 359 minecraft:red_concrete
setblock 54 126 364 minecraft:red_concrete
fill 61 126 355 61 134 355 minecraft:dark_oak_planks
fill 80 126 322 80 144 322 minecraft:dark_oak_planks
fill 88 126 364 88 140 364 minecraft:dark_oak_planks
setblock 89 126 328 minecraft:red_concrete
setblock 48 127 329 minecraft:stripped_dark_oak_log
setblock 48 127 336 minecraft:stripped_dark_oak_log
setblock 48 127 343 minecraft:stripped_dark_oak_log
setblock 48 127 350 minecraft:stripped_dark_oak_log
setblock 48 127 357 minecraft:stripped_dark_oak_log
setblock 49 127 323 minecraft:stripped_dark_oak_log
fill 49 127 348 49 129 348 minecraft:red_concrete
fill 49 127 356 49 128 356 minecraft:shroomlight
setblock 49 127 363 minecraft:stripped_dark_oak_log
fill 51 127 358 51 129 359 minecraft:red_concrete
fill 52 127 347 52 129 347 minecraft:red_concrete
fill 52 127 349 52 129 349 minecraft:red_concrete
fill 52 127 360 54 129 360 minecraft:red_concrete
fill 53 127 356 53 129 356 minecraft:red_concrete
fill 54 127 364 54 144 364 minecraft:dark_oak_planks
fill 55 127 358 55 129 359 minecraft:red_concrete
setblock 56 127 323 minecraft:stripped_dark_oak_log
setblock 56 127 363 minecraft:stripped_dark_oak_log
setblock 58 127 323 minecraft:shroomlight
setblock 58 127 325 minecraft:shroomlight
setblock 58 127 327 minecraft:shroomlight
setblock 58 127 329 minecraft:shroomlight
setblock 58 127 331 minecraft:shroomlight
setblock 59 127 324 minecraft:shroomlight
setblock 59 127 326 minecraft:shroomlight
setblock 59 127 328 minecraft:shroomlight
setblock 59 127 330 minecraft:shroomlight
setblock 60 127 323 minecraft:shroomlight
setblock 60 127 325 minecraft:shroomlight
setblock 60 127 327 minecraft:shroomlight
setblock 60 127 329 minecraft:shroomlight
setblock 60 127 331 minecraft:shroomlight
fill 60 127 355 60 134 355 minecraft:dark_oak_planks
setblock 61 127 324 minecraft:shroomlight
setblock 61 127 326 minecraft:shroomlight
setblock 61 127 328 minecraft:shroomlight
setblock 61 127 330 minecraft:shroomlight
fill 61 127 354 61 134 354 minecraft:dark_oak_planks
setblock 62 127 323 minecraft:shroomlight
setblock 62 127 325 minecraft:shroomlight
setblock 62 127 327 minecraft:shroomlight
setblock 62 127 329 minecraft:shroomlight
setblock 62 127 331 minecraft:shroomlight
setblock 63 127 324 minecraft:shroomlight
setblock 63 127 326 minecraft:shroomlight
setblock 63 127 328 minecraft:shroomlight
setblock 63 127 330 minecraft:shroomlight
setblock 63 127 363 minecraft:stripped_dark_oak_log
setblock 64 127 323 minecraft:shroomlight
setblock 64 127 325 minecraft:shroomlight
setblock 64 127 327 minecraft:shroomlight
setblock 64 127 329 minecraft:shroomlight
setblock 64 127 331 minecraft:shroomlight
setblock 65 127 324 minecraft:shroomlight
setblock 65 127 326 minecraft:shroomlight
setblock 65 127 328 minecraft:shroomlight
setblock 65 127 330 minecraft:shroomlight
setblock 66 127 323 minecraft:shroomlight
setblock 66 127 325 minecraft:shroomlight
setblock 66 127 327 minecraft:shroomlight
setblock 66 127 329 minecraft:shroomlight
setblock 66 127 331 minecraft:shroomlight
setblock 67 127 324 minecraft:shroomlight
setblock 67 127 326 minecraft:shroomlight
setblock 67 127 328 minecraft:shroomlight
setblock 67 127 330 minecraft:shroomlight
setblock 68 127 323 minecraft:shroomlight
setblock 68 127 325 minecraft:shroomlight
setblock 68 127 327 minecraft:shroomlight
setblock 68 127 329 minecraft:shroomlight
setblock 68 127 331 minecraft:shroomlight
setblock 70 127 323 minecraft:stripped_dark_oak_log
setblock 70 127 363 minecraft:stripped_dark_oak_log
setblock 77 127 323 minecraft:stripped_dark_oak_log
setblock 77 127 363 minecraft:stripped_dark_oak_log
setblock 84 127 323 minecraft:stripped_dark_oak_log
setblock 84 127 363 minecraft:stripped_dark_oak_log
setblock 88 127 326 minecraft:stripped_dark_oak_log
setblock 88 127 333 minecraft:stripped_dark_oak_log
setblock 88 127 340 minecraft:stripped_dark_oak_log
setblock 88 127 347 minecraft:stripped_dark_oak_log
setblock 88 127 354 minecraft:stripped_dark_oak_log
setblock 88 127 361 minecraft:stripped_dark_oak_log
fill 89 127 328 89 144 328 minecraft:dark_oak_planks
fill 47 128 328 47 140 337 minecraft:dark_oak_planks
setblock 47 128 338 minecraft:red_concrete
setblock 47 128 349 minecraft:red_concrete
setblock 48 128 323 minecraft:stripped_dark_oak_log
setblock 48 128 330 minecraft:stripped_dark_oak_log
setblock 48 128 337 minecraft:stripped_dark_oak_log
setblock 48 128 344 minecraft:stripped_dark_oak_log
setblock 48 128 351 minecraft:stripped_dark_oak_log
setblock 48 128 358 minecraft:stripped_dark_oak_log
fill 49 128 347 49 129 347 minecraft:red_concrete
fill 49 128 349 49 129 349 minecraft:red_concrete
setblock 50 128 325 minecraft:light[level=15]
setblock 50 128 333 minecraft:light[level=15]
setblock 50 128 341 minecraft:light[level=15]
fill 50 128 346 51 129 346 minecraft:red_concrete
fill 50 128 350 51 129 350 minecraft:red_concrete
setblock 50 128 357 minecraft:light[level=15]
setblock 50 128 363 minecraft:stripped_dark_oak_log
fill 51 128 357 51 129 357 minecraft:red_concrete
fill 51 128 360 51 129 360 minecraft:red_concrete
fill 52 128 356 52 129 356 minecraft:red_concrete
fill 52 128 361 54 129 361 minecraft:red_concrete
fill 53 128 348 53 129 348 minecraft:red_concrete
fill 54 128 356 54 129 356 minecraft:red_concrete
setblock 55 128 323 minecraft:stripped_dark_oak_log
fill 55 128 357 55 129 357 minecraft:red_concrete
fill 55 128 360 55 129 360 minecraft:red_concrete
setblock 57 128 363 minecraft:stripped_dark_oak_log
fill 58 128 323 58 129 323 minecraft:stripped_dark_oak_log
fill 58 128 325 58 129 325 minecraft:stripped_dark_oak_log
fill 58 128 327 58 129 327 minecraft:stripped_dark_oak_log
fill 58 128 329 58 129 329 minecraft:stripped_dark_oak_log
fill 58 128 331 58 129 331 minecraft:stripped_dark_oak_log
setblock 58 128 333 minecraft:light[level=15]
setblock 58 128 341 minecraft:light[level=15]
setblock 58 128 349 minecraft:light[level=15]
setblock 58 128 357 minecraft:light[level=15]
fill 59 128 324 59 129 324 minecraft:stripped_dark_oak_log
fill 59 128 326 59 129 326 minecraft:stripped_dark_oak_log
fill 59 128 328 59 129 328 minecraft:stripped_dark_oak_log
fill 59 128 330 59 129 330 minecraft:stripped_dark_oak_log
fill 60 128 323 60 129 323 minecraft:stripped_dark_oak_log
fill 60 128 325 60 129 325 minecraft:stripped_dark_oak_log
fill 60 128 327 60 129 327 minecraft:stripped_dark_oak_log
fill 60 128 329 60 129 329 minecraft:stripped_dark_oak_log
fill 60 128 331 60 129 331 minecraft:stripped_dark_oak_log
fill 60 128 354 60 134 354 minecraft:dark_oak_planks
fill 60 128 356 61 134 356 minecraft:dark_oak_planks
fill 61 128 322 62 144 322 minecraft:dark_oak_planks
fill 61 128 324 61 129 324 minecraft:stripped_dark_oak_log
fill 61 128 326 61 129 326 minecraft:stripped_dark_oak_log
fill 61 128 328 61 129 328 minecraft:stripped_dark_oak_log
fill 61 128 330 61 129 330 minecraft:stripped_dark_oak_log
fill 62 128 323 62 129 323 minecraft:stripped_dark_oak_log
fill 62 128 325 62 129 325 minecraft:stripped_dark_oak_log
fill 62 128 327 62 129 327 minecraft:stripped_dark_oak_log
fill 62 128 329 62 129 329 minecraft:stripped_dark_oak_log
fill 62 128 331 62 129 331 minecraft:stripped_dark_oak_log
fill 62 128 354 62 134 355 minecraft:dark_oak_planks
setblock 63 128 322 minecraft:red_concrete
fill 63 128 324 63 129 324 minecraft:stripped_dark_oak_log
fill 63 128 326 63 129 326 minecraft:stripped_dark_oak_log
fill 63 128 328 63 129 328 minecraft:stripped_dark_oak_log
fill 63 128 330 63 129 330 minecraft:stripped_dark_oak_log
fill 64 128 322 68 141 322 minecraft:dark_oak_planks
fill 64 128 323 64 129 323 minecraft:stripped_dark_oak_log
fill 64 128 325 64 129 325 minecraft:stripped_dark_oak_log
fill 64 128 327 64 129 327 minecraft:stripped_dark_oak_log
fill 64 128 329 64 129 329 minecraft:stripped_dark_oak_log
fill 64 128 331 64 129 331 minecraft:stripped_dark_oak_log
setblock 64 128 363 minecraft:stripped_dark_oak_log
fill 65 128 324 65 129 324 minecraft:stripped_dark_oak_log
fill 65 128 326 65 129 326 minecraft:stripped_dark_oak_log
fill 65 128 328 65 129 328 minecraft:stripped_dark_oak_log
fill 65 128 330 65 129 330 minecraft:stripped_dark_oak_log
fill 66 128 323 66 129 323 minecraft:stripped_dark_oak_log
fill 66 128 325 66 129 325 minecraft:stripped_dark_oak_log
fill 66 128 327 66 129 327 minecraft:stripped_dark_oak_log
fill 66 128 329 66 129 329 minecraft:stripped_dark_oak_log
fill 66 128 331 66 129 331 minecraft:stripped_dark_oak_log
setblock 66 128 333 minecraft:light[level=15]
setblock 66 128 341 minecraft:light[level=15]
setblock 66 128 349 minecraft:light[level=15]
setblock 66 128 357 minecraft:light[level=15]
fill 67 128 324 67 129 324 minecraft:stripped_dark_oak_log
fill 67 128 326 67 129 326 minecraft:stripped_dark_oak_log
fill 67 128 328 67 129 328 minecraft:stripped_dark_oak_log
fill 67 128 330 67 129 330 minecraft:stripped_dark_oak_log
fill 68 128 323 69 128 323 minecraft:stripped_dark_oak_log
fill 68 128 325 68 129 325 minecraft:stripped_dark_oak_log
fill 68 128 327 68 129 327 minecraft:stripped_dark_oak_log
fill 68 128 329 68 129 329 minecraft:stripped_dark_oak_log
fill 68 128 331 68 129 331 minecraft:stripped_dark_oak_log
setblock 71 128 363 minecraft:stripped_dark_oak_log
setblock 74 128 325 minecraft:light[level=15]
setblock 74 128 333 minecraft:light[level=15]
setblock 74 128 341 minecraft:light[level=15]
setblock 74 128 349 minecraft:light[level=15]
setblock 74 128 357 minecraft:light[level=15]
setblock 76 128 323 minecraft:stripped_dark_oak_log
setblock 78 128 363 minecraft:stripped_dark_oak_log
setblock 82 128 325 minecraft:light[level=15]
setblock 82 128 333 minecraft:light[level=15]
setblock 82 128 341 minecraft:light[level=15]
setblock 82 128 349 minecraft:light[level=15]
setblock 82 128 357 minecraft:light[level=15]
setblock 83 128 323 minecraft:stripped_dark_oak_log
setblock 85 128 363 minecraft:stripped_dark_oak_log
setblock 88 128 325 minecraft:stripped_dark_oak_log
setblock 88 128 332 minecraft:stripped_dark_oak_log
setblock 88 128 339 minecraft:stripped_dark_oak_log
setblock 88 128 346 minecraft:stripped_dark_oak_log
setblock 88 128 353 minecraft:stripped_dark_oak_log
setblock 88 128 360 minecraft:stripped_dark_oak_log
fill 47 129 338 47 134 338 minecraft:dark_oak_planks
fill 47 129 349 47 135 349 minecraft:dark_oak_planks
fill 48 129 324 48 130 324 minecraft:stripped_dark_oak_log
fill 48 129 331 48 130 331 minecraft:stripped_dark_oak_log
fill 48 129 338 48 130 338 minecraft:stripped_dark_oak_log
fill 48 129 341 48 130 341 minecraft:stripped_dark_oak_log
fill 48 129 343 48 142 343 minecraft:stripped_dark_oak_log
fill 48 129 345 48 142 345 minecraft:stripped_dark_oak_log
setblock 48 129 348 minecraft:red_concrete
fill 48 129 352 48 142 352 minecraft:stripped_dark_oak_log
fill 48 129 359 48 132 359 minecraft:stripped_dark_oak_log
setblock 49 129 346 minecraft:red_concrete
setblock 49 129 350 minecraft:red_concrete
setblock 49 129 356 minecraft:red_concrete
fill 50 129 357 50 129 360 minecraft:red_concrete
setblock 51 129 356 minecraft:red_concrete
setblock 51 129 361 minecraft:red_concrete
fill 51 129 363 51 142 363 minecraft:stripped_dark_oak_log
setblock 52 129 346 minecraft:red_concrete
setblock 52 129 350 minecraft:red_concrete
fill 52 129 355 54 129 355 minecraft:red_concrete
setblock 53 129 347 minecraft:red_concrete
setblock 53 129 349 minecraft:red_concrete
fill 54 129 323 54 130 323 minecraft:stripped_dark_oak_log
setblock 55 129 356 minecraft:red_concrete
setblock 55 129 361 minecraft:red_concrete
fill 56 129 357 56 129 360 minecraft:red_concrete
fill 58 129 363 58 132 363 minecraft:stripped_dark_oak_log
fill 59 129 355 59 134 355 minecraft:dark_oak_planks
fill 61 129 353 61 134 353 minecraft:dark_oak_planks
fill 62 129 356 62 134 356 minecraft:dark_oak_planks
fill 63 129 322 63 139 322 minecraft:dark_oak_planks
fill 65 129 363 65 130 363 minecraft:stripped_dark_oak_log
setblock 68 129 323 minecraft:stripped_dark_oak_log
fill 72 129 363 72 130 363 minecraft:stripped_dark_oak_log
fill 75 129 323 75 130 323 minecraft:stripped_dark_oak_log
fill 79 129 363 79 130 363 minecraft:stripped_dark_oak_log
fill 82 129 323 82 130 323 minecraft:stripped_dark_oak_log
fill 86 129 363 86 130 363 minecraft:stripped_dark_oak_log
fill 87 129 341 87 130 343 minecraft:stripped_dark_oak_log
fill 88 129 324 88 130 324 minecraft:stripped_dark_oak_log
fill 88 129 331 88 130 331 minecraft:stripped_dark_oak_log
fill 88 129 338 88 130 338 minecraft:stripped_dark_oak_log
fill 88 129 342 88 130 343 minecraft:stripped_dark_oak_log
fill 88 129 345 88 130 345 minecraft:stripped_dark_oak_log
fill 88 129 352 88 130 352 minecraft:stripped_dark_oak_log
fill 88 129 359 88 130 359 minecraft:stripped_dark_oak_log
fill 48 130 323 49 130 323 minecraft:stripped_dark_oak_log
fill 48 130 325 48 130 327 minecraft:stripped_dark_oak_log
fill 48 130 329 48 130 330 minecraft:stripped_dark_oak_log
fill 48 130 332 48 130 334 minecraft:stripped_dark_oak_log
fill 48 130 336 48 130 337 minecraft:stripped_dark_oak_log
fill 48 130 339 48 130 340 minecraft:stripped_dark_oak_log
fill 48 130 344 54 142 344 minecraft:stripped_dark_oak_log
fill 48 130 346 54 142 348 minecraft:stripped_dark_oak_log
fill 48 130 350 54 142 351 minecraft:stripped_dark_oak_log
fill 48 130 353 54 132 355 minecraft:stripped_dark_oak_log
fill 48 130 357 58 132 358 minecraft:stripped_dark_oak_log
fill 48 130 360 58 132 362 minecraft:stripped_dark_oak_log
fill 49 130 341 49 131 343 minecraft:stripped_dark_oak_log
fill 49 130 345 54 142 345 minecraft:stripped_dark_oak_log
fill 49 130 349 54 142 349 minecraft:stripped_dark_oak_log
fill 49 130 352 54 142 352 minecraft:stripped_dark_oak_log
fill 49 130 356 58 132 356 minecraft:stripped_dark_oak_log
fill 49 130 359 58 132 359 minecraft:stripped_dark_oak_log
fill 49 130 363 50 132 363 minecraft:stripped_dark_oak_log
setblock 50 130 325 minecraft:light[level=12]
setblock 50 130 332 minecraft:light[level=12]
setblock 50 130 339 minecraft:light[level=12]
fill 50 130 342 54 142 343 minecraft:stripped_dark_oak_log
fill 51 130 323 53 130 323 minecraft:stripped_dark_oak_log
fill 52 130 363 54 132 363 minecraft:stripped_dark_oak_log
fill 55 130 323 56 130 323 minecraft:stripped_dark_oak_log
fill 55 130 354 58 132 355 minecraft:stripped_dark_oak_log
fill 56 130 363 57 132 363 minecraft:stripped_dark_oak_log
setblock 57 130 325 minecraft:light[level=12]
setblock 57 130 332 minecraft:light[level=12]
setblock 57 130 339 minecraft:light[level=12]
setblock 57 130 346 minecraft:light[level=12]
setblock 57 130 353 minecraft:light[level=12]
setblock 58 130 323 minecraft:shroomlight
setblock 58 130 325 minecraft:shroomlight
setblock 58 130 327 minecraft:shroomlight
setblock 58 130 329 minecraft:shroomlight
setblock 58 130 331 minecraft:shroomlight
setblock 59 130 324 minecraft:shroomlight
setblock 59 130 326 minecraft:shroomlight
setblock 59 130 328 minecraft:shroomlight
setblock 59 130 330 minecraft:shroomlight
fill 59 130 354 59 134 354 minecraft:dark_oak_planks
fill 59 130 356 59 134 356 minecraft:dark_oak_planks
fill 59 130 363 61 130 363 minecraft:stripped_dark_oak_log
setblock 60 130 323 minecraft:shroomlight
setblock 60 130 325 minecraft:shroomlight
setblock 60 130 327 minecraft:shroomlight
setblock 60 130 329 minecraft:shroomlight
setblock 60 130 331 minecraft:shroomlight
fill 60 130 353 60 134 353 minecraft:dark_oak_planks
fill 60 130 357 62 134 357 minecraft:dark_oak_planks
setblock 61 130 324 minecraft:shroomlight
setblock 61 130 326 minecraft:shroomlight
setblock 61 130 328 minecraft:shroomlight
setblock 61 130 330 minecraft:shroomlight
setblock 62 130 323 minecraft:shroomlight
setblock 62 130 325 minecraft:shroomlight
setblock 62 130 327 minecraft:shroomlight
setblock 62 130 329 minecraft:shroomlight
setblock 62 130 331 minecraft:shroomlight
fill 62 130 353 62 134 353 minecraft:dark_oak_planks
setblock 63 130 324 minecraft:shroomlight
setblock 63 130 326 minecraft:shroomlight
setblock 63 130 328 minecraft:shroomlight
setblock 63 130 330 minecraft:shroomlight
fill 63 130 354 63 134 356 minecraft:dark_oak_planks
fill 63 130 363 64 130 363 minecraft:stripped_dark_oak_log
setblock 64 130 323 minecraft:shroomlight
setblock 64 130 325 minecraft:shroomlight
setblock 64 130 327 minecraft:shroomlight
setblock 64 130 329 minecraft:shroomlight
setblock 64 130 331 minecraft:shroomlight
setblock 64 130 332 minecraft:light[level=12]
setblock 64 130 339 minecraft:light[level=12]
setblock 64 130 346 minecraft:light[level=12]
setblock 64 130 353 minecraft:light[level=12]
setblock 64 130 360 minecraft:light[level=12]
setblock 65 130 324 minecraft:shroomlight
setblock 65 130 326 minecraft:shroomlight
setblock 65 130 328 minecraft:shroomlight
setblock 65 130 330 minecraft:shroomlight
setblock 66 130 323 minecraft:shroomlight
setblock 66 130 325 minecraft:shroomlight
setblock 66 130 327 minecraft:shroomlight
setblock 66 130 329 minecraft:shroomlight
setblock 66 130 331 minecraft:shroomlight
fill 66 130 363 68 130 363 minecraft:stripped_dark_oak_log
setblock 67 130 324 minecraft:shroomlight
setblock 67 130 326 minecraft:shroomlight
setblock 67 130 328 minecraft:shroomlight
setblock 67 130 330 minecraft:shroomlight
setblock 68 130 323 minecraft:shroomlight
setblock 68 130 325 minecraft:shroomlight
setblock 68 130 327 minecraft:shroomlight
setblock 68 130 329 minecraft:shroomlight
setblock 68 130 331 minecraft:shroomlight
fill 69 130 323 70 130 323 minecraft:stripped_dark_oak_log
fill 70 130 363 71 130 363 minecraft:stripped_dark_oak_log
setblock 71 130 325 minecraft:light[level=12]
setblock 71 130 332 minecraft:light[level=12]
setblock 71 130 339 minecraft:light[level=12]
setblock 71 130 346 minecraft:light[level=12]
setblock 71 130 353 minecraft:light[level=12]
setblock 71 130 360 minecraft:light[level=12]
fill 72 130 323 74 130 323 minecraft:stripped_dark_oak_log
fill 73 130 363 75 130 363 minecraft:stripped_dark_oak_log
fill 76 130 323 77 130 323 minecraft:stripped_dark_oak_log
fill 77 130 363 78 130 363 minecraft:stripped_dark_oak_log
setblock 78 130 325 minecraft:light[level=12]
setblock 78 130 332 minecraft:light[level=12]
setblock 78 130 339 minecraft:light[level=12]
setblock 78 130 346 minecraft:light[level=12]
setblock 78 130 353 minecraft:light[level=12]
setblock 78 130 360 minecraft:light[level=12]
fill 79 130 323 81 130 323 minecraft:stripped_dark_oak_log
fill 80 130 363 82 130 363 minecraft:stripped_dark_oak_log
fill 83 130 323 84 130 323 minecraft:stripped_dark_oak_log
fill 84 130 363 85 130 363 minecraft:stripped_dark_oak_log
setblock 85 130 325 minecraft:light[level=12]
setblock 85 130 332 minecraft:light[level=12]
setblock 85 130 339 minecraft:light[level=12]
fill 85 130 342 86 132 342 minecraft:stripped_dark_oak_log
setblock 85 130 346 minecraft:light[level=12]
setblock 85 130 353 minecraft:light[level=12]
fill 86 130 323 88 130 323 minecraft:stripped_dark_oak_log
fill 86 130 341 86 131 341 minecraft:stripped_dark_oak_log
fill 86 130 343 86 131 343 minecraft:stripped_dark_oak_log
fill 87 130 363 88 130 363 minecraft:stripped_dark_oak_log
fill 88 130 325 88 130 326 minecraft:stripped_dark_oak_log
fill 88 130 328 88 130 330 minecraft:stripped_dark_oak_log
fill 88 130 332 88 130 333 minecraft:stripped_dark_oak_log
fill 88 130 335 88 130 337 minecraft:stripped_dark_oak_log
fill 88 130 339 88 130 340 minecraft:stripped_dark_oak_log
setblock 88 130 344 minecraft:stripped_dark_oak_log
fill 88 130 346 88 130 347 minecraft:stripped_dark_oak_log
fill 88 130 349 88 130 351 minecraft:stripped_dark_oak_log
fill 88 130 353 88 130 354 minecraft:stripped_dark_oak_log
fill 88 130 356 88 130 358 minecraft:stripped_dark_oak_log
fill 88 130 360 88 130 361 minecraft:stripped_dark_oak_log
setblock 48 131 326 minecraft:stripped_dark_oak_log
setblock 48 131 333 minecraft:stripped_dark_oak_log
setblock 48 131 340 minecraft:stripped_dark_oak_log
fill 50 131 341 50 132 341 minecraft:stripped_dark_oak_log
setblock 52 131 323 minecraft:stripped_dark_oak_log
fill 58 131 323 58 132 323 minecraft:stripped_dark_oak_log
fill 58 131 325 58 132 325 minecraft:stripped_dark_oak_log
fill 58 131 327 58 132 327 minecraft:stripped_dark_oak_log
fill 58 131 329 58 132 329 minecraft:stripped_dark_oak_log
fill 58 131 331 58 132 331 minecraft:stripped_dark_oak_log
fill 59 131 324 59 132 324 minecraft:stripped_dark_oak_log
fill 59 131 326 59 132 326 minecraft:stripped_dark_oak_log
fill 59 131 328 59 132 328 minecraft:stripped_dark_oak_log
fill 59 131 330 59 132 330 minecraft:stripped_dark_oak_log
fill 59 131 353 59 134 353 minecraft:dark_oak_planks
fill 59 131 357 59 134 357 minecraft:dark_oak_planks
fill 60 131 323 60 132 323 minecraft:stripped_dark_oak_log
fill 60 131 325 60 132 325 minecraft:stripped_dark_oak_log
fill 60 131 327 60 132 327 minecraft:stripped_dark_oak_log
fill 60 131 329 60 132 329 minecraft:stripped_dark_oak_log
fill 60 131 331 60 132 331 minecraft:stripped_dark_oak_log
setblock 60 131 363 minecraft:stripped_dark_oak_log
fill 61 131 324 61 132 324 minecraft:stripped_dark_oak_log
fill 61 131 326 61 132 326 minecraft:stripped_dark_oak_log
fill 61 131 328 61 132 328 minecraft:stripped_dark_oak_log
fill 61 131 330 61 132 330 minecraft:stripped_dark_oak_log
fill 61 131 352 61 134 352 minecraft:dark_oak_planks
fill 62 131 323 62 132 323 minecraft:stripped_dark_oak_log
fill 62 131 325 62 132 325 minecraft:stripped_dark_oak_log
fill 62 131 327 62 132 327 minecraft:stripped_dark_oak_log
fill 62 131 329 62 132 329 minecraft:stripped_dark_oak_log
fill 62 131 331 62 132 331 minecraft:stripped_dark_oak_log
fill 63 131 324 63 132 324 minecraft:stripped_dark_oak_log
fill 63 131 326 63 132 326 minecraft:stripped_dark_oak_log
fill 63 131 328 63 132 328 minecraft:stripped_dark_oak_log
fill 63 131 330 63 132 330 minecraft:stripped_dark_oak_log
fill 63 131 353 63 134 353 minecraft:dark_oak_planks
fill 64 131 323 64 132 323 minecraft:stripped_dark_oak_log
fill 64 131 325 64 132 325 minecraft:stripped_dark_oak_log
fill 64 131 327 64 132 327 minecraft:stripped_dark_oak_log
fill 64 131 329 64 132 329 minecraft:stripped_dark_oak_log
fill 64 131 331 64 132 331 minecraft:stripped_dark_oak_log
fill 65 131 324 65 132 324 minecraft:stripped_dark_oak_log
fill 65 131 326 65 132 326 minecraft:stripped_dark_oak_log
fill 65 131 328 65 132 328 minecraft:stripped_dark_oak_log
fill 65 131 330 65 132 330 minecraft:stripped_dark_oak_log
fill 66 131 323 66 132 323 minecraft:stripped_dark_oak_log
fill 66 131 325 66 132 325 minecraft:stripped_dark_oak_log
fill 66 131 327 66 132 327 minecraft:stripped_dark_oak_log
fill 66 131 329 66 132 329 minecraft:stripped_dark_oak_log
fill 66 131 331 66 132 331 minecraft:stripped_dark_oak_log
fill 67 131 324 67 132 324 minecraft:stripped_dark_oak_log
fill 67 131 326 67 132 326 minecraft:stripped_dark_oak_log
fill 67 131 328 67 132 328 minecraft:stripped_dark_oak_log
fill 67 131 330 67 132 330 minecraft:stripped_dark_oak_log
setblock 67 131 363 minecraft:stripped_dark_oak_log
fill 68 131 323 68 132 323 minecraft:stripped_dark_oak_log
fill 68 131 325 68 132 325 minecraft:stripped_dark_oak_log
fill 68 131 327 68 132 327 minecraft:stripped_dark_oak_log
fill 68 131 329 68 132 329 minecraft:stripped_dark_oak_log
fill 68 131 331 68 132 331 minecraft:stripped_dark_oak_log
setblock 73 131 323 minecraft:stripped_dark_oak_log
setblock 74 131 363 minecraft:stripped_dark_oak_log
setblock 80 131 323 minecraft:stripped_dark_oak_log
setblock 81 131 363 minecraft:stripped_dark_oak_log
fill 84 131 342 84 133 342 minecraft:stripped_dark_oak_log
fill 85 131 341 85 132 341 minecraft:stripped_dark_oak_log
fill 85 131 343 85 132 343 minecraft:stripped_dark_oak_log
setblock 87 131 323 minecraft:stripped_dark_oak_log
setblock 87 131 342 minecraft:stripped_dark_oak_log
setblock 88 131 329 minecraft:stripped_dark_oak_log
setblock 88 131 336 minecraft:stripped_dark_oak_log
setblock 88 131 342 minecraft:red_concrete
setblock 88 131 343 minecraft:stripped_dark_oak_log
setblock 88 131 350 minecraft:stripped_dark_oak_log
setblock 88 131 357 minecraft:stripped_dark_oak_log
setblock 88 131 363 minecraft:stripped_dark_oak_log
setblock 89 131 327 minecraft:red_concrete
setblock 48 132 327 minecraft:stripped_dark_oak_log
setblock 48 132 334 minecraft:stripped_dark_oak_log
setblock 48 132 341 minecraft:stripped_dark_oak_log
fill 49 132 342 49 142 343 minecraft:stripped_dark_oak_log
setblock 51 132 323 minecraft:stripped_dark_oak_log
fill 51 132 341 52 133 341 minecraft:stripped_dark_oak_log
fill 58 132 353 58 134 353 minecraft:dark_oak_planks
fill 59 132 359 59 135 359 minecraft:iron_bars
fill 60 132 352 60 134 352 minecraft:dark_oak_planks
fill 60 132 358 62 134 358 minecraft:dark_oak_planks
setblock 61 132 363 minecraft:stripped_dark_oak_log
fill 62 132 352 62 134 352 minecraft:dark_oak_planks
fill 63 132 357 63 134 357 minecraft:dark_oak_planks
fill 64 132 354 64 134 356 minecraft:dark_oak_planks
setblock 68 132 363 minecraft:stripped_dark_oak_log
setblock 72 132 323 minecraft:stripped_dark_oak_log
setblock 75 132 363 minecraft:stripped_dark_oak_log
setblock 79 132 323 minecraft:stripped_dark_oak_log
setblock 81 132 322 minecraft:red_concrete
fill 82 132 322 89 144 322 minecraft:dark_oak_planks
fill 82 132 357 82 132 358 minecraft:dark_oak_planks
setblock 82 132 360 minecraft:dark_oak_planks
setblock 82 132 363 minecraft:stripped_dark_oak_log
fill 83 132 341 83 133 343 minecraft:stripped_dark_oak_log
fill 83 132 357 85 132 357 minecraft:dark_oak_planks
fill 83 132 361 85 132 361 minecraft:dark_oak_planks
fill 84 132 341 84 133 341 minecraft:stripped_dark_oak_log
fill 84 132 343 84 133 343 minecraft:stripped_dark_oak_log
setblock 86 132 323 minecraft:stripped_dark_oak_log
fill 86 132 358 86 132 360 minecraft:dark_oak_planks
setblock 87 132 342 minecraft:red_concrete
setblock 88 132 328 minecraft:stripped_dark_oak_log
setblock 88 132 335 minecraft:stripped_dark_oak_log
setblock 88 132 342 minecraft:stripped_dark_oak_log
setblock 88 132 349 minecraft:stripped_dark_oak_log
setblock 88 132 356 minecraft:stripped_dark_oak_log
fill 89 132 327 89 144 327 minecraft:dark_oak_planks
fill 47 133 355 47 144 355 minecraft:dark_oak_planks
setblock 47 133 356 minecraft:red_concrete
fill 47 133 357 47 136 362 minecraft:dark_oak_planks
fill 48 133 353 48 142 354 minecraft:stripped_dark_oak_log
setblock 48 133 355 minecraft:shroomlight
setblock 48 133 357 minecraft:shroomlight
fill 48 133 358 48 142 358 minecraft:stripped_dark_oak_log
setblock 48 133 359 minecraft:shroomlight
fill 48 133 360 48 142 360 minecraft:stripped_dark_oak_log
setblock 48 133 361 minecraft:shroomlight
fill 48 133 362 48 142 362 minecraft:stripped_dark_oak_log
setblock 48 133 363 minecraft:shroomlight
fill 49 133 353 54 142 353 minecraft:stripped_dark_oak_log
setblock 49 133 354 minecraft:shroomlight
fill 49 133 355 49 142 355 minecraft:stripped_dark_oak_log
setblock 49 133 356 minecraft:shroomlight
fill 49 133 357 49 142 357 minecraft:stripped_dark_oak_log
setblock 49 133 358 minecraft:shroomlight
fill 49 133 359 49 142 359 minecraft:stripped_dark_oak_log
setblock 49 133 360 minecraft:shroomlight
fill 49 133 361 49 142 361 minecraft:stripped_dark_oak_log
setblock 49 133 362 minecraft:shroomlight
fill 49 133 363 49 142 363 minecraft:stripped_dark_oak_log
fill 50 133 354 50 142 354 minecraft:stripped_dark_oak_log
setblock 50 133 355 minecraft:shroomlight
fill 50 133 356 50 142 356 minecraft:stripped_dark_oak_log
setblock 50 133 357 minecraft:shroomlight
fill 50 133 358 50 142 358 minecraft:stripped_dark_oak_log
setblock 50 133 359 minecraft:shroomlight
fill 50 133 360 50 142 360 minecraft:stripped_dark_oak_log
setblock 50 133 361 minecraft:shroomlight
fill 50 133 362 50 142 362 minecraft:stripped_dark_oak_log
setblock 50 133 363 minecraft:shroomlight
setblock 51 133 354 minecraft:shroomlight
fill 51 133 355 51 142 355 minecraft:stripped_dark_oak_log
setblock 51 133 356 minecraft:shroomlight
fill 51 133 357 51 142 357 minecraft:stripped_dark_oak_log
setblock 51 133 358 minecraft:shroomlight
fill 51 133 359 51 142 359 minecraft:stripped_dark_oak_log
setblock 51 133 360 minecraft:shroomlight
fill 51 133 361 51 142 361 minecraft:stripped_dark_oak_log
setblock 51 133 362 minecraft:shroomlight
fill 52 133 354 52 142 354 minecraft:stripped_dark_oak_log
setblock 52 133 355 minecraft:shroomlight
fill 52 133 356 52 142 356 minecraft:stripped_dark_oak_log
setblock 52 133 357 minecraft:shroomlight
fill 52 133 358 52 142 358 minecraft:stripped_dark_oak_log
setblock 52 133 359 minecraft:shroomlight
fill 52 133 360 52 142 360 minecraft:stripped_dark_oak_log
setblock 52 133 361 minecraft:shroomlight
fill 52 133 362 52 142 362 minecraft:stripped_dark_oak_log
setblock 52 133 363 minecraft:shroomlight
fill 53 133 341 53 134 341 minecraft:stripped_dark_oak_log
setblock 53 133 354 minecraft:shroomlight
fill 53 133 355 53 142 355 minecraft:stripped_dark_oak_log
setblock 53 133 356 minecraft:shroomlight
fill 53 133 357 53 142 357 minecraft:stripped_dark_oak_log
setblock 53 133 358 minecraft:shroomlight
fill 53 133 359 53 142 359 minecraft:stripped_dark_oak_log
setblock 53 133 360 minecraft:shroomlight
fill 53 133 361 53 142 361 minecraft:stripped_dark_oak_log
setblock 53 133 362 minecraft:shroomlight
fill 53 133 363 53 142 363 minecraft:stripped_dark_oak_log
fill 54 133 354 54 142 354 minecraft:stripped_dark_oak_log
setblock 54 133 355 minecraft:shroomlight
fill 54 133 356 54 142 356 minecraft:stripped_dark_oak_log
setblock 54 133 357 minecraft:shroomlight
fill 54 133 358 54 142 358 minecraft:stripped_dark_oak_log
setblock 54 133 359 minecraft:shroomlight
fill 54 133 360 54 142 360 minecraft:stripped_dark_oak_log
setblock 54 133 361 minecraft:shroomlight
fill 54 133 362 54 142 362 minecraft:stripped_dark_oak_log
setblock 54 133 363 minecraft:shroomlight
setblock 55 133 354 minecraft:shroomlight
fill 55 133 355 55 142 355 minecraft:stripped_dark_oak_log
setblock 55 133 356 minecraft:shroomlight
fill 55 133 357 55 142 357 minecraft:stripped_dark_oak_log
setblock 55 133 358 minecraft:shroomlight
fill 55 133 359 55 142 359 minecraft:stripped_dark_oak_log
setblock 55 133 360 minecraft:shroomlight
fill 55 133 361 55 142 361 minecraft:stripped_dark_oak_log
setblock 55 133 362 minecraft:shroomlight
fill 56 133 354 56 142 354 minecraft:stripped_dark_oak_log
setblock 56 133 355 minecraft:shroomlight
fill 56 133 356 56 142 356 minecraft:stripped_dark_oak_log
setblock 56 133 357 minecraft:shroomlight
fill 56 133 358 56 142 358 minecraft:stripped_dark_oak_log
setblock 56 133 359 minecraft:shroomlight
fill 56 133 360 56 142 360 minecraft:stripped_dark_oak_log
setblock 56 133 361 minecraft:shroomlight
fill 56 133 362 56 142 362 minecraft:stripped_dark_oak_log
setblock 56 133 363 minecraft:shroomlight
setblock 57 133 354 minecraft:shroomlight
fill 57 133 355 57 142 355 minecraft:stripped_dark_oak_log
setblock 57 133 356 minecraft:shroomlight
fill 57 133 357 57 142 357 minecraft:stripped_dark_oak_log
setblock 57 133 358 minecraft:shroomlight
fill 57 133 359 57 142 359 minecraft:stripped_dark_oak_log
setblock 57 133 360 minecraft:shroomlight
fill 57 133 361 57 142 361 minecraft:stripped_dark_oak_log
setblock 57 133 362 minecraft:shroomlight
fill 57 133 363 57 142 363 minecraft:stripped_dark_oak_log
setblock 58 133 322 minecraft:red_concrete
setblock 58 133 323 minecraft:shroomlight
setblock 58 133 325 minecraft:shroomlight
setblock 58 133 327 minecraft:shroomlight
setblock 58 133 329 minecraft:shroomlight
setblock 58 133 331 minecraft:shroomlight
fill 58 133 354 58 142 354 minecraft:stripped_dark_oak_log
setblock 58 133 355 minecraft:shroomlight
fill 58 133 356 58 142 356 minecraft:stripped_dark_oak_log
setblock 58 133 357 minecraft:shroomlight
fill 58 133 358 58 142 358 minecraft:stripped_dark_oak_log
setblock 58 133 359 minecraft:shroomlight
fill 58 133 360 58 142 360 minecraft:stripped_dark_oak_log
setblock 58 133 361 minecraft:shroomlight
fill 58 133 362 58 142 362 minecraft:stripped_dark_oak_log
setblock 58 133 363 minecraft:shroomlight
fill 59 133 322 59 140 322 minecraft:dark_oak_planks
setblock 59 133 324 minecraft:shroomlight
setblock 59 133 326 minecraft:shroomlight
setblock 59 133 328 minecraft:shroomlight
setblock 59 133 330 minecraft:shroomlight
fill 59 133 352 59 134 352 minecraft:dark_oak_planks
fill 59 133 358 59 134 358 minecraft:dark_oak_planks
setblock 60 133 323 minecraft:shroomlight
setblock 60 133 325 minecraft:shroomlight
setblock 60 133 327 minecraft:shroomlight
setblock 60 133 329 minecraft:shroomlight
setblock 60 133 331 minecraft:shroomlight
setblock 61 133 324 minecraft:shroomlight
setblock 61 133 326 minecraft:shroomlight
setblock 61 133 328 minecraft:shroomlight
setblock 61 133 330 minecraft:shroomlight
fill 61 133 351 61 134 351 minecraft:dark_oak_planks
setblock 62 133 323 minecraft:shroomlight
setblock 62 133 325 minecraft:shroomlight
setblock 62 133 327 minecraft:shroomlight
setblock 62 133 329 minecraft:shroomlight
setblock 62 133 331 minecraft:shroomlight
setblock 63 133 324 minecraft:shroomlight
setblock 63 133 326 minecraft:shroomlight
setblock 63 133 328 minecraft:shroomlight
setblock 63 133 330 minecraft:shroomlight
fill 63 133 352 63 134 352 minecraft:dark_oak_planks
fill 63 133 358 63 134 358 minecraft:dark_oak_planks
setblock 64 133 323 minecraft:shroomlight
setblock 64 133 325 minecraft:shroomlight
setblock 64 133 327 minecraft:shroomlight
setblock 64 133 329 minecraft:shroomlight
setblock 64 133 331 minecraft:shroomlight
fill 64 133 353 64 134 353 minecraft:dark_oak_planks
fill 64 133 357 64 134 357 minecraft:dark_oak_planks
setblock 65 133 324 minecraft:shroomlight
setblock 65 133 326 minecraft:shroomlight
setblock 65 133 328 minecraft:shroomlight
setblock 65 133 330 minecraft:shroomlight
setblock 66 133 323 minecraft:shroomlight
setblock 66 133 325 minecraft:shroomlight
setblock 66 133 327 minecraft:shroomlight
setblock 66 133 329 minecraft:shroomlight
setblock 66 133 331 minecraft:shroomlight
setblock 67 133 324 minecraft:shroomlight
setblock 67 133 326 minecraft:shroomlight
setblock 67 133 328 minecraft:shroomlight
setblock 67 133 330 minecraft:shroomlight
setblock 68 133 323 minecraft:shroomlight
setblock 68 133 325 minecraft:shroomlight
setblock 68 133 327 minecraft:shroomlight
setblock 68 133 329 minecraft:shroomlight
setblock 68 133 331 minecraft:shroomlight
fill 74 133 322 76 141 322 minecraft:dark_oak_planks
setblock 77 133 322 minecraft:red_concrete
fill 78 133 322 78 144 322 minecraft:dark_oak_planks
fill 81 133 322 81 144 322 minecraft:dark_oak_planks
fill 81 133 342 82 135 342 minecraft:stripped_dark_oak_log
fill 82 133 341 82 134 341 minecraft:stripped_dark_oak_log
fill 82 133 343 82 134 343 minecraft:stripped_dark_oak_log
setblock 83 133 364 minecraft:red_concrete
setblock 85 133 342 minecraft:stripped_dark_oak_log
setblock 86 133 342 minecraft:red_concrete
setblock 47 134 353 minecraft:red_concrete
fill 47 134 356 47 140 356 minecraft:dark_oak_planks
setblock 48 134 329 minecraft:stripped_dark_oak_log
setblock 48 134 336 minecraft:stripped_dark_oak_log
fill 48 134 355 48 135 355 minecraft:stripped_dark_oak_log
fill 48 134 357 48 135 357 minecraft:stripped_dark_oak_log
fill 48 134 359 48 135 359 minecraft:stripped_dark_oak_log
fill 48 134 361 48 135 361 minecraft:stripped_dark_oak_log
fill 48 134 363 48 135 363 minecraft:stripped_dark_oak_log
setblock 49 134 323 minecraft:stripped_dark_oak_log
fill 49 134 354 49 135 354 minecraft:stripped_dark_oak_log
fill 49 134 356 49 135 356 minecraft:stripped_dark_oak_log
fill 49 134 358 49 135 358 minecraft:stripped_dark_oak_log
fill 49 134 360 49 135 360 minecraft:stripped_dark_oak_log
fill 49 134 362 49 135 362 minecraft:stripped_dark_oak_log
fill 50 134 355 50 135 355 minecraft:stripped_dark_oak_log
fill 50 134 357 50 135 357 minecraft:stripped_dark_oak_log
fill 50 134 359 50 135 359 minecraft:stripped_dark_oak_log
fill 50 134 361 50 135 361 minecraft:stripped_dark_oak_log
fill 50 134 363 50 135 363 minecraft:stripped_dark_oak_log
fill 51 134 354 51 135 354 minecraft:stripped_dark_oak_log
fill 51 134 356 51 135 356 minecraft:stripped_dark_oak_log
fill 51 134 358 51 135 358 minecraft:stripped_dark_oak_log
fill 51 134 360 51 135 360 minecraft:stripped_dark_oak_log
fill 51 134 362 51 135 362 minecraft:stripped_dark_oak_log
fill 52 134 355 52 135 355 minecraft:stripped_dark_oak_log
fill 52 134 357 52 135 357 minecraft:stripped_dark_oak_log
fill 52 134 359 52 135 359 minecraft:stripped_dark_oak_log
fill 52 134 361 52 135 361 minecraft:stripped_dark_oak_log
fill 52 134 363 52 135 363 minecraft:stripped_dark_oak_log
fill 53 134 354 53 135 354 minecraft:stripped_dark_oak_log
fill 53 134 356 53 135 356 minecraft:stripped_dark_oak_log
fill 53 134 358 53 135 358 minecraft:stripped_dark_oak_log
fill 53 134 360 53 135 360 minecraft:stripped_dark_oak_log
fill 53 134 362 53 135 362 minecraft:stripped_dark_oak_log
fill 54 134 341 54 135 341 minecraft:stripped_dark_oak_log
fill 54 134 355 54 135 355 minecraft:stripped_dark_oak_log
fill 54 134 357 54 135 357 minecraft:stripped_dark_oak_log
fill 54 134 359 54 135 359 minecraft:stripped_dark_oak_log
fill 54 134 361 54 135 361 minecraft:stripped_dark_oak_log
fill 54 134 363 54 135 363 minecraft:stripped_dark_oak_log
fill 55 134 342 55 136 342 minecraft:stripped_dark_oak_log
fill 55 134 354 55 135 354 minecraft:stripped_dark_oak_log
fill 55 134 356 55 135 356 minecraft:stripped_dark_oak_log
fill 55 134 358 55 135 358 minecraft:stripped_dark_oak_log
fill 55 134 360 55 135 360 minecraft:stripped_dark_oak_log
fill 55 134 362 55 135 362 minecraft:stripped_dark_oak_log
setblock 56 134 323 minecraft:stripped_dark_oak_log
fill 56 134 355 56 135 355 minecraft:stripped_dark_oak_log
fill 56 134 357 56 135 357 minecraft:stripped_dark_oak_log
fill 56 134 359 56 135 359 minecraft:stripped_dark_oak_log
fill 56 134 361 56 135 361 minecraft:stripped_dark_oak_log
fill 56 134 363 56 135 363 minecraft:stripped_dark_oak_log
setblock 57 134 353 minecraft:dark_oak_planks
fill 57 134 354 57 135 354 minecraft:stripped_dark_oak_log
fill 57 134 356 57 135 356 minecraft:stripped_dark_oak_log
fill 57 134 358 57 135 358 minecraft:stripped_dark_oak_log
fill 57 134 360 57 135 360 minecraft:stripped_dark_oak_log
fill 57 134 362 57 135 362 minecraft:stripped_dark_oak_log
fill 58 134 322 58 144 322 minecraft:dark_oak_planks
fill 58 134 323 58 135 323 minecraft:stripped_dark_oak_log
fill 58 134 325 58 135 325 minecraft:stripped_dark_oak_log
fill 58 134 327 58 135 327 minecraft:stripped_dark_oak_log
fill 58 134 329 58 135 329 minecraft:stripped_dark_oak_log
fill 58 134 331 58 135 331 minecraft:stripped_dark_oak_log
setblock 58 134 352 minecraft:dark_oak_planks
fill 58 134 355 58 135 355 minecraft:stripped_dark_oak_log
fill 58 134 357 58 135 357 minecraft:stripped_dark_oak_log
fill 58 134 359 58 135 359 minecraft:stripped_dark_oak_log
fill 58 134 361 58 135 361 minecraft:stripped_dark_oak_log
fill 58 134 363 58 135 363 minecraft:stripped_dark_oak_log
fill 59 134 324 59 135 324 minecraft:stripped_dark_oak_log
fill 59 134 326 59 135 326 minecraft:stripped_dark_oak_log
fill 59 134 328 59 135 328 minecraft:stripped_dark_oak_log
fill 59 134 330 59 135 330 minecraft:stripped_dark_oak_log
fill 59 134 351 60 134 351 minecraft:dark_oak_planks
fill 60 134 323 60 135 323 minecraft:stripped_dark_oak_log
fill 60 134 325 60 135 325 minecraft:stripped_dark_oak_log
fill 60 134 327 60 135 327 minecraft:stripped_dark_oak_log
fill 60 134 329 60 135 329 minecraft:stripped_dark_oak_log
fill 60 134 331 60 135 331 minecraft:stripped_dark_oak_log
fill 60 134 359 62 134 359 minecraft:dark_oak_planks
fill 61 134 324 61 135 324 minecraft:stripped_dark_oak_log
fill 61 134 326 61 135 326 minecraft:stripped_dark_oak_log
fill 61 134 328 61 135 328 minecraft:stripped_dark_oak_log
fill 61 134 330 61 135 330 minecraft:stripped_dark_oak_log
fill 62 134 323 62 135 323 minecraft:stripped_dark_oak_log
fill 62 134 325 62 135 325 minecraft:stripped_dark_oak_log
fill 62 134 327 62 135 327 minecraft:stripped_dark_oak_log
fill 62 134 329 62 135 329 minecraft:stripped_dark_oak_log
fill 62 134 331 62 135 331 minecraft:stripped_dark_oak_log
setblock 62 134 351 minecraft:dark_oak_planks
fill 63 134 324 63 135 324 minecraft:stripped_dark_oak_log
fill 63 134 326 63 135 326 minecraft:stripped_dark_oak_log
fill 63 134 328 63 135 328 minecraft:stripped_dark_oak_log
fill 63 134 330 63 135 330 minecraft:stripped_dark_oak_log
setblock 63 134 363 minecraft:stripped_dark_oak_log
fill 64 134 323 64 135 323 minecraft:stripped_dark_oak_log
fill 64 134 325 64 135 325 minecraft:stripped_dark_oak_log
fill 64 134 327 64 135 327 minecraft:stripped_dark_oak_log
fill 64 134 329 64 135 329 minecraft:stripped_dark_oak_log
fill 64 134 331 64 135 331 minecraft:stripped_dark_oak_log
setblock 64 134 352 minecraft:dark_oak_planks
fill 65 134 324 65 135 324 minecraft:stripped_dark_oak_log
fill 65 134 326 65 135 326 minecraft:stripped_dark_oak_log
fill 65 134 328 65 135 328 minecraft:stripped_dark_oak_log
fill 65 134 330 65 135 330 minecraft:stripped_dark_oak_log
fill 65 134 354 65 134 356 minecraft:dark_oak_planks
fill 66 134 323 66 135 323 minecraft:stripped_dark_oak_log
fill 66 134 325 66 135 325 minecraft:stripped_dark_oak_log
fill 66 134 327 66 135 327 minecraft:stripped_dark_oak_log
fill 66 134 329 66 135 329 minecraft:stripped_dark_oak_log
fill 66 134 331 66 135 331 minecraft:stripped_dark_oak_log
fill 67 134 324 67 135 324 minecraft:stripped_dark_oak_log
fill 67 134 326 67 135 326 minecraft:stripped_dark_oak_log
fill 67 134 328 67 135 328 minecraft:stripped_dark_oak_log
fill 67 134 330 67 135 330 minecraft:stripped_dark_oak_log
fill 68 134 323 68 135 323 minecraft:stripped_dark_oak_log
fill 68 134 325 68 135 325 minecraft:stripped_dark_oak_log
fill 68 134 327 68 135 327 minecraft:stripped_dark_oak_log
fill 68 134 329 68 135 329 minecraft:stripped_dark_oak_log
fill 68 134 331 68 135 331 minecraft:stripped_dark_oak_log
setblock 70 134 323 minecraft:stripped_dark_oak_log
setblock 70 134 363 minecraft:stripped_dark_oak_log
fill 73 134 364 73 144 364 minecraft:dark_oak_planks
setblock 74 134 364 minecraft:red_concrete
fill 75 134 364 77 141 364 minecraft:dark_oak_planks
fill 77 134 322 77 141 322 minecraft:dark_oak_planks
setblock 77 134 323 minecraft:stripped_dark_oak_log
setblock 77 134 363 minecraft:stripped_dark_oak_log
fill 80 134 342 80 136 342 minecraft:stripped_dark_oak_log
fill 81 134 341 81 135 341 minecraft:stripped_dark_oak_log
fill 81 134 343 81 135 343 minecraft:stripped_dark_oak_log
setblock 83 134 342 minecraft:stripped_dark_oak_log
fill 83 134 364 83 138 364 minecraft:dark_oak_planks
setblock 84 134 323 minecraft:stripped_dark_oak_log
setblock 84 134 342 minecraft:red_concrete
setblock 84 134 363 minecraft:stripped_dark_oak_log
setblock 88 134 326 minecraft:stripped_dark_oak_log
setblock 88 134 333 minecraft:stripped_dark_oak_log
setblock 88 134 340 minecraft:stripped_dark_oak_log
setblock 88 134 347 minecraft:stripped_dark_oak_log
setblock 88 134 354 minecraft:stripped_dark_oak_log
setblock 88 134 361 minecraft:stripped_dark_oak_log
setblock 47 135 338 minecraft:red_concrete
fill 47 135 353 47 144 353 minecraft:dark_oak_planks
setblock 48 135 323 minecraft:stripped_dark_oak_log
setblock 48 135 330 minecraft:stripped_dark_oak_log
setblock 48 135 337 minecraft:stripped_dark_oak_log
setblock 55 135 323 minecraft:stripped_dark_oak_log
fill 55 135 341 56 135 341 minecraft:stripped_dark_oak_log
fill 55 135 343 56 135 343 minecraft:stripped_dark_oak_log
fill 56 135 342 57 137 342 minecraft:stripped_dark_oak_log
fill 61 135 355 61 138 355 minecraft:stripped_dark_oak_log
setblock 64 135 363 minecraft:stripped_dark_oak_log
setblock 69 135 323 minecraft:stripped_dark_oak_log
setblock 71 135 363 minecraft:stripped_dark_oak_log
fill 74 135 364 74 145 364 minecraft:dark_oak_planks
setblock 76 135 323 minecraft:stripped_dark_oak_log
fill 78 135 342 79 137 342 minecraft:stripped_dark_oak_log
setblock 78 135 363 minecraft:stripped_dark_oak_log
fill 79 135 341 80 135 341 minecraft:stripped_dark_oak_log
fill 79 135 343 80 135 343 minecraft:stripped_dark_oak_log
setblock 83 135 323 minecraft:stripped_dark_oak_log
setblock 83 135 342 minecraft:red_concrete
setblock 85 135 363 minecraft:stripped_dark_oak_log
setblock 88 135 325 minecraft:stripped_dark_oak_log
setblock 88 135 332 minecraft:stripped_dark_oak_log
setblock 88 135 339 minecraft:stripped_dark_oak_log
setblock 88 135 346 minecraft:stripped_dark_oak_log
setblock 88 135 353 minecraft:stripped_dark_oak_log
setblock 88 135 360 minecraft:stripped_dark_oak_log
fill 89 135 345 89 144 347 minecraft:dark_oak_planks
setblock 89 135 348 minecraft:red_concrete
fill 89 135 349 89 144 349 minecraft:dark_oak_planks
fill 47 136 338 47 144 338 minecraft:dark_oak_planks
fill 47 136 347 47 139 349 minecraft:shroomlight
setblock 48 136 324 minecraft:stripped_dark_oak_log
setblock 48 136 331 minecraft:stripped_dark_oak_log
setblock 48 136 338 minecraft:stripped_dark_oak_log
setblock 48 136 355 minecraft:shroomlight
setblock 48 136 357 minecraft:shroomlight
setblock 48 136 359 minecraft:shroomlight
setblock 48 136 361 minecraft:shroomlight
setblock 48 136 363 minecraft:shroomlight
setblock 49 136 354 minecraft:shroomlight
setblock 49 136 356 minecraft:shroomlight
setblock 49 136 358 minecraft:shroomlight
setblock 49 136 360 minecraft:shroomlight
setblock 49 136 362 minecraft:shroomlight
setblock 50 136 325 minecraft:light[level=15]
setblock 50 136 332 minecraft:light[level=12]
setblock 50 136 333 minecraft:light[level=15]
setblock 50 136 339 minecraft:light[level=12]
setblock 50 136 341 minecraft:light[level=15]
setblock 50 136 355 minecraft:shroomlight
setblock 50 136 357 minecraft:shroomlight
setblock 50 136 359 minecraft:shroomlight
setblock 50 136 361 minecraft:shroomlight
setblock 50 136 363 minecraft:shroomlight
setblock 51 136 354 minecraft:shroomlight
setblock 51 136 356 minecraft:shroomlight
setblock 51 136 358 minecraft:shroomlight
setblock 51 136 360 minecraft:shroomlight
setblock 51 136 362 minecraft:shroomlight
setblock 52 136 355 minecraft:shroomlight
setblock 52 136 357 minecraft:shroomlight
setblock 52 136 359 minecraft:shroomlight
setblock 52 136 361 minecraft:shroomlight
setblock 52 136 363 minecraft:shroomlight
setblock 53 136 354 minecraft:shroomlight
setblock 53 136 356 minecraft:shroomlight
setblock 53 136 358 minecraft:shroomlight
setblock 53 136 360 minecraft:shroomlight
setblock 53 136 362 minecraft:shroomlight
setblock 54 136 323 minecraft:stripped_dark_oak_log
setblock 54 136 355 minecraft:shroomlight
setblock 54 136 357 minecraft:shroomlight
setblock 54 136 359 minecraft:shroomlight
setblock 54 136 361 minecraft:shroomlight
setblock 54 136 363 minecraft:shroomlight
setblock 55 136 354 minecraft:shroomlight
setblock 55 136 356 minecraft:shroomlight
setblock 55 136 358 minecraft:shroomlight
setblock 55 136 360 minecraft:shroomlight
setblock 55 136 362 minecraft:shroomlight
fill 56 136 341 58 136 341 minecraft:stripped_dark_oak_log
fill 56 136 343 58 136 343 minecraft:stripped_dark_oak_log
setblock 56 136 355 minecraft:shroomlight
setblock 56 136 357 minecraft:shroomlight
setblock 56 136 359 minecraft:shroomlight
setblock 56 136 361 minecraft:shroomlight
setblock 56 136 363 minecraft:shroomlight
setblock 57 136 325 minecraft:light[level=12]
setblock 57 136 332 minecraft:light[level=12]
setblock 57 136 339 minecraft:light[level=12]
setblock 57 136 346 minecraft:light[level=12]
setblock 57 136 353 minecraft:light[level=12]
setblock 57 136 354 minecraft:shroomlight
setblock 57 136 356 minecraft:shroomlight
setblock 57 136 358 minecraft:shroomlight
setblock 57 136 360 minecraft:shroomlight
setblock 57 136 362 minecraft:shroomlight
setblock 58 136 323 minecraft:shroomlight
setblock 58 136 325 minecraft:shroomlight
setblock 58 136 327 minecraft:shroomlight
setblock 58 136 329 minecraft:shroomlight
setblock 58 136 331 minecraft:shroomlight
setblock 58 136 333 minecraft:light[level=15]
fill 58 136 342 59 137 342 minecraft:stripped_dark_oak_log
setblock 58 136 349 minecraft:light[level=15]
setblock 58 136 355 minecraft:shroomlight
setblock 58 136 357 minecraft:shroomlight
setblock 58 136 359 minecraft:shroomlight
setblock 58 136 361 minecraft:shroomlight
setblock 58 136 363 minecraft:shroomlight
setblock 59 136 324 minecraft:shroomlight
setblock 59 136 326 minecraft:shroomlight
setblock 59 136 328 minecraft:shroomlight
setblock 59 136 330 minecraft:shroomlight
fill 59 136 359 63 136 362 minecraft:dark_oak_planks
setblock 60 136 323 minecraft:shroomlight
setblock 60 136 325 minecraft:shroomlight
setblock 60 136 327 minecraft:shroomlight
setblock 60 136 329 minecraft:shroomlight
setblock 60 136 331 minecraft:shroomlight
setblock 61 136 324 minecraft:shroomlight
setblock 61 136 326 minecraft:shroomlight
setblock 61 136 328 minecraft:shroomlight
setblock 61 136 330 minecraft:shroomlight
setblock 62 136 323 minecraft:shroomlight
setblock 62 136 325 minecraft:shroomlight
setblock 62 136 327 minecraft:shroomlight
setblock 62 136 329 minecraft:shroomlight
setblock 62 136 331 minecraft:shroomlight
setblock 63 136 324 minecraft:shroomlight
setblock 63 136 326 minecraft:shroomlight
setblock 63 136 328 minecraft:shroomlight
setblock 63 136 330 minecraft:shroomlight
setblock 64 136 323 minecraft:shroomlight
setblock 64 136 325 minecraft:shroomlight
setblock 64 136 327 minecraft:shroomlight
setblock 64 136 329 minecraft:shroomlight
setblock 64 136 331 minecraft:shroomlight
setblock 64 136 332 minecraft:light[level=12]
setblock 64 136 339 minecraft:light[level=12]
setblock 64 136 346 minecraft:light[level=12]
setblock 64 136 353 minecraft:light[level=12]
setblock 64 136 360 minecraft:light[level=12]
setblock 65 136 324 minecraft:shroomlight
setblock 65 136 326 minecraft:shroomlight
setblock 65 136 328 minecraft:shroomlight
setblock 65 136 330 minecraft:shroomlight
setblock 65 136 363 minecraft:stripped_dark_oak_log
setblock 66 136 323 minecraft:shroomlight
setblock 66 136 325 minecraft:shroomlight
setblock 66 136 327 minecraft:shroomlight
setblock 66 136 329 minecraft:shroomlight
setblock 66 136 331 minecraft:shroomlight
setblock 66 136 333 minecraft:light[level=15]
setblock 66 136 341 minecraft:light[level=15]
setblock 66 136 349 minecraft:light[level=15]
setblock 66 136 357 minecraft:light[level=15]
setblock 67 136 324 minecraft:shroomlight
setblock 67 136 326 minecraft:shroomlight
setblock 67 136 328 minecraft:shroomlight
setblock 67 136 330 minecraft:shroomlight
setblock 68 136 323 minecraft:shroomlight
setblock 68 136 325 minecraft:shroomlight
setblock 68 136 327 minecraft:shroomlight
setblock 68 136 329 minecraft:shroomlight
setblock 68 136 331 minecraft:shroomlight
setblock 71 136 325 minecraft:light[level=12]
setblock 71 136 332 minecraft:light[level=12]
setblock 71 136 339 minecraft:light[level=12]
setblock 71 136 346 minecraft:light[level=12]
setblock 71 136 353 minecraft:light[level=12]
setblock 71 136 360 minecraft:light[level=12]
setblock 72 136 363 minecraft:stripped_dark_oak_log
setblock 74 136 325 minecraft:light[level=15]
setblock 74 136 333 minecraft:light[level=15]
setblock 74 136 341 minecraft:light[level=15]
setblock 74 136 349 minecraft:light[level=15]
setblock 74 136 357 minecraft:light[level=15]
setblock 75 136 323 minecraft:stripped_dark_oak_log
fill 76 136 342 77 138 342 minecraft:stripped_dark_oak_log
fill 77 136 341 79 136 341 minecraft:stripped_dark_oak_log
fill 77 136 343 79 136 343 minecraft:stripped_dark_oak_log
setblock 78 136 325 minecraft:light[level=12]
setblock 78 136 332 minecraft:light[level=12]
setblock 78 136 339 minecraft:light[level=12]
setblock 78 136 346 minecraft:light[level=12]
setblock 78 136 353 minecraft:light[level=12]
setblock 78 136 360 minecraft:light[level=12]
fill 79 136 323 79 137 325 minecraft:iron_bars
setblock 79 136 363 minecraft:stripped_dark_oak_log
setblock 81 136 342 minecraft:red_concrete
setblock 82 136 323 minecraft:stripped_dark_oak_log
setblock 82 136 325 minecraft:light[level=15]
setblock 82 136 333 minecraft:light[level=15]
setblock 82 136 341 minecraft:light[level=15]
setblock 82 136 349 minecraft:light[level=15]
setblock 82 136 357 minecraft:light[level=15]
setblock 85 136 325 minecraft:light[level=12]
setblock 85 136 332 minecraft:light[level=12]
setblock 85 136 339 minecraft:light[level=12]
setblock 85 136 346 minecraft:light[level=12]
setblock 85 136 353 minecraft:light[level=12]
setblock 86 136 363 minecraft:stripped_dark_oak_log
setblock 88 136 324 minecraft:stripped_dark_oak_log
setblock 88 136 331 minecraft:stripped_dark_oak_log
setblock 88 136 338 minecraft:stripped_dark_oak_log
setblock 88 136 345 minecraft:stripped_dark_oak_log
setblock 88 136 352 minecraft:stripped_dark_oak_log
setblock 88 136 359 minecraft:stripped_dark_oak_log
fill 89 136 348 89 144 348 minecraft:dark_oak_planks
setblock 47 137 357 minecraft:red_concrete
fill 47 137 358 47 140 362 minecraft:dark_oak_planks
setblock 48 137 325 minecraft:stripped_dark_oak_log
setblock 48 137 332 minecraft:stripped_dark_oak_log
setblock 48 137 339 minecraft:stripped_dark_oak_log
fill 48 137 355 48 138 355 minecraft:stripped_dark_oak_log
fill 48 137 357 48 138 357 minecraft:stripped_dark_oak_log
fill 48 137 359 48 138 359 minecraft:stripped_dark_oak_log
fill 48 137 361 48 138 361 minecraft:stripped_dark_oak_log
fill 48 137 363 48 138 363 minecraft:stripped_dark_oak_log
fill 49 137 354 49 138 354 minecraft:stripped_dark_oak_log
fill 49 137 356 49 138 356 minecraft:stripped_dark_oak_log
fill 49 137 358 49 138 358 minecraft:stripped_dark_oak_log
fill 49 137 360 49 138 360 minecraft:stripped_dark_oak_log
fill 49 137 362 49 138 362 minecraft:stripped_dark_oak_log
fill 50 137 355 50 138 355 minecraft:stripped_dark_oak_log
fill 50 137 357 50 138 357 minecraft:stripped_dark_oak_log
fill 50 137 359 50 138 359 minecraft:stripped_dark_oak_log
fill 50 137 361 50 138 361 minecraft:stripped_dark_oak_log
fill 50 137 363 50 138 363 minecraft:stripped_dark_oak_log
fill 51 137 354 51 138 354 minecraft:stripped_dark_oak_log
fill 51 137 356 51 138 356 minecraft:stripped_dark_oak_log
fill 51 137 358 51 138 358 minecraft:stripped_dark_oak_log
fill 51 137 360 51 138 360 minecraft:stripped_dark_oak_log
fill 51 137 362 51 138 362 minecraft:stripped_dark_oak_log
fill 52 137 355 52 138 355 minecraft:stripped_dark_oak_log
fill 52 137 357 52 138 357 minecraft:stripped_dark_oak_log
fill 52 137 359 52 138 359 minecraft:stripped_dark_oak_log
fill 52 137 361 52 138 361 minecraft:stripped_dark_oak_log
fill 52 137 363 52 138 363 minecraft:stripped_dark_oak_log
setblock 53 137 323 minecraft:stripped_dark_oak_log
fill 53 137 354 53 138 354 minecraft:stripped_dark_oak_log
fill 53 137 356 53 138 356 minecraft:stripped_dark_oak_log
fill 53 137 358 53 138 358 minecraft:stripped_dark_oak_log
fill 53 137 360 53 138 360 minecraft:stripped_dark_oak_log
fill 53 137 362 53 138 362 minecraft:stripped_dark_oak_log
fill 54 137 355 54 138 355 minecraft:stripped_dark_oak_log
fill 54 137 357 54 138 357 minecraft:stripped_dark_oak_log
fill 54 137 359 54 138 359 minecraft:stripped_dark_oak_log
fill 54 137 361 54 138 361 minecraft:stripped_dark_oak_log
fill 54 137 363 54 138 363 minecraft:stripped_dark_oak_log
setblock 55 137 342 minecraft:red_concrete
fill 55 137 354 55 138 354 minecraft:stripped_dark_oak_log
fill 55 137 356 55 138 356 minecraft:stripped_dark_oak_log
fill 55 137 358 55 138 358 minecraft:stripped_dark_oak_log
fill 55 137 360 55 138 360 minecraft:stripped_dark_oak_log
fill 55 137 362 55 138 362 minecraft:stripped_dark_oak_log
fill 56 137 355 56 138 355 minecraft:stripped_dark_oak_log
fill 56 137 357 56 138 357 minecraft:stripped_dark_oak_log
fill 56 137 359 56 138 359 minecraft:stripped_dark_oak_log
fill 56 137 361 56 138 361 minecraft:stripped_dark_oak_log
fill 56 137 363 56 138 363 minecraft:stripped_dark_oak_log
fill 57 137 341 60 137 341 minecraft:stripped_dark_oak_log
fill 57 137 343 60 137 343 minecraft:stripped_dark_oak_log
fill 57 137 354 57 138 354 minecraft:stripped_dark_oak_log
fill 57 137 356 57 138 356 minecraft:stripped_dark_oak_log
fill 57 137 358 57 138 358 minecraft:stripped_dark_oak_log
fill 57 137 360 57 138 360 minecraft:stripped_dark_oak_log
fill 57 137 362 57 138 362 minecraft:stripped_dark_oak_log
fill 58 137 323 58 138 323 minecraft:stripped_dark_oak_log
fill 58 137 325 58 138 325 minecraft:stripped_dark_oak_log
fill 58 137 327 58 138 327 minecraft:stripped_dark_oak_log
fill 58 137 329 58 138 329 minecraft:stripped_dark_oak_log
fill 58 137 331 58 138 331 minecraft:stripped_dark_oak_log
fill 58 137 355 58 138 355 minecraft:stripped_dark_oak_log
fill 58 137 357 58 138 357 minecraft:stripped_dark_oak_log
fill 58 137 359 63 137 359 minecraft:stripped_dark_oak_log
fill 58 137 361 63 137 361 minecraft:stripped_dark_oak_log
fill 58 137 363 59 137 363 minecraft:stripped_dark_oak_log
fill 59 137 324 59 138 324 minecraft:stripped_dark_oak_log
fill 59 137 326 59 138 326 minecraft:stripped_dark_oak_log
fill 59 137 328 59 138 328 minecraft:stripped_dark_oak_log
fill 59 137 330 59 138 330 minecraft:stripped_dark_oak_log
fill 59 137 360 63 137 360 minecraft:stripped_dark_oak_log
fill 59 137 362 63 137 362 minecraft:stripped_dark_oak_log
fill 60 137 323 60 138 323 minecraft:stripped_dark_oak_log
fill 60 137 325 60 138 325 minecraft:stripped_dark_oak_log
fill 60 137 327 60 138 327 minecraft:stripped_dark_oak_log
fill 60 137 329 60 138 329 minecraft:stripped_dark_oak_log
fill 60 137 331 60 138 331 minecraft:stripped_dark_oak_log
fill 60 137 342 61 139 342 minecraft:stripped_dark_oak_log
fill 61 137 324 61 138 324 minecraft:stripped_dark_oak_log
fill 61 137 326 61 138 326 minecraft:stripped_dark_oak_log
fill 61 137 328 61 138 328 minecraft:stripped_dark_oak_log
fill 61 137 330 61 138 330 minecraft:stripped_dark_oak_log
fill 62 137 323 62 138 323 minecraft:stripped_dark_oak_log
fill 62 137 325 62 138 325 minecraft:stripped_dark_oak_log
fill 62 137 327 62 138 327 minecraft:stripped_dark_oak_log
fill 62 137 329 62 138 329 minecraft:stripped_dark_oak_log
fill 62 137 331 62 138 331 minecraft:stripped_dark_oak_log
fill 63 137 324 63 138 324 minecraft:stripped_dark_oak_log
fill 63 137 326 63 138 326 minecraft:stripped_dark_oak_log
fill 63 137 328 63 138 328 minecraft:stripped_dark_oak_log
fill 63 137 330 63 138 330 minecraft:stripped_dark_oak_log
fill 64 137 323 64 138 323 minecraft:stripped_dark_oak_log
fill 64 137 325 64 138 325 minecraft:stripped_dark_oak_log
fill 64 137 327 64 138 327 minecraft:stripped_dark_oak_log
fill 64 137 329 64 138 329 minecraft:stripped_dark_oak_log
fill 64 137 331 64 138 331 minecraft:stripped_dark_oak_log
fill 65 137 324 65 138 324 minecraft:stripped_dark_oak_log
fill 65 137 326 65 138 326 minecraft:stripped_dark_oak_log
fill 65 137 328 65 138 328 minecraft:stripped_dark_oak_log
fill 65 137 330 65 138 330 minecraft:stripped_dark_oak_log
fill 66 137 323 66 138 323 minecraft:stripped_dark_oak_log
fill 66 137 325 66 138 325 minecraft:stripped_dark_oak_log
fill 66 137 327 66 138 327 minecraft:stripped_dark_oak_log
fill 66 137 329 66 138 329 minecraft:stripped_dark_oak_log
fill 66 137 331 66 138 331 minecraft:stripped_dark_oak_log
setblock 66 137 363 minecraft:stripped_dark_oak_log
fill 67 137 324 67 138 324 minecraft:stripped_dark_oak_log
fill 67 137 326 67 138 326 minecraft:stripped_dark_oak_log
fill 67 137 328 67 138 328 minecraft:stripped_dark_oak_log
fill 67 137 330 67 138 330 minecraft:stripped_dark_oak_log
fill 68 137 323 68 138 323 minecraft:stripped_dark_oak_log
fill 68 137 325 68 138 325 minecraft:stripped_dark_oak_log
fill 68 137 327 68 138 327 minecraft:stripped_dark_oak_log
fill 68 137 329 68 138 329 minecraft:stripped_dark_oak_log
fill 68 137 331 68 138 331 minecraft:stripped_dark_oak_log
setblock 73 137 363 minecraft:stripped_dark_oak_log
setblock 74 137 323 minecraft:stripped_dark_oak_log
fill 74 137 342 75 139 342 minecraft:stripped_dark_oak_log
fill 75 137 341 78 137 341 minecraft:stripped_dark_oak_log
fill 75 137 343 78 137 343 minecraft:stripped_dark_oak_log
setblock 80 137 342 minecraft:red_concrete
setblock 80 137 363 minecraft:stripped_dark_oak_log
setblock 81 137 323 minecraft:stripped_dark_oak_log
setblock 87 137 363 minecraft:stripped_dark_oak_log
setblock 88 137 323 minecraft:stripped_dark_oak_log
setblock 88 137 330 minecraft:stripped_dark_oak_log
setblock 88 137 337 minecraft:stripped_dark_oak_log
setblock 88 137 344 minecraft:stripped_dark_oak_log
setblock 88 137 351 minecraft:stripped_dark_oak_log
setblock 88 137 358 minecraft:stripped_dark_oak_log
fill 47 138 357 47 144 357 minecraft:dark_oak_planks
setblock 48 138 326 minecraft:stripped_dark_oak_log
setblock 48 138 333 minecraft:stripped_dark_oak_log
setblock 48 138 340 minecraft:stripped_dark_oak_log
setblock 52 138 323 minecraft:stripped_dark_oak_log
fill 57 138 342 58 138 342 minecraft:red_concrete
setblock 58 138 359 minecraft:stripped_dark_oak_log
setblock 58 138 361 minecraft:stripped_dark_oak_log
fill 58 138 363 60 141 363 minecraft:shroomlight
fill 59 138 341 59 138 343 minecraft:stripped_dark_oak_log
fill 59 138 355 60 140 355 minecraft:cherry_leaves[persistent=true]
fill 59 138 359 63 138 359 minecraft:red_concrete
fill 60 138 341 62 138 341 minecraft:stripped_dark_oak_log
fill 60 138 343 62 138 343 minecraft:stripped_dark_oak_log
fill 60 138 354 62 140 354 minecraft:cherry_leaves[persistent=true]
fill 60 138 356 62 140 356 minecraft:cherry_leaves[persistent=true]
fill 61 138 353 61 140 353 minecraft:cherry_leaves[persistent=true]
fill 62 138 342 63 139 342 minecraft:stripped_dark_oak_log
fill 62 138 355 62 140 355 minecraft:cherry_leaves[persistent=true]
setblock 67 138 363 minecraft:stripped_dark_oak_log
fill 71 138 342 73 139 342 minecraft:stripped_dark_oak_log
setblock 73 138 323 minecraft:stripped_dark_oak_log
fill 73 138 341 76 138 341 minecraft:stripped_dark_oak_log
fill 73 138 343 76 138 343 minecraft:stripped_dark_oak_log
setblock 74 138 363 minecraft:stripped_dark_oak_log
setblock 78 138 342 minecraft:red_concrete
setblock 79 138 322 minecraft:red_concrete
setblock 80 138 323 minecraft:stripped_dark_oak_log
setblock 81 138 363 minecraft:stripped_dark_oak_log
setblock 87 138 323 minecraft:stripped_dark_oak_log
setblock 88 138 329 minecraft:stripped_dark_oak_log
setblock 88 138 336 minecraft:stripped_dark_oak_log
setblock 88 138 343 minecraft:stripped_dark_oak_log
setblock 88 138 350 minecraft:stripped_dark_oak_log
setblock 88 138 357 minecraft:stripped_dark_oak_log
setblock 88 138 363 minecraft:stripped_dark_oak_log
setblock 89 138 326 minecraft:red_concrete
fill 48 139 327 48 140 327 minecraft:stripped_dark_oak_log
fill 48 139 334 48 140 334 minecraft:stripped_dark_oak_log
fill 48 139 341 48 140 341 minecraft:stripped_dark_oak_log
setblock 48 139 355 minecraft:shroomlight
setblock 48 139 357 minecraft:shroomlight
setblock 48 139 359 minecraft:shroomlight
setblock 48 139 361 minecraft:shroomlight
setblock 48 139 363 minecraft:shroomlight
setblock 49 139 354 minecraft:shroomlight
setblock 49 139 356 minecraft:shroomlight
setblock 49 139 358 minecraft:shroomlight
setblock 49 139 360 minecraft:shroomlight
setblock 49 139 362 minecraft:shroomlight
setblock 50 139 355 minecraft:shroomlight
setblock 50 139 357 minecraft:shroomlight
setblock 50 139 359 minecraft:shroomlight
setblock 50 139 361 minecraft:shroomlight
setblock 50 139 363 minecraft:shroomlight
fill 51 139 323 51 140 323 minecraft:stripped_dark_oak_log
setblock 51 139 354 minecraft:shroomlight
setblock 51 139 356 minecraft:shroomlight
setblock 51 139 358 minecraft:shroomlight
setblock 51 139 360 minecraft:shroomlight
setblock 51 139 362 minecraft:shroomlight
setblock 52 139 355 minecraft:shroomlight
setblock 52 139 357 minecraft:shroomlight
setblock 52 139 359 minecraft:shroomlight
setblock 52 139 361 minecraft:shroomlight
setblock 52 139 363 minecraft:shroomlight
setblock 53 139 354 minecraft:shroomlight
setblock 53 139 356 minecraft:shroomlight
setblock 53 139 358 minecraft:shroomlight
setblock 53 139 360 minecraft:shroomlight
setblock 53 139 362 minecraft:shroomlight
setblock 54 139 355 minecraft:shroomlight
setblock 54 139 357 minecraft:shroomlight
setblock 54 139 359 minecraft:shroomlight
setblock 54 139 361 minecraft:shroomlight
setblock 54 139 363 minecraft:shroomlight
setblock 55 139 354 minecraft:shroomlight
setblock 55 139 356 minecraft:shroomlight
setblock 55 139 358 minecraft:shroomlight
setblock 55 139 360 minecraft:shroomlight
setblock 55 139 362 minecraft:shroomlight
setblock 56 139 355 minecraft:shroomlight
setblock 56 139 357 minecraft:shroomlight
setblock 56 139 359 minecraft:shroomlight
setblock 56 139 361 minecraft:shroomlight
setblock 56 139 363 minecraft:shroomlight
setblock 57 139 354 minecraft:shroomlight
setblock 57 139 356 minecraft:shroomlight
setblock 57 139 358 minecraft:shroomlight
setblock 57 139 360 minecraft:shroomlight
setblock 57 139 362 minecraft:shroomlight
setblock 58 139 323 minecraft:shroomlight
setblock 58 139 325 minecraft:shroomlight
setblock 58 139 327 minecraft:shroomlight
setblock 58 139 329 minecraft:shroomlight
setblock 58 139 331 minecraft:shroomlight
fill 58 139 342 59 139 342 minecraft:red_concrete
setblock 58 139 355 minecraft:shroomlight
setblock 58 139 357 minecraft:shroomlight
setblock 58 139 359 minecraft:shroomlight
setblock 58 139 361 minecraft:shroomlight
setblock 59 139 324 minecraft:shroomlight
setblock 59 139 326 minecraft:shroomlight
setblock 59 139 328 minecraft:shroomlight
setblock 59 139 330 minecraft:shroomlight
setblock 59 139 354 minecraft:cherry_leaves[persistent=true]
setblock 59 139 356 minecraft:cherry_leaves[persistent=true]
setblock 59 139 359 minecraft:stripped_dark_oak_log
setblock 60 139 323 minecraft:shroomlight
setblock 60 139 325 minecraft:shroomlight
setblock 60 139 327 minecraft:shroomlight
setblock 60 139 329 minecraft:shroomlight
setblock 60 139 331 minecraft:shroomlight
setblock 60 139 353 minecraft:cherry_leaves[persistent=true]
fill 60 139 357 62 139 357 minecraft:cherry_leaves[persistent=true]
setblock 61 139 324 minecraft:shroomlight
setblock 61 139 326 minecraft:shroomlight
setblock 61 139 328 minecraft:shroomlight
setblock 61 139 330 minecraft:shroomlight
fill 61 139 341 63 139 341 minecraft:stripped_dark_oak_log
fill 61 139 343 63 139 343 minecraft:stripped_dark_oak_log
fill 61 139 355 61 140 355 minecraft:cherry_leaves[persistent=true]
fill 61 139 363 61 140 363 minecraft:stripped_dark_oak_log
setblock 62 139 323 minecraft:shroomlight
setblock 62 139 325 minecraft:shroomlight
setblock 62 139 327 minecraft:shroomlight
setblock 62 139 329 minecraft:shroomlight
setblock 62 139 331 minecraft:shroomlight
setblock 62 139 353 minecraft:cherry_leaves[persistent=true]
setblock 63 139 324 minecraft:shroomlight
setblock 63 139 326 minecraft:shroomlight
setblock 63 139 328 minecraft:shroomlight
setblock 63 139 330 minecraft:shroomlight
fill 63 139 354 63 139 356 minecraft:cherry_leaves[persistent=true]
setblock 63 139 359 minecraft:stripped_dark_oak_log
setblock 64 139 323 minecraft:shroomlight
setblock 64 139 325 minecraft:shroomlight
setblock 64 139 327 minecraft:shroomlight
setblock 64 139 329 minecraft:shroomlight
setblock 64 139 331 minecraft:shroomlight
setblock 65 139 324 minecraft:shroomlight
setblock 65 139 326 minecraft:shroomlight
setblock 65 139 328 minecraft:shroomlight
setblock 65 139 330 minecraft:shroomlight
setblock 66 139 323 minecraft:shroomlight
setblock 66 139 325 minecraft:shroomlight
setblock 66 139 327 minecraft:shroomlight
setblock 66 139 329 minecraft:shroomlight
setblock 66 139 331 minecraft:shroomlight
setblock 67 139 324 minecraft:shroomlight
setblock 67 139 326 minecraft:shroomlight
setblock 67 139 328 minecraft:shroomlight
setblock 67 139 330 minecraft:shroomlight
setblock 68 139 323 minecraft:shroomlight
setblock 68 139 325 minecraft:shroomlight
setblock 68 139 327 minecraft:shroomlight
setblock 68 139 329 minecraft:shroomlight
setblock 68 139 331 minecraft:shroomlight
fill 68 139 363 68 140 363 minecraft:stripped_dark_oak_log
fill 71 139 341 74 139 341 minecraft:stripped_dark_oak_log
fill 71 139 343 74 139 343 minecraft:stripped_dark_oak_log
fill 72 139 323 72 140 323 minecraft:stripped_dark_oak_log
fill 75 139 363 75 140 363 minecraft:stripped_dark_oak_log
fill 76 139 342 77 139 342 minecraft:red_concrete
fill 79 139 322 79 144 322 minecraft:dark_oak_planks
fill 79 139 323 79 140 323 minecraft:stripped_dark_oak_log
fill 82 139 363 82 140 363 minecraft:stripped_dark_oak_log
setblock 83 139 364 minecraft:red_concrete
fill 86 139 323 86 140 323 minecraft:stripped_dark_oak_log
fill 88 139 328 88 140 328 minecraft:stripped_dark_oak_log
fill 88 139 335 88 140 335 minecraft:stripped_dark_oak_log
fill 88 139 342 88 140 342 minecraft:stripped_dark_oak_log
fill 88 139 349 88 140 349 minecraft:stripped_dark_oak_log
fill 88 139 356 88 140 356 minecraft:stripped_dark_oak_log
fill 89 139 326 89 144 326 minecraft:dark_oak_planks
setblock 89 139 332 minecraft:red_concrete
fill 47 140 347 47 144 349 minecraft:dark_oak_planks
fill 48 140 323 48 140 326 minecraft:stripped_dark_oak_log
fill 48 140 329 48 140 333 minecraft:stripped_dark_oak_log
fill 48 140 336 48 140 340 minecraft:stripped_dark_oak_log
fill 48 140 355 48 142 355 minecraft:stripped_dark_oak_log
fill 48 140 357 48 142 357 minecraft:stripped_dark_oak_log
fill 48 140 359 48 142 359 minecraft:stripped_dark_oak_log
fill 48 140 361 48 142 361 minecraft:stripped_dark_oak_log
fill 48 140 363 48 142 363 minecraft:stripped_dark_oak_log
fill 49 140 323 49 141 323 minecraft:stripped_dark_oak_log
fill 49 140 354 49 142 354 minecraft:stripped_dark_oak_log
fill 49 140 356 49 142 356 minecraft:stripped_dark_oak_log
fill 49 140 358 49 142 358 minecraft:stripped_dark_oak_log
fill 49 140 360 49 142 360 minecraft:stripped_dark_oak_log
fill 49 140 362 49 142 362 minecraft:stripped_dark_oak_log
fill 50 140 355 50 142 355 minecraft:stripped_dark_oak_log
fill 50 140 357 50 142 357 minecraft:stripped_dark_oak_log
fill 50 140 359 50 142 359 minecraft:stripped_dark_oak_log
fill 50 140 361 50 142 361 minecraft:stripped_dark_oak_log
fill 50 140 363 50 142 363 minecraft:stripped_dark_oak_log
fill 51 140 354 51 142 354 minecraft:stripped_dark_oak_log
fill 51 140 356 51 142 356 minecraft:stripped_dark_oak_log
fill 51 140 358 51 142 358 minecraft:stripped_dark_oak_log
fill 51 140 360 51 142 360 minecraft:stripped_dark_oak_log
fill 51 140 362 51 142 362 minecraft:stripped_dark_oak_log
fill 52 140 323 56 140 323 minecraft:stripped_dark_oak_log
fill 52 140 355 52 142 355 minecraft:stripped_dark_oak_log
fill 52 140 357 52 142 357 minecraft:stripped_dark_oak_log
fill 52 140 359 52 142 359 minecraft:stripped_dark_oak_log
fill 52 140 361 52 142 361 minecraft:stripped_dark_oak_log
fill 52 140 363 52 142 363 minecraft:stripped_dark_oak_log
fill 53 140 354 53 142 354 minecraft:stripped_dark_oak_log
fill 53 140 356 53 142 356 minecraft:stripped_dark_oak_log
fill 53 140 358 53 142 358 minecraft:stripped_dark_oak_log
fill 53 140 360 53 142 360 minecraft:stripped_dark_oak_log
fill 53 140 362 53 142 362 minecraft:stripped_dark_oak_log
fill 54 140 355 54 142 355 minecraft:stripped_dark_oak_log
fill 54 140 357 54 142 357 minecraft:stripped_dark_oak_log
fill 54 140 359 54 142 359 minecraft:stripped_dark_oak_log
fill 54 140 361 54 142 361 minecraft:stripped_dark_oak_log
fill 54 140 363 54 142 363 minecraft:stripped_dark_oak_log
fill 55 140 354 55 142 354 minecraft:stripped_dark_oak_log
fill 55 140 356 55 142 356 minecraft:stripped_dark_oak_log
fill 55 140 358 55 142 358 minecraft:stripped_dark_oak_log
fill 55 140 360 55 142 360 minecraft:stripped_dark_oak_log
fill 55 140 362 55 142 362 minecraft:stripped_dark_oak_log
fill 56 140 355 56 142 355 minecraft:stripped_dark_oak_log
fill 56 140 357 56 142 357 minecraft:stripped_dark_oak_log
fill 56 140 359 56 142 359 minecraft:stripped_dark_oak_log
fill 56 140 361 56 142 361 minecraft:stripped_dark_oak_log
fill 56 140 363 56 142 363 minecraft:stripped_dark_oak_log
fill 57 140 354 57 142 354 minecraft:stripped_dark_oak_log
fill 57 140 356 57 142 356 minecraft:stripped_dark_oak_log
fill 57 140 358 57 142 358 minecraft:stripped_dark_oak_log
fill 57 140 360 57 142 360 minecraft:stripped_dark_oak_log
fill 57 140 362 57 142 362 minecraft:stripped_dark_oak_log
fill 58 140 323 58 142 323 minecraft:stripped_dark_oak_log
fill 58 140 325 58 142 325 minecraft:stripped_dark_oak_log
fill 58 140 327 58 142 327 minecraft:stripped_dark_oak_log
fill 58 140 329 58 142 329 minecraft:stripped_dark_oak_log
fill 58 140 331 58 142 331 minecraft:stripped_dark_oak_log
fill 58 140 355 58 142 355 minecraft:stripped_dark_oak_log
fill 58 140 357 58 142 357 minecraft:stripped_dark_oak_log
fill 58 140 359 58 142 359 minecraft:stripped_dark_oak_log
fill 58 140 361 58 142 361 minecraft:stripped_dark_oak_log
fill 59 140 324 59 142 324 minecraft:stripped_dark_oak_log
fill 59 140 326 59 142 326 minecraft:stripped_dark_oak_log
fill 59 140 328 59 142 328 minecraft:stripped_dark_oak_log
fill 59 140 330 59 142 330 minecraft:stripped_dark_oak_log
fill 60 140 323 60 142 323 minecraft:stripped_dark_oak_log
fill 60 140 325 60 142 325 minecraft:stripped_dark_oak_log
fill 60 140 327 60 142 327 minecraft:stripped_dark_oak_log
fill 60 140 329 60 142 329 minecraft:stripped_dark_oak_log
fill 60 140 331 60 142 331 minecraft:stripped_dark_oak_log
fill 60 140 342 62 140 342 minecraft:red_concrete
fill 61 140 324 61 142 324 minecraft:stripped_dark_oak_log
fill 61 140 326 61 142 326 minecraft:stripped_dark_oak_log
fill 61 140 328 61 142 328 minecraft:stripped_dark_oak_log
fill 61 140 330 61 142 330 minecraft:stripped_dark_oak_log
fill 62 140 323 62 142 323 minecraft:stripped_dark_oak_log
fill 62 140 325 62 142 325 minecraft:stripped_dark_oak_log
fill 62 140 327 62 142 327 minecraft:stripped_dark_oak_log
fill 62 140 329 62 142 329 minecraft:stripped_dark_oak_log
fill 62 140 331 62 142 331 minecraft:stripped_dark_oak_log
setblock 63 140 322 minecraft:red_concrete
fill 63 140 324 63 142 324 minecraft:stripped_dark_oak_log
fill 63 140 326 63 142 326 minecraft:stripped_dark_oak_log
fill 63 140 328 63 142 328 minecraft:stripped_dark_oak_log
fill 63 140 330 63 142 330 minecraft:stripped_dark_oak_log
setblock 63 140 342 minecraft:stripped_dark_oak_log
fill 63 140 363 67 140 363 minecraft:stripped_dark_oak_log
fill 64 140 323 64 142 323 minecraft:stripped_dark_oak_log
fill 64 140 325 64 142 325 minecraft:stripped_dark_oak_log
fill 64 140 327 64 142 327 minecraft:stripped_dark_oak_log
fill 64 140 329 64 142 329 minecraft:stripped_dark_oak_log
fill 64 140 331 64 142 331 minecraft:stripped_dark_oak_log
fill 65 140 324 65 142 324 minecraft:stripped_dark_oak_log
fill 65 140 326 65 142 326 minecraft:stripped_dark_oak_log
fill 65 140 328 65 142 328 minecraft:stripped_dark_oak_log
fill 65 140 330 65 142 330 minecraft:stripped_dark_oak_log
fill 66 140 323 66 142 323 minecraft:stripped_dark_oak_log
fill 66 140 325 66 142 325 minecraft:stripped_dark_oak_log
fill 66 140 327 66 142 327 minecraft:stripped_dark_oak_log
fill 66 140 329 66 142 329 minecraft:stripped_dark_oak_log
fill 66 140 331 66 142 331 minecraft:stripped_dark_oak_log
fill 67 140 324 67 142 324 minecraft:stripped_dark_oak_log
fill 67 140 326 67 142 326 minecraft:stripped_dark_oak_log
fill 67 140 328 67 142 328 minecraft:stripped_dark_oak_log
fill 67 140 330 67 142 330 minecraft:stripped_dark_oak_log
fill 68 140 323 70 140 323 minecraft:stripped_dark_oak_log
fill 68 140 325 68 142 325 minecraft:stripped_dark_oak_log
fill 68 140 327 68 142 327 minecraft:stripped_dark_oak_log
fill 68 140 329 68 142 329 minecraft:stripped_dark_oak_log
fill 68 140 331 68 142 331 minecraft:stripped_dark_oak_log
fill 70 140 363 74 140 363 minecraft:stripped_dark_oak_log
fill 71 140 342 72 140 342 minecraft:stripped_dark_oak_log
fill 73 140 323 77 140 323 minecraft:stripped_dark_oak_log
fill 73 140 342 75 140 342 minecraft:red_concrete
fill 77 140 363 81 140 363 minecraft:stripped_dark_oak_log
fill 80 140 323 84 140 323 minecraft:stripped_dark_oak_log
fill 82 140 357 82 140 358 minecraft:dark_oak_planks
setblock 82 140 360 minecraft:dark_oak_planks
fill 83 140 357 85 140 357 minecraft:dark_oak_planks
fill 83 140 361 85 140 361 minecraft:dark_oak_planks
fill 83 140 364 83 142 364 minecraft:dark_oak_planks
fill 84 140 363 88 140 363 minecraft:stripped_dark_oak_log
fill 86 140 358 86 140 360 minecraft:dark_oak_planks
fill 87 140 323 88 140 323 minecraft:stripped_dark_oak_log
fill 88 140 324 88 140 326 minecraft:stripped_dark_oak_log
fill 88 140 329 88 140 333 minecraft:stripped_dark_oak_log
fill 88 140 336 88 140 340 minecraft:stripped_dark_oak_log
fill 88 140 343 88 140 347 minecraft:stripped_dark_oak_log
fill 88 140 350 88 140 354 minecraft:stripped_dark_oak_log
fill 88 140 357 88 140 361 minecraft:stripped_dark_oak_log
setblock 89 140 332 minecraft:dark_oak_planks
fill 47 141 328 47 144 329 minecraft:dark_oak_planks
setblock 47 141 330 minecraft:spruce_planks
fill 47 141 331 47 142 336 minecraft:dark_oak_planks
setblock 47 141 337 minecraft:spruce_planks
fill 47 141 341 47 144 343 minecraft:dark_oak_planks
setblock 47 141 344 minecraft:spruce_planks
setblock 47 141 354 minecraft:spruce_planks
setblock 47 141 356 minecraft:spruce_planks
fill 47 141 358 47 142 358 minecraft:spruce_planks
fill 47 141 359 47 141 362 minecraft:dark_oak_planks
setblock 48 141 329 minecraft:stripped_dark_oak_log
setblock 48 141 336 minecraft:stripped_dark_oak_log
setblock 56 141 323 minecraft:stripped_dark_oak_log
setblock 59 141 322 minecraft:spruce_planks
setblock 59 141 364 minecraft:spruce_planks
setblock 60 141 322 minecraft:red_concrete
fill 60 141 364 61 144 364 minecraft:dark_oak_planks
fill 62 141 364 62 142 364 minecraft:spruce_planks
fill 63 141 322 63 144 322 minecraft:dark_oak_planks
setblock 63 141 342 minecraft:red_concrete
setblock 63 141 363 minecraft:stripped_dark_oak_log
fill 68 141 323 68 142 323 minecraft:stripped_dark_oak_log
setblock 70 141 323 minecraft:stripped_dark_oak_log
setblock 70 141 363 minecraft:stripped_dark_oak_log
fill 71 141 342 72 141 342 minecraft:red_concrete
setblock 72 141 364 minecraft:spruce_planks
setblock 77 141 323 minecraft:stripped_dark_oak_log
setblock 77 141 363 minecraft:stripped_dark_oak_log
setblock 78 141 364 minecraft:spruce_planks
fill 82 141 358 82 142 358 minecraft:red_concrete
fill 82 141 360 82 142 360 minecraft:red_concrete
fill 83 141 357 85 142 357 minecraft:red_concrete
fill 83 141 361 84 142 361 minecraft:red_concrete
setblock 84 141 323 minecraft:stripped_dark_oak_log
setblock 84 141 363 minecraft:stripped_dark_oak_log
fill 86 141 358 86 142 359 minecraft:red_concrete
setblock 88 141 326 minecraft:stripped_dark_oak_log
setblock 88 141 333 minecraft:stripped_dark_oak_log
setblock 88 141 340 minecraft:stripped_dark_oak_log
setblock 88 141 347 minecraft:stripped_dark_oak_log
setblock 88 141 354 minecraft:stripped_dark_oak_log
setblock 88 141 361 minecraft:stripped_dark_oak_log
setblock 88 141 364 minecraft:spruce_planks
setblock 89 141 323 minecraft:spruce_planks
fill 89 141 324 89 144 325 minecraft:dark_oak_planks
setblock 89 141 332 minecraft:spruce_planks
fill 89 141 353 89 141 354 minecraft:spruce_planks
fill 89 141 356 89 141 359 minecraft:dark_oak_planks
setblock 89 141 360 minecraft:spruce_planks
fill 89 141 361 89 142 363 minecraft:dark_oak_planks
setblock 47 142 322 minecraft:spruce_planks
fill 47 142 323 47 144 326 minecraft:dark_oak_planks
setblock 47 142 327 minecraft:spruce_planks
fill 47 142 330 47 144 330 minecraft:dark_oak_planks
fill 47 142 337 47 144 337 minecraft:dark_oak_planks
setblock 47 142 340 minecraft:red_concrete
fill 47 142 344 47 144 344 minecraft:dark_oak_planks
setblock 47 142 346 minecraft:spruce_planks
fill 47 142 354 47 144 354 minecraft:dark_oak_planks
fill 47 142 356 47 144 356 minecraft:dark_oak_planks
setblock 47 142 359 minecraft:spruce_planks
fill 47 142 360 47 144 362 minecraft:dark_oak_planks
setblock 47 142 363 minecraft:spruce_planks
setblock 48 142 323 minecraft:stripped_dark_oak_log
setblock 48 142 330 minecraft:stripped_dark_oak_log
setblock 48 142 337 minecraft:stripped_dark_oak_log
setblock 48 142 364 minecraft:spruce_planks
fill 49 142 364 51 144 364 minecraft:dark_oak_planks
setblock 50 142 325 minecraft:light[level=12]
setblock 50 142 332 minecraft:light[level=12]
setblock 50 142 339 minecraft:light[level=12]
setblock 55 142 323 minecraft:stripped_dark_oak_log
setblock 56 142 364 minecraft:spruce_planks
setblock 57 142 322 minecraft:spruce_planks
setblock 57 142 325 minecraft:light[level=12]
setblock 57 142 332 minecraft:light[level=12]
setblock 57 142 339 minecraft:light[level=12]
setblock 57 142 346 minecraft:light[level=12]
setblock 57 142 353 minecraft:light[level=12]
fill 57 142 364 59 144 364 minecraft:dark_oak_planks
setblock 58 142 363 minecraft:stripped_dark_oak_log
fill 59 142 322 59 143 322 minecraft:dark_oak_planks
setblock 60 142 322 minecraft:spruce_planks
fill 64 142 322 64 144 322 minecraft:dark_oak_planks
setblock 64 142 332 minecraft:light[level=12]
setblock 64 142 339 minecraft:light[level=12]
setblock 64 142 346 minecraft:light[level=12]
setblock 64 142 353 minecraft:light[level=12]
setblock 64 142 360 minecraft:light[level=12]
setblock 64 142 363 minecraft:stripped_dark_oak_log
setblock 65 142 322 minecraft:spruce_planks
fill 66 142 322 66 144 322 minecraft:dark_oak_planks
fill 66 142 364 68 144 364 minecraft:dark_oak_planks
setblock 67 142 322 minecraft:spruce_planks
fill 68 142 322 68 144 322 minecraft:dark_oak_planks
setblock 69 142 323 minecraft:stripped_dark_oak_log
setblock 69 142 364 minecraft:spruce_planks
fill 70 142 364 72 142 364 minecraft:dark_oak_planks
fill 71 142 322 72 142 322 minecraft:spruce_planks
setblock 71 142 325 minecraft:light[level=12]
setblock 71 142 332 minecraft:light[level=12]
setblock 71 142 339 minecraft:light[level=12]
setblock 71 142 346 minecraft:light[level=12]
setblock 71 142 353 minecraft:light[level=12]
setblock 71 142 360 minecraft:light[level=12]
setblock 71 142 363 minecraft:stripped_dark_oak_log
fill 74 142 322 75 144 322 minecraft:dark_oak_planks
setblock 75 142 364 minecraft:spruce_planks
fill 76 142 322 77 142 322 minecraft:spruce_planks
setblock 76 142 323 minecraft:stripped_dark_oak_log
fill 76 142 364 78 144 364 minecraft:dark_oak_planks
setblock 78 142 325 minecraft:light[level=12]
setblock 78 142 332 minecraft:light[level=12]
setblock 78 142 339 minecraft:light[level=12]
setblock 78 142 346 minecraft:light[level=12]
setblock 78 142 353 minecraft:light[level=12]
setblock 78 142 360 minecraft:light[level=12]
setblock 78 142 363 minecraft:stripped_dark_oak_log
setblock 81 142 364 minecraft:spruce_planks
setblock 83 142 323 minecraft:stripped_dark_oak_log
setblock 85 142 325 minecraft:light[level=12]
setblock 85 142 332 minecraft:light[level=12]
setblock 85 142 339 minecraft:light[level=12]
setblock 85 142 346 minecraft:light[level=12]
setblock 85 142 353 minecraft:light[level=12]
setblock 85 142 363 minecraft:stripped_dark_oak_log
setblock 88 142 325 minecraft:stripped_dark_oak_log
setblock 88 142 332 minecraft:stripped_dark_oak_log
setblock 88 142 339 minecraft:stripped_dark_oak_log
setblock 88 142 346 minecraft:stripped_dark_oak_log
setblock 88 142 353 minecraft:stripped_dark_oak_log
setblock 88 142 360 minecraft:stripped_dark_oak_log
fill 88 142 364 88 146 364 minecraft:dark_oak_planks
fill 89 142 323 89 144 323 minecraft:dark_oak_planks
fill 89 142 332 89 144 332 minecraft:dark_oak_planks
fill 89 142 337 89 143 337 minecraft:spruce_planks
fill 89 142 340 89 144 340 minecraft:dark_oak_planks
setblock 89 142 341 minecraft:spruce_planks
fill 89 142 342 89 144 342 minecraft:dark_oak_planks
fill 89 142 353 89 142 354 minecraft:dark_oak_planks
fill 89 142 356 89 144 357 minecraft:dark_oak_planks
setblock 89 142 358 minecraft:spruce_planks
fill 89 142 359 89 144 360 minecraft:dark_oak_planks
fill 89 142 364 89 143 364 minecraft:spruce_planks
fill 47 143 322 52 144 322 minecraft:dark_oak_planks
fill 47 143 327 47 144 327 minecraft:dark_oak_planks
fill 47 143 331 47 144 332 minecraft:dark_oak_planks
setblock 47 143 333 minecraft:red_concrete
fill 47 143 334 47 144 336 minecraft:dark_oak_planks
setblock 47 143 339 minecraft:spruce_planks
fill 47 143 340 47 144 340 minecraft:dark_oak_planks
fill 47 143 346 47 144 346 minecraft:dark_oak_planks
fill 47 143 358 47 144 359 minecraft:dark_oak_planks
fill 47 143 363 47 144 363 minecraft:dark_oak_planks
setblock 47 143 364 minecraft:spruce_planks
fill 48 143 364 48 144 364 minecraft:dark_oak_planks
setblock 52 143 364 minecraft:spruce_planks
setblock 53 143 322 minecraft:spruce_planks
fill 54 143 322 57 144 322 minecraft:dark_oak_planks
fill 56 143 364 56 144 364 minecraft:dark_oak_planks
fill 60 143 322 60 144 322 minecraft:dark_oak_planks
fill 62 143 364 62 145 364 minecraft:dark_oak_planks
fill 65 143 322 65 144 322 minecraft:dark_oak_planks
fill 67 143 322 67 144 322 minecraft:dark_oak_planks
fill 69 143 364 71 144 364 minecraft:dark_oak_planks
fill 71 143 322 72 144 322 minecraft:dark_oak_planks
setblock 72 143 364 minecraft:spruce_planks
fill 75 143 364 75 144 364 minecraft:dark_oak_planks
fill 76 143 322 76 144 322 minecraft:dark_oak_planks
setblock 77 143 322 minecraft:spruce_planks
setblock 79 143 364 minecraft:spruce_planks
fill 81 143 364 81 144 364 minecraft:dark_oak_planks
setblock 83 143 364 minecraft:spruce_planks
fill 89 143 333 89 144 334 minecraft:dark_oak_planks
setblock 89 143 335 minecraft:spruce_planks
fill 89 143 336 89 144 336 minecraft:dark_oak_planks
fill 89 143 341 89 144 341 minecraft:dark_oak_planks
fill 89 143 353 89 144 353 minecraft:dark_oak_planks
setblock 89 143 354 minecraft:spruce_planks
fill 89 143 358 89 144 358 minecraft:dark_oak_planks
fill 89 143 361 89 144 362 minecraft:dark_oak_planks
setblock 89 143 363 minecraft:spruce_planks
setblock 47 144 333 minecraft:dark_oak_planks
fill 47 144 339 47 145 339 minecraft:dark_oak_planks
setblock 47 144 364 minecraft:dark_oak_planks
setblock 50 144 325 minecraft:light[level=15]
setblock 50 144 333 minecraft:light[level=15]
setblock 50 144 341 minecraft:light[level=15]
setblock 50 144 349 minecraft:light[level=15]
setblock 50 144 357 minecraft:light[level=15]
setblock 52 144 364 minecraft:dark_oak_planks
setblock 53 144 322 minecraft:dark_oak_planks
setblock 58 144 325 minecraft:light[level=15]
setblock 58 144 333 minecraft:light[level=15]
setblock 58 144 341 minecraft:light[level=15]
setblock 58 144 349 minecraft:light[level=15]
setblock 58 144 357 minecraft:light[level=15]
setblock 59 144 322 minecraft:red_concrete
setblock 66 144 325 minecraft:light[level=15]
setblock 66 144 333 minecraft:light[level=15]
setblock 66 144 341 minecraft:light[level=15]
setblock 66 144 349 minecraft:light[level=15]
setblock 66 144 357 minecraft:light[level=15]
setblock 72 144 364 minecraft:dark_oak_planks
setblock 74 144 325 minecraft:light[level=15]
setblock 74 144 333 minecraft:light[level=15]
setblock 74 144 341 minecraft:light[level=15]
setblock 74 144 349 minecraft:light[level=15]
setblock 74 144 357 minecraft:light[level=15]
setblock 77 144 322 minecraft:dark_oak_planks
setblock 79 144 364 minecraft:dark_oak_planks
setblock 82 144 325 minecraft:light[level=15]
setblock 82 144 333 minecraft:light[level=15]
setblock 82 144 341 minecraft:light[level=15]
setblock 82 144 349 minecraft:light[level=15]
setblock 82 144 357 minecraft:light[level=15]
setblock 83 144 364 minecraft:dark_oak_planks
setblock 89 144 335 minecraft:dark_oak_planks
fill 89 144 337 89 145 337 minecraft:dark_oak_planks
setblock 89 144 354 minecraft:dark_oak_planks
fill 89 144 363 89 144 364 minecraft:dark_oak_planks
fill 47 145 322 47 145 338 minecraft:spruce_planks
fill 47 145 340 47 145 346 minecraft:spruce_planks
setblock 47 145 347 minecraft:dark_oak_planks
fill 47 145 348 47 226 349 minecraft:spruce_planks
fill 47 145 351 47 145 357 minecraft:spruce_planks
setblock 47 145 358 minecraft:dark_oak_planks
fill 47 145 359 47 172 361 minecraft:spruce_planks
setblock 47 145 362 minecraft:dark_oak_planks
fill 47 145 363 47 168 364 minecraft:spruce_planks
fill 48 145 322 82 145 322 minecraft:spruce_planks
setblock 48 145 364 minecraft:red_concrete
fill 49 145 364 57 167 364 minecraft:spruce_planks
setblock 58 145 364 minecraft:dark_oak_planks
fill 59 145 364 61 223 364 minecraft:spruce_planks
fill 63 145 364 73 145 364 minecraft:spruce_planks
fill 75 145 364 76 163 364 minecraft:spruce_planks
setblock 77 145 364 minecraft:dark_oak_planks
fill 78 145 364 84 190 364 minecraft:spruce_planks
setblock 83 145 322 minecraft:dark_oak_planks
setblock 84 145 322 minecraft:spruce_planks
setblock 85 145 322 minecraft:dark_oak_planks
fill 86 145 322 89 146 322 minecraft:spruce_planks
fill 86 145 364 86 226 364 minecraft:spruce_planks
setblock 87 145 364 minecraft:dark_oak_planks
fill 89 145 323 89 145 336 minecraft:spruce_planks
fill 89 145 338 89 146 343 minecraft:spruce_planks
fill 89 145 345 89 145 351 minecraft:spruce_planks
fill 89 145 352 89 146 352 minecraft:dark_oak_planks
fill 89 145 353 89 145 359 minecraft:spruce_planks
setblock 89 145 360 minecraft:red_concrete
fill 89 145 361 89 145 364 minecraft:spruce_planks
fill 47 146 322 47 146 333 minecraft:spruce_planks
fill 47 146 334 47 146 335 minecraft:dark_oak_planks
fill 47 146 336 47 223 339 minecraft:spruce_planks
setblock 47 146 340 minecraft:dark_oak_planks
fill 47 146 341 47 191 341 minecraft:spruce_planks
fill 47 146 342 47 146 344 minecraft:dark_oak_planks
fill 47 146 345 47 146 347 minecraft:spruce_planks
fill 47 146 350 47 151 354 minecraft:spruce_planks
setblock 47 146 355 minecraft:dark_oak_planks
fill 47 146 356 47 226 356 minecraft:spruce_planks
fill 47 146 357 47 147 357 minecraft:dark_oak_planks
fill 47 146 358 47 152 358 minecraft:spruce_planks
setblock 47 146 362 minecraft:spruce_planks
fill 48 146 322 68 146 322 minecraft:spruce_planks
fill 48 146 364 48 226 364 minecraft:spruce_planks
fill 58 146 364 58 226 364 minecraft:spruce_planks
fill 62 146 364 62 226 364 minecraft:spruce_planks
setblock 63 146 364 minecraft:dark_oak_planks
fill 64 146 364 66 222 364 minecraft:spruce_planks
setblock 67 146 364 minecraft:dark_oak_planks
fill 68 146 364 74 175 364 minecraft:spruce_planks
fill 69 146 322 69 147 322 minecraft:dark_oak_planks
fill 70 146 322 77 223 322 minecraft:spruce_planks
fill 77 146 364 77 226 364 minecraft:spruce_planks
setblock 78 146 322 minecraft:red_concrete
fill 79 146 322 83 156 322 minecraft:spruce_planks
setblock 84 146 322 minecraft:dark_oak_planks
setblock 85 146 322 minecraft:spruce_planks
fill 85 146 364 85 222 364 minecraft:spruce_planks
fill 87 146 364 87 225 364 minecraft:spruce_planks
fill 89 146 323 89 146 334 minecraft:spruce_planks
setblock 89 146 335 minecraft:dark_oak_planks
fill 89 146 336 89 188 337 minecraft:spruce_planks
fill 89 146 344 89 146 347 minecraft:spruce_planks
setblock 89 146 348 minecraft:dark_oak_planks
fill 89 146 349 89 223 349 minecraft:spruce_planks
setblock 89 146 350 minecraft:dark_oak_planks
fill 89 146 351 89 226 351 minecraft:spruce_planks
fill 89 146 353 89 146 354 minecraft:dark_oak_planks
fill 89 146 355 89 171 363 minecraft:spruce_planks
setblock 89 146 364 minecraft:dark_oak_planks
fill 47 147 322 47 170 326 minecraft:spruce_planks
setblock 47 147 327 minecraft:dark_oak_planks
fill 47 147 328 47 157 335 minecraft:spruce_planks
fill 47 147 340 47 222 340 minecraft:spruce_planks
fill 47 147 342 47 170 345 minecraft:spruce_planks
setblock 47 147 346 minecraft:dark_oak_planks
fill 47 147 347 47 226 347 minecraft:spruce_planks
fill 47 147 355 47 186 355 minecraft:spruce_planks
setblock 47 147 362 minecraft:dark_oak_planks
fill 48 147 322 50 170 322 minecraft:spruce_planks
setblock 51 147 322 minecraft:dark_oak_planks
fill 52 147 322 68 148 322 minecraft:spruce_planks
fill 63 147 364 63 166 364 minecraft:spruce_planks
fill 67 147 364 67 186 364 minecraft:spruce_planks
fill 78 147 322 78 227 322 minecraft:spruce_planks
fill 84 147 322 84 158 322 minecraft:spruce_planks
setblock 85 147 322 minecraft:dark_oak_planks
fill 86 147 322 88 222 322 minecraft:spruce_planks
fill 88 147 364 89 222 364 minecraft:spruce_planks
setblock 89 147 322 minecraft:dark_oak_planks
fill 89 147 323 89 157 326 minecraft:spruce_planks
setblock 89 147 327 minecraft:dark_oak_planks
fill 89 147 328 89 156 335 minecraft:spruce_planks
fill 89 147 338 89 148 339 minecraft:spruce_planks
fill 89 147 340 89 147 341 minecraft:dark_oak_planks
fill 89 147 342 89 163 345 minecraft:spruce_planks
fill 89 147 346 89 147 347 minecraft:dark_oak_planks
fill 89 147 348 89 226 348 minecraft:spruce_planks
fill 89 147 350 89 157 350 minecraft:spruce_planks
fill 89 147 352 89 180 354 minecraft:spruce_planks
fill 47 148 327 47 226 327 minecraft:spruce_planks
fill 47 148 346 47 226 346 minecraft:spruce_planks
fill 47 148 357 47 226 357 minecraft:spruce_planks
fill 47 148 362 47 226 362 minecraft:spruce_planks
setblock 50 148 325 minecraft:light[level=12]
setblock 50 148 332 minecraft:light[level=12]
setblock 50 148 339 minecraft:light[level=12]
setblock 50 148 346 minecraft:light[level=12]
setblock 50 148 353 minecraft:light[level=12]
setblock 50 148 360 minecraft:light[level=12]
fill 51 148 322 51 183 322 minecraft:spruce_planks
setblock 57 148 325 minecraft:light[level=12]
setblock 57 148 332 minecraft:light[level=12]
setblock 57 148 339 minecraft:light[level=12]
fill 57 148 342 65 148 342 minecraft:smooth_sandstone
setblock 57 148 346 minecraft:light[level=12]
setblock 57 148 353 minecraft:light[level=12]
setblock 57 148 360 minecraft:light[level=12]
fill 58 148 338 65 148 341 minecraft:smooth_sandstone
fill 58 148 343 65 148 346 minecraft:smooth_sandstone
fill 59 148 336 77 148 337 minecraft:smooth_sandstone
fill 59 148 347 77 148 348 minecraft:smooth_sandstone
fill 60 148 335 76 148 335 minecraft:smooth_sandstone
fill 60 148 349 76 148 349 minecraft:smooth_sandstone
fill 61 148 334 75 148 334 minecraft:smooth_sandstone
fill 61 148 350 75 148 350 minecraft:smooth_sandstone
fill 62 148 333 74 148 333 minecraft:smooth_sandstone
fill 62 148 351 74 148 351 minecraft:smooth_sandstone
setblock 64 148 325 minecraft:light[level=12]
fill 64 148 332 72 148 332 minecraft:smooth_sandstone
fill 64 148 352 72 148 352 minecraft:smooth_sandstone
setblock 64 148 353 minecraft:light[level=12]
setblock 64 148 360 minecraft:light[level=12]
fill 66 148 338 66 148 340 minecraft:smooth_sandstone
fill 66 148 344 66 148 346 minecraft:smooth_sandstone
fill 67 148 338 78 148 339 minecraft:smooth_sandstone
fill 67 148 345 78 148 346 minecraft:smooth_sandstone
fill 68 148 331 68 149 331 minecraft:smooth_sandstone
fill 68 148 353 68 149 353 minecraft:smooth_sandstone
fill 69 148 322 69 192 322 minecraft:spruce_planks
fill 70 148 340 78 148 340 minecraft:smooth_sandstone
fill 70 148 344 78 148 344 minecraft:smooth_sandstone
setblock 71 148 325 minecraft:light[level=12]
fill 71 148 341 78 148 343 minecraft:smooth_sandstone
setblock 71 148 353 minecraft:light[level=12]
setblock 71 148 360 minecraft:light[level=12]
setblock 78 148 325 minecraft:light[level=12]
setblock 78 148 332 minecraft:light[level=12]
setblock 78 148 353 minecraft:light[level=12]
setblock 78 148 360 minecraft:light[level=12]
fill 79 148 342 79 149 342 minecraft:smooth_sandstone
fill 85 148 322 85 226 322 minecraft:spruce_planks
setblock 85 148 325 minecraft:light[level=12]
setblock 85 148 332 minecraft:light[level=12]
setblock 85 148 339 minecraft:light[level=12]
setblock 85 148 346 minecraft:light[level=12]
setblock 85 148 353 minecraft:light[level=12]
setblock 85 148 360 minecraft:light[level=12]
fill 89 148 322 89 222 322 minecraft:spruce_planks
fill 89 148 327 89 176 327 minecraft:spruce_planks
fill 89 148 340 89 220 341 minecraft:spruce_planks
fill 89 148 346 89 226 347 minecraft:spruce_planks
fill 48 149 323 48 149 324 minecraft:moss_block
setblock 48 149 325 minecraft:mossy_cobblestone
fill 48 149 326 48 149 328 minecraft:moss_block
setblock 48 149 329 minecraft:mossy_cobblestone
fill 48 149 330 48 149 332 minecraft:moss_block
setblock 48 149 333 minecraft:mossy_cobblestone
fill 48 149 334 48 149 336 minecraft:moss_block
setblock 48 149 337 minecraft:mossy_cobblestone
fill 48 149 338 48 149 340 minecraft:moss_block
setblock 48 149 341 minecraft:mossy_cobblestone
fill 48 149 342 48 149 344 minecraft:moss_block
setblock 48 149 345 minecraft:mossy_cobblestone
fill 48 149 346 48 149 348 minecraft:moss_block
setblock 48 149 349 minecraft:mossy_cobblestone
fill 48 149 350 48 149 352 minecraft:moss_block
setblock 48 149 353 minecraft:mossy_cobblestone
fill 48 149 354 48 149 356 minecraft:moss_block
setblock 48 149 357 minecraft:mossy_cobblestone
fill 48 149 358 48 149 360 minecraft:moss_block
setblock 48 149 361 minecraft:mossy_cobblestone
fill 48 149 362 49 149 363 minecraft:moss_block
schedule function dropper:buildpart/73_2 1t
