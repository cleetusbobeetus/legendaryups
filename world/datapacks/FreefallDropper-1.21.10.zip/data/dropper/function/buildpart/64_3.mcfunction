fill 207 212 296 208 212 296 minecraft:prismarine
setblock 207 212 298 minecraft:dark_prismarine
fill 207 212 299 208 212 299 minecraft:prismarine
fill 207 212 301 207 213 301 minecraft:dark_prismarine
fill 207 212 302 208 213 302 minecraft:prismarine
fill 207 212 304 208 213 304 minecraft:gold_block
fill 208 212 291 208 213 291 minecraft:dark_prismarine
fill 208 212 292 209 213 292 minecraft:prismarine
fill 208 212 294 208 213 294 minecraft:dark_prismarine
fill 208 212 295 209 213 295 minecraft:prismarine
setblock 208 212 297 minecraft:dark_prismarine
fill 208 212 298 209 212 298 minecraft:prismarine
fill 208 212 300 208 213 300 minecraft:dark_prismarine
fill 208 212 301 209 213 301 minecraft:prismarine
fill 208 212 303 208 213 303 minecraft:dark_prismarine
fill 209 212 291 209 213 291 minecraft:gold_block
fill 209 212 293 209 213 293 minecraft:dark_prismarine
fill 209 212 294 210 213 294 minecraft:prismarine
fill 209 212 296 209 213 296 minecraft:dark_prismarine
fill 209 212 297 210 213 297 minecraft:prismarine
fill 209 212 299 209 213 299 minecraft:dark_prismarine
fill 209 212 300 210 213 300 minecraft:prismarine
fill 209 212 302 209 213 302 minecraft:dark_prismarine
fill 209 212 303 209 213 303 minecraft:gold_block
fill 210 212 292 210 213 292 minecraft:gold_block
fill 210 212 293 210 213 293 minecraft:prismarine
fill 210 212 295 210 213 295 minecraft:dark_prismarine
fill 210 212 296 211 213 296 minecraft:prismarine
fill 210 212 298 210 213 298 minecraft:dark_prismarine
fill 210 212 299 211 213 299 minecraft:prismarine
fill 210 212 301 210 213 301 minecraft:dark_prismarine
fill 210 212 302 210 213 302 minecraft:gold_block
fill 211 212 293 211 213 294 minecraft:gold_block
fill 211 212 295 211 213 295 minecraft:prismarine
fill 211 212 297 211 213 297 minecraft:dark_prismarine
fill 211 212 298 211 213 298 minecraft:prismarine
fill 211 212 300 211 213 301 minecraft:gold_block
setblock 212 212 278 minecraft:light[level=12]
setblock 212 212 285 minecraft:light[level=12]
setblock 212 212 292 minecraft:light[level=12]
fill 212 212 295 212 213 299 minecraft:gold_block
setblock 212 212 306 minecraft:light[level=12]
setblock 212 212 313 minecraft:light[level=12]
setblock 219 212 278 minecraft:light[level=12]
setblock 219 212 285 minecraft:light[level=12]
setblock 219 212 292 minecraft:light[level=12]
setblock 219 212 299 minecraft:light[level=12]
setblock 219 212 306 minecraft:light[level=12]
setblock 219 212 313 minecraft:light[level=12]
setblock 226 212 285 minecraft:light[level=12]
setblock 226 212 292 minecraft:light[level=12]
setblock 226 212 299 minecraft:light[level=12]
setblock 226 212 306 minecraft:light[level=12]
fill 230 212 294 230 217 294 minecraft:prismarine_bricks
fill 189 213 276 189 213 277 minecraft:dark_prismarine
setblock 189 213 278 minecraft:prismarine
fill 189 213 279 189 213 281 minecraft:dark_prismarine
setblock 189 213 282 minecraft:prismarine
fill 189 213 283 189 213 285 minecraft:dark_prismarine
setblock 189 213 286 minecraft:prismarine
fill 189 213 287 189 213 289 minecraft:dark_prismarine
setblock 189 213 290 minecraft:prismarine
fill 189 213 291 189 213 293 minecraft:dark_prismarine
setblock 189 213 294 minecraft:prismarine
fill 189 213 295 189 213 297 minecraft:dark_prismarine
setblock 189 213 298 minecraft:prismarine
fill 189 213 299 189 213 301 minecraft:dark_prismarine
setblock 189 213 302 minecraft:prismarine
fill 189 213 303 189 213 305 minecraft:dark_prismarine
setblock 189 213 306 minecraft:prismarine
fill 189 213 307 189 213 309 minecraft:dark_prismarine
setblock 189 213 310 minecraft:prismarine
fill 189 213 311 189 213 313 minecraft:dark_prismarine
setblock 189 213 314 minecraft:prismarine
fill 189 213 315 190 213 316 minecraft:dark_prismarine
setblock 190 213 276 minecraft:dark_prismarine
setblock 190 213 277 minecraft:prismarine
fill 190 213 278 190 213 280 minecraft:dark_prismarine
setblock 190 213 281 minecraft:prismarine
fill 190 213 282 190 213 284 minecraft:dark_prismarine
setblock 190 213 285 minecraft:prismarine
fill 190 213 286 190 213 288 minecraft:dark_prismarine
setblock 190 213 289 minecraft:prismarine
fill 190 213 290 190 213 292 minecraft:dark_prismarine
setblock 190 213 293 minecraft:prismarine
fill 190 213 294 192 213 294 minecraft:dark_prismarine
fill 190 213 298 190 213 300 minecraft:dark_prismarine
setblock 190 213 301 minecraft:prismarine
fill 190 213 302 190 213 304 minecraft:dark_prismarine
setblock 190 213 305 minecraft:prismarine
fill 190 213 306 190 213 308 minecraft:dark_prismarine
setblock 190 213 309 minecraft:prismarine
fill 190 213 310 190 213 312 minecraft:dark_prismarine
setblock 190 213 313 minecraft:prismarine
setblock 190 213 314 minecraft:dark_prismarine
setblock 191 213 276 minecraft:prismarine
fill 191 213 277 193 213 277 minecraft:dark_prismarine
fill 191 213 281 191 213 283 minecraft:dark_prismarine
setblock 191 213 284 minecraft:prismarine
fill 191 213 285 191 213 287 minecraft:dark_prismarine
setblock 191 213 288 minecraft:prismarine
fill 191 213 289 191 213 291 minecraft:dark_prismarine
setblock 191 213 292 minecraft:prismarine
fill 191 213 293 193 213 293 minecraft:dark_prismarine
fill 191 213 298 191 213 299 minecraft:dark_prismarine
setblock 191 213 300 minecraft:prismarine
fill 191 213 301 191 213 303 minecraft:dark_prismarine
setblock 191 213 304 minecraft:prismarine
fill 191 213 305 191 213 307 minecraft:dark_prismarine
setblock 191 213 308 minecraft:prismarine
fill 191 213 309 191 213 311 minecraft:dark_prismarine
setblock 191 213 315 minecraft:dark_prismarine
setblock 191 213 316 minecraft:prismarine
fill 192 213 276 194 213 276 minecraft:dark_prismarine
fill 192 213 281 192 213 282 minecraft:dark_prismarine
setblock 192 213 283 minecraft:prismarine
fill 192 213 284 192 213 286 minecraft:dark_prismarine
setblock 192 213 287 minecraft:prismarine
fill 192 213 288 192 213 290 minecraft:dark_prismarine
setblock 192 213 291 minecraft:prismarine
fill 192 213 292 194 213 292 minecraft:dark_prismarine
setblock 192 213 298 minecraft:dark_prismarine
setblock 192 213 299 minecraft:prismarine
fill 192 213 300 192 213 302 minecraft:dark_prismarine
setblock 192 213 303 minecraft:prismarine
fill 192 213 304 192 213 306 minecraft:dark_prismarine
setblock 192 213 307 minecraft:prismarine
fill 192 213 308 192 213 310 minecraft:dark_prismarine
setblock 192 213 311 minecraft:prismarine
setblock 192 213 315 minecraft:prismarine
fill 192 213 316 194 213 316 minecraft:dark_prismarine
setblock 193 213 281 minecraft:dark_prismarine
setblock 193 213 282 minecraft:prismarine
fill 193 213 283 193 213 285 minecraft:dark_prismarine
setblock 193 213 286 minecraft:prismarine
fill 193 213 287 193 213 289 minecraft:dark_prismarine
setblock 193 213 290 minecraft:prismarine
fill 193 213 291 195 213 291 minecraft:dark_prismarine
setblock 193 213 294 minecraft:prismarine
fill 193 213 295 193 213 297 minecraft:dark_prismarine
setblock 193 213 298 minecraft:prismarine
fill 193 213 299 193 213 301 minecraft:dark_prismarine
setblock 193 213 302 minecraft:prismarine
fill 193 213 303 193 213 305 minecraft:dark_prismarine
setblock 193 213 306 minecraft:prismarine
fill 193 213 307 193 213 309 minecraft:dark_prismarine
setblock 193 213 310 minecraft:prismarine
fill 193 213 311 195 213 311 minecraft:dark_prismarine
fill 193 213 315 195 213 315 minecraft:dark_prismarine
setblock 194 213 277 minecraft:prismarine
fill 194 213 278 194 213 280 minecraft:dark_prismarine
setblock 194 213 281 minecraft:prismarine
fill 194 213 282 194 213 284 minecraft:dark_prismarine
setblock 194 213 285 minecraft:prismarine
fill 194 213 286 194 213 288 minecraft:dark_prismarine
setblock 194 213 289 minecraft:prismarine
fill 194 213 290 196 213 290 minecraft:dark_prismarine
setblock 194 213 293 minecraft:prismarine
fill 194 213 294 194 213 296 minecraft:dark_prismarine
setblock 194 213 297 minecraft:prismarine
fill 194 213 298 194 213 300 minecraft:dark_prismarine
setblock 194 213 301 minecraft:prismarine
fill 194 213 302 194 213 304 minecraft:dark_prismarine
setblock 194 213 305 minecraft:prismarine
fill 194 213 306 194 213 308 minecraft:dark_prismarine
setblock 194 213 309 minecraft:prismarine
fill 194 213 310 196 213 310 minecraft:dark_prismarine
setblock 194 213 312 minecraft:dark_prismarine
setblock 194 213 313 minecraft:prismarine
fill 194 213 314 196 213 314 minecraft:dark_prismarine
setblock 195 213 276 minecraft:prismarine
fill 195 213 277 195 213 279 minecraft:dark_prismarine
setblock 195 213 280 minecraft:prismarine
fill 195 213 281 195 213 283 minecraft:dark_prismarine
setblock 195 213 284 minecraft:prismarine
fill 195 213 285 195 213 287 minecraft:dark_prismarine
setblock 195 213 288 minecraft:prismarine
fill 195 213 289 197 213 289 minecraft:dark_prismarine
setblock 195 213 292 minecraft:prismarine
fill 195 213 293 195 213 295 minecraft:dark_prismarine
setblock 195 213 296 minecraft:prismarine
fill 195 213 297 195 213 299 minecraft:dark_prismarine
setblock 195 213 300 minecraft:prismarine
fill 195 213 301 195 213 303 minecraft:dark_prismarine
setblock 195 213 304 minecraft:prismarine
fill 195 213 305 195 213 307 minecraft:dark_prismarine
setblock 195 213 308 minecraft:prismarine
fill 195 213 309 197 213 309 minecraft:dark_prismarine
setblock 195 213 312 minecraft:prismarine
fill 195 213 313 197 213 313 minecraft:dark_prismarine
setblock 195 213 316 minecraft:prismarine
fill 196 213 276 196 213 278 minecraft:dark_prismarine
setblock 196 213 279 minecraft:prismarine
fill 196 213 280 196 213 282 minecraft:dark_prismarine
setblock 196 213 283 minecraft:prismarine
fill 196 213 284 196 213 286 minecraft:dark_prismarine
setblock 196 213 287 minecraft:prismarine
fill 196 213 288 198 213 288 minecraft:dark_prismarine
setblock 196 213 291 minecraft:prismarine
fill 196 213 292 196 213 293 minecraft:dark_prismarine
setblock 196 213 294 minecraft:gold_block
setblock 196 213 300 minecraft:gold_block
fill 196 213 301 196 213 302 minecraft:dark_prismarine
setblock 196 213 303 minecraft:prismarine
fill 196 213 304 196 213 306 minecraft:dark_prismarine
setblock 196 213 307 minecraft:prismarine
fill 196 213 308 198 213 308 minecraft:dark_prismarine
setblock 196 213 311 minecraft:prismarine
fill 196 213 312 198 213 312 minecraft:dark_prismarine
setblock 196 213 315 minecraft:prismarine
fill 196 213 316 198 213 316 minecraft:dark_prismarine
fill 197 213 276 197 213 277 minecraft:dark_prismarine
setblock 197 213 278 minecraft:prismarine
fill 197 213 279 197 213 281 minecraft:dark_prismarine
setblock 197 213 282 minecraft:prismarine
fill 197 213 283 197 213 285 minecraft:dark_prismarine
setblock 197 213 286 minecraft:prismarine
fill 197 213 287 199 213 287 minecraft:dark_prismarine
setblock 197 213 290 minecraft:prismarine
setblock 197 213 291 minecraft:dark_prismarine
setblock 197 213 292 minecraft:gold_block
setblock 197 213 302 minecraft:gold_block
fill 197 213 303 197 213 305 minecraft:dark_prismarine
setblock 197 213 306 minecraft:prismarine
fill 197 213 307 199 213 307 minecraft:dark_prismarine
setblock 197 213 310 minecraft:prismarine
fill 197 213 311 199 213 311 minecraft:dark_prismarine
setblock 197 213 314 minecraft:prismarine
fill 197 213 315 199 213 315 minecraft:dark_prismarine
setblock 198 213 276 minecraft:dark_prismarine
setblock 198 213 277 minecraft:prismarine
fill 198 213 278 198 213 280 minecraft:dark_prismarine
setblock 198 213 281 minecraft:prismarine
fill 198 213 282 198 213 284 minecraft:dark_prismarine
setblock 198 213 285 minecraft:prismarine
fill 198 213 286 200 213 286 minecraft:dark_prismarine
setblock 198 213 289 minecraft:prismarine
setblock 198 213 290 minecraft:dark_prismarine
setblock 198 213 291 minecraft:gold_block
setblock 198 213 303 minecraft:gold_block
setblock 198 213 304 minecraft:dark_prismarine
setblock 198 213 305 minecraft:prismarine
fill 198 213 306 200 213 306 minecraft:dark_prismarine
setblock 198 213 309 minecraft:prismarine
fill 198 213 310 200 213 310 minecraft:dark_prismarine
setblock 198 213 313 minecraft:prismarine
fill 198 213 314 200 213 314 minecraft:dark_prismarine
setblock 199 213 276 minecraft:prismarine
fill 199 213 277 199 213 279 minecraft:dark_prismarine
setblock 199 213 280 minecraft:prismarine
fill 199 213 281 199 213 283 minecraft:dark_prismarine
setblock 199 213 284 minecraft:prismarine
fill 199 213 285 201 213 285 minecraft:dark_prismarine
setblock 199 213 288 minecraft:prismarine
fill 199 213 289 200 213 289 minecraft:dark_prismarine
setblock 199 213 290 minecraft:gold_block
setblock 199 213 304 minecraft:gold_block
fill 199 213 305 200 213 305 minecraft:dark_prismarine
setblock 199 213 308 minecraft:prismarine
fill 199 213 309 201 213 309 minecraft:dark_prismarine
setblock 199 213 312 minecraft:prismarine
fill 199 213 313 201 213 313 minecraft:dark_prismarine
setblock 199 213 316 minecraft:prismarine
fill 200 213 276 200 213 278 minecraft:dark_prismarine
setblock 200 213 279 minecraft:prismarine
fill 200 213 280 200 213 282 minecraft:dark_prismarine
setblock 200 213 283 minecraft:prismarine
fill 200 213 284 202 213 284 minecraft:dark_prismarine
setblock 200 213 287 minecraft:prismarine
fill 200 213 288 202 213 288 minecraft:dark_prismarine
fill 200 213 296 200 213 298 minecraft:sea_lantern
setblock 200 213 307 minecraft:prismarine
fill 200 213 308 202 213 308 minecraft:dark_prismarine
setblock 200 213 311 minecraft:prismarine
fill 200 213 312 202 213 312 minecraft:dark_prismarine
setblock 200 213 315 minecraft:prismarine
fill 200 213 316 202 213 316 minecraft:dark_prismarine
fill 201 213 276 201 213 277 minecraft:dark_prismarine
setblock 201 213 278 minecraft:prismarine
fill 201 213 279 201 213 281 minecraft:dark_prismarine
setblock 201 213 282 minecraft:prismarine
fill 201 213 283 203 213 283 minecraft:dark_prismarine
setblock 201 213 286 minecraft:prismarine
fill 201 213 287 203 213 287 minecraft:dark_prismarine
setblock 201 213 289 minecraft:gold_block
setblock 201 213 293 minecraft:prismarine
fill 201 213 294 201 213 296 minecraft:sea_lantern
fill 201 213 298 201 213 300 minecraft:sea_lantern
setblock 201 213 305 minecraft:gold_block
setblock 201 213 306 minecraft:prismarine
fill 201 213 307 203 213 307 minecraft:dark_prismarine
setblock 201 213 310 minecraft:prismarine
fill 201 213 311 203 213 311 minecraft:dark_prismarine
setblock 201 213 314 minecraft:prismarine
fill 201 213 315 203 213 315 minecraft:dark_prismarine
setblock 202 213 276 minecraft:dark_prismarine
setblock 202 213 277 minecraft:prismarine
fill 202 213 278 202 213 280 minecraft:dark_prismarine
setblock 202 213 281 minecraft:prismarine
fill 202 213 282 204 213 282 minecraft:dark_prismarine
setblock 202 213 285 minecraft:prismarine
fill 202 213 286 204 213 286 minecraft:dark_prismarine
fill 202 213 294 203 213 294 minecraft:sea_lantern
fill 202 213 300 203 213 300 minecraft:sea_lantern
setblock 202 213 301 minecraft:prismarine
fill 202 213 306 203 213 306 minecraft:dark_prismarine
setblock 202 213 309 minecraft:prismarine
fill 202 213 310 203 213 310 minecraft:dark_prismarine
setblock 202 213 313 minecraft:prismarine
fill 202 213 314 204 213 314 minecraft:dark_prismarine
setblock 203 213 276 minecraft:prismarine
fill 203 213 277 203 213 279 minecraft:dark_prismarine
setblock 203 213 280 minecraft:prismarine
fill 203 213 281 205 213 281 minecraft:dark_prismarine
setblock 203 213 284 minecraft:prismarine
fill 203 213 285 205 213 285 minecraft:dark_prismarine
setblock 203 213 288 minecraft:prismarine
fill 203 213 293 205 213 293 minecraft:sea_lantern
fill 203 213 301 205 213 301 minecraft:sea_lantern
setblock 203 213 308 minecraft:prismarine
setblock 203 213 309 minecraft:dark_prismarine
setblock 203 213 312 minecraft:prismarine
fill 203 213 313 205 213 313 minecraft:dark_prismarine
setblock 203 213 316 minecraft:prismarine
fill 204 213 276 204 213 278 minecraft:dark_prismarine
setblock 204 213 279 minecraft:prismarine
fill 204 213 280 206 213 280 minecraft:dark_prismarine
setblock 204 213 283 minecraft:prismarine
fill 204 213 284 206 213 284 minecraft:dark_prismarine
setblock 204 213 287 minecraft:prismarine
fill 204 213 288 206 213 288 minecraft:dark_prismarine
fill 204 213 306 204 213 310 minecraft:gold_block
setblock 204 213 311 minecraft:prismarine
fill 204 213 312 206 213 312 minecraft:dark_prismarine
setblock 204 213 315 minecraft:prismarine
fill 204 213 316 206 213 316 minecraft:dark_prismarine
fill 205 213 276 205 213 277 minecraft:dark_prismarine
setblock 205 213 278 minecraft:prismarine
fill 205 213 279 207 213 279 minecraft:dark_prismarine
setblock 205 213 282 minecraft:prismarine
fill 205 213 283 207 213 283 minecraft:dark_prismarine
setblock 205 213 286 minecraft:prismarine
fill 205 213 287 207 213 287 minecraft:dark_prismarine
fill 205 213 294 207 213 294 minecraft:sea_lantern
fill 205 213 300 207 213 300 minecraft:sea_lantern
setblock 205 213 306 minecraft:prismarine
fill 205 213 307 205 213 309 minecraft:dark_prismarine
setblock 205 213 310 minecraft:prismarine
fill 205 213 311 207 213 311 minecraft:dark_prismarine
setblock 205 213 314 minecraft:prismarine
fill 205 213 315 207 213 315 minecraft:dark_prismarine
setblock 206 213 276 minecraft:dark_prismarine
setblock 206 213 277 minecraft:prismarine
fill 206 213 278 207 213 278 minecraft:dark_prismarine
setblock 206 213 281 minecraft:prismarine
fill 206 213 282 208 213 282 minecraft:dark_prismarine
setblock 206 213 285 minecraft:prismarine
fill 206 213 286 208 213 286 minecraft:dark_prismarine
setblock 206 213 301 minecraft:prismarine
fill 206 213 306 206 213 308 minecraft:dark_prismarine
setblock 206 213 309 minecraft:prismarine
fill 206 213 310 208 213 310 minecraft:dark_prismarine
setblock 206 213 313 minecraft:prismarine
fill 206 213 314 207 213 314 minecraft:dark_prismarine
setblock 207 213 276 minecraft:prismarine
setblock 207 213 277 minecraft:dark_prismarine
setblock 207 213 280 minecraft:prismarine
fill 207 213 281 209 213 281 minecraft:dark_prismarine
setblock 207 213 284 minecraft:prismarine
fill 207 213 285 209 213 285 minecraft:dark_prismarine
setblock 207 213 288 minecraft:prismarine
setblock 207 213 289 minecraft:gold_block
fill 207 213 295 207 213 296 minecraft:sea_lantern
fill 207 213 298 207 213 299 minecraft:sea_lantern
setblock 207 213 305 minecraft:gold_block
fill 207 213 306 207 213 307 minecraft:dark_prismarine
setblock 207 213 308 minecraft:prismarine
fill 207 213 309 209 213 309 minecraft:dark_prismarine
setblock 207 213 312 minecraft:prismarine
setblock 207 213 313 minecraft:dark_prismarine
setblock 207 213 316 minecraft:prismarine
fill 208 213 276 210 213 276 minecraft:dark_prismarine
fill 208 213 280 210 213 280 minecraft:dark_prismarine
setblock 208 213 283 minecraft:prismarine
fill 208 213 284 210 213 284 minecraft:dark_prismarine
setblock 208 213 287 minecraft:prismarine
fill 208 213 288 209 213 289 minecraft:dark_prismarine
fill 208 213 296 208 213 298 minecraft:sea_lantern
setblock 208 213 299 minecraft:prismarine
fill 208 213 305 208 213 306 minecraft:dark_prismarine
setblock 208 213 307 minecraft:prismarine
fill 208 213 308 210 213 308 minecraft:dark_prismarine
setblock 208 213 311 minecraft:prismarine
fill 208 213 312 210 213 312 minecraft:dark_prismarine
fill 208 213 316 210 213 316 minecraft:dark_prismarine
setblock 209 213 282 minecraft:prismarine
fill 209 213 283 211 213 283 minecraft:dark_prismarine
setblock 209 213 286 minecraft:prismarine
fill 209 213 287 211 213 287 minecraft:dark_prismarine
setblock 209 213 290 minecraft:gold_block
setblock 209 213 298 minecraft:prismarine
setblock 209 213 304 minecraft:gold_block
setblock 209 213 305 minecraft:dark_prismarine
setblock 209 213 306 minecraft:prismarine
fill 209 213 307 211 213 307 minecraft:dark_prismarine
setblock 209 213 310 minecraft:prismarine
fill 209 213 311 211 213 311 minecraft:dark_prismarine
setblock 210 213 281 minecraft:prismarine
fill 210 213 282 212 213 282 minecraft:dark_prismarine
setblock 210 213 285 minecraft:prismarine
fill 210 213 286 212 213 286 minecraft:dark_prismarine
setblock 210 213 288 minecraft:dark_prismarine
setblock 210 213 289 minecraft:prismarine
fill 210 213 290 212 213 290 minecraft:dark_prismarine
setblock 210 213 291 minecraft:gold_block
setblock 210 213 303 minecraft:gold_block
setblock 210 213 304 minecraft:dark_prismarine
setblock 210 213 305 minecraft:prismarine
fill 210 213 306 212 213 306 minecraft:dark_prismarine
setblock 210 213 309 minecraft:prismarine
fill 210 213 310 212 213 310 minecraft:dark_prismarine
setblock 211 213 276 minecraft:prismarine
fill 211 213 277 211 213 279 minecraft:dark_prismarine
setblock 211 213 280 minecraft:prismarine
fill 211 213 281 213 213 281 minecraft:dark_prismarine
setblock 211 213 284 minecraft:prismarine
fill 211 213 285 213 213 285 minecraft:dark_prismarine
setblock 211 213 288 minecraft:prismarine
fill 211 213 289 213 213 289 minecraft:dark_prismarine
setblock 211 213 291 minecraft:dark_prismarine
setblock 211 213 292 minecraft:gold_block
setblock 211 213 302 minecraft:gold_block
setblock 211 213 303 minecraft:dark_prismarine
setblock 211 213 304 minecraft:prismarine
fill 211 213 305 213 213 305 minecraft:dark_prismarine
setblock 211 213 308 minecraft:prismarine
fill 211 213 309 213 213 309 minecraft:dark_prismarine
setblock 211 213 312 minecraft:prismarine
fill 211 213 313 211 213 315 minecraft:dark_prismarine
setblock 211 213 316 minecraft:prismarine
fill 212 213 276 212 213 278 minecraft:dark_prismarine
setblock 212 213 279 minecraft:prismarine
fill 212 213 280 214 213 280 minecraft:dark_prismarine
setblock 212 213 283 minecraft:prismarine
fill 212 213 284 214 213 284 minecraft:dark_prismarine
setblock 212 213 287 minecraft:prismarine
fill 212 213 288 214 213 288 minecraft:dark_prismarine
setblock 212 213 291 minecraft:prismarine
fill 212 213 292 213 213 293 minecraft:dark_prismarine
setblock 212 213 294 minecraft:gold_block
setblock 212 213 300 minecraft:gold_block
fill 212 213 301 212 213 302 minecraft:dark_prismarine
setblock 212 213 303 minecraft:prismarine
fill 212 213 304 214 213 304 minecraft:dark_prismarine
setblock 212 213 307 minecraft:prismarine
fill 212 213 308 214 213 308 minecraft:dark_prismarine
setblock 212 213 311 minecraft:prismarine
fill 212 213 312 212 213 314 minecraft:dark_prismarine
setblock 212 213 315 minecraft:prismarine
fill 212 213 316 214 213 316 minecraft:dark_prismarine
fill 213 213 276 213 213 277 minecraft:dark_prismarine
setblock 213 213 278 minecraft:prismarine
fill 213 213 279 215 213 279 minecraft:dark_prismarine
setblock 213 213 282 minecraft:prismarine
fill 213 213 283 215 213 283 minecraft:dark_prismarine
setblock 213 213 286 minecraft:prismarine
fill 213 213 287 215 213 287 minecraft:dark_prismarine
setblock 213 213 290 minecraft:prismarine
fill 213 213 291 215 213 291 minecraft:dark_prismarine
setblock 213 213 294 minecraft:prismarine
fill 213 213 295 213 213 297 minecraft:dark_prismarine
setblock 213 213 298 minecraft:prismarine
fill 213 213 299 213 213 301 minecraft:dark_prismarine
setblock 213 213 302 minecraft:prismarine
fill 213 213 303 215 213 303 minecraft:dark_prismarine
setblock 213 213 306 minecraft:prismarine
fill 213 213 307 215 213 307 minecraft:dark_prismarine
setblock 213 213 310 minecraft:prismarine
fill 213 213 311 213 213 313 minecraft:dark_prismarine
setblock 213 213 314 minecraft:prismarine
fill 213 213 315 215 213 315 minecraft:dark_prismarine
setblock 214 213 276 minecraft:dark_prismarine
setblock 214 213 277 minecraft:prismarine
fill 214 213 278 216 213 278 minecraft:dark_prismarine
setblock 214 213 281 minecraft:prismarine
fill 214 213 282 216 213 282 minecraft:dark_prismarine
setblock 214 213 285 minecraft:prismarine
fill 214 213 286 216 213 286 minecraft:dark_prismarine
setblock 214 213 289 minecraft:prismarine
fill 214 213 290 216 213 290 minecraft:dark_prismarine
setblock 214 213 292 minecraft:dark_prismarine
setblock 214 213 293 minecraft:prismarine
fill 214 213 294 214 213 296 minecraft:dark_prismarine
setblock 214 213 297 minecraft:prismarine
fill 214 213 298 214 213 300 minecraft:dark_prismarine
setblock 214 213 301 minecraft:prismarine
fill 214 213 302 216 213 302 minecraft:dark_prismarine
setblock 214 213 305 minecraft:prismarine
fill 214 213 306 216 213 306 minecraft:dark_prismarine
setblock 214 213 309 minecraft:prismarine
fill 214 213 310 214 213 312 minecraft:dark_prismarine
setblock 214 213 313 minecraft:prismarine
fill 214 213 314 216 213 314 minecraft:dark_prismarine
setblock 215 213 276 minecraft:prismarine
fill 215 213 277 217 213 277 minecraft:dark_prismarine
setblock 215 213 280 minecraft:prismarine
fill 215 213 281 217 213 281 minecraft:dark_prismarine
setblock 215 213 284 minecraft:prismarine
fill 215 213 285 217 213 285 minecraft:dark_prismarine
setblock 215 213 288 minecraft:prismarine
fill 215 213 289 217 213 289 minecraft:dark_prismarine
setblock 215 213 292 minecraft:prismarine
fill 215 213 293 215 213 295 minecraft:dark_prismarine
setblock 215 213 296 minecraft:prismarine
fill 215 213 297 215 213 299 minecraft:dark_prismarine
setblock 215 213 300 minecraft:prismarine
fill 215 213 301 217 213 301 minecraft:dark_prismarine
setblock 215 213 304 minecraft:prismarine
fill 215 213 305 217 213 305 minecraft:dark_prismarine
setblock 215 213 308 minecraft:prismarine
fill 215 213 309 215 213 311 minecraft:dark_prismarine
setblock 215 213 312 minecraft:prismarine
fill 215 213 313 217 213 313 minecraft:dark_prismarine
setblock 215 213 316 minecraft:prismarine
fill 216 213 276 218 213 276 minecraft:dark_prismarine
setblock 216 213 279 minecraft:prismarine
fill 216 213 280 218 213 280 minecraft:dark_prismarine
setblock 216 213 283 minecraft:prismarine
fill 216 213 284 218 213 284 minecraft:dark_prismarine
setblock 216 213 287 minecraft:prismarine
fill 216 213 288 218 213 288 minecraft:dark_prismarine
setblock 216 213 291 minecraft:prismarine
fill 216 213 292 216 213 294 minecraft:dark_prismarine
setblock 216 213 295 minecraft:prismarine
fill 216 213 296 216 213 298 minecraft:dark_prismarine
setblock 216 213 299 minecraft:prismarine
fill 216 213 300 218 213 300 minecraft:dark_prismarine
setblock 216 213 303 minecraft:prismarine
fill 216 213 304 218 213 304 minecraft:dark_prismarine
setblock 216 213 307 minecraft:prismarine
fill 216 213 308 216 213 310 minecraft:dark_prismarine
setblock 216 213 311 minecraft:prismarine
fill 216 213 312 218 213 312 minecraft:dark_prismarine
setblock 216 213 315 minecraft:prismarine
fill 216 213 316 218 213 316 minecraft:dark_prismarine
setblock 217 213 278 minecraft:prismarine
fill 217 213 279 219 213 279 minecraft:dark_prismarine
setblock 217 213 282 minecraft:prismarine
fill 217 213 283 219 213 283 minecraft:dark_prismarine
setblock 217 213 286 minecraft:prismarine
fill 217 213 287 219 213 287 minecraft:dark_prismarine
setblock 217 213 290 minecraft:prismarine
fill 217 213 291 217 213 293 minecraft:dark_prismarine
setblock 217 213 294 minecraft:prismarine
fill 217 213 295 217 213 297 minecraft:dark_prismarine
setblock 217 213 298 minecraft:prismarine
fill 217 213 299 219 213 299 minecraft:dark_prismarine
setblock 217 213 302 minecraft:prismarine
fill 217 213 303 219 213 303 minecraft:dark_prismarine
setblock 217 213 306 minecraft:prismarine
fill 217 213 307 217 213 309 minecraft:dark_prismarine
setblock 217 213 310 minecraft:prismarine
fill 217 213 311 219 213 311 minecraft:dark_prismarine
setblock 217 213 314 minecraft:prismarine
fill 217 213 315 219 213 315 minecraft:dark_prismarine
setblock 218 213 277 minecraft:prismarine
fill 218 213 278 220 213 278 minecraft:dark_prismarine
setblock 218 213 281 minecraft:prismarine
fill 218 213 282 220 213 282 minecraft:dark_prismarine
setblock 218 213 285 minecraft:prismarine
fill 218 213 286 220 213 286 minecraft:dark_prismarine
setblock 218 213 289 minecraft:prismarine
fill 218 213 290 218 213 292 minecraft:dark_prismarine
setblock 218 213 293 minecraft:prismarine
fill 218 213 294 218 213 296 minecraft:dark_prismarine
setblock 218 213 297 minecraft:prismarine
fill 218 213 298 220 213 298 minecraft:dark_prismarine
setblock 218 213 301 minecraft:prismarine
fill 218 213 302 220 213 302 minecraft:dark_prismarine
setblock 218 213 305 minecraft:prismarine
fill 218 213 306 218 213 308 minecraft:dark_prismarine
setblock 218 213 309 minecraft:prismarine
fill 218 213 310 220 213 310 minecraft:dark_prismarine
setblock 218 213 313 minecraft:prismarine
fill 218 213 314 220 213 314 minecraft:dark_prismarine
setblock 219 213 276 minecraft:prismarine
fill 219 213 277 221 213 277 minecraft:dark_prismarine
setblock 219 213 280 minecraft:prismarine
fill 219 213 281 221 213 281 minecraft:dark_prismarine
setblock 219 213 284 minecraft:prismarine
fill 219 213 285 221 213 285 minecraft:dark_prismarine
setblock 219 213 288 minecraft:prismarine
fill 219 213 289 219 213 291 minecraft:dark_prismarine
setblock 219 213 292 minecraft:prismarine
fill 219 213 293 219 213 295 minecraft:dark_prismarine
setblock 219 213 296 minecraft:prismarine
fill 219 213 297 221 213 297 minecraft:dark_prismarine
setblock 219 213 300 minecraft:prismarine
fill 219 213 301 221 213 301 minecraft:dark_prismarine
setblock 219 213 304 minecraft:prismarine
fill 219 213 305 219 213 307 minecraft:dark_prismarine
setblock 219 213 308 minecraft:prismarine
fill 219 213 309 221 213 309 minecraft:dark_prismarine
setblock 219 213 312 minecraft:prismarine
fill 219 213 313 221 213 313 minecraft:dark_prismarine
setblock 219 213 316 minecraft:prismarine
fill 220 213 276 222 213 276 minecraft:dark_prismarine
setblock 220 213 279 minecraft:prismarine
fill 220 213 280 222 213 280 minecraft:dark_prismarine
setblock 220 213 283 minecraft:prismarine
fill 220 213 284 222 213 284 minecraft:dark_prismarine
setblock 220 213 287 minecraft:prismarine
fill 220 213 288 220 213 290 minecraft:dark_prismarine
setblock 220 213 291 minecraft:prismarine
fill 220 213 292 220 213 294 minecraft:dark_prismarine
setblock 220 213 295 minecraft:prismarine
fill 220 213 296 222 213 296 minecraft:dark_prismarine
setblock 220 213 299 minecraft:prismarine
fill 220 213 300 222 213 300 minecraft:dark_prismarine
setblock 220 213 303 minecraft:prismarine
fill 220 213 304 220 213 306 minecraft:dark_prismarine
setblock 220 213 307 minecraft:prismarine
fill 220 213 308 222 213 308 minecraft:dark_prismarine
setblock 220 213 311 minecraft:prismarine
fill 220 213 312 222 213 312 minecraft:dark_prismarine
setblock 220 213 315 minecraft:prismarine
fill 220 213 316 222 213 316 minecraft:dark_prismarine
setblock 221 213 278 minecraft:prismarine
fill 221 213 279 223 213 279 minecraft:dark_prismarine
setblock 221 213 282 minecraft:prismarine
fill 221 213 283 223 213 283 minecraft:dark_prismarine
setblock 221 213 286 minecraft:prismarine
fill 221 213 287 221 213 289 minecraft:dark_prismarine
setblock 221 213 290 minecraft:prismarine
fill 221 213 291 221 213 293 minecraft:dark_prismarine
setblock 221 213 294 minecraft:prismarine
fill 221 213 295 223 213 295 minecraft:dark_prismarine
setblock 221 213 298 minecraft:prismarine
fill 221 213 299 223 213 299 minecraft:dark_prismarine
setblock 221 213 302 minecraft:prismarine
fill 221 213 303 221 213 305 minecraft:dark_prismarine
setblock 221 213 306 minecraft:prismarine
fill 221 213 307 223 213 307 minecraft:dark_prismarine
setblock 221 213 310 minecraft:prismarine
fill 221 213 311 223 213 311 minecraft:dark_prismarine
setblock 221 213 314 minecraft:prismarine
fill 221 213 315 223 213 315 minecraft:dark_prismarine
setblock 222 213 277 minecraft:prismarine
fill 222 213 278 224 213 278 minecraft:dark_prismarine
setblock 222 213 281 minecraft:prismarine
fill 222 213 282 224 213 282 minecraft:dark_prismarine
setblock 222 213 285 minecraft:prismarine
fill 222 213 286 222 213 288 minecraft:dark_prismarine
setblock 222 213 289 minecraft:prismarine
fill 222 213 290 222 213 292 minecraft:dark_prismarine
setblock 222 213 293 minecraft:prismarine
fill 222 213 294 224 213 294 minecraft:dark_prismarine
setblock 222 213 297 minecraft:prismarine
fill 222 213 298 224 213 298 minecraft:dark_prismarine
setblock 222 213 301 minecraft:prismarine
fill 222 213 302 222 213 304 minecraft:dark_prismarine
setblock 222 213 305 minecraft:prismarine
fill 222 213 306 224 213 306 minecraft:dark_prismarine
setblock 222 213 309 minecraft:prismarine
fill 222 213 310 224 213 310 minecraft:dark_prismarine
setblock 222 213 313 minecraft:prismarine
fill 222 213 314 224 213 314 minecraft:dark_prismarine
setblock 223 213 276 minecraft:prismarine
fill 223 213 277 225 213 277 minecraft:dark_prismarine
setblock 223 213 280 minecraft:prismarine
fill 223 213 281 225 213 281 minecraft:dark_prismarine
setblock 223 213 284 minecraft:prismarine
fill 223 213 285 223 213 287 minecraft:dark_prismarine
setblock 223 213 288 minecraft:prismarine
fill 223 213 289 223 213 291 minecraft:dark_prismarine
setblock 223 213 292 minecraft:prismarine
fill 223 213 293 225 213 293 minecraft:dark_prismarine
setblock 223 213 296 minecraft:prismarine
fill 223 213 297 225 213 297 minecraft:dark_prismarine
setblock 223 213 300 minecraft:prismarine
fill 223 213 301 223 213 303 minecraft:dark_prismarine
setblock 223 213 304 minecraft:prismarine
fill 223 213 305 225 213 305 minecraft:dark_prismarine
setblock 223 213 308 minecraft:prismarine
fill 223 213 309 225 213 309 minecraft:dark_prismarine
setblock 223 213 312 minecraft:prismarine
fill 223 213 313 224 213 313 minecraft:dark_prismarine
setblock 223 213 316 minecraft:prismarine
fill 224 213 276 226 213 276 minecraft:dark_prismarine
setblock 224 213 279 minecraft:prismarine
setblock 224 213 280 minecraft:dark_prismarine
setblock 224 213 283 minecraft:prismarine
fill 224 213 284 224 213 286 minecraft:dark_prismarine
setblock 224 213 287 minecraft:prismarine
fill 224 213 288 224 213 290 minecraft:dark_prismarine
setblock 224 213 291 minecraft:prismarine
fill 224 213 292 226 213 292 minecraft:dark_prismarine
setblock 224 213 295 minecraft:prismarine
fill 224 213 296 225 213 296 minecraft:dark_prismarine
setblock 224 213 299 minecraft:prismarine
fill 224 213 300 224 213 302 minecraft:dark_prismarine
setblock 224 213 303 minecraft:prismarine
fill 224 213 304 226 213 304 minecraft:dark_prismarine
setblock 224 213 307 minecraft:prismarine
fill 224 213 308 226 213 308 minecraft:dark_prismarine
setblock 224 213 311 minecraft:prismarine
setblock 224 213 312 minecraft:dark_prismarine
setblock 224 213 315 minecraft:prismarine
fill 224 213 316 226 213 316 minecraft:dark_prismarine
setblock 225 213 282 minecraft:prismarine
fill 225 213 283 225 213 285 minecraft:dark_prismarine
setblock 225 213 286 minecraft:prismarine
fill 225 213 287 225 213 289 minecraft:dark_prismarine
setblock 225 213 290 minecraft:prismarine
fill 225 213 291 227 213 291 minecraft:dark_prismarine
setblock 225 213 294 minecraft:prismarine
setblock 225 213 295 minecraft:dark_prismarine
setblock 225 213 298 minecraft:prismarine
fill 225 213 299 225 213 301 minecraft:dark_prismarine
setblock 225 213 302 minecraft:prismarine
fill 225 213 303 227 213 303 minecraft:dark_prismarine
setblock 225 213 306 minecraft:prismarine
fill 225 213 307 227 213 307 minecraft:dark_prismarine
setblock 225 213 310 minecraft:prismarine
fill 225 213 311 227 213 311 minecraft:dark_prismarine
fill 225 213 315 227 213 315 minecraft:dark_prismarine
setblock 226 213 277 minecraft:prismarine
setblock 226 213 281 minecraft:prismarine
fill 226 213 282 226 213 284 minecraft:dark_prismarine
setblock 226 213 285 minecraft:prismarine
fill 226 213 286 226 213 288 minecraft:dark_prismarine
setblock 226 213 289 minecraft:prismarine
fill 226 213 290 228 213 290 minecraft:dark_prismarine
setblock 226 213 293 minecraft:prismarine
fill 226 213 294 228 213 294 minecraft:dark_prismarine
fill 226 213 298 226 213 300 minecraft:dark_prismarine
setblock 226 213 301 minecraft:prismarine
fill 226 213 302 228 213 302 minecraft:dark_prismarine
setblock 226 213 305 minecraft:prismarine
fill 226 213 306 228 213 306 minecraft:dark_prismarine
setblock 226 213 309 minecraft:prismarine
fill 226 213 310 228 213 310 minecraft:dark_prismarine
setblock 227 213 276 minecraft:prismarine
fill 227 213 277 229 213 277 minecraft:dark_prismarine
fill 227 213 281 227 213 283 minecraft:dark_prismarine
setblock 227 213 284 minecraft:prismarine
fill 227 213 285 227 213 287 minecraft:dark_prismarine
setblock 227 213 288 minecraft:prismarine
fill 227 213 289 229 213 289 minecraft:dark_prismarine
setblock 227 213 292 minecraft:prismarine
fill 227 213 293 229 213 293 minecraft:dark_prismarine
fill 227 213 298 227 213 299 minecraft:dark_prismarine
setblock 227 213 300 minecraft:prismarine
fill 227 213 301 229 213 301 minecraft:dark_prismarine
setblock 227 213 304 minecraft:prismarine
fill 227 213 305 229 213 305 minecraft:dark_prismarine
setblock 227 213 308 minecraft:prismarine
fill 227 213 309 229 213 309 minecraft:dark_prismarine
setblock 227 213 316 minecraft:prismarine
fill 228 213 276 229 213 276 minecraft:dark_prismarine
setblock 228 213 278 minecraft:dark_prismarine
setblock 228 213 279 minecraft:prismarine
fill 228 213 280 228 213 282 minecraft:dark_prismarine
setblock 228 213 283 minecraft:prismarine
fill 228 213 284 228 213 286 minecraft:dark_prismarine
setblock 228 213 287 minecraft:prismarine
fill 228 213 288 229 213 288 minecraft:dark_prismarine
setblock 228 213 291 minecraft:prismarine
fill 228 213 292 229 213 292 minecraft:dark_prismarine
setblock 228 213 298 minecraft:dark_prismarine
setblock 228 213 299 minecraft:prismarine
fill 228 213 300 229 213 300 minecraft:dark_prismarine
setblock 228 213 303 minecraft:prismarine
fill 228 213 304 229 213 304 minecraft:dark_prismarine
setblock 228 213 307 minecraft:prismarine
fill 228 213 308 229 213 308 minecraft:dark_prismarine
setblock 228 213 311 minecraft:prismarine
fill 228 213 312 228 213 314 minecraft:dark_prismarine
setblock 228 213 315 minecraft:prismarine
fill 228 213 316 229 213 316 minecraft:dark_prismarine
setblock 229 213 278 minecraft:prismarine
fill 229 213 279 229 213 281 minecraft:dark_prismarine
setblock 229 213 282 minecraft:prismarine
fill 229 213 283 229 213 285 minecraft:dark_prismarine
setblock 229 213 286 minecraft:prismarine
setblock 229 213 287 minecraft:dark_prismarine
setblock 229 213 290 minecraft:prismarine
setblock 229 213 291 minecraft:dark_prismarine
setblock 229 213 294 minecraft:prismarine
fill 229 213 295 229 213 297 minecraft:dark_prismarine
setblock 229 213 298 minecraft:prismarine
setblock 229 213 299 minecraft:dark_prismarine
setblock 229 213 302 minecraft:prismarine
setblock 229 213 303 minecraft:dark_prismarine
setblock 229 213 306 minecraft:prismarine
setblock 229 213 307 minecraft:dark_prismarine
setblock 229 213 310 minecraft:prismarine
fill 229 213 311 229 213 313 minecraft:dark_prismarine
setblock 229 213 314 minecraft:prismarine
setblock 229 213 315 minecraft:dark_prismarine
fill 188 214 297 188 217 297 minecraft:prismarine_bricks
fill 188 214 298 188 216 298 minecraft:prismarine
fill 188 214 299 188 214 303 minecraft:prismarine_bricks
setblock 188 214 305 minecraft:prismarine_bricks
setblock 188 214 306 minecraft:prismarine
fill 188 214 307 188 217 308 minecraft:prismarine_bricks
fill 190 214 295 191 230 297 minecraft:quartz_pillar
setblock 191 214 286 minecraft:light[level=15]
setblock 191 214 294 minecraft:light[level=15]
setblock 191 214 302 minecraft:light[level=15]
setblock 191 214 310 minecraft:light[level=15]
fill 192 214 285 200 215 309 minecraft:prismarine_bricks
setblock 196 214 317 minecraft:prismarine
setblock 199 214 275 minecraft:prismarine
setblock 199 214 278 minecraft:light[level=15]
setblock 199 214 310 minecraft:light[level=15]
setblock 201 214 275 minecraft:prismarine
fill 201 214 285 201 214 295 minecraft:prismarine_bricks
fill 201 214 299 201 214 309 minecraft:prismarine_bricks
fill 202 214 285 202 214 294 minecraft:prismarine_bricks
fill 202 214 300 202 214 309 minecraft:prismarine_bricks
fill 203 214 285 216 215 293 minecraft:prismarine_bricks
fill 203 214 301 216 215 309 minecraft:prismarine_bricks
setblock 204 214 310 minecraft:gold_block
setblock 206 214 275 minecraft:prismarine
fill 206 214 294 216 214 294 minecraft:prismarine_bricks
fill 206 214 300 216 214 300 minecraft:prismarine_bricks
setblock 207 214 278 minecraft:light[level=15]
fill 207 214 295 216 214 295 minecraft:prismarine_bricks
fill 207 214 299 216 214 299 minecraft:prismarine_bricks
setblock 207 214 310 minecraft:light[level=15]
fill 208 214 296 216 215 298 minecraft:prismarine_bricks
setblock 211 214 317 minecraft:sea_lantern
fill 212 214 317 213 214 317 minecraft:prismarine_bricks
setblock 214 214 317 minecraft:prismarine
fill 215 214 275 215 215 275 minecraft:prismarine
setblock 215 214 278 minecraft:light[level=15]
setblock 215 214 310 minecraft:light[level=15]
fill 215 214 317 215 217 317 minecraft:prismarine_bricks
fill 219 214 275 220 214 275 minecraft:prismarine
fill 221 214 275 221 217 275 minecraft:prismarine_bricks
setblock 222 214 275 minecraft:prismarine
setblock 223 214 278 minecraft:light[level=15]
setblock 223 214 286 minecraft:light[level=15]
setblock 223 214 294 minecraft:light[level=15]
setblock 223 214 302 minecraft:light[level=15]
setblock 223 214 310 minecraft:light[level=15]
setblock 228 214 317 minecraft:prismarine
fill 230 214 276 230 217 276 minecraft:prismarine_bricks
setblock 230 214 277 minecraft:prismarine
fill 230 214 278 230 214 279 minecraft:prismarine_bricks
setblock 230 214 285 minecraft:prismarine
fill 230 214 292 230 214 293 minecraft:prismarine
setblock 230 214 296 minecraft:prismarine
fill 230 214 308 230 214 309 minecraft:prismarine
setblock 230 214 317 minecraft:prismarine
fill 188 215 299 188 215 301 minecraft:prismarine_bricks
setblock 188 215 302 minecraft:prismarine
fill 188 215 303 188 217 303 minecraft:prismarine_bricks
setblock 188 215 305 minecraft:prismarine
setblock 188 215 306 minecraft:prismarine_bricks
setblock 188 215 313 minecraft:prismarine
fill 188 215 314 188 217 314 minecraft:prismarine_bricks
setblock 188 215 315 minecraft:prismarine
fill 188 215 316 188 217 317 minecraft:prismarine_bricks
fill 189 215 317 189 217 317 minecraft:prismarine_bricks
setblock 190 215 317 minecraft:prismarine
fill 191 215 317 193 217 317 minecraft:prismarine_bricks
setblock 193 215 275 minecraft:prismarine
setblock 194 215 317 minecraft:prismarine
fill 196 215 317 196 217 317 minecraft:prismarine_bricks
fill 199 215 275 199 217 275 minecraft:prismarine_bricks
fill 201 215 275 201 219 275 minecraft:prismarine_bricks
fill 201 215 285 201 215 294 minecraft:prismarine_bricks
fill 201 215 300 201 215 309 minecraft:prismarine_bricks
fill 202 215 285 202 215 293 minecraft:prismarine_bricks
fill 202 215 301 202 215 309 minecraft:prismarine_bricks
fill 206 215 275 206 217 275 minecraft:prismarine_bricks
fill 207 215 294 216 215 294 minecraft:prismarine_bricks
fill 207 215 300 216 215 300 minecraft:prismarine_bricks
fill 208 215 295 216 215 295 minecraft:prismarine_bricks
fill 208 215 299 216 215 299 minecraft:prismarine_bricks
fill 211 215 317 211 217 317 minecraft:prismarine_bricks
setblock 212 215 317 minecraft:prismarine
fill 213 215 317 214 217 317 minecraft:prismarine_bricks
setblock 216 215 275 minecraft:prismarine
setblock 219 215 275 minecraft:prismarine
fill 220 215 275 220 217 275 minecraft:prismarine_bricks
fill 222 215 275 222 217 275 minecraft:prismarine_bricks
fill 228 215 317 228 217 317 minecraft:prismarine_bricks
setblock 229 215 317 minecraft:sea_lantern
fill 230 215 277 230 217 277 minecraft:prismarine_bricks
setblock 230 215 278 minecraft:prismarine
fill 230 215 279 230 217 279 minecraft:prismarine_bricks
setblock 230 215 283 minecraft:prismarine
fill 230 215 285 230 217 285 minecraft:prismarine_bricks
fill 230 215 292 230 215 293 minecraft:prismarine_bricks
fill 230 215 296 230 217 296 minecraft:prismarine_bricks
fill 230 215 308 230 215 309 minecraft:prismarine_bricks
setblock 230 215 317 minecraft:prismarine_bricks
fill 188 216 281 188 217 282 minecraft:prismarine_bricks
setblock 188 216 283 minecraft:prismarine
fill 188 216 284 188 217 284 minecraft:prismarine_bricks
setblock 188 216 299 minecraft:sea_lantern
setblock 188 216 300 minecraft:prismarine
fill 188 216 301 188 217 302 minecraft:prismarine_bricks
setblock 188 216 304 minecraft:prismarine
fill 188 216 305 188 217 305 minecraft:prismarine_bricks
setblock 188 216 306 minecraft:prismarine
setblock 188 216 310 minecraft:prismarine
fill 188 216 313 188 217 313 minecraft:prismarine_bricks
fill 188 216 315 188 217 315 minecraft:prismarine_bricks
fill 190 216 317 190 217 317 minecraft:prismarine_bricks
setblock 192 216 275 minecraft:prismarine
fill 192 216 295 192 230 297 minecraft:quartz_pillar
fill 193 216 275 193 217 275 minecraft:prismarine_bricks
fill 193 216 286 193 217 286 minecraft:sea_lantern
fill 193 216 308 193 217 308 minecraft:sea_lantern
setblock 194 216 275 minecraft:prismarine
fill 194 216 287 200 217 307 minecraft:dark_prismarine
fill 194 216 317 194 217 317 minecraft:prismarine_bricks
setblock 200 216 275 minecraft:prismarine
setblock 200 216 317 minecraft:prismarine
fill 201 216 287 201 217 294 minecraft:dark_prismarine
fill 201 216 300 201 217 307 minecraft:dark_prismarine
setblock 201 216 317 minecraft:sea_lantern
fill 202 216 287 214 217 293 minecraft:dark_prismarine
fill 202 216 301 214 217 307 minecraft:dark_prismarine
fill 202 216 317 203 217 317 minecraft:prismarine_bricks
setblock 205 216 275 minecraft:prismarine
setblock 207 216 275 minecraft:prismarine
fill 207 216 294 214 217 294 minecraft:dark_prismarine
fill 207 216 300 214 217 300 minecraft:dark_prismarine
fill 208 216 275 208 218 275 minecraft:prismarine_bricks
fill 208 216 295 214 217 299 minecraft:dark_prismarine
fill 212 216 317 212 217 317 minecraft:prismarine_bricks
setblock 214 216 275 minecraft:prismarine
fill 215 216 275 216 217 275 minecraft:prismarine_bricks
fill 215 216 286 215 217 286 minecraft:sea_lantern
fill 215 216 308 215 217 308 minecraft:sea_lantern
fill 216 216 317 216 217 317 minecraft:prismarine_bricks
setblock 217 216 317 minecraft:prismarine
fill 219 216 275 219 217 275 minecraft:prismarine_bricks
setblock 220 216 317 minecraft:prismarine
fill 224 216 317 226 217 317 minecraft:prismarine_bricks
setblock 227 216 317 minecraft:prismarine
fill 229 216 317 229 218 317 minecraft:prismarine_bricks
setblock 230 216 275 minecraft:prismarine
fill 230 216 278 230 217 278 minecraft:prismarine_bricks
fill 230 216 283 230 217 283 minecraft:prismarine_bricks
setblock 230 216 284 minecraft:prismarine
fill 230 216 292 230 216 293 minecraft:prismarine
fill 230 216 300 230 217 302 minecraft:prismarine_bricks
setblock 230 216 303 minecraft:prismarine
fill 230 216 308 230 217 308 minecraft:prismarine_bricks
setblock 230 216 309 minecraft:prismarine
fill 230 216 312 230 216 313 minecraft:prismarine
setblock 230 216 317 minecraft:prismarine
setblock 188 217 283 minecraft:prismarine_bricks
fill 188 217 298 189 217 300 minecraft:prismarine_bricks
setblock 188 217 304 minecraft:prismarine_bricks
fill 188 217 306 188 218 306 minecraft:prismarine_bricks
fill 188 217 310 189 217 310 minecraft:prismarine_bricks
fill 189 217 276 191 272 276 minecraft:prismarine_bricks
fill 189 217 286 189 272 288 minecraft:prismarine_bricks
fill 189 217 311 189 272 312 minecraft:prismarine_bricks
setblock 192 217 275 minecraft:prismarine_bricks
fill 192 217 311 194 217 311 minecraft:dark_prismarine
fill 192 217 315 194 217 315 minecraft:dark_prismarine
setblock 194 217 275 minecraft:prismarine_bricks
fill 194 217 312 194 228 314 minecraft:prismarine_bricks
fill 195 217 312 195 217 314 minecraft:dark_prismarine
fill 195 217 316 197 272 316 minecraft:prismarine_bricks
setblock 200 217 275 minecraft:prismarine_bricks
fill 200 217 317 201 217 317 minecraft:prismarine_bricks
fill 201 217 276 203 272 276 minecraft:prismarine_bricks
fill 205 217 275 205 218 275 minecraft:prismarine_bricks
setblock 207 217 275 minecraft:prismarine_bricks
fill 207 217 316 209 272 316 minecraft:prismarine_bricks
fill 213 217 276 215 272 276 minecraft:prismarine_bricks
setblock 214 217 275 minecraft:prismarine_bricks
setblock 217 217 317 minecraft:prismarine_bricks
fill 219 217 316 221 272 316 minecraft:prismarine_bricks
setblock 220 217 317 minecraft:prismarine_bricks
fill 225 217 276 227 272 276 minecraft:prismarine_bricks
setblock 227 217 317 minecraft:prismarine_bricks
fill 229 217 284 229 272 286 minecraft:prismarine_bricks
fill 229 217 296 229 272 298 minecraft:prismarine_bricks
fill 229 217 308 229 272 310 minecraft:prismarine_bricks
setblock 230 217 275 minecraft:prismarine_bricks
setblock 230 217 284 minecraft:sea_lantern
fill 230 217 292 230 217 293 minecraft:prismarine_bricks
setblock 230 217 303 minecraft:prismarine_bricks
fill 230 217 309 230 218 309 minecraft:prismarine_bricks
fill 230 217 312 230 217 313 minecraft:prismarine_bricks
setblock 230 217 317 minecraft:prismarine_bricks
fill 188 218 275 188 218 293 minecraft:prismarine
setblock 188 218 294 minecraft:prismarine_bricks
fill 188 218 295 188 218 305 minecraft:prismarine
fill 188 218 307 188 218 315 minecraft:prismarine
setblock 188 218 316 minecraft:prismarine_bricks
fill 188 218 317 194 219 317 minecraft:prismarine
fill 189 218 275 194 222 275 minecraft:prismarine
fill 189 218 298 189 272 300 minecraft:prismarine_bricks
fill 189 218 310 189 272 310 minecraft:prismarine_bricks
setblock 191 218 285 minecraft:light[level=12]
setblock 191 218 292 minecraft:light[level=12]
setblock 191 218 299 minecraft:light[level=12]
setblock 191 218 306 minecraft:light[level=12]
fill 195 218 275 196 218 275 minecraft:prismarine_bricks
fill 196 218 289 199 219 305 minecraft:prismarine_bricks
fill 196 218 317 200 225 317 minecraft:prismarine
fill 197 218 275 200 223 275 minecraft:prismarine
setblock 198 218 278 minecraft:light[level=12]
setblock 198 218 285 minecraft:light[level=12]
setblock 198 218 306 minecraft:light[level=12]
setblock 198 218 313 minecraft:light[level=12]
fill 200 218 289 200 219 295 minecraft:prismarine_bricks
fill 200 218 299 200 219 305 minecraft:prismarine_bricks
fill 201 218 289 201 218 294 minecraft:prismarine_bricks
fill 201 218 300 201 218 305 minecraft:prismarine_bricks
setblock 201 218 317 minecraft:prismarine_bricks
fill 202 218 275 204 218 275 minecraft:prismarine
fill 202 218 289 202 219 293 minecraft:prismarine_bricks
fill 202 218 301 202 219 305 minecraft:prismarine_bricks
fill 202 218 317 207 219 317 minecraft:prismarine
fill 203 218 289 212 219 292 minecraft:prismarine_bricks
fill 203 218 302 212 219 305 minecraft:prismarine_bricks
setblock 205 218 278 minecraft:light[level=12]
setblock 205 218 285 minecraft:light[level=12]
setblock 205 218 306 minecraft:light[level=12]
setblock 205 218 313 minecraft:light[level=12]
fill 206 218 275 207 219 275 minecraft:prismarine
fill 206 218 293 212 219 293 minecraft:prismarine_bricks
fill 206 218 301 212 219 301 minecraft:prismarine_bricks
fill 207 218 294 212 218 294 minecraft:prismarine_bricks
fill 207 218 300 212 218 300 minecraft:prismarine_bricks
fill 208 218 295 212 219 295 minecraft:prismarine_bricks
fill 208 218 299 212 219 299 minecraft:prismarine_bricks
fill 209 218 275 209 225 275 minecraft:prismarine
fill 209 218 296 212 219 298 minecraft:prismarine_bricks
fill 209 218 317 213 218 317 minecraft:prismarine
fill 211 218 275 215 233 275 minecraft:prismarine
setblock 212 218 278 minecraft:light[level=12]
setblock 212 218 285 minecraft:light[level=12]
setblock 212 218 306 minecraft:light[level=12]
setblock 212 218 313 minecraft:light[level=12]
setblock 214 218 317 minecraft:prismarine_bricks
fill 215 218 317 224 225 317 minecraft:prismarine
setblock 216 218 275 minecraft:prismarine_bricks
fill 217 218 275 225 218 275 minecraft:prismarine
setblock 219 218 278 minecraft:light[level=12]
setblock 219 218 285 minecraft:light[level=12]
setblock 219 218 292 minecraft:light[level=12]
setblock 219 218 299 minecraft:light[level=12]
setblock 219 218 306 minecraft:light[level=12]
setblock 219 218 313 minecraft:light[level=12]
setblock 225 218 317 minecraft:prismarine_bricks
setblock 226 218 285 minecraft:light[level=12]
setblock 226 218 292 minecraft:light[level=12]
setblock 226 218 299 minecraft:light[level=12]
setblock 226 218 306 minecraft:light[level=12]
fill 226 218 317 228 225 317 minecraft:prismarine
fill 227 218 275 230 219 275 minecraft:prismarine
fill 230 218 276 230 218 289 minecraft:prismarine
setblock 230 218 290 minecraft:prismarine_bricks
fill 230 218 291 230 225 297 minecraft:prismarine
setblock 230 218 298 minecraft:prismarine_bricks
fill 230 218 299 230 225 300 minecraft:prismarine
setblock 230 218 301 minecraft:prismarine_bricks
fill 230 218 302 230 218 305 minecraft:prismarine
fill 230 218 307 230 219 307 minecraft:prismarine
setblock 230 218 308 minecraft:sea_lantern
fill 230 218 310 230 218 317 minecraft:prismarine
setblock 188 219 275 minecraft:prismarine_bricks
fill 188 219 276 188 219 278 minecraft:prismarine
setblock 188 219 279 minecraft:prismarine_bricks
fill 188 219 280 188 219 282 minecraft:prismarine
setblock 188 219 283 minecraft:prismarine_bricks
setblock 188 219 284 minecraft:prismarine
setblock 188 219 285 minecraft:prismarine_bricks
fill 188 219 286 188 219 300 minecraft:prismarine
setblock 188 219 301 minecraft:prismarine_bricks
fill 188 219 302 188 219 308 minecraft:prismarine
setblock 188 219 309 minecraft:prismarine_bricks
fill 188 219 310 188 221 312 minecraft:prismarine
setblock 188 219 313 minecraft:prismarine_bricks
fill 188 219 314 188 219 316 minecraft:prismarine
fill 195 219 275 196 219 275 minecraft:prismarine
fill 195 219 317 195 308 317 minecraft:prismarine
fill 201 219 289 201 219 293 minecraft:prismarine_bricks
fill 201 219 301 201 219 305 minecraft:prismarine_bricks
fill 201 219 317 201 223 317 minecraft:prismarine
fill 202 219 275 203 219 275 minecraft:prismarine
setblock 204 219 275 minecraft:prismarine_bricks
fill 205 219 275 205 308 275 minecraft:prismarine
fill 208 219 275 208 225 275 minecraft:prismarine
fill 208 219 294 212 219 294 minecraft:prismarine_bricks
fill 208 219 300 212 219 300 minecraft:prismarine_bricks
fill 209 219 317 209 220 317 minecraft:prismarine_bricks
fill 210 219 275 210 225 275 minecraft:prismarine
fill 210 219 317 211 267 317 minecraft:prismarine
fill 212 219 317 213 219 317 minecraft:prismarine_bricks
fill 214 219 317 214 225 317 minecraft:prismarine
fill 216 219 275 218 219 275 minecraft:prismarine
setblock 219 219 275 minecraft:prismarine_bricks
fill 220 219 275 226 219 275 minecraft:prismarine
setblock 225 219 317 minecraft:prismarine
fill 229 219 317 230 308 317 minecraft:prismarine
fill 230 219 276 230 225 277 minecraft:prismarine
setblock 230 219 278 minecraft:prismarine_bricks
fill 230 219 279 230 221 290 minecraft:prismarine
fill 230 219 298 230 232 298 minecraft:prismarine
fill 230 219 301 230 225 304 minecraft:prismarine
setblock 230 219 305 minecraft:prismarine_bricks
fill 230 219 306 230 226 306 minecraft:prismarine
fill 230 219 308 230 234 310 minecraft:prismarine
setblock 230 219 311 minecraft:prismarine_bricks
fill 230 219 312 230 219 316 minecraft:prismarine
fill 188 220 275 188 231 276 minecraft:prismarine
setblock 188 220 277 minecraft:prismarine_bricks
fill 188 220 278 188 308 279 minecraft:prismarine
setblock 188 220 280 minecraft:prismarine_bricks
fill 188 220 281 188 220 283 minecraft:prismarine
setblock 188 220 284 minecraft:prismarine_bricks
fill 188 220 285 188 225 298 minecraft:prismarine
setblock 188 220 299 minecraft:prismarine_bricks
fill 188 220 300 188 225 305 minecraft:prismarine
fill 188 220 306 188 220 307 minecraft:prismarine_bricks
fill 188 220 308 188 225 309 minecraft:prismarine
fill 188 220 313 188 308 315 minecraft:prismarine
setblock 188 220 316 minecraft:prismarine_bricks
fill 188 220 317 189 225 317 minecraft:prismarine
fill 190 220 285 190 225 287 minecraft:prismarine_bricks
fill 190 220 298 190 225 299 minecraft:prismarine_bricks
fill 190 220 309 190 225 311 minecraft:prismarine_bricks
setblock 190 220 317 minecraft:prismarine_bricks
fill 191 220 317 191 225 317 minecraft:prismarine
setblock 192 220 317 minecraft:prismarine_bricks
fill 193 220 317 194 234 317 minecraft:prismarine
setblock 195 220 275 minecraft:prismarine_bricks
fill 196 220 275 196 225 275 minecraft:prismarine
fill 196 220 315 198 225 315 minecraft:prismarine_bricks
fill 198 220 291 199 221 303 minecraft:dark_prismarine
fill 200 220 277 202 225 277 minecraft:prismarine_bricks
fill 200 220 291 200 220 295 minecraft:dark_prismarine
fill 200 220 299 200 220 303 minecraft:dark_prismarine
fill 201 220 275 201 302 275 minecraft:prismarine
fill 201 220 291 202 220 293 minecraft:dark_prismarine
fill 201 220 301 202 220 303 minecraft:dark_prismarine
setblock 202 220 275 minecraft:prismarine_bricks
fill 202 220 317 202 225 317 minecraft:prismarine
fill 203 220 275 204 230 275 minecraft:prismarine
fill 203 220 291 210 221 292 minecraft:dark_prismarine
fill 203 220 302 210 221 303 minecraft:dark_prismarine
fill 203 220 317 204 220 317 minecraft:prismarine_bricks
fill 205 220 317 208 224 317 minecraft:prismarine
fill 206 220 275 206 227 275 minecraft:prismarine
fill 206 220 293 210 220 293 minecraft:dark_prismarine
fill 206 220 301 210 220 301 minecraft:dark_prismarine
setblock 207 220 275 minecraft:prismarine_bricks
fill 208 220 294 210 220 295 minecraft:dark_prismarine
fill 208 220 299 210 220 300 minecraft:dark_prismarine
fill 209 220 296 210 221 298 minecraft:dark_prismarine
fill 212 220 277 214 225 277 minecraft:prismarine_bricks
setblock 212 220 317 minecraft:prismarine
setblock 213 220 317 minecraft:prismarine_bricks
fill 216 220 275 216 221 275 minecraft:prismarine_bricks
fill 217 220 275 223 225 275 minecraft:prismarine
fill 220 220 315 222 225 315 minecraft:prismarine_bricks
setblock 224 220 275 minecraft:prismarine_bricks
fill 224 220 277 226 225 277 minecraft:prismarine_bricks
fill 225 220 275 229 240 275 minecraft:prismarine
setblock 225 220 317 minecraft:prismarine_bricks
fill 228 220 285 228 225 287 minecraft:prismarine_bricks
fill 228 220 298 228 225 299 minecraft:prismarine_bricks
fill 228 220 309 228 225 311 minecraft:prismarine_bricks
setblock 230 220 275 minecraft:prismarine_bricks
fill 230 220 278 230 225 278 minecraft:prismarine
fill 230 220 305 230 221 305 minecraft:prismarine
setblock 230 220 307 minecraft:sea_lantern
fill 230 220 311 230 225 315 minecraft:prismarine
setblock 230 220 316 minecraft:prismarine_bricks
fill 188 221 277 188 253 277 minecraft:prismarine
fill 188 221 280 188 225 282 minecraft:prismarine
setblock 188 221 283 minecraft:prismarine_bricks
fill 188 221 284 188 225 284 minecraft:prismarine
fill 188 221 299 188 230 299 minecraft:prismarine
fill 188 221 306 188 225 307 minecraft:prismarine
fill 188 221 316 188 247 316 minecraft:prismarine
fill 190 221 317 190 225 317 minecraft:prismarine
fill 192 221 317 192 308 317 minecraft:prismarine
fill 195 221 275 195 225 275 minecraft:prismarine
fill 196 221 294 196 222 294 minecraft:light_blue_stained_glass
fill 200 221 291 200 221 294 minecraft:dark_prismarine
fill 200 221 300 200 221 303 minecraft:dark_prismarine
fill 201 221 291 201 221 293 minecraft:dark_prismarine
fill 201 221 301 201 221 303 minecraft:dark_prismarine
fill 202 221 275 202 257 275 minecraft:prismarine
fill 202 221 291 202 221 292 minecraft:dark_prismarine
fill 202 221 302 202 221 303 minecraft:dark_prismarine
fill 203 221 317 204 225 317 minecraft:prismarine
fill 207 221 275 207 225 275 minecraft:prismarine
fill 207 221 293 210 221 293 minecraft:dark_prismarine
fill 207 221 301 210 221 301 minecraft:dark_prismarine
fill 208 221 294 210 221 294 minecraft:dark_prismarine
fill 208 221 300 210 221 300 minecraft:dark_prismarine
fill 209 221 295 210 221 295 minecraft:dark_prismarine
fill 209 221 299 210 221 299 minecraft:dark_prismarine
fill 209 221 317 209 265 317 minecraft:prismarine
setblock 212 221 317 minecraft:sea_lantern
fill 213 221 317 213 225 317 minecraft:prismarine
fill 224 221 275 224 308 275 minecraft:prismarine
fill 225 221 317 225 225 317 minecraft:prismarine
fill 230 221 275 230 308 275 minecraft:prismarine
fill 230 221 307 230 227 307 minecraft:prismarine
fill 230 221 316 230 308 316 minecraft:prismarine
fill 188 222 283 188 225 283 minecraft:prismarine
setblock 188 222 310 minecraft:prismarine_bricks
fill 188 222 311 188 237 312 minecraft:prismarine
setblock 191 222 286 minecraft:light[level=15]
setblock 191 222 294 minecraft:light[level=15]
setblock 191 222 302 minecraft:light[level=15]
setblock 191 222 310 minecraft:light[level=15]
fill 193 222 294 193 223 294 minecraft:dark_prismarine
setblock 199 222 278 minecraft:light[level=15]
setblock 199 222 286 minecraft:light[level=15]
setblock 199 222 294 minecraft:light[level=15]
setblock 199 222 302 minecraft:light[level=15]
setblock 199 222 310 minecraft:light[level=15]
fill 200 222 293 200 223 294 minecraft:prismarine_bricks
fill 200 222 300 200 223 301 minecraft:prismarine_bricks
fill 200 222 311 200 223 311 minecraft:dark_prismarine
fill 201 222 293 201 223 293 minecraft:prismarine_bricks
fill 201 222 301 201 223 301 minecraft:prismarine_bricks
fill 206 222 311 206 223 311 minecraft:dark_prismarine
setblock 207 222 278 minecraft:light[level=15]
setblock 207 222 286 minecraft:light[level=15]
fill 207 222 293 208 223 293 minecraft:prismarine_bricks
fill 207 222 301 208 223 301 minecraft:prismarine_bricks
setblock 207 222 302 minecraft:light[level=15]
setblock 207 222 310 minecraft:light[level=15]
fill 208 222 294 208 223 294 minecraft:prismarine_bricks
fill 208 222 300 208 223 300 minecraft:prismarine_bricks
fill 210 222 280 210 223 280 minecraft:dark_prismarine
fill 212 222 317 212 225 317 minecraft:prismarine
setblock 215 222 278 minecraft:light[level=15]
setblock 215 222 286 minecraft:light[level=15]
setblock 215 222 294 minecraft:light[level=15]
setblock 215 222 302 minecraft:light[level=15]
setblock 215 222 310 minecraft:light[level=15]
fill 216 222 275 216 239 275 minecraft:prismarine
setblock 223 222 278 minecraft:light[level=15]
setblock 223 222 286 minecraft:light[level=15]
setblock 223 222 294 minecraft:light[level=15]
setblock 223 222 302 minecraft:light[level=15]
setblock 223 222 310 minecraft:light[level=15]
fill 230 222 279 230 225 280 minecraft:prismarine
setblock 230 222 281 minecraft:sea_lantern
fill 230 222 282 230 225 290 minecraft:prismarine
setblock 230 222 305 minecraft:prismarine_bricks
fill 188 223 310 188 256 310 minecraft:prismarine
fill 189 223 275 192 264 275 minecraft:prismarine
fill 192 223 294 192 224 294 minecraft:dark_prismarine
setblock 193 223 275 minecraft:prismarine_bricks
fill 194 223 275 194 308 275 minecraft:prismarine
fill 200 223 312 200 224 312 minecraft:dark_prismarine
fill 206 223 312 206 224 312 minecraft:dark_prismarine
fill 230 223 281 230 246 281 minecraft:prismarine
fill 230 223 305 230 247 305 minecraft:prismarine
setblock 191 224 285 minecraft:light[level=12]
setblock 191 224 292 minecraft:light[level=12]
fill 191 224 294 191 225 294 minecraft:dark_prismarine
setblock 191 224 299 minecraft:light[level=12]
setblock 191 224 306 minecraft:light[level=12]
fill 193 224 275 193 285 275 minecraft:prismarine
setblock 197 224 275 minecraft:sea_lantern
fill 198 224 275 200 225 275 minecraft:prismarine
setblock 198 224 278 minecraft:light[level=12]
setblock 198 224 285 minecraft:light[level=12]
setblock 198 224 292 minecraft:light[level=12]
setblock 198 224 299 minecraft:light[level=12]
setblock 198 224 306 minecraft:light[level=12]
setblock 198 224 313 minecraft:light[level=12]
fill 200 224 313 200 225 313 minecraft:dark_prismarine
setblock 201 224 317 minecraft:sea_lantern
setblock 205 224 278 minecraft:light[level=12]
setblock 205 224 285 minecraft:light[level=12]
setblock 205 224 292 minecraft:light[level=12]
setblock 205 224 306 minecraft:light[level=12]
setblock 205 224 313 minecraft:light[level=12]
fill 206 224 313 206 225 313 minecraft:dark_prismarine
fill 207 224 286 208 225 286 minecraft:white_stained_glass
setblock 212 224 278 minecraft:light[level=12]
setblock 212 224 285 minecraft:light[level=12]
setblock 212 224 292 minecraft:light[level=12]
setblock 212 224 299 minecraft:light[level=12]
setblock 212 224 306 minecraft:light[level=12]
setblock 212 224 313 minecraft:light[level=12]
setblock 219 224 278 minecraft:light[level=12]
setblock 219 224 285 minecraft:light[level=12]
setblock 219 224 292 minecraft:light[level=12]
setblock 219 224 299 minecraft:light[level=12]
setblock 219 224 306 minecraft:light[level=12]
setblock 219 224 313 minecraft:light[level=12]
fill 220 224 298 220 225 298 minecraft:sea_lantern
setblock 226 224 285 minecraft:light[level=12]
setblock 226 224 292 minecraft:light[level=12]
setblock 226 224 299 minecraft:light[level=12]
setblock 226 224 306 minecraft:light[level=12]
fill 189 225 279 189 225 284 minecraft:dark_prismarine
fill 189 225 291 189 225 296 minecraft:dark_prismarine
fill 189 225 303 189 225 308 minecraft:dark_prismarine
fill 189 225 315 189 225 316 minecraft:dark_prismarine
fill 190 225 294 190 226 294 minecraft:dark_prismarine
fill 190 225 316 193 225 316 minecraft:dark_prismarine
fill 192 225 311 194 225 311 minecraft:dark_prismarine
fill 192 225 315 194 225 315 minecraft:dark_prismarine
fill 193 225 276 198 225 276 minecraft:dark_prismarine
fill 195 225 312 195 225 314 minecraft:dark_prismarine
setblock 197 225 275 minecraft:prismarine
fill 200 225 314 200 226 314 minecraft:dark_prismarine
fill 200 225 316 205 225 316 minecraft:dark_prismarine
setblock 201 225 317 minecraft:prismarine
fill 205 225 276 210 225 276 minecraft:dark_prismarine
fill 205 225 317 207 229 317 minecraft:prismarine
fill 206 225 314 206 226 314 minecraft:dark_prismarine
setblock 208 225 317 minecraft:sea_lantern
fill 212 225 316 217 225 316 minecraft:dark_prismarine
fill 217 225 276 222 225 276 minecraft:dark_prismarine
fill 224 225 316 229 225 316 minecraft:dark_prismarine
fill 229 225 276 229 225 281 minecraft:dark_prismarine
fill 229 225 288 229 225 293 minecraft:dark_prismarine
fill 229 225 300 229 225 305 minecraft:dark_prismarine
fill 229 225 312 229 225 315 minecraft:dark_prismarine
fill 188 226 280 188 308 280 minecraft:prismarine
fill 188 226 281 188 231 284 minecraft:sea_lantern
fill 188 226 285 188 291 285 minecraft:prismarine
setblock 188 226 286 minecraft:sea_lantern
fill 188 226 287 188 240 292 minecraft:prismarine
fill 188 226 293 188 231 296 minecraft:sea_lantern
fill 188 226 297 188 258 298 minecraft:prismarine
fill 188 226 300 188 229 304 minecraft:prismarine
fill 188 226 305 188 231 308 minecraft:sea_lantern
fill 188 226 309 188 243 309 minecraft:prismarine
fill 188 226 317 191 231 317 minecraft:sea_lantern
fill 189 226 294 189 227 294 minecraft:dark_prismarine
fill 195 226 275 198 231 275 minecraft:sea_lantern
fill 196 226 317 199 272 317 minecraft:prismarine
fill 199 226 275 200 266 275 minecraft:prismarine
fill 200 226 315 200 227 315 minecraft:dark_prismarine
fill 200 226 317 203 231 317 minecraft:sea_lantern
fill 204 226 317 204 282 317 minecraft:prismarine
fill 206 226 315 206 227 315 minecraft:dark_prismarine
fill 207 226 275 210 231 275 minecraft:sea_lantern
fill 208 226 317 208 308 317 minecraft:prismarine
fill 210 226 276 210 227 276 minecraft:dark_prismarine
fill 212 226 317 215 231 317 minecraft:sea_lantern
fill 216 226 317 223 236 317 minecraft:prismarine
fill 217 226 275 218 231 275 minecraft:prismarine
fill 219 226 275 222 231 275 minecraft:sea_lantern
fill 220 226 298 220 232 298 minecraft:dark_prismarine
fill 223 226 275 223 308 275 minecraft:prismarine
fill 224 226 317 227 231 317 minecraft:sea_lantern
fill 228 226 317 228 308 317 minecraft:prismarine
fill 230 226 276 230 231 279 minecraft:sea_lantern
fill 230 226 280 230 308 280 minecraft:prismarine
fill 230 226 282 230 257 287 minecraft:prismarine
fill 230 226 288 230 231 291 minecraft:sea_lantern
fill 230 226 292 230 232 297 minecraft:prismarine
fill 230 226 299 230 247 299 minecraft:prismarine
fill 230 226 300 230 231 303 minecraft:sea_lantern
fill 230 226 304 230 233 304 minecraft:prismarine
fill 230 226 311 230 308 311 minecraft:prismarine
fill 230 226 312 230 231 315 minecraft:sea_lantern
fill 188 227 286 188 247 286 minecraft:prismarine
setblock 193 227 282 minecraft:sea_lantern
setblock 193 227 288 minecraft:sea_lantern
setblock 193 227 294 minecraft:sea_lantern
setblock 193 227 300 minecraft:sea_lantern
setblock 193 227 306 minecraft:sea_lantern
setblock 195 227 280 minecraft:sea_lantern
setblock 199 227 312 minecraft:sea_lantern
setblock 201 227 280 minecraft:sea_lantern
setblock 205 227 312 minecraft:sea_lantern
setblock 207 227 280 minecraft:sea_lantern
setblock 211 227 312 minecraft:sea_lantern
setblock 213 227 280 minecraft:sea_lantern
setblock 217 227 312 minecraft:sea_lantern
setblock 219 227 280 minecraft:sea_lantern
fill 219 227 298 219 232 298 minecraft:dark_prismarine
fill 220 227 299 220 232 299 minecraft:dark_prismarine
setblock 223 227 312 minecraft:sea_lantern
setblock 225 227 286 minecraft:sea_lantern
setblock 225 227 292 minecraft:sea_lantern
setblock 225 227 298 minecraft:sea_lantern
setblock 225 227 304 minecraft:sea_lantern
setblock 225 227 310 minecraft:sea_lantern
setblock 230 227 306 minecraft:prismarine_bricks
fill 189 228 277 190 228 285 minecraft:prismarine_bricks
fill 189 228 289 189 228 297 minecraft:prismarine_bricks
fill 189 228 301 193 228 309 minecraft:prismarine_bricks
fill 189 228 313 190 228 316 minecraft:prismarine_bricks
fill 190 228 286 193 228 294 minecraft:prismarine_bricks
fill 190 228 298 193 228 300 minecraft:prismarine_bricks
fill 190 228 310 190 228 312 minecraft:prismarine_bricks
fill 191 228 277 207 228 277 minecraft:prismarine_bricks
fill 191 228 281 193 228 285 minecraft:prismarine_bricks
fill 191 228 310 193 228 311 minecraft:prismarine_bricks
fill 191 228 315 194 228 316 minecraft:prismarine_bricks
fill 192 228 276 200 228 276 minecraft:prismarine_bricks
fill 193 228 295 193 228 297 minecraft:prismarine_bricks
fill 194 228 278 207 228 280 minecraft:prismarine_bricks
fill 195 228 312 207 228 315 minecraft:prismarine_bricks
fill 198 228 316 206 228 316 minecraft:prismarine_bricks
fill 204 228 276 212 228 276 minecraft:prismarine_bricks
setblock 206 228 275 minecraft:prismarine_bricks
fill 208 228 280 224 228 280 minecraft:prismarine_bricks
fill 208 228 312 224 228 312 minecraft:prismarine_bricks
fill 210 228 316 218 228 316 minecraft:prismarine_bricks
fill 211 228 277 224 228 279 minecraft:prismarine_bricks
fill 211 228 313 224 228 315 minecraft:prismarine_bricks
fill 216 228 276 224 228 276 minecraft:prismarine_bricks
fill 219 228 299 219 232 299 minecraft:dark_prismarine
fill 220 228 297 220 232 297 minecraft:dark_prismarine
fill 222 228 316 229 228 316 minecraft:prismarine_bricks
fill 225 228 277 229 228 277 minecraft:prismarine_bricks
fill 225 228 281 225 228 311 minecraft:prismarine_bricks
fill 225 228 315 229 228 315 minecraft:prismarine_bricks
fill 226 228 281 228 228 294 minecraft:prismarine_bricks
fill 226 228 298 228 228 311 minecraft:prismarine_bricks
fill 228 228 276 229 228 276 minecraft:prismarine_bricks
fill 228 228 278 229 228 280 minecraft:prismarine_bricks
fill 228 228 312 229 228 314 minecraft:prismarine_bricks
fill 229 228 281 229 228 283 minecraft:prismarine_bricks
fill 229 228 287 229 228 295 minecraft:prismarine_bricks
fill 229 228 299 229 228 307 minecraft:prismarine_bricks
setblock 229 228 311 minecraft:prismarine_bricks
fill 230 228 306 230 285 306 minecraft:prismarine
setblock 230 228 307 minecraft:sea_lantern
fill 193 229 281 193 229 311 minecraft:gold_block
fill 194 229 280 224 229 280 minecraft:gold_block
fill 194 229 312 224 229 312 minecraft:gold_block
fill 194 229 313 194 272 314 minecraft:prismarine_bricks
fill 206 229 275 206 232 275 minecraft:prismarine
setblock 211 229 278 minecraft:light_blue_stained_glass
fill 218 229 298 218 232 299 minecraft:dark_prismarine
fill 219 229 297 219 232 297 minecraft:dark_prismarine
fill 220 229 300 220 232 300 minecraft:dark_prismarine
fill 221 229 298 221 232 299 minecraft:dark_prismarine
fill 225 229 281 225 229 311 minecraft:gold_block
fill 230 229 307 230 301 307 minecraft:prismarine
fill 188 230 300 188 254 301 minecraft:prismarine
setblock 188 230 302 minecraft:prismarine_bricks
fill 188 230 303 188 257 304 minecraft:prismarine
fill 189 230 297 189 231 297 minecraft:prismarine_bricks
setblock 191 230 285 minecraft:light[level=12]
setblock 191 230 286 minecraft:light[level=15]
setblock 191 230 292 minecraft:light[level=12]
setblock 191 230 294 minecraft:light[level=15]
setblock 191 230 299 minecraft:light[level=12]
setblock 191 230 302 minecraft:light[level=15]
setblock 191 230 306 minecraft:light[level=12]
setblock 191 230 310 minecraft:light[level=15]
fill 194 230 312 194 272 312 minecraft:prismarine_bricks
setblock 198 230 278 minecraft:light[level=12]
setblock 198 230 285 minecraft:light[level=12]
setblock 198 230 292 minecraft:light[level=12]
setblock 198 230 299 minecraft:light[level=12]
setblock 198 230 306 minecraft:light[level=12]
setblock 198 230 313 minecraft:light[level=12]
setblock 199 230 278 minecraft:light[level=15]
setblock 199 230 286 minecraft:light[level=15]
setblock 199 230 294 minecraft:light[level=15]
setblock 199 230 302 minecraft:light[level=15]
setblock 199 230 310 minecraft:light[level=15]
setblock 205 230 278 minecraft:light[level=12]
setblock 205 230 285 minecraft:light[level=12]
setblock 205 230 292 minecraft:light[level=12]
setblock 205 230 299 minecraft:light[level=12]
setblock 205 230 306 minecraft:light[level=12]
setblock 205 230 313 minecraft:light[level=12]
fill 205 230 317 206 257 317 minecraft:prismarine
setblock 207 230 278 minecraft:light[level=15]
setblock 207 230 286 minecraft:light[level=15]
setblock 207 230 294 minecraft:light[level=15]
setblock 207 230 302 minecraft:light[level=15]
setblock 207 230 310 minecraft:light[level=15]
setblock 207 230 317 minecraft:sea_lantern
setblock 212 230 278 minecraft:light[level=12]
setblock 212 230 285 minecraft:light[level=12]
setblock 212 230 292 minecraft:light[level=12]
setblock 212 230 299 minecraft:light[level=12]
setblock 212 230 306 minecraft:light[level=12]
setblock 212 230 313 minecraft:light[level=12]
setblock 215 230 278 minecraft:light[level=15]
setblock 215 230 286 minecraft:light[level=15]
setblock 215 230 294 minecraft:light[level=15]
setblock 215 230 302 minecraft:light[level=15]
setblock 215 230 310 minecraft:light[level=15]
fill 216 230 307 217 231 308 minecraft:white_stained_glass
fill 218 230 297 218 232 297 minecraft:dark_prismarine
setblock 219 230 278 minecraft:light[level=12]
setblock 219 230 285 minecraft:light[level=12]
setblock 219 230 292 minecraft:light[level=12]
fill 219 230 300 219 232 300 minecraft:dark_prismarine
setblock 219 230 306 minecraft:light[level=12]
setblock 219 230 313 minecraft:light[level=12]
fill 221 230 297 221 232 297 minecraft:dark_prismarine
fill 221 230 300 221 232 300 minecraft:dark_prismarine
setblock 223 230 278 minecraft:light[level=15]
setblock 223 230 286 minecraft:light[level=15]
setblock 223 230 294 minecraft:light[level=15]
setblock 223 230 302 minecraft:light[level=15]
setblock 223 230 310 minecraft:light[level=15]
setblock 226 230 285 minecraft:light[level=12]
setblock 226 230 292 minecraft:light[level=12]
setblock 226 230 299 minecraft:light[level=12]
setblock 226 230 306 minecraft:light[level=12]
fill 228 230 298 228 231 299 minecraft:prismarine_bricks
fill 229 230 299 229 231 299 minecraft:prismarine_bricks
setblock 188 231 299 minecraft:sea_lantern
fill 188 231 302 188 244 302 minecraft:prismarine
fill 189 231 296 193 232 296 minecraft:prismarine_bricks
fill 190 231 279 194 232 279 minecraft:prismarine_bricks
fill 190 231 295 192 232 295 minecraft:prismarine_bricks
fill 190 231 297 190 232 299 minecraft:prismarine_bricks
fill 190 231 313 193 232 313 minecraft:prismarine_bricks
fill 191 231 278 193 232 278 minecraft:prismarine_bricks
fill 191 231 280 193 232 280 minecraft:prismarine_bricks
fill 191 231 294 191 232 294 minecraft:prismarine_bricks
fill 191 231 297 191 232 298 minecraft:prismarine_bricks
fill 191 231 312 193 232 312 minecraft:prismarine_bricks
fill 191 231 314 193 232 314 minecraft:prismarine_bricks
fill 192 231 277 192 232 277 minecraft:prismarine_bricks
fill 192 231 281 192 232 281 minecraft:prismarine_bricks
fill 192 231 297 192 232 297 minecraft:prismarine_bricks
fill 192 231 311 192 232 311 minecraft:prismarine_bricks
fill 192 231 315 192 232 315 minecraft:prismarine_bricks
fill 203 231 275 203 248 275 minecraft:prismarine
setblock 204 231 275 minecraft:sea_lantern
fill 207 231 278 211 232 278 minecraft:prismarine_bricks
fill 207 231 314 211 232 314 minecraft:prismarine_bricks
fill 207 231 317 207 308 317 minecraft:prismarine
fill 208 231 277 210 232 277 minecraft:prismarine_bricks
fill 208 231 279 210 232 279 minecraft:prismarine_bricks
fill 208 231 313 210 232 313 minecraft:prismarine_bricks
fill 208 231 315 210 232 315 minecraft:prismarine_bricks
fill 209 231 276 209 232 276 minecraft:prismarine_bricks
fill 209 231 280 209 232 280 minecraft:prismarine_bricks
fill 209 231 312 209 232 312 minecraft:prismarine_bricks
fill 217 231 298 217 232 298 minecraft:dark_prismarine
fill 218 231 300 218 232 300 minecraft:dark_prismarine
fill 219 231 296 221 232 296 minecraft:dark_prismarine
fill 222 231 298 222 232 299 minecraft:dark_prismarine
fill 224 231 279 228 232 279 minecraft:prismarine_bricks
fill 224 231 313 228 232 313 minecraft:prismarine_bricks
fill 225 231 278 227 232 278 minecraft:prismarine_bricks
fill 225 231 280 227 232 280 minecraft:prismarine_bricks
fill 225 231 296 228 232 296 minecraft:prismarine_bricks
fill 225 231 312 227 232 312 minecraft:prismarine_bricks
fill 225 231 314 227 232 314 minecraft:prismarine_bricks
fill 226 231 277 226 232 277 minecraft:prismarine_bricks
fill 226 231 281 226 232 281 minecraft:prismarine_bricks
fill 226 231 295 228 232 295 minecraft:prismarine_bricks
fill 226 231 297 227 232 298 minecraft:prismarine_bricks
fill 226 231 311 226 232 311 minecraft:prismarine_bricks
fill 226 231 315 226 232 315 minecraft:prismarine_bricks
fill 227 231 294 227 232 294 minecraft:prismarine_bricks
fill 227 231 299 227 232 299 minecraft:prismarine_bricks
fill 228 231 297 228 232 297 minecraft:prismarine_bricks
fill 188 232 275 188 308 275 minecraft:prismarine
setblock 188 232 276 minecraft:sea_lantern
fill 188 232 281 188 245 281 minecraft:prismarine
fill 188 232 282 188 232 283 minecraft:sea_lantern
fill 188 232 284 188 245 284 minecraft:prismarine
fill 188 232 293 188 245 293 minecraft:prismarine
fill 188 232 294 188 232 295 minecraft:sea_lantern
fill 188 232 296 188 245 296 minecraft:prismarine
fill 188 232 299 188 308 299 minecraft:prismarine
fill 188 232 305 188 245 305 minecraft:prismarine
fill 188 232 306 188 232 307 minecraft:sea_lantern
fill 188 232 308 188 245 308 minecraft:prismarine
fill 188 232 317 188 245 317 minecraft:prismarine
fill 189 232 317 190 232 317 minecraft:sea_lantern
fill 191 232 299 191 233 299 minecraft:prismarine_bricks
fill 191 232 317 191 245 317 minecraft:prismarine
fill 192 232 298 192 234 298 minecraft:prismarine_bricks
fill 195 232 275 195 245 275 minecraft:prismarine
fill 196 232 275 197 232 275 minecraft:sea_lantern
fill 198 232 275 198 245 275 minecraft:prismarine
setblock 200 232 317 minecraft:prismarine
fill 201 232 317 202 232 317 minecraft:sea_lantern
fill 203 232 317 203 245 317 minecraft:prismarine
fill 204 232 275 204 308 275 minecraft:prismarine
fill 207 232 275 207 245 275 minecraft:prismarine
fill 208 232 275 209 232 275 minecraft:sea_lantern
fill 210 232 275 210 245 275 minecraft:prismarine
fill 212 232 317 212 245 317 minecraft:prismarine
fill 213 232 277 213 239 277 minecraft:iron_block
fill 213 232 317 214 232 317 minecraft:sea_lantern
fill 215 232 317 215 245 317 minecraft:prismarine
fill 217 232 275 217 239 275 minecraft:prismarine
setblock 217 232 297 minecraft:dark_prismarine
fill 217 232 299 217 232 300 minecraft:dark_prismarine
setblock 218 232 275 minecraft:sea_lantern
setblock 218 232 296 minecraft:dark_prismarine
fill 219 232 275 219 245 275 minecraft:prismarine
fill 219 232 301 221 232 301 minecraft:dark_prismarine
fill 220 232 275 221 232 275 minecraft:sea_lantern
fill 222 232 275 222 233 275 minecraft:prismarine
setblock 222 232 297 minecraft:dark_prismarine
setblock 222 232 300 minecraft:dark_prismarine
fill 224 232 317 224 245 317 minecraft:prismarine
fill 225 232 298 225 234 298 minecraft:prismarine_bricks
fill 225 232 317 226 232 317 minecraft:sea_lantern
fill 226 232 299 226 233 299 minecraft:prismarine_bricks
fill 227 232 317 227 245 317 minecraft:prismarine
setblock 228 232 298 minecraft:prismarine_bricks
fill 230 232 276 230 245 276 minecraft:prismarine
fill 230 232 277 230 232 278 minecraft:sea_lantern
fill 230 232 279 230 245 279 minecraft:prismarine
fill 230 232 288 230 245 288 minecraft:prismarine
fill 230 232 289 230 232 290 minecraft:sea_lantern
fill 230 232 291 230 238 291 minecraft:prismarine
fill 230 232 300 230 245 300 minecraft:prismarine
fill 230 232 301 230 232 302 minecraft:sea_lantern
fill 230 232 303 230 238 303 minecraft:prismarine
fill 230 232 312 230 245 312 minecraft:prismarine
fill 230 232 313 230 232 314 minecraft:sea_lantern
fill 230 232 315 230 245 315 minecraft:prismarine
fill 188 233 276 188 251 276 minecraft:prismarine
fill 188 233 282 188 245 283 minecraft:prismarine
fill 188 233 294 188 245 295 minecraft:prismarine
fill 188 233 306 188 245 307 minecraft:prismarine
fill 189 233 317 190 245 317 minecraft:prismarine
fill 190 233 295 192 260 297 minecraft:quartz_pillar
fill 190 233 298 191 233 298 minecraft:prismarine_bricks
fill 191 233 278 193 260 280 minecraft:quartz_pillar
fill 191 233 312 193 260 314 minecraft:quartz_pillar
fill 192 233 299 193 234 299 minecraft:prismarine_bricks
fill 192 233 311 194 233 311 minecraft:dark_prismarine
fill 192 233 315 194 233 315 minecraft:dark_prismarine
fill 193 233 297 193 234 298 minecraft:prismarine_bricks
fill 195 233 312 195 233 314 minecraft:dark_prismarine
fill 196 233 275 197 245 275 minecraft:prismarine
setblock 200 233 317 minecraft:sea_lantern
fill 201 233 317 202 243 317 minecraft:prismarine
setblock 206 233 275 minecraft:sea_lantern
fill 208 233 275 209 233 275 minecraft:prismarine
fill 208 233 277 210 260 279 minecraft:quartz_pillar
fill 208 233 313 210 260 315 minecraft:quartz_pillar
fill 213 233 317 214 245 317 minecraft:prismarine
fill 218 233 275 218 308 275 minecraft:prismarine
fill 219 233 297 219 235 297 minecraft:prismarine_bricks
fill 219 233 299 219 234 299 minecraft:prismarine_bricks
fill 220 233 275 221 245 275 minecraft:prismarine
fill 221 233 299 221 237 299 minecraft:prismarine_bricks
fill 224 233 297 224 234 299 minecraft:prismarine_bricks
fill 225 233 278 227 260 280 minecraft:quartz_pillar
fill 225 233 297 225 234 297 minecraft:prismarine_bricks
fill 225 233 299 225 234 299 minecraft:prismarine_bricks
fill 225 233 312 227 260 314 minecraft:quartz_pillar
fill 225 233 317 226 242 317 minecraft:prismarine
fill 226 233 295 228 260 297 minecraft:quartz_pillar
fill 226 233 298 227 233 298 minecraft:prismarine_bricks
setblock 228 233 298 minecraft:gold_block
fill 230 233 277 230 245 278 minecraft:prismarine
fill 230 233 289 230 245 290 minecraft:prismarine
fill 230 233 292 230 274 296 minecraft:prismarine
setblock 230 233 297 minecraft:sea_lantern
setblock 230 233 298 minecraft:prismarine_bricks
fill 230 233 301 230 235 302 minecraft:prismarine
fill 230 233 313 230 245 314 minecraft:prismarine
setblock 190 234 298 minecraft:gold_block
setblock 191 234 298 minecraft:prismarine_bricks
fill 194 234 297 194 235 299 minecraft:prismarine_bricks
fill 195 234 298 195 236 298 minecraft:prismarine_bricks
fill 200 234 317 200 245 317 minecraft:prismarine
fill 206 234 275 206 308 275 minecraft:prismarine
setblock 208 234 275 minecraft:sea_lantern
fill 209 234 275 209 245 275 minecraft:prismarine
fill 211 234 275 213 252 275 minecraft:prismarine
setblock 214 234 275 minecraft:sea_lantern
fill 215 234 275 215 308 275 minecraft:prismarine
setblock 222 234 275 minecraft:sea_lantern
fill 222 234 298 223 236 298 minecraft:prismarine_bricks
fill 223 234 297 223 235 297 minecraft:prismarine_bricks
fill 223 234 299 223 235 299 minecraft:prismarine_bricks
setblock 226 234 298 minecraft:prismarine_bricks
setblock 227 234 298 minecraft:gold_block
fill 230 234 297 230 269 298 minecraft:prismarine
setblock 230 234 304 minecraft:sea_lantern
setblock 192 235 298 minecraft:gold_block
setblock 193 235 298 minecraft:prismarine_bricks
fill 193 235 317 193 308 317 minecraft:prismarine
setblock 194 235 317 minecraft:prismarine_bricks
fill 195 235 297 195 236 297 minecraft:prismarine_bricks
fill 195 235 299 195 236 299 minecraft:prismarine_bricks
fill 196 235 298 196 237 298 minecraft:prismarine_bricks
fill 208 235 275 208 245 275 minecraft:prismarine
fill 214 235 275 214 279 275 minecraft:prismarine
fill 221 235 298 221 237 298 minecraft:prismarine_bricks
fill 222 235 275 222 245 275 minecraft:prismarine
fill 222 235 297 222 236 297 minecraft:prismarine_bricks
fill 222 235 299 222 236 299 minecraft:prismarine_bricks
setblock 224 235 298 minecraft:prismarine_bricks
setblock 225 235 298 minecraft:gold_block
fill 230 235 304 230 254 304 minecraft:prismarine
setblock 230 235 308 minecraft:prismarine_bricks
fill 230 235 309 230 239 310 minecraft:prismarine
setblock 191 236 285 minecraft:light[level=12]
setblock 191 236 292 minecraft:light[level=12]
setblock 191 236 299 minecraft:light[level=12]
setblock 191 236 306 minecraft:light[level=12]
fill 193 236 298 194 236 298 minecraft:gold_block
fill 194 236 317 194 241 317 minecraft:prismarine
fill 196 236 297 197 236 297 minecraft:prismarine_bricks
fill 196 236 299 197 236 299 minecraft:prismarine_bricks
fill 197 236 298 198 238 298 minecraft:prismarine_bricks
setblock 198 236 278 minecraft:light[level=12]
setblock 198 236 285 minecraft:light[level=12]
setblock 198 236 292 minecraft:light[level=12]
setblock 198 236 299 minecraft:light[level=12]
setblock 198 236 306 minecraft:light[level=12]
setblock 198 236 313 minecraft:light[level=12]
setblock 205 236 278 minecraft:light[level=12]
setblock 205 236 285 minecraft:light[level=12]
setblock 205 236 292 minecraft:light[level=12]
setblock 205 236 299 minecraft:light[level=12]
setblock 205 236 306 minecraft:light[level=12]
setblock 205 236 313 minecraft:light[level=12]
setblock 212 236 278 minecraft:light[level=12]
setblock 212 236 285 minecraft:light[level=12]
setblock 212 236 292 minecraft:light[level=12]
setblock 212 236 299 minecraft:light[level=12]
setblock 212 236 306 minecraft:light[level=12]
setblock 212 236 313 minecraft:light[level=12]
setblock 219 236 278 minecraft:light[level=12]
setblock 219 236 285 minecraft:light[level=12]
setblock 219 236 292 minecraft:light[level=12]
fill 219 236 298 220 238 298 minecraft:prismarine_bricks
setblock 219 236 299 minecraft:light[level=12]
setblock 219 236 306 minecraft:light[level=12]
setblock 219 236 313 minecraft:light[level=12]
fill 220 236 297 221 236 297 minecraft:prismarine_bricks
fill 220 236 299 220 237 299 minecraft:prismarine_bricks
setblock 224 236 298 minecraft:gold_block
setblock 226 236 285 minecraft:light[level=12]
setblock 226 236 292 minecraft:light[level=12]
setblock 226 236 299 minecraft:light[level=12]
fill 226 236 305 226 246 305 minecraft:iron_block
setblock 226 236 306 minecraft:light[level=12]
fill 230 236 301 230 245 301 minecraft:prismarine
setblock 230 236 302 minecraft:sea_lantern
fill 230 236 308 230 308 308 minecraft:prismarine
setblock 195 237 298 minecraft:gold_block
fill 197 237 297 199 237 297 minecraft:prismarine_bricks
fill 197 237 299 199 237 299 minecraft:prismarine_bricks
fill 199 237 298 200 238 298 minecraft:prismarine_bricks
fill 216 237 317 217 308 317 minecraft:prismarine
fill 217 237 298 218 239 298 minecraft:prismarine_bricks
fill 218 237 297 220 237 297 minecraft:prismarine_bricks
fill 218 237 299 219 238 299 minecraft:prismarine_bricks
setblock 218 237 317 minecraft:sea_lantern
fill 219 237 317 223 263 317 minecraft:prismarine
fill 222 237 297 222 247 297 minecraft:dark_prismarine
setblock 222 237 298 minecraft:gold_block
fill 230 237 302 230 245 302 minecraft:prismarine
setblock 188 238 311 minecraft:sea_lantern
fill 188 238 312 188 308 312 minecraft:prismarine
setblock 191 238 286 minecraft:light[level=15]
setblock 191 238 294 minecraft:light[level=15]
setblock 191 238 302 minecraft:light[level=15]
setblock 191 238 310 minecraft:light[level=15]
setblock 196 238 298 minecraft:gold_block
fill 198 238 297 201 238 297 minecraft:prismarine_bricks
fill 198 238 299 201 238 299 minecraft:prismarine_bricks
setblock 199 238 278 minecraft:light[level=15]
setblock 199 238 286 minecraft:light[level=15]
setblock 199 238 294 minecraft:light[level=15]
setblock 199 238 302 minecraft:light[level=15]
setblock 199 238 310 minecraft:light[level=15]
fill 201 238 298 202 240 298 minecraft:prismarine_bricks
setblock 207 238 278 minecraft:light[level=15]
setblock 207 238 286 minecraft:light[level=15]
setblock 207 238 294 minecraft:light[level=15]
setblock 207 238 302 minecraft:light[level=15]
setblock 207 238 310 minecraft:light[level=15]
setblock 215 238 278 minecraft:light[level=15]
setblock 215 238 286 minecraft:light[level=15]
setblock 215 238 294 minecraft:light[level=15]
fill 215 238 298 216 240 298 minecraft:prismarine_bricks
setblock 215 238 302 minecraft:light[level=15]
setblock 215 238 310 minecraft:light[level=15]
fill 216 238 297 219 238 297 minecraft:prismarine_bricks
fill 216 238 299 217 239 299 minecraft:prismarine_bricks
fill 218 238 317 218 308 317 minecraft:prismarine
setblock 221 238 298 minecraft:gold_block
setblock 223 238 278 minecraft:light[level=15]
setblock 223 238 286 minecraft:light[level=15]
setblock 223 238 294 minecraft:light[level=15]
setblock 223 238 302 minecraft:light[level=15]
setblock 223 238 310 minecraft:light[level=15]
fill 188 239 311 188 274 311 minecraft:prismarine
fill 198 239 298 199 239 298 minecraft:gold_block
fill 200 239 297 200 239 299 minecraft:prismarine_bricks
fill 201 239 297 202 239 297 minecraft:prismarine_bricks
fill 201 239 299 202 239 299 minecraft:prismarine_bricks
fill 210 239 298 214 240 298 minecraft:prismarine_bricks
fill 214 239 297 217 239 297 minecraft:prismarine_bricks
fill 214 239 299 215 239 299 minecraft:prismarine_bricks
setblock 219 239 298 minecraft:gold_block
fill 221 239 297 221 247 298 minecraft:dark_prismarine
fill 222 239 296 222 247 296 minecraft:dark_prismarine
fill 222 239 298 222 247 298 minecraft:dark_prismarine
fill 223 239 297 223 247 297 minecraft:dark_prismarine
setblock 230 239 291 minecraft:sea_lantern
setblock 230 239 303 minecraft:sea_lantern
fill 190 240 285 190 245 287 minecraft:prismarine_bricks
fill 190 240 298 190 245 299 minecraft:prismarine_bricks
fill 190 240 309 190 245 311 minecraft:prismarine_bricks
fill 196 240 315 198 245 315 minecraft:prismarine_bricks
fill 199 240 298 200 240 298 minecraft:gold_block
fill 200 240 277 202 245 277 minecraft:prismarine_bricks
fill 210 240 297 214 240 297 minecraft:prismarine_bricks
fill 210 240 299 214 240 299 minecraft:prismarine_bricks
fill 212 240 277 214 245 277 minecraft:prismarine_bricks
setblock 216 240 275 minecraft:prismarine_bricks
setblock 217 240 275 minecraft:sea_lantern
fill 217 240 298 218 240 298 minecraft:gold_block
fill 220 240 315 222 245 315 minecraft:prismarine_bricks
fill 221 240 296 221 247 296 minecraft:dark_prismarine
fill 223 240 296 223 247 296 minecraft:dark_prismarine
fill 223 240 298 223 247 298 minecraft:dark_prismarine
fill 224 240 277 226 245 277 minecraft:prismarine_bricks
fill 228 240 285 228 245 287 minecraft:prismarine_bricks
fill 228 240 298 228 245 299 minecraft:prismarine_bricks
fill 228 240 309 228 245 311 minecraft:prismarine_bricks
fill 230 240 291 230 245 291 minecraft:prismarine
fill 230 240 303 230 245 303 minecraft:prismarine
fill 230 240 309 230 266 309 minecraft:prismarine
setblock 230 240 310 minecraft:sea_lantern
fill 188 241 287 188 290 288 minecraft:prismarine
setblock 188 241 289 minecraft:prismarine_bricks
fill 188 241 290 188 268 292 minecraft:prismarine
fill 192 241 311 194 241 311 minecraft:dark_prismarine
fill 192 241 315 194 241 315 minecraft:dark_prismarine
fill 195 241 312 195 241 314 minecraft:dark_prismarine
setblock 202 241 298 minecraft:gold_block
fill 210 241 297 210 241 299 minecraft:prismarine_bricks
fill 211 241 298 213 241 298 minecraft:prismarine_bricks
fill 214 241 298 215 241 298 minecraft:gold_block
fill 216 241 275 217 308 275 minecraft:prismarine
fill 220 241 296 220 247 298 minecraft:dark_prismarine
fill 221 241 299 223 247 299 minecraft:dark_prismarine
fill 222 241 295 222 247 295 minecraft:dark_prismarine
fill 224 241 297 224 247 297 minecraft:dark_prismarine
fill 225 241 275 225 308 275 minecraft:prismarine
setblock 226 241 275 minecraft:sea_lantern
fill 227 241 275 229 261 275 minecraft:prismarine
fill 230 241 310 230 308 310 minecraft:prismarine
fill 188 242 289 188 308 289 minecraft:prismarine
setblock 191 242 285 minecraft:light[level=12]
setblock 191 242 292 minecraft:light[level=12]
setblock 191 242 299 minecraft:light[level=12]
setblock 191 242 306 minecraft:light[level=12]
setblock 194 242 317 minecraft:prismarine_bricks
setblock 198 242 278 minecraft:light[level=12]
setblock 198 242 285 minecraft:light[level=12]
setblock 198 242 292 minecraft:light[level=12]
setblock 198 242 299 minecraft:light[level=12]
setblock 198 242 306 minecraft:light[level=12]
setblock 198 242 313 minecraft:light[level=12]
setblock 205 242 278 minecraft:light[level=12]
setblock 205 242 285 minecraft:light[level=12]
setblock 205 242 292 minecraft:light[level=12]
setblock 205 242 299 minecraft:light[level=12]
setblock 205 242 306 minecraft:light[level=12]
setblock 205 242 313 minecraft:light[level=12]
fill 210 242 298 213 242 298 minecraft:gold_block
setblock 212 242 278 minecraft:light[level=12]
setblock 212 242 285 minecraft:light[level=12]
setblock 212 242 292 minecraft:light[level=12]
setblock 212 242 299 minecraft:light[level=12]
setblock 212 242 306 minecraft:light[level=12]
setblock 212 242 313 minecraft:light[level=12]
setblock 219 242 278 minecraft:light[level=12]
setblock 219 242 285 minecraft:light[level=12]
setblock 219 242 292 minecraft:light[level=12]
setblock 219 242 299 minecraft:light[level=12]
setblock 219 242 306 minecraft:light[level=12]
setblock 219 242 313 minecraft:light[level=12]
fill 220 242 299 220 247 299 minecraft:dark_prismarine
fill 221 242 295 221 247 295 minecraft:dark_prismarine
fill 223 242 295 223 247 295 minecraft:dark_prismarine
fill 224 242 296 224 247 296 minecraft:dark_prismarine
fill 224 242 298 224 247 298 minecraft:dark_prismarine
fill 226 242 275 226 264 275 minecraft:prismarine
setblock 226 242 285 minecraft:light[level=12]
setblock 226 242 292 minecraft:light[level=12]
setblock 226 242 299 minecraft:light[level=12]
setblock 226 242 306 minecraft:light[level=12]
fill 194 243 317 194 308 317 minecraft:prismarine
fill 219 243 296 219 247 298 minecraft:dark_prismarine
fill 220 243 295 220 247 295 minecraft:dark_prismarine
fill 221 243 300 223 247 300 minecraft:dark_prismarine
fill 222 243 294 222 247 294 minecraft:dark_prismarine
fill 224 243 295 224 247 295 minecraft:dark_prismarine
fill 224 243 299 224 247 299 minecraft:dark_prismarine
fill 225 243 297 225 247 297 minecraft:dark_prismarine
fill 225 243 317 225 245 317 minecraft:prismarine
setblock 226 243 317 minecraft:sea_lantern
setblock 188 244 309 minecraft:prismarine_bricks
fill 198 244 308 198 245 308 minecraft:sea_lantern
setblock 201 244 317 minecraft:sea_lantern
fill 202 244 317 202 245 317 minecraft:prismarine
fill 219 244 295 219 247 295 minecraft:dark_prismarine
fill 219 244 299 219 247 299 minecraft:dark_prismarine
fill 220 244 294 221 247 294 minecraft:dark_prismarine
fill 220 244 300 220 247 300 minecraft:dark_prismarine
fill 223 244 294 223 247 294 minecraft:dark_prismarine
fill 224 244 300 224 247 300 minecraft:dark_prismarine
fill 225 244 296 225 247 296 minecraft:dark_prismarine
fill 225 244 298 225 247 299 minecraft:dark_prismarine
fill 226 244 317 226 245 317 minecraft:prismarine
setblock 188 245 302 minecraft:sea_lantern
fill 188 245 309 188 308 309 minecraft:prismarine
fill 189 245 279 189 245 284 minecraft:dark_prismarine
fill 189 245 291 189 245 296 minecraft:dark_prismarine
fill 189 245 303 189 245 308 minecraft:dark_prismarine
fill 189 245 315 189 245 316 minecraft:dark_prismarine
fill 190 245 316 193 245 316 minecraft:dark_prismarine
fill 193 245 276 198 245 276 minecraft:dark_prismarine
fill 200 245 316 205 245 316 minecraft:dark_prismarine
setblock 201 245 317 minecraft:prismarine
fill 205 245 276 210 245 276 minecraft:dark_prismarine
fill 212 245 316 217 245 316 minecraft:dark_prismarine
fill 217 245 276 222 245 276 minecraft:dark_prismarine
fill 218 245 296 218 247 298 minecraft:dark_prismarine
fill 219 245 300 219 247 300 minecraft:dark_prismarine
fill 221 245 301 223 247 301 minecraft:dark_prismarine
fill 222 245 293 222 247 293 minecraft:dark_prismarine
fill 224 245 294 224 247 294 minecraft:dark_prismarine
fill 224 245 316 229 245 316 minecraft:dark_prismarine
fill 225 245 295 225 247 295 minecraft:dark_prismarine
fill 229 245 276 229 245 281 minecraft:dark_prismarine
fill 229 245 288 229 245 293 minecraft:dark_prismarine
fill 229 245 300 229 245 305 minecraft:dark_prismarine
fill 229 245 312 229 245 315 minecraft:dark_prismarine
fill 188 246 281 188 251 284 minecraft:sea_lantern
fill 188 246 293 188 251 296 minecraft:sea_lantern
fill 188 246 302 188 308 302 minecraft:prismarine
fill 188 246 305 188 251 308 minecraft:sea_lantern
fill 188 246 317 191 251 317 minecraft:sea_lantern
setblock 191 246 286 minecraft:light[level=15]
setblock 191 246 294 minecraft:light[level=15]
setblock 191 246 302 minecraft:light[level=15]
setblock 191 246 310 minecraft:light[level=15]
fill 195 246 275 198 251 275 minecraft:sea_lantern
fill 198 246 308 198 253 308 minecraft:dark_prismarine
setblock 199 246 278 minecraft:light[level=15]
setblock 199 246 286 minecraft:light[level=15]
setblock 199 246 294 minecraft:light[level=15]
setblock 199 246 302 minecraft:light[level=15]
setblock 199 246 310 minecraft:light[level=15]
fill 200 246 317 203 251 317 minecraft:sea_lantern
fill 207 246 275 210 251 275 minecraft:sea_lantern
setblock 207 246 278 minecraft:light[level=15]
setblock 207 246 286 minecraft:light[level=15]
setblock 207 246 294 minecraft:light[level=15]
setblock 207 246 302 minecraft:light[level=15]
setblock 207 246 310 minecraft:light[level=15]
fill 212 246 317 215 251 317 minecraft:sea_lantern
setblock 215 246 278 minecraft:light[level=15]
setblock 215 246 286 minecraft:light[level=15]
setblock 215 246 294 minecraft:light[level=15]
setblock 215 246 302 minecraft:light[level=15]
setblock 215 246 310 minecraft:light[level=15]
fill 218 246 295 218 247 295 minecraft:dark_prismarine
fill 218 246 299 218 247 299 minecraft:dark_prismarine
fill 219 246 275 222 251 275 minecraft:sea_lantern
fill 219 246 294 219 247 294 minecraft:dark_prismarine
fill 220 246 293 221 247 293 minecraft:dark_prismarine
fill 220 246 301 220 247 301 minecraft:dark_prismarine
setblock 223 246 278 minecraft:light[level=15]
setblock 223 246 286 minecraft:light[level=15]
fill 223 246 293 224 247 293 minecraft:dark_prismarine
setblock 223 246 302 minecraft:light[level=15]
setblock 223 246 310 minecraft:light[level=15]
fill 224 246 301 224 247 301 minecraft:dark_prismarine
fill 224 246 317 227 251 317 minecraft:sea_lantern
fill 225 246 294 225 247 294 minecraft:dark_prismarine
fill 225 246 300 225 247 300 minecraft:dark_prismarine
fill 226 246 298 226 247 299 minecraft:dark_prismarine
fill 230 246 276 230 251 279 minecraft:sea_lantern
fill 230 246 288 230 251 291 minecraft:sea_lantern
fill 230 246 300 230 251 303 minecraft:sea_lantern
fill 230 246 312 230 251 315 minecraft:sea_lantern
fill 198 247 309 198 253 309 minecraft:dark_prismarine
fill 217 247 296 217 247 298 minecraft:dark_prismarine
setblock 218 247 294 minecraft:dark_prismarine
setblock 218 247 300 minecraft:dark_prismarine
setblock 219 247 293 minecraft:dark_prismarine
setblock 219 247 301 minecraft:dark_prismarine
fill 221 247 302 223 247 302 minecraft:dark_prismarine
setblock 222 247 292 minecraft:dark_prismarine
setblock 225 247 301 minecraft:dark_prismarine
setblock 226 247 300 minecraft:dark_prismarine
setblock 230 247 281 minecraft:prismarine_bricks
setblock 188 248 286 minecraft:sea_lantern
setblock 188 248 316 minecraft:prismarine_bricks
setblock 191 248 285 minecraft:light[level=12]
setblock 191 248 292 minecraft:light[level=12]
setblock 191 248 299 minecraft:light[level=12]
setblock 191 248 306 minecraft:light[level=12]
fill 197 248 308 197 253 309 minecraft:dark_prismarine
setblock 198 248 278 minecraft:light[level=12]
setblock 198 248 285 minecraft:light[level=12]
setblock 198 248 292 minecraft:light[level=12]
setblock 198 248 299 minecraft:light[level=12]
setblock 198 248 306 minecraft:light[level=12]
fill 198 248 307 198 253 307 minecraft:dark_prismarine
setblock 198 248 313 minecraft:light[level=12]
fill 199 248 308 199 253 309 minecraft:dark_prismarine
setblock 205 248 278 minecraft:light[level=12]
setblock 205 248 285 minecraft:light[level=12]
setblock 205 248 292 minecraft:light[level=12]
setblock 205 248 299 minecraft:light[level=12]
setblock 205 248 306 minecraft:light[level=12]
setblock 205 248 313 minecraft:light[level=12]
setblock 212 248 278 minecraft:light[level=12]
setblock 212 248 285 minecraft:light[level=12]
setblock 212 248 292 minecraft:light[level=12]
setblock 212 248 299 minecraft:light[level=12]
setblock 212 248 306 minecraft:light[level=12]
setblock 212 248 313 minecraft:light[level=12]
setblock 219 248 278 minecraft:light[level=12]
setblock 219 248 285 minecraft:light[level=12]
setblock 219 248 292 minecraft:light[level=12]
setblock 219 248 299 minecraft:light[level=12]
setblock 219 248 306 minecraft:light[level=12]
setblock 219 248 313 minecraft:light[level=12]
fill 221 248 296 221 251 296 minecraft:prismarine_bricks
fill 221 248 298 221 251 298 minecraft:prismarine_bricks
fill 223 248 297 223 251 297 minecraft:prismarine_bricks
setblock 226 248 285 minecraft:light[level=12]
setblock 226 248 292 minecraft:light[level=12]
setblock 226 248 299 minecraft:light[level=12]
setblock 226 248 306 minecraft:light[level=12]
fill 230 248 281 230 308 281 minecraft:prismarine
setblock 230 248 299 minecraft:prismarine_bricks
setblock 230 248 305 minecraft:sea_lantern
fill 188 249 286 188 273 286 minecraft:prismarine
fill 188 249 316 188 308 316 minecraft:prismarine
fill 192 249 311 194 249 311 minecraft:dark_prismarine
fill 192 249 315 194 249 315 minecraft:dark_prismarine
fill 195 249 312 195 249 314 minecraft:dark_prismarine
fill 197 249 307 197 253 307 minecraft:dark_prismarine
fill 198 249 310 198 253 310 minecraft:dark_prismarine
fill 199 249 307 199 253 307 minecraft:dark_prismarine
setblock 203 249 275 minecraft:sea_lantern
fill 212 249 281 214 250 281 minecraft:light_blue_stained_glass
fill 213 249 280 213 250 280 minecraft:light_blue_stained_glass
fill 213 249 282 213 250 282 minecraft:light_blue_stained_glass
fill 230 249 299 230 308 299 minecraft:prismarine
fill 230 249 305 230 308 305 minecraft:prismarine
fill 196 250 308 196 253 309 minecraft:dark_prismarine
fill 197 250 310 197 253 310 minecraft:dark_prismarine
fill 198 250 306 198 253 306 minecraft:dark_prismarine
fill 199 250 310 199 253 310 minecraft:dark_prismarine
fill 200 250 307 200 253 309 minecraft:dark_prismarine
fill 201 250 306 201 251 306 minecraft:sea_lantern
fill 203 250 275 203 266 275 minecraft:prismarine
fill 196 251 307 196 253 307 minecraft:dark_prismarine
fill 196 251 310 196 253 310 minecraft:dark_prismarine
fill 197 251 306 197 253 306 minecraft:dark_prismarine
fill 198 251 311 199 253 311 minecraft:dark_prismarine
fill 199 251 306 199 253 306 minecraft:dark_prismarine
fill 200 251 310 200 253 310 minecraft:dark_prismarine
fill 214 251 307 214 252 308 minecraft:white_stained_glass
setblock 188 252 276 minecraft:sea_lantern
fill 188 252 281 188 265 281 minecraft:prismarine
fill 188 252 282 188 252 283 minecraft:sea_lantern
fill 188 252 284 188 265 284 minecraft:prismarine
fill 188 252 293 188 265 293 minecraft:prismarine
fill 188 252 294 188 252 295 minecraft:sea_lantern
setblock 188 252 296 minecraft:prismarine
fill 188 252 305 188 265 305 minecraft:prismarine
fill 188 252 306 188 252 307 minecraft:sea_lantern
fill 188 252 308 188 265 308 minecraft:prismarine
fill 188 252 317 188 265 317 minecraft:prismarine
fill 189 252 317 190 252 317 minecraft:sea_lantern
fill 191 252 317 191 265 317 minecraft:prismarine
fill 195 252 275 195 265 275 minecraft:prismarine
fill 195 252 307 195 253 309 minecraft:dark_prismarine
fill 196 252 275 197 252 275 minecraft:sea_lantern
fill 196 252 306 196 253 306 minecraft:dark_prismarine
fill 197 252 311 197 253 311 minecraft:dark_prismarine
fill 198 252 275 198 265 275 minecraft:prismarine
fill 198 252 305 198 253 305 minecraft:dark_prismarine
fill 200 252 306 202 253 306 minecraft:dark_prismarine
fill 200 252 311 200 253 311 minecraft:dark_prismarine
fill 200 252 317 200 265 317 minecraft:prismarine
fill 201 252 307 201 253 309 minecraft:dark_prismarine
fill 201 252 317 202 252 317 minecraft:sea_lantern
fill 203 252 317 203 262 317 minecraft:prismarine
fill 207 252 275 207 265 275 minecraft:prismarine
fill 208 252 275 209 252 275 minecraft:sea_lantern
fill 210 252 275 210 265 275 minecraft:prismarine
fill 212 252 317 212 256 317 minecraft:prismarine
fill 213 252 317 214 252 317 minecraft:sea_lantern
fill 215 252 317 215 265 317 minecraft:prismarine
fill 219 252 275 219 265 275 minecraft:prismarine
fill 220 252 275 221 252 275 minecraft:sea_lantern
fill 222 252 275 222 265 275 minecraft:prismarine
fill 224 252 317 224 265 317 minecraft:prismarine
fill 225 252 317 226 252 317 minecraft:sea_lantern
fill 227 252 317 227 265 317 minecraft:prismarine
fill 230 252 276 230 265 276 minecraft:prismarine
fill 230 252 277 230 252 278 minecraft:sea_lantern
fill 230 252 279 230 265 279 minecraft:prismarine
fill 230 252 288 230 265 288 minecraft:prismarine
fill 230 252 289 230 252 290 minecraft:sea_lantern
fill 230 252 291 230 265 291 minecraft:prismarine
fill 230 252 300 230 261 300 minecraft:prismarine
fill 230 252 301 230 252 302 minecraft:sea_lantern
fill 230 252 303 230 265 303 minecraft:prismarine
fill 230 252 312 230 265 312 minecraft:prismarine
fill 230 252 313 230 252 314 minecraft:sea_lantern
fill 230 252 315 230 265 315 minecraft:prismarine
fill 188 253 276 188 308 276 minecraft:prismarine
fill 188 253 282 188 265 283 minecraft:prismarine
fill 188 253 294 188 265 295 minecraft:prismarine
setblock 188 253 296 minecraft:sea_lantern
fill 188 253 306 188 265 307 minecraft:prismarine
fill 189 253 317 190 265 317 minecraft:prismarine
setblock 195 253 310 minecraft:dark_prismarine
fill 196 253 275 197 265 275 minecraft:prismarine
setblock 196 253 311 minecraft:dark_prismarine
setblock 197 253 305 minecraft:dark_prismarine
setblock 198 253 312 minecraft:dark_prismarine
setblock 199 253 305 minecraft:dark_prismarine
setblock 201 253 310 minecraft:dark_prismarine
fill 201 253 317 202 265 317 minecraft:prismarine
fill 208 253 275 209 265 275 minecraft:prismarine
fill 211 253 275 212 264 275 minecraft:prismarine
setblock 213 253 275 minecraft:prismarine_bricks
fill 213 253 317 214 265 317 minecraft:prismarine
fill 220 253 275 221 265 275 minecraft:prismarine
fill 225 253 317 226 258 317 minecraft:prismarine
fill 230 253 277 230 265 278 minecraft:prismarine
fill 230 253 289 230 253 290 minecraft:prismarine
fill 230 253 301 230 265 302 minecraft:prismarine
fill 230 253 313 230 265 314 minecraft:prismarine
setblock 188 254 277 minecraft:prismarine_bricks
fill 188 254 296 188 265 296 minecraft:prismarine
setblock 191 254 285 minecraft:light[level=12]
setblock 191 254 286 minecraft:light[level=15]
setblock 191 254 292 minecraft:light[level=12]
setblock 191 254 294 minecraft:light[level=15]
setblock 191 254 299 minecraft:light[level=12]
setblock 191 254 302 minecraft:light[level=15]
setblock 191 254 306 minecraft:light[level=12]
setblock 191 254 310 minecraft:light[level=15]
fill 197 254 309 197 256 309 minecraft:prismarine_bricks
setblock 198 254 278 minecraft:light[level=12]
setblock 198 254 285 minecraft:light[level=12]
setblock 198 254 292 minecraft:light[level=12]
setblock 198 254 299 minecraft:light[level=12]
setblock 198 254 306 minecraft:light[level=12]
fill 198 254 307 198 257 307 minecraft:prismarine_bricks
setblock 198 254 313 minecraft:light[level=12]
setblock 199 254 278 minecraft:light[level=15]
setblock 199 254 286 minecraft:light[level=15]
setblock 199 254 294 minecraft:light[level=15]
setblock 199 254 302 minecraft:light[level=15]
setblock 199 254 310 minecraft:light[level=15]
fill 200 254 309 200 257 309 minecraft:prismarine_bricks
fill 201 254 305 202 259 307 minecraft:dark_prismarine
setblock 205 254 278 minecraft:light[level=12]
setblock 205 254 285 minecraft:light[level=12]
setblock 205 254 292 minecraft:light[level=12]
setblock 205 254 299 minecraft:light[level=12]
setblock 205 254 306 minecraft:light[level=12]
setblock 205 254 313 minecraft:light[level=12]
setblock 207 254 278 minecraft:light[level=15]
setblock 207 254 286 minecraft:light[level=15]
setblock 207 254 294 minecraft:light[level=15]
setblock 207 254 302 minecraft:light[level=15]
setblock 207 254 310 minecraft:light[level=15]
setblock 212 254 278 minecraft:light[level=12]
setblock 212 254 285 minecraft:light[level=12]
setblock 212 254 292 minecraft:light[level=12]
setblock 212 254 299 minecraft:light[level=12]
setblock 212 254 306 minecraft:light[level=12]
setblock 212 254 313 minecraft:light[level=12]
setblock 213 254 275 minecraft:prismarine
setblock 215 254 278 minecraft:light[level=15]
setblock 215 254 286 minecraft:light[level=15]
setblock 215 254 294 minecraft:light[level=15]
setblock 215 254 302 minecraft:light[level=15]
setblock 215 254 310 minecraft:light[level=15]
setblock 219 254 278 minecraft:light[level=12]
setblock 219 254 285 minecraft:light[level=12]
setblock 219 254 292 minecraft:light[level=12]
setblock 219 254 299 minecraft:light[level=12]
setblock 219 254 306 minecraft:light[level=12]
setblock 219 254 313 minecraft:light[level=12]
setblock 223 254 278 minecraft:light[level=15]
setblock 223 254 286 minecraft:light[level=15]
setblock 223 254 294 minecraft:light[level=15]
setblock 223 254 302 minecraft:light[level=15]
setblock 223 254 310 minecraft:light[level=15]
setblock 226 254 285 minecraft:light[level=12]
setblock 226 254 292 minecraft:light[level=12]
setblock 226 254 299 minecraft:light[level=12]
setblock 226 254 306 minecraft:light[level=12]
fill 230 254 289 230 265 289 minecraft:prismarine
setblock 230 254 290 minecraft:sea_lantern
fill 188 255 277 188 295 277 minecraft:prismarine
fill 188 255 300 188 308 300 minecraft:prismarine
setblock 188 255 301 minecraft:sea_lantern
fill 194 255 278 194 264 278 minecraft:iron_block
fill 200 255 305 200 259 307 minecraft:dark_prismarine
fill 203 255 305 203 259 306 minecraft:dark_prismarine
setblock 213 255 275 minecraft:prismarine_bricks
fill 230 255 290 230 265 290 minecraft:prismarine
setblock 230 255 304 minecraft:sea_lantern
fill 188 256 301 188 275 301 minecraft:prismarine
fill 201 256 304 202 259 304 minecraft:dark_prismarine
fill 201 256 308 202 259 308 minecraft:dark_prismarine
fill 203 256 307 203 259 307 minecraft:dark_prismarine
fill 213 256 275 213 308 275 minecraft:prismarine
fill 230 256 304 230 308 304 minecraft:prismarine
setblock 188 257 310 minecraft:sea_lantern
fill 192 257 311 194 257 311 minecraft:dark_prismarine
fill 192 257 315 194 257 315 minecraft:dark_prismarine
fill 195 257 312 195 257 314 minecraft:dark_prismarine
fill 199 257 287 200 258 288 minecraft:white_stained_glass
fill 199 257 305 199 259 307 minecraft:dark_prismarine
fill 200 257 304 200 259 304 minecraft:dark_prismarine
fill 200 257 308 200 259 308 minecraft:dark_prismarine
fill 203 257 304 203 259 304 minecraft:dark_prismarine
fill 203 257 308 203 259 308 minecraft:dark_prismarine
fill 204 257 305 204 259 306 minecraft:dark_prismarine
setblock 212 257 317 minecraft:prismarine_bricks
fill 188 258 303 188 308 303 minecraft:prismarine
setblock 188 258 304 minecraft:sea_lantern
fill 188 258 310 188 304 310 minecraft:prismarine
fill 199 258 304 199 259 304 minecraft:dark_prismarine
fill 199 258 308 199 259 308 minecraft:dark_prismarine
fill 201 258 303 202 259 303 minecraft:dark_prismarine
fill 201 258 309 202 259 309 minecraft:dark_prismarine
setblock 202 258 275 minecraft:prismarine_bricks
fill 204 258 304 204 259 304 minecraft:dark_prismarine
fill 204 258 307 204 259 307 minecraft:dark_prismarine
fill 205 258 317 205 308 317 minecraft:prismarine
setblock 206 258 317 minecraft:prismarine_bricks
fill 212 258 317 212 265 317 minecraft:prismarine
fill 230 258 282 230 271 285 minecraft:prismarine
setblock 230 258 286 minecraft:sea_lantern
fill 230 258 287 230 308 287 minecraft:prismarine
setblock 188 259 297 minecraft:prismarine_bricks
fill 188 259 298 188 308 298 minecraft:prismarine
fill 188 259 304 188 305 304 minecraft:prismarine
fill 198 259 305 198 259 307 minecraft:dark_prismarine
setblock 200 259 303 minecraft:dark_prismarine
setblock 200 259 309 minecraft:dark_prismarine
fill 202 259 275 202 285 275 minecraft:prismarine
setblock 203 259 303 minecraft:dark_prismarine
setblock 203 259 309 minecraft:dark_prismarine
setblock 204 259 308 minecraft:dark_prismarine
fill 205 259 305 205 259 306 minecraft:dark_prismarine
fill 206 259 317 206 308 317 minecraft:prismarine
setblock 225 259 317 minecraft:prismarine_bricks
fill 226 259 317 226 265 317 minecraft:prismarine
fill 230 259 286 230 308 286 minecraft:prismarine
fill 188 260 297 188 292 297 minecraft:prismarine
fill 190 260 285 190 265 287 minecraft:prismarine_bricks
fill 190 260 298 190 265 299 minecraft:prismarine_bricks
fill 190 260 309 190 265 311 minecraft:prismarine_bricks
setblock 191 260 285 minecraft:light[level=12]
setblock 191 260 292 minecraft:light[level=12]
setblock 191 260 299 minecraft:light[level=12]
setblock 191 260 306 minecraft:light[level=12]
fill 196 260 315 198 265 315 minecraft:prismarine_bricks
setblock 198 260 278 minecraft:light[level=12]
setblock 198 260 285 minecraft:light[level=12]
setblock 198 260 292 minecraft:light[level=12]
setblock 198 260 299 minecraft:light[level=12]
setblock 198 260 306 minecraft:light[level=12]
setblock 198 260 313 minecraft:light[level=12]
fill 200 260 277 202 265 277 minecraft:prismarine_bricks
fill 200 260 307 200 261 307 minecraft:prismarine_bricks
fill 201 260 304 201 261 304 minecraft:prismarine_bricks
fill 203 260 306 203 263 306 minecraft:prismarine_bricks
setblock 205 260 278 minecraft:light[level=12]
setblock 205 260 285 minecraft:light[level=12]
setblock 205 260 292 minecraft:light[level=12]
setblock 205 260 299 minecraft:light[level=12]
setblock 205 260 306 minecraft:light[level=12]
setblock 205 260 313 minecraft:light[level=12]
fill 212 260 277 214 265 277 minecraft:prismarine_bricks
setblock 212 260 278 minecraft:light[level=12]
setblock 212 260 285 minecraft:light[level=12]
setblock 212 260 292 minecraft:light[level=12]
setblock 212 260 299 minecraft:light[level=12]
setblock 212 260 306 minecraft:light[level=12]
setblock 212 260 313 minecraft:light[level=12]
setblock 219 260 278 minecraft:light[level=12]
setblock 219 260 285 minecraft:light[level=12]
setblock 219 260 292 minecraft:light[level=12]
setblock 219 260 299 minecraft:light[level=12]
setblock 219 260 306 minecraft:light[level=12]
setblock 219 260 313 minecraft:light[level=12]
fill 220 260 315 222 265 315 minecraft:prismarine_bricks
fill 224 260 277 226 265 277 minecraft:prismarine_bricks
fill 225 260 317 225 265 317 minecraft:prismarine
setblock 226 260 285 minecraft:light[level=12]
setblock 226 260 292 minecraft:light[level=12]
setblock 226 260 299 minecraft:light[level=12]
setblock 226 260 306 minecraft:light[level=12]
fill 228 260 285 228 265 287 minecraft:prismarine_bricks
fill 228 260 298 228 265 299 minecraft:prismarine_bricks
fill 228 260 309 228 265 311 minecraft:prismarine_bricks
fill 189 261 296 193 262 296 minecraft:prismarine_bricks
fill 190 261 279 194 262 279 minecraft:prismarine_bricks
fill 190 261 295 192 262 295 minecraft:prismarine_bricks
fill 190 261 297 192 262 297 minecraft:prismarine_bricks
fill 190 261 313 193 262 313 minecraft:prismarine_bricks
fill 191 261 278 193 262 278 minecraft:prismarine_bricks
fill 191 261 280 193 262 280 minecraft:prismarine_bricks
fill 191 261 294 191 262 294 minecraft:prismarine_bricks
fill 191 261 298 191 262 298 minecraft:prismarine_bricks
fill 191 261 312 193 262 312 minecraft:prismarine_bricks
fill 191 261 314 193 262 314 minecraft:prismarine_bricks
fill 192 261 277 192 262 277 minecraft:prismarine_bricks
fill 192 261 281 192 262 281 minecraft:prismarine_bricks
fill 192 261 311 192 262 311 minecraft:prismarine_bricks
fill 192 261 315 192 262 315 minecraft:prismarine_bricks
fill 207 261 278 211 262 278 minecraft:prismarine_bricks
fill 207 261 314 211 262 314 minecraft:prismarine_bricks
fill 208 261 277 210 262 277 minecraft:prismarine_bricks
fill 208 261 279 210 262 279 minecraft:prismarine_bricks
fill 208 261 313 210 262 313 minecraft:prismarine_bricks
fill 208 261 315 210 262 315 minecraft:prismarine_bricks
fill 209 261 276 209 262 276 minecraft:prismarine_bricks
fill 209 261 280 209 262 280 minecraft:prismarine_bricks
fill 209 261 312 209 262 312 minecraft:prismarine_bricks
fill 224 261 279 228 262 279 minecraft:prismarine_bricks
fill 224 261 313 228 262 313 minecraft:prismarine_bricks
fill 225 261 278 227 262 278 minecraft:prismarine_bricks
fill 225 261 280 227 262 280 minecraft:prismarine_bricks
fill 225 261 296 228 262 296 minecraft:prismarine_bricks
fill 225 261 312 227 262 312 minecraft:prismarine_bricks
fill 225 261 314 227 262 314 minecraft:prismarine_bricks
fill 226 261 281 226 262 281 minecraft:prismarine_bricks
fill 226 261 295 228 262 295 minecraft:prismarine_bricks
fill 226 261 297 228 262 297 minecraft:prismarine_bricks
fill 226 261 311 226 262 311 minecraft:prismarine_bricks
fill 226 261 315 226 262 315 minecraft:prismarine_bricks
fill 227 261 294 227 262 294 minecraft:prismarine_bricks
fill 227 261 298 227 262 298 minecraft:prismarine_bricks
setblock 191 262 286 minecraft:light[level=15]
setblock 191 262 302 minecraft:light[level=15]
setblock 191 262 310 minecraft:light[level=15]
setblock 199 262 278 minecraft:light[level=15]
setblock 199 262 286 minecraft:light[level=15]
setblock 199 262 294 minecraft:light[level=15]
setblock 199 262 302 minecraft:light[level=15]
setblock 199 262 310 minecraft:light[level=15]
setblock 207 262 286 minecraft:light[level=15]
setblock 207 262 294 minecraft:light[level=15]
setblock 207 262 302 minecraft:light[level=15]
setblock 207 262 310 minecraft:light[level=15]
setblock 215 262 278 minecraft:light[level=15]
setblock 215 262 286 minecraft:light[level=15]
setblock 215 262 294 minecraft:light[level=15]
setblock 215 262 302 minecraft:light[level=15]
setblock 215 262 310 minecraft:light[level=15]
setblock 223 262 278 minecraft:light[level=15]
setblock 223 262 286 minecraft:light[level=15]
setblock 223 262 294 minecraft:light[level=15]
setblock 223 262 302 minecraft:light[level=15]
setblock 223 262 310 minecraft:light[level=15]
fill 227 262 275 228 292 275 minecraft:prismarine
setblock 229 262 275 minecraft:sea_lantern
setblock 230 262 300 minecraft:sea_lantern
fill 190 263 295 192 290 297 minecraft:quartz_pillar
fill 191 263 278 193 290 280 minecraft:quartz_pillar
fill 191 263 312 193 290 314 minecraft:quartz_pillar
setblock 203 263 317 minecraft:sea_lantern
fill 208 263 277 210 290 279 minecraft:quartz_pillar
fill 208 263 313 210 290 315 minecraft:quartz_pillar
fill 225 263 278 227 290 280 minecraft:quartz_pillar
fill 225 263 312 227 290 314 minecraft:quartz_pillar
fill 226 263 295 228 290 297 minecraft:quartz_pillar
fill 229 263 275 229 308 275 minecraft:prismarine
fill 230 263 300 230 265 300 minecraft:prismarine
fill 203 264 317 203 265 317 minecraft:prismarine
fill 219 264 317 221 269 317 minecraft:prismarine
setblock 222 264 317 minecraft:prismarine_bricks
fill 223 264 317 223 308 317 minecraft:prismarine
fill 189 265 275 189 308 275 minecraft:prismarine
fill 189 265 279 189 265 284 minecraft:dark_prismarine
fill 189 265 291 189 265 296 minecraft:dark_prismarine
fill 189 265 303 189 265 308 minecraft:dark_prismarine
fill 189 265 315 189 265 316 minecraft:dark_prismarine
setblock 190 265 275 minecraft:prismarine_bricks
fill 190 265 316 193 265 316 minecraft:dark_prismarine
fill 191 265 275 192 297 275 minecraft:prismarine
fill 192 265 311 194 265 311 minecraft:dark_prismarine
fill 192 265 315 194 265 315 minecraft:dark_prismarine
fill 193 265 276 198 265 276 minecraft:dark_prismarine
fill 195 265 312 195 265 314 minecraft:dark_prismarine
fill 200 265 316 205 265 316 minecraft:dark_prismarine
fill 205 265 276 210 265 276 minecraft:dark_prismarine
setblock 211 265 275 minecraft:prismarine_bricks
fill 212 265 275 212 269 275 minecraft:prismarine
fill 212 265 316 217 265 316 minecraft:dark_prismarine
fill 217 265 276 222 265 276 minecraft:dark_prismarine
fill 222 265 317 222 308 317 minecraft:prismarine
fill 224 265 316 229 265 316 minecraft:dark_prismarine
setblock 226 265 275 minecraft:prismarine_bricks
fill 229 265 276 229 265 281 minecraft:dark_prismarine
fill 229 265 288 229 265 293 minecraft:dark_prismarine
fill 229 265 300 229 265 305 minecraft:dark_prismarine
fill 229 265 312 229 265 315 minecraft:dark_prismarine
fill 188 266 281 188 271 284 minecraft:sea_lantern
fill 188 266 293 188 271 296 minecraft:sea_lantern
fill 188 266 305 188 271 308 minecraft:sea_lantern
fill 188 266 317 191 271 317 minecraft:sea_lantern
fill 190 266 275 190 291 275 minecraft:prismarine
setblock 191 266 285 minecraft:light[level=12]
setblock 191 266 292 minecraft:light[level=12]
setblock 191 266 299 minecraft:light[level=12]
setblock 191 266 306 minecraft:light[level=12]
fill 195 266 275 198 271 275 minecraft:sea_lantern
setblock 198 266 278 minecraft:light[level=12]
setblock 198 266 285 minecraft:light[level=12]
setblock 198 266 292 minecraft:light[level=12]
setblock 198 266 299 minecraft:light[level=12]
setblock 198 266 306 minecraft:light[level=12]
setblock 198 266 313 minecraft:light[level=12]
fill 200 266 317 203 271 317 minecraft:sea_lantern
setblock 205 266 278 minecraft:light[level=12]
setblock 205 266 285 minecraft:light[level=12]
setblock 205 266 292 minecraft:light[level=12]
setblock 205 266 299 minecraft:light[level=12]
setblock 205 266 306 minecraft:light[level=12]
setblock 205 266 313 minecraft:light[level=12]
fill 207 266 275 210 271 275 minecraft:sea_lantern
setblock 209 266 317 minecraft:sea_lantern
fill 211 266 275 211 308 275 minecraft:prismarine
setblock 212 266 278 minecraft:light[level=12]
setblock 212 266 285 minecraft:light[level=12]
setblock 212 266 292 minecraft:light[level=12]
setblock 212 266 299 minecraft:light[level=12]
setblock 212 266 306 minecraft:light[level=12]
setblock 212 266 313 minecraft:light[level=12]
fill 212 266 317 215 271 317 minecraft:sea_lantern
fill 219 266 275 222 271 275 minecraft:sea_lantern
setblock 219 266 278 minecraft:light[level=12]
setblock 219 266 285 minecraft:light[level=12]
setblock 219 266 292 minecraft:light[level=12]
setblock 219 266 299 minecraft:light[level=12]
setblock 219 266 306 minecraft:light[level=12]
setblock 219 266 313 minecraft:light[level=12]
fill 224 266 317 227 271 317 minecraft:sea_lantern
fill 226 266 275 226 269 275 minecraft:prismarine
setblock 226 266 285 minecraft:light[level=12]
setblock 226 266 292 minecraft:light[level=12]
setblock 226 266 299 minecraft:light[level=12]
setblock 226 266 306 minecraft:light[level=12]
fill 230 266 276 230 271 279 minecraft:sea_lantern
fill 230 266 288 230 271 291 minecraft:sea_lantern
fill 230 266 300 230 271 303 minecraft:sea_lantern
fill 230 266 312 230 271 315 minecraft:sea_lantern
setblock 199 267 275 minecraft:sea_lantern
fill 200 267 275 200 308 275 minecraft:prismarine
setblock 203 267 275 minecraft:prismarine_bricks
fill 203 267 288 205 268 288 minecraft:white_stained_glass
fill 204 267 289 204 268 289 minecraft:white_stained_glass
fill 209 267 317 209 273 317 minecraft:prismarine
setblock 230 267 309 minecraft:sea_lantern
fill 199 268 275 199 308 275 minecraft:prismarine
setblock 203 268 275 minecraft:sea_lantern
setblock 210 268 317 minecraft:sea_lantern
fill 211 268 317 211 273 317 minecraft:prismarine
fill 230 268 309 230 289 309 minecraft:prismarine
fill 188 269 290 188 308 290 minecraft:prismarine
setblock 188 269 291 minecraft:sea_lantern
fill 188 269 292 188 308 292 minecraft:prismarine
fill 197 269 294 197 271 294 minecraft:cyan_stained_glass
fill 197 269 295 197 272 295 minecraft:prismarine_bricks
fill 197 269 296 197 272 300 minecraft:cyan_stained_glass
fill 197 269 301 197 272 301 minecraft:prismarine_bricks
fill 197 269 302 197 271 302 minecraft:cyan_stained_glass
fill 198 269 292 198 271 293 minecraft:cyan_stained_glass
schedule function dropper:buildpart/64_4 1t
