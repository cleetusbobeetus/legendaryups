setblock 479 79 503 minecraft:red_terracotta
setblock 479 79 504 minecraft:terracotta
setblock 480 79 503 minecraft:terracotta
fill 480 79 504 480 81 504 minecraft:red_terracotta
fill 481 79 478 482 79 478 minecraft:orange_concrete
fill 481 79 503 484 79 503 minecraft:red_terracotta
fill 482 79 464 483 79 464 minecraft:red_terracotta
fill 482 79 476 482 79 477 minecraft:orange_concrete
fill 482 79 479 482 79 480 minecraft:orange_concrete
fill 483 79 475 488 79 475 minecraft:orange_concrete
fill 483 79 481 487 79 481 minecraft:orange_concrete
setblock 483 79 502 minecraft:red_terracotta
setblock 484 79 464 minecraft:terracotta
fill 484 79 474 486 79 474 minecraft:orange_concrete
setblock 484 79 504 minecraft:terracotta
fill 485 79 464 485 81 464 minecraft:red_terracotta
setblock 485 79 503 minecraft:terracotta
fill 485 79 504 485 81 504 minecraft:red_terracotta
fill 486 79 503 486 81 503 minecraft:red_terracotta
fill 487 79 476 488 79 476 minecraft:orange_concrete
fill 487 79 480 488 79 480 minecraft:orange_concrete
setblock 489 79 464 minecraft:terracotta
setblock 489 79 504 minecraft:terracotta
setblock 490 79 504 minecraft:red_terracotta
fill 491 79 481 492 79 484 minecraft:orange_concrete
fill 492 79 480 493 79 480 minecraft:orange_concrete
fill 492 79 485 493 79 485 minecraft:orange_concrete
fill 493 79 479 497 79 479 minecraft:orange_concrete
fill 493 79 486 497 79 486 minecraft:orange_concrete
fill 496 79 464 496 81 464 minecraft:red_terracotta
fill 497 79 480 498 79 480 minecraft:orange_concrete
fill 497 79 485 498 79 485 minecraft:orange_concrete
fill 497 79 504 498 79 504 minecraft:red_terracotta
setblock 499 79 464 minecraft:terracotta
setblock 499 79 503 minecraft:red_terracotta
setblock 499 79 504 minecraft:terracotta
fill 500 79 464 500 81 464 minecraft:red_terracotta
setblock 500 79 503 minecraft:terracotta
fill 500 79 504 500 81 504 minecraft:red_terracotta
setblock 501 79 502 minecraft:terracotta
fill 501 79 503 501 81 503 minecraft:red_terracotta
fill 502 79 502 502 81 502 minecraft:red_terracotta
setblock 503 79 465 minecraft:terracotta
fill 503 79 501 503 81 501 minecraft:red_terracotta
setblock 504 79 464 minecraft:terracotta
fill 504 79 465 504 81 465 minecraft:red_terracotta
setblock 504 79 504 minecraft:terracotta
fill 505 79 464 505 81 464 minecraft:red_terracotta
setblock 505 79 503 minecraft:terracotta
fill 505 79 504 505 81 504 minecraft:red_terracotta
setblock 506 79 501 minecraft:red_terracotta
setblock 506 79 502 minecraft:terracotta
fill 506 79 503 506 81 503 minecraft:red_terracotta
setblock 507 79 501 minecraft:terracotta
fill 507 79 502 507 81 502 minecraft:red_terracotta
setblock 508 79 465 minecraft:terracotta
setblock 508 79 499 minecraft:red_terracotta
setblock 508 79 500 minecraft:terracotta
fill 508 79 501 508 80 501 minecraft:red_terracotta
setblock 509 79 464 minecraft:terracotta
setblock 509 79 499 minecraft:terracotta
fill 509 79 500 509 81 500 minecraft:red_terracotta
setblock 509 79 504 minecraft:terracotta
fill 510 79 464 510 81 464 minecraft:red_terracotta
setblock 510 79 498 minecraft:terracotta
fill 510 79 499 510 81 499 minecraft:red_terracotta
setblock 510 79 503 minecraft:terracotta
fill 510 79 504 510 81 504 minecraft:red_terracotta
setblock 511 79 477 minecraft:terracotta
fill 511 79 478 511 80 478 minecraft:red_terracotta
setblock 511 79 493 minecraft:red_terracotta
setblock 511 79 497 minecraft:terracotta
fill 511 79 498 511 81 498 minecraft:red_terracotta
setblock 511 79 502 minecraft:terracotta
fill 511 79 503 511 81 503 minecraft:red_terracotta
setblock 471 80 477 minecraft:red_terracotta
setblock 471 80 481 minecraft:terracotta
fill 471 80 482 471 81 482 minecraft:red_terracotta
setblock 471 80 492 minecraft:red_terracotta
setblock 471 80 496 minecraft:terracotta
fill 471 80 497 471 81 497 minecraft:red_terracotta
setblock 471 80 501 minecraft:terracotta
fill 471 80 502 471 81 502 minecraft:red_terracotta
setblock 472 80 496 minecraft:red_terracotta
setblock 472 80 500 minecraft:terracotta
fill 472 80 501 472 81 501 minecraft:red_terracotta
setblock 473 80 504 minecraft:terracotta
fill 474 80 504 477 80 504 minecraft:red_terracotta
setblock 478 80 504 minecraft:terracotta
setblock 479 80 503 minecraft:terracotta
fill 479 80 504 479 81 504 minecraft:red_terracotta
fill 480 80 503 483 80 503 minecraft:red_terracotta
setblock 482 80 464 minecraft:red_terracotta
fill 482 80 477 482 80 479 minecraft:orange_concrete
setblock 483 80 464 minecraft:terracotta
setblock 483 80 504 minecraft:terracotta
fill 484 80 464 484 81 464 minecraft:red_terracotta
fill 484 80 475 486 80 475 minecraft:orange_concrete
fill 484 80 481 486 80 481 minecraft:orange_concrete
setblock 484 80 503 minecraft:terracotta
fill 484 80 504 484 81 504 minecraft:red_terracotta
fill 485 80 503 485 81 503 minecraft:red_terracotta
setblock 487 80 476 minecraft:orange_concrete
setblock 487 80 480 minecraft:orange_concrete
setblock 488 80 464 minecraft:terracotta
fill 488 80 477 488 80 479 minecraft:orange_concrete
setblock 488 80 504 minecraft:terracotta
setblock 489 80 464 minecraft:red_terracotta
fill 489 80 504 489 81 504 minecraft:red_terracotta
fill 492 80 481 492 80 484 minecraft:orange_concrete
setblock 493 80 480 minecraft:orange_concrete
setblock 493 80 485 minecraft:orange_concrete
fill 494 80 486 495 80 486 minecraft:orange_concrete
setblock 495 80 479 minecraft:orange_concrete
fill 496 80 501 496 81 501 minecraft:orange_concrete
fill 496 80 504 497 80 504 minecraft:red_terracotta
setblock 497 80 480 minecraft:orange_concrete
setblock 497 80 485 minecraft:orange_concrete
setblock 498 80 464 minecraft:terracotta
fill 498 80 481 498 80 484 minecraft:orange_concrete
setblock 498 80 503 minecraft:red_terracotta
setblock 498 80 504 minecraft:terracotta
fill 499 80 464 499 81 465 minecraft:red_terracotta
setblock 499 80 503 minecraft:terracotta
fill 499 80 504 499 81 504 minecraft:red_terracotta
setblock 500 80 502 minecraft:terracotta
fill 500 80 503 500 81 503 minecraft:red_terracotta
fill 501 80 502 501 81 502 minecraft:red_terracotta
setblock 502 80 465 minecraft:terracotta
fill 502 80 483 503 81 484 minecraft:orange_concrete
setblock 503 80 464 minecraft:terracotta
fill 503 80 465 503 81 465 minecraft:red_terracotta
setblock 503 80 504 minecraft:terracotta
fill 504 80 464 504 81 464 minecraft:red_terracotta
setblock 504 80 503 minecraft:terracotta
fill 504 80 504 504 81 504 minecraft:red_terracotta
setblock 505 80 502 minecraft:terracotta
fill 505 80 503 505 81 503 minecraft:red_terracotta
setblock 506 80 501 minecraft:terracotta
fill 506 80 502 506 81 502 minecraft:red_terracotta
setblock 507 80 465 minecraft:terracotta
setblock 507 80 501 minecraft:red_terracotta
setblock 508 80 464 minecraft:terracotta
setblock 508 80 465 minecraft:red_terracotta
setblock 508 80 504 minecraft:terracotta
fill 509 80 464 509 81 464 minecraft:red_terracotta
setblock 509 80 498 minecraft:terracotta
fill 509 80 499 509 81 499 minecraft:red_terracotta
setblock 509 80 503 minecraft:terracotta
fill 509 80 504 509 81 504 minecraft:red_terracotta
setblock 510 80 497 minecraft:terracotta
fill 510 80 498 510 81 498 minecraft:red_terracotta
setblock 510 80 502 minecraft:terracotta
fill 510 80 503 510 81 503 minecraft:red_terracotta
setblock 511 80 477 minecraft:red_terracotta
setblock 511 80 496 minecraft:terracotta
fill 511 80 497 511 81 497 minecraft:red_terracotta
setblock 511 80 501 minecraft:terracotta
fill 511 80 502 511 81 502 minecraft:red_terracotta
setblock 471 81 480 minecraft:terracotta
setblock 471 81 481 minecraft:red_terracotta
setblock 471 81 484 minecraft:red_terracotta
setblock 471 81 495 minecraft:terracotta
setblock 471 81 496 minecraft:red_terracotta
setblock 471 81 500 minecraft:terracotta
setblock 471 81 501 minecraft:red_terracotta
setblock 472 81 499 minecraft:terracotta
setblock 472 81 500 minecraft:red_terracotta
setblock 472 81 504 minecraft:terracotta
fill 473 81 504 476 81 504 minecraft:red_terracotta
setblock 477 81 504 minecraft:terracotta
setblock 478 81 504 minecraft:red_terracotta
fill 479 81 503 482 81 503 minecraft:red_terracotta
setblock 481 81 464 minecraft:red_terracotta
setblock 482 81 464 minecraft:terracotta
setblock 482 81 504 minecraft:terracotta
setblock 483 81 464 minecraft:red_terracotta
setblock 483 81 503 minecraft:terracotta
setblock 483 81 504 minecraft:red_terracotta
setblock 484 81 503 minecraft:red_terracotta
setblock 487 81 464 minecraft:terracotta
setblock 487 81 504 minecraft:terracotta
setblock 488 81 464 minecraft:red_terracotta
setblock 488 81 504 minecraft:red_terracotta
setblock 495 81 464 minecraft:red_terracotta
setblock 496 81 504 minecraft:red_terracotta
setblock 497 81 464 minecraft:terracotta
setblock 497 81 504 minecraft:terracotta
setblock 498 81 464 minecraft:red_terracotta
setblock 498 81 503 minecraft:terracotta
setblock 498 81 504 minecraft:red_terracotta
setblock 499 81 503 minecraft:red_terracotta
setblock 500 81 502 minecraft:red_terracotta
setblock 501 81 465 minecraft:terracotta
setblock 502 81 464 minecraft:terracotta
setblock 502 81 465 minecraft:red_terracotta
setblock 502 81 504 minecraft:terracotta
setblock 503 81 464 minecraft:red_terracotta
setblock 503 81 503 minecraft:terracotta
setblock 503 81 504 minecraft:red_terracotta
setblock 504 81 502 minecraft:terracotta
setblock 504 81 503 minecraft:red_terracotta
setblock 505 81 501 minecraft:terracotta
setblock 505 81 502 minecraft:red_terracotta
setblock 506 81 465 minecraft:terracotta
setblock 506 81 501 minecraft:red_terracotta
setblock 507 81 464 minecraft:terracotta
setblock 507 81 465 minecraft:red_terracotta
setblock 507 81 504 minecraft:terracotta
setblock 508 81 464 minecraft:red_terracotta
setblock 508 81 503 minecraft:terracotta
setblock 508 81 504 minecraft:red_terracotta
setblock 509 81 502 minecraft:terracotta
setblock 509 81 503 minecraft:red_terracotta
setblock 510 81 497 minecraft:red_terracotta
setblock 510 81 501 minecraft:terracotta
setblock 510 81 502 minecraft:red_terracotta
setblock 511 81 495 minecraft:terracotta
setblock 511 81 496 minecraft:red_terracotta
setblock 511 81 500 minecraft:terracotta
setblock 511 81 501 minecraft:red_terracotta
setblock 473 86 466 minecraft:light[level=14]
setblock 473 86 474 minecraft:light[level=14]
setblock 473 86 482 minecraft:light[level=14]
setblock 473 86 490 minecraft:light[level=14]
setblock 473 86 498 minecraft:light[level=14]
setblock 481 86 466 minecraft:light[level=14]
setblock 481 86 474 minecraft:light[level=14]
setblock 481 86 482 minecraft:light[level=14]
setblock 481 86 490 minecraft:light[level=14]
setblock 481 86 498 minecraft:light[level=14]
fill 488 86 492 490 86 494 minecraft:redstone_block
setblock 489 86 466 minecraft:light[level=14]
setblock 489 86 474 minecraft:light[level=14]
setblock 489 86 482 minecraft:light[level=14]
setblock 489 86 490 minecraft:light[level=14]
setblock 489 86 498 minecraft:light[level=14]
fill 496 86 486 498 86 488 minecraft:redstone_block
fill 496 86 492 498 86 494 minecraft:redstone_block
setblock 497 86 466 minecraft:light[level=14]
setblock 497 86 474 minecraft:light[level=14]
setblock 497 86 482 minecraft:light[level=14]
setblock 497 86 490 minecraft:light[level=14]
setblock 497 86 498 minecraft:light[level=14]
setblock 505 86 466 minecraft:light[level=14]
setblock 505 86 474 minecraft:light[level=14]
setblock 505 86 482 minecraft:light[level=14]
setblock 505 86 490 minecraft:light[level=14]
setblock 505 86 498 minecraft:light[level=14]
fill 471 87 464 471 88 471 minecraft:basalt
fill 471 87 472 471 88 472 minecraft:magma_block
fill 471 87 473 471 88 476 minecraft:basalt
fill 471 87 477 471 88 477 minecraft:magma_block
fill 471 87 478 474 88 481 minecraft:basalt
fill 471 87 482 471 88 482 minecraft:magma_block
fill 471 87 483 471 88 497 minecraft:basalt
fill 471 87 498 471 88 498 minecraft:magma_block
fill 471 87 499 474 88 502 minecraft:basalt
fill 471 87 503 471 88 503 minecraft:magma_block
fill 471 87 504 475 88 504 minecraft:basalt
fill 472 87 464 472 88 470 minecraft:basalt
fill 472 87 471 472 88 471 minecraft:magma_block
fill 472 87 472 472 88 475 minecraft:basalt
fill 472 87 476 472 88 476 minecraft:magma_block
fill 472 87 477 476 88 477 minecraft:basalt
fill 472 87 482 472 88 491 minecraft:basalt
fill 472 87 492 472 88 492 minecraft:magma_block
fill 472 87 493 472 88 496 minecraft:basalt
fill 472 87 497 472 88 497 minecraft:magma_block
fill 472 87 498 476 88 498 minecraft:basalt
fill 472 87 503 483 88 503 minecraft:basalt
fill 473 87 464 473 88 464 minecraft:basalt
fill 473 87 465 473 88 465 minecraft:magma_block
fill 473 87 466 473 88 469 minecraft:basalt
fill 473 87 470 473 88 470 minecraft:magma_block
fill 473 87 471 475 88 474 minecraft:basalt
fill 473 87 475 473 88 475 minecraft:magma_block
fill 473 87 476 484 88 476 minecraft:basalt
fill 473 87 482 473 88 485 minecraft:basalt
fill 473 87 486 473 88 486 minecraft:magma_block
fill 473 87 487 473 88 490 minecraft:basalt
fill 473 87 491 473 88 491 minecraft:magma_block
fill 473 87 492 475 88 495 minecraft:basalt
fill 473 87 496 473 88 496 minecraft:magma_block
fill 473 87 497 484 88 497 minecraft:basalt
fill 474 87 464 474 88 464 minecraft:magma_block
fill 474 87 465 476 88 468 minecraft:basalt
fill 474 87 469 474 88 469 minecraft:magma_block
fill 474 87 470 478 88 470 minecraft:basalt
fill 474 87 475 485 88 475 minecraft:basalt
fill 474 87 482 474 88 484 minecraft:basalt
fill 474 87 485 474 88 485 minecraft:magma_block
fill 474 87 486 477 88 489 minecraft:basalt
fill 474 87 490 474 88 490 minecraft:magma_block
fill 474 87 491 478 88 491 minecraft:basalt
fill 474 87 496 485 88 496 minecraft:basalt
fill 475 87 464 479 88 464 minecraft:basalt
fill 475 87 469 486 88 469 minecraft:basalt
fill 475 87 478 475 88 478 minecraft:basalt
fill 475 87 479 475 88 479 minecraft:magma_block
fill 475 87 480 475 88 483 minecraft:basalt
fill 475 87 484 475 88 484 minecraft:magma_block
fill 475 87 485 479 88 485 minecraft:basalt
fill 475 87 490 486 88 490 minecraft:basalt
fill 475 87 499 475 88 499 minecraft:basalt
fill 475 87 500 475 88 500 minecraft:magma_block
fill 475 87 501 478 88 502 minecraft:basalt
fill 476 87 471 476 88 472 minecraft:basalt
fill 476 87 473 476 88 473 minecraft:magma_block
fill 476 87 474 480 88 474 minecraft:basalt
fill 476 87 478 476 88 478 minecraft:magma_block
fill 476 87 479 478 88 482 minecraft:basalt
fill 476 87 483 476 88 483 minecraft:magma_block
fill 476 87 484 487 88 484 minecraft:basalt
fill 476 87 492 476 88 493 minecraft:basalt
fill 476 87 494 476 88 494 minecraft:magma_block
fill 476 87 495 480 88 495 minecraft:basalt
fill 476 87 499 476 88 499 minecraft:magma_block
fill 476 87 500 480 88 500 minecraft:basalt
fill 476 87 504 476 88 504 minecraft:magma_block
fill 477 87 465 477 88 466 minecraft:basalt
fill 477 87 467 477 88 467 minecraft:magma_block
fill 477 87 468 481 88 468 minecraft:basalt
fill 477 87 471 477 88 471 minecraft:basalt
fill 477 87 472 477 88 472 minecraft:magma_block
fill 477 87 473 481 88 473 minecraft:basalt
fill 477 87 477 477 88 477 minecraft:magma_block
fill 477 87 478 481 88 478 minecraft:basalt
fill 477 87 483 488 88 483 minecraft:basalt
fill 477 87 492 477 88 492 minecraft:basalt
fill 477 87 493 477 88 493 minecraft:magma_block
fill 477 87 494 481 88 494 minecraft:basalt
fill 477 87 498 477 88 498 minecraft:magma_block
fill 477 87 499 481 88 499 minecraft:basalt
fill 477 87 504 488 88 504 minecraft:basalt
fill 478 87 465 478 88 465 minecraft:basalt
fill 478 87 466 478 88 466 minecraft:magma_block
fill 478 87 467 482 88 467 minecraft:basalt
fill 478 87 471 478 88 471 minecraft:magma_block
fill 478 87 472 482 88 472 minecraft:basalt
fill 478 87 477 489 88 477 minecraft:basalt
fill 478 87 486 478 88 486 minecraft:basalt
fill 478 87 487 478 88 487 minecraft:magma_block
fill 478 87 488 481 88 489 minecraft:basalt
fill 478 87 492 478 88 492 minecraft:magma_block
fill 478 87 493 482 88 493 minecraft:basalt
fill 478 87 498 489 88 498 minecraft:basalt
fill 479 87 465 479 88 465 minecraft:magma_block
fill 479 87 466 483 88 466 minecraft:basalt
fill 479 87 470 479 88 470 minecraft:magma_block
fill 479 87 471 490 88 471 minecraft:basalt
fill 479 87 479 479 88 480 minecraft:basalt
fill 479 87 481 479 88 481 minecraft:magma_block
fill 479 87 482 483 88 482 minecraft:basalt
fill 479 87 486 479 88 486 minecraft:magma_block
fill 479 87 487 483 88 487 minecraft:basalt
fill 479 87 491 479 88 491 minecraft:magma_block
fill 479 87 492 487 87 492 minecraft:basalt
fill 479 87 501 479 88 501 minecraft:basalt
fill 479 87 502 479 88 502 minecraft:magma_block
fill 480 87 464 480 88 464 minecraft:magma_block
fill 480 87 465 484 88 465 minecraft:basalt
fill 480 87 470 491 88 470 minecraft:basalt
fill 480 87 479 480 88 479 minecraft:basalt
fill 480 87 480 480 88 480 minecraft:magma_block
fill 480 87 481 484 88 481 minecraft:basalt
fill 480 87 485 480 88 485 minecraft:magma_block
fill 480 87 486 484 88 486 minecraft:basalt
fill 480 87 491 491 87 491 minecraft:basalt
fill 480 87 501 480 88 501 minecraft:magma_block
fill 480 87 502 484 88 502 minecraft:basalt
fill 481 87 464 492 88 464 minecraft:basalt
fill 481 87 474 481 88 474 minecraft:magma_block
fill 481 87 479 481 88 479 minecraft:magma_block
fill 481 87 480 485 88 480 minecraft:basalt
fill 481 87 485 492 88 485 minecraft:basalt
fill 481 87 495 481 88 495 minecraft:magma_block
fill 481 87 500 481 88 500 minecraft:magma_block
fill 481 87 501 485 88 501 minecraft:basalt
fill 482 87 468 482 88 468 minecraft:magma_block
fill 482 87 473 482 88 473 minecraft:magma_block
fill 482 87 474 486 88 474 minecraft:basalt
fill 482 87 478 482 88 478 minecraft:magma_block
fill 482 87 479 493 88 479 minecraft:basalt
fill 482 87 488 482 88 488 minecraft:basalt
fill 482 87 489 482 88 489 minecraft:magma_block
fill 482 87 494 482 88 494 minecraft:magma_block
fill 482 87 495 486 88 495 minecraft:basalt
fill 482 87 499 482 88 499 minecraft:magma_block
fill 482 87 500 486 88 500 minecraft:basalt
fill 483 87 467 483 88 467 minecraft:magma_block
fill 483 87 468 487 88 468 minecraft:basalt
fill 483 87 472 483 88 472 minecraft:magma_block
fill 483 87 473 487 88 473 minecraft:basalt
fill 483 87 478 494 88 478 minecraft:basalt
fill 483 87 488 483 88 488 minecraft:magma_block
fill 483 87 489 487 88 489 minecraft:basalt
fill 483 87 493 483 88 493 minecraft:magma_block
fill 483 87 494 487 87 494 minecraft:basalt
fill 483 87 499 494 88 499 minecraft:basalt
fill 484 87 466 484 88 466 minecraft:magma_block
fill 484 87 467 488 88 467 minecraft:basalt
fill 484 87 472 495 88 472 minecraft:basalt
fill 484 87 482 484 88 482 minecraft:magma_block
fill 484 87 487 484 88 487 minecraft:magma_block
fill 484 87 488 488 88 488 minecraft:basalt
fill 484 87 493 487 87 493 minecraft:basalt
fill 484 87 503 484 88 503 minecraft:magma_block
fill 485 87 465 485 88 465 minecraft:magma_block
fill 485 87 466 496 88 466 minecraft:basalt
fill 485 87 476 485 88 476 minecraft:magma_block
fill 485 87 481 485 88 481 minecraft:magma_block
fill 485 87 482 489 88 482 minecraft:basalt
fill 485 87 486 485 88 486 minecraft:magma_block
fill 485 87 487 495 87 487 minecraft:basalt
fill 485 87 497 485 88 497 minecraft:magma_block
fill 485 87 502 485 88 502 minecraft:magma_block
fill 485 87 503 489 88 503 minecraft:basalt
fill 486 87 465 497 88 465 minecraft:basalt
fill 486 87 475 486 88 475 minecraft:magma_block
fill 486 87 476 490 88 476 minecraft:basalt
fill 486 87 480 486 88 480 minecraft:magma_block
fill 486 87 481 490 88 481 minecraft:basalt
fill 486 87 486 495 87 486 minecraft:basalt
fill 486 87 496 486 88 496 minecraft:magma_block
fill 486 87 497 490 88 497 minecraft:basalt
fill 486 87 501 486 88 501 minecraft:magma_block
fill 486 87 502 490 88 502 minecraft:basalt
fill 487 87 469 487 88 469 minecraft:magma_block
fill 487 87 474 487 88 474 minecraft:magma_block
fill 487 87 475 491 88 475 minecraft:basalt
fill 487 87 480 498 88 480 minecraft:basalt
fill 487 87 490 487 88 490 minecraft:magma_block
setblock 487 87 495 minecraft:magma_block
fill 487 87 496 491 88 496 minecraft:basalt
fill 487 87 500 487 88 500 minecraft:magma_block
fill 487 87 501 498 88 501 minecraft:basalt
fill 488 87 468 488 88 468 minecraft:magma_block
fill 488 87 469 492 88 469 minecraft:basalt
fill 488 87 473 488 88 473 minecraft:magma_block
fill 488 87 474 499 88 474 minecraft:basalt
fill 488 87 484 488 88 484 minecraft:magma_block
fill 488 87 489 488 88 489 minecraft:magma_block
fill 488 87 490 491 87 490 minecraft:basalt
fill 488 87 495 492 87 495 minecraft:basalt
fill 488 87 500 499 88 500 minecraft:basalt
fill 489 87 467 489 88 467 minecraft:magma_block
fill 489 87 468 493 88 468 minecraft:basalt
fill 489 87 473 500 88 473 minecraft:basalt
fill 489 87 483 489 88 483 minecraft:magma_block
fill 489 87 484 493 88 484 minecraft:basalt
fill 489 87 488 489 88 488 minecraft:magma_block
fill 489 87 489 491 87 489 minecraft:basalt
fill 489 87 504 489 88 504 minecraft:magma_block
fill 490 87 467 501 88 467 minecraft:basalt
fill 490 87 477 490 88 477 minecraft:magma_block
fill 490 87 482 490 88 482 minecraft:magma_block
fill 490 87 483 494 88 483 minecraft:basalt
fill 490 87 488 495 87 488 minecraft:basalt
fill 490 87 498 490 88 498 minecraft:magma_block
fill 490 87 503 490 88 503 minecraft:magma_block
fill 490 87 504 494 88 504 minecraft:basalt
fill 491 87 471 491 88 471 minecraft:magma_block
fill 491 87 476 491 88 476 minecraft:magma_block
fill 491 87 477 495 88 477 minecraft:basalt
fill 491 87 481 491 88 481 minecraft:magma_block
fill 491 87 482 502 88 482 minecraft:basalt
setblock 491 87 492 minecraft:magma_block
fill 491 87 493 495 87 494 minecraft:basalt
fill 491 87 497 491 88 497 minecraft:magma_block
fill 491 87 498 495 88 498 minecraft:basalt
fill 491 87 502 491 88 502 minecraft:magma_block
fill 491 87 503 495 88 503 minecraft:basalt
fill 492 87 470 492 88 470 minecraft:magma_block
fill 492 87 471 496 88 471 minecraft:basalt
fill 492 87 475 492 88 475 minecraft:magma_block
fill 492 87 476 496 88 476 minecraft:basalt
fill 492 87 481 503 88 481 minecraft:basalt
fill 492 87 492 495 87 492 minecraft:basalt
fill 492 87 496 492 88 496 minecraft:magma_block
fill 492 87 497 496 88 497 minecraft:basalt
fill 492 87 502 503 88 502 minecraft:basalt
fill 493 87 464 493 88 464 minecraft:magma_block
fill 493 87 469 493 88 469 minecraft:magma_block
fill 493 87 470 497 88 470 minecraft:basalt
fill 493 87 475 504 88 475 minecraft:basalt
fill 493 87 485 493 88 485 minecraft:magma_block
fill 493 87 495 493 88 495 minecraft:magma_block
fill 493 87 496 504 88 496 minecraft:basalt
fill 494 87 464 498 88 464 minecraft:basalt
fill 494 87 468 494 88 468 minecraft:magma_block
fill 494 87 469 505 88 469 minecraft:basalt
fill 494 87 479 494 88 479 minecraft:magma_block
fill 494 87 484 494 88 484 minecraft:magma_block
fill 494 87 485 498 87 485 minecraft:basalt
fill 494 87 495 505 87 495 minecraft:basalt
fill 495 87 468 506 88 468 minecraft:basalt
fill 495 87 478 495 88 478 minecraft:magma_block
fill 495 87 479 499 88 479 minecraft:basalt
fill 495 87 483 495 88 483 minecraft:magma_block
fill 495 87 484 499 88 484 minecraft:basalt
fill 495 87 489 497 87 491 minecraft:basalt
fill 495 87 499 495 88 499 minecraft:magma_block
fill 495 87 504 495 88 504 minecraft:magma_block
fill 496 87 472 496 88 472 minecraft:magma_block
fill 496 87 477 496 88 477 minecraft:magma_block
fill 496 87 478 500 88 478 minecraft:basalt
fill 496 87 483 507 88 483 minecraft:basalt
fill 496 87 498 496 88 498 minecraft:magma_block
fill 496 87 499 500 88 499 minecraft:basalt
fill 496 87 503 496 88 503 minecraft:magma_block
fill 496 87 504 507 88 504 minecraft:basalt
fill 497 87 466 497 88 466 minecraft:magma_block
fill 497 87 471 497 88 471 minecraft:magma_block
fill 497 87 472 501 88 472 minecraft:basalt
fill 497 87 476 497 88 476 minecraft:magma_block
fill 497 87 477 508 88 477 minecraft:basalt
fill 497 87 497 497 88 497 minecraft:magma_block
fill 497 87 498 501 88 498 minecraft:basalt
fill 497 87 503 508 88 503 minecraft:basalt
fill 498 87 465 498 88 465 minecraft:magma_block
fill 498 87 466 502 88 466 minecraft:basalt
fill 498 87 470 498 88 470 minecraft:magma_block
fill 498 87 471 502 88 471 minecraft:basalt
fill 498 87 476 509 88 476 minecraft:basalt
fill 498 87 489 498 87 490 minecraft:basalt
setblock 498 87 491 minecraft:magma_block
fill 498 87 497 509 88 497 minecraft:basalt
fill 499 87 464 499 88 464 minecraft:magma_block
fill 499 87 465 503 88 465 minecraft:basalt
fill 499 87 470 510 88 470 minecraft:basalt
fill 499 87 480 499 88 480 minecraft:magma_block
setblock 499 87 485 minecraft:magma_block
fill 499 87 486 501 87 489 minecraft:basalt
fill 499 87 490 499 88 490 minecraft:magma_block
fill 499 87 491 500 87 494 minecraft:basalt
fill 499 87 501 499 88 501 minecraft:magma_block
fill 500 87 464 511 88 464 minecraft:basalt
fill 500 87 474 500 88 474 minecraft:magma_block
fill 500 87 479 500 88 479 minecraft:magma_block
fill 500 87 480 504 88 480 minecraft:basalt
fill 500 87 484 500 88 484 minecraft:magma_block
fill 500 87 485 504 88 485 minecraft:basalt
fill 500 87 490 511 88 490 minecraft:basalt
fill 500 87 500 500 88 500 minecraft:magma_block
fill 500 87 501 504 88 501 minecraft:basalt
fill 501 87 473 501 88 473 minecraft:magma_block
fill 501 87 474 505 88 474 minecraft:basalt
fill 501 87 478 501 88 478 minecraft:magma_block
fill 501 87 479 505 88 479 minecraft:basalt
fill 501 87 484 511 88 484 minecraft:basalt
fill 501 87 491 501 88 493 minecraft:basalt
fill 501 87 494 501 88 494 minecraft:magma_block
fill 501 87 499 501 88 499 minecraft:magma_block
fill 501 87 500 505 88 500 minecraft:basalt
fill 502 87 467 502 88 467 minecraft:magma_block
fill 502 87 472 502 88 472 minecraft:magma_block
fill 502 87 473 506 88 473 minecraft:basalt
fill 502 87 478 511 88 478 minecraft:basalt
fill 502 87 486 502 88 487 minecraft:basalt
fill 502 87 488 502 88 488 minecraft:magma_block
fill 502 87 489 506 88 489 minecraft:basalt
fill 502 87 491 502 88 492 minecraft:basalt
fill 502 87 493 502 88 493 minecraft:magma_block
fill 502 87 494 506 88 494 minecraft:basalt
fill 502 87 498 502 88 498 minecraft:magma_block
fill 502 87 499 511 88 499 minecraft:basalt
fill 503 87 466 503 88 466 minecraft:magma_block
fill 503 87 467 507 88 467 minecraft:basalt
fill 503 87 471 503 88 471 minecraft:magma_block
fill 503 87 472 511 88 472 minecraft:basalt
fill 503 87 482 503 88 482 minecraft:magma_block
fill 503 87 486 503 88 486 minecraft:basalt
fill 503 87 487 503 88 487 minecraft:magma_block
fill 503 87 488 507 88 488 minecraft:basalt
fill 503 87 491 510 88 491 minecraft:basalt
fill 503 87 492 503 88 492 minecraft:magma_block
fill 503 87 493 507 88 493 minecraft:basalt
fill 503 87 498 511 88 498 minecraft:basalt
fill 504 87 465 504 88 465 minecraft:magma_block
fill 504 87 466 508 88 466 minecraft:basalt
fill 504 87 471 511 88 471 minecraft:basalt
fill 504 87 481 504 88 481 minecraft:magma_block
fill 504 87 482 508 88 482 minecraft:basalt
fill 504 87 486 504 88 486 minecraft:magma_block
fill 504 87 487 508 88 487 minecraft:basalt
fill 504 87 492 511 88 492 minecraft:basalt
fill 504 87 502 504 88 502 minecraft:magma_block
fill 505 87 465 511 88 465 minecraft:basalt
fill 505 87 475 505 88 475 minecraft:magma_block
fill 505 87 480 505 88 480 minecraft:magma_block
fill 505 87 481 509 88 481 minecraft:basalt
fill 505 87 485 505 88 485 minecraft:magma_block
fill 505 87 486 511 88 486 minecraft:basalt
fill 505 87 496 505 88 496 minecraft:magma_block
fill 505 87 501 505 88 501 minecraft:magma_block
fill 505 87 502 509 88 502 minecraft:basalt
fill 506 87 469 506 88 469 minecraft:magma_block
fill 506 87 474 506 88 474 minecraft:magma_block
fill 506 87 475 510 88 475 minecraft:basalt
fill 506 87 479 506 88 479 minecraft:magma_block
fill 506 87 480 510 88 480 minecraft:basalt
fill 506 87 485 511 88 485 minecraft:basalt
fill 506 87 495 506 88 495 minecraft:magma_block
fill 506 87 496 510 88 496 minecraft:basalt
fill 506 87 500 506 88 500 minecraft:magma_block
fill 506 87 501 510 88 501 minecraft:basalt
fill 507 87 468 507 88 468 minecraft:magma_block
fill 507 87 469 511 88 469 minecraft:basalt
fill 507 87 473 507 88 473 minecraft:magma_block
fill 507 87 474 511 88 474 minecraft:basalt
fill 507 87 479 511 88 479 minecraft:basalt
fill 507 87 489 507 88 489 minecraft:magma_block
fill 507 87 494 507 88 494 minecraft:magma_block
fill 507 87 495 511 88 495 minecraft:basalt
fill 507 87 500 511 88 500 minecraft:basalt
fill 508 87 467 508 88 467 minecraft:magma_block
fill 508 87 468 511 88 468 minecraft:basalt
fill 508 87 473 511 88 473 minecraft:basalt
fill 508 87 483 508 88 483 minecraft:magma_block
fill 508 87 488 508 88 488 minecraft:magma_block
fill 508 87 489 511 88 489 minecraft:basalt
fill 508 87 493 508 88 493 minecraft:magma_block
fill 508 87 494 511 88 494 minecraft:basalt
fill 508 87 504 508 88 504 minecraft:magma_block
fill 509 87 466 509 88 466 minecraft:magma_block
fill 509 87 467 511 88 467 minecraft:basalt
fill 509 87 477 509 88 477 minecraft:magma_block
fill 509 87 482 509 88 482 minecraft:magma_block
fill 509 87 483 511 88 483 minecraft:basalt
fill 509 87 487 509 88 487 minecraft:magma_block
fill 509 87 488 511 88 488 minecraft:basalt
fill 509 87 493 511 88 493 minecraft:basalt
fill 509 87 503 509 88 503 minecraft:magma_block
fill 509 87 504 511 88 504 minecraft:basalt
fill 510 87 466 511 88 466 minecraft:basalt
fill 510 87 476 510 88 476 minecraft:magma_block
fill 510 87 477 511 88 477 minecraft:basalt
fill 510 87 481 510 88 481 minecraft:magma_block
fill 510 87 482 511 88 482 minecraft:basalt
fill 510 87 487 511 88 487 minecraft:basalt
fill 510 87 497 510 88 497 minecraft:magma_block
fill 510 87 502 510 88 502 minecraft:magma_block
fill 510 87 503 511 88 503 minecraft:basalt
fill 511 87 470 511 88 470 minecraft:magma_block
fill 511 87 475 511 88 475 minecraft:magma_block
fill 511 87 476 511 88 476 minecraft:basalt
fill 511 87 480 511 88 480 minecraft:magma_block
fill 511 87 481 511 88 481 minecraft:basalt
fill 511 87 491 511 88 491 minecraft:magma_block
fill 511 87 496 511 88 496 minecraft:magma_block
fill 511 87 497 511 88 497 minecraft:basalt
fill 511 87 501 511 88 501 minecraft:magma_block
fill 511 87 502 511 88 502 minecraft:basalt
fill 479 88 492 486 88 492 minecraft:basalt
fill 480 88 491 486 88 491 minecraft:basalt
fill 483 88 494 486 88 494 minecraft:basalt
fill 484 88 493 486 88 493 minecraft:basalt
fill 485 88 487 494 88 487 minecraft:basalt
fill 486 88 486 494 88 486 minecraft:basalt
fill 487 88 491 487 88 495 minecraft:shroomlight
fill 488 88 490 490 88 490 minecraft:basalt
fill 488 88 491 491 88 491 minecraft:shroomlight
fill 488 88 492 490 88 494 minecraft:basalt
fill 488 88 495 491 88 495 minecraft:shroomlight
fill 489 88 489 490 88 489 minecraft:basalt
setblock 490 88 488 minecraft:basalt
fill 491 88 488 491 88 490 minecraft:shroomlight
fill 491 88 492 491 88 494 minecraft:shroomlight
fill 492 88 488 495 88 488 minecraft:shroomlight
fill 492 88 492 495 88 492 minecraft:shroomlight
fill 492 88 493 492 88 495 minecraft:basalt
fill 493 88 493 494 88 494 minecraft:basalt
setblock 494 88 485 minecraft:basalt
setblock 494 88 495 minecraft:basalt
fill 495 88 485 495 88 487 minecraft:shroomlight
fill 495 88 489 495 88 491 minecraft:shroomlight
fill 495 88 493 495 88 495 minecraft:shroomlight
fill 496 88 485 499 88 485 minecraft:shroomlight
fill 496 88 486 498 88 488 minecraft:basalt
fill 496 88 489 499 88 489 minecraft:shroomlight
fill 496 88 490 498 88 490 minecraft:basalt
fill 496 88 491 499 88 491 minecraft:shroomlight
fill 496 88 492 498 88 494 minecraft:basalt
fill 496 88 495 499 88 495 minecraft:shroomlight
fill 499 88 486 499 88 488 minecraft:shroomlight
fill 499 88 492 499 88 494 minecraft:shroomlight
fill 500 88 486 501 88 489 minecraft:basalt
fill 500 88 491 500 88 495 minecraft:basalt
fill 501 88 495 505 88 495 minecraft:basalt
setblock 471 92 464 minecraft:terracotta
fill 471 92 465 471 92 468 minecraft:red_terracotta
setblock 471 92 469 minecraft:terracotta
fill 471 92 470 471 93 472 minecraft:red_terracotta
fill 471 92 477 471 92 478 minecraft:red_terracotta
setblock 471 92 479 minecraft:terracotta
fill 471 92 480 471 92 483 minecraft:red_terracotta
setblock 471 92 484 minecraft:terracotta
fill 471 92 485 471 92 488 minecraft:red_terracotta
setblock 471 92 489 minecraft:terracotta
fill 471 92 490 471 92 493 minecraft:red_terracotta
setblock 471 92 494 minecraft:terracotta
fill 471 92 495 471 94 496 minecraft:red_terracotta
setblock 471 92 503 minecraft:red_terracotta
setblock 471 92 504 minecraft:terracotta
fill 472 92 464 472 92 467 minecraft:red_terracotta
setblock 472 92 468 minecraft:terracotta
fill 472 92 469 472 95 469 minecraft:red_terracotta
fill 472 92 480 472 92 482 minecraft:red_terracotta
setblock 472 92 483 minecraft:terracotta
fill 472 92 484 472 92 487 minecraft:red_terracotta
setblock 472 92 488 minecraft:terracotta
fill 472 92 489 472 92 492 minecraft:red_terracotta
setblock 472 92 493 minecraft:terracotta
fill 472 92 494 472 95 494 minecraft:red_terracotta
fill 472 92 504 475 92 504 minecraft:red_terracotta
fill 473 92 464 474 92 465 minecraft:red_terracotta
setblock 473 92 481 minecraft:red_terracotta
setblock 473 92 482 minecraft:terracotta
fill 473 92 483 473 92 486 minecraft:red_terracotta
setblock 473 92 487 minecraft:terracotta
fill 473 92 488 473 92 491 minecraft:red_terracotta
setblock 473 92 492 minecraft:terracotta
setblock 474 92 466 minecraft:terracotta
fill 474 92 483 474 92 485 minecraft:red_terracotta
setblock 474 92 486 minecraft:terracotta
fill 474 92 487 474 92 490 minecraft:red_terracotta
setblock 475 92 464 minecraft:red_terracotta
setblock 475 92 465 minecraft:terracotta
fill 475 92 466 478 92 466 minecraft:red_terracotta
fill 475 92 486 475 92 487 minecraft:red_terracotta
setblock 476 92 464 minecraft:terracotta
fill 476 92 465 479 92 465 minecraft:red_terracotta
setblock 476 92 504 minecraft:terracotta
fill 477 92 464 480 92 464 minecraft:red_terracotta
setblock 477 92 467 minecraft:red_terracotta
fill 477 92 504 480 92 504 minecraft:red_terracotta
setblock 478 92 467 minecraft:terracotta
setblock 479 92 466 minecraft:terracotta
fill 479 92 467 480 92 467 minecraft:red_terracotta
setblock 480 92 465 minecraft:terracotta
fill 480 92 466 483 92 466 minecraft:red_terracotta
setblock 481 92 464 minecraft:terracotta
fill 481 92 465 484 92 465 minecraft:red_terracotta
setblock 481 92 504 minecraft:terracotta
fill 482 92 464 485 92 464 minecraft:red_terracotta
fill 482 92 504 483 92 504 minecraft:red_terracotta
setblock 484 92 466 minecraft:terracotta
setblock 485 92 465 minecraft:terracotta
fill 485 92 466 488 92 466 minecraft:red_terracotta
setblock 486 92 464 minecraft:terracotta
fill 486 92 465 489 92 465 minecraft:red_terracotta
fill 487 92 464 490 92 464 minecraft:red_terracotta
setblock 489 92 466 minecraft:terracotta
fill 489 92 504 490 92 504 minecraft:red_terracotta
setblock 490 92 465 minecraft:terracotta
fill 490 92 466 493 92 466 minecraft:red_terracotta
setblock 491 92 464 minecraft:terracotta
fill 491 92 465 494 92 465 minecraft:red_terracotta
setblock 491 92 504 minecraft:terracotta
fill 492 92 464 495 92 464 minecraft:red_terracotta
setblock 492 92 467 minecraft:red_terracotta
fill 492 92 504 495 92 504 minecraft:red_terracotta
setblock 493 92 467 minecraft:terracotta
fill 493 92 503 496 92 503 minecraft:red_terracotta
setblock 494 92 466 minecraft:terracotta
fill 494 92 467 497 92 467 minecraft:red_terracotta
setblock 495 92 465 minecraft:terracotta
fill 495 92 466 498 92 466 minecraft:red_terracotta
setblock 496 92 464 minecraft:terracotta
fill 496 92 465 499 92 465 minecraft:red_terracotta
fill 496 92 502 497 92 502 minecraft:red_terracotta
setblock 496 92 504 minecraft:terracotta
fill 497 92 464 500 92 464 minecraft:red_terracotta
setblock 497 92 503 minecraft:terracotta
fill 497 92 504 500 92 504 minecraft:red_terracotta
setblock 498 92 467 minecraft:terracotta
setblock 498 92 502 minecraft:terracotta
fill 498 92 503 501 92 503 minecraft:red_terracotta
setblock 499 92 466 minecraft:terracotta
fill 499 92 467 500 93 467 minecraft:red_terracotta
fill 499 92 502 501 92 502 minecraft:red_terracotta
setblock 500 92 465 minecraft:terracotta
fill 500 92 466 503 92 466 minecraft:red_terracotta
setblock 501 92 464 minecraft:terracotta
fill 501 92 465 504 92 465 minecraft:red_terracotta
setblock 501 92 504 minecraft:terracotta
fill 502 92 464 505 92 464 minecraft:red_terracotta
setblock 502 92 503 minecraft:terracotta
fill 502 92 504 505 92 504 minecraft:red_terracotta
fill 503 92 503 505 92 503 minecraft:red_terracotta
setblock 505 92 465 minecraft:terracotta
setblock 506 92 464 minecraft:terracotta
setblock 506 92 465 minecraft:red_terracotta
setblock 506 92 504 minecraft:terracotta
fill 507 92 464 510 92 464 minecraft:red_terracotta
fill 507 92 504 510 92 504 minecraft:red_terracotta
setblock 510 92 485 minecraft:terracotta
fill 510 92 486 510 92 489 minecraft:red_terracotta
setblock 510 92 490 minecraft:terracotta
fill 510 92 491 510 92 494 minecraft:red_terracotta
setblock 511 92 464 minecraft:terracotta
fill 511 92 465 511 92 468 minecraft:red_terracotta
setblock 511 92 469 minecraft:terracotta
fill 511 92 481 511 92 483 minecraft:red_terracotta
setblock 511 92 484 minecraft:terracotta
fill 511 92 485 511 92 488 minecraft:red_terracotta
setblock 511 92 489 minecraft:terracotta
fill 511 92 490 511 92 493 minecraft:red_terracotta
setblock 511 92 494 minecraft:terracotta
fill 511 92 495 511 92 498 minecraft:red_terracotta
setblock 511 92 499 minecraft:terracotta
fill 511 92 500 511 92 503 minecraft:red_terracotta
setblock 511 92 504 minecraft:terracotta
fill 471 93 464 471 93 467 minecraft:red_terracotta
setblock 471 93 468 minecraft:terracotta
fill 471 93 469 471 96 469 minecraft:red_terracotta
setblock 471 93 473 minecraft:terracotta
fill 471 93 474 471 93 477 minecraft:red_terracotta
setblock 471 93 478 minecraft:terracotta
fill 471 93 479 471 93 482 minecraft:red_terracotta
setblock 471 93 483 minecraft:terracotta
fill 471 93 484 471 93 487 minecraft:red_terracotta
setblock 471 93 488 minecraft:terracotta
fill 471 93 489 471 93 492 minecraft:red_terracotta
setblock 471 93 493 minecraft:terracotta
fill 471 93 494 471 96 494 minecraft:red_terracotta
setblock 471 93 497 minecraft:red_terracotta
fill 472 93 464 472 93 466 minecraft:red_terracotta
setblock 472 93 467 minecraft:terracotta
fill 472 93 468 472 96 468 minecraft:red_terracotta
fill 472 93 470 472 93 471 minecraft:red_terracotta
setblock 472 93 472 minecraft:terracotta
fill 472 93 479 472 93 481 minecraft:red_terracotta
setblock 472 93 482 minecraft:terracotta
fill 472 93 483 472 93 486 minecraft:red_terracotta
setblock 472 93 487 minecraft:terracotta
fill 472 93 488 472 93 491 minecraft:red_terracotta
setblock 472 93 492 minecraft:terracotta
fill 472 93 493 473 95 493 minecraft:red_terracotta
fill 472 93 495 472 94 495 minecraft:red_terracotta
fill 472 93 504 474 93 504 minecraft:red_terracotta
fill 473 93 464 473 93 465 minecraft:red_terracotta
setblock 473 93 481 minecraft:terracotta
fill 473 93 482 473 93 485 minecraft:red_terracotta
setblock 473 93 486 minecraft:terracotta
fill 473 93 487 473 93 490 minecraft:red_terracotta
setblock 473 93 491 minecraft:terracotta
fill 473 93 492 473 96 492 minecraft:red_terracotta
setblock 474 93 464 minecraft:red_terracotta
setblock 474 93 465 minecraft:terracotta
fill 474 93 466 477 93 466 minecraft:red_terracotta
fill 474 93 483 474 93 484 minecraft:red_terracotta
setblock 474 93 485 minecraft:terracotta
fill 474 93 486 474 93 489 minecraft:red_terracotta
setblock 474 93 490 minecraft:terracotta
fill 474 93 491 474 95 491 minecraft:red_terracotta
setblock 475 93 464 minecraft:terracotta
fill 475 93 465 478 93 465 minecraft:red_terracotta
setblock 475 93 504 minecraft:terracotta
fill 476 93 464 479 93 464 minecraft:red_terracotta
fill 476 93 504 479 93 504 minecraft:red_terracotta
setblock 477 93 467 minecraft:terracotta
setblock 478 93 466 minecraft:terracotta
fill 478 93 467 479 93 467 minecraft:red_terracotta
setblock 479 93 465 minecraft:terracotta
fill 479 93 466 482 93 466 minecraft:red_terracotta
setblock 480 93 464 minecraft:terracotta
fill 480 93 465 483 93 465 minecraft:red_terracotta
setblock 480 93 504 minecraft:terracotta
fill 481 93 464 484 93 464 minecraft:red_terracotta
setblock 481 93 504 minecraft:red_terracotta
setblock 483 93 466 minecraft:terracotta
setblock 484 93 465 minecraft:terracotta
setblock 484 93 466 minecraft:red_terracotta
setblock 485 93 464 minecraft:terracotta
fill 485 93 465 488 93 465 minecraft:red_terracotta
fill 486 93 464 489 93 464 minecraft:red_terracotta
setblock 487 93 466 minecraft:red_terracotta
setblock 488 93 466 minecraft:terracotta
setblock 489 93 465 minecraft:terracotta
fill 489 93 466 492 93 466 minecraft:red_terracotta
setblock 489 93 504 minecraft:red_terracotta
setblock 490 93 464 minecraft:terracotta
fill 490 93 465 493 93 465 minecraft:red_terracotta
setblock 490 93 504 minecraft:terracotta
fill 491 93 464 494 93 464 minecraft:red_terracotta
fill 491 93 504 494 93 504 minecraft:red_terracotta
setblock 492 93 467 minecraft:terracotta
setblock 493 93 466 minecraft:terracotta
fill 493 93 467 496 93 467 minecraft:red_terracotta
fill 493 93 503 495 93 503 minecraft:red_terracotta
setblock 494 93 465 minecraft:terracotta
fill 494 93 466 497 93 466 minecraft:red_terracotta
setblock 495 93 464 minecraft:terracotta
fill 495 93 465 498 93 465 minecraft:red_terracotta
setblock 495 93 504 minecraft:terracotta
fill 496 93 464 499 93 464 minecraft:red_terracotta
fill 496 93 492 498 94 492 minecraft:orange_concrete
setblock 496 93 502 minecraft:red_terracotta
setblock 496 93 503 minecraft:terracotta
fill 496 93 504 499 93 504 minecraft:red_terracotta
setblock 497 93 467 minecraft:terracotta
fill 497 93 491 497 94 491 minecraft:orange_concrete
fill 497 93 493 497 94 493 minecraft:orange_concrete
setblock 497 93 502 minecraft:terracotta
fill 497 93 503 500 93 503 minecraft:red_terracotta
setblock 498 93 466 minecraft:terracotta
fill 498 93 467 498 94 467 minecraft:red_terracotta
fill 498 93 502 499 93 502 minecraft:red_terracotta
setblock 499 93 465 minecraft:terracotta
fill 499 93 466 502 93 466 minecraft:red_terracotta
setblock 500 93 464 minecraft:terracotta
fill 500 93 465 503 93 465 minecraft:red_terracotta
setblock 500 93 504 minecraft:terracotta
fill 501 93 464 504 93 464 minecraft:red_terracotta
setblock 501 93 503 minecraft:terracotta
fill 501 93 504 504 93 504 minecraft:red_terracotta
fill 502 93 503 504 93 503 minecraft:red_terracotta
setblock 504 93 465 minecraft:terracotta
setblock 505 93 464 minecraft:terracotta
setblock 505 93 465 minecraft:red_terracotta
setblock 505 93 504 minecraft:terracotta
fill 506 93 464 509 93 464 minecraft:red_terracotta
fill 506 93 504 509 93 504 minecraft:red_terracotta
setblock 510 93 464 minecraft:terracotta
fill 510 93 485 510 93 488 minecraft:red_terracotta
setblock 510 93 489 minecraft:terracotta
fill 510 93 490 510 93 493 minecraft:red_terracotta
setblock 510 93 494 minecraft:terracotta
fill 510 93 495 511 95 495 minecraft:red_terracotta
setblock 510 93 504 minecraft:terracotta
fill 511 93 464 511 93 467 minecraft:red_terracotta
setblock 511 93 468 minecraft:terracotta
fill 511 93 469 511 95 470 minecraft:red_terracotta
fill 511 93 481 511 93 482 minecraft:red_terracotta
setblock 511 93 483 minecraft:terracotta
fill 511 93 484 511 93 487 minecraft:red_terracotta
setblock 511 93 488 minecraft:terracotta
fill 511 93 489 511 93 492 minecraft:red_terracotta
setblock 511 93 493 minecraft:terracotta
fill 511 93 494 511 96 494 minecraft:red_terracotta
fill 511 93 496 511 93 497 minecraft:red_terracotta
setblock 511 93 498 minecraft:terracotta
fill 511 93 499 511 93 502 minecraft:red_terracotta
setblock 511 93 503 minecraft:terracotta
fill 511 93 504 511 95 504 minecraft:red_terracotta
fill 471 94 464 471 94 466 minecraft:red_terracotta
setblock 471 94 467 minecraft:terracotta
fill 471 94 468 471 97 468 minecraft:red_terracotta
fill 471 94 470 471 94 471 minecraft:red_terracotta
setblock 471 94 472 minecraft:terracotta
fill 471 94 473 471 94 476 minecraft:red_terracotta
setblock 471 94 477 minecraft:terracotta
fill 471 94 478 471 94 481 minecraft:red_terracotta
setblock 471 94 482 minecraft:terracotta
fill 471 94 483 471 94 486 minecraft:red_terracotta
setblock 471 94 487 minecraft:terracotta
fill 471 94 488 471 94 491 minecraft:red_terracotta
setblock 471 94 492 minecraft:terracotta
fill 471 94 493 471 97 493 minecraft:red_terracotta
setblock 471 94 497 minecraft:terracotta
fill 472 94 464 472 94 465 minecraft:red_terracotta
setblock 472 94 466 minecraft:terracotta
fill 472 94 467 473 95 467 minecraft:red_terracotta
setblock 472 94 470 minecraft:red_terracotta
setblock 472 94 471 minecraft:terracotta
fill 472 94 472 472 95 474 minecraft:red_terracotta
fill 472 94 479 472 94 480 minecraft:red_terracotta
setblock 472 94 481 minecraft:terracotta
fill 472 94 482 472 94 485 minecraft:red_terracotta
setblock 472 94 486 minecraft:terracotta
fill 472 94 487 472 94 490 minecraft:red_terracotta
setblock 472 94 491 minecraft:terracotta
fill 472 94 492 472 97 492 minecraft:red_terracotta
setblock 473 94 464 minecraft:red_terracotta
setblock 473 94 465 minecraft:terracotta
setblock 473 94 466 minecraft:light[level=14]
fill 473 94 468 473 94 469 minecraft:red_terracotta
setblock 473 94 470 minecraft:terracotta
setblock 473 94 474 minecraft:light[level=14]
fill 473 94 482 473 94 484 minecraft:red_terracotta
setblock 473 94 485 minecraft:terracotta
fill 473 94 486 473 94 489 minecraft:red_terracotta
setblock 473 94 490 minecraft:terracotta
fill 473 94 491 473 97 491 minecraft:red_terracotta
setblock 473 94 498 minecraft:light[level=14]
setblock 473 94 504 minecraft:red_terracotta
setblock 474 94 464 minecraft:terracotta
fill 474 94 465 476 94 466 minecraft:red_terracotta
setblock 474 94 484 minecraft:terracotta
fill 474 94 485 474 94 488 minecraft:red_terracotta
setblock 474 94 489 minecraft:terracotta
fill 474 94 490 474 95 490 minecraft:red_terracotta
setblock 474 94 504 minecraft:terracotta
fill 475 94 464 478 94 464 minecraft:red_terracotta
fill 475 94 504 478 94 504 minecraft:red_terracotta
setblock 477 94 465 minecraft:red_terracotta
setblock 477 94 466 minecraft:terracotta
fill 477 94 467 478 94 467 minecraft:red_terracotta
setblock 478 94 465 minecraft:terracotta
fill 478 94 466 481 94 466 minecraft:red_terracotta
setblock 479 94 464 minecraft:terracotta
fill 479 94 465 482 94 465 minecraft:red_terracotta
setblock 479 94 504 minecraft:terracotta
fill 480 94 464 483 94 464 minecraft:red_terracotta
setblock 481 94 474 minecraft:light[level=14]
setblock 481 94 482 minecraft:light[level=14]
setblock 481 94 490 minecraft:light[level=14]
setblock 481 94 498 minecraft:light[level=14]
setblock 482 94 466 minecraft:terracotta
setblock 483 94 465 minecraft:terracotta
setblock 484 94 464 minecraft:terracotta
fill 484 94 465 487 94 465 minecraft:red_terracotta
fill 485 94 464 488 94 464 minecraft:red_terracotta
setblock 488 94 465 minecraft:terracotta
fill 488 94 466 491 94 466 minecraft:red_terracotta
setblock 489 94 464 minecraft:terracotta
fill 489 94 465 492 94 465 minecraft:red_terracotta
setblock 489 94 474 minecraft:light[level=14]
setblock 489 94 482 minecraft:light[level=14]
setblock 489 94 490 minecraft:light[level=14]
setblock 489 94 498 minecraft:light[level=14]
fill 490 94 464 493 94 464 minecraft:red_terracotta
fill 490 94 504 493 94 504 minecraft:red_terracotta
setblock 492 94 466 minecraft:terracotta
fill 492 94 467 495 94 467 minecraft:red_terracotta
setblock 493 94 465 minecraft:terracotta
fill 493 94 466 496 94 466 minecraft:red_terracotta
fill 493 94 503 494 94 503 minecraft:red_terracotta
setblock 494 94 464 minecraft:terracotta
fill 494 94 465 497 94 465 minecraft:red_terracotta
setblock 494 94 504 minecraft:terracotta
fill 495 94 464 498 94 464 minecraft:red_terracotta
setblock 495 94 503 minecraft:terracotta
fill 495 94 504 498 94 504 minecraft:red_terracotta
setblock 496 94 467 minecraft:terracotta
fill 496 94 503 499 94 503 minecraft:red_terracotta
setblock 497 94 466 minecraft:terracotta
fill 497 94 467 497 95 467 minecraft:red_terracotta
setblock 497 94 474 minecraft:light[level=14]
setblock 497 94 482 minecraft:light[level=14]
setblock 497 94 490 minecraft:light[level=14]
setblock 497 94 498 minecraft:light[level=14]
setblock 498 94 465 minecraft:terracotta
fill 498 94 466 501 94 466 minecraft:red_terracotta
setblock 499 94 464 minecraft:terracotta
fill 499 94 465 502 94 465 minecraft:red_terracotta
setblock 499 94 467 minecraft:red_terracotta
setblock 499 94 504 minecraft:terracotta
fill 500 94 464 503 94 464 minecraft:red_terracotta
setblock 500 94 503 minecraft:terracotta
fill 500 94 504 503 94 504 minecraft:red_terracotta
fill 501 94 503 502 94 503 minecraft:red_terracotta
setblock 503 94 465 minecraft:terracotta
setblock 504 94 464 minecraft:terracotta
setblock 504 94 504 minecraft:terracotta
fill 505 94 464 508 94 464 minecraft:red_terracotta
setblock 505 94 466 minecraft:light[level=14]
setblock 505 94 474 minecraft:light[level=14]
setblock 505 94 482 minecraft:light[level=14]
setblock 505 94 490 minecraft:light[level=14]
setblock 505 94 498 minecraft:light[level=14]
fill 505 94 504 508 94 504 minecraft:red_terracotta
setblock 509 94 464 minecraft:terracotta
setblock 509 94 504 minecraft:terracotta
fill 510 94 464 511 95 464 minecraft:red_terracotta
fill 510 94 485 510 94 487 minecraft:red_terracotta
setblock 510 94 488 minecraft:terracotta
fill 510 94 489 510 94 492 minecraft:red_terracotta
setblock 510 94 493 minecraft:terracotta
fill 510 94 494 510 97 494 minecraft:red_terracotta
fill 510 94 504 510 95 504 minecraft:red_terracotta
fill 511 94 465 511 94 466 minecraft:red_terracotta
setblock 511 94 467 minecraft:terracotta
fill 511 94 468 511 97 468 minecraft:red_terracotta
setblock 511 94 471 minecraft:red_terracotta
setblock 511 94 482 minecraft:terracotta
fill 511 94 483 511 94 486 minecraft:red_terracotta
setblock 511 94 487 minecraft:terracotta
fill 511 94 488 511 94 491 minecraft:red_terracotta
setblock 511 94 492 minecraft:terracotta
fill 511 94 493 511 97 493 minecraft:red_terracotta
setblock 511 94 496 minecraft:red_terracotta
setblock 511 94 497 minecraft:terracotta
fill 511 94 498 511 94 501 minecraft:red_terracotta
setblock 511 94 502 minecraft:terracotta
fill 511 94 503 511 95 503 minecraft:red_terracotta
fill 471 95 464 471 95 465 minecraft:red_terracotta
setblock 471 95 466 minecraft:terracotta
fill 471 95 467 471 98 467 minecraft:red_terracotta
setblock 471 95 470 minecraft:red_terracotta
setblock 471 95 471 minecraft:terracotta
fill 471 95 472 471 95 475 minecraft:red_terracotta
setblock 471 95 476 minecraft:terracotta
fill 471 95 477 471 95 480 minecraft:red_terracotta
setblock 471 95 481 minecraft:terracotta
fill 471 95 482 471 95 485 minecraft:red_terracotta
setblock 471 95 486 minecraft:terracotta
fill 471 95 487 471 95 490 minecraft:red_terracotta
setblock 471 95 491 minecraft:terracotta
fill 471 95 492 471 98 492 minecraft:red_terracotta
setblock 471 95 495 minecraft:red_terracotta
setblock 471 95 496 minecraft:terracotta
fill 471 95 497 471 98 497 minecraft:red_terracotta
setblock 472 95 464 minecraft:red_terracotta
setblock 472 95 465 minecraft:terracotta
fill 472 95 466 472 97 466 minecraft:red_terracotta
setblock 472 95 470 minecraft:terracotta
fill 472 95 471 473 97 471 minecraft:red_terracotta
setblock 472 95 475 minecraft:terracotta
setblock 472 95 480 minecraft:terracotta
fill 472 95 481 472 95 484 minecraft:red_terracotta
setblock 472 95 485 minecraft:terracotta
fill 472 95 486 472 95 489 minecraft:red_terracotta
setblock 472 95 490 minecraft:terracotta
fill 472 95 491 472 98 491 minecraft:red_terracotta
setblock 472 95 495 minecraft:terracotta
setblock 473 95 464 minecraft:terracotta
fill 473 95 465 476 95 465 minecraft:red_terracotta
setblock 473 95 468 minecraft:red_terracotta
setblock 473 95 469 minecraft:terracotta
fill 473 95 470 473 98 470 minecraft:red_terracotta
fill 473 95 472 473 96 472 minecraft:red_terracotta
setblock 473 95 483 minecraft:red_terracotta
setblock 473 95 484 minecraft:terracotta
fill 473 95 485 473 95 488 minecraft:red_terracotta
setblock 473 95 489 minecraft:terracotta
fill 473 95 490 473 98 490 minecraft:red_terracotta
fill 474 95 464 477 95 464 minecraft:red_terracotta
fill 474 95 466 475 95 466 minecraft:red_terracotta
fill 474 95 486 474 95 487 minecraft:red_terracotta
setblock 474 95 488 minecraft:terracotta
fill 474 95 489 474 96 489 minecraft:red_terracotta
fill 474 95 504 477 95 504 minecraft:red_terracotta
setblock 476 95 466 minecraft:terracotta
setblock 477 95 465 minecraft:terracotta
fill 477 95 466 480 95 466 minecraft:red_terracotta
setblock 478 95 464 minecraft:terracotta
fill 478 95 465 481 95 465 minecraft:red_terracotta
fill 479 95 464 482 95 464 minecraft:red_terracotta
setblock 482 95 465 minecraft:terracotta
setblock 483 95 464 minecraft:terracotta
fill 483 95 465 486 95 465 minecraft:red_terracotta
fill 484 95 464 487 95 464 minecraft:red_terracotta
setblock 487 95 465 minecraft:terracotta
setblock 488 95 464 minecraft:terracotta
fill 488 95 465 491 95 465 minecraft:red_terracotta
fill 489 95 464 492 95 464 minecraft:red_terracotta
fill 489 95 466 490 95 466 minecraft:red_terracotta
fill 490 95 504 492 95 504 minecraft:red_terracotta
setblock 491 95 466 minecraft:terracotta
setblock 492 95 465 minecraft:terracotta
fill 492 95 466 494 95 467 minecraft:red_terracotta
setblock 493 95 464 minecraft:terracotta
fill 493 95 465 496 95 465 minecraft:red_terracotta
setblock 493 95 503 minecraft:red_terracotta
setblock 493 95 504 minecraft:terracotta
fill 494 95 464 497 95 464 minecraft:red_terracotta
setblock 494 95 503 minecraft:terracotta
fill 494 95 504 497 95 504 minecraft:red_terracotta
setblock 495 95 466 minecraft:red_terracotta
setblock 495 95 467 minecraft:terracotta
fill 495 95 503 498 95 503 minecraft:red_terracotta
setblock 496 95 466 minecraft:terracotta
fill 496 95 467 496 96 467 minecraft:red_terracotta
setblock 497 95 465 minecraft:terracotta
fill 497 95 466 500 95 466 minecraft:red_terracotta
setblock 498 95 464 minecraft:terracotta
fill 498 95 465 501 95 465 minecraft:red_terracotta
setblock 498 95 504 minecraft:terracotta
fill 499 95 464 502 95 464 minecraft:red_terracotta
setblock 499 95 503 minecraft:terracotta
fill 499 95 504 502 95 504 minecraft:red_terracotta
setblock 500 95 503 minecraft:red_terracotta
setblock 502 95 465 minecraft:terracotta
setblock 503 95 464 minecraft:terracotta
setblock 503 95 504 minecraft:terracotta
setblock 504 95 464 minecraft:red_terracotta
setblock 504 95 504 minecraft:red_terracotta
fill 510 95 485 510 95 486 minecraft:red_terracotta
setblock 510 95 487 minecraft:terracotta
fill 510 95 488 510 95 491 minecraft:red_terracotta
setblock 510 95 492 minecraft:terracotta
fill 510 95 493 510 98 493 minecraft:red_terracotta
setblock 510 95 496 minecraft:red_terracotta
setblock 511 95 465 minecraft:red_terracotta
setblock 511 95 466 minecraft:terracotta
fill 511 95 467 511 98 467 minecraft:red_terracotta
setblock 511 95 471 minecraft:terracotta
fill 511 95 472 511 98 472 minecraft:red_terracotta
fill 511 95 482 511 95 485 minecraft:red_terracotta
setblock 511 95 486 minecraft:terracotta
fill 511 95 487 511 95 490 minecraft:red_terracotta
setblock 511 95 491 minecraft:terracotta
fill 511 95 492 511 98 492 minecraft:red_terracotta
setblock 511 95 496 minecraft:terracotta
fill 511 95 497 511 95 500 minecraft:red_terracotta
setblock 511 95 501 minecraft:terracotta
setblock 511 95 502 minecraft:red_terracotta
setblock 471 96 464 minecraft:red_terracotta
setblock 471 96 465 minecraft:terracotta
fill 471 96 466 471 99 466 minecraft:red_terracotta
setblock 471 96 470 minecraft:terracotta
fill 471 96 471 471 96 474 minecraft:red_terracotta
setblock 471 96 475 minecraft:terracotta
fill 471 96 476 471 96 479 minecraft:red_terracotta
setblock 471 96 480 minecraft:terracotta
fill 471 96 481 471 96 484 minecraft:red_terracotta
setblock 471 96 485 minecraft:terracotta
fill 471 96 486 471 96 489 minecraft:red_terracotta
setblock 471 96 490 minecraft:terracotta
fill 471 96 491 471 99 491 minecraft:red_terracotta
setblock 471 96 495 minecraft:terracotta
fill 471 96 496 471 99 496 minecraft:red_terracotta
setblock 472 96 464 minecraft:terracotta
fill 472 96 467 472 97 467 minecraft:red_terracotta
setblock 472 96 469 minecraft:terracotta
fill 472 96 470 472 99 470 minecraft:red_terracotta
fill 472 96 472 472 96 473 minecraft:red_terracotta
setblock 472 96 474 minecraft:terracotta
fill 472 96 475 472 97 477 minecraft:red_terracotta
fill 472 96 480 472 96 483 minecraft:red_terracotta
setblock 472 96 484 minecraft:terracotta
fill 472 96 485 472 96 488 minecraft:red_terracotta
setblock 472 96 489 minecraft:terracotta
fill 472 96 490 472 99 490 minecraft:red_terracotta
setblock 472 96 493 minecraft:red_terracotta
setblock 472 96 494 minecraft:terracotta
fill 472 96 495 472 99 495 minecraft:red_terracotta
fill 473 96 464 475 96 465 minecraft:red_terracotta
setblock 473 96 468 minecraft:terracotta
fill 473 96 469 473 99 469 minecraft:red_terracotta
setblock 473 96 473 minecraft:terracotta
fill 473 96 484 473 96 487 minecraft:red_terracotta
setblock 473 96 488 minecraft:terracotta
fill 473 96 489 473 99 489 minecraft:red_terracotta
setblock 473 96 493 minecraft:terracotta
setblock 474 96 488 minecraft:red_terracotta
setblock 475 96 466 minecraft:terracotta
setblock 476 96 464 minecraft:red_terracotta
setblock 476 96 465 minecraft:terracotta
fill 476 96 466 478 96 466 minecraft:red_terracotta
setblock 477 96 464 minecraft:terracotta
fill 477 96 465 480 96 465 minecraft:red_terracotta
fill 478 96 464 481 96 464 minecraft:red_terracotta
setblock 481 96 465 minecraft:terracotta
setblock 482 96 464 minecraft:terracotta
fill 483 96 464 486 96 464 minecraft:red_terracotta
setblock 487 96 464 minecraft:terracotta
fill 487 96 465 490 96 465 minecraft:red_terracotta
fill 488 96 464 491 96 464 minecraft:red_terracotta
setblock 490 96 466 minecraft:terracotta
fill 490 96 504 491 96 504 minecraft:red_terracotta
setblock 491 96 465 minecraft:terracotta
fill 491 96 466 494 96 466 minecraft:red_terracotta
setblock 492 96 464 minecraft:terracotta
fill 492 96 465 495 96 465 minecraft:red_terracotta
setblock 492 96 504 minecraft:terracotta
fill 493 96 464 496 96 464 minecraft:red_terracotta
setblock 493 96 467 minecraft:red_terracotta
fill 493 96 504 496 96 504 minecraft:red_terracotta
setblock 494 96 467 minecraft:terracotta
fill 494 96 503 497 96 503 minecraft:red_terracotta
setblock 495 96 466 minecraft:terracotta
setblock 495 96 467 minecraft:red_terracotta
setblock 496 96 465 minecraft:terracotta
fill 496 96 466 498 96 466 minecraft:red_terracotta
setblock 497 96 464 minecraft:terracotta
fill 497 96 465 500 96 465 minecraft:red_terracotta
setblock 497 96 504 minecraft:terracotta
fill 498 96 464 501 96 464 minecraft:red_terracotta
setblock 498 96 503 minecraft:terracotta
fill 498 96 504 501 96 504 minecraft:red_terracotta
setblock 499 96 503 minecraft:red_terracotta
setblock 502 96 464 minecraft:terracotta
setblock 502 96 504 minecraft:terracotta
setblock 509 96 491 minecraft:red_terracotta
setblock 510 96 486 minecraft:terracotta
fill 510 96 487 510 96 490 minecraft:red_terracotta
setblock 510 96 491 minecraft:terracotta
fill 510 96 492 510 99 492 minecraft:red_terracotta
setblock 510 96 495 minecraft:red_terracotta
setblock 510 96 496 minecraft:terracotta
setblock 511 96 465 minecraft:terracotta
fill 511 96 466 511 97 466 minecraft:red_terracotta
setblock 511 96 469 minecraft:red_terracotta
setblock 511 96 470 minecraft:terracotta
fill 511 96 471 511 99 471 minecraft:red_terracotta
fill 511 96 473 511 97 473 minecraft:red_terracotta
fill 511 96 482 511 96 484 minecraft:red_terracotta
setblock 511 96 485 minecraft:terracotta
fill 511 96 486 511 96 489 minecraft:red_terracotta
setblock 511 96 490 minecraft:terracotta
fill 511 96 491 511 99 491 minecraft:red_terracotta
setblock 511 96 495 minecraft:terracotta
fill 511 96 496 511 96 499 minecraft:red_terracotta
setblock 511 96 500 minecraft:terracotta
fill 471 97 465 471 100 465 minecraft:red_terracotta
setblock 471 97 469 minecraft:terracotta
fill 471 97 470 471 97 473 minecraft:red_terracotta
setblock 471 97 474 minecraft:terracotta
fill 471 97 475 471 97 478 minecraft:red_terracotta
setblock 471 97 479 minecraft:terracotta
fill 471 97 480 471 97 483 minecraft:red_terracotta
setblock 471 97 484 minecraft:terracotta
fill 471 97 485 471 97 488 minecraft:red_terracotta
setblock 471 97 489 minecraft:terracotta
fill 471 97 490 471 100 490 minecraft:red_terracotta
setblock 471 97 494 minecraft:terracotta
fill 471 97 495 471 100 495 minecraft:red_terracotta
fill 472 97 464 475 97 464 minecraft:red_terracotta
setblock 472 97 468 minecraft:terracotta
fill 472 97 469 472 100 469 minecraft:red_terracotta
setblock 472 97 472 minecraft:red_terracotta
setblock 472 97 473 minecraft:terracotta
fill 472 97 474 473 99 474 minecraft:red_terracotta
setblock 472 97 478 minecraft:terracotta
fill 472 97 481 472 97 482 minecraft:red_terracotta
setblock 472 97 483 minecraft:terracotta
fill 472 97 484 472 97 487 minecraft:red_terracotta
setblock 472 97 488 minecraft:terracotta
fill 472 97 489 472 100 489 minecraft:red_terracotta
setblock 472 97 493 minecraft:terracotta
fill 472 97 494 472 100 494 minecraft:red_terracotta
fill 473 97 465 474 97 465 minecraft:red_terracotta
fill 473 97 468 473 98 468 minecraft:red_terracotta
setblock 473 97 472 minecraft:terracotta
fill 473 97 473 473 100 473 minecraft:red_terracotta
fill 473 97 485 473 97 486 minecraft:red_terracotta
setblock 473 97 487 minecraft:terracotta
fill 473 97 488 473 98 488 minecraft:red_terracotta
setblock 473 97 492 minecraft:terracotta
fill 473 97 493 473 100 493 minecraft:red_terracotta
setblock 475 97 465 minecraft:terracotta
setblock 476 97 464 minecraft:terracotta
fill 476 97 465 479 97 465 minecraft:red_terracotta
fill 477 97 464 480 97 464 minecraft:red_terracotta
setblock 481 97 464 minecraft:terracotta
setblock 482 97 464 minecraft:red_terracotta
setblock 485 97 464 minecraft:red_terracotta
setblock 486 97 464 minecraft:terracotta
fill 487 97 464 490 97 464 minecraft:red_terracotta
fill 488 97 465 489 97 465 minecraft:red_terracotta
setblock 490 97 465 minecraft:terracotta
fill 490 97 466 493 97 466 minecraft:red_terracotta
setblock 491 97 464 minecraft:terracotta
fill 491 97 465 494 97 465 minecraft:red_terracotta
setblock 491 97 504 minecraft:terracotta
fill 492 97 464 495 97 464 minecraft:red_terracotta
fill 492 97 504 495 97 504 minecraft:red_terracotta
setblock 494 97 466 minecraft:terracotta
fill 494 97 503 496 97 503 minecraft:red_terracotta
setblock 495 97 465 minecraft:terracotta
fill 495 97 466 497 97 466 minecraft:red_terracotta
setblock 496 97 464 minecraft:terracotta
fill 496 97 465 499 97 465 minecraft:red_terracotta
setblock 496 97 504 minecraft:terracotta
fill 497 97 464 500 97 464 minecraft:red_terracotta
setblock 497 97 503 minecraft:terracotta
fill 497 97 504 500 97 504 minecraft:red_terracotta
setblock 501 97 464 minecraft:terracotta
setblock 509 97 491 minecraft:terracotta
fill 509 97 492 509 100 492 minecraft:red_terracotta
fill 510 97 486 510 97 489 minecraft:red_terracotta
setblock 510 97 490 minecraft:terracotta
fill 510 97 491 510 100 491 minecraft:red_terracotta
setblock 510 97 495 minecraft:terracotta
fill 510 97 496 511 99 496 minecraft:red_terracotta
setblock 511 97 469 minecraft:terracotta
fill 511 97 470 511 100 470 minecraft:red_terracotta
setblock 511 97 474 minecraft:terracotta
fill 511 97 482 511 97 483 minecraft:red_terracotta
setblock 511 97 484 minecraft:terracotta
fill 511 97 485 511 97 488 minecraft:red_terracotta
setblock 511 97 489 minecraft:terracotta
fill 511 97 490 511 100 490 minecraft:red_terracotta
setblock 511 97 494 minecraft:terracotta
fill 511 97 495 511 100 495 minecraft:red_terracotta
fill 511 97 497 511 97 498 minecraft:red_terracotta
setblock 511 97 499 minecraft:terracotta
fill 511 97 500 511 100 500 minecraft:red_terracotta
setblock 471 98 468 minecraft:terracotta
fill 471 98 469 471 98 472 minecraft:red_terracotta
setblock 471 98 473 minecraft:terracotta
fill 471 98 474 471 98 477 minecraft:red_terracotta
setblock 471 98 478 minecraft:terracotta
fill 471 98 479 471 98 482 minecraft:red_terracotta
setblock 471 98 483 minecraft:terracotta
fill 471 98 484 471 98 487 minecraft:red_terracotta
setblock 471 98 488 minecraft:terracotta
fill 471 98 489 471 101 489 minecraft:red_terracotta
setblock 471 98 493 minecraft:terracotta
fill 471 98 494 471 101 494 minecraft:red_terracotta
setblock 471 98 498 minecraft:terracotta
fill 472 98 464 474 98 464 minecraft:red_terracotta
setblock 472 98 467 minecraft:terracotta
fill 472 98 468 472 101 468 minecraft:red_terracotta
setblock 472 98 471 minecraft:red_terracotta
setblock 472 98 472 minecraft:terracotta
fill 472 98 473 472 101 473 minecraft:red_terracotta
fill 472 98 475 472 98 476 minecraft:red_terracotta
setblock 472 98 477 minecraft:terracotta
fill 472 98 478 472 98 481 minecraft:red_terracotta
setblock 472 98 482 minecraft:terracotta
fill 472 98 483 472 98 486 minecraft:red_terracotta
setblock 472 98 487 minecraft:terracotta
fill 472 98 488 472 101 488 minecraft:red_terracotta
setblock 472 98 492 minecraft:terracotta
fill 472 98 493 472 101 493 minecraft:red_terracotta
setblock 472 98 496 minecraft:red_terracotta
setblock 473 98 471 minecraft:terracotta
fill 473 98 472 473 101 472 minecraft:red_terracotta
setblock 473 98 475 minecraft:red_terracotta
setblock 473 98 487 minecraft:red_terracotta
setblock 473 98 491 minecraft:terracotta
fill 473 98 492 473 101 492 minecraft:red_terracotta
setblock 475 98 464 minecraft:terracotta
fill 475 98 465 476 98 465 minecraft:red_terracotta
fill 476 98 464 479 98 464 minecraft:red_terracotta
fill 487 98 464 489 98 464 minecraft:red_terracotta
setblock 489 98 465 minecraft:terracotta
setblock 490 98 464 minecraft:terracotta
fill 490 98 465 493 98 465 minecraft:red_terracotta
fill 491 98 464 494 98 464 minecraft:red_terracotta
fill 491 98 466 492 98 466 minecraft:red_terracotta
fill 491 98 504 494 98 504 minecraft:red_terracotta
setblock 493 98 466 minecraft:terracotta
setblock 494 98 465 minecraft:terracotta
fill 494 98 466 495 98 466 minecraft:red_terracotta
setblock 495 98 464 minecraft:terracotta
fill 495 98 465 497 98 465 minecraft:red_terracotta
setblock 495 98 503 minecraft:red_terracotta
setblock 495 98 504 minecraft:terracotta
fill 496 98 464 499 98 464 minecraft:red_terracotta
fill 496 98 504 499 98 504 minecraft:red_terracotta
fill 509 98 491 509 101 491 minecraft:red_terracotta
fill 509 98 493 509 99 493 minecraft:red_terracotta
fill 510 98 486 510 98 488 minecraft:red_terracotta
setblock 510 98 489 minecraft:terracotta
fill 510 98 490 510 101 490 minecraft:red_terracotta
setblock 510 98 494 minecraft:terracotta
fill 510 98 495 510 101 495 minecraft:red_terracotta
fill 510 98 497 511 98 497 minecraft:red_terracotta
setblock 511 98 468 minecraft:terracotta
fill 511 98 469 511 101 469 minecraft:red_terracotta
setblock 511 98 473 minecraft:terracotta
fill 511 98 474 511 99 476 minecraft:red_terracotta
setblock 511 98 482 minecraft:red_terracotta
setblock 511 98 483 minecraft:terracotta
fill 511 98 484 511 98 487 minecraft:red_terracotta
setblock 511 98 488 minecraft:terracotta
fill 511 98 489 511 101 489 minecraft:red_terracotta
setblock 511 98 493 minecraft:terracotta
fill 511 98 494 511 101 494 minecraft:red_terracotta
setblock 511 98 498 minecraft:terracotta
fill 511 98 499 511 101 499 minecraft:red_terracotta
setblock 471 99 467 minecraft:terracotta
fill 471 99 468 471 99 471 minecraft:red_terracotta
setblock 471 99 472 minecraft:terracotta
fill 471 99 473 471 99 476 minecraft:red_terracotta
setblock 471 99 477 minecraft:terracotta
fill 471 99 478 471 99 481 minecraft:red_terracotta
setblock 471 99 482 minecraft:terracotta
fill 471 99 483 471 99 486 minecraft:red_terracotta
setblock 471 99 487 minecraft:terracotta
fill 471 99 488 471 102 488 minecraft:red_terracotta
setblock 471 99 492 minecraft:terracotta
fill 471 99 493 471 102 493 minecraft:red_terracotta
setblock 471 99 497 minecraft:terracotta
fill 471 99 498 471 102 498 minecraft:red_terracotta
fill 472 99 464 473 99 464 minecraft:red_terracotta
fill 472 99 467 472 102 467 minecraft:red_terracotta
setblock 472 99 471 minecraft:terracotta
fill 472 99 472 472 102 472 minecraft:red_terracotta
setblock 472 99 475 minecraft:red_terracotta
setblock 472 99 476 minecraft:terracotta
fill 472 99 477 472 99 480 minecraft:red_terracotta
setblock 472 99 481 minecraft:terracotta
fill 472 99 482 472 99 485 minecraft:red_terracotta
setblock 472 99 486 minecraft:terracotta
fill 472 99 487 472 102 487 minecraft:red_terracotta
setblock 472 99 491 minecraft:terracotta
fill 472 99 492 472 102 492 minecraft:red_terracotta
setblock 472 99 496 minecraft:terracotta
setblock 473 99 470 minecraft:terracotta
fill 473 99 471 473 102 471 minecraft:red_terracotta
setblock 473 99 475 minecraft:terracotta
fill 473 99 476 473 102 476 minecraft:red_terracotta
setblock 473 99 490 minecraft:terracotta
fill 473 99 491 473 100 491 minecraft:red_terracotta
setblock 474 99 464 minecraft:terracotta
fill 475 99 464 477 99 464 minecraft:red_terracotta
fill 487 99 464 488 99 464 minecraft:red_terracotta
setblock 489 99 464 minecraft:terracotta
fill 489 99 465 492 99 465 minecraft:red_terracotta
fill 490 99 464 493 99 464 minecraft:red_terracotta
fill 490 99 504 493 99 504 minecraft:red_terracotta
setblock 492 99 466 minecraft:terracotta
setblock 493 99 465 minecraft:terracotta
fill 493 99 466 494 99 466 minecraft:red_terracotta
setblock 494 99 464 minecraft:terracotta
fill 494 99 465 496 99 465 minecraft:red_terracotta
setblock 494 99 504 minecraft:terracotta
fill 495 99 464 498 99 464 minecraft:red_terracotta
fill 495 99 504 498 99 504 minecraft:red_terracotta
fill 509 99 490 509 102 490 minecraft:red_terracotta
setblock 509 99 494 minecraft:terracotta
setblock 510 99 487 minecraft:red_terracotta
setblock 510 99 488 minecraft:terracotta
fill 510 99 489 510 102 489 minecraft:red_terracotta
setblock 510 99 493 minecraft:terracotta
fill 510 99 494 510 102 494 minecraft:red_terracotta
setblock 510 99 497 minecraft:red_terracotta
setblock 510 99 498 minecraft:terracotta
setblock 511 99 467 minecraft:terracotta
fill 511 99 468 511 102 468 minecraft:red_terracotta
setblock 511 99 472 minecraft:terracotta
fill 511 99 473 511 102 473 minecraft:red_terracotta
setblock 511 99 477 minecraft:terracotta
fill 511 99 478 511 99 481 minecraft:red_terracotta
setblock 511 99 482 minecraft:terracotta
fill 511 99 483 511 99 486 minecraft:red_terracotta
setblock 511 99 487 minecraft:terracotta
fill 511 99 488 511 102 488 minecraft:red_terracotta
setblock 511 99 492 minecraft:terracotta
fill 511 99 493 511 102 493 minecraft:red_terracotta
setblock 511 99 497 minecraft:terracotta
fill 511 99 498 511 102 498 minecraft:red_terracotta
setblock 511 99 501 minecraft:red_terracotta
setblock 471 100 466 minecraft:terracotta
fill 471 100 467 471 100 470 minecraft:red_terracotta
setblock 471 100 471 minecraft:terracotta
fill 471 100 472 471 100 475 minecraft:red_terracotta
setblock 471 100 476 minecraft:terracotta
fill 471 100 477 471 100 480 minecraft:red_terracotta
setblock 471 100 481 minecraft:terracotta
fill 471 100 482 471 100 485 minecraft:red_terracotta
setblock 471 100 486 minecraft:terracotta
fill 471 100 487 471 103 487 minecraft:red_terracotta
setblock 471 100 491 minecraft:terracotta
fill 471 100 492 471 103 492 minecraft:red_terracotta
setblock 471 100 496 minecraft:terracotta
fill 471 100 497 472 102 497 minecraft:red_terracotta
fill 471 100 499 471 101 499 minecraft:red_terracotta
setblock 472 100 464 minecraft:red_terracotta
setblock 472 100 470 minecraft:terracotta
fill 472 100 471 472 103 471 minecraft:red_terracotta
setblock 472 100 474 minecraft:red_terracotta
setblock 472 100 475 minecraft:terracotta
fill 472 100 476 472 100 479 minecraft:red_terracotta
setblock 472 100 480 minecraft:terracotta
fill 472 100 481 472 100 484 minecraft:red_terracotta
setblock 472 100 485 minecraft:terracotta
fill 472 100 486 472 103 486 minecraft:red_terracotta
setblock 472 100 490 minecraft:terracotta
fill 472 100 491 472 103 491 minecraft:red_terracotta
setblock 472 100 495 minecraft:terracotta
fill 472 100 496 472 103 496 minecraft:red_terracotta
setblock 473 100 464 minecraft:terracotta
setblock 473 100 469 minecraft:terracotta
fill 473 100 470 473 103 470 minecraft:red_terracotta
setblock 473 100 474 minecraft:terracotta
fill 473 100 475 473 103 475 minecraft:red_terracotta
fill 473 100 477 473 101 477 minecraft:red_terracotta
setblock 473 100 490 minecraft:red_terracotta
fill 474 100 464 476 100 464 minecraft:red_terracotta
setblock 487 100 464 minecraft:red_terracotta
setblock 488 100 464 minecraft:terracotta
fill 489 100 464 491 100 465 minecraft:red_terracotta
fill 490 100 504 492 100 504 minecraft:red_terracotta
setblock 492 100 464 minecraft:red_terracotta
setblock 492 100 465 minecraft:terracotta
setblock 493 100 464 minecraft:terracotta
fill 493 100 465 495 100 465 minecraft:red_terracotta
setblock 493 100 503 minecraft:red_terracotta
setblock 493 100 504 minecraft:terracotta
fill 494 100 464 497 100 464 minecraft:red_terracotta
setblock 494 100 503 minecraft:terracotta
fill 494 100 504 497 100 504 minecraft:red_terracotta
fill 495 100 503 495 103 503 minecraft:red_terracotta
setblock 498 100 504 minecraft:terracotta
setblock 509 100 493 minecraft:terracotta
fill 509 100 494 509 101 496 minecraft:red_terracotta
setblock 510 100 486 minecraft:red_terracotta
setblock 510 100 487 minecraft:terracotta
fill 510 100 488 510 103 488 minecraft:red_terracotta
setblock 510 100 492 minecraft:terracotta
fill 510 100 493 510 103 493 minecraft:red_terracotta
setblock 510 100 496 minecraft:red_terracotta
setblock 510 100 497 minecraft:terracotta
fill 510 100 498 510 102 499 minecraft:red_terracotta
fill 511 100 467 511 103 467 minecraft:red_terracotta
setblock 511 100 471 minecraft:terracotta
fill 511 100 472 511 103 472 minecraft:red_terracotta
fill 511 100 474 511 100 475 minecraft:red_terracotta
setblock 511 100 476 minecraft:terracotta
fill 511 100 477 511 100 480 minecraft:red_terracotta
setblock 511 100 481 minecraft:terracotta
fill 511 100 482 511 100 485 minecraft:red_terracotta
setblock 511 100 486 minecraft:terracotta
fill 511 100 487 511 103 487 minecraft:red_terracotta
setblock 511 100 491 minecraft:terracotta
fill 511 100 492 511 103 492 minecraft:red_terracotta
setblock 511 100 496 minecraft:terracotta
fill 511 100 497 511 103 497 minecraft:red_terracotta
setblock 511 100 501 minecraft:terracotta
setblock 471 101 465 minecraft:terracotta
fill 471 101 466 471 101 469 minecraft:red_terracotta
setblock 471 101 470 minecraft:terracotta
fill 471 101 471 471 101 474 minecraft:red_terracotta
setblock 471 101 475 minecraft:terracotta
fill 471 101 476 471 101 479 minecraft:red_terracotta
setblock 471 101 480 minecraft:terracotta
fill 471 101 481 471 101 484 minecraft:red_terracotta
setblock 471 101 485 minecraft:terracotta
fill 471 101 486 471 104 486 minecraft:red_terracotta
setblock 471 101 490 minecraft:terracotta
fill 471 101 491 471 104 491 minecraft:red_terracotta
setblock 471 101 495 minecraft:terracotta
fill 471 101 496 471 104 496 minecraft:red_terracotta
setblock 471 101 500 minecraft:terracotta
setblock 472 101 464 minecraft:terracotta
setblock 472 101 469 minecraft:terracotta
fill 472 101 470 472 104 470 minecraft:red_terracotta
setblock 472 101 474 minecraft:terracotta
fill 472 101 475 472 101 478 minecraft:red_terracotta
setblock 472 101 479 minecraft:terracotta
fill 472 101 480 472 101 483 minecraft:red_terracotta
setblock 472 101 484 minecraft:terracotta
fill 472 101 485 472 104 485 minecraft:red_terracotta
setblock 472 101 489 minecraft:terracotta
fill 472 101 490 472 104 490 minecraft:red_terracotta
setblock 472 101 494 minecraft:terracotta
fill 472 101 495 472 104 495 minecraft:red_terracotta
fill 473 101 464 475 102 464 minecraft:red_terracotta
fill 473 101 469 473 104 469 minecraft:red_terracotta
setblock 473 101 473 minecraft:terracotta
fill 473 101 474 474 103 474 minecraft:red_terracotta
setblock 473 101 478 minecraft:terracotta
setblock 473 101 493 minecraft:terracotta
setblock 474 101 472 minecraft:terracotta
fill 474 101 473 474 104 473 minecraft:red_terracotta
setblock 486 101 464 minecraft:red_terracotta
setblock 487 101 464 minecraft:terracotta
fill 488 101 464 491 101 464 minecraft:red_terracotta
fill 489 101 465 490 101 465 minecraft:red_terracotta
fill 489 101 504 491 101 504 minecraft:red_terracotta
setblock 491 101 465 minecraft:terracotta
fill 491 101 503 492 101 503 minecraft:red_terracotta
setblock 492 101 464 minecraft:terracotta
fill 492 101 465 494 102 465 minecraft:red_terracotta
setblock 492 101 504 minecraft:terracotta
fill 493 101 464 496 101 464 minecraft:red_terracotta
setblock 493 101 503 minecraft:terracotta
fill 493 101 504 496 101 504 minecraft:red_terracotta
fill 494 101 503 494 104 503 minecraft:red_terracotta
setblock 497 101 464 minecraft:terracotta
setblock 497 101 504 minecraft:terracotta
fill 498 101 504 498 104 504 minecraft:red_terracotta
setblock 509 101 492 minecraft:terracotta
fill 509 101 493 509 104 493 minecraft:red_terracotta
setblock 509 101 497 minecraft:terracotta
setblock 510 101 471 minecraft:terracotta
fill 510 101 472 510 101 475 minecraft:red_terracotta
setblock 510 101 476 minecraft:terracotta
fill 510 101 477 511 103 477 minecraft:red_terracotta
setblock 510 101 486 minecraft:terracotta
fill 510 101 487 510 104 487 minecraft:red_terracotta
setblock 510 101 491 minecraft:terracotta
fill 510 101 492 510 104 492 minecraft:red_terracotta
setblock 510 101 496 minecraft:terracotta
fill 510 101 497 510 104 497 minecraft:red_terracotta
setblock 510 101 500 minecraft:red_terracotta
setblock 511 101 470 minecraft:terracotta
fill 511 101 471 511 104 471 minecraft:red_terracotta
setblock 511 101 474 minecraft:red_terracotta
setblock 511 101 475 minecraft:terracotta
fill 511 101 476 511 104 476 minecraft:red_terracotta
fill 511 101 478 511 101 479 minecraft:red_terracotta
setblock 511 101 480 minecraft:terracotta
fill 511 101 481 511 101 484 minecraft:red_terracotta
setblock 511 101 485 minecraft:terracotta
fill 511 101 486 511 104 486 minecraft:red_terracotta
setblock 511 101 490 minecraft:terracotta
fill 511 101 491 511 104 491 minecraft:red_terracotta
setblock 511 101 495 minecraft:terracotta
fill 511 101 496 511 104 496 minecraft:red_terracotta
setblock 511 101 500 minecraft:terracotta
fill 511 101 501 511 103 502 minecraft:red_terracotta
setblock 471 102 464 minecraft:terracotta
fill 471 102 465 471 102 468 minecraft:red_terracotta
setblock 471 102 469 minecraft:terracotta
fill 471 102 470 471 102 473 minecraft:red_terracotta
setblock 471 102 474 minecraft:terracotta
fill 471 102 475 471 102 478 minecraft:red_terracotta
setblock 471 102 479 minecraft:terracotta
fill 471 102 480 471 102 483 minecraft:red_terracotta
setblock 471 102 484 minecraft:terracotta
fill 471 102 485 471 105 485 minecraft:red_terracotta
setblock 471 102 489 minecraft:terracotta
fill 471 102 490 471 105 490 minecraft:red_terracotta
setblock 471 102 494 minecraft:terracotta
fill 471 102 495 471 105 495 minecraft:red_terracotta
setblock 471 102 499 minecraft:terracotta
fill 471 102 500 471 104 501 minecraft:red_terracotta
fill 472 102 464 472 105 464 minecraft:red_terracotta
setblock 472 102 468 minecraft:terracotta
fill 472 102 469 472 105 469 minecraft:red_terracotta
setblock 472 102 473 minecraft:terracotta
fill 472 102 474 472 102 477 minecraft:red_terracotta
setblock 472 102 478 minecraft:terracotta
fill 472 102 479 472 102 482 minecraft:red_terracotta
setblock 472 102 483 minecraft:terracotta
fill 472 102 484 472 105 484 minecraft:red_terracotta
setblock 472 102 488 minecraft:terracotta
fill 472 102 489 472 105 489 minecraft:red_terracotta
setblock 472 102 493 minecraft:terracotta
fill 472 102 494 472 105 494 minecraft:red_terracotta
setblock 472 102 498 minecraft:terracotta
setblock 473 102 466 minecraft:light[level=14]
setblock 473 102 472 minecraft:terracotta
fill 473 102 473 473 105 473 minecraft:red_terracotta
setblock 473 102 477 minecraft:terracotta
fill 473 102 478 473 103 480 minecraft:red_terracotta
setblock 473 102 482 minecraft:light[level=14]
setblock 473 102 490 minecraft:light[level=14]
setblock 473 102 493 minecraft:red_terracotta
setblock 473 102 498 minecraft:light[level=14]
setblock 474 102 471 minecraft:terracotta
fill 474 102 472 474 105 472 minecraft:red_terracotta
setblock 474 102 475 minecraft:red_terracotta
setblock 474 102 476 minecraft:terracotta
setblock 481 102 466 minecraft:light[level=14]
setblock 481 102 474 minecraft:light[level=14]
setblock 481 102 482 minecraft:light[level=14]
setblock 481 102 490 minecraft:light[level=14]
setblock 481 102 498 minecraft:light[level=14]
setblock 486 102 464 minecraft:terracotta
fill 487 102 464 490 102 464 minecraft:red_terracotta
fill 487 102 504 490 102 504 minecraft:red_terracotta
fill 488 102 465 489 102 465 minecraft:red_terracotta
setblock 489 102 466 minecraft:light[level=14]
setblock 489 102 474 minecraft:light[level=14]
setblock 489 102 482 minecraft:light[level=14]
setblock 489 102 490 minecraft:light[level=14]
setblock 489 102 498 minecraft:light[level=14]
setblock 490 102 465 minecraft:terracotta
fill 490 102 503 491 102 503 minecraft:red_terracotta
setblock 491 102 464 minecraft:terracotta
fill 491 102 465 491 105 465 minecraft:red_terracotta
setblock 491 102 504 minecraft:terracotta
fill 492 102 464 495 102 464 minecraft:red_terracotta
setblock 492 102 503 minecraft:terracotta
fill 492 102 504 495 102 504 minecraft:red_terracotta
fill 493 102 503 493 105 503 minecraft:red_terracotta
setblock 496 102 464 minecraft:terracotta
setblock 496 102 503 minecraft:red_terracotta
setblock 496 102 504 minecraft:terracotta
setblock 497 102 466 minecraft:light[level=14]
setblock 497 102 474 minecraft:light[level=14]
setblock 497 102 482 minecraft:light[level=14]
setblock 497 102 490 minecraft:light[level=14]
setblock 497 102 498 minecraft:light[level=14]
fill 497 102 504 497 105 504 minecraft:red_terracotta
setblock 505 102 466 minecraft:light[level=14]
setblock 505 102 474 minecraft:light[level=14]
setblock 505 102 482 minecraft:light[level=14]
setblock 505 102 490 minecraft:light[level=14]
setblock 505 102 498 minecraft:light[level=14]
fill 509 102 489 509 103 489 minecraft:red_terracotta
setblock 509 102 491 minecraft:terracotta
fill 509 102 492 509 105 492 minecraft:red_terracotta
fill 509 102 494 509 102 495 minecraft:red_terracotta
setblock 509 102 496 minecraft:terracotta
fill 509 102 497 509 104 498 minecraft:red_terracotta
setblock 510 102 470 minecraft:terracotta
fill 510 102 471 510 102 474 minecraft:red_terracotta
setblock 510 102 475 minecraft:terracotta
fill 510 102 476 510 105 476 minecraft:red_terracotta
fill 510 102 478 510 102 479 minecraft:red_terracotta
setblock 510 102 480 minecraft:terracotta
fill 510 102 481 510 102 484 minecraft:red_terracotta
setblock 510 102 485 minecraft:terracotta
fill 510 102 486 510 105 486 minecraft:red_terracotta
setblock 510 102 490 minecraft:terracotta
fill 510 102 491 510 105 491 minecraft:red_terracotta
setblock 510 102 495 minecraft:terracotta
fill 510 102 496 510 105 496 minecraft:red_terracotta
setblock 510 102 500 minecraft:terracotta
fill 510 102 501 510 105 501 minecraft:red_terracotta
setblock 511 102 469 minecraft:terracotta
fill 511 102 470 511 105 470 minecraft:red_terracotta
setblock 511 102 474 minecraft:terracotta
fill 511 102 475 511 105 475 minecraft:red_terracotta
setblock 511 102 478 minecraft:red_terracotta
setblock 511 102 479 minecraft:terracotta
fill 511 102 480 511 102 483 minecraft:red_terracotta
setblock 511 102 484 minecraft:terracotta
fill 511 102 485 511 105 485 minecraft:red_terracotta
setblock 511 102 489 minecraft:terracotta
fill 511 102 490 511 105 490 minecraft:red_terracotta
setblock 511 102 494 minecraft:terracotta
fill 511 102 495 511 105 495 minecraft:red_terracotta
setblock 511 102 499 minecraft:terracotta
fill 511 102 500 511 105 500 minecraft:red_terracotta
setblock 511 102 503 minecraft:red_terracotta
fill 471 103 464 471 103 467 minecraft:red_terracotta
setblock 471 103 468 minecraft:terracotta
fill 471 103 469 471 103 472 minecraft:red_terracotta
setblock 471 103 473 minecraft:terracotta
fill 471 103 474 471 103 477 minecraft:red_terracotta
setblock 471 103 478 minecraft:terracotta
fill 471 103 479 471 103 482 minecraft:red_terracotta
setblock 471 103 483 minecraft:terracotta
fill 471 103 484 471 106 484 minecraft:red_terracotta
setblock 471 103 488 minecraft:terracotta
fill 471 103 489 471 106 489 minecraft:red_terracotta
setblock 471 103 493 minecraft:terracotta
fill 471 103 494 471 106 494 minecraft:red_terracotta
setblock 471 103 497 minecraft:red_terracotta
setblock 471 103 498 minecraft:terracotta
fill 471 103 499 472 105 499 minecraft:red_terracotta
setblock 471 103 502 minecraft:red_terracotta
setblock 471 103 503 minecraft:terracotta
setblock 472 103 466 minecraft:red_terracotta
setblock 472 103 467 minecraft:terracotta
fill 472 103 468 472 106 468 minecraft:red_terracotta
setblock 472 103 472 minecraft:terracotta
fill 472 103 473 472 103 476 minecraft:red_terracotta
setblock 472 103 477 minecraft:terracotta
fill 472 103 478 472 103 481 minecraft:red_terracotta
setblock 472 103 482 minecraft:terracotta
fill 472 103 483 472 106 483 minecraft:red_terracotta
setblock 472 103 487 minecraft:terracotta
fill 472 103 488 472 105 488 minecraft:red_terracotta
setblock 472 103 492 minecraft:terracotta
fill 472 103 493 472 106 493 minecraft:red_terracotta
setblock 472 103 497 minecraft:terracotta
fill 472 103 498 472 106 498 minecraft:red_terracotta
fill 473 103 464 474 103 464 minecraft:red_terracotta
setblock 473 103 471 minecraft:terracotta
fill 473 103 472 473 106 472 minecraft:red_terracotta
setblock 473 103 476 minecraft:terracotta
fill 473 103 477 474 105 477 minecraft:red_terracotta
setblock 474 103 471 minecraft:red_terracotta
setblock 474 103 475 minecraft:terracotta
fill 474 103 476 474 106 476 minecraft:red_terracotta
setblock 475 103 464 minecraft:terracotta
fill 476 103 464 476 106 464 minecraft:red_terracotta
setblock 485 103 464 minecraft:terracotta
fill 486 103 464 489 103 464 minecraft:red_terracotta
fill 486 103 504 489 103 504 minecraft:red_terracotta
fill 487 103 465 488 103 465 minecraft:red_terracotta
fill 488 103 503 490 103 503 minecraft:red_terracotta
setblock 489 103 465 minecraft:terracotta
setblock 490 103 464 minecraft:terracotta
fill 490 103 465 490 106 465 minecraft:red_terracotta
fill 490 103 502 491 103 502 minecraft:red_terracotta
setblock 490 103 504 minecraft:terracotta
fill 491 103 464 494 103 464 minecraft:red_terracotta
setblock 491 103 503 minecraft:terracotta
fill 491 103 504 494 103 504 minecraft:red_terracotta
fill 492 103 465 493 103 465 minecraft:red_terracotta
setblock 492 103 502 minecraft:terracotta
fill 492 103 503 492 106 503 minecraft:red_terracotta
fill 493 103 502 494 105 502 minecraft:red_terracotta
setblock 494 103 465 minecraft:terracotta
setblock 495 103 464 minecraft:terracotta
setblock 495 103 504 minecraft:terracotta
fill 496 103 464 496 104 464 minecraft:red_terracotta
setblock 496 103 503 minecraft:terracotta
fill 496 103 504 496 106 504 minecraft:red_terracotta
fill 508 103 493 508 103 495 minecraft:red_terracotta
setblock 508 103 496 minecraft:terracotta
fill 508 103 504 509 103 504 minecraft:red_terracotta
setblock 509 103 474 minecraft:red_terracotta
setblock 509 103 475 minecraft:terracotta
fill 509 103 476 509 105 477 minecraft:red_terracotta
setblock 509 103 490 minecraft:terracotta
fill 509 103 491 509 106 491 minecraft:red_terracotta
setblock 509 103 494 minecraft:red_terracotta
setblock 509 103 495 minecraft:terracotta
fill 509 103 496 509 106 496 minecraft:red_terracotta
setblock 509 103 499 minecraft:red_terracotta
fill 510 103 470 510 103 473 minecraft:red_terracotta
setblock 510 103 474 minecraft:terracotta
fill 510 103 475 510 106 475 minecraft:red_terracotta
setblock 510 103 478 minecraft:red_terracotta
setblock 510 103 479 minecraft:terracotta
fill 510 103 480 510 103 483 minecraft:red_terracotta
setblock 510 103 484 minecraft:terracotta
fill 510 103 485 510 106 485 minecraft:red_terracotta
setblock 510 103 489 minecraft:terracotta
fill 510 103 490 510 106 490 minecraft:red_terracotta
setblock 510 103 494 minecraft:terracotta
fill 510 103 495 510 106 495 minecraft:red_terracotta
setblock 510 103 498 minecraft:red_terracotta
setblock 510 103 499 minecraft:terracotta
fill 510 103 500 510 106 500 minecraft:red_terracotta
fill 510 103 502 510 104 502 minecraft:red_terracotta
setblock 510 103 504 minecraft:terracotta
fill 511 103 466 511 104 466 minecraft:red_terracotta
setblock 511 103 468 minecraft:terracotta
fill 511 103 469 511 106 469 minecraft:red_terracotta
setblock 511 103 473 minecraft:terracotta
fill 511 103 474 511 106 474 minecraft:red_terracotta
setblock 511 103 478 minecraft:terracotta
fill 511 103 479 511 103 482 minecraft:red_terracotta
setblock 511 103 483 minecraft:terracotta
fill 511 103 484 511 106 484 minecraft:red_terracotta
setblock 511 103 488 minecraft:terracotta
fill 511 103 489 511 106 489 minecraft:red_terracotta
setblock 511 103 493 minecraft:terracotta
fill 511 103 494 511 106 494 minecraft:red_terracotta
setblock 511 103 498 minecraft:terracotta
fill 511 103 499 511 106 499 minecraft:red_terracotta
setblock 511 103 503 minecraft:terracotta
fill 511 103 504 511 106 504 minecraft:red_terracotta
fill 471 104 464 471 104 466 minecraft:red_terracotta
setblock 471 104 467 minecraft:terracotta
fill 471 104 468 471 104 471 minecraft:red_terracotta
setblock 471 104 472 minecraft:terracotta
fill 471 104 473 471 104 476 minecraft:red_terracotta
setblock 471 104 477 minecraft:terracotta
fill 471 104 478 471 104 481 minecraft:red_terracotta
setblock 471 104 482 minecraft:terracotta
fill 471 104 483 471 107 483 minecraft:red_terracotta
setblock 471 104 487 minecraft:terracotta
fill 471 104 488 471 107 488 minecraft:red_terracotta
setblock 471 104 492 minecraft:terracotta
fill 471 104 493 471 107 493 minecraft:red_terracotta
setblock 471 104 497 minecraft:terracotta
fill 471 104 498 471 107 498 minecraft:red_terracotta
setblock 471 104 502 minecraft:terracotta
fill 471 104 503 471 106 504 minecraft:red_terracotta
setblock 472 104 466 minecraft:terracotta
fill 472 104 467 472 107 467 minecraft:red_terracotta
setblock 472 104 471 minecraft:terracotta
fill 472 104 472 472 104 475 minecraft:red_terracotta
setblock 472 104 476 minecraft:terracotta
fill 472 104 477 472 104 480 minecraft:red_terracotta
setblock 472 104 481 minecraft:terracotta
fill 472 104 482 472 107 482 minecraft:red_terracotta
setblock 472 104 486 minecraft:terracotta
fill 472 104 487 472 105 487 minecraft:red_terracotta
setblock 472 104 491 minecraft:terracotta
fill 472 104 492 472 106 492 minecraft:red_terracotta
setblock 472 104 496 minecraft:terracotta
fill 472 104 497 472 107 497 minecraft:red_terracotta
setblock 472 104 500 minecraft:red_terracotta
fill 472 104 504 472 105 504 minecraft:red_terracotta
setblock 473 104 464 minecraft:red_terracotta
setblock 473 104 470 minecraft:terracotta
fill 473 104 471 473 107 471 minecraft:red_terracotta
setblock 473 104 474 minecraft:red_terracotta
setblock 473 104 475 minecraft:terracotta
fill 473 104 476 473 107 476 minecraft:red_terracotta
fill 473 104 478 473 104 479 minecraft:red_terracotta
setblock 473 104 480 minecraft:terracotta
fill 473 104 481 473 107 481 minecraft:red_terracotta
setblock 474 104 464 minecraft:terracotta
setblock 474 104 474 minecraft:terracotta
fill 474 104 475 474 107 475 minecraft:red_terracotta
setblock 474 104 478 minecraft:red_terracotta
fill 475 104 464 475 107 464 minecraft:red_terracotta
setblock 483 104 464 minecraft:red_terracotta
setblock 484 104 464 minecraft:terracotta
fill 485 104 464 488 104 464 minecraft:red_terracotta
fill 485 104 504 488 104 504 minecraft:red_terracotta
fill 486 104 465 487 104 465 minecraft:red_terracotta
fill 487 104 503 489 104 503 minecraft:red_terracotta
setblock 488 104 465 minecraft:terracotta
fill 488 104 502 490 104 502 minecraft:red_terracotta
setblock 489 104 464 minecraft:terracotta
fill 489 104 465 489 107 465 minecraft:red_terracotta
setblock 489 104 504 minecraft:terracotta
fill 490 104 464 493 104 464 minecraft:red_terracotta
setblock 490 104 503 minecraft:terracotta
fill 490 104 504 493 104 504 minecraft:red_terracotta
setblock 491 104 502 minecraft:terracotta
fill 491 104 503 491 107 503 minecraft:red_terracotta
setblock 492 104 465 minecraft:red_terracotta
fill 492 104 502 492 107 502 minecraft:red_terracotta
setblock 493 104 465 minecraft:terracotta
setblock 494 104 464 minecraft:terracotta
setblock 494 104 504 minecraft:terracotta
fill 495 104 464 495 106 464 minecraft:red_terracotta
setblock 495 104 502 minecraft:red_terracotta
setblock 495 104 503 minecraft:terracotta
fill 495 104 504 495 107 504 minecraft:red_terracotta
fill 496 104 503 497 106 503 minecraft:red_terracotta
setblock 499 104 504 minecraft:terracotta
fill 506 104 504 508 104 504 minecraft:red_terracotta
fill 508 104 492 508 104 494 minecraft:red_terracotta
setblock 508 104 495 minecraft:terracotta
fill 508 104 496 508 106 497 minecraft:red_terracotta
fill 509 104 472 509 104 473 minecraft:red_terracotta
setblock 509 104 474 minecraft:terracotta
fill 509 104 475 509 107 475 minecraft:red_terracotta
setblock 509 104 478 minecraft:red_terracotta
setblock 509 104 479 minecraft:terracotta
fill 509 104 480 511 105 480 minecraft:red_terracotta
setblock 509 104 488 minecraft:red_terracotta
setblock 509 104 489 minecraft:terracotta
fill 509 104 490 509 107 490 minecraft:red_terracotta
setblock 509 104 494 minecraft:terracotta
fill 509 104 495 509 107 495 minecraft:red_terracotta
setblock 509 104 499 minecraft:terracotta
fill 509 104 500 509 107 500 minecraft:red_terracotta
setblock 509 104 504 minecraft:terracotta
fill 510 104 469 510 104 472 minecraft:red_terracotta
setblock 510 104 473 minecraft:terracotta
fill 510 104 474 510 107 474 minecraft:red_terracotta
setblock 510 104 477 minecraft:red_terracotta
setblock 510 104 478 minecraft:terracotta
fill 510 104 479 511 106 479 minecraft:red_terracotta
fill 510 104 481 510 104 482 minecraft:red_terracotta
setblock 510 104 483 minecraft:terracotta
fill 510 104 484 510 107 484 minecraft:red_terracotta
setblock 510 104 488 minecraft:terracotta
fill 510 104 489 510 107 489 minecraft:red_terracotta
setblock 510 104 493 minecraft:terracotta
fill 510 104 494 510 107 494 minecraft:red_terracotta
setblock 510 104 498 minecraft:terracotta
fill 510 104 499 510 107 499 minecraft:red_terracotta
setblock 510 104 503 minecraft:terracotta
fill 510 104 504 510 107 504 minecraft:red_terracotta
setblock 511 104 467 minecraft:terracotta
fill 511 104 468 511 107 468 minecraft:red_terracotta
setblock 511 104 472 minecraft:terracotta
fill 511 104 473 511 107 473 minecraft:red_terracotta
setblock 511 104 477 minecraft:terracotta
fill 511 104 478 511 107 478 minecraft:red_terracotta
setblock 511 104 481 minecraft:red_terracotta
setblock 511 104 482 minecraft:terracotta
fill 511 104 483 511 107 483 minecraft:red_terracotta
setblock 511 104 487 minecraft:terracotta
fill 511 104 488 511 107 488 minecraft:red_terracotta
setblock 511 104 492 minecraft:terracotta
fill 511 104 493 511 107 493 minecraft:red_terracotta
setblock 511 104 497 minecraft:terracotta
fill 511 104 498 511 107 498 minecraft:red_terracotta
setblock 511 104 501 minecraft:red_terracotta
setblock 511 104 502 minecraft:terracotta
fill 511 104 503 511 107 503 minecraft:red_terracotta
fill 471 105 464 471 105 465 minecraft:red_terracotta
setblock 471 105 466 minecraft:terracotta
fill 471 105 467 471 105 470 minecraft:red_terracotta
setblock 471 105 471 minecraft:terracotta
fill 471 105 472 471 105 475 minecraft:red_terracotta
setblock 471 105 476 minecraft:terracotta
fill 471 105 477 471 105 480 minecraft:red_terracotta
setblock 471 105 481 minecraft:terracotta
fill 471 105 482 471 108 482 minecraft:red_terracotta
setblock 471 105 486 minecraft:terracotta
fill 471 105 487 471 108 487 minecraft:red_terracotta
setblock 471 105 491 minecraft:terracotta
fill 471 105 492 471 108 492 minecraft:red_terracotta
setblock 471 105 496 minecraft:terracotta
fill 471 105 497 471 108 497 minecraft:red_terracotta
setblock 471 105 500 minecraft:red_terracotta
setblock 471 105 501 minecraft:terracotta
fill 471 105 502 471 108 502 minecraft:red_terracotta
fill 472 105 466 472 107 466 minecraft:red_terracotta
setblock 472 105 470 minecraft:terracotta
fill 472 105 471 472 105 474 minecraft:red_terracotta
setblock 472 105 475 minecraft:terracotta
fill 472 105 476 472 105 479 minecraft:red_terracotta
setblock 472 105 480 minecraft:terracotta
fill 472 105 481 472 108 481 minecraft:red_terracotta
setblock 472 105 485 minecraft:terracotta
fill 472 105 486 472 106 486 minecraft:red_terracotta
setblock 472 105 490 minecraft:terracotta
fill 472 105 491 472 106 491 minecraft:red_terracotta
setblock 472 105 495 minecraft:terracotta
fill 472 105 496 472 108 496 minecraft:red_terracotta
setblock 472 105 500 minecraft:terracotta
fill 472 105 501 472 108 501 minecraft:red_terracotta
setblock 473 105 464 minecraft:terracotta
setblock 473 105 469 minecraft:terracotta
fill 473 105 470 473 107 470 minecraft:red_terracotta
setblock 473 105 474 minecraft:terracotta
fill 473 105 475 473 108 475 minecraft:red_terracotta
setblock 473 105 478 minecraft:red_terracotta
setblock 473 105 479 minecraft:terracotta
fill 473 105 480 473 108 480 minecraft:red_terracotta
fill 473 105 482 473 106 482 minecraft:red_terracotta
setblock 473 105 504 minecraft:terracotta
fill 474 105 464 474 108 464 minecraft:red_terracotta
setblock 474 105 473 minecraft:terracotta
fill 474 105 474 474 107 474 minecraft:red_terracotta
setblock 474 105 478 minecraft:terracotta
fill 474 105 504 474 108 504 minecraft:red_terracotta
setblock 482 105 464 minecraft:red_terracotta
setblock 483 105 464 minecraft:terracotta
setblock 483 105 504 minecraft:terracotta
fill 484 105 464 487 105 464 minecraft:red_terracotta
fill 484 105 504 487 105 504 minecraft:red_terracotta
fill 485 105 503 488 105 503 minecraft:red_terracotta
setblock 486 105 465 minecraft:red_terracotta
setblock 487 105 465 minecraft:terracotta
fill 487 105 502 489 105 502 minecraft:red_terracotta
setblock 488 105 464 minecraft:terracotta
fill 488 105 465 488 108 465 minecraft:red_terracotta
setblock 488 105 504 minecraft:terracotta
fill 489 105 464 492 105 464 minecraft:red_terracotta
fill 489 105 501 490 105 501 minecraft:red_terracotta
setblock 489 105 503 minecraft:terracotta
fill 489 105 504 492 105 504 minecraft:red_terracotta
setblock 490 105 502 minecraft:terracotta
fill 490 105 503 490 108 503 minecraft:red_terracotta
setblock 491 105 501 minecraft:terracotta
fill 491 105 502 491 108 502 minecraft:red_terracotta
setblock 492 105 465 minecraft:terracotta
fill 492 105 501 493 107 501 minecraft:red_terracotta
setblock 493 105 464 minecraft:terracotta
setblock 493 105 465 minecraft:red_terracotta
setblock 493 105 504 minecraft:terracotta
fill 494 105 464 494 108 464 minecraft:red_terracotta
setblock 494 105 503 minecraft:terracotta
fill 494 105 504 494 108 504 minecraft:red_terracotta
setblock 495 105 502 minecraft:terracotta
fill 495 105 503 495 108 503 minecraft:red_terracotta
fill 496 105 502 496 107 502 minecraft:red_terracotta
setblock 498 105 504 minecraft:terracotta
fill 499 105 504 500 107 504 minecraft:red_terracotta
fill 501 105 498 505 107 502 minecraft:terracotta
fill 503 105 497 504 157 497 minecraft:terracotta
setblock 503 105 504 minecraft:terracotta
fill 504 105 504 507 105 504 minecraft:red_terracotta
fill 506 105 499 506 157 501 minecraft:terracotta
fill 507 105 503 508 105 503 minecraft:red_terracotta
fill 508 105 492 508 105 493 minecraft:red_terracotta
setblock 508 105 494 minecraft:terracotta
fill 508 105 495 508 108 495 minecraft:red_terracotta
setblock 508 105 498 minecraft:red_terracotta
setblock 508 105 499 minecraft:terracotta
setblock 508 105 504 minecraft:terracotta
setblock 509 105 472 minecraft:red_terracotta
setblock 509 105 473 minecraft:terracotta
fill 509 105 474 509 108 474 minecraft:red_terracotta
setblock 509 105 478 minecraft:terracotta
fill 509 105 479 509 108 479 minecraft:red_terracotta
fill 509 105 481 509 105 482 minecraft:red_terracotta
setblock 509 105 483 minecraft:terracotta
fill 509 105 484 509 105 487 minecraft:red_terracotta
setblock 509 105 488 minecraft:terracotta
fill 509 105 489 509 108 489 minecraft:red_terracotta
setblock 509 105 493 minecraft:terracotta
fill 509 105 494 509 108 494 minecraft:red_terracotta
setblock 509 105 497 minecraft:red_terracotta
setblock 509 105 498 minecraft:terracotta
fill 509 105 499 509 108 499 minecraft:red_terracotta
fill 509 105 501 509 106 501 minecraft:red_terracotta
setblock 509 105 503 minecraft:terracotta
fill 509 105 504 509 108 504 minecraft:red_terracotta
fill 510 105 469 510 105 471 minecraft:red_terracotta
setblock 510 105 472 minecraft:terracotta
fill 510 105 473 510 108 473 minecraft:red_terracotta
setblock 510 105 477 minecraft:terracotta
fill 510 105 478 510 108 478 minecraft:red_terracotta
setblock 510 105 481 minecraft:red_terracotta
setblock 510 105 482 minecraft:terracotta
fill 510 105 483 510 108 483 minecraft:red_terracotta
setblock 510 105 487 minecraft:terracotta
fill 510 105 488 510 108 488 minecraft:red_terracotta
setblock 510 105 492 minecraft:terracotta
fill 510 105 493 510 108 493 minecraft:red_terracotta
setblock 510 105 497 minecraft:terracotta
fill 510 105 498 510 108 498 minecraft:red_terracotta
setblock 510 105 502 minecraft:terracotta
fill 510 105 503 510 108 503 minecraft:red_terracotta
fill 511 105 464 511 105 465 minecraft:red_terracotta
setblock 511 105 466 minecraft:terracotta
fill 511 105 467 511 108 467 minecraft:red_terracotta
setblock 511 105 471 minecraft:terracotta
fill 511 105 472 511 108 472 minecraft:red_terracotta
setblock 511 105 476 minecraft:terracotta
fill 511 105 477 511 108 477 minecraft:red_terracotta
setblock 511 105 481 minecraft:terracotta
fill 511 105 482 511 108 482 minecraft:red_terracotta
setblock 511 105 486 minecraft:terracotta
fill 511 105 487 511 108 487 minecraft:red_terracotta
setblock 511 105 491 minecraft:terracotta
fill 511 105 492 511 108 492 minecraft:red_terracotta
setblock 511 105 496 minecraft:terracotta
fill 511 105 497 511 108 497 minecraft:red_terracotta
setblock 511 105 501 minecraft:terracotta
fill 511 105 502 511 108 502 minecraft:red_terracotta
setblock 471 106 464 minecraft:red_terracotta
setblock 471 106 465 minecraft:terracotta
fill 471 106 466 471 106 469 minecraft:red_terracotta
setblock 471 106 470 minecraft:terracotta
fill 471 106 471 471 106 474 minecraft:red_terracotta
setblock 471 106 475 minecraft:terracotta
fill 471 106 476 471 106 479 minecraft:red_terracotta
setblock 471 106 480 minecraft:terracotta
fill 471 106 481 471 109 481 minecraft:red_terracotta
setblock 471 106 485 minecraft:terracotta
fill 471 106 486 471 109 486 minecraft:red_terracotta
setblock 471 106 490 minecraft:terracotta
fill 471 106 491 471 108 491 minecraft:red_terracotta
setblock 471 106 495 minecraft:terracotta
fill 471 106 496 471 109 496 minecraft:red_terracotta
setblock 471 106 499 minecraft:red_terracotta
setblock 471 106 500 minecraft:terracotta
fill 471 106 501 471 109 501 minecraft:red_terracotta
setblock 472 106 464 minecraft:terracotta
setblock 472 106 469 minecraft:terracotta
fill 472 106 470 472 106 473 minecraft:red_terracotta
setblock 472 106 474 minecraft:terracotta
fill 472 106 475 472 106 478 minecraft:red_terracotta
setblock 472 106 479 minecraft:terracotta
fill 472 106 480 472 109 480 minecraft:red_terracotta
setblock 472 106 484 minecraft:terracotta
fill 472 106 485 472 108 485 minecraft:red_terracotta
setblock 472 106 490 minecraft:red_terracotta
setblock 472 106 494 minecraft:terracotta
fill 472 106 495 472 107 495 minecraft:red_terracotta
setblock 472 106 499 minecraft:terracotta
fill 472 106 500 472 109 500 minecraft:red_terracotta
fill 472 106 502 472 107 502 minecraft:red_terracotta
setblock 472 106 504 minecraft:terracotta
fill 473 106 464 473 109 464 minecraft:red_terracotta
setblock 473 106 469 minecraft:red_terracotta
setblock 473 106 473 minecraft:terracotta
fill 473 106 474 473 109 474 minecraft:red_terracotta
setblock 473 106 477 minecraft:red_terracotta
setblock 473 106 478 minecraft:terracotta
fill 473 106 479 473 109 479 minecraft:red_terracotta
fill 473 106 504 473 109 504 minecraft:red_terracotta
setblock 474 106 473 minecraft:red_terracotta
setblock 474 106 477 minecraft:terracotta
fill 474 106 478 474 107 478 minecraft:red_terracotta
setblock 477 106 464 minecraft:terracotta
setblock 481 106 464 minecraft:red_terracotta
setblock 482 106 464 minecraft:terracotta
setblock 482 106 504 minecraft:terracotta
fill 483 106 464 486 106 464 minecraft:red_terracotta
fill 483 106 504 486 106 504 minecraft:red_terracotta
fill 484 106 503 487 106 503 minecraft:red_terracotta
setblock 485 106 465 minecraft:red_terracotta
setblock 486 106 465 minecraft:terracotta
fill 486 106 502 488 106 502 minecraft:red_terracotta
setblock 487 106 464 minecraft:terracotta
fill 487 106 465 487 109 465 minecraft:red_terracotta
setblock 487 106 504 minecraft:terracotta
fill 488 106 464 491 106 464 minecraft:red_terracotta
fill 488 106 501 489 106 501 minecraft:red_terracotta
setblock 488 106 503 minecraft:terracotta
fill 488 106 504 491 106 504 minecraft:red_terracotta
setblock 489 106 502 minecraft:terracotta
fill 489 106 503 489 109 503 minecraft:red_terracotta
setblock 490 106 501 minecraft:terracotta
fill 490 106 502 490 109 502 minecraft:red_terracotta
setblock 491 106 465 minecraft:terracotta
fill 491 106 501 491 109 501 minecraft:red_terracotta
setblock 492 106 464 minecraft:terracotta
fill 492 106 465 492 107 465 minecraft:red_terracotta
setblock 492 106 504 minecraft:terracotta
fill 493 106 464 493 109 464 minecraft:red_terracotta
setblock 493 106 502 minecraft:red_terracotta
setblock 493 106 503 minecraft:terracotta
fill 493 106 504 493 109 504 minecraft:red_terracotta
setblock 494 106 501 minecraft:red_terracotta
setblock 494 106 502 minecraft:terracotta
fill 494 106 503 494 109 503 minecraft:red_terracotta
fill 495 106 502 495 109 502 minecraft:red_terracotta
setblock 497 106 504 minecraft:terracotta
setblock 498 106 503 minecraft:terracotta
fill 498 106 504 498 109 504 minecraft:red_terracotta
fill 499 106 500 500 107 500 minecraft:brown_terracotta
fill 500 106 498 500 107 499 minecraft:brown_terracotta
fill 500 106 501 500 107 502 minecraft:brown_terracotta
fill 501 106 497 502 107 497 minecraft:brown_terracotta
fill 501 106 503 504 106 503 minecraft:brown_terracotta
setblock 501 106 504 minecraft:red_terracotta
fill 502 106 496 505 107 496 minecraft:brown_terracotta
setblock 502 106 504 minecraft:terracotta
fill 503 106 504 506 106 504 minecraft:red_terracotta
fill 505 106 497 506 107 497 minecraft:brown_terracotta
fill 505 106 503 507 106 503 minecraft:red_terracotta
fill 506 106 498 507 107 498 minecraft:brown_terracotta
setblock 506 106 502 minecraft:brown_terracotta
fill 507 106 499 507 107 501 minecraft:brown_terracotta
setblock 507 106 504 minecraft:terracotta
fill 508 106 476 508 106 477 minecraft:red_terracotta
setblock 508 106 478 minecraft:terracotta
fill 508 106 479 508 109 479 minecraft:red_terracotta
setblock 508 106 493 minecraft:terracotta
fill 508 106 494 508 107 494 minecraft:red_terracotta
setblock 508 106 498 minecraft:terracotta
fill 508 106 499 508 108 499 minecraft:red_terracotta
setblock 508 106 502 minecraft:red_terracotta
setblock 508 106 503 minecraft:terracotta
fill 508 106 504 508 109 504 minecraft:red_terracotta
fill 509 106 464 511 106 464 minecraft:red_terracotta
setblock 509 106 472 minecraft:terracotta
fill 509 106 473 509 108 473 minecraft:red_terracotta
setblock 509 106 476 minecraft:red_terracotta
setblock 509 106 477 minecraft:terracotta
fill 509 106 478 509 109 478 minecraft:red_terracotta
fill 509 106 480 509 106 481 minecraft:red_terracotta
setblock 509 106 482 minecraft:terracotta
fill 509 106 483 509 106 486 minecraft:red_terracotta
setblock 509 106 487 minecraft:terracotta
fill 509 106 488 509 108 488 minecraft:red_terracotta
setblock 509 106 492 minecraft:terracotta
fill 509 106 493 509 109 493 minecraft:red_terracotta
setblock 509 106 497 minecraft:terracotta
fill 509 106 498 509 109 498 minecraft:red_terracotta
setblock 509 106 502 minecraft:terracotta
fill 509 106 503 509 109 503 minecraft:red_terracotta
fill 510 106 469 510 106 470 minecraft:red_terracotta
setblock 510 106 471 minecraft:terracotta
fill 510 106 472 510 109 472 minecraft:red_terracotta
setblock 510 106 476 minecraft:terracotta
fill 510 106 477 510 109 477 minecraft:red_terracotta
setblock 510 106 480 minecraft:red_terracotta
setblock 510 106 481 minecraft:terracotta
fill 510 106 482 510 109 482 minecraft:red_terracotta
setblock 510 106 486 minecraft:terracotta
fill 510 106 487 510 109 487 minecraft:red_terracotta
setblock 510 106 491 minecraft:terracotta
fill 510 106 492 510 109 492 minecraft:red_terracotta
setblock 510 106 496 minecraft:terracotta
fill 510 106 497 510 109 497 minecraft:red_terracotta
setblock 510 106 501 minecraft:terracotta
fill 510 106 502 510 109 502 minecraft:red_terracotta
setblock 511 106 465 minecraft:terracotta
fill 511 106 466 511 108 466 minecraft:red_terracotta
setblock 511 106 470 minecraft:terracotta
fill 511 106 471 511 109 471 minecraft:red_terracotta
setblock 511 106 475 minecraft:terracotta
fill 511 106 476 511 109 476 minecraft:red_terracotta
setblock 511 106 480 minecraft:terracotta
fill 511 106 481 511 109 481 minecraft:red_terracotta
setblock 511 106 485 minecraft:terracotta
fill 511 106 486 511 109 486 minecraft:red_terracotta
setblock 511 106 490 minecraft:terracotta
fill 511 106 491 511 109 491 minecraft:red_terracotta
setblock 511 106 495 minecraft:terracotta
fill 511 106 496 511 109 496 minecraft:red_terracotta
setblock 511 106 500 minecraft:terracotta
fill 511 106 501 511 109 501 minecraft:red_terracotta
setblock 471 107 464 minecraft:terracotta
fill 471 107 465 471 107 468 minecraft:red_terracotta
setblock 471 107 469 minecraft:terracotta
fill 471 107 470 471 107 473 minecraft:red_terracotta
setblock 471 107 474 minecraft:terracotta
fill 471 107 475 471 107 478 minecraft:red_terracotta
setblock 471 107 479 minecraft:terracotta
fill 471 107 480 471 110 480 minecraft:red_terracotta
setblock 471 107 484 minecraft:terracotta
fill 471 107 485 471 110 485 minecraft:red_terracotta
setblock 471 107 489 minecraft:terracotta
fill 471 107 490 471 108 490 minecraft:red_terracotta
setblock 471 107 494 minecraft:terracotta
fill 471 107 495 471 110 495 minecraft:red_terracotta
setblock 471 107 499 minecraft:terracotta
fill 471 107 500 471 110 500 minecraft:red_terracotta
setblock 471 107 503 minecraft:red_terracotta
setblock 471 107 504 minecraft:terracotta
fill 472 107 464 472 110 464 minecraft:red_terracotta
setblock 472 107 468 minecraft:terracotta
fill 472 107 469 472 107 472 minecraft:red_terracotta
setblock 472 107 473 minecraft:terracotta
fill 472 107 474 472 107 477 minecraft:red_terracotta
setblock 472 107 478 minecraft:terracotta
fill 472 107 479 472 110 479 minecraft:red_terracotta
setblock 472 107 483 minecraft:terracotta
fill 472 107 484 472 109 484 minecraft:red_terracotta
fill 472 107 486 475 144 488 minecraft:terracotta
setblock 472 107 493 minecraft:terracotta
setblock 472 107 494 minecraft:red_terracotta
setblock 472 107 498 minecraft:terracotta
fill 472 107 499 472 109 499 minecraft:red_terracotta
fill 472 107 504 472 110 504 minecraft:red_terracotta
setblock 473 107 472 minecraft:terracotta
fill 473 107 473 473 109 473 minecraft:red_terracotta
setblock 473 107 477 minecraft:terracotta
fill 473 107 478 473 110 478 minecraft:red_terracotta
setblock 473 107 482 minecraft:terracotta
setblock 474 107 476 minecraft:terracotta
setblock 474 107 477 minecraft:red_terracotta
fill 474 107 485 474 157 485 minecraft:terracotta
setblock 475 107 504 minecraft:red_terracotta
setblock 476 107 464 minecraft:terracotta
fill 477 107 464 477 108 464 minecraft:red_terracotta
setblock 480 107 464 minecraft:red_terracotta
setblock 480 107 504 minecraft:red_terracotta
setblock 481 107 464 minecraft:terracotta
setblock 481 107 504 minecraft:terracotta
fill 482 107 464 485 107 464 minecraft:red_terracotta
fill 482 107 504 485 107 504 minecraft:red_terracotta
fill 483 107 503 486 107 503 minecraft:red_terracotta
setblock 484 107 465 minecraft:red_terracotta
setblock 485 107 465 minecraft:terracotta
fill 485 107 502 487 107 502 minecraft:red_terracotta
setblock 486 107 464 minecraft:terracotta
fill 486 107 465 486 110 465 minecraft:red_terracotta
setblock 486 107 504 minecraft:terracotta
fill 487 107 464 490 107 464 minecraft:red_terracotta
fill 487 107 501 488 107 501 minecraft:red_terracotta
setblock 487 107 503 minecraft:terracotta
fill 487 107 504 490 107 504 minecraft:red_terracotta
setblock 488 107 502 minecraft:terracotta
fill 488 107 503 488 110 503 minecraft:red_terracotta
setblock 489 107 501 minecraft:terracotta
fill 489 107 502 489 110 502 minecraft:red_terracotta
setblock 490 107 465 minecraft:terracotta
fill 490 107 501 490 110 501 minecraft:red_terracotta
setblock 491 107 464 minecraft:terracotta
fill 491 107 465 491 108 465 minecraft:red_terracotta
setblock 491 107 504 minecraft:terracotta
fill 492 107 464 492 110 464 minecraft:red_terracotta
setblock 492 107 503 minecraft:terracotta
fill 492 107 504 492 110 504 minecraft:red_terracotta
setblock 493 107 502 minecraft:terracotta
fill 493 107 503 493 110 503 minecraft:red_terracotta
setblock 494 107 501 minecraft:terracotta
fill 494 107 502 494 110 502 minecraft:red_terracotta
setblock 496 107 503 minecraft:red_terracotta
setblock 496 107 504 minecraft:terracotta
setblock 497 107 503 minecraft:terracotta
fill 497 107 504 497 110 504 minecraft:red_terracotta
fill 498 107 499 498 107 501 minecraft:brown_terracotta
fill 498 107 503 498 109 503 minecraft:red_terracotta
fill 499 107 497 499 107 499 minecraft:brown_terracotta
fill 499 107 501 499 107 503 minecraft:brown_terracotta
fill 500 107 496 500 107 497 minecraft:brown_terracotta
fill 500 107 503 502 107 503 minecraft:brown_terracotta
fill 501 107 495 501 107 496 minecraft:brown_terracotta
setblock 501 107 504 minecraft:terracotta
fill 502 107 495 505 107 495 minecraft:brown_terracotta
fill 502 107 504 505 107 504 minecraft:red_terracotta
fill 503 107 503 506 107 503 minecraft:red_terracotta
fill 506 107 496 507 107 496 minecraft:brown_terracotta
fill 506 107 502 507 107 502 minecraft:red_terracotta
setblock 506 107 504 minecraft:terracotta
setblock 507 107 497 minecraft:brown_terracotta
setblock 507 107 503 minecraft:terracotta
fill 507 107 504 507 110 504 minecraft:red_terracotta
fill 508 107 464 510 107 464 minecraft:red_terracotta
fill 508 107 475 508 107 476 minecraft:red_terracotta
setblock 508 107 477 minecraft:terracotta
fill 508 107 478 508 110 478 minecraft:red_terracotta
fill 508 107 480 508 107 481 minecraft:red_terracotta
setblock 508 107 493 minecraft:red_terracotta
setblock 508 107 496 minecraft:red_terracotta
setblock 508 107 497 minecraft:terracotta
fill 508 107 498 508 108 498 minecraft:red_terracotta
setblock 508 107 500 minecraft:red_terracotta
setblock 508 107 501 minecraft:brown_terracotta
setblock 508 107 502 minecraft:terracotta
fill 508 107 503 508 110 503 minecraft:red_terracotta
setblock 509 107 472 minecraft:red_terracotta
setblock 509 107 476 minecraft:terracotta
fill 509 107 477 509 110 477 minecraft:red_terracotta
setblock 509 107 480 minecraft:red_terracotta
setblock 509 107 481 minecraft:terracotta
fill 509 107 482 509 107 485 minecraft:red_terracotta
setblock 509 107 486 minecraft:terracotta
fill 509 107 487 509 109 487 minecraft:red_terracotta
setblock 509 107 491 minecraft:terracotta
fill 509 107 492 509 108 492 minecraft:red_terracotta
setblock 509 107 496 minecraft:terracotta
fill 509 107 497 509 110 497 minecraft:red_terracotta
setblock 509 107 501 minecraft:terracotta
fill 509 107 502 509 109 502 minecraft:red_terracotta
setblock 510 107 470 minecraft:terracotta
fill 510 107 471 510 109 471 minecraft:red_terracotta
setblock 510 107 475 minecraft:terracotta
fill 510 107 476 510 110 476 minecraft:red_terracotta
setblock 510 107 479 minecraft:red_terracotta
setblock 510 107 480 minecraft:terracotta
fill 510 107 481 510 110 481 minecraft:red_terracotta
setblock 510 107 485 minecraft:terracotta
fill 510 107 486 510 110 486 minecraft:red_terracotta
setblock 510 107 490 minecraft:terracotta
fill 510 107 491 510 110 491 minecraft:red_terracotta
setblock 510 107 495 minecraft:terracotta
fill 510 107 496 510 110 496 minecraft:red_terracotta
setblock 510 107 500 minecraft:terracotta
fill 510 107 501 510 110 501 minecraft:red_terracotta
setblock 511 107 464 minecraft:terracotta
fill 511 107 465 511 108 465 minecraft:red_terracotta
setblock 511 107 469 minecraft:terracotta
fill 511 107 470 511 110 470 minecraft:red_terracotta
setblock 511 107 474 minecraft:terracotta
fill 511 107 475 511 110 475 minecraft:red_terracotta
setblock 511 107 479 minecraft:terracotta
fill 511 107 480 511 110 480 minecraft:red_terracotta
setblock 511 107 484 minecraft:terracotta
fill 511 107 485 511 110 485 minecraft:red_terracotta
setblock 511 107 489 minecraft:terracotta
fill 511 107 490 511 110 490 minecraft:red_terracotta
setblock 511 107 494 minecraft:terracotta
fill 511 107 495 511 110 495 minecraft:red_terracotta
schedule function dropper:buildpart/118_4 1t
