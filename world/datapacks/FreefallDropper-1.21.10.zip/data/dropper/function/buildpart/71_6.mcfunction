fill 517 272 296 517 279 296 minecraft:brown_terracotta
fill 517 272 298 517 279 298 minecraft:brown_terracotta
setblock 517 272 299 minecraft:white_concrete
fill 517 272 300 517 279 300 minecraft:brown_terracotta
fill 517 272 302 517 279 302 minecraft:brown_terracotta
setblock 517 272 303 minecraft:white_concrete
fill 517 272 304 517 278 306 minecraft:brown_terracotta
setblock 517 272 307 minecraft:white_concrete
fill 517 272 308 517 279 308 minecraft:brown_terracotta
fill 517 272 310 517 279 310 minecraft:brown_terracotta
setblock 517 272 311 minecraft:white_concrete
fill 517 272 312 517 279 312 minecraft:brown_terracotta
fill 517 272 314 517 279 314 minecraft:brown_terracotta
setblock 517 272 315 minecraft:white_concrete
fill 517 272 316 517 279 316 minecraft:brown_terracotta
setblock 517 272 317 minecraft:white_concrete
fill 518 272 275 518 279 275 minecraft:brown_terracotta
fill 518 272 317 520 278 317 minecraft:brown_terracotta
fill 520 272 275 520 279 275 minecraft:brown_terracotta
setblock 521 272 275 minecraft:white_concrete
setblock 521 272 317 minecraft:white_concrete
fill 522 272 275 522 279 275 minecraft:brown_terracotta
fill 522 272 317 522 279 317 minecraft:brown_terracotta
fill 524 272 275 524 279 275 minecraft:brown_terracotta
fill 524 272 317 524 279 317 minecraft:brown_terracotta
setblock 525 272 275 minecraft:white_concrete
setblock 525 272 317 minecraft:white_concrete
fill 526 272 275 528 278 275 minecraft:brown_terracotta
fill 526 272 317 526 279 317 minecraft:brown_terracotta
fill 528 272 317 528 279 317 minecraft:brown_terracotta
setblock 529 272 275 minecraft:white_concrete
setblock 529 272 317 minecraft:white_concrete
fill 530 272 275 530 279 275 minecraft:brown_terracotta
fill 530 272 317 532 278 317 minecraft:brown_terracotta
fill 532 272 275 532 279 275 minecraft:brown_terracotta
setblock 533 272 275 minecraft:white_concrete
setblock 533 272 317 minecraft:white_concrete
fill 534 272 275 534 279 275 minecraft:brown_terracotta
fill 534 272 317 534 279 317 minecraft:brown_terracotta
fill 536 272 275 536 279 275 minecraft:brown_terracotta
fill 536 272 317 536 279 317 minecraft:brown_terracotta
setblock 537 272 275 minecraft:white_concrete
setblock 537 272 317 minecraft:white_concrete
fill 538 272 275 540 278 275 minecraft:brown_terracotta
fill 538 272 317 538 279 317 minecraft:brown_terracotta
fill 540 272 317 540 279 317 minecraft:brown_terracotta
setblock 541 272 275 minecraft:white_concrete
setblock 541 272 317 minecraft:white_concrete
fill 542 272 275 542 279 275 minecraft:brown_terracotta
fill 542 272 317 544 278 317 minecraft:brown_terracotta
fill 544 272 275 544 279 275 minecraft:brown_terracotta
setblock 545 272 275 minecraft:white_concrete
setblock 545 272 317 minecraft:white_concrete
fill 546 272 275 546 279 275 minecraft:brown_terracotta
fill 546 272 317 546 279 317 minecraft:brown_terracotta
fill 548 272 275 548 279 275 minecraft:brown_terracotta
fill 548 272 317 548 279 317 minecraft:brown_terracotta
setblock 549 272 275 minecraft:white_concrete
setblock 549 272 317 minecraft:white_concrete
fill 550 272 275 552 278 275 minecraft:brown_terracotta
fill 550 272 317 550 279 317 minecraft:brown_terracotta
fill 552 272 317 552 279 317 minecraft:brown_terracotta
setblock 553 272 275 minecraft:white_concrete
setblock 553 272 317 minecraft:white_concrete
fill 554 272 275 554 279 275 minecraft:brown_terracotta
fill 554 272 317 556 278 317 minecraft:brown_terracotta
fill 556 272 275 556 279 275 minecraft:brown_terracotta
setblock 557 272 275 minecraft:white_concrete
setblock 557 272 317 minecraft:white_concrete
fill 558 272 275 558 279 275 minecraft:brown_terracotta
fill 558 272 317 558 279 317 minecraft:brown_terracotta
setblock 559 272 275 minecraft:white_concrete
fill 559 272 276 559 278 278 minecraft:brown_terracotta
setblock 559 272 279 minecraft:white_concrete
fill 559 272 280 559 279 280 minecraft:brown_terracotta
fill 559 272 282 559 279 282 minecraft:brown_terracotta
setblock 559 272 283 minecraft:white_concrete
fill 559 272 284 559 279 284 minecraft:brown_terracotta
fill 559 272 286 559 279 286 minecraft:brown_terracotta
setblock 559 272 287 minecraft:white_concrete
fill 559 272 288 559 278 290 minecraft:brown_terracotta
setblock 559 272 291 minecraft:white_concrete
fill 559 272 292 559 279 292 minecraft:brown_terracotta
fill 559 272 294 559 279 294 minecraft:brown_terracotta
setblock 559 272 295 minecraft:white_concrete
fill 559 272 296 559 279 296 minecraft:brown_terracotta
fill 559 272 298 559 279 298 minecraft:brown_terracotta
setblock 559 272 299 minecraft:white_concrete
fill 559 272 300 559 278 302 minecraft:brown_terracotta
setblock 559 272 303 minecraft:white_concrete
fill 559 272 304 559 279 304 minecraft:brown_terracotta
fill 559 272 306 559 279 306 minecraft:brown_terracotta
setblock 559 272 307 minecraft:white_concrete
fill 559 272 308 559 279 308 minecraft:brown_terracotta
fill 559 272 310 559 279 310 minecraft:brown_terracotta
setblock 559 272 311 minecraft:white_concrete
fill 559 272 312 559 278 314 minecraft:brown_terracotta
setblock 559 272 315 minecraft:white_concrete
fill 559 272 316 559 279 316 minecraft:brown_terracotta
fill 517 273 275 517 280 275 minecraft:brown_terracotta
fill 517 273 279 517 280 279 minecraft:brown_terracotta
fill 517 273 283 517 280 283 minecraft:brown_terracotta
fill 517 273 287 517 280 287 minecraft:brown_terracotta
fill 517 273 291 517 280 291 minecraft:brown_terracotta
fill 517 273 295 517 280 295 minecraft:brown_terracotta
fill 517 273 299 517 280 299 minecraft:brown_terracotta
fill 517 273 303 517 280 303 minecraft:brown_terracotta
fill 517 273 307 517 280 307 minecraft:brown_terracotta
fill 517 273 311 517 280 311 minecraft:brown_terracotta
fill 517 273 315 517 280 315 minecraft:brown_terracotta
fill 517 273 317 517 278 317 minecraft:brown_terracotta
setblock 520 273 278 minecraft:light[level=12]
setblock 520 273 285 minecraft:light[level=12]
setblock 520 273 292 minecraft:light[level=12]
setblock 520 273 299 minecraft:light[level=12]
setblock 520 273 306 minecraft:light[level=12]
setblock 520 273 313 minecraft:light[level=12]
fill 521 273 275 521 280 275 minecraft:brown_terracotta
fill 521 273 317 521 280 317 minecraft:brown_terracotta
fill 525 273 275 525 280 275 minecraft:brown_terracotta
fill 525 273 317 525 280 317 minecraft:brown_terracotta
setblock 527 273 278 minecraft:light[level=12]
setblock 527 273 285 minecraft:light[level=12]
setblock 527 273 292 minecraft:light[level=12]
setblock 527 273 299 minecraft:light[level=12]
setblock 527 273 306 minecraft:light[level=12]
setblock 527 273 313 minecraft:light[level=12]
fill 529 273 275 529 280 275 minecraft:brown_terracotta
fill 529 273 317 529 280 317 minecraft:brown_terracotta
fill 533 273 275 533 280 275 minecraft:brown_terracotta
fill 533 273 317 533 280 317 minecraft:brown_terracotta
setblock 534 273 278 minecraft:light[level=12]
setblock 534 273 285 minecraft:light[level=12]
setblock 534 273 292 minecraft:light[level=12]
setblock 534 273 299 minecraft:light[level=12]
setblock 534 273 306 minecraft:light[level=12]
setblock 534 273 313 minecraft:light[level=12]
fill 537 273 275 537 280 275 minecraft:brown_terracotta
fill 537 273 317 537 280 317 minecraft:brown_terracotta
fill 541 273 275 541 280 275 minecraft:brown_terracotta
setblock 541 273 278 minecraft:light[level=12]
setblock 541 273 285 minecraft:light[level=12]
setblock 541 273 292 minecraft:light[level=12]
setblock 541 273 299 minecraft:light[level=12]
setblock 541 273 306 minecraft:light[level=12]
setblock 541 273 313 minecraft:light[level=12]
fill 541 273 317 541 280 317 minecraft:brown_terracotta
fill 545 273 275 545 280 275 minecraft:brown_terracotta
fill 545 273 317 545 280 317 minecraft:brown_terracotta
setblock 548 273 278 minecraft:light[level=12]
setblock 548 273 285 minecraft:light[level=12]
setblock 548 273 292 minecraft:light[level=12]
setblock 548 273 299 minecraft:light[level=12]
setblock 548 273 306 minecraft:light[level=12]
setblock 548 273 313 minecraft:light[level=12]
fill 549 273 275 549 280 275 minecraft:brown_terracotta
fill 549 273 317 549 280 317 minecraft:brown_terracotta
fill 553 273 275 553 280 275 minecraft:brown_terracotta
fill 553 273 317 553 280 317 minecraft:brown_terracotta
setblock 555 273 278 minecraft:light[level=12]
setblock 555 273 285 minecraft:light[level=12]
setblock 555 273 292 minecraft:light[level=12]
setblock 555 273 299 minecraft:light[level=12]
setblock 555 273 306 minecraft:light[level=12]
setblock 555 273 313 minecraft:light[level=12]
fill 557 273 275 557 280 275 minecraft:brown_terracotta
fill 557 273 317 557 280 317 minecraft:brown_terracotta
fill 559 273 275 559 278 275 minecraft:brown_terracotta
fill 559 273 279 559 280 279 minecraft:brown_terracotta
fill 559 273 283 559 280 283 minecraft:brown_terracotta
fill 559 273 287 559 280 287 minecraft:brown_terracotta
fill 559 273 291 559 280 291 minecraft:brown_terracotta
fill 559 273 295 559 280 295 minecraft:brown_terracotta
fill 559 273 299 559 280 299 minecraft:brown_terracotta
fill 559 273 303 559 280 303 minecraft:brown_terracotta
fill 559 273 307 559 280 307 minecraft:brown_terracotta
fill 559 273 311 559 280 311 minecraft:brown_terracotta
fill 559 273 315 559 280 315 minecraft:brown_terracotta
setblock 520 275 278 minecraft:light[level=15]
setblock 520 275 286 minecraft:light[level=15]
setblock 520 275 294 minecraft:light[level=15]
setblock 520 275 302 minecraft:light[level=15]
setblock 520 275 310 minecraft:light[level=15]
setblock 528 275 278 minecraft:light[level=15]
setblock 528 275 286 minecraft:light[level=15]
setblock 528 275 294 minecraft:light[level=15]
setblock 528 275 302 minecraft:light[level=15]
setblock 528 275 310 minecraft:light[level=15]
setblock 536 275 278 minecraft:light[level=15]
setblock 536 275 286 minecraft:light[level=15]
setblock 536 275 294 minecraft:light[level=15]
setblock 536 275 302 minecraft:light[level=15]
setblock 536 275 310 minecraft:light[level=15]
setblock 544 275 278 minecraft:light[level=15]
setblock 544 275 286 minecraft:light[level=15]
setblock 544 275 294 minecraft:light[level=15]
setblock 544 275 302 minecraft:light[level=15]
setblock 544 275 310 minecraft:light[level=15]
setblock 552 275 278 minecraft:light[level=15]
setblock 552 275 286 minecraft:light[level=15]
setblock 552 275 294 minecraft:light[level=15]
setblock 552 275 302 minecraft:light[level=15]
setblock 552 275 310 minecraft:light[level=15]
fill 526 277 299 533 278 299 minecraft:brown_terracotta
fill 527 277 295 534 278 298 minecraft:brown_terracotta
fill 527 277 300 534 278 303 minecraft:brown_terracotta
fill 528 277 293 546 278 294 minecraft:brown_terracotta
fill 528 277 304 546 277 305 minecraft:brown_terracotta
fill 529 277 292 545 278 292 minecraft:brown_terracotta
fill 529 277 306 545 278 306 minecraft:brown_terracotta
fill 530 277 291 544 278 291 minecraft:brown_terracotta
fill 530 277 307 544 278 307 minecraft:brown_terracotta
fill 531 277 290 543 278 290 minecraft:brown_terracotta
fill 531 277 308 543 278 308 minecraft:brown_terracotta
fill 533 277 289 541 278 289 minecraft:brown_terracotta
fill 533 277 309 541 278 309 minecraft:brown_terracotta
fill 535 277 295 536 278 296 minecraft:brown_terracotta
fill 535 277 302 536 278 303 minecraft:brown_terracotta
fill 537 277 288 537 278 288 minecraft:brown_terracotta
fill 537 277 295 547 278 295 minecraft:brown_terracotta
fill 537 277 303 547 278 303 minecraft:brown_terracotta
fill 537 277 310 537 278 310 minecraft:brown_terracotta
fill 538 277 296 547 278 296 minecraft:brown_terracotta
fill 538 277 302 547 278 302 minecraft:brown_terracotta
fill 540 277 297 547 278 298 minecraft:brown_terracotta
fill 540 277 300 547 278 301 minecraft:brown_terracotta
fill 541 277 299 548 278 299 minecraft:brown_terracotta
fill 528 278 304 532 278 305 minecraft:brown_terracotta
fill 533 278 304 546 278 304 minecraft:brown_terracotta
fill 533 278 305 533 280 305 minecraft:red_concrete
fill 534 278 305 536 278 305 minecraft:brown_terracotta
fill 537 278 305 537 280 305 minecraft:lime_concrete
fill 538 278 305 540 278 305 minecraft:brown_terracotta
fill 541 278 305 541 280 305 minecraft:light_blue_concrete
fill 542 278 305 546 278 305 minecraft:brown_terracotta
setblock 517 279 277 minecraft:white_concrete
setblock 517 279 280 minecraft:brown_terracotta
setblock 517 279 281 minecraft:white_concrete
setblock 517 279 282 minecraft:brown_terracotta
setblock 517 279 285 minecraft:white_concrete
setblock 517 279 289 minecraft:white_concrete
setblock 517 279 292 minecraft:brown_terracotta
setblock 517 279 293 minecraft:white_concrete
setblock 517 279 294 minecraft:brown_terracotta
setblock 517 279 297 minecraft:white_concrete
setblock 517 279 301 minecraft:white_concrete
setblock 517 279 304 minecraft:brown_terracotta
setblock 517 279 305 minecraft:white_concrete
setblock 517 279 306 minecraft:brown_terracotta
setblock 517 279 309 minecraft:white_concrete
setblock 517 279 313 minecraft:white_concrete
setblock 517 279 317 minecraft:white_concrete
fill 518 279 276 518 279 277 minecraft:snow_block
setblock 518 279 278 minecraft:white_wool
fill 518 279 279 518 279 281 minecraft:snow_block
setblock 518 279 282 minecraft:white_wool
fill 518 279 283 518 279 285 minecraft:snow_block
setblock 518 279 286 minecraft:white_wool
fill 518 279 287 518 279 289 minecraft:snow_block
setblock 518 279 290 minecraft:white_wool
fill 518 279 291 518 279 293 minecraft:snow_block
setblock 518 279 294 minecraft:white_wool
fill 518 279 295 518 279 297 minecraft:snow_block
setblock 518 279 298 minecraft:white_wool
fill 518 279 299 518 279 301 minecraft:snow_block
setblock 518 279 302 minecraft:white_wool
fill 518 279 303 518 279 305 minecraft:snow_block
setblock 518 279 306 minecraft:white_wool
fill 518 279 307 518 279 309 minecraft:snow_block
setblock 518 279 310 minecraft:white_wool
fill 518 279 311 518 279 313 minecraft:snow_block
setblock 518 279 314 minecraft:white_wool
fill 518 279 315 519 279 316 minecraft:snow_block
setblock 518 279 317 minecraft:brown_terracotta
setblock 519 279 275 minecraft:white_concrete
setblock 519 279 276 minecraft:snow_block
setblock 519 279 277 minecraft:white_wool
fill 519 279 278 519 279 280 minecraft:snow_block
setblock 519 279 281 minecraft:white_wool
fill 519 279 282 519 279 284 minecraft:snow_block
setblock 519 279 285 minecraft:white_wool
fill 519 279 286 519 279 288 minecraft:snow_block
setblock 519 279 289 minecraft:white_wool
fill 519 279 290 519 279 292 minecraft:snow_block
setblock 519 279 293 minecraft:white_wool
fill 519 279 294 519 279 296 minecraft:snow_block
setblock 519 279 297 minecraft:white_wool
fill 519 279 298 519 279 300 minecraft:snow_block
setblock 519 279 301 minecraft:white_wool
fill 519 279 302 519 279 304 minecraft:snow_block
setblock 519 279 305 minecraft:white_wool
fill 519 279 306 519 279 308 minecraft:snow_block
setblock 519 279 309 minecraft:white_wool
fill 519 279 310 519 279 312 minecraft:snow_block
setblock 519 279 313 minecraft:white_wool
fill 519 279 314 521 279 314 minecraft:snow_block
setblock 519 279 317 minecraft:white_concrete
setblock 520 279 276 minecraft:white_wool
fill 520 279 277 520 279 279 minecraft:snow_block
setblock 520 279 280 minecraft:white_wool
fill 520 279 281 520 279 283 minecraft:snow_block
setblock 520 279 284 minecraft:white_wool
fill 520 279 285 520 279 287 minecraft:snow_block
setblock 520 279 288 minecraft:white_wool
fill 520 279 289 520 279 291 minecraft:snow_block
setblock 520 279 292 minecraft:white_wool
fill 520 279 293 520 279 295 minecraft:snow_block
setblock 520 279 296 minecraft:white_wool
fill 520 279 297 520 279 299 minecraft:snow_block
setblock 520 279 300 minecraft:white_wool
fill 520 279 301 520 279 303 minecraft:snow_block
setblock 520 279 304 minecraft:white_wool
fill 520 279 305 520 279 307 minecraft:snow_block
setblock 520 279 308 minecraft:white_wool
fill 520 279 309 520 279 311 minecraft:snow_block
setblock 520 279 312 minecraft:white_wool
fill 520 279 313 522 279 313 minecraft:snow_block
setblock 520 279 315 minecraft:snow_block
setblock 520 279 316 minecraft:white_wool
setblock 520 279 317 minecraft:brown_terracotta
fill 521 279 276 521 279 278 minecraft:snow_block
setblock 521 279 279 minecraft:white_wool
fill 521 279 280 521 279 282 minecraft:snow_block
setblock 521 279 283 minecraft:white_wool
fill 521 279 284 521 279 286 minecraft:snow_block
setblock 521 279 287 minecraft:white_wool
fill 521 279 288 521 279 290 minecraft:snow_block
setblock 521 279 291 minecraft:white_wool
fill 521 279 292 521 279 294 minecraft:snow_block
setblock 521 279 295 minecraft:white_wool
fill 521 279 296 521 279 298 minecraft:snow_block
setblock 521 279 299 minecraft:white_wool
fill 521 279 300 521 279 302 minecraft:snow_block
setblock 521 279 303 minecraft:white_wool
fill 521 279 304 521 279 306 minecraft:snow_block
setblock 521 279 307 minecraft:white_wool
fill 521 279 308 521 279 310 minecraft:snow_block
setblock 521 279 311 minecraft:white_wool
fill 521 279 312 523 279 312 minecraft:snow_block
setblock 521 279 315 minecraft:white_wool
fill 521 279 316 523 279 316 minecraft:snow_block
fill 522 279 276 522 279 277 minecraft:snow_block
setblock 522 279 278 minecraft:white_wool
fill 522 279 279 522 279 281 minecraft:snow_block
setblock 522 279 282 minecraft:white_wool
fill 522 279 283 522 279 285 minecraft:snow_block
setblock 522 279 286 minecraft:white_wool
fill 522 279 287 522 279 289 minecraft:snow_block
setblock 522 279 290 minecraft:white_wool
fill 522 279 291 522 279 293 minecraft:snow_block
setblock 522 279 294 minecraft:white_wool
fill 522 279 295 522 279 297 minecraft:snow_block
setblock 522 279 298 minecraft:white_wool
fill 522 279 299 522 279 301 minecraft:snow_block
setblock 522 279 302 minecraft:white_wool
fill 522 279 303 522 279 305 minecraft:snow_block
setblock 522 279 306 minecraft:white_wool
fill 522 279 307 522 279 309 minecraft:snow_block
setblock 522 279 310 minecraft:white_wool
fill 522 279 311 524 279 311 minecraft:snow_block
setblock 522 279 314 minecraft:white_wool
fill 522 279 315 524 279 315 minecraft:snow_block
setblock 523 279 275 minecraft:white_concrete
setblock 523 279 276 minecraft:snow_block
setblock 523 279 277 minecraft:white_wool
fill 523 279 278 523 279 280 minecraft:snow_block
setblock 523 279 281 minecraft:white_wool
fill 523 279 282 523 279 284 minecraft:snow_block
setblock 523 279 285 minecraft:white_wool
fill 523 279 286 523 279 288 minecraft:snow_block
setblock 523 279 289 minecraft:white_wool
fill 523 279 290 523 279 292 minecraft:snow_block
setblock 523 279 293 minecraft:white_wool
fill 523 279 294 523 279 296 minecraft:snow_block
setblock 523 279 297 minecraft:white_wool
fill 523 279 298 523 279 300 minecraft:snow_block
setblock 523 279 301 minecraft:white_wool
fill 523 279 302 523 279 304 minecraft:snow_block
setblock 523 279 305 minecraft:white_wool
fill 523 279 306 523 279 308 minecraft:snow_block
setblock 523 279 309 minecraft:white_wool
fill 523 279 310 525 279 310 minecraft:snow_block
setblock 523 279 313 minecraft:white_wool
fill 523 279 314 525 279 314 minecraft:snow_block
setblock 523 279 317 minecraft:white_concrete
setblock 524 279 276 minecraft:white_wool
fill 524 279 277 524 279 279 minecraft:snow_block
setblock 524 279 280 minecraft:white_wool
fill 524 279 281 524 279 283 minecraft:snow_block
setblock 524 279 284 minecraft:white_wool
fill 524 279 285 524 279 287 minecraft:snow_block
setblock 524 279 288 minecraft:white_wool
fill 524 279 289 524 279 291 minecraft:snow_block
setblock 524 279 292 minecraft:white_wool
fill 524 279 293 524 279 295 minecraft:snow_block
setblock 524 279 296 minecraft:white_wool
fill 524 279 297 524 279 299 minecraft:snow_block
setblock 524 279 300 minecraft:white_wool
fill 524 279 301 524 279 303 minecraft:snow_block
setblock 524 279 304 minecraft:white_wool
fill 524 279 305 524 279 307 minecraft:snow_block
setblock 524 279 308 minecraft:white_wool
fill 524 279 309 526 279 309 minecraft:snow_block
setblock 524 279 312 minecraft:white_wool
fill 524 279 313 526 279 313 minecraft:snow_block
setblock 524 279 316 minecraft:white_wool
fill 525 279 276 525 279 278 minecraft:snow_block
setblock 525 279 279 minecraft:white_wool
fill 525 279 280 525 279 282 minecraft:snow_block
setblock 525 279 283 minecraft:white_wool
fill 525 279 284 525 279 286 minecraft:snow_block
setblock 525 279 287 minecraft:white_wool
fill 525 279 288 525 279 290 minecraft:snow_block
setblock 525 279 291 minecraft:white_wool
fill 525 279 292 525 279 294 minecraft:snow_block
setblock 525 279 295 minecraft:white_wool
fill 525 279 296 525 279 298 minecraft:snow_block
setblock 525 279 299 minecraft:white_wool
fill 525 279 300 525 279 302 minecraft:snow_block
setblock 525 279 303 minecraft:white_wool
fill 525 279 304 525 279 306 minecraft:snow_block
setblock 525 279 307 minecraft:white_wool
fill 525 279 308 527 279 308 minecraft:snow_block
setblock 525 279 311 minecraft:white_wool
fill 525 279 312 527 279 312 minecraft:snow_block
setblock 525 279 315 minecraft:white_wool
fill 525 279 316 527 279 316 minecraft:snow_block
setblock 526 279 275 minecraft:brown_terracotta
fill 526 279 276 526 279 277 minecraft:snow_block
setblock 526 279 278 minecraft:white_wool
fill 526 279 279 526 279 281 minecraft:snow_block
setblock 526 279 282 minecraft:white_wool
fill 526 279 283 526 279 285 minecraft:snow_block
setblock 526 279 286 minecraft:white_wool
fill 526 279 287 526 279 289 minecraft:snow_block
setblock 526 279 290 minecraft:white_wool
fill 526 279 291 526 279 293 minecraft:snow_block
setblock 526 279 294 minecraft:white_wool
fill 526 279 295 526 279 297 minecraft:snow_block
setblock 526 279 298 minecraft:white_wool
setblock 526 279 299 minecraft:orange_terracotta
fill 526 279 300 526 279 301 minecraft:snow_block
setblock 526 279 302 minecraft:white_wool
fill 526 279 303 526 279 305 minecraft:snow_block
setblock 526 279 306 minecraft:white_wool
fill 526 279 307 528 279 307 minecraft:snow_block
setblock 526 279 310 minecraft:white_wool
fill 526 279 311 528 279 311 minecraft:snow_block
setblock 526 279 314 minecraft:white_wool
fill 526 279 315 528 279 315 minecraft:snow_block
setblock 527 279 275 minecraft:white_concrete
setblock 527 279 276 minecraft:snow_block
setblock 527 279 277 minecraft:white_wool
fill 527 279 278 527 279 280 minecraft:snow_block
setblock 527 279 281 minecraft:white_wool
fill 527 279 282 527 279 284 minecraft:snow_block
setblock 527 279 285 minecraft:white_wool
fill 527 279 286 527 279 288 minecraft:snow_block
setblock 527 279 289 minecraft:white_wool
fill 527 279 290 527 279 292 minecraft:snow_block
setblock 527 279 293 minecraft:white_wool
setblock 527 279 294 minecraft:snow_block
fill 527 279 295 529 279 295 minecraft:orange_terracotta
fill 527 279 296 527 279 302 minecraft:white_concrete
fill 527 279 303 529 279 303 minecraft:orange_terracotta
setblock 527 279 304 minecraft:snow_block
setblock 527 279 305 minecraft:white_wool
fill 527 279 306 528 279 306 minecraft:snow_block
setblock 527 279 309 minecraft:white_wool
fill 527 279 310 529 279 310 minecraft:snow_block
setblock 527 279 313 minecraft:white_wool
fill 527 279 314 529 279 314 minecraft:snow_block
setblock 527 279 317 minecraft:white_concrete
setblock 528 279 275 minecraft:brown_terracotta
setblock 528 279 276 minecraft:white_wool
fill 528 279 277 528 279 279 minecraft:snow_block
setblock 528 279 280 minecraft:white_wool
fill 528 279 281 528 279 283 minecraft:snow_block
setblock 528 279 284 minecraft:white_wool
fill 528 279 285 528 279 287 minecraft:snow_block
setblock 528 279 288 minecraft:white_wool
fill 528 279 289 528 279 291 minecraft:snow_block
setblock 528 279 292 minecraft:white_wool
setblock 528 279 293 minecraft:orange_terracotta
setblock 528 279 294 minecraft:white_concrete
fill 528 279 296 528 279 302 minecraft:orange_terracotta
setblock 528 279 304 minecraft:white_concrete
setblock 528 279 305 minecraft:orange_terracotta
setblock 528 279 308 minecraft:white_wool
fill 528 279 309 530 279 309 minecraft:snow_block
setblock 528 279 312 minecraft:white_wool
fill 528 279 313 530 279 313 minecraft:snow_block
setblock 528 279 316 minecraft:white_wool
fill 529 279 276 529 279 278 minecraft:snow_block
setblock 529 279 279 minecraft:white_wool
fill 529 279 280 529 279 282 minecraft:snow_block
setblock 529 279 283 minecraft:white_wool
fill 529 279 284 529 279 286 minecraft:snow_block
setblock 529 279 287 minecraft:white_wool
fill 529 279 288 529 279 290 minecraft:snow_block
setblock 529 279 291 minecraft:white_wool
fill 529 279 292 529 279 293 minecraft:white_concrete
fill 529 279 294 530 279 294 minecraft:orange_terracotta
fill 529 279 296 533 279 296 minecraft:orange_terracotta
fill 529 279 297 529 279 301 minecraft:white_concrete
fill 529 279 302 533 279 302 minecraft:orange_terracotta
fill 529 279 304 530 279 304 minecraft:orange_terracotta
fill 529 279 305 529 279 306 minecraft:white_concrete
setblock 529 279 307 minecraft:white_wool
fill 529 279 308 530 279 308 minecraft:snow_block
setblock 529 279 311 minecraft:white_wool
fill 529 279 312 531 279 312 minecraft:snow_block
setblock 529 279 315 minecraft:white_wool
fill 529 279 316 531 279 316 minecraft:snow_block
fill 530 279 276 530 279 277 minecraft:snow_block
setblock 530 279 278 minecraft:white_wool
fill 530 279 279 530 279 281 minecraft:snow_block
setblock 530 279 282 minecraft:white_wool
fill 530 279 283 530 279 285 minecraft:snow_block
setblock 530 279 286 minecraft:white_wool
fill 530 279 287 530 279 289 minecraft:snow_block
setblock 530 279 290 minecraft:white_wool
fill 530 279 291 530 279 292 minecraft:white_concrete
fill 530 279 293 531 279 293 minecraft:orange_terracotta
setblock 530 279 295 minecraft:white_concrete
fill 530 279 297 532 279 301 minecraft:orange_terracotta
setblock 530 279 303 minecraft:white_concrete
fill 530 279 305 531 279 305 minecraft:orange_terracotta
fill 530 279 306 530 279 307 minecraft:white_concrete
setblock 530 279 310 minecraft:white_wool
fill 530 279 311 532 279 311 minecraft:snow_block
setblock 530 279 314 minecraft:white_wool
fill 530 279 315 532 279 315 minecraft:snow_block
setblock 530 279 317 minecraft:brown_terracotta
setblock 531 279 275 minecraft:white_concrete
setblock 531 279 276 minecraft:snow_block
setblock 531 279 277 minecraft:white_wool
fill 531 279 278 531 279 280 minecraft:snow_block
setblock 531 279 281 minecraft:white_wool
fill 531 279 282 531 279 284 minecraft:snow_block
setblock 531 279 285 minecraft:white_wool
fill 531 279 286 531 279 288 minecraft:snow_block
setblock 531 279 289 minecraft:white_wool
setblock 531 279 290 minecraft:orange_terracotta
setblock 531 279 291 minecraft:white_concrete
fill 531 279 292 532 279 292 minecraft:orange_terracotta
setblock 531 279 294 minecraft:white_concrete
fill 531 279 295 535 279 295 minecraft:orange_terracotta
fill 531 279 303 535 279 303 minecraft:orange_terracotta
setblock 531 279 304 minecraft:white_concrete
fill 531 279 306 532 279 306 minecraft:orange_terracotta
setblock 531 279 307 minecraft:white_concrete
setblock 531 279 308 minecraft:orange_terracotta
setblock 531 279 309 minecraft:white_wool
fill 531 279 310 533 279 310 minecraft:snow_block
setblock 531 279 313 minecraft:white_wool
fill 531 279 314 533 279 314 minecraft:snow_block
setblock 531 279 317 minecraft:white_concrete
setblock 532 279 276 minecraft:white_wool
fill 532 279 277 532 279 279 minecraft:snow_block
setblock 532 279 280 minecraft:white_wool
fill 532 279 281 532 279 283 minecraft:snow_block
setblock 532 279 284 minecraft:white_wool
fill 532 279 285 532 279 287 minecraft:snow_block
setblock 532 279 288 minecraft:white_wool
setblock 532 279 289 minecraft:snow_block
setblock 532 279 290 minecraft:white_concrete
fill 532 279 291 534 279 291 minecraft:orange_terracotta
setblock 532 279 293 minecraft:white_concrete
fill 532 279 294 533 279 294 minecraft:orange_terracotta
setblock 532 279 304 minecraft:orange_terracotta
setblock 532 279 305 minecraft:red_concrete
fill 532 279 307 534 279 307 minecraft:orange_terracotta
setblock 532 279 308 minecraft:white_concrete
setblock 532 279 309 minecraft:snow_block
setblock 532 279 312 minecraft:white_wool
fill 532 279 313 534 279 313 minecraft:snow_block
setblock 532 279 316 minecraft:white_wool
setblock 532 279 317 minecraft:brown_terracotta
fill 533 279 276 533 279 278 minecraft:snow_block
setblock 533 279 279 minecraft:white_wool
fill 533 279 280 533 279 282 minecraft:snow_block
setblock 533 279 283 minecraft:white_wool
fill 533 279 284 533 279 286 minecraft:snow_block
setblock 533 279 287 minecraft:white_wool
fill 533 279 288 535 279 288 minecraft:snow_block
fill 533 279 289 533 279 290 minecraft:orange_terracotta
setblock 533 279 292 minecraft:white_concrete
fill 533 279 293 541 279 293 minecraft:orange_terracotta
setblock 533 279 297 minecraft:orange_terracotta
fill 533 279 298 533 279 300 minecraft:white_concrete
setblock 533 279 301 minecraft:orange_terracotta
setblock 533 279 304 minecraft:red_concrete
setblock 533 279 306 minecraft:red_concrete
fill 533 279 308 533 279 309 minecraft:orange_terracotta
setblock 533 279 311 minecraft:white_wool
fill 533 279 312 535 279 312 minecraft:snow_block
setblock 533 279 315 minecraft:white_wool
fill 533 279 316 535 279 316 minecraft:snow_block
fill 534 279 276 534 279 277 minecraft:snow_block
setblock 534 279 278 minecraft:white_wool
fill 534 279 279 534 279 281 minecraft:snow_block
setblock 534 279 282 minecraft:white_wool
fill 534 279 283 534 279 285 minecraft:snow_block
setblock 534 279 286 minecraft:white_wool
fill 534 279 287 536 279 287 minecraft:snow_block
fill 534 279 289 540 279 289 minecraft:white_concrete
fill 534 279 290 541 279 290 minecraft:orange_terracotta
fill 534 279 292 540 279 292 minecraft:orange_terracotta
fill 534 279 294 534 280 294 minecraft:white_concrete
fill 534 279 296 534 279 298 minecraft:white_concrete
fill 534 279 300 534 279 302 minecraft:white_concrete
fill 534 279 304 536 279 304 minecraft:orange_terracotta
setblock 534 279 305 minecraft:red_concrete
fill 534 279 306 536 279 306 minecraft:orange_terracotta
fill 534 279 308 541 279 308 minecraft:orange_terracotta
fill 534 279 309 540 279 309 minecraft:white_concrete
setblock 534 279 310 minecraft:white_wool
fill 534 279 311 536 279 311 minecraft:snow_block
setblock 534 279 314 minecraft:white_wool
fill 534 279 315 536 279 315 minecraft:snow_block
setblock 535 279 275 minecraft:white_concrete
setblock 535 279 276 minecraft:snow_block
setblock 535 279 277 minecraft:white_wool
fill 535 279 278 535 279 280 minecraft:snow_block
setblock 535 279 281 minecraft:white_wool
fill 535 279 282 535 279 284 minecraft:snow_block
setblock 535 279 285 minecraft:white_wool
fill 535 279 286 537 279 286 minecraft:snow_block
fill 535 279 291 539 279 291 minecraft:white_concrete
fill 535 279 294 539 279 294 minecraft:orange_terracotta
fill 535 279 296 536 279 296 minecraft:white_concrete
fill 535 279 302 536 279 302 minecraft:white_concrete
setblock 535 279 305 minecraft:orange_terracotta
fill 535 279 307 539 279 307 minecraft:white_concrete
fill 535 279 310 536 279 310 minecraft:snow_block
setblock 535 279 313 minecraft:white_wool
fill 535 279 314 537 279 314 minecraft:snow_block
setblock 535 279 317 minecraft:white_concrete
setblock 536 279 276 minecraft:white_wool
fill 536 279 277 536 279 279 minecraft:snow_block
setblock 536 279 280 minecraft:white_wool
fill 536 279 281 536 279 283 minecraft:snow_block
setblock 536 279 284 minecraft:white_wool
fill 536 279 285 538 279 285 minecraft:snow_block
setblock 536 279 288 minecraft:white_wool
fill 536 279 295 538 279 295 minecraft:white_concrete
fill 536 279 303 538 279 303 minecraft:white_concrete
setblock 536 279 305 minecraft:lime_concrete
setblock 536 279 312 minecraft:white_wool
fill 536 279 313 538 279 313 minecraft:snow_block
setblock 536 279 316 minecraft:white_wool
fill 537 279 276 537 279 278 minecraft:snow_block
setblock 537 279 279 minecraft:white_wool
fill 537 279 280 537 279 282 minecraft:snow_block
setblock 537 279 283 minecraft:white_wool
fill 537 279 284 539 279 284 minecraft:snow_block
setblock 537 279 287 minecraft:white_wool
setblock 537 279 288 minecraft:orange_terracotta
setblock 537 279 304 minecraft:lime_concrete
setblock 537 279 306 minecraft:lime_concrete
setblock 537 279 310 minecraft:orange_terracotta
setblock 537 279 311 minecraft:white_wool
fill 537 279 312 539 279 312 minecraft:snow_block
setblock 537 279 315 minecraft:white_wool
fill 537 279 316 539 279 316 minecraft:snow_block
setblock 538 279 275 minecraft:brown_terracotta
fill 538 279 276 538 279 277 minecraft:snow_block
setblock 538 279 278 minecraft:white_wool
fill 538 279 279 538 279 281 minecraft:snow_block
setblock 538 279 282 minecraft:white_wool
fill 538 279 283 540 279 283 minecraft:snow_block
setblock 538 279 286 minecraft:white_wool
fill 538 279 287 539 279 288 minecraft:snow_block
fill 538 279 296 540 279 296 minecraft:white_concrete
fill 538 279 302 540 279 302 minecraft:white_concrete
fill 538 279 304 540 279 304 minecraft:orange_terracotta
setblock 538 279 305 minecraft:lime_concrete
fill 538 279 306 540 279 306 minecraft:orange_terracotta
setblock 538 279 310 minecraft:white_wool
fill 538 279 311 540 279 311 minecraft:snow_block
setblock 538 279 314 minecraft:white_wool
fill 538 279 315 540 279 315 minecraft:snow_block
setblock 539 279 275 minecraft:white_concrete
setblock 539 279 276 minecraft:snow_block
setblock 539 279 277 minecraft:white_wool
fill 539 279 278 539 279 280 minecraft:snow_block
setblock 539 279 281 minecraft:white_wool
fill 539 279 282 541 279 282 minecraft:snow_block
setblock 539 279 285 minecraft:white_wool
fill 539 279 286 541 279 286 minecraft:snow_block
fill 539 279 295 543 279 295 minecraft:orange_terracotta
fill 539 279 303 543 279 303 minecraft:orange_terracotta
setblock 539 279 305 minecraft:orange_terracotta
fill 539 279 310 541 279 310 minecraft:snow_block
setblock 539 279 313 minecraft:white_wool
fill 539 279 314 541 279 314 minecraft:snow_block
setblock 539 279 317 minecraft:white_concrete
setblock 540 279 275 minecraft:brown_terracotta
setblock 540 279 276 minecraft:white_wool
fill 540 279 277 540 279 279 minecraft:snow_block
setblock 540 279 280 minecraft:white_wool
fill 540 279 281 542 279 281 minecraft:snow_block
setblock 540 279 284 minecraft:white_wool
fill 540 279 285 542 279 285 minecraft:snow_block
setblock 540 279 287 minecraft:snow_block
setblock 540 279 288 minecraft:white_wool
fill 540 279 291 542 279 291 minecraft:orange_terracotta
fill 540 279 294 540 280 294 minecraft:white_concrete
fill 540 279 297 540 279 298 minecraft:white_concrete
fill 540 279 300 540 279 301 minecraft:white_concrete
setblock 540 279 305 minecraft:light_blue_concrete
fill 540 279 307 542 279 307 minecraft:orange_terracotta
setblock 540 279 312 minecraft:white_wool
fill 540 279 313 542 279 313 minecraft:snow_block
setblock 540 279 316 minecraft:white_wool
fill 541 279 276 541 279 278 minecraft:snow_block
setblock 541 279 279 minecraft:white_wool
fill 541 279 280 543 279 280 minecraft:snow_block
setblock 541 279 283 minecraft:white_wool
fill 541 279 284 543 279 284 minecraft:snow_block
setblock 541 279 287 minecraft:white_wool
fill 541 279 288 543 279 288 minecraft:snow_block
setblock 541 279 289 minecraft:orange_terracotta
setblock 541 279 292 minecraft:white_concrete
fill 541 279 294 542 279 294 minecraft:orange_terracotta
fill 541 279 296 544 279 297 minecraft:orange_terracotta
fill 541 279 298 541 279 300 minecraft:white_concrete
fill 541 279 301 544 279 302 minecraft:orange_terracotta
setblock 541 279 304 minecraft:light_blue_concrete
setblock 541 279 306 minecraft:light_blue_concrete
setblock 541 279 309 minecraft:orange_terracotta
setblock 541 279 311 minecraft:white_wool
fill 541 279 312 543 279 312 minecraft:snow_block
setblock 541 279 315 minecraft:white_wool
fill 541 279 316 543 279 316 minecraft:snow_block
fill 542 279 276 542 279 277 minecraft:snow_block
setblock 542 279 278 minecraft:white_wool
fill 542 279 279 544 279 279 minecraft:snow_block
setblock 542 279 282 minecraft:white_wool
fill 542 279 283 544 279 283 minecraft:snow_block
setblock 542 279 286 minecraft:white_wool
fill 542 279 287 544 279 287 minecraft:snow_block
setblock 542 279 289 minecraft:snow_block
setblock 542 279 290 minecraft:white_concrete
fill 542 279 292 543 279 292 minecraft:orange_terracotta
setblock 542 279 293 minecraft:white_concrete
fill 542 279 298 544 279 300 minecraft:orange_terracotta
setblock 542 279 304 minecraft:orange_terracotta
setblock 542 279 305 minecraft:light_blue_concrete
fill 542 279 306 543 279 306 minecraft:orange_terracotta
setblock 542 279 308 minecraft:white_concrete
setblock 542 279 309 minecraft:snow_block
setblock 542 279 310 minecraft:white_wool
fill 542 279 311 544 279 311 minecraft:snow_block
setblock 542 279 314 minecraft:white_wool
fill 542 279 315 544 279 315 minecraft:snow_block
setblock 542 279 317 minecraft:brown_terracotta
setblock 543 279 275 minecraft:white_concrete
setblock 543 279 276 minecraft:snow_block
setblock 543 279 277 minecraft:white_wool
fill 543 279 278 545 279 278 minecraft:snow_block
setblock 543 279 281 minecraft:white_wool
fill 543 279 282 545 279 282 minecraft:snow_block
setblock 543 279 285 minecraft:white_wool
fill 543 279 286 545 279 286 minecraft:snow_block
setblock 543 279 289 minecraft:white_wool
setblock 543 279 290 minecraft:orange_terracotta
fill 543 279 291 544 279 291 minecraft:white_concrete
fill 543 279 293 544 279 293 minecraft:orange_terracotta
setblock 543 279 294 minecraft:white_concrete
setblock 543 279 304 minecraft:white_concrete
fill 543 279 305 544 279 305 minecraft:orange_terracotta
fill 543 279 307 544 279 307 minecraft:white_concrete
setblock 543 279 308 minecraft:orange_terracotta
setblock 543 279 309 minecraft:white_wool
fill 543 279 310 545 279 310 minecraft:snow_block
setblock 543 279 313 minecraft:white_wool
fill 543 279 314 545 279 314 minecraft:snow_block
setblock 543 279 317 minecraft:white_concrete
setblock 544 279 276 minecraft:white_wool
fill 544 279 277 546 279 277 minecraft:snow_block
setblock 544 279 280 minecraft:white_wool
fill 544 279 281 546 279 281 minecraft:snow_block
setblock 544 279 284 minecraft:white_wool
fill 544 279 285 546 279 285 minecraft:snow_block
setblock 544 279 288 minecraft:white_wool
fill 544 279 289 545 279 290 minecraft:snow_block
fill 544 279 292 545 279 292 minecraft:white_concrete
fill 544 279 294 545 279 294 minecraft:orange_terracotta
setblock 544 279 295 minecraft:white_concrete
setblock 544 279 303 minecraft:white_concrete
fill 544 279 304 545 279 304 minecraft:orange_terracotta
fill 544 279 306 545 279 306 minecraft:white_concrete
setblock 544 279 308 minecraft:white_wool
fill 544 279 309 546 279 309 minecraft:snow_block
setblock 544 279 312 minecraft:white_wool
fill 544 279 313 546 279 313 minecraft:snow_block
setblock 544 279 316 minecraft:white_wool
setblock 544 279 317 minecraft:brown_terracotta
fill 545 279 276 547 279 276 minecraft:snow_block
setblock 545 279 279 minecraft:white_wool
fill 545 279 280 547 279 280 minecraft:snow_block
setblock 545 279 283 minecraft:white_wool
fill 545 279 284 547 279 284 minecraft:snow_block
setblock 545 279 287 minecraft:white_wool
fill 545 279 288 547 279 288 minecraft:snow_block
setblock 545 279 291 minecraft:white_wool
setblock 545 279 293 minecraft:white_concrete
fill 545 279 295 546 279 296 minecraft:orange_terracotta
fill 545 279 297 545 279 301 minecraft:white_concrete
fill 545 279 302 546 279 303 minecraft:orange_terracotta
setblock 545 279 305 minecraft:white_concrete
setblock 545 279 307 minecraft:white_wool
fill 545 279 308 547 279 308 minecraft:snow_block
setblock 545 279 311 minecraft:white_wool
fill 545 279 312 547 279 312 minecraft:snow_block
setblock 545 279 315 minecraft:white_wool
fill 545 279 316 547 279 316 minecraft:snow_block
setblock 546 279 278 minecraft:white_wool
fill 546 279 279 548 279 279 minecraft:snow_block
setblock 546 279 282 minecraft:white_wool
fill 546 279 283 548 279 283 minecraft:snow_block
setblock 546 279 286 minecraft:white_wool
fill 546 279 287 548 279 287 minecraft:snow_block
setblock 546 279 289 minecraft:snow_block
setblock 546 279 290 minecraft:white_wool
fill 546 279 291 547 279 292 minecraft:snow_block
setblock 546 279 293 minecraft:orange_terracotta
setblock 546 279 294 minecraft:white_concrete
fill 546 279 297 546 279 301 minecraft:orange_terracotta
setblock 546 279 304 minecraft:white_concrete
setblock 546 279 305 minecraft:orange_terracotta
setblock 546 279 306 minecraft:white_wool
fill 546 279 307 548 279 307 minecraft:snow_block
setblock 546 279 310 minecraft:white_wool
fill 546 279 311 548 279 311 minecraft:snow_block
setblock 546 279 314 minecraft:white_wool
fill 546 279 315 548 279 315 minecraft:snow_block
setblock 547 279 275 minecraft:white_concrete
setblock 547 279 277 minecraft:white_wool
fill 547 279 278 549 279 278 minecraft:snow_block
setblock 547 279 281 minecraft:white_wool
fill 547 279 282 549 279 282 minecraft:snow_block
setblock 547 279 285 minecraft:white_wool
fill 547 279 286 549 279 286 minecraft:snow_block
setblock 547 279 289 minecraft:white_wool
fill 547 279 290 549 279 290 minecraft:snow_block
setblock 547 279 293 minecraft:white_wool
fill 547 279 294 549 279 294 minecraft:snow_block
setblock 547 279 295 minecraft:orange_terracotta
fill 547 279 296 547 279 302 minecraft:white_concrete
setblock 547 279 303 minecraft:orange_terracotta
setblock 547 279 304 minecraft:snow_block
setblock 547 279 305 minecraft:white_wool
fill 547 279 306 549 279 306 minecraft:snow_block
setblock 547 279 309 minecraft:white_wool
fill 547 279 310 549 279 310 minecraft:snow_block
setblock 547 279 313 minecraft:white_wool
fill 547 279 314 549 279 314 minecraft:snow_block
setblock 547 279 317 minecraft:white_concrete
setblock 548 279 276 minecraft:white_wool
fill 548 279 277 550 279 277 minecraft:snow_block
setblock 548 279 280 minecraft:white_wool
fill 548 279 281 550 279 281 minecraft:snow_block
setblock 548 279 284 minecraft:white_wool
fill 548 279 285 550 279 285 minecraft:snow_block
setblock 548 279 288 minecraft:white_wool
fill 548 279 289 550 279 289 minecraft:snow_block
setblock 548 279 291 minecraft:snow_block
setblock 548 279 292 minecraft:white_wool
fill 548 279 293 550 279 293 minecraft:snow_block
setblock 548 279 295 minecraft:snow_block
setblock 548 279 296 minecraft:white_wool
fill 548 279 297 549 279 298 minecraft:snow_block
setblock 548 279 299 minecraft:orange_terracotta
setblock 548 279 300 minecraft:white_wool
fill 548 279 301 548 279 303 minecraft:snow_block
setblock 548 279 304 minecraft:white_wool
fill 548 279 305 550 279 305 minecraft:snow_block
setblock 548 279 308 minecraft:white_wool
fill 548 279 309 550 279 309 minecraft:snow_block
setblock 548 279 312 minecraft:white_wool
fill 548 279 313 550 279 313 minecraft:snow_block
setblock 548 279 316 minecraft:white_wool
fill 549 279 276 551 279 276 minecraft:snow_block
setblock 549 279 279 minecraft:white_wool
fill 549 279 280 551 279 280 minecraft:snow_block
setblock 549 279 283 minecraft:white_wool
fill 549 279 284 551 279 284 minecraft:snow_block
setblock 549 279 287 minecraft:white_wool
fill 549 279 288 551 279 288 minecraft:snow_block
setblock 549 279 291 minecraft:white_wool
fill 549 279 292 551 279 292 minecraft:snow_block
setblock 549 279 295 minecraft:white_wool
fill 549 279 296 551 279 296 minecraft:snow_block
setblock 549 279 299 minecraft:white_wool
fill 549 279 300 549 279 302 minecraft:snow_block
setblock 549 279 303 minecraft:white_wool
fill 549 279 304 551 279 304 minecraft:snow_block
setblock 549 279 307 minecraft:white_wool
fill 549 279 308 551 279 308 minecraft:snow_block
setblock 549 279 311 minecraft:white_wool
fill 549 279 312 551 279 312 minecraft:snow_block
setblock 549 279 315 minecraft:white_wool
fill 549 279 316 551 279 316 minecraft:snow_block
setblock 550 279 275 minecraft:brown_terracotta
setblock 550 279 278 minecraft:white_wool
fill 550 279 279 552 279 279 minecraft:snow_block
setblock 550 279 282 minecraft:white_wool
fill 550 279 283 552 279 283 minecraft:snow_block
setblock 550 279 286 minecraft:white_wool
fill 550 279 287 552 279 287 minecraft:snow_block
setblock 550 279 290 minecraft:white_wool
fill 550 279 291 552 279 291 minecraft:snow_block
setblock 550 279 294 minecraft:white_wool
fill 550 279 295 552 279 295 minecraft:snow_block
setblock 550 279 297 minecraft:snow_block
setblock 550 279 298 minecraft:white_wool
fill 550 279 299 550 279 301 minecraft:snow_block
setblock 550 279 302 minecraft:white_wool
fill 550 279 303 552 279 303 minecraft:snow_block
setblock 550 279 306 minecraft:white_wool
fill 550 279 307 552 279 307 minecraft:snow_block
setblock 550 279 310 minecraft:white_wool
fill 550 279 311 552 279 311 minecraft:snow_block
setblock 550 279 314 minecraft:white_wool
fill 550 279 315 552 279 315 minecraft:snow_block
setblock 551 279 275 minecraft:white_concrete
setblock 551 279 277 minecraft:white_wool
fill 551 279 278 553 279 278 minecraft:snow_block
setblock 551 279 281 minecraft:white_wool
fill 551 279 282 553 279 282 minecraft:snow_block
setblock 551 279 285 minecraft:white_wool
fill 551 279 286 553 279 286 minecraft:snow_block
setblock 551 279 289 minecraft:white_wool
fill 551 279 290 553 279 290 minecraft:snow_block
setblock 551 279 293 minecraft:white_wool
fill 551 279 294 553 279 294 minecraft:snow_block
setblock 551 279 297 minecraft:white_wool
fill 551 279 298 551 279 300 minecraft:snow_block
setblock 551 279 301 minecraft:white_wool
fill 551 279 302 553 279 302 minecraft:snow_block
setblock 551 279 305 minecraft:white_wool
fill 551 279 306 553 279 306 minecraft:snow_block
setblock 551 279 309 minecraft:white_wool
fill 551 279 310 553 279 310 minecraft:snow_block
setblock 551 279 313 minecraft:white_wool
fill 551 279 314 553 279 314 minecraft:snow_block
setblock 551 279 317 minecraft:white_concrete
setblock 552 279 275 minecraft:brown_terracotta
setblock 552 279 276 minecraft:white_wool
fill 552 279 277 554 279 277 minecraft:snow_block
setblock 552 279 280 minecraft:white_wool
fill 552 279 281 554 279 281 minecraft:snow_block
setblock 552 279 284 minecraft:white_wool
fill 552 279 285 554 279 285 minecraft:snow_block
setblock 552 279 288 minecraft:white_wool
fill 552 279 289 554 279 289 minecraft:snow_block
setblock 552 279 292 minecraft:white_wool
fill 552 279 293 554 279 293 minecraft:snow_block
setblock 552 279 296 minecraft:white_wool
fill 552 279 297 552 279 299 minecraft:snow_block
setblock 552 279 300 minecraft:white_wool
fill 552 279 301 554 279 301 minecraft:snow_block
setblock 552 279 304 minecraft:white_wool
fill 552 279 305 554 279 305 minecraft:snow_block
setblock 552 279 308 minecraft:white_wool
fill 552 279 309 554 279 309 minecraft:snow_block
setblock 552 279 312 minecraft:white_wool
fill 552 279 313 554 279 313 minecraft:snow_block
setblock 552 279 316 minecraft:white_wool
fill 553 279 276 555 279 276 minecraft:snow_block
setblock 553 279 279 minecraft:white_wool
fill 553 279 280 555 279 280 minecraft:snow_block
setblock 553 279 283 minecraft:white_wool
fill 553 279 284 555 279 284 minecraft:snow_block
setblock 553 279 287 minecraft:white_wool
fill 553 279 288 555 279 288 minecraft:snow_block
setblock 553 279 291 minecraft:white_wool
fill 553 279 292 555 279 292 minecraft:snow_block
setblock 553 279 295 minecraft:white_wool
fill 553 279 296 553 279 298 minecraft:snow_block
setblock 553 279 299 minecraft:white_wool
fill 553 279 300 555 279 300 minecraft:snow_block
setblock 553 279 303 minecraft:white_wool
fill 553 279 304 555 279 304 minecraft:snow_block
setblock 553 279 307 minecraft:white_wool
fill 553 279 308 555 279 308 minecraft:snow_block
setblock 553 279 311 minecraft:white_wool
fill 553 279 312 555 279 312 minecraft:snow_block
setblock 553 279 315 minecraft:white_wool
fill 553 279 316 555 279 316 minecraft:snow_block
setblock 554 279 278 minecraft:white_wool
fill 554 279 279 556 279 279 minecraft:snow_block
setblock 554 279 282 minecraft:white_wool
fill 554 279 283 556 279 283 minecraft:snow_block
setblock 554 279 286 minecraft:white_wool
fill 554 279 287 556 279 287 minecraft:snow_block
setblock 554 279 290 minecraft:white_wool
fill 554 279 291 556 279 291 minecraft:snow_block
setblock 554 279 294 minecraft:white_wool
fill 554 279 295 554 279 297 minecraft:snow_block
setblock 554 279 298 minecraft:white_wool
fill 554 279 299 556 279 299 minecraft:snow_block
setblock 554 279 302 minecraft:white_wool
fill 554 279 303 556 279 303 minecraft:snow_block
setblock 554 279 306 minecraft:white_wool
fill 554 279 307 556 279 307 minecraft:snow_block
setblock 554 279 310 minecraft:white_wool
fill 554 279 311 556 279 311 minecraft:snow_block
setblock 554 279 314 minecraft:white_wool
fill 554 279 315 556 279 315 minecraft:snow_block
setblock 554 279 317 minecraft:brown_terracotta
setblock 555 279 275 minecraft:white_concrete
setblock 555 279 277 minecraft:white_wool
fill 555 279 278 557 279 278 minecraft:snow_block
setblock 555 279 281 minecraft:white_wool
fill 555 279 282 557 279 282 minecraft:snow_block
setblock 555 279 285 minecraft:white_wool
fill 555 279 286 557 279 286 minecraft:snow_block
setblock 555 279 289 minecraft:white_wool
fill 555 279 290 557 279 290 minecraft:snow_block
setblock 555 279 293 minecraft:white_wool
fill 555 279 294 555 279 296 minecraft:snow_block
setblock 555 279 297 minecraft:white_wool
fill 555 279 298 557 279 298 minecraft:snow_block
setblock 555 279 301 minecraft:white_wool
fill 555 279 302 557 279 302 minecraft:snow_block
setblock 555 279 305 minecraft:white_wool
fill 555 279 306 557 279 306 minecraft:snow_block
setblock 555 279 309 minecraft:white_wool
fill 555 279 310 557 279 310 minecraft:snow_block
setblock 555 279 313 minecraft:white_wool
fill 555 279 314 557 279 314 minecraft:snow_block
setblock 555 279 317 minecraft:white_concrete
setblock 556 279 276 minecraft:white_wool
fill 556 279 277 558 279 277 minecraft:snow_block
setblock 556 279 280 minecraft:white_wool
fill 556 279 281 558 279 281 minecraft:snow_block
setblock 556 279 284 minecraft:white_wool
fill 556 279 285 558 279 285 minecraft:snow_block
setblock 556 279 288 minecraft:white_wool
fill 556 279 289 558 279 289 minecraft:snow_block
setblock 556 279 292 minecraft:white_wool
fill 556 279 293 556 279 295 minecraft:snow_block
setblock 556 279 296 minecraft:white_wool
fill 556 279 297 558 279 297 minecraft:snow_block
setblock 556 279 300 minecraft:white_wool
fill 556 279 301 558 279 301 minecraft:snow_block
setblock 556 279 304 minecraft:white_wool
fill 556 279 305 558 279 305 minecraft:snow_block
setblock 556 279 308 minecraft:white_wool
fill 556 279 309 558 279 309 minecraft:snow_block
setblock 556 279 312 minecraft:white_wool
fill 556 279 313 558 279 313 minecraft:snow_block
setblock 556 279 316 minecraft:white_wool
setblock 556 279 317 minecraft:brown_terracotta
fill 557 279 276 558 279 276 minecraft:snow_block
setblock 557 279 279 minecraft:white_wool
fill 557 279 280 558 279 280 minecraft:snow_block
setblock 557 279 283 minecraft:white_wool
fill 557 279 284 558 279 284 minecraft:snow_block
setblock 557 279 287 minecraft:white_wool
fill 557 279 288 558 279 288 minecraft:snow_block
setblock 557 279 291 minecraft:white_wool
fill 557 279 292 557 279 294 minecraft:snow_block
setblock 557 279 295 minecraft:white_wool
fill 557 279 296 558 279 296 minecraft:snow_block
setblock 557 279 299 minecraft:white_wool
fill 557 279 300 558 279 300 minecraft:snow_block
setblock 557 279 303 minecraft:white_wool
fill 557 279 304 558 279 304 minecraft:snow_block
setblock 557 279 307 minecraft:white_wool
fill 557 279 308 558 279 308 minecraft:snow_block
setblock 557 279 311 minecraft:white_wool
fill 557 279 312 558 279 312 minecraft:snow_block
setblock 557 279 315 minecraft:white_wool
fill 557 279 316 558 279 316 minecraft:snow_block
setblock 558 279 278 minecraft:white_wool
setblock 558 279 279 minecraft:snow_block
setblock 558 279 282 minecraft:white_wool
setblock 558 279 283 minecraft:snow_block
setblock 558 279 286 minecraft:white_wool
setblock 558 279 287 minecraft:snow_block
setblock 558 279 290 minecraft:white_wool
fill 558 279 291 558 279 293 minecraft:snow_block
setblock 558 279 294 minecraft:white_wool
setblock 558 279 295 minecraft:snow_block
setblock 558 279 298 minecraft:white_wool
setblock 558 279 299 minecraft:snow_block
setblock 558 279 302 minecraft:white_wool
setblock 558 279 303 minecraft:snow_block
setblock 558 279 306 minecraft:white_wool
setblock 558 279 307 minecraft:snow_block
setblock 558 279 310 minecraft:white_wool
setblock 558 279 311 minecraft:snow_block
setblock 558 279 314 minecraft:white_wool
setblock 558 279 315 minecraft:snow_block
setblock 559 279 275 minecraft:white_concrete
setblock 559 279 276 minecraft:brown_terracotta
setblock 559 279 277 minecraft:white_concrete
setblock 559 279 278 minecraft:brown_terracotta
setblock 559 279 281 minecraft:white_concrete
setblock 559 279 285 minecraft:white_concrete
setblock 559 279 288 minecraft:brown_terracotta
setblock 559 279 289 minecraft:white_concrete
setblock 559 279 290 minecraft:brown_terracotta
setblock 559 279 293 minecraft:white_concrete
setblock 559 279 297 minecraft:white_concrete
setblock 559 279 300 minecraft:brown_terracotta
setblock 559 279 301 minecraft:white_concrete
setblock 559 279 302 minecraft:brown_terracotta
setblock 559 279 305 minecraft:white_concrete
setblock 559 279 309 minecraft:white_concrete
setblock 559 279 312 minecraft:brown_terracotta
setblock 559 279 313 minecraft:white_concrete
setblock 559 279 314 minecraft:brown_terracotta
setblock 559 279 317 minecraft:white_concrete
setblock 517 280 276 minecraft:white_concrete
fill 517 280 277 517 287 277 minecraft:brown_terracotta
setblock 517 280 278 minecraft:white_concrete
setblock 517 280 280 minecraft:white_concrete
fill 517 280 281 517 285 281 minecraft:brown_terracotta
setblock 517 280 282 minecraft:white_concrete
setblock 517 280 284 minecraft:white_concrete
fill 517 280 285 517 287 285 minecraft:brown_terracotta
setblock 517 280 286 minecraft:white_concrete
setblock 517 280 288 minecraft:white_concrete
fill 517 280 289 517 287 289 minecraft:brown_terracotta
setblock 517 280 290 minecraft:white_concrete
setblock 517 280 292 minecraft:white_concrete
fill 517 280 293 517 285 293 minecraft:brown_terracotta
setblock 517 280 294 minecraft:white_concrete
setblock 517 280 296 minecraft:white_concrete
fill 517 280 297 517 287 297 minecraft:brown_terracotta
setblock 517 280 298 minecraft:white_concrete
setblock 517 280 300 minecraft:white_concrete
fill 517 280 301 517 287 301 minecraft:brown_terracotta
setblock 517 280 302 minecraft:white_concrete
setblock 517 280 304 minecraft:white_concrete
fill 517 280 305 517 285 305 minecraft:brown_terracotta
setblock 517 280 306 minecraft:white_concrete
setblock 517 280 308 minecraft:white_concrete
fill 517 280 309 517 287 309 minecraft:brown_terracotta
setblock 517 280 310 minecraft:white_concrete
setblock 517 280 312 minecraft:white_concrete
fill 517 280 313 517 287 313 minecraft:brown_terracotta
setblock 517 280 314 minecraft:white_concrete
setblock 517 280 316 minecraft:white_concrete
setblock 517 280 317 minecraft:brown_terracotta
setblock 518 280 275 minecraft:white_concrete
setblock 518 280 317 minecraft:white_concrete
fill 519 280 275 519 287 275 minecraft:brown_terracotta
fill 519 280 317 519 285 317 minecraft:brown_terracotta
setblock 520 280 275 minecraft:white_concrete
setblock 520 280 317 minecraft:white_concrete
setblock 522 280 275 minecraft:white_concrete
setblock 522 280 317 minecraft:white_concrete
fill 523 280 275 523 287 275 minecraft:brown_terracotta
fill 523 280 317 523 287 317 minecraft:brown_terracotta
setblock 524 280 275 minecraft:white_concrete
setblock 524 280 317 minecraft:white_concrete
setblock 526 280 275 minecraft:white_concrete
setblock 526 280 317 minecraft:white_concrete
fill 527 280 275 527 285 275 minecraft:brown_terracotta
fill 527 280 317 527 287 317 minecraft:brown_terracotta
setblock 528 280 275 minecraft:white_concrete
setblock 528 280 317 minecraft:white_concrete
setblock 530 280 275 minecraft:white_concrete
setblock 530 280 317 minecraft:white_concrete
fill 531 280 275 531 287 275 minecraft:brown_terracotta
fill 531 280 317 531 285 317 minecraft:brown_terracotta
setblock 532 280 275 minecraft:white_concrete
setblock 532 280 317 minecraft:white_concrete
setblock 534 280 275 minecraft:white_concrete
setblock 534 280 317 minecraft:white_concrete
fill 535 280 275 535 287 275 minecraft:brown_terracotta
fill 535 280 317 535 287 317 minecraft:brown_terracotta
setblock 536 280 275 minecraft:white_concrete
setblock 536 280 317 minecraft:white_concrete
setblock 538 280 275 minecraft:white_concrete
setblock 538 280 317 minecraft:white_concrete
fill 539 280 275 539 285 275 minecraft:brown_terracotta
fill 539 280 317 539 287 317 minecraft:brown_terracotta
setblock 540 280 275 minecraft:white_concrete
setblock 540 280 317 minecraft:white_concrete
setblock 542 280 275 minecraft:white_concrete
setblock 542 280 317 minecraft:white_concrete
fill 543 280 275 543 287 275 minecraft:brown_terracotta
fill 543 280 317 543 285 317 minecraft:brown_terracotta
setblock 544 280 275 minecraft:white_concrete
setblock 544 280 317 minecraft:white_concrete
setblock 546 280 275 minecraft:white_concrete
setblock 546 280 317 minecraft:white_concrete
fill 547 280 275 547 287 275 minecraft:brown_terracotta
fill 547 280 317 547 287 317 minecraft:brown_terracotta
setblock 548 280 275 minecraft:white_concrete
setblock 548 280 317 minecraft:white_concrete
setblock 550 280 275 minecraft:white_concrete
setblock 550 280 317 minecraft:white_concrete
fill 551 280 275 551 285 275 minecraft:brown_terracotta
fill 551 280 317 551 287 317 minecraft:brown_terracotta
setblock 552 280 275 minecraft:white_concrete
setblock 552 280 317 minecraft:white_concrete
setblock 554 280 275 minecraft:white_concrete
setblock 554 280 317 minecraft:white_concrete
fill 555 280 275 555 287 275 minecraft:brown_terracotta
fill 555 280 317 555 285 317 minecraft:brown_terracotta
setblock 556 280 275 minecraft:white_concrete
setblock 556 280 317 minecraft:white_concrete
setblock 558 280 275 minecraft:white_concrete
setblock 558 280 317 minecraft:white_concrete
setblock 559 280 275 minecraft:brown_terracotta
setblock 559 280 276 minecraft:white_concrete
fill 559 280 277 559 285 277 minecraft:brown_terracotta
setblock 559 280 278 minecraft:white_concrete
setblock 559 280 280 minecraft:white_concrete
fill 559 280 281 559 287 281 minecraft:brown_terracotta
setblock 559 280 282 minecraft:white_concrete
setblock 559 280 284 minecraft:white_concrete
fill 559 280 285 559 287 285 minecraft:brown_terracotta
setblock 559 280 286 minecraft:white_concrete
setblock 559 280 288 minecraft:white_concrete
fill 559 280 289 559 285 289 minecraft:brown_terracotta
setblock 559 280 290 minecraft:white_concrete
setblock 559 280 292 minecraft:white_concrete
fill 559 280 293 559 287 293 minecraft:brown_terracotta
setblock 559 280 294 minecraft:white_concrete
setblock 559 280 296 minecraft:white_concrete
fill 559 280 297 559 287 297 minecraft:brown_terracotta
setblock 559 280 298 minecraft:white_concrete
setblock 559 280 300 minecraft:white_concrete
fill 559 280 301 559 285 301 minecraft:brown_terracotta
setblock 559 280 302 minecraft:white_concrete
setblock 559 280 304 minecraft:white_concrete
fill 559 280 305 559 287 305 minecraft:brown_terracotta
setblock 559 280 306 minecraft:white_concrete
setblock 559 280 308 minecraft:white_concrete
fill 559 280 309 559 287 309 minecraft:brown_terracotta
setblock 559 280 310 minecraft:white_concrete
setblock 559 280 312 minecraft:white_concrete
fill 559 280 313 559 285 313 minecraft:brown_terracotta
setblock 559 280 314 minecraft:white_concrete
setblock 559 280 316 minecraft:white_concrete
fill 559 280 317 559 287 317 minecraft:brown_terracotta
setblock 517 281 275 minecraft:white_concrete
fill 517 281 276 517 288 276 minecraft:brown_terracotta
fill 517 281 278 517 288 278 minecraft:brown_terracotta
setblock 517 281 279 minecraft:white_concrete
fill 517 281 280 517 288 280 minecraft:brown_terracotta
fill 517 281 282 517 285 282 minecraft:brown_terracotta
setblock 517 281 283 minecraft:white_concrete
fill 517 281 284 517 285 284 minecraft:brown_terracotta
fill 517 281 286 517 288 286 minecraft:brown_terracotta
setblock 517 281 287 minecraft:white_concrete
fill 517 281 288 517 288 288 minecraft:brown_terracotta
fill 517 281 290 517 288 290 minecraft:brown_terracotta
setblock 517 281 291 minecraft:white_concrete
fill 517 281 292 517 288 292 minecraft:brown_terracotta
fill 517 281 294 517 285 294 minecraft:brown_terracotta
setblock 517 281 295 minecraft:white_concrete
fill 517 281 296 517 285 296 minecraft:brown_terracotta
fill 517 281 298 517 288 298 minecraft:brown_terracotta
setblock 517 281 299 minecraft:white_concrete
fill 517 281 300 517 288 300 minecraft:brown_terracotta
fill 517 281 302 517 288 302 minecraft:brown_terracotta
setblock 517 281 303 minecraft:white_concrete
fill 517 281 304 517 288 304 minecraft:brown_terracotta
fill 517 281 306 517 285 306 minecraft:brown_terracotta
setblock 517 281 307 minecraft:white_concrete
fill 517 281 308 517 285 308 minecraft:brown_terracotta
fill 517 281 310 517 288 310 minecraft:brown_terracotta
setblock 517 281 311 minecraft:white_concrete
fill 517 281 312 517 288 312 minecraft:brown_terracotta
fill 517 281 314 517 288 314 minecraft:brown_terracotta
setblock 517 281 315 minecraft:white_concrete
fill 517 281 316 517 288 316 minecraft:brown_terracotta
setblock 517 281 317 minecraft:white_concrete
fill 518 281 275 518 288 275 minecraft:brown_terracotta
fill 518 281 317 518 285 317 minecraft:brown_terracotta
fill 520 281 275 520 288 275 minecraft:brown_terracotta
fill 520 281 317 520 285 317 minecraft:brown_terracotta
setblock 521 281 275 minecraft:white_concrete
setblock 521 281 317 minecraft:white_concrete
fill 522 281 275 522 288 275 minecraft:brown_terracotta
fill 522 281 317 522 288 317 minecraft:brown_terracotta
fill 524 281 275 524 285 275 minecraft:brown_terracotta
fill 524 281 317 524 288 317 minecraft:brown_terracotta
setblock 525 281 275 minecraft:white_concrete
setblock 525 281 317 minecraft:white_concrete
fill 526 281 275 526 285 275 minecraft:brown_terracotta
fill 526 281 317 526 288 317 minecraft:brown_terracotta
fill 528 281 275 528 288 275 minecraft:brown_terracotta
fill 528 281 317 528 288 317 minecraft:brown_terracotta
setblock 529 281 275 minecraft:white_concrete
setblock 529 281 317 minecraft:white_concrete
fill 530 281 275 530 288 275 minecraft:brown_terracotta
fill 530 281 317 530 285 317 minecraft:brown_terracotta
fill 532 281 275 532 288 275 minecraft:brown_terracotta
fill 532 281 317 532 285 317 minecraft:brown_terracotta
setblock 533 281 275 minecraft:white_concrete
setblock 533 281 317 minecraft:white_concrete
fill 534 281 275 534 288 275 minecraft:brown_terracotta
fill 534 281 317 534 288 317 minecraft:brown_terracotta
fill 536 281 275 536 285 275 minecraft:brown_terracotta
fill 536 281 317 536 288 317 minecraft:brown_terracotta
setblock 537 281 275 minecraft:white_concrete
setblock 537 281 317 minecraft:white_concrete
fill 538 281 275 538 285 275 minecraft:brown_terracotta
fill 538 281 317 538 288 317 minecraft:brown_terracotta
fill 540 281 275 540 288 275 minecraft:brown_terracotta
fill 540 281 317 540 288 317 minecraft:brown_terracotta
setblock 541 281 275 minecraft:white_concrete
setblock 541 281 317 minecraft:white_concrete
fill 542 281 275 542 288 275 minecraft:brown_terracotta
fill 542 281 317 542 285 317 minecraft:brown_terracotta
fill 544 281 275 544 288 275 minecraft:brown_terracotta
fill 544 281 317 544 285 317 minecraft:brown_terracotta
setblock 545 281 275 minecraft:white_concrete
setblock 545 281 317 minecraft:white_concrete
fill 546 281 275 546 288 275 minecraft:brown_terracotta
fill 546 281 317 546 288 317 minecraft:brown_terracotta
fill 548 281 275 548 285 275 minecraft:brown_terracotta
fill 548 281 317 548 288 317 minecraft:brown_terracotta
setblock 549 281 275 minecraft:white_concrete
setblock 549 281 317 minecraft:white_concrete
fill 550 281 275 550 285 275 minecraft:brown_terracotta
fill 550 281 317 550 288 317 minecraft:brown_terracotta
fill 552 281 275 552 288 275 minecraft:brown_terracotta
fill 552 281 317 552 288 317 minecraft:brown_terracotta
setblock 553 281 275 minecraft:white_concrete
setblock 553 281 317 minecraft:white_concrete
fill 554 281 275 554 288 275 minecraft:brown_terracotta
fill 554 281 317 554 285 317 minecraft:brown_terracotta
fill 556 281 275 556 288 275 minecraft:brown_terracotta
fill 556 281 317 556 285 317 minecraft:brown_terracotta
setblock 557 281 275 minecraft:white_concrete
setblock 557 281 317 minecraft:white_concrete
fill 558 281 275 558 288 275 minecraft:brown_terracotta
fill 558 281 317 558 288 317 minecraft:brown_terracotta
setblock 559 281 275 minecraft:white_concrete
fill 559 281 276 559 285 276 minecraft:brown_terracotta
fill 559 281 278 559 285 278 minecraft:brown_terracotta
setblock 559 281 279 minecraft:white_concrete
fill 559 281 280 559 288 280 minecraft:brown_terracotta
fill 559 281 282 559 288 282 minecraft:brown_terracotta
setblock 559 281 283 minecraft:white_concrete
fill 559 281 284 559 288 284 minecraft:brown_terracotta
fill 559 281 286 559 288 286 minecraft:brown_terracotta
setblock 559 281 287 minecraft:white_concrete
fill 559 281 288 559 285 288 minecraft:brown_terracotta
fill 559 281 290 559 285 290 minecraft:brown_terracotta
setblock 559 281 291 minecraft:white_concrete
fill 559 281 292 559 288 292 minecraft:brown_terracotta
fill 559 281 294 559 288 294 minecraft:brown_terracotta
setblock 559 281 295 minecraft:white_concrete
fill 559 281 296 559 288 296 minecraft:brown_terracotta
fill 559 281 298 559 288 298 minecraft:brown_terracotta
setblock 559 281 299 minecraft:white_concrete
fill 559 281 300 559 285 300 minecraft:brown_terracotta
fill 559 281 302 559 285 302 minecraft:brown_terracotta
setblock 559 281 303 minecraft:white_concrete
fill 559 281 304 559 288 304 minecraft:brown_terracotta
fill 559 281 306 559 288 306 minecraft:brown_terracotta
setblock 559 281 307 minecraft:white_concrete
fill 559 281 308 559 288 308 minecraft:brown_terracotta
fill 559 281 310 559 288 310 minecraft:brown_terracotta
setblock 559 281 311 minecraft:white_concrete
fill 559 281 312 559 285 312 minecraft:brown_terracotta
fill 559 281 314 559 285 314 minecraft:brown_terracotta
setblock 559 281 315 minecraft:white_concrete
fill 559 281 316 559 288 316 minecraft:brown_terracotta
fill 517 282 275 517 289 275 minecraft:brown_terracotta
fill 517 282 279 517 289 279 minecraft:brown_terracotta
fill 517 282 283 517 285 283 minecraft:brown_terracotta
fill 517 282 287 517 289 287 minecraft:brown_terracotta
fill 517 282 291 517 289 291 minecraft:brown_terracotta
fill 517 282 295 517 285 295 minecraft:brown_terracotta
fill 517 282 299 517 289 299 minecraft:brown_terracotta
fill 517 282 303 517 289 303 minecraft:brown_terracotta
fill 517 282 307 517 285 307 minecraft:brown_terracotta
fill 517 282 311 517 289 311 minecraft:brown_terracotta
fill 517 282 315 517 289 315 minecraft:brown_terracotta
fill 517 282 317 517 285 317 minecraft:brown_terracotta
fill 521 282 275 521 289 275 minecraft:brown_terracotta
fill 521 282 317 521 289 317 minecraft:brown_terracotta
fill 525 282 275 525 285 275 minecraft:brown_terracotta
fill 525 282 317 525 289 317 minecraft:brown_terracotta
fill 529 282 275 529 289 275 minecraft:brown_terracotta
fill 529 282 317 529 285 317 minecraft:brown_terracotta
fill 533 282 275 533 289 275 minecraft:brown_terracotta
fill 533 282 317 533 289 317 minecraft:brown_terracotta
fill 537 282 275 537 285 275 minecraft:brown_terracotta
fill 537 282 317 537 289 317 minecraft:brown_terracotta
fill 541 282 275 541 289 275 minecraft:brown_terracotta
fill 541 282 317 541 285 317 minecraft:brown_terracotta
fill 545 282 275 545 289 275 minecraft:brown_terracotta
fill 545 282 317 545 289 317 minecraft:brown_terracotta
fill 549 282 275 549 285 275 minecraft:brown_terracotta
fill 549 282 317 549 289 317 minecraft:brown_terracotta
fill 553 282 275 553 289 275 minecraft:brown_terracotta
fill 553 282 317 553 285 317 minecraft:brown_terracotta
fill 557 282 275 557 289 275 minecraft:brown_terracotta
fill 557 282 317 557 289 317 minecraft:brown_terracotta
fill 559 282 275 559 287 275 minecraft:brown_terracotta
fill 559 282 279 559 285 279 minecraft:brown_terracotta
fill 559 282 283 559 289 283 minecraft:brown_terracotta
fill 559 282 287 559 289 287 minecraft:brown_terracotta
fill 559 282 291 559 285 291 minecraft:brown_terracotta
fill 559 282 295 559 289 295 minecraft:brown_terracotta
fill 559 282 299 559 289 299 minecraft:brown_terracotta
fill 559 282 303 559 285 303 minecraft:brown_terracotta
fill 559 282 307 559 289 307 minecraft:brown_terracotta
fill 559 282 311 559 289 311 minecraft:brown_terracotta
fill 559 282 315 559 285 315 minecraft:brown_terracotta
fill 518 283 276 520 300 276 minecraft:white_concrete
fill 518 283 286 518 300 288 minecraft:white_concrete
fill 518 283 290 518 284 300 minecraft:white_concrete
fill 518 283 310 518 300 312 minecraft:white_concrete
fill 519 283 285 519 285 287 minecraft:white_concrete
fill 519 283 290 519 285 299 minecraft:white_concrete
fill 519 283 309 519 285 311 minecraft:white_concrete
setblock 520 283 278 minecraft:light[level=15]
setblock 520 283 286 minecraft:light[level=15]
fill 520 283 290 523 285 298 minecraft:white_concrete
setblock 520 283 302 minecraft:light[level=15]
setblock 520 283 310 minecraft:light[level=15]
fill 524 283 316 526 300 316 minecraft:white_concrete
fill 525 283 315 527 285 315 minecraft:white_concrete
setblock 528 283 278 minecraft:light[level=15]
setblock 528 283 286 minecraft:light[level=15]
setblock 528 283 294 minecraft:light[level=15]
setblock 528 283 302 minecraft:light[level=15]
setblock 528 283 310 minecraft:light[level=15]
fill 529 283 277 531 285 277 minecraft:white_concrete
fill 530 283 276 532 300 276 minecraft:white_concrete
setblock 536 283 278 minecraft:light[level=15]
setblock 536 283 286 minecraft:light[level=15]
setblock 536 283 294 minecraft:light[level=15]
setblock 536 283 302 minecraft:light[level=15]
setblock 536 283 310 minecraft:light[level=15]
fill 536 283 316 538 300 316 minecraft:white_concrete
fill 537 283 315 539 285 315 minecraft:white_concrete
fill 541 283 277 543 285 277 minecraft:white_concrete
fill 542 283 276 544 300 276 minecraft:white_concrete
setblock 544 283 278 minecraft:light[level=15]
setblock 544 283 286 minecraft:light[level=15]
setblock 544 283 294 minecraft:light[level=15]
setblock 544 283 302 minecraft:light[level=15]
setblock 544 283 310 minecraft:light[level=15]
fill 548 283 287 558 284 293 minecraft:white_concrete
fill 548 283 316 550 300 316 minecraft:white_concrete
fill 549 283 315 551 285 315 minecraft:white_concrete
setblock 552 283 278 minecraft:light[level=15]
fill 552 283 280 552 283 281 minecraft:brown_terracotta
setblock 552 283 286 minecraft:light[level=15]
setblock 552 283 294 minecraft:light[level=15]
setblock 552 283 302 minecraft:light[level=15]
setblock 552 283 310 minecraft:light[level=15]
fill 553 283 277 555 285 277 minecraft:white_concrete
setblock 553 283 279 minecraft:brown_terracotta
fill 553 283 280 555 298 281 minecraft:white_concrete
setblock 553 283 282 minecraft:brown_terracotta
fill 554 283 276 556 298 276 minecraft:white_concrete
fill 554 283 278 555 283 278 minecraft:brown_terracotta
fill 554 283 279 555 298 279 minecraft:white_concrete
fill 554 283 282 555 300 282 minecraft:white_concrete
fill 556 283 279 556 283 282 minecraft:brown_terracotta
fill 557 283 285 558 285 286 minecraft:white_concrete
fill 557 283 297 557 285 299 minecraft:white_concrete
fill 557 283 309 557 285 311 minecraft:white_concrete
fill 558 283 284 558 300 284 minecraft:white_concrete
fill 558 283 296 558 300 298 minecraft:white_concrete
fill 558 283 308 558 300 310 minecraft:white_concrete
fill 518 285 279 518 285 284 minecraft:brown_terracotta
setblock 518 285 290 minecraft:white_concrete
fill 518 285 291 518 285 296 minecraft:brown_terracotta
fill 518 285 297 518 285 300 minecraft:white_concrete
fill 518 285 303 518 285 308 minecraft:brown_terracotta
fill 518 285 315 518 285 316 minecraft:brown_terracotta
fill 519 285 316 522 285 316 minecraft:brown_terracotta
setblock 520 285 278 minecraft:light[level=12]
setblock 520 285 285 minecraft:light[level=12]
setblock 520 285 299 minecraft:light[level=12]
setblock 520 285 306 minecraft:light[level=12]
setblock 520 285 313 minecraft:light[level=12]
fill 522 285 276 527 285 276 minecraft:brown_terracotta
setblock 527 285 278 minecraft:light[level=12]
setblock 527 285 285 minecraft:light[level=12]
setblock 527 285 292 minecraft:light[level=12]
setblock 527 285 299 minecraft:light[level=12]
setblock 527 285 306 minecraft:light[level=12]
setblock 527 285 313 minecraft:light[level=12]
fill 529 285 316 534 285 316 minecraft:brown_terracotta
fill 534 285 276 539 285 276 minecraft:brown_terracotta
setblock 534 285 278 minecraft:light[level=12]
setblock 534 285 285 minecraft:light[level=12]
setblock 534 285 292 minecraft:light[level=12]
setblock 534 285 299 minecraft:light[level=12]
setblock 534 285 306 minecraft:light[level=12]
setblock 534 285 313 minecraft:light[level=12]
setblock 541 285 278 minecraft:light[level=12]
setblock 541 285 285 minecraft:light[level=12]
setblock 541 285 292 minecraft:light[level=12]
setblock 541 285 299 minecraft:light[level=12]
setblock 541 285 306 minecraft:light[level=12]
setblock 541 285 313 minecraft:light[level=12]
fill 541 285 316 546 285 316 minecraft:brown_terracotta
fill 546 285 276 551 285 276 minecraft:brown_terracotta
setblock 548 285 278 minecraft:light[level=12]
setblock 548 285 285 minecraft:light[level=12]
fill 548 285 287 557 300 293 minecraft:white_concrete
setblock 548 285 299 minecraft:light[level=12]
setblock 548 285 306 minecraft:light[level=12]
setblock 548 285 313 minecraft:light[level=12]
fill 553 285 316 558 285 316 minecraft:brown_terracotta
setblock 555 285 278 minecraft:light[level=12]
setblock 555 285 285 minecraft:light[level=12]
setblock 555 285 299 minecraft:light[level=12]
setblock 555 285 306 minecraft:light[level=12]
setblock 555 285 313 minecraft:light[level=12]
fill 558 285 276 558 285 281 minecraft:brown_terracotta
fill 558 285 287 558 300 287 minecraft:white_concrete
fill 558 285 288 558 285 293 minecraft:brown_terracotta
fill 558 285 300 558 285 305 minecraft:brown_terracotta
fill 558 285 312 558 285 315 minecraft:brown_terracotta
fill 517 286 281 517 291 284 minecraft:shroomlight
fill 517 286 293 517 291 296 minecraft:shroomlight
fill 517 286 305 517 291 308 minecraft:shroomlight
fill 517 286 317 520 291 317 minecraft:shroomlight
setblock 518 286 290 minecraft:shroomlight
fill 518 286 291 518 300 291 minecraft:white_concrete
setblock 518 286 292 minecraft:shroomlight
fill 518 286 293 518 300 293 minecraft:white_concrete
setblock 518 286 294 minecraft:shroomlight
fill 518 286 295 518 300 295 minecraft:white_concrete
setblock 518 286 296 minecraft:shroomlight
fill 518 286 297 518 300 297 minecraft:white_concrete
setblock 518 286 298 minecraft:shroomlight
fill 518 286 299 518 300 300 minecraft:white_concrete
fill 519 286 290 519 300 290 minecraft:white_concrete
setblock 519 286 291 minecraft:shroomlight
fill 519 286 292 519 300 292 minecraft:white_concrete
setblock 519 286 293 minecraft:shroomlight
fill 519 286 294 519 300 294 minecraft:white_concrete
setblock 519 286 295 minecraft:shroomlight
fill 519 286 296 519 300 296 minecraft:white_concrete
setblock 519 286 297 minecraft:shroomlight
fill 519 286 298 519 300 298 minecraft:white_concrete
setblock 520 286 290 minecraft:shroomlight
fill 520 286 291 520 300 291 minecraft:white_concrete
setblock 520 286 292 minecraft:shroomlight
fill 520 286 293 520 300 293 minecraft:white_concrete
setblock 520 286 294 minecraft:shroomlight
fill 520 286 295 520 300 295 minecraft:white_concrete
setblock 520 286 296 minecraft:shroomlight
fill 520 286 297 520 300 297 minecraft:white_concrete
setblock 520 286 298 minecraft:shroomlight
fill 521 286 290 521 300 290 minecraft:white_concrete
setblock 521 286 291 minecraft:shroomlight
fill 521 286 292 521 300 292 minecraft:white_concrete
setblock 521 286 293 minecraft:shroomlight
fill 521 286 294 521 300 294 minecraft:white_concrete
setblock 521 286 295 minecraft:shroomlight
fill 521 286 296 521 300 296 minecraft:white_concrete
setblock 521 286 297 minecraft:shroomlight
fill 521 286 298 521 300 298 minecraft:white_concrete
setblock 522 286 290 minecraft:shroomlight
fill 522 286 291 522 300 291 minecraft:white_concrete
setblock 522 286 292 minecraft:shroomlight
fill 522 286 293 522 300 293 minecraft:white_concrete
setblock 522 286 294 minecraft:shroomlight
fill 522 286 295 522 300 295 minecraft:white_concrete
setblock 522 286 296 minecraft:shroomlight
fill 522 286 297 522 300 297 minecraft:white_concrete
setblock 522 286 298 minecraft:shroomlight
fill 523 286 290 523 300 290 minecraft:white_concrete
setblock 523 286 291 minecraft:shroomlight
fill 523 286 292 523 300 292 minecraft:white_concrete
setblock 523 286 293 minecraft:shroomlight
fill 523 286 294 523 300 294 minecraft:white_concrete
setblock 523 286 295 minecraft:shroomlight
fill 523 286 296 523 300 296 minecraft:white_concrete
setblock 523 286 297 minecraft:shroomlight
fill 523 286 298 523 300 298 minecraft:white_concrete
fill 524 286 275 527 291 275 minecraft:shroomlight
fill 529 286 317 532 291 317 minecraft:shroomlight
fill 536 286 275 539 291 275 minecraft:shroomlight
fill 541 286 317 544 291 317 minecraft:shroomlight
fill 548 286 275 551 291 275 minecraft:shroomlight
fill 553 286 317 556 291 317 minecraft:shroomlight
fill 558 286 285 558 300 286 minecraft:white_concrete
fill 558 286 288 558 300 293 minecraft:white_concrete
fill 559 286 276 559 291 279 minecraft:shroomlight
fill 559 286 288 559 291 291 minecraft:shroomlight
fill 559 286 300 559 291 303 minecraft:shroomlight
fill 559 286 312 559 291 315 minecraft:shroomlight
fill 518 287 290 518 288 290 minecraft:white_concrete
fill 518 287 292 518 288 292 minecraft:white_concrete
fill 518 287 294 518 288 294 minecraft:white_concrete
fill 518 287 296 518 288 296 minecraft:white_concrete
fill 518 287 298 518 288 298 minecraft:white_concrete
fill 519 287 291 519 288 291 minecraft:white_concrete
fill 519 287 293 519 288 293 minecraft:white_concrete
fill 519 287 295 519 288 295 minecraft:white_concrete
fill 519 287 297 519 288 297 minecraft:white_concrete
fill 520 287 290 520 288 290 minecraft:white_concrete
fill 520 287 292 520 288 292 minecraft:white_concrete
fill 520 287 294 520 288 294 minecraft:white_concrete
fill 520 287 296 520 288 296 minecraft:white_concrete
fill 520 287 298 520 288 298 minecraft:white_concrete
fill 521 287 291 521 288 291 minecraft:white_concrete
fill 521 287 293 521 288 293 minecraft:white_concrete
fill 521 287 295 521 288 295 minecraft:white_concrete
fill 521 287 297 521 288 297 minecraft:white_concrete
fill 522 287 290 522 288 290 minecraft:white_concrete
fill 522 287 292 522 288 292 minecraft:white_concrete
fill 522 287 294 522 288 294 minecraft:white_concrete
fill 522 287 296 522 288 296 minecraft:white_concrete
fill 522 287 298 522 288 298 minecraft:white_concrete
fill 523 287 291 523 288 291 minecraft:white_concrete
fill 523 287 293 523 288 293 minecraft:white_concrete
fill 523 287 295 523 288 295 minecraft:white_concrete
fill 523 287 297 523 288 297 minecraft:white_concrete
setblock 517 288 277 minecraft:white_concrete
setblock 517 288 285 minecraft:white_concrete
setblock 517 288 289 minecraft:white_concrete
setblock 517 288 297 minecraft:white_concrete
setblock 517 288 301 minecraft:white_concrete
setblock 517 288 309 minecraft:white_concrete
setblock 517 288 313 minecraft:white_concrete
setblock 519 288 275 minecraft:white_concrete
setblock 523 288 275 minecraft:white_concrete
setblock 523 288 317 minecraft:white_concrete
setblock 527 288 317 minecraft:white_concrete
setblock 531 288 275 minecraft:white_concrete
setblock 535 288 275 minecraft:white_concrete
setblock 535 288 317 minecraft:white_concrete
setblock 539 288 317 minecraft:white_concrete
setblock 543 288 275 minecraft:white_concrete
setblock 547 288 275 minecraft:white_concrete
setblock 547 288 317 minecraft:white_concrete
setblock 551 288 317 minecraft:white_concrete
setblock 555 288 275 minecraft:white_concrete
setblock 559 288 275 minecraft:white_concrete
setblock 559 288 281 minecraft:white_concrete
setblock 559 288 285 minecraft:white_concrete
setblock 559 288 293 minecraft:white_concrete
setblock 559 288 297 minecraft:white_concrete
setblock 559 288 305 minecraft:white_concrete
setblock 559 288 309 minecraft:white_concrete
setblock 559 288 317 minecraft:white_concrete
setblock 517 289 276 minecraft:white_concrete
fill 517 289 277 517 296 277 minecraft:brown_terracotta
setblock 517 289 278 minecraft:white_concrete
setblock 517 289 280 minecraft:white_concrete
fill 517 289 285 517 296 285 minecraft:brown_terracotta
setblock 517 289 286 minecraft:white_concrete
setblock 517 289 288 minecraft:white_concrete
fill 517 289 289 517 296 289 minecraft:brown_terracotta
setblock 517 289 290 minecraft:white_concrete
setblock 517 289 292 minecraft:white_concrete
fill 517 289 297 517 296 297 minecraft:brown_terracotta
setblock 517 289 298 minecraft:white_concrete
setblock 517 289 300 minecraft:white_concrete
fill 517 289 301 517 296 301 minecraft:brown_terracotta
setblock 517 289 302 minecraft:white_concrete
setblock 517 289 304 minecraft:white_concrete
fill 517 289 309 517 296 309 minecraft:brown_terracotta
setblock 517 289 310 minecraft:white_concrete
setblock 517 289 312 minecraft:white_concrete
fill 517 289 313 517 296 313 minecraft:brown_terracotta
setblock 517 289 314 minecraft:white_concrete
setblock 517 289 316 minecraft:white_concrete
setblock 518 289 275 minecraft:white_concrete
setblock 518 289 290 minecraft:shroomlight
setblock 518 289 292 minecraft:shroomlight
setblock 518 289 294 minecraft:shroomlight
setblock 518 289 296 minecraft:shroomlight
setblock 518 289 298 minecraft:shroomlight
fill 519 289 275 519 296 275 minecraft:brown_terracotta
setblock 519 289 291 minecraft:shroomlight
setblock 519 289 293 minecraft:shroomlight
setblock 519 289 295 minecraft:shroomlight
setblock 519 289 297 minecraft:shroomlight
setblock 520 289 275 minecraft:white_concrete
setblock 520 289 290 minecraft:shroomlight
setblock 520 289 292 minecraft:shroomlight
setblock 520 289 294 minecraft:shroomlight
setblock 520 289 296 minecraft:shroomlight
setblock 520 289 298 minecraft:shroomlight
setblock 521 289 291 minecraft:shroomlight
setblock 521 289 293 minecraft:shroomlight
setblock 521 289 295 minecraft:shroomlight
setblock 521 289 297 minecraft:shroomlight
setblock 522 289 275 minecraft:white_concrete
setblock 522 289 290 minecraft:shroomlight
setblock 522 289 292 minecraft:shroomlight
setblock 522 289 294 minecraft:shroomlight
setblock 522 289 296 minecraft:shroomlight
setblock 522 289 298 minecraft:shroomlight
setblock 522 289 317 minecraft:white_concrete
fill 523 289 275 523 296 275 minecraft:brown_terracotta
setblock 523 289 291 minecraft:shroomlight
setblock 523 289 293 minecraft:shroomlight
setblock 523 289 295 minecraft:shroomlight
setblock 523 289 297 minecraft:shroomlight
fill 523 289 317 523 296 317 minecraft:brown_terracotta
setblock 524 289 317 minecraft:white_concrete
setblock 526 289 317 minecraft:white_concrete
fill 527 289 317 527 296 317 minecraft:brown_terracotta
setblock 528 289 275 minecraft:white_concrete
setblock 528 289 317 minecraft:white_concrete
setblock 530 289 275 minecraft:white_concrete
fill 531 289 275 531 296 275 minecraft:brown_terracotta
setblock 532 289 275 minecraft:white_concrete
setblock 534 289 275 minecraft:white_concrete
setblock 534 289 317 minecraft:white_concrete
fill 535 289 275 535 296 275 minecraft:brown_terracotta
fill 535 289 317 535 296 317 minecraft:brown_terracotta
setblock 536 289 317 minecraft:white_concrete
setblock 538 289 317 minecraft:white_concrete
fill 539 289 317 539 296 317 minecraft:brown_terracotta
setblock 540 289 275 minecraft:white_concrete
setblock 540 289 317 minecraft:white_concrete
setblock 542 289 275 minecraft:white_concrete
fill 543 289 275 543 296 275 minecraft:brown_terracotta
setblock 544 289 275 minecraft:white_concrete
setblock 546 289 275 minecraft:white_concrete
setblock 546 289 317 minecraft:white_concrete
fill 547 289 275 547 296 275 minecraft:brown_terracotta
fill 547 289 317 547 296 317 minecraft:brown_terracotta
setblock 548 289 317 minecraft:white_concrete
setblock 550 289 317 minecraft:white_concrete
fill 551 289 317 551 296 317 minecraft:brown_terracotta
setblock 552 289 275 minecraft:white_concrete
setblock 552 289 317 minecraft:white_concrete
setblock 554 289 275 minecraft:white_concrete
fill 555 289 275 555 296 275 minecraft:brown_terracotta
setblock 556 289 275 minecraft:white_concrete
setblock 558 289 275 minecraft:white_concrete
setblock 558 289 317 minecraft:white_concrete
setblock 559 289 275 minecraft:brown_terracotta
setblock 559 289 280 minecraft:white_concrete
fill 559 289 281 559 296 281 minecraft:brown_terracotta
setblock 559 289 282 minecraft:white_concrete
setblock 559 289 284 minecraft:white_concrete
fill 559 289 285 559 296 285 minecraft:brown_terracotta
setblock 559 289 286 minecraft:white_concrete
setblock 559 289 292 minecraft:white_concrete
fill 559 289 293 559 296 293 minecraft:brown_terracotta
setblock 559 289 294 minecraft:white_concrete
setblock 559 289 296 minecraft:white_concrete
fill 559 289 297 559 296 297 minecraft:brown_terracotta
setblock 559 289 298 minecraft:white_concrete
setblock 559 289 304 minecraft:white_concrete
fill 559 289 305 559 296 305 minecraft:brown_terracotta
setblock 559 289 306 minecraft:white_concrete
setblock 559 289 308 minecraft:white_concrete
fill 559 289 309 559 296 309 minecraft:brown_terracotta
setblock 559 289 310 minecraft:white_concrete
setblock 559 289 316 minecraft:white_concrete
fill 559 289 317 559 296 317 minecraft:brown_terracotta
setblock 517 290 275 minecraft:white_concrete
fill 517 290 276 517 297 276 minecraft:brown_terracotta
fill 517 290 278 517 297 278 minecraft:brown_terracotta
setblock 517 290 279 minecraft:white_concrete
fill 517 290 280 517 297 280 minecraft:brown_terracotta
fill 517 290 286 517 297 286 minecraft:brown_terracotta
setblock 517 290 287 minecraft:white_concrete
fill 517 290 288 517 297 288 minecraft:brown_terracotta
fill 517 290 290 517 297 290 minecraft:brown_terracotta
setblock 517 290 291 minecraft:white_concrete
fill 517 290 292 517 297 292 minecraft:brown_terracotta
fill 517 290 298 517 297 298 minecraft:brown_terracotta
setblock 517 290 299 minecraft:white_concrete
fill 517 290 300 517 297 300 minecraft:brown_terracotta
fill 517 290 302 517 297 302 minecraft:brown_terracotta
setblock 517 290 303 minecraft:white_concrete
fill 517 290 304 517 297 304 minecraft:brown_terracotta
fill 517 290 310 517 297 310 minecraft:brown_terracotta
setblock 517 290 311 minecraft:white_concrete
fill 517 290 312 517 297 312 minecraft:brown_terracotta
fill 517 290 314 517 297 314 minecraft:brown_terracotta
setblock 517 290 315 minecraft:white_concrete
fill 517 290 316 517 297 316 minecraft:brown_terracotta
fill 518 290 275 518 297 275 minecraft:brown_terracotta
fill 518 290 290 518 291 290 minecraft:white_concrete
fill 518 290 292 518 291 292 minecraft:white_concrete
fill 518 290 294 518 291 294 minecraft:white_concrete
fill 518 290 296 518 291 296 minecraft:white_concrete
fill 518 290 298 518 291 298 minecraft:white_concrete
fill 519 290 291 519 291 291 minecraft:white_concrete
fill 519 290 293 519 291 293 minecraft:white_concrete
fill 519 290 295 519 291 295 minecraft:white_concrete
fill 519 290 297 519 291 297 minecraft:white_concrete
fill 520 290 275 520 297 275 minecraft:brown_terracotta
fill 520 290 290 520 291 290 minecraft:white_concrete
fill 520 290 292 520 291 292 minecraft:white_concrete
fill 520 290 294 520 291 294 minecraft:white_concrete
fill 520 290 296 520 291 296 minecraft:white_concrete
fill 520 290 298 520 291 298 minecraft:white_concrete
setblock 521 290 275 minecraft:white_concrete
fill 521 290 291 521 291 291 minecraft:white_concrete
fill 521 290 293 521 291 293 minecraft:white_concrete
fill 521 290 295 521 291 295 minecraft:white_concrete
fill 521 290 297 521 291 297 minecraft:white_concrete
setblock 521 290 317 minecraft:white_concrete
fill 522 290 275 522 297 275 minecraft:brown_terracotta
fill 522 290 290 522 291 290 minecraft:white_concrete
fill 522 290 292 522 291 292 minecraft:white_concrete
fill 522 290 294 522 291 294 minecraft:white_concrete
fill 522 290 296 522 291 296 minecraft:white_concrete
fill 522 290 298 522 291 298 minecraft:white_concrete
fill 522 290 317 522 297 317 minecraft:brown_terracotta
fill 523 290 291 523 291 291 minecraft:white_concrete
fill 523 290 293 523 291 293 minecraft:white_concrete
fill 523 290 295 523 291 295 minecraft:white_concrete
fill 523 290 297 523 291 297 minecraft:white_concrete
fill 524 290 317 524 297 317 minecraft:brown_terracotta
setblock 525 290 317 minecraft:white_concrete
fill 526 290 317 526 297 317 minecraft:brown_terracotta
fill 528 290 275 528 297 275 minecraft:brown_terracotta
fill 528 290 317 528 297 317 minecraft:brown_terracotta
setblock 529 290 275 minecraft:white_concrete
fill 530 290 275 530 297 275 minecraft:brown_terracotta
fill 532 290 275 532 297 275 minecraft:brown_terracotta
setblock 533 290 275 minecraft:white_concrete
setblock 533 290 317 minecraft:white_concrete
fill 534 290 275 534 297 275 minecraft:brown_terracotta
fill 534 290 317 534 297 317 minecraft:brown_terracotta
fill 536 290 317 536 297 317 minecraft:brown_terracotta
setblock 537 290 317 minecraft:white_concrete
fill 538 290 317 538 297 317 minecraft:brown_terracotta
fill 540 290 275 540 297 275 minecraft:brown_terracotta
fill 540 290 317 540 297 317 minecraft:brown_terracotta
setblock 541 290 275 minecraft:white_concrete
fill 542 290 275 542 297 275 minecraft:brown_terracotta
fill 544 290 275 544 297 275 minecraft:brown_terracotta
setblock 545 290 275 minecraft:white_concrete
setblock 545 290 317 minecraft:white_concrete
fill 546 290 275 546 297 275 minecraft:brown_terracotta
fill 546 290 317 546 297 317 minecraft:brown_terracotta
fill 548 290 317 548 297 317 minecraft:brown_terracotta
setblock 549 290 317 minecraft:white_concrete
fill 550 290 286 551 293 286 minecraft:brown_terracotta
fill 550 290 317 550 297 317 minecraft:brown_terracotta
fill 552 290 275 552 297 275 minecraft:brown_terracotta
fill 552 290 317 552 297 317 minecraft:brown_terracotta
setblock 553 290 275 minecraft:white_concrete
fill 554 290 275 554 297 275 minecraft:brown_terracotta
fill 556 290 275 556 297 275 minecraft:brown_terracotta
setblock 557 290 275 minecraft:white_concrete
setblock 557 290 317 minecraft:white_concrete
fill 558 290 275 558 297 275 minecraft:brown_terracotta
fill 558 290 317 558 297 317 minecraft:brown_terracotta
setblock 559 290 275 minecraft:white_concrete
fill 559 290 280 559 297 280 minecraft:brown_terracotta
fill 559 290 282 559 297 282 minecraft:brown_terracotta
setblock 559 290 283 minecraft:white_concrete
fill 559 290 284 559 297 284 minecraft:brown_terracotta
fill 559 290 286 559 297 286 minecraft:brown_terracotta
setblock 559 290 287 minecraft:white_concrete
fill 559 290 292 559 297 292 minecraft:brown_terracotta
fill 559 290 294 559 297 294 minecraft:brown_terracotta
setblock 559 290 295 minecraft:white_concrete
fill 559 290 296 559 297 296 minecraft:brown_terracotta
fill 559 290 298 559 297 298 minecraft:brown_terracotta
setblock 559 290 299 minecraft:white_concrete
fill 559 290 304 559 297 304 minecraft:brown_terracotta
fill 559 290 306 559 297 306 minecraft:brown_terracotta
setblock 559 290 307 minecraft:white_concrete
fill 559 290 308 559 297 308 minecraft:brown_terracotta
fill 559 290 310 559 297 310 minecraft:brown_terracotta
setblock 559 290 311 minecraft:white_concrete
fill 559 290 316 559 297 316 minecraft:brown_terracotta
fill 517 291 275 517 298 275 minecraft:brown_terracotta
fill 517 291 279 517 298 279 minecraft:brown_terracotta
fill 517 291 287 517 298 287 minecraft:brown_terracotta
fill 517 291 291 517 298 291 minecraft:brown_terracotta
fill 517 291 299 517 298 299 minecraft:brown_terracotta
fill 517 291 303 517 298 303 minecraft:brown_terracotta
fill 517 291 311 517 298 311 minecraft:brown_terracotta
fill 517 291 315 517 298 315 minecraft:brown_terracotta
setblock 520 291 278 minecraft:light[level=15]
setblock 520 291 285 minecraft:light[level=12]
setblock 520 291 286 minecraft:light[level=15]
setblock 520 291 299 minecraft:light[level=12]
setblock 520 291 302 minecraft:light[level=15]
setblock 520 291 306 minecraft:light[level=12]
setblock 520 291 310 minecraft:light[level=15]
setblock 520 291 313 minecraft:light[level=12]
fill 521 291 275 521 298 275 minecraft:brown_terracotta
fill 521 291 317 521 298 317 minecraft:brown_terracotta
fill 525 291 317 525 298 317 minecraft:brown_terracotta
setblock 527 291 278 minecraft:light[level=12]
setblock 527 291 285 minecraft:light[level=12]
setblock 527 291 292 minecraft:light[level=12]
setblock 527 291 299 minecraft:light[level=12]
setblock 527 291 306 minecraft:light[level=12]
setblock 527 291 313 minecraft:light[level=12]
setblock 528 291 278 minecraft:light[level=15]
setblock 528 291 286 minecraft:light[level=15]
setblock 528 291 294 minecraft:light[level=15]
setblock 528 291 302 minecraft:light[level=15]
setblock 528 291 310 minecraft:light[level=15]
fill 529 291 275 529 298 275 minecraft:brown_terracotta
fill 533 291 275 533 298 275 minecraft:brown_terracotta
fill 533 291 317 533 298 317 minecraft:brown_terracotta
setblock 534 291 278 minecraft:light[level=12]
setblock 534 291 285 minecraft:light[level=12]
setblock 534 291 292 minecraft:light[level=12]
setblock 534 291 299 minecraft:light[level=12]
setblock 534 291 306 minecraft:light[level=12]
setblock 534 291 313 minecraft:light[level=12]
setblock 536 291 278 minecraft:light[level=15]
setblock 536 291 286 minecraft:light[level=15]
setblock 536 291 294 minecraft:light[level=15]
setblock 536 291 302 minecraft:light[level=15]
setblock 536 291 310 minecraft:light[level=15]
fill 537 291 317 537 298 317 minecraft:brown_terracotta
fill 541 291 275 541 298 275 minecraft:brown_terracotta
setblock 541 291 278 minecraft:light[level=12]
setblock 541 291 285 minecraft:light[level=12]
setblock 541 291 292 minecraft:light[level=12]
setblock 541 291 299 minecraft:light[level=12]
setblock 541 291 306 minecraft:light[level=12]
setblock 541 291 313 minecraft:light[level=12]
setblock 544 291 278 minecraft:light[level=15]
setblock 544 291 286 minecraft:light[level=15]
setblock 544 291 294 minecraft:light[level=15]
setblock 544 291 302 minecraft:light[level=15]
setblock 544 291 310 minecraft:light[level=15]
fill 545 291 275 545 298 275 minecraft:brown_terracotta
fill 545 291 317 545 298 317 minecraft:brown_terracotta
setblock 548 291 278 minecraft:light[level=12]
setblock 548 291 285 minecraft:light[level=12]
setblock 548 291 299 minecraft:light[level=12]
setblock 548 291 306 minecraft:light[level=12]
setblock 548 291 313 minecraft:light[level=12]
fill 549 291 286 549 293 286 minecraft:brown_terracotta
fill 549 291 317 549 298 317 minecraft:brown_terracotta
setblock 552 291 278 minecraft:light[level=15]
fill 552 291 280 552 291 281 minecraft:brown_terracotta
setblock 552 291 286 minecraft:light[level=15]
setblock 552 291 294 minecraft:light[level=15]
setblock 552 291 302 minecraft:light[level=15]
setblock 552 291 310 minecraft:light[level=15]
fill 553 291 275 553 298 275 minecraft:brown_terracotta
setblock 553 291 279 minecraft:brown_terracotta
setblock 553 291 282 minecraft:brown_terracotta
fill 554 291 278 555 291 278 minecraft:brown_terracotta
setblock 555 291 285 minecraft:light[level=12]
setblock 555 291 299 minecraft:light[level=12]
setblock 555 291 306 minecraft:light[level=12]
setblock 555 291 313 minecraft:light[level=12]
fill 556 291 279 556 291 282 minecraft:brown_terracotta
fill 557 291 275 557 298 275 minecraft:brown_terracotta
fill 557 291 317 557 298 317 minecraft:brown_terracotta
fill 559 291 275 559 296 275 minecraft:brown_terracotta
fill 559 291 283 559 298 283 minecraft:brown_terracotta
fill 559 291 287 559 298 287 minecraft:brown_terracotta
fill 559 291 295 559 298 295 minecraft:brown_terracotta
fill 559 291 299 559 298 299 minecraft:brown_terracotta
fill 559 291 307 559 298 307 minecraft:brown_terracotta
fill 559 291 311 559 298 311 minecraft:brown_terracotta
fill 517 292 281 517 296 281 minecraft:brown_terracotta
fill 517 292 282 517 292 283 minecraft:shroomlight
fill 517 292 284 517 297 284 minecraft:brown_terracotta
fill 517 292 293 517 296 293 minecraft:brown_terracotta
fill 517 292 294 517 292 295 minecraft:shroomlight
fill 517 292 296 517 297 296 minecraft:brown_terracotta
fill 517 292 305 517 296 305 minecraft:brown_terracotta
fill 517 292 306 517 292 307 minecraft:shroomlight
fill 517 292 308 517 297 308 minecraft:brown_terracotta
fill 517 292 317 517 296 317 minecraft:brown_terracotta
setblock 518 292 290 minecraft:shroomlight
setblock 518 292 292 minecraft:shroomlight
setblock 518 292 294 minecraft:shroomlight
setblock 518 292 296 minecraft:shroomlight
setblock 518 292 298 minecraft:shroomlight
fill 518 292 317 519 292 317 minecraft:shroomlight
setblock 519 292 291 minecraft:shroomlight
setblock 519 292 293 minecraft:shroomlight
setblock 519 292 295 minecraft:shroomlight
setblock 519 292 297 minecraft:shroomlight
setblock 520 292 290 minecraft:shroomlight
setblock 520 292 292 minecraft:shroomlight
setblock 520 292 294 minecraft:shroomlight
setblock 520 292 296 minecraft:shroomlight
setblock 520 292 298 minecraft:shroomlight
fill 520 292 317 520 297 317 minecraft:brown_terracotta
setblock 521 292 291 minecraft:shroomlight
setblock 521 292 293 minecraft:shroomlight
setblock 521 292 295 minecraft:shroomlight
setblock 521 292 297 minecraft:shroomlight
setblock 522 292 290 minecraft:shroomlight
setblock 522 292 292 minecraft:shroomlight
setblock 522 292 294 minecraft:shroomlight
setblock 522 292 296 minecraft:shroomlight
setblock 522 292 298 minecraft:shroomlight
setblock 523 292 291 minecraft:shroomlight
setblock 523 292 293 minecraft:shroomlight
setblock 523 292 295 minecraft:shroomlight
setblock 523 292 297 minecraft:shroomlight
fill 524 292 275 524 297 275 minecraft:brown_terracotta
fill 525 292 275 526 292 275 minecraft:shroomlight
fill 527 292 275 527 296 275 minecraft:brown_terracotta
fill 529 292 317 529 298 317 minecraft:brown_terracotta
fill 530 292 317 531 292 317 minecraft:shroomlight
fill 532 292 317 532 297 317 minecraft:brown_terracotta
fill 536 292 275 536 297 275 minecraft:brown_terracotta
fill 537 292 275 538 292 275 minecraft:shroomlight
fill 539 292 275 539 296 275 minecraft:brown_terracotta
fill 541 292 317 541 298 317 minecraft:brown_terracotta
fill 542 292 317 543 292 317 minecraft:shroomlight
fill 544 292 317 544 297 317 minecraft:brown_terracotta
fill 547 292 288 547 293 289 minecraft:brown_terracotta
fill 548 292 275 548 297 275 minecraft:brown_terracotta
fill 548 292 286 548 293 286 minecraft:brown_terracotta
fill 549 292 275 550 292 275 minecraft:shroomlight
fill 550 292 285 551 293 285 minecraft:brown_terracotta
fill 551 292 275 551 296 275 minecraft:brown_terracotta
fill 552 292 286 552 293 286 minecraft:brown_terracotta
fill 553 292 317 553 298 317 minecraft:brown_terracotta
fill 554 292 317 555 292 317 minecraft:shroomlight
fill 556 292 317 556 297 317 minecraft:brown_terracotta
fill 559 292 276 559 297 276 minecraft:brown_terracotta
fill 559 292 277 559 292 278 minecraft:shroomlight
fill 559 292 279 559 298 279 minecraft:brown_terracotta
fill 559 292 288 559 297 288 minecraft:brown_terracotta
fill 559 292 289 559 292 290 minecraft:shroomlight
fill 559 292 291 559 298 291 minecraft:brown_terracotta
fill 559 292 300 559 297 300 minecraft:brown_terracotta
fill 559 292 301 559 292 302 minecraft:shroomlight
fill 559 292 303 559 298 303 minecraft:brown_terracotta
fill 559 292 312 559 297 312 minecraft:brown_terracotta
fill 559 292 313 559 292 314 minecraft:shroomlight
fill 559 292 315 559 298 315 minecraft:brown_terracotta
fill 517 293 282 517 297 283 minecraft:brown_terracotta
fill 517 293 294 517 297 295 minecraft:brown_terracotta
fill 517 293 306 517 297 307 minecraft:brown_terracotta
fill 518 293 290 518 294 290 minecraft:white_concrete
fill 518 293 292 518 294 292 minecraft:white_concrete
fill 518 293 294 518 294 294 minecraft:white_concrete
fill 518 293 296 518 294 296 minecraft:white_concrete
fill 518 293 298 518 294 298 minecraft:white_concrete
fill 518 293 317 519 296 317 minecraft:brown_terracotta
fill 519 293 291 519 294 291 minecraft:white_concrete
fill 519 293 293 519 294 293 minecraft:white_concrete
fill 519 293 295 519 294 295 minecraft:white_concrete
fill 519 293 297 519 294 297 minecraft:white_concrete
fill 520 293 290 520 294 290 minecraft:white_concrete
fill 520 293 292 520 294 292 minecraft:white_concrete
fill 520 293 294 520 294 294 minecraft:white_concrete
fill 520 293 296 520 294 296 minecraft:white_concrete
fill 520 293 298 520 294 298 minecraft:white_concrete
fill 521 293 291 521 294 291 minecraft:white_concrete
fill 521 293 293 521 294 293 minecraft:white_concrete
fill 521 293 295 521 294 295 minecraft:white_concrete
fill 521 293 297 521 294 297 minecraft:white_concrete
fill 522 293 290 522 294 290 minecraft:white_concrete
fill 522 293 292 522 294 292 minecraft:white_concrete
fill 522 293 294 522 294 294 minecraft:white_concrete
fill 522 293 296 522 294 296 minecraft:white_concrete
fill 522 293 298 522 294 298 minecraft:white_concrete
fill 523 293 291 523 294 291 minecraft:white_concrete
fill 523 293 293 523 294 293 minecraft:white_concrete
fill 523 293 295 523 294 295 minecraft:white_concrete
fill 523 293 297 523 294 297 minecraft:white_concrete
fill 525 293 275 526 297 275 minecraft:brown_terracotta
fill 530 293 317 531 296 317 minecraft:brown_terracotta
fill 537 293 275 538 297 275 minecraft:brown_terracotta
fill 542 293 287 542 294 287 minecraft:lime_concrete
fill 542 293 317 543 296 317 minecraft:brown_terracotta
setblock 547 293 287 minecraft:brown_terracotta
setblock 547 293 290 minecraft:brown_terracotta
fill 549 293 275 550 297 275 minecraft:brown_terracotta
setblock 549 293 285 minecraft:brown_terracotta
setblock 552 293 285 minecraft:brown_terracotta
setblock 553 293 286 minecraft:brown_terracotta
fill 554 293 317 555 296 317 minecraft:brown_terracotta
fill 559 293 277 559 296 278 minecraft:brown_terracotta
fill 559 293 289 559 296 290 minecraft:brown_terracotta
fill 559 293 301 559 296 302 minecraft:brown_terracotta
fill 559 293 313 559 296 314 minecraft:brown_terracotta
setblock 518 295 290 minecraft:shroomlight
setblock 518 295 292 minecraft:shroomlight
setblock 518 295 294 minecraft:shroomlight
setblock 518 295 296 minecraft:shroomlight
setblock 518 295 298 minecraft:shroomlight
setblock 519 295 291 minecraft:shroomlight
setblock 519 295 293 minecraft:shroomlight
setblock 519 295 295 minecraft:shroomlight
setblock 519 295 297 minecraft:shroomlight
setblock 520 295 290 minecraft:shroomlight
setblock 520 295 292 minecraft:shroomlight
setblock 520 295 294 minecraft:shroomlight
setblock 520 295 296 minecraft:shroomlight
setblock 520 295 298 minecraft:shroomlight
setblock 521 295 291 minecraft:shroomlight
setblock 521 295 293 minecraft:shroomlight
setblock 521 295 295 minecraft:shroomlight
setblock 521 295 297 minecraft:shroomlight
setblock 522 295 290 minecraft:shroomlight
setblock 522 295 292 minecraft:shroomlight
setblock 522 295 294 minecraft:shroomlight
setblock 522 295 296 minecraft:shroomlight
setblock 522 295 298 minecraft:shroomlight
setblock 523 295 291 minecraft:shroomlight
setblock 523 295 293 minecraft:shroomlight
setblock 523 295 295 minecraft:shroomlight
setblock 523 295 297 minecraft:shroomlight
fill 518 296 290 518 297 290 minecraft:white_concrete
fill 518 296 292 518 297 292 minecraft:white_concrete
fill 518 296 294 518 297 294 minecraft:white_concrete
fill 518 296 296 518 297 296 minecraft:white_concrete
fill 518 296 298 518 297 298 minecraft:white_concrete
fill 519 296 291 519 297 291 minecraft:white_concrete
fill 519 296 293 519 297 293 minecraft:white_concrete
fill 519 296 295 519 297 295 minecraft:white_concrete
fill 519 296 297 519 297 297 minecraft:white_concrete
fill 520 296 290 520 297 290 minecraft:white_concrete
fill 520 296 292 520 297 292 minecraft:white_concrete
fill 520 296 294 520 297 294 minecraft:white_concrete
fill 520 296 296 520 297 296 minecraft:white_concrete
fill 520 296 298 520 297 298 minecraft:white_concrete
fill 521 296 291 521 297 291 minecraft:white_concrete
fill 521 296 293 521 297 293 minecraft:white_concrete
fill 521 296 295 521 297 295 minecraft:white_concrete
fill 521 296 297 521 297 297 minecraft:white_concrete
fill 522 296 290 522 297 290 minecraft:white_concrete
fill 522 296 292 522 297 292 minecraft:white_concrete
fill 522 296 294 522 297 294 minecraft:white_concrete
fill 522 296 296 522 297 296 minecraft:white_concrete
fill 522 296 298 522 297 298 minecraft:white_concrete
fill 523 296 291 523 297 291 minecraft:white_concrete
fill 523 296 293 523 297 293 minecraft:white_concrete
fill 523 296 295 523 297 295 minecraft:white_concrete
fill 523 296 297 523 297 297 minecraft:white_concrete
setblock 517 297 277 minecraft:white_concrete
setblock 517 297 281 minecraft:white_concrete
setblock 517 297 285 minecraft:white_concrete
setblock 517 297 289 minecraft:white_concrete
setblock 517 297 293 minecraft:white_concrete
setblock 517 297 297 minecraft:white_concrete
setblock 517 297 301 minecraft:white_concrete
setblock 517 297 305 minecraft:white_concrete
setblock 517 297 309 minecraft:white_concrete
setblock 517 297 313 minecraft:white_concrete
setblock 517 297 317 minecraft:white_concrete
setblock 518 297 317 minecraft:brown_terracotta
setblock 519 297 275 minecraft:white_concrete
setblock 519 297 317 minecraft:white_concrete
setblock 520 297 278 minecraft:light[level=12]
setblock 520 297 285 minecraft:light[level=12]
setblock 520 297 299 minecraft:light[level=12]
setblock 520 297 306 minecraft:light[level=12]
setblock 520 297 313 minecraft:light[level=12]
setblock 523 297 275 minecraft:white_concrete
setblock 523 297 317 minecraft:white_concrete
setblock 527 297 275 minecraft:white_concrete
setblock 527 297 278 minecraft:light[level=12]
setblock 527 297 285 minecraft:light[level=12]
setblock 527 297 292 minecraft:light[level=12]
setblock 527 297 299 minecraft:light[level=12]
setblock 527 297 306 minecraft:light[level=12]
setblock 527 297 313 minecraft:light[level=12]
setblock 527 297 317 minecraft:white_concrete
setblock 530 297 317 minecraft:brown_terracotta
setblock 531 297 275 minecraft:white_concrete
setblock 531 297 317 minecraft:white_concrete
setblock 534 297 278 minecraft:light[level=12]
setblock 534 297 285 minecraft:light[level=12]
setblock 534 297 292 minecraft:light[level=12]
setblock 534 297 299 minecraft:light[level=12]
setblock 534 297 306 minecraft:light[level=12]
setblock 534 297 313 minecraft:light[level=12]
setblock 535 297 275 minecraft:white_concrete
setblock 535 297 317 minecraft:white_concrete
fill 536 297 305 536 298 305 minecraft:white_concrete
setblock 539 297 275 minecraft:white_concrete
setblock 539 297 317 minecraft:white_concrete
setblock 541 297 278 minecraft:light[level=12]
setblock 541 297 285 minecraft:light[level=12]
setblock 541 297 292 minecraft:light[level=12]
setblock 541 297 299 minecraft:light[level=12]
setblock 541 297 306 minecraft:light[level=12]
setblock 541 297 313 minecraft:light[level=12]
setblock 542 297 317 minecraft:brown_terracotta
setblock 543 297 275 minecraft:white_concrete
setblock 543 297 317 minecraft:white_concrete
setblock 547 297 275 minecraft:white_concrete
setblock 547 297 317 minecraft:white_concrete
setblock 548 297 278 minecraft:light[level=12]
setblock 548 297 285 minecraft:light[level=12]
setblock 548 297 299 minecraft:light[level=12]
setblock 548 297 306 minecraft:light[level=12]
setblock 548 297 313 minecraft:light[level=12]
setblock 551 297 275 minecraft:white_concrete
setblock 551 297 317 minecraft:white_concrete
setblock 554 297 317 minecraft:brown_terracotta
setblock 555 297 275 minecraft:white_concrete
setblock 555 297 278 minecraft:light[level=12]
setblock 555 297 285 minecraft:light[level=12]
setblock 555 297 299 minecraft:light[level=12]
setblock 555 297 306 minecraft:light[level=12]
setblock 555 297 313 minecraft:light[level=12]
setblock 555 297 317 minecraft:white_concrete
setblock 559 297 275 minecraft:white_concrete
setblock 559 297 277 minecraft:white_concrete
setblock 559 297 278 minecraft:brown_terracotta
setblock 559 297 281 minecraft:white_concrete
setblock 559 297 285 minecraft:white_concrete
setblock 559 297 289 minecraft:white_concrete
setblock 559 297 290 minecraft:brown_terracotta
setblock 559 297 293 minecraft:white_concrete
setblock 559 297 297 minecraft:white_concrete
setblock 559 297 301 minecraft:white_concrete
setblock 559 297 302 minecraft:brown_terracotta
setblock 559 297 305 minecraft:white_concrete
setblock 559 297 309 minecraft:white_concrete
setblock 559 297 313 minecraft:white_concrete
setblock 559 297 314 minecraft:brown_terracotta
setblock 559 297 317 minecraft:white_concrete
setblock 517 298 276 minecraft:white_concrete
fill 517 298 277 517 305 277 minecraft:brown_terracotta
setblock 517 298 278 minecraft:white_concrete
setblock 517 298 280 minecraft:white_concrete
fill 517 298 281 517 305 281 minecraft:brown_terracotta
setblock 517 298 282 minecraft:white_concrete
setblock 517 298 283 minecraft:brown_terracotta
setblock 517 298 284 minecraft:white_concrete
fill 517 298 285 517 305 285 minecraft:brown_terracotta
setblock 517 298 286 minecraft:white_concrete
setblock 517 298 288 minecraft:white_concrete
fill 517 298 289 517 305 289 minecraft:brown_terracotta
setblock 517 298 290 minecraft:white_concrete
setblock 517 298 292 minecraft:white_concrete
fill 517 298 293 517 305 293 minecraft:brown_terracotta
setblock 517 298 294 minecraft:white_concrete
setblock 517 298 295 minecraft:brown_terracotta
setblock 517 298 296 minecraft:white_concrete
fill 517 298 297 517 305 297 minecraft:brown_terracotta
setblock 517 298 298 minecraft:white_concrete
setblock 517 298 300 minecraft:white_concrete
fill 517 298 301 517 305 301 minecraft:brown_terracotta
setblock 517 298 302 minecraft:white_concrete
setblock 517 298 304 minecraft:white_concrete
fill 517 298 305 517 305 305 minecraft:brown_terracotta
setblock 517 298 306 minecraft:white_concrete
setblock 517 298 307 minecraft:brown_terracotta
setblock 517 298 308 minecraft:white_concrete
fill 517 298 309 517 305 309 minecraft:brown_terracotta
setblock 517 298 310 minecraft:white_concrete
setblock 517 298 312 minecraft:white_concrete
fill 517 298 313 517 305 313 minecraft:brown_terracotta
setblock 517 298 314 minecraft:white_concrete
setblock 517 298 316 minecraft:white_concrete
setblock 517 298 317 minecraft:brown_terracotta
setblock 518 298 275 minecraft:white_concrete
setblock 518 298 290 minecraft:shroomlight
setblock 518 298 292 minecraft:shroomlight
setblock 518 298 294 minecraft:shroomlight
setblock 518 298 296 minecraft:shroomlight
setblock 518 298 298 minecraft:shroomlight
setblock 518 298 317 minecraft:white_concrete
fill 519 298 275 519 305 275 minecraft:brown_terracotta
setblock 519 298 291 minecraft:shroomlight
setblock 519 298 293 minecraft:shroomlight
setblock 519 298 295 minecraft:shroomlight
setblock 519 298 297 minecraft:shroomlight
fill 519 298 317 519 305 317 minecraft:brown_terracotta
setblock 520 298 275 minecraft:white_concrete
setblock 520 298 290 minecraft:shroomlight
setblock 520 298 292 minecraft:shroomlight
setblock 520 298 294 minecraft:shroomlight
setblock 520 298 296 minecraft:shroomlight
setblock 520 298 298 minecraft:shroomlight
setblock 520 298 317 minecraft:white_concrete
setblock 521 298 291 minecraft:shroomlight
setblock 521 298 293 minecraft:shroomlight
setblock 521 298 295 minecraft:shroomlight
setblock 521 298 297 minecraft:shroomlight
setblock 522 298 275 minecraft:white_concrete
setblock 522 298 290 minecraft:shroomlight
setblock 522 298 292 minecraft:shroomlight
setblock 522 298 294 minecraft:shroomlight
setblock 522 298 296 minecraft:shroomlight
setblock 522 298 298 minecraft:shroomlight
setblock 522 298 317 minecraft:white_concrete
fill 523 298 275 523 305 275 minecraft:brown_terracotta
setblock 523 298 291 minecraft:shroomlight
setblock 523 298 293 minecraft:shroomlight
setblock 523 298 295 minecraft:shroomlight
setblock 523 298 297 minecraft:shroomlight
fill 523 298 317 523 305 317 minecraft:brown_terracotta
setblock 524 298 275 minecraft:white_concrete
setblock 524 298 317 minecraft:white_concrete
setblock 525 298 275 minecraft:brown_terracotta
setblock 526 298 275 minecraft:white_concrete
setblock 526 298 317 minecraft:white_concrete
fill 527 298 275 527 305 275 minecraft:brown_terracotta
fill 527 298 317 527 305 317 minecraft:brown_terracotta
setblock 528 298 275 minecraft:white_concrete
setblock 528 298 317 minecraft:white_concrete
setblock 530 298 275 minecraft:white_concrete
setblock 530 298 317 minecraft:white_concrete
fill 531 298 275 531 305 275 minecraft:brown_terracotta
fill 531 298 317 531 305 317 minecraft:brown_terracotta
setblock 532 298 275 minecraft:white_concrete
setblock 532 298 317 minecraft:white_concrete
setblock 534 298 275 minecraft:white_concrete
setblock 534 298 317 minecraft:white_concrete
fill 535 298 275 535 305 275 minecraft:brown_terracotta
fill 535 298 317 535 305 317 minecraft:brown_terracotta
setblock 536 298 275 minecraft:white_concrete
setblock 536 298 317 minecraft:white_concrete
setblock 537 298 275 minecraft:brown_terracotta
setblock 538 298 275 minecraft:white_concrete
setblock 538 298 317 minecraft:white_concrete
fill 539 298 275 539 305 275 minecraft:brown_terracotta
fill 539 298 317 539 305 317 minecraft:brown_terracotta
setblock 540 298 275 minecraft:white_concrete
setblock 540 298 317 minecraft:white_concrete
setblock 542 298 275 minecraft:white_concrete
setblock 542 298 317 minecraft:white_concrete
fill 543 298 275 543 305 275 minecraft:brown_terracotta
fill 543 298 317 543 305 317 minecraft:brown_terracotta
setblock 544 298 275 minecraft:white_concrete
setblock 544 298 317 minecraft:white_concrete
setblock 546 298 275 minecraft:white_concrete
setblock 546 298 317 minecraft:white_concrete
fill 547 298 275 547 305 275 minecraft:brown_terracotta
fill 547 298 317 547 305 317 minecraft:brown_terracotta
setblock 548 298 275 minecraft:white_concrete
setblock 548 298 317 minecraft:white_concrete
setblock 549 298 275 minecraft:brown_terracotta
setblock 550 298 275 minecraft:white_concrete
fill 550 298 286 551 298 286 minecraft:spruce_leaves[persistent=true]
setblock 550 298 317 minecraft:white_concrete
fill 551 298 275 551 305 275 minecraft:brown_terracotta
fill 551 298 317 551 305 317 minecraft:brown_terracotta
setblock 552 298 275 minecraft:white_concrete
setblock 552 298 317 minecraft:white_concrete
setblock 554 298 275 minecraft:white_concrete
setblock 554 298 317 minecraft:white_concrete
fill 555 298 275 555 305 275 minecraft:brown_terracotta
fill 555 298 317 555 305 317 minecraft:brown_terracotta
setblock 556 298 275 minecraft:white_concrete
setblock 556 298 317 minecraft:white_concrete
setblock 558 298 275 minecraft:white_concrete
setblock 558 298 317 minecraft:white_concrete
setblock 559 298 275 minecraft:brown_terracotta
setblock 559 298 276 minecraft:white_concrete
fill 559 298 277 559 305 277 minecraft:brown_terracotta
setblock 559 298 278 minecraft:white_concrete
setblock 559 298 280 minecraft:white_concrete
fill 559 298 281 559 305 281 minecraft:brown_terracotta
setblock 559 298 282 minecraft:white_concrete
setblock 559 298 284 minecraft:white_concrete
fill 559 298 285 559 305 285 minecraft:brown_terracotta
setblock 559 298 286 minecraft:white_concrete
setblock 559 298 288 minecraft:white_concrete
fill 559 298 289 559 305 289 minecraft:brown_terracotta
setblock 559 298 290 minecraft:white_concrete
setblock 559 298 292 minecraft:white_concrete
fill 559 298 293 559 305 293 minecraft:brown_terracotta
setblock 559 298 294 minecraft:white_concrete
setblock 559 298 296 minecraft:white_concrete
fill 559 298 297 559 305 297 minecraft:brown_terracotta
setblock 559 298 298 minecraft:white_concrete
setblock 559 298 300 minecraft:white_concrete
fill 559 298 301 559 305 301 minecraft:brown_terracotta
setblock 559 298 302 minecraft:white_concrete
setblock 559 298 304 minecraft:white_concrete
fill 559 298 305 559 305 305 minecraft:brown_terracotta
setblock 559 298 306 minecraft:white_concrete
setblock 559 298 308 minecraft:white_concrete
fill 559 298 309 559 305 309 minecraft:brown_terracotta
setblock 559 298 310 minecraft:white_concrete
setblock 559 298 312 minecraft:white_concrete
fill 559 298 313 559 305 313 minecraft:brown_terracotta
setblock 559 298 314 minecraft:white_concrete
setblock 559 298 316 minecraft:white_concrete
fill 559 298 317 559 305 317 minecraft:brown_terracotta
setblock 517 299 275 minecraft:white_concrete
fill 517 299 276 517 306 276 minecraft:brown_terracotta
fill 517 299 278 517 306 278 minecraft:brown_terracotta
setblock 517 299 279 minecraft:white_concrete
fill 517 299 280 517 306 280 minecraft:brown_terracotta
fill 517 299 282 517 306 282 minecraft:brown_terracotta
setblock 517 299 283 minecraft:white_concrete
fill 517 299 284 517 306 284 minecraft:brown_terracotta
fill 517 299 286 517 306 286 minecraft:brown_terracotta
setblock 517 299 287 minecraft:white_concrete
fill 517 299 288 517 306 288 minecraft:brown_terracotta
fill 517 299 290 517 306 290 minecraft:brown_terracotta
setblock 517 299 291 minecraft:white_concrete
fill 517 299 292 517 306 292 minecraft:brown_terracotta
fill 517 299 294 517 306 294 minecraft:brown_terracotta
setblock 517 299 295 minecraft:white_concrete
fill 517 299 296 517 306 296 minecraft:brown_terracotta
fill 517 299 298 517 306 298 minecraft:brown_terracotta
setblock 517 299 299 minecraft:white_concrete
fill 517 299 300 517 306 300 minecraft:brown_terracotta
fill 517 299 302 517 306 302 minecraft:brown_terracotta
setblock 517 299 303 minecraft:white_concrete
fill 517 299 304 517 306 304 minecraft:brown_terracotta
fill 517 299 306 517 306 306 minecraft:brown_terracotta
setblock 517 299 307 minecraft:white_concrete
fill 517 299 308 517 306 308 minecraft:brown_terracotta
fill 517 299 310 517 306 310 minecraft:brown_terracotta
setblock 517 299 311 minecraft:white_concrete
fill 517 299 312 517 306 312 minecraft:brown_terracotta
fill 517 299 314 517 306 314 minecraft:brown_terracotta
setblock 517 299 315 minecraft:white_concrete
fill 517 299 316 517 306 316 minecraft:brown_terracotta
setblock 517 299 317 minecraft:white_concrete
fill 518 299 275 518 306 275 minecraft:brown_terracotta
fill 518 299 290 518 300 290 minecraft:white_concrete
fill 518 299 292 518 300 292 minecraft:white_concrete
fill 518 299 294 518 300 294 minecraft:white_concrete
fill 518 299 296 518 300 296 minecraft:white_concrete
fill 518 299 298 518 300 298 minecraft:white_concrete
fill 518 299 317 518 306 317 minecraft:brown_terracotta
fill 519 299 291 519 300 291 minecraft:white_concrete
fill 519 299 293 519 300 293 minecraft:white_concrete
fill 519 299 295 519 300 295 minecraft:white_concrete
fill 519 299 297 519 300 297 minecraft:white_concrete
fill 520 299 275 520 306 275 minecraft:brown_terracotta
setblock 520 299 278 minecraft:light[level=15]
setblock 520 299 286 minecraft:light[level=15]
fill 520 299 290 520 300 290 minecraft:white_concrete
fill 520 299 292 520 300 292 minecraft:white_concrete
fill 520 299 294 520 300 294 minecraft:white_concrete
fill 520 299 296 520 300 296 minecraft:white_concrete
fill 520 299 298 520 300 298 minecraft:white_concrete
setblock 520 299 302 minecraft:light[level=15]
setblock 520 299 310 minecraft:light[level=15]
fill 520 299 317 520 306 317 minecraft:brown_terracotta
setblock 521 299 275 minecraft:white_concrete
fill 521 299 291 521 300 291 minecraft:white_concrete
fill 521 299 293 521 300 293 minecraft:white_concrete
fill 521 299 295 521 300 295 minecraft:white_concrete
fill 521 299 297 521 300 297 minecraft:white_concrete
setblock 521 299 317 minecraft:white_concrete
fill 522 299 275 522 306 275 minecraft:brown_terracotta
fill 522 299 290 522 300 290 minecraft:white_concrete
fill 522 299 292 522 300 292 minecraft:white_concrete
fill 522 299 294 522 300 294 minecraft:white_concrete
fill 522 299 296 522 300 296 minecraft:white_concrete
fill 522 299 298 522 300 298 minecraft:white_concrete
fill 522 299 317 522 306 317 minecraft:brown_terracotta
fill 523 299 291 523 300 291 minecraft:white_concrete
fill 523 299 293 523 300 293 minecraft:white_concrete
fill 523 299 295 523 300 295 minecraft:white_concrete
fill 523 299 297 523 300 297 minecraft:white_concrete
fill 524 299 275 524 306 275 minecraft:brown_terracotta
fill 524 299 317 524 306 317 minecraft:brown_terracotta
setblock 525 299 275 minecraft:white_concrete
setblock 525 299 317 minecraft:white_concrete
fill 526 299 275 526 306 275 minecraft:brown_terracotta
fill 526 299 317 526 306 317 minecraft:brown_terracotta
fill 528 299 275 528 306 275 minecraft:brown_terracotta
setblock 528 299 278 minecraft:light[level=15]
setblock 528 299 286 minecraft:light[level=15]
setblock 528 299 294 minecraft:light[level=15]
setblock 528 299 302 minecraft:light[level=15]
setblock 528 299 310 minecraft:light[level=15]
fill 528 299 317 528 306 317 minecraft:brown_terracotta
setblock 529 299 275 minecraft:white_concrete
setblock 529 299 317 minecraft:white_concrete
fill 530 299 275 530 306 275 minecraft:brown_terracotta
fill 530 299 317 530 306 317 minecraft:brown_terracotta
fill 532 299 275 532 306 275 minecraft:brown_terracotta
fill 532 299 317 532 306 317 minecraft:brown_terracotta
setblock 533 299 275 minecraft:white_concrete
setblock 533 299 317 minecraft:white_concrete
fill 534 299 275 534 306 275 minecraft:brown_terracotta
fill 534 299 279 536 300 279 minecraft:red_concrete
fill 534 299 317 534 306 317 minecraft:brown_terracotta
fill 535 299 278 535 300 278 minecraft:red_concrete
fill 535 299 280 535 300 280 minecraft:red_concrete
fill 536 299 275 536 306 275 minecraft:brown_terracotta
setblock 536 299 278 minecraft:light[level=15]
setblock 536 299 286 minecraft:light[level=15]
setblock 536 299 294 minecraft:light[level=15]
setblock 536 299 302 minecraft:light[level=15]
setblock 536 299 310 minecraft:light[level=15]
fill 536 299 317 536 306 317 minecraft:brown_terracotta
setblock 537 299 275 minecraft:white_concrete
setblock 537 299 317 minecraft:white_concrete
fill 538 299 275 538 306 275 minecraft:brown_terracotta
fill 538 299 317 538 306 317 minecraft:brown_terracotta
fill 540 299 275 540 306 275 minecraft:brown_terracotta
fill 540 299 317 540 306 317 minecraft:brown_terracotta
setblock 541 299 275 minecraft:white_concrete
setblock 541 299 317 minecraft:white_concrete
schedule function dropper:buildpart/71_7 1t
