fill 118 223 557 123 232 557 minecraft:black_concrete
setblock 124 223 557 minecraft:blue_concrete
fill 125 223 557 125 289 557 minecraft:black_concrete
fill 127 223 599 127 289 599 minecraft:black_concrete
fill 130 223 557 133 229 557 minecraft:black_concrete
fill 130 223 599 130 307 599 minecraft:black_concrete
setblock 131 223 599 minecraft:blue_concrete
fill 132 223 599 134 227 599 minecraft:black_concrete
setblock 134 223 557 minecraft:blue_concrete
fill 135 223 557 135 254 557 minecraft:black_concrete
fill 136 223 561 136 228 563 minecraft:black_concrete
setblock 136 223 564 minecraft:blue_concrete
fill 136 223 566 136 233 567 minecraft:black_concrete
fill 136 223 570 136 239 570 minecraft:black_concrete
fill 136 223 576 136 264 577 minecraft:black_concrete
setblock 136 223 578 minecraft:blue_concrete
fill 136 223 579 136 265 581 minecraft:black_concrete
setblock 136 223 582 minecraft:blue_concrete
fill 136 223 583 136 227 594 minecraft:black_concrete
setblock 136 223 595 minecraft:blue_concrete
fill 136 223 596 136 223 597 minecraft:black_concrete
fill 136 223 599 136 307 599 minecraft:black_concrete
fill 94 224 557 94 307 557 minecraft:black_concrete
fill 94 224 564 94 267 564 minecraft:black_concrete
fill 94 224 578 94 307 578 minecraft:black_concrete
fill 94 224 583 94 307 583 minecraft:black_concrete
fill 94 224 596 94 307 596 minecraft:black_concrete
setblock 97 224 560 minecraft:light[level=14]
setblock 97 224 568 minecraft:light[level=14]
setblock 97 224 576 minecraft:light[level=14]
setblock 97 224 584 minecraft:light[level=14]
setblock 97 224 592 minecraft:light[level=14]
fill 102 224 599 102 275 599 minecraft:black_concrete
setblock 105 224 560 minecraft:light[level=14]
setblock 105 224 568 minecraft:light[level=14]
setblock 105 224 576 minecraft:light[level=14]
setblock 105 224 584 minecraft:light[level=14]
setblock 105 224 592 minecraft:light[level=14]
fill 112 224 599 112 238 599 minecraft:black_concrete
setblock 113 224 560 minecraft:light[level=14]
setblock 113 224 568 minecraft:light[level=14]
setblock 113 224 576 minecraft:light[level=14]
setblock 113 224 584 minecraft:light[level=14]
setblock 113 224 592 minecraft:light[level=14]
setblock 121 224 560 minecraft:light[level=14]
setblock 121 224 568 minecraft:light[level=14]
setblock 121 224 576 minecraft:light[level=14]
setblock 121 224 584 minecraft:light[level=14]
setblock 121 224 592 minecraft:light[level=14]
fill 124 224 557 124 252 557 minecraft:black_concrete
setblock 129 224 560 minecraft:light[level=14]
setblock 129 224 568 minecraft:light[level=14]
setblock 129 224 576 minecraft:light[level=14]
setblock 129 224 584 minecraft:light[level=14]
setblock 129 224 592 minecraft:light[level=14]
fill 131 224 599 131 253 599 minecraft:black_concrete
fill 134 224 557 134 225 557 minecraft:black_concrete
fill 136 224 564 136 229 564 minecraft:black_concrete
fill 136 224 578 136 250 578 minecraft:black_concrete
fill 136 224 582 136 256 582 minecraft:black_concrete
fill 136 224 595 136 242 596 minecraft:black_concrete
setblock 136 224 597 minecraft:pearlescent_froglight
setblock 94 225 597 minecraft:pearlescent_froglight
fill 94 225 598 94 240 599 minecraft:black_concrete
fill 136 225 597 136 307 597 minecraft:black_concrete
fill 94 226 597 94 233 597 minecraft:black_concrete
fill 95 226 557 97 235 557 minecraft:black_concrete
setblock 98 226 557 minecraft:white_concrete
fill 99 226 557 107 231 557 minecraft:black_concrete
fill 103 226 599 103 307 599 minecraft:black_concrete
setblock 104 226 599 minecraft:pearlescent_froglight
fill 105 226 599 106 274 599 minecraft:black_concrete
setblock 134 226 557 minecraft:white_concrete
setblock 94 227 579 minecraft:white_concrete
fill 94 227 580 94 231 582 minecraft:black_concrete
fill 98 227 557 98 233 557 minecraft:black_concrete
fill 104 227 599 104 288 599 minecraft:black_concrete
fill 134 227 557 134 228 557 minecraft:black_concrete
fill 94 228 579 94 282 579 minecraft:black_concrete
fill 95 228 599 95 297 599 minecraft:black_concrete
setblock 96 228 599 minecraft:white_stained_glass
fill 97 228 599 101 236 599 minecraft:black_concrete
fill 111 228 575 113 228 577 minecraft:redstone_block
fill 116 228 570 118 228 572 minecraft:redstone_block
fill 117 228 580 119 228 582 minecraft:redstone_block
fill 121 228 575 123 228 577 minecraft:redstone_block
setblock 132 228 599 minecraft:white_stained_glass
fill 133 228 599 134 265 599 minecraft:black_concrete
fill 136 228 583 136 233 583 minecraft:black_concrete
setblock 136 228 584 minecraft:white_stained_glass
fill 136 228 585 136 242 594 minecraft:black_concrete
setblock 94 229 566 minecraft:white_stained_glass
fill 94 229 567 94 307 567 minecraft:black_concrete
setblock 94 229 575 minecraft:white_concrete
fill 94 229 576 94 251 577 minecraft:black_concrete
setblock 94 229 591 minecraft:pearlescent_froglight
fill 95 229 558 96 230 562 minecraft:end_stone
fill 95 229 563 95 230 563 minecraft:black_concrete
fill 95 229 564 97 230 567 minecraft:end_stone
fill 95 229 568 95 230 568 minecraft:black_concrete
fill 95 229 569 95 230 588 minecraft:end_stone
fill 95 229 589 95 230 589 minecraft:black_concrete
fill 95 229 590 95 230 598 minecraft:end_stone
fill 96 229 563 101 230 563 minecraft:end_stone
fill 96 229 568 101 230 568 minecraft:end_stone
fill 96 229 569 96 230 569 minecraft:black_concrete
fill 96 229 570 98 230 573 minecraft:end_stone
fill 96 229 574 96 230 574 minecraft:black_concrete
fill 96 229 575 96 230 594 minecraft:end_stone
fill 96 229 595 96 230 595 minecraft:black_concrete
fill 96 229 596 99 230 598 minecraft:end_stone
fill 96 229 599 96 295 599 minecraft:black_concrete
fill 97 229 558 135 230 558 minecraft:end_stone
fill 97 229 559 97 230 559 minecraft:black_concrete
fill 97 229 560 97 230 562 minecraft:end_stone
fill 97 229 569 102 230 569 minecraft:end_stone
fill 97 229 574 99 230 579 minecraft:end_stone
fill 97 229 580 97 230 580 minecraft:black_concrete
fill 97 229 581 97 230 595 minecraft:end_stone
fill 98 229 559 103 230 559 minecraft:end_stone
fill 98 229 560 98 230 560 minecraft:black_concrete
fill 98 229 561 100 230 562 minecraft:end_stone
fill 98 229 564 135 230 564 minecraft:end_stone
fill 98 229 565 98 230 565 minecraft:black_concrete
fill 98 229 566 98 230 567 minecraft:end_stone
fill 98 229 580 100 230 585 minecraft:end_stone
fill 98 229 586 98 230 586 minecraft:black_concrete
fill 98 229 587 98 230 595 minecraft:end_stone
fill 99 229 560 104 230 560 minecraft:end_stone
fill 99 229 565 104 230 565 minecraft:end_stone
fill 99 229 566 99 230 566 minecraft:black_concrete
fill 99 229 567 135 230 567 minecraft:end_stone
fill 99 229 570 115 229 570 minecraft:end_stone
fill 99 229 571 99 230 571 minecraft:black_concrete
fill 99 229 572 99 230 573 minecraft:end_stone
fill 99 229 586 101 230 591 minecraft:end_stone
fill 99 229 592 99 230 592 minecraft:black_concrete
fill 99 229 593 102 230 595 minecraft:end_stone
fill 100 229 566 105 230 566 minecraft:end_stone
fill 100 229 571 105 230 571 minecraft:end_stone
fill 100 229 572 100 230 572 minecraft:black_concrete
fill 100 229 573 102 230 576 minecraft:end_stone
fill 100 229 577 100 230 577 minecraft:black_concrete
fill 100 229 578 107 230 579 minecraft:end_stone
fill 100 229 592 105 230 592 minecraft:end_stone
fill 100 229 596 131 230 597 minecraft:end_stone
fill 100 229 598 100 230 598 minecraft:black_concrete
fill 101 229 561 135 230 561 minecraft:end_stone
fill 101 229 562 101 230 562 minecraft:black_concrete
fill 101 229 572 106 230 572 minecraft:end_stone
fill 101 229 577 106 230 577 minecraft:end_stone
fill 101 229 580 103 230 582 minecraft:end_stone
fill 101 229 583 101 230 583 minecraft:black_concrete
fill 101 229 584 115 230 585 minecraft:end_stone
fill 101 229 598 106 230 598 minecraft:end_stone
fill 102 229 562 107 230 562 minecraft:end_stone
fill 102 229 563 102 230 563 minecraft:black_concrete
fill 102 229 568 102 230 568 minecraft:black_concrete
fill 102 229 583 107 230 583 minecraft:end_stone
fill 102 229 586 104 230 588 minecraft:end_stone
fill 102 229 589 102 230 589 minecraft:black_concrete
fill 102 229 590 123 230 591 minecraft:end_stone
fill 103 229 563 108 230 563 minecraft:end_stone
fill 103 229 568 108 230 568 minecraft:end_stone
fill 103 229 569 103 230 569 minecraft:black_concrete
fill 103 229 573 135 229 573 minecraft:end_stone
fill 103 229 574 103 230 574 minecraft:black_concrete
fill 103 229 575 103 230 576 minecraft:end_stone
fill 103 229 589 108 230 589 minecraft:end_stone
fill 103 229 593 127 230 594 minecraft:end_stone
fill 103 229 595 103 230 595 minecraft:black_concrete
fill 104 229 559 104 230 559 minecraft:black_concrete
fill 104 229 569 109 230 569 minecraft:end_stone
fill 104 229 574 109 230 574 minecraft:end_stone
fill 104 229 575 104 230 575 minecraft:black_concrete
fill 104 229 576 110 229 576 minecraft:end_stone
fill 104 229 580 104 230 580 minecraft:black_concrete
fill 104 229 581 111 230 582 minecraft:end_stone
fill 104 229 595 109 230 595 minecraft:end_stone
fill 105 229 559 110 230 559 minecraft:end_stone
fill 105 229 560 105 230 560 minecraft:black_concrete
fill 105 229 565 105 230 565 minecraft:black_concrete
fill 105 229 575 110 229 575 minecraft:end_stone
fill 105 229 580 110 230 580 minecraft:end_stone
fill 105 229 586 105 230 586 minecraft:black_concrete
fill 105 229 587 119 230 588 minecraft:end_stone
fill 106 229 560 111 230 560 minecraft:end_stone
fill 106 229 565 111 230 565 minecraft:end_stone
fill 106 229 566 106 230 566 minecraft:black_concrete
fill 106 229 571 106 230 571 minecraft:black_concrete
fill 106 229 586 111 230 586 minecraft:end_stone
fill 106 229 592 106 230 592 minecraft:black_concrete
fill 107 229 566 112 230 566 minecraft:end_stone
fill 107 229 571 112 230 571 minecraft:end_stone
fill 107 229 572 107 230 572 minecraft:black_concrete
fill 107 229 577 107 230 577 minecraft:black_concrete
fill 107 229 592 112 230 592 minecraft:end_stone
fill 107 229 598 107 230 598 minecraft:black_concrete
fill 108 229 562 108 230 562 minecraft:black_concrete
fill 108 229 572 113 230 572 minecraft:end_stone
fill 108 229 577 110 229 577 minecraft:end_stone
fill 108 229 578 108 230 578 minecraft:black_concrete
fill 108 229 579 135 229 579 minecraft:end_stone
fill 108 229 583 108 230 583 minecraft:black_concrete
fill 108 229 598 113 230 598 minecraft:end_stone
fill 109 229 562 114 230 562 minecraft:end_stone
fill 109 229 563 109 230 563 minecraft:black_concrete
fill 109 229 568 109 230 568 minecraft:black_concrete
fill 109 229 578 114 229 578 minecraft:end_stone
fill 109 229 583 114 230 583 minecraft:end_stone
fill 109 229 589 109 230 589 minecraft:black_concrete
fill 110 229 563 115 230 563 minecraft:end_stone
fill 110 229 568 115 230 568 minecraft:end_stone
fill 110 229 569 110 230 569 minecraft:black_concrete
setblock 110 229 574 minecraft:black_concrete
fill 110 229 589 115 230 589 minecraft:end_stone
fill 110 229 595 110 230 595 minecraft:black_concrete
fill 111 229 559 111 230 559 minecraft:black_concrete
fill 111 229 569 116 229 569 minecraft:end_stone
fill 111 229 574 116 229 574 minecraft:end_stone
fill 111 229 580 111 230 580 minecraft:black_concrete
fill 111 229 595 116 230 595 minecraft:end_stone
fill 112 229 559 135 230 559 minecraft:end_stone
fill 112 229 560 112 230 560 minecraft:black_concrete
fill 112 229 565 112 230 565 minecraft:black_concrete
fill 112 229 580 116 229 580 minecraft:end_stone
fill 112 229 581 112 230 581 minecraft:black_concrete
fill 112 229 582 116 229 582 minecraft:end_stone
fill 112 229 586 112 230 586 minecraft:black_concrete
fill 113 229 560 118 230 560 minecraft:end_stone
fill 113 229 565 118 230 565 minecraft:end_stone
fill 113 229 566 113 230 566 minecraft:black_concrete
fill 113 229 571 113 230 571 minecraft:black_concrete
fill 113 229 581 116 229 581 minecraft:end_stone
fill 113 229 586 118 230 586 minecraft:end_stone
fill 113 229 592 113 230 592 minecraft:black_concrete
fill 114 229 566 119 230 566 minecraft:end_stone
fill 114 229 571 115 229 571 minecraft:end_stone
fill 114 229 572 114 230 572 minecraft:black_concrete
fill 114 229 575 115 229 576 minecraft:end_stone
setblock 114 229 577 minecraft:black_concrete
fill 114 229 592 119 230 592 minecraft:end_stone
fill 114 229 598 114 230 598 minecraft:black_concrete
fill 115 229 562 115 230 562 minecraft:black_concrete
setblock 115 229 572 minecraft:end_stone
setblock 115 229 577 minecraft:end_stone
setblock 115 229 578 minecraft:black_concrete
fill 115 229 583 115 230 583 minecraft:black_concrete
fill 115 229 598 120 230 598 minecraft:end_stone
fill 116 229 562 135 230 562 minecraft:end_stone
fill 116 229 563 116 230 563 minecraft:black_concrete
fill 116 229 568 116 230 568 minecraft:black_concrete
fill 116 229 578 121 229 578 minecraft:end_stone
fill 116 229 583 121 229 583 minecraft:end_stone
fill 116 229 584 116 230 584 minecraft:black_concrete
fill 116 229 585 135 230 585 minecraft:end_stone
fill 116 229 589 116 230 589 minecraft:black_concrete
fill 117 229 563 122 230 563 minecraft:end_stone
fill 117 229 568 122 230 568 minecraft:end_stone
setblock 117 229 569 minecraft:black_concrete
setblock 117 229 574 minecraft:black_concrete
fill 117 229 584 122 230 584 minecraft:end_stone
fill 117 229 589 122 230 589 minecraft:end_stone
fill 117 229 595 117 230 595 minecraft:black_concrete
fill 118 229 569 123 229 569 minecraft:end_stone
fill 118 229 574 123 229 574 minecraft:end_stone
fill 118 229 595 123 230 595 minecraft:end_stone
fill 119 229 560 119 230 560 minecraft:black_concrete
fill 119 229 565 119 230 565 minecraft:black_concrete
fill 119 229 570 119 229 572 minecraft:end_stone
fill 119 229 575 120 229 577 minecraft:end_stone
fill 119 229 586 119 230 586 minecraft:black_concrete
fill 120 229 560 125 230 560 minecraft:end_stone
fill 120 229 565 135 230 565 minecraft:end_stone
fill 120 229 566 120 230 566 minecraft:black_concrete
fill 120 229 570 135 230 570 minecraft:end_stone
fill 120 229 571 120 230 571 minecraft:black_concrete
fill 120 229 572 120 230 572 minecraft:end_stone
fill 120 229 580 124 229 582 minecraft:end_stone
fill 120 229 586 125 230 586 minecraft:end_stone
fill 120 229 587 120 230 587 minecraft:black_concrete
fill 120 229 588 135 230 588 minecraft:end_stone
fill 120 229 592 120 230 592 minecraft:black_concrete
fill 121 229 566 126 230 566 minecraft:end_stone
fill 121 229 571 126 230 571 minecraft:end_stone
fill 121 229 572 121 230 572 minecraft:black_concrete
fill 121 229 587 126 230 587 minecraft:end_stone
fill 121 229 592 126 230 592 minecraft:end_stone
fill 121 229 598 121 230 598 minecraft:black_concrete
fill 122 229 572 127 230 572 minecraft:end_stone
setblock 122 229 578 minecraft:black_concrete
fill 122 229 583 122 230 583 minecraft:black_concrete
fill 122 229 598 127 230 598 minecraft:end_stone
fill 123 229 563 123 230 563 minecraft:black_concrete
fill 123 229 568 123 230 568 minecraft:black_concrete
fill 123 229 578 128 229 578 minecraft:end_stone
fill 123 229 583 128 230 583 minecraft:end_stone
fill 123 229 584 123 230 584 minecraft:black_concrete
fill 123 229 589 123 230 589 minecraft:black_concrete
fill 124 229 563 129 230 563 minecraft:end_stone
fill 124 229 568 135 230 568 minecraft:end_stone
fill 124 229 569 124 230 569 minecraft:black_concrete
setblock 124 229 574 minecraft:black_concrete
fill 124 229 575 124 229 577 minecraft:end_stone
fill 124 229 584 129 230 584 minecraft:end_stone
fill 124 229 589 129 230 589 minecraft:end_stone
fill 124 229 590 124 230 590 minecraft:black_concrete
fill 124 229 591 135 230 591 minecraft:end_stone
fill 124 229 595 124 230 595 minecraft:black_concrete
fill 125 229 569 130 230 569 minecraft:end_stone
fill 125 229 574 130 230 574 minecraft:end_stone
fill 125 229 575 125 230 575 minecraft:black_concrete
fill 125 229 576 127 230 577 minecraft:end_stone
fill 125 229 580 125 230 580 minecraft:black_concrete
fill 125 229 581 125 230 582 minecraft:end_stone
fill 125 229 590 130 230 590 minecraft:end_stone
fill 125 229 595 130 230 595 minecraft:end_stone
fill 126 229 560 126 230 560 minecraft:black_concrete
fill 126 229 575 131 230 575 minecraft:end_stone
fill 126 229 580 131 230 580 minecraft:end_stone
fill 126 229 581 126 230 581 minecraft:black_concrete
fill 126 229 582 135 230 582 minecraft:end_stone
fill 126 229 586 126 230 586 minecraft:black_concrete
fill 127 229 560 132 230 560 minecraft:end_stone
fill 127 229 566 127 230 566 minecraft:black_concrete
fill 127 229 571 127 230 571 minecraft:black_concrete
fill 127 229 581 132 230 581 minecraft:end_stone
fill 127 229 586 132 230 586 minecraft:end_stone
fill 127 229 587 127 230 587 minecraft:black_concrete
fill 127 229 592 127 230 592 minecraft:black_concrete
fill 128 229 566 133 230 566 minecraft:end_stone
fill 128 229 571 135 230 571 minecraft:end_stone
fill 128 229 572 128 230 572 minecraft:black_concrete
fill 128 229 576 135 230 576 minecraft:end_stone
fill 128 229 577 128 230 577 minecraft:black_concrete
fill 128 229 587 133 230 587 minecraft:end_stone
fill 128 229 592 133 230 592 minecraft:end_stone
fill 128 229 593 128 230 593 minecraft:black_concrete
fill 128 229 594 135 230 594 minecraft:end_stone
fill 128 229 598 128 230 598 minecraft:black_concrete
fill 129 229 572 134 230 572 minecraft:end_stone
fill 129 229 577 134 230 577 minecraft:end_stone
fill 129 229 578 129 230 578 minecraft:black_concrete
fill 129 229 583 129 230 583 minecraft:black_concrete
fill 129 229 593 134 230 593 minecraft:end_stone
fill 129 229 598 134 230 598 minecraft:end_stone
fill 130 229 563 130 230 563 minecraft:black_concrete
fill 130 229 578 135 230 578 minecraft:end_stone
fill 130 229 583 135 230 583 minecraft:end_stone
fill 130 229 584 130 230 584 minecraft:black_concrete
fill 130 229 589 130 230 589 minecraft:black_concrete
fill 131 229 563 135 230 563 minecraft:end_stone
fill 131 229 569 131 230 569 minecraft:black_concrete
fill 131 229 574 131 230 574 minecraft:black_concrete
fill 131 229 584 135 230 584 minecraft:end_stone
fill 131 229 589 135 230 589 minecraft:end_stone
fill 131 229 590 131 230 590 minecraft:black_concrete
fill 131 229 595 131 230 595 minecraft:black_concrete
fill 132 229 569 135 230 569 minecraft:end_stone
fill 132 229 574 135 230 574 minecraft:end_stone
fill 132 229 575 132 230 575 minecraft:black_concrete
fill 132 229 580 132 230 580 minecraft:black_concrete
fill 132 229 590 135 230 590 minecraft:end_stone
fill 132 229 595 135 230 595 minecraft:end_stone
fill 132 229 596 132 230 596 minecraft:black_concrete
fill 132 229 597 135 230 597 minecraft:end_stone
fill 132 229 599 132 307 599 minecraft:black_concrete
fill 133 229 560 133 230 560 minecraft:black_concrete
fill 133 229 575 135 230 575 minecraft:end_stone
fill 133 229 580 135 230 580 minecraft:end_stone
fill 133 229 581 133 230 581 minecraft:black_concrete
fill 133 229 586 133 230 586 minecraft:black_concrete
fill 133 229 596 135 230 596 minecraft:end_stone
setblock 134 229 557 minecraft:white_stained_glass
fill 134 229 560 135 230 560 minecraft:end_stone
fill 134 229 566 134 230 566 minecraft:black_concrete
fill 134 229 581 135 230 581 minecraft:end_stone
fill 134 229 586 135 230 586 minecraft:end_stone
fill 134 229 587 134 230 587 minecraft:black_concrete
fill 134 229 592 134 230 592 minecraft:black_concrete
fill 135 229 566 135 230 566 minecraft:end_stone
fill 135 229 572 135 230 572 minecraft:black_concrete
fill 135 229 577 135 230 577 minecraft:black_concrete
fill 135 229 587 135 230 587 minecraft:end_stone
fill 135 229 592 135 230 592 minecraft:end_stone
fill 135 229 593 135 230 593 minecraft:black_concrete
fill 135 229 598 135 230 598 minecraft:black_concrete
fill 136 229 561 136 266 561 minecraft:black_concrete
setblock 136 229 562 minecraft:white_concrete
fill 136 229 563 136 274 563 minecraft:black_concrete
fill 136 229 584 136 307 584 minecraft:black_concrete
fill 94 230 566 94 307 566 minecraft:black_concrete
fill 94 230 575 94 260 575 minecraft:black_concrete
fill 94 230 591 94 307 591 minecraft:black_concrete
fill 99 230 570 114 230 570 minecraft:end_stone
fill 103 230 573 114 230 573 minecraft:end_stone
fill 104 230 576 109 230 576 minecraft:end_stone
fill 105 230 575 109 230 575 minecraft:end_stone
fill 108 230 577 109 230 577 minecraft:end_stone
fill 108 230 579 115 230 579 minecraft:end_stone
setblock 109 230 578 minecraft:end_stone
fill 110 230 574 110 230 578 minecraft:pearlescent_froglight
fill 111 230 569 114 230 569 minecraft:end_stone
fill 111 230 574 124 230 574 minecraft:pearlescent_froglight
fill 111 230 575 113 230 577 minecraft:end_stone
fill 111 230 578 124 230 578 minecraft:pearlescent_froglight
fill 112 230 580 115 230 580 minecraft:end_stone
fill 112 230 582 115 230 582 minecraft:end_stone
fill 113 230 581 115 230 581 minecraft:end_stone
setblock 114 230 571 minecraft:end_stone
fill 114 230 575 115 230 577 minecraft:pearlescent_froglight
fill 115 230 569 115 230 573 minecraft:pearlescent_froglight
fill 116 230 569 119 230 569 minecraft:pearlescent_froglight
fill 116 230 570 118 230 572 minecraft:end_stone
fill 116 230 573 119 230 573 minecraft:pearlescent_froglight
fill 116 230 579 116 230 583 minecraft:pearlescent_froglight
fill 117 230 579 120 230 579 minecraft:pearlescent_froglight
fill 117 230 580 119 230 582 minecraft:end_stone
fill 117 230 583 120 230 583 minecraft:pearlescent_froglight
fill 119 230 570 119 230 572 minecraft:pearlescent_froglight
fill 119 230 575 120 230 577 minecraft:pearlescent_froglight
fill 120 230 569 123 230 569 minecraft:end_stone
fill 120 230 573 135 230 573 minecraft:end_stone
fill 120 230 580 120 230 582 minecraft:pearlescent_froglight
fill 121 230 575 123 230 577 minecraft:end_stone
fill 121 230 579 121 230 583 minecraft:end_stone
fill 122 230 579 124 230 582 minecraft:end_stone
fill 124 230 575 124 230 577 minecraft:pearlescent_froglight
fill 125 230 578 128 230 579 minecraft:end_stone
fill 126 230 557 126 236 557 minecraft:black_concrete
setblock 127 230 557 minecraft:white_concrete
fill 128 230 557 131 233 557 minecraft:black_concrete
fill 129 230 579 135 230 579 minecraft:end_stone
setblock 132 230 557 minecraft:white_stained_glass
setblock 133 230 557 minecraft:white_concrete
fill 134 230 557 134 231 557 minecraft:black_concrete
fill 136 230 562 136 307 562 minecraft:black_concrete
setblock 136 230 564 minecraft:white_concrete
fill 136 230 572 136 307 572 minecraft:black_concrete
setblock 136 230 573 minecraft:pearlescent_froglight
fill 127 231 557 127 280 557 minecraft:black_concrete
fill 132 231 557 133 250 557 minecraft:black_concrete
fill 136 231 564 136 255 564 minecraft:black_concrete
fill 136 231 573 136 271 573 minecraft:black_concrete
fill 94 232 580 94 233 581 minecraft:black_concrete
setblock 94 232 582 minecraft:white_concrete
setblock 97 232 560 minecraft:light[level=14]
setblock 97 232 568 minecraft:light[level=14]
setblock 97 232 576 minecraft:light[level=14]
setblock 97 232 584 minecraft:light[level=14]
setblock 97 232 592 minecraft:light[level=14]
setblock 99 232 557 minecraft:white_stained_glass
fill 100 232 557 107 238 557 minecraft:black_concrete
setblock 105 232 560 minecraft:light[level=14]
setblock 105 232 568 minecraft:light[level=14]
setblock 105 232 576 minecraft:light[level=14]
setblock 105 232 584 minecraft:light[level=14]
setblock 105 232 592 minecraft:light[level=14]
setblock 113 232 560 minecraft:light[level=14]
setblock 113 232 568 minecraft:light[level=14]
setblock 113 232 576 minecraft:light[level=14]
setblock 113 232 584 minecraft:light[level=14]
setblock 113 232 592 minecraft:light[level=14]
setblock 121 232 560 minecraft:light[level=14]
setblock 121 232 568 minecraft:light[level=14]
setblock 121 232 576 minecraft:light[level=14]
setblock 121 232 584 minecraft:light[level=14]
setblock 121 232 592 minecraft:light[level=14]
setblock 129 232 560 minecraft:light[level=14]
setblock 129 232 568 minecraft:light[level=14]
setblock 129 232 576 minecraft:light[level=14]
setblock 129 232 584 minecraft:light[level=14]
setblock 129 232 592 minecraft:light[level=14]
setblock 134 232 557 minecraft:white_concrete
fill 94 233 582 94 246 582 minecraft:black_concrete
fill 99 233 557 99 307 557 minecraft:black_concrete
fill 110 233 557 110 278 557 minecraft:black_concrete
setblock 111 233 557 minecraft:white_stained_glass
fill 112 233 557 113 274 557 minecraft:black_concrete
fill 118 233 557 122 238 557 minecraft:black_concrete
setblock 123 233 557 minecraft:white_concrete
fill 134 233 557 134 251 557 minecraft:black_concrete
fill 94 234 565 94 236 565 minecraft:light_gray_concrete
fill 94 234 580 94 246 580 minecraft:black_concrete
fill 94 234 581 94 236 581 minecraft:light_gray_concrete
fill 94 234 597 94 236 597 minecraft:light_gray_concrete
fill 98 234 557 98 236 557 minecraft:light_gray_concrete
fill 108 234 599 108 236 599 minecraft:light_gray_concrete
fill 109 234 599 111 258 599 minecraft:black_concrete
fill 111 234 557 111 278 557 minecraft:black_concrete
fill 114 234 557 114 236 557 minecraft:light_gray_concrete
fill 115 234 557 116 278 557 minecraft:black_concrete
fill 122 234 599 123 282 599 minecraft:black_concrete
fill 123 234 557 123 278 557 minecraft:black_concrete
fill 124 234 599 124 236 599 minecraft:light_gray_concrete
fill 128 234 557 129 252 557 minecraft:black_concrete
fill 130 234 557 130 236 557 minecraft:light_gray_concrete
fill 131 234 557 131 307 557 minecraft:black_concrete
setblock 136 234 566 minecraft:white_concrete
fill 136 234 567 136 236 567 minecraft:light_gray_concrete
fill 136 234 583 136 236 583 minecraft:light_gray_concrete
fill 102 235 573 104 236 573 minecraft:light_gray_concrete
fill 103 235 572 103 236 572 minecraft:light_gray_concrete
fill 103 235 574 103 236 574 minecraft:light_gray_concrete
setblock 107 235 599 minecraft:pearlescent_froglight
fill 108 235 557 108 278 557 minecraft:black_concrete
setblock 109 235 557 minecraft:white_stained_glass
fill 136 235 566 136 307 566 minecraft:black_concrete
fill 95 236 557 95 300 557 minecraft:black_concrete
setblock 96 236 557 minecraft:white_concrete
fill 97 236 557 97 307 557 minecraft:black_concrete
fill 107 236 599 107 292 599 minecraft:black_concrete
fill 109 236 557 109 249 557 minecraft:black_concrete
setblock 136 236 574 minecraft:white_concrete
fill 136 236 575 136 307 575 minecraft:black_concrete
setblock 94 237 560 minecraft:pearlescent_froglight
fill 94 237 565 94 242 565 minecraft:black_concrete
fill 94 237 581 94 242 581 minecraft:black_concrete
fill 94 237 597 94 242 597 minecraft:black_concrete
fill 96 237 557 96 270 557 minecraft:black_concrete
fill 97 237 599 98 260 599 minecraft:black_concrete
fill 98 237 557 98 242 557 minecraft:black_concrete
setblock 99 237 599 minecraft:white_concrete
fill 100 237 599 101 251 599 minecraft:black_concrete
fill 108 237 599 108 242 599 minecraft:black_concrete
fill 114 237 557 114 242 557 minecraft:black_concrete
fill 124 237 599 124 242 599 minecraft:black_concrete
setblock 126 237 557 minecraft:white_stained_glass
fill 130 237 557 130 242 557 minecraft:black_concrete
fill 136 237 567 136 242 567 minecraft:black_concrete
fill 136 237 574 136 307 574 minecraft:black_concrete
fill 136 237 583 136 242 583 minecraft:black_concrete
setblock 136 237 598 minecraft:white_stained_glass
fill 94 238 560 94 307 560 minecraft:black_concrete
fill 99 238 599 99 273 599 minecraft:black_concrete
fill 124 238 566 126 239 566 minecraft:end_stone
fill 125 238 567 126 239 567 minecraft:end_stone
fill 126 238 557 126 250 557 minecraft:black_concrete
fill 136 238 598 136 286 598 minecraft:black_concrete
fill 100 239 557 104 239 557 minecraft:black_concrete
setblock 105 239 557 minecraft:pearlescent_froglight
fill 106 239 557 107 251 557 minecraft:black_concrete
setblock 112 239 599 minecraft:white_concrete
setblock 118 239 557 minecraft:white_stained_glass
fill 119 239 557 122 248 557 minecraft:black_concrete
setblock 121 239 599 minecraft:pearlescent_froglight
setblock 97 240 560 minecraft:light[level=14]
setblock 97 240 568 minecraft:light[level=14]
setblock 97 240 576 minecraft:light[level=14]
setblock 97 240 584 minecraft:light[level=14]
setblock 97 240 592 minecraft:light[level=14]
fill 100 240 557 100 243 557 minecraft:black_concrete
setblock 101 240 557 minecraft:white_stained_glass
fill 102 240 557 105 269 557 minecraft:black_concrete
setblock 105 240 560 minecraft:light[level=14]
setblock 105 240 568 minecraft:light[level=14]
setblock 105 240 576 minecraft:light[level=14]
setblock 105 240 584 minecraft:light[level=14]
setblock 105 240 592 minecraft:light[level=14]
fill 112 240 599 112 307 599 minecraft:black_concrete
setblock 113 240 560 minecraft:light[level=14]
setblock 113 240 568 minecraft:light[level=14]
setblock 113 240 576 minecraft:light[level=14]
setblock 113 240 584 minecraft:light[level=14]
setblock 113 240 592 minecraft:light[level=14]
fill 118 240 557 118 261 557 minecraft:black_concrete
setblock 121 240 560 minecraft:light[level=14]
setblock 121 240 568 minecraft:light[level=14]
setblock 121 240 576 minecraft:light[level=14]
setblock 121 240 584 minecraft:light[level=14]
setblock 121 240 592 minecraft:light[level=14]
fill 121 240 599 121 241 599 minecraft:black_concrete
setblock 129 240 560 minecraft:light[level=14]
setblock 129 240 568 minecraft:light[level=14]
setblock 129 240 576 minecraft:light[level=14]
setblock 129 240 584 minecraft:light[level=14]
setblock 129 240 592 minecraft:light[level=14]
setblock 136 240 570 minecraft:white_stained_glass
setblock 94 241 598 minecraft:white_concrete
fill 94 241 599 94 307 599 minecraft:black_concrete
fill 101 241 557 101 307 557 minecraft:black_concrete
fill 136 241 570 136 302 570 minecraft:black_concrete
setblock 94 242 558 minecraft:white_concrete
fill 94 242 559 94 307 559 minecraft:black_concrete
fill 94 242 586 94 257 586 minecraft:black_concrete
setblock 94 242 587 minecraft:white_stained_glass
fill 94 242 588 94 281 590 minecraft:black_concrete
setblock 94 242 598 minecraft:black_concrete
setblock 121 242 599 minecraft:pearlescent_froglight
fill 130 242 573 131 243 574 minecraft:gray_concrete
fill 94 243 558 94 307 558 minecraft:black_concrete
fill 94 243 565 94 245 565 minecraft:light_gray_concrete
fill 94 243 581 94 245 581 minecraft:light_gray_concrete
fill 94 243 587 94 307 587 minecraft:black_concrete
fill 94 243 597 94 245 597 minecraft:light_gray_concrete
setblock 94 243 598 minecraft:pearlescent_froglight
fill 98 243 557 98 245 557 minecraft:light_gray_concrete
fill 108 243 599 108 245 599 minecraft:light_gray_concrete
fill 114 243 557 114 245 557 minecraft:light_gray_concrete
fill 121 243 599 121 307 599 minecraft:black_concrete
fill 124 243 599 124 245 599 minecraft:light_gray_concrete
fill 130 243 557 130 245 557 minecraft:light_gray_concrete
fill 136 243 567 136 245 567 minecraft:light_gray_concrete
setblock 136 243 571 minecraft:pearlescent_froglight
fill 136 243 583 136 245 583 minecraft:light_gray_concrete
fill 136 243 585 136 246 592 minecraft:black_concrete
setblock 136 243 593 minecraft:white_concrete
fill 136 243 594 136 283 594 minecraft:black_concrete
setblock 136 243 595 minecraft:pearlescent_froglight
fill 136 243 596 136 246 596 minecraft:black_concrete
fill 94 244 569 94 245 573 minecraft:black_concrete
setblock 94 244 574 minecraft:white_concrete
fill 94 244 598 94 288 598 minecraft:black_concrete
setblock 100 244 557 minecraft:white_concrete
fill 136 244 571 136 307 571 minecraft:black_concrete
fill 136 244 593 136 289 593 minecraft:black_concrete
fill 136 244 595 136 268 595 minecraft:black_concrete
fill 94 245 574 94 307 574 minecraft:black_concrete
fill 100 245 557 100 307 557 minecraft:black_concrete
fill 94 246 565 94 247 565 minecraft:black_concrete
fill 94 246 569 94 307 570 minecraft:black_concrete
setblock 94 246 571 minecraft:white_concrete
fill 94 246 572 94 277 573 minecraft:black_concrete
fill 94 246 581 94 251 581 minecraft:black_concrete
fill 94 246 597 94 251 597 minecraft:black_concrete
fill 98 246 557 98 251 557 minecraft:black_concrete
fill 108 246 599 108 251 599 minecraft:black_concrete
fill 114 246 557 114 251 557 minecraft:black_concrete
fill 114 246 599 114 262 599 minecraft:black_concrete
setblock 115 246 599 minecraft:white_concrete
fill 116 246 599 116 280 599 minecraft:black_concrete
fill 124 246 599 124 251 599 minecraft:black_concrete
fill 130 246 557 130 251 557 minecraft:black_concrete
fill 136 246 567 136 251 567 minecraft:black_concrete
fill 136 246 583 136 251 583 minecraft:black_concrete
fill 94 247 571 94 254 571 minecraft:black_concrete
setblock 94 247 580 minecraft:pearlescent_froglight
setblock 94 247 582 minecraft:white_stained_glass
setblock 115 247 599 minecraft:black_concrete
fill 136 247 585 136 252 589 minecraft:black_concrete
setblock 136 247 590 minecraft:white_stained_glass
fill 136 247 591 136 253 592 minecraft:black_concrete
setblock 136 247 596 minecraft:white_concrete
setblock 94 248 565 minecraft:white_concrete
fill 94 248 580 94 307 580 minecraft:black_concrete
fill 94 248 582 94 285 582 minecraft:black_concrete
setblock 94 248 593 minecraft:white_stained_glass
fill 94 248 594 94 290 595 minecraft:black_concrete
setblock 97 248 560 minecraft:light[level=14]
setblock 97 248 568 minecraft:light[level=14]
setblock 97 248 576 minecraft:light[level=14]
setblock 97 248 584 minecraft:light[level=14]
setblock 97 248 592 minecraft:light[level=14]
setblock 105 248 560 minecraft:light[level=14]
setblock 105 248 568 minecraft:light[level=14]
setblock 105 248 576 minecraft:light[level=14]
setblock 105 248 584 minecraft:light[level=14]
setblock 105 248 592 minecraft:light[level=14]
setblock 113 248 560 minecraft:light[level=14]
setblock 113 248 568 minecraft:light[level=14]
setblock 113 248 576 minecraft:light[level=14]
setblock 113 248 584 minecraft:light[level=14]
setblock 113 248 592 minecraft:light[level=14]
setblock 115 248 599 minecraft:white_concrete
setblock 121 248 560 minecraft:light[level=14]
setblock 121 248 568 minecraft:light[level=14]
setblock 121 248 576 minecraft:light[level=14]
setblock 121 248 584 minecraft:light[level=14]
setblock 121 248 592 minecraft:light[level=14]
setblock 129 248 560 minecraft:light[level=14]
setblock 129 248 568 minecraft:light[level=14]
setblock 129 248 576 minecraft:light[level=14]
setblock 129 248 584 minecraft:light[level=14]
setblock 129 248 592 minecraft:light[level=14]
fill 136 248 590 136 298 590 minecraft:black_concrete
fill 136 248 596 136 307 596 minecraft:black_concrete
fill 94 249 565 94 251 565 minecraft:black_concrete
fill 94 249 593 94 257 593 minecraft:black_concrete
fill 115 249 599 115 265 599 minecraft:black_concrete
setblock 119 249 557 minecraft:white_concrete
fill 120 249 557 122 257 557 minecraft:black_concrete
setblock 109 250 557 minecraft:white_concrete
fill 119 250 557 119 278 557 minecraft:black_concrete
fill 109 251 557 109 278 557 minecraft:black_concrete
setblock 126 251 557 minecraft:white_stained_glass
setblock 132 251 557 minecraft:white_concrete
fill 133 251 557 133 307 557 minecraft:black_concrete
setblock 136 251 578 minecraft:pearlescent_froglight
fill 94 252 565 94 254 565 minecraft:light_gray_concrete
fill 94 252 576 94 253 576 minecraft:black_concrete
setblock 94 252 577 minecraft:white_concrete
fill 94 252 581 94 254 581 minecraft:light_gray_concrete
fill 94 252 597 94 254 597 minecraft:light_gray_concrete
fill 98 252 557 98 254 557 minecraft:light_gray_concrete
setblock 100 252 599 minecraft:pearlescent_froglight
fill 101 252 599 101 307 599 minecraft:black_concrete
fill 106 252 557 106 295 557 minecraft:black_concrete
setblock 107 252 557 minecraft:white_concrete
fill 108 252 599 108 254 599 minecraft:light_gray_concrete
fill 114 252 557 114 254 557 minecraft:light_gray_concrete
fill 124 252 599 124 254 599 minecraft:light_gray_concrete
fill 126 252 557 126 284 557 minecraft:black_concrete
fill 130 252 557 130 254 557 minecraft:light_gray_concrete
fill 132 252 557 132 282 557 minecraft:black_concrete
setblock 134 252 557 minecraft:white_concrete
fill 136 252 567 136 254 567 minecraft:light_gray_concrete
fill 136 252 578 136 307 578 minecraft:black_concrete
fill 136 252 583 136 254 583 minecraft:light_gray_concrete
fill 94 253 577 94 278 577 minecraft:black_concrete
fill 100 253 599 100 258 599 minecraft:black_concrete
fill 106 253 569 106 254 569 minecraft:white_stained_glass
fill 107 253 557 107 259 557 minecraft:black_concrete
setblock 124 253 557 minecraft:pearlescent_froglight
setblock 128 253 557 minecraft:white_concrete
fill 129 253 557 129 277 557 minecraft:black_concrete
fill 134 253 557 134 266 557 minecraft:black_concrete
setblock 136 253 585 minecraft:white_stained_glass
fill 136 253 586 136 259 589 minecraft:black_concrete
setblock 94 254 576 minecraft:white_stained_glass
fill 103 254 563 104 255 564 minecraft:gray_concrete
fill 124 254 557 124 300 557 minecraft:black_concrete
fill 128 254 557 128 256 557 minecraft:black_concrete
setblock 131 254 599 minecraft:pearlescent_froglight
fill 136 254 585 136 307 585 minecraft:black_concrete
setblock 136 254 591 minecraft:white_concrete
fill 136 254 592 136 291 592 minecraft:black_concrete
fill 94 255 565 94 260 565 minecraft:black_concrete
setblock 94 255 571 minecraft:pearlescent_froglight
fill 94 255 576 94 256 576 minecraft:black_concrete
fill 94 255 581 94 260 581 minecraft:black_concrete
fill 94 255 597 94 260 597 minecraft:black_concrete
fill 98 255 557 98 260 557 minecraft:black_concrete
fill 106 255 569 107 261 569 minecraft:gray_concrete
fill 108 255 599 108 260 599 minecraft:black_concrete
fill 114 255 557 114 260 557 minecraft:black_concrete
fill 124 255 599 124 260 599 minecraft:black_concrete
fill 130 255 557 130 260 557 minecraft:black_concrete
fill 131 255 599 131 288 599 minecraft:black_concrete
setblock 135 255 557 minecraft:pearlescent_froglight
fill 136 255 567 136 260 567 minecraft:black_concrete
fill 136 255 583 136 260 583 minecraft:black_concrete
fill 136 255 591 136 307 591 minecraft:black_concrete
fill 94 256 571 94 307 571 minecraft:black_concrete
setblock 97 256 560 minecraft:light[level=14]
setblock 97 256 568 minecraft:light[level=14]
setblock 97 256 576 minecraft:light[level=14]
setblock 97 256 584 minecraft:light[level=14]
setblock 97 256 592 minecraft:light[level=14]
setblock 105 256 560 minecraft:light[level=14]
setblock 105 256 568 minecraft:light[level=14]
setblock 105 256 576 minecraft:light[level=14]
setblock 105 256 584 minecraft:light[level=14]
setblock 105 256 592 minecraft:light[level=14]
fill 107 256 576 107 257 576 minecraft:gray_concrete
setblock 113 256 560 minecraft:light[level=14]
setblock 113 256 568 minecraft:light[level=14]
setblock 113 256 576 minecraft:light[level=14]
setblock 113 256 584 minecraft:light[level=14]
setblock 113 256 592 minecraft:light[level=14]
setblock 121 256 560 minecraft:light[level=14]
setblock 121 256 568 minecraft:light[level=14]
setblock 121 256 576 minecraft:light[level=14]
setblock 121 256 584 minecraft:light[level=14]
setblock 121 256 592 minecraft:light[level=14]
fill 124 256 570 126 257 570 minecraft:gray_concrete
fill 125 256 569 125 257 569 minecraft:gray_concrete
fill 125 256 571 125 257 571 minecraft:gray_concrete
setblock 129 256 560 minecraft:light[level=14]
setblock 129 256 568 minecraft:light[level=14]
setblock 129 256 576 minecraft:light[level=14]
setblock 129 256 584 minecraft:light[level=14]
setblock 129 256 592 minecraft:light[level=14]
fill 135 256 557 135 307 557 minecraft:black_concrete
setblock 136 256 564 minecraft:pearlescent_froglight
setblock 94 257 576 minecraft:white_concrete
fill 106 257 568 107 261 568 minecraft:gray_concrete
fill 106 257 570 107 261 570 minecraft:gray_concrete
setblock 128 257 557 minecraft:white_concrete
fill 136 257 564 136 307 564 minecraft:black_concrete
setblock 136 257 582 minecraft:white_stained_glass
setblock 94 258 561 minecraft:pearlescent_froglight
fill 94 258 562 94 280 563 minecraft:black_concrete
fill 94 258 576 94 278 576 minecraft:black_concrete
setblock 94 258 586 minecraft:pearlescent_froglight
setblock 94 258 593 minecraft:white_stained_glass
fill 105 258 568 105 261 569 minecraft:gray_concrete
fill 108 258 569 108 261 569 minecraft:gray_concrete
fill 120 258 557 121 278 557 minecraft:black_concrete
setblock 122 258 557 minecraft:white_concrete
fill 128 258 557 128 283 557 minecraft:black_concrete
fill 131 258 580 131 259 580 minecraft:white_stained_glass
fill 136 258 582 136 270 582 minecraft:black_concrete
fill 94 259 561 94 307 561 minecraft:black_concrete
fill 94 259 586 94 307 586 minecraft:black_concrete
fill 94 259 593 94 281 593 minecraft:black_concrete
setblock 100 259 599 minecraft:white_stained_glass
fill 105 259 570 105 261 570 minecraft:gray_concrete
fill 106 259 567 107 261 567 minecraft:gray_concrete
fill 106 259 571 107 261 571 minecraft:gray_concrete
fill 108 259 568 108 261 568 minecraft:gray_concrete
fill 108 259 570 108 261 570 minecraft:gray_concrete
fill 109 259 599 109 307 599 minecraft:black_concrete
setblock 110 259 599 minecraft:white_stained_glass
fill 111 259 599 111 307 599 minecraft:black_concrete
fill 122 259 557 122 278 557 minecraft:black_concrete
fill 100 260 599 100 307 599 minecraft:black_concrete
fill 104 260 568 104 261 569 minecraft:gray_concrete
fill 105 260 567 105 261 567 minecraft:gray_concrete
fill 105 260 571 105 261 571 minecraft:gray_concrete
setblock 107 260 557 minecraft:white_stained_glass
fill 108 260 567 108 261 567 minecraft:gray_concrete
fill 109 260 569 109 261 569 minecraft:gray_concrete
fill 110 260 599 110 307 599 minecraft:black_concrete
fill 131 260 580 131 268 580 minecraft:gray_concrete
setblock 136 260 586 minecraft:pearlescent_froglight
fill 136 260 587 136 274 589 minecraft:black_concrete
fill 94 261 565 94 263 565 minecraft:light_gray_concrete
setblock 94 261 575 minecraft:pearlescent_froglight
fill 94 261 581 94 263 581 minecraft:light_gray_concrete
fill 94 261 597 94 263 597 minecraft:light_gray_concrete
fill 97 261 599 97 292 599 minecraft:black_concrete
fill 98 261 557 98 263 557 minecraft:light_gray_concrete
setblock 98 261 599 minecraft:pearlescent_froglight
setblock 104 261 570 minecraft:gray_concrete
fill 106 261 566 107 261 566 minecraft:gray_concrete
fill 107 261 557 107 278 557 minecraft:black_concrete
setblock 108 261 571 minecraft:gray_concrete
fill 108 261 599 108 263 599 minecraft:light_gray_concrete
setblock 109 261 568 minecraft:gray_concrete
setblock 109 261 570 minecraft:gray_concrete
fill 114 261 557 114 263 557 minecraft:light_gray_concrete
fill 124 261 599 124 263 599 minecraft:light_gray_concrete
fill 130 261 557 130 263 557 minecraft:light_gray_concrete
fill 131 261 579 132 268 579 minecraft:gray_concrete
fill 132 261 580 132 268 580 minecraft:gray_concrete
fill 136 261 567 136 263 567 minecraft:light_gray_concrete
fill 136 261 583 136 263 583 minecraft:light_gray_concrete
fill 136 261 586 136 307 586 minecraft:black_concrete
fill 94 262 575 94 307 575 minecraft:black_concrete
fill 98 262 599 98 307 599 minecraft:black_concrete
fill 105 262 568 105 264 568 minecraft:end_stone
fill 106 262 570 106 263 570 minecraft:end_stone
fill 108 262 569 108 265 569 minecraft:end_stone
setblock 118 262 557 minecraft:white_stained_glass
fill 130 262 580 130 268 580 minecraft:gray_concrete
fill 131 262 581 132 268 581 minecraft:gray_concrete
setblock 114 263 599 minecraft:pearlescent_froglight
fill 118 263 557 118 278 557 minecraft:black_concrete
fill 130 263 579 130 268 579 minecraft:gray_concrete
fill 130 263 581 130 268 581 minecraft:gray_concrete
fill 131 263 578 132 268 578 minecraft:gray_concrete
fill 133 263 579 133 268 580 minecraft:gray_concrete
fill 94 264 565 94 269 565 minecraft:black_concrete
fill 94 264 581 94 265 581 minecraft:black_concrete
setblock 94 264 585 minecraft:pearlescent_froglight
fill 94 264 597 94 269 597 minecraft:black_concrete
setblock 97 264 560 minecraft:light[level=14]
setblock 97 264 568 minecraft:light[level=14]
setblock 97 264 576 minecraft:light[level=14]
setblock 97 264 584 minecraft:light[level=14]
setblock 97 264 592 minecraft:light[level=14]
fill 98 264 557 98 269 557 minecraft:black_concrete
setblock 105 264 560 minecraft:light[level=14]
setblock 105 264 576 minecraft:light[level=14]
setblock 105 264 584 minecraft:light[level=14]
setblock 105 264 592 minecraft:light[level=14]
fill 108 264 599 108 269 599 minecraft:black_concrete
setblock 113 264 560 minecraft:light[level=14]
setblock 113 264 568 minecraft:light[level=14]
setblock 113 264 576 minecraft:light[level=14]
setblock 113 264 584 minecraft:light[level=14]
setblock 113 264 592 minecraft:light[level=14]
fill 114 264 557 114 269 557 minecraft:black_concrete
fill 114 264 599 114 268 599 minecraft:black_concrete
setblock 121 264 560 minecraft:light[level=14]
setblock 121 264 568 minecraft:light[level=14]
setblock 121 264 576 minecraft:light[level=14]
setblock 121 264 584 minecraft:light[level=14]
setblock 121 264 592 minecraft:light[level=14]
fill 124 264 599 124 269 599 minecraft:black_concrete
setblock 129 264 560 minecraft:light[level=14]
setblock 129 264 568 minecraft:light[level=14]
setblock 129 264 576 minecraft:light[level=14]
fill 129 264 580 129 268 580 minecraft:gray_concrete
setblock 129 264 584 minecraft:light[level=14]
setblock 129 264 592 minecraft:light[level=14]
fill 130 264 557 130 269 557 minecraft:black_concrete
fill 130 264 578 130 268 578 minecraft:gray_concrete
fill 131 264 582 132 268 582 minecraft:gray_concrete
fill 133 264 578 133 268 578 minecraft:gray_concrete
fill 133 264 581 133 268 581 minecraft:gray_concrete
fill 136 264 567 136 269 567 minecraft:black_concrete
fill 136 264 583 136 269 583 minecraft:black_concrete
fill 94 265 585 94 281 585 minecraft:black_concrete
fill 129 265 579 129 268 579 minecraft:gray_concrete
fill 129 265 581 129 268 581 minecraft:gray_concrete
fill 130 265 582 130 268 582 minecraft:gray_concrete
fill 131 265 577 132 268 577 minecraft:gray_concrete
fill 133 265 582 133 268 582 minecraft:gray_concrete
fill 134 265 579 134 268 581 minecraft:gray_concrete
fill 136 265 576 136 278 576 minecraft:black_concrete
setblock 136 265 577 minecraft:white_stained_glass
setblock 94 266 581 minecraft:white_stained_glass
setblock 115 266 599 minecraft:pearlescent_froglight
fill 128 266 580 128 268 580 minecraft:gray_concrete
fill 129 266 578 129 268 578 minecraft:gray_concrete
fill 129 266 582 129 268 582 minecraft:gray_concrete
fill 130 266 577 130 268 577 minecraft:gray_concrete
fill 131 266 583 132 268 583 minecraft:gray_concrete
fill 133 266 577 133 268 577 minecraft:gray_concrete
fill 133 266 599 133 307 599 minecraft:black_concrete
fill 134 266 578 134 268 578 minecraft:gray_concrete
fill 134 266 582 134 268 582 minecraft:gray_concrete
setblock 134 266 599 minecraft:pearlescent_froglight
fill 136 266 577 136 273 577 minecraft:black_concrete
fill 136 266 579 136 307 580 minecraft:black_concrete
setblock 136 266 581 minecraft:white_stained_glass
fill 94 267 581 94 269 581 minecraft:black_concrete
fill 115 267 599 115 307 599 minecraft:black_concrete
fill 128 267 578 128 268 579 minecraft:gray_concrete
fill 128 267 581 128 268 581 minecraft:gray_concrete
fill 129 267 577 129 268 577 minecraft:gray_concrete
fill 130 267 583 130 268 583 minecraft:gray_concrete
fill 131 267 576 132 268 576 minecraft:gray_concrete
fill 133 267 583 133 268 583 minecraft:gray_concrete
setblock 134 267 557 minecraft:white_concrete
fill 134 267 577 134 268 577 minecraft:gray_concrete
fill 134 267 599 134 285 599 minecraft:black_concrete
fill 135 267 579 135 268 581 minecraft:gray_concrete
setblock 136 267 561 minecraft:white_concrete
fill 136 267 581 136 282 581 minecraft:black_concrete
setblock 94 268 564 minecraft:white_stained_glass
setblock 127 268 580 minecraft:gray_concrete
setblock 128 268 577 minecraft:gray_concrete
setblock 128 268 582 minecraft:gray_concrete
setblock 129 268 583 minecraft:gray_concrete
setblock 130 268 576 minecraft:gray_concrete
fill 130 268 584 132 268 584 minecraft:gray_concrete
setblock 133 268 576 minecraft:gray_concrete
fill 134 268 557 134 307 557 minecraft:black_concrete
setblock 134 268 583 minecraft:gray_concrete
setblock 135 268 578 minecraft:gray_concrete
setblock 135 268 582 minecraft:gray_concrete
fill 136 268 561 136 307 561 minecraft:black_concrete
fill 94 269 564 94 284 564 minecraft:black_concrete
setblock 114 269 599 minecraft:white_concrete
fill 130 269 581 130 273 581 minecraft:end_stone
fill 131 269 578 131 272 578 minecraft:end_stone
fill 133 269 580 133 273 580 minecraft:end_stone
setblock 136 269 595 minecraft:white_concrete
fill 94 270 565 94 272 565 minecraft:light_gray_concrete
fill 94 270 581 94 272 581 minecraft:light_gray_concrete
fill 94 270 597 94 272 597 minecraft:light_gray_concrete
fill 98 270 557 98 272 557 minecraft:light_gray_concrete
fill 102 270 557 102 284 557 minecraft:black_concrete
setblock 103 270 557 minecraft:white_concrete
fill 104 270 557 105 272 557 minecraft:black_concrete
fill 108 270 599 108 272 599 minecraft:light_gray_concrete
fill 114 270 557 114 272 557 minecraft:light_gray_concrete
fill 114 270 599 114 307 599 minecraft:black_concrete
fill 124 270 599 124 272 599 minecraft:light_gray_concrete
fill 130 270 557 130 272 557 minecraft:light_gray_concrete
fill 136 270 567 136 272 567 minecraft:light_gray_concrete
fill 136 270 583 136 272 583 minecraft:light_gray_concrete
fill 136 270 595 136 280 595 minecraft:black_concrete
setblock 96 271 557 minecraft:pearlescent_froglight
fill 103 271 557 103 307 557 minecraft:black_concrete
setblock 136 271 582 minecraft:white_concrete
fill 96 272 557 96 307 557 minecraft:black_concrete
setblock 97 272 560 minecraft:light[level=14]
setblock 97 272 568 minecraft:light[level=14]
setblock 97 272 576 minecraft:light[level=14]
setblock 97 272 584 minecraft:light[level=14]
setblock 97 272 592 minecraft:light[level=14]
setblock 105 272 560 minecraft:light[level=14]
setblock 105 272 568 minecraft:light[level=14]
setblock 105 272 576 minecraft:light[level=14]
setblock 105 272 584 minecraft:light[level=14]
setblock 105 272 592 minecraft:light[level=14]
setblock 113 272 560 minecraft:light[level=14]
setblock 113 272 568 minecraft:light[level=14]
setblock 113 272 576 minecraft:light[level=14]
setblock 113 272 584 minecraft:light[level=14]
setblock 113 272 592 minecraft:light[level=14]
setblock 121 272 560 minecraft:light[level=14]
setblock 121 272 568 minecraft:light[level=14]
setblock 121 272 576 minecraft:light[level=14]
setblock 121 272 584 minecraft:light[level=14]
setblock 121 272 592 minecraft:light[level=14]
setblock 129 272 560 minecraft:light[level=14]
setblock 129 272 568 minecraft:light[level=14]
setblock 129 272 576 minecraft:light[level=14]
setblock 129 272 584 minecraft:light[level=14]
setblock 129 272 592 minecraft:light[level=14]
setblock 136 272 573 minecraft:white_concrete
fill 136 272 582 136 296 582 minecraft:black_concrete
fill 94 273 565 94 287 565 minecraft:black_concrete
fill 94 273 581 94 287 581 minecraft:black_concrete
fill 94 273 597 94 287 597 minecraft:black_concrete
fill 98 273 557 98 287 557 minecraft:black_concrete
fill 104 273 557 104 307 557 minecraft:black_concrete
setblock 105 273 557 minecraft:pearlescent_froglight
setblock 106 273 570 minecraft:white_stained_glass
fill 108 273 599 108 287 599 minecraft:black_concrete
fill 114 273 557 114 278 557 minecraft:black_concrete
fill 124 273 599 124 287 599 minecraft:black_concrete
fill 130 273 557 130 287 557 minecraft:black_concrete
fill 136 273 567 136 287 567 minecraft:black_concrete
fill 136 273 573 136 287 573 minecraft:black_concrete
fill 136 273 583 136 282 583 minecraft:black_concrete
setblock 99 274 599 minecraft:white_stained_glass
fill 105 274 557 105 284 557 minecraft:black_concrete
setblock 136 274 577 minecraft:pearlescent_froglight
fill 99 275 599 99 291 599 minecraft:black_concrete
setblock 105 275 599 minecraft:white_concrete
fill 106 275 599 106 307 599 minecraft:black_concrete
setblock 112 275 557 minecraft:white_stained_glass
fill 113 275 557 113 278 557 minecraft:black_concrete
setblock 136 275 563 minecraft:pearlescent_froglight
fill 136 275 577 136 307 577 minecraft:black_concrete
fill 136 275 587 136 281 588 minecraft:black_concrete
setblock 136 275 589 minecraft:white_concrete
setblock 102 276 599 minecraft:white_concrete
fill 105 276 599 105 307 599 minecraft:black_concrete
fill 112 276 557 112 278 557 minecraft:black_concrete
fill 136 276 563 136 307 563 minecraft:black_concrete
fill 136 276 589 136 307 589 minecraft:black_concrete
fill 102 277 599 102 307 599 minecraft:black_concrete
fill 94 278 572 94 292 572 minecraft:black_concrete
setblock 94 278 573 minecraft:white_concrete
setblock 129 278 557 minecraft:pearlescent_froglight
fill 136 278 558 136 307 558 minecraft:black_concrete
setblock 136 278 559 minecraft:white_stained_glass
setblock 136 278 568 minecraft:pearlescent_froglight
fill 136 278 569 136 284 569 minecraft:black_concrete
fill 94 279 573 94 307 573 minecraft:black_concrete
fill 94 279 576 112 279 576 minecraft:end_stone
setblock 94 279 577 minecraft:white_concrete
fill 95 279 570 113 279 575 minecraft:end_stone
fill 95 279 577 113 279 582 minecraft:end_stone
fill 96 279 568 134 279 569 minecraft:end_stone
fill 96 279 583 134 279 584 minecraft:end_stone
fill 97 279 566 133 279 567 minecraft:end_stone
fill 97 279 585 133 279 586 minecraft:end_stone
fill 98 279 564 132 279 565 minecraft:end_stone
fill 98 279 587 132 279 588 minecraft:end_stone
fill 99 279 563 131 279 563 minecraft:end_stone
fill 99 279 589 131 279 589 minecraft:end_stone
fill 100 279 562 130 279 562 minecraft:end_stone
fill 100 279 590 130 279 590 minecraft:end_stone
fill 101 279 561 129 279 561 minecraft:end_stone
fill 101 279 591 129 279 591 minecraft:end_stone
fill 102 279 560 128 279 560 minecraft:end_stone
fill 102 279 592 128 279 592 minecraft:end_stone
fill 103 279 559 127 279 559 minecraft:end_stone
fill 103 279 593 127 279 593 minecraft:end_stone
fill 105 279 558 125 279 558 minecraft:end_stone
fill 105 279 594 125 279 594 minecraft:end_stone
fill 107 279 557 123 279 557 minecraft:end_stone
fill 107 279 595 123 279 595 minecraft:end_stone
fill 109 279 596 121 279 596 minecraft:end_stone
fill 114 279 570 114 279 574 minecraft:end_stone
fill 114 279 578 114 279 582 minecraft:end_stone
fill 115 279 570 135 279 573 minecraft:end_stone
fill 115 279 579 135 279 582 minecraft:end_stone
fill 115 279 597 115 286 597 minecraft:end_stone
fill 116 279 574 135 279 574 minecraft:end_stone
fill 116 279 578 135 279 578 minecraft:end_stone
fill 117 279 575 135 279 575 minecraft:end_stone
fill 117 279 577 135 279 577 minecraft:end_stone
fill 118 279 576 136 279 576 minecraft:end_stone
fill 129 279 557 129 304 557 minecraft:black_concrete
fill 136 279 559 136 285 559 minecraft:black_concrete
fill 136 279 568 136 307 568 minecraft:black_concrete
fill 94 280 576 94 307 577 minecraft:black_concrete
fill 95 280 558 96 280 574 minecraft:end_stone
fill 95 280 575 95 286 575 minecraft:black_concrete
fill 95 280 576 96 280 598 minecraft:end_stone
fill 96 280 575 107 282 575 minecraft:end_stone
fill 97 280 558 97 280 573 minecraft:end_stone
fill 97 280 574 97 286 574 minecraft:black_concrete
fill 97 280 576 97 286 582 minecraft:end_stone
fill 97 280 583 97 286 583 minecraft:black_concrete
fill 97 280 584 101 280 598 minecraft:end_stone
fill 98 280 558 99 280 572 minecraft:end_stone
fill 98 280 573 99 285 573 minecraft:black_concrete
fill 98 280 574 109 282 574 minecraft:end_stone
fill 98 280 576 98 286 581 minecraft:end_stone
fill 98 280 582 98 286 582 minecraft:black_concrete
fill 98 280 583 103 284 583 minecraft:end_stone
fill 99 280 576 99 285 579 minecraft:end_stone
fill 99 280 580 99 285 580 minecraft:black_concrete
fill 99 280 581 104 284 582 minecraft:end_stone
fill 100 280 558 102 280 565 minecraft:end_stone
fill 100 280 566 102 285 566 minecraft:black_concrete
fill 100 280 567 100 285 573 minecraft:end_stone
fill 100 280 576 100 285 578 minecraft:end_stone
fill 100 280 579 100 285 579 minecraft:black_concrete
fill 100 280 580 105 283 580 minecraft:end_stone
fill 101 280 567 105 283 571 minecraft:end_stone
fill 101 280 572 102 284 572 minecraft:black_concrete
fill 101 280 573 110 281 573 minecraft:end_stone
fill 101 280 576 102 284 577 minecraft:end_stone
fill 101 280 578 101 285 578 minecraft:black_concrete
fill 101 280 579 106 283 579 minecraft:end_stone
fill 102 280 578 109 282 578 minecraft:end_stone
fill 102 280 584 102 285 587 minecraft:end_stone
fill 102 280 588 102 286 592 minecraft:black_concrete
fill 102 280 593 108 280 598 minecraft:end_stone
fill 103 280 558 112 280 559 minecraft:end_stone
fill 103 280 560 104 286 560 minecraft:black_concrete
fill 103 280 561 105 285 566 minecraft:end_stone
fill 103 280 572 108 282 572 minecraft:end_stone
fill 103 280 576 109 281 576 minecraft:end_stone
fill 103 280 577 103 284 577 minecraft:black_concrete
fill 103 280 584 115 282 584 minecraft:end_stone
fill 103 280 585 103 285 585 minecraft:black_concrete
fill 103 280 586 107 284 592 minecraft:end_stone
fill 104 280 577 109 282 577 minecraft:end_stone
fill 104 280 583 104 284 583 minecraft:black_concrete
fill 104 280 585 122 283 585 minecraft:end_stone
fill 105 280 560 114 285 560 minecraft:end_stone
fill 105 280 581 105 283 581 minecraft:black_concrete
fill 105 280 582 135 280 583 minecraft:end_stone
fill 106 280 561 107 286 561 minecraft:black_concrete
fill 106 280 562 109 284 566 minecraft:end_stone
fill 106 280 567 107 284 567 minecraft:black_concrete
fill 106 280 568 108 282 571 minecraft:end_stone
fill 106 280 580 106 283 580 minecraft:black_concrete
fill 106 280 581 112 281 581 minecraft:end_stone
fill 107 280 557 111 286 557 minecraft:end_stone
fill 107 280 579 107 282 579 minecraft:black_concrete
fill 107 280 580 111 281 580 minecraft:end_stone
fill 108 280 561 127 285 561 minecraft:end_stone
fill 108 280 567 126 283 567 minecraft:end_stone
fill 108 280 575 108 282 575 minecraft:black_concrete
fill 108 280 579 110 281 579 minecraft:end_stone
fill 108 280 586 108 284 590 minecraft:black_concrete
fill 108 280 591 114 285 592 minecraft:end_stone
fill 109 280 568 109 283 568 minecraft:black_concrete
fill 109 280 569 112 281 571 minecraft:end_stone
fill 109 280 572 109 282 572 minecraft:black_concrete
fill 109 280 575 109 282 575 minecraft:end_stone
fill 109 280 586 112 283 590 minecraft:end_stone
fill 109 280 593 109 286 594 minecraft:black_concrete
fill 109 280 595 109 280 598 minecraft:end_stone
fill 110 280 562 115 284 562 minecraft:end_stone
fill 110 280 563 110 284 563 minecraft:black_concrete
fill 110 280 564 110 283 566 minecraft:end_stone
fill 110 280 568 113 282 568 minecraft:end_stone
fill 110 280 572 111 281 572 minecraft:end_stone
fill 110 280 574 111 281 578 minecraft:light_gray_concrete
fill 110 280 593 115 286 595 minecraft:end_stone
fill 110 280 596 110 286 596 minecraft:black_concrete
fill 110 280 597 114 280 598 minecraft:end_stone
fill 111 280 563 121 284 563 minecraft:end_stone
fill 111 280 564 111 284 564 minecraft:black_concrete
fill 111 280 565 111 283 566 minecraft:end_stone
fill 111 280 573 113 281 573 minecraft:light_gray_concrete
fill 111 280 579 113 281 579 minecraft:light_gray_concrete
fill 111 280 596 118 286 596 minecraft:end_stone
fill 112 280 557 112 307 557 minecraft:black_concrete
fill 112 280 564 116 284 564 minecraft:end_stone
fill 112 280 565 112 284 565 minecraft:black_concrete
fill 112 280 566 112 283 566 minecraft:end_stone
fill 112 280 572 118 281 572 minecraft:light_gray_concrete
fill 112 280 574 112 281 574 minecraft:light_gray_concrete
fill 112 280 575 112 280 577 minecraft:pearlescent_froglight
fill 112 280 578 112 281 578 minecraft:light_gray_concrete
fill 112 280 580 118 281 580 minecraft:light_gray_concrete
fill 113 280 557 123 286 557 minecraft:end_stone
fill 113 280 558 113 286 558 minecraft:black_concrete
fill 113 280 559 113 286 559 minecraft:end_stone
fill 113 280 565 116 283 565 minecraft:end_stone
fill 113 280 566 113 283 566 minecraft:black_concrete
fill 113 280 569 125 281 570 minecraft:end_stone
fill 113 280 571 117 281 571 minecraft:light_gray_concrete
fill 113 280 574 113 280 575 minecraft:pearlescent_froglight
fill 113 280 577 113 280 578 minecraft:pearlescent_froglight
fill 113 280 581 117 281 581 minecraft:light_gray_concrete
fill 113 280 586 116 283 586 minecraft:end_stone
fill 113 280 587 113 283 588 minecraft:black_concrete
fill 113 280 589 113 284 590 minecraft:end_stone
fill 114 280 558 120 286 558 minecraft:end_stone
fill 114 280 559 114 286 559 minecraft:black_concrete
fill 114 280 566 121 283 566 minecraft:end_stone
fill 114 280 568 114 282 568 minecraft:black_concrete
fill 114 280 573 114 280 574 minecraft:pearlescent_froglight
fill 114 280 578 114 280 579 minecraft:pearlescent_froglight
fill 114 280 587 117 283 589 minecraft:end_stone
fill 114 280 590 114 285 590 minecraft:black_concrete
fill 115 280 559 120 286 559 minecraft:end_stone
fill 115 280 560 115 285 560 minecraft:black_concrete
fill 115 280 568 135 280 568 minecraft:end_stone
fill 115 280 573 116 280 573 minecraft:pearlescent_froglight
fill 115 280 579 116 280 579 minecraft:pearlescent_froglight
fill 115 280 590 122 284 591 minecraft:end_stone
fill 115 280 592 115 285 592 minecraft:black_concrete
fill 115 280 598 135 280 598 minecraft:end_stone
fill 116 280 560 127 285 560 minecraft:end_stone
fill 116 280 562 116 285 562 minecraft:black_concrete
fill 116 280 574 117 280 574 minecraft:pearlescent_froglight
fill 116 280 578 117 280 578 minecraft:pearlescent_froglight
fill 116 280 584 116 282 584 minecraft:black_concrete
fill 116 280 592 125 285 592 minecraft:end_stone
fill 116 280 593 116 286 593 minecraft:black_concrete
fill 116 280 594 116 286 595 minecraft:end_stone
fill 116 280 597 135 280 597 minecraft:end_stone
fill 117 280 562 121 285 562 minecraft:end_stone
fill 117 280 564 117 283 565 minecraft:black_concrete
fill 117 280 573 119 281 573 minecraft:light_gray_concrete
fill 117 280 575 118 280 575 minecraft:pearlescent_froglight
fill 117 280 577 118 280 577 minecraft:pearlescent_froglight
fill 117 280 579 119 281 579 minecraft:light_gray_concrete
fill 117 280 584 120 282 584 minecraft:end_stone
fill 117 280 586 117 283 586 minecraft:black_concrete
fill 117 280 593 135 280 593 minecraft:end_stone
fill 117 280 594 117 286 594 minecraft:black_concrete
fill 117 280 595 117 286 595 minecraft:end_stone
fill 118 280 564 121 284 565 minecraft:end_stone
fill 118 280 571 124 281 571 minecraft:end_stone
fill 118 280 574 120 281 574 minecraft:light_gray_concrete
setblock 118 280 576 minecraft:pearlescent_froglight
fill 118 280 578 120 281 578 minecraft:light_gray_concrete
fill 118 280 581 135 281 581 minecraft:end_stone
fill 118 280 586 127 283 586 minecraft:end_stone
fill 118 280 587 118 284 587 minecraft:black_concrete
fill 118 280 588 118 284 589 minecraft:end_stone
fill 118 280 594 135 280 594 minecraft:end_stone
fill 118 280 595 118 286 595 minecraft:black_concrete
fill 119 280 572 123 281 572 minecraft:end_stone
fill 119 280 575 120 281 577 minecraft:light_gray_concrete
fill 119 280 580 120 281 580 minecraft:end_stone
fill 119 280 587 135 280 587 minecraft:end_stone
fill 119 280 588 119 284 588 minecraft:black_concrete
fill 119 280 589 119 284 589 minecraft:end_stone
fill 119 280 595 135 280 595 minecraft:end_stone
fill 119 280 596 119 286 596 minecraft:black_concrete
fill 120 280 573 122 281 573 minecraft:end_stone
fill 120 280 579 130 281 579 minecraft:end_stone
fill 120 280 588 135 280 588 minecraft:end_stone
fill 120 280 589 120 284 589 minecraft:black_concrete
fill 120 280 596 135 280 596 minecraft:end_stone
fill 121 280 558 121 286 559 minecraft:black_concrete
fill 121 280 574 121 281 578 minecraft:end_stone
fill 121 280 580 121 282 580 minecraft:black_concrete
fill 121 280 584 121 283 584 minecraft:black_concrete
fill 121 280 589 135 280 589 minecraft:end_stone
fill 122 280 558 135 280 559 minecraft:end_stone
fill 122 280 562 122 284 566 minecraft:black_concrete
fill 122 280 574 126 282 576 minecraft:end_stone
fill 122 280 577 122 282 577 minecraft:black_concrete
fill 122 280 578 132 282 578 minecraft:end_stone
fill 122 280 580 127 282 580 minecraft:end_stone
fill 122 280 584 135 280 584 minecraft:end_stone
fill 123 280 562 127 284 566 minecraft:end_stone
fill 123 280 573 123 282 573 minecraft:black_concrete
fill 123 280 577 134 282 577 minecraft:end_stone
fill 123 280 585 124 284 585 minecraft:black_concrete
fill 123 280 590 135 280 590 minecraft:end_stone
fill 123 280 591 124 286 591 minecraft:black_concrete
fill 124 280 572 124 283 572 minecraft:black_concrete
fill 124 280 573 129 283 573 minecraft:end_stone
fill 125 280 571 125 283 571 minecraft:black_concrete
fill 125 280 572 130 283 572 minecraft:end_stone
fill 125 280 585 135 280 585 minecraft:end_stone
fill 125 280 591 135 280 591 minecraft:end_stone
fill 126 280 569 126 284 569 minecraft:black_concrete
fill 126 280 570 131 284 571 minecraft:end_stone
fill 126 280 592 127 286 592 minecraft:black_concrete
fill 127 280 567 127 285 567 minecraft:black_concrete
fill 127 280 569 132 284 569 minecraft:end_stone
fill 127 280 574 128 284 574 minecraft:end_stone
fill 127 280 575 127 284 575 minecraft:black_concrete
fill 127 280 576 135 284 576 minecraft:end_stone
fill 128 280 560 128 286 564 minecraft:black_concrete
fill 128 280 565 135 280 567 minecraft:end_stone
fill 128 280 575 135 284 575 minecraft:end_stone
fill 128 280 580 129 284 580 minecraft:black_concrete
fill 128 280 586 130 285 586 minecraft:black_concrete
fill 128 280 592 135 280 592 minecraft:end_stone
fill 129 280 560 135 280 564 minecraft:end_stone
fill 129 280 574 129 285 574 minecraft:black_concrete
fill 130 280 573 130 285 573 minecraft:black_concrete
fill 130 280 574 135 285 574 minecraft:end_stone
fill 130 280 580 135 285 580 minecraft:end_stone
fill 131 280 572 131 285 572 minecraft:black_concrete
fill 131 280 573 135 285 573 minecraft:end_stone
fill 131 280 579 132 285 579 minecraft:black_concrete
fill 131 280 586 135 280 586 minecraft:end_stone
fill 132 280 570 132 286 570 minecraft:black_concrete
fill 132 280 571 135 286 572 minecraft:end_stone
fill 133 280 569 133 286 569 minecraft:black_concrete
fill 133 280 570 135 286 570 minecraft:end_stone
fill 133 280 578 133 286 578 minecraft:black_concrete
fill 133 280 579 135 286 579 minecraft:end_stone
fill 134 280 569 135 280 569 minecraft:end_stone
fill 134 280 578 135 286 578 minecraft:end_stone
fill 135 280 577 135 286 577 minecraft:black_concrete
fill 136 280 576 136 307 576 minecraft:black_concrete
setblock 94 281 562 minecraft:white_concrete
fill 94 281 563 94 286 563 minecraft:black_concrete
fill 95 281 570 96 286 574 minecraft:end_stone
fill 95 281 576 96 286 582 minecraft:end_stone
fill 96 281 568 99 286 569 minecraft:end_stone
fill 96 281 583 96 286 584 minecraft:end_stone
fill 97 281 566 99 286 567 minecraft:end_stone
fill 97 281 570 97 286 573 minecraft:end_stone
fill 97 281 584 101 285 586 minecraft:end_stone
fill 98 281 564 102 286 565 minecraft:end_stone
fill 98 281 570 99 285 572 minecraft:end_stone
fill 98 281 587 101 286 588 minecraft:end_stone
fill 99 281 563 102 286 563 minecraft:end_stone
fill 99 281 589 101 286 589 minecraft:end_stone
fill 100 281 562 102 286 562 minecraft:end_stone
fill 100 281 590 101 286 590 minecraft:end_stone
fill 101 281 561 102 286 561 minecraft:end_stone
fill 101 281 591 101 286 591 minecraft:end_stone
fill 102 281 560 102 286 560 minecraft:end_stone
fill 103 281 559 112 286 559 minecraft:end_stone
fill 103 281 593 108 286 593 minecraft:end_stone
fill 105 281 558 112 286 558 minecraft:end_stone
fill 105 281 582 134 281 583 minecraft:end_stone
fill 105 281 594 108 286 594 minecraft:end_stone
fill 107 281 595 109 286 595 minecraft:end_stone
fill 109 281 596 109 286 596 minecraft:end_stone
fill 115 281 568 134 282 568 minecraft:end_stone
fill 116 281 599 117 281 599 minecraft:white_concrete
fill 117 281 593 127 286 593 minecraft:end_stone
fill 118 281 594 125 286 594 minecraft:end_stone
fill 118 281 599 120 307 599 minecraft:black_concrete
fill 119 281 587 132 284 587 minecraft:end_stone
fill 119 281 595 123 286 595 minecraft:end_stone
fill 120 281 588 132 284 588 minecraft:end_stone
fill 120 281 596 121 286 596 minecraft:end_stone
fill 121 281 589 131 285 589 minecraft:end_stone
fill 122 281 558 125 286 559 minecraft:end_stone
fill 122 281 584 134 283 584 minecraft:end_stone
fill 123 281 590 130 285 590 minecraft:end_stone
fill 125 281 585 133 284 585 minecraft:end_stone
fill 125 281 591 129 286 591 minecraft:end_stone
fill 126 281 559 127 286 559 minecraft:end_stone
setblock 127 281 557 minecraft:pearlescent_froglight
fill 128 281 565 132 285 567 minecraft:end_stone
fill 128 281 592 128 286 592 minecraft:end_stone
fill 129 281 561 129 286 564 minecraft:end_stone
fill 130 281 562 130 286 564 minecraft:end_stone
fill 131 281 563 131 286 564 minecraft:end_stone
fill 131 281 586 133 286 586 minecraft:end_stone
fill 132 281 564 132 286 564 minecraft:end_stone
fill 133 281 566 133 286 567 minecraft:end_stone
fill 134 281 569 134 286 569 minecraft:end_stone
fill 135 281 582 135 286 582 minecraft:end_stone
setblock 136 281 560 minecraft:pearlescent_froglight
setblock 136 281 595 minecraft:white_concrete
fill 94 282 562 94 307 562 minecraft:black_concrete
setblock 94 282 585 minecraft:pearlescent_froglight
fill 94 282 588 94 307 588 minecraft:black_concrete
setblock 94 282 589 minecraft:white_stained_glass
fill 94 282 590 94 307 590 minecraft:black_concrete
setblock 94 282 593 minecraft:white_stained_glass
fill 101 282 573 109 282 573 minecraft:end_stone
fill 103 282 576 108 282 576 minecraft:end_stone
fill 105 282 582 114 282 583 minecraft:end_stone
fill 106 282 581 111 282 581 minecraft:end_stone
fill 107 282 580 110 282 580 minecraft:end_stone
fill 108 282 579 109 282 579 minecraft:end_stone
fill 109 282 569 111 282 571 minecraft:end_stone
setblock 110 282 572 minecraft:end_stone
fill 112 282 569 114 282 570 minecraft:end_stone
fill 115 282 569 125 282 569 minecraft:end_stone
fill 115 282 583 134 282 583 minecraft:end_stone
fill 116 282 570 125 282 570 minecraft:end_stone
fill 116 282 582 134 282 582 minecraft:end_stone
fill 116 282 599 117 288 599 minecraft:black_concrete
fill 119 282 571 124 282 571 minecraft:end_stone
fill 119 282 581 135 282 581 minecraft:end_stone
fill 120 282 572 123 282 572 minecraft:end_stone
setblock 120 282 580 minecraft:end_stone
fill 121 282 573 121 282 575 minecraft:end_stone
fill 121 282 577 121 282 579 minecraft:end_stone
setblock 122 282 573 minecraft:end_stone
fill 122 282 579 130 282 579 minecraft:end_stone
setblock 125 282 599 minecraft:white_concrete
fill 126 282 599 126 307 599 minecraft:black_concrete
fill 127 282 557 127 307 557 minecraft:black_concrete
setblock 128 282 599 minecraft:white_stained_glass
fill 129 282 599 129 307 599 minecraft:black_concrete
fill 136 282 560 136 299 560 minecraft:black_concrete
fill 136 282 587 136 307 587 minecraft:black_concrete
setblock 136 282 588 minecraft:white_concrete
fill 136 282 595 136 307 595 minecraft:black_concrete
setblock 94 283 579 minecraft:white_concrete
fill 94 283 585 94 307 585 minecraft:black_concrete
fill 94 283 589 94 306 589 minecraft:black_concrete
fill 94 283 593 94 307 593 minecraft:black_concrete
fill 96 283 575 106 283 575 minecraft:end_stone
fill 98 283 574 106 283 574 minecraft:end_stone
fill 101 283 573 106 283 573 minecraft:end_stone
fill 102 283 578 106 283 578 minecraft:end_stone
fill 103 283 572 107 283 572 minecraft:end_stone
fill 103 283 576 106 283 576 minecraft:end_stone
fill 103 283 584 111 283 584 minecraft:end_stone
fill 104 283 577 106 283 577 minecraft:end_stone
fill 105 283 582 108 283 583 minecraft:end_stone
fill 106 283 568 107 283 571 minecraft:end_stone
fill 106 283 581 107 283 581 minecraft:end_stone
setblock 107 283 580 minecraft:end_stone
fill 108 283 568 108 283 570 minecraft:end_stone
setblock 109 283 569 minecraft:end_stone
setblock 109 283 583 minecraft:end_stone
fill 110 283 568 111 283 568 minecraft:end_stone
fill 119 283 568 134 283 568 minecraft:end_stone
fill 119 283 584 120 283 584 minecraft:end_stone
fill 121 283 569 125 283 569 minecraft:end_stone
fill 121 283 583 134 283 583 minecraft:end_stone
fill 122 283 570 125 283 570 minecraft:end_stone
fill 122 283 582 134 283 582 minecraft:end_stone
fill 122 283 599 122 288 599 minecraft:black_concrete
fill 123 283 571 123 283 572 minecraft:end_stone
fill 123 283 580 127 283 581 minecraft:end_stone
setblock 123 283 599 minecraft:white_concrete
setblock 124 283 571 minecraft:end_stone
fill 124 283 574 126 283 579 minecraft:end_stone
fill 125 283 599 125 307 599 minecraft:black_concrete
fill 127 283 577 130 284 579 minecraft:end_stone
fill 128 283 581 135 284 581 minecraft:end_stone
fill 128 283 599 128 307 599 minecraft:black_concrete
fill 131 283 577 132 285 578 minecraft:end_stone
setblock 132 283 557 minecraft:white_concrete
fill 133 283 577 134 286 577 minecraft:end_stone
setblock 136 283 581 minecraft:pearlescent_froglight
setblock 136 283 583 minecraft:white_concrete
fill 136 283 588 136 307 588 minecraft:black_concrete
fill 94 284 579 94 307 579 minecraft:black_concrete
fill 96 284 575 103 284 575 minecraft:end_stone
fill 98 284 574 103 284 574 minecraft:end_stone
fill 100 284 580 104 284 580 minecraft:end_stone
fill 101 284 567 104 284 571 minecraft:end_stone
fill 101 284 573 104 284 573 minecraft:end_stone
fill 101 284 579 104 284 579 minecraft:end_stone
fill 102 284 578 103 284 578 minecraft:end_stone
fill 103 284 572 104 284 572 minecraft:end_stone
setblock 103 284 576 minecraft:end_stone
fill 103 284 584 106 284 584 minecraft:end_stone
fill 104 284 574 108 285 574 minecraft:gray_concrete
fill 104 284 585 108 284 585 minecraft:end_stone
fill 105 284 567 105 284 570 minecraft:end_stone
fill 105 284 571 109 285 573 minecraft:gray_concrete
fill 105 284 582 105 284 583 minecraft:end_stone
fill 106 284 568 106 284 569 minecraft:end_stone
fill 106 284 570 110 285 570 minecraft:gray_concrete
setblock 106 284 583 minecraft:end_stone
fill 107 284 568 110 285 569 minecraft:gray_concrete
setblock 108 284 567 minecraft:end_stone
fill 109 284 567 109 285 567 minecraft:gray_concrete
fill 109 284 586 109 284 590 minecraft:end_stone
fill 110 284 564 110 284 565 minecraft:end_stone
fill 110 284 571 110 285 572 minecraft:gray_concrete
fill 110 284 587 112 284 590 minecraft:end_stone
setblock 111 284 565 minecraft:end_stone
setblock 113 284 588 minecraft:black_concrete
fill 114 284 588 117 284 589 minecraft:end_stone
setblock 117 284 564 minecraft:black_concrete
setblock 121 284 566 minecraft:end_stone
fill 121 284 586 127 284 586 minecraft:end_stone
fill 122 284 567 126 284 567 minecraft:end_stone
setblock 122 284 585 minecraft:end_stone
fill 123 284 599 123 291 599 minecraft:black_concrete
fill 124 284 568 125 284 569 minecraft:end_stone
fill 124 284 583 134 284 584 minecraft:end_stone
setblock 125 284 570 minecraft:end_stone
fill 125 284 582 134 284 582 minecraft:end_stone
fill 126 284 568 134 284 568 minecraft:end_stone
fill 126 284 572 129 284 573 minecraft:end_stone
fill 126 284 579 126 284 581 minecraft:end_stone
fill 127 284 580 127 284 581 minecraft:end_stone
setblock 128 284 557 minecraft:pearlescent_froglight
fill 130 284 572 130 285 572 minecraft:end_stone
fill 132 284 557 132 285 557 minecraft:black_concrete
fill 136 284 581 136 287 581 minecraft:black_concrete
fill 136 284 583 136 287 583 minecraft:black_concrete
setblock 136 284 594 minecraft:white_stained_glass
setblock 94 285 564 minecraft:white_stained_glass
fill 96 285 575 101 285 575 minecraft:end_stone
fill 98 285 574 101 285 574 minecraft:end_stone
fill 98 285 583 102 285 583 minecraft:end_stone
fill 99 285 581 101 285 582 minecraft:end_stone
fill 100 285 580 101 285 580 minecraft:end_stone
fill 101 285 567 101 285 571 minecraft:end_stone
setblock 101 285 572 minecraft:black_concrete
setblock 101 285 573 minecraft:end_stone
setblock 101 285 577 minecraft:end_stone
setblock 101 285 579 minecraft:end_stone
setblock 102 285 557 minecraft:pearlescent_froglight
fill 102 285 567 102 285 570 minecraft:end_stone
fill 102 285 571 104 285 573 minecraft:gray_concrete
setblock 102 285 582 minecraft:end_stone
fill 103 285 567 103 285 568 minecraft:end_stone
fill 103 285 569 105 285 570 minecraft:gray_concrete
setblock 103 285 574 minecraft:gray_concrete
setblock 103 285 584 minecraft:end_stone
fill 103 285 586 105 285 592 minecraft:end_stone
setblock 104 285 567 minecraft:end_stone
fill 104 285 568 106 285 568 minecraft:gray_concrete
setblock 104 285 585 minecraft:end_stone
setblock 105 285 557 minecraft:pearlescent_froglight
fill 105 285 567 108 285 567 minecraft:gray_concrete
fill 105 285 575 106 285 575 minecraft:gray_concrete
fill 106 285 562 106 285 565 minecraft:end_stone
fill 106 285 566 109 285 566 minecraft:gray_concrete
setblock 106 285 569 minecraft:gray_concrete
fill 106 285 587 106 285 592 minecraft:end_stone
fill 107 285 562 107 285 564 minecraft:end_stone
fill 107 285 565 108 285 565 minecraft:gray_concrete
fill 107 285 588 107 285 592 minecraft:end_stone
fill 108 285 562 109 285 563 minecraft:end_stone
fill 108 285 589 108 285 590 minecraft:black_concrete
setblock 109 285 574 minecraft:gray_concrete
fill 109 285 589 109 285 590 minecraft:end_stone
fill 110 285 562 114 285 562 minecraft:end_stone
setblock 110 285 567 minecraft:gray_concrete
setblock 110 285 573 minecraft:gray_concrete
fill 110 285 590 113 285 590 minecraft:end_stone
fill 111 285 569 111 285 571 minecraft:gray_concrete
fill 115 285 591 122 285 591 minecraft:end_stone
fill 116 285 590 122 285 590 minecraft:end_stone
setblock 121 285 563 minecraft:end_stone
fill 122 285 562 122 285 563 minecraft:black_concrete
fill 123 285 562 127 285 564 minecraft:end_stone
fill 123 285 588 132 285 588 minecraft:end_stone
fill 124 285 565 127 285 565 minecraft:end_stone
fill 124 285 587 132 285 587 minecraft:end_stone
fill 125 285 566 127 285 566 minecraft:end_stone
fill 125 285 586 127 285 586 minecraft:end_stone
setblock 126 285 557 minecraft:pearlescent_froglight
setblock 126 285 567 minecraft:end_stone
setblock 126 285 570 minecraft:light_gray_concrete
fill 126 285 585 133 285 585 minecraft:end_stone
fill 127 285 568 134 285 568 minecraft:end_stone
fill 127 285 584 134 285 584 minecraft:end_stone
fill 128 285 557 128 307 557 minecraft:black_concrete
fill 128 285 569 131 285 570 minecraft:end_stone
fill 128 285 582 134 285 583 minecraft:end_stone
fill 129 285 571 129 285 573 minecraft:end_stone
fill 129 285 575 135 285 575 minecraft:end_stone
fill 129 285 577 130 285 579 minecraft:end_stone
setblock 129 285 580 minecraft:black_concrete
fill 129 285 581 135 285 581 minecraft:end_stone
fill 130 285 571 131 285 571 minecraft:end_stone
fill 130 285 576 135 285 576 minecraft:end_stone
fill 132 285 569 132 286 569 minecraft:end_stone
setblock 136 285 569 minecraft:white_stained_glass
fill 136 285 594 136 290 594 minecraft:black_concrete
fill 94 286 564 94 307 564 minecraft:black_concrete
setblock 94 286 582 minecraft:white_concrete
setblock 94 286 584 minecraft:pearlescent_froglight
fill 96 286 575 98 286 575 minecraft:end_stone
fill 97 286 584 100 286 586 minecraft:end_stone
fill 98 286 570 98 286 572 minecraft:end_stone
setblock 98 286 573 minecraft:black_concrete
setblock 98 286 574 minecraft:end_stone
fill 98 286 583 99 286 583 minecraft:end_stone
fill 99 286 570 99 286 571 minecraft:end_stone
fill 99 286 581 99 286 582 minecraft:end_stone
fill 100 286 566 101 286 566 minecraft:black_concrete
fill 100 286 567 100 286 568 minecraft:end_stone
setblock 101 286 586 minecraft:end_stone
fill 102 286 557 102 288 557 minecraft:black_concrete
setblock 102 286 587 minecraft:end_stone
fill 103 286 561 103 286 564 minecraft:end_stone
fill 103 286 588 103 286 592 minecraft:end_stone
fill 104 286 561 104 286 563 minecraft:end_stone
fill 104 286 589 104 286 592 minecraft:end_stone
fill 105 286 557 105 307 557 minecraft:black_concrete
fill 105 286 560 105 286 562 minecraft:end_stone
fill 105 286 569 105 287 569 minecraft:end_stone
fill 105 286 571 105 290 571 minecraft:end_stone
fill 105 286 590 105 286 592 minecraft:end_stone
fill 106 286 560 110 286 560 minecraft:end_stone
fill 106 286 591 107 286 592 minecraft:end_stone
fill 107 286 569 107 289 569 minecraft:end_stone
fill 108 286 592 110 286 592 minecraft:end_stone
fill 120 286 560 127 286 560 minecraft:end_stone
fill 120 286 592 125 286 592 minecraft:end_stone
fill 123 286 561 127 286 561 minecraft:end_stone
fill 125 286 562 127 286 562 minecraft:end_stone
fill 125 286 590 130 286 590 minecraft:end_stone
fill 126 286 557 126 307 557 minecraft:black_concrete
fill 126 286 563 127 286 563 minecraft:end_stone
fill 126 286 589 131 286 589 minecraft:end_stone
setblock 127 286 564 minecraft:end_stone
fill 127 286 588 132 286 588 minecraft:end_stone
fill 128 286 565 132 286 565 minecraft:end_stone
fill 128 286 587 132 286 587 minecraft:end_stone
fill 129 286 566 132 286 566 minecraft:end_stone
fill 129 286 586 130 286 586 minecraft:black_concrete
fill 130 286 567 132 286 568 minecraft:end_stone
fill 130 286 584 133 286 585 minecraft:end_stone
fill 131 286 569 131 286 571 minecraft:end_stone
fill 131 286 581 134 286 583 minecraft:end_stone
setblock 132 286 557 minecraft:pearlescent_froglight
fill 132 286 573 132 286 578 minecraft:end_stone
setblock 132 286 579 minecraft:black_concrete
fill 132 286 580 135 286 580 minecraft:end_stone
fill 133 286 568 134 286 568 minecraft:end_stone
fill 133 286 573 135 286 576 minecraft:end_stone
setblock 134 286 584 minecraft:end_stone
setblock 134 286 599 minecraft:pearlescent_froglight
setblock 135 286 581 minecraft:end_stone
setblock 136 286 559 minecraft:pearlescent_froglight
fill 136 286 569 136 307 569 minecraft:black_concrete
setblock 94 287 563 minecraft:white_stained_glass
fill 94 287 582 94 296 582 minecraft:black_concrete
fill 94 287 584 94 290 584 minecraft:black_concrete
fill 107 287 557 111 300 557 minecraft:black_concrete
fill 113 287 557 123 287 557 minecraft:black_concrete
fill 132 287 557 132 291 557 minecraft:black_concrete
fill 134 287 599 134 307 599 minecraft:black_concrete
fill 136 287 559 136 307 559 minecraft:black_concrete
setblock 136 287 598 minecraft:white_stained_glass
fill 94 288 563 94 307 563 minecraft:black_concrete
fill 94 288 565 94 290 565 minecraft:light_gray_concrete
fill 94 288 581 94 290 581 minecraft:light_gray_concrete
fill 94 288 597 94 290 597 minecraft:light_gray_concrete
setblock 97 288 560 minecraft:light[level=14]
setblock 97 288 568 minecraft:light[level=14]
setblock 97 288 576 minecraft:light[level=14]
setblock 97 288 584 minecraft:light[level=14]
setblock 97 288 592 minecraft:light[level=14]
fill 98 288 557 98 290 557 minecraft:light_gray_concrete
setblock 105 288 560 minecraft:light[level=14]
setblock 105 288 568 minecraft:light[level=14]
setblock 105 288 576 minecraft:light[level=14]
setblock 105 288 584 minecraft:light[level=14]
setblock 105 288 592 minecraft:light[level=14]
fill 108 288 599 108 290 599 minecraft:light_gray_concrete
fill 113 288 557 113 307 557 minecraft:black_concrete
setblock 113 288 560 minecraft:light[level=14]
setblock 113 288 568 minecraft:light[level=14]
setblock 113 288 576 minecraft:light[level=14]
setblock 113 288 584 minecraft:light[level=14]
setblock 113 288 592 minecraft:light[level=14]
fill 114 288 557 114 290 557 minecraft:light_gray_concrete
fill 115 288 557 123 293 557 minecraft:black_concrete
setblock 121 288 560 minecraft:light[level=14]
setblock 121 288 568 minecraft:light[level=14]
setblock 121 288 576 minecraft:light[level=14]
setblock 121 288 584 minecraft:light[level=14]
setblock 121 288 592 minecraft:light[level=14]
fill 124 288 599 124 290 599 minecraft:light_gray_concrete
setblock 129 288 560 minecraft:light[level=14]
setblock 129 288 568 minecraft:light[level=14]
setblock 129 288 576 minecraft:light[level=14]
setblock 129 288 584 minecraft:light[level=14]
setblock 129 288 592 minecraft:light[level=14]
fill 130 288 557 130 290 557 minecraft:light_gray_concrete
fill 136 288 567 136 290 567 minecraft:light_gray_concrete
setblock 136 288 573 minecraft:white_concrete
setblock 136 288 581 minecraft:white_concrete
fill 136 288 583 136 290 583 minecraft:light_gray_concrete
fill 136 288 598 136 307 598 minecraft:black_concrete
setblock 94 289 598 minecraft:white_stained_glass
setblock 102 289 557 minecraft:pearlescent_froglight
setblock 104 289 599 minecraft:white_concrete
setblock 116 289 599 minecraft:white_stained_glass
fill 117 289 599 117 307 599 minecraft:black_concrete
setblock 122 289 599 minecraft:pearlescent_froglight
fill 126 289 569 127 290 569 minecraft:light_gray_concrete
setblock 131 289 599 minecraft:white_stained_glass
fill 136 289 573 136 307 573 minecraft:black_concrete
fill 136 289 581 136 307 581 minecraft:black_concrete
fill 94 290 598 94 307 598 minecraft:black_concrete
fill 102 290 557 102 307 557 minecraft:black_concrete
fill 104 290 599 104 307 599 minecraft:black_concrete
fill 116 290 599 116 307 599 minecraft:black_concrete
fill 122 290 599 122 297 599 minecraft:black_concrete
setblock 125 290 557 minecraft:white_concrete
setblock 127 290 599 minecraft:pearlescent_froglight
fill 131 290 599 131 307 599 minecraft:black_concrete
setblock 136 290 593 minecraft:pearlescent_froglight
fill 94 291 565 94 296 565 minecraft:black_concrete
fill 94 291 581 94 296 581 minecraft:black_concrete
setblock 94 291 584 minecraft:white_stained_glass
setblock 94 291 594 minecraft:pearlescent_froglight
fill 94 291 595 94 307 595 minecraft:black_concrete
setblock 94 291 597 minecraft:black_concrete
fill 98 291 557 98 296 557 minecraft:black_concrete
fill 108 291 599 108 296 599 minecraft:black_concrete
fill 114 291 557 114 296 557 minecraft:black_concrete
fill 124 291 599 124 296 599 minecraft:black_concrete
fill 125 291 557 125 301 557 minecraft:black_concrete
fill 127 291 599 127 307 599 minecraft:black_concrete
fill 130 291 557 130 296 557 minecraft:black_concrete
fill 136 291 567 136 296 567 minecraft:black_concrete
fill 136 291 583 136 296 583 minecraft:black_concrete
fill 136 291 593 136 303 593 minecraft:black_concrete
fill 136 291 594 136 292 594 minecraft:white_stained_glass
fill 94 292 584 94 307 584 minecraft:black_concrete
fill 94 292 594 94 307 594 minecraft:black_concrete
setblock 94 292 597 minecraft:white_concrete
setblock 99 292 599 minecraft:pearlescent_froglight
setblock 123 292 599 minecraft:white_concrete
setblock 132 292 557 minecraft:white_stained_glass
setblock 136 292 592 minecraft:white_stained_glass
setblock 94 293 572 minecraft:pearlescent_froglight
fill 94 293 597 94 296 597 minecraft:black_concrete
setblock 97 293 599 minecraft:pearlescent_froglight
fill 99 293 599 99 307 599 minecraft:black_concrete
setblock 107 293 599 minecraft:pearlescent_froglight
fill 123 293 599 123 307 599 minecraft:black_concrete
fill 132 293 557 132 307 557 minecraft:black_concrete
fill 136 293 592 136 307 592 minecraft:black_concrete
fill 136 293 594 136 307 594 minecraft:black_concrete
fill 94 294 572 94 307 572 minecraft:black_concrete
fill 97 294 599 97 307 599 minecraft:black_concrete
fill 107 294 599 107 301 599 minecraft:black_concrete
setblock 115 294 557 minecraft:white_concrete
fill 116 294 557 123 306 557 minecraft:black_concrete
fill 115 295 557 115 307 557 minecraft:black_concrete
setblock 96 296 599 minecraft:white_stained_glass
setblock 97 296 560 minecraft:light[level=14]
setblock 97 296 568 minecraft:light[level=14]
setblock 97 296 576 minecraft:light[level=14]
setblock 97 296 584 minecraft:light[level=14]
setblock 97 296 592 minecraft:light[level=14]
setblock 105 296 560 minecraft:light[level=14]
setblock 105 296 568 minecraft:light[level=14]
setblock 105 296 576 minecraft:light[level=14]
setblock 105 296 584 minecraft:light[level=14]
setblock 105 296 592 minecraft:light[level=14]
setblock 106 296 557 minecraft:pearlescent_froglight
setblock 113 296 560 minecraft:light[level=14]
setblock 113 296 568 minecraft:light[level=14]
setblock 113 296 576 minecraft:light[level=14]
setblock 113 296 584 minecraft:light[level=14]
setblock 113 296 592 minecraft:light[level=14]
setblock 121 296 560 minecraft:light[level=14]
setblock 121 296 568 minecraft:light[level=14]
setblock 121 296 576 minecraft:light[level=14]
setblock 121 296 584 minecraft:light[level=14]
setblock 121 296 592 minecraft:light[level=14]
setblock 129 296 560 minecraft:light[level=14]
setblock 129 296 568 minecraft:light[level=14]
setblock 129 296 576 minecraft:light[level=14]
setblock 129 296 584 minecraft:light[level=14]
setblock 129 296 592 minecraft:light[level=14]
fill 94 297 565 94 299 565 minecraft:light_gray_concrete
fill 94 297 581 94 299 581 minecraft:light_gray_concrete
setblock 94 297 582 minecraft:white_concrete
fill 94 297 597 94 299 597 minecraft:light_gray_concrete
fill 96 297 599 96 307 599 minecraft:black_concrete
fill 98 297 557 98 299 557 minecraft:light_gray_concrete
fill 106 297 557 106 307 557 minecraft:black_concrete
fill 108 297 599 108 299 599 minecraft:light_gray_concrete
fill 114 297 557 114 299 557 minecraft:light_gray_concrete
fill 124 297 599 124 299 599 minecraft:light_gray_concrete
fill 130 297 557 130 299 557 minecraft:light_gray_concrete
fill 136 297 567 136 299 567 minecraft:light_gray_concrete
setblock 136 297 582 minecraft:white_stained_glass
fill 136 297 583 136 299 583 minecraft:light_gray_concrete
fill 94 298 582 94 307 582 minecraft:black_concrete
setblock 95 298 599 minecraft:white_concrete
setblock 122 298 599 minecraft:white_stained_glass
fill 136 298 582 136 307 582 minecraft:black_concrete
fill 95 299 599 95 307 599 minecraft:black_concrete
fill 122 299 599 122 307 599 minecraft:black_concrete
setblock 136 299 590 minecraft:white_concrete
fill 94 300 565 94 307 565 minecraft:black_concrete
fill 94 300 581 94 303 581 minecraft:black_concrete
fill 94 300 597 94 307 597 minecraft:black_concrete
fill 98 300 557 98 307 557 minecraft:black_concrete
setblock 108 300 599 minecraft:black_concrete
fill 114 300 557 114 307 557 minecraft:black_concrete
fill 124 300 599 124 307 599 minecraft:black_concrete
fill 130 300 557 130 307 557 minecraft:black_concrete
setblock 136 300 560 minecraft:pearlescent_froglight
fill 136 300 567 136 307 567 minecraft:black_concrete
fill 136 300 583 136 302 583 minecraft:black_concrete
fill 136 300 590 136 307 590 minecraft:black_concrete
setblock 95 301 557 minecraft:pearlescent_froglight
setblock 107 301 557 minecraft:white_concrete
fill 108 301 557 111 307 557 minecraft:black_concrete
setblock 108 301 599 minecraft:pearlescent_froglight
setblock 124 301 557 minecraft:pearlescent_froglight
fill 136 301 560 136 307 560 minecraft:black_concrete
fill 95 302 557 95 307 557 minecraft:black_concrete
fill 107 302 557 107 307 557 minecraft:black_concrete
setblock 107 302 599 minecraft:white_concrete
fill 108 302 599 108 307 599 minecraft:black_concrete
fill 124 302 557 124 307 557 minecraft:black_concrete
setblock 125 302 557 minecraft:pearlescent_froglight
fill 107 303 599 107 307 599 minecraft:black_concrete
fill 125 303 557 125 307 557 minecraft:black_concrete
setblock 136 303 570 minecraft:pearlescent_froglight
setblock 136 303 583 minecraft:white_stained_glass
setblock 94 304 581 minecraft:white_concrete
fill 136 304 570 136 307 570 minecraft:black_concrete
fill 136 304 583 136 307 583 minecraft:black_concrete
setblock 136 304 593 minecraft:white_concrete
fill 94 305 581 94 307 581 minecraft:black_concrete
setblock 129 305 557 minecraft:pearlescent_froglight
fill 136 305 593 136 307 593 minecraft:black_concrete
fill 129 306 557 129 307 557 minecraft:black_concrete
setblock 94 307 589 minecraft:pearlescent_froglight
fill 116 307 557 117 307 557 minecraft:black_concrete
setblock 118 307 557 minecraft:white_stained_glass
fill 119 307 557 123 307 557 minecraft:black_concrete
setblock 136 307 565 minecraft:white_stained_glass
