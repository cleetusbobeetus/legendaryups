fill 407 113 276 407 116 276 minecraft:red_terracotta
setblock 407 113 278 minecraft:light[level=12]
setblock 407 113 285 minecraft:light[level=12]
setblock 407 113 292 minecraft:light[level=12]
setblock 407 113 299 minecraft:light[level=12]
setblock 407 113 306 minecraft:light[level=12]
setblock 407 113 313 minecraft:light[level=12]
setblock 411 113 276 minecraft:stripped_oak_log
fill 411 113 288 416 113 288 minecraft:orange_terracotta
fill 412 113 276 412 114 276 minecraft:red_terracotta
setblock 414 113 278 minecraft:light[level=12]
setblock 414 113 285 minecraft:light[level=12]
setblock 414 113 292 minecraft:light[level=12]
setblock 414 113 299 minecraft:light[level=12]
setblock 414 113 306 minecraft:light[level=12]
setblock 414 113 313 minecraft:light[level=12]
setblock 416 113 276 minecraft:stripped_oak_log
setblock 416 113 277 minecraft:red_terracotta
setblock 416 113 281 minecraft:stripped_oak_log
fill 416 113 282 416 116 282 minecraft:red_terracotta
fill 417 113 276 417 116 276 minecraft:red_terracotta
setblock 417 113 280 minecraft:stripped_oak_log
fill 417 113 281 417 116 281 minecraft:red_terracotta
setblock 417 113 285 minecraft:stripped_oak_log
fill 417 113 301 417 116 301 minecraft:red_terracotta
setblock 417 113 304 minecraft:red_terracotta
setblock 417 113 305 minecraft:stripped_oak_log
fill 417 113 306 417 115 307 minecraft:red_terracotta
fill 417 113 316 417 116 316 minecraft:red_terracotta
setblock 377 114 279 minecraft:stripped_oak_log
fill 377 114 280 377 117 280 minecraft:red_terracotta
setblock 377 114 284 minecraft:stripped_oak_log
fill 377 114 289 390 114 290 minecraft:stripped_oak_log
setblock 377 114 299 minecraft:stripped_oak_log
fill 377 114 300 377 117 300 minecraft:red_terracotta
setblock 377 114 304 minecraft:stripped_oak_log
fill 377 114 305 377 117 305 minecraft:red_terracotta
setblock 377 114 309 minecraft:stripped_oak_log
fill 377 114 310 378 116 310 minecraft:red_terracotta
setblock 377 114 314 minecraft:stripped_oak_log
fill 377 114 315 377 117 315 minecraft:red_terracotta
fill 378 114 299 378 117 299 minecraft:red_terracotta
setblock 378 114 303 minecraft:stripped_oak_log
fill 378 114 304 378 117 304 minecraft:red_terracotta
setblock 378 114 308 minecraft:stripped_oak_log
fill 378 114 309 378 117 309 minecraft:red_terracotta
setblock 379 114 302 minecraft:stripped_oak_log
fill 379 114 303 380 116 303 minecraft:red_terracotta
setblock 379 114 307 minecraft:stripped_oak_log
fill 379 114 308 379 117 308 minecraft:red_terracotta
setblock 380 114 276 minecraft:stripped_oak_log
fill 380 114 304 380 115 304 minecraft:red_terracotta
setblock 380 114 316 minecraft:stripped_oak_log
fill 381 114 276 381 116 276 minecraft:red_terracotta
fill 381 114 316 381 117 316 minecraft:red_terracotta
fill 391 114 289 396 114 289 minecraft:stripped_oak_log
fill 397 114 289 402 114 289 minecraft:orange_terracotta
setblock 399 114 276 minecraft:red_terracotta
setblock 399 114 277 minecraft:stripped_oak_log
setblock 400 114 276 minecraft:stripped_oak_log
fill 400 114 277 400 117 277 minecraft:red_terracotta
fill 401 114 276 401 117 276 minecraft:red_terracotta
fill 402 114 288 408 114 288 minecraft:orange_terracotta
setblock 403 114 278 minecraft:stripped_oak_log
setblock 404 114 277 minecraft:stripped_oak_log
fill 404 114 278 404 115 278 minecraft:red_terracotta
setblock 405 114 276 minecraft:stripped_oak_log
fill 405 114 277 405 117 277 minecraft:red_terracotta
fill 406 114 276 406 117 276 minecraft:red_terracotta
setblock 410 114 276 minecraft:stripped_oak_log
fill 410 114 278 410 119 278 minecraft:brown_terracotta
setblock 411 114 276 minecraft:red_terracotta
fill 414 114 292 414 116 292 minecraft:green_concrete
setblock 415 114 276 minecraft:stripped_oak_log
fill 416 114 276 416 117 276 minecraft:red_terracotta
setblock 416 114 280 minecraft:stripped_oak_log
fill 416 114 281 416 117 281 minecraft:red_terracotta
setblock 417 114 279 minecraft:stripped_oak_log
fill 417 114 280 417 117 280 minecraft:red_terracotta
setblock 417 114 284 minecraft:stripped_oak_log
fill 417 114 285 417 117 285 minecraft:red_terracotta
setblock 417 114 304 minecraft:stripped_oak_log
fill 417 114 305 417 117 305 minecraft:red_terracotta
setblock 417 114 308 minecraft:red_terracotta
setblock 417 114 309 minecraft:stripped_oak_log
setblock 377 115 278 minecraft:stripped_oak_log
fill 377 115 279 377 118 279 minecraft:red_terracotta
setblock 377 115 283 minecraft:stripped_oak_log
fill 377 115 284 377 117 285 minecraft:red_terracotta
fill 377 115 290 382 115 290 minecraft:stripped_oak_log
setblock 377 115 298 minecraft:stripped_oak_log
fill 377 115 299 377 118 299 minecraft:red_terracotta
setblock 377 115 303 minecraft:stripped_oak_log
fill 377 115 304 377 118 304 minecraft:red_terracotta
setblock 377 115 308 minecraft:stripped_oak_log
fill 377 115 309 377 118 309 minecraft:red_terracotta
setblock 377 115 313 minecraft:stripped_oak_log
fill 377 115 314 377 118 314 minecraft:red_terracotta
setblock 378 115 302 minecraft:stripped_oak_log
fill 378 115 303 378 118 303 minecraft:red_terracotta
setblock 378 115 306 minecraft:red_terracotta
setblock 378 115 307 minecraft:stripped_oak_log
fill 378 115 308 378 118 308 minecraft:red_terracotta
setblock 378 115 311 minecraft:red_terracotta
setblock 378 115 312 minecraft:stripped_oak_log
setblock 379 115 276 minecraft:stripped_oak_log
setblock 379 115 300 minecraft:red_terracotta
setblock 379 115 301 minecraft:stripped_oak_log
fill 379 115 302 379 118 302 minecraft:red_terracotta
setblock 379 115 306 minecraft:stripped_oak_log
fill 379 115 307 379 118 307 minecraft:red_terracotta
fill 379 115 309 379 116 309 minecraft:red_terracotta
setblock 379 115 316 minecraft:stripped_oak_log
fill 380 115 276 380 118 276 minecraft:red_terracotta
setblock 380 115 305 minecraft:stripped_oak_log
fill 380 115 306 380 118 306 minecraft:red_terracotta
fill 380 115 316 380 118 316 minecraft:red_terracotta
fill 385 115 289 395 115 289 minecraft:orange_terracotta
setblock 399 115 276 minecraft:stripped_oak_log
fill 399 115 277 399 118 277 minecraft:red_terracotta
fill 400 115 276 400 118 276 minecraft:red_terracotta
setblock 402 115 278 minecraft:stripped_oak_log
setblock 403 115 277 minecraft:stripped_oak_log
fill 403 115 278 403 116 278 minecraft:red_terracotta
setblock 404 115 276 minecraft:stripped_oak_log
fill 404 115 277 404 118 277 minecraft:red_terracotta
fill 405 115 276 405 118 276 minecraft:red_terracotta
setblock 409 115 276 minecraft:stripped_oak_log
setblock 414 115 276 minecraft:stripped_oak_log
fill 415 115 276 415 118 276 minecraft:red_terracotta
setblock 416 115 279 minecraft:stripped_oak_log
fill 416 115 280 416 118 280 minecraft:red_terracotta
setblock 416 115 283 minecraft:red_terracotta
setblock 417 115 278 minecraft:stripped_oak_log
fill 417 115 279 417 118 279 minecraft:red_terracotta
setblock 417 115 283 minecraft:stripped_oak_log
fill 417 115 284 417 118 284 minecraft:red_terracotta
fill 417 115 286 417 116 286 minecraft:red_terracotta
setblock 417 115 303 minecraft:stripped_oak_log
fill 417 115 304 417 118 304 minecraft:red_terracotta
setblock 417 115 308 minecraft:stripped_oak_log
fill 417 115 309 417 115 312 minecraft:red_terracotta
setblock 417 115 313 minecraft:stripped_oak_log
fill 417 115 314 417 117 315 minecraft:red_terracotta
fill 376 116 275 376 119 317 minecraft:red_terracotta
fill 377 116 275 418 119 275 minecraft:red_terracotta
setblock 377 116 277 minecraft:stripped_oak_log
fill 377 116 278 377 119 278 minecraft:red_terracotta
setblock 377 116 282 minecraft:stripped_oak_log
fill 377 116 283 378 118 283 minecraft:red_terracotta
setblock 377 116 286 minecraft:red_terracotta
setblock 377 116 287 minecraft:stripped_oak_log
fill 377 116 290 380 116 290 minecraft:orange_terracotta
setblock 377 116 297 minecraft:stripped_oak_log
fill 377 116 298 377 119 298 minecraft:red_terracotta
setblock 377 116 302 minecraft:stripped_oak_log
fill 377 116 303 377 119 303 minecraft:red_terracotta
setblock 377 116 307 minecraft:stripped_oak_log
fill 377 116 308 377 119 308 minecraft:red_terracotta
setblock 377 116 312 minecraft:stripped_oak_log
fill 377 116 313 378 118 313 minecraft:red_terracotta
fill 377 116 317 418 119 317 minecraft:red_terracotta
setblock 378 116 276 minecraft:stripped_oak_log
setblock 378 116 281 minecraft:stripped_oak_log
fill 378 116 282 378 119 282 minecraft:red_terracotta
setblock 378 116 301 minecraft:stripped_oak_log
fill 378 116 302 378 119 302 minecraft:red_terracotta
setblock 378 116 306 minecraft:stripped_oak_log
fill 378 116 307 378 119 307 minecraft:red_terracotta
setblock 378 116 311 minecraft:stripped_oak_log
fill 378 116 312 378 119 312 minecraft:red_terracotta
setblock 378 116 316 minecraft:stripped_oak_log
fill 379 116 276 379 119 276 minecraft:red_terracotta
setblock 379 116 300 minecraft:stripped_oak_log
fill 379 116 301 379 119 301 minecraft:red_terracotta
setblock 379 116 305 minecraft:stripped_oak_log
fill 379 116 306 379 119 306 minecraft:red_terracotta
setblock 379 116 310 minecraft:stripped_oak_log
fill 379 116 316 379 119 316 minecraft:red_terracotta
fill 380 116 302 380 117 302 minecraft:red_terracotta
setblock 380 116 304 minecraft:stripped_oak_log
fill 380 116 305 380 119 305 minecraft:red_terracotta
fill 380 116 307 380 117 307 minecraft:red_terracotta
setblock 397 116 276 minecraft:red_terracotta
setblock 398 116 276 minecraft:stripped_oak_log
fill 399 116 276 399 119 276 minecraft:red_terracotta
setblock 401 116 278 minecraft:stripped_oak_log
setblock 402 116 277 minecraft:stripped_oak_log
fill 402 116 278 402 117 278 minecraft:red_terracotta
setblock 403 116 276 minecraft:stripped_oak_log
fill 403 116 277 403 119 277 minecraft:red_terracotta
fill 404 116 276 404 119 276 minecraft:red_terracotta
setblock 408 116 276 minecraft:stripped_oak_log
setblock 413 116 276 minecraft:stripped_oak_log
fill 414 116 276 414 119 276 minecraft:red_terracotta
setblock 416 116 278 minecraft:stripped_oak_log
fill 416 116 279 416 119 279 minecraft:red_terracotta
setblock 416 116 283 minecraft:stripped_oak_log
fill 416 116 284 416 119 284 minecraft:red_terracotta
fill 416 116 305 416 116 307 minecraft:red_terracotta
setblock 416 116 308 minecraft:stripped_oak_log
fill 416 116 316 416 117 316 minecraft:red_terracotta
setblock 417 116 277 minecraft:stripped_oak_log
fill 417 116 278 418 119 278 minecraft:red_terracotta
setblock 417 116 282 minecraft:stripped_oak_log
fill 417 116 283 418 119 283 minecraft:red_terracotta
setblock 417 116 287 minecraft:stripped_oak_log
fill 417 116 300 418 117 300 minecraft:red_terracotta
setblock 417 116 302 minecraft:stripped_oak_log
fill 417 116 303 418 119 303 minecraft:red_terracotta
fill 417 116 306 418 116 306 minecraft:red_terracotta
setblock 417 116 307 minecraft:stripped_oak_log
fill 417 116 308 418 116 311 minecraft:red_terracotta
setblock 417 116 312 minecraft:stripped_oak_log
fill 417 116 313 418 119 313 minecraft:red_terracotta
fill 418 116 276 418 119 277 minecraft:red_terracotta
fill 418 116 279 418 119 282 minecraft:red_terracotta
fill 418 116 284 418 119 299 minecraft:red_terracotta
fill 418 116 301 418 119 302 minecraft:red_terracotta
fill 418 116 304 418 119 305 minecraft:red_terracotta
fill 418 116 307 418 119 307 minecraft:red_terracotta
fill 418 116 312 418 119 312 minecraft:red_terracotta
fill 418 116 314 418 119 316 minecraft:red_terracotta
setblock 377 117 276 minecraft:stripped_oak_log
fill 377 117 277 377 120 277 minecraft:red_terracotta
setblock 377 117 281 minecraft:stripped_oak_log
fill 377 117 282 377 120 282 minecraft:red_terracotta
setblock 377 117 286 minecraft:stripped_oak_log
fill 377 117 287 377 118 289 minecraft:red_terracotta
setblock 377 117 296 minecraft:stripped_oak_log
fill 377 117 297 377 120 297 minecraft:red_terracotta
setblock 377 117 301 minecraft:stripped_oak_log
fill 377 117 302 377 120 302 minecraft:red_terracotta
setblock 377 117 306 minecraft:stripped_oak_log
fill 377 117 307 377 120 307 minecraft:red_terracotta
setblock 377 117 310 minecraft:red_terracotta
setblock 377 117 311 minecraft:stripped_oak_log
fill 377 117 312 377 120 312 minecraft:red_terracotta
setblock 377 117 316 minecraft:stripped_oak_log
fill 378 117 276 378 120 276 minecraft:red_terracotta
fill 378 117 281 378 120 281 minecraft:red_terracotta
setblock 378 117 284 minecraft:red_terracotta
setblock 378 117 285 minecraft:stripped_oak_log
fill 378 117 286 378 120 286 minecraft:red_terracotta
fill 378 117 298 378 118 298 minecraft:red_terracotta
setblock 378 117 300 minecraft:stripped_oak_log
fill 378 117 301 378 120 301 minecraft:red_terracotta
setblock 378 117 305 minecraft:stripped_oak_log
fill 378 117 306 378 120 306 minecraft:red_terracotta
setblock 378 117 310 minecraft:stripped_oak_log
fill 378 117 311 379 119 311 minecraft:red_terracotta
setblock 378 117 314 minecraft:red_terracotta
fill 378 117 316 378 120 316 minecraft:red_terracotta
fill 379 117 300 379 120 300 minecraft:red_terracotta
setblock 379 117 303 minecraft:red_terracotta
setblock 379 117 304 minecraft:stripped_oak_log
fill 379 117 305 379 120 305 minecraft:red_terracotta
setblock 379 117 309 minecraft:stripped_oak_log
fill 379 117 310 379 120 310 minecraft:red_terracotta
fill 379 117 315 379 120 315 minecraft:red_terracotta
setblock 380 117 303 minecraft:stripped_oak_log
fill 380 117 304 380 120 304 minecraft:red_terracotta
setblock 380 117 308 minecraft:stripped_oak_log
fill 380 117 309 380 120 309 minecraft:red_terracotta
setblock 382 117 316 minecraft:stripped_oak_log
setblock 397 117 276 minecraft:stripped_oak_log
fill 398 117 276 398 119 277 minecraft:red_terracotta
setblock 400 117 278 minecraft:stripped_oak_log
setblock 401 117 277 minecraft:stripped_oak_log
fill 401 117 278 401 119 278 minecraft:red_terracotta
setblock 402 117 276 minecraft:stripped_oak_log
fill 402 117 277 402 120 277 minecraft:red_terracotta
fill 403 117 276 403 120 276 minecraft:red_terracotta
setblock 407 117 276 minecraft:stripped_oak_log
fill 413 117 276 413 120 276 minecraft:red_terracotta
fill 415 117 316 415 118 316 minecraft:red_terracotta
setblock 416 117 277 minecraft:stripped_oak_log
fill 416 117 278 416 120 278 minecraft:red_terracotta
setblock 416 117 282 minecraft:stripped_oak_log
fill 416 117 283 416 120 283 minecraft:red_terracotta
fill 416 117 285 416 118 285 minecraft:red_terracotta
fill 416 117 303 416 117 306 minecraft:red_terracotta
setblock 416 117 307 minecraft:stripped_oak_log
fill 416 117 308 416 117 311 minecraft:red_terracotta
setblock 417 117 276 minecraft:stripped_oak_log
fill 417 117 277 417 120 277 minecraft:red_terracotta
setblock 417 117 281 minecraft:stripped_oak_log
fill 417 117 282 417 120 282 minecraft:red_terracotta
setblock 417 117 286 minecraft:stripped_oak_log
fill 417 117 287 417 118 289 minecraft:red_terracotta
setblock 417 117 301 minecraft:stripped_oak_log
fill 417 117 302 417 120 302 minecraft:red_terracotta
setblock 417 117 306 minecraft:stripped_oak_log
fill 417 117 307 417 117 310 minecraft:red_terracotta
setblock 417 117 311 minecraft:stripped_oak_log
fill 417 117 312 417 120 312 minecraft:red_terracotta
setblock 417 117 316 minecraft:stripped_oak_log
fill 418 117 306 418 119 306 minecraft:red_terracotta
fill 418 117 308 418 119 311 minecraft:red_terracotta
fill 377 118 276 377 121 276 minecraft:red_terracotta
setblock 377 118 280 minecraft:stripped_oak_log
fill 377 118 281 377 121 281 minecraft:red_terracotta
setblock 377 118 284 minecraft:red_terracotta
setblock 377 118 285 minecraft:stripped_oak_log
fill 377 118 286 377 121 286 minecraft:red_terracotta
setblock 377 118 290 minecraft:stripped_oak_log
fill 377 118 291 377 118 294 minecraft:red_terracotta
setblock 377 118 295 minecraft:stripped_oak_log
fill 377 118 296 377 121 296 minecraft:red_terracotta
setblock 377 118 300 minecraft:stripped_oak_log
fill 377 118 301 377 121 301 minecraft:red_terracotta
setblock 377 118 305 minecraft:stripped_oak_log
fill 377 118 306 377 121 306 minecraft:red_terracotta
setblock 377 118 310 minecraft:stripped_oak_log
fill 377 118 311 377 121 311 minecraft:red_terracotta
setblock 377 118 315 minecraft:stripped_oak_log
fill 377 118 316 377 121 316 minecraft:red_terracotta
fill 378 118 280 378 119 280 minecraft:red_terracotta
setblock 378 118 284 minecraft:stripped_oak_log
fill 378 118 285 378 121 285 minecraft:red_terracotta
fill 378 118 287 378 118 288 minecraft:red_terracotta
setblock 378 118 289 minecraft:stripped_oak_log
setblock 378 118 299 minecraft:stripped_oak_log
fill 378 118 300 378 121 300 minecraft:red_terracotta
setblock 378 118 304 minecraft:stripped_oak_log
fill 378 118 305 378 121 305 minecraft:red_terracotta
setblock 378 118 309 minecraft:stripped_oak_log
fill 378 118 310 378 121 310 minecraft:red_terracotta
setblock 378 118 314 minecraft:stripped_oak_log
fill 378 118 315 378 121 315 minecraft:red_terracotta
setblock 379 118 303 minecraft:stripped_oak_log
fill 379 118 304 379 121 304 minecraft:red_terracotta
setblock 379 118 308 minecraft:stripped_oak_log
fill 379 118 309 379 121 309 minecraft:red_terracotta
setblock 379 118 312 minecraft:red_terracotta
setblock 380 118 302 minecraft:stripped_oak_log
fill 380 118 303 380 121 303 minecraft:red_terracotta
setblock 380 118 307 minecraft:stripped_oak_log
fill 380 118 308 380 121 308 minecraft:red_terracotta
fill 380 118 310 380 119 310 minecraft:red_terracotta
fill 380 118 315 380 119 315 minecraft:red_terracotta
setblock 381 118 316 minecraft:stripped_oak_log
fill 382 118 316 382 121 316 minecraft:red_terracotta
setblock 396 118 276 minecraft:stripped_oak_log
fill 397 118 276 397 121 276 minecraft:red_terracotta
setblock 400 118 277 minecraft:stripped_oak_log
fill 400 118 278 400 120 278 minecraft:red_terracotta
setblock 401 118 276 minecraft:stripped_oak_log
fill 401 118 277 401 121 277 minecraft:red_terracotta
fill 402 118 276 402 121 276 minecraft:red_terracotta
setblock 406 118 276 minecraft:stripped_oak_log
fill 407 118 276 407 121 276 minecraft:red_terracotta
fill 409 118 278 409 119 278 minecraft:brown_terracotta
fill 410 118 277 410 119 277 minecraft:brown_terracotta
fill 410 118 279 410 119 279 minecraft:brown_terracotta
fill 411 118 278 411 119 278 minecraft:brown_terracotta
fill 412 118 276 412 121 276 minecraft:red_terracotta
fill 414 118 316 414 119 316 minecraft:red_terracotta
setblock 416 118 276 minecraft:stripped_oak_log
fill 416 118 277 416 121 277 minecraft:red_terracotta
setblock 416 118 281 minecraft:stripped_oak_log
fill 416 118 282 416 121 282 minecraft:red_terracotta
setblock 416 118 286 minecraft:stripped_oak_log
fill 416 118 287 416 121 287 minecraft:red_terracotta
fill 416 118 302 416 118 305 minecraft:red_terracotta
setblock 416 118 306 minecraft:stripped_oak_log
fill 416 118 307 416 118 310 minecraft:red_terracotta
setblock 416 118 311 minecraft:stripped_oak_log
fill 416 118 312 416 118 315 minecraft:red_terracotta
setblock 416 118 316 minecraft:stripped_oak_log
fill 417 118 276 417 121 276 minecraft:red_terracotta
setblock 417 118 280 minecraft:stripped_oak_log
fill 417 118 281 417 121 281 minecraft:red_terracotta
setblock 417 118 285 minecraft:stripped_oak_log
fill 417 118 286 417 121 286 minecraft:red_terracotta
setblock 417 118 290 minecraft:stripped_oak_log
setblock 417 118 299 minecraft:red_terracotta
setblock 417 118 300 minecraft:stripped_oak_log
fill 417 118 301 417 121 301 minecraft:red_terracotta
setblock 417 118 305 minecraft:stripped_oak_log
fill 417 118 306 417 118 309 minecraft:red_terracotta
setblock 417 118 310 minecraft:stripped_oak_log
fill 417 118 311 417 121 311 minecraft:red_terracotta
setblock 417 118 314 minecraft:red_terracotta
setblock 417 118 315 minecraft:stripped_oak_log
fill 417 118 316 417 121 316 minecraft:red_terracotta
fill 418 118 300 418 119 300 minecraft:red_terracotta
setblock 377 119 279 minecraft:stripped_oak_log
fill 377 119 280 377 122 280 minecraft:red_terracotta
setblock 377 119 283 minecraft:red_terracotta
setblock 377 119 284 minecraft:stripped_oak_log
fill 377 119 285 377 122 285 minecraft:red_terracotta
fill 377 119 287 377 119 288 minecraft:red_terracotta
setblock 377 119 289 minecraft:stripped_oak_log
fill 377 119 290 377 119 293 minecraft:red_terracotta
setblock 377 119 294 minecraft:stripped_oak_log
fill 377 119 295 377 122 295 minecraft:red_terracotta
setblock 377 119 299 minecraft:stripped_oak_log
fill 377 119 300 377 122 300 minecraft:red_terracotta
setblock 377 119 304 minecraft:stripped_oak_log
fill 377 119 305 377 122 305 minecraft:red_terracotta
setblock 377 119 309 minecraft:stripped_oak_log
fill 377 119 310 377 122 310 minecraft:red_terracotta
setblock 377 119 313 minecraft:red_terracotta
setblock 377 119 314 minecraft:stripped_oak_log
fill 377 119 315 377 122 315 minecraft:red_terracotta
setblock 378 119 283 minecraft:stripped_oak_log
fill 378 119 284 378 122 284 minecraft:red_terracotta
setblock 378 119 287 minecraft:red_terracotta
setblock 378 119 288 minecraft:stripped_oak_log
fill 378 119 289 378 119 292 minecraft:red_terracotta
fill 378 119 296 378 119 297 minecraft:red_terracotta
setblock 378 119 298 minecraft:stripped_oak_log
fill 378 119 299 379 121 299 minecraft:red_terracotta
setblock 378 119 303 minecraft:stripped_oak_log
fill 378 119 304 378 122 304 minecraft:red_terracotta
setblock 378 119 308 minecraft:stripped_oak_log
fill 378 119 309 378 122 309 minecraft:red_terracotta
setblock 378 119 313 minecraft:stripped_oak_log
fill 378 119 314 378 122 314 minecraft:red_terracotta
setblock 379 119 278 minecraft:light[level=15]
fill 379 119 285 379 119 286 minecraft:red_terracotta
setblock 379 119 287 minecraft:stripped_oak_log
setblock 379 119 292 minecraft:light[level=12]
setblock 379 119 294 minecraft:light[level=15]
setblock 379 119 302 minecraft:stripped_oak_log
fill 379 119 303 379 122 303 minecraft:red_terracotta
setblock 379 119 307 minecraft:stripped_oak_log
fill 379 119 308 379 122 308 minecraft:red_terracotta
setblock 379 119 312 minecraft:stripped_oak_log
fill 379 119 313 379 122 313 minecraft:red_terracotta
setblock 380 119 276 minecraft:stripped_oak_log
fill 380 119 302 380 120 302 minecraft:red_terracotta
setblock 380 119 306 minecraft:stripped_oak_log
fill 380 119 307 380 122 307 minecraft:red_terracotta
setblock 380 119 316 minecraft:stripped_oak_log
fill 381 119 316 381 122 316 minecraft:red_terracotta
setblock 386 119 278 minecraft:light[level=12]
setblock 386 119 285 minecraft:light[level=12]
setblock 386 119 292 minecraft:light[level=12]
setblock 386 119 299 minecraft:light[level=12]
setblock 386 119 306 minecraft:light[level=12]
setblock 386 119 313 minecraft:light[level=12]
setblock 387 119 278 minecraft:light[level=15]
setblock 387 119 286 minecraft:light[level=15]
setblock 387 119 294 minecraft:light[level=15]
setblock 387 119 302 minecraft:light[level=15]
setblock 387 119 310 minecraft:light[level=15]
setblock 393 119 278 minecraft:light[level=12]
setblock 393 119 285 minecraft:light[level=12]
setblock 393 119 292 minecraft:light[level=12]
setblock 393 119 299 minecraft:light[level=12]
setblock 393 119 306 minecraft:light[level=12]
setblock 393 119 313 minecraft:light[level=12]
setblock 395 119 276 minecraft:stripped_oak_log
setblock 395 119 278 minecraft:light[level=15]
setblock 395 119 286 minecraft:light[level=15]
setblock 395 119 302 minecraft:light[level=15]
setblock 395 119 310 minecraft:light[level=15]
fill 396 119 276 396 122 276 minecraft:red_terracotta
fill 397 119 277 397 120 277 minecraft:red_terracotta
fill 398 119 316 399 119 316 minecraft:red_terracotta
setblock 399 119 277 minecraft:stripped_oak_log
fill 399 119 278 399 121 278 minecraft:red_terracotta
setblock 400 119 276 minecraft:stripped_oak_log
fill 400 119 277 400 122 277 minecraft:red_terracotta
setblock 400 119 285 minecraft:light[level=12]
setblock 400 119 292 minecraft:light[level=12]
setblock 400 119 299 minecraft:light[level=12]
setblock 400 119 306 minecraft:light[level=12]
setblock 400 119 313 minecraft:light[level=12]
setblock 400 119 316 minecraft:stripped_oak_log
fill 401 119 276 401 122 276 minecraft:red_terracotta
fill 401 119 316 402 121 316 minecraft:red_terracotta
setblock 403 119 278 minecraft:light[level=15]
setblock 403 119 286 minecraft:light[level=15]
setblock 403 119 294 minecraft:light[level=15]
setblock 403 119 302 minecraft:light[level=15]
setblock 403 119 310 minecraft:light[level=15]
setblock 404 119 277 minecraft:stripped_oak_log
setblock 405 119 276 minecraft:stripped_oak_log
fill 406 119 276 406 122 276 minecraft:red_terracotta
setblock 407 119 278 minecraft:light[level=12]
setblock 407 119 285 minecraft:light[level=12]
setblock 407 119 292 minecraft:light[level=12]
setblock 407 119 299 minecraft:light[level=12]
setblock 407 119 306 minecraft:light[level=12]
setblock 407 119 313 minecraft:light[level=12]
setblock 409 119 277 minecraft:brown_terracotta
setblock 409 119 279 minecraft:brown_terracotta
fill 411 119 276 411 122 276 minecraft:red_terracotta
setblock 411 119 277 minecraft:brown_terracotta
setblock 411 119 279 minecraft:brown_terracotta
setblock 411 119 286 minecraft:light[level=15]
setblock 411 119 294 minecraft:light[level=15]
setblock 411 119 302 minecraft:light[level=15]
setblock 411 119 310 minecraft:light[level=15]
fill 412 119 316 413 120 316 minecraft:red_terracotta
setblock 414 119 278 minecraft:light[level=12]
setblock 414 119 285 minecraft:light[level=12]
setblock 414 119 292 minecraft:light[level=12]
setblock 414 119 299 minecraft:light[level=12]
setblock 414 119 306 minecraft:light[level=12]
setblock 414 119 313 minecraft:light[level=12]
setblock 415 119 276 minecraft:stripped_oak_log
fill 415 119 277 415 122 277 minecraft:red_terracotta
setblock 415 119 305 minecraft:red_terracotta
setblock 415 119 306 minecraft:stripped_oak_log
fill 415 119 307 415 119 310 minecraft:red_terracotta
setblock 415 119 311 minecraft:stripped_oak_log
setblock 415 119 315 minecraft:red_terracotta
setblock 415 119 316 minecraft:stripped_oak_log
fill 416 119 276 416 122 276 minecraft:red_terracotta
setblock 416 119 280 minecraft:stripped_oak_log
fill 416 119 281 416 122 281 minecraft:red_terracotta
setblock 416 119 285 minecraft:stripped_oak_log
fill 416 119 286 416 122 286 minecraft:red_terracotta
fill 416 119 288 417 119 288 minecraft:red_terracotta
fill 416 119 302 416 119 304 minecraft:red_terracotta
setblock 416 119 305 minecraft:stripped_oak_log
fill 416 119 306 416 119 309 minecraft:red_terracotta
setblock 416 119 310 minecraft:stripped_oak_log
fill 416 119 311 416 119 314 minecraft:red_terracotta
setblock 416 119 315 minecraft:stripped_oak_log
fill 416 119 316 416 122 316 minecraft:red_terracotta
setblock 417 119 279 minecraft:stripped_oak_log
fill 417 119 280 417 122 280 minecraft:red_terracotta
setblock 417 119 284 minecraft:stripped_oak_log
fill 417 119 285 417 122 285 minecraft:red_terracotta
fill 417 119 287 417 120 287 minecraft:red_terracotta
setblock 417 119 289 minecraft:stripped_oak_log
fill 417 119 290 417 120 292 minecraft:red_terracotta
setblock 417 119 298 minecraft:red_terracotta
setblock 417 119 299 minecraft:stripped_oak_log
fill 417 119 300 417 122 300 minecraft:red_terracotta
setblock 417 119 304 minecraft:stripped_oak_log
fill 417 119 305 417 119 308 minecraft:red_terracotta
setblock 417 119 309 minecraft:stripped_oak_log
fill 417 119 310 417 122 310 minecraft:red_terracotta
setblock 417 119 314 minecraft:stripped_oak_log
fill 417 119 315 417 122 315 minecraft:red_terracotta
fill 376 120 275 376 123 317 minecraft:yellow_terracotta
fill 377 120 275 418 123 275 minecraft:yellow_terracotta
setblock 377 120 278 minecraft:stripped_oak_log
fill 377 120 279 377 123 279 minecraft:red_terracotta
setblock 377 120 283 minecraft:stripped_oak_log
fill 377 120 284 377 123 284 minecraft:red_terracotta
setblock 377 120 287 minecraft:red_terracotta
setblock 377 120 288 minecraft:stripped_oak_log
fill 377 120 289 377 120 292 minecraft:red_terracotta
setblock 377 120 293 minecraft:stripped_oak_log
fill 377 120 294 378 122 294 minecraft:red_terracotta
setblock 377 120 298 minecraft:stripped_oak_log
fill 377 120 299 377 123 299 minecraft:red_terracotta
setblock 377 120 303 minecraft:stripped_oak_log
fill 377 120 304 377 123 304 minecraft:red_terracotta
setblock 377 120 308 minecraft:stripped_oak_log
fill 377 120 309 377 123 309 minecraft:red_terracotta
setblock 377 120 313 minecraft:stripped_oak_log
fill 377 120 314 377 123 314 minecraft:red_terracotta
fill 377 120 317 418 123 317 minecraft:yellow_terracotta
setblock 378 120 282 minecraft:stripped_oak_log
fill 378 120 283 378 123 283 minecraft:red_terracotta
setblock 378 120 287 minecraft:stripped_oak_log
fill 378 120 288 378 120 291 minecraft:red_terracotta
setblock 378 120 292 minecraft:stripped_oak_log
fill 378 120 293 378 123 293 minecraft:red_terracotta
fill 378 120 295 378 120 296 minecraft:red_terracotta
setblock 378 120 297 minecraft:stripped_oak_log
fill 378 120 298 378 123 298 minecraft:red_terracotta
setblock 378 120 302 minecraft:stripped_oak_log
fill 378 120 303 378 123 303 minecraft:red_terracotta
setblock 378 120 307 minecraft:stripped_oak_log
fill 378 120 308 378 123 308 minecraft:red_terracotta
setblock 378 120 311 minecraft:red_terracotta
setblock 378 120 312 minecraft:stripped_oak_log
fill 378 120 313 378 123 313 minecraft:red_terracotta
setblock 379 120 276 minecraft:stripped_oak_log
fill 379 120 284 379 120 285 minecraft:red_terracotta
setblock 379 120 286 minecraft:stripped_oak_log
fill 379 120 287 379 120 290 minecraft:red_terracotta
setblock 379 120 301 minecraft:stripped_oak_log
fill 379 120 302 379 123 302 minecraft:red_terracotta
setblock 379 120 306 minecraft:stripped_oak_log
fill 379 120 307 379 123 307 minecraft:red_terracotta
setblock 379 120 311 minecraft:stripped_oak_log
fill 379 120 312 379 123 312 minecraft:red_terracotta
fill 379 120 314 379 121 314 minecraft:red_terracotta
setblock 379 120 316 minecraft:stripped_oak_log
setblock 380 120 305 minecraft:stripped_oak_log
fill 380 120 306 380 123 306 minecraft:red_terracotta
setblock 380 120 310 minecraft:stripped_oak_log
fill 380 120 311 380 122 311 minecraft:red_terracotta
setblock 380 120 315 minecraft:stripped_oak_log
fill 380 120 316 380 123 316 minecraft:red_terracotta
fill 381 120 315 381 122 315 minecraft:red_terracotta
fill 393 120 278 395 120 280 minecraft:terracotta
fill 395 120 276 395 123 276 minecraft:red_terracotta
fill 396 120 277 396 121 277 minecraft:red_terracotta
fill 396 120 316 398 120 316 minecraft:red_terracotta
setblock 398 120 276 minecraft:red_terracotta
setblock 398 120 277 minecraft:stripped_oak_log
fill 398 120 278 398 121 278 minecraft:red_terracotta
setblock 399 120 276 minecraft:stripped_oak_log
fill 399 120 277 399 123 277 minecraft:red_terracotta
setblock 399 120 316 minecraft:stripped_oak_log
fill 400 120 276 400 123 276 minecraft:red_terracotta
fill 400 120 316 400 123 316 minecraft:red_terracotta
setblock 403 120 277 minecraft:stripped_oak_log
setblock 403 120 316 minecraft:red_terracotta
setblock 404 120 276 minecraft:stripped_oak_log
fill 405 120 276 405 123 276 minecraft:red_terracotta
setblock 408 120 276 minecraft:red_terracotta
setblock 409 120 276 minecraft:stripped_oak_log
fill 410 120 276 410 123 276 minecraft:red_terracotta
fill 411 120 316 411 122 316 minecraft:red_terracotta
fill 413 120 315 414 120 315 minecraft:red_terracotta
setblock 414 120 276 minecraft:stripped_oak_log
setblock 414 120 316 minecraft:stripped_oak_log
fill 415 120 276 415 123 276 minecraft:red_terracotta
fill 415 120 283 415 120 284 minecraft:red_terracotta
setblock 415 120 285 minecraft:stripped_oak_log
setblock 415 120 305 minecraft:stripped_oak_log
fill 415 120 306 415 120 309 minecraft:red_terracotta
setblock 415 120 310 minecraft:stripped_oak_log
fill 415 120 311 415 120 314 minecraft:red_terracotta
setblock 415 120 315 minecraft:stripped_oak_log
fill 415 120 316 415 123 316 minecraft:red_terracotta
setblock 416 120 279 minecraft:stripped_oak_log
fill 416 120 280 416 123 280 minecraft:red_terracotta
setblock 416 120 284 minecraft:stripped_oak_log
fill 416 120 285 416 123 285 minecraft:red_terracotta
setblock 416 120 288 minecraft:red_terracotta
setblock 416 120 289 minecraft:stripped_oak_log
fill 416 120 290 416 123 290 minecraft:red_terracotta
fill 416 120 301 416 120 303 minecraft:red_terracotta
setblock 416 120 304 minecraft:stripped_oak_log
fill 416 120 305 416 120 308 minecraft:red_terracotta
setblock 416 120 309 minecraft:stripped_oak_log
fill 416 120 310 416 120 313 minecraft:red_terracotta
setblock 416 120 314 minecraft:stripped_oak_log
fill 416 120 315 416 123 315 minecraft:red_terracotta
setblock 417 120 278 minecraft:stripped_oak_log
fill 417 120 279 417 123 279 minecraft:red_terracotta
setblock 417 120 283 minecraft:stripped_oak_log
fill 417 120 284 417 123 284 minecraft:red_terracotta
setblock 417 120 288 minecraft:stripped_oak_log
fill 417 120 289 417 123 289 minecraft:red_terracotta
setblock 417 120 293 minecraft:stripped_oak_log
fill 417 120 294 417 120 297 minecraft:red_terracotta
setblock 417 120 298 minecraft:stripped_oak_log
fill 417 120 299 417 123 299 minecraft:red_terracotta
setblock 417 120 303 minecraft:stripped_oak_log
fill 417 120 304 417 120 307 minecraft:red_terracotta
setblock 417 120 308 minecraft:stripped_oak_log
fill 417 120 309 417 123 309 minecraft:red_terracotta
setblock 417 120 313 minecraft:stripped_oak_log
fill 417 120 314 417 123 314 minecraft:red_terracotta
fill 418 120 276 418 123 316 minecraft:yellow_terracotta
setblock 377 121 277 minecraft:stripped_oak_log
fill 377 121 278 377 123 278 minecraft:red_terracotta
setblock 377 121 282 minecraft:stripped_oak_log
fill 377 121 283 377 124 283 minecraft:red_terracotta
setblock 377 121 287 minecraft:stripped_oak_log
fill 377 121 288 377 121 291 minecraft:red_terracotta
setblock 377 121 292 minecraft:stripped_oak_log
fill 377 121 293 377 124 293 minecraft:red_terracotta
setblock 377 121 297 minecraft:stripped_oak_log
fill 377 121 298 377 124 298 minecraft:red_terracotta
setblock 377 121 302 minecraft:stripped_oak_log
fill 377 121 303 377 124 303 minecraft:red_terracotta
setblock 377 121 307 minecraft:stripped_oak_log
fill 377 121 308 377 124 308 minecraft:red_terracotta
setblock 377 121 312 minecraft:stripped_oak_log
fill 377 121 313 377 124 313 minecraft:red_terracotta
setblock 378 121 276 minecraft:stripped_oak_log
setblock 378 121 281 minecraft:stripped_oak_log
fill 378 121 282 378 122 282 minecraft:red_terracotta
setblock 378 121 286 minecraft:stripped_oak_log
fill 378 121 287 378 121 290 minecraft:red_terracotta
setblock 378 121 291 minecraft:stripped_oak_log
fill 378 121 292 379 123 292 minecraft:red_terracotta
setblock 378 121 295 minecraft:red_terracotta
setblock 378 121 296 minecraft:stripped_oak_log
fill 378 121 297 378 124 297 minecraft:red_terracotta
setblock 378 121 301 minecraft:stripped_oak_log
fill 378 121 302 378 124 302 minecraft:red_terracotta
setblock 378 121 306 minecraft:stripped_oak_log
fill 378 121 307 378 124 307 minecraft:red_terracotta
setblock 378 121 311 minecraft:stripped_oak_log
fill 378 121 312 378 124 312 minecraft:red_terracotta
setblock 378 121 316 minecraft:stripped_oak_log
setblock 379 121 276 minecraft:red_terracotta
setblock 379 121 285 minecraft:stripped_oak_log
fill 379 121 286 379 121 289 minecraft:red_terracotta
setblock 379 121 290 minecraft:stripped_oak_log
fill 379 121 291 379 124 291 minecraft:red_terracotta
setblock 379 121 300 minecraft:stripped_oak_log
fill 379 121 301 379 123 301 minecraft:red_terracotta
setblock 379 121 305 minecraft:stripped_oak_log
fill 379 121 306 379 124 306 minecraft:red_terracotta
setblock 379 121 310 minecraft:stripped_oak_log
fill 379 121 311 379 124 311 minecraft:red_terracotta
setblock 379 121 315 minecraft:stripped_oak_log
fill 379 121 316 379 124 316 minecraft:red_terracotta
setblock 380 121 304 minecraft:stripped_oak_log
fill 380 121 305 380 122 305 minecraft:red_terracotta
setblock 380 121 309 minecraft:stripped_oak_log
fill 380 121 310 380 123 310 minecraft:red_terracotta
fill 380 121 315 380 124 315 minecraft:red_terracotta
fill 394 121 276 394 124 276 minecraft:red_terracotta
fill 394 121 279 394 127 279 minecraft:green_concrete
fill 395 121 316 397 121 316 minecraft:red_terracotta
setblock 397 121 277 minecraft:stripped_oak_log
setblock 398 121 276 minecraft:stripped_oak_log
fill 398 121 277 398 124 277 minecraft:red_terracotta
setblock 398 121 316 minecraft:stripped_oak_log
fill 399 121 276 399 124 276 minecraft:red_terracotta
fill 399 121 316 399 124 316 minecraft:red_terracotta
setblock 402 121 277 minecraft:stripped_oak_log
setblock 403 121 276 minecraft:stripped_oak_log
setblock 403 121 277 minecraft:red_terracotta
setblock 403 121 316 minecraft:stripped_oak_log
fill 404 121 276 404 124 276 minecraft:red_terracotta
fill 404 121 316 404 124 316 minecraft:red_terracotta
setblock 408 121 276 minecraft:stripped_oak_log
fill 409 121 276 409 124 276 minecraft:red_terracotta
fill 409 121 316 410 123 316 minecraft:red_terracotta
fill 412 121 315 412 121 316 minecraft:red_terracotta
setblock 413 121 276 minecraft:stripped_oak_log
setblock 413 121 315 minecraft:red_terracotta
setblock 413 121 316 minecraft:stripped_oak_log
fill 414 121 276 414 123 277 minecraft:red_terracotta
fill 414 121 289 415 122 289 minecraft:iron_bars
setblock 414 121 309 minecraft:red_terracotta
setblock 414 121 310 minecraft:stripped_oak_log
setblock 414 121 314 minecraft:red_terracotta
setblock 414 121 315 minecraft:stripped_oak_log
fill 414 121 316 414 124 316 minecraft:red_terracotta
setblock 415 121 283 minecraft:red_terracotta
setblock 415 121 284 minecraft:stripped_oak_log
fill 415 121 285 415 122 287 minecraft:red_terracotta
setblock 415 121 304 minecraft:stripped_oak_log
fill 415 121 305 415 121 308 minecraft:red_terracotta
setblock 415 121 309 minecraft:stripped_oak_log
fill 415 121 310 415 121 313 minecraft:red_terracotta
setblock 415 121 314 minecraft:stripped_oak_log
fill 415 121 315 415 124 315 minecraft:red_terracotta
setblock 416 121 278 minecraft:stripped_oak_log
fill 416 121 279 416 123 279 minecraft:red_terracotta
setblock 416 121 283 minecraft:stripped_oak_log
fill 416 121 284 416 124 284 minecraft:red_terracotta
setblock 416 121 288 minecraft:stripped_oak_log
fill 416 121 289 416 124 289 minecraft:red_terracotta
fill 416 121 291 417 121 291 minecraft:red_terracotta
fill 416 121 301 416 121 302 minecraft:red_terracotta
setblock 416 121 303 minecraft:stripped_oak_log
fill 416 121 304 416 121 307 minecraft:red_terracotta
setblock 416 121 308 minecraft:stripped_oak_log
fill 416 121 309 416 121 312 minecraft:red_terracotta
setblock 416 121 313 minecraft:stripped_oak_log
fill 416 121 314 416 124 314 minecraft:red_terracotta
setblock 417 121 277 minecraft:stripped_oak_log
fill 417 121 278 417 124 278 minecraft:red_terracotta
setblock 417 121 282 minecraft:stripped_oak_log
fill 417 121 283 417 124 283 minecraft:red_terracotta
setblock 417 121 287 minecraft:stripped_oak_log
fill 417 121 288 417 124 288 minecraft:red_terracotta
fill 417 121 290 417 122 290 minecraft:red_terracotta
setblock 417 121 292 minecraft:stripped_oak_log
fill 417 121 293 417 121 296 minecraft:red_terracotta
setblock 417 121 297 minecraft:stripped_oak_log
fill 417 121 298 417 124 298 minecraft:red_terracotta
setblock 417 121 302 minecraft:stripped_oak_log
fill 417 121 303 417 121 306 minecraft:red_terracotta
setblock 417 121 307 minecraft:stripped_oak_log
fill 417 121 308 417 124 308 minecraft:red_terracotta
setblock 417 121 312 minecraft:stripped_oak_log
fill 417 121 313 417 124 313 minecraft:red_terracotta
setblock 377 122 276 minecraft:stripped_oak_log
fill 377 122 277 377 123 277 minecraft:red_terracotta
setblock 377 122 281 minecraft:stripped_oak_log
fill 377 122 282 377 124 282 minecraft:red_terracotta
setblock 377 122 286 minecraft:stripped_oak_log
fill 377 122 287 377 122 290 minecraft:red_terracotta
setblock 377 122 291 minecraft:stripped_oak_log
fill 377 122 292 377 125 292 minecraft:red_terracotta
setblock 377 122 296 minecraft:stripped_oak_log
fill 377 122 297 377 125 297 minecraft:red_terracotta
setblock 377 122 301 minecraft:stripped_oak_log
fill 377 122 302 377 125 302 minecraft:red_terracotta
setblock 377 122 306 minecraft:stripped_oak_log
fill 377 122 307 377 125 307 minecraft:red_terracotta
setblock 377 122 311 minecraft:stripped_oak_log
fill 377 122 312 377 125 312 minecraft:red_terracotta
setblock 377 122 316 minecraft:stripped_oak_log
setblock 378 122 276 minecraft:red_terracotta
setblock 378 122 285 minecraft:stripped_oak_log
fill 378 122 286 378 122 289 minecraft:red_terracotta
setblock 378 122 290 minecraft:stripped_oak_log
fill 378 122 291 378 125 291 minecraft:red_terracotta
setblock 378 122 295 minecraft:stripped_oak_log
fill 378 122 296 378 125 296 minecraft:red_terracotta
setblock 378 122 299 minecraft:red_terracotta
setblock 378 122 300 minecraft:stripped_oak_log
fill 378 122 301 378 125 301 minecraft:red_terracotta
setblock 378 122 305 minecraft:stripped_oak_log
fill 378 122 306 378 125 306 minecraft:red_terracotta
setblock 378 122 310 minecraft:stripped_oak_log
fill 378 122 311 378 125 311 minecraft:red_terracotta
setblock 378 122 315 minecraft:stripped_oak_log
fill 378 122 316 378 125 316 minecraft:red_terracotta
fill 379 122 285 379 122 288 minecraft:red_terracotta
setblock 379 122 289 minecraft:stripped_oak_log
fill 379 122 290 379 125 290 minecraft:red_terracotta
setblock 379 122 293 minecraft:red_terracotta
setblock 379 122 300 minecraft:red_terracotta
setblock 379 122 304 minecraft:stripped_oak_log
fill 379 122 305 379 124 305 minecraft:red_terracotta
setblock 379 122 309 minecraft:stripped_oak_log
fill 379 122 310 379 125 310 minecraft:red_terracotta
setblock 379 122 314 minecraft:stripped_oak_log
fill 379 122 315 379 125 315 minecraft:red_terracotta
setblock 380 122 304 minecraft:red_terracotta
setblock 380 122 308 minecraft:stripped_oak_log
fill 380 122 309 380 123 309 minecraft:red_terracotta
setblock 382 122 316 minecraft:stripped_oak_log
fill 393 122 276 393 125 276 minecraft:red_terracotta
fill 394 122 316 396 122 316 minecraft:red_terracotta
setblock 395 122 277 minecraft:red_terracotta
setblock 396 122 277 minecraft:stripped_oak_log
setblock 397 122 276 minecraft:stripped_oak_log
fill 397 122 277 397 125 277 minecraft:red_terracotta
setblock 397 122 315 minecraft:red_terracotta
setblock 397 122 316 minecraft:stripped_oak_log
fill 398 122 276 398 125 276 minecraft:red_terracotta
setblock 398 122 315 minecraft:stripped_oak_log
fill 398 122 316 398 125 316 minecraft:red_terracotta
fill 399 122 315 400 124 315 minecraft:red_terracotta
setblock 401 122 277 minecraft:stripped_oak_log
setblock 401 122 316 minecraft:red_terracotta
setblock 402 122 276 minecraft:stripped_oak_log
setblock 402 122 277 minecraft:red_terracotta
setblock 402 122 316 minecraft:stripped_oak_log
fill 403 122 276 403 125 276 minecraft:red_terracotta
fill 403 122 316 403 125 316 minecraft:red_terracotta
fill 405 122 316 406 122 316 minecraft:red_terracotta
setblock 407 122 276 minecraft:stripped_oak_log
setblock 407 122 316 minecraft:stripped_oak_log
fill 408 122 276 408 123 276 minecraft:red_terracotta
fill 408 122 316 408 125 316 minecraft:red_terracotta
fill 411 122 315 412 122 315 minecraft:red_terracotta
setblock 412 122 276 minecraft:stripped_oak_log
setblock 412 122 316 minecraft:stripped_oak_log
fill 413 122 276 413 125 276 minecraft:red_terracotta
setblock 413 122 314 minecraft:red_terracotta
setblock 413 122 315 minecraft:stripped_oak_log
fill 413 122 316 413 125 316 minecraft:red_terracotta
setblock 414 122 308 minecraft:red_terracotta
setblock 414 122 309 minecraft:stripped_oak_log
fill 414 122 310 415 122 312 minecraft:red_terracotta
setblock 414 122 314 minecraft:stripped_oak_log
fill 414 122 315 414 125 315 minecraft:red_terracotta
setblock 415 122 284 minecraft:red_terracotta
setblock 415 122 288 minecraft:stripped_oak_log
fill 415 122 304 415 122 307 minecraft:red_terracotta
setblock 415 122 308 minecraft:stripped_oak_log
fill 415 122 309 416 124 309 minecraft:red_terracotta
setblock 415 122 313 minecraft:stripped_oak_log
fill 415 122 314 415 125 314 minecraft:red_terracotta
setblock 416 122 277 minecraft:stripped_oak_log
fill 416 122 278 416 123 278 minecraft:red_terracotta
setblock 416 122 282 minecraft:stripped_oak_log
fill 416 122 283 416 124 283 minecraft:red_terracotta
setblock 416 122 287 minecraft:stripped_oak_log
fill 416 122 288 416 125 288 minecraft:red_terracotta
setblock 416 122 291 minecraft:red_terracotta
setblock 416 122 292 minecraft:stripped_oak_log
setblock 416 122 301 minecraft:red_terracotta
setblock 416 122 302 minecraft:stripped_oak_log
fill 416 122 303 416 122 306 minecraft:red_terracotta
setblock 416 122 307 minecraft:stripped_oak_log
fill 416 122 308 416 125 308 minecraft:red_terracotta
fill 416 122 310 416 122 311 minecraft:red_terracotta
setblock 416 122 312 minecraft:stripped_oak_log
fill 416 122 313 416 125 313 minecraft:red_terracotta
setblock 417 122 276 minecraft:stripped_oak_log
fill 417 122 277 417 125 277 minecraft:red_terracotta
setblock 417 122 281 minecraft:stripped_oak_log
fill 417 122 282 417 125 282 minecraft:red_terracotta
setblock 417 122 286 minecraft:stripped_oak_log
fill 417 122 287 417 125 287 minecraft:red_terracotta
setblock 417 122 291 minecraft:stripped_oak_log
fill 417 122 292 417 122 295 minecraft:red_terracotta
setblock 417 122 296 minecraft:stripped_oak_log
fill 417 122 297 417 125 297 minecraft:red_terracotta
setblock 417 122 301 minecraft:stripped_oak_log
fill 417 122 302 417 122 305 minecraft:red_terracotta
setblock 417 122 306 minecraft:stripped_oak_log
fill 417 122 307 417 125 307 minecraft:red_terracotta
setblock 417 122 311 minecraft:stripped_oak_log
fill 417 122 312 417 125 312 minecraft:red_terracotta
setblock 417 122 316 minecraft:stripped_oak_log
setblock 377 123 276 minecraft:red_terracotta
setblock 377 123 280 minecraft:stripped_oak_log
fill 377 123 281 377 124 281 minecraft:red_terracotta
setblock 377 123 285 minecraft:stripped_oak_log
fill 377 123 286 377 123 289 minecraft:red_terracotta
setblock 377 123 290 minecraft:stripped_oak_log
fill 377 123 291 377 126 291 minecraft:red_terracotta
setblock 377 123 294 minecraft:red_terracotta
setblock 377 123 295 minecraft:stripped_oak_log
fill 377 123 296 377 126 296 minecraft:red_terracotta
setblock 377 123 300 minecraft:stripped_oak_log
fill 377 123 301 377 126 301 minecraft:red_terracotta
setblock 377 123 305 minecraft:stripped_oak_log
fill 377 123 306 377 126 306 minecraft:red_terracotta
setblock 377 123 310 minecraft:stripped_oak_log
fill 377 123 311 377 126 311 minecraft:red_terracotta
setblock 377 123 315 minecraft:stripped_oak_log
fill 377 123 316 377 126 316 minecraft:red_terracotta
setblock 378 123 284 minecraft:stripped_oak_log
fill 378 123 285 378 123 288 minecraft:red_terracotta
setblock 378 123 289 minecraft:stripped_oak_log
fill 378 123 290 378 126 290 minecraft:red_terracotta
setblock 378 123 294 minecraft:stripped_oak_log
fill 378 123 295 378 126 295 minecraft:red_terracotta
setblock 378 123 299 minecraft:stripped_oak_log
fill 378 123 300 378 125 300 minecraft:red_terracotta
setblock 378 123 304 minecraft:stripped_oak_log
fill 378 123 305 378 126 305 minecraft:red_terracotta
setblock 378 123 309 minecraft:stripped_oak_log
fill 378 123 310 378 126 310 minecraft:red_terracotta
setblock 378 123 314 minecraft:stripped_oak_log
fill 378 123 315 378 126 315 minecraft:red_terracotta
fill 379 123 286 379 123 287 minecraft:red_terracotta
setblock 379 123 288 minecraft:stripped_oak_log
fill 379 123 289 379 125 289 minecraft:red_terracotta
setblock 379 123 293 minecraft:stripped_oak_log
fill 379 123 294 379 124 294 minecraft:red_terracotta
setblock 379 123 303 minecraft:stripped_oak_log
fill 379 123 304 379 124 304 minecraft:red_terracotta
setblock 379 123 308 minecraft:stripped_oak_log
fill 379 123 309 379 125 309 minecraft:red_terracotta
setblock 379 123 313 minecraft:stripped_oak_log
fill 379 123 314 379 124 314 minecraft:red_terracotta
setblock 380 123 307 minecraft:stripped_oak_log
setblock 380 123 308 minecraft:red_terracotta
setblock 381 123 316 minecraft:stripped_oak_log
fill 393 123 316 395 123 316 minecraft:red_terracotta
setblock 395 123 277 minecraft:stripped_oak_log
fill 395 123 315 396 123 315 minecraft:red_terracotta
setblock 396 123 276 minecraft:stripped_oak_log
fill 396 123 277 396 126 277 minecraft:red_terracotta
setblock 396 123 316 minecraft:stripped_oak_log
fill 397 123 276 397 126 276 minecraft:red_terracotta
setblock 397 123 315 minecraft:stripped_oak_log
fill 397 123 316 397 126 316 minecraft:red_terracotta
fill 398 123 315 398 126 315 minecraft:red_terracotta
setblock 400 123 277 minecraft:stripped_oak_log
setblock 401 123 276 minecraft:stripped_oak_log
setblock 401 123 277 minecraft:red_terracotta
setblock 401 123 316 minecraft:stripped_oak_log
fill 402 123 276 402 126 276 minecraft:red_terracotta
fill 402 123 316 402 126 316 minecraft:red_terracotta
setblock 405 123 316 minecraft:red_terracotta
setblock 406 123 276 minecraft:stripped_oak_log
setblock 406 123 316 minecraft:stripped_oak_log
fill 407 123 316 407 126 316 minecraft:red_terracotta
fill 410 123 315 411 123 315 minecraft:red_terracotta
setblock 411 123 276 minecraft:stripped_oak_log
setblock 411 123 316 minecraft:stripped_oak_log
fill 412 123 276 412 126 276 minecraft:red_terracotta
setblock 412 123 314 minecraft:red_terracotta
setblock 412 123 315 minecraft:stripped_oak_log
fill 412 123 316 412 126 316 minecraft:red_terracotta
setblock 413 123 314 minecraft:stripped_oak_log
fill 413 123 315 413 126 315 minecraft:red_terracotta
setblock 414 123 308 minecraft:stripped_oak_log
fill 414 123 309 414 123 312 minecraft:red_terracotta
setblock 414 123 313 minecraft:stripped_oak_log
fill 414 123 314 414 126 314 minecraft:red_terracotta
setblock 415 123 277 minecraft:stripped_oak_log
setblock 415 123 286 minecraft:red_terracotta
setblock 415 123 287 minecraft:stripped_oak_log
setblock 415 123 288 minecraft:red_terracotta
fill 415 123 304 415 123 306 minecraft:red_terracotta
setblock 415 123 307 minecraft:stripped_oak_log
fill 415 123 308 415 126 308 minecraft:red_terracotta
fill 415 123 310 415 123 311 minecraft:red_terracotta
setblock 415 123 312 minecraft:stripped_oak_log
fill 415 123 313 415 126 313 minecraft:red_terracotta
setblock 416 123 276 minecraft:stripped_oak_log
setblock 416 123 277 minecraft:red_terracotta
setblock 416 123 281 minecraft:stripped_oak_log
setblock 416 123 282 minecraft:red_terracotta
setblock 416 123 286 minecraft:stripped_oak_log
fill 416 123 287 416 126 287 minecraft:red_terracotta
setblock 416 123 291 minecraft:stripped_oak_log
fill 416 123 292 417 124 293 minecraft:red_terracotta
setblock 416 123 301 minecraft:stripped_oak_log
fill 416 123 302 416 123 305 minecraft:red_terracotta
setblock 416 123 306 minecraft:stripped_oak_log
fill 416 123 307 416 126 307 minecraft:red_terracotta
setblock 416 123 310 minecraft:red_terracotta
setblock 416 123 311 minecraft:stripped_oak_log
fill 416 123 312 416 126 312 minecraft:red_terracotta
setblock 416 123 316 minecraft:stripped_oak_log
fill 417 123 276 417 126 276 minecraft:red_terracotta
setblock 417 123 280 minecraft:stripped_oak_log
fill 417 123 281 417 125 281 minecraft:red_terracotta
setblock 417 123 285 minecraft:stripped_oak_log
fill 417 123 286 417 126 286 minecraft:red_terracotta
setblock 417 123 290 minecraft:stripped_oak_log
fill 417 123 291 417 126 291 minecraft:red_terracotta
setblock 417 123 294 minecraft:red_terracotta
setblock 417 123 295 minecraft:stripped_oak_log
fill 417 123 296 417 126 296 minecraft:red_terracotta
setblock 417 123 300 minecraft:stripped_oak_log
fill 417 123 301 417 123 304 minecraft:red_terracotta
setblock 417 123 305 minecraft:stripped_oak_log
fill 417 123 306 417 126 306 minecraft:red_terracotta
setblock 417 123 310 minecraft:stripped_oak_log
fill 417 123 311 417 126 311 minecraft:red_terracotta
setblock 417 123 315 minecraft:stripped_oak_log
fill 417 123 316 417 126 316 minecraft:red_terracotta
fill 376 124 275 376 127 317 minecraft:white_terracotta
fill 377 124 275 418 127 275 minecraft:white_terracotta
setblock 377 124 284 minecraft:stripped_oak_log
fill 377 124 285 377 124 288 minecraft:red_terracotta
setblock 377 124 289 minecraft:stripped_oak_log
fill 377 124 290 377 127 290 minecraft:red_terracotta
setblock 377 124 294 minecraft:stripped_oak_log
fill 377 124 295 377 127 295 minecraft:red_terracotta
setblock 377 124 299 minecraft:stripped_oak_log
fill 377 124 300 377 127 300 minecraft:red_terracotta
setblock 377 124 304 minecraft:stripped_oak_log
fill 377 124 305 377 127 305 minecraft:red_terracotta
setblock 377 124 309 minecraft:stripped_oak_log
fill 377 124 310 377 127 310 minecraft:red_terracotta
setblock 377 124 314 minecraft:stripped_oak_log
fill 377 124 315 377 127 315 minecraft:red_terracotta
fill 377 124 317 418 127 317 minecraft:white_terracotta
fill 378 124 284 378 124 287 minecraft:red_terracotta
setblock 378 124 288 minecraft:stripped_oak_log
fill 378 124 289 378 127 289 minecraft:red_terracotta
setblock 378 124 292 minecraft:red_terracotta
setblock 378 124 293 minecraft:stripped_oak_log
fill 378 124 294 378 127 294 minecraft:red_terracotta
setblock 378 124 298 minecraft:stripped_oak_log
fill 378 124 299 378 126 299 minecraft:red_terracotta
setblock 378 124 303 minecraft:stripped_oak_log
fill 378 124 304 378 126 304 minecraft:red_terracotta
setblock 378 124 308 minecraft:stripped_oak_log
fill 378 124 309 378 127 309 minecraft:red_terracotta
setblock 378 124 313 minecraft:stripped_oak_log
fill 378 124 314 378 127 314 minecraft:red_terracotta
setblock 379 124 287 minecraft:stripped_oak_log
setblock 379 124 288 minecraft:red_terracotta
setblock 379 124 292 minecraft:stripped_oak_log
fill 379 124 293 379 125 293 minecraft:red_terracotta
setblock 379 124 303 minecraft:red_terracotta
setblock 379 124 307 minecraft:stripped_oak_log
fill 379 124 308 379 125 308 minecraft:red_terracotta
setblock 379 124 312 minecraft:stripped_oak_log
fill 379 124 313 379 125 313 minecraft:red_terracotta
setblock 380 124 316 minecraft:stripped_oak_log
setblock 381 124 316 minecraft:red_terracotta
fill 392 124 276 392 126 276 minecraft:red_terracotta
fill 392 124 316 394 124 316 minecraft:red_terracotta
setblock 395 124 276 minecraft:stripped_oak_log
fill 395 124 277 395 127 277 minecraft:red_terracotta
fill 395 124 279 395 126 279 minecraft:green_concrete
setblock 395 124 315 minecraft:red_terracotta
setblock 395 124 316 minecraft:stripped_oak_log
fill 396 124 276 396 127 276 minecraft:red_terracotta
setblock 396 124 315 minecraft:stripped_oak_log
fill 396 124 316 396 127 316 minecraft:red_terracotta
fill 397 124 315 397 127 315 minecraft:red_terracotta
setblock 399 124 277 minecraft:stripped_oak_log
setblock 400 124 276 minecraft:stripped_oak_log
setblock 400 124 277 minecraft:red_terracotta
setblock 400 124 316 minecraft:stripped_oak_log
fill 401 124 276 401 127 276 minecraft:red_terracotta
fill 401 124 316 401 127 316 minecraft:red_terracotta
setblock 405 124 316 minecraft:stripped_oak_log
fill 406 124 289 407 124 291 minecraft:orange_terracotta
fill 406 124 316 406 127 316 minecraft:red_terracotta
fill 407 124 287 408 124 288 minecraft:orange_terracotta
fill 407 124 292 412 124 292 minecraft:orange_terracotta
fill 408 124 293 411 124 293 minecraft:orange_terracotta
fill 409 124 286 410 124 287 minecraft:orange_terracotta
fill 409 124 315 409 124 316 minecraft:red_terracotta
setblock 410 124 276 minecraft:stripped_oak_log
setblock 410 124 315 minecraft:red_terracotta
setblock 410 124 316 minecraft:stripped_oak_log
fill 411 124 276 411 127 276 minecraft:red_terracotta
fill 411 124 287 412 124 288 minecraft:orange_terracotta
setblock 411 124 314 minecraft:red_terracotta
setblock 411 124 315 minecraft:stripped_oak_log
fill 411 124 316 411 127 316 minecraft:red_terracotta
fill 412 124 289 413 124 291 minecraft:orange_terracotta
setblock 412 124 314 minecraft:stripped_oak_log
fill 412 124 315 412 127 315 minecraft:red_terracotta
setblock 413 124 313 minecraft:stripped_oak_log
fill 413 124 314 413 127 314 minecraft:red_terracotta
setblock 414 124 276 minecraft:red_terracotta
fill 414 124 308 414 124 311 minecraft:red_terracotta
setblock 414 124 312 minecraft:stripped_oak_log
fill 414 124 313 414 127 313 minecraft:red_terracotta
setblock 415 124 276 minecraft:stripped_oak_log
setblock 415 124 305 minecraft:red_terracotta
setblock 415 124 306 minecraft:stripped_oak_log
fill 415 124 307 415 127 307 minecraft:red_terracotta
setblock 415 124 310 minecraft:red_terracotta
setblock 415 124 311 minecraft:stripped_oak_log
fill 415 124 312 415 127 312 minecraft:red_terracotta
setblock 415 124 316 minecraft:stripped_oak_log
fill 416 124 276 416 127 276 minecraft:red_terracotta
setblock 416 124 285 minecraft:stripped_oak_log
fill 416 124 286 416 125 286 minecraft:red_terracotta
setblock 416 124 290 minecraft:stripped_oak_log
fill 416 124 291 416 127 291 minecraft:red_terracotta
setblock 416 124 294 minecraft:red_terracotta
fill 416 124 302 416 124 304 minecraft:red_terracotta
setblock 416 124 305 minecraft:stripped_oak_log
fill 416 124 306 416 127 306 minecraft:red_terracotta
setblock 416 124 310 minecraft:stripped_oak_log
fill 416 124 311 416 127 311 minecraft:red_terracotta
setblock 416 124 315 minecraft:stripped_oak_log
fill 416 124 316 416 127 316 minecraft:red_terracotta
setblock 417 124 279 minecraft:stripped_oak_log
fill 417 124 280 417 125 280 minecraft:red_terracotta
setblock 417 124 284 minecraft:stripped_oak_log
fill 417 124 285 417 126 285 minecraft:red_terracotta
setblock 417 124 289 minecraft:stripped_oak_log
fill 417 124 290 417 127 290 minecraft:red_terracotta
setblock 417 124 294 minecraft:stripped_oak_log
fill 417 124 295 417 127 295 minecraft:red_terracotta
setblock 417 124 299 minecraft:stripped_oak_log
fill 417 124 300 417 124 303 minecraft:red_terracotta
setblock 417 124 304 minecraft:stripped_oak_log
fill 417 124 305 417 127 305 minecraft:red_terracotta
setblock 417 124 309 minecraft:stripped_oak_log
fill 417 124 310 417 127 310 minecraft:red_terracotta
setblock 417 124 314 minecraft:stripped_oak_log
fill 417 124 315 417 127 315 minecraft:red_terracotta
fill 418 124 276 418 127 316 minecraft:white_terracotta
setblock 377 125 283 minecraft:stripped_oak_log
fill 377 125 284 377 125 287 minecraft:red_terracotta
setblock 377 125 288 minecraft:stripped_oak_log
fill 377 125 289 377 127 289 minecraft:red_terracotta
setblock 377 125 293 minecraft:stripped_oak_log
fill 377 125 294 377 127 294 minecraft:red_terracotta
setblock 377 125 298 minecraft:stripped_oak_log
fill 377 125 299 377 127 299 minecraft:red_terracotta
setblock 377 125 303 minecraft:stripped_oak_log
fill 377 125 304 377 127 304 minecraft:red_terracotta
setblock 377 125 308 minecraft:stripped_oak_log
fill 377 125 309 377 127 309 minecraft:red_terracotta
setblock 377 125 313 minecraft:stripped_oak_log
fill 377 125 314 377 127 314 minecraft:red_terracotta
setblock 378 125 286 minecraft:red_terracotta
setblock 378 125 287 minecraft:stripped_oak_log
fill 378 125 288 378 127 288 minecraft:red_terracotta
setblock 378 125 292 minecraft:stripped_oak_log
fill 378 125 293 378 127 293 minecraft:red_terracotta
setblock 378 125 297 minecraft:stripped_oak_log
fill 378 125 298 378 127 298 minecraft:red_terracotta
setblock 378 125 302 minecraft:stripped_oak_log
fill 378 125 303 378 126 303 minecraft:red_terracotta
setblock 378 125 307 minecraft:stripped_oak_log
fill 378 125 308 378 127 308 minecraft:red_terracotta
setblock 378 125 312 minecraft:stripped_oak_log
fill 378 125 313 378 127 313 minecraft:red_terracotta
setblock 379 125 278 minecraft:light[level=12]
setblock 379 125 285 minecraft:light[level=12]
setblock 379 125 291 minecraft:stripped_oak_log
fill 379 125 292 379 126 292 minecraft:red_terracotta
setblock 379 125 299 minecraft:light[level=12]
setblock 379 125 306 minecraft:stripped_oak_log
setblock 379 125 307 minecraft:red_terracotta
setblock 379 125 311 minecraft:stripped_oak_log
setblock 379 125 312 minecraft:red_terracotta
setblock 379 125 316 minecraft:stripped_oak_log
fill 380 125 316 380 126 316 minecraft:red_terracotta
setblock 386 125 278 minecraft:light[level=12]
setblock 386 125 285 minecraft:light[level=12]
setblock 386 125 292 minecraft:light[level=12]
setblock 386 125 299 minecraft:light[level=12]
setblock 386 125 306 minecraft:light[level=12]
setblock 386 125 313 minecraft:light[level=12]
fill 392 125 316 393 125 316 minecraft:red_terracotta
setblock 393 125 278 minecraft:light[level=12]
setblock 393 125 285 minecraft:light[level=12]
setblock 393 125 292 minecraft:light[level=12]
setblock 393 125 299 minecraft:light[level=12]
setblock 393 125 306 minecraft:light[level=12]
setblock 393 125 313 minecraft:light[level=12]
setblock 394 125 276 minecraft:stripped_oak_log
setblock 394 125 315 minecraft:red_terracotta
setblock 394 125 316 minecraft:stripped_oak_log
fill 395 125 276 395 127 276 minecraft:red_terracotta
setblock 395 125 315 minecraft:stripped_oak_log
fill 395 125 316 395 127 316 minecraft:red_terracotta
fill 396 125 315 396 127 315 minecraft:red_terracotta
setblock 398 125 277 minecraft:stripped_oak_log
setblock 399 125 276 minecraft:stripped_oak_log
setblock 399 125 277 minecraft:red_terracotta
setblock 399 125 315 minecraft:red_terracotta
setblock 399 125 316 minecraft:stripped_oak_log
fill 400 125 276 400 127 276 minecraft:red_terracotta
setblock 400 125 278 minecraft:light[level=12]
setblock 400 125 285 minecraft:light[level=12]
setblock 400 125 292 minecraft:light[level=12]
setblock 400 125 299 minecraft:light[level=12]
setblock 400 125 306 minecraft:light[level=12]
setblock 400 125 313 minecraft:light[level=12]
setblock 400 125 315 minecraft:stripped_oak_log
fill 400 125 316 400 127 316 minecraft:red_terracotta
setblock 404 125 316 minecraft:stripped_oak_log
fill 405 125 316 405 127 316 minecraft:red_terracotta
setblock 407 125 278 minecraft:light[level=12]
setblock 407 125 285 minecraft:light[level=12]
fill 407 125 288 407 125 291 minecraft:orange_terracotta
setblock 407 125 292 minecraft:light[level=12]
setblock 407 125 299 minecraft:light[level=12]
setblock 407 125 306 minecraft:light[level=12]
setblock 407 125 313 minecraft:light[level=12]
fill 408 125 287 408 125 288 minecraft:orange_terracotta
fill 408 125 292 411 125 292 minecraft:orange_terracotta
fill 408 125 315 409 125 315 minecraft:red_terracotta
setblock 409 125 276 minecraft:stripped_oak_log
fill 409 125 287 411 125 287 minecraft:orange_terracotta
setblock 409 125 316 minecraft:stripped_oak_log
fill 410 125 276 410 127 276 minecraft:red_terracotta
setblock 410 125 315 minecraft:stripped_oak_log
fill 410 125 316 410 127 316 minecraft:red_terracotta
fill 411 125 288 412 125 288 minecraft:orange_terracotta
setblock 411 125 314 minecraft:stripped_oak_log
fill 411 125 315 411 127 315 minecraft:red_terracotta
fill 412 125 289 412 125 291 minecraft:orange_terracotta
fill 412 125 314 412 127 314 minecraft:red_terracotta
fill 413 125 313 413 127 313 minecraft:red_terracotta
setblock 414 125 276 minecraft:stripped_oak_log
setblock 414 125 278 minecraft:light[level=12]
setblock 414 125 285 minecraft:light[level=12]
setblock 414 125 292 minecraft:light[level=12]
setblock 414 125 299 minecraft:light[level=12]
setblock 414 125 306 minecraft:light[level=12]
fill 414 125 309 414 125 310 minecraft:red_terracotta
setblock 414 125 311 minecraft:stripped_oak_log
fill 414 125 312 414 127 312 minecraft:red_terracotta
setblock 414 125 316 minecraft:stripped_oak_log
fill 415 125 276 415 127 276 minecraft:red_terracotta
fill 415 125 306 415 126 306 minecraft:red_terracotta
setblock 415 125 309 minecraft:red_terracotta
setblock 415 125 310 minecraft:stripped_oak_log
fill 415 125 311 415 127 311 minecraft:red_terracotta
setblock 415 125 315 minecraft:stripped_oak_log
fill 415 125 316 415 127 316 minecraft:red_terracotta
setblock 416 125 285 minecraft:red_terracotta
setblock 416 125 289 minecraft:stripped_oak_log
fill 416 125 290 416 127 290 minecraft:red_terracotta
fill 416 125 292 416 125 293 minecraft:red_terracotta
setblock 416 125 294 minecraft:stripped_oak_log
setblock 416 125 303 minecraft:red_terracotta
setblock 416 125 304 minecraft:stripped_oak_log
fill 416 125 305 416 127 305 minecraft:red_terracotta
setblock 416 125 309 minecraft:stripped_oak_log
fill 416 125 310 416 127 310 minecraft:red_terracotta
setblock 416 125 314 minecraft:stripped_oak_log
fill 416 125 315 416 127 315 minecraft:red_terracotta
setblock 417 125 278 minecraft:stripped_oak_log
setblock 417 125 279 minecraft:red_terracotta
setblock 417 125 283 minecraft:stripped_oak_log
fill 417 125 284 417 126 284 minecraft:red_terracotta
setblock 417 125 288 minecraft:stripped_oak_log
fill 417 125 289 417 127 289 minecraft:red_terracotta
setblock 417 125 292 minecraft:red_terracotta
setblock 417 125 293 minecraft:stripped_oak_log
fill 417 125 294 417 127 294 minecraft:red_terracotta
setblock 417 125 298 minecraft:stripped_oak_log
fill 417 125 299 417 125 302 minecraft:red_terracotta
setblock 417 125 303 minecraft:stripped_oak_log
fill 417 125 304 417 127 304 minecraft:red_terracotta
setblock 417 125 308 minecraft:stripped_oak_log
fill 417 125 309 417 127 309 minecraft:red_terracotta
setblock 417 125 313 minecraft:stripped_oak_log
fill 417 125 314 417 127 314 minecraft:red_terracotta
fill 377 126 284 377 126 286 minecraft:red_terracotta
setblock 377 126 287 minecraft:stripped_oak_log
fill 377 126 288 377 127 288 minecraft:red_terracotta
setblock 377 126 292 minecraft:stripped_oak_log
fill 377 126 293 377 127 293 minecraft:red_terracotta
setblock 377 126 297 minecraft:stripped_oak_log
fill 377 126 298 377 127 298 minecraft:red_terracotta
setblock 377 126 302 minecraft:stripped_oak_log
fill 377 126 303 377 127 303 minecraft:red_terracotta
setblock 377 126 307 minecraft:stripped_oak_log
fill 377 126 308 377 127 308 minecraft:red_terracotta
setblock 377 126 312 minecraft:stripped_oak_log
fill 377 126 313 377 127 313 minecraft:red_terracotta
setblock 378 126 287 minecraft:red_terracotta
setblock 378 126 291 minecraft:stripped_oak_log
fill 378 126 292 378 127 292 minecraft:red_terracotta
setblock 378 126 296 minecraft:stripped_oak_log
fill 378 126 297 378 127 297 minecraft:red_terracotta
setblock 378 126 302 minecraft:red_terracotta
setblock 378 126 306 minecraft:stripped_oak_log
fill 378 126 307 378 127 307 minecraft:red_terracotta
setblock 378 126 311 minecraft:stripped_oak_log
fill 378 126 312 378 127 312 minecraft:red_terracotta
setblock 378 126 316 minecraft:stripped_oak_log
setblock 379 126 291 minecraft:red_terracotta
setblock 379 126 310 minecraft:stripped_oak_log
setblock 379 126 311 minecraft:red_terracotta
setblock 379 126 315 minecraft:stripped_oak_log
fill 379 126 316 379 127 316 minecraft:red_terracotta
fill 391 126 316 392 126 316 minecraft:red_terracotta
setblock 393 126 276 minecraft:stripped_oak_log
setblock 393 126 316 minecraft:stripped_oak_log
fill 394 126 276 394 127 277 minecraft:red_terracotta
setblock 394 126 315 minecraft:stripped_oak_log
fill 394 126 316 394 127 316 minecraft:red_terracotta
fill 395 126 315 395 127 315 minecraft:red_terracotta
setblock 397 126 277 minecraft:stripped_oak_log
setblock 398 126 276 minecraft:stripped_oak_log
setblock 398 126 277 minecraft:red_terracotta
setblock 398 126 316 minecraft:stripped_oak_log
fill 399 126 276 399 127 276 minecraft:red_terracotta
setblock 399 126 315 minecraft:stripped_oak_log
fill 399 126 316 399 127 316 minecraft:red_terracotta
setblock 403 126 316 minecraft:stripped_oak_log
fill 404 126 316 404 127 316 minecraft:red_terracotta
fill 407 126 289 407 126 290 minecraft:orange_terracotta
setblock 408 126 288 minecraft:orange_terracotta
setblock 408 126 315 minecraft:red_terracotta
setblock 408 126 316 minecraft:stripped_oak_log
fill 409 126 276 409 127 276 minecraft:red_terracotta
fill 409 126 292 410 126 292 minecraft:orange_terracotta
setblock 409 126 315 minecraft:stripped_oak_log
fill 409 126 316 409 127 316 minecraft:red_terracotta
setblock 410 126 314 minecraft:stripped_oak_log
fill 410 126 315 410 127 315 minecraft:red_terracotta
setblock 411 126 288 minecraft:orange_terracotta
fill 411 126 314 411 127 314 minecraft:red_terracotta
fill 412 126 289 412 126 290 minecraft:orange_terracotta
setblock 413 126 276 minecraft:stripped_oak_log
setblock 413 126 316 minecraft:stripped_oak_log
fill 414 126 276 414 127 276 minecraft:red_terracotta
setblock 414 126 309 minecraft:red_terracotta
setblock 414 126 310 minecraft:stripped_oak_log
fill 414 126 311 414 127 311 minecraft:red_terracotta
setblock 414 126 315 minecraft:stripped_oak_log
fill 414 126 316 414 127 316 minecraft:red_terracotta
setblock 415 126 309 minecraft:stripped_oak_log
fill 415 126 310 415 127 310 minecraft:red_terracotta
setblock 415 126 314 minecraft:stripped_oak_log
fill 415 126 315 415 127 315 minecraft:red_terracotta
setblock 416 126 288 minecraft:stripped_oak_log
fill 416 126 289 416 127 289 minecraft:red_terracotta
setblock 416 126 292 minecraft:red_terracotta
setblock 416 126 293 minecraft:stripped_oak_log
fill 416 126 294 416 127 294 minecraft:red_terracotta
setblock 416 126 304 minecraft:red_terracotta
setblock 416 126 308 minecraft:stripped_oak_log
fill 416 126 309 416 127 309 minecraft:red_terracotta
setblock 416 126 313 minecraft:stripped_oak_log
fill 416 126 314 416 127 314 minecraft:red_terracotta
setblock 417 126 277 minecraft:stripped_oak_log
setblock 417 126 287 minecraft:stripped_oak_log
fill 417 126 288 417 127 288 minecraft:red_terracotta
setblock 417 126 292 minecraft:stripped_oak_log
fill 417 126 293 417 127 293 minecraft:red_terracotta
setblock 417 126 297 minecraft:stripped_oak_log
fill 417 126 298 417 126 301 minecraft:red_terracotta
setblock 417 126 302 minecraft:stripped_oak_log
fill 417 126 303 417 127 303 minecraft:red_terracotta
setblock 417 126 307 minecraft:stripped_oak_log
fill 417 126 308 417 127 308 minecraft:red_terracotta
setblock 417 126 312 minecraft:stripped_oak_log
fill 417 126 313 417 127 313 minecraft:red_terracotta
setblock 377 127 285 minecraft:red_terracotta
setblock 377 127 286 minecraft:stripped_oak_log
setblock 377 127 287 minecraft:red_terracotta
setblock 377 127 291 minecraft:stripped_oak_log
setblock 377 127 292 minecraft:red_terracotta
setblock 377 127 296 minecraft:stripped_oak_log
setblock 377 127 297 minecraft:red_terracotta
setblock 377 127 301 minecraft:stripped_oak_log
setblock 377 127 302 minecraft:red_terracotta
setblock 377 127 306 minecraft:stripped_oak_log
setblock 377 127 307 minecraft:red_terracotta
setblock 377 127 311 minecraft:stripped_oak_log
setblock 377 127 312 minecraft:red_terracotta
setblock 377 127 316 minecraft:stripped_oak_log
setblock 378 127 290 minecraft:stripped_oak_log
setblock 378 127 291 minecraft:red_terracotta
setblock 378 127 295 minecraft:stripped_oak_log
setblock 378 127 296 minecraft:red_terracotta
setblock 378 127 306 minecraft:red_terracotta
setblock 378 127 310 minecraft:stripped_oak_log
setblock 378 127 311 minecraft:red_terracotta
setblock 378 127 315 minecraft:stripped_oak_log
setblock 378 127 316 minecraft:red_terracotta
setblock 379 127 278 minecraft:light[level=15]
setblock 379 127 286 minecraft:light[level=15]
setblock 379 127 294 minecraft:light[level=15]
setblock 379 127 302 minecraft:light[level=15]
setblock 379 127 310 minecraft:light[level=15]
setblock 387 127 278 minecraft:light[level=15]
setblock 387 127 286 minecraft:light[level=15]
setblock 387 127 294 minecraft:light[level=15]
setblock 387 127 302 minecraft:light[level=15]
setblock 387 127 310 minecraft:light[level=15]
setblock 391 127 276 minecraft:red_terracotta
setblock 391 127 316 minecraft:red_terracotta
setblock 392 127 276 minecraft:stripped_oak_log
setblock 392 127 316 minecraft:stripped_oak_log
setblock 393 127 276 minecraft:red_terracotta
setblock 393 127 315 minecraft:stripped_oak_log
setblock 393 127 316 minecraft:red_terracotta
setblock 394 127 315 minecraft:red_terracotta
setblock 395 127 278 minecraft:light[level=15]
setblock 395 127 286 minecraft:light[level=15]
setblock 395 127 302 minecraft:light[level=15]
setblock 395 127 310 minecraft:light[level=15]
setblock 396 127 277 minecraft:stripped_oak_log
setblock 397 127 276 minecraft:stripped_oak_log
setblock 397 127 277 minecraft:red_terracotta
setblock 397 127 316 minecraft:stripped_oak_log
setblock 398 127 276 minecraft:red_terracotta
setblock 398 127 315 minecraft:stripped_oak_log
setblock 398 127 316 minecraft:red_terracotta
setblock 399 127 315 minecraft:red_terracotta
setblock 402 127 276 minecraft:stripped_oak_log
setblock 402 127 316 minecraft:stripped_oak_log
setblock 403 127 278 minecraft:light[level=15]
setblock 403 127 286 minecraft:light[level=15]
setblock 403 127 294 minecraft:light[level=15]
setblock 403 127 302 minecraft:light[level=15]
setblock 403 127 310 minecraft:light[level=15]
setblock 403 127 316 minecraft:red_terracotta
setblock 407 127 315 minecraft:red_terracotta
setblock 407 127 316 minecraft:stripped_oak_log
setblock 408 127 276 minecraft:red_terracotta
setblock 408 127 315 minecraft:stripped_oak_log
setblock 408 127 316 minecraft:red_terracotta
setblock 409 127 315 minecraft:red_terracotta
setblock 410 127 314 minecraft:red_terracotta
setblock 411 127 278 minecraft:light[level=15]
setblock 411 127 286 minecraft:light[level=15]
setblock 411 127 294 minecraft:light[level=15]
setblock 411 127 302 minecraft:light[level=15]
setblock 411 127 310 minecraft:light[level=15]
setblock 412 127 276 minecraft:stripped_oak_log
setblock 412 127 313 minecraft:red_terracotta
setblock 412 127 316 minecraft:stripped_oak_log
setblock 413 127 276 minecraft:red_terracotta
setblock 413 127 315 minecraft:stripped_oak_log
setblock 413 127 316 minecraft:red_terracotta
setblock 414 127 310 minecraft:red_terracotta
setblock 414 127 314 minecraft:stripped_oak_log
setblock 414 127 315 minecraft:red_terracotta
setblock 415 127 308 minecraft:stripped_oak_log
setblock 415 127 309 minecraft:red_terracotta
setblock 415 127 313 minecraft:stripped_oak_log
setblock 415 127 314 minecraft:red_terracotta
setblock 416 127 292 minecraft:stripped_oak_log
setblock 416 127 293 minecraft:red_terracotta
setblock 416 127 307 minecraft:stripped_oak_log
setblock 416 127 308 minecraft:red_terracotta
setblock 416 127 312 minecraft:stripped_oak_log
setblock 416 127 313 minecraft:red_terracotta
setblock 417 127 276 minecraft:stripped_oak_log
setblock 417 127 286 minecraft:stripped_oak_log
setblock 417 127 287 minecraft:red_terracotta
setblock 417 127 291 minecraft:stripped_oak_log
setblock 417 127 292 minecraft:red_terracotta
setblock 417 127 296 minecraft:stripped_oak_log
fill 417 127 297 417 127 300 minecraft:red_terracotta
setblock 417 127 301 minecraft:stripped_oak_log
setblock 417 127 302 minecraft:red_terracotta
setblock 417 127 306 minecraft:stripped_oak_log
setblock 417 127 307 minecraft:red_terracotta
setblock 417 127 311 minecraft:stripped_oak_log
setblock 417 127 312 minecraft:red_terracotta
setblock 417 127 316 minecraft:stripped_oak_log
fill 376 128 275 376 131 317 minecraft:terracotta
fill 377 128 275 418 131 275 minecraft:terracotta
fill 377 128 317 418 131 317 minecraft:terracotta
fill 384 128 278 386 128 280 minecraft:terracotta
fill 418 128 276 418 131 316 minecraft:terracotta
fill 385 129 279 385 132 279 minecraft:green_concrete
setblock 379 131 278 minecraft:light[level=12]
setblock 379 131 285 minecraft:light[level=12]
setblock 379 131 292 minecraft:light[level=12]
setblock 379 131 299 minecraft:light[level=12]
setblock 379 131 306 minecraft:light[level=12]
setblock 379 131 313 minecraft:light[level=12]
setblock 386 131 278 minecraft:light[level=12]
setblock 386 131 285 minecraft:light[level=12]
setblock 386 131 292 minecraft:light[level=12]
setblock 386 131 299 minecraft:light[level=12]
setblock 386 131 306 minecraft:light[level=12]
setblock 386 131 313 minecraft:light[level=12]
setblock 393 131 278 minecraft:light[level=12]
setblock 393 131 285 minecraft:light[level=12]
setblock 393 131 292 minecraft:light[level=12]
setblock 393 131 299 minecraft:light[level=12]
setblock 393 131 306 minecraft:light[level=12]
setblock 393 131 313 minecraft:light[level=12]
setblock 400 131 278 minecraft:light[level=12]
setblock 400 131 285 minecraft:light[level=12]
setblock 400 131 292 minecraft:light[level=12]
setblock 400 131 299 minecraft:light[level=12]
setblock 400 131 306 minecraft:light[level=12]
setblock 400 131 313 minecraft:light[level=12]
fill 402 131 278 404 131 280 minecraft:terracotta
setblock 407 131 278 minecraft:light[level=12]
setblock 407 131 285 minecraft:light[level=12]
setblock 407 131 292 minecraft:light[level=12]
setblock 407 131 299 minecraft:light[level=12]
setblock 407 131 306 minecraft:light[level=12]
setblock 407 131 313 minecraft:light[level=12]
setblock 414 131 278 minecraft:light[level=12]
setblock 414 131 285 minecraft:light[level=12]
setblock 414 131 292 minecraft:light[level=12]
setblock 414 131 299 minecraft:light[level=12]
setblock 414 131 306 minecraft:light[level=12]
setblock 414 131 313 minecraft:light[level=12]
fill 376 132 275 376 135 317 minecraft:brown_terracotta
fill 377 132 275 418 135 275 minecraft:brown_terracotta
fill 377 132 317 418 135 317 minecraft:brown_terracotta
setblock 386 132 279 minecraft:green_concrete
setblock 403 132 279 minecraft:green_concrete
fill 418 132 276 418 135 316 minecraft:brown_terracotta
fill 377 133 276 417 134 277 minecraft:spruce_planks
fill 377 133 278 417 134 278 minecraft:dark_oak_planks
fill 377 133 279 417 134 280 minecraft:spruce_planks
fill 377 133 281 417 134 281 minecraft:dark_oak_planks
fill 377 133 282 417 134 283 minecraft:spruce_planks
fill 377 133 284 417 134 284 minecraft:dark_oak_planks
fill 377 133 285 417 134 286 minecraft:spruce_planks
fill 377 133 287 417 134 287 minecraft:dark_oak_planks
fill 377 133 288 417 134 289 minecraft:spruce_planks
fill 377 133 290 417 134 290 minecraft:dark_oak_planks
fill 377 133 291 395 133 292 minecraft:spruce_planks
fill 377 133 293 393 133 293 minecraft:dark_oak_planks
fill 377 133 294 392 133 295 minecraft:spruce_planks
fill 377 133 296 393 133 296 minecraft:dark_oak_planks
fill 377 133 297 393 133 298 minecraft:spruce_planks
fill 377 133 299 417 133 299 minecraft:dark_oak_planks
fill 377 133 300 417 134 301 minecraft:spruce_planks
fill 377 133 302 417 133 302 minecraft:dark_oak_planks
fill 377 133 303 417 133 304 minecraft:spruce_planks
fill 377 133 305 417 133 305 minecraft:dark_oak_planks
fill 377 133 306 417 133 307 minecraft:spruce_planks
fill 377 133 308 417 134 308 minecraft:dark_oak_planks
fill 377 133 309 417 134 310 minecraft:spruce_planks
fill 377 133 311 417 134 311 minecraft:dark_oak_planks
fill 377 133 312 417 134 313 minecraft:spruce_planks
fill 377 133 314 417 134 314 minecraft:dark_oak_planks
fill 377 133 315 417 134 316 minecraft:spruce_planks
setblock 393 133 294 minecraft:spruce_planks
fill 394 133 298 395 133 298 minecraft:spruce_planks
fill 396 133 291 417 133 291 minecraft:spruce_planks
fill 397 133 292 417 133 292 minecraft:spruce_planks
fill 397 133 298 417 133 298 minecraft:spruce_planks
fill 399 133 293 417 133 293 minecraft:dark_oak_planks
fill 399 133 294 417 133 294 minecraft:spruce_planks
fill 399 133 296 417 133 296 minecraft:dark_oak_planks
fill 399 133 297 417 133 297 minecraft:spruce_planks
fill 400 133 295 417 133 295 minecraft:spruce_planks
fill 377 134 291 392 134 292 minecraft:spruce_planks
fill 377 134 293 392 134 293 minecraft:dark_oak_planks
fill 377 134 294 391 134 295 minecraft:spruce_planks
fill 377 134 296 391 134 296 minecraft:dark_oak_planks
fill 377 134 297 392 134 298 minecraft:spruce_planks
fill 377 134 299 394 134 299 minecraft:dark_oak_planks
fill 377 134 302 385 134 302 minecraft:dark_oak_planks
fill 377 134 303 385 134 304 minecraft:spruce_planks
fill 377 134 305 385 134 305 minecraft:dark_oak_planks
fill 377 134 306 386 134 307 minecraft:spruce_planks
fill 386 134 302 386 134 305 minecraft:ochre_froglight
setblock 387 134 302 minecraft:dark_oak_planks
fill 387 134 303 387 134 304 minecraft:spruce_planks
setblock 387 134 305 minecraft:dark_oak_planks
fill 387 134 306 388 134 306 minecraft:ochre_froglight
fill 387 134 307 417 134 307 minecraft:spruce_planks
fill 388 134 302 388 134 305 minecraft:ochre_froglight
fill 389 134 302 390 134 302 minecraft:dark_oak_planks
fill 389 134 303 389 134 304 minecraft:spruce_planks
setblock 389 134 305 minecraft:dark_oak_planks
fill 389 134 306 390 134 306 minecraft:spruce_planks
fill 390 134 303 390 134 305 minecraft:ochre_froglight
setblock 391 134 302 minecraft:ochre_froglight
fill 391 134 303 391 134 304 minecraft:spruce_planks
setblock 391 134 305 minecraft:dark_oak_planks
setblock 391 134 306 minecraft:ochre_froglight
fill 392 134 294 392 134 296 minecraft:ochre_froglight
fill 392 134 302 394 134 302 minecraft:dark_oak_planks
fill 392 134 303 392 134 305 minecraft:ochre_froglight
fill 392 134 306 394 134 306 minecraft:spruce_planks
fill 393 134 291 394 134 291 minecraft:spruce_planks
fill 393 134 292 393 134 294 minecraft:ochre_froglight
fill 393 134 296 393 134 298 minecraft:ochre_froglight
fill 393 134 303 393 134 304 minecraft:spruce_planks
setblock 393 134 305 minecraft:dark_oak_planks
fill 394 134 292 395 134 292 minecraft:ochre_froglight
fill 394 134 298 395 134 298 minecraft:ochre_froglight
fill 394 134 303 394 134 305 minecraft:ochre_froglight
fill 395 134 291 397 134 291 minecraft:ochre_froglight
fill 395 134 299 397 134 299 minecraft:ochre_froglight
setblock 395 134 302 minecraft:ochre_froglight
fill 395 134 303 395 134 304 minecraft:spruce_planks
setblock 395 134 305 minecraft:dark_oak_planks
setblock 395 134 306 minecraft:ochre_froglight
fill 396 134 302 397 134 302 minecraft:dark_oak_planks
fill 396 134 303 396 134 305 minecraft:ochre_froglight
fill 396 134 306 399 134 306 minecraft:spruce_planks
fill 397 134 292 399 134 292 minecraft:ochre_froglight
fill 397 134 298 399 134 298 minecraft:ochre_froglight
fill 397 134 303 399 134 304 minecraft:spruce_planks
fill 397 134 305 399 134 305 minecraft:dark_oak_planks
fill 398 134 291 417 134 291 minecraft:spruce_planks
fill 398 134 299 417 134 299 minecraft:dark_oak_planks
fill 398 134 302 400 134 302 minecraft:ochre_froglight
fill 399 134 293 399 134 294 minecraft:ochre_froglight
fill 399 134 296 399 134 297 minecraft:ochre_froglight
fill 400 134 292 417 134 292 minecraft:spruce_planks
fill 400 134 293 417 134 293 minecraft:dark_oak_planks
fill 400 134 294 400 134 296 minecraft:ochre_froglight
fill 400 134 297 417 134 298 minecraft:spruce_planks
fill 400 134 303 400 134 306 minecraft:ochre_froglight
fill 401 134 294 417 134 295 minecraft:spruce_planks
fill 401 134 296 417 134 296 minecraft:dark_oak_planks
setblock 401 134 302 minecraft:dark_oak_planks
fill 401 134 303 401 134 304 minecraft:spruce_planks
setblock 401 134 305 minecraft:dark_oak_planks
fill 401 134 306 402 134 306 minecraft:spruce_planks
fill 402 134 302 402 134 305 minecraft:ochre_froglight
setblock 403 134 302 minecraft:dark_oak_planks
setblock 403 134 303 minecraft:spruce_planks
fill 403 134 304 404 134 304 minecraft:ochre_froglight
setblock 403 134 305 minecraft:dark_oak_planks
setblock 403 134 306 minecraft:ochre_froglight
fill 404 134 302 404 134 303 minecraft:ochre_froglight
setblock 404 134 305 minecraft:ochre_froglight
fill 404 134 306 405 134 306 minecraft:spruce_planks
fill 405 134 302 406 134 302 minecraft:dark_oak_planks
fill 405 134 303 405 134 304 minecraft:spruce_planks
fill 405 134 305 407 134 305 minecraft:dark_oak_planks
setblock 406 134 303 minecraft:ochre_froglight
setblock 406 134 304 minecraft:spruce_planks
fill 406 134 306 407 134 306 minecraft:ochre_froglight
fill 407 134 302 408 134 302 minecraft:ochre_froglight
fill 407 134 303 417 134 303 minecraft:spruce_planks
setblock 407 134 304 minecraft:ochre_froglight
fill 408 134 304 417 134 304 minecraft:spruce_planks
setblock 408 134 305 minecraft:ochre_froglight
fill 408 134 306 417 134 306 minecraft:spruce_planks
fill 409 134 302 417 134 302 minecraft:dark_oak_planks
fill 409 134 305 417 134 305 minecraft:dark_oak_planks
setblock 379 135 278 minecraft:light[level=15]
setblock 379 135 286 minecraft:light[level=15]
setblock 379 135 294 minecraft:light[level=15]
setblock 379 135 302 minecraft:light[level=15]
setblock 379 135 310 minecraft:light[level=15]
setblock 385 135 279 minecraft:green_concrete
setblock 387 135 278 minecraft:light[level=15]
setblock 387 135 286 minecraft:light[level=15]
setblock 387 135 294 minecraft:light[level=15]
setblock 387 135 302 minecraft:light[level=15]
setblock 387 135 310 minecraft:light[level=15]
setblock 395 135 278 minecraft:light[level=15]
setblock 395 135 286 minecraft:light[level=15]
setblock 395 135 302 minecraft:light[level=15]
setblock 395 135 310 minecraft:light[level=15]
setblock 403 135 278 minecraft:light[level=15]
fill 403 135 279 404 137 279 minecraft:green_concrete
setblock 403 135 286 minecraft:light[level=15]
setblock 403 135 294 minecraft:light[level=15]
setblock 403 135 302 minecraft:light[level=15]
setblock 403 135 310 minecraft:light[level=15]
setblock 411 135 278 minecraft:light[level=15]
setblock 411 135 286 minecraft:light[level=15]
setblock 411 135 294 minecraft:light[level=15]
setblock 411 135 302 minecraft:light[level=15]
setblock 411 135 310 minecraft:light[level=15]
fill 376 136 275 376 139 317 minecraft:light_gray_terracotta
fill 377 136 275 418 139 275 minecraft:light_gray_terracotta
fill 377 136 317 418 139 317 minecraft:light_gray_terracotta
fill 418 136 276 418 139 316 minecraft:light_gray_terracotta
setblock 379 137 278 minecraft:light[level=12]
setblock 379 137 285 minecraft:light[level=12]
setblock 379 137 292 minecraft:light[level=12]
setblock 379 137 299 minecraft:light[level=12]
setblock 379 137 306 minecraft:light[level=12]
setblock 379 137 313 minecraft:light[level=12]
setblock 386 137 278 minecraft:light[level=12]
setblock 386 137 285 minecraft:light[level=12]
setblock 386 137 292 minecraft:light[level=12]
setblock 386 137 299 minecraft:light[level=12]
setblock 386 137 306 minecraft:light[level=12]
setblock 386 137 313 minecraft:light[level=12]
setblock 393 137 278 minecraft:light[level=12]
setblock 393 137 285 minecraft:light[level=12]
setblock 393 137 292 minecraft:light[level=12]
setblock 393 137 299 minecraft:light[level=12]
setblock 393 137 306 minecraft:light[level=12]
setblock 393 137 313 minecraft:light[level=12]
setblock 400 137 278 minecraft:light[level=12]
setblock 400 137 285 minecraft:light[level=12]
setblock 400 137 292 minecraft:light[level=12]
setblock 400 137 299 minecraft:light[level=12]
setblock 400 137 306 minecraft:light[level=12]
setblock 400 137 313 minecraft:light[level=12]
setblock 407 137 278 minecraft:light[level=12]
setblock 407 137 285 minecraft:light[level=12]
setblock 407 137 292 minecraft:light[level=12]
setblock 407 137 299 minecraft:light[level=12]
setblock 407 137 306 minecraft:light[level=12]
setblock 407 137 313 minecraft:light[level=12]
setblock 414 137 278 minecraft:light[level=12]
setblock 414 137 285 minecraft:light[level=12]
setblock 414 137 292 minecraft:light[level=12]
setblock 414 137 299 minecraft:light[level=12]
setblock 414 137 306 minecraft:light[level=12]
setblock 414 137 313 minecraft:light[level=12]
fill 377 138 276 377 138 279 minecraft:red_terracotta
setblock 377 138 280 minecraft:stripped_oak_log
fill 377 138 281 377 140 282 minecraft:red_terracotta
fill 377 138 291 377 138 294 minecraft:red_terracotta
setblock 377 138 295 minecraft:stripped_oak_log
fill 377 138 296 377 138 299 minecraft:red_terracotta
setblock 377 138 300 minecraft:stripped_oak_log
fill 377 138 301 377 138 304 minecraft:red_terracotta
fill 377 138 305 383 138 314 minecraft:stripped_oak_log
fill 378 138 276 380 138 276 minecraft:red_terracotta
fill 378 138 294 380 149 294 minecraft:stripped_oak_log
fill 378 138 295 378 138 298 minecraft:red_terracotta
fill 378 138 299 380 138 299 minecraft:stripped_oak_log
fill 378 138 300 378 138 302 minecraft:red_terracotta
fill 378 138 303 383 138 304 minecraft:stripped_oak_log
fill 379 138 295 380 154 298 minecraft:stripped_oak_log
fill 379 138 300 380 138 302 minecraft:stripped_oak_log
setblock 381 138 276 minecraft:stripped_oak_log
fill 381 138 277 384 138 277 minecraft:red_terracotta
fill 381 138 278 381 139 278 minecraft:iron_bars
fill 381 138 302 383 138 302 minecraft:stripped_oak_log
fill 382 138 276 385 138 276 minecraft:red_terracotta
setblock 383 138 278 minecraft:red_terracotta
fill 383 138 316 385 138 316 minecraft:red_terracotta
setblock 384 138 278 minecraft:stripped_oak_log
setblock 385 138 277 minecraft:stripped_oak_log
fill 385 138 278 387 138 279 minecraft:red_terracotta
setblock 386 138 276 minecraft:stripped_oak_log
fill 386 138 277 389 138 277 minecraft:red_terracotta
setblock 386 138 316 minecraft:stripped_oak_log
fill 387 138 276 390 138 276 minecraft:red_terracotta
setblock 387 138 315 minecraft:stripped_oak_log
fill 387 138 316 390 138 316 minecraft:red_terracotta
setblock 388 138 278 minecraft:red_terracotta
setblock 388 138 279 minecraft:stripped_oak_log
fill 388 138 315 391 138 315 minecraft:red_terracotta
setblock 389 138 278 minecraft:stripped_oak_log
fill 389 138 279 392 138 279 minecraft:red_terracotta
setblock 390 138 277 minecraft:stripped_oak_log
fill 390 138 278 393 138 278 minecraft:red_terracotta
setblock 391 138 276 minecraft:stripped_oak_log
fill 391 138 277 394 138 277 minecraft:red_terracotta
setblock 391 138 316 minecraft:stripped_oak_log
fill 392 138 276 395 138 276 minecraft:red_terracotta
setblock 392 138 315 minecraft:stripped_oak_log
fill 392 138 316 395 138 316 minecraft:red_terracotta
setblock 393 138 279 minecraft:stripped_oak_log
setblock 393 138 315 minecraft:red_terracotta
setblock 394 138 278 minecraft:stripped_oak_log
setblock 395 138 277 minecraft:stripped_oak_log
fill 395 138 278 397 138 278 minecraft:red_terracotta
setblock 396 138 276 minecraft:stripped_oak_log
fill 396 138 277 399 138 277 minecraft:red_terracotta
setblock 396 138 316 minecraft:stripped_oak_log
fill 397 138 276 400 138 276 minecraft:red_terracotta
fill 397 138 316 400 138 316 minecraft:red_terracotta
setblock 400 138 277 minecraft:stripped_oak_log
setblock 401 138 276 minecraft:stripped_oak_log
fill 401 138 277 404 138 277 minecraft:red_terracotta
setblock 401 138 315 minecraft:red_terracotta
setblock 401 138 316 minecraft:stripped_oak_log
fill 402 138 276 405 138 276 minecraft:red_terracotta
setblock 402 138 315 minecraft:stripped_oak_log
fill 402 138 316 405 138 316 minecraft:red_terracotta
setblock 403 138 278 minecraft:red_terracotta
setblock 403 138 279 minecraft:green_concrete
fill 403 138 315 406 138 315 minecraft:red_terracotta
setblock 404 138 278 minecraft:stripped_oak_log
setblock 405 138 277 minecraft:stripped_oak_log
fill 405 138 278 408 138 278 minecraft:red_terracotta
fill 405 138 314 407 138 314 minecraft:red_terracotta
setblock 406 138 276 minecraft:stripped_oak_log
fill 406 138 277 409 138 277 minecraft:red_terracotta
fill 406 138 280 406 144 280 minecraft:brown_terracotta
setblock 406 138 316 minecraft:stripped_oak_log
fill 407 138 276 410 138 276 minecraft:red_terracotta
setblock 407 138 315 minecraft:stripped_oak_log
fill 407 138 316 410 138 316 minecraft:red_terracotta
setblock 408 138 314 minecraft:stripped_oak_log
fill 408 138 315 411 138 315 minecraft:red_terracotta
setblock 409 138 278 minecraft:stripped_oak_log
fill 409 138 314 412 138 314 minecraft:red_terracotta
setblock 410 138 277 minecraft:stripped_oak_log
fill 410 138 278 411 138 278 minecraft:red_terracotta
setblock 411 138 276 minecraft:stripped_oak_log
fill 411 138 277 414 138 277 minecraft:red_terracotta
setblock 411 138 316 minecraft:stripped_oak_log
fill 412 138 276 415 138 276 minecraft:red_terracotta
setblock 412 138 315 minecraft:stripped_oak_log
fill 412 138 316 415 138 316 minecraft:red_terracotta
fill 413 138 315 414 138 315 minecraft:red_terracotta
setblock 415 138 297 minecraft:stripped_oak_log
fill 415 138 298 415 138 301 minecraft:red_terracotta
setblock 415 138 302 minecraft:stripped_oak_log
fill 415 138 303 417 138 303 minecraft:red_terracotta
setblock 416 138 276 minecraft:stripped_oak_log
setblock 416 138 295 minecraft:red_terracotta
setblock 416 138 296 minecraft:stripped_oak_log
fill 416 138 297 416 138 300 minecraft:red_terracotta
setblock 416 138 301 minecraft:stripped_oak_log
fill 416 138 302 417 140 302 minecraft:red_terracotta
fill 416 138 304 416 138 305 minecraft:red_terracotta
setblock 416 138 316 minecraft:stripped_oak_log
fill 417 138 276 417 138 278 minecraft:red_terracotta
fill 417 138 293 417 138 294 minecraft:red_terracotta
setblock 417 138 295 minecraft:stripped_oak_log
fill 417 138 296 417 138 299 minecraft:red_terracotta
setblock 417 138 300 minecraft:stripped_oak_log
fill 417 138 301 417 141 301 minecraft:red_terracotta
setblock 417 138 304 minecraft:red_terracotta
setblock 417 138 305 minecraft:stripped_oak_log
fill 417 138 306 417 139 307 minecraft:red_terracotta
setblock 417 138 315 minecraft:stripped_oak_log
setblock 417 138 316 minecraft:red_terracotta
fill 377 139 277 377 139 278 minecraft:red_terracotta
setblock 377 139 279 minecraft:stripped_oak_log
fill 377 139 280 377 142 280 minecraft:red_terracotta
fill 377 139 292 377 139 293 minecraft:red_terracotta
setblock 377 139 294 minecraft:stripped_oak_log
fill 377 139 295 377 139 298 minecraft:red_terracotta
setblock 377 139 299 minecraft:stripped_oak_log
fill 377 139 300 378 139 301 minecraft:red_terracotta
setblock 377 139 302 minecraft:shroomlight
setblock 377 139 303 minecraft:red_terracotta
setblock 377 139 304 minecraft:shroomlight
fill 377 139 305 377 145 305 minecraft:stripped_oak_log
setblock 377 139 306 minecraft:shroomlight
fill 377 139 307 377 146 307 minecraft:stripped_oak_log
setblock 377 139 308 minecraft:shroomlight
fill 377 139 309 377 147 309 minecraft:stripped_oak_log
setblock 377 139 310 minecraft:shroomlight
fill 377 139 311 377 148 311 minecraft:stripped_oak_log
setblock 377 139 312 minecraft:shroomlight
fill 377 139 313 377 150 313 minecraft:stripped_oak_log
setblock 377 139 314 minecraft:shroomlight
fill 378 139 295 378 139 297 minecraft:red_terracotta
setblock 378 139 298 minecraft:stripped_oak_log
fill 378 139 299 378 140 299 minecraft:red_terracotta
fill 378 139 302 378 154 302 minecraft:stripped_oak_log
setblock 378 139 303 minecraft:shroomlight
fill 378 139 304 378 148 304 minecraft:stripped_oak_log
setblock 378 139 305 minecraft:shroomlight
fill 378 139 306 378 147 306 minecraft:stripped_oak_log
setblock 378 139 307 minecraft:shroomlight
fill 378 139 308 378 149 308 minecraft:stripped_oak_log
setblock 378 139 309 minecraft:shroomlight
fill 378 139 310 378 149 310 minecraft:stripped_oak_log
setblock 378 139 311 minecraft:shroomlight
fill 378 139 312 378 150 312 minecraft:stripped_oak_log
setblock 378 139 313 minecraft:shroomlight
fill 378 139 314 378 151 314 minecraft:stripped_oak_log
setblock 379 139 276 minecraft:red_terracotta
fill 379 139 299 380 154 301 minecraft:stripped_oak_log
setblock 379 139 302 minecraft:shroomlight
fill 379 139 303 379 154 303 minecraft:stripped_oak_log
setblock 379 139 304 minecraft:shroomlight
fill 379 139 305 379 154 305 minecraft:stripped_oak_log
setblock 379 139 306 minecraft:shroomlight
fill 379 139 307 379 153 307 minecraft:stripped_oak_log
setblock 379 139 308 minecraft:shroomlight
fill 379 139 309 379 153 309 minecraft:stripped_oak_log
setblock 379 139 310 minecraft:shroomlight
fill 379 139 311 379 152 311 minecraft:stripped_oak_log
setblock 379 139 312 minecraft:shroomlight
fill 379 139 313 379 153 313 minecraft:stripped_oak_log
setblock 379 139 314 minecraft:shroomlight
setblock 380 139 276 minecraft:stripped_oak_log
fill 380 139 302 380 154 302 minecraft:stripped_oak_log
setblock 380 139 303 minecraft:shroomlight
fill 380 139 304 380 154 304 minecraft:stripped_oak_log
setblock 380 139 305 minecraft:shroomlight
fill 380 139 306 380 154 306 minecraft:stripped_oak_log
setblock 380 139 307 minecraft:shroomlight
fill 380 139 308 380 153 308 minecraft:stripped_oak_log
setblock 380 139 309 minecraft:shroomlight
fill 380 139 310 380 153 310 minecraft:stripped_oak_log
setblock 380 139 311 minecraft:shroomlight
fill 380 139 312 380 153 312 minecraft:stripped_oak_log
setblock 380 139 313 minecraft:shroomlight
fill 380 139 314 380 153 314 minecraft:stripped_oak_log
fill 381 139 276 383 139 277 minecraft:red_terracotta
setblock 381 139 302 minecraft:shroomlight
fill 381 139 303 381 153 303 minecraft:stripped_oak_log
setblock 381 139 304 minecraft:shroomlight
fill 381 139 305 381 153 305 minecraft:stripped_oak_log
setblock 381 139 306 minecraft:shroomlight
fill 381 139 307 381 153 307 minecraft:stripped_oak_log
setblock 381 139 308 minecraft:shroomlight
fill 381 139 309 381 153 309 minecraft:stripped_oak_log
setblock 381 139 310 minecraft:shroomlight
fill 381 139 311 381 153 311 minecraft:stripped_oak_log
setblock 381 139 312 minecraft:shroomlight
fill 381 139 313 381 153 313 minecraft:stripped_oak_log
setblock 381 139 314 minecraft:shroomlight
fill 382 139 302 382 153 302 minecraft:stripped_oak_log
setblock 382 139 303 minecraft:shroomlight
fill 382 139 304 382 153 304 minecraft:stripped_oak_log
setblock 382 139 305 minecraft:shroomlight
fill 382 139 306 382 153 306 minecraft:stripped_oak_log
setblock 382 139 307 minecraft:shroomlight
fill 382 139 308 382 153 308 minecraft:stripped_oak_log
setblock 382 139 309 minecraft:shroomlight
fill 382 139 310 382 153 310 minecraft:stripped_oak_log
setblock 382 139 311 minecraft:shroomlight
fill 382 139 312 382 153 312 minecraft:stripped_oak_log
setblock 382 139 313 minecraft:shroomlight
fill 382 139 314 382 153 314 minecraft:stripped_oak_log
setblock 383 139 278 minecraft:stripped_oak_log
setblock 383 139 302 minecraft:shroomlight
fill 383 139 303 383 153 303 minecraft:stripped_oak_log
setblock 383 139 304 minecraft:shroomlight
fill 383 139 305 383 153 305 minecraft:stripped_oak_log
setblock 383 139 306 minecraft:shroomlight
fill 383 139 307 383 153 307 minecraft:stripped_oak_log
setblock 383 139 308 minecraft:shroomlight
fill 383 139 309 383 153 309 minecraft:stripped_oak_log
setblock 383 139 310 minecraft:shroomlight
fill 383 139 311 383 153 311 minecraft:stripped_oak_log
setblock 383 139 312 minecraft:shroomlight
fill 383 139 313 383 153 313 minecraft:stripped_oak_log
setblock 383 139 314 minecraft:shroomlight
setblock 384 139 276 minecraft:red_terracotta
setblock 384 139 277 minecraft:stripped_oak_log
fill 384 139 278 387 139 278 minecraft:red_terracotta
setblock 384 139 316 minecraft:red_terracotta
setblock 385 139 276 minecraft:stripped_oak_log
fill 385 139 277 388 139 277 minecraft:red_terracotta
fill 385 139 279 386 139 279 minecraft:red_terracotta
setblock 385 139 316 minecraft:stripped_oak_log
fill 386 139 276 389 139 276 minecraft:red_terracotta
fill 386 139 316 389 139 316 minecraft:red_terracotta
setblock 387 139 279 minecraft:stripped_oak_log
setblock 388 139 278 minecraft:stripped_oak_log
fill 388 139 279 391 139 279 minecraft:red_terracotta
fill 388 139 315 390 139 315 minecraft:red_terracotta
setblock 389 139 277 minecraft:stripped_oak_log
fill 389 139 278 392 139 278 minecraft:red_terracotta
setblock 390 139 276 minecraft:stripped_oak_log
fill 390 139 277 393 139 277 minecraft:red_terracotta
setblock 390 139 316 minecraft:stripped_oak_log
fill 391 139 276 394 139 276 minecraft:red_terracotta
setblock 391 139 315 minecraft:stripped_oak_log
fill 391 139 316 394 139 316 minecraft:red_terracotta
setblock 392 139 279 minecraft:stripped_oak_log
setblock 393 139 278 minecraft:stripped_oak_log
setblock 394 139 277 minecraft:stripped_oak_log
fill 394 139 278 395 139 278 minecraft:red_terracotta
setblock 395 139 276 minecraft:stripped_oak_log
fill 395 139 277 398 139 277 minecraft:red_terracotta
setblock 395 139 316 minecraft:stripped_oak_log
fill 396 139 276 399 139 276 minecraft:red_terracotta
fill 396 139 316 399 139 316 minecraft:red_terracotta
setblock 399 139 277 minecraft:stripped_oak_log
setblock 400 139 276 minecraft:stripped_oak_log
fill 400 139 277 403 139 277 minecraft:red_terracotta
setblock 400 139 316 minecraft:stripped_oak_log
fill 401 139 276 404 139 276 minecraft:red_terracotta
fill 401 139 316 404 139 316 minecraft:red_terracotta
fill 402 139 315 405 139 315 minecraft:red_terracotta
setblock 403 139 278 minecraft:stripped_oak_log
setblock 404 139 277 minecraft:stripped_oak_log
fill 404 139 278 407 139 278 minecraft:red_terracotta
setblock 405 139 276 minecraft:stripped_oak_log
fill 405 139 277 408 139 277 minecraft:red_terracotta
fill 405 139 280 405 144 280 minecraft:brown_terracotta
setblock 405 139 316 minecraft:stripped_oak_log
fill 406 139 276 409 139 276 minecraft:red_terracotta
fill 406 139 279 406 144 279 minecraft:brown_terracotta
fill 406 139 281 406 144 281 minecraft:brown_terracotta
setblock 406 139 314 minecraft:red_terracotta
setblock 406 139 315 minecraft:stripped_oak_log
fill 406 139 316 409 139 316 minecraft:red_terracotta
fill 407 139 280 407 144 280 minecraft:brown_terracotta
setblock 407 139 314 minecraft:stripped_oak_log
fill 407 139 315 410 139 315 minecraft:red_terracotta
setblock 408 139 278 minecraft:stripped_oak_log
fill 408 139 314 410 139 314 minecraft:red_terracotta
setblock 409 139 277 minecraft:stripped_oak_log
fill 409 139 278 410 139 278 minecraft:red_terracotta
setblock 410 139 276 minecraft:stripped_oak_log
fill 410 139 277 413 139 277 minecraft:red_terracotta
setblock 410 139 316 minecraft:stripped_oak_log
fill 411 139 276 414 139 276 minecraft:red_terracotta
setblock 411 139 315 minecraft:stripped_oak_log
fill 411 139 316 414 139 316 minecraft:red_terracotta
fill 412 139 315 413 139 315 minecraft:red_terracotta
fill 414 139 302 414 140 302 minecraft:iron_bars
setblock 415 139 276 minecraft:stripped_oak_log
fill 415 139 299 415 139 300 minecraft:red_terracotta
setblock 415 139 301 minecraft:stripped_oak_log
setblock 415 139 302 minecraft:red_terracotta
setblock 415 139 316 minecraft:stripped_oak_log
fill 416 139 296 416 139 299 minecraft:red_terracotta
setblock 416 139 300 minecraft:stripped_oak_log
fill 416 139 301 416 142 301 minecraft:red_terracotta
fill 416 139 303 416 139 304 minecraft:red_terracotta
setblock 417 139 294 minecraft:stripped_oak_log
fill 417 139 295 417 139 298 minecraft:red_terracotta
setblock 417 139 299 minecraft:stripped_oak_log
fill 417 139 300 417 142 300 minecraft:red_terracotta
setblock 417 139 303 minecraft:red_terracotta
setblock 417 139 304 minecraft:stripped_oak_log
fill 417 139 305 417 142 305 minecraft:red_terracotta
fill 376 140 275 376 143 317 minecraft:orange_terracotta
fill 377 140 275 418 143 275 minecraft:orange_terracotta
setblock 377 140 278 minecraft:stripped_oak_log
fill 377 140 279 377 143 279 minecraft:red_terracotta
setblock 377 140 283 minecraft:stripped_oak_log
fill 377 140 294 377 140 297 minecraft:red_terracotta
setblock 377 140 298 minecraft:stripped_oak_log
fill 377 140 299 377 140 302 minecraft:red_terracotta
fill 377 140 303 378 140 303 minecraft:stripped_oak_log
setblock 377 140 304 minecraft:red_terracotta
fill 377 140 306 377 141 306 minecraft:stripped_oak_log
fill 377 140 308 377 141 308 minecraft:stripped_oak_log
fill 377 140 310 377 141 310 minecraft:stripped_oak_log
fill 377 140 312 377 141 312 minecraft:stripped_oak_log
fill 377 140 314 377 141 314 minecraft:stripped_oak_log
fill 377 140 317 418 143 317 minecraft:orange_terracotta
fill 378 140 295 378 150 297 minecraft:stripped_oak_log
setblock 378 140 298 minecraft:red_terracotta
setblock 378 140 300 minecraft:red_terracotta
fill 378 140 301 378 154 301 minecraft:stripped_oak_log
fill 378 140 305 378 141 305 minecraft:stripped_oak_log
fill 378 140 307 378 141 307 minecraft:stripped_oak_log
fill 378 140 309 378 141 309 minecraft:stripped_oak_log
fill 378 140 311 378 141 311 minecraft:stripped_oak_log
fill 378 140 313 378 141 313 minecraft:stripped_oak_log
fill 379 140 302 379 141 302 minecraft:stripped_oak_log
fill 379 140 304 379 141 304 minecraft:stripped_oak_log
fill 379 140 306 379 141 306 minecraft:stripped_oak_log
fill 379 140 308 379 141 308 minecraft:stripped_oak_log
fill 379 140 310 379 141 310 minecraft:stripped_oak_log
fill 379 140 312 379 141 312 minecraft:stripped_oak_log
fill 379 140 314 379 141 314 minecraft:stripped_oak_log
fill 380 140 276 383 140 276 minecraft:red_terracotta
fill 380 140 303 380 141 303 minecraft:stripped_oak_log
fill 380 140 305 380 141 305 minecraft:stripped_oak_log
fill 380 140 307 380 141 307 minecraft:stripped_oak_log
fill 380 140 309 380 141 309 minecraft:stripped_oak_log
fill 380 140 311 380 141 311 minecraft:stripped_oak_log
fill 380 140 313 380 141 313 minecraft:stripped_oak_log
fill 381 140 277 382 140 277 minecraft:red_terracotta
fill 381 140 302 381 141 302 minecraft:stripped_oak_log
fill 381 140 304 381 141 304 minecraft:stripped_oak_log
fill 381 140 306 381 141 306 minecraft:stripped_oak_log
fill 381 140 308 381 141 308 minecraft:stripped_oak_log
fill 381 140 310 381 141 310 minecraft:stripped_oak_log
fill 381 140 312 381 141 312 minecraft:stripped_oak_log
fill 381 140 314 381 141 314 minecraft:stripped_oak_log
fill 382 140 303 382 141 303 minecraft:stripped_oak_log
fill 382 140 305 382 141 305 minecraft:stripped_oak_log
fill 382 140 307 382 141 307 minecraft:stripped_oak_log
fill 382 140 309 382 141 309 minecraft:stripped_oak_log
fill 382 140 311 382 141 311 minecraft:stripped_oak_log
fill 382 140 313 382 141 313 minecraft:stripped_oak_log
setblock 383 140 277 minecraft:stripped_oak_log
fill 383 140 278 386 140 278 minecraft:red_terracotta
fill 383 140 302 383 141 302 minecraft:stripped_oak_log
fill 383 140 304 383 141 304 minecraft:stripped_oak_log
fill 383 140 306 383 141 306 minecraft:stripped_oak_log
fill 383 140 308 383 141 308 minecraft:stripped_oak_log
fill 383 140 310 383 141 310 minecraft:stripped_oak_log
fill 383 140 312 383 141 312 minecraft:stripped_oak_log
fill 383 140 314 383 141 314 minecraft:stripped_oak_log
setblock 384 140 276 minecraft:stripped_oak_log
fill 384 140 277 387 140 277 minecraft:red_terracotta
setblock 384 140 316 minecraft:stripped_oak_log
fill 385 140 276 388 140 276 minecraft:red_terracotta
setblock 385 140 279 minecraft:red_terracotta
fill 385 140 316 388 140 316 minecraft:red_terracotta
setblock 386 140 279 minecraft:stripped_oak_log
setblock 387 140 278 minecraft:stripped_oak_log
fill 387 140 279 390 140 279 minecraft:red_terracotta
setblock 388 140 277 minecraft:stripped_oak_log
fill 388 140 278 391 140 278 minecraft:red_terracotta
setblock 389 140 276 minecraft:stripped_oak_log
fill 389 140 277 392 140 277 minecraft:red_terracotta
setblock 389 140 316 minecraft:stripped_oak_log
fill 390 140 276 393 140 276 minecraft:red_terracotta
fill 390 140 316 393 140 316 minecraft:red_terracotta
setblock 391 140 279 minecraft:stripped_oak_log
setblock 392 140 278 minecraft:stripped_oak_log
setblock 393 140 277 minecraft:stripped_oak_log
fill 393 140 278 394 140 278 minecraft:red_terracotta
setblock 394 140 276 minecraft:stripped_oak_log
fill 394 140 277 397 140 277 minecraft:red_terracotta
setblock 394 140 316 minecraft:stripped_oak_log
fill 395 140 276 398 140 276 minecraft:red_terracotta
fill 395 140 316 398 140 316 minecraft:red_terracotta
setblock 398 140 277 minecraft:stripped_oak_log
setblock 399 140 276 minecraft:stripped_oak_log
fill 399 140 277 402 140 277 minecraft:red_terracotta
setblock 399 140 316 minecraft:stripped_oak_log
fill 400 140 276 403 140 276 minecraft:red_terracotta
fill 400 140 316 403 140 316 minecraft:red_terracotta
setblock 403 140 277 minecraft:stripped_oak_log
fill 403 140 315 404 140 315 minecraft:red_terracotta
setblock 404 140 276 minecraft:stripped_oak_log
fill 404 140 277 406 140 278 minecraft:red_terracotta
setblock 404 140 316 minecraft:stripped_oak_log
fill 405 140 276 408 140 276 minecraft:red_terracotta
setblock 405 140 315 minecraft:stripped_oak_log
fill 405 140 316 408 140 316 minecraft:red_terracotta
fill 406 140 315 409 140 315 minecraft:red_terracotta
setblock 407 140 277 minecraft:red_terracotta
setblock 407 140 278 minecraft:stripped_oak_log
setblock 408 140 277 minecraft:stripped_oak_log
setblock 408 140 278 minecraft:red_terracotta
setblock 409 140 276 minecraft:stripped_oak_log
fill 409 140 277 411 140 277 minecraft:red_terracotta
setblock 409 140 316 minecraft:stripped_oak_log
fill 410 140 276 413 140 276 minecraft:red_terracotta
setblock 410 140 315 minecraft:stripped_oak_log
fill 410 140 316 413 140 316 minecraft:red_terracotta
setblock 411 140 315 minecraft:red_terracotta
setblock 414 140 316 minecraft:stripped_oak_log
setblock 415 140 302 minecraft:iron_bars
fill 416 140 297 416 140 298 minecraft:red_terracotta
setblock 416 140 299 minecraft:stripped_oak_log
fill 416 140 300 416 142 300 minecraft:red_terracotta
setblock 416 140 303 minecraft:red_terracotta
setblock 416 140 304 minecraft:stripped_oak_log
fill 417 140 295 417 140 297 minecraft:red_terracotta
setblock 417 140 298 minecraft:stripped_oak_log
fill 417 140 299 417 143 299 minecraft:red_terracotta
setblock 417 140 303 minecraft:stripped_oak_log
fill 417 140 304 417 143 304 minecraft:red_terracotta
fill 417 140 306 417 141 306 minecraft:red_terracotta
fill 418 140 276 418 143 316 minecraft:orange_terracotta
setblock 377 141 281 minecraft:red_terracotta
setblock 377 141 282 minecraft:stripped_oak_log
fill 377 141 283 377 144 283 minecraft:red_terracotta
fill 377 141 294 377 147 294 minecraft:stripped_oak_log
fill 377 141 295 377 141 296 minecraft:red_terracotta
setblock 377 141 297 minecraft:stripped_oak_log
fill 377 141 298 377 141 301 minecraft:red_terracotta
setblock 377 141 302 minecraft:stripped_oak_log
fill 377 141 303 377 144 303 minecraft:red_terracotta
setblock 377 141 304 minecraft:stripped_oak_log
fill 378 141 298 378 154 300 minecraft:stripped_oak_log
setblock 378 141 303 minecraft:stripped_oak_log
fill 380 141 276 382 141 276 minecraft:red_terracotta
setblock 381 141 277 minecraft:red_terracotta
setblock 382 141 277 minecraft:stripped_oak_log
setblock 383 141 276 minecraft:stripped_oak_log
fill 383 141 277 385 141 278 minecraft:red_terracotta
fill 384 141 276 387 141 276 minecraft:red_terracotta
setblock 385 141 279 minecraft:stripped_oak_log
fill 385 141 316 387 141 316 minecraft:red_terracotta
setblock 386 141 277 minecraft:red_terracotta
setblock 386 141 278 minecraft:stripped_oak_log
fill 386 141 279 389 141 279 minecraft:red_terracotta
setblock 387 141 277 minecraft:stripped_oak_log
fill 387 141 278 390 141 278 minecraft:red_terracotta
setblock 388 141 276 minecraft:stripped_oak_log
fill 388 141 277 391 141 277 minecraft:red_terracotta
setblock 388 141 316 minecraft:stripped_oak_log
fill 389 141 276 392 141 276 minecraft:red_terracotta
fill 389 141 316 392 141 316 minecraft:red_terracotta
setblock 390 141 279 minecraft:stripped_oak_log
setblock 391 141 278 minecraft:stripped_oak_log
setblock 392 141 277 minecraft:stripped_oak_log
fill 392 141 278 393 141 278 minecraft:red_terracotta
setblock 393 141 276 minecraft:stripped_oak_log
fill 393 141 277 396 141 277 minecraft:red_terracotta
setblock 393 141 316 minecraft:stripped_oak_log
fill 394 141 276 397 141 276 minecraft:red_terracotta
setblock 397 141 277 minecraft:stripped_oak_log
setblock 398 141 276 minecraft:stripped_oak_log
fill 399 141 276 401 141 277 minecraft:red_terracotta
fill 399 141 316 402 141 316 minecraft:red_terracotta
setblock 402 141 276 minecraft:red_terracotta
setblock 402 141 277 minecraft:stripped_oak_log
setblock 403 141 276 minecraft:stripped_oak_log
fill 403 141 277 406 141 277 minecraft:red_terracotta
setblock 403 141 315 minecraft:red_terracotta
setblock 403 141 316 minecraft:stripped_oak_log
fill 404 141 276 407 141 276 minecraft:red_terracotta
setblock 404 141 315 minecraft:stripped_oak_log
fill 404 141 316 407 141 316 minecraft:red_terracotta
setblock 405 141 278 minecraft:red_terracotta
fill 405 141 279 405 144 279 minecraft:brown_terracotta
fill 405 141 281 405 144 281 minecraft:brown_terracotta
fill 405 141 315 408 141 315 minecraft:red_terracotta
setblock 406 141 278 minecraft:stripped_oak_log
setblock 407 141 277 minecraft:stripped_oak_log
fill 407 141 279 407 144 279 minecraft:brown_terracotta
fill 407 141 281 407 144 281 minecraft:brown_terracotta
setblock 408 141 276 minecraft:stripped_oak_log
fill 408 141 277 410 141 277 minecraft:red_terracotta
setblock 408 141 316 minecraft:stripped_oak_log
fill 409 141 276 412 141 276 minecraft:red_terracotta
setblock 409 141 315 minecraft:stripped_oak_log
fill 409 141 316 412 141 316 minecraft:red_terracotta
setblock 410 141 315 minecraft:red_terracotta
setblock 416 141 299 minecraft:red_terracotta
setblock 416 141 302 minecraft:red_terracotta
setblock 416 141 303 minecraft:stripped_oak_log
setblock 416 141 304 minecraft:red_terracotta
setblock 417 141 296 minecraft:red_terracotta
setblock 417 141 297 minecraft:stripped_oak_log
fill 417 141 298 417 144 298 minecraft:red_terracotta
setblock 417 141 302 minecraft:stripped_oak_log
fill 417 141 303 417 144 303 minecraft:red_terracotta
setblock 377 142 281 minecraft:stripped_oak_log
fill 377 142 282 377 145 282 minecraft:red_terracotta
fill 377 142 284 377 143 284 minecraft:red_terracotta
fill 377 142 295 377 148 296 minecraft:stripped_oak_log
fill 377 142 297 377 142 300 minecraft:red_terracotta
setblock 377 142 301 minecraft:stripped_oak_log
setblock 377 142 302 minecraft:shroomlight
setblock 377 142 304 minecraft:shroomlight
setblock 377 142 306 minecraft:shroomlight
setblock 377 142 308 minecraft:shroomlight
setblock 377 142 310 minecraft:shroomlight
setblock 377 142 312 minecraft:shroomlight
setblock 377 142 314 minecraft:shroomlight
setblock 378 142 303 minecraft:shroomlight
setblock 378 142 305 minecraft:shroomlight
setblock 378 142 307 minecraft:shroomlight
setblock 378 142 309 minecraft:shroomlight
setblock 378 142 311 minecraft:shroomlight
setblock 378 142 313 minecraft:shroomlight
setblock 379 142 302 minecraft:shroomlight
setblock 379 142 304 minecraft:shroomlight
setblock 379 142 306 minecraft:shroomlight
setblock 379 142 308 minecraft:shroomlight
setblock 379 142 310 minecraft:shroomlight
setblock 379 142 312 minecraft:shroomlight
setblock 379 142 314 minecraft:shroomlight
fill 380 142 276 381 142 276 minecraft:red_terracotta
setblock 380 142 303 minecraft:shroomlight
setblock 380 142 305 minecraft:shroomlight
setblock 380 142 307 minecraft:shroomlight
setblock 380 142 309 minecraft:shroomlight
setblock 380 142 311 minecraft:shroomlight
setblock 380 142 313 minecraft:shroomlight
setblock 381 142 302 minecraft:shroomlight
setblock 381 142 304 minecraft:shroomlight
setblock 381 142 306 minecraft:shroomlight
setblock 381 142 308 minecraft:shroomlight
setblock 381 142 310 minecraft:shroomlight
setblock 381 142 312 minecraft:shroomlight
setblock 381 142 314 minecraft:shroomlight
setblock 382 142 276 minecraft:stripped_oak_log
fill 382 142 277 385 142 277 minecraft:red_terracotta
setblock 382 142 303 minecraft:shroomlight
setblock 382 142 305 minecraft:shroomlight
setblock 382 142 307 minecraft:shroomlight
setblock 382 142 309 minecraft:shroomlight
setblock 382 142 311 minecraft:shroomlight
setblock 382 142 313 minecraft:shroomlight
fill 383 142 276 386 142 276 minecraft:red_terracotta
fill 383 142 278 384 142 278 minecraft:red_terracotta
setblock 383 142 302 minecraft:shroomlight
setblock 383 142 304 minecraft:shroomlight
setblock 383 142 306 minecraft:shroomlight
setblock 383 142 308 minecraft:shroomlight
setblock 383 142 310 minecraft:shroomlight
setblock 383 142 312 minecraft:shroomlight
setblock 383 142 314 minecraft:shroomlight
setblock 385 142 278 minecraft:stripped_oak_log
fill 385 142 279 388 142 279 minecraft:red_terracotta
fill 385 142 316 386 142 316 minecraft:red_terracotta
setblock 386 142 277 minecraft:stripped_oak_log
fill 386 142 278 389 142 278 minecraft:red_terracotta
setblock 387 142 276 minecraft:stripped_oak_log
fill 387 142 277 390 142 277 minecraft:red_terracotta
setblock 387 142 316 minecraft:stripped_oak_log
fill 388 142 276 391 142 276 minecraft:red_terracotta
fill 388 142 316 390 142 316 minecraft:red_terracotta
setblock 389 142 279 minecraft:stripped_oak_log
setblock 390 142 278 minecraft:stripped_oak_log
setblock 391 142 277 minecraft:stripped_oak_log
setblock 391 142 278 minecraft:red_terracotta
setblock 392 142 276 minecraft:stripped_oak_log
fill 392 142 277 394 142 277 minecraft:red_terracotta
fill 393 142 276 396 142 276 minecraft:red_terracotta
setblock 397 142 276 minecraft:stripped_oak_log
fill 398 142 276 401 142 276 minecraft:red_terracotta
fill 400 142 316 401 142 316 minecraft:red_terracotta
setblock 401 142 277 minecraft:stripped_oak_log
setblock 402 142 276 minecraft:stripped_oak_log
fill 402 142 277 405 142 277 minecraft:red_terracotta
setblock 402 142 316 minecraft:stripped_oak_log
fill 403 142 276 406 142 276 minecraft:red_terracotta
fill 403 142 316 406 142 316 minecraft:red_terracotta
fill 404 142 315 407 142 315 minecraft:red_terracotta
setblock 406 142 277 minecraft:stripped_oak_log
setblock 407 142 276 minecraft:stripped_oak_log
fill 407 142 277 408 142 277 minecraft:red_terracotta
setblock 407 142 316 minecraft:stripped_oak_log
fill 408 142 276 411 142 276 minecraft:red_terracotta
setblock 408 142 315 minecraft:stripped_oak_log
fill 408 142 316 411 142 316 minecraft:red_terracotta
setblock 416 142 302 minecraft:stripped_oak_log
fill 416 142 303 416 145 303 minecraft:red_terracotta
fill 417 142 297 417 143 297 minecraft:red_terracotta
setblock 417 142 301 minecraft:stripped_oak_log
fill 417 142 302 417 145 302 minecraft:red_terracotta
setblock 417 142 306 minecraft:stripped_oak_log
setblock 377 143 280 minecraft:stripped_oak_log
fill 377 143 281 377 146 281 minecraft:red_terracotta
setblock 377 143 285 minecraft:stripped_oak_log
fill 377 143 297 377 148 297 minecraft:stripped_oak_log
fill 377 143 298 377 143 299 minecraft:red_terracotta
setblock 377 143 300 minecraft:stripped_oak_log
fill 377 143 301 377 144 302 minecraft:red_terracotta
fill 377 143 304 377 144 304 minecraft:stripped_oak_log
fill 377 143 306 377 144 306 minecraft:stripped_oak_log
fill 377 143 308 377 144 308 minecraft:stripped_oak_log
fill 377 143 310 377 144 310 minecraft:stripped_oak_log
fill 377 143 312 377 144 312 minecraft:stripped_oak_log
fill 377 143 314 377 144 314 minecraft:stripped_oak_log
fill 378 143 303 378 144 303 minecraft:stripped_oak_log
fill 378 143 305 378 144 305 minecraft:stripped_oak_log
fill 378 143 307 378 144 307 minecraft:stripped_oak_log
fill 378 143 309 378 144 309 minecraft:stripped_oak_log
fill 378 143 311 378 144 311 minecraft:stripped_oak_log
fill 378 143 313 378 144 313 minecraft:stripped_oak_log
setblock 379 143 278 minecraft:light[level=15]
setblock 379 143 285 minecraft:light[level=12]
setblock 379 143 286 minecraft:light[level=15]
setblock 379 143 292 minecraft:light[level=12]
fill 379 143 302 379 144 302 minecraft:stripped_oak_log
fill 379 143 304 379 144 304 minecraft:stripped_oak_log
fill 379 143 306 379 144 306 minecraft:stripped_oak_log
fill 379 143 308 379 144 308 minecraft:stripped_oak_log
fill 379 143 310 379 144 310 minecraft:stripped_oak_log
fill 379 143 312 379 144 312 minecraft:stripped_oak_log
fill 379 143 314 379 144 314 minecraft:stripped_oak_log
setblock 380 143 276 minecraft:red_terracotta
fill 380 143 303 380 144 303 minecraft:stripped_oak_log
fill 380 143 305 380 144 305 minecraft:stripped_oak_log
fill 380 143 307 380 144 307 minecraft:stripped_oak_log
fill 380 143 309 380 144 309 minecraft:stripped_oak_log
fill 380 143 311 380 144 311 minecraft:stripped_oak_log
fill 380 143 313 380 144 313 minecraft:stripped_oak_log
setblock 381 143 276 minecraft:stripped_oak_log
fill 381 143 302 381 144 302 minecraft:stripped_oak_log
fill 381 143 304 381 144 304 minecraft:stripped_oak_log
fill 381 143 306 381 144 306 minecraft:stripped_oak_log
fill 381 143 308 381 144 308 minecraft:stripped_oak_log
fill 381 143 310 381 144 310 minecraft:stripped_oak_log
fill 381 143 312 381 144 312 minecraft:stripped_oak_log
fill 381 143 314 381 144 314 minecraft:stripped_oak_log
fill 382 143 276 384 143 277 minecraft:red_terracotta
fill 382 143 303 382 144 303 minecraft:stripped_oak_log
fill 382 143 305 382 144 305 minecraft:stripped_oak_log
fill 382 143 307 382 144 307 minecraft:stripped_oak_log
fill 382 143 309 382 144 309 minecraft:stripped_oak_log
fill 382 143 311 382 144 311 minecraft:stripped_oak_log
fill 382 143 313 382 144 313 minecraft:stripped_oak_log
setblock 383 143 278 minecraft:red_terracotta
fill 383 143 302 383 144 302 minecraft:stripped_oak_log
fill 383 143 304 383 144 304 minecraft:stripped_oak_log
fill 383 143 306 383 144 306 minecraft:stripped_oak_log
fill 383 143 308 383 144 308 minecraft:stripped_oak_log
fill 383 143 310 383 144 310 minecraft:stripped_oak_log
fill 383 143 312 383 144 312 minecraft:stripped_oak_log
fill 383 143 314 383 144 314 minecraft:stripped_oak_log
setblock 384 143 278 minecraft:stripped_oak_log
setblock 385 143 276 minecraft:red_terracotta
setblock 385 143 277 minecraft:stripped_oak_log
fill 385 143 278 387 143 279 minecraft:red_terracotta
setblock 386 143 276 minecraft:stripped_oak_log
fill 386 143 277 389 143 277 minecraft:red_terracotta
setblock 386 143 285 minecraft:light[level=12]
setblock 386 143 292 minecraft:light[level=12]
setblock 386 143 299 minecraft:light[level=12]
setblock 386 143 306 minecraft:light[level=12]
setblock 386 143 313 minecraft:light[level=12]
setblock 386 143 316 minecraft:stripped_oak_log
fill 387 143 276 390 143 276 minecraft:red_terracotta
setblock 387 143 286 minecraft:light[level=15]
setblock 387 143 294 minecraft:light[level=15]
setblock 387 143 302 minecraft:light[level=15]
setblock 387 143 310 minecraft:light[level=15]
fill 387 143 316 388 143 316 minecraft:red_terracotta
setblock 388 143 278 minecraft:red_terracotta
setblock 389 143 278 minecraft:stripped_oak_log
setblock 390 143 277 minecraft:stripped_oak_log
setblock 390 143 278 minecraft:red_terracotta
setblock 391 143 276 minecraft:stripped_oak_log
fill 391 143 277 392 143 277 minecraft:red_terracotta
fill 392 143 276 395 143 276 minecraft:red_terracotta
setblock 393 143 278 minecraft:light[level=12]
setblock 393 143 285 minecraft:light[level=12]
setblock 393 143 292 minecraft:light[level=12]
setblock 393 143 299 minecraft:light[level=12]
setblock 393 143 306 minecraft:light[level=12]
setblock 393 143 313 minecraft:light[level=12]
setblock 395 143 278 minecraft:light[level=15]
setblock 395 143 286 minecraft:light[level=15]
setblock 395 143 294 minecraft:light[level=15]
setblock 395 143 302 minecraft:light[level=15]
setblock 395 143 310 minecraft:light[level=15]
setblock 396 143 276 minecraft:stripped_oak_log
fill 397 143 276 400 143 276 minecraft:red_terracotta
setblock 400 143 278 minecraft:light[level=12]
setblock 400 143 285 minecraft:light[level=12]
setblock 400 143 292 minecraft:light[level=12]
setblock 400 143 299 minecraft:light[level=12]
setblock 400 143 306 minecraft:light[level=12]
setblock 400 143 313 minecraft:light[level=12]
setblock 400 143 316 minecraft:red_terracotta
setblock 401 143 276 minecraft:stripped_oak_log
setblock 401 143 316 minecraft:stripped_oak_log
fill 402 143 276 404 143 277 minecraft:red_terracotta
fill 402 143 316 405 143 316 minecraft:red_terracotta
setblock 403 143 278 minecraft:light[level=15]
setblock 403 143 286 minecraft:light[level=15]
setblock 403 143 294 minecraft:light[level=15]
setblock 403 143 302 minecraft:light[level=15]
setblock 403 143 310 minecraft:light[level=15]
fill 404 143 315 406 143 315 minecraft:red_terracotta
setblock 405 143 276 minecraft:red_terracotta
setblock 405 143 277 minecraft:stripped_oak_log
setblock 406 143 276 minecraft:stripped_oak_log
fill 406 143 277 407 143 277 minecraft:red_terracotta
setblock 406 143 316 minecraft:stripped_oak_log
fill 407 143 276 409 143 276 minecraft:red_terracotta
setblock 407 143 278 minecraft:light[level=12]
setblock 407 143 285 minecraft:light[level=12]
setblock 407 143 292 minecraft:light[level=12]
setblock 407 143 299 minecraft:light[level=12]
setblock 407 143 306 minecraft:light[level=12]
setblock 407 143 313 minecraft:light[level=12]
fill 407 143 316 410 143 316 minecraft:red_terracotta
setblock 411 143 278 minecraft:light[level=15]
setblock 411 143 286 minecraft:light[level=15]
setblock 411 143 294 minecraft:light[level=15]
setblock 411 143 302 minecraft:light[level=15]
setblock 411 143 310 minecraft:light[level=15]
setblock 414 143 278 minecraft:light[level=12]
setblock 414 143 285 minecraft:light[level=12]
setblock 414 143 292 minecraft:light[level=12]
setblock 414 143 299 minecraft:light[level=12]
setblock 414 143 306 minecraft:light[level=12]
setblock 414 143 313 minecraft:light[level=12]
setblock 416 143 301 minecraft:stripped_oak_log
fill 416 143 302 416 146 302 minecraft:red_terracotta
setblock 417 143 300 minecraft:stripped_oak_log
fill 417 143 301 417 146 301 minecraft:red_terracotta
setblock 417 143 305 minecraft:stripped_oak_log
fill 417 143 306 417 146 306 minecraft:red_terracotta
fill 376 144 275 376 147 317 minecraft:red_terracotta
fill 377 144 275 418 147 275 minecraft:red_terracotta
setblock 377 144 279 minecraft:stripped_oak_log
fill 377 144 280 377 147 280 minecraft:red_terracotta
setblock 377 144 284 minecraft:stripped_oak_log
fill 377 144 285 377 145 287 minecraft:red_terracotta
fill 377 144 298 377 146 299 minecraft:stripped_oak_log
fill 377 144 300 377 147 300 minecraft:red_terracotta
fill 377 144 317 418 147 317 minecraft:red_terracotta
setblock 378 144 282 minecraft:red_terracotta
setblock 378 144 283 minecraft:stripped_oak_log
fill 378 144 284 378 147 284 minecraft:red_terracotta
setblock 380 144 276 minecraft:stripped_oak_log
fill 381 144 276 383 144 277 minecraft:red_terracotta
setblock 383 144 278 minecraft:stripped_oak_log
setblock 384 144 276 minecraft:red_terracotta
setblock 384 144 277 minecraft:stripped_oak_log
fill 384 144 278 387 144 278 minecraft:red_terracotta
setblock 385 144 276 minecraft:stripped_oak_log
fill 385 144 277 388 144 277 minecraft:red_terracotta
fill 385 144 279 386 144 279 minecraft:red_terracotta
fill 386 144 276 389 144 276 minecraft:red_terracotta
schedule function dropper:buildpart/68_4 1t
