fill 241 114 261 241 115 261 minecraft:cyan_terracotta
fill 241 114 269 241 115 269 minecraft:cyan_terracotta
fill 243 114 229 243 115 229 minecraft:light_gray_concrete
fill 243 114 237 243 115 237 minecraft:light_gray_concrete
fill 243 114 261 243 115 261 minecraft:cyan_terracotta
fill 243 114 269 243 115 269 minecraft:cyan_terracotta
fill 244 114 230 244 115 230 minecraft:light_gray_concrete
fill 244 114 232 244 115 232 minecraft:light_gray_concrete
fill 244 114 234 244 115 234 minecraft:light_gray_concrete
fill 244 114 236 244 115 236 minecraft:light_gray_concrete
fill 244 114 262 244 115 262 minecraft:cyan_terracotta
fill 244 114 264 244 115 264 minecraft:cyan_terracotta
fill 244 114 266 244 115 266 minecraft:cyan_terracotta
fill 244 114 268 244 115 268 minecraft:cyan_terracotta
fill 249 114 230 249 115 230 minecraft:light_gray_concrete
fill 249 114 232 249 115 232 minecraft:light_gray_concrete
fill 249 114 265 249 115 265 minecraft:cyan_terracotta
fill 249 114 267 249 115 267 minecraft:cyan_terracotta
fill 250 114 229 250 115 229 minecraft:light_gray_concrete
fill 250 114 234 250 115 234 minecraft:light_gray_concrete
fill 250 114 264 250 115 264 minecraft:cyan_terracotta
fill 250 114 269 250 115 269 minecraft:cyan_terracotta
fill 252 114 229 252 115 229 minecraft:light_gray_concrete
fill 252 114 234 252 115 234 minecraft:light_gray_concrete
fill 252 114 264 252 115 264 minecraft:cyan_terracotta
fill 252 114 269 252 115 269 minecraft:cyan_terracotta
fill 254 114 229 254 115 229 minecraft:light_gray_concrete
fill 254 114 234 254 115 234 minecraft:light_gray_concrete
fill 254 114 264 254 115 264 minecraft:cyan_terracotta
fill 254 114 269 254 115 269 minecraft:cyan_terracotta
fill 256 114 229 256 115 229 minecraft:light_gray_concrete
fill 256 114 234 256 115 234 minecraft:light_gray_concrete
fill 256 114 264 256 115 264 minecraft:cyan_terracotta
fill 256 114 269 256 115 269 minecraft:cyan_terracotta
fill 258 114 229 258 115 229 minecraft:light_gray_concrete
fill 258 114 234 258 115 234 minecraft:light_gray_concrete
fill 258 114 264 258 115 264 minecraft:cyan_terracotta
fill 258 114 269 258 115 269 minecraft:cyan_terracotta
setblock 259 114 228 minecraft:verdant_froglight
fill 260 114 228 262 117 228 minecraft:black_concrete
fill 260 114 229 260 115 229 minecraft:light_gray_concrete
fill 260 114 234 260 115 234 minecraft:light_gray_concrete
fill 260 114 264 260 115 264 minecraft:cyan_terracotta
fill 260 114 269 260 115 269 minecraft:cyan_terracotta
setblock 261 114 270 minecraft:sea_lantern
fill 262 114 230 262 115 230 minecraft:light_gray_concrete
fill 262 114 232 262 115 232 minecraft:light_gray_concrete
fill 262 114 265 262 115 265 minecraft:cyan_terracotta
fill 262 114 267 262 115 267 minecraft:cyan_terracotta
fill 262 114 270 262 155 270 minecraft:black_concrete
fill 268 114 230 268 115 230 minecraft:cyan_terracotta
fill 268 114 232 268 115 232 minecraft:cyan_terracotta
fill 268 114 234 268 115 234 minecraft:cyan_terracotta
fill 268 114 236 268 115 236 minecraft:cyan_terracotta
fill 268 114 262 268 115 262 minecraft:light_gray_concrete
fill 268 114 264 268 115 264 minecraft:light_gray_concrete
fill 268 114 266 268 115 266 minecraft:light_gray_concrete
fill 268 114 268 268 115 268 minecraft:light_gray_concrete
fill 269 114 229 269 115 229 minecraft:cyan_terracotta
fill 269 114 237 269 115 237 minecraft:cyan_terracotta
fill 269 114 261 269 115 261 minecraft:light_gray_concrete
fill 269 114 269 269 115 269 minecraft:light_gray_concrete
fill 271 114 229 271 115 229 minecraft:cyan_terracotta
fill 271 114 237 271 115 237 minecraft:cyan_terracotta
fill 271 114 243 271 115 243 minecraft:light_gray_concrete
fill 271 114 245 271 115 245 minecraft:light_gray_concrete
fill 271 114 247 271 115 247 minecraft:light_gray_concrete
fill 271 114 249 271 115 249 minecraft:light_gray_concrete
fill 271 114 251 271 115 251 minecraft:light_gray_concrete
fill 271 114 253 271 115 253 minecraft:light_gray_concrete
fill 271 114 261 271 115 261 minecraft:light_gray_concrete
fill 271 114 269 271 115 269 minecraft:light_gray_concrete
fill 272 114 242 272 115 242 minecraft:light_gray_concrete
fill 272 114 255 272 115 255 minecraft:light_gray_concrete
fill 273 114 229 273 115 229 minecraft:cyan_terracotta
fill 273 114 237 273 115 237 minecraft:cyan_terracotta
fill 273 114 261 273 115 261 minecraft:light_gray_concrete
fill 273 114 269 273 115 269 minecraft:light_gray_concrete
setblock 274 114 228 minecraft:blue_concrete
fill 274 114 242 274 115 242 minecraft:light_gray_concrete
fill 274 114 255 274 115 255 minecraft:light_gray_concrete
fill 275 114 229 275 115 229 minecraft:cyan_terracotta
fill 275 114 237 275 115 237 minecraft:cyan_terracotta
fill 275 114 261 275 115 261 minecraft:light_gray_concrete
fill 275 114 269 275 115 269 minecraft:light_gray_concrete
fill 276 114 230 276 115 230 minecraft:cyan_terracotta
fill 276 114 232 276 115 232 minecraft:cyan_terracotta
fill 276 114 234 276 115 234 minecraft:cyan_terracotta
fill 276 114 236 276 115 236 minecraft:cyan_terracotta
fill 276 114 243 276 115 243 minecraft:light_gray_concrete
fill 276 114 245 276 115 245 minecraft:light_gray_concrete
fill 276 114 247 276 115 247 minecraft:light_gray_concrete
fill 276 114 249 276 115 249 minecraft:light_gray_concrete
fill 276 114 251 276 115 251 minecraft:light_gray_concrete
fill 276 114 253 276 115 253 minecraft:light_gray_concrete
fill 276 114 262 276 115 262 minecraft:light_gray_concrete
fill 276 114 264 276 115 264 minecraft:light_gray_concrete
fill 276 114 266 276 115 266 minecraft:light_gray_concrete
fill 276 114 268 276 115 268 minecraft:light_gray_concrete
fill 277 114 229 277 173 229 minecraft:black_concrete
fill 277 114 243 277 154 243 minecraft:black_concrete
setblock 277 114 244 minecraft:sea_lantern
setblock 277 114 252 minecraft:ochre_froglight
setblock 235 115 255 minecraft:magenta_concrete
setblock 238 115 238 minecraft:light[level=12]
setblock 238 115 239 minecraft:light[level=15]
setblock 238 115 259 minecraft:light[level=12]
setblock 239 115 228 minecraft:sea_lantern
fill 240 115 228 241 135 228 minecraft:black_concrete
setblock 245 115 231 minecraft:light[level=12]
setblock 245 115 238 minecraft:light[level=12]
setblock 245 115 245 minecraft:light[level=12]
setblock 245 115 252 minecraft:light[level=12]
setblock 245 115 259 minecraft:light[level=12]
setblock 245 115 266 minecraft:light[level=12]
setblock 246 115 231 minecraft:light[level=15]
setblock 246 115 239 minecraft:light[level=15]
setblock 246 115 247 minecraft:light[level=15]
setblock 246 115 255 minecraft:light[level=15]
setblock 246 115 263 minecraft:light[level=15]
setblock 252 115 238 minecraft:light[level=12]
setblock 252 115 245 minecraft:light[level=12]
setblock 252 115 252 minecraft:light[level=12]
setblock 252 115 259 minecraft:light[level=12]
setblock 254 115 239 minecraft:light[level=15]
setblock 254 115 247 minecraft:light[level=15]
setblock 254 115 255 minecraft:light[level=15]
setblock 254 115 263 minecraft:light[level=15]
setblock 257 115 270 minecraft:blue_concrete
setblock 259 115 228 minecraft:black_concrete
setblock 259 115 238 minecraft:light[level=12]
setblock 259 115 245 minecraft:light[level=12]
setblock 259 115 252 minecraft:light[level=12]
setblock 259 115 259 minecraft:light[level=12]
setblock 261 115 270 minecraft:ochre_froglight
setblock 262 115 239 minecraft:light[level=15]
setblock 262 115 247 minecraft:light[level=15]
setblock 262 115 255 minecraft:light[level=15]
setblock 262 115 263 minecraft:light[level=15]
setblock 266 115 231 minecraft:light[level=12]
setblock 266 115 238 minecraft:light[level=12]
setblock 266 115 245 minecraft:light[level=12]
setblock 266 115 252 minecraft:light[level=12]
setblock 266 115 259 minecraft:light[level=12]
setblock 266 115 266 minecraft:light[level=12]
setblock 270 115 239 minecraft:light[level=15]
setblock 270 115 247 minecraft:light[level=15]
setblock 270 115 255 minecraft:light[level=15]
setblock 273 115 238 minecraft:light[level=12]
setblock 273 115 259 minecraft:light[level=12]
fill 274 115 228 274 308 228 minecraft:black_concrete
fill 277 115 244 277 150 244 minecraft:black_concrete
fill 277 115 252 277 153 252 minecraft:black_concrete
setblock 277 115 261 minecraft:ochre_froglight
setblock 235 116 248 minecraft:purple_concrete
fill 235 116 255 235 135 255 minecraft:black_concrete
setblock 235 116 258 minecraft:pearlescent_froglight
setblock 236 116 230 minecraft:cyan_stained_glass
setblock 236 116 232 minecraft:black_stained_glass
setblock 236 116 234 minecraft:black_stained_glass
setblock 236 116 236 minecraft:sea_lantern
setblock 236 116 243 minecraft:ochre_froglight
setblock 236 116 245 minecraft:black_stained_glass
setblock 236 116 247 minecraft:cyan_stained_glass
setblock 236 116 249 minecraft:sea_lantern
setblock 236 116 251 minecraft:pearlescent_froglight
setblock 236 116 253 minecraft:light_blue_stained_glass
setblock 236 116 262 minecraft:black_stained_glass
setblock 236 116 264 minecraft:sea_lantern
setblock 236 116 266 minecraft:black_stained_glass
setblock 236 116 268 minecraft:pearlescent_froglight
setblock 237 116 229 minecraft:sea_lantern
setblock 237 116 237 minecraft:magenta_stained_glass
setblock 237 116 242 minecraft:ochre_froglight
setblock 237 116 255 minecraft:pearlescent_froglight
setblock 237 116 261 minecraft:sea_lantern
setblock 237 116 269 minecraft:sea_lantern
fill 239 116 228 239 140 228 minecraft:black_concrete
setblock 239 116 229 minecraft:pearlescent_froglight
setblock 239 116 237 minecraft:sea_lantern
setblock 239 116 242 minecraft:light_blue_stained_glass
setblock 239 116 255 minecraft:black_stained_glass
setblock 239 116 261 minecraft:black_stained_glass
setblock 239 116 269 minecraft:black_stained_glass
setblock 241 116 229 minecraft:pearlescent_froglight
setblock 241 116 237 minecraft:pearlescent_froglight
setblock 241 116 243 minecraft:magenta_stained_glass
setblock 241 116 245 minecraft:sea_lantern
setblock 241 116 247 minecraft:black_stained_glass
setblock 241 116 249 minecraft:light_blue_stained_glass
setblock 241 116 251 minecraft:ochre_froglight
setblock 241 116 253 minecraft:ochre_froglight
setblock 241 116 261 minecraft:ochre_froglight
setblock 241 116 269 minecraft:black_stained_glass
setblock 243 116 229 minecraft:black_stained_glass
setblock 243 116 237 minecraft:sea_lantern
setblock 243 116 261 minecraft:black_stained_glass
setblock 243 116 269 minecraft:ochre_froglight
setblock 244 116 230 minecraft:magenta_stained_glass
setblock 244 116 232 minecraft:ochre_froglight
setblock 244 116 234 minecraft:black_stained_glass
setblock 244 116 236 minecraft:pearlescent_froglight
setblock 244 116 262 minecraft:sea_lantern
setblock 244 116 264 minecraft:black_stained_glass
setblock 244 116 266 minecraft:black_stained_glass
setblock 244 116 268 minecraft:magenta_stained_glass
setblock 249 116 230 minecraft:black_stained_glass
setblock 249 116 232 minecraft:black_stained_glass
setblock 249 116 265 minecraft:magenta_stained_glass
setblock 249 116 267 minecraft:black_stained_glass
setblock 250 116 229 minecraft:black_stained_glass
setblock 250 116 234 minecraft:black_stained_glass
setblock 250 116 264 minecraft:ochre_froglight
setblock 250 116 269 minecraft:pearlescent_froglight
setblock 252 116 229 minecraft:magenta_stained_glass
setblock 252 116 234 minecraft:black_stained_glass
setblock 252 116 264 minecraft:cyan_stained_glass
setblock 252 116 269 minecraft:magenta_stained_glass
setblock 254 116 229 minecraft:cyan_stained_glass
setblock 254 116 234 minecraft:black_stained_glass
setblock 254 116 264 minecraft:sea_lantern
setblock 254 116 269 minecraft:black_stained_glass
setblock 256 116 229 minecraft:black_stained_glass
setblock 256 116 234 minecraft:black_stained_glass
setblock 256 116 264 minecraft:sea_lantern
setblock 256 116 269 minecraft:black_stained_glass
fill 257 116 270 257 137 270 minecraft:black_concrete
setblock 258 116 229 minecraft:pearlescent_froglight
setblock 258 116 234 minecraft:light_blue_stained_glass
setblock 258 116 264 minecraft:sea_lantern
setblock 258 116 269 minecraft:black_stained_glass
setblock 259 116 228 minecraft:magenta_concrete
setblock 260 116 229 minecraft:black_stained_glass
setblock 260 116 234 minecraft:black_stained_glass
setblock 260 116 264 minecraft:magenta_stained_glass
setblock 260 116 269 minecraft:sea_lantern
fill 261 116 270 261 122 270 minecraft:black_concrete
setblock 262 116 230 minecraft:black_stained_glass
setblock 262 116 232 minecraft:ochre_froglight
setblock 262 116 265 minecraft:ochre_froglight
setblock 262 116 267 minecraft:pearlescent_froglight
fill 264 116 228 265 119 228 minecraft:black_concrete
setblock 266 116 228 minecraft:pearlescent_froglight
setblock 268 116 230 minecraft:light_blue_stained_glass
setblock 268 116 232 minecraft:light_blue_stained_glass
setblock 268 116 234 minecraft:light_blue_stained_glass
setblock 268 116 236 minecraft:black_stained_glass
setblock 268 116 262 minecraft:black_stained_glass
setblock 268 116 264 minecraft:sea_lantern
setblock 268 116 266 minecraft:black_stained_glass
setblock 268 116 268 minecraft:light_blue_stained_glass
setblock 269 116 229 minecraft:cyan_stained_glass
setblock 269 116 237 minecraft:cyan_stained_glass
setblock 269 116 261 minecraft:black_stained_glass
setblock 269 116 269 minecraft:magenta_stained_glass
setblock 271 116 229 minecraft:magenta_stained_glass
setblock 271 116 237 minecraft:black_stained_glass
setblock 271 116 243 minecraft:black_stained_glass
setblock 271 116 245 minecraft:black_stained_glass
setblock 271 116 247 minecraft:pearlescent_froglight
setblock 271 116 249 minecraft:black_stained_glass
setblock 271 116 251 minecraft:cyan_stained_glass
setblock 271 116 253 minecraft:magenta_stained_glass
setblock 271 116 261 minecraft:pearlescent_froglight
setblock 271 116 269 minecraft:cyan_stained_glass
setblock 272 116 242 minecraft:black_stained_glass
setblock 272 116 255 minecraft:black_stained_glass
setblock 273 116 229 minecraft:pearlescent_froglight
setblock 273 116 237 minecraft:sea_lantern
setblock 273 116 261 minecraft:sea_lantern
setblock 273 116 269 minecraft:black_stained_glass
setblock 274 116 242 minecraft:ochre_froglight
setblock 274 116 255 minecraft:black_stained_glass
setblock 275 116 229 minecraft:black_stained_glass
setblock 275 116 237 minecraft:ochre_froglight
setblock 275 116 261 minecraft:black_stained_glass
setblock 275 116 269 minecraft:black_stained_glass
setblock 276 116 230 minecraft:pearlescent_froglight
setblock 276 116 232 minecraft:sea_lantern
setblock 276 116 234 minecraft:pearlescent_froglight
setblock 276 116 236 minecraft:black_stained_glass
setblock 276 116 243 minecraft:black_stained_glass
setblock 276 116 245 minecraft:black_stained_glass
setblock 276 116 247 minecraft:black_stained_glass
setblock 276 116 249 minecraft:light_blue_stained_glass
setblock 276 116 251 minecraft:black_stained_glass
setblock 276 116 253 minecraft:pearlescent_froglight
setblock 276 116 262 minecraft:ochre_froglight
setblock 276 116 264 minecraft:black_stained_glass
setblock 276 116 266 minecraft:magenta_stained_glass
setblock 276 116 268 minecraft:cyan_stained_glass
setblock 277 116 247 minecraft:sea_lantern
fill 277 116 261 277 183 261 minecraft:black_concrete
fill 235 117 248 235 155 248 minecraft:black_concrete
fill 235 117 258 235 252 258 minecraft:black_concrete
fill 236 117 230 236 118 230 minecraft:light_gray_concrete
fill 236 117 232 236 118 232 minecraft:light_gray_concrete
fill 236 117 234 236 118 234 minecraft:light_gray_concrete
fill 236 117 236 236 118 236 minecraft:light_gray_concrete
fill 236 117 243 236 118 243 minecraft:light_gray_concrete
fill 236 117 245 236 118 245 minecraft:light_gray_concrete
fill 236 117 247 236 118 247 minecraft:light_gray_concrete
fill 236 117 249 236 118 249 minecraft:light_gray_concrete
fill 236 117 251 236 118 251 minecraft:light_gray_concrete
fill 236 117 253 236 118 253 minecraft:light_gray_concrete
fill 236 117 262 236 118 262 minecraft:cyan_terracotta
fill 236 117 264 236 118 264 minecraft:cyan_terracotta
fill 236 117 266 236 118 266 minecraft:cyan_terracotta
fill 236 117 268 236 118 268 minecraft:cyan_terracotta
fill 237 117 229 237 118 229 minecraft:light_gray_concrete
fill 237 117 237 237 118 237 minecraft:light_gray_concrete
fill 237 117 242 237 118 242 minecraft:light_gray_concrete
fill 237 117 255 237 118 255 minecraft:light_gray_concrete
fill 237 117 261 237 118 261 minecraft:cyan_terracotta
fill 237 117 269 237 118 269 minecraft:cyan_terracotta
fill 239 117 229 239 118 229 minecraft:light_gray_concrete
fill 239 117 237 239 118 237 minecraft:light_gray_concrete
fill 239 117 242 239 118 242 minecraft:light_gray_concrete
fill 239 117 255 239 118 255 minecraft:light_gray_concrete
fill 239 117 261 239 118 261 minecraft:cyan_terracotta
fill 239 117 269 239 118 269 minecraft:cyan_terracotta
fill 241 117 229 241 118 229 minecraft:light_gray_concrete
fill 241 117 237 241 118 237 minecraft:light_gray_concrete
fill 241 117 243 241 118 243 minecraft:light_gray_concrete
fill 241 117 245 241 118 245 minecraft:light_gray_concrete
fill 241 117 247 241 118 247 minecraft:light_gray_concrete
fill 241 117 249 241 118 249 minecraft:light_gray_concrete
fill 241 117 251 241 118 251 minecraft:light_gray_concrete
fill 241 117 253 241 118 253 minecraft:light_gray_concrete
fill 241 117 261 241 118 261 minecraft:cyan_terracotta
fill 241 117 269 241 118 269 minecraft:cyan_terracotta
fill 243 117 229 243 118 229 minecraft:light_gray_concrete
fill 243 117 237 243 118 237 minecraft:light_gray_concrete
fill 243 117 261 243 118 261 minecraft:cyan_terracotta
fill 243 117 269 243 118 269 minecraft:cyan_terracotta
fill 244 117 230 244 118 230 minecraft:light_gray_concrete
fill 244 117 232 244 118 232 minecraft:light_gray_concrete
fill 244 117 234 244 118 234 minecraft:light_gray_concrete
fill 244 117 236 244 118 236 minecraft:light_gray_concrete
fill 244 117 262 244 118 262 minecraft:cyan_terracotta
fill 244 117 264 244 118 264 minecraft:cyan_terracotta
fill 244 117 266 244 118 266 minecraft:cyan_terracotta
fill 244 117 268 244 118 268 minecraft:cyan_terracotta
fill 249 117 230 249 118 230 minecraft:light_gray_concrete
fill 249 117 232 249 118 232 minecraft:light_gray_concrete
fill 249 117 265 249 118 265 minecraft:cyan_terracotta
fill 249 117 267 249 118 267 minecraft:cyan_terracotta
fill 250 117 229 250 118 229 minecraft:light_gray_concrete
fill 250 117 234 250 118 234 minecraft:light_gray_concrete
fill 250 117 264 250 118 264 minecraft:cyan_terracotta
fill 250 117 269 250 118 269 minecraft:cyan_terracotta
fill 252 117 229 252 118 229 minecraft:light_gray_concrete
fill 252 117 234 252 118 234 minecraft:light_gray_concrete
fill 252 117 264 252 118 264 minecraft:cyan_terracotta
fill 252 117 269 252 118 269 minecraft:cyan_terracotta
fill 254 117 229 254 118 229 minecraft:light_gray_concrete
fill 254 117 234 254 118 234 minecraft:light_gray_concrete
fill 254 117 264 254 118 264 minecraft:cyan_terracotta
fill 254 117 269 254 118 269 minecraft:cyan_terracotta
fill 256 117 229 256 118 229 minecraft:light_gray_concrete
fill 256 117 234 256 118 234 minecraft:light_gray_concrete
fill 256 117 264 256 118 264 minecraft:cyan_terracotta
fill 256 117 269 256 118 269 minecraft:cyan_terracotta
fill 258 117 229 258 118 229 minecraft:light_gray_concrete
fill 258 117 234 258 118 234 minecraft:light_gray_concrete
fill 258 117 264 258 118 264 minecraft:cyan_terracotta
fill 258 117 269 258 118 269 minecraft:cyan_terracotta
fill 259 117 228 259 271 228 minecraft:black_concrete
fill 260 117 229 260 118 229 minecraft:light_gray_concrete
fill 260 117 234 260 118 234 minecraft:light_gray_concrete
fill 260 117 264 260 118 264 minecraft:cyan_terracotta
fill 260 117 269 260 118 269 minecraft:cyan_terracotta
fill 262 117 230 262 118 230 minecraft:light_gray_concrete
fill 262 117 232 262 118 232 minecraft:light_gray_concrete
fill 262 117 265 262 118 265 minecraft:cyan_terracotta
fill 262 117 267 262 118 267 minecraft:cyan_terracotta
fill 266 117 228 266 118 228 minecraft:black_concrete
fill 268 117 230 268 118 230 minecraft:cyan_terracotta
fill 268 117 232 268 118 232 minecraft:cyan_terracotta
fill 268 117 234 268 118 234 minecraft:cyan_terracotta
fill 268 117 236 268 118 236 minecraft:cyan_terracotta
fill 268 117 262 268 118 262 minecraft:light_gray_concrete
fill 268 117 264 268 118 264 minecraft:light_gray_concrete
fill 268 117 266 268 118 266 minecraft:light_gray_concrete
fill 268 117 268 268 118 268 minecraft:light_gray_concrete
fill 269 117 229 269 118 229 minecraft:cyan_terracotta
fill 269 117 237 269 118 237 minecraft:cyan_terracotta
fill 269 117 261 269 118 261 minecraft:light_gray_concrete
fill 269 117 269 269 118 269 minecraft:light_gray_concrete
fill 271 117 229 271 118 229 minecraft:cyan_terracotta
fill 271 117 237 271 118 237 minecraft:cyan_terracotta
fill 271 117 243 271 118 243 minecraft:light_gray_concrete
fill 271 117 245 271 118 245 minecraft:light_gray_concrete
fill 271 117 247 271 118 247 minecraft:light_gray_concrete
fill 271 117 249 271 118 249 minecraft:light_gray_concrete
fill 271 117 251 271 118 251 minecraft:light_gray_concrete
fill 271 117 253 271 118 253 minecraft:light_gray_concrete
fill 271 117 261 271 118 261 minecraft:light_gray_concrete
fill 271 117 269 271 118 269 minecraft:light_gray_concrete
fill 272 117 242 272 118 242 minecraft:light_gray_concrete
fill 272 117 255 272 118 255 minecraft:light_gray_concrete
fill 273 117 229 273 118 229 minecraft:cyan_terracotta
fill 273 117 237 273 118 237 minecraft:cyan_terracotta
fill 273 117 261 273 118 261 minecraft:light_gray_concrete
fill 273 117 269 273 118 269 minecraft:light_gray_concrete
fill 274 117 242 274 118 242 minecraft:light_gray_concrete
fill 274 117 255 274 118 255 minecraft:light_gray_concrete
fill 275 117 229 275 118 229 minecraft:cyan_terracotta
fill 275 117 237 275 118 237 minecraft:cyan_terracotta
fill 275 117 261 275 118 261 minecraft:light_gray_concrete
fill 275 117 269 275 118 269 minecraft:light_gray_concrete
fill 276 117 230 276 118 230 minecraft:cyan_terracotta
fill 276 117 232 276 118 232 minecraft:cyan_terracotta
fill 276 117 234 276 118 234 minecraft:cyan_terracotta
fill 276 117 236 276 118 236 minecraft:cyan_terracotta
fill 276 117 243 276 118 243 minecraft:light_gray_concrete
fill 276 117 245 276 118 245 minecraft:light_gray_concrete
fill 276 117 247 276 118 247 minecraft:light_gray_concrete
fill 276 117 249 276 118 249 minecraft:light_gray_concrete
fill 276 117 251 276 118 251 minecraft:light_gray_concrete
fill 276 117 253 276 118 253 minecraft:light_gray_concrete
fill 276 117 262 276 118 262 minecraft:light_gray_concrete
fill 276 117 264 276 118 264 minecraft:light_gray_concrete
fill 276 117 266 276 118 266 minecraft:light_gray_concrete
fill 276 117 268 276 118 268 minecraft:light_gray_concrete
fill 277 117 247 277 185 247 minecraft:black_concrete
setblock 277 117 254 minecraft:magenta_concrete
fill 260 118 228 261 144 228 minecraft:black_concrete
setblock 262 118 228 minecraft:magenta_concrete
setblock 266 118 270 minecraft:pearlescent_froglight
fill 277 118 254 277 134 254 minecraft:black_concrete
fill 235 119 236 235 194 236 minecraft:black_concrete
setblock 235 119 237 minecraft:cyan_concrete
fill 235 119 249 235 172 249 minecraft:black_concrete
setblock 235 119 250 minecraft:ochre_froglight
fill 235 119 251 235 124 252 minecraft:black_concrete
setblock 235 119 257 minecraft:magenta_concrete
setblock 236 119 230 minecraft:black_stained_glass
setblock 236 119 232 minecraft:light_blue_stained_glass
setblock 236 119 234 minecraft:magenta_stained_glass
setblock 236 119 236 minecraft:black_stained_glass
setblock 236 119 243 minecraft:black_stained_glass
setblock 236 119 245 minecraft:sea_lantern
setblock 236 119 247 minecraft:black_stained_glass
setblock 236 119 249 minecraft:black_stained_glass
setblock 236 119 251 minecraft:black_stained_glass
setblock 236 119 253 minecraft:black_stained_glass
setblock 236 119 262 minecraft:pearlescent_froglight
setblock 236 119 264 minecraft:pearlescent_froglight
setblock 236 119 266 minecraft:ochre_froglight
setblock 236 119 268 minecraft:magenta_stained_glass
setblock 237 119 229 minecraft:magenta_stained_glass
setblock 237 119 237 minecraft:black_stained_glass
setblock 237 119 242 minecraft:black_stained_glass
setblock 237 119 255 minecraft:black_stained_glass
setblock 237 119 261 minecraft:black_stained_glass
setblock 237 119 269 minecraft:cyan_stained_glass
setblock 239 119 229 minecraft:cyan_stained_glass
setblock 239 119 237 minecraft:sea_lantern
setblock 239 119 242 minecraft:black_stained_glass
setblock 239 119 255 minecraft:black_stained_glass
setblock 239 119 261 minecraft:ochre_froglight
setblock 239 119 269 minecraft:ochre_froglight
setblock 241 119 229 minecraft:ochre_froglight
setblock 241 119 237 minecraft:sea_lantern
setblock 241 119 243 minecraft:black_stained_glass
setblock 241 119 245 minecraft:black_stained_glass
setblock 241 119 247 minecraft:magenta_stained_glass
setblock 241 119 249 minecraft:black_stained_glass
setblock 241 119 251 minecraft:black_stained_glass
setblock 241 119 253 minecraft:ochre_froglight
setblock 241 119 261 minecraft:light_blue_stained_glass
setblock 241 119 269 minecraft:cyan_stained_glass
setblock 243 119 229 minecraft:light_blue_stained_glass
setblock 243 119 237 minecraft:ochre_froglight
setblock 243 119 261 minecraft:black_stained_glass
setblock 243 119 269 minecraft:black_stained_glass
setblock 244 119 230 minecraft:magenta_stained_glass
setblock 244 119 232 minecraft:cyan_stained_glass
setblock 244 119 234 minecraft:black_stained_glass
setblock 244 119 236 minecraft:ochre_froglight
setblock 244 119 262 minecraft:black_stained_glass
setblock 244 119 264 minecraft:black_stained_glass
setblock 244 119 266 minecraft:black_stained_glass
setblock 244 119 268 minecraft:black_stained_glass
setblock 249 119 230 minecraft:black_stained_glass
setblock 249 119 232 minecraft:black_stained_glass
setblock 249 119 265 minecraft:magenta_stained_glass
setblock 249 119 267 minecraft:black_stained_glass
setblock 250 119 229 minecraft:black_stained_glass
setblock 250 119 234 minecraft:black_stained_glass
setblock 250 119 264 minecraft:sea_lantern
setblock 250 119 269 minecraft:black_stained_glass
setblock 250 119 270 minecraft:verdant_froglight
setblock 252 119 229 minecraft:magenta_stained_glass
setblock 252 119 234 minecraft:magenta_stained_glass
setblock 252 119 264 minecraft:black_stained_glass
setblock 252 119 269 minecraft:ochre_froglight
setblock 254 119 229 minecraft:cyan_stained_glass
setblock 254 119 234 minecraft:light_blue_stained_glass
setblock 254 119 264 minecraft:magenta_stained_glass
setblock 254 119 269 minecraft:cyan_stained_glass
setblock 256 119 229 minecraft:black_stained_glass
setblock 256 119 234 minecraft:black_stained_glass
setblock 256 119 264 minecraft:light_blue_stained_glass
setblock 256 119 269 minecraft:ochre_froglight
setblock 258 119 229 minecraft:black_stained_glass
setblock 258 119 234 minecraft:pearlescent_froglight
setblock 258 119 264 minecraft:black_stained_glass
setblock 258 119 269 minecraft:magenta_stained_glass
setblock 260 119 229 minecraft:black_stained_glass
setblock 260 119 234 minecraft:magenta_stained_glass
setblock 260 119 264 minecraft:ochre_froglight
setblock 260 119 269 minecraft:pearlescent_froglight
fill 262 119 228 262 255 228 minecraft:black_concrete
setblock 262 119 230 minecraft:cyan_stained_glass
setblock 262 119 232 minecraft:black_stained_glass
setblock 262 119 265 minecraft:cyan_stained_glass
setblock 262 119 267 minecraft:magenta_stained_glass
setblock 266 119 228 minecraft:pearlescent_froglight
fill 266 119 270 267 149 270 minecraft:black_concrete
setblock 268 119 230 minecraft:light_blue_stained_glass
setblock 268 119 232 minecraft:magenta_stained_glass
setblock 268 119 234 minecraft:black_stained_glass
setblock 268 119 236 minecraft:magenta_stained_glass
setblock 268 119 262 minecraft:black_stained_glass
setblock 268 119 264 minecraft:black_stained_glass
setblock 268 119 266 minecraft:ochre_froglight
setblock 268 119 268 minecraft:magenta_stained_glass
setblock 268 119 270 minecraft:blue_concrete
setblock 269 119 229 minecraft:sea_lantern
setblock 269 119 237 minecraft:black_stained_glass
setblock 269 119 261 minecraft:black_stained_glass
setblock 269 119 269 minecraft:ochre_froglight
setblock 271 119 229 minecraft:ochre_froglight
setblock 271 119 237 minecraft:magenta_stained_glass
setblock 271 119 243 minecraft:ochre_froglight
setblock 271 119 245 minecraft:magenta_stained_glass
setblock 271 119 247 minecraft:pearlescent_froglight
setblock 271 119 249 minecraft:black_stained_glass
setblock 271 119 251 minecraft:black_stained_glass
setblock 271 119 253 minecraft:black_stained_glass
setblock 271 119 261 minecraft:black_stained_glass
setblock 271 119 269 minecraft:black_stained_glass
setblock 272 119 242 minecraft:pearlescent_froglight
setblock 272 119 255 minecraft:black_stained_glass
setblock 273 119 229 minecraft:magenta_stained_glass
setblock 273 119 237 minecraft:sea_lantern
setblock 273 119 261 minecraft:light_blue_stained_glass
setblock 273 119 269 minecraft:magenta_stained_glass
setblock 274 119 242 minecraft:black_stained_glass
setblock 274 119 255 minecraft:magenta_stained_glass
setblock 275 119 229 minecraft:light_blue_stained_glass
setblock 275 119 237 minecraft:black_stained_glass
setblock 275 119 261 minecraft:cyan_stained_glass
setblock 275 119 269 minecraft:pearlescent_froglight
setblock 276 119 230 minecraft:black_stained_glass
setblock 276 119 232 minecraft:black_stained_glass
setblock 276 119 234 minecraft:ochre_froglight
setblock 276 119 236 minecraft:ochre_froglight
setblock 276 119 243 minecraft:black_stained_glass
setblock 276 119 245 minecraft:ochre_froglight
setblock 276 119 247 minecraft:cyan_stained_glass
setblock 276 119 249 minecraft:pearlescent_froglight
setblock 276 119 251 minecraft:black_stained_glass
setblock 276 119 253 minecraft:black_stained_glass
setblock 276 119 262 minecraft:black_stained_glass
setblock 276 119 264 minecraft:pearlescent_froglight
setblock 276 119 266 minecraft:magenta_stained_glass
setblock 276 119 268 minecraft:ochre_froglight
fill 235 120 237 235 185 237 minecraft:black_concrete
fill 235 120 250 235 308 250 minecraft:black_concrete
fill 235 120 257 235 195 257 minecraft:black_concrete
setblock 236 120 228 minecraft:magenta_concrete
fill 236 120 230 236 121 230 minecraft:light_gray_concrete
fill 236 120 232 236 121 232 minecraft:light_gray_concrete
fill 236 120 234 236 121 234 minecraft:light_gray_concrete
fill 236 120 236 236 121 236 minecraft:light_gray_concrete
fill 236 120 243 236 121 243 minecraft:light_gray_concrete
fill 236 120 245 236 121 245 minecraft:light_gray_concrete
fill 236 120 247 236 121 247 minecraft:light_gray_concrete
fill 236 120 249 236 121 249 minecraft:light_gray_concrete
fill 236 120 251 236 121 251 minecraft:light_gray_concrete
fill 236 120 253 236 121 253 minecraft:light_gray_concrete
fill 236 120 262 236 121 262 minecraft:cyan_terracotta
fill 236 120 264 236 121 264 minecraft:cyan_terracotta
fill 236 120 266 236 121 266 minecraft:cyan_terracotta
fill 236 120 268 236 121 268 minecraft:cyan_terracotta
fill 237 120 229 237 121 229 minecraft:light_gray_concrete
fill 237 120 237 237 121 237 minecraft:light_gray_concrete
fill 237 120 242 237 121 242 minecraft:light_gray_concrete
fill 237 120 255 237 121 255 minecraft:light_gray_concrete
fill 237 120 261 237 121 261 minecraft:cyan_terracotta
fill 237 120 269 237 121 269 minecraft:cyan_terracotta
fill 239 120 229 239 121 229 minecraft:light_gray_concrete
fill 239 120 237 239 121 237 minecraft:light_gray_concrete
fill 239 120 242 239 121 242 minecraft:light_gray_concrete
fill 239 120 255 239 121 255 minecraft:light_gray_concrete
fill 239 120 261 239 121 261 minecraft:cyan_terracotta
fill 239 120 269 239 121 269 minecraft:cyan_terracotta
fill 241 120 229 241 121 229 minecraft:light_gray_concrete
fill 241 120 237 241 121 237 minecraft:light_gray_concrete
fill 241 120 243 241 121 243 minecraft:light_gray_concrete
fill 241 120 245 241 121 245 minecraft:light_gray_concrete
fill 241 120 247 241 121 247 minecraft:light_gray_concrete
fill 241 120 249 241 121 249 minecraft:light_gray_concrete
fill 241 120 251 241 121 251 minecraft:light_gray_concrete
fill 241 120 253 241 121 253 minecraft:light_gray_concrete
fill 241 120 261 241 121 261 minecraft:cyan_terracotta
fill 241 120 269 241 121 269 minecraft:cyan_terracotta
fill 243 120 229 243 121 229 minecraft:light_gray_concrete
fill 243 120 237 243 121 237 minecraft:light_gray_concrete
fill 243 120 261 243 121 261 minecraft:cyan_terracotta
fill 243 120 269 243 121 269 minecraft:cyan_terracotta
fill 244 120 230 244 121 230 minecraft:light_gray_concrete
fill 244 120 232 244 121 232 minecraft:light_gray_concrete
fill 244 120 234 244 121 234 minecraft:light_gray_concrete
fill 244 120 236 244 121 236 minecraft:light_gray_concrete
fill 244 120 262 244 121 262 minecraft:cyan_terracotta
fill 244 120 264 244 121 264 minecraft:cyan_terracotta
fill 244 120 266 244 121 266 minecraft:cyan_terracotta
fill 244 120 268 244 121 268 minecraft:cyan_terracotta
fill 249 120 230 249 121 230 minecraft:light_gray_concrete
fill 249 120 232 249 121 232 minecraft:light_gray_concrete
fill 249 120 265 249 121 265 minecraft:cyan_terracotta
fill 249 120 267 249 121 267 minecraft:cyan_terracotta
fill 250 120 229 250 121 229 minecraft:light_gray_concrete
fill 250 120 234 250 121 234 minecraft:light_gray_concrete
fill 250 120 264 250 121 264 minecraft:cyan_terracotta
fill 250 120 269 250 121 269 minecraft:cyan_terracotta
fill 250 120 270 250 174 270 minecraft:black_concrete
fill 252 120 229 252 121 229 minecraft:light_gray_concrete
fill 252 120 234 252 121 234 minecraft:light_gray_concrete
fill 252 120 264 252 121 264 minecraft:cyan_terracotta
fill 252 120 269 252 121 269 minecraft:cyan_terracotta
fill 254 120 229 254 121 229 minecraft:light_gray_concrete
fill 254 120 234 254 121 234 minecraft:light_gray_concrete
fill 254 120 264 254 121 264 minecraft:cyan_terracotta
fill 254 120 269 254 121 269 minecraft:cyan_terracotta
fill 256 120 229 256 121 229 minecraft:light_gray_concrete
fill 256 120 234 256 121 234 minecraft:light_gray_concrete
fill 256 120 264 256 121 264 minecraft:cyan_terracotta
fill 256 120 269 256 121 269 minecraft:cyan_terracotta
fill 258 120 229 258 121 229 minecraft:light_gray_concrete
fill 258 120 234 258 121 234 minecraft:light_gray_concrete
fill 258 120 264 258 121 264 minecraft:cyan_terracotta
fill 258 120 269 258 121 269 minecraft:cyan_terracotta
fill 260 120 229 260 121 229 minecraft:light_gray_concrete
fill 260 120 234 260 121 234 minecraft:light_gray_concrete
fill 260 120 264 260 121 264 minecraft:cyan_terracotta
fill 260 120 269 260 121 269 minecraft:cyan_terracotta
fill 262 120 230 262 121 230 minecraft:light_gray_concrete
fill 262 120 232 262 121 232 minecraft:light_gray_concrete
fill 262 120 265 262 121 265 minecraft:cyan_terracotta
fill 262 120 267 262 121 267 minecraft:cyan_terracotta
setblock 264 120 228 minecraft:purple_concrete
fill 265 120 228 266 187 228 minecraft:black_concrete
fill 268 120 230 268 121 230 minecraft:cyan_terracotta
fill 268 120 232 268 121 232 minecraft:cyan_terracotta
fill 268 120 234 268 121 234 minecraft:cyan_terracotta
fill 268 120 236 268 121 236 minecraft:cyan_terracotta
fill 268 120 262 268 121 262 minecraft:light_gray_concrete
fill 268 120 264 268 121 264 minecraft:light_gray_concrete
fill 268 120 266 268 121 266 minecraft:light_gray_concrete
fill 268 120 268 268 121 268 minecraft:light_gray_concrete
fill 268 120 270 268 211 270 minecraft:black_concrete
fill 269 120 229 269 121 229 minecraft:cyan_terracotta
fill 269 120 237 269 121 237 minecraft:cyan_terracotta
fill 269 120 261 269 121 261 minecraft:light_gray_concrete
fill 269 120 269 269 121 269 minecraft:light_gray_concrete
fill 271 120 229 271 121 229 minecraft:cyan_terracotta
fill 271 120 237 271 121 237 minecraft:cyan_terracotta
fill 271 120 243 271 121 243 minecraft:light_gray_concrete
fill 271 120 245 271 121 245 minecraft:light_gray_concrete
fill 271 120 247 271 121 247 minecraft:light_gray_concrete
fill 271 120 249 271 121 249 minecraft:light_gray_concrete
fill 271 120 251 271 121 251 minecraft:light_gray_concrete
fill 271 120 253 271 121 253 minecraft:light_gray_concrete
fill 271 120 261 271 121 261 minecraft:light_gray_concrete
fill 271 120 269 271 121 269 minecraft:light_gray_concrete
fill 272 120 242 272 121 242 minecraft:light_gray_concrete
fill 272 120 255 272 121 255 minecraft:light_gray_concrete
fill 273 120 229 273 121 229 minecraft:cyan_terracotta
fill 273 120 237 273 121 237 minecraft:cyan_terracotta
fill 273 120 261 273 121 261 minecraft:light_gray_concrete
fill 273 120 269 273 121 269 minecraft:light_gray_concrete
fill 274 120 242 274 121 242 minecraft:light_gray_concrete
fill 274 120 255 274 121 255 minecraft:light_gray_concrete
fill 275 120 229 275 121 229 minecraft:cyan_terracotta
fill 275 120 237 275 121 237 minecraft:cyan_terracotta
fill 275 120 261 275 121 261 minecraft:light_gray_concrete
fill 275 120 269 275 121 269 minecraft:light_gray_concrete
fill 276 120 230 276 121 230 minecraft:cyan_terracotta
fill 276 120 232 276 121 232 minecraft:cyan_terracotta
fill 276 120 234 276 121 234 minecraft:cyan_terracotta
fill 276 120 236 276 121 236 minecraft:cyan_terracotta
fill 276 120 243 276 121 243 minecraft:light_gray_concrete
fill 276 120 245 276 121 245 minecraft:light_gray_concrete
fill 276 120 247 276 121 247 minecraft:light_gray_concrete
fill 276 120 249 276 121 249 minecraft:light_gray_concrete
fill 276 120 251 276 121 251 minecraft:light_gray_concrete
fill 276 120 253 276 121 253 minecraft:light_gray_concrete
fill 276 120 262 276 121 262 minecraft:light_gray_concrete
fill 276 120 264 276 121 264 minecraft:light_gray_concrete
fill 276 120 266 276 121 266 minecraft:light_gray_concrete
fill 276 120 268 276 121 268 minecraft:light_gray_concrete
setblock 277 120 253 minecraft:pearlescent_froglight
setblock 235 121 239 minecraft:verdant_froglight
setblock 235 121 247 minecraft:blue_concrete
fill 236 121 228 236 180 228 minecraft:black_concrete
setblock 238 121 238 minecraft:light[level=12]
setblock 238 121 259 minecraft:light[level=12]
setblock 242 121 249 minecraft:sea_lantern
setblock 245 121 231 minecraft:light[level=12]
setblock 245 121 238 minecraft:light[level=12]
setblock 245 121 245 minecraft:light[level=12]
setblock 245 121 252 minecraft:light[level=12]
setblock 245 121 259 minecraft:light[level=12]
setblock 245 121 266 minecraft:light[level=12]
setblock 252 121 238 minecraft:light[level=12]
setblock 252 121 245 minecraft:light[level=12]
setblock 252 121 252 minecraft:light[level=12]
setblock 252 121 259 minecraft:light[level=12]
setblock 259 121 238 minecraft:light[level=12]
setblock 259 121 245 minecraft:light[level=12]
setblock 259 121 252 minecraft:light[level=12]
setblock 259 121 259 minecraft:light[level=12]
fill 264 121 228 264 133 228 minecraft:black_concrete
setblock 266 121 231 minecraft:light[level=12]
setblock 266 121 238 minecraft:light[level=12]
setblock 266 121 245 minecraft:light[level=12]
setblock 266 121 252 minecraft:light[level=12]
setblock 266 121 259 minecraft:light[level=12]
setblock 266 121 266 minecraft:light[level=12]
fill 267 121 229 267 122 231 minecraft:iron_block
setblock 273 121 238 minecraft:light[level=12]
setblock 273 121 259 minecraft:light[level=12]
fill 277 121 253 277 256 253 minecraft:black_concrete
fill 277 121 258 277 194 258 minecraft:black_concrete
setblock 277 121 259 minecraft:cyan_concrete
fill 235 122 239 235 127 239 minecraft:black_concrete
fill 235 122 247 235 134 247 minecraft:black_concrete
setblock 236 122 230 minecraft:cyan_stained_glass
setblock 236 122 232 minecraft:black_stained_glass
setblock 236 122 234 minecraft:black_stained_glass
setblock 236 122 236 minecraft:sea_lantern
setblock 236 122 243 minecraft:magenta_stained_glass
setblock 236 122 245 minecraft:sea_lantern
setblock 236 122 247 minecraft:black_stained_glass
setblock 236 122 249 minecraft:magenta_stained_glass
setblock 236 122 251 minecraft:ochre_froglight
setblock 236 122 253 minecraft:ochre_froglight
setblock 236 122 262 minecraft:black_stained_glass
setblock 236 122 264 minecraft:pearlescent_froglight
setblock 236 122 266 minecraft:black_stained_glass
setblock 236 122 268 minecraft:black_stained_glass
setblock 237 122 229 minecraft:light_blue_stained_glass
setblock 237 122 237 minecraft:ochre_froglight
setblock 237 122 242 minecraft:pearlescent_froglight
setblock 237 122 255 minecraft:black_stained_glass
setblock 237 122 261 minecraft:black_stained_glass
setblock 237 122 269 minecraft:black_stained_glass
setblock 238 122 239 minecraft:light[level=15]
setblock 239 122 229 minecraft:ochre_froglight
setblock 239 122 237 minecraft:black_stained_glass
setblock 239 122 242 minecraft:black_stained_glass
setblock 239 122 255 minecraft:pearlescent_froglight
setblock 239 122 261 minecraft:black_stained_glass
setblock 239 122 269 minecraft:black_stained_glass
setblock 241 122 229 minecraft:magenta_stained_glass
setblock 241 122 237 minecraft:black_stained_glass
setblock 241 122 243 minecraft:sea_lantern
setblock 241 122 245 minecraft:black_stained_glass
setblock 241 122 247 minecraft:magenta_stained_glass
fill 241 122 248 243 122 250 minecraft:red_concrete
setblock 241 122 251 minecraft:light_blue_stained_glass
setblock 241 122 253 minecraft:ochre_froglight
setblock 241 122 261 minecraft:black_stained_glass
setblock 241 122 269 minecraft:black_stained_glass
setblock 242 122 247 minecraft:red_concrete
setblock 242 122 251 minecraft:red_concrete
setblock 243 122 229 minecraft:cyan_stained_glass
setblock 243 122 237 minecraft:black_stained_glass
setblock 243 122 261 minecraft:light_blue_stained_glass
setblock 243 122 269 minecraft:black_stained_glass
setblock 244 122 230 minecraft:magenta_stained_glass
setblock 244 122 232 minecraft:black_stained_glass
setblock 244 122 234 minecraft:black_stained_glass
setblock 244 122 236 minecraft:ochre_froglight
setblock 244 122 262 minecraft:ochre_froglight
setblock 244 122 264 minecraft:cyan_stained_glass
setblock 244 122 266 minecraft:magenta_stained_glass
setblock 244 122 268 minecraft:magenta_stained_glass
setblock 246 122 231 minecraft:light[level=15]
setblock 246 122 239 minecraft:light[level=15]
setblock 246 122 247 minecraft:light[level=15]
setblock 246 122 255 minecraft:light[level=15]
setblock 246 122 263 minecraft:light[level=15]
setblock 249 122 230 minecraft:sea_lantern
setblock 249 122 232 minecraft:ochre_froglight
setblock 249 122 265 minecraft:black_stained_glass
setblock 249 122 267 minecraft:black_stained_glass
setblock 250 122 229 minecraft:light_blue_stained_glass
setblock 250 122 234 minecraft:black_stained_glass
setblock 250 122 264 minecraft:cyan_stained_glass
setblock 250 122 269 minecraft:black_stained_glass
setblock 252 122 229 minecraft:magenta_stained_glass
setblock 252 122 234 minecraft:black_stained_glass
setblock 252 122 264 minecraft:ochre_froglight
setblock 252 122 269 minecraft:black_stained_glass
setblock 254 122 229 minecraft:light_blue_stained_glass
setblock 254 122 234 minecraft:light_blue_stained_glass
setblock 254 122 239 minecraft:light[level=15]
setblock 254 122 247 minecraft:light[level=15]
setblock 254 122 255 minecraft:light[level=15]
setblock 254 122 263 minecraft:light[level=15]
setblock 254 122 264 minecraft:black_stained_glass
setblock 254 122 269 minecraft:black_stained_glass
setblock 256 122 229 minecraft:ochre_froglight
setblock 256 122 234 minecraft:light_blue_stained_glass
setblock 256 122 264 minecraft:sea_lantern
setblock 256 122 269 minecraft:cyan_stained_glass
setblock 258 122 229 minecraft:ochre_froglight
setblock 258 122 234 minecraft:light_blue_stained_glass
setblock 258 122 264 minecraft:black_stained_glass
setblock 258 122 269 minecraft:light_blue_stained_glass
setblock 260 122 229 minecraft:ochre_froglight
setblock 260 122 234 minecraft:ochre_froglight
setblock 260 122 264 minecraft:sea_lantern
setblock 260 122 269 minecraft:sea_lantern
setblock 262 122 230 minecraft:ochre_froglight
setblock 262 122 232 minecraft:light_blue_stained_glass
setblock 262 122 239 minecraft:light[level=15]
setblock 262 122 247 minecraft:light[level=15]
setblock 262 122 255 minecraft:light[level=15]
setblock 262 122 263 minecraft:light[level=15]
setblock 262 122 265 minecraft:light_blue_stained_glass
setblock 262 122 267 minecraft:black_stained_glass
setblock 268 122 230 minecraft:ochre_froglight
setblock 268 122 232 minecraft:light_blue_stained_glass
setblock 268 122 234 minecraft:sea_lantern
setblock 268 122 236 minecraft:black_stained_glass
setblock 268 122 262 minecraft:sea_lantern
setblock 268 122 264 minecraft:black_stained_glass
setblock 268 122 266 minecraft:black_stained_glass
setblock 268 122 268 minecraft:black_stained_glass
setblock 269 122 229 minecraft:black_stained_glass
setblock 269 122 237 minecraft:cyan_stained_glass
setblock 269 122 261 minecraft:pearlescent_froglight
setblock 269 122 269 minecraft:ochre_froglight
setblock 270 122 239 minecraft:light[level=15]
setblock 270 122 247 minecraft:light[level=15]
setblock 270 122 255 minecraft:light[level=15]
setblock 271 122 229 minecraft:sea_lantern
setblock 271 122 237 minecraft:sea_lantern
setblock 271 122 243 minecraft:pearlescent_froglight
setblock 271 122 245 minecraft:pearlescent_froglight
setblock 271 122 247 minecraft:black_stained_glass
setblock 271 122 249 minecraft:ochre_froglight
setblock 271 122 251 minecraft:black_stained_glass
setblock 271 122 253 minecraft:black_stained_glass
setblock 271 122 261 minecraft:light_blue_stained_glass
setblock 271 122 269 minecraft:black_stained_glass
setblock 272 122 242 minecraft:magenta_stained_glass
setblock 272 122 255 minecraft:cyan_stained_glass
setblock 273 122 229 minecraft:black_stained_glass
setblock 273 122 237 minecraft:magenta_stained_glass
setblock 273 122 261 minecraft:ochre_froglight
setblock 273 122 269 minecraft:black_stained_glass
setblock 274 122 242 minecraft:black_stained_glass
setblock 274 122 255 minecraft:black_stained_glass
setblock 275 122 229 minecraft:cyan_stained_glass
setblock 275 122 237 minecraft:black_stained_glass
setblock 275 122 261 minecraft:light_blue_stained_glass
setblock 275 122 269 minecraft:black_stained_glass
setblock 276 122 230 minecraft:sea_lantern
setblock 276 122 232 minecraft:light_blue_stained_glass
setblock 276 122 234 minecraft:magenta_stained_glass
setblock 276 122 236 minecraft:black_stained_glass
setblock 276 122 243 minecraft:black_stained_glass
setblock 276 122 245 minecraft:pearlescent_froglight
setblock 276 122 247 minecraft:sea_lantern
setblock 276 122 249 minecraft:light_blue_stained_glass
setblock 276 122 251 minecraft:magenta_stained_glass
setblock 276 122 253 minecraft:pearlescent_froglight
setblock 276 122 262 minecraft:black_stained_glass
setblock 276 122 264 minecraft:ochre_froglight
setblock 276 122 266 minecraft:black_stained_glass
setblock 276 122 268 minecraft:pearlescent_froglight
fill 277 122 259 277 158 259 minecraft:black_concrete
setblock 235 123 259 minecraft:cyan_concrete
fill 235 123 264 235 129 264 minecraft:black_concrete
setblock 235 123 265 minecraft:ochre_froglight
fill 236 123 230 236 124 230 minecraft:light_gray_concrete
fill 236 123 232 236 124 232 minecraft:light_gray_concrete
fill 236 123 234 236 124 234 minecraft:light_gray_concrete
fill 236 123 236 236 124 236 minecraft:light_gray_concrete
fill 236 123 243 236 124 243 minecraft:light_gray_concrete
fill 236 123 245 236 124 245 minecraft:light_gray_concrete
fill 236 123 247 236 124 247 minecraft:light_gray_concrete
fill 236 123 249 236 124 249 minecraft:light_gray_concrete
fill 236 123 251 236 124 251 minecraft:light_gray_concrete
fill 236 123 253 236 124 253 minecraft:light_gray_concrete
fill 236 123 262 236 124 262 minecraft:cyan_terracotta
fill 236 123 264 236 124 264 minecraft:cyan_terracotta
fill 236 123 266 236 124 266 minecraft:cyan_terracotta
fill 236 123 268 236 124 268 minecraft:cyan_terracotta
fill 237 123 229 237 124 229 minecraft:light_gray_concrete
fill 237 123 237 237 124 237 minecraft:light_gray_concrete
fill 237 123 242 237 124 242 minecraft:light_gray_concrete
fill 237 123 255 237 124 255 minecraft:light_gray_concrete
fill 237 123 261 237 124 261 minecraft:cyan_terracotta
fill 237 123 269 237 124 269 minecraft:cyan_terracotta
fill 239 123 229 239 124 229 minecraft:light_gray_concrete
fill 239 123 237 239 124 237 minecraft:light_gray_concrete
fill 239 123 242 239 124 242 minecraft:light_gray_concrete
fill 239 123 255 239 124 255 minecraft:light_gray_concrete
fill 239 123 261 239 124 261 minecraft:cyan_terracotta
fill 239 123 269 239 124 269 minecraft:cyan_terracotta
fill 241 123 229 241 124 229 minecraft:light_gray_concrete
fill 241 123 237 241 124 237 minecraft:light_gray_concrete
fill 241 123 243 241 124 243 minecraft:light_gray_concrete
fill 241 123 245 241 124 245 minecraft:light_gray_concrete
fill 241 123 247 241 124 251 minecraft:light_gray_concrete
fill 241 123 253 241 124 253 minecraft:light_gray_concrete
fill 241 123 261 241 124 261 minecraft:cyan_terracotta
fill 241 123 269 241 124 269 minecraft:cyan_terracotta
fill 242 123 248 242 123 250 minecraft:light_blue_stained_glass
setblock 243 123 228 minecraft:cyan_concrete
fill 243 123 229 243 124 229 minecraft:light_gray_concrete
fill 243 123 237 243 124 237 minecraft:light_gray_concrete
fill 243 123 261 243 124 261 minecraft:cyan_terracotta
fill 243 123 269 243 124 269 minecraft:cyan_terracotta
setblock 243 123 270 minecraft:pearlescent_froglight
fill 244 123 230 244 124 230 minecraft:light_gray_concrete
fill 244 123 232 244 124 232 minecraft:light_gray_concrete
fill 244 123 234 244 124 234 minecraft:light_gray_concrete
fill 244 123 236 244 124 236 minecraft:light_gray_concrete
fill 244 123 262 244 124 262 minecraft:cyan_terracotta
fill 244 123 264 244 124 264 minecraft:cyan_terracotta
fill 244 123 266 244 124 266 minecraft:cyan_terracotta
fill 244 123 268 244 124 268 minecraft:cyan_terracotta
fill 249 123 230 249 124 230 minecraft:light_gray_concrete
fill 249 123 232 249 124 232 minecraft:light_gray_concrete
fill 249 123 265 249 124 265 minecraft:cyan_terracotta
fill 249 123 267 249 124 267 minecraft:cyan_terracotta
fill 250 123 229 250 124 229 minecraft:light_gray_concrete
fill 250 123 234 250 124 234 minecraft:light_gray_concrete
fill 250 123 264 250 124 264 minecraft:cyan_terracotta
fill 250 123 269 250 124 269 minecraft:cyan_terracotta
fill 252 123 229 252 124 229 minecraft:light_gray_concrete
fill 252 123 234 252 124 234 minecraft:light_gray_concrete
fill 252 123 264 252 124 264 minecraft:cyan_terracotta
fill 252 123 269 252 124 269 minecraft:cyan_terracotta
fill 254 123 229 254 124 229 minecraft:light_gray_concrete
fill 254 123 234 254 124 234 minecraft:light_gray_concrete
fill 254 123 264 254 124 264 minecraft:cyan_terracotta
fill 254 123 269 254 124 269 minecraft:cyan_terracotta
setblock 254 123 270 minecraft:cyan_concrete
fill 256 123 229 256 124 229 minecraft:light_gray_concrete
fill 256 123 234 256 124 234 minecraft:light_gray_concrete
fill 256 123 264 256 124 264 minecraft:cyan_terracotta
fill 256 123 269 256 124 269 minecraft:cyan_terracotta
fill 258 123 229 258 124 229 minecraft:light_gray_concrete
fill 258 123 234 258 124 234 minecraft:light_gray_concrete
fill 258 123 264 258 124 264 minecraft:cyan_terracotta
fill 258 123 269 258 124 269 minecraft:cyan_terracotta
fill 260 123 229 260 124 229 minecraft:light_gray_concrete
fill 260 123 234 260 124 234 minecraft:light_gray_concrete
fill 260 123 264 260 124 264 minecraft:cyan_terracotta
fill 260 123 269 260 124 269 minecraft:cyan_terracotta
setblock 261 123 270 minecraft:ochre_froglight
fill 262 123 230 262 124 230 minecraft:light_gray_concrete
fill 262 123 232 262 124 232 minecraft:light_gray_concrete
fill 262 123 265 262 124 265 minecraft:cyan_terracotta
fill 262 123 267 262 124 267 minecraft:cyan_terracotta
fill 268 123 230 268 124 230 minecraft:cyan_terracotta
fill 268 123 232 268 124 232 minecraft:cyan_terracotta
fill 268 123 234 268 124 234 minecraft:cyan_terracotta
fill 268 123 236 268 124 236 minecraft:cyan_terracotta
fill 268 123 262 268 124 262 minecraft:light_gray_concrete
fill 268 123 264 268 124 264 minecraft:light_gray_concrete
fill 268 123 266 268 124 266 minecraft:light_gray_concrete
fill 268 123 268 268 124 268 minecraft:light_gray_concrete
fill 269 123 229 269 124 229 minecraft:cyan_terracotta
fill 269 123 237 269 124 237 minecraft:cyan_terracotta
fill 269 123 261 269 124 261 minecraft:light_gray_concrete
fill 269 123 269 269 124 269 minecraft:light_gray_concrete
fill 271 123 229 271 124 229 minecraft:cyan_terracotta
fill 271 123 237 271 124 237 minecraft:cyan_terracotta
fill 271 123 243 271 124 243 minecraft:light_gray_concrete
fill 271 123 245 271 124 245 minecraft:light_gray_concrete
fill 271 123 247 271 124 247 minecraft:light_gray_concrete
fill 271 123 249 271 124 249 minecraft:light_gray_concrete
fill 271 123 251 271 124 251 minecraft:light_gray_concrete
fill 271 123 253 271 124 253 minecraft:light_gray_concrete
fill 271 123 261 271 124 261 minecraft:light_gray_concrete
fill 271 123 269 271 124 269 minecraft:light_gray_concrete
fill 272 123 242 272 124 242 minecraft:light_gray_concrete
fill 272 123 255 272 124 255 minecraft:light_gray_concrete
fill 273 123 229 273 124 229 minecraft:cyan_terracotta
fill 273 123 237 273 124 237 minecraft:cyan_terracotta
fill 273 123 261 273 124 261 minecraft:light_gray_concrete
fill 273 123 269 273 124 269 minecraft:light_gray_concrete
fill 274 123 242 274 124 242 minecraft:light_gray_concrete
fill 274 123 255 274 124 255 minecraft:light_gray_concrete
fill 275 123 229 275 124 229 minecraft:cyan_terracotta
fill 275 123 237 275 124 237 minecraft:cyan_terracotta
fill 275 123 261 275 124 261 minecraft:light_gray_concrete
fill 275 123 269 275 124 269 minecraft:light_gray_concrete
fill 276 123 230 276 124 230 minecraft:cyan_terracotta
fill 276 123 232 276 124 232 minecraft:cyan_terracotta
fill 276 123 234 276 124 234 minecraft:cyan_terracotta
fill 276 123 236 276 124 236 minecraft:cyan_terracotta
fill 276 123 243 276 124 243 minecraft:light_gray_concrete
fill 276 123 245 276 124 245 minecraft:light_gray_concrete
fill 276 123 247 276 124 247 minecraft:light_gray_concrete
fill 276 123 249 276 124 249 minecraft:light_gray_concrete
fill 276 123 251 276 124 251 minecraft:light_gray_concrete
fill 276 123 253 276 124 253 minecraft:light_gray_concrete
fill 276 123 262 276 124 262 minecraft:light_gray_concrete
fill 276 123 264 276 124 264 minecraft:light_gray_concrete
fill 276 123 266 276 124 266 minecraft:light_gray_concrete
fill 276 123 268 276 124 268 minecraft:light_gray_concrete
setblock 277 123 255 minecraft:purple_concrete
fill 235 124 259 235 225 259 minecraft:black_concrete
fill 235 124 265 235 140 265 minecraft:black_concrete
fill 243 124 228 243 128 228 minecraft:black_concrete
fill 243 124 270 243 308 270 minecraft:black_concrete
setblock 251 124 228 minecraft:magenta_concrete
fill 254 124 270 254 147 270 minecraft:black_concrete
fill 261 124 270 261 149 270 minecraft:black_concrete
fill 277 124 255 277 186 255 minecraft:black_concrete
setblock 235 125 241 minecraft:blue_concrete
setblock 235 125 251 minecraft:cyan_concrete
fill 235 125 252 235 156 252 minecraft:black_concrete
setblock 236 125 230 minecraft:ochre_froglight
setblock 236 125 232 minecraft:black_stained_glass
setblock 236 125 234 minecraft:sea_lantern
setblock 236 125 236 minecraft:black_stained_glass
setblock 236 125 243 minecraft:cyan_stained_glass
setblock 236 125 245 minecraft:light_blue_stained_glass
setblock 236 125 247 minecraft:cyan_stained_glass
setblock 236 125 249 minecraft:pearlescent_froglight
setblock 236 125 251 minecraft:black_stained_glass
setblock 236 125 253 minecraft:black_stained_glass
setblock 236 125 262 minecraft:black_stained_glass
setblock 236 125 264 minecraft:black_stained_glass
setblock 236 125 266 minecraft:black_stained_glass
setblock 236 125 268 minecraft:cyan_stained_glass
setblock 237 125 229 minecraft:pearlescent_froglight
setblock 237 125 237 minecraft:black_stained_glass
setblock 237 125 242 minecraft:ochre_froglight
setblock 237 125 255 minecraft:black_stained_glass
setblock 237 125 261 minecraft:ochre_froglight
setblock 237 125 269 minecraft:black_stained_glass
setblock 239 125 229 minecraft:black_stained_glass
setblock 239 125 237 minecraft:pearlescent_froglight
setblock 239 125 242 minecraft:cyan_stained_glass
setblock 239 125 255 minecraft:pearlescent_froglight
setblock 239 125 261 minecraft:cyan_stained_glass
setblock 239 125 269 minecraft:light_blue_stained_glass
setblock 241 125 229 minecraft:black_stained_glass
setblock 241 125 237 minecraft:black_stained_glass
setblock 241 125 243 minecraft:ochre_froglight
setblock 241 125 245 minecraft:black_stained_glass
setblock 241 125 247 minecraft:cyan_stained_glass
fill 241 125 248 241 183 248 minecraft:light_gray_concrete
setblock 241 125 249 minecraft:pearlescent_froglight
fill 241 125 250 241 183 250 minecraft:light_gray_concrete
setblock 241 125 251 minecraft:sea_lantern
setblock 241 125 253 minecraft:ochre_froglight
setblock 241 125 261 minecraft:cyan_stained_glass
setblock 241 125 269 minecraft:black_stained_glass
setblock 243 125 229 minecraft:magenta_stained_glass
setblock 243 125 237 minecraft:cyan_stained_glass
setblock 243 125 261 minecraft:pearlescent_froglight
setblock 243 125 269 minecraft:ochre_froglight
setblock 244 125 230 minecraft:cyan_stained_glass
setblock 244 125 232 minecraft:cyan_stained_glass
setblock 244 125 234 minecraft:pearlescent_froglight
setblock 244 125 236 minecraft:black_stained_glass
setblock 244 125 262 minecraft:black_stained_glass
setblock 244 125 264 minecraft:black_stained_glass
setblock 244 125 266 minecraft:ochre_froglight
setblock 244 125 268 minecraft:light_blue_stained_glass
setblock 249 125 230 minecraft:sea_lantern
setblock 249 125 232 minecraft:sea_lantern
setblock 249 125 265 minecraft:black_stained_glass
setblock 249 125 267 minecraft:cyan_stained_glass
setblock 250 125 229 minecraft:black_stained_glass
setblock 250 125 234 minecraft:pearlescent_froglight
setblock 250 125 264 minecraft:cyan_stained_glass
setblock 250 125 269 minecraft:cyan_stained_glass
fill 251 125 228 251 215 228 minecraft:black_concrete
setblock 252 125 229 minecraft:black_stained_glass
setblock 252 125 234 minecraft:black_stained_glass
setblock 252 125 264 minecraft:light_blue_stained_glass
setblock 252 125 269 minecraft:cyan_stained_glass
setblock 254 125 229 minecraft:magenta_stained_glass
setblock 254 125 234 minecraft:ochre_froglight
setblock 254 125 264 minecraft:pearlescent_froglight
setblock 254 125 269 minecraft:magenta_stained_glass
setblock 256 125 229 minecraft:black_stained_glass
setblock 256 125 234 minecraft:black_stained_glass
setblock 256 125 264 minecraft:ochre_froglight
setblock 256 125 269 minecraft:black_stained_glass
setblock 258 125 229 minecraft:cyan_stained_glass
setblock 258 125 234 minecraft:cyan_stained_glass
setblock 258 125 264 minecraft:black_stained_glass
setblock 258 125 269 minecraft:black_stained_glass
setblock 260 125 229 minecraft:black_stained_glass
setblock 260 125 234 minecraft:pearlescent_froglight
setblock 260 125 264 minecraft:black_stained_glass
setblock 260 125 269 minecraft:black_stained_glass
setblock 262 125 230 minecraft:pearlescent_froglight
setblock 262 125 232 minecraft:black_stained_glass
setblock 262 125 265 minecraft:black_stained_glass
setblock 262 125 267 minecraft:black_stained_glass
setblock 268 125 230 minecraft:black_stained_glass
setblock 268 125 232 minecraft:pearlescent_froglight
setblock 268 125 234 minecraft:magenta_stained_glass
setblock 268 125 236 minecraft:cyan_stained_glass
setblock 268 125 262 minecraft:light_blue_stained_glass
setblock 268 125 264 minecraft:cyan_stained_glass
setblock 268 125 266 minecraft:cyan_stained_glass
setblock 268 125 268 minecraft:black_stained_glass
setblock 269 125 229 minecraft:cyan_stained_glass
setblock 269 125 237 minecraft:black_stained_glass
setblock 269 125 261 minecraft:light_blue_stained_glass
setblock 269 125 269 minecraft:ochre_froglight
setblock 271 125 229 minecraft:cyan_stained_glass
setblock 271 125 237 minecraft:pearlescent_froglight
setblock 271 125 243 minecraft:black_stained_glass
setblock 271 125 245 minecraft:pearlescent_froglight
setblock 271 125 247 minecraft:pearlescent_froglight
setblock 271 125 249 minecraft:black_stained_glass
setblock 271 125 251 minecraft:black_stained_glass
setblock 271 125 253 minecraft:black_stained_glass
setblock 271 125 261 minecraft:cyan_stained_glass
setblock 271 125 269 minecraft:sea_lantern
setblock 272 125 242 minecraft:magenta_stained_glass
setblock 272 125 255 minecraft:sea_lantern
setblock 273 125 229 minecraft:light_blue_stained_glass
setblock 273 125 237 minecraft:black_stained_glass
setblock 273 125 261 minecraft:ochre_froglight
setblock 273 125 269 minecraft:black_stained_glass
setblock 274 125 242 minecraft:pearlescent_froglight
setblock 274 125 255 minecraft:magenta_stained_glass
setblock 275 125 229 minecraft:black_stained_glass
setblock 275 125 237 minecraft:cyan_stained_glass
setblock 275 125 261 minecraft:cyan_stained_glass
setblock 275 125 269 minecraft:sea_lantern
setblock 276 125 230 minecraft:pearlescent_froglight
setblock 276 125 232 minecraft:ochre_froglight
setblock 276 125 234 minecraft:pearlescent_froglight
setblock 276 125 236 minecraft:magenta_stained_glass
setblock 276 125 243 minecraft:cyan_stained_glass
setblock 276 125 245 minecraft:black_stained_glass
setblock 276 125 247 minecraft:light_blue_stained_glass
setblock 276 125 249 minecraft:magenta_stained_glass
setblock 276 125 251 minecraft:light_blue_stained_glass
setblock 276 125 253 minecraft:light_blue_stained_glass
setblock 276 125 262 minecraft:black_stained_glass
setblock 276 125 264 minecraft:black_stained_glass
setblock 276 125 266 minecraft:black_stained_glass
setblock 276 125 268 minecraft:black_stained_glass
setblock 235 126 232 minecraft:magenta_concrete
fill 235 126 241 235 173 241 minecraft:black_concrete
fill 235 126 251 235 308 251 minecraft:black_concrete
setblock 235 126 260 minecraft:pearlescent_froglight
fill 236 126 230 236 127 230 minecraft:light_gray_concrete
fill 236 126 232 236 127 232 minecraft:light_gray_concrete
fill 236 126 234 236 127 234 minecraft:light_gray_concrete
fill 236 126 236 236 127 236 minecraft:light_gray_concrete
fill 236 126 243 236 127 243 minecraft:light_gray_concrete
fill 236 126 245 236 127 245 minecraft:light_gray_concrete
fill 236 126 247 236 127 247 minecraft:light_gray_concrete
fill 236 126 249 236 127 249 minecraft:light_gray_concrete
fill 236 126 251 236 127 251 minecraft:light_gray_concrete
fill 236 126 253 236 127 253 minecraft:light_gray_concrete
fill 236 126 262 236 127 262 minecraft:cyan_terracotta
fill 236 126 264 236 127 264 minecraft:cyan_terracotta
fill 236 126 266 236 127 266 minecraft:cyan_terracotta
fill 236 126 268 236 127 268 minecraft:cyan_terracotta
fill 237 126 229 237 127 229 minecraft:light_gray_concrete
fill 237 126 237 237 127 237 minecraft:light_gray_concrete
fill 237 126 242 237 127 242 minecraft:light_gray_concrete
fill 237 126 255 237 127 255 minecraft:light_gray_concrete
fill 237 126 261 237 127 261 minecraft:cyan_terracotta
fill 237 126 269 237 127 269 minecraft:cyan_terracotta
fill 239 126 229 239 127 229 minecraft:light_gray_concrete
fill 239 126 237 239 127 237 minecraft:light_gray_concrete
fill 239 126 242 239 127 242 minecraft:light_gray_concrete
fill 239 126 255 239 127 255 minecraft:light_gray_concrete
fill 239 126 261 239 127 261 minecraft:cyan_terracotta
fill 239 126 269 239 127 269 minecraft:cyan_terracotta
fill 241 126 229 241 127 229 minecraft:light_gray_concrete
fill 241 126 237 241 127 237 minecraft:light_gray_concrete
fill 241 126 243 241 127 243 minecraft:light_gray_concrete
fill 241 126 245 241 127 245 minecraft:light_gray_concrete
fill 241 126 247 241 127 247 minecraft:light_gray_concrete
fill 241 126 249 241 127 249 minecraft:light_gray_concrete
fill 241 126 251 241 127 251 minecraft:light_gray_concrete
fill 241 126 253 241 127 253 minecraft:light_gray_concrete
fill 241 126 261 241 127 261 minecraft:cyan_terracotta
fill 241 126 269 241 127 269 minecraft:cyan_terracotta
fill 243 126 229 243 127 229 minecraft:light_gray_concrete
fill 243 126 237 243 127 237 minecraft:light_gray_concrete
fill 243 126 261 243 127 261 minecraft:cyan_terracotta
fill 243 126 269 243 127 269 minecraft:cyan_terracotta
fill 244 126 230 244 127 230 minecraft:light_gray_concrete
fill 244 126 232 244 127 232 minecraft:light_gray_concrete
fill 244 126 234 244 127 234 minecraft:light_gray_concrete
fill 244 126 236 244 127 236 minecraft:light_gray_concrete
fill 244 126 262 244 127 262 minecraft:cyan_terracotta
fill 244 126 264 244 127 264 minecraft:cyan_terracotta
fill 244 126 266 244 127 266 minecraft:cyan_terracotta
fill 244 126 268 244 127 268 minecraft:cyan_terracotta
fill 249 126 230 249 127 230 minecraft:light_gray_concrete
fill 249 126 232 249 127 232 minecraft:light_gray_concrete
fill 249 126 265 249 127 265 minecraft:cyan_terracotta
fill 249 126 267 249 127 267 minecraft:cyan_terracotta
fill 250 126 229 250 127 229 minecraft:light_gray_concrete
fill 250 126 234 250 127 234 minecraft:light_gray_concrete
fill 250 126 264 250 127 264 minecraft:cyan_terracotta
fill 250 126 269 250 127 269 minecraft:cyan_terracotta
fill 252 126 229 252 127 229 minecraft:light_gray_concrete
fill 252 126 234 252 127 234 minecraft:light_gray_concrete
fill 252 126 264 252 127 264 minecraft:cyan_terracotta
fill 252 126 269 252 127 269 minecraft:cyan_terracotta
fill 254 126 229 254 127 229 minecraft:light_gray_concrete
fill 254 126 234 254 127 234 minecraft:light_gray_concrete
fill 254 126 264 254 127 264 minecraft:cyan_terracotta
fill 254 126 269 254 127 269 minecraft:cyan_terracotta
fill 256 126 229 256 127 229 minecraft:light_gray_concrete
fill 256 126 234 256 127 234 minecraft:light_gray_concrete
fill 256 126 264 256 127 264 minecraft:cyan_terracotta
fill 256 126 269 256 127 269 minecraft:cyan_terracotta
fill 258 126 229 258 127 229 minecraft:light_gray_concrete
fill 258 126 234 258 127 234 minecraft:light_gray_concrete
fill 258 126 264 258 127 264 minecraft:cyan_terracotta
fill 258 126 269 258 127 269 minecraft:cyan_terracotta
fill 260 126 229 260 127 229 minecraft:light_gray_concrete
fill 260 126 234 260 127 234 minecraft:light_gray_concrete
fill 260 126 264 260 127 264 minecraft:cyan_terracotta
fill 260 126 269 260 127 269 minecraft:cyan_terracotta
fill 262 126 230 262 127 230 minecraft:light_gray_concrete
fill 262 126 232 262 127 232 minecraft:light_gray_concrete
fill 262 126 265 262 127 265 minecraft:cyan_terracotta
fill 262 126 267 262 127 267 minecraft:cyan_terracotta
fill 268 126 230 268 127 230 minecraft:cyan_terracotta
fill 268 126 232 268 127 232 minecraft:cyan_terracotta
fill 268 126 234 268 127 234 minecraft:cyan_terracotta
fill 268 126 236 268 127 236 minecraft:cyan_terracotta
fill 268 126 262 268 127 262 minecraft:light_gray_concrete
fill 268 126 264 268 127 264 minecraft:light_gray_concrete
fill 268 126 266 268 127 266 minecraft:light_gray_concrete
fill 268 126 268 268 127 268 minecraft:light_gray_concrete
fill 269 126 229 269 127 229 minecraft:cyan_terracotta
fill 269 126 237 269 127 237 minecraft:cyan_terracotta
fill 269 126 261 269 127 261 minecraft:light_gray_concrete
fill 269 126 269 269 127 269 minecraft:light_gray_concrete
fill 271 126 229 271 127 229 minecraft:cyan_terracotta
fill 271 126 237 271 127 237 minecraft:cyan_terracotta
fill 271 126 243 271 127 243 minecraft:light_gray_concrete
fill 271 126 245 271 127 245 minecraft:light_gray_concrete
fill 271 126 247 271 127 247 minecraft:light_gray_concrete
fill 271 126 249 271 127 249 minecraft:light_gray_concrete
fill 271 126 251 271 127 251 minecraft:light_gray_concrete
fill 271 126 253 271 127 253 minecraft:light_gray_concrete
fill 271 126 261 271 127 261 minecraft:light_gray_concrete
fill 271 126 269 271 127 269 minecraft:light_gray_concrete
fill 272 126 242 272 127 242 minecraft:light_gray_concrete
fill 272 126 255 272 127 255 minecraft:light_gray_concrete
fill 273 126 229 273 127 229 minecraft:cyan_terracotta
fill 273 126 237 273 127 237 minecraft:cyan_terracotta
fill 273 126 261 273 127 261 minecraft:light_gray_concrete
fill 273 126 269 273 127 269 minecraft:light_gray_concrete
fill 274 126 242 274 127 242 minecraft:light_gray_concrete
fill 274 126 255 274 127 255 minecraft:light_gray_concrete
fill 275 126 229 275 127 229 minecraft:cyan_terracotta
fill 275 126 237 275 127 237 minecraft:cyan_terracotta
fill 275 126 261 275 127 261 minecraft:light_gray_concrete
fill 275 126 269 275 127 269 minecraft:light_gray_concrete
fill 276 126 230 276 127 230 minecraft:cyan_terracotta
fill 276 126 232 276 127 232 minecraft:cyan_terracotta
fill 276 126 234 276 127 234 minecraft:cyan_terracotta
fill 276 126 236 276 127 236 minecraft:cyan_terracotta
fill 276 126 243 276 127 243 minecraft:light_gray_concrete
fill 276 126 245 276 127 245 minecraft:light_gray_concrete
fill 276 126 247 276 127 247 minecraft:light_gray_concrete
fill 276 126 249 276 127 249 minecraft:light_gray_concrete
fill 276 126 251 276 127 251 minecraft:light_gray_concrete
fill 276 126 253 276 127 253 minecraft:light_gray_concrete
fill 276 126 262 276 127 262 minecraft:light_gray_concrete
fill 276 126 264 276 127 264 minecraft:light_gray_concrete
fill 276 126 266 276 127 266 minecraft:light_gray_concrete
fill 276 126 268 276 127 268 minecraft:light_gray_concrete
fill 235 127 232 235 205 232 minecraft:black_concrete
fill 235 127 260 235 154 260 minecraft:black_concrete
setblock 238 127 238 minecraft:light[level=12]
setblock 238 127 259 minecraft:light[level=12]
setblock 245 127 231 minecraft:light[level=12]
setblock 245 127 238 minecraft:light[level=12]
setblock 245 127 245 minecraft:light[level=12]
setblock 245 127 252 minecraft:light[level=12]
setblock 245 127 259 minecraft:light[level=12]
setblock 245 127 266 minecraft:light[level=12]
setblock 252 127 238 minecraft:light[level=12]
setblock 252 127 245 minecraft:light[level=12]
setblock 252 127 252 minecraft:light[level=12]
setblock 252 127 259 minecraft:light[level=12]
setblock 259 127 238 minecraft:light[level=12]
setblock 259 127 245 minecraft:light[level=12]
setblock 259 127 252 minecraft:light[level=12]
setblock 259 127 259 minecraft:light[level=12]
setblock 266 127 231 minecraft:light[level=12]
setblock 266 127 238 minecraft:light[level=12]
setblock 266 127 245 minecraft:light[level=12]
setblock 266 127 252 minecraft:light[level=12]
setblock 266 127 259 minecraft:light[level=12]
setblock 266 127 266 minecraft:light[level=12]
setblock 268 127 228 minecraft:verdant_froglight
setblock 273 127 238 minecraft:light[level=12]
setblock 273 127 259 minecraft:light[level=12]
fill 277 127 238 277 231 238 minecraft:black_concrete
setblock 277 127 239 minecraft:sea_lantern
setblock 235 128 239 minecraft:ochre_froglight
setblock 235 128 246 minecraft:blue_concrete
setblock 236 128 230 minecraft:magenta_stained_glass
setblock 236 128 232 minecraft:black_stained_glass
setblock 236 128 234 minecraft:black_stained_glass
setblock 236 128 236 minecraft:cyan_stained_glass
setblock 236 128 243 minecraft:black_stained_glass
setblock 236 128 245 minecraft:light_blue_stained_glass
setblock 236 128 247 minecraft:magenta_stained_glass
setblock 236 128 249 minecraft:black_stained_glass
setblock 236 128 251 minecraft:black_stained_glass
setblock 236 128 253 minecraft:black_stained_glass
setblock 236 128 262 minecraft:ochre_froglight
setblock 236 128 264 minecraft:black_stained_glass
setblock 236 128 266 minecraft:black_stained_glass
setblock 236 128 268 minecraft:cyan_stained_glass
setblock 237 128 229 minecraft:black_stained_glass
setblock 237 128 237 minecraft:sea_lantern
setblock 237 128 242 minecraft:black_stained_glass
setblock 237 128 255 minecraft:pearlescent_froglight
setblock 237 128 261 minecraft:sea_lantern
setblock 237 128 269 minecraft:black_stained_glass
setblock 239 128 229 minecraft:black_stained_glass
setblock 239 128 237 minecraft:sea_lantern
setblock 239 128 242 minecraft:black_stained_glass
setblock 239 128 255 minecraft:sea_lantern
setblock 239 128 261 minecraft:black_stained_glass
setblock 239 128 269 minecraft:black_stained_glass
fill 239 128 270 240 153 270 minecraft:black_concrete
setblock 241 128 229 minecraft:pearlescent_froglight
setblock 241 128 237 minecraft:black_stained_glass
setblock 241 128 243 minecraft:black_stained_glass
setblock 241 128 245 minecraft:ochre_froglight
setblock 241 128 247 minecraft:pearlescent_froglight
setblock 241 128 249 minecraft:magenta_stained_glass
setblock 241 128 251 minecraft:black_stained_glass
setblock 241 128 253 minecraft:magenta_stained_glass
setblock 241 128 261 minecraft:black_stained_glass
setblock 241 128 269 minecraft:black_stained_glass
setblock 241 128 270 minecraft:purple_concrete
setblock 243 128 229 minecraft:black_stained_glass
setblock 243 128 237 minecraft:cyan_stained_glass
setblock 243 128 261 minecraft:black_stained_glass
setblock 243 128 269 minecraft:black_stained_glass
setblock 244 128 230 minecraft:black_stained_glass
setblock 244 128 232 minecraft:black_stained_glass
setblock 244 128 234 minecraft:black_stained_glass
setblock 244 128 236 minecraft:black_stained_glass
setblock 244 128 262 minecraft:magenta_stained_glass
setblock 244 128 264 minecraft:magenta_stained_glass
setblock 244 128 266 minecraft:black_stained_glass
setblock 244 128 268 minecraft:light_blue_stained_glass
setblock 249 128 230 minecraft:light_blue_stained_glass
setblock 249 128 232 minecraft:ochre_froglight
setblock 249 128 265 minecraft:black_stained_glass
setblock 249 128 267 minecraft:black_stained_glass
setblock 250 128 229 minecraft:sea_lantern
setblock 250 128 234 minecraft:black_stained_glass
setblock 250 128 264 minecraft:cyan_stained_glass
setblock 250 128 269 minecraft:black_stained_glass
setblock 252 128 229 minecraft:black_stained_glass
setblock 252 128 234 minecraft:light_blue_stained_glass
setblock 252 128 264 minecraft:pearlescent_froglight
setblock 252 128 269 minecraft:cyan_stained_glass
setblock 254 128 229 minecraft:light_blue_stained_glass
setblock 254 128 234 minecraft:black_stained_glass
setblock 254 128 264 minecraft:light_blue_stained_glass
setblock 254 128 269 minecraft:magenta_stained_glass
setblock 256 128 229 minecraft:cyan_stained_glass
setblock 256 128 234 minecraft:black_stained_glass
setblock 256 128 264 minecraft:black_stained_glass
setblock 256 128 269 minecraft:ochre_froglight
setblock 258 128 229 minecraft:ochre_froglight
setblock 258 128 234 minecraft:magenta_stained_glass
setblock 258 128 264 minecraft:cyan_stained_glass
setblock 258 128 269 minecraft:black_stained_glass
setblock 260 128 229 minecraft:pearlescent_froglight
setblock 260 128 234 minecraft:magenta_stained_glass
setblock 260 128 264 minecraft:sea_lantern
setblock 260 128 269 minecraft:black_stained_glass
setblock 262 128 230 minecraft:black_stained_glass
setblock 262 128 232 minecraft:black_stained_glass
setblock 262 128 265 minecraft:cyan_stained_glass
setblock 262 128 267 minecraft:magenta_stained_glass
setblock 265 128 270 minecraft:cyan_concrete
setblock 267 128 228 minecraft:ochre_froglight
fill 268 128 228 268 219 228 minecraft:black_concrete
setblock 268 128 230 minecraft:sea_lantern
setblock 268 128 232 minecraft:pearlescent_froglight
setblock 268 128 234 minecraft:black_stained_glass
setblock 268 128 236 minecraft:pearlescent_froglight
setblock 268 128 262 minecraft:black_stained_glass
setblock 268 128 264 minecraft:sea_lantern
setblock 268 128 266 minecraft:pearlescent_froglight
setblock 268 128 268 minecraft:sea_lantern
setblock 269 128 229 minecraft:black_stained_glass
setblock 269 128 237 minecraft:sea_lantern
setblock 269 128 261 minecraft:cyan_stained_glass
setblock 269 128 269 minecraft:black_stained_glass
setblock 271 128 229 minecraft:ochre_froglight
setblock 271 128 237 minecraft:light_blue_stained_glass
setblock 271 128 243 minecraft:pearlescent_froglight
setblock 271 128 245 minecraft:cyan_stained_glass
setblock 271 128 247 minecraft:black_stained_glass
setblock 271 128 249 minecraft:light_blue_stained_glass
setblock 271 128 251 minecraft:ochre_froglight
setblock 271 128 253 minecraft:magenta_stained_glass
setblock 271 128 261 minecraft:black_stained_glass
setblock 271 128 269 minecraft:ochre_froglight
setblock 272 128 242 minecraft:black_stained_glass
setblock 272 128 255 minecraft:magenta_stained_glass
setblock 273 128 229 minecraft:magenta_stained_glass
setblock 273 128 237 minecraft:black_stained_glass
setblock 273 128 261 minecraft:black_stained_glass
setblock 273 128 269 minecraft:magenta_stained_glass
setblock 274 128 242 minecraft:magenta_stained_glass
setblock 274 128 255 minecraft:black_stained_glass
setblock 275 128 229 minecraft:black_stained_glass
setblock 275 128 237 minecraft:cyan_stained_glass
setblock 275 128 261 minecraft:cyan_stained_glass
setblock 275 128 269 minecraft:light_blue_stained_glass
setblock 276 128 230 minecraft:black_stained_glass
setblock 276 128 232 minecraft:sea_lantern
setblock 276 128 234 minecraft:black_stained_glass
setblock 276 128 236 minecraft:magenta_stained_glass
setblock 276 128 243 minecraft:black_stained_glass
setblock 276 128 245 minecraft:magenta_stained_glass
setblock 276 128 247 minecraft:pearlescent_froglight
setblock 276 128 249 minecraft:cyan_stained_glass
setblock 276 128 251 minecraft:black_stained_glass
setblock 276 128 253 minecraft:black_stained_glass
setblock 276 128 262 minecraft:cyan_stained_glass
setblock 276 128 264 minecraft:black_stained_glass
setblock 276 128 266 minecraft:pearlescent_froglight
setblock 276 128 268 minecraft:pearlescent_froglight
fill 277 128 239 277 177 239 minecraft:black_concrete
setblock 277 128 251 minecraft:purple_concrete
fill 235 129 239 235 145 239 minecraft:black_concrete
fill 235 129 246 235 223 246 minecraft:black_concrete
fill 236 129 230 236 130 230 minecraft:light_gray_concrete
fill 236 129 232 236 130 232 minecraft:light_gray_concrete
fill 236 129 234 236 130 234 minecraft:light_gray_concrete
fill 236 129 236 236 130 236 minecraft:light_gray_concrete
fill 236 129 243 236 130 243 minecraft:light_gray_concrete
fill 236 129 245 236 130 245 minecraft:light_gray_concrete
fill 236 129 247 236 130 247 minecraft:light_gray_concrete
fill 236 129 249 236 130 249 minecraft:light_gray_concrete
fill 236 129 251 236 130 251 minecraft:light_gray_concrete
fill 236 129 253 236 130 253 minecraft:light_gray_concrete
fill 236 129 262 236 130 262 minecraft:cyan_terracotta
fill 236 129 264 236 130 264 minecraft:cyan_terracotta
fill 236 129 266 236 130 266 minecraft:cyan_terracotta
fill 236 129 268 236 130 268 minecraft:cyan_terracotta
fill 237 129 229 237 130 229 minecraft:light_gray_concrete
fill 237 129 237 237 130 237 minecraft:light_gray_concrete
fill 237 129 242 237 130 242 minecraft:light_gray_concrete
fill 237 129 255 237 130 255 minecraft:light_gray_concrete
fill 237 129 261 237 130 261 minecraft:cyan_terracotta
fill 237 129 269 237 130 269 minecraft:cyan_terracotta
setblock 238 129 239 minecraft:light[level=15]
fill 239 129 229 239 130 229 minecraft:light_gray_concrete
fill 239 129 237 239 130 237 minecraft:light_gray_concrete
fill 239 129 242 239 130 242 minecraft:light_gray_concrete
fill 239 129 255 239 130 255 minecraft:light_gray_concrete
fill 239 129 261 239 130 261 minecraft:cyan_terracotta
fill 239 129 269 239 130 269 minecraft:cyan_terracotta
fill 241 129 229 241 130 229 minecraft:light_gray_concrete
fill 241 129 237 241 130 237 minecraft:light_gray_concrete
fill 241 129 243 241 130 243 minecraft:light_gray_concrete
fill 241 129 245 241 130 245 minecraft:light_gray_concrete
fill 241 129 247 241 130 247 minecraft:light_gray_concrete
fill 241 129 249 241 130 249 minecraft:light_gray_concrete
fill 241 129 251 241 130 251 minecraft:light_gray_concrete
fill 241 129 253 241 130 253 minecraft:light_gray_concrete
fill 241 129 261 241 130 261 minecraft:cyan_terracotta
fill 241 129 269 241 130 269 minecraft:cyan_terracotta
fill 241 129 270 241 131 270 minecraft:black_concrete
setblock 243 129 228 minecraft:verdant_froglight
fill 243 129 229 243 130 229 minecraft:light_gray_concrete
fill 243 129 237 243 130 237 minecraft:light_gray_concrete
fill 243 129 261 243 130 261 minecraft:cyan_terracotta
fill 243 129 269 243 130 269 minecraft:cyan_terracotta
fill 244 129 230 244 130 230 minecraft:light_gray_concrete
fill 244 129 232 244 130 232 minecraft:light_gray_concrete
fill 244 129 234 244 130 234 minecraft:light_gray_concrete
fill 244 129 236 244 130 236 minecraft:light_gray_concrete
fill 244 129 262 244 130 262 minecraft:cyan_terracotta
fill 244 129 264 244 130 264 minecraft:cyan_terracotta
fill 244 129 266 244 130 266 minecraft:cyan_terracotta
fill 244 129 268 244 130 268 minecraft:cyan_terracotta
setblock 246 129 231 minecraft:light[level=15]
setblock 246 129 239 minecraft:light[level=15]
setblock 246 129 247 minecraft:light[level=15]
setblock 246 129 255 minecraft:light[level=15]
setblock 246 129 263 minecraft:light[level=15]
fill 249 129 230 249 130 230 minecraft:light_gray_concrete
fill 249 129 232 249 130 232 minecraft:light_gray_concrete
fill 249 129 265 249 130 265 minecraft:cyan_terracotta
fill 249 129 267 249 130 267 minecraft:cyan_terracotta
fill 250 129 229 250 130 229 minecraft:light_gray_concrete
fill 250 129 234 250 130 234 minecraft:light_gray_concrete
fill 250 129 264 250 130 264 minecraft:cyan_terracotta
fill 250 129 269 250 130 269 minecraft:cyan_terracotta
fill 252 129 229 252 130 229 minecraft:light_gray_concrete
fill 252 129 234 252 130 234 minecraft:light_gray_concrete
fill 252 129 264 252 130 264 minecraft:cyan_terracotta
fill 252 129 269 252 130 269 minecraft:cyan_terracotta
fill 254 129 229 254 130 229 minecraft:light_gray_concrete
fill 254 129 234 254 130 234 minecraft:light_gray_concrete
setblock 254 129 239 minecraft:light[level=15]
setblock 254 129 247 minecraft:light[level=15]
setblock 254 129 255 minecraft:light[level=15]
setblock 254 129 263 minecraft:light[level=15]
fill 254 129 264 254 130 264 minecraft:cyan_terracotta
fill 254 129 269 254 130 269 minecraft:cyan_terracotta
fill 256 129 229 256 130 229 minecraft:light_gray_concrete
fill 256 129 234 256 130 234 minecraft:light_gray_concrete
fill 256 129 264 256 130 264 minecraft:cyan_terracotta
fill 256 129 269 256 130 269 minecraft:cyan_terracotta
setblock 256 129 270 minecraft:pearlescent_froglight
fill 258 129 229 258 130 229 minecraft:light_gray_concrete
fill 258 129 234 258 130 234 minecraft:light_gray_concrete
fill 258 129 264 258 130 264 minecraft:cyan_terracotta
fill 258 129 269 258 130 269 minecraft:cyan_terracotta
fill 260 129 229 260 130 229 minecraft:light_gray_concrete
fill 260 129 234 260 130 234 minecraft:light_gray_concrete
fill 260 129 264 260 130 264 minecraft:cyan_terracotta
fill 260 129 269 260 130 269 minecraft:cyan_terracotta
fill 262 129 230 262 130 230 minecraft:light_gray_concrete
fill 262 129 232 262 130 232 minecraft:light_gray_concrete
setblock 262 129 239 minecraft:light[level=15]
setblock 262 129 247 minecraft:light[level=15]
setblock 262 129 255 minecraft:light[level=15]
setblock 262 129 263 minecraft:light[level=15]
fill 262 129 265 262 130 265 minecraft:cyan_terracotta
fill 262 129 267 262 130 267 minecraft:cyan_terracotta
fill 265 129 270 265 308 270 minecraft:black_concrete
fill 267 129 228 267 139 228 minecraft:black_concrete
fill 268 129 230 268 130 230 minecraft:cyan_terracotta
fill 268 129 232 268 130 232 minecraft:cyan_terracotta
fill 268 129 234 268 130 234 minecraft:cyan_terracotta
fill 268 129 236 268 130 236 minecraft:cyan_terracotta
fill 268 129 262 268 130 262 minecraft:light_gray_concrete
fill 268 129 264 268 130 264 minecraft:light_gray_concrete
fill 268 129 266 268 130 266 minecraft:light_gray_concrete
fill 268 129 268 268 130 268 minecraft:light_gray_concrete
fill 269 129 229 269 130 229 minecraft:cyan_terracotta
fill 269 129 237 269 130 237 minecraft:cyan_terracotta
fill 269 129 261 269 130 261 minecraft:light_gray_concrete
fill 269 129 269 269 130 269 minecraft:light_gray_concrete
setblock 270 129 239 minecraft:light[level=15]
setblock 270 129 247 minecraft:light[level=15]
setblock 270 129 255 minecraft:light[level=15]
fill 271 129 229 271 130 229 minecraft:cyan_terracotta
fill 271 129 237 271 130 237 minecraft:cyan_terracotta
fill 271 129 243 271 130 243 minecraft:light_gray_concrete
fill 271 129 245 271 130 245 minecraft:light_gray_concrete
fill 271 129 247 271 130 247 minecraft:light_gray_concrete
fill 271 129 249 271 130 249 minecraft:light_gray_concrete
fill 271 129 251 271 130 251 minecraft:light_gray_concrete
fill 271 129 253 271 130 253 minecraft:light_gray_concrete
fill 271 129 261 271 130 261 minecraft:light_gray_concrete
fill 271 129 269 271 130 269 minecraft:light_gray_concrete
fill 272 129 242 272 130 242 minecraft:light_gray_concrete
fill 272 129 255 272 130 255 minecraft:light_gray_concrete
fill 273 129 229 273 130 229 minecraft:cyan_terracotta
fill 273 129 237 273 130 237 minecraft:cyan_terracotta
fill 273 129 261 273 130 261 minecraft:light_gray_concrete
fill 273 129 269 273 130 269 minecraft:light_gray_concrete
fill 274 129 242 274 130 242 minecraft:light_gray_concrete
fill 274 129 255 274 130 255 minecraft:light_gray_concrete
fill 275 129 229 275 130 229 minecraft:cyan_terracotta
fill 275 129 237 275 130 237 minecraft:cyan_terracotta
fill 275 129 261 275 130 261 minecraft:light_gray_concrete
fill 275 129 269 275 130 269 minecraft:light_gray_concrete
fill 276 129 230 276 130 230 minecraft:cyan_terracotta
fill 276 129 232 276 130 232 minecraft:cyan_terracotta
fill 276 129 234 276 130 234 minecraft:cyan_terracotta
fill 276 129 236 276 130 236 minecraft:cyan_terracotta
fill 276 129 243 276 130 243 minecraft:light_gray_concrete
fill 276 129 245 276 130 245 minecraft:light_gray_concrete
fill 276 129 247 276 130 247 minecraft:light_gray_concrete
fill 276 129 249 276 130 249 minecraft:light_gray_concrete
fill 276 129 251 276 130 251 minecraft:light_gray_concrete
fill 276 129 253 276 130 253 minecraft:light_gray_concrete
fill 276 129 262 276 130 262 minecraft:light_gray_concrete
fill 276 129 264 276 130 264 minecraft:light_gray_concrete
fill 276 129 266 276 130 266 minecraft:light_gray_concrete
fill 276 129 268 276 130 268 minecraft:light_gray_concrete
setblock 277 129 230 minecraft:magenta_concrete
fill 277 129 231 277 136 231 minecraft:black_concrete
setblock 277 129 250 minecraft:verdant_froglight
fill 277 129 251 277 130 251 minecraft:black_concrete
setblock 235 130 264 minecraft:magenta_concrete
fill 243 130 228 243 224 228 minecraft:black_concrete
fill 256 130 270 256 253 270 minecraft:black_concrete
setblock 259 130 270 minecraft:ochre_froglight
fill 277 130 230 277 281 230 minecraft:black_concrete
fill 277 130 250 277 308 250 minecraft:black_concrete
fill 235 131 264 235 191 264 minecraft:black_concrete
setblock 236 131 230 minecraft:light_blue_stained_glass
setblock 236 131 232 minecraft:black_stained_glass
setblock 236 131 234 minecraft:black_stained_glass
setblock 236 131 236 minecraft:black_stained_glass
setblock 236 131 243 minecraft:black_stained_glass
setblock 236 131 245 minecraft:cyan_stained_glass
setblock 236 131 247 minecraft:sea_lantern
setblock 236 131 249 minecraft:sea_lantern
setblock 236 131 251 minecraft:black_stained_glass
setblock 236 131 253 minecraft:black_stained_glass
setblock 236 131 262 minecraft:sea_lantern
setblock 236 131 264 minecraft:black_stained_glass
setblock 236 131 266 minecraft:light_blue_stained_glass
setblock 236 131 268 minecraft:light_blue_stained_glass
setblock 237 131 229 minecraft:sea_lantern
setblock 237 131 237 minecraft:pearlescent_froglight
setblock 237 131 242 minecraft:cyan_stained_glass
setblock 237 131 255 minecraft:magenta_stained_glass
setblock 237 131 261 minecraft:magenta_stained_glass
setblock 237 131 269 minecraft:pearlescent_froglight
setblock 239 131 229 minecraft:black_stained_glass
setblock 239 131 237 minecraft:cyan_stained_glass
setblock 239 131 242 minecraft:light_blue_stained_glass
setblock 239 131 255 minecraft:light_blue_stained_glass
setblock 239 131 261 minecraft:cyan_stained_glass
setblock 239 131 269 minecraft:light_blue_stained_glass
setblock 241 131 229 minecraft:black_stained_glass
setblock 241 131 237 minecraft:black_stained_glass
setblock 241 131 243 minecraft:black_stained_glass
setblock 241 131 245 minecraft:ochre_froglight
setblock 241 131 247 minecraft:ochre_froglight
setblock 241 131 249 minecraft:magenta_stained_glass
setblock 241 131 251 minecraft:cyan_stained_glass
setblock 241 131 253 minecraft:cyan_stained_glass
setblock 241 131 261 minecraft:pearlescent_froglight
setblock 241 131 269 minecraft:ochre_froglight
setblock 243 131 229 minecraft:light_blue_stained_glass
setblock 243 131 237 minecraft:black_stained_glass
setblock 243 131 261 minecraft:black_stained_glass
setblock 243 131 269 minecraft:black_stained_glass
setblock 244 131 230 minecraft:black_stained_glass
setblock 244 131 232 minecraft:cyan_stained_glass
setblock 244 131 234 minecraft:cyan_stained_glass
setblock 244 131 236 minecraft:pearlescent_froglight
setblock 244 131 262 minecraft:ochre_froglight
setblock 244 131 264 minecraft:black_stained_glass
setblock 244 131 266 minecraft:black_stained_glass
setblock 244 131 268 minecraft:black_stained_glass
setblock 249 131 230 minecraft:sea_lantern
setblock 249 131 232 minecraft:black_stained_glass
setblock 249 131 265 minecraft:black_stained_glass
setblock 249 131 267 minecraft:sea_lantern
setblock 250 131 229 minecraft:pearlescent_froglight
setblock 250 131 234 minecraft:light_blue_stained_glass
setblock 250 131 264 minecraft:black_stained_glass
setblock 250 131 269 minecraft:ochre_froglight
setblock 252 131 229 minecraft:pearlescent_froglight
setblock 252 131 234 minecraft:black_stained_glass
setblock 252 131 264 minecraft:black_stained_glass
setblock 252 131 269 minecraft:black_stained_glass
setblock 254 131 229 minecraft:ochre_froglight
setblock 254 131 234 minecraft:black_stained_glass
setblock 254 131 264 minecraft:magenta_stained_glass
setblock 254 131 269 minecraft:black_stained_glass
setblock 256 131 229 minecraft:magenta_stained_glass
setblock 256 131 234 minecraft:pearlescent_froglight
setblock 256 131 264 minecraft:ochre_froglight
setblock 256 131 269 minecraft:ochre_froglight
setblock 258 131 229 minecraft:black_stained_glass
setblock 258 131 234 minecraft:ochre_froglight
setblock 258 131 264 minecraft:light_blue_stained_glass
setblock 258 131 269 minecraft:cyan_stained_glass
fill 259 131 270 259 149 270 minecraft:black_concrete
setblock 260 131 229 minecraft:black_stained_glass
setblock 260 131 234 minecraft:magenta_stained_glass
setblock 260 131 264 minecraft:sea_lantern
setblock 260 131 269 minecraft:light_blue_stained_glass
setblock 262 131 230 minecraft:black_stained_glass
setblock 262 131 232 minecraft:black_stained_glass
setblock 262 131 265 minecraft:black_stained_glass
setblock 262 131 267 minecraft:black_stained_glass
setblock 268 131 230 minecraft:sea_lantern
setblock 268 131 232 minecraft:black_stained_glass
setblock 268 131 234 minecraft:pearlescent_froglight
setblock 268 131 236 minecraft:black_stained_glass
setblock 268 131 262 minecraft:ochre_froglight
setblock 268 131 264 minecraft:sea_lantern
setblock 268 131 266 minecraft:black_stained_glass
setblock 268 131 268 minecraft:black_stained_glass
setblock 269 131 229 minecraft:light_blue_stained_glass
setblock 269 131 237 minecraft:black_stained_glass
setblock 269 131 261 minecraft:magenta_stained_glass
setblock 269 131 269 minecraft:black_stained_glass
setblock 271 131 229 minecraft:black_stained_glass
setblock 271 131 237 minecraft:cyan_stained_glass
setblock 271 131 243 minecraft:cyan_stained_glass
setblock 271 131 245 minecraft:black_stained_glass
setblock 271 131 247 minecraft:ochre_froglight
setblock 271 131 249 minecraft:sea_lantern
setblock 271 131 251 minecraft:ochre_froglight
setblock 271 131 253 minecraft:sea_lantern
setblock 271 131 261 minecraft:sea_lantern
setblock 271 131 269 minecraft:cyan_stained_glass
setblock 272 131 242 minecraft:cyan_stained_glass
setblock 272 131 255 minecraft:black_stained_glass
setblock 273 131 229 minecraft:magenta_stained_glass
setblock 273 131 237 minecraft:ochre_froglight
setblock 273 131 261 minecraft:sea_lantern
setblock 273 131 269 minecraft:black_stained_glass
setblock 274 131 242 minecraft:black_stained_glass
setblock 274 131 255 minecraft:sea_lantern
setblock 275 131 229 minecraft:ochre_froglight
setblock 275 131 237 minecraft:ochre_froglight
setblock 275 131 261 minecraft:ochre_froglight
setblock 275 131 269 minecraft:cyan_stained_glass
setblock 276 131 230 minecraft:cyan_stained_glass
setblock 276 131 232 minecraft:black_stained_glass
setblock 276 131 234 minecraft:black_stained_glass
setblock 276 131 236 minecraft:black_stained_glass
setblock 276 131 243 minecraft:sea_lantern
setblock 276 131 245 minecraft:black_stained_glass
setblock 276 131 247 minecraft:black_stained_glass
setblock 276 131 249 minecraft:black_stained_glass
setblock 276 131 251 minecraft:magenta_stained_glass
setblock 276 131 253 minecraft:black_stained_glass
setblock 276 131 262 minecraft:magenta_stained_glass
setblock 276 131 264 minecraft:black_stained_glass
setblock 276 131 266 minecraft:black_stained_glass
setblock 276 131 268 minecraft:black_stained_glass
setblock 277 131 251 minecraft:cyan_concrete
fill 236 132 230 236 133 230 minecraft:light_gray_concrete
fill 236 132 232 236 133 232 minecraft:light_gray_concrete
fill 236 132 234 236 133 234 minecraft:light_gray_concrete
fill 236 132 236 236 133 236 minecraft:light_gray_concrete
fill 236 132 243 236 133 243 minecraft:light_gray_concrete
fill 236 132 245 236 133 245 minecraft:light_gray_concrete
fill 236 132 247 236 133 247 minecraft:light_gray_concrete
fill 236 132 249 236 133 249 minecraft:light_gray_concrete
fill 236 132 251 236 133 251 minecraft:light_gray_concrete
fill 236 132 253 236 133 253 minecraft:light_gray_concrete
fill 236 132 262 236 133 262 minecraft:cyan_terracotta
fill 236 132 264 236 133 264 minecraft:cyan_terracotta
fill 236 132 266 236 133 266 minecraft:cyan_terracotta
fill 236 132 268 236 133 268 minecraft:cyan_terracotta
fill 237 132 229 237 133 229 minecraft:light_gray_concrete
fill 237 132 237 237 133 237 minecraft:light_gray_concrete
fill 237 132 242 237 133 242 minecraft:light_gray_concrete
fill 237 132 255 237 133 255 minecraft:light_gray_concrete
fill 237 132 261 237 133 261 minecraft:cyan_terracotta
fill 237 132 269 237 133 269 minecraft:cyan_terracotta
fill 239 132 229 239 133 229 minecraft:light_gray_concrete
fill 239 132 237 239 133 237 minecraft:light_gray_concrete
fill 239 132 242 239 133 242 minecraft:light_gray_concrete
fill 239 132 255 239 133 255 minecraft:light_gray_concrete
fill 239 132 261 239 133 261 minecraft:cyan_terracotta
fill 239 132 269 239 133 269 minecraft:cyan_terracotta
fill 241 132 229 241 133 229 minecraft:light_gray_concrete
fill 241 132 237 241 133 237 minecraft:light_gray_concrete
fill 241 132 243 241 133 243 minecraft:light_gray_concrete
fill 241 132 245 241 133 245 minecraft:light_gray_concrete
fill 241 132 247 241 133 247 minecraft:light_gray_concrete
fill 241 132 249 241 133 249 minecraft:light_gray_concrete
fill 241 132 251 241 133 251 minecraft:light_gray_concrete
fill 241 132 253 241 133 253 minecraft:light_gray_concrete
fill 241 132 261 241 133 261 minecraft:cyan_terracotta
fill 241 132 269 241 133 269 minecraft:cyan_terracotta
setblock 241 132 270 minecraft:pearlescent_froglight
fill 243 132 229 243 133 229 minecraft:light_gray_concrete
fill 243 132 237 243 133 237 minecraft:light_gray_concrete
fill 243 132 261 243 133 261 minecraft:cyan_terracotta
fill 243 132 269 243 133 269 minecraft:cyan_terracotta
fill 244 132 230 244 133 230 minecraft:light_gray_concrete
fill 244 132 232 244 133 232 minecraft:light_gray_concrete
fill 244 132 234 244 133 234 minecraft:light_gray_concrete
fill 244 132 236 244 133 236 minecraft:light_gray_concrete
fill 244 132 262 244 133 262 minecraft:cyan_terracotta
fill 244 132 264 244 133 264 minecraft:cyan_terracotta
fill 244 132 266 244 133 266 minecraft:cyan_terracotta
fill 244 132 268 244 133 268 minecraft:cyan_terracotta
fill 249 132 230 249 133 230 minecraft:light_gray_concrete
fill 249 132 232 249 133 232 minecraft:light_gray_concrete
fill 249 132 265 249 133 265 minecraft:cyan_terracotta
fill 249 132 267 249 133 267 minecraft:cyan_terracotta
fill 250 132 229 250 133 229 minecraft:light_gray_concrete
fill 250 132 234 250 133 234 minecraft:light_gray_concrete
fill 250 132 264 250 133 264 minecraft:cyan_terracotta
fill 250 132 269 250 133 269 minecraft:cyan_terracotta
fill 252 132 229 252 133 229 minecraft:light_gray_concrete
fill 252 132 234 252 133 234 minecraft:light_gray_concrete
fill 252 132 264 252 133 264 minecraft:cyan_terracotta
fill 252 132 269 252 133 269 minecraft:cyan_terracotta
fill 254 132 229 254 133 229 minecraft:light_gray_concrete
fill 254 132 234 254 133 234 minecraft:light_gray_concrete
fill 254 132 264 254 133 264 minecraft:cyan_terracotta
fill 254 132 269 254 133 269 minecraft:cyan_terracotta
fill 256 132 229 256 133 229 minecraft:light_gray_concrete
fill 256 132 234 256 133 234 minecraft:light_gray_concrete
fill 256 132 264 256 133 264 minecraft:cyan_terracotta
fill 256 132 269 256 133 269 minecraft:cyan_terracotta
fill 258 132 229 258 133 229 minecraft:light_gray_concrete
fill 258 132 234 258 133 234 minecraft:light_gray_concrete
fill 258 132 264 258 133 264 minecraft:cyan_terracotta
fill 258 132 269 258 133 269 minecraft:cyan_terracotta
fill 260 132 229 260 133 229 minecraft:light_gray_concrete
fill 260 132 234 260 133 234 minecraft:light_gray_concrete
fill 260 132 264 260 133 264 minecraft:cyan_terracotta
fill 260 132 269 260 133 269 minecraft:cyan_terracotta
fill 262 132 230 262 133 230 minecraft:light_gray_concrete
fill 262 132 232 262 133 232 minecraft:light_gray_concrete
fill 262 132 265 262 133 265 minecraft:cyan_terracotta
fill 262 132 267 262 133 267 minecraft:cyan_terracotta
fill 268 132 230 268 133 230 minecraft:cyan_terracotta
fill 268 132 232 268 133 232 minecraft:cyan_terracotta
fill 268 132 234 268 133 234 minecraft:cyan_terracotta
fill 268 132 236 268 133 236 minecraft:cyan_terracotta
fill 268 132 262 268 133 262 minecraft:light_gray_concrete
fill 268 132 264 268 133 264 minecraft:light_gray_concrete
fill 268 132 266 268 133 266 minecraft:light_gray_concrete
fill 268 132 268 268 133 268 minecraft:light_gray_concrete
fill 269 132 229 269 133 229 minecraft:cyan_terracotta
fill 269 132 237 269 133 237 minecraft:cyan_terracotta
fill 269 132 261 269 133 261 minecraft:light_gray_concrete
fill 269 132 269 269 133 269 minecraft:light_gray_concrete
setblock 270 132 256 minecraft:sea_lantern
fill 271 132 229 271 133 229 minecraft:cyan_terracotta
fill 271 132 237 271 133 237 minecraft:cyan_terracotta
fill 271 132 243 271 133 243 minecraft:light_gray_concrete
fill 271 132 245 271 133 245 minecraft:light_gray_concrete
fill 271 132 247 271 133 247 minecraft:light_gray_concrete
fill 271 132 249 271 133 249 minecraft:light_gray_concrete
fill 271 132 251 271 133 251 minecraft:light_gray_concrete
fill 271 132 253 271 133 253 minecraft:light_gray_concrete
fill 271 132 261 271 133 261 minecraft:light_gray_concrete
fill 271 132 269 271 133 269 minecraft:light_gray_concrete
fill 272 132 242 272 133 242 minecraft:light_gray_concrete
fill 272 132 255 272 133 255 minecraft:light_gray_concrete
fill 272 132 270 272 243 270 minecraft:black_concrete
fill 273 132 229 273 133 229 minecraft:cyan_terracotta
fill 273 132 237 273 133 237 minecraft:cyan_terracotta
fill 273 132 261 273 133 261 minecraft:light_gray_concrete
fill 273 132 269 273 133 269 minecraft:light_gray_concrete
setblock 273 132 270 minecraft:ochre_froglight
fill 274 132 242 274 133 242 minecraft:light_gray_concrete
fill 274 132 255 274 133 255 minecraft:light_gray_concrete
fill 275 132 229 275 133 229 minecraft:cyan_terracotta
fill 275 132 237 275 133 237 minecraft:cyan_terracotta
fill 275 132 261 275 133 261 minecraft:light_gray_concrete
fill 275 132 269 275 133 269 minecraft:light_gray_concrete
fill 276 132 230 276 133 230 minecraft:cyan_terracotta
fill 276 132 232 276 133 232 minecraft:cyan_terracotta
fill 276 132 234 276 133 234 minecraft:cyan_terracotta
fill 276 132 236 276 133 236 minecraft:cyan_terracotta
fill 276 132 243 276 133 243 minecraft:light_gray_concrete
fill 276 132 245 276 133 245 minecraft:light_gray_concrete
fill 276 132 247 276 133 247 minecraft:light_gray_concrete
fill 276 132 249 276 133 249 minecraft:light_gray_concrete
fill 276 132 251 276 133 251 minecraft:light_gray_concrete
fill 276 132 253 276 133 253 minecraft:light_gray_concrete
fill 276 132 262 276 133 262 minecraft:light_gray_concrete
fill 276 132 264 276 133 264 minecraft:light_gray_concrete
fill 276 132 266 276 133 266 minecraft:light_gray_concrete
fill 276 132 268 276 133 268 minecraft:light_gray_concrete
fill 277 132 251 277 190 251 minecraft:black_concrete
setblock 235 133 254 minecraft:sea_lantern
setblock 238 133 238 minecraft:light[level=12]
setblock 238 133 259 minecraft:light[level=12]
fill 241 133 270 241 186 270 minecraft:black_concrete
setblock 245 133 231 minecraft:light[level=12]
setblock 245 133 238 minecraft:light[level=12]
setblock 245 133 245 minecraft:light[level=12]
setblock 245 133 252 minecraft:light[level=12]
setblock 245 133 259 minecraft:light[level=12]
setblock 245 133 266 minecraft:light[level=12]
setblock 252 133 238 minecraft:light[level=12]
setblock 252 133 245 minecraft:light[level=12]
setblock 252 133 252 minecraft:light[level=12]
setblock 252 133 259 minecraft:light[level=12]
setblock 259 133 238 minecraft:light[level=12]
setblock 259 133 245 minecraft:light[level=12]
setblock 259 133 252 minecraft:light[level=12]
setblock 259 133 259 minecraft:light[level=12]
setblock 266 133 231 minecraft:light[level=12]
setblock 266 133 238 minecraft:light[level=12]
setblock 266 133 245 minecraft:light[level=12]
setblock 266 133 252 minecraft:light[level=12]
setblock 266 133 259 minecraft:light[level=12]
setblock 266 133 266 minecraft:light[level=12]
fill 269 133 255 271 133 257 minecraft:magenta_concrete
setblock 270 133 254 minecraft:magenta_concrete
setblock 270 133 258 minecraft:magenta_concrete
fill 271 133 254 271 141 254 minecraft:light_gray_concrete
setblock 273 133 238 minecraft:light[level=12]
setblock 273 133 259 minecraft:light[level=12]
fill 273 133 270 273 140 270 minecraft:black_concrete
fill 235 134 254 235 158 254 minecraft:black_concrete
setblock 236 134 230 minecraft:pearlescent_froglight
setblock 236 134 232 minecraft:black_stained_glass
setblock 236 134 234 minecraft:black_stained_glass
setblock 236 134 236 minecraft:cyan_stained_glass
setblock 236 134 243 minecraft:black_stained_glass
setblock 236 134 245 minecraft:ochre_froglight
setblock 236 134 247 minecraft:sea_lantern
setblock 236 134 249 minecraft:black_stained_glass
setblock 236 134 251 minecraft:black_stained_glass
setblock 236 134 253 minecraft:light_blue_stained_glass
setblock 236 134 262 minecraft:sea_lantern
setblock 236 134 264 minecraft:black_stained_glass
setblock 236 134 266 minecraft:sea_lantern
setblock 236 134 268 minecraft:sea_lantern
setblock 237 134 229 minecraft:black_stained_glass
setblock 237 134 237 minecraft:light_blue_stained_glass
setblock 237 134 242 minecraft:light_blue_stained_glass
setblock 237 134 255 minecraft:light_blue_stained_glass
setblock 237 134 261 minecraft:light_blue_stained_glass
setblock 237 134 269 minecraft:black_stained_glass
setblock 239 134 229 minecraft:pearlescent_froglight
setblock 239 134 237 minecraft:black_stained_glass
setblock 239 134 242 minecraft:black_stained_glass
setblock 239 134 255 minecraft:sea_lantern
setblock 239 134 261 minecraft:magenta_stained_glass
setblock 239 134 269 minecraft:black_stained_glass
setblock 241 134 229 minecraft:black_stained_glass
setblock 241 134 237 minecraft:cyan_stained_glass
setblock 241 134 243 minecraft:magenta_stained_glass
setblock 241 134 245 minecraft:sea_lantern
setblock 241 134 247 minecraft:black_stained_glass
setblock 241 134 249 minecraft:cyan_stained_glass
setblock 241 134 251 minecraft:pearlescent_froglight
setblock 241 134 253 minecraft:black_stained_glass
setblock 241 134 261 minecraft:black_stained_glass
setblock 241 134 269 minecraft:black_stained_glass
setblock 243 134 229 minecraft:black_stained_glass
setblock 243 134 237 minecraft:sea_lantern
setblock 243 134 261 minecraft:magenta_stained_glass
setblock 243 134 269 minecraft:black_stained_glass
setblock 244 134 230 minecraft:pearlescent_froglight
setblock 244 134 232 minecraft:black_stained_glass
setblock 244 134 234 minecraft:ochre_froglight
setblock 244 134 236 minecraft:black_stained_glass
setblock 244 134 262 minecraft:ochre_froglight
setblock 244 134 264 minecraft:magenta_stained_glass
setblock 244 134 266 minecraft:light_blue_stained_glass
setblock 244 134 268 minecraft:black_stained_glass
setblock 249 134 230 minecraft:black_stained_glass
setblock 249 134 232 minecraft:black_stained_glass
setblock 249 134 265 minecraft:sea_lantern
setblock 249 134 267 minecraft:pearlescent_froglight
setblock 250 134 229 minecraft:magenta_stained_glass
setblock 250 134 234 minecraft:black_stained_glass
setblock 250 134 264 minecraft:pearlescent_froglight
setblock 250 134 269 minecraft:black_stained_glass
setblock 252 134 229 minecraft:black_stained_glass
setblock 252 134 234 minecraft:black_stained_glass
setblock 252 134 264 minecraft:magenta_stained_glass
setblock 252 134 269 minecraft:magenta_stained_glass
setblock 254 134 229 minecraft:cyan_stained_glass
setblock 254 134 234 minecraft:sea_lantern
setblock 254 134 264 minecraft:sea_lantern
setblock 254 134 269 minecraft:black_stained_glass
setblock 256 134 229 minecraft:black_stained_glass
setblock 256 134 234 minecraft:ochre_froglight
setblock 256 134 264 minecraft:black_stained_glass
setblock 256 134 269 minecraft:pearlescent_froglight
setblock 258 134 229 minecraft:cyan_stained_glass
setblock 258 134 234 minecraft:black_stained_glass
setblock 258 134 264 minecraft:ochre_froglight
setblock 258 134 269 minecraft:black_stained_glass
setblock 260 134 229 minecraft:cyan_stained_glass
setblock 260 134 234 minecraft:black_stained_glass
setblock 260 134 264 minecraft:cyan_stained_glass
setblock 260 134 269 minecraft:black_stained_glass
setblock 262 134 230 minecraft:black_stained_glass
setblock 262 134 232 minecraft:cyan_stained_glass
setblock 262 134 265 minecraft:cyan_stained_glass
setblock 262 134 267 minecraft:pearlescent_froglight
setblock 264 134 228 minecraft:cyan_concrete
setblock 268 134 230 minecraft:black_stained_glass
setblock 268 134 232 minecraft:black_stained_glass
setblock 268 134 234 minecraft:sea_lantern
setblock 268 134 236 minecraft:black_stained_glass
setblock 268 134 262 minecraft:sea_lantern
setblock 268 134 264 minecraft:black_stained_glass
setblock 268 134 266 minecraft:black_stained_glass
setblock 268 134 268 minecraft:black_stained_glass
setblock 269 134 229 minecraft:ochre_froglight
setblock 269 134 237 minecraft:ochre_froglight
setblock 269 134 261 minecraft:pearlescent_froglight
setblock 269 134 269 minecraft:pearlescent_froglight
fill 270 134 255 270 134 257 minecraft:light_blue_stained_glass
setblock 271 134 229 minecraft:cyan_stained_glass
setblock 271 134 237 minecraft:ochre_froglight
setblock 271 134 243 minecraft:sea_lantern
setblock 271 134 245 minecraft:black_stained_glass
setblock 271 134 247 minecraft:light_blue_stained_glass
setblock 271 134 249 minecraft:black_stained_glass
setblock 271 134 251 minecraft:magenta_stained_glass
setblock 271 134 253 minecraft:black_stained_glass
fill 271 134 255 271 141 255 minecraft:light_gray_concrete
setblock 271 134 261 minecraft:light_blue_stained_glass
setblock 271 134 269 minecraft:magenta_stained_glass
setblock 272 134 242 minecraft:sea_lantern
setblock 272 134 255 minecraft:black_stained_glass
setblock 273 134 229 minecraft:black_stained_glass
setblock 273 134 237 minecraft:black_stained_glass
setblock 273 134 261 minecraft:sea_lantern
setblock 273 134 269 minecraft:black_stained_glass
setblock 274 134 242 minecraft:black_stained_glass
setblock 274 134 255 minecraft:magenta_stained_glass
setblock 275 134 229 minecraft:light_blue_stained_glass
setblock 275 134 237 minecraft:black_stained_glass
setblock 275 134 261 minecraft:black_stained_glass
setblock 275 134 269 minecraft:magenta_stained_glass
setblock 276 134 230 minecraft:magenta_stained_glass
setblock 276 134 232 minecraft:sea_lantern
setblock 276 134 234 minecraft:light_blue_stained_glass
setblock 276 134 236 minecraft:light_blue_stained_glass
setblock 276 134 243 minecraft:black_stained_glass
setblock 276 134 245 minecraft:cyan_stained_glass
setblock 276 134 247 minecraft:black_stained_glass
setblock 276 134 249 minecraft:magenta_stained_glass
setblock 276 134 251 minecraft:black_stained_glass
setblock 276 134 253 minecraft:black_stained_glass
setblock 276 134 262 minecraft:black_stained_glass
setblock 276 134 264 minecraft:black_stained_glass
setblock 276 134 266 minecraft:black_stained_glass
setblock 276 134 268 minecraft:black_stained_glass
setblock 235 135 247 minecraft:cyan_concrete
fill 236 135 230 236 136 230 minecraft:light_gray_concrete
fill 236 135 232 236 136 232 minecraft:light_gray_concrete
fill 236 135 234 236 136 234 minecraft:light_gray_concrete
fill 236 135 236 236 136 236 minecraft:light_gray_concrete
fill 236 135 243 236 136 243 minecraft:light_gray_concrete
fill 236 135 245 236 136 245 minecraft:light_gray_concrete
fill 236 135 247 236 136 247 minecraft:light_gray_concrete
fill 236 135 249 236 136 249 minecraft:light_gray_concrete
fill 236 135 251 236 136 251 minecraft:light_gray_concrete
fill 236 135 253 236 136 253 minecraft:light_gray_concrete
fill 236 135 262 236 136 262 minecraft:cyan_terracotta
fill 236 135 264 236 136 264 minecraft:cyan_terracotta
fill 236 135 266 236 136 266 minecraft:cyan_terracotta
fill 236 135 268 236 136 268 minecraft:cyan_terracotta
fill 237 135 229 237 136 229 minecraft:light_gray_concrete
fill 237 135 237 237 136 237 minecraft:light_gray_concrete
fill 237 135 242 237 136 242 minecraft:light_gray_concrete
fill 237 135 255 237 136 255 minecraft:light_gray_concrete
fill 237 135 261 237 136 261 minecraft:cyan_terracotta
fill 237 135 269 237 136 269 minecraft:cyan_terracotta
fill 239 135 229 239 136 229 minecraft:light_gray_concrete
fill 239 135 237 239 136 237 minecraft:light_gray_concrete
fill 239 135 242 239 136 242 minecraft:light_gray_concrete
fill 239 135 255 239 136 255 minecraft:light_gray_concrete
fill 239 135 261 239 136 261 minecraft:cyan_terracotta
fill 239 135 269 239 136 269 minecraft:cyan_terracotta
fill 241 135 229 241 136 229 minecraft:light_gray_concrete
fill 241 135 237 241 136 237 minecraft:light_gray_concrete
fill 241 135 243 241 136 243 minecraft:light_gray_concrete
fill 241 135 245 241 136 245 minecraft:light_gray_concrete
fill 241 135 247 241 136 247 minecraft:light_gray_concrete
fill 241 135 249 241 136 249 minecraft:light_gray_concrete
fill 241 135 251 241 136 251 minecraft:light_gray_concrete
fill 241 135 253 241 136 253 minecraft:light_gray_concrete
fill 241 135 261 241 136 261 minecraft:cyan_terracotta
fill 241 135 269 241 136 269 minecraft:cyan_terracotta
fill 243 135 229 243 136 229 minecraft:light_gray_concrete
fill 243 135 237 243 136 237 minecraft:light_gray_concrete
fill 243 135 261 243 136 261 minecraft:cyan_terracotta
fill 243 135 269 243 136 269 minecraft:cyan_terracotta
fill 244 135 230 244 136 230 minecraft:light_gray_concrete
fill 244 135 232 244 136 232 minecraft:light_gray_concrete
fill 244 135 234 244 136 234 minecraft:light_gray_concrete
fill 244 135 236 244 136 236 minecraft:light_gray_concrete
fill 244 135 262 244 136 262 minecraft:cyan_terracotta
fill 244 135 264 244 136 264 minecraft:cyan_terracotta
fill 244 135 266 244 136 266 minecraft:cyan_terracotta
fill 244 135 268 244 136 268 minecraft:cyan_terracotta
fill 249 135 230 249 136 230 minecraft:light_gray_concrete
fill 249 135 232 249 136 232 minecraft:light_gray_concrete
fill 249 135 265 249 136 265 minecraft:cyan_terracotta
fill 249 135 267 249 136 267 minecraft:cyan_terracotta
fill 250 135 229 250 136 229 minecraft:light_gray_concrete
fill 250 135 234 250 136 234 minecraft:light_gray_concrete
fill 250 135 264 250 136 264 minecraft:cyan_terracotta
fill 250 135 269 250 136 269 minecraft:cyan_terracotta
fill 252 135 229 252 136 229 minecraft:light_gray_concrete
fill 252 135 234 252 136 234 minecraft:light_gray_concrete
fill 252 135 264 252 136 264 minecraft:cyan_terracotta
fill 252 135 269 252 136 269 minecraft:cyan_terracotta
setblock 253 135 228 minecraft:cyan_concrete
fill 254 135 229 254 136 229 minecraft:light_gray_concrete
fill 254 135 234 254 136 234 minecraft:light_gray_concrete
fill 254 135 264 254 136 264 minecraft:cyan_terracotta
fill 254 135 269 254 136 269 minecraft:cyan_terracotta
fill 256 135 229 256 136 229 minecraft:light_gray_concrete
fill 256 135 234 256 136 234 minecraft:light_gray_concrete
fill 256 135 264 256 136 264 minecraft:cyan_terracotta
fill 256 135 269 256 136 269 minecraft:cyan_terracotta
fill 258 135 229 258 136 229 minecraft:light_gray_concrete
fill 258 135 234 258 136 234 minecraft:light_gray_concrete
fill 258 135 264 258 136 264 minecraft:cyan_terracotta
fill 258 135 269 258 136 269 minecraft:cyan_terracotta
fill 260 135 229 260 136 229 minecraft:light_gray_concrete
fill 260 135 234 260 136 234 minecraft:light_gray_concrete
fill 260 135 264 260 136 264 minecraft:cyan_terracotta
fill 260 135 269 260 136 269 minecraft:cyan_terracotta
fill 262 135 230 262 136 230 minecraft:light_gray_concrete
fill 262 135 232 262 136 232 minecraft:light_gray_concrete
fill 262 135 265 262 136 265 minecraft:cyan_terracotta
fill 262 135 267 262 136 267 minecraft:cyan_terracotta
fill 264 135 228 264 185 228 minecraft:black_concrete
fill 268 135 230 268 136 230 minecraft:cyan_terracotta
fill 268 135 232 268 136 232 minecraft:cyan_terracotta
fill 268 135 234 268 136 234 minecraft:cyan_terracotta
fill 268 135 236 268 136 236 minecraft:cyan_terracotta
fill 268 135 262 268 136 262 minecraft:light_gray_concrete
fill 268 135 264 268 136 264 minecraft:light_gray_concrete
fill 268 135 266 268 136 266 minecraft:light_gray_concrete
fill 268 135 268 268 136 268 minecraft:light_gray_concrete
fill 269 135 229 269 136 229 minecraft:cyan_terracotta
fill 269 135 237 269 136 237 minecraft:cyan_terracotta
fill 269 135 261 269 136 261 minecraft:light_gray_concrete
fill 269 135 269 269 136 269 minecraft:light_gray_concrete
fill 271 135 229 271 136 229 minecraft:cyan_terracotta
fill 271 135 237 271 136 237 minecraft:cyan_terracotta
fill 271 135 243 271 136 243 minecraft:light_gray_concrete
fill 271 135 245 271 136 245 minecraft:light_gray_concrete
fill 271 135 247 271 136 247 minecraft:light_gray_concrete
fill 271 135 249 271 136 249 minecraft:light_gray_concrete
fill 271 135 251 271 136 251 minecraft:light_gray_concrete
fill 271 135 253 271 136 253 minecraft:light_gray_concrete
fill 271 135 261 271 136 261 minecraft:light_gray_concrete
fill 271 135 269 271 136 269 minecraft:light_gray_concrete
fill 272 135 242 272 136 242 minecraft:light_gray_concrete
fill 272 135 255 272 136 255 minecraft:light_gray_concrete
fill 273 135 229 273 136 229 minecraft:cyan_terracotta
fill 273 135 237 273 136 237 minecraft:cyan_terracotta
fill 273 135 261 273 136 261 minecraft:light_gray_concrete
fill 273 135 269 273 136 269 minecraft:light_gray_concrete
fill 274 135 242 274 136 242 minecraft:light_gray_concrete
fill 274 135 255 274 136 255 minecraft:light_gray_concrete
fill 275 135 229 275 136 229 minecraft:cyan_terracotta
fill 275 135 237 275 136 237 minecraft:cyan_terracotta
fill 275 135 261 275 136 261 minecraft:light_gray_concrete
fill 275 135 269 275 136 269 minecraft:light_gray_concrete
fill 276 135 230 276 136 230 minecraft:cyan_terracotta
fill 276 135 232 276 136 232 minecraft:cyan_terracotta
fill 276 135 234 276 136 234 minecraft:cyan_terracotta
fill 276 135 236 276 136 236 minecraft:cyan_terracotta
fill 276 135 243 276 136 243 minecraft:light_gray_concrete
fill 276 135 245 276 136 245 minecraft:light_gray_concrete
fill 276 135 247 276 136 247 minecraft:light_gray_concrete
fill 276 135 249 276 136 249 minecraft:light_gray_concrete
fill 276 135 251 276 136 251 minecraft:light_gray_concrete
fill 276 135 253 276 136 253 minecraft:light_gray_concrete
fill 276 135 262 276 136 262 minecraft:light_gray_concrete
fill 276 135 264 276 136 264 minecraft:light_gray_concrete
fill 276 135 266 276 136 266 minecraft:light_gray_concrete
fill 276 135 268 276 136 268 minecraft:light_gray_concrete
setblock 277 135 254 minecraft:purple_concrete
fill 235 136 247 235 160 247 minecraft:black_concrete
setblock 235 136 255 minecraft:pearlescent_froglight
setblock 238 136 239 minecraft:light[level=15]
setblock 240 136 228 minecraft:cyan_concrete
fill 241 136 228 241 182 228 minecraft:black_concrete
setblock 246 136 231 minecraft:light[level=15]
setblock 246 136 239 minecraft:light[level=15]
setblock 246 136 247 minecraft:light[level=15]
setblock 246 136 255 minecraft:light[level=15]
setblock 246 136 263 minecraft:light[level=15]
fill 253 136 228 253 151 228 minecraft:black_concrete
setblock 254 136 239 minecraft:light[level=15]
setblock 254 136 247 minecraft:light[level=15]
setblock 254 136 255 minecraft:light[level=15]
setblock 254 136 263 minecraft:light[level=15]
setblock 262 136 239 minecraft:light[level=15]
setblock 262 136 247 minecraft:light[level=15]
setblock 262 136 255 minecraft:light[level=15]
setblock 262 136 263 minecraft:light[level=15]
setblock 270 136 239 minecraft:light[level=15]
setblock 270 136 247 minecraft:light[level=15]
setblock 270 136 255 minecraft:light[level=15]
fill 277 136 254 277 155 254 minecraft:black_concrete
fill 235 137 255 235 263 255 minecraft:black_concrete
setblock 236 137 230 minecraft:light_blue_stained_glass
setblock 236 137 232 minecraft:black_stained_glass
setblock 236 137 234 minecraft:black_stained_glass
setblock 236 137 236 minecraft:pearlescent_froglight
setblock 236 137 243 minecraft:black_stained_glass
setblock 236 137 245 minecraft:cyan_stained_glass
setblock 236 137 247 minecraft:pearlescent_froglight
setblock 236 137 249 minecraft:black_stained_glass
setblock 236 137 251 minecraft:light_blue_stained_glass
setblock 236 137 253 minecraft:magenta_stained_glass
setblock 236 137 262 minecraft:pearlescent_froglight
setblock 236 137 264 minecraft:sea_lantern
setblock 236 137 266 minecraft:light_blue_stained_glass
setblock 236 137 268 minecraft:magenta_stained_glass
setblock 237 137 229 minecraft:ochre_froglight
setblock 237 137 237 minecraft:light_blue_stained_glass
setblock 237 137 242 minecraft:ochre_froglight
setblock 237 137 255 minecraft:black_stained_glass
setblock 237 137 261 minecraft:pearlescent_froglight
setblock 237 137 269 minecraft:pearlescent_froglight
setblock 239 137 229 minecraft:pearlescent_froglight
setblock 239 137 237 minecraft:magenta_stained_glass
setblock 239 137 242 minecraft:black_stained_glass
setblock 239 137 255 minecraft:sea_lantern
setblock 239 137 261 minecraft:black_stained_glass
setblock 239 137 269 minecraft:ochre_froglight
fill 240 137 228 240 142 228 minecraft:black_concrete
setblock 241 137 229 minecraft:black_stained_glass
setblock 241 137 237 minecraft:ochre_froglight
setblock 241 137 243 minecraft:sea_lantern
setblock 241 137 245 minecraft:black_stained_glass
setblock 241 137 247 minecraft:pearlescent_froglight
setblock 241 137 249 minecraft:sea_lantern
setblock 241 137 251 minecraft:cyan_stained_glass
setblock 241 137 253 minecraft:light_blue_stained_glass
setblock 241 137 261 minecraft:black_stained_glass
setblock 241 137 269 minecraft:black_stained_glass
setblock 243 137 229 minecraft:black_stained_glass
setblock 243 137 237 minecraft:magenta_stained_glass
setblock 243 137 261 minecraft:light_blue_stained_glass
setblock 243 137 269 minecraft:light_blue_stained_glass
setblock 244 137 230 minecraft:black_stained_glass
setblock 244 137 232 minecraft:black_stained_glass
setblock 244 137 234 minecraft:magenta_stained_glass
setblock 244 137 236 minecraft:black_stained_glass
setblock 244 137 262 minecraft:cyan_stained_glass
setblock 244 137 264 minecraft:black_stained_glass
setblock 244 137 266 minecraft:cyan_stained_glass
setblock 244 137 268 minecraft:sea_lantern
setblock 249 137 230 minecraft:black_stained_glass
setblock 249 137 232 minecraft:pearlescent_froglight
setblock 249 137 265 minecraft:pearlescent_froglight
setblock 249 137 267 minecraft:sea_lantern
setblock 250 137 229 minecraft:black_stained_glass
setblock 250 137 234 minecraft:black_stained_glass
setblock 250 137 264 minecraft:sea_lantern
setblock 250 137 269 minecraft:black_stained_glass
setblock 252 137 229 minecraft:black_stained_glass
setblock 252 137 234 minecraft:sea_lantern
setblock 252 137 264 minecraft:magenta_stained_glass
setblock 252 137 269 minecraft:magenta_stained_glass
setblock 254 137 229 minecraft:light_blue_stained_glass
setblock 254 137 234 minecraft:black_stained_glass
setblock 254 137 264 minecraft:black_stained_glass
setblock 254 137 269 minecraft:black_stained_glass
setblock 256 137 229 minecraft:black_stained_glass
setblock 256 137 234 minecraft:cyan_stained_glass
setblock 256 137 264 minecraft:light_blue_stained_glass
setblock 256 137 269 minecraft:ochre_froglight
setblock 258 137 229 minecraft:black_stained_glass
setblock 258 137 234 minecraft:black_stained_glass
setblock 258 137 264 minecraft:magenta_stained_glass
setblock 258 137 269 minecraft:sea_lantern
setblock 260 137 229 minecraft:black_stained_glass
setblock 260 137 234 minecraft:black_stained_glass
setblock 260 137 264 minecraft:black_stained_glass
setblock 260 137 269 minecraft:black_stained_glass
setblock 262 137 230 minecraft:black_stained_glass
setblock 262 137 232 minecraft:ochre_froglight
setblock 262 137 265 minecraft:black_stained_glass
setblock 262 137 267 minecraft:black_stained_glass
setblock 268 137 230 minecraft:pearlescent_froglight
setblock 268 137 232 minecraft:black_stained_glass
setblock 268 137 234 minecraft:black_stained_glass
setblock 268 137 236 minecraft:sea_lantern
setblock 268 137 262 minecraft:ochre_froglight
setblock 268 137 264 minecraft:cyan_stained_glass
setblock 268 137 266 minecraft:black_stained_glass
setblock 268 137 268 minecraft:black_stained_glass
setblock 269 137 229 minecraft:black_stained_glass
setblock 269 137 237 minecraft:ochre_froglight
setblock 269 137 261 minecraft:cyan_stained_glass
setblock 269 137 269 minecraft:sea_lantern
setblock 271 137 229 minecraft:light_blue_stained_glass
setblock 271 137 237 minecraft:cyan_stained_glass
setblock 271 137 243 minecraft:black_stained_glass
setblock 271 137 245 minecraft:sea_lantern
setblock 271 137 247 minecraft:pearlescent_froglight
setblock 271 137 249 minecraft:ochre_froglight
setblock 271 137 251 minecraft:light_blue_stained_glass
setblock 271 137 253 minecraft:black_stained_glass
setblock 271 137 261 minecraft:light_blue_stained_glass
setblock 271 137 269 minecraft:ochre_froglight
setblock 272 137 242 minecraft:black_stained_glass
setblock 272 137 255 minecraft:black_stained_glass
setblock 273 137 229 minecraft:black_stained_glass
setblock 273 137 237 minecraft:pearlescent_froglight
setblock 273 137 261 minecraft:cyan_stained_glass
setblock 273 137 269 minecraft:black_stained_glass
setblock 274 137 242 minecraft:pearlescent_froglight
setblock 274 137 255 minecraft:sea_lantern
setblock 275 137 229 minecraft:ochre_froglight
setblock 275 137 237 minecraft:magenta_stained_glass
setblock 275 137 261 minecraft:sea_lantern
setblock 275 137 269 minecraft:light_blue_stained_glass
setblock 276 137 230 minecraft:black_stained_glass
setblock 276 137 232 minecraft:sea_lantern
setblock 276 137 234 minecraft:magenta_stained_glass
setblock 276 137 236 minecraft:cyan_stained_glass
setblock 276 137 243 minecraft:pearlescent_froglight
setblock 276 137 245 minecraft:black_stained_glass
setblock 276 137 247 minecraft:magenta_stained_glass
setblock 276 137 249 minecraft:sea_lantern
setblock 276 137 251 minecraft:cyan_stained_glass
setblock 276 137 253 minecraft:cyan_stained_glass
setblock 276 137 262 minecraft:pearlescent_froglight
setblock 276 137 264 minecraft:pearlescent_froglight
setblock 276 137 266 minecraft:black_stained_glass
setblock 276 137 268 minecraft:light_blue_stained_glass
setblock 277 137 231 minecraft:cyan_concrete
fill 236 138 230 236 139 230 minecraft:light_gray_concrete
fill 236 138 232 236 139 232 minecraft:light_gray_concrete
fill 236 138 234 236 139 234 minecraft:light_gray_concrete
fill 236 138 236 236 139 236 minecraft:light_gray_concrete
fill 236 138 243 236 139 243 minecraft:light_gray_concrete
fill 236 138 245 236 139 245 minecraft:light_gray_concrete
fill 236 138 247 236 139 247 minecraft:light_gray_concrete
fill 236 138 249 236 139 249 minecraft:light_gray_concrete
fill 236 138 251 236 139 251 minecraft:light_gray_concrete
fill 236 138 253 236 139 253 minecraft:light_gray_concrete
fill 236 138 262 236 139 262 minecraft:cyan_terracotta
fill 236 138 264 236 139 264 minecraft:cyan_terracotta
fill 236 138 266 236 139 266 minecraft:cyan_terracotta
fill 236 138 268 236 139 268 minecraft:cyan_terracotta
fill 237 138 229 237 139 229 minecraft:light_gray_concrete
fill 237 138 237 237 139 237 minecraft:light_gray_concrete
fill 237 138 242 237 139 242 minecraft:light_gray_concrete
fill 237 138 255 237 139 255 minecraft:light_gray_concrete
fill 237 138 261 237 139 261 minecraft:cyan_terracotta
fill 237 138 269 237 139 269 minecraft:cyan_terracotta
fill 239 138 229 239 139 229 minecraft:light_gray_concrete
fill 239 138 237 239 139 237 minecraft:light_gray_concrete
fill 239 138 242 239 139 242 minecraft:light_gray_concrete
fill 239 138 255 239 139 255 minecraft:light_gray_concrete
fill 239 138 261 239 139 261 minecraft:cyan_terracotta
fill 239 138 269 239 139 269 minecraft:cyan_terracotta
fill 241 138 229 241 139 229 minecraft:light_gray_concrete
fill 241 138 237 241 139 237 minecraft:light_gray_concrete
fill 241 138 243 241 139 243 minecraft:light_gray_concrete
fill 241 138 245 241 139 245 minecraft:light_gray_concrete
fill 241 138 247 241 139 247 minecraft:light_gray_concrete
fill 241 138 249 241 139 249 minecraft:light_gray_concrete
fill 241 138 251 241 139 251 minecraft:light_gray_concrete
fill 241 138 253 241 139 253 minecraft:light_gray_concrete
fill 241 138 261 241 139 261 minecraft:cyan_terracotta
fill 241 138 269 241 139 269 minecraft:cyan_terracotta
fill 243 138 229 243 139 229 minecraft:light_gray_concrete
fill 243 138 237 243 139 237 minecraft:light_gray_concrete
fill 243 138 261 243 139 261 minecraft:cyan_terracotta
fill 243 138 269 243 139 269 minecraft:cyan_terracotta
fill 244 138 230 244 139 230 minecraft:light_gray_concrete
fill 244 138 232 244 139 232 minecraft:light_gray_concrete
fill 244 138 234 244 139 234 minecraft:light_gray_concrete
fill 244 138 236 244 139 236 minecraft:light_gray_concrete
fill 244 138 262 244 139 262 minecraft:cyan_terracotta
fill 244 138 264 244 139 264 minecraft:cyan_terracotta
fill 244 138 266 244 139 266 minecraft:cyan_terracotta
fill 244 138 268 244 139 268 minecraft:cyan_terracotta
fill 249 138 230 249 139 230 minecraft:light_gray_concrete
fill 249 138 232 249 139 232 minecraft:light_gray_concrete
fill 249 138 265 249 139 265 minecraft:cyan_terracotta
fill 249 138 267 249 139 267 minecraft:cyan_terracotta
fill 250 138 229 250 139 229 minecraft:light_gray_concrete
fill 250 138 234 250 139 234 minecraft:light_gray_concrete
fill 250 138 264 250 139 264 minecraft:cyan_terracotta
fill 250 138 269 250 139 269 minecraft:cyan_terracotta
fill 252 138 229 252 139 229 minecraft:light_gray_concrete
fill 252 138 234 252 139 234 minecraft:light_gray_concrete
fill 252 138 264 252 139 264 minecraft:cyan_terracotta
fill 252 138 269 252 139 269 minecraft:cyan_terracotta
fill 254 138 229 254 139 229 minecraft:light_gray_concrete
fill 254 138 234 254 139 234 minecraft:light_gray_concrete
fill 254 138 264 254 139 264 minecraft:cyan_terracotta
fill 254 138 269 254 139 269 minecraft:cyan_terracotta
fill 256 138 229 256 139 229 minecraft:light_gray_concrete
fill 256 138 234 256 139 234 minecraft:light_gray_concrete
fill 256 138 264 256 139 264 minecraft:cyan_terracotta
fill 256 138 269 256 139 269 minecraft:cyan_terracotta
setblock 257 138 270 minecraft:verdant_froglight
fill 258 138 229 258 139 229 minecraft:light_gray_concrete
fill 258 138 234 258 139 234 minecraft:light_gray_concrete
fill 258 138 264 258 139 264 minecraft:cyan_terracotta
fill 258 138 269 258 139 269 minecraft:cyan_terracotta
fill 260 138 229 260 139 229 minecraft:light_gray_concrete
fill 260 138 234 260 139 234 minecraft:light_gray_concrete
fill 260 138 264 260 139 264 minecraft:cyan_terracotta
fill 260 138 269 260 139 269 minecraft:cyan_terracotta
fill 262 138 230 262 139 230 minecraft:light_gray_concrete
fill 262 138 232 262 139 232 minecraft:light_gray_concrete
fill 262 138 265 262 139 265 minecraft:cyan_terracotta
fill 262 138 267 262 139 267 minecraft:cyan_terracotta
fill 268 138 230 268 139 230 minecraft:cyan_terracotta
fill 268 138 232 268 139 232 minecraft:cyan_terracotta
fill 268 138 234 268 139 234 minecraft:cyan_terracotta
fill 268 138 236 268 139 236 minecraft:cyan_terracotta
fill 268 138 262 268 139 262 minecraft:light_gray_concrete
fill 268 138 264 268 139 264 minecraft:light_gray_concrete
fill 268 138 266 268 139 266 minecraft:light_gray_concrete
fill 268 138 268 268 139 268 minecraft:light_gray_concrete
fill 269 138 229 269 139 229 minecraft:cyan_terracotta
fill 269 138 237 269 139 237 minecraft:cyan_terracotta
fill 269 138 261 269 139 261 minecraft:light_gray_concrete
fill 269 138 269 269 139 269 minecraft:light_gray_concrete
fill 271 138 229 271 139 229 minecraft:cyan_terracotta
fill 271 138 237 271 139 237 minecraft:cyan_terracotta
fill 271 138 243 271 139 243 minecraft:light_gray_concrete
fill 271 138 245 271 139 245 minecraft:light_gray_concrete
fill 271 138 247 271 139 247 minecraft:light_gray_concrete
fill 271 138 249 271 139 249 minecraft:light_gray_concrete
fill 271 138 251 271 139 251 minecraft:light_gray_concrete
fill 271 138 253 271 139 253 minecraft:light_gray_concrete
fill 271 138 261 271 139 261 minecraft:light_gray_concrete
fill 271 138 269 271 139 269 minecraft:light_gray_concrete
fill 272 138 242 272 139 242 minecraft:light_gray_concrete
fill 272 138 255 272 139 255 minecraft:light_gray_concrete
fill 273 138 229 273 139 229 minecraft:cyan_terracotta
fill 273 138 237 273 139 237 minecraft:cyan_terracotta
fill 273 138 261 273 139 261 minecraft:light_gray_concrete
fill 273 138 269 273 139 269 minecraft:light_gray_concrete
fill 274 138 242 274 139 242 minecraft:light_gray_concrete
fill 274 138 255 274 139 255 minecraft:light_gray_concrete
fill 275 138 229 275 139 229 minecraft:cyan_terracotta
fill 275 138 237 275 139 237 minecraft:cyan_terracotta
fill 275 138 261 275 139 261 minecraft:light_gray_concrete
fill 275 138 269 275 139 269 minecraft:light_gray_concrete
fill 276 138 230 276 139 230 minecraft:cyan_terracotta
fill 276 138 232 276 139 232 minecraft:cyan_terracotta
fill 276 138 234 276 139 234 minecraft:cyan_terracotta
fill 276 138 236 276 139 236 minecraft:cyan_terracotta
fill 276 138 243 276 139 243 minecraft:light_gray_concrete
fill 276 138 245 276 139 245 minecraft:light_gray_concrete
fill 276 138 247 276 139 247 minecraft:light_gray_concrete
fill 276 138 249 276 139 249 minecraft:light_gray_concrete
fill 276 138 251 276 139 251 minecraft:light_gray_concrete
fill 276 138 253 276 139 253 minecraft:light_gray_concrete
fill 276 138 262 276 139 262 minecraft:light_gray_concrete
fill 276 138 264 276 139 264 minecraft:light_gray_concrete
fill 276 138 266 276 139 266 minecraft:light_gray_concrete
fill 276 138 268 276 139 268 minecraft:light_gray_concrete
fill 277 138 231 277 250 231 minecraft:black_concrete
setblock 235 139 261 minecraft:sea_lantern
setblock 238 139 238 minecraft:light[level=12]
setblock 238 139 259 minecraft:light[level=12]
setblock 245 139 231 minecraft:light[level=12]
setblock 245 139 238 minecraft:light[level=12]
setblock 245 139 245 minecraft:light[level=12]
setblock 245 139 252 minecraft:light[level=12]
setblock 245 139 259 minecraft:light[level=12]
setblock 245 139 266 minecraft:light[level=12]
setblock 250 139 228 minecraft:verdant_froglight
setblock 252 139 238 minecraft:light[level=12]
setblock 252 139 245 minecraft:light[level=12]
setblock 252 139 252 minecraft:light[level=12]
setblock 252 139 259 minecraft:light[level=12]
setblock 254 139 228 minecraft:cyan_concrete
fill 257 139 270 257 150 270 minecraft:black_concrete
setblock 259 139 238 minecraft:light[level=12]
setblock 259 139 245 minecraft:light[level=12]
setblock 259 139 252 minecraft:light[level=12]
setblock 259 139 259 minecraft:light[level=12]
setblock 266 139 231 minecraft:light[level=12]
setblock 266 139 238 minecraft:light[level=12]
setblock 266 139 245 minecraft:light[level=12]
setblock 266 139 252 minecraft:light[level=12]
setblock 266 139 259 minecraft:light[level=12]
setblock 266 139 266 minecraft:light[level=12]
setblock 269 139 228 minecraft:sea_lantern
setblock 273 139 238 minecraft:light[level=12]
setblock 273 139 259 minecraft:light[level=12]
fill 235 140 261 235 208 261 minecraft:black_concrete
schedule function dropper:buildpart/53_4 1t
