setblock 348 114 464 minecraft:red_nether_bricks
setblock 348 114 465 minecraft:pink_terracotta
setblock 348 114 504 minecraft:red_nether_bricks
setblock 349 114 464 minecraft:pink_terracotta
setblock 349 114 504 minecraft:pink_terracotta
fill 351 114 504 352 114 504 minecraft:pink_terracotta
fill 359 114 504 360 114 504 minecraft:pink_terracotta
fill 361 114 503 363 114 503 minecraft:pink_terracotta
setblock 363 114 464 minecraft:red_nether_bricks
fill 363 114 502 364 114 502 minecraft:pink_terracotta
setblock 363 114 504 minecraft:red_nether_bricks
setblock 364 114 464 minecraft:pink_terracotta
setblock 364 114 503 minecraft:red_nether_bricks
setblock 364 114 504 minecraft:pink_terracotta
setblock 365 114 502 minecraft:red_nether_bricks
setblock 365 114 503 minecraft:pink_terracotta
setblock 366 114 501 minecraft:red_nether_bricks
setblock 366 114 502 minecraft:pink_terracotta
setblock 367 114 495 minecraft:red_nether_bricks
setblock 367 114 496 minecraft:pink_terracotta
setblock 367 114 499 minecraft:pink_terracotta
setblock 367 114 500 minecraft:red_nether_bricks
setblock 367 114 501 minecraft:pink_terracotta
setblock 368 114 464 minecraft:red_nether_bricks
setblock 368 114 494 minecraft:red_nether_bricks
setblock 368 114 495 minecraft:pink_terracotta
setblock 368 114 499 minecraft:red_nether_bricks
setblock 368 114 500 minecraft:pink_terracotta
setblock 368 114 504 minecraft:red_nether_bricks
setblock 369 114 474 minecraft:pink_terracotta
setblock 369 114 478 minecraft:red_nether_bricks
setblock 369 114 479 minecraft:pink_terracotta
setblock 369 114 493 minecraft:red_nether_bricks
setblock 369 114 494 minecraft:pink_terracotta
setblock 369 114 498 minecraft:red_nether_bricks
setblock 369 114 499 minecraft:pink_terracotta
setblock 369 114 503 minecraft:red_nether_bricks
setblock 369 114 504 minecraft:pink_terracotta
setblock 370 114 465 minecraft:white_concrete
setblock 370 114 472 minecraft:red_nether_bricks
setblock 370 114 473 minecraft:pink_terracotta
setblock 370 114 477 minecraft:red_nether_bricks
setblock 370 114 478 minecraft:pink_terracotta
setblock 370 114 481 minecraft:pink_terracotta
setblock 370 114 482 minecraft:red_nether_bricks
fill 370 114 483 370 114 486 minecraft:pink_terracotta
setblock 370 114 487 minecraft:red_nether_bricks
setblock 370 114 488 minecraft:pink_terracotta
setblock 370 114 492 minecraft:red_nether_bricks
setblock 370 114 493 minecraft:pink_terracotta
setblock 370 114 497 minecraft:red_nether_bricks
setblock 370 114 498 minecraft:pink_terracotta
setblock 370 114 502 minecraft:red_nether_bricks
setblock 370 114 503 minecraft:pink_terracotta
fill 346 119 482 348 119 484 minecraft:redstone_block
fill 348 119 491 350 119 493 minecraft:redstone_block
fill 352 119 482 354 119 484 minecraft:redstone_block
fill 353 119 489 355 119 491 minecraft:redstone_block
fill 329 120 463 329 120 468 minecraft:red_concrete
setblock 329 120 469 minecraft:pink_terracotta
fill 329 120 470 329 120 480 minecraft:red_concrete
setblock 329 120 481 minecraft:pink_terracotta
fill 329 120 482 329 123 487 minecraft:red_concrete
setblock 329 120 488 minecraft:pink_terracotta
fill 329 120 489 329 123 490 minecraft:red_concrete
setblock 329 120 491 minecraft:pink_terracotta
fill 329 120 492 329 123 493 minecraft:red_concrete
setblock 329 120 494 minecraft:pink_terracotta
fill 329 120 495 329 120 505 minecraft:red_concrete
fill 330 120 463 344 120 463 minecraft:red_concrete
fill 330 120 505 332 120 505 minecraft:red_concrete
setblock 333 120 505 minecraft:pink_terracotta
fill 334 120 505 357 120 505 minecraft:red_concrete
fill 337 120 487 338 121 487 minecraft:red_nether_bricks
fill 338 120 484 339 121 486 minecraft:red_nether_bricks
fill 338 120 488 339 121 490 minecraft:red_nether_bricks
fill 339 120 483 341 121 483 minecraft:red_nether_bricks
fill 339 120 487 345 121 487 minecraft:white_concrete
fill 339 120 491 341 121 491 minecraft:red_nether_bricks
fill 340 120 482 342 121 482 minecraft:red_nether_bricks
fill 340 120 484 340 121 484 minecraft:red_nether_bricks
fill 340 120 485 345 120 486 minecraft:white_concrete
fill 340 120 488 345 121 489 minecraft:white_concrete
fill 340 120 490 340 121 490 minecraft:red_nether_bricks
fill 340 120 492 342 121 492 minecraft:red_nether_bricks
fill 341 120 481 344 121 481 minecraft:red_nether_bricks
fill 341 120 484 345 120 484 minecraft:white_concrete
fill 341 120 490 346 121 490 minecraft:white_concrete
fill 341 120 493 344 121 493 minecraft:red_nether_bricks
fill 342 120 483 345 120 483 minecraft:white_concrete
fill 342 120 491 347 120 491 minecraft:white_concrete
fill 343 120 480 357 121 480 minecraft:red_nether_bricks
fill 343 120 482 345 120 482 minecraft:white_concrete
fill 343 120 492 347 120 492 minecraft:white_concrete
fill 343 120 494 357 120 494 minecraft:red_nether_bricks
setblock 345 120 463 minecraft:pink_terracotta
fill 345 120 479 355 121 479 minecraft:red_nether_bricks
fill 345 120 481 355 120 481 minecraft:white_concrete
fill 345 120 493 347 120 493 minecraft:white_concrete
fill 345 120 495 355 121 495 minecraft:red_nether_bricks
fill 346 120 463 349 121 463 minecraft:red_concrete
setblock 346 120 485 minecraft:gray_concrete
fill 346 120 486 347 121 488 minecraft:black_concrete
fill 346 120 489 346 121 489 minecraft:gray_concrete
fill 347 120 485 353 120 485 minecraft:black_concrete
fill 347 120 489 348 120 490 minecraft:black_concrete
setblock 348 120 486 minecraft:gray_concrete
setblock 348 120 487 minecraft:black_concrete
setblock 348 120 488 minecraft:gray_concrete
fill 349 120 482 351 120 482 minecraft:white_concrete
setblock 349 120 483 minecraft:black_concrete
fill 349 120 484 351 120 484 minecraft:gray_concrete
fill 349 120 489 352 120 489 minecraft:black_concrete
fill 349 120 490 351 120 490 minecraft:gray_concrete
setblock 350 120 463 minecraft:pink_terracotta
fill 350 120 483 350 121 483 minecraft:gray_concrete
fill 351 120 463 353 123 463 minecraft:red_concrete
setblock 351 120 483 minecraft:black_concrete
fill 351 120 491 352 120 491 minecraft:black_concrete
fill 351 120 492 355 120 493 minecraft:white_concrete
setblock 352 120 486 minecraft:gray_concrete
fill 352 120 487 354 120 487 minecraft:black_concrete
setblock 352 120 488 minecraft:gray_concrete
setblock 352 120 490 minecraft:black_concrete
fill 353 120 486 354 121 486 minecraft:black_concrete
fill 353 120 488 354 120 488 minecraft:black_concrete
setblock 354 120 463 minecraft:pink_terracotta
setblock 354 120 485 minecraft:gray_concrete
fill 355 120 463 362 120 463 minecraft:red_concrete
fill 355 120 482 357 120 488 minecraft:white_concrete
fill 356 120 481 359 121 481 minecraft:red_nether_bricks
fill 356 120 489 357 120 492 minecraft:white_concrete
fill 356 120 493 359 121 493 minecraft:red_nether_bricks
fill 358 120 482 360 121 482 minecraft:red_nether_bricks
fill 358 120 483 358 121 491 minecraft:white_concrete
fill 358 120 492 360 121 492 minecraft:red_nether_bricks
setblock 358 120 505 minecraft:pink_terracotta
fill 359 120 483 361 121 483 minecraft:red_nether_bricks
fill 359 120 484 359 121 490 minecraft:white_concrete
fill 359 120 491 361 121 491 minecraft:red_nether_bricks
fill 359 120 505 370 120 505 minecraft:red_concrete
fill 360 120 484 362 121 484 minecraft:red_nether_bricks
fill 360 120 485 360 121 489 minecraft:white_concrete
fill 360 120 490 362 121 490 minecraft:red_nether_bricks
fill 361 120 485 362 121 486 minecraft:red_nether_bricks
fill 361 120 487 361 121 487 minecraft:white_concrete
fill 361 120 488 362 121 489 minecraft:red_nether_bricks
fill 362 120 487 363 121 487 minecraft:red_nether_bricks
setblock 363 120 463 minecraft:pink_terracotta
fill 364 120 463 371 120 463 minecraft:red_concrete
fill 371 120 464 371 120 467 minecraft:red_concrete
setblock 371 120 468 minecraft:pink_terracotta
fill 371 120 469 371 120 481 minecraft:red_concrete
fill 371 120 482 371 120 483 minecraft:pink_terracotta
fill 371 120 484 371 123 491 minecraft:red_concrete
setblock 371 120 492 minecraft:pink_terracotta
fill 371 120 493 371 123 493 minecraft:red_concrete
setblock 371 120 494 minecraft:pink_terracotta
fill 371 120 495 371 121 500 minecraft:red_concrete
setblock 371 120 501 minecraft:pink_terracotta
fill 371 120 502 371 123 504 minecraft:red_concrete
setblock 371 120 505 minecraft:pink_terracotta
setblock 329 121 463 minecraft:pink_terracotta
fill 329 121 464 329 121 465 minecraft:red_concrete
fill 329 121 466 329 122 466 minecraft:pink_terracotta
fill 329 121 467 329 123 469 minecraft:red_concrete
setblock 329 121 470 minecraft:pink_terracotta
fill 329 121 471 329 123 478 minecraft:red_concrete
setblock 329 121 479 minecraft:pink_terracotta
fill 329 121 480 329 123 481 minecraft:red_concrete
setblock 329 121 488 minecraft:red_concrete
fill 329 121 491 329 123 491 minecraft:red_concrete
fill 329 121 494 329 121 496 minecraft:red_concrete
setblock 329 121 497 minecraft:pink_terracotta
fill 329 121 498 329 123 499 minecraft:red_concrete
setblock 329 121 500 minecraft:pink_terracotta
fill 329 121 501 329 123 504 minecraft:red_concrete
setblock 329 121 505 minecraft:pink_terracotta
fill 330 121 463 334 123 463 minecraft:red_concrete
fill 330 121 464 336 121 504 minecraft:red_nether_bricks
fill 330 121 505 331 123 505 minecraft:red_concrete
setblock 332 121 505 minecraft:pink_terracotta
fill 333 121 505 337 123 505 minecraft:red_concrete
setblock 335 121 463 minecraft:pink_terracotta
fill 336 121 463 345 123 463 minecraft:red_concrete
fill 337 121 464 337 121 486 minecraft:red_nether_bricks
fill 337 121 488 337 121 504 minecraft:red_nether_bricks
fill 338 121 464 338 121 483 minecraft:red_nether_bricks
fill 338 121 491 338 121 504 minecraft:red_nether_bricks
setblock 338 121 505 minecraft:pink_terracotta
fill 339 121 464 339 121 482 minecraft:red_nether_bricks
fill 339 121 492 339 121 504 minecraft:red_nether_bricks
fill 339 121 505 344 121 505 minecraft:red_concrete
fill 340 121 464 340 121 481 minecraft:red_nether_bricks
fill 340 121 485 344 121 486 minecraft:white_concrete
fill 340 121 493 340 121 504 minecraft:red_nether_bricks
fill 341 121 464 342 121 480 minecraft:red_nether_bricks
fill 341 121 484 344 121 484 minecraft:white_concrete
fill 341 121 494 344 121 504 minecraft:red_nether_bricks
fill 342 121 483 344 121 483 minecraft:white_concrete
fill 342 121 491 346 121 491 minecraft:white_concrete
fill 343 121 464 344 121 479 minecraft:red_nether_bricks
fill 343 121 482 344 121 482 minecraft:white_concrete
fill 343 121 492 346 121 492 minecraft:white_concrete
fill 345 121 464 370 121 478 minecraft:red_nether_bricks
fill 345 121 481 345 121 485 minecraft:shroomlight
setblock 345 121 486 minecraft:white_concrete
fill 345 121 493 346 121 493 minecraft:white_concrete
fill 345 121 494 346 121 494 minecraft:red_nether_bricks
fill 345 121 496 370 121 504 minecraft:red_nether_bricks
setblock 345 121 505 minecraft:pink_terracotta
fill 346 121 481 349 121 481 minecraft:shroomlight
fill 346 121 482 348 121 484 minecraft:red_nether_bricks
fill 346 121 485 355 121 485 minecraft:shroomlight
fill 346 121 505 351 121 505 minecraft:red_concrete
setblock 347 121 489 minecraft:black_concrete
fill 347 121 490 347 121 494 minecraft:shroomlight
fill 348 121 486 348 121 490 minecraft:shroomlight
fill 348 121 491 350 121 493 minecraft:red_nether_bricks
fill 348 121 494 351 121 494 minecraft:shroomlight
fill 349 121 482 349 121 484 minecraft:shroomlight
fill 349 121 489 352 121 490 minecraft:shroomlight
fill 350 121 463 350 123 463 minecraft:red_concrete
fill 350 121 481 350 121 482 minecraft:white_concrete
setblock 350 121 484 minecraft:gray_concrete
fill 351 121 481 351 121 484 minecraft:shroomlight
fill 351 121 491 351 121 493 minecraft:shroomlight
fill 352 121 481 355 121 481 minecraft:shroomlight
fill 352 121 482 354 121 484 minecraft:red_nether_bricks
fill 352 121 486 352 121 488 minecraft:shroomlight
fill 352 121 491 352 121 492 minecraft:shroomlight
fill 352 121 493 355 121 493 minecraft:white_concrete
fill 352 121 494 370 121 494 minecraft:red_nether_bricks
fill 352 121 505 352 122 505 minecraft:pink_terracotta
fill 353 121 487 354 121 487 minecraft:black_concrete
fill 353 121 488 356 121 488 minecraft:shroomlight
fill 353 121 489 355 121 491 minecraft:red_nether_bricks
fill 353 121 492 356 121 492 minecraft:shroomlight
fill 353 121 505 356 121 505 minecraft:red_concrete
fill 354 121 463 356 121 463 minecraft:red_concrete
fill 355 121 482 355 121 484 minecraft:shroomlight
fill 355 121 486 357 121 487 minecraft:white_concrete
fill 356 121 479 370 121 479 minecraft:red_nether_bricks
fill 356 121 482 357 121 485 minecraft:white_concrete
fill 356 121 489 356 121 491 minecraft:shroomlight
fill 356 121 495 370 121 495 minecraft:red_nether_bricks
fill 357 121 463 357 122 463 minecraft:pink_terracotta
fill 357 121 488 357 121 492 minecraft:white_concrete
setblock 357 121 505 minecraft:pink_terracotta
fill 358 121 463 363 123 463 minecraft:red_concrete
fill 358 121 480 370 121 480 minecraft:red_nether_bricks
fill 358 121 505 366 121 505 minecraft:red_concrete
fill 360 121 481 370 121 481 minecraft:red_nether_bricks
fill 360 121 493 370 121 493 minecraft:red_nether_bricks
fill 361 121 482 370 121 482 minecraft:red_nether_bricks
fill 361 121 492 370 121 492 minecraft:red_nether_bricks
fill 362 121 483 370 121 483 minecraft:red_nether_bricks
fill 362 121 491 370 121 491 minecraft:red_nether_bricks
fill 363 121 484 370 121 486 minecraft:red_nether_bricks
fill 363 121 488 370 121 490 minecraft:red_nether_bricks
fill 364 121 463 365 121 463 minecraft:pink_terracotta
fill 364 121 487 370 121 487 minecraft:red_nether_bricks
fill 366 121 463 370 123 463 minecraft:red_concrete
setblock 367 121 505 minecraft:pink_terracotta
fill 368 121 505 371 123 505 minecraft:red_concrete
setblock 371 121 463 minecraft:pink_terracotta
fill 371 121 464 371 123 464 minecraft:red_concrete
setblock 371 121 465 minecraft:pink_terracotta
fill 371 121 466 371 123 466 minecraft:red_concrete
setblock 371 121 467 minecraft:pink_terracotta
fill 371 121 468 371 121 475 minecraft:red_concrete
setblock 371 121 476 minecraft:pink_terracotta
fill 371 121 477 371 121 483 minecraft:red_concrete
fill 371 121 492 371 123 492 minecraft:red_concrete
fill 371 121 494 371 123 494 minecraft:red_concrete
fill 371 121 501 371 123 501 minecraft:red_concrete
fill 329 122 463 329 123 464 minecraft:red_concrete
setblock 329 122 465 minecraft:pink_terracotta
fill 329 122 470 329 123 470 minecraft:red_concrete
fill 329 122 479 329 123 479 minecraft:red_concrete
setblock 329 122 488 minecraft:pink_terracotta
setblock 329 122 494 minecraft:pink_terracotta
fill 329 122 495 329 123 497 minecraft:red_concrete
fill 329 122 500 329 123 500 minecraft:red_concrete
fill 329 122 505 329 124 505 minecraft:red_concrete
fill 332 122 505 332 123 505 minecraft:red_concrete
fill 335 122 463 335 123 463 minecraft:red_concrete
fill 338 122 505 343 123 505 minecraft:red_concrete
setblock 344 122 505 minecraft:pink_terracotta
fill 345 122 505 347 123 505 minecraft:red_concrete
fill 346 122 463 346 123 463 minecraft:red_concrete
setblock 347 122 463 minecraft:pink_terracotta
fill 348 122 463 349 123 463 minecraft:red_concrete
fill 348 122 505 349 122 505 minecraft:pink_terracotta
fill 350 122 505 351 123 505 minecraft:red_concrete
fill 353 122 505 355 123 505 minecraft:red_concrete
fill 354 122 463 355 123 463 minecraft:red_concrete
setblock 356 122 463 minecraft:pink_terracotta
setblock 356 122 505 minecraft:pink_terracotta
fill 357 122 505 359 123 505 minecraft:red_concrete
setblock 360 122 505 minecraft:pink_terracotta
fill 361 122 505 367 123 505 minecraft:red_concrete
fill 364 122 463 365 123 463 minecraft:red_concrete
fill 371 122 463 371 123 463 minecraft:red_concrete
fill 371 122 465 371 123 465 minecraft:red_concrete
fill 371 122 467 371 123 473 minecraft:red_concrete
setblock 371 122 474 minecraft:pink_terracotta
fill 371 122 475 371 123 481 minecraft:red_concrete
setblock 371 122 482 minecraft:pink_terracotta
fill 371 122 483 371 123 483 minecraft:red_concrete
setblock 371 122 495 minecraft:pink_terracotta
fill 371 122 496 371 123 498 minecraft:red_concrete
setblock 371 122 499 minecraft:pink_terracotta
fill 371 122 500 371 123 500 minecraft:red_concrete
fill 329 123 465 329 123 466 minecraft:red_concrete
setblock 329 123 488 minecraft:red_concrete
setblock 329 123 494 minecraft:red_concrete
setblock 344 123 505 minecraft:red_concrete
setblock 347 123 463 minecraft:red_concrete
fill 348 123 505 349 123 505 minecraft:red_concrete
setblock 352 123 505 minecraft:red_concrete
fill 356 123 463 357 123 463 minecraft:red_concrete
setblock 356 123 505 minecraft:red_concrete
fill 360 123 505 360 124 505 minecraft:red_concrete
setblock 371 123 474 minecraft:red_concrete
fill 371 123 482 371 124 482 minecraft:red_concrete
fill 371 123 495 371 124 495 minecraft:red_concrete
fill 371 123 499 371 124 499 minecraft:red_concrete
fill 329 124 463 329 124 504 minecraft:pink_terracotta
fill 330 124 463 332 215 463 minecraft:pink_terracotta
fill 330 124 505 335 212 505 minecraft:pink_terracotta
setblock 333 124 463 minecraft:red_concrete
fill 334 124 463 357 124 463 minecraft:pink_terracotta
fill 336 124 505 337 124 505 minecraft:red_concrete
fill 338 124 505 342 124 505 minecraft:pink_terracotta
setblock 343 124 505 minecraft:red_concrete
fill 344 124 505 350 125 505 minecraft:pink_terracotta
setblock 351 124 505 minecraft:red_concrete
fill 352 124 505 356 125 505 minecraft:pink_terracotta
fill 357 124 505 358 124 505 minecraft:red_concrete
setblock 358 124 463 minecraft:red_concrete
fill 359 124 463 371 124 463 minecraft:pink_terracotta
fill 359 124 505 359 215 505 minecraft:pink_terracotta
fill 361 124 505 364 124 505 minecraft:pink_terracotta
setblock 365 124 505 minecraft:red_concrete
fill 366 124 505 371 124 505 minecraft:pink_terracotta
fill 371 124 464 371 124 469 minecraft:pink_terracotta
fill 371 124 470 371 124 471 minecraft:red_concrete
fill 371 124 472 371 124 474 minecraft:pink_terracotta
setblock 371 124 475 minecraft:red_concrete
fill 371 124 476 371 215 476 minecraft:pink_terracotta
setblock 371 124 477 minecraft:red_concrete
fill 371 124 478 371 124 481 minecraft:pink_terracotta
fill 371 124 483 371 211 487 minecraft:pink_terracotta
setblock 371 124 488 minecraft:red_concrete
fill 371 124 489 371 125 489 minecraft:pink_terracotta
setblock 371 124 490 minecraft:red_concrete
fill 371 124 491 371 124 494 minecraft:pink_terracotta
fill 371 124 496 371 124 498 minecraft:pink_terracotta
fill 371 124 500 371 212 504 minecraft:pink_terracotta
fill 329 125 463 329 125 471 minecraft:pink_terracotta
fill 329 125 472 329 125 473 minecraft:red_concrete
fill 329 125 474 329 125 486 minecraft:pink_terracotta
setblock 329 125 487 minecraft:red_concrete
fill 329 125 488 329 215 490 minecraft:pink_terracotta
setblock 329 125 491 minecraft:red_concrete
fill 329 125 492 329 215 492 minecraft:pink_terracotta
setblock 329 125 493 minecraft:red_concrete
fill 329 125 494 329 125 502 minecraft:pink_terracotta
setblock 329 125 503 minecraft:red_concrete
fill 329 125 504 329 213 505 minecraft:pink_terracotta
fill 330 125 479 330 125 480 minecraft:pink_terracotta
setblock 330 125 481 minecraft:red_nether_bricks
fill 330 125 482 330 125 485 minecraft:pink_terracotta
setblock 330 125 486 minecraft:red_nether_bricks
fill 330 125 487 330 127 488 minecraft:pink_terracotta
fill 331 125 482 331 125 484 minecraft:pink_terracotta
setblock 332 125 504 minecraft:white_concrete
fill 333 125 463 337 211 463 minecraft:pink_terracotta
fill 334 125 464 336 125 464 minecraft:pink_terracotta
setblock 336 125 465 minecraft:red_nether_bricks
fill 336 125 504 336 125 505 minecraft:pink_terracotta
setblock 337 125 464 minecraft:red_nether_bricks
fill 337 125 465 340 125 465 minecraft:pink_terracotta
setblock 337 125 504 minecraft:red_nether_bricks
fill 337 125 505 337 215 505 minecraft:pink_terracotta
fill 338 125 463 339 125 463 minecraft:red_concrete
fill 338 125 464 341 125 464 minecraft:pink_terracotta
fill 338 125 466 339 125 466 minecraft:pink_terracotta
fill 338 125 504 341 125 504 minecraft:pink_terracotta
fill 338 125 505 339 125 505 minecraft:red_concrete
fill 339 125 503 342 125 503 minecraft:pink_terracotta
fill 340 125 463 343 213 463 minecraft:pink_terracotta
setblock 340 125 466 minecraft:red_nether_bricks
fill 340 125 505 343 125 505 minecraft:pink_terracotta
setblock 341 125 465 minecraft:red_nether_bricks
fill 341 125 466 344 125 466 minecraft:pink_terracotta
setblock 342 125 464 minecraft:red_nether_bricks
fill 342 125 465 345 125 465 minecraft:pink_terracotta
setblock 342 125 504 minecraft:red_nether_bricks
fill 343 125 464 346 125 464 minecraft:pink_terracotta
setblock 343 125 503 minecraft:red_nether_bricks
fill 343 125 504 346 125 504 minecraft:pink_terracotta
setblock 344 125 463 minecraft:red_concrete
fill 344 125 503 346 125 503 minecraft:pink_terracotta
fill 345 125 463 346 215 463 minecraft:pink_terracotta
setblock 346 125 465 minecraft:red_nether_bricks
fill 347 125 463 347 126 463 minecraft:red_concrete
setblock 347 125 464 minecraft:red_nether_bricks
fill 347 125 465 348 127 465 minecraft:pink_terracotta
setblock 347 125 504 minecraft:red_nether_bricks
fill 348 125 463 350 126 464 minecraft:pink_terracotta
fill 348 125 504 351 125 504 minecraft:pink_terracotta
setblock 351 125 463 minecraft:red_concrete
setblock 351 125 464 minecraft:pink_terracotta
fill 351 125 505 351 215 505 minecraft:pink_terracotta
fill 352 125 463 356 211 463 minecraft:pink_terracotta
setblock 352 125 464 minecraft:red_nether_bricks
setblock 352 125 504 minecraft:red_nether_bricks
fill 353 125 464 356 125 464 minecraft:pink_terracotta
setblock 353 125 503 minecraft:red_nether_bricks
fill 353 125 504 356 125 504 minecraft:pink_terracotta
fill 354 125 503 357 125 503 minecraft:pink_terracotta
setblock 355 125 465 minecraft:pink_terracotta
setblock 356 125 465 minecraft:red_nether_bricks
setblock 357 125 463 minecraft:red_concrete
setblock 357 125 464 minecraft:red_nether_bricks
fill 357 125 465 360 125 465 minecraft:pink_terracotta
fill 357 125 502 358 125 502 minecraft:pink_terracotta
setblock 357 125 504 minecraft:red_nether_bricks
fill 357 125 505 358 125 505 minecraft:pink_terracotta
fill 358 125 463 360 126 464 minecraft:pink_terracotta
setblock 358 125 503 minecraft:red_nether_bricks
fill 358 125 504 361 125 504 minecraft:pink_terracotta
setblock 359 125 502 minecraft:red_nether_bricks
fill 359 125 503 362 125 503 minecraft:pink_terracotta
fill 360 125 502 363 125 502 minecraft:pink_terracotta
fill 360 125 505 361 215 505 minecraft:pink_terracotta
setblock 361 125 463 minecraft:red_concrete
setblock 361 125 464 minecraft:pink_terracotta
setblock 361 125 465 minecraft:red_nether_bricks
fill 362 125 463 370 125 463 minecraft:pink_terracotta
setblock 362 125 464 minecraft:red_nether_bricks
fill 362 125 465 363 126 465 minecraft:pink_terracotta
setblock 362 125 504 minecraft:red_nether_bricks
setblock 362 125 505 minecraft:red_concrete
fill 363 125 464 366 125 464 minecraft:pink_terracotta
setblock 363 125 503 minecraft:red_nether_bricks
fill 363 125 504 366 125 505 minecraft:pink_terracotta
setblock 364 125 502 minecraft:red_nether_bricks
fill 364 125 503 366 125 503 minecraft:pink_terracotta
fill 367 125 497 367 132 497 minecraft:iron_block
setblock 367 125 504 minecraft:red_nether_bricks
fill 367 125 505 369 125 505 minecraft:pink_terracotta
setblock 368 125 464 minecraft:white_concrete
fill 368 125 476 368 134 476 minecraft:iron_block
fill 368 125 504 369 125 504 minecraft:pink_terracotta
fill 369 125 484 369 125 486 minecraft:pink_terracotta
setblock 370 125 481 minecraft:red_nether_bricks
fill 370 125 482 370 125 485 minecraft:pink_terracotta
setblock 370 125 486 minecraft:red_nether_bricks
fill 370 125 487 370 126 489 minecraft:pink_terracotta
setblock 370 125 505 minecraft:red_concrete
setblock 371 125 463 minecraft:red_concrete
fill 371 125 464 371 125 467 minecraft:pink_terracotta
setblock 371 125 468 minecraft:red_concrete
fill 371 125 469 371 211 470 minecraft:pink_terracotta
fill 371 125 471 371 125 472 minecraft:red_concrete
fill 371 125 473 371 211 475 minecraft:pink_terracotta
fill 371 125 477 371 211 479 minecraft:pink_terracotta
setblock 371 125 480 minecraft:red_concrete
fill 371 125 481 371 125 482 minecraft:pink_terracotta
fill 371 125 488 371 215 488 minecraft:pink_terracotta
fill 371 125 490 371 215 490 minecraft:pink_terracotta
setblock 371 125 491 minecraft:red_concrete
fill 371 125 492 371 211 496 minecraft:pink_terracotta
setblock 371 125 497 minecraft:red_concrete
fill 371 125 498 371 215 499 minecraft:pink_terracotta
fill 371 125 505 371 211 505 minecraft:pink_terracotta
fill 329 126 463 329 211 468 minecraft:pink_terracotta
setblock 329 126 469 minecraft:red_concrete
fill 329 126 470 329 212 472 minecraft:pink_terracotta
setblock 329 126 473 minecraft:red_concrete
fill 329 126 474 329 211 476 minecraft:pink_terracotta
setblock 329 126 477 minecraft:red_concrete
fill 329 126 478 329 211 487 minecraft:pink_terracotta
fill 329 126 491 329 215 491 minecraft:pink_terracotta
fill 329 126 493 329 215 493 minecraft:pink_terracotta
setblock 329 126 494 minecraft:red_concrete
fill 329 126 495 329 211 500 minecraft:pink_terracotta
setblock 329 126 501 minecraft:red_concrete
fill 329 126 502 329 213 503 minecraft:pink_terracotta
setblock 330 126 468 minecraft:white_concrete
setblock 330 126 480 minecraft:red_nether_bricks
fill 330 126 481 330 126 484 minecraft:pink_terracotta
setblock 330 126 485 minecraft:red_nether_bricks
fill 330 126 486 330 129 486 minecraft:pink_terracotta
setblock 331 126 484 minecraft:red_nether_bricks
fill 333 126 464 335 126 464 minecraft:pink_terracotta
setblock 335 126 465 minecraft:red_nether_bricks
setblock 336 126 464 minecraft:red_nether_bricks
fill 336 126 465 339 126 465 minecraft:pink_terracotta
setblock 336 126 504 minecraft:red_nether_bricks
fill 336 126 505 336 215 505 minecraft:pink_terracotta
fill 337 126 464 340 126 464 minecraft:pink_terracotta
fill 337 126 504 340 126 504 minecraft:pink_terracotta
fill 338 126 463 339 215 463 minecraft:pink_terracotta
setblock 338 126 466 minecraft:pink_terracotta
fill 338 126 505 341 212 505 minecraft:pink_terracotta
setblock 339 126 466 minecraft:red_nether_bricks
fill 339 126 503 341 126 503 minecraft:pink_terracotta
setblock 340 126 465 minecraft:red_nether_bricks
fill 340 126 466 343 126 466 minecraft:pink_terracotta
setblock 341 126 464 minecraft:red_nether_bricks
fill 341 126 465 344 126 465 minecraft:pink_terracotta
setblock 341 126 504 minecraft:red_nether_bricks
fill 342 126 464 345 126 464 minecraft:pink_terracotta
setblock 342 126 503 minecraft:red_nether_bricks
fill 342 126 504 345 126 504 minecraft:pink_terracotta
setblock 342 126 505 minecraft:red_concrete
fill 343 126 503 344 126 503 minecraft:pink_terracotta
fill 343 126 505 344 215 505 minecraft:pink_terracotta
fill 344 126 463 344 215 463 minecraft:pink_terracotta
setblock 344 126 466 minecraft:red_nether_bricks
setblock 345 126 465 minecraft:red_nether_bricks
setblock 345 126 505 minecraft:red_concrete
setblock 346 126 464 minecraft:red_nether_bricks
fill 346 126 465 346 129 465 minecraft:pink_terracotta
setblock 346 126 504 minecraft:red_nether_bricks
fill 346 126 505 350 213 505 minecraft:pink_terracotta
fill 347 126 464 347 129 464 minecraft:pink_terracotta
fill 347 126 504 350 126 504 minecraft:pink_terracotta
fill 351 126 463 351 215 463 minecraft:pink_terracotta
setblock 351 126 464 minecraft:red_nether_bricks
setblock 351 126 504 minecraft:red_nether_bricks
fill 352 126 464 355 126 464 minecraft:pink_terracotta
fill 352 126 504 355 126 505 minecraft:pink_terracotta
setblock 354 126 465 minecraft:pink_terracotta
fill 354 126 503 356 126 503 minecraft:pink_terracotta
setblock 355 126 465 minecraft:red_nether_bricks
setblock 356 126 464 minecraft:red_nether_bricks
fill 356 126 465 359 126 465 minecraft:pink_terracotta
setblock 356 126 504 minecraft:red_nether_bricks
setblock 356 126 505 minecraft:red_concrete
fill 357 126 463 357 129 464 minecraft:pink_terracotta
setblock 357 126 502 minecraft:pink_terracotta
setblock 357 126 503 minecraft:red_nether_bricks
fill 357 126 504 357 129 505 minecraft:pink_terracotta
setblock 358 126 502 minecraft:red_nether_bricks
fill 358 126 503 360 126 504 minecraft:pink_terracotta
setblock 358 126 505 minecraft:red_concrete
fill 359 126 502 362 126 502 minecraft:pink_terracotta
setblock 360 126 465 minecraft:red_nether_bricks
fill 361 126 463 364 211 463 minecraft:pink_terracotta
setblock 361 126 464 minecraft:red_nether_bricks
fill 361 126 465 361 129 465 minecraft:pink_terracotta
setblock 361 126 503 minecraft:pink_terracotta
setblock 361 126 504 minecraft:red_nether_bricks
fill 362 126 464 365 126 464 minecraft:pink_terracotta
setblock 362 126 503 minecraft:red_nether_bricks
fill 362 126 504 362 129 505 minecraft:pink_terracotta
fill 363 126 503 365 126 504 minecraft:pink_terracotta
setblock 363 126 505 minecraft:red_concrete
fill 364 126 505 368 213 505 minecraft:pink_terracotta
setblock 365 126 463 minecraft:red_concrete
fill 366 126 463 371 211 463 minecraft:pink_terracotta
setblock 366 126 464 minecraft:red_nether_bricks
setblock 366 126 504 minecraft:red_nether_bricks
fill 367 126 504 367 127 504 minecraft:pink_terracotta
setblock 369 126 485 minecraft:pink_terracotta
setblock 369 126 486 minecraft:red_nether_bricks
setblock 369 126 505 minecraft:red_concrete
setblock 370 126 475 minecraft:white_concrete
fill 370 126 481 370 126 484 minecraft:pink_terracotta
setblock 370 126 485 minecraft:red_nether_bricks
fill 370 126 486 370 129 486 minecraft:pink_terracotta
setblock 370 126 490 minecraft:red_nether_bricks
setblock 370 126 500 minecraft:white_concrete
fill 370 126 505 370 215 505 minecraft:pink_terracotta
fill 371 126 464 371 215 466 minecraft:pink_terracotta
setblock 371 126 467 minecraft:red_concrete
fill 371 126 468 371 215 468 minecraft:pink_terracotta
fill 371 126 471 371 215 471 minecraft:pink_terracotta
setblock 371 126 472 minecraft:red_concrete
fill 371 126 480 371 215 480 minecraft:pink_terracotta
setblock 371 126 481 minecraft:red_concrete
fill 371 126 482 371 215 482 minecraft:pink_terracotta
setblock 371 126 489 minecraft:red_concrete
fill 371 126 491 371 215 491 minecraft:pink_terracotta
fill 371 126 497 371 215 497 minecraft:pink_terracotta
fill 329 127 469 329 215 469 minecraft:pink_terracotta
fill 329 127 473 329 211 473 minecraft:pink_terracotta
fill 329 127 477 329 215 477 minecraft:pink_terracotta
fill 329 127 494 329 212 494 minecraft:pink_terracotta
fill 329 127 501 329 215 501 minecraft:pink_terracotta
setblock 330 127 474 minecraft:white_concrete
fill 330 127 480 330 127 483 minecraft:pink_terracotta
setblock 330 127 484 minecraft:red_nether_bricks
fill 330 127 485 330 130 485 minecraft:pink_terracotta
setblock 330 127 493 minecraft:white_concrete
fill 330 127 499 330 128 499 minecraft:white_concrete
setblock 331 127 464 minecraft:white_concrete
fill 331 127 484 331 130 484 minecraft:pink_terracotta
fill 332 127 464 334 127 464 minecraft:pink_terracotta
setblock 334 127 465 minecraft:red_nether_bricks
setblock 335 127 464 minecraft:red_nether_bricks
fill 335 127 465 338 127 465 minecraft:pink_terracotta
setblock 335 127 504 minecraft:red_nether_bricks
fill 336 127 464 339 127 464 minecraft:pink_terracotta
fill 336 127 466 337 127 466 minecraft:pink_terracotta
fill 336 127 504 339 127 504 minecraft:pink_terracotta
setblock 338 127 466 minecraft:red_nether_bricks
setblock 339 127 465 minecraft:red_nether_bricks
fill 339 127 466 342 127 466 minecraft:pink_terracotta
fill 339 127 503 340 127 503 minecraft:pink_terracotta
setblock 340 127 464 minecraft:red_nether_bricks
fill 340 127 465 343 127 465 minecraft:pink_terracotta
setblock 340 127 504 minecraft:red_nether_bricks
fill 341 127 464 344 127 464 minecraft:pink_terracotta
setblock 341 127 503 minecraft:red_nether_bricks
fill 341 127 504 344 127 504 minecraft:pink_terracotta
fill 342 127 503 343 127 503 minecraft:pink_terracotta
fill 342 127 505 342 211 505 minecraft:pink_terracotta
setblock 343 127 466 minecraft:red_nether_bricks
setblock 344 127 465 minecraft:red_nether_bricks
fill 344 127 466 344 130 466 minecraft:pink_terracotta
setblock 345 127 464 minecraft:red_nether_bricks
fill 345 127 465 345 130 465 minecraft:pink_terracotta
setblock 345 127 504 minecraft:red_nether_bricks
fill 345 127 505 345 215 505 minecraft:pink_terracotta
fill 346 127 464 346 130 464 minecraft:pink_terracotta
fill 346 127 504 349 127 504 minecraft:pink_terracotta
fill 347 127 463 350 211 463 minecraft:pink_terracotta
fill 348 127 464 349 127 464 minecraft:pink_terracotta
setblock 350 127 464 minecraft:red_nether_bricks
setblock 350 127 504 minecraft:red_nether_bricks
fill 351 127 464 354 127 464 minecraft:pink_terracotta
fill 351 127 504 354 127 504 minecraft:pink_terracotta
fill 352 127 505 356 211 505 minecraft:pink_terracotta
setblock 353 127 465 minecraft:pink_terracotta
fill 353 127 503 355 127 503 minecraft:pink_terracotta
setblock 354 127 465 minecraft:red_nether_bricks
setblock 355 127 464 minecraft:red_nether_bricks
fill 355 127 465 358 127 465 minecraft:pink_terracotta
setblock 355 127 504 minecraft:red_nether_bricks
fill 356 127 464 356 130 464 minecraft:pink_terracotta
setblock 356 127 503 minecraft:red_nether_bricks
fill 356 127 504 356 130 504 minecraft:pink_terracotta
setblock 357 127 502 minecraft:red_nether_bricks
fill 357 127 503 360 127 503 minecraft:pink_terracotta
fill 358 127 463 359 127 464 minecraft:pink_terracotta
fill 358 127 502 361 127 502 minecraft:pink_terracotta
fill 358 127 504 358 128 505 minecraft:pink_terracotta
setblock 359 127 465 minecraft:red_nether_bricks
setblock 359 127 504 minecraft:pink_terracotta
fill 360 127 463 360 215 463 minecraft:pink_terracotta
setblock 360 127 464 minecraft:red_nether_bricks
fill 360 127 465 360 130 465 minecraft:pink_terracotta
setblock 360 127 504 minecraft:red_nether_bricks
fill 361 127 464 364 127 464 minecraft:pink_terracotta
setblock 361 127 503 minecraft:red_nether_bricks
fill 361 127 504 361 130 504 minecraft:pink_terracotta
fill 362 127 465 362 128 465 minecraft:pink_terracotta
fill 362 127 503 364 127 503 minecraft:pink_terracotta
fill 363 127 504 363 128 505 minecraft:pink_terracotta
setblock 364 127 504 minecraft:pink_terracotta
fill 365 127 463 365 215 463 minecraft:pink_terracotta
setblock 365 127 464 minecraft:red_nether_bricks
setblock 365 127 504 minecraft:red_nether_bricks
fill 366 127 504 366 128 504 minecraft:pink_terracotta
setblock 369 127 485 minecraft:red_nether_bricks
fill 369 127 486 369 129 487 minecraft:pink_terracotta
setblock 369 127 504 minecraft:white_concrete
fill 369 127 505 369 215 505 minecraft:pink_terracotta
setblock 370 127 469 minecraft:white_concrete
fill 370 127 481 370 127 483 minecraft:pink_terracotta
setblock 370 127 484 minecraft:red_nether_bricks
fill 370 127 485 370 130 485 minecraft:pink_terracotta
fill 370 127 487 370 127 488 minecraft:pink_terracotta
setblock 370 127 489 minecraft:red_nether_bricks
fill 370 127 490 370 130 490 minecraft:pink_terracotta
setblock 370 127 494 minecraft:white_concrete
fill 371 127 467 371 215 467 minecraft:pink_terracotta
fill 371 127 472 371 212 472 minecraft:pink_terracotta
fill 371 127 481 371 215 481 minecraft:pink_terracotta
fill 371 127 489 371 215 489 minecraft:pink_terracotta
fill 330 128 466 330 129 466 minecraft:pink_terracotta
fill 330 128 480 330 128 482 minecraft:pink_terracotta
setblock 330 128 483 minecraft:red_nether_bricks
fill 330 128 484 330 131 484 minecraft:pink_terracotta
setblock 330 128 487 minecraft:pink_terracotta
setblock 330 128 488 minecraft:red_nether_bricks
fill 330 128 489 330 131 489 minecraft:pink_terracotta
fill 331 128 464 333 128 464 minecraft:pink_terracotta
fill 331 128 485 331 128 486 minecraft:pink_terracotta
setblock 331 128 504 minecraft:white_concrete
setblock 333 128 465 minecraft:red_nether_bricks
setblock 334 128 464 minecraft:red_nether_bricks
fill 334 128 465 337 128 465 minecraft:pink_terracotta
fill 335 128 464 338 128 464 minecraft:pink_terracotta
fill 335 128 466 336 128 466 minecraft:pink_terracotta
fill 335 128 504 338 128 504 minecraft:pink_terracotta
setblock 337 128 466 minecraft:red_nether_bricks
setblock 338 128 465 minecraft:red_nether_bricks
fill 338 128 466 340 128 467 minecraft:pink_terracotta
setblock 339 128 464 minecraft:red_nether_bricks
fill 339 128 465 342 128 465 minecraft:pink_terracotta
setblock 339 128 503 minecraft:pink_terracotta
setblock 339 128 504 minecraft:red_nether_bricks
fill 340 128 464 343 128 464 minecraft:pink_terracotta
setblock 340 128 503 minecraft:red_nether_bricks
fill 340 128 504 343 128 504 minecraft:pink_terracotta
setblock 341 128 466 minecraft:pink_terracotta
setblock 341 128 467 minecraft:red_nether_bricks
fill 341 128 503 342 128 503 minecraft:pink_terracotta
setblock 342 128 466 minecraft:red_nether_bricks
setblock 343 128 465 minecraft:red_nether_bricks
fill 343 128 466 343 131 466 minecraft:pink_terracotta
setblock 344 128 464 minecraft:red_nether_bricks
fill 344 128 465 344 131 465 minecraft:pink_terracotta
setblock 344 128 504 minecraft:red_nether_bricks
fill 345 128 464 345 131 464 minecraft:pink_terracotta
fill 345 128 504 348 128 504 minecraft:pink_terracotta
setblock 347 128 465 minecraft:pink_terracotta
setblock 348 128 464 minecraft:pink_terracotta
setblock 348 128 465 minecraft:red_nether_bricks
setblock 349 128 464 minecraft:red_nether_bricks
fill 349 128 465 352 128 465 minecraft:pink_terracotta
setblock 349 128 504 minecraft:red_nether_bricks
fill 350 128 464 353 128 464 minecraft:pink_terracotta
fill 350 128 504 353 128 504 minecraft:pink_terracotta
setblock 353 128 465 minecraft:red_nether_bricks
fill 353 128 503 354 128 503 minecraft:pink_terracotta
setblock 354 128 464 minecraft:red_nether_bricks
fill 354 128 465 357 128 465 minecraft:pink_terracotta
setblock 354 128 504 minecraft:red_nether_bricks
fill 355 128 464 355 131 464 minecraft:pink_terracotta
setblock 355 128 503 minecraft:red_nether_bricks
fill 355 128 504 355 131 504 minecraft:pink_terracotta
fill 356 128 503 359 128 503 minecraft:pink_terracotta
fill 357 128 502 360 128 502 minecraft:pink_terracotta
fill 358 128 463 358 128 464 minecraft:pink_terracotta
setblock 358 128 465 minecraft:red_nether_bricks
fill 359 128 463 359 215 463 minecraft:pink_terracotta
setblock 359 128 464 minecraft:red_nether_bricks
fill 359 128 465 359 131 465 minecraft:pink_terracotta
setblock 359 128 504 minecraft:red_nether_bricks
fill 360 128 464 363 128 464 minecraft:pink_terracotta
setblock 360 128 503 minecraft:red_nether_bricks
fill 360 128 504 360 131 504 minecraft:pink_terracotta
fill 361 128 503 363 129 503 minecraft:pink_terracotta
setblock 364 128 464 minecraft:red_nether_bricks
setblock 364 128 504 minecraft:red_nether_bricks
fill 365 128 464 365 130 464 minecraft:pink_terracotta
fill 365 128 504 365 130 504 minecraft:pink_terracotta
setblock 369 128 464 minecraft:white_concrete
fill 369 128 485 369 131 485 minecraft:pink_terracotta
setblock 369 128 488 minecraft:pink_terracotta
fill 370 128 481 370 128 482 minecraft:pink_terracotta
setblock 370 128 483 minecraft:red_nether_bricks
fill 370 128 484 370 131 484 minecraft:pink_terracotta
setblock 370 128 487 minecraft:pink_terracotta
setblock 370 128 488 minecraft:red_nether_bricks
fill 370 128 489 370 131 489 minecraft:pink_terracotta
fill 370 128 491 370 129 491 minecraft:pink_terracotta
fill 330 129 464 330 130 465 minecraft:pink_terracotta
setblock 330 129 467 minecraft:red_nether_bricks
fill 330 129 468 330 130 470 minecraft:pink_terracotta
fill 330 129 480 330 129 481 minecraft:pink_terracotta
setblock 330 129 482 minecraft:red_nether_bricks
fill 330 129 483 331 131 483 minecraft:pink_terracotta
setblock 330 129 487 minecraft:red_nether_bricks
fill 330 129 488 330 132 488 minecraft:pink_terracotta
fill 330 129 490 330 130 490 minecraft:pink_terracotta
fill 331 129 464 332 129 464 minecraft:pink_terracotta
setblock 331 129 485 minecraft:pink_terracotta
setblock 331 129 486 minecraft:red_nether_bricks
fill 331 129 487 331 132 487 minecraft:pink_terracotta
setblock 332 129 465 minecraft:red_nether_bricks
setblock 332 129 466 minecraft:light[level=12]
setblock 332 129 474 minecraft:light[level=12]
setblock 332 129 482 minecraft:light[level=12]
setblock 332 129 490 minecraft:light[level=12]
setblock 332 129 498 minecraft:light[level=12]
setblock 333 129 464 minecraft:red_nether_bricks
fill 333 129 465 336 129 465 minecraft:pink_terracotta
fill 334 129 464 337 129 464 minecraft:pink_terracotta
fill 334 129 466 335 129 466 minecraft:pink_terracotta
fill 334 129 504 337 129 504 minecraft:pink_terracotta
setblock 336 129 466 minecraft:red_nether_bricks
fill 336 129 467 339 129 467 minecraft:pink_terracotta
setblock 337 129 465 minecraft:red_nether_bricks
fill 337 129 466 340 129 466 minecraft:pink_terracotta
setblock 338 129 464 minecraft:red_nether_bricks
fill 338 129 465 341 129 465 minecraft:pink_terracotta
setblock 338 129 503 minecraft:pink_terracotta
setblock 338 129 504 minecraft:red_nether_bricks
fill 339 129 464 342 129 464 minecraft:pink_terracotta
setblock 339 129 503 minecraft:red_nether_bricks
fill 339 129 504 342 129 504 minecraft:pink_terracotta
setblock 340 129 467 minecraft:red_nether_bricks
setblock 340 129 474 minecraft:light[level=12]
setblock 340 129 482 minecraft:light[level=12]
setblock 340 129 490 minecraft:light[level=12]
setblock 340 129 498 minecraft:light[level=12]
fill 340 129 503 341 131 503 minecraft:pink_terracotta
setblock 341 129 466 minecraft:red_nether_bricks
fill 341 129 467 341 132 467 minecraft:pink_terracotta
setblock 342 129 465 minecraft:red_nether_bricks
fill 342 129 466 342 132 466 minecraft:pink_terracotta
setblock 343 129 464 minecraft:red_nether_bricks
fill 343 129 465 343 132 465 minecraft:pink_terracotta
setblock 343 129 504 minecraft:red_nether_bricks
fill 344 129 464 344 132 464 minecraft:pink_terracotta
fill 344 129 504 347 129 504 minecraft:pink_terracotta
setblock 345 129 466 minecraft:pink_terracotta
setblock 347 129 465 minecraft:red_nether_bricks
setblock 348 129 464 minecraft:red_nether_bricks
fill 348 129 465 351 129 465 minecraft:pink_terracotta
setblock 348 129 466 minecraft:light[level=12]
setblock 348 129 474 minecraft:light[level=12]
setblock 348 129 482 minecraft:light[level=12]
setblock 348 129 490 minecraft:light[level=12]
setblock 348 129 498 minecraft:light[level=12]
setblock 348 129 504 minecraft:red_nether_bricks
fill 349 129 464 352 129 464 minecraft:pink_terracotta
fill 349 129 504 352 129 504 minecraft:pink_terracotta
setblock 352 129 465 minecraft:red_nether_bricks
setblock 353 129 464 minecraft:red_nether_bricks
fill 353 129 465 356 129 465 minecraft:pink_terracotta
setblock 353 129 503 minecraft:pink_terracotta
setblock 353 129 504 minecraft:red_nether_bricks
fill 354 129 464 354 132 464 minecraft:pink_terracotta
setblock 354 129 503 minecraft:red_nether_bricks
fill 354 129 504 354 132 504 minecraft:pink_terracotta
fill 355 129 503 358 129 503 minecraft:pink_terracotta
setblock 356 129 466 minecraft:red_nether_bricks
setblock 356 129 474 minecraft:light[level=12]
setblock 356 129 482 minecraft:light[level=12]
setblock 356 129 490 minecraft:light[level=12]
setblock 356 129 498 minecraft:light[level=12]
setblock 357 129 465 minecraft:red_nether_bricks
fill 357 129 466 358 131 466 minecraft:pink_terracotta
fill 357 129 502 359 129 502 minecraft:pink_terracotta
fill 358 129 463 358 215 463 minecraft:pink_terracotta
setblock 358 129 464 minecraft:red_nether_bricks
fill 358 129 465 358 132 465 minecraft:pink_terracotta
setblock 358 129 504 minecraft:red_nether_bricks
fill 358 129 505 358 215 505 minecraft:pink_terracotta
fill 359 129 464 362 129 464 minecraft:pink_terracotta
setblock 359 129 503 minecraft:red_nether_bricks
fill 359 129 504 359 132 504 minecraft:pink_terracotta
fill 360 129 503 360 132 503 minecraft:pink_terracotta
setblock 362 129 465 minecraft:red_nether_bricks
setblock 363 129 464 minecraft:red_nether_bricks
setblock 363 129 504 minecraft:red_nether_bricks
fill 363 129 505 363 215 505 minecraft:pink_terracotta
fill 364 129 464 364 132 464 minecraft:pink_terracotta
setblock 364 129 466 minecraft:light[level=12]
setblock 364 129 474 minecraft:light[level=12]
setblock 364 129 482 minecraft:light[level=12]
setblock 364 129 490 minecraft:light[level=12]
setblock 364 129 498 minecraft:light[level=12]
fill 364 129 504 364 131 504 minecraft:pink_terracotta
fill 369 129 484 369 132 484 minecraft:pink_terracotta
setblock 369 129 488 minecraft:red_nether_bricks
fill 369 129 489 369 131 490 minecraft:pink_terracotta
setblock 370 129 481 minecraft:pink_terracotta
setblock 370 129 482 minecraft:red_nether_bricks
fill 370 129 483 370 132 483 minecraft:pink_terracotta
setblock 370 129 487 minecraft:red_nether_bricks
fill 370 129 488 370 132 488 minecraft:pink_terracotta
setblock 370 129 492 minecraft:red_nether_bricks
setblock 370 129 501 minecraft:white_concrete
setblock 330 130 466 minecraft:red_nether_bricks
fill 330 130 467 331 132 467 minecraft:pink_terracotta
setblock 330 130 471 minecraft:red_nether_bricks
fill 330 130 472 330 131 474 minecraft:pink_terracotta
fill 330 130 479 330 130 480 minecraft:pink_terracotta
setblock 330 130 481 minecraft:red_nether_bricks
fill 330 130 482 330 133 482 minecraft:pink_terracotta
setblock 330 130 486 minecraft:red_nether_bricks
fill 330 130 487 330 133 487 minecraft:pink_terracotta
setblock 330 130 491 minecraft:red_nether_bricks
setblock 330 130 492 minecraft:white_concrete
setblock 331 130 464 minecraft:pink_terracotta
setblock 331 130 465 minecraft:red_nether_bricks
fill 331 130 466 331 133 466 minecraft:pink_terracotta
fill 331 130 468 331 130 469 minecraft:pink_terracotta
setblock 331 130 470 minecraft:red_nether_bricks
setblock 331 130 485 minecraft:red_nether_bricks
fill 331 130 486 331 133 486 minecraft:pink_terracotta
fill 331 130 488 331 130 489 minecraft:pink_terracotta
setblock 332 130 464 minecraft:red_nether_bricks
fill 332 130 465 335 130 465 minecraft:pink_terracotta
fill 333 130 464 336 130 464 minecraft:pink_terracotta
fill 333 130 466 334 130 466 minecraft:pink_terracotta
fill 334 130 504 336 130 504 minecraft:pink_terracotta
setblock 335 130 466 minecraft:red_nether_bricks
fill 335 130 467 338 130 467 minecraft:pink_terracotta
setblock 336 130 465 minecraft:red_nether_bricks
fill 336 130 466 339 130 466 minecraft:pink_terracotta
setblock 337 130 464 minecraft:red_nether_bricks
fill 337 130 465 340 130 465 minecraft:pink_terracotta
setblock 337 130 504 minecraft:red_nether_bricks
fill 338 130 464 341 130 464 minecraft:pink_terracotta
fill 338 130 468 339 130 468 minecraft:red_nether_bricks
setblock 338 130 503 minecraft:red_nether_bricks
fill 338 130 504 341 130 504 minecraft:pink_terracotta
setblock 339 130 467 minecraft:red_nether_bricks
fill 339 130 503 339 133 503 minecraft:pink_terracotta
setblock 340 130 466 minecraft:red_nether_bricks
fill 340 130 467 340 133 467 minecraft:pink_terracotta
setblock 341 130 465 minecraft:red_nether_bricks
fill 341 130 466 341 133 466 minecraft:pink_terracotta
setblock 342 130 464 minecraft:red_nether_bricks
fill 342 130 465 342 133 465 minecraft:pink_terracotta
fill 342 130 467 342 131 467 minecraft:pink_terracotta
setblock 342 130 504 minecraft:red_nether_bricks
fill 343 130 464 343 133 464 minecraft:pink_terracotta
fill 343 130 504 346 130 504 minecraft:pink_terracotta
setblock 345 130 466 minecraft:red_nether_bricks
setblock 346 130 465 minecraft:red_nether_bricks
setblock 347 130 464 minecraft:red_nether_bricks
fill 347 130 465 350 130 465 minecraft:pink_terracotta
setblock 347 130 504 minecraft:red_nether_bricks
fill 348 130 464 351 130 464 minecraft:pink_terracotta
fill 348 130 504 351 130 504 minecraft:pink_terracotta
setblock 351 130 465 minecraft:red_nether_bricks
setblock 352 130 464 minecraft:red_nether_bricks
fill 352 130 465 355 130 465 minecraft:pink_terracotta
setblock 352 130 503 minecraft:pink_terracotta
setblock 352 130 504 minecraft:red_nether_bricks
fill 353 130 464 353 133 464 minecraft:pink_terracotta
setblock 353 130 503 minecraft:red_nether_bricks
fill 353 130 504 353 133 504 minecraft:pink_terracotta
setblock 354 130 466 minecraft:pink_terracotta
fill 354 130 503 357 130 503 minecraft:pink_terracotta
setblock 355 130 466 minecraft:red_nether_bricks
setblock 356 130 465 minecraft:red_nether_bricks
fill 356 130 466 356 133 466 minecraft:pink_terracotta
fill 356 130 502 358 130 502 minecraft:pink_terracotta
fill 357 130 463 357 215 463 minecraft:pink_terracotta
setblock 357 130 464 minecraft:red_nether_bricks
fill 357 130 465 357 133 465 minecraft:pink_terracotta
setblock 357 130 504 minecraft:red_nether_bricks
fill 357 130 505 357 215 505 minecraft:pink_terracotta
fill 358 130 464 361 130 464 minecraft:pink_terracotta
setblock 358 130 503 minecraft:red_nether_bricks
fill 358 130 504 358 133 504 minecraft:pink_terracotta
setblock 359 130 466 minecraft:pink_terracotta
setblock 359 130 502 minecraft:red_nether_bricks
fill 359 130 503 359 133 503 minecraft:pink_terracotta
setblock 361 130 465 minecraft:red_nether_bricks
fill 361 130 503 362 130 503 minecraft:pink_terracotta
setblock 362 130 464 minecraft:red_nether_bricks
fill 362 130 465 362 131 465 minecraft:pink_terracotta
setblock 362 130 504 minecraft:red_nether_bricks
fill 362 130 505 362 215 505 minecraft:pink_terracotta
fill 363 130 464 363 133 464 minecraft:pink_terracotta
fill 363 130 504 363 132 504 minecraft:pink_terracotta
fill 367 130 485 368 133 485 minecraft:white_concrete
fill 368 130 484 368 133 484 minecraft:white_concrete
fill 368 130 486 368 133 486 minecraft:white_concrete
fill 369 130 483 369 133 483 minecraft:white_concrete
setblock 369 130 486 minecraft:pink_terracotta
setblock 369 130 487 minecraft:red_nether_bricks
fill 369 130 488 369 133 488 minecraft:pink_terracotta
setblock 369 130 491 minecraft:pink_terracotta
setblock 370 130 476 minecraft:white_concrete
setblock 370 130 481 minecraft:red_nether_bricks
fill 370 130 482 370 133 482 minecraft:pink_terracotta
setblock 370 130 486 minecraft:red_nether_bricks
fill 370 130 487 370 133 487 minecraft:pink_terracotta
setblock 370 130 491 minecraft:red_nether_bricks
fill 370 130 492 370 132 493 minecraft:pink_terracotta
setblock 370 130 495 minecraft:white_concrete
setblock 330 131 464 minecraft:pink_terracotta
setblock 330 131 465 minecraft:red_nether_bricks
fill 330 131 466 330 134 466 minecraft:pink_terracotta
fill 330 131 468 330 131 469 minecraft:pink_terracotta
setblock 330 131 470 minecraft:red_nether_bricks
fill 330 131 471 332 132 471 minecraft:pink_terracotta
setblock 330 131 475 minecraft:red_nether_bricks
fill 330 131 476 330 131 479 minecraft:pink_terracotta
setblock 330 131 480 minecraft:red_nether_bricks
fill 330 131 481 330 134 481 minecraft:pink_terracotta
setblock 330 131 485 minecraft:red_nether_bricks
fill 330 131 486 330 134 486 minecraft:pink_terracotta
setblock 330 131 490 minecraft:red_nether_bricks
fill 330 131 491 330 133 492 minecraft:pink_terracotta
setblock 330 131 498 minecraft:white_concrete
setblock 331 131 464 minecraft:red_nether_bricks
fill 331 131 465 334 131 465 minecraft:pink_terracotta
setblock 331 131 468 minecraft:pink_terracotta
setblock 331 131 469 minecraft:red_nether_bricks
fill 331 131 470 332 133 470 minecraft:pink_terracotta
fill 331 131 472 331 131 473 minecraft:pink_terracotta
setblock 331 131 484 minecraft:red_nether_bricks
fill 331 131 485 331 134 485 minecraft:pink_terracotta
setblock 331 131 488 minecraft:pink_terracotta
setblock 331 131 489 minecraft:red_nether_bricks
fill 331 131 490 331 134 490 minecraft:pink_terracotta
fill 332 131 464 335 131 464 minecraft:pink_terracotta
fill 332 131 466 332 131 467 minecraft:pink_terracotta
setblock 332 131 468 minecraft:red_nether_bricks
fill 332 131 469 332 134 469 minecraft:pink_terracotta
setblock 333 131 466 minecraft:pink_terracotta
fill 333 131 504 335 131 504 minecraft:pink_terracotta
setblock 334 131 466 minecraft:red_nether_bricks
fill 334 131 467 337 131 467 minecraft:pink_terracotta
setblock 335 131 465 minecraft:red_nether_bricks
fill 335 131 466 338 131 466 minecraft:pink_terracotta
setblock 336 131 464 minecraft:red_nether_bricks
fill 336 131 465 339 131 465 minecraft:pink_terracotta
setblock 336 131 504 minecraft:red_nether_bricks
fill 337 131 464 340 131 464 minecraft:pink_terracotta
setblock 337 131 468 minecraft:red_nether_bricks
setblock 337 131 503 minecraft:red_nether_bricks
fill 337 131 504 340 131 504 minecraft:pink_terracotta
setblock 338 131 467 minecraft:red_nether_bricks
fill 338 131 468 338 134 468 minecraft:pink_terracotta
fill 338 131 503 338 133 503 minecraft:pink_terracotta
setblock 339 131 466 minecraft:red_nether_bricks
fill 339 131 467 339 134 467 minecraft:pink_terracotta
setblock 339 131 468 minecraft:red_nether_bricks
setblock 340 131 465 minecraft:red_nether_bricks
fill 340 131 466 340 134 466 minecraft:pink_terracotta
setblock 341 131 464 minecraft:red_nether_bricks
fill 341 131 465 341 134 465 minecraft:pink_terracotta
setblock 341 131 504 minecraft:red_nether_bricks
fill 342 131 464 342 134 464 minecraft:pink_terracotta
fill 342 131 504 345 131 504 minecraft:pink_terracotta
setblock 344 131 466 minecraft:red_nether_bricks
setblock 345 131 465 minecraft:red_nether_bricks
fill 345 131 466 345 132 466 minecraft:pink_terracotta
setblock 346 131 464 minecraft:red_nether_bricks
fill 346 131 465 349 131 465 minecraft:pink_terracotta
setblock 346 131 504 minecraft:red_nether_bricks
fill 347 131 464 350 131 464 minecraft:pink_terracotta
fill 347 131 504 350 131 504 minecraft:pink_terracotta
setblock 350 131 465 minecraft:red_nether_bricks
setblock 351 131 464 minecraft:red_nether_bricks
fill 351 131 465 354 131 465 minecraft:pink_terracotta
setblock 351 131 503 minecraft:pink_terracotta
setblock 351 131 504 minecraft:red_nether_bricks
fill 352 131 464 352 134 464 minecraft:pink_terracotta
fill 352 131 502 352 138 502 minecraft:iron_block
setblock 352 131 503 minecraft:red_nether_bricks
fill 352 131 504 352 134 504 minecraft:pink_terracotta
setblock 353 131 466 minecraft:pink_terracotta
fill 353 131 503 356 131 503 minecraft:pink_terracotta
setblock 354 131 466 minecraft:red_nether_bricks
setblock 355 131 465 minecraft:red_nether_bricks
fill 355 131 466 355 134 466 minecraft:pink_terracotta
fill 355 131 502 357 131 502 minecraft:pink_terracotta
setblock 356 131 464 minecraft:red_nether_bricks
fill 356 131 465 356 134 465 minecraft:pink_terracotta
setblock 356 131 504 minecraft:red_nether_bricks
fill 357 131 464 360 131 464 minecraft:pink_terracotta
setblock 357 131 503 minecraft:red_nether_bricks
fill 357 131 504 357 134 504 minecraft:pink_terracotta
setblock 358 131 502 minecraft:red_nether_bricks
fill 358 131 503 358 134 503 minecraft:pink_terracotta
setblock 359 131 466 minecraft:red_nether_bricks
setblock 360 131 465 minecraft:red_nether_bricks
setblock 361 131 464 minecraft:red_nether_bricks
fill 361 131 465 361 133 465 minecraft:pink_terracotta
setblock 361 131 503 minecraft:pink_terracotta
setblock 361 131 504 minecraft:red_nether_bricks
fill 362 131 464 362 134 464 minecraft:pink_terracotta
setblock 362 131 503 minecraft:red_nether_bricks
fill 362 131 504 362 133 504 minecraft:pink_terracotta
fill 367 131 484 367 132 484 minecraft:white_concrete
fill 367 131 486 367 132 486 minecraft:white_concrete
fill 368 131 483 368 132 483 minecraft:white_concrete
setblock 368 131 487 minecraft:white_concrete
setblock 368 131 504 minecraft:white_concrete
setblock 369 131 486 minecraft:red_nether_bricks
fill 369 131 487 369 134 487 minecraft:pink_terracotta
setblock 369 131 491 minecraft:red_nether_bricks
fill 369 131 492 369 134 492 minecraft:pink_terracotta
setblock 370 131 465 minecraft:red_nether_bricks
fill 370 131 466 370 131 469 minecraft:pink_terracotta
setblock 370 131 470 minecraft:red_nether_bricks
fill 370 131 471 370 134 471 minecraft:pink_terracotta
setblock 370 131 480 minecraft:red_nether_bricks
fill 370 131 481 370 134 481 minecraft:pink_terracotta
setblock 370 131 485 minecraft:red_nether_bricks
fill 370 131 486 370 134 486 minecraft:pink_terracotta
setblock 370 131 490 minecraft:red_nether_bricks
fill 370 131 491 370 134 491 minecraft:pink_terracotta
setblock 370 131 494 minecraft:pink_terracotta
setblock 330 132 464 minecraft:red_nether_bricks
fill 330 132 465 333 132 465 minecraft:pink_terracotta
setblock 330 132 468 minecraft:pink_terracotta
setblock 330 132 469 minecraft:red_nether_bricks
fill 330 132 470 330 135 470 minecraft:pink_terracotta
fill 330 132 472 330 132 473 minecraft:pink_terracotta
setblock 330 132 474 minecraft:red_nether_bricks
fill 330 132 475 330 132 478 minecraft:pink_terracotta
setblock 330 132 479 minecraft:red_nether_bricks
fill 330 132 480 330 135 480 minecraft:pink_terracotta
setblock 330 132 483 minecraft:pink_terracotta
setblock 330 132 484 minecraft:red_nether_bricks
fill 330 132 485 330 135 485 minecraft:pink_terracotta
setblock 330 132 489 minecraft:red_nether_bricks
fill 330 132 490 330 135 490 minecraft:pink_terracotta
setblock 330 132 493 minecraft:pink_terracotta
setblock 330 132 504 minecraft:white_concrete
fill 331 132 464 334 132 464 minecraft:pink_terracotta
setblock 331 132 468 minecraft:red_nether_bricks
fill 331 132 469 331 135 469 minecraft:pink_terracotta
setblock 331 132 472 minecraft:pink_terracotta
setblock 331 132 473 minecraft:red_nether_bricks
fill 331 132 474 331 133 476 minecraft:pink_terracotta
setblock 331 132 482 minecraft:pink_terracotta
setblock 331 132 483 minecraft:red_nether_bricks
fill 331 132 484 331 134 484 minecraft:pink_terracotta
setblock 331 132 488 minecraft:red_nether_bricks
fill 331 132 489 331 135 489 minecraft:pink_terracotta
fill 331 132 491 331 133 491 minecraft:pink_terracotta
setblock 332 132 466 minecraft:pink_terracotta
setblock 332 132 467 minecraft:red_nether_bricks
fill 332 132 468 333 134 468 minecraft:pink_terracotta
setblock 332 132 472 minecraft:red_nether_bricks
fill 332 132 473 332 135 473 minecraft:pink_terracotta
setblock 333 132 466 minecraft:red_nether_bricks
fill 333 132 467 336 132 467 minecraft:pink_terracotta
fill 333 132 469 333 132 470 minecraft:pink_terracotta
setblock 333 132 471 minecraft:red_nether_bricks
fill 333 132 504 334 132 504 minecraft:pink_terracotta
setblock 334 132 465 minecraft:red_nether_bricks
fill 334 132 466 337 132 466 minecraft:pink_terracotta
setblock 335 132 464 minecraft:red_nether_bricks
fill 335 132 465 338 132 465 minecraft:pink_terracotta
setblock 335 132 468 minecraft:pink_terracotta
setblock 335 132 504 minecraft:red_nether_bricks
fill 336 132 464 339 132 464 minecraft:pink_terracotta
setblock 336 132 468 minecraft:red_nether_bricks
fill 336 132 504 339 132 504 minecraft:pink_terracotta
setblock 337 132 467 minecraft:red_nether_bricks
fill 337 132 468 337 135 468 minecraft:pink_terracotta
fill 337 132 503 337 134 503 minecraft:pink_terracotta
setblock 338 132 466 minecraft:red_nether_bricks
fill 338 132 467 338 135 467 minecraft:pink_terracotta
fill 338 132 469 339 132 469 minecraft:red_terracotta
setblock 339 132 465 minecraft:red_nether_bricks
fill 339 132 466 339 135 466 minecraft:pink_terracotta
fill 339 132 468 339 133 468 minecraft:pink_terracotta
setblock 340 132 464 minecraft:red_nether_bricks
fill 340 132 465 340 135 465 minecraft:pink_terracotta
setblock 340 132 468 minecraft:red_terracotta
setblock 340 132 503 minecraft:pink_terracotta
setblock 340 132 504 minecraft:red_nether_bricks
fill 341 132 464 341 135 464 minecraft:pink_terracotta
fill 341 132 504 344 132 504 minecraft:pink_terracotta
setblock 342 132 467 minecraft:red_nether_bricks
setblock 343 132 466 minecraft:red_nether_bricks
setblock 344 132 465 minecraft:red_nether_bricks
fill 344 132 466 344 133 466 minecraft:pink_terracotta
setblock 345 132 464 minecraft:red_nether_bricks
fill 345 132 465 348 132 465 minecraft:pink_terracotta
setblock 345 132 504 minecraft:red_nether_bricks
fill 346 132 464 349 132 464 minecraft:pink_terracotta
fill 346 132 504 349 132 504 minecraft:pink_terracotta
setblock 349 132 465 minecraft:red_nether_bricks
setblock 350 132 464 minecraft:red_nether_bricks
fill 350 132 465 353 132 465 minecraft:pink_terracotta
setblock 350 132 504 minecraft:red_nether_bricks
fill 351 132 464 351 135 464 minecraft:pink_terracotta
setblock 351 132 503 minecraft:red_nether_bricks
fill 351 132 504 351 135 504 minecraft:pink_terracotta
setblock 352 132 466 minecraft:pink_terracotta
fill 352 132 503 355 132 503 minecraft:pink_terracotta
setblock 353 132 466 minecraft:red_nether_bricks
setblock 354 132 465 minecraft:red_nether_bricks
fill 354 132 466 354 135 466 minecraft:pink_terracotta
setblock 355 132 464 minecraft:red_nether_bricks
fill 355 132 465 355 135 465 minecraft:pink_terracotta
fill 355 132 502 356 132 502 minecraft:pink_terracotta
setblock 355 132 504 minecraft:red_nether_bricks
fill 356 132 464 359 132 464 minecraft:pink_terracotta
setblock 356 132 503 minecraft:red_nether_bricks
fill 356 132 504 356 135 504 minecraft:pink_terracotta
setblock 357 132 466 minecraft:pink_terracotta
setblock 357 132 502 minecraft:red_nether_bricks
fill 357 132 503 357 135 503 minecraft:pink_terracotta
setblock 358 132 466 minecraft:red_nether_bricks
setblock 358 132 502 minecraft:pink_terracotta
setblock 359 132 465 minecraft:red_nether_bricks
setblock 359 132 466 minecraft:pink_terracotta
setblock 360 132 464 minecraft:red_nether_bricks
fill 360 132 465 360 134 465 minecraft:pink_terracotta
setblock 360 132 504 minecraft:red_nether_bricks
fill 361 132 464 361 134 464 minecraft:pink_terracotta
setblock 361 132 503 minecraft:red_nether_bricks
fill 361 132 504 361 134 504 minecraft:pink_terracotta
setblock 366 132 485 minecraft:black_concrete
fill 368 132 487 368 132 490 minecraft:pink_terracotta
setblock 369 132 485 minecraft:red_nether_bricks
fill 369 132 486 369 135 486 minecraft:pink_terracotta
setblock 369 132 489 minecraft:pink_terracotta
setblock 369 132 490 minecraft:red_nether_bricks
fill 369 132 491 369 135 491 minecraft:pink_terracotta
fill 369 132 493 369 133 493 minecraft:pink_terracotta
setblock 370 132 464 minecraft:white_concrete
fill 370 132 465 370 132 468 minecraft:pink_terracotta
setblock 370 132 469 minecraft:red_nether_bricks
fill 370 132 470 370 135 470 minecraft:pink_terracotta
fill 370 132 472 370 132 473 minecraft:pink_terracotta
setblock 370 132 474 minecraft:red_nether_bricks
fill 370 132 475 370 135 475 minecraft:pink_terracotta
setblock 370 132 479 minecraft:red_nether_bricks
fill 370 132 480 370 135 480 minecraft:pink_terracotta
setblock 370 132 484 minecraft:red_nether_bricks
fill 370 132 485 370 135 485 minecraft:pink_terracotta
setblock 370 132 489 minecraft:red_nether_bricks
fill 370 132 490 370 135 490 minecraft:pink_terracotta
setblock 370 132 494 minecraft:red_nether_bricks
fill 370 132 495 370 135 495 minecraft:pink_terracotta
fill 330 133 464 332 133 465 minecraft:pink_terracotta
setblock 330 133 467 minecraft:pink_terracotta
setblock 330 133 468 minecraft:red_nether_bricks
fill 330 133 469 330 136 469 minecraft:pink_terracotta
fill 330 133 471 330 133 472 minecraft:pink_terracotta
setblock 330 133 473 minecraft:red_nether_bricks
fill 330 133 474 330 133 477 minecraft:pink_terracotta
setblock 330 133 478 minecraft:red_nether_bricks
fill 330 133 479 330 136 479 minecraft:pink_terracotta
setblock 330 133 483 minecraft:red_nether_bricks
fill 330 133 484 330 136 484 minecraft:pink_terracotta
setblock 330 133 488 minecraft:red_nether_bricks
fill 330 133 489 330 136 489 minecraft:pink_terracotta
setblock 330 133 493 minecraft:red_nether_bricks
fill 330 133 494 330 136 494 minecraft:pink_terracotta
setblock 331 133 467 minecraft:red_nether_bricks
fill 331 133 468 331 136 468 minecraft:pink_terracotta
setblock 331 133 471 minecraft:pink_terracotta
setblock 331 133 472 minecraft:red_nether_bricks
fill 331 133 473 331 136 473 minecraft:pink_terracotta
setblock 331 133 477 minecraft:red_nether_bricks
fill 331 133 478 331 136 478 minecraft:pink_terracotta
setblock 331 133 482 minecraft:red_nether_bricks
fill 331 133 483 331 134 483 minecraft:pink_terracotta
setblock 331 133 487 minecraft:red_nether_bricks
fill 331 133 488 332 134 488 minecraft:pink_terracotta
setblock 331 133 492 minecraft:red_nether_bricks
setblock 332 133 466 minecraft:red_nether_bricks
fill 332 133 467 335 133 467 minecraft:pink_terracotta
setblock 332 133 471 minecraft:red_nether_bricks
fill 332 133 472 333 135 472 minecraft:pink_terracotta
fill 332 133 474 332 133 475 minecraft:pink_terracotta
setblock 332 133 487 minecraft:pink_terracotta
fill 332 133 489 332 134 489 minecraft:pink_terracotta
fill 332 133 504 333 133 504 minecraft:pink_terracotta
setblock 333 133 464 minecraft:pink_terracotta
setblock 333 133 465 minecraft:red_nether_bricks
fill 333 133 466 336 133 466 minecraft:pink_terracotta
setblock 333 133 469 minecraft:pink_terracotta
setblock 333 133 470 minecraft:red_nether_bricks
fill 333 133 471 333 136 471 minecraft:pink_terracotta
setblock 334 133 464 minecraft:red_nether_bricks
fill 334 133 465 337 133 465 minecraft:pink_terracotta
setblock 334 133 468 minecraft:pink_terracotta
setblock 334 133 469 minecraft:red_nether_bricks
setblock 334 133 504 minecraft:red_nether_bricks
fill 335 133 464 338 133 464 minecraft:pink_terracotta
setblock 335 133 468 minecraft:red_nether_bricks
fill 335 133 503 335 138 503 minecraft:white_concrete
fill 335 133 504 338 133 504 minecraft:pink_terracotta
setblock 336 133 467 minecraft:red_nether_bricks
fill 336 133 468 336 135 468 minecraft:pink_terracotta
setblock 336 133 503 minecraft:pink_terracotta
setblock 337 133 466 minecraft:red_nether_bricks
fill 337 133 467 337 136 467 minecraft:pink_terracotta
setblock 338 133 465 minecraft:red_nether_bricks
fill 338 133 466 338 136 466 minecraft:pink_terracotta
setblock 339 133 464 minecraft:red_nether_bricks
fill 339 133 465 339 136 465 minecraft:pink_terracotta
setblock 339 133 504 minecraft:red_nether_bricks
fill 340 133 464 340 136 464 minecraft:pink_terracotta
fill 340 133 504 343 133 504 minecraft:pink_terracotta
setblock 341 133 467 minecraft:red_nether_bricks
setblock 342 133 466 minecraft:red_nether_bricks
setblock 343 133 465 minecraft:red_nether_bricks
fill 343 133 466 343 134 466 minecraft:pink_terracotta
setblock 344 133 464 minecraft:red_nether_bricks
fill 344 133 465 347 133 465 minecraft:pink_terracotta
setblock 344 133 504 minecraft:red_nether_bricks
fill 345 133 464 348 133 464 minecraft:pink_terracotta
fill 345 133 504 348 133 504 minecraft:pink_terracotta
setblock 348 133 465 minecraft:red_nether_bricks
setblock 349 133 464 minecraft:red_nether_bricks
fill 349 133 465 352 133 465 minecraft:pink_terracotta
setblock 349 133 504 minecraft:red_nether_bricks
fill 350 133 464 350 136 464 minecraft:pink_terracotta
fill 350 133 504 350 136 504 minecraft:pink_terracotta
setblock 351 133 466 minecraft:pink_terracotta
fill 351 133 503 354 133 503 minecraft:pink_terracotta
setblock 352 133 466 minecraft:red_nether_bricks
setblock 353 133 465 minecraft:red_nether_bricks
fill 353 133 466 353 135 466 minecraft:pink_terracotta
setblock 354 133 464 minecraft:red_nether_bricks
fill 354 133 465 354 136 465 minecraft:pink_terracotta
setblock 354 133 504 minecraft:red_nether_bricks
fill 355 133 464 358 133 464 minecraft:pink_terracotta
setblock 355 133 502 minecraft:pink_terracotta
setblock 355 133 503 minecraft:red_nether_bricks
fill 355 133 504 355 136 504 minecraft:pink_terracotta
setblock 356 133 502 minecraft:red_nether_bricks
fill 356 133 503 356 136 503 minecraft:pink_terracotta
setblock 357 133 466 minecraft:red_nether_bricks
setblock 357 133 502 minecraft:pink_terracotta
setblock 358 133 465 minecraft:red_nether_bricks
setblock 358 133 466 minecraft:pink_terracotta
setblock 359 133 464 minecraft:red_nether_bricks
fill 359 133 465 359 134 465 minecraft:pink_terracotta
setblock 359 133 504 minecraft:red_nether_bricks
fill 360 133 464 360 135 464 minecraft:pink_terracotta
setblock 360 133 503 minecraft:red_nether_bricks
fill 360 133 504 360 135 504 minecraft:pink_terracotta
setblock 364 133 464 minecraft:white_concrete
fill 368 133 475 368 140 475 minecraft:iron_block
fill 368 133 487 368 133 489 minecraft:pink_terracotta
setblock 368 133 490 minecraft:red_nether_bricks
fill 368 133 491 368 135 491 minecraft:pink_terracotta
setblock 369 133 484 minecraft:red_nether_bricks
fill 369 133 485 369 136 485 minecraft:pink_terracotta
setblock 369 133 489 minecraft:red_nether_bricks
fill 369 133 490 369 136 490 minecraft:pink_terracotta
setblock 369 133 494 minecraft:red_nether_bricks
fill 370 133 464 370 133 467 minecraft:pink_terracotta
setblock 370 133 468 minecraft:red_nether_bricks
fill 370 133 469 370 136 469 minecraft:pink_terracotta
setblock 370 133 472 minecraft:pink_terracotta
setblock 370 133 473 minecraft:red_nether_bricks
fill 370 133 474 370 136 474 minecraft:pink_terracotta
fill 370 133 476 370 133 477 minecraft:pink_terracotta
setblock 370 133 478 minecraft:red_nether_bricks
fill 370 133 479 370 136 479 minecraft:pink_terracotta
setblock 370 133 483 minecraft:red_nether_bricks
fill 370 133 484 370 136 484 minecraft:pink_terracotta
setblock 370 133 488 minecraft:red_nether_bricks
fill 370 133 489 370 136 489 minecraft:pink_terracotta
setblock 370 133 492 minecraft:pink_terracotta
setblock 370 133 493 minecraft:red_nether_bricks
fill 370 133 494 370 136 494 minecraft:pink_terracotta
fill 370 133 496 370 134 496 minecraft:pink_terracotta
setblock 370 133 502 minecraft:white_concrete
fill 330 134 464 331 134 465 minecraft:pink_terracotta
setblock 330 134 467 minecraft:red_nether_bricks
fill 330 134 468 330 137 468 minecraft:pink_terracotta
setblock 330 134 471 minecraft:pink_terracotta
setblock 330 134 472 minecraft:red_nether_bricks
fill 330 134 473 330 134 476 minecraft:pink_terracotta
setblock 330 134 477 minecraft:red_nether_bricks
fill 330 134 478 330 137 478 minecraft:pink_terracotta
setblock 330 134 482 minecraft:red_nether_bricks
fill 330 134 483 330 137 483 minecraft:pink_terracotta
setblock 330 134 487 minecraft:red_nether_bricks
fill 330 134 488 330 137 488 minecraft:pink_terracotta
setblock 330 134 491 minecraft:pink_terracotta
setblock 330 134 492 minecraft:red_nether_bricks
fill 330 134 493 331 136 493 minecraft:pink_terracotta
fill 330 134 495 330 135 495 minecraft:pink_terracotta
setblock 330 134 497 minecraft:white_concrete
setblock 331 134 466 minecraft:red_nether_bricks
fill 331 134 467 334 134 467 minecraft:pink_terracotta
setblock 331 134 470 minecraft:pink_terracotta
setblock 331 134 471 minecraft:red_nether_bricks
fill 331 134 472 331 137 472 minecraft:pink_terracotta
fill 331 134 474 331 134 475 minecraft:pink_terracotta
setblock 331 134 476 minecraft:red_nether_bricks
fill 331 134 477 331 137 477 minecraft:pink_terracotta
fill 331 134 479 331 135 479 minecraft:pink_terracotta
setblock 331 134 486 minecraft:red_nether_bricks
fill 331 134 487 331 136 487 minecraft:pink_terracotta
setblock 331 134 491 minecraft:red_nether_bricks
fill 331 134 492 331 137 492 minecraft:pink_terracotta
setblock 332 134 464 minecraft:pink_terracotta
setblock 332 134 465 minecraft:red_nether_bricks
fill 332 134 466 335 134 466 minecraft:pink_terracotta
setblock 332 134 470 minecraft:red_nether_bricks
fill 332 134 471 332 137 471 minecraft:pink_terracotta
setblock 332 134 474 minecraft:pink_terracotta
setblock 332 134 475 minecraft:red_nether_bricks
fill 332 134 476 332 137 476 minecraft:pink_terracotta
setblock 332 134 490 minecraft:red_nether_bricks
setblock 332 134 504 minecraft:pink_terracotta
setblock 333 134 464 minecraft:red_nether_bricks
fill 333 134 465 336 134 465 minecraft:pink_terracotta
setblock 333 134 469 minecraft:red_nether_bricks
fill 333 134 470 334 136 470 minecraft:pink_terracotta
setblock 333 134 473 minecraft:pink_terracotta
fill 333 134 503 334 137 503 minecraft:white_concrete
setblock 333 134 504 minecraft:red_nether_bricks
fill 334 134 464 337 134 464 minecraft:pink_terracotta
setblock 334 134 468 minecraft:red_nether_bricks
fill 334 134 469 334 136 469 minecraft:pink_terracotta
fill 334 134 471 334 135 471 minecraft:pink_terracotta
fill 334 134 502 336 137 502 minecraft:white_concrete
fill 334 134 504 337 134 504 minecraft:pink_terracotta
setblock 335 134 467 minecraft:red_nether_bricks
fill 335 134 468 335 135 468 minecraft:pink_terracotta
fill 335 134 501 335 137 501 minecraft:white_concrete
setblock 336 134 466 minecraft:red_nether_bricks
fill 336 134 467 336 137 467 minecraft:pink_terracotta
fill 336 134 503 336 137 503 minecraft:white_concrete
setblock 337 134 465 minecraft:red_nether_bricks
fill 337 134 466 337 137 466 minecraft:pink_terracotta
setblock 338 134 464 minecraft:red_nether_bricks
fill 338 134 465 338 137 465 minecraft:pink_terracotta
setblock 338 134 504 minecraft:red_nether_bricks
fill 339 134 464 339 137 464 minecraft:pink_terracotta
fill 339 134 468 339 176 468 minecraft:red_nether_bricks
fill 339 134 504 342 134 504 minecraft:pink_terracotta
setblock 340 134 467 minecraft:red_nether_bricks
setblock 341 134 466 minecraft:red_nether_bricks
setblock 341 134 467 minecraft:pink_terracotta
setblock 342 134 465 minecraft:red_nether_bricks
fill 342 134 466 342 135 466 minecraft:pink_terracotta
setblock 343 134 464 minecraft:red_nether_bricks
fill 343 134 465 346 134 465 minecraft:pink_terracotta
setblock 343 134 504 minecraft:red_nether_bricks
fill 344 134 464 347 134 464 minecraft:pink_terracotta
fill 344 134 504 347 134 504 minecraft:pink_terracotta
setblock 347 134 465 minecraft:red_nether_bricks
setblock 348 134 464 minecraft:red_nether_bricks
fill 348 134 465 351 134 465 minecraft:pink_terracotta
setblock 348 134 504 minecraft:red_nether_bricks
fill 349 134 464 349 137 464 minecraft:pink_terracotta
fill 349 134 504 349 137 504 minecraft:pink_terracotta
fill 351 134 503 353 134 503 minecraft:pink_terracotta
setblock 352 134 465 minecraft:red_nether_bricks
setblock 352 134 466 minecraft:pink_terracotta
setblock 353 134 464 minecraft:red_nether_bricks
fill 353 134 465 353 137 465 minecraft:pink_terracotta
setblock 353 134 504 minecraft:red_nether_bricks
fill 354 134 464 357 134 464 minecraft:pink_terracotta
setblock 354 134 503 minecraft:red_nether_bricks
fill 354 134 504 354 137 504 minecraft:pink_terracotta
setblock 355 134 502 minecraft:red_nether_bricks
fill 355 134 503 355 137 503 minecraft:pink_terracotta
setblock 356 134 466 minecraft:red_nether_bricks
setblock 356 134 502 minecraft:pink_terracotta
setblock 357 134 465 minecraft:red_nether_bricks
setblock 357 134 466 minecraft:pink_terracotta
setblock 358 134 464 minecraft:red_nether_bricks
fill 358 134 465 358 135 465 minecraft:pink_terracotta
setblock 358 134 504 minecraft:red_nether_bricks
fill 359 134 464 359 136 464 minecraft:pink_terracotta
setblock 359 134 503 minecraft:red_nether_bricks
fill 359 134 504 359 136 504 minecraft:pink_terracotta
setblock 367 134 504 minecraft:white_concrete
setblock 368 134 488 minecraft:pink_terracotta
setblock 368 134 489 minecraft:red_nether_bricks
fill 368 134 490 368 135 490 minecraft:pink_terracotta
fill 369 134 469 369 134 472 minecraft:pink_terracotta
fill 369 134 484 369 135 484 minecraft:pink_terracotta
setblock 369 134 488 minecraft:red_nether_bricks
fill 369 134 489 369 137 489 minecraft:pink_terracotta
setblock 369 134 493 minecraft:red_nether_bricks
fill 369 134 494 369 137 494 minecraft:pink_terracotta
fill 370 134 464 370 134 466 minecraft:pink_terracotta
setblock 370 134 467 minecraft:red_nether_bricks
fill 370 134 468 370 137 468 minecraft:pink_terracotta
setblock 370 134 472 minecraft:red_nether_bricks
fill 370 134 473 370 137 473 minecraft:pink_terracotta
setblock 370 134 476 minecraft:pink_terracotta
setblock 370 134 477 minecraft:red_nether_bricks
fill 370 134 478 370 137 478 minecraft:pink_terracotta
setblock 370 134 482 minecraft:red_nether_bricks
fill 370 134 483 370 137 483 minecraft:pink_terracotta
setblock 370 134 487 minecraft:red_nether_bricks
fill 370 134 488 370 137 488 minecraft:pink_terracotta
setblock 370 134 492 minecraft:red_nether_bricks
fill 370 134 493 370 137 493 minecraft:pink_terracotta
setblock 370 134 497 minecraft:red_nether_bricks
fill 330 135 464 330 135 465 minecraft:pink_terracotta
setblock 330 135 466 minecraft:red_nether_bricks
fill 330 135 467 333 135 467 minecraft:pink_terracotta
setblock 330 135 471 minecraft:red_nether_bricks
fill 330 135 472 330 135 475 minecraft:pink_terracotta
setblock 330 135 476 minecraft:red_nether_bricks
fill 330 135 477 330 138 477 minecraft:pink_terracotta
setblock 330 135 481 minecraft:red_nether_bricks
fill 330 135 482 330 138 482 minecraft:pink_terracotta
setblock 330 135 486 minecraft:red_nether_bricks
fill 330 135 487 330 138 487 minecraft:pink_terracotta
setblock 330 135 491 minecraft:red_nether_bricks
fill 330 135 492 330 138 492 minecraft:pink_terracotta
setblock 330 135 496 minecraft:red_nether_bricks
setblock 330 135 503 minecraft:white_concrete
setblock 331 135 464 minecraft:pink_terracotta
setblock 331 135 465 minecraft:red_nether_bricks
fill 331 135 466 334 135 466 minecraft:pink_terracotta
setblock 331 135 470 minecraft:red_nether_bricks
fill 331 135 471 331 138 471 minecraft:pink_terracotta
setblock 331 135 474 minecraft:pink_terracotta
setblock 331 135 475 minecraft:red_nether_bricks
fill 331 135 476 331 138 476 minecraft:pink_terracotta
setblock 331 135 485 minecraft:red_nether_bricks
setblock 331 135 486 minecraft:pink_terracotta
fill 331 135 488 331 136 488 minecraft:pink_terracotta
setblock 331 135 490 minecraft:red_nether_bricks
fill 331 135 491 331 138 491 minecraft:pink_terracotta
setblock 331 135 494 minecraft:pink_terracotta
setblock 332 135 464 minecraft:red_nether_bricks
fill 332 135 465 335 135 465 minecraft:pink_terracotta
setblock 332 135 468 minecraft:pink_terracotta
setblock 332 135 469 minecraft:red_nether_bricks
fill 332 135 470 332 138 470 minecraft:pink_terracotta
setblock 332 135 474 minecraft:red_nether_bricks
fill 332 135 475 332 138 475 minecraft:pink_terracotta
setblock 332 135 504 minecraft:red_nether_bricks
fill 333 135 464 336 135 464 minecraft:pink_terracotta
setblock 333 135 468 minecraft:red_nether_bricks
fill 333 135 469 333 138 469 minecraft:pink_terracotta
setblock 333 135 473 minecraft:red_nether_bricks
fill 333 135 474 333 138 474 minecraft:pink_terracotta
fill 333 135 502 333 136 502 minecraft:white_concrete
fill 333 135 504 336 135 504 minecraft:pink_terracotta
setblock 334 135 467 minecraft:red_nether_bricks
setblock 334 135 468 minecraft:pink_terracotta
fill 334 135 501 334 136 501 minecraft:white_concrete
setblock 335 135 466 minecraft:red_nether_bricks
fill 335 135 467 335 137 467 minecraft:pink_terracotta
setblock 336 135 465 minecraft:red_nether_bricks
fill 336 135 466 336 138 466 minecraft:pink_terracotta
fill 336 135 501 336 136 501 minecraft:white_concrete
setblock 337 135 464 minecraft:red_nether_bricks
fill 337 135 465 337 138 465 minecraft:pink_terracotta
fill 337 135 502 337 136 503 minecraft:white_concrete
setblock 337 135 504 minecraft:red_nether_bricks
fill 338 135 464 338 138 464 minecraft:pink_terracotta
fill 338 135 468 338 176 468 minecraft:red_nether_bricks
fill 338 135 504 341 135 504 minecraft:pink_terracotta
fill 339 135 467 339 161 467 minecraft:red_nether_bricks
setblock 340 135 466 minecraft:red_nether_bricks
setblock 341 135 465 minecraft:red_nether_bricks
setblock 341 135 466 minecraft:pink_terracotta
setblock 342 135 464 minecraft:red_nether_bricks
fill 342 135 465 345 135 465 minecraft:pink_terracotta
setblock 342 135 504 minecraft:red_nether_bricks
fill 343 135 464 346 135 464 minecraft:pink_terracotta
fill 343 135 504 344 135 504 minecraft:pink_terracotta
setblock 346 135 504 minecraft:pink_terracotta
setblock 347 135 464 minecraft:red_nether_bricks
setblock 347 135 504 minecraft:red_nether_bricks
fill 348 135 464 348 135 465 minecraft:pink_terracotta
fill 348 135 504 348 138 504 minecraft:pink_terracotta
fill 349 135 465 350 135 465 minecraft:pink_terracotta
setblock 351 135 465 minecraft:red_nether_bricks
fill 351 135 503 352 135 503 minecraft:pink_terracotta
setblock 352 135 464 minecraft:red_nether_bricks
fill 352 135 465 352 136 465 minecraft:pink_terracotta
setblock 352 135 504 minecraft:red_nether_bricks
fill 353 135 464 356 135 464 minecraft:pink_terracotta
setblock 353 135 503 minecraft:red_nether_bricks
fill 353 135 504 353 138 504 minecraft:pink_terracotta
fill 354 135 503 354 138 503 minecraft:pink_terracotta
setblock 355 135 466 minecraft:red_nether_bricks
setblock 356 135 465 minecraft:red_nether_bricks
setblock 357 135 464 minecraft:red_nether_bricks
setblock 357 135 465 minecraft:pink_terracotta
setblock 357 135 504 minecraft:red_nether_bricks
fill 358 135 464 358 136 464 minecraft:pink_terracotta
setblock 358 135 503 minecraft:red_nether_bricks
fill 358 135 504 358 137 504 minecraft:pink_terracotta
setblock 368 135 489 minecraft:pink_terracotta
fill 369 135 469 369 135 471 minecraft:pink_terracotta
setblock 369 135 472 minecraft:red_nether_bricks
fill 369 135 473 369 137 474 minecraft:pink_terracotta
setblock 369 135 487 minecraft:red_nether_bricks
fill 369 135 488 369 138 488 minecraft:pink_terracotta
setblock 369 135 492 minecraft:red_nether_bricks
fill 369 135 493 369 138 493 minecraft:pink_terracotta
fill 369 135 495 369 136 495 minecraft:pink_terracotta
setblock 370 135 465 minecraft:pink_terracotta
setblock 370 135 466 minecraft:red_nether_bricks
fill 370 135 467 370 138 467 minecraft:pink_terracotta
setblock 370 135 471 minecraft:red_nether_bricks
fill 370 135 472 370 138 472 minecraft:pink_terracotta
setblock 370 135 476 minecraft:red_nether_bricks
fill 370 135 477 370 138 477 minecraft:pink_terracotta
setblock 370 135 481 minecraft:red_nether_bricks
fill 370 135 482 370 138 482 minecraft:pink_terracotta
setblock 370 135 486 minecraft:red_nether_bricks
fill 370 135 487 370 138 487 minecraft:pink_terracotta
setblock 370 135 491 minecraft:red_nether_bricks
fill 370 135 492 370 138 492 minecraft:pink_terracotta
setblock 370 135 496 minecraft:red_nether_bricks
fill 370 135 497 370 138 497 minecraft:pink_terracotta
setblock 330 136 464 minecraft:pink_terracotta
setblock 330 136 465 minecraft:red_nether_bricks
fill 330 136 466 332 136 467 minecraft:pink_terracotta
setblock 330 136 470 minecraft:red_nether_bricks
fill 330 136 471 330 136 474 minecraft:pink_terracotta
setblock 330 136 475 minecraft:red_nether_bricks
fill 330 136 476 330 139 476 minecraft:pink_terracotta
setblock 330 136 480 minecraft:red_nether_bricks
fill 330 136 481 330 139 481 minecraft:pink_terracotta
setblock 330 136 485 minecraft:red_nether_bricks
fill 330 136 486 330 138 486 minecraft:pink_terracotta
setblock 330 136 490 minecraft:red_nether_bricks
fill 330 136 491 330 139 491 minecraft:pink_terracotta
setblock 330 136 495 minecraft:red_nether_bricks
fill 330 136 496 330 139 496 minecraft:pink_terracotta
setblock 331 136 464 minecraft:red_nether_bricks
fill 331 136 465 334 136 465 minecraft:pink_terracotta
setblock 331 136 469 minecraft:red_nether_bricks
fill 331 136 470 331 139 470 minecraft:pink_terracotta
setblock 331 136 474 minecraft:red_nether_bricks
fill 331 136 475 331 139 475 minecraft:pink_terracotta
setblock 331 136 479 minecraft:red_nether_bricks
setblock 331 136 489 minecraft:red_nether_bricks
fill 331 136 490 331 137 490 minecraft:pink_terracotta
setblock 331 136 494 minecraft:red_nether_bricks
fill 332 136 464 335 136 464 minecraft:pink_terracotta
setblock 332 136 468 minecraft:red_nether_bricks
fill 332 136 469 332 139 469 minecraft:pink_terracotta
setblock 332 136 472 minecraft:pink_terracotta
setblock 332 136 473 minecraft:red_nether_bricks
fill 332 136 474 332 139 474 minecraft:pink_terracotta
fill 332 136 504 335 136 504 minecraft:pink_terracotta
setblock 333 136 466 minecraft:pink_terracotta
setblock 333 136 467 minecraft:red_nether_bricks
fill 333 136 468 333 138 468 minecraft:pink_terracotta
setblock 333 136 472 minecraft:red_nether_bricks
fill 333 136 473 333 139 473 minecraft:pink_terracotta
setblock 334 136 466 minecraft:red_nether_bricks
fill 334 136 467 334 137 467 minecraft:pink_terracotta
setblock 334 136 471 minecraft:red_nether_bricks
setblock 335 136 465 minecraft:red_nether_bricks
fill 335 136 466 335 138 466 minecraft:pink_terracotta
setblock 335 136 500 minecraft:black_concrete
setblock 336 136 464 minecraft:red_nether_bricks
fill 336 136 465 336 139 465 minecraft:pink_terracotta
setblock 336 136 504 minecraft:red_nether_bricks
fill 337 136 464 337 139 464 minecraft:pink_terracotta
fill 337 136 504 340 136 504 minecraft:pink_terracotta
fill 338 136 467 338 176 467 minecraft:red_nether_bricks
setblock 339 136 466 minecraft:red_nether_bricks
setblock 340 136 465 minecraft:red_nether_bricks
setblock 340 136 466 minecraft:pink_terracotta
setblock 341 136 464 minecraft:red_nether_bricks
fill 341 136 465 342 136 465 minecraft:pink_terracotta
setblock 341 136 504 minecraft:red_nether_bricks
fill 342 136 464 345 136 464 minecraft:pink_terracotta
setblock 346 136 464 minecraft:red_nether_bricks
fill 347 136 464 348 136 464 minecraft:pink_terracotta
setblock 347 136 504 minecraft:pink_terracotta
setblock 350 136 465 minecraft:red_nether_bricks
setblock 351 136 464 minecraft:red_nether_bricks
setblock 351 136 465 minecraft:pink_terracotta
setblock 351 136 503 minecraft:pink_terracotta
setblock 351 136 504 minecraft:red_nether_bricks
fill 352 136 464 355 136 464 minecraft:pink_terracotta
setblock 352 136 503 minecraft:red_nether_bricks
fill 352 136 504 352 139 504 minecraft:pink_terracotta
fill 353 136 503 353 139 503 minecraft:pink_terracotta
setblock 355 136 465 minecraft:red_nether_bricks
setblock 356 136 464 minecraft:red_nether_bricks
setblock 356 136 465 minecraft:pink_terracotta
setblock 356 136 504 minecraft:red_nether_bricks
fill 357 136 464 357 137 464 minecraft:pink_terracotta
setblock 357 136 503 minecraft:red_nether_bricks
fill 357 136 504 357 138 504 minecraft:pink_terracotta
fill 360 136 504 360 137 504 minecraft:white_concrete
setblock 365 136 464 minecraft:white_concrete
fill 369 136 469 369 136 470 minecraft:pink_terracotta
setblock 369 136 471 minecraft:red_nether_bricks
fill 369 136 472 369 139 472 minecraft:pink_terracotta
setblock 369 136 475 minecraft:pink_terracotta
setblock 369 136 476 minecraft:red_nether_bricks
setblock 369 136 486 minecraft:red_nether_bricks
fill 369 136 487 369 137 487 minecraft:pink_terracotta
setblock 369 136 491 minecraft:red_nether_bricks
fill 369 136 492 369 139 492 minecraft:pink_terracotta
setblock 370 136 465 minecraft:red_nether_bricks
fill 370 136 466 370 139 466 minecraft:pink_terracotta
setblock 370 136 470 minecraft:red_nether_bricks
fill 370 136 471 370 139 471 minecraft:pink_terracotta
setblock 370 136 475 minecraft:red_nether_bricks
fill 370 136 476 370 139 476 minecraft:pink_terracotta
setblock 370 136 480 minecraft:red_nether_bricks
fill 370 136 481 370 139 481 minecraft:pink_terracotta
setblock 370 136 485 minecraft:red_nether_bricks
fill 370 136 486 370 139 486 minecraft:pink_terracotta
setblock 370 136 490 minecraft:red_nether_bricks
fill 370 136 491 370 139 491 minecraft:pink_terracotta
setblock 370 136 495 minecraft:red_nether_bricks
fill 370 136 496 370 139 496 minecraft:pink_terracotta
fill 370 136 498 370 137 498 minecraft:pink_terracotta
setblock 370 136 503 minecraft:white_concrete
setblock 330 137 464 minecraft:red_nether_bricks
fill 330 137 465 331 137 467 minecraft:pink_terracotta
setblock 330 137 469 minecraft:red_nether_bricks
fill 330 137 470 330 137 473 minecraft:pink_terracotta
setblock 330 137 474 minecraft:red_nether_bricks
fill 330 137 475 330 140 475 minecraft:pink_terracotta
setblock 330 137 479 minecraft:red_nether_bricks
fill 330 137 480 330 140 480 minecraft:pink_terracotta
setblock 330 137 484 minecraft:red_nether_bricks
setblock 330 137 485 minecraft:pink_terracotta
setblock 330 137 489 minecraft:red_nether_bricks
fill 330 137 490 330 140 490 minecraft:pink_terracotta
setblock 330 137 493 minecraft:pink_terracotta
setblock 330 137 494 minecraft:red_nether_bricks
fill 330 137 495 330 140 495 minecraft:pink_terracotta
fill 330 137 497 330 138 497 minecraft:pink_terracotta
fill 331 137 464 334 137 464 minecraft:pink_terracotta
setblock 331 137 468 minecraft:red_nether_bricks
fill 331 137 469 331 140 469 minecraft:pink_terracotta
setblock 331 137 473 minecraft:red_nether_bricks
fill 331 137 474 331 140 474 minecraft:pink_terracotta
setblock 331 137 478 minecraft:red_nether_bricks
fill 331 137 479 331 140 479 minecraft:pink_terracotta
setblock 331 137 489 minecraft:pink_terracotta
setblock 331 137 493 minecraft:red_nether_bricks
fill 331 137 494 331 140 494 minecraft:pink_terracotta
fill 332 137 465 332 137 466 minecraft:pink_terracotta
setblock 332 137 467 minecraft:red_nether_bricks
fill 332 137 468 332 140 468 minecraft:pink_terracotta
setblock 332 137 472 minecraft:red_nether_bricks
fill 332 137 473 332 140 473 minecraft:pink_terracotta
setblock 332 137 477 minecraft:red_nether_bricks
setblock 332 137 482 minecraft:light[level=12]
setblock 332 137 490 minecraft:light[level=12]
setblock 332 137 498 minecraft:light[level=12]
setblock 333 137 465 minecraft:pink_terracotta
setblock 333 137 466 minecraft:red_nether_bricks
setblock 333 137 467 minecraft:pink_terracotta
setblock 333 137 470 minecraft:pink_terracotta
setblock 333 137 471 minecraft:red_nether_bricks
fill 333 137 472 333 140 472 minecraft:pink_terracotta
fill 333 137 504 334 137 504 minecraft:pink_terracotta
setblock 334 137 465 minecraft:red_nether_bricks
fill 334 137 466 334 139 466 minecraft:pink_terracotta
setblock 335 137 464 minecraft:red_nether_bricks
fill 335 137 465 335 140 465 minecraft:pink_terracotta
setblock 335 137 504 minecraft:red_nether_bricks
fill 336 137 464 336 140 464 minecraft:pink_terracotta
fill 336 137 504 339 137 504 minecraft:pink_terracotta
setblock 337 137 503 minecraft:white_concrete
setblock 338 137 466 minecraft:red_nether_bricks
setblock 339 137 465 minecraft:red_nether_bricks
setblock 340 137 464 minecraft:red_nether_bricks
setblock 340 137 465 minecraft:pink_terracotta
setblock 340 137 466 minecraft:light[level=12]
setblock 340 137 474 minecraft:light[level=12]
setblock 340 137 482 minecraft:light[level=12]
setblock 340 137 490 minecraft:light[level=12]
setblock 340 137 498 minecraft:light[level=12]
fill 341 137 464 343 137 464 minecraft:pink_terracotta
setblock 341 137 504 minecraft:white_concrete
setblock 348 137 464 minecraft:pink_terracotta
setblock 348 137 466 minecraft:light[level=12]
setblock 348 137 474 minecraft:light[level=12]
setblock 348 137 482 minecraft:light[level=12]
setblock 348 137 490 minecraft:light[level=12]
setblock 348 137 498 minecraft:light[level=12]
setblock 350 137 464 minecraft:red_nether_bricks
setblock 350 137 504 minecraft:red_nether_bricks
fill 351 137 464 354 137 464 minecraft:pink_terracotta
setblock 351 137 503 minecraft:red_nether_bricks
fill 351 137 504 351 140 504 minecraft:pink_terracotta
fill 352 137 503 352 140 503 minecraft:pink_terracotta
setblock 355 137 464 minecraft:red_nether_bricks
setblock 355 137 504 minecraft:red_nether_bricks
setblock 356 137 464 minecraft:pink_terracotta
setblock 356 137 466 minecraft:light[level=12]
setblock 356 137 474 minecraft:light[level=12]
setblock 356 137 482 minecraft:light[level=12]
setblock 356 137 490 minecraft:light[level=12]
setblock 356 137 498 minecraft:light[level=12]
setblock 356 137 503 minecraft:red_nether_bricks
fill 356 137 504 356 139 504 minecraft:pink_terracotta
setblock 359 137 464 minecraft:white_concrete
setblock 364 137 466 minecraft:light[level=12]
setblock 364 137 474 minecraft:light[level=12]
setblock 364 137 482 minecraft:light[level=12]
setblock 364 137 490 minecraft:light[level=12]
setblock 364 137 498 minecraft:light[level=12]
setblock 366 137 504 minecraft:white_concrete
setblock 369 137 469 minecraft:pink_terracotta
setblock 369 137 470 minecraft:red_nether_bricks
fill 369 137 471 369 140 471 minecraft:pink_terracotta
setblock 369 137 475 minecraft:red_nether_bricks
fill 369 137 476 369 139 477 minecraft:pink_terracotta
setblock 369 137 486 minecraft:pink_terracotta
setblock 369 137 490 minecraft:red_nether_bricks
fill 369 137 491 369 140 491 minecraft:pink_terracotta
setblock 369 137 495 minecraft:red_nether_bricks
setblock 370 137 465 minecraft:pink_terracotta
setblock 370 137 469 minecraft:red_nether_bricks
fill 370 137 470 370 140 470 minecraft:pink_terracotta
setblock 370 137 474 minecraft:red_nether_bricks
fill 370 137 475 370 140 475 minecraft:pink_terracotta
setblock 370 137 479 minecraft:red_nether_bricks
fill 370 137 480 370 140 480 minecraft:pink_terracotta
setblock 370 137 484 minecraft:red_nether_bricks
fill 370 137 485 370 140 485 minecraft:pink_terracotta
setblock 370 137 489 minecraft:red_nether_bricks
fill 370 137 490 370 140 490 minecraft:pink_terracotta
setblock 370 137 494 minecraft:red_nether_bricks
fill 370 137 495 370 140 495 minecraft:pink_terracotta
fill 330 138 464 330 138 467 minecraft:pink_terracotta
setblock 330 138 468 minecraft:red_nether_bricks
fill 330 138 469 330 138 472 minecraft:pink_terracotta
setblock 330 138 473 minecraft:red_nether_bricks
fill 330 138 474 330 141 474 minecraft:pink_terracotta
setblock 330 138 478 minecraft:red_nether_bricks
fill 330 138 479 330 141 479 minecraft:pink_terracotta
setblock 330 138 488 minecraft:red_nether_bricks
fill 330 138 489 330 139 489 minecraft:pink_terracotta
setblock 330 138 493 minecraft:red_nether_bricks
fill 330 138 494 330 141 494 minecraft:pink_terracotta
setblock 330 138 498 minecraft:red_nether_bricks
setblock 330 138 502 minecraft:white_concrete
fill 331 138 464 331 138 466 minecraft:pink_terracotta
setblock 331 138 467 minecraft:red_nether_bricks
fill 331 138 468 331 141 468 minecraft:pink_terracotta
setblock 331 138 472 minecraft:red_nether_bricks
fill 331 138 473 331 141 473 minecraft:pink_terracotta
setblock 331 138 477 minecraft:red_nether_bricks
fill 331 138 478 331 141 478 minecraft:pink_terracotta
setblock 331 138 492 minecraft:red_nether_bricks
fill 331 138 493 331 139 493 minecraft:pink_terracotta
fill 331 138 495 331 139 495 minecraft:pink_terracotta
fill 332 138 464 332 138 465 minecraft:pink_terracotta
setblock 332 138 466 minecraft:red_nether_bricks
fill 332 138 467 332 140 467 minecraft:pink_terracotta
setblock 332 138 471 minecraft:red_nether_bricks
fill 332 138 472 332 141 472 minecraft:pink_terracotta
setblock 332 138 476 minecraft:red_nether_bricks
fill 332 138 477 332 141 477 minecraft:pink_terracotta
setblock 333 138 464 minecraft:pink_terracotta
setblock 333 138 465 minecraft:red_nether_bricks
fill 333 138 466 333 139 466 minecraft:pink_terracotta
setblock 333 138 470 minecraft:red_nether_bricks
fill 333 138 471 333 140 471 minecraft:pink_terracotta
setblock 333 138 504 minecraft:pink_terracotta
setblock 334 138 464 minecraft:red_nether_bricks
fill 334 138 465 334 141 465 minecraft:pink_terracotta
setblock 334 138 504 minecraft:red_nether_bricks
fill 335 138 464 335 141 464 minecraft:pink_terracotta
fill 335 138 504 337 138 504 minecraft:pink_terracotta
setblock 338 138 465 minecraft:red_nether_bricks
setblock 339 138 464 minecraft:red_nether_bricks
setblock 340 138 464 minecraft:pink_terracotta
setblock 347 138 504 minecraft:white_concrete
setblock 349 138 504 minecraft:red_nether_bricks
fill 350 138 464 353 138 464 minecraft:pink_terracotta
fill 350 138 504 350 141 504 minecraft:pink_terracotta
fill 351 138 503 351 141 503 minecraft:pink_terracotta
setblock 354 138 464 minecraft:red_nether_bricks
setblock 354 138 504 minecraft:red_nether_bricks
setblock 355 138 464 minecraft:pink_terracotta
fill 355 138 504 355 141 504 minecraft:pink_terracotta
setblock 369 138 469 minecraft:red_nether_bricks
fill 369 138 470 369 141 470 minecraft:pink_terracotta
setblock 369 138 473 minecraft:pink_terracotta
setblock 369 138 474 minecraft:red_nether_bricks
fill 369 138 475 369 141 475 minecraft:pink_terracotta
setblock 369 138 478 minecraft:pink_terracotta
setblock 369 138 489 minecraft:red_nether_bricks
fill 369 138 490 369 139 490 minecraft:pink_terracotta
setblock 369 138 494 minecraft:red_nether_bricks
fill 369 138 495 369 141 495 minecraft:pink_terracotta
setblock 370 138 468 minecraft:red_nether_bricks
fill 370 138 469 370 141 469 minecraft:pink_terracotta
setblock 370 138 473 minecraft:red_nether_bricks
fill 370 138 474 370 141 474 minecraft:pink_terracotta
setblock 370 138 478 minecraft:red_nether_bricks
fill 370 138 479 370 141 479 minecraft:pink_terracotta
setblock 370 138 483 minecraft:red_nether_bricks
fill 370 138 484 370 141 484 minecraft:pink_terracotta
setblock 370 138 488 minecraft:red_nether_bricks
fill 370 138 489 370 141 489 minecraft:pink_terracotta
setblock 370 138 493 minecraft:red_nether_bricks
fill 370 138 494 370 141 494 minecraft:pink_terracotta
setblock 370 138 498 minecraft:red_nether_bricks
fill 330 139 464 330 139 466 minecraft:pink_terracotta
setblock 330 139 467 minecraft:red_nether_bricks
fill 330 139 468 330 139 471 minecraft:pink_terracotta
setblock 330 139 472 minecraft:red_nether_bricks
fill 330 139 473 330 142 473 minecraft:pink_terracotta
setblock 330 139 477 minecraft:red_nether_bricks
fill 330 139 478 330 142 478 minecraft:pink_terracotta
setblock 330 139 482 minecraft:red_nether_bricks
setblock 330 139 483 minecraft:white_concrete
setblock 330 139 488 minecraft:pink_terracotta
setblock 330 139 492 minecraft:red_nether_bricks
fill 330 139 493 330 142 493 minecraft:pink_terracotta
setblock 330 139 497 minecraft:red_nether_bricks
fill 330 139 498 330 142 498 minecraft:pink_terracotta
fill 331 139 464 331 139 465 minecraft:pink_terracotta
setblock 331 139 466 minecraft:red_nether_bricks
fill 331 139 467 331 142 467 minecraft:pink_terracotta
setblock 331 139 471 minecraft:red_nether_bricks
fill 331 139 472 331 142 472 minecraft:pink_terracotta
setblock 331 139 476 minecraft:red_nether_bricks
fill 331 139 477 331 142 477 minecraft:pink_terracotta
setblock 332 139 464 minecraft:pink_terracotta
setblock 332 139 465 minecraft:red_nether_bricks
setblock 332 139 470 minecraft:red_nether_bricks
fill 332 139 471 332 142 471 minecraft:pink_terracotta
setblock 332 139 475 minecraft:red_nether_bricks
fill 332 139 476 332 142 476 minecraft:pink_terracotta
setblock 333 139 464 minecraft:red_nether_bricks
fill 333 139 465 333 142 465 minecraft:pink_terracotta
setblock 333 139 469 minecraft:red_nether_bricks
setblock 333 139 470 minecraft:pink_terracotta
setblock 333 139 474 minecraft:red_nether_bricks
setblock 333 139 504 minecraft:red_nether_bricks
fill 334 139 464 334 142 464 minecraft:pink_terracotta
fill 334 139 504 336 139 504 minecraft:pink_terracotta
setblock 337 139 465 minecraft:red_nether_bricks
setblock 338 139 464 minecraft:red_nether_bricks
setblock 339 139 464 minecraft:pink_terracotta
setblock 347 139 464 minecraft:white_concrete
setblock 348 139 504 minecraft:red_nether_bricks
fill 349 139 504 349 142 504 minecraft:pink_terracotta
setblock 352 139 464 minecraft:pink_terracotta
setblock 353 139 504 minecraft:red_nether_bricks
fill 354 139 504 354 142 504 minecraft:pink_terracotta
setblock 366 139 464 minecraft:white_concrete
setblock 369 139 469 minecraft:pink_terracotta
setblock 369 139 473 minecraft:red_nether_bricks
fill 369 139 474 369 142 474 minecraft:pink_terracotta
setblock 369 139 478 minecraft:red_nether_bricks
fill 369 139 479 369 142 479 minecraft:pink_terracotta
setblock 369 139 489 minecraft:pink_terracotta
setblock 369 139 493 minecraft:red_nether_bricks
fill 369 139 494 369 142 494 minecraft:pink_terracotta
setblock 370 139 467 minecraft:red_nether_bricks
fill 370 139 468 370 142 468 minecraft:pink_terracotta
setblock 370 139 472 minecraft:red_nether_bricks
fill 370 139 473 370 142 473 minecraft:pink_terracotta
setblock 370 139 477 minecraft:red_nether_bricks
fill 370 139 478 370 142 478 minecraft:pink_terracotta
setblock 370 139 482 minecraft:red_nether_bricks
fill 370 139 483 370 142 483 minecraft:pink_terracotta
setblock 370 139 487 minecraft:red_nether_bricks
fill 370 139 488 370 142 488 minecraft:pink_terracotta
setblock 370 139 492 minecraft:red_nether_bricks
fill 370 139 493 370 142 493 minecraft:pink_terracotta
setblock 370 139 497 minecraft:red_nether_bricks
fill 370 139 498 370 142 498 minecraft:pink_terracotta
fill 330 140 464 330 140 465 minecraft:pink_terracotta
setblock 330 140 466 minecraft:red_nether_bricks
fill 330 140 467 330 140 470 minecraft:pink_terracotta
setblock 330 140 471 minecraft:red_nether_bricks
fill 330 140 472 330 143 472 minecraft:pink_terracotta
setblock 330 140 476 minecraft:red_nether_bricks
fill 330 140 477 330 143 477 minecraft:pink_terracotta
setblock 330 140 481 minecraft:red_nether_bricks
fill 330 140 482 330 143 482 minecraft:pink_terracotta
setblock 330 140 489 minecraft:white_concrete
setblock 330 140 491 minecraft:red_nether_bricks
fill 330 140 492 330 143 492 minecraft:pink_terracotta
setblock 330 140 496 minecraft:red_nether_bricks
fill 330 140 497 330 143 497 minecraft:pink_terracotta
fill 330 140 499 330 140 500 minecraft:pink_terracotta
setblock 331 140 464 minecraft:pink_terracotta
setblock 331 140 465 minecraft:red_nether_bricks
fill 331 140 466 331 143 466 minecraft:pink_terracotta
setblock 331 140 470 minecraft:red_nether_bricks
fill 331 140 471 331 143 471 minecraft:pink_terracotta
setblock 331 140 475 minecraft:red_nether_bricks
fill 331 140 476 331 143 476 minecraft:pink_terracotta
setblock 331 140 495 minecraft:red_nether_bricks
fill 331 140 496 331 143 496 minecraft:pink_terracotta
setblock 332 140 464 minecraft:red_nether_bricks
fill 332 140 465 332 143 465 minecraft:pink_terracotta
setblock 332 140 469 minecraft:red_nether_bricks
fill 332 140 470 332 143 470 minecraft:pink_terracotta
setblock 332 140 474 minecraft:red_nether_bricks
fill 332 140 475 332 143 475 minecraft:pink_terracotta
setblock 332 140 504 minecraft:red_nether_bricks
fill 333 140 464 333 143 464 minecraft:pink_terracotta
setblock 333 140 473 minecraft:red_nether_bricks
fill 333 140 504 335 141 504 minecraft:pink_terracotta
setblock 337 140 464 minecraft:red_nether_bricks
setblock 338 140 464 minecraft:pink_terracotta
setblock 340 140 504 minecraft:white_concrete
setblock 341 140 464 minecraft:white_concrete
fill 344 140 468 344 151 468 minecraft:iron_block
fill 348 140 504 348 143 504 minecraft:pink_terracotta
setblock 352 140 504 minecraft:red_nether_bricks
setblock 353 140 503 minecraft:red_nether_bricks
fill 353 140 504 353 143 504 minecraft:pink_terracotta
setblock 359 140 504 minecraft:white_concrete
setblock 360 140 464 minecraft:white_concrete
setblock 369 140 472 minecraft:red_nether_bricks
fill 369 140 473 369 143 473 minecraft:pink_terracotta
setblock 369 140 476 minecraft:pink_terracotta
setblock 369 140 477 minecraft:red_nether_bricks
fill 369 140 478 369 143 478 minecraft:pink_terracotta
fill 369 140 480 369 141 480 minecraft:pink_terracotta
setblock 369 140 492 minecraft:red_nether_bricks
fill 369 140 493 369 143 493 minecraft:pink_terracotta
setblock 370 140 466 minecraft:red_nether_bricks
fill 370 140 467 370 143 467 minecraft:pink_terracotta
setblock 370 140 471 minecraft:red_nether_bricks
fill 370 140 472 370 143 472 minecraft:pink_terracotta
setblock 370 140 476 minecraft:red_nether_bricks
fill 370 140 477 370 143 477 minecraft:pink_terracotta
setblock 370 140 481 minecraft:red_nether_bricks
fill 370 140 482 370 143 482 minecraft:pink_terracotta
setblock 370 140 486 minecraft:red_nether_bricks
fill 370 140 487 370 143 487 minecraft:pink_terracotta
setblock 370 140 491 minecraft:red_nether_bricks
fill 370 140 492 370 143 492 minecraft:pink_terracotta
setblock 370 140 496 minecraft:red_nether_bricks
fill 370 140 497 370 143 497 minecraft:pink_terracotta
fill 370 140 499 370 141 499 minecraft:pink_terracotta
setblock 330 141 464 minecraft:pink_terracotta
setblock 330 141 465 minecraft:red_nether_bricks
fill 330 141 466 330 141 469 minecraft:pink_terracotta
setblock 330 141 470 minecraft:red_nether_bricks
fill 330 141 471 330 144 471 minecraft:pink_terracotta
setblock 330 141 475 minecraft:red_nether_bricks
fill 330 141 476 330 144 476 minecraft:pink_terracotta
setblock 330 141 480 minecraft:red_nether_bricks
fill 330 141 481 330 144 481 minecraft:pink_terracotta
setblock 330 141 490 minecraft:red_nether_bricks
fill 330 141 491 330 144 491 minecraft:pink_terracotta
setblock 330 141 495 minecraft:red_nether_bricks
fill 330 141 496 330 144 496 minecraft:pink_terracotta
setblock 330 141 499 minecraft:pink_terracotta
setblock 330 141 500 minecraft:red_nether_bricks
fill 330 141 501 330 143 502 minecraft:pink_terracotta
setblock 331 141 464 minecraft:red_nether_bricks
fill 331 141 465 331 144 465 minecraft:pink_terracotta
setblock 331 141 469 minecraft:red_nether_bricks
fill 331 141 470 331 144 470 minecraft:pink_terracotta
setblock 331 141 474 minecraft:red_nether_bricks
fill 331 141 475 331 144 475 minecraft:pink_terracotta
setblock 331 141 479 minecraft:red_nether_bricks
fill 331 141 480 331 144 480 minecraft:pink_terracotta
setblock 331 141 494 minecraft:red_nether_bricks
fill 331 141 495 331 144 495 minecraft:pink_terracotta
fill 331 141 497 331 141 498 minecraft:pink_terracotta
setblock 331 141 504 minecraft:red_nether_bricks
fill 332 141 464 332 144 464 minecraft:pink_terracotta
setblock 332 141 468 minecraft:red_nether_bricks
fill 332 141 469 332 144 469 minecraft:pink_terracotta
setblock 332 141 473 minecraft:red_nether_bricks
fill 332 141 474 332 144 474 minecraft:pink_terracotta
fill 332 141 504 332 144 504 minecraft:pink_terracotta
setblock 336 141 464 minecraft:red_nether_bricks
setblock 336 141 504 minecraft:red_nether_bricks
setblock 337 141 464 minecraft:pink_terracotta
setblock 346 141 504 minecraft:white_concrete
fill 347 141 504 347 144 504 minecraft:pink_terracotta
fill 349 141 503 350 142 503 minecraft:pink_terracotta
setblock 351 141 504 minecraft:red_nether_bricks
setblock 352 141 503 minecraft:red_nether_bricks
fill 352 141 504 352 144 504 minecraft:pink_terracotta
fill 353 141 503 353 144 503 minecraft:pink_terracotta
setblock 354 141 464 minecraft:white_concrete
setblock 365 141 504 minecraft:white_concrete
fill 368 141 474 368 141 476 minecraft:pink_terracotta
fill 369 141 469 369 142 469 minecraft:pink_terracotta
setblock 369 141 471 minecraft:red_nether_bricks
fill 369 141 472 369 144 472 minecraft:pink_terracotta
setblock 369 141 476 minecraft:red_nether_bricks
fill 369 141 477 369 144 477 minecraft:pink_terracotta
setblock 369 141 481 minecraft:red_nether_bricks
fill 369 141 492 369 144 492 minecraft:pink_terracotta
setblock 369 141 496 minecraft:red_nether_bricks
fill 370 141 466 370 144 466 minecraft:pink_terracotta
setblock 370 141 470 minecraft:red_nether_bricks
fill 370 141 471 370 144 471 minecraft:pink_terracotta
setblock 370 141 475 minecraft:red_nether_bricks
fill 370 141 476 370 144 476 minecraft:pink_terracotta
setblock 370 141 480 minecraft:red_nether_bricks
fill 370 141 481 370 144 481 minecraft:pink_terracotta
setblock 370 141 485 minecraft:red_nether_bricks
fill 370 141 486 370 144 486 minecraft:pink_terracotta
setblock 370 141 490 minecraft:red_nether_bricks
fill 370 141 491 370 144 491 minecraft:pink_terracotta
setblock 370 141 495 minecraft:red_nether_bricks
fill 370 141 496 370 144 496 minecraft:pink_terracotta
setblock 370 141 500 minecraft:red_nether_bricks
setblock 330 142 464 minecraft:red_nether_bricks
fill 330 142 465 330 142 468 minecraft:pink_terracotta
setblock 330 142 469 minecraft:red_nether_bricks
fill 330 142 470 330 145 470 minecraft:pink_terracotta
setblock 330 142 474 minecraft:red_nether_bricks
fill 330 142 475 330 145 475 minecraft:pink_terracotta
setblock 330 142 479 minecraft:red_nether_bricks
fill 330 142 480 330 145 480 minecraft:pink_terracotta
setblock 330 142 483 minecraft:pink_terracotta
setblock 330 142 494 minecraft:red_nether_bricks
fill 330 142 495 330 145 495 minecraft:pink_terracotta
setblock 330 142 499 minecraft:red_nether_bricks
fill 330 142 500 331 144 500 minecraft:pink_terracotta
setblock 330 142 503 minecraft:pink_terracotta
setblock 330 142 504 minecraft:red_nether_bricks
fill 331 142 464 331 145 464 minecraft:pink_terracotta
setblock 331 142 468 minecraft:red_nether_bricks
fill 331 142 469 331 145 469 minecraft:pink_terracotta
setblock 331 142 473 minecraft:red_nether_bricks
fill 331 142 474 331 145 474 minecraft:pink_terracotta
setblock 331 142 478 minecraft:red_nether_bricks
fill 331 142 479 331 145 479 minecraft:pink_terracotta
fill 331 142 494 331 145 494 minecraft:pink_terracotta
setblock 331 142 497 minecraft:pink_terracotta
setblock 331 142 498 minecraft:red_nether_bricks
fill 331 142 499 331 145 499 minecraft:pink_terracotta
fill 331 142 504 331 145 504 minecraft:pink_terracotta
setblock 332 142 472 minecraft:red_nether_bricks
fill 332 142 473 332 145 473 minecraft:pink_terracotta
setblock 332 142 477 minecraft:red_nether_bricks
fill 332 142 478 332 145 478 minecraft:pink_terracotta
fill 333 142 504 334 142 504 minecraft:pink_terracotta
setblock 335 142 464 minecraft:red_nether_bricks
setblock 335 142 504 minecraft:red_nether_bricks
fill 336 142 464 336 145 464 minecraft:pink_terracotta
fill 336 142 504 336 145 504 minecraft:pink_terracotta
setblock 345 142 504 minecraft:red_nether_bricks
fill 346 142 504 346 145 504 minecraft:pink_terracotta
setblock 348 142 464 minecraft:white_concrete
fill 348 142 503 348 144 503 minecraft:pink_terracotta
setblock 350 142 504 minecraft:red_nether_bricks
setblock 351 142 503 minecraft:red_nether_bricks
fill 351 142 504 351 145 504 minecraft:pink_terracotta
fill 352 142 503 352 145 503 minecraft:pink_terracotta
setblock 355 142 504 minecraft:red_nether_bricks
fill 368 142 473 368 142 475 minecraft:pink_terracotta
setblock 368 142 476 minecraft:red_nether_bricks
fill 368 142 477 368 144 478 minecraft:pink_terracotta
setblock 369 142 470 minecraft:red_nether_bricks
fill 369 142 471 369 145 471 minecraft:pink_terracotta
setblock 369 142 475 minecraft:red_nether_bricks
fill 369 142 476 369 145 476 minecraft:pink_terracotta
setblock 369 142 480 minecraft:red_nether_bricks
fill 369 142 481 369 144 482 minecraft:pink_terracotta
setblock 369 142 495 minecraft:red_nether_bricks
fill 369 142 496 369 144 497 minecraft:pink_terracotta
setblock 370 142 469 minecraft:red_nether_bricks
fill 370 142 470 370 145 470 minecraft:pink_terracotta
setblock 370 142 474 minecraft:red_nether_bricks
fill 370 142 475 370 145 475 minecraft:pink_terracotta
setblock 370 142 479 minecraft:red_nether_bricks
fill 370 142 480 370 145 480 minecraft:pink_terracotta
setblock 370 142 484 minecraft:red_nether_bricks
fill 370 142 485 370 145 485 minecraft:pink_terracotta
setblock 370 142 489 minecraft:red_nether_bricks
fill 370 142 490 370 145 490 minecraft:pink_terracotta
setblock 370 142 494 minecraft:red_nether_bricks
fill 370 142 495 370 145 495 minecraft:pink_terracotta
setblock 370 142 499 minecraft:red_nether_bricks
fill 370 142 500 370 144 501 minecraft:pink_terracotta
fill 330 143 464 330 143 467 minecraft:pink_terracotta
setblock 330 143 468 minecraft:red_nether_bricks
fill 330 143 469 330 146 469 minecraft:pink_terracotta
setblock 330 143 473 minecraft:red_nether_bricks
fill 330 143 474 330 146 474 minecraft:pink_terracotta
setblock 330 143 478 minecraft:red_nether_bricks
fill 330 143 479 330 146 479 minecraft:pink_terracotta
setblock 330 143 483 minecraft:red_nether_bricks
fill 330 143 484 330 146 484 minecraft:pink_terracotta
setblock 330 143 488 minecraft:white_concrete
setblock 330 143 493 minecraft:red_nether_bricks
fill 330 143 494 330 146 494 minecraft:pink_terracotta
setblock 330 143 498 minecraft:red_nether_bricks
fill 330 143 499 330 146 499 minecraft:pink_terracotta
setblock 330 143 503 minecraft:red_nether_bricks
fill 330 143 504 330 146 504 minecraft:pink_terracotta
setblock 331 143 467 minecraft:red_nether_bricks
fill 331 143 468 331 146 468 minecraft:pink_terracotta
setblock 331 143 472 minecraft:red_nether_bricks
fill 331 143 473 331 146 473 minecraft:pink_terracotta
setblock 331 143 477 minecraft:red_nether_bricks
fill 331 143 478 331 146 478 minecraft:pink_terracotta
setblock 331 143 481 minecraft:pink_terracotta
setblock 331 143 497 minecraft:red_nether_bricks
fill 331 143 498 331 146 498 minecraft:pink_terracotta
setblock 331 143 501 minecraft:pink_terracotta
setblock 331 143 502 minecraft:red_nether_bricks
fill 331 143 503 333 144 503 minecraft:pink_terracotta
setblock 332 143 471 minecraft:red_nether_bricks
fill 332 143 472 332 146 472 minecraft:pink_terracotta
setblock 332 143 476 minecraft:red_nether_bricks
fill 332 143 477 332 146 477 minecraft:pink_terracotta
setblock 333 143 465 minecraft:red_nether_bricks
setblock 333 143 504 minecraft:pink_terracotta
setblock 334 143 464 minecraft:red_nether_bricks
setblock 334 143 504 minecraft:red_nether_bricks
fill 335 143 464 335 146 464 minecraft:pink_terracotta
fill 335 143 504 335 146 504 minecraft:pink_terracotta
fill 337 143 504 337 144 504 minecraft:pink_terracotta
setblock 342 143 464 minecraft:white_concrete
setblock 343 143 504 minecraft:pink_terracotta
setblock 344 143 504 minecraft:red_nether_bricks
fill 345 143 504 345 146 504 minecraft:pink_terracotta
fill 346 143 503 347 145 503 minecraft:pink_terracotta
fill 348 143 502 350 143 502 minecraft:pink_terracotta
setblock 349 143 503 minecraft:pink_terracotta
setblock 349 143 504 minecraft:red_nether_bricks
setblock 350 143 503 minecraft:red_nether_bricks
fill 350 143 504 350 146 504 minecraft:pink_terracotta
setblock 351 143 502 minecraft:red_nether_bricks
fill 351 143 503 351 146 503 minecraft:pink_terracotta
fill 352 143 502 352 146 502 minecraft:pink_terracotta
setblock 354 143 503 minecraft:pink_terracotta
setblock 354 143 504 minecraft:red_nether_bricks
fill 355 143 504 355 146 504 minecraft:pink_terracotta
setblock 358 143 504 minecraft:white_concrete
setblock 367 143 464 minecraft:white_concrete
fill 368 143 472 368 143 474 minecraft:pink_terracotta
setblock 368 143 475 minecraft:red_nether_bricks
fill 368 143 476 368 146 476 minecraft:pink_terracotta
setblock 368 143 479 minecraft:pink_terracotta
setblock 368 143 480 minecraft:red_nether_bricks
setblock 369 143 469 minecraft:red_nether_bricks
fill 369 143 470 369 146 470 minecraft:pink_terracotta
setblock 369 143 474 minecraft:red_nether_bricks
fill 369 143 475 369 146 475 minecraft:pink_terracotta
setblock 369 143 479 minecraft:red_nether_bricks
fill 369 143 480 369 146 480 minecraft:pink_terracotta
setblock 369 143 483 minecraft:pink_terracotta
setblock 369 143 484 minecraft:red_nether_bricks
setblock 369 143 494 minecraft:red_nether_bricks
fill 369 143 495 369 146 495 minecraft:pink_terracotta
setblock 369 143 498 minecraft:pink_terracotta
setblock 369 143 499 minecraft:red_nether_bricks
fill 370 143 464 370 145 465 minecraft:pink_terracotta
setblock 370 143 468 minecraft:red_nether_bricks
fill 370 143 469 370 146 469 minecraft:pink_terracotta
setblock 370 143 473 minecraft:red_nether_bricks
fill 370 143 474 370 146 474 minecraft:pink_terracotta
setblock 370 143 478 minecraft:red_nether_bricks
fill 370 143 479 370 146 479 minecraft:pink_terracotta
setblock 370 143 483 minecraft:red_nether_bricks
fill 370 143 484 370 146 484 minecraft:pink_terracotta
setblock 370 143 488 minecraft:red_nether_bricks
fill 370 143 489 370 146 489 minecraft:pink_terracotta
setblock 370 143 493 minecraft:red_nether_bricks
fill 370 143 494 370 146 494 minecraft:pink_terracotta
setblock 370 143 498 minecraft:red_nether_bricks
fill 370 143 499 370 146 499 minecraft:pink_terracotta
setblock 370 143 502 minecraft:pink_terracotta
setblock 370 143 503 minecraft:red_nether_bricks
fill 330 144 464 330 144 466 minecraft:pink_terracotta
setblock 330 144 467 minecraft:red_nether_bricks
fill 330 144 468 330 147 468 minecraft:pink_terracotta
setblock 330 144 472 minecraft:red_nether_bricks
fill 330 144 473 330 147 473 minecraft:pink_terracotta
setblock 330 144 477 minecraft:red_nether_bricks
fill 330 144 478 330 147 478 minecraft:pink_terracotta
setblock 330 144 482 minecraft:red_nether_bricks
fill 330 144 483 330 147 483 minecraft:pink_terracotta
fill 330 144 485 330 145 485 minecraft:pink_terracotta
setblock 330 144 492 minecraft:red_nether_bricks
fill 330 144 493 330 147 493 minecraft:pink_terracotta
setblock 330 144 497 minecraft:red_nether_bricks
fill 330 144 498 330 147 498 minecraft:pink_terracotta
setblock 330 144 501 minecraft:pink_terracotta
setblock 330 144 502 minecraft:red_nether_bricks
fill 330 144 503 330 147 503 minecraft:pink_terracotta
setblock 331 144 466 minecraft:red_nether_bricks
fill 331 144 467 331 147 467 minecraft:pink_terracotta
setblock 331 144 471 minecraft:red_nether_bricks
fill 331 144 472 331 147 472 minecraft:pink_terracotta
setblock 331 144 476 minecraft:red_nether_bricks
fill 331 144 477 331 147 477 minecraft:pink_terracotta
setblock 331 144 481 minecraft:red_nether_bricks
setblock 331 144 496 minecraft:red_nether_bricks
fill 331 144 497 331 147 497 minecraft:pink_terracotta
setblock 331 144 501 minecraft:red_nether_bricks
fill 331 144 502 331 147 502 minecraft:pink_terracotta
setblock 332 144 465 minecraft:red_nether_bricks
setblock 332 144 470 minecraft:red_nether_bricks
fill 332 144 471 332 146 471 minecraft:pink_terracotta
setblock 332 144 475 minecraft:red_nether_bricks
fill 332 144 476 332 147 476 minecraft:pink_terracotta
setblock 332 144 479 minecraft:pink_terracotta
setblock 332 144 499 minecraft:pink_terracotta
setblock 333 144 464 minecraft:red_nether_bricks
fill 333 144 465 333 147 465 minecraft:pink_terracotta
setblock 333 144 504 minecraft:red_nether_bricks
fill 334 144 464 334 147 464 minecraft:pink_terracotta
setblock 334 144 503 minecraft:red_nether_bricks
fill 334 144 504 334 147 504 minecraft:pink_terracotta
fill 335 144 503 335 147 503 minecraft:pink_terracotta
setblock 338 144 504 minecraft:red_nether_bricks
fill 339 144 504 342 144 504 minecraft:pink_terracotta
setblock 343 144 504 minecraft:red_nether_bricks
setblock 344 144 503 minecraft:red_nether_bricks
fill 344 144 504 344 147 504 minecraft:pink_terracotta
fill 345 144 503 345 147 503 minecraft:pink_terracotta
fill 346 144 502 349 144 502 minecraft:pink_terracotta
setblock 348 144 464 minecraft:red_nether_bricks
setblock 348 144 504 minecraft:red_nether_bricks
fill 349 144 464 350 146 464 minecraft:pink_terracotta
fill 349 144 501 350 144 501 minecraft:pink_terracotta
setblock 349 144 503 minecraft:red_nether_bricks
fill 349 144 504 349 147 504 minecraft:pink_terracotta
setblock 350 144 502 minecraft:red_nether_bricks
fill 350 144 503 350 147 503 minecraft:pink_terracotta
setblock 351 144 501 minecraft:red_nether_bricks
fill 351 144 502 351 147 502 minecraft:pink_terracotta
fill 353 144 502 353 145 502 minecraft:pink_terracotta
setblock 353 144 504 minecraft:red_nether_bricks
setblock 354 144 503 minecraft:red_nether_bricks
fill 354 144 504 354 147 504 minecraft:pink_terracotta
fill 355 144 464 355 145 464 minecraft:white_concrete
fill 355 144 491 355 145 492 minecraft:red_concrete
setblock 361 144 464 minecraft:white_concrete
setblock 364 144 504 minecraft:white_concrete
fill 366 144 479 367 144 481 minecraft:pink_concrete
fill 367 144 476 367 146 477 minecraft:pink_terracotta
fill 368 144 471 368 144 473 minecraft:pink_terracotta
setblock 368 144 474 minecraft:red_nether_bricks
fill 368 144 475 368 147 475 minecraft:pink_terracotta
setblock 368 144 479 minecraft:red_nether_bricks
fill 368 144 480 368 145 482 minecraft:pink_terracotta
fill 369 144 464 369 147 464 minecraft:pink_terracotta
setblock 369 144 468 minecraft:red_nether_bricks
fill 369 144 469 369 147 469 minecraft:pink_terracotta
setblock 369 144 473 minecraft:red_nether_bricks
fill 369 144 474 369 147 474 minecraft:pink_terracotta
setblock 369 144 478 minecraft:red_nether_bricks
fill 369 144 479 369 147 479 minecraft:pink_terracotta
setblock 369 144 483 minecraft:red_nether_bricks
fill 369 144 484 369 146 485 minecraft:pink_terracotta
setblock 369 144 493 minecraft:red_nether_bricks
fill 369 144 494 369 147 494 minecraft:pink_terracotta
setblock 369 144 498 minecraft:red_nether_bricks
fill 369 144 499 369 146 500 minecraft:pink_terracotta
fill 369 144 504 370 146 504 minecraft:pink_terracotta
setblock 370 144 467 minecraft:red_nether_bricks
fill 370 144 468 370 147 468 minecraft:pink_terracotta
setblock 370 144 472 minecraft:red_nether_bricks
fill 370 144 473 370 147 473 minecraft:pink_terracotta
setblock 370 144 477 minecraft:red_nether_bricks
fill 370 144 478 370 147 478 minecraft:pink_terracotta
setblock 370 144 482 minecraft:red_nether_bricks
fill 370 144 483 370 147 483 minecraft:pink_terracotta
setblock 370 144 487 minecraft:red_nether_bricks
fill 370 144 488 370 147 488 minecraft:pink_terracotta
setblock 370 144 492 minecraft:red_nether_bricks
fill 370 144 493 370 147 493 minecraft:pink_terracotta
setblock 370 144 497 minecraft:red_nether_bricks
fill 370 144 498 370 147 498 minecraft:pink_terracotta
setblock 370 144 502 minecraft:red_nether_bricks
fill 370 144 503 370 147 503 minecraft:pink_terracotta
fill 330 145 464 330 145 465 minecraft:pink_terracotta
setblock 330 145 466 minecraft:red_nether_bricks
fill 330 145 467 330 148 467 minecraft:pink_terracotta
setblock 330 145 471 minecraft:red_nether_bricks
fill 330 145 472 330 148 472 minecraft:pink_terracotta
setblock 330 145 476 minecraft:red_nether_bricks
fill 330 145 477 330 148 477 minecraft:pink_terracotta
setblock 330 145 481 minecraft:red_nether_bricks
fill 330 145 482 331 147 482 minecraft:pink_terracotta
setblock 330 145 486 minecraft:red_nether_bricks
setblock 330 145 491 minecraft:red_nether_bricks
fill 330 145 492 330 148 492 minecraft:pink_terracotta
setblock 330 145 496 minecraft:red_nether_bricks
fill 330 145 497 330 148 497 minecraft:pink_terracotta
setblock 330 145 500 minecraft:pink_terracotta
setblock 330 145 501 minecraft:red_nether_bricks
fill 330 145 502 330 148 502 minecraft:pink_terracotta
setblock 331 145 465 minecraft:red_nether_bricks
fill 331 145 466 331 148 466 minecraft:pink_terracotta
setblock 331 145 470 minecraft:red_nether_bricks
fill 331 145 471 331 148 471 minecraft:pink_terracotta
setblock 331 145 475 minecraft:red_nether_bricks
fill 331 145 476 331 148 476 minecraft:pink_terracotta
setblock 331 145 480 minecraft:red_nether_bricks
fill 331 145 481 331 148 481 minecraft:pink_terracotta
setblock 331 145 495 minecraft:red_nether_bricks
fill 331 145 496 331 148 496 minecraft:pink_terracotta
setblock 331 145 500 minecraft:red_nether_bricks
fill 331 145 501 332 147 501 minecraft:pink_terracotta
fill 331 145 503 332 145 503 minecraft:pink_terracotta
setblock 332 145 464 minecraft:red_nether_bricks
fill 332 145 465 332 148 465 minecraft:pink_terracotta
setblock 332 145 466 minecraft:light[level=12]
setblock 332 145 470 minecraft:pink_terracotta
setblock 332 145 474 minecraft:red_nether_bricks
fill 332 145 475 332 148 475 minecraft:pink_terracotta
setblock 332 145 479 minecraft:red_nether_bricks
setblock 332 145 482 minecraft:light[level=12]
setblock 332 145 490 minecraft:light[level=12]
setblock 332 145 498 minecraft:pink_terracotta
setblock 332 145 499 minecraft:red_nether_bricks
fill 332 145 500 332 148 500 minecraft:pink_terracotta
fill 332 145 502 333 145 502 minecraft:pink_terracotta
setblock 332 145 504 minecraft:red_nether_bricks
fill 333 145 464 333 148 464 minecraft:pink_terracotta
setblock 333 145 503 minecraft:red_nether_bricks
fill 333 145 504 333 148 504 minecraft:pink_terracotta
fill 334 145 465 334 146 465 minecraft:pink_terracotta
fill 334 145 503 334 148 503 minecraft:pink_terracotta
fill 336 145 503 337 145 503 minecraft:pink_terracotta
setblock 337 145 464 minecraft:red_nether_bricks
setblock 337 145 504 minecraft:red_nether_bricks
fill 338 145 504 341 145 504 minecraft:pink_terracotta
setblock 340 145 466 minecraft:light[level=12]
setblock 340 145 474 minecraft:light[level=12]
setblock 340 145 482 minecraft:light[level=12]
setblock 340 145 490 minecraft:light[level=12]
setblock 340 145 498 minecraft:light[level=12]
fill 341 145 503 342 145 503 minecraft:pink_terracotta
setblock 342 145 504 minecraft:red_nether_bricks
setblock 343 145 503 minecraft:red_nether_bricks
fill 343 145 504 343 148 504 minecraft:pink_terracotta
setblock 344 145 502 minecraft:red_nether_bricks
fill 344 145 503 344 148 503 minecraft:pink_terracotta
fill 345 145 502 348 145 502 minecraft:pink_terracotta
setblock 346 145 464 minecraft:pink_terracotta
fill 346 145 501 349 145 501 minecraft:pink_terracotta
setblock 347 145 464 minecraft:red_nether_bricks
setblock 347 145 504 minecraft:red_nether_bricks
fill 348 145 464 348 148 464 minecraft:pink_terracotta
setblock 348 145 466 minecraft:light[level=12]
setblock 348 145 474 minecraft:light[level=12]
setblock 348 145 482 minecraft:light[level=12]
setblock 348 145 490 minecraft:light[level=12]
setblock 348 145 498 minecraft:light[level=12]
setblock 348 145 503 minecraft:red_nether_bricks
fill 348 145 504 348 148 504 minecraft:pink_terracotta
setblock 349 145 502 minecraft:red_nether_bricks
fill 349 145 503 349 148 503 minecraft:pink_terracotta
setblock 350 145 501 minecraft:red_nether_bricks
fill 350 145 502 350 148 502 minecraft:pink_terracotta
setblock 351 145 464 minecraft:pink_terracotta
fill 351 145 501 352 147 501 minecraft:pink_terracotta
setblock 352 145 504 minecraft:red_nether_bricks
setblock 353 145 503 minecraft:red_nether_bricks
fill 353 145 504 353 148 504 minecraft:pink_terracotta
fill 354 145 503 354 148 503 minecraft:pink_terracotta
setblock 356 145 466 minecraft:light[level=12]
setblock 356 145 474 minecraft:light[level=12]
setblock 356 145 482 minecraft:light[level=12]
setblock 356 145 490 minecraft:light[level=12]
setblock 356 145 498 minecraft:light[level=12]
setblock 356 145 504 minecraft:pink_terracotta
setblock 364 145 466 minecraft:light[level=12]
setblock 364 145 474 minecraft:light[level=12]
setblock 364 145 482 minecraft:light[level=12]
setblock 364 145 490 minecraft:light[level=12]
setblock 364 145 498 minecraft:light[level=12]
fill 366 145 479 366 145 481 minecraft:pink_concrete
setblock 367 145 464 minecraft:red_nether_bricks
setblock 367 145 474 minecraft:red_nether_bricks
fill 367 145 475 367 148 475 minecraft:pink_terracotta
setblock 367 145 478 minecraft:pink_terracotta
setblock 367 145 479 minecraft:red_nether_bricks
fill 367 145 480 367 148 480 minecraft:pink_terracotta
setblock 367 145 481 minecraft:pink_concrete
setblock 367 145 504 minecraft:red_nether_bricks
fill 368 145 464 368 148 464 minecraft:pink_terracotta
fill 368 145 471 368 145 472 minecraft:pink_terracotta
setblock 368 145 473 minecraft:red_nether_bricks
fill 368 145 474 368 148 474 minecraft:pink_terracotta
setblock 368 145 477 minecraft:pink_terracotta
setblock 368 145 478 minecraft:red_nether_bricks
fill 368 145 479 368 148 479 minecraft:pink_terracotta
setblock 368 145 483 minecraft:red_nether_bricks
fill 368 145 504 368 148 504 minecraft:pink_terracotta
setblock 369 145 467 minecraft:red_nether_bricks
fill 369 145 468 369 148 468 minecraft:pink_terracotta
setblock 369 145 472 minecraft:red_nether_bricks
fill 369 145 473 369 148 473 minecraft:pink_terracotta
setblock 369 145 477 minecraft:red_nether_bricks
fill 369 145 478 369 148 478 minecraft:pink_terracotta
setblock 369 145 481 minecraft:pink_terracotta
setblock 369 145 482 minecraft:red_nether_bricks
fill 369 145 483 369 148 483 minecraft:pink_terracotta
setblock 369 145 486 minecraft:pink_terracotta
setblock 369 145 492 minecraft:red_nether_bricks
fill 369 145 493 369 147 493 minecraft:pink_terracotta
setblock 369 145 496 minecraft:pink_terracotta
setblock 369 145 497 minecraft:red_nether_bricks
fill 369 145 498 369 148 498 minecraft:pink_terracotta
setblock 369 145 501 minecraft:pink_terracotta
setblock 369 145 502 minecraft:red_nether_bricks
setblock 370 145 466 minecraft:red_nether_bricks
fill 370 145 467 370 148 467 minecraft:pink_terracotta
setblock 370 145 471 minecraft:red_nether_bricks
fill 370 145 472 370 148 472 minecraft:pink_terracotta
setblock 370 145 476 minecraft:red_nether_bricks
fill 370 145 477 370 148 477 minecraft:pink_terracotta
setblock 370 145 481 minecraft:red_nether_bricks
fill 370 145 482 370 148 482 minecraft:pink_terracotta
setblock 370 145 486 minecraft:red_nether_bricks
fill 370 145 487 370 148 487 minecraft:pink_terracotta
setblock 370 145 491 minecraft:red_nether_bricks
fill 370 145 492 370 148 492 minecraft:pink_terracotta
setblock 370 145 496 minecraft:red_nether_bricks
fill 370 145 497 370 148 497 minecraft:pink_terracotta
schedule function dropper:buildpart/115_4 1t
