fill 535 112 264 536 113 265 minecraft:black_concrete
fill 535 112 266 536 112 267 minecraft:white_concrete
fill 535 112 268 536 112 269 minecraft:black_concrete
setblock 536 112 244 minecraft:black_concrete
setblock 536 112 250 minecraft:white_concrete
fill 537 112 229 538 112 229 minecraft:white_concrete
fill 537 112 230 538 112 231 minecraft:black_concrete
fill 537 112 232 538 113 233 minecraft:white_concrete
fill 537 112 234 538 113 235 minecraft:black_concrete
fill 537 112 236 538 113 237 minecraft:white_concrete
fill 537 112 238 538 113 239 minecraft:black_concrete
fill 537 112 240 538 113 241 minecraft:white_concrete
fill 537 112 242 538 113 243 minecraft:black_concrete
fill 537 112 244 538 112 244 minecraft:white_concrete
fill 537 112 250 538 112 251 minecraft:black_concrete
fill 537 112 252 538 113 253 minecraft:white_concrete
fill 537 112 254 538 113 255 minecraft:black_concrete
fill 537 112 256 538 113 257 minecraft:white_concrete
fill 537 112 258 538 113 259 minecraft:black_concrete
fill 537 112 260 538 113 261 minecraft:white_concrete
fill 537 112 262 538 113 263 minecraft:black_concrete
fill 537 112 264 538 113 265 minecraft:white_concrete
fill 537 112 266 538 112 267 minecraft:black_concrete
fill 537 112 268 538 112 269 minecraft:white_concrete
setblock 538 112 245 minecraft:white_concrete
setblock 538 112 246 minecraft:black_concrete
fill 538 112 248 538 112 249 minecraft:white_concrete
fill 539 112 229 540 112 229 minecraft:black_concrete
fill 539 112 230 540 112 231 minecraft:white_concrete
fill 539 112 232 540 113 233 minecraft:black_concrete
fill 539 112 234 540 113 235 minecraft:white_concrete
fill 539 112 236 540 113 237 minecraft:black_concrete
fill 539 112 238 540 113 239 minecraft:white_concrete
fill 539 112 240 540 113 241 minecraft:black_concrete
fill 539 112 242 540 113 243 minecraft:white_concrete
fill 539 112 244 540 113 245 minecraft:black_concrete
fill 539 112 246 540 112 247 minecraft:white_concrete
fill 539 112 248 540 112 249 minecraft:black_concrete
fill 539 112 250 540 113 251 minecraft:white_concrete
fill 539 112 252 540 113 253 minecraft:black_concrete
fill 539 112 254 540 113 255 minecraft:white_concrete
fill 539 112 256 540 113 257 minecraft:black_concrete
fill 539 112 258 540 113 259 minecraft:white_concrete
fill 539 112 260 540 113 261 minecraft:black_concrete
fill 539 112 262 540 113 263 minecraft:white_concrete
fill 539 112 264 540 113 265 minecraft:black_concrete
fill 539 112 266 540 112 267 minecraft:white_concrete
fill 539 112 268 540 112 269 minecraft:black_concrete
fill 541 112 229 542 112 229 minecraft:white_concrete
fill 541 112 230 542 112 231 minecraft:black_concrete
fill 541 112 232 542 113 233 minecraft:white_concrete
fill 541 112 234 542 113 235 minecraft:black_concrete
fill 541 112 236 542 113 237 minecraft:white_concrete
fill 541 112 238 542 113 239 minecraft:black_concrete
fill 541 112 240 542 113 241 minecraft:white_concrete
fill 541 112 242 542 113 243 minecraft:black_concrete
fill 541 112 244 542 113 245 minecraft:white_concrete
fill 541 112 246 542 113 247 minecraft:black_concrete
fill 541 112 248 542 113 249 minecraft:white_concrete
fill 541 112 250 542 113 251 minecraft:black_concrete
fill 541 112 252 542 113 253 minecraft:white_concrete
fill 541 112 254 542 113 255 minecraft:black_concrete
fill 541 112 256 542 113 257 minecraft:white_concrete
fill 541 112 258 542 113 259 minecraft:black_concrete
fill 541 112 260 542 113 261 minecraft:white_concrete
fill 541 112 262 542 113 263 minecraft:black_concrete
fill 541 112 264 542 113 265 minecraft:white_concrete
fill 541 112 266 542 112 267 minecraft:black_concrete
fill 541 112 268 542 112 269 minecraft:white_concrete
setblock 541 112 270 minecraft:stone_bricks
fill 543 112 229 544 112 229 minecraft:black_concrete
fill 543 112 230 544 112 231 minecraft:white_concrete
fill 543 112 232 544 113 233 minecraft:black_concrete
fill 543 112 234 544 113 235 minecraft:white_concrete
fill 543 112 236 544 113 237 minecraft:black_concrete
fill 543 112 238 544 113 239 minecraft:white_concrete
fill 543 112 240 544 113 241 minecraft:black_concrete
fill 543 112 242 544 113 243 minecraft:white_concrete
fill 543 112 244 544 113 245 minecraft:black_concrete
fill 543 112 246 544 113 247 minecraft:white_concrete
fill 543 112 248 544 113 249 minecraft:black_concrete
fill 543 112 250 544 113 251 minecraft:white_concrete
fill 543 112 252 544 113 253 minecraft:black_concrete
fill 543 112 254 544 113 255 minecraft:white_concrete
fill 543 112 256 544 113 257 minecraft:black_concrete
fill 543 112 258 544 113 259 minecraft:white_concrete
fill 543 112 260 544 113 261 minecraft:black_concrete
fill 543 112 262 544 113 263 minecraft:white_concrete
fill 543 112 264 544 113 265 minecraft:black_concrete
fill 543 112 266 544 112 267 minecraft:white_concrete
fill 543 112 268 544 112 269 minecraft:black_concrete
fill 545 112 229 546 112 229 minecraft:white_concrete
fill 545 112 230 546 112 231 minecraft:black_concrete
fill 545 112 232 546 113 233 minecraft:white_concrete
fill 545 112 234 546 113 235 minecraft:black_concrete
fill 545 112 236 546 113 237 minecraft:white_concrete
fill 545 112 238 546 113 239 minecraft:black_concrete
fill 545 112 240 546 113 241 minecraft:white_concrete
fill 545 112 242 546 113 243 minecraft:black_concrete
fill 545 112 244 546 113 245 minecraft:white_concrete
fill 545 112 246 546 113 247 minecraft:black_concrete
fill 545 112 248 546 113 249 minecraft:white_concrete
fill 545 112 250 546 113 251 minecraft:black_concrete
fill 545 112 252 546 113 253 minecraft:white_concrete
fill 545 112 254 546 113 255 minecraft:black_concrete
fill 545 112 256 546 113 257 minecraft:white_concrete
fill 545 112 258 546 113 259 minecraft:black_concrete
fill 545 112 260 546 113 261 minecraft:white_concrete
fill 545 112 262 546 113 263 minecraft:black_concrete
fill 545 112 264 546 113 265 minecraft:white_concrete
fill 545 112 266 546 112 267 minecraft:black_concrete
fill 545 112 268 546 112 269 minecraft:white_concrete
fill 547 112 229 548 112 229 minecraft:black_concrete
fill 547 112 230 548 112 231 minecraft:white_concrete
fill 547 112 232 548 113 233 minecraft:black_concrete
fill 547 112 234 548 113 235 minecraft:white_concrete
fill 547 112 236 548 113 237 minecraft:black_concrete
fill 547 112 238 548 113 239 minecraft:white_concrete
fill 547 112 240 548 113 241 minecraft:black_concrete
fill 547 112 242 548 113 243 minecraft:white_concrete
fill 547 112 244 548 113 245 minecraft:black_concrete
fill 547 112 246 548 113 247 minecraft:white_concrete
fill 547 112 248 548 113 249 minecraft:black_concrete
fill 547 112 250 548 113 251 minecraft:white_concrete
fill 547 112 252 548 113 253 minecraft:black_concrete
fill 547 112 254 548 113 255 minecraft:white_concrete
fill 547 112 256 548 113 257 minecraft:black_concrete
fill 547 112 258 548 113 259 minecraft:white_concrete
fill 547 112 260 548 113 261 minecraft:black_concrete
fill 547 112 262 548 113 263 minecraft:white_concrete
fill 547 112 264 548 113 265 minecraft:black_concrete
fill 547 112 266 548 112 267 minecraft:white_concrete
fill 547 112 268 548 112 269 minecraft:black_concrete
fill 549 112 229 550 112 229 minecraft:white_concrete
fill 549 112 230 550 112 231 minecraft:black_concrete
fill 549 112 232 550 113 233 minecraft:white_concrete
fill 549 112 234 550 113 235 minecraft:black_concrete
fill 549 112 236 550 113 237 minecraft:white_concrete
fill 549 112 238 550 113 239 minecraft:black_concrete
fill 549 112 240 550 113 241 minecraft:white_concrete
fill 549 112 242 550 113 243 minecraft:black_concrete
fill 549 112 244 550 113 245 minecraft:white_concrete
fill 549 112 246 550 113 247 minecraft:black_concrete
fill 549 112 248 550 113 249 minecraft:white_concrete
fill 549 112 250 550 113 251 minecraft:black_concrete
fill 549 112 252 550 113 253 minecraft:white_concrete
fill 549 112 254 550 113 255 minecraft:black_concrete
fill 549 112 256 550 113 257 minecraft:white_concrete
fill 549 112 258 550 113 259 minecraft:black_concrete
fill 549 112 260 550 113 261 minecraft:white_concrete
fill 549 112 262 550 113 263 minecraft:black_concrete
fill 549 112 264 550 113 265 minecraft:white_concrete
fill 549 112 266 550 112 267 minecraft:black_concrete
fill 549 112 268 550 112 269 minecraft:white_concrete
fill 551 112 229 552 112 229 minecraft:black_concrete
fill 551 112 230 552 112 231 minecraft:white_concrete
fill 551 112 232 552 113 233 minecraft:black_concrete
fill 551 112 234 552 113 235 minecraft:white_concrete
fill 551 112 236 552 113 237 minecraft:black_concrete
fill 551 112 238 552 113 239 minecraft:white_concrete
fill 551 112 240 552 113 241 minecraft:black_concrete
fill 551 112 242 552 113 243 minecraft:white_concrete
fill 551 112 244 552 113 245 minecraft:black_concrete
fill 551 112 246 552 113 247 minecraft:white_concrete
fill 551 112 248 552 113 249 minecraft:black_concrete
fill 551 112 250 552 113 251 minecraft:white_concrete
fill 551 112 252 552 113 253 minecraft:black_concrete
fill 551 112 254 552 113 255 minecraft:white_concrete
fill 551 112 256 552 113 257 minecraft:black_concrete
fill 551 112 258 552 113 259 minecraft:white_concrete
fill 551 112 260 552 113 261 minecraft:black_concrete
fill 551 112 262 552 113 263 minecraft:white_concrete
fill 551 112 264 552 113 265 minecraft:black_concrete
fill 551 112 266 552 112 267 minecraft:white_concrete
fill 551 112 268 552 112 269 minecraft:black_concrete
fill 553 112 229 554 112 229 minecraft:white_concrete
fill 553 112 230 554 112 231 minecraft:black_concrete
fill 553 112 232 554 113 233 minecraft:white_concrete
fill 553 112 234 554 113 235 minecraft:black_concrete
fill 553 112 236 554 113 237 minecraft:white_concrete
fill 553 112 238 554 113 239 minecraft:black_concrete
fill 553 112 240 554 113 241 minecraft:white_concrete
fill 553 112 242 554 113 243 minecraft:black_concrete
fill 553 112 244 554 113 245 minecraft:white_concrete
fill 553 112 246 554 113 247 minecraft:black_concrete
fill 553 112 248 554 113 249 minecraft:white_concrete
fill 553 112 250 554 113 251 minecraft:black_concrete
fill 553 112 252 554 113 253 minecraft:white_concrete
fill 553 112 254 554 113 255 minecraft:black_concrete
fill 553 112 256 554 113 257 minecraft:white_concrete
fill 553 112 258 554 113 259 minecraft:black_concrete
fill 553 112 260 554 113 261 minecraft:white_concrete
fill 553 112 262 554 113 263 minecraft:black_concrete
fill 553 112 264 554 113 265 minecraft:white_concrete
fill 553 112 266 554 112 267 minecraft:black_concrete
fill 553 112 268 554 112 269 minecraft:white_concrete
fill 555 112 229 556 112 229 minecraft:black_concrete
fill 555 112 230 556 112 231 minecraft:white_concrete
fill 555 112 232 556 112 233 minecraft:black_concrete
fill 555 112 234 556 112 235 minecraft:white_concrete
fill 555 112 236 556 112 237 minecraft:black_concrete
fill 555 112 238 556 112 239 minecraft:white_concrete
fill 555 112 240 556 112 241 minecraft:black_concrete
fill 555 112 242 556 112 243 minecraft:white_concrete
fill 555 112 244 556 112 245 minecraft:black_concrete
fill 555 112 246 556 112 247 minecraft:white_concrete
fill 555 112 248 556 112 249 minecraft:black_concrete
fill 555 112 250 556 112 251 minecraft:white_concrete
fill 555 112 252 556 112 253 minecraft:black_concrete
fill 555 112 254 556 112 255 minecraft:white_concrete
fill 555 112 256 556 112 257 minecraft:black_concrete
fill 555 112 258 556 112 259 minecraft:white_concrete
fill 555 112 260 556 112 261 minecraft:black_concrete
fill 555 112 262 556 112 263 minecraft:white_concrete
fill 555 112 264 556 112 265 minecraft:black_concrete
fill 555 112 266 556 112 267 minecraft:white_concrete
fill 555 112 268 556 112 269 minecraft:black_concrete
fill 557 112 229 558 112 229 minecraft:white_concrete
fill 557 112 230 558 112 231 minecraft:black_concrete
fill 557 112 232 558 112 233 minecraft:white_concrete
fill 557 112 234 558 112 235 minecraft:black_concrete
fill 557 112 236 558 112 237 minecraft:white_concrete
fill 557 112 238 558 112 239 minecraft:black_concrete
fill 557 112 240 558 112 241 minecraft:white_concrete
fill 557 112 242 558 112 243 minecraft:black_concrete
fill 557 112 244 558 112 245 minecraft:white_concrete
fill 557 112 246 558 112 247 minecraft:black_concrete
fill 557 112 248 558 112 249 minecraft:white_concrete
fill 557 112 250 558 112 251 minecraft:black_concrete
fill 557 112 252 558 112 253 minecraft:white_concrete
fill 557 112 254 558 112 255 minecraft:black_concrete
fill 557 112 256 558 112 257 minecraft:white_concrete
fill 557 112 258 558 112 259 minecraft:black_concrete
fill 557 112 260 558 112 261 minecraft:white_concrete
fill 557 112 262 558 112 263 minecraft:black_concrete
fill 557 112 264 558 112 265 minecraft:white_concrete
fill 557 112 266 558 112 267 minecraft:black_concrete
fill 557 112 268 558 112 269 minecraft:white_concrete
fill 517 113 228 517 113 229 minecraft:white_concrete
fill 517 113 230 517 113 231 minecraft:black_concrete
fill 517 113 232 517 113 233 minecraft:white_concrete
fill 517 113 234 517 113 235 minecraft:black_concrete
fill 517 113 236 517 113 237 minecraft:white_concrete
fill 517 113 238 517 113 239 minecraft:black_concrete
fill 517 113 240 517 113 241 minecraft:white_concrete
fill 517 113 242 517 113 243 minecraft:black_concrete
fill 517 113 244 517 113 245 minecraft:white_concrete
fill 517 113 246 517 113 247 minecraft:black_concrete
fill 517 113 248 517 113 249 minecraft:white_concrete
fill 517 113 250 517 113 251 minecraft:black_concrete
fill 517 113 252 517 113 253 minecraft:white_concrete
fill 517 113 254 517 113 255 minecraft:black_concrete
fill 517 113 256 517 113 257 minecraft:white_concrete
fill 517 113 258 517 113 259 minecraft:black_concrete
fill 517 113 260 517 113 261 minecraft:white_concrete
fill 517 113 262 517 113 263 minecraft:black_concrete
fill 517 113 264 517 113 265 minecraft:white_concrete
fill 517 113 266 517 113 267 minecraft:black_concrete
fill 517 113 268 517 113 269 minecraft:white_concrete
fill 517 113 270 518 113 270 minecraft:black_concrete
setblock 518 113 228 minecraft:white_concrete
fill 518 113 229 520 113 269 minecraft:dark_oak_planks
fill 519 113 228 520 113 228 minecraft:black_concrete
fill 519 113 270 520 113 270 minecraft:white_concrete
fill 521 113 228 522 113 228 minecraft:white_concrete
fill 521 113 229 558 113 231 minecraft:dark_oak_planks
fill 521 113 266 522 113 266 minecraft:black_concrete
fill 521 113 267 558 113 269 minecraft:dark_oak_planks
fill 521 113 270 522 113 270 minecraft:black_concrete
fill 523 113 228 524 113 228 minecraft:black_concrete
fill 523 113 266 524 113 266 minecraft:white_concrete
fill 523 113 270 524 113 270 minecraft:white_concrete
fill 525 113 228 526 113 228 minecraft:white_concrete
fill 525 113 266 526 113 266 minecraft:black_concrete
fill 525 113 270 526 113 270 minecraft:black_concrete
fill 527 113 228 528 113 228 minecraft:black_concrete
fill 527 113 266 528 113 266 minecraft:white_concrete
fill 527 113 270 528 113 270 minecraft:white_concrete
fill 529 113 228 530 113 228 minecraft:white_concrete
fill 529 113 266 530 113 266 minecraft:black_concrete
fill 529 113 270 530 113 270 minecraft:black_concrete
fill 531 113 228 532 113 228 minecraft:black_concrete
fill 531 113 244 531 113 245 minecraft:black_concrete
fill 531 113 246 531 113 248 minecraft:spruce_planks
setblock 531 113 249 minecraft:black_concrete
fill 531 113 250 531 113 251 minecraft:white_concrete
fill 531 113 266 532 113 266 minecraft:white_concrete
fill 531 113 270 532 113 270 minecraft:white_concrete
fill 532 113 244 532 113 246 minecraft:spruce_planks
fill 532 113 248 532 113 250 minecraft:spruce_planks
setblock 532 113 251 minecraft:white_concrete
fill 533 113 228 534 113 228 minecraft:white_concrete
fill 533 113 242 533 113 243 minecraft:black_concrete
fill 533 113 244 534 113 244 minecraft:spruce_planks
fill 533 113 250 534 113 250 minecraft:spruce_planks
setblock 533 113 251 minecraft:black_concrete
fill 533 113 266 534 113 266 minecraft:black_concrete
fill 533 113 270 534 113 270 minecraft:black_concrete
setblock 534 113 242 minecraft:black_concrete
fill 534 113 243 536 113 243 minecraft:spruce_planks
fill 534 113 251 536 113 251 minecraft:spruce_planks
fill 535 113 228 536 113 228 minecraft:black_concrete
fill 535 113 242 536 113 242 minecraft:white_concrete
fill 535 113 266 536 113 266 minecraft:white_concrete
fill 535 113 270 536 113 270 minecraft:white_concrete
fill 536 113 244 538 113 244 minecraft:spruce_planks
fill 536 113 250 538 113 250 minecraft:spruce_planks
fill 537 113 228 538 113 228 minecraft:white_concrete
fill 537 113 251 538 113 251 minecraft:black_concrete
fill 537 113 266 538 113 266 minecraft:black_concrete
fill 537 113 270 538 113 270 minecraft:black_concrete
fill 538 113 245 538 113 246 minecraft:spruce_planks
fill 538 113 248 538 113 249 minecraft:spruce_planks
fill 539 113 228 540 113 228 minecraft:black_concrete
fill 539 113 246 539 113 248 minecraft:spruce_planks
fill 539 113 249 540 113 249 minecraft:black_concrete
fill 539 113 266 540 113 266 minecraft:white_concrete
fill 539 113 270 540 113 270 minecraft:white_concrete
fill 540 113 246 540 113 247 minecraft:white_concrete
setblock 540 113 248 minecraft:black_concrete
fill 541 113 228 542 113 228 minecraft:white_concrete
fill 541 113 266 542 113 266 minecraft:black_concrete
fill 541 113 270 542 113 270 minecraft:black_concrete
fill 543 113 228 544 113 228 minecraft:black_concrete
fill 543 113 266 544 113 266 minecraft:white_concrete
fill 543 113 270 544 113 270 minecraft:white_concrete
fill 545 113 228 546 113 228 minecraft:white_concrete
fill 545 113 266 546 113 266 minecraft:black_concrete
fill 545 113 270 546 113 270 minecraft:black_concrete
fill 547 113 228 548 113 228 minecraft:black_concrete
fill 547 113 266 548 113 266 minecraft:white_concrete
fill 547 113 270 548 113 270 minecraft:white_concrete
fill 549 113 228 550 113 228 minecraft:white_concrete
fill 549 113 266 550 113 266 minecraft:black_concrete
fill 549 113 270 550 113 270 minecraft:black_concrete
fill 551 113 228 552 113 228 minecraft:black_concrete
fill 551 113 266 552 113 266 minecraft:white_concrete
fill 551 113 270 552 113 270 minecraft:white_concrete
fill 553 113 228 554 113 228 minecraft:white_concrete
fill 553 113 266 554 113 266 minecraft:black_concrete
fill 553 113 270 554 113 270 minecraft:black_concrete
fill 555 113 228 556 113 228 minecraft:black_concrete
fill 555 113 232 555 113 233 minecraft:black_concrete
fill 555 113 234 555 113 235 minecraft:white_concrete
fill 555 113 236 555 113 237 minecraft:black_concrete
fill 555 113 238 555 113 239 minecraft:white_concrete
fill 555 113 240 555 113 241 minecraft:black_concrete
fill 555 113 242 555 113 243 minecraft:white_concrete
fill 555 113 244 555 113 245 minecraft:black_concrete
fill 555 113 246 555 113 247 minecraft:white_concrete
fill 555 113 248 555 113 249 minecraft:black_concrete
fill 555 113 250 555 113 251 minecraft:white_concrete
fill 555 113 252 555 113 253 minecraft:black_concrete
fill 555 113 254 555 113 255 minecraft:white_concrete
fill 555 113 256 555 113 257 minecraft:black_concrete
fill 555 113 258 555 113 259 minecraft:white_concrete
fill 555 113 260 555 113 261 minecraft:black_concrete
fill 555 113 262 555 113 263 minecraft:white_concrete
fill 555 113 264 555 113 265 minecraft:black_concrete
setblock 555 113 266 minecraft:white_concrete
fill 555 113 270 556 113 270 minecraft:white_concrete
fill 556 113 232 558 113 266 minecraft:dark_oak_planks
fill 557 113 228 558 113 228 minecraft:white_concrete
fill 557 113 270 558 113 270 minecraft:black_concrete
fill 559 113 228 559 113 229 minecraft:black_concrete
fill 559 113 230 559 113 231 minecraft:white_concrete
fill 559 113 232 559 113 233 minecraft:black_concrete
fill 559 113 234 559 113 235 minecraft:white_concrete
fill 559 113 236 559 113 237 minecraft:black_concrete
fill 559 113 238 559 113 239 minecraft:white_concrete
fill 559 113 240 559 113 241 minecraft:black_concrete
fill 559 113 242 559 113 243 minecraft:white_concrete
fill 559 113 244 559 113 245 minecraft:black_concrete
fill 559 113 246 559 113 247 minecraft:white_concrete
fill 559 113 248 559 113 249 minecraft:black_concrete
fill 559 113 250 559 113 251 minecraft:white_concrete
fill 559 113 252 559 113 253 minecraft:black_concrete
fill 559 113 254 559 113 255 minecraft:white_concrete
fill 559 113 256 559 113 257 minecraft:black_concrete
fill 559 113 258 559 113 259 minecraft:white_concrete
fill 559 113 260 559 113 261 minecraft:black_concrete
fill 559 113 262 559 113 263 minecraft:white_concrete
fill 559 113 264 559 113 265 minecraft:black_concrete
fill 559 113 266 559 113 267 minecraft:white_concrete
fill 559 113 268 559 113 269 minecraft:black_concrete
setblock 559 113 270 minecraft:white_concrete
fill 517 114 228 517 115 229 minecraft:purple_terracotta
setblock 517 114 230 minecraft:magenta_terracotta
fill 517 114 231 517 115 233 minecraft:purple_terracotta
setblock 517 114 234 minecraft:magenta_terracotta
fill 517 114 235 517 115 237 minecraft:purple_terracotta
setblock 517 114 238 minecraft:magenta_terracotta
fill 517 114 239 517 115 241 minecraft:purple_terracotta
setblock 517 114 242 minecraft:magenta_terracotta
fill 517 114 243 517 115 245 minecraft:purple_terracotta
setblock 517 114 246 minecraft:magenta_terracotta
fill 517 114 247 517 115 249 minecraft:purple_terracotta
setblock 517 114 250 minecraft:magenta_terracotta
fill 517 114 251 517 115 253 minecraft:purple_terracotta
setblock 517 114 254 minecraft:magenta_terracotta
fill 517 114 255 517 115 257 minecraft:purple_terracotta
setblock 517 114 258 minecraft:magenta_terracotta
fill 517 114 259 517 115 261 minecraft:purple_terracotta
setblock 517 114 262 minecraft:magenta_terracotta
fill 517 114 263 517 115 265 minecraft:purple_terracotta
setblock 517 114 266 minecraft:magenta_terracotta
fill 517 114 267 517 115 269 minecraft:purple_terracotta
setblock 517 114 270 minecraft:magenta_terracotta
fill 518 114 228 518 207 228 minecraft:purple_terracotta
fill 518 114 270 518 207 270 minecraft:purple_terracotta
setblock 519 114 228 minecraft:magenta_terracotta
setblock 519 114 270 minecraft:magenta_terracotta
fill 520 114 228 522 115 228 minecraft:purple_terracotta
fill 520 114 270 522 115 270 minecraft:purple_terracotta
setblock 523 114 228 minecraft:magenta_terracotta
setblock 523 114 270 minecraft:magenta_terracotta
fill 524 114 228 526 115 228 minecraft:purple_terracotta
fill 524 114 270 526 115 270 minecraft:purple_terracotta
setblock 527 114 228 minecraft:magenta_terracotta
setblock 527 114 270 minecraft:magenta_terracotta
fill 528 114 228 530 115 228 minecraft:purple_terracotta
fill 528 114 270 530 115 270 minecraft:purple_terracotta
setblock 531 114 228 minecraft:magenta_terracotta
setblock 531 114 270 minecraft:magenta_terracotta
fill 532 114 228 534 115 228 minecraft:purple_terracotta
fill 532 114 270 534 115 270 minecraft:purple_terracotta
setblock 535 114 228 minecraft:magenta_terracotta
setblock 535 114 270 minecraft:magenta_terracotta
fill 536 114 228 538 115 228 minecraft:purple_terracotta
fill 536 114 270 538 115 270 minecraft:purple_terracotta
setblock 539 114 228 minecraft:magenta_terracotta
setblock 539 114 270 minecraft:magenta_terracotta
fill 540 114 228 542 115 228 minecraft:purple_terracotta
fill 540 114 270 542 115 270 minecraft:purple_terracotta
setblock 543 114 228 minecraft:magenta_terracotta
setblock 543 114 270 minecraft:magenta_terracotta
fill 544 114 228 546 115 228 minecraft:purple_terracotta
fill 544 114 270 546 115 270 minecraft:purple_terracotta
setblock 547 114 228 minecraft:magenta_terracotta
setblock 547 114 270 minecraft:magenta_terracotta
fill 548 114 228 550 115 228 minecraft:purple_terracotta
fill 548 114 270 550 115 270 minecraft:purple_terracotta
setblock 551 114 228 minecraft:magenta_terracotta
setblock 551 114 270 minecraft:magenta_terracotta
fill 552 114 228 554 115 228 minecraft:purple_terracotta
fill 552 114 270 554 115 270 minecraft:purple_terracotta
setblock 555 114 228 minecraft:magenta_terracotta
setblock 555 114 270 minecraft:magenta_terracotta
fill 556 114 228 558 115 228 minecraft:purple_terracotta
fill 556 114 270 558 115 270 minecraft:purple_terracotta
setblock 559 114 228 minecraft:magenta_terracotta
fill 559 114 229 559 207 229 minecraft:purple_terracotta
setblock 559 114 230 minecraft:magenta_terracotta
fill 559 114 231 559 115 233 minecraft:purple_terracotta
setblock 559 114 234 minecraft:magenta_terracotta
fill 559 114 235 559 115 237 minecraft:purple_terracotta
setblock 559 114 238 minecraft:magenta_terracotta
fill 559 114 239 559 114 241 minecraft:purple_terracotta
setblock 559 114 242 minecraft:magenta_terracotta
fill 559 114 243 559 115 245 minecraft:purple_terracotta
setblock 559 114 246 minecraft:magenta_terracotta
fill 559 114 247 559 115 249 minecraft:purple_terracotta
setblock 559 114 250 minecraft:magenta_terracotta
fill 559 114 251 559 115 253 minecraft:purple_terracotta
setblock 559 114 254 minecraft:magenta_terracotta
fill 559 114 255 559 115 257 minecraft:purple_terracotta
setblock 559 114 258 minecraft:magenta_terracotta
fill 559 114 259 559 115 261 minecraft:purple_terracotta
setblock 559 114 262 minecraft:magenta_terracotta
fill 559 114 263 559 115 265 minecraft:purple_terracotta
setblock 559 114 266 minecraft:magenta_terracotta
fill 559 114 267 559 115 269 minecraft:purple_terracotta
setblock 559 114 270 minecraft:magenta_terracotta
fill 517 115 230 517 117 230 minecraft:purple_terracotta
fill 517 115 234 517 117 234 minecraft:purple_terracotta
fill 517 115 238 517 117 238 minecraft:purple_terracotta
fill 517 115 242 517 117 242 minecraft:purple_terracotta
fill 517 115 246 517 117 246 minecraft:purple_terracotta
fill 517 115 250 517 117 250 minecraft:purple_terracotta
fill 517 115 254 517 117 254 minecraft:purple_terracotta
fill 517 115 258 517 117 258 minecraft:purple_terracotta
fill 517 115 262 517 117 262 minecraft:purple_terracotta
fill 517 115 266 517 117 266 minecraft:purple_terracotta
setblock 517 115 270 minecraft:purple_terracotta
fill 519 115 228 519 117 228 minecraft:purple_terracotta
fill 519 115 270 519 117 270 minecraft:purple_terracotta
setblock 520 115 231 minecraft:light[level=12]
setblock 520 115 238 minecraft:light[level=12]
setblock 520 115 245 minecraft:light[level=12]
setblock 520 115 252 minecraft:light[level=12]
setblock 520 115 259 minecraft:light[level=12]
setblock 520 115 266 minecraft:light[level=12]
fill 523 115 228 523 117 228 minecraft:purple_terracotta
fill 523 115 270 523 117 270 minecraft:purple_terracotta
fill 527 115 228 527 117 228 minecraft:purple_terracotta
setblock 527 115 231 minecraft:light[level=12]
setblock 527 115 238 minecraft:light[level=12]
setblock 527 115 245 minecraft:light[level=12]
setblock 527 115 252 minecraft:light[level=12]
setblock 527 115 259 minecraft:light[level=12]
setblock 527 115 266 minecraft:light[level=12]
fill 527 115 270 527 117 270 minecraft:purple_terracotta
fill 529 115 230 530 115 230 minecraft:spruce_planks
fill 531 115 228 531 117 228 minecraft:purple_terracotta
fill 531 115 270 531 117 270 minecraft:purple_terracotta
setblock 534 115 231 minecraft:light[level=12]
setblock 534 115 238 minecraft:light[level=12]
setblock 534 115 252 minecraft:light[level=12]
setblock 534 115 259 minecraft:light[level=12]
setblock 534 115 266 minecraft:light[level=12]
fill 535 115 228 535 117 228 minecraft:purple_terracotta
fill 535 115 270 535 117 270 minecraft:purple_terracotta
fill 539 115 228 539 117 228 minecraft:purple_terracotta
fill 539 115 270 539 117 270 minecraft:purple_terracotta
setblock 541 115 231 minecraft:light[level=12]
setblock 541 115 238 minecraft:light[level=12]
setblock 541 115 245 minecraft:light[level=12]
setblock 541 115 252 minecraft:light[level=12]
setblock 541 115 259 minecraft:light[level=12]
setblock 541 115 266 minecraft:light[level=12]
fill 543 115 228 543 117 228 minecraft:purple_terracotta
fill 543 115 270 543 117 270 minecraft:purple_terracotta
fill 547 115 228 547 117 228 minecraft:purple_terracotta
fill 547 115 270 547 117 270 minecraft:purple_terracotta
setblock 548 115 231 minecraft:light[level=12]
setblock 548 115 238 minecraft:light[level=12]
setblock 548 115 245 minecraft:light[level=12]
setblock 548 115 252 minecraft:light[level=12]
setblock 548 115 259 minecraft:light[level=12]
setblock 548 115 266 minecraft:light[level=12]
fill 551 115 228 551 117 228 minecraft:purple_terracotta
fill 551 115 270 551 117 270 minecraft:purple_terracotta
fill 555 115 228 555 117 228 minecraft:purple_terracotta
setblock 555 115 231 minecraft:light[level=12]
setblock 555 115 238 minecraft:light[level=12]
setblock 555 115 245 minecraft:light[level=12]
setblock 555 115 252 minecraft:light[level=12]
setblock 555 115 259 minecraft:light[level=12]
setblock 555 115 266 minecraft:light[level=12]
fill 555 115 270 555 117 270 minecraft:purple_terracotta
setblock 559 115 228 minecraft:purple_terracotta
fill 559 115 230 559 117 230 minecraft:purple_terracotta
fill 559 115 234 559 117 234 minecraft:purple_terracotta
fill 559 115 238 559 117 239 minecraft:purple_terracotta
setblock 559 115 240 minecraft:black_terracotta
fill 559 115 241 559 117 242 minecraft:purple_terracotta
fill 559 115 246 559 117 246 minecraft:purple_terracotta
fill 559 115 250 559 117 250 minecraft:purple_terracotta
fill 559 115 254 559 117 254 minecraft:purple_terracotta
fill 559 115 258 559 117 258 minecraft:purple_terracotta
fill 559 115 262 559 117 262 minecraft:purple_terracotta
fill 559 115 266 559 117 266 minecraft:purple_terracotta
fill 559 115 270 559 117 270 minecraft:purple_terracotta
setblock 517 116 228 minecraft:magenta_terracotta
fill 517 116 229 517 131 229 minecraft:purple_terracotta
fill 517 116 231 517 207 231 minecraft:purple_terracotta
setblock 517 116 232 minecraft:magenta_terracotta
fill 517 116 233 517 207 233 minecraft:purple_terracotta
fill 517 116 235 517 207 235 minecraft:purple_terracotta
setblock 517 116 236 minecraft:magenta_terracotta
fill 517 116 237 517 192 237 minecraft:purple_terracotta
fill 517 116 239 517 207 239 minecraft:purple_terracotta
setblock 517 116 240 minecraft:magenta_terracotta
fill 517 116 241 517 157 241 minecraft:purple_terracotta
fill 517 116 243 517 170 243 minecraft:purple_terracotta
setblock 517 116 244 minecraft:magenta_terracotta
fill 517 116 245 517 207 245 minecraft:purple_terracotta
fill 517 116 247 517 207 247 minecraft:purple_terracotta
setblock 517 116 248 minecraft:magenta_terracotta
fill 517 116 249 517 166 249 minecraft:purple_terracotta
fill 517 116 251 517 207 251 minecraft:purple_terracotta
setblock 517 116 252 minecraft:magenta_terracotta
fill 517 116 253 517 175 253 minecraft:purple_terracotta
fill 517 116 255 517 207 255 minecraft:purple_terracotta
setblock 517 116 256 minecraft:magenta_terracotta
fill 517 116 257 517 207 257 minecraft:purple_terracotta
fill 517 116 259 517 207 259 minecraft:purple_terracotta
setblock 517 116 260 minecraft:magenta_terracotta
fill 517 116 261 517 122 261 minecraft:purple_terracotta
fill 517 116 263 517 207 263 minecraft:purple_terracotta
setblock 517 116 264 minecraft:magenta_terracotta
fill 517 116 265 517 131 265 minecraft:purple_terracotta
fill 517 116 267 517 207 267 minecraft:purple_terracotta
setblock 517 116 268 minecraft:magenta_terracotta
fill 517 116 269 517 144 269 minecraft:purple_terracotta
setblock 517 116 270 minecraft:magenta_terracotta
fill 520 116 228 520 207 228 minecraft:purple_terracotta
fill 520 116 270 520 207 270 minecraft:purple_terracotta
setblock 521 116 228 minecraft:magenta_terracotta
setblock 521 116 270 minecraft:magenta_terracotta
fill 522 116 228 522 207 228 minecraft:purple_terracotta
fill 522 116 270 522 207 270 minecraft:purple_terracotta
fill 524 116 228 524 157 228 minecraft:purple_terracotta
fill 524 116 270 524 207 270 minecraft:purple_terracotta
setblock 525 116 228 minecraft:magenta_terracotta
setblock 525 116 270 minecraft:magenta_terracotta
fill 526 116 228 526 197 228 minecraft:purple_terracotta
fill 526 116 270 526 189 270 minecraft:purple_terracotta
fill 527 116 230 528 116 230 minecraft:spruce_planks
setblock 528 116 228 minecraft:purple_terracotta
fill 528 116 270 528 207 270 minecraft:purple_terracotta
setblock 529 116 228 minecraft:magenta_terracotta
fill 529 116 229 530 116 230 minecraft:dark_oak_planks
setblock 529 116 270 minecraft:magenta_terracotta
fill 530 116 228 530 207 228 minecraft:purple_terracotta
fill 530 116 270 530 207 270 minecraft:purple_terracotta
fill 532 116 228 532 207 228 minecraft:purple_terracotta
fill 532 116 270 532 188 270 minecraft:purple_terracotta
setblock 533 116 228 minecraft:magenta_terracotta
setblock 533 116 270 minecraft:magenta_terracotta
fill 534 116 228 534 180 228 minecraft:purple_terracotta
fill 534 116 270 534 140 270 minecraft:purple_terracotta
fill 536 116 228 536 195 228 minecraft:purple_terracotta
fill 536 116 270 536 198 270 minecraft:purple_terracotta
setblock 537 116 228 minecraft:magenta_terracotta
setblock 537 116 270 minecraft:magenta_terracotta
fill 538 116 228 538 147 228 minecraft:purple_terracotta
fill 538 116 270 538 207 270 minecraft:purple_terracotta
fill 540 116 228 540 156 228 minecraft:purple_terracotta
fill 540 116 270 540 207 270 minecraft:purple_terracotta
setblock 541 116 228 minecraft:magenta_terracotta
setblock 541 116 270 minecraft:magenta_terracotta
fill 542 116 228 542 202 228 minecraft:purple_terracotta
fill 542 116 270 542 164 270 minecraft:purple_terracotta
fill 544 116 228 544 156 228 minecraft:purple_terracotta
fill 544 116 270 544 120 270 minecraft:purple_terracotta
setblock 545 116 228 minecraft:magenta_terracotta
setblock 545 116 270 minecraft:magenta_terracotta
fill 546 116 228 546 207 228 minecraft:purple_terracotta
fill 546 116 270 546 155 270 minecraft:purple_terracotta
fill 548 116 228 548 207 228 minecraft:purple_terracotta
fill 548 116 270 548 207 270 minecraft:purple_terracotta
setblock 549 116 228 minecraft:magenta_terracotta
setblock 549 116 270 minecraft:magenta_terracotta
fill 550 116 228 550 117 228 minecraft:purple_terracotta
fill 550 116 270 550 184 270 minecraft:purple_terracotta
fill 552 116 228 552 207 228 minecraft:purple_terracotta
fill 552 116 270 552 207 270 minecraft:purple_terracotta
setblock 553 116 228 minecraft:magenta_terracotta
setblock 553 116 270 minecraft:magenta_terracotta
fill 554 116 228 554 207 228 minecraft:purple_terracotta
fill 554 116 270 554 207 270 minecraft:purple_terracotta
fill 556 116 228 556 207 228 minecraft:purple_terracotta
fill 556 116 270 556 207 270 minecraft:purple_terracotta
setblock 557 116 228 minecraft:magenta_terracotta
setblock 557 116 270 minecraft:magenta_terracotta
fill 558 116 228 558 207 228 minecraft:purple_terracotta
fill 558 116 270 558 207 270 minecraft:purple_terracotta
setblock 559 116 228 minecraft:magenta_terracotta
fill 559 116 231 559 155 231 minecraft:purple_terracotta
setblock 559 116 232 minecraft:magenta_terracotta
fill 559 116 233 559 139 233 minecraft:purple_terracotta
fill 559 116 235 559 207 235 minecraft:purple_terracotta
setblock 559 116 236 minecraft:magenta_terracotta
fill 559 116 237 559 207 237 minecraft:purple_terracotta
setblock 559 116 240 minecraft:magenta_terracotta
fill 559 116 243 559 207 243 minecraft:purple_terracotta
setblock 559 116 244 minecraft:magenta_terracotta
fill 559 116 245 559 207 245 minecraft:purple_terracotta
fill 559 116 247 559 146 247 minecraft:purple_terracotta
setblock 559 116 248 minecraft:magenta_terracotta
fill 559 116 249 559 207 249 minecraft:purple_terracotta
fill 559 116 251 559 187 251 minecraft:purple_terracotta
setblock 559 116 252 minecraft:magenta_terracotta
fill 559 116 253 559 207 253 minecraft:purple_terracotta
fill 559 116 255 559 133 255 minecraft:purple_terracotta
setblock 559 116 256 minecraft:magenta_terracotta
fill 559 116 257 559 159 257 minecraft:purple_terracotta
fill 559 116 259 559 207 259 minecraft:purple_terracotta
setblock 559 116 260 minecraft:magenta_terracotta
fill 559 116 261 559 207 261 minecraft:purple_terracotta
fill 559 116 263 559 207 263 minecraft:purple_terracotta
setblock 559 116 264 minecraft:magenta_terracotta
fill 559 116 265 559 207 265 minecraft:purple_terracotta
fill 559 116 267 559 207 267 minecraft:purple_terracotta
setblock 559 116 268 minecraft:magenta_terracotta
fill 559 116 269 559 137 269 minecraft:purple_terracotta
fill 517 117 228 517 119 228 minecraft:purple_terracotta
fill 517 117 232 517 119 232 minecraft:purple_terracotta
fill 517 117 236 517 119 236 minecraft:purple_terracotta
fill 517 117 240 517 119 240 minecraft:purple_terracotta
fill 517 117 244 517 119 244 minecraft:purple_terracotta
fill 517 117 248 517 119 248 minecraft:purple_terracotta
fill 517 117 252 517 119 252 minecraft:purple_terracotta
fill 517 117 256 517 119 256 minecraft:purple_terracotta
fill 517 117 260 517 119 260 minecraft:purple_terracotta
fill 517 117 264 517 119 264 minecraft:purple_terracotta
fill 517 117 268 517 119 268 minecraft:purple_terracotta
setblock 517 117 270 minecraft:purple_terracotta
fill 520 117 241 520 123 241 minecraft:iron_bars
fill 521 117 228 521 119 228 minecraft:purple_terracotta
fill 521 117 270 521 119 270 minecraft:purple_terracotta
fill 525 117 228 525 119 228 minecraft:purple_terracotta
fill 525 117 230 526 117 230 minecraft:spruce_planks
fill 525 117 270 525 119 270 minecraft:purple_terracotta
fill 527 117 229 528 117 230 minecraft:dark_oak_planks
setblock 528 117 228 minecraft:gray_terracotta
fill 529 117 228 529 119 228 minecraft:purple_terracotta
fill 529 117 270 529 119 270 minecraft:purple_terracotta
fill 533 117 228 533 119 228 minecraft:purple_terracotta
fill 533 117 270 533 119 270 minecraft:purple_terracotta
fill 537 117 228 537 119 228 minecraft:purple_terracotta
fill 537 117 270 537 119 270 minecraft:purple_terracotta
fill 541 117 228 541 119 228 minecraft:purple_terracotta
fill 541 117 270 541 119 270 minecraft:purple_terracotta
fill 545 117 228 545 119 228 minecraft:purple_terracotta
fill 545 117 270 545 119 270 minecraft:purple_terracotta
fill 549 117 228 549 119 228 minecraft:purple_terracotta
fill 549 117 270 549 119 270 minecraft:purple_terracotta
fill 553 117 228 553 119 228 minecraft:purple_terracotta
fill 553 117 270 553 119 270 minecraft:purple_terracotta
fill 557 117 228 557 119 228 minecraft:purple_terracotta
fill 557 117 270 557 119 270 minecraft:purple_terracotta
setblock 559 117 228 minecraft:purple_terracotta
fill 559 117 232 559 119 232 minecraft:purple_terracotta
fill 559 117 236 559 119 236 minecraft:purple_terracotta
fill 559 117 240 559 119 240 minecraft:purple_terracotta
fill 559 117 244 559 119 244 minecraft:purple_terracotta
fill 559 117 248 559 119 248 minecraft:purple_terracotta
fill 559 117 252 559 119 252 minecraft:purple_terracotta
fill 559 117 256 559 119 256 minecraft:purple_terracotta
fill 559 117 260 559 119 260 minecraft:purple_terracotta
fill 559 117 264 559 119 264 minecraft:purple_terracotta
fill 559 117 268 559 119 268 minecraft:purple_terracotta
setblock 517 118 230 minecraft:magenta_terracotta
setblock 517 118 234 minecraft:magenta_terracotta
setblock 517 118 238 minecraft:magenta_terracotta
setblock 517 118 242 minecraft:magenta_terracotta
setblock 517 118 246 minecraft:magenta_terracotta
setblock 517 118 250 minecraft:magenta_terracotta
setblock 517 118 254 minecraft:magenta_terracotta
setblock 517 118 258 minecraft:magenta_terracotta
setblock 517 118 262 minecraft:magenta_terracotta
setblock 517 118 266 minecraft:magenta_terracotta
setblock 517 118 270 minecraft:magenta_terracotta
setblock 519 118 228 minecraft:magenta_terracotta
setblock 519 118 270 minecraft:magenta_terracotta
setblock 523 118 228 minecraft:magenta_terracotta
fill 523 118 230 524 118 230 minecraft:spruce_planks
setblock 523 118 270 minecraft:magenta_terracotta
fill 525 118 229 526 118 230 minecraft:dark_oak_planks
setblock 527 118 228 minecraft:magenta_terracotta
setblock 527 118 270 minecraft:magenta_terracotta
fill 528 118 228 528 197 228 minecraft:purple_terracotta
setblock 531 118 228 minecraft:magenta_terracotta
setblock 531 118 270 minecraft:magenta_terracotta
setblock 535 118 228 minecraft:magenta_terracotta
setblock 535 118 270 minecraft:magenta_terracotta
setblock 539 118 228 minecraft:magenta_terracotta
setblock 539 118 270 minecraft:magenta_terracotta
setblock 543 118 228 minecraft:magenta_terracotta
setblock 543 118 270 minecraft:magenta_terracotta
setblock 547 118 228 minecraft:magenta_terracotta
setblock 547 118 270 minecraft:magenta_terracotta
setblock 550 118 228 minecraft:black_terracotta
setblock 551 118 228 minecraft:magenta_terracotta
setblock 551 118 270 minecraft:magenta_terracotta
setblock 555 118 228 minecraft:magenta_terracotta
setblock 555 118 270 minecraft:magenta_terracotta
setblock 559 118 228 minecraft:magenta_terracotta
setblock 559 118 230 minecraft:magenta_terracotta
setblock 559 118 234 minecraft:magenta_terracotta
setblock 559 118 238 minecraft:magenta_terracotta
fill 559 118 239 559 207 239 minecraft:purple_terracotta
fill 559 118 241 559 119 241 minecraft:purple_terracotta
setblock 559 118 242 minecraft:magenta_terracotta
setblock 559 118 246 minecraft:magenta_terracotta
setblock 559 118 250 minecraft:magenta_terracotta
setblock 559 118 254 minecraft:magenta_terracotta
setblock 559 118 258 minecraft:magenta_terracotta
setblock 559 118 262 minecraft:magenta_terracotta
setblock 559 118 266 minecraft:magenta_terracotta
setblock 559 118 270 minecraft:magenta_terracotta
fill 517 119 230 517 121 230 minecraft:purple_terracotta
fill 517 119 234 517 121 234 minecraft:purple_terracotta
fill 517 119 238 517 121 238 minecraft:purple_terracotta
fill 517 119 242 517 121 242 minecraft:purple_terracotta
fill 517 119 246 517 121 246 minecraft:purple_terracotta
fill 517 119 250 517 121 250 minecraft:purple_terracotta
fill 517 119 254 517 121 254 minecraft:purple_terracotta
fill 517 119 258 517 121 258 minecraft:purple_terracotta
fill 517 119 262 517 121 262 minecraft:purple_terracotta
fill 517 119 266 517 121 266 minecraft:purple_terracotta
setblock 517 119 270 minecraft:purple_terracotta
fill 519 119 228 519 121 228 minecraft:purple_terracotta
fill 519 119 270 519 121 270 minecraft:purple_terracotta
fill 521 119 230 522 119 230 minecraft:spruce_planks
fill 523 119 228 523 121 228 minecraft:purple_terracotta
fill 523 119 229 524 119 230 minecraft:dark_oak_planks
fill 523 119 270 523 121 270 minecraft:purple_terracotta
fill 527 119 228 527 121 228 minecraft:purple_terracotta
fill 527 119 270 527 121 270 minecraft:purple_terracotta
fill 531 119 228 531 121 228 minecraft:purple_terracotta
fill 531 119 270 531 121 270 minecraft:purple_terracotta
fill 535 119 228 535 121 228 minecraft:purple_terracotta
fill 535 119 270 535 121 270 minecraft:purple_terracotta
fill 539 119 228 539 121 228 minecraft:purple_terracotta
fill 539 119 270 539 121 270 minecraft:purple_terracotta
fill 543 119 228 543 121 228 minecraft:purple_terracotta
fill 543 119 270 543 121 270 minecraft:purple_terracotta
fill 547 119 228 547 121 228 minecraft:purple_terracotta
fill 547 119 270 547 121 270 minecraft:purple_terracotta
fill 550 119 228 551 121 228 minecraft:purple_terracotta
fill 551 119 270 551 121 270 minecraft:purple_terracotta
fill 555 119 228 555 121 228 minecraft:purple_terracotta
fill 555 119 270 555 121 270 minecraft:purple_terracotta
setblock 559 119 228 minecraft:purple_terracotta
fill 559 119 230 559 121 230 minecraft:purple_terracotta
fill 559 119 234 559 121 234 minecraft:purple_terracotta
fill 559 119 238 559 121 238 minecraft:purple_terracotta
fill 559 119 242 559 121 242 minecraft:purple_terracotta
fill 559 119 246 559 121 246 minecraft:purple_terracotta
fill 559 119 250 559 121 250 minecraft:purple_terracotta
fill 559 119 254 559 121 254 minecraft:purple_terracotta
fill 559 119 258 559 121 258 minecraft:purple_terracotta
fill 559 119 262 559 121 262 minecraft:purple_terracotta
fill 559 119 266 559 121 266 minecraft:purple_terracotta
fill 559 119 270 559 121 270 minecraft:purple_terracotta
setblock 517 120 228 minecraft:magenta_terracotta
setblock 517 120 232 minecraft:magenta_terracotta
setblock 517 120 236 minecraft:magenta_terracotta
setblock 517 120 240 minecraft:magenta_terracotta
setblock 517 120 244 minecraft:magenta_terracotta
setblock 517 120 248 minecraft:magenta_terracotta
setblock 517 120 252 minecraft:magenta_terracotta
setblock 517 120 256 minecraft:magenta_terracotta
setblock 517 120 260 minecraft:magenta_terracotta
setblock 517 120 264 minecraft:magenta_terracotta
setblock 517 120 268 minecraft:magenta_terracotta
setblock 517 120 270 minecraft:magenta_terracotta
fill 519 120 230 520 120 230 minecraft:spruce_planks
setblock 521 120 228 minecraft:magenta_terracotta
fill 521 120 229 522 120 230 minecraft:dark_oak_planks
setblock 521 120 270 minecraft:magenta_terracotta
setblock 525 120 228 minecraft:magenta_terracotta
setblock 525 120 270 minecraft:magenta_terracotta
setblock 529 120 228 minecraft:magenta_terracotta
setblock 529 120 270 minecraft:magenta_terracotta
setblock 533 120 228 minecraft:magenta_terracotta
setblock 533 120 270 minecraft:magenta_terracotta
setblock 537 120 228 minecraft:magenta_terracotta
setblock 537 120 270 minecraft:magenta_terracotta
setblock 541 120 228 minecraft:magenta_terracotta
setblock 541 120 270 minecraft:magenta_terracotta
setblock 545 120 228 minecraft:magenta_terracotta
setblock 545 120 270 minecraft:magenta_terracotta
setblock 549 120 228 minecraft:magenta_terracotta
setblock 549 120 270 minecraft:magenta_terracotta
setblock 553 120 228 minecraft:magenta_terracotta
setblock 553 120 270 minecraft:magenta_terracotta
setblock 557 120 228 minecraft:magenta_terracotta
setblock 557 120 270 minecraft:magenta_terracotta
setblock 559 120 228 minecraft:magenta_terracotta
setblock 559 120 232 minecraft:magenta_terracotta
setblock 559 120 236 minecraft:magenta_terracotta
setblock 559 120 240 minecraft:magenta_terracotta
setblock 559 120 241 minecraft:black_terracotta
setblock 559 120 244 minecraft:magenta_terracotta
setblock 559 120 248 minecraft:magenta_terracotta
setblock 559 120 252 minecraft:magenta_terracotta
setblock 559 120 256 minecraft:magenta_terracotta
setblock 559 120 260 minecraft:magenta_terracotta
setblock 559 120 264 minecraft:magenta_terracotta
setblock 559 120 268 minecraft:magenta_terracotta
fill 517 121 228 517 123 228 minecraft:purple_terracotta
fill 517 121 232 517 123 232 minecraft:purple_terracotta
fill 517 121 236 517 123 236 minecraft:purple_terracotta
fill 517 121 240 517 123 240 minecraft:purple_terracotta
fill 517 121 244 517 123 244 minecraft:purple_terracotta
fill 517 121 248 517 123 248 minecraft:purple_terracotta
fill 517 121 252 517 123 252 minecraft:purple_terracotta
fill 517 121 256 517 123 256 minecraft:purple_terracotta
fill 517 121 260 517 123 260 minecraft:purple_terracotta
fill 517 121 264 517 123 264 minecraft:purple_terracotta
fill 517 121 268 517 123 268 minecraft:purple_terracotta
setblock 517 121 270 minecraft:purple_terracotta
fill 518 121 229 520 121 230 minecraft:dark_oak_planks
setblock 519 121 231 minecraft:spruce_planks
setblock 520 121 231 minecraft:light[level=11]
setblock 520 121 238 minecraft:light[level=12]
setblock 520 121 239 minecraft:light[level=11]
setblock 520 121 245 minecraft:light[level=12]
setblock 520 121 247 minecraft:light[level=11]
setblock 520 121 252 minecraft:light[level=12]
setblock 520 121 255 minecraft:light[level=11]
setblock 520 121 259 minecraft:light[level=12]
setblock 520 121 263 minecraft:light[level=11]
setblock 520 121 266 minecraft:light[level=12]
fill 521 121 228 521 123 228 minecraft:purple_terracotta
fill 521 121 270 521 123 270 minecraft:purple_terracotta
fill 525 121 228 525 123 228 minecraft:purple_terracotta
fill 525 121 270 525 123 270 minecraft:purple_terracotta
setblock 527 121 231 minecraft:light[level=12]
setblock 527 121 238 minecraft:light[level=12]
setblock 527 121 245 minecraft:light[level=12]
setblock 527 121 252 minecraft:light[level=12]
setblock 527 121 259 minecraft:light[level=12]
setblock 527 121 266 minecraft:light[level=12]
setblock 528 121 231 minecraft:light[level=11]
setblock 528 121 239 minecraft:light[level=11]
setblock 528 121 247 minecraft:light[level=11]
setblock 528 121 255 minecraft:light[level=11]
setblock 528 121 263 minecraft:light[level=11]
fill 529 121 228 529 123 228 minecraft:purple_terracotta
fill 529 121 270 529 123 270 minecraft:purple_terracotta
fill 533 121 228 533 123 228 minecraft:purple_terracotta
fill 533 121 270 533 123 270 minecraft:purple_terracotta
setblock 534 121 231 minecraft:light[level=12]
setblock 534 121 238 minecraft:light[level=12]
setblock 534 121 245 minecraft:light[level=12]
setblock 534 121 252 minecraft:light[level=12]
setblock 534 121 259 minecraft:light[level=12]
setblock 534 121 266 minecraft:light[level=12]
setblock 536 121 231 minecraft:light[level=11]
setblock 536 121 239 minecraft:light[level=11]
setblock 536 121 255 minecraft:light[level=11]
setblock 536 121 263 minecraft:light[level=11]
fill 537 121 228 537 123 228 minecraft:purple_terracotta
fill 537 121 270 537 123 270 minecraft:purple_terracotta
fill 541 121 228 541 123 228 minecraft:purple_terracotta
setblock 541 121 231 minecraft:light[level=12]
setblock 541 121 238 minecraft:light[level=12]
setblock 541 121 245 minecraft:light[level=12]
setblock 541 121 252 minecraft:light[level=12]
setblock 541 121 259 minecraft:light[level=12]
setblock 541 121 266 minecraft:light[level=12]
fill 541 121 270 541 123 270 minecraft:purple_terracotta
setblock 544 121 231 minecraft:light[level=11]
setblock 544 121 239 minecraft:light[level=11]
setblock 544 121 247 minecraft:light[level=11]
setblock 544 121 255 minecraft:light[level=11]
setblock 544 121 263 minecraft:light[level=11]
setblock 544 121 270 minecraft:light_gray_terracotta
fill 545 121 228 545 123 228 minecraft:purple_terracotta
fill 545 121 270 545 123 270 minecraft:purple_terracotta
setblock 548 121 231 minecraft:light[level=12]
setblock 548 121 238 minecraft:light[level=12]
setblock 548 121 245 minecraft:light[level=12]
setblock 548 121 252 minecraft:light[level=12]
setblock 548 121 259 minecraft:light[level=12]
setblock 548 121 266 minecraft:light[level=12]
fill 549 121 228 549 123 228 minecraft:purple_terracotta
fill 549 121 270 549 123 270 minecraft:purple_terracotta
setblock 552 121 231 minecraft:light[level=11]
setblock 552 121 239 minecraft:light[level=11]
setblock 552 121 247 minecraft:light[level=11]
setblock 552 121 255 minecraft:light[level=11]
setblock 552 121 263 minecraft:light[level=11]
fill 553 121 228 553 123 228 minecraft:purple_terracotta
fill 553 121 270 553 123 270 minecraft:purple_terracotta
setblock 555 121 231 minecraft:light[level=12]
setblock 555 121 238 minecraft:light[level=12]
setblock 555 121 245 minecraft:light[level=12]
setblock 555 121 252 minecraft:light[level=12]
setblock 555 121 259 minecraft:light[level=12]
setblock 555 121 266 minecraft:light[level=12]
fill 557 121 228 557 123 228 minecraft:purple_terracotta
fill 557 121 270 557 123 270 minecraft:purple_terracotta
setblock 559 121 228 minecraft:purple_terracotta
fill 559 121 232 559 123 232 minecraft:purple_terracotta
fill 559 121 236 559 123 236 minecraft:purple_terracotta
fill 559 121 240 559 123 241 minecraft:purple_terracotta
fill 559 121 244 559 123 244 minecraft:purple_terracotta
fill 559 121 248 559 123 248 minecraft:purple_terracotta
fill 559 121 252 559 123 252 minecraft:purple_terracotta
fill 559 121 256 559 123 256 minecraft:purple_terracotta
fill 559 121 260 559 123 260 minecraft:purple_terracotta
fill 559 121 264 559 123 264 minecraft:purple_terracotta
fill 559 121 268 559 123 268 minecraft:purple_terracotta
setblock 517 122 230 minecraft:magenta_terracotta
setblock 517 122 234 minecraft:magenta_terracotta
setblock 517 122 238 minecraft:magenta_terracotta
setblock 517 122 242 minecraft:magenta_terracotta
setblock 517 122 246 minecraft:magenta_terracotta
setblock 517 122 250 minecraft:magenta_terracotta
setblock 517 122 254 minecraft:magenta_terracotta
setblock 517 122 258 minecraft:magenta_terracotta
setblock 517 122 262 minecraft:magenta_terracotta
setblock 517 122 266 minecraft:magenta_terracotta
setblock 517 122 270 minecraft:magenta_terracotta
fill 518 122 229 519 122 231 minecraft:dark_oak_planks
setblock 519 122 228 minecraft:magenta_terracotta
fill 519 122 232 519 122 233 minecraft:spruce_planks
setblock 519 122 270 minecraft:magenta_terracotta
setblock 523 122 228 minecraft:magenta_terracotta
setblock 523 122 270 minecraft:magenta_terracotta
setblock 527 122 228 minecraft:magenta_terracotta
setblock 527 122 270 minecraft:magenta_terracotta
setblock 531 122 228 minecraft:magenta_terracotta
setblock 531 122 270 minecraft:magenta_terracotta
setblock 535 122 228 minecraft:magenta_terracotta
setblock 535 122 270 minecraft:magenta_terracotta
fill 536 122 232 536 129 232 minecraft:iron_bars
setblock 539 122 228 minecraft:magenta_terracotta
setblock 539 122 270 minecraft:magenta_terracotta
setblock 543 122 228 minecraft:magenta_terracotta
setblock 543 122 270 minecraft:magenta_terracotta
fill 544 122 270 544 203 270 minecraft:purple_terracotta
setblock 547 122 228 minecraft:magenta_terracotta
setblock 547 122 270 minecraft:magenta_terracotta
fill 550 122 228 550 172 228 minecraft:purple_terracotta
setblock 551 122 228 minecraft:magenta_terracotta
setblock 551 122 270 minecraft:magenta_terracotta
setblock 555 122 228 minecraft:magenta_terracotta
setblock 555 122 270 minecraft:magenta_terracotta
setblock 559 122 228 minecraft:magenta_terracotta
setblock 559 122 230 minecraft:magenta_terracotta
setblock 559 122 234 minecraft:magenta_terracotta
setblock 559 122 238 minecraft:magenta_terracotta
setblock 559 122 242 minecraft:magenta_terracotta
setblock 559 122 246 minecraft:magenta_terracotta
setblock 559 122 250 minecraft:magenta_terracotta
setblock 559 122 254 minecraft:magenta_terracotta
setblock 559 122 258 minecraft:magenta_terracotta
setblock 559 122 262 minecraft:magenta_terracotta
setblock 559 122 266 minecraft:magenta_terracotta
setblock 559 122 270 minecraft:magenta_terracotta
fill 517 123 230 517 125 230 minecraft:purple_terracotta
fill 517 123 234 517 125 234 minecraft:purple_terracotta
fill 517 123 238 517 125 238 minecraft:purple_terracotta
fill 517 123 242 517 125 242 minecraft:purple_terracotta
fill 517 123 246 517 125 246 minecraft:purple_terracotta
fill 517 123 250 517 125 250 minecraft:purple_terracotta
fill 517 123 254 517 125 254 minecraft:purple_terracotta
fill 517 123 258 517 125 258 minecraft:purple_terracotta
setblock 517 123 261 minecraft:light_gray_terracotta
fill 517 123 262 517 125 262 minecraft:purple_terracotta
fill 517 123 266 517 125 266 minecraft:purple_terracotta
setblock 517 123 270 minecraft:purple_terracotta
fill 518 123 232 519 123 233 minecraft:dark_oak_planks
fill 519 123 228 519 125 228 minecraft:purple_terracotta
fill 519 123 234 519 123 235 minecraft:spruce_planks
fill 519 123 270 519 125 270 minecraft:purple_terracotta
fill 523 123 228 523 125 228 minecraft:purple_terracotta
fill 523 123 270 523 125 270 minecraft:purple_terracotta
fill 527 123 228 527 125 228 minecraft:purple_terracotta
fill 527 123 270 527 125 270 minecraft:purple_terracotta
fill 531 123 228 531 125 228 minecraft:purple_terracotta
fill 531 123 270 531 125 270 minecraft:purple_terracotta
fill 535 123 228 535 125 228 minecraft:purple_terracotta
fill 535 123 270 535 125 270 minecraft:purple_terracotta
fill 539 123 228 539 125 228 minecraft:purple_terracotta
fill 539 123 270 539 125 270 minecraft:purple_terracotta
fill 543 123 228 543 125 228 minecraft:purple_terracotta
fill 543 123 270 543 125 270 minecraft:purple_terracotta
fill 547 123 228 547 125 228 minecraft:purple_terracotta
fill 547 123 270 547 125 270 minecraft:purple_terracotta
fill 551 123 228 551 125 228 minecraft:purple_terracotta
fill 551 123 270 551 125 270 minecraft:purple_terracotta
fill 555 123 228 555 125 228 minecraft:purple_terracotta
fill 555 123 270 555 125 270 minecraft:purple_terracotta
setblock 559 123 228 minecraft:purple_terracotta
fill 559 123 230 559 125 230 minecraft:purple_terracotta
fill 559 123 234 559 125 234 minecraft:purple_terracotta
fill 559 123 238 559 125 238 minecraft:purple_terracotta
fill 559 123 242 559 125 242 minecraft:purple_terracotta
fill 559 123 246 559 125 246 minecraft:purple_terracotta
fill 559 123 250 559 125 250 minecraft:purple_terracotta
fill 559 123 254 559 125 254 minecraft:purple_terracotta
fill 559 123 258 559 125 258 minecraft:purple_terracotta
fill 559 123 262 559 125 262 minecraft:purple_terracotta
fill 559 123 266 559 125 266 minecraft:purple_terracotta
fill 559 123 270 559 125 270 minecraft:purple_terracotta
setblock 517 124 228 minecraft:magenta_terracotta
setblock 517 124 232 minecraft:magenta_terracotta
setblock 517 124 236 minecraft:magenta_terracotta
setblock 517 124 240 minecraft:magenta_terracotta
setblock 517 124 244 minecraft:magenta_terracotta
setblock 517 124 248 minecraft:magenta_terracotta
setblock 517 124 252 minecraft:magenta_terracotta
setblock 517 124 256 minecraft:magenta_terracotta
setblock 517 124 260 minecraft:magenta_terracotta
fill 517 124 261 517 169 261 minecraft:purple_terracotta
setblock 517 124 264 minecraft:magenta_terracotta
setblock 517 124 268 minecraft:magenta_terracotta
setblock 517 124 270 minecraft:magenta_terracotta
fill 518 124 234 519 124 235 minecraft:dark_oak_planks
fill 519 124 236 519 124 237 minecraft:spruce_planks
setblock 521 124 228 minecraft:magenta_terracotta
setblock 521 124 270 minecraft:magenta_terracotta
setblock 525 124 228 minecraft:magenta_terracotta
setblock 525 124 270 minecraft:magenta_terracotta
setblock 529 124 228 minecraft:magenta_terracotta
setblock 529 124 270 minecraft:magenta_terracotta
setblock 533 124 228 minecraft:magenta_terracotta
setblock 533 124 270 minecraft:magenta_terracotta
setblock 537 124 228 minecraft:magenta_terracotta
setblock 537 124 270 minecraft:magenta_terracotta
setblock 541 124 228 minecraft:magenta_terracotta
setblock 541 124 270 minecraft:magenta_terracotta
setblock 545 124 228 minecraft:magenta_terracotta
setblock 545 124 270 minecraft:magenta_terracotta
setblock 549 124 228 minecraft:magenta_terracotta
setblock 549 124 270 minecraft:magenta_terracotta
setblock 553 124 228 minecraft:magenta_terracotta
setblock 553 124 270 minecraft:magenta_terracotta
setblock 557 124 228 minecraft:magenta_terracotta
setblock 557 124 270 minecraft:magenta_terracotta
setblock 559 124 228 minecraft:magenta_terracotta
setblock 559 124 232 minecraft:magenta_terracotta
setblock 559 124 236 minecraft:magenta_terracotta
setblock 559 124 240 minecraft:magenta_terracotta
fill 559 124 241 559 207 241 minecraft:purple_terracotta
setblock 559 124 244 minecraft:magenta_terracotta
setblock 559 124 248 minecraft:magenta_terracotta
setblock 559 124 252 minecraft:magenta_terracotta
setblock 559 124 256 minecraft:magenta_terracotta
setblock 559 124 260 minecraft:magenta_terracotta
setblock 559 124 264 minecraft:magenta_terracotta
setblock 559 124 268 minecraft:magenta_terracotta
fill 517 125 228 517 127 228 minecraft:purple_terracotta
fill 517 125 232 517 127 232 minecraft:purple_terracotta
fill 517 125 236 517 127 236 minecraft:purple_terracotta
fill 517 125 240 517 127 240 minecraft:purple_terracotta
fill 517 125 244 517 127 244 minecraft:purple_terracotta
fill 517 125 248 517 127 248 minecraft:purple_terracotta
fill 517 125 252 517 127 252 minecraft:purple_terracotta
fill 517 125 256 517 127 256 minecraft:purple_terracotta
fill 517 125 260 517 127 260 minecraft:purple_terracotta
fill 517 125 264 517 127 264 minecraft:purple_terracotta
fill 517 125 268 517 127 268 minecraft:purple_terracotta
setblock 517 125 270 minecraft:purple_terracotta
fill 518 125 236 519 125 237 minecraft:dark_oak_planks
fill 519 125 238 519 125 239 minecraft:spruce_planks
fill 521 125 228 521 127 228 minecraft:purple_terracotta
fill 521 125 270 521 127 270 minecraft:purple_terracotta
fill 525 125 228 525 127 228 minecraft:purple_terracotta
fill 525 125 270 525 127 270 minecraft:purple_terracotta
fill 529 125 228 529 127 228 minecraft:purple_terracotta
fill 529 125 270 529 127 270 minecraft:purple_terracotta
fill 533 125 228 533 127 228 minecraft:purple_terracotta
fill 533 125 270 533 127 270 minecraft:purple_terracotta
fill 537 125 228 537 127 228 minecraft:purple_terracotta
fill 537 125 270 537 127 270 minecraft:purple_terracotta
fill 541 125 228 541 127 228 minecraft:purple_terracotta
fill 541 125 270 541 127 270 minecraft:purple_terracotta
fill 545 125 228 545 127 228 minecraft:purple_terracotta
fill 545 125 270 545 127 270 minecraft:purple_terracotta
fill 549 125 228 549 127 228 minecraft:purple_terracotta
fill 549 125 270 549 127 270 minecraft:purple_terracotta
fill 553 125 228 553 127 228 minecraft:purple_terracotta
fill 553 125 270 553 127 270 minecraft:purple_terracotta
fill 557 125 228 557 127 228 minecraft:purple_terracotta
fill 557 125 270 557 127 270 minecraft:purple_terracotta
setblock 559 125 228 minecraft:purple_terracotta
fill 559 125 232 559 127 232 minecraft:purple_terracotta
fill 559 125 236 559 127 236 minecraft:purple_terracotta
fill 559 125 240 559 127 240 minecraft:purple_terracotta
fill 559 125 244 559 127 244 minecraft:purple_terracotta
fill 559 125 248 559 127 248 minecraft:purple_terracotta
fill 559 125 252 559 127 252 minecraft:purple_terracotta
fill 559 125 256 559 127 256 minecraft:purple_terracotta
fill 559 125 260 559 127 260 minecraft:purple_terracotta
fill 559 125 264 559 127 264 minecraft:purple_terracotta
fill 559 125 268 559 127 268 minecraft:purple_terracotta
setblock 517 126 230 minecraft:magenta_terracotta
setblock 517 126 234 minecraft:magenta_terracotta
setblock 517 126 238 minecraft:magenta_terracotta
setblock 517 126 242 minecraft:magenta_terracotta
setblock 517 126 246 minecraft:magenta_terracotta
setblock 517 126 250 minecraft:magenta_terracotta
setblock 517 126 254 minecraft:magenta_terracotta
setblock 517 126 258 minecraft:magenta_terracotta
setblock 517 126 262 minecraft:magenta_terracotta
setblock 517 126 266 minecraft:magenta_terracotta
setblock 517 126 270 minecraft:magenta_terracotta
fill 518 126 238 519 126 239 minecraft:dark_oak_planks
setblock 519 126 228 minecraft:magenta_terracotta
fill 519 126 240 519 126 241 minecraft:spruce_planks
setblock 519 126 270 minecraft:magenta_terracotta
setblock 523 126 228 minecraft:magenta_terracotta
setblock 523 126 270 minecraft:magenta_terracotta
setblock 527 126 228 minecraft:magenta_terracotta
setblock 527 126 270 minecraft:magenta_terracotta
setblock 531 126 228 minecraft:magenta_terracotta
setblock 531 126 270 minecraft:magenta_terracotta
setblock 535 126 228 minecraft:magenta_terracotta
setblock 535 126 270 minecraft:magenta_terracotta
setblock 539 126 228 minecraft:magenta_terracotta
setblock 539 126 270 minecraft:magenta_terracotta
setblock 543 126 228 minecraft:magenta_terracotta
setblock 543 126 270 minecraft:magenta_terracotta
fill 546 126 245 546 128 245 minecraft:white_stained_glass
setblock 547 126 228 minecraft:magenta_terracotta
fill 547 126 246 547 128 247 minecraft:white_stained_glass
setblock 547 126 270 minecraft:magenta_terracotta
fill 548 126 245 548 128 246 minecraft:white_stained_glass
setblock 551 126 228 minecraft:magenta_terracotta
setblock 551 126 270 minecraft:magenta_terracotta
setblock 555 126 228 minecraft:magenta_terracotta
setblock 555 126 270 minecraft:magenta_terracotta
setblock 559 126 228 minecraft:magenta_terracotta
setblock 559 126 230 minecraft:magenta_terracotta
setblock 559 126 234 minecraft:magenta_terracotta
setblock 559 126 238 minecraft:magenta_terracotta
setblock 559 126 242 minecraft:magenta_terracotta
setblock 559 126 246 minecraft:magenta_terracotta
setblock 559 126 250 minecraft:magenta_terracotta
setblock 559 126 254 minecraft:magenta_terracotta
setblock 559 126 258 minecraft:magenta_terracotta
setblock 559 126 262 minecraft:magenta_terracotta
setblock 559 126 266 minecraft:magenta_terracotta
setblock 559 126 270 minecraft:magenta_terracotta
fill 517 127 230 517 129 230 minecraft:purple_terracotta
fill 517 127 234 517 129 234 minecraft:purple_terracotta
fill 517 127 238 517 129 238 minecraft:purple_terracotta
fill 517 127 242 517 129 242 minecraft:purple_terracotta
fill 517 127 246 517 129 246 minecraft:purple_terracotta
fill 517 127 250 517 129 250 minecraft:purple_terracotta
fill 517 127 254 517 129 254 minecraft:purple_terracotta
fill 517 127 258 517 129 258 minecraft:purple_terracotta
fill 517 127 262 517 129 262 minecraft:purple_terracotta
fill 517 127 266 517 129 266 minecraft:purple_terracotta
setblock 517 127 270 minecraft:purple_terracotta
fill 518 127 240 519 127 241 minecraft:dark_oak_planks
fill 519 127 228 519 129 228 minecraft:purple_terracotta
fill 519 127 242 519 127 243 minecraft:spruce_planks
fill 519 127 270 519 129 270 minecraft:purple_terracotta
setblock 520 127 231 minecraft:light[level=12]
setblock 520 127 238 minecraft:light[level=12]
setblock 520 127 245 minecraft:light[level=12]
setblock 520 127 252 minecraft:light[level=12]
setblock 520 127 259 minecraft:light[level=12]
setblock 520 127 266 minecraft:light[level=12]
fill 523 127 228 523 129 228 minecraft:purple_terracotta
fill 523 127 270 523 129 270 minecraft:purple_terracotta
fill 527 127 228 527 129 228 minecraft:purple_terracotta
setblock 527 127 231 minecraft:light[level=12]
setblock 527 127 238 minecraft:light[level=12]
setblock 527 127 245 minecraft:light[level=12]
setblock 527 127 252 minecraft:light[level=12]
setblock 527 127 259 minecraft:light[level=12]
setblock 527 127 266 minecraft:light[level=12]
fill 527 127 270 527 129 270 minecraft:purple_terracotta
fill 531 127 228 531 129 228 minecraft:purple_terracotta
fill 531 127 270 531 129 270 minecraft:purple_terracotta
setblock 534 127 231 minecraft:light[level=12]
setblock 534 127 238 minecraft:light[level=12]
setblock 534 127 245 minecraft:light[level=12]
setblock 534 127 252 minecraft:light[level=12]
setblock 534 127 259 minecraft:light[level=12]
setblock 534 127 266 minecraft:light[level=12]
fill 535 127 228 535 129 228 minecraft:purple_terracotta
fill 535 127 270 535 129 270 minecraft:purple_terracotta
fill 539 127 228 539 129 228 minecraft:purple_terracotta
setblock 539 127 270 minecraft:black_terracotta
setblock 541 127 231 minecraft:light[level=12]
setblock 541 127 238 minecraft:light[level=12]
setblock 541 127 245 minecraft:light[level=12]
setblock 541 127 252 minecraft:light[level=12]
setblock 541 127 259 minecraft:light[level=12]
setblock 541 127 266 minecraft:light[level=12]
fill 543 127 228 543 129 228 minecraft:purple_terracotta
setblock 543 127 270 minecraft:purple_terracotta
fill 546 127 246 546 128 247 minecraft:white_stained_glass
fill 547 127 228 547 129 228 minecraft:purple_terracotta
fill 547 127 244 547 128 245 minecraft:white_stained_glass
fill 547 127 270 547 129 270 minecraft:purple_terracotta
setblock 548 127 231 minecraft:light[level=12]
setblock 548 127 238 minecraft:light[level=12]
fill 548 127 244 548 129 244 minecraft:white_stained_glass
fill 548 127 247 548 129 247 minecraft:white_stained_glass
setblock 548 127 252 minecraft:light[level=12]
setblock 548 127 259 minecraft:light[level=12]
setblock 548 127 266 minecraft:light[level=12]
fill 549 127 246 549 130 246 minecraft:white_stained_glass
fill 551 127 228 551 129 228 minecraft:purple_terracotta
fill 551 127 270 551 129 270 minecraft:purple_terracotta
fill 555 127 228 555 129 228 minecraft:purple_terracotta
setblock 555 127 231 minecraft:light[level=12]
setblock 555 127 238 minecraft:light[level=12]
setblock 555 127 245 minecraft:light[level=12]
setblock 555 127 252 minecraft:light[level=12]
setblock 555 127 259 minecraft:light[level=12]
setblock 555 127 266 minecraft:light[level=12]
fill 555 127 270 555 129 270 minecraft:purple_terracotta
setblock 559 127 228 minecraft:purple_terracotta
fill 559 127 230 559 129 230 minecraft:purple_terracotta
fill 559 127 234 559 129 234 minecraft:purple_terracotta
fill 559 127 238 559 129 238 minecraft:purple_terracotta
fill 559 127 242 559 129 242 minecraft:purple_terracotta
fill 559 127 246 559 129 246 minecraft:purple_terracotta
fill 559 127 250 559 129 250 minecraft:purple_terracotta
fill 559 127 254 559 129 254 minecraft:purple_terracotta
fill 559 127 258 559 129 258 minecraft:purple_terracotta
fill 559 127 262 559 129 262 minecraft:purple_terracotta
fill 559 127 266 559 129 266 minecraft:purple_terracotta
fill 559 127 270 559 129 270 minecraft:purple_terracotta
setblock 517 128 228 minecraft:magenta_terracotta
setblock 517 128 232 minecraft:magenta_terracotta
setblock 517 128 236 minecraft:magenta_terracotta
setblock 517 128 240 minecraft:magenta_terracotta
setblock 517 128 244 minecraft:magenta_terracotta
setblock 517 128 248 minecraft:magenta_terracotta
setblock 517 128 252 minecraft:magenta_terracotta
setblock 517 128 256 minecraft:magenta_terracotta
setblock 517 128 260 minecraft:magenta_terracotta
setblock 517 128 264 minecraft:magenta_terracotta
setblock 517 128 268 minecraft:magenta_terracotta
setblock 517 128 270 minecraft:magenta_terracotta
fill 518 128 242 519 128 243 minecraft:dark_oak_planks
fill 519 128 244 519 128 245 minecraft:spruce_planks
setblock 521 128 228 minecraft:magenta_terracotta
setblock 521 128 270 minecraft:magenta_terracotta
setblock 525 128 228 minecraft:magenta_terracotta
setblock 525 128 270 minecraft:magenta_terracotta
setblock 529 128 228 minecraft:magenta_terracotta
setblock 529 128 270 minecraft:magenta_terracotta
setblock 533 128 228 minecraft:magenta_terracotta
setblock 533 128 270 minecraft:magenta_terracotta
setblock 537 128 228 minecraft:magenta_terracotta
setblock 537 128 270 minecraft:magenta_terracotta
fill 539 128 270 539 129 270 minecraft:purple_terracotta
setblock 541 128 228 minecraft:magenta_terracotta
setblock 541 128 270 minecraft:magenta_terracotta
setblock 543 128 270 minecraft:light_gray_terracotta
setblock 545 128 228 minecraft:magenta_terracotta
fill 545 128 246 545 129 246 minecraft:white_stained_glass
setblock 545 128 270 minecraft:magenta_terracotta
fill 546 128 244 546 129 244 minecraft:white_stained_glass
setblock 549 128 228 minecraft:magenta_terracotta
fill 549 128 245 549 129 245 minecraft:white_stained_glass
setblock 549 128 270 minecraft:magenta_terracotta
setblock 553 128 228 minecraft:magenta_terracotta
setblock 553 128 270 minecraft:magenta_terracotta
setblock 557 128 228 minecraft:magenta_terracotta
setblock 557 128 270 minecraft:magenta_terracotta
setblock 559 128 228 minecraft:magenta_terracotta
setblock 559 128 232 minecraft:magenta_terracotta
setblock 559 128 236 minecraft:magenta_terracotta
setblock 559 128 240 minecraft:magenta_terracotta
setblock 559 128 244 minecraft:magenta_terracotta
setblock 559 128 248 minecraft:gray_terracotta
setblock 559 128 252 minecraft:magenta_terracotta
setblock 559 128 256 minecraft:magenta_terracotta
setblock 559 128 260 minecraft:magenta_terracotta
setblock 559 128 264 minecraft:magenta_terracotta
setblock 559 128 268 minecraft:magenta_terracotta
fill 517 129 228 517 131 228 minecraft:purple_terracotta
fill 517 129 232 517 131 232 minecraft:purple_terracotta
fill 517 129 236 517 131 236 minecraft:purple_terracotta
fill 517 129 240 517 131 240 minecraft:purple_terracotta
fill 517 129 244 517 131 244 minecraft:purple_terracotta
fill 517 129 248 517 131 248 minecraft:purple_terracotta
fill 517 129 252 517 131 252 minecraft:purple_terracotta
fill 517 129 256 517 131 256 minecraft:purple_terracotta
fill 517 129 260 517 131 260 minecraft:purple_terracotta
fill 517 129 264 517 131 264 minecraft:purple_terracotta
fill 517 129 268 517 131 268 minecraft:purple_terracotta
setblock 517 129 270 minecraft:purple_terracotta
fill 518 129 244 519 129 245 minecraft:dark_oak_planks
fill 519 129 246 519 129 247 minecraft:spruce_planks
setblock 520 129 231 minecraft:light[level=11]
setblock 520 129 239 minecraft:light[level=11]
setblock 520 129 247 minecraft:light[level=11]
setblock 520 129 255 minecraft:light[level=11]
setblock 520 129 263 minecraft:light[level=11]
fill 521 129 228 521 131 228 minecraft:purple_terracotta
fill 521 129 270 521 130 270 minecraft:purple_terracotta
fill 525 129 228 525 131 228 minecraft:purple_terracotta
fill 525 129 270 525 131 270 minecraft:purple_terracotta
setblock 528 129 231 minecraft:light[level=11]
setblock 528 129 239 minecraft:light[level=11]
setblock 528 129 247 minecraft:light[level=11]
setblock 528 129 255 minecraft:light[level=11]
setblock 528 129 263 minecraft:light[level=11]
fill 529 129 228 529 131 228 minecraft:purple_terracotta
fill 529 129 270 529 131 270 minecraft:purple_terracotta
fill 531 129 269 535 129 269 minecraft:gold_block
fill 533 129 228 533 131 228 minecraft:purple_terracotta
fill 533 129 270 533 131 270 minecraft:purple_terracotta
setblock 536 129 231 minecraft:light[level=11]
setblock 536 129 239 minecraft:light[level=11]
setblock 536 129 255 minecraft:light[level=11]
setblock 536 129 263 minecraft:light[level=11]
fill 537 129 228 537 131 228 minecraft:purple_terracotta
fill 537 129 270 537 131 270 minecraft:purple_terracotta
fill 541 129 228 541 131 228 minecraft:purple_terracotta
fill 541 129 270 541 131 270 minecraft:purple_terracotta
setblock 543 129 270 minecraft:purple_terracotta
setblock 544 129 231 minecraft:light[level=11]
setblock 544 129 239 minecraft:light[level=11]
setblock 544 129 247 minecraft:light[level=11]
setblock 544 129 255 minecraft:light[level=11]
setblock 544 129 263 minecraft:light[level=11]
fill 545 129 228 545 131 228 minecraft:purple_terracotta
fill 545 129 270 545 131 270 minecraft:purple_terracotta
fill 546 129 245 548 131 246 minecraft:white_concrete
setblock 546 129 247 minecraft:white_stained_glass
setblock 547 129 244 minecraft:black_concrete
fill 547 129 247 547 131 247 minecraft:white_concrete
fill 549 129 228 549 131 228 minecraft:purple_terracotta
fill 549 129 270 549 131 270 minecraft:purple_terracotta
setblock 552 129 231 minecraft:light[level=11]
setblock 552 129 239 minecraft:light[level=11]
setblock 552 129 247 minecraft:light[level=11]
setblock 552 129 255 minecraft:light[level=11]
setblock 552 129 263 minecraft:light[level=11]
fill 553 129 228 553 131 228 minecraft:purple_terracotta
fill 553 129 270 553 131 270 minecraft:purple_terracotta
fill 557 129 228 557 131 228 minecraft:purple_terracotta
fill 557 129 270 557 131 270 minecraft:purple_terracotta
setblock 559 129 228 minecraft:purple_terracotta
fill 559 129 232 559 131 232 minecraft:purple_terracotta
fill 559 129 236 559 131 236 minecraft:purple_terracotta
fill 559 129 240 559 131 240 minecraft:purple_terracotta
fill 559 129 244 559 131 244 minecraft:purple_terracotta
fill 559 129 248 559 131 248 minecraft:purple_terracotta
fill 559 129 252 559 131 252 minecraft:purple_terracotta
fill 559 129 256 559 131 256 minecraft:purple_terracotta
fill 559 129 260 559 131 260 minecraft:purple_terracotta
fill 559 129 264 559 131 264 minecraft:purple_terracotta
fill 559 129 268 559 131 268 minecraft:purple_terracotta
setblock 517 130 230 minecraft:magenta_terracotta
setblock 517 130 234 minecraft:magenta_terracotta
setblock 517 130 238 minecraft:magenta_terracotta
setblock 517 130 242 minecraft:magenta_terracotta
setblock 517 130 246 minecraft:magenta_terracotta
setblock 517 130 250 minecraft:magenta_terracotta
setblock 517 130 254 minecraft:magenta_terracotta
setblock 517 130 258 minecraft:magenta_terracotta
setblock 517 130 262 minecraft:magenta_terracotta
setblock 517 130 266 minecraft:magenta_terracotta
setblock 517 130 270 minecraft:magenta_terracotta
fill 518 130 246 519 130 247 minecraft:dark_oak_planks
setblock 519 130 228 minecraft:magenta_terracotta
fill 519 130 248 519 130 249 minecraft:spruce_planks
setblock 519 130 270 minecraft:magenta_terracotta
setblock 523 130 228 minecraft:magenta_terracotta
setblock 523 130 270 minecraft:magenta_terracotta
setblock 527 130 228 minecraft:magenta_terracotta
setblock 527 130 270 minecraft:magenta_terracotta
setblock 531 130 228 minecraft:magenta_terracotta
fill 531 130 269 531 135 269 minecraft:gold_block
setblock 531 130 270 minecraft:magenta_terracotta
fill 532 130 269 534 131 269 minecraft:black_concrete
setblock 535 130 228 minecraft:magenta_terracotta
fill 535 130 269 535 135 269 minecraft:gold_block
setblock 535 130 270 minecraft:magenta_terracotta
setblock 539 130 228 minecraft:magenta_terracotta
setblock 539 130 270 minecraft:magenta_terracotta
setblock 543 130 228 minecraft:magenta_terracotta
setblock 543 130 270 minecraft:magenta_terracotta
setblock 546 130 247 minecraft:white_concrete
setblock 547 130 228 minecraft:magenta_terracotta
setblock 547 130 244 minecraft:white_concrete
setblock 547 130 270 minecraft:magenta_terracotta
setblock 548 130 244 minecraft:black_concrete
setblock 548 130 247 minecraft:white_concrete
setblock 551 130 228 minecraft:magenta_terracotta
setblock 551 130 270 minecraft:magenta_terracotta
setblock 555 130 228 minecraft:magenta_terracotta
setblock 555 130 270 minecraft:magenta_terracotta
setblock 559 130 228 minecraft:magenta_terracotta
setblock 559 130 230 minecraft:magenta_terracotta
setblock 559 130 234 minecraft:magenta_terracotta
setblock 559 130 238 minecraft:magenta_terracotta
setblock 559 130 242 minecraft:magenta_terracotta
setblock 559 130 246 minecraft:magenta_terracotta
setblock 559 130 250 minecraft:magenta_terracotta
setblock 559 130 254 minecraft:magenta_terracotta
setblock 559 130 258 minecraft:magenta_terracotta
setblock 559 130 262 minecraft:magenta_terracotta
setblock 559 130 266 minecraft:magenta_terracotta
setblock 559 130 270 minecraft:magenta_terracotta
fill 517 131 230 517 133 230 minecraft:purple_terracotta
fill 517 131 234 517 133 234 minecraft:purple_terracotta
fill 517 131 238 517 133 238 minecraft:purple_terracotta
fill 517 131 242 517 133 242 minecraft:purple_terracotta
fill 517 131 246 517 133 246 minecraft:purple_terracotta
fill 517 131 250 517 133 250 minecraft:purple_terracotta
fill 517 131 254 517 133 254 minecraft:purple_terracotta
fill 517 131 258 517 133 258 minecraft:purple_terracotta
fill 517 131 262 517 133 262 minecraft:purple_terracotta
fill 517 131 266 517 133 266 minecraft:purple_terracotta
setblock 517 131 270 minecraft:purple_terracotta
fill 518 131 248 519 131 249 minecraft:dark_oak_planks
fill 519 131 228 519 133 228 minecraft:purple_terracotta
fill 519 131 250 519 131 251 minecraft:spruce_planks
fill 519 131 270 519 133 270 minecraft:purple_terracotta
setblock 521 131 270 minecraft:gray_terracotta
fill 523 131 228 523 133 228 minecraft:purple_terracotta
fill 523 131 270 523 133 270 minecraft:purple_terracotta
fill 527 131 228 527 133 228 minecraft:purple_terracotta
fill 527 131 270 527 133 270 minecraft:purple_terracotta
fill 531 131 228 531 133 228 minecraft:purple_terracotta
fill 531 131 270 531 133 270 minecraft:purple_terracotta
fill 535 131 228 535 133 228 minecraft:purple_terracotta
fill 535 131 270 535 133 270 minecraft:purple_terracotta
fill 539 131 228 539 133 228 minecraft:purple_terracotta
fill 539 131 270 539 133 270 minecraft:purple_terracotta
fill 543 131 228 543 133 228 minecraft:purple_terracotta
fill 543 131 270 543 133 270 minecraft:purple_terracotta
fill 547 131 228 547 133 228 minecraft:purple_terracotta
fill 547 131 270 547 133 270 minecraft:purple_terracotta
fill 551 131 228 551 133 228 minecraft:purple_terracotta
fill 551 131 270 551 133 270 minecraft:purple_terracotta
fill 555 131 228 555 133 228 minecraft:purple_terracotta
fill 555 131 270 555 133 270 minecraft:purple_terracotta
setblock 559 131 228 minecraft:purple_terracotta
fill 559 131 230 559 133 230 minecraft:purple_terracotta
fill 559 131 234 559 133 234 minecraft:purple_terracotta
fill 559 131 238 559 133 238 minecraft:purple_terracotta
fill 559 131 242 559 133 242 minecraft:purple_terracotta
fill 559 131 246 559 133 246 minecraft:purple_terracotta
fill 559 131 250 559 133 250 minecraft:purple_terracotta
fill 559 131 254 559 133 254 minecraft:purple_terracotta
fill 559 131 258 559 133 258 minecraft:purple_terracotta
fill 559 131 262 559 133 262 minecraft:purple_terracotta
fill 559 131 266 559 133 266 minecraft:purple_terracotta
fill 559 131 270 559 133 270 minecraft:purple_terracotta
setblock 517 132 228 minecraft:magenta_terracotta
setblock 517 132 229 minecraft:black_terracotta
setblock 517 132 232 minecraft:magenta_terracotta
setblock 517 132 236 minecraft:magenta_terracotta
setblock 517 132 240 minecraft:magenta_terracotta
setblock 517 132 244 minecraft:magenta_terracotta
setblock 517 132 248 minecraft:magenta_terracotta
setblock 517 132 252 minecraft:magenta_terracotta
setblock 517 132 256 minecraft:magenta_terracotta
setblock 517 132 260 minecraft:magenta_terracotta
setblock 517 132 264 minecraft:magenta_terracotta
setblock 517 132 265 minecraft:black_terracotta
setblock 517 132 268 minecraft:magenta_terracotta
setblock 517 132 270 minecraft:magenta_terracotta
fill 518 132 250 519 132 251 minecraft:dark_oak_planks
fill 519 132 252 519 132 253 minecraft:spruce_planks
setblock 521 132 228 minecraft:magenta_terracotta
setblock 521 132 270 minecraft:magenta_terracotta
setblock 525 132 228 minecraft:magenta_terracotta
setblock 525 132 270 minecraft:magenta_terracotta
setblock 529 132 228 minecraft:magenta_terracotta
setblock 529 132 270 minecraft:magenta_terracotta
fill 532 132 269 534 132 269 minecraft:light_gray_concrete
setblock 533 132 228 minecraft:magenta_terracotta
setblock 533 132 270 minecraft:magenta_terracotta
setblock 537 132 228 minecraft:magenta_terracotta
setblock 537 132 270 minecraft:magenta_terracotta
setblock 541 132 228 minecraft:magenta_terracotta
setblock 541 132 270 minecraft:magenta_terracotta
setblock 545 132 228 minecraft:magenta_terracotta
setblock 545 132 270 minecraft:magenta_terracotta
setblock 549 132 228 minecraft:magenta_terracotta
setblock 549 132 270 minecraft:magenta_terracotta
setblock 553 132 228 minecraft:magenta_terracotta
setblock 553 132 270 minecraft:magenta_terracotta
setblock 557 132 228 minecraft:magenta_terracotta
setblock 557 132 270 minecraft:magenta_terracotta
setblock 559 132 228 minecraft:magenta_terracotta
setblock 559 132 232 minecraft:magenta_terracotta
setblock 559 132 236 minecraft:magenta_terracotta
setblock 559 132 240 minecraft:magenta_terracotta
setblock 559 132 244 minecraft:magenta_terracotta
setblock 559 132 248 minecraft:magenta_terracotta
setblock 559 132 252 minecraft:magenta_terracotta
setblock 559 132 256 minecraft:magenta_terracotta
setblock 559 132 260 minecraft:magenta_terracotta
setblock 559 132 264 minecraft:magenta_terracotta
setblock 559 132 268 minecraft:magenta_terracotta
fill 517 133 228 517 135 229 minecraft:purple_terracotta
fill 517 133 232 517 135 232 minecraft:purple_terracotta
fill 517 133 236 517 135 236 minecraft:purple_terracotta
fill 517 133 240 517 135 240 minecraft:purple_terracotta
fill 517 133 244 517 135 244 minecraft:purple_terracotta
fill 517 133 248 517 135 248 minecraft:purple_terracotta
fill 517 133 252 517 135 252 minecraft:purple_terracotta
fill 517 133 256 517 135 256 minecraft:purple_terracotta
fill 517 133 260 517 135 260 minecraft:purple_terracotta
fill 517 133 264 517 135 265 minecraft:purple_terracotta
fill 517 133 268 517 135 268 minecraft:purple_terracotta
setblock 517 133 270 minecraft:purple_terracotta
fill 518 133 252 519 133 253 minecraft:dark_oak_planks
fill 519 133 254 519 133 255 minecraft:spruce_planks
setblock 520 133 231 minecraft:light[level=12]
setblock 520 133 238 minecraft:light[level=12]
setblock 520 133 245 minecraft:light[level=12]
setblock 520 133 252 minecraft:light[level=12]
setblock 520 133 259 minecraft:light[level=12]
setblock 520 133 266 minecraft:light[level=12]
fill 521 133 228 521 135 228 minecraft:purple_terracotta
fill 521 133 270 521 135 270 minecraft:purple_terracotta
fill 525 133 228 525 135 228 minecraft:purple_terracotta
fill 525 133 270 525 135 270 minecraft:purple_terracotta
setblock 527 133 231 minecraft:light[level=12]
setblock 527 133 238 minecraft:light[level=12]
setblock 527 133 245 minecraft:light[level=12]
setblock 527 133 252 minecraft:light[level=12]
setblock 527 133 259 minecraft:light[level=12]
setblock 527 133 266 minecraft:light[level=12]
fill 529 133 228 529 135 228 minecraft:purple_terracotta
fill 529 133 270 529 135 270 minecraft:purple_terracotta
setblock 532 133 269 minecraft:green_concrete
fill 533 133 228 533 135 228 minecraft:purple_terracotta
fill 533 133 269 533 134 269 minecraft:light_gray_concrete
fill 533 133 270 533 135 270 minecraft:purple_terracotta
setblock 534 133 231 minecraft:light[level=12]
setblock 534 133 238 minecraft:light[level=12]
setblock 534 133 245 minecraft:light[level=12]
setblock 534 133 252 minecraft:light[level=12]
setblock 534 133 259 minecraft:light[level=12]
setblock 534 133 266 minecraft:light[level=12]
setblock 534 133 269 minecraft:green_concrete
fill 537 133 228 537 135 228 minecraft:purple_terracotta
fill 537 133 270 537 135 270 minecraft:purple_terracotta
fill 541 133 228 541 135 228 minecraft:purple_terracotta
setblock 541 133 231 minecraft:light[level=12]
setblock 541 133 238 minecraft:light[level=12]
setblock 541 133 245 minecraft:light[level=12]
setblock 541 133 252 minecraft:light[level=12]
setblock 541 133 259 minecraft:light[level=12]
setblock 541 133 266 minecraft:light[level=12]
fill 541 133 270 541 135 270 minecraft:purple_terracotta
fill 545 133 228 545 135 228 minecraft:purple_terracotta
fill 545 133 270 545 135 270 minecraft:purple_terracotta
setblock 548 133 231 minecraft:light[level=12]
setblock 548 133 238 minecraft:light[level=12]
setblock 548 133 245 minecraft:light[level=12]
setblock 548 133 252 minecraft:light[level=12]
setblock 548 133 259 minecraft:light[level=12]
setblock 548 133 266 minecraft:light[level=12]
fill 549 133 228 549 135 228 minecraft:purple_terracotta
fill 549 133 270 549 135 270 minecraft:purple_terracotta
fill 553 133 228 553 135 228 minecraft:purple_terracotta
fill 553 133 270 553 135 270 minecraft:purple_terracotta
setblock 555 133 231 minecraft:light[level=12]
setblock 555 133 238 minecraft:light[level=12]
setblock 555 133 245 minecraft:light[level=12]
setblock 555 133 252 minecraft:light[level=12]
setblock 555 133 259 minecraft:light[level=12]
setblock 555 133 266 minecraft:light[level=12]
fill 557 133 228 557 135 228 minecraft:purple_terracotta
fill 557 133 270 557 135 270 minecraft:purple_terracotta
setblock 559 133 228 minecraft:purple_terracotta
fill 559 133 232 559 135 232 minecraft:purple_terracotta
fill 559 133 236 559 135 236 minecraft:purple_terracotta
fill 559 133 240 559 135 240 minecraft:purple_terracotta
fill 559 133 244 559 135 244 minecraft:purple_terracotta
fill 559 133 248 559 135 248 minecraft:purple_terracotta
fill 559 133 252 559 135 252 minecraft:purple_terracotta
fill 559 133 256 559 135 256 minecraft:purple_terracotta
fill 559 133 260 559 135 260 minecraft:purple_terracotta
fill 559 133 264 559 135 264 minecraft:purple_terracotta
fill 559 133 268 559 135 268 minecraft:purple_terracotta
setblock 517 134 230 minecraft:magenta_terracotta
setblock 517 134 234 minecraft:magenta_terracotta
setblock 517 134 238 minecraft:magenta_terracotta
setblock 517 134 242 minecraft:magenta_terracotta
setblock 517 134 246 minecraft:magenta_terracotta
setblock 517 134 250 minecraft:magenta_terracotta
setblock 517 134 254 minecraft:magenta_terracotta
setblock 517 134 258 minecraft:magenta_terracotta
setblock 517 134 262 minecraft:magenta_terracotta
setblock 517 134 266 minecraft:magenta_terracotta
setblock 517 134 270 minecraft:magenta_terracotta
fill 518 134 254 519 134 255 minecraft:dark_oak_planks
setblock 519 134 228 minecraft:magenta_terracotta
fill 519 134 256 519 134 257 minecraft:spruce_planks
setblock 519 134 270 minecraft:magenta_terracotta
setblock 523 134 228 minecraft:magenta_terracotta
setblock 523 134 270 minecraft:magenta_terracotta
setblock 527 134 228 minecraft:magenta_terracotta
setblock 527 134 270 minecraft:magenta_terracotta
setblock 531 134 228 minecraft:magenta_terracotta
setblock 531 134 270 minecraft:magenta_terracotta
setblock 532 134 269 minecraft:light_gray_concrete
setblock 534 134 269 minecraft:light_gray_concrete
setblock 535 134 228 minecraft:magenta_terracotta
setblock 535 134 270 minecraft:magenta_terracotta
setblock 539 134 228 minecraft:magenta_terracotta
setblock 539 134 270 minecraft:magenta_terracotta
setblock 543 134 228 minecraft:magenta_terracotta
setblock 543 134 270 minecraft:magenta_terracotta
setblock 547 134 228 minecraft:magenta_terracotta
setblock 547 134 270 minecraft:magenta_terracotta
setblock 551 134 228 minecraft:magenta_terracotta
setblock 551 134 270 minecraft:magenta_terracotta
setblock 555 134 228 minecraft:magenta_terracotta
setblock 555 134 270 minecraft:magenta_terracotta
setblock 559 134 228 minecraft:magenta_terracotta
setblock 559 134 230 minecraft:magenta_terracotta
setblock 559 134 234 minecraft:magenta_terracotta
setblock 559 134 238 minecraft:magenta_terracotta
setblock 559 134 242 minecraft:magenta_terracotta
setblock 559 134 246 minecraft:magenta_terracotta
setblock 559 134 250 minecraft:magenta_terracotta
setblock 559 134 254 minecraft:magenta_terracotta
setblock 559 134 255 minecraft:light_gray_terracotta
setblock 559 134 258 minecraft:magenta_terracotta
setblock 559 134 262 minecraft:magenta_terracotta
setblock 559 134 266 minecraft:black_terracotta
setblock 559 134 270 minecraft:magenta_terracotta
fill 517 135 230 517 137 230 minecraft:purple_terracotta
fill 517 135 234 517 137 234 minecraft:purple_terracotta
fill 517 135 238 517 137 238 minecraft:purple_terracotta
fill 517 135 242 517 137 242 minecraft:purple_terracotta
fill 517 135 246 517 137 246 minecraft:purple_terracotta
fill 517 135 250 517 137 250 minecraft:purple_terracotta
fill 517 135 254 517 137 254 minecraft:purple_terracotta
fill 517 135 258 517 137 258 minecraft:purple_terracotta
fill 517 135 262 517 137 262 minecraft:purple_terracotta
fill 517 135 266 517 137 266 minecraft:purple_terracotta
setblock 517 135 270 minecraft:purple_terracotta
fill 518 135 256 519 135 257 minecraft:dark_oak_planks
fill 519 135 228 519 137 228 minecraft:purple_terracotta
fill 519 135 258 519 135 259 minecraft:spruce_planks
fill 519 135 270 519 137 270 minecraft:purple_terracotta
fill 523 135 228 523 137 228 minecraft:purple_terracotta
fill 523 135 270 523 137 270 minecraft:purple_terracotta
fill 527 135 228 527 137 228 minecraft:purple_terracotta
fill 527 135 270 527 137 270 minecraft:purple_terracotta
fill 531 135 228 531 137 228 minecraft:purple_terracotta
fill 531 135 270 531 137 270 minecraft:purple_terracotta
fill 532 135 269 534 135 269 minecraft:gold_block
fill 535 135 228 535 137 228 minecraft:purple_terracotta
fill 535 135 270 535 137 270 minecraft:purple_terracotta
fill 539 135 228 539 137 228 minecraft:purple_terracotta
fill 539 135 270 539 137 270 minecraft:purple_terracotta
fill 543 135 228 543 137 228 minecraft:purple_terracotta
fill 543 135 270 543 137 270 minecraft:purple_terracotta
fill 547 135 228 547 137 228 minecraft:purple_terracotta
fill 547 135 270 547 137 270 minecraft:purple_terracotta
fill 551 135 228 551 137 228 minecraft:purple_terracotta
fill 551 135 270 551 137 270 minecraft:purple_terracotta
fill 555 135 228 555 137 228 minecraft:purple_terracotta
fill 555 135 270 555 137 270 minecraft:purple_terracotta
setblock 559 135 228 minecraft:purple_terracotta
fill 559 135 230 559 137 230 minecraft:purple_terracotta
fill 559 135 234 559 137 234 minecraft:purple_terracotta
fill 559 135 238 559 137 238 minecraft:purple_terracotta
fill 559 135 242 559 137 242 minecraft:purple_terracotta
fill 559 135 246 559 137 246 minecraft:purple_terracotta
fill 559 135 250 559 137 250 minecraft:purple_terracotta
fill 559 135 254 559 137 255 minecraft:purple_terracotta
fill 559 135 258 559 137 258 minecraft:purple_terracotta
fill 559 135 262 559 137 262 minecraft:purple_terracotta
fill 559 135 266 559 137 266 minecraft:purple_terracotta
fill 559 135 270 559 137 270 minecraft:purple_terracotta
setblock 517 136 228 minecraft:magenta_terracotta
fill 517 136 229 517 207 229 minecraft:purple_terracotta
setblock 517 136 232 minecraft:magenta_terracotta
setblock 517 136 236 minecraft:magenta_terracotta
setblock 517 136 240 minecraft:magenta_terracotta
setblock 517 136 244 minecraft:magenta_terracotta
setblock 517 136 248 minecraft:magenta_terracotta
setblock 517 136 252 minecraft:magenta_terracotta
setblock 517 136 256 minecraft:magenta_terracotta
setblock 517 136 260 minecraft:magenta_terracotta
setblock 517 136 264 minecraft:magenta_terracotta
fill 517 136 265 517 207 265 minecraft:purple_terracotta
setblock 517 136 268 minecraft:magenta_terracotta
setblock 517 136 270 minecraft:magenta_terracotta
fill 518 136 258 519 136 259 minecraft:dark_oak_planks
fill 519 136 260 519 136 261 minecraft:spruce_planks
setblock 521 136 228 minecraft:magenta_terracotta
setblock 521 136 270 minecraft:magenta_terracotta
setblock 525 136 228 minecraft:magenta_terracotta
setblock 525 136 270 minecraft:magenta_terracotta
setblock 529 136 228 minecraft:magenta_terracotta
setblock 529 136 270 minecraft:magenta_terracotta
setblock 533 136 228 minecraft:magenta_terracotta
setblock 533 136 270 minecraft:magenta_terracotta
setblock 537 136 228 minecraft:magenta_terracotta
setblock 537 136 270 minecraft:magenta_terracotta
setblock 541 136 228 minecraft:magenta_terracotta
setblock 541 136 270 minecraft:magenta_terracotta
setblock 545 136 228 minecraft:magenta_terracotta
setblock 545 136 270 minecraft:magenta_terracotta
setblock 549 136 228 minecraft:magenta_terracotta
setblock 549 136 270 minecraft:magenta_terracotta
setblock 553 136 228 minecraft:magenta_terracotta
setblock 553 136 270 minecraft:magenta_terracotta
setblock 557 136 228 minecraft:magenta_terracotta
setblock 557 136 270 minecraft:magenta_terracotta
setblock 559 136 228 minecraft:magenta_terracotta
setblock 559 136 232 minecraft:magenta_terracotta
setblock 559 136 236 minecraft:magenta_terracotta
setblock 559 136 240 minecraft:magenta_terracotta
setblock 559 136 244 minecraft:magenta_terracotta
setblock 559 136 248 minecraft:magenta_terracotta
setblock 559 136 252 minecraft:magenta_terracotta
setblock 559 136 256 minecraft:magenta_terracotta
setblock 559 136 260 minecraft:magenta_terracotta
setblock 559 136 264 minecraft:magenta_terracotta
setblock 559 136 268 minecraft:magenta_terracotta
fill 517 137 228 517 139 228 minecraft:purple_terracotta
fill 517 137 232 517 139 232 minecraft:purple_terracotta
fill 517 137 236 517 139 236 minecraft:purple_terracotta
fill 517 137 240 517 139 240 minecraft:purple_terracotta
fill 517 137 244 517 139 244 minecraft:purple_terracotta
fill 517 137 248 517 139 248 minecraft:purple_terracotta
fill 517 137 252 517 139 252 minecraft:purple_terracotta
fill 517 137 256 517 139 256 minecraft:purple_terracotta
fill 517 137 260 517 139 260 minecraft:purple_terracotta
fill 517 137 264 517 139 264 minecraft:purple_terracotta
setblock 517 137 268 minecraft:purple_terracotta
setblock 517 137 270 minecraft:purple_terracotta
fill 518 137 260 519 137 261 minecraft:dark_oak_planks
fill 519 137 262 519 137 263 minecraft:spruce_planks
setblock 520 137 231 minecraft:light[level=11]
setblock 520 137 239 minecraft:light[level=11]
setblock 520 137 247 minecraft:light[level=11]
setblock 520 137 255 minecraft:light[level=11]
setblock 520 137 263 minecraft:light[level=11]
fill 521 137 228 521 139 228 minecraft:purple_terracotta
fill 521 137 270 521 139 270 minecraft:purple_terracotta
fill 525 137 228 525 139 228 minecraft:purple_terracotta
fill 525 137 270 525 139 270 minecraft:purple_terracotta
setblock 528 137 231 minecraft:light[level=11]
setblock 528 137 239 minecraft:light[level=11]
setblock 528 137 247 minecraft:light[level=11]
setblock 528 137 255 minecraft:light[level=11]
setblock 528 137 263 minecraft:light[level=11]
fill 529 137 228 529 139 228 minecraft:purple_terracotta
fill 529 137 270 529 139 270 minecraft:purple_terracotta
fill 533 137 228 533 139 228 minecraft:purple_terracotta
fill 533 137 270 533 139 270 minecraft:purple_terracotta
setblock 536 137 231 minecraft:light[level=11]
setblock 536 137 239 minecraft:light[level=11]
setblock 536 137 255 minecraft:light[level=11]
setblock 536 137 263 minecraft:light[level=11]
fill 537 137 228 537 139 228 minecraft:purple_terracotta
fill 537 137 270 537 139 270 minecraft:purple_terracotta
fill 541 137 228 541 139 228 minecraft:purple_terracotta
fill 541 137 270 541 139 270 minecraft:purple_terracotta
setblock 544 137 231 minecraft:light[level=11]
setblock 544 137 239 minecraft:light[level=11]
setblock 544 137 247 minecraft:light[level=11]
setblock 544 137 255 minecraft:light[level=11]
setblock 544 137 263 minecraft:light[level=11]
fill 545 137 228 545 139 228 minecraft:purple_terracotta
fill 545 137 270 545 139 270 minecraft:purple_terracotta
fill 549 137 228 549 139 228 minecraft:purple_terracotta
fill 549 137 270 549 139 270 minecraft:purple_terracotta
setblock 552 137 231 minecraft:light[level=11]
setblock 552 137 239 minecraft:light[level=11]
setblock 552 137 247 minecraft:light[level=11]
setblock 552 137 255 minecraft:light[level=11]
setblock 552 137 263 minecraft:light[level=11]
fill 553 137 228 553 139 228 minecraft:purple_terracotta
fill 553 137 270 553 139 270 minecraft:purple_terracotta
fill 557 137 228 557 139 228 minecraft:purple_terracotta
fill 557 137 270 557 139 270 minecraft:purple_terracotta
setblock 559 137 228 minecraft:purple_terracotta
fill 559 137 232 559 139 232 minecraft:purple_terracotta
fill 559 137 236 559 139 236 minecraft:purple_terracotta
fill 559 137 240 559 139 240 minecraft:purple_terracotta
fill 559 137 244 559 139 244 minecraft:purple_terracotta
fill 559 137 248 559 139 248 minecraft:purple_terracotta
fill 559 137 252 559 139 252 minecraft:purple_terracotta
fill 559 137 256 559 139 256 minecraft:purple_terracotta
fill 559 137 260 559 139 260 minecraft:purple_terracotta
fill 559 137 264 559 139 264 minecraft:purple_terracotta
fill 559 137 268 559 139 268 minecraft:purple_terracotta
setblock 517 138 230 minecraft:magenta_terracotta
setblock 517 138 234 minecraft:magenta_terracotta
setblock 517 138 238 minecraft:magenta_terracotta
setblock 517 138 242 minecraft:magenta_terracotta
setblock 517 138 246 minecraft:magenta_terracotta
setblock 517 138 250 minecraft:magenta_terracotta
setblock 517 138 254 minecraft:magenta_terracotta
setblock 517 138 258 minecraft:magenta_terracotta
setblock 517 138 262 minecraft:magenta_terracotta
setblock 517 138 266 minecraft:magenta_terracotta
setblock 517 138 268 minecraft:gray_terracotta
setblock 517 138 270 minecraft:magenta_terracotta
fill 518 138 262 519 138 263 minecraft:dark_oak_planks
setblock 519 138 228 minecraft:magenta_terracotta
fill 519 138 264 519 138 265 minecraft:spruce_planks
setblock 519 138 270 minecraft:magenta_terracotta
setblock 523 138 228 minecraft:magenta_terracotta
setblock 523 138 270 minecraft:magenta_terracotta
setblock 527 138 228 minecraft:magenta_terracotta
setblock 527 138 270 minecraft:magenta_terracotta
setblock 531 138 228 minecraft:magenta_terracotta
setblock 531 138 270 minecraft:magenta_terracotta
setblock 535 138 228 minecraft:magenta_terracotta
setblock 535 138 270 minecraft:magenta_terracotta
setblock 539 138 228 minecraft:magenta_terracotta
setblock 539 138 270 minecraft:magenta_terracotta
setblock 543 138 228 minecraft:magenta_terracotta
setblock 543 138 270 minecraft:magenta_terracotta
setblock 547 138 228 minecraft:magenta_terracotta
setblock 547 138 270 minecraft:magenta_terracotta
setblock 551 138 228 minecraft:magenta_terracotta
setblock 551 138 270 minecraft:magenta_terracotta
setblock 555 138 228 minecraft:magenta_terracotta
setblock 555 138 270 minecraft:magenta_terracotta
setblock 559 138 228 minecraft:magenta_terracotta
setblock 559 138 230 minecraft:magenta_terracotta
setblock 559 138 234 minecraft:magenta_terracotta
setblock 559 138 238 minecraft:magenta_terracotta
setblock 559 138 242 minecraft:magenta_terracotta
setblock 559 138 246 minecraft:magenta_terracotta
setblock 559 138 250 minecraft:magenta_terracotta
setblock 559 138 254 minecraft:magenta_terracotta
fill 559 138 255 559 207 255 minecraft:purple_terracotta
setblock 559 138 258 minecraft:magenta_terracotta
setblock 559 138 262 minecraft:magenta_terracotta
setblock 559 138 266 minecraft:magenta_terracotta
setblock 559 138 269 minecraft:light_gray_terracotta
setblock 559 138 270 minecraft:magenta_terracotta
fill 517 139 230 517 141 230 minecraft:purple_terracotta
fill 517 139 234 517 141 234 minecraft:purple_terracotta
fill 517 139 238 517 141 238 minecraft:purple_terracotta
fill 517 139 242 517 141 242 minecraft:purple_terracotta
fill 517 139 246 517 141 246 minecraft:purple_terracotta
fill 517 139 250 517 141 250 minecraft:purple_terracotta
fill 517 139 254 517 141 254 minecraft:purple_terracotta
fill 517 139 258 517 141 258 minecraft:purple_terracotta
fill 517 139 262 517 141 262 minecraft:purple_terracotta
fill 517 139 266 517 141 266 minecraft:purple_terracotta
setblock 517 139 268 minecraft:purple_terracotta
setblock 517 139 270 minecraft:purple_terracotta
fill 518 139 264 519 139 265 minecraft:dark_oak_planks
fill 519 139 228 519 141 228 minecraft:purple_terracotta
fill 519 139 266 519 139 267 minecraft:spruce_planks
fill 519 139 270 519 141 270 minecraft:purple_terracotta
setblock 520 139 231 minecraft:light[level=12]
setblock 520 139 238 minecraft:light[level=12]
setblock 520 139 245 minecraft:light[level=12]
setblock 520 139 252 minecraft:light[level=12]
setblock 520 139 259 minecraft:light[level=12]
setblock 520 139 266 minecraft:light[level=12]
fill 523 139 228 523 141 228 minecraft:purple_terracotta
fill 523 139 270 523 141 270 minecraft:purple_terracotta
fill 527 139 228 527 141 228 minecraft:purple_terracotta
setblock 527 139 231 minecraft:light[level=12]
setblock 527 139 238 minecraft:light[level=12]
setblock 527 139 245 minecraft:light[level=12]
setblock 527 139 252 minecraft:light[level=12]
setblock 527 139 259 minecraft:light[level=12]
setblock 527 139 266 minecraft:light[level=12]
fill 527 139 270 527 141 270 minecraft:purple_terracotta
fill 531 139 228 531 141 228 minecraft:purple_terracotta
fill 531 139 270 531 141 270 minecraft:purple_terracotta
setblock 534 139 231 minecraft:light[level=12]
setblock 534 139 238 minecraft:light[level=12]
setblock 534 139 245 minecraft:light[level=12]
setblock 534 139 252 minecraft:light[level=12]
setblock 534 139 259 minecraft:light[level=12]
setblock 534 139 266 minecraft:light[level=12]
fill 535 139 228 535 141 228 minecraft:purple_terracotta
fill 535 139 270 535 141 270 minecraft:purple_terracotta
fill 539 139 228 539 141 228 minecraft:purple_terracotta
fill 539 139 270 539 141 270 minecraft:purple_terracotta
setblock 541 139 231 minecraft:light[level=12]
setblock 541 139 238 minecraft:light[level=12]
setblock 541 139 245 minecraft:light[level=12]
setblock 541 139 252 minecraft:light[level=12]
setblock 541 139 259 minecraft:light[level=12]
setblock 541 139 266 minecraft:light[level=12]
fill 543 139 228 543 141 228 minecraft:purple_terracotta
fill 543 139 270 543 141 270 minecraft:purple_terracotta
fill 547 139 228 547 141 228 minecraft:purple_terracotta
fill 547 139 270 547 141 270 minecraft:purple_terracotta
setblock 548 139 231 minecraft:light[level=12]
setblock 548 139 238 minecraft:light[level=12]
setblock 548 139 245 minecraft:light[level=12]
setblock 548 139 252 minecraft:light[level=12]
setblock 548 139 259 minecraft:light[level=12]
setblock 548 139 266 minecraft:light[level=12]
fill 551 139 228 551 141 228 minecraft:purple_terracotta
fill 551 139 247 555 140 251 minecraft:dark_oak_planks
fill 551 139 270 551 141 270 minecraft:purple_terracotta
fill 555 139 228 555 141 228 minecraft:purple_terracotta
setblock 555 139 231 minecraft:light[level=12]
setblock 555 139 238 minecraft:light[level=12]
setblock 555 139 245 minecraft:light[level=12]
setblock 555 139 252 minecraft:light[level=12]
setblock 555 139 259 minecraft:light[level=12]
setblock 555 139 266 minecraft:light[level=12]
fill 555 139 270 555 141 270 minecraft:purple_terracotta
fill 556 139 249 557 139 249 minecraft:dark_oak_planks
setblock 559 139 228 minecraft:purple_terracotta
fill 559 139 230 559 141 230 minecraft:purple_terracotta
fill 559 139 234 559 141 234 minecraft:purple_terracotta
fill 559 139 238 559 141 238 minecraft:purple_terracotta
fill 559 139 242 559 141 242 minecraft:purple_terracotta
fill 559 139 246 559 141 246 minecraft:purple_terracotta
fill 559 139 250 559 141 250 minecraft:purple_terracotta
fill 559 139 254 559 141 254 minecraft:purple_terracotta
fill 559 139 258 559 141 258 minecraft:purple_terracotta
fill 559 139 262 559 141 262 minecraft:purple_terracotta
fill 559 139 266 559 141 266 minecraft:purple_terracotta
fill 559 139 269 559 141 270 minecraft:purple_terracotta
setblock 517 140 228 minecraft:magenta_terracotta
setblock 517 140 232 minecraft:magenta_terracotta
setblock 517 140 236 minecraft:magenta_terracotta
setblock 517 140 240 minecraft:magenta_terracotta
setblock 517 140 244 minecraft:magenta_terracotta
setblock 517 140 248 minecraft:magenta_terracotta
setblock 517 140 252 minecraft:magenta_terracotta
setblock 517 140 256 minecraft:magenta_terracotta
setblock 517 140 260 minecraft:magenta_terracotta
setblock 517 140 264 minecraft:magenta_terracotta
setblock 517 140 268 minecraft:magenta_terracotta
setblock 517 140 270 minecraft:magenta_terracotta
fill 518 140 266 519 140 267 minecraft:dark_oak_planks
setblock 519 140 268 minecraft:spruce_planks
setblock 521 140 228 minecraft:magenta_terracotta
setblock 521 140 270 minecraft:magenta_terracotta
setblock 525 140 228 minecraft:magenta_terracotta
setblock 525 140 270 minecraft:magenta_terracotta
setblock 529 140 228 minecraft:magenta_terracotta
setblock 529 140 270 minecraft:magenta_terracotta
setblock 533 140 228 minecraft:magenta_terracotta
setblock 533 140 270 minecraft:magenta_terracotta
setblock 537 140 228 minecraft:magenta_terracotta
setblock 537 140 270 minecraft:magenta_terracotta
setblock 541 140 228 minecraft:magenta_terracotta
setblock 541 140 270 minecraft:magenta_terracotta
setblock 545 140 228 minecraft:magenta_terracotta
setblock 545 140 270 minecraft:magenta_terracotta
setblock 549 140 228 minecraft:magenta_terracotta
setblock 549 140 270 minecraft:magenta_terracotta
setblock 553 140 228 minecraft:magenta_terracotta
setblock 553 140 270 minecraft:magenta_terracotta
setblock 557 140 228 minecraft:magenta_terracotta
setblock 557 140 270 minecraft:magenta_terracotta
setblock 559 140 228 minecraft:magenta_terracotta
setblock 559 140 232 minecraft:magenta_terracotta
setblock 559 140 233 minecraft:light_gray_terracotta
setblock 559 140 236 minecraft:magenta_terracotta
setblock 559 140 240 minecraft:magenta_terracotta
setblock 559 140 244 minecraft:magenta_terracotta
setblock 559 140 248 minecraft:magenta_terracotta
setblock 559 140 252 minecraft:magenta_terracotta
setblock 559 140 256 minecraft:magenta_terracotta
setblock 559 140 260 minecraft:magenta_terracotta
setblock 559 140 264 minecraft:magenta_terracotta
setblock 559 140 268 minecraft:magenta_terracotta
fill 517 141 228 517 143 228 minecraft:purple_terracotta
fill 517 141 232 517 143 232 minecraft:purple_terracotta
setblock 517 141 236 minecraft:purple_terracotta
fill 517 141 240 517 143 240 minecraft:purple_terracotta
fill 517 141 244 517 143 244 minecraft:purple_terracotta
fill 517 141 248 517 143 248 minecraft:purple_terracotta
fill 517 141 252 517 143 252 minecraft:purple_terracotta
fill 517 141 256 517 143 256 minecraft:purple_terracotta
fill 517 141 260 517 143 260 minecraft:purple_terracotta
fill 517 141 264 517 143 264 minecraft:purple_terracotta
fill 517 141 268 517 143 268 minecraft:purple_terracotta
setblock 517 141 270 minecraft:purple_terracotta
fill 518 141 268 519 141 269 minecraft:dark_oak_planks
fill 520 141 268 521 141 268 minecraft:spruce_planks
fill 521 141 228 521 143 228 minecraft:purple_terracotta
fill 521 141 270 521 143 270 minecraft:purple_terracotta
fill 525 141 228 525 143 228 minecraft:purple_terracotta
fill 525 141 270 525 143 270 minecraft:purple_terracotta
fill 529 141 228 529 143 228 minecraft:purple_terracotta
fill 529 141 270 529 143 270 minecraft:purple_terracotta
fill 533 141 228 533 143 228 minecraft:purple_terracotta
fill 533 141 270 533 143 270 minecraft:purple_terracotta
setblock 534 141 270 minecraft:black_terracotta
fill 537 141 228 537 143 228 minecraft:purple_terracotta
fill 537 141 270 537 143 270 minecraft:purple_terracotta
fill 541 141 228 541 143 228 minecraft:purple_terracotta
fill 541 141 270 541 143 270 minecraft:purple_terracotta
fill 545 141 228 545 143 228 minecraft:purple_terracotta
fill 545 141 270 545 143 270 minecraft:purple_terracotta
fill 549 141 228 549 143 228 minecraft:purple_terracotta
fill 549 141 270 549 143 270 minecraft:purple_terracotta
fill 552 141 249 554 145 249 minecraft:stripped_dark_oak_log
fill 553 141 228 553 143 228 minecraft:purple_terracotta
fill 553 141 270 553 143 270 minecraft:purple_terracotta
fill 557 141 228 557 143 228 minecraft:purple_terracotta
fill 557 141 270 557 143 270 minecraft:purple_terracotta
setblock 559 141 228 minecraft:purple_terracotta
fill 559 141 232 559 143 233 minecraft:purple_terracotta
fill 559 141 236 559 143 236 minecraft:purple_terracotta
fill 559 141 240 559 143 240 minecraft:purple_terracotta
fill 559 141 244 559 143 244 minecraft:purple_terracotta
fill 559 141 248 559 143 248 minecraft:purple_terracotta
fill 559 141 252 559 143 252 minecraft:purple_terracotta
fill 559 141 256 559 143 256 minecraft:purple_terracotta
fill 559 141 260 559 143 260 minecraft:purple_terracotta
fill 559 141 264 559 143 264 minecraft:purple_terracotta
fill 559 141 268 559 143 268 minecraft:purple_terracotta
setblock 517 142 230 minecraft:magenta_terracotta
setblock 517 142 234 minecraft:magenta_terracotta
setblock 517 142 236 minecraft:light_gray_terracotta
setblock 517 142 238 minecraft:magenta_terracotta
setblock 517 142 242 minecraft:magenta_terracotta
setblock 517 142 246 minecraft:magenta_terracotta
setblock 517 142 250 minecraft:magenta_terracotta
setblock 517 142 254 minecraft:magenta_terracotta
setblock 517 142 258 minecraft:magenta_terracotta
setblock 517 142 262 minecraft:magenta_terracotta
setblock 517 142 266 minecraft:magenta_terracotta
setblock 517 142 270 minecraft:magenta_terracotta
setblock 519 142 228 minecraft:magenta_terracotta
setblock 519 142 270 minecraft:magenta_terracotta
fill 520 142 268 521 142 269 minecraft:dark_oak_planks
fill 522 142 268 523 142 268 minecraft:spruce_planks
setblock 523 142 228 minecraft:magenta_terracotta
setblock 523 142 270 minecraft:magenta_terracotta
setblock 527 142 228 minecraft:magenta_terracotta
setblock 527 142 270 minecraft:magenta_terracotta
setblock 531 142 228 minecraft:magenta_terracotta
setblock 531 142 270 minecraft:magenta_terracotta
fill 534 142 270 534 207 270 minecraft:purple_terracotta
setblock 535 142 228 minecraft:magenta_terracotta
setblock 535 142 270 minecraft:magenta_terracotta
setblock 539 142 228 minecraft:magenta_terracotta
setblock 539 142 270 minecraft:magenta_terracotta
setblock 543 142 228 minecraft:magenta_terracotta
setblock 543 142 270 minecraft:magenta_terracotta
setblock 547 142 228 minecraft:magenta_terracotta
setblock 547 142 270 minecraft:magenta_terracotta
setblock 551 142 228 minecraft:magenta_terracotta
setblock 551 142 270 minecraft:magenta_terracotta
setblock 555 142 228 minecraft:magenta_terracotta
setblock 555 142 270 minecraft:magenta_terracotta
setblock 559 142 228 minecraft:magenta_terracotta
setblock 559 142 230 minecraft:magenta_terracotta
setblock 559 142 234 minecraft:magenta_terracotta
setblock 559 142 238 minecraft:magenta_terracotta
setblock 559 142 242 minecraft:magenta_terracotta
setblock 559 142 246 minecraft:magenta_terracotta
setblock 559 142 250 minecraft:magenta_terracotta
setblock 559 142 254 minecraft:magenta_terracotta
setblock 559 142 258 minecraft:magenta_terracotta
setblock 559 142 262 minecraft:magenta_terracotta
setblock 559 142 266 minecraft:magenta_terracotta
fill 559 142 269 559 207 269 minecraft:purple_terracotta
setblock 559 142 270 minecraft:magenta_terracotta
fill 517 143 230 517 145 230 minecraft:purple_terracotta
fill 517 143 234 517 145 234 minecraft:purple_terracotta
setblock 517 143 236 minecraft:purple_terracotta
fill 517 143 238 517 145 238 minecraft:purple_terracotta
fill 517 143 242 517 145 242 minecraft:purple_terracotta
setblock 517 143 246 minecraft:purple_terracotta
fill 517 143 250 517 145 250 minecraft:purple_terracotta
fill 517 143 254 517 145 254 minecraft:purple_terracotta
fill 517 143 258 517 145 258 minecraft:purple_terracotta
fill 517 143 262 517 145 262 minecraft:purple_terracotta
fill 517 143 266 517 145 266 minecraft:purple_terracotta
setblock 517 143 270 minecraft:purple_terracotta
fill 519 143 228 519 145 228 minecraft:purple_terracotta
fill 519 143 270 519 145 270 minecraft:purple_terracotta
fill 522 143 268 523 143 269 minecraft:dark_oak_planks
fill 523 143 228 523 145 228 minecraft:purple_terracotta
fill 523 143 270 523 145 270 minecraft:purple_terracotta
fill 524 143 268 525 143 268 minecraft:spruce_planks
fill 527 143 228 527 145 228 minecraft:purple_terracotta
fill 527 143 270 527 145 270 minecraft:purple_terracotta
fill 531 143 228 531 145 228 minecraft:purple_terracotta
fill 531 143 270 531 145 270 minecraft:purple_terracotta
fill 535 143 228 535 145 228 minecraft:purple_terracotta
fill 535 143 270 535 145 270 minecraft:purple_terracotta
fill 539 143 228 539 145 228 minecraft:purple_terracotta
fill 539 143 270 539 145 270 minecraft:purple_terracotta
fill 543 143 228 543 145 228 minecraft:purple_terracotta
fill 543 143 270 543 145 270 minecraft:purple_terracotta
fill 547 143 228 547 145 228 minecraft:purple_terracotta
fill 547 143 270 547 145 270 minecraft:purple_terracotta
fill 551 143 228 551 145 228 minecraft:purple_terracotta
fill 551 143 270 551 145 270 minecraft:purple_terracotta
fill 555 143 228 555 145 228 minecraft:purple_terracotta
fill 555 143 270 555 145 270 minecraft:purple_terracotta
setblock 559 143 228 minecraft:purple_terracotta
fill 559 143 230 559 145 230 minecraft:purple_terracotta
fill 559 143 234 559 145 234 minecraft:purple_terracotta
fill 559 143 238 559 145 238 minecraft:purple_terracotta
fill 559 143 242 559 145 242 minecraft:purple_terracotta
fill 559 143 246 559 145 246 minecraft:purple_terracotta
fill 559 143 250 559 145 250 minecraft:purple_terracotta
fill 559 143 254 559 145 254 minecraft:purple_terracotta
fill 559 143 258 559 145 258 minecraft:purple_terracotta
fill 559 143 262 559 145 262 minecraft:purple_terracotta
fill 559 143 266 559 145 266 minecraft:purple_terracotta
fill 559 143 270 559 145 270 minecraft:purple_terracotta
setblock 517 144 228 minecraft:magenta_terracotta
setblock 517 144 232 minecraft:magenta_terracotta
setblock 517 144 236 minecraft:magenta_terracotta
setblock 517 144 240 minecraft:magenta_terracotta
setblock 517 144 244 minecraft:magenta_terracotta
setblock 517 144 246 minecraft:black_terracotta
setblock 517 144 248 minecraft:magenta_terracotta
setblock 517 144 252 minecraft:magenta_terracotta
setblock 517 144 256 minecraft:magenta_terracotta
setblock 517 144 260 minecraft:magenta_terracotta
setblock 517 144 264 minecraft:magenta_terracotta
setblock 517 144 268 minecraft:magenta_terracotta
setblock 517 144 270 minecraft:magenta_terracotta
setblock 521 144 228 minecraft:magenta_terracotta
setblock 521 144 270 minecraft:magenta_terracotta
fill 524 144 268 525 144 269 minecraft:dark_oak_planks
setblock 525 144 228 minecraft:magenta_terracotta
setblock 525 144 270 minecraft:magenta_terracotta
fill 526 144 268 527 144 268 minecraft:spruce_planks
setblock 529 144 228 minecraft:magenta_terracotta
setblock 529 144 270 minecraft:magenta_terracotta
setblock 533 144 228 minecraft:magenta_terracotta
setblock 533 144 270 minecraft:magenta_terracotta
setblock 537 144 228 minecraft:magenta_terracotta
setblock 537 144 270 minecraft:magenta_terracotta
setblock 541 144 228 minecraft:magenta_terracotta
setblock 541 144 270 minecraft:magenta_terracotta
setblock 545 144 228 minecraft:magenta_terracotta
setblock 545 144 270 minecraft:magenta_terracotta
setblock 549 144 228 minecraft:magenta_terracotta
setblock 549 144 270 minecraft:magenta_terracotta
setblock 553 144 228 minecraft:magenta_terracotta
fill 553 144 248 553 145 248 minecraft:stripped_dark_oak_log
fill 553 144 250 553 145 250 minecraft:stripped_dark_oak_log
setblock 553 144 270 minecraft:magenta_terracotta
setblock 557 144 228 minecraft:magenta_terracotta
setblock 557 144 270 minecraft:magenta_terracotta
setblock 559 144 228 minecraft:magenta_terracotta
setblock 559 144 232 minecraft:magenta_terracotta
fill 559 144 233 559 207 233 minecraft:purple_terracotta
setblock 559 144 236 minecraft:magenta_terracotta
setblock 559 144 240 minecraft:magenta_terracotta
setblock 559 144 244 minecraft:magenta_terracotta
setblock 559 144 248 minecraft:magenta_terracotta
setblock 559 144 252 minecraft:magenta_terracotta
setblock 559 144 256 minecraft:magenta_terracotta
setblock 559 144 260 minecraft:magenta_terracotta
setblock 559 144 264 minecraft:magenta_terracotta
setblock 559 144 268 minecraft:magenta_terracotta
fill 517 145 228 517 147 228 minecraft:purple_terracotta
fill 517 145 232 517 147 232 minecraft:purple_terracotta
fill 517 145 236 517 147 236 minecraft:purple_terracotta
fill 517 145 240 517 147 240 minecraft:purple_terracotta
fill 517 145 244 517 147 244 minecraft:purple_terracotta
setblock 517 145 246 minecraft:purple_terracotta
fill 517 145 248 517 147 248 minecraft:purple_terracotta
fill 517 145 252 517 147 252 minecraft:purple_terracotta
fill 517 145 256 517 147 256 minecraft:purple_terracotta
fill 517 145 260 517 147 260 minecraft:purple_terracotta
fill 517 145 264 517 147 264 minecraft:purple_terracotta
fill 517 145 268 517 147 268 minecraft:purple_terracotta
setblock 517 145 269 minecraft:gray_terracotta
setblock 517 145 270 minecraft:purple_terracotta
setblock 520 145 231 minecraft:light[level=11]
setblock 520 145 238 minecraft:light[level=12]
setblock 520 145 239 minecraft:light[level=11]
setblock 520 145 245 minecraft:light[level=12]
setblock 520 145 247 minecraft:light[level=11]
setblock 520 145 252 minecraft:light[level=12]
setblock 520 145 255 minecraft:light[level=11]
setblock 520 145 259 minecraft:light[level=12]
setblock 520 145 263 minecraft:light[level=11]
setblock 520 145 266 minecraft:light[level=12]
fill 521 145 228 521 147 228 minecraft:purple_terracotta
fill 521 145 270 521 147 270 minecraft:purple_terracotta
fill 525 145 228 525 147 228 minecraft:purple_terracotta
fill 525 145 270 525 147 270 minecraft:purple_terracotta
fill 526 145 268 527 145 269 minecraft:dark_oak_planks
setblock 527 145 231 minecraft:light[level=12]
setblock 527 145 238 minecraft:light[level=12]
setblock 527 145 245 minecraft:light[level=12]
setblock 527 145 252 minecraft:light[level=12]
setblock 527 145 259 minecraft:light[level=12]
setblock 527 145 266 minecraft:light[level=12]
setblock 528 145 231 minecraft:light[level=11]
setblock 528 145 239 minecraft:light[level=11]
setblock 528 145 247 minecraft:light[level=11]
setblock 528 145 255 minecraft:light[level=11]
setblock 528 145 263 minecraft:light[level=11]
fill 528 145 268 529 145 268 minecraft:spruce_planks
fill 529 145 228 529 147 228 minecraft:purple_terracotta
fill 529 145 270 529 147 270 minecraft:purple_terracotta
fill 533 145 228 533 147 228 minecraft:purple_terracotta
fill 533 145 270 533 147 270 minecraft:purple_terracotta
setblock 534 145 231 minecraft:light[level=12]
setblock 534 145 238 minecraft:light[level=12]
setblock 534 145 245 minecraft:light[level=12]
setblock 534 145 252 minecraft:light[level=12]
setblock 534 145 259 minecraft:light[level=12]
setblock 534 145 266 minecraft:light[level=12]
setblock 536 145 231 minecraft:light[level=11]
setblock 536 145 239 minecraft:light[level=11]
setblock 536 145 255 minecraft:light[level=11]
setblock 536 145 263 minecraft:light[level=11]
fill 537 145 228 537 147 228 minecraft:purple_terracotta
fill 537 145 270 537 147 270 minecraft:purple_terracotta
fill 541 145 228 541 147 228 minecraft:purple_terracotta
setblock 541 145 231 minecraft:light[level=12]
setblock 541 145 238 minecraft:light[level=12]
setblock 541 145 245 minecraft:light[level=12]
setblock 541 145 252 minecraft:light[level=12]
setblock 541 145 259 minecraft:light[level=12]
setblock 541 145 266 minecraft:light[level=12]
fill 541 145 270 541 147 270 minecraft:purple_terracotta
setblock 544 145 231 minecraft:light[level=11]
setblock 544 145 239 minecraft:light[level=11]
setblock 544 145 247 minecraft:light[level=11]
setblock 544 145 255 minecraft:light[level=11]
setblock 544 145 263 minecraft:light[level=11]
fill 545 145 228 545 147 228 minecraft:purple_terracotta
fill 545 145 270 545 147 270 minecraft:purple_terracotta
setblock 548 145 231 minecraft:light[level=12]
setblock 548 145 238 minecraft:light[level=12]
setblock 548 145 245 minecraft:light[level=12]
setblock 548 145 252 minecraft:light[level=12]
setblock 548 145 259 minecraft:light[level=12]
setblock 548 145 266 minecraft:light[level=12]
fill 549 145 228 549 147 228 minecraft:purple_terracotta
fill 549 145 270 549 147 270 minecraft:purple_terracotta
setblock 552 145 231 minecraft:light[level=11]
setblock 552 145 239 minecraft:light[level=11]
setblock 552 145 247 minecraft:light[level=11]
setblock 552 145 255 minecraft:light[level=11]
setblock 552 145 263 minecraft:light[level=11]
fill 553 145 228 553 147 228 minecraft:purple_terracotta
fill 553 145 270 553 147 270 minecraft:purple_terracotta
setblock 555 145 231 minecraft:light[level=12]
setblock 555 145 238 minecraft:light[level=12]
setblock 555 145 245 minecraft:light[level=12]
setblock 555 145 252 minecraft:light[level=12]
setblock 555 145 259 minecraft:light[level=12]
setblock 555 145 266 minecraft:light[level=12]
fill 557 145 228 557 147 228 minecraft:purple_terracotta
fill 557 145 270 557 147 270 minecraft:purple_terracotta
setblock 559 145 228 minecraft:purple_terracotta
fill 559 145 232 559 147 232 minecraft:purple_terracotta
fill 559 145 236 559 147 236 minecraft:purple_terracotta
fill 559 145 240 559 147 240 minecraft:purple_terracotta
fill 559 145 244 559 147 244 minecraft:purple_terracotta
fill 559 145 248 559 147 248 minecraft:purple_terracotta
fill 559 145 252 559 147 252 minecraft:purple_terracotta
fill 559 145 256 559 147 256 minecraft:purple_terracotta
fill 559 145 260 559 147 260 minecraft:purple_terracotta
fill 559 145 264 559 147 264 minecraft:purple_terracotta
fill 559 145 268 559 147 268 minecraft:purple_terracotta
setblock 517 146 230 minecraft:magenta_terracotta
setblock 517 146 234 minecraft:magenta_terracotta
setblock 517 146 238 minecraft:magenta_terracotta
setblock 517 146 242 minecraft:magenta_terracotta
setblock 517 146 246 minecraft:magenta_terracotta
setblock 517 146 250 minecraft:magenta_terracotta
setblock 517 146 254 minecraft:magenta_terracotta
setblock 517 146 258 minecraft:magenta_terracotta
setblock 517 146 262 minecraft:magenta_terracotta
setblock 517 146 266 minecraft:magenta_terracotta
fill 517 146 269 517 207 269 minecraft:purple_terracotta
setblock 517 146 270 minecraft:magenta_terracotta
setblock 519 146 228 minecraft:magenta_terracotta
setblock 519 146 270 minecraft:magenta_terracotta
setblock 523 146 228 minecraft:magenta_terracotta
setblock 523 146 270 minecraft:magenta_terracotta
setblock 527 146 228 minecraft:magenta_terracotta
setblock 527 146 270 minecraft:magenta_terracotta
fill 528 146 268 529 146 269 minecraft:dark_oak_planks
fill 530 146 268 531 146 268 minecraft:spruce_planks
setblock 531 146 228 minecraft:magenta_terracotta
setblock 531 146 270 minecraft:magenta_terracotta
setblock 535 146 228 minecraft:magenta_terracotta
setblock 535 146 270 minecraft:magenta_terracotta
setblock 539 146 228 minecraft:magenta_terracotta
setblock 539 146 270 minecraft:magenta_terracotta
setblock 543 146 228 minecraft:magenta_terracotta
setblock 543 146 270 minecraft:magenta_terracotta
setblock 547 146 228 minecraft:magenta_terracotta
setblock 547 146 270 minecraft:magenta_terracotta
setblock 551 146 228 minecraft:magenta_terracotta
setblock 551 146 270 minecraft:magenta_terracotta
setblock 555 146 228 minecraft:magenta_terracotta
setblock 555 146 270 minecraft:magenta_terracotta
setblock 559 146 228 minecraft:magenta_terracotta
setblock 559 146 230 minecraft:magenta_terracotta
setblock 559 146 234 minecraft:magenta_terracotta
setblock 559 146 238 minecraft:magenta_terracotta
setblock 559 146 242 minecraft:magenta_terracotta
setblock 559 146 246 minecraft:magenta_terracotta
setblock 559 146 250 minecraft:magenta_terracotta
setblock 559 146 254 minecraft:magenta_terracotta
setblock 559 146 258 minecraft:magenta_terracotta
setblock 559 146 262 minecraft:magenta_terracotta
setblock 559 146 266 minecraft:magenta_terracotta
setblock 559 146 270 minecraft:magenta_terracotta
fill 517 147 230 517 149 230 minecraft:purple_terracotta
fill 517 147 234 517 149 234 minecraft:purple_terracotta
fill 517 147 238 517 149 238 minecraft:purple_terracotta
fill 517 147 242 517 149 242 minecraft:purple_terracotta
fill 517 147 246 517 149 246 minecraft:purple_terracotta
fill 517 147 250 517 148 250 minecraft:purple_terracotta
fill 517 147 254 517 149 254 minecraft:purple_terracotta
fill 517 147 258 517 149 258 minecraft:purple_terracotta
fill 517 147 262 517 149 262 minecraft:purple_terracotta
fill 517 147 266 517 149 266 minecraft:purple_terracotta
setblock 517 147 270 minecraft:purple_terracotta
fill 519 147 228 519 149 228 minecraft:purple_terracotta
fill 519 147 270 519 149 270 minecraft:purple_terracotta
fill 523 147 228 523 149 228 minecraft:purple_terracotta
fill 523 147 257 523 163 257 minecraft:iron_bars
fill 523 147 270 523 149 270 minecraft:purple_terracotta
fill 527 147 228 527 149 228 minecraft:purple_terracotta
fill 527 147 270 527 149 270 minecraft:purple_terracotta
fill 530 147 268 531 147 269 minecraft:dark_oak_planks
fill 531 147 228 531 149 228 minecraft:purple_terracotta
fill 531 147 270 531 149 270 minecraft:purple_terracotta
fill 532 147 268 533 147 268 minecraft:spruce_planks
fill 535 147 228 535 149 228 minecraft:purple_terracotta
fill 535 147 270 535 149 270 minecraft:purple_terracotta
fill 539 147 228 539 149 228 minecraft:purple_terracotta
fill 539 147 270 539 149 270 minecraft:purple_terracotta
fill 543 147 228 543 149 228 minecraft:purple_terracotta
fill 543 147 270 543 149 270 minecraft:purple_terracotta
fill 545 147 245 546 149 245 minecraft:white_stained_glass
fill 546 147 244 547 149 244 minecraft:white_stained_glass
fill 547 147 228 547 149 228 minecraft:purple_terracotta
fill 547 147 246 547 149 246 minecraft:white_stained_glass
fill 547 147 270 547 149 270 minecraft:purple_terracotta
fill 551 147 228 551 149 228 minecraft:purple_terracotta
fill 551 147 270 551 149 270 minecraft:purple_terracotta
fill 555 147 228 555 149 228 minecraft:purple_terracotta
fill 555 147 270 555 149 270 minecraft:purple_terracotta
setblock 559 147 228 minecraft:purple_terracotta
fill 559 147 230 559 149 230 minecraft:purple_terracotta
fill 559 147 234 559 149 234 minecraft:purple_terracotta
fill 559 147 238 559 149 238 minecraft:purple_terracotta
fill 559 147 242 559 149 242 minecraft:purple_terracotta
fill 559 147 246 559 149 246 minecraft:purple_terracotta
setblock 559 147 247 minecraft:black_terracotta
fill 559 147 250 559 149 250 minecraft:purple_terracotta
fill 559 147 254 559 149 254 minecraft:purple_terracotta
fill 559 147 258 559 149 258 minecraft:purple_terracotta
fill 559 147 262 559 149 262 minecraft:purple_terracotta
fill 559 147 266 559 149 266 minecraft:purple_terracotta
fill 559 147 270 559 149 270 minecraft:purple_terracotta
setblock 517 148 228 minecraft:magenta_terracotta
setblock 517 148 232 minecraft:magenta_terracotta
setblock 517 148 236 minecraft:magenta_terracotta
setblock 517 148 240 minecraft:magenta_terracotta
setblock 517 148 244 minecraft:magenta_terracotta
setblock 517 148 248 minecraft:magenta_terracotta
setblock 517 148 252 minecraft:magenta_terracotta
setblock 517 148 256 minecraft:magenta_terracotta
setblock 517 148 260 minecraft:magenta_terracotta
setblock 517 148 264 minecraft:magenta_terracotta
setblock 517 148 268 minecraft:magenta_terracotta
setblock 517 148 270 minecraft:magenta_terracotta
setblock 521 148 228 minecraft:magenta_terracotta
setblock 521 148 270 minecraft:magenta_terracotta
setblock 525 148 228 minecraft:magenta_terracotta
setblock 525 148 270 minecraft:magenta_terracotta
setblock 529 148 228 minecraft:magenta_terracotta
setblock 529 148 270 minecraft:magenta_terracotta
fill 532 148 268 533 148 269 minecraft:dark_oak_planks
setblock 533 148 228 minecraft:magenta_terracotta
setblock 533 148 270 minecraft:magenta_terracotta
fill 534 148 268 535 148 268 minecraft:spruce_planks
setblock 537 148 228 minecraft:magenta_terracotta
setblock 537 148 270 minecraft:magenta_terracotta
setblock 538 148 228 minecraft:gray_terracotta
setblock 541 148 228 minecraft:magenta_terracotta
setblock 541 148 270 minecraft:magenta_terracotta
setblock 545 148 228 minecraft:magenta_terracotta
fill 545 148 244 545 149 244 minecraft:white_stained_glass
fill 545 148 246 546 149 246 minecraft:white_stained_glass
setblock 545 148 270 minecraft:magenta_terracotta
fill 546 148 243 547 149 243 minecraft:white_stained_glass
fill 547 148 245 548 149 245 minecraft:white_stained_glass
fill 548 148 244 548 151 244 minecraft:white_stained_glass
setblock 549 148 228 minecraft:magenta_terracotta
setblock 549 148 270 minecraft:magenta_terracotta
setblock 553 148 228 minecraft:magenta_terracotta
setblock 553 148 270 minecraft:magenta_terracotta
setblock 557 148 228 minecraft:magenta_terracotta
setblock 557 148 270 minecraft:magenta_terracotta
setblock 559 148 228 minecraft:magenta_terracotta
setblock 559 148 232 minecraft:magenta_terracotta
setblock 559 148 236 minecraft:magenta_terracotta
setblock 559 148 240 minecraft:magenta_terracotta
setblock 559 148 244 minecraft:magenta_terracotta
fill 559 148 247 559 207 247 minecraft:purple_terracotta
setblock 559 148 248 minecraft:magenta_terracotta
setblock 559 148 252 minecraft:magenta_terracotta
setblock 559 148 256 minecraft:magenta_terracotta
setblock 559 148 260 minecraft:magenta_terracotta
setblock 559 148 264 minecraft:magenta_terracotta
setblock 559 148 268 minecraft:magenta_terracotta
fill 517 149 228 517 151 228 minecraft:purple_terracotta
fill 517 149 232 517 151 232 minecraft:purple_terracotta
fill 517 149 236 517 151 236 minecraft:purple_terracotta
fill 517 149 240 517 151 240 minecraft:purple_terracotta
fill 517 149 244 517 151 244 minecraft:purple_terracotta
fill 517 149 248 517 151 248 minecraft:purple_terracotta
setblock 517 149 250 minecraft:black_terracotta
fill 517 149 252 517 151 252 minecraft:purple_terracotta
fill 517 149 256 517 151 256 minecraft:purple_terracotta
fill 517 149 260 517 151 260 minecraft:purple_terracotta
fill 517 149 264 517 151 264 minecraft:purple_terracotta
fill 517 149 268 517 151 268 minecraft:purple_terracotta
setblock 517 149 270 minecraft:purple_terracotta
fill 521 149 228 521 151 228 minecraft:purple_terracotta
fill 521 149 270 521 151 270 minecraft:purple_terracotta
fill 525 149 228 525 151 228 minecraft:purple_terracotta
fill 525 149 270 525 151 270 minecraft:purple_terracotta
fill 529 149 228 529 151 228 minecraft:purple_terracotta
fill 529 149 270 529 151 270 minecraft:purple_terracotta
fill 533 149 228 533 151 228 minecraft:purple_terracotta
fill 533 149 270 533 151 270 minecraft:purple_terracotta
fill 534 149 268 535 149 269 minecraft:dark_oak_planks
fill 536 149 268 537 149 268 minecraft:spruce_planks
fill 537 149 228 538 151 228 minecraft:purple_terracotta
fill 537 149 270 537 151 270 minecraft:purple_terracotta
schedule function dropper:buildpart/59_2 1t
