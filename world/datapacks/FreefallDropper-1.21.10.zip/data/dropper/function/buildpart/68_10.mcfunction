fill 391 282 276 403 282 276 minecraft:terracotta
fill 391 282 277 403 282 277 minecraft:red_terracotta
setblock 391 282 290 minecraft:red_terracotta
setblock 391 282 291 minecraft:yellow_terracotta
setblock 391 282 300 minecraft:yellow_terracotta
fill 391 282 301 391 282 302 minecraft:red_terracotta
fill 391 282 315 403 282 315 minecraft:red_terracotta
fill 391 282 316 403 282 316 minecraft:terracotta
setblock 392 282 290 minecraft:yellow_terracotta
setblock 392 282 301 minecraft:yellow_terracotta
setblock 392 282 302 minecraft:red_terracotta
fill 393 282 288 415 282 288 minecraft:red_terracotta
fill 393 282 289 399 282 289 minecraft:yellow_terracotta
fill 393 282 302 398 282 302 minecraft:yellow_terracotta
fill 399 282 290 400 282 290 minecraft:yellow_terracotta
fill 399 282 301 400 282 301 minecraft:yellow_terracotta
fill 399 282 302 416 282 302 minecraft:red_terracotta
fill 400 282 289 415 282 289 minecraft:red_terracotta
fill 400 282 300 401 282 300 minecraft:yellow_terracotta
fill 401 282 290 416 282 290 minecraft:red_terracotta
setblock 401 282 291 minecraft:yellow_terracotta
fill 401 282 299 402 282 299 minecraft:yellow_terracotta
fill 401 282 301 416 282 301 minecraft:red_terracotta
fill 402 282 291 416 282 291 minecraft:red_terracotta
fill 402 282 292 402 282 298 minecraft:yellow_terracotta
fill 402 282 300 416 282 300 minecraft:red_terracotta
fill 403 282 292 416 282 294 minecraft:red_terracotta
fill 403 282 295 403 282 296 minecraft:yellow_terracotta
fill 403 282 297 416 282 299 minecraft:red_terracotta
fill 404 282 277 405 282 277 minecraft:terracotta
fill 404 282 295 416 282 296 minecraft:red_terracotta
fill 404 282 315 405 282 315 minecraft:terracotta
fill 406 282 278 407 282 278 minecraft:terracotta
fill 406 282 314 407 282 314 minecraft:terracotta
fill 408 282 279 408 283 279 minecraft:terracotta
fill 408 282 313 408 283 313 minecraft:terracotta
setblock 410 282 280 minecraft:terracotta
setblock 410 282 312 minecraft:terracotta
setblock 411 282 281 minecraft:terracotta
setblock 411 282 311 minecraft:terracotta
setblock 412 282 282 minecraft:terracotta
setblock 412 282 310 minecraft:terracotta
setblock 413 282 283 minecraft:terracotta
setblock 413 282 309 minecraft:terracotta
fill 414 282 285 414 283 285 minecraft:terracotta
fill 414 282 307 414 283 307 minecraft:terracotta
fill 415 282 286 415 282 287 minecraft:terracotta
fill 415 282 305 415 282 306 minecraft:terracotta
fill 416 282 288 416 282 289 minecraft:terracotta
fill 416 282 303 416 282 304 minecraft:terracotta
fill 417 282 290 417 282 302 minecraft:terracotta
fill 377 283 276 377 283 279 minecraft:red_terracotta
setblock 377 283 280 minecraft:stripped_oak_log
fill 377 283 281 377 283 284 minecraft:red_terracotta
setblock 377 283 285 minecraft:stripped_oak_log
fill 377 283 286 377 283 289 minecraft:red_terracotta
setblock 377 283 290 minecraft:stripped_oak_log
fill 377 283 291 377 285 292 minecraft:red_terracotta
fill 377 283 293 377 283 299 minecraft:terracotta
setblock 377 283 300 minecraft:stripped_oak_log
fill 377 283 301 377 284 302 minecraft:red_terracotta
fill 377 283 303 377 285 305 minecraft:stripped_oak_log
setblock 377 283 314 minecraft:red_terracotta
setblock 377 283 315 minecraft:stripped_oak_log
fill 377 283 316 380 283 316 minecraft:red_terracotta
fill 378 283 276 380 283 276 minecraft:red_terracotta
fill 378 283 289 378 283 292 minecraft:terracotta
fill 378 283 293 387 283 299 minecraft:red_terracotta
fill 378 283 300 378 283 303 minecraft:terracotta
fill 378 283 304 378 285 305 minecraft:stripped_oak_log
fill 379 283 287 379 283 288 minecraft:terracotta
fill 379 283 289 388 283 292 minecraft:red_terracotta
fill 379 283 300 389 283 303 minecraft:red_terracotta
fill 379 283 304 379 283 305 minecraft:terracotta
setblock 380 283 286 minecraft:terracotta
fill 380 283 287 392 283 288 minecraft:red_terracotta
fill 380 283 304 414 283 305 minecraft:red_terracotta
setblock 380 283 306 minecraft:terracotta
setblock 381 283 276 minecraft:stripped_oak_log
fill 381 283 277 384 283 277 minecraft:red_terracotta
setblock 381 283 284 minecraft:terracotta
fill 381 283 286 413 283 286 minecraft:red_terracotta
fill 381 283 306 413 283 306 minecraft:red_terracotta
setblock 381 283 308 minecraft:terracotta
setblock 381 283 316 minecraft:stripped_oak_log
fill 382 283 276 385 283 276 minecraft:red_terracotta
setblock 382 283 283 minecraft:terracotta
fill 382 283 284 412 283 284 minecraft:red_terracotta
fill 382 283 308 412 283 308 minecraft:red_terracotta
setblock 382 283 309 minecraft:terracotta
fill 382 283 316 385 283 316 minecraft:red_terracotta
setblock 383 283 282 minecraft:terracotta
fill 383 283 283 411 283 283 minecraft:red_terracotta
fill 383 283 309 411 283 309 minecraft:red_terracotta
setblock 383 283 310 minecraft:terracotta
setblock 384 283 281 minecraft:terracotta
fill 384 283 282 410 283 282 minecraft:red_terracotta
fill 384 283 310 410 283 310 minecraft:red_terracotta
setblock 384 283 311 minecraft:terracotta
fill 384 283 315 386 283 315 minecraft:red_terracotta
setblock 385 283 277 minecraft:stripped_oak_log
fill 385 283 278 387 284 278 minecraft:red_terracotta
setblock 385 283 280 minecraft:terracotta
fill 385 283 281 409 283 281 minecraft:red_terracotta
fill 385 283 311 409 283 311 minecraft:red_terracotta
setblock 385 283 312 minecraft:terracotta
setblock 386 283 276 minecraft:stripped_oak_log
fill 386 283 277 389 283 277 minecraft:red_terracotta
fill 386 283 280 408 283 280 minecraft:red_terracotta
fill 386 283 312 408 283 312 minecraft:red_terracotta
setblock 386 283 316 minecraft:stripped_oak_log
fill 387 283 276 390 283 276 minecraft:red_terracotta
setblock 387 283 279 minecraft:terracotta
setblock 387 283 313 minecraft:terracotta
setblock 387 283 314 minecraft:red_terracotta
setblock 387 283 315 minecraft:stripped_oak_log
fill 387 283 316 390 283 316 minecraft:red_terracotta
fill 388 283 278 389 283 278 minecraft:terracotta
fill 388 283 279 406 283 279 minecraft:red_terracotta
setblock 388 283 293 minecraft:red_terracotta
fill 388 283 294 388 284 297 minecraft:orange_terracotta
fill 388 283 298 388 283 299 minecraft:red_terracotta
fill 388 283 313 406 283 313 minecraft:red_terracotta
fill 388 283 314 389 283 314 minecraft:terracotta
fill 388 283 315 389 285 315 minecraft:red_terracotta
fill 389 283 289 389 283 291 minecraft:red_terracotta
fill 389 283 292 389 283 293 minecraft:orange_terracotta
fill 389 283 298 389 283 299 minecraft:orange_terracotta
fill 390 283 277 393 283 277 minecraft:terracotta
fill 390 283 278 404 283 278 minecraft:red_terracotta
fill 390 283 289 390 283 290 minecraft:red_terracotta
setblock 390 283 291 minecraft:orange_terracotta
setblock 390 283 300 minecraft:orange_terracotta
fill 390 283 301 390 283 303 minecraft:red_terracotta
fill 390 283 314 404 283 314 minecraft:red_terracotta
fill 390 283 315 393 283 315 minecraft:terracotta
setblock 391 283 276 minecraft:stripped_oak_log
setblock 391 283 289 minecraft:red_terracotta
setblock 391 283 290 minecraft:orange_terracotta
setblock 391 283 301 minecraft:orange_terracotta
fill 391 283 302 391 283 303 minecraft:red_terracotta
setblock 391 283 316 minecraft:stripped_oak_log
fill 392 283 276 393 285 276 minecraft:red_terracotta
setblock 392 283 289 minecraft:orange_terracotta
fill 392 283 302 393 283 302 minecraft:orange_terracotta
fill 392 283 303 393 283 303 minecraft:red_terracotta
fill 392 283 316 393 285 316 minecraft:red_terracotta
fill 393 283 287 414 283 287 minecraft:red_terracotta
fill 393 283 288 399 283 288 minecraft:orange_terracotta
fill 394 283 276 400 283 276 minecraft:terracotta
fill 394 283 277 400 283 277 minecraft:red_terracotta
fill 394 283 303 399 283 303 minecraft:orange_terracotta
fill 394 283 315 400 283 315 minecraft:red_terracotta
fill 394 283 316 400 283 316 minecraft:terracotta
fill 399 283 302 400 283 302 minecraft:orange_terracotta
fill 400 283 288 414 283 288 minecraft:red_terracotta
setblock 400 283 289 minecraft:orange_terracotta
fill 400 283 303 415 283 303 minecraft:red_terracotta
setblock 401 283 276 minecraft:stripped_oak_log
fill 401 283 277 404 283 277 minecraft:terracotta
fill 401 283 289 415 283 289 minecraft:red_terracotta
setblock 401 283 290 minecraft:orange_terracotta
fill 401 283 301 402 283 301 minecraft:orange_terracotta
fill 401 283 302 415 283 302 minecraft:red_terracotta
fill 401 283 315 404 283 315 minecraft:terracotta
setblock 401 283 316 minecraft:stripped_oak_log
fill 402 283 276 405 283 276 minecraft:red_terracotta
fill 402 283 290 415 283 290 minecraft:red_terracotta
setblock 402 283 291 minecraft:orange_terracotta
setblock 402 283 300 minecraft:orange_terracotta
fill 402 283 316 405 283 316 minecraft:red_terracotta
fill 403 283 291 415 283 291 minecraft:red_terracotta
fill 403 283 292 403 283 294 minecraft:orange_terracotta
fill 403 283 297 403 283 299 minecraft:orange_terracotta
fill 403 283 300 415 283 301 minecraft:red_terracotta
fill 404 283 292 415 283 294 minecraft:red_terracotta
fill 404 283 295 404 283 297 minecraft:orange_terracotta
fill 404 283 298 416 283 299 minecraft:red_terracotta
setblock 405 283 277 minecraft:stripped_oak_log
fill 405 283 278 406 283 278 minecraft:terracotta
fill 405 283 295 416 283 297 minecraft:red_terracotta
fill 405 283 314 406 283 314 minecraft:terracotta
fill 405 283 315 406 283 315 minecraft:red_terracotta
setblock 406 283 276 minecraft:stripped_oak_log
fill 406 283 277 409 283 277 minecraft:red_terracotta
setblock 406 283 316 minecraft:stripped_oak_log
fill 407 283 276 410 283 276 minecraft:red_terracotta
fill 407 283 278 410 285 278 minecraft:stripped_oak_log
setblock 407 283 279 minecraft:terracotta
setblock 407 283 313 minecraft:terracotta
setblock 407 283 314 minecraft:red_terracotta
setblock 407 283 315 minecraft:stripped_oak_log
fill 407 283 316 410 283 316 minecraft:red_terracotta
setblock 408 283 314 minecraft:stripped_oak_log
fill 408 283 315 411 283 315 minecraft:red_terracotta
fill 409 283 279 410 285 279 minecraft:stripped_oak_log
setblock 409 283 280 minecraft:terracotta
setblock 409 283 312 minecraft:terracotta
setblock 409 283 313 minecraft:stripped_oak_log
fill 409 283 314 412 283 314 minecraft:red_terracotta
setblock 410 283 277 minecraft:stripped_oak_log
fill 410 283 280 410 300 280 minecraft:stripped_oak_log
setblock 410 283 281 minecraft:terracotta
setblock 410 283 311 minecraft:terracotta
fill 410 283 313 411 283 313 minecraft:red_terracotta
setblock 411 283 276 minecraft:stripped_oak_log
fill 411 283 277 414 283 277 minecraft:red_terracotta
setblock 411 283 282 minecraft:terracotta
setblock 411 283 310 minecraft:terracotta
setblock 411 283 316 minecraft:stripped_oak_log
fill 412 283 276 415 283 276 minecraft:red_terracotta
setblock 412 283 283 minecraft:terracotta
setblock 412 283 309 minecraft:terracotta
setblock 412 283 315 minecraft:stripped_oak_log
fill 412 283 316 415 283 316 minecraft:red_terracotta
fill 413 283 280 417 285 283 minecraft:stripped_oak_log
setblock 413 283 284 minecraft:terracotta
setblock 413 283 308 minecraft:terracotta
setblock 413 283 314 minecraft:stripped_oak_log
fill 413 283 315 416 283 315 minecraft:red_terracotta
fill 414 283 284 417 285 284 minecraft:stripped_oak_log
setblock 414 283 286 minecraft:terracotta
setblock 414 283 306 minecraft:terracotta
setblock 414 283 314 minecraft:red_terracotta
fill 415 283 285 417 285 286 minecraft:stripped_oak_log
fill 415 283 287 415 283 288 minecraft:terracotta
fill 415 283 304 415 283 305 minecraft:terracotta
setblock 416 283 276 minecraft:stripped_oak_log
fill 416 283 287 416 285 288 minecraft:stripped_oak_log
fill 416 283 289 416 283 292 minecraft:terracotta
fill 416 283 293 416 283 294 minecraft:red_terracotta
fill 416 283 300 416 283 303 minecraft:terracotta
fill 416 283 312 417 283 314 minecraft:red_terracotta
setblock 416 283 316 minecraft:stripped_oak_log
fill 417 283 276 417 284 277 minecraft:red_terracotta
fill 417 283 287 417 292 287 minecraft:stripped_oak_log
fill 417 283 288 417 283 289 minecraft:red_terracotta
setblock 417 283 290 minecraft:stripped_oak_log
fill 417 283 291 417 285 292 minecraft:red_terracotta
fill 417 283 293 417 283 299 minecraft:terracotta
setblock 417 283 300 minecraft:stripped_oak_log
fill 417 283 301 417 283 304 minecraft:red_terracotta
setblock 417 283 305 minecraft:stripped_oak_log
fill 417 283 306 417 283 309 minecraft:red_terracotta
setblock 417 283 310 minecraft:stripped_oak_log
setblock 417 283 311 minecraft:red_terracotta
setblock 417 283 315 minecraft:stripped_oak_log
fill 417 283 316 417 285 316 minecraft:red_terracotta
fill 376 284 275 376 287 317 minecraft:red_terracotta
fill 377 284 275 377 284 278 minecraft:red_terracotta
setblock 377 284 279 minecraft:stripped_oak_log
fill 377 284 280 377 285 282 minecraft:red_terracotta
fill 377 284 286 377 284 288 minecraft:red_terracotta
setblock 377 284 289 minecraft:stripped_oak_log
fill 377 284 290 377 285 290 minecraft:red_terracotta
setblock 377 284 293 minecraft:red_terracotta
setblock 377 284 294 minecraft:stripped_oak_log
fill 377 284 295 377 284 298 minecraft:red_terracotta
setblock 377 284 299 minecraft:stripped_oak_log
fill 377 284 300 377 285 300 minecraft:red_terracotta
fill 377 284 316 377 284 317 minecraft:red_terracotta
fill 378 284 275 379 284 276 minecraft:red_terracotta
setblock 378 284 291 minecraft:red_terracotta
fill 378 284 292 378 284 300 minecraft:terracotta
fill 378 284 301 378 285 303 minecraft:stripped_oak_log
fill 378 284 317 418 287 317 minecraft:red_terracotta
fill 379 284 289 379 284 291 minecraft:terracotta
fill 379 284 292 387 284 300 minecraft:red_terracotta
fill 379 284 301 379 284 303 minecraft:terracotta
fill 379 284 304 379 285 305 minecraft:stripped_oak_log
fill 380 284 275 418 287 275 minecraft:red_terracotta
setblock 380 284 276 minecraft:stripped_oak_log
fill 380 284 277 383 284 277 minecraft:red_terracotta
fill 380 284 287 380 284 288 minecraft:terracotta
fill 380 284 289 388 284 291 minecraft:red_terracotta
fill 380 284 301 389 284 303 minecraft:red_terracotta
fill 380 284 304 380 284 305 minecraft:terracotta
fill 381 284 276 384 284 276 minecraft:red_terracotta
fill 381 284 285 381 284 286 minecraft:terracotta
fill 381 284 287 391 284 288 minecraft:red_terracotta
fill 381 284 304 393 284 305 minecraft:red_terracotta
fill 381 284 306 381 284 307 minecraft:terracotta
fill 381 284 316 384 284 316 minecraft:red_terracotta
setblock 382 284 284 minecraft:terracotta
fill 382 284 285 412 284 286 minecraft:red_terracotta
fill 382 284 306 412 284 307 minecraft:red_terracotta
setblock 382 284 308 minecraft:terracotta
setblock 383 284 283 minecraft:terracotta
fill 383 284 284 411 284 284 minecraft:red_terracotta
fill 383 284 308 411 284 308 minecraft:red_terracotta
setblock 383 284 309 minecraft:terracotta
setblock 384 284 277 minecraft:stripped_oak_log
fill 384 284 278 384 287 278 minecraft:red_terracotta
setblock 384 284 282 minecraft:terracotta
fill 384 284 283 410 284 283 minecraft:red_terracotta
fill 384 284 309 410 284 309 minecraft:red_terracotta
setblock 384 284 310 minecraft:terracotta
fill 384 284 315 385 284 315 minecraft:red_terracotta
setblock 385 284 276 minecraft:stripped_oak_log
fill 385 284 277 388 284 277 minecraft:red_terracotta
setblock 385 284 281 minecraft:terracotta
fill 385 284 282 409 284 282 minecraft:red_terracotta
fill 385 284 310 409 284 310 minecraft:red_terracotta
setblock 385 284 311 minecraft:terracotta
setblock 385 284 316 minecraft:stripped_oak_log
fill 386 284 276 389 284 276 minecraft:red_terracotta
fill 386 284 280 387 284 280 minecraft:terracotta
fill 386 284 281 408 284 281 minecraft:red_terracotta
fill 386 284 311 408 284 311 minecraft:red_terracotta
fill 386 284 312 387 284 312 minecraft:terracotta
setblock 386 284 315 minecraft:stripped_oak_log
fill 386 284 316 389 284 316 minecraft:red_terracotta
setblock 387 284 279 minecraft:stripped_oak_log
fill 387 284 315 387 287 315 minecraft:red_terracotta
setblock 388 284 278 minecraft:stripped_oak_log
fill 388 284 279 389 284 279 minecraft:terracotta
fill 388 284 280 406 284 280 minecraft:red_terracotta
fill 388 284 292 388 284 293 minecraft:orange_terracotta
fill 388 284 298 388 284 299 minecraft:orange_terracotta
setblock 388 284 300 minecraft:red_terracotta
fill 388 284 312 406 284 312 minecraft:red_terracotta
fill 388 284 313 389 284 313 minecraft:terracotta
fill 388 284 314 389 285 314 minecraft:red_terracotta
setblock 389 284 277 minecraft:stripped_oak_log
fill 389 284 278 389 287 278 minecraft:red_terracotta
fill 389 284 289 389 284 290 minecraft:red_terracotta
setblock 389 284 291 minecraft:orange_terracotta
setblock 389 284 300 minecraft:orange_terracotta
setblock 390 284 276 minecraft:stripped_oak_log
fill 390 284 277 392 285 277 minecraft:red_terracotta
fill 390 284 278 392 284 278 minecraft:terracotta
fill 390 284 279 404 284 279 minecraft:red_terracotta
setblock 390 284 289 minecraft:red_terracotta
setblock 390 284 290 minecraft:orange_terracotta
setblock 390 284 301 minecraft:orange_terracotta
fill 390 284 302 390 284 303 minecraft:red_terracotta
fill 390 284 313 404 284 313 minecraft:red_terracotta
fill 390 284 314 392 284 314 minecraft:terracotta
setblock 390 284 315 minecraft:red_terracotta
setblock 390 284 316 minecraft:stripped_oak_log
fill 391 284 276 391 287 276 minecraft:red_terracotta
setblock 391 284 289 minecraft:orange_terracotta
setblock 391 284 302 minecraft:orange_terracotta
setblock 391 284 303 minecraft:red_terracotta
setblock 391 284 315 minecraft:stripped_oak_log
fill 391 284 316 391 285 316 minecraft:red_terracotta
fill 392 284 287 393 284 287 minecraft:red_terracotta
fill 392 284 288 393 284 288 minecraft:orange_terracotta
fill 392 284 303 393 284 303 minecraft:orange_terracotta
fill 392 284 315 392 285 315 minecraft:red_terracotta
fill 393 284 277 401 284 277 minecraft:terracotta
fill 393 284 278 401 284 278 minecraft:red_terracotta
fill 393 284 314 401 284 314 minecraft:red_terracotta
fill 393 284 315 401 284 315 minecraft:terracotta
setblock 394 284 276 minecraft:red_terracotta
fill 394 284 287 398 284 287 minecraft:orange_terracotta
fill 394 284 304 399 284 304 minecraft:orange_terracotta
fill 394 284 305 413 284 305 minecraft:red_terracotta
setblock 394 284 316 minecraft:red_terracotta
setblock 395 284 276 minecraft:stripped_oak_log
setblock 395 284 316 minecraft:stripped_oak_log
fill 396 284 276 399 284 276 minecraft:red_terracotta
fill 396 284 316 399 284 316 minecraft:red_terracotta
fill 399 284 287 413 284 287 minecraft:red_terracotta
fill 399 284 288 400 284 288 minecraft:orange_terracotta
setblock 400 284 276 minecraft:stripped_oak_log
fill 400 284 303 401 284 303 minecraft:orange_terracotta
fill 400 284 304 413 284 304 minecraft:red_terracotta
setblock 400 284 316 minecraft:stripped_oak_log
fill 401 284 276 404 284 276 minecraft:red_terracotta
fill 401 284 288 413 284 288 minecraft:red_terracotta
fill 401 284 289 402 284 289 minecraft:orange_terracotta
fill 401 284 302 402 284 302 minecraft:orange_terracotta
fill 401 284 316 404 284 316 minecraft:red_terracotta
fill 402 284 277 403 284 277 minecraft:red_terracotta
fill 402 284 278 404 284 278 minecraft:terracotta
fill 402 284 290 403 284 290 minecraft:orange_terracotta
fill 402 284 303 414 284 303 minecraft:red_terracotta
fill 402 284 314 404 284 314 minecraft:terracotta
fill 402 284 315 405 284 315 minecraft:red_terracotta
fill 403 284 289 414 284 289 minecraft:red_terracotta
setblock 403 284 291 minecraft:orange_terracotta
fill 403 284 300 403 284 301 minecraft:orange_terracotta
fill 403 284 302 414 284 302 minecraft:red_terracotta
setblock 404 284 277 minecraft:stripped_oak_log
fill 404 284 290 414 284 291 minecraft:red_terracotta
fill 404 284 292 404 284 294 minecraft:orange_terracotta
fill 404 284 298 404 284 300 minecraft:orange_terracotta
fill 404 284 301 414 284 301 minecraft:red_terracotta
setblock 405 284 276 minecraft:stripped_oak_log
fill 405 284 277 408 284 277 minecraft:red_terracotta
fill 405 284 278 406 285 278 minecraft:stripped_oak_log
fill 405 284 279 406 284 279 minecraft:terracotta
fill 405 284 292 415 284 293 minecraft:red_terracotta
fill 405 284 294 405 284 297 minecraft:orange_terracotta
fill 405 284 298 415 284 300 minecraft:red_terracotta
fill 405 284 313 406 284 313 minecraft:terracotta
fill 405 284 314 406 284 314 minecraft:red_terracotta
setblock 405 284 316 minecraft:stripped_oak_log
fill 406 284 276 409 284 276 minecraft:red_terracotta
fill 406 284 294 415 284 297 minecraft:red_terracotta
setblock 406 284 315 minecraft:stripped_oak_log
fill 406 284 316 409 284 316 minecraft:red_terracotta
fill 407 284 279 408 285 279 minecraft:stripped_oak_log
fill 407 284 280 408 284 280 minecraft:terracotta
fill 407 284 312 408 284 312 minecraft:terracotta
setblock 407 284 314 minecraft:stripped_oak_log
fill 407 284 315 410 284 315 minecraft:red_terracotta
fill 408 284 314 411 284 314 minecraft:red_terracotta
setblock 409 284 277 minecraft:stripped_oak_log
fill 409 284 280 409 285 280 minecraft:stripped_oak_log
setblock 409 284 281 minecraft:terracotta
setblock 409 284 311 minecraft:terracotta
setblock 410 284 276 minecraft:stripped_oak_log
fill 410 284 277 413 284 277 minecraft:red_terracotta
fill 410 284 281 410 285 281 minecraft:stripped_oak_log
setblock 410 284 282 minecraft:terracotta
setblock 410 284 310 minecraft:terracotta
setblock 410 284 316 minecraft:stripped_oak_log
fill 411 284 276 414 284 276 minecraft:red_terracotta
setblock 411 284 283 minecraft:terracotta
setblock 411 284 309 minecraft:terracotta
setblock 411 284 315 minecraft:stripped_oak_log
fill 411 284 316 414 284 316 minecraft:red_terracotta
setblock 412 284 284 minecraft:terracotta
setblock 412 284 308 minecraft:terracotta
setblock 412 284 314 minecraft:stripped_oak_log
fill 412 284 315 415 284 315 minecraft:red_terracotta
fill 413 284 284 413 285 284 minecraft:stripped_oak_log
fill 413 284 285 413 284 286 minecraft:terracotta
fill 413 284 306 413 284 307 minecraft:terracotta
setblock 413 284 314 minecraft:red_terracotta
fill 414 284 285 414 285 286 minecraft:stripped_oak_log
fill 414 284 287 414 284 288 minecraft:terracotta
fill 414 284 304 414 284 305 minecraft:terracotta
setblock 415 284 276 minecraft:stripped_oak_log
fill 415 284 287 415 285 288 minecraft:stripped_oak_log
fill 415 284 289 415 284 291 minecraft:terracotta
fill 415 284 301 415 284 303 minecraft:terracotta
setblock 415 284 316 minecraft:stripped_oak_log
fill 416 284 276 416 285 276 minecraft:red_terracotta
fill 416 284 289 416 285 290 minecraft:stripped_oak_log
setblock 416 284 291 minecraft:red_terracotta
fill 416 284 292 416 284 300 minecraft:terracotta
fill 416 284 301 418 284 303 minecraft:red_terracotta
fill 416 284 316 416 285 316 minecraft:red_terracotta
fill 417 284 288 417 285 289 minecraft:stripped_oak_log
fill 417 284 290 418 285 290 minecraft:red_terracotta
fill 417 284 293 418 284 293 minecraft:red_terracotta
setblock 417 284 294 minecraft:stripped_oak_log
fill 417 284 295 418 284 298 minecraft:red_terracotta
setblock 417 284 299 minecraft:stripped_oak_log
fill 417 284 300 418 287 300 minecraft:red_terracotta
setblock 417 284 304 minecraft:stripped_oak_log
fill 417 284 305 418 284 305 minecraft:red_terracotta
fill 417 284 313 418 284 313 minecraft:red_terracotta
setblock 417 284 314 minecraft:stripped_oak_log
fill 417 284 315 418 284 315 minecraft:red_terracotta
fill 418 284 276 418 287 289 minecraft:red_terracotta
fill 418 284 291 418 287 292 minecraft:red_terracotta
fill 418 284 294 418 287 294 minecraft:red_terracotta
fill 418 284 299 418 287 299 minecraft:red_terracotta
fill 418 284 304 418 287 304 minecraft:red_terracotta
fill 418 284 306 418 287 312 minecraft:red_terracotta
fill 418 284 314 418 287 314 minecraft:red_terracotta
fill 418 284 316 418 287 316 minecraft:red_terracotta
fill 377 285 275 377 285 277 minecraft:red_terracotta
setblock 377 285 278 minecraft:stripped_oak_log
fill 377 285 279 377 288 279 minecraft:red_terracotta
setblock 377 285 288 minecraft:stripped_oak_log
setblock 377 285 289 minecraft:red_terracotta
setblock 377 285 293 minecraft:stripped_oak_log
fill 377 285 294 377 285 297 minecraft:red_terracotta
setblock 377 285 298 minecraft:stripped_oak_log
fill 377 285 299 377 288 299 minecraft:red_terracotta
fill 377 285 301 377 286 301 minecraft:red_terracotta
setblock 377 285 302 minecraft:stripped_oak_log
fill 377 285 317 377 287 317 minecraft:red_terracotta
fill 378 285 275 378 285 276 minecraft:red_terracotta
fill 378 285 293 378 285 296 minecraft:red_terracotta
setblock 378 285 297 minecraft:stripped_oak_log
setblock 378 285 298 minecraft:red_terracotta
fill 378 285 299 378 285 300 minecraft:stripped_oak_log
fill 379 285 275 379 287 275 minecraft:red_terracotta
setblock 379 285 276 minecraft:stripped_oak_log
fill 379 285 291 379 285 301 minecraft:terracotta
fill 379 285 302 379 285 303 minecraft:stripped_oak_log
fill 380 285 276 382 285 277 minecraft:red_terracotta
fill 380 285 288 380 285 290 minecraft:terracotta
fill 380 285 291 386 285 301 minecraft:red_terracotta
fill 380 285 302 380 285 304 minecraft:terracotta
setblock 380 285 305 minecraft:stripped_oak_log
setblock 381 285 287 minecraft:terracotta
fill 381 285 288 388 285 290 minecraft:red_terracotta
fill 381 285 302 388 285 304 minecraft:red_terracotta
setblock 381 285 305 minecraft:terracotta
fill 381 285 316 383 285 316 minecraft:red_terracotta
fill 382 285 285 382 285 286 minecraft:terracotta
fill 382 285 287 391 285 287 minecraft:red_terracotta
fill 382 285 305 393 285 305 minecraft:red_terracotta
fill 382 285 306 382 285 307 minecraft:terracotta
setblock 383 285 276 minecraft:red_terracotta
setblock 383 285 277 minecraft:stripped_oak_log
fill 383 285 278 383 288 278 minecraft:red_terracotta
setblock 383 285 284 minecraft:terracotta
fill 383 285 285 394 285 286 minecraft:red_terracotta
fill 383 285 306 411 285 307 minecraft:red_terracotta
setblock 383 285 308 minecraft:terracotta
setblock 384 285 276 minecraft:stripped_oak_log
fill 384 285 277 387 285 277 minecraft:red_terracotta
setblock 384 285 283 minecraft:terracotta
fill 384 285 284 410 285 284 minecraft:red_terracotta
fill 384 285 308 410 285 308 minecraft:red_terracotta
setblock 384 285 309 minecraft:terracotta
setblock 384 285 316 minecraft:stripped_oak_log
fill 385 285 276 388 285 276 minecraft:red_terracotta
fill 385 285 278 386 285 278 minecraft:red_terracotta
setblock 385 285 282 minecraft:terracotta
fill 385 285 283 409 285 283 minecraft:red_terracotta
fill 385 285 309 409 285 309 minecraft:red_terracotta
setblock 385 285 310 minecraft:terracotta
setblock 385 285 315 minecraft:stripped_oak_log
fill 385 285 316 388 285 316 minecraft:red_terracotta
setblock 386 285 279 minecraft:stripped_oak_log
fill 386 285 281 387 285 281 minecraft:terracotta
fill 386 285 282 408 285 282 minecraft:red_terracotta
fill 386 285 310 408 285 310 minecraft:red_terracotta
fill 386 285 311 387 285 311 minecraft:terracotta
fill 386 285 315 386 288 315 minecraft:red_terracotta
setblock 387 285 278 minecraft:stripped_oak_log
fill 387 285 279 388 287 279 minecraft:red_terracotta
fill 387 285 291 387 285 292 minecraft:red_terracotta
fill 387 285 293 387 285 298 minecraft:yellow_terracotta
fill 387 285 299 387 285 301 minecraft:red_terracotta
setblock 388 285 277 minecraft:stripped_oak_log
fill 388 285 278 388 288 278 minecraft:red_terracotta
setblock 388 285 280 minecraft:terracotta
fill 388 285 281 406 285 281 minecraft:red_terracotta
fill 388 285 291 388 285 292 minecraft:yellow_terracotta
fill 388 285 299 388 285 300 minecraft:yellow_terracotta
setblock 388 285 301 minecraft:red_terracotta
fill 388 285 311 406 285 311 minecraft:red_terracotta
setblock 388 285 312 minecraft:terracotta
setblock 388 285 313 minecraft:stripped_oak_log
setblock 389 285 276 minecraft:stripped_oak_log
fill 389 285 277 389 288 277 minecraft:red_terracotta
fill 389 285 279 391 285 279 minecraft:terracotta
fill 389 285 280 405 285 280 minecraft:red_terracotta
fill 389 285 288 389 285 289 minecraft:red_terracotta
setblock 389 285 290 minecraft:yellow_terracotta
fill 389 285 301 389 285 302 minecraft:yellow_terracotta
fill 389 285 303 389 285 304 minecraft:red_terracotta
fill 389 285 312 405 285 312 minecraft:red_terracotta
fill 389 285 313 391 285 313 minecraft:terracotta
setblock 389 285 316 minecraft:stripped_oak_log
fill 390 285 276 390 288 276 minecraft:red_terracotta
fill 390 285 278 391 285 278 minecraft:red_terracotta
setblock 390 285 288 minecraft:red_terracotta
setblock 390 285 289 minecraft:yellow_terracotta
fill 390 285 302 390 285 303 minecraft:yellow_terracotta
fill 390 285 304 391 285 304 minecraft:red_terracotta
setblock 390 285 314 minecraft:red_terracotta
setblock 390 285 315 minecraft:stripped_oak_log
fill 390 285 316 390 288 316 minecraft:red_terracotta
setblock 391 285 288 minecraft:yellow_terracotta
setblock 391 285 303 minecraft:yellow_terracotta
setblock 391 285 314 minecraft:stripped_oak_log
fill 391 285 315 391 288 315 minecraft:red_terracotta
fill 392 285 278 402 285 278 minecraft:terracotta
fill 392 285 279 402 285 279 minecraft:red_terracotta
fill 392 285 287 394 285 287 minecraft:yellow_terracotta
fill 392 285 304 393 285 304 minecraft:yellow_terracotta
fill 392 285 313 402 285 313 minecraft:red_terracotta
fill 392 285 314 402 285 314 minecraft:terracotta
setblock 393 285 277 minecraft:stripped_oak_log
fill 393 285 315 394 285 315 minecraft:red_terracotta
setblock 394 285 276 minecraft:stripped_oak_log
fill 394 285 277 397 285 277 minecraft:red_terracotta
fill 394 285 305 399 285 305 minecraft:yellow_terracotta
setblock 394 285 316 minecraft:stripped_oak_log
fill 395 285 276 398 285 276 minecraft:red_terracotta
fill 395 285 285 411 285 285 minecraft:red_terracotta
fill 395 285 286 398 285 286 minecraft:yellow_terracotta
setblock 395 285 315 minecraft:stripped_oak_log
fill 395 285 316 398 285 316 minecraft:red_terracotta
fill 396 285 315 399 285 315 minecraft:red_terracotta
setblock 398 285 277 minecraft:stripped_oak_log
setblock 399 285 276 minecraft:stripped_oak_log
setblock 399 285 277 minecraft:red_terracotta
fill 399 285 286 411 285 286 minecraft:red_terracotta
fill 399 285 287 400 285 287 minecraft:yellow_terracotta
setblock 399 285 316 minecraft:stripped_oak_log
fill 400 285 276 403 285 276 minecraft:red_terracotta
fill 400 285 304 401 285 304 minecraft:yellow_terracotta
fill 400 285 305 412 285 305 minecraft:red_terracotta
setblock 400 285 315 minecraft:stripped_oak_log
fill 400 285 316 403 285 316 minecraft:red_terracotta
fill 401 285 287 412 285 287 minecraft:red_terracotta
fill 401 285 288 402 285 288 minecraft:yellow_terracotta
fill 401 285 315 404 285 315 minecraft:red_terracotta
setblock 402 285 277 minecraft:red_terracotta
fill 402 285 303 403 285 303 minecraft:yellow_terracotta
fill 402 285 304 413 285 304 minecraft:red_terracotta
setblock 403 285 277 minecraft:stripped_oak_log
fill 403 285 279 405 285 279 minecraft:terracotta
fill 403 285 288 413 285 288 minecraft:red_terracotta
setblock 403 285 289 minecraft:yellow_terracotta
fill 403 285 302 404 285 302 minecraft:yellow_terracotta
fill 403 285 313 405 285 313 minecraft:terracotta
setblock 404 285 276 minecraft:stripped_oak_log
fill 404 285 277 407 285 277 minecraft:red_terracotta
fill 404 285 278 404 300 278 minecraft:stripped_oak_log
fill 404 285 289 413 285 289 minecraft:red_terracotta
fill 404 285 290 404 285 291 minecraft:yellow_terracotta
setblock 404 285 301 minecraft:yellow_terracotta
fill 404 285 303 413 285 303 minecraft:red_terracotta
fill 404 285 314 405 285 314 minecraft:red_terracotta
setblock 404 285 316 minecraft:stripped_oak_log
fill 405 285 276 408 285 276 minecraft:red_terracotta
fill 405 285 290 413 285 290 minecraft:red_terracotta
fill 405 285 291 405 285 293 minecraft:yellow_terracotta
fill 405 285 298 405 285 300 minecraft:yellow_terracotta
fill 405 285 301 413 285 302 minecraft:red_terracotta
setblock 405 285 315 minecraft:stripped_oak_log
fill 405 285 316 408 285 316 minecraft:red_terracotta
setblock 406 285 279 minecraft:stripped_oak_log
setblock 406 285 280 minecraft:terracotta
fill 406 285 291 414 285 293 minecraft:red_terracotta
fill 406 285 294 406 285 298 minecraft:yellow_terracotta
fill 406 285 299 414 285 300 minecraft:red_terracotta
setblock 406 285 312 minecraft:terracotta
setblock 406 285 314 minecraft:stripped_oak_log
fill 406 285 315 409 285 315 minecraft:red_terracotta
fill 407 285 280 408 285 280 minecraft:stripped_oak_log
fill 407 285 281 408 285 281 minecraft:terracotta
fill 407 285 294 414 285 298 minecraft:red_terracotta
fill 407 285 311 408 285 311 minecraft:terracotta
fill 407 285 314 410 285 314 minecraft:red_terracotta
setblock 408 285 277 minecraft:stripped_oak_log
setblock 409 285 276 minecraft:stripped_oak_log
fill 409 285 277 412 285 277 minecraft:red_terracotta
fill 409 285 281 409 300 281 minecraft:stripped_oak_log
setblock 409 285 282 minecraft:terracotta
setblock 409 285 310 minecraft:terracotta
setblock 409 285 316 minecraft:stripped_oak_log
fill 410 285 276 413 285 276 minecraft:red_terracotta
fill 410 285 282 410 300 282 minecraft:stripped_oak_log
setblock 410 285 283 minecraft:terracotta
setblock 410 285 309 minecraft:terracotta
setblock 410 285 315 minecraft:stripped_oak_log
fill 410 285 316 413 285 316 minecraft:red_terracotta
setblock 411 285 284 minecraft:terracotta
setblock 411 285 308 minecraft:terracotta
setblock 411 285 314 minecraft:stripped_oak_log
fill 411 285 315 414 285 315 minecraft:red_terracotta
fill 412 285 285 412 285 286 minecraft:terracotta
fill 412 285 306 412 285 307 minecraft:terracotta
setblock 413 285 277 minecraft:stripped_oak_log
fill 413 285 285 413 285 286 minecraft:stripped_oak_log
setblock 413 285 287 minecraft:terracotta
setblock 413 285 305 minecraft:terracotta
setblock 414 285 276 minecraft:stripped_oak_log
setblock 414 285 287 minecraft:stripped_oak_log
fill 414 285 288 414 285 290 minecraft:terracotta
setblock 414 285 301 minecraft:red_terracotta
fill 414 285 302 414 285 304 minecraft:terracotta
setblock 414 285 316 minecraft:stripped_oak_log
fill 415 285 276 415 286 276 minecraft:red_terracotta
fill 415 285 289 415 285 290 minecraft:stripped_oak_log
fill 415 285 291 415 285 301 minecraft:terracotta
fill 415 285 316 415 286 316 minecraft:red_terracotta
fill 416 285 292 416 285 293 minecraft:red_terracotta
setblock 416 285 294 minecraft:stripped_oak_log
fill 416 285 295 416 285 298 minecraft:red_terracotta
setblock 416 285 299 minecraft:stripped_oak_log
fill 416 285 300 416 286 302 minecraft:red_terracotta
setblock 417 285 293 minecraft:stripped_oak_log
fill 417 285 294 417 285 297 minecraft:red_terracotta
setblock 417 285 298 minecraft:stripped_oak_log
fill 417 285 299 417 288 299 minecraft:red_terracotta
fill 417 285 301 418 285 302 minecraft:red_terracotta
setblock 417 285 303 minecraft:stripped_oak_log
setblock 417 285 304 minecraft:red_terracotta
fill 418 285 293 418 287 293 minecraft:red_terracotta
fill 418 285 295 418 287 298 minecraft:red_terracotta
fill 418 285 303 418 287 303 minecraft:red_terracotta
fill 418 285 305 418 287 305 minecraft:red_terracotta
fill 418 285 313 418 287 313 minecraft:red_terracotta
fill 418 285 315 418 287 315 minecraft:red_terracotta
fill 377 286 275 377 286 276 minecraft:red_terracotta
setblock 377 286 277 minecraft:stripped_oak_log
fill 377 286 278 377 289 278 minecraft:red_terracotta
fill 377 286 280 377 286 281 minecraft:red_terracotta
setblock 377 286 282 minecraft:stripped_oak_log
setblock 377 286 291 minecraft:red_terracotta
setblock 377 286 292 minecraft:stripped_oak_log
fill 377 286 293 377 287 295 minecraft:red_terracotta
setblock 377 286 296 minecraft:shroomlight
setblock 377 286 297 minecraft:stripped_oak_log
setblock 377 286 298 minecraft:shroomlight
setblock 377 286 300 minecraft:shroomlight
setblock 377 286 302 minecraft:shroomlight
fill 377 286 303 377 292 303 minecraft:stripped_oak_log
setblock 377 286 304 minecraft:shroomlight
fill 377 286 305 377 293 305 minecraft:stripped_oak_log
fill 378 286 275 378 287 275 minecraft:red_terracotta
setblock 378 286 276 minecraft:stripped_oak_log
setblock 378 286 295 minecraft:shroomlight
fill 378 286 296 378 300 296 minecraft:stripped_oak_log
setblock 378 286 297 minecraft:shroomlight
fill 378 286 298 378 300 298 minecraft:stripped_oak_log
setblock 378 286 299 minecraft:shroomlight
fill 378 286 300 378 300 300 minecraft:stripped_oak_log
setblock 378 286 301 minecraft:shroomlight
fill 378 286 302 378 300 302 minecraft:stripped_oak_log
setblock 378 286 303 minecraft:shroomlight
fill 378 286 304 378 295 304 minecraft:stripped_oak_log
setblock 378 286 305 minecraft:shroomlight
fill 379 286 276 382 286 276 minecraft:red_terracotta
fill 379 286 295 379 300 295 minecraft:stripped_oak_log
setblock 379 286 296 minecraft:shroomlight
fill 379 286 297 379 300 297 minecraft:stripped_oak_log
setblock 379 286 298 minecraft:shroomlight
fill 379 286 299 379 300 299 minecraft:stripped_oak_log
setblock 379 286 300 minecraft:shroomlight
fill 379 286 301 379 300 301 minecraft:stripped_oak_log
setblock 379 286 302 minecraft:shroomlight
fill 379 286 303 379 300 303 minecraft:stripped_oak_log
setblock 379 286 304 minecraft:shroomlight
fill 379 286 305 379 300 305 minecraft:stripped_oak_log
fill 380 286 277 381 286 277 minecraft:red_terracotta
fill 380 286 291 380 286 294 minecraft:terracotta
setblock 380 286 295 minecraft:shroomlight
setblock 380 286 296 minecraft:terracotta
setblock 380 286 297 minecraft:shroomlight
setblock 380 286 298 minecraft:terracotta
setblock 380 286 299 minecraft:shroomlight
setblock 380 286 300 minecraft:terracotta
setblock 380 286 301 minecraft:shroomlight
fill 380 286 302 380 300 302 minecraft:stripped_oak_log
setblock 380 286 303 minecraft:shroomlight
fill 380 286 304 380 300 304 minecraft:stripped_oak_log
setblock 380 286 305 minecraft:shroomlight
fill 381 286 288 381 286 290 minecraft:terracotta
fill 381 286 291 381 286 295 minecraft:red_terracotta
setblock 381 286 296 minecraft:shroomlight
setblock 381 286 297 minecraft:red_terracotta
setblock 381 286 298 minecraft:shroomlight
setblock 381 286 299 minecraft:red_terracotta
setblock 381 286 300 minecraft:shroomlight
setblock 381 286 301 minecraft:red_terracotta
setblock 381 286 302 minecraft:shroomlight
setblock 381 286 303 minecraft:terracotta
setblock 381 286 304 minecraft:shroomlight
fill 381 286 305 381 300 305 minecraft:stripped_oak_log
setblock 382 286 277 minecraft:stripped_oak_log
fill 382 286 287 382 286 288 minecraft:terracotta
fill 382 286 289 385 286 294 minecraft:red_terracotta
setblock 382 286 295 minecraft:shroomlight
fill 382 286 296 382 287 296 minecraft:red_terracotta
setblock 382 286 297 minecraft:shroomlight
fill 382 286 298 382 287 298 minecraft:red_terracotta
setblock 382 286 299 minecraft:shroomlight
setblock 382 286 300 minecraft:red_terracotta
setblock 382 286 301 minecraft:shroomlight
setblock 382 286 302 minecraft:red_terracotta
setblock 382 286 303 minecraft:shroomlight
setblock 382 286 304 minecraft:terracotta
setblock 382 286 305 minecraft:shroomlight
setblock 382 286 316 minecraft:red_terracotta
setblock 383 286 276 minecraft:stripped_oak_log
fill 383 286 277 386 286 277 minecraft:red_terracotta
fill 383 286 285 383 286 286 minecraft:terracotta
fill 383 286 287 389 286 288 minecraft:red_terracotta
fill 383 286 295 383 287 295 minecraft:red_terracotta
setblock 383 286 296 minecraft:shroomlight
fill 383 286 297 383 287 297 minecraft:red_terracotta
setblock 383 286 298 minecraft:shroomlight
fill 383 286 299 383 287 299 minecraft:red_terracotta
setblock 383 286 300 minecraft:shroomlight
fill 383 286 301 383 287 301 minecraft:red_terracotta
setblock 383 286 302 minecraft:shroomlight
setblock 383 286 303 minecraft:red_terracotta
setblock 383 286 304 minecraft:shroomlight
setblock 383 286 305 minecraft:red_terracotta
fill 383 286 306 383 286 307 minecraft:terracotta
setblock 383 286 316 minecraft:stripped_oak_log
fill 384 286 276 387 286 276 minecraft:red_terracotta
fill 384 286 284 384 286 285 minecraft:terracotta
fill 384 286 286 392 286 286 minecraft:red_terracotta
setblock 384 286 295 minecraft:shroomlight
fill 384 286 296 385 287 296 minecraft:red_terracotta
setblock 384 286 297 minecraft:shroomlight
fill 384 286 298 385 287 298 minecraft:red_terracotta
setblock 384 286 299 minecraft:shroomlight
fill 384 286 300 386 286 300 minecraft:red_terracotta
setblock 384 286 301 minecraft:shroomlight
fill 384 286 302 387 286 302 minecraft:red_terracotta
setblock 384 286 303 minecraft:shroomlight
fill 384 286 304 389 286 304 minecraft:red_terracotta
setblock 384 286 305 minecraft:shroomlight
fill 384 286 306 388 286 306 minecraft:red_terracotta
fill 384 286 307 384 286 308 minecraft:terracotta
fill 384 286 316 387 286 316 minecraft:red_terracotta
setblock 385 286 278 minecraft:red_terracotta
fill 385 286 283 385 286 284 minecraft:terracotta
fill 385 286 285 395 286 285 minecraft:red_terracotta
fill 385 286 295 385 287 295 minecraft:red_terracotta
fill 385 286 297 385 287 297 minecraft:red_terracotta
fill 385 286 299 386 286 299 minecraft:red_terracotta
fill 385 286 301 387 286 301 minecraft:red_terracotta
fill 385 286 303 388 286 303 minecraft:red_terracotta
fill 385 286 305 391 286 305 minecraft:red_terracotta
fill 385 286 307 387 286 307 minecraft:red_terracotta
fill 385 286 308 385 286 309 minecraft:terracotta
setblock 385 286 315 minecraft:red_terracotta
setblock 386 286 278 minecraft:stripped_oak_log
fill 386 286 279 386 289 279 minecraft:red_terracotta
fill 386 286 282 386 286 283 minecraft:terracotta
fill 386 286 284 408 286 284 minecraft:red_terracotta
fill 386 286 289 386 286 293 minecraft:red_terracotta
fill 386 286 294 386 287 298 minecraft:orange_terracotta
fill 386 286 308 388 286 308 minecraft:red_terracotta
fill 386 286 309 386 286 310 minecraft:terracotta
setblock 387 286 277 minecraft:stripped_oak_log
fill 387 286 278 387 289 278 minecraft:red_terracotta
setblock 387 286 282 minecraft:terracotta
fill 387 286 283 403 286 283 minecraft:red_terracotta
fill 387 286 289 387 286 290 minecraft:red_terracotta
fill 387 286 291 387 286 293 minecraft:orange_terracotta
fill 387 286 299 387 286 300 minecraft:orange_terracotta
setblock 387 286 309 minecraft:red_terracotta
setblock 387 286 310 minecraft:terracotta
setblock 388 286 276 minecraft:stripped_oak_log
fill 388 286 277 388 289 277 minecraft:red_terracotta
fill 388 286 281 389 286 281 minecraft:terracotta
fill 388 286 282 404 286 282 minecraft:red_terracotta
setblock 388 286 289 minecraft:red_terracotta
setblock 388 286 290 minecraft:orange_terracotta
fill 388 286 301 388 286 302 minecraft:orange_terracotta
setblock 388 286 307 minecraft:shroomlight
setblock 388 286 309 minecraft:shroomlight
setblock 388 286 310 minecraft:red_terracotta
setblock 388 286 311 minecraft:shroomlight
fill 388 286 312 388 294 312 minecraft:stripped_oak_log
setblock 388 286 313 minecraft:shroomlight
fill 388 286 314 388 294 314 minecraft:stripped_oak_log
setblock 388 286 315 minecraft:shroomlight
setblock 388 286 316 minecraft:stripped_oak_log
fill 389 286 276 389 289 276 minecraft:red_terracotta
setblock 389 286 279 minecraft:red_terracotta
fill 389 286 280 391 286 280 minecraft:terracotta
setblock 389 286 289 minecraft:orange_terracotta
setblock 389 286 303 minecraft:orange_terracotta
setblock 389 286 306 minecraft:shroomlight
fill 389 286 307 389 287 307 minecraft:red_terracotta
setblock 389 286 308 minecraft:shroomlight
setblock 389 286 309 minecraft:red_terracotta
setblock 389 286 310 minecraft:shroomlight
setblock 389 286 311 minecraft:terracotta
setblock 389 286 312 minecraft:shroomlight
fill 389 286 313 389 294 313 minecraft:stripped_oak_log
setblock 389 286 314 minecraft:shroomlight
setblock 389 286 315 minecraft:stripped_oak_log
setblock 389 286 316 minecraft:shroomlight
fill 390 286 277 390 286 278 minecraft:red_terracotta
setblock 390 286 279 minecraft:stripped_oak_log
fill 390 286 281 403 286 281 minecraft:red_terracotta
setblock 390 286 287 minecraft:red_terracotta
setblock 390 286 288 minecraft:orange_terracotta
fill 390 286 304 391 286 304 minecraft:orange_terracotta
fill 390 286 306 390 287 306 minecraft:red_terracotta
setblock 390 286 307 minecraft:shroomlight
fill 390 286 308 390 287 308 minecraft:red_terracotta
setblock 390 286 309 minecraft:shroomlight
setblock 390 286 310 minecraft:red_terracotta
setblock 390 286 311 minecraft:shroomlight
setblock 390 286 312 minecraft:terracotta
setblock 390 286 313 minecraft:shroomlight
fill 390 286 314 390 294 314 minecraft:stripped_oak_log
setblock 390 286 315 minecraft:shroomlight
setblock 391 286 277 minecraft:red_terracotta
setblock 391 286 278 minecraft:stripped_oak_log
fill 391 286 287 392 286 287 minecraft:orange_terracotta
setblock 391 286 306 minecraft:shroomlight
fill 391 286 307 391 287 307 minecraft:red_terracotta
setblock 391 286 308 minecraft:shroomlight
fill 391 286 309 391 287 309 minecraft:red_terracotta
setblock 391 286 310 minecraft:shroomlight
setblock 391 286 311 minecraft:red_terracotta
setblock 391 286 312 minecraft:shroomlight
fill 391 286 313 391 294 313 minecraft:stripped_oak_log
setblock 391 286 314 minecraft:shroomlight
setblock 391 286 316 minecraft:shroomlight
setblock 392 286 276 minecraft:red_terracotta
setblock 392 286 277 minecraft:stripped_oak_log
fill 392 286 278 394 286 278 minecraft:red_terracotta
fill 392 286 279 402 286 279 minecraft:terracotta
fill 392 286 280 402 286 280 minecraft:red_terracotta
fill 392 286 305 393 286 305 minecraft:orange_terracotta
setblock 392 286 306 minecraft:red_terracotta
setblock 392 286 307 minecraft:shroomlight
fill 392 286 308 392 287 308 minecraft:red_terracotta
setblock 392 286 309 minecraft:shroomlight
fill 392 286 310 392 287 310 minecraft:red_terracotta
setblock 392 286 311 minecraft:shroomlight
setblock 392 286 312 minecraft:red_terracotta
setblock 392 286 313 minecraft:shroomlight
fill 392 286 314 392 294 314 minecraft:stripped_oak_log
setblock 392 286 315 minecraft:shroomlight
setblock 392 286 316 minecraft:red_terracotta
setblock 393 286 276 minecraft:stripped_oak_log
fill 393 286 277 396 286 277 minecraft:red_terracotta
fill 393 286 286 395 286 286 minecraft:orange_terracotta
setblock 393 286 306 minecraft:shroomlight
fill 393 286 307 393 287 307 minecraft:red_terracotta
setblock 393 286 308 minecraft:shroomlight
fill 393 286 309 393 287 309 minecraft:red_terracotta
setblock 393 286 310 minecraft:shroomlight
setblock 393 286 311 minecraft:red_terracotta
setblock 393 286 312 minecraft:shroomlight
setblock 393 286 313 minecraft:terracotta
setblock 393 286 314 minecraft:shroomlight
setblock 393 286 315 minecraft:red_terracotta
setblock 393 286 316 minecraft:shroomlight
fill 394 286 276 397 286 276 minecraft:red_terracotta
setblock 394 286 306 minecraft:orange_terracotta
setblock 394 286 307 minecraft:shroomlight
fill 394 286 308 394 287 308 minecraft:red_terracotta
setblock 394 286 309 minecraft:shroomlight
fill 394 286 310 394 287 310 minecraft:red_terracotta
setblock 394 286 311 minecraft:shroomlight
setblock 394 286 312 minecraft:red_terracotta
setblock 394 286 313 minecraft:shroomlight
fill 394 286 314 394 294 314 minecraft:stripped_oak_log
setblock 394 286 315 minecraft:shroomlight
fill 394 286 316 394 289 316 minecraft:red_terracotta
setblock 395 286 306 minecraft:shroomlight
setblock 395 286 307 minecraft:red_terracotta
setblock 395 286 308 minecraft:shroomlight
fill 395 286 309 395 287 309 minecraft:red_terracotta
setblock 395 286 310 minecraft:shroomlight
fill 395 286 311 395 287 311 minecraft:red_terracotta
setblock 395 286 312 minecraft:shroomlight
setblock 395 286 313 minecraft:terracotta
setblock 395 286 314 minecraft:shroomlight
setblock 395 286 315 minecraft:red_terracotta
setblock 395 286 316 minecraft:shroomlight
fill 396 286 285 397 287 285 minecraft:orange_terracotta
fill 396 286 306 400 286 306 minecraft:orange_terracotta
setblock 396 286 307 minecraft:shroomlight
fill 396 286 308 408 286 308 minecraft:red_terracotta
setblock 396 286 309 minecraft:shroomlight
fill 396 286 310 406 286 310 minecraft:red_terracotta
setblock 396 286 311 minecraft:shroomlight
fill 396 286 312 402 286 312 minecraft:red_terracotta
setblock 396 286 313 minecraft:shroomlight
fill 396 286 314 396 294 314 minecraft:stripped_oak_log
setblock 396 286 315 minecraft:shroomlight
fill 396 286 316 397 286 316 minecraft:red_terracotta
setblock 397 286 277 minecraft:stripped_oak_log
fill 397 286 307 409 286 307 minecraft:red_terracotta
fill 397 286 309 407 286 309 minecraft:red_terracotta
fill 397 286 311 404 286 311 minecraft:red_terracotta
fill 397 286 313 402 286 313 minecraft:terracotta
setblock 397 286 315 minecraft:red_terracotta
setblock 398 286 276 minecraft:stripped_oak_log
fill 398 286 285 409 286 285 minecraft:red_terracotta
fill 398 286 286 400 286 286 minecraft:orange_terracotta
setblock 398 286 316 minecraft:stripped_oak_log
fill 399 286 276 402 286 276 minecraft:red_terracotta
fill 399 286 316 402 286 316 minecraft:red_terracotta
fill 400 286 305 402 286 305 minecraft:orange_terracotta
fill 400 286 315 403 286 315 minecraft:red_terracotta
fill 401 286 286 410 286 286 minecraft:red_terracotta
fill 401 286 287 402 286 287 minecraft:orange_terracotta
fill 401 286 306 410 286 306 minecraft:red_terracotta
fill 402 286 304 403 286 304 minecraft:orange_terracotta
setblock 403 286 276 minecraft:stripped_oak_log
fill 403 286 277 403 287 277 minecraft:red_terracotta
fill 403 286 280 404 286 280 minecraft:terracotta
fill 403 286 287 411 286 287 minecraft:red_terracotta
setblock 403 286 288 minecraft:orange_terracotta
fill 403 286 305 411 286 305 minecraft:red_terracotta
fill 403 286 312 405 286 312 minecraft:terracotta
setblock 403 286 316 minecraft:stripped_oak_log
fill 404 286 276 404 289 276 minecraft:red_terracotta
setblock 404 286 277 minecraft:shroomlight
setblock 404 286 279 minecraft:shroomlight
setblock 404 286 281 minecraft:shroomlight
setblock 404 286 283 minecraft:shroomlight
fill 404 286 288 411 286 288 minecraft:red_terracotta
setblock 404 286 289 minecraft:orange_terracotta
setblock 404 286 303 minecraft:orange_terracotta
fill 404 286 304 411 286 304 minecraft:red_terracotta
setblock 404 286 315 minecraft:stripped_oak_log
fill 404 286 316 407 286 316 minecraft:red_terracotta
setblock 405 286 276 minecraft:shroomlight
fill 405 286 277 405 287 277 minecraft:red_terracotta
setblock 405 286 278 minecraft:shroomlight
fill 405 286 279 405 300 279 minecraft:stripped_oak_log
setblock 405 286 280 minecraft:shroomlight
setblock 405 286 281 minecraft:terracotta
setblock 405 286 282 minecraft:shroomlight
setblock 405 286 283 minecraft:red_terracotta
fill 405 286 289 412 286 289 minecraft:red_terracotta
setblock 405 286 290 minecraft:orange_terracotta
fill 405 286 301 405 286 302 minecraft:orange_terracotta
fill 405 286 303 412 286 303 minecraft:red_terracotta
fill 405 286 311 406 286 311 minecraft:terracotta
fill 405 286 315 408 286 315 minecraft:red_terracotta
fill 406 286 276 406 287 276 minecraft:red_terracotta
setblock 406 286 277 minecraft:shroomlight
fill 406 286 278 406 300 278 minecraft:stripped_oak_log
setblock 406 286 279 minecraft:shroomlight
fill 406 286 280 406 300 280 minecraft:stripped_oak_log
setblock 406 286 281 minecraft:shroomlight
setblock 406 286 282 minecraft:red_terracotta
setblock 406 286 283 minecraft:shroomlight
fill 406 286 290 412 286 290 minecraft:red_terracotta
fill 406 286 291 406 286 293 minecraft:orange_terracotta
fill 406 286 299 406 286 301 minecraft:orange_terracotta
fill 406 286 302 412 286 302 minecraft:red_terracotta
fill 406 286 314 409 286 314 minecraft:red_terracotta
setblock 407 286 276 minecraft:shroomlight
setblock 407 286 277 minecraft:stripped_oak_log
setblock 407 286 278 minecraft:shroomlight
fill 407 286 279 407 300 279 minecraft:stripped_oak_log
setblock 407 286 280 minecraft:shroomlight
fill 407 286 281 407 300 281 minecraft:stripped_oak_log
setblock 407 286 282 minecraft:shroomlight
setblock 407 286 283 minecraft:red_terracotta
fill 407 286 291 413 286 293 minecraft:red_terracotta
fill 407 286 294 407 286 298 minecraft:orange_terracotta
fill 407 286 299 413 286 301 minecraft:red_terracotta
fill 407 286 310 408 286 310 minecraft:terracotta
setblock 408 286 276 minecraft:stripped_oak_log
setblock 408 286 277 minecraft:shroomlight
fill 408 286 278 408 300 278 minecraft:stripped_oak_log
setblock 408 286 279 minecraft:shroomlight
fill 408 286 280 408 300 280 minecraft:stripped_oak_log
setblock 408 286 281 minecraft:shroomlight
setblock 408 286 282 minecraft:terracotta
setblock 408 286 283 minecraft:shroomlight
fill 408 286 294 413 286 298 minecraft:red_terracotta
fill 408 286 309 409 286 309 minecraft:terracotta
setblock 408 286 316 minecraft:stripped_oak_log
setblock 409 286 276 minecraft:shroomlight
fill 409 286 277 409 288 277 minecraft:red_terracotta
setblock 409 286 278 minecraft:shroomlight
fill 409 286 279 409 300 279 minecraft:stripped_oak_log
setblock 409 286 280 minecraft:shroomlight
setblock 409 286 282 minecraft:shroomlight
fill 409 286 283 409 286 284 minecraft:terracotta
fill 409 286 308 410 286 308 minecraft:terracotta
setblock 409 286 315 minecraft:stripped_oak_log
fill 409 286 316 412 286 316 minecraft:red_terracotta
fill 410 286 276 412 286 276 minecraft:red_terracotta
setblock 410 286 277 minecraft:shroomlight
fill 410 286 278 410 300 278 minecraft:stripped_oak_log
setblock 410 286 279 minecraft:shroomlight
setblock 410 286 281 minecraft:shroomlight
setblock 410 286 283 minecraft:shroomlight
fill 410 286 284 410 286 285 minecraft:terracotta
fill 410 286 307 411 286 307 minecraft:terracotta
fill 410 286 315 412 286 315 minecraft:red_terracotta
setblock 411 286 277 minecraft:red_terracotta
fill 411 286 285 411 286 286 minecraft:terracotta
setblock 411 286 306 minecraft:terracotta
setblock 412 286 277 minecraft:stripped_oak_log
fill 412 286 287 412 286 288 minecraft:terracotta
fill 412 286 304 412 286 305 minecraft:terracotta
setblock 413 286 276 minecraft:stripped_oak_log
setblock 413 286 280 minecraft:shroomlight
fill 413 286 281 413 300 281 minecraft:stripped_oak_log
setblock 413 286 282 minecraft:shroomlight
fill 413 286 283 413 300 283 minecraft:stripped_oak_log
setblock 413 286 284 minecraft:shroomlight
fill 413 286 285 413 300 285 minecraft:stripped_oak_log
setblock 413 286 286 minecraft:shroomlight
fill 413 286 287 413 300 287 minecraft:stripped_oak_log
setblock 413 286 288 minecraft:shroomlight
setblock 413 286 289 minecraft:terracotta
setblock 413 286 290 minecraft:shroomlight
fill 413 286 302 413 286 304 minecraft:terracotta
setblock 413 286 316 minecraft:stripped_oak_log
fill 414 286 276 414 287 276 minecraft:red_terracotta
fill 414 286 280 414 300 280 minecraft:stripped_oak_log
setblock 414 286 281 minecraft:shroomlight
fill 414 286 282 414 300 282 minecraft:stripped_oak_log
setblock 414 286 283 minecraft:shroomlight
fill 414 286 284 414 300 284 minecraft:stripped_oak_log
setblock 414 286 285 minecraft:shroomlight
fill 414 286 286 414 300 286 minecraft:stripped_oak_log
setblock 414 286 287 minecraft:shroomlight
fill 414 286 288 414 300 288 minecraft:stripped_oak_log
setblock 414 286 289 minecraft:shroomlight
fill 414 286 290 414 300 290 minecraft:stripped_oak_log
fill 414 286 291 414 286 301 minecraft:terracotta
setblock 414 286 316 minecraft:red_terracotta
setblock 415 286 280 minecraft:shroomlight
fill 415 286 281 415 300 281 minecraft:stripped_oak_log
setblock 415 286 282 minecraft:shroomlight
fill 415 286 283 415 300 283 minecraft:stripped_oak_log
setblock 415 286 284 minecraft:shroomlight
fill 415 286 285 415 296 285 minecraft:stripped_oak_log
setblock 415 286 286 minecraft:shroomlight
fill 415 286 287 415 298 287 minecraft:stripped_oak_log
setblock 415 286 288 minecraft:shroomlight
fill 415 286 289 415 299 289 minecraft:stripped_oak_log
setblock 415 286 290 minecraft:shroomlight
fill 415 286 296 415 286 298 minecraft:red_terracotta
setblock 415 286 299 minecraft:stripped_oak_log
setblock 415 286 300 minecraft:red_terracotta
fill 416 286 280 416 295 280 minecraft:stripped_oak_log
setblock 416 286 281 minecraft:shroomlight
fill 416 286 282 416 293 282 minecraft:stripped_oak_log
setblock 416 286 283 minecraft:shroomlight
fill 416 286 284 416 293 284 minecraft:stripped_oak_log
setblock 416 286 285 minecraft:shroomlight
fill 416 286 286 416 294 286 minecraft:stripped_oak_log
setblock 416 286 287 minecraft:shroomlight
fill 416 286 288 416 294 288 minecraft:stripped_oak_log
setblock 416 286 289 minecraft:shroomlight
fill 416 286 290 416 295 290 minecraft:stripped_oak_log
fill 416 286 294 416 286 297 minecraft:red_terracotta
setblock 416 286 298 minecraft:stripped_oak_log
fill 416 286 299 416 289 299 minecraft:red_terracotta
setblock 417 286 280 minecraft:shroomlight
fill 417 286 281 417 290 281 minecraft:stripped_oak_log
setblock 417 286 282 minecraft:shroomlight
fill 417 286 283 417 291 283 minecraft:stripped_oak_log
setblock 417 286 284 minecraft:shroomlight
fill 417 286 285 417 291 285 minecraft:stripped_oak_log
setblock 417 286 286 minecraft:shroomlight
setblock 417 286 288 minecraft:shroomlight
fill 417 286 289 417 294 289 minecraft:stripped_oak_log
setblock 417 286 290 minecraft:shroomlight
setblock 417 286 291 minecraft:red_terracotta
setblock 417 286 292 minecraft:stripped_oak_log
fill 417 286 293 417 286 296 minecraft:red_terracotta
setblock 417 286 297 minecraft:stripped_oak_log
fill 417 286 298 417 289 298 minecraft:red_terracotta
fill 417 286 301 418 286 301 minecraft:red_terracotta
setblock 417 286 302 minecraft:stripped_oak_log
fill 417 286 303 417 289 303 minecraft:red_terracotta
fill 418 286 290 418 287 290 minecraft:red_terracotta
fill 418 286 302 418 287 302 minecraft:red_terracotta
setblock 377 287 275 minecraft:red_terracotta
setblock 377 287 276 minecraft:stripped_oak_log
fill 377 287 277 377 290 277 minecraft:red_terracotta
setblock 377 287 280 minecraft:red_terracotta
setblock 377 287 281 minecraft:stripped_oak_log
fill 377 287 282 377 290 282 minecraft:red_terracotta
setblock 377 287 296 minecraft:stripped_oak_log
fill 377 287 297 377 288 298 minecraft:red_terracotta
setblock 377 287 300 minecraft:red_terracotta
fill 377 287 301 377 288 302 minecraft:stripped_oak_log
fill 377 287 304 377 288 304 minecraft:stripped_oak_log
fill 378 287 276 381 287 276 minecraft:red_terracotta
fill 378 287 295 378 288 295 minecraft:stripped_oak_log
fill 378 287 297 378 288 297 minecraft:stripped_oak_log
fill 378 287 299 378 288 299 minecraft:stripped_oak_log
fill 378 287 301 378 288 301 minecraft:stripped_oak_log
fill 378 287 303 378 288 303 minecraft:stripped_oak_log
fill 378 287 305 378 288 305 minecraft:stripped_oak_log
setblock 379 287 278 minecraft:light[level=15]
setblock 379 287 285 minecraft:light[level=12]
setblock 379 287 286 minecraft:light[level=15]
setblock 379 287 292 minecraft:light[level=12]
setblock 379 287 294 minecraft:light[level=15]
fill 379 287 296 380 288 296 minecraft:stripped_oak_log
fill 379 287 298 380 288 298 minecraft:stripped_oak_log
fill 379 287 300 380 288 300 minecraft:stripped_oak_log
fill 379 287 302 379 288 302 minecraft:stripped_oak_log
fill 379 287 304 379 288 304 minecraft:stripped_oak_log
setblock 379 287 306 minecraft:light[level=12]
setblock 379 287 310 minecraft:light[level=15]
setblock 379 287 313 minecraft:light[level=12]
setblock 380 287 277 minecraft:red_terracotta
fill 380 287 295 380 288 295 minecraft:stripped_oak_log
fill 380 287 297 380 288 297 minecraft:stripped_oak_log
fill 380 287 299 380 288 299 minecraft:stripped_oak_log
fill 380 287 301 380 288 301 minecraft:stripped_oak_log
fill 380 287 303 381 288 303 minecraft:stripped_oak_log
fill 380 287 305 380 288 305 minecraft:stripped_oak_log
setblock 381 287 277 minecraft:stripped_oak_log
fill 381 287 291 381 287 301 minecraft:terracotta
fill 381 287 302 381 288 302 minecraft:stripped_oak_log
fill 381 287 304 382 288 304 minecraft:stripped_oak_log
setblock 382 287 276 minecraft:stripped_oak_log
fill 382 287 277 385 287 277 minecraft:red_terracotta
fill 382 287 289 382 287 293 minecraft:terracotta
fill 382 287 294 382 287 295 minecraft:red_terracotta
setblock 382 287 297 minecraft:red_terracotta
fill 382 287 299 382 287 303 minecraft:terracotta
fill 382 287 305 382 288 305 minecraft:stripped_oak_log
setblock 382 287 316 minecraft:stripped_oak_log
fill 383 287 276 386 287 276 minecraft:red_terracotta
fill 383 287 287 383 287 290 minecraft:terracotta
fill 383 287 291 385 287 294 minecraft:red_terracotta
setblock 383 287 296 minecraft:red_terracotta
setblock 383 287 298 minecraft:red_terracotta
fill 383 287 300 385 287 300 minecraft:red_terracotta
fill 383 287 302 383 287 305 minecraft:terracotta
fill 383 287 316 386 287 316 minecraft:red_terracotta
fill 384 287 286 384 287 288 minecraft:terracotta
fill 384 287 289 386 287 290 minecraft:red_terracotta
setblock 384 287 295 minecraft:red_terracotta
setblock 384 287 297 minecraft:red_terracotta
fill 384 287 299 385 287 299 minecraft:red_terracotta
fill 384 287 301 386 287 303 minecraft:red_terracotta
fill 384 287 304 384 287 306 minecraft:terracotta
setblock 385 287 278 minecraft:stripped_oak_log
fill 385 287 285 385 287 286 minecraft:terracotta
fill 385 287 287 388 287 288 minecraft:red_terracotta
fill 385 287 304 388 287 305 minecraft:red_terracotta
fill 385 287 306 385 287 307 minecraft:terracotta
setblock 386 287 277 minecraft:stripped_oak_log
fill 386 287 278 386 290 278 minecraft:red_terracotta
fill 386 287 284 386 287 285 minecraft:terracotta
fill 386 287 286 390 287 286 minecraft:red_terracotta
setblock 386 287 291 minecraft:red_terracotta
fill 386 287 292 386 287 293 minecraft:orange_terracotta
fill 386 287 299 386 287 300 minecraft:orange_terracotta
fill 386 287 306 389 287 306 minecraft:red_terracotta
fill 386 287 307 386 287 308 minecraft:terracotta
setblock 386 287 313 minecraft:light[level=12]
setblock 387 287 276 minecraft:stripped_oak_log
fill 387 287 277 387 290 277 minecraft:red_terracotta
fill 387 287 283 387 287 284 minecraft:terracotta
fill 387 287 285 392 287 285 minecraft:red_terracotta
setblock 387 287 289 minecraft:red_terracotta
fill 387 287 290 387 287 291 minecraft:orange_terracotta
setblock 387 287 294 minecraft:light[level=15]
fill 387 287 301 387 287 302 minecraft:orange_terracotta
setblock 387 287 303 minecraft:red_terracotta
fill 387 287 307 388 287 307 minecraft:red_terracotta
fill 387 287 308 387 287 309 minecraft:terracotta
setblock 387 287 310 minecraft:light[level=15]
setblock 387 287 316 minecraft:stripped_oak_log
fill 388 287 276 388 290 276 minecraft:red_terracotta
fill 388 287 282 389 287 283 minecraft:terracotta
fill 388 287 284 406 287 284 minecraft:red_terracotta
setblock 388 287 289 minecraft:orange_terracotta
setblock 388 287 303 minecraft:orange_terracotta
fill 388 287 308 389 287 308 minecraft:red_terracotta
fill 388 287 309 389 287 310 minecraft:terracotta
fill 388 287 311 389 288 311 minecraft:stripped_oak_log
fill 388 287 313 388 288 313 minecraft:stripped_oak_log
setblock 388 287 315 minecraft:stripped_oak_log
fill 388 287 316 389 288 316 minecraft:red_terracotta
setblock 389 287 279 minecraft:stripped_oak_log
setblock 389 287 287 minecraft:red_terracotta
setblock 389 287 288 minecraft:orange_terracotta
setblock 389 287 304 minecraft:orange_terracotta
setblock 389 287 305 minecraft:red_terracotta
fill 389 287 312 391 288 312 minecraft:stripped_oak_log
fill 389 287 314 389 288 314 minecraft:stripped_oak_log
fill 389 287 315 390 288 315 minecraft:red_terracotta
setblock 390 287 277 minecraft:red_terracotta
setblock 390 287 278 minecraft:stripped_oak_log
setblock 390 287 279 minecraft:red_terracotta
fill 390 287 281 391 287 282 minecraft:terracotta
fill 390 287 283 404 287 283 minecraft:red_terracotta
setblock 390 287 287 minecraft:orange_terracotta
fill 390 287 305 391 287 305 minecraft:orange_terracotta
setblock 390 287 307 minecraft:red_terracotta
setblock 390 287 309 minecraft:red_terracotta
fill 390 287 310 391 287 311 minecraft:terracotta
fill 390 287 313 390 288 313 minecraft:stripped_oak_log
setblock 391 287 277 minecraft:stripped_oak_log
fill 391 287 278 393 287 278 minecraft:red_terracotta
fill 391 287 286 392 287 286 minecraft:orange_terracotta
setblock 391 287 306 minecraft:red_terracotta
setblock 391 287 308 minecraft:red_terracotta
fill 391 287 314 391 288 314 minecraft:stripped_oak_log
setblock 391 287 316 minecraft:red_terracotta
setblock 392 287 276 minecraft:stripped_oak_log
fill 392 287 277 395 287 277 minecraft:red_terracotta
fill 392 287 280 394 287 281 minecraft:terracotta
fill 392 287 282 402 287 282 minecraft:red_terracotta
fill 392 287 306 393 287 306 minecraft:orange_terracotta
setblock 392 287 307 minecraft:red_terracotta
setblock 392 287 309 minecraft:red_terracotta
fill 392 287 311 394 287 312 minecraft:terracotta
fill 392 287 313 396 288 313 minecraft:stripped_oak_log
setblock 392 287 315 minecraft:red_terracotta
setblock 392 287 316 minecraft:stripped_oak_log
fill 393 287 276 396 287 276 minecraft:red_terracotta
fill 393 287 285 395 287 285 minecraft:orange_terracotta
setblock 393 287 292 minecraft:light[level=12]
setblock 393 287 299 minecraft:light[level=12]
setblock 393 287 308 minecraft:red_terracotta
setblock 393 287 310 minecraft:red_terracotta
fill 393 287 314 393 288 315 minecraft:stripped_oak_log
fill 393 287 316 393 288 316 minecraft:red_terracotta
fill 394 287 306 396 288 306 minecraft:stripped_oak_log
fill 394 287 307 400 287 307 minecraft:orange_terracotta
setblock 394 287 309 minecraft:red_terracotta
setblock 394 287 315 minecraft:red_terracotta
setblock 395 287 278 minecraft:light[level=15]
fill 395 287 280 402 287 280 minecraft:terracotta
fill 395 287 281 399 287 281 minecraft:red_terracotta
setblock 395 287 286 minecraft:light[level=15]
setblock 395 287 302 minecraft:light[level=15]
fill 395 287 308 406 287 308 minecraft:red_terracotta
fill 395 287 310 402 287 310 minecraft:red_terracotta
fill 395 287 312 402 287 312 minecraft:terracotta
fill 395 287 314 395 288 315 minecraft:stripped_oak_log
fill 395 287 316 396 287 316 minecraft:red_terracotta
setblock 396 287 277 minecraft:stripped_oak_log
fill 396 287 309 404 287 309 minecraft:red_terracotta
fill 396 287 311 399 287 311 minecraft:red_terracotta
fill 396 287 315 396 288 315 minecraft:stripped_oak_log
setblock 397 287 276 minecraft:stripped_oak_log
setblock 397 287 316 minecraft:stripped_oak_log
fill 398 287 276 401 287 276 minecraft:red_terracotta
fill 398 287 285 400 287 285 minecraft:orange_terracotta
fill 398 287 316 401 287 316 minecraft:red_terracotta
setblock 400 287 278 minecraft:light[level=12]
fill 400 287 281 404 287 281 minecraft:terracotta
setblock 400 287 292 minecraft:light[level=12]
setblock 400 287 299 minecraft:light[level=12]
setblock 400 287 306 minecraft:light[level=12]
fill 400 287 311 404 287 311 minecraft:terracotta
setblock 400 287 313 minecraft:light[level=12]
fill 401 287 285 407 287 285 minecraft:red_terracotta
fill 401 287 286 402 287 286 minecraft:orange_terracotta
fill 401 287 306 402 287 306 minecraft:orange_terracotta
fill 401 287 307 407 287 307 minecraft:red_terracotta
setblock 402 287 276 minecraft:stripped_oak_log
setblock 402 287 315 minecraft:red_terracotta
setblock 402 287 316 minecraft:stripped_oak_log
fill 403 287 276 403 290 276 minecraft:red_terracotta
setblock 403 287 278 minecraft:light[level=15]
fill 403 287 282 406 287 282 minecraft:terracotta
fill 403 287 286 408 287 286 minecraft:red_terracotta
fill 403 287 287 404 287 287 minecraft:orange_terracotta
setblock 403 287 294 minecraft:light[level=15]
setblock 403 287 302 minecraft:light[level=15]
fill 403 287 305 404 287 305 minecraft:orange_terracotta
fill 403 287 306 408 287 306 minecraft:red_terracotta
fill 403 287 310 406 287 310 minecraft:terracotta
setblock 403 287 315 minecraft:stripped_oak_log
fill 403 287 316 406 287 316 minecraft:red_terracotta
fill 404 287 277 404 288 277 minecraft:red_terracotta
fill 404 287 279 404 288 280 minecraft:stripped_oak_log
fill 404 287 288 405 287 288 minecraft:orange_terracotta
fill 404 287 304 405 287 304 minecraft:orange_terracotta
fill 404 287 315 407 287 315 minecraft:red_terracotta
fill 405 287 276 405 288 276 minecraft:red_terracotta
fill 405 287 278 405 288 278 minecraft:stripped_oak_log
fill 405 287 280 405 288 281 minecraft:stripped_oak_log
fill 405 287 283 407 287 283 minecraft:terracotta
fill 405 287 287 409 287 287 minecraft:red_terracotta
fill 405 287 289 406 287 289 minecraft:orange_terracotta
fill 405 287 303 406 287 303 minecraft:orange_terracotta
fill 405 287 305 409 287 305 minecraft:red_terracotta
fill 405 287 309 407 287 309 minecraft:terracotta
setblock 406 287 277 minecraft:stripped_oak_log
fill 406 287 279 406 288 279 minecraft:stripped_oak_log
fill 406 287 281 406 288 281 minecraft:stripped_oak_log
fill 406 287 288 409 287 288 minecraft:red_terracotta
setblock 406 287 290 minecraft:orange_terracotta
setblock 406 287 302 minecraft:orange_terracotta
fill 406 287 304 409 287 304 minecraft:red_terracotta
setblock 407 287 276 minecraft:stripped_oak_log
fill 407 287 277 408 288 277 minecraft:red_terracotta
fill 407 287 278 407 288 278 minecraft:stripped_oak_log
fill 407 287 280 407 288 280 minecraft:stripped_oak_log
fill 407 287 282 409 288 282 minecraft:stripped_oak_log
fill 407 287 284 408 287 284 minecraft:terracotta
fill 407 287 289 410 287 290 minecraft:red_terracotta
fill 407 287 291 407 287 293 minecraft:orange_terracotta
fill 407 287 299 407 287 301 minecraft:orange_terracotta
fill 407 287 302 410 287 303 minecraft:red_terracotta
fill 407 287 308 408 287 308 minecraft:terracotta
setblock 407 287 313 minecraft:light[level=12]
setblock 407 287 316 minecraft:stripped_oak_log
fill 408 287 276 411 287 276 minecraft:red_terracotta
fill 408 287 279 408 288 279 minecraft:stripped_oak_log
fill 408 287 281 408 288 281 minecraft:stripped_oak_log
fill 408 287 283 410 288 283 minecraft:stripped_oak_log
fill 408 287 285 409 287 285 minecraft:terracotta
fill 408 287 291 411 287 292 minecraft:red_terracotta
fill 408 287 293 408 287 299 minecraft:orange_terracotta
fill 408 287 300 411 287 301 minecraft:red_terracotta
fill 408 287 307 409 287 307 minecraft:terracotta
setblock 408 287 315 minecraft:stripped_oak_log
fill 408 287 316 411 287 316 minecraft:red_terracotta
fill 409 287 278 409 288 278 minecraft:stripped_oak_log
fill 409 287 280 409 288 280 minecraft:stripped_oak_log
fill 409 287 286 410 287 286 minecraft:terracotta
fill 409 287 293 411 287 299 minecraft:red_terracotta
fill 409 287 306 410 287 306 minecraft:terracotta
fill 409 287 315 411 287 315 minecraft:red_terracotta
setblock 410 287 277 minecraft:red_terracotta
fill 410 287 279 410 288 279 minecraft:stripped_oak_log
fill 410 287 281 410 288 281 minecraft:stripped_oak_log
fill 410 287 287 411 287 288 minecraft:terracotta
fill 410 287 304 411 287 305 minecraft:terracotta
setblock 411 287 277 minecraft:stripped_oak_log
setblock 411 287 278 minecraft:light[level=15]
setblock 411 287 286 minecraft:light[level=15]
fill 411 287 289 412 287 290 minecraft:terracotta
fill 411 287 302 412 287 303 minecraft:terracotta
setblock 411 287 310 minecraft:light[level=15]
setblock 412 287 276 minecraft:stripped_oak_log
fill 412 287 291 413 287 293 minecraft:terracotta
fill 412 287 294 412 287 298 minecraft:red_terracotta
fill 412 287 299 413 287 301 minecraft:terracotta
setblock 412 287 316 minecraft:stripped_oak_log
setblock 413 287 276 minecraft:red_terracotta
fill 413 287 280 413 288 280 minecraft:stripped_oak_log
fill 413 287 282 413 288 282 minecraft:stripped_oak_log
fill 413 287 284 413 288 284 minecraft:stripped_oak_log
fill 413 287 286 413 288 286 minecraft:stripped_oak_log
fill 413 287 288 413 288 290 minecraft:stripped_oak_log
fill 413 287 294 413 287 298 minecraft:terracotta
setblock 413 287 316 minecraft:red_terracotta
setblock 414 287 278 minecraft:light[level=12]
fill 414 287 281 414 288 281 minecraft:stripped_oak_log
fill 414 287 283 414 288 283 minecraft:stripped_oak_log
fill 414 287 285 414 288 285 minecraft:stripped_oak_log
fill 414 287 287 414 288 287 minecraft:stripped_oak_log
fill 414 287 289 414 288 289 minecraft:stripped_oak_log
setblock 414 287 292 minecraft:light[level=12]
setblock 414 287 299 minecraft:light[level=12]
setblock 414 287 306 minecraft:light[level=12]
setblock 414 287 313 minecraft:light[level=12]
fill 415 287 280 415 288 280 minecraft:stripped_oak_log
fill 415 287 282 415 288 282 minecraft:stripped_oak_log
fill 415 287 284 415 288 284 minecraft:stripped_oak_log
fill 415 287 286 415 288 286 minecraft:stripped_oak_log
fill 415 287 288 415 288 288 minecraft:stripped_oak_log
fill 415 287 290 415 288 290 minecraft:stripped_oak_log
fill 416 287 281 416 288 281 minecraft:stripped_oak_log
fill 416 287 283 416 288 283 minecraft:stripped_oak_log
fill 416 287 285 416 288 285 minecraft:stripped_oak_log
fill 416 287 287 416 288 287 minecraft:stripped_oak_log
fill 416 287 289 416 288 289 minecraft:stripped_oak_log
fill 416 287 295 416 287 296 minecraft:red_terracotta
setblock 416 287 297 minecraft:stripped_oak_log
fill 416 287 298 416 289 298 minecraft:red_terracotta
fill 416 287 300 416 287 301 minecraft:red_terracotta
fill 417 287 280 417 288 280 minecraft:stripped_oak_log
fill 417 287 282 417 288 282 minecraft:stripped_oak_log
fill 417 287 284 417 288 284 minecraft:stripped_oak_log
fill 417 287 286 417 288 286 minecraft:stripped_oak_log
fill 417 287 288 417 288 288 minecraft:stripped_oak_log
fill 417 287 290 417 288 290 minecraft:stripped_oak_log
fill 417 287 293 417 287 295 minecraft:red_terracotta
setblock 417 287 296 minecraft:stripped_oak_log
fill 417 287 297 417 290 297 minecraft:red_terracotta
setblock 417 287 301 minecraft:stripped_oak_log
fill 417 287 302 417 290 302 minecraft:red_terracotta
setblock 418 287 301 minecraft:red_terracotta
fill 376 288 275 376 291 317 minecraft:yellow_terracotta
fill 377 288 275 418 291 275 minecraft:yellow_terracotta
fill 377 288 276 380 288 276 minecraft:red_terracotta
setblock 377 288 280 minecraft:stripped_oak_log
fill 377 288 281 377 291 281 minecraft:red_terracotta
fill 377 288 295 377 300 295 minecraft:stripped_oak_log
setblock 377 288 296 minecraft:red_terracotta
setblock 377 288 300 minecraft:stripped_oak_log
fill 377 288 317 418 291 317 minecraft:yellow_terracotta
setblock 380 288 277 minecraft:stripped_oak_log
setblock 381 288 276 minecraft:stripped_oak_log
fill 381 288 277 384 288 277 minecraft:red_terracotta
fill 381 288 295 381 288 301 minecraft:stripped_oak_log
fill 382 288 276 385 288 276 minecraft:red_terracotta
fill 382 288 278 382 289 278 minecraft:red_terracotta
fill 382 288 294 384 288 298 minecraft:terracotta
fill 382 288 299 382 288 303 minecraft:stripped_oak_log
fill 383 288 291 384 288 293 minecraft:terracotta
fill 383 288 299 384 288 301 minecraft:terracotta
fill 383 288 302 383 288 305 minecraft:stripped_oak_log
fill 383 288 316 385 288 316 minecraft:red_terracotta
setblock 384 288 278 minecraft:stripped_oak_log
fill 384 288 289 385 288 290 minecraft:terracotta
fill 384 288 302 386 288 303 minecraft:terracotta
fill 384 288 304 384 288 305 minecraft:stripped_oak_log
setblock 385 288 277 minecraft:stripped_oak_log
fill 385 288 278 385 290 279 minecraft:red_terracotta
fill 385 288 287 387 288 288 minecraft:terracotta
fill 385 288 291 385 288 292 minecraft:terracotta
fill 385 288 293 385 288 299 minecraft:yellow_terracotta
fill 385 288 300 385 288 301 minecraft:terracotta
fill 385 288 304 387 288 305 minecraft:terracotta
setblock 386 288 276 minecraft:stripped_oak_log
fill 386 288 277 386 291 277 minecraft:red_terracotta
fill 386 288 286 389 288 286 minecraft:terracotta
setblock 386 288 289 minecraft:terracotta
fill 386 288 290 386 288 292 minecraft:yellow_terracotta
fill 386 288 300 386 288 301 minecraft:yellow_terracotta
fill 386 288 306 389 288 306 minecraft:terracotta
setblock 386 288 316 minecraft:stripped_oak_log
fill 387 288 276 387 291 276 minecraft:red_terracotta
setblock 387 288 279 minecraft:red_terracotta
fill 387 288 285 391 288 285 minecraft:terracotta
setblock 387 288 289 minecraft:yellow_terracotta
fill 387 288 302 387 288 303 minecraft:yellow_terracotta
fill 387 288 307 391 288 307 minecraft:terracotta
setblock 387 288 315 minecraft:stripped_oak_log
fill 387 288 316 387 291 316 minecraft:red_terracotta
setblock 388 288 279 minecraft:stripped_oak_log
fill 388 288 284 393 288 284 minecraft:terracotta
setblock 388 288 287 minecraft:terracotta
setblock 388 288 288 minecraft:yellow_terracotta
setblock 388 288 304 minecraft:yellow_terracotta
setblock 388 288 305 minecraft:terracotta
fill 388 288 308 393 288 308 minecraft:terracotta
fill 388 288 309 389 288 310 minecraft:stripped_oak_log
setblock 388 288 315 minecraft:red_terracotta
setblock 389 288 278 minecraft:stripped_oak_log
setblock 389 288 279 minecraft:red_terracotta
setblock 389 288 287 minecraft:yellow_terracotta
setblock 389 288 305 minecraft:yellow_terracotta
setblock 390 288 277 minecraft:stripped_oak_log
fill 390 288 278 392 288 278 minecraft:red_terracotta
fill 390 288 283 404 288 283 minecraft:terracotta
fill 390 288 286 391 288 286 minecraft:yellow_terracotta
fill 390 288 306 391 288 306 minecraft:yellow_terracotta
fill 390 288 309 404 288 309 minecraft:terracotta
fill 390 288 310 391 288 311 minecraft:stripped_oak_log
setblock 391 288 276 minecraft:stripped_oak_log
fill 391 288 277 394 288 277 minecraft:red_terracotta
setblock 391 288 316 minecraft:stripped_oak_log
fill 392 288 276 395 288 276 minecraft:red_terracotta
fill 392 288 282 402 288 282 minecraft:terracotta
fill 392 288 285 393 288 285 minecraft:yellow_terracotta
fill 392 288 306 393 288 306 minecraft:stripped_oak_log
fill 392 288 307 393 288 307 minecraft:yellow_terracotta
fill 392 288 310 402 288 310 minecraft:terracotta
fill 392 288 311 394 288 312 minecraft:stripped_oak_log
setblock 392 288 315 minecraft:stripped_oak_log
fill 392 288 316 392 291 316 minecraft:red_terracotta
fill 394 288 284 400 288 284 minecraft:yellow_terracotta
fill 394 288 307 396 288 307 minecraft:stripped_oak_log
fill 394 288 308 400 288 308 minecraft:yellow_terracotta
setblock 394 288 315 minecraft:stripped_oak_log
setblock 395 288 277 minecraft:stripped_oak_log
fill 395 288 281 399 288 281 minecraft:terracotta
fill 395 288 311 399 288 311 minecraft:terracotta
fill 395 288 312 396 288 312 minecraft:stripped_oak_log
setblock 395 288 316 minecraft:red_terracotta
setblock 396 288 276 minecraft:stripped_oak_log
setblock 396 288 316 minecraft:stripped_oak_log
fill 397 288 276 400 288 276 minecraft:red_terracotta
fill 397 288 316 400 288 316 minecraft:red_terracotta
setblock 401 288 276 minecraft:stripped_oak_log
fill 401 288 284 406 288 284 minecraft:terracotta
fill 401 288 285 402 288 285 minecraft:yellow_terracotta
fill 401 288 307 402 288 307 minecraft:yellow_terracotta
fill 401 288 308 406 288 308 minecraft:terracotta
setblock 401 288 316 minecraft:stripped_oak_log
fill 402 288 276 402 291 276 minecraft:red_terracotta
fill 402 288 316 405 288 316 minecraft:red_terracotta
fill 403 288 285 407 288 285 minecraft:terracotta
fill 403 288 286 404 288 286 minecraft:yellow_terracotta
fill 403 288 306 404 288 306 minecraft:yellow_terracotta
fill 403 288 307 407 288 307 minecraft:terracotta
fill 403 288 315 406 288 315 minecraft:red_terracotta
fill 404 288 281 404 288 282 minecraft:stripped_oak_log
setblock 405 288 277 minecraft:stripped_oak_log
fill 405 288 282 406 288 283 minecraft:stripped_oak_log
fill 405 288 286 408 288 286 minecraft:terracotta
setblock 405 288 287 minecraft:yellow_terracotta
setblock 405 288 305 minecraft:yellow_terracotta
fill 405 288 306 408 288 306 minecraft:terracotta
setblock 406 288 276 minecraft:stripped_oak_log
setblock 406 288 277 minecraft:red_terracotta
fill 406 288 287 409 288 287 minecraft:terracotta
setblock 406 288 288 minecraft:yellow_terracotta
setblock 406 288 304 minecraft:yellow_terracotta
fill 406 288 305 409 288 305 minecraft:terracotta
setblock 406 288 316 minecraft:stripped_oak_log
fill 407 288 276 410 288 276 minecraft:red_terracotta
fill 407 288 283 407 300 283 minecraft:stripped_oak_log
fill 407 288 288 409 288 288 minecraft:terracotta
fill 407 288 289 407 288 290 minecraft:yellow_terracotta
fill 407 288 302 407 288 303 minecraft:yellow_terracotta
fill 407 288 304 409 288 304 minecraft:terracotta
setblock 407 288 315 minecraft:stripped_oak_log
fill 407 288 316 410 288 316 minecraft:red_terracotta
fill 408 288 289 410 288 290 minecraft:terracotta
fill 408 288 291 408 288 292 minecraft:yellow_terracotta
fill 408 288 300 408 288 301 minecraft:yellow_terracotta
fill 408 288 302 410 288 303 minecraft:terracotta
fill 408 288 315 409 288 315 minecraft:red_terracotta
fill 409 288 291 411 288 292 minecraft:terracotta
fill 409 288 293 409 288 299 minecraft:yellow_terracotta
fill 409 288 300 411 288 301 minecraft:terracotta
setblock 410 288 277 minecraft:stripped_oak_log
fill 410 288 293 411 288 299 minecraft:terracotta
setblock 411 288 276 minecraft:stripped_oak_log
setblock 411 288 316 minecraft:stripped_oak_log
setblock 412 288 276 minecraft:red_terracotta
fill 412 288 294 412 288 298 minecraft:terracotta
setblock 412 288 316 minecraft:red_terracotta
setblock 416 288 296 minecraft:stripped_oak_log
setblock 416 288 297 minecraft:red_terracotta
setblock 416 288 300 minecraft:red_terracotta
setblock 416 288 301 minecraft:stripped_oak_log
setblock 417 288 294 minecraft:red_terracotta
setblock 417 288 295 minecraft:stripped_oak_log
fill 417 288 296 417 291 296 minecraft:red_terracotta
setblock 417 288 300 minecraft:stripped_oak_log
fill 417 288 301 417 291 301 minecraft:red_terracotta
fill 418 288 276 418 291 316 minecraft:yellow_terracotta
fill 377 289 276 379 289 276 minecraft:red_terracotta
setblock 377 289 279 minecraft:stripped_oak_log
fill 377 289 280 377 292 280 minecraft:red_terracotta
setblock 377 289 283 minecraft:red_terracotta
setblock 377 289 296 minecraft:shroomlight
fill 377 289 297 377 300 297 minecraft:stripped_oak_log
setblock 377 289 298 minecraft:shroomlight
fill 377 289 299 377 294 299 minecraft:stripped_oak_log
setblock 377 289 300 minecraft:shroomlight
fill 377 289 301 377 292 301 minecraft:stripped_oak_log
setblock 377 289 302 minecraft:shroomlight
setblock 377 289 304 minecraft:shroomlight
setblock 378 289 295 minecraft:shroomlight
setblock 378 289 297 minecraft:shroomlight
setblock 378 289 299 minecraft:shroomlight
setblock 378 289 301 minecraft:shroomlight
setblock 378 289 303 minecraft:shroomlight
setblock 378 289 305 minecraft:shroomlight
setblock 379 289 296 minecraft:shroomlight
setblock 379 289 298 minecraft:shroomlight
setblock 379 289 300 minecraft:shroomlight
setblock 379 289 302 minecraft:shroomlight
setblock 379 289 304 minecraft:shroomlight
setblock 380 289 276 minecraft:stripped_oak_log
fill 380 289 277 383 289 277 minecraft:red_terracotta
setblock 380 289 295 minecraft:shroomlight
fill 380 289 296 380 300 296 minecraft:stripped_oak_log
setblock 380 289 297 minecraft:shroomlight
fill 380 289 298 380 300 298 minecraft:stripped_oak_log
setblock 380 289 299 minecraft:shroomlight
fill 380 289 300 380 300 300 minecraft:stripped_oak_log
setblock 380 289 301 minecraft:shroomlight
setblock 380 289 303 minecraft:shroomlight
setblock 380 289 305 minecraft:shroomlight
fill 381 289 276 384 289 276 minecraft:red_terracotta
fill 381 289 295 381 300 295 minecraft:stripped_oak_log
setblock 381 289 296 minecraft:shroomlight
fill 381 289 297 381 300 297 minecraft:stripped_oak_log
setblock 381 289 298 minecraft:shroomlight
fill 381 289 299 381 300 299 minecraft:stripped_oak_log
setblock 381 289 300 minecraft:shroomlight
fill 381 289 301 381 300 301 minecraft:stripped_oak_log
setblock 381 289 302 minecraft:shroomlight
fill 381 289 303 381 300 303 minecraft:stripped_oak_log
setblock 381 289 304 minecraft:shroomlight
fill 382 289 294 383 300 294 minecraft:stripped_oak_log
setblock 382 289 295 minecraft:shroomlight
fill 382 289 296 382 300 296 minecraft:stripped_oak_log
setblock 382 289 297 minecraft:shroomlight
fill 382 289 298 382 300 298 minecraft:stripped_oak_log
setblock 382 289 299 minecraft:shroomlight
fill 382 289 300 382 300 300 minecraft:stripped_oak_log
setblock 382 289 301 minecraft:shroomlight
fill 382 289 302 382 300 302 minecraft:stripped_oak_log
setblock 382 289 303 minecraft:shroomlight
fill 382 289 304 382 300 304 minecraft:stripped_oak_log
setblock 382 289 305 minecraft:shroomlight
setblock 383 289 278 minecraft:stripped_oak_log
fill 383 289 295 383 300 295 minecraft:stripped_oak_log
setblock 383 289 296 minecraft:shroomlight
fill 383 289 297 383 300 297 minecraft:stripped_oak_log
setblock 383 289 298 minecraft:shroomlight
fill 383 289 299 383 300 299 minecraft:stripped_oak_log
setblock 383 289 300 minecraft:shroomlight
fill 383 289 301 383 300 301 minecraft:stripped_oak_log
setblock 383 289 302 minecraft:shroomlight
fill 383 289 303 383 300 303 minecraft:stripped_oak_log
setblock 383 289 304 minecraft:shroomlight
fill 383 289 305 383 300 305 minecraft:stripped_oak_log
fill 383 289 316 384 289 316 minecraft:red_terracotta
setblock 384 289 277 minecraft:stripped_oak_log
fill 384 289 278 384 292 278 minecraft:red_terracotta
setblock 384 289 295 minecraft:shroomlight
fill 384 289 296 384 300 296 minecraft:stripped_oak_log
setblock 384 289 297 minecraft:shroomlight
fill 384 289 298 384 300 298 minecraft:stripped_oak_log
setblock 384 289 299 minecraft:shroomlight
fill 384 289 300 384 300 300 minecraft:stripped_oak_log
setblock 384 289 301 minecraft:shroomlight
fill 384 289 302 384 300 302 minecraft:stripped_oak_log
setblock 384 289 303 minecraft:shroomlight
fill 384 289 304 384 300 304 minecraft:stripped_oak_log
setblock 384 289 305 minecraft:shroomlight
setblock 385 289 276 minecraft:stripped_oak_log
fill 385 289 277 385 292 277 minecraft:red_terracotta
setblock 385 289 316 minecraft:stripped_oak_log
fill 386 289 276 386 292 276 minecraft:red_terracotta
fill 386 289 316 386 292 316 minecraft:red_terracotta
setblock 387 289 279 minecraft:stripped_oak_log
setblock 387 289 315 minecraft:red_terracotta
setblock 388 289 278 minecraft:stripped_oak_log
fill 388 289 279 388 290 279 minecraft:red_terracotta
fill 388 289 306 388 294 306 minecraft:stripped_oak_log
setblock 388 289 307 minecraft:shroomlight
fill 388 289 308 388 294 308 minecraft:stripped_oak_log
setblock 388 289 309 minecraft:shroomlight
fill 388 289 310 388 294 310 minecraft:stripped_oak_log
setblock 388 289 311 minecraft:shroomlight
setblock 388 289 313 minecraft:shroomlight
setblock 388 289 315 minecraft:shroomlight
fill 388 289 316 388 290 316 minecraft:red_terracotta
setblock 389 289 277 minecraft:stripped_oak_log
fill 389 289 278 391 290 278 minecraft:red_terracotta
setblock 389 289 306 minecraft:shroomlight
fill 389 289 307 389 294 307 minecraft:stripped_oak_log
setblock 389 289 308 minecraft:shroomlight
fill 389 289 309 389 294 309 minecraft:stripped_oak_log
setblock 389 289 310 minecraft:shroomlight
fill 389 289 311 389 294 311 minecraft:stripped_oak_log
setblock 389 289 312 minecraft:shroomlight
setblock 389 289 314 minecraft:shroomlight
setblock 389 289 315 minecraft:red_terracotta
setblock 389 289 316 minecraft:shroomlight
setblock 390 289 276 minecraft:stripped_oak_log
fill 390 289 277 393 289 277 minecraft:red_terracotta
fill 390 289 306 390 294 306 minecraft:stripped_oak_log
setblock 390 289 307 minecraft:shroomlight
fill 390 289 308 390 294 308 minecraft:stripped_oak_log
setblock 390 289 309 minecraft:shroomlight
fill 390 289 310 390 294 310 minecraft:stripped_oak_log
setblock 390 289 311 minecraft:shroomlight
fill 390 289 312 390 294 312 minecraft:stripped_oak_log
setblock 390 289 313 minecraft:shroomlight
setblock 390 289 315 minecraft:shroomlight
setblock 390 289 316 minecraft:stripped_oak_log
fill 391 289 276 394 289 276 minecraft:red_terracotta
setblock 391 289 306 minecraft:shroomlight
fill 391 289 307 391 294 307 minecraft:stripped_oak_log
setblock 391 289 308 minecraft:shroomlight
fill 391 289 309 391 294 309 minecraft:stripped_oak_log
setblock 391 289 310 minecraft:shroomlight
fill 391 289 311 391 294 311 minecraft:stripped_oak_log
setblock 391 289 312 minecraft:shroomlight
setblock 391 289 314 minecraft:shroomlight
fill 391 289 315 391 294 315 minecraft:stripped_oak_log
setblock 391 289 316 minecraft:shroomlight
fill 392 289 306 392 294 306 minecraft:stripped_oak_log
setblock 392 289 307 minecraft:shroomlight
fill 392 289 308 392 294 308 minecraft:stripped_oak_log
setblock 392 289 309 minecraft:shroomlight
fill 392 289 310 392 294 310 minecraft:stripped_oak_log
setblock 392 289 311 minecraft:shroomlight
fill 392 289 312 392 294 312 minecraft:stripped_oak_log
setblock 392 289 313 minecraft:shroomlight
setblock 392 289 315 minecraft:shroomlight
setblock 393 289 306 minecraft:shroomlight
fill 393 289 307 393 294 307 minecraft:stripped_oak_log
setblock 393 289 308 minecraft:shroomlight
fill 393 289 309 393 294 309 minecraft:stripped_oak_log
setblock 393 289 310 minecraft:shroomlight
fill 393 289 311 393 294 311 minecraft:stripped_oak_log
setblock 393 289 312 minecraft:shroomlight
fill 393 289 313 393 294 313 minecraft:stripped_oak_log
setblock 393 289 314 minecraft:shroomlight
fill 393 289 315 393 294 315 minecraft:stripped_oak_log
setblock 393 289 316 minecraft:shroomlight
setblock 394 289 277 minecraft:stripped_oak_log
fill 394 289 306 394 294 306 minecraft:stripped_oak_log
setblock 394 289 307 minecraft:shroomlight
fill 394 289 308 394 294 308 minecraft:stripped_oak_log
setblock 394 289 309 minecraft:shroomlight
fill 394 289 310 394 294 310 minecraft:stripped_oak_log
setblock 394 289 311 minecraft:shroomlight
fill 394 289 312 394 294 312 minecraft:stripped_oak_log
setblock 394 289 313 minecraft:shroomlight
setblock 394 289 315 minecraft:shroomlight
setblock 395 289 276 minecraft:stripped_oak_log
setblock 395 289 306 minecraft:shroomlight
fill 395 289 307 395 294 307 minecraft:stripped_oak_log
setblock 395 289 308 minecraft:shroomlight
fill 395 289 309 395 294 309 minecraft:stripped_oak_log
setblock 395 289 310 minecraft:shroomlight
fill 395 289 311 395 294 311 minecraft:stripped_oak_log
setblock 395 289 312 minecraft:shroomlight
fill 395 289 313 395 294 313 minecraft:stripped_oak_log
setblock 395 289 314 minecraft:shroomlight
fill 395 289 315 395 294 315 minecraft:stripped_oak_log
setblock 395 289 316 minecraft:shroomlight
fill 396 289 276 399 289 276 minecraft:red_terracotta
fill 396 289 306 396 294 306 minecraft:stripped_oak_log
setblock 396 289 307 minecraft:shroomlight
fill 396 289 308 396 294 308 minecraft:stripped_oak_log
setblock 396 289 309 minecraft:shroomlight
fill 396 289 310 396 294 310 minecraft:stripped_oak_log
setblock 396 289 311 minecraft:shroomlight
fill 396 289 312 396 294 312 minecraft:stripped_oak_log
setblock 396 289 313 minecraft:shroomlight
setblock 396 289 315 minecraft:shroomlight
fill 396 289 316 399 289 316 minecraft:red_terracotta
setblock 400 289 276 minecraft:stripped_oak_log
setblock 400 289 316 minecraft:stripped_oak_log
fill 401 289 276 401 292 276 minecraft:red_terracotta
fill 401 289 316 404 289 316 minecraft:red_terracotta
setblock 404 289 277 minecraft:shroomlight
setblock 404 289 279 minecraft:shroomlight
fill 404 289 280 404 300 280 minecraft:stripped_oak_log
setblock 404 289 281 minecraft:shroomlight
fill 404 289 282 404 300 282 minecraft:stripped_oak_log
setblock 404 289 283 minecraft:shroomlight
fill 404 289 315 405 289 315 minecraft:red_terracotta
setblock 405 289 276 minecraft:shroomlight
fill 405 289 277 405 292 277 minecraft:red_terracotta
setblock 405 289 278 minecraft:shroomlight
setblock 405 289 280 minecraft:shroomlight
fill 405 289 281 405 300 281 minecraft:stripped_oak_log
setblock 405 289 282 minecraft:shroomlight
fill 405 289 283 405 300 283 minecraft:stripped_oak_log
setblock 405 289 316 minecraft:stripped_oak_log
fill 406 289 276 406 292 276 minecraft:red_terracotta
setblock 406 289 277 minecraft:shroomlight
setblock 406 289 279 minecraft:shroomlight
setblock 406 289 281 minecraft:shroomlight
fill 406 289 282 406 300 282 minecraft:stripped_oak_log
setblock 406 289 283 minecraft:shroomlight
setblock 406 289 315 minecraft:stripped_oak_log
fill 406 289 316 409 289 316 minecraft:red_terracotta
setblock 407 289 276 minecraft:shroomlight
fill 407 289 277 407 290 277 minecraft:red_terracotta
setblock 407 289 278 minecraft:shroomlight
setblock 407 289 280 minecraft:shroomlight
setblock 407 289 282 minecraft:shroomlight
setblock 407 289 315 minecraft:red_terracotta
fill 408 289 276 408 290 276 minecraft:red_terracotta
setblock 408 289 277 minecraft:shroomlight
setblock 408 289 279 minecraft:shroomlight
setblock 408 289 281 minecraft:shroomlight
fill 408 289 282 408 300 282 minecraft:stripped_oak_log
setblock 408 289 283 minecraft:shroomlight
setblock 409 289 276 minecraft:shroomlight
fill 409 289 277 409 300 277 minecraft:stripped_oak_log
setblock 409 289 278 minecraft:shroomlight
setblock 409 289 280 minecraft:shroomlight
setblock 409 289 282 minecraft:shroomlight
fill 409 289 283 409 300 283 minecraft:stripped_oak_log
setblock 410 289 276 minecraft:stripped_oak_log
setblock 410 289 277 minecraft:shroomlight
setblock 410 289 279 minecraft:shroomlight
setblock 410 289 281 minecraft:shroomlight
setblock 410 289 283 minecraft:shroomlight
setblock 410 289 316 minecraft:stripped_oak_log
setblock 411 289 276 minecraft:red_terracotta
setblock 411 289 316 minecraft:red_terracotta
setblock 413 289 280 minecraft:shroomlight
setblock 413 289 282 minecraft:shroomlight
setblock 413 289 284 minecraft:shroomlight
setblock 413 289 286 minecraft:shroomlight
setblock 413 289 288 minecraft:shroomlight
fill 413 289 289 413 300 289 minecraft:stripped_oak_log
setblock 413 289 290 minecraft:shroomlight
setblock 414 289 281 minecraft:shroomlight
setblock 414 289 283 minecraft:shroomlight
setblock 414 289 285 minecraft:shroomlight
setblock 414 289 287 minecraft:shroomlight
setblock 414 289 289 minecraft:shroomlight
setblock 415 289 280 minecraft:shroomlight
setblock 415 289 282 minecraft:shroomlight
setblock 415 289 284 minecraft:shroomlight
setblock 415 289 286 minecraft:shroomlight
setblock 415 289 288 minecraft:shroomlight
setblock 415 289 290 minecraft:shroomlight
setblock 416 289 281 minecraft:shroomlight
setblock 416 289 283 minecraft:shroomlight
setblock 416 289 285 minecraft:shroomlight
setblock 416 289 287 minecraft:shroomlight
setblock 416 289 289 minecraft:shroomlight
setblock 416 289 300 minecraft:stripped_oak_log
setblock 417 289 280 minecraft:shroomlight
setblock 417 289 282 minecraft:shroomlight
setblock 417 289 284 minecraft:shroomlight
setblock 417 289 286 minecraft:shroomlight
setblock 417 289 288 minecraft:shroomlight
setblock 417 289 290 minecraft:shroomlight
fill 417 289 295 417 290 295 minecraft:red_terracotta
setblock 417 289 299 minecraft:stripped_oak_log
fill 417 289 300 417 292 300 minecraft:red_terracotta
fill 377 290 276 378 290 276 minecraft:red_terracotta
setblock 377 290 278 minecraft:stripped_oak_log
fill 377 290 279 378 292 279 minecraft:red_terracotta
setblock 377 290 283 minecraft:stripped_oak_log
fill 377 290 284 377 293 284 minecraft:red_terracotta
fill 377 290 296 377 291 296 minecraft:stripped_oak_log
fill 377 290 298 377 291 298 minecraft:stripped_oak_log
fill 377 290 300 377 291 300 minecraft:stripped_oak_log
fill 377 290 302 377 291 302 minecraft:stripped_oak_log
fill 377 290 304 377 291 304 minecraft:stripped_oak_log
fill 378 290 280 378 291 280 minecraft:red_terracotta
fill 378 290 295 378 291 295 minecraft:stripped_oak_log
fill 378 290 297 378 291 297 minecraft:stripped_oak_log
fill 378 290 299 378 291 299 minecraft:stripped_oak_log
fill 378 290 301 378 291 301 minecraft:stripped_oak_log
fill 378 290 303 378 291 303 minecraft:stripped_oak_log
fill 378 290 305 378 291 305 minecraft:stripped_oak_log
setblock 379 290 276 minecraft:stripped_oak_log
fill 379 290 277 382 290 277 minecraft:red_terracotta
fill 379 290 296 379 291 296 minecraft:stripped_oak_log
fill 379 290 298 379 291 298 minecraft:stripped_oak_log
fill 379 290 300 379 291 300 minecraft:stripped_oak_log
fill 379 290 302 379 291 302 minecraft:stripped_oak_log
fill 379 290 304 379 291 304 minecraft:stripped_oak_log
fill 380 290 276 383 290 276 minecraft:red_terracotta
fill 380 290 295 380 291 295 minecraft:stripped_oak_log
fill 380 290 297 380 291 297 minecraft:stripped_oak_log
fill 380 290 299 380 291 299 minecraft:stripped_oak_log
fill 380 290 301 380 291 301 minecraft:stripped_oak_log
fill 380 290 303 380 291 303 minecraft:stripped_oak_log
fill 380 290 305 380 291 305 minecraft:stripped_oak_log
setblock 381 290 278 minecraft:red_terracotta
fill 381 290 296 381 291 296 minecraft:stripped_oak_log
fill 381 290 298 381 291 298 minecraft:stripped_oak_log
fill 381 290 300 381 291 300 minecraft:stripped_oak_log
fill 381 290 302 381 291 302 minecraft:stripped_oak_log
fill 381 290 304 381 291 304 minecraft:stripped_oak_log
setblock 382 290 278 minecraft:stripped_oak_log
fill 382 290 295 382 291 295 minecraft:stripped_oak_log
fill 382 290 297 382 291 297 minecraft:stripped_oak_log
fill 382 290 299 382 291 299 minecraft:stripped_oak_log
fill 382 290 301 382 291 301 minecraft:stripped_oak_log
fill 382 290 303 382 291 303 minecraft:stripped_oak_log
fill 382 290 305 382 291 305 minecraft:stripped_oak_log
setblock 383 290 277 minecraft:stripped_oak_log
fill 383 290 278 383 293 278 minecraft:red_terracotta
fill 383 290 296 383 291 296 minecraft:stripped_oak_log
fill 383 290 298 383 291 298 minecraft:stripped_oak_log
fill 383 290 300 383 291 300 minecraft:stripped_oak_log
fill 383 290 302 383 291 302 minecraft:stripped_oak_log
fill 383 290 304 383 291 304 minecraft:stripped_oak_log
setblock 383 290 316 minecraft:red_terracotta
setblock 384 290 276 minecraft:stripped_oak_log
fill 384 290 277 384 293 277 minecraft:red_terracotta
fill 384 290 279 384 291 279 minecraft:red_terracotta
fill 384 290 295 384 291 295 minecraft:stripped_oak_log
fill 384 290 297 384 291 297 minecraft:stripped_oak_log
fill 384 290 299 384 291 299 minecraft:stripped_oak_log
fill 384 290 301 384 291 301 minecraft:stripped_oak_log
fill 384 290 303 384 291 303 minecraft:stripped_oak_log
fill 384 290 305 384 291 305 minecraft:stripped_oak_log
setblock 384 290 316 minecraft:stripped_oak_log
fill 385 290 276 385 293 276 minecraft:red_terracotta
fill 385 290 316 385 293 316 minecraft:red_terracotta
setblock 386 290 279 minecraft:stripped_oak_log
setblock 387 290 278 minecraft:stripped_oak_log
fill 387 290 279 387 293 279 minecraft:red_terracotta
setblock 388 290 277 minecraft:stripped_oak_log
fill 388 290 278 388 293 278 minecraft:red_terracotta
fill 388 290 307 388 291 307 minecraft:stripped_oak_log
fill 388 290 309 388 291 309 minecraft:stripped_oak_log
fill 388 290 311 388 291 311 minecraft:stripped_oak_log
fill 388 290 313 388 291 313 minecraft:stripped_oak_log
fill 388 290 315 390 291 315 minecraft:stripped_oak_log
setblock 389 290 276 minecraft:stripped_oak_log
fill 389 290 277 392 290 277 minecraft:red_terracotta
fill 389 290 306 389 291 306 minecraft:stripped_oak_log
fill 389 290 308 389 291 308 minecraft:stripped_oak_log
fill 389 290 310 389 291 310 minecraft:stripped_oak_log
fill 389 290 312 389 291 312 minecraft:stripped_oak_log
fill 389 290 314 389 291 314 minecraft:stripped_oak_log
setblock 389 290 316 minecraft:stripped_oak_log
fill 390 290 276 393 290 276 minecraft:red_terracotta
fill 390 290 307 390 291 307 minecraft:stripped_oak_log
fill 390 290 309 390 291 309 minecraft:stripped_oak_log
fill 390 290 311 390 291 311 minecraft:stripped_oak_log
fill 390 290 313 390 291 313 minecraft:stripped_oak_log
fill 390 290 316 391 291 316 minecraft:red_terracotta
fill 391 290 306 391 291 306 minecraft:stripped_oak_log
fill 391 290 308 391 291 308 minecraft:stripped_oak_log
fill 391 290 310 391 291 310 minecraft:stripped_oak_log
fill 391 290 312 391 291 312 minecraft:stripped_oak_log
fill 391 290 314 391 291 314 minecraft:stripped_oak_log
fill 392 290 307 392 291 307 minecraft:stripped_oak_log
fill 392 290 309 392 291 309 minecraft:stripped_oak_log
fill 392 290 311 392 291 311 minecraft:stripped_oak_log
fill 392 290 313 392 291 313 minecraft:stripped_oak_log
fill 392 290 315 392 291 315 minecraft:stripped_oak_log
setblock 393 290 277 minecraft:stripped_oak_log
fill 393 290 306 393 291 306 minecraft:stripped_oak_log
fill 393 290 308 393 291 308 minecraft:stripped_oak_log
fill 393 290 310 393 291 310 minecraft:stripped_oak_log
fill 393 290 312 393 291 312 minecraft:stripped_oak_log
fill 393 290 314 393 291 314 minecraft:stripped_oak_log
setblock 393 290 316 minecraft:red_terracotta
setblock 394 290 276 minecraft:stripped_oak_log
fill 394 290 307 394 291 307 minecraft:stripped_oak_log
fill 394 290 309 394 291 309 minecraft:stripped_oak_log
fill 394 290 311 394 291 311 minecraft:stripped_oak_log
fill 394 290 313 394 291 313 minecraft:stripped_oak_log
fill 394 290 315 394 291 316 minecraft:stripped_oak_log
fill 395 290 276 398 290 276 minecraft:red_terracotta
fill 395 290 306 395 291 306 minecraft:stripped_oak_log
fill 395 290 308 395 291 308 minecraft:stripped_oak_log
fill 395 290 310 395 291 310 minecraft:stripped_oak_log
fill 395 290 312 395 291 312 minecraft:stripped_oak_log
fill 395 290 314 395 291 314 minecraft:stripped_oak_log
fill 395 290 316 396 291 316 minecraft:stripped_oak_log
fill 396 290 307 396 291 307 minecraft:stripped_oak_log
fill 396 290 309 396 291 309 minecraft:stripped_oak_log
fill 396 290 311 396 291 311 minecraft:stripped_oak_log
fill 396 290 313 396 291 313 minecraft:stripped_oak_log
fill 396 290 315 396 291 315 minecraft:stripped_oak_log
setblock 399 290 276 minecraft:stripped_oak_log
setblock 399 290 316 minecraft:stripped_oak_log
fill 400 290 276 400 293 276 minecraft:red_terracotta
fill 400 290 316 403 290 316 minecraft:red_terracotta
setblock 404 290 276 minecraft:stripped_oak_log
fill 404 290 277 404 291 277 minecraft:red_terracotta
fill 404 290 279 404 291 279 minecraft:stripped_oak_log
fill 404 290 281 404 291 281 minecraft:stripped_oak_log
fill 404 290 283 404 291 283 minecraft:stripped_oak_log
setblock 404 290 316 minecraft:stripped_oak_log
fill 405 290 276 405 291 276 minecraft:red_terracotta
fill 405 290 278 405 291 278 minecraft:stripped_oak_log
fill 405 290 280 405 291 280 minecraft:stripped_oak_log
fill 405 290 282 405 291 282 minecraft:stripped_oak_log
fill 405 290 316 408 290 316 minecraft:red_terracotta
fill 406 290 277 406 291 277 minecraft:red_terracotta
fill 406 290 279 406 291 279 minecraft:stripped_oak_log
fill 406 290 281 406 291 281 minecraft:stripped_oak_log
fill 406 290 283 406 291 283 minecraft:stripped_oak_log
fill 407 290 276 407 291 276 minecraft:red_terracotta
fill 407 290 278 407 291 278 minecraft:stripped_oak_log
fill 407 290 280 407 291 280 minecraft:stripped_oak_log
fill 407 290 282 407 291 282 minecraft:stripped_oak_log
fill 408 290 277 408 291 277 minecraft:stripped_oak_log
fill 408 290 279 408 291 279 minecraft:stripped_oak_log
fill 408 290 281 408 291 281 minecraft:stripped_oak_log
fill 408 290 283 408 291 283 minecraft:stripped_oak_log
setblock 409 290 276 minecraft:stripped_oak_log
fill 409 290 278 409 291 278 minecraft:stripped_oak_log
fill 409 290 280 409 291 280 minecraft:stripped_oak_log
fill 409 290 282 409 291 282 minecraft:stripped_oak_log
setblock 409 290 316 minecraft:stripped_oak_log
setblock 410 290 276 minecraft:red_terracotta
fill 410 290 277 410 291 277 minecraft:stripped_oak_log
fill 410 290 279 410 291 279 minecraft:stripped_oak_log
fill 410 290 281 410 291 281 minecraft:stripped_oak_log
fill 410 290 283 410 291 283 minecraft:stripped_oak_log
fill 413 290 280 413 291 280 minecraft:stripped_oak_log
fill 413 290 282 413 291 282 minecraft:stripped_oak_log
fill 413 290 284 413 291 284 minecraft:stripped_oak_log
fill 413 290 286 413 291 286 minecraft:stripped_oak_log
fill 413 290 288 413 291 288 minecraft:stripped_oak_log
fill 413 290 290 413 291 290 minecraft:stripped_oak_log
fill 414 290 281 414 291 281 minecraft:stripped_oak_log
fill 414 290 283 414 291 283 minecraft:stripped_oak_log
fill 414 290 285 414 291 285 minecraft:stripped_oak_log
fill 414 290 287 414 291 287 minecraft:stripped_oak_log
fill 414 290 289 414 291 289 minecraft:stripped_oak_log
fill 415 290 280 415 291 280 minecraft:stripped_oak_log
fill 415 290 282 415 291 282 minecraft:stripped_oak_log
fill 415 290 284 415 291 284 minecraft:stripped_oak_log
fill 415 290 286 415 291 286 minecraft:stripped_oak_log
fill 415 290 288 415 291 288 minecraft:stripped_oak_log
fill 415 290 290 415 291 290 minecraft:stripped_oak_log
fill 416 290 281 416 291 281 minecraft:stripped_oak_log
fill 416 290 283 416 291 283 minecraft:stripped_oak_log
fill 416 290 285 416 291 285 minecraft:stripped_oak_log
fill 416 290 287 416 291 287 minecraft:stripped_oak_log
fill 416 290 289 416 291 289 minecraft:stripped_oak_log
fill 417 290 280 417 291 280 minecraft:stripped_oak_log
fill 417 290 282 417 291 282 minecraft:stripped_oak_log
fill 417 290 284 417 291 284 minecraft:stripped_oak_log
fill 417 290 286 417 291 286 minecraft:stripped_oak_log
fill 417 290 288 417 291 288 minecraft:stripped_oak_log
fill 417 290 290 417 291 290 minecraft:stripped_oak_log
setblock 417 290 298 minecraft:stripped_oak_log
fill 417 290 299 417 293 299 minecraft:red_terracotta
setblock 417 290 303 minecraft:stripped_oak_log
setblock 377 291 276 minecraft:red_terracotta
setblock 377 291 277 minecraft:stripped_oak_log
fill 377 291 278 378 293 278 minecraft:red_terracotta
setblock 377 291 282 minecraft:stripped_oak_log
fill 377 291 283 378 293 283 minecraft:red_terracotta
fill 377 291 285 377 292 285 minecraft:red_terracotta
setblock 378 291 276 minecraft:stripped_oak_log
setblock 378 291 281 minecraft:stripped_oak_log
fill 378 291 282 378 294 282 minecraft:red_terracotta
fill 379 291 276 381 291 277 minecraft:red_terracotta
setblock 381 291 278 minecraft:stripped_oak_log
setblock 382 291 276 minecraft:red_terracotta
setblock 382 291 277 minecraft:stripped_oak_log
fill 382 291 278 382 294 278 minecraft:red_terracotta
setblock 382 291 316 minecraft:red_terracotta
setblock 383 291 276 minecraft:stripped_oak_log
fill 383 291 277 383 294 277 minecraft:red_terracotta
fill 383 291 279 383 292 279 minecraft:red_terracotta
setblock 383 291 316 minecraft:stripped_oak_log
fill 384 291 276 384 294 276 minecraft:red_terracotta
fill 384 291 316 384 294 316 minecraft:red_terracotta
setblock 385 291 278 minecraft:red_terracotta
setblock 385 291 279 minecraft:stripped_oak_log
setblock 386 291 278 minecraft:stripped_oak_log
fill 386 291 279 386 294 279 minecraft:red_terracotta
setblock 387 291 277 minecraft:stripped_oak_log
fill 387 291 278 387 294 278 minecraft:red_terracotta
setblock 388 291 276 minecraft:stripped_oak_log
fill 388 291 277 391 291 277 minecraft:red_terracotta
setblock 388 291 316 minecraft:stripped_oak_log
fill 389 291 276 392 291 276 minecraft:red_terracotta
fill 389 291 278 390 291 278 minecraft:red_terracotta
setblock 389 291 316 minecraft:red_terracotta
setblock 392 291 277 minecraft:stripped_oak_log
setblock 393 291 276 minecraft:stripped_oak_log
setblock 393 291 316 minecraft:stripped_oak_log
fill 394 291 276 395 291 276 minecraft:red_terracotta
fill 399 291 276 399 294 276 minecraft:red_terracotta
fill 399 291 316 402 291 316 minecraft:red_terracotta
setblock 403 291 276 minecraft:stripped_oak_log
setblock 403 291 316 minecraft:stripped_oak_log
fill 404 291 276 404 294 276 minecraft:red_terracotta
fill 404 291 316 407 291 316 minecraft:red_terracotta
fill 407 291 277 407 300 277 minecraft:stripped_oak_log
setblock 408 291 276 minecraft:stripped_oak_log
setblock 408 291 316 minecraft:stripped_oak_log
setblock 409 291 276 minecraft:red_terracotta
setblock 409 291 316 minecraft:red_terracotta
fill 410 291 276 410 300 276 minecraft:stripped_oak_log
setblock 417 291 281 minecraft:red_terracotta
setblock 417 291 297 minecraft:stripped_oak_log
fill 417 291 298 417 294 298 minecraft:red_terracotta
setblock 417 291 302 minecraft:stripped_oak_log
fill 417 291 303 417 293 304 minecraft:red_terracotta
fill 376 292 275 376 295 317 minecraft:white_terracotta
fill 377 292 275 418 295 275 minecraft:white_terracotta
setblock 377 292 276 minecraft:stripped_oak_log
fill 377 292 277 380 292 277 minecraft:red_terracotta
setblock 377 292 281 minecraft:stripped_oak_log
fill 377 292 282 377 295 282 minecraft:red_terracotta
setblock 377 292 286 minecraft:stripped_oak_log
fill 377 292 287 377 295 287 minecraft:red_terracotta
setblock 377 292 296 minecraft:shroomlight
setblock 377 292 298 minecraft:shroomlight
setblock 377 292 300 minecraft:shroomlight
setblock 377 292 302 minecraft:shroomlight
setblock 377 292 304 minecraft:shroomlight
fill 377 292 317 418 295 317 minecraft:white_terracotta
fill 378 292 276 381 292 276 minecraft:red_terracotta
setblock 378 292 280 minecraft:stripped_oak_log
fill 378 292 281 379 294 281 minecraft:red_terracotta
setblock 378 292 284 minecraft:red_terracotta
setblock 378 292 295 minecraft:shroomlight
setblock 378 292 297 minecraft:shroomlight
setblock 378 292 299 minecraft:shroomlight
setblock 378 292 301 minecraft:shroomlight
setblock 378 292 303 minecraft:shroomlight
setblock 378 292 305 minecraft:shroomlight
setblock 379 292 279 minecraft:stripped_oak_log
fill 379 292 280 379 295 280 minecraft:red_terracotta
fill 379 292 282 379 293 282 minecraft:red_terracotta
setblock 379 292 296 minecraft:shroomlight
setblock 379 292 298 minecraft:shroomlight
setblock 379 292 300 minecraft:shroomlight
setblock 379 292 302 minecraft:shroomlight
setblock 379 292 304 minecraft:shroomlight
setblock 380 292 278 minecraft:stripped_oak_log
setblock 380 292 295 minecraft:shroomlight
setblock 380 292 297 minecraft:shroomlight
setblock 380 292 299 minecraft:shroomlight
setblock 380 292 301 minecraft:shroomlight
setblock 380 292 303 minecraft:shroomlight
setblock 380 292 305 minecraft:shroomlight
setblock 381 292 277 minecraft:stripped_oak_log
fill 381 292 278 381 295 278 minecraft:red_terracotta
setblock 381 292 296 minecraft:shroomlight
setblock 381 292 298 minecraft:shroomlight
setblock 381 292 300 minecraft:shroomlight
setblock 381 292 302 minecraft:shroomlight
setblock 381 292 304 minecraft:shroomlight
setblock 382 292 276 minecraft:stripped_oak_log
fill 382 292 277 382 295 277 minecraft:red_terracotta
fill 382 292 279 382 293 279 minecraft:red_terracotta
setblock 382 292 295 minecraft:shroomlight
setblock 382 292 297 minecraft:shroomlight
setblock 382 292 299 minecraft:shroomlight
setblock 382 292 301 minecraft:shroomlight
setblock 382 292 303 minecraft:shroomlight
setblock 382 292 305 minecraft:shroomlight
setblock 382 292 316 minecraft:stripped_oak_log
fill 383 292 276 383 295 276 minecraft:red_terracotta
setblock 383 292 296 minecraft:shroomlight
setblock 383 292 298 minecraft:shroomlight
setblock 383 292 300 minecraft:shroomlight
setblock 383 292 302 minecraft:shroomlight
setblock 383 292 304 minecraft:shroomlight
fill 383 292 316 383 295 316 minecraft:red_terracotta
setblock 384 292 279 minecraft:stripped_oak_log
setblock 384 292 295 minecraft:shroomlight
setblock 384 292 297 minecraft:shroomlight
setblock 384 292 299 minecraft:shroomlight
setblock 384 292 301 minecraft:shroomlight
setblock 384 292 303 minecraft:shroomlight
setblock 384 292 305 minecraft:shroomlight
setblock 385 292 278 minecraft:stripped_oak_log
fill 385 292 279 385 295 279 minecraft:red_terracotta
setblock 386 292 277 minecraft:stripped_oak_log
fill 386 292 278 386 295 278 minecraft:red_terracotta
setblock 387 292 276 minecraft:stripped_oak_log
fill 387 292 277 390 292 277 minecraft:red_terracotta
setblock 387 292 316 minecraft:stripped_oak_log
fill 388 292 276 391 292 276 minecraft:red_terracotta
setblock 388 292 307 minecraft:shroomlight
setblock 388 292 309 minecraft:shroomlight
setblock 388 292 311 minecraft:shroomlight
setblock 388 292 313 minecraft:shroomlight
setblock 388 292 315 minecraft:shroomlight
fill 388 292 316 388 295 316 minecraft:red_terracotta
setblock 389 292 278 minecraft:red_terracotta
setblock 389 292 306 minecraft:shroomlight
setblock 389 292 308 minecraft:shroomlight
setblock 389 292 310 minecraft:shroomlight
setblock 389 292 312 minecraft:shroomlight
setblock 389 292 314 minecraft:shroomlight
fill 389 292 315 389 294 315 minecraft:stripped_oak_log
setblock 389 292 316 minecraft:shroomlight
setblock 390 292 278 minecraft:stripped_oak_log
setblock 390 292 307 minecraft:shroomlight
setblock 390 292 309 minecraft:shroomlight
setblock 390 292 311 minecraft:shroomlight
setblock 390 292 313 minecraft:shroomlight
setblock 390 292 315 minecraft:shroomlight
fill 390 292 316 390 293 316 minecraft:red_terracotta
setblock 391 292 277 minecraft:stripped_oak_log
setblock 391 292 306 minecraft:shroomlight
setblock 391 292 308 minecraft:shroomlight
setblock 391 292 310 minecraft:shroomlight
setblock 391 292 312 minecraft:shroomlight
setblock 391 292 314 minecraft:shroomlight
setblock 391 292 316 minecraft:shroomlight
setblock 392 292 276 minecraft:stripped_oak_log
setblock 392 292 277 minecraft:red_terracotta
setblock 392 292 307 minecraft:shroomlight
setblock 392 292 309 minecraft:shroomlight
setblock 392 292 311 minecraft:shroomlight
setblock 392 292 313 minecraft:shroomlight
setblock 392 292 315 minecraft:shroomlight
setblock 392 292 316 minecraft:stripped_oak_log
fill 393 292 276 394 293 276 minecraft:red_terracotta
setblock 393 292 306 minecraft:shroomlight
setblock 393 292 308 minecraft:shroomlight
setblock 393 292 310 minecraft:shroomlight
setblock 393 292 312 minecraft:shroomlight
setblock 393 292 314 minecraft:shroomlight
setblock 393 292 316 minecraft:shroomlight
setblock 394 292 307 minecraft:shroomlight
setblock 394 292 309 minecraft:shroomlight
setblock 394 292 311 minecraft:shroomlight
setblock 394 292 313 minecraft:shroomlight
setblock 394 292 315 minecraft:shroomlight
fill 394 292 316 394 294 316 minecraft:stripped_oak_log
setblock 395 292 306 minecraft:shroomlight
setblock 395 292 308 minecraft:shroomlight
setblock 395 292 310 minecraft:shroomlight
setblock 395 292 312 minecraft:shroomlight
setblock 395 292 314 minecraft:shroomlight
setblock 395 292 316 minecraft:shroomlight
setblock 396 292 307 minecraft:shroomlight
setblock 396 292 309 minecraft:shroomlight
setblock 396 292 311 minecraft:shroomlight
setblock 396 292 313 minecraft:shroomlight
setblock 396 292 315 minecraft:shroomlight
fill 396 292 316 396 294 316 minecraft:stripped_oak_log
fill 399 292 316 401 292 316 minecraft:red_terracotta
setblock 402 292 276 minecraft:stripped_oak_log
setblock 402 292 316 minecraft:stripped_oak_log
fill 403 292 276 403 295 276 minecraft:red_terracotta
fill 403 292 316 406 292 316 minecraft:red_terracotta
setblock 404 292 277 minecraft:shroomlight
setblock 404 292 279 minecraft:shroomlight
setblock 404 292 281 minecraft:shroomlight
setblock 404 292 283 minecraft:shroomlight
setblock 405 292 276 minecraft:shroomlight
setblock 405 292 278 minecraft:shroomlight
setblock 405 292 280 minecraft:shroomlight
setblock 405 292 282 minecraft:shroomlight
setblock 406 292 277 minecraft:shroomlight
setblock 406 292 279 minecraft:shroomlight
setblock 406 292 281 minecraft:shroomlight
setblock 406 292 283 minecraft:shroomlight
setblock 407 292 276 minecraft:shroomlight
setblock 407 292 278 minecraft:shroomlight
setblock 407 292 280 minecraft:shroomlight
setblock 407 292 282 minecraft:shroomlight
setblock 407 292 316 minecraft:stripped_oak_log
fill 408 292 276 408 294 276 minecraft:red_terracotta
setblock 408 292 277 minecraft:shroomlight
setblock 408 292 279 minecraft:shroomlight
setblock 408 292 281 minecraft:shroomlight
setblock 408 292 283 minecraft:shroomlight
setblock 408 292 316 minecraft:red_terracotta
setblock 409 292 276 minecraft:shroomlight
setblock 409 292 278 minecraft:shroomlight
setblock 409 292 280 minecraft:shroomlight
setblock 409 292 282 minecraft:shroomlight
setblock 410 292 277 minecraft:shroomlight
setblock 410 292 279 minecraft:shroomlight
setblock 410 292 281 minecraft:shroomlight
setblock 410 292 283 minecraft:shroomlight
setblock 413 292 280 minecraft:shroomlight
setblock 413 292 282 minecraft:shroomlight
setblock 413 292 284 minecraft:shroomlight
setblock 413 292 286 minecraft:shroomlight
setblock 413 292 288 minecraft:shroomlight
setblock 413 292 290 minecraft:shroomlight
setblock 414 292 281 minecraft:shroomlight
setblock 414 292 283 minecraft:shroomlight
setblock 414 292 285 minecraft:shroomlight
setblock 414 292 287 minecraft:shroomlight
setblock 414 292 289 minecraft:shroomlight
setblock 415 292 280 minecraft:shroomlight
setblock 415 292 282 minecraft:shroomlight
setblock 415 292 284 minecraft:shroomlight
setblock 415 292 286 minecraft:shroomlight
setblock 415 292 288 minecraft:shroomlight
setblock 415 292 290 minecraft:shroomlight
setblock 416 292 281 minecraft:shroomlight
setblock 416 292 283 minecraft:shroomlight
setblock 416 292 285 minecraft:shroomlight
setblock 416 292 287 minecraft:shroomlight
setblock 416 292 289 minecraft:shroomlight
fill 417 292 279 417 293 279 minecraft:red_terracotta
setblock 417 292 280 minecraft:shroomlight
setblock 417 292 281 minecraft:stripped_oak_log
setblock 417 292 282 minecraft:shroomlight
fill 417 292 283 417 294 283 minecraft:red_terracotta
setblock 417 292 284 minecraft:shroomlight
setblock 417 292 285 minecraft:red_terracotta
setblock 417 292 286 minecraft:shroomlight
setblock 417 292 288 minecraft:shroomlight
setblock 417 292 290 minecraft:shroomlight
setblock 417 292 296 minecraft:stripped_oak_log
fill 417 292 297 417 295 297 minecraft:red_terracotta
setblock 417 292 301 minecraft:stripped_oak_log
fill 417 292 302 417 295 302 minecraft:red_terracotta
setblock 417 292 305 minecraft:red_terracotta
fill 418 292 276 418 295 316 minecraft:white_terracotta
fill 377 293 276 379 293 277 minecraft:red_terracotta
setblock 377 293 279 minecraft:red_terracotta
setblock 377 293 280 minecraft:stripped_oak_log
fill 377 293 281 377 296 281 minecraft:red_terracotta
setblock 377 293 285 minecraft:stripped_oak_log
fill 377 293 286 378 295 286 minecraft:red_terracotta
fill 377 293 288 377 294 288 minecraft:red_terracotta
fill 377 293 296 377 294 296 minecraft:stripped_oak_log
fill 377 293 298 377 294 298 minecraft:stripped_oak_log
setblock 377 293 300 minecraft:stripped_oak_log
fill 377 293 301 377 294 303 minecraft:red_terracotta
fill 377 293 304 377 294 304 minecraft:stripped_oak_log
setblock 378 293 279 minecraft:stripped_oak_log
fill 378 293 280 378 296 280 minecraft:red_terracotta
setblock 378 293 284 minecraft:stripped_oak_log
fill 378 293 285 378 296 285 minecraft:red_terracotta
fill 378 293 295 378 294 295 minecraft:stripped_oak_log
fill 378 293 297 378 294 297 minecraft:stripped_oak_log
fill 378 293 299 378 294 299 minecraft:stripped_oak_log
fill 378 293 301 378 294 301 minecraft:stripped_oak_log
fill 378 293 303 378 294 303 minecraft:stripped_oak_log
fill 378 293 305 378 294 305 minecraft:stripped_oak_log
setblock 379 293 278 minecraft:stripped_oak_log
fill 379 293 279 379 296 279 minecraft:red_terracotta
setblock 379 293 283 minecraft:stripped_oak_log
fill 379 293 284 379 296 284 minecraft:red_terracotta
setblock 379 293 285 minecraft:light[level=12]
setblock 379 293 292 minecraft:light[level=12]
fill 379 293 296 379 294 296 minecraft:stripped_oak_log
fill 379 293 298 379 294 298 minecraft:stripped_oak_log
fill 379 293 300 379 294 300 minecraft:stripped_oak_log
fill 379 293 302 379 294 302 minecraft:stripped_oak_log
fill 379 293 304 379 294 304 minecraft:stripped_oak_log
setblock 379 293 306 minecraft:light[level=12]
setblock 379 293 313 minecraft:light[level=12]
setblock 380 293 276 minecraft:red_terracotta
setblock 380 293 277 minecraft:stripped_oak_log
fill 380 293 278 380 296 278 minecraft:red_terracotta
fill 380 293 295 380 294 295 minecraft:stripped_oak_log
fill 380 293 297 380 294 297 minecraft:stripped_oak_log
fill 380 293 299 380 294 299 minecraft:stripped_oak_log
fill 380 293 301 380 294 301 minecraft:stripped_oak_log
fill 380 293 303 380 294 303 minecraft:stripped_oak_log
fill 380 293 305 380 294 305 minecraft:stripped_oak_log
setblock 381 293 276 minecraft:stripped_oak_log
fill 381 293 277 381 296 277 minecraft:red_terracotta
fill 381 293 279 381 294 279 minecraft:red_terracotta
fill 381 293 296 381 294 296 minecraft:stripped_oak_log
fill 381 293 298 381 294 298 minecraft:stripped_oak_log
fill 381 293 300 381 294 300 minecraft:stripped_oak_log
fill 381 293 302 381 294 302 minecraft:stripped_oak_log
fill 381 293 304 381 294 304 minecraft:stripped_oak_log
setblock 381 293 316 minecraft:stripped_oak_log
fill 382 293 276 382 296 276 minecraft:red_terracotta
fill 382 293 295 382 294 295 minecraft:stripped_oak_log
fill 382 293 297 382 294 297 minecraft:stripped_oak_log
fill 382 293 299 382 294 299 minecraft:stripped_oak_log
fill 382 293 301 382 294 301 minecraft:stripped_oak_log
fill 382 293 303 382 294 303 minecraft:stripped_oak_log
fill 382 293 305 382 294 305 minecraft:stripped_oak_log
fill 382 293 316 382 296 316 minecraft:red_terracotta
setblock 383 293 279 minecraft:stripped_oak_log
fill 383 293 296 383 294 296 minecraft:stripped_oak_log
fill 383 293 298 383 294 298 minecraft:stripped_oak_log
fill 383 293 300 383 294 300 minecraft:stripped_oak_log
fill 383 293 302 383 294 302 minecraft:stripped_oak_log
fill 383 293 304 383 294 304 minecraft:stripped_oak_log
setblock 384 293 278 minecraft:stripped_oak_log
fill 384 293 279 384 296 279 minecraft:red_terracotta
fill 384 293 295 384 294 295 minecraft:stripped_oak_log
fill 384 293 297 384 294 297 minecraft:stripped_oak_log
fill 384 293 299 384 294 299 minecraft:stripped_oak_log
fill 384 293 301 384 294 301 minecraft:stripped_oak_log
fill 384 293 303 384 294 303 minecraft:stripped_oak_log
fill 384 293 305 384 294 305 minecraft:stripped_oak_log
setblock 385 293 277 minecraft:stripped_oak_log
fill 385 293 278 385 296 278 minecraft:red_terracotta
fill 385 293 315 386 293 315 minecraft:red_terracotta
setblock 386 293 276 minecraft:stripped_oak_log
fill 386 293 277 389 293 277 minecraft:red_terracotta
setblock 386 293 285 minecraft:light[level=12]
setblock 386 293 292 minecraft:light[level=12]
setblock 386 293 299 minecraft:light[level=12]
setblock 386 293 306 minecraft:light[level=12]
setblock 386 293 313 minecraft:light[level=12]
setblock 386 293 316 minecraft:stripped_oak_log
fill 387 293 276 390 293 276 minecraft:red_terracotta
fill 387 293 315 388 293 315 minecraft:stripped_oak_log
fill 387 293 316 387 296 316 minecraft:red_terracotta
fill 388 293 307 388 294 307 minecraft:stripped_oak_log
fill 388 293 309 388 294 309 minecraft:stripped_oak_log
fill 388 293 311 388 294 311 minecraft:stripped_oak_log
fill 388 293 313 388 294 313 minecraft:stripped_oak_log
setblock 389 293 278 minecraft:stripped_oak_log
fill 389 293 306 389 294 306 minecraft:stripped_oak_log
fill 389 293 308 389 294 308 minecraft:stripped_oak_log
fill 389 293 310 389 294 310 minecraft:stripped_oak_log
fill 389 293 312 389 294 312 minecraft:stripped_oak_log
fill 389 293 314 389 294 314 minecraft:stripped_oak_log
fill 389 293 316 389 294 316 minecraft:red_terracotta
setblock 390 293 277 minecraft:stripped_oak_log
fill 390 293 307 390 294 307 minecraft:stripped_oak_log
fill 390 293 309 390 294 309 minecraft:stripped_oak_log
fill 390 293 311 390 294 311 minecraft:stripped_oak_log
fill 390 293 313 390 294 313 minecraft:stripped_oak_log
fill 390 293 315 390 294 315 minecraft:stripped_oak_log
setblock 391 293 276 minecraft:stripped_oak_log
setblock 391 293 277 minecraft:red_terracotta
fill 391 293 306 391 294 306 minecraft:stripped_oak_log
fill 391 293 308 391 294 308 minecraft:stripped_oak_log
fill 391 293 310 391 294 310 minecraft:stripped_oak_log
fill 391 293 312 391 294 312 minecraft:stripped_oak_log
fill 391 293 314 391 294 314 minecraft:stripped_oak_log
setblock 391 293 316 minecraft:stripped_oak_log
fill 392 293 276 392 295 276 minecraft:red_terracotta
fill 392 293 307 392 294 307 minecraft:stripped_oak_log
fill 392 293 309 392 294 309 minecraft:stripped_oak_log
fill 392 293 311 392 294 311 minecraft:stripped_oak_log
fill 392 293 313 392 294 313 minecraft:stripped_oak_log
fill 392 293 315 392 294 315 minecraft:stripped_oak_log
fill 392 293 316 392 296 316 minecraft:red_terracotta
setblock 393 293 278 minecraft:light[level=12]
setblock 393 293 285 minecraft:light[level=12]
setblock 393 293 292 minecraft:light[level=12]
setblock 393 293 299 minecraft:light[level=12]
fill 393 293 306 393 294 306 minecraft:stripped_oak_log
fill 393 293 308 393 294 308 minecraft:stripped_oak_log
fill 393 293 310 393 294 310 minecraft:stripped_oak_log
fill 393 293 312 393 294 312 minecraft:stripped_oak_log
fill 393 293 314 393 294 314 minecraft:stripped_oak_log
fill 393 293 316 393 294 316 minecraft:stripped_oak_log
fill 394 293 307 394 294 307 minecraft:stripped_oak_log
fill 394 293 309 394 294 309 minecraft:stripped_oak_log
fill 394 293 311 394 294 311 minecraft:stripped_oak_log
fill 394 293 313 394 294 313 minecraft:stripped_oak_log
fill 394 293 315 394 294 315 minecraft:stripped_oak_log
fill 395 293 306 395 294 306 minecraft:stripped_oak_log
fill 395 293 308 395 294 308 minecraft:stripped_oak_log
fill 395 293 310 395 294 310 minecraft:stripped_oak_log
fill 395 293 312 395 294 312 minecraft:stripped_oak_log
fill 395 293 314 395 294 314 minecraft:stripped_oak_log
fill 395 293 316 395 294 316 minecraft:stripped_oak_log
fill 396 293 307 396 294 307 minecraft:stripped_oak_log
fill 396 293 309 396 294 309 minecraft:stripped_oak_log
fill 396 293 311 396 294 311 minecraft:stripped_oak_log
fill 396 293 313 396 294 313 minecraft:stripped_oak_log
fill 396 293 315 396 294 315 minecraft:stripped_oak_log
fill 398 293 316 400 293 316 minecraft:red_terracotta
setblock 400 293 278 minecraft:light[level=12]
setblock 400 293 285 minecraft:light[level=12]
setblock 400 293 292 minecraft:light[level=12]
setblock 400 293 299 minecraft:light[level=12]
setblock 400 293 306 minecraft:light[level=12]
setblock 400 293 313 minecraft:light[level=12]
setblock 401 293 276 minecraft:stripped_oak_log
setblock 401 293 316 minecraft:stripped_oak_log
schedule function dropper:buildpart/68_11 1t
