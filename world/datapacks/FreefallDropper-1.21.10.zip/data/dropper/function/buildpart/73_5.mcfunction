fill 71 283 327 83 284 328 minecraft:stripped_dark_oak_log
fill 71 283 340 71 285 340 minecraft:red_concrete
fill 71 283 341 76 283 341 minecraft:deepslate_tiles
fill 71 283 345 76 283 345 minecraft:deepslate_tiles
fill 71 283 346 71 285 346 minecraft:red_concrete
fill 72 283 339 72 285 339 minecraft:red_concrete
fill 72 283 340 76 283 340 minecraft:deepslate_tiles
fill 72 283 346 76 283 346 minecraft:deepslate_tiles
fill 72 283 347 72 285 347 minecraft:red_concrete
setblock 72 283 363 minecraft:stripped_dark_oak_log
fill 73 283 338 73 284 338 minecraft:red_concrete
fill 73 283 339 76 283 339 minecraft:deepslate_tiles
fill 73 283 347 76 283 347 minecraft:deepslate_tiles
fill 73 283 348 73 284 348 minecraft:red_concrete
fill 74 283 337 74 284 337 minecraft:red_concrete
fill 74 283 338 76 283 338 minecraft:deepslate_tiles
fill 74 283 348 76 283 348 minecraft:deepslate_tiles
fill 74 283 349 74 284 349 minecraft:red_concrete
setblock 75 283 336 minecraft:red_concrete
fill 75 283 337 76 283 337 minecraft:deepslate_tiles
fill 75 283 349 76 283 349 minecraft:deepslate_tiles
setblock 75 283 350 minecraft:red_concrete
setblock 76 283 335 minecraft:red_concrete
setblock 76 283 336 minecraft:deepslate_tiles
setblock 76 283 350 minecraft:deepslate_tiles
setblock 76 283 351 minecraft:red_concrete
fill 76 283 357 84 300 363 minecraft:stripped_dark_oak_log
fill 78 283 343 88 285 349 minecraft:stripped_dark_oak_log
fill 85 283 323 85 300 323 minecraft:stripped_dark_oak_log
fill 85 283 360 87 284 360 minecraft:iron_bars
setblock 86 283 363 minecraft:stripped_dark_oak_log
setblock 88 283 324 minecraft:stripped_dark_oak_log
fill 88 283 327 88 300 327 minecraft:stripped_dark_oak_log
setblock 88 283 331 minecraft:stripped_dark_oak_log
fill 88 283 334 88 300 334 minecraft:stripped_dark_oak_log
setblock 88 283 338 minecraft:stripped_dark_oak_log
fill 88 283 341 88 300 341 minecraft:stripped_dark_oak_log
setblock 88 283 352 minecraft:stripped_dark_oak_log
fill 88 283 355 88 300 355 minecraft:stripped_dark_oak_log
setblock 88 283 359 minecraft:stripped_dark_oak_log
fill 88 283 362 88 300 362 minecraft:stripped_dark_oak_log
fill 47 284 325 47 308 334 minecraft:dark_oak_planks
setblock 47 284 335 minecraft:red_concrete
fill 47 284 336 47 308 336 minecraft:dark_oak_planks
setblock 48 284 325 minecraft:stripped_dark_oak_log
setblock 48 284 332 minecraft:stripped_dark_oak_log
setblock 48 284 339 minecraft:stripped_dark_oak_log
setblock 48 284 346 minecraft:stripped_dark_oak_log
setblock 48 284 353 minecraft:stripped_dark_oak_log
setblock 48 284 360 minecraft:stripped_dark_oak_log
setblock 52 284 363 minecraft:stripped_dark_oak_log
setblock 53 284 323 minecraft:stripped_dark_oak_log
fill 58 284 322 58 285 322 minecraft:red_concrete
setblock 59 284 363 minecraft:stripped_dark_oak_log
setblock 60 284 323 minecraft:stripped_dark_oak_log
fill 69 284 343 74 284 343 minecraft:deepslate_tiles
fill 70 284 342 74 284 342 minecraft:deepslate_tiles
fill 70 284 344 74 284 344 minecraft:deepslate_tiles
fill 71 284 341 74 284 341 minecraft:deepslate_tiles
fill 71 284 345 74 284 345 minecraft:deepslate_tiles
fill 72 284 340 74 284 340 minecraft:deepslate_tiles
fill 72 284 346 74 284 346 minecraft:deepslate_tiles
fill 73 284 339 74 284 339 minecraft:deepslate_tiles
fill 73 284 347 74 284 347 minecraft:deepslate_tiles
setblock 73 284 363 minecraft:stripped_dark_oak_log
setblock 74 284 338 minecraft:deepslate_tiles
setblock 74 284 348 minecraft:deepslate_tiles
setblock 87 284 350 minecraft:red_concrete
setblock 87 284 363 minecraft:stripped_dark_oak_log
setblock 88 284 323 minecraft:stripped_dark_oak_log
setblock 88 284 330 minecraft:stripped_dark_oak_log
setblock 88 284 337 minecraft:stripped_dark_oak_log
setblock 88 284 351 minecraft:stripped_dark_oak_log
setblock 88 284 358 minecraft:stripped_dark_oak_log
fill 47 285 335 47 294 335 minecraft:dark_oak_planks
setblock 48 285 326 minecraft:stripped_dark_oak_log
setblock 48 285 333 minecraft:stripped_dark_oak_log
setblock 48 285 340 minecraft:stripped_dark_oak_log
setblock 48 285 347 minecraft:stripped_dark_oak_log
setblock 48 285 354 minecraft:stripped_dark_oak_log
setblock 48 285 361 minecraft:stripped_dark_oak_log
setblock 52 285 323 minecraft:stripped_dark_oak_log
setblock 53 285 363 minecraft:stripped_dark_oak_log
setblock 59 285 323 minecraft:stripped_dark_oak_log
setblock 60 285 363 minecraft:stripped_dark_oak_log
fill 69 285 343 72 285 343 minecraft:deepslate_tiles
fill 70 285 342 72 285 342 minecraft:deepslate_tiles
fill 70 285 344 72 285 344 minecraft:deepslate_tiles
fill 71 285 327 73 285 328 minecraft:stripped_dark_oak_log
fill 71 285 341 72 285 341 minecraft:deepslate_tiles
fill 71 285 345 72 285 345 minecraft:deepslate_tiles
fill 72 285 329 74 288 329 minecraft:cherry_leaves[persistent=true]
setblock 72 285 340 minecraft:deepslate_tiles
setblock 72 285 346 minecraft:deepslate_tiles
fill 73 285 330 74 286 331 minecraft:cherry_leaves[persistent=true]
fill 74 285 327 83 285 327 minecraft:stripped_dark_oak_log
fill 74 285 328 75 285 328 minecraft:cherry_leaves[persistent=true]
setblock 74 285 363 minecraft:stripped_dark_oak_log
fill 76 285 328 83 285 328 minecraft:stripped_dark_oak_log
setblock 87 285 323 minecraft:stripped_dark_oak_log
fill 87 285 350 87 286 350 minecraft:shroomlight
setblock 88 285 329 minecraft:stripped_dark_oak_log
setblock 88 285 336 minecraft:stripped_dark_oak_log
setblock 88 285 350 minecraft:stripped_dark_oak_log
setblock 88 285 357 minecraft:stripped_dark_oak_log
setblock 88 285 363 minecraft:stripped_dark_oak_log
setblock 48 286 327 minecraft:stripped_dark_oak_log
setblock 48 286 334 minecraft:stripped_dark_oak_log
setblock 48 286 341 minecraft:stripped_dark_oak_log
setblock 48 286 348 minecraft:stripped_dark_oak_log
setblock 48 286 355 minecraft:stripped_dark_oak_log
setblock 48 286 362 minecraft:stripped_dark_oak_log
setblock 50 286 325 minecraft:light[level=12]
setblock 50 286 332 minecraft:light[level=12]
setblock 50 286 339 minecraft:light[level=12]
setblock 50 286 346 minecraft:light[level=12]
setblock 50 286 353 minecraft:light[level=12]
setblock 50 286 360 minecraft:light[level=12]
setblock 51 286 323 minecraft:stripped_dark_oak_log
setblock 54 286 363 minecraft:stripped_dark_oak_log
setblock 57 286 325 minecraft:light[level=12]
setblock 57 286 332 minecraft:light[level=12]
setblock 57 286 339 minecraft:light[level=12]
setblock 57 286 346 minecraft:light[level=12]
setblock 57 286 353 minecraft:light[level=12]
setblock 57 286 360 minecraft:light[level=12]
fill 58 286 322 58 308 322 minecraft:dark_oak_planks
setblock 58 286 323 minecraft:stripped_dark_oak_log
fill 61 286 363 63 286 363 minecraft:stripped_dark_oak_log
setblock 63 286 354 minecraft:shroomlight
fill 63 286 355 63 300 355 minecraft:stripped_dark_oak_log
setblock 63 286 356 minecraft:shroomlight
fill 63 286 357 63 300 357 minecraft:stripped_dark_oak_log
setblock 63 286 358 minecraft:shroomlight
fill 63 286 359 63 300 359 minecraft:stripped_dark_oak_log
setblock 63 286 360 minecraft:shroomlight
fill 63 286 361 63 300 361 minecraft:stripped_dark_oak_log
setblock 63 286 362 minecraft:shroomlight
fill 64 286 323 65 300 323 minecraft:stripped_dark_oak_log
setblock 64 286 325 minecraft:light[level=12]
setblock 64 286 332 minecraft:light[level=12]
setblock 64 286 339 minecraft:light[level=12]
setblock 64 286 346 minecraft:light[level=12]
setblock 64 286 353 minecraft:light[level=12]
fill 64 286 354 64 300 354 minecraft:stripped_dark_oak_log
setblock 64 286 355 minecraft:shroomlight
fill 64 286 356 64 300 356 minecraft:stripped_dark_oak_log
setblock 64 286 357 minecraft:shroomlight
fill 64 286 358 64 300 358 minecraft:stripped_dark_oak_log
setblock 64 286 359 minecraft:shroomlight
fill 64 286 360 64 300 360 minecraft:stripped_dark_oak_log
setblock 64 286 361 minecraft:shroomlight
fill 64 286 362 64 300 362 minecraft:stripped_dark_oak_log
setblock 64 286 363 minecraft:shroomlight
setblock 65 286 324 minecraft:shroomlight
fill 65 286 325 65 300 325 minecraft:stripped_dark_oak_log
setblock 65 286 326 minecraft:shroomlight
setblock 65 286 354 minecraft:shroomlight
fill 65 286 355 65 300 355 minecraft:stripped_dark_oak_log
setblock 65 286 356 minecraft:shroomlight
fill 65 286 357 65 300 357 minecraft:stripped_dark_oak_log
setblock 65 286 358 minecraft:shroomlight
fill 65 286 359 65 300 359 minecraft:stripped_dark_oak_log
setblock 65 286 360 minecraft:shroomlight
fill 65 286 361 65 300 361 minecraft:stripped_dark_oak_log
setblock 65 286 362 minecraft:shroomlight
fill 65 286 363 65 300 363 minecraft:stripped_dark_oak_log
setblock 66 286 323 minecraft:shroomlight
fill 66 286 324 66 300 324 minecraft:stripped_dark_oak_log
setblock 66 286 325 minecraft:shroomlight
fill 66 286 326 66 300 326 minecraft:stripped_dark_oak_log
fill 66 286 354 66 300 354 minecraft:stripped_dark_oak_log
setblock 66 286 355 minecraft:shroomlight
fill 66 286 356 66 300 356 minecraft:stripped_dark_oak_log
setblock 66 286 357 minecraft:shroomlight
fill 66 286 358 66 300 358 minecraft:stripped_dark_oak_log
setblock 66 286 359 minecraft:shroomlight
fill 66 286 360 66 300 360 minecraft:stripped_dark_oak_log
setblock 66 286 361 minecraft:shroomlight
fill 66 286 362 66 300 362 minecraft:stripped_dark_oak_log
setblock 66 286 363 minecraft:shroomlight
fill 67 286 323 67 300 323 minecraft:stripped_dark_oak_log
setblock 67 286 324 minecraft:shroomlight
fill 67 286 325 67 300 325 minecraft:stripped_dark_oak_log
setblock 67 286 326 minecraft:shroomlight
setblock 67 286 354 minecraft:shroomlight
fill 67 286 355 67 300 355 minecraft:stripped_dark_oak_log
setblock 67 286 356 minecraft:shroomlight
fill 67 286 357 67 300 357 minecraft:stripped_dark_oak_log
setblock 67 286 358 minecraft:shroomlight
fill 67 286 359 67 300 359 minecraft:stripped_dark_oak_log
setblock 67 286 360 minecraft:shroomlight
fill 67 286 361 67 300 361 minecraft:stripped_dark_oak_log
setblock 67 286 362 minecraft:shroomlight
fill 67 286 363 67 300 363 minecraft:stripped_dark_oak_log
setblock 68 286 323 minecraft:shroomlight
fill 68 286 324 68 300 324 minecraft:stripped_dark_oak_log
setblock 68 286 325 minecraft:shroomlight
fill 68 286 326 68 300 326 minecraft:stripped_dark_oak_log
fill 68 286 354 68 300 354 minecraft:stripped_dark_oak_log
setblock 68 286 355 minecraft:shroomlight
fill 68 286 356 68 300 356 minecraft:stripped_dark_oak_log
setblock 68 286 357 minecraft:shroomlight
fill 68 286 358 68 300 358 minecraft:stripped_dark_oak_log
setblock 68 286 359 minecraft:shroomlight
fill 68 286 360 68 300 360 minecraft:stripped_dark_oak_log
setblock 68 286 361 minecraft:shroomlight
fill 68 286 362 68 300 362 minecraft:stripped_dark_oak_log
setblock 68 286 363 minecraft:shroomlight
fill 69 286 323 69 300 323 minecraft:stripped_dark_oak_log
setblock 69 286 324 minecraft:shroomlight
fill 69 286 325 69 300 325 minecraft:stripped_dark_oak_log
setblock 69 286 326 minecraft:shroomlight
setblock 69 286 354 minecraft:shroomlight
fill 69 286 355 69 300 355 minecraft:stripped_dark_oak_log
setblock 69 286 356 minecraft:shroomlight
fill 69 286 357 69 300 357 minecraft:stripped_dark_oak_log
setblock 69 286 358 minecraft:shroomlight
fill 69 286 359 69 300 359 minecraft:stripped_dark_oak_log
setblock 69 286 360 minecraft:shroomlight
fill 69 286 361 69 300 361 minecraft:stripped_dark_oak_log
setblock 69 286 362 minecraft:shroomlight
fill 69 286 363 69 300 363 minecraft:stripped_dark_oak_log
setblock 70 286 323 minecraft:shroomlight
fill 70 286 324 70 300 324 minecraft:stripped_dark_oak_log
setblock 70 286 325 minecraft:shroomlight
fill 70 286 326 70 300 326 minecraft:stripped_dark_oak_log
fill 71 286 323 71 300 323 minecraft:stripped_dark_oak_log
setblock 71 286 324 minecraft:shroomlight
fill 71 286 325 71 300 325 minecraft:stripped_dark_oak_log
setblock 71 286 326 minecraft:shroomlight
fill 71 286 327 71 300 327 minecraft:stripped_dark_oak_log
setblock 71 286 328 minecraft:shroomlight
setblock 71 286 332 minecraft:light[level=12]
setblock 71 286 339 minecraft:light[level=12]
setblock 71 286 346 minecraft:light[level=12]
setblock 71 286 353 minecraft:light[level=12]
setblock 71 286 360 minecraft:light[level=12]
setblock 72 286 323 minecraft:shroomlight
fill 72 286 324 72 300 324 minecraft:stripped_dark_oak_log
setblock 72 286 325 minecraft:shroomlight
fill 72 286 326 72 300 326 minecraft:stripped_dark_oak_log
setblock 72 286 327 minecraft:shroomlight
setblock 72 286 328 minecraft:stripped_dark_oak_log
fill 72 286 330 72 287 331 minecraft:cherry_leaves[persistent=true]
fill 73 286 323 73 300 323 minecraft:stripped_dark_oak_log
setblock 73 286 324 minecraft:shroomlight
fill 73 286 325 73 300 325 minecraft:stripped_dark_oak_log
setblock 73 286 326 minecraft:shroomlight
fill 73 286 327 73 300 327 minecraft:stripped_dark_oak_log
setblock 73 286 328 minecraft:shroomlight
setblock 74 286 323 minecraft:shroomlight
fill 74 286 324 74 300 324 minecraft:stripped_dark_oak_log
setblock 74 286 325 minecraft:shroomlight
fill 74 286 326 74 300 326 minecraft:stripped_dark_oak_log
setblock 74 286 327 minecraft:shroomlight
fill 74 286 328 74 287 328 minecraft:cherry_leaves[persistent=true]
fill 75 286 323 75 300 323 minecraft:stripped_dark_oak_log
setblock 75 286 324 minecraft:shroomlight
fill 75 286 325 75 300 325 minecraft:stripped_dark_oak_log
setblock 75 286 326 minecraft:shroomlight
fill 75 286 327 75 300 327 minecraft:stripped_dark_oak_log
setblock 75 286 328 minecraft:shroomlight
fill 75 286 329 75 288 330 minecraft:cherry_leaves[persistent=true]
setblock 75 286 363 minecraft:stripped_dark_oak_log
setblock 76 286 323 minecraft:shroomlight
fill 76 286 324 76 300 324 minecraft:stripped_dark_oak_log
setblock 76 286 325 minecraft:shroomlight
fill 76 286 326 76 300 326 minecraft:stripped_dark_oak_log
setblock 76 286 327 minecraft:shroomlight
fill 76 286 328 76 300 328 minecraft:stripped_dark_oak_log
fill 77 286 323 77 300 323 minecraft:stripped_dark_oak_log
setblock 77 286 324 minecraft:shroomlight
fill 77 286 325 77 300 325 minecraft:stripped_dark_oak_log
setblock 77 286 326 minecraft:shroomlight
fill 77 286 327 77 300 327 minecraft:stripped_dark_oak_log
setblock 77 286 328 minecraft:shroomlight
setblock 78 286 323 minecraft:shroomlight
fill 78 286 324 78 300 324 minecraft:stripped_dark_oak_log
setblock 78 286 325 minecraft:shroomlight
fill 78 286 326 78 300 326 minecraft:stripped_dark_oak_log
setblock 78 286 327 minecraft:shroomlight
fill 78 286 328 78 300 328 minecraft:stripped_dark_oak_log
setblock 78 286 332 minecraft:light[level=12]
setblock 78 286 339 minecraft:light[level=12]
setblock 78 286 343 minecraft:shroomlight
fill 78 286 344 78 300 344 minecraft:stripped_dark_oak_log
setblock 78 286 345 minecraft:shroomlight
fill 78 286 346 78 300 346 minecraft:stripped_dark_oak_log
setblock 78 286 347 minecraft:shroomlight
fill 78 286 348 78 300 348 minecraft:stripped_dark_oak_log
setblock 78 286 349 minecraft:shroomlight
setblock 78 286 353 minecraft:light[level=12]
fill 79 286 323 79 300 323 minecraft:stripped_dark_oak_log
setblock 79 286 324 minecraft:shroomlight
fill 79 286 325 79 300 325 minecraft:stripped_dark_oak_log
setblock 79 286 326 minecraft:shroomlight
fill 79 286 327 79 300 327 minecraft:stripped_dark_oak_log
setblock 79 286 328 minecraft:shroomlight
fill 79 286 343 79 300 343 minecraft:stripped_dark_oak_log
setblock 79 286 344 minecraft:shroomlight
fill 79 286 345 79 300 345 minecraft:stripped_dark_oak_log
setblock 79 286 346 minecraft:shroomlight
fill 79 286 347 79 300 347 minecraft:stripped_dark_oak_log
setblock 79 286 348 minecraft:shroomlight
fill 79 286 349 79 300 349 minecraft:stripped_dark_oak_log
setblock 80 286 323 minecraft:shroomlight
fill 80 286 324 80 300 324 minecraft:stripped_dark_oak_log
setblock 80 286 325 minecraft:shroomlight
fill 80 286 326 80 300 326 minecraft:stripped_dark_oak_log
setblock 80 286 327 minecraft:shroomlight
fill 80 286 328 80 300 328 minecraft:stripped_dark_oak_log
setblock 80 286 343 minecraft:shroomlight
fill 80 286 344 80 300 344 minecraft:stripped_dark_oak_log
setblock 80 286 345 minecraft:shroomlight
fill 80 286 346 80 300 346 minecraft:stripped_dark_oak_log
setblock 80 286 347 minecraft:shroomlight
fill 80 286 348 80 300 348 minecraft:stripped_dark_oak_log
setblock 80 286 349 minecraft:shroomlight
fill 81 286 323 81 300 323 minecraft:stripped_dark_oak_log
setblock 81 286 324 minecraft:shroomlight
fill 81 286 325 81 300 325 minecraft:stripped_dark_oak_log
setblock 81 286 326 minecraft:shroomlight
fill 81 286 327 81 300 327 minecraft:stripped_dark_oak_log
setblock 81 286 328 minecraft:shroomlight
fill 81 286 343 81 300 343 minecraft:stripped_dark_oak_log
setblock 81 286 344 minecraft:shroomlight
fill 81 286 345 81 300 345 minecraft:stripped_dark_oak_log
setblock 81 286 346 minecraft:shroomlight
fill 81 286 347 81 300 347 minecraft:stripped_dark_oak_log
setblock 81 286 348 minecraft:shroomlight
fill 81 286 349 81 300 349 minecraft:stripped_dark_oak_log
setblock 82 286 323 minecraft:shroomlight
fill 82 286 324 82 300 324 minecraft:stripped_dark_oak_log
setblock 82 286 325 minecraft:shroomlight
fill 82 286 326 82 300 326 minecraft:stripped_dark_oak_log
setblock 82 286 327 minecraft:shroomlight
fill 82 286 328 82 300 328 minecraft:stripped_dark_oak_log
setblock 82 286 343 minecraft:shroomlight
fill 82 286 344 82 300 344 minecraft:stripped_dark_oak_log
setblock 82 286 345 minecraft:shroomlight
fill 82 286 346 82 300 346 minecraft:stripped_dark_oak_log
setblock 82 286 347 minecraft:shroomlight
fill 82 286 348 82 300 348 minecraft:stripped_dark_oak_log
setblock 82 286 349 minecraft:shroomlight
fill 83 286 323 83 300 323 minecraft:stripped_dark_oak_log
setblock 83 286 324 minecraft:shroomlight
fill 83 286 325 83 300 325 minecraft:stripped_dark_oak_log
setblock 83 286 326 minecraft:shroomlight
fill 83 286 327 83 300 327 minecraft:stripped_dark_oak_log
setblock 83 286 328 minecraft:shroomlight
fill 83 286 343 83 300 343 minecraft:stripped_dark_oak_log
setblock 83 286 344 minecraft:shroomlight
fill 83 286 345 83 300 345 minecraft:stripped_dark_oak_log
setblock 83 286 346 minecraft:shroomlight
fill 83 286 347 83 300 347 minecraft:stripped_dark_oak_log
setblock 83 286 348 minecraft:shroomlight
fill 83 286 349 83 300 349 minecraft:stripped_dark_oak_log
setblock 84 286 343 minecraft:shroomlight
fill 84 286 344 84 300 344 minecraft:stripped_dark_oak_log
setblock 84 286 345 minecraft:shroomlight
fill 84 286 346 84 300 346 minecraft:stripped_dark_oak_log
setblock 84 286 347 minecraft:shroomlight
fill 84 286 348 84 300 348 minecraft:stripped_dark_oak_log
setblock 84 286 349 minecraft:shroomlight
setblock 85 286 325 minecraft:light[level=12]
setblock 85 286 332 minecraft:light[level=12]
setblock 85 286 339 minecraft:light[level=12]
fill 85 286 343 85 300 343 minecraft:stripped_dark_oak_log
setblock 85 286 344 minecraft:shroomlight
fill 85 286 345 85 300 345 minecraft:stripped_dark_oak_log
setblock 85 286 346 minecraft:shroomlight
fill 85 286 347 85 300 347 minecraft:stripped_dark_oak_log
setblock 85 286 348 minecraft:shroomlight
fill 85 286 349 85 300 349 minecraft:stripped_dark_oak_log
setblock 85 286 353 minecraft:light[level=12]
setblock 85 286 360 minecraft:light[level=12]
setblock 86 286 323 minecraft:stripped_dark_oak_log
setblock 86 286 343 minecraft:shroomlight
fill 86 286 344 86 300 344 minecraft:stripped_dark_oak_log
setblock 86 286 345 minecraft:shroomlight
fill 86 286 346 86 300 346 minecraft:stripped_dark_oak_log
setblock 86 286 347 minecraft:shroomlight
fill 86 286 348 86 300 348 minecraft:stripped_dark_oak_log
setblock 86 286 349 minecraft:shroomlight
fill 87 286 343 87 300 343 minecraft:stripped_dark_oak_log
setblock 87 286 344 minecraft:shroomlight
fill 87 286 345 87 300 345 minecraft:stripped_dark_oak_log
setblock 87 286 346 minecraft:shroomlight
fill 87 286 347 87 300 347 minecraft:stripped_dark_oak_log
setblock 87 286 348 minecraft:shroomlight
fill 87 286 349 87 300 349 minecraft:stripped_dark_oak_log
setblock 88 286 328 minecraft:stripped_dark_oak_log
setblock 88 286 335 minecraft:stripped_dark_oak_log
setblock 88 286 342 minecraft:stripped_dark_oak_log
setblock 88 286 343 minecraft:shroomlight
fill 88 286 344 88 300 344 minecraft:stripped_dark_oak_log
setblock 88 286 345 minecraft:shroomlight
fill 88 286 346 88 300 346 minecraft:stripped_dark_oak_log
setblock 88 286 347 minecraft:shroomlight
fill 88 286 348 88 300 348 minecraft:stripped_dark_oak_log
setblock 88 286 349 minecraft:shroomlight
setblock 88 286 356 minecraft:stripped_dark_oak_log
setblock 89 286 334 minecraft:red_concrete
fill 57 287 324 63 288 324 minecraft:iron_bars
fill 61 287 364 61 303 364 minecraft:dark_oak_planks
fill 62 287 363 64 288 363 minecraft:stripped_dark_oak_log
setblock 62 287 364 minecraft:red_concrete
fill 63 287 354 63 288 354 minecraft:stripped_dark_oak_log
fill 63 287 356 63 288 356 minecraft:stripped_dark_oak_log
fill 63 287 358 63 288 358 minecraft:stripped_dark_oak_log
fill 63 287 360 63 288 360 minecraft:stripped_dark_oak_log
fill 63 287 362 63 288 362 minecraft:stripped_dark_oak_log
fill 64 287 355 64 288 355 minecraft:stripped_dark_oak_log
fill 64 287 357 64 288 357 minecraft:stripped_dark_oak_log
fill 64 287 359 64 288 359 minecraft:stripped_dark_oak_log
fill 64 287 361 64 288 361 minecraft:stripped_dark_oak_log
fill 65 287 324 65 288 324 minecraft:stripped_dark_oak_log
fill 65 287 326 65 288 326 minecraft:stripped_dark_oak_log
fill 65 287 354 65 288 354 minecraft:stripped_dark_oak_log
fill 65 287 356 65 288 356 minecraft:stripped_dark_oak_log
fill 65 287 358 65 288 358 minecraft:stripped_dark_oak_log
fill 65 287 360 65 288 360 minecraft:stripped_dark_oak_log
fill 65 287 362 65 288 362 minecraft:stripped_dark_oak_log
fill 66 287 323 66 288 323 minecraft:stripped_dark_oak_log
fill 66 287 325 66 288 325 minecraft:stripped_dark_oak_log
fill 66 287 355 66 288 355 minecraft:stripped_dark_oak_log
fill 66 287 357 66 288 357 minecraft:stripped_dark_oak_log
fill 66 287 359 66 288 359 minecraft:stripped_dark_oak_log
fill 66 287 361 66 288 361 minecraft:stripped_dark_oak_log
fill 66 287 363 66 288 363 minecraft:stripped_dark_oak_log
fill 67 287 324 67 288 324 minecraft:stripped_dark_oak_log
fill 67 287 326 67 288 326 minecraft:stripped_dark_oak_log
fill 67 287 354 67 288 354 minecraft:stripped_dark_oak_log
fill 67 287 356 67 288 356 minecraft:stripped_dark_oak_log
fill 67 287 358 67 288 358 minecraft:stripped_dark_oak_log
fill 67 287 360 67 288 360 minecraft:stripped_dark_oak_log
fill 67 287 362 67 288 362 minecraft:stripped_dark_oak_log
fill 68 287 323 68 288 323 minecraft:stripped_dark_oak_log
fill 68 287 325 68 288 325 minecraft:stripped_dark_oak_log
fill 68 287 355 68 288 355 minecraft:stripped_dark_oak_log
fill 68 287 357 68 288 357 minecraft:stripped_dark_oak_log
fill 68 287 359 68 288 359 minecraft:stripped_dark_oak_log
fill 68 287 361 68 288 361 minecraft:stripped_dark_oak_log
fill 68 287 363 68 288 363 minecraft:stripped_dark_oak_log
fill 69 287 324 69 288 324 minecraft:stripped_dark_oak_log
fill 69 287 326 69 288 326 minecraft:stripped_dark_oak_log
fill 69 287 354 69 288 354 minecraft:stripped_dark_oak_log
fill 69 287 356 69 288 356 minecraft:stripped_dark_oak_log
fill 69 287 358 69 288 358 minecraft:stripped_dark_oak_log
fill 69 287 360 69 288 360 minecraft:stripped_dark_oak_log
fill 69 287 362 69 288 362 minecraft:stripped_dark_oak_log
fill 70 287 323 70 288 323 minecraft:stripped_dark_oak_log
fill 70 287 325 70 288 325 minecraft:stripped_dark_oak_log
fill 71 287 324 71 288 324 minecraft:stripped_dark_oak_log
fill 71 287 326 71 288 326 minecraft:stripped_dark_oak_log
fill 71 287 328 71 288 328 minecraft:stripped_dark_oak_log
fill 72 287 323 72 288 323 minecraft:stripped_dark_oak_log
fill 72 287 325 72 288 325 minecraft:stripped_dark_oak_log
fill 72 287 327 72 288 327 minecraft:stripped_dark_oak_log
fill 72 287 328 73 287 328 minecraft:cherry_leaves[persistent=true]
fill 73 287 324 73 288 324 minecraft:stripped_dark_oak_log
fill 73 287 326 73 288 326 minecraft:stripped_dark_oak_log
fill 73 287 330 73 287 331 minecraft:cherry_leaves[persistent=true]
fill 74 287 323 74 288 323 minecraft:stripped_dark_oak_log
fill 74 287 325 74 288 325 minecraft:stripped_dark_oak_log
fill 74 287 327 74 288 327 minecraft:stripped_dark_oak_log
fill 74 287 330 74 288 330 minecraft:cherry_leaves[persistent=true]
fill 75 287 324 75 288 324 minecraft:stripped_dark_oak_log
fill 75 287 326 75 288 326 minecraft:stripped_dark_oak_log
setblock 75 287 328 minecraft:cherry_leaves[persistent=true]
fill 76 287 323 76 288 323 minecraft:stripped_dark_oak_log
fill 76 287 325 76 288 325 minecraft:stripped_dark_oak_log
fill 76 287 327 76 288 327 minecraft:stripped_dark_oak_log
fill 77 287 324 77 288 324 minecraft:stripped_dark_oak_log
fill 77 287 326 77 288 326 minecraft:stripped_dark_oak_log
fill 77 287 328 77 288 328 minecraft:stripped_dark_oak_log
fill 78 287 323 78 288 323 minecraft:stripped_dark_oak_log
fill 78 287 325 78 288 325 minecraft:stripped_dark_oak_log
fill 78 287 327 78 288 327 minecraft:stripped_dark_oak_log
fill 78 287 343 78 288 343 minecraft:stripped_dark_oak_log
fill 78 287 345 78 288 345 minecraft:stripped_dark_oak_log
fill 78 287 347 78 288 347 minecraft:stripped_dark_oak_log
fill 78 287 349 78 288 349 minecraft:stripped_dark_oak_log
fill 79 287 324 79 288 324 minecraft:stripped_dark_oak_log
fill 79 287 326 79 288 326 minecraft:stripped_dark_oak_log
fill 79 287 328 79 288 328 minecraft:stripped_dark_oak_log
fill 79 287 344 79 288 344 minecraft:stripped_dark_oak_log
fill 79 287 346 79 288 346 minecraft:stripped_dark_oak_log
fill 79 287 348 79 288 348 minecraft:stripped_dark_oak_log
fill 80 287 323 80 288 323 minecraft:stripped_dark_oak_log
fill 80 287 325 80 288 325 minecraft:stripped_dark_oak_log
fill 80 287 327 80 288 327 minecraft:stripped_dark_oak_log
fill 80 287 343 80 288 343 minecraft:stripped_dark_oak_log
fill 80 287 345 80 288 345 minecraft:stripped_dark_oak_log
fill 80 287 347 80 288 347 minecraft:stripped_dark_oak_log
fill 80 287 349 80 288 349 minecraft:stripped_dark_oak_log
fill 81 287 324 81 288 324 minecraft:stripped_dark_oak_log
fill 81 287 326 81 288 326 minecraft:stripped_dark_oak_log
fill 81 287 328 81 288 328 minecraft:stripped_dark_oak_log
fill 81 287 344 81 288 344 minecraft:stripped_dark_oak_log
fill 81 287 346 81 288 346 minecraft:stripped_dark_oak_log
fill 81 287 348 81 288 348 minecraft:stripped_dark_oak_log
fill 82 287 323 82 288 323 minecraft:stripped_dark_oak_log
fill 82 287 325 82 288 325 minecraft:stripped_dark_oak_log
fill 82 287 327 82 288 327 minecraft:stripped_dark_oak_log
fill 82 287 343 82 288 343 minecraft:stripped_dark_oak_log
fill 82 287 345 82 288 345 minecraft:stripped_dark_oak_log
fill 82 287 347 82 288 347 minecraft:stripped_dark_oak_log
fill 82 287 349 82 288 349 minecraft:stripped_dark_oak_log
fill 83 287 324 83 288 324 minecraft:stripped_dark_oak_log
fill 83 287 326 83 288 326 minecraft:stripped_dark_oak_log
fill 83 287 328 83 288 328 minecraft:stripped_dark_oak_log
fill 83 287 344 83 288 344 minecraft:stripped_dark_oak_log
fill 83 287 346 83 288 346 minecraft:stripped_dark_oak_log
fill 83 287 348 83 288 348 minecraft:stripped_dark_oak_log
fill 84 287 343 84 288 343 minecraft:stripped_dark_oak_log
fill 84 287 345 84 288 345 minecraft:stripped_dark_oak_log
fill 84 287 347 84 288 347 minecraft:stripped_dark_oak_log
fill 84 287 349 84 288 349 minecraft:stripped_dark_oak_log
fill 85 287 344 85 288 344 minecraft:stripped_dark_oak_log
fill 85 287 346 85 288 346 minecraft:stripped_dark_oak_log
fill 85 287 348 85 288 348 minecraft:stripped_dark_oak_log
fill 86 287 343 86 288 343 minecraft:stripped_dark_oak_log
fill 86 287 345 86 288 345 minecraft:stripped_dark_oak_log
fill 86 287 347 86 288 347 minecraft:stripped_dark_oak_log
fill 86 287 349 86 288 349 minecraft:stripped_dark_oak_log
fill 87 287 344 87 288 344 minecraft:stripped_dark_oak_log
fill 87 287 346 87 288 346 minecraft:stripped_dark_oak_log
fill 87 287 348 87 288 348 minecraft:stripped_dark_oak_log
setblock 87 287 350 minecraft:red_concrete
fill 88 287 343 88 288 343 minecraft:stripped_dark_oak_log
fill 88 287 345 88 288 345 minecraft:stripped_dark_oak_log
fill 88 287 347 88 288 347 minecraft:stripped_dark_oak_log
fill 88 287 349 88 288 349 minecraft:stripped_dark_oak_log
fill 89 287 334 89 290 334 minecraft:dark_oak_planks
setblock 47 288 338 minecraft:red_concrete
fill 47 288 339 47 308 341 minecraft:dark_oak_planks
setblock 47 288 359 minecraft:red_concrete
setblock 48 288 329 minecraft:stripped_dark_oak_log
setblock 48 288 336 minecraft:stripped_dark_oak_log
setblock 48 288 343 minecraft:stripped_dark_oak_log
setblock 48 288 350 minecraft:stripped_dark_oak_log
setblock 48 288 357 minecraft:stripped_dark_oak_log
setblock 49 288 323 minecraft:stripped_dark_oak_log
setblock 49 288 363 minecraft:stripped_dark_oak_log
setblock 50 288 325 minecraft:light[level=15]
setblock 50 288 333 minecraft:light[level=15]
setblock 50 288 341 minecraft:light[level=15]
setblock 50 288 349 minecraft:light[level=15]
setblock 50 288 357 minecraft:light[level=15]
setblock 56 288 323 minecraft:stripped_dark_oak_log
setblock 56 288 363 minecraft:stripped_dark_oak_log
setblock 58 288 325 minecraft:light[level=15]
setblock 58 288 333 minecraft:light[level=15]
setblock 58 288 341 minecraft:light[level=15]
setblock 58 288 349 minecraft:light[level=15]
setblock 58 288 357 minecraft:light[level=15]
fill 59 288 323 59 289 323 minecraft:iron_bars
fill 59 288 325 59 289 325 minecraft:iron_bars
fill 62 288 364 62 308 364 minecraft:dark_oak_planks
setblock 63 288 323 minecraft:stripped_dark_oak_log
setblock 66 288 333 minecraft:light[level=15]
setblock 66 288 341 minecraft:light[level=15]
setblock 66 288 349 minecraft:light[level=15]
setblock 70 288 363 minecraft:stripped_dark_oak_log
fill 72 288 328 72 300 328 minecraft:stripped_dark_oak_log
fill 72 288 330 73 288 330 minecraft:cherry_leaves[persistent=true]
setblock 73 288 328 minecraft:cherry_leaves[persistent=true]
fill 74 288 328 75 288 328 minecraft:stripped_dark_oak_log
setblock 74 288 333 minecraft:light[level=15]
setblock 74 288 341 minecraft:light[level=15]
setblock 74 288 349 minecraft:light[level=15]
setblock 74 288 357 minecraft:light[level=15]
setblock 82 288 333 minecraft:light[level=15]
setblock 82 288 341 minecraft:light[level=15]
setblock 84 288 323 minecraft:stripped_dark_oak_log
setblock 88 288 326 minecraft:stripped_dark_oak_log
setblock 88 288 333 minecraft:stripped_dark_oak_log
setblock 88 288 340 minecraft:stripped_dark_oak_log
setblock 88 288 354 minecraft:stripped_dark_oak_log
setblock 88 288 361 minecraft:stripped_dark_oak_log
fill 47 289 338 47 308 338 minecraft:dark_oak_planks
fill 47 289 359 47 308 359 minecraft:dark_oak_planks
fill 48 289 323 48 290 323 minecraft:stripped_dark_oak_log
fill 48 289 330 48 290 330 minecraft:stripped_dark_oak_log
fill 48 289 337 48 290 337 minecraft:stripped_dark_oak_log
fill 48 289 344 48 290 344 minecraft:stripped_dark_oak_log
fill 48 289 351 48 290 351 minecraft:stripped_dark_oak_log
fill 48 289 358 48 290 358 minecraft:stripped_dark_oak_log
fill 50 289 363 50 290 363 minecraft:stripped_dark_oak_log
fill 55 289 323 55 290 323 minecraft:stripped_dark_oak_log
fill 57 289 363 57 290 363 minecraft:stripped_dark_oak_log
setblock 59 289 324 minecraft:iron_bars
fill 62 289 323 62 290 323 minecraft:stripped_dark_oak_log
fill 62 289 363 63 300 363 minecraft:stripped_dark_oak_log
setblock 63 289 354 minecraft:shroomlight
setblock 63 289 356 minecraft:shroomlight
setblock 63 289 358 minecraft:shroomlight
setblock 63 289 360 minecraft:shroomlight
setblock 63 289 362 minecraft:shroomlight
setblock 64 289 355 minecraft:shroomlight
setblock 64 289 357 minecraft:shroomlight
setblock 64 289 359 minecraft:shroomlight
setblock 64 289 361 minecraft:shroomlight
setblock 64 289 363 minecraft:shroomlight
setblock 65 289 324 minecraft:shroomlight
setblock 65 289 326 minecraft:shroomlight
setblock 65 289 354 minecraft:shroomlight
setblock 65 289 356 minecraft:shroomlight
setblock 65 289 358 minecraft:shroomlight
setblock 65 289 360 minecraft:shroomlight
setblock 65 289 362 minecraft:shroomlight
setblock 66 289 323 minecraft:shroomlight
setblock 66 289 325 minecraft:shroomlight
setblock 66 289 355 minecraft:shroomlight
setblock 66 289 357 minecraft:shroomlight
setblock 66 289 359 minecraft:shroomlight
setblock 66 289 361 minecraft:shroomlight
setblock 66 289 363 minecraft:shroomlight
setblock 67 289 324 minecraft:shroomlight
setblock 67 289 326 minecraft:shroomlight
setblock 67 289 354 minecraft:shroomlight
setblock 67 289 356 minecraft:shroomlight
setblock 67 289 358 minecraft:shroomlight
setblock 67 289 360 minecraft:shroomlight
setblock 67 289 362 minecraft:shroomlight
setblock 68 289 323 minecraft:shroomlight
setblock 68 289 325 minecraft:shroomlight
setblock 68 289 355 minecraft:shroomlight
setblock 68 289 357 minecraft:shroomlight
setblock 68 289 359 minecraft:shroomlight
setblock 68 289 361 minecraft:shroomlight
setblock 68 289 363 minecraft:shroomlight
setblock 69 289 324 minecraft:shroomlight
setblock 69 289 326 minecraft:shroomlight
setblock 69 289 354 minecraft:shroomlight
setblock 69 289 356 minecraft:shroomlight
setblock 69 289 358 minecraft:shroomlight
setblock 69 289 360 minecraft:shroomlight
setblock 69 289 362 minecraft:shroomlight
setblock 70 289 323 minecraft:shroomlight
setblock 70 289 325 minecraft:shroomlight
setblock 71 289 324 minecraft:shroomlight
setblock 71 289 326 minecraft:shroomlight
setblock 71 289 328 minecraft:shroomlight
fill 71 289 363 71 290 363 minecraft:stripped_dark_oak_log
setblock 72 289 323 minecraft:shroomlight
setblock 72 289 325 minecraft:shroomlight
setblock 72 289 327 minecraft:shroomlight
setblock 73 289 324 minecraft:shroomlight
setblock 73 289 326 minecraft:shroomlight
setblock 73 289 328 minecraft:shroomlight
setblock 73 289 329 minecraft:cherry_leaves[persistent=true]
setblock 74 289 323 minecraft:shroomlight
setblock 74 289 325 minecraft:shroomlight
setblock 74 289 327 minecraft:shroomlight
fill 74 289 328 74 300 328 minecraft:stripped_dark_oak_log
setblock 75 289 324 minecraft:shroomlight
setblock 75 289 326 minecraft:shroomlight
setblock 75 289 328 minecraft:shroomlight
setblock 76 289 323 minecraft:shroomlight
setblock 76 289 325 minecraft:shroomlight
setblock 76 289 327 minecraft:shroomlight
setblock 77 289 324 minecraft:shroomlight
setblock 77 289 326 minecraft:shroomlight
setblock 77 289 328 minecraft:shroomlight
setblock 78 289 323 minecraft:shroomlight
setblock 78 289 325 minecraft:shroomlight
setblock 78 289 327 minecraft:shroomlight
setblock 78 289 343 minecraft:shroomlight
setblock 78 289 345 minecraft:shroomlight
setblock 78 289 347 minecraft:shroomlight
setblock 78 289 349 minecraft:shroomlight
setblock 79 289 324 minecraft:shroomlight
setblock 79 289 326 minecraft:shroomlight
setblock 79 289 328 minecraft:shroomlight
setblock 79 289 344 minecraft:shroomlight
setblock 79 289 346 minecraft:shroomlight
setblock 79 289 348 minecraft:shroomlight
setblock 80 289 323 minecraft:shroomlight
setblock 80 289 325 minecraft:shroomlight
setblock 80 289 327 minecraft:shroomlight
setblock 80 289 343 minecraft:shroomlight
setblock 80 289 345 minecraft:shroomlight
setblock 80 289 347 minecraft:shroomlight
setblock 80 289 349 minecraft:shroomlight
setblock 81 289 324 minecraft:shroomlight
setblock 81 289 326 minecraft:shroomlight
setblock 81 289 328 minecraft:shroomlight
setblock 81 289 344 minecraft:shroomlight
setblock 81 289 346 minecraft:shroomlight
setblock 81 289 348 minecraft:shroomlight
setblock 82 289 323 minecraft:shroomlight
setblock 82 289 325 minecraft:shroomlight
setblock 82 289 327 minecraft:shroomlight
setblock 82 289 343 minecraft:shroomlight
setblock 82 289 345 minecraft:shroomlight
setblock 82 289 347 minecraft:shroomlight
setblock 82 289 349 minecraft:shroomlight
setblock 83 289 324 minecraft:shroomlight
setblock 83 289 326 minecraft:shroomlight
setblock 83 289 328 minecraft:shroomlight
setblock 83 289 344 minecraft:shroomlight
setblock 83 289 346 minecraft:shroomlight
setblock 83 289 348 minecraft:shroomlight
setblock 84 289 343 minecraft:shroomlight
setblock 84 289 345 minecraft:shroomlight
setblock 84 289 347 minecraft:shroomlight
setblock 84 289 349 minecraft:shroomlight
setblock 85 289 344 minecraft:shroomlight
setblock 85 289 346 minecraft:shroomlight
setblock 85 289 348 minecraft:shroomlight
fill 85 289 363 85 290 363 minecraft:stripped_dark_oak_log
setblock 86 289 343 minecraft:shroomlight
setblock 86 289 345 minecraft:shroomlight
setblock 86 289 347 minecraft:shroomlight
setblock 86 289 349 minecraft:shroomlight
setblock 87 289 344 minecraft:shroomlight
setblock 87 289 346 minecraft:shroomlight
setblock 87 289 348 minecraft:shroomlight
fill 88 289 325 88 290 325 minecraft:stripped_dark_oak_log
fill 88 289 332 88 290 332 minecraft:stripped_dark_oak_log
fill 88 289 339 88 290 339 minecraft:stripped_dark_oak_log
setblock 88 289 343 minecraft:shroomlight
setblock 88 289 345 minecraft:shroomlight
setblock 88 289 347 minecraft:shroomlight
setblock 88 289 349 minecraft:shroomlight
fill 88 289 353 88 290 353 minecraft:stripped_dark_oak_log
fill 88 289 360 88 290 360 minecraft:stripped_dark_oak_log
fill 48 290 324 48 290 327 minecraft:stripped_dark_oak_log
setblock 48 290 329 minecraft:stripped_dark_oak_log
fill 48 290 331 48 290 334 minecraft:stripped_dark_oak_log
setblock 48 290 336 minecraft:stripped_dark_oak_log
fill 48 290 338 48 290 341 minecraft:stripped_dark_oak_log
setblock 48 290 343 minecraft:stripped_dark_oak_log
fill 48 290 345 48 290 348 minecraft:stripped_dark_oak_log
setblock 48 290 350 minecraft:stripped_dark_oak_log
fill 48 290 352 48 290 355 minecraft:stripped_dark_oak_log
setblock 48 290 357 minecraft:stripped_dark_oak_log
fill 48 290 359 48 290 362 minecraft:stripped_dark_oak_log
setblock 49 290 323 minecraft:stripped_dark_oak_log
setblock 49 290 363 minecraft:stripped_dark_oak_log
fill 51 290 323 54 290 323 minecraft:stripped_dark_oak_log
fill 51 290 363 54 290 363 minecraft:stripped_dark_oak_log
setblock 56 290 323 minecraft:stripped_dark_oak_log
setblock 56 290 363 minecraft:stripped_dark_oak_log
fill 58 290 323 61 290 323 minecraft:stripped_dark_oak_log
fill 58 290 363 61 290 363 minecraft:stripped_dark_oak_log
setblock 59 290 322 minecraft:red_concrete
setblock 63 290 323 minecraft:stripped_dark_oak_log
fill 63 290 354 63 291 354 minecraft:stripped_dark_oak_log
fill 63 290 356 63 291 356 minecraft:stripped_dark_oak_log
fill 63 290 358 63 291 358 minecraft:stripped_dark_oak_log
fill 63 290 360 63 291 360 minecraft:stripped_dark_oak_log
fill 63 290 362 63 291 362 minecraft:stripped_dark_oak_log
setblock 64 290 322 minecraft:red_concrete
fill 64 290 355 64 291 355 minecraft:stripped_dark_oak_log
fill 64 290 357 64 291 357 minecraft:stripped_dark_oak_log
fill 64 290 359 64 291 359 minecraft:stripped_dark_oak_log
fill 64 290 361 64 291 361 minecraft:stripped_dark_oak_log
fill 64 290 363 64 291 363 minecraft:stripped_dark_oak_log
fill 65 290 324 65 291 324 minecraft:stripped_dark_oak_log
fill 65 290 326 65 291 326 minecraft:stripped_dark_oak_log
fill 65 290 354 65 291 354 minecraft:stripped_dark_oak_log
fill 65 290 356 65 291 356 minecraft:stripped_dark_oak_log
fill 65 290 358 65 291 358 minecraft:stripped_dark_oak_log
fill 65 290 360 65 291 360 minecraft:stripped_dark_oak_log
fill 65 290 362 65 291 362 minecraft:stripped_dark_oak_log
fill 66 290 323 66 291 323 minecraft:stripped_dark_oak_log
fill 66 290 325 66 291 325 minecraft:stripped_dark_oak_log
fill 66 290 355 66 291 355 minecraft:stripped_dark_oak_log
fill 66 290 357 66 291 357 minecraft:stripped_dark_oak_log
fill 66 290 359 66 291 359 minecraft:stripped_dark_oak_log
fill 66 290 361 66 291 361 minecraft:stripped_dark_oak_log
fill 66 290 363 66 291 363 minecraft:stripped_dark_oak_log
fill 67 290 324 67 291 324 minecraft:stripped_dark_oak_log
fill 67 290 326 67 291 326 minecraft:stripped_dark_oak_log
fill 67 290 354 67 291 354 minecraft:stripped_dark_oak_log
fill 67 290 356 67 291 356 minecraft:stripped_dark_oak_log
fill 67 290 358 67 291 358 minecraft:stripped_dark_oak_log
fill 67 290 360 67 291 360 minecraft:stripped_dark_oak_log
fill 67 290 362 67 291 362 minecraft:stripped_dark_oak_log
fill 68 290 323 68 291 323 minecraft:stripped_dark_oak_log
fill 68 290 325 68 291 325 minecraft:stripped_dark_oak_log
fill 68 290 355 68 291 355 minecraft:stripped_dark_oak_log
fill 68 290 357 68 291 357 minecraft:stripped_dark_oak_log
fill 68 290 359 68 291 359 minecraft:stripped_dark_oak_log
fill 68 290 361 68 291 361 minecraft:stripped_dark_oak_log
fill 68 290 363 68 291 363 minecraft:stripped_dark_oak_log
fill 69 290 324 69 291 324 minecraft:stripped_dark_oak_log
fill 69 290 326 69 291 326 minecraft:stripped_dark_oak_log
fill 69 290 354 69 291 354 minecraft:stripped_dark_oak_log
fill 69 290 356 69 291 356 minecraft:stripped_dark_oak_log
fill 69 290 358 69 291 358 minecraft:stripped_dark_oak_log
fill 69 290 360 69 291 360 minecraft:stripped_dark_oak_log
fill 69 290 362 69 291 362 minecraft:stripped_dark_oak_log
fill 70 290 323 70 291 323 minecraft:stripped_dark_oak_log
fill 70 290 325 70 291 325 minecraft:stripped_dark_oak_log
setblock 70 290 363 minecraft:stripped_dark_oak_log
fill 71 290 324 71 291 324 minecraft:stripped_dark_oak_log
fill 71 290 326 71 291 326 minecraft:stripped_dark_oak_log
fill 71 290 328 71 291 328 minecraft:stripped_dark_oak_log
fill 72 290 323 72 291 323 minecraft:stripped_dark_oak_log
fill 72 290 325 72 291 325 minecraft:stripped_dark_oak_log
fill 72 290 327 72 291 327 minecraft:stripped_dark_oak_log
fill 72 290 363 75 290 363 minecraft:stripped_dark_oak_log
fill 73 290 324 73 291 324 minecraft:stripped_dark_oak_log
fill 73 290 326 73 291 326 minecraft:stripped_dark_oak_log
fill 73 290 328 73 291 328 minecraft:stripped_dark_oak_log
fill 74 290 323 74 291 323 minecraft:stripped_dark_oak_log
fill 74 290 325 74 291 325 minecraft:stripped_dark_oak_log
fill 74 290 327 74 291 327 minecraft:stripped_dark_oak_log
fill 75 290 324 75 291 324 minecraft:stripped_dark_oak_log
fill 75 290 326 75 291 326 minecraft:stripped_dark_oak_log
fill 75 290 328 75 291 328 minecraft:stripped_dark_oak_log
fill 76 290 323 76 291 323 minecraft:stripped_dark_oak_log
fill 76 290 325 76 291 325 minecraft:stripped_dark_oak_log
fill 76 290 327 76 291 327 minecraft:stripped_dark_oak_log
fill 77 290 324 77 291 324 minecraft:stripped_dark_oak_log
fill 77 290 326 77 291 326 minecraft:stripped_dark_oak_log
fill 77 290 328 77 291 328 minecraft:stripped_dark_oak_log
fill 78 290 323 78 291 323 minecraft:stripped_dark_oak_log
fill 78 290 325 78 291 325 minecraft:stripped_dark_oak_log
fill 78 290 327 78 291 327 minecraft:stripped_dark_oak_log
fill 78 290 343 78 291 343 minecraft:stripped_dark_oak_log
fill 78 290 345 78 291 345 minecraft:stripped_dark_oak_log
fill 78 290 347 78 291 347 minecraft:stripped_dark_oak_log
fill 78 290 349 78 291 349 minecraft:stripped_dark_oak_log
fill 79 290 324 79 291 324 minecraft:stripped_dark_oak_log
fill 79 290 326 79 291 326 minecraft:stripped_dark_oak_log
fill 79 290 328 79 291 328 minecraft:stripped_dark_oak_log
fill 79 290 344 79 291 344 minecraft:stripped_dark_oak_log
fill 79 290 346 79 291 346 minecraft:stripped_dark_oak_log
fill 79 290 348 79 291 348 minecraft:stripped_dark_oak_log
fill 80 290 323 80 291 323 minecraft:stripped_dark_oak_log
fill 80 290 325 80 291 325 minecraft:stripped_dark_oak_log
fill 80 290 327 80 291 327 minecraft:stripped_dark_oak_log
fill 80 290 343 80 291 343 minecraft:stripped_dark_oak_log
fill 80 290 345 80 291 345 minecraft:stripped_dark_oak_log
fill 80 290 347 80 291 347 minecraft:stripped_dark_oak_log
fill 80 290 349 80 291 349 minecraft:stripped_dark_oak_log
fill 81 290 324 81 291 324 minecraft:stripped_dark_oak_log
fill 81 290 326 81 291 326 minecraft:stripped_dark_oak_log
fill 81 290 328 81 291 328 minecraft:stripped_dark_oak_log
fill 81 290 344 81 291 344 minecraft:stripped_dark_oak_log
fill 81 290 346 81 291 346 minecraft:stripped_dark_oak_log
fill 81 290 348 81 291 348 minecraft:stripped_dark_oak_log
fill 82 290 323 82 291 323 minecraft:stripped_dark_oak_log
fill 82 290 325 82 291 325 minecraft:stripped_dark_oak_log
fill 82 290 327 82 291 327 minecraft:stripped_dark_oak_log
fill 82 290 343 82 291 343 minecraft:stripped_dark_oak_log
fill 82 290 345 82 291 345 minecraft:stripped_dark_oak_log
fill 82 290 347 82 291 347 minecraft:stripped_dark_oak_log
fill 82 290 349 82 291 349 minecraft:stripped_dark_oak_log
fill 83 290 324 83 291 324 minecraft:stripped_dark_oak_log
fill 83 290 326 83 291 326 minecraft:stripped_dark_oak_log
fill 83 290 328 83 291 328 minecraft:stripped_dark_oak_log
fill 83 290 344 83 291 344 minecraft:stripped_dark_oak_log
fill 83 290 346 83 291 346 minecraft:stripped_dark_oak_log
fill 83 290 348 83 291 348 minecraft:stripped_dark_oak_log
setblock 84 290 323 minecraft:stripped_dark_oak_log
fill 84 290 343 84 291 343 minecraft:stripped_dark_oak_log
fill 84 290 345 84 291 345 minecraft:stripped_dark_oak_log
fill 84 290 347 84 291 347 minecraft:stripped_dark_oak_log
fill 84 290 349 84 291 349 minecraft:stripped_dark_oak_log
fill 85 290 344 85 291 344 minecraft:stripped_dark_oak_log
fill 85 290 346 85 291 346 minecraft:stripped_dark_oak_log
fill 85 290 348 85 291 348 minecraft:stripped_dark_oak_log
fill 86 290 323 88 290 323 minecraft:stripped_dark_oak_log
fill 86 290 343 86 291 343 minecraft:stripped_dark_oak_log
fill 86 290 345 86 291 345 minecraft:stripped_dark_oak_log
fill 86 290 347 86 291 347 minecraft:stripped_dark_oak_log
fill 86 290 349 86 291 349 minecraft:stripped_dark_oak_log
fill 86 290 363 88 290 363 minecraft:stripped_dark_oak_log
fill 87 290 344 87 291 344 minecraft:stripped_dark_oak_log
fill 87 290 346 87 291 346 minecraft:stripped_dark_oak_log
fill 87 290 348 87 291 348 minecraft:stripped_dark_oak_log
setblock 88 290 324 minecraft:stripped_dark_oak_log
setblock 88 290 326 minecraft:stripped_dark_oak_log
fill 88 290 328 88 290 331 minecraft:stripped_dark_oak_log
setblock 88 290 333 minecraft:stripped_dark_oak_log
fill 88 290 335 88 290 338 minecraft:stripped_dark_oak_log
setblock 88 290 340 minecraft:stripped_dark_oak_log
fill 88 290 342 88 290 343 minecraft:stripped_dark_oak_log
fill 88 290 345 88 291 345 minecraft:stripped_dark_oak_log
fill 88 290 347 88 291 347 minecraft:stripped_dark_oak_log
fill 88 290 349 88 290 352 minecraft:stripped_dark_oak_log
setblock 88 290 354 minecraft:stripped_dark_oak_log
fill 88 290 356 88 290 359 minecraft:stripped_dark_oak_log
setblock 88 290 361 minecraft:stripped_dark_oak_log
setblock 48 291 325 minecraft:stripped_dark_oak_log
setblock 48 291 332 minecraft:stripped_dark_oak_log
setblock 48 291 339 minecraft:stripped_dark_oak_log
setblock 48 291 346 minecraft:stripped_dark_oak_log
setblock 48 291 353 minecraft:stripped_dark_oak_log
setblock 48 291 360 minecraft:stripped_dark_oak_log
setblock 52 291 363 minecraft:stripped_dark_oak_log
setblock 53 291 323 minecraft:stripped_dark_oak_log
fill 59 291 322 59 308 322 minecraft:dark_oak_planks
setblock 59 291 363 minecraft:stripped_dark_oak_log
setblock 60 291 323 minecraft:stripped_dark_oak_log
fill 64 291 322 64 308 322 minecraft:dark_oak_planks
setblock 73 291 363 minecraft:stripped_dark_oak_log
setblock 87 291 363 minecraft:stripped_dark_oak_log
setblock 88 291 323 minecraft:stripped_dark_oak_log
setblock 88 291 330 minecraft:stripped_dark_oak_log
setblock 88 291 337 minecraft:stripped_dark_oak_log
setblock 88 291 343 minecraft:stripped_dark_oak_log
setblock 88 291 349 minecraft:stripped_dark_oak_log
setblock 88 291 351 minecraft:stripped_dark_oak_log
setblock 88 291 358 minecraft:stripped_dark_oak_log
setblock 89 291 334 minecraft:red_concrete
setblock 48 292 326 minecraft:stripped_dark_oak_log
setblock 48 292 333 minecraft:stripped_dark_oak_log
setblock 48 292 340 minecraft:stripped_dark_oak_log
setblock 48 292 347 minecraft:stripped_dark_oak_log
setblock 48 292 354 minecraft:stripped_dark_oak_log
setblock 48 292 361 minecraft:stripped_dark_oak_log
setblock 50 292 325 minecraft:light[level=12]
setblock 50 292 332 minecraft:light[level=12]
setblock 50 292 339 minecraft:light[level=12]
setblock 50 292 346 minecraft:light[level=12]
setblock 50 292 353 minecraft:light[level=12]
setblock 50 292 360 minecraft:light[level=12]
setblock 52 292 323 minecraft:stripped_dark_oak_log
setblock 53 292 363 minecraft:stripped_dark_oak_log
setblock 57 292 325 minecraft:light[level=12]
setblock 57 292 332 minecraft:light[level=12]
setblock 57 292 339 minecraft:light[level=12]
setblock 57 292 346 minecraft:light[level=12]
setblock 57 292 353 minecraft:light[level=12]
setblock 57 292 360 minecraft:light[level=12]
setblock 59 292 323 minecraft:stripped_dark_oak_log
setblock 60 292 363 minecraft:stripped_dark_oak_log
setblock 63 292 354 minecraft:shroomlight
setblock 63 292 356 minecraft:shroomlight
setblock 63 292 358 minecraft:shroomlight
setblock 63 292 360 minecraft:shroomlight
setblock 63 292 362 minecraft:shroomlight
setblock 64 292 325 minecraft:light[level=12]
setblock 64 292 332 minecraft:light[level=12]
setblock 64 292 339 minecraft:light[level=12]
setblock 64 292 346 minecraft:light[level=12]
setblock 64 292 353 minecraft:light[level=12]
setblock 64 292 355 minecraft:shroomlight
setblock 64 292 357 minecraft:shroomlight
setblock 64 292 359 minecraft:shroomlight
setblock 64 292 361 minecraft:shroomlight
setblock 64 292 363 minecraft:shroomlight
setblock 65 292 324 minecraft:shroomlight
setblock 65 292 326 minecraft:shroomlight
setblock 65 292 354 minecraft:shroomlight
setblock 65 292 356 minecraft:shroomlight
setblock 65 292 358 minecraft:shroomlight
setblock 65 292 360 minecraft:shroomlight
setblock 65 292 362 minecraft:shroomlight
setblock 66 292 323 minecraft:shroomlight
setblock 66 292 325 minecraft:shroomlight
setblock 66 292 355 minecraft:shroomlight
setblock 66 292 357 minecraft:shroomlight
setblock 66 292 359 minecraft:shroomlight
setblock 66 292 361 minecraft:shroomlight
setblock 66 292 363 minecraft:shroomlight
setblock 67 292 324 minecraft:shroomlight
setblock 67 292 326 minecraft:shroomlight
setblock 67 292 354 minecraft:shroomlight
setblock 67 292 356 minecraft:shroomlight
setblock 67 292 358 minecraft:shroomlight
setblock 67 292 360 minecraft:shroomlight
setblock 67 292 362 minecraft:shroomlight
setblock 68 292 323 minecraft:shroomlight
setblock 68 292 325 minecraft:shroomlight
setblock 68 292 355 minecraft:shroomlight
setblock 68 292 357 minecraft:shroomlight
setblock 68 292 359 minecraft:shroomlight
setblock 68 292 361 minecraft:shroomlight
setblock 68 292 363 minecraft:shroomlight
setblock 69 292 324 minecraft:shroomlight
setblock 69 292 326 minecraft:shroomlight
setblock 69 292 354 minecraft:shroomlight
setblock 69 292 356 minecraft:shroomlight
setblock 69 292 358 minecraft:shroomlight
setblock 69 292 360 minecraft:shroomlight
setblock 69 292 362 minecraft:shroomlight
setblock 70 292 323 minecraft:shroomlight
setblock 70 292 325 minecraft:shroomlight
setblock 71 292 324 minecraft:shroomlight
setblock 71 292 326 minecraft:shroomlight
setblock 71 292 328 minecraft:shroomlight
setblock 71 292 332 minecraft:light[level=12]
setblock 71 292 339 minecraft:light[level=12]
setblock 71 292 346 minecraft:light[level=12]
setblock 71 292 353 minecraft:light[level=12]
setblock 71 292 360 minecraft:light[level=12]
setblock 72 292 323 minecraft:shroomlight
setblock 72 292 325 minecraft:shroomlight
setblock 72 292 327 minecraft:shroomlight
setblock 73 292 324 minecraft:shroomlight
setblock 73 292 326 minecraft:shroomlight
setblock 73 292 328 minecraft:shroomlight
setblock 74 292 323 minecraft:shroomlight
setblock 74 292 325 minecraft:shroomlight
setblock 74 292 327 minecraft:shroomlight
setblock 74 292 363 minecraft:stripped_dark_oak_log
setblock 75 292 324 minecraft:shroomlight
setblock 75 292 326 minecraft:shroomlight
setblock 75 292 328 minecraft:shroomlight
setblock 76 292 323 minecraft:shroomlight
setblock 76 292 325 minecraft:shroomlight
setblock 76 292 327 minecraft:shroomlight
setblock 77 292 324 minecraft:shroomlight
setblock 77 292 326 minecraft:shroomlight
setblock 77 292 328 minecraft:shroomlight
setblock 78 292 323 minecraft:shroomlight
setblock 78 292 325 minecraft:shroomlight
setblock 78 292 327 minecraft:shroomlight
setblock 78 292 332 minecraft:light[level=12]
setblock 78 292 339 minecraft:light[level=12]
setblock 78 292 343 minecraft:shroomlight
setblock 78 292 345 minecraft:shroomlight
setblock 78 292 347 minecraft:shroomlight
setblock 78 292 349 minecraft:shroomlight
setblock 78 292 353 minecraft:light[level=12]
setblock 79 292 324 minecraft:shroomlight
setblock 79 292 326 minecraft:shroomlight
setblock 79 292 328 minecraft:shroomlight
setblock 79 292 344 minecraft:shroomlight
setblock 79 292 346 minecraft:shroomlight
setblock 79 292 348 minecraft:shroomlight
setblock 80 292 323 minecraft:shroomlight
setblock 80 292 325 minecraft:shroomlight
setblock 80 292 327 minecraft:shroomlight
setblock 80 292 343 minecraft:shroomlight
setblock 80 292 345 minecraft:shroomlight
setblock 80 292 347 minecraft:shroomlight
setblock 80 292 349 minecraft:shroomlight
setblock 81 292 324 minecraft:shroomlight
setblock 81 292 326 minecraft:shroomlight
setblock 81 292 328 minecraft:shroomlight
setblock 81 292 344 minecraft:shroomlight
setblock 81 292 346 minecraft:shroomlight
setblock 81 292 348 minecraft:shroomlight
setblock 82 292 323 minecraft:shroomlight
setblock 82 292 325 minecraft:shroomlight
setblock 82 292 327 minecraft:shroomlight
setblock 82 292 343 minecraft:shroomlight
setblock 82 292 345 minecraft:shroomlight
setblock 82 292 347 minecraft:shroomlight
setblock 82 292 349 minecraft:shroomlight
setblock 83 292 324 minecraft:shroomlight
setblock 83 292 326 minecraft:shroomlight
setblock 83 292 328 minecraft:shroomlight
setblock 83 292 344 minecraft:shroomlight
setblock 83 292 346 minecraft:shroomlight
setblock 83 292 348 minecraft:shroomlight
setblock 84 292 343 minecraft:shroomlight
setblock 84 292 345 minecraft:shroomlight
setblock 84 292 347 minecraft:shroomlight
setblock 84 292 349 minecraft:shroomlight
setblock 85 292 325 minecraft:light[level=12]
setblock 85 292 332 minecraft:light[level=12]
setblock 85 292 339 minecraft:light[level=12]
setblock 85 292 344 minecraft:shroomlight
setblock 85 292 346 minecraft:shroomlight
setblock 85 292 348 minecraft:shroomlight
setblock 85 292 353 minecraft:light[level=12]
setblock 85 292 360 minecraft:light[level=12]
setblock 86 292 343 minecraft:shroomlight
setblock 86 292 345 minecraft:shroomlight
setblock 86 292 347 minecraft:shroomlight
setblock 86 292 349 minecraft:shroomlight
setblock 87 292 323 minecraft:stripped_dark_oak_log
setblock 87 292 344 minecraft:shroomlight
setblock 87 292 346 minecraft:shroomlight
setblock 87 292 348 minecraft:shroomlight
setblock 88 292 329 minecraft:stripped_dark_oak_log
setblock 88 292 336 minecraft:stripped_dark_oak_log
setblock 88 292 343 minecraft:shroomlight
setblock 88 292 345 minecraft:shroomlight
setblock 88 292 347 minecraft:shroomlight
setblock 88 292 349 minecraft:shroomlight
setblock 88 292 350 minecraft:stripped_dark_oak_log
setblock 88 292 357 minecraft:stripped_dark_oak_log
setblock 88 292 363 minecraft:stripped_dark_oak_log
fill 89 292 334 89 308 334 minecraft:dark_oak_planks
setblock 48 293 327 minecraft:stripped_dark_oak_log
setblock 48 293 334 minecraft:stripped_dark_oak_log
setblock 48 293 341 minecraft:stripped_dark_oak_log
setblock 48 293 348 minecraft:stripped_dark_oak_log
setblock 48 293 355 minecraft:stripped_dark_oak_log
setblock 48 293 362 minecraft:stripped_dark_oak_log
setblock 51 293 323 minecraft:stripped_dark_oak_log
setblock 54 293 363 minecraft:stripped_dark_oak_log
setblock 58 293 323 minecraft:stripped_dark_oak_log
setblock 61 293 363 minecraft:stripped_dark_oak_log
fill 63 293 354 63 294 354 minecraft:stripped_dark_oak_log
fill 63 293 356 63 294 356 minecraft:stripped_dark_oak_log
fill 63 293 358 63 294 358 minecraft:stripped_dark_oak_log
fill 63 293 360 63 294 360 minecraft:stripped_dark_oak_log
fill 63 293 362 63 294 362 minecraft:stripped_dark_oak_log
fill 64 293 355 64 294 355 minecraft:stripped_dark_oak_log
fill 64 293 357 64 294 357 minecraft:stripped_dark_oak_log
fill 64 293 359 64 294 359 minecraft:stripped_dark_oak_log
fill 64 293 361 64 294 361 minecraft:stripped_dark_oak_log
fill 64 293 363 64 294 363 minecraft:stripped_dark_oak_log
fill 65 293 324 65 294 324 minecraft:stripped_dark_oak_log
fill 65 293 326 65 294 326 minecraft:stripped_dark_oak_log
fill 65 293 354 65 294 354 minecraft:stripped_dark_oak_log
fill 65 293 356 65 294 356 minecraft:stripped_dark_oak_log
fill 65 293 358 65 294 358 minecraft:stripped_dark_oak_log
fill 65 293 360 65 294 360 minecraft:stripped_dark_oak_log
fill 65 293 362 65 294 362 minecraft:stripped_dark_oak_log
fill 66 293 323 66 294 323 minecraft:stripped_dark_oak_log
fill 66 293 325 66 294 325 minecraft:stripped_dark_oak_log
fill 66 293 355 66 294 355 minecraft:stripped_dark_oak_log
fill 66 293 357 66 294 357 minecraft:stripped_dark_oak_log
fill 66 293 359 66 294 359 minecraft:stripped_dark_oak_log
fill 66 293 361 66 294 361 minecraft:stripped_dark_oak_log
fill 66 293 363 66 294 363 minecraft:stripped_dark_oak_log
fill 67 293 324 67 294 324 minecraft:stripped_dark_oak_log
fill 67 293 326 67 294 326 minecraft:stripped_dark_oak_log
fill 67 293 354 67 294 354 minecraft:stripped_dark_oak_log
fill 67 293 356 67 294 356 minecraft:stripped_dark_oak_log
fill 67 293 358 67 294 358 minecraft:stripped_dark_oak_log
fill 67 293 360 67 294 360 minecraft:stripped_dark_oak_log
fill 67 293 362 67 294 362 minecraft:stripped_dark_oak_log
fill 68 293 323 68 294 323 minecraft:stripped_dark_oak_log
fill 68 293 325 68 294 325 minecraft:stripped_dark_oak_log
fill 68 293 355 68 294 355 minecraft:stripped_dark_oak_log
fill 68 293 357 68 294 357 minecraft:stripped_dark_oak_log
fill 68 293 359 68 294 359 minecraft:stripped_dark_oak_log
fill 68 293 361 68 294 361 minecraft:stripped_dark_oak_log
fill 68 293 363 68 294 363 minecraft:stripped_dark_oak_log
fill 69 293 324 69 294 324 minecraft:stripped_dark_oak_log
fill 69 293 326 69 294 326 minecraft:stripped_dark_oak_log
fill 69 293 354 69 294 354 minecraft:stripped_dark_oak_log
fill 69 293 356 69 294 356 minecraft:stripped_dark_oak_log
fill 69 293 358 69 294 358 minecraft:stripped_dark_oak_log
fill 69 293 360 69 294 360 minecraft:stripped_dark_oak_log
fill 69 293 362 69 294 362 minecraft:stripped_dark_oak_log
fill 70 293 323 70 294 323 minecraft:stripped_dark_oak_log
fill 70 293 325 70 294 325 minecraft:stripped_dark_oak_log
fill 70 293 364 71 308 364 minecraft:dark_oak_planks
fill 71 293 324 71 294 324 minecraft:stripped_dark_oak_log
fill 71 293 326 71 294 326 minecraft:stripped_dark_oak_log
fill 71 293 328 71 294 328 minecraft:stripped_dark_oak_log
fill 72 293 323 72 294 323 minecraft:stripped_dark_oak_log
fill 72 293 325 72 294 325 minecraft:stripped_dark_oak_log
fill 72 293 327 72 294 327 minecraft:stripped_dark_oak_log
setblock 72 293 364 minecraft:red_concrete
fill 73 293 324 73 294 324 minecraft:stripped_dark_oak_log
fill 73 293 326 73 294 326 minecraft:stripped_dark_oak_log
fill 73 293 328 73 294 328 minecraft:stripped_dark_oak_log
fill 74 293 323 74 294 323 minecraft:stripped_dark_oak_log
fill 74 293 325 74 294 325 minecraft:stripped_dark_oak_log
fill 74 293 327 74 294 327 minecraft:stripped_dark_oak_log
fill 75 293 324 75 294 324 minecraft:stripped_dark_oak_log
fill 75 293 326 75 294 326 minecraft:stripped_dark_oak_log
fill 75 293 328 75 294 328 minecraft:stripped_dark_oak_log
setblock 75 293 363 minecraft:stripped_dark_oak_log
fill 76 293 323 76 294 323 minecraft:stripped_dark_oak_log
fill 76 293 325 76 294 325 minecraft:stripped_dark_oak_log
fill 76 293 327 76 294 327 minecraft:stripped_dark_oak_log
fill 77 293 324 77 294 324 minecraft:stripped_dark_oak_log
fill 77 293 326 77 294 326 minecraft:stripped_dark_oak_log
fill 77 293 328 77 294 328 minecraft:stripped_dark_oak_log
fill 78 293 323 78 294 323 minecraft:stripped_dark_oak_log
fill 78 293 325 78 294 325 minecraft:stripped_dark_oak_log
fill 78 293 327 78 294 327 minecraft:stripped_dark_oak_log
fill 78 293 343 78 294 343 minecraft:stripped_dark_oak_log
fill 78 293 345 78 294 345 minecraft:stripped_dark_oak_log
fill 78 293 347 78 294 347 minecraft:stripped_dark_oak_log
fill 78 293 349 78 294 349 minecraft:stripped_dark_oak_log
fill 79 293 324 79 294 324 minecraft:stripped_dark_oak_log
fill 79 293 326 79 294 326 minecraft:stripped_dark_oak_log
fill 79 293 328 79 294 328 minecraft:stripped_dark_oak_log
fill 79 293 344 79 294 344 minecraft:stripped_dark_oak_log
fill 79 293 346 79 294 346 minecraft:stripped_dark_oak_log
fill 79 293 348 79 294 348 minecraft:stripped_dark_oak_log
fill 80 293 323 80 294 323 minecraft:stripped_dark_oak_log
fill 80 293 325 80 294 325 minecraft:stripped_dark_oak_log
fill 80 293 327 80 294 327 minecraft:stripped_dark_oak_log
fill 80 293 343 80 294 343 minecraft:stripped_dark_oak_log
fill 80 293 345 80 294 345 minecraft:stripped_dark_oak_log
fill 80 293 347 80 294 347 minecraft:stripped_dark_oak_log
fill 80 293 349 80 294 349 minecraft:stripped_dark_oak_log
fill 81 293 324 81 294 324 minecraft:stripped_dark_oak_log
fill 81 293 326 81 294 326 minecraft:stripped_dark_oak_log
fill 81 293 328 81 294 328 minecraft:stripped_dark_oak_log
fill 81 293 344 81 294 344 minecraft:stripped_dark_oak_log
fill 81 293 346 81 294 346 minecraft:stripped_dark_oak_log
fill 81 293 348 81 294 348 minecraft:stripped_dark_oak_log
fill 82 293 323 82 294 323 minecraft:stripped_dark_oak_log
fill 82 293 325 82 294 325 minecraft:stripped_dark_oak_log
fill 82 293 327 82 294 327 minecraft:stripped_dark_oak_log
fill 82 293 343 82 294 343 minecraft:stripped_dark_oak_log
fill 82 293 345 82 294 345 minecraft:stripped_dark_oak_log
fill 82 293 347 82 294 347 minecraft:stripped_dark_oak_log
fill 82 293 349 82 294 349 minecraft:stripped_dark_oak_log
fill 83 293 324 83 294 324 minecraft:stripped_dark_oak_log
fill 83 293 326 83 294 326 minecraft:stripped_dark_oak_log
fill 83 293 328 83 294 328 minecraft:stripped_dark_oak_log
fill 83 293 344 83 294 344 minecraft:stripped_dark_oak_log
fill 83 293 346 83 294 346 minecraft:stripped_dark_oak_log
fill 83 293 348 83 294 348 minecraft:stripped_dark_oak_log
fill 84 293 343 84 294 343 minecraft:stripped_dark_oak_log
fill 84 293 345 84 294 345 minecraft:stripped_dark_oak_log
fill 84 293 347 84 294 347 minecraft:stripped_dark_oak_log
fill 84 293 349 84 294 349 minecraft:stripped_dark_oak_log
fill 85 293 344 85 294 344 minecraft:stripped_dark_oak_log
fill 85 293 346 85 294 346 minecraft:stripped_dark_oak_log
fill 85 293 348 85 294 348 minecraft:stripped_dark_oak_log
setblock 86 293 323 minecraft:stripped_dark_oak_log
fill 86 293 343 86 294 343 minecraft:stripped_dark_oak_log
fill 86 293 345 86 294 345 minecraft:stripped_dark_oak_log
fill 86 293 347 86 294 347 minecraft:stripped_dark_oak_log
fill 86 293 349 86 294 349 minecraft:stripped_dark_oak_log
fill 87 293 344 87 294 344 minecraft:stripped_dark_oak_log
fill 87 293 346 87 294 346 minecraft:stripped_dark_oak_log
fill 87 293 348 87 294 348 minecraft:stripped_dark_oak_log
setblock 88 293 328 minecraft:stripped_dark_oak_log
setblock 88 293 335 minecraft:stripped_dark_oak_log
fill 88 293 342 88 293 343 minecraft:stripped_dark_oak_log
fill 88 293 345 88 294 345 minecraft:stripped_dark_oak_log
fill 88 293 347 88 294 347 minecraft:stripped_dark_oak_log
fill 88 293 349 88 294 349 minecraft:stripped_dark_oak_log
setblock 88 293 356 minecraft:stripped_dark_oak_log
fill 72 294 364 72 308 364 minecraft:dark_oak_planks
fill 84 294 332 84 297 332 minecraft:iron_bars
setblock 88 294 343 minecraft:stripped_dark_oak_log
setblock 47 295 335 minecraft:red_concrete
setblock 48 295 329 minecraft:stripped_dark_oak_log
setblock 48 295 336 minecraft:stripped_dark_oak_log
setblock 48 295 343 minecraft:stripped_dark_oak_log
setblock 48 295 350 minecraft:stripped_dark_oak_log
setblock 48 295 357 minecraft:stripped_dark_oak_log
setblock 49 295 323 minecraft:stripped_dark_oak_log
setblock 49 295 363 minecraft:stripped_dark_oak_log
setblock 56 295 323 minecraft:stripped_dark_oak_log
setblock 56 295 363 minecraft:stripped_dark_oak_log
setblock 63 295 323 minecraft:stripped_dark_oak_log
setblock 63 295 354 minecraft:shroomlight
setblock 63 295 356 minecraft:shroomlight
setblock 63 295 358 minecraft:shroomlight
setblock 63 295 360 minecraft:shroomlight
setblock 63 295 362 minecraft:shroomlight
setblock 64 295 355 minecraft:shroomlight
setblock 64 295 357 minecraft:shroomlight
setblock 64 295 359 minecraft:shroomlight
setblock 64 295 361 minecraft:shroomlight
setblock 64 295 363 minecraft:shroomlight
setblock 65 295 324 minecraft:shroomlight
setblock 65 295 326 minecraft:shroomlight
setblock 65 295 354 minecraft:shroomlight
setblock 65 295 356 minecraft:shroomlight
setblock 65 295 358 minecraft:shroomlight
setblock 65 295 360 minecraft:shroomlight
setblock 65 295 362 minecraft:shroomlight
setblock 66 295 323 minecraft:shroomlight
setblock 66 295 325 minecraft:shroomlight
setblock 66 295 355 minecraft:shroomlight
setblock 66 295 357 minecraft:shroomlight
setblock 66 295 359 minecraft:shroomlight
setblock 66 295 361 minecraft:shroomlight
setblock 66 295 363 minecraft:shroomlight
setblock 67 295 324 minecraft:shroomlight
setblock 67 295 326 minecraft:shroomlight
setblock 67 295 354 minecraft:shroomlight
setblock 67 295 356 minecraft:shroomlight
setblock 67 295 358 minecraft:shroomlight
setblock 67 295 360 minecraft:shroomlight
setblock 67 295 362 minecraft:shroomlight
setblock 68 295 323 minecraft:shroomlight
setblock 68 295 325 minecraft:shroomlight
setblock 68 295 355 minecraft:shroomlight
setblock 68 295 357 minecraft:shroomlight
setblock 68 295 359 minecraft:shroomlight
setblock 68 295 361 minecraft:shroomlight
setblock 68 295 363 minecraft:shroomlight
setblock 69 295 324 minecraft:shroomlight
setblock 69 295 326 minecraft:shroomlight
setblock 69 295 354 minecraft:shroomlight
setblock 69 295 356 minecraft:shroomlight
setblock 69 295 358 minecraft:shroomlight
setblock 69 295 360 minecraft:shroomlight
setblock 69 295 362 minecraft:shroomlight
setblock 70 295 323 minecraft:shroomlight
setblock 70 295 325 minecraft:shroomlight
setblock 70 295 363 minecraft:stripped_dark_oak_log
setblock 71 295 324 minecraft:shroomlight
setblock 71 295 326 minecraft:shroomlight
setblock 71 295 328 minecraft:shroomlight
setblock 72 295 323 minecraft:shroomlight
setblock 72 295 325 minecraft:shroomlight
setblock 72 295 327 minecraft:shroomlight
setblock 73 295 324 minecraft:shroomlight
setblock 73 295 326 minecraft:shroomlight
setblock 73 295 328 minecraft:shroomlight
setblock 74 295 323 minecraft:shroomlight
setblock 74 295 325 minecraft:shroomlight
setblock 74 295 327 minecraft:shroomlight
setblock 75 295 324 minecraft:shroomlight
setblock 75 295 326 minecraft:shroomlight
setblock 75 295 328 minecraft:shroomlight
setblock 76 295 323 minecraft:shroomlight
setblock 76 295 325 minecraft:shroomlight
setblock 76 295 327 minecraft:shroomlight
setblock 77 295 324 minecraft:shroomlight
setblock 77 295 326 minecraft:shroomlight
setblock 77 295 328 minecraft:shroomlight
setblock 78 295 323 minecraft:shroomlight
setblock 78 295 325 minecraft:shroomlight
setblock 78 295 327 minecraft:shroomlight
setblock 78 295 343 minecraft:shroomlight
setblock 78 295 345 minecraft:shroomlight
setblock 78 295 347 minecraft:shroomlight
setblock 78 295 349 minecraft:shroomlight
setblock 79 295 324 minecraft:shroomlight
setblock 79 295 326 minecraft:shroomlight
setblock 79 295 328 minecraft:shroomlight
setblock 79 295 344 minecraft:shroomlight
setblock 79 295 346 minecraft:shroomlight
setblock 79 295 348 minecraft:shroomlight
setblock 80 295 323 minecraft:shroomlight
setblock 80 295 325 minecraft:shroomlight
setblock 80 295 327 minecraft:shroomlight
setblock 80 295 343 minecraft:shroomlight
setblock 80 295 345 minecraft:shroomlight
setblock 80 295 347 minecraft:shroomlight
setblock 80 295 349 minecraft:shroomlight
setblock 81 295 324 minecraft:shroomlight
setblock 81 295 326 minecraft:shroomlight
setblock 81 295 328 minecraft:shroomlight
setblock 81 295 344 minecraft:shroomlight
setblock 81 295 346 minecraft:shroomlight
setblock 81 295 348 minecraft:shroomlight
setblock 82 295 323 minecraft:shroomlight
setblock 82 295 325 minecraft:shroomlight
setblock 82 295 327 minecraft:shroomlight
setblock 82 295 343 minecraft:shroomlight
setblock 82 295 345 minecraft:shroomlight
setblock 82 295 347 minecraft:shroomlight
setblock 82 295 349 minecraft:shroomlight
setblock 83 295 324 minecraft:shroomlight
setblock 83 295 326 minecraft:shroomlight
setblock 83 295 328 minecraft:shroomlight
setblock 83 295 344 minecraft:shroomlight
setblock 83 295 346 minecraft:shroomlight
setblock 83 295 348 minecraft:shroomlight
setblock 84 295 323 minecraft:stripped_dark_oak_log
setblock 84 295 343 minecraft:shroomlight
setblock 84 295 345 minecraft:shroomlight
setblock 84 295 347 minecraft:shroomlight
setblock 84 295 349 minecraft:shroomlight
setblock 85 295 344 minecraft:shroomlight
setblock 85 295 346 minecraft:shroomlight
setblock 85 295 348 minecraft:shroomlight
setblock 86 295 343 minecraft:shroomlight
setblock 86 295 345 minecraft:shroomlight
setblock 86 295 347 minecraft:shroomlight
setblock 86 295 349 minecraft:shroomlight
setblock 87 295 344 minecraft:shroomlight
setblock 87 295 346 minecraft:shroomlight
setblock 87 295 348 minecraft:shroomlight
setblock 88 295 326 minecraft:stripped_dark_oak_log
setblock 88 295 333 minecraft:stripped_dark_oak_log
setblock 88 295 340 minecraft:stripped_dark_oak_log
setblock 88 295 343 minecraft:shroomlight
setblock 88 295 345 minecraft:shroomlight
setblock 88 295 347 minecraft:shroomlight
setblock 88 295 349 minecraft:shroomlight
setblock 88 295 354 minecraft:stripped_dark_oak_log
setblock 88 295 361 minecraft:stripped_dark_oak_log
fill 47 296 335 47 308 335 minecraft:dark_oak_planks
setblock 48 296 323 minecraft:stripped_dark_oak_log
setblock 48 296 330 minecraft:stripped_dark_oak_log
setblock 48 296 337 minecraft:stripped_dark_oak_log
setblock 48 296 344 minecraft:stripped_dark_oak_log
setblock 48 296 351 minecraft:stripped_dark_oak_log
setblock 48 296 358 minecraft:stripped_dark_oak_log
setblock 50 296 325 minecraft:light[level=15]
setblock 50 296 333 minecraft:light[level=15]
setblock 50 296 341 minecraft:light[level=15]
setblock 50 296 349 minecraft:light[level=15]
setblock 50 296 357 minecraft:light[level=15]
setblock 50 296 363 minecraft:stripped_dark_oak_log
setblock 55 296 323 minecraft:stripped_dark_oak_log
setblock 57 296 363 minecraft:stripped_dark_oak_log
setblock 58 296 325 minecraft:light[level=15]
setblock 58 296 333 minecraft:light[level=15]
setblock 58 296 341 minecraft:light[level=15]
setblock 58 296 349 minecraft:light[level=15]
setblock 58 296 357 minecraft:light[level=15]
setblock 62 296 323 minecraft:stripped_dark_oak_log
fill 63 296 354 63 297 354 minecraft:stripped_dark_oak_log
fill 63 296 356 63 297 356 minecraft:stripped_dark_oak_log
fill 63 296 358 63 297 358 minecraft:stripped_dark_oak_log
fill 63 296 360 63 297 360 minecraft:stripped_dark_oak_log
fill 63 296 362 63 297 362 minecraft:stripped_dark_oak_log
fill 64 296 355 64 297 355 minecraft:stripped_dark_oak_log
fill 64 296 357 64 297 357 minecraft:stripped_dark_oak_log
fill 64 296 359 64 297 359 minecraft:stripped_dark_oak_log
fill 64 296 361 64 297 361 minecraft:stripped_dark_oak_log
fill 64 296 363 64 297 363 minecraft:stripped_dark_oak_log
fill 65 296 324 65 297 324 minecraft:stripped_dark_oak_log
fill 65 296 326 65 297 326 minecraft:stripped_dark_oak_log
fill 65 296 354 65 297 354 minecraft:stripped_dark_oak_log
fill 65 296 356 65 297 356 minecraft:stripped_dark_oak_log
fill 65 296 358 65 297 358 minecraft:stripped_dark_oak_log
fill 65 296 360 65 297 360 minecraft:stripped_dark_oak_log
fill 65 296 362 65 297 362 minecraft:stripped_dark_oak_log
fill 66 296 323 66 297 323 minecraft:stripped_dark_oak_log
fill 66 296 325 66 297 325 minecraft:stripped_dark_oak_log
setblock 66 296 333 minecraft:light[level=15]
setblock 66 296 341 minecraft:light[level=15]
setblock 66 296 349 minecraft:light[level=15]
fill 66 296 355 66 297 355 minecraft:stripped_dark_oak_log
fill 66 296 357 66 297 357 minecraft:stripped_dark_oak_log
fill 66 296 359 66 297 359 minecraft:stripped_dark_oak_log
fill 66 296 361 66 297 361 minecraft:stripped_dark_oak_log
fill 66 296 363 66 297 363 minecraft:stripped_dark_oak_log
fill 67 296 324 67 297 324 minecraft:stripped_dark_oak_log
fill 67 296 326 67 297 326 minecraft:stripped_dark_oak_log
fill 67 296 354 67 297 354 minecraft:stripped_dark_oak_log
fill 67 296 356 67 297 356 minecraft:stripped_dark_oak_log
fill 67 296 358 67 297 358 minecraft:stripped_dark_oak_log
fill 67 296 360 67 297 360 minecraft:stripped_dark_oak_log
fill 67 296 362 67 297 362 minecraft:stripped_dark_oak_log
fill 68 296 323 68 297 323 minecraft:stripped_dark_oak_log
fill 68 296 325 68 297 325 minecraft:stripped_dark_oak_log
fill 68 296 355 68 297 355 minecraft:stripped_dark_oak_log
fill 68 296 357 68 297 357 minecraft:stripped_dark_oak_log
fill 68 296 359 68 297 359 minecraft:stripped_dark_oak_log
fill 68 296 361 68 297 361 minecraft:stripped_dark_oak_log
fill 68 296 363 68 297 363 minecraft:stripped_dark_oak_log
fill 69 296 324 69 297 324 minecraft:stripped_dark_oak_log
fill 69 296 326 69 297 326 minecraft:stripped_dark_oak_log
fill 69 296 354 69 297 354 minecraft:stripped_dark_oak_log
fill 69 296 356 69 297 356 minecraft:stripped_dark_oak_log
fill 69 296 358 69 297 358 minecraft:stripped_dark_oak_log
fill 69 296 360 69 297 360 minecraft:stripped_dark_oak_log
fill 69 296 362 69 297 362 minecraft:stripped_dark_oak_log
fill 70 296 323 70 297 323 minecraft:stripped_dark_oak_log
fill 70 296 325 70 297 325 minecraft:stripped_dark_oak_log
fill 71 296 324 71 297 324 minecraft:stripped_dark_oak_log
fill 71 296 326 71 297 326 minecraft:stripped_dark_oak_log
fill 71 296 328 71 297 328 minecraft:stripped_dark_oak_log
setblock 71 296 363 minecraft:stripped_dark_oak_log
fill 72 296 323 72 297 323 minecraft:stripped_dark_oak_log
fill 72 296 325 72 297 325 minecraft:stripped_dark_oak_log
fill 72 296 327 72 297 327 minecraft:stripped_dark_oak_log
fill 73 296 324 73 297 324 minecraft:stripped_dark_oak_log
fill 73 296 326 73 297 326 minecraft:stripped_dark_oak_log
fill 73 296 328 73 297 328 minecraft:stripped_dark_oak_log
fill 74 296 323 74 297 323 minecraft:stripped_dark_oak_log
fill 74 296 325 74 297 325 minecraft:stripped_dark_oak_log
fill 74 296 327 74 297 327 minecraft:stripped_dark_oak_log
setblock 74 296 333 minecraft:light[level=15]
setblock 74 296 341 minecraft:light[level=15]
setblock 74 296 349 minecraft:light[level=15]
setblock 74 296 357 minecraft:light[level=15]
fill 75 296 324 75 297 324 minecraft:stripped_dark_oak_log
fill 75 296 326 75 297 326 minecraft:stripped_dark_oak_log
fill 75 296 328 75 297 328 minecraft:stripped_dark_oak_log
fill 76 296 323 76 297 323 minecraft:stripped_dark_oak_log
fill 76 296 325 76 297 325 minecraft:stripped_dark_oak_log
fill 76 296 327 76 297 327 minecraft:stripped_dark_oak_log
fill 77 296 324 77 297 324 minecraft:stripped_dark_oak_log
fill 77 296 326 77 297 326 minecraft:stripped_dark_oak_log
fill 77 296 328 77 297 328 minecraft:stripped_dark_oak_log
fill 78 296 323 78 297 323 minecraft:stripped_dark_oak_log
fill 78 296 325 78 297 325 minecraft:stripped_dark_oak_log
fill 78 296 327 78 297 327 minecraft:stripped_dark_oak_log
fill 78 296 343 78 297 343 minecraft:stripped_dark_oak_log
fill 78 296 345 78 297 345 minecraft:stripped_dark_oak_log
fill 78 296 347 78 297 347 minecraft:stripped_dark_oak_log
fill 78 296 349 78 297 349 minecraft:stripped_dark_oak_log
fill 79 296 324 79 297 324 minecraft:stripped_dark_oak_log
fill 79 296 326 79 297 326 minecraft:stripped_dark_oak_log
fill 79 296 328 79 297 328 minecraft:stripped_dark_oak_log
fill 79 296 344 79 297 344 minecraft:stripped_dark_oak_log
fill 79 296 346 79 297 346 minecraft:stripped_dark_oak_log
fill 79 296 348 79 297 348 minecraft:stripped_dark_oak_log
fill 80 296 323 80 297 323 minecraft:stripped_dark_oak_log
fill 80 296 325 80 297 325 minecraft:stripped_dark_oak_log
fill 80 296 327 80 297 327 minecraft:stripped_dark_oak_log
fill 80 296 343 80 297 343 minecraft:stripped_dark_oak_log
fill 80 296 345 80 297 345 minecraft:stripped_dark_oak_log
fill 80 296 347 80 297 347 minecraft:stripped_dark_oak_log
fill 80 296 349 80 297 349 minecraft:stripped_dark_oak_log
fill 81 296 324 81 297 324 minecraft:stripped_dark_oak_log
fill 81 296 326 81 297 326 minecraft:stripped_dark_oak_log
fill 81 296 328 81 297 328 minecraft:stripped_dark_oak_log
fill 81 296 344 81 297 344 minecraft:stripped_dark_oak_log
fill 81 296 346 81 297 346 minecraft:stripped_dark_oak_log
fill 81 296 348 81 297 348 minecraft:stripped_dark_oak_log
fill 82 296 323 82 297 323 minecraft:stripped_dark_oak_log
fill 82 296 325 82 297 325 minecraft:stripped_dark_oak_log
fill 82 296 327 82 297 327 minecraft:stripped_dark_oak_log
setblock 82 296 333 minecraft:light[level=15]
setblock 82 296 341 minecraft:light[level=15]
fill 82 296 343 82 297 343 minecraft:stripped_dark_oak_log
fill 82 296 345 82 297 345 minecraft:stripped_dark_oak_log
fill 82 296 347 82 297 347 minecraft:stripped_dark_oak_log
fill 82 296 349 82 297 349 minecraft:stripped_dark_oak_log
fill 83 296 324 83 297 324 minecraft:stripped_dark_oak_log
fill 83 296 326 83 297 326 minecraft:stripped_dark_oak_log
fill 83 296 328 83 297 328 minecraft:stripped_dark_oak_log
fill 83 296 344 83 297 344 minecraft:stripped_dark_oak_log
fill 83 296 346 83 297 346 minecraft:stripped_dark_oak_log
fill 83 296 348 83 297 348 minecraft:stripped_dark_oak_log
fill 84 296 343 84 297 343 minecraft:stripped_dark_oak_log
fill 84 296 345 84 297 345 minecraft:stripped_dark_oak_log
fill 84 296 347 84 297 347 minecraft:stripped_dark_oak_log
fill 84 296 349 84 297 349 minecraft:stripped_dark_oak_log
fill 85 296 344 85 297 344 minecraft:stripped_dark_oak_log
fill 85 296 346 85 297 346 minecraft:stripped_dark_oak_log
fill 85 296 348 85 297 348 minecraft:stripped_dark_oak_log
setblock 85 296 363 minecraft:stripped_dark_oak_log
fill 86 296 343 86 297 343 minecraft:stripped_dark_oak_log
fill 86 296 345 86 297 345 minecraft:stripped_dark_oak_log
fill 86 296 347 86 297 347 minecraft:stripped_dark_oak_log
fill 86 296 349 86 297 349 minecraft:stripped_dark_oak_log
fill 87 296 344 87 297 344 minecraft:stripped_dark_oak_log
fill 87 296 346 87 297 346 minecraft:stripped_dark_oak_log
fill 87 296 348 87 297 348 minecraft:stripped_dark_oak_log
setblock 88 296 325 minecraft:stripped_dark_oak_log
setblock 88 296 332 minecraft:stripped_dark_oak_log
setblock 88 296 339 minecraft:stripped_dark_oak_log
fill 88 296 343 88 297 343 minecraft:stripped_dark_oak_log
fill 88 296 345 88 297 345 minecraft:stripped_dark_oak_log
fill 88 296 347 88 297 347 minecraft:stripped_dark_oak_log
fill 88 296 349 88 297 349 minecraft:stripped_dark_oak_log
setblock 88 296 353 minecraft:stripped_dark_oak_log
setblock 88 296 360 minecraft:stripped_dark_oak_log
setblock 48 297 324 minecraft:stripped_dark_oak_log
setblock 48 297 331 minecraft:stripped_dark_oak_log
setblock 48 297 338 minecraft:stripped_dark_oak_log
setblock 48 297 345 minecraft:stripped_dark_oak_log
setblock 48 297 352 minecraft:stripped_dark_oak_log
setblock 48 297 359 minecraft:stripped_dark_oak_log
setblock 51 297 363 minecraft:stripped_dark_oak_log
setblock 54 297 323 minecraft:stripped_dark_oak_log
setblock 58 297 363 minecraft:stripped_dark_oak_log
setblock 61 297 323 minecraft:stripped_dark_oak_log
setblock 72 297 363 minecraft:stripped_dark_oak_log
setblock 86 297 363 minecraft:stripped_dark_oak_log
setblock 88 297 324 minecraft:stripped_dark_oak_log
setblock 88 297 331 minecraft:stripped_dark_oak_log
setblock 88 297 338 minecraft:stripped_dark_oak_log
setblock 88 297 352 minecraft:stripped_dark_oak_log
setblock 88 297 359 minecraft:stripped_dark_oak_log
setblock 48 298 325 minecraft:stripped_dark_oak_log
setblock 48 298 332 minecraft:stripped_dark_oak_log
setblock 48 298 339 minecraft:stripped_dark_oak_log
setblock 48 298 346 minecraft:stripped_dark_oak_log
setblock 48 298 353 minecraft:stripped_dark_oak_log
setblock 48 298 360 minecraft:stripped_dark_oak_log
setblock 50 298 325 minecraft:light[level=12]
setblock 50 298 332 minecraft:light[level=12]
setblock 50 298 339 minecraft:light[level=12]
setblock 50 298 346 minecraft:light[level=12]
setblock 50 298 353 minecraft:light[level=12]
setblock 50 298 360 minecraft:light[level=12]
setblock 52 298 363 minecraft:stripped_dark_oak_log
setblock 53 298 323 minecraft:stripped_dark_oak_log
setblock 57 298 325 minecraft:light[level=12]
setblock 57 298 332 minecraft:light[level=12]
setblock 57 298 339 minecraft:light[level=12]
setblock 57 298 346 minecraft:light[level=12]
setblock 57 298 353 minecraft:light[level=12]
setblock 57 298 360 minecraft:light[level=12]
setblock 59 298 363 minecraft:stripped_dark_oak_log
setblock 60 298 323 minecraft:stripped_dark_oak_log
setblock 63 298 354 minecraft:shroomlight
setblock 63 298 356 minecraft:shroomlight
setblock 63 298 358 minecraft:shroomlight
setblock 63 298 360 minecraft:shroomlight
setblock 63 298 362 minecraft:shroomlight
setblock 64 298 325 minecraft:light[level=12]
setblock 64 298 332 minecraft:light[level=12]
setblock 64 298 339 minecraft:light[level=12]
setblock 64 298 346 minecraft:light[level=12]
setblock 64 298 353 minecraft:light[level=12]
setblock 64 298 355 minecraft:shroomlight
setblock 64 298 357 minecraft:shroomlight
setblock 64 298 359 minecraft:shroomlight
setblock 64 298 361 minecraft:shroomlight
setblock 64 298 363 minecraft:shroomlight
setblock 65 298 324 minecraft:shroomlight
setblock 65 298 326 minecraft:shroomlight
setblock 65 298 354 minecraft:shroomlight
setblock 65 298 356 minecraft:shroomlight
setblock 65 298 358 minecraft:shroomlight
setblock 65 298 360 minecraft:shroomlight
setblock 65 298 362 minecraft:shroomlight
setblock 66 298 323 minecraft:shroomlight
setblock 66 298 325 minecraft:shroomlight
setblock 66 298 355 minecraft:shroomlight
setblock 66 298 357 minecraft:shroomlight
setblock 66 298 359 minecraft:shroomlight
setblock 66 298 361 minecraft:shroomlight
setblock 66 298 363 minecraft:shroomlight
setblock 67 298 324 minecraft:shroomlight
setblock 67 298 326 minecraft:shroomlight
setblock 67 298 354 minecraft:shroomlight
setblock 67 298 356 minecraft:shroomlight
setblock 67 298 358 minecraft:shroomlight
setblock 67 298 360 minecraft:shroomlight
setblock 67 298 362 minecraft:shroomlight
setblock 68 298 323 minecraft:shroomlight
setblock 68 298 325 minecraft:shroomlight
setblock 68 298 355 minecraft:shroomlight
setblock 68 298 357 minecraft:shroomlight
setblock 68 298 359 minecraft:shroomlight
setblock 68 298 361 minecraft:shroomlight
setblock 68 298 363 minecraft:shroomlight
setblock 69 298 324 minecraft:shroomlight
setblock 69 298 326 minecraft:shroomlight
setblock 69 298 354 minecraft:shroomlight
setblock 69 298 356 minecraft:shroomlight
setblock 69 298 358 minecraft:shroomlight
setblock 69 298 360 minecraft:shroomlight
setblock 69 298 362 minecraft:shroomlight
setblock 70 298 323 minecraft:shroomlight
setblock 70 298 325 minecraft:shroomlight
setblock 71 298 324 minecraft:shroomlight
setblock 71 298 326 minecraft:shroomlight
setblock 71 298 328 minecraft:shroomlight
setblock 71 298 332 minecraft:light[level=12]
setblock 71 298 339 minecraft:light[level=12]
setblock 71 298 346 minecraft:light[level=12]
setblock 71 298 353 minecraft:light[level=12]
setblock 71 298 360 minecraft:light[level=12]
setblock 72 298 323 minecraft:shroomlight
setblock 72 298 325 minecraft:shroomlight
setblock 72 298 327 minecraft:shroomlight
setblock 73 298 324 minecraft:shroomlight
setblock 73 298 326 minecraft:shroomlight
setblock 73 298 328 minecraft:shroomlight
setblock 73 298 363 minecraft:stripped_dark_oak_log
setblock 74 298 323 minecraft:shroomlight
setblock 74 298 325 minecraft:shroomlight
setblock 74 298 327 minecraft:shroomlight
setblock 75 298 324 minecraft:shroomlight
setblock 75 298 326 minecraft:shroomlight
setblock 75 298 328 minecraft:shroomlight
setblock 76 298 323 minecraft:shroomlight
setblock 76 298 325 minecraft:shroomlight
setblock 76 298 327 minecraft:shroomlight
setblock 77 298 324 minecraft:shroomlight
setblock 77 298 326 minecraft:shroomlight
setblock 77 298 328 minecraft:shroomlight
setblock 78 298 323 minecraft:shroomlight
setblock 78 298 325 minecraft:shroomlight
setblock 78 298 327 minecraft:shroomlight
setblock 78 298 332 minecraft:light[level=12]
setblock 78 298 339 minecraft:light[level=12]
setblock 78 298 343 minecraft:shroomlight
setblock 78 298 345 minecraft:shroomlight
setblock 78 298 347 minecraft:shroomlight
setblock 78 298 349 minecraft:shroomlight
setblock 78 298 353 minecraft:light[level=12]
setblock 79 298 324 minecraft:shroomlight
setblock 79 298 326 minecraft:shroomlight
setblock 79 298 328 minecraft:shroomlight
setblock 79 298 344 minecraft:shroomlight
setblock 79 298 346 minecraft:shroomlight
setblock 79 298 348 minecraft:shroomlight
setblock 80 298 323 minecraft:shroomlight
setblock 80 298 325 minecraft:shroomlight
setblock 80 298 327 minecraft:shroomlight
setblock 80 298 343 minecraft:shroomlight
setblock 80 298 345 minecraft:shroomlight
setblock 80 298 347 minecraft:shroomlight
setblock 80 298 349 minecraft:shroomlight
setblock 81 298 324 minecraft:shroomlight
setblock 81 298 326 minecraft:shroomlight
setblock 81 298 328 minecraft:shroomlight
setblock 81 298 344 minecraft:shroomlight
setblock 81 298 346 minecraft:shroomlight
setblock 81 298 348 minecraft:shroomlight
setblock 82 298 323 minecraft:shroomlight
setblock 82 298 325 minecraft:shroomlight
setblock 82 298 327 minecraft:shroomlight
setblock 82 298 343 minecraft:shroomlight
setblock 82 298 345 minecraft:shroomlight
setblock 82 298 347 minecraft:shroomlight
setblock 82 298 349 minecraft:shroomlight
setblock 83 298 324 minecraft:shroomlight
setblock 83 298 326 minecraft:shroomlight
setblock 83 298 328 minecraft:shroomlight
setblock 83 298 344 minecraft:shroomlight
setblock 83 298 346 minecraft:shroomlight
setblock 83 298 348 minecraft:shroomlight
fill 84 298 327 87 298 337 minecraft:dark_oak_planks
setblock 84 298 343 minecraft:shroomlight
setblock 84 298 345 minecraft:shroomlight
setblock 84 298 347 minecraft:shroomlight
setblock 84 298 349 minecraft:shroomlight
setblock 85 298 325 minecraft:light[level=12]
setblock 85 298 339 minecraft:light[level=12]
setblock 85 298 344 minecraft:shroomlight
setblock 85 298 346 minecraft:shroomlight
setblock 85 298 348 minecraft:shroomlight
setblock 85 298 353 minecraft:light[level=12]
fill 85 298 358 87 299 358 minecraft:iron_bars
setblock 85 298 360 minecraft:light[level=12]
setblock 86 298 343 minecraft:shroomlight
setblock 86 298 345 minecraft:shroomlight
setblock 86 298 347 minecraft:shroomlight
setblock 86 298 349 minecraft:shroomlight
setblock 87 298 344 minecraft:shroomlight
setblock 87 298 346 minecraft:shroomlight
setblock 87 298 348 minecraft:shroomlight
setblock 87 298 363 minecraft:stripped_dark_oak_log
setblock 88 298 323 minecraft:stripped_dark_oak_log
setblock 88 298 330 minecraft:stripped_dark_oak_log
setblock 88 298 337 minecraft:stripped_dark_oak_log
setblock 88 298 343 minecraft:shroomlight
setblock 88 298 345 minecraft:shroomlight
setblock 88 298 347 minecraft:shroomlight
setblock 88 298 349 minecraft:shroomlight
setblock 88 298 351 minecraft:stripped_dark_oak_log
setblock 88 298 358 minecraft:stripped_dark_oak_log
fill 48 299 326 48 300 326 minecraft:stripped_dark_oak_log
fill 48 299 333 48 300 333 minecraft:stripped_dark_oak_log
fill 48 299 340 48 300 340 minecraft:stripped_dark_oak_log
fill 48 299 347 48 300 347 minecraft:stripped_dark_oak_log
fill 48 299 354 48 300 354 minecraft:stripped_dark_oak_log
fill 48 299 361 48 300 361 minecraft:stripped_dark_oak_log
fill 52 299 323 52 300 323 minecraft:stripped_dark_oak_log
fill 53 299 363 53 300 363 minecraft:stripped_dark_oak_log
fill 59 299 323 59 300 323 minecraft:stripped_dark_oak_log
fill 60 299 363 60 300 363 minecraft:stripped_dark_oak_log
fill 63 299 354 63 300 354 minecraft:stripped_dark_oak_log
fill 63 299 356 63 300 356 minecraft:stripped_dark_oak_log
fill 63 299 358 63 300 358 minecraft:stripped_dark_oak_log
fill 63 299 360 63 300 360 minecraft:stripped_dark_oak_log
fill 63 299 362 63 300 362 minecraft:stripped_dark_oak_log
fill 64 299 355 64 300 355 minecraft:stripped_dark_oak_log
fill 64 299 357 64 300 357 minecraft:stripped_dark_oak_log
fill 64 299 359 64 300 359 minecraft:stripped_dark_oak_log
fill 64 299 361 64 300 361 minecraft:stripped_dark_oak_log
fill 64 299 363 64 300 363 minecraft:stripped_dark_oak_log
fill 65 299 324 65 300 324 minecraft:stripped_dark_oak_log
fill 65 299 326 65 300 326 minecraft:stripped_dark_oak_log
fill 65 299 354 65 300 354 minecraft:stripped_dark_oak_log
fill 65 299 356 65 300 356 minecraft:stripped_dark_oak_log
fill 65 299 358 65 300 358 minecraft:stripped_dark_oak_log
fill 65 299 360 65 300 360 minecraft:stripped_dark_oak_log
fill 65 299 362 65 300 362 minecraft:stripped_dark_oak_log
fill 66 299 323 66 300 323 minecraft:stripped_dark_oak_log
fill 66 299 325 66 300 325 minecraft:stripped_dark_oak_log
fill 66 299 355 66 300 355 minecraft:stripped_dark_oak_log
fill 66 299 357 66 300 357 minecraft:stripped_dark_oak_log
fill 66 299 359 66 300 359 minecraft:stripped_dark_oak_log
fill 66 299 361 66 300 361 minecraft:stripped_dark_oak_log
fill 66 299 363 66 300 363 minecraft:stripped_dark_oak_log
fill 67 299 324 67 300 324 minecraft:stripped_dark_oak_log
fill 67 299 326 67 300 326 minecraft:stripped_dark_oak_log
fill 67 299 354 67 300 354 minecraft:stripped_dark_oak_log
fill 67 299 356 67 300 356 minecraft:stripped_dark_oak_log
fill 67 299 358 67 300 358 minecraft:stripped_dark_oak_log
fill 67 299 360 67 300 360 minecraft:stripped_dark_oak_log
fill 67 299 362 67 300 362 minecraft:stripped_dark_oak_log
fill 68 299 323 68 300 323 minecraft:stripped_dark_oak_log
fill 68 299 325 68 300 325 minecraft:stripped_dark_oak_log
fill 68 299 355 68 300 355 minecraft:stripped_dark_oak_log
fill 68 299 357 68 300 357 minecraft:stripped_dark_oak_log
fill 68 299 359 68 300 359 minecraft:stripped_dark_oak_log
fill 68 299 361 68 300 361 minecraft:stripped_dark_oak_log
fill 68 299 363 68 300 363 minecraft:stripped_dark_oak_log
fill 69 299 324 69 300 324 minecraft:stripped_dark_oak_log
fill 69 299 326 69 300 326 minecraft:stripped_dark_oak_log
fill 69 299 354 69 300 354 minecraft:stripped_dark_oak_log
fill 69 299 356 69 300 356 minecraft:stripped_dark_oak_log
fill 69 299 358 69 300 358 minecraft:stripped_dark_oak_log
fill 69 299 360 69 300 360 minecraft:stripped_dark_oak_log
fill 69 299 362 69 300 362 minecraft:stripped_dark_oak_log
fill 70 299 323 70 300 323 minecraft:stripped_dark_oak_log
fill 70 299 325 70 300 325 minecraft:stripped_dark_oak_log
fill 71 299 324 71 300 324 minecraft:stripped_dark_oak_log
fill 71 299 326 71 300 326 minecraft:stripped_dark_oak_log
fill 71 299 328 71 300 328 minecraft:stripped_dark_oak_log
fill 72 299 323 72 300 323 minecraft:stripped_dark_oak_log
fill 72 299 325 72 300 325 minecraft:stripped_dark_oak_log
fill 72 299 327 72 300 327 minecraft:stripped_dark_oak_log
fill 73 299 324 73 300 324 minecraft:stripped_dark_oak_log
fill 73 299 326 73 300 326 minecraft:stripped_dark_oak_log
fill 73 299 328 73 300 328 minecraft:stripped_dark_oak_log
fill 74 299 323 74 300 323 minecraft:stripped_dark_oak_log
fill 74 299 325 74 300 325 minecraft:stripped_dark_oak_log
fill 74 299 327 74 300 327 minecraft:stripped_dark_oak_log
fill 74 299 363 74 300 363 minecraft:stripped_dark_oak_log
fill 75 299 324 75 300 324 minecraft:stripped_dark_oak_log
fill 75 299 326 75 300 326 minecraft:stripped_dark_oak_log
fill 75 299 328 75 300 328 minecraft:stripped_dark_oak_log
fill 76 299 323 76 300 323 minecraft:stripped_dark_oak_log
fill 76 299 325 76 300 325 minecraft:stripped_dark_oak_log
fill 76 299 327 76 300 327 minecraft:stripped_dark_oak_log
fill 77 299 324 77 300 324 minecraft:stripped_dark_oak_log
fill 77 299 326 77 300 326 minecraft:stripped_dark_oak_log
fill 77 299 328 77 300 328 minecraft:stripped_dark_oak_log
fill 78 299 323 78 300 323 minecraft:stripped_dark_oak_log
fill 78 299 325 78 300 325 minecraft:stripped_dark_oak_log
fill 78 299 327 78 300 327 minecraft:stripped_dark_oak_log
fill 78 299 343 78 300 343 minecraft:stripped_dark_oak_log
fill 78 299 345 78 300 345 minecraft:stripped_dark_oak_log
fill 78 299 347 78 300 347 minecraft:stripped_dark_oak_log
fill 78 299 349 78 300 349 minecraft:stripped_dark_oak_log
fill 79 299 324 79 300 324 minecraft:stripped_dark_oak_log
fill 79 299 326 79 300 326 minecraft:stripped_dark_oak_log
fill 79 299 328 79 300 328 minecraft:stripped_dark_oak_log
fill 79 299 344 79 300 344 minecraft:stripped_dark_oak_log
fill 79 299 346 79 300 346 minecraft:stripped_dark_oak_log
fill 79 299 348 79 300 348 minecraft:stripped_dark_oak_log
fill 80 299 323 80 300 323 minecraft:stripped_dark_oak_log
fill 80 299 325 80 300 325 minecraft:stripped_dark_oak_log
fill 80 299 327 80 300 327 minecraft:stripped_dark_oak_log
fill 80 299 343 80 300 343 minecraft:stripped_dark_oak_log
fill 80 299 345 80 300 345 minecraft:stripped_dark_oak_log
fill 80 299 347 80 300 347 minecraft:stripped_dark_oak_log
fill 80 299 349 80 300 349 minecraft:stripped_dark_oak_log
fill 81 299 324 81 300 324 minecraft:stripped_dark_oak_log
fill 81 299 326 81 300 326 minecraft:stripped_dark_oak_log
fill 81 299 328 81 300 328 minecraft:stripped_dark_oak_log
fill 81 299 344 81 300 344 minecraft:stripped_dark_oak_log
fill 81 299 346 81 300 346 minecraft:stripped_dark_oak_log
fill 81 299 348 81 300 348 minecraft:stripped_dark_oak_log
fill 82 299 323 82 300 323 minecraft:stripped_dark_oak_log
fill 82 299 325 82 300 325 minecraft:stripped_dark_oak_log
fill 82 299 327 82 300 327 minecraft:stripped_dark_oak_log
fill 82 299 343 82 300 343 minecraft:stripped_dark_oak_log
fill 82 299 345 82 300 345 minecraft:stripped_dark_oak_log
fill 82 299 347 82 300 347 minecraft:stripped_dark_oak_log
fill 82 299 349 82 300 349 minecraft:stripped_dark_oak_log
fill 83 299 324 83 300 324 minecraft:stripped_dark_oak_log
fill 83 299 326 83 300 326 minecraft:stripped_dark_oak_log
fill 83 299 328 87 299 328 minecraft:stripped_dark_oak_log
fill 83 299 344 83 300 344 minecraft:stripped_dark_oak_log
fill 83 299 346 83 300 346 minecraft:stripped_dark_oak_log
fill 83 299 348 83 300 348 minecraft:stripped_dark_oak_log
fill 84 299 327 87 299 327 minecraft:stripped_dark_oak_log
fill 84 299 329 87 299 337 minecraft:stripped_dark_oak_log
fill 84 299 343 84 300 343 minecraft:stripped_dark_oak_log
fill 84 299 345 84 300 345 minecraft:stripped_dark_oak_log
fill 84 299 347 84 300 347 minecraft:stripped_dark_oak_log
fill 84 299 349 84 300 349 minecraft:stripped_dark_oak_log
fill 85 299 344 85 300 344 minecraft:stripped_dark_oak_log
fill 85 299 346 85 300 346 minecraft:stripped_dark_oak_log
fill 85 299 348 85 300 348 minecraft:stripped_dark_oak_log
fill 86 299 343 86 300 343 minecraft:stripped_dark_oak_log
fill 86 299 345 86 300 345 minecraft:stripped_dark_oak_log
fill 86 299 347 86 300 347 minecraft:stripped_dark_oak_log
fill 86 299 349 86 300 349 minecraft:stripped_dark_oak_log
fill 87 299 323 87 300 323 minecraft:stripped_dark_oak_log
fill 87 299 344 87 300 344 minecraft:stripped_dark_oak_log
fill 87 299 346 87 300 346 minecraft:stripped_dark_oak_log
fill 87 299 348 87 300 348 minecraft:stripped_dark_oak_log
fill 88 299 329 88 300 329 minecraft:stripped_dark_oak_log
fill 88 299 336 88 300 336 minecraft:stripped_dark_oak_log
fill 88 299 343 88 300 343 minecraft:stripped_dark_oak_log
fill 88 299 345 88 300 345 minecraft:stripped_dark_oak_log
fill 88 299 347 88 300 347 minecraft:stripped_dark_oak_log
fill 88 299 349 88 300 350 minecraft:stripped_dark_oak_log
fill 88 299 357 88 300 357 minecraft:stripped_dark_oak_log
fill 88 299 363 88 300 363 minecraft:stripped_dark_oak_log
fill 48 300 323 48 300 325 minecraft:stripped_dark_oak_log
setblock 48 300 327 minecraft:stripped_dark_oak_log
fill 48 300 329 48 300 332 minecraft:stripped_dark_oak_log
setblock 48 300 334 minecraft:stripped_dark_oak_log
fill 48 300 336 48 300 339 minecraft:stripped_dark_oak_log
setblock 48 300 341 minecraft:stripped_dark_oak_log
fill 48 300 343 48 300 346 minecraft:stripped_dark_oak_log
setblock 48 300 348 minecraft:stripped_dark_oak_log
fill 48 300 350 48 300 353 minecraft:stripped_dark_oak_log
setblock 48 300 355 minecraft:stripped_dark_oak_log
fill 48 300 357 48 300 360 minecraft:stripped_dark_oak_log
setblock 48 300 362 minecraft:stripped_dark_oak_log
setblock 49 300 323 minecraft:stripped_dark_oak_log
fill 49 300 363 52 300 363 minecraft:stripped_dark_oak_log
setblock 51 300 323 minecraft:stripped_dark_oak_log
fill 53 300 323 56 300 323 minecraft:stripped_dark_oak_log
setblock 54 300 363 minecraft:stripped_dark_oak_log
fill 56 300 363 59 300 363 minecraft:stripped_dark_oak_log
setblock 58 300 323 minecraft:stripped_dark_oak_log
fill 60 300 323 63 300 323 minecraft:stripped_dark_oak_log
setblock 61 300 363 minecraft:stripped_dark_oak_log
fill 70 300 363 73 300 363 minecraft:stripped_dark_oak_log
setblock 75 300 363 minecraft:stripped_dark_oak_log
setblock 83 300 328 minecraft:stripped_dark_oak_log
setblock 84 300 323 minecraft:stripped_dark_oak_log
fill 84 300 327 84 300 337 minecraft:red_concrete
fill 85 300 363 87 300 363 minecraft:stripped_dark_oak_log
setblock 86 300 323 minecraft:stripped_dark_oak_log
fill 88 300 323 88 300 326 minecraft:stripped_dark_oak_log
setblock 88 300 328 minecraft:stripped_dark_oak_log
setblock 88 300 330 minecraft:stripped_dark_oak_log
fill 88 300 331 88 303 333 minecraft:shroomlight
setblock 88 300 335 minecraft:stripped_dark_oak_log
fill 88 300 337 88 300 340 minecraft:stripped_dark_oak_log
setblock 88 300 342 minecraft:stripped_dark_oak_log
fill 88 300 351 88 300 354 minecraft:stripped_dark_oak_log
setblock 88 300 356 minecraft:stripped_dark_oak_log
fill 88 300 358 88 300 361 minecraft:stripped_dark_oak_log
setblock 69 301 364 minecraft:red_concrete
setblock 47 302 353 minecraft:red_concrete
fill 69 302 364 69 308 364 minecraft:dark_oak_planks
fill 47 303 353 47 308 355 minecraft:dark_oak_planks
setblock 47 303 356 minecraft:red_concrete
fill 47 304 356 47 308 356 minecraft:dark_oak_planks
fill 48 304 322 50 308 322 minecraft:dark_oak_planks
setblock 51 304 322 minecraft:red_concrete
setblock 61 304 364 minecraft:red_concrete
setblock 64 304 364 minecraft:red_concrete
fill 51 305 322 51 308 322 minecraft:dark_oak_planks
fill 61 305 364 61 308 364 minecraft:dark_oak_planks
fill 64 305 364 64 308 364 minecraft:dark_oak_planks
setblock 76 308 322 minecraft:dark_oak_planks
setblock 77 308 322 minecraft:red_concrete
setblock 78 308 322 minecraft:dark_oak_planks
