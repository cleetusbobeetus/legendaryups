setblock 236 83 234 minecraft:black_stained_glass
setblock 236 83 236 minecraft:black_stained_glass
setblock 236 83 243 minecraft:pearlescent_froglight
setblock 236 83 245 minecraft:magenta_stained_glass
setblock 236 83 247 minecraft:black_stained_glass
setblock 236 83 249 minecraft:black_stained_glass
setblock 236 83 251 minecraft:black_stained_glass
setblock 236 83 253 minecraft:black_stained_glass
fill 236 83 255 236 84 255 minecraft:gray_concrete
fill 236 83 257 236 84 257 minecraft:gray_concrete
fill 236 83 259 236 84 259 minecraft:gray_concrete
fill 236 83 261 236 84 261 minecraft:cyan_terracotta
setblock 236 83 262 minecraft:pearlescent_froglight
setblock 236 83 264 minecraft:black_stained_glass
setblock 236 83 266 minecraft:magenta_stained_glass
setblock 236 83 268 minecraft:black_stained_glass
setblock 237 83 229 minecraft:cyan_stained_glass
setblock 237 83 237 minecraft:magenta_stained_glass
setblock 237 83 242 minecraft:sea_lantern
fill 237 83 248 237 84 248 minecraft:gray_concrete
fill 237 83 250 237 84 250 minecraft:gray_concrete
fill 237 83 252 237 84 252 minecraft:gray_concrete
fill 237 83 254 237 84 254 minecraft:gray_concrete
setblock 237 83 255 minecraft:pearlescent_froglight
fill 237 83 256 237 84 256 minecraft:gray_concrete
fill 237 83 258 237 84 258 minecraft:gray_concrete
fill 237 83 260 237 84 260 minecraft:gray_concrete
setblock 237 83 261 minecraft:sea_lantern
fill 237 83 262 237 84 262 minecraft:cyan_terracotta
setblock 237 83 269 minecraft:light_blue_stained_glass
fill 238 83 229 238 84 229 minecraft:gray_concrete
fill 238 83 231 238 84 231 minecraft:gray_concrete
fill 238 83 233 238 84 233 minecraft:gray_concrete
fill 238 83 235 238 84 235 minecraft:gray_concrete
fill 238 83 237 238 84 237 minecraft:gray_concrete
fill 238 83 247 238 84 247 minecraft:gray_concrete
fill 238 83 249 238 84 249 minecraft:gray_concrete
fill 238 83 251 238 84 251 minecraft:gray_concrete
fill 238 83 253 238 84 253 minecraft:gray_concrete
fill 238 83 255 238 84 255 minecraft:gray_concrete
fill 238 83 257 238 84 257 minecraft:gray_concrete
fill 238 83 259 238 84 259 minecraft:gray_concrete
fill 238 83 261 238 84 261 minecraft:cyan_terracotta
setblock 239 83 229 minecraft:black_stained_glass
fill 239 83 230 239 84 230 minecraft:gray_concrete
fill 239 83 232 239 84 232 minecraft:gray_concrete
fill 239 83 234 239 84 234 minecraft:gray_concrete
fill 239 83 236 239 84 236 minecraft:gray_concrete
setblock 239 83 237 minecraft:ochre_froglight
setblock 239 83 242 minecraft:magenta_stained_glass
fill 239 83 248 239 84 248 minecraft:gray_concrete
fill 239 83 250 239 84 250 minecraft:gray_concrete
fill 239 83 252 239 84 252 minecraft:gray_concrete
fill 239 83 254 239 84 254 minecraft:gray_concrete
setblock 239 83 255 minecraft:black_stained_glass
fill 239 83 256 239 84 256 minecraft:gray_concrete
fill 239 83 258 239 84 258 minecraft:gray_concrete
fill 239 83 260 239 84 260 minecraft:gray_concrete
setblock 239 83 261 minecraft:magenta_stained_glass
fill 239 83 262 239 84 262 minecraft:cyan_terracotta
setblock 239 83 269 minecraft:black_stained_glass
fill 240 83 229 240 84 229 minecraft:gray_concrete
fill 240 83 231 240 84 231 minecraft:gray_concrete
fill 240 83 233 240 84 233 minecraft:gray_concrete
fill 240 83 235 240 84 235 minecraft:gray_concrete
fill 240 83 237 240 84 237 minecraft:gray_concrete
fill 240 83 247 240 84 247 minecraft:gray_concrete
fill 240 83 249 240 84 249 minecraft:gray_concrete
fill 240 83 251 240 84 251 minecraft:gray_concrete
fill 240 83 253 240 84 253 minecraft:gray_concrete
fill 240 83 255 240 84 255 minecraft:gray_concrete
fill 240 83 257 240 84 257 minecraft:gray_concrete
fill 240 83 259 240 84 259 minecraft:gray_concrete
fill 240 83 261 240 84 261 minecraft:cyan_terracotta
setblock 241 83 229 minecraft:black_stained_glass
fill 241 83 230 241 84 230 minecraft:gray_concrete
fill 241 83 232 241 84 232 minecraft:gray_concrete
fill 241 83 234 241 84 234 minecraft:gray_concrete
fill 241 83 236 241 84 236 minecraft:gray_concrete
setblock 241 83 237 minecraft:black_stained_glass
setblock 241 83 243 minecraft:black_stained_glass
setblock 241 83 245 minecraft:pearlescent_froglight
setblock 241 83 247 minecraft:black_stained_glass
setblock 241 83 249 minecraft:pearlescent_froglight
setblock 241 83 251 minecraft:sea_lantern
fill 241 83 252 241 84 252 minecraft:gray_concrete
setblock 241 83 253 minecraft:sea_lantern
fill 241 83 254 241 84 254 minecraft:gray_concrete
fill 241 83 256 241 84 256 minecraft:gray_concrete
fill 241 83 258 241 84 258 minecraft:gray_concrete
fill 241 83 260 241 84 260 minecraft:gray_concrete
setblock 241 83 261 minecraft:ochre_froglight
fill 241 83 262 241 84 262 minecraft:cyan_terracotta
setblock 241 83 269 minecraft:magenta_stained_glass
fill 242 83 229 242 84 229 minecraft:gray_concrete
fill 242 83 231 242 84 231 minecraft:gray_concrete
fill 242 83 233 242 84 233 minecraft:gray_concrete
fill 242 83 235 242 84 235 minecraft:gray_concrete
fill 242 83 237 242 84 237 minecraft:gray_concrete
fill 242 83 253 242 84 253 minecraft:gray_concrete
fill 242 83 255 242 84 255 minecraft:gray_concrete
fill 242 83 257 242 84 257 minecraft:gray_concrete
fill 242 83 259 242 84 259 minecraft:gray_concrete
fill 242 83 261 242 84 261 minecraft:cyan_terracotta
setblock 243 83 229 minecraft:magenta_stained_glass
fill 243 83 230 243 84 230 minecraft:gray_concrete
fill 243 83 232 243 84 232 minecraft:gray_concrete
fill 243 83 234 243 84 234 minecraft:gray_concrete
fill 243 83 236 243 84 236 minecraft:gray_concrete
setblock 243 83 237 minecraft:pearlescent_froglight
setblock 243 83 261 minecraft:light_blue_stained_glass
setblock 243 83 269 minecraft:black_stained_glass
fill 244 83 229 244 84 229 minecraft:gray_concrete
setblock 244 83 230 minecraft:black_stained_glass
fill 244 83 231 244 84 231 minecraft:gray_concrete
setblock 244 83 232 minecraft:ochre_froglight
fill 244 83 233 244 84 233 minecraft:gray_concrete
setblock 244 83 234 minecraft:sea_lantern
fill 244 83 235 244 84 235 minecraft:gray_concrete
fill 244 83 237 244 84 237 minecraft:gray_concrete
setblock 244 83 262 minecraft:black_stained_glass
setblock 244 83 264 minecraft:magenta_stained_glass
setblock 244 83 266 minecraft:ochre_froglight
setblock 244 83 268 minecraft:black_stained_glass
fill 245 83 230 245 84 230 minecraft:gray_concrete
fill 245 83 232 245 84 232 minecraft:gray_concrete
fill 245 83 234 245 84 234 minecraft:gray_concrete
fill 245 83 236 245 84 236 minecraft:gray_concrete
fill 246 83 229 246 84 229 minecraft:gray_concrete
fill 246 83 231 246 84 231 minecraft:gray_concrete
fill 246 83 233 246 84 233 minecraft:gray_concrete
fill 246 83 235 246 84 235 minecraft:gray_concrete
fill 246 83 237 246 84 237 minecraft:gray_concrete
fill 247 83 230 247 84 230 minecraft:gray_concrete
fill 247 83 232 247 84 232 minecraft:gray_concrete
fill 247 83 234 247 84 234 minecraft:gray_concrete
fill 247 83 236 247 84 236 minecraft:gray_concrete
fill 248 83 229 248 84 229 minecraft:gray_concrete
fill 248 83 231 248 84 231 minecraft:gray_concrete
fill 248 83 233 248 84 233 minecraft:gray_concrete
fill 248 83 235 248 84 235 minecraft:gray_concrete
fill 248 83 237 248 84 237 minecraft:gray_concrete
setblock 249 83 230 minecraft:light_blue_stained_glass
setblock 249 83 232 minecraft:light_blue_stained_glass
setblock 249 83 265 minecraft:black_stained_glass
setblock 249 83 267 minecraft:ochre_froglight
setblock 250 83 229 minecraft:light_blue_stained_glass
setblock 250 83 234 minecraft:ochre_froglight
setblock 250 83 264 minecraft:black_stained_glass
setblock 250 83 269 minecraft:cyan_stained_glass
setblock 252 83 229 minecraft:sea_lantern
setblock 252 83 234 minecraft:black_stained_glass
setblock 252 83 264 minecraft:sea_lantern
setblock 252 83 269 minecraft:cyan_stained_glass
setblock 254 83 229 minecraft:magenta_stained_glass
setblock 254 83 234 minecraft:cyan_stained_glass
setblock 254 83 264 minecraft:pearlescent_froglight
setblock 254 83 269 minecraft:black_stained_glass
fill 255 83 270 255 180 270 minecraft:black_concrete
setblock 256 83 229 minecraft:magenta_stained_glass
setblock 256 83 234 minecraft:pearlescent_froglight
setblock 256 83 264 minecraft:black_stained_glass
setblock 256 83 269 minecraft:light_blue_stained_glass
setblock 256 83 270 minecraft:pearlescent_froglight
fill 257 83 270 257 85 270 minecraft:black_concrete
setblock 258 83 229 minecraft:pearlescent_froglight
setblock 258 83 234 minecraft:black_stained_glass
setblock 258 83 264 minecraft:black_stained_glass
setblock 258 83 269 minecraft:sea_lantern
setblock 260 83 229 minecraft:black_stained_glass
setblock 260 83 234 minecraft:cyan_stained_glass
setblock 260 83 264 minecraft:black_stained_glass
setblock 260 83 269 minecraft:black_stained_glass
setblock 262 83 230 minecraft:light_blue_stained_glass
setblock 262 83 232 minecraft:black_stained_glass
setblock 262 83 265 minecraft:black_stained_glass
setblock 262 83 267 minecraft:black_stained_glass
fill 266 83 229 266 84 229 minecraft:gray_concrete
fill 266 83 231 266 84 231 minecraft:gray_concrete
fill 266 83 233 266 84 233 minecraft:gray_concrete
fill 266 83 235 266 84 235 minecraft:gray_concrete
fill 266 83 237 266 84 237 minecraft:gray_concrete
fill 266 83 239 266 84 239 minecraft:gray_concrete
fill 266 83 259 266 84 259 minecraft:gray_concrete
fill 266 83 261 266 84 261 minecraft:gray_concrete
fill 266 83 263 266 84 263 minecraft:gray_concrete
fill 266 83 265 266 84 265 minecraft:gray_concrete
fill 266 83 267 266 84 267 minecraft:gray_concrete
fill 266 83 269 266 84 269 minecraft:gray_concrete
fill 267 83 230 267 84 230 minecraft:gray_concrete
fill 267 83 232 267 84 232 minecraft:gray_concrete
fill 267 83 234 267 84 234 minecraft:gray_concrete
fill 267 83 236 267 84 236 minecraft:gray_concrete
fill 267 83 238 267 84 238 minecraft:gray_concrete
fill 267 83 260 267 84 260 minecraft:gray_concrete
fill 267 83 262 267 84 262 minecraft:gray_concrete
fill 267 83 264 267 84 264 minecraft:gray_concrete
fill 267 83 266 267 84 266 minecraft:gray_concrete
fill 267 83 268 267 84 268 minecraft:gray_concrete
fill 268 83 229 268 84 229 minecraft:cyan_terracotta
setblock 268 83 230 minecraft:black_stained_glass
fill 268 83 231 268 84 231 minecraft:cyan_terracotta
setblock 268 83 232 minecraft:black_stained_glass
fill 268 83 233 268 84 233 minecraft:cyan_terracotta
setblock 268 83 234 minecraft:black_stained_glass
fill 268 83 235 268 84 235 minecraft:cyan_terracotta
setblock 268 83 236 minecraft:black_stained_glass
fill 268 83 237 268 84 237 minecraft:cyan_terracotta
fill 268 83 239 268 84 239 minecraft:gray_concrete
fill 268 83 259 268 84 259 minecraft:gray_concrete
fill 268 83 261 268 84 261 minecraft:gray_concrete
setblock 268 83 262 minecraft:black_stained_glass
fill 268 83 263 268 84 263 minecraft:gray_concrete
setblock 268 83 264 minecraft:ochre_froglight
fill 268 83 265 268 84 265 minecraft:gray_concrete
setblock 268 83 266 minecraft:magenta_stained_glass
fill 268 83 267 268 84 267 minecraft:gray_concrete
setblock 268 83 268 minecraft:black_stained_glass
fill 268 83 269 268 84 269 minecraft:gray_concrete
setblock 269 83 229 minecraft:black_stained_glass
fill 269 83 230 269 84 230 minecraft:cyan_terracotta
fill 269 83 232 269 84 232 minecraft:cyan_terracotta
fill 269 83 234 269 84 234 minecraft:cyan_terracotta
fill 269 83 236 269 84 236 minecraft:cyan_terracotta
setblock 269 83 237 minecraft:black_stained_glass
fill 269 83 238 269 84 238 minecraft:gray_concrete
fill 269 83 260 269 84 260 minecraft:gray_concrete
setblock 269 83 261 minecraft:black_stained_glass
fill 269 83 262 269 84 262 minecraft:gray_concrete
fill 269 83 264 269 84 264 minecraft:gray_concrete
fill 269 83 266 269 84 266 minecraft:gray_concrete
fill 269 83 268 269 84 268 minecraft:gray_concrete
setblock 269 83 269 minecraft:pearlescent_froglight
fill 270 83 229 270 84 229 minecraft:cyan_terracotta
fill 270 83 231 270 84 231 minecraft:cyan_terracotta
fill 270 83 233 270 84 233 minecraft:cyan_terracotta
fill 270 83 235 270 84 235 minecraft:cyan_terracotta
fill 270 83 237 270 84 237 minecraft:cyan_terracotta
fill 270 83 239 270 84 239 minecraft:gray_concrete
fill 270 83 259 270 84 259 minecraft:gray_concrete
fill 270 83 261 270 84 261 minecraft:gray_concrete
fill 270 83 263 270 84 263 minecraft:gray_concrete
fill 270 83 265 270 84 265 minecraft:gray_concrete
fill 270 83 267 270 84 267 minecraft:gray_concrete
fill 270 83 269 270 84 269 minecraft:gray_concrete
fill 271 83 228 271 102 228 minecraft:black_concrete
setblock 271 83 229 minecraft:cyan_stained_glass
fill 271 83 230 271 84 230 minecraft:cyan_terracotta
fill 271 83 232 271 84 232 minecraft:cyan_terracotta
fill 271 83 234 271 84 234 minecraft:cyan_terracotta
fill 271 83 236 271 84 236 minecraft:cyan_terracotta
setblock 271 83 237 minecraft:black_stained_glass
fill 271 83 238 271 84 238 minecraft:gray_concrete
setblock 271 83 243 minecraft:cyan_stained_glass
setblock 271 83 245 minecraft:cyan_stained_glass
setblock 271 83 247 minecraft:cyan_stained_glass
setblock 271 83 249 minecraft:ochre_froglight
setblock 271 83 251 minecraft:black_stained_glass
setblock 271 83 253 minecraft:black_stained_glass
fill 271 83 260 271 84 260 minecraft:gray_concrete
setblock 271 83 261 minecraft:sea_lantern
fill 271 83 262 271 84 262 minecraft:gray_concrete
fill 271 83 264 271 84 264 minecraft:gray_concrete
fill 271 83 266 271 84 266 minecraft:gray_concrete
fill 271 83 268 271 84 268 minecraft:gray_concrete
setblock 271 83 269 minecraft:cyan_stained_glass
setblock 271 83 270 minecraft:purple_concrete
fill 272 83 229 272 84 229 minecraft:cyan_terracotta
fill 272 83 231 272 84 231 minecraft:cyan_terracotta
fill 272 83 233 272 84 233 minecraft:cyan_terracotta
fill 272 83 235 272 84 235 minecraft:cyan_terracotta
fill 272 83 237 272 84 237 minecraft:cyan_terracotta
fill 272 83 239 272 84 239 minecraft:gray_concrete
setblock 272 83 242 minecraft:magenta_stained_glass
setblock 272 83 255 minecraft:black_stained_glass
fill 272 83 259 272 84 259 minecraft:gray_concrete
fill 272 83 261 272 84 261 minecraft:gray_concrete
fill 272 83 263 272 84 263 minecraft:gray_concrete
fill 272 83 265 272 84 265 minecraft:gray_concrete
fill 272 83 267 272 84 267 minecraft:gray_concrete
fill 272 83 269 272 84 269 minecraft:gray_concrete
fill 272 83 270 273 131 270 minecraft:black_concrete
setblock 273 83 229 minecraft:black_stained_glass
fill 273 83 230 273 84 230 minecraft:cyan_terracotta
fill 273 83 232 273 84 232 minecraft:cyan_terracotta
fill 273 83 234 273 84 234 minecraft:cyan_terracotta
fill 273 83 236 273 84 236 minecraft:cyan_terracotta
setblock 273 83 237 minecraft:black_stained_glass
fill 273 83 238 273 84 238 minecraft:gray_concrete
fill 273 83 260 273 84 260 minecraft:gray_concrete
setblock 273 83 261 minecraft:pearlescent_froglight
fill 273 83 262 273 84 262 minecraft:gray_concrete
fill 273 83 264 273 84 264 minecraft:gray_concrete
fill 273 83 266 273 84 266 minecraft:gray_concrete
fill 273 83 268 273 84 268 minecraft:gray_concrete
setblock 273 83 269 minecraft:cyan_stained_glass
fill 274 83 229 274 84 229 minecraft:cyan_terracotta
fill 274 83 231 274 84 231 minecraft:cyan_terracotta
fill 274 83 233 274 84 233 minecraft:cyan_terracotta
fill 274 83 235 274 84 235 minecraft:cyan_terracotta
fill 274 83 237 274 84 237 minecraft:cyan_terracotta
fill 274 83 239 274 84 239 minecraft:gray_concrete
setblock 274 83 242 minecraft:ochre_froglight
setblock 274 83 255 minecraft:magenta_stained_glass
fill 274 83 259 274 84 259 minecraft:gray_concrete
fill 274 83 261 274 84 261 minecraft:gray_concrete
fill 274 83 263 274 84 263 minecraft:gray_concrete
fill 274 83 265 274 84 265 minecraft:gray_concrete
fill 274 83 267 274 84 267 minecraft:gray_concrete
fill 274 83 269 274 84 269 minecraft:gray_concrete
setblock 275 83 229 minecraft:cyan_stained_glass
fill 275 83 230 275 84 230 minecraft:cyan_terracotta
fill 275 83 232 275 84 232 minecraft:cyan_terracotta
fill 275 83 234 275 84 234 minecraft:cyan_terracotta
fill 275 83 236 275 84 236 minecraft:cyan_terracotta
setblock 275 83 237 minecraft:pearlescent_froglight
fill 275 83 238 275 84 238 minecraft:gray_concrete
fill 275 83 260 275 84 260 minecraft:gray_concrete
setblock 275 83 261 minecraft:cyan_stained_glass
fill 275 83 262 275 84 262 minecraft:gray_concrete
fill 275 83 264 275 84 264 minecraft:gray_concrete
fill 275 83 266 275 84 266 minecraft:gray_concrete
fill 275 83 268 275 84 268 minecraft:gray_concrete
setblock 275 83 269 minecraft:sea_lantern
setblock 276 83 228 minecraft:magenta_concrete
fill 276 83 229 276 84 229 minecraft:cyan_terracotta
setblock 276 83 230 minecraft:black_stained_glass
fill 276 83 231 276 84 231 minecraft:cyan_terracotta
setblock 276 83 232 minecraft:black_stained_glass
fill 276 83 233 276 84 233 minecraft:cyan_terracotta
setblock 276 83 234 minecraft:sea_lantern
fill 276 83 235 276 84 235 minecraft:cyan_terracotta
setblock 276 83 236 minecraft:black_stained_glass
fill 276 83 237 276 84 237 minecraft:cyan_terracotta
fill 276 83 239 276 84 239 minecraft:gray_concrete
setblock 276 83 243 minecraft:light_blue_stained_glass
setblock 276 83 245 minecraft:black_stained_glass
setblock 276 83 247 minecraft:ochre_froglight
setblock 276 83 249 minecraft:black_stained_glass
setblock 276 83 251 minecraft:ochre_froglight
setblock 276 83 253 minecraft:magenta_stained_glass
fill 276 83 259 276 84 259 minecraft:gray_concrete
fill 276 83 261 276 84 261 minecraft:gray_concrete
fill 276 83 263 276 84 263 minecraft:gray_concrete
setblock 276 83 264 minecraft:black_stained_glass
fill 276 83 265 276 84 265 minecraft:gray_concrete
setblock 276 83 266 minecraft:cyan_stained_glass
fill 276 83 267 276 84 267 minecraft:gray_concrete
setblock 276 83 268 minecraft:magenta_stained_glass
fill 276 83 269 276 84 269 minecraft:gray_concrete
fill 277 83 260 277 102 260 minecraft:black_concrete
fill 235 84 231 235 103 231 minecraft:black_concrete
setblock 235 84 247 minecraft:ochre_froglight
fill 235 84 248 235 91 252 minecraft:black_concrete
fill 236 84 230 236 85 230 minecraft:light_gray_concrete
fill 236 84 232 236 85 232 minecraft:light_gray_concrete
fill 236 84 234 236 85 234 minecraft:light_gray_concrete
fill 236 84 236 236 85 236 minecraft:light_gray_concrete
fill 236 84 243 236 85 243 minecraft:light_gray_concrete
fill 236 84 245 236 85 245 minecraft:light_gray_concrete
setblock 236 84 247 minecraft:gray_concrete
setblock 236 84 249 minecraft:gray_concrete
setblock 236 84 251 minecraft:gray_concrete
setblock 236 84 253 minecraft:gray_concrete
fill 236 84 262 236 85 262 minecraft:cyan_terracotta
fill 236 84 264 236 85 264 minecraft:cyan_terracotta
fill 236 84 266 236 85 266 minecraft:cyan_terracotta
fill 236 84 268 236 85 268 minecraft:cyan_terracotta
fill 237 84 229 237 85 229 minecraft:light_gray_concrete
fill 237 84 237 237 85 237 minecraft:light_gray_concrete
fill 237 84 242 237 85 242 minecraft:light_gray_concrete
fill 237 84 245 237 95 245 minecraft:cyan_wool
fill 237 84 255 237 85 255 minecraft:gray_concrete
fill 237 84 261 237 85 261 minecraft:cyan_terracotta
fill 237 84 269 237 85 269 minecraft:cyan_terracotta
fill 238 84 245 241 85 245 minecraft:light_gray_concrete
fill 239 84 229 239 85 229 minecraft:gray_concrete
fill 239 84 237 239 85 237 minecraft:gray_concrete
fill 239 84 242 239 85 242 minecraft:light_gray_concrete
fill 239 84 255 239 88 255 minecraft:gray_concrete
fill 239 84 261 239 85 261 minecraft:cyan_terracotta
fill 239 84 269 239 85 269 minecraft:cyan_terracotta
fill 241 84 229 241 88 229 minecraft:gray_concrete
fill 241 84 237 241 85 237 minecraft:gray_concrete
fill 241 84 243 241 85 243 minecraft:light_gray_concrete
fill 241 84 247 241 85 247 minecraft:light_gray_concrete
fill 241 84 249 241 85 249 minecraft:light_gray_concrete
fill 241 84 251 241 85 251 minecraft:light_gray_concrete
fill 241 84 253 241 88 253 minecraft:gray_concrete
fill 241 84 261 241 85 261 minecraft:cyan_terracotta
fill 241 84 269 241 85 269 minecraft:cyan_terracotta
fill 243 84 229 243 85 229 minecraft:gray_concrete
fill 243 84 237 243 85 237 minecraft:gray_concrete
fill 243 84 261 243 85 261 minecraft:cyan_terracotta
fill 243 84 269 243 85 269 minecraft:cyan_terracotta
fill 244 84 230 244 88 230 minecraft:gray_concrete
fill 244 84 232 244 85 232 minecraft:gray_concrete
fill 244 84 234 244 85 234 minecraft:gray_concrete
fill 244 84 262 244 85 262 minecraft:cyan_terracotta
fill 244 84 264 244 85 264 minecraft:cyan_terracotta
fill 244 84 266 244 85 266 minecraft:cyan_terracotta
fill 244 84 268 244 85 268 minecraft:cyan_terracotta
fill 249 84 230 249 85 230 minecraft:light_gray_concrete
fill 249 84 232 249 85 232 minecraft:light_gray_concrete
fill 249 84 265 249 85 265 minecraft:cyan_terracotta
fill 249 84 267 249 85 267 minecraft:cyan_terracotta
fill 250 84 228 250 138 228 minecraft:black_concrete
fill 250 84 229 250 85 229 minecraft:light_gray_concrete
fill 250 84 234 250 85 234 minecraft:light_gray_concrete
fill 250 84 264 250 85 264 minecraft:cyan_terracotta
fill 250 84 269 250 85 269 minecraft:cyan_terracotta
setblock 251 84 228 minecraft:magenta_concrete
fill 252 84 228 252 249 228 minecraft:black_concrete
fill 252 84 229 252 85 229 minecraft:light_gray_concrete
fill 252 84 234 252 85 234 minecraft:light_gray_concrete
fill 252 84 264 252 85 264 minecraft:cyan_terracotta
fill 252 84 269 252 85 269 minecraft:cyan_terracotta
fill 254 84 229 254 85 229 minecraft:light_gray_concrete
fill 254 84 234 254 85 234 minecraft:light_gray_concrete
fill 254 84 264 254 85 264 minecraft:cyan_terracotta
fill 254 84 269 254 85 269 minecraft:cyan_terracotta
fill 256 84 229 256 85 229 minecraft:light_gray_concrete
fill 256 84 234 256 85 234 minecraft:light_gray_concrete
fill 256 84 264 256 85 264 minecraft:cyan_terracotta
fill 256 84 269 256 85 269 minecraft:cyan_terracotta
fill 256 84 270 256 128 270 minecraft:black_concrete
fill 258 84 229 258 85 229 minecraft:light_gray_concrete
fill 258 84 234 258 85 234 minecraft:light_gray_concrete
fill 258 84 264 258 85 264 minecraft:cyan_terracotta
fill 258 84 269 258 85 269 minecraft:cyan_terracotta
fill 260 84 229 260 85 229 minecraft:light_gray_concrete
fill 260 84 234 260 85 234 minecraft:light_gray_concrete
fill 260 84 264 260 85 264 minecraft:cyan_terracotta
fill 260 84 269 260 85 269 minecraft:cyan_terracotta
fill 262 84 230 262 85 230 minecraft:light_gray_concrete
fill 262 84 232 262 85 232 minecraft:light_gray_concrete
fill 262 84 265 262 85 265 minecraft:cyan_terracotta
fill 262 84 267 262 85 267 minecraft:cyan_terracotta
fill 268 84 230 268 85 230 minecraft:cyan_terracotta
fill 268 84 232 268 85 232 minecraft:cyan_terracotta
fill 268 84 234 268 85 234 minecraft:cyan_terracotta
fill 268 84 236 268 85 236 minecraft:cyan_terracotta
fill 268 84 262 268 85 262 minecraft:gray_concrete
fill 268 84 264 268 85 264 minecraft:gray_concrete
fill 268 84 266 268 85 266 minecraft:gray_concrete
fill 268 84 268 268 85 268 minecraft:gray_concrete
fill 269 84 229 269 85 229 minecraft:cyan_terracotta
fill 269 84 237 269 85 237 minecraft:cyan_terracotta
fill 269 84 261 269 85 261 minecraft:gray_concrete
fill 269 84 269 269 85 269 minecraft:gray_concrete
fill 271 84 229 271 85 229 minecraft:cyan_terracotta
fill 271 84 237 271 85 237 minecraft:cyan_terracotta
fill 271 84 243 271 85 243 minecraft:light_gray_concrete
fill 271 84 245 271 85 245 minecraft:light_gray_concrete
fill 271 84 247 271 85 247 minecraft:light_gray_concrete
fill 271 84 249 271 85 249 minecraft:light_gray_concrete
fill 271 84 251 271 85 251 minecraft:light_gray_concrete
fill 271 84 253 271 85 253 minecraft:light_gray_concrete
fill 271 84 261 271 85 261 minecraft:gray_concrete
fill 271 84 269 271 85 269 minecraft:gray_concrete
fill 271 84 270 271 160 270 minecraft:black_concrete
fill 272 84 242 272 85 242 minecraft:light_gray_concrete
fill 272 84 255 272 85 255 minecraft:light_gray_concrete
fill 273 84 229 273 85 229 minecraft:cyan_terracotta
fill 273 84 237 273 85 237 minecraft:cyan_terracotta
fill 273 84 261 273 85 261 minecraft:gray_concrete
fill 273 84 269 273 85 269 minecraft:gray_concrete
fill 274 84 242 274 85 242 minecraft:light_gray_concrete
fill 274 84 255 274 85 255 minecraft:light_gray_concrete
fill 275 84 229 275 85 229 minecraft:cyan_terracotta
fill 275 84 237 275 85 237 minecraft:cyan_terracotta
fill 275 84 261 275 85 261 minecraft:gray_concrete
fill 275 84 269 275 85 269 minecraft:gray_concrete
fill 276 84 228 276 93 228 minecraft:black_concrete
fill 276 84 230 276 85 230 minecraft:cyan_terracotta
fill 276 84 232 276 85 232 minecraft:cyan_terracotta
fill 276 84 234 276 85 234 minecraft:cyan_terracotta
fill 276 84 236 276 85 236 minecraft:cyan_terracotta
fill 276 84 243 276 85 243 minecraft:light_gray_concrete
fill 276 84 245 276 85 245 minecraft:light_gray_concrete
fill 276 84 247 276 85 247 minecraft:light_gray_concrete
fill 276 84 249 276 85 249 minecraft:light_gray_concrete
fill 276 84 251 276 85 251 minecraft:light_gray_concrete
fill 276 84 253 276 85 253 minecraft:light_gray_concrete
fill 276 84 264 276 85 264 minecraft:gray_concrete
fill 276 84 266 276 85 266 minecraft:gray_concrete
fill 276 84 268 276 85 268 minecraft:gray_concrete
fill 277 84 243 277 113 244 minecraft:black_concrete
setblock 277 84 245 minecraft:blue_concrete
fill 277 84 246 277 203 246 minecraft:black_concrete
fill 235 85 247 235 120 247 minecraft:black_concrete
fill 236 85 244 236 183 244 minecraft:light_gray_concrete
fill 236 85 246 236 183 246 minecraft:light_gray_concrete
fill 236 85 247 236 86 247 minecraft:sea_lantern
setblock 236 85 249 minecraft:sea_lantern
setblock 236 85 251 minecraft:sea_lantern
setblock 236 85 253 minecraft:sea_lantern
setblock 236 85 255 minecraft:sea_lantern
setblock 236 85 257 minecraft:sea_lantern
setblock 236 85 259 minecraft:sea_lantern
setblock 236 85 261 minecraft:sea_lantern
fill 237 85 243 237 95 244 minecraft:cyan_wool
fill 237 85 246 237 95 246 minecraft:cyan_wool
setblock 237 85 248 minecraft:sea_lantern
setblock 237 85 250 minecraft:sea_lantern
setblock 237 85 252 minecraft:sea_lantern
setblock 237 85 254 minecraft:sea_lantern
setblock 237 85 256 minecraft:sea_lantern
setblock 237 85 258 minecraft:sea_lantern
setblock 237 85 260 minecraft:sea_lantern
setblock 237 85 262 minecraft:sea_lantern
setblock 238 85 229 minecraft:sea_lantern
setblock 238 85 231 minecraft:sea_lantern
setblock 238 85 233 minecraft:sea_lantern
setblock 238 85 235 minecraft:sea_lantern
setblock 238 85 237 minecraft:sea_lantern
setblock 238 85 238 minecraft:light[level=12]
fill 238 85 243 240 170 244 minecraft:light_gray_concrete
fill 238 85 246 241 170 246 minecraft:light_gray_concrete
setblock 238 85 247 minecraft:sea_lantern
setblock 238 85 249 minecraft:sea_lantern
setblock 238 85 251 minecraft:sea_lantern
setblock 238 85 253 minecraft:sea_lantern
setblock 238 85 255 minecraft:sea_lantern
setblock 238 85 257 minecraft:sea_lantern
setblock 238 85 259 minecraft:sea_lantern
setblock 238 85 261 minecraft:sea_lantern
setblock 239 85 230 minecraft:sea_lantern
setblock 239 85 232 minecraft:sea_lantern
setblock 239 85 234 minecraft:sea_lantern
setblock 239 85 236 minecraft:sea_lantern
setblock 239 85 248 minecraft:sea_lantern
setblock 239 85 250 minecraft:sea_lantern
setblock 239 85 252 minecraft:sea_lantern
setblock 239 85 254 minecraft:sea_lantern
setblock 239 85 256 minecraft:sea_lantern
setblock 239 85 258 minecraft:sea_lantern
setblock 239 85 260 minecraft:sea_lantern
setblock 239 85 262 minecraft:sea_lantern
setblock 240 85 229 minecraft:sea_lantern
setblock 240 85 231 minecraft:sea_lantern
setblock 240 85 233 minecraft:sea_lantern
setblock 240 85 235 minecraft:sea_lantern
setblock 240 85 237 minecraft:sea_lantern
setblock 240 85 247 minecraft:sea_lantern
setblock 240 85 249 minecraft:sea_lantern
setblock 240 85 251 minecraft:sea_lantern
setblock 240 85 253 minecraft:sea_lantern
setblock 240 85 255 minecraft:sea_lantern
setblock 240 85 257 minecraft:sea_lantern
setblock 240 85 259 minecraft:sea_lantern
setblock 240 85 261 minecraft:sea_lantern
setblock 241 85 230 minecraft:sea_lantern
setblock 241 85 232 minecraft:sea_lantern
setblock 241 85 234 minecraft:sea_lantern
setblock 241 85 236 minecraft:sea_lantern
fill 241 85 244 241 183 244 minecraft:light_gray_concrete
setblock 241 85 252 minecraft:sea_lantern
setblock 241 85 254 minecraft:sea_lantern
setblock 241 85 256 minecraft:sea_lantern
setblock 241 85 258 minecraft:sea_lantern
setblock 241 85 260 minecraft:sea_lantern
setblock 241 85 262 minecraft:sea_lantern
setblock 242 85 229 minecraft:sea_lantern
setblock 242 85 231 minecraft:sea_lantern
setblock 242 85 233 minecraft:sea_lantern
setblock 242 85 235 minecraft:sea_lantern
setblock 242 85 237 minecraft:sea_lantern
setblock 242 85 253 minecraft:sea_lantern
setblock 242 85 255 minecraft:sea_lantern
setblock 242 85 257 minecraft:sea_lantern
setblock 242 85 259 minecraft:sea_lantern
setblock 242 85 261 minecraft:sea_lantern
setblock 243 85 228 minecraft:blue_concrete
setblock 243 85 230 minecraft:sea_lantern
setblock 243 85 232 minecraft:sea_lantern
setblock 243 85 234 minecraft:sea_lantern
setblock 243 85 236 minecraft:sea_lantern
setblock 244 85 229 minecraft:sea_lantern
setblock 244 85 231 minecraft:sea_lantern
setblock 244 85 233 minecraft:sea_lantern
setblock 244 85 235 minecraft:sea_lantern
setblock 244 85 237 minecraft:sea_lantern
setblock 245 85 230 minecraft:sea_lantern
setblock 245 85 232 minecraft:sea_lantern
setblock 245 85 234 minecraft:sea_lantern
setblock 245 85 236 minecraft:sea_lantern
setblock 245 85 238 minecraft:light[level=12]
setblock 245 85 245 minecraft:light[level=12]
setblock 245 85 252 minecraft:light[level=12]
setblock 245 85 259 minecraft:light[level=12]
setblock 245 85 266 minecraft:light[level=12]
setblock 246 85 229 minecraft:sea_lantern
setblock 246 85 231 minecraft:sea_lantern
setblock 246 85 233 minecraft:sea_lantern
setblock 246 85 235 minecraft:sea_lantern
setblock 246 85 237 minecraft:sea_lantern
setblock 247 85 230 minecraft:sea_lantern
setblock 247 85 232 minecraft:sea_lantern
setblock 247 85 234 minecraft:sea_lantern
setblock 247 85 236 minecraft:sea_lantern
setblock 248 85 229 minecraft:sea_lantern
setblock 248 85 231 minecraft:sea_lantern
setblock 248 85 233 minecraft:sea_lantern
setblock 248 85 235 minecraft:sea_lantern
setblock 248 85 237 minecraft:sea_lantern
fill 251 85 228 251 123 228 minecraft:black_concrete
setblock 252 85 238 minecraft:light[level=12]
setblock 252 85 245 minecraft:light[level=12]
setblock 252 85 252 minecraft:light[level=12]
setblock 252 85 259 minecraft:light[level=12]
setblock 259 85 238 minecraft:light[level=12]
setblock 259 85 245 minecraft:light[level=12]
setblock 259 85 252 minecraft:light[level=12]
setblock 259 85 259 minecraft:light[level=12]
fill 259 85 270 259 129 270 minecraft:black_concrete
setblock 260 85 270 minecraft:pearlescent_froglight
fill 261 85 270 262 113 270 minecraft:black_concrete
setblock 266 85 229 minecraft:sea_lantern
setblock 266 85 231 minecraft:sea_lantern
setblock 266 85 233 minecraft:sea_lantern
setblock 266 85 235 minecraft:sea_lantern
setblock 266 85 237 minecraft:sea_lantern
setblock 266 85 239 minecraft:sea_lantern
setblock 266 85 245 minecraft:light[level=12]
setblock 266 85 252 minecraft:light[level=12]
setblock 266 85 259 minecraft:sea_lantern
setblock 266 85 261 minecraft:sea_lantern
setblock 266 85 263 minecraft:sea_lantern
setblock 266 85 265 minecraft:sea_lantern
setblock 266 85 267 minecraft:sea_lantern
setblock 266 85 269 minecraft:sea_lantern
setblock 267 85 230 minecraft:sea_lantern
setblock 267 85 232 minecraft:sea_lantern
setblock 267 85 234 minecraft:sea_lantern
setblock 267 85 236 minecraft:sea_lantern
setblock 267 85 238 minecraft:sea_lantern
setblock 267 85 260 minecraft:sea_lantern
setblock 267 85 262 minecraft:sea_lantern
setblock 267 85 264 minecraft:sea_lantern
setblock 267 85 266 minecraft:sea_lantern
setblock 267 85 268 minecraft:sea_lantern
setblock 268 85 229 minecraft:sea_lantern
setblock 268 85 231 minecraft:sea_lantern
setblock 268 85 233 minecraft:sea_lantern
setblock 268 85 235 minecraft:sea_lantern
setblock 268 85 237 minecraft:sea_lantern
setblock 268 85 239 minecraft:sea_lantern
setblock 268 85 259 minecraft:sea_lantern
setblock 268 85 261 minecraft:sea_lantern
setblock 268 85 263 minecraft:sea_lantern
setblock 268 85 265 minecraft:sea_lantern
setblock 268 85 267 minecraft:sea_lantern
setblock 268 85 269 minecraft:sea_lantern
setblock 269 85 230 minecraft:sea_lantern
setblock 269 85 232 minecraft:sea_lantern
setblock 269 85 234 minecraft:sea_lantern
setblock 269 85 236 minecraft:sea_lantern
setblock 269 85 238 minecraft:sea_lantern
setblock 269 85 260 minecraft:sea_lantern
setblock 269 85 262 minecraft:sea_lantern
setblock 269 85 264 minecraft:sea_lantern
setblock 269 85 266 minecraft:sea_lantern
setblock 269 85 268 minecraft:sea_lantern
setblock 270 85 229 minecraft:sea_lantern
setblock 270 85 231 minecraft:sea_lantern
setblock 270 85 233 minecraft:sea_lantern
setblock 270 85 235 minecraft:sea_lantern
setblock 270 85 237 minecraft:sea_lantern
setblock 270 85 239 minecraft:sea_lantern
setblock 270 85 259 minecraft:sea_lantern
setblock 270 85 261 minecraft:sea_lantern
setblock 270 85 263 minecraft:sea_lantern
setblock 270 85 265 minecraft:sea_lantern
setblock 270 85 267 minecraft:sea_lantern
setblock 270 85 269 minecraft:sea_lantern
setblock 271 85 230 minecraft:sea_lantern
setblock 271 85 232 minecraft:sea_lantern
setblock 271 85 234 minecraft:sea_lantern
setblock 271 85 236 minecraft:sea_lantern
setblock 271 85 238 minecraft:sea_lantern
setblock 271 85 260 minecraft:sea_lantern
setblock 271 85 262 minecraft:sea_lantern
setblock 271 85 264 minecraft:sea_lantern
setblock 271 85 266 minecraft:sea_lantern
setblock 271 85 268 minecraft:sea_lantern
setblock 272 85 229 minecraft:sea_lantern
setblock 272 85 231 minecraft:sea_lantern
setblock 272 85 233 minecraft:sea_lantern
setblock 272 85 235 minecraft:sea_lantern
setblock 272 85 237 minecraft:sea_lantern
setblock 272 85 239 minecraft:sea_lantern
setblock 272 85 259 minecraft:sea_lantern
setblock 272 85 261 minecraft:sea_lantern
setblock 272 85 263 minecraft:sea_lantern
setblock 272 85 265 minecraft:sea_lantern
setblock 272 85 267 minecraft:sea_lantern
setblock 272 85 269 minecraft:sea_lantern
setblock 273 85 230 minecraft:sea_lantern
setblock 273 85 232 minecraft:sea_lantern
setblock 273 85 234 minecraft:sea_lantern
setblock 273 85 236 minecraft:sea_lantern
setblock 273 85 238 minecraft:sea_lantern
setblock 273 85 260 minecraft:sea_lantern
setblock 273 85 262 minecraft:sea_lantern
setblock 273 85 264 minecraft:sea_lantern
setblock 273 85 266 minecraft:sea_lantern
setblock 273 85 268 minecraft:sea_lantern
setblock 274 85 229 minecraft:sea_lantern
setblock 274 85 231 minecraft:sea_lantern
setblock 274 85 233 minecraft:sea_lantern
setblock 274 85 235 minecraft:sea_lantern
setblock 274 85 237 minecraft:sea_lantern
setblock 274 85 239 minecraft:sea_lantern
setblock 274 85 259 minecraft:sea_lantern
setblock 274 85 261 minecraft:sea_lantern
setblock 274 85 263 minecraft:sea_lantern
setblock 274 85 265 minecraft:sea_lantern
setblock 274 85 267 minecraft:sea_lantern
setblock 274 85 269 minecraft:sea_lantern
setblock 275 85 230 minecraft:sea_lantern
setblock 275 85 232 minecraft:sea_lantern
setblock 275 85 234 minecraft:sea_lantern
setblock 275 85 236 minecraft:sea_lantern
setblock 275 85 238 minecraft:sea_lantern
setblock 275 85 260 minecraft:sea_lantern
setblock 275 85 262 minecraft:sea_lantern
setblock 275 85 264 minecraft:sea_lantern
setblock 275 85 266 minecraft:sea_lantern
setblock 275 85 268 minecraft:sea_lantern
setblock 276 85 229 minecraft:sea_lantern
setblock 276 85 231 minecraft:sea_lantern
setblock 276 85 233 minecraft:sea_lantern
setblock 276 85 235 minecraft:sea_lantern
setblock 276 85 237 minecraft:sea_lantern
setblock 276 85 239 minecraft:sea_lantern
setblock 276 85 259 minecraft:sea_lantern
setblock 276 85 261 minecraft:sea_lantern
setblock 276 85 263 minecraft:sea_lantern
setblock 276 85 265 minecraft:sea_lantern
setblock 276 85 267 minecraft:sea_lantern
setblock 276 85 269 minecraft:sea_lantern
fill 277 85 245 277 102 245 minecraft:black_concrete
fill 235 86 236 235 97 239 minecraft:black_concrete
setblock 235 86 240 minecraft:blue_concrete
fill 235 86 241 235 124 241 minecraft:black_concrete
fill 235 86 264 235 122 265 minecraft:black_concrete
setblock 235 86 266 minecraft:purple_concrete
fill 235 86 267 235 102 267 minecraft:black_concrete
setblock 235 86 268 minecraft:cyan_concrete
fill 235 86 269 235 144 270 minecraft:black_concrete
setblock 236 86 230 minecraft:black_stained_glass
setblock 236 86 232 minecraft:pearlescent_froglight
setblock 236 86 234 minecraft:black_stained_glass
setblock 236 86 236 minecraft:light_blue_stained_glass
setblock 236 86 243 minecraft:pearlescent_froglight
setblock 236 86 245 minecraft:black_stained_glass
setblock 236 86 249 minecraft:pearlescent_froglight
setblock 236 86 251 minecraft:black_stained_glass
setblock 236 86 253 minecraft:cyan_stained_glass
fill 236 86 255 236 87 255 minecraft:gray_concrete
fill 236 86 257 236 87 257 minecraft:gray_concrete
fill 236 86 259 236 87 259 minecraft:gray_concrete
fill 236 86 261 236 87 261 minecraft:cyan_terracotta
setblock 236 86 262 minecraft:black_stained_glass
setblock 236 86 264 minecraft:black_stained_glass
setblock 236 86 266 minecraft:magenta_stained_glass
setblock 236 86 268 minecraft:black_stained_glass
setblock 237 86 229 minecraft:black_stained_glass
setblock 237 86 237 minecraft:light_blue_stained_glass
setblock 237 86 242 minecraft:pearlescent_froglight
fill 237 86 248 237 87 248 minecraft:gray_concrete
fill 237 86 250 237 87 250 minecraft:gray_concrete
fill 237 86 252 237 87 252 minecraft:gray_concrete
fill 237 86 254 237 87 254 minecraft:gray_concrete
setblock 237 86 255 minecraft:magenta_stained_glass
fill 237 86 256 237 87 256 minecraft:gray_concrete
fill 237 86 258 237 87 258 minecraft:gray_concrete
fill 237 86 260 237 86 261 minecraft:gray_concrete
fill 237 86 262 237 87 262 minecraft:cyan_terracotta
setblock 237 86 269 minecraft:ochre_froglight
fill 238 86 229 238 87 229 minecraft:gray_concrete
fill 238 86 231 238 87 231 minecraft:gray_concrete
fill 238 86 233 238 87 233 minecraft:gray_concrete
fill 238 86 235 238 87 235 minecraft:gray_concrete
fill 238 86 237 238 87 237 minecraft:gray_concrete
fill 238 86 245 240 170 245 minecraft:light_gray_concrete
fill 238 86 247 238 87 247 minecraft:gray_concrete
fill 238 86 249 238 87 249 minecraft:gray_concrete
fill 238 86 251 238 87 251 minecraft:gray_concrete
fill 238 86 253 238 87 253 minecraft:gray_concrete
fill 238 86 255 238 87 255 minecraft:gray_concrete
fill 238 86 257 238 87 257 minecraft:gray_concrete
fill 238 86 259 238 87 259 minecraft:gray_concrete
fill 238 86 261 238 87 261 minecraft:cyan_terracotta
setblock 239 86 229 minecraft:black_stained_glass
fill 239 86 230 239 87 230 minecraft:gray_concrete
fill 239 86 232 239 87 232 minecraft:gray_concrete
fill 239 86 234 239 87 234 minecraft:gray_concrete
fill 239 86 236 239 87 236 minecraft:gray_concrete
setblock 239 86 237 minecraft:cyan_stained_glass
setblock 239 86 242 minecraft:black_stained_glass
fill 239 86 248 239 87 248 minecraft:gray_concrete
fill 239 86 250 239 87 250 minecraft:gray_concrete
fill 239 86 252 239 87 252 minecraft:gray_concrete
fill 239 86 254 239 87 254 minecraft:gray_concrete
fill 239 86 256 239 87 256 minecraft:gray_concrete
fill 239 86 258 239 87 258 minecraft:gray_concrete
fill 239 86 260 239 87 260 minecraft:gray_concrete
setblock 239 86 261 minecraft:cyan_stained_glass
fill 239 86 262 239 87 262 minecraft:cyan_terracotta
setblock 239 86 269 minecraft:pearlescent_froglight
fill 240 86 229 240 87 229 minecraft:gray_concrete
fill 240 86 231 240 87 231 minecraft:gray_concrete
fill 240 86 233 240 87 233 minecraft:gray_concrete
fill 240 86 235 240 87 235 minecraft:gray_concrete
fill 240 86 237 240 87 237 minecraft:gray_concrete
fill 240 86 247 240 87 247 minecraft:gray_concrete
fill 240 86 249 240 87 249 minecraft:gray_concrete
fill 240 86 251 240 87 251 minecraft:gray_concrete
fill 240 86 253 240 87 253 minecraft:gray_concrete
fill 240 86 255 240 87 255 minecraft:gray_concrete
fill 240 86 257 240 87 257 minecraft:gray_concrete
fill 240 86 259 240 87 259 minecraft:gray_concrete
fill 240 86 261 240 87 261 minecraft:cyan_terracotta
fill 241 86 230 241 87 230 minecraft:gray_concrete
fill 241 86 232 241 87 232 minecraft:gray_concrete
fill 241 86 234 241 87 234 minecraft:gray_concrete
fill 241 86 236 241 87 236 minecraft:gray_concrete
setblock 241 86 237 minecraft:black_stained_glass
setblock 241 86 243 minecraft:light_blue_stained_glass
setblock 241 86 245 minecraft:pearlescent_froglight
setblock 241 86 247 minecraft:black_stained_glass
setblock 241 86 249 minecraft:light_blue_stained_glass
setblock 241 86 251 minecraft:black_stained_glass
fill 241 86 252 241 87 252 minecraft:gray_concrete
fill 241 86 254 241 87 254 minecraft:gray_concrete
fill 241 86 256 241 87 256 minecraft:gray_concrete
fill 241 86 258 241 87 258 minecraft:gray_concrete
fill 241 86 260 241 87 260 minecraft:gray_concrete
setblock 241 86 261 minecraft:black_stained_glass
fill 241 86 262 241 87 262 minecraft:cyan_terracotta
setblock 241 86 269 minecraft:sea_lantern
fill 242 86 229 242 87 229 minecraft:gray_concrete
fill 242 86 231 242 87 231 minecraft:gray_concrete
fill 242 86 233 242 87 233 minecraft:gray_concrete
fill 242 86 235 242 87 235 minecraft:gray_concrete
fill 242 86 237 242 87 237 minecraft:gray_concrete
fill 242 86 253 242 87 253 minecraft:gray_concrete
fill 242 86 255 242 87 255 minecraft:gray_concrete
fill 242 86 257 242 87 257 minecraft:gray_concrete
fill 242 86 259 242 87 259 minecraft:gray_concrete
fill 242 86 261 242 87 261 minecraft:cyan_terracotta
fill 243 86 228 243 110 228 minecraft:black_concrete
setblock 243 86 229 minecraft:black_stained_glass
fill 243 86 230 243 87 230 minecraft:gray_concrete
fill 243 86 232 243 87 232 minecraft:gray_concrete
fill 243 86 234 243 87 234 minecraft:gray_concrete
fill 243 86 236 243 87 236 minecraft:gray_concrete
setblock 243 86 237 minecraft:ochre_froglight
setblock 243 86 261 minecraft:black_stained_glass
setblock 243 86 269 minecraft:cyan_stained_glass
fill 244 86 229 244 87 229 minecraft:gray_concrete
fill 244 86 231 244 87 231 minecraft:gray_concrete
setblock 244 86 232 minecraft:cyan_stained_glass
fill 244 86 233 244 87 233 minecraft:gray_concrete
setblock 244 86 234 minecraft:cyan_stained_glass
fill 244 86 235 244 87 235 minecraft:gray_concrete
setblock 244 86 236 minecraft:black_stained_glass
fill 244 86 237 244 87 237 minecraft:gray_concrete
setblock 244 86 262 minecraft:black_stained_glass
setblock 244 86 264 minecraft:black_stained_glass
setblock 244 86 266 minecraft:black_stained_glass
setblock 244 86 268 minecraft:cyan_stained_glass
fill 245 86 230 245 87 230 minecraft:gray_concrete
fill 245 86 232 245 87 232 minecraft:gray_concrete
fill 245 86 234 245 87 234 minecraft:gray_concrete
fill 245 86 236 245 87 236 minecraft:gray_concrete
fill 246 86 229 246 87 229 minecraft:gray_concrete
fill 246 86 231 246 87 231 minecraft:gray_concrete
fill 246 86 233 246 87 233 minecraft:gray_concrete
fill 246 86 235 246 87 235 minecraft:gray_concrete
fill 246 86 237 246 87 237 minecraft:gray_concrete
fill 247 86 230 247 87 230 minecraft:gray_concrete
fill 247 86 232 247 87 232 minecraft:gray_concrete
fill 247 86 234 247 87 234 minecraft:gray_concrete
fill 247 86 236 247 87 236 minecraft:gray_concrete
fill 248 86 229 248 87 229 minecraft:gray_concrete
fill 248 86 231 248 87 231 minecraft:gray_concrete
fill 248 86 233 248 87 233 minecraft:gray_concrete
fill 248 86 235 248 87 235 minecraft:gray_concrete
fill 248 86 237 248 87 237 minecraft:gray_concrete
setblock 249 86 230 minecraft:cyan_stained_glass
setblock 249 86 232 minecraft:sea_lantern
setblock 249 86 265 minecraft:magenta_stained_glass
setblock 249 86 267 minecraft:black_stained_glass
setblock 250 86 229 minecraft:black_stained_glass
setblock 250 86 234 minecraft:ochre_froglight
setblock 250 86 264 minecraft:black_stained_glass
setblock 250 86 269 minecraft:ochre_froglight
setblock 252 86 229 minecraft:black_stained_glass
setblock 252 86 234 minecraft:black_stained_glass
setblock 252 86 264 minecraft:cyan_stained_glass
setblock 252 86 269 minecraft:sea_lantern
setblock 254 86 229 minecraft:light_blue_stained_glass
setblock 254 86 234 minecraft:magenta_stained_glass
setblock 254 86 264 minecraft:cyan_stained_glass
setblock 254 86 269 minecraft:black_stained_glass
setblock 256 86 228 minecraft:cyan_concrete
setblock 256 86 229 minecraft:light_blue_stained_glass
setblock 256 86 234 minecraft:cyan_stained_glass
setblock 256 86 264 minecraft:pearlescent_froglight
setblock 256 86 269 minecraft:magenta_stained_glass
fill 257 86 228 262 106 228 minecraft:black_concrete
setblock 257 86 270 minecraft:magenta_concrete
setblock 258 86 229 minecraft:black_stained_glass
setblock 258 86 234 minecraft:pearlescent_froglight
setblock 258 86 264 minecraft:black_stained_glass
setblock 258 86 269 minecraft:black_stained_glass
setblock 260 86 229 minecraft:pearlescent_froglight
setblock 260 86 234 minecraft:pearlescent_froglight
setblock 260 86 264 minecraft:black_stained_glass
setblock 260 86 269 minecraft:cyan_stained_glass
fill 260 86 270 260 174 270 minecraft:black_concrete
setblock 262 86 230 minecraft:black_stained_glass
setblock 262 86 232 minecraft:black_stained_glass
setblock 262 86 265 minecraft:light_blue_stained_glass
setblock 262 86 267 minecraft:ochre_froglight
fill 266 86 229 266 87 229 minecraft:gray_concrete
fill 266 86 231 266 87 231 minecraft:gray_concrete
fill 266 86 233 266 87 233 minecraft:gray_concrete
fill 266 86 235 266 87 235 minecraft:gray_concrete
fill 266 86 237 266 87 237 minecraft:gray_concrete
fill 266 86 239 266 87 239 minecraft:gray_concrete
fill 266 86 259 266 87 259 minecraft:gray_concrete
fill 266 86 261 266 87 261 minecraft:gray_concrete
fill 266 86 263 266 87 263 minecraft:gray_concrete
fill 266 86 265 266 87 265 minecraft:gray_concrete
fill 266 86 267 266 87 267 minecraft:gray_concrete
fill 266 86 269 266 87 269 minecraft:gray_concrete
fill 267 86 230 267 87 230 minecraft:gray_concrete
fill 267 86 232 267 87 232 minecraft:gray_concrete
fill 267 86 234 267 87 234 minecraft:gray_concrete
fill 267 86 236 267 87 236 minecraft:gray_concrete
fill 267 86 238 267 87 238 minecraft:gray_concrete
fill 267 86 260 267 87 260 minecraft:gray_concrete
fill 267 86 262 267 87 262 minecraft:gray_concrete
fill 267 86 264 267 87 264 minecraft:gray_concrete
fill 267 86 266 267 87 266 minecraft:gray_concrete
fill 267 86 268 267 87 268 minecraft:gray_concrete
fill 268 86 229 268 87 229 minecraft:cyan_terracotta
setblock 268 86 230 minecraft:black_stained_glass
fill 268 86 231 268 87 231 minecraft:cyan_terracotta
setblock 268 86 232 minecraft:black_stained_glass
fill 268 86 233 268 87 233 minecraft:cyan_terracotta
setblock 268 86 234 minecraft:black_stained_glass
fill 268 86 235 268 87 235 minecraft:cyan_terracotta
setblock 268 86 236 minecraft:ochre_froglight
fill 268 86 237 268 87 237 minecraft:cyan_terracotta
fill 268 86 239 268 87 239 minecraft:gray_concrete
fill 268 86 259 268 87 259 minecraft:gray_concrete
fill 268 86 261 268 87 261 minecraft:gray_concrete
setblock 268 86 262 minecraft:cyan_stained_glass
fill 268 86 263 268 87 263 minecraft:gray_concrete
setblock 268 86 264 minecraft:black_stained_glass
fill 268 86 265 268 87 265 minecraft:gray_concrete
setblock 268 86 266 minecraft:pearlescent_froglight
fill 268 86 267 268 87 267 minecraft:gray_concrete
setblock 268 86 268 minecraft:black_stained_glass
fill 268 86 269 268 87 269 minecraft:gray_concrete
setblock 269 86 229 minecraft:pearlescent_froglight
fill 269 86 230 269 87 230 minecraft:cyan_terracotta
fill 269 86 232 269 87 232 minecraft:cyan_terracotta
fill 269 86 234 269 87 234 minecraft:cyan_terracotta
fill 269 86 236 269 87 236 minecraft:cyan_terracotta
setblock 269 86 237 minecraft:black_stained_glass
fill 269 86 238 269 87 238 minecraft:gray_concrete
fill 269 86 260 269 87 260 minecraft:gray_concrete
setblock 269 86 261 minecraft:cyan_stained_glass
fill 269 86 262 269 87 262 minecraft:gray_concrete
fill 269 86 264 269 87 264 minecraft:gray_concrete
fill 269 86 266 269 87 266 minecraft:gray_concrete
fill 269 86 268 269 87 268 minecraft:gray_concrete
setblock 269 86 269 minecraft:ochre_froglight
fill 270 86 229 270 87 229 minecraft:cyan_terracotta
fill 270 86 231 270 87 231 minecraft:cyan_terracotta
fill 270 86 233 270 87 233 minecraft:cyan_terracotta
fill 270 86 235 270 87 235 minecraft:cyan_terracotta
fill 270 86 237 270 87 237 minecraft:cyan_terracotta
fill 270 86 239 270 87 239 minecraft:gray_concrete
fill 270 86 259 270 87 259 minecraft:gray_concrete
fill 270 86 261 270 87 261 minecraft:gray_concrete
fill 270 86 263 270 87 263 minecraft:gray_concrete
fill 270 86 265 270 87 265 minecraft:gray_concrete
fill 270 86 267 270 87 267 minecraft:gray_concrete
fill 270 86 269 270 87 269 minecraft:gray_concrete
setblock 271 86 229 minecraft:black_stained_glass
fill 271 86 230 271 87 230 minecraft:cyan_terracotta
fill 271 86 232 271 87 232 minecraft:cyan_terracotta
fill 271 86 234 271 87 234 minecraft:cyan_terracotta
fill 271 86 236 271 87 236 minecraft:cyan_terracotta
setblock 271 86 237 minecraft:ochre_froglight
fill 271 86 238 271 87 238 minecraft:gray_concrete
setblock 271 86 243 minecraft:black_stained_glass
setblock 271 86 245 minecraft:ochre_froglight
setblock 271 86 247 minecraft:magenta_stained_glass
setblock 271 86 249 minecraft:black_stained_glass
setblock 271 86 251 minecraft:pearlescent_froglight
setblock 271 86 253 minecraft:pearlescent_froglight
fill 271 86 260 271 87 260 minecraft:gray_concrete
setblock 271 86 261 minecraft:black_stained_glass
fill 271 86 262 271 87 262 minecraft:gray_concrete
fill 271 86 264 271 87 264 minecraft:gray_concrete
fill 271 86 266 271 87 266 minecraft:gray_concrete
fill 271 86 268 271 87 268 minecraft:gray_concrete
setblock 271 86 269 minecraft:black_stained_glass
setblock 272 86 228 minecraft:sea_lantern
fill 272 86 229 272 87 229 minecraft:cyan_terracotta
fill 272 86 231 272 87 231 minecraft:cyan_terracotta
fill 272 86 233 272 87 233 minecraft:cyan_terracotta
fill 272 86 235 272 87 235 minecraft:cyan_terracotta
fill 272 86 237 272 87 237 minecraft:cyan_terracotta
fill 272 86 239 272 87 239 minecraft:gray_concrete
setblock 272 86 242 minecraft:black_stained_glass
setblock 272 86 255 minecraft:black_stained_glass
fill 272 86 259 272 87 259 minecraft:gray_concrete
fill 272 86 261 272 87 261 minecraft:gray_concrete
fill 272 86 263 272 87 263 minecraft:gray_concrete
fill 272 86 265 272 87 265 minecraft:gray_concrete
fill 272 86 267 272 87 267 minecraft:gray_concrete
fill 272 86 269 272 87 269 minecraft:gray_concrete
setblock 273 86 228 minecraft:purple_concrete
setblock 273 86 229 minecraft:pearlescent_froglight
fill 273 86 230 273 87 230 minecraft:cyan_terracotta
fill 273 86 232 273 87 232 minecraft:cyan_terracotta
fill 273 86 234 273 87 234 minecraft:cyan_terracotta
fill 273 86 236 273 87 236 minecraft:cyan_terracotta
setblock 273 86 237 minecraft:cyan_stained_glass
fill 273 86 238 273 87 238 minecraft:gray_concrete
fill 273 86 260 273 87 260 minecraft:gray_concrete
setblock 273 86 261 minecraft:black_stained_glass
fill 273 86 262 273 87 262 minecraft:gray_concrete
fill 273 86 264 273 87 264 minecraft:gray_concrete
fill 273 86 266 273 87 266 minecraft:gray_concrete
fill 273 86 268 273 87 268 minecraft:gray_concrete
setblock 273 86 269 minecraft:black_stained_glass
fill 274 86 229 274 87 229 minecraft:cyan_terracotta
fill 274 86 231 274 87 231 minecraft:cyan_terracotta
fill 274 86 233 274 87 233 minecraft:cyan_terracotta
fill 274 86 235 274 87 235 minecraft:cyan_terracotta
fill 274 86 237 274 87 237 minecraft:cyan_terracotta
fill 274 86 239 274 87 239 minecraft:gray_concrete
setblock 274 86 242 minecraft:pearlescent_froglight
setblock 274 86 255 minecraft:sea_lantern
fill 274 86 259 274 87 259 minecraft:gray_concrete
fill 274 86 261 274 87 261 minecraft:gray_concrete
fill 274 86 263 274 87 263 minecraft:gray_concrete
fill 274 86 265 274 87 265 minecraft:gray_concrete
fill 274 86 267 274 87 267 minecraft:gray_concrete
fill 274 86 269 274 87 269 minecraft:gray_concrete
setblock 275 86 229 minecraft:ochre_froglight
fill 275 86 230 275 87 230 minecraft:cyan_terracotta
fill 275 86 232 275 87 232 minecraft:cyan_terracotta
fill 275 86 234 275 87 234 minecraft:cyan_terracotta
fill 275 86 236 275 87 236 minecraft:cyan_terracotta
setblock 275 86 237 minecraft:black_stained_glass
fill 275 86 238 275 87 238 minecraft:gray_concrete
fill 275 86 260 275 87 260 minecraft:gray_concrete
setblock 275 86 261 minecraft:black_stained_glass
fill 275 86 262 275 87 262 minecraft:gray_concrete
fill 275 86 264 275 87 264 minecraft:gray_concrete
fill 275 86 266 275 87 266 minecraft:gray_concrete
fill 275 86 268 275 87 268 minecraft:gray_concrete
setblock 275 86 269 minecraft:black_stained_glass
fill 276 86 229 276 87 229 minecraft:cyan_terracotta
setblock 276 86 230 minecraft:black_stained_glass
fill 276 86 231 276 87 231 minecraft:cyan_terracotta
setblock 276 86 232 minecraft:cyan_stained_glass
fill 276 86 233 276 87 233 minecraft:cyan_terracotta
setblock 276 86 234 minecraft:black_stained_glass
fill 276 86 235 276 87 235 minecraft:cyan_terracotta
setblock 276 86 236 minecraft:pearlescent_froglight
fill 276 86 237 276 87 237 minecraft:cyan_terracotta
fill 276 86 239 276 87 239 minecraft:gray_concrete
setblock 276 86 243 minecraft:sea_lantern
setblock 276 86 245 minecraft:black_stained_glass
setblock 276 86 247 minecraft:light_blue_stained_glass
fill 276 86 249 277 86 249 minecraft:pearlescent_froglight
setblock 276 86 251 minecraft:cyan_stained_glass
setblock 276 86 253 minecraft:magenta_stained_glass
fill 276 86 259 276 87 259 minecraft:gray_concrete
fill 276 86 261 276 87 261 minecraft:gray_concrete
setblock 276 86 262 minecraft:pearlescent_froglight
fill 276 86 263 276 87 263 minecraft:gray_concrete
setblock 276 86 264 minecraft:black_stained_glass
fill 276 86 265 276 87 265 minecraft:gray_concrete
setblock 276 86 266 minecraft:black_stained_glass
fill 276 86 267 276 87 267 minecraft:gray_concrete
setblock 276 86 268 minecraft:black_stained_glass
fill 276 86 269 276 87 269 minecraft:gray_concrete
setblock 277 86 232 minecraft:magenta_concrete
fill 277 86 248 277 94 248 minecraft:black_concrete
fill 277 86 250 277 100 251 minecraft:black_concrete
fill 235 87 240 235 149 240 minecraft:black_concrete
fill 235 87 266 235 109 266 minecraft:black_concrete
fill 235 87 268 235 146 268 minecraft:black_concrete
setblock 236 87 228 minecraft:sea_lantern
fill 236 87 230 236 88 230 minecraft:light_gray_concrete
fill 236 87 232 236 88 232 minecraft:light_gray_concrete
fill 236 87 234 236 88 234 minecraft:light_gray_concrete
fill 236 87 236 236 88 236 minecraft:light_gray_concrete
fill 236 87 243 236 88 243 minecraft:light_gray_concrete
fill 236 87 245 236 88 245 minecraft:light_gray_concrete
setblock 236 87 247 minecraft:gray_concrete
setblock 236 87 249 minecraft:gray_concrete
setblock 236 87 251 minecraft:gray_concrete
setblock 236 87 253 minecraft:gray_concrete
fill 236 87 262 236 88 262 minecraft:cyan_terracotta
fill 236 87 264 236 88 264 minecraft:cyan_terracotta
fill 236 87 266 236 88 266 minecraft:cyan_terracotta
fill 236 87 268 236 88 268 minecraft:cyan_terracotta
fill 237 87 228 238 160 228 minecraft:black_concrete
fill 237 87 229 237 88 229 minecraft:light_gray_concrete
fill 237 87 237 237 88 237 minecraft:light_gray_concrete
fill 237 87 242 237 88 242 minecraft:light_gray_concrete
fill 237 87 255 237 91 255 minecraft:gray_concrete
setblock 237 87 260 minecraft:gray_concrete
fill 237 87 261 237 88 261 minecraft:cyan_terracotta
fill 237 87 269 237 88 269 minecraft:cyan_terracotta
setblock 238 87 239 minecraft:light[level=15]
fill 239 87 229 239 88 229 minecraft:gray_concrete
fill 239 87 237 239 88 237 minecraft:gray_concrete
fill 239 87 242 239 88 242 minecraft:light_gray_concrete
fill 239 87 261 239 88 261 minecraft:cyan_terracotta
fill 239 87 269 239 88 269 minecraft:cyan_terracotta
fill 241 87 237 241 88 237 minecraft:gray_concrete
fill 241 87 243 241 88 243 minecraft:light_gray_concrete
fill 241 87 245 241 88 245 minecraft:light_gray_concrete
fill 241 87 247 241 88 247 minecraft:light_gray_concrete
fill 241 87 249 241 88 249 minecraft:light_gray_concrete
fill 241 87 251 241 88 251 minecraft:light_gray_concrete
fill 241 87 261 241 88 261 minecraft:cyan_terracotta
fill 241 87 269 241 88 269 minecraft:cyan_terracotta
fill 243 87 229 243 91 229 minecraft:gray_concrete
fill 243 87 237 243 88 237 minecraft:gray_concrete
fill 243 87 261 243 88 261 minecraft:cyan_terracotta
fill 243 87 269 243 88 269 minecraft:cyan_terracotta
fill 244 87 232 244 88 232 minecraft:gray_concrete
fill 244 87 234 244 88 234 minecraft:gray_concrete
fill 244 87 236 244 88 236 minecraft:gray_concrete
fill 244 87 262 244 88 262 minecraft:cyan_terracotta
fill 244 87 264 244 88 264 minecraft:cyan_terracotta
fill 244 87 266 244 88 266 minecraft:cyan_terracotta
fill 244 87 268 244 88 268 minecraft:cyan_terracotta
setblock 246 87 239 minecraft:light[level=15]
setblock 246 87 247 minecraft:light[level=15]
setblock 246 87 255 minecraft:light[level=15]
setblock 246 87 263 minecraft:light[level=15]
setblock 246 87 270 minecraft:ochre_froglight
fill 249 87 230 249 88 230 minecraft:light_gray_concrete
fill 249 87 232 249 88 232 minecraft:light_gray_concrete
fill 249 87 265 249 88 265 minecraft:cyan_terracotta
fill 249 87 267 249 88 267 minecraft:cyan_terracotta
fill 250 87 229 250 88 229 minecraft:light_gray_concrete
fill 250 87 234 250 88 234 minecraft:light_gray_concrete
fill 250 87 264 250 88 264 minecraft:cyan_terracotta
fill 250 87 269 250 88 269 minecraft:cyan_terracotta
fill 252 87 229 252 88 229 minecraft:light_gray_concrete
fill 252 87 234 252 88 234 minecraft:light_gray_concrete
fill 252 87 264 252 88 264 minecraft:cyan_terracotta
fill 252 87 269 252 88 269 minecraft:cyan_terracotta
fill 254 87 229 254 88 229 minecraft:light_gray_concrete
fill 254 87 234 254 88 234 minecraft:light_gray_concrete
setblock 254 87 239 minecraft:light[level=15]
setblock 254 87 247 minecraft:light[level=15]
setblock 254 87 255 minecraft:light[level=15]
setblock 254 87 263 minecraft:light[level=15]
fill 254 87 264 254 88 264 minecraft:cyan_terracotta
fill 254 87 269 254 88 269 minecraft:cyan_terracotta
fill 256 87 228 256 140 228 minecraft:black_concrete
fill 256 87 229 256 88 229 minecraft:light_gray_concrete
fill 256 87 234 256 88 234 minecraft:light_gray_concrete
fill 256 87 264 256 88 264 minecraft:cyan_terracotta
fill 256 87 269 256 88 269 minecraft:cyan_terracotta
fill 257 87 270 257 114 270 minecraft:black_concrete
fill 258 87 229 258 88 229 minecraft:light_gray_concrete
fill 258 87 234 258 88 234 minecraft:light_gray_concrete
fill 258 87 264 258 88 264 minecraft:cyan_terracotta
fill 258 87 269 258 88 269 minecraft:cyan_terracotta
fill 260 87 229 260 88 229 minecraft:light_gray_concrete
fill 260 87 234 260 88 234 minecraft:light_gray_concrete
fill 260 87 264 260 88 264 minecraft:cyan_terracotta
fill 260 87 269 260 88 269 minecraft:cyan_terracotta
fill 262 87 230 262 88 230 minecraft:light_gray_concrete
fill 262 87 232 262 88 232 minecraft:light_gray_concrete
setblock 262 87 239 minecraft:light[level=15]
setblock 262 87 247 minecraft:light[level=15]
setblock 262 87 255 minecraft:light[level=15]
setblock 262 87 263 minecraft:light[level=15]
fill 262 87 265 262 88 265 minecraft:cyan_terracotta
fill 262 87 267 262 88 267 minecraft:cyan_terracotta
fill 264 87 270 264 148 270 minecraft:black_concrete
setblock 265 87 270 minecraft:ochre_froglight
fill 266 87 270 269 107 270 minecraft:black_concrete
fill 268 87 230 268 88 230 minecraft:cyan_terracotta
fill 268 87 232 268 88 232 minecraft:cyan_terracotta
fill 268 87 234 268 88 234 minecraft:cyan_terracotta
fill 268 87 236 268 88 236 minecraft:cyan_terracotta
fill 268 87 262 268 88 262 minecraft:gray_concrete
fill 268 87 264 268 88 264 minecraft:gray_concrete
fill 268 87 266 268 88 266 minecraft:gray_concrete
fill 268 87 268 268 91 268 minecraft:gray_concrete
fill 269 87 229 269 88 229 minecraft:cyan_terracotta
fill 269 87 237 269 88 237 minecraft:cyan_terracotta
fill 269 87 261 269 88 261 minecraft:gray_concrete
fill 269 87 269 269 88 269 minecraft:gray_concrete
setblock 270 87 247 minecraft:light[level=15]
setblock 270 87 255 minecraft:light[level=15]
fill 271 87 229 271 88 229 minecraft:cyan_terracotta
fill 271 87 237 271 88 237 minecraft:cyan_terracotta
fill 271 87 243 271 88 243 minecraft:light_gray_concrete
fill 271 87 245 271 88 245 minecraft:light_gray_concrete
fill 271 87 247 271 88 247 minecraft:light_gray_concrete
fill 271 87 249 271 88 249 minecraft:light_gray_concrete
fill 271 87 251 271 88 251 minecraft:light_gray_concrete
fill 271 87 253 271 88 253 minecraft:light_gray_concrete
fill 271 87 261 271 90 261 minecraft:gray_concrete
fill 271 87 269 271 88 269 minecraft:gray_concrete
fill 272 87 228 273 140 228 minecraft:black_concrete
fill 272 87 242 272 88 242 minecraft:light_gray_concrete
fill 272 87 255 272 88 255 minecraft:light_gray_concrete
fill 273 87 229 273 88 229 minecraft:cyan_terracotta
fill 273 87 237 273 88 237 minecraft:cyan_terracotta
fill 273 87 261 273 88 261 minecraft:gray_concrete
fill 273 87 269 273 88 269 minecraft:gray_concrete
fill 274 87 242 274 88 242 minecraft:light_gray_concrete
fill 274 87 255 274 88 255 minecraft:light_gray_concrete
fill 275 87 229 275 88 229 minecraft:cyan_terracotta
fill 275 87 237 275 88 237 minecraft:cyan_terracotta
fill 275 87 261 275 88 261 minecraft:gray_concrete
fill 275 87 269 275 88 269 minecraft:gray_concrete
fill 276 87 230 276 88 230 minecraft:cyan_terracotta
fill 276 87 232 276 88 232 minecraft:cyan_terracotta
fill 276 87 234 276 88 234 minecraft:cyan_terracotta
fill 276 87 236 276 88 236 minecraft:cyan_terracotta
fill 276 87 243 276 88 243 minecraft:light_gray_concrete
fill 276 87 245 276 88 245 minecraft:light_gray_concrete
fill 276 87 247 276 88 247 minecraft:light_gray_concrete
fill 276 87 249 276 88 249 minecraft:light_gray_concrete
fill 276 87 251 276 88 251 minecraft:light_gray_concrete
fill 276 87 253 276 88 253 minecraft:light_gray_concrete
fill 276 87 262 276 88 262 minecraft:gray_concrete
fill 276 87 264 276 88 264 minecraft:gray_concrete
fill 276 87 266 276 88 266 minecraft:gray_concrete
fill 276 87 268 276 88 268 minecraft:gray_concrete
fill 277 87 232 277 303 232 minecraft:black_concrete
fill 277 87 249 277 229 249 minecraft:black_concrete
fill 236 88 228 236 119 228 minecraft:black_concrete
setblock 236 88 247 minecraft:sea_lantern
setblock 236 88 249 minecraft:sea_lantern
setblock 236 88 251 minecraft:sea_lantern
setblock 236 88 253 minecraft:sea_lantern
setblock 236 88 255 minecraft:sea_lantern
setblock 236 88 257 minecraft:sea_lantern
setblock 236 88 259 minecraft:sea_lantern
setblock 236 88 261 minecraft:sea_lantern
setblock 237 88 248 minecraft:sea_lantern
setblock 237 88 250 minecraft:sea_lantern
setblock 237 88 252 minecraft:sea_lantern
setblock 237 88 254 minecraft:sea_lantern
setblock 237 88 256 minecraft:sea_lantern
setblock 237 88 258 minecraft:sea_lantern
setblock 237 88 260 minecraft:sea_lantern
setblock 237 88 262 minecraft:sea_lantern
setblock 238 88 229 minecraft:sea_lantern
setblock 238 88 231 minecraft:sea_lantern
setblock 238 88 233 minecraft:sea_lantern
setblock 238 88 235 minecraft:sea_lantern
setblock 238 88 237 minecraft:sea_lantern
setblock 238 88 247 minecraft:sea_lantern
setblock 238 88 249 minecraft:sea_lantern
setblock 238 88 251 minecraft:sea_lantern
setblock 238 88 253 minecraft:sea_lantern
setblock 238 88 255 minecraft:sea_lantern
setblock 238 88 257 minecraft:sea_lantern
setblock 238 88 259 minecraft:sea_lantern
setblock 238 88 261 minecraft:sea_lantern
setblock 239 88 230 minecraft:sea_lantern
setblock 239 88 232 minecraft:sea_lantern
setblock 239 88 234 minecraft:sea_lantern
setblock 239 88 236 minecraft:sea_lantern
setblock 239 88 248 minecraft:sea_lantern
setblock 239 88 250 minecraft:sea_lantern
setblock 239 88 252 minecraft:sea_lantern
setblock 239 88 254 minecraft:sea_lantern
setblock 239 88 256 minecraft:sea_lantern
setblock 239 88 258 minecraft:sea_lantern
setblock 239 88 260 minecraft:sea_lantern
setblock 239 88 262 minecraft:sea_lantern
setblock 240 88 229 minecraft:sea_lantern
setblock 240 88 231 minecraft:sea_lantern
setblock 240 88 233 minecraft:sea_lantern
setblock 240 88 235 minecraft:sea_lantern
setblock 240 88 237 minecraft:sea_lantern
setblock 240 88 247 minecraft:sea_lantern
setblock 240 88 249 minecraft:sea_lantern
setblock 240 88 251 minecraft:sea_lantern
setblock 240 88 253 minecraft:sea_lantern
setblock 240 88 255 minecraft:sea_lantern
setblock 240 88 257 minecraft:sea_lantern
setblock 240 88 259 minecraft:sea_lantern
setblock 240 88 261 minecraft:sea_lantern
setblock 241 88 230 minecraft:sea_lantern
setblock 241 88 232 minecraft:sea_lantern
setblock 241 88 234 minecraft:sea_lantern
setblock 241 88 236 minecraft:sea_lantern
setblock 241 88 252 minecraft:sea_lantern
setblock 241 88 254 minecraft:sea_lantern
setblock 241 88 256 minecraft:sea_lantern
setblock 241 88 258 minecraft:sea_lantern
setblock 241 88 260 minecraft:sea_lantern
setblock 241 88 262 minecraft:sea_lantern
setblock 242 88 229 minecraft:sea_lantern
setblock 242 88 231 minecraft:sea_lantern
setblock 242 88 233 minecraft:sea_lantern
setblock 242 88 235 minecraft:sea_lantern
setblock 242 88 237 minecraft:sea_lantern
setblock 242 88 253 minecraft:sea_lantern
setblock 242 88 255 minecraft:sea_lantern
setblock 242 88 257 minecraft:sea_lantern
setblock 242 88 259 minecraft:sea_lantern
setblock 242 88 261 minecraft:sea_lantern
setblock 243 88 230 minecraft:sea_lantern
setblock 243 88 232 minecraft:sea_lantern
setblock 243 88 234 minecraft:sea_lantern
setblock 243 88 236 minecraft:sea_lantern
setblock 244 88 229 minecraft:sea_lantern
setblock 244 88 231 minecraft:sea_lantern
setblock 244 88 233 minecraft:sea_lantern
setblock 244 88 235 minecraft:sea_lantern
setblock 244 88 237 minecraft:sea_lantern
setblock 245 88 230 minecraft:sea_lantern
setblock 245 88 232 minecraft:sea_lantern
setblock 245 88 234 minecraft:sea_lantern
setblock 245 88 236 minecraft:sea_lantern
setblock 246 88 229 minecraft:sea_lantern
setblock 246 88 231 minecraft:sea_lantern
setblock 246 88 233 minecraft:sea_lantern
setblock 246 88 235 minecraft:sea_lantern
setblock 246 88 237 minecraft:sea_lantern
setblock 246 88 270 minecraft:black_concrete
setblock 247 88 230 minecraft:sea_lantern
setblock 247 88 232 minecraft:sea_lantern
setblock 247 88 234 minecraft:sea_lantern
setblock 247 88 236 minecraft:sea_lantern
setblock 248 88 229 minecraft:sea_lantern
setblock 248 88 231 minecraft:sea_lantern
setblock 248 88 233 minecraft:sea_lantern
setblock 248 88 235 minecraft:sea_lantern
setblock 248 88 237 minecraft:sea_lantern
fill 265 88 270 265 100 270 minecraft:black_concrete
setblock 266 88 229 minecraft:sea_lantern
setblock 266 88 231 minecraft:sea_lantern
setblock 266 88 233 minecraft:sea_lantern
setblock 266 88 235 minecraft:sea_lantern
setblock 266 88 237 minecraft:sea_lantern
setblock 266 88 239 minecraft:sea_lantern
setblock 266 88 259 minecraft:sea_lantern
setblock 266 88 261 minecraft:sea_lantern
setblock 266 88 263 minecraft:sea_lantern
setblock 266 88 265 minecraft:sea_lantern
setblock 266 88 267 minecraft:sea_lantern
setblock 266 88 269 minecraft:sea_lantern
setblock 267 88 230 minecraft:sea_lantern
setblock 267 88 232 minecraft:sea_lantern
setblock 267 88 234 minecraft:sea_lantern
setblock 267 88 236 minecraft:sea_lantern
setblock 267 88 238 minecraft:sea_lantern
setblock 267 88 260 minecraft:sea_lantern
setblock 267 88 262 minecraft:sea_lantern
setblock 267 88 264 minecraft:sea_lantern
setblock 267 88 266 minecraft:sea_lantern
setblock 267 88 268 minecraft:sea_lantern
setblock 268 88 229 minecraft:sea_lantern
setblock 268 88 231 minecraft:sea_lantern
setblock 268 88 233 minecraft:sea_lantern
setblock 268 88 235 minecraft:sea_lantern
setblock 268 88 237 minecraft:sea_lantern
setblock 268 88 239 minecraft:sea_lantern
setblock 268 88 259 minecraft:sea_lantern
setblock 268 88 261 minecraft:sea_lantern
setblock 268 88 263 minecraft:sea_lantern
setblock 268 88 265 minecraft:sea_lantern
setblock 268 88 267 minecraft:sea_lantern
setblock 268 88 269 minecraft:sea_lantern
setblock 269 88 230 minecraft:sea_lantern
setblock 269 88 232 minecraft:sea_lantern
setblock 269 88 234 minecraft:sea_lantern
setblock 269 88 236 minecraft:sea_lantern
setblock 269 88 238 minecraft:sea_lantern
setblock 269 88 260 minecraft:sea_lantern
setblock 269 88 262 minecraft:sea_lantern
setblock 269 88 264 minecraft:sea_lantern
setblock 269 88 266 minecraft:sea_lantern
setblock 269 88 268 minecraft:sea_lantern
setblock 270 88 229 minecraft:sea_lantern
setblock 270 88 231 minecraft:sea_lantern
setblock 270 88 233 minecraft:sea_lantern
setblock 270 88 235 minecraft:sea_lantern
setblock 270 88 237 minecraft:sea_lantern
setblock 270 88 239 minecraft:sea_lantern
setblock 270 88 259 minecraft:sea_lantern
setblock 270 88 261 minecraft:sea_lantern
setblock 270 88 263 minecraft:sea_lantern
setblock 270 88 265 minecraft:sea_lantern
setblock 270 88 267 minecraft:sea_lantern
setblock 270 88 269 minecraft:sea_lantern
setblock 271 88 230 minecraft:sea_lantern
setblock 271 88 232 minecraft:sea_lantern
setblock 271 88 234 minecraft:sea_lantern
setblock 271 88 236 minecraft:sea_lantern
setblock 271 88 238 minecraft:sea_lantern
setblock 271 88 260 minecraft:sea_lantern
setblock 271 88 262 minecraft:sea_lantern
setblock 271 88 264 minecraft:sea_lantern
setblock 271 88 266 minecraft:sea_lantern
setblock 271 88 268 minecraft:sea_lantern
setblock 272 88 229 minecraft:sea_lantern
setblock 272 88 231 minecraft:sea_lantern
setblock 272 88 233 minecraft:sea_lantern
setblock 272 88 235 minecraft:sea_lantern
setblock 272 88 237 minecraft:sea_lantern
setblock 272 88 239 minecraft:sea_lantern
setblock 272 88 259 minecraft:sea_lantern
setblock 272 88 261 minecraft:sea_lantern
setblock 272 88 263 minecraft:sea_lantern
setblock 272 88 265 minecraft:sea_lantern
setblock 272 88 267 minecraft:sea_lantern
setblock 272 88 269 minecraft:sea_lantern
setblock 273 88 230 minecraft:sea_lantern
setblock 273 88 232 minecraft:sea_lantern
setblock 273 88 234 minecraft:sea_lantern
setblock 273 88 236 minecraft:sea_lantern
setblock 273 88 238 minecraft:sea_lantern
setblock 273 88 260 minecraft:sea_lantern
setblock 273 88 262 minecraft:sea_lantern
setblock 273 88 264 minecraft:sea_lantern
setblock 273 88 266 minecraft:sea_lantern
setblock 273 88 268 minecraft:sea_lantern
setblock 274 88 229 minecraft:sea_lantern
setblock 274 88 231 minecraft:sea_lantern
setblock 274 88 233 minecraft:sea_lantern
setblock 274 88 235 minecraft:sea_lantern
setblock 274 88 237 minecraft:sea_lantern
setblock 274 88 239 minecraft:sea_lantern
setblock 274 88 259 minecraft:sea_lantern
setblock 274 88 261 minecraft:sea_lantern
setblock 274 88 263 minecraft:sea_lantern
setblock 274 88 265 minecraft:sea_lantern
setblock 274 88 267 minecraft:sea_lantern
setblock 274 88 269 minecraft:sea_lantern
setblock 274 88 270 minecraft:verdant_froglight
setblock 275 88 230 minecraft:sea_lantern
setblock 275 88 232 minecraft:sea_lantern
setblock 275 88 234 minecraft:sea_lantern
setblock 275 88 236 minecraft:sea_lantern
setblock 275 88 238 minecraft:sea_lantern
setblock 275 88 260 minecraft:sea_lantern
setblock 275 88 262 minecraft:sea_lantern
setblock 275 88 264 minecraft:sea_lantern
setblock 275 88 266 minecraft:sea_lantern
setblock 275 88 268 minecraft:sea_lantern
fill 275 88 270 277 95 270 minecraft:black_concrete
setblock 276 88 229 minecraft:sea_lantern
setblock 276 88 231 minecraft:sea_lantern
setblock 276 88 233 minecraft:sea_lantern
setblock 276 88 235 minecraft:sea_lantern
setblock 276 88 237 minecraft:sea_lantern
setblock 276 88 239 minecraft:sea_lantern
setblock 276 88 259 minecraft:sea_lantern
setblock 276 88 261 minecraft:sea_lantern
setblock 276 88 263 minecraft:sea_lantern
setblock 276 88 265 minecraft:sea_lantern
setblock 276 88 267 minecraft:sea_lantern
setblock 276 88 269 minecraft:sea_lantern
setblock 235 89 257 minecraft:purple_concrete
setblock 236 89 230 minecraft:black_stained_glass
setblock 236 89 232 minecraft:sea_lantern
setblock 236 89 234 minecraft:black_stained_glass
setblock 236 89 236 minecraft:light_blue_stained_glass
setblock 236 89 243 minecraft:magenta_stained_glass
setblock 236 89 245 minecraft:black_stained_glass
setblock 236 89 247 minecraft:black_stained_glass
setblock 236 89 249 minecraft:ochre_froglight
setblock 236 89 251 minecraft:black_stained_glass
setblock 236 89 253 minecraft:cyan_stained_glass
fill 236 89 255 236 90 255 minecraft:gray_concrete
fill 236 89 257 236 90 257 minecraft:gray_concrete
fill 236 89 259 236 90 259 minecraft:gray_concrete
fill 236 89 261 236 90 261 minecraft:cyan_terracotta
setblock 236 89 262 minecraft:black_stained_glass
setblock 236 89 264 minecraft:sea_lantern
setblock 236 89 266 minecraft:magenta_stained_glass
setblock 236 89 268 minecraft:sea_lantern
setblock 237 89 229 minecraft:black_stained_glass
setblock 237 89 237 minecraft:black_stained_glass
setblock 237 89 242 minecraft:black_stained_glass
fill 237 89 248 237 90 248 minecraft:gray_concrete
fill 237 89 250 237 90 250 minecraft:gray_concrete
fill 237 89 252 237 90 252 minecraft:gray_concrete
fill 237 89 254 237 90 254 minecraft:gray_concrete
fill 237 89 256 237 90 256 minecraft:gray_concrete
fill 237 89 258 237 90 258 minecraft:gray_concrete
fill 237 89 260 237 90 260 minecraft:gray_concrete
setblock 237 89 261 minecraft:ochre_froglight
fill 237 89 262 237 90 262 minecraft:cyan_terracotta
setblock 237 89 269 minecraft:light_blue_stained_glass
fill 238 89 229 238 90 229 minecraft:gray_concrete
fill 238 89 231 238 90 231 minecraft:gray_concrete
fill 238 89 233 238 90 233 minecraft:gray_concrete
fill 238 89 235 238 90 235 minecraft:gray_concrete
fill 238 89 237 238 90 237 minecraft:gray_concrete
fill 238 89 247 238 90 247 minecraft:gray_concrete
fill 238 89 249 238 90 249 minecraft:gray_concrete
fill 238 89 251 238 90 251 minecraft:gray_concrete
fill 238 89 253 238 90 253 minecraft:gray_concrete
fill 238 89 255 238 90 255 minecraft:gray_concrete
fill 238 89 257 238 90 257 minecraft:gray_concrete
fill 238 89 259 238 90 259 minecraft:gray_concrete
fill 238 89 261 238 90 261 minecraft:cyan_terracotta
setblock 239 89 229 minecraft:black_stained_glass
fill 239 89 230 239 90 230 minecraft:gray_concrete
fill 239 89 232 239 90 232 minecraft:gray_concrete
fill 239 89 234 239 90 234 minecraft:gray_concrete
fill 239 89 236 239 90 236 minecraft:gray_concrete
setblock 239 89 237 minecraft:black_stained_glass
setblock 239 89 242 minecraft:ochre_froglight
fill 239 89 248 239 90 248 minecraft:gray_concrete
fill 239 89 250 239 90 250 minecraft:gray_concrete
fill 239 89 252 239 90 252 minecraft:gray_concrete
fill 239 89 254 239 90 254 minecraft:gray_concrete
setblock 239 89 255 minecraft:black_stained_glass
fill 239 89 256 239 90 256 minecraft:gray_concrete
fill 239 89 258 239 90 258 minecraft:gray_concrete
fill 239 89 260 239 90 260 minecraft:gray_concrete
setblock 239 89 261 minecraft:black_stained_glass
fill 239 89 262 239 90 262 minecraft:cyan_terracotta
setblock 239 89 269 minecraft:black_stained_glass
fill 240 89 229 240 90 229 minecraft:gray_concrete
fill 240 89 231 240 90 231 minecraft:gray_concrete
fill 240 89 233 240 90 233 minecraft:gray_concrete
fill 240 89 235 240 90 235 minecraft:gray_concrete
fill 240 89 237 240 90 237 minecraft:gray_concrete
fill 240 89 247 240 90 247 minecraft:gray_concrete
fill 240 89 249 240 90 249 minecraft:gray_concrete
fill 240 89 251 240 90 251 minecraft:gray_concrete
fill 240 89 253 240 90 253 minecraft:gray_concrete
fill 240 89 255 240 90 255 minecraft:gray_concrete
fill 240 89 257 240 90 257 minecraft:gray_concrete
fill 240 89 259 240 90 259 minecraft:gray_concrete
fill 240 89 261 240 90 261 minecraft:cyan_terracotta
setblock 241 89 229 minecraft:black_stained_glass
fill 241 89 230 241 90 230 minecraft:gray_concrete
fill 241 89 232 241 90 232 minecraft:gray_concrete
fill 241 89 234 241 90 234 minecraft:gray_concrete
fill 241 89 236 241 90 236 minecraft:gray_concrete
setblock 241 89 237 minecraft:pearlescent_froglight
setblock 241 89 243 minecraft:magenta_stained_glass
setblock 241 89 245 minecraft:black_stained_glass
setblock 241 89 247 minecraft:black_stained_glass
setblock 241 89 249 minecraft:light_blue_stained_glass
setblock 241 89 251 minecraft:black_stained_glass
fill 241 89 252 241 90 252 minecraft:gray_concrete
setblock 241 89 253 minecraft:black_stained_glass
fill 241 89 254 241 90 254 minecraft:gray_concrete
fill 241 89 256 241 90 256 minecraft:gray_concrete
fill 241 89 258 241 90 258 minecraft:gray_concrete
fill 241 89 260 241 90 260 minecraft:gray_concrete
setblock 241 89 261 minecraft:cyan_stained_glass
fill 241 89 262 241 90 262 minecraft:cyan_terracotta
setblock 241 89 269 minecraft:black_stained_glass
fill 242 89 229 242 90 229 minecraft:gray_concrete
fill 242 89 231 242 90 231 minecraft:gray_concrete
fill 242 89 233 242 90 233 minecraft:gray_concrete
fill 242 89 235 242 90 235 minecraft:gray_concrete
fill 242 89 237 242 90 237 minecraft:gray_concrete
fill 242 89 253 242 90 253 minecraft:gray_concrete
fill 242 89 255 242 90 255 minecraft:gray_concrete
fill 242 89 257 242 90 257 minecraft:gray_concrete
fill 242 89 259 242 90 259 minecraft:gray_concrete
fill 242 89 261 242 90 261 minecraft:cyan_terracotta
fill 243 89 230 243 90 230 minecraft:gray_concrete
fill 243 89 232 243 90 232 minecraft:gray_concrete
fill 243 89 234 243 90 234 minecraft:gray_concrete
fill 243 89 236 243 90 236 minecraft:gray_concrete
setblock 243 89 237 minecraft:sea_lantern
setblock 243 89 261 minecraft:black_stained_glass
setblock 243 89 269 minecraft:black_stained_glass
fill 243 89 270 243 122 270 minecraft:black_concrete
setblock 244 89 228 minecraft:cyan_concrete
fill 244 89 229 244 90 229 minecraft:gray_concrete
setblock 244 89 230 minecraft:black_stained_glass
fill 244 89 231 244 90 231 minecraft:gray_concrete
setblock 244 89 232 minecraft:black_stained_glass
fill 244 89 233 244 90 233 minecraft:gray_concrete
setblock 244 89 234 minecraft:ochre_froglight
fill 244 89 235 244 90 235 minecraft:gray_concrete
setblock 244 89 236 minecraft:cyan_stained_glass
fill 244 89 237 244 90 237 minecraft:gray_concrete
setblock 244 89 262 minecraft:pearlescent_froglight
setblock 244 89 264 minecraft:ochre_froglight
setblock 244 89 266 minecraft:black_stained_glass
setblock 244 89 268 minecraft:black_stained_glass
setblock 244 89 270 minecraft:purple_concrete
fill 245 89 228 248 104 228 minecraft:black_concrete
fill 245 89 230 245 90 230 minecraft:gray_concrete
fill 245 89 232 245 90 232 minecraft:gray_concrete
fill 245 89 234 245 90 234 minecraft:gray_concrete
fill 245 89 236 245 90 236 minecraft:gray_concrete
fill 245 89 270 245 235 270 minecraft:black_concrete
fill 246 89 229 246 90 229 minecraft:gray_concrete
fill 246 89 231 246 90 231 minecraft:gray_concrete
fill 246 89 233 246 90 233 minecraft:gray_concrete
fill 246 89 235 246 90 235 minecraft:gray_concrete
fill 246 89 237 246 90 237 minecraft:gray_concrete
setblock 246 89 270 minecraft:cyan_concrete
fill 247 89 230 247 90 230 minecraft:gray_concrete
fill 247 89 232 247 90 232 minecraft:gray_concrete
fill 247 89 234 247 90 234 minecraft:gray_concrete
fill 247 89 236 247 90 236 minecraft:gray_concrete
fill 248 89 229 248 90 229 minecraft:gray_concrete
fill 248 89 231 248 90 231 minecraft:gray_concrete
fill 248 89 233 248 90 233 minecraft:gray_concrete
fill 248 89 235 248 90 235 minecraft:gray_concrete
fill 248 89 237 248 90 237 minecraft:gray_concrete
setblock 249 89 230 minecraft:black_stained_glass
setblock 249 89 232 minecraft:black_stained_glass
setblock 249 89 265 minecraft:black_stained_glass
setblock 249 89 267 minecraft:sea_lantern
setblock 250 89 229 minecraft:light_blue_stained_glass
setblock 250 89 234 minecraft:sea_lantern
setblock 250 89 264 minecraft:black_stained_glass
setblock 250 89 269 minecraft:sea_lantern
setblock 252 89 229 minecraft:black_stained_glass
setblock 252 89 234 minecraft:cyan_stained_glass
setblock 252 89 264 minecraft:black_stained_glass
setblock 252 89 269 minecraft:pearlescent_froglight
setblock 254 89 229 minecraft:pearlescent_froglight
setblock 254 89 234 minecraft:light_blue_stained_glass
setblock 254 89 264 minecraft:sea_lantern
setblock 254 89 269 minecraft:black_stained_glass
setblock 256 89 229 minecraft:light_blue_stained_glass
setblock 256 89 234 minecraft:cyan_stained_glass
setblock 256 89 264 minecraft:black_stained_glass
setblock 256 89 269 minecraft:black_stained_glass
setblock 258 89 229 minecraft:black_stained_glass
setblock 258 89 234 minecraft:black_stained_glass
setblock 258 89 264 minecraft:magenta_stained_glass
setblock 258 89 269 minecraft:light_blue_stained_glass
setblock 260 89 229 minecraft:black_stained_glass
setblock 260 89 234 minecraft:magenta_stained_glass
setblock 260 89 264 minecraft:black_stained_glass
setblock 260 89 269 minecraft:pearlescent_froglight
setblock 262 89 230 minecraft:cyan_stained_glass
setblock 262 89 232 minecraft:black_stained_glass
setblock 262 89 265 minecraft:ochre_froglight
setblock 262 89 267 minecraft:magenta_stained_glass
fill 266 89 229 266 90 229 minecraft:gray_concrete
fill 266 89 231 266 90 231 minecraft:gray_concrete
fill 266 89 233 266 90 233 minecraft:gray_concrete
fill 266 89 235 266 90 235 minecraft:gray_concrete
fill 266 89 237 266 90 237 minecraft:gray_concrete
fill 266 89 239 266 90 239 minecraft:gray_concrete
fill 266 89 259 266 90 259 minecraft:gray_concrete
fill 266 89 261 266 90 261 minecraft:gray_concrete
fill 266 89 263 266 90 263 minecraft:gray_concrete
fill 266 89 265 266 90 265 minecraft:gray_concrete
fill 266 89 267 266 90 267 minecraft:gray_concrete
fill 266 89 269 266 90 269 minecraft:gray_concrete
fill 267 89 230 267 90 230 minecraft:gray_concrete
fill 267 89 232 267 90 232 minecraft:gray_concrete
fill 267 89 234 267 90 234 minecraft:gray_concrete
fill 267 89 236 267 90 236 minecraft:gray_concrete
fill 267 89 238 267 90 238 minecraft:gray_concrete
fill 267 89 260 267 90 260 minecraft:gray_concrete
fill 267 89 262 267 90 262 minecraft:gray_concrete
fill 267 89 264 267 90 264 minecraft:gray_concrete
fill 267 89 266 267 90 266 minecraft:gray_concrete
fill 267 89 268 267 90 268 minecraft:gray_concrete
fill 268 89 229 268 90 229 minecraft:cyan_terracotta
setblock 268 89 230 minecraft:cyan_stained_glass
fill 268 89 231 268 90 231 minecraft:cyan_terracotta
setblock 268 89 232 minecraft:magenta_stained_glass
fill 268 89 233 268 90 233 minecraft:cyan_terracotta
setblock 268 89 234 minecraft:black_stained_glass
fill 268 89 235 268 90 235 minecraft:cyan_terracotta
setblock 268 89 236 minecraft:black_stained_glass
fill 268 89 237 268 90 237 minecraft:cyan_terracotta
fill 268 89 239 268 90 239 minecraft:gray_concrete
fill 268 89 259 268 90 259 minecraft:gray_concrete
fill 268 89 261 268 90 261 minecraft:gray_concrete
setblock 268 89 262 minecraft:pearlescent_froglight
fill 268 89 263 268 90 263 minecraft:gray_concrete
setblock 268 89 264 minecraft:ochre_froglight
fill 268 89 265 268 90 265 minecraft:gray_concrete
setblock 268 89 266 minecraft:magenta_stained_glass
fill 268 89 267 268 90 267 minecraft:gray_concrete
fill 268 89 269 268 90 269 minecraft:gray_concrete
setblock 269 89 229 minecraft:cyan_stained_glass
fill 269 89 230 269 90 230 minecraft:cyan_terracotta
fill 269 89 232 269 90 232 minecraft:cyan_terracotta
fill 269 89 234 269 90 234 minecraft:cyan_terracotta
fill 269 89 236 269 90 236 minecraft:cyan_terracotta
setblock 269 89 237 minecraft:black_stained_glass
fill 269 89 238 269 90 238 minecraft:gray_concrete
fill 269 89 260 269 90 260 minecraft:gray_concrete
setblock 269 89 261 minecraft:black_stained_glass
fill 269 89 262 269 90 262 minecraft:gray_concrete
fill 269 89 264 269 90 264 minecraft:gray_concrete
fill 269 89 266 269 90 266 minecraft:gray_concrete
fill 269 89 268 269 90 268 minecraft:gray_concrete
setblock 269 89 269 minecraft:pearlescent_froglight
fill 270 89 229 270 90 229 minecraft:cyan_terracotta
fill 270 89 231 270 90 231 minecraft:cyan_terracotta
fill 270 89 233 270 90 233 minecraft:cyan_terracotta
fill 270 89 235 270 90 235 minecraft:cyan_terracotta
fill 270 89 237 270 90 237 minecraft:cyan_terracotta
fill 270 89 239 270 90 239 minecraft:gray_concrete
fill 270 89 259 270 90 259 minecraft:gray_concrete
fill 270 89 261 270 90 261 minecraft:gray_concrete
fill 270 89 263 270 90 263 minecraft:gray_concrete
fill 270 89 265 270 90 265 minecraft:gray_concrete
fill 270 89 267 270 90 267 minecraft:gray_concrete
fill 270 89 269 270 90 269 minecraft:gray_concrete
setblock 271 89 229 minecraft:pearlescent_froglight
fill 271 89 230 271 90 230 minecraft:cyan_terracotta
fill 271 89 232 271 90 232 minecraft:cyan_terracotta
fill 271 89 234 271 90 234 minecraft:cyan_terracotta
fill 271 89 236 271 90 236 minecraft:cyan_terracotta
setblock 271 89 237 minecraft:magenta_stained_glass
fill 271 89 238 271 90 238 minecraft:gray_concrete
setblock 271 89 243 minecraft:black_stained_glass
setblock 271 89 245 minecraft:sea_lantern
setblock 271 89 247 minecraft:sea_lantern
setblock 271 89 249 minecraft:magenta_stained_glass
setblock 271 89 251 minecraft:magenta_stained_glass
setblock 271 89 253 minecraft:light_blue_stained_glass
fill 271 89 260 271 90 260 minecraft:gray_concrete
fill 271 89 262 271 90 262 minecraft:gray_concrete
fill 271 89 264 271 90 264 minecraft:gray_concrete
fill 271 89 266 271 90 266 minecraft:gray_concrete
fill 271 89 268 271 90 268 minecraft:gray_concrete
setblock 271 89 269 minecraft:pearlescent_froglight
fill 272 89 229 272 90 229 minecraft:cyan_terracotta
fill 272 89 231 272 90 231 minecraft:cyan_terracotta
fill 272 89 233 272 90 233 minecraft:cyan_terracotta
fill 272 89 235 272 90 235 minecraft:cyan_terracotta
fill 272 89 237 272 90 237 minecraft:cyan_terracotta
fill 272 89 239 272 90 239 minecraft:gray_concrete
setblock 272 89 242 minecraft:cyan_stained_glass
setblock 272 89 255 minecraft:black_stained_glass
fill 272 89 259 272 90 259 minecraft:gray_concrete
fill 272 89 261 272 90 261 minecraft:gray_concrete
fill 272 89 263 272 90 263 minecraft:gray_concrete
fill 272 89 265 272 90 265 minecraft:gray_concrete
fill 272 89 267 272 90 267 minecraft:gray_concrete
fill 272 89 269 272 90 269 minecraft:gray_concrete
setblock 273 89 229 minecraft:gray_concrete
fill 273 89 230 273 90 230 minecraft:cyan_terracotta
fill 273 89 232 273 90 232 minecraft:cyan_terracotta
fill 273 89 234 273 90 234 minecraft:cyan_terracotta
fill 273 89 236 273 90 236 minecraft:cyan_terracotta
setblock 273 89 237 minecraft:cyan_stained_glass
fill 273 89 238 273 90 238 minecraft:gray_concrete
fill 273 89 260 273 90 260 minecraft:gray_concrete
setblock 273 89 261 minecraft:sea_lantern
fill 273 89 262 273 90 262 minecraft:gray_concrete
fill 273 89 264 273 90 264 minecraft:gray_concrete
fill 273 89 266 273 90 266 minecraft:gray_concrete
fill 273 89 268 273 90 268 minecraft:gray_concrete
setblock 273 89 269 minecraft:magenta_stained_glass
fill 274 89 229 274 90 229 minecraft:cyan_terracotta
fill 274 89 231 274 90 231 minecraft:cyan_terracotta
fill 274 89 233 274 90 233 minecraft:cyan_terracotta
fill 274 89 235 274 90 235 minecraft:cyan_terracotta
fill 274 89 237 274 90 237 minecraft:cyan_terracotta
fill 274 89 239 274 90 239 minecraft:gray_concrete
setblock 274 89 242 minecraft:black_stained_glass
setblock 274 89 255 minecraft:ochre_froglight
fill 274 89 259 274 90 259 minecraft:gray_concrete
fill 274 89 261 274 90 261 minecraft:gray_concrete
fill 274 89 263 274 90 263 minecraft:gray_concrete
fill 274 89 265 274 90 265 minecraft:gray_concrete
fill 274 89 267 274 90 267 minecraft:gray_concrete
fill 274 89 269 274 90 269 minecraft:gray_concrete
fill 274 89 270 274 107 270 minecraft:black_concrete
setblock 275 89 229 minecraft:pearlescent_froglight
fill 275 89 230 275 90 230 minecraft:cyan_terracotta
fill 275 89 232 275 90 232 minecraft:cyan_terracotta
fill 275 89 234 275 90 234 minecraft:cyan_terracotta
fill 275 89 236 275 90 236 minecraft:cyan_terracotta
setblock 275 89 237 minecraft:black_stained_glass
fill 275 89 238 275 90 238 minecraft:gray_concrete
fill 275 89 260 275 90 260 minecraft:gray_concrete
setblock 275 89 261 minecraft:black_stained_glass
fill 275 89 262 275 90 262 minecraft:gray_concrete
fill 275 89 264 275 90 264 minecraft:gray_concrete
fill 275 89 266 275 90 266 minecraft:gray_concrete
fill 275 89 268 275 90 268 minecraft:gray_concrete
setblock 275 89 269 minecraft:magenta_stained_glass
fill 276 89 229 276 90 229 minecraft:cyan_terracotta
setblock 276 89 230 minecraft:black_stained_glass
fill 276 89 231 276 90 231 minecraft:cyan_terracotta
setblock 276 89 232 minecraft:black_stained_glass
fill 276 89 233 276 90 233 minecraft:cyan_terracotta
setblock 276 89 234 minecraft:black_stained_glass
fill 276 89 235 276 90 235 minecraft:cyan_terracotta
setblock 276 89 236 minecraft:black_stained_glass
fill 276 89 237 276 90 237 minecraft:cyan_terracotta
fill 276 89 239 276 90 239 minecraft:gray_concrete
setblock 276 89 243 minecraft:ochre_froglight
setblock 276 89 245 minecraft:black_stained_glass
setblock 276 89 247 minecraft:cyan_stained_glass
setblock 276 89 249 minecraft:black_stained_glass
setblock 276 89 251 minecraft:black_stained_glass
setblock 276 89 253 minecraft:magenta_stained_glass
fill 276 89 259 276 90 259 minecraft:gray_concrete
fill 276 89 261 276 90 261 minecraft:gray_concrete
setblock 276 89 262 minecraft:sea_lantern
fill 276 89 263 276 90 263 minecraft:gray_concrete
setblock 276 89 264 minecraft:ochre_froglight
fill 276 89 265 276 90 265 minecraft:gray_concrete
setblock 276 89 266 minecraft:black_stained_glass
fill 276 89 267 276 90 267 minecraft:gray_concrete
setblock 276 89 268 minecraft:ochre_froglight
fill 276 89 269 276 90 269 minecraft:gray_concrete
fill 235 90 257 235 118 257 minecraft:black_concrete
setblock 235 90 261 minecraft:magenta_concrete
fill 236 90 230 236 91 230 minecraft:light_gray_concrete
fill 236 90 232 236 91 232 minecraft:light_gray_concrete
fill 236 90 234 236 91 234 minecraft:light_gray_concrete
fill 236 90 236 236 91 236 minecraft:light_gray_concrete
fill 236 90 243 236 91 243 minecraft:light_gray_concrete
fill 236 90 245 236 91 245 minecraft:light_gray_concrete
setblock 236 90 247 minecraft:gray_concrete
setblock 236 90 249 minecraft:gray_concrete
setblock 236 90 251 minecraft:gray_concrete
setblock 236 90 253 minecraft:gray_concrete
fill 236 90 262 236 91 262 minecraft:cyan_terracotta
fill 236 90 264 236 91 264 minecraft:cyan_terracotta
fill 236 90 266 236 91 266 minecraft:cyan_terracotta
fill 236 90 268 236 91 268 minecraft:cyan_terracotta
fill 237 90 229 237 91 229 minecraft:light_gray_concrete
fill 237 90 237 237 91 237 minecraft:light_gray_concrete
fill 237 90 242 237 91 242 minecraft:light_gray_concrete
fill 237 90 261 237 91 261 minecraft:cyan_terracotta
fill 237 90 269 237 91 269 minecraft:cyan_terracotta
fill 239 90 229 239 91 229 minecraft:gray_concrete
fill 239 90 237 239 91 237 minecraft:gray_concrete
fill 239 90 242 239 91 242 minecraft:light_gray_concrete
fill 239 90 255 239 91 255 minecraft:gray_concrete
fill 239 90 261 239 91 261 minecraft:cyan_terracotta
fill 239 90 269 239 91 269 minecraft:cyan_terracotta
fill 241 90 229 241 91 229 minecraft:gray_concrete
fill 241 90 237 241 91 237 minecraft:gray_concrete
fill 241 90 243 241 91 243 minecraft:light_gray_concrete
fill 241 90 245 241 91 245 minecraft:light_gray_concrete
fill 241 90 247 241 91 247 minecraft:light_gray_concrete
fill 241 90 249 241 91 249 minecraft:light_gray_concrete
fill 241 90 251 241 91 251 minecraft:light_gray_concrete
fill 241 90 253 241 91 253 minecraft:gray_concrete
fill 241 90 261 241 91 261 minecraft:cyan_terracotta
fill 241 90 269 241 91 269 minecraft:cyan_terracotta
fill 243 90 237 243 91 237 minecraft:gray_concrete
fill 243 90 261 243 91 261 minecraft:cyan_terracotta
fill 243 90 269 243 91 269 minecraft:cyan_terracotta
fill 244 90 228 244 91 228 minecraft:black_concrete
fill 244 90 230 244 91 230 minecraft:gray_concrete
fill 244 90 232 244 91 232 minecraft:gray_concrete
fill 244 90 234 244 91 234 minecraft:gray_concrete
fill 244 90 236 244 93 236 minecraft:gray_concrete
fill 244 90 262 244 91 262 minecraft:cyan_terracotta
fill 244 90 264 244 91 264 minecraft:cyan_terracotta
fill 244 90 266 244 91 266 minecraft:cyan_terracotta
fill 244 90 268 244 91 268 minecraft:cyan_terracotta
fill 244 90 270 244 201 270 minecraft:black_concrete
fill 246 90 270 246 157 270 minecraft:black_concrete
fill 249 90 230 249 91 230 minecraft:light_gray_concrete
fill 249 90 232 249 91 232 minecraft:light_gray_concrete
fill 249 90 265 249 91 265 minecraft:cyan_terracotta
fill 249 90 267 249 91 267 minecraft:cyan_terracotta
fill 250 90 229 250 91 229 minecraft:light_gray_concrete
fill 250 90 234 250 91 234 minecraft:light_gray_concrete
fill 250 90 264 250 91 264 minecraft:cyan_terracotta
fill 250 90 269 250 91 269 minecraft:cyan_terracotta
setblock 250 90 270 minecraft:blue_concrete
fill 252 90 229 252 91 229 minecraft:light_gray_concrete
fill 252 90 234 252 91 234 minecraft:light_gray_concrete
fill 252 90 264 252 91 264 minecraft:cyan_terracotta
fill 252 90 269 252 91 269 minecraft:cyan_terracotta
fill 254 90 229 254 91 229 minecraft:light_gray_concrete
fill 254 90 234 254 91 234 minecraft:light_gray_concrete
fill 254 90 264 254 91 264 minecraft:cyan_terracotta
fill 254 90 269 254 91 269 minecraft:cyan_terracotta
fill 256 90 229 256 91 229 minecraft:light_gray_concrete
fill 256 90 234 256 91 234 minecraft:light_gray_concrete
fill 256 90 264 256 91 264 minecraft:cyan_terracotta
fill 256 90 269 256 91 269 minecraft:cyan_terracotta
fill 258 90 229 258 91 229 minecraft:light_gray_concrete
fill 258 90 234 258 91 234 minecraft:light_gray_concrete
fill 258 90 264 258 91 264 minecraft:cyan_terracotta
fill 258 90 269 258 91 269 minecraft:cyan_terracotta
fill 260 90 229 260 91 229 minecraft:light_gray_concrete
fill 260 90 234 260 91 234 minecraft:light_gray_concrete
fill 260 90 264 260 91 264 minecraft:cyan_terracotta
fill 260 90 269 260 91 269 minecraft:cyan_terracotta
fill 262 90 230 262 91 230 minecraft:light_gray_concrete
fill 262 90 232 262 91 232 minecraft:light_gray_concrete
fill 262 90 265 262 91 265 minecraft:cyan_terracotta
fill 262 90 267 262 91 267 minecraft:cyan_terracotta
fill 268 90 230 268 91 230 minecraft:cyan_terracotta
fill 268 90 232 268 91 232 minecraft:cyan_terracotta
fill 268 90 234 268 91 234 minecraft:cyan_terracotta
fill 268 90 236 268 91 236 minecraft:cyan_terracotta
setblock 268 90 262 minecraft:gray_concrete
fill 268 90 264 268 91 264 minecraft:gray_concrete
fill 268 90 266 268 94 266 minecraft:gray_concrete
fill 269 90 229 269 91 229 minecraft:cyan_terracotta
fill 269 90 237 269 91 237 minecraft:cyan_terracotta
setblock 269 90 261 minecraft:gray_concrete
fill 269 90 269 269 91 269 minecraft:gray_concrete
fill 271 90 229 271 91 229 minecraft:cyan_terracotta
fill 271 90 237 271 91 237 minecraft:cyan_terracotta
fill 271 90 243 271 91 243 minecraft:light_gray_concrete
fill 271 90 245 271 91 245 minecraft:light_gray_concrete
fill 271 90 247 271 91 247 minecraft:light_gray_concrete
fill 271 90 249 271 91 249 minecraft:light_gray_concrete
fill 271 90 251 271 91 251 minecraft:light_gray_concrete
fill 271 90 253 271 91 253 minecraft:light_gray_concrete
fill 271 90 269 271 91 269 minecraft:gray_concrete
fill 272 90 242 272 91 242 minecraft:light_gray_concrete
fill 272 90 255 272 91 255 minecraft:light_gray_concrete
fill 273 90 229 273 91 229 minecraft:cyan_terracotta
fill 273 90 237 273 91 237 minecraft:cyan_terracotta
setblock 273 90 261 minecraft:gray_concrete
setblock 273 90 269 minecraft:gray_concrete
fill 274 90 242 274 91 242 minecraft:light_gray_concrete
fill 274 90 255 274 91 255 minecraft:light_gray_concrete
fill 275 90 229 275 91 229 minecraft:cyan_terracotta
fill 275 90 237 275 91 237 minecraft:cyan_terracotta
setblock 275 90 261 minecraft:gray_concrete
setblock 275 90 269 minecraft:gray_concrete
fill 276 90 230 276 91 230 minecraft:cyan_terracotta
fill 276 90 232 276 91 232 minecraft:cyan_terracotta
fill 276 90 234 276 91 234 minecraft:cyan_terracotta
fill 276 90 236 276 91 236 minecraft:cyan_terracotta
fill 276 90 243 276 91 243 minecraft:light_gray_concrete
fill 276 90 245 276 91 245 minecraft:light_gray_concrete
fill 276 90 247 276 91 247 minecraft:light_gray_concrete
fill 276 90 249 276 91 249 minecraft:light_gray_concrete
fill 276 90 251 276 91 251 minecraft:light_gray_concrete
fill 276 90 253 276 91 253 minecraft:light_gray_concrete
setblock 276 90 262 minecraft:gray_concrete
setblock 276 90 264 minecraft:gray_concrete
setblock 276 90 266 minecraft:gray_concrete
setblock 276 90 268 minecraft:gray_concrete
fill 235 91 261 235 106 261 minecraft:black_concrete
setblock 236 91 247 minecraft:sea_lantern
fill 236 91 249 236 92 249 minecraft:sea_lantern
setblock 236 91 251 minecraft:sea_lantern
fill 236 91 253 236 92 253 minecraft:sea_lantern
setblock 236 91 255 minecraft:sea_lantern
setblock 236 91 257 minecraft:sea_lantern
setblock 236 91 259 minecraft:sea_lantern
setblock 236 91 261 minecraft:sea_lantern
setblock 237 91 248 minecraft:sea_lantern
setblock 237 91 250 minecraft:sea_lantern
setblock 237 91 252 minecraft:sea_lantern
setblock 237 91 254 minecraft:sea_lantern
setblock 237 91 256 minecraft:sea_lantern
setblock 237 91 258 minecraft:sea_lantern
setblock 237 91 260 minecraft:sea_lantern
setblock 237 91 262 minecraft:sea_lantern
setblock 238 91 229 minecraft:sea_lantern
setblock 238 91 231 minecraft:sea_lantern
setblock 238 91 233 minecraft:sea_lantern
setblock 238 91 235 minecraft:sea_lantern
setblock 238 91 237 minecraft:sea_lantern
setblock 238 91 238 minecraft:light[level=12]
setblock 238 91 247 minecraft:sea_lantern
setblock 238 91 249 minecraft:sea_lantern
setblock 238 91 251 minecraft:sea_lantern
setblock 238 91 253 minecraft:sea_lantern
setblock 238 91 255 minecraft:sea_lantern
setblock 238 91 257 minecraft:sea_lantern
setblock 238 91 259 minecraft:sea_lantern
setblock 238 91 261 minecraft:sea_lantern
setblock 239 91 230 minecraft:sea_lantern
setblock 239 91 232 minecraft:sea_lantern
setblock 239 91 234 minecraft:sea_lantern
setblock 239 91 236 minecraft:sea_lantern
setblock 239 91 248 minecraft:sea_lantern
setblock 239 91 250 minecraft:sea_lantern
setblock 239 91 252 minecraft:sea_lantern
setblock 239 91 254 minecraft:sea_lantern
setblock 239 91 256 minecraft:sea_lantern
setblock 239 91 258 minecraft:sea_lantern
setblock 239 91 260 minecraft:sea_lantern
setblock 239 91 262 minecraft:sea_lantern
setblock 240 91 229 minecraft:sea_lantern
setblock 240 91 231 minecraft:sea_lantern
setblock 240 91 233 minecraft:sea_lantern
setblock 240 91 235 minecraft:sea_lantern
setblock 240 91 237 minecraft:sea_lantern
setblock 240 91 247 minecraft:sea_lantern
setblock 240 91 249 minecraft:sea_lantern
setblock 240 91 251 minecraft:sea_lantern
setblock 240 91 253 minecraft:sea_lantern
setblock 240 91 255 minecraft:sea_lantern
setblock 240 91 257 minecraft:sea_lantern
setblock 240 91 259 minecraft:sea_lantern
setblock 240 91 261 minecraft:sea_lantern
setblock 241 91 230 minecraft:sea_lantern
setblock 241 91 232 minecraft:sea_lantern
setblock 241 91 234 minecraft:sea_lantern
setblock 241 91 236 minecraft:sea_lantern
setblock 241 91 252 minecraft:sea_lantern
setblock 241 91 254 minecraft:sea_lantern
setblock 241 91 256 minecraft:sea_lantern
setblock 241 91 258 minecraft:sea_lantern
setblock 241 91 260 minecraft:sea_lantern
setblock 241 91 262 minecraft:sea_lantern
setblock 242 91 229 minecraft:sea_lantern
setblock 242 91 231 minecraft:sea_lantern
setblock 242 91 233 minecraft:sea_lantern
setblock 242 91 235 minecraft:sea_lantern
setblock 242 91 237 minecraft:sea_lantern
setblock 242 91 253 minecraft:sea_lantern
setblock 242 91 255 minecraft:sea_lantern
setblock 242 91 257 minecraft:sea_lantern
setblock 242 91 259 minecraft:sea_lantern
setblock 242 91 261 minecraft:sea_lantern
setblock 243 91 230 minecraft:sea_lantern
setblock 243 91 232 minecraft:sea_lantern
setblock 243 91 234 minecraft:sea_lantern
setblock 243 91 236 minecraft:sea_lantern
setblock 244 91 229 minecraft:sea_lantern
setblock 244 91 231 minecraft:sea_lantern
setblock 244 91 233 minecraft:sea_lantern
setblock 244 91 235 minecraft:sea_lantern
setblock 244 91 237 minecraft:sea_lantern
setblock 245 91 230 minecraft:sea_lantern
setblock 245 91 232 minecraft:sea_lantern
setblock 245 91 234 minecraft:sea_lantern
setblock 245 91 236 minecraft:sea_lantern
setblock 245 91 238 minecraft:light[level=12]
setblock 245 91 245 minecraft:light[level=12]
setblock 245 91 252 minecraft:light[level=12]
setblock 245 91 259 minecraft:light[level=12]
setblock 245 91 266 minecraft:light[level=12]
setblock 246 91 229 minecraft:sea_lantern
setblock 246 91 231 minecraft:sea_lantern
setblock 246 91 233 minecraft:sea_lantern
setblock 246 91 235 minecraft:sea_lantern
setblock 246 91 237 minecraft:sea_lantern
setblock 247 91 230 minecraft:sea_lantern
setblock 247 91 232 minecraft:sea_lantern
setblock 247 91 234 minecraft:sea_lantern
setblock 247 91 236 minecraft:sea_lantern
setblock 248 91 229 minecraft:sea_lantern
setblock 248 91 231 minecraft:sea_lantern
setblock 248 91 233 minecraft:sea_lantern
setblock 248 91 235 minecraft:sea_lantern
setblock 248 91 237 minecraft:sea_lantern
fill 250 91 270 250 118 270 minecraft:black_concrete
setblock 252 91 238 minecraft:light[level=12]
setblock 252 91 245 minecraft:light[level=12]
setblock 252 91 252 minecraft:light[level=12]
setblock 252 91 259 minecraft:light[level=12]
setblock 259 91 238 minecraft:light[level=12]
setblock 259 91 245 minecraft:light[level=12]
setblock 259 91 252 minecraft:light[level=12]
setblock 259 91 259 minecraft:light[level=12]
setblock 266 91 229 minecraft:sea_lantern
setblock 266 91 231 minecraft:sea_lantern
setblock 266 91 233 minecraft:sea_lantern
setblock 266 91 235 minecraft:sea_lantern
setblock 266 91 237 minecraft:sea_lantern
setblock 266 91 239 minecraft:sea_lantern
setblock 266 91 245 minecraft:light[level=12]
setblock 266 91 252 minecraft:light[level=12]
setblock 266 91 259 minecraft:light[level=12]
setblock 266 91 265 minecraft:sea_lantern
setblock 266 91 267 minecraft:sea_lantern
setblock 266 91 269 minecraft:sea_lantern
setblock 267 91 230 minecraft:sea_lantern
setblock 267 91 232 minecraft:sea_lantern
setblock 267 91 234 minecraft:sea_lantern
setblock 267 91 236 minecraft:sea_lantern
setblock 267 91 238 minecraft:sea_lantern
setblock 267 91 264 minecraft:sea_lantern
setblock 267 91 266 minecraft:sea_lantern
setblock 267 91 268 minecraft:sea_lantern
setblock 268 91 229 minecraft:sea_lantern
setblock 268 91 231 minecraft:sea_lantern
setblock 268 91 233 minecraft:sea_lantern
setblock 268 91 235 minecraft:sea_lantern
setblock 268 91 237 minecraft:sea_lantern
setblock 268 91 239 minecraft:sea_lantern
fill 268 91 261 276 91 263 minecraft:light_gray_concrete
setblock 268 91 265 minecraft:sea_lantern
setblock 268 91 267 minecraft:sea_lantern
setblock 268 91 269 minecraft:sea_lantern
setblock 269 91 230 minecraft:sea_lantern
setblock 269 91 232 minecraft:sea_lantern
setblock 269 91 234 minecraft:sea_lantern
setblock 269 91 236 minecraft:sea_lantern
setblock 269 91 238 minecraft:sea_lantern
setblock 269 91 264 minecraft:sea_lantern
setblock 269 91 266 minecraft:sea_lantern
setblock 269 91 268 minecraft:sea_lantern
setblock 270 91 229 minecraft:sea_lantern
setblock 270 91 231 minecraft:sea_lantern
setblock 270 91 233 minecraft:sea_lantern
setblock 270 91 235 minecraft:sea_lantern
setblock 270 91 237 minecraft:sea_lantern
setblock 270 91 239 minecraft:sea_lantern
setblock 270 91 265 minecraft:sea_lantern
setblock 270 91 267 minecraft:sea_lantern
setblock 270 91 269 minecraft:sea_lantern
setblock 271 91 230 minecraft:sea_lantern
setblock 271 91 232 minecraft:sea_lantern
setblock 271 91 234 minecraft:sea_lantern
setblock 271 91 236 minecraft:sea_lantern
setblock 271 91 238 minecraft:sea_lantern
setblock 271 91 264 minecraft:sea_lantern
setblock 271 91 266 minecraft:sea_lantern
setblock 271 91 268 minecraft:sea_lantern
setblock 272 91 229 minecraft:sea_lantern
setblock 272 91 231 minecraft:sea_lantern
setblock 272 91 233 minecraft:sea_lantern
setblock 272 91 235 minecraft:sea_lantern
setblock 272 91 237 minecraft:sea_lantern
setblock 272 91 239 minecraft:sea_lantern
setblock 272 91 265 minecraft:sea_lantern
setblock 272 91 267 minecraft:sea_lantern
setblock 272 91 269 minecraft:sea_lantern
setblock 273 91 230 minecraft:sea_lantern
setblock 273 91 232 minecraft:sea_lantern
setblock 273 91 234 minecraft:sea_lantern
setblock 273 91 236 minecraft:sea_lantern
setblock 273 91 238 minecraft:sea_lantern
setblock 273 91 259 minecraft:light[level=12]
fill 273 91 264 276 91 269 minecraft:light_gray_concrete
setblock 274 91 229 minecraft:sea_lantern
setblock 274 91 231 minecraft:sea_lantern
setblock 274 91 233 minecraft:sea_lantern
setblock 274 91 235 minecraft:sea_lantern
setblock 274 91 237 minecraft:sea_lantern
setblock 274 91 239 minecraft:sea_lantern
setblock 275 91 230 minecraft:sea_lantern
setblock 275 91 232 minecraft:sea_lantern
setblock 275 91 234 minecraft:sea_lantern
setblock 275 91 236 minecraft:sea_lantern
setblock 275 91 238 minecraft:sea_lantern
setblock 276 91 229 minecraft:sea_lantern
setblock 276 91 231 minecraft:sea_lantern
setblock 276 91 233 minecraft:sea_lantern
setblock 276 91 235 minecraft:sea_lantern
setblock 276 91 237 minecraft:sea_lantern
setblock 276 91 239 minecraft:sea_lantern
setblock 277 91 257 minecraft:blue_concrete
fill 235 92 232 235 125 232 minecraft:black_concrete
setblock 235 92 233 minecraft:pearlescent_froglight
fill 235 92 234 235 162 234 minecraft:black_concrete
setblock 235 92 248 minecraft:verdant_froglight
fill 235 92 249 235 118 252 minecraft:black_concrete
setblock 236 92 230 minecraft:black_stained_glass
setblock 236 92 232 minecraft:black_stained_glass
setblock 236 92 234 minecraft:black_stained_glass
setblock 236 92 236 minecraft:black_stained_glass
setblock 236 92 243 minecraft:cyan_stained_glass
setblock 236 92 245 minecraft:black_stained_glass
setblock 236 92 247 minecraft:pearlescent_froglight
setblock 236 92 251 minecraft:ochre_froglight
fill 236 92 255 236 93 255 minecraft:gray_concrete
fill 236 92 257 236 93 257 minecraft:gray_concrete
fill 236 92 259 236 93 259 minecraft:gray_concrete
fill 236 92 261 236 93 261 minecraft:cyan_terracotta
setblock 236 92 262 minecraft:black_stained_glass
setblock 236 92 264 minecraft:black_stained_glass
setblock 236 92 266 minecraft:sea_lantern
setblock 236 92 268 minecraft:cyan_stained_glass
setblock 237 92 229 minecraft:black_stained_glass
setblock 237 92 237 minecraft:black_stained_glass
setblock 237 92 242 minecraft:ochre_froglight
fill 237 92 248 237 93 248 minecraft:gray_concrete
fill 237 92 250 237 93 250 minecraft:gray_concrete
fill 237 92 252 237 93 252 minecraft:gray_concrete
fill 237 92 254 237 93 254 minecraft:gray_concrete
setblock 237 92 255 minecraft:magenta_stained_glass
fill 237 92 256 237 93 256 minecraft:gray_concrete
fill 237 92 258 237 93 258 minecraft:gray_concrete
fill 237 92 260 237 93 260 minecraft:gray_concrete
setblock 237 92 261 minecraft:ochre_froglight
fill 237 92 262 237 93 262 minecraft:cyan_terracotta
setblock 237 92 269 minecraft:black_stained_glass
fill 238 92 229 238 93 229 minecraft:gray_concrete
fill 238 92 231 238 93 231 minecraft:gray_concrete
fill 238 92 233 238 93 233 minecraft:gray_concrete
fill 238 92 235 238 93 235 minecraft:gray_concrete
fill 238 92 237 238 93 237 minecraft:gray_concrete
fill 238 92 247 238 93 247 minecraft:gray_concrete
fill 238 92 249 238 93 249 minecraft:gray_concrete
fill 238 92 251 238 93 251 minecraft:gray_concrete
fill 238 92 253 238 93 253 minecraft:gray_concrete
fill 238 92 255 238 93 255 minecraft:gray_concrete
fill 238 92 257 238 93 257 minecraft:gray_concrete
fill 238 92 259 238 93 259 minecraft:gray_concrete
fill 238 92 261 238 93 261 minecraft:cyan_terracotta
setblock 239 92 229 minecraft:sea_lantern
fill 239 92 230 239 93 230 minecraft:gray_concrete
fill 239 92 232 239 93 232 minecraft:gray_concrete
fill 239 92 234 239 93 234 minecraft:gray_concrete
fill 239 92 236 239 93 236 minecraft:gray_concrete
setblock 239 92 237 minecraft:sea_lantern
setblock 239 92 242 minecraft:black_stained_glass
fill 239 92 248 239 93 248 minecraft:gray_concrete
fill 239 92 250 239 93 250 minecraft:gray_concrete
fill 239 92 252 239 93 252 minecraft:gray_concrete
fill 239 92 254 239 93 254 minecraft:gray_concrete
setblock 239 92 255 minecraft:ochre_froglight
fill 239 92 256 239 93 256 minecraft:gray_concrete
fill 239 92 258 239 93 258 minecraft:gray_concrete
fill 239 92 260 239 93 260 minecraft:gray_concrete
setblock 239 92 261 minecraft:ochre_froglight
fill 239 92 262 239 93 262 minecraft:cyan_terracotta
setblock 239 92 269 minecraft:cyan_stained_glass
fill 240 92 229 240 93 229 minecraft:gray_concrete
fill 240 92 231 240 93 231 minecraft:gray_concrete
fill 240 92 233 240 93 233 minecraft:gray_concrete
fill 240 92 235 240 93 235 minecraft:gray_concrete
fill 240 92 237 240 93 237 minecraft:gray_concrete
fill 240 92 247 240 93 247 minecraft:gray_concrete
fill 240 92 249 240 93 249 minecraft:gray_concrete
fill 240 92 251 240 93 251 minecraft:gray_concrete
fill 240 92 253 240 93 253 minecraft:gray_concrete
fill 240 92 255 240 93 255 minecraft:gray_concrete
fill 240 92 257 240 93 257 minecraft:gray_concrete
fill 240 92 259 240 93 259 minecraft:gray_concrete
fill 240 92 261 240 93 261 minecraft:cyan_terracotta
setblock 241 92 229 minecraft:black_stained_glass
fill 241 92 230 241 93 230 minecraft:gray_concrete
fill 241 92 232 241 93 232 minecraft:gray_concrete
fill 241 92 234 241 93 234 minecraft:gray_concrete
fill 241 92 236 241 93 236 minecraft:gray_concrete
setblock 241 92 237 minecraft:black_stained_glass
setblock 241 92 243 minecraft:cyan_stained_glass
setblock 241 92 245 minecraft:black_stained_glass
setblock 241 92 247 minecraft:cyan_stained_glass
setblock 241 92 249 minecraft:black_stained_glass
setblock 241 92 251 minecraft:cyan_stained_glass
fill 241 92 252 241 93 252 minecraft:gray_concrete
setblock 241 92 253 minecraft:black_stained_glass
fill 241 92 254 241 93 254 minecraft:gray_concrete
fill 241 92 256 241 93 256 minecraft:gray_concrete
fill 241 92 258 241 93 258 minecraft:gray_concrete
fill 241 92 260 241 93 260 minecraft:gray_concrete
setblock 241 92 261 minecraft:black_stained_glass
fill 241 92 262 241 93 262 minecraft:cyan_terracotta
setblock 241 92 269 minecraft:black_stained_glass
fill 242 92 229 242 93 229 minecraft:gray_concrete
fill 242 92 231 242 93 231 minecraft:gray_concrete
fill 242 92 233 242 93 233 minecraft:gray_concrete
fill 242 92 235 242 93 235 minecraft:gray_concrete
fill 242 92 237 242 93 237 minecraft:gray_concrete
fill 242 92 253 242 93 253 minecraft:gray_concrete
fill 242 92 255 242 93 255 minecraft:gray_concrete
fill 242 92 257 242 93 257 minecraft:gray_concrete
fill 242 92 259 242 93 259 minecraft:gray_concrete
fill 242 92 261 242 93 261 minecraft:cyan_terracotta
setblock 243 92 229 minecraft:black_stained_glass
fill 243 92 230 243 93 230 minecraft:gray_concrete
fill 243 92 232 243 93 232 minecraft:gray_concrete
fill 243 92 234 243 93 234 minecraft:gray_concrete
fill 243 92 236 243 93 236 minecraft:gray_concrete
setblock 243 92 237 minecraft:magenta_stained_glass
setblock 243 92 261 minecraft:black_stained_glass
setblock 243 92 269 minecraft:magenta_stained_glass
setblock 244 92 228 minecraft:verdant_froglight
fill 244 92 229 244 93 229 minecraft:gray_concrete
setblock 244 92 230 minecraft:sea_lantern
fill 244 92 231 244 93 231 minecraft:gray_concrete
setblock 244 92 232 minecraft:magenta_stained_glass
fill 244 92 233 244 93 233 minecraft:gray_concrete
setblock 244 92 234 minecraft:magenta_stained_glass
fill 244 92 235 244 93 235 minecraft:gray_concrete
fill 244 92 237 244 93 237 minecraft:gray_concrete
setblock 244 92 262 minecraft:sea_lantern
setblock 244 92 264 minecraft:black_stained_glass
setblock 244 92 266 minecraft:magenta_stained_glass
setblock 244 92 268 minecraft:sea_lantern
fill 245 92 230 245 93 230 minecraft:gray_concrete
fill 245 92 232 245 93 232 minecraft:gray_concrete
fill 245 92 234 245 93 234 minecraft:gray_concrete
fill 245 92 236 245 93 236 minecraft:gray_concrete
fill 246 92 229 246 93 229 minecraft:gray_concrete
fill 246 92 231 246 93 231 minecraft:gray_concrete
fill 246 92 233 246 93 233 minecraft:gray_concrete
fill 246 92 235 246 93 235 minecraft:gray_concrete
fill 246 92 237 246 93 237 minecraft:gray_concrete
fill 247 92 230 247 93 230 minecraft:gray_concrete
fill 247 92 232 247 93 232 minecraft:gray_concrete
fill 247 92 234 247 93 234 minecraft:gray_concrete
fill 247 92 236 247 93 236 minecraft:gray_concrete
fill 248 92 229 248 93 229 minecraft:gray_concrete
fill 248 92 231 248 93 231 minecraft:gray_concrete
fill 248 92 233 248 93 233 minecraft:gray_concrete
fill 248 92 235 248 93 235 minecraft:gray_concrete
fill 248 92 237 248 93 237 minecraft:gray_concrete
setblock 249 92 230 minecraft:black_stained_glass
setblock 249 92 232 minecraft:cyan_stained_glass
setblock 249 92 265 minecraft:ochre_froglight
setblock 249 92 267 minecraft:cyan_stained_glass
setblock 250 92 229 minecraft:light_blue_stained_glass
setblock 250 92 234 minecraft:ochre_froglight
setblock 250 92 264 minecraft:light_blue_stained_glass
setblock 250 92 269 minecraft:black_stained_glass
setblock 252 92 229 minecraft:pearlescent_froglight
setblock 252 92 234 minecraft:light_blue_stained_glass
setblock 252 92 264 minecraft:black_stained_glass
setblock 252 92 269 minecraft:ochre_froglight
setblock 254 92 229 minecraft:light_blue_stained_glass
setblock 254 92 234 minecraft:pearlescent_froglight
setblock 254 92 264 minecraft:ochre_froglight
setblock 254 92 269 minecraft:black_stained_glass
setblock 256 92 229 minecraft:black_stained_glass
setblock 256 92 234 minecraft:magenta_stained_glass
setblock 256 92 264 minecraft:sea_lantern
setblock 256 92 269 minecraft:ochre_froglight
setblock 258 92 229 minecraft:black_stained_glass
setblock 258 92 234 minecraft:magenta_stained_glass
setblock 258 92 264 minecraft:sea_lantern
setblock 258 92 269 minecraft:black_stained_glass
setblock 260 92 229 minecraft:magenta_stained_glass
setblock 260 92 234 minecraft:sea_lantern
setblock 260 92 264 minecraft:sea_lantern
setblock 260 92 269 minecraft:sea_lantern
setblock 262 92 230 minecraft:black_stained_glass
setblock 262 92 232 minecraft:cyan_stained_glass
setblock 262 92 265 minecraft:ochre_froglight
setblock 262 92 267 minecraft:sea_lantern
fill 266 92 229 266 93 229 minecraft:gray_concrete
fill 266 92 231 266 93 231 minecraft:gray_concrete
fill 266 92 233 266 93 233 minecraft:gray_concrete
fill 266 92 235 266 93 235 minecraft:gray_concrete
fill 266 92 237 266 93 237 minecraft:gray_concrete
fill 266 92 239 266 93 239 minecraft:gray_concrete
fill 266 92 265 266 94 265 minecraft:gray_concrete
fill 266 92 267 266 94 267 minecraft:gray_concrete
fill 266 92 269 266 94 269 minecraft:gray_concrete
fill 267 92 230 267 93 230 minecraft:gray_concrete
fill 267 92 232 267 93 232 minecraft:gray_concrete
fill 267 92 234 267 93 234 minecraft:gray_concrete
fill 267 92 236 267 93 236 minecraft:gray_concrete
fill 267 92 238 267 93 238 minecraft:gray_concrete
fill 267 92 264 267 94 264 minecraft:gray_concrete
fill 267 92 266 267 94 266 minecraft:gray_concrete
fill 267 92 268 267 94 268 minecraft:gray_concrete
fill 268 92 229 268 93 229 minecraft:cyan_terracotta
setblock 268 92 230 minecraft:black_stained_glass
fill 268 92 231 268 93 231 minecraft:cyan_terracotta
setblock 268 92 232 minecraft:black_stained_glass
fill 268 92 233 268 93 233 minecraft:cyan_terracotta
setblock 268 92 234 minecraft:black_stained_glass
fill 268 92 235 268 93 235 minecraft:cyan_terracotta
setblock 268 92 236 minecraft:black_stained_glass
fill 268 92 237 268 93 237 minecraft:cyan_terracotta
fill 268 92 239 268 93 239 minecraft:gray_concrete
fill 268 92 261 268 191 261 minecraft:light_gray_concrete
setblock 268 92 262 minecraft:ochre_froglight
fill 268 92 263 276 153 263 minecraft:light_gray_concrete
setblock 268 92 264 minecraft:ochre_froglight
fill 268 92 265 268 94 265 minecraft:gray_concrete
fill 268 92 267 268 94 267 minecraft:gray_concrete
setblock 268 92 268 minecraft:pearlescent_froglight
fill 268 92 269 268 94 269 minecraft:gray_concrete
setblock 269 92 229 minecraft:black_stained_glass
fill 269 92 230 269 93 230 minecraft:cyan_terracotta
fill 269 92 232 269 93 232 minecraft:cyan_terracotta
fill 269 92 234 269 93 234 minecraft:cyan_terracotta
fill 269 92 236 269 93 236 minecraft:cyan_terracotta
setblock 269 92 237 minecraft:black_stained_glass
fill 269 92 238 269 93 238 minecraft:gray_concrete
setblock 269 92 261 minecraft:light_blue_stained_glass
fill 269 92 262 275 191 262 minecraft:light_gray_concrete
fill 269 92 264 269 94 264 minecraft:gray_concrete
fill 269 92 266 269 94 266 minecraft:gray_concrete
fill 269 92 268 269 94 268 minecraft:gray_concrete
setblock 269 92 269 minecraft:black_stained_glass
fill 270 92 229 270 93 229 minecraft:cyan_terracotta
fill 270 92 231 270 93 231 minecraft:cyan_terracotta
fill 270 92 233 270 93 233 minecraft:cyan_terracotta
fill 270 92 235 270 93 235 minecraft:cyan_terracotta
fill 270 92 237 270 93 237 minecraft:cyan_terracotta
fill 270 92 239 270 93 239 minecraft:gray_concrete
fill 270 92 261 270 191 261 minecraft:light_gray_concrete
fill 270 92 265 270 94 265 minecraft:gray_concrete
fill 270 92 267 270 94 267 minecraft:gray_concrete
fill 270 92 269 270 94 269 minecraft:gray_concrete
setblock 271 92 229 minecraft:black_stained_glass
fill 271 92 230 271 93 230 minecraft:cyan_terracotta
fill 271 92 232 271 93 232 minecraft:cyan_terracotta
fill 271 92 234 271 93 234 minecraft:cyan_terracotta
fill 271 92 236 271 93 236 minecraft:cyan_terracotta
setblock 271 92 237 minecraft:black_stained_glass
fill 271 92 238 271 93 238 minecraft:gray_concrete
setblock 271 92 243 minecraft:cyan_stained_glass
setblock 271 92 245 minecraft:black_stained_glass
setblock 271 92 247 minecraft:black_stained_glass
setblock 271 92 249 minecraft:magenta_stained_glass
setblock 271 92 251 minecraft:magenta_stained_glass
setblock 271 92 253 minecraft:ochre_froglight
setblock 271 92 261 minecraft:black_stained_glass
fill 271 92 264 271 94 264 minecraft:gray_concrete
fill 271 92 266 271 94 266 minecraft:gray_concrete
fill 271 92 268 271 94 268 minecraft:gray_concrete
setblock 271 92 269 minecraft:black_stained_glass
fill 272 92 229 272 93 229 minecraft:cyan_terracotta
fill 272 92 231 272 93 231 minecraft:cyan_terracotta
fill 272 92 233 272 93 233 minecraft:cyan_terracotta
fill 272 92 235 272 93 235 minecraft:cyan_terracotta
fill 272 92 237 272 93 237 minecraft:cyan_terracotta
fill 272 92 239 272 93 239 minecraft:gray_concrete
setblock 272 92 242 minecraft:pearlescent_froglight
setblock 272 92 255 minecraft:pearlescent_froglight
fill 272 92 261 272 230 261 minecraft:light_gray_concrete
fill 272 92 265 272 94 265 minecraft:gray_concrete
fill 272 92 267 272 94 267 minecraft:gray_concrete
fill 272 92 269 272 94 269 minecraft:gray_concrete
setblock 273 92 229 minecraft:gray_concrete
fill 273 92 230 273 93 230 minecraft:cyan_terracotta
fill 273 92 232 273 93 232 minecraft:cyan_terracotta
fill 273 92 234 273 93 234 minecraft:cyan_terracotta
fill 273 92 236 273 93 236 minecraft:cyan_terracotta
setblock 273 92 237 minecraft:magenta_stained_glass
fill 273 92 238 273 93 238 minecraft:gray_concrete
setblock 273 92 261 minecraft:ochre_froglight
fill 273 92 264 275 146 268 minecraft:light_gray_concrete
setblock 273 92 269 minecraft:ochre_froglight
fill 274 92 229 274 93 229 minecraft:cyan_terracotta
fill 274 92 231 274 93 231 minecraft:cyan_terracotta
fill 274 92 233 274 93 233 minecraft:cyan_terracotta
fill 274 92 235 274 93 235 minecraft:cyan_terracotta
fill 274 92 237 274 93 237 minecraft:cyan_terracotta
fill 274 92 239 274 93 239 minecraft:gray_concrete
setblock 274 92 242 minecraft:black_stained_glass
setblock 274 92 255 minecraft:black_stained_glass
fill 274 92 261 274 237 261 minecraft:light_gray_concrete
fill 274 92 269 274 237 269 minecraft:light_gray_concrete
setblock 275 92 229 minecraft:sea_lantern
fill 275 92 230 275 93 230 minecraft:cyan_terracotta
fill 275 92 232 275 93 232 minecraft:cyan_terracotta
fill 275 92 234 275 93 234 minecraft:cyan_terracotta
fill 275 92 236 275 93 236 minecraft:cyan_terracotta
setblock 275 92 237 minecraft:ochre_froglight
fill 275 92 238 275 93 238 minecraft:gray_concrete
setblock 275 92 261 minecraft:magenta_stained_glass
setblock 275 92 269 minecraft:magenta_stained_glass
fill 276 92 229 276 93 229 minecraft:cyan_terracotta
setblock 276 92 230 minecraft:cyan_stained_glass
fill 276 92 231 276 93 231 minecraft:cyan_terracotta
setblock 276 92 232 minecraft:magenta_stained_glass
fill 276 92 233 276 93 233 minecraft:cyan_terracotta
setblock 276 92 234 minecraft:gray_concrete
fill 276 92 235 276 93 235 minecraft:cyan_terracotta
setblock 276 92 236 minecraft:cyan_stained_glass
fill 276 92 237 276 93 237 minecraft:cyan_terracotta
fill 276 92 239 276 93 239 minecraft:gray_concrete
setblock 276 92 243 minecraft:black_stained_glass
setblock 276 92 245 minecraft:magenta_stained_glass
setblock 276 92 247 minecraft:ochre_froglight
setblock 276 92 249 minecraft:black_stained_glass
setblock 276 92 251 minecraft:ochre_froglight
setblock 276 92 253 minecraft:magenta_stained_glass
fill 276 92 261 276 237 261 minecraft:light_gray_concrete
setblock 276 92 262 minecraft:ochre_froglight
setblock 276 92 264 minecraft:pearlescent_froglight
fill 276 92 265 276 237 265 minecraft:light_gray_concrete
setblock 276 92 266 minecraft:black_stained_glass
fill 276 92 267 276 237 267 minecraft:light_gray_concrete
setblock 276 92 268 minecraft:black_stained_glass
fill 276 92 269 276 237 269 minecraft:light_gray_concrete
fill 277 92 257 277 192 257 minecraft:black_concrete
fill 235 93 233 235 154 233 minecraft:black_concrete
fill 235 93 248 235 115 248 minecraft:black_concrete
fill 236 93 230 236 94 230 minecraft:light_gray_concrete
fill 236 93 232 236 94 232 minecraft:light_gray_concrete
fill 236 93 234 236 94 234 minecraft:light_gray_concrete
fill 236 93 236 236 94 236 minecraft:light_gray_concrete
schedule function dropper:buildpart/53_2 1t
