fill 272 206 278 272 207 278 minecraft:cut_sandstone
fill 272 206 280 272 207 280 minecraft:cut_sandstone
fill 272 206 282 272 207 282 minecraft:cut_sandstone
fill 272 206 284 272 207 284 minecraft:cut_sandstone
fill 272 206 286 272 207 286 minecraft:cut_sandstone
fill 273 206 277 273 207 277 minecraft:cut_sandstone
fill 273 206 279 273 207 279 minecraft:cut_sandstone
fill 273 206 281 273 207 281 minecraft:cut_sandstone
fill 273 206 283 273 207 283 minecraft:cut_sandstone
fill 273 206 285 273 207 285 minecraft:cut_sandstone
fill 273 206 287 273 207 287 minecraft:cut_sandstone
fill 274 206 278 274 207 278 minecraft:cut_sandstone
fill 274 206 280 274 207 280 minecraft:cut_sandstone
fill 274 206 282 274 207 282 minecraft:cut_sandstone
fill 274 206 284 274 207 284 minecraft:cut_sandstone
fill 274 206 286 274 207 286 minecraft:cut_sandstone
fill 275 206 277 276 207 277 minecraft:cut_sandstone
fill 275 206 279 276 207 279 minecraft:cut_sandstone
fill 275 206 281 276 207 281 minecraft:cut_sandstone
fill 275 206 283 275 207 283 minecraft:cut_sandstone
fill 275 206 285 275 207 285 minecraft:cut_sandstone
fill 275 206 287 275 207 287 minecraft:cut_sandstone
setblock 275 206 317 minecraft:blue_terracotta
fill 276 206 278 276 207 278 minecraft:cut_sandstone
fill 276 206 280 276 207 280 minecraft:cut_sandstone
fill 276 206 282 276 207 282 minecraft:cut_sandstone
fill 276 206 284 276 207 284 minecraft:cut_sandstone
fill 276 206 286 276 207 286 minecraft:cut_sandstone
fill 276 206 317 277 226 317 minecraft:smooth_sandstone
fill 277 206 276 277 211 279 minecraft:glowstone
fill 277 206 280 277 211 283 minecraft:smooth_sandstone
fill 277 206 286 277 218 287 minecraft:smooth_sandstone
fill 277 206 288 277 211 291 minecraft:glowstone
fill 277 206 292 277 267 292 minecraft:smooth_sandstone
fill 277 206 294 277 214 294 minecraft:smooth_sandstone
setblock 277 206 296 minecraft:black_terracotta
fill 277 206 299 277 308 299 minecraft:smooth_sandstone
fill 277 206 300 277 211 303 minecraft:glowstone
fill 277 206 309 277 258 309 minecraft:smooth_sandstone
fill 277 206 312 277 211 315 minecraft:glowstone
fill 277 206 316 277 209 316 minecraft:smooth_sandstone
setblock 238 207 278 minecraft:light[level=15]
setblock 238 207 285 minecraft:light[level=12]
setblock 238 207 286 minecraft:light[level=15]
setblock 238 207 292 minecraft:light[level=12]
setblock 238 207 294 minecraft:light[level=15]
setblock 238 207 299 minecraft:light[level=12]
setblock 238 207 302 minecraft:light[level=15]
setblock 238 207 306 minecraft:light[level=12]
setblock 238 207 310 minecraft:light[level=15]
setblock 238 207 313 minecraft:light[level=12]
setblock 245 207 285 minecraft:light[level=12]
setblock 245 207 292 minecraft:light[level=12]
setblock 245 207 299 minecraft:light[level=12]
setblock 245 207 306 minecraft:light[level=12]
setblock 245 207 313 minecraft:light[level=12]
setblock 246 207 286 minecraft:light[level=15]
setblock 246 207 294 minecraft:light[level=15]
setblock 246 207 302 minecraft:light[level=15]
setblock 246 207 310 minecraft:light[level=15]
fill 248 207 275 248 208 275 minecraft:smooth_sandstone
setblock 252 207 278 minecraft:light[level=12]
setblock 252 207 285 minecraft:light[level=12]
setblock 252 207 292 minecraft:light[level=12]
setblock 252 207 299 minecraft:light[level=12]
setblock 252 207 306 minecraft:light[level=12]
setblock 254 207 278 minecraft:light[level=15]
setblock 254 207 286 minecraft:light[level=15]
setblock 254 207 294 minecraft:light[level=15]
setblock 254 207 302 minecraft:light[level=15]
setblock 254 207 310 minecraft:light[level=15]
setblock 259 207 278 minecraft:light[level=12]
setblock 259 207 285 minecraft:light[level=12]
setblock 259 207 292 minecraft:light[level=12]
setblock 259 207 299 minecraft:light[level=12]
setblock 259 207 306 minecraft:light[level=12]
setblock 259 207 313 minecraft:light[level=12]
setblock 262 207 278 minecraft:light[level=15]
setblock 262 207 286 minecraft:light[level=15]
setblock 262 207 294 minecraft:light[level=15]
setblock 262 207 302 minecraft:light[level=15]
setblock 262 207 310 minecraft:light[level=15]
fill 265 207 317 265 308 317 minecraft:smooth_sandstone
setblock 266 207 278 minecraft:light[level=12]
setblock 266 207 285 minecraft:light[level=12]
setblock 266 207 292 minecraft:light[level=12]
setblock 266 207 299 minecraft:light[level=12]
setblock 266 207 306 minecraft:light[level=12]
setblock 266 207 313 minecraft:light[level=12]
setblock 266 207 317 minecraft:black_terracotta
setblock 270 207 294 minecraft:light[level=15]
setblock 270 207 302 minecraft:light[level=15]
setblock 270 207 310 minecraft:light[level=15]
setblock 273 207 292 minecraft:light[level=12]
setblock 273 207 299 minecraft:light[level=12]
setblock 273 207 306 minecraft:light[level=12]
setblock 273 207 313 minecraft:light[level=12]
fill 275 207 317 275 308 317 minecraft:smooth_sandstone
fill 277 207 296 277 259 296 minecraft:smooth_sandstone
fill 235 208 277 235 222 278 minecraft:smooth_sandstone
setblock 235 208 279 minecraft:orange_terracotta
fill 244 208 277 248 208 281 minecraft:lapis_block
fill 248 208 276 249 270 276 minecraft:cut_sandstone
fill 266 208 317 266 308 317 minecraft:smooth_sandstone
setblock 267 208 277 minecraft:glowstone
setblock 267 208 279 minecraft:glowstone
setblock 267 208 281 minecraft:glowstone
setblock 267 208 283 minecraft:glowstone
setblock 267 208 285 minecraft:glowstone
setblock 267 208 287 minecraft:glowstone
setblock 268 208 278 minecraft:glowstone
setblock 268 208 280 minecraft:glowstone
setblock 268 208 282 minecraft:glowstone
setblock 268 208 284 minecraft:glowstone
setblock 268 208 286 minecraft:glowstone
setblock 269 208 277 minecraft:glowstone
setblock 269 208 279 minecraft:glowstone
setblock 269 208 281 minecraft:glowstone
setblock 269 208 283 minecraft:glowstone
setblock 269 208 285 minecraft:glowstone
setblock 269 208 287 minecraft:glowstone
setblock 270 208 278 minecraft:glowstone
setblock 270 208 280 minecraft:glowstone
setblock 270 208 282 minecraft:glowstone
setblock 270 208 284 minecraft:glowstone
setblock 270 208 286 minecraft:glowstone
setblock 271 208 277 minecraft:glowstone
setblock 271 208 279 minecraft:glowstone
setblock 271 208 281 minecraft:glowstone
setblock 271 208 283 minecraft:glowstone
setblock 271 208 285 minecraft:glowstone
setblock 271 208 287 minecraft:glowstone
setblock 272 208 278 minecraft:glowstone
setblock 272 208 280 minecraft:glowstone
setblock 272 208 282 minecraft:glowstone
setblock 272 208 284 minecraft:glowstone
setblock 272 208 286 minecraft:glowstone
fill 272 208 304 272 210 304 minecraft:shroomlight
setblock 273 208 277 minecraft:glowstone
setblock 273 208 279 minecraft:glowstone
setblock 273 208 281 minecraft:glowstone
setblock 273 208 283 minecraft:glowstone
setblock 273 208 285 minecraft:glowstone
setblock 273 208 287 minecraft:glowstone
setblock 274 208 278 minecraft:glowstone
setblock 274 208 280 minecraft:glowstone
setblock 274 208 282 minecraft:glowstone
setblock 274 208 284 minecraft:glowstone
setblock 274 208 286 minecraft:glowstone
setblock 275 208 277 minecraft:glowstone
setblock 275 208 279 minecraft:glowstone
setblock 275 208 281 minecraft:glowstone
setblock 275 208 283 minecraft:glowstone
setblock 275 208 285 minecraft:glowstone
setblock 275 208 287 minecraft:glowstone
fill 276 208 277 276 214 277 minecraft:cut_sandstone
setblock 276 208 278 minecraft:glowstone
fill 276 208 279 276 214 279 minecraft:cut_sandstone
setblock 276 208 280 minecraft:glowstone
fill 276 208 281 276 214 281 minecraft:cut_sandstone
setblock 276 208 282 minecraft:glowstone
setblock 276 208 284 minecraft:glowstone
setblock 276 208 286 minecraft:glowstone
fill 235 209 279 235 308 279 minecraft:smooth_sandstone
fill 245 209 278 247 209 280 minecraft:lapis_block
setblock 248 209 275 minecraft:black_terracotta
fill 267 209 277 267 210 277 minecraft:cut_sandstone
fill 267 209 279 267 210 279 minecraft:cut_sandstone
fill 267 209 281 267 210 281 minecraft:cut_sandstone
fill 267 209 283 267 210 283 minecraft:cut_sandstone
fill 267 209 285 267 210 285 minecraft:cut_sandstone
fill 267 209 287 267 210 287 minecraft:cut_sandstone
fill 268 209 278 268 210 278 minecraft:cut_sandstone
fill 268 209 280 268 210 280 minecraft:cut_sandstone
fill 268 209 282 268 210 282 minecraft:cut_sandstone
fill 268 209 284 268 210 284 minecraft:cut_sandstone
fill 268 209 286 268 210 286 minecraft:cut_sandstone
fill 269 209 277 269 210 277 minecraft:cut_sandstone
fill 269 209 279 269 210 279 minecraft:cut_sandstone
fill 269 209 281 269 210 281 minecraft:cut_sandstone
fill 269 209 283 269 210 283 minecraft:cut_sandstone
fill 269 209 285 269 210 285 minecraft:cut_sandstone
fill 269 209 287 269 210 287 minecraft:cut_sandstone
fill 270 209 278 270 210 278 minecraft:cut_sandstone
fill 270 209 280 270 210 280 minecraft:cut_sandstone
fill 270 209 282 270 210 282 minecraft:cut_sandstone
fill 270 209 284 270 210 284 minecraft:cut_sandstone
fill 270 209 286 270 210 286 minecraft:cut_sandstone
fill 271 209 277 271 210 277 minecraft:cut_sandstone
fill 271 209 279 271 210 279 minecraft:cut_sandstone
fill 271 209 281 271 210 281 minecraft:cut_sandstone
fill 271 209 283 271 210 283 minecraft:cut_sandstone
fill 271 209 285 271 210 285 minecraft:cut_sandstone
fill 271 209 287 271 210 287 minecraft:cut_sandstone
fill 272 209 278 272 210 278 minecraft:cut_sandstone
fill 272 209 280 272 210 280 minecraft:cut_sandstone
fill 272 209 282 272 210 282 minecraft:cut_sandstone
fill 272 209 284 272 210 284 minecraft:cut_sandstone
fill 272 209 286 272 210 286 minecraft:cut_sandstone
fill 273 209 277 273 210 277 minecraft:cut_sandstone
fill 273 209 279 273 210 279 minecraft:cut_sandstone
fill 273 209 281 273 210 281 minecraft:cut_sandstone
fill 273 209 283 273 210 283 minecraft:cut_sandstone
fill 273 209 285 273 210 285 minecraft:cut_sandstone
fill 273 209 287 273 210 287 minecraft:cut_sandstone
fill 274 209 278 274 210 278 minecraft:cut_sandstone
fill 274 209 280 274 210 280 minecraft:cut_sandstone
fill 274 209 282 274 210 282 minecraft:cut_sandstone
fill 274 209 284 274 210 284 minecraft:cut_sandstone
fill 274 209 286 274 210 286 minecraft:cut_sandstone
fill 275 209 277 275 210 277 minecraft:cut_sandstone
fill 275 209 279 275 210 279 minecraft:cut_sandstone
fill 275 209 281 275 210 281 minecraft:cut_sandstone
fill 275 209 283 275 210 283 minecraft:cut_sandstone
fill 275 209 285 275 210 285 minecraft:cut_sandstone
fill 275 209 287 275 210 287 minecraft:cut_sandstone
fill 276 209 278 276 210 278 minecraft:cut_sandstone
fill 276 209 280 276 210 280 minecraft:cut_sandstone
fill 276 209 282 276 210 282 minecraft:cut_sandstone
fill 276 209 284 276 210 284 minecraft:cut_sandstone
fill 276 209 286 276 210 286 minecraft:cut_sandstone
fill 277 209 304 277 251 307 minecraft:smooth_sandstone
setblock 277 209 308 minecraft:black_terracotta
fill 246 210 279 246 211 279 minecraft:lapis_block
fill 248 210 275 248 308 275 minecraft:smooth_sandstone
setblock 252 210 275 minecraft:blue_terracotta
fill 253 210 275 253 228 275 minecraft:smooth_sandstone
fill 277 210 308 277 308 308 minecraft:smooth_sandstone
setblock 277 210 316 minecraft:blue_terracotta
fill 245 211 278 245 211 280 minecraft:lapis_block
fill 246 211 278 247 211 278 minecraft:lapis_block
fill 246 211 280 247 211 280 minecraft:lapis_block
setblock 247 211 279 minecraft:lapis_block
fill 252 211 275 252 264 275 minecraft:smooth_sandstone
setblock 267 211 277 minecraft:glowstone
setblock 267 211 279 minecraft:glowstone
setblock 267 211 281 minecraft:glowstone
setblock 267 211 283 minecraft:glowstone
setblock 267 211 285 minecraft:glowstone
setblock 267 211 287 minecraft:glowstone
setblock 268 211 278 minecraft:glowstone
setblock 268 211 280 minecraft:glowstone
setblock 268 211 282 minecraft:glowstone
setblock 268 211 284 minecraft:glowstone
setblock 268 211 286 minecraft:glowstone
setblock 269 211 277 minecraft:glowstone
setblock 269 211 279 minecraft:glowstone
setblock 269 211 281 minecraft:glowstone
setblock 269 211 283 minecraft:glowstone
setblock 269 211 285 minecraft:glowstone
setblock 269 211 287 minecraft:glowstone
setblock 270 211 278 minecraft:glowstone
setblock 270 211 280 minecraft:glowstone
setblock 270 211 282 minecraft:glowstone
setblock 270 211 284 minecraft:glowstone
setblock 270 211 286 minecraft:glowstone
setblock 271 211 277 minecraft:glowstone
setblock 271 211 279 minecraft:glowstone
setblock 271 211 281 minecraft:glowstone
setblock 271 211 283 minecraft:glowstone
setblock 271 211 285 minecraft:glowstone
setblock 271 211 287 minecraft:glowstone
setblock 272 211 278 minecraft:glowstone
setblock 272 211 280 minecraft:glowstone
setblock 272 211 282 minecraft:glowstone
setblock 272 211 284 minecraft:glowstone
setblock 272 211 286 minecraft:glowstone
setblock 273 211 277 minecraft:glowstone
setblock 273 211 279 minecraft:glowstone
setblock 273 211 281 minecraft:glowstone
setblock 273 211 283 minecraft:glowstone
setblock 273 211 285 minecraft:glowstone
setblock 273 211 287 minecraft:glowstone
setblock 274 211 278 minecraft:glowstone
setblock 274 211 280 minecraft:glowstone
setblock 274 211 282 minecraft:glowstone
setblock 274 211 284 minecraft:glowstone
setblock 274 211 286 minecraft:glowstone
setblock 275 211 277 minecraft:glowstone
setblock 275 211 279 minecraft:glowstone
setblock 275 211 281 minecraft:glowstone
setblock 275 211 283 minecraft:glowstone
setblock 275 211 285 minecraft:glowstone
setblock 275 211 287 minecraft:glowstone
setblock 276 211 278 minecraft:glowstone
setblock 276 211 280 minecraft:glowstone
setblock 276 211 282 minecraft:glowstone
setblock 276 211 284 minecraft:glowstone
setblock 276 211 286 minecraft:glowstone
setblock 277 211 297 minecraft:orange_terracotta
fill 277 211 316 277 279 316 minecraft:smooth_sandstone
fill 235 212 281 235 225 281 minecraft:smooth_sandstone
fill 235 212 282 235 212 283 minecraft:glowstone
fill 235 212 284 235 225 284 minecraft:smooth_sandstone
fill 235 212 293 235 225 293 minecraft:smooth_sandstone
fill 235 212 294 235 212 295 minecraft:glowstone
fill 235 212 296 235 225 296 minecraft:smooth_sandstone
fill 235 212 305 235 225 305 minecraft:smooth_sandstone
fill 235 212 306 235 212 307 minecraft:glowstone
fill 235 212 308 235 225 308 minecraft:smooth_sandstone
fill 235 212 317 235 225 317 minecraft:smooth_sandstone
fill 236 212 317 237 212 317 minecraft:glowstone
fill 238 212 317 238 225 317 minecraft:smooth_sandstone
fill 242 212 275 242 225 275 minecraft:smooth_sandstone
fill 243 212 275 244 212 275 minecraft:glowstone
fill 245 212 275 245 225 275 minecraft:smooth_sandstone
fill 247 212 317 247 225 317 minecraft:smooth_sandstone
fill 248 212 317 249 212 317 minecraft:glowstone
fill 250 212 317 250 225 317 minecraft:smooth_sandstone
fill 254 212 275 254 225 275 minecraft:smooth_sandstone
fill 255 212 275 256 212 275 minecraft:glowstone
fill 257 212 275 257 225 275 minecraft:smooth_sandstone
fill 259 212 317 259 225 317 minecraft:smooth_sandstone
fill 260 212 317 261 212 317 minecraft:glowstone
fill 262 212 317 262 225 317 minecraft:smooth_sandstone
fill 266 212 275 266 225 275 minecraft:smooth_sandstone
fill 267 212 275 268 212 275 minecraft:glowstone
fill 267 212 277 267 214 277 minecraft:cut_sandstone
fill 267 212 279 267 214 279 minecraft:cut_sandstone
fill 267 212 281 267 214 281 minecraft:cut_sandstone
fill 267 212 283 267 214 283 minecraft:cut_sandstone
fill 267 212 285 267 214 285 minecraft:cut_sandstone
fill 267 212 287 267 214 287 minecraft:cut_sandstone
fill 268 212 278 268 214 278 minecraft:cut_sandstone
fill 268 212 280 268 214 280 minecraft:cut_sandstone
fill 268 212 282 268 214 282 minecraft:cut_sandstone
fill 268 212 284 268 214 284 minecraft:cut_sandstone
fill 268 212 286 268 214 286 minecraft:cut_sandstone
fill 269 212 275 269 214 275 minecraft:smooth_sandstone
fill 269 212 277 269 214 277 minecraft:cut_sandstone
fill 269 212 279 269 214 279 minecraft:cut_sandstone
fill 269 212 281 269 214 281 minecraft:cut_sandstone
fill 269 212 283 269 214 283 minecraft:cut_sandstone
fill 269 212 285 269 214 285 minecraft:cut_sandstone
fill 269 212 287 269 214 287 minecraft:cut_sandstone
fill 270 212 278 270 214 278 minecraft:cut_sandstone
fill 270 212 280 270 214 280 minecraft:cut_sandstone
fill 270 212 282 270 214 282 minecraft:cut_sandstone
fill 270 212 284 270 214 284 minecraft:cut_sandstone
fill 270 212 286 270 214 286 minecraft:cut_sandstone
fill 271 212 277 271 214 277 minecraft:cut_sandstone
fill 271 212 279 271 214 279 minecraft:cut_sandstone
fill 271 212 281 271 214 281 minecraft:cut_sandstone
fill 271 212 283 271 214 283 minecraft:cut_sandstone
fill 271 212 285 271 214 285 minecraft:cut_sandstone
fill 271 212 287 271 214 287 minecraft:cut_sandstone
fill 271 212 317 271 225 317 minecraft:smooth_sandstone
fill 272 212 278 272 214 278 minecraft:cut_sandstone
fill 272 212 280 272 214 280 minecraft:cut_sandstone
fill 272 212 282 272 214 282 minecraft:cut_sandstone
fill 272 212 284 272 214 284 minecraft:cut_sandstone
fill 272 212 286 272 214 286 minecraft:cut_sandstone
fill 272 212 317 273 212 317 minecraft:glowstone
fill 273 212 277 273 214 277 minecraft:cut_sandstone
fill 273 212 279 273 214 279 minecraft:cut_sandstone
fill 273 212 281 273 214 281 minecraft:cut_sandstone
fill 273 212 283 273 214 283 minecraft:cut_sandstone
fill 273 212 285 273 214 285 minecraft:cut_sandstone
fill 273 212 287 273 214 287 minecraft:cut_sandstone
fill 274 212 278 274 214 278 minecraft:cut_sandstone
fill 274 212 280 274 214 280 minecraft:cut_sandstone
fill 274 212 282 274 214 282 minecraft:cut_sandstone
fill 274 212 284 274 214 284 minecraft:cut_sandstone
fill 274 212 286 274 214 286 minecraft:cut_sandstone
fill 274 212 317 274 225 317 minecraft:smooth_sandstone
fill 275 212 277 275 214 277 minecraft:cut_sandstone
fill 275 212 279 275 214 279 minecraft:cut_sandstone
fill 275 212 281 275 214 281 minecraft:cut_sandstone
fill 275 212 283 275 214 283 minecraft:cut_sandstone
fill 275 212 285 275 214 285 minecraft:cut_sandstone
fill 275 212 287 275 214 287 minecraft:cut_sandstone
fill 276 212 278 276 214 278 minecraft:cut_sandstone
fill 276 212 280 276 214 280 minecraft:cut_sandstone
fill 276 212 282 276 214 282 minecraft:cut_sandstone
fill 276 212 284 276 270 284 minecraft:cut_sandstone
fill 276 212 286 276 270 286 minecraft:cut_sandstone
fill 277 212 276 277 225 276 minecraft:smooth_sandstone
fill 277 212 277 277 212 278 minecraft:glowstone
fill 277 212 279 277 225 280 minecraft:smooth_sandstone
setblock 277 212 281 minecraft:blue_terracotta
fill 277 212 282 277 238 283 minecraft:smooth_sandstone
fill 277 212 288 277 225 288 minecraft:smooth_sandstone
fill 277 212 289 277 212 290 minecraft:glowstone
fill 277 212 291 277 225 291 minecraft:smooth_sandstone
fill 277 212 297 277 227 297 minecraft:smooth_sandstone
fill 277 212 300 277 223 300 minecraft:smooth_sandstone
fill 277 212 301 277 212 302 minecraft:glowstone
fill 277 212 303 277 225 303 minecraft:smooth_sandstone
fill 277 212 312 277 225 312 minecraft:smooth_sandstone
fill 277 212 313 277 212 314 minecraft:glowstone
fill 277 212 315 277 225 315 minecraft:smooth_sandstone
fill 235 213 282 235 225 283 minecraft:smooth_sandstone
fill 235 213 294 235 225 295 minecraft:smooth_sandstone
fill 235 213 306 235 225 307 minecraft:smooth_sandstone
fill 236 213 317 237 225 317 minecraft:smooth_sandstone
setblock 238 213 278 minecraft:light[level=12]
setblock 238 213 285 minecraft:light[level=12]
setblock 238 213 292 minecraft:light[level=12]
setblock 238 213 299 minecraft:light[level=12]
setblock 238 213 306 minecraft:light[level=12]
setblock 238 213 313 minecraft:light[level=12]
fill 243 213 275 244 221 275 minecraft:smooth_sandstone
setblock 245 213 278 minecraft:light[level=12]
setblock 245 213 285 minecraft:light[level=12]
setblock 245 213 292 minecraft:light[level=12]
setblock 245 213 299 minecraft:light[level=12]
setblock 245 213 306 minecraft:light[level=12]
setblock 245 213 313 minecraft:light[level=12]
fill 248 213 317 249 225 317 minecraft:smooth_sandstone
setblock 251 213 317 minecraft:lapis_block
setblock 252 213 278 minecraft:light[level=12]
setblock 252 213 285 minecraft:light[level=12]
setblock 252 213 292 minecraft:light[level=12]
setblock 252 213 299 minecraft:light[level=12]
setblock 252 213 306 minecraft:light[level=12]
fill 252 213 317 252 275 317 minecraft:smooth_sandstone
fill 255 213 275 256 225 275 minecraft:smooth_sandstone
setblock 259 213 278 minecraft:light[level=12]
setblock 259 213 285 minecraft:light[level=12]
setblock 259 213 292 minecraft:light[level=12]
setblock 259 213 299 minecraft:light[level=12]
setblock 259 213 306 minecraft:light[level=12]
setblock 259 213 313 minecraft:light[level=12]
fill 260 213 317 261 225 317 minecraft:smooth_sandstone
setblock 266 213 278 minecraft:light[level=12]
setblock 266 213 285 minecraft:light[level=12]
setblock 266 213 292 minecraft:light[level=12]
setblock 266 213 299 minecraft:light[level=12]
setblock 266 213 306 minecraft:light[level=12]
setblock 266 213 313 minecraft:light[level=12]
fill 267 213 275 268 225 275 minecraft:smooth_sandstone
fill 272 213 317 273 214 317 minecraft:smooth_sandstone
setblock 273 213 292 minecraft:light[level=12]
setblock 273 213 299 minecraft:light[level=12]
setblock 273 213 306 minecraft:light[level=12]
setblock 273 213 313 minecraft:light[level=12]
fill 277 213 277 277 225 278 minecraft:smooth_sandstone
fill 277 213 281 277 249 281 minecraft:smooth_sandstone
fill 277 213 289 277 215 290 minecraft:smooth_sandstone
fill 277 213 301 277 225 302 minecraft:smooth_sandstone
fill 277 213 313 277 225 314 minecraft:smooth_sandstone
fill 251 214 317 251 263 317 minecraft:smooth_sandstone
setblock 238 215 278 minecraft:light[level=15]
setblock 238 215 286 minecraft:light[level=15]
setblock 238 215 294 minecraft:light[level=15]
setblock 238 215 302 minecraft:light[level=15]
setblock 238 215 310 minecraft:light[level=15]
setblock 246 215 278 minecraft:light[level=15]
setblock 246 215 286 minecraft:light[level=15]
setblock 246 215 294 minecraft:light[level=15]
setblock 246 215 302 minecraft:light[level=15]
setblock 246 215 310 minecraft:light[level=15]
fill 247 215 313 255 215 315 minecraft:lapis_block
setblock 254 215 278 minecraft:light[level=15]
setblock 254 215 286 minecraft:light[level=15]
setblock 254 215 294 minecraft:light[level=15]
setblock 254 215 302 minecraft:light[level=15]
setblock 254 215 310 minecraft:light[level=15]
fill 254 215 316 256 270 316 minecraft:cut_sandstone
setblock 262 215 278 minecraft:light[level=15]
setblock 262 215 286 minecraft:light[level=15]
setblock 262 215 294 minecraft:light[level=15]
setblock 262 215 302 minecraft:light[level=15]
setblock 262 215 310 minecraft:light[level=15]
fill 268 215 278 275 215 286 minecraft:lapis_block
setblock 269 215 275 minecraft:lapis_block
setblock 270 215 294 minecraft:light[level=15]
setblock 270 215 302 minecraft:light[level=15]
setblock 270 215 310 minecraft:light[level=15]
fill 272 215 317 272 225 317 minecraft:smooth_sandstone
setblock 273 215 317 minecraft:lapis_block
setblock 277 215 294 minecraft:orange_terracotta
fill 237 216 275 238 275 275 minecraft:smooth_sandstone
setblock 239 216 275 minecraft:orange_terracotta
fill 248 216 314 254 216 314 minecraft:lapis_block
fill 269 216 275 269 225 275 minecraft:smooth_sandstone
fill 269 216 279 274 216 285 minecraft:lapis_block
fill 273 216 317 273 225 317 minecraft:smooth_sandstone
setblock 277 216 289 minecraft:orange_terracotta
fill 277 216 290 277 225 290 minecraft:smooth_sandstone
fill 277 216 294 277 226 294 minecraft:smooth_sandstone
fill 239 217 275 239 223 275 minecraft:smooth_sandstone
fill 249 217 313 253 217 315 minecraft:lapis_block
setblock 270 217 275 minecraft:black_terracotta
fill 270 217 280 273 217 284 minecraft:lapis_block
fill 271 217 275 277 225 275 minecraft:smooth_sandstone
fill 277 217 289 277 225 289 minecraft:smooth_sandstone
setblock 235 218 280 minecraft:orange_terracotta
fill 250 218 312 252 218 316 minecraft:lapis_block
fill 270 218 275 270 258 275 minecraft:smooth_sandstone
fill 271 218 281 272 218 283 minecraft:lapis_block
fill 235 219 280 235 285 280 minecraft:smooth_sandstone
setblock 238 219 278 minecraft:light[level=12]
setblock 238 219 285 minecraft:light[level=12]
setblock 238 219 292 minecraft:light[level=12]
setblock 238 219 299 minecraft:light[level=12]
setblock 238 219 306 minecraft:light[level=12]
setblock 238 219 313 minecraft:light[level=12]
setblock 245 219 278 minecraft:light[level=12]
setblock 245 219 285 minecraft:light[level=12]
setblock 245 219 292 minecraft:light[level=12]
setblock 245 219 299 minecraft:light[level=12]
setblock 245 219 306 minecraft:light[level=12]
setblock 245 219 313 minecraft:light[level=12]
setblock 252 219 278 minecraft:light[level=12]
setblock 252 219 285 minecraft:light[level=12]
setblock 252 219 292 minecraft:light[level=12]
setblock 252 219 299 minecraft:light[level=12]
setblock 252 219 306 minecraft:light[level=12]
setblock 252 219 313 minecraft:light[level=12]
setblock 259 219 278 minecraft:light[level=12]
setblock 259 219 285 minecraft:light[level=12]
setblock 259 219 292 minecraft:light[level=12]
setblock 259 219 299 minecraft:light[level=12]
setblock 259 219 306 minecraft:light[level=12]
setblock 259 219 313 minecraft:light[level=12]
setblock 266 219 278 minecraft:light[level=12]
setblock 266 219 285 minecraft:light[level=12]
setblock 266 219 292 minecraft:light[level=12]
setblock 266 219 299 minecraft:light[level=12]
setblock 266 219 306 minecraft:light[level=12]
setblock 266 219 313 minecraft:light[level=12]
setblock 273 219 278 minecraft:light[level=12]
setblock 273 219 285 minecraft:light[level=12]
setblock 273 219 292 minecraft:light[level=12]
setblock 273 219 299 minecraft:light[level=12]
setblock 273 219 306 minecraft:light[level=12]
setblock 273 219 313 minecraft:light[level=12]
fill 277 219 286 277 250 286 minecraft:smooth_sandstone
setblock 277 219 287 minecraft:blue_terracotta
fill 235 220 289 235 242 291 minecraft:smooth_sandstone
setblock 235 220 292 minecraft:lapis_block
setblock 236 220 275 minecraft:orange_terracotta
fill 237 220 285 237 225 287 minecraft:cut_sandstone
fill 237 220 297 237 225 299 minecraft:cut_sandstone
fill 237 220 309 237 225 311 minecraft:cut_sandstone
fill 243 220 315 245 225 315 minecraft:cut_sandstone
fill 244 220 317 244 308 317 minecraft:smooth_sandstone
setblock 245 220 317 minecraft:lapis_block
fill 246 220 317 246 283 317 minecraft:smooth_sandstone
fill 247 220 277 249 225 277 minecraft:cut_sandstone
fill 255 220 315 257 225 315 minecraft:cut_sandstone
fill 259 220 277 261 225 277 minecraft:cut_sandstone
fill 267 220 315 269 225 315 minecraft:cut_sandstone
fill 271 220 277 273 225 277 minecraft:cut_sandstone
fill 275 220 285 275 225 287 minecraft:cut_sandstone
fill 275 220 297 275 225 299 minecraft:cut_sandstone
fill 275 220 309 275 225 311 minecraft:cut_sandstone
fill 277 220 287 277 301 287 minecraft:smooth_sandstone
fill 235 221 292 235 225 292 minecraft:smooth_sandstone
setblock 235 221 310 minecraft:blue_terracotta
fill 236 221 275 236 308 275 minecraft:smooth_sandstone
fill 245 221 317 245 308 317 minecraft:smooth_sandstone
fill 259 221 275 261 225 275 minecraft:smooth_sandstone
setblock 262 221 275 minecraft:orange_terracotta
fill 263 221 275 263 225 275 minecraft:smooth_sandstone
fill 235 222 310 235 308 310 minecraft:smooth_sandstone
fill 243 222 275 243 225 275 minecraft:smooth_sandstone
setblock 244 222 275 minecraft:blue_terracotta
fill 260 222 309 264 223 313 minecraft:chiseled_sandstone
fill 262 222 275 262 308 275 minecraft:smooth_sandstone
fill 262 222 314 262 222 315 minecraft:chiseled_sandstone
fill 263 222 317 263 297 317 minecraft:smooth_sandstone
setblock 264 222 317 minecraft:lapis_block
fill 235 223 277 235 308 277 minecraft:smooth_sandstone
setblock 235 223 278 minecraft:blue_terracotta
setblock 235 223 285 minecraft:orange_terracotta
fill 235 223 286 235 308 286 minecraft:smooth_sandstone
setblock 238 223 278 minecraft:light[level=15]
setblock 238 223 286 minecraft:light[level=15]
setblock 238 223 294 minecraft:light[level=15]
setblock 238 223 302 minecraft:light[level=15]
setblock 238 223 310 minecraft:light[level=15]
setblock 244 223 275 minecraft:lapis_block
setblock 246 223 278 minecraft:light[level=15]
setblock 246 223 286 minecraft:light[level=15]
setblock 246 223 294 minecraft:light[level=15]
setblock 246 223 302 minecraft:light[level=15]
setblock 246 223 310 minecraft:light[level=15]
setblock 254 223 278 minecraft:light[level=15]
setblock 254 223 286 minecraft:light[level=15]
setblock 254 223 294 minecraft:light[level=15]
setblock 254 223 302 minecraft:light[level=15]
setblock 254 223 310 minecraft:light[level=15]
setblock 262 223 278 minecraft:light[level=15]
setblock 262 223 286 minecraft:light[level=15]
setblock 262 223 294 minecraft:light[level=15]
setblock 262 223 302 minecraft:light[level=15]
fill 264 223 317 264 244 317 minecraft:smooth_sandstone
setblock 270 223 278 minecraft:light[level=15]
setblock 270 223 286 minecraft:light[level=15]
setblock 270 223 294 minecraft:light[level=15]
setblock 270 223 302 minecraft:light[level=15]
setblock 270 223 310 minecraft:light[level=15]
fill 235 224 278 235 308 278 minecraft:smooth_sandstone
fill 235 224 285 235 273 285 minecraft:smooth_sandstone
setblock 239 224 275 minecraft:blue_terracotta
fill 239 224 317 239 236 317 minecraft:smooth_sandstone
setblock 240 224 317 minecraft:orange_terracotta
fill 241 224 317 241 243 317 minecraft:smooth_sandstone
fill 244 224 275 244 225 275 minecraft:smooth_sandstone
fill 261 224 310 263 225 312 minecraft:cut_sandstone
setblock 277 224 300 minecraft:orange_terracotta
fill 235 225 297 235 246 297 minecraft:smooth_sandstone
setblock 235 225 298 minecraft:orange_terracotta
fill 235 225 299 235 233 304 minecraft:smooth_sandstone
fill 236 225 279 236 225 284 minecraft:chiseled_sandstone
fill 236 225 291 236 225 296 minecraft:chiseled_sandstone
fill 236 225 303 236 225 308 minecraft:chiseled_sandstone
fill 236 225 315 236 225 316 minecraft:chiseled_sandstone
fill 237 225 316 240 225 316 minecraft:chiseled_sandstone
setblock 238 225 278 minecraft:light[level=12]
setblock 238 225 285 minecraft:light[level=12]
setblock 238 225 292 minecraft:light[level=12]
setblock 238 225 299 minecraft:light[level=12]
setblock 238 225 306 minecraft:light[level=12]
setblock 238 225 313 minecraft:light[level=12]
fill 239 225 275 239 250 275 minecraft:smooth_sandstone
fill 240 225 276 245 225 276 minecraft:chiseled_sandstone
fill 240 225 317 240 289 317 minecraft:smooth_sandstone
setblock 245 225 278 minecraft:light[level=12]
setblock 245 225 285 minecraft:light[level=12]
setblock 245 225 292 minecraft:light[level=12]
setblock 245 225 299 minecraft:light[level=12]
setblock 245 225 306 minecraft:light[level=12]
setblock 245 225 313 minecraft:light[level=12]
fill 247 225 316 252 225 316 minecraft:chiseled_sandstone
fill 252 225 276 257 225 276 minecraft:chiseled_sandstone
setblock 252 225 278 minecraft:light[level=12]
setblock 252 225 285 minecraft:light[level=12]
setblock 252 225 292 minecraft:light[level=12]
setblock 252 225 299 minecraft:light[level=12]
setblock 252 225 306 minecraft:light[level=12]
setblock 252 225 313 minecraft:light[level=12]
setblock 259 225 278 minecraft:light[level=12]
setblock 259 225 285 minecraft:light[level=12]
setblock 259 225 292 minecraft:light[level=12]
setblock 259 225 299 minecraft:light[level=12]
setblock 259 225 306 minecraft:light[level=12]
setblock 259 225 313 minecraft:light[level=12]
fill 259 225 316 264 225 316 minecraft:chiseled_sandstone
fill 264 225 276 269 225 276 minecraft:chiseled_sandstone
setblock 266 225 278 minecraft:light[level=12]
setblock 266 225 285 minecraft:light[level=12]
setblock 266 225 292 minecraft:light[level=12]
setblock 266 225 299 minecraft:light[level=12]
setblock 266 225 306 minecraft:light[level=12]
setblock 266 225 313 minecraft:light[level=12]
fill 271 225 316 276 225 316 minecraft:chiseled_sandstone
setblock 273 225 278 minecraft:light[level=12]
setblock 273 225 285 minecraft:light[level=12]
setblock 273 225 292 minecraft:light[level=12]
setblock 273 225 299 minecraft:light[level=12]
setblock 273 225 306 minecraft:light[level=12]
setblock 273 225 313 minecraft:light[level=12]
fill 276 225 276 276 225 281 minecraft:chiseled_sandstone
fill 276 225 288 276 225 293 minecraft:chiseled_sandstone
fill 276 225 300 276 225 305 minecraft:chiseled_sandstone
fill 276 225 312 276 225 315 minecraft:chiseled_sandstone
setblock 277 225 300 minecraft:smooth_sandstone
fill 235 226 281 235 231 284 minecraft:glowstone
setblock 235 226 292 minecraft:orange_terracotta
fill 235 226 293 235 231 296 minecraft:glowstone
fill 235 226 298 235 308 298 minecraft:smooth_sandstone
fill 235 226 305 235 231 308 minecraft:glowstone
fill 235 226 317 238 231 317 minecraft:glowstone
fill 242 226 275 245 231 275 minecraft:glowstone
fill 246 226 296 247 227 297 minecraft:sandstone
fill 247 226 317 250 231 317 minecraft:glowstone
fill 254 226 275 257 231 275 minecraft:glowstone
fill 259 226 275 259 271 275 minecraft:smooth_sandstone
fill 259 226 317 262 231 317 minecraft:glowstone
setblock 260 226 275 minecraft:orange_terracotta
fill 261 226 275 261 256 275 minecraft:smooth_sandstone
fill 261 226 311 263 228 311 minecraft:cut_sandstone
fill 262 226 310 262 228 310 minecraft:cut_sandstone
fill 262 226 312 262 228 312 minecraft:cut_sandstone
setblock 263 226 275 minecraft:blue_terracotta
fill 266 226 275 269 231 275 minecraft:glowstone
fill 271 226 275 272 258 275 minecraft:smooth_sandstone
fill 271 226 317 274 231 317 minecraft:glowstone
setblock 273 226 275 minecraft:orange_terracotta
fill 274 226 275 277 250 275 minecraft:smooth_sandstone
fill 277 226 276 277 231 279 minecraft:glowstone
fill 277 226 280 277 243 280 minecraft:smooth_sandstone
fill 277 226 288 277 231 291 minecraft:glowstone
fill 277 226 300 277 231 303 minecraft:glowstone
fill 277 226 312 277 231 315 minecraft:glowstone
fill 235 227 292 235 230 292 minecraft:smooth_sandstone
fill 260 227 275 260 308 275 minecraft:smooth_sandstone
fill 263 227 275 263 283 275 minecraft:smooth_sandstone
fill 273 227 275 273 308 275 minecraft:smooth_sandstone
setblock 276 227 317 minecraft:blue_terracotta
setblock 277 227 294 minecraft:blue_terracotta
fill 277 227 317 277 308 317 minecraft:smooth_sandstone
fill 269 228 285 273 229 289 minecraft:chiseled_sandstone
fill 274 228 287 275 228 287 minecraft:chiseled_sandstone
fill 276 228 317 276 308 317 minecraft:smooth_sandstone
fill 277 228 294 277 308 294 minecraft:smooth_sandstone
setblock 277 228 297 minecraft:lapis_block
setblock 246 229 275 minecraft:orange_terracotta
fill 247 229 275 247 308 275 minecraft:smooth_sandstone
setblock 253 229 275 minecraft:black_terracotta
fill 262 229 311 262 233 311 minecraft:cut_sandstone
fill 277 229 297 277 277 297 minecraft:smooth_sandstone
fill 246 230 275 246 285 275 minecraft:smooth_sandstone
fill 253 230 275 253 308 275 minecraft:smooth_sandstone
fill 270 230 286 272 231 288 minecraft:cut_sandstone
setblock 235 231 292 minecraft:blue_terracotta
setblock 238 231 278 minecraft:light[level=15]
setblock 238 231 285 minecraft:light[level=12]
setblock 238 231 286 minecraft:light[level=15]
setblock 238 231 292 minecraft:light[level=12]
setblock 238 231 294 minecraft:light[level=15]
setblock 238 231 299 minecraft:light[level=12]
setblock 238 231 302 minecraft:light[level=15]
setblock 238 231 306 minecraft:light[level=12]
setblock 238 231 310 minecraft:light[level=15]
setblock 238 231 313 minecraft:light[level=12]
setblock 245 231 278 minecraft:light[level=12]
setblock 245 231 285 minecraft:light[level=12]
setblock 245 231 292 minecraft:light[level=12]
setblock 245 231 299 minecraft:light[level=12]
setblock 245 231 306 minecraft:light[level=12]
setblock 245 231 313 minecraft:light[level=12]
setblock 246 231 278 minecraft:light[level=15]
setblock 246 231 286 minecraft:light[level=15]
setblock 246 231 294 minecraft:light[level=15]
setblock 246 231 302 minecraft:light[level=15]
setblock 246 231 310 minecraft:light[level=15]
setblock 252 231 278 minecraft:light[level=12]
setblock 252 231 285 minecraft:light[level=12]
setblock 252 231 292 minecraft:light[level=12]
setblock 252 231 299 minecraft:light[level=12]
setblock 252 231 306 minecraft:light[level=12]
setblock 252 231 313 minecraft:light[level=12]
setblock 254 231 278 minecraft:light[level=15]
setblock 254 231 286 minecraft:light[level=15]
setblock 254 231 294 minecraft:light[level=15]
setblock 254 231 302 minecraft:light[level=15]
setblock 254 231 310 minecraft:light[level=15]
setblock 259 231 278 minecraft:light[level=12]
setblock 259 231 285 minecraft:light[level=12]
setblock 259 231 292 minecraft:light[level=12]
setblock 259 231 299 minecraft:light[level=12]
setblock 259 231 306 minecraft:light[level=12]
setblock 259 231 313 minecraft:light[level=12]
setblock 262 231 278 minecraft:light[level=15]
setblock 262 231 286 minecraft:light[level=15]
setblock 262 231 294 minecraft:light[level=15]
setblock 262 231 302 minecraft:light[level=15]
setblock 262 231 310 minecraft:light[level=15]
setblock 266 231 278 minecraft:light[level=12]
setblock 266 231 285 minecraft:light[level=12]
setblock 266 231 292 minecraft:light[level=12]
setblock 266 231 299 minecraft:light[level=12]
setblock 266 231 306 minecraft:light[level=12]
setblock 266 231 313 minecraft:light[level=12]
setblock 270 231 278 minecraft:light[level=15]
setblock 270 231 294 minecraft:light[level=15]
setblock 270 231 302 minecraft:light[level=15]
setblock 270 231 310 minecraft:light[level=15]
setblock 273 231 278 minecraft:light[level=12]
setblock 273 231 285 minecraft:light[level=12]
setblock 273 231 292 minecraft:light[level=12]
setblock 273 231 299 minecraft:light[level=12]
setblock 273 231 306 minecraft:light[level=12]
setblock 273 231 313 minecraft:light[level=12]
fill 235 232 281 235 245 281 minecraft:smooth_sandstone
fill 235 232 282 235 232 283 minecraft:glowstone
fill 235 232 284 235 245 284 minecraft:smooth_sandstone
fill 235 232 292 235 245 293 minecraft:smooth_sandstone
fill 235 232 294 235 232 295 minecraft:glowstone
fill 235 232 296 235 245 296 minecraft:smooth_sandstone
fill 235 232 305 235 245 305 minecraft:smooth_sandstone
fill 235 232 306 235 232 307 minecraft:glowstone
fill 235 232 308 235 245 308 minecraft:smooth_sandstone
fill 235 232 317 235 245 317 minecraft:smooth_sandstone
fill 236 232 317 237 232 317 minecraft:glowstone
fill 238 232 317 238 245 317 minecraft:smooth_sandstone
fill 242 232 275 242 245 275 minecraft:smooth_sandstone
fill 242 232 276 244 233 276 minecraft:cut_sandstone
fill 242 232 315 244 233 315 minecraft:cut_sandstone
fill 243 232 275 244 232 275 minecraft:glowstone
fill 245 232 275 245 245 275 minecraft:smooth_sandstone
fill 247 232 317 247 245 317 minecraft:smooth_sandstone
fill 248 232 317 249 232 317 minecraft:glowstone
fill 250 232 317 250 245 317 minecraft:smooth_sandstone
fill 254 232 275 254 245 275 minecraft:smooth_sandstone
fill 255 232 275 256 232 275 minecraft:glowstone
fill 257 232 275 257 245 275 minecraft:smooth_sandstone
fill 259 232 317 259 245 317 minecraft:smooth_sandstone
fill 260 232 317 261 232 317 minecraft:glowstone
fill 262 232 317 262 245 317 minecraft:smooth_sandstone
fill 266 232 275 266 233 275 minecraft:smooth_sandstone
fill 267 232 275 268 232 275 minecraft:glowstone
fill 269 232 275 269 243 275 minecraft:smooth_sandstone
fill 270 232 287 272 234 287 minecraft:cut_sandstone
fill 271 232 286 271 234 286 minecraft:cut_sandstone
fill 271 232 288 271 234 288 minecraft:cut_sandstone
fill 271 232 317 271 241 317 minecraft:smooth_sandstone
fill 272 232 317 273 232 317 minecraft:glowstone
fill 274 232 317 274 245 317 minecraft:smooth_sandstone
fill 277 232 276 277 245 276 minecraft:smooth_sandstone
fill 277 232 277 277 232 278 minecraft:glowstone
fill 277 232 279 277 245 279 minecraft:smooth_sandstone
fill 277 232 288 277 245 288 minecraft:smooth_sandstone
fill 277 232 289 277 232 290 minecraft:glowstone
fill 277 232 291 277 245 291 minecraft:smooth_sandstone
fill 277 232 300 277 245 300 minecraft:smooth_sandstone
fill 277 232 301 277 232 302 minecraft:glowstone
fill 277 232 303 277 239 303 minecraft:smooth_sandstone
fill 277 232 312 277 245 312 minecraft:smooth_sandstone
fill 277 232 313 277 232 314 minecraft:glowstone
fill 277 232 315 277 245 315 minecraft:smooth_sandstone
fill 235 233 282 235 245 283 minecraft:smooth_sandstone
fill 235 233 294 235 237 295 minecraft:smooth_sandstone
fill 235 233 306 235 245 307 minecraft:smooth_sandstone
fill 236 233 317 237 245 317 minecraft:smooth_sandstone
fill 242 233 277 244 234 277 minecraft:cut_sandstone
fill 242 233 314 244 234 314 minecraft:cut_sandstone
fill 243 233 275 244 236 275 minecraft:smooth_sandstone
fill 243 233 278 243 235 278 minecraft:cut_sandstone
fill 243 233 313 243 235 313 minecraft:cut_sandstone
fill 248 233 317 249 245 317 minecraft:smooth_sandstone
fill 255 233 275 255 245 275 minecraft:smooth_sandstone
setblock 256 233 275 minecraft:black_terracotta
fill 260 233 317 261 245 317 minecraft:smooth_sandstone
fill 267 233 275 268 245 275 minecraft:smooth_sandstone
fill 272 233 317 273 242 317 minecraft:smooth_sandstone
fill 277 233 277 277 234 278 minecraft:smooth_sandstone
fill 277 233 289 277 234 290 minecraft:smooth_sandstone
fill 277 233 301 277 245 302 minecraft:smooth_sandstone
fill 277 233 313 277 245 314 minecraft:smooth_sandstone
fill 235 234 299 235 243 302 minecraft:smooth_sandstone
setblock 235 234 303 minecraft:orange_terracotta
fill 235 234 304 235 252 304 minecraft:smooth_sandstone
fill 242 234 278 242 235 278 minecraft:cut_sandstone
fill 242 234 313 242 235 313 minecraft:cut_sandstone
setblock 243 234 276 minecraft:cut_sandstone
fill 243 234 279 243 236 279 minecraft:cut_sandstone
fill 243 234 312 243 236 312 minecraft:cut_sandstone
setblock 243 234 315 minecraft:cut_sandstone
fill 244 234 278 244 235 278 minecraft:cut_sandstone
fill 244 234 313 244 235 313 minecraft:cut_sandstone
fill 252 234 277 252 248 277 minecraft:blue_wool
fill 256 234 275 256 245 275 minecraft:smooth_sandstone
setblock 262 234 311 minecraft:glowstone
setblock 266 234 275 minecraft:black_terracotta
fill 235 235 303 235 281 303 minecraft:smooth_sandstone
fill 242 235 279 242 236 280 minecraft:cut_sandstone
fill 242 235 311 242 236 312 minecraft:cut_sandstone
setblock 243 235 276 minecraft:lapis_block
setblock 243 235 277 minecraft:cut_sandstone
fill 243 235 280 244 236 280 minecraft:cut_sandstone
fill 243 235 311 244 236 311 minecraft:cut_sandstone
setblock 243 235 314 minecraft:cut_sandstone
setblock 243 235 315 minecraft:lapis_block
fill 244 235 279 244 236 279 minecraft:cut_sandstone
fill 244 235 312 244 236 312 minecraft:cut_sandstone
fill 250 235 277 251 248 277 minecraft:blue_wool
fill 253 235 277 254 248 277 minecraft:blue_wool
fill 266 235 275 266 245 275 minecraft:smooth_sandstone
fill 271 235 287 271 239 287 minecraft:cut_sandstone
setblock 277 235 277 minecraft:orange_terracotta
fill 277 235 278 277 245 278 minecraft:smooth_sandstone
fill 277 235 289 277 245 289 minecraft:smooth_sandstone
setblock 277 235 290 minecraft:lapis_block
fill 242 236 281 244 237 281 minecraft:cut_sandstone
fill 242 236 310 244 237 310 minecraft:cut_sandstone
setblock 243 236 278 minecraft:lapis_block
fill 243 236 282 243 238 282 minecraft:cut_sandstone
fill 243 236 309 243 238 309 minecraft:cut_sandstone
setblock 243 236 313 minecraft:lapis_block
fill 255 236 317 256 289 317 minecraft:smooth_sandstone
setblock 257 236 317 minecraft:blue_terracotta
fill 258 236 317 258 270 317 minecraft:smooth_sandstone
fill 268 236 317 269 255 317 minecraft:smooth_sandstone
setblock 270 236 317 minecraft:blue_terracotta
fill 277 236 277 277 245 277 minecraft:smooth_sandstone
fill 277 236 290 277 245 290 minecraft:smooth_sandstone
setblock 238 237 278 minecraft:light[level=12]
setblock 238 237 285 minecraft:light[level=12]
setblock 238 237 292 minecraft:light[level=12]
setblock 238 237 299 minecraft:light[level=12]
setblock 238 237 306 minecraft:light[level=12]
setblock 238 237 313 minecraft:light[level=12]
setblock 239 237 317 minecraft:blue_terracotta
fill 242 237 282 242 238 282 minecraft:cut_sandstone
fill 242 237 309 242 238 309 minecraft:cut_sandstone
setblock 243 237 275 minecraft:lapis_block
setblock 243 237 279 minecraft:lapis_block
setblock 243 237 280 minecraft:cut_sandstone
fill 243 237 283 243 239 283 minecraft:cut_sandstone
fill 243 237 308 243 239 308 minecraft:cut_sandstone
setblock 243 237 311 minecraft:cut_sandstone
setblock 243 237 312 minecraft:lapis_block
fill 244 237 275 244 245 275 minecraft:smooth_sandstone
fill 244 237 282 244 238 282 minecraft:cut_sandstone
fill 244 237 309 244 238 309 minecraft:cut_sandstone
setblock 245 237 278 minecraft:light[level=12]
setblock 245 237 285 minecraft:light[level=12]
setblock 245 237 292 minecraft:light[level=12]
setblock 245 237 299 minecraft:light[level=12]
setblock 245 237 306 minecraft:light[level=12]
setblock 245 237 313 minecraft:light[level=12]
setblock 252 237 278 minecraft:light[level=12]
setblock 252 237 285 minecraft:light[level=12]
setblock 252 237 292 minecraft:light[level=12]
setblock 252 237 299 minecraft:light[level=12]
setblock 252 237 306 minecraft:light[level=12]
setblock 252 237 313 minecraft:light[level=12]
fill 257 237 317 257 244 317 minecraft:smooth_sandstone
setblock 259 237 278 minecraft:light[level=12]
setblock 259 237 285 minecraft:light[level=12]
setblock 259 237 292 minecraft:light[level=12]
setblock 259 237 299 minecraft:light[level=12]
setblock 259 237 306 minecraft:light[level=12]
setblock 259 237 313 minecraft:light[level=12]
setblock 266 237 278 minecraft:light[level=12]
setblock 266 237 285 minecraft:light[level=12]
setblock 266 237 292 minecraft:light[level=12]
setblock 266 237 299 minecraft:light[level=12]
setblock 266 237 306 minecraft:light[level=12]
setblock 266 237 313 minecraft:light[level=12]
fill 270 237 317 270 284 317 minecraft:smooth_sandstone
setblock 273 237 278 minecraft:light[level=12]
setblock 273 237 285 minecraft:light[level=12]
setblock 273 237 292 minecraft:light[level=12]
setblock 273 237 299 minecraft:light[level=12]
setblock 273 237 306 minecraft:light[level=12]
setblock 273 237 313 minecraft:light[level=12]
setblock 235 238 294 minecraft:blue_terracotta
fill 235 238 295 235 241 295 minecraft:smooth_sandstone
fill 239 238 317 239 292 317 minecraft:smooth_sandstone
fill 242 238 283 242 238 284 minecraft:cut_sandstone
fill 242 238 307 242 238 308 minecraft:cut_sandstone
fill 243 238 275 243 242 275 minecraft:smooth_sandstone
setblock 243 238 280 minecraft:lapis_block
setblock 243 238 281 minecraft:cut_sandstone
fill 243 238 284 243 239 285 minecraft:cut_sandstone
fill 243 238 306 243 239 307 minecraft:cut_sandstone
setblock 243 238 310 minecraft:cut_sandstone
setblock 243 238 311 minecraft:lapis_block
fill 244 238 283 244 238 284 minecraft:cut_sandstone
fill 244 238 307 244 238 308 minecraft:cut_sandstone
fill 272 238 307 272 241 307 minecraft:iron_block
setblock 277 238 311 minecraft:orange_terracotta
fill 235 239 294 235 245 294 minecraft:smooth_sandstone
setblock 238 239 278 minecraft:light[level=15]
setblock 238 239 286 minecraft:light[level=15]
setblock 238 239 294 minecraft:light[level=15]
setblock 238 239 302 minecraft:light[level=15]
setblock 238 239 310 minecraft:light[level=15]
fill 242 239 284 242 239 286 minecraft:cut_sandstone
fill 242 239 305 242 239 307 minecraft:cut_sandstone
setblock 243 239 282 minecraft:lapis_block
fill 243 239 286 243 241 287 minecraft:cut_sandstone
fill 243 239 304 243 241 305 minecraft:cut_sandstone
setblock 243 239 309 minecraft:lapis_block
fill 244 239 284 244 239 286 minecraft:cut_sandstone
fill 244 239 305 244 239 307 minecraft:cut_sandstone
setblock 246 239 278 minecraft:light[level=15]
setblock 246 239 286 minecraft:light[level=15]
setblock 246 239 294 minecraft:light[level=15]
setblock 246 239 302 minecraft:light[level=15]
setblock 246 239 310 minecraft:light[level=15]
setblock 254 239 278 minecraft:light[level=15]
setblock 254 239 286 minecraft:light[level=15]
setblock 254 239 294 minecraft:light[level=15]
setblock 254 239 302 minecraft:light[level=15]
setblock 254 239 310 minecraft:light[level=15]
setblock 262 239 278 minecraft:light[level=15]
setblock 262 239 286 minecraft:light[level=15]
setblock 262 239 294 minecraft:light[level=15]
setblock 262 239 302 minecraft:light[level=15]
setblock 262 239 310 minecraft:light[level=15]
setblock 270 239 278 minecraft:light[level=15]
setblock 270 239 286 minecraft:light[level=15]
setblock 270 239 294 minecraft:light[level=15]
setblock 270 239 302 minecraft:light[level=15]
setblock 270 239 310 minecraft:light[level=15]
setblock 277 239 282 minecraft:lapis_block
fill 277 239 283 277 269 283 minecraft:smooth_sandstone
setblock 277 239 293 minecraft:lapis_block
fill 277 239 311 277 308 311 minecraft:smooth_sandstone
fill 237 240 285 237 245 287 minecraft:cut_sandstone
fill 237 240 297 237 245 299 minecraft:cut_sandstone
fill 237 240 309 237 245 311 minecraft:cut_sandstone
fill 242 240 286 242 240 288 minecraft:cut_sandstone
fill 242 240 303 242 240 305 minecraft:cut_sandstone
fill 243 240 283 243 240 284 minecraft:lapis_block
setblock 243 240 285 minecraft:cut_sandstone
fill 243 240 288 243 242 289 minecraft:cut_sandstone
fill 243 240 302 243 242 303 minecraft:cut_sandstone
setblock 243 240 306 minecraft:cut_sandstone
fill 243 240 307 243 240 308 minecraft:lapis_block
fill 243 240 315 245 245 315 minecraft:cut_sandstone
fill 244 240 286 244 240 288 minecraft:cut_sandstone
fill 244 240 303 244 240 305 minecraft:cut_sandstone
fill 247 240 277 249 245 277 minecraft:cut_sandstone
fill 255 240 315 257 245 315 minecraft:cut_sandstone
fill 259 240 277 261 245 277 minecraft:cut_sandstone
fill 267 240 315 269 245 315 minecraft:cut_sandstone
fill 271 240 277 273 245 277 minecraft:cut_sandstone
setblock 271 240 287 minecraft:glowstone
fill 275 240 285 275 245 287 minecraft:cut_sandstone
fill 275 240 297 275 245 299 minecraft:cut_sandstone
fill 275 240 309 275 245 311 minecraft:cut_sandstone
fill 277 240 282 277 308 282 minecraft:smooth_sandstone
fill 277 240 293 277 308 293 minecraft:smooth_sandstone
setblock 277 240 303 minecraft:black_terracotta
fill 242 241 287 242 241 291 minecraft:cut_sandstone
fill 242 241 300 242 241 304 minecraft:cut_sandstone
setblock 243 241 285 minecraft:lapis_block
fill 243 241 290 243 242 294 minecraft:cut_sandstone
fill 243 241 297 243 242 301 minecraft:cut_sandstone
setblock 243 241 306 minecraft:lapis_block
fill 244 241 287 244 241 291 minecraft:cut_sandstone
fill 244 241 300 244 241 304 minecraft:cut_sandstone
fill 245 241 309 249 242 313 minecraft:chiseled_sandstone
fill 247 241 314 247 241 315 minecraft:chiseled_sandstone
fill 277 241 303 277 245 303 minecraft:smooth_sandstone
setblock 235 242 295 minecraft:lapis_block
fill 242 242 290 242 242 301 minecraft:cut_sandstone
setblock 243 242 287 minecraft:lapis_block
fill 243 242 295 244 243 296 minecraft:cut_sandstone
setblock 243 242 304 minecraft:lapis_block
fill 244 242 290 244 242 294 minecraft:cut_sandstone
fill 244 242 297 244 242 301 minecraft:cut_sandstone
setblock 271 242 317 minecraft:lapis_block
fill 272 242 302 274 242 312 minecraft:chiseled_sandstone
fill 275 242 302 275 242 308 minecraft:chiseled_sandstone
setblock 275 242 312 minecraft:chiseled_sandstone
fill 235 243 289 235 248 290 minecraft:smooth_sandstone
setblock 235 243 291 minecraft:blue_terracotta
fill 235 243 295 235 245 295 minecraft:smooth_sandstone
setblock 238 243 278 minecraft:light[level=12]
setblock 238 243 285 minecraft:light[level=12]
setblock 238 243 292 minecraft:light[level=12]
setblock 238 243 299 minecraft:light[level=12]
setblock 238 243 306 minecraft:light[level=12]
setblock 238 243 313 minecraft:light[level=12]
fill 242 243 295 242 243 296 minecraft:cut_sandstone
setblock 243 243 275 minecraft:lapis_block
fill 243 243 289 243 243 291 minecraft:lapis_block
fill 243 243 292 243 243 294 minecraft:cut_sandstone
fill 243 243 297 243 243 299 minecraft:cut_sandstone
fill 243 243 300 243 243 302 minecraft:lapis_block
setblock 245 243 278 minecraft:light[level=12]
setblock 245 243 285 minecraft:light[level=12]
setblock 245 243 292 minecraft:light[level=12]
setblock 245 243 299 minecraft:light[level=12]
setblock 245 243 306 minecraft:light[level=12]
setblock 245 243 313 minecraft:light[level=12]
fill 246 243 310 248 244 312 minecraft:cut_sandstone
setblock 252 243 278 minecraft:light[level=12]
setblock 252 243 285 minecraft:light[level=12]
setblock 252 243 292 minecraft:light[level=12]
setblock 252 243 299 minecraft:light[level=12]
setblock 252 243 306 minecraft:light[level=12]
setblock 252 243 313 minecraft:light[level=12]
fill 255 243 277 255 245 277 minecraft:shroomlight
setblock 259 243 278 minecraft:light[level=12]
setblock 259 243 285 minecraft:light[level=12]
setblock 259 243 292 minecraft:light[level=12]
setblock 259 243 299 minecraft:light[level=12]
setblock 259 243 306 minecraft:light[level=12]
setblock 259 243 313 minecraft:light[level=12]
setblock 266 243 278 minecraft:light[level=12]
setblock 266 243 285 minecraft:light[level=12]
setblock 266 243 292 minecraft:light[level=12]
setblock 266 243 299 minecraft:light[level=12]
setblock 266 243 306 minecraft:light[level=12]
setblock 266 243 313 minecraft:light[level=12]
fill 271 243 317 271 245 317 minecraft:smooth_sandstone
fill 272 243 302 274 243 312 minecraft:cut_sandstone
setblock 272 243 317 minecraft:lapis_block
setblock 273 243 278 minecraft:light[level=12]
setblock 273 243 285 minecraft:light[level=12]
setblock 273 243 292 minecraft:light[level=12]
setblock 273 243 299 minecraft:light[level=12]
setblock 273 243 313 minecraft:light[level=12]
fill 273 243 317 273 245 317 minecraft:smooth_sandstone
fill 275 243 302 275 243 308 minecraft:cut_sandstone
setblock 275 243 312 minecraft:cut_sandstone
fill 235 244 291 235 308 291 minecraft:smooth_sandstone
fill 235 244 299 235 253 299 minecraft:smooth_sandstone
setblock 235 244 300 minecraft:orange_terracotta
fill 235 244 301 235 267 302 minecraft:smooth_sandstone
setblock 241 244 317 minecraft:blue_terracotta
fill 243 244 275 243 245 275 minecraft:smooth_sandstone
fill 243 244 292 243 244 299 minecraft:lapis_block
setblock 269 244 275 minecraft:black_terracotta
fill 272 244 302 272 244 312 minecraft:lapis_block
fill 272 244 317 272 245 317 minecraft:smooth_sandstone
fill 276 244 306 276 247 308 minecraft:glowstone
fill 276 244 309 276 270 310 minecraft:cut_sandstone
setblock 277 244 280 minecraft:black_terracotta
fill 235 245 300 235 251 300 minecraft:smooth_sandstone
fill 236 245 279 236 245 284 minecraft:chiseled_sandstone
fill 236 245 291 236 245 296 minecraft:chiseled_sandstone
fill 236 245 303 236 245 308 minecraft:chiseled_sandstone
fill 236 245 315 236 245 316 minecraft:chiseled_sandstone
fill 237 245 316 240 245 316 minecraft:chiseled_sandstone
fill 240 245 276 245 245 276 minecraft:chiseled_sandstone
fill 241 245 317 241 262 317 minecraft:smooth_sandstone
fill 246 245 311 248 247 311 minecraft:cut_sandstone
fill 247 245 310 247 247 310 minecraft:cut_sandstone
fill 247 245 312 247 247 312 minecraft:cut_sandstone
fill 247 245 316 252 245 316 minecraft:chiseled_sandstone
fill 252 245 276 257 245 276 minecraft:chiseled_sandstone
setblock 257 245 317 minecraft:orange_terracotta
fill 259 245 316 264 245 316 minecraft:chiseled_sandstone
fill 264 245 276 269 245 276 minecraft:chiseled_sandstone
setblock 264 245 317 minecraft:lapis_block
setblock 269 245 275 minecraft:smooth_sandstone
fill 271 245 316 276 245 316 minecraft:chiseled_sandstone
setblock 272 245 302 minecraft:cut_sandstone
setblock 272 245 307 minecraft:cut_sandstone
setblock 272 245 312 minecraft:cut_sandstone
fill 276 245 276 276 245 281 minecraft:chiseled_sandstone
fill 276 245 288 276 245 293 minecraft:chiseled_sandstone
fill 276 245 300 276 245 305 minecraft:chiseled_sandstone
fill 276 245 312 276 245 315 minecraft:chiseled_sandstone
fill 277 245 280 277 308 280 minecraft:smooth_sandstone
fill 235 246 281 235 251 284 minecraft:glowstone
fill 235 246 292 235 271 292 minecraft:smooth_sandstone
fill 235 246 293 235 251 296 minecraft:glowstone
fill 235 246 305 235 251 308 minecraft:glowstone
fill 235 246 317 238 251 317 minecraft:glowstone
fill 242 246 275 245 251 275 minecraft:glowstone
fill 247 246 317 250 251 317 minecraft:glowstone
fill 254 246 275 257 251 275 minecraft:glowstone
fill 257 246 317 257 308 317 minecraft:smooth_sandstone
fill 259 246 317 262 251 317 minecraft:glowstone
fill 264 246 317 264 265 317 minecraft:smooth_sandstone
fill 266 246 275 269 251 275 minecraft:glowstone
fill 271 246 317 274 251 317 minecraft:glowstone
fill 277 246 276 277 251 279 minecraft:glowstone
fill 277 246 288 277 251 291 minecraft:glowstone
fill 277 246 300 277 251 303 minecraft:glowstone
setblock 277 246 310 minecraft:blue_terracotta
fill 277 246 312 277 251 315 minecraft:glowstone
setblock 235 247 297 minecraft:orange_terracotta
setblock 238 247 278 minecraft:light[level=15]
setblock 238 247 286 minecraft:light[level=15]
setblock 238 247 294 minecraft:light[level=15]
setblock 238 247 302 minecraft:light[level=15]
setblock 238 247 310 minecraft:light[level=15]
setblock 246 247 278 minecraft:light[level=15]
setblock 246 247 286 minecraft:light[level=15]
setblock 246 247 294 minecraft:light[level=15]
setblock 246 247 302 minecraft:light[level=15]
setblock 246 247 310 minecraft:light[level=15]
setblock 254 247 278 minecraft:light[level=15]
setblock 254 247 286 minecraft:light[level=15]
setblock 254 247 294 minecraft:light[level=15]
setblock 254 247 302 minecraft:light[level=15]
setblock 254 247 310 minecraft:light[level=15]
setblock 262 247 278 minecraft:light[level=15]
setblock 262 247 286 minecraft:light[level=15]
setblock 262 247 294 minecraft:light[level=15]
setblock 262 247 302 minecraft:light[level=15]
setblock 262 247 310 minecraft:light[level=15]
setblock 270 247 278 minecraft:light[level=15]
setblock 270 247 286 minecraft:light[level=15]
setblock 270 247 294 minecraft:light[level=15]
setblock 270 247 302 minecraft:light[level=15]
setblock 270 247 310 minecraft:light[level=15]
setblock 277 247 284 minecraft:lapis_block
fill 277 247 310 277 249 310 minecraft:smooth_sandstone
fill 235 248 297 235 308 297 minecraft:smooth_sandstone
fill 247 248 311 247 252 311 minecraft:cut_sandstone
fill 276 248 308 276 270 308 minecraft:cut_sandstone
fill 277 248 284 277 267 284 minecraft:smooth_sandstone
setblock 235 249 289 minecraft:blue_terracotta
fill 235 249 290 235 308 290 minecraft:smooth_sandstone
setblock 238 249 278 minecraft:light[level=12]
setblock 238 249 285 minecraft:light[level=12]
setblock 238 249 292 minecraft:light[level=12]
setblock 238 249 299 minecraft:light[level=12]
setblock 238 249 306 minecraft:light[level=12]
setblock 238 249 313 minecraft:light[level=12]
setblock 245 249 278 minecraft:light[level=12]
setblock 245 249 285 minecraft:light[level=12]
setblock 245 249 292 minecraft:light[level=12]
setblock 245 249 299 minecraft:light[level=12]
setblock 245 249 306 minecraft:light[level=12]
setblock 245 249 313 minecraft:light[level=12]
fill 249 249 277 255 250 277 minecraft:iron_block
setblock 252 249 278 minecraft:light[level=12]
setblock 252 249 285 minecraft:light[level=12]
setblock 252 249 292 minecraft:light[level=12]
setblock 252 249 299 minecraft:light[level=12]
setblock 252 249 306 minecraft:light[level=12]
setblock 252 249 313 minecraft:light[level=12]
setblock 259 249 278 minecraft:light[level=12]
setblock 259 249 285 minecraft:light[level=12]
setblock 259 249 292 minecraft:light[level=12]
setblock 259 249 299 minecraft:light[level=12]
setblock 259 249 306 minecraft:light[level=12]
setblock 259 249 313 minecraft:light[level=12]
setblock 266 249 278 minecraft:light[level=12]
setblock 266 249 285 minecraft:light[level=12]
setblock 266 249 292 minecraft:light[level=12]
setblock 266 249 299 minecraft:light[level=12]
setblock 266 249 306 minecraft:light[level=12]
setblock 266 249 313 minecraft:light[level=12]
setblock 273 249 278 minecraft:light[level=12]
setblock 273 249 285 minecraft:light[level=12]
setblock 273 249 292 minecraft:light[level=12]
setblock 273 249 299 minecraft:light[level=12]
setblock 273 249 306 minecraft:light[level=12]
setblock 273 249 313 minecraft:light[level=12]
fill 235 250 289 235 254 289 minecraft:smooth_sandstone
setblock 277 250 281 minecraft:lapis_block
setblock 277 250 310 minecraft:lapis_block
setblock 239 251 275 minecraft:black_terracotta
fill 274 251 275 274 308 275 minecraft:smooth_sandstone
setblock 275 251 275 minecraft:blue_terracotta
fill 276 251 275 277 277 275 minecraft:smooth_sandstone
fill 277 251 281 277 308 281 minecraft:smooth_sandstone
setblock 277 251 286 minecraft:lapis_block
fill 277 251 310 277 308 310 minecraft:smooth_sandstone
fill 235 252 281 235 265 281 minecraft:smooth_sandstone
fill 235 252 282 235 252 283 minecraft:glowstone
fill 235 252 284 235 265 284 minecraft:smooth_sandstone
fill 235 252 293 235 265 293 minecraft:smooth_sandstone
fill 235 252 294 235 252 295 minecraft:glowstone
fill 235 252 296 235 265 296 minecraft:smooth_sandstone
setblock 235 252 300 minecraft:lapis_block
fill 235 252 305 235 265 305 minecraft:smooth_sandstone
fill 235 252 306 235 252 307 minecraft:glowstone
fill 235 252 308 235 263 308 minecraft:smooth_sandstone
fill 235 252 317 235 265 317 minecraft:smooth_sandstone
fill 236 252 317 237 252 317 minecraft:glowstone
fill 238 252 317 238 265 317 minecraft:smooth_sandstone
setblock 239 252 275 minecraft:smooth_sandstone
fill 242 252 275 242 265 275 minecraft:smooth_sandstone
fill 243 252 275 244 252 275 minecraft:glowstone
fill 245 252 275 245 255 275 minecraft:smooth_sandstone
fill 247 252 317 247 265 317 minecraft:smooth_sandstone
fill 248 252 317 249 252 317 minecraft:glowstone
fill 250 252 317 250 255 317 minecraft:smooth_sandstone
fill 254 252 275 254 255 275 minecraft:smooth_sandstone
fill 255 252 275 256 252 275 minecraft:glowstone
fill 257 252 275 257 265 275 minecraft:smooth_sandstone
fill 259 252 317 259 265 317 minecraft:smooth_sandstone
fill 260 252 317 261 252 317 minecraft:glowstone
fill 262 252 317 262 265 317 minecraft:smooth_sandstone
fill 266 252 275 266 254 275 minecraft:smooth_sandstone
fill 267 252 275 268 252 275 minecraft:glowstone
fill 269 252 275 269 265 275 minecraft:smooth_sandstone
fill 271 252 317 271 265 317 minecraft:smooth_sandstone
fill 272 252 317 273 252 317 minecraft:glowstone
fill 274 252 317 274 265 317 minecraft:smooth_sandstone
fill 275 252 275 275 254 275 minecraft:smooth_sandstone
fill 277 252 276 277 260 276 minecraft:smooth_sandstone
fill 277 252 277 277 252 278 minecraft:glowstone
fill 277 252 279 277 265 279 minecraft:smooth_sandstone
fill 277 252 286 277 308 286 minecraft:smooth_sandstone
fill 277 252 288 277 265 288 minecraft:smooth_sandstone
fill 277 252 289 277 252 290 minecraft:glowstone
fill 277 252 291 277 265 291 minecraft:smooth_sandstone
fill 277 252 300 277 265 300 minecraft:smooth_sandstone
fill 277 252 301 277 252 302 minecraft:glowstone
fill 277 252 303 277 265 303 minecraft:smooth_sandstone
setblock 277 252 304 minecraft:black_terracotta
fill 277 252 305 277 292 307 minecraft:smooth_sandstone
fill 277 252 312 277 265 312 minecraft:smooth_sandstone
fill 277 252 313 277 252 314 minecraft:glowstone
fill 277 252 315 277 265 315 minecraft:smooth_sandstone
fill 235 253 282 235 255 283 minecraft:smooth_sandstone
fill 235 253 294 235 262 295 minecraft:smooth_sandstone
fill 235 253 300 235 260 300 minecraft:smooth_sandstone
setblock 235 253 304 minecraft:blue_terracotta
fill 235 253 306 235 265 307 minecraft:smooth_sandstone
fill 236 253 317 237 265 317 minecraft:smooth_sandstone
setblock 239 253 275 minecraft:black_terracotta
fill 243 253 275 244 265 275 minecraft:smooth_sandstone
setblock 247 253 311 minecraft:glowstone
fill 248 253 317 249 259 317 minecraft:smooth_sandstone
fill 254 253 283 255 254 284 minecraft:smooth_sandstone
fill 255 253 275 256 265 275 minecraft:smooth_sandstone
fill 260 253 317 261 265 317 minecraft:smooth_sandstone
fill 267 253 275 268 265 275 minecraft:smooth_sandstone
fill 272 253 317 273 265 317 minecraft:smooth_sandstone
fill 277 253 277 277 265 278 minecraft:smooth_sandstone
setblock 277 253 289 minecraft:lapis_block
fill 277 253 290 277 265 290 minecraft:smooth_sandstone
fill 277 253 301 277 265 302 minecraft:smooth_sandstone
fill 277 253 304 277 287 304 minecraft:smooth_sandstone
fill 277 253 313 277 262 314 minecraft:smooth_sandstone
setblock 235 254 299 minecraft:orange_terracotta
fill 235 254 304 235 291 304 minecraft:smooth_sandstone
fill 239 254 275 239 285 275 minecraft:smooth_sandstone
fill 277 254 289 277 265 289 minecraft:smooth_sandstone
setblock 235 255 289 minecraft:blue_terracotta
fill 235 255 299 235 256 299 minecraft:smooth_sandstone
setblock 238 255 278 minecraft:light[level=15]
setblock 238 255 285 minecraft:light[level=12]
setblock 238 255 286 minecraft:light[level=15]
setblock 238 255 292 minecraft:light[level=12]
setblock 238 255 294 minecraft:light[level=15]
setblock 238 255 299 minecraft:light[level=12]
setblock 238 255 302 minecraft:light[level=15]
setblock 238 255 306 minecraft:light[level=12]
setblock 238 255 310 minecraft:light[level=15]
setblock 238 255 313 minecraft:light[level=12]
setblock 245 255 278 minecraft:light[level=12]
setblock 245 255 285 minecraft:light[level=12]
setblock 245 255 292 minecraft:light[level=12]
setblock 245 255 299 minecraft:light[level=12]
setblock 245 255 306 minecraft:light[level=12]
setblock 245 255 313 minecraft:light[level=12]
setblock 246 255 278 minecraft:light[level=15]
setblock 246 255 286 minecraft:light[level=15]
setblock 246 255 294 minecraft:light[level=15]
setblock 246 255 302 minecraft:light[level=15]
setblock 246 255 310 minecraft:light[level=15]
setblock 252 255 278 minecraft:light[level=12]
setblock 252 255 285 minecraft:light[level=12]
setblock 252 255 292 minecraft:light[level=12]
setblock 252 255 299 minecraft:light[level=12]
setblock 252 255 306 minecraft:light[level=12]
setblock 252 255 313 minecraft:light[level=12]
setblock 254 255 278 minecraft:light[level=15]
setblock 254 255 286 minecraft:light[level=15]
setblock 254 255 294 minecraft:light[level=15]
setblock 254 255 302 minecraft:light[level=15]
setblock 254 255 310 minecraft:light[level=15]
setblock 259 255 278 minecraft:light[level=12]
setblock 259 255 285 minecraft:light[level=12]
setblock 259 255 292 minecraft:light[level=12]
setblock 259 255 299 minecraft:light[level=12]
setblock 259 255 306 minecraft:light[level=12]
setblock 259 255 313 minecraft:light[level=12]
setblock 262 255 278 minecraft:light[level=15]
setblock 262 255 286 minecraft:light[level=15]
setblock 262 255 294 minecraft:light[level=15]
setblock 262 255 302 minecraft:light[level=15]
setblock 262 255 310 minecraft:light[level=15]
setblock 266 255 275 minecraft:blue_terracotta
setblock 266 255 278 minecraft:light[level=12]
setblock 266 255 285 minecraft:light[level=12]
setblock 266 255 292 minecraft:light[level=12]
setblock 266 255 299 minecraft:light[level=12]
setblock 266 255 306 minecraft:light[level=12]
setblock 266 255 313 minecraft:light[level=12]
setblock 270 255 278 minecraft:light[level=15]
setblock 270 255 286 minecraft:light[level=15]
setblock 270 255 294 minecraft:light[level=15]
setblock 270 255 302 minecraft:light[level=15]
setblock 270 255 310 minecraft:light[level=15]
setblock 273 255 278 minecraft:light[level=12]
setblock 273 255 285 minecraft:light[level=12]
setblock 273 255 292 minecraft:light[level=12]
setblock 273 255 299 minecraft:light[level=12]
setblock 273 255 306 minecraft:light[level=12]
setblock 273 255 313 minecraft:light[level=12]
setblock 275 255 275 minecraft:blue_terracotta
setblock 235 256 282 minecraft:black_terracotta
fill 235 256 283 235 265 283 minecraft:smooth_sandstone
fill 235 256 289 235 260 289 minecraft:smooth_sandstone
setblock 243 256 317 minecraft:orange_terracotta
setblock 245 256 275 minecraft:orange_terracotta
setblock 250 256 317 minecraft:orange_terracotta
setblock 254 256 275 minecraft:blue_terracotta
fill 266 256 275 266 265 275 minecraft:smooth_sandstone
setblock 268 256 317 minecraft:orange_terracotta
fill 269 256 317 269 308 317 minecraft:smooth_sandstone
fill 275 256 275 275 299 275 minecraft:smooth_sandstone
fill 235 257 282 235 265 282 minecraft:smooth_sandstone
setblock 235 257 299 minecraft:lapis_block
fill 243 257 317 243 308 317 minecraft:smooth_sandstone
fill 245 257 275 245 265 275 minecraft:smooth_sandstone
fill 250 257 317 250 265 317 minecraft:smooth_sandstone
fill 254 257 275 254 265 275 minecraft:smooth_sandstone
setblock 261 257 275 minecraft:black_terracotta
fill 268 257 317 268 259 317 minecraft:smooth_sandstone
fill 235 258 299 235 268 299 minecraft:smooth_sandstone
fill 261 258 275 261 308 275 minecraft:smooth_sandstone
setblock 270 259 275 minecraft:lapis_block
fill 271 259 275 271 289 275 minecraft:smooth_sandstone
setblock 272 259 275 minecraft:black_terracotta
setblock 277 259 309 minecraft:blue_terracotta
fill 237 260 285 237 265 287 minecraft:cut_sandstone
fill 237 260 297 237 265 299 minecraft:cut_sandstone
fill 237 260 309 237 265 311 minecraft:cut_sandstone
fill 243 260 315 245 265 315 minecraft:cut_sandstone
fill 247 260 277 249 265 277 minecraft:cut_sandstone
fill 248 260 317 248 265 317 minecraft:smooth_sandstone
setblock 249 260 317 minecraft:orange_terracotta
fill 255 260 315 257 265 315 minecraft:cut_sandstone
fill 259 260 277 261 265 277 minecraft:cut_sandstone
fill 267 260 315 269 265 315 minecraft:cut_sandstone
setblock 268 260 317 minecraft:black_terracotta
fill 270 260 275 270 308 275 minecraft:smooth_sandstone
fill 271 260 277 273 265 277 minecraft:cut_sandstone
fill 272 260 275 272 265 275 minecraft:smooth_sandstone
fill 275 260 285 275 265 287 minecraft:cut_sandstone
fill 275 260 297 275 265 299 minecraft:cut_sandstone
fill 275 260 309 275 265 311 minecraft:cut_sandstone
fill 277 260 296 277 261 296 minecraft:orange_terracotta
fill 277 260 309 277 308 309 minecraft:smooth_sandstone
setblock 235 261 289 minecraft:blue_terracotta
setblock 235 261 300 minecraft:black_terracotta
setblock 238 261 278 minecraft:light[level=12]
setblock 238 261 285 minecraft:light[level=12]
setblock 238 261 292 minecraft:light[level=12]
setblock 238 261 299 minecraft:light[level=12]
setblock 238 261 306 minecraft:light[level=12]
setblock 238 261 313 minecraft:light[level=12]
setblock 245 261 278 minecraft:light[level=12]
setblock 245 261 285 minecraft:light[level=12]
setblock 245 261 292 minecraft:light[level=12]
setblock 245 261 299 minecraft:light[level=12]
setblock 245 261 306 minecraft:light[level=12]
setblock 245 261 313 minecraft:light[level=12]
fill 249 261 317 249 265 317 minecraft:smooth_sandstone
setblock 252 261 278 minecraft:light[level=12]
setblock 252 261 285 minecraft:light[level=12]
setblock 252 261 292 minecraft:light[level=12]
setblock 252 261 299 minecraft:light[level=12]
setblock 252 261 306 minecraft:light[level=12]
setblock 252 261 313 minecraft:light[level=12]
setblock 254 261 317 minecraft:orange_terracotta
setblock 259 261 278 minecraft:light[level=12]
setblock 259 261 285 minecraft:light[level=12]
setblock 259 261 292 minecraft:light[level=12]
setblock 259 261 299 minecraft:light[level=12]
setblock 259 261 306 minecraft:light[level=12]
setblock 259 261 313 minecraft:light[level=12]
setblock 266 261 278 minecraft:light[level=12]
setblock 266 261 285 minecraft:light[level=12]
setblock 266 261 292 minecraft:light[level=12]
setblock 266 261 299 minecraft:light[level=12]
setblock 266 261 306 minecraft:light[level=12]
setblock 266 261 313 minecraft:light[level=12]
fill 268 261 317 268 308 317 minecraft:smooth_sandstone
setblock 273 261 278 minecraft:light[level=12]
setblock 273 261 285 minecraft:light[level=12]
setblock 273 261 292 minecraft:light[level=12]
setblock 273 261 299 minecraft:light[level=12]
setblock 273 261 306 minecraft:light[level=12]
setblock 273 261 313 minecraft:light[level=12]
setblock 277 261 276 minecraft:blue_terracotta
fill 235 262 289 235 291 289 minecraft:smooth_sandstone
fill 235 262 300 235 291 300 minecraft:smooth_sandstone
fill 254 262 317 254 283 317 minecraft:smooth_sandstone
fill 277 262 276 277 265 276 minecraft:smooth_sandstone
fill 277 262 296 277 308 296 minecraft:smooth_sandstone
setblock 235 263 294 minecraft:lapis_block
fill 235 263 295 235 265 295 minecraft:smooth_sandstone
setblock 238 263 278 minecraft:light[level=15]
setblock 238 263 286 minecraft:light[level=15]
setblock 238 263 294 minecraft:light[level=15]
setblock 238 263 302 minecraft:light[level=15]
setblock 238 263 310 minecraft:light[level=15]
setblock 241 263 317 minecraft:orange_terracotta
setblock 246 263 278 minecraft:light[level=15]
setblock 246 263 286 minecraft:light[level=15]
setblock 246 263 294 minecraft:light[level=15]
setblock 246 263 302 minecraft:light[level=15]
setblock 246 263 310 minecraft:light[level=15]
setblock 254 263 278 minecraft:light[level=15]
setblock 254 263 286 minecraft:light[level=15]
setblock 254 263 294 minecraft:light[level=15]
setblock 254 263 302 minecraft:light[level=15]
setblock 254 263 310 minecraft:light[level=15]
setblock 262 263 278 minecraft:light[level=15]
setblock 262 263 286 minecraft:light[level=15]
setblock 262 263 294 minecraft:light[level=15]
setblock 262 263 302 minecraft:light[level=15]
setblock 262 263 310 minecraft:light[level=15]
setblock 270 263 278 minecraft:light[level=15]
setblock 270 263 286 minecraft:light[level=15]
setblock 270 263 294 minecraft:light[level=15]
setblock 270 263 302 minecraft:light[level=15]
setblock 270 263 310 minecraft:light[level=15]
fill 277 263 313 277 265 313 minecraft:smooth_sandstone
setblock 277 263 314 minecraft:black_terracotta
fill 235 264 294 235 265 294 minecraft:smooth_sandstone
setblock 235 264 308 minecraft:lapis_block
fill 241 264 317 241 282 317 minecraft:smooth_sandstone
setblock 251 264 317 minecraft:orange_terracotta
fill 277 264 314 277 265 314 minecraft:smooth_sandstone
setblock 235 265 308 minecraft:smooth_sandstone
fill 236 265 279 236 265 284 minecraft:chiseled_sandstone
fill 236 265 291 236 265 296 minecraft:chiseled_sandstone
fill 236 265 303 236 265 308 minecraft:chiseled_sandstone
fill 236 265 315 236 265 316 minecraft:chiseled_sandstone
fill 237 265 316 240 265 316 minecraft:chiseled_sandstone
fill 240 265 276 245 265 276 minecraft:chiseled_sandstone
fill 247 265 316 252 265 316 minecraft:chiseled_sandstone
fill 251 265 317 251 308 317 minecraft:smooth_sandstone
setblock 252 265 275 minecraft:lapis_block
fill 252 265 276 257 265 276 minecraft:chiseled_sandstone
fill 259 265 316 264 265 316 minecraft:chiseled_sandstone
fill 264 265 276 269 265 276 minecraft:chiseled_sandstone
fill 271 265 316 276 265 316 minecraft:chiseled_sandstone
fill 276 265 276 276 265 281 minecraft:chiseled_sandstone
fill 276 265 288 276 265 293 minecraft:chiseled_sandstone
fill 276 265 300 276 265 305 minecraft:chiseled_sandstone
fill 276 265 312 276 265 315 minecraft:chiseled_sandstone
fill 235 266 281 235 270 284 minecraft:glowstone
fill 235 266 293 235 270 296 minecraft:glowstone
fill 235 266 305 235 270 308 minecraft:glowstone
setblock 235 266 315 minecraft:blue_terracotta
fill 235 266 316 235 308 316 minecraft:smooth_sandstone
fill 235 266 317 238 270 317 minecraft:glowstone
fill 242 266 275 245 270 275 minecraft:glowstone
fill 247 266 317 250 270 317 minecraft:glowstone
fill 250 266 285 250 267 285 minecraft:smooth_sandstone
fill 252 266 275 252 308 275 minecraft:smooth_sandstone
fill 254 266 275 257 270 275 minecraft:glowstone
fill 259 266 317 262 270 317 minecraft:glowstone
setblock 264 266 317 minecraft:lapis_block
fill 266 266 275 269 270 275 minecraft:glowstone
fill 271 266 317 274 270 317 minecraft:glowstone
setblock 272 266 275 minecraft:orange_terracotta
fill 277 266 276 277 270 279 minecraft:glowstone
fill 277 266 288 277 270 291 minecraft:glowstone
fill 277 266 300 277 270 303 minecraft:glowstone
fill 277 266 312 277 270 315 minecraft:glowstone
fill 235 267 315 235 296 315 minecraft:smooth_sandstone
setblock 238 267 278 minecraft:light[level=12]
setblock 238 267 285 minecraft:light[level=12]
setblock 238 267 292 minecraft:light[level=12]
setblock 238 267 299 minecraft:light[level=12]
setblock 238 267 306 minecraft:light[level=12]
setblock 238 267 313 minecraft:light[level=12]
setblock 245 267 278 minecraft:light[level=12]
setblock 245 267 285 minecraft:light[level=12]
setblock 245 267 292 minecraft:light[level=12]
setblock 245 267 299 minecraft:light[level=12]
setblock 245 267 306 minecraft:light[level=12]
setblock 245 267 313 minecraft:light[level=12]
setblock 252 267 278 minecraft:light[level=12]
setblock 252 267 285 minecraft:light[level=12]
setblock 252 267 292 minecraft:light[level=12]
setblock 252 267 299 minecraft:light[level=12]
setblock 252 267 306 minecraft:light[level=12]
setblock 252 267 313 minecraft:light[level=12]
setblock 259 267 278 minecraft:light[level=12]
setblock 259 267 285 minecraft:light[level=12]
setblock 259 267 292 minecraft:light[level=12]
setblock 259 267 299 minecraft:light[level=12]
setblock 259 267 306 minecraft:light[level=12]
setblock 259 267 313 minecraft:light[level=12]
fill 264 267 317 264 308 317 minecraft:smooth_sandstone
setblock 266 267 278 minecraft:light[level=12]
setblock 266 267 285 minecraft:light[level=12]
setblock 266 267 292 minecraft:light[level=12]
setblock 266 267 299 minecraft:light[level=12]
setblock 266 267 306 minecraft:light[level=12]
setblock 266 267 313 minecraft:light[level=12]
fill 272 267 275 272 299 275 minecraft:smooth_sandstone
setblock 273 267 278 minecraft:light[level=12]
setblock 273 267 285 minecraft:light[level=12]
setblock 273 267 292 minecraft:light[level=12]
setblock 273 267 299 minecraft:light[level=12]
setblock 273 267 306 minecraft:light[level=12]
setblock 273 267 313 minecraft:light[level=12]
fill 235 268 301 235 308 301 minecraft:smooth_sandstone
setblock 235 268 302 minecraft:orange_terracotta
setblock 277 268 284 minecraft:lapis_block
setblock 277 268 292 minecraft:orange_terracotta
setblock 235 269 299 minecraft:blue_terracotta
fill 235 269 302 235 308 302 minecraft:smooth_sandstone
fill 236 269 283 242 269 283 minecraft:chiseled_sandstone
fill 238 269 281 242 270 282 minecraft:chiseled_sandstone
fill 238 269 284 242 270 285 minecraft:chiseled_sandstone
fill 277 269 284 277 292 284 minecraft:smooth_sandstone
fill 277 269 292 277 308 292 minecraft:smooth_sandstone
fill 235 270 299 235 308 299 minecraft:smooth_sandstone
fill 238 270 283 242 270 283 minecraft:chiseled_sandstone
setblock 277 270 283 minecraft:black_terracotta
fill 235 271 281 235 272 284 minecraft:smooth_sandstone
fill 235 271 287 235 308 287 minecraft:smooth_sandstone
setblock 235 271 288 minecraft:orange_terracotta
fill 235 271 293 235 285 296 minecraft:smooth_sandstone
fill 235 271 305 235 282 308 minecraft:smooth_sandstone
fill 235 271 317 238 285 317 minecraft:smooth_sandstone
setblock 238 271 278 minecraft:light[level=15]
setblock 238 271 286 minecraft:light[level=15]
setblock 238 271 294 minecraft:light[level=15]
setblock 238 271 302 minecraft:light[level=15]
setblock 238 271 310 minecraft:light[level=15]
fill 242 271 275 245 280 275 minecraft:smooth_sandstone
setblock 246 271 278 minecraft:light[level=15]
setblock 246 271 286 minecraft:light[level=15]
setblock 246 271 294 minecraft:light[level=15]
setblock 246 271 302 minecraft:light[level=15]
setblock 246 271 310 minecraft:light[level=15]
fill 247 271 317 250 277 317 minecraft:smooth_sandstone
fill 254 271 275 257 283 275 minecraft:smooth_sandstone
setblock 254 271 278 minecraft:light[level=15]
setblock 254 271 286 minecraft:light[level=15]
setblock 254 271 302 minecraft:light[level=15]
setblock 254 271 310 minecraft:light[level=15]
setblock 258 271 317 minecraft:lapis_block
fill 259 271 317 262 276 317 minecraft:smooth_sandstone
setblock 262 271 278 minecraft:light[level=15]
setblock 262 271 286 minecraft:light[level=15]
setblock 262 271 294 minecraft:light[level=15]
setblock 262 271 302 minecraft:light[level=15]
setblock 262 271 310 minecraft:light[level=15]
fill 266 271 275 269 271 275 minecraft:smooth_sandstone
setblock 270 271 278 minecraft:light[level=15]
setblock 270 271 286 minecraft:light[level=15]
setblock 270 271 294 minecraft:light[level=15]
setblock 270 271 302 minecraft:light[level=15]
setblock 270 271 310 minecraft:light[level=15]
setblock 271 271 317 minecraft:lapis_block
fill 272 271 317 274 285 317 minecraft:smooth_sandstone
fill 277 271 276 277 285 279 minecraft:smooth_sandstone
fill 277 271 283 277 308 283 minecraft:smooth_sandstone
fill 277 271 288 277 285 291 minecraft:smooth_sandstone
fill 277 271 300 277 285 303 minecraft:smooth_sandstone
fill 277 271 312 277 282 315 minecraft:smooth_sandstone
fill 235 272 288 235 276 288 minecraft:smooth_sandstone
setblock 235 272 292 minecraft:orange_terracotta
fill 258 272 317 258 299 317 minecraft:smooth_sandstone
setblock 259 272 275 minecraft:blue_terracotta
fill 266 272 275 266 285 275 minecraft:smooth_sandstone
setblock 267 272 275 minecraft:black_terracotta
fill 268 272 275 269 285 275 minecraft:smooth_sandstone
fill 271 272 317 271 285 317 minecraft:smooth_sandstone
setblock 277 272 298 minecraft:black_terracotta
fill 235 273 281 235 285 281 minecraft:smooth_sandstone
setblock 235 273 282 minecraft:orange_terracotta
fill 235 273 283 235 285 284 minecraft:smooth_sandstone
fill 235 273 292 235 274 292 minecraft:smooth_sandstone
setblock 238 273 278 minecraft:light[level=12]
setblock 238 273 285 minecraft:light[level=12]
setblock 238 273 292 minecraft:light[level=12]
setblock 238 273 299 minecraft:light[level=12]
setblock 238 273 306 minecraft:light[level=12]
setblock 238 273 313 minecraft:light[level=12]
setblock 245 273 278 minecraft:light[level=12]
setblock 245 273 285 minecraft:light[level=12]
setblock 245 273 292 minecraft:light[level=12]
setblock 245 273 299 minecraft:light[level=12]
setblock 245 273 306 minecraft:light[level=12]
setblock 245 273 313 minecraft:light[level=12]
setblock 252 273 278 minecraft:light[level=12]
setblock 252 273 285 minecraft:light[level=12]
setblock 252 273 292 minecraft:light[level=12]
setblock 252 273 299 minecraft:light[level=12]
setblock 252 273 306 minecraft:light[level=12]
setblock 252 273 313 minecraft:light[level=12]
fill 259 273 275 259 298 275 minecraft:smooth_sandstone
setblock 259 273 278 minecraft:light[level=12]
setblock 259 273 285 minecraft:light[level=12]
setblock 259 273 292 minecraft:light[level=12]
setblock 259 273 299 minecraft:light[level=12]
setblock 259 273 306 minecraft:light[level=12]
setblock 259 273 313 minecraft:light[level=12]
setblock 266 273 278 minecraft:light[level=12]
setblock 266 273 285 minecraft:light[level=12]
setblock 266 273 292 minecraft:light[level=12]
setblock 266 273 299 minecraft:light[level=12]
setblock 266 273 306 minecraft:light[level=12]
setblock 266 273 313 minecraft:light[level=12]
fill 267 273 275 267 285 275 minecraft:smooth_sandstone
setblock 273 273 278 minecraft:light[level=12]
setblock 273 273 285 minecraft:light[level=12]
setblock 273 273 292 minecraft:light[level=12]
setblock 273 273 299 minecraft:light[level=12]
setblock 273 273 306 minecraft:light[level=12]
setblock 273 273 313 minecraft:light[level=12]
fill 277 273 298 277 293 298 minecraft:smooth_sandstone
fill 235 274 282 235 285 282 minecraft:smooth_sandstone
setblock 235 274 285 minecraft:orange_terracotta
setblock 235 275 276 minecraft:lapis_block
fill 235 275 285 235 308 285 minecraft:smooth_sandstone
setblock 235 275 292 minecraft:orange_terracotta
setblock 251 275 275 minecraft:orange_terracotta
fill 235 276 276 235 308 276 minecraft:smooth_sandstone
fill 235 276 292 251 276 292 minecraft:smooth_sandstone
fill 236 276 276 236 278 276 minecraft:gold_block
fill 236 276 277 236 276 291 minecraft:smooth_sandstone
fill 236 276 293 236 276 315 minecraft:smooth_sandstone
fill 236 276 316 236 278 316 minecraft:gold_block
fill 237 276 275 237 276 276 minecraft:smooth_sandstone
fill 237 276 277 237 279 277 minecraft:gold_block
fill 237 276 278 237 276 291 minecraft:smooth_sandstone
fill 237 276 293 237 276 314 minecraft:smooth_sandstone
fill 237 276 315 237 279 315 minecraft:gold_block
fill 237 276 316 275 276 316 minecraft:smooth_sandstone
setblock 238 276 275 minecraft:lapis_block
fill 238 276 276 274 276 277 minecraft:smooth_sandstone
fill 238 276 278 238 279 278 minecraft:gold_block
fill 238 276 279 238 276 291 minecraft:smooth_sandstone
fill 238 276 293 238 276 313 minecraft:smooth_sandstone
fill 238 276 314 238 279 314 minecraft:gold_block
fill 238 276 315 274 276 315 minecraft:smooth_sandstone
fill 239 276 278 273 276 278 minecraft:smooth_sandstone
fill 239 276 279 239 280 279 minecraft:gold_block
fill 239 276 280 239 276 291 minecraft:smooth_sandstone
fill 239 276 293 239 276 312 minecraft:smooth_sandstone
fill 239 276 313 239 280 313 minecraft:gold_block
fill 239 276 314 273 276 314 minecraft:smooth_sandstone
fill 240 276 279 272 276 279 minecraft:smooth_sandstone
fill 240 276 280 240 281 280 minecraft:gold_block
fill 240 276 281 240 276 291 minecraft:smooth_sandstone
fill 240 276 293 240 276 311 minecraft:smooth_sandstone
fill 240 276 312 240 281 312 minecraft:gold_block
fill 240 276 313 272 276 313 minecraft:smooth_sandstone
fill 241 276 280 271 276 280 minecraft:smooth_sandstone
fill 241 276 281 241 282 281 minecraft:gold_block
fill 241 276 282 241 276 291 minecraft:smooth_sandstone
fill 241 276 293 241 276 310 minecraft:smooth_sandstone
fill 241 276 311 241 282 311 minecraft:gold_block
fill 241 276 312 271 276 312 minecraft:smooth_sandstone
fill 242 276 281 270 276 281 minecraft:smooth_sandstone
fill 242 276 282 242 282 282 minecraft:gold_block
fill 242 276 283 242 276 291 minecraft:smooth_sandstone
fill 242 276 293 242 276 309 minecraft:smooth_sandstone
fill 242 276 310 242 282 310 minecraft:gold_block
fill 242 276 311 270 276 311 minecraft:smooth_sandstone
fill 243 276 282 269 276 282 minecraft:smooth_sandstone
fill 243 276 283 243 283 283 minecraft:gold_block
fill 243 276 284 243 276 291 minecraft:smooth_sandstone
fill 243 276 293 243 276 308 minecraft:smooth_sandstone
fill 243 276 309 243 283 309 minecraft:gold_block
fill 243 276 310 269 276 310 minecraft:smooth_sandstone
fill 244 276 283 268 276 283 minecraft:smooth_sandstone
fill 244 276 284 244 284 284 minecraft:gold_block
fill 244 276 285 244 276 291 minecraft:smooth_sandstone
fill 244 276 293 244 276 307 minecraft:smooth_sandstone
fill 244 276 308 244 284 308 minecraft:gold_block
fill 244 276 309 268 276 309 minecraft:smooth_sandstone
fill 245 276 284 267 276 284 minecraft:smooth_sandstone
fill 245 276 285 245 285 285 minecraft:gold_block
fill 245 276 286 245 276 291 minecraft:smooth_sandstone
fill 245 276 293 245 276 306 minecraft:smooth_sandstone
fill 245 276 307 245 285 307 minecraft:gold_block
fill 245 276 308 267 276 308 minecraft:smooth_sandstone
fill 246 276 285 266 276 285 minecraft:smooth_sandstone
fill 246 276 286 246 285 286 minecraft:gold_block
fill 246 276 287 246 276 291 minecraft:smooth_sandstone
fill 246 276 293 246 276 305 minecraft:smooth_sandstone
fill 246 276 306 246 285 306 minecraft:gold_block
fill 246 276 307 266 276 307 minecraft:smooth_sandstone
fill 247 276 286 265 276 286 minecraft:smooth_sandstone
fill 247 276 287 247 286 287 minecraft:gold_block
fill 247 276 288 247 276 291 minecraft:smooth_sandstone
fill 247 276 293 247 276 304 minecraft:smooth_sandstone
fill 247 276 305 247 286 305 minecraft:gold_block
fill 247 276 306 265 276 306 minecraft:smooth_sandstone
fill 248 276 287 264 276 287 minecraft:smooth_sandstone
fill 248 276 288 248 287 288 minecraft:gold_block
fill 248 276 289 248 276 291 minecraft:smooth_sandstone
fill 248 276 293 248 276 303 minecraft:smooth_sandstone
fill 248 276 304 248 287 304 minecraft:gold_block
fill 248 276 305 264 276 305 minecraft:smooth_sandstone
fill 249 276 288 263 276 288 minecraft:smooth_sandstone
fill 249 276 289 249 288 289 minecraft:gold_block
fill 249 276 290 249 276 291 minecraft:smooth_sandstone
fill 249 276 293 249 276 302 minecraft:smooth_sandstone
fill 249 276 303 249 288 303 minecraft:gold_block
fill 249 276 304 263 276 304 minecraft:smooth_sandstone
fill 250 276 289 262 276 289 minecraft:smooth_sandstone
fill 250 276 290 250 288 290 minecraft:gold_block
setblock 250 276 291 minecraft:smooth_sandstone
fill 250 276 293 250 276 301 minecraft:smooth_sandstone
fill 250 276 302 250 288 302 minecraft:gold_block
fill 250 276 303 262 276 303 minecraft:smooth_sandstone
fill 251 276 275 251 301 275 minecraft:smooth_sandstone
fill 251 276 290 261 276 290 minecraft:smooth_sandstone
fill 251 276 291 251 289 291 minecraft:gold_block
fill 251 276 293 251 276 300 minecraft:smooth_sandstone
fill 251 276 301 251 289 301 minecraft:gold_block
fill 251 276 302 261 276 302 minecraft:smooth_sandstone
fill 252 276 291 254 276 291 minecraft:smooth_sandstone
fill 252 276 292 252 290 292 minecraft:gold_block
setblock 252 276 293 minecraft:smooth_sandstone
fill 252 276 295 252 276 299 minecraft:smooth_sandstone
fill 252 276 300 252 290 300 minecraft:gold_block
fill 252 276 301 260 276 301 minecraft:smooth_sandstone
setblock 252 276 317 minecraft:lapis_block
fill 253 276 297 253 276 298 minecraft:smooth_sandstone
fill 253 276 299 253 291 299 minecraft:gold_block
fill 253 276 300 259 276 300 minecraft:smooth_sandstone
setblock 254 276 297 minecraft:smooth_sandstone
fill 254 276 298 254 291 298 minecraft:gold_block
fill 254 276 299 258 276 299 minecraft:smooth_sandstone
fill 255 276 298 257 276 298 minecraft:smooth_sandstone
fill 256 276 291 260 276 291 minecraft:smooth_sandstone
setblock 256 276 297 minecraft:smooth_sandstone
fill 257 276 297 257 292 297 minecraft:gold_block
fill 258 276 292 258 276 293 minecraft:smooth_sandstone
fill 258 276 295 276 276 297 minecraft:smooth_sandstone
fill 258 276 298 258 291 298 minecraft:gold_block
setblock 259 276 292 minecraft:smooth_sandstone
fill 259 276 293 259 291 293 minecraft:gold_block
fill 259 276 294 276 276 294 minecraft:smooth_sandstone
fill 259 276 298 276 276 298 minecraft:smooth_sandstone
fill 259 276 299 259 291 299 minecraft:gold_block
fill 260 276 292 260 290 292 minecraft:gold_block
fill 260 276 293 276 276 293 minecraft:smooth_sandstone
fill 260 276 299 276 276 299 minecraft:smooth_sandstone
fill 260 276 300 260 290 300 minecraft:gold_block
fill 261 276 291 261 289 291 minecraft:gold_block
fill 261 276 292 276 276 292 minecraft:smooth_sandstone
fill 261 276 300 276 276 300 minecraft:smooth_sandstone
fill 261 276 301 261 289 301 minecraft:gold_block
fill 262 276 290 262 288 290 minecraft:gold_block
fill 262 276 291 276 276 291 minecraft:smooth_sandstone
fill 262 276 301 276 276 301 minecraft:smooth_sandstone
fill 262 276 302 262 288 302 minecraft:gold_block
fill 263 276 289 263 288 289 minecraft:gold_block
fill 263 276 290 276 276 290 minecraft:smooth_sandstone
fill 263 276 302 276 276 302 minecraft:smooth_sandstone
fill 263 276 303 263 288 303 minecraft:gold_block
fill 264 276 288 264 287 288 minecraft:gold_block
fill 264 276 289 276 276 289 minecraft:smooth_sandstone
fill 264 276 303 276 276 303 minecraft:smooth_sandstone
fill 264 276 304 264 287 304 minecraft:gold_block
fill 265 276 287 265 286 287 minecraft:gold_block
fill 265 276 288 276 276 288 minecraft:smooth_sandstone
fill 265 276 304 276 276 304 minecraft:smooth_sandstone
fill 265 276 305 265 286 305 minecraft:gold_block
fill 266 276 286 266 285 286 minecraft:gold_block
fill 266 276 287 276 276 287 minecraft:smooth_sandstone
fill 266 276 305 276 276 305 minecraft:smooth_sandstone
fill 266 276 306 266 285 306 minecraft:gold_block
fill 267 276 285 267 285 285 minecraft:gold_block
fill 267 276 286 276 276 286 minecraft:smooth_sandstone
fill 267 276 306 276 276 306 minecraft:smooth_sandstone
fill 267 276 307 267 285 307 minecraft:gold_block
fill 268 276 284 268 284 284 minecraft:gold_block
fill 268 276 285 276 276 285 minecraft:smooth_sandstone
fill 268 276 307 276 276 307 minecraft:smooth_sandstone
fill 268 276 308 268 284 308 minecraft:gold_block
fill 269 276 283 269 283 283 minecraft:gold_block
fill 269 276 284 276 276 284 minecraft:smooth_sandstone
fill 269 276 308 276 276 308 minecraft:smooth_sandstone
fill 269 276 309 269 283 309 minecraft:gold_block
fill 270 276 282 270 282 282 minecraft:gold_block
fill 270 276 283 276 276 283 minecraft:smooth_sandstone
fill 270 276 309 276 276 309 minecraft:smooth_sandstone
fill 270 276 310 270 282 310 minecraft:gold_block
fill 271 276 281 271 282 281 minecraft:gold_block
fill 271 276 282 276 276 282 minecraft:smooth_sandstone
fill 271 276 310 276 276 310 minecraft:smooth_sandstone
fill 271 276 311 271 282 311 minecraft:gold_block
fill 272 276 280 272 281 280 minecraft:gold_block
fill 272 276 281 276 276 281 minecraft:smooth_sandstone
fill 272 276 311 276 276 311 minecraft:smooth_sandstone
fill 272 276 312 272 281 312 minecraft:gold_block
fill 273 276 279 273 280 279 minecraft:gold_block
fill 273 276 280 276 276 280 minecraft:smooth_sandstone
fill 273 276 312 276 276 312 minecraft:smooth_sandstone
fill 273 276 313 273 280 313 minecraft:gold_block
fill 274 276 278 274 279 278 minecraft:gold_block
fill 274 276 279 276 276 279 minecraft:smooth_sandstone
fill 274 276 313 276 276 313 minecraft:smooth_sandstone
fill 274 276 314 274 279 314 minecraft:gold_block
setblock 275 276 276 minecraft:smooth_sandstone
fill 275 276 277 275 279 277 minecraft:gold_block
fill 275 276 278 276 276 278 minecraft:smooth_sandstone
fill 275 276 314 276 276 314 minecraft:smooth_sandstone
fill 275 276 315 275 279 315 minecraft:gold_block
fill 276 276 276 276 278 276 minecraft:gold_block
setblock 276 276 277 minecraft:smooth_sandstone
setblock 276 276 315 minecraft:smooth_sandstone
fill 276 276 316 276 278 316 minecraft:gold_block
setblock 235 277 288 minecraft:orange_terracotta
fill 235 277 292 235 306 292 minecraft:smooth_sandstone
fill 236 277 277 236 277 315 minecraft:sandstone
fill 237 277 275 238 285 275 minecraft:smooth_sandstone
fill 237 277 276 275 277 276 minecraft:sandstone
fill 237 277 278 237 277 314 minecraft:sandstone
fill 237 277 316 275 277 316 minecraft:sandstone
fill 238 277 277 274 277 277 minecraft:sandstone
fill 238 277 279 238 277 313 minecraft:sandstone
fill 238 277 315 274 277 315 minecraft:sandstone
fill 239 277 278 273 277 278 minecraft:sandstone
fill 239 277 280 239 277 312 minecraft:sandstone
fill 239 277 314 273 277 314 minecraft:sandstone
fill 240 277 279 272 277 279 minecraft:sandstone
fill 240 277 281 240 277 311 minecraft:sandstone
fill 240 277 313 272 277 313 minecraft:sandstone
fill 241 277 280 271 277 280 minecraft:sandstone
fill 241 277 282 241 277 310 minecraft:sandstone
fill 241 277 312 271 277 312 minecraft:sandstone
fill 242 277 281 270 277 281 minecraft:sandstone
fill 242 277 283 242 277 309 minecraft:sandstone
fill 242 277 311 270 277 311 minecraft:sandstone
fill 243 277 282 269 277 282 minecraft:sandstone
fill 243 277 284 243 277 308 minecraft:sandstone
fill 243 277 310 269 277 310 minecraft:sandstone
fill 244 277 283 268 277 283 minecraft:sandstone
fill 244 277 285 244 277 307 minecraft:sandstone
fill 244 277 309 268 277 309 minecraft:sandstone
fill 245 277 284 267 277 284 minecraft:sandstone
fill 245 277 286 245 277 306 minecraft:sandstone
fill 245 277 308 267 277 308 minecraft:sandstone
fill 246 277 285 266 277 285 minecraft:sandstone
fill 246 277 287 246 277 305 minecraft:sandstone
fill 246 277 307 266 277 307 minecraft:sandstone
fill 247 277 286 265 277 286 minecraft:sandstone
fill 247 277 288 247 277 304 minecraft:sandstone
fill 247 277 306 265 277 306 minecraft:sandstone
fill 248 277 287 264 277 287 minecraft:sandstone
fill 248 277 289 248 277 303 minecraft:sandstone
fill 248 277 305 264 277 305 minecraft:sandstone
fill 249 277 288 263 277 288 minecraft:sandstone
fill 249 277 290 249 277 302 minecraft:sandstone
fill 249 277 304 263 277 304 minecraft:sandstone
fill 250 277 289 262 277 289 minecraft:sandstone
fill 250 277 291 250 277 301 minecraft:sandstone
fill 250 277 303 262 277 303 minecraft:sandstone
fill 251 277 290 261 277 290 minecraft:sandstone
fill 251 277 292 251 277 300 minecraft:sandstone
fill 251 277 302 261 277 302 minecraft:sandstone
fill 252 277 291 254 277 291 minecraft:sandstone
setblock 252 277 293 minecraft:sandstone
fill 252 277 295 252 277 299 minecraft:sandstone
fill 252 277 301 260 277 301 minecraft:sandstone
fill 252 277 317 252 283 317 minecraft:smooth_sandstone
fill 253 277 297 253 277 298 minecraft:sandstone
fill 253 277 300 259 277 300 minecraft:sandstone
setblock 254 277 297 minecraft:sandstone
fill 254 277 299 258 277 299 minecraft:sandstone
fill 255 277 298 257 277 298 minecraft:sandstone
fill 256 277 291 260 277 291 minecraft:sandstone
setblock 256 277 297 minecraft:sandstone
fill 258 277 292 258 277 293 minecraft:sandstone
fill 258 277 295 276 277 297 minecraft:sandstone
setblock 259 277 292 minecraft:sandstone
fill 259 277 294 276 277 294 minecraft:sandstone
fill 259 277 298 276 277 298 minecraft:sandstone
fill 259 277 317 260 285 317 minecraft:smooth_sandstone
fill 260 277 293 276 277 293 minecraft:sandstone
fill 260 277 299 276 277 299 minecraft:sandstone
fill 261 277 292 276 277 292 minecraft:sandstone
fill 261 277 300 276 277 300 minecraft:sandstone
setblock 261 277 317 minecraft:blue_terracotta
fill 262 277 291 276 277 291 minecraft:sandstone
fill 262 277 301 276 277 301 minecraft:sandstone
fill 262 277 317 262 285 317 minecraft:smooth_sandstone
fill 263 277 290 276 277 290 minecraft:sandstone
fill 263 277 302 276 277 302 minecraft:sandstone
fill 264 277 289 276 277 289 minecraft:sandstone
fill 264 277 303 276 277 303 minecraft:sandstone
fill 265 277 288 276 277 288 minecraft:sandstone
fill 265 277 304 276 277 304 minecraft:sandstone
fill 266 277 287 276 277 287 minecraft:sandstone
fill 266 277 305 276 277 305 minecraft:sandstone
fill 267 277 286 276 277 286 minecraft:sandstone
fill 267 277 306 276 277 306 minecraft:sandstone
fill 268 277 285 276 277 285 minecraft:sandstone
fill 268 277 307 276 277 307 minecraft:sandstone
fill 269 277 284 276 277 284 minecraft:sandstone
fill 269 277 308 276 277 308 minecraft:sandstone
fill 270 277 283 276 277 283 minecraft:sandstone
fill 270 277 309 276 277 309 minecraft:sandstone
fill 271 277 282 276 277 282 minecraft:sandstone
fill 271 277 310 276 277 310 minecraft:sandstone
fill 272 277 281 276 277 281 minecraft:sandstone
fill 272 277 311 276 277 311 minecraft:sandstone
fill 273 277 280 276 277 280 minecraft:sandstone
fill 273 277 312 276 277 312 minecraft:sandstone
fill 274 277 279 276 277 279 minecraft:sandstone
fill 274 277 313 276 277 313 minecraft:sandstone
fill 275 277 278 276 277 278 minecraft:sandstone
fill 275 277 314 276 277 314 minecraft:sandstone
setblock 276 277 277 minecraft:sandstone
setblock 276 277 315 minecraft:sandstone
fill 235 278 288 247 278 288 minecraft:smooth_sandstone
fill 236 278 277 236 278 287 minecraft:smooth_sandstone
fill 236 278 289 236 278 315 minecraft:smooth_sandstone
fill 237 278 276 275 278 276 minecraft:smooth_sandstone
fill 237 278 278 237 278 287 minecraft:smooth_sandstone
fill 237 278 289 237 278 314 minecraft:smooth_sandstone
fill 237 278 316 275 278 316 minecraft:smooth_sandstone
fill 238 278 277 274 278 277 minecraft:smooth_sandstone
fill 238 278 279 238 278 287 minecraft:smooth_sandstone
fill 238 278 289 238 278 313 minecraft:smooth_sandstone
fill 238 278 315 274 278 315 minecraft:smooth_sandstone
fill 239 278 278 273 278 278 minecraft:smooth_sandstone
fill 239 278 280 239 278 287 minecraft:smooth_sandstone
fill 239 278 289 239 278 312 minecraft:smooth_sandstone
fill 239 278 314 273 278 314 minecraft:smooth_sandstone
fill 240 278 279 272 278 279 minecraft:smooth_sandstone
fill 240 278 281 240 278 287 minecraft:smooth_sandstone
fill 240 278 289 240 278 311 minecraft:smooth_sandstone
fill 240 278 313 272 278 313 minecraft:smooth_sandstone
fill 241 278 280 271 278 280 minecraft:smooth_sandstone
fill 241 278 282 241 278 287 minecraft:smooth_sandstone
fill 241 278 289 241 278 310 minecraft:smooth_sandstone
fill 241 278 312 271 278 312 minecraft:smooth_sandstone
fill 242 278 281 270 278 281 minecraft:smooth_sandstone
fill 242 278 283 242 278 287 minecraft:smooth_sandstone
fill 242 278 289 242 278 309 minecraft:smooth_sandstone
fill 242 278 311 270 278 311 minecraft:smooth_sandstone
fill 243 278 282 269 278 282 minecraft:smooth_sandstone
fill 243 278 284 243 278 287 minecraft:smooth_sandstone
fill 243 278 289 243 278 308 minecraft:smooth_sandstone
fill 243 278 310 269 278 310 minecraft:smooth_sandstone
fill 244 278 283 268 278 283 minecraft:smooth_sandstone
fill 244 278 285 244 278 287 minecraft:smooth_sandstone
fill 244 278 289 244 278 307 minecraft:smooth_sandstone
fill 244 278 309 268 278 309 minecraft:smooth_sandstone
fill 245 278 284 267 278 284 minecraft:smooth_sandstone
fill 245 278 286 245 278 287 minecraft:smooth_sandstone
fill 245 278 289 245 278 306 minecraft:smooth_sandstone
fill 245 278 308 267 278 308 minecraft:smooth_sandstone
fill 246 278 285 266 278 285 minecraft:smooth_sandstone
setblock 246 278 287 minecraft:smooth_sandstone
fill 246 278 289 246 278 305 minecraft:smooth_sandstone
fill 246 278 307 266 278 307 minecraft:smooth_sandstone
fill 247 278 286 265 278 286 minecraft:smooth_sandstone
fill 247 278 289 247 278 304 minecraft:smooth_sandstone
fill 247 278 306 265 278 306 minecraft:smooth_sandstone
fill 247 278 317 248 285 317 minecraft:smooth_sandstone
fill 248 278 287 264 278 287 minecraft:smooth_sandstone
fill 248 278 289 248 278 303 minecraft:smooth_sandstone
fill 248 278 305 264 278 305 minecraft:smooth_sandstone
fill 249 278 288 263 278 288 minecraft:smooth_sandstone
fill 249 278 290 249 278 302 minecraft:smooth_sandstone
fill 249 278 304 263 278 304 minecraft:smooth_sandstone
setblock 249 278 317 minecraft:blue_terracotta
fill 250 278 289 262 278 289 minecraft:smooth_sandstone
fill 250 278 291 250 278 301 minecraft:smooth_sandstone
fill 250 278 303 262 278 303 minecraft:smooth_sandstone
fill 250 278 317 250 285 317 minecraft:smooth_sandstone
fill 251 278 290 261 278 290 minecraft:smooth_sandstone
fill 251 278 292 251 278 300 minecraft:smooth_sandstone
fill 251 278 302 261 278 302 minecraft:smooth_sandstone
fill 252 278 291 254 278 291 minecraft:smooth_sandstone
setblock 252 278 293 minecraft:smooth_sandstone
fill 252 278 295 252 278 299 minecraft:smooth_sandstone
fill 252 278 301 260 278 301 minecraft:smooth_sandstone
fill 253 278 297 253 278 298 minecraft:smooth_sandstone
fill 253 278 300 259 278 300 minecraft:smooth_sandstone
setblock 254 278 297 minecraft:smooth_sandstone
fill 254 278 299 258 278 299 minecraft:smooth_sandstone
fill 255 278 298 257 278 298 minecraft:smooth_sandstone
fill 256 278 291 260 278 291 minecraft:smooth_sandstone
setblock 256 278 297 minecraft:smooth_sandstone
fill 258 278 292 258 278 293 minecraft:smooth_sandstone
fill 258 278 295 276 278 297 minecraft:smooth_sandstone
setblock 259 278 292 minecraft:smooth_sandstone
fill 259 278 294 276 278 294 minecraft:smooth_sandstone
fill 259 278 298 276 278 298 minecraft:smooth_sandstone
fill 260 278 293 276 278 293 minecraft:smooth_sandstone
fill 260 278 299 276 278 299 minecraft:smooth_sandstone
fill 261 278 292 276 278 292 minecraft:smooth_sandstone
fill 261 278 300 276 278 300 minecraft:smooth_sandstone
fill 261 278 317 261 285 317 minecraft:smooth_sandstone
fill 262 278 291 276 278 291 minecraft:smooth_sandstone
fill 262 278 301 276 278 301 minecraft:smooth_sandstone
fill 263 278 290 276 278 290 minecraft:smooth_sandstone
fill 263 278 302 276 278 302 minecraft:smooth_sandstone
fill 264 278 289 276 278 289 minecraft:smooth_sandstone
fill 264 278 303 276 278 303 minecraft:smooth_sandstone
fill 265 278 288 276 278 288 minecraft:smooth_sandstone
fill 265 278 304 276 278 304 minecraft:smooth_sandstone
fill 266 278 287 276 278 287 minecraft:smooth_sandstone
fill 266 278 305 276 278 305 minecraft:smooth_sandstone
fill 267 278 286 276 278 286 minecraft:smooth_sandstone
fill 267 278 306 276 278 306 minecraft:smooth_sandstone
fill 268 278 285 276 278 285 minecraft:smooth_sandstone
fill 268 278 307 276 278 307 minecraft:smooth_sandstone
fill 269 278 284 276 278 284 minecraft:smooth_sandstone
fill 269 278 308 276 278 308 minecraft:smooth_sandstone
fill 270 278 283 276 278 283 minecraft:smooth_sandstone
fill 270 278 309 276 278 309 minecraft:smooth_sandstone
fill 271 278 282 276 278 282 minecraft:smooth_sandstone
fill 271 278 310 276 278 310 minecraft:smooth_sandstone
fill 272 278 281 276 278 281 minecraft:smooth_sandstone
fill 272 278 311 276 278 311 minecraft:smooth_sandstone
fill 273 278 280 276 278 280 minecraft:smooth_sandstone
fill 273 278 312 276 278 312 minecraft:smooth_sandstone
fill 274 278 279 276 278 279 minecraft:smooth_sandstone
fill 274 278 313 276 278 313 minecraft:smooth_sandstone
fill 275 278 278 276 278 278 minecraft:smooth_sandstone
fill 275 278 314 276 278 314 minecraft:smooth_sandstone
setblock 276 278 275 minecraft:lapis_block
setblock 276 278 277 minecraft:smooth_sandstone
setblock 276 278 315 minecraft:smooth_sandstone
fill 277 278 275 277 308 275 minecraft:smooth_sandstone
setblock 277 278 297 minecraft:black_terracotta
fill 235 279 288 235 308 288 minecraft:smooth_sandstone
fill 236 279 276 236 279 316 minecraft:sandstone
fill 237 279 276 276 279 276 minecraft:sandstone
fill 237 279 278 237 279 314 minecraft:sandstone
fill 237 279 316 276 279 316 minecraft:sandstone
fill 238 279 277 274 279 277 minecraft:sandstone
fill 238 279 279 238 279 313 minecraft:sandstone
fill 238 279 315 274 279 315 minecraft:sandstone
fill 239 279 278 273 279 278 minecraft:sandstone
fill 239 279 280 239 279 312 minecraft:sandstone
fill 239 279 314 273 279 314 minecraft:sandstone
fill 240 279 279 272 279 279 minecraft:sandstone
fill 240 279 281 240 279 311 minecraft:sandstone
fill 240 279 313 272 279 313 minecraft:sandstone
fill 241 279 280 271 279 280 minecraft:sandstone
fill 241 279 282 241 279 310 minecraft:sandstone
fill 241 279 312 271 279 312 minecraft:sandstone
fill 242 279 281 270 279 281 minecraft:sandstone
fill 242 279 283 242 279 309 minecraft:sandstone
fill 242 279 311 270 279 311 minecraft:sandstone
fill 243 279 282 269 279 282 minecraft:sandstone
fill 243 279 284 243 279 308 minecraft:sandstone
fill 243 279 310 269 279 310 minecraft:sandstone
fill 244 279 283 268 279 283 minecraft:sandstone
fill 244 279 285 244 279 307 minecraft:sandstone
fill 244 279 309 268 279 309 minecraft:sandstone
fill 245 279 284 267 279 284 minecraft:sandstone
fill 245 279 286 245 279 306 minecraft:sandstone
fill 245 279 308 267 279 308 minecraft:sandstone
fill 246 279 285 266 279 285 minecraft:sandstone
fill 246 279 287 246 279 305 minecraft:sandstone
fill 246 279 307 266 279 307 minecraft:sandstone
fill 247 279 286 265 279 286 minecraft:sandstone
fill 247 279 288 247 279 304 minecraft:sandstone
fill 247 279 306 265 279 306 minecraft:sandstone
fill 248 279 287 264 279 287 minecraft:sandstone
fill 248 279 289 248 279 303 minecraft:sandstone
fill 248 279 305 264 279 305 minecraft:sandstone
fill 249 279 288 263 279 288 minecraft:sandstone
fill 249 279 290 249 279 302 minecraft:sandstone
fill 249 279 304 263 279 304 minecraft:sandstone
fill 249 279 317 249 285 317 minecraft:smooth_sandstone
fill 250 279 289 262 279 289 minecraft:sandstone
fill 250 279 291 250 279 301 minecraft:sandstone
fill 250 279 303 262 279 303 minecraft:sandstone
fill 251 279 290 253 279 290 minecraft:sandstone
setblock 251 279 292 minecraft:sandstone
fill 251 279 293 251 279 295 minecraft:gold_block
fill 251 279 296 251 279 300 minecraft:sandstone
fill 251 279 302 261 279 302 minecraft:sandstone
fill 252 279 291 254 279 291 minecraft:gold_block
setblock 252 279 293 minecraft:gold_block
fill 252 279 295 252 279 297 minecraft:gold_block
fill 252 279 298 252 279 299 minecraft:sandstone
fill 252 279 301 260 279 301 minecraft:sandstone
fill 253 279 297 254 279 297 minecraft:gold_block
setblock 253 279 298 minecraft:sandstone
fill 253 279 300 259 279 300 minecraft:sandstone
fill 254 279 290 256 279 290 minecraft:gold_block
fill 254 279 299 258 279 299 minecraft:sandstone
fill 255 279 298 256 279 298 minecraft:gold_block
fill 256 279 291 258 279 291 minecraft:gold_block
setblock 256 279 297 minecraft:gold_block
fill 257 279 290 261 279 290 minecraft:sandstone
setblock 257 279 298 minecraft:sandstone
fill 258 279 292 258 279 293 minecraft:gold_block
fill 258 279 295 258 279 297 minecraft:gold_block
fill 259 279 291 259 279 292 minecraft:sandstone
fill 259 279 294 259 279 295 minecraft:gold_block
fill 259 279 296 276 279 298 minecraft:sandstone
setblock 260 279 291 minecraft:sandstone
fill 260 279 293 276 279 295 minecraft:sandstone
fill 260 279 299 276 279 299 minecraft:sandstone
fill 261 279 292 276 279 292 minecraft:sandstone
fill 261 279 300 276 279 300 minecraft:sandstone
fill 262 279 291 276 279 291 minecraft:sandstone
fill 262 279 301 276 279 301 minecraft:sandstone
fill 263 279 290 276 279 290 minecraft:sandstone
fill 263 279 302 276 279 302 minecraft:sandstone
fill 264 279 289 276 279 289 minecraft:sandstone
fill 264 279 303 276 279 303 minecraft:sandstone
fill 265 279 288 276 279 288 minecraft:sandstone
fill 265 279 304 276 279 304 minecraft:sandstone
fill 266 279 287 276 279 287 minecraft:sandstone
fill 266 279 305 276 279 305 minecraft:sandstone
fill 267 279 286 276 279 286 minecraft:sandstone
fill 267 279 306 276 279 306 minecraft:sandstone
fill 268 279 285 276 279 285 minecraft:sandstone
fill 268 279 307 276 279 307 minecraft:sandstone
fill 269 279 284 276 279 284 minecraft:sandstone
fill 269 279 308 276 279 308 minecraft:sandstone
fill 270 279 283 276 279 283 minecraft:sandstone
fill 270 279 309 276 279 309 minecraft:sandstone
fill 271 279 282 276 279 282 minecraft:sandstone
fill 271 279 310 276 279 310 minecraft:sandstone
fill 272 279 281 276 279 281 minecraft:sandstone
fill 272 279 311 276 279 311 minecraft:sandstone
fill 273 279 280 276 279 280 minecraft:sandstone
fill 273 279 312 276 279 312 minecraft:sandstone
fill 274 279 279 276 279 279 minecraft:sandstone
fill 274 279 313 276 279 313 minecraft:sandstone
fill 275 279 278 276 279 278 minecraft:sandstone
fill 275 279 314 276 279 314 minecraft:sandstone
fill 276 279 275 276 308 275 minecraft:smooth_sandstone
setblock 276 279 277 minecraft:sandstone
setblock 276 279 315 minecraft:sandstone
fill 277 279 297 277 308 297 minecraft:smooth_sandstone
setblock 235 280 311 minecraft:orange_terracotta
fill 235 280 312 235 308 314 minecraft:smooth_sandstone
fill 239 280 280 239 280 312 minecraft:smooth_sandstone
fill 240 280 279 272 280 279 minecraft:smooth_sandstone
fill 240 280 281 240 280 311 minecraft:smooth_sandstone
fill 240 280 313 272 280 313 minecraft:smooth_sandstone
fill 241 280 280 271 280 280 minecraft:smooth_sandstone
fill 241 280 282 241 280 310 minecraft:smooth_sandstone
fill 241 280 312 271 280 312 minecraft:smooth_sandstone
fill 242 280 281 270 280 281 minecraft:smooth_sandstone
fill 242 280 283 242 280 309 minecraft:smooth_sandstone
fill 242 280 311 270 280 311 minecraft:smooth_sandstone
fill 243 280 282 269 280 282 minecraft:smooth_sandstone
fill 243 280 284 243 280 308 minecraft:smooth_sandstone
fill 243 280 310 269 280 310 minecraft:smooth_sandstone
fill 244 280 283 268 280 283 minecraft:smooth_sandstone
fill 244 280 285 244 280 307 minecraft:smooth_sandstone
fill 244 280 309 268 280 309 minecraft:smooth_sandstone
fill 245 280 284 267 280 284 minecraft:smooth_sandstone
fill 245 280 286 245 280 306 minecraft:smooth_sandstone
fill 245 280 308 267 280 308 minecraft:smooth_sandstone
fill 246 280 285 266 280 285 minecraft:smooth_sandstone
fill 246 280 287 246 280 305 minecraft:smooth_sandstone
fill 246 280 307 266 280 307 minecraft:smooth_sandstone
fill 247 280 286 265 280 286 minecraft:smooth_sandstone
fill 247 280 288 247 280 304 minecraft:smooth_sandstone
fill 247 280 306 265 280 306 minecraft:smooth_sandstone
fill 248 280 287 264 280 287 minecraft:smooth_sandstone
fill 248 280 289 248 280 303 minecraft:smooth_sandstone
fill 248 280 305 264 280 305 minecraft:smooth_sandstone
fill 249 280 288 263 280 288 minecraft:smooth_sandstone
fill 249 280 290 249 280 302 minecraft:smooth_sandstone
fill 249 280 304 263 280 304 minecraft:smooth_sandstone
fill 250 280 289 262 280 289 minecraft:smooth_sandstone
fill 250 280 291 250 280 301 minecraft:smooth_sandstone
fill 250 280 303 262 280 303 minecraft:smooth_sandstone
fill 251 280 290 261 280 290 minecraft:smooth_sandstone
fill 251 280 292 251 280 300 minecraft:smooth_sandstone
fill 251 280 302 261 280 302 minecraft:smooth_sandstone
fill 252 280 291 254 280 291 minecraft:smooth_sandstone
setblock 252 280 293 minecraft:smooth_sandstone
fill 252 280 295 252 280 299 minecraft:smooth_sandstone
fill 252 280 301 260 280 301 minecraft:smooth_sandstone
fill 253 280 297 253 280 298 minecraft:smooth_sandstone
fill 253 280 300 259 280 300 minecraft:smooth_sandstone
setblock 254 280 297 minecraft:smooth_sandstone
fill 254 280 299 258 280 299 minecraft:smooth_sandstone
fill 255 280 298 257 280 298 minecraft:smooth_sandstone
fill 256 280 291 260 280 291 minecraft:smooth_sandstone
setblock 256 280 297 minecraft:smooth_sandstone
fill 258 280 292 258 280 293 minecraft:smooth_sandstone
fill 258 280 295 273 280 297 minecraft:smooth_sandstone
setblock 259 280 292 minecraft:smooth_sandstone
fill 259 280 294 273 280 294 minecraft:smooth_sandstone
fill 259 280 298 273 280 298 minecraft:smooth_sandstone
fill 260 280 293 273 280 293 minecraft:smooth_sandstone
fill 260 280 299 273 280 299 minecraft:smooth_sandstone
fill 261 280 292 273 280 292 minecraft:smooth_sandstone
fill 261 280 300 273 280 300 minecraft:smooth_sandstone
fill 262 280 291 273 280 291 minecraft:smooth_sandstone
fill 262 280 301 273 280 301 minecraft:smooth_sandstone
fill 263 280 290 273 280 290 minecraft:smooth_sandstone
fill 263 280 302 273 280 302 minecraft:smooth_sandstone
fill 264 280 289 273 280 289 minecraft:smooth_sandstone
fill 264 280 303 273 280 303 minecraft:smooth_sandstone
fill 265 280 288 273 280 288 minecraft:smooth_sandstone
fill 265 280 304 273 280 304 minecraft:smooth_sandstone
fill 266 280 287 273 280 287 minecraft:smooth_sandstone
fill 266 280 305 273 280 305 minecraft:smooth_sandstone
fill 267 280 286 273 280 286 minecraft:smooth_sandstone
fill 267 280 306 273 280 306 minecraft:smooth_sandstone
fill 268 280 285 273 280 285 minecraft:smooth_sandstone
fill 268 280 307 273 280 307 minecraft:smooth_sandstone
fill 269 280 284 273 280 284 minecraft:smooth_sandstone
fill 269 280 308 273 280 308 minecraft:smooth_sandstone
fill 270 280 283 273 280 283 minecraft:smooth_sandstone
fill 270 280 309 273 280 309 minecraft:smooth_sandstone
fill 271 280 282 273 280 282 minecraft:smooth_sandstone
fill 271 280 310 273 280 310 minecraft:smooth_sandstone
fill 272 280 281 273 280 281 minecraft:smooth_sandstone
fill 272 280 311 273 280 311 minecraft:smooth_sandstone
setblock 273 280 280 minecraft:smooth_sandstone
setblock 273 280 312 minecraft:smooth_sandstone
setblock 277 280 316 minecraft:lapis_block
fill 235 281 311 235 308 311 minecraft:smooth_sandstone
fill 240 281 281 240 281 311 minecraft:sandstone
fill 241 281 280 271 281 280 minecraft:sandstone
fill 241 281 282 241 281 310 minecraft:sandstone
fill 241 281 312 271 281 312 minecraft:sandstone
fill 242 281 275 242 285 275 minecraft:smooth_sandstone
fill 242 281 281 270 281 281 minecraft:sandstone
fill 242 281 283 242 281 309 minecraft:sandstone
fill 242 281 311 270 281 311 minecraft:sandstone
setblock 243 281 275 minecraft:blue_terracotta
fill 243 281 282 269 281 282 minecraft:sandstone
fill 243 281 284 243 281 308 minecraft:sandstone
fill 243 281 310 269 281 310 minecraft:sandstone
fill 244 281 275 245 285 275 minecraft:smooth_sandstone
fill 244 281 283 268 281 283 minecraft:sandstone
fill 244 281 285 244 281 307 minecraft:sandstone
fill 244 281 309 268 281 309 minecraft:sandstone
fill 245 281 284 267 281 284 minecraft:sandstone
fill 245 281 286 245 281 306 minecraft:sandstone
fill 245 281 308 267 281 308 minecraft:sandstone
fill 246 281 285 266 281 285 minecraft:sandstone
fill 246 281 287 246 281 305 minecraft:sandstone
fill 246 281 307 266 281 307 minecraft:sandstone
fill 247 281 286 265 281 286 minecraft:sandstone
fill 247 281 288 247 281 304 minecraft:sandstone
fill 247 281 306 265 281 306 minecraft:sandstone
fill 248 281 287 264 281 287 minecraft:sandstone
fill 248 281 289 248 281 303 minecraft:sandstone
fill 248 281 305 264 281 305 minecraft:sandstone
fill 249 281 288 263 281 288 minecraft:sandstone
fill 249 281 290 249 281 302 minecraft:sandstone
fill 249 281 304 263 281 304 minecraft:sandstone
fill 250 281 289 262 281 289 minecraft:sandstone
fill 250 281 291 250 281 301 minecraft:sandstone
fill 250 281 303 262 281 303 minecraft:sandstone
fill 251 281 290 261 281 290 minecraft:sandstone
fill 251 281 292 251 281 300 minecraft:sandstone
fill 251 281 302 261 281 302 minecraft:sandstone
fill 252 281 291 254 281 291 minecraft:sandstone
setblock 252 281 293 minecraft:sandstone
fill 252 281 295 252 281 299 minecraft:sandstone
fill 252 281 301 260 281 301 minecraft:sandstone
fill 253 281 297 253 281 298 minecraft:sandstone
fill 253 281 300 259 281 300 minecraft:sandstone
setblock 254 281 297 minecraft:sandstone
fill 254 281 299 258 281 299 minecraft:sandstone
fill 255 281 298 257 281 298 minecraft:sandstone
fill 256 281 291 260 281 291 minecraft:sandstone
setblock 256 281 297 minecraft:sandstone
fill 258 281 292 258 281 293 minecraft:sandstone
fill 258 281 295 272 281 297 minecraft:sandstone
setblock 259 281 292 minecraft:sandstone
fill 259 281 294 272 281 294 minecraft:sandstone
fill 259 281 298 272 281 298 minecraft:sandstone
fill 260 281 293 272 281 293 minecraft:sandstone
fill 260 281 299 272 281 299 minecraft:sandstone
fill 261 281 292 272 281 292 minecraft:sandstone
fill 261 281 300 272 281 300 minecraft:sandstone
fill 262 281 291 272 281 291 minecraft:sandstone
fill 262 281 301 272 281 301 minecraft:sandstone
fill 263 281 290 272 281 290 minecraft:sandstone
fill 263 281 302 272 281 302 minecraft:sandstone
fill 264 281 289 272 281 289 minecraft:sandstone
fill 264 281 303 272 281 303 minecraft:sandstone
fill 265 281 288 272 281 288 minecraft:sandstone
fill 265 281 304 272 281 304 minecraft:sandstone
fill 266 281 287 272 281 287 minecraft:sandstone
fill 266 281 305 272 281 305 minecraft:sandstone
fill 267 281 286 272 281 286 minecraft:sandstone
fill 267 281 306 272 281 306 minecraft:sandstone
fill 268 281 285 272 281 285 minecraft:sandstone
fill 268 281 307 272 281 307 minecraft:sandstone
fill 269 281 284 272 281 284 minecraft:sandstone
fill 269 281 308 272 281 308 minecraft:sandstone
fill 270 281 283 272 281 283 minecraft:sandstone
fill 270 281 309 272 281 309 minecraft:sandstone
fill 271 281 282 272 281 282 minecraft:sandstone
fill 271 281 310 272 281 310 minecraft:sandstone
setblock 272 281 281 minecraft:sandstone
setblock 272 281 311 minecraft:sandstone
fill 277 281 316 277 291 316 minecraft:smooth_sandstone
setblock 235 282 303 minecraft:orange_terracotta
fill 241 282 282 241 282 310 minecraft:smooth_sandstone
fill 242 282 281 270 282 281 minecraft:smooth_sandstone
fill 242 282 283 242 282 309 minecraft:smooth_sandstone
fill 242 282 311 270 282 311 minecraft:smooth_sandstone
fill 243 282 275 243 285 275 minecraft:smooth_sandstone
fill 243 282 282 269 282 282 minecraft:smooth_sandstone
fill 243 282 284 243 282 308 minecraft:smooth_sandstone
fill 243 282 310 269 282 310 minecraft:smooth_sandstone
fill 244 282 283 268 282 283 minecraft:smooth_sandstone
fill 244 282 285 244 282 307 minecraft:smooth_sandstone
fill 244 282 309 268 282 309 minecraft:smooth_sandstone
fill 245 282 284 267 282 284 minecraft:smooth_sandstone
fill 245 282 286 245 282 306 minecraft:smooth_sandstone
fill 245 282 308 267 282 308 minecraft:smooth_sandstone
fill 246 282 285 266 282 285 minecraft:smooth_sandstone
fill 246 282 287 246 282 305 minecraft:smooth_sandstone
fill 246 282 307 266 282 307 minecraft:smooth_sandstone
fill 247 282 286 265 282 286 minecraft:smooth_sandstone
fill 247 282 288 247 282 304 minecraft:smooth_sandstone
fill 247 282 306 265 282 306 minecraft:smooth_sandstone
fill 248 282 287 264 282 287 minecraft:smooth_sandstone
fill 248 282 289 248 282 303 minecraft:smooth_sandstone
fill 248 282 305 264 282 305 minecraft:smooth_sandstone
fill 249 282 288 263 282 288 minecraft:smooth_sandstone
fill 249 282 290 249 282 302 minecraft:smooth_sandstone
fill 249 282 304 263 282 304 minecraft:smooth_sandstone
fill 250 282 289 262 282 289 minecraft:smooth_sandstone
fill 250 282 291 250 282 301 minecraft:smooth_sandstone
fill 250 282 303 262 282 303 minecraft:smooth_sandstone
fill 251 282 290 261 282 290 minecraft:smooth_sandstone
fill 251 282 292 251 282 300 minecraft:smooth_sandstone
fill 251 282 302 261 282 302 minecraft:smooth_sandstone
fill 252 282 291 260 282 291 minecraft:smooth_sandstone
fill 252 282 293 252 282 299 minecraft:smooth_sandstone
fill 252 282 301 260 282 301 minecraft:smooth_sandstone
fill 253 282 292 259 282 292 minecraft:smooth_sandstone
fill 253 282 293 253 291 293 minecraft:gold_block
fill 253 282 294 253 282 298 minecraft:smooth_sandstone
fill 253 282 300 259 282 300 minecraft:smooth_sandstone
setblock 254 282 293 minecraft:smooth_sandstone
fill 254 282 295 254 282 297 minecraft:smooth_sandstone
fill 254 282 299 258 282 299 minecraft:smooth_sandstone
setblock 255 282 296 minecraft:smooth_sandstone
fill 255 282 297 255 292 297 minecraft:gold_block
fill 255 282 298 257 282 298 minecraft:smooth_sandstone
fill 256 282 293 258 282 293 minecraft:smooth_sandstone
setblock 256 282 295 minecraft:smooth_sandstone
fill 256 282 296 256 293 296 minecraft:gold_block
setblock 256 282 297 minecraft:smooth_sandstone
setblock 257 282 294 minecraft:smooth_sandstone
fill 257 282 295 257 292 295 minecraft:gold_block
fill 257 282 296 271 282 296 minecraft:smooth_sandstone
fill 258 282 294 258 291 294 minecraft:gold_block
fill 258 282 295 271 282 295 minecraft:smooth_sandstone
fill 258 282 297 271 282 297 minecraft:smooth_sandstone
fill 259 282 294 271 282 294 minecraft:smooth_sandstone
fill 259 282 298 271 282 298 minecraft:smooth_sandstone
fill 260 282 293 271 282 293 minecraft:smooth_sandstone
fill 260 282 299 271 282 299 minecraft:smooth_sandstone
fill 261 282 292 271 282 292 minecraft:smooth_sandstone
fill 261 282 300 271 282 300 minecraft:smooth_sandstone
fill 262 282 291 271 282 291 minecraft:smooth_sandstone
fill 262 282 301 271 282 301 minecraft:smooth_sandstone
fill 263 282 290 271 282 290 minecraft:smooth_sandstone
fill 263 282 302 271 282 302 minecraft:smooth_sandstone
fill 264 282 289 271 282 289 minecraft:smooth_sandstone
fill 264 282 303 271 282 303 minecraft:smooth_sandstone
fill 265 282 288 271 282 288 minecraft:smooth_sandstone
fill 265 282 304 271 282 304 minecraft:smooth_sandstone
fill 266 282 287 271 282 287 minecraft:smooth_sandstone
fill 266 282 305 271 282 305 minecraft:smooth_sandstone
fill 267 282 286 271 282 286 minecraft:smooth_sandstone
fill 267 282 306 271 282 306 minecraft:smooth_sandstone
fill 268 282 285 271 282 285 minecraft:smooth_sandstone
fill 268 282 307 271 282 307 minecraft:smooth_sandstone
fill 269 282 284 271 282 284 minecraft:smooth_sandstone
fill 269 282 308 271 282 308 minecraft:smooth_sandstone
fill 270 282 283 271 282 283 minecraft:smooth_sandstone
fill 270 282 309 271 282 309 minecraft:smooth_sandstone
setblock 271 282 282 minecraft:smooth_sandstone
setblock 271 282 310 minecraft:smooth_sandstone
fill 235 283 303 235 308 303 minecraft:smooth_sandstone
setblock 235 283 305 minecraft:black_terracotta
fill 235 283 306 235 285 308 minecraft:smooth_sandstone
fill 236 283 276 242 284 283 minecraft:cut_sandstone
fill 236 283 286 236 300 288 minecraft:cut_sandstone
fill 236 283 298 236 300 300 minecraft:cut_sandstone
fill 236 283 310 236 300 312 minecraft:cut_sandstone
fill 237 283 285 237 285 287 minecraft:cut_sandstone
fill 237 283 297 237 285 299 minecraft:cut_sandstone
fill 237 283 309 237 285 311 minecraft:cut_sandstone
fill 239 283 310 239 283 313 minecraft:chiseled_sandstone
fill 240 283 309 242 283 309 minecraft:chiseled_sandstone
fill 240 283 310 242 300 312 minecraft:cut_sandstone
setblock 240 283 313 minecraft:chiseled_sandstone
fill 241 283 313 241 300 313 minecraft:cut_sandstone
setblock 241 283 317 minecraft:orange_terracotta
setblock 242 283 313 minecraft:chiseled_sandstone
fill 242 283 316 244 300 316 minecraft:cut_sandstone
fill 243 283 276 244 284 282 minecraft:cut_sandstone
fill 243 283 284 243 283 308 minecraft:sandstone
fill 243 283 310 243 283 312 minecraft:chiseled_sandstone
fill 243 283 315 245 285 315 minecraft:cut_sandstone
fill 244 283 283 268 283 283 minecraft:sandstone
fill 244 283 285 244 283 307 minecraft:sandstone
fill 244 283 309 268 283 309 minecraft:sandstone
fill 245 283 284 267 283 284 minecraft:sandstone
fill 245 283 286 245 283 306 minecraft:sandstone
fill 245 283 308 267 283 308 minecraft:sandstone
fill 246 283 285 266 283 285 minecraft:sandstone
fill 246 283 287 246 283 305 minecraft:sandstone
fill 246 283 307 266 283 307 minecraft:sandstone
fill 247 283 277 249 285 277 minecraft:cut_sandstone
fill 247 283 286 265 283 286 minecraft:sandstone
fill 247 283 288 247 283 304 minecraft:sandstone
fill 247 283 306 265 283 306 minecraft:sandstone
fill 248 283 276 250 300 276 minecraft:cut_sandstone
fill 248 283 287 264 283 287 minecraft:sandstone
fill 248 283 289 248 283 303 minecraft:sandstone
fill 248 283 305 264 283 305 minecraft:sandstone
fill 249 283 288 263 283 288 minecraft:sandstone
fill 249 283 290 249 283 302 minecraft:sandstone
fill 249 283 304 263 283 304 minecraft:sandstone
fill 250 283 289 262 283 289 minecraft:sandstone
fill 250 283 291 250 283 301 minecraft:sandstone
fill 250 283 303 262 283 303 minecraft:sandstone
fill 251 283 290 261 283 290 minecraft:sandstone
fill 251 283 292 251 283 300 minecraft:sandstone
fill 251 283 302 261 283 302 minecraft:sandstone
fill 252 283 291 260 283 291 minecraft:sandstone
fill 252 283 293 252 283 299 minecraft:sandstone
fill 252 283 301 260 283 301 minecraft:sandstone
fill 253 283 292 259 283 292 minecraft:sandstone
fill 253 283 294 253 283 298 minecraft:sandstone
fill 253 283 300 259 283 300 minecraft:sandstone
setblock 254 283 293 minecraft:sandstone
fill 254 283 295 254 283 297 minecraft:sandstone
fill 254 283 299 258 283 299 minecraft:sandstone
schedule function dropper:buildpart/65_4 1t
