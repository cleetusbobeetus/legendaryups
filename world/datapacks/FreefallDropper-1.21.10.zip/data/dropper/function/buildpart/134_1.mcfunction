fill 136 78 596 136 92 597 minecraft:black_concrete
fill 94 79 562 94 132 562 minecraft:black_concrete
fill 111 79 599 111 132 599 minecraft:black_concrete
setblock 112 79 599 minecraft:pearlescent_froglight
fill 127 79 557 128 129 557 minecraft:black_concrete
setblock 127 79 599 minecraft:white_stained_glass
fill 128 79 599 128 82 599 minecraft:black_concrete
setblock 129 79 557 minecraft:pearlescent_froglight
fill 136 79 580 136 132 580 minecraft:black_concrete
fill 136 79 595 136 96 595 minecraft:black_concrete
setblock 97 80 560 minecraft:light[level=14]
setblock 97 80 568 minecraft:light[level=14]
setblock 97 80 576 minecraft:light[level=14]
setblock 97 80 584 minecraft:light[level=14]
setblock 97 80 592 minecraft:light[level=14]
fill 103 80 573 103 84 574 minecraft:gray_concrete
fill 104 80 572 105 84 572 minecraft:gray_concrete
fill 104 80 575 105 84 575 minecraft:gray_concrete
setblock 105 80 560 minecraft:light[level=14]
setblock 105 80 568 minecraft:light[level=14]
setblock 105 80 576 minecraft:light[level=14]
setblock 105 80 584 minecraft:light[level=14]
fill 106 80 573 106 84 574 minecraft:gray_concrete
fill 112 80 599 112 129 599 minecraft:black_concrete
setblock 113 80 560 minecraft:light[level=14]
setblock 113 80 568 minecraft:light[level=14]
setblock 113 80 576 minecraft:light[level=14]
setblock 113 80 584 minecraft:light[level=14]
setblock 113 80 592 minecraft:light[level=14]
setblock 121 80 560 minecraft:light[level=14]
setblock 121 80 568 minecraft:light[level=14]
setblock 121 80 576 minecraft:light[level=14]
setblock 121 80 584 minecraft:light[level=14]
setblock 121 80 592 minecraft:light[level=14]
setblock 127 80 599 minecraft:black_concrete
fill 129 80 557 129 99 557 minecraft:black_concrete
setblock 129 80 560 minecraft:light[level=14]
setblock 129 80 568 minecraft:light[level=14]
setblock 129 80 576 minecraft:light[level=14]
setblock 129 80 584 minecraft:light[level=14]
setblock 129 80 592 minecraft:light[level=14]
fill 103 81 572 103 84 572 minecraft:gray_concrete
fill 103 81 575 103 84 575 minecraft:gray_concrete
fill 106 81 572 106 84 572 minecraft:gray_concrete
fill 106 81 575 106 84 575 minecraft:gray_concrete
setblock 113 81 557 minecraft:white_stained_glass
fill 124 81 574 125 82 575 minecraft:end_stone
setblock 127 81 599 minecraft:white_stained_glass
setblock 136 81 562 minecraft:pearlescent_froglight
fill 94 82 565 94 83 565 minecraft:light_gray_concrete
fill 94 82 581 94 83 581 minecraft:light_gray_concrete
fill 94 82 597 94 83 597 minecraft:light_gray_concrete
fill 98 82 557 98 83 557 minecraft:light_gray_concrete
fill 102 82 572 102 84 574 minecraft:gray_concrete
fill 104 82 571 105 84 571 minecraft:gray_concrete
fill 104 82 576 105 84 576 minecraft:gray_concrete
fill 105 82 592 107 82 594 minecraft:light_gray_concrete
fill 107 82 573 107 84 574 minecraft:gray_concrete
fill 108 82 599 108 83 599 minecraft:light_gray_concrete
fill 113 82 557 113 130 557 minecraft:black_concrete
fill 114 82 557 114 83 557 minecraft:light_gray_concrete
fill 124 82 599 124 83 599 minecraft:light_gray_concrete
fill 127 82 599 127 126 599 minecraft:black_concrete
fill 130 82 557 130 83 557 minecraft:light_gray_concrete
fill 136 82 562 136 128 562 minecraft:black_concrete
fill 136 82 567 136 83 567 minecraft:light_gray_concrete
fill 136 82 582 136 128 582 minecraft:black_concrete
fill 136 82 583 136 83 583 minecraft:light_gray_concrete
setblock 94 83 560 minecraft:white_stained_glass
fill 94 83 561 94 89 561 minecraft:black_concrete
setblock 94 83 579 minecraft:white_concrete
fill 100 83 584 102 84 584 minecraft:light_gray_concrete
fill 101 83 583 101 84 583 minecraft:light_gray_concrete
fill 101 83 585 101 84 585 minecraft:light_gray_concrete
fill 102 83 575 102 84 575 minecraft:gray_concrete
fill 103 83 571 103 84 571 minecraft:gray_concrete
fill 103 83 576 103 84 576 minecraft:gray_concrete
fill 105 83 593 107 83 593 minecraft:light_gray_concrete
fill 106 83 571 106 84 571 minecraft:gray_concrete
fill 106 83 576 106 84 576 minecraft:gray_concrete
setblock 106 83 592 minecraft:light_gray_concrete
setblock 106 83 594 minecraft:light_gray_concrete
fill 107 83 572 107 84 572 minecraft:gray_concrete
fill 107 83 575 107 84 575 minecraft:gray_concrete
setblock 128 83 599 minecraft:white_stained_glass
fill 94 84 560 94 93 560 minecraft:black_concrete
fill 94 84 565 94 90 565 minecraft:black_concrete
setblock 94 84 573 minecraft:white_concrete
fill 94 84 574 94 129 574 minecraft:black_concrete
fill 94 84 579 94 102 579 minecraft:black_concrete
fill 94 84 581 94 90 581 minecraft:black_concrete
setblock 94 84 590 minecraft:pearlescent_froglight
fill 94 84 591 94 107 592 minecraft:black_concrete
fill 94 84 597 94 90 597 minecraft:black_concrete
fill 98 84 557 98 90 557 minecraft:black_concrete
setblock 99 84 599 minecraft:pearlescent_froglight
fill 101 84 572 101 84 575 minecraft:gray_concrete
setblock 102 84 571 minecraft:gray_concrete
setblock 102 84 576 minecraft:gray_concrete
fill 103 84 570 105 84 570 minecraft:gray_concrete
fill 104 84 577 105 84 577 minecraft:gray_concrete
fill 106 84 593 106 85 593 minecraft:light_gray_concrete
setblock 107 84 571 minecraft:gray_concrete
setblock 107 84 576 minecraft:gray_concrete
fill 108 84 573 108 84 574 minecraft:gray_concrete
fill 108 84 599 108 90 599 minecraft:black_concrete
fill 114 84 557 114 90 557 minecraft:black_concrete
fill 124 84 599 124 90 599 minecraft:black_concrete
fill 128 84 599 128 132 599 minecraft:black_concrete
fill 130 84 557 130 90 557 minecraft:black_concrete
fill 136 84 567 136 89 567 minecraft:black_concrete
fill 136 84 583 136 90 583 minecraft:black_concrete
fill 94 85 573 94 128 573 minecraft:black_concrete
fill 94 85 590 94 91 590 minecraft:black_concrete
fill 99 85 599 99 130 599 minecraft:black_concrete
setblock 100 85 557 minecraft:pearlescent_froglight
fill 103 85 573 103 87 573 minecraft:end_stone
fill 105 85 575 105 86 575 minecraft:end_stone
fill 106 85 573 106 86 573 minecraft:end_stone
setblock 115 85 557 minecraft:white_stained_glass
fill 116 85 557 117 129 557 minecraft:black_concrete
setblock 124 85 557 minecraft:white_stained_glass
fill 136 85 584 136 92 586 minecraft:black_concrete
setblock 136 85 587 minecraft:white_stained_glass
fill 94 86 575 94 107 575 minecraft:black_concrete
setblock 94 86 576 minecraft:white_stained_glass
fill 94 86 577 94 132 577 minecraft:black_concrete
setblock 94 86 582 minecraft:white_stained_glass
fill 94 86 583 94 130 584 minecraft:black_concrete
setblock 94 86 589 minecraft:pearlescent_froglight
fill 100 86 557 100 132 557 minecraft:black_concrete
fill 115 86 557 115 129 557 minecraft:black_concrete
fill 124 86 557 124 132 557 minecraft:black_concrete
fill 136 86 587 136 132 587 minecraft:black_concrete
setblock 136 86 591 minecraft:white_concrete
setblock 136 86 592 minecraft:pearlescent_froglight
fill 94 87 576 94 91 576 minecraft:black_concrete
fill 94 87 582 94 131 582 minecraft:black_concrete
fill 94 87 589 94 128 589 minecraft:black_concrete
setblock 134 87 599 minecraft:white_stained_glass
fill 136 87 572 136 132 572 minecraft:black_concrete
setblock 136 87 573 minecraft:white_stained_glass
setblock 136 87 577 minecraft:white_stained_glass
fill 136 87 578 136 90 578 minecraft:black_concrete
fill 136 87 591 136 132 592 minecraft:black_concrete
setblock 94 88 569 minecraft:white_stained_glass
fill 94 88 570 94 128 570 minecraft:black_concrete
setblock 96 88 599 minecraft:white_stained_glass
setblock 97 88 560 minecraft:light[level=14]
setblock 97 88 568 minecraft:light[level=14]
setblock 97 88 576 minecraft:light[level=14]
setblock 97 88 584 minecraft:light[level=14]
setblock 97 88 592 minecraft:light[level=14]
setblock 105 88 560 minecraft:light[level=14]
setblock 105 88 568 minecraft:light[level=14]
setblock 105 88 576 minecraft:light[level=14]
setblock 105 88 584 minecraft:light[level=14]
setblock 105 88 592 minecraft:light[level=14]
setblock 113 88 560 minecraft:light[level=14]
setblock 113 88 568 minecraft:light[level=14]
setblock 113 88 576 minecraft:light[level=14]
setblock 113 88 584 minecraft:light[level=14]
setblock 113 88 592 minecraft:light[level=14]
setblock 121 88 560 minecraft:light[level=14]
setblock 121 88 568 minecraft:light[level=14]
setblock 121 88 576 minecraft:light[level=14]
setblock 121 88 584 minecraft:light[level=14]
setblock 121 88 592 minecraft:light[level=14]
setblock 129 88 560 minecraft:light[level=14]
setblock 129 88 568 minecraft:light[level=14]
setblock 129 88 576 minecraft:light[level=14]
setblock 129 88 584 minecraft:light[level=14]
setblock 129 88 592 minecraft:light[level=14]
fill 134 88 599 134 132 599 minecraft:black_concrete
fill 136 88 573 136 106 573 minecraft:black_concrete
fill 136 88 577 136 112 577 minecraft:black_concrete
fill 94 89 569 94 129 569 minecraft:black_concrete
fill 96 89 599 96 130 599 minecraft:black_concrete
fill 107 89 576 107 90 577 minecraft:gray_concrete
setblock 94 90 558 minecraft:pearlescent_froglight
setblock 94 90 561 minecraft:pearlescent_froglight
setblock 100 90 599 minecraft:pearlescent_froglight
setblock 101 90 557 minecraft:white_stained_glass
fill 117 90 599 117 127 599 minecraft:black_concrete
setblock 118 90 599 minecraft:white_stained_glass
setblock 136 90 567 minecraft:pearlescent_froglight
fill 94 91 558 94 132 558 minecraft:black_concrete
fill 94 91 561 94 101 561 minecraft:black_concrete
fill 94 91 565 94 92 565 minecraft:light_gray_concrete
fill 94 91 581 94 92 581 minecraft:light_gray_concrete
fill 94 91 597 94 92 597 minecraft:light_gray_concrete
fill 98 91 557 98 92 557 minecraft:light_gray_concrete
fill 100 91 599 100 105 599 minecraft:black_concrete
fill 101 91 557 101 132 557 minecraft:black_concrete
fill 108 91 599 108 92 599 minecraft:light_gray_concrete
fill 114 91 557 114 92 557 minecraft:light_gray_concrete
setblock 118 91 599 minecraft:white_concrete
fill 124 91 599 124 92 599 minecraft:light_gray_concrete
fill 130 91 557 130 92 557 minecraft:light_gray_concrete
fill 136 91 567 136 92 567 minecraft:light_gray_concrete
setblock 136 91 578 minecraft:white_stained_glass
fill 136 91 583 136 92 583 minecraft:light_gray_concrete
setblock 94 92 576 minecraft:white_concrete
setblock 94 92 590 minecraft:white_stained_glass
fill 101 92 599 101 117 599 minecraft:black_concrete
setblock 102 92 599 minecraft:white_concrete
fill 118 92 599 118 99 599 minecraft:black_concrete
fill 136 92 578 136 128 578 minecraft:black_concrete
fill 94 93 565 94 99 565 minecraft:black_concrete
fill 94 93 576 94 112 576 minecraft:black_concrete
fill 94 93 581 94 99 581 minecraft:black_concrete
fill 94 93 590 94 132 590 minecraft:black_concrete
fill 94 93 597 94 99 597 minecraft:black_concrete
fill 98 93 557 98 97 557 minecraft:black_concrete
fill 102 93 599 102 130 599 minecraft:black_concrete
fill 108 93 599 108 99 599 minecraft:black_concrete
fill 114 93 557 114 99 557 minecraft:black_concrete
fill 124 93 599 124 99 599 minecraft:black_concrete
fill 130 93 557 130 99 557 minecraft:black_concrete
fill 136 93 567 136 99 567 minecraft:black_concrete
fill 136 93 583 136 99 584 minecraft:black_concrete
setblock 136 93 585 minecraft:white_concrete
fill 136 93 586 136 130 586 minecraft:black_concrete
setblock 136 93 596 minecraft:white_stained_glass
fill 136 93 597 136 98 597 minecraft:black_concrete
setblock 94 94 560 minecraft:pearlescent_froglight
setblock 94 94 594 minecraft:pearlescent_froglight
fill 136 94 563 136 95 565 minecraft:black_concrete
setblock 136 94 566 minecraft:white_concrete
fill 136 94 585 136 124 585 minecraft:black_concrete
fill 136 94 596 136 129 596 minecraft:black_concrete
fill 94 95 560 94 132 560 minecraft:black_concrete
fill 94 95 594 94 119 594 minecraft:black_concrete
setblock 110 95 599 minecraft:white_concrete
setblock 131 95 599 minecraft:white_concrete
fill 136 95 566 136 128 566 minecraft:black_concrete
setblock 97 96 560 minecraft:light[level=14]
setblock 97 96 568 minecraft:light[level=14]
setblock 97 96 576 minecraft:light[level=14]
setblock 97 96 584 minecraft:light[level=14]
setblock 97 96 592 minecraft:light[level=14]
setblock 97 96 599 minecraft:pearlescent_froglight
setblock 105 96 560 minecraft:light[level=14]
setblock 105 96 568 minecraft:light[level=14]
setblock 105 96 576 minecraft:light[level=14]
setblock 105 96 584 minecraft:light[level=14]
setblock 105 96 592 minecraft:light[level=14]
fill 110 96 599 110 132 599 minecraft:black_concrete
setblock 113 96 560 minecraft:light[level=14]
setblock 113 96 568 minecraft:light[level=14]
setblock 113 96 576 minecraft:light[level=14]
setblock 113 96 584 minecraft:light[level=14]
setblock 113 96 592 minecraft:light[level=14]
setblock 121 96 560 minecraft:light[level=14]
setblock 121 96 568 minecraft:light[level=14]
setblock 121 96 576 minecraft:light[level=14]
setblock 121 96 584 minecraft:light[level=14]
setblock 121 96 592 minecraft:light[level=14]
setblock 129 96 560 minecraft:light[level=14]
setblock 129 96 568 minecraft:light[level=14]
setblock 129 96 576 minecraft:light[level=14]
setblock 129 96 584 minecraft:light[level=14]
setblock 129 96 592 minecraft:light[level=14]
fill 131 96 599 131 113 599 minecraft:black_concrete
fill 136 96 563 136 128 564 minecraft:black_concrete
setblock 136 96 565 minecraft:white_concrete
fill 97 97 599 97 121 599 minecraft:black_concrete
setblock 135 97 557 minecraft:white_stained_glass
fill 136 97 565 136 126 565 minecraft:black_concrete
fill 136 97 589 136 128 589 minecraft:black_concrete
setblock 136 97 590 minecraft:white_stained_glass
setblock 136 97 595 minecraft:pearlescent_froglight
setblock 98 98 557 minecraft:white_concrete
setblock 107 98 557 minecraft:pearlescent_froglight
setblock 133 98 557 minecraft:white_stained_glass
fill 135 98 557 135 115 557 minecraft:black_concrete
fill 136 98 590 136 132 590 minecraft:black_concrete
fill 136 98 595 136 118 595 minecraft:black_concrete
setblock 98 99 557 minecraft:black_concrete
fill 107 99 557 107 132 557 minecraft:black_concrete
fill 133 99 557 133 128 557 minecraft:black_concrete
setblock 136 99 597 minecraft:white_stained_glass
fill 94 100 565 94 101 565 minecraft:light_gray_concrete
fill 94 100 581 94 101 581 minecraft:light_gray_concrete
fill 94 100 597 94 101 597 minecraft:light_gray_concrete
fill 98 100 557 98 101 557 minecraft:light_gray_concrete
fill 108 100 599 108 101 599 minecraft:light_gray_concrete
fill 114 100 557 114 101 557 minecraft:light_gray_concrete
setblock 118 100 599 minecraft:white_concrete
fill 124 100 599 124 101 599 minecraft:light_gray_concrete
setblock 129 100 557 minecraft:pearlescent_froglight
fill 130 100 557 130 101 557 minecraft:light_gray_concrete
setblock 130 100 599 minecraft:pearlescent_froglight
setblock 136 100 560 minecraft:white_stained_glass
setblock 136 100 561 minecraft:black_concrete
fill 136 100 567 136 101 567 minecraft:light_gray_concrete
fill 136 100 583 136 101 583 minecraft:light_gray_concrete
fill 136 100 584 136 132 584 minecraft:black_concrete
fill 136 100 597 136 129 597 minecraft:black_concrete
fill 118 101 599 118 118 599 minecraft:black_concrete
fill 129 101 557 129 132 557 minecraft:black_concrete
fill 130 101 599 130 129 599 minecraft:black_concrete
fill 136 101 560 136 132 560 minecraft:black_concrete
setblock 136 101 561 minecraft:white_concrete
setblock 136 101 568 minecraft:pearlescent_froglight
setblock 94 102 561 minecraft:white_concrete
fill 94 102 565 94 104 565 minecraft:black_concrete
fill 94 102 567 94 104 567 minecraft:black_concrete
setblock 94 102 568 minecraft:white_stained_glass
fill 94 102 581 94 108 581 minecraft:black_concrete
fill 94 102 597 94 108 597 minecraft:black_concrete
fill 98 102 557 98 108 557 minecraft:black_concrete
setblock 108 102 599 minecraft:pearlescent_froglight
fill 114 102 557 114 108 557 minecraft:black_concrete
fill 124 102 599 124 108 599 minecraft:black_concrete
fill 130 102 557 130 108 557 minecraft:black_concrete
fill 136 102 561 136 128 561 minecraft:black_concrete
fill 136 102 567 136 106 568 minecraft:black_concrete
fill 136 102 583 136 108 583 minecraft:black_concrete
fill 94 103 561 94 132 561 minecraft:black_concrete
fill 94 103 568 94 117 568 minecraft:black_concrete
setblock 94 103 579 minecraft:white_stained_glass
fill 108 103 599 108 108 599 minecraft:black_concrete
setblock 111 103 557 minecraft:pearlescent_froglight
setblock 122 103 599 minecraft:pearlescent_froglight
setblock 136 103 569 minecraft:pearlescent_froglight
fill 136 103 570 136 116 570 minecraft:black_concrete
fill 94 104 579 94 132 579 minecraft:black_concrete
setblock 97 104 560 minecraft:light[level=14]
setblock 97 104 568 minecraft:light[level=14]
setblock 97 104 576 minecraft:light[level=14]
setblock 97 104 584 minecraft:light[level=14]
setblock 97 104 592 minecraft:light[level=14]
setblock 105 104 560 minecraft:light[level=14]
setblock 105 104 568 minecraft:light[level=14]
setblock 105 104 576 minecraft:light[level=14]
setblock 105 104 584 minecraft:light[level=14]
setblock 105 104 592 minecraft:light[level=14]
fill 111 104 557 111 116 557 minecraft:black_concrete
setblock 113 104 560 minecraft:light[level=14]
setblock 113 104 568 minecraft:light[level=14]
setblock 113 104 576 minecraft:light[level=14]
setblock 113 104 584 minecraft:light[level=14]
setblock 113 104 592 minecraft:light[level=14]
fill 120 104 569 122 105 569 minecraft:end_stone
setblock 121 104 560 minecraft:light[level=14]
fill 121 104 568 121 105 568 minecraft:end_stone
fill 121 104 570 121 105 570 minecraft:end_stone
setblock 121 104 576 minecraft:light[level=14]
setblock 121 104 584 minecraft:light[level=14]
setblock 121 104 592 minecraft:light[level=14]
fill 122 104 599 122 132 599 minecraft:black_concrete
setblock 129 104 560 minecraft:light[level=14]
setblock 129 104 568 minecraft:light[level=14]
setblock 129 104 576 minecraft:light[level=14]
setblock 129 104 584 minecraft:light[level=14]
setblock 129 104 592 minecraft:light[level=14]
fill 136 104 569 136 132 569 minecraft:black_concrete
setblock 94 105 565 minecraft:pearlescent_froglight
setblock 94 105 567 minecraft:white_stained_glass
setblock 98 105 599 minecraft:white_stained_glass
fill 94 106 565 94 108 565 minecraft:black_concrete
fill 94 106 567 94 130 567 minecraft:black_concrete
setblock 94 106 585 minecraft:white_stained_glass
fill 98 106 599 98 132 599 minecraft:black_concrete
setblock 100 106 599 minecraft:white_concrete
fill 94 107 585 94 132 585 minecraft:black_concrete
fill 100 107 599 100 132 599 minecraft:black_concrete
setblock 108 107 557 minecraft:pearlescent_froglight
fill 109 107 557 110 117 557 minecraft:black_concrete
fill 114 107 599 114 132 599 minecraft:black_concrete
setblock 115 107 599 minecraft:white_stained_glass
fill 136 107 567 136 108 567 minecraft:black_concrete
setblock 136 107 568 minecraft:white_stained_glass
fill 136 107 573 136 108 573 minecraft:white_concrete
setblock 94 108 575 minecraft:pearlescent_froglight
fill 94 108 591 94 110 591 minecraft:black_concrete
setblock 94 108 592 minecraft:white_stained_glass
fill 108 108 557 108 132 557 minecraft:black_concrete
fill 115 108 599 115 132 599 minecraft:black_concrete
fill 136 108 568 136 132 568 minecraft:black_concrete
fill 94 109 565 94 110 565 minecraft:light_gray_concrete
fill 94 109 575 94 121 575 minecraft:black_concrete
fill 94 109 581 94 110 581 minecraft:light_gray_concrete
fill 94 109 592 94 130 592 minecraft:black_concrete
fill 94 109 597 94 110 597 minecraft:light_gray_concrete
fill 98 109 557 98 110 557 minecraft:light_gray_concrete
fill 108 109 599 108 110 599 minecraft:light_gray_concrete
fill 114 109 557 114 110 557 minecraft:light_gray_concrete
fill 124 109 599 124 110 599 minecraft:light_gray_concrete
fill 125 109 589 125 110 589 minecraft:white_stained_glass
fill 130 109 557 130 110 557 minecraft:light_gray_concrete
fill 136 109 567 136 110 567 minecraft:light_gray_concrete
fill 136 109 573 136 130 573 minecraft:black_concrete
fill 136 109 583 136 110 583 minecraft:light_gray_concrete
setblock 103 110 599 minecraft:white_concrete
fill 94 111 565 94 117 565 minecraft:black_concrete
fill 94 111 581 94 117 581 minecraft:black_concrete
setblock 94 111 591 minecraft:pearlescent_froglight
fill 94 111 597 94 117 597 minecraft:black_concrete
setblock 98 111 557 minecraft:black_concrete
fill 98 111 577 100 112 578 minecraft:gray_concrete
fill 103 111 599 103 132 599 minecraft:black_concrete
fill 108 111 599 108 117 599 minecraft:black_concrete
fill 114 111 557 114 117 557 minecraft:black_concrete
fill 124 111 599 124 117 599 minecraft:black_concrete
fill 125 111 589 125 117 589 minecraft:gray_concrete
fill 130 111 557 130 117 557 minecraft:black_concrete
setblock 134 111 557 minecraft:pearlescent_froglight
setblock 136 111 567 minecraft:black_concrete
fill 136 111 583 136 117 583 minecraft:black_concrete
fill 94 112 591 94 132 591 minecraft:black_concrete
setblock 97 112 560 minecraft:light[level=14]
setblock 97 112 568 minecraft:light[level=14]
setblock 97 112 576 minecraft:light[level=14]
setblock 97 112 584 minecraft:light[level=14]
setblock 97 112 592 minecraft:light[level=14]
setblock 98 112 557 minecraft:white_stained_glass
fill 98 112 574 98 113 574 minecraft:light_gray_concrete
setblock 105 112 560 minecraft:light[level=14]
setblock 105 112 568 minecraft:light[level=14]
setblock 105 112 576 minecraft:light[level=14]
setblock 105 112 584 minecraft:light[level=14]
setblock 105 112 592 minecraft:light[level=14]
fill 112 112 566 114 113 566 minecraft:light_gray_concrete
setblock 113 112 560 minecraft:light[level=14]
fill 113 112 565 113 113 565 minecraft:light_gray_concrete
fill 113 112 567 113 113 567 minecraft:light_gray_concrete
setblock 113 112 568 minecraft:light[level=14]
setblock 113 112 576 minecraft:light[level=14]
setblock 113 112 584 minecraft:light[level=14]
setblock 113 112 592 minecraft:light[level=14]
setblock 121 112 560 minecraft:light[level=14]
setblock 121 112 568 minecraft:light[level=14]
setblock 121 112 576 minecraft:light[level=14]
setblock 121 112 584 minecraft:light[level=14]
setblock 121 112 592 minecraft:light[level=14]
fill 125 112 588 125 117 588 minecraft:gray_concrete
setblock 129 112 560 minecraft:light[level=14]
setblock 129 112 568 minecraft:light[level=14]
setblock 129 112 576 minecraft:light[level=14]
setblock 129 112 584 minecraft:light[level=14]
setblock 129 112 592 minecraft:light[level=14]
fill 134 112 557 134 132 557 minecraft:black_concrete
setblock 136 112 567 minecraft:white_stained_glass
setblock 94 113 576 minecraft:pearlescent_froglight
fill 98 113 557 98 117 557 minecraft:black_concrete
fill 124 113 588 124 117 589 minecraft:gray_concrete
fill 136 113 567 136 114 567 minecraft:black_concrete
setblock 136 113 577 minecraft:white_stained_glass
setblock 136 113 594 minecraft:white_concrete
fill 94 114 576 94 130 576 minecraft:black_concrete
setblock 119 114 599 minecraft:white_concrete
fill 124 114 590 125 117 590 minecraft:gray_concrete
fill 125 114 587 125 117 587 minecraft:gray_concrete
fill 126 114 588 126 117 589 minecraft:gray_concrete
setblock 131 114 599 minecraft:white_stained_glass
fill 136 114 577 136 132 577 minecraft:black_concrete
fill 136 114 594 136 128 594 minecraft:black_concrete
setblock 104 115 599 minecraft:pearlescent_froglight
fill 119 115 599 119 132 599 minecraft:black_concrete
fill 123 115 588 123 117 589 minecraft:gray_concrete
fill 124 115 587 124 117 587 minecraft:gray_concrete
fill 126 115 587 126 117 587 minecraft:gray_concrete
fill 126 115 590 126 117 590 minecraft:gray_concrete
fill 131 115 599 131 132 599 minecraft:black_concrete
setblock 136 115 567 minecraft:white_stained_glass
fill 104 116 599 104 132 599 minecraft:black_concrete
fill 106 116 590 106 117 590 minecraft:end_stone
fill 123 116 587 123 117 587 minecraft:gray_concrete
fill 123 116 590 123 117 590 minecraft:gray_concrete
fill 125 116 591 125 117 591 minecraft:gray_concrete
fill 127 116 588 127 117 589 minecraft:gray_concrete
setblock 135 116 557 minecraft:pearlescent_froglight
fill 136 116 567 136 117 567 minecraft:black_concrete
setblock 94 117 563 minecraft:white_concrete
setblock 111 117 557 minecraft:pearlescent_froglight
fill 122 117 588 122 117 589 minecraft:gray_concrete
fill 123 117 591 124 117 591 minecraft:gray_concrete
fill 124 117 586 126 117 586 minecraft:gray_concrete
setblock 126 117 591 minecraft:gray_concrete
setblock 127 117 587 minecraft:gray_concrete
setblock 127 117 590 minecraft:gray_concrete
fill 135 117 557 135 132 557 minecraft:black_concrete
setblock 136 117 570 minecraft:pearlescent_froglight
fill 94 118 563 94 128 563 minecraft:black_concrete
fill 94 118 565 94 119 565 minecraft:light_gray_concrete
setblock 94 118 568 minecraft:white_stained_glass
fill 94 118 581 94 119 581 minecraft:light_gray_concrete
fill 94 118 597 94 119 597 minecraft:light_gray_concrete
fill 98 118 557 98 119 557 minecraft:light_gray_concrete
setblock 99 118 557 minecraft:white_concrete
setblock 101 118 599 minecraft:pearlescent_froglight
fill 108 118 599 108 119 599 minecraft:light_gray_concrete
fill 109 118 557 109 132 557 minecraft:black_concrete
setblock 110 118 557 minecraft:pearlescent_froglight
fill 111 118 557 111 132 557 minecraft:black_concrete
fill 114 118 557 114 119 557 minecraft:light_gray_concrete
fill 123 118 589 123 121 589 minecraft:end_stone
fill 124 118 599 124 119 599 minecraft:light_gray_concrete
fill 125 118 587 125 119 587 minecraft:end_stone
fill 126 118 590 126 120 590 minecraft:end_stone
fill 130 118 557 130 119 557 minecraft:light_gray_concrete
fill 136 118 567 136 119 567 minecraft:light_gray_concrete
fill 136 118 570 136 122 570 minecraft:black_concrete
fill 136 118 583 136 119 583 minecraft:light_gray_concrete
fill 94 119 568 94 130 568 minecraft:black_concrete
fill 99 119 557 99 132 557 minecraft:black_concrete
fill 101 119 599 101 132 599 minecraft:black_concrete
fill 110 119 557 110 132 557 minecraft:black_concrete
setblock 118 119 599 minecraft:white_concrete
setblock 132 119 599 minecraft:pearlescent_froglight
fill 133 119 599 133 130 599 minecraft:black_concrete
setblock 136 119 595 minecraft:pearlescent_froglight
fill 94 120 565 94 126 565 minecraft:black_concrete
fill 94 120 581 94 126 581 minecraft:black_concrete
setblock 94 120 594 minecraft:white_concrete
fill 94 120 597 94 126 597 minecraft:black_concrete
setblock 97 120 560 minecraft:light[level=14]
setblock 97 120 568 minecraft:light[level=14]
setblock 97 120 576 minecraft:light[level=14]
setblock 97 120 584 minecraft:light[level=14]
setblock 97 120 592 minecraft:light[level=14]
setblock 98 120 557 minecraft:white_stained_glass
setblock 105 120 560 minecraft:light[level=14]
setblock 105 120 568 minecraft:light[level=14]
setblock 105 120 576 minecraft:light[level=14]
setblock 105 120 584 minecraft:light[level=14]
setblock 105 120 592 minecraft:light[level=14]
fill 108 120 599 108 126 599 minecraft:black_concrete
setblock 113 120 560 minecraft:light[level=14]
setblock 113 120 568 minecraft:light[level=14]
setblock 113 120 576 minecraft:light[level=14]
setblock 113 120 584 minecraft:light[level=14]
setblock 113 120 592 minecraft:light[level=14]
fill 114 120 557 114 126 557 minecraft:black_concrete
fill 118 120 599 118 132 599 minecraft:black_concrete
setblock 121 120 560 minecraft:light[level=14]
setblock 121 120 568 minecraft:light[level=14]
setblock 121 120 576 minecraft:light[level=14]
setblock 121 120 584 minecraft:light[level=14]
setblock 121 120 592 minecraft:light[level=14]
fill 124 120 599 124 126 599 minecraft:black_concrete
setblock 129 120 560 minecraft:light[level=14]
setblock 129 120 568 minecraft:light[level=14]
setblock 129 120 576 minecraft:light[level=14]
setblock 129 120 584 minecraft:light[level=14]
setblock 129 120 592 minecraft:light[level=14]
fill 130 120 557 130 124 557 minecraft:black_concrete
fill 132 120 599 132 133 599 minecraft:black_concrete
fill 136 120 567 136 126 567 minecraft:black_concrete
fill 136 120 583 136 125 583 minecraft:black_concrete
setblock 136 120 595 minecraft:white_concrete
fill 94 121 594 94 132 594 minecraft:black_concrete
fill 98 121 557 98 126 557 minecraft:black_concrete
fill 102 121 579 102 122 580 minecraft:light_gray_concrete
fill 123 121 581 124 122 583 minecraft:end_stone
fill 136 121 595 136 133 595 minecraft:black_concrete
setblock 94 122 575 minecraft:white_concrete
setblock 97 122 599 minecraft:white_stained_glass
fill 107 122 568 108 123 569 minecraft:light_gray_concrete
setblock 119 122 557 minecraft:white_stained_glass
fill 94 123 575 94 130 575 minecraft:black_concrete
fill 97 123 599 97 130 599 minecraft:black_concrete
fill 119 123 557 119 124 557 minecraft:black_concrete
fill 136 123 557 136 132 557 minecraft:black_concrete
setblock 136 123 558 minecraft:white_concrete
setblock 136 123 570 minecraft:white_concrete
setblock 103 124 557 minecraft:white_concrete
fill 136 124 558 136 132 558 minecraft:black_concrete
fill 136 124 570 136 132 570 minecraft:black_concrete
fill 103 125 557 103 128 557 minecraft:black_concrete
setblock 119 125 557 minecraft:pearlescent_froglight
setblock 130 125 557 minecraft:pearlescent_froglight
setblock 136 125 585 minecraft:white_stained_glass
fill 103 126 581 103 127 581 minecraft:end_stone
fill 119 126 557 119 128 557 minecraft:black_concrete
setblock 130 126 557 minecraft:black_concrete
setblock 136 126 583 minecraft:white_concrete
fill 136 126 585 136 132 585 minecraft:black_concrete
setblock 94 127 565 minecraft:light_gray_concrete
setblock 94 127 581 minecraft:light_gray_concrete
setblock 94 127 597 minecraft:light_gray_concrete
setblock 95 127 557 minecraft:white_stained_glass
setblock 98 127 557 minecraft:light_gray_concrete
setblock 108 127 599 minecraft:light_gray_concrete
fill 113 127 577 113 127 579 minecraft:pearlescent_froglight
setblock 114 127 557 minecraft:light_gray_concrete
fill 114 127 576 114 127 577 minecraft:pearlescent_froglight
fill 114 127 579 114 127 580 minecraft:pearlescent_froglight
fill 115 127 576 116 127 576 minecraft:pearlescent_froglight
fill 115 127 580 116 127 580 minecraft:pearlescent_froglight
fill 116 127 577 117 127 577 minecraft:pearlescent_froglight
fill 116 127 579 117 127 579 minecraft:pearlescent_froglight
setblock 117 127 578 minecraft:pearlescent_froglight
setblock 124 127 599 minecraft:light_gray_concrete
setblock 127 127 599 minecraft:pearlescent_froglight
setblock 130 127 557 minecraft:light_gray_concrete
setblock 136 127 565 minecraft:pearlescent_froglight
setblock 136 127 567 minecraft:light_gray_concrete
setblock 136 127 583 minecraft:light_gray_concrete
setblock 94 128 565 minecraft:black_concrete
fill 94 128 581 94 132 581 minecraft:black_concrete
fill 94 128 597 94 134 597 minecraft:black_concrete
setblock 95 128 557 minecraft:black_concrete
setblock 97 128 560 minecraft:light[level=14]
setblock 97 128 568 minecraft:light[level=14]
setblock 97 128 576 minecraft:light[level=14]
setblock 97 128 584 minecraft:light[level=14]
setblock 97 128 592 minecraft:light[level=14]
fill 98 128 557 98 132 557 minecraft:black_concrete
setblock 105 128 560 minecraft:light[level=14]
setblock 105 128 568 minecraft:light[level=14]
setblock 105 128 576 minecraft:light[level=14]
setblock 105 128 584 minecraft:light[level=14]
setblock 105 128 592 minecraft:light[level=14]
setblock 108 128 599 minecraft:black_concrete
fill 111 128 577 112 128 579 minecraft:pearlescent_froglight
fill 112 128 575 113 128 576 minecraft:pearlescent_froglight
fill 112 128 580 113 128 581 minecraft:pearlescent_froglight
setblock 113 128 560 minecraft:light[level=14]
setblock 113 128 568 minecraft:light[level=14]
fill 113 128 577 113 133 579 minecraft:light_gray_concrete
setblock 113 128 584 minecraft:light[level=14]
setblock 113 128 592 minecraft:light[level=14]
fill 114 128 557 114 132 557 minecraft:black_concrete
fill 114 128 574 116 128 575 minecraft:pearlescent_froglight
fill 114 128 576 114 131 577 minecraft:light_gray_concrete
fill 114 128 579 114 131 580 minecraft:light_gray_concrete
fill 114 128 581 116 128 582 minecraft:pearlescent_froglight
fill 115 128 576 116 133 576 minecraft:light_gray_concrete
fill 115 128 580 116 133 580 minecraft:light_gray_concrete
fill 116 128 577 117 131 577 minecraft:light_gray_concrete
fill 116 128 579 117 131 579 minecraft:light_gray_concrete
fill 117 128 575 118 128 576 minecraft:pearlescent_froglight
fill 117 128 578 117 133 578 minecraft:light_gray_concrete
fill 117 128 580 118 128 581 minecraft:pearlescent_froglight
setblock 117 128 599 minecraft:white_concrete
fill 118 128 577 119 128 579 minecraft:pearlescent_froglight
setblock 121 128 560 minecraft:light[level=14]
setblock 121 128 568 minecraft:light[level=14]
setblock 121 128 576 minecraft:light[level=14]
setblock 121 128 584 minecraft:light[level=14]
setblock 121 128 592 minecraft:light[level=14]
fill 124 128 599 124 132 599 minecraft:black_concrete
setblock 126 128 557 minecraft:white_concrete
fill 127 128 599 127 132 599 minecraft:black_concrete
setblock 129 128 560 minecraft:light[level=14]
setblock 129 128 568 minecraft:light[level=14]
setblock 129 128 576 minecraft:light[level=14]
setblock 129 128 584 minecraft:light[level=14]
setblock 129 128 592 minecraft:light[level=14]
fill 130 128 557 130 129 557 minecraft:black_concrete
setblock 136 128 559 minecraft:white_stained_glass
fill 136 128 565 136 132 565 minecraft:black_concrete
fill 136 128 567 136 132 567 minecraft:black_concrete
fill 136 128 583 136 130 583 minecraft:black_concrete
setblock 94 129 563 minecraft:blue_concrete
fill 94 129 565 94 130 565 minecraft:blue_concrete
setblock 94 129 570 minecraft:blue_concrete
setblock 94 129 573 minecraft:blue_concrete
setblock 94 129 589 minecraft:blue_concrete
fill 94 129 599 95 129 599 minecraft:blue_concrete
setblock 95 129 557 minecraft:blue_concrete
setblock 103 129 557 minecraft:blue_concrete
setblock 108 129 599 minecraft:blue_concrete
fill 110 129 577 110 129 579 minecraft:pearlescent_froglight
fill 111 129 575 111 129 576 minecraft:pearlescent_froglight
fill 111 129 577 112 131 579 minecraft:light_gray_concrete
fill 111 129 580 111 129 581 minecraft:pearlescent_froglight
fill 112 129 574 113 129 574 minecraft:pearlescent_froglight
fill 112 129 575 113 133 576 minecraft:light_gray_concrete
fill 112 129 580 113 133 581 minecraft:light_gray_concrete
fill 112 129 582 113 129 582 minecraft:pearlescent_froglight
fill 114 129 573 116 129 573 minecraft:pearlescent_froglight
fill 114 129 574 116 131 575 minecraft:light_gray_concrete
fill 114 129 581 116 131 582 minecraft:light_gray_concrete
fill 114 129 583 116 129 583 minecraft:pearlescent_froglight
fill 117 129 574 118 129 574 minecraft:pearlescent_froglight
fill 117 129 575 118 133 576 minecraft:light_gray_concrete
fill 117 129 580 118 133 581 minecraft:light_gray_concrete
fill 117 129 582 118 129 582 minecraft:pearlescent_froglight
setblock 117 129 599 minecraft:white_stained_glass
fill 118 129 577 119 131 579 minecraft:light_gray_concrete
setblock 119 129 557 minecraft:blue_concrete
fill 119 129 575 119 129 576 minecraft:pearlescent_froglight
fill 119 129 580 119 129 581 minecraft:pearlescent_froglight
fill 120 129 577 120 129 579 minecraft:pearlescent_froglight
setblock 121 129 557 minecraft:pearlescent_froglight
fill 126 129 557 126 131 557 minecraft:black_concrete
setblock 133 129 557 minecraft:blue_concrete
fill 136 129 559 136 132 559 minecraft:black_concrete
fill 136 129 561 136 129 563 minecraft:blue_concrete
fill 136 129 564 136 130 564 minecraft:black_concrete
setblock 136 129 566 minecraft:blue_concrete
setblock 136 129 571 minecraft:blue_concrete
setblock 136 129 578 minecraft:blue_concrete
setblock 136 129 582 minecraft:blue_concrete
fill 136 129 588 136 129 589 minecraft:blue_concrete
setblock 136 129 594 minecraft:blue_concrete
fill 136 129 599 136 131 599 minecraft:blue_concrete
fill 94 130 563 94 132 563 minecraft:black_concrete
setblock 94 130 564 minecraft:blue_concrete
setblock 94 130 569 minecraft:blue_concrete
fill 94 130 570 94 132 570 minecraft:black_concrete
fill 94 130 573 94 132 573 minecraft:black_concrete
fill 94 130 574 94 131 574 minecraft:blue_concrete
fill 94 130 589 94 132 589 minecraft:black_concrete
setblock 94 130 595 minecraft:blue_concrete
fill 94 130 599 95 132 599 minecraft:black_concrete
fill 95 130 557 95 132 557 minecraft:black_concrete
fill 103 130 557 103 132 557 minecraft:black_concrete
fill 105 130 599 105 132 599 minecraft:black_concrete
fill 106 130 599 107 130 599 minecraft:blue_concrete
setblock 108 130 599 minecraft:black_concrete
fill 109 130 578 109 131 578 minecraft:pearlescent_froglight
fill 110 130 575 110 130 577 minecraft:pearlescent_froglight
fill 110 130 578 110 131 578 minecraft:light_gray_concrete
fill 110 130 579 110 130 581 minecraft:pearlescent_froglight
setblock 111 130 574 minecraft:pearlescent_froglight
fill 111 130 575 111 133 576 minecraft:light_gray_concrete
fill 111 130 580 111 133 581 minecraft:light_gray_concrete
setblock 111 130 582 minecraft:pearlescent_froglight
fill 112 130 573 114 130 573 minecraft:pearlescent_froglight
fill 112 130 574 113 133 574 minecraft:light_gray_concrete
fill 112 130 582 113 133 582 minecraft:light_gray_concrete
fill 112 130 583 114 130 583 minecraft:pearlescent_froglight
setblock 112 130 599 minecraft:blue_concrete
setblock 115 130 557 minecraft:blue_concrete
fill 115 130 572 115 131 572 minecraft:pearlescent_froglight
fill 115 130 573 115 131 573 minecraft:light_gray_concrete
fill 115 130 583 115 131 583 minecraft:light_gray_concrete
fill 115 130 584 115 131 584 minecraft:pearlescent_froglight
fill 116 130 557 116 132 557 minecraft:black_concrete
fill 116 130 573 118 130 573 minecraft:pearlescent_froglight
fill 116 130 583 118 130 583 minecraft:pearlescent_froglight
setblock 117 130 557 minecraft:blue_concrete
fill 117 130 574 118 133 574 minecraft:light_gray_concrete
fill 117 130 582 118 133 582 minecraft:light_gray_concrete
fill 117 130 599 117 132 599 minecraft:black_concrete
fill 119 130 557 119 131 557 minecraft:black_concrete
setblock 119 130 574 minecraft:pearlescent_froglight
fill 119 130 575 119 133 576 minecraft:light_gray_concrete
fill 119 130 580 119 133 581 minecraft:light_gray_concrete
setblock 119 130 582 minecraft:pearlescent_froglight
fill 120 130 575 120 130 577 minecraft:pearlescent_froglight
fill 120 130 578 120 131 578 minecraft:light_gray_concrete
fill 120 130 579 120 130 581 minecraft:pearlescent_froglight
fill 121 130 557 121 132 557 minecraft:black_concrete
fill 121 130 578 121 131 578 minecraft:pearlescent_froglight
fill 127 130 557 127 131 557 minecraft:blue_concrete
fill 128 130 557 128 133 557 minecraft:black_concrete
setblock 130 130 557 minecraft:blue_concrete
setblock 130 130 599 minecraft:blue_concrete
fill 133 130 557 133 132 557 minecraft:black_concrete
fill 136 130 561 136 132 563 minecraft:black_concrete
fill 136 130 566 136 132 566 minecraft:black_concrete
fill 136 130 571 136 132 571 minecraft:black_concrete
fill 136 130 578 136 133 578 minecraft:black_concrete
setblock 136 130 582 minecraft:black_concrete
fill 136 130 588 136 130 589 minecraft:black_concrete
fill 136 130 594 136 132 594 minecraft:black_concrete
fill 136 130 596 136 130 597 minecraft:blue_concrete
fill 94 131 564 94 132 565 minecraft:black_concrete
setblock 94 131 567 minecraft:blue_concrete
setblock 94 131 568 minecraft:pearlescent_froglight
fill 94 131 569 94 132 569 minecraft:black_concrete
setblock 94 131 572 minecraft:blue_concrete
fill 94 131 575 94 131 576 minecraft:blue_concrete
setblock 94 131 583 minecraft:white_concrete
fill 94 131 584 94 132 584 minecraft:black_concrete
setblock 94 131 592 minecraft:blue_concrete
fill 94 131 595 94 134 595 minecraft:black_concrete
setblock 96 131 599 minecraft:white_stained_glass
setblock 97 131 557 minecraft:blue_concrete
setblock 97 131 599 minecraft:blue_concrete
setblock 99 131 599 minecraft:blue_concrete
setblock 102 131 599 minecraft:white_concrete
fill 106 131 599 106 132 599 minecraft:black_concrete
fill 107 131 599 109 131 599 minecraft:blue_concrete
fill 109 131 576 109 131 577 minecraft:pearlescent_froglight
fill 109 131 579 109 131 580 minecraft:pearlescent_froglight
fill 110 131 574 110 131 575 minecraft:pearlescent_froglight
fill 110 131 576 110 131 577 minecraft:light_gray_concrete
fill 110 131 579 110 131 580 minecraft:light_gray_concrete
fill 110 131 581 110 131 582 minecraft:pearlescent_froglight
fill 111 131 573 112 131 573 minecraft:pearlescent_froglight
fill 111 131 574 111 134 574 minecraft:light_gray_concrete
fill 111 131 582 111 134 582 minecraft:light_gray_concrete
fill 111 131 583 112 131 583 minecraft:pearlescent_froglight
fill 112 131 599 112 132 599 minecraft:black_concrete
setblock 113 131 557 minecraft:blue_concrete
fill 113 131 572 114 131 572 minecraft:pearlescent_froglight
fill 113 131 573 114 131 573 minecraft:light_gray_concrete
fill 113 131 583 114 131 583 minecraft:light_gray_concrete
fill 113 131 584 114 131 584 minecraft:pearlescent_froglight
fill 115 131 557 115 132 557 minecraft:black_concrete
fill 116 131 572 117 131 572 minecraft:pearlescent_froglight
fill 116 131 573 117 131 573 minecraft:light_gray_concrete
fill 116 131 583 117 131 583 minecraft:light_gray_concrete
fill 116 131 584 117 131 584 minecraft:pearlescent_froglight
fill 117 131 557 117 132 557 minecraft:black_concrete
fill 118 131 573 119 131 573 minecraft:pearlescent_froglight
fill 118 131 583 119 131 583 minecraft:pearlescent_froglight
fill 119 131 574 119 134 574 minecraft:light_gray_concrete
fill 119 131 582 119 134 582 minecraft:light_gray_concrete
fill 120 131 574 120 131 575 minecraft:pearlescent_froglight
fill 120 131 576 120 131 577 minecraft:light_gray_concrete
fill 120 131 579 120 131 580 minecraft:light_gray_concrete
fill 120 131 581 120 131 582 minecraft:pearlescent_froglight
fill 121 131 576 121 131 577 minecraft:pearlescent_froglight
fill 121 131 579 121 131 580 minecraft:pearlescent_froglight
fill 130 131 557 130 132 557 minecraft:black_concrete
fill 130 131 599 130 132 599 minecraft:black_concrete
setblock 131 131 557 minecraft:blue_concrete
setblock 133 131 599 minecraft:blue_concrete
setblock 136 131 564 minecraft:blue_concrete
setblock 136 131 573 minecraft:blue_concrete
fill 136 131 582 136 131 583 minecraft:blue_concrete
setblock 136 131 586 minecraft:white_stained_glass
fill 136 131 588 136 132 588 minecraft:black_concrete
setblock 136 131 589 minecraft:blue_concrete
fill 136 131 596 136 132 597 minecraft:black_concrete
fill 94 132 567 94 132 568 minecraft:black_concrete
setblock 94 132 572 minecraft:black_concrete
fill 94 132 574 94 132 576 minecraft:black_concrete
setblock 94 132 582 minecraft:pearlescent_froglight
setblock 94 132 583 minecraft:black_concrete
setblock 94 132 592 minecraft:black_concrete
fill 96 132 599 97 132 599 minecraft:black_concrete
setblock 97 132 557 minecraft:black_concrete
setblock 99 132 599 minecraft:black_concrete
setblock 102 132 599 minecraft:black_concrete
fill 107 132 599 109 132 599 minecraft:black_concrete
fill 109 132 575 109 134 576 minecraft:pearlescent_froglight
fill 109 132 577 111 132 579 minecraft:redstone_block
fill 109 132 580 109 134 581 minecraft:pearlescent_froglight
fill 110 132 574 110 134 574 minecraft:pearlescent_froglight
fill 110 132 575 110 133 576 minecraft:light_gray_concrete
fill 110 132 580 110 133 581 minecraft:light_gray_concrete
fill 110 132 582 110 134 582 minecraft:pearlescent_froglight
fill 111 132 573 111 134 573 minecraft:pearlescent_froglight
fill 111 132 583 111 134 583 minecraft:pearlescent_froglight
fill 112 132 572 113 134 572 minecraft:pearlescent_froglight
fill 112 132 573 113 133 573 minecraft:light_gray_concrete
fill 112 132 577 112 133 579 minecraft:light_gray_concrete
fill 112 132 583 113 133 583 minecraft:light_gray_concrete
fill 112 132 584 113 134 584 minecraft:pearlescent_froglight
setblock 113 132 557 minecraft:black_concrete
fill 114 132 572 116 132 574 minecraft:redstone_block
fill 114 132 575 114 133 576 minecraft:light_gray_concrete
fill 114 132 580 114 133 581 minecraft:light_gray_concrete
fill 114 132 582 116 132 584 minecraft:redstone_block
fill 115 132 575 116 133 575 minecraft:light_gray_concrete
fill 115 132 581 116 133 581 minecraft:light_gray_concrete
fill 117 132 572 118 135 572 minecraft:pearlescent_froglight
fill 117 132 573 118 133 573 minecraft:light_gray_concrete
fill 117 132 577 118 133 577 minecraft:light_gray_concrete
fill 117 132 579 118 133 579 minecraft:light_gray_concrete
fill 117 132 583 118 133 583 minecraft:light_gray_concrete
fill 117 132 584 118 135 584 minecraft:pearlescent_froglight
fill 118 132 578 118 133 578 minecraft:light_gray_concrete
setblock 119 132 557 minecraft:white_concrete
fill 119 132 573 119 134 573 minecraft:pearlescent_froglight
fill 119 132 577 121 132 579 minecraft:redstone_block
fill 119 132 583 119 134 583 minecraft:pearlescent_froglight
fill 120 132 574 120 134 574 minecraft:pearlescent_froglight
fill 120 132 575 120 133 576 minecraft:light_gray_concrete
fill 120 132 580 120 133 581 minecraft:light_gray_concrete
fill 120 132 582 120 134 582 minecraft:pearlescent_froglight
fill 121 132 575 121 134 576 minecraft:pearlescent_froglight
fill 121 132 580 121 134 581 minecraft:pearlescent_froglight
setblock 126 132 557 minecraft:white_stained_glass
setblock 127 132 557 minecraft:pearlescent_froglight
setblock 131 132 557 minecraft:black_concrete
fill 133 132 599 133 133 599 minecraft:black_concrete
setblock 135 132 599 minecraft:white_stained_glass
setblock 136 132 564 minecraft:black_concrete
setblock 136 132 573 minecraft:black_concrete
fill 136 132 582 136 132 583 minecraft:black_concrete
setblock 136 132 586 minecraft:black_concrete
setblock 136 132 589 minecraft:black_concrete
setblock 136 132 599 minecraft:black_concrete
fill 94 133 557 94 133 574 minecraft:blue_concrete
setblock 94 133 575 minecraft:black_concrete
fill 94 133 576 94 134 577 minecraft:blue_concrete
fill 94 133 579 94 133 587 minecraft:blue_concrete
fill 94 133 589 94 149 594 minecraft:blue_concrete
fill 94 133 596 94 146 596 minecraft:blue_concrete
fill 94 133 598 94 134 599 minecraft:blue_concrete
fill 95 133 557 105 133 557 minecraft:blue_concrete
fill 95 133 599 108 134 599 minecraft:blue_concrete
fill 107 133 557 108 150 557 minecraft:blue_concrete
setblock 109 133 557 minecraft:white_concrete
setblock 109 133 599 minecraft:black_concrete
fill 110 133 557 119 133 557 minecraft:blue_concrete
fill 110 133 599 112 134 599 minecraft:blue_concrete
fill 114 133 599 124 133 599 minecraft:blue_concrete
fill 121 133 557 127 145 557 minecraft:blue_concrete
setblock 125 133 599 minecraft:black_concrete
fill 126 133 599 131 133 599 minecraft:blue_concrete
fill 129 133 557 136 133 557 minecraft:blue_concrete
fill 134 133 599 134 139 599 minecraft:blue_concrete
setblock 135 133 599 minecraft:black_concrete
fill 136 133 558 136 133 577 minecraft:blue_concrete
fill 136 133 580 136 133 594 minecraft:blue_concrete
fill 136 133 596 136 145 599 minecraft:blue_concrete
fill 94 134 557 94 134 561 minecraft:blue_concrete
setblock 94 134 562 minecraft:white_stained_glass
fill 94 134 563 94 134 573 minecraft:blue_concrete
fill 94 134 574 109 134 574 minecraft:black_concrete
fill 94 134 575 94 216 575 minecraft:blue_concrete
fill 94 134 578 94 134 583 minecraft:blue_concrete
fill 94 134 584 111 134 584 minecraft:black_concrete
fill 94 134 585 94 134 588 minecraft:blue_concrete
fill 95 134 557 99 134 557 minecraft:blue_concrete
fill 95 134 558 110 134 573 minecraft:black_concrete
fill 95 134 575 107 134 583 minecraft:black_concrete
fill 95 134 585 112 134 598 minecraft:black_concrete
fill 100 134 557 101 134 557 minecraft:black_concrete
fill 102 134 557 106 134 557 minecraft:blue_concrete
setblock 108 134 575 minecraft:black_concrete
fill 108 134 576 108 134 580 minecraft:pearlescent_froglight
fill 108 134 581 108 134 583 minecraft:black_concrete
fill 109 134 557 110 143 557 minecraft:blue_concrete
fill 109 134 577 111 134 579 minecraft:black_concrete
fill 109 134 582 109 134 583 minecraft:black_concrete
fill 109 134 599 109 216 599 minecraft:blue_concrete
fill 110 134 575 112 134 575 minecraft:light_gray_concrete
fill 110 134 576 113 134 576 minecraft:pearlescent_froglight
fill 110 134 580 113 134 580 minecraft:pearlescent_froglight
fill 110 134 581 112 134 581 minecraft:light_gray_concrete
setblock 110 134 583 minecraft:black_concrete
fill 111 134 557 111 134 572 minecraft:black_concrete
fill 112 134 557 119 134 557 minecraft:blue_concrete
fill 112 134 558 112 134 571 minecraft:black_concrete
fill 112 134 573 112 134 574 minecraft:light_gray_concrete
fill 112 134 577 112 134 579 minecraft:pearlescent_froglight
fill 112 134 582 112 134 583 minecraft:light_gray_concrete
fill 113 134 558 135 134 570 minecraft:black_concrete
fill 113 134 571 117 134 571 minecraft:pearlescent_froglight
fill 113 134 573 113 134 575 minecraft:pearlescent_froglight
fill 113 134 577 113 134 579 minecraft:ochre_froglight
fill 113 134 581 113 134 583 minecraft:pearlescent_froglight
fill 113 134 585 117 134 585 minecraft:pearlescent_froglight
fill 113 134 586 135 134 598 minecraft:black_concrete
fill 114 134 572 116 134 574 minecraft:black_concrete
fill 114 134 575 117 134 575 minecraft:pearlescent_froglight
fill 114 134 576 116 134 576 minecraft:ochre_froglight
fill 114 134 580 116 134 580 minecraft:ochre_froglight
fill 114 134 581 117 134 581 minecraft:pearlescent_froglight
fill 114 134 582 116 134 584 minecraft:black_concrete
fill 114 134 599 116 179 599 minecraft:blue_concrete
fill 117 134 573 117 134 574 minecraft:pearlescent_froglight
fill 117 134 576 120 134 576 minecraft:pearlescent_froglight
fill 117 134 577 117 134 579 minecraft:ochre_froglight
fill 117 134 580 120 134 580 minecraft:pearlescent_froglight
fill 117 134 582 117 134 583 minecraft:pearlescent_froglight
setblock 117 134 599 minecraft:black_concrete
fill 118 134 571 135 134 571 minecraft:black_concrete
fill 118 134 573 118 135 575 minecraft:light_gray_concrete
fill 118 134 577 118 134 579 minecraft:pearlescent_froglight
fill 118 134 581 118 135 583 minecraft:light_gray_concrete
fill 118 134 585 135 134 585 minecraft:black_concrete
fill 118 134 599 120 137 599 minecraft:blue_concrete
fill 119 134 572 135 134 572 minecraft:black_concrete
fill 119 134 575 120 134 575 minecraft:light_gray_concrete
fill 119 134 577 121 134 579 minecraft:black_concrete
fill 119 134 581 120 134 581 minecraft:light_gray_concrete
fill 119 134 584 135 134 584 minecraft:black_concrete
fill 120 134 573 136 134 573 minecraft:black_concrete
fill 120 134 583 135 134 583 minecraft:black_concrete
fill 121 134 574 135 134 574 minecraft:black_concrete
fill 121 134 582 135 134 582 minecraft:black_concrete
setblock 121 134 599 minecraft:black_concrete
fill 122 134 575 135 134 575 minecraft:black_concrete
fill 122 134 576 122 134 580 minecraft:pearlescent_froglight
fill 122 134 581 135 134 581 minecraft:black_concrete
fill 122 134 599 128 138 599 minecraft:blue_concrete
fill 123 134 576 135 134 580 minecraft:black_concrete
fill 128 134 557 129 209 557 minecraft:blue_concrete
fill 129 134 599 131 134 599 minecraft:black_concrete
setblock 130 134 557 minecraft:black_concrete
fill 131 134 557 136 146 557 minecraft:blue_concrete
fill 132 134 599 133 134 599 minecraft:blue_concrete
fill 135 134 599 135 184 599 minecraft:blue_concrete
fill 136 134 558 136 134 569 minecraft:blue_concrete
setblock 136 134 570 minecraft:black_concrete
fill 136 134 571 136 148 572 minecraft:blue_concrete
fill 136 134 574 136 144 577 minecraft:blue_concrete
setblock 136 134 578 minecraft:white_concrete
fill 136 134 579 136 134 593 minecraft:blue_concrete
setblock 136 134 594 minecraft:black_concrete
fill 136 134 595 136 140 595 minecraft:blue_concrete
fill 94 135 557 96 216 557 minecraft:blue_concrete
setblock 94 135 558 minecraft:black_concrete
fill 94 135 559 94 139 566 minecraft:blue_concrete
setblock 94 135 567 minecraft:black_concrete
fill 94 135 568 94 135 574 minecraft:blue_concrete
setblock 94 135 576 minecraft:black_concrete
fill 94 135 577 94 216 579 minecraft:blue_concrete
setblock 94 135 580 minecraft:black_concrete
fill 94 135 581 94 144 586 minecraft:blue_concrete
setblock 94 135 587 minecraft:black_concrete
fill 94 135 588 94 159 588 minecraft:blue_concrete
fill 94 135 595 94 220 595 minecraft:blue_concrete
fill 94 135 597 94 137 597 minecraft:blue_concrete
setblock 94 135 598 minecraft:black_concrete
fill 94 135 599 101 138 599 minecraft:blue_concrete
setblock 97 135 557 minecraft:black_concrete
fill 98 135 557 102 139 557 minecraft:blue_concrete
fill 102 135 569 111 143 587 minecraft:smooth_stone
setblock 102 135 599 minecraft:black_concrete
setblock 103 135 557 minecraft:black_concrete
fill 103 135 599 106 142 599 minecraft:blue_concrete
fill 104 135 557 106 165 557 minecraft:blue_concrete
setblock 107 135 599 minecraft:black_concrete
fill 108 135 599 108 144 599 minecraft:blue_concrete
fill 110 135 599 111 140 599 minecraft:blue_concrete
fill 111 135 557 115 144 557 minecraft:blue_concrete
fill 112 135 569 112 143 587 minecraft:oak_planks
setblock 112 135 599 minecraft:pearlescent_froglight
fill 113 135 572 116 136 572 minecraft:pearlescent_froglight
fill 113 135 573 113 136 583 minecraft:light_gray_concrete
fill 113 135 584 116 136 584 minecraft:pearlescent_froglight
fill 114 135 573 117 136 576 minecraft:light_gray_concrete
fill 114 135 580 117 136 583 minecraft:light_gray_concrete
setblock 116 135 557 minecraft:black_concrete
fill 117 135 557 120 146 557 minecraft:blue_concrete
fill 117 135 577 118 138 579 minecraft:light_gray_concrete
fill 117 135 599 117 176 599 minecraft:blue_concrete
fill 118 135 576 118 138 576 minecraft:light_gray_concrete
fill 118 135 580 118 138 580 minecraft:light_gray_concrete
fill 119 135 569 119 143 587 minecraft:oak_planks
fill 120 135 569 128 143 587 minecraft:smooth_stone
fill 121 135 599 121 221 599 minecraft:blue_concrete
setblock 129 135 599 minecraft:pearlescent_froglight
fill 130 135 557 130 144 557 minecraft:blue_concrete
fill 130 135 599 132 140 599 minecraft:blue_concrete
setblock 133 135 599 minecraft:black_concrete
setblock 136 135 558 minecraft:black_concrete
fill 136 135 559 136 149 561 minecraft:blue_concrete
setblock 136 135 562 minecraft:black_concrete
fill 136 135 563 136 179 563 minecraft:blue_concrete
setblock 136 135 564 minecraft:black_concrete
fill 136 135 565 136 143 570 minecraft:blue_concrete
fill 136 135 573 136 202 573 minecraft:blue_concrete
fill 136 135 578 136 176 578 minecraft:blue_concrete
setblock 136 135 579 minecraft:black_concrete
fill 136 135 580 136 191 580 minecraft:blue_concrete
setblock 136 135 581 minecraft:black_concrete
fill 136 135 582 136 144 587 minecraft:blue_concrete
setblock 136 135 588 minecraft:black_concrete
fill 136 135 589 136 145 594 minecraft:blue_concrete
fill 94 136 558 94 147 558 minecraft:blue_concrete
fill 94 136 567 94 166 567 minecraft:blue_concrete
setblock 94 136 568 minecraft:white_concrete
fill 94 136 569 94 144 574 minecraft:blue_concrete
fill 94 136 576 94 143 576 minecraft:blue_concrete
fill 94 136 580 94 151 580 minecraft:blue_concrete
fill 94 136 587 94 220 587 minecraft:blue_concrete
fill 94 136 598 94 192 598 minecraft:blue_concrete
fill 97 136 557 97 162 557 minecraft:blue_concrete
setblock 97 136 560 minecraft:light[level=14]
setblock 97 136 568 minecraft:light[level=14]
setblock 97 136 576 minecraft:light[level=14]
setblock 97 136 584 minecraft:light[level=14]
setblock 97 136 592 minecraft:light[level=14]
fill 102 136 599 102 187 599 minecraft:blue_concrete
fill 103 136 557 103 218 557 minecraft:blue_concrete
setblock 105 136 560 minecraft:light[level=14]
setblock 105 136 568 minecraft:light[level=14]
setblock 105 136 592 minecraft:light[level=14]
fill 107 136 599 107 220 599 minecraft:blue_concrete
fill 112 136 599 113 141 599 minecraft:blue_concrete
setblock 113 136 560 minecraft:light[level=14]
setblock 113 136 568 minecraft:light[level=14]
setblock 113 136 592 minecraft:light[level=14]
setblock 116 136 557 minecraft:blue_concrete
setblock 117 136 572 minecraft:pearlescent_froglight
setblock 117 136 584 minecraft:pearlescent_froglight
fill 118 136 573 118 137 573 minecraft:pearlescent_froglight
fill 118 136 574 118 137 575 minecraft:light_gray_concrete
fill 118 136 581 118 137 582 minecraft:light_gray_concrete
fill 118 136 583 118 137 583 minecraft:pearlescent_froglight
setblock 121 136 560 minecraft:light[level=14]
setblock 121 136 568 minecraft:light[level=14]
setblock 121 136 592 minecraft:light[level=14]
setblock 129 136 560 minecraft:light[level=14]
setblock 129 136 568 minecraft:light[level=14]
setblock 129 136 576 minecraft:light[level=14]
setblock 129 136 584 minecraft:light[level=14]
setblock 129 136 592 minecraft:light[level=14]
fill 129 136 599 129 148 599 minecraft:blue_concrete
fill 133 136 599 133 179 599 minecraft:blue_concrete
fill 136 136 558 136 147 558 minecraft:blue_concrete
fill 136 136 562 136 216 562 minecraft:blue_concrete
fill 136 136 564 136 161 564 minecraft:blue_concrete
fill 136 136 579 136 203 579 minecraft:blue_concrete
fill 136 136 581 136 201 581 minecraft:blue_concrete
fill 136 136 588 136 142 588 minecraft:blue_concrete
fill 94 137 568 94 168 568 minecraft:blue_concrete
fill 113 137 573 114 137 573 minecraft:pearlescent_froglight
fill 113 137 574 113 137 582 minecraft:light_gray_concrete
fill 113 137 583 114 137 583 minecraft:pearlescent_froglight
fill 114 137 574 114 138 577 minecraft:light_gray_concrete
fill 114 137 579 114 138 582 minecraft:light_gray_concrete
setblock 115 137 572 minecraft:pearlescent_froglight
fill 115 137 573 115 137 576 minecraft:light_gray_concrete
fill 115 137 580 115 137 583 minecraft:light_gray_concrete
setblock 115 137 584 minecraft:pearlescent_froglight
setblock 116 137 557 minecraft:white_concrete
fill 116 137 573 117 137 573 minecraft:pearlescent_froglight
fill 116 137 574 116 138 577 minecraft:light_gray_concrete
fill 116 137 579 116 138 582 minecraft:light_gray_concrete
fill 116 137 583 117 137 583 minecraft:pearlescent_froglight
fill 117 137 574 117 137 576 minecraft:light_gray_concrete
fill 117 137 580 117 137 582 minecraft:light_gray_concrete
setblock 94 138 597 minecraft:pearlescent_froglight
setblock 113 138 574 minecraft:pearlescent_froglight
fill 113 138 575 113 138 581 minecraft:light_gray_concrete
setblock 113 138 582 minecraft:pearlescent_froglight
fill 114 138 573 116 138 573 minecraft:pearlescent_froglight
fill 114 138 583 116 138 583 minecraft:pearlescent_froglight
fill 115 138 574 115 138 576 minecraft:light_gray_concrete
fill 115 138 580 115 138 582 minecraft:light_gray_concrete
fill 116 138 557 116 186 557 minecraft:blue_concrete
fill 117 138 574 118 138 574 minecraft:pearlescent_froglight
fill 117 138 575 117 138 576 minecraft:light_gray_concrete
fill 117 138 580 117 138 581 minecraft:light_gray_concrete
fill 117 138 582 118 138 582 minecraft:pearlescent_froglight
setblock 118 138 575 minecraft:light_gray_concrete
setblock 118 138 581 minecraft:light_gray_concrete
setblock 118 138 599 minecraft:white_concrete
fill 119 138 599 120 140 599 minecraft:blue_concrete
fill 94 139 597 94 144 597 minecraft:blue_concrete
fill 94 139 599 94 216 599 minecraft:blue_concrete
setblock 95 139 599 minecraft:pearlescent_froglight
fill 96 139 599 101 142 599 minecraft:blue_concrete
fill 113 139 575 113 139 576 minecraft:pearlescent_froglight
fill 113 139 577 113 139 579 minecraft:light_gray_concrete
fill 113 139 580 113 139 581 minecraft:pearlescent_froglight
fill 114 139 574 116 139 575 minecraft:pearlescent_froglight
fill 114 139 576 114 139 577 minecraft:light_gray_concrete
fill 114 139 579 114 139 580 minecraft:light_gray_concrete
fill 114 139 581 116 139 582 minecraft:pearlescent_froglight
fill 115 139 576 116 139 576 minecraft:light_gray_concrete
fill 115 139 580 116 139 580 minecraft:light_gray_concrete
fill 116 139 577 117 139 577 minecraft:light_gray_concrete
fill 116 139 579 117 139 579 minecraft:light_gray_concrete
fill 117 139 575 118 139 576 minecraft:pearlescent_froglight
setblock 117 139 578 minecraft:light_gray_concrete
fill 117 139 580 118 139 581 minecraft:pearlescent_froglight
fill 118 139 577 118 139 579 minecraft:pearlescent_froglight
fill 118 139 599 118 218 599 minecraft:blue_concrete
fill 122 139 599 127 140 599 minecraft:blue_concrete
setblock 128 139 599 minecraft:pearlescent_froglight
fill 94 140 559 94 144 565 minecraft:blue_concrete
setblock 94 140 566 minecraft:pearlescent_froglight
fill 95 140 599 95 162 599 minecraft:blue_concrete
setblock 98 140 557 minecraft:pearlescent_froglight
fill 99 140 557 102 181 557 minecraft:blue_concrete
fill 113 140 577 113 140 579 minecraft:pearlescent_froglight
fill 114 140 576 114 140 577 minecraft:pearlescent_froglight
fill 114 140 579 114 140 580 minecraft:pearlescent_froglight
fill 115 140 576 116 140 576 minecraft:pearlescent_froglight
fill 115 140 580 116 140 580 minecraft:pearlescent_froglight
fill 116 140 577 117 140 577 minecraft:pearlescent_froglight
fill 116 140 579 117 140 579 minecraft:pearlescent_froglight
setblock 117 140 578 minecraft:pearlescent_froglight
fill 128 140 599 128 177 599 minecraft:blue_concrete
setblock 134 140 599 minecraft:white_concrete
fill 94 141 566 94 171 566 minecraft:blue_concrete
fill 98 141 557 98 144 557 minecraft:blue_concrete
setblock 110 141 599 minecraft:white_stained_glass
fill 111 141 599 111 149 599 minecraft:blue_concrete
setblock 119 141 599 minecraft:pearlescent_froglight
fill 120 141 599 120 163 599 minecraft:blue_concrete
fill 122 141 599 124 144 599 minecraft:blue_concrete
setblock 125 141 599 minecraft:white_concrete
fill 126 141 599 127 187 599 minecraft:blue_concrete
setblock 130 141 599 minecraft:white_concrete
fill 131 141 599 132 177 599 minecraft:blue_concrete
fill 134 141 599 134 218 599 minecraft:blue_concrete
setblock 136 141 595 minecraft:white_concrete
fill 110 142 599 110 149 599 minecraft:blue_concrete
fill 112 142 599 112 215 599 minecraft:blue_concrete
setblock 113 142 599 minecraft:white_stained_glass
fill 119 142 599 119 173 599 minecraft:blue_concrete
fill 125 142 599 125 189 599 minecraft:blue_concrete
fill 130 142 599 130 164 599 minecraft:blue_concrete
fill 136 142 595 136 180 595 minecraft:blue_concrete
setblock 96 143 599 minecraft:white_stained_glass
fill 97 143 599 101 163 599 minecraft:blue_concrete
fill 103 143 599 104 169 599 minecraft:blue_concrete
setblock 105 143 599 minecraft:white_concrete
fill 106 143 599 106 220 599 minecraft:blue_concrete
fill 113 143 599 113 161 599 minecraft:blue_concrete
setblock 136 143 588 minecraft:pearlescent_froglight
setblock 94 144 576 minecraft:pearlescent_froglight
fill 96 144 599 96 220 599 minecraft:blue_concrete
setblock 97 144 560 minecraft:light[level=14]
setblock 97 144 568 minecraft:light[level=14]
setblock 97 144 576 minecraft:light[level=14]
setblock 97 144 584 minecraft:light[level=14]
setblock 97 144 592 minecraft:light[level=14]
setblock 105 144 560 minecraft:light[level=14]
setblock 105 144 568 minecraft:light[level=14]
setblock 105 144 576 minecraft:light[level=14]
setblock 105 144 584 minecraft:light[level=14]
setblock 105 144 592 minecraft:light[level=14]
fill 105 144 599 105 152 599 minecraft:blue_concrete
fill 107 144 569 109 147 570 minecraft:gray_concrete
fill 108 144 568 108 147 568 minecraft:gray_concrete
setblock 109 144 557 minecraft:white_concrete
fill 110 144 557 110 145 557 minecraft:blue_concrete
setblock 113 144 560 minecraft:light[level=14]
setblock 113 144 568 minecraft:light[level=14]
setblock 113 144 576 minecraft:light[level=14]
setblock 113 144 584 minecraft:light[level=14]
setblock 113 144 592 minecraft:light[level=14]
setblock 121 144 560 minecraft:light[level=14]
setblock 121 144 568 minecraft:light[level=14]
setblock 121 144 576 minecraft:light[level=14]
setblock 121 144 584 minecraft:light[level=14]
setblock 121 144 592 minecraft:light[level=14]
fill 128 144 587 129 145 587 minecraft:light_gray_concrete
setblock 129 144 560 minecraft:light[level=14]
setblock 129 144 568 minecraft:light[level=14]
setblock 129 144 576 minecraft:light[level=14]
setblock 129 144 584 minecraft:light[level=14]
setblock 129 144 592 minecraft:light[level=14]
setblock 136 144 565 minecraft:white_stained_glass
fill 136 144 566 136 144 570 minecraft:blue_concrete
fill 136 144 588 136 217 588 minecraft:blue_concrete
fill 94 145 559 94 177 562 minecraft:blue_concrete
setblock 94 145 563 minecraft:white_stained_glass
fill 94 145 564 94 220 564 minecraft:blue_concrete
fill 94 145 565 94 146 565 minecraft:light_gray_concrete
fill 94 145 569 94 158 572 minecraft:blue_concrete
setblock 94 145 573 minecraft:white_concrete
fill 94 145 574 94 157 574 minecraft:blue_concrete
fill 94 145 576 94 178 576 minecraft:blue_concrete
fill 94 145 581 94 146 581 minecraft:light_gray_concrete
fill 94 145 582 94 149 584 minecraft:blue_concrete
setblock 94 145 585 minecraft:white_stained_glass
fill 94 145 586 94 152 586 minecraft:blue_concrete
fill 94 145 597 94 146 597 minecraft:light_gray_concrete
fill 98 145 557 98 146 557 minecraft:light_gray_concrete
fill 107 145 568 107 147 568 minecraft:gray_concrete
fill 108 145 571 108 147 571 minecraft:gray_concrete
fill 108 145 599 108 146 599 minecraft:light_gray_concrete
fill 109 145 557 109 164 557 minecraft:blue_concrete
fill 109 145 568 109 147 568 minecraft:gray_concrete
fill 111 145 557 113 161 557 minecraft:blue_concrete
fill 114 145 557 114 146 557 minecraft:light_gray_concrete
fill 115 145 557 115 193 557 minecraft:blue_concrete
fill 122 145 599 123 154 599 minecraft:blue_concrete
fill 124 145 599 124 146 599 minecraft:light_gray_concrete
fill 130 145 557 130 146 557 minecraft:light_gray_concrete
fill 136 145 565 136 146 566 minecraft:blue_concrete
fill 136 145 567 136 146 567 minecraft:light_gray_concrete
fill 136 145 568 136 151 570 minecraft:blue_concrete
fill 136 145 574 136 159 574 minecraft:blue_concrete
setblock 136 145 575 minecraft:white_concrete
fill 136 145 576 136 148 577 minecraft:blue_concrete
fill 136 145 582 136 175 582 minecraft:blue_concrete
fill 136 145 583 136 146 583 minecraft:light_gray_concrete
fill 136 145 584 136 147 587 minecraft:blue_concrete
fill 94 146 563 94 217 563 minecraft:blue_concrete
fill 94 146 573 94 206 573 minecraft:blue_concrete
fill 94 146 585 94 152 585 minecraft:blue_concrete
fill 102 146 576 114 147 577 minecraft:iron_block
fill 106 146 569 106 147 570 minecraft:gray_concrete
fill 106 146 593 108 147 593 minecraft:end_stone
fill 107 146 571 107 147 571 minecraft:gray_concrete
fill 107 146 592 107 147 592 minecraft:end_stone
fill 107 146 594 107 147 594 minecraft:end_stone
fill 108 146 567 108 147 567 minecraft:gray_concrete
fill 109 146 571 109 147 571 minecraft:gray_concrete
setblock 110 146 557 minecraft:pearlescent_froglight
fill 110 146 569 110 147 570 minecraft:gray_concrete
fill 115 146 576 128 147 576 minecraft:iron_block
fill 116 146 577 128 147 577 minecraft:iron_block
fill 121 146 557 125 146 557 minecraft:blue_concrete
setblock 126 146 557 minecraft:pearlescent_froglight
fill 127 146 557 127 220 557 minecraft:blue_concrete
fill 136 146 575 136 151 575 minecraft:blue_concrete
fill 136 146 589 136 167 590 minecraft:blue_concrete
setblock 136 146 591 minecraft:white_stained_glass
fill 136 146 592 136 152 594 minecraft:blue_concrete
fill 136 146 596 136 217 596 minecraft:blue_concrete
setblock 136 146 597 minecraft:white_stained_glass
fill 136 146 598 136 177 599 minecraft:blue_concrete
fill 94 147 565 94 153 565 minecraft:blue_concrete
fill 94 147 581 94 148 581 minecraft:blue_concrete
setblock 94 147 596 minecraft:white_concrete
fill 94 147 597 94 153 597 minecraft:blue_concrete
fill 98 147 557 98 153 557 minecraft:blue_concrete
setblock 106 147 568 minecraft:gray_concrete
setblock 106 147 571 minecraft:gray_concrete
setblock 107 147 567 minecraft:gray_concrete
fill 108 147 599 108 153 599 minecraft:blue_concrete
setblock 109 147 567 minecraft:gray_concrete
fill 110 147 557 110 217 557 minecraft:blue_concrete
setblock 110 147 568 minecraft:gray_concrete
setblock 110 147 571 minecraft:gray_concrete
fill 114 147 557 114 153 557 minecraft:blue_concrete
fill 117 147 557 117 220 557 minecraft:blue_concrete
setblock 118 147 557 minecraft:pearlescent_froglight
fill 119 147 557 124 149 557 minecraft:blue_concrete
fill 124 147 599 124 149 599 minecraft:blue_concrete
setblock 125 147 557 minecraft:white_stained_glass
fill 126 147 557 126 216 557 minecraft:blue_concrete
fill 130 147 557 134 149 557 minecraft:blue_concrete
setblock 135 147 557 minecraft:white_stained_glass
fill 136 147 557 136 216 557 minecraft:blue_concrete
fill 136 147 565 136 221 565 minecraft:blue_concrete
setblock 136 147 566 minecraft:white_concrete
fill 136 147 567 136 153 567 minecraft:blue_concrete
fill 136 147 583 136 153 583 minecraft:blue_concrete
fill 136 147 591 136 220 591 minecraft:blue_concrete
fill 136 147 597 136 178 597 minecraft:blue_concrete
setblock 94 148 558 minecraft:white_stained_glass
fill 94 148 596 94 220 596 minecraft:blue_concrete
fill 107 148 568 107 150 568 minecraft:end_stone
fill 107 148 571 107 152 571 minecraft:end_stone
fill 110 148 569 110 150 569 minecraft:end_stone
setblock 118 148 557 minecraft:blue_concrete
fill 122 148 593 124 149 593 minecraft:end_stone
fill 123 148 592 123 149 592 minecraft:end_stone
fill 123 148 594 123 149 594 minecraft:end_stone
fill 125 148 557 125 220 557 minecraft:blue_concrete
fill 135 148 557 135 217 557 minecraft:blue_concrete
setblock 136 148 558 minecraft:pearlescent_froglight
fill 136 148 566 136 195 566 minecraft:blue_concrete
fill 136 148 584 136 157 585 minecraft:blue_concrete
setblock 136 148 586 minecraft:white_concrete
fill 136 148 587 136 159 587 minecraft:blue_concrete
fill 94 149 558 94 220 558 minecraft:blue_concrete
setblock 94 149 581 minecraft:pearlescent_froglight
fill 113 149 587 114 150 587 minecraft:light_gray_concrete
setblock 118 149 557 minecraft:pearlescent_froglight
setblock 129 149 599 minecraft:white_stained_glass
fill 136 149 558 136 216 558 minecraft:blue_concrete
fill 136 149 571 136 216 571 minecraft:blue_concrete
setblock 136 149 572 minecraft:white_concrete
setblock 136 149 576 minecraft:white_stained_glass
fill 136 149 577 136 165 577 minecraft:blue_concrete
fill 136 149 586 136 220 586 minecraft:blue_concrete
fill 94 150 581 94 153 582 minecraft:blue_concrete
setblock 94 150 583 minecraft:white_concrete
fill 94 150 584 94 174 584 minecraft:blue_concrete
fill 94 150 589 94 168 589 minecraft:blue_concrete
setblock 94 150 590 minecraft:white_concrete
fill 94 150 591 94 158 594 minecraft:blue_concrete
fill 110 150 599 111 150 599 minecraft:white_concrete
fill 118 150 557 118 200 557 minecraft:blue_concrete
setblock 119 150 557 minecraft:white_stained_glass
fill 120 150 557 124 163 557 minecraft:blue_concrete
setblock 124 150 599 minecraft:white_stained_glass
fill 129 150 599 129 218 599 minecraft:blue_concrete
fill 130 150 557 132 153 557 minecraft:blue_concrete
setblock 133 150 557 minecraft:white_concrete
fill 134 150 557 134 218 557 minecraft:blue_concrete
setblock 136 150 559 minecraft:white_concrete
fill 136 150 560 136 196 561 minecraft:blue_concrete
fill 136 150 572 136 161 572 minecraft:blue_concrete
fill 136 150 576 136 178 576 minecraft:blue_concrete
fill 94 151 583 94 172 583 minecraft:blue_concrete
fill 94 151 590 94 220 590 minecraft:blue_concrete
fill 107 151 557 107 189 557 minecraft:blue_concrete
setblock 108 151 557 minecraft:pearlescent_froglight
fill 110 151 599 111 172 599 minecraft:blue_concrete
fill 116 151 563 117 152 564 minecraft:gray_concrete
fill 119 151 557 119 165 557 minecraft:blue_concrete
fill 124 151 599 124 153 599 minecraft:blue_concrete
fill 133 151 557 133 203 557 minecraft:blue_concrete
fill 136 151 559 136 217 559 minecraft:blue_concrete
setblock 94 152 580 minecraft:white_stained_glass
setblock 97 152 560 minecraft:light[level=14]
setblock 97 152 568 minecraft:light[level=14]
setblock 97 152 576 minecraft:light[level=14]
setblock 97 152 584 minecraft:light[level=14]
setblock 97 152 592 minecraft:light[level=14]
setblock 105 152 560 minecraft:light[level=14]
setblock 105 152 568 minecraft:light[level=14]
setblock 105 152 576 minecraft:light[level=14]
setblock 105 152 584 minecraft:light[level=14]
setblock 105 152 592 minecraft:light[level=14]
fill 108 152 557 108 221 557 minecraft:blue_concrete
setblock 113 152 560 minecraft:light[level=14]
setblock 113 152 568 minecraft:light[level=14]
setblock 113 152 576 minecraft:light[level=14]
setblock 113 152 584 minecraft:light[level=14]
setblock 113 152 592 minecraft:light[level=14]
setblock 121 152 560 minecraft:light[level=14]
setblock 121 152 568 minecraft:light[level=14]
setblock 121 152 576 minecraft:light[level=14]
setblock 121 152 584 minecraft:light[level=14]
setblock 121 152 592 minecraft:light[level=14]
setblock 129 152 560 minecraft:light[level=14]
setblock 129 152 568 minecraft:light[level=14]
setblock 129 152 576 minecraft:light[level=14]
setblock 129 152 584 minecraft:light[level=14]
setblock 129 152 592 minecraft:light[level=14]
fill 136 152 568 136 153 569 minecraft:blue_concrete
setblock 136 152 570 minecraft:pearlescent_froglight
setblock 136 152 575 minecraft:white_stained_glass
fill 94 153 580 94 220 580 minecraft:blue_concrete
setblock 94 153 585 minecraft:white_concrete
setblock 94 153 586 minecraft:white_stained_glass
setblock 105 153 599 minecraft:pearlescent_froglight
fill 136 153 570 136 155 570 minecraft:blue_concrete
fill 136 153 575 136 221 575 minecraft:blue_concrete
setblock 136 153 592 minecraft:white_stained_glass
fill 136 153 593 136 164 594 minecraft:blue_concrete
fill 94 154 565 94 155 565 minecraft:light_gray_concrete
fill 94 154 581 94 155 581 minecraft:light_gray_concrete
fill 94 154 582 94 220 582 minecraft:blue_concrete
fill 94 154 585 94 194 586 minecraft:blue_concrete
fill 94 154 597 94 155 597 minecraft:light_gray_concrete
fill 98 154 557 98 155 557 minecraft:light_gray_concrete
fill 105 154 599 105 156 599 minecraft:blue_concrete
fill 108 154 599 108 155 599 minecraft:light_gray_concrete
fill 114 154 557 114 155 557 minecraft:light_gray_concrete
fill 124 154 599 124 155 599 minecraft:light_gray_concrete
fill 130 154 557 130 155 557 minecraft:light_gray_concrete
fill 131 154 557 132 158 557 minecraft:blue_concrete
fill 136 154 567 136 155 567 minecraft:light_gray_concrete
setblock 136 154 568 minecraft:white_concrete
fill 136 154 569 136 212 569 minecraft:blue_concrete
fill 136 154 583 136 155 583 minecraft:light_gray_concrete
setblock 136 154 592 minecraft:white_concrete
fill 122 155 599 122 220 599 minecraft:blue_concrete
setblock 123 155 599 minecraft:white_concrete
fill 136 155 568 136 220 568 minecraft:blue_concrete
fill 136 155 592 136 220 592 minecraft:blue_concrete
fill 94 156 565 94 161 565 minecraft:blue_concrete
fill 94 156 581 94 161 581 minecraft:blue_concrete
fill 94 156 597 94 161 597 minecraft:blue_concrete
fill 98 156 557 98 161 557 minecraft:blue_concrete
fill 108 156 599 108 161 599 minecraft:blue_concrete
fill 114 156 557 114 161 557 minecraft:blue_concrete
fill 123 156 599 124 161 599 minecraft:blue_concrete
fill 130 156 557 130 161 557 minecraft:blue_concrete
fill 136 156 567 136 157 567 minecraft:blue_concrete
setblock 136 156 570 minecraft:white_stained_glass
fill 136 156 583 136 161 583 minecraft:blue_concrete
setblock 105 157 599 minecraft:pearlescent_froglight
fill 136 157 570 136 210 570 minecraft:blue_concrete
setblock 94 158 574 minecraft:pearlescent_froglight
fill 105 158 599 105 220 599 minecraft:blue_concrete
setblock 136 158 567 minecraft:white_concrete
setblock 136 158 584 minecraft:white_stained_glass
fill 136 158 585 136 161 585 minecraft:blue_concrete
setblock 94 159 569 minecraft:white_concrete
fill 94 159 570 94 165 572 minecraft:blue_concrete
setblock 94 159 574 minecraft:white_stained_glass
fill 94 159 591 94 160 591 minecraft:blue_concrete
setblock 94 159 592 minecraft:white_concrete
fill 94 159 593 94 179 594 minecraft:blue_concrete
fill 131 159 557 131 209 557 minecraft:blue_concrete
setblock 132 159 557 minecraft:pearlescent_froglight
fill 136 159 567 136 161 567 minecraft:blue_concrete
fill 136 159 584 136 183 584 minecraft:blue_concrete
fill 94 160 569 94 220 569 minecraft:blue_concrete
fill 94 160 574 94 196 574 minecraft:blue_concrete
setblock 94 160 588 minecraft:white_stained_glass
fill 94 160 592 94 180 592 minecraft:blue_concrete
setblock 97 160 560 minecraft:light[level=14]
setblock 97 160 568 minecraft:light[level=14]
setblock 97 160 576 minecraft:light[level=14]
setblock 97 160 584 minecraft:light[level=14]
setblock 97 160 592 minecraft:light[level=14]
setblock 105 160 560 minecraft:light[level=14]
setblock 105 160 568 minecraft:light[level=14]
setblock 105 160 576 minecraft:light[level=14]
setblock 105 160 584 minecraft:light[level=14]
setblock 105 160 592 minecraft:light[level=14]
setblock 113 160 560 minecraft:light[level=14]
setblock 113 160 568 minecraft:light[level=14]
setblock 113 160 576 minecraft:light[level=14]
setblock 113 160 584 minecraft:light[level=14]
setblock 113 160 592 minecraft:light[level=14]
setblock 121 160 560 minecraft:light[level=14]
setblock 121 160 568 minecraft:light[level=14]
setblock 121 160 576 minecraft:light[level=14]
setblock 121 160 584 minecraft:light[level=14]
setblock 121 160 592 minecraft:light[level=14]
setblock 129 160 560 minecraft:light[level=14]
setblock 129 160 568 minecraft:light[level=14]
setblock 129 160 576 minecraft:light[level=14]
setblock 129 160 584 minecraft:light[level=14]
setblock 129 160 592 minecraft:light[level=14]
fill 132 160 557 132 220 557 minecraft:blue_concrete
setblock 136 160 574 minecraft:white_stained_glass
setblock 136 160 587 minecraft:pearlescent_froglight
fill 94 161 588 94 218 588 minecraft:blue_concrete
setblock 94 161 591 minecraft:pearlescent_froglight
fill 136 161 574 136 203 574 minecraft:blue_concrete
fill 136 161 587 136 220 587 minecraft:blue_concrete
fill 94 162 565 94 164 565 minecraft:light_gray_concrete
fill 94 162 581 94 164 581 minecraft:light_gray_concrete
fill 94 162 591 94 196 591 minecraft:blue_concrete
fill 94 162 597 94 164 597 minecraft:light_gray_concrete
fill 98 162 557 98 164 557 minecraft:light_gray_concrete
fill 107 162 579 107 163 579 minecraft:gray_concrete
fill 108 162 599 108 164 599 minecraft:light_gray_concrete
setblock 111 162 557 minecraft:white_stained_glass
fill 112 162 557 113 176 557 minecraft:blue_concrete
setblock 113 162 599 minecraft:white_concrete
fill 114 162 557 114 164 557 minecraft:light_gray_concrete
setblock 123 162 599 minecraft:blue_concrete
fill 124 162 599 124 164 599 minecraft:light_gray_concrete
fill 130 162 557 130 164 557 minecraft:light_gray_concrete
setblock 136 162 564 minecraft:white_stained_glass
fill 136 162 567 136 164 567 minecraft:light_gray_concrete
setblock 136 162 572 minecraft:white_concrete
fill 136 162 583 136 164 583 minecraft:light_gray_concrete
setblock 136 162 585 minecraft:white_concrete
setblock 95 163 599 minecraft:pearlescent_froglight
setblock 97 163 557 minecraft:white_concrete
fill 111 163 557 111 208 557 minecraft:blue_concrete
fill 113 163 599 113 205 599 minecraft:blue_concrete
setblock 123 163 599 minecraft:pearlescent_froglight
fill 136 163 564 136 220 564 minecraft:blue_concrete
fill 136 163 572 136 174 572 minecraft:blue_concrete
fill 136 163 585 136 176 585 minecraft:blue_concrete
fill 95 164 599 95 203 599 minecraft:blue_concrete
fill 97 164 557 97 220 557 minecraft:blue_concrete
setblock 97 164 599 minecraft:white_concrete
fill 98 164 599 101 185 599 minecraft:blue_concrete
fill 101 164 571 102 165 572 minecraft:light_gray_concrete
fill 103 164 571 103 165 571 minecraft:light_gray_concrete
fill 120 164 557 122 202 557 minecraft:blue_concrete
setblock 120 164 599 minecraft:white_concrete
setblock 123 164 557 minecraft:white_stained_glass
fill 123 164 599 123 204 599 minecraft:blue_concrete
fill 124 164 557 124 220 557 minecraft:blue_concrete
fill 94 165 565 94 170 565 minecraft:blue_concrete
fill 94 165 581 94 170 581 minecraft:blue_concrete
fill 94 165 597 94 170 597 minecraft:blue_concrete
fill 97 165 599 97 201 599 minecraft:blue_concrete
fill 98 165 557 98 170 557 minecraft:blue_concrete
fill 108 165 599 108 170 599 minecraft:blue_concrete
setblock 109 165 557 minecraft:white_stained_glass
fill 113 165 569 113 166 569 minecraft:end_stone
fill 114 165 557 114 170 557 minecraft:blue_concrete
fill 120 165 599 120 216 599 minecraft:blue_concrete
fill 123 165 557 123 209 557 minecraft:blue_concrete
fill 124 165 599 124 170 599 minecraft:blue_concrete
fill 130 165 557 130 170 557 minecraft:blue_concrete
setblock 130 165 599 minecraft:white_stained_glass
fill 136 165 567 136 170 567 minecraft:blue_concrete
fill 136 165 583 136 170 583 minecraft:blue_concrete
fill 136 165 593 136 217 593 minecraft:blue_concrete
setblock 136 165 594 minecraft:white_concrete
fill 94 166 570 94 176 570 minecraft:blue_concrete
setblock 94 166 571 minecraft:white_stained_glass
fill 94 166 572 94 217 572 minecraft:blue_concrete
setblock 104 166 557 minecraft:pearlescent_froglight
fill 105 166 557 106 188 557 minecraft:blue_concrete
fill 109 166 557 109 200 557 minecraft:blue_concrete
setblock 119 166 557 minecraft:white_concrete
fill 130 166 599 130 182 599 minecraft:blue_concrete
setblock 136 166 577 minecraft:white_concrete
fill 136 166 594 136 215 594 minecraft:blue_concrete
setblock 94 167 567 minecraft:white_concrete
fill 94 167 571 94 220 571 minecraft:blue_concrete
fill 104 167 557 104 220 557 minecraft:blue_concrete
fill 106 167 588 106 168 588 minecraft:light_gray_concrete
fill 119 167 557 119 218 557 minecraft:blue_concrete
fill 136 167 577 136 218 577 minecraft:blue_concrete
fill 94 168 567 94 217 567 minecraft:blue_concrete
setblock 97 168 560 minecraft:light[level=14]
setblock 97 168 568 minecraft:light[level=14]
setblock 97 168 576 minecraft:light[level=14]
setblock 97 168 584 minecraft:light[level=14]
setblock 97 168 592 minecraft:light[level=14]
setblock 105 168 560 minecraft:light[level=14]
setblock 105 168 568 minecraft:light[level=14]
setblock 105 168 576 minecraft:light[level=14]
setblock 105 168 584 minecraft:light[level=14]
setblock 105 168 592 minecraft:light[level=14]
setblock 113 168 560 minecraft:light[level=14]
setblock 113 168 568 minecraft:light[level=14]
setblock 113 168 576 minecraft:light[level=14]
setblock 113 168 584 minecraft:light[level=14]
setblock 113 168 592 minecraft:light[level=14]
setblock 121 168 560 minecraft:light[level=14]
setblock 121 168 568 minecraft:light[level=14]
setblock 121 168 576 minecraft:light[level=14]
setblock 121 168 584 minecraft:light[level=14]
setblock 121 168 592 minecraft:light[level=14]
fill 122 168 568 123 169 569 minecraft:end_stone
setblock 129 168 560 minecraft:light[level=14]
setblock 129 168 568 minecraft:light[level=14]
setblock 129 168 576 minecraft:light[level=14]
setblock 129 168 584 minecraft:light[level=14]
setblock 129 168 592 minecraft:light[level=14]
fill 136 168 589 136 220 589 minecraft:blue_concrete
setblock 136 168 590 minecraft:white_stained_glass
setblock 94 169 568 minecraft:pearlescent_froglight
setblock 94 169 589 minecraft:white_stained_glass
fill 136 169 590 136 202 590 minecraft:blue_concrete
fill 94 170 568 94 189 568 minecraft:blue_concrete
fill 94 170 589 94 188 589 minecraft:blue_concrete
fill 103 170 599 103 220 599 minecraft:blue_concrete
setblock 104 170 599 minecraft:white_concrete
fill 94 171 565 94 173 565 minecraft:light_gray_concrete
fill 94 171 581 94 173 581 minecraft:light_gray_concrete
fill 94 171 597 94 173 597 minecraft:light_gray_concrete
fill 98 171 557 98 173 557 minecraft:light_gray_concrete
fill 104 171 599 104 174 599 minecraft:blue_concrete
fill 108 171 599 108 173 599 minecraft:light_gray_concrete
fill 114 171 557 114 173 557 minecraft:light_gray_concrete
fill 124 171 599 124 173 599 minecraft:light_gray_concrete
fill 130 171 557 130 173 557 minecraft:light_gray_concrete
fill 131 171 573 131 172 574 minecraft:end_stone
fill 136 171 567 136 173 567 minecraft:light_gray_concrete
fill 136 171 583 136 173 583 minecraft:light_gray_concrete
setblock 94 172 566 minecraft:white_concrete
fill 94 173 566 94 220 566 minecraft:blue_concrete
setblock 94 173 583 minecraft:pearlescent_froglight
fill 110 173 599 110 201 599 minecraft:blue_concrete
setblock 111 173 599 minecraft:white_stained_glass
fill 94 174 565 94 179 565 minecraft:blue_concrete
fill 94 174 581 94 179 581 minecraft:blue_concrete
fill 94 174 583 94 195 583 minecraft:blue_concrete
fill 94 174 597 94 179 597 minecraft:blue_concrete
fill 98 174 557 98 179 557 minecraft:blue_concrete
fill 108 174 599 108 179 599 minecraft:blue_concrete
fill 111 174 599 111 195 599 minecraft:blue_concrete
fill 114 174 557 114 179 557 minecraft:blue_concrete
setblock 119 174 599 minecraft:pearlescent_froglight
fill 124 174 599 124 179 599 minecraft:blue_concrete
fill 130 174 557 130 179 557 minecraft:blue_concrete
fill 136 174 567 136 179 567 minecraft:blue_concrete
fill 136 174 583 136 179 583 minecraft:blue_concrete
setblock 94 175 584 minecraft:pearlescent_froglight
setblock 104 175 599 minecraft:pearlescent_froglight
setblock 119 175 599 minecraft:blue_concrete
fill 127 175 573 127 176 573 minecraft:gray_concrete
setblock 136 175 572 minecraft:white_stained_glass
fill 94 176 584 94 189 584 minecraft:blue_concrete
setblock 97 176 560 minecraft:light[level=14]
setblock 97 176 568 minecraft:light[level=14]
setblock 97 176 576 minecraft:light[level=14]
setblock 97 176 584 minecraft:light[level=14]
setblock 97 176 592 minecraft:light[level=14]
fill 104 176 599 104 220 599 minecraft:blue_concrete
setblock 105 176 560 minecraft:light[level=14]
setblock 105 176 568 minecraft:light[level=14]
setblock 105 176 576 minecraft:light[level=14]
setblock 105 176 584 minecraft:light[level=14]
setblock 105 176 592 minecraft:light[level=14]
setblock 113 176 560 minecraft:light[level=14]
setblock 113 176 568 minecraft:light[level=14]
setblock 113 176 576 minecraft:light[level=14]
setblock 113 176 584 minecraft:light[level=14]
setblock 113 176 592 minecraft:light[level=14]
fill 114 176 595 115 177 595 minecraft:light_gray_concrete
setblock 119 176 599 minecraft:white_concrete
setblock 121 176 560 minecraft:light[level=14]
setblock 121 176 568 minecraft:light[level=14]
setblock 121 176 576 minecraft:light[level=14]
setblock 121 176 584 minecraft:light[level=14]
setblock 121 176 592 minecraft:light[level=14]
setblock 129 176 560 minecraft:light[level=14]
setblock 129 176 568 minecraft:light[level=14]
setblock 129 176 576 minecraft:light[level=14]
setblock 129 176 584 minecraft:light[level=14]
setblock 129 176 592 minecraft:light[level=14]
fill 136 176 572 136 220 572 minecraft:blue_concrete
setblock 136 176 582 minecraft:pearlescent_froglight
setblock 94 177 570 minecraft:white_concrete
fill 111 177 568 111 178 569 minecraft:end_stone
fill 112 177 557 112 207 557 minecraft:blue_concrete
setblock 113 177 557 minecraft:pearlescent_froglight
setblock 117 177 599 minecraft:pearlescent_froglight
fill 119 177 599 119 180 599 minecraft:blue_concrete
setblock 136 177 578 minecraft:white_concrete
fill 136 177 582 136 220 582 minecraft:blue_concrete
setblock 136 177 585 minecraft:white_stained_glass
setblock 94 178 559 minecraft:pearlescent_froglight
fill 94 178 560 94 188 562 minecraft:blue_concrete
fill 94 178 570 94 180 570 minecraft:blue_concrete
fill 113 178 557 113 220 557 minecraft:blue_concrete
fill 117 178 599 117 218 599 minecraft:blue_concrete
fill 126 178 584 126 179 584 minecraft:white_stained_glass
setblock 128 178 599 minecraft:white_stained_glass
setblock 131 178 599 minecraft:white_concrete
fill 132 178 599 132 220 599 minecraft:blue_concrete
fill 136 178 578 136 192 578 minecraft:blue_concrete
fill 136 178 585 136 188 585 minecraft:blue_concrete
setblock 136 178 598 minecraft:pearlescent_froglight
fill 136 178 599 136 217 599 minecraft:blue_concrete
fill 94 179 559 94 215 559 minecraft:blue_concrete
setblock 94 179 576 minecraft:white_concrete
fill 128 179 599 128 180 599 minecraft:blue_concrete
fill 131 179 599 131 220 599 minecraft:blue_concrete
setblock 136 179 576 minecraft:white_concrete
setblock 136 179 597 minecraft:pearlescent_froglight
fill 136 179 598 136 220 598 minecraft:blue_concrete
fill 94 180 565 94 182 565 minecraft:light_gray_concrete
fill 94 180 576 94 183 576 minecraft:blue_concrete
fill 94 180 581 94 182 581 minecraft:light_gray_concrete
fill 94 180 593 94 217 593 minecraft:blue_concrete
setblock 94 180 594 minecraft:pearlescent_froglight
fill 94 180 597 94 182 597 minecraft:light_gray_concrete
fill 98 180 557 98 182 557 minecraft:light_gray_concrete
fill 108 180 594 108 181 594 minecraft:light_gray_concrete
fill 108 180 599 108 182 599 minecraft:light_gray_concrete
fill 114 180 557 114 182 557 minecraft:light_gray_concrete
fill 114 180 599 114 218 599 minecraft:blue_concrete
setblock 115 180 599 minecraft:pearlescent_froglight
fill 116 180 599 116 206 599 minecraft:blue_concrete
fill 124 180 599 124 182 599 minecraft:light_gray_concrete
fill 126 180 584 126 185 584 minecraft:gray_concrete
fill 130 180 557 130 182 557 minecraft:light_gray_concrete
setblock 133 180 599 minecraft:white_concrete
setblock 136 180 563 minecraft:pearlescent_froglight
fill 136 180 567 136 182 567 minecraft:light_gray_concrete
fill 136 180 576 136 216 576 minecraft:blue_concrete
fill 136 180 583 136 182 583 minecraft:light_gray_concrete
fill 136 180 597 136 203 597 minecraft:blue_concrete
setblock 94 181 570 minecraft:pearlescent_froglight
setblock 94 181 592 minecraft:white_concrete
fill 94 181 594 94 218 594 minecraft:blue_concrete
fill 115 181 599 115 216 599 minecraft:blue_concrete
setblock 119 181 599 minecraft:white_concrete
fill 126 181 583 126 185 583 minecraft:gray_concrete
fill 127 181 584 127 185 584 minecraft:gray_concrete
setblock 128 181 599 minecraft:white_concrete
fill 133 181 599 133 192 599 minecraft:blue_concrete
fill 136 181 563 136 218 563 minecraft:blue_concrete
setblock 136 181 595 minecraft:pearlescent_froglight
fill 94 182 570 94 220 570 minecraft:blue_concrete
fill 94 182 592 94 218 592 minecraft:blue_concrete
setblock 99 182 557 minecraft:white_concrete
fill 100 182 557 101 220 557 minecraft:blue_concrete
setblock 102 182 557 minecraft:pearlescent_froglight
fill 119 182 599 119 216 599 minecraft:blue_concrete
fill 125 182 584 125 185 584 minecraft:gray_concrete
fill 126 182 585 127 185 585 minecraft:gray_concrete
fill 127 182 583 127 185 583 minecraft:gray_concrete
fill 128 182 599 128 197 599 minecraft:blue_concrete
fill 136 182 595 136 199 595 minecraft:blue_concrete
fill 94 183 565 94 188 565 minecraft:blue_concrete
fill 94 183 581 94 188 581 minecraft:blue_concrete
fill 94 183 597 94 188 597 minecraft:blue_concrete
fill 98 183 557 99 188 557 minecraft:blue_concrete
fill 102 183 557 102 216 557 minecraft:blue_concrete
fill 108 183 599 108 188 599 minecraft:blue_concrete
fill 114 183 557 114 188 557 minecraft:blue_concrete
fill 124 183 599 124 188 599 minecraft:blue_concrete
fill 125 183 583 125 185 583 minecraft:gray_concrete
fill 125 183 585 125 185 585 minecraft:gray_concrete
fill 128 183 583 128 185 584 minecraft:gray_concrete
fill 130 183 557 130 188 557 minecraft:blue_concrete
setblock 130 183 599 minecraft:white_stained_glass
fill 136 183 567 136 188 567 minecraft:blue_concrete
fill 136 183 583 136 188 583 minecraft:blue_concrete
setblock 94 184 576 minecraft:white_concrete
setblock 97 184 560 minecraft:light[level=14]
setblock 97 184 568 minecraft:light[level=14]
setblock 97 184 576 minecraft:light[level=14]
setblock 97 184 584 minecraft:light[level=14]
setblock 97 184 592 minecraft:light[level=14]
setblock 105 184 560 minecraft:light[level=14]
setblock 105 184 568 minecraft:light[level=14]
setblock 105 184 576 minecraft:light[level=14]
setblock 105 184 584 minecraft:light[level=14]
setblock 105 184 592 minecraft:light[level=14]
fill 106 184 586 107 185 586 minecraft:end_stone
fill 107 184 587 107 185 587 minecraft:end_stone
setblock 113 184 560 minecraft:light[level=14]
setblock 113 184 568 minecraft:light[level=14]
setblock 113 184 576 minecraft:light[level=14]
setblock 113 184 584 minecraft:light[level=14]
setblock 113 184 592 minecraft:light[level=14]
setblock 121 184 560 minecraft:light[level=14]
setblock 121 184 568 minecraft:light[level=14]
setblock 121 184 576 minecraft:light[level=14]
setblock 121 184 584 minecraft:light[level=14]
setblock 121 184 592 minecraft:light[level=14]
fill 125 184 582 127 185 582 minecraft:gray_concrete
fill 126 184 586 127 185 586 minecraft:gray_concrete
fill 128 184 585 128 185 585 minecraft:gray_concrete
setblock 129 184 560 minecraft:light[level=14]
setblock 129 184 568 minecraft:light[level=14]
setblock 129 184 576 minecraft:light[level=14]
setblock 129 184 584 minecraft:light[level=14]
setblock 129 184 592 minecraft:light[level=14]
fill 130 184 599 130 186 599 minecraft:blue_concrete
setblock 136 184 584 minecraft:pearlescent_froglight
fill 94 185 576 94 220 576 minecraft:blue_concrete
fill 124 185 583 124 185 585 minecraft:gray_concrete
setblock 125 185 586 minecraft:gray_concrete
setblock 128 185 582 minecraft:gray_concrete
setblock 128 185 586 minecraft:gray_concrete
setblock 129 185 584 minecraft:gray_concrete
setblock 135 185 599 minecraft:white_concrete
fill 136 185 584 136 220 584 minecraft:blue_concrete
fill 98 186 599 99 201 599 minecraft:blue_concrete
setblock 100 186 599 minecraft:pearlescent_froglight
fill 101 186 599 101 220 599 minecraft:blue_concrete
fill 125 186 585 125 190 585 minecraft:end_stone
fill 126 186 582 126 190 582 minecraft:end_stone
fill 128 186 581 129 187 582 minecraft:light_gray_concrete
fill 128 186 585 128 189 585 minecraft:end_stone
fill 135 186 599 135 194 599 minecraft:blue_concrete
fill 100 187 599 100 218 599 minecraft:blue_concrete
fill 102 187 568 103 188 568 minecraft:end_stone
setblock 116 187 557 minecraft:white_concrete
setblock 130 187 599 minecraft:white_concrete
setblock 102 188 599 minecraft:pearlescent_froglight
fill 116 188 557 116 221 557 minecraft:blue_concrete
setblock 126 188 599 minecraft:white_concrete
fill 127 188 599 127 220 599 minecraft:blue_concrete
fill 130 188 599 130 220 599 minecraft:blue_concrete
fill 94 189 560 94 211 561 minecraft:blue_concrete
setblock 94 189 562 minecraft:white_concrete
fill 94 189 565 94 191 565 minecraft:light_gray_concrete
fill 94 189 581 94 191 581 minecraft:light_gray_concrete
setblock 94 189 589 minecraft:pearlescent_froglight
fill 94 189 597 94 191 597 minecraft:light_gray_concrete
fill 98 189 557 98 191 557 minecraft:light_gray_concrete
fill 99 189 557 99 218 557 minecraft:blue_concrete
fill 102 189 599 102 220 599 minecraft:blue_concrete
fill 105 189 557 105 220 557 minecraft:blue_concrete
setblock 106 189 557 minecraft:pearlescent_froglight
fill 108 189 599 108 191 599 minecraft:light_gray_concrete
fill 114 189 557 114 191 557 minecraft:light_gray_concrete
fill 124 189 599 124 191 599 minecraft:light_gray_concrete
fill 126 189 599 126 213 599 minecraft:blue_concrete
fill 130 189 557 130 191 557 minecraft:light_gray_concrete
fill 136 189 567 136 191 567 minecraft:light_gray_concrete
fill 136 189 583 136 191 583 minecraft:light_gray_concrete
setblock 136 189 585 minecraft:white_stained_glass
fill 94 190 562 94 217 562 minecraft:blue_concrete
setblock 94 190 568 minecraft:pearlescent_froglight
setblock 94 190 584 minecraft:white_concrete
fill 94 190 589 94 218 589 minecraft:blue_concrete
fill 106 190 557 106 220 557 minecraft:blue_concrete
setblock 107 190 557 minecraft:white_stained_glass
fill 110 190 564 111 191 564 minecraft:gray_concrete
fill 110 190 568 110 191 568 minecraft:white_stained_glass
setblock 125 190 599 minecraft:white_stained_glass
fill 136 190 585 136 216 585 minecraft:blue_concrete
fill 94 191 568 94 220 568 minecraft:blue_concrete
fill 94 191 584 94 193 584 minecraft:blue_concrete
fill 107 191 557 107 220 557 minecraft:blue_concrete
fill 125 191 599 125 221 599 minecraft:blue_concrete
fill 94 192 565 94 197 565 minecraft:blue_concrete
fill 94 192 581 94 197 581 minecraft:blue_concrete
fill 94 192 597 94 197 597 minecraft:blue_concrete
setblock 97 192 560 minecraft:light[level=14]
setblock 97 192 568 minecraft:light[level=14]
setblock 97 192 576 minecraft:light[level=14]
setblock 97 192 584 minecraft:light[level=14]
setblock 97 192 592 minecraft:light[level=14]
fill 98 192 557 98 197 557 minecraft:blue_concrete
setblock 105 192 560 minecraft:light[level=14]
setblock 105 192 568 minecraft:light[level=14]
setblock 105 192 576 minecraft:light[level=14]
setblock 105 192 584 minecraft:light[level=14]
setblock 105 192 592 minecraft:light[level=14]
fill 108 192 599 108 197 599 minecraft:blue_concrete
fill 110 192 568 110 201 568 minecraft:gray_concrete
setblock 113 192 560 minecraft:light[level=14]
setblock 113 192 568 minecraft:light[level=14]
setblock 113 192 576 minecraft:light[level=14]
setblock 113 192 584 minecraft:light[level=14]
setblock 113 192 592 minecraft:light[level=14]
fill 114 192 557 114 197 557 minecraft:blue_concrete
setblock 121 192 560 minecraft:light[level=14]
setblock 121 192 568 minecraft:light[level=14]
setblock 121 192 576 minecraft:light[level=14]
setblock 121 192 584 minecraft:light[level=14]
setblock 121 192 592 minecraft:light[level=14]
fill 124 192 599 124 197 599 minecraft:blue_concrete
setblock 129 192 560 minecraft:light[level=14]
setblock 129 192 568 minecraft:light[level=14]
setblock 129 192 576 minecraft:light[level=14]
setblock 129 192 584 minecraft:light[level=14]
setblock 129 192 592 minecraft:light[level=14]
fill 130 192 557 130 197 557 minecraft:blue_concrete
fill 136 192 567 136 197 567 minecraft:blue_concrete
setblock 136 192 580 minecraft:pearlescent_froglight
fill 136 192 583 136 197 583 minecraft:blue_concrete
setblock 94 193 598 minecraft:pearlescent_froglight
fill 111 193 568 111 201 568 minecraft:gray_concrete
setblock 133 193 599 minecraft:white_concrete
setblock 136 193 578 minecraft:pearlescent_froglight
fill 136 193 580 136 221 580 minecraft:blue_concrete
setblock 94 194 584 minecraft:pearlescent_froglight
fill 94 194 598 94 220 598 minecraft:blue_concrete
fill 110 194 569 111 201 569 minecraft:gray_concrete
setblock 115 194 557 minecraft:white_stained_glass
fill 122 194 582 122 195 584 minecraft:light_gray_concrete
fill 123 194 583 123 195 584 minecraft:light_gray_concrete
fill 133 194 599 133 220 599 minecraft:blue_concrete
fill 136 194 578 136 215 578 minecraft:blue_concrete
fill 94 195 584 94 207 585 minecraft:blue_concrete
setblock 94 195 586 minecraft:white_concrete
fill 109 195 568 109 201 569 minecraft:gray_concrete
fill 110 195 567 111 201 567 minecraft:gray_concrete
fill 112 195 568 112 201 568 minecraft:gray_concrete
fill 115 195 557 115 221 557 minecraft:blue_concrete
fill 127 195 586 127 196 586 minecraft:gray_concrete
fill 128 195 580 128 196 580 minecraft:light_gray_concrete
setblock 135 195 599 minecraft:white_stained_glass
setblock 94 196 583 minecraft:pearlescent_froglight
fill 94 196 586 94 205 586 minecraft:blue_concrete
fill 109 196 567 109 201 567 minecraft:gray_concrete
fill 110 196 570 111 201 570 minecraft:gray_concrete
setblock 111 196 599 minecraft:pearlescent_froglight
fill 112 196 567 112 201 567 minecraft:gray_concrete
fill 112 196 569 112 201 569 minecraft:gray_concrete
fill 135 196 599 135 218 599 minecraft:blue_concrete
setblock 136 196 566 minecraft:white_concrete
setblock 94 197 574 minecraft:pearlescent_froglight
fill 94 197 583 94 201 583 minecraft:blue_concrete
setblock 94 197 591 minecraft:pearlescent_froglight
fill 108 197 568 108 201 569 minecraft:gray_concrete
fill 109 197 570 109 201 570 minecraft:gray_concrete
fill 110 197 566 111 201 566 minecraft:gray_concrete
setblock 111 197 599 minecraft:blue_concrete
fill 112 197 570 112 201 570 minecraft:gray_concrete
fill 113 197 568 113 201 568 minecraft:gray_concrete
setblock 136 197 560 minecraft:white_stained_glass
fill 136 197 561 136 220 561 minecraft:blue_concrete
fill 136 197 566 136 220 566 minecraft:blue_concrete
fill 94 198 565 94 200 565 minecraft:light_gray_concrete
fill 94 198 574 94 220 574 minecraft:blue_concrete
fill 94 198 581 94 200 581 minecraft:light_gray_concrete
fill 94 198 591 94 218 591 minecraft:blue_concrete
fill 94 198 597 94 200 597 minecraft:light_gray_concrete
fill 98 198 557 98 200 557 minecraft:light_gray_concrete
fill 108 198 567 108 201 567 minecraft:gray_concrete
fill 108 198 570 108 201 570 minecraft:gray_concrete
fill 108 198 599 108 200 599 minecraft:light_gray_concrete
fill 109 198 566 109 201 566 minecraft:gray_concrete
fill 109 198 571 111 201 571 minecraft:gray_concrete
setblock 111 198 599 minecraft:white_stained_glass
fill 112 198 566 112 201 566 minecraft:gray_concrete
fill 113 198 567 113 201 567 minecraft:gray_concrete
fill 113 198 569 113 201 570 minecraft:gray_concrete
fill 114 198 557 114 200 557 minecraft:light_gray_concrete
fill 124 198 599 124 200 599 minecraft:light_gray_concrete
setblock 128 198 599 minecraft:white_stained_glass
fill 130 198 557 130 200 557 minecraft:light_gray_concrete
fill 136 198 560 136 217 560 minecraft:blue_concrete
fill 136 198 567 136 200 567 minecraft:light_gray_concrete
fill 136 198 583 136 200 583 minecraft:light_gray_concrete
fill 107 199 568 107 201 569 minecraft:gray_concrete
fill 108 199 566 108 201 566 minecraft:gray_concrete
fill 110 199 565 111 201 565 minecraft:gray_concrete
fill 111 199 599 111 216 599 minecraft:blue_concrete
fill 112 199 571 112 201 571 minecraft:gray_concrete
fill 113 199 566 113 201 566 minecraft:gray_concrete
fill 114 199 568 114 201 568 minecraft:gray_concrete
fill 124 199 585 124 200 585 minecraft:white_stained_glass
fill 128 199 599 128 200 599 minecraft:blue_concrete
setblock 97 200 560 minecraft:light[level=14]
setblock 97 200 568 minecraft:light[level=14]
setblock 97 200 576 minecraft:light[level=14]
setblock 97 200 584 minecraft:light[level=14]
setblock 97 200 592 minecraft:light[level=14]
setblock 105 200 560 minecraft:light[level=14]
setblock 105 200 568 minecraft:light[level=14]
setblock 105 200 576 minecraft:light[level=14]
setblock 105 200 584 minecraft:light[level=14]
setblock 105 200 592 minecraft:light[level=14]
fill 107 200 567 107 201 567 minecraft:gray_concrete
fill 107 200 570 107 201 570 minecraft:gray_concrete
fill 108 200 571 108 201 571 minecraft:gray_concrete
fill 109 200 565 109 201 565 minecraft:gray_concrete
fill 109 200 572 112 201 572 minecraft:gray_concrete
fill 112 200 565 112 201 565 minecraft:gray_concrete
setblock 113 200 560 minecraft:light[level=14]
fill 113 200 571 113 201 571 minecraft:gray_concrete
setblock 113 200 576 minecraft:light[level=14]
setblock 113 200 584 minecraft:light[level=14]
setblock 113 200 592 minecraft:light[level=14]
fill 114 200 567 114 201 567 minecraft:gray_concrete
fill 114 200 569 114 201 570 minecraft:gray_concrete
setblock 121 200 560 minecraft:light[level=14]
setblock 121 200 568 minecraft:light[level=14]
setblock 121 200 576 minecraft:light[level=14]
setblock 121 200 584 minecraft:light[level=14]
setblock 121 200 592 minecraft:light[level=14]
setblock 129 200 560 minecraft:light[level=14]
setblock 129 200 568 minecraft:light[level=14]
setblock 129 200 576 minecraft:light[level=14]
setblock 129 200 584 minecraft:light[level=14]
setblock 129 200 592 minecraft:light[level=14]
setblock 136 200 595 minecraft:white_concrete
fill 94 201 565 94 206 565 minecraft:blue_concrete
setblock 94 201 581 minecraft:white_stained_glass
fill 94 201 597 94 206 597 minecraft:blue_concrete
fill 98 201 557 98 206 557 minecraft:blue_concrete
fill 106 201 568 106 201 569 minecraft:gray_concrete
setblock 107 201 566 minecraft:gray_concrete
setblock 107 201 571 minecraft:gray_concrete
setblock 108 201 565 minecraft:gray_concrete
setblock 108 201 572 minecraft:gray_concrete
fill 108 201 599 108 206 599 minecraft:blue_concrete
setblock 109 201 557 minecraft:white_stained_glass
fill 109 201 564 111 201 564 minecraft:gray_concrete
setblock 113 201 565 minecraft:gray_concrete
setblock 113 201 572 minecraft:gray_concrete
fill 114 201 557 114 206 557 minecraft:blue_concrete
setblock 114 201 566 minecraft:gray_concrete
setblock 114 201 571 minecraft:gray_concrete
setblock 115 201 568 minecraft:gray_concrete
setblock 118 201 557 minecraft:white_concrete
fill 124 201 585 124 211 586 minecraft:gray_concrete
fill 124 201 599 124 206 599 minecraft:blue_concrete
setblock 128 201 599 minecraft:white_concrete
fill 130 201 557 130 206 557 minecraft:blue_concrete
fill 136 201 567 136 206 567 minecraft:blue_concrete
fill 136 201 583 136 206 583 minecraft:blue_concrete
fill 136 201 595 136 220 595 minecraft:blue_concrete
fill 94 202 581 94 206 581 minecraft:blue_concrete
setblock 94 202 583 minecraft:white_concrete
setblock 97 202 599 minecraft:white_stained_glass
setblock 98 202 599 minecraft:white_concrete
fill 99 202 599 99 216 599 minecraft:blue_concrete
fill 109 202 557 109 220 557 minecraft:blue_concrete
fill 110 202 567 110 203 567 minecraft:end_stone
fill 110 202 570 110 205 570 minecraft:end_stone
setblock 110 202 599 minecraft:white_concrete
fill 112 202 568 112 204 568 minecraft:end_stone
fill 118 202 557 118 221 557 minecraft:blue_concrete
fill 128 202 599 128 210 599 minecraft:blue_concrete
setblock 136 202 581 minecraft:pearlescent_froglight
fill 94 203 583 94 217 583 minecraft:blue_concrete
fill 95 203 583 101 203 583 minecraft:gray_concrete
fill 97 203 581 101 204 582 minecraft:gray_concrete
fill 97 203 584 101 204 585 minecraft:gray_concrete
fill 97 203 599 98 218 599 minecraft:blue_concrete
fill 110 203 599 110 220 599 minecraft:blue_concrete
setblock 120 203 557 minecraft:white_concrete
fill 121 203 557 122 220 557 minecraft:blue_concrete
fill 123 203 585 123 211 586 minecraft:gray_concrete
fill 125 203 585 125 211 585 minecraft:gray_concrete
setblock 136 203 573 minecraft:white_stained_glass
fill 136 203 581 136 220 581 minecraft:blue_concrete
setblock 136 203 590 minecraft:white_concrete
setblock 95 204 599 minecraft:white_stained_glass
fill 96 204 583 96 205 583 minecraft:light_gray_concrete
fill 97 204 583 101 204 583 minecraft:gray_concrete
fill 99 204 580 99 205 580 minecraft:light_gray_concrete
fill 99 204 586 99 205 586 minecraft:light_gray_concrete
fill 102 204 583 102 205 583 minecraft:light_gray_concrete
fill 120 204 557 120 206 557 minecraft:blue_concrete
fill 124 204 584 124 211 584 minecraft:gray_concrete
fill 124 204 587 124 211 587 minecraft:gray_concrete
fill 125 204 586 125 211 586 minecraft:gray_concrete
setblock 133 204 557 minecraft:white_stained_glass
fill 136 204 573 136 220 573 minecraft:blue_concrete
setblock 136 204 574 minecraft:pearlescent_froglight
setblock 136 204 579 minecraft:pearlescent_froglight
fill 136 204 590 136 216 590 minecraft:blue_concrete
setblock 136 204 597 minecraft:pearlescent_froglight
fill 95 205 599 95 215 599 minecraft:blue_concrete
fill 98 205 582 100 215 584 minecraft:end_stone
fill 122 205 585 122 211 586 minecraft:gray_concrete
fill 123 205 584 123 211 584 minecraft:gray_concrete
fill 123 205 587 123 211 587 minecraft:gray_concrete
setblock 123 205 599 minecraft:white_concrete
fill 125 205 584 125 211 584 minecraft:gray_concrete
fill 125 205 587 125 211 587 minecraft:gray_concrete
fill 126 205 585 126 211 586 minecraft:gray_concrete
fill 133 205 557 133 218 557 minecraft:blue_concrete
fill 136 205 574 136 214 574 minecraft:blue_concrete
fill 136 205 579 136 215 579 minecraft:blue_concrete
fill 136 205 597 136 217 597 minecraft:blue_concrete
setblock 94 206 586 minecraft:white_concrete
fill 97 206 583 97 207 583 minecraft:light_gray_concrete
fill 99 206 581 99 207 581 minecraft:light_gray_concrete
fill 99 206 585 99 207 585 minecraft:light_gray_concrete
fill 101 206 583 101 207 583 minecraft:light_gray_concrete
setblock 113 206 599 minecraft:pearlescent_froglight
fill 122 206 584 122 211 584 minecraft:gray_concrete
fill 122 206 587 122 211 587 minecraft:gray_concrete
fill 123 206 583 124 211 583 minecraft:gray_concrete
fill 123 206 588 124 211 588 minecraft:gray_concrete
fill 123 206 599 123 220 599 minecraft:blue_concrete
fill 126 206 584 126 211 584 minecraft:gray_concrete
fill 126 206 587 126 211 587 minecraft:gray_concrete
fill 94 207 565 94 209 565 minecraft:light_gray_concrete
setblock 94 207 573 minecraft:white_stained_glass
fill 94 207 581 94 209 581 minecraft:light_gray_concrete
fill 94 207 586 94 220 586 minecraft:blue_concrete
fill 94 207 597 94 209 597 minecraft:light_gray_concrete
fill 98 207 557 98 209 557 minecraft:light_gray_concrete
fill 108 207 599 108 209 599 minecraft:light_gray_concrete
fill 113 207 599 113 215 599 minecraft:blue_concrete
fill 114 207 557 114 209 557 minecraft:light_gray_concrete
setblock 116 207 599 minecraft:white_concrete
setblock 120 207 557 minecraft:white_concrete
fill 121 207 585 121 211 586 minecraft:gray_concrete
fill 122 207 583 122 211 583 minecraft:gray_concrete
fill 122 207 588 122 211 588 minecraft:gray_concrete
fill 124 207 599 124 209 599 minecraft:light_gray_concrete
fill 125 207 583 125 211 583 minecraft:gray_concrete
fill 125 207 588 125 211 588 minecraft:gray_concrete
fill 127 207 585 127 211 586 minecraft:gray_concrete
fill 130 207 557 130 209 557 minecraft:light_gray_concrete
fill 136 207 567 136 209 567 minecraft:light_gray_concrete
fill 136 207 583 136 209 583 minecraft:light_gray_concrete
fill 94 208 573 94 221 573 minecraft:blue_concrete
fill 94 208 584 94 215 584 minecraft:blue_concrete
setblock 94 208 585 minecraft:white_concrete
setblock 97 208 560 minecraft:light[level=14]
setblock 97 208 568 minecraft:light[level=14]
setblock 97 208 576 minecraft:light[level=14]
setblock 97 208 584 minecraft:light[level=14]
setblock 97 208 592 minecraft:light[level=14]
setblock 105 208 560 minecraft:light[level=14]
setblock 105 208 568 minecraft:light[level=14]
setblock 105 208 576 minecraft:light[level=14]
setblock 105 208 584 minecraft:light[level=14]
setblock 105 208 592 minecraft:light[level=14]
setblock 112 208 557 minecraft:white_concrete
setblock 113 208 560 minecraft:light[level=14]
setblock 113 208 568 minecraft:light[level=14]
setblock 113 208 576 minecraft:light[level=14]
setblock 113 208 584 minecraft:light[level=14]
setblock 113 208 592 minecraft:light[level=14]
fill 116 208 599 116 214 599 minecraft:blue_concrete
fill 120 208 557 120 216 557 minecraft:blue_concrete
setblock 121 208 560 minecraft:light[level=14]
setblock 121 208 568 minecraft:light[level=14]
setblock 121 208 576 minecraft:light[level=14]
fill 121 208 584 121 211 584 minecraft:gray_concrete
fill 121 208 587 121 211 587 minecraft:gray_concrete
setblock 121 208 592 minecraft:light[level=14]
fill 123 208 582 125 211 582 minecraft:gray_concrete
fill 123 208 589 124 211 589 minecraft:gray_concrete
fill 126 208 583 126 211 583 minecraft:gray_concrete
fill 126 208 588 126 211 588 minecraft:gray_concrete
fill 127 208 584 127 211 584 minecraft:gray_concrete
fill 127 208 587 127 211 587 minecraft:gray_concrete
setblock 129 208 560 minecraft:light[level=14]
setblock 129 208 568 minecraft:light[level=14]
setblock 129 208 576 minecraft:light[level=14]
setblock 129 208 584 minecraft:light[level=14]
setblock 129 208 592 minecraft:light[level=14]
fill 94 209 585 94 220 585 minecraft:blue_concrete
setblock 111 209 557 minecraft:pearlescent_froglight
fill 112 209 557 112 220 557 minecraft:blue_concrete
fill 120 209 585 120 211 586 minecraft:gray_concrete
fill 121 209 583 121 211 583 minecraft:gray_concrete
fill 121 209 588 121 211 588 minecraft:gray_concrete
fill 122 209 582 122 211 582 minecraft:gray_concrete
fill 122 209 589 122 211 589 minecraft:gray_concrete
fill 125 209 589 126 211 589 minecraft:gray_concrete
fill 126 209 582 126 211 582 minecraft:gray_concrete
fill 127 209 583 127 211 583 minecraft:gray_concrete
fill 127 209 588 127 211 588 minecraft:gray_concrete
fill 128 209 585 128 211 586 minecraft:gray_concrete
fill 94 210 565 94 215 565 minecraft:blue_concrete
fill 94 210 581 94 215 581 minecraft:blue_concrete
fill 94 210 597 94 215 597 minecraft:blue_concrete
fill 98 210 557 98 215 557 minecraft:blue_concrete
fill 108 210 599 108 215 599 minecraft:blue_concrete
fill 111 210 557 111 217 557 minecraft:blue_concrete
fill 112 210 567 112 211 568 minecraft:end_stone
fill 114 210 557 114 215 557 minecraft:blue_concrete
fill 120 210 583 120 211 584 minecraft:gray_concrete
fill 120 210 587 120 211 588 minecraft:gray_concrete
fill 121 210 582 121 211 582 minecraft:gray_concrete
fill 121 210 589 121 211 589 minecraft:gray_concrete
setblock 123 210 557 minecraft:white_stained_glass
fill 123 210 581 125 211 581 minecraft:gray_concrete
fill 123 210 590 125 211 590 minecraft:gray_concrete
fill 124 210 599 124 215 599 minecraft:blue_concrete
setblock 128 210 557 minecraft:white_concrete
fill 128 210 584 128 211 584 minecraft:gray_concrete
fill 128 210 587 128 211 587 minecraft:gray_concrete
fill 129 210 557 130 215 557 minecraft:blue_concrete
setblock 131 210 557 minecraft:white_concrete
fill 136 210 567 136 215 567 minecraft:blue_concrete
fill 136 210 583 136 215 583 minecraft:blue_concrete
fill 119 211 584 119 211 587 minecraft:gray_concrete
setblock 122 211 581 minecraft:gray_concrete
setblock 122 211 590 minecraft:gray_concrete
fill 123 211 557 123 220 557 minecraft:blue_concrete
setblock 126 211 581 minecraft:gray_concrete
setblock 126 211 590 minecraft:gray_concrete
setblock 127 211 582 minecraft:gray_concrete
setblock 127 211 589 minecraft:gray_concrete
fill 128 211 557 128 220 557 minecraft:blue_concrete
setblock 128 211 583 minecraft:gray_concrete
setblock 128 211 588 minecraft:gray_concrete
setblock 128 211 599 minecraft:white_concrete
fill 129 211 585 129 211 586 minecraft:gray_concrete
fill 131 211 557 131 220 557 minecraft:blue_concrete
setblock 136 211 570 minecraft:white_concrete
fill 94 212 560 94 217 560 minecraft:blue_concrete
setblock 94 212 561 minecraft:pearlescent_froglight
fill 122 212 586 122 214 586 minecraft:end_stone
fill 124 212 567 124 213 567 minecraft:end_stone
fill 124 212 584 124 215 584 minecraft:end_stone
fill 125 212 587 125 213 587 minecraft:end_stone
fill 128 212 599 128 220 599 minecraft:blue_concrete
fill 136 212 570 136 220 570 minecraft:blue_concrete
fill 94 213 561 94 220 561 minecraft:blue_concrete
fill 116 213 593 117 214 593 minecraft:light_gray_concrete
setblock 136 213 569 minecraft:pearlescent_froglight
setblock 126 214 599 minecraft:white_stained_glass
setblock 136 214 569 minecraft:blue_concrete
setblock 116 215 599 minecraft:white_stained_glass
fill 126 215 599 126 220 599 minecraft:blue_concrete
setblock 136 215 569 minecraft:pearlescent_froglight
setblock 136 215 574 minecraft:pearlescent_froglight
setblock 94 216 559 minecraft:pearlescent_froglight
fill 94 216 565 94 218 565 minecraft:light_gray_concrete
fill 94 216 581 94 218 581 minecraft:light_gray_concrete
setblock 94 216 584 minecraft:pearlescent_froglight
fill 94 216 597 94 218 597 minecraft:light_gray_concrete
setblock 95 216 599 minecraft:white_concrete
setblock 97 216 560 minecraft:light[level=14]
setblock 97 216 568 minecraft:light[level=14]
setblock 97 216 576 minecraft:light[level=14]
setblock 97 216 584 minecraft:light[level=14]
setblock 97 216 592 minecraft:light[level=14]
fill 98 216 557 98 218 557 minecraft:light_gray_concrete
fill 98 216 582 100 216 584 minecraft:light_gray_concrete
setblock 105 216 560 minecraft:light[level=14]
setblock 105 216 568 minecraft:light[level=14]
setblock 105 216 576 minecraft:light[level=14]
setblock 105 216 584 minecraft:light[level=14]
setblock 105 216 592 minecraft:light[level=14]
fill 108 216 599 108 218 599 minecraft:light_gray_concrete
setblock 112 216 599 minecraft:white_concrete
setblock 113 216 560 minecraft:light[level=14]
setblock 113 216 568 minecraft:light[level=14]
setblock 113 216 576 minecraft:light[level=14]
setblock 113 216 584 minecraft:light[level=14]
setblock 113 216 592 minecraft:light[level=14]
setblock 113 216 599 minecraft:pearlescent_froglight
fill 114 216 557 114 218 557 minecraft:light_gray_concrete
fill 116 216 599 116 221 599 minecraft:blue_concrete
setblock 121 216 560 minecraft:light[level=14]
setblock 121 216 568 minecraft:light[level=14]
setblock 121 216 576 minecraft:light[level=14]
setblock 121 216 584 minecraft:light[level=14]
setblock 121 216 592 minecraft:light[level=14]
fill 124 216 599 124 218 599 minecraft:light_gray_concrete
fill 129 216 557 129 218 557 minecraft:blue_concrete
setblock 129 216 560 minecraft:light[level=14]
setblock 129 216 568 minecraft:light[level=14]
setblock 129 216 576 minecraft:light[level=14]
setblock 129 216 584 minecraft:light[level=14]
setblock 129 216 592 minecraft:light[level=14]
fill 130 216 557 130 218 557 minecraft:light_gray_concrete
fill 136 216 567 136 218 567 minecraft:light_gray_concrete
fill 136 216 569 136 220 569 minecraft:blue_concrete
setblock 136 216 574 minecraft:white_stained_glass
fill 136 216 578 136 216 579 minecraft:white_concrete
fill 136 216 583 136 218 583 minecraft:light_gray_concrete
setblock 136 216 594 minecraft:white_stained_glass
setblock 94 217 557 minecraft:black_concrete
setblock 94 217 559 minecraft:blue_concrete
setblock 94 217 575 minecraft:black_concrete
setblock 94 217 577 minecraft:black_concrete
fill 94 217 578 94 218 579 minecraft:blue_concrete
fill 94 217 584 94 220 584 minecraft:blue_concrete
setblock 94 217 599 minecraft:black_concrete
fill 95 217 557 96 220 557 minecraft:blue_concrete
fill 95 217 599 95 220 599 minecraft:blue_concrete
fill 98 217 583 100 217 583 minecraft:light_gray_concrete
setblock 99 217 582 minecraft:light_gray_concrete
setblock 99 217 584 minecraft:light_gray_concrete
setblock 99 217 599 minecraft:black_concrete
setblock 102 217 557 minecraft:white_stained_glass
setblock 109 217 599 minecraft:black_concrete
setblock 111 217 599 minecraft:white_concrete
fill 112 217 599 113 220 599 minecraft:blue_concrete
setblock 115 217 599 minecraft:white_stained_glass
setblock 119 217 599 minecraft:black_concrete
setblock 120 217 557 minecraft:black_concrete
setblock 120 217 599 minecraft:pearlescent_froglight
fill 126 217 557 126 218 557 minecraft:black_concrete
fill 136 217 557 136 217 558 minecraft:black_concrete
setblock 136 217 562 minecraft:black_concrete
setblock 136 217 571 minecraft:black_concrete
fill 136 217 574 136 221 574 minecraft:blue_concrete
setblock 136 217 576 minecraft:black_concrete
fill 136 217 578 136 220 579 minecraft:blue_concrete
setblock 136 217 585 minecraft:black_concrete
setblock 136 217 590 minecraft:white_stained_glass
fill 136 217 594 136 220 594 minecraft:blue_concrete
fill 94 218 557 94 221 557 minecraft:blue_concrete
fill 94 218 559 94 218 560 minecraft:black_concrete
setblock 94 218 562 minecraft:black_concrete
setblock 94 218 563 minecraft:white_concrete
setblock 94 218 567 minecraft:black_concrete
fill 94 218 572 94 219 572 minecraft:black_concrete
fill 94 218 575 94 220 575 minecraft:blue_concrete
fill 94 218 577 94 220 577 minecraft:blue_concrete
setblock 94 218 583 minecraft:black_concrete
fill 94 218 593 94 219 593 minecraft:black_concrete
fill 94 218 599 94 220 599 minecraft:blue_concrete
fill 99 218 583 99 219 583 minecraft:light_gray_concrete
fill 99 218 599 99 220 599 minecraft:blue_concrete
fill 102 218 557 102 220 557 minecraft:blue_concrete
fill 109 218 599 109 220 599 minecraft:blue_concrete
fill 110 218 557 111 218 557 minecraft:black_concrete
fill 111 218 599 111 220 599 minecraft:blue_concrete
fill 115 218 599 115 220 599 minecraft:blue_concrete
fill 119 218 599 120 220 599 minecraft:blue_concrete
fill 120 218 557 120 220 557 minecraft:blue_concrete
setblock 135 218 557 minecraft:black_concrete
fill 136 218 557 136 218 558 minecraft:blue_concrete
fill 136 218 559 136 218 560 minecraft:black_concrete
fill 136 218 562 136 220 562 minecraft:blue_concrete
fill 136 218 571 136 221 571 minecraft:blue_concrete
fill 136 218 576 136 220 576 minecraft:blue_concrete
fill 136 218 585 136 220 585 minecraft:blue_concrete
setblock 136 218 588 minecraft:pearlescent_froglight
fill 136 218 590 136 220 590 minecraft:blue_concrete
setblock 136 218 593 minecraft:black_concrete
fill 136 218 596 136 218 597 minecraft:black_concrete
setblock 136 218 599 minecraft:black_concrete
fill 94 219 559 94 220 560 minecraft:blue_concrete
fill 94 219 562 94 220 563 minecraft:blue_concrete
setblock 94 219 565 minecraft:black_concrete
fill 94 219 567 94 220 567 minecraft:blue_concrete
fill 94 219 578 94 220 578 minecraft:blue_concrete
setblock 94 219 579 minecraft:black_concrete
fill 94 219 581 94 220 581 minecraft:blue_concrete
fill 94 219 583 94 220 583 minecraft:blue_concrete
fill 94 219 588 94 219 589 minecraft:black_concrete
setblock 94 219 591 minecraft:white_stained_glass
setblock 94 219 592 minecraft:black_concrete
setblock 94 219 594 minecraft:black_concrete
fill 94 219 597 94 220 597 minecraft:blue_concrete
setblock 97 219 599 minecraft:black_concrete
fill 98 219 557 98 220 557 minecraft:blue_concrete
fill 98 219 599 98 220 599 minecraft:blue_concrete
setblock 99 219 557 minecraft:black_concrete
setblock 100 219 599 minecraft:black_concrete
setblock 103 219 557 minecraft:black_concrete
fill 108 219 599 108 220 599 minecraft:blue_concrete
fill 110 219 557 111 220 557 minecraft:blue_concrete
fill 114 219 557 114 220 557 minecraft:blue_concrete
setblock 114 219 599 minecraft:black_concrete
fill 117 219 599 118 219 599 minecraft:black_concrete
setblock 119 219 557 minecraft:black_concrete
fill 124 219 599 124 220 599 minecraft:blue_concrete
fill 126 219 557 126 220 557 minecraft:blue_concrete
setblock 129 219 557 minecraft:black_concrete
setblock 129 219 599 minecraft:black_concrete
fill 130 219 557 130 220 557 minecraft:blue_concrete
fill 133 219 557 134 219 557 minecraft:black_concrete
setblock 134 219 599 minecraft:black_concrete
setblock 135 219 557 minecraft:blue_concrete
setblock 135 219 599 minecraft:white_concrete
fill 136 219 557 136 219 558 minecraft:black_concrete
fill 136 219 559 136 220 560 minecraft:blue_concrete
setblock 136 219 563 minecraft:black_concrete
fill 136 219 567 136 220 567 minecraft:blue_concrete
setblock 136 219 577 minecraft:black_concrete
setblock 136 219 583 minecraft:black_concrete
fill 136 219 588 136 220 588 minecraft:blue_concrete
fill 136 219 593 136 220 593 minecraft:blue_concrete
fill 136 219 596 136 220 596 minecraft:blue_concrete
setblock 136 219 597 minecraft:white_concrete
fill 136 219 599 136 220 599 minecraft:blue_concrete
fill 94 220 565 94 222 565 minecraft:blue_concrete
setblock 94 220 572 minecraft:blue_concrete
setblock 94 220 579 minecraft:blue_concrete
fill 94 220 588 94 220 589 minecraft:blue_concrete
fill 94 220 591 94 220 594 minecraft:blue_concrete
setblock 97 220 599 minecraft:pearlescent_froglight
setblock 99 220 557 minecraft:blue_concrete
setblock 100 220 599 minecraft:blue_concrete
setblock 103 220 557 minecraft:blue_concrete
setblock 114 220 599 minecraft:blue_concrete
fill 117 220 599 118 220 599 minecraft:blue_concrete
setblock 119 220 557 minecraft:blue_concrete
setblock 129 220 557 minecraft:blue_concrete
fill 129 220 599 129 221 599 minecraft:blue_concrete
fill 133 220 557 134 220 557 minecraft:blue_concrete
fill 134 220 599 135 220 599 minecraft:blue_concrete
setblock 135 220 557 minecraft:white_stained_glass
fill 136 220 557 136 220 558 minecraft:blue_concrete
setblock 136 220 563 minecraft:blue_concrete
setblock 136 220 577 minecraft:blue_concrete
setblock 136 220 583 minecraft:blue_concrete
setblock 136 220 597 minecraft:blue_concrete
fill 94 221 558 94 241 559 minecraft:black_concrete
setblock 94 221 560 minecraft:pearlescent_froglight
fill 94 221 561 94 222 564 minecraft:black_concrete
fill 94 221 566 94 221 572 minecraft:black_concrete
fill 94 221 574 94 221 592 minecraft:black_concrete
fill 94 221 593 94 221 594 minecraft:blue_concrete
fill 94 221 595 94 221 599 minecraft:black_concrete
fill 95 221 557 107 225 557 minecraft:black_concrete
fill 95 221 599 115 221 599 minecraft:black_concrete
fill 108 221 573 109 222 574 minecraft:end_stone
fill 109 221 557 114 221 557 minecraft:black_concrete
fill 117 221 557 117 278 557 minecraft:black_concrete
fill 117 221 599 120 280 599 minecraft:black_concrete
fill 119 221 557 136 221 557 minecraft:black_concrete
fill 122 221 599 124 233 599 minecraft:black_concrete
fill 126 221 599 128 221 599 minecraft:black_concrete
fill 130 221 599 133 222 599 minecraft:black_concrete
fill 134 221 599 134 222 599 minecraft:blue_concrete
fill 135 221 599 136 221 599 minecraft:black_concrete
fill 136 221 558 136 277 559 minecraft:black_concrete
setblock 136 221 560 minecraft:blue_concrete
fill 136 221 561 136 222 564 minecraft:black_concrete
fill 136 221 566 136 221 570 minecraft:black_concrete
fill 136 221 572 136 229 573 minecraft:black_concrete
fill 136 221 576 136 222 579 minecraft:black_concrete
fill 136 221 581 136 221 591 minecraft:black_concrete
setblock 136 221 592 minecraft:pearlescent_froglight
fill 136 221 593 136 221 598 minecraft:black_concrete
setblock 94 222 557 minecraft:black_concrete
fill 94 222 560 94 236 560 minecraft:black_concrete
fill 94 222 566 94 228 567 minecraft:black_concrete
setblock 94 222 568 minecraft:blue_concrete
fill 94 222 569 94 243 574 minecraft:black_concrete
setblock 94 222 575 minecraft:blue_concrete
fill 94 222 576 94 222 581 minecraft:black_concrete
fill 94 222 582 94 222 583 minecraft:blue_concrete
fill 94 222 584 94 285 584 minecraft:black_concrete
setblock 94 222 585 minecraft:blue_concrete
fill 94 222 586 94 241 590 minecraft:black_concrete
setblock 94 222 591 minecraft:pearlescent_froglight
fill 94 222 592 94 307 592 minecraft:black_concrete
setblock 94 222 593 minecraft:blue_concrete
fill 94 222 594 94 222 598 minecraft:black_concrete
setblock 94 222 599 minecraft:blue_concrete
fill 95 222 599 104 222 599 minecraft:black_concrete
setblock 105 222 599 minecraft:pearlescent_froglight
setblock 106 222 599 minecraft:blue_concrete
fill 107 222 599 107 234 599 minecraft:black_concrete
fill 108 222 557 109 234 557 minecraft:black_concrete
setblock 108 222 599 minecraft:blue_concrete
fill 109 222 599 112 222 599 minecraft:black_concrete
setblock 110 222 557 minecraft:white_stained_glass
fill 111 222 557 113 222 557 minecraft:blue_concrete
setblock 113 222 599 minecraft:blue_concrete
fill 114 222 557 116 233 557 minecraft:black_concrete
fill 114 222 599 116 245 599 minecraft:black_concrete
fill 118 222 557 124 222 557 minecraft:black_concrete
fill 121 222 599 121 238 599 minecraft:black_concrete
setblock 125 222 557 minecraft:blue_concrete
fill 125 222 599 126 281 599 minecraft:black_concrete
fill 126 222 557 129 229 557 minecraft:black_concrete
setblock 127 222 599 minecraft:blue_concrete
fill 128 222 599 129 281 599 minecraft:black_concrete
setblock 130 222 557 minecraft:white_concrete
fill 131 222 557 134 222 557 minecraft:black_concrete
setblock 135 222 557 minecraft:blue_concrete
fill 135 222 599 135 307 599 minecraft:black_concrete
fill 136 222 557 136 307 557 minecraft:black_concrete
fill 136 222 560 136 280 560 minecraft:black_concrete
fill 136 222 565 136 306 565 minecraft:black_concrete
fill 136 222 566 136 222 567 minecraft:blue_concrete
fill 136 222 568 136 277 569 minecraft:black_concrete
setblock 136 222 570 minecraft:blue_concrete
fill 136 222 571 136 242 571 minecraft:black_concrete
fill 136 222 574 136 235 575 minecraft:black_concrete
fill 136 222 580 136 222 587 minecraft:black_concrete
setblock 136 222 588 minecraft:blue_concrete
fill 136 222 589 136 222 596 minecraft:black_concrete
setblock 136 222 597 minecraft:blue_concrete
fill 136 222 598 136 236 598 minecraft:black_concrete
setblock 136 222 599 minecraft:blue_concrete
setblock 94 223 557 minecraft:blue_concrete
fill 94 223 561 94 257 563 minecraft:black_concrete
setblock 94 223 564 minecraft:blue_concrete
fill 94 223 565 94 233 565 minecraft:black_concrete
fill 94 223 568 94 307 568 minecraft:black_concrete
fill 94 223 575 94 228 577 minecraft:black_concrete
setblock 94 223 578 minecraft:blue_concrete
fill 94 223 579 94 226 582 minecraft:black_concrete
setblock 94 223 583 minecraft:blue_concrete
fill 94 223 585 94 263 585 minecraft:black_concrete
fill 94 223 591 94 228 591 minecraft:black_concrete
fill 94 223 593 94 247 595 minecraft:black_concrete
setblock 94 223 596 minecraft:white_concrete
fill 94 223 597 94 224 599 minecraft:black_concrete
fill 95 223 599 101 227 599 minecraft:black_concrete
setblock 102 223 599 minecraft:blue_concrete
fill 103 223 599 106 225 599 minecraft:black_concrete
fill 108 223 599 111 233 599 minecraft:black_concrete
fill 110 223 557 113 232 557 minecraft:black_concrete
setblock 112 223 599 minecraft:blue_concrete
fill 113 223 599 113 307 599 minecraft:black_concrete
schedule function dropper:buildpart/134_2 1t
