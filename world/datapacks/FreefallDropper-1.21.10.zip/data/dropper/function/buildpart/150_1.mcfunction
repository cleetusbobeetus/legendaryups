fill 324 89 611 324 91 611 minecraft:black_concrete
setblock 324 89 619 minecraft:purple_concrete
fill 324 89 624 324 91 624 minecraft:black_concrete
fill 324 89 635 324 91 635 minecraft:black_concrete
setblock 324 89 642 minecraft:purple_concrete
fill 324 89 646 324 91 646 minecraft:black_concrete
fill 282 90 604 282 94 604 minecraft:black_concrete
setblock 282 90 605 minecraft:purple_concrete
fill 282 90 606 282 91 607 minecraft:black_concrete
fill 282 90 613 282 91 613 minecraft:black_concrete
fill 282 90 615 282 91 615 minecraft:black_concrete
setblock 282 90 616 minecraft:purple_concrete
fill 282 90 626 282 91 626 minecraft:black_concrete
fill 282 90 632 282 91 633 minecraft:black_concrete
setblock 282 90 634 minecraft:purple_concrete
setblock 282 90 639 minecraft:purple_concrete
fill 282 90 643 282 91 643 minecraft:black_concrete
setblock 282 90 646 minecraft:purple_concrete
fill 283 90 646 283 91 646 minecraft:black_concrete
setblock 284 90 646 minecraft:purple_concrete
fill 288 90 646 288 91 646 minecraft:black_concrete
setblock 289 90 646 minecraft:purple_concrete
fill 295 90 604 295 93 604 minecraft:black_concrete
fill 295 90 646 297 90 646 minecraft:purple_concrete
setblock 296 90 604 minecraft:purple_concrete
setblock 301 90 604 minecraft:black_concrete
fill 313 90 604 313 91 604 minecraft:black_concrete
fill 314 90 646 314 91 646 minecraft:black_concrete
setblock 315 90 604 minecraft:purple_concrete
fill 317 90 604 317 93 604 minecraft:black_concrete
setblock 319 90 604 minecraft:purple_concrete
fill 324 90 607 324 91 607 minecraft:black_concrete
setblock 324 90 616 minecraft:purple_concrete
fill 324 90 619 324 91 619 minecraft:black_concrete
setblock 324 90 633 minecraft:purple_concrete
fill 324 90 639 324 90 640 minecraft:purple_concrete
fill 324 90 642 324 91 642 minecraft:black_concrete
fill 282 91 605 282 92 605 minecraft:black_concrete
setblock 282 91 611 minecraft:black_concrete
fill 282 91 612 282 92 612 minecraft:gold_block
setblock 282 91 616 minecraft:black_concrete
fill 282 91 628 282 92 628 minecraft:gold_block
setblock 282 91 634 minecraft:black_concrete
setblock 282 91 639 minecraft:black_concrete
fill 282 91 644 282 92 644 minecraft:gold_block
setblock 282 91 646 minecraft:black_concrete
setblock 284 91 646 minecraft:black_concrete
fill 286 91 604 286 92 604 minecraft:gold_block
setblock 289 91 646 minecraft:black_concrete
setblock 291 91 646 minecraft:black_concrete
setblock 292 91 604 minecraft:amethyst_block
setblock 295 91 646 minecraft:black_concrete
setblock 296 91 604 minecraft:black_concrete
fill 296 91 646 296 92 646 minecraft:gold_block
setblock 297 91 646 minecraft:black_concrete
setblock 301 91 604 minecraft:pearlescent_froglight
fill 302 91 604 302 92 604 minecraft:gold_block
setblock 307 91 604 minecraft:black_concrete
fill 312 91 646 312 92 646 minecraft:gold_block
setblock 315 91 604 minecraft:black_concrete
fill 318 91 604 318 92 604 minecraft:gold_block
setblock 319 91 604 minecraft:black_concrete
fill 324 91 614 324 92 614 minecraft:gold_block
setblock 324 91 616 minecraft:black_concrete
fill 324 91 630 324 92 630 minecraft:gold_block
setblock 324 91 633 minecraft:black_concrete
fill 324 91 639 324 91 640 minecraft:black_concrete
fill 282 92 606 282 92 611 minecraft:purple_concrete
fill 282 92 613 282 100 617 minecraft:purple_concrete
fill 282 92 619 282 92 627 minecraft:purple_concrete
fill 282 92 629 282 93 635 minecraft:purple_concrete
fill 282 92 637 282 92 643 minecraft:purple_concrete
fill 282 92 646 289 94 646 minecraft:purple_concrete
fill 283 92 604 285 92 604 minecraft:purple_concrete
fill 288 92 604 294 92 604 minecraft:purple_concrete
fill 291 92 646 291 113 646 minecraft:purple_concrete
fill 293 92 646 295 93 646 minecraft:purple_concrete
fill 296 92 604 301 92 604 minecraft:purple_concrete
fill 297 92 646 311 92 646 minecraft:purple_concrete
fill 303 92 604 316 92 604 minecraft:purple_concrete
fill 313 92 646 313 147 646 minecraft:purple_concrete
setblock 314 92 646 minecraft:pearlescent_froglight
fill 315 92 646 322 92 646 minecraft:purple_concrete
fill 319 92 604 324 92 604 minecraft:purple_concrete
fill 324 92 605 324 92 611 minecraft:purple_concrete
fill 324 92 613 324 131 613 minecraft:purple_concrete
fill 324 92 615 324 92 629 minecraft:purple_concrete
fill 324 92 631 324 125 631 minecraft:purple_concrete
fill 324 92 633 324 92 646 minecraft:purple_concrete
fill 282 93 605 282 93 607 minecraft:purple_concrete
setblock 282 93 608 minecraft:black_concrete
fill 282 93 609 282 93 612 minecraft:purple_concrete
fill 282 93 618 282 112 619 minecraft:purple_concrete
setblock 282 93 620 minecraft:black_concrete
fill 282 93 621 282 120 622 minecraft:purple_concrete
setblock 282 93 623 minecraft:black_concrete
fill 282 93 624 282 98 624 minecraft:purple_concrete
fill 282 93 625 282 93 627 minecraft:black_concrete
fill 282 93 628 282 109 628 minecraft:purple_concrete
fill 282 93 636 282 160 636 minecraft:purple_concrete
setblock 282 93 637 minecraft:black_concrete
fill 282 93 638 282 133 638 minecraft:purple_concrete
setblock 282 93 639 minecraft:black_concrete
fill 282 93 640 282 163 641 minecraft:purple_concrete
fill 282 93 642 282 93 644 minecraft:black_concrete
fill 282 93 645 282 119 645 minecraft:purple_concrete
setblock 283 93 604 minecraft:amethyst_block
fill 284 93 604 284 152 604 minecraft:purple_concrete
setblock 285 93 604 minecraft:black_concrete
fill 286 93 604 287 93 604 minecraft:purple_concrete
setblock 288 93 604 minecraft:amethyst_block
fill 289 93 604 294 100 604 minecraft:purple_concrete
fill 290 93 646 290 102 646 minecraft:purple_concrete
setblock 292 93 646 minecraft:purple_concrete
fill 296 93 604 296 163 604 minecraft:purple_concrete
fill 296 93 646 302 93 646 minecraft:purple_concrete
setblock 297 93 604 minecraft:black_concrete
fill 298 93 604 308 93 604 minecraft:purple_concrete
fill 303 93 646 304 93 646 minecraft:black_concrete
fill 305 93 646 310 103 646 minecraft:purple_concrete
fill 309 93 604 311 93 604 minecraft:black_concrete
setblock 311 93 646 minecraft:black_concrete
fill 312 93 604 316 93 604 minecraft:purple_concrete
setblock 312 93 646 minecraft:purple_concrete
fill 314 93 646 314 144 646 minecraft:purple_concrete
setblock 315 93 646 minecraft:amethyst_block
fill 316 93 646 324 93 646 minecraft:purple_concrete
setblock 318 93 604 minecraft:black_concrete
fill 319 93 604 322 93 604 minecraft:purple_concrete
fill 323 93 604 323 94 604 minecraft:black_concrete
fill 324 93 604 324 99 608 minecraft:purple_concrete
setblock 324 93 609 minecraft:black_concrete
fill 324 93 610 324 104 612 minecraft:purple_concrete
fill 324 93 614 324 93 621 minecraft:purple_concrete
setblock 324 93 622 minecraft:black_concrete
fill 324 93 623 324 100 626 minecraft:purple_concrete
setblock 324 93 627 minecraft:black_concrete
fill 324 93 628 324 109 630 minecraft:purple_concrete
fill 324 93 632 324 93 641 minecraft:purple_concrete
setblock 324 93 642 minecraft:black_concrete
fill 324 93 643 324 103 645 minecraft:purple_concrete
fill 282 94 605 282 125 606 minecraft:purple_concrete
setblock 282 94 607 minecraft:black_concrete
fill 282 94 608 282 98 610 minecraft:purple_concrete
setblock 282 94 611 minecraft:pearlescent_froglight
fill 282 94 612 282 109 612 minecraft:purple_concrete
fill 282 94 620 282 164 620 minecraft:purple_concrete
fill 282 94 623 282 126 623 minecraft:purple_concrete
fill 282 94 625 282 107 627 minecraft:purple_concrete
setblock 282 94 629 minecraft:black_concrete
fill 282 94 630 282 95 635 minecraft:purple_concrete
fill 282 94 637 282 141 637 minecraft:purple_concrete
fill 282 94 639 282 102 639 minecraft:purple_concrete
fill 282 94 642 282 109 644 minecraft:purple_concrete
fill 283 94 604 283 113 604 minecraft:purple_concrete
fill 285 94 604 285 116 604 minecraft:purple_concrete
setblock 285 94 607 minecraft:light[level=13]
setblock 285 94 615 minecraft:light[level=13]
setblock 285 94 623 minecraft:light[level=13]
setblock 285 94 631 minecraft:light[level=13]
setblock 285 94 639 minecraft:light[level=13]
setblock 286 94 604 minecraft:black_concrete
fill 287 94 604 287 163 604 minecraft:purple_concrete
setblock 288 94 604 minecraft:black_concrete
setblock 292 94 646 minecraft:white_concrete
setblock 293 94 607 minecraft:light[level=13]
setblock 293 94 615 minecraft:light[level=13]
setblock 293 94 623 minecraft:light[level=13]
setblock 293 94 631 minecraft:light[level=13]
setblock 293 94 639 minecraft:light[level=13]
fill 293 94 646 293 151 646 minecraft:purple_concrete
setblock 294 94 646 minecraft:black_concrete
fill 295 94 604 295 163 604 minecraft:purple_concrete
fill 295 94 646 301 102 646 minecraft:purple_concrete
fill 297 94 604 301 95 604 minecraft:purple_concrete
setblock 301 94 607 minecraft:light[level=13]
setblock 301 94 615 minecraft:light[level=13]
setblock 301 94 623 minecraft:light[level=13]
setblock 301 94 631 minecraft:light[level=13]
setblock 301 94 639 minecraft:light[level=13]
setblock 302 94 604 minecraft:black_concrete
setblock 302 94 646 minecraft:black_concrete
fill 303 94 604 304 100 604 minecraft:purple_concrete
fill 303 94 646 304 150 646 minecraft:purple_concrete
setblock 305 94 604 minecraft:black_concrete
fill 305 94 643 306 95 643 minecraft:amethyst_block
fill 306 94 604 310 109 604 minecraft:purple_concrete
setblock 309 94 607 minecraft:light[level=13]
setblock 309 94 615 minecraft:light[level=13]
setblock 309 94 623 minecraft:light[level=13]
setblock 309 94 631 minecraft:light[level=13]
setblock 309 94 639 minecraft:light[level=13]
setblock 311 94 604 minecraft:black_concrete
fill 311 94 646 311 106 646 minecraft:purple_concrete
fill 312 94 604 313 109 604 minecraft:purple_concrete
setblock 312 94 646 minecraft:black_concrete
fill 314 94 604 315 94 604 minecraft:black_concrete
fill 315 94 646 315 164 646 minecraft:purple_concrete
setblock 316 94 604 minecraft:amethyst_block
setblock 316 94 646 minecraft:black_concrete
fill 317 94 604 320 109 604 minecraft:purple_concrete
setblock 317 94 607 minecraft:light[level=13]
setblock 317 94 615 minecraft:light[level=13]
setblock 317 94 623 minecraft:light[level=13]
setblock 317 94 631 minecraft:light[level=13]
setblock 317 94 639 minecraft:light[level=13]
fill 317 94 646 324 103 646 minecraft:purple_concrete
setblock 321 94 604 minecraft:black_concrete
fill 322 94 604 322 148 604 minecraft:purple_concrete
fill 324 94 609 324 107 609 minecraft:purple_concrete
fill 324 94 614 324 109 615 minecraft:purple_concrete
setblock 324 94 616 minecraft:pearlescent_froglight
fill 324 94 617 324 96 622 minecraft:purple_concrete
fill 324 94 627 324 101 627 minecraft:purple_concrete
fill 324 94 632 324 104 636 minecraft:purple_concrete
setblock 324 94 637 minecraft:black_concrete
fill 324 94 638 324 99 642 minecraft:purple_concrete
fill 282 95 604 282 163 604 minecraft:purple_concrete
fill 282 95 607 282 119 607 minecraft:purple_concrete
fill 282 95 611 282 163 611 minecraft:purple_concrete
fill 282 95 629 282 163 629 minecraft:purple_concrete
fill 282 95 646 285 105 646 minecraft:purple_concrete
fill 286 95 604 286 109 604 minecraft:purple_concrete
setblock 286 95 646 minecraft:white_concrete
fill 287 95 646 289 99 646 minecraft:purple_concrete
fill 288 95 604 288 154 604 minecraft:purple_concrete
fill 292 95 646 292 99 646 minecraft:purple_concrete
fill 294 95 646 294 163 646 minecraft:purple_concrete
fill 302 95 604 302 109 604 minecraft:purple_concrete
fill 302 95 646 302 132 646 minecraft:purple_concrete
fill 305 95 604 305 113 604 minecraft:purple_concrete
fill 311 95 604 311 134 604 minecraft:purple_concrete
fill 312 95 646 312 109 646 minecraft:purple_concrete
fill 314 95 604 316 111 604 minecraft:purple_concrete
setblock 316 95 646 minecraft:purple_concrete
fill 321 95 604 321 97 604 minecraft:purple_concrete
fill 323 95 604 323 163 604 minecraft:purple_concrete
fill 324 95 616 324 163 616 minecraft:purple_concrete
fill 324 95 637 324 98 637 minecraft:purple_concrete
fill 282 96 630 282 110 630 minecraft:purple_concrete
setblock 282 96 631 minecraft:white_concrete
fill 282 96 632 282 105 635 minecraft:purple_concrete
fill 286 96 646 286 102 646 minecraft:purple_concrete
fill 297 96 604 299 103 604 minecraft:purple_concrete
setblock 300 96 604 minecraft:white_concrete
fill 301 96 604 301 153 604 minecraft:purple_concrete
setblock 316 96 646 minecraft:amethyst_block
fill 282 97 631 282 103 631 minecraft:purple_concrete
fill 290 97 620 291 98 621 minecraft:end_stone
fill 300 97 604 300 125 604 minecraft:purple_concrete
fill 316 97 646 316 163 646 minecraft:purple_concrete
fill 324 97 617 324 121 617 minecraft:purple_concrete
setblock 324 97 618 minecraft:amethyst_block
fill 324 97 619 324 103 622 minecraft:purple_concrete
setblock 321 98 604 minecraft:amethyst_block
fill 324 98 618 324 149 618 minecraft:purple_concrete
fill 282 99 608 282 125 608 minecraft:purple_concrete
setblock 282 99 609 minecraft:amethyst_block
fill 282 99 610 282 163 610 minecraft:purple_concrete
setblock 282 99 624 minecraft:amethyst_block
fill 321 99 604 321 112 604 minecraft:purple_concrete
setblock 324 99 637 minecraft:pearlescent_froglight
fill 282 100 609 282 163 609 minecraft:purple_concrete
fill 282 100 624 282 163 624 minecraft:purple_concrete
fill 287 100 646 288 134 646 minecraft:purple_concrete
setblock 289 100 646 minecraft:white_concrete
setblock 292 100 646 minecraft:white_concrete
fill 324 100 604 324 129 606 minecraft:purple_concrete
setblock 324 100 607 minecraft:pearlescent_froglight
fill 324 100 608 324 101 608 minecraft:purple_concrete
fill 324 100 637 324 117 640 minecraft:purple_concrete
fill 324 100 641 324 100 642 minecraft:amethyst_block
fill 282 101 613 282 163 613 minecraft:purple_concrete
setblock 282 101 614 minecraft:white_concrete
fill 282 101 615 282 102 617 minecraft:purple_concrete
fill 289 101 604 292 122 604 minecraft:purple_concrete
fill 289 101 646 289 161 646 minecraft:purple_concrete
fill 292 101 646 292 159 646 minecraft:purple_concrete
setblock 293 101 604 minecraft:pearlescent_froglight
fill 294 101 604 294 105 604 minecraft:purple_concrete
setblock 303 101 604 minecraft:amethyst_block
fill 304 101 604 304 163 604 minecraft:purple_concrete
fill 324 101 607 324 127 607 minecraft:purple_concrete
setblock 324 101 623 minecraft:white_concrete
fill 324 101 624 324 106 626 minecraft:purple_concrete
fill 324 101 641 324 116 642 minecraft:purple_concrete
fill 282 102 614 282 112 614 minecraft:purple_concrete
setblock 285 102 607 minecraft:light[level=13]
setblock 285 102 615 minecraft:light[level=13]
setblock 285 102 623 minecraft:light[level=13]
setblock 285 102 631 minecraft:light[level=13]
setblock 285 102 639 minecraft:light[level=13]
fill 293 102 604 293 160 604 minecraft:purple_concrete
setblock 293 102 607 minecraft:light[level=13]
setblock 293 102 615 minecraft:light[level=13]
setblock 293 102 623 minecraft:light[level=13]
setblock 293 102 631 minecraft:light[level=13]
setblock 293 102 639 minecraft:light[level=13]
setblock 301 102 607 minecraft:light[level=13]
setblock 301 102 615 minecraft:light[level=13]
setblock 301 102 623 minecraft:light[level=13]
setblock 301 102 631 minecraft:light[level=13]
setblock 301 102 639 minecraft:light[level=13]
fill 303 102 604 303 158 604 minecraft:purple_concrete
setblock 309 102 607 minecraft:light[level=13]
setblock 309 102 615 minecraft:light[level=13]
setblock 309 102 623 minecraft:light[level=13]
setblock 309 102 631 minecraft:light[level=13]
setblock 309 102 639 minecraft:light[level=13]
setblock 317 102 607 minecraft:light[level=13]
setblock 317 102 615 minecraft:light[level=13]
setblock 317 102 623 minecraft:light[level=13]
setblock 317 102 631 minecraft:light[level=13]
setblock 317 102 639 minecraft:light[level=13]
setblock 324 102 608 minecraft:amethyst_block
fill 324 102 623 324 116 623 minecraft:purple_concrete
setblock 324 102 627 minecraft:amethyst_block
setblock 282 103 615 minecraft:pearlescent_froglight
fill 282 103 616 282 107 617 minecraft:purple_concrete
setblock 282 103 639 minecraft:pearlescent_froglight
setblock 286 103 646 minecraft:amethyst_block
setblock 290 103 646 minecraft:pearlescent_froglight
fill 295 103 646 300 109 646 minecraft:purple_concrete
setblock 301 103 646 minecraft:amethyst_block
fill 324 103 608 324 163 608 minecraft:purple_concrete
fill 324 103 627 324 163 627 minecraft:purple_concrete
fill 282 104 615 282 163 615 minecraft:purple_concrete
setblock 282 104 631 minecraft:white_concrete
fill 282 104 639 282 163 639 minecraft:purple_concrete
fill 286 104 646 286 163 646 minecraft:purple_concrete
setblock 290 104 646 minecraft:amethyst_block
setblock 297 104 604 minecraft:amethyst_block
fill 298 104 604 299 121 604 minecraft:purple_concrete
fill 301 104 646 301 108 646 minecraft:purple_concrete
fill 302 104 618 304 104 620 minecraft:redstone_block
fill 302 104 626 304 104 628 minecraft:redstone_block
fill 305 104 646 306 105 646 minecraft:purple_concrete
setblock 307 104 646 minecraft:pearlescent_froglight
fill 308 104 646 310 116 646 minecraft:purple_concrete
fill 310 104 622 312 104 624 minecraft:redstone_block
fill 317 104 646 322 118 646 minecraft:purple_concrete
setblock 323 104 646 minecraft:pearlescent_froglight
fill 324 104 619 324 163 619 minecraft:purple_concrete
setblock 324 104 620 minecraft:amethyst_block
fill 324 104 621 324 128 622 minecraft:purple_concrete
fill 324 104 643 324 128 644 minecraft:purple_concrete
setblock 324 104 645 minecraft:amethyst_block
fill 324 104 646 324 163 646 minecraft:purple_concrete
fill 282 105 631 282 151 631 minecraft:purple_concrete
fill 290 105 623 293 106 623 minecraft:black_concrete
fill 290 105 646 290 123 646 minecraft:purple_concrete
fill 291 105 618 291 106 621 minecraft:purple_concrete
fill 291 105 622 294 106 622 minecraft:black_concrete
fill 291 105 624 291 106 628 minecraft:black_concrete
fill 292 105 616 292 106 620 minecraft:purple_concrete
fill 292 105 621 296 106 621 minecraft:black_concrete
fill 292 105 624 292 106 625 minecraft:black_concrete
fill 292 105 626 296 106 630 minecraft:purple_concrete
fill 293 105 614 293 106 619 minecraft:purple_concrete
fill 293 105 620 298 106 620 minecraft:black_concrete
fill 293 105 624 293 106 624 minecraft:black_concrete
fill 293 105 625 298 106 625 minecraft:purple_concrete
fill 293 105 631 296 106 632 minecraft:purple_concrete
fill 294 105 613 295 106 618 minecraft:purple_concrete
fill 294 105 619 301 105 619 minecraft:black_concrete
fill 294 105 623 299 106 624 minecraft:purple_concrete
fill 294 105 633 296 106 633 minecraft:purple_concrete
fill 295 105 612 305 106 612 minecraft:black_concrete
fill 295 105 622 302 106 622 minecraft:purple_concrete
fill 295 105 634 296 106 634 minecraft:purple_concrete
fill 296 105 611 304 106 611 minecraft:black_concrete
fill 296 105 613 301 105 617 minecraft:purple_concrete
fill 296 105 618 301 105 618 minecraft:black_concrete
fill 296 105 635 296 106 635 minecraft:purple_concrete
fill 297 105 604 297 140 604 minecraft:purple_concrete
fill 297 105 610 302 106 610 minecraft:black_concrete
fill 297 105 621 303 105 621 minecraft:purple_concrete
fill 297 105 626 297 106 627 minecraft:purple_concrete
fill 297 105 628 299 106 635 minecraft:black_concrete
fill 297 105 636 297 106 636 minecraft:purple_concrete
fill 298 105 626 300 106 627 minecraft:black_concrete
fill 298 105 636 301 106 636 minecraft:black_concrete
fill 299 105 609 299 106 609 minecraft:black_concrete
fill 299 105 620 301 105 620 minecraft:purple_concrete
fill 299 105 625 301 105 625 minecraft:black_concrete
fill 299 105 637 301 106 637 minecraft:black_concrete
fill 300 105 609 310 106 609 minecraft:purple_concrete
fill 300 105 623 300 106 623 minecraft:purple_concrete
fill 300 105 624 302 106 624 minecraft:black_concrete
fill 300 105 628 301 105 633 minecraft:purple_concrete
fill 300 105 634 300 106 635 minecraft:black_concrete
fill 301 105 608 309 106 608 minecraft:purple_concrete
fill 301 105 623 302 106 623 minecraft:black_concrete
fill 301 105 626 301 105 627 minecraft:purple_concrete
fill 301 105 634 306 106 635 minecraft:purple_concrete
fill 301 105 638 302 106 638 minecraft:black_concrete
fill 302 105 613 306 106 613 minecraft:black_concrete
fill 302 105 614 303 105 617 minecraft:purple_concrete
fill 302 105 625 303 105 625 minecraft:purple_concrete
fill 302 105 629 303 105 633 minecraft:purple_concrete
fill 302 105 636 309 106 637 minecraft:purple_concrete
fill 303 105 610 310 106 610 minecraft:purple_concrete
fill 303 105 622 304 105 624 minecraft:crying_obsidian
fill 303 105 638 311 106 638 minecraft:purple_concrete
fill 304 105 614 307 106 614 minecraft:black_concrete
fill 304 105 615 304 105 617 minecraft:purple_concrete
fill 304 105 621 308 105 621 minecraft:crying_obsidian
fill 304 105 625 308 105 625 minecraft:crying_obsidian
fill 304 105 629 305 105 630 minecraft:black_concrete
fill 304 105 631 304 106 633 minecraft:purple_concrete
fill 305 105 611 311 106 611 minecraft:purple_concrete
fill 305 105 615 307 106 615 minecraft:black_concrete
fill 305 105 616 305 105 619 minecraft:purple_concrete
fill 305 105 620 307 105 620 minecraft:crying_obsidian
fill 305 105 626 307 105 626 minecraft:crying_obsidian
fill 305 105 627 305 105 628 minecraft:black_concrete
fill 305 105 631 307 106 632 minecraft:black_concrete
fill 305 105 633 305 106 633 minecraft:purple_concrete
fill 306 105 607 306 106 607 minecraft:purple_concrete
fill 306 105 612 311 106 612 minecraft:purple_concrete
fill 306 105 616 308 106 616 minecraft:black_concrete
fill 306 105 617 306 106 619 minecraft:purple_concrete
fill 306 105 627 308 106 629 minecraft:purple_concrete
fill 306 105 630 306 106 630 minecraft:black_concrete
fill 306 105 633 310 106 633 minecraft:black_concrete
fill 306 105 639 306 106 639 minecraft:purple_concrete
fill 307 105 613 312 106 613 minecraft:purple_concrete
fill 307 105 617 308 106 619 minecraft:black_concrete
fill 307 105 630 320 106 630 minecraft:purple_concrete
fill 307 105 634 317 106 634 minecraft:black_concrete
fill 307 105 635 307 106 635 minecraft:purple_concrete
fill 307 105 646 307 114 646 minecraft:purple_concrete
fill 308 105 614 312 106 615 minecraft:purple_concrete
fill 308 105 620 308 106 620 minecraft:black_concrete
fill 308 105 622 309 105 624 minecraft:crying_obsidian
fill 308 105 626 309 106 626 minecraft:black_concrete
fill 308 105 631 319 106 631 minecraft:purple_concrete
fill 308 105 632 308 106 632 minecraft:black_concrete
fill 308 105 635 316 106 635 minecraft:black_concrete
fill 309 105 616 310 105 621 minecraft:purple_concrete
fill 309 105 625 315 105 625 minecraft:purple_concrete
fill 309 105 627 318 106 627 minecraft:black_concrete
fill 309 105 628 309 106 629 minecraft:purple_concrete
fill 309 105 632 319 106 632 minecraft:purple_concrete
fill 310 105 608 311 106 608 minecraft:black_concrete
fill 310 105 626 313 106 626 minecraft:purple_concrete
fill 310 105 628 316 106 628 minecraft:black_concrete
fill 310 105 629 320 106 629 minecraft:purple_concrete
fill 310 105 636 315 106 636 minecraft:black_concrete
fill 310 105 637 312 106 637 minecraft:purple_concrete
fill 311 105 609 313 106 610 minecraft:black_concrete
fill 311 105 616 311 106 620 minecraft:purple_concrete
fill 311 105 621 313 105 621 minecraft:black_concrete
fill 311 105 633 318 106 633 minecraft:purple_concrete
fill 312 105 611 315 106 612 minecraft:black_concrete
fill 312 105 616 312 106 618 minecraft:purple_concrete
fill 312 105 619 314 106 620 minecraft:black_concrete
fill 313 105 613 315 106 618 minecraft:black_concrete
fill 313 105 622 317 105 624 minecraft:purple_concrete
fill 313 105 637 313 106 637 minecraft:black_concrete
fill 314 105 610 314 106 610 minecraft:black_concrete
fill 314 105 621 319 106 621 minecraft:purple_concrete
fill 314 105 626 319 106 626 minecraft:black_concrete
fill 315 105 610 315 106 610 minecraft:purple_concrete
fill 315 105 619 320 106 620 minecraft:purple_concrete
fill 316 105 611 316 106 618 minecraft:purple_concrete
fill 316 105 625 320 106 625 minecraft:black_concrete
fill 317 105 612 317 106 618 minecraft:purple_concrete
fill 317 105 628 321 106 628 minecraft:purple_concrete
fill 318 105 613 318 106 618 minecraft:purple_concrete
fill 318 105 622 318 106 623 minecraft:purple_concrete
fill 318 105 624 321 106 624 minecraft:black_concrete
fill 319 105 614 319 106 618 minecraft:purple_concrete
fill 319 105 622 321 106 623 minecraft:black_concrete
fill 319 105 627 321 106 627 minecraft:purple_concrete
fill 320 105 616 320 106 618 minecraft:purple_concrete
fill 320 105 621 321 106 621 minecraft:black_concrete
fill 320 105 626 321 106 626 minecraft:purple_concrete
fill 321 105 618 321 106 620 minecraft:black_concrete
fill 321 105 625 321 106 625 minecraft:purple_concrete
fill 322 105 623 322 106 623 minecraft:black_concrete
fill 323 105 646 323 160 646 minecraft:purple_concrete
fill 324 105 610 324 128 610 minecraft:purple_concrete
setblock 324 105 611 minecraft:amethyst_block
fill 324 105 612 324 141 612 minecraft:purple_concrete
fill 324 105 620 324 161 620 minecraft:purple_concrete
setblock 324 105 632 minecraft:amethyst_block
fill 324 105 633 324 115 636 minecraft:purple_concrete
fill 324 105 645 324 163 645 minecraft:purple_concrete
fill 282 106 632 282 120 633 minecraft:purple_concrete
setblock 282 106 634 minecraft:white_concrete
fill 282 106 635 282 163 635 minecraft:purple_concrete
fill 282 106 646 282 160 646 minecraft:purple_concrete
fill 283 106 605 289 106 645 minecraft:black_concrete
setblock 283 106 646 minecraft:white_concrete
fill 284 106 646 285 117 646 minecraft:purple_concrete
fill 290 106 605 290 106 622 minecraft:black_concrete
fill 290 106 624 290 106 645 minecraft:black_concrete
fill 291 106 605 291 106 617 minecraft:black_concrete
fill 291 106 629 291 106 645 minecraft:black_concrete
fill 292 106 605 292 106 615 minecraft:black_concrete
fill 292 106 631 292 106 645 minecraft:black_concrete
fill 293 106 605 293 106 613 minecraft:black_concrete
fill 293 106 633 293 106 645 minecraft:black_concrete
setblock 294 106 604 minecraft:pearlescent_froglight
fill 294 106 605 294 106 612 minecraft:black_concrete
fill 294 106 619 300 106 619 minecraft:black_concrete
fill 294 106 634 294 106 645 minecraft:black_concrete
fill 295 106 605 295 106 611 minecraft:black_concrete
fill 295 106 635 295 106 645 minecraft:black_concrete
fill 296 106 605 296 106 610 minecraft:black_concrete
fill 296 106 613 300 106 617 minecraft:purple_concrete
fill 296 106 618 300 106 618 minecraft:black_concrete
fill 296 106 636 296 106 645 minecraft:black_concrete
fill 297 106 605 298 106 609 minecraft:black_concrete
fill 297 106 621 300 106 621 minecraft:purple_concrete
fill 297 106 637 298 106 645 minecraft:black_concrete
fill 299 106 605 300 106 608 minecraft:black_concrete
fill 299 106 620 300 106 620 minecraft:purple_concrete
fill 299 106 625 300 106 625 minecraft:black_concrete
fill 299 106 638 300 106 645 minecraft:black_concrete
fill 300 106 628 300 106 633 minecraft:purple_concrete
fill 301 106 605 305 106 607 minecraft:black_concrete
fill 301 106 613 301 106 616 minecraft:purple_concrete
fill 301 106 617 301 106 621 minecraft:pearlescent_froglight
fill 301 106 625 301 106 629 minecraft:pearlescent_froglight
fill 301 106 630 303 106 633 minecraft:purple_concrete
fill 301 106 639 305 106 645 minecraft:black_concrete
fill 302 106 614 303 106 616 minecraft:purple_concrete
fill 302 106 617 305 106 617 minecraft:pearlescent_froglight
fill 302 106 618 304 106 620 minecraft:black_concrete
fill 302 106 621 304 106 621 minecraft:pearlescent_froglight
fill 302 106 625 304 106 625 minecraft:pearlescent_froglight
fill 302 106 626 304 106 628 minecraft:black_concrete
fill 302 106 629 305 106 629 minecraft:pearlescent_froglight
fill 303 106 622 303 106 624 minecraft:crying_obsidian
fill 304 106 615 304 106 616 minecraft:purple_concrete
fill 304 106 622 304 106 624 minecraft:shroomlight
fill 304 106 630 305 106 630 minecraft:black_concrete
setblock 305 106 616 minecraft:purple_concrete
fill 305 106 618 305 106 620 minecraft:pearlescent_froglight
fill 305 106 621 307 106 621 minecraft:shroomlight
fill 305 106 625 307 106 625 minecraft:shroomlight
fill 305 106 626 305 106 628 minecraft:pearlescent_froglight
setblock 305 106 646 minecraft:pearlescent_froglight
fill 306 106 605 323 106 606 minecraft:black_concrete
fill 306 106 620 307 106 620 minecraft:crying_obsidian
fill 306 106 626 307 106 626 minecraft:crying_obsidian
fill 306 106 640 323 106 645 minecraft:black_concrete
fill 306 106 646 306 123 646 minecraft:purple_concrete
fill 307 106 607 323 106 607 minecraft:black_concrete
fill 307 106 639 323 106 639 minecraft:black_concrete
fill 308 106 621 313 106 621 minecraft:pearlescent_froglight
fill 308 106 622 308 106 624 minecraft:shroomlight
fill 308 106 625 313 106 625 minecraft:pearlescent_froglight
fill 309 106 616 310 106 620 minecraft:purple_concrete
fill 309 106 622 309 106 624 minecraft:pearlescent_froglight
fill 310 106 622 312 106 624 minecraft:black_concrete
fill 312 106 608 323 106 608 minecraft:black_concrete
fill 312 106 638 323 106 638 minecraft:black_concrete
fill 313 106 622 313 106 624 minecraft:pearlescent_froglight
fill 314 106 609 323 106 609 minecraft:black_concrete
fill 314 106 622 315 106 625 minecraft:purple_concrete
fill 314 106 637 323 106 637 minecraft:black_concrete
fill 316 106 610 323 106 610 minecraft:black_concrete
fill 316 106 622 317 106 624 minecraft:purple_concrete
fill 316 106 636 323 106 636 minecraft:black_concrete
fill 317 106 611 323 106 611 minecraft:black_concrete
fill 317 106 635 323 106 635 minecraft:black_concrete
fill 318 106 612 323 106 612 minecraft:black_concrete
fill 318 106 634 323 106 634 minecraft:black_concrete
fill 319 106 613 323 106 613 minecraft:black_concrete
fill 319 106 633 323 106 633 minecraft:black_concrete
fill 320 106 614 323 106 615 minecraft:black_concrete
fill 320 106 631 323 106 632 minecraft:black_concrete
fill 321 106 616 323 106 617 minecraft:black_concrete
fill 321 106 629 323 106 630 minecraft:black_concrete
fill 322 106 618 323 106 622 minecraft:black_concrete
fill 322 106 624 323 106 628 minecraft:black_concrete
setblock 323 106 623 minecraft:black_concrete
fill 324 106 611 324 125 611 minecraft:purple_concrete
fill 324 106 632 324 163 632 minecraft:purple_concrete
fill 282 107 634 282 117 634 minecraft:purple_concrete
fill 283 107 622 283 107 624 minecraft:basalt
fill 283 107 646 283 160 646 minecraft:purple_concrete
fill 284 107 617 286 107 618 minecraft:basalt
setblock 284 107 619 minecraft:magma_block
fill 284 107 620 286 107 621 minecraft:basalt
setblock 284 107 622 minecraft:magma_block
fill 284 107 623 286 108 624 minecraft:basalt
setblock 284 107 625 minecraft:magma_block
fill 284 107 626 286 107 627 minecraft:basalt
setblock 284 107 628 minecraft:magma_block
fill 284 107 629 289 107 629 minecraft:basalt
fill 285 107 614 286 107 616 minecraft:basalt
fill 285 107 619 292 108 619 minecraft:basalt
fill 285 107 622 291 108 622 minecraft:basalt
fill 285 107 625 291 108 625 minecraft:basalt
fill 285 107 628 292 108 628 minecraft:basalt
fill 285 107 630 286 107 632 minecraft:basalt
fill 286 107 612 286 107 613 minecraft:basalt
fill 286 107 633 286 107 634 minecraft:basalt
fill 287 107 610 289 107 611 minecraft:basalt
setblock 287 107 612 minecraft:magma_block
fill 287 107 613 289 108 614 minecraft:basalt
setblock 287 107 615 minecraft:magma_block
fill 287 107 616 289 109 617 minecraft:basalt
setblock 287 107 618 minecraft:magma_block
fill 287 107 620 289 111 620 minecraft:basalt
setblock 287 107 621 minecraft:magma_block
fill 287 107 623 289 111 623 minecraft:basalt
setblock 287 107 624 minecraft:magma_block
fill 287 107 626 289 111 626 minecraft:basalt
setblock 287 107 627 minecraft:magma_block
setblock 287 107 630 minecraft:magma_block
fill 287 107 631 289 109 632 minecraft:basalt
setblock 287 107 633 minecraft:magma_block
fill 287 107 634 289 107 635 minecraft:basalt
setblock 287 107 636 minecraft:magma_block
fill 288 107 609 295 107 609 minecraft:basalt
fill 288 107 612 295 108 612 minecraft:basalt
fill 288 107 615 294 110 615 minecraft:basalt
fill 288 107 618 292 112 618 minecraft:basalt
fill 288 107 621 291 112 621 minecraft:basalt
fill 288 107 624 291 112 624 minecraft:basalt
fill 288 107 627 292 112 627 minecraft:basalt
fill 288 107 630 293 111 630 minecraft:basalt
fill 288 107 633 295 108 633 minecraft:basalt
fill 288 107 636 292 107 637 minecraft:basalt
setblock 289 107 608 minecraft:basalt
setblock 289 107 638 minecraft:basalt
fill 290 107 607 292 107 607 minecraft:basalt
setblock 290 107 608 minecraft:magma_block
fill 290 107 610 292 109 610 minecraft:basalt
setblock 290 107 611 minecraft:magma_block
fill 290 107 613 292 111 613 minecraft:basalt
setblock 290 107 614 minecraft:magma_block
fill 290 107 616 292 113 616 minecraft:basalt
setblock 290 107 617 minecraft:magma_block
setblock 290 107 620 minecraft:magma_block
setblock 290 107 623 minecraft:magma_block
setblock 290 107 626 minecraft:magma_block
setblock 290 107 629 minecraft:magma_block
fill 290 107 631 292 112 631 minecraft:basalt
setblock 290 107 632 minecraft:magma_block
fill 290 107 634 292 111 634 minecraft:basalt
setblock 290 107 635 minecraft:magma_block
setblock 290 107 638 minecraft:magma_block
fill 290 107 639 295 107 639 minecraft:basalt
fill 291 107 606 295 107 606 minecraft:basalt
fill 291 107 608 298 108 608 minecraft:basalt
fill 291 107 611 298 111 611 minecraft:basalt
fill 291 107 614 295 107 614 minecraft:basalt
fill 291 107 617 293 114 617 minecraft:basalt
fill 291 107 620 292 115 620 minecraft:basalt
fill 291 107 623 291 116 623 minecraft:basalt
fill 291 107 626 292 115 626 minecraft:basalt
fill 291 107 629 293 114 629 minecraft:basalt
fill 291 107 632 295 107 632 minecraft:basalt
fill 291 107 635 298 111 635 minecraft:basalt
fill 291 107 638 298 108 638 minecraft:basalt
fill 291 107 640 292 107 640 minecraft:basalt
fill 292 107 605 298 107 605 minecraft:basalt
fill 292 107 641 298 107 641 minecraft:basalt
setblock 293 107 607 minecraft:magma_block
setblock 293 107 610 minecraft:magma_block
setblock 293 107 613 minecraft:magma_block
setblock 293 107 616 minecraft:magma_block
setblock 293 107 631 minecraft:magma_block
setblock 293 107 634 minecraft:magma_block
fill 293 107 636 295 112 636 minecraft:basalt
setblock 293 107 637 minecraft:magma_block
setblock 293 107 640 minecraft:magma_block
fill 293 107 642 295 107 642 minecraft:basalt
fill 294 107 604 294 163 604 minecraft:purple_concrete
fill 294 107 607 301 110 607 minecraft:basalt
fill 294 107 610 300 113 610 minecraft:basalt
fill 294 107 613 295 115 613 minecraft:basalt
fill 294 107 631 294 116 631 minecraft:basalt
fill 294 107 634 297 114 634 minecraft:basalt
fill 294 107 637 301 112 637 minecraft:basalt
fill 294 107 640 301 108 640 minecraft:basalt
fill 295 107 643 301 107 643 minecraft:basalt
setblock 296 107 606 minecraft:magma_block
setblock 296 107 609 minecraft:magma_block
setblock 296 107 612 minecraft:magma_block
setblock 296 107 636 minecraft:magma_block
setblock 296 107 639 minecraft:magma_block
setblock 296 107 642 minecraft:magma_block
fill 297 107 606 304 110 606 minecraft:basalt
fill 297 107 609 303 114 609 minecraft:basalt
fill 297 107 612 297 117 612 minecraft:basalt
fill 297 107 636 300 115 636 minecraft:basalt
fill 297 107 639 304 112 639 minecraft:basalt
fill 297 107 642 304 108 642 minecraft:basalt
fill 297 107 644 298 107 644 minecraft:basalt
setblock 299 107 605 minecraft:magma_block
setblock 299 107 608 minecraft:magma_block
setblock 299 107 638 minecraft:magma_block
setblock 299 107 641 minecraft:magma_block
setblock 299 107 644 minecraft:magma_block
fill 300 107 605 307 110 605 minecraft:basalt
fill 300 107 608 307 114 608 minecraft:basalt
fill 300 107 638 307 114 638 minecraft:basalt
fill 300 107 641 307 110 641 minecraft:basalt
fill 300 107 644 304 107 645 minecraft:basalt
setblock 302 107 607 minecraft:magma_block
setblock 302 107 637 minecraft:magma_block
setblock 302 107 640 minecraft:magma_block
setblock 302 107 643 minecraft:magma_block
fill 303 107 607 310 113 607 minecraft:basalt
fill 303 107 637 303 116 637 minecraft:basalt
fill 303 107 640 310 112 640 minecraft:basalt
fill 303 107 643 310 109 643 minecraft:basalt
setblock 305 107 606 minecraft:magma_block
setblock 305 107 639 minecraft:magma_block
setblock 305 107 642 minecraft:magma_block
fill 305 107 644 307 109 644 minecraft:basalt
setblock 305 107 645 minecraft:magma_block
fill 305 107 646 305 136 646 minecraft:purple_concrete
fill 306 107 606 313 111 606 minecraft:basalt
fill 306 107 639 313 113 639 minecraft:basalt
fill 306 107 642 313 109 642 minecraft:basalt
fill 306 107 645 312 107 645 minecraft:basalt
setblock 308 107 605 minecraft:magma_block
setblock 308 107 608 minecraft:magma_block
setblock 308 107 638 minecraft:magma_block
setblock 308 107 641 minecraft:magma_block
setblock 308 107 644 minecraft:magma_block
fill 309 107 605 316 109 605 minecraft:basalt
fill 309 107 608 313 114 609 minecraft:basalt
fill 309 107 637 310 115 638 minecraft:basalt
fill 309 107 641 316 109 641 minecraft:basalt
fill 309 107 644 315 107 644 minecraft:basalt
setblock 311 107 607 minecraft:magma_block
setblock 311 107 637 minecraft:magma_block
fill 311 107 638 316 112 638 minecraft:basalt
setblock 311 107 640 minecraft:magma_block
setblock 311 107 643 minecraft:magma_block
setblock 311 107 646 minecraft:amethyst_block
fill 312 107 607 319 109 607 minecraft:basalt
fill 312 107 610 319 112 610 minecraft:basalt
fill 312 107 636 313 115 637 minecraft:basalt
fill 312 107 640 319 108 640 minecraft:basalt
fill 312 107 643 317 107 643 minecraft:basalt
setblock 314 107 606 minecraft:magma_block
fill 314 107 608 316 112 608 minecraft:basalt
setblock 314 107 609 minecraft:magma_block
fill 314 107 611 316 115 611 minecraft:basalt
fill 314 107 635 316 115 635 minecraft:basalt
setblock 314 107 636 minecraft:magma_block
fill 314 107 637 319 111 637 minecraft:basalt
setblock 314 107 639 minecraft:magma_block
setblock 314 107 642 minecraft:magma_block
fill 315 107 606 321 107 606 minecraft:basalt
fill 315 107 609 322 109 609 minecraft:basalt
fill 315 107 612 322 111 612 minecraft:basalt
fill 315 107 634 319 113 634 minecraft:basalt
fill 315 107 636 322 109 636 minecraft:basalt
fill 315 107 639 322 107 639 minecraft:basalt
fill 315 107 642 319 107 642 minecraft:basalt
setblock 317 107 605 minecraft:magma_block
setblock 317 107 608 minecraft:magma_block
setblock 317 107 611 minecraft:magma_block
fill 317 107 613 319 113 613 minecraft:basalt
setblock 317 107 614 minecraft:magma_block
setblock 317 107 632 minecraft:magma_block
fill 317 107 633 322 111 633 minecraft:basalt
setblock 317 107 635 minecraft:magma_block
setblock 317 107 638 minecraft:magma_block
setblock 317 107 641 minecraft:magma_block
fill 318 107 605 320 107 605 minecraft:basalt
fill 318 107 608 323 107 608 minecraft:basalt
fill 318 107 611 323 109 611 minecraft:basalt
fill 318 107 614 322 112 615 minecraft:basalt
fill 318 107 631 319 115 632 minecraft:basalt
fill 318 107 635 323 109 635 minecraft:basalt
fill 318 107 638 323 107 638 minecraft:basalt
fill 318 107 641 320 107 641 minecraft:basalt
fill 319 107 616 319 116 617 minecraft:basalt
fill 319 107 629 322 113 630 minecraft:basalt
setblock 320 107 607 minecraft:magma_block
setblock 320 107 610 minecraft:magma_block
setblock 320 107 613 minecraft:magma_block
setblock 320 107 616 minecraft:magma_block
fill 320 107 617 322 113 618 minecraft:basalt
setblock 320 107 619 minecraft:magma_block
fill 320 107 620 323 113 620 minecraft:basalt
fill 320 107 626 322 113 627 minecraft:basalt
setblock 320 107 628 minecraft:magma_block
setblock 320 107 631 minecraft:magma_block
fill 320 107 632 323 111 632 minecraft:basalt
setblock 320 107 634 minecraft:magma_block
setblock 320 107 637 minecraft:magma_block
setblock 320 107 640 minecraft:magma_block
fill 321 107 607 322 107 607 minecraft:basalt
fill 321 107 610 323 108 610 minecraft:basalt
fill 321 107 613 323 110 613 minecraft:basalt
fill 321 107 616 323 112 616 minecraft:basalt
fill 321 107 619 323 112 619 minecraft:basalt
fill 321 107 621 322 113 625 minecraft:basalt
fill 321 107 628 323 112 628 minecraft:basalt
fill 321 107 631 323 111 631 minecraft:basalt
fill 321 107 634 323 110 634 minecraft:basalt
fill 321 107 637 323 108 637 minecraft:basalt
setblock 321 107 640 minecraft:basalt
setblock 323 107 609 minecraft:magma_block
setblock 323 107 612 minecraft:magma_block
fill 323 107 614 323 111 614 minecraft:basalt
setblock 323 107 615 minecraft:magma_block
fill 323 107 617 323 112 617 minecraft:basalt
setblock 323 107 618 minecraft:magma_block
setblock 323 107 621 minecraft:magma_block
fill 323 107 622 323 112 623 minecraft:basalt
setblock 323 107 624 minecraft:magma_block
fill 323 107 625 323 112 626 minecraft:basalt
setblock 323 107 627 minecraft:magma_block
fill 323 107 629 323 112 629 minecraft:basalt
setblock 323 107 630 minecraft:magma_block
setblock 323 107 633 minecraft:magma_block
setblock 323 107 636 minecraft:magma_block
setblock 324 107 624 minecraft:amethyst_block
fill 324 107 625 324 123 626 minecraft:purple_concrete
setblock 282 108 616 minecraft:amethyst_block
fill 282 108 617 282 127 617 minecraft:purple_concrete
setblock 282 108 625 minecraft:amethyst_block
fill 282 108 626 282 116 627 minecraft:purple_concrete
fill 284 108 621 284 108 622 minecraft:basalt
setblock 284 108 625 minecraft:basalt
fill 285 108 616 286 108 618 minecraft:basalt
fill 285 108 620 286 109 621 minecraft:basalt
fill 285 108 626 286 108 627 minecraft:basalt
fill 285 108 629 287 108 630 minecraft:basalt
setblock 286 108 614 minecraft:magma_block
fill 286 108 615 287 108 615 minecraft:basalt
setblock 286 108 631 minecraft:basalt
setblock 286 108 632 minecraft:magma_block
setblock 287 108 612 minecraft:basalt
fill 287 108 618 287 110 618 minecraft:basalt
fill 287 108 621 287 111 621 minecraft:basalt
fill 287 108 624 287 111 624 minecraft:basalt
fill 287 108 627 287 111 627 minecraft:basalt
fill 287 108 633 287 108 634 minecraft:basalt
fill 288 108 611 290 108 611 minecraft:basalt
fill 288 108 629 290 111 629 minecraft:basalt
fill 288 108 634 289 108 635 minecraft:basalt
fill 289 108 609 296 108 609 minecraft:basalt
setblock 289 108 610 minecraft:magma_block
fill 289 108 636 292 108 636 minecraft:basalt
setblock 289 108 637 minecraft:magma_block
setblock 290 108 608 minecraft:basalt
fill 290 108 614 294 112 614 minecraft:basalt
fill 290 108 617 290 113 617 minecraft:basalt
fill 290 108 620 290 114 620 minecraft:basalt
fill 290 108 623 290 115 623 minecraft:basalt
fill 290 108 626 290 114 626 minecraft:basalt
fill 290 108 632 294 112 632 minecraft:basalt
fill 290 108 635 290 110 635 minecraft:basalt
fill 290 108 637 290 108 638 minecraft:basalt
fill 291 108 607 293 108 607 minecraft:basalt
fill 291 108 637 293 109 637 minecraft:basalt
fill 291 108 639 296 108 639 minecraft:basalt
setblock 292 108 606 minecraft:magma_block
setblock 292 108 621 minecraft:magma_block
fill 292 108 622 292 117 623 minecraft:basalt
setblock 292 108 624 minecraft:magma_block
fill 292 108 625 292 117 625 minecraft:basalt
fill 292 108 640 293 108 640 minecraft:basalt
fill 293 108 606 296 108 606 minecraft:basalt
fill 293 108 610 293 112 610 minecraft:basalt
fill 293 108 613 293 114 613 minecraft:basalt
fill 293 108 616 294 115 616 minecraft:basalt
fill 293 108 618 293 117 619 minecraft:basalt
fill 293 108 627 293 117 628 minecraft:basalt
fill 293 108 631 293 115 631 minecraft:basalt
fill 293 108 634 293 113 634 minecraft:basalt
fill 294 108 605 299 108 605 minecraft:basalt
fill 294 108 630 294 117 630 minecraft:basalt
fill 294 108 641 299 108 641 minecraft:basalt
setblock 295 108 614 minecraft:magma_block
fill 295 108 615 295 117 615 minecraft:basalt
fill 295 108 631 295 117 631 minecraft:basalt
setblock 295 108 632 minecraft:magma_block
fill 295 108 642 296 108 642 minecraft:basalt
fill 296 108 612 296 115 613 minecraft:basalt
fill 296 108 633 296 117 633 minecraft:basalt
fill 296 108 636 296 114 636 minecraft:basalt
setblock 297 108 643 minecraft:basalt
fill 298 108 612 298 117 612 minecraft:basalt
setblock 298 108 634 minecraft:magma_block
setblock 298 108 643 minecraft:magma_block
fill 299 108 608 299 114 608 minecraft:basalt
fill 299 108 611 299 117 611 minecraft:basalt
fill 299 108 635 299 117 635 minecraft:basalt
fill 299 108 638 299 114 638 minecraft:basalt
fill 299 108 643 302 108 644 minecraft:basalt
fill 301 108 610 302 117 610 minecraft:basalt
setblock 301 108 636 minecraft:magma_block
fill 302 108 607 302 114 607 minecraft:basalt
fill 302 108 636 302 115 637 minecraft:basalt
fill 302 108 640 302 113 640 minecraft:basalt
fill 303 108 644 304 109 644 minecraft:basalt
fill 304 108 609 308 117 609 minecraft:basalt
fill 304 108 637 306 117 637 minecraft:basalt
fill 304 108 645 308 108 645 minecraft:basalt
fill 305 108 606 305 113 606 minecraft:basalt
fill 305 108 639 305 115 639 minecraft:basalt
fill 305 108 642 305 111 642 minecraft:basalt
setblock 307 108 637 minecraft:magma_block
fill 308 108 605 308 112 605 minecraft:basalt
fill 308 108 608 308 115 608 minecraft:basalt
fill 308 108 637 308 115 638 minecraft:basalt
fill 308 108 641 308 112 641 minecraft:basalt
fill 308 108 644 312 108 644 minecraft:basalt
fill 310 108 610 311 117 610 minecraft:basalt
setblock 310 108 636 minecraft:magma_block
fill 311 108 607 311 114 607 minecraft:basalt
fill 311 108 636 311 115 637 minecraft:basalt
fill 311 108 640 311 113 640 minecraft:basalt
fill 311 108 643 315 108 643 minecraft:basalt
fill 311 108 646 311 147 646 minecraft:purple_concrete
setblock 313 108 611 minecraft:magma_block
setblock 313 108 635 minecraft:magma_block
setblock 313 108 644 minecraft:magma_block
fill 314 108 606 318 109 606 minecraft:basalt
fill 314 108 609 314 114 609 minecraft:basalt
fill 314 108 612 314 117 612 minecraft:basalt
fill 314 108 634 314 117 634 minecraft:basalt
fill 314 108 636 314 115 636 minecraft:basalt
fill 314 108 639 321 108 639 minecraft:basalt
fill 314 108 642 317 108 642 minecraft:basalt
setblock 316 108 613 minecraft:magma_block
fill 316 108 633 316 117 633 minecraft:basalt
fill 317 108 605 318 108 605 minecraft:basalt
fill 317 108 608 321 109 608 minecraft:basalt
fill 317 108 611 317 114 611 minecraft:basalt
fill 317 108 614 317 117 615 minecraft:basalt
fill 317 108 631 317 117 632 minecraft:basalt
fill 317 108 635 317 114 635 minecraft:basalt
fill 317 108 638 321 109 638 minecraft:basalt
fill 317 108 641 318 108 641 minecraft:basalt
fill 318 108 616 318 117 616 minecraft:basalt
fill 318 108 630 318 117 630 minecraft:basalt
setblock 319 108 606 minecraft:magma_block
setblock 319 108 618 minecraft:magma_block
fill 319 108 619 320 115 619 minecraft:basalt
setblock 319 108 627 minecraft:magma_block
fill 319 108 628 320 115 628 minecraft:basalt
fill 320 108 606 320 108 607 minecraft:basalt
fill 320 108 610 320 111 610 minecraft:basalt
fill 320 108 613 320 113 613 minecraft:basalt
fill 320 108 616 320 115 616 minecraft:basalt
fill 320 108 621 320 117 625 minecraft:basalt
fill 320 108 631 320 114 631 minecraft:basalt
fill 320 108 634 320 113 634 minecraft:basalt
fill 320 108 637 320 110 637 minecraft:basalt
setblock 320 108 640 minecraft:basalt
setblock 321 108 607 minecraft:basalt
setblock 322 108 608 minecraft:magma_block
setblock 322 108 638 minecraft:magma_block
setblock 323 108 609 minecraft:basalt
fill 323 108 612 323 110 612 minecraft:basalt
fill 323 108 615 323 111 615 minecraft:basalt
fill 323 108 618 323 113 618 minecraft:basalt
fill 323 108 621 323 113 621 minecraft:basalt
fill 323 108 624 323 113 624 minecraft:basalt
fill 323 108 627 323 113 627 minecraft:basalt
fill 323 108 630 323 112 630 minecraft:basalt
fill 323 108 633 323 110 633 minecraft:basalt
setblock 323 108 636 minecraft:basalt
setblock 324 108 609 minecraft:amethyst_block
fill 324 108 624 324 163 624 minecraft:purple_concrete
fill 282 109 616 282 164 616 minecraft:purple_concrete
fill 282 109 625 282 163 625 minecraft:purple_concrete
setblock 285 109 622 minecraft:magma_block
fill 285 109 623 286 109 624 minecraft:basalt
setblock 285 109 625 minecraft:magma_block
fill 285 109 626 286 109 626 minecraft:basalt
fill 286 109 616 286 109 619 minecraft:basalt
fill 286 109 622 291 110 622 minecraft:basalt
fill 286 109 625 291 110 625 minecraft:basalt
fill 286 109 627 286 109 630 minecraft:basalt
fill 287 109 614 287 109 615 minecraft:basalt
fill 287 109 619 292 111 619 minecraft:basalt
fill 287 109 628 287 109 630 minecraft:basalt
setblock 288 109 612 minecraft:magma_block
fill 288 109 613 289 109 614 minecraft:basalt
fill 288 109 628 292 112 628 minecraft:basalt
setblock 288 109 633 minecraft:magma_block
fill 288 109 634 289 109 634 minecraft:basalt
fill 289 109 611 290 109 612 minecraft:basalt
fill 289 109 633 295 110 633 minecraft:basalt
setblock 289 109 635 minecraft:basalt
fill 290 109 609 296 109 609 minecraft:basalt
fill 290 109 636 290 109 637 minecraft:basalt
setblock 291 109 608 minecraft:magma_block
fill 291 109 612 295 112 612 minecraft:basalt
fill 291 109 636 292 110 636 minecraft:basalt
setblock 291 109 638 minecraft:magma_block
fill 292 109 607 293 109 608 minecraft:basalt
fill 292 109 621 293 109 621 minecraft:basalt
fill 292 109 624 293 109 624 minecraft:basalt
fill 292 109 638 296 109 639 minecraft:basalt
fill 293 109 620 293 118 620 minecraft:basalt
fill 293 109 622 293 118 623 minecraft:basalt
fill 293 109 625 293 118 626 minecraft:basalt
fill 294 109 606 296 109 606 minecraft:basalt
fill 294 109 608 298 111 608 minecraft:basalt
fill 294 109 617 294 118 618 minecraft:basalt
setblock 294 109 628 minecraft:magma_block
fill 294 109 629 294 118 629 minecraft:basalt
setblock 294 109 640 minecraft:magma_block
fill 295 109 605 299 109 605 minecraft:basalt
fill 295 109 614 296 116 614 minecraft:basalt
fill 295 109 616 295 118 616 minecraft:basalt
fill 295 109 630 295 118 630 minecraft:basalt
fill 295 109 632 296 116 632 minecraft:basalt
fill 295 109 640 299 109 641 minecraft:basalt
fill 297 109 613 297 117 613 minecraft:basalt
setblock 297 109 633 minecraft:magma_block
fill 297 109 638 298 113 638 minecraft:basalt
setblock 297 109 642 minecraft:magma_block
fill 298 109 634 299 109 634 minecraft:basalt
fill 298 109 642 304 109 642 minecraft:basalt
fill 299 109 612 299 118 612 minecraft:basalt
fill 299 109 643 302 109 643 minecraft:basalt
setblock 300 109 611 minecraft:magma_block
setblock 300 109 635 minecraft:magma_block
fill 300 109 640 301 111 640 minecraft:basalt
fill 301 109 611 301 118 611 minecraft:basalt
fill 301 109 635 301 116 636 minecraft:basalt
setblock 301 109 646 minecraft:amethyst_block
setblock 303 109 610 minecraft:magma_block
fill 303 109 636 305 118 636 minecraft:basalt
fill 304 109 610 309 109 610 minecraft:basalt
setblock 306 109 636 minecraft:magma_block
fill 307 109 636 307 116 637 minecraft:basalt
fill 308 109 636 310 116 636 minecraft:basalt
setblock 308 109 644 minecraft:basalt
setblock 309 109 644 minecraft:magma_block
fill 311 109 611 313 116 611 minecraft:basalt
fill 311 109 635 313 116 635 minecraft:basalt
setblock 311 109 643 minecraft:basalt
fill 312 109 640 318 109 640 minecraft:basalt
setblock 312 109 643 minecraft:magma_block
fill 313 109 612 313 118 612 minecraft:basalt
fill 313 109 634 313 118 634 minecraft:basalt
setblock 313 109 643 minecraft:basalt
fill 314 109 639 320 109 639 minecraft:basalt
setblock 314 109 642 minecraft:basalt
fill 315 109 613 316 116 613 minecraft:basalt
setblock 315 109 633 minecraft:magma_block
setblock 315 109 642 minecraft:magma_block
fill 316 109 614 316 117 614 minecraft:basalt
fill 316 109 632 316 117 632 minecraft:basalt
setblock 317 109 605 minecraft:basalt
setblock 317 109 616 minecraft:basalt
fill 317 109 630 317 118 630 minecraft:basalt
setblock 317 109 641 minecraft:basalt
setblock 318 109 617 minecraft:magma_block
fill 318 109 618 319 116 618 minecraft:basalt
fill 318 109 628 318 118 628 minecraft:basalt
setblock 318 109 629 minecraft:magma_block
fill 319 109 620 319 116 627 minecraft:basalt
setblock 320 109 607 minecraft:basalt
fill 321 109 610 322 109 610 minecraft:basalt
setblock 321 109 637 minecraft:magma_block
setblock 322 109 637 minecraft:basalt
fill 324 109 609 324 121 609 minecraft:purple_concrete
setblock 282 110 612 minecraft:gold_block
setblock 282 110 628 minecraft:gold_block
fill 282 110 642 282 147 643 minecraft:purple_concrete
setblock 282 110 644 minecraft:gold_block
setblock 285 110 607 minecraft:light[level=13]
setblock 285 110 615 minecraft:light[level=13]
setblock 285 110 623 minecraft:light[level=13]
fill 285 110 626 285 111 628 minecraft:black_concrete
setblock 285 110 631 minecraft:light[level=13]
setblock 285 110 639 minecraft:light[level=13]
setblock 286 110 604 minecraft:gold_block
fill 286 110 619 286 110 621 minecraft:basalt
fill 286 110 623 286 110 624 minecraft:basalt
fill 286 110 626 286 110 627 minecraft:basalt
fill 286 110 628 286 111 629 minecraft:black_concrete
fill 287 110 616 289 110 616 minecraft:basalt
setblock 287 110 617 minecraft:magma_block
setblock 287 110 628 minecraft:basalt
setblock 287 110 629 minecraft:magma_block
setblock 287 110 630 minecraft:basalt
fill 288 110 614 289 110 614 minecraft:basalt
fill 288 110 617 289 111 617 minecraft:basalt
fill 288 110 631 289 110 632 minecraft:basalt
fill 289 110 612 289 110 613 minecraft:basalt
setblock 289 110 634 minecraft:basalt
fill 290 110 611 290 110 612 minecraft:basalt
fill 291 110 610 292 110 610 minecraft:basalt
fill 292 110 609 296 110 609 minecraft:basalt
fill 292 110 621 292 116 621 minecraft:basalt
fill 292 110 624 292 116 624 minecraft:basalt
fill 292 110 637 293 110 637 minecraft:basalt
setblock 293 110 607 minecraft:light[level=13]
setblock 293 110 608 minecraft:basalt
setblock 293 110 621 minecraft:magma_block
setblock 293 110 624 minecraft:magma_block
fill 293 110 638 296 110 638 minecraft:basalt
setblock 293 110 639 minecraft:light[level=13]
fill 294 110 619 294 117 620 minecraft:basalt
fill 294 110 626 294 117 628 minecraft:basalt
fill 294 110 639 296 110 639 minecraft:basalt
fill 295 110 606 296 110 606 minecraft:basalt
fill 295 110 617 295 119 617 minecraft:basalt
fill 295 110 629 295 119 629 minecraft:basalt
fill 295 110 640 299 110 640 minecraft:basalt
fill 295 110 646 295 159 646 minecraft:purple_concrete
fill 296 110 615 296 118 615 minecraft:basalt
fill 296 110 631 296 118 631 minecraft:basalt
setblock 296 110 646 minecraft:gold_block
fill 297 110 605 299 110 605 minecraft:basalt
fill 297 110 614 297 118 614 minecraft:basalt
fill 297 110 632 297 117 633 minecraft:basalt
fill 297 110 641 299 110 641 minecraft:basalt
fill 297 110 646 301 126 646 minecraft:purple_concrete
fill 298 110 613 298 118 613 minecraft:basalt
fill 298 110 633 298 116 634 minecraft:basalt
setblock 299 110 634 minecraft:magma_block
fill 299 110 642 304 110 642 minecraft:basalt
fill 300 110 611 300 117 612 minecraft:basalt
fill 300 110 634 300 117 635 minecraft:basalt
setblock 301 110 615 minecraft:light[level=13]
setblock 301 110 623 minecraft:light[level=13]
setblock 301 110 631 minecraft:light[level=13]
setblock 302 110 604 minecraft:gold_block
fill 302 110 611 303 118 611 minecraft:basalt
fill 302 110 635 303 118 635 minecraft:basalt
fill 302 110 643 307 110 643 minecraft:basalt
fill 303 110 610 307 117 610 minecraft:basalt
fill 306 110 604 308 130 604 minecraft:purple_concrete
fill 306 110 636 306 117 636 minecraft:basalt
fill 306 110 642 310 110 642 minecraft:basalt
setblock 308 110 610 minecraft:magma_block
setblock 308 110 643 minecraft:magma_block
setblock 309 110 604 minecraft:white_concrete
fill 309 110 605 313 111 605 minecraft:basalt
fill 309 110 610 309 118 611 minecraft:basalt
setblock 309 110 615 minecraft:light[level=13]
setblock 309 110 623 minecraft:light[level=13]
setblock 309 110 631 minecraft:light[level=13]
fill 309 110 635 310 118 635 minecraft:basalt
fill 309 110 641 313 111 641 minecraft:basalt
fill 309 110 643 310 110 643 minecraft:basalt
fill 310 110 604 310 151 604 minecraft:purple_concrete
fill 310 110 611 310 118 611 minecraft:basalt
setblock 311 110 642 minecraft:magma_block
fill 312 110 604 312 116 604 minecraft:purple_concrete
fill 312 110 607 318 110 607 minecraft:basalt
fill 312 110 612 312 119 612 minecraft:basalt
fill 312 110 634 312 119 634 minecraft:basalt
fill 312 110 640 316 110 640 minecraft:basalt
fill 312 110 642 313 110 642 minecraft:basalt
setblock 312 110 646 minecraft:gold_block
setblock 313 110 604 minecraft:amethyst_block
setblock 314 110 605 minecraft:magma_block
fill 314 110 606 317 110 606 minecraft:basalt
fill 314 110 613 314 118 613 minecraft:basalt
fill 314 110 633 315 117 633 minecraft:basalt
fill 314 110 639 318 110 639 minecraft:basalt
setblock 314 110 641 minecraft:magma_block
setblock 315 110 605 minecraft:basalt
fill 315 110 609 319 111 609 minecraft:basalt
fill 315 110 614 315 118 614 minecraft:basalt
fill 315 110 632 315 118 632 minecraft:basalt
fill 315 110 636 321 110 636 minecraft:basalt
setblock 315 110 641 minecraft:basalt
fill 316 110 615 316 118 615 minecraft:basalt
fill 316 110 631 316 118 631 minecraft:basalt
fill 317 110 604 317 163 604 minecraft:purple_concrete
fill 317 110 608 319 110 608 minecraft:basalt
setblock 317 110 616 minecraft:magma_block
fill 317 110 617 318 117 617 minecraft:basalt
setblock 317 110 623 minecraft:light[level=13]
fill 317 110 629 318 117 629 minecraft:basalt
fill 317 110 638 319 110 638 minecraft:basalt
setblock 317 110 640 minecraft:magma_block
setblock 318 110 604 minecraft:gold_block
fill 318 110 611 322 110 611 minecraft:basalt
fill 318 110 619 318 118 620 minecraft:basalt
fill 318 110 626 318 118 627 minecraft:basalt
fill 318 110 635 322 110 635 minecraft:basalt
fill 319 110 604 320 125 604 minecraft:purple_concrete
setblock 320 110 609 minecraft:magma_block
setblock 321 110 610 minecraft:basalt
setblock 324 110 614 minecraft:gold_block
fill 324 110 615 324 163 615 minecraft:purple_concrete
fill 324 110 628 324 139 629 minecraft:purple_concrete
setblock 324 110 630 minecraft:gold_block
fill 282 111 612 282 117 612 minecraft:purple_concrete
fill 282 111 628 282 117 628 minecraft:purple_concrete
setblock 282 111 630 minecraft:pearlescent_froglight
fill 282 111 644 282 117 644 minecraft:purple_concrete
fill 284 111 626 284 111 627 minecraft:black_concrete
fill 285 111 625 286 111 625 minecraft:black_concrete
setblock 285 111 629 minecraft:black_concrete
fill 286 111 604 286 117 604 minecraft:purple_concrete
setblock 286 111 624 minecraft:black_concrete
fill 286 111 626 286 111 627 minecraft:black_concrete
fill 287 111 622 291 111 622 minecraft:basalt
fill 287 111 625 291 111 625 minecraft:basalt
fill 287 111 628 287 111 629 minecraft:black_concrete
fill 288 111 616 289 111 616 minecraft:basalt
setblock 289 111 614 minecraft:basalt
setblock 289 111 615 minecraft:magma_block
fill 289 111 631 289 111 632 minecraft:basalt
setblock 290 111 612 minecraft:basalt
fill 290 111 615 294 112 615 minecraft:basalt
fill 290 111 633 295 111 633 minecraft:basalt
setblock 292 111 610 minecraft:basalt
setblock 292 111 636 minecraft:basalt
fill 293 111 609 296 111 609 minecraft:basalt
fill 293 111 621 294 118 621 minecraft:basalt
fill 293 111 624 294 111 624 minecraft:basalt
setblock 293 111 637 minecraft:basalt
fill 294 111 622 294 119 623 minecraft:basalt
fill 294 111 625 294 119 625 minecraft:basalt
fill 294 111 638 296 111 638 minecraft:basalt
setblock 295 111 607 minecraft:magma_block
fill 295 111 618 295 119 618 minecraft:basalt
setblock 295 111 619 minecraft:magma_block
fill 295 111 627 295 119 627 minecraft:basalt
setblock 295 111 628 minecraft:magma_block
fill 295 111 639 296 111 639 minecraft:basalt
fill 296 111 607 301 111 607 minecraft:basalt
fill 296 111 616 296 119 616 minecraft:basalt
fill 296 111 630 296 119 630 minecraft:basalt
fill 296 111 646 296 117 646 minecraft:purple_concrete
setblock 297 111 606 minecraft:basalt
fill 297 111 615 297 119 615 minecraft:basalt
fill 297 111 631 297 119 631 minecraft:basalt
fill 297 111 640 299 111 640 minecraft:basalt
setblock 298 111 606 minecraft:magma_block
fill 298 111 614 298 119 614 minecraft:basalt
fill 298 111 632 298 119 632 minecraft:basalt
fill 299 111 605 300 111 606 minecraft:basalt
fill 299 111 613 299 118 613 minecraft:basalt
fill 299 111 633 299 118 634 minecraft:basalt
fill 299 111 641 300 111 641 minecraft:basalt
setblock 301 111 605 minecraft:magma_block
fill 301 111 606 304 113 606 minecraft:basalt
fill 301 111 612 302 118 612 minecraft:basalt
fill 301 111 634 302 119 634 minecraft:basalt
setblock 301 111 641 minecraft:magma_block
fill 302 111 604 302 117 604 minecraft:purple_concrete
fill 302 111 605 307 111 605 minecraft:basalt
fill 302 111 641 304 111 642 minecraft:basalt
fill 304 111 611 308 111 611 minecraft:basalt
fill 304 111 635 308 111 635 minecraft:basalt
fill 305 111 641 307 111 641 minecraft:basalt
setblock 306 111 642 minecraft:basalt
setblock 307 111 642 minecraft:magma_block
fill 308 111 610 308 118 610 minecraft:basalt
fill 308 111 642 310 111 642 minecraft:basalt
fill 309 111 604 309 142 604 minecraft:purple_concrete
fill 310 111 612 311 118 612 minecraft:basalt
fill 310 111 634 311 119 634 minecraft:basalt
fill 312 111 607 317 111 607 minecraft:basalt
fill 312 111 640 315 111 640 minecraft:basalt
fill 312 111 646 312 117 646 minecraft:purple_concrete
fill 313 111 604 313 112 604 minecraft:purple_concrete
setblock 313 111 613 minecraft:magma_block
fill 313 111 633 313 119 633 minecraft:basalt
fill 314 111 606 315 111 606 minecraft:basalt
fill 314 111 614 314 118 614 minecraft:basalt
fill 314 111 632 314 118 632 minecraft:basalt
fill 314 111 639 315 112 639 minecraft:basalt
fill 315 111 615 315 119 615 minecraft:basalt
fill 315 111 631 315 119 631 minecraft:basalt
fill 315 111 636 320 111 636 minecraft:basalt
fill 316 111 616 317 118 616 minecraft:basalt
setblock 316 111 630 minecraft:magma_block
setblock 316 111 639 minecraft:magma_block
fill 317 111 608 318 111 608 minecraft:basalt
fill 317 111 618 317 118 619 minecraft:basalt
fill 317 111 627 317 118 628 minecraft:basalt
fill 317 111 638 317 111 639 minecraft:basalt
fill 318 111 604 318 117 604 minecraft:purple_concrete
fill 318 111 611 321 111 611 minecraft:basalt
fill 318 111 621 318 111 625 minecraft:basalt
fill 318 111 635 321 111 635 minecraft:basalt
setblock 318 111 638 minecraft:basalt
fill 321 111 613 321 112 613 minecraft:basalt
fill 321 111 634 321 112 634 minecraft:basalt
setblock 322 111 613 minecraft:magma_block
setblock 322 111 634 minecraft:magma_block
fill 324 111 614 324 117 614 minecraft:purple_concrete
fill 324 111 630 324 117 630 minecraft:purple_concrete
fill 282 112 630 282 127 630 minecraft:purple_concrete
fill 284 112 626 285 113 627 minecraft:end_stone
fill 286 112 626 287 112 627 minecraft:amethyst_block
setblock 287 112 628 minecraft:amethyst_block
fill 288 112 619 292 112 619 minecraft:basalt
setblock 288 112 620 minecraft:magma_block
fill 288 112 622 291 112 622 minecraft:basalt
setblock 288 112 623 minecraft:magma_block
fill 288 112 625 291 112 625 minecraft:basalt
setblock 288 112 626 minecraft:magma_block
fill 289 112 616 289 112 617 minecraft:basalt
fill 289 112 620 289 113 620 minecraft:basalt
fill 289 112 623 289 113 623 minecraft:basalt
fill 289 112 626 289 113 626 minecraft:basalt
fill 289 112 629 290 112 630 minecraft:basalt
setblock 291 112 613 minecraft:magma_block
fill 291 112 630 293 114 630 minecraft:basalt
fill 291 112 633 295 112 633 minecraft:basalt
setblock 291 112 634 minecraft:magma_block
fill 292 112 611 298 112 611 minecraft:basalt
fill 292 112 613 292 113 613 minecraft:basalt
fill 292 112 634 292 112 635 minecraft:basalt
fill 293 112 624 293 118 624 minecraft:basalt
fill 293 112 635 298 112 635 minecraft:basalt
setblock 294 112 609 minecraft:magma_block
setblock 294 112 624 minecraft:magma_block
fill 295 112 608 296 112 609 minecraft:basalt
fill 295 112 619 295 119 621 minecraft:basalt
fill 295 112 625 295 119 626 minecraft:basalt
fill 295 112 628 296 112 628 minecraft:basalt
fill 295 112 638 296 112 638 minecraft:basalt
fill 296 112 617 296 120 618 minecraft:basalt
fill 296 112 629 296 120 629 minecraft:basalt
fill 297 112 607 298 112 608 minecraft:basalt
fill 297 112 616 297 120 616 minecraft:basalt
fill 297 112 630 297 120 630 minecraft:basalt
fill 298 112 615 298 119 615 minecraft:basalt
fill 298 112 631 298 120 631 minecraft:basalt
fill 299 112 606 300 112 607 minecraft:basalt
fill 299 112 614 299 120 614 minecraft:basalt
fill 299 112 632 299 120 632 minecraft:basalt
setblock 299 112 640 minecraft:basalt
setblock 300 112 613 minecraft:magma_block
fill 300 112 633 301 120 633 minecraft:basalt
setblock 300 112 640 minecraft:magma_block
fill 301 112 605 305 112 605 minecraft:basalt
fill 301 112 607 301 113 607 minecraft:basalt
fill 301 112 613 301 120 613 minecraft:basalt
fill 301 112 640 301 112 641 minecraft:basalt
fill 302 112 641 305 112 641 minecraft:basalt
setblock 303 112 612 minecraft:magma_block
fill 303 112 634 304 119 634 minecraft:basalt
fill 304 112 611 304 119 612 minecraft:basalt
fill 304 112 635 305 118 635 minecraft:basalt
fill 305 112 611 305 118 611 minecraft:basalt
setblock 306 112 605 minecraft:magma_block
fill 306 112 606 311 112 606 minecraft:basalt
setblock 306 112 611 minecraft:magma_block
setblock 306 112 635 minecraft:magma_block
setblock 306 112 641 minecraft:magma_block
setblock 307 112 605 minecraft:basalt
fill 307 112 611 308 119 611 minecraft:basalt
fill 307 112 635 308 119 635 minecraft:basalt
setblock 307 112 641 minecraft:basalt
fill 308 112 612 309 112 612 minecraft:basalt
fill 308 112 634 308 120 634 minecraft:basalt
fill 309 112 605 311 112 605 minecraft:basalt
setblock 309 112 634 minecraft:magma_block
fill 309 112 641 311 112 641 minecraft:basalt
fill 311 112 613 313 119 613 minecraft:basalt
fill 311 112 633 311 120 633 minecraft:basalt
setblock 312 112 606 minecraft:magma_block
fill 312 112 607 315 112 607 minecraft:basalt
setblock 312 112 633 minecraft:magma_block
fill 312 112 640 313 112 640 minecraft:basalt
setblock 313 112 606 minecraft:basalt
fill 313 112 614 313 120 614 minecraft:basalt
fill 313 112 632 313 120 632 minecraft:basalt
fill 314 112 604 314 128 604 minecraft:purple_concrete
fill 314 112 615 314 120 615 minecraft:basalt
fill 314 112 631 314 120 631 minecraft:basalt
fill 314 112 637 317 113 637 minecraft:basalt
setblock 315 112 604 minecraft:white_concrete
fill 315 112 609 318 112 609 minecraft:basalt
fill 315 112 612 320 113 612 minecraft:basalt
fill 315 112 616 315 120 616 minecraft:basalt
fill 315 112 630 316 119 630 minecraft:basalt
fill 315 112 636 319 112 636 minecraft:basalt
fill 316 112 604 316 150 604 minecraft:purple_concrete
fill 316 112 617 316 119 618 minecraft:basalt
fill 316 112 628 316 120 629 minecraft:basalt
setblock 317 112 608 minecraft:basalt
fill 317 112 620 317 112 621 minecraft:basalt
fill 317 112 625 317 120 626 minecraft:basalt
fill 317 112 633 320 113 633 minecraft:basalt
setblock 317 112 638 minecraft:basalt
fill 318 112 611 320 112 611 minecraft:basalt
fill 318 112 621 318 119 621 minecraft:basalt
setblock 318 112 622 minecraft:magma_block
fill 318 112 623 318 119 625 minecraft:basalt
fill 318 112 635 320 112 635 minecraft:basalt
setblock 318 112 637 minecraft:magma_block
fill 320 112 632 322 112 632 minecraft:basalt
setblock 321 112 612 minecraft:magma_block
fill 321 112 631 322 112 631 minecraft:basalt
setblock 321 112 633 minecraft:magma_block
setblock 282 113 614 minecraft:pearlescent_froglight
fill 282 113 618 282 143 618 minecraft:purple_concrete
setblock 282 113 619 minecraft:white_concrete
fill 286 113 627 287 113 627 minecraft:amethyst_block
fill 287 113 626 287 114 626 minecraft:amethyst_block
fill 289 113 618 292 113 619 minecraft:basalt
fill 289 113 621 291 113 622 minecraft:basalt
fill 289 113 624 291 113 625 minecraft:basalt
fill 289 113 627 292 113 628 minecraft:basalt
setblock 290 113 629 minecraft:basalt
setblock 290 113 630 minecraft:magma_block
fill 291 113 614 294 113 615 minecraft:basalt
fill 291 113 631 292 113 632 minecraft:basalt
fill 292 113 612 295 113 612 minecraft:basalt
fill 292 113 633 292 113 634 minecraft:basalt
setblock 293 113 611 minecraft:magma_block
fill 293 113 632 294 114 633 minecraft:basalt
setblock 293 113 635 minecraft:magma_block
fill 294 113 611 298 113 611 minecraft:basalt
fill 294 113 624 295 119 624 minecraft:basalt
fill 294 113 635 295 113 636 minecraft:basalt
fill 295 113 609 296 113 609 minecraft:basalt
fill 295 113 622 295 119 623 minecraft:basalt
fill 295 113 628 295 119 628 minecraft:basalt
fill 295 113 633 295 116 633 minecraft:basalt
setblock 295 113 637 minecraft:basalt
setblock 296 113 619 minecraft:magma_block
fill 296 113 620 296 121 620 minecraft:basalt
fill 296 113 626 296 121 627 minecraft:basalt
setblock 296 113 628 minecraft:magma_block
fill 296 113 635 298 115 635 minecraft:basalt
setblock 296 113 637 minecraft:magma_block
fill 297 113 608 298 113 608 minecraft:basalt
fill 297 113 617 297 120 617 minecraft:basalt
fill 297 113 629 297 120 629 minecraft:basalt
fill 297 113 637 301 114 637 minecraft:basalt
fill 298 113 616 298 121 616 minecraft:basalt
fill 298 113 630 298 121 630 minecraft:basalt
fill 299 113 607 300 113 607 minecraft:basalt
setblock 299 113 615 minecraft:magma_block
fill 299 113 631 299 121 631 minecraft:basalt
setblock 299 113 639 minecraft:magma_block
fill 300 113 613 300 120 614 minecraft:basalt
fill 300 113 632 300 120 632 minecraft:basalt
fill 300 113 639 304 113 639 minecraft:basalt
setblock 301 113 640 minecraft:basalt
fill 302 113 613 303 121 613 minecraft:basalt
fill 302 113 633 303 120 633 minecraft:basalt
fill 303 113 612 303 120 612 minecraft:basalt
fill 303 113 640 304 113 640 minecraft:basalt
fill 305 113 612 307 119 612 minecraft:basalt
setblock 305 113 634 minecraft:magma_block
setblock 305 113 640 minecraft:magma_block
fill 306 113 606 307 113 606 minecraft:basalt
fill 306 113 611 306 119 611 minecraft:basalt
fill 306 113 634 306 119 635 minecraft:basalt
fill 306 113 640 310 113 640 minecraft:basalt
fill 307 113 634 307 120 634 minecraft:basalt
setblock 308 113 606 minecraft:magma_block
setblock 308 113 612 minecraft:magma_block
fill 309 113 606 311 113 606 minecraft:basalt
fill 309 113 612 309 120 613 minecraft:basalt
fill 309 113 633 309 120 634 minecraft:basalt
fill 310 113 613 310 121 613 minecraft:basalt
fill 310 113 633 310 121 633 minecraft:basalt
fill 311 113 638 315 113 638 minecraft:basalt
fill 312 113 607 313 113 607 minecraft:basalt
fill 312 113 610 318 113 610 minecraft:basalt
fill 312 113 614 312 120 614 minecraft:basalt
fill 312 113 632 312 120 633 minecraft:basalt
setblock 313 113 604 minecraft:white_concrete
fill 313 113 615 313 121 615 minecraft:basalt
fill 313 113 631 313 121 631 minecraft:basalt
fill 314 113 608 315 113 608 minecraft:basalt
setblock 314 113 616 minecraft:magma_block
fill 314 113 630 314 121 630 minecraft:basalt
fill 315 113 604 315 156 604 minecraft:purple_concrete
fill 315 113 609 316 113 609 minecraft:basalt
fill 315 113 617 315 120 617 minecraft:basalt
fill 315 113 629 315 120 629 minecraft:basalt
fill 315 113 636 316 114 636 minecraft:basalt
fill 316 113 619 316 113 620 minecraft:basalt
fill 316 113 626 316 113 627 minecraft:basalt
setblock 317 113 609 minecraft:magma_block
fill 317 113 620 317 120 620 minecraft:basalt
setblock 317 113 621 minecraft:magma_block
fill 317 113 622 317 120 623 minecraft:basalt
setblock 317 113 624 minecraft:magma_block
setblock 317 113 636 minecraft:magma_block
fill 318 113 611 319 113 611 minecraft:basalt
fill 318 113 614 321 113 615 minecraft:basalt
fill 318 113 622 318 119 622 minecraft:basalt
fill 318 113 635 318 113 636 minecraft:basalt
setblock 319 113 635 minecraft:basalt
fill 320 113 632 321 113 632 minecraft:basalt
setblock 321 113 604 minecraft:white_concrete
fill 321 113 616 322 113 616 minecraft:basalt
fill 321 113 619 322 114 619 minecraft:basalt
fill 321 113 628 322 114 628 minecraft:basalt
setblock 321 113 631 minecraft:basalt
setblock 323 113 619 minecraft:magma_block
setblock 323 113 622 minecraft:magma_block
setblock 323 113 623 minecraft:basalt
setblock 323 113 625 minecraft:magma_block
setblock 323 113 626 minecraft:basalt
setblock 323 113 628 minecraft:magma_block
fill 282 114 614 282 163 614 minecraft:purple_concrete
fill 282 114 619 282 154 619 minecraft:purple_concrete
setblock 283 114 604 minecraft:white_concrete
fill 287 114 627 287 116 627 minecraft:amethyst_block
fill 290 114 618 292 114 619 minecraft:basalt
fill 290 114 621 291 114 622 minecraft:basalt
fill 290 114 624 291 114 625 minecraft:basalt
fill 290 114 627 292 114 628 minecraft:basalt
fill 291 114 616 292 114 616 minecraft:basalt
setblock 291 114 646 minecraft:pearlescent_froglight
fill 292 114 614 294 114 615 minecraft:basalt
setblock 292 114 631 minecraft:magma_block
setblock 292 114 632 minecraft:basalt
fill 294 114 612 295 114 612 minecraft:basalt
fill 295 114 611 298 114 611 minecraft:basalt
setblock 295 114 635 minecraft:basalt
fill 296 114 610 300 114 610 minecraft:basalt
fill 296 114 619 297 114 619 minecraft:basalt
fill 296 114 621 296 121 625 minecraft:basalt
fill 296 114 628 297 120 628 minecraft:basalt
fill 297 114 618 297 121 618 minecraft:basalt
fill 297 114 627 297 122 627 minecraft:basalt
setblock 298 114 617 minecraft:magma_block
setblock 298 114 629 minecraft:magma_block
fill 299 114 615 299 121 616 minecraft:basalt
fill 299 114 630 299 121 630 minecraft:basalt
fill 300 114 615 300 121 615 minecraft:basalt
fill 300 114 631 300 120 631 minecraft:basalt
setblock 301 114 607 minecraft:magma_block
fill 301 114 614 302 121 614 minecraft:basalt
fill 301 114 632 302 121 632 minecraft:basalt
fill 301 114 639 303 114 639 minecraft:basalt
fill 303 114 607 309 114 607 minecraft:basalt
fill 304 114 613 308 114 613 minecraft:basalt
setblock 304 114 633 minecraft:magma_block
setblock 304 114 639 minecraft:magma_block
setblock 305 114 604 minecraft:amethyst_block
fill 305 114 633 305 120 634 minecraft:basalt
fill 306 114 633 308 121 633 minecraft:basalt
fill 306 114 639 311 114 639 minecraft:basalt
fill 308 114 612 308 120 612 minecraft:basalt
setblock 310 114 607 minecraft:magma_block
fill 310 114 614 311 121 614 minecraft:basalt
fill 310 114 632 311 121 632 minecraft:basalt
fill 311 114 638 313 114 638 minecraft:basalt
fill 312 114 610 316 114 610 minecraft:basalt
fill 312 114 615 312 120 615 minecraft:basalt
fill 312 114 631 312 121 631 minecraft:basalt
fill 313 114 604 313 164 604 minecraft:purple_concrete
fill 313 114 616 314 121 616 minecraft:basalt
setblock 313 114 630 minecraft:magma_block
fill 314 114 617 314 121 617 minecraft:basalt
fill 314 114 629 314 121 629 minecraft:basalt
fill 314 114 637 315 114 637 minecraft:basalt
setblock 315 114 609 minecraft:basalt
fill 315 114 612 318 114 612 minecraft:basalt
fill 315 114 618 315 114 619 minecraft:basalt
fill 315 114 627 315 121 628 minecraft:basalt
fill 315 114 634 318 114 634 minecraft:basalt
fill 316 114 619 316 121 619 minecraft:basalt
setblock 316 114 620 minecraft:magma_block
fill 316 114 621 316 121 622 minecraft:basalt
setblock 316 114 623 minecraft:magma_block
fill 316 114 624 316 121 625 minecraft:basalt
setblock 316 114 626 minecraft:magma_block
fill 316 114 627 316 119 627 minecraft:basalt
fill 317 114 613 318 115 613 minecraft:basalt
fill 317 114 621 317 120 621 minecraft:basalt
fill 317 114 624 317 120 624 minecraft:basalt
fill 317 114 633 319 114 633 minecraft:basalt
fill 318 114 614 320 114 615 minecraft:basalt
setblock 319 114 613 minecraft:magma_block
fill 319 114 629 321 114 630 minecraft:basalt
fill 320 114 617 321 114 618 minecraft:basalt
fill 320 114 620 322 114 620 minecraft:basalt
fill 320 114 626 321 114 627 minecraft:basalt
setblock 320 114 632 minecraft:basalt
fill 321 114 604 321 163 604 minecraft:purple_concrete
setblock 321 114 616 minecraft:basalt
fill 321 114 621 321 116 625 minecraft:basalt
setblock 322 114 618 minecraft:magma_block
setblock 322 114 621 minecraft:magma_block
fill 322 114 622 322 115 623 minecraft:basalt
setblock 322 114 624 minecraft:magma_block
fill 322 114 625 322 114 626 minecraft:basalt
setblock 322 114 627 minecraft:magma_block
fill 283 115 604 283 122 604 minecraft:purple_concrete
fill 290 115 622 291 115 622 minecraft:basalt
fill 290 115 624 291 115 624 minecraft:basalt
setblock 291 115 618 minecraft:magma_block
fill 291 115 619 292 115 619 minecraft:basalt
setblock 291 115 621 minecraft:magma_block
fill 291 115 625 291 116 625 minecraft:basalt
setblock 291 115 627 minecraft:magma_block
fill 291 115 628 292 115 628 minecraft:basalt
fill 291 115 646 291 163 646 minecraft:purple_concrete
fill 292 115 616 292 115 618 minecraft:basalt
fill 292 115 627 292 116 627 minecraft:basalt
fill 292 115 629 293 115 630 minecraft:basalt
fill 293 115 614 294 115 615 minecraft:basalt
fill 293 115 617 293 116 617 minecraft:basalt
fill 293 115 632 294 115 632 minecraft:basalt
setblock 294 115 633 minecraft:basalt
setblock 295 115 612 minecraft:basalt
fill 295 115 634 297 115 634 minecraft:basalt
fill 296 115 611 298 115 611 minecraft:basalt
fill 296 115 619 296 121 619 minecraft:basalt
setblock 297 115 610 minecraft:magma_block
setblock 297 115 619 minecraft:magma_block
fill 297 115 620 297 122 621 minecraft:basalt
setblock 297 115 625 minecraft:magma_block
fill 297 115 626 297 122 626 minecraft:basalt
fill 298 115 610 300 115 610 minecraft:basalt
fill 298 115 617 298 121 618 minecraft:basalt
fill 298 115 628 298 121 629 minecraft:basalt
setblock 299 115 609 minecraft:basalt
setblock 299 115 617 minecraft:basalt
setblock 299 115 629 minecraft:basalt
fill 299 115 637 301 115 637 minecraft:basalt
setblock 300 115 609 minecraft:magma_block
fill 300 115 616 300 122 616 minecraft:basalt
setblock 300 115 630 minecraft:magma_block
fill 301 115 608 302 115 609 minecraft:basalt
fill 301 115 615 301 122 615 minecraft:basalt
fill 301 115 631 301 122 631 minecraft:basalt
fill 301 115 638 302 115 638 minecraft:basalt
setblock 303 115 608 minecraft:magma_block
fill 303 115 609 303 116 609 minecraft:basalt
setblock 303 115 614 minecraft:magma_block
setblock 303 115 632 minecraft:magma_block
setblock 303 115 638 minecraft:magma_block
fill 304 115 608 307 116 608 minecraft:basalt
fill 304 115 613 304 121 614 minecraft:basalt
fill 304 115 632 304 121 633 minecraft:basalt
fill 304 115 638 307 116 638 minecraft:basalt
fill 305 115 604 305 163 604 minecraft:purple_concrete
setblock 305 115 607 minecraft:basalt
fill 305 115 613 305 121 613 minecraft:basalt
setblock 306 115 607 minecraft:magma_block
setblock 306 115 613 minecraft:magma_block
fill 306 115 639 307 115 639 minecraft:basalt
setblock 307 115 607 minecraft:basalt
fill 307 115 613 308 121 613 minecraft:basalt
setblock 307 115 646 minecraft:amethyst_block
fill 308 115 614 309 115 614 minecraft:basalt
fill 308 115 632 309 115 632 minecraft:basalt
fill 309 115 608 311 115 609 minecraft:basalt
fill 311 115 615 311 122 615 minecraft:basalt
fill 311 115 631 311 122 631 minecraft:basalt
setblock 311 115 638 minecraft:basalt
fill 312 115 609 313 115 610 minecraft:basalt
fill 312 115 616 312 122 616 minecraft:basalt
fill 312 115 630 313 122 630 minecraft:basalt
fill 313 115 617 313 122 617 minecraft:basalt
fill 313 115 629 313 122 629 minecraft:basalt
setblock 314 115 610 minecraft:basalt
fill 314 115 618 315 121 618 minecraft:basalt
fill 314 115 628 314 121 628 minecraft:basalt
setblock 315 115 610 minecraft:magma_block
fill 315 115 612 317 115 612 minecraft:basalt
setblock 315 115 619 minecraft:magma_block
fill 315 115 620 315 122 621 minecraft:basalt
setblock 315 115 625 minecraft:magma_block
fill 315 115 626 316 121 626 minecraft:basalt
fill 315 115 634 317 115 634 minecraft:basalt
setblock 315 115 636 minecraft:basalt
fill 316 115 620 316 121 620 minecraft:basalt
fill 316 115 623 316 121 623 minecraft:basalt
fill 317 115 633 317 116 633 minecraft:basalt
fill 318 115 614 319 115 615 minecraft:basalt
setblock 318 115 633 minecraft:magma_block
fill 319 115 629 320 115 630 minecraft:basalt
fill 320 115 617 320 115 618 minecraft:basalt
fill 320 115 620 320 116 620 minecraft:basalt
fill 320 115 626 320 116 627 minecraft:basalt
fill 321 115 618 321 115 619 minecraft:basalt
setblock 321 115 620 minecraft:magma_block
setblock 321 115 626 minecraft:magma_block
fill 321 115 627 321 115 628 minecraft:basalt
setblock 322 115 624 minecraft:basalt
fill 291 116 621 291 116 622 minecraft:basalt
setblock 291 116 624 minecraft:basalt
fill 292 116 618 292 116 620 minecraft:basalt
setblock 292 116 626 minecraft:basalt
setblock 292 116 628 minecraft:basalt
setblock 293 116 616 minecraft:magma_block
fill 293 116 629 293 116 630 minecraft:basalt
fill 294 116 614 294 116 616 minecraft:basalt
setblock 294 116 632 minecraft:basalt
fill 295 116 613 296 116 613 minecraft:basalt
setblock 296 116 612 minecraft:magma_block
fill 296 116 634 297 116 634 minecraft:basalt
fill 297 116 611 298 116 611 minecraft:basalt
fill 297 116 619 298 122 619 minecraft:basalt
fill 297 116 622 297 122 625 minecraft:basalt
fill 297 116 635 298 116 635 minecraft:basalt
fill 298 116 627 298 122 627 minecraft:basalt
fill 299 116 610 300 116 610 minecraft:basalt
setblock 299 116 617 minecraft:magma_block
fill 299 116 618 299 121 618 minecraft:basalt
fill 299 116 628 299 122 628 minecraft:basalt
setblock 299 116 629 minecraft:magma_block
fill 299 116 636 300 116 636 minecraft:basalt
fill 300 116 630 301 116 630 minecraft:basalt
fill 301 116 609 302 116 609 minecraft:basalt
fill 301 116 616 301 122 616 minecraft:basalt
setblock 301 116 637 minecraft:basalt
fill 302 116 615 302 122 615 minecraft:basalt
setblock 302 116 631 minecraft:magma_block
fill 302 116 636 302 117 636 minecraft:basalt
setblock 302 116 637 minecraft:magma_block
fill 303 116 614 303 122 614 minecraft:basalt
fill 303 116 632 303 122 632 minecraft:basalt
fill 305 116 614 307 122 614 minecraft:basalt
fill 305 116 632 307 122 632 minecraft:basalt
fill 306 116 613 306 121 613 minecraft:basalt
fill 307 116 646 307 163 646 minecraft:purple_concrete
setblock 308 116 608 minecraft:magma_block
setblock 308 116 614 minecraft:magma_block
setblock 308 116 632 minecraft:magma_block
fill 308 116 637 310 116 637 minecraft:basalt
setblock 308 116 638 minecraft:magma_block
fill 309 116 609 311 116 609 minecraft:basalt
fill 309 116 614 309 122 614 minecraft:basalt
fill 309 116 632 309 122 632 minecraft:basalt
fill 310 116 615 310 122 615 minecraft:basalt
fill 310 116 631 310 122 631 minecraft:basalt
setblock 311 116 616 minecraft:magma_block
fill 311 116 630 311 122 630 minecraft:basalt
fill 311 116 636 313 116 636 minecraft:basalt
setblock 311 116 637 minecraft:magma_block
fill 312 116 610 313 116 610 minecraft:basalt
fill 313 116 618 313 122 618 minecraft:basalt
fill 313 116 628 313 122 628 minecraft:basalt
fill 314 116 611 315 116 611 minecraft:basalt
fill 314 116 619 315 121 619 minecraft:basalt
setblock 314 116 627 minecraft:magma_block
fill 314 116 635 315 116 635 minecraft:basalt
fill 315 116 612 316 116 612 minecraft:basalt
fill 315 116 622 315 122 625 minecraft:basalt
fill 315 116 634 316 116 634 minecraft:basalt
setblock 317 116 613 minecraft:basalt
fill 318 116 614 318 116 615 minecraft:basalt
fill 318 116 631 318 116 632 minecraft:basalt
fill 319 116 619 319 117 619 minecraft:basalt
fill 319 116 628 319 116 630 minecraft:basalt
setblock 320 116 618 minecraft:basalt
setblock 320 116 619 minecraft:magma_block
setblock 320 116 628 minecraft:magma_block
setblock 324 116 633 minecraft:white_concrete
fill 324 116 634 324 121 636 minecraft:purple_concrete
setblock 282 117 626 minecraft:white_concrete
fill 282 117 627 282 135 627 minecraft:purple_concrete
setblock 285 117 604 minecraft:pearlescent_froglight
setblock 292 117 621 minecraft:magma_block
setblock 292 117 624 minecraft:magma_block
setblock 294 117 616 minecraft:basalt
setblock 295 117 614 minecraft:magma_block
setblock 295 117 632 minecraft:magma_block
fill 296 117 613 296 117 614 minecraft:basalt
setblock 296 117 632 minecraft:basalt
setblock 297 117 634 minecraft:basalt
fill 298 117 620 298 122 621 minecraft:basalt
setblock 298 117 622 minecraft:magma_block
fill 298 117 623 298 122 624 minecraft:basalt
setblock 298 117 625 minecraft:magma_block
fill 298 117 626 298 122 626 minecraft:basalt
fill 298 117 633 298 118 633 minecraft:basalt
setblock 298 117 634 minecraft:magma_block
fill 299 117 617 300 122 617 minecraft:basalt
fill 299 117 619 299 122 619 minecraft:basalt
fill 299 117 627 299 121 627 minecraft:basalt
fill 299 117 629 300 122 629 minecraft:basalt
fill 300 117 630 300 122 630 minecraft:basalt
setblock 301 117 630 minecraft:magma_block
fill 301 117 635 301 118 635 minecraft:basalt
setblock 301 117 636 minecraft:magma_block
fill 302 117 616 302 122 616 minecraft:basalt
fill 302 117 630 302 122 631 minecraft:basalt
fill 303 117 615 309 117 615 minecraft:basalt
fill 303 117 631 306 121 631 minecraft:basalt
setblock 307 117 631 minecraft:magma_block
fill 307 117 636 309 118 636 minecraft:basalt
setblock 307 117 637 minecraft:magma_block
fill 308 117 614 308 122 614 minecraft:basalt
fill 308 117 631 308 122 632 minecraft:basalt
setblock 308 117 637 minecraft:basalt
setblock 308 117 646 minecraft:pearlescent_froglight
fill 309 117 631 309 122 631 minecraft:basalt
fill 309 117 646 310 156 646 minecraft:purple_concrete
fill 310 117 616 311 122 616 minecraft:basalt
setblock 310 117 630 minecraft:magma_block
setblock 310 117 636 minecraft:magma_block
fill 311 117 611 312 118 611 minecraft:basalt
fill 311 117 635 311 117 636 minecraft:basalt
setblock 312 117 604 minecraft:white_concrete
fill 312 117 617 312 122 617 minecraft:basalt
fill 312 117 629 312 122 629 minecraft:basalt
fill 312 117 635 312 118 635 minecraft:basalt
setblock 313 117 611 minecraft:magma_block
fill 313 117 619 313 122 619 minecraft:basalt
fill 313 117 627 314 122 627 minecraft:basalt
setblock 313 117 635 minecraft:magma_block
fill 314 117 620 314 121 626 minecraft:basalt
fill 315 117 612 315 117 613 minecraft:basalt
setblock 315 117 634 minecraft:basalt
setblock 316 117 613 minecraft:magma_block
fill 318 117 618 318 118 618 minecraft:basalt
setblock 319 117 618 minecraft:magma_block
fill 319 117 620 319 118 626 minecraft:basalt
setblock 319 117 627 minecraft:magma_block
setblock 319 117 628 minecraft:basalt
setblock 324 117 623 minecraft:pearlescent_froglight
fill 324 117 633 324 138 633 minecraft:purple_concrete
setblock 324 117 641 minecraft:pearlescent_froglight
fill 324 117 642 324 162 642 minecraft:purple_concrete
fill 282 118 612 282 119 612 minecraft:gold_block
fill 282 118 626 282 153 626 minecraft:purple_concrete
fill 282 118 628 282 119 628 minecraft:gold_block
setblock 282 118 634 minecraft:pearlescent_froglight
fill 282 118 644 282 119 644 minecraft:gold_block
fill 284 118 646 284 163 646 minecraft:purple_concrete
fill 285 118 604 285 125 604 minecraft:purple_concrete
setblock 285 118 607 minecraft:light[level=13]
setblock 285 118 615 minecraft:light[level=13]
setblock 285 118 623 minecraft:light[level=13]
setblock 285 118 631 minecraft:light[level=13]
setblock 285 118 639 minecraft:light[level=13]
setblock 285 118 646 minecraft:white_concrete
fill 286 118 604 286 119 604 minecraft:gold_block
setblock 293 118 607 minecraft:light[level=13]
setblock 293 118 615 minecraft:light[level=13]
setblock 293 118 631 minecraft:light[level=13]
setblock 293 118 639 minecraft:light[level=13]
setblock 294 118 619 minecraft:magma_block
fill 294 118 620 294 119 620 minecraft:basalt
fill 294 118 626 294 118 627 minecraft:basalt
setblock 294 118 628 minecraft:magma_block
fill 296 118 646 296 119 646 minecraft:gold_block
setblock 297 118 632 minecraft:basalt
fill 298 118 622 298 122 622 minecraft:basalt
fill 298 118 625 298 122 625 minecraft:basalt
fill 299 118 620 299 122 620 minecraft:basalt
fill 299 118 626 299 122 626 minecraft:basalt
setblock 300 118 611 minecraft:magma_block
fill 300 118 612 300 119 612 minecraft:basalt
fill 300 118 618 300 122 618 minecraft:basalt
fill 300 118 628 300 122 628 minecraft:basalt
fill 300 118 634 300 119 634 minecraft:basalt
setblock 300 118 635 minecraft:magma_block
setblock 301 118 607 minecraft:light[level=13]
fill 301 118 617 301 122 617 minecraft:basalt
setblock 301 118 623 minecraft:light[level=13]
fill 301 118 629 301 122 630 minecraft:basalt
setblock 301 118 639 minecraft:light[level=13]
fill 302 118 604 302 119 604 minecraft:gold_block
setblock 303 118 610 minecraft:magma_block
fill 303 118 615 305 122 615 minecraft:basalt
setblock 303 118 616 minecraft:magma_block
fill 303 118 630 303 122 630 minecraft:basalt
fill 304 118 610 307 118 610 minecraft:basalt
setblock 306 118 615 minecraft:magma_block
setblock 306 118 636 minecraft:magma_block
fill 307 118 615 309 121 615 minecraft:basalt
fill 307 118 631 307 122 631 minecraft:basalt
fill 308 118 646 308 137 646 minecraft:purple_concrete
setblock 309 118 607 minecraft:light[level=13]
fill 309 118 616 309 122 616 minecraft:basalt
setblock 309 118 623 minecraft:light[level=13]
fill 309 118 630 310 122 630 minecraft:basalt
setblock 309 118 639 minecraft:light[level=13]
fill 311 118 617 311 121 617 minecraft:basalt
fill 311 118 629 311 121 629 minecraft:basalt
setblock 311 118 635 minecraft:basalt
fill 312 118 604 312 163 604 minecraft:purple_concrete
fill 312 118 618 312 122 618 minecraft:basalt
setblock 312 118 628 minecraft:magma_block
fill 312 118 639 314 119 639 minecraft:obsidian
fill 312 118 646 312 119 646 minecraft:gold_block
fill 313 118 620 313 122 620 minecraft:basalt
fill 313 118 626 313 122 626 minecraft:basalt
fill 313 118 638 313 119 638 minecraft:obsidian
fill 313 118 640 313 119 640 minecraft:obsidian
setblock 314 118 633 minecraft:basalt
setblock 317 118 607 minecraft:light[level=13]
fill 317 118 615 317 119 615 minecraft:amethyst_block
fill 317 118 617 317 119 617 minecraft:basalt
fill 317 118 629 317 119 629 minecraft:basalt
setblock 317 118 631 minecraft:light[level=13]
setblock 317 118 639 minecraft:light[level=13]
fill 318 118 604 318 119 604 minecraft:gold_block
setblock 318 118 617 minecraft:magma_block
setblock 318 118 629 minecraft:magma_block
fill 324 118 614 324 119 614 minecraft:gold_block
fill 324 118 623 324 163 623 minecraft:purple_concrete
fill 324 118 630 324 119 630 minecraft:gold_block
setblock 324 118 637 minecraft:pearlescent_froglight
fill 324 118 638 324 155 641 minecraft:purple_concrete
fill 282 119 634 282 163 634 minecraft:purple_concrete
fill 285 119 646 285 161 646 minecraft:purple_concrete
setblock 294 119 621 minecraft:basalt
setblock 294 119 626 minecraft:basalt
setblock 299 119 613 minecraft:magma_block
fill 299 119 621 299 121 621 minecraft:basalt
setblock 299 119 622 minecraft:magma_block
fill 299 119 623 299 121 624 minecraft:basalt
setblock 299 119 625 minecraft:magma_block
setblock 299 119 633 minecraft:basalt
fill 300 119 619 300 122 620 minecraft:basalt
fill 300 119 626 300 122 627 minecraft:basalt
setblock 301 119 612 minecraft:basalt
fill 301 119 618 301 122 618 minecraft:basalt
fill 301 119 628 301 122 628 minecraft:basalt
setblock 302 119 612 minecraft:magma_block
fill 302 119 617 303 121 617 minecraft:basalt
fill 302 119 629 303 121 629 minecraft:basalt
setblock 303 119 611 minecraft:basalt
fill 303 119 616 307 121 616 minecraft:basalt
fill 303 119 635 304 119 635 minecraft:basalt
fill 304 119 630 308 121 630 minecraft:basalt
setblock 305 119 611 minecraft:magma_block
setblock 305 119 635 minecraft:magma_block
fill 306 119 615 306 122 615 minecraft:basalt
setblock 308 119 616 minecraft:magma_block
setblock 309 119 611 minecraft:basalt
fill 309 119 617 310 122 617 minecraft:basalt
fill 309 119 629 310 122 629 minecraft:basalt
setblock 309 119 635 minecraft:basalt
setblock 310 119 612 minecraft:basalt
setblock 311 119 612 minecraft:magma_block
setblock 311 119 618 minecraft:magma_block
fill 311 119 628 312 122 628 minecraft:basalt
fill 312 119 619 312 122 620 minecraft:basalt
fill 312 119 626 312 122 627 minecraft:basalt
fill 313 119 621 313 122 625 minecraft:basalt
setblock 314 119 614 minecraft:magma_block
setblock 314 119 632 minecraft:magma_block
setblock 316 119 616 minecraft:basalt
setblock 317 119 618 minecraft:basalt
setblock 317 119 619 minecraft:magma_block
setblock 317 119 627 minecraft:basalt
setblock 317 119 628 minecraft:magma_block
fill 317 119 646 317 163 646 minecraft:purple_concrete
setblock 318 119 620 minecraft:basalt
setblock 318 119 626 minecraft:basalt
setblock 318 119 646 minecraft:pearlescent_froglight
fill 319 119 646 322 122 646 minecraft:purple_concrete
fill 324 119 637 324 161 637 minecraft:purple_concrete
setblock 282 120 607 minecraft:amethyst_block
fill 282 120 612 282 126 612 minecraft:purple_concrete
fill 282 120 628 282 126 628 minecraft:purple_concrete
fill 282 120 644 282 126 644 minecraft:purple_concrete
setblock 282 120 645 minecraft:white_concrete
fill 286 120 604 286 126 604 minecraft:purple_concrete
fill 295 120 620 295 120 621 minecraft:basalt
setblock 295 120 622 minecraft:magma_block
fill 295 120 623 295 120 624 minecraft:basalt
setblock 295 120 625 minecraft:magma_block
setblock 295 120 626 minecraft:basalt
fill 296 120 646 296 126 646 minecraft:purple_concrete
setblock 298 120 615 minecraft:magma_block
fill 299 120 622 300 120 622 minecraft:basalt
fill 299 120 625 300 120 625 minecraft:basalt
fill 300 120 621 300 122 621 minecraft:basalt
fill 300 120 624 300 122 624 minecraft:basalt
fill 301 120 619 301 122 619 minecraft:basalt
fill 301 120 627 301 122 627 minecraft:basalt
fill 302 120 604 302 126 604 minecraft:purple_concrete
fill 302 120 618 302 122 618 minecraft:basalt
fill 302 120 628 302 122 628 minecraft:basalt
setblock 303 120 634 minecraft:basalt
fill 304 120 612 306 120 612 minecraft:basalt
fill 304 120 617 305 122 617 minecraft:basalt
fill 304 120 629 305 122 629 minecraft:basalt
setblock 304 120 634 minecraft:magma_block
setblock 306 120 634 minecraft:basalt
setblock 307 120 612 minecraft:magma_block
fill 307 120 617 308 122 617 minecraft:basalt
fill 307 120 629 308 122 629 minecraft:basalt
fill 308 120 616 308 122 616 minecraft:basalt
fill 310 120 618 311 122 618 minecraft:basalt
fill 310 120 628 310 122 628 minecraft:basalt
fill 311 120 613 312 120 613 minecraft:basalt
fill 311 120 619 311 122 619 minecraft:basalt
fill 311 120 627 311 122 627 minecraft:basalt
fill 312 120 621 312 120 622 minecraft:basalt
fill 312 120 624 312 120 625 minecraft:basalt
fill 312 120 646 312 126 646 minecraft:purple_concrete
setblock 315 120 630 minecraft:basalt
fill 316 120 615 317 125 615 minecraft:black_concrete
setblock 316 120 617 minecraft:basalt
setblock 316 120 618 minecraft:magma_block
setblock 316 120 627 minecraft:magma_block
setblock 318 120 604 minecraft:purple_concrete
fill 318 120 646 318 163 646 minecraft:purple_concrete
fill 324 120 614 324 126 614 minecraft:purple_concrete
setblock 324 120 630 minecraft:purple_concrete
fill 282 121 607 282 164 607 minecraft:purple_concrete
setblock 282 121 621 minecraft:amethyst_block
fill 282 121 622 282 163 622 minecraft:purple_concrete
fill 282 121 632 282 131 632 minecraft:purple_concrete
setblock 282 121 633 minecraft:pearlescent_froglight
fill 282 121 645 282 159 645 minecraft:purple_concrete
setblock 297 121 628 minecraft:basalt
fill 299 121 622 299 122 622 minecraft:basalt
fill 299 121 625 299 122 625 minecraft:basalt
setblock 300 121 622 minecraft:magma_block
fill 300 121 623 300 122 623 minecraft:basalt
setblock 300 121 625 minecraft:magma_block
setblock 300 121 631 minecraft:magma_block
fill 301 121 620 301 122 620 minecraft:basalt
fill 301 121 626 301 122 626 minecraft:basalt
setblock 302 121 619 minecraft:basalt
setblock 302 121 627 minecraft:basalt
setblock 302 121 633 minecraft:basalt
setblock 303 121 618 minecraft:magma_block
fill 303 121 628 303 122 628 minecraft:basalt
setblock 303 121 633 minecraft:magma_block
setblock 305 121 633 minecraft:basalt
setblock 306 121 617 minecraft:magma_block
setblock 306 121 629 minecraft:magma_block
setblock 309 121 613 minecraft:magma_block
fill 309 121 618 309 122 618 minecraft:basalt
setblock 309 121 628 minecraft:magma_block
setblock 309 121 633 minecraft:basalt
setblock 310 121 619 minecraft:basalt
setblock 310 121 627 minecraft:basalt
setblock 311 121 620 minecraft:basalt
setblock 311 121 626 minecraft:basalt
setblock 312 121 615 minecraft:magma_block
setblock 312 121 621 minecraft:magma_block
fill 312 121 622 312 122 623 minecraft:basalt
setblock 312 121 624 minecraft:magma_block
fill 312 121 625 312 122 625 minecraft:basalt
setblock 316 121 627 minecraft:basalt
setblock 318 121 604 minecraft:pearlescent_froglight
setblock 324 121 630 minecraft:pearlescent_froglight
fill 282 122 621 282 146 621 minecraft:purple_concrete
fill 282 122 633 282 130 633 minecraft:purple_concrete
setblock 298 122 604 minecraft:white_concrete
setblock 298 122 618 minecraft:basalt
setblock 298 122 628 minecraft:basalt
fill 299 122 604 299 140 604 minecraft:purple_concrete
setblock 299 122 616 minecraft:basalt
setblock 299 122 618 minecraft:magma_block
setblock 299 122 621 minecraft:magma_block
setblock 299 122 623 minecraft:basalt
setblock 299 122 624 minecraft:magma_block
setblock 299 122 627 minecraft:magma_block
setblock 299 122 630 minecraft:magma_block
setblock 300 122 622 minecraft:basalt
setblock 300 122 625 minecraft:basalt
fill 301 122 621 301 122 625 minecraft:magma_block
setblock 302 122 614 minecraft:magma_block
setblock 302 122 617 minecraft:magma_block
fill 302 122 619 302 122 620 minecraft:magma_block
fill 302 122 626 302 122 627 minecraft:magma_block
setblock 302 122 629 minecraft:magma_block
setblock 302 122 632 minecraft:magma_block
fill 303 122 616 303 122 618 minecraft:basalt
setblock 303 122 619 minecraft:magma_block
setblock 303 122 627 minecraft:magma_block
setblock 303 122 629 minecraft:basalt
fill 303 122 631 304 122 631 minecraft:basalt
setblock 304 122 614 minecraft:basalt
setblock 304 122 616 minecraft:basalt
fill 304 122 618 308 122 618 minecraft:magma_block
fill 304 122 628 308 122 628 minecraft:magma_block
fill 304 122 630 307 122 630 minecraft:basalt
setblock 304 122 632 minecraft:basalt
setblock 305 122 616 minecraft:magma_block
setblock 305 122 631 minecraft:magma_block
fill 306 122 616 306 122 617 minecraft:basalt
setblock 306 122 629 minecraft:basalt
setblock 306 122 631 minecraft:basalt
fill 307 122 615 307 122 616 minecraft:basalt
setblock 308 122 615 minecraft:magma_block
setblock 308 122 630 minecraft:magma_block
setblock 309 122 615 minecraft:basalt
fill 309 122 619 310 122 619 minecraft:magma_block
fill 309 122 627 310 122 627 minecraft:magma_block
setblock 309 122 628 minecraft:basalt
setblock 310 122 614 minecraft:basalt
fill 310 122 620 311 122 620 minecraft:magma_block
fill 310 122 626 311 122 626 minecraft:magma_block
setblock 310 122 632 minecraft:basalt
setblock 311 122 617 minecraft:magma_block
fill 311 122 621 311 122 625 minecraft:magma_block
setblock 311 122 629 minecraft:magma_block
setblock 312 122 621 minecraft:basalt
setblock 312 122 624 minecraft:basalt
setblock 313 122 616 minecraft:basalt
setblock 314 122 618 minecraft:basalt
setblock 314 122 619 minecraft:magma_block
fill 314 122 620 314 122 621 minecraft:basalt
setblock 314 122 622 minecraft:magma_block
fill 314 122 623 314 122 624 minecraft:basalt
setblock 314 122 625 minecraft:magma_block
fill 314 122 626 315 122 626 minecraft:basalt
setblock 314 122 628 minecraft:magma_block
setblock 315 122 619 minecraft:basalt
setblock 315 122 627 minecraft:basalt
fill 316 122 614 317 125 614 minecraft:black_concrete
fill 316 122 616 317 125 616 minecraft:black_concrete
fill 318 122 604 318 126 604 minecraft:purple_concrete
setblock 324 122 609 minecraft:white_concrete
setblock 324 122 617 minecraft:pearlescent_froglight
fill 324 122 630 324 126 630 minecraft:purple_concrete
setblock 324 122 634 minecraft:white_concrete
fill 324 122 635 324 160 636 minecraft:purple_concrete
setblock 283 123 604 minecraft:amethyst_block
fill 289 123 604 291 163 604 minecraft:purple_concrete
setblock 292 123 604 minecraft:pearlescent_froglight
fill 298 123 604 298 163 604 minecraft:purple_concrete
fill 315 123 615 315 125 615 minecraft:black_concrete
fill 318 123 615 318 125 616 minecraft:black_concrete
fill 319 123 646 320 159 646 minecraft:purple_concrete
setblock 321 123 646 minecraft:pearlescent_froglight
fill 322 123 646 322 159 646 minecraft:purple_concrete
fill 324 123 609 324 158 609 minecraft:purple_concrete
fill 324 123 617 324 163 617 minecraft:purple_concrete
fill 324 123 634 324 163 634 minecraft:purple_concrete
fill 283 124 604 283 163 604 minecraft:purple_concrete
setblock 290 124 646 minecraft:amethyst_block
fill 292 124 604 292 160 604 minecraft:purple_concrete
fill 301 124 639 302 125 640 minecraft:obsidian
setblock 306 124 646 minecraft:pearlescent_froglight
fill 315 124 614 315 125 614 minecraft:black_concrete
fill 315 124 616 315 125 616 minecraft:black_concrete
fill 316 124 617 317 125 617 minecraft:black_concrete
fill 317 124 613 317 125 613 minecraft:black_concrete
fill 318 124 614 318 125 614 minecraft:black_concrete
fill 321 124 646 321 159 646 minecraft:purple_concrete
setblock 324 124 625 minecraft:white_concrete
fill 324 124 626 324 136 626 minecraft:purple_concrete
fill 287 125 615 288 126 616 minecraft:white_concrete
fill 289 125 616 289 126 616 minecraft:white_concrete
fill 290 125 646 290 163 646 minecraft:purple_concrete
fill 306 125 646 306 158 646 minecraft:purple_concrete
setblock 314 125 615 minecraft:black_concrete
setblock 315 125 617 minecraft:black_concrete
setblock 316 125 613 minecraft:black_concrete
setblock 318 125 613 minecraft:black_concrete
setblock 318 125 617 minecraft:black_concrete
fill 319 125 615 319 125 616 minecraft:black_concrete
fill 324 125 625 324 163 625 minecraft:purple_concrete
fill 282 126 605 282 163 605 minecraft:purple_concrete
setblock 282 126 606 minecraft:white_concrete
setblock 282 126 608 minecraft:amethyst_block
setblock 285 126 604 minecraft:pearlescent_froglight
setblock 285 126 607 minecraft:light[level=13]
setblock 285 126 615 minecraft:light[level=13]
setblock 285 126 623 minecraft:light[level=13]
setblock 285 126 631 minecraft:light[level=13]
setblock 285 126 639 minecraft:light[level=13]
setblock 293 126 607 minecraft:light[level=13]
setblock 293 126 615 minecraft:light[level=13]
setblock 293 126 623 minecraft:light[level=13]
setblock 293 126 631 minecraft:light[level=13]
setblock 293 126 639 minecraft:light[level=13]
setblock 300 126 604 minecraft:amethyst_block
setblock 301 126 607 minecraft:light[level=13]
setblock 301 126 615 minecraft:light[level=13]
setblock 301 126 623 minecraft:light[level=13]
setblock 301 126 631 minecraft:light[level=13]
setblock 301 126 639 minecraft:light[level=13]
setblock 309 126 607 minecraft:light[level=13]
setblock 309 126 615 minecraft:light[level=13]
setblock 309 126 623 minecraft:light[level=13]
setblock 309 126 631 minecraft:light[level=13]
setblock 309 126 639 minecraft:light[level=13]
fill 316 126 614 317 126 616 minecraft:amethyst_block
setblock 317 126 607 minecraft:light[level=13]
setblock 317 126 623 minecraft:light[level=13]
setblock 317 126 631 minecraft:light[level=13]
setblock 317 126 639 minecraft:light[level=13]
fill 319 126 604 319 163 604 minecraft:purple_concrete
setblock 320 126 604 minecraft:pearlescent_froglight
setblock 324 126 611 minecraft:white_concrete
setblock 324 126 631 minecraft:white_concrete
fill 282 127 606 282 163 606 minecraft:purple_concrete
fill 282 127 608 282 147 608 minecraft:purple_concrete
fill 282 127 612 282 128 612 minecraft:gold_block
setblock 282 127 623 minecraft:amethyst_block
fill 282 127 628 282 128 628 minecraft:gold_block
fill 282 127 644 282 128 644 minecraft:gold_block
fill 283 127 628 284 130 630 minecraft:amethyst_block
fill 285 127 604 285 144 604 minecraft:purple_concrete
fill 286 127 604 286 128 604 minecraft:gold_block
fill 296 127 646 296 128 646 minecraft:gold_block
fill 297 127 646 300 137 646 minecraft:purple_concrete
fill 300 127 604 300 150 604 minecraft:purple_concrete
setblock 301 127 646 minecraft:pearlescent_froglight
fill 302 127 604 302 128 604 minecraft:gold_block
fill 312 127 646 312 128 646 minecraft:gold_block
fill 316 127 615 317 127 616 minecraft:amethyst_block
fill 318 127 604 318 128 604 minecraft:gold_block
fill 320 127 604 320 156 604 minecraft:purple_concrete
fill 324 127 611 324 160 611 minecraft:purple_concrete
fill 324 127 614 324 128 614 minecraft:gold_block
fill 324 127 630 324 128 630 minecraft:gold_block
fill 324 127 631 324 149 631 minecraft:purple_concrete
setblock 282 128 617 minecraft:white_concrete
fill 282 128 623 282 159 623 minecraft:purple_concrete
setblock 282 128 630 minecraft:white_concrete
fill 283 128 627 283 129 627 minecraft:amethyst_block
fill 283 128 631 283 129 631 minecraft:amethyst_block
fill 285 128 628 285 130 630 minecraft:amethyst_block
fill 301 128 646 301 160 646 minecraft:purple_concrete
fill 316 128 615 317 128 615 minecraft:amethyst_block
setblock 324 128 607 minecraft:pearlescent_froglight
fill 282 129 612 282 135 612 minecraft:purple_concrete
fill 282 129 617 282 163 617 minecraft:purple_concrete
fill 282 129 628 282 135 628 minecraft:purple_concrete
fill 282 129 630 282 163 630 minecraft:purple_concrete
fill 282 129 644 282 135 644 minecraft:purple_concrete
fill 286 129 604 286 135 604 minecraft:purple_concrete
fill 286 129 628 286 130 630 minecraft:amethyst_block
fill 296 129 646 296 135 646 minecraft:purple_concrete
fill 302 129 604 302 135 604 minecraft:purple_concrete
fill 312 129 646 312 135 646 minecraft:purple_concrete
setblock 314 129 604 minecraft:amethyst_block
setblock 317 129 615 minecraft:amethyst_block
fill 318 129 604 318 135 604 minecraft:purple_concrete
fill 324 129 607 324 163 607 minecraft:purple_concrete
setblock 324 129 610 minecraft:amethyst_block
fill 324 129 614 324 131 614 minecraft:purple_concrete
setblock 324 129 621 minecraft:amethyst_block
fill 324 129 622 324 138 622 minecraft:purple_concrete
fill 324 129 630 324 135 630 minecraft:purple_concrete
setblock 324 129 643 minecraft:white_concrete
fill 324 129 644 324 163 644 minecraft:purple_concrete
fill 287 130 628 287 130 630 minecraft:amethyst_block
fill 314 130 604 314 159 604 minecraft:purple_concrete
fill 324 130 604 324 163 604 minecraft:purple_concrete
setblock 324 130 605 minecraft:amethyst_block
fill 324 130 606 324 163 606 minecraft:purple_concrete
fill 324 130 610 324 140 610 minecraft:purple_concrete
fill 324 130 621 324 161 621 minecraft:purple_concrete
fill 324 130 643 324 134 643 minecraft:purple_concrete
setblock 282 131 633 minecraft:white_concrete
fill 285 131 629 289 131 629 minecraft:amethyst_block
setblock 306 131 604 minecraft:amethyst_block
fill 307 131 604 308 136 604 minecraft:purple_concrete
fill 324 131 605 324 160 605 minecraft:purple_concrete
setblock 282 132 632 minecraft:pearlescent_froglight
fill 282 132 633 282 155 633 minecraft:purple_concrete
setblock 289 132 629 minecraft:amethyst_block
fill 306 132 604 306 148 604 minecraft:purple_concrete
setblock 324 132 613 minecraft:amethyst_block
setblock 324 132 614 minecraft:pearlescent_froglight
fill 282 133 632 282 142 632 minecraft:purple_concrete
setblock 302 133 646 minecraft:amethyst_block
fill 324 133 613 324 135 614 minecraft:purple_concrete
setblock 282 134 638 minecraft:amethyst_block
setblock 285 134 607 minecraft:light[level=13]
setblock 285 134 615 minecraft:light[level=13]
setblock 285 134 623 minecraft:light[level=13]
setblock 285 134 631 minecraft:light[level=13]
setblock 285 134 639 minecraft:light[level=13]
setblock 293 134 607 minecraft:light[level=13]
setblock 293 134 615 minecraft:light[level=13]
setblock 293 134 623 minecraft:light[level=13]
setblock 293 134 631 minecraft:light[level=13]
setblock 293 134 639 minecraft:light[level=13]
setblock 301 134 607 minecraft:light[level=13]
setblock 301 134 615 minecraft:light[level=13]
setblock 301 134 623 minecraft:light[level=13]
setblock 301 134 631 minecraft:light[level=13]
setblock 301 134 639 minecraft:light[level=13]
fill 302 134 646 302 159 646 minecraft:purple_concrete
setblock 309 134 607 minecraft:light[level=13]
setblock 309 134 615 minecraft:light[level=13]
setblock 309 134 623 minecraft:light[level=13]
setblock 309 134 631 minecraft:light[level=13]
setblock 309 134 639 minecraft:light[level=13]
setblock 317 134 607 minecraft:light[level=13]
setblock 317 134 615 minecraft:light[level=13]
setblock 317 134 623 minecraft:light[level=13]
setblock 317 134 631 minecraft:light[level=13]
setblock 317 134 639 minecraft:light[level=13]
fill 318 134 628 320 135 628 minecraft:amethyst_block
fill 282 135 638 282 163 638 minecraft:purple_concrete
fill 287 135 646 287 157 646 minecraft:purple_concrete
setblock 288 135 646 minecraft:amethyst_block
setblock 311 135 604 minecraft:white_concrete
fill 319 135 627 323 135 627 minecraft:amethyst_block
fill 319 135 629 323 135 629 minecraft:amethyst_block
fill 321 135 628 323 138 628 minecraft:amethyst_block
setblock 324 135 643 minecraft:white_concrete
fill 282 136 612 282 137 612 minecraft:gold_block
setblock 282 136 627 minecraft:pearlescent_froglight
fill 282 136 628 282 137 628 minecraft:gold_block
fill 282 136 644 282 137 644 minecraft:gold_block
fill 286 136 604 286 137 604 minecraft:gold_block
fill 288 136 646 288 163 646 minecraft:purple_concrete
fill 294 136 631 295 137 632 minecraft:gold_block
fill 296 136 631 296 137 631 minecraft:gold_block
fill 296 136 646 296 137 646 minecraft:gold_block
fill 302 136 604 302 137 604 minecraft:gold_block
fill 311 136 604 311 141 604 minecraft:purple_concrete
fill 312 136 646 312 137 646 minecraft:gold_block
fill 318 136 604 318 137 604 minecraft:gold_block
fill 319 136 628 320 136 628 minecraft:amethyst_block
fill 320 136 627 323 136 627 minecraft:amethyst_block
fill 320 136 629 323 136 629 minecraft:amethyst_block
fill 322 136 626 322 137 626 minecraft:amethyst_block
fill 322 136 630 322 137 630 minecraft:amethyst_block
fill 324 136 613 324 160 613 minecraft:purple_concrete
fill 324 136 614 324 137 614 minecraft:gold_block
fill 324 136 630 324 137 630 minecraft:gold_block
fill 324 136 643 324 163 643 minecraft:purple_concrete
fill 282 137 627 282 163 627 minecraft:purple_concrete
setblock 305 137 646 minecraft:white_concrete
setblock 307 137 604 minecraft:white_concrete
fill 308 137 604 308 160 604 minecraft:purple_concrete
setblock 320 137 628 minecraft:amethyst_block
fill 321 137 627 323 138 627 minecraft:amethyst_block
fill 321 137 629 323 138 629 minecraft:amethyst_block
setblock 324 137 626 minecraft:amethyst_block
fill 282 138 612 282 144 612 minecraft:purple_concrete
fill 282 138 628 282 144 628 minecraft:purple_concrete
fill 282 138 644 282 144 644 minecraft:purple_concrete
fill 286 138 604 286 144 604 minecraft:purple_concrete
fill 296 138 646 297 144 646 minecraft:purple_concrete
setblock 298 138 646 minecraft:pearlescent_froglight
setblock 299 138 646 minecraft:amethyst_block
fill 300 138 646 300 163 646 minecraft:purple_concrete
fill 302 138 604 302 140 604 minecraft:purple_concrete
fill 305 138 646 305 158 646 minecraft:purple_concrete
fill 307 138 604 307 145 604 minecraft:purple_concrete
setblock 308 138 646 minecraft:amethyst_block
fill 312 138 646 312 144 646 minecraft:purple_concrete
fill 318 138 604 318 144 604 minecraft:purple_concrete
fill 324 138 614 324 144 614 minecraft:purple_concrete
fill 324 138 626 324 159 626 minecraft:purple_concrete
fill 324 138 630 324 144 630 minecraft:purple_concrete
fill 298 139 646 299 153 646 minecraft:purple_concrete
fill 308 139 646 308 161 646 minecraft:purple_concrete
setblock 324 139 622 minecraft:pearlescent_froglight
setblock 324 139 633 minecraft:amethyst_block
fill 307 140 605 309 143 606 minecraft:amethyst_block
fill 324 140 622 324 163 622 minecraft:purple_concrete
fill 324 140 628 324 163 628 minecraft:purple_concrete
setblock 324 140 629 minecraft:pearlescent_froglight
fill 324 140 633 324 163 633 minecraft:purple_concrete
setblock 297 141 604 minecraft:white_concrete
setblock 299 141 604 minecraft:amethyst_block
setblock 302 141 604 minecraft:pearlescent_froglight
fill 306 141 605 306 142 605 minecraft:amethyst_block
fill 307 141 607 309 143 607 minecraft:amethyst_block
fill 308 141 608 308 144 608 minecraft:amethyst_block
fill 310 141 605 310 142 605 minecraft:amethyst_block
setblock 324 141 610 minecraft:pearlescent_froglight
fill 324 141 629 324 163 629 minecraft:purple_concrete
setblock 282 142 637 minecraft:white_concrete
setblock 285 142 607 minecraft:light[level=13]
setblock 285 142 615 minecraft:light[level=13]
setblock 285 142 623 minecraft:light[level=13]
setblock 285 142 631 minecraft:light[level=13]
setblock 285 142 639 minecraft:light[level=13]
setblock 293 142 607 minecraft:light[level=13]
setblock 293 142 615 minecraft:light[level=13]
setblock 293 142 623 minecraft:light[level=13]
setblock 293 142 631 minecraft:light[level=13]
setblock 293 142 639 minecraft:light[level=13]
fill 297 142 604 297 163 604 minecraft:purple_concrete
fill 299 142 604 299 159 604 minecraft:purple_concrete
setblock 301 142 607 minecraft:light[level=13]
setblock 301 142 615 minecraft:light[level=13]
setblock 301 142 623 minecraft:light[level=13]
setblock 301 142 631 minecraft:light[level=13]
setblock 301 142 639 minecraft:light[level=13]
fill 302 142 604 302 144 604 minecraft:purple_concrete
fill 307 142 608 307 143 609 minecraft:amethyst_block
fill 308 142 609 308 144 610 minecraft:amethyst_block
fill 309 142 608 309 143 609 minecraft:amethyst_block
setblock 309 142 615 minecraft:light[level=13]
setblock 309 142 623 minecraft:light[level=13]
setblock 309 142 631 minecraft:light[level=13]
setblock 309 142 639 minecraft:light[level=13]
setblock 311 142 604 minecraft:pearlescent_froglight
fill 311 142 630 311 143 630 minecraft:gold_block
setblock 317 142 607 minecraft:light[level=13]
setblock 317 142 615 minecraft:light[level=13]
setblock 317 142 623 minecraft:light[level=13]
setblock 317 142 631 minecraft:light[level=13]
setblock 317 142 639 minecraft:light[level=13]
fill 324 142 610 324 147 610 minecraft:purple_concrete
setblock 324 142 612 minecraft:amethyst_block
setblock 282 143 632 minecraft:pearlescent_froglight
fill 282 143 637 282 163 637 minecraft:purple_concrete
fill 308 143 611 308 144 611 minecraft:amethyst_block
setblock 309 143 604 minecraft:white_concrete
fill 311 143 604 311 161 604 minecraft:purple_concrete
fill 324 143 612 324 159 612 minecraft:purple_concrete
setblock 282 144 618 minecraft:pearlescent_froglight
fill 282 144 632 282 162 632 minecraft:purple_concrete
fill 290 144 623 290 145 623 minecraft:obsidian
setblock 308 144 612 minecraft:amethyst_block
fill 309 144 604 309 160 604 minecraft:purple_concrete
fill 309 144 616 310 145 616 minecraft:gold_block
fill 282 145 612 282 146 612 minecraft:gold_block
fill 282 145 618 282 163 618 minecraft:purple_concrete
fill 282 145 628 282 146 628 minecraft:gold_block
fill 282 145 644 282 146 644 minecraft:gold_block
setblock 285 145 604 minecraft:amethyst_block
fill 286 145 604 286 146 604 minecraft:gold_block
fill 296 145 646 296 146 646 minecraft:gold_block
fill 297 145 646 297 161 646 minecraft:purple_concrete
fill 302 145 604 302 146 604 minecraft:gold_block
fill 312 145 646 312 146 646 minecraft:gold_block
setblock 314 145 646 minecraft:amethyst_block
fill 316 145 630 316 146 630 minecraft:end_stone
fill 318 145 604 318 146 604 minecraft:gold_block
fill 324 145 614 324 146 614 minecraft:gold_block
fill 324 145 630 324 146 630 minecraft:gold_block
setblock 285 146 604 minecraft:purple_concrete
setblock 307 146 604 minecraft:amethyst_block
fill 314 146 646 314 159 646 minecraft:purple_concrete
fill 282 147 612 282 153 612 minecraft:purple_concrete
setblock 282 147 621 minecraft:white_concrete
fill 282 147 628 282 149 628 minecraft:purple_concrete
fill 282 147 644 282 153 644 minecraft:purple_concrete
setblock 285 147 604 minecraft:amethyst_block
fill 286 147 604 286 153 604 minecraft:purple_concrete
fill 296 147 646 296 153 646 minecraft:purple_concrete
fill 302 147 604 302 149 604 minecraft:purple_concrete
fill 307 147 604 307 163 604 minecraft:purple_concrete
fill 312 147 646 312 153 646 minecraft:purple_concrete
fill 318 147 604 318 153 604 minecraft:purple_concrete
fill 324 147 614 324 153 614 minecraft:purple_concrete
fill 324 147 630 324 153 630 minecraft:purple_concrete
setblock 282 148 608 minecraft:white_concrete
fill 282 148 621 282 163 621 minecraft:purple_concrete
fill 282 148 642 282 163 642 minecraft:purple_concrete
setblock 282 148 643 minecraft:pearlescent_froglight
fill 285 148 604 285 150 604 minecraft:purple_concrete
setblock 311 148 646 minecraft:pearlescent_froglight
setblock 313 148 646 minecraft:amethyst_block
setblock 324 148 610 minecraft:white_concrete
fill 282 149 608 282 160 608 minecraft:purple_concrete
fill 282 149 643 282 163 643 minecraft:purple_concrete
fill 288 149 628 288 150 628 minecraft:end_stone
setblock 306 149 604 minecraft:white_concrete
fill 311 149 646 311 161 646 minecraft:purple_concrete
fill 313 149 646 313 153 646 minecraft:purple_concrete
setblock 322 149 604 minecraft:amethyst_block
fill 324 149 610 324 163 610 minecraft:purple_concrete
setblock 282 150 628 minecraft:amethyst_block
setblock 285 150 607 minecraft:light[level=13]
setblock 285 150 615 minecraft:light[level=13]
setblock 285 150 623 minecraft:light[level=13]
setblock 285 150 631 minecraft:light[level=13]
setblock 285 150 639 minecraft:light[level=13]
setblock 293 150 607 minecraft:light[level=13]
setblock 293 150 615 minecraft:light[level=13]
setblock 293 150 623 minecraft:light[level=13]
setblock 293 150 631 minecraft:light[level=13]
setblock 293 150 639 minecraft:light[level=13]
setblock 301 150 607 minecraft:light[level=13]
setblock 301 150 615 minecraft:light[level=13]
setblock 301 150 623 minecraft:light[level=13]
setblock 301 150 631 minecraft:light[level=13]
setblock 301 150 639 minecraft:light[level=13]
setblock 302 150 604 minecraft:white_concrete
fill 306 150 604 306 163 604 minecraft:purple_concrete
setblock 309 150 607 minecraft:light[level=13]
setblock 309 150 615 minecraft:light[level=13]
setblock 309 150 623 minecraft:light[level=13]
setblock 309 150 631 minecraft:light[level=13]
setblock 309 150 639 minecraft:light[level=13]
setblock 317 150 607 minecraft:light[level=13]
setblock 317 150 615 minecraft:light[level=13]
setblock 317 150 623 minecraft:light[level=13]
setblock 317 150 631 minecraft:light[level=13]
setblock 317 150 639 minecraft:light[level=13]
fill 322 150 604 322 163 604 minecraft:purple_concrete
fill 324 150 618 324 151 618 minecraft:pearlescent_froglight
setblock 324 150 631 minecraft:pearlescent_froglight
fill 282 151 628 282 153 628 minecraft:purple_concrete
setblock 285 151 604 minecraft:white_concrete
setblock 300 151 604 minecraft:pearlescent_froglight
fill 302 151 604 302 153 604 minecraft:purple_concrete
fill 303 151 646 303 163 646 minecraft:purple_concrete
setblock 304 151 646 minecraft:pearlescent_froglight
setblock 316 151 604 minecraft:white_concrete
fill 324 151 631 324 161 631 minecraft:purple_concrete
setblock 282 152 631 minecraft:pearlescent_froglight
fill 285 152 604 285 164 604 minecraft:purple_concrete
setblock 293 152 646 minecraft:amethyst_block
fill 300 152 604 300 161 604 minecraft:purple_concrete
fill 304 152 646 304 159 646 minecraft:purple_concrete
setblock 310 152 604 minecraft:white_concrete
schedule function dropper:buildpart/150_2 1t
