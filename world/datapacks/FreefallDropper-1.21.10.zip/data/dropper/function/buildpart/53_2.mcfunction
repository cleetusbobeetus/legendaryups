fill 236 93 243 236 94 243 minecraft:light_gray_concrete
fill 236 93 245 236 94 245 minecraft:light_gray_concrete
setblock 236 93 247 minecraft:gray_concrete
setblock 236 93 249 minecraft:gray_concrete
setblock 236 93 251 minecraft:gray_concrete
setblock 236 93 253 minecraft:gray_concrete
fill 236 93 262 236 94 262 minecraft:cyan_terracotta
fill 236 93 264 236 94 264 minecraft:cyan_terracotta
fill 236 93 266 236 94 266 minecraft:cyan_terracotta
fill 236 93 268 236 94 268 minecraft:cyan_terracotta
fill 237 93 229 237 94 229 minecraft:light_gray_concrete
fill 237 93 237 237 94 237 minecraft:light_gray_concrete
fill 237 93 242 237 94 242 minecraft:light_gray_concrete
fill 237 93 255 237 94 255 minecraft:gray_concrete
fill 237 93 261 237 94 261 minecraft:cyan_terracotta
fill 237 93 269 237 94 269 minecraft:cyan_terracotta
setblock 239 93 229 minecraft:gray_concrete
setblock 239 93 237 minecraft:gray_concrete
fill 239 93 242 239 94 242 minecraft:light_gray_concrete
fill 239 93 255 239 94 255 minecraft:gray_concrete
fill 239 93 261 239 94 261 minecraft:cyan_terracotta
fill 239 93 269 239 94 269 minecraft:cyan_terracotta
setblock 241 93 229 minecraft:gray_concrete
setblock 241 93 237 minecraft:gray_concrete
fill 241 93 243 241 94 243 minecraft:light_gray_concrete
fill 241 93 245 241 94 245 minecraft:light_gray_concrete
fill 241 93 247 241 94 247 minecraft:light_gray_concrete
fill 241 93 249 241 94 249 minecraft:light_gray_concrete
fill 241 93 251 241 94 251 minecraft:light_gray_concrete
fill 241 93 253 241 97 253 minecraft:gray_concrete
fill 241 93 261 241 94 261 minecraft:cyan_terracotta
fill 241 93 269 241 94 269 minecraft:cyan_terracotta
setblock 243 93 229 minecraft:gray_concrete
setblock 243 93 237 minecraft:gray_concrete
fill 243 93 261 243 94 261 minecraft:cyan_terracotta
fill 243 93 269 243 94 269 minecraft:cyan_terracotta
fill 244 93 228 244 159 228 minecraft:black_concrete
setblock 244 93 230 minecraft:gray_concrete
setblock 244 93 232 minecraft:gray_concrete
setblock 244 93 234 minecraft:gray_concrete
fill 244 93 262 244 94 262 minecraft:cyan_terracotta
fill 244 93 264 244 94 264 minecraft:cyan_terracotta
fill 244 93 266 244 94 266 minecraft:cyan_terracotta
fill 244 93 268 244 94 268 minecraft:cyan_terracotta
fill 249 93 230 249 94 230 minecraft:light_gray_concrete
fill 249 93 232 249 94 232 minecraft:light_gray_concrete
fill 249 93 265 249 94 265 minecraft:cyan_terracotta
fill 249 93 267 249 94 267 minecraft:cyan_terracotta
fill 250 93 229 250 94 229 minecraft:light_gray_concrete
fill 250 93 234 250 94 234 minecraft:light_gray_concrete
fill 250 93 264 250 94 264 minecraft:cyan_terracotta
fill 250 93 269 250 94 269 minecraft:cyan_terracotta
fill 252 93 229 252 94 229 minecraft:light_gray_concrete
fill 252 93 234 252 94 234 minecraft:light_gray_concrete
fill 252 93 264 252 94 264 minecraft:cyan_terracotta
fill 252 93 269 252 94 269 minecraft:cyan_terracotta
fill 254 93 229 254 94 229 minecraft:light_gray_concrete
fill 254 93 234 254 94 234 minecraft:light_gray_concrete
fill 254 93 264 254 94 264 minecraft:cyan_terracotta
fill 254 93 269 254 94 269 minecraft:cyan_terracotta
fill 256 93 229 256 94 229 minecraft:light_gray_concrete
fill 256 93 234 256 94 234 minecraft:light_gray_concrete
fill 256 93 264 256 94 264 minecraft:cyan_terracotta
fill 256 93 269 256 94 269 minecraft:cyan_terracotta
fill 258 93 229 258 94 229 minecraft:light_gray_concrete
fill 258 93 234 258 94 234 minecraft:light_gray_concrete
fill 258 93 264 258 94 264 minecraft:cyan_terracotta
fill 258 93 269 258 94 269 minecraft:cyan_terracotta
fill 260 93 229 260 94 229 minecraft:light_gray_concrete
fill 260 93 234 260 94 234 minecraft:light_gray_concrete
fill 260 93 264 260 94 264 minecraft:cyan_terracotta
fill 260 93 269 260 94 269 minecraft:cyan_terracotta
fill 262 93 230 262 94 230 minecraft:light_gray_concrete
fill 262 93 232 262 94 232 minecraft:light_gray_concrete
fill 262 93 265 262 94 265 minecraft:cyan_terracotta
fill 262 93 267 262 94 267 minecraft:cyan_terracotta
fill 268 93 230 268 94 230 minecraft:cyan_terracotta
fill 268 93 232 268 94 232 minecraft:cyan_terracotta
fill 268 93 234 268 94 234 minecraft:cyan_terracotta
fill 268 93 236 268 94 236 minecraft:cyan_terracotta
fill 268 93 262 268 94 262 minecraft:light_gray_concrete
fill 268 93 264 268 94 264 minecraft:gray_concrete
fill 268 93 268 268 94 268 minecraft:gray_concrete
fill 269 93 229 269 94 229 minecraft:cyan_terracotta
fill 269 93 237 269 94 237 minecraft:cyan_terracotta
fill 269 93 261 269 94 261 minecraft:light_gray_concrete
fill 269 93 269 269 94 269 minecraft:gray_concrete
fill 271 93 229 271 94 229 minecraft:cyan_terracotta
fill 271 93 237 271 94 237 minecraft:cyan_terracotta
fill 271 93 243 271 94 243 minecraft:light_gray_concrete
fill 271 93 245 271 94 245 minecraft:light_gray_concrete
fill 271 93 247 271 94 247 minecraft:light_gray_concrete
fill 271 93 249 271 94 249 minecraft:light_gray_concrete
fill 271 93 251 271 94 251 minecraft:light_gray_concrete
fill 271 93 253 271 94 253 minecraft:light_gray_concrete
fill 271 93 261 271 94 261 minecraft:light_gray_concrete
fill 271 93 269 271 94 269 minecraft:gray_concrete
fill 272 93 242 272 94 242 minecraft:light_gray_concrete
fill 272 93 255 272 94 255 minecraft:light_gray_concrete
fill 273 93 229 273 94 229 minecraft:cyan_terracotta
fill 273 93 237 273 94 237 minecraft:cyan_terracotta
fill 273 93 261 273 94 261 minecraft:light_gray_concrete
fill 273 93 269 273 94 269 minecraft:light_gray_concrete
fill 274 93 242 274 94 242 minecraft:light_gray_concrete
fill 274 93 255 274 94 255 minecraft:light_gray_concrete
fill 275 93 229 275 94 229 minecraft:cyan_terracotta
fill 275 93 237 275 94 237 minecraft:cyan_terracotta
fill 275 93 261 275 94 261 minecraft:light_gray_concrete
fill 275 93 269 275 94 269 minecraft:light_gray_concrete
fill 276 93 230 276 94 230 minecraft:cyan_terracotta
fill 276 93 232 276 94 232 minecraft:cyan_terracotta
fill 276 93 234 276 94 234 minecraft:cyan_terracotta
fill 276 93 236 276 94 236 minecraft:cyan_terracotta
fill 276 93 243 276 94 243 minecraft:light_gray_concrete
fill 276 93 245 276 94 245 minecraft:light_gray_concrete
fill 276 93 247 276 94 247 minecraft:light_gray_concrete
fill 276 93 249 276 94 249 minecraft:light_gray_concrete
fill 276 93 251 276 94 251 minecraft:light_gray_concrete
fill 276 93 253 276 94 253 minecraft:light_gray_concrete
fill 276 93 262 276 94 262 minecraft:light_gray_concrete
fill 276 93 264 276 94 264 minecraft:light_gray_concrete
fill 276 93 266 276 94 266 minecraft:light_gray_concrete
fill 276 93 268 276 94 268 minecraft:light_gray_concrete
fill 236 94 247 236 95 247 minecraft:sea_lantern
setblock 236 94 249 minecraft:sea_lantern
fill 236 94 251 236 95 251 minecraft:sea_lantern
setblock 236 94 253 minecraft:sea_lantern
setblock 236 94 255 minecraft:sea_lantern
setblock 236 94 257 minecraft:sea_lantern
setblock 236 94 259 minecraft:sea_lantern
setblock 236 94 261 minecraft:sea_lantern
setblock 237 94 248 minecraft:sea_lantern
setblock 237 94 250 minecraft:sea_lantern
setblock 237 94 252 minecraft:sea_lantern
setblock 237 94 254 minecraft:sea_lantern
setblock 237 94 256 minecraft:sea_lantern
setblock 237 94 258 minecraft:sea_lantern
setblock 237 94 260 minecraft:sea_lantern
setblock 237 94 262 minecraft:sea_lantern
fill 238 94 229 244 94 237 minecraft:light_gray_concrete
setblock 238 94 239 minecraft:light[level=15]
setblock 238 94 247 minecraft:sea_lantern
setblock 238 94 249 minecraft:sea_lantern
setblock 238 94 251 minecraft:sea_lantern
setblock 238 94 253 minecraft:sea_lantern
setblock 238 94 255 minecraft:sea_lantern
setblock 238 94 257 minecraft:sea_lantern
setblock 238 94 259 minecraft:sea_lantern
setblock 238 94 261 minecraft:sea_lantern
setblock 239 94 248 minecraft:sea_lantern
setblock 239 94 250 minecraft:sea_lantern
setblock 239 94 252 minecraft:sea_lantern
setblock 239 94 254 minecraft:sea_lantern
setblock 239 94 256 minecraft:sea_lantern
setblock 239 94 258 minecraft:sea_lantern
setblock 239 94 260 minecraft:sea_lantern
setblock 239 94 262 minecraft:sea_lantern
setblock 240 94 247 minecraft:sea_lantern
setblock 240 94 249 minecraft:sea_lantern
setblock 240 94 251 minecraft:sea_lantern
setblock 240 94 253 minecraft:sea_lantern
setblock 240 94 255 minecraft:sea_lantern
setblock 240 94 257 minecraft:sea_lantern
setblock 240 94 259 minecraft:sea_lantern
setblock 240 94 261 minecraft:sea_lantern
setblock 241 94 252 minecraft:sea_lantern
setblock 241 94 254 minecraft:sea_lantern
setblock 241 94 256 minecraft:sea_lantern
setblock 241 94 258 minecraft:sea_lantern
setblock 241 94 260 minecraft:sea_lantern
setblock 241 94 262 minecraft:sea_lantern
setblock 242 94 253 minecraft:sea_lantern
setblock 242 94 255 minecraft:sea_lantern
setblock 242 94 257 minecraft:sea_lantern
setblock 242 94 259 minecraft:sea_lantern
setblock 242 94 261 minecraft:sea_lantern
setblock 246 94 231 minecraft:light[level=15]
setblock 246 94 239 minecraft:light[level=15]
setblock 246 94 247 minecraft:light[level=15]
setblock 246 94 255 minecraft:light[level=15]
setblock 246 94 263 minecraft:light[level=15]
setblock 251 94 270 minecraft:magenta_concrete
setblock 254 94 239 minecraft:light[level=15]
setblock 254 94 247 minecraft:light[level=15]
setblock 254 94 255 minecraft:light[level=15]
setblock 254 94 263 minecraft:light[level=15]
setblock 262 94 239 minecraft:light[level=15]
setblock 262 94 247 minecraft:light[level=15]
setblock 262 94 255 minecraft:light[level=15]
setblock 262 94 263 minecraft:light[level=15]
setblock 266 94 229 minecraft:sea_lantern
setblock 266 94 231 minecraft:sea_lantern
setblock 266 94 233 minecraft:sea_lantern
setblock 266 94 235 minecraft:sea_lantern
setblock 266 94 237 minecraft:sea_lantern
setblock 266 94 239 minecraft:sea_lantern
setblock 267 94 230 minecraft:sea_lantern
setblock 267 94 232 minecraft:sea_lantern
setblock 267 94 234 minecraft:sea_lantern
setblock 267 94 236 minecraft:sea_lantern
setblock 267 94 238 minecraft:sea_lantern
setblock 268 94 229 minecraft:sea_lantern
setblock 268 94 231 minecraft:sea_lantern
setblock 268 94 233 minecraft:sea_lantern
setblock 268 94 235 minecraft:sea_lantern
setblock 268 94 237 minecraft:sea_lantern
setblock 268 94 239 minecraft:sea_lantern
setblock 269 94 230 minecraft:sea_lantern
setblock 269 94 232 minecraft:sea_lantern
setblock 269 94 234 minecraft:sea_lantern
setblock 269 94 236 minecraft:sea_lantern
setblock 269 94 238 minecraft:sea_lantern
setblock 270 94 229 minecraft:sea_lantern
setblock 270 94 231 minecraft:sea_lantern
setblock 270 94 233 minecraft:sea_lantern
setblock 270 94 235 minecraft:sea_lantern
setblock 270 94 237 minecraft:sea_lantern
setblock 270 94 239 minecraft:sea_lantern
setblock 270 94 247 minecraft:light[level=15]
setblock 270 94 255 minecraft:light[level=15]
setblock 271 94 230 minecraft:sea_lantern
setblock 271 94 232 minecraft:sea_lantern
setblock 271 94 234 minecraft:sea_lantern
setblock 271 94 236 minecraft:sea_lantern
setblock 271 94 238 minecraft:sea_lantern
setblock 272 94 229 minecraft:sea_lantern
setblock 272 94 231 minecraft:sea_lantern
setblock 272 94 233 minecraft:sea_lantern
setblock 272 94 235 minecraft:sea_lantern
setblock 272 94 237 minecraft:sea_lantern
setblock 272 94 239 minecraft:sea_lantern
setblock 273 94 230 minecraft:sea_lantern
setblock 273 94 232 minecraft:sea_lantern
setblock 273 94 234 minecraft:sea_lantern
setblock 273 94 236 minecraft:sea_lantern
setblock 273 94 238 minecraft:sea_lantern
setblock 274 94 229 minecraft:sea_lantern
setblock 274 94 231 minecraft:sea_lantern
setblock 274 94 233 minecraft:sea_lantern
setblock 274 94 235 minecraft:sea_lantern
setblock 274 94 237 minecraft:sea_lantern
setblock 274 94 239 minecraft:sea_lantern
setblock 275 94 230 minecraft:sea_lantern
setblock 275 94 232 minecraft:sea_lantern
setblock 275 94 234 minecraft:sea_lantern
setblock 275 94 236 minecraft:sea_lantern
setblock 275 94 238 minecraft:sea_lantern
setblock 276 94 228 minecraft:ochre_froglight
setblock 276 94 229 minecraft:sea_lantern
setblock 276 94 231 minecraft:sea_lantern
setblock 276 94 233 minecraft:sea_lantern
setblock 276 94 235 minecraft:sea_lantern
setblock 276 94 237 minecraft:sea_lantern
setblock 276 94 239 minecraft:sea_lantern
setblock 236 95 230 minecraft:pearlescent_froglight
setblock 236 95 232 minecraft:black_stained_glass
setblock 236 95 234 minecraft:ochre_froglight
setblock 236 95 236 minecraft:black_stained_glass
setblock 236 95 243 minecraft:light_blue_stained_glass
setblock 236 95 245 minecraft:black_stained_glass
setblock 236 95 249 minecraft:pearlescent_froglight
setblock 236 95 253 minecraft:ochre_froglight
fill 236 95 255 236 96 255 minecraft:gray_concrete
fill 236 95 257 236 96 257 minecraft:gray_concrete
fill 236 95 259 236 96 259 minecraft:gray_concrete
fill 236 95 261 236 96 261 minecraft:cyan_terracotta
setblock 236 95 262 minecraft:cyan_stained_glass
setblock 236 95 264 minecraft:black_stained_glass
setblock 236 95 266 minecraft:pearlescent_froglight
setblock 236 95 268 minecraft:black_stained_glass
setblock 237 95 229 minecraft:cyan_stained_glass
setblock 237 95 237 minecraft:sea_lantern
setblock 237 95 242 minecraft:black_stained_glass
fill 237 95 248 237 96 248 minecraft:gray_concrete
fill 237 95 250 237 96 250 minecraft:gray_concrete
fill 237 95 252 237 96 252 minecraft:gray_concrete
fill 237 95 254 237 96 254 minecraft:gray_concrete
setblock 237 95 255 minecraft:black_stained_glass
fill 237 95 256 237 96 256 minecraft:gray_concrete
fill 237 95 258 237 96 258 minecraft:gray_concrete
fill 237 95 260 237 96 260 minecraft:gray_concrete
setblock 237 95 261 minecraft:cyan_stained_glass
fill 237 95 262 237 96 262 minecraft:cyan_terracotta
setblock 237 95 269 minecraft:cyan_stained_glass
fill 238 95 229 238 225 237 minecraft:light_gray_concrete
fill 238 95 247 238 96 247 minecraft:gray_concrete
fill 238 95 249 238 96 249 minecraft:gray_concrete
fill 238 95 251 238 96 251 minecraft:gray_concrete
fill 238 95 253 238 96 253 minecraft:gray_concrete
fill 238 95 255 238 96 255 minecraft:gray_concrete
fill 238 95 257 238 96 257 minecraft:gray_concrete
fill 238 95 259 238 96 259 minecraft:gray_concrete
fill 238 95 261 238 96 261 minecraft:cyan_terracotta
setblock 239 95 229 minecraft:sea_lantern
fill 239 95 230 243 154 236 minecraft:light_gray_concrete
setblock 239 95 237 minecraft:light_blue_stained_glass
setblock 239 95 242 minecraft:black_stained_glass
fill 239 95 248 239 96 248 minecraft:gray_concrete
fill 239 95 250 239 96 250 minecraft:gray_concrete
fill 239 95 252 239 96 252 minecraft:gray_concrete
fill 239 95 254 239 96 254 minecraft:gray_concrete
setblock 239 95 255 minecraft:black_stained_glass
fill 239 95 256 239 96 256 minecraft:gray_concrete
fill 239 95 258 239 96 258 minecraft:gray_concrete
fill 239 95 260 239 96 260 minecraft:gray_concrete
setblock 239 95 261 minecraft:black_stained_glass
fill 239 95 262 239 96 262 minecraft:cyan_terracotta
setblock 239 95 269 minecraft:pearlescent_froglight
fill 240 95 229 240 225 229 minecraft:light_gray_concrete
fill 240 95 237 240 171 237 minecraft:light_gray_concrete
fill 240 95 247 240 96 247 minecraft:gray_concrete
fill 240 95 249 240 96 249 minecraft:gray_concrete
fill 240 95 251 240 96 251 minecraft:gray_concrete
fill 240 95 253 240 96 253 minecraft:gray_concrete
fill 240 95 255 240 96 255 minecraft:gray_concrete
fill 240 95 257 240 96 257 minecraft:gray_concrete
fill 240 95 259 240 96 259 minecraft:gray_concrete
fill 240 95 261 240 96 261 minecraft:cyan_terracotta
setblock 241 95 229 minecraft:sea_lantern
setblock 241 95 237 minecraft:cyan_stained_glass
setblock 241 95 243 minecraft:black_stained_glass
setblock 241 95 245 minecraft:black_stained_glass
setblock 241 95 247 minecraft:sea_lantern
setblock 241 95 249 minecraft:light_blue_stained_glass
setblock 241 95 251 minecraft:black_stained_glass
fill 241 95 252 241 96 252 minecraft:gray_concrete
fill 241 95 254 241 96 254 minecraft:gray_concrete
fill 241 95 256 241 96 256 minecraft:gray_concrete
fill 241 95 258 241 96 258 minecraft:gray_concrete
fill 241 95 260 241 96 260 minecraft:gray_concrete
setblock 241 95 261 minecraft:sea_lantern
fill 241 95 262 241 96 262 minecraft:cyan_terracotta
setblock 241 95 269 minecraft:black_stained_glass
fill 242 95 229 242 225 229 minecraft:light_gray_concrete
fill 242 95 237 242 154 237 minecraft:light_gray_concrete
fill 242 95 253 242 96 253 minecraft:gray_concrete
fill 242 95 255 242 96 255 minecraft:gray_concrete
fill 242 95 257 242 96 257 minecraft:gray_concrete
fill 242 95 259 242 96 259 minecraft:gray_concrete
fill 242 95 261 242 96 261 minecraft:cyan_terracotta
setblock 243 95 229 minecraft:black_stained_glass
setblock 243 95 237 minecraft:black_stained_glass
setblock 243 95 261 minecraft:magenta_stained_glass
setblock 243 95 269 minecraft:light_blue_stained_glass
fill 244 95 229 244 225 229 minecraft:light_gray_concrete
setblock 244 95 230 minecraft:magenta_stained_glass
fill 244 95 231 244 225 231 minecraft:light_gray_concrete
setblock 244 95 232 minecraft:cyan_stained_glass
fill 244 95 233 244 165 233 minecraft:light_gray_concrete
setblock 244 95 234 minecraft:magenta_stained_glass
fill 244 95 235 244 154 235 minecraft:light_gray_concrete
setblock 244 95 236 minecraft:black_stained_glass
fill 244 95 237 244 154 237 minecraft:light_gray_concrete
setblock 244 95 262 minecraft:black_stained_glass
setblock 244 95 264 minecraft:sea_lantern
setblock 244 95 266 minecraft:ochre_froglight
setblock 244 95 268 minecraft:black_stained_glass
setblock 249 95 230 minecraft:sea_lantern
setblock 249 95 232 minecraft:black_stained_glass
setblock 249 95 265 minecraft:light_blue_stained_glass
setblock 249 95 267 minecraft:black_stained_glass
setblock 250 95 229 minecraft:black_stained_glass
setblock 250 95 234 minecraft:light_blue_stained_glass
setblock 250 95 264 minecraft:black_stained_glass
setblock 250 95 269 minecraft:pearlescent_froglight
fill 251 95 270 251 99 270 minecraft:black_concrete
setblock 252 95 229 minecraft:black_stained_glass
setblock 252 95 234 minecraft:black_stained_glass
setblock 252 95 264 minecraft:black_stained_glass
setblock 252 95 269 minecraft:black_stained_glass
setblock 254 95 229 minecraft:light_blue_stained_glass
setblock 254 95 234 minecraft:pearlescent_froglight
setblock 254 95 264 minecraft:black_stained_glass
setblock 254 95 269 minecraft:black_stained_glass
setblock 256 95 229 minecraft:magenta_stained_glass
setblock 256 95 234 minecraft:light_blue_stained_glass
setblock 256 95 264 minecraft:sea_lantern
setblock 256 95 269 minecraft:black_stained_glass
setblock 258 95 229 minecraft:cyan_stained_glass
setblock 258 95 234 minecraft:sea_lantern
setblock 258 95 264 minecraft:pearlescent_froglight
setblock 258 95 269 minecraft:ochre_froglight
setblock 260 95 229 minecraft:black_stained_glass
setblock 260 95 234 minecraft:ochre_froglight
setblock 260 95 264 minecraft:black_stained_glass
setblock 260 95 269 minecraft:ochre_froglight
setblock 262 95 230 minecraft:black_stained_glass
setblock 262 95 232 minecraft:black_stained_glass
setblock 262 95 265 minecraft:pearlescent_froglight
setblock 262 95 267 minecraft:black_stained_glass
fill 266 95 229 266 96 229 minecraft:gray_concrete
fill 266 95 231 266 96 231 minecraft:gray_concrete
fill 266 95 233 266 96 233 minecraft:gray_concrete
fill 266 95 235 266 96 235 minecraft:gray_concrete
fill 266 95 237 266 96 237 minecraft:gray_concrete
fill 266 95 239 266 96 239 minecraft:gray_concrete
fill 267 95 230 267 96 230 minecraft:gray_concrete
fill 267 95 232 267 96 232 minecraft:gray_concrete
fill 267 95 234 267 96 234 minecraft:gray_concrete
fill 267 95 236 267 96 236 minecraft:gray_concrete
fill 267 95 238 267 96 238 minecraft:gray_concrete
fill 268 95 229 268 96 229 minecraft:cyan_terracotta
setblock 268 95 230 minecraft:pearlescent_froglight
fill 268 95 231 268 96 231 minecraft:cyan_terracotta
setblock 268 95 232 minecraft:magenta_stained_glass
fill 268 95 233 268 96 233 minecraft:cyan_terracotta
setblock 268 95 234 minecraft:sea_lantern
fill 268 95 235 268 96 235 minecraft:cyan_terracotta
setblock 268 95 236 minecraft:black_stained_glass
fill 268 95 237 268 96 237 minecraft:cyan_terracotta
fill 268 95 239 268 96 239 minecraft:gray_concrete
setblock 268 95 262 minecraft:light_blue_stained_glass
setblock 268 95 264 minecraft:black_stained_glass
fill 268 95 265 272 145 265 minecraft:light_gray_concrete
setblock 268 95 266 minecraft:black_stained_glass
fill 268 95 267 272 153 267 minecraft:light_gray_concrete
setblock 268 95 268 minecraft:ochre_froglight
fill 268 95 269 268 153 269 minecraft:light_gray_concrete
setblock 269 95 229 minecraft:cyan_stained_glass
fill 269 95 230 269 96 230 minecraft:cyan_terracotta
fill 269 95 232 269 96 232 minecraft:cyan_terracotta
fill 269 95 234 269 96 234 minecraft:cyan_terracotta
fill 269 95 236 269 96 236 minecraft:cyan_terracotta
setblock 269 95 237 minecraft:black_stained_glass
fill 269 95 238 269 96 238 minecraft:gray_concrete
setblock 269 95 261 minecraft:cyan_stained_glass
fill 269 95 264 272 146 264 minecraft:light_gray_concrete
fill 269 95 266 272 146 266 minecraft:light_gray_concrete
fill 269 95 268 272 237 268 minecraft:light_gray_concrete
setblock 269 95 269 minecraft:black_stained_glass
fill 270 95 229 270 96 229 minecraft:cyan_terracotta
fill 270 95 231 270 96 231 minecraft:cyan_terracotta
fill 270 95 233 270 96 233 minecraft:cyan_terracotta
fill 270 95 235 270 96 235 minecraft:cyan_terracotta
fill 270 95 237 270 96 237 minecraft:cyan_terracotta
fill 270 95 239 270 96 239 minecraft:gray_concrete
fill 270 95 269 270 237 269 minecraft:light_gray_concrete
setblock 271 95 229 minecraft:gray_concrete
fill 271 95 230 271 96 230 minecraft:cyan_terracotta
fill 271 95 232 271 96 232 minecraft:cyan_terracotta
fill 271 95 234 271 96 234 minecraft:cyan_terracotta
fill 271 95 236 271 96 236 minecraft:cyan_terracotta
setblock 271 95 237 minecraft:black_stained_glass
fill 271 95 238 271 96 238 minecraft:gray_concrete
setblock 271 95 243 minecraft:light_blue_stained_glass
setblock 271 95 245 minecraft:cyan_stained_glass
setblock 271 95 247 minecraft:sea_lantern
setblock 271 95 249 minecraft:black_stained_glass
setblock 271 95 251 minecraft:black_stained_glass
setblock 271 95 253 minecraft:pearlescent_froglight
setblock 271 95 261 minecraft:sea_lantern
setblock 271 95 269 minecraft:sea_lantern
fill 272 95 229 272 96 229 minecraft:cyan_terracotta
fill 272 95 231 272 96 231 minecraft:cyan_terracotta
fill 272 95 233 272 96 233 minecraft:cyan_terracotta
fill 272 95 235 272 96 235 minecraft:cyan_terracotta
fill 272 95 237 272 96 237 minecraft:cyan_terracotta
fill 272 95 239 272 96 239 minecraft:gray_concrete
setblock 272 95 242 minecraft:black_stained_glass
setblock 272 95 255 minecraft:light_blue_stained_glass
fill 272 95 269 272 237 269 minecraft:light_gray_concrete
setblock 273 95 229 minecraft:magenta_stained_glass
fill 273 95 230 273 96 230 minecraft:cyan_terracotta
fill 273 95 232 273 96 232 minecraft:cyan_terracotta
fill 273 95 234 273 96 234 minecraft:cyan_terracotta
fill 273 95 236 273 96 236 minecraft:cyan_terracotta
setblock 273 95 237 minecraft:black_stained_glass
fill 273 95 238 273 96 238 minecraft:gray_concrete
setblock 273 95 261 minecraft:black_stained_glass
setblock 273 95 269 minecraft:pearlescent_froglight
fill 274 95 229 274 96 229 minecraft:cyan_terracotta
fill 274 95 231 274 96 231 minecraft:cyan_terracotta
fill 274 95 233 274 96 233 minecraft:cyan_terracotta
fill 274 95 235 274 96 235 minecraft:cyan_terracotta
fill 274 95 237 274 96 237 minecraft:cyan_terracotta
fill 274 95 239 274 96 239 minecraft:gray_concrete
setblock 274 95 242 minecraft:magenta_stained_glass
setblock 274 95 255 minecraft:magenta_stained_glass
setblock 275 95 229 minecraft:black_stained_glass
fill 275 95 230 275 96 230 minecraft:cyan_terracotta
fill 275 95 232 275 96 232 minecraft:cyan_terracotta
fill 275 95 234 275 96 234 minecraft:cyan_terracotta
fill 275 95 236 275 96 236 minecraft:cyan_terracotta
setblock 275 95 237 minecraft:sea_lantern
fill 275 95 238 275 96 238 minecraft:gray_concrete
setblock 275 95 261 minecraft:black_stained_glass
setblock 275 95 269 minecraft:cyan_stained_glass
fill 276 95 228 276 143 228 minecraft:black_concrete
fill 276 95 229 276 96 229 minecraft:cyan_terracotta
setblock 276 95 230 minecraft:cyan_stained_glass
fill 276 95 231 276 96 231 minecraft:cyan_terracotta
setblock 276 95 232 minecraft:black_stained_glass
fill 276 95 233 276 96 233 minecraft:cyan_terracotta
setblock 276 95 234 minecraft:pearlescent_froglight
fill 276 95 235 276 96 235 minecraft:cyan_terracotta
setblock 276 95 236 minecraft:black_stained_glass
fill 276 95 237 276 96 237 minecraft:cyan_terracotta
fill 276 95 239 276 96 239 minecraft:gray_concrete
setblock 276 95 243 minecraft:light_blue_stained_glass
setblock 276 95 245 minecraft:black_stained_glass
setblock 276 95 247 minecraft:pearlescent_froglight
setblock 276 95 249 minecraft:light_blue_stained_glass
setblock 276 95 251 minecraft:light_blue_stained_glass
setblock 276 95 253 minecraft:ochre_froglight
setblock 276 95 262 minecraft:cyan_stained_glass
setblock 276 95 264 minecraft:sea_lantern
setblock 276 95 266 minecraft:cyan_stained_glass
setblock 276 95 268 minecraft:cyan_stained_glass
setblock 277 95 248 minecraft:pearlescent_froglight
setblock 277 95 255 minecraft:magenta_concrete
fill 235 96 243 235 101 244 minecraft:black_concrete
setblock 235 96 245 minecraft:sea_lantern
fill 236 96 230 236 97 230 minecraft:light_gray_concrete
fill 236 96 232 236 97 232 minecraft:light_gray_concrete
fill 236 96 234 236 97 234 minecraft:light_gray_concrete
fill 236 96 236 236 97 236 minecraft:light_gray_concrete
fill 236 96 243 236 97 243 minecraft:light_gray_concrete
fill 236 96 245 236 97 245 minecraft:light_gray_concrete
setblock 236 96 247 minecraft:gray_concrete
setblock 236 96 249 minecraft:gray_concrete
setblock 236 96 251 minecraft:gray_concrete
setblock 236 96 253 minecraft:gray_concrete
fill 236 96 262 236 97 262 minecraft:cyan_terracotta
fill 236 96 264 236 97 264 minecraft:cyan_terracotta
fill 236 96 266 236 97 266 minecraft:cyan_terracotta
fill 236 96 268 236 97 268 minecraft:cyan_terracotta
fill 237 96 229 237 97 229 minecraft:light_gray_concrete
fill 237 96 237 237 97 237 minecraft:light_gray_concrete
fill 237 96 242 237 97 246 minecraft:iron_block
fill 237 96 255 237 97 255 minecraft:gray_concrete
fill 237 96 261 237 97 261 minecraft:cyan_terracotta
fill 237 96 269 237 97 269 minecraft:cyan_terracotta
fill 239 96 229 239 97 229 minecraft:light_gray_concrete
fill 239 96 237 239 97 237 minecraft:light_gray_concrete
fill 239 96 242 239 97 242 minecraft:light_gray_concrete
fill 239 96 255 239 97 255 minecraft:gray_concrete
fill 239 96 261 239 97 261 minecraft:cyan_terracotta
fill 239 96 269 239 97 269 minecraft:cyan_terracotta
fill 241 96 229 241 97 229 minecraft:light_gray_concrete
fill 241 96 237 241 97 237 minecraft:light_gray_concrete
fill 241 96 243 241 97 243 minecraft:light_gray_concrete
fill 241 96 245 241 97 245 minecraft:light_gray_concrete
fill 241 96 247 241 97 247 minecraft:light_gray_concrete
fill 241 96 249 241 97 249 minecraft:light_gray_concrete
fill 241 96 251 241 97 251 minecraft:light_gray_concrete
fill 241 96 261 241 97 261 minecraft:cyan_terracotta
fill 241 96 269 241 97 269 minecraft:cyan_terracotta
fill 243 96 229 243 97 229 minecraft:light_gray_concrete
fill 243 96 237 243 97 237 minecraft:light_gray_concrete
fill 243 96 261 243 97 261 minecraft:cyan_terracotta
fill 243 96 269 243 97 269 minecraft:cyan_terracotta
fill 244 96 230 244 97 230 minecraft:light_gray_concrete
fill 244 96 232 244 97 232 minecraft:light_gray_concrete
fill 244 96 234 244 97 234 minecraft:light_gray_concrete
fill 244 96 236 244 97 236 minecraft:light_gray_concrete
fill 244 96 262 244 97 262 minecraft:cyan_terracotta
fill 244 96 264 244 97 264 minecraft:cyan_terracotta
fill 244 96 266 244 97 266 minecraft:cyan_terracotta
fill 244 96 268 244 97 268 minecraft:cyan_terracotta
fill 249 96 230 249 97 230 minecraft:light_gray_concrete
fill 249 96 232 249 97 232 minecraft:light_gray_concrete
fill 249 96 265 249 97 265 minecraft:cyan_terracotta
fill 249 96 267 249 97 267 minecraft:cyan_terracotta
fill 250 96 229 250 97 229 minecraft:light_gray_concrete
fill 250 96 234 250 97 234 minecraft:light_gray_concrete
fill 250 96 264 250 97 264 minecraft:cyan_terracotta
fill 250 96 269 250 97 269 minecraft:cyan_terracotta
fill 252 96 229 252 97 229 minecraft:light_gray_concrete
fill 252 96 234 252 97 234 minecraft:light_gray_concrete
fill 252 96 264 252 97 264 minecraft:cyan_terracotta
fill 252 96 269 252 97 269 minecraft:cyan_terracotta
fill 254 96 229 254 97 229 minecraft:light_gray_concrete
fill 254 96 234 254 97 234 minecraft:light_gray_concrete
fill 254 96 264 254 97 264 minecraft:cyan_terracotta
fill 254 96 269 254 97 269 minecraft:cyan_terracotta
fill 256 96 229 256 97 229 minecraft:light_gray_concrete
fill 256 96 234 256 97 234 minecraft:light_gray_concrete
fill 256 96 264 256 97 264 minecraft:cyan_terracotta
fill 256 96 269 256 97 269 minecraft:cyan_terracotta
fill 258 96 229 258 97 229 minecraft:light_gray_concrete
fill 258 96 234 258 97 234 minecraft:light_gray_concrete
fill 258 96 264 258 97 264 minecraft:cyan_terracotta
fill 258 96 269 258 97 269 minecraft:cyan_terracotta
fill 260 96 229 260 97 229 minecraft:light_gray_concrete
fill 260 96 234 260 97 234 minecraft:light_gray_concrete
fill 260 96 264 260 97 264 minecraft:cyan_terracotta
fill 260 96 269 260 97 269 minecraft:cyan_terracotta
fill 262 96 230 262 97 230 minecraft:light_gray_concrete
fill 262 96 232 262 97 232 minecraft:light_gray_concrete
fill 262 96 265 262 97 265 minecraft:cyan_terracotta
fill 262 96 267 262 97 267 minecraft:cyan_terracotta
fill 268 96 230 268 97 230 minecraft:cyan_terracotta
fill 268 96 232 268 97 232 minecraft:cyan_terracotta
fill 268 96 234 268 97 234 minecraft:cyan_terracotta
fill 268 96 236 268 97 236 minecraft:cyan_terracotta
fill 268 96 262 268 97 262 minecraft:light_gray_concrete
fill 268 96 264 268 97 264 minecraft:light_gray_concrete
fill 268 96 266 268 97 266 minecraft:light_gray_concrete
fill 268 96 268 268 97 268 minecraft:light_gray_concrete
fill 269 96 229 269 97 229 minecraft:cyan_terracotta
fill 269 96 237 269 97 237 minecraft:cyan_terracotta
fill 269 96 261 269 97 261 minecraft:light_gray_concrete
fill 269 96 269 269 97 269 minecraft:light_gray_concrete
fill 271 96 229 271 97 229 minecraft:cyan_terracotta
fill 271 96 237 271 97 237 minecraft:cyan_terracotta
fill 271 96 243 271 97 243 minecraft:light_gray_concrete
fill 271 96 245 271 97 245 minecraft:light_gray_concrete
fill 271 96 247 271 97 247 minecraft:light_gray_concrete
fill 271 96 249 271 97 249 minecraft:light_gray_concrete
fill 271 96 251 271 97 251 minecraft:light_gray_concrete
fill 271 96 253 271 97 253 minecraft:light_gray_concrete
fill 271 96 261 271 97 261 minecraft:light_gray_concrete
fill 271 96 269 271 97 269 minecraft:light_gray_concrete
fill 272 96 242 272 97 242 minecraft:light_gray_concrete
fill 272 96 255 272 97 255 minecraft:light_gray_concrete
fill 273 96 229 273 97 229 minecraft:cyan_terracotta
fill 273 96 237 273 97 237 minecraft:cyan_terracotta
fill 273 96 261 273 97 261 minecraft:light_gray_concrete
fill 273 96 269 273 97 269 minecraft:light_gray_concrete
fill 274 96 242 274 97 242 minecraft:light_gray_concrete
fill 274 96 255 274 97 255 minecraft:light_gray_concrete
fill 275 96 229 275 97 229 minecraft:cyan_terracotta
fill 275 96 237 275 97 237 minecraft:cyan_terracotta
fill 275 96 261 275 97 261 minecraft:light_gray_concrete
fill 275 96 269 275 97 269 minecraft:light_gray_concrete
fill 275 96 270 275 143 270 minecraft:black_concrete
fill 276 96 230 276 97 230 minecraft:cyan_terracotta
fill 276 96 232 276 97 232 minecraft:cyan_terracotta
fill 276 96 234 276 97 234 minecraft:cyan_terracotta
fill 276 96 236 276 97 236 minecraft:cyan_terracotta
fill 276 96 243 276 97 243 minecraft:light_gray_concrete
fill 276 96 245 276 97 245 minecraft:light_gray_concrete
fill 276 96 247 276 97 247 minecraft:light_gray_concrete
fill 276 96 249 276 97 249 minecraft:light_gray_concrete
fill 276 96 251 276 97 251 minecraft:light_gray_concrete
fill 276 96 253 276 97 253 minecraft:light_gray_concrete
fill 276 96 262 276 97 262 minecraft:light_gray_concrete
fill 276 96 264 276 97 264 minecraft:light_gray_concrete
fill 276 96 266 276 97 266 minecraft:light_gray_concrete
fill 276 96 268 276 97 268 minecraft:light_gray_concrete
setblock 276 96 270 minecraft:ochre_froglight
fill 277 96 238 277 126 239 minecraft:black_concrete
setblock 277 96 240 minecraft:pearlescent_froglight
fill 277 96 241 277 102 241 minecraft:black_concrete
fill 277 96 248 277 168 248 minecraft:black_concrete
fill 277 96 255 277 122 255 minecraft:black_concrete
fill 277 96 270 277 308 270 minecraft:black_concrete
fill 235 97 245 235 144 245 minecraft:black_concrete
setblock 236 97 247 minecraft:sea_lantern
setblock 236 97 249 minecraft:sea_lantern
setblock 236 97 251 minecraft:sea_lantern
setblock 236 97 253 minecraft:sea_lantern
setblock 236 97 255 minecraft:sea_lantern
setblock 236 97 257 minecraft:sea_lantern
setblock 236 97 259 minecraft:sea_lantern
setblock 236 97 261 minecraft:sea_lantern
setblock 237 97 248 minecraft:sea_lantern
setblock 237 97 250 minecraft:sea_lantern
setblock 237 97 252 minecraft:sea_lantern
setblock 237 97 254 minecraft:sea_lantern
setblock 237 97 256 minecraft:sea_lantern
setblock 237 97 258 minecraft:sea_lantern
setblock 237 97 260 minecraft:sea_lantern
setblock 237 97 262 minecraft:sea_lantern
setblock 238 97 238 minecraft:light[level=12]
setblock 238 97 247 minecraft:sea_lantern
setblock 238 97 249 minecraft:sea_lantern
setblock 238 97 251 minecraft:sea_lantern
setblock 238 97 253 minecraft:sea_lantern
setblock 238 97 255 minecraft:sea_lantern
setblock 238 97 257 minecraft:sea_lantern
setblock 238 97 259 minecraft:sea_lantern
setblock 238 97 261 minecraft:sea_lantern
setblock 239 97 248 minecraft:sea_lantern
setblock 239 97 250 minecraft:sea_lantern
setblock 239 97 252 minecraft:sea_lantern
setblock 239 97 254 minecraft:sea_lantern
setblock 239 97 256 minecraft:sea_lantern
setblock 239 97 258 minecraft:sea_lantern
setblock 239 97 260 minecraft:sea_lantern
setblock 239 97 262 minecraft:sea_lantern
setblock 240 97 247 minecraft:sea_lantern
setblock 240 97 249 minecraft:sea_lantern
setblock 240 97 251 minecraft:sea_lantern
setblock 240 97 253 minecraft:sea_lantern
setblock 240 97 255 minecraft:sea_lantern
setblock 240 97 257 minecraft:sea_lantern
setblock 240 97 259 minecraft:sea_lantern
setblock 240 97 261 minecraft:sea_lantern
setblock 241 97 252 minecraft:sea_lantern
setblock 241 97 254 minecraft:sea_lantern
setblock 241 97 256 minecraft:sea_lantern
setblock 241 97 258 minecraft:sea_lantern
setblock 241 97 260 minecraft:sea_lantern
setblock 241 97 262 minecraft:sea_lantern
setblock 242 97 253 minecraft:sea_lantern
setblock 242 97 255 minecraft:sea_lantern
setblock 242 97 257 minecraft:sea_lantern
setblock 242 97 259 minecraft:sea_lantern
setblock 242 97 261 minecraft:sea_lantern
setblock 245 97 231 minecraft:light[level=12]
setblock 245 97 238 minecraft:light[level=12]
setblock 245 97 245 minecraft:light[level=12]
setblock 245 97 252 minecraft:light[level=12]
setblock 245 97 259 minecraft:light[level=12]
setblock 245 97 266 minecraft:light[level=12]
setblock 252 97 238 minecraft:light[level=12]
setblock 252 97 245 minecraft:light[level=12]
setblock 252 97 252 minecraft:light[level=12]
setblock 252 97 259 minecraft:light[level=12]
setblock 259 97 238 minecraft:light[level=12]
setblock 259 97 245 minecraft:light[level=12]
setblock 259 97 252 minecraft:light[level=12]
setblock 259 97 259 minecraft:light[level=12]
setblock 266 97 229 minecraft:sea_lantern
setblock 266 97 231 minecraft:sea_lantern
setblock 266 97 233 minecraft:sea_lantern
setblock 266 97 235 minecraft:sea_lantern
setblock 266 97 237 minecraft:sea_lantern
setblock 266 97 239 minecraft:sea_lantern
setblock 266 97 245 minecraft:light[level=12]
setblock 266 97 252 minecraft:light[level=12]
setblock 266 97 259 minecraft:light[level=12]
setblock 266 97 266 minecraft:light[level=12]
setblock 267 97 230 minecraft:sea_lantern
setblock 267 97 232 minecraft:sea_lantern
setblock 267 97 234 minecraft:sea_lantern
setblock 267 97 236 minecraft:sea_lantern
setblock 267 97 238 minecraft:sea_lantern
setblock 268 97 229 minecraft:sea_lantern
setblock 268 97 231 minecraft:sea_lantern
setblock 268 97 233 minecraft:sea_lantern
setblock 268 97 235 minecraft:sea_lantern
setblock 268 97 237 minecraft:sea_lantern
setblock 268 97 239 minecraft:sea_lantern
setblock 269 97 230 minecraft:sea_lantern
setblock 269 97 232 minecraft:sea_lantern
setblock 269 97 234 minecraft:sea_lantern
setblock 269 97 236 minecraft:sea_lantern
setblock 269 97 238 minecraft:sea_lantern
setblock 270 97 229 minecraft:sea_lantern
setblock 270 97 231 minecraft:sea_lantern
setblock 270 97 233 minecraft:sea_lantern
setblock 270 97 235 minecraft:sea_lantern
setblock 270 97 237 minecraft:sea_lantern
setblock 270 97 239 minecraft:sea_lantern
setblock 271 97 230 minecraft:sea_lantern
setblock 271 97 232 minecraft:sea_lantern
setblock 271 97 234 minecraft:sea_lantern
setblock 271 97 236 minecraft:sea_lantern
setblock 271 97 238 minecraft:sea_lantern
setblock 272 97 229 minecraft:sea_lantern
setblock 272 97 231 minecraft:sea_lantern
setblock 272 97 233 minecraft:sea_lantern
setblock 272 97 235 minecraft:sea_lantern
setblock 272 97 237 minecraft:sea_lantern
setblock 272 97 239 minecraft:sea_lantern
setblock 273 97 230 minecraft:sea_lantern
setblock 273 97 232 minecraft:sea_lantern
setblock 273 97 234 minecraft:sea_lantern
setblock 273 97 236 minecraft:sea_lantern
setblock 273 97 238 minecraft:sea_lantern
setblock 273 97 259 minecraft:light[level=12]
setblock 274 97 229 minecraft:sea_lantern
setblock 274 97 231 minecraft:sea_lantern
setblock 274 97 233 minecraft:sea_lantern
setblock 274 97 235 minecraft:sea_lantern
setblock 274 97 237 minecraft:sea_lantern
setblock 274 97 239 minecraft:sea_lantern
setblock 275 97 230 minecraft:sea_lantern
setblock 275 97 232 minecraft:sea_lantern
setblock 275 97 234 minecraft:sea_lantern
setblock 275 97 236 minecraft:sea_lantern
setblock 275 97 238 minecraft:sea_lantern
setblock 276 97 229 minecraft:sea_lantern
setblock 276 97 231 minecraft:sea_lantern
setblock 276 97 233 minecraft:sea_lantern
setblock 276 97 235 minecraft:sea_lantern
setblock 276 97 237 minecraft:sea_lantern
setblock 276 97 239 minecraft:sea_lantern
fill 276 97 270 276 308 270 minecraft:black_concrete
fill 277 97 240 277 98 240 minecraft:black_concrete
setblock 277 97 247 minecraft:purple_concrete
fill 235 98 236 235 118 237 minecraft:black_concrete
setblock 235 98 238 minecraft:purple_concrete
fill 235 98 239 235 120 239 minecraft:black_concrete
setblock 236 98 230 minecraft:sea_lantern
setblock 236 98 232 minecraft:black_stained_glass
setblock 236 98 234 minecraft:light_blue_stained_glass
setblock 236 98 236 minecraft:pearlescent_froglight
setblock 236 98 243 minecraft:pearlescent_froglight
setblock 236 98 245 minecraft:black_stained_glass
setblock 236 98 247 minecraft:pearlescent_froglight
setblock 236 98 249 minecraft:ochre_froglight
setblock 236 98 251 minecraft:black_stained_glass
setblock 236 98 253 minecraft:black_stained_glass
setblock 236 98 255 minecraft:gray_concrete
setblock 236 98 257 minecraft:gray_concrete
setblock 236 98 259 minecraft:gray_concrete
fill 236 98 261 236 198 261 minecraft:cyan_terracotta
setblock 236 98 262 minecraft:cyan_stained_glass
setblock 236 98 264 minecraft:black_stained_glass
setblock 236 98 266 minecraft:black_stained_glass
setblock 236 98 268 minecraft:black_stained_glass
setblock 237 98 229 minecraft:black_stained_glass
setblock 237 98 237 minecraft:pearlescent_froglight
setblock 237 98 242 minecraft:pearlescent_froglight
fill 237 98 243 237 183 246 minecraft:light_gray_concrete
setblock 237 98 248 minecraft:gray_concrete
setblock 237 98 250 minecraft:gray_concrete
setblock 237 98 252 minecraft:gray_concrete
setblock 237 98 254 minecraft:gray_concrete
setblock 237 98 255 minecraft:black_stained_glass
setblock 237 98 256 minecraft:gray_concrete
setblock 237 98 258 minecraft:gray_concrete
setblock 237 98 260 minecraft:gray_concrete
setblock 237 98 261 minecraft:ochre_froglight
fill 237 98 262 237 198 262 minecraft:cyan_terracotta
setblock 237 98 269 minecraft:ochre_froglight
setblock 238 98 247 minecraft:gray_concrete
setblock 238 98 249 minecraft:gray_concrete
setblock 238 98 251 minecraft:gray_concrete
setblock 238 98 253 minecraft:gray_concrete
setblock 238 98 255 minecraft:gray_concrete
setblock 238 98 257 minecraft:gray_concrete
setblock 238 98 259 minecraft:gray_concrete
fill 238 98 261 238 198 261 minecraft:cyan_terracotta
setblock 239 98 229 minecraft:sea_lantern
setblock 239 98 237 minecraft:magenta_stained_glass
setblock 239 98 242 minecraft:black_stained_glass
setblock 239 98 248 minecraft:gray_concrete
setblock 239 98 250 minecraft:gray_concrete
setblock 239 98 252 minecraft:gray_concrete
setblock 239 98 254 minecraft:gray_concrete
setblock 239 98 255 minecraft:pearlescent_froglight
setblock 239 98 256 minecraft:gray_concrete
setblock 239 98 258 minecraft:gray_concrete
setblock 239 98 260 minecraft:gray_concrete
setblock 239 98 261 minecraft:magenta_stained_glass
fill 239 98 262 239 169 262 minecraft:cyan_terracotta
setblock 239 98 269 minecraft:sea_lantern
setblock 240 98 247 minecraft:gray_concrete
setblock 240 98 249 minecraft:gray_concrete
setblock 240 98 251 minecraft:gray_concrete
setblock 240 98 253 minecraft:gray_concrete
setblock 240 98 255 minecraft:gray_concrete
setblock 240 98 257 minecraft:gray_concrete
setblock 240 98 259 minecraft:gray_concrete
fill 240 98 261 240 169 261 minecraft:cyan_terracotta
setblock 241 98 229 minecraft:sea_lantern
setblock 241 98 237 minecraft:sea_lantern
setblock 241 98 243 minecraft:black_stained_glass
setblock 241 98 245 minecraft:pearlescent_froglight
setblock 241 98 247 minecraft:black_stained_glass
setblock 241 98 249 minecraft:sea_lantern
setblock 241 98 251 minecraft:black_stained_glass
setblock 241 98 252 minecraft:gray_concrete
setblock 241 98 253 minecraft:black_stained_glass
setblock 241 98 254 minecraft:gray_concrete
setblock 241 98 256 minecraft:gray_concrete
setblock 241 98 258 minecraft:gray_concrete
setblock 241 98 260 minecraft:gray_concrete
setblock 241 98 261 minecraft:ochre_froglight
fill 241 98 262 241 198 262 minecraft:cyan_terracotta
setblock 241 98 269 minecraft:magenta_stained_glass
setblock 242 98 253 minecraft:gray_concrete
setblock 242 98 255 minecraft:gray_concrete
setblock 242 98 257 minecraft:gray_concrete
setblock 242 98 259 minecraft:gray_concrete
fill 242 98 261 242 198 261 minecraft:cyan_terracotta
setblock 243 98 229 minecraft:black_stained_glass
setblock 243 98 237 minecraft:cyan_stained_glass
setblock 243 98 261 minecraft:cyan_stained_glass
setblock 243 98 269 minecraft:sea_lantern
setblock 244 98 230 minecraft:ochre_froglight
setblock 244 98 232 minecraft:black_stained_glass
setblock 244 98 234 minecraft:sea_lantern
setblock 244 98 236 minecraft:black_stained_glass
setblock 244 98 262 minecraft:black_stained_glass
setblock 244 98 264 minecraft:magenta_stained_glass
setblock 244 98 266 minecraft:sea_lantern
setblock 244 98 268 minecraft:ochre_froglight
setblock 249 98 230 minecraft:black_stained_glass
setblock 249 98 232 minecraft:cyan_stained_glass
setblock 249 98 265 minecraft:black_stained_glass
setblock 249 98 267 minecraft:cyan_stained_glass
setblock 250 98 229 minecraft:black_stained_glass
setblock 250 98 234 minecraft:black_stained_glass
setblock 250 98 264 minecraft:cyan_stained_glass
setblock 250 98 269 minecraft:black_stained_glass
setblock 252 98 229 minecraft:black_stained_glass
setblock 252 98 234 minecraft:black_stained_glass
setblock 252 98 264 minecraft:black_stained_glass
setblock 252 98 269 minecraft:sea_lantern
setblock 254 98 229 minecraft:black_stained_glass
setblock 254 98 234 minecraft:cyan_stained_glass
setblock 254 98 264 minecraft:black_stained_glass
setblock 254 98 269 minecraft:black_stained_glass
setblock 256 98 229 minecraft:black_stained_glass
setblock 256 98 234 minecraft:black_stained_glass
setblock 256 98 264 minecraft:light_blue_stained_glass
setblock 256 98 269 minecraft:light_blue_stained_glass
setblock 258 98 229 minecraft:black_stained_glass
setblock 258 98 234 minecraft:light_blue_stained_glass
setblock 258 98 264 minecraft:black_stained_glass
setblock 258 98 269 minecraft:black_stained_glass
setblock 260 98 229 minecraft:sea_lantern
setblock 260 98 234 minecraft:cyan_stained_glass
setblock 260 98 264 minecraft:pearlescent_froglight
setblock 260 98 269 minecraft:black_stained_glass
setblock 262 98 230 minecraft:black_stained_glass
setblock 262 98 232 minecraft:cyan_stained_glass
setblock 262 98 265 minecraft:black_stained_glass
setblock 262 98 267 minecraft:black_stained_glass
setblock 266 98 229 minecraft:gray_concrete
setblock 266 98 231 minecraft:gray_concrete
setblock 266 98 233 minecraft:gray_concrete
setblock 266 98 235 minecraft:gray_concrete
setblock 266 98 237 minecraft:gray_concrete
setblock 266 98 239 minecraft:gray_concrete
setblock 267 98 230 minecraft:gray_concrete
fill 267 98 232 268 98 232 minecraft:gray_concrete
setblock 267 98 234 minecraft:gray_concrete
setblock 267 98 236 minecraft:gray_concrete
setblock 267 98 238 minecraft:gray_concrete
fill 268 98 229 268 156 229 minecraft:cyan_terracotta
setblock 268 98 230 minecraft:sea_lantern
fill 268 98 231 268 156 231 minecraft:cyan_terracotta
fill 268 98 233 268 156 233 minecraft:cyan_terracotta
setblock 268 98 234 minecraft:ochre_froglight
fill 268 98 235 268 208 235 minecraft:cyan_terracotta
setblock 268 98 236 minecraft:black_stained_glass
fill 268 98 237 268 208 237 minecraft:cyan_terracotta
setblock 268 98 239 minecraft:gray_concrete
setblock 268 98 262 minecraft:black_stained_glass
setblock 268 98 264 minecraft:black_stained_glass
setblock 268 98 266 minecraft:cyan_stained_glass
setblock 268 98 268 minecraft:black_stained_glass
setblock 269 98 229 minecraft:ochre_froglight
fill 269 98 230 269 156 230 minecraft:cyan_terracotta
fill 269 98 232 269 156 232 minecraft:cyan_terracotta
fill 269 98 234 269 156 234 minecraft:cyan_terracotta
fill 269 98 236 269 208 236 minecraft:cyan_terracotta
setblock 269 98 237 minecraft:sea_lantern
setblock 269 98 238 minecraft:gray_concrete
setblock 269 98 261 minecraft:black_stained_glass
setblock 269 98 269 minecraft:cyan_stained_glass
fill 270 98 229 270 156 229 minecraft:cyan_terracotta
fill 270 98 231 270 156 231 minecraft:cyan_terracotta
fill 270 98 233 270 156 233 minecraft:cyan_terracotta
fill 270 98 235 270 208 235 minecraft:cyan_terracotta
fill 270 98 237 270 208 237 minecraft:cyan_terracotta
setblock 270 98 239 minecraft:gray_concrete
setblock 271 98 229 minecraft:sea_lantern
fill 271 98 230 271 156 230 minecraft:cyan_terracotta
fill 271 98 232 271 156 232 minecraft:cyan_terracotta
fill 271 98 234 271 156 234 minecraft:cyan_terracotta
fill 271 98 236 271 208 236 minecraft:cyan_terracotta
setblock 271 98 237 minecraft:black_stained_glass
setblock 271 98 238 minecraft:gray_concrete
setblock 271 98 243 minecraft:ochre_froglight
setblock 271 98 245 minecraft:black_stained_glass
setblock 271 98 247 minecraft:ochre_froglight
setblock 271 98 249 minecraft:ochre_froglight
setblock 271 98 251 minecraft:light_blue_stained_glass
setblock 271 98 253 minecraft:black_stained_glass
setblock 271 98 261 minecraft:pearlescent_froglight
setblock 271 98 269 minecraft:black_stained_glass
fill 272 98 229 272 156 229 minecraft:cyan_terracotta
fill 272 98 231 272 156 231 minecraft:cyan_terracotta
fill 272 98 233 272 156 233 minecraft:cyan_terracotta
fill 272 98 235 272 198 235 minecraft:cyan_terracotta
fill 272 98 237 272 199 237 minecraft:cyan_terracotta
setblock 272 98 239 minecraft:gray_concrete
setblock 272 98 242 minecraft:light_blue_stained_glass
setblock 272 98 255 minecraft:sea_lantern
setblock 273 98 229 minecraft:cyan_stained_glass
fill 273 98 230 273 156 230 minecraft:cyan_terracotta
fill 273 98 232 273 156 232 minecraft:cyan_terracotta
fill 273 98 234 273 156 234 minecraft:cyan_terracotta
fill 273 98 236 273 199 236 minecraft:cyan_terracotta
setblock 273 98 237 minecraft:black_stained_glass
setblock 273 98 238 minecraft:gray_concrete
setblock 273 98 261 minecraft:light_blue_stained_glass
setblock 273 98 269 minecraft:black_stained_glass
setblock 274 98 228 minecraft:purple_concrete
fill 274 98 229 274 208 229 minecraft:cyan_terracotta
fill 274 98 231 274 208 231 minecraft:cyan_terracotta
fill 274 98 233 274 208 233 minecraft:cyan_terracotta
fill 274 98 235 274 208 235 minecraft:cyan_terracotta
fill 274 98 237 274 208 237 minecraft:cyan_terracotta
setblock 274 98 239 minecraft:gray_concrete
setblock 274 98 242 minecraft:black_stained_glass
setblock 274 98 255 minecraft:black_stained_glass
setblock 275 98 229 minecraft:cyan_stained_glass
fill 275 98 230 275 208 230 minecraft:cyan_terracotta
fill 275 98 232 275 208 232 minecraft:cyan_terracotta
fill 275 98 234 275 208 234 minecraft:cyan_terracotta
fill 275 98 236 275 208 236 minecraft:cyan_terracotta
setblock 275 98 237 minecraft:magenta_stained_glass
setblock 275 98 238 minecraft:gray_concrete
setblock 275 98 261 minecraft:ochre_froglight
setblock 275 98 269 minecraft:ochre_froglight
fill 276 98 229 276 208 229 minecraft:cyan_terracotta
setblock 276 98 230 minecraft:black_stained_glass
fill 276 98 231 276 208 231 minecraft:cyan_terracotta
setblock 276 98 232 minecraft:black_stained_glass
fill 276 98 233 276 208 233 minecraft:cyan_terracotta
setblock 276 98 234 minecraft:black_stained_glass
fill 276 98 235 276 208 235 minecraft:cyan_terracotta
setblock 276 98 236 minecraft:ochre_froglight
fill 276 98 237 276 208 237 minecraft:cyan_terracotta
setblock 276 98 239 minecraft:gray_concrete
setblock 276 98 243 minecraft:black_stained_glass
setblock 276 98 245 minecraft:black_stained_glass
setblock 276 98 247 minecraft:black_stained_glass
setblock 276 98 249 minecraft:light_blue_stained_glass
setblock 276 98 251 minecraft:pearlescent_froglight
setblock 276 98 253 minecraft:black_stained_glass
setblock 276 98 262 minecraft:black_stained_glass
setblock 276 98 264 minecraft:magenta_stained_glass
setblock 276 98 266 minecraft:sea_lantern
setblock 276 98 268 minecraft:black_stained_glass
fill 277 98 247 277 115 247 minecraft:black_concrete
fill 235 99 238 235 110 238 minecraft:black_concrete
fill 236 99 230 236 100 230 minecraft:light_gray_concrete
fill 236 99 232 236 100 232 minecraft:light_gray_concrete
fill 236 99 234 236 100 234 minecraft:light_gray_concrete
fill 236 99 236 236 100 236 minecraft:light_gray_concrete
fill 236 99 243 236 100 243 minecraft:light_gray_concrete
fill 236 99 245 236 100 245 minecraft:light_gray_concrete
fill 236 99 247 240 100 255 minecraft:light_gray_concrete
fill 236 99 262 236 100 262 minecraft:cyan_terracotta
fill 236 99 264 236 100 264 minecraft:cyan_terracotta
fill 236 99 266 236 100 266 minecraft:cyan_terracotta
fill 236 99 268 236 100 268 minecraft:cyan_terracotta
fill 237 99 229 237 100 229 minecraft:light_gray_concrete
fill 237 99 237 237 100 237 minecraft:light_gray_concrete
fill 237 99 242 237 100 242 minecraft:light_gray_concrete
fill 237 99 261 237 100 261 minecraft:cyan_terracotta
fill 237 99 269 237 100 269 minecraft:cyan_terracotta
fill 239 99 229 239 100 229 minecraft:light_gray_concrete
fill 239 99 237 239 100 237 minecraft:light_gray_concrete
fill 239 99 242 239 100 242 minecraft:light_gray_concrete
fill 239 99 261 239 100 261 minecraft:cyan_terracotta
fill 239 99 269 239 100 269 minecraft:cyan_terracotta
fill 241 99 229 241 100 229 minecraft:light_gray_concrete
fill 241 99 237 241 100 237 minecraft:light_gray_concrete
fill 241 99 243 241 100 243 minecraft:light_gray_concrete
fill 241 99 245 241 100 245 minecraft:light_gray_concrete
fill 241 99 247 241 100 247 minecraft:light_gray_concrete
fill 241 99 249 241 100 249 minecraft:light_gray_concrete
fill 241 99 251 241 100 255 minecraft:light_gray_concrete
fill 241 99 261 241 100 261 minecraft:cyan_terracotta
fill 241 99 269 241 100 269 minecraft:cyan_terracotta
fill 243 99 229 243 100 229 minecraft:light_gray_concrete
fill 243 99 237 243 100 237 minecraft:light_gray_concrete
fill 243 99 261 243 100 261 minecraft:cyan_terracotta
fill 243 99 269 243 100 269 minecraft:cyan_terracotta
fill 244 99 230 244 100 230 minecraft:light_gray_concrete
fill 244 99 232 244 100 232 minecraft:light_gray_concrete
fill 244 99 234 244 100 234 minecraft:light_gray_concrete
fill 244 99 236 244 100 236 minecraft:light_gray_concrete
fill 244 99 262 244 100 262 minecraft:cyan_terracotta
fill 244 99 264 244 100 264 minecraft:cyan_terracotta
fill 244 99 266 244 100 266 minecraft:cyan_terracotta
fill 244 99 268 244 100 268 minecraft:cyan_terracotta
fill 249 99 230 249 100 230 minecraft:light_gray_concrete
fill 249 99 232 249 100 232 minecraft:light_gray_concrete
fill 249 99 265 249 100 265 minecraft:cyan_terracotta
fill 249 99 267 249 100 267 minecraft:cyan_terracotta
fill 250 99 229 250 100 229 minecraft:light_gray_concrete
fill 250 99 234 250 100 234 minecraft:light_gray_concrete
fill 250 99 264 250 100 264 minecraft:cyan_terracotta
fill 250 99 269 250 100 269 minecraft:cyan_terracotta
fill 252 99 229 252 100 229 minecraft:light_gray_concrete
fill 252 99 234 252 100 234 minecraft:light_gray_concrete
fill 252 99 264 252 100 264 minecraft:cyan_terracotta
fill 252 99 269 252 100 269 minecraft:cyan_terracotta
fill 254 99 229 254 100 229 minecraft:light_gray_concrete
fill 254 99 234 254 100 234 minecraft:light_gray_concrete
fill 254 99 264 254 100 264 minecraft:cyan_terracotta
fill 254 99 269 254 100 269 minecraft:cyan_terracotta
fill 256 99 229 256 100 229 minecraft:light_gray_concrete
fill 256 99 234 256 100 234 minecraft:light_gray_concrete
fill 256 99 264 256 100 264 minecraft:cyan_terracotta
fill 256 99 269 256 100 269 minecraft:cyan_terracotta
fill 258 99 229 258 100 229 minecraft:light_gray_concrete
fill 258 99 234 258 100 234 minecraft:light_gray_concrete
fill 258 99 264 258 100 264 minecraft:cyan_terracotta
fill 258 99 269 258 100 269 minecraft:cyan_terracotta
fill 260 99 229 260 100 229 minecraft:light_gray_concrete
fill 260 99 234 260 100 234 minecraft:light_gray_concrete
fill 260 99 264 260 100 264 minecraft:cyan_terracotta
fill 260 99 269 260 100 269 minecraft:cyan_terracotta
fill 262 99 230 262 100 230 minecraft:light_gray_concrete
fill 262 99 232 262 100 232 minecraft:light_gray_concrete
fill 262 99 265 262 100 265 minecraft:cyan_terracotta
fill 262 99 267 262 100 267 minecraft:cyan_terracotta
fill 268 99 230 268 100 230 minecraft:cyan_terracotta
fill 268 99 232 268 100 232 minecraft:cyan_terracotta
fill 268 99 234 268 100 234 minecraft:cyan_terracotta
fill 268 99 236 268 100 236 minecraft:cyan_terracotta
fill 268 99 262 268 100 262 minecraft:light_gray_concrete
fill 268 99 264 268 100 264 minecraft:light_gray_concrete
fill 268 99 266 268 100 266 minecraft:light_gray_concrete
fill 268 99 268 268 100 268 minecraft:light_gray_concrete
fill 269 99 229 269 100 229 minecraft:cyan_terracotta
fill 269 99 237 269 100 237 minecraft:cyan_terracotta
fill 269 99 261 269 100 261 minecraft:light_gray_concrete
fill 269 99 269 269 100 269 minecraft:light_gray_concrete
fill 271 99 229 271 100 229 minecraft:cyan_terracotta
fill 271 99 237 271 100 237 minecraft:cyan_terracotta
fill 271 99 243 271 100 243 minecraft:light_gray_concrete
fill 271 99 245 271 100 245 minecraft:light_gray_concrete
fill 271 99 247 271 100 247 minecraft:light_gray_concrete
fill 271 99 249 271 100 249 minecraft:light_gray_concrete
fill 271 99 251 271 100 251 minecraft:light_gray_concrete
fill 271 99 253 271 100 253 minecraft:light_gray_concrete
fill 271 99 261 271 100 261 minecraft:light_gray_concrete
fill 271 99 269 271 100 269 minecraft:light_gray_concrete
fill 272 99 242 272 100 242 minecraft:light_gray_concrete
fill 272 99 255 272 100 255 minecraft:light_gray_concrete
fill 273 99 229 273 100 229 minecraft:cyan_terracotta
fill 273 99 237 273 100 237 minecraft:cyan_terracotta
fill 273 99 261 273 100 261 minecraft:light_gray_concrete
fill 273 99 269 273 100 269 minecraft:light_gray_concrete
setblock 274 99 228 minecraft:cyan_concrete
fill 274 99 242 274 100 242 minecraft:light_gray_concrete
fill 274 99 255 274 100 255 minecraft:light_gray_concrete
fill 275 99 229 275 100 229 minecraft:cyan_terracotta
fill 275 99 237 275 100 237 minecraft:cyan_terracotta
fill 275 99 261 275 100 261 minecraft:light_gray_concrete
fill 275 99 269 275 100 269 minecraft:light_gray_concrete
fill 276 99 230 276 100 230 minecraft:cyan_terracotta
fill 276 99 232 276 100 232 minecraft:cyan_terracotta
fill 276 99 234 276 100 234 minecraft:cyan_terracotta
fill 276 99 236 276 100 236 minecraft:cyan_terracotta
fill 276 99 243 276 100 243 minecraft:light_gray_concrete
fill 276 99 245 276 100 245 minecraft:light_gray_concrete
fill 276 99 247 276 100 247 minecraft:light_gray_concrete
fill 276 99 249 276 100 249 minecraft:light_gray_concrete
fill 276 99 251 276 100 251 minecraft:light_gray_concrete
fill 276 99 253 276 100 253 minecraft:light_gray_concrete
fill 276 99 262 276 100 262 minecraft:light_gray_concrete
fill 276 99 264 276 100 264 minecraft:light_gray_concrete
fill 276 99 266 276 100 266 minecraft:light_gray_concrete
fill 276 99 268 276 100 268 minecraft:light_gray_concrete
setblock 277 99 240 minecraft:cyan_concrete
setblock 251 100 270 minecraft:purple_concrete
fill 274 100 228 274 113 228 minecraft:black_concrete
fill 277 100 240 277 171 240 minecraft:black_concrete
setblock 236 101 230 minecraft:black_stained_glass
setblock 236 101 232 minecraft:black_stained_glass
setblock 236 101 234 minecraft:cyan_stained_glass
setblock 236 101 236 minecraft:pearlescent_froglight
setblock 236 101 243 minecraft:black_stained_glass
setblock 236 101 245 minecraft:black_stained_glass
setblock 236 101 247 minecraft:black_stained_glass
fill 236 101 248 240 169 248 minecraft:light_gray_concrete
setblock 236 101 249 minecraft:ochre_froglight
fill 236 101 250 240 169 250 minecraft:light_gray_concrete
setblock 236 101 251 minecraft:magenta_stained_glass
fill 236 101 252 241 168 252 minecraft:light_gray_concrete
setblock 236 101 253 minecraft:black_stained_glass
fill 236 101 254 236 159 255 minecraft:light_gray_concrete
setblock 236 101 262 minecraft:black_stained_glass
setblock 236 101 264 minecraft:pearlescent_froglight
setblock 236 101 266 minecraft:cyan_stained_glass
setblock 236 101 268 minecraft:ochre_froglight
setblock 237 101 229 minecraft:black_stained_glass
setblock 237 101 237 minecraft:pearlescent_froglight
setblock 237 101 242 minecraft:sea_lantern
fill 237 101 247 240 171 247 minecraft:light_gray_concrete
fill 237 101 249 240 169 249 minecraft:light_gray_concrete
fill 237 101 251 240 168 251 minecraft:light_gray_concrete
fill 237 101 253 240 159 254 minecraft:light_gray_concrete
setblock 237 101 255 minecraft:pearlescent_froglight
setblock 237 101 261 minecraft:black_stained_glass
setblock 237 101 269 minecraft:magenta_stained_glass
setblock 238 101 239 minecraft:light[level=15]
fill 238 101 255 238 169 255 minecraft:light_gray_concrete
setblock 239 101 229 minecraft:light_blue_stained_glass
setblock 239 101 237 minecraft:light_blue_stained_glass
setblock 239 101 242 minecraft:light_blue_stained_glass
setblock 239 101 255 minecraft:black_stained_glass
setblock 239 101 261 minecraft:ochre_froglight
setblock 239 101 269 minecraft:sea_lantern
fill 240 101 255 241 159 255 minecraft:light_gray_concrete
setblock 241 101 229 minecraft:black_stained_glass
setblock 241 101 237 minecraft:black_stained_glass
setblock 241 101 243 minecraft:light_blue_stained_glass
setblock 241 101 245 minecraft:black_stained_glass
setblock 241 101 247 minecraft:cyan_stained_glass
setblock 241 101 249 minecraft:light_blue_stained_glass
setblock 241 101 251 minecraft:light_blue_stained_glass
setblock 241 101 253 minecraft:black_stained_glass
fill 241 101 254 241 159 254 minecraft:light_gray_concrete
setblock 241 101 261 minecraft:magenta_stained_glass
setblock 241 101 269 minecraft:sea_lantern
setblock 243 101 229 minecraft:black_stained_glass
setblock 243 101 237 minecraft:sea_lantern
setblock 243 101 261 minecraft:magenta_stained_glass
setblock 243 101 269 minecraft:ochre_froglight
setblock 244 101 230 minecraft:cyan_stained_glass
setblock 244 101 232 minecraft:sea_lantern
setblock 244 101 234 minecraft:black_stained_glass
setblock 244 101 236 minecraft:pearlescent_froglight
setblock 244 101 262 minecraft:light_blue_stained_glass
setblock 244 101 264 minecraft:magenta_stained_glass
setblock 244 101 266 minecraft:pearlescent_froglight
setblock 244 101 268 minecraft:black_stained_glass
setblock 246 101 231 minecraft:light[level=15]
setblock 246 101 239 minecraft:light[level=15]
setblock 246 101 247 minecraft:light[level=15]
setblock 246 101 255 minecraft:light[level=15]
setblock 246 101 263 minecraft:light[level=15]
setblock 249 101 230 minecraft:cyan_stained_glass
setblock 249 101 232 minecraft:ochre_froglight
setblock 249 101 265 minecraft:black_stained_glass
setblock 249 101 267 minecraft:black_stained_glass
setblock 250 101 229 minecraft:pearlescent_froglight
setblock 250 101 234 minecraft:black_stained_glass
setblock 250 101 264 minecraft:ochre_froglight
setblock 250 101 269 minecraft:light_blue_stained_glass
fill 251 101 270 251 308 270 minecraft:black_concrete
setblock 252 101 229 minecraft:pearlescent_froglight
setblock 252 101 234 minecraft:ochre_froglight
setblock 252 101 264 minecraft:pearlescent_froglight
setblock 252 101 269 minecraft:black_stained_glass
setblock 254 101 229 minecraft:sea_lantern
setblock 254 101 234 minecraft:black_stained_glass
setblock 254 101 239 minecraft:light[level=15]
setblock 254 101 247 minecraft:light[level=15]
setblock 254 101 255 minecraft:light[level=15]
setblock 254 101 263 minecraft:light[level=15]
setblock 254 101 264 minecraft:light_blue_stained_glass
setblock 254 101 269 minecraft:black_stained_glass
setblock 256 101 229 minecraft:black_stained_glass
setblock 256 101 234 minecraft:black_stained_glass
setblock 256 101 264 minecraft:ochre_froglight
setblock 256 101 269 minecraft:sea_lantern
setblock 258 101 229 minecraft:cyan_stained_glass
setblock 258 101 234 minecraft:black_stained_glass
setblock 258 101 264 minecraft:black_stained_glass
setblock 258 101 269 minecraft:pearlescent_froglight
setblock 260 101 229 minecraft:light_blue_stained_glass
setblock 260 101 234 minecraft:cyan_stained_glass
setblock 260 101 264 minecraft:black_stained_glass
setblock 260 101 269 minecraft:ochre_froglight
setblock 262 101 230 minecraft:black_stained_glass
setblock 262 101 232 minecraft:black_stained_glass
setblock 262 101 239 minecraft:light[level=15]
setblock 262 101 247 minecraft:light[level=15]
setblock 262 101 255 minecraft:light[level=15]
setblock 262 101 263 minecraft:light[level=15]
setblock 262 101 265 minecraft:black_stained_glass
setblock 262 101 267 minecraft:ochre_froglight
setblock 265 101 270 minecraft:ochre_froglight
setblock 268 101 230 minecraft:black_stained_glass
setblock 268 101 232 minecraft:black_stained_glass
setblock 268 101 234 minecraft:pearlescent_froglight
setblock 268 101 236 minecraft:black_stained_glass
setblock 268 101 262 minecraft:black_stained_glass
setblock 268 101 264 minecraft:pearlescent_froglight
setblock 268 101 266 minecraft:black_stained_glass
setblock 268 101 268 minecraft:magenta_stained_glass
setblock 269 101 229 minecraft:black_stained_glass
setblock 269 101 237 minecraft:black_stained_glass
setblock 269 101 261 minecraft:magenta_stained_glass
setblock 269 101 269 minecraft:sea_lantern
setblock 270 101 239 minecraft:light[level=15]
setblock 270 101 247 minecraft:light[level=15]
setblock 270 101 255 minecraft:light[level=15]
setblock 271 101 229 minecraft:ochre_froglight
setblock 271 101 237 minecraft:ochre_froglight
setblock 271 101 243 minecraft:cyan_stained_glass
setblock 271 101 245 minecraft:black_stained_glass
setblock 271 101 247 minecraft:black_stained_glass
setblock 271 101 249 minecraft:cyan_stained_glass
setblock 271 101 251 minecraft:sea_lantern
setblock 271 101 253 minecraft:ochre_froglight
setblock 271 101 261 minecraft:black_stained_glass
setblock 271 101 269 minecraft:ochre_froglight
setblock 272 101 242 minecraft:magenta_stained_glass
setblock 272 101 255 minecraft:ochre_froglight
setblock 273 101 229 minecraft:pearlescent_froglight
setblock 273 101 237 minecraft:sea_lantern
setblock 273 101 261 minecraft:pearlescent_froglight
setblock 273 101 269 minecraft:cyan_stained_glass
setblock 274 101 242 minecraft:pearlescent_froglight
setblock 274 101 255 minecraft:black_stained_glass
setblock 275 101 229 minecraft:pearlescent_froglight
setblock 275 101 237 minecraft:pearlescent_froglight
setblock 275 101 261 minecraft:magenta_stained_glass
setblock 275 101 269 minecraft:cyan_stained_glass
setblock 276 101 230 minecraft:black_stained_glass
setblock 276 101 232 minecraft:black_stained_glass
setblock 276 101 234 minecraft:ochre_froglight
setblock 276 101 236 minecraft:black_stained_glass
setblock 276 101 243 minecraft:black_stained_glass
setblock 276 101 245 minecraft:black_stained_glass
setblock 276 101 247 minecraft:magenta_stained_glass
setblock 276 101 249 minecraft:black_stained_glass
setblock 276 101 251 minecraft:black_stained_glass
setblock 276 101 253 minecraft:magenta_stained_glass
setblock 276 101 262 minecraft:magenta_stained_glass
setblock 276 101 264 minecraft:magenta_stained_glass
setblock 276 101 266 minecraft:ochre_froglight
setblock 276 101 268 minecraft:black_stained_glass
fill 277 101 250 277 128 250 minecraft:black_concrete
setblock 277 101 251 minecraft:blue_concrete
setblock 235 102 243 minecraft:verdant_froglight
fill 235 102 244 235 274 244 minecraft:black_concrete
fill 236 102 230 236 103 230 minecraft:light_gray_concrete
fill 236 102 232 236 103 232 minecraft:light_gray_concrete
fill 236 102 234 236 103 234 minecraft:light_gray_concrete
fill 236 102 236 236 103 236 minecraft:light_gray_concrete
fill 236 102 243 236 103 243 minecraft:light_gray_concrete
fill 236 102 245 236 103 245 minecraft:light_gray_concrete
fill 236 102 247 236 103 247 minecraft:light_gray_concrete
fill 236 102 249 236 103 249 minecraft:light_gray_concrete
fill 236 102 251 236 103 251 minecraft:light_gray_concrete
fill 236 102 253 236 103 253 minecraft:light_gray_concrete
fill 236 102 262 236 103 262 minecraft:cyan_terracotta
fill 236 102 264 236 103 264 minecraft:cyan_terracotta
fill 236 102 266 236 103 266 minecraft:cyan_terracotta
fill 236 102 268 236 103 268 minecraft:cyan_terracotta
fill 237 102 229 237 103 229 minecraft:light_gray_concrete
fill 237 102 237 237 103 237 minecraft:light_gray_concrete
fill 237 102 242 237 103 242 minecraft:light_gray_concrete
fill 237 102 255 237 103 255 minecraft:light_gray_concrete
fill 237 102 261 237 103 261 minecraft:cyan_terracotta
fill 237 102 269 237 103 269 minecraft:cyan_terracotta
fill 239 102 229 239 103 229 minecraft:light_gray_concrete
fill 239 102 237 239 103 237 minecraft:light_gray_concrete
fill 239 102 242 239 103 242 minecraft:light_gray_concrete
fill 239 102 255 239 103 255 minecraft:light_gray_concrete
fill 239 102 261 239 103 261 minecraft:cyan_terracotta
fill 239 102 269 239 103 269 minecraft:cyan_terracotta
fill 241 102 229 241 103 229 minecraft:light_gray_concrete
fill 241 102 237 241 103 237 minecraft:light_gray_concrete
fill 241 102 243 241 103 243 minecraft:light_gray_concrete
fill 241 102 245 241 103 245 minecraft:light_gray_concrete
fill 241 102 247 241 103 247 minecraft:light_gray_concrete
fill 241 102 249 241 103 249 minecraft:light_gray_concrete
fill 241 102 251 241 103 251 minecraft:light_gray_concrete
fill 241 102 253 241 103 253 minecraft:light_gray_concrete
fill 241 102 261 241 103 261 minecraft:cyan_terracotta
fill 241 102 269 241 103 269 minecraft:cyan_terracotta
fill 243 102 229 243 103 229 minecraft:light_gray_concrete
fill 243 102 237 243 103 237 minecraft:light_gray_concrete
fill 243 102 261 243 103 261 minecraft:cyan_terracotta
fill 243 102 269 243 103 269 minecraft:cyan_terracotta
fill 244 102 230 244 103 230 minecraft:light_gray_concrete
fill 244 102 232 244 103 232 minecraft:light_gray_concrete
fill 244 102 234 244 103 234 minecraft:light_gray_concrete
fill 244 102 236 244 103 236 minecraft:light_gray_concrete
fill 244 102 262 244 103 262 minecraft:cyan_terracotta
fill 244 102 264 244 103 264 minecraft:cyan_terracotta
fill 244 102 266 244 103 266 minecraft:cyan_terracotta
fill 244 102 268 244 103 268 minecraft:cyan_terracotta
fill 249 102 230 249 103 230 minecraft:light_gray_concrete
fill 249 102 232 249 103 232 minecraft:light_gray_concrete
fill 249 102 265 249 103 265 minecraft:cyan_terracotta
fill 249 102 267 249 103 267 minecraft:cyan_terracotta
fill 250 102 229 250 103 229 minecraft:light_gray_concrete
fill 250 102 234 250 103 234 minecraft:light_gray_concrete
fill 250 102 264 250 103 264 minecraft:cyan_terracotta
fill 250 102 269 250 103 269 minecraft:cyan_terracotta
fill 252 102 229 252 103 229 minecraft:light_gray_concrete
fill 252 102 234 252 103 234 minecraft:light_gray_concrete
fill 252 102 264 252 103 264 minecraft:cyan_terracotta
fill 252 102 269 252 103 269 minecraft:cyan_terracotta
fill 254 102 229 254 103 229 minecraft:light_gray_concrete
fill 254 102 234 254 103 234 minecraft:light_gray_concrete
fill 254 102 264 254 103 264 minecraft:cyan_terracotta
fill 254 102 269 254 103 269 minecraft:cyan_terracotta
fill 256 102 229 256 103 229 minecraft:light_gray_concrete
fill 256 102 234 256 103 234 minecraft:light_gray_concrete
fill 256 102 264 256 103 264 minecraft:cyan_terracotta
fill 256 102 269 256 103 269 minecraft:cyan_terracotta
fill 258 102 229 258 103 229 minecraft:light_gray_concrete
fill 258 102 234 258 103 234 minecraft:light_gray_concrete
fill 258 102 264 258 103 264 minecraft:cyan_terracotta
fill 258 102 269 258 103 269 minecraft:cyan_terracotta
fill 260 102 229 260 103 229 minecraft:light_gray_concrete
fill 260 102 234 260 103 234 minecraft:light_gray_concrete
fill 260 102 264 260 103 264 minecraft:cyan_terracotta
fill 260 102 269 260 103 269 minecraft:cyan_terracotta
fill 262 102 230 262 103 230 minecraft:light_gray_concrete
fill 262 102 232 262 103 232 minecraft:light_gray_concrete
fill 262 102 265 262 103 265 minecraft:cyan_terracotta
fill 262 102 267 262 103 267 minecraft:cyan_terracotta
fill 265 102 270 265 127 270 minecraft:black_concrete
fill 268 102 230 268 103 230 minecraft:cyan_terracotta
fill 268 102 232 268 103 232 minecraft:cyan_terracotta
fill 268 102 234 268 103 234 minecraft:cyan_terracotta
fill 268 102 236 268 103 236 minecraft:cyan_terracotta
fill 268 102 262 268 103 262 minecraft:light_gray_concrete
fill 268 102 264 268 103 264 minecraft:light_gray_concrete
fill 268 102 266 268 103 266 minecraft:light_gray_concrete
fill 268 102 268 268 103 268 minecraft:light_gray_concrete
fill 269 102 229 269 103 229 minecraft:cyan_terracotta
fill 269 102 237 269 103 237 minecraft:cyan_terracotta
fill 269 102 261 269 103 261 minecraft:light_gray_concrete
fill 269 102 269 269 103 269 minecraft:light_gray_concrete
fill 271 102 229 271 103 229 minecraft:cyan_terracotta
fill 271 102 237 271 103 237 minecraft:cyan_terracotta
fill 271 102 243 271 103 243 minecraft:light_gray_concrete
fill 271 102 245 271 103 245 minecraft:light_gray_concrete
fill 271 102 247 271 103 247 minecraft:light_gray_concrete
fill 271 102 249 271 103 249 minecraft:light_gray_concrete
fill 271 102 251 271 103 251 minecraft:light_gray_concrete
fill 271 102 253 271 103 253 minecraft:light_gray_concrete
fill 271 102 261 271 103 261 minecraft:light_gray_concrete
fill 271 102 269 271 103 269 minecraft:light_gray_concrete
fill 272 102 242 272 103 242 minecraft:light_gray_concrete
fill 272 102 255 272 103 255 minecraft:light_gray_concrete
fill 273 102 229 273 103 229 minecraft:cyan_terracotta
fill 273 102 237 273 103 237 minecraft:cyan_terracotta
fill 273 102 261 273 103 261 minecraft:light_gray_concrete
fill 273 102 269 273 103 269 minecraft:light_gray_concrete
fill 274 102 242 274 103 242 minecraft:light_gray_concrete
fill 274 102 255 274 103 255 minecraft:light_gray_concrete
fill 275 102 229 275 103 229 minecraft:cyan_terracotta
fill 275 102 237 275 103 237 minecraft:cyan_terracotta
fill 275 102 261 275 103 261 minecraft:light_gray_concrete
fill 275 102 269 275 103 269 minecraft:light_gray_concrete
fill 276 102 230 276 103 230 minecraft:cyan_terracotta
fill 276 102 232 276 103 232 minecraft:cyan_terracotta
fill 276 102 234 276 103 234 minecraft:cyan_terracotta
fill 276 102 236 276 103 236 minecraft:cyan_terracotta
fill 276 102 243 276 103 243 minecraft:light_gray_concrete
fill 276 102 245 276 103 245 minecraft:light_gray_concrete
fill 276 102 247 276 103 247 minecraft:light_gray_concrete
fill 276 102 249 276 103 249 minecraft:light_gray_concrete
fill 276 102 251 276 103 251 minecraft:light_gray_concrete
fill 276 102 253 276 103 253 minecraft:light_gray_concrete
fill 276 102 262 276 103 262 minecraft:light_gray_concrete
fill 276 102 264 276 103 264 minecraft:light_gray_concrete
fill 276 102 266 276 103 266 minecraft:light_gray_concrete
fill 276 102 268 276 103 268 minecraft:light_gray_concrete
fill 277 102 251 277 127 251 minecraft:black_concrete
setblock 277 102 267 minecraft:pearlescent_froglight
fill 277 102 268 277 104 269 minecraft:black_concrete
fill 235 103 243 235 169 243 minecraft:black_concrete
setblock 235 103 267 minecraft:purple_concrete
setblock 238 103 238 minecraft:light[level=12]
setblock 238 103 259 minecraft:light[level=12]
setblock 245 103 231 minecraft:light[level=12]
setblock 245 103 238 minecraft:light[level=12]
setblock 245 103 245 minecraft:light[level=12]
setblock 245 103 252 minecraft:light[level=12]
setblock 245 103 259 minecraft:light[level=12]
setblock 245 103 266 minecraft:light[level=12]
setblock 252 103 238 minecraft:light[level=12]
setblock 252 103 245 minecraft:light[level=12]
setblock 252 103 252 minecraft:light[level=12]
setblock 252 103 259 minecraft:light[level=12]
setblock 259 103 238 minecraft:light[level=12]
setblock 259 103 245 minecraft:light[level=12]
setblock 259 103 252 minecraft:light[level=12]
setblock 259 103 259 minecraft:light[level=12]
setblock 266 103 231 minecraft:light[level=12]
setblock 266 103 238 minecraft:light[level=12]
setblock 266 103 245 minecraft:light[level=12]
setblock 266 103 252 minecraft:light[level=12]
setblock 266 103 259 minecraft:light[level=12]
setblock 266 103 266 minecraft:light[level=12]
setblock 271 103 228 minecraft:pearlescent_froglight
setblock 273 103 238 minecraft:light[level=12]
setblock 273 103 259 minecraft:light[level=12]
setblock 277 103 241 minecraft:magenta_concrete
setblock 277 103 245 minecraft:sea_lantern
setblock 277 103 260 minecraft:ochre_froglight
fill 277 103 267 277 157 267 minecraft:black_concrete
setblock 235 104 231 minecraft:purple_concrete
fill 235 104 267 235 169 267 minecraft:black_concrete
setblock 236 104 230 minecraft:ochre_froglight
setblock 236 104 232 minecraft:sea_lantern
setblock 236 104 234 minecraft:pearlescent_froglight
setblock 236 104 236 minecraft:magenta_stained_glass
setblock 236 104 243 minecraft:magenta_stained_glass
setblock 236 104 245 minecraft:black_stained_glass
setblock 236 104 247 minecraft:cyan_stained_glass
setblock 236 104 249 minecraft:pearlescent_froglight
setblock 236 104 251 minecraft:magenta_stained_glass
setblock 236 104 253 minecraft:cyan_stained_glass
setblock 236 104 262 minecraft:light_blue_stained_glass
setblock 236 104 264 minecraft:black_stained_glass
setblock 236 104 266 minecraft:black_stained_glass
setblock 236 104 268 minecraft:black_stained_glass
setblock 237 104 229 minecraft:sea_lantern
setblock 237 104 237 minecraft:black_stained_glass
setblock 237 104 242 minecraft:magenta_stained_glass
setblock 237 104 255 minecraft:black_stained_glass
setblock 237 104 261 minecraft:black_stained_glass
setblock 237 104 269 minecraft:pearlescent_froglight
setblock 239 104 229 minecraft:ochre_froglight
setblock 239 104 237 minecraft:black_stained_glass
setblock 239 104 242 minecraft:black_stained_glass
setblock 239 104 255 minecraft:pearlescent_froglight
setblock 239 104 261 minecraft:sea_lantern
setblock 239 104 269 minecraft:pearlescent_froglight
setblock 241 104 229 minecraft:light_blue_stained_glass
setblock 241 104 237 minecraft:black_stained_glass
setblock 241 104 243 minecraft:black_stained_glass
setblock 241 104 245 minecraft:pearlescent_froglight
setblock 241 104 247 minecraft:black_stained_glass
setblock 241 104 249 minecraft:light_blue_stained_glass
setblock 241 104 251 minecraft:black_stained_glass
setblock 241 104 253 minecraft:black_stained_glass
setblock 241 104 261 minecraft:black_stained_glass
setblock 241 104 269 minecraft:pearlescent_froglight
setblock 243 104 229 minecraft:pearlescent_froglight
setblock 243 104 237 minecraft:black_stained_glass
setblock 243 104 261 minecraft:black_stained_glass
setblock 243 104 269 minecraft:black_stained_glass
setblock 244 104 230 minecraft:ochre_froglight
setblock 244 104 232 minecraft:black_stained_glass
setblock 244 104 234 minecraft:pearlescent_froglight
setblock 244 104 236 minecraft:magenta_stained_glass
setblock 244 104 262 minecraft:cyan_stained_glass
setblock 244 104 264 minecraft:ochre_froglight
setblock 244 104 266 minecraft:cyan_stained_glass
setblock 244 104 268 minecraft:magenta_stained_glass
setblock 249 104 230 minecraft:pearlescent_froglight
setblock 249 104 232 minecraft:sea_lantern
setblock 249 104 265 minecraft:magenta_stained_glass
setblock 249 104 267 minecraft:black_stained_glass
setblock 250 104 229 minecraft:cyan_stained_glass
setblock 250 104 234 minecraft:black_stained_glass
setblock 250 104 264 minecraft:magenta_stained_glass
setblock 250 104 269 minecraft:magenta_stained_glass
setblock 252 104 229 minecraft:black_stained_glass
setblock 252 104 234 minecraft:light_blue_stained_glass
setblock 252 104 264 minecraft:black_stained_glass
setblock 252 104 269 minecraft:pearlescent_froglight
setblock 254 104 229 minecraft:ochre_froglight
setblock 254 104 234 minecraft:light_blue_stained_glass
setblock 254 104 264 minecraft:magenta_stained_glass
setblock 254 104 269 minecraft:ochre_froglight
setblock 256 104 229 minecraft:light_blue_stained_glass
setblock 256 104 234 minecraft:cyan_stained_glass
setblock 256 104 264 minecraft:black_stained_glass
setblock 256 104 269 minecraft:black_stained_glass
setblock 258 104 229 minecraft:light_blue_stained_glass
setblock 258 104 234 minecraft:black_stained_glass
setblock 258 104 264 minecraft:pearlescent_froglight
setblock 258 104 269 minecraft:magenta_stained_glass
setblock 260 104 229 minecraft:black_stained_glass
setblock 260 104 234 minecraft:black_stained_glass
setblock 260 104 264 minecraft:black_stained_glass
setblock 260 104 269 minecraft:magenta_stained_glass
setblock 262 104 230 minecraft:black_stained_glass
setblock 262 104 232 minecraft:sea_lantern
setblock 262 104 265 minecraft:ochre_froglight
setblock 262 104 267 minecraft:pearlescent_froglight
setblock 268 104 228 minecraft:purple_concrete
setblock 268 104 230 minecraft:light_blue_stained_glass
setblock 268 104 232 minecraft:black_stained_glass
setblock 268 104 234 minecraft:pearlescent_froglight
setblock 268 104 236 minecraft:light_blue_stained_glass
setblock 268 104 262 minecraft:black_stained_glass
setblock 268 104 264 minecraft:black_stained_glass
setblock 268 104 266 minecraft:black_stained_glass
setblock 268 104 268 minecraft:ochre_froglight
fill 269 104 228 269 138 228 minecraft:black_concrete
setblock 269 104 229 minecraft:sea_lantern
setblock 269 104 237 minecraft:light_blue_stained_glass
setblock 269 104 261 minecraft:cyan_stained_glass
setblock 269 104 269 minecraft:cyan_stained_glass
fill 271 104 228 271 159 228 minecraft:black_concrete
setblock 271 104 229 minecraft:black_stained_glass
setblock 271 104 237 minecraft:black_stained_glass
setblock 271 104 243 minecraft:ochre_froglight
setblock 271 104 245 minecraft:black_stained_glass
setblock 271 104 247 minecraft:pearlescent_froglight
setblock 271 104 249 minecraft:black_stained_glass
setblock 271 104 251 minecraft:ochre_froglight
setblock 271 104 253 minecraft:black_stained_glass
setblock 271 104 261 minecraft:sea_lantern
setblock 271 104 269 minecraft:sea_lantern
setblock 272 104 242 minecraft:cyan_stained_glass
setblock 272 104 255 minecraft:black_stained_glass
setblock 273 104 229 minecraft:black_stained_glass
setblock 273 104 237 minecraft:light_blue_stained_glass
setblock 273 104 261 minecraft:black_stained_glass
setblock 273 104 269 minecraft:ochre_froglight
setblock 274 104 242 minecraft:pearlescent_froglight
setblock 274 104 255 minecraft:black_stained_glass
setblock 275 104 229 minecraft:pearlescent_froglight
setblock 275 104 237 minecraft:black_stained_glass
setblock 275 104 261 minecraft:black_stained_glass
setblock 275 104 269 minecraft:black_stained_glass
setblock 276 104 230 minecraft:black_stained_glass
setblock 276 104 232 minecraft:magenta_stained_glass
setblock 276 104 234 minecraft:pearlescent_froglight
setblock 276 104 236 minecraft:black_stained_glass
setblock 276 104 243 minecraft:sea_lantern
setblock 276 104 245 minecraft:black_stained_glass
setblock 276 104 247 minecraft:black_stained_glass
setblock 276 104 249 minecraft:ochre_froglight
setblock 276 104 251 minecraft:ochre_froglight
setblock 276 104 253 minecraft:ochre_froglight
setblock 276 104 262 minecraft:black_stained_glass
setblock 276 104 264 minecraft:magenta_stained_glass
setblock 276 104 266 minecraft:cyan_stained_glass
setblock 276 104 268 minecraft:black_stained_glass
fill 277 104 241 277 140 241 minecraft:black_concrete
fill 277 104 245 277 308 245 minecraft:black_concrete
setblock 277 104 252 minecraft:purple_concrete
fill 277 104 260 277 241 260 minecraft:black_concrete
setblock 277 104 261 minecraft:sea_lantern
fill 235 105 231 235 155 231 minecraft:black_concrete
fill 236 105 230 236 106 230 minecraft:light_gray_concrete
fill 236 105 232 236 106 232 minecraft:light_gray_concrete
fill 236 105 234 236 106 234 minecraft:light_gray_concrete
fill 236 105 236 236 106 236 minecraft:light_gray_concrete
fill 236 105 243 236 106 243 minecraft:light_gray_concrete
fill 236 105 245 236 106 245 minecraft:light_gray_concrete
fill 236 105 247 236 106 247 minecraft:light_gray_concrete
fill 236 105 249 236 106 249 minecraft:light_gray_concrete
fill 236 105 251 236 106 251 minecraft:light_gray_concrete
fill 236 105 253 236 106 253 minecraft:light_gray_concrete
fill 236 105 262 236 106 262 minecraft:cyan_terracotta
fill 236 105 264 236 106 264 minecraft:cyan_terracotta
fill 236 105 266 236 106 266 minecraft:cyan_terracotta
fill 236 105 268 236 106 268 minecraft:cyan_terracotta
fill 237 105 229 237 106 229 minecraft:light_gray_concrete
fill 237 105 237 237 106 237 minecraft:light_gray_concrete
fill 237 105 242 237 106 242 minecraft:light_gray_concrete
fill 237 105 255 237 106 255 minecraft:light_gray_concrete
fill 237 105 261 237 106 261 minecraft:cyan_terracotta
fill 237 105 269 237 106 269 minecraft:cyan_terracotta
fill 239 105 229 239 106 229 minecraft:light_gray_concrete
fill 239 105 237 239 106 237 minecraft:light_gray_concrete
fill 239 105 242 239 106 242 minecraft:light_gray_concrete
fill 239 105 255 239 106 255 minecraft:light_gray_concrete
fill 239 105 261 239 106 261 minecraft:cyan_terracotta
fill 239 105 269 239 106 269 minecraft:cyan_terracotta
fill 241 105 229 241 106 229 minecraft:light_gray_concrete
fill 241 105 237 241 106 237 minecraft:light_gray_concrete
fill 241 105 243 241 106 243 minecraft:light_gray_concrete
fill 241 105 245 241 106 245 minecraft:light_gray_concrete
fill 241 105 247 241 106 247 minecraft:light_gray_concrete
fill 241 105 249 241 106 249 minecraft:light_gray_concrete
fill 241 105 251 241 106 251 minecraft:light_gray_concrete
fill 241 105 253 241 106 253 minecraft:light_gray_concrete
fill 241 105 261 241 106 261 minecraft:cyan_terracotta
fill 241 105 269 241 106 269 minecraft:cyan_terracotta
fill 243 105 229 243 106 229 minecraft:light_gray_concrete
fill 243 105 237 243 106 237 minecraft:light_gray_concrete
fill 243 105 261 243 106 261 minecraft:cyan_terracotta
fill 243 105 269 243 106 269 minecraft:cyan_terracotta
fill 244 105 230 244 106 230 minecraft:light_gray_concrete
fill 244 105 232 244 106 232 minecraft:light_gray_concrete
fill 244 105 234 244 106 234 minecraft:light_gray_concrete
fill 244 105 236 244 106 236 minecraft:light_gray_concrete
fill 244 105 262 244 106 262 minecraft:cyan_terracotta
fill 244 105 264 244 106 264 minecraft:cyan_terracotta
fill 244 105 266 244 106 266 minecraft:cyan_terracotta
fill 244 105 268 244 106 268 minecraft:cyan_terracotta
fill 245 105 228 247 140 228 minecraft:black_concrete
setblock 248 105 228 minecraft:pearlescent_froglight
fill 249 105 230 249 106 230 minecraft:light_gray_concrete
fill 249 105 232 249 106 232 minecraft:light_gray_concrete
fill 249 105 265 249 106 265 minecraft:cyan_terracotta
fill 249 105 267 249 106 267 minecraft:cyan_terracotta
fill 250 105 229 250 106 229 minecraft:light_gray_concrete
fill 250 105 234 250 106 234 minecraft:light_gray_concrete
fill 250 105 264 250 106 264 minecraft:cyan_terracotta
fill 250 105 269 250 106 269 minecraft:cyan_terracotta
fill 252 105 229 252 106 229 minecraft:light_gray_concrete
fill 252 105 234 252 106 234 minecraft:light_gray_concrete
fill 252 105 264 252 106 264 minecraft:cyan_terracotta
fill 252 105 269 252 106 269 minecraft:cyan_terracotta
fill 254 105 229 254 106 229 minecraft:light_gray_concrete
fill 254 105 234 254 106 234 minecraft:light_gray_concrete
fill 254 105 264 254 106 264 minecraft:cyan_terracotta
fill 254 105 269 254 106 269 minecraft:cyan_terracotta
fill 256 105 229 256 106 229 minecraft:light_gray_concrete
fill 256 105 234 256 106 234 minecraft:light_gray_concrete
fill 256 105 264 256 106 264 minecraft:cyan_terracotta
fill 256 105 269 256 106 269 minecraft:cyan_terracotta
fill 258 105 229 258 106 229 minecraft:light_gray_concrete
fill 258 105 234 258 106 234 minecraft:light_gray_concrete
fill 258 105 264 258 106 264 minecraft:cyan_terracotta
fill 258 105 269 258 106 269 minecraft:cyan_terracotta
fill 260 105 229 260 106 229 minecraft:light_gray_concrete
fill 260 105 234 260 106 234 minecraft:light_gray_concrete
fill 260 105 264 260 106 264 minecraft:cyan_terracotta
fill 260 105 269 260 106 269 minecraft:cyan_terracotta
fill 262 105 230 262 106 230 minecraft:light_gray_concrete
fill 262 105 232 262 106 232 minecraft:light_gray_concrete
fill 262 105 265 262 106 265 minecraft:cyan_terracotta
fill 262 105 267 262 106 267 minecraft:cyan_terracotta
fill 268 105 228 268 126 228 minecraft:black_concrete
fill 268 105 230 268 106 230 minecraft:cyan_terracotta
fill 268 105 232 268 106 232 minecraft:cyan_terracotta
fill 268 105 234 268 106 234 minecraft:cyan_terracotta
fill 268 105 236 268 106 236 minecraft:cyan_terracotta
fill 268 105 262 268 106 262 minecraft:light_gray_concrete
fill 268 105 264 268 106 264 minecraft:light_gray_concrete
fill 268 105 266 268 106 266 minecraft:light_gray_concrete
fill 268 105 268 268 106 268 minecraft:light_gray_concrete
fill 269 105 229 269 106 229 minecraft:cyan_terracotta
fill 269 105 237 269 106 237 minecraft:cyan_terracotta
fill 269 105 261 269 106 261 minecraft:light_gray_concrete
fill 269 105 269 269 106 269 minecraft:light_gray_concrete
fill 271 105 229 271 106 229 minecraft:cyan_terracotta
fill 271 105 237 271 106 237 minecraft:cyan_terracotta
fill 271 105 243 271 106 243 minecraft:light_gray_concrete
fill 271 105 245 271 106 245 minecraft:light_gray_concrete
fill 271 105 247 271 106 247 minecraft:light_gray_concrete
fill 271 105 249 271 106 249 minecraft:light_gray_concrete
fill 271 105 251 271 106 251 minecraft:light_gray_concrete
fill 271 105 253 271 106 253 minecraft:light_gray_concrete
fill 271 105 261 271 106 261 minecraft:light_gray_concrete
fill 271 105 269 271 106 269 minecraft:light_gray_concrete
fill 272 105 242 272 106 242 minecraft:light_gray_concrete
fill 272 105 255 272 106 255 minecraft:light_gray_concrete
fill 273 105 229 273 106 229 minecraft:cyan_terracotta
fill 273 105 237 273 106 237 minecraft:cyan_terracotta
fill 273 105 261 273 106 261 minecraft:light_gray_concrete
fill 273 105 269 273 106 269 minecraft:light_gray_concrete
fill 274 105 242 274 106 242 minecraft:light_gray_concrete
fill 274 105 255 274 106 255 minecraft:light_gray_concrete
fill 275 105 229 275 106 229 minecraft:cyan_terracotta
fill 275 105 237 275 106 237 minecraft:cyan_terracotta
fill 275 105 261 275 106 261 minecraft:light_gray_concrete
fill 275 105 269 275 106 269 minecraft:light_gray_concrete
fill 276 105 230 276 106 230 minecraft:cyan_terracotta
fill 276 105 232 276 106 232 minecraft:cyan_terracotta
fill 276 105 234 276 106 234 minecraft:cyan_terracotta
fill 276 105 236 276 106 236 minecraft:cyan_terracotta
fill 276 105 243 276 106 243 minecraft:light_gray_concrete
fill 276 105 245 276 106 245 minecraft:light_gray_concrete
fill 276 105 247 276 106 247 minecraft:light_gray_concrete
fill 276 105 249 276 106 249 minecraft:light_gray_concrete
fill 276 105 251 276 106 251 minecraft:light_gray_concrete
fill 276 105 253 276 106 253 minecraft:light_gray_concrete
fill 276 105 262 276 106 262 minecraft:light_gray_concrete
fill 276 105 264 276 106 264 minecraft:light_gray_concrete
fill 276 105 266 276 106 266 minecraft:light_gray_concrete
fill 276 105 268 276 106 268 minecraft:light_gray_concrete
fill 277 105 252 277 113 252 minecraft:black_concrete
fill 277 105 261 277 114 261 minecraft:black_concrete
setblock 277 105 268 minecraft:cyan_concrete
setblock 277 105 269 minecraft:verdant_froglight
setblock 248 106 228 minecraft:black_concrete
fill 277 106 268 277 106 269 minecraft:black_concrete
setblock 235 107 261 minecraft:ochre_froglight
setblock 236 107 230 minecraft:light_blue_stained_glass
setblock 236 107 232 minecraft:magenta_stained_glass
setblock 236 107 234 minecraft:light_blue_stained_glass
setblock 236 107 236 minecraft:light_blue_stained_glass
setblock 236 107 243 minecraft:ochre_froglight
setblock 236 107 245 minecraft:black_stained_glass
setblock 236 107 247 minecraft:ochre_froglight
setblock 236 107 249 minecraft:magenta_stained_glass
setblock 236 107 251 minecraft:light_blue_stained_glass
setblock 236 107 253 minecraft:pearlescent_froglight
setblock 236 107 262 minecraft:black_stained_glass
setblock 236 107 264 minecraft:pearlescent_froglight
setblock 236 107 266 minecraft:black_stained_glass
setblock 236 107 268 minecraft:black_stained_glass
setblock 237 107 229 minecraft:magenta_stained_glass
setblock 237 107 237 minecraft:light_blue_stained_glass
setblock 237 107 242 minecraft:black_stained_glass
setblock 237 107 255 minecraft:magenta_stained_glass
setblock 237 107 261 minecraft:magenta_stained_glass
setblock 237 107 269 minecraft:black_stained_glass
setblock 239 107 229 minecraft:ochre_froglight
setblock 239 107 237 minecraft:sea_lantern
setblock 239 107 242 minecraft:ochre_froglight
setblock 239 107 255 minecraft:ochre_froglight
setblock 239 107 261 minecraft:magenta_stained_glass
setblock 239 107 269 minecraft:sea_lantern
setblock 241 107 229 minecraft:light_blue_stained_glass
setblock 241 107 237 minecraft:magenta_stained_glass
setblock 241 107 243 minecraft:pearlescent_froglight
setblock 241 107 245 minecraft:black_stained_glass
setblock 241 107 247 minecraft:sea_lantern
setblock 241 107 249 minecraft:black_stained_glass
setblock 241 107 251 minecraft:black_stained_glass
setblock 241 107 253 minecraft:light_blue_stained_glass
setblock 241 107 261 minecraft:sea_lantern
setblock 241 107 269 minecraft:black_stained_glass
setblock 243 107 229 minecraft:black_stained_glass
setblock 243 107 237 minecraft:ochre_froglight
setblock 243 107 261 minecraft:cyan_stained_glass
setblock 243 107 269 minecraft:ochre_froglight
setblock 244 107 230 minecraft:sea_lantern
setblock 244 107 232 minecraft:black_stained_glass
setblock 244 107 234 minecraft:cyan_stained_glass
setblock 244 107 236 minecraft:black_stained_glass
setblock 244 107 262 minecraft:cyan_stained_glass
setblock 244 107 264 minecraft:black_stained_glass
setblock 244 107 266 minecraft:black_stained_glass
setblock 244 107 268 minecraft:pearlescent_froglight
setblock 248 107 228 minecraft:magenta_concrete
setblock 249 107 230 minecraft:cyan_stained_glass
setblock 249 107 232 minecraft:pearlescent_froglight
setblock 249 107 265 minecraft:black_stained_glass
setblock 249 107 267 minecraft:sea_lantern
setblock 250 107 229 minecraft:pearlescent_froglight
setblock 250 107 234 minecraft:magenta_stained_glass
setblock 250 107 264 minecraft:magenta_stained_glass
setblock 250 107 269 minecraft:ochre_froglight
setblock 252 107 229 minecraft:sea_lantern
setblock 252 107 234 minecraft:ochre_froglight
setblock 252 107 264 minecraft:pearlescent_froglight
setblock 252 107 269 minecraft:cyan_stained_glass
setblock 254 107 229 minecraft:magenta_stained_glass
setblock 254 107 234 minecraft:magenta_stained_glass
setblock 254 107 264 minecraft:black_stained_glass
setblock 254 107 269 minecraft:black_stained_glass
setblock 256 107 229 minecraft:sea_lantern
setblock 256 107 234 minecraft:black_stained_glass
setblock 256 107 264 minecraft:sea_lantern
setblock 256 107 269 minecraft:sea_lantern
fill 257 107 228 257 142 228 minecraft:black_concrete
setblock 258 107 228 minecraft:cyan_concrete
setblock 258 107 229 minecraft:magenta_stained_glass
setblock 258 107 234 minecraft:magenta_stained_glass
setblock 258 107 264 minecraft:light_blue_stained_glass
setblock 258 107 269 minecraft:sea_lantern
fill 259 107 228 262 113 228 minecraft:black_concrete
setblock 260 107 229 minecraft:black_stained_glass
setblock 260 107 234 minecraft:pearlescent_froglight
setblock 260 107 264 minecraft:black_stained_glass
setblock 260 107 269 minecraft:black_stained_glass
setblock 262 107 230 minecraft:cyan_stained_glass
setblock 262 107 232 minecraft:pearlescent_froglight
setblock 262 107 265 minecraft:ochre_froglight
setblock 262 107 267 minecraft:black_stained_glass
setblock 268 107 230 minecraft:black_stained_glass
setblock 268 107 232 minecraft:black_stained_glass
setblock 268 107 234 minecraft:black_stained_glass
setblock 268 107 236 minecraft:black_stained_glass
setblock 268 107 262 minecraft:black_stained_glass
setblock 268 107 264 minecraft:black_stained_glass
setblock 268 107 266 minecraft:magenta_stained_glass
setblock 268 107 268 minecraft:cyan_stained_glass
setblock 269 107 229 minecraft:black_stained_glass
setblock 269 107 237 minecraft:cyan_stained_glass
setblock 269 107 261 minecraft:cyan_stained_glass
setblock 269 107 269 minecraft:ochre_froglight
setblock 271 107 229 minecraft:black_stained_glass
setblock 271 107 237 minecraft:black_stained_glass
setblock 271 107 243 minecraft:light_blue_stained_glass
setblock 271 107 245 minecraft:light_blue_stained_glass
setblock 271 107 247 minecraft:cyan_stained_glass
setblock 271 107 249 minecraft:sea_lantern
setblock 271 107 251 minecraft:magenta_stained_glass
setblock 271 107 253 minecraft:black_stained_glass
setblock 271 107 261 minecraft:black_stained_glass
setblock 271 107 269 minecraft:pearlescent_froglight
setblock 272 107 242 minecraft:black_stained_glass
setblock 272 107 255 minecraft:sea_lantern
setblock 273 107 229 minecraft:pearlescent_froglight
setblock 273 107 237 minecraft:ochre_froglight
setblock 273 107 261 minecraft:cyan_stained_glass
setblock 273 107 269 minecraft:sea_lantern
setblock 274 107 242 minecraft:sea_lantern
setblock 274 107 255 minecraft:black_stained_glass
setblock 275 107 229 minecraft:black_stained_glass
setblock 275 107 237 minecraft:sea_lantern
setblock 275 107 261 minecraft:black_stained_glass
setblock 275 107 269 minecraft:black_stained_glass
setblock 276 107 230 minecraft:ochre_froglight
setblock 276 107 232 minecraft:ochre_froglight
setblock 276 107 234 minecraft:pearlescent_froglight
setblock 276 107 236 minecraft:magenta_stained_glass
setblock 276 107 243 minecraft:black_stained_glass
setblock 276 107 245 minecraft:pearlescent_froglight
setblock 276 107 247 minecraft:magenta_stained_glass
setblock 276 107 249 minecraft:light_blue_stained_glass
setblock 276 107 251 minecraft:light_blue_stained_glass
setblock 276 107 253 minecraft:pearlescent_froglight
setblock 276 107 262 minecraft:black_stained_glass
setblock 276 107 264 minecraft:ochre_froglight
setblock 276 107 266 minecraft:ochre_froglight
setblock 276 107 268 minecraft:black_stained_glass
setblock 277 107 268 minecraft:blue_concrete
fill 277 107 269 277 154 269 minecraft:black_concrete
fill 235 108 261 235 138 261 minecraft:black_concrete
fill 236 108 230 236 109 230 minecraft:light_gray_concrete
fill 236 108 232 236 109 232 minecraft:light_gray_concrete
fill 236 108 234 236 109 234 minecraft:light_gray_concrete
fill 236 108 236 236 109 236 minecraft:light_gray_concrete
fill 236 108 243 236 109 243 minecraft:light_gray_concrete
fill 236 108 245 236 109 245 minecraft:light_gray_concrete
fill 236 108 247 236 109 247 minecraft:light_gray_concrete
fill 236 108 249 236 109 249 minecraft:light_gray_concrete
fill 236 108 251 236 109 251 minecraft:light_gray_concrete
fill 236 108 253 236 109 253 minecraft:light_gray_concrete
fill 236 108 262 236 109 262 minecraft:cyan_terracotta
fill 236 108 264 236 109 264 minecraft:cyan_terracotta
fill 236 108 266 236 109 266 minecraft:cyan_terracotta
fill 236 108 268 236 109 268 minecraft:cyan_terracotta
fill 237 108 229 237 109 229 minecraft:light_gray_concrete
fill 237 108 237 237 109 237 minecraft:light_gray_concrete
fill 237 108 242 237 109 242 minecraft:light_gray_concrete
fill 237 108 255 237 109 255 minecraft:light_gray_concrete
fill 237 108 261 237 109 261 minecraft:cyan_terracotta
fill 237 108 269 237 109 269 minecraft:cyan_terracotta
setblock 238 108 239 minecraft:light[level=15]
fill 239 108 229 239 109 229 minecraft:light_gray_concrete
fill 239 108 237 239 109 237 minecraft:light_gray_concrete
fill 239 108 242 239 109 242 minecraft:light_gray_concrete
fill 239 108 255 239 109 255 minecraft:light_gray_concrete
fill 239 108 261 239 109 261 minecraft:cyan_terracotta
fill 239 108 269 239 109 269 minecraft:cyan_terracotta
fill 241 108 229 241 109 229 minecraft:light_gray_concrete
fill 241 108 237 241 109 237 minecraft:light_gray_concrete
fill 241 108 243 241 109 243 minecraft:light_gray_concrete
fill 241 108 245 241 109 245 minecraft:light_gray_concrete
fill 241 108 247 241 109 247 minecraft:light_gray_concrete
fill 241 108 249 241 109 249 minecraft:light_gray_concrete
fill 241 108 251 241 109 251 minecraft:light_gray_concrete
fill 241 108 253 241 109 253 minecraft:light_gray_concrete
fill 241 108 261 241 109 261 minecraft:cyan_terracotta
fill 241 108 269 241 109 269 minecraft:cyan_terracotta
fill 243 108 229 243 109 229 minecraft:light_gray_concrete
fill 243 108 237 243 109 237 minecraft:light_gray_concrete
fill 243 108 261 243 109 261 minecraft:cyan_terracotta
fill 243 108 269 243 109 269 minecraft:cyan_terracotta
fill 244 108 230 244 109 230 minecraft:light_gray_concrete
fill 244 108 232 244 109 232 minecraft:light_gray_concrete
fill 244 108 234 244 109 234 minecraft:light_gray_concrete
fill 244 108 236 244 109 236 minecraft:light_gray_concrete
fill 244 108 262 244 109 262 minecraft:cyan_terracotta
fill 244 108 264 244 109 264 minecraft:cyan_terracotta
fill 244 108 266 244 109 266 minecraft:cyan_terracotta
fill 244 108 268 244 109 268 minecraft:cyan_terracotta
setblock 246 108 231 minecraft:light[level=15]
setblock 246 108 239 minecraft:light[level=15]
setblock 246 108 247 minecraft:light[level=15]
setblock 246 108 255 minecraft:light[level=15]
setblock 246 108 263 minecraft:light[level=15]
fill 248 108 228 248 258 228 minecraft:black_concrete
fill 249 108 230 249 109 230 minecraft:light_gray_concrete
fill 249 108 232 249 109 232 minecraft:light_gray_concrete
fill 249 108 265 249 109 265 minecraft:cyan_terracotta
fill 249 108 267 249 109 267 minecraft:cyan_terracotta
fill 250 108 229 250 109 229 minecraft:light_gray_concrete
fill 250 108 234 250 109 234 minecraft:light_gray_concrete
fill 250 108 264 250 109 264 minecraft:cyan_terracotta
fill 250 108 269 250 109 269 minecraft:cyan_terracotta
fill 252 108 229 252 109 229 minecraft:light_gray_concrete
fill 252 108 234 252 109 234 minecraft:light_gray_concrete
fill 252 108 264 252 109 264 minecraft:cyan_terracotta
fill 252 108 269 252 109 269 minecraft:cyan_terracotta
fill 254 108 229 254 109 229 minecraft:light_gray_concrete
fill 254 108 234 254 109 234 minecraft:light_gray_concrete
setblock 254 108 239 minecraft:light[level=15]
setblock 254 108 247 minecraft:light[level=15]
setblock 254 108 255 minecraft:light[level=15]
setblock 254 108 263 minecraft:light[level=15]
fill 254 108 264 254 109 264 minecraft:cyan_terracotta
fill 254 108 269 254 109 269 minecraft:cyan_terracotta
fill 256 108 229 256 109 229 minecraft:light_gray_concrete
fill 256 108 234 256 109 234 minecraft:light_gray_concrete
fill 256 108 264 256 109 264 minecraft:cyan_terracotta
fill 256 108 269 256 109 269 minecraft:cyan_terracotta
fill 258 108 228 258 215 228 minecraft:black_concrete
fill 258 108 229 258 109 229 minecraft:light_gray_concrete
fill 258 108 234 258 109 234 minecraft:light_gray_concrete
fill 258 108 264 258 109 264 minecraft:cyan_terracotta
fill 258 108 269 258 109 269 minecraft:cyan_terracotta
fill 260 108 229 260 109 229 minecraft:light_gray_concrete
fill 260 108 234 260 109 234 minecraft:light_gray_concrete
fill 260 108 264 260 109 264 minecraft:cyan_terracotta
fill 260 108 269 260 109 269 minecraft:cyan_terracotta
fill 262 108 230 262 109 230 minecraft:light_gray_concrete
fill 262 108 232 262 109 232 minecraft:light_gray_concrete
setblock 262 108 239 minecraft:light[level=15]
setblock 262 108 247 minecraft:light[level=15]
setblock 262 108 255 minecraft:light[level=15]
setblock 262 108 263 minecraft:light[level=15]
fill 262 108 265 262 109 265 minecraft:cyan_terracotta
fill 262 108 267 262 109 267 minecraft:cyan_terracotta
fill 266 108 270 268 110 270 minecraft:black_concrete
fill 268 108 230 268 109 230 minecraft:cyan_terracotta
fill 268 108 232 268 109 232 minecraft:cyan_terracotta
fill 268 108 234 268 109 234 minecraft:cyan_terracotta
fill 268 108 236 268 109 236 minecraft:cyan_terracotta
fill 268 108 262 268 109 262 minecraft:light_gray_concrete
fill 268 108 264 268 109 264 minecraft:light_gray_concrete
fill 268 108 266 268 109 266 minecraft:light_gray_concrete
fill 268 108 268 268 109 268 minecraft:light_gray_concrete
fill 269 108 229 269 109 229 minecraft:cyan_terracotta
fill 269 108 237 269 109 237 minecraft:cyan_terracotta
fill 269 108 261 269 109 261 minecraft:light_gray_concrete
fill 269 108 269 269 109 269 minecraft:light_gray_concrete
setblock 269 108 270 minecraft:verdant_froglight
setblock 270 108 239 minecraft:light[level=15]
setblock 270 108 247 minecraft:light[level=15]
setblock 270 108 255 minecraft:light[level=15]
fill 271 108 229 271 109 229 minecraft:cyan_terracotta
fill 271 108 237 271 109 237 minecraft:cyan_terracotta
fill 271 108 243 271 109 243 minecraft:light_gray_concrete
fill 271 108 245 271 109 245 minecraft:light_gray_concrete
fill 271 108 247 271 109 247 minecraft:light_gray_concrete
fill 271 108 249 271 109 249 minecraft:light_gray_concrete
fill 271 108 251 271 109 251 minecraft:light_gray_concrete
fill 271 108 253 271 109 253 minecraft:light_gray_concrete
fill 271 108 261 271 109 261 minecraft:light_gray_concrete
fill 271 108 269 271 109 269 minecraft:light_gray_concrete
fill 272 108 242 272 109 242 minecraft:light_gray_concrete
fill 272 108 255 272 109 255 minecraft:light_gray_concrete
fill 273 108 229 273 109 229 minecraft:cyan_terracotta
fill 273 108 237 273 109 237 minecraft:cyan_terracotta
fill 273 108 261 273 109 261 minecraft:light_gray_concrete
fill 273 108 269 273 109 269 minecraft:light_gray_concrete
fill 274 108 242 274 109 242 minecraft:light_gray_concrete
fill 274 108 255 274 109 255 minecraft:light_gray_concrete
setblock 274 108 270 minecraft:sea_lantern
fill 275 108 229 275 109 229 minecraft:cyan_terracotta
fill 275 108 237 275 109 237 minecraft:cyan_terracotta
fill 275 108 261 275 109 261 minecraft:light_gray_concrete
fill 275 108 269 275 109 269 minecraft:light_gray_concrete
fill 276 108 230 276 109 230 minecraft:cyan_terracotta
fill 276 108 232 276 109 232 minecraft:cyan_terracotta
fill 276 108 234 276 109 234 minecraft:cyan_terracotta
fill 276 108 236 276 109 236 minecraft:cyan_terracotta
fill 276 108 243 276 109 243 minecraft:light_gray_concrete
fill 276 108 245 276 109 245 minecraft:light_gray_concrete
fill 276 108 247 276 109 247 minecraft:light_gray_concrete
fill 276 108 249 276 109 249 minecraft:light_gray_concrete
fill 276 108 251 276 109 251 minecraft:light_gray_concrete
fill 276 108 253 276 109 253 minecraft:light_gray_concrete
fill 276 108 262 276 109 262 minecraft:light_gray_concrete
fill 276 108 264 276 109 264 minecraft:light_gray_concrete
fill 276 108 266 276 109 266 minecraft:light_gray_concrete
fill 276 108 268 276 109 268 minecraft:light_gray_concrete
fill 277 108 268 277 308 268 minecraft:black_concrete
setblock 238 109 238 minecraft:light[level=12]
setblock 238 109 259 minecraft:light[level=12]
setblock 245 109 231 minecraft:light[level=12]
setblock 245 109 238 minecraft:light[level=12]
setblock 245 109 245 minecraft:light[level=12]
setblock 245 109 252 minecraft:light[level=12]
setblock 245 109 259 minecraft:light[level=12]
setblock 245 109 266 minecraft:light[level=12]
setblock 252 109 238 minecraft:light[level=12]
setblock 252 109 245 minecraft:light[level=12]
setblock 252 109 252 minecraft:light[level=12]
setblock 252 109 259 minecraft:light[level=12]
setblock 258 109 270 minecraft:magenta_concrete
setblock 259 109 238 minecraft:light[level=12]
setblock 259 109 245 minecraft:light[level=12]
setblock 259 109 252 minecraft:light[level=12]
setblock 259 109 259 minecraft:light[level=12]
setblock 266 109 231 minecraft:light[level=12]
setblock 266 109 238 minecraft:light[level=12]
setblock 266 109 245 minecraft:light[level=12]
setblock 266 109 252 minecraft:light[level=12]
setblock 266 109 259 minecraft:light[level=12]
setblock 266 109 266 minecraft:light[level=12]
fill 269 109 270 269 144 270 minecraft:black_concrete
setblock 273 109 238 minecraft:light[level=12]
setblock 273 109 259 minecraft:light[level=12]
fill 274 109 270 274 209 270 minecraft:black_concrete
setblock 235 110 266 minecraft:verdant_froglight
setblock 236 110 230 minecraft:pearlescent_froglight
setblock 236 110 232 minecraft:pearlescent_froglight
setblock 236 110 234 minecraft:light_blue_stained_glass
setblock 236 110 236 minecraft:black_stained_glass
setblock 236 110 243 minecraft:sea_lantern
setblock 236 110 245 minecraft:pearlescent_froglight
setblock 236 110 247 minecraft:light_blue_stained_glass
setblock 236 110 249 minecraft:sea_lantern
setblock 236 110 251 minecraft:pearlescent_froglight
setblock 236 110 253 minecraft:black_stained_glass
setblock 236 110 262 minecraft:magenta_stained_glass
setblock 236 110 264 minecraft:light_blue_stained_glass
setblock 236 110 266 minecraft:pearlescent_froglight
setblock 236 110 268 minecraft:light_blue_stained_glass
setblock 237 110 229 minecraft:black_stained_glass
setblock 237 110 237 minecraft:black_stained_glass
setblock 237 110 242 minecraft:ochre_froglight
setblock 237 110 255 minecraft:light_blue_stained_glass
setblock 237 110 261 minecraft:light_blue_stained_glass
setblock 237 110 269 minecraft:black_stained_glass
setblock 239 110 229 minecraft:black_stained_glass
setblock 239 110 237 minecraft:black_stained_glass
setblock 239 110 242 minecraft:ochre_froglight
setblock 239 110 255 minecraft:sea_lantern
setblock 239 110 261 minecraft:ochre_froglight
setblock 239 110 269 minecraft:magenta_stained_glass
setblock 241 110 229 minecraft:pearlescent_froglight
setblock 241 110 237 minecraft:black_stained_glass
setblock 241 110 243 minecraft:cyan_stained_glass
setblock 241 110 245 minecraft:magenta_stained_glass
setblock 241 110 247 minecraft:black_stained_glass
setblock 241 110 249 minecraft:light_blue_stained_glass
setblock 241 110 251 minecraft:black_stained_glass
setblock 241 110 253 minecraft:sea_lantern
setblock 241 110 261 minecraft:black_stained_glass
setblock 241 110 269 minecraft:light_blue_stained_glass
setblock 243 110 229 minecraft:cyan_stained_glass
setblock 243 110 237 minecraft:black_stained_glass
setblock 243 110 261 minecraft:black_stained_glass
setblock 243 110 269 minecraft:pearlescent_froglight
setblock 244 110 230 minecraft:black_stained_glass
setblock 244 110 232 minecraft:black_stained_glass
setblock 244 110 234 minecraft:black_stained_glass
setblock 244 110 236 minecraft:black_stained_glass
setblock 244 110 262 minecraft:pearlescent_froglight
setblock 244 110 264 minecraft:magenta_stained_glass
setblock 244 110 266 minecraft:cyan_stained_glass
setblock 244 110 268 minecraft:black_stained_glass
setblock 249 110 230 minecraft:magenta_stained_glass
setblock 249 110 232 minecraft:black_stained_glass
setblock 249 110 265 minecraft:black_stained_glass
setblock 249 110 267 minecraft:light_blue_stained_glass
setblock 250 110 229 minecraft:black_stained_glass
setblock 250 110 234 minecraft:magenta_stained_glass
setblock 250 110 264 minecraft:black_stained_glass
setblock 250 110 269 minecraft:light_blue_stained_glass
setblock 252 110 229 minecraft:cyan_stained_glass
setblock 252 110 234 minecraft:sea_lantern
setblock 252 110 264 minecraft:black_stained_glass
setblock 252 110 269 minecraft:pearlescent_froglight
setblock 254 110 229 minecraft:black_stained_glass
setblock 254 110 234 minecraft:black_stained_glass
setblock 254 110 264 minecraft:cyan_stained_glass
setblock 254 110 269 minecraft:sea_lantern
setblock 256 110 229 minecraft:pearlescent_froglight
setblock 256 110 234 minecraft:sea_lantern
setblock 256 110 264 minecraft:cyan_stained_glass
setblock 256 110 269 minecraft:black_stained_glass
setblock 258 110 229 minecraft:ochre_froglight
setblock 258 110 234 minecraft:black_stained_glass
setblock 258 110 264 minecraft:cyan_stained_glass
setblock 258 110 269 minecraft:ochre_froglight
fill 258 110 270 258 252 270 minecraft:black_concrete
setblock 260 110 229 minecraft:black_stained_glass
setblock 260 110 234 minecraft:magenta_stained_glass
setblock 260 110 264 minecraft:black_stained_glass
setblock 260 110 269 minecraft:black_stained_glass
setblock 262 110 230 minecraft:cyan_stained_glass
setblock 262 110 232 minecraft:ochre_froglight
setblock 262 110 265 minecraft:light_blue_stained_glass
setblock 262 110 267 minecraft:black_stained_glass
setblock 268 110 230 minecraft:light_blue_stained_glass
setblock 268 110 232 minecraft:magenta_stained_glass
setblock 268 110 234 minecraft:cyan_stained_glass
setblock 268 110 236 minecraft:magenta_stained_glass
setblock 268 110 262 minecraft:ochre_froglight
setblock 268 110 264 minecraft:sea_lantern
setblock 268 110 266 minecraft:black_stained_glass
setblock 268 110 268 minecraft:pearlescent_froglight
setblock 269 110 229 minecraft:pearlescent_froglight
setblock 269 110 237 minecraft:pearlescent_froglight
setblock 269 110 261 minecraft:ochre_froglight
setblock 269 110 269 minecraft:pearlescent_froglight
setblock 271 110 229 minecraft:black_stained_glass
setblock 271 110 237 minecraft:black_stained_glass
setblock 271 110 243 minecraft:black_stained_glass
setblock 271 110 245 minecraft:black_stained_glass
setblock 271 110 247 minecraft:black_stained_glass
setblock 271 110 249 minecraft:light_blue_stained_glass
setblock 271 110 251 minecraft:cyan_stained_glass
setblock 271 110 253 minecraft:black_stained_glass
setblock 271 110 261 minecraft:black_stained_glass
setblock 271 110 269 minecraft:magenta_stained_glass
setblock 272 110 242 minecraft:pearlescent_froglight
setblock 272 110 255 minecraft:cyan_stained_glass
setblock 273 110 229 minecraft:magenta_stained_glass
setblock 273 110 237 minecraft:black_stained_glass
setblock 273 110 261 minecraft:sea_lantern
setblock 273 110 269 minecraft:magenta_stained_glass
setblock 274 110 242 minecraft:magenta_stained_glass
setblock 274 110 255 minecraft:black_stained_glass
setblock 275 110 229 minecraft:cyan_stained_glass
setblock 275 110 237 minecraft:black_stained_glass
setblock 275 110 261 minecraft:light_blue_stained_glass
setblock 275 110 269 minecraft:sea_lantern
setblock 276 110 230 minecraft:black_stained_glass
setblock 276 110 232 minecraft:magenta_stained_glass
setblock 276 110 234 minecraft:black_stained_glass
setblock 276 110 236 minecraft:magenta_stained_glass
setblock 276 110 243 minecraft:pearlescent_froglight
setblock 276 110 245 minecraft:magenta_stained_glass
setblock 276 110 247 minecraft:black_stained_glass
setblock 276 110 249 minecraft:black_stained_glass
setblock 276 110 251 minecraft:black_stained_glass
setblock 276 110 253 minecraft:black_stained_glass
setblock 276 110 262 minecraft:black_stained_glass
fill 276 110 264 277 110 264 minecraft:sea_lantern
setblock 276 110 266 minecraft:black_stained_glass
setblock 276 110 268 minecraft:black_stained_glass
setblock 235 111 238 minecraft:pearlescent_froglight
fill 235 111 266 235 154 266 minecraft:black_concrete
fill 236 111 230 236 112 230 minecraft:light_gray_concrete
fill 236 111 232 236 112 232 minecraft:light_gray_concrete
fill 236 111 234 236 112 234 minecraft:light_gray_concrete
fill 236 111 236 236 112 236 minecraft:light_gray_concrete
fill 236 111 243 236 112 243 minecraft:light_gray_concrete
fill 236 111 245 236 112 245 minecraft:light_gray_concrete
fill 236 111 247 236 112 247 minecraft:light_gray_concrete
fill 236 111 249 236 112 249 minecraft:light_gray_concrete
fill 236 111 251 236 112 251 minecraft:light_gray_concrete
fill 236 111 253 236 112 253 minecraft:light_gray_concrete
fill 236 111 262 236 112 262 minecraft:cyan_terracotta
fill 236 111 264 236 112 264 minecraft:cyan_terracotta
fill 236 111 266 236 112 266 minecraft:cyan_terracotta
fill 236 111 268 236 112 268 minecraft:cyan_terracotta
fill 237 111 229 237 112 229 minecraft:light_gray_concrete
fill 237 111 237 237 112 237 minecraft:light_gray_concrete
fill 237 111 242 237 112 242 minecraft:light_gray_concrete
fill 237 111 255 237 112 255 minecraft:light_gray_concrete
fill 237 111 261 237 112 261 minecraft:cyan_terracotta
fill 237 111 269 237 112 269 minecraft:cyan_terracotta
fill 239 111 229 239 112 229 minecraft:light_gray_concrete
fill 239 111 237 239 112 237 minecraft:light_gray_concrete
fill 239 111 242 239 112 242 minecraft:light_gray_concrete
fill 239 111 255 239 112 255 minecraft:light_gray_concrete
fill 239 111 261 239 112 261 minecraft:cyan_terracotta
fill 239 111 269 239 112 269 minecraft:cyan_terracotta
fill 241 111 229 241 112 229 minecraft:light_gray_concrete
fill 241 111 237 241 112 237 minecraft:light_gray_concrete
fill 241 111 243 241 112 243 minecraft:light_gray_concrete
fill 241 111 245 241 112 245 minecraft:light_gray_concrete
fill 241 111 247 241 112 247 minecraft:light_gray_concrete
fill 241 111 249 241 112 249 minecraft:light_gray_concrete
fill 241 111 251 241 112 251 minecraft:light_gray_concrete
fill 241 111 253 241 112 253 minecraft:light_gray_concrete
fill 241 111 261 241 112 261 minecraft:cyan_terracotta
fill 241 111 269 241 112 269 minecraft:cyan_terracotta
setblock 243 111 228 minecraft:magenta_concrete
fill 243 111 229 243 112 229 minecraft:light_gray_concrete
fill 243 111 237 243 112 237 minecraft:light_gray_concrete
fill 243 111 261 243 112 261 minecraft:cyan_terracotta
fill 243 111 269 243 112 269 minecraft:cyan_terracotta
fill 244 111 230 244 112 230 minecraft:light_gray_concrete
fill 244 111 232 244 112 232 minecraft:light_gray_concrete
fill 244 111 234 244 112 234 minecraft:light_gray_concrete
fill 244 111 236 244 112 236 minecraft:light_gray_concrete
fill 244 111 262 244 112 262 minecraft:cyan_terracotta
fill 244 111 264 244 112 264 minecraft:cyan_terracotta
fill 244 111 266 244 112 266 minecraft:cyan_terracotta
fill 244 111 268 244 112 268 minecraft:cyan_terracotta
fill 249 111 230 249 112 230 minecraft:light_gray_concrete
fill 249 111 232 249 112 232 minecraft:light_gray_concrete
fill 249 111 265 249 112 265 minecraft:cyan_terracotta
fill 249 111 267 249 112 267 minecraft:cyan_terracotta
fill 250 111 229 250 112 229 minecraft:light_gray_concrete
fill 250 111 234 250 112 234 minecraft:light_gray_concrete
fill 250 111 264 250 112 264 minecraft:cyan_terracotta
fill 250 111 269 250 112 269 minecraft:cyan_terracotta
fill 252 111 229 252 112 229 minecraft:light_gray_concrete
fill 252 111 234 252 112 234 minecraft:light_gray_concrete
fill 252 111 264 252 112 264 minecraft:cyan_terracotta
fill 252 111 269 252 112 269 minecraft:cyan_terracotta
fill 254 111 229 254 112 229 minecraft:light_gray_concrete
fill 254 111 234 254 112 234 minecraft:light_gray_concrete
fill 254 111 264 254 112 264 minecraft:cyan_terracotta
fill 254 111 269 254 112 269 minecraft:cyan_terracotta
fill 256 111 229 256 112 229 minecraft:light_gray_concrete
fill 256 111 234 256 112 234 minecraft:light_gray_concrete
fill 256 111 264 256 112 264 minecraft:cyan_terracotta
fill 256 111 269 256 112 269 minecraft:cyan_terracotta
fill 258 111 229 258 112 229 minecraft:light_gray_concrete
fill 258 111 234 258 112 234 minecraft:light_gray_concrete
fill 258 111 264 258 112 264 minecraft:cyan_terracotta
fill 258 111 269 258 112 269 minecraft:cyan_terracotta
fill 260 111 229 260 112 229 minecraft:light_gray_concrete
fill 260 111 234 260 112 234 minecraft:light_gray_concrete
fill 260 111 264 260 112 264 minecraft:cyan_terracotta
fill 260 111 269 260 112 269 minecraft:cyan_terracotta
fill 262 111 230 262 112 230 minecraft:light_gray_concrete
fill 262 111 232 262 112 232 minecraft:light_gray_concrete
fill 262 111 265 262 112 265 minecraft:cyan_terracotta
fill 262 111 267 262 112 267 minecraft:cyan_terracotta
setblock 266 111 270 minecraft:verdant_froglight
fill 267 111 270 268 118 270 minecraft:black_concrete
fill 268 111 230 268 112 230 minecraft:cyan_terracotta
fill 268 111 232 268 112 232 minecraft:cyan_terracotta
fill 268 111 234 268 112 234 minecraft:cyan_terracotta
fill 268 111 236 268 112 236 minecraft:cyan_terracotta
fill 268 111 262 268 112 262 minecraft:light_gray_concrete
fill 268 111 264 268 112 264 minecraft:light_gray_concrete
fill 268 111 266 268 112 266 minecraft:light_gray_concrete
fill 268 111 268 268 112 268 minecraft:light_gray_concrete
fill 269 111 229 269 112 229 minecraft:cyan_terracotta
fill 269 111 237 269 112 237 minecraft:cyan_terracotta
fill 269 111 261 269 112 261 minecraft:light_gray_concrete
fill 269 111 269 269 112 269 minecraft:light_gray_concrete
fill 271 111 229 271 112 229 minecraft:cyan_terracotta
fill 271 111 237 271 112 237 minecraft:cyan_terracotta
fill 271 111 243 271 112 243 minecraft:light_gray_concrete
fill 271 111 245 271 112 245 minecraft:light_gray_concrete
fill 271 111 247 271 112 247 minecraft:light_gray_concrete
fill 271 111 249 271 112 249 minecraft:light_gray_concrete
fill 271 111 251 271 112 251 minecraft:light_gray_concrete
fill 271 111 253 271 112 253 minecraft:light_gray_concrete
fill 271 111 261 271 112 261 minecraft:light_gray_concrete
fill 271 111 269 271 112 269 minecraft:light_gray_concrete
fill 272 111 242 272 112 242 minecraft:light_gray_concrete
fill 272 111 255 272 112 255 minecraft:light_gray_concrete
fill 273 111 229 273 112 229 minecraft:cyan_terracotta
fill 273 111 237 273 112 237 minecraft:cyan_terracotta
fill 273 111 261 273 112 261 minecraft:light_gray_concrete
fill 273 111 269 273 112 269 minecraft:light_gray_concrete
fill 274 111 242 274 112 242 minecraft:light_gray_concrete
fill 274 111 255 274 112 255 minecraft:light_gray_concrete
fill 275 111 229 275 112 229 minecraft:cyan_terracotta
fill 275 111 237 275 112 237 minecraft:cyan_terracotta
fill 275 111 261 275 112 261 minecraft:light_gray_concrete
fill 275 111 269 275 112 269 minecraft:light_gray_concrete
fill 276 111 230 276 112 230 minecraft:cyan_terracotta
fill 276 111 232 276 112 232 minecraft:cyan_terracotta
fill 276 111 234 276 112 234 minecraft:cyan_terracotta
fill 276 111 236 276 112 236 minecraft:cyan_terracotta
fill 276 111 243 276 112 243 minecraft:light_gray_concrete
fill 276 111 245 276 112 245 minecraft:light_gray_concrete
fill 276 111 247 276 112 247 minecraft:light_gray_concrete
fill 276 111 249 276 112 249 minecraft:light_gray_concrete
fill 276 111 251 276 112 251 minecraft:light_gray_concrete
fill 276 111 253 276 112 253 minecraft:light_gray_concrete
fill 276 111 262 276 112 262 minecraft:light_gray_concrete
fill 276 111 264 276 112 264 minecraft:light_gray_concrete
fill 276 111 266 276 112 266 minecraft:light_gray_concrete
fill 276 111 268 276 112 268 minecraft:light_gray_concrete
fill 277 111 264 277 175 264 minecraft:black_concrete
fill 235 112 238 235 168 238 minecraft:black_concrete
fill 243 112 228 243 122 228 minecraft:black_concrete
fill 266 112 270 266 117 270 minecraft:black_concrete
fill 277 112 253 277 119 253 minecraft:black_concrete
setblock 277 112 254 minecraft:cyan_concrete
setblock 236 113 230 minecraft:pearlescent_froglight
setblock 236 113 232 minecraft:black_stained_glass
setblock 236 113 234 minecraft:pearlescent_froglight
setblock 236 113 236 minecraft:ochre_froglight
setblock 236 113 243 minecraft:magenta_stained_glass
setblock 236 113 245 minecraft:pearlescent_froglight
setblock 236 113 247 minecraft:black_stained_glass
setblock 236 113 249 minecraft:magenta_stained_glass
setblock 236 113 251 minecraft:magenta_stained_glass
setblock 236 113 253 minecraft:cyan_stained_glass
setblock 236 113 262 minecraft:black_stained_glass
setblock 236 113 264 minecraft:black_stained_glass
setblock 236 113 266 minecraft:sea_lantern
setblock 236 113 268 minecraft:black_stained_glass
setblock 237 113 229 minecraft:black_stained_glass
setblock 237 113 237 minecraft:light_blue_stained_glass
setblock 237 113 242 minecraft:black_stained_glass
setblock 237 113 255 minecraft:light_blue_stained_glass
setblock 237 113 261 minecraft:sea_lantern
setblock 237 113 269 minecraft:light_blue_stained_glass
setblock 239 113 229 minecraft:sea_lantern
setblock 239 113 237 minecraft:sea_lantern
setblock 239 113 242 minecraft:black_stained_glass
setblock 239 113 255 minecraft:black_stained_glass
setblock 239 113 261 minecraft:sea_lantern
setblock 239 113 269 minecraft:sea_lantern
setblock 241 113 229 minecraft:black_stained_glass
setblock 241 113 237 minecraft:black_stained_glass
setblock 241 113 243 minecraft:ochre_froglight
setblock 241 113 245 minecraft:black_stained_glass
setblock 241 113 247 minecraft:black_stained_glass
setblock 241 113 249 minecraft:light_blue_stained_glass
setblock 241 113 251 minecraft:black_stained_glass
setblock 241 113 253 minecraft:black_stained_glass
setblock 241 113 261 minecraft:pearlescent_froglight
setblock 241 113 269 minecraft:light_blue_stained_glass
setblock 243 113 229 minecraft:black_stained_glass
setblock 243 113 237 minecraft:black_stained_glass
setblock 243 113 261 minecraft:pearlescent_froglight
setblock 243 113 269 minecraft:black_stained_glass
setblock 244 113 230 minecraft:pearlescent_froglight
setblock 244 113 232 minecraft:black_stained_glass
setblock 244 113 234 minecraft:cyan_stained_glass
setblock 244 113 236 minecraft:cyan_stained_glass
setblock 244 113 262 minecraft:light_blue_stained_glass
setblock 244 113 264 minecraft:ochre_froglight
setblock 244 113 266 minecraft:black_stained_glass
setblock 244 113 268 minecraft:ochre_froglight
setblock 249 113 230 minecraft:cyan_stained_glass
setblock 249 113 232 minecraft:magenta_stained_glass
setblock 249 113 265 minecraft:black_stained_glass
setblock 249 113 267 minecraft:black_stained_glass
setblock 250 113 229 minecraft:ochre_froglight
setblock 250 113 234 minecraft:black_stained_glass
setblock 250 113 264 minecraft:sea_lantern
setblock 250 113 269 minecraft:black_stained_glass
setblock 252 113 229 minecraft:magenta_stained_glass
setblock 252 113 234 minecraft:black_stained_glass
setblock 252 113 264 minecraft:black_stained_glass
setblock 252 113 269 minecraft:light_blue_stained_glass
setblock 254 113 229 minecraft:pearlescent_froglight
setblock 254 113 234 minecraft:black_stained_glass
setblock 254 113 264 minecraft:pearlescent_froglight
setblock 254 113 269 minecraft:magenta_stained_glass
setblock 256 113 229 minecraft:black_stained_glass
setblock 256 113 234 minecraft:black_stained_glass
setblock 256 113 264 minecraft:light_blue_stained_glass
setblock 256 113 269 minecraft:black_stained_glass
setblock 258 113 229 minecraft:ochre_froglight
setblock 258 113 234 minecraft:black_stained_glass
setblock 258 113 264 minecraft:ochre_froglight
setblock 258 113 269 minecraft:ochre_froglight
setblock 260 113 229 minecraft:black_stained_glass
setblock 260 113 234 minecraft:cyan_stained_glass
setblock 260 113 264 minecraft:black_stained_glass
setblock 260 113 269 minecraft:black_stained_glass
setblock 262 113 230 minecraft:cyan_stained_glass
setblock 262 113 232 minecraft:sea_lantern
setblock 262 113 265 minecraft:ochre_froglight
setblock 262 113 267 minecraft:sea_lantern
setblock 268 113 230 minecraft:black_stained_glass
setblock 268 113 232 minecraft:magenta_stained_glass
setblock 268 113 234 minecraft:ochre_froglight
setblock 268 113 236 minecraft:pearlescent_froglight
setblock 268 113 262 minecraft:pearlescent_froglight
setblock 268 113 264 minecraft:magenta_stained_glass
setblock 268 113 266 minecraft:magenta_stained_glass
setblock 268 113 268 minecraft:black_stained_glass
setblock 269 113 229 minecraft:black_stained_glass
setblock 269 113 237 minecraft:cyan_stained_glass
setblock 269 113 261 minecraft:black_stained_glass
setblock 269 113 269 minecraft:light_blue_stained_glass
setblock 271 113 229 minecraft:pearlescent_froglight
setblock 271 113 237 minecraft:pearlescent_froglight
setblock 271 113 243 minecraft:black_stained_glass
setblock 271 113 245 minecraft:cyan_stained_glass
setblock 271 113 247 minecraft:cyan_stained_glass
setblock 271 113 249 minecraft:black_stained_glass
setblock 271 113 251 minecraft:sea_lantern
setblock 271 113 253 minecraft:pearlescent_froglight
setblock 271 113 261 minecraft:pearlescent_froglight
setblock 271 113 269 minecraft:sea_lantern
setblock 272 113 242 minecraft:sea_lantern
setblock 272 113 255 minecraft:pearlescent_froglight
setblock 273 113 229 minecraft:black_stained_glass
setblock 273 113 237 minecraft:light_blue_stained_glass
setblock 273 113 261 minecraft:sea_lantern
setblock 273 113 269 minecraft:light_blue_stained_glass
setblock 274 113 242 minecraft:cyan_stained_glass
setblock 274 113 255 minecraft:black_stained_glass
setblock 275 113 229 minecraft:cyan_stained_glass
setblock 275 113 237 minecraft:light_blue_stained_glass
setblock 275 113 261 minecraft:magenta_stained_glass
setblock 275 113 269 minecraft:ochre_froglight
setblock 276 113 230 minecraft:cyan_stained_glass
setblock 276 113 232 minecraft:sea_lantern
setblock 276 113 234 minecraft:black_stained_glass
setblock 276 113 236 minecraft:light_blue_stained_glass
setblock 276 113 243 minecraft:black_stained_glass
setblock 276 113 245 minecraft:black_stained_glass
setblock 276 113 247 minecraft:black_stained_glass
setblock 276 113 249 minecraft:pearlescent_froglight
setblock 276 113 251 minecraft:black_stained_glass
setblock 276 113 253 minecraft:black_stained_glass
setblock 276 113 262 minecraft:sea_lantern
setblock 276 113 264 minecraft:light_blue_stained_glass
setblock 276 113 266 minecraft:sea_lantern
setblock 276 113 268 minecraft:black_stained_glass
setblock 277 113 229 minecraft:magenta_concrete
fill 277 113 254 277 116 254 minecraft:black_concrete
fill 236 114 230 236 115 230 minecraft:light_gray_concrete
fill 236 114 232 236 115 232 minecraft:light_gray_concrete
fill 236 114 234 236 115 234 minecraft:light_gray_concrete
fill 236 114 236 236 115 236 minecraft:light_gray_concrete
fill 236 114 243 236 115 243 minecraft:light_gray_concrete
fill 236 114 245 236 115 245 minecraft:light_gray_concrete
fill 236 114 247 236 115 247 minecraft:light_gray_concrete
fill 236 114 249 236 115 249 minecraft:light_gray_concrete
fill 236 114 251 236 115 251 minecraft:light_gray_concrete
fill 236 114 253 236 115 253 minecraft:light_gray_concrete
fill 236 114 262 236 115 262 minecraft:cyan_terracotta
fill 236 114 264 236 115 264 minecraft:cyan_terracotta
fill 236 114 266 236 115 266 minecraft:cyan_terracotta
fill 236 114 268 236 115 268 minecraft:cyan_terracotta
fill 237 114 229 237 115 229 minecraft:light_gray_concrete
fill 237 114 237 237 115 237 minecraft:light_gray_concrete
fill 237 114 242 237 115 242 minecraft:light_gray_concrete
fill 237 114 255 237 115 255 minecraft:light_gray_concrete
fill 237 114 261 237 115 261 minecraft:cyan_terracotta
fill 237 114 269 237 115 269 minecraft:cyan_terracotta
fill 239 114 229 239 115 229 minecraft:light_gray_concrete
fill 239 114 237 239 115 237 minecraft:light_gray_concrete
fill 239 114 242 239 115 242 minecraft:light_gray_concrete
fill 239 114 255 239 115 255 minecraft:light_gray_concrete
fill 239 114 261 239 115 261 minecraft:cyan_terracotta
fill 239 114 269 239 115 269 minecraft:cyan_terracotta
fill 241 114 229 241 115 229 minecraft:light_gray_concrete
fill 241 114 237 241 115 237 minecraft:light_gray_concrete
fill 241 114 243 241 115 243 minecraft:light_gray_concrete
fill 241 114 245 241 115 245 minecraft:light_gray_concrete
fill 241 114 247 241 115 247 minecraft:light_gray_concrete
fill 241 114 249 241 115 249 minecraft:light_gray_concrete
fill 241 114 251 241 115 251 minecraft:light_gray_concrete
fill 241 114 253 241 115 253 minecraft:light_gray_concrete
schedule function dropper:buildpart/53_3 1t
