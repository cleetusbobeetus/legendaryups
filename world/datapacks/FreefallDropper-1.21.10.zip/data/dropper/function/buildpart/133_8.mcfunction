setblock 50 206 562 minecraft:calcite
fill 50 206 563 50 209 563 minecraft:cobbled_deepslate
fill 50 206 565 50 206 566 minecraft:cobbled_deepslate
setblock 52 206 560 minecraft:calcite
setblock 53 206 559 minecraft:calcite
fill 53 206 560 53 209 560 minecraft:cobbled_deepslate
setblock 54 206 558 minecraft:calcite
fill 54 206 559 54 209 559 minecraft:cobbled_deepslate
setblock 54 206 598 minecraft:calcite
fill 55 206 558 55 209 558 minecraft:cobbled_deepslate
setblock 55 206 597 minecraft:calcite
fill 55 206 598 55 209 598 minecraft:cobbled_deepslate
fill 56 206 597 56 209 597 minecraft:cobbled_deepslate
setblock 57 206 560 minecraft:calcite
setblock 58 206 559 minecraft:calcite
fill 58 206 560 58 207 560 minecraft:cobbled_deepslate
fill 58 206 597 58 206 598 minecraft:cobbled_deepslate
setblock 59 206 558 minecraft:calcite
fill 59 206 559 59 208 559 minecraft:cobbled_deepslate
setblock 59 206 598 minecraft:calcite
fill 60 206 558 60 209 558 minecraft:cobbled_deepslate
fill 60 206 598 60 209 598 minecraft:cobbled_deepslate
fill 72 206 598 72 207 598 minecraft:cobbled_deepslate
setblock 74 206 558 minecraft:calcite
setblock 74 206 598 minecraft:calcite
fill 75 206 558 75 209 558 minecraft:cobbled_deepslate
fill 75 206 598 75 209 598 minecraft:cobbled_deepslate
setblock 87 206 564 minecraft:cobbled_deepslate
setblock 87 206 565 minecraft:calcite
fill 87 206 566 87 209 566 minecraft:cobbled_deepslate
fill 88 206 560 88 209 560 minecraft:cobbled_deepslate
setblock 88 206 564 minecraft:calcite
fill 88 206 565 88 209 565 minecraft:cobbled_deepslate
setblock 88 206 568 minecraft:cobbled_deepslate
setblock 88 206 569 minecraft:calcite
fill 88 206 570 88 208 571 minecraft:cobbled_deepslate
setblock 88 206 583 minecraft:cobbled_deepslate
setblock 88 206 584 minecraft:calcite
fill 88 206 585 88 209 585 minecraft:cobbled_deepslate
fill 88 206 587 88 207 587 minecraft:cobbled_deepslate
setblock 48 207 558 minecraft:calcite
fill 48 207 559 48 210 559 minecraft:cobbled_deepslate
setblock 48 207 563 minecraft:calcite
fill 48 207 564 48 210 564 minecraft:cobbled_deepslate
setblock 48 207 567 minecraft:cobbled_deepslate
setblock 48 207 568 minecraft:calcite
fill 48 207 569 49 209 569 minecraft:cobbled_deepslate
fill 48 207 571 48 208 571 minecraft:cobbled_deepslate
fill 48 207 585 48 207 587 minecraft:cobbled_deepslate
setblock 48 207 588 minecraft:calcite
fill 49 207 558 49 210 558 minecraft:cobbled_deepslate
setblock 49 207 562 minecraft:calcite
fill 49 207 563 49 210 563 minecraft:cobbled_deepslate
setblock 49 207 567 minecraft:calcite
fill 49 207 568 49 210 568 minecraft:cobbled_deepslate
setblock 50 207 560 minecraft:cobbled_deepslate
setblock 50 207 561 minecraft:calcite
fill 50 207 562 50 210 562 minecraft:cobbled_deepslate
setblock 50 207 565 minecraft:cobbled_deepslate
setblock 50 207 566 minecraft:calcite
fill 50 207 567 50 210 567 minecraft:cobbled_deepslate
setblock 51 207 560 minecraft:calcite
fill 51 207 563 51 207 564 minecraft:cobbled_deepslate
fill 51 207 598 51 208 598 minecraft:cobbled_deepslate
setblock 52 207 559 minecraft:calcite
fill 52 207 560 52 210 560 minecraft:cobbled_deepslate
setblock 53 207 558 minecraft:calcite
fill 53 207 559 53 210 559 minecraft:cobbled_deepslate
fill 53 207 561 53 208 561 minecraft:cobbled_deepslate
setblock 53 207 597 minecraft:cobbled_deepslate
setblock 53 207 598 minecraft:calcite
fill 54 207 558 54 210 558 minecraft:cobbled_deepslate
setblock 54 207 597 minecraft:calcite
fill 54 207 598 54 210 598 minecraft:cobbled_deepslate
setblock 55 207 561 minecraft:calcite
fill 55 207 597 55 210 597 minecraft:cobbled_deepslate
setblock 56 207 560 minecraft:calcite
setblock 57 207 559 minecraft:calcite
fill 57 207 560 57 208 560 minecraft:cobbled_deepslate
setblock 58 207 558 minecraft:calcite
fill 58 207 559 58 209 559 minecraft:cobbled_deepslate
setblock 58 207 597 minecraft:cobbled_deepslate
setblock 58 207 598 minecraft:calcite
fill 59 207 558 59 210 558 minecraft:cobbled_deepslate
fill 59 207 598 59 210 598 minecraft:cobbled_deepslate
fill 61 207 558 61 208 558 minecraft:cobbled_deepslate
fill 71 207 598 71 208 598 minecraft:cobbled_deepslate
setblock 73 207 558 minecraft:calcite
setblock 73 207 598 minecraft:calcite
fill 74 207 558 74 210 558 minecraft:cobbled_deepslate
fill 74 207 598 74 210 598 minecraft:cobbled_deepslate
setblock 87 207 563 minecraft:cobbled_deepslate
setblock 87 207 564 minecraft:calcite
fill 87 207 565 87 210 565 minecraft:cobbled_deepslate
fill 87 207 567 87 207 568 minecraft:cobbled_deepslate
setblock 87 207 569 minecraft:calcite
setblock 88 207 563 minecraft:calcite
fill 88 207 564 88 210 564 minecraft:cobbled_deepslate
setblock 88 207 568 minecraft:calcite
fill 88 207 569 88 210 569 minecraft:cobbled_deepslate
setblock 88 207 572 minecraft:cobbled_deepslate
setblock 88 207 573 minecraft:calcite
fill 88 207 580 88 209 580 minecraft:cobbled_deepslate
setblock 88 207 583 minecraft:calcite
fill 88 207 584 88 210 584 minecraft:cobbled_deepslate
setblock 88 207 588 minecraft:calcite
fill 48 208 558 48 211 558 minecraft:cobbled_deepslate
setblock 48 208 562 minecraft:calcite
fill 48 208 563 48 211 563 minecraft:cobbled_deepslate
setblock 48 208 566 minecraft:cobbled_deepslate
setblock 48 208 567 minecraft:calcite
fill 48 208 568 48 211 568 minecraft:cobbled_deepslate
setblock 48 208 572 minecraft:calcite
fill 48 208 584 48 208 586 minecraft:cobbled_deepslate
setblock 48 208 587 minecraft:calcite
fill 48 208 588 48 208 591 minecraft:cobbled_deepslate
setblock 49 208 561 minecraft:calcite
fill 49 208 562 49 211 562 minecraft:cobbled_deepslate
setblock 49 208 566 minecraft:calcite
fill 49 208 567 49 211 567 minecraft:cobbled_deepslate
setblock 49 208 570 minecraft:cobbled_deepslate
setblock 50 208 560 minecraft:calcite
fill 50 208 561 50 211 561 minecraft:cobbled_deepslate
setblock 50 208 565 minecraft:calcite
fill 50 208 566 51 210 566 minecraft:cobbled_deepslate
fill 50 208 568 50 208 569 minecraft:cobbled_deepslate
setblock 50 208 576 minecraft:light[level=14]
setblock 50 208 584 minecraft:light[level=14]
setblock 50 208 592 minecraft:light[level=14]
fill 50 208 598 50 209 598 minecraft:cobbled_deepslate
setblock 51 208 559 minecraft:calcite
fill 51 208 560 51 211 560 minecraft:cobbled_deepslate
fill 51 208 562 51 208 563 minecraft:cobbled_deepslate
setblock 51 208 564 minecraft:calcite
fill 51 208 565 51 211 565 minecraft:cobbled_deepslate
setblock 52 208 558 minecraft:calcite
fill 52 208 559 52 211 559 minecraft:cobbled_deepslate
fill 52 208 561 52 209 561 minecraft:cobbled_deepslate
setblock 52 208 597 minecraft:cobbled_deepslate
setblock 52 208 598 minecraft:calcite
fill 53 208 558 53 211 558 minecraft:cobbled_deepslate
setblock 53 208 597 minecraft:calcite
fill 53 208 598 53 211 598 minecraft:cobbled_deepslate
setblock 54 208 560 minecraft:cobbled_deepslate
setblock 54 208 561 minecraft:calcite
fill 54 208 597 54 211 597 minecraft:cobbled_deepslate
setblock 55 208 560 minecraft:calcite
setblock 56 208 559 minecraft:calcite
fill 56 208 560 56 209 560 minecraft:cobbled_deepslate
setblock 57 208 558 minecraft:calcite
fill 57 208 559 57 210 559 minecraft:cobbled_deepslate
setblock 57 208 598 minecraft:calcite
fill 58 208 558 58 211 558 minecraft:cobbled_deepslate
setblock 58 208 560 minecraft:light[level=14]
setblock 58 208 568 minecraft:light[level=14]
setblock 58 208 576 minecraft:light[level=14]
setblock 58 208 584 minecraft:light[level=14]
setblock 58 208 592 minecraft:light[level=14]
setblock 58 208 597 minecraft:calcite
fill 58 208 598 58 211 598 minecraft:cobbled_deepslate
setblock 66 208 560 minecraft:light[level=14]
setblock 66 208 568 minecraft:light[level=14]
setblock 66 208 576 minecraft:light[level=14]
setblock 66 208 584 minecraft:light[level=14]
setblock 66 208 592 minecraft:light[level=14]
fill 69 208 598 70 209 598 minecraft:cobbled_deepslate
setblock 72 208 558 minecraft:calcite
setblock 72 208 598 minecraft:calcite
fill 73 208 558 73 211 558 minecraft:cobbled_deepslate
fill 73 208 598 73 211 598 minecraft:cobbled_deepslate
setblock 74 208 560 minecraft:light[level=14]
setblock 74 208 568 minecraft:light[level=14]
setblock 74 208 576 minecraft:light[level=14]
setblock 74 208 584 minecraft:light[level=14]
setblock 74 208 592 minecraft:light[level=14]
setblock 82 208 560 minecraft:light[level=14]
setblock 82 208 568 minecraft:light[level=14]
setblock 82 208 576 minecraft:light[level=14]
setblock 82 208 584 minecraft:light[level=14]
setblock 82 208 592 minecraft:light[level=14]
setblock 87 208 562 minecraft:cobbled_deepslate
setblock 87 208 563 minecraft:calcite
fill 87 208 564 87 211 564 minecraft:cobbled_deepslate
setblock 87 208 567 minecraft:cobbled_deepslate
setblock 87 208 568 minecraft:calcite
fill 87 208 569 87 209 571 minecraft:cobbled_deepslate
fill 88 208 559 88 210 559 minecraft:cobbled_deepslate
setblock 88 208 562 minecraft:calcite
fill 88 208 563 88 211 563 minecraft:cobbled_deepslate
setblock 88 208 567 minecraft:calcite
fill 88 208 568 88 211 568 minecraft:cobbled_deepslate
setblock 88 208 572 minecraft:calcite
fill 88 208 573 88 209 575 minecraft:cobbled_deepslate
setblock 88 208 582 minecraft:calcite
fill 88 208 583 88 211 583 minecraft:cobbled_deepslate
setblock 88 208 587 minecraft:calcite
fill 88 208 588 88 209 590 minecraft:cobbled_deepslate
setblock 48 209 561 minecraft:calcite
fill 48 209 562 48 212 562 minecraft:cobbled_deepslate
setblock 48 209 566 minecraft:calcite
fill 48 209 567 48 212 567 minecraft:cobbled_deepslate
setblock 48 209 571 minecraft:calcite
fill 48 209 572 48 211 573 minecraft:cobbled_deepslate
fill 48 209 584 48 209 585 minecraft:cobbled_deepslate
setblock 48 209 586 minecraft:calcite
fill 48 209 587 48 209 590 minecraft:cobbled_deepslate
setblock 48 209 591 minecraft:calcite
fill 48 209 592 48 209 595 minecraft:cobbled_deepslate
setblock 49 209 560 minecraft:calcite
fill 49 209 561 49 212 561 minecraft:cobbled_deepslate
setblock 49 209 565 minecraft:calcite
fill 49 209 566 49 212 566 minecraft:cobbled_deepslate
setblock 49 209 570 minecraft:calcite
fill 49 209 571 49 211 572 minecraft:cobbled_deepslate
fill 49 209 586 49 209 589 minecraft:cobbled_deepslate
setblock 49 209 590 minecraft:calcite
fill 49 209 591 49 211 592 minecraft:cobbled_deepslate
fill 49 209 598 49 210 598 minecraft:cobbled_deepslate
setblock 50 209 559 minecraft:calcite
fill 50 209 560 50 212 560 minecraft:cobbled_deepslate
setblock 50 209 564 minecraft:calcite
fill 50 209 565 50 212 565 minecraft:cobbled_deepslate
setblock 50 209 568 minecraft:cobbled_deepslate
setblock 50 209 569 minecraft:calcite
fill 50 209 570 50 212 570 minecraft:cobbled_deepslate
setblock 51 209 558 minecraft:calcite
fill 51 209 559 51 212 559 minecraft:cobbled_deepslate
setblock 51 209 562 minecraft:cobbled_deepslate
setblock 51 209 563 minecraft:calcite
fill 51 209 564 51 211 564 minecraft:cobbled_deepslate
setblock 51 209 567 minecraft:cobbled_deepslate
setblock 51 209 597 minecraft:cobbled_deepslate
setblock 51 209 598 minecraft:calcite
fill 52 209 558 52 212 558 minecraft:cobbled_deepslate
setblock 52 209 597 minecraft:calcite
fill 52 209 598 52 212 598 minecraft:cobbled_deepslate
setblock 53 209 561 minecraft:calcite
fill 53 209 597 53 212 597 minecraft:cobbled_deepslate
setblock 54 209 560 minecraft:calcite
fill 54 209 596 55 211 596 minecraft:cobbled_deepslate
setblock 55 209 559 minecraft:calcite
fill 55 209 560 55 210 560 minecraft:cobbled_deepslate
setblock 56 209 558 minecraft:calcite
fill 56 209 559 56 211 559 minecraft:cobbled_deepslate
setblock 56 209 598 minecraft:calcite
fill 57 209 558 57 212 558 minecraft:cobbled_deepslate
setblock 57 209 597 minecraft:calcite
fill 57 209 598 57 212 598 minecraft:cobbled_deepslate
fill 58 209 597 59 211 597 minecraft:cobbled_deepslate
setblock 61 209 598 minecraft:calcite
fill 62 209 598 62 212 598 minecraft:cobbled_deepslate
fill 68 209 598 68 211 598 minecraft:cobbled_deepslate
setblock 71 209 598 minecraft:calcite
fill 72 209 558 72 211 558 minecraft:cobbled_deepslate
fill 72 209 598 72 212 598 minecraft:cobbled_deepslate
setblock 76 209 558 minecraft:calcite
setblock 76 209 598 minecraft:calcite
fill 86 209 566 86 209 567 minecraft:cobbled_deepslate
setblock 86 209 568 minecraft:calcite
setblock 87 209 562 minecraft:calcite
fill 87 209 563 87 212 563 minecraft:cobbled_deepslate
setblock 87 209 567 minecraft:calcite
fill 87 209 568 87 212 568 minecraft:cobbled_deepslate
setblock 87 209 572 minecraft:calcite
fill 88 209 558 88 211 558 minecraft:cobbled_deepslate
setblock 88 209 561 minecraft:calcite
fill 88 209 562 88 212 562 minecraft:cobbled_deepslate
setblock 88 209 566 minecraft:calcite
fill 88 209 567 88 212 567 minecraft:cobbled_deepslate
setblock 88 209 570 minecraft:cobbled_deepslate
setblock 88 209 571 minecraft:calcite
fill 88 209 572 88 212 572 minecraft:cobbled_deepslate
setblock 88 209 576 minecraft:calcite
fill 88 209 577 88 210 579 minecraft:cobbled_deepslate
setblock 88 209 581 minecraft:calcite
fill 88 209 582 88 212 582 minecraft:cobbled_deepslate
setblock 88 209 586 minecraft:calcite
fill 88 209 587 88 212 587 minecraft:cobbled_deepslate
setblock 88 209 591 minecraft:calcite
setblock 48 210 560 minecraft:calcite
fill 48 210 561 48 213 561 minecraft:cobbled_deepslate
setblock 48 210 565 minecraft:calcite
fill 48 210 566 48 213 566 minecraft:cobbled_deepslate
setblock 48 210 569 minecraft:cobbled_deepslate
setblock 48 210 570 minecraft:calcite
fill 48 210 571 48 213 571 minecraft:cobbled_deepslate
setblock 48 210 574 minecraft:cobbled_deepslate
fill 48 210 583 48 210 584 minecraft:cobbled_deepslate
setblock 48 210 585 minecraft:calcite
fill 48 210 586 48 210 589 minecraft:cobbled_deepslate
setblock 48 210 590 minecraft:calcite
fill 48 210 591 48 210 594 minecraft:cobbled_deepslate
setblock 48 210 595 minecraft:calcite
fill 48 210 596 48 211 598 minecraft:cobbled_deepslate
setblock 49 210 559 minecraft:calcite
fill 49 210 560 49 213 560 minecraft:cobbled_deepslate
setblock 49 210 564 minecraft:calcite
fill 49 210 565 49 213 565 minecraft:cobbled_deepslate
setblock 49 210 569 minecraft:calcite
fill 49 210 570 49 213 570 minecraft:cobbled_deepslate
fill 49 210 586 49 210 588 minecraft:cobbled_deepslate
setblock 49 210 589 minecraft:calcite
fill 49 210 590 50 212 590 minecraft:cobbled_deepslate
setblock 49 210 593 minecraft:cobbled_deepslate
setblock 49 210 594 minecraft:calcite
fill 49 210 595 49 213 595 minecraft:cobbled_deepslate
setblock 50 210 558 minecraft:calcite
fill 50 210 559 50 213 559 minecraft:cobbled_deepslate
setblock 50 210 563 minecraft:calcite
fill 50 210 564 50 213 564 minecraft:cobbled_deepslate
setblock 50 210 568 minecraft:calcite
fill 50 210 569 50 213 569 minecraft:cobbled_deepslate
fill 50 210 571 50 211 571 minecraft:cobbled_deepslate
setblock 50 210 588 minecraft:calcite
fill 50 210 589 50 213 589 minecraft:cobbled_deepslate
fill 50 210 591 50 210 592 minecraft:cobbled_deepslate
setblock 50 210 597 minecraft:cobbled_deepslate
setblock 50 210 598 minecraft:calcite
fill 51 210 558 51 213 558 minecraft:cobbled_deepslate
setblock 51 210 562 minecraft:calcite
fill 51 210 563 51 211 563 minecraft:cobbled_deepslate
setblock 51 210 567 minecraft:calcite
fill 51 210 568 51 212 568 minecraft:cobbled_deepslate
setblock 51 210 597 minecraft:calcite
fill 51 210 598 51 213 598 minecraft:cobbled_deepslate
setblock 52 210 596 minecraft:calcite
fill 52 210 597 52 213 597 minecraft:cobbled_deepslate
setblock 53 210 560 minecraft:calcite
fill 53 210 596 53 213 596 minecraft:cobbled_deepslate
setblock 54 210 559 minecraft:calcite
fill 54 210 560 54 211 560 minecraft:cobbled_deepslate
setblock 55 210 558 minecraft:calcite
fill 55 210 559 55 212 559 minecraft:cobbled_deepslate
setblock 55 210 598 minecraft:calcite
fill 56 210 558 56 213 558 minecraft:cobbled_deepslate
setblock 56 210 596 minecraft:cobbled_deepslate
setblock 56 210 597 minecraft:calcite
fill 56 210 598 56 213 598 minecraft:cobbled_deepslate
fill 57 210 597 57 213 597 minecraft:cobbled_deepslate
setblock 60 210 598 minecraft:calcite
fill 61 210 598 61 213 598 minecraft:cobbled_deepslate
fill 67 210 598 67 212 598 minecraft:cobbled_deepslate
setblock 69 210 598 minecraft:cobbled_deepslate
setblock 70 210 597 minecraft:cobbled_deepslate
setblock 70 210 598 minecraft:calcite
setblock 71 210 558 minecraft:cobbled_deepslate
setblock 71 210 597 minecraft:calcite
fill 71 210 598 71 213 598 minecraft:cobbled_deepslate
fill 72 210 597 73 212 597 minecraft:cobbled_deepslate
setblock 75 210 558 minecraft:calcite
setblock 75 210 598 minecraft:calcite
fill 76 210 598 76 211 598 minecraft:cobbled_deepslate
fill 86 210 565 86 210 566 minecraft:cobbled_deepslate
setblock 86 210 567 minecraft:calcite
fill 86 210 568 86 211 570 minecraft:cobbled_deepslate
setblock 87 210 561 minecraft:calcite
fill 87 210 562 87 213 562 minecraft:cobbled_deepslate
setblock 87 210 566 minecraft:calcite
fill 87 210 567 87 213 567 minecraft:cobbled_deepslate
fill 87 210 569 87 210 570 minecraft:cobbled_deepslate
setblock 87 210 571 minecraft:calcite
fill 87 210 572 87 211 574 minecraft:cobbled_deepslate
setblock 88 210 560 minecraft:calcite
fill 88 210 561 88 213 561 minecraft:cobbled_deepslate
setblock 88 210 565 minecraft:calcite
fill 88 210 566 88 213 566 minecraft:cobbled_deepslate
setblock 88 210 570 minecraft:calcite
fill 88 210 571 88 213 571 minecraft:cobbled_deepslate
fill 88 210 573 88 210 574 minecraft:cobbled_deepslate
setblock 88 210 575 minecraft:calcite
fill 88 210 576 88 213 576 minecraft:cobbled_deepslate
setblock 88 210 580 minecraft:calcite
fill 88 210 581 88 211 581 minecraft:cobbled_deepslate
setblock 88 210 585 minecraft:calcite
fill 88 210 586 88 213 586 minecraft:cobbled_deepslate
fill 88 210 588 88 210 589 minecraft:cobbled_deepslate
setblock 88 210 590 minecraft:calcite
fill 88 210 591 88 211 593 minecraft:cobbled_deepslate
setblock 48 211 559 minecraft:calcite
fill 48 211 560 48 214 560 minecraft:cobbled_deepslate
setblock 48 211 564 minecraft:calcite
fill 48 211 565 48 214 565 minecraft:cobbled_deepslate
setblock 48 211 569 minecraft:calcite
fill 48 211 570 48 214 570 minecraft:cobbled_deepslate
setblock 48 211 574 minecraft:calcite
fill 48 211 575 48 214 575 minecraft:cobbled_deepslate
setblock 48 211 584 minecraft:calcite
fill 48 211 585 48 211 588 minecraft:cobbled_deepslate
setblock 48 211 589 minecraft:calcite
fill 48 211 590 48 211 593 minecraft:cobbled_deepslate
setblock 48 211 594 minecraft:calcite
fill 48 211 595 48 214 595 minecraft:cobbled_deepslate
setblock 49 211 558 minecraft:calcite
fill 49 211 559 49 214 559 minecraft:cobbled_deepslate
setblock 49 211 563 minecraft:calcite
fill 49 211 564 49 214 564 minecraft:cobbled_deepslate
setblock 49 211 568 minecraft:calcite
fill 49 211 569 49 214 569 minecraft:cobbled_deepslate
setblock 49 211 573 minecraft:calcite
fill 49 211 586 49 211 587 minecraft:cobbled_deepslate
setblock 49 211 588 minecraft:calcite
fill 49 211 589 49 214 589 minecraft:cobbled_deepslate
setblock 49 211 593 minecraft:calcite
fill 49 211 594 50 213 594 minecraft:cobbled_deepslate
fill 49 211 596 49 211 597 minecraft:cobbled_deepslate
setblock 49 211 598 minecraft:calcite
fill 50 211 558 50 214 558 minecraft:cobbled_deepslate
setblock 50 211 562 minecraft:calcite
fill 50 211 563 50 213 563 minecraft:cobbled_deepslate
setblock 50 211 566 minecraft:cobbled_deepslate
setblock 50 211 567 minecraft:calcite
fill 50 211 568 50 214 568 minecraft:cobbled_deepslate
fill 50 211 588 50 213 588 minecraft:cobbled_deepslate
setblock 50 211 591 minecraft:cobbled_deepslate
setblock 50 211 592 minecraft:calcite
fill 50 211 593 50 214 593 minecraft:cobbled_deepslate
fill 50 211 595 50 212 595 minecraft:cobbled_deepslate
setblock 50 211 597 minecraft:calcite
fill 50 211 598 50 214 598 minecraft:cobbled_deepslate
setblock 51 211 566 minecraft:calcite
fill 51 211 567 51 212 567 minecraft:cobbled_deepslate
setblock 51 211 569 minecraft:cobbled_deepslate
setblock 51 211 596 minecraft:calcite
fill 51 211 597 51 214 597 minecraft:cobbled_deepslate
setblock 52 211 560 minecraft:calcite
fill 52 211 596 52 214 596 minecraft:cobbled_deepslate
setblock 53 211 559 minecraft:calcite
setblock 53 211 560 minecraft:cobbled_deepslate
setblock 54 211 558 minecraft:calcite
fill 54 211 559 54 213 559 minecraft:cobbled_deepslate
setblock 54 211 598 minecraft:calcite
fill 55 211 558 55 214 558 minecraft:cobbled_deepslate
setblock 55 211 597 minecraft:calcite
fill 55 211 598 55 214 598 minecraft:cobbled_deepslate
setblock 56 211 596 minecraft:calcite
fill 56 211 597 56 214 597 minecraft:cobbled_deepslate
setblock 59 211 598 minecraft:calcite
fill 60 211 595 60 219 595 minecraft:deepslate
fill 60 211 598 60 214 598 minecraft:cobbled_deepslate
fill 65 211 598 66 213 598 minecraft:cobbled_deepslate
setblock 69 211 597 minecraft:cobbled_deepslate
setblock 69 211 598 minecraft:calcite
setblock 70 211 597 minecraft:calcite
fill 70 211 598 70 214 598 minecraft:cobbled_deepslate
fill 71 211 597 71 214 597 minecraft:cobbled_deepslate
setblock 74 211 558 minecraft:calcite
setblock 74 211 597 minecraft:cobbled_deepslate
setblock 74 211 598 minecraft:calcite
fill 75 211 598 75 212 598 minecraft:cobbled_deepslate
setblock 86 211 565 minecraft:cobbled_deepslate
setblock 86 211 566 minecraft:calcite
fill 86 211 567 86 214 567 minecraft:cobbled_deepslate
setblock 86 211 571 minecraft:calcite
setblock 87 211 561 minecraft:cobbled_deepslate
setblock 87 211 565 minecraft:calcite
fill 87 211 566 87 214 566 minecraft:cobbled_deepslate
setblock 87 211 569 minecraft:cobbled_deepslate
setblock 87 211 570 minecraft:calcite
fill 87 211 571 87 214 571 minecraft:cobbled_deepslate
setblock 88 211 559 minecraft:calcite
fill 88 211 560 88 214 560 minecraft:cobbled_deepslate
setblock 88 211 564 minecraft:calcite
fill 88 211 565 88 214 565 minecraft:cobbled_deepslate
setblock 88 211 569 minecraft:calcite
fill 88 211 570 88 214 570 minecraft:cobbled_deepslate
setblock 88 211 573 minecraft:cobbled_deepslate
setblock 88 211 574 minecraft:calcite
fill 88 211 575 88 214 575 minecraft:cobbled_deepslate
fill 88 211 577 88 211 578 minecraft:cobbled_deepslate
setblock 88 211 579 minecraft:calcite
setblock 88 211 580 minecraft:cobbled_deepslate
setblock 88 211 584 minecraft:calcite
fill 88 211 585 88 213 585 minecraft:cobbled_deepslate
setblock 88 211 588 minecraft:cobbled_deepslate
setblock 88 211 589 minecraft:calcite
fill 88 211 590 88 214 590 minecraft:cobbled_deepslate
setblock 88 211 594 minecraft:calcite
fill 88 211 595 88 214 595 minecraft:cobbled_deepslate
setblock 48 212 558 minecraft:calcite
fill 48 212 559 48 215 559 minecraft:cobbled_deepslate
setblock 48 212 563 minecraft:calcite
fill 48 212 564 48 215 564 minecraft:cobbled_deepslate
setblock 48 212 568 minecraft:calcite
fill 48 212 569 48 215 569 minecraft:cobbled_deepslate
setblock 48 212 572 minecraft:cobbled_deepslate
setblock 48 212 573 minecraft:calcite
fill 48 212 574 49 214 574 minecraft:cobbled_deepslate
fill 48 212 576 48 213 576 minecraft:cobbled_deepslate
fill 48 212 584 48 212 587 minecraft:cobbled_deepslate
setblock 48 212 588 minecraft:calcite
fill 48 212 589 48 212 592 minecraft:cobbled_deepslate
setblock 48 212 593 minecraft:calcite
fill 48 212 594 48 215 594 minecraft:cobbled_deepslate
fill 48 212 596 48 212 597 minecraft:cobbled_deepslate
setblock 48 212 598 minecraft:calcite
fill 49 212 558 49 215 558 minecraft:cobbled_deepslate
setblock 49 212 562 minecraft:calcite
fill 49 212 563 49 215 563 minecraft:cobbled_deepslate
setblock 49 212 567 minecraft:calcite
fill 49 212 568 49 215 568 minecraft:cobbled_deepslate
setblock 49 212 571 minecraft:cobbled_deepslate
setblock 49 212 572 minecraft:calcite
fill 49 212 573 49 215 573 minecraft:cobbled_deepslate
setblock 49 212 586 minecraft:cobbled_deepslate
setblock 49 212 587 minecraft:calcite
fill 49 212 588 49 215 588 minecraft:cobbled_deepslate
setblock 49 212 591 minecraft:cobbled_deepslate
setblock 49 212 592 minecraft:calcite
fill 49 212 593 49 215 593 minecraft:cobbled_deepslate
setblock 49 212 596 minecraft:cobbled_deepslate
setblock 49 212 597 minecraft:calcite
fill 49 212 598 49 215 598 minecraft:cobbled_deepslate
setblock 50 212 561 minecraft:calcite
fill 50 212 562 50 213 562 minecraft:cobbled_deepslate
setblock 50 212 566 minecraft:calcite
fill 50 212 567 50 214 567 minecraft:cobbled_deepslate
setblock 50 212 571 minecraft:calcite
setblock 50 212 591 minecraft:calcite
fill 50 212 592 51 214 592 minecraft:cobbled_deepslate
setblock 50 212 596 minecraft:calcite
fill 50 212 597 50 215 597 minecraft:cobbled_deepslate
setblock 51 212 560 minecraft:calcite
setblock 51 212 565 minecraft:calcite
setblock 51 212 566 minecraft:cobbled_deepslate
fill 51 212 591 51 213 591 minecraft:cobbled_deepslate
fill 51 212 596 51 215 596 minecraft:cobbled_deepslate
setblock 52 212 559 minecraft:calcite
setblock 52 212 560 minecraft:cobbled_deepslate
setblock 53 212 558 minecraft:calcite
fill 53 212 559 53 214 559 minecraft:cobbled_deepslate
setblock 53 212 598 minecraft:calcite
fill 54 212 558 54 215 558 minecraft:cobbled_deepslate
setblock 54 212 596 minecraft:cobbled_deepslate
setblock 54 212 597 minecraft:calcite
fill 54 212 598 54 215 598 minecraft:cobbled_deepslate
setblock 55 212 596 minecraft:calcite
fill 55 212 597 55 215 597 minecraft:cobbled_deepslate
fill 56 212 596 56 213 596 minecraft:cobbled_deepslate
setblock 58 212 597 minecraft:cobbled_deepslate
setblock 58 212 598 minecraft:calcite
fill 59 212 598 59 215 598 minecraft:cobbled_deepslate
fill 64 212 598 64 215 598 minecraft:cobbled_deepslate
setblock 68 212 597 minecraft:cobbled_deepslate
setblock 68 212 598 minecraft:calcite
setblock 69 212 597 minecraft:calcite
fill 69 212 598 69 215 598 minecraft:cobbled_deepslate
fill 70 212 597 70 215 597 minecraft:cobbled_deepslate
setblock 73 212 598 minecraft:calcite
fill 74 212 598 74 214 598 minecraft:cobbled_deepslate
setblock 86 212 565 minecraft:calcite
fill 86 212 566 86 214 566 minecraft:cobbled_deepslate
fill 86 212 568 86 212 569 minecraft:cobbled_deepslate
setblock 86 212 570 minecraft:calcite
fill 86 212 571 86 214 572 minecraft:cobbled_deepslate
setblock 87 212 558 minecraft:cobbled_deepslate
setblock 87 212 564 minecraft:calcite
fill 87 212 565 87 215 565 minecraft:cobbled_deepslate
setblock 87 212 569 minecraft:calcite
fill 87 212 570 87 215 570 minecraft:cobbled_deepslate
fill 87 212 572 87 212 573 minecraft:cobbled_deepslate
setblock 87 212 574 minecraft:calcite
fill 87 212 575 87 215 575 minecraft:cobbled_deepslate
setblock 88 212 558 minecraft:calcite
fill 88 212 559 88 215 559 minecraft:cobbled_deepslate
setblock 88 212 563 minecraft:calcite
fill 88 212 564 88 215 564 minecraft:cobbled_deepslate
setblock 88 212 568 minecraft:calcite
fill 88 212 569 88 215 569 minecraft:cobbled_deepslate
setblock 88 212 573 minecraft:calcite
fill 88 212 574 88 215 574 minecraft:cobbled_deepslate
setblock 88 212 577 minecraft:cobbled_deepslate
setblock 88 212 578 minecraft:calcite
fill 88 212 579 88 213 579 minecraft:cobbled_deepslate
setblock 88 212 583 minecraft:calcite
fill 88 212 584 88 213 584 minecraft:cobbled_deepslate
setblock 88 212 588 minecraft:calcite
fill 88 212 589 88 215 589 minecraft:cobbled_deepslate
fill 88 212 591 88 212 592 minecraft:cobbled_deepslate
setblock 88 212 593 minecraft:calcite
fill 88 212 594 88 215 594 minecraft:cobbled_deepslate
fill 88 212 596 88 213 596 minecraft:cobbled_deepslate
fill 48 213 558 48 216 558 minecraft:cobbled_deepslate
setblock 48 213 562 minecraft:calcite
fill 48 213 563 48 216 563 minecraft:cobbled_deepslate
setblock 48 213 567 minecraft:calcite
fill 48 213 568 48 216 568 minecraft:cobbled_deepslate
setblock 48 213 572 minecraft:calcite
fill 48 213 573 48 216 573 minecraft:cobbled_deepslate
fill 48 213 585 48 213 586 minecraft:cobbled_deepslate
setblock 48 213 587 minecraft:calcite
fill 48 213 588 48 213 591 minecraft:cobbled_deepslate
setblock 48 213 592 minecraft:calcite
fill 48 213 593 48 216 593 minecraft:cobbled_deepslate
setblock 48 213 596 minecraft:cobbled_deepslate
setblock 48 213 597 minecraft:calcite
fill 48 213 598 48 216 598 minecraft:cobbled_deepslate
setblock 49 213 561 minecraft:calcite
fill 49 213 562 49 215 562 minecraft:cobbled_deepslate
setblock 49 213 566 minecraft:calcite
fill 49 213 567 49 216 567 minecraft:cobbled_deepslate
setblock 49 213 571 minecraft:calcite
fill 49 213 572 49 216 572 minecraft:cobbled_deepslate
fill 49 213 587 49 214 587 minecraft:cobbled_deepslate
setblock 49 213 590 minecraft:cobbled_deepslate
setblock 49 213 591 minecraft:calcite
fill 49 213 592 49 216 592 minecraft:cobbled_deepslate
setblock 49 213 596 minecraft:calcite
fill 49 213 597 49 216 597 minecraft:cobbled_deepslate
setblock 50 213 565 minecraft:calcite
fill 50 213 566 50 214 566 minecraft:cobbled_deepslate
setblock 50 213 570 minecraft:calcite
fill 50 213 571 50 214 571 minecraft:cobbled_deepslate
setblock 50 213 590 minecraft:calcite
fill 50 213 591 50 216 591 minecraft:cobbled_deepslate
setblock 50 213 595 minecraft:calcite
fill 50 213 596 50 216 596 minecraft:cobbled_deepslate
setblock 51 213 559 minecraft:calcite
setblock 51 213 593 minecraft:cobbled_deepslate
setblock 52 213 558 minecraft:calcite
fill 52 213 559 52 214 559 minecraft:cobbled_deepslate
setblock 52 213 598 minecraft:calcite
fill 53 213 558 53 216 558 minecraft:cobbled_deepslate
setblock 53 213 597 minecraft:calcite
fill 53 213 598 53 216 598 minecraft:cobbled_deepslate
setblock 54 213 596 minecraft:calcite
fill 54 213 597 54 216 597 minecraft:cobbled_deepslate
fill 55 213 596 55 215 596 minecraft:cobbled_deepslate
setblock 57 213 598 minecraft:calcite
setblock 58 213 597 minecraft:calcite
fill 58 213 598 58 216 598 minecraft:cobbled_deepslate
setblock 67 213 597 minecraft:cobbled_deepslate
setblock 67 213 598 minecraft:calcite
setblock 68 213 597 minecraft:calcite
fill 68 213 598 68 216 598 minecraft:cobbled_deepslate
fill 69 213 597 69 216 597 minecraft:cobbled_deepslate
setblock 72 213 597 minecraft:cobbled_deepslate
setblock 72 213 598 minecraft:calcite
setblock 73 213 597 minecraft:calcite
fill 73 213 598 73 216 598 minecraft:cobbled_deepslate
setblock 86 213 568 minecraft:cobbled_deepslate
setblock 86 213 569 minecraft:calcite
fill 86 213 570 86 216 570 minecraft:cobbled_deepslate
setblock 87 213 558 minecraft:calcite
setblock 87 213 563 minecraft:calcite
fill 87 213 564 87 216 564 minecraft:cobbled_deepslate
setblock 87 213 568 minecraft:calcite
fill 87 213 569 87 216 569 minecraft:cobbled_deepslate
setblock 87 213 572 minecraft:cobbled_deepslate
setblock 87 213 573 minecraft:calcite
fill 87 213 574 87 216 574 minecraft:cobbled_deepslate
fill 88 213 558 88 216 558 minecraft:cobbled_deepslate
setblock 88 213 562 minecraft:calcite
fill 88 213 563 88 216 563 minecraft:cobbled_deepslate
setblock 88 213 567 minecraft:calcite
fill 88 213 568 88 216 568 minecraft:cobbled_deepslate
setblock 88 213 572 minecraft:calcite
fill 88 213 573 88 216 573 minecraft:cobbled_deepslate
setblock 88 213 577 minecraft:calcite
fill 88 213 578 88 216 578 minecraft:cobbled_deepslate
setblock 88 213 587 minecraft:calcite
fill 88 213 588 88 216 588 minecraft:cobbled_deepslate
setblock 88 213 591 minecraft:cobbled_deepslate
setblock 88 213 592 minecraft:calcite
fill 88 213 593 88 216 593 minecraft:cobbled_deepslate
setblock 88 213 597 minecraft:calcite
fill 88 213 598 88 216 598 minecraft:cobbled_deepslate
setblock 48 214 561 minecraft:calcite
fill 48 214 562 48 217 562 minecraft:cobbled_deepslate
setblock 48 214 566 minecraft:calcite
fill 48 214 567 48 217 567 minecraft:cobbled_deepslate
setblock 48 214 571 minecraft:calcite
fill 48 214 572 48 217 572 minecraft:cobbled_deepslate
setblock 48 214 576 minecraft:calcite
setblock 48 214 585 minecraft:cobbled_deepslate
setblock 48 214 586 minecraft:calcite
fill 48 214 587 48 214 590 minecraft:cobbled_deepslate
setblock 48 214 591 minecraft:calcite
fill 48 214 592 48 217 592 minecraft:cobbled_deepslate
setblock 48 214 596 minecraft:calcite
fill 48 214 597 48 217 597 minecraft:cobbled_deepslate
setblock 49 214 560 minecraft:calcite
fill 49 214 561 49 215 561 minecraft:cobbled_deepslate
setblock 49 214 565 minecraft:calcite
fill 49 214 566 49 217 566 minecraft:cobbled_deepslate
setblock 49 214 570 minecraft:calcite
fill 49 214 571 49 217 571 minecraft:cobbled_deepslate
setblock 49 214 590 minecraft:calcite
fill 49 214 591 49 217 591 minecraft:cobbled_deepslate
setblock 49 214 594 minecraft:cobbled_deepslate
setblock 49 214 595 minecraft:calcite
fill 49 214 596 49 217 596 minecraft:cobbled_deepslate
setblock 50 214 559 minecraft:calcite
setblock 50 214 564 minecraft:calcite
setblock 50 214 565 minecraft:cobbled_deepslate
setblock 50 214 569 minecraft:calcite
fill 50 214 570 50 215 570 minecraft:cobbled_deepslate
setblock 50 214 589 minecraft:calcite
fill 50 214 590 50 216 590 minecraft:cobbled_deepslate
setblock 50 214 594 minecraft:calcite
fill 50 214 595 50 217 595 minecraft:cobbled_deepslate
setblock 51 214 558 minecraft:calcite
fill 51 214 559 51 215 559 minecraft:cobbled_deepslate
setblock 51 214 593 minecraft:calcite
setblock 51 214 594 minecraft:cobbled_deepslate
setblock 51 214 598 minecraft:calcite
fill 52 214 558 52 217 558 minecraft:cobbled_deepslate
setblock 52 214 597 minecraft:calcite
fill 52 214 598 52 217 598 minecraft:cobbled_deepslate
setblock 53 214 596 minecraft:calcite
fill 53 214 597 53 217 597 minecraft:cobbled_deepslate
fill 54 214 596 54 217 596 minecraft:cobbled_deepslate
setblock 56 214 598 minecraft:calcite
setblock 57 214 597 minecraft:calcite
fill 57 214 598 57 217 598 minecraft:cobbled_deepslate
setblock 65 214 598 minecraft:cobbled_deepslate
setblock 66 214 598 minecraft:calcite
setblock 67 214 597 minecraft:calcite
fill 67 214 598 67 217 598 minecraft:cobbled_deepslate
fill 68 214 597 68 217 597 minecraft:cobbled_deepslate
setblock 71 214 598 minecraft:calcite
setblock 72 214 597 minecraft:calcite
fill 72 214 598 72 217 598 minecraft:cobbled_deepslate
setblock 86 214 568 minecraft:calcite
fill 86 214 569 86 217 569 minecraft:cobbled_deepslate
fill 87 214 558 87 217 558 minecraft:cobbled_deepslate
setblock 87 214 562 minecraft:calcite
fill 87 214 563 87 216 563 minecraft:cobbled_deepslate
setblock 87 214 567 minecraft:calcite
fill 87 214 568 87 217 568 minecraft:cobbled_deepslate
setblock 87 214 572 minecraft:calcite
fill 87 214 573 87 217 573 minecraft:cobbled_deepslate
setblock 88 214 561 minecraft:calcite
fill 88 214 562 88 217 562 minecraft:cobbled_deepslate
setblock 88 214 566 minecraft:calcite
fill 88 214 567 88 217 567 minecraft:cobbled_deepslate
setblock 88 214 571 minecraft:calcite
fill 88 214 572 88 217 572 minecraft:cobbled_deepslate
setblock 88 214 576 minecraft:calcite
fill 88 214 577 88 217 577 minecraft:cobbled_deepslate
setblock 88 214 586 minecraft:calcite
fill 88 214 587 88 215 587 minecraft:cobbled_deepslate
setblock 88 214 591 minecraft:calcite
fill 88 214 592 88 217 592 minecraft:cobbled_deepslate
setblock 88 214 596 minecraft:calcite
fill 88 214 597 88 217 597 minecraft:cobbled_deepslate
setblock 48 215 560 minecraft:calcite
fill 48 215 561 48 218 561 minecraft:cobbled_deepslate
setblock 48 215 565 minecraft:calcite
fill 48 215 566 48 218 566 minecraft:cobbled_deepslate
setblock 48 215 570 minecraft:calcite
fill 48 215 571 48 218 571 minecraft:cobbled_deepslate
setblock 48 215 574 minecraft:cobbled_deepslate
setblock 48 215 575 minecraft:calcite
fill 48 215 576 48 218 576 minecraft:cobbled_deepslate
fill 48 215 586 48 215 589 minecraft:cobbled_deepslate
setblock 48 215 590 minecraft:calcite
fill 48 215 591 48 218 591 minecraft:cobbled_deepslate
setblock 48 215 595 minecraft:calcite
fill 48 215 596 48 218 596 minecraft:cobbled_deepslate
setblock 49 215 559 minecraft:calcite
fill 49 215 560 49 216 560 minecraft:cobbled_deepslate
setblock 49 215 564 minecraft:calcite
fill 49 215 565 49 216 565 minecraft:cobbled_deepslate
setblock 49 215 569 minecraft:calcite
fill 49 215 570 49 218 570 minecraft:cobbled_deepslate
setblock 49 215 574 minecraft:calcite
setblock 49 215 589 minecraft:calcite
fill 49 215 590 49 218 590 minecraft:cobbled_deepslate
setblock 49 215 594 minecraft:calcite
fill 49 215 595 49 218 595 minecraft:cobbled_deepslate
setblock 50 215 558 minecraft:calcite
fill 50 215 559 50 218 559 minecraft:cobbled_deepslate
setblock 50 215 568 minecraft:calcite
setblock 50 215 569 minecraft:cobbled_deepslate
setblock 50 215 592 minecraft:cobbled_deepslate
setblock 50 215 593 minecraft:calcite
fill 50 215 594 50 218 594 minecraft:cobbled_deepslate
setblock 50 215 598 minecraft:calcite
fill 51 215 558 51 218 558 minecraft:cobbled_deepslate
setblock 51 215 597 minecraft:calcite
fill 51 215 598 51 218 598 minecraft:cobbled_deepslate
setblock 52 215 596 minecraft:calcite
fill 52 215 597 52 218 597 minecraft:cobbled_deepslate
fill 53 215 596 53 218 596 minecraft:cobbled_deepslate
setblock 55 215 558 minecraft:calcite
setblock 55 215 598 minecraft:calcite
setblock 56 215 597 minecraft:calcite
fill 56 215 598 56 218 598 minecraft:cobbled_deepslate
setblock 57 215 597 minecraft:cobbled_deepslate
setblock 60 215 598 minecraft:calcite
setblock 65 215 598 minecraft:calcite
fill 66 215 598 66 218 598 minecraft:cobbled_deepslate
fill 67 215 597 67 218 597 minecraft:cobbled_deepslate
setblock 70 215 598 minecraft:calcite
setblock 71 215 597 minecraft:calcite
fill 71 215 598 71 218 598 minecraft:cobbled_deepslate
setblock 86 215 567 minecraft:calcite
fill 86 215 568 86 217 568 minecraft:cobbled_deepslate
setblock 86 215 571 minecraft:cobbled_deepslate
setblock 86 215 572 minecraft:calcite
fill 86 215 573 86 218 573 minecraft:cobbled_deepslate
setblock 87 215 566 minecraft:calcite
fill 87 215 567 87 218 567 minecraft:cobbled_deepslate
setblock 87 215 571 minecraft:calcite
fill 87 215 572 87 218 572 minecraft:cobbled_deepslate
setblock 87 215 576 minecraft:calcite
fill 87 215 598 87 217 598 minecraft:cobbled_deepslate
setblock 88 215 560 minecraft:calcite
fill 88 215 561 88 218 561 minecraft:cobbled_deepslate
setblock 88 215 565 minecraft:calcite
fill 88 215 566 88 218 566 minecraft:cobbled_deepslate
setblock 88 215 570 minecraft:calcite
fill 88 215 571 88 218 571 minecraft:cobbled_deepslate
setblock 88 215 575 minecraft:calcite
fill 88 215 576 88 218 576 minecraft:cobbled_deepslate
setblock 88 215 590 minecraft:calcite
fill 88 215 591 88 218 591 minecraft:cobbled_deepslate
setblock 88 215 595 minecraft:calcite
fill 88 215 596 88 218 596 minecraft:cobbled_deepslate
setblock 48 216 559 minecraft:calcite
fill 48 216 560 48 219 560 minecraft:cobbled_deepslate
setblock 48 216 564 minecraft:calcite
fill 48 216 565 48 219 565 minecraft:cobbled_deepslate
setblock 48 216 569 minecraft:calcite
fill 48 216 570 48 219 570 minecraft:cobbled_deepslate
setblock 48 216 574 minecraft:calcite
fill 48 216 575 48 219 575 minecraft:cobbled_deepslate
fill 48 216 587 48 216 588 minecraft:cobbled_deepslate
setblock 48 216 589 minecraft:calcite
fill 48 216 590 48 219 590 minecraft:cobbled_deepslate
setblock 48 216 594 minecraft:calcite
fill 48 216 595 48 219 595 minecraft:cobbled_deepslate
setblock 49 216 558 minecraft:calcite
fill 49 216 559 49 219 559 minecraft:cobbled_deepslate
setblock 49 216 564 minecraft:cobbled_deepslate
setblock 49 216 568 minecraft:calcite
fill 49 216 569 49 218 569 minecraft:cobbled_deepslate
setblock 49 216 573 minecraft:calcite
fill 49 216 574 49 219 574 minecraft:cobbled_deepslate
setblock 49 216 588 minecraft:calcite
fill 49 216 589 49 219 589 minecraft:cobbled_deepslate
setblock 49 216 593 minecraft:calcite
fill 49 216 594 49 219 594 minecraft:cobbled_deepslate
setblock 49 216 598 minecraft:calcite
fill 50 216 558 50 219 558 minecraft:cobbled_deepslate
setblock 50 216 560 minecraft:light[level=14]
setblock 50 216 568 minecraft:light[level=14]
setblock 50 216 576 minecraft:light[level=14]
setblock 50 216 584 minecraft:light[level=14]
setblock 50 216 592 minecraft:calcite
fill 50 216 593 50 219 593 minecraft:cobbled_deepslate
setblock 50 216 597 minecraft:calcite
fill 50 216 598 50 219 598 minecraft:cobbled_deepslate
setblock 51 216 596 minecraft:calcite
fill 51 216 597 51 219 597 minecraft:cobbled_deepslate
fill 52 216 596 52 219 596 minecraft:cobbled_deepslate
setblock 54 216 558 minecraft:calcite
setblock 54 216 598 minecraft:calcite
setblock 55 216 597 minecraft:calcite
fill 55 216 598 55 219 598 minecraft:cobbled_deepslate
fill 56 216 597 56 219 597 minecraft:cobbled_deepslate
setblock 58 216 560 minecraft:light[level=14]
setblock 58 216 568 minecraft:light[level=14]
setblock 58 216 576 minecraft:light[level=14]
setblock 58 216 584 minecraft:light[level=14]
setblock 58 216 592 minecraft:light[level=14]
setblock 59 216 598 minecraft:calcite
setblock 63 216 598 minecraft:cobbled_deepslate
setblock 64 216 598 minecraft:calcite
fill 65 216 598 65 219 598 minecraft:cobbled_deepslate
setblock 66 216 560 minecraft:light[level=14]
setblock 66 216 568 minecraft:light[level=14]
setblock 66 216 576 minecraft:light[level=14]
setblock 66 216 584 minecraft:light[level=14]
setblock 66 216 592 minecraft:light[level=14]
fill 66 216 597 66 219 597 minecraft:cobbled_deepslate
setblock 69 216 598 minecraft:calcite
setblock 70 216 597 minecraft:calcite
fill 70 216 598 70 219 598 minecraft:cobbled_deepslate
fill 71 216 597 71 219 597 minecraft:cobbled_deepslate
setblock 74 216 560 minecraft:light[level=14]
setblock 74 216 568 minecraft:light[level=14]
setblock 74 216 576 minecraft:light[level=14]
setblock 74 216 584 minecraft:light[level=14]
setblock 74 216 592 minecraft:light[level=14]
setblock 82 216 560 minecraft:light[level=14]
setblock 82 216 568 minecraft:light[level=14]
setblock 82 216 576 minecraft:light[level=14]
setblock 82 216 584 minecraft:light[level=14]
setblock 82 216 592 minecraft:light[level=14]
fill 86 216 558 86 218 558 minecraft:cobbled_deepslate
setblock 86 216 571 minecraft:calcite
fill 86 216 572 86 219 572 minecraft:cobbled_deepslate
setblock 87 216 565 minecraft:calcite
fill 87 216 566 87 219 566 minecraft:cobbled_deepslate
setblock 87 216 570 minecraft:calcite
fill 87 216 571 87 219 571 minecraft:cobbled_deepslate
setblock 87 216 575 minecraft:calcite
fill 87 216 576 87 219 576 minecraft:cobbled_deepslate
setblock 88 216 559 minecraft:calcite
fill 88 216 560 88 219 560 minecraft:cobbled_deepslate
setblock 88 216 564 minecraft:calcite
fill 88 216 565 88 219 565 minecraft:cobbled_deepslate
setblock 88 216 569 minecraft:calcite
fill 88 216 570 88 219 570 minecraft:cobbled_deepslate
setblock 88 216 574 minecraft:calcite
fill 88 216 575 88 219 575 minecraft:cobbled_deepslate
setblock 88 216 589 minecraft:calcite
fill 88 216 590 88 219 590 minecraft:cobbled_deepslate
setblock 88 216 594 minecraft:calcite
fill 88 216 595 88 219 595 minecraft:cobbled_deepslate
setblock 48 217 558 minecraft:calcite
fill 48 217 559 48 220 559 minecraft:cobbled_deepslate
setblock 48 217 563 minecraft:calcite
fill 48 217 564 48 220 564 minecraft:cobbled_deepslate
setblock 48 217 568 minecraft:calcite
fill 48 217 569 48 220 569 minecraft:cobbled_deepslate
setblock 48 217 573 minecraft:calcite
fill 48 217 574 48 220 574 minecraft:cobbled_deepslate
setblock 48 217 577 minecraft:cobbled_deepslate
setblock 48 217 587 minecraft:cobbled_deepslate
setblock 48 217 588 minecraft:calcite
fill 48 217 589 48 220 589 minecraft:cobbled_deepslate
setblock 48 217 593 minecraft:calcite
fill 48 217 594 48 220 594 minecraft:cobbled_deepslate
setblock 48 217 598 minecraft:calcite
fill 49 217 558 49 220 558 minecraft:cobbled_deepslate
setblock 49 217 567 minecraft:calcite
fill 49 217 568 49 218 568 minecraft:cobbled_deepslate
setblock 49 217 572 minecraft:calcite
fill 49 217 573 49 220 573 minecraft:cobbled_deepslate
setblock 49 217 592 minecraft:calcite
fill 49 217 593 49 220 593 minecraft:cobbled_deepslate
setblock 49 217 597 minecraft:calcite
fill 49 217 598 49 220 598 minecraft:cobbled_deepslate
setblock 50 217 591 minecraft:calcite
fill 50 217 592 50 220 592 minecraft:cobbled_deepslate
setblock 50 217 596 minecraft:calcite
fill 50 217 597 50 220 597 minecraft:cobbled_deepslate
fill 51 217 596 51 220 596 minecraft:cobbled_deepslate
setblock 53 217 558 minecraft:calcite
setblock 53 217 598 minecraft:calcite
setblock 54 217 597 minecraft:calcite
fill 54 217 598 54 220 598 minecraft:cobbled_deepslate
fill 55 217 597 55 220 597 minecraft:cobbled_deepslate
setblock 58 217 598 minecraft:calcite
fill 59 217 598 62 217 598 minecraft:cobbled_deepslate
setblock 63 217 598 minecraft:calcite
fill 64 217 598 64 220 598 minecraft:cobbled_deepslate
fill 65 217 597 65 220 597 minecraft:cobbled_deepslate
setblock 68 217 598 minecraft:calcite
setblock 69 217 597 minecraft:calcite
fill 69 217 598 69 220 598 minecraft:cobbled_deepslate
fill 70 217 597 70 220 597 minecraft:cobbled_deepslate
setblock 86 217 570 minecraft:calcite
fill 86 217 571 86 220 571 minecraft:cobbled_deepslate
fill 86 217 598 86 218 598 minecraft:cobbled_deepslate
setblock 87 217 564 minecraft:calcite
fill 87 217 565 87 220 565 minecraft:cobbled_deepslate
setblock 87 217 569 minecraft:calcite
fill 87 217 570 87 220 570 minecraft:cobbled_deepslate
setblock 87 217 574 minecraft:calcite
fill 87 217 575 87 220 575 minecraft:cobbled_deepslate
setblock 87 217 594 minecraft:calcite
fill 87 217 595 87 219 596 minecraft:cobbled_deepslate
setblock 88 217 558 minecraft:calcite
fill 88 217 559 88 220 559 minecraft:cobbled_deepslate
setblock 88 217 563 minecraft:calcite
fill 88 217 564 88 220 564 minecraft:cobbled_deepslate
setblock 88 217 568 minecraft:calcite
fill 88 217 569 88 220 569 minecraft:cobbled_deepslate
setblock 88 217 573 minecraft:calcite
fill 88 217 574 88 220 574 minecraft:cobbled_deepslate
setblock 88 217 578 minecraft:calcite
fill 88 217 579 88 220 579 minecraft:cobbled_deepslate
fill 88 217 589 88 218 589 minecraft:cobbled_deepslate
setblock 88 217 593 minecraft:calcite
fill 88 217 594 88 220 594 minecraft:cobbled_deepslate
setblock 88 217 598 minecraft:calcite
fill 48 218 558 48 220 558 minecraft:cobbled_deepslate
setblock 48 218 562 minecraft:calcite
fill 48 218 563 48 220 563 minecraft:cobbled_deepslate
setblock 48 218 567 minecraft:calcite
fill 48 218 568 48 220 568 minecraft:cobbled_deepslate
setblock 48 218 572 minecraft:calcite
fill 48 218 573 48 220 573 minecraft:cobbled_deepslate
setblock 48 218 577 minecraft:calcite
fill 48 218 578 48 220 578 minecraft:cobbled_deepslate
setblock 48 218 587 minecraft:calcite
fill 48 218 588 48 220 588 minecraft:cobbled_deepslate
setblock 48 218 592 minecraft:calcite
fill 48 218 593 48 220 593 minecraft:cobbled_deepslate
setblock 48 218 597 minecraft:calcite
fill 48 218 598 48 220 598 minecraft:cobbled_deepslate
setblock 49 218 571 minecraft:calcite
fill 49 218 572 49 220 572 minecraft:cobbled_deepslate
setblock 49 218 591 minecraft:calcite
fill 49 218 592 49 220 592 minecraft:cobbled_deepslate
setblock 49 218 596 minecraft:calcite
fill 49 218 597 49 220 597 minecraft:cobbled_deepslate
setblock 50 218 591 minecraft:cobbled_deepslate
setblock 50 218 595 minecraft:calcite
fill 50 218 596 50 220 596 minecraft:cobbled_deepslate
setblock 52 218 558 minecraft:calcite
setblock 52 218 598 minecraft:calcite
fill 53 218 558 53 220 558 minecraft:cobbled_deepslate
setblock 53 218 597 minecraft:calcite
fill 53 218 598 53 220 598 minecraft:cobbled_deepslate
setblock 54 218 596 minecraft:calcite
fill 54 218 597 54 220 597 minecraft:cobbled_deepslate
setblock 57 218 598 minecraft:calcite
fill 58 218 598 61 218 598 minecraft:cobbled_deepslate
fill 59 218 595 59 219 595 minecraft:deepslate
fill 60 218 594 60 219 594 minecraft:deepslate
fill 60 218 596 60 219 596 minecraft:deepslate
fill 61 218 595 61 219 595 minecraft:deepslate
setblock 62 218 598 minecraft:calcite
fill 63 218 598 63 220 598 minecraft:cobbled_deepslate
fill 64 218 597 64 220 597 minecraft:cobbled_deepslate
setblock 67 218 598 minecraft:calcite
setblock 68 218 597 minecraft:calcite
fill 68 218 598 68 220 598 minecraft:cobbled_deepslate
fill 69 218 597 69 220 597 minecraft:cobbled_deepslate
setblock 72 218 598 minecraft:calcite
fill 85 218 558 85 219 558 minecraft:cobbled_deepslate
fill 85 218 598 85 219 598 minecraft:cobbled_deepslate
setblock 86 218 569 minecraft:calcite
fill 86 218 570 86 220 570 minecraft:cobbled_deepslate
setblock 86 218 574 minecraft:calcite
setblock 87 218 558 minecraft:calcite
fill 87 218 559 87 220 559 minecraft:cobbled_deepslate
fill 87 218 564 87 220 564 minecraft:cobbled_deepslate
setblock 87 218 568 minecraft:calcite
fill 87 218 569 87 220 569 minecraft:cobbled_deepslate
setblock 87 218 573 minecraft:calcite
fill 87 218 574 87 220 574 minecraft:cobbled_deepslate
setblock 87 218 577 minecraft:cobbled_deepslate
setblock 87 218 593 minecraft:calcite
fill 87 218 594 87 220 594 minecraft:cobbled_deepslate
setblock 87 218 597 minecraft:cobbled_deepslate
setblock 87 218 598 minecraft:calcite
fill 88 218 558 88 220 558 minecraft:cobbled_deepslate
setblock 88 218 562 minecraft:calcite
fill 88 218 563 88 220 563 minecraft:cobbled_deepslate
setblock 88 218 567 minecraft:calcite
fill 88 218 568 88 220 568 minecraft:cobbled_deepslate
setblock 88 218 572 minecraft:calcite
fill 88 218 573 88 220 573 minecraft:cobbled_deepslate
setblock 88 218 577 minecraft:calcite
fill 88 218 578 88 220 578 minecraft:cobbled_deepslate
setblock 88 218 592 minecraft:calcite
fill 88 218 593 88 220 593 minecraft:cobbled_deepslate
setblock 88 218 597 minecraft:calcite
fill 88 218 598 88 220 598 minecraft:cobbled_deepslate
setblock 48 219 561 minecraft:calcite
fill 48 219 562 48 220 562 minecraft:cobbled_deepslate
setblock 48 219 566 minecraft:calcite
fill 48 219 567 48 220 567 minecraft:cobbled_deepslate
setblock 48 219 571 minecraft:calcite
fill 48 219 572 48 220 572 minecraft:cobbled_deepslate
setblock 48 219 576 minecraft:calcite
fill 48 219 577 48 220 577 minecraft:cobbled_deepslate
fill 48 219 579 48 220 579 minecraft:cobbled_deepslate
fill 48 219 587 48 220 587 minecraft:cobbled_deepslate
setblock 48 219 591 minecraft:calcite
fill 48 219 592 48 220 592 minecraft:cobbled_deepslate
setblock 48 219 596 minecraft:calcite
fill 48 219 597 48 220 597 minecraft:cobbled_deepslate
setblock 49 219 560 minecraft:calcite
setblock 49 219 570 minecraft:calcite
fill 49 219 571 49 220 571 minecraft:cobbled_deepslate
setblock 49 219 575 minecraft:calcite
setblock 49 219 590 minecraft:calcite
fill 49 219 591 49 220 591 minecraft:cobbled_deepslate
setblock 49 219 595 minecraft:calcite
fill 49 219 596 49 220 596 minecraft:cobbled_deepslate
setblock 50 219 559 minecraft:calcite
setblock 50 219 594 minecraft:calcite
fill 50 219 595 50 220 595 minecraft:cobbled_deepslate
setblock 51 219 558 minecraft:calcite
setblock 51 219 598 minecraft:calcite
fill 52 219 558 52 220 558 minecraft:cobbled_deepslate
setblock 52 219 597 minecraft:calcite
fill 52 219 598 52 220 598 minecraft:cobbled_deepslate
setblock 53 219 596 minecraft:calcite
fill 53 219 597 53 220 597 minecraft:cobbled_deepslate
fill 54 219 596 54 220 596 minecraft:cobbled_deepslate
setblock 56 219 598 minecraft:calcite
fill 57 219 598 60 219 598 minecraft:cobbled_deepslate
setblock 61 219 598 minecraft:calcite
setblock 62 219 597 minecraft:calcite
fill 62 219 598 62 220 598 minecraft:cobbled_deepslate
fill 63 219 597 63 220 597 minecraft:cobbled_deepslate
fill 66 219 596 67 219 596 minecraft:cobbled_deepslate
setblock 66 219 598 minecraft:calcite
setblock 67 219 597 minecraft:calcite
fill 67 219 598 67 220 598 minecraft:cobbled_deepslate
setblock 68 219 596 minecraft:calcite
fill 68 219 597 68 220 597 minecraft:cobbled_deepslate
setblock 71 219 598 minecraft:calcite
fill 72 219 598 73 220 598 minecraft:cobbled_deepslate
fill 83 219 558 84 220 558 minecraft:cobbled_deepslate
fill 84 219 598 84 220 598 minecraft:cobbled_deepslate
setblock 86 219 558 minecraft:calcite
fill 86 219 559 86 220 559 minecraft:cobbled_deepslate
fill 86 219 569 86 220 569 minecraft:cobbled_deepslate
setblock 86 219 573 minecraft:calcite
fill 86 219 574 86 220 575 minecraft:cobbled_deepslate
setblock 86 219 597 minecraft:cobbled_deepslate
setblock 86 219 598 minecraft:calcite
fill 87 219 558 87 220 558 minecraft:cobbled_deepslate
fill 87 219 560 87 219 561 minecraft:cobbled_deepslate
setblock 87 219 562 minecraft:calcite
fill 87 219 563 87 220 563 minecraft:cobbled_deepslate
setblock 87 219 567 minecraft:calcite
fill 87 219 568 87 220 568 minecraft:cobbled_deepslate
setblock 87 219 572 minecraft:calcite
fill 87 219 573 87 220 573 minecraft:cobbled_deepslate
setblock 87 219 577 minecraft:calcite
fill 87 219 593 87 220 593 minecraft:cobbled_deepslate
setblock 87 219 597 minecraft:calcite
fill 87 219 598 87 220 598 minecraft:cobbled_deepslate
setblock 88 219 561 minecraft:calcite
fill 88 219 562 88 220 562 minecraft:cobbled_deepslate
setblock 88 219 566 minecraft:calcite
fill 88 219 567 88 220 567 minecraft:cobbled_deepslate
setblock 88 219 571 minecraft:calcite
fill 88 219 572 88 220 572 minecraft:cobbled_deepslate
setblock 88 219 576 minecraft:calcite
fill 88 219 577 88 220 577 minecraft:cobbled_deepslate
setblock 88 219 580 minecraft:cobbled_deepslate
setblock 88 219 591 minecraft:calcite
fill 88 219 592 88 220 592 minecraft:cobbled_deepslate
setblock 88 219 596 minecraft:calcite
fill 88 219 597 88 220 597 minecraft:cobbled_deepslate
setblock 48 220 560 minecraft:calcite
setblock 48 220 561 minecraft:cobbled_deepslate
setblock 48 220 565 minecraft:calcite
setblock 48 220 566 minecraft:cobbled_deepslate
setblock 48 220 570 minecraft:calcite
setblock 48 220 571 minecraft:cobbled_deepslate
setblock 48 220 575 minecraft:calcite
fill 48 220 576 49 220 576 minecraft:cobbled_deepslate
setblock 48 220 580 minecraft:calcite
setblock 48 220 590 minecraft:calcite
setblock 48 220 591 minecraft:cobbled_deepslate
setblock 48 220 595 minecraft:calcite
setblock 48 220 596 minecraft:cobbled_deepslate
setblock 49 220 559 minecraft:calcite
setblock 49 220 560 minecraft:cobbled_deepslate
setblock 49 220 574 minecraft:calcite
setblock 49 220 575 minecraft:cobbled_deepslate
setblock 49 220 590 minecraft:cobbled_deepslate
setblock 49 220 594 minecraft:calcite
setblock 49 220 595 minecraft:cobbled_deepslate
setblock 50 220 558 minecraft:calcite
setblock 50 220 559 minecraft:cobbled_deepslate
setblock 50 220 593 minecraft:calcite
setblock 50 220 594 minecraft:cobbled_deepslate
setblock 50 220 598 minecraft:calcite
setblock 51 220 558 minecraft:cobbled_deepslate
setblock 51 220 597 minecraft:calcite
setblock 51 220 598 minecraft:cobbled_deepslate
setblock 52 220 596 minecraft:calcite
setblock 52 220 597 minecraft:cobbled_deepslate
setblock 53 220 596 minecraft:cobbled_deepslate
setblock 55 220 598 minecraft:calcite
setblock 56 220 597 minecraft:calcite
fill 56 220 598 59 220 598 minecraft:cobbled_deepslate
fill 57 220 597 60 220 597 minecraft:cobbled_deepslate
setblock 60 220 598 minecraft:calcite
setblock 61 220 597 minecraft:calcite
setblock 61 220 598 minecraft:cobbled_deepslate
setblock 62 220 597 minecraft:cobbled_deepslate
fill 65 220 596 66 220 596 minecraft:cobbled_deepslate
setblock 65 220 598 minecraft:calcite
fill 66 220 558 69 220 558 minecraft:cobbled_deepslate
setblock 66 220 597 minecraft:calcite
setblock 66 220 598 minecraft:cobbled_deepslate
setblock 67 220 596 minecraft:calcite
setblock 67 220 597 minecraft:cobbled_deepslate
setblock 68 220 596 minecraft:cobbled_deepslate
setblock 70 220 558 minecraft:calcite
setblock 70 220 598 minecraft:calcite
setblock 71 220 597 minecraft:calcite
setblock 71 220 598 minecraft:cobbled_deepslate
setblock 82 220 558 minecraft:cobbled_deepslate
fill 82 220 598 83 220 598 minecraft:cobbled_deepslate
fill 84 220 597 85 220 597 minecraft:cobbled_deepslate
setblock 85 220 558 minecraft:calcite
setblock 85 220 559 minecraft:cobbled_deepslate
setblock 85 220 598 minecraft:calcite
setblock 86 220 558 minecraft:cobbled_deepslate
setblock 86 220 572 minecraft:calcite
setblock 86 220 573 minecraft:cobbled_deepslate
setblock 86 220 576 minecraft:cobbled_deepslate
setblock 86 220 597 minecraft:calcite
setblock 86 220 598 minecraft:cobbled_deepslate
setblock 87 220 560 minecraft:cobbled_deepslate
setblock 87 220 561 minecraft:calcite
setblock 87 220 562 minecraft:cobbled_deepslate
setblock 87 220 566 minecraft:calcite
setblock 87 220 567 minecraft:cobbled_deepslate
setblock 87 220 571 minecraft:calcite
setblock 87 220 572 minecraft:cobbled_deepslate
setblock 87 220 576 minecraft:calcite
fill 87 220 577 87 220 578 minecraft:cobbled_deepslate
setblock 87 220 592 minecraft:cobbled_deepslate
setblock 87 220 595 minecraft:cobbled_deepslate
setblock 87 220 596 minecraft:calcite
setblock 87 220 597 minecraft:cobbled_deepslate
setblock 88 220 560 minecraft:calcite
setblock 88 220 561 minecraft:cobbled_deepslate
setblock 88 220 565 minecraft:calcite
setblock 88 220 566 minecraft:cobbled_deepslate
setblock 88 220 570 minecraft:calcite
setblock 88 220 571 minecraft:cobbled_deepslate
setblock 88 220 575 minecraft:calcite
setblock 88 220 576 minecraft:cobbled_deepslate
setblock 88 220 580 minecraft:calcite
setblock 88 220 581 minecraft:cobbled_deepslate
setblock 88 220 590 minecraft:calcite
setblock 88 220 591 minecraft:cobbled_deepslate
setblock 88 220 595 minecraft:calcite
setblock 88 220 596 minecraft:cobbled_deepslate
setblock 50 224 560 minecraft:light[level=14]
setblock 50 224 568 minecraft:light[level=14]
setblock 50 224 576 minecraft:light[level=14]
setblock 50 224 584 minecraft:light[level=14]
setblock 50 224 592 minecraft:light[level=14]
setblock 58 224 560 minecraft:light[level=14]
setblock 58 224 568 minecraft:light[level=14]
setblock 58 224 576 minecraft:light[level=14]
setblock 58 224 584 minecraft:light[level=14]
setblock 58 224 592 minecraft:light[level=14]
setblock 66 224 560 minecraft:light[level=14]
setblock 66 224 568 minecraft:light[level=14]
setblock 66 224 576 minecraft:light[level=14]
setblock 66 224 584 minecraft:light[level=14]
setblock 66 224 592 minecraft:light[level=14]
setblock 74 224 560 minecraft:light[level=14]
setblock 74 224 568 minecraft:light[level=14]
setblock 74 224 576 minecraft:light[level=14]
setblock 74 224 584 minecraft:light[level=14]
setblock 74 224 592 minecraft:light[level=14]
setblock 82 224 560 minecraft:light[level=14]
setblock 82 224 568 minecraft:light[level=14]
setblock 82 224 576 minecraft:light[level=14]
setblock 82 224 584 minecraft:light[level=14]
setblock 82 224 592 minecraft:light[level=14]
fill 60 225 578 62 225 580 minecraft:redstone_block
fill 62 225 583 64 225 585 minecraft:redstone_block
fill 65 225 574 67 225 576 minecraft:redstone_block
fill 70 225 580 72 225 582 minecraft:redstone_block
fill 52 226 580 59 226 580 minecraft:diamond_block
fill 54 226 579 59 226 579 minecraft:diamond_block
fill 54 226 581 64 226 581 minecraft:diamond_block
fill 55 226 578 59 226 578 minecraft:diamond_block
fill 55 226 582 69 226 582 minecraft:diamond_block
fill 58 226 577 74 226 577 minecraft:diamond_block
fill 58 226 583 61 226 583 minecraft:diamond_block
fill 59 226 568 59 227 573 minecraft:diamond_block
fill 59 226 587 59 227 592 minecraft:diamond_block
fill 60 226 569 61 226 576 minecraft:diamond_block
fill 60 226 584 61 226 591 minecraft:diamond_block
fill 62 226 570 63 226 576 minecraft:diamond_block
fill 62 226 586 63 226 590 minecraft:diamond_block
fill 63 226 578 64 226 580 minecraft:diamond_block
fill 64 226 571 64 226 576 minecraft:diamond_block
fill 64 226 586 64 226 589 minecraft:diamond_block
fill 65 226 572 65 226 573 minecraft:diamond_block
fill 65 226 578 77 226 578 minecraft:diamond_block
fill 65 226 583 65 226 588 minecraft:diamond_block
fill 66 226 583 72 226 586 minecraft:diamond_block
fill 67 226 572 73 226 573 minecraft:diamond_block
fill 67 226 587 73 226 588 minecraft:diamond_block
fill 68 226 571 73 227 571 minecraft:diamond_block
fill 68 226 574 72 226 576 minecraft:diamond_block
fill 68 226 579 69 226 581 minecraft:diamond_block
fill 68 226 589 73 227 589 minecraft:diamond_block
fill 69 226 570 73 227 570 minecraft:diamond_block
fill 69 226 590 73 227 590 minecraft:diamond_block
fill 70 226 579 78 226 579 minecraft:diamond_block
fill 71 226 569 73 227 569 minecraft:diamond_block
fill 71 226 591 73 227 591 minecraft:diamond_block
fill 73 226 568 73 227 568 minecraft:diamond_block
fill 73 226 580 74 226 583 minecraft:diamond_block
fill 73 226 592 73 227 592 minecraft:diamond_block
fill 75 226 580 77 226 582 minecraft:diamond_block
fill 78 226 580 78 227 581 minecraft:diamond_block
fill 79 226 580 80 227 580 minecraft:diamond_block
fill 48 227 558 51 227 598 minecraft:cobbled_deepslate
fill 52 227 558 53 227 579 minecraft:cobbled_deepslate
fill 52 227 580 56 227 580 minecraft:diamond_block
fill 52 227 581 53 227 598 minecraft:cobbled_deepslate
fill 54 227 558 54 227 578 minecraft:cobbled_deepslate
fill 54 227 579 57 227 579 minecraft:diamond_block
fill 54 227 581 57 227 581 minecraft:diamond_block
fill 54 227 582 54 227 598 minecraft:cobbled_deepslate
fill 55 227 558 57 227 577 minecraft:cobbled_deepslate
fill 55 227 578 58 227 578 minecraft:diamond_block
fill 55 227 582 59 227 582 minecraft:diamond_block
fill 55 227 583 57 227 598 minecraft:cobbled_deepslate
fill 57 227 580 58 227 580 minecraft:light_blue_stained_glass
fill 58 227 558 58 227 576 minecraft:cobbled_deepslate
setblock 58 227 577 minecraft:diamond_block
setblock 58 227 579 minecraft:light_blue_stained_glass
setblock 58 227 581 minecraft:light_blue_stained_glass
fill 58 227 583 60 227 583 minecraft:diamond_block
fill 58 227 584 58 227 598 minecraft:cobbled_deepslate
fill 59 227 558 88 227 567 minecraft:cobbled_deepslate
fill 59 227 574 59 227 576 minecraft:cobbled_deepslate
fill 59 227 577 59 227 581 minecraft:sea_lantern
fill 59 227 584 59 227 586 minecraft:cobbled_deepslate
fill 59 227 593 88 227 598 minecraft:cobbled_deepslate
fill 60 227 568 72 227 568 minecraft:cobbled_deepslate
fill 60 227 569 60 227 576 minecraft:diamond_block
fill 60 227 577 68 227 577 minecraft:sea_lantern
fill 60 227 578 62 227 580 minecraft:cobbled_deepslate
fill 60 227 581 64 227 581 minecraft:sea_lantern
setblock 60 227 582 minecraft:light_blue_stained_glass
fill 60 227 584 60 227 591 minecraft:diamond_block
fill 60 227 592 72 227 592 minecraft:cobbled_deepslate
fill 61 227 569 61 227 571 minecraft:diamond_block
fill 61 227 572 62 227 575 minecraft:light_blue_stained_glass
setblock 61 227 576 minecraft:diamond_block
fill 61 227 582 61 227 586 minecraft:sea_lantern
fill 61 227 587 62 227 588 minecraft:light_blue_stained_glass
fill 61 227 589 61 227 591 minecraft:diamond_block
fill 62 227 569 70 227 569 minecraft:cobbled_deepslate
fill 62 227 570 63 227 571 minecraft:diamond_block
fill 62 227 576 63 227 576 minecraft:light_blue_stained_glass
fill 62 227 582 69 227 582 minecraft:sea_lantern
fill 62 227 583 64 227 585 minecraft:cobbled_deepslate
fill 62 227 586 65 227 586 minecraft:sea_lantern
fill 62 227 589 63 227 590 minecraft:diamond_block
fill 62 227 591 70 227 591 minecraft:cobbled_deepslate
fill 63 227 572 65 227 572 minecraft:diamond_block
fill 63 227 573 63 227 575 minecraft:light_blue_stained_glass
fill 63 227 578 64 227 580 minecraft:sea_lantern
setblock 63 227 587 minecraft:light_blue_stained_glass
fill 63 227 588 65 227 588 minecraft:diamond_block
fill 64 227 570 68 227 570 minecraft:cobbled_deepslate
setblock 64 227 571 minecraft:diamond_block
fill 64 227 573 64 227 576 minecraft:sea_lantern
fill 64 227 587 65 227 587 minecraft:diamond_block
setblock 64 227 589 minecraft:diamond_block
fill 64 227 590 68 227 590 minecraft:cobbled_deepslate
fill 65 227 571 67 227 571 minecraft:cobbled_deepslate
fill 65 227 573 68 227 573 minecraft:sea_lantern
fill 65 227 574 67 227 576 minecraft:cobbled_deepslate
fill 65 227 578 69 227 578 minecraft:sea_lantern
fill 65 227 583 65 227 585 minecraft:sea_lantern
fill 65 227 589 67 227 589 minecraft:cobbled_deepslate
setblock 66 227 572 minecraft:cobbled_deepslate
fill 66 227 583 66 227 584 minecraft:sea_lantern
fill 66 227 585 66 227 586 minecraft:diamond_block
fill 66 227 587 66 227 588 minecraft:cobbled_deepslate
fill 67 227 572 69 227 572 minecraft:diamond_block
fill 67 227 583 73 227 583 minecraft:sea_lantern
fill 67 227 584 70 227 586 minecraft:light_blue_stained_glass
fill 67 227 587 68 227 588 minecraft:diamond_block
fill 68 227 574 68 227 576 minecraft:sea_lantern
fill 68 227 579 69 227 581 minecraft:sea_lantern
fill 69 227 573 70 227 577 minecraft:light_blue_stained_glass
fill 69 227 587 71 227 587 minecraft:light_blue_stained_glass
setblock 69 227 588 minecraft:diamond_block
fill 70 227 572 71 227 572 minecraft:light_blue_stained_glass
fill 70 227 578 72 227 578 minecraft:light_blue_stained_glass
fill 70 227 579 73 227 579 minecraft:sea_lantern
fill 70 227 580 72 227 582 minecraft:cobbled_deepslate
fill 70 227 588 71 227 588 minecraft:light_blue_stained_glass
fill 71 227 573 71 227 575 minecraft:light_blue_stained_glass
fill 71 227 576 72 227 577 minecraft:diamond_block
fill 71 227 584 72 227 584 minecraft:diamond_block
fill 71 227 585 71 227 586 minecraft:light_blue_stained_glass
fill 72 227 572 72 227 575 minecraft:diamond_block
fill 72 227 585 72 227 588 minecraft:diamond_block
fill 73 227 572 73 227 573 minecraft:diamond_block
fill 73 227 574 88 227 576 minecraft:cobbled_deepslate
fill 73 227 577 74 227 578 minecraft:diamond_block
fill 73 227 580 73 227 582 minecraft:sea_lantern
fill 73 227 584 88 227 586 minecraft:cobbled_deepslate
fill 73 227 587 73 227 588 minecraft:diamond_block
fill 74 227 568 88 227 573 minecraft:cobbled_deepslate
fill 74 227 579 74 227 581 minecraft:light_blue_stained_glass
fill 74 227 582 74 227 583 minecraft:diamond_block
fill 74 227 587 88 227 592 minecraft:cobbled_deepslate
fill 75 227 577 88 227 577 minecraft:cobbled_deepslate
fill 75 227 578 77 227 579 minecraft:diamond_block
setblock 75 227 580 minecraft:light_blue_stained_glass
fill 75 227 581 77 227 582 minecraft:diamond_block
fill 75 227 583 88 227 583 minecraft:cobbled_deepslate
fill 76 227 580 77 227 580 minecraft:diamond_block
fill 78 227 578 88 227 578 minecraft:cobbled_deepslate
setblock 78 227 579 minecraft:diamond_block
fill 78 227 582 88 227 582 minecraft:cobbled_deepslate
fill 79 227 579 88 227 579 minecraft:cobbled_deepslate
fill 79 227 581 88 227 581 minecraft:cobbled_deepslate
fill 81 227 580 88 227 580 minecraft:cobbled_deepslate
setblock 48 231 558 minecraft:cobbled_deepslate
setblock 48 231 559 minecraft:calcite
fill 48 231 560 48 231 562 minecraft:cobbled_deepslate
setblock 48 231 579 minecraft:calcite
fill 48 231 580 48 231 583 minecraft:cobbled_deepslate
setblock 48 231 584 minecraft:calcite
fill 48 231 585 48 231 588 minecraft:cobbled_deepslate
setblock 48 231 589 minecraft:calcite
fill 48 231 596 48 231 598 minecraft:cobbled_deepslate
setblock 49 231 558 minecraft:calcite
setblock 49 231 598 minecraft:calcite
fill 57 231 558 58 231 558 minecraft:cobbled_deepslate
setblock 58 231 598 minecraft:cobbled_deepslate
setblock 59 231 558 minecraft:calcite
setblock 59 231 598 minecraft:calcite
fill 60 231 558 63 231 558 minecraft:cobbled_deepslate
fill 60 231 598 63 231 598 minecraft:cobbled_deepslate
fill 61 231 559 62 231 559 minecraft:cobbled_deepslate
setblock 63 231 559 minecraft:calcite
setblock 64 231 558 minecraft:calcite
fill 64 231 559 65 231 559 minecraft:cobbled_deepslate
fill 65 231 558 68 231 558 minecraft:cobbled_deepslate
setblock 73 231 558 minecraft:cobbled_deepslate
setblock 74 231 558 minecraft:calcite
fill 75 231 558 77 231 559 minecraft:cobbled_deepslate
setblock 77 231 560 minecraft:calcite
setblock 78 231 558 minecraft:cobbled_deepslate
setblock 78 231 559 minecraft:calcite
fill 78 231 560 81 231 560 minecraft:cobbled_deepslate
setblock 78 231 598 minecraft:cobbled_deepslate
setblock 79 231 558 minecraft:calcite
fill 79 231 559 82 231 559 minecraft:cobbled_deepslate
setblock 79 231 598 minecraft:calcite
fill 80 231 558 83 231 558 minecraft:cobbled_deepslate
setblock 80 231 561 minecraft:cobbled_deepslate
fill 80 231 598 83 231 598 minecraft:cobbled_deepslate
setblock 81 231 561 minecraft:calcite
setblock 82 231 560 minecraft:calcite
fill 82 231 561 84 231 561 minecraft:cobbled_deepslate
setblock 83 231 559 minecraft:calcite
fill 83 231 560 86 231 560 minecraft:cobbled_deepslate
fill 83 231 582 87 231 582 minecraft:light_blue_stained_glass
fill 83 231 597 84 231 597 minecraft:cobbled_deepslate
setblock 84 231 558 minecraft:calcite
fill 84 231 559 87 231 559 minecraft:cobbled_deepslate
fill 84 231 581 88 232 581 minecraft:light_blue_stained_glass
fill 84 231 583 87 232 583 minecraft:light_blue_stained_glass
setblock 84 231 598 minecraft:calcite
fill 85 231 558 88 231 558 minecraft:cobbled_deepslate
fill 85 231 580 88 232 580 minecraft:light_blue_stained_glass
fill 85 231 584 87 232 584 minecraft:light_blue_stained_glass
fill 85 231 598 88 231 598 minecraft:cobbled_deepslate
setblock 86 231 561 minecraft:calcite
fill 86 231 562 88 232 562 minecraft:cobbled_deepslate
setblock 87 231 560 minecraft:calcite
fill 87 231 561 88 233 561 minecraft:cobbled_deepslate
fill 87 231 563 87 231 564 minecraft:cobbled_deepslate
setblock 88 231 559 minecraft:calcite
fill 88 231 560 88 234 560 minecraft:cobbled_deepslate
setblock 88 231 563 minecraft:cobbled_deepslate
setblock 88 231 564 minecraft:calcite
fill 88 231 565 88 234 565 minecraft:cobbled_deepslate
fill 88 231 582 88 231 583 minecraft:cobbled_deepslate
setblock 88 231 584 minecraft:calcite
setblock 88 231 597 minecraft:cobbled_deepslate
fill 48 232 559 48 232 560 minecraft:cobbled_deepslate
fill 48 232 580 48 232 582 minecraft:cobbled_deepslate
setblock 48 232 583 minecraft:calcite
fill 48 232 584 48 232 587 minecraft:cobbled_deepslate
setblock 48 232 588 minecraft:calcite
fill 48 232 589 48 235 589 minecraft:cobbled_deepslate
setblock 50 232 560 minecraft:light[level=14]
setblock 50 232 568 minecraft:light[level=14]
setblock 50 232 576 minecraft:light[level=14]
setblock 50 232 584 minecraft:light[level=14]
setblock 50 232 592 minecraft:light[level=14]
setblock 58 232 558 minecraft:calcite
setblock 58 232 560 minecraft:light[level=14]
setblock 58 232 568 minecraft:light[level=14]
setblock 58 232 576 minecraft:light[level=14]
setblock 58 232 584 minecraft:light[level=14]
setblock 58 232 592 minecraft:light[level=14]
fill 59 232 558 62 232 558 minecraft:cobbled_deepslate
fill 59 232 598 61 232 598 minecraft:cobbled_deepslate
setblock 61 232 559 minecraft:cobbled_deepslate
setblock 62 232 559 minecraft:calcite
setblock 63 232 558 minecraft:calcite
setblock 63 232 559 minecraft:cobbled_deepslate
fill 64 232 558 66 232 558 minecraft:cobbled_deepslate
setblock 66 232 560 minecraft:light[level=14]
setblock 66 232 568 minecraft:light[level=14]
setblock 66 232 576 minecraft:light[level=14]
setblock 66 232 584 minecraft:light[level=14]
setblock 66 232 592 minecraft:light[level=14]
setblock 73 232 558 minecraft:calcite
fill 74 232 558 77 232 558 minecraft:cobbled_deepslate
setblock 74 232 560 minecraft:light[level=14]
setblock 74 232 568 minecraft:light[level=14]
setblock 74 232 576 minecraft:light[level=14]
setblock 74 232 584 minecraft:light[level=14]
setblock 74 232 592 minecraft:light[level=14]
fill 75 232 559 76 232 559 minecraft:cobbled_deepslate
setblock 77 232 559 minecraft:calcite
fill 77 232 560 80 232 560 minecraft:cobbled_deepslate
setblock 78 232 558 minecraft:calcite
fill 78 232 559 81 232 559 minecraft:cobbled_deepslate
setblock 78 232 598 minecraft:calcite
fill 79 232 558 82 232 558 minecraft:cobbled_deepslate
setblock 79 232 561 minecraft:cobbled_deepslate
fill 79 232 598 82 232 598 minecraft:cobbled_deepslate
setblock 80 232 561 minecraft:calcite
setblock 81 232 560 minecraft:calcite
fill 81 232 561 83 233 561 minecraft:cobbled_deepslate
setblock 82 232 559 minecraft:calcite
fill 82 232 560 85 232 560 minecraft:cobbled_deepslate
setblock 82 232 568 minecraft:light[level=14]
setblock 82 232 576 minecraft:light[level=14]
setblock 82 232 584 minecraft:light[level=14]
setblock 82 232 592 minecraft:light[level=14]
setblock 83 232 558 minecraft:calcite
fill 83 232 559 86 232 559 minecraft:cobbled_deepslate
setblock 83 232 598 minecraft:calcite
fill 84 232 558 87 232 558 minecraft:cobbled_deepslate
fill 84 232 582 88 232 582 minecraft:light_blue_stained_glass
fill 84 232 598 87 232 598 minecraft:cobbled_deepslate
setblock 86 232 560 minecraft:calcite
setblock 86 232 561 minecraft:cobbled_deepslate
setblock 87 232 559 minecraft:calcite
fill 87 232 560 87 234 560 minecraft:cobbled_deepslate
setblock 87 232 563 minecraft:cobbled_deepslate
setblock 88 232 558 minecraft:calcite
fill 88 232 559 88 235 559 minecraft:cobbled_deepslate
setblock 88 232 563 minecraft:calcite
fill 88 232 564 88 235 564 minecraft:cobbled_deepslate
fill 88 232 583 88 233 584 minecraft:light_blue_stained_glass
setblock 88 232 598 minecraft:calcite
setblock 48 233 581 minecraft:cobbled_deepslate
setblock 48 233 582 minecraft:calcite
fill 48 233 583 48 233 586 minecraft:cobbled_deepslate
setblock 48 233 587 minecraft:calcite
fill 48 233 588 48 236 588 minecraft:cobbled_deepslate
fill 48 233 590 48 234 590 minecraft:cobbled_deepslate
fill 58 233 558 61 233 558 minecraft:cobbled_deepslate
setblock 62 233 558 minecraft:calcite
fill 63 233 558 65 233 558 minecraft:cobbled_deepslate
fill 73 233 558 76 233 558 minecraft:cobbled_deepslate
setblock 75 233 559 minecraft:cobbled_deepslate
setblock 76 233 559 minecraft:calcite
setblock 77 233 558 minecraft:calcite
fill 77 233 559 79 233 560 minecraft:cobbled_deepslate
fill 78 233 558 81 233 558 minecraft:cobbled_deepslate
fill 78 233 598 81 233 598 minecraft:cobbled_deepslate
setblock 79 233 561 minecraft:calcite
setblock 80 233 559 minecraft:cobbled_deepslate
setblock 80 233 560 minecraft:calcite
fill 80 233 561 80 236 561 minecraft:cobbled_deepslate
setblock 81 233 559 minecraft:calcite
fill 81 233 560 84 233 560 minecraft:cobbled_deepslate
setblock 82 233 558 minecraft:calcite
fill 82 233 559 85 233 559 minecraft:cobbled_deepslate
setblock 82 233 598 minecraft:calcite
fill 83 233 558 86 233 558 minecraft:cobbled_deepslate
fill 83 233 598 86 233 598 minecraft:cobbled_deepslate
setblock 85 233 560 minecraft:calcite
fill 85 233 581 87 233 583 minecraft:light_blue_stained_glass
setblock 86 233 559 minecraft:calcite
fill 86 233 580 88 233 580 minecraft:light_blue_stained_glass
fill 86 233 584 87 233 584 minecraft:light_blue_stained_glass
setblock 87 233 558 minecraft:calcite
fill 87 233 559 87 234 559 minecraft:cobbled_deepslate
setblock 87 233 562 minecraft:cobbled_deepslate
setblock 87 233 563 minecraft:calcite
setblock 87 233 598 minecraft:calcite
fill 88 233 558 88 236 558 minecraft:cobbled_deepslate
setblock 88 233 562 minecraft:calcite
fill 88 233 563 88 236 563 minecraft:cobbled_deepslate
fill 88 233 581 88 234 582 minecraft:light_blue_stained_glass
setblock 48 234 581 minecraft:calcite
fill 48 234 582 48 234 585 minecraft:cobbled_deepslate
setblock 48 234 586 minecraft:calcite
fill 48 234 587 48 237 587 minecraft:cobbled_deepslate
setblock 49 234 585 minecraft:calcite
fill 49 234 586 49 237 586 minecraft:cobbled_deepslate
fill 58 234 558 60 234 558 minecraft:cobbled_deepslate
setblock 61 234 558 minecraft:calcite
fill 62 234 558 64 235 558 minecraft:cobbled_deepslate
fill 67 234 594 67 242 594 minecraft:calcite
fill 73 234 558 75 234 558 minecraft:cobbled_deepslate
setblock 74 234 559 minecraft:cobbled_deepslate
setblock 75 234 559 minecraft:calcite
setblock 76 234 558 minecraft:calcite
fill 76 234 559 78 234 560 minecraft:cobbled_deepslate
fill 77 234 558 80 234 558 minecraft:cobbled_deepslate
setblock 78 234 561 minecraft:calcite
fill 78 234 598 80 234 598 minecraft:cobbled_deepslate
setblock 79 234 559 minecraft:cobbled_deepslate
setblock 79 234 560 minecraft:calcite
fill 79 234 561 79 237 561 minecraft:cobbled_deepslate
setblock 80 234 559 minecraft:calcite
fill 80 234 560 83 234 560 minecraft:cobbled_deepslate
setblock 81 234 558 minecraft:calcite
fill 81 234 559 84 234 559 minecraft:cobbled_deepslate
fill 81 234 561 82 234 561 minecraft:cobbled_deepslate
setblock 81 234 598 minecraft:calcite
fill 82 234 558 85 234 558 minecraft:cobbled_deepslate
fill 82 234 598 85 234 598 minecraft:cobbled_deepslate
setblock 84 234 560 minecraft:calcite
setblock 85 234 559 minecraft:calcite
setblock 85 234 560 minecraft:cobbled_deepslate
setblock 86 234 558 minecraft:calcite
fill 86 234 559 86 235 559 minecraft:cobbled_deepslate
fill 86 234 581 87 234 583 minecraft:light_blue_stained_glass
setblock 86 234 598 minecraft:calcite
fill 87 234 558 87 237 558 minecraft:cobbled_deepslate
setblock 87 234 561 minecraft:cobbled_deepslate
setblock 87 234 562 minecraft:calcite
setblock 87 234 563 minecraft:cobbled_deepslate
setblock 88 234 561 minecraft:calcite
fill 88 234 562 88 237 562 minecraft:cobbled_deepslate
setblock 88 234 583 minecraft:light_blue_stained_glass
setblock 88 234 585 minecraft:cobbled_deepslate
setblock 88 234 586 minecraft:calcite
fill 88 234 587 88 237 587 minecraft:cobbled_deepslate
fill 48 235 581 48 235 584 minecraft:cobbled_deepslate
setblock 48 235 585 minecraft:calcite
fill 48 235 586 48 238 586 minecraft:cobbled_deepslate
setblock 48 235 590 minecraft:calcite
fill 48 235 591 48 238 591 minecraft:cobbled_deepslate
setblock 49 235 584 minecraft:calcite
fill 49 235 585 49 238 585 minecraft:cobbled_deepslate
fill 49 235 587 49 235 588 minecraft:cobbled_deepslate
fill 57 235 558 59 235 558 minecraft:cobbled_deepslate
setblock 60 235 558 minecraft:calcite
fill 61 235 558 61 238 558 minecraft:cobbled_deepslate
fill 72 235 558 74 235 558 minecraft:cobbled_deepslate
setblock 74 235 559 minecraft:calcite
setblock 75 235 558 minecraft:calcite
fill 75 235 559 77 235 560 minecraft:cobbled_deepslate
fill 76 235 558 79 235 558 minecraft:cobbled_deepslate
setblock 77 235 561 minecraft:calcite
fill 77 235 598 79 235 598 minecraft:cobbled_deepslate
setblock 78 235 559 minecraft:cobbled_deepslate
setblock 78 235 560 minecraft:calcite
fill 78 235 561 78 238 561 minecraft:cobbled_deepslate
fill 78 235 566 81 273 567 minecraft:calcite
setblock 79 235 559 minecraft:calcite
fill 79 235 560 82 235 560 minecraft:cobbled_deepslate
fill 79 235 565 80 273 565 minecraft:calcite
fill 79 235 568 80 273 568 minecraft:calcite
setblock 80 235 558 minecraft:calcite
fill 80 235 559 83 235 559 minecraft:cobbled_deepslate
setblock 80 235 598 minecraft:calcite
fill 81 235 558 84 235 558 minecraft:cobbled_deepslate
setblock 81 235 561 minecraft:cobbled_deepslate
fill 81 235 598 84 235 598 minecraft:cobbled_deepslate
setblock 82 235 561 minecraft:calcite
setblock 83 235 560 minecraft:calcite
setblock 84 235 559 minecraft:calcite
setblock 84 235 560 minecraft:cobbled_deepslate
setblock 85 235 558 minecraft:calcite
fill 85 235 559 85 237 559 minecraft:cobbled_deepslate
setblock 85 235 598 minecraft:calcite
fill 86 235 558 86 238 558 minecraft:cobbled_deepslate
fill 86 235 598 86 238 598 minecraft:cobbled_deepslate
setblock 87 235 561 minecraft:calcite
setblock 87 235 562 minecraft:cobbled_deepslate
setblock 88 235 560 minecraft:calcite
fill 88 235 561 88 238 561 minecraft:cobbled_deepslate
setblock 88 235 565 minecraft:calcite
setblock 88 235 584 minecraft:cobbled_deepslate
setblock 88 235 585 minecraft:calcite
fill 88 235 586 88 238 586 minecraft:cobbled_deepslate
fill 88 235 588 88 235 589 minecraft:cobbled_deepslate
fill 48 236 581 48 236 583 minecraft:cobbled_deepslate
setblock 48 236 584 minecraft:calcite
fill 48 236 585 48 239 585 minecraft:cobbled_deepslate
setblock 48 236 589 minecraft:calcite
fill 48 236 590 48 239 590 minecraft:cobbled_deepslate
fill 48 236 592 48 236 593 minecraft:cobbled_deepslate
setblock 49 236 583 minecraft:calcite
fill 49 236 584 49 239 584 minecraft:cobbled_deepslate
setblock 49 236 587 minecraft:cobbled_deepslate
setblock 49 236 588 minecraft:calcite
fill 49 236 589 49 239 589 minecraft:cobbled_deepslate
fill 57 236 558 58 236 558 minecraft:cobbled_deepslate
setblock 59 236 558 minecraft:calcite
fill 60 236 558 60 239 558 minecraft:cobbled_deepslate
fill 62 236 558 63 236 558 minecraft:cobbled_deepslate
fill 72 236 558 73 236 558 minecraft:cobbled_deepslate
setblock 73 236 559 minecraft:calcite
setblock 74 236 558 minecraft:calcite
fill 74 236 559 77 236 559 minecraft:cobbled_deepslate
fill 75 236 558 78 236 558 minecraft:cobbled_deepslate
fill 75 236 560 76 236 560 minecraft:cobbled_deepslate
fill 76 236 598 78 236 598 minecraft:cobbled_deepslate
setblock 77 236 560 minecraft:calcite
fill 77 236 561 77 239 561 minecraft:cobbled_deepslate
setblock 78 236 559 minecraft:calcite
fill 78 236 560 81 236 560 minecraft:cobbled_deepslate
fill 78 236 565 78 237 565 minecraft:deepslate
fill 78 236 568 78 237 568 minecraft:deepslate
setblock 79 236 558 minecraft:calcite
fill 79 236 559 82 236 559 minecraft:cobbled_deepslate
setblock 79 236 598 minecraft:calcite
fill 80 236 558 83 236 558 minecraft:cobbled_deepslate
fill 80 236 598 83 236 598 minecraft:cobbled_deepslate
setblock 81 236 561 minecraft:calcite
fill 81 236 565 81 237 565 minecraft:deepslate
fill 81 236 568 81 237 568 minecraft:deepslate
setblock 82 236 560 minecraft:calcite
fill 82 236 566 82 237 567 minecraft:deepslate
setblock 83 236 559 minecraft:calcite
fill 83 236 560 83 237 560 minecraft:cobbled_deepslate
setblock 84 236 558 minecraft:calcite
fill 84 236 559 84 238 559 minecraft:cobbled_deepslate
setblock 84 236 598 minecraft:calcite
fill 85 236 558 85 239 558 minecraft:cobbled_deepslate
fill 85 236 598 85 239 598 minecraft:cobbled_deepslate
setblock 88 236 559 minecraft:calcite
fill 88 236 560 88 238 560 minecraft:cobbled_deepslate
setblock 88 236 564 minecraft:calcite
fill 88 236 565 88 238 566 minecraft:cobbled_deepslate
setblock 88 236 584 minecraft:calcite
fill 88 236 585 88 239 585 minecraft:cobbled_deepslate
setblock 88 236 588 minecraft:cobbled_deepslate
setblock 88 236 589 minecraft:calcite
fill 88 236 590 88 237 592 minecraft:cobbled_deepslate
fill 48 237 581 48 237 582 minecraft:cobbled_deepslate
setblock 48 237 583 minecraft:calcite
fill 48 237 584 48 240 584 minecraft:cobbled_deepslate
setblock 48 237 588 minecraft:calcite
fill 48 237 589 48 240 589 minecraft:cobbled_deepslate
setblock 48 237 592 minecraft:cobbled_deepslate
setblock 48 237 593 minecraft:calcite
fill 48 237 594 48 240 594 minecraft:cobbled_deepslate
fill 49 237 583 49 240 583 minecraft:cobbled_deepslate
setblock 49 237 587 minecraft:calcite
fill 49 237 588 49 240 588 minecraft:cobbled_deepslate
fill 49 237 590 49 237 591 minecraft:cobbled_deepslate
setblock 50 237 586 minecraft:calcite
fill 50 237 587 50 240 587 minecraft:cobbled_deepslate
fill 56 237 558 57 237 558 minecraft:cobbled_deepslate
setblock 57 237 598 minecraft:cobbled_deepslate
setblock 58 237 558 minecraft:calcite
setblock 58 237 598 minecraft:calcite
fill 59 237 558 59 240 558 minecraft:cobbled_deepslate
setblock 62 237 558 minecraft:cobbled_deepslate
setblock 63 237 558 minecraft:calcite
fill 71 237 558 72 237 558 minecraft:cobbled_deepslate
setblock 73 237 558 minecraft:calcite
fill 73 237 559 76 237 559 minecraft:cobbled_deepslate
fill 74 237 558 77 237 558 minecraft:cobbled_deepslate
fill 74 237 560 75 237 560 minecraft:cobbled_deepslate
fill 75 237 598 77 237 598 minecraft:cobbled_deepslate
setblock 76 237 560 minecraft:calcite
fill 76 237 561 76 240 561 minecraft:cobbled_deepslate
setblock 77 237 559 minecraft:calcite
fill 77 237 560 80 237 560 minecraft:cobbled_deepslate
fill 77 237 565 77 237 568 minecraft:deepslate
setblock 78 237 558 minecraft:calcite
fill 78 237 559 81 237 559 minecraft:cobbled_deepslate
fill 78 237 564 81 237 564 minecraft:deepslate
fill 78 237 569 81 237 569 minecraft:deepslate
setblock 78 237 598 minecraft:calcite
fill 79 237 558 82 237 558 minecraft:cobbled_deepslate
setblock 79 237 597 minecraft:calcite
fill 79 237 598 82 237 598 minecraft:cobbled_deepslate
setblock 80 237 561 minecraft:calcite
fill 80 237 597 82 238 597 minecraft:cobbled_deepslate
setblock 81 237 560 minecraft:calcite
setblock 81 237 561 minecraft:cobbled_deepslate
setblock 82 237 559 minecraft:calcite
fill 82 237 560 82 238 560 minecraft:cobbled_deepslate
setblock 82 237 565 minecraft:deepslate
setblock 82 237 568 minecraft:deepslate
setblock 83 237 558 minecraft:calcite
fill 83 237 559 83 239 559 minecraft:cobbled_deepslate
setblock 83 237 598 minecraft:calcite
fill 84 237 558 84 240 558 minecraft:cobbled_deepslate
fill 84 237 598 84 240 598 minecraft:cobbled_deepslate
fill 87 237 587 87 237 588 minecraft:cobbled_deepslate
setblock 87 237 589 minecraft:calcite
setblock 88 237 559 minecraft:cobbled_deepslate
setblock 88 237 563 minecraft:calcite
fill 88 237 564 88 240 564 minecraft:cobbled_deepslate
fill 88 237 584 88 240 584 minecraft:cobbled_deepslate
setblock 88 237 588 minecraft:calcite
fill 88 237 589 88 240 589 minecraft:cobbled_deepslate
setblock 88 237 593 minecraft:calcite
fill 88 237 594 88 240 594 minecraft:cobbled_deepslate
setblock 48 238 581 minecraft:cobbled_deepslate
setblock 48 238 582 minecraft:calcite
fill 48 238 583 48 241 583 minecraft:cobbled_deepslate
setblock 48 238 587 minecraft:calcite
fill 48 238 588 48 241 588 minecraft:cobbled_deepslate
setblock 48 238 592 minecraft:calcite
fill 48 238 593 48 241 593 minecraft:cobbled_deepslate
setblock 49 238 586 minecraft:calcite
fill 49 238 587 49 241 587 minecraft:cobbled_deepslate
setblock 49 238 590 minecraft:cobbled_deepslate
setblock 49 238 591 minecraft:calcite
fill 49 238 592 49 241 592 minecraft:cobbled_deepslate
setblock 50 238 585 minecraft:calcite
fill 50 238 586 50 241 586 minecraft:cobbled_deepslate
fill 50 238 588 50 238 589 minecraft:cobbled_deepslate
fill 55 238 598 56 238 598 minecraft:cobbled_deepslate
setblock 56 238 558 minecraft:cobbled_deepslate
setblock 57 238 558 minecraft:calcite
setblock 57 238 598 minecraft:calcite
fill 58 238 558 58 241 558 minecraft:cobbled_deepslate
fill 58 238 598 59 239 598 minecraft:cobbled_deepslate
setblock 62 238 558 minecraft:calcite
setblock 71 238 558 minecraft:cobbled_deepslate
setblock 72 238 558 minecraft:calcite
fill 72 238 559 75 238 559 minecraft:cobbled_deepslate
fill 73 238 558 76 238 558 minecraft:cobbled_deepslate
setblock 74 238 560 minecraft:cobbled_deepslate
fill 74 238 598 76 238 598 minecraft:cobbled_deepslate
setblock 75 238 560 minecraft:calcite
setblock 76 238 559 minecraft:calcite
fill 76 238 560 79 238 560 minecraft:cobbled_deepslate
setblock 77 238 558 minecraft:calcite
fill 77 238 559 80 238 559 minecraft:cobbled_deepslate
setblock 77 238 597 minecraft:cobbled_deepslate
setblock 77 238 598 minecraft:calcite
fill 78 238 558 81 238 558 minecraft:cobbled_deepslate
setblock 78 238 597 minecraft:calcite
fill 78 238 598 81 238 598 minecraft:cobbled_deepslate
setblock 79 238 561 minecraft:calcite
fill 79 238 597 79 241 597 minecraft:cobbled_deepslate
setblock 80 238 560 minecraft:calcite
setblock 80 238 561 minecraft:cobbled_deepslate
setblock 81 238 559 minecraft:calcite
fill 81 238 560 81 239 560 minecraft:cobbled_deepslate
setblock 82 238 558 minecraft:calcite
fill 82 238 559 82 240 559 minecraft:cobbled_deepslate
setblock 82 238 598 minecraft:calcite
fill 83 238 558 83 241 558 minecraft:cobbled_deepslate
setblock 83 238 597 minecraft:light_blue_stained_glass
fill 83 238 598 83 241 598 minecraft:cobbled_deepslate
setblock 84 238 596 minecraft:deepslate
fill 87 238 586 87 238 587 minecraft:cobbled_deepslate
setblock 87 238 588 minecraft:calcite
fill 87 238 589 87 239 591 minecraft:cobbled_deepslate
setblock 87 238 598 minecraft:calcite
setblock 88 238 562 minecraft:calcite
fill 88 238 563 88 240 563 minecraft:cobbled_deepslate
setblock 88 238 567 minecraft:calcite
fill 88 238 583 88 239 583 minecraft:cobbled_deepslate
setblock 88 238 587 minecraft:calcite
fill 88 238 588 88 241 588 minecraft:cobbled_deepslate
fill 88 238 590 88 238 591 minecraft:cobbled_deepslate
setblock 88 238 592 minecraft:calcite
fill 88 238 593 88 241 593 minecraft:cobbled_deepslate
fill 88 238 595 88 238 596 minecraft:cobbled_deepslate
setblock 48 239 566 minecraft:calcite
fill 48 239 567 48 241 568 minecraft:cobbled_deepslate
setblock 48 239 581 minecraft:calcite
fill 48 239 582 48 242 582 minecraft:cobbled_deepslate
setblock 48 239 586 minecraft:calcite
fill 48 239 587 48 242 587 minecraft:cobbled_deepslate
setblock 48 239 591 minecraft:calcite
fill 48 239 592 48 242 592 minecraft:cobbled_deepslate
setblock 48 239 595 minecraft:cobbled_deepslate
setblock 49 239 585 minecraft:calcite
fill 49 239 586 49 242 586 minecraft:cobbled_deepslate
setblock 49 239 590 minecraft:calcite
fill 49 239 591 49 242 591 minecraft:cobbled_deepslate
fill 49 239 593 49 240 593 minecraft:cobbled_deepslate
fill 50 239 585 50 241 585 minecraft:cobbled_deepslate
setblock 50 239 588 minecraft:cobbled_deepslate
setblock 50 239 589 minecraft:calcite
fill 50 239 590 50 242 590 minecraft:cobbled_deepslate
fill 54 239 598 55 239 598 minecraft:cobbled_deepslate
setblock 55 239 558 minecraft:cobbled_deepslate
setblock 56 239 558 minecraft:calcite
setblock 56 239 598 minecraft:calcite
fill 57 239 558 57 241 558 minecraft:cobbled_deepslate
fill 57 239 598 57 242 598 minecraft:cobbled_deepslate
setblock 61 239 558 minecraft:calcite
fill 66 239 594 66 242 594 minecraft:calcite
fill 67 239 593 67 242 593 minecraft:calcite
fill 67 239 595 67 242 595 minecraft:calcite
fill 68 239 594 68 242 594 minecraft:calcite
setblock 70 239 558 minecraft:cobbled_deepslate
setblock 71 239 558 minecraft:calcite
fill 72 239 558 74 239 559 minecraft:cobbled_deepslate
setblock 73 239 560 minecraft:cobbled_deepslate
setblock 74 239 560 minecraft:calcite
fill 74 239 598 75 239 598 minecraft:cobbled_deepslate
setblock 75 239 558 minecraft:cobbled_deepslate
setblock 75 239 559 minecraft:calcite
fill 75 239 560 75 239 561 minecraft:cobbled_deepslate
setblock 76 239 558 minecraft:calcite
fill 76 239 559 78 239 560 minecraft:cobbled_deepslate
setblock 76 239 597 minecraft:cobbled_deepslate
setblock 76 239 598 minecraft:calcite
fill 77 239 558 80 239 558 minecraft:cobbled_deepslate
setblock 77 239 597 minecraft:calcite
fill 77 239 598 80 239 598 minecraft:cobbled_deepslate
setblock 78 239 561 minecraft:calcite
fill 78 239 597 78 242 597 minecraft:cobbled_deepslate
setblock 79 239 559 minecraft:cobbled_deepslate
setblock 79 239 560 minecraft:calcite
setblock 79 239 561 minecraft:cobbled_deepslate
setblock 80 239 559 minecraft:calcite
fill 80 239 560 80 240 560 minecraft:cobbled_deepslate
fill 80 239 597 81 239 597 minecraft:cobbled_deepslate
setblock 81 239 558 minecraft:calcite
fill 81 239 559 81 241 559 minecraft:cobbled_deepslate
setblock 81 239 598 minecraft:calcite
fill 82 239 558 82 242 558 minecraft:cobbled_deepslate
fill 82 239 596 84 242 596 minecraft:light_blue_stained_glass
setblock 82 239 597 minecraft:calcite
fill 82 239 598 82 242 598 minecraft:cobbled_deepslate
fill 83 239 595 83 242 595 minecraft:light_blue_stained_glass
fill 83 239 597 83 240 597 minecraft:cobbled_deepslate
fill 84 239 597 85 242 597 minecraft:light_blue_stained_glass
setblock 86 239 598 minecraft:calcite
setblock 87 239 586 minecraft:cobbled_deepslate
setblock 87 239 587 minecraft:calcite
fill 87 239 588 87 242 588 minecraft:cobbled_deepslate
setblock 87 239 592 minecraft:calcite
fill 87 239 593 87 242 593 minecraft:cobbled_deepslate
fill 87 239 598 88 241 598 minecraft:cobbled_deepslate
setblock 88 239 562 minecraft:cobbled_deepslate
setblock 88 239 565 minecraft:cobbled_deepslate
setblock 88 239 566 minecraft:calcite
fill 88 239 567 88 241 568 minecraft:cobbled_deepslate
setblock 88 239 586 minecraft:calcite
fill 88 239 587 88 242 587 minecraft:cobbled_deepslate
setblock 88 239 590 minecraft:cobbled_deepslate
setblock 88 239 591 minecraft:calcite
fill 88 239 592 88 242 592 minecraft:cobbled_deepslate
setblock 88 239 595 minecraft:cobbled_deepslate
setblock 88 239 596 minecraft:calcite
fill 88 239 597 88 242 597 minecraft:cobbled_deepslate
fill 48 240 566 48 241 566 minecraft:cobbled_deepslate
setblock 48 240 569 minecraft:cobbled_deepslate
setblock 48 240 570 minecraft:calcite
fill 48 240 581 48 241 581 minecraft:cobbled_deepslate
setblock 48 240 585 minecraft:calcite
fill 48 240 586 48 243 586 minecraft:cobbled_deepslate
setblock 48 240 590 minecraft:calcite
fill 48 240 591 48 243 591 minecraft:cobbled_deepslate
setblock 48 240 595 minecraft:calcite
fill 48 240 596 48 243 596 minecraft:cobbled_deepslate
fill 49 240 568 49 242 570 minecraft:light_blue_stained_glass
setblock 49 240 584 minecraft:calcite
fill 49 240 585 49 243 585 minecraft:cobbled_deepslate
setblock 49 240 589 minecraft:calcite
fill 49 240 590 49 243 590 minecraft:cobbled_deepslate
setblock 50 240 560 minecraft:light[level=14]
setblock 50 240 568 minecraft:light[level=14]
fill 50 240 569 51 242 569 minecraft:light_blue_stained_glass
setblock 50 240 576 minecraft:light[level=14]
setblock 50 240 584 minecraft:light[level=14]
setblock 50 240 588 minecraft:calcite
fill 50 240 589 50 243 589 minecraft:cobbled_deepslate
fill 50 240 591 50 241 591 minecraft:cobbled_deepslate
setblock 50 240 592 minecraft:light[level=14]
fill 53 240 598 54 240 598 minecraft:cobbled_deepslate
setblock 55 240 558 minecraft:calcite
setblock 55 240 598 minecraft:calcite
fill 56 240 558 56 241 558 minecraft:cobbled_deepslate
fill 56 240 598 56 243 598 minecraft:cobbled_deepslate
setblock 58 240 560 minecraft:light[level=14]
setblock 58 240 568 minecraft:light[level=14]
setblock 58 240 576 minecraft:light[level=14]
setblock 58 240 584 minecraft:light[level=14]
setblock 58 240 592 minecraft:light[level=14]
fill 58 240 598 58 241 598 minecraft:cobbled_deepslate
setblock 60 240 558 minecraft:calcite
setblock 66 240 560 minecraft:light[level=14]
setblock 66 240 568 minecraft:light[level=14]
setblock 66 240 576 minecraft:light[level=14]
setblock 66 240 584 minecraft:light[level=14]
setblock 66 240 592 minecraft:light[level=14]
setblock 70 240 558 minecraft:calcite
fill 71 240 558 74 240 558 minecraft:cobbled_deepslate
fill 72 240 559 73 240 559 minecraft:cobbled_deepslate
setblock 73 240 560 minecraft:calcite
fill 73 240 598 74 240 598 minecraft:cobbled_deepslate
setblock 74 240 559 minecraft:calcite
fill 74 240 560 77 240 560 minecraft:cobbled_deepslate
setblock 74 240 568 minecraft:light[level=14]
setblock 74 240 576 minecraft:light[level=14]
setblock 74 240 584 minecraft:light[level=14]
setblock 74 240 592 minecraft:light[level=14]
setblock 75 240 558 minecraft:calcite
fill 75 240 559 78 240 559 minecraft:cobbled_deepslate
setblock 75 240 597 minecraft:cobbled_deepslate
setblock 75 240 598 minecraft:calcite
fill 76 240 558 79 240 558 minecraft:cobbled_deepslate
setblock 76 240 597 minecraft:calcite
fill 76 240 598 79 240 598 minecraft:cobbled_deepslate
setblock 77 240 561 minecraft:calcite
fill 77 240 597 77 243 597 minecraft:cobbled_deepslate
setblock 78 240 560 minecraft:calcite
setblock 78 240 561 minecraft:cobbled_deepslate
setblock 79 240 559 minecraft:calcite
fill 79 240 560 79 241 560 minecraft:cobbled_deepslate
setblock 80 240 558 minecraft:calcite
fill 80 240 559 80 242 559 minecraft:cobbled_deepslate
setblock 80 240 597 minecraft:cobbled_deepslate
setblock 80 240 598 minecraft:calcite
fill 81 240 558 81 243 558 minecraft:cobbled_deepslate
fill 81 240 596 81 241 596 minecraft:light_blue_stained_glass
setblock 81 240 597 minecraft:calcite
fill 81 240 598 81 243 598 minecraft:cobbled_deepslate
setblock 82 240 560 minecraft:light[level=14]
setblock 82 240 568 minecraft:light[level=14]
setblock 82 240 576 minecraft:light[level=14]
setblock 82 240 584 minecraft:light[level=14]
setblock 82 240 592 minecraft:light[level=14]
fill 82 240 594 82 242 595 minecraft:light_blue_stained_glass
fill 82 240 597 82 242 597 minecraft:cobbled_deepslate
fill 83 240 594 84 242 594 minecraft:light_blue_stained_glass
fill 84 240 595 84 242 595 minecraft:light_blue_stained_glass
fill 85 240 596 85 241 596 minecraft:light_blue_stained_glass
setblock 85 240 598 minecraft:calcite
fill 86 240 598 86 243 598 minecraft:cobbled_deepslate
setblock 87 240 586 minecraft:calcite
fill 87 240 587 87 242 587 minecraft:cobbled_deepslate
fill 87 240 589 87 240 590 minecraft:cobbled_deepslate
setblock 87 240 591 minecraft:calcite
fill 87 240 592 87 243 592 minecraft:cobbled_deepslate
fill 87 240 594 87 241 594 minecraft:cobbled_deepslate
setblock 88 240 565 minecraft:calcite
fill 88 240 566 88 241 566 minecraft:cobbled_deepslate
setblock 88 240 585 minecraft:calcite
fill 88 240 586 88 243 586 minecraft:cobbled_deepslate
setblock 88 240 590 minecraft:calcite
fill 88 240 591 88 243 591 minecraft:cobbled_deepslate
setblock 88 240 595 minecraft:calcite
fill 88 240 596 88 243 596 minecraft:cobbled_deepslate
setblock 48 241 569 minecraft:calcite
fill 48 241 570 48 242 572 minecraft:cobbled_deepslate
setblock 48 241 584 minecraft:calcite
fill 48 241 585 48 244 585 minecraft:cobbled_deepslate
setblock 48 241 589 minecraft:calcite
fill 48 241 590 48 244 590 minecraft:cobbled_deepslate
setblock 48 241 594 minecraft:calcite
fill 48 241 595 48 244 595 minecraft:cobbled_deepslate
setblock 49 241 583 minecraft:calcite
fill 49 241 584 49 242 584 minecraft:cobbled_deepslate
setblock 49 241 588 minecraft:calcite
fill 49 241 589 49 244 589 minecraft:cobbled_deepslate
setblock 49 241 593 minecraft:calcite
fill 49 241 594 49 244 594 minecraft:cobbled_deepslate
fill 50 241 568 51 241 568 minecraft:light_blue_stained_glass
fill 50 241 570 51 241 570 minecraft:light_blue_stained_glass
setblock 50 241 587 minecraft:calcite
fill 50 241 588 50 243 588 minecraft:cobbled_deepslate
setblock 50 241 592 minecraft:calcite
setblock 52 241 569 minecraft:light_blue_stained_glass
setblock 53 241 598 minecraft:cobbled_deepslate
setblock 54 241 598 minecraft:calcite
fill 55 241 598 55 244 598 minecraft:cobbled_deepslate
setblock 59 241 558 minecraft:calcite
fill 66 241 593 66 242 593 minecraft:calcite
fill 66 241 595 66 242 595 minecraft:calcite
fill 68 241 593 68 242 593 minecraft:calcite
fill 68 241 595 68 242 595 minecraft:calcite
fill 70 241 558 73 241 558 minecraft:cobbled_deepslate
setblock 72 241 559 minecraft:cobbled_deepslate
fill 72 241 598 73 241 598 minecraft:cobbled_deepslate
setblock 73 241 559 minecraft:calcite
setblock 74 241 558 minecraft:calcite
fill 74 241 559 76 241 560 minecraft:cobbled_deepslate
setblock 74 241 597 minecraft:cobbled_deepslate
setblock 74 241 598 minecraft:calcite
fill 75 241 558 78 241 558 minecraft:cobbled_deepslate
setblock 75 241 597 minecraft:calcite
fill 75 241 598 78 241 598 minecraft:cobbled_deepslate
fill 76 241 597 76 244 597 minecraft:cobbled_deepslate
setblock 77 241 559 minecraft:cobbled_deepslate
setblock 77 241 560 minecraft:calcite
fill 77 241 596 79 242 596 minecraft:cobbled_deepslate
setblock 78 241 559 minecraft:calcite
setblock 78 241 560 minecraft:cobbled_deepslate
setblock 79 241 558 minecraft:calcite
fill 79 241 559 79 243 559 minecraft:cobbled_deepslate
setblock 79 241 598 minecraft:calcite
fill 80 241 558 80 244 558 minecraft:cobbled_deepslate
setblock 80 241 597 minecraft:calcite
fill 80 241 598 80 244 598 minecraft:cobbled_deepslate
fill 81 241 597 81 244 597 minecraft:cobbled_deepslate
fill 82 241 593 84 241 593 minecraft:light_blue_stained_glass
fill 83 241 592 83 242 592 minecraft:light_blue_stained_glass
fill 83 241 597 83 243 597 minecraft:light_blue_stained_glass
setblock 84 241 598 minecraft:calcite
fill 85 241 598 85 244 598 minecraft:cobbled_deepslate
setblock 87 241 589 minecraft:cobbled_deepslate
setblock 87 241 590 minecraft:calcite
fill 87 241 591 87 244 591 minecraft:cobbled_deepslate
setblock 88 241 565 minecraft:cobbled_deepslate
setblock 88 241 584 minecraft:calcite
fill 88 241 585 88 243 585 minecraft:cobbled_deepslate
setblock 88 241 589 minecraft:calcite
fill 88 241 590 88 244 590 minecraft:cobbled_deepslate
setblock 88 241 594 minecraft:calcite
fill 88 241 595 88 244 595 minecraft:cobbled_deepslate
setblock 48 242 567 minecraft:cobbled_deepslate
setblock 48 242 568 minecraft:calcite
fill 48 242 569 48 245 569 minecraft:cobbled_deepslate
setblock 48 242 573 minecraft:calcite
setblock 48 242 583 minecraft:calcite
fill 48 242 584 48 245 584 minecraft:cobbled_deepslate
setblock 48 242 588 minecraft:calcite
fill 48 242 589 48 245 589 minecraft:cobbled_deepslate
setblock 48 242 593 minecraft:calcite
fill 48 242 594 48 245 594 minecraft:cobbled_deepslate
setblock 49 242 587 minecraft:calcite
fill 49 242 588 49 245 588 minecraft:cobbled_deepslate
setblock 49 242 592 minecraft:calcite
fill 49 242 593 49 245 593 minecraft:cobbled_deepslate
setblock 50 242 568 minecraft:light_blue_stained_glass
setblock 50 242 570 minecraft:light_blue_stained_glass
setblock 50 242 586 minecraft:calcite
fill 50 242 587 50 243 587 minecraft:cobbled_deepslate
setblock 50 242 591 minecraft:calcite
fill 50 242 592 50 244 592 minecraft:cobbled_deepslate
fill 50 242 596 50 250 596 minecraft:deepslate
setblock 52 242 598 minecraft:cobbled_deepslate
setblock 53 242 598 minecraft:calcite
fill 54 242 598 54 245 598 minecraft:cobbled_deepslate
fill 70 242 558 72 242 558 minecraft:cobbled_deepslate
setblock 72 242 559 minecraft:calcite
setblock 72 242 598 minecraft:cobbled_deepslate
setblock 73 242 558 minecraft:calcite
fill 73 242 559 76 242 559 minecraft:cobbled_deepslate
setblock 73 242 598 minecraft:calcite
fill 74 242 558 77 242 558 minecraft:cobbled_deepslate
fill 74 242 560 75 242 560 minecraft:cobbled_deepslate
setblock 74 242 597 minecraft:calcite
fill 74 242 598 77 242 598 minecraft:cobbled_deepslate
fill 75 242 597 75 245 597 minecraft:cobbled_deepslate
setblock 76 242 560 minecraft:calcite
fill 76 242 596 76 245 596 minecraft:cobbled_deepslate
setblock 77 242 559 minecraft:calcite
setblock 77 242 560 minecraft:cobbled_deepslate
setblock 78 242 558 minecraft:calcite
fill 78 242 559 78 243 559 minecraft:cobbled_deepslate
setblock 78 242 598 minecraft:calcite
fill 79 242 558 79 245 558 minecraft:cobbled_deepslate
setblock 79 242 597 minecraft:calcite
fill 79 242 598 79 245 598 minecraft:cobbled_deepslate
fill 80 242 597 80 245 597 minecraft:cobbled_deepslate
setblock 83 242 593 minecraft:light_blue_stained_glass
setblock 83 242 598 minecraft:calcite
fill 84 242 598 84 245 598 minecraft:cobbled_deepslate
setblock 87 242 589 minecraft:calcite
fill 87 242 590 87 245 590 minecraft:cobbled_deepslate
setblock 87 242 594 minecraft:calcite
fill 87 242 595 87 245 595 minecraft:cobbled_deepslate
setblock 87 242 598 minecraft:cobbled_deepslate
setblock 88 242 588 minecraft:calcite
fill 88 242 589 88 245 589 minecraft:cobbled_deepslate
setblock 88 242 593 minecraft:calcite
fill 88 242 594 88 245 594 minecraft:cobbled_deepslate
setblock 88 242 598 minecraft:calcite
setblock 48 243 567 minecraft:calcite
fill 48 243 568 48 246 568 minecraft:cobbled_deepslate
fill 48 243 570 48 243 571 minecraft:cobbled_deepslate
setblock 48 243 572 minecraft:calcite
fill 48 243 573 48 244 575 minecraft:cobbled_deepslate
setblock 48 243 582 minecraft:calcite
fill 48 243 583 48 244 583 minecraft:cobbled_deepslate
setblock 48 243 587 minecraft:calcite
fill 48 243 588 48 246 588 minecraft:cobbled_deepslate
setblock 48 243 592 minecraft:calcite
fill 48 243 593 48 246 593 minecraft:cobbled_deepslate
setblock 49 243 569 minecraft:light_blue_stained_glass
setblock 49 243 570 minecraft:cobbled_deepslate
setblock 49 243 571 minecraft:calcite
setblock 49 243 586 minecraft:calcite
fill 49 243 587 49 245 587 minecraft:cobbled_deepslate
setblock 49 243 591 minecraft:calcite
fill 49 243 592 49 246 592 minecraft:cobbled_deepslate
setblock 50 243 590 minecraft:calcite
fill 50 243 591 50 245 591 minecraft:cobbled_deepslate
setblock 52 243 598 minecraft:calcite
fill 53 243 598 53 246 598 minecraft:cobbled_deepslate
fill 57 243 593 57 247 593 minecraft:calcite
setblock 57 243 598 minecraft:calcite
fill 70 243 558 71 243 558 minecraft:cobbled_deepslate
setblock 71 243 598 minecraft:cobbled_deepslate
setblock 72 243 558 minecraft:calcite
fill 72 243 559 75 243 559 minecraft:cobbled_deepslate
setblock 72 243 598 minecraft:calcite
fill 73 243 558 76 243 558 minecraft:cobbled_deepslate
setblock 73 243 597 minecraft:calcite
fill 73 243 598 76 243 598 minecraft:cobbled_deepslate
fill 74 243 597 74 246 597 minecraft:cobbled_deepslate
setblock 76 243 559 minecraft:calcite
setblock 77 243 558 minecraft:calcite
fill 77 243 559 77 244 559 minecraft:cobbled_deepslate
fill 77 243 596 78 243 596 minecraft:cobbled_deepslate
setblock 77 243 598 minecraft:calcite
fill 78 243 558 78 246 558 minecraft:cobbled_deepslate
setblock 78 243 597 minecraft:calcite
fill 78 243 598 78 246 598 minecraft:cobbled_deepslate
fill 79 243 597 79 246 597 minecraft:cobbled_deepslate
setblock 82 243 598 minecraft:calcite
fill 83 243 596 85 246 596 minecraft:deepslate
fill 83 243 598 83 246 598 minecraft:cobbled_deepslate
fill 84 243 595 84 246 595 minecraft:deepslate
fill 84 243 597 84 246 597 minecraft:deepslate
fill 86 243 584 87 248 586 minecraft:light_blue_stained_glass
setblock 87 243 588 minecraft:calcite
fill 87 243 589 87 245 589 minecraft:cobbled_deepslate
setblock 87 243 593 minecraft:calcite
fill 87 243 594 87 246 594 minecraft:cobbled_deepslate
setblock 87 243 598 minecraft:calcite
fill 88 243 584 88 248 584 minecraft:light_blue_stained_glass
setblock 88 243 587 minecraft:calcite
fill 88 243 588 88 246 588 minecraft:cobbled_deepslate
setblock 88 243 592 minecraft:calcite
fill 88 243 593 88 246 593 minecraft:cobbled_deepslate
setblock 88 243 597 minecraft:calcite
fill 88 243 598 88 246 598 minecraft:cobbled_deepslate
setblock 48 244 570 minecraft:cobbled_deepslate
setblock 48 244 571 minecraft:calcite
fill 48 244 572 49 246 572 minecraft:cobbled_deepslate
setblock 48 244 576 minecraft:calcite
setblock 48 244 586 minecraft:calcite
fill 48 244 587 48 247 587 minecraft:cobbled_deepslate
setblock 48 244 591 minecraft:calcite
fill 48 244 592 48 247 592 minecraft:cobbled_deepslate
setblock 48 244 596 minecraft:calcite
setblock 49 244 570 minecraft:calcite
fill 49 244 571 49 247 571 minecraft:cobbled_deepslate
fill 49 244 573 49 245 573 minecraft:cobbled_deepslate
setblock 49 244 586 minecraft:cobbled_deepslate
setblock 49 244 590 minecraft:calcite
fill 49 244 591 49 247 591 minecraft:cobbled_deepslate
setblock 50 244 589 minecraft:calcite
setblock 50 244 590 minecraft:cobbled_deepslate
fill 52 244 598 52 247 598 minecraft:cobbled_deepslate
setblock 56 244 598 minecraft:calcite
setblock 70 244 558 minecraft:cobbled_deepslate
setblock 71 244 558 minecraft:calcite
setblock 71 244 598 minecraft:calcite
fill 72 244 558 74 244 559 minecraft:cobbled_deepslate
setblock 72 244 597 minecraft:calcite
fill 72 244 598 75 244 598 minecraft:cobbled_deepslate
fill 73 244 597 73 247 597 minecraft:cobbled_deepslate
setblock 75 244 558 minecraft:cobbled_deepslate
setblock 75 244 559 minecraft:calcite
fill 75 244 596 75 246 596 minecraft:cobbled_deepslate
setblock 76 244 558 minecraft:calcite
fill 76 244 559 76 245 559 minecraft:cobbled_deepslate
setblock 76 244 598 minecraft:calcite
fill 77 244 558 77 247 558 minecraft:cobbled_deepslate
setblock 77 244 596 minecraft:cobbled_deepslate
setblock 77 244 597 minecraft:calcite
fill 77 244 598 77 247 598 minecraft:cobbled_deepslate
setblock 78 244 596 minecraft:calcite
fill 78 244 597 78 247 597 minecraft:cobbled_deepslate
setblock 81 244 598 minecraft:calcite
fill 82 244 598 82 247 598 minecraft:cobbled_deepslate
fill 85 244 584 85 248 586 minecraft:light_blue_stained_glass
fill 86 244 583 88 247 583 minecraft:light_blue_stained_glass
fill 86 244 587 87 247 587 minecraft:light_blue_stained_glass
setblock 86 244 598 minecraft:calcite
setblock 87 244 592 minecraft:calcite
fill 87 244 593 87 247 593 minecraft:cobbled_deepslate
fill 87 244 598 87 247 598 minecraft:cobbled_deepslate
fill 88 244 585 88 248 585 minecraft:light_blue_stained_glass
setblock 88 244 586 minecraft:calcite
fill 88 244 587 88 247 587 minecraft:cobbled_deepslate
setblock 88 244 591 minecraft:calcite
fill 88 244 592 88 247 592 minecraft:cobbled_deepslate
setblock 88 244 596 minecraft:calcite
fill 88 244 597 88 247 597 minecraft:cobbled_deepslate
setblock 48 245 570 minecraft:calcite
fill 48 245 571 48 248 571 minecraft:cobbled_deepslate
fill 48 245 573 48 245 574 minecraft:cobbled_deepslate
setblock 48 245 575 minecraft:calcite
fill 48 245 576 48 246 578 minecraft:cobbled_deepslate
setblock 48 245 585 minecraft:calcite
fill 48 245 586 48 248 586 minecraft:cobbled_deepslate
setblock 48 245 590 minecraft:calcite
fill 48 245 591 48 248 591 minecraft:cobbled_deepslate
setblock 48 245 595 minecraft:calcite
fill 48 245 596 48 248 596 minecraft:cobbled_deepslate
fill 49 245 570 49 248 570 minecraft:cobbled_deepslate
setblock 49 245 574 minecraft:calcite
fill 49 245 575 49 248 575 minecraft:cobbled_deepslate
setblock 49 245 589 minecraft:calcite
fill 49 245 590 49 248 590 minecraft:cobbled_deepslate
setblock 49 245 594 minecraft:calcite
fill 51 245 598 51 248 598 minecraft:cobbled_deepslate
setblock 55 245 598 minecraft:calcite
setblock 69 245 558 minecraft:cobbled_deepslate
setblock 70 245 558 minecraft:calcite
setblock 70 245 598 minecraft:calcite
fill 71 245 558 74 245 558 minecraft:cobbled_deepslate
fill 71 245 598 74 245 598 minecraft:cobbled_deepslate
fill 72 245 559 73 245 559 minecraft:cobbled_deepslate
fill 72 245 597 72 248 597 minecraft:cobbled_deepslate
setblock 74 245 559 minecraft:calcite
fill 74 245 596 74 247 596 minecraft:cobbled_deepslate
setblock 75 245 558 minecraft:calcite
fill 75 245 559 75 248 559 minecraft:cobbled_deepslate
setblock 75 245 598 minecraft:calcite
fill 76 245 558 76 248 558 minecraft:cobbled_deepslate
setblock 76 245 597 minecraft:calcite
fill 76 245 598 76 248 598 minecraft:cobbled_deepslate
setblock 77 245 596 minecraft:calcite
fill 77 245 597 77 248 597 minecraft:cobbled_deepslate
setblock 80 245 598 minecraft:calcite
fill 81 245 598 81 248 598 minecraft:cobbled_deepslate
fill 83 245 595 83 246 595 minecraft:deepslate
fill 83 245 597 83 246 597 minecraft:deepslate
fill 84 245 584 84 248 586 minecraft:light_blue_stained_glass
fill 85 245 583 85 247 583 minecraft:light_blue_stained_glass
fill 85 245 587 85 247 587 minecraft:light_blue_stained_glass
fill 85 245 595 85 246 595 minecraft:deepslate
fill 85 245 597 85 246 597 minecraft:deepslate
setblock 85 245 598 minecraft:calcite
fill 86 245 598 86 248 598 minecraft:cobbled_deepslate
setblock 87 245 591 minecraft:calcite
fill 87 245 592 87 248 592 minecraft:cobbled_deepslate
fill 88 245 586 88 248 586 minecraft:cobbled_deepslate
setblock 88 245 590 minecraft:calcite
fill 88 245 591 88 248 591 minecraft:cobbled_deepslate
setblock 88 245 595 minecraft:calcite
fill 88 245 596 88 248 596 minecraft:cobbled_deepslate
setblock 48 246 569 minecraft:calcite
fill 48 246 570 48 249 570 minecraft:cobbled_deepslate
setblock 48 246 573 minecraft:cobbled_deepslate
setblock 48 246 574 minecraft:calcite
fill 48 246 575 48 249 575 minecraft:cobbled_deepslate
setblock 48 246 579 minecraft:calcite
fill 48 246 580 48 249 580 minecraft:cobbled_deepslate
setblock 48 246 584 minecraft:calcite
fill 48 246 585 48 249 585 minecraft:cobbled_deepslate
setblock 48 246 589 minecraft:calcite
fill 48 246 590 48 249 590 minecraft:cobbled_deepslate
setblock 48 246 594 minecraft:calcite
fill 48 246 595 49 248 595 minecraft:cobbled_deepslate
fill 48 246 597 48 247 597 minecraft:cobbled_deepslate
setblock 49 246 573 minecraft:calcite
fill 49 246 574 49 249 574 minecraft:cobbled_deepslate
fill 49 246 576 49 247 576 minecraft:cobbled_deepslate
setblock 49 246 588 minecraft:calcite
fill 49 246 589 49 249 589 minecraft:cobbled_deepslate
setblock 49 246 593 minecraft:calcite
fill 49 246 594 49 249 594 minecraft:cobbled_deepslate
fill 49 246 596 49 247 596 minecraft:deepslate
setblock 50 246 572 minecraft:calcite
fill 50 246 573 50 249 573 minecraft:cobbled_deepslate
fill 50 246 595 50 250 595 minecraft:deepslate
fill 50 246 597 50 247 597 minecraft:deepslate
fill 50 246 598 50 249 598 minecraft:cobbled_deepslate
fill 51 246 596 51 250 596 minecraft:deepslate
setblock 54 246 598 minecraft:calcite
fill 55 246 598 55 249 598 minecraft:cobbled_deepslate
fill 56 246 593 56 247 593 minecraft:calcite
fill 57 246 592 57 247 592 minecraft:calcite
fill 57 246 594 57 247 594 minecraft:calcite
fill 58 246 593 58 247 593 minecraft:calcite
setblock 69 246 558 minecraft:calcite
setblock 69 246 598 minecraft:calcite
fill 70 246 558 73 246 558 minecraft:cobbled_deepslate
fill 70 246 598 73 246 598 minecraft:cobbled_deepslate
fill 71 246 597 71 249 597 minecraft:cobbled_deepslate
setblock 72 246 559 minecraft:cobbled_deepslate
setblock 73 246 559 minecraft:calcite
fill 73 246 596 73 248 596 minecraft:cobbled_deepslate
setblock 74 246 558 minecraft:calcite
fill 74 246 559 74 249 559 minecraft:cobbled_deepslate
setblock 74 246 598 minecraft:calcite
fill 75 246 558 75 249 558 minecraft:cobbled_deepslate
setblock 75 246 597 minecraft:calcite
fill 75 246 598 75 249 598 minecraft:cobbled_deepslate
setblock 76 246 596 minecraft:calcite
fill 76 246 597 76 249 597 minecraft:cobbled_deepslate
fill 77 246 596 77 249 596 minecraft:cobbled_deepslate
setblock 79 246 558 minecraft:calcite
setblock 79 246 598 minecraft:calcite
setblock 80 246 597 minecraft:calcite
fill 80 246 598 80 249 598 minecraft:cobbled_deepslate
fill 83 246 584 83 248 586 minecraft:light_blue_stained_glass
setblock 84 246 598 minecraft:calcite
fill 85 246 598 85 249 598 minecraft:cobbled_deepslate
setblock 87 246 590 minecraft:calcite
fill 87 246 591 87 249 591 minecraft:cobbled_deepslate
setblock 87 246 595 minecraft:calcite
fill 87 246 596 87 249 596 minecraft:cobbled_deepslate
setblock 88 246 589 minecraft:calcite
fill 88 246 590 88 249 590 minecraft:cobbled_deepslate
setblock 88 246 594 minecraft:calcite
fill 88 246 595 88 249 595 minecraft:cobbled_deepslate
setblock 48 247 568 minecraft:calcite
fill 48 247 569 49 249 569 minecraft:cobbled_deepslate
setblock 48 247 572 minecraft:cobbled_deepslate
setblock 48 247 573 minecraft:calcite
fill 48 247 574 48 250 574 minecraft:cobbled_deepslate
fill 48 247 576 48 247 577 minecraft:cobbled_deepslate
setblock 48 247 578 minecraft:calcite
fill 48 247 579 48 250 579 minecraft:cobbled_deepslate
fill 48 247 581 48 247 582 minecraft:cobbled_deepslate
setblock 48 247 583 minecraft:calcite
fill 48 247 584 48 250 584 minecraft:cobbled_deepslate
setblock 48 247 588 minecraft:calcite
fill 48 247 589 48 250 589 minecraft:cobbled_deepslate
setblock 48 247 593 minecraft:calcite
fill 48 247 594 48 250 594 minecraft:cobbled_deepslate
setblock 49 247 572 minecraft:calcite
fill 49 247 573 49 250 573 minecraft:cobbled_deepslate
setblock 49 247 577 minecraft:calcite
fill 49 247 578 49 250 578 minecraft:cobbled_deepslate
setblock 49 247 588 minecraft:cobbled_deepslate
setblock 49 247 592 minecraft:calcite
fill 49 247 593 49 250 593 minecraft:cobbled_deepslate
fill 49 247 598 49 250 598 minecraft:cobbled_deepslate
setblock 50 247 571 minecraft:calcite
fill 50 247 572 50 250 572 minecraft:cobbled_deepslate
fill 50 247 574 50 247 575 minecraft:cobbled_deepslate
setblock 50 247 576 minecraft:calcite
setblock 53 247 598 minecraft:calcite
fill 54 247 598 54 250 598 minecraft:cobbled_deepslate
setblock 56 247 592 minecraft:calcite
setblock 56 247 594 minecraft:calcite
setblock 58 247 592 minecraft:calcite
setblock 58 247 594 minecraft:calcite
setblock 68 247 558 minecraft:calcite
setblock 68 247 598 minecraft:calcite
fill 69 247 558 72 247 558 minecraft:cobbled_deepslate
fill 69 247 598 72 247 598 minecraft:cobbled_deepslate
fill 70 247 597 70 250 597 minecraft:cobbled_deepslate
setblock 71 247 559 minecraft:cobbled_deepslate
setblock 72 247 559 minecraft:calcite
fill 72 247 596 72 249 596 minecraft:cobbled_deepslate
setblock 73 247 558 minecraft:calcite
fill 73 247 559 73 250 559 minecraft:cobbled_deepslate
setblock 73 247 598 minecraft:calcite
fill 74 247 558 74 250 558 minecraft:cobbled_deepslate
setblock 74 247 597 minecraft:calcite
fill 74 247 598 74 250 598 minecraft:cobbled_deepslate
setblock 75 247 596 minecraft:calcite
fill 75 247 597 75 250 597 minecraft:cobbled_deepslate
fill 76 247 596 76 250 596 minecraft:cobbled_deepslate
setblock 78 247 558 minecraft:calcite
setblock 78 247 598 minecraft:calcite
setblock 79 247 597 minecraft:calcite
fill 79 247 598 79 250 598 minecraft:cobbled_deepslate
fill 80 247 597 80 250 597 minecraft:cobbled_deepslate
fill 81 247 585 82 248 585 minecraft:light_blue_stained_glass
fill 82 247 584 82 248 584 minecraft:light_blue_stained_glass
fill 82 247 586 82 248 586 minecraft:light_blue_stained_glass
setblock 83 247 598 minecraft:calcite
fill 84 247 598 84 250 598 minecraft:cobbled_deepslate
fill 87 247 590 87 250 590 minecraft:cobbled_deepslate
setblock 87 247 594 minecraft:calcite
fill 87 247 595 87 250 595 minecraft:cobbled_deepslate
fill 87 247 597 87 248 597 minecraft:cobbled_deepslate
setblock 88 247 572 minecraft:cobbled_deepslate
setblock 88 247 573 minecraft:calcite
fill 88 247 574 88 249 575 minecraft:cobbled_deepslate
setblock 88 247 588 minecraft:calcite
fill 88 247 589 88 250 589 minecraft:cobbled_deepslate
setblock 88 247 593 minecraft:calcite
fill 88 247 594 88 250 594 minecraft:cobbled_deepslate
setblock 88 247 598 minecraft:calcite
fill 48 248 568 48 251 568 minecraft:cobbled_deepslate
setblock 48 248 572 minecraft:calcite
fill 48 248 573 48 251 573 minecraft:cobbled_deepslate
setblock 48 248 576 minecraft:cobbled_deepslate
setblock 48 248 577 minecraft:calcite
fill 48 248 578 48 251 578 minecraft:cobbled_deepslate
setblock 48 248 581 minecraft:cobbled_deepslate
setblock 48 248 582 minecraft:calcite
fill 48 248 583 48 251 583 minecraft:cobbled_deepslate
setblock 48 248 587 minecraft:calcite
fill 48 248 588 48 251 588 minecraft:cobbled_deepslate
setblock 48 248 592 minecraft:calcite
fill 48 248 593 48 251 593 minecraft:cobbled_deepslate
setblock 48 248 597 minecraft:calcite
fill 48 248 598 48 251 598 minecraft:cobbled_deepslate
setblock 49 248 571 minecraft:calcite
fill 49 248 572 49 251 572 minecraft:cobbled_deepslate
setblock 49 248 576 minecraft:calcite
fill 49 248 577 50 250 577 minecraft:cobbled_deepslate
fill 49 248 579 49 248 580 minecraft:cobbled_deepslate
setblock 49 248 591 minecraft:calcite
fill 49 248 592 49 251 592 minecraft:cobbled_deepslate
setblock 49 248 596 minecraft:calcite
setblock 49 248 597 minecraft:deepslate
setblock 50 248 560 minecraft:light[level=14]
setblock 50 248 568 minecraft:light[level=14]
fill 50 248 571 50 251 571 minecraft:cobbled_deepslate
setblock 50 248 574 minecraft:cobbled_deepslate
setblock 50 248 575 minecraft:calcite
fill 50 248 576 50 251 576 minecraft:cobbled_deepslate
setblock 50 248 584 minecraft:light[level=14]
setblock 50 248 592 minecraft:light[level=14]
schedule function dropper:buildpart/133_9 1t
