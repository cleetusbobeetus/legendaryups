setblock 237 180 552 minecraft:white_concrete
fill 239 180 510 239 182 510 minecraft:purple_concrete
fill 249 180 552 249 182 552 minecraft:purple_concrete
fill 255 180 510 255 182 510 minecraft:purple_concrete
fill 259 180 548 259 181 551 minecraft:amethyst_block
fill 260 180 546 260 181 549 minecraft:amethyst_block
fill 260 180 551 261 181 551 minecraft:amethyst_block
fill 261 180 548 261 181 550 minecraft:amethyst_block
setblock 264 180 514 minecraft:bone_block
fill 265 180 515 265 181 515 minecraft:bone_block
fill 265 180 552 265 182 552 minecraft:purple_concrete
fill 268 180 526 268 183 527 minecraft:bone_block
fill 269 180 525 270 185 525 minecraft:bone_block
fill 270 180 531 271 180 531 minecraft:bone_block
fill 271 180 510 271 182 510 minecraft:purple_concrete
fill 273 180 540 276 183 542 minecraft:amethyst_block
fill 274 180 528 275 181 528 minecraft:bone_block
fill 277 180 520 277 182 520 minecraft:purple_concrete
fill 277 180 536 277 182 536 minecraft:purple_concrete
setblock 277 180 540 minecraft:crying_obsidian
fill 277 180 541 277 231 541 minecraft:black_concrete
fill 235 181 531 235 198 532 minecraft:black_concrete
setblock 235 181 533 minecraft:white_concrete
fill 237 181 552 237 221 552 minecraft:black_concrete
setblock 241 181 510 minecraft:white_concrete
setblock 252 181 510 minecraft:amethyst_block
fill 254 181 511 256 184 512 minecraft:amethyst_block
setblock 259 181 547 minecraft:amethyst_block
fill 260 181 543 260 181 545 minecraft:amethyst_block
setblock 261 181 547 minecraft:amethyst_block
fill 263 181 510 263 198 510 minecraft:black_concrete
setblock 264 181 510 minecraft:crying_obsidian
fill 265 181 510 266 197 510 minecraft:black_concrete
fill 265 181 516 266 181 516 minecraft:bone_block
setblock 266 181 515 minecraft:bone_block
fill 266 181 517 266 182 517 minecraft:bone_block
fill 268 181 525 268 186 525 minecraft:bone_block
fill 268 181 528 268 182 528 minecraft:bone_block
fill 269 181 524 270 186 524 minecraft:bone_block
fill 270 181 541 272 183 541 minecraft:amethyst_block
fill 271 181 525 271 184 525 minecraft:bone_block
fill 271 181 540 272 182 540 minecraft:amethyst_block
fill 271 181 542 272 182 542 minecraft:amethyst_block
fill 272 181 526 272 183 526 minecraft:bone_block
fill 273 181 527 273 181 528 minecraft:bone_block
setblock 274 181 527 minecraft:bone_block
fill 274 181 539 276 182 539 minecraft:amethyst_block
fill 274 181 543 276 182 543 minecraft:amethyst_block
setblock 277 181 514 minecraft:white_concrete
fill 277 181 528 277 239 528 minecraft:black_concrete
setblock 277 181 529 minecraft:white_concrete
fill 277 181 540 277 190 540 minecraft:black_concrete
fill 235 182 533 235 307 533 minecraft:black_concrete
fill 241 182 510 241 307 510 minecraft:black_concrete
fill 252 182 510 252 200 510 minecraft:black_concrete
fill 253 182 511 253 183 512 minecraft:amethyst_block
fill 254 182 513 256 184 513 minecraft:amethyst_block
fill 255 182 514 255 184 514 minecraft:amethyst_block
fill 257 182 511 257 183 512 minecraft:amethyst_block
fill 264 182 510 264 185 510 minecraft:black_concrete
setblock 265 182 517 minecraft:bone_block
setblock 266 182 516 minecraft:bone_block
fill 266 182 518 266 183 518 minecraft:bone_block
fill 267 182 525 267 186 525 minecraft:bone_block
fill 268 182 523 268 187 524 minecraft:bone_block
fill 268 182 541 269 182 541 minecraft:amethyst_block
fill 269 182 523 270 186 523 minecraft:bone_block
fill 269 182 540 270 182 540 minecraft:amethyst_block
fill 269 182 542 270 182 542 minecraft:amethyst_block
fill 271 182 524 271 184 524 minecraft:bone_block
fill 273 182 526 273 182 527 minecraft:bone_block
fill 277 182 514 277 266 514 minecraft:black_concrete
fill 277 182 529 277 224 529 minecraft:black_concrete
setblock 235 183 518 minecraft:black_concrete
fill 235 183 534 235 187 534 minecraft:black_concrete
fill 235 183 550 235 188 550 minecraft:black_concrete
fill 239 183 510 239 188 510 minecraft:black_concrete
fill 249 183 552 249 188 552 minecraft:black_concrete
setblock 254 183 514 minecraft:amethyst_block
fill 255 183 510 255 188 510 minecraft:black_concrete
setblock 255 183 515 minecraft:amethyst_block
setblock 256 183 514 minecraft:amethyst_block
fill 259 183 514 259 184 515 minecraft:amethyst_block
fill 260 183 514 260 184 514 minecraft:amethyst_block
fill 265 183 552 265 188 552 minecraft:black_concrete
fill 266 183 519 267 183 519 minecraft:bone_block
setblock 267 183 518 minecraft:bone_block
fill 267 183 520 267 184 520 minecraft:bone_block
fill 267 183 523 267 187 524 minecraft:bone_block
setblock 267 183 526 minecraft:bone_block
fill 268 183 522 269 188 522 minecraft:bone_block
setblock 269 183 541 minecraft:amethyst_block
setblock 270 183 528 minecraft:bone_block
fill 271 183 510 271 188 510 minecraft:black_concrete
setblock 272 183 525 minecraft:bone_block
setblock 272 183 540 minecraft:amethyst_block
setblock 272 183 542 minecraft:amethyst_block
fill 277 183 520 277 188 520 minecraft:black_concrete
setblock 277 183 521 minecraft:white_concrete
fill 277 183 536 277 188 536 minecraft:black_concrete
setblock 235 184 518 minecraft:amethyst_block
fill 266 184 523 266 188 523 minecraft:bone_block
setblock 267 184 519 minecraft:bone_block
fill 267 184 521 267 189 522 minecraft:bone_block
fill 268 184 521 268 189 521 minecraft:bone_block
fill 268 184 526 268 185 526 minecraft:bone_block
fill 270 184 522 270 186 522 minecraft:bone_block
setblock 270 184 527 minecraft:bone_block
fill 277 184 521 277 234 521 minecraft:black_concrete
setblock 277 184 535 minecraft:crying_obsidian
setblock 277 184 546 minecraft:crying_obsidian
fill 277 184 547 277 196 548 minecraft:black_concrete
fill 235 185 518 235 188 518 minecraft:black_concrete
setblock 235 185 539 minecraft:amethyst_block
fill 239 185 552 239 207 552 minecraft:black_concrete
setblock 240 185 552 minecraft:white_concrete
setblock 245 185 510 minecraft:crying_obsidian
fill 246 185 510 246 222 510 minecraft:black_concrete
fill 264 185 519 265 186 519 minecraft:obsidian
fill 266 185 521 266 190 522 minecraft:bone_block
fill 266 185 524 266 186 524 minecraft:bone_block
fill 269 185 521 269 187 521 minecraft:bone_block
fill 269 185 526 270 185 526 minecraft:bone_block
fill 277 185 523 277 194 524 minecraft:black_concrete
setblock 277 185 525 minecraft:amethyst_block
setblock 277 185 533 minecraft:amethyst_block
fill 277 185 535 277 254 535 minecraft:black_concrete
fill 277 185 546 277 212 546 minecraft:black_concrete
fill 235 186 539 235 280 539 minecraft:black_concrete
fill 240 186 541 241 187 542 minecraft:obsidian
fill 240 186 552 240 233 552 minecraft:black_concrete
fill 245 186 510 245 211 510 minecraft:black_concrete
fill 254 186 521 255 187 522 minecraft:amethyst_block
fill 263 186 541 264 187 542 minecraft:white_concrete
setblock 264 186 510 minecraft:crying_obsidian
fill 265 186 520 265 190 522 minecraft:bone_block
fill 266 186 520 268 189 520 minecraft:bone_block
setblock 269 186 525 minecraft:bone_block
fill 277 186 525 277 208 525 minecraft:black_concrete
fill 277 186 533 277 307 533 minecraft:black_concrete
setblock 238 187 513 minecraft:light[level=12]
setblock 238 187 521 minecraft:light[level=12]
setblock 238 187 529 minecraft:light[level=12]
setblock 238 187 537 minecraft:light[level=12]
setblock 238 187 545 minecraft:light[level=12]
setblock 246 187 513 minecraft:light[level=12]
setblock 246 187 521 minecraft:light[level=12]
setblock 246 187 529 minecraft:light[level=12]
setblock 246 187 537 minecraft:light[level=12]
setblock 246 187 545 minecraft:light[level=12]
setblock 254 187 513 minecraft:light[level=12]
setblock 254 187 529 minecraft:light[level=12]
setblock 254 187 537 minecraft:light[level=12]
setblock 254 187 545 minecraft:light[level=12]
setblock 262 187 513 minecraft:light[level=12]
setblock 262 187 521 minecraft:light[level=12]
setblock 262 187 529 minecraft:light[level=12]
setblock 262 187 537 minecraft:light[level=12]
setblock 262 187 545 minecraft:light[level=12]
fill 264 187 510 264 248 510 minecraft:black_concrete
fill 264 187 520 264 191 521 minecraft:bone_block
fill 265 187 519 267 190 519 minecraft:bone_block
setblock 265 187 523 minecraft:bone_block
fill 269 187 523 269 187 524 minecraft:bone_block
setblock 270 187 513 minecraft:light[level=12]
setblock 270 187 521 minecraft:light[level=12]
setblock 270 187 529 minecraft:light[level=12]
setblock 270 187 537 minecraft:light[level=12]
setblock 270 187 545 minecraft:light[level=12]
setblock 235 188 523 minecraft:white_concrete
fill 235 188 524 235 269 524 minecraft:black_concrete
setblock 235 188 525 minecraft:amethyst_block
setblock 235 188 534 minecraft:amethyst_block
setblock 235 188 545 minecraft:crying_obsidian
setblock 243 188 510 minecraft:amethyst_block
fill 244 188 510 244 232 510 minecraft:black_concrete
fill 252 188 512 253 188 512 minecraft:bone_block
setblock 253 188 511 minecraft:bone_block
fill 264 188 519 264 193 519 minecraft:bone_block
fill 265 188 518 266 191 518 minecraft:bone_block
fill 267 188 523 268 188 523 minecraft:bone_block
fill 269 188 518 271 188 518 minecraft:bone_block
setblock 270 188 517 minecraft:bone_block
fill 235 189 518 235 191 518 minecraft:purple_concrete
fill 235 189 523 235 263 523 minecraft:black_concrete
fill 235 189 525 235 231 525 minecraft:black_concrete
fill 235 189 534 235 191 534 minecraft:purple_concrete
fill 235 189 545 235 249 545 minecraft:black_concrete
fill 235 189 550 235 191 550 minecraft:purple_concrete
fill 239 189 510 239 191 510 minecraft:purple_concrete
fill 243 189 510 243 191 510 minecraft:black_concrete
fill 249 189 552 249 191 552 minecraft:purple_concrete
setblock 253 189 510 minecraft:white_concrete
fill 253 189 512 254 189 513 minecraft:bone_block
fill 255 189 510 255 191 510 minecraft:purple_concrete
fill 255 189 513 255 190 513 minecraft:bone_block
setblock 261 189 552 minecraft:crying_obsidian
fill 262 189 552 264 193 552 minecraft:black_concrete
fill 263 189 518 263 191 521 minecraft:bone_block
fill 264 189 518 264 194 518 minecraft:bone_block
fill 265 189 552 265 191 552 minecraft:purple_concrete
fill 268 189 517 269 189 518 minecraft:bone_block
setblock 268 189 522 minecraft:bone_block
setblock 270 189 518 minecraft:bone_block
fill 271 189 510 271 191 510 minecraft:purple_concrete
fill 277 189 520 277 191 520 minecraft:purple_concrete
fill 277 189 536 277 191 536 minecraft:purple_concrete
setblock 235 190 519 minecraft:crying_obsidian
setblock 235 190 520 minecraft:white_concrete
setblock 235 190 526 minecraft:crying_obsidian
fill 253 190 510 253 239 510 minecraft:black_concrete
setblock 254 190 513 minecraft:bone_block
fill 255 190 514 256 190 514 minecraft:bone_block
fill 261 190 552 261 263 552 minecraft:black_concrete
fill 262 190 517 262 193 520 minecraft:bone_block
fill 263 190 517 268 190 517 minecraft:bone_block
fill 266 190 520 267 190 520 minecraft:bone_block
fill 267 190 518 268 190 518 minecraft:bone_block
setblock 267 190 521 minecraft:bone_block
fill 235 191 519 235 227 520 minecraft:black_concrete
fill 235 191 526 235 283 526 minecraft:black_concrete
fill 235 191 546 235 217 546 minecraft:black_concrete
setblock 235 191 547 minecraft:crying_obsidian
fill 256 191 514 257 191 515 minecraft:bone_block
fill 256 191 552 256 220 552 minecraft:black_concrete
setblock 257 191 552 minecraft:white_concrete
fill 258 191 515 258 192 515 minecraft:bone_block
fill 258 191 552 258 209 552 minecraft:black_concrete
fill 261 191 517 261 195 519 minecraft:bone_block
fill 263 191 517 266 191 517 minecraft:bone_block
fill 265 191 519 266 191 521 minecraft:bone_block
setblock 267 191 518 minecraft:bone_block
setblock 277 191 530 minecraft:crying_obsidian
setblock 277 191 540 minecraft:white_concrete
fill 235 192 518 235 197 518 minecraft:black_concrete
fill 235 192 534 235 197 534 minecraft:black_concrete
fill 235 192 547 235 209 547 minecraft:black_concrete
fill 235 192 550 235 197 550 minecraft:black_concrete
setblock 236 192 510 minecraft:white_concrete
fill 237 192 510 239 197 510 minecraft:black_concrete
fill 242 192 542 243 193 542 minecraft:amethyst_block
setblock 243 192 510 minecraft:amethyst_block
fill 243 192 541 243 193 541 minecraft:amethyst_block
fill 249 192 552 249 197 552 minecraft:black_concrete
fill 255 192 510 255 197 510 minecraft:black_concrete
setblock 257 192 515 minecraft:bone_block
fill 257 192 552 257 201 552 minecraft:black_concrete
fill 258 192 516 259 198 516 minecraft:bone_block
fill 260 192 517 260 196 519 minecraft:bone_block
fill 261 192 516 263 194 516 minecraft:bone_block
fill 261 192 520 261 193 520 minecraft:bone_block
fill 263 192 517 263 193 520 minecraft:bone_block
fill 264 192 517 265 192 517 minecraft:bone_block
fill 264 192 520 265 192 520 minecraft:bone_block
fill 265 192 518 265 193 519 minecraft:bone_block
fill 265 192 552 265 197 552 minecraft:black_concrete
fill 271 192 510 271 197 510 minecraft:black_concrete
setblock 277 192 517 minecraft:crying_obsidian
fill 277 192 520 277 197 520 minecraft:black_concrete
setblock 277 192 526 minecraft:amethyst_block
fill 277 192 530 277 260 530 minecraft:black_concrete
fill 277 192 536 277 197 536 minecraft:black_concrete
fill 277 192 540 277 238 540 minecraft:black_concrete
fill 236 193 510 236 248 510 minecraft:black_concrete
fill 243 193 510 243 307 510 minecraft:black_concrete
fill 259 193 517 259 198 518 minecraft:bone_block
fill 260 193 516 260 197 516 minecraft:bone_block
setblock 264 193 517 minecraft:bone_block
setblock 264 193 520 minecraft:bone_block
setblock 269 193 552 minecraft:crying_obsidian
fill 270 193 552 270 227 552 minecraft:black_concrete
fill 272 193 552 273 193 552 minecraft:black_concrete
setblock 274 193 552 minecraft:crying_obsidian
fill 277 193 517 277 235 517 minecraft:black_concrete
fill 277 193 526 277 200 526 minecraft:black_concrete
setblock 277 193 549 minecraft:white_concrete
fill 254 194 544 255 195 546 minecraft:obsidian
fill 258 194 517 258 199 518 minecraft:bone_block
fill 259 194 515 261 195 515 minecraft:bone_block
fill 259 194 519 259 196 519 minecraft:bone_block
fill 262 194 517 263 194 519 minecraft:bone_block
fill 262 194 552 262 224 552 minecraft:black_concrete
setblock 263 194 552 minecraft:crying_obsidian
fill 264 194 552 264 211 552 minecraft:black_concrete
fill 269 194 552 269 288 552 minecraft:black_concrete
setblock 272 194 552 minecraft:crying_obsidian
fill 273 194 552 274 212 552 minecraft:black_concrete
setblock 277 194 537 minecraft:white_concrete
fill 277 194 538 277 307 538 minecraft:black_concrete
fill 277 194 549 277 214 549 minecraft:black_concrete
setblock 238 195 513 minecraft:light[level=12]
setblock 238 195 521 minecraft:light[level=12]
setblock 238 195 529 minecraft:light[level=12]
setblock 238 195 537 minecraft:light[level=12]
setblock 238 195 545 minecraft:light[level=12]
setblock 246 195 513 minecraft:light[level=12]
setblock 246 195 521 minecraft:light[level=12]
setblock 246 195 529 minecraft:light[level=12]
setblock 246 195 537 minecraft:light[level=12]
setblock 246 195 545 minecraft:light[level=12]
setblock 254 195 513 minecraft:light[level=12]
setblock 254 195 521 minecraft:light[level=12]
setblock 254 195 529 minecraft:light[level=12]
setblock 254 195 537 minecraft:light[level=12]
setblock 254 195 552 minecraft:white_concrete
fill 257 195 516 257 200 518 minecraft:bone_block
fill 258 195 515 258 199 515 minecraft:bone_block
fill 261 195 516 262 195 516 minecraft:bone_block
setblock 262 195 513 minecraft:light[level=12]
fill 262 195 517 262 195 519 minecraft:bone_block
setblock 262 195 521 minecraft:light[level=12]
setblock 262 195 529 minecraft:light[level=12]
setblock 262 195 537 minecraft:light[level=12]
setblock 262 195 545 minecraft:light[level=12]
fill 263 195 517 263 195 518 minecraft:bone_block
fill 263 195 552 263 270 552 minecraft:black_concrete
setblock 270 195 513 minecraft:light[level=12]
setblock 270 195 521 minecraft:light[level=12]
setblock 270 195 529 minecraft:light[level=12]
setblock 270 195 537 minecraft:light[level=12]
setblock 270 195 545 minecraft:light[level=12]
fill 272 195 552 272 307 552 minecraft:black_concrete
fill 277 195 523 277 307 523 minecraft:black_concrete
setblock 277 195 524 minecraft:amethyst_block
fill 277 195 537 277 206 537 minecraft:black_concrete
fill 242 196 517 242 197 518 minecraft:bone_block
setblock 249 196 510 minecraft:crying_obsidian
fill 250 196 510 250 224 510 minecraft:black_concrete
fill 254 196 552 254 204 552 minecraft:black_concrete
fill 256 196 516 256 201 518 minecraft:bone_block
fill 257 196 515 257 200 515 minecraft:bone_block
fill 258 196 519 258 197 519 minecraft:bone_block
fill 259 196 515 260 196 515 minecraft:bone_block
fill 260 196 512 260 197 512 minecraft:bone_block
fill 261 196 516 261 196 518 minecraft:bone_block
setblock 262 196 517 minecraft:bone_block
setblock 267 196 552 minecraft:amethyst_block
fill 277 196 524 277 286 524 minecraft:black_concrete
setblock 235 197 537 minecraft:white_concrete
fill 243 197 517 243 198 518 minecraft:bone_block
fill 244 197 517 244 198 517 minecraft:bone_block
fill 249 197 510 249 253 510 minecraft:black_concrete
setblock 254 197 510 minecraft:amethyst_block
fill 255 197 516 255 202 518 minecraft:bone_block
fill 256 197 515 256 201 515 minecraft:bone_block
fill 258 197 513 259 198 513 minecraft:bone_block
fill 259 197 512 259 198 512 minecraft:bone_block
fill 259 197 515 259 198 515 minecraft:bone_block
fill 260 197 517 260 197 518 minecraft:bone_block
setblock 261 197 517 minecraft:bone_block
fill 267 197 552 267 234 552 minecraft:black_concrete
setblock 277 197 547 minecraft:white_concrete
fill 277 197 548 277 212 548 minecraft:black_concrete
fill 235 198 518 235 200 518 minecraft:purple_concrete
fill 235 198 534 235 200 534 minecraft:purple_concrete
fill 235 198 537 235 205 537 minecraft:black_concrete
fill 235 198 550 235 200 550 minecraft:purple_concrete
setblock 237 198 510 minecraft:crying_obsidian
fill 238 198 510 238 256 510 minecraft:black_concrete
fill 239 198 510 239 200 510 minecraft:purple_concrete
fill 244 198 518 245 198 518 minecraft:bone_block
setblock 244 198 552 minecraft:white_concrete
fill 245 198 517 245 199 517 minecraft:bone_block
fill 249 198 552 249 200 552 minecraft:purple_concrete
setblock 253 198 552 minecraft:amethyst_block
fill 254 198 510 254 205 510 minecraft:black_concrete
fill 254 198 515 254 202 518 minecraft:bone_block
fill 255 198 510 255 200 510 minecraft:purple_concrete
fill 255 198 515 255 201 515 minecraft:bone_block
setblock 257 198 510 minecraft:crying_obsidian
fill 257 198 513 257 199 514 minecraft:bone_block
setblock 258 198 514 minecraft:bone_block
setblock 260 198 517 minecraft:bone_block
setblock 265 198 510 minecraft:amethyst_block
fill 265 198 552 265 200 552 minecraft:purple_concrete
fill 266 198 510 266 239 510 minecraft:black_concrete
fill 271 198 510 271 200 510 minecraft:purple_concrete
setblock 276 198 552 minecraft:white_concrete
fill 277 198 520 277 200 520 minecraft:purple_concrete
fill 277 198 536 277 200 536 minecraft:purple_concrete
fill 277 198 547 277 233 547 minecraft:black_concrete
fill 277 198 552 277 307 552 minecraft:black_concrete
setblock 235 199 531 minecraft:crying_obsidian
fill 235 199 532 235 297 532 minecraft:black_concrete
setblock 235 199 538 minecraft:crying_obsidian
fill 236 199 536 237 202 538 minecraft:amethyst_block
fill 237 199 510 237 286 510 minecraft:black_concrete
fill 244 199 552 244 219 552 minecraft:black_concrete
fill 245 199 518 246 199 518 minecraft:bone_block
fill 246 199 517 247 200 517 minecraft:bone_block
setblock 251 199 510 minecraft:crying_obsidian
fill 253 199 515 253 203 518 minecraft:bone_block
fill 253 199 552 253 225 552 minecraft:black_concrete
setblock 256 199 510 minecraft:white_concrete
fill 256 199 514 256 200 514 minecraft:bone_block
fill 257 199 510 257 206 510 minecraft:black_concrete
setblock 258 199 513 minecraft:bone_block
setblock 258 199 516 minecraft:bone_block
setblock 263 199 510 minecraft:crying_obsidian
fill 265 199 510 265 307 510 minecraft:black_concrete
fill 276 199 552 276 216 552 minecraft:black_concrete
fill 277 199 511 277 244 511 minecraft:black_concrete
setblock 277 199 512 minecraft:white_concrete
fill 277 199 513 277 307 513 minecraft:black_concrete
fill 235 200 531 235 251 531 minecraft:black_concrete
fill 235 200 538 235 255 538 minecraft:black_concrete
fill 236 200 535 236 201 535 minecraft:amethyst_block
fill 236 200 539 236 201 539 minecraft:amethyst_block
fill 238 200 536 238 202 538 minecraft:amethyst_block
fill 245 200 552 246 229 552 minecraft:black_concrete
fill 247 200 518 248 200 518 minecraft:bone_block
setblock 247 200 552 minecraft:white_concrete
fill 248 200 517 249 201 517 minecraft:bone_block
fill 248 200 552 248 307 552 minecraft:black_concrete
fill 251 200 510 251 220 510 minecraft:black_concrete
fill 251 200 517 252 205 517 minecraft:bone_block
fill 252 200 516 252 204 516 minecraft:bone_block
fill 252 200 518 252 205 518 minecraft:bone_block
fill 254 200 519 254 201 519 minecraft:bone_block
setblock 255 200 514 minecraft:bone_block
fill 256 200 510 256 214 510 minecraft:black_concrete
setblock 260 200 552 minecraft:amethyst_block
fill 263 200 510 263 307 510 minecraft:black_concrete
fill 277 200 512 277 265 512 minecraft:black_concrete
setblock 277 200 532 minecraft:amethyst_block
fill 235 201 518 235 206 518 minecraft:black_concrete
fill 235 201 534 235 206 534 minecraft:black_concrete
fill 235 201 550 235 206 550 minecraft:black_concrete
fill 239 201 510 239 205 510 minecraft:black_concrete
fill 239 201 536 239 202 538 minecraft:amethyst_block
fill 247 201 552 247 264 552 minecraft:black_concrete
setblock 249 201 518 minecraft:bone_block
fill 249 201 552 249 206 552 minecraft:black_concrete
fill 250 201 517 250 207 517 minecraft:bone_block
fill 251 201 516 251 205 516 minecraft:bone_block
fill 251 201 518 251 206 518 minecraft:bone_block
setblock 252 201 510 minecraft:crying_obsidian
fill 252 201 515 252 203 515 minecraft:bone_block
fill 252 201 519 253 203 519 minecraft:bone_block
fill 255 201 510 255 206 510 minecraft:black_concrete
fill 260 201 552 260 204 552 minecraft:black_concrete
fill 265 201 552 265 206 552 minecraft:black_concrete
setblock 270 201 510 minecraft:white_concrete
fill 271 201 510 271 206 510 minecraft:black_concrete
fill 275 201 510 275 210 510 minecraft:black_concrete
setblock 276 201 510 minecraft:white_concrete
fill 277 201 520 277 206 520 minecraft:black_concrete
setblock 277 201 526 minecraft:white_concrete
fill 277 201 532 277 204 532 minecraft:black_concrete
fill 277 201 536 277 206 536 minecraft:black_concrete
fill 240 202 537 241 203 537 minecraft:amethyst_block
fill 249 202 517 249 207 517 minecraft:bone_block
fill 250 202 516 250 205 516 minecraft:bone_block
fill 250 202 518 250 207 519 minecraft:bone_block
fill 251 202 515 251 203 515 minecraft:bone_block
fill 251 202 519 251 206 519 minecraft:bone_block
fill 252 202 510 252 220 510 minecraft:black_concrete
setblock 257 202 552 minecraft:white_concrete
fill 270 202 510 270 232 510 minecraft:black_concrete
fill 270 202 523 271 203 523 minecraft:amethyst_block
fill 271 202 522 271 203 522 minecraft:amethyst_block
setblock 273 202 510 minecraft:white_concrete
fill 274 202 510 274 239 510 minecraft:black_concrete
fill 276 202 510 276 307 510 minecraft:black_concrete
fill 277 202 526 277 216 526 minecraft:black_concrete
setblock 238 203 513 minecraft:light[level=12]
setblock 238 203 521 minecraft:light[level=12]
setblock 238 203 529 minecraft:light[level=12]
setblock 238 203 537 minecraft:light[level=12]
setblock 238 203 545 minecraft:light[level=12]
setblock 239 203 537 minecraft:amethyst_block
setblock 246 203 513 minecraft:light[level=12]
setblock 246 203 521 minecraft:light[level=12]
setblock 246 203 529 minecraft:light[level=12]
setblock 246 203 537 minecraft:light[level=12]
setblock 246 203 545 minecraft:light[level=12]
fill 248 203 518 249 208 518 minecraft:bone_block
fill 249 203 519 249 208 519 minecraft:bone_block
setblock 254 203 513 minecraft:light[level=12]
fill 254 203 516 254 203 518 minecraft:bone_block
setblock 254 203 521 minecraft:light[level=12]
setblock 254 203 529 minecraft:light[level=12]
setblock 254 203 537 minecraft:light[level=12]
setblock 254 203 545 minecraft:light[level=12]
fill 257 203 552 257 212 552 minecraft:black_concrete
setblock 262 203 513 minecraft:light[level=12]
setblock 262 203 521 minecraft:light[level=12]
setblock 262 203 529 minecraft:light[level=12]
setblock 262 203 537 minecraft:light[level=12]
setblock 262 203 545 minecraft:light[level=12]
setblock 270 203 513 minecraft:light[level=12]
setblock 270 203 521 minecraft:light[level=12]
setblock 270 203 529 minecraft:light[level=12]
setblock 270 203 537 minecraft:light[level=12]
setblock 270 203 545 minecraft:light[level=12]
fill 273 203 510 273 214 510 minecraft:black_concrete
setblock 235 204 548 minecraft:crying_obsidian
fill 248 204 517 248 207 517 minecraft:bone_block
fill 248 204 519 248 209 520 minecraft:bone_block
fill 249 204 516 249 206 516 minecraft:bone_block
fill 249 204 520 251 205 520 minecraft:bone_block
fill 252 204 519 252 205 519 minecraft:bone_block
fill 253 204 516 253 204 518 minecraft:bone_block
fill 235 205 548 235 307 548 minecraft:black_concrete
fill 236 205 528 237 205 528 minecraft:bone_block
setblock 237 205 529 minecraft:bone_block
fill 247 205 514 248 206 514 minecraft:bone_block
fill 247 205 517 247 208 520 minecraft:bone_block
fill 248 205 513 248 206 513 minecraft:bone_block
setblock 254 205 552 minecraft:crying_obsidian
setblock 260 205 552 minecraft:white_concrete
setblock 277 205 532 minecraft:white_concrete
setblock 235 206 537 minecraft:white_concrete
fill 237 206 527 238 206 528 minecraft:bone_block
setblock 239 206 510 minecraft:amethyst_block
fill 239 206 527 239 207 527 minecraft:bone_block
fill 246 206 518 246 209 521 minecraft:bone_block
fill 247 206 515 247 207 516 minecraft:bone_block
fill 247 206 521 249 208 521 minecraft:bone_block
setblock 248 206 515 minecraft:bone_block
fill 249 206 520 250 207 520 minecraft:bone_block
setblock 251 206 517 minecraft:bone_block
setblock 254 206 510 minecraft:white_concrete
fill 254 206 552 254 220 552 minecraft:black_concrete
fill 260 206 552 260 256 552 minecraft:black_concrete
fill 277 206 532 277 268 532 minecraft:black_concrete
fill 235 207 518 235 209 518 minecraft:purple_concrete
fill 235 207 534 235 209 534 minecraft:purple_concrete
fill 235 207 537 235 223 537 minecraft:black_concrete
fill 235 207 550 235 209 550 minecraft:purple_concrete
setblock 238 207 527 minecraft:bone_block
fill 239 207 510 239 209 510 minecraft:purple_concrete
fill 239 207 526 240 208 526 minecraft:bone_block
fill 245 207 519 245 210 521 minecraft:bone_block
fill 246 207 516 246 207 517 minecraft:bone_block
fill 246 207 522 247 211 522 minecraft:bone_block
fill 249 207 552 249 209 552 minecraft:purple_concrete
fill 254 207 510 254 268 510 minecraft:black_concrete
fill 255 207 510 255 209 510 minecraft:purple_concrete
setblock 257 207 510 minecraft:white_concrete
fill 265 207 552 265 209 552 minecraft:purple_concrete
fill 271 207 510 271 209 510 minecraft:purple_concrete
fill 277 207 520 277 209 520 minecraft:purple_concrete
fill 277 207 536 277 209 536 minecraft:purple_concrete
setblock 277 207 537 minecraft:crying_obsidian
fill 235 208 512 235 295 512 minecraft:black_concrete
setblock 235 208 513 minecraft:crying_obsidian
fill 235 208 514 235 290 514 minecraft:black_concrete
setblock 239 208 552 minecraft:amethyst_block
fill 240 208 525 241 208 525 minecraft:bone_block
setblock 241 208 526 minecraft:bone_block
fill 244 208 520 244 211 522 minecraft:bone_block
fill 245 208 522 245 213 522 minecraft:bone_block
setblock 246 208 517 minecraft:bone_block
setblock 249 208 520 minecraft:bone_block
fill 257 208 510 257 211 510 minecraft:black_concrete
setblock 277 208 531 minecraft:amethyst_block
fill 277 208 537 277 307 537 minecraft:black_concrete
fill 235 209 513 235 218 513 minecraft:black_concrete
fill 239 209 552 239 242 552 minecraft:black_concrete
fill 241 209 524 242 209 525 minecraft:bone_block
fill 243 209 522 243 213 522 minecraft:bone_block
fill 244 209 523 246 213 523 minecraft:bone_block
fill 247 209 518 247 209 521 minecraft:bone_block
setblock 248 209 518 minecraft:bone_block
fill 248 209 521 248 210 521 minecraft:bone_block
setblock 277 209 525 minecraft:white_concrete
fill 277 209 531 277 307 531 minecraft:black_concrete
fill 235 210 518 235 219 518 minecraft:black_concrete
setblock 235 210 534 minecraft:black_concrete
setblock 235 210 547 minecraft:white_concrete
setblock 235 210 550 minecraft:black_concrete
fill 239 210 510 239 224 510 minecraft:black_concrete
fill 242 210 524 245 213 524 minecraft:bone_block
fill 243 210 521 243 212 521 minecraft:bone_block
fill 243 210 523 243 213 523 minecraft:bone_block
fill 246 210 519 247 210 521 minecraft:bone_block
setblock 247 210 523 minecraft:bone_block
setblock 248 210 520 minecraft:bone_block
fill 249 210 552 249 224 552 minecraft:black_concrete
fill 255 210 510 255 224 510 minecraft:black_concrete
setblock 258 210 552 minecraft:crying_obsidian
fill 265 210 552 265 222 552 minecraft:black_concrete
fill 271 210 510 271 224 510 minecraft:black_concrete
fill 277 210 520 277 224 520 minecraft:black_concrete
fill 277 210 525 277 229 525 minecraft:black_concrete
fill 277 210 536 277 224 536 minecraft:black_concrete
setblock 235 211 534 minecraft:amethyst_block
fill 235 211 547 235 264 547 minecraft:black_concrete
setblock 235 211 550 minecraft:white_concrete
setblock 238 211 513 minecraft:light[level=12]
setblock 238 211 521 minecraft:light[level=12]
setblock 238 211 529 minecraft:light[level=12]
setblock 238 211 537 minecraft:light[level=12]
setblock 238 211 545 minecraft:light[level=12]
fill 242 211 522 242 213 523 minecraft:bone_block
fill 243 211 525 244 213 525 minecraft:bone_block
fill 245 211 520 247 211 521 minecraft:bone_block
setblock 246 211 513 minecraft:light[level=12]
fill 246 211 524 246 212 524 minecraft:bone_block
setblock 246 211 529 minecraft:light[level=12]
setblock 246 211 537 minecraft:light[level=12]
setblock 246 211 545 minecraft:light[level=12]
setblock 254 211 513 minecraft:light[level=12]
setblock 254 211 521 minecraft:light[level=12]
setblock 254 211 529 minecraft:light[level=12]
setblock 254 211 537 minecraft:light[level=12]
setblock 254 211 545 minecraft:light[level=12]
fill 258 211 552 258 280 552 minecraft:black_concrete
setblock 262 211 513 minecraft:light[level=12]
setblock 262 211 521 minecraft:light[level=12]
setblock 262 211 529 minecraft:light[level=12]
setblock 262 211 537 minecraft:light[level=12]
setblock 262 211 545 minecraft:light[level=12]
setblock 270 211 513 minecraft:light[level=12]
setblock 270 211 521 minecraft:light[level=12]
setblock 270 211 529 minecraft:light[level=12]
setblock 270 211 537 minecraft:light[level=12]
setblock 270 211 545 minecraft:light[level=12]
setblock 275 211 510 minecraft:crying_obsidian
setblock 277 211 550 minecraft:crying_obsidian
fill 277 211 551 277 307 551 minecraft:black_concrete
fill 235 212 534 235 224 534 minecraft:black_concrete
fill 235 212 550 235 224 550 minecraft:black_concrete
fill 242 212 525 242 213 526 minecraft:bone_block
fill 243 212 526 244 213 526 minecraft:bone_block
fill 244 212 521 244 213 522 minecraft:bone_block
setblock 245 212 510 minecraft:crying_obsidian
fill 245 212 520 245 212 521 minecraft:bone_block
fill 245 212 525 245 213 525 minecraft:bone_block
fill 246 212 521 246 212 522 minecraft:bone_block
setblock 257 212 510 minecraft:crying_obsidian
setblock 261 212 510 minecraft:crying_obsidian
setblock 264 212 552 minecraft:white_concrete
fill 275 212 510 275 216 510 minecraft:black_concrete
fill 277 212 543 277 260 543 minecraft:black_concrete
setblock 277 212 544 minecraft:white_concrete
fill 277 212 550 277 223 550 minecraft:black_concrete
fill 235 213 543 235 307 543 minecraft:black_concrete
setblock 235 213 544 minecraft:white_concrete
setblock 239 213 522 minecraft:bone_block
setblock 239 213 540 minecraft:bone_block
fill 241 213 524 241 213 526 minecraft:bone_block
fill 242 213 527 243 213 527 minecraft:bone_block
fill 245 213 510 245 307 510 minecraft:black_concrete
setblock 245 213 521 minecraft:bone_block
fill 257 213 510 257 226 510 minecraft:black_concrete
setblock 257 213 552 minecraft:crying_obsidian
fill 261 213 510 261 239 510 minecraft:black_concrete
fill 264 213 552 264 259 552 minecraft:black_concrete
fill 273 213 552 273 287 552 minecraft:black_concrete
setblock 274 213 552 minecraft:crying_obsidian
fill 277 213 544 277 235 544 minecraft:black_concrete
setblock 277 213 546 minecraft:white_concrete
setblock 277 213 548 minecraft:amethyst_block
fill 235 214 544 235 307 544 minecraft:black_concrete
fill 257 214 552 257 278 552 minecraft:black_concrete
fill 274 214 552 274 226 552 minecraft:black_concrete
fill 277 214 546 277 233 546 minecraft:black_concrete
fill 277 214 548 277 267 548 minecraft:black_concrete
setblock 235 215 527 minecraft:amethyst_block
setblock 256 215 510 minecraft:white_concrete
setblock 273 215 510 minecraft:white_concrete
setblock 277 215 549 minecraft:white_concrete
fill 235 216 527 235 264 527 minecraft:black_concrete
fill 256 216 510 256 230 510 minecraft:black_concrete
fill 273 216 510 273 231 510 minecraft:black_concrete
fill 277 216 549 277 307 549 minecraft:black_concrete
setblock 275 217 510 minecraft:crying_obsidian
setblock 276 217 552 minecraft:crying_obsidian
setblock 277 217 526 minecraft:crying_obsidian
setblock 277 217 527 minecraft:white_concrete
setblock 235 218 546 minecraft:crying_obsidian
setblock 242 218 510 minecraft:crying_obsidian
fill 275 218 510 275 269 510 minecraft:black_concrete
fill 276 218 552 276 262 552 minecraft:black_concrete
fill 277 218 526 277 227 527 minecraft:black_concrete
setblock 235 219 511 minecraft:crying_obsidian
setblock 235 219 513 minecraft:white_concrete
fill 235 219 546 235 261 546 minecraft:black_concrete
setblock 238 219 513 minecraft:light[level=12]
setblock 238 219 521 minecraft:light[level=12]
setblock 238 219 529 minecraft:light[level=12]
setblock 238 219 537 minecraft:light[level=12]
setblock 238 219 545 minecraft:light[level=12]
fill 242 219 510 242 296 510 minecraft:black_concrete
fill 242 219 531 247 220 531 minecraft:black_concrete
fill 243 219 526 247 220 530 minecraft:black_concrete
fill 243 219 532 246 220 536 minecraft:black_concrete
fill 244 219 524 244 220 524 minecraft:purple_concrete
fill 244 219 525 260 219 525 minecraft:black_concrete
fill 244 219 537 246 220 538 minecraft:black_concrete
fill 245 219 522 245 220 523 minecraft:purple_concrete
fill 245 219 524 260 220 524 minecraft:black_concrete
fill 245 219 539 246 220 540 minecraft:black_concrete
setblock 246 219 513 minecraft:light[level=12]
fill 246 219 521 247 220 522 minecraft:purple_concrete
fill 246 219 523 259 220 523 minecraft:black_concrete
fill 246 219 541 247 220 541 minecraft:black_concrete
setblock 246 219 545 minecraft:light[level=12]
fill 247 219 520 262 220 520 minecraft:purple_concrete
fill 247 219 532 250 220 540 minecraft:purple_concrete
fill 247 219 542 247 220 542 minecraft:black_concrete
fill 248 219 519 260 220 519 minecraft:purple_concrete
fill 248 219 521 249 220 521 minecraft:purple_concrete
fill 248 219 522 258 220 522 minecraft:black_concrete
fill 248 219 526 248 220 529 minecraft:black_concrete
fill 248 219 530 251 220 531 minecraft:purple_concrete
fill 248 219 541 251 220 542 minecraft:purple_concrete
fill 248 219 543 248 220 543 minecraft:black_concrete
fill 249 219 518 259 220 518 minecraft:purple_concrete
fill 249 219 526 249 220 528 minecraft:black_concrete
fill 249 219 529 255 219 529 minecraft:purple_concrete
fill 249 219 543 253 220 544 minecraft:purple_concrete
fill 250 219 521 256 220 521 minecraft:black_concrete
fill 250 219 526 251 220 527 minecraft:black_concrete
fill 250 219 528 256 219 528 minecraft:purple_concrete
fill 251 219 517 256 220 517 minecraft:purple_concrete
fill 251 219 532 254 219 539 minecraft:black_concrete
fill 251 219 540 251 220 540 minecraft:purple_concrete
fill 251 219 545 255 220 545 minecraft:purple_concrete
fill 252 219 526 261 219 526 minecraft:black_concrete
fill 252 219 527 256 219 527 minecraft:purple_concrete
setblock 252 219 530 minecraft:purple_concrete
fill 252 219 531 254 219 531 minecraft:black_concrete
fill 252 219 540 260 220 541 minecraft:black_concrete
fill 252 219 542 252 220 542 minecraft:purple_concrete
fill 253 219 516 263 220 516 minecraft:black_concrete
fill 253 219 530 254 219 530 minecraft:black_concrete
fill 253 219 542 269 220 542 minecraft:black_concrete
fill 253 219 546 258 220 546 minecraft:purple_concrete
setblock 254 219 513 minecraft:light[level=12]
fill 254 219 543 268 220 543 minecraft:black_concrete
fill 254 219 544 254 220 544 minecraft:purple_concrete
fill 255 219 530 255 219 532 minecraft:amethyst_block
fill 255 219 533 255 219 539 minecraft:black_concrete
fill 255 219 544 267 220 544 minecraft:black_concrete
fill 256 219 529 256 219 530 minecraft:amethyst_block
fill 256 219 532 256 219 533 minecraft:amethyst_block
fill 256 219 534 256 219 536 minecraft:purple_concrete
fill 256 219 537 256 219 539 minecraft:black_concrete
fill 256 219 545 265 220 545 minecraft:black_concrete
fill 257 219 517 265 220 517 minecraft:black_concrete
fill 257 219 521 262 220 521 minecraft:purple_concrete
fill 257 219 527 261 219 527 minecraft:black_concrete
fill 257 219 528 257 219 529 minecraft:amethyst_block
fill 257 219 533 257 219 534 minecraft:amethyst_block
fill 257 219 535 258 219 538 minecraft:purple_concrete
fill 257 219 539 258 220 539 minecraft:black_concrete
fill 258 219 515 258 220 515 minecraft:black_concrete
fill 258 219 528 259 219 528 minecraft:amethyst_block
fill 258 219 534 259 219 534 minecraft:amethyst_block
fill 258 219 547 258 220 547 minecraft:purple_concrete
fill 259 219 522 263 220 522 minecraft:purple_concrete
fill 259 219 529 260 219 529 minecraft:amethyst_block
fill 259 219 533 260 219 533 minecraft:amethyst_block
fill 259 219 535 266 219 535 minecraft:black_concrete
fill 259 219 536 259 219 539 minecraft:purple_concrete
fill 259 219 546 263 220 546 minecraft:black_concrete
fill 260 219 518 267 220 518 minecraft:black_concrete
fill 260 219 523 264 220 523 minecraft:purple_concrete
fill 260 219 528 261 219 528 minecraft:black_concrete
fill 260 219 530 261 219 530 minecraft:amethyst_block
fill 260 219 532 261 219 532 minecraft:amethyst_block
fill 260 219 534 268 219 534 minecraft:black_concrete
fill 260 219 536 265 219 536 minecraft:black_concrete
fill 260 219 537 267 219 539 minecraft:purple_concrete
fill 261 219 519 268 220 519 minecraft:black_concrete
fill 261 219 524 264 220 525 minecraft:purple_concrete
setblock 261 219 529 minecraft:black_concrete
setblock 261 219 531 minecraft:amethyst_block
fill 261 219 533 268 219 533 minecraft:black_concrete
fill 261 219 540 265 220 540 minecraft:purple_concrete
fill 261 219 541 270 220 541 minecraft:black_concrete
setblock 262 219 513 minecraft:light[level=12]
fill 262 219 526 263 219 531 minecraft:purple_concrete
fill 262 219 532 269 219 532 minecraft:black_concrete
fill 263 219 520 269 220 521 minecraft:black_concrete
fill 264 219 522 270 220 522 minecraft:black_concrete
fill 264 219 526 264 219 529 minecraft:purple_concrete
fill 264 219 530 270 219 531 minecraft:black_concrete
fill 265 219 523 270 220 529 minecraft:black_concrete
fill 266 219 536 271 220 536 minecraft:purple_concrete
fill 266 219 540 271 220 540 minecraft:black_concrete
fill 267 219 535 272 220 535 minecraft:purple_concrete
fill 268 219 537 269 220 538 minecraft:purple_concrete
fill 268 219 539 271 220 539 minecraft:black_concrete
fill 269 219 533 273 220 534 minecraft:purple_concrete
setblock 270 219 513 minecraft:light[level=12]
fill 270 219 521 270 220 521 minecraft:black_concrete
fill 270 219 532 273 220 532 minecraft:purple_concrete
fill 270 219 537 270 220 537 minecraft:purple_concrete
fill 270 219 538 272 220 538 minecraft:black_concrete
setblock 270 219 545 minecraft:light[level=12]
fill 271 219 522 271 220 523 minecraft:purple_concrete
fill 271 219 524 271 220 527 minecraft:black_concrete
fill 271 219 528 273 220 531 minecraft:purple_concrete
fill 271 219 537 272 220 537 minecraft:black_concrete
fill 272 219 524 272 220 527 minecraft:purple_concrete
fill 272 219 536 273 220 536 minecraft:black_concrete
fill 273 219 526 273 220 527 minecraft:purple_concrete
fill 273 219 535 273 220 535 minecraft:black_concrete
fill 274 219 531 274 220 531 minecraft:purple_concrete
fill 235 220 511 276 220 511 minecraft:black_concrete
fill 235 220 513 276 220 513 minecraft:black_concrete
setblock 235 220 518 minecraft:amethyst_block
setblock 235 220 522 minecraft:crying_obsidian
fill 236 220 512 276 220 512 minecraft:black_concrete
fill 236 220 514 241 220 551 minecraft:black_concrete
fill 242 220 514 242 220 530 minecraft:black_concrete
fill 242 220 532 242 220 551 minecraft:black_concrete
fill 243 220 514 243 220 525 minecraft:black_concrete
fill 243 220 537 243 220 551 minecraft:black_concrete
fill 244 220 514 244 220 523 minecraft:black_concrete
fill 244 220 525 255 220 525 minecraft:black_concrete
fill 244 220 539 244 220 551 minecraft:black_concrete
setblock 244 220 552 minecraft:amethyst_block
fill 245 220 514 245 220 521 minecraft:black_concrete
fill 245 220 541 245 220 551 minecraft:black_concrete
fill 246 220 514 246 220 520 minecraft:black_concrete
fill 246 220 542 246 220 551 minecraft:black_concrete
fill 247 220 514 247 220 519 minecraft:black_concrete
fill 247 220 543 247 220 551 minecraft:black_concrete
fill 248 220 514 248 220 518 minecraft:black_concrete
fill 248 220 544 248 220 551 minecraft:black_concrete
fill 249 220 514 250 220 517 minecraft:black_concrete
fill 249 220 529 251 220 529 minecraft:purple_concrete
fill 249 220 545 250 220 551 minecraft:black_concrete
fill 250 220 528 252 220 528 minecraft:purple_concrete
fill 251 220 514 252 220 516 minecraft:black_concrete
fill 251 220 532 251 220 539 minecraft:black_concrete
fill 251 220 546 252 220 551 minecraft:black_concrete
fill 252 220 526 253 220 526 minecraft:black_concrete
setblock 252 220 527 minecraft:purple_concrete
fill 252 220 529 255 220 533 minecraft:mossy_stone_bricks
fill 252 220 534 252 220 539 minecraft:black_concrete
fill 253 220 514 257 220 515 minecraft:black_concrete
fill 253 220 527 263 220 528 minecraft:mossy_stone_bricks
fill 253 220 534 263 220 535 minecraft:mossy_stone_bricks
fill 253 220 536 253 220 539 minecraft:black_concrete
fill 253 220 547 257 220 551 minecraft:black_concrete
fill 254 220 526 262 220 526 minecraft:mossy_stone_bricks
fill 254 220 536 262 220 536 minecraft:mossy_stone_bricks
fill 254 220 537 255 220 539 minecraft:black_concrete
fill 256 220 525 260 220 525 minecraft:mossy_stone_bricks
fill 256 220 529 256 220 530 minecraft:mossy_stone_bricks
fill 256 220 532 256 220 533 minecraft:mossy_stone_bricks
fill 256 220 537 260 220 537 minecraft:mossy_stone_bricks
fill 256 220 538 256 220 539 minecraft:black_concrete
setblock 257 220 529 minecraft:mossy_stone_bricks
setblock 257 220 533 minecraft:mossy_stone_bricks
fill 257 220 538 267 220 538 minecraft:purple_concrete
fill 258 220 514 276 220 514 minecraft:black_concrete
fill 258 220 548 276 220 551 minecraft:black_concrete
fill 259 220 515 276 220 515 minecraft:black_concrete
fill 259 220 529 264 220 529 minecraft:mossy_stone_bricks
fill 259 220 533 264 220 533 minecraft:mossy_stone_bricks
fill 259 220 539 267 220 539 minecraft:purple_concrete
fill 259 220 547 276 220 547 minecraft:black_concrete
fill 260 220 530 264 220 530 minecraft:mossy_stone_bricks
fill 260 220 532 264 220 532 minecraft:mossy_stone_bricks
fill 261 220 531 264 220 531 minecraft:mossy_stone_bricks
fill 261 220 537 267 220 537 minecraft:purple_concrete
fill 263 220 526 264 220 526 minecraft:purple_concrete
fill 263 220 536 265 220 536 minecraft:black_concrete
fill 264 220 516 276 220 516 minecraft:black_concrete
fill 264 220 527 264 220 528 minecraft:purple_concrete
fill 264 220 534 266 220 535 minecraft:black_concrete
fill 264 220 546 276 220 546 minecraft:black_concrete
fill 265 220 530 268 220 533 minecraft:black_concrete
fill 266 220 517 276 220 517 minecraft:black_concrete
fill 266 220 545 276 220 545 minecraft:black_concrete
fill 267 220 534 268 220 534 minecraft:black_concrete
fill 268 220 518 276 220 518 minecraft:black_concrete
fill 268 220 544 276 220 544 minecraft:black_concrete
fill 269 220 519 276 220 519 minecraft:black_concrete
fill 269 220 530 269 220 532 minecraft:black_concrete
fill 269 220 543 276 220 543 minecraft:black_concrete
fill 270 220 520 276 220 520 minecraft:black_concrete
fill 270 220 530 270 220 531 minecraft:black_concrete
fill 270 220 542 276 220 542 minecraft:black_concrete
fill 271 220 521 276 220 521 minecraft:black_concrete
fill 271 220 541 276 220 541 minecraft:black_concrete
fill 272 220 522 276 220 523 minecraft:black_concrete
fill 272 220 539 276 220 540 minecraft:black_concrete
fill 273 220 524 276 220 525 minecraft:black_concrete
fill 273 220 537 276 220 538 minecraft:black_concrete
fill 274 220 526 276 220 530 minecraft:black_concrete
fill 274 220 532 276 220 536 minecraft:black_concrete
fill 275 220 531 276 220 531 minecraft:black_concrete
fill 235 221 511 235 223 511 minecraft:black_concrete
fill 235 221 513 235 225 513 minecraft:black_concrete
fill 235 221 518 235 224 518 minecraft:black_concrete
fill 235 221 522 235 307 522 minecraft:black_concrete
fill 244 221 552 244 265 552 minecraft:black_concrete
fill 250 221 529 251 230 533 minecraft:stone_bricks
fill 251 221 510 252 221 510 minecraft:white_concrete
fill 251 221 524 253 233 527 minecraft:cobblestone
fill 251 221 528 252 230 528 minecraft:stone_bricks
fill 251 221 534 252 231 534 minecraft:stone_bricks
fill 251 221 535 253 233 538 minecraft:cobblestone
fill 254 221 524 254 233 526 minecraft:cobblestone
fill 254 221 536 254 233 538 minecraft:cobblestone
setblock 254 221 552 minecraft:amethyst_block
fill 255 221 524 255 230 525 minecraft:stone_bricks
fill 255 221 537 255 230 538 minecraft:stone_bricks
fill 256 221 523 260 230 524 minecraft:stone_bricks
fill 256 221 538 260 230 539 minecraft:stone_bricks
setblock 256 221 552 minecraft:amethyst_block
fill 261 221 524 261 230 525 minecraft:stone_bricks
fill 261 221 537 261 231 538 minecraft:stone_bricks
fill 262 221 524 265 233 526 minecraft:cobblestone
fill 262 221 536 265 233 538 minecraft:cobblestone
fill 263 221 527 265 233 527 minecraft:cobblestone
fill 263 221 535 265 233 535 minecraft:cobblestone
fill 264 221 528 265 231 528 minecraft:stone_bricks
fill 264 221 534 265 230 534 minecraft:stone_bricks
fill 265 221 529 266 230 533 minecraft:stone_bricks
setblock 237 222 552 minecraft:amethyst_block
fill 251 222 510 252 238 510 minecraft:black_concrete
fill 254 222 552 254 260 552 minecraft:black_concrete
fill 256 222 552 256 233 552 minecraft:black_concrete
fill 237 223 552 237 277 552 minecraft:black_concrete
setblock 246 223 510 minecraft:amethyst_block
setblock 265 223 552 minecraft:crying_obsidian
setblock 235 224 511 minecraft:amethyst_block
setblock 235 224 537 minecraft:amethyst_block
fill 238 224 534 238 224 535 minecraft:bone_block
fill 239 224 535 244 224 536 minecraft:bone_block
fill 240 224 534 244 224 534 minecraft:bone_block
fill 241 224 533 243 224 533 minecraft:bone_block
fill 241 224 537 244 227 537 minecraft:bone_block
setblock 242 224 532 minecraft:bone_block
fill 242 224 538 244 228 538 minecraft:bone_block
fill 246 224 510 246 242 510 minecraft:black_concrete
fill 246 224 545 247 224 546 minecraft:bone_block
setblock 247 224 547 minecraft:bone_block
setblock 265 224 552 minecraft:black_concrete
setblock 277 224 550 minecraft:crying_obsidian
fill 235 225 511 235 252 511 minecraft:black_concrete
fill 235 225 518 235 227 518 minecraft:purple_concrete
fill 235 225 534 235 227 534 minecraft:purple_concrete
fill 235 225 537 235 307 537 minecraft:black_concrete
fill 235 225 550 235 227 550 minecraft:purple_concrete
fill 239 225 510 239 227 510 minecraft:purple_concrete
fill 239 225 535 239 225 536 minecraft:bone_block
fill 240 225 536 240 225 537 minecraft:bone_block
fill 241 225 534 243 225 536 minecraft:bone_block
fill 241 225 538 241 227 538 minecraft:bone_block
setblock 242 225 533 minecraft:bone_block
fill 242 225 539 244 229 539 minecraft:bone_block
fill 244 225 535 244 226 536 minecraft:bone_block
fill 245 225 537 245 228 538 minecraft:bone_block
fill 246 225 543 246 225 545 minecraft:bone_block
setblock 247 225 545 minecraft:bone_block
fill 249 225 552 249 227 552 minecraft:purple_concrete
setblock 250 225 510 minecraft:white_concrete
fill 255 225 510 255 227 510 minecraft:purple_concrete
fill 256 225 550 258 228 550 minecraft:amethyst_block
fill 257 225 549 257 228 549 minecraft:amethyst_block
fill 257 225 551 257 228 551 minecraft:amethyst_block
setblock 262 225 552 minecraft:amethyst_block
fill 265 225 552 265 227 552 minecraft:purple_concrete
fill 271 225 510 271 227 510 minecraft:purple_concrete
fill 277 225 515 277 238 515 minecraft:black_concrete
setblock 277 225 516 minecraft:crying_obsidian
fill 277 225 520 277 227 520 minecraft:purple_concrete
setblock 277 225 529 minecraft:crying_obsidian
fill 277 225 536 277 227 536 minecraft:purple_concrete
fill 277 225 550 277 307 550 minecraft:black_concrete
setblock 235 226 513 minecraft:amethyst_block
fill 241 226 535 243 226 536 minecraft:bone_block
setblock 242 226 534 minecraft:bone_block
fill 243 226 540 245 230 540 minecraft:bone_block
setblock 245 226 536 minecraft:bone_block
fill 245 226 539 245 231 539 minecraft:bone_block
fill 245 226 542 246 226 543 minecraft:bone_block
setblock 246 226 544 minecraft:bone_block
fill 250 226 510 250 229 510 minecraft:black_concrete
setblock 253 226 552 minecraft:amethyst_block
fill 256 226 548 256 228 549 minecraft:amethyst_block
fill 256 226 551 256 227 551 minecraft:amethyst_block
fill 257 226 548 258 228 548 minecraft:amethyst_block
fill 258 226 549 258 228 549 minecraft:amethyst_block
fill 258 226 551 258 227 551 minecraft:amethyst_block
fill 262 226 552 262 267 552 minecraft:black_concrete
fill 277 226 516 277 307 516 minecraft:black_concrete
fill 277 226 529 277 307 529 minecraft:black_concrete
fill 235 227 513 235 307 513 minecraft:black_concrete
setblock 235 227 549 minecraft:amethyst_block
setblock 238 227 513 minecraft:light[level=12]
setblock 238 227 521 minecraft:light[level=12]
setblock 238 227 529 minecraft:light[level=12]
setblock 238 227 537 minecraft:light[level=12]
setblock 238 227 545 minecraft:light[level=12]
fill 242 227 536 244 227 536 minecraft:bone_block
fill 242 227 540 242 229 540 minecraft:bone_block
setblock 243 227 535 minecraft:bone_block
fill 243 227 541 245 230 541 minecraft:bone_block
fill 245 227 542 245 233 542 minecraft:bone_block
setblock 246 227 513 minecraft:light[level=12]
setblock 246 227 521 minecraft:light[level=12]
setblock 246 227 529 minecraft:light[level=12]
setblock 246 227 537 minecraft:light[level=12]
fill 246 227 538 246 229 540 minecraft:bone_block
setblock 246 227 545 minecraft:light[level=12]
fill 253 227 552 253 265 552 minecraft:black_concrete
setblock 254 227 513 minecraft:light[level=12]
setblock 254 227 521 minecraft:light[level=12]
setblock 254 227 529 minecraft:light[level=12]
setblock 254 227 545 minecraft:light[level=12]
fill 256 227 547 258 228 547 minecraft:amethyst_block
setblock 257 227 510 minecraft:crying_obsidian
setblock 262 227 513 minecraft:light[level=12]
setblock 262 227 521 minecraft:light[level=12]
setblock 262 227 529 minecraft:light[level=12]
setblock 262 227 545 minecraft:light[level=12]
fill 264 227 523 264 228 523 minecraft:amethyst_block
setblock 270 227 513 minecraft:light[level=12]
setblock 270 227 521 minecraft:light[level=12]
setblock 270 227 529 minecraft:light[level=12]
setblock 270 227 537 minecraft:light[level=12]
setblock 270 227 545 minecraft:light[level=12]
setblock 274 227 552 minecraft:white_concrete
setblock 277 227 522 minecraft:crying_obsidian
fill 235 228 518 235 233 518 minecraft:black_concrete
setblock 235 228 519 minecraft:crying_obsidian
fill 235 228 520 235 307 520 minecraft:black_concrete
fill 235 228 534 235 230 534 minecraft:black_concrete
fill 235 228 549 235 233 550 minecraft:black_concrete
fill 239 228 510 239 230 510 minecraft:black_concrete
fill 242 228 537 244 228 537 minecraft:bone_block
setblock 242 228 552 minecraft:amethyst_block
setblock 243 228 536 minecraft:bone_block
fill 243 228 552 243 287 552 minecraft:black_concrete
fill 244 228 542 244 232 542 minecraft:bone_block
fill 246 228 541 246 233 542 minecraft:bone_block
fill 249 228 552 249 233 552 minecraft:black_concrete
fill 255 228 510 255 233 510 minecraft:black_concrete
fill 256 228 546 258 229 546 minecraft:amethyst_block
fill 257 228 510 257 285 510 minecraft:black_concrete
fill 257 228 545 257 229 545 minecraft:amethyst_block
setblock 259 228 510 minecraft:crying_obsidian
fill 260 228 510 260 306 510 minecraft:black_concrete
fill 265 228 552 265 233 552 minecraft:black_concrete
setblock 270 228 552 minecraft:white_concrete
fill 271 228 510 271 233 510 minecraft:black_concrete
fill 274 228 552 274 307 552 minecraft:black_concrete
fill 277 228 520 277 233 520 minecraft:black_concrete
fill 277 228 522 277 231 522 minecraft:black_concrete
fill 277 228 526 277 235 526 minecraft:black_concrete
setblock 277 228 527 minecraft:white_concrete
fill 277 228 536 277 233 536 minecraft:black_concrete
setblock 235 229 519 minecraft:black_concrete
fill 242 229 552 242 270 552 minecraft:black_concrete
fill 243 229 537 244 229 538 minecraft:bone_block
fill 245 229 538 245 230 538 minecraft:bone_block
fill 246 229 543 246 234 543 minecraft:bone_block
fill 247 229 540 247 232 542 minecraft:bone_block
setblock 257 229 544 minecraft:amethyst_block
setblock 257 229 547 minecraft:amethyst_block
fill 259 229 510 259 307 510 minecraft:black_concrete
fill 270 229 552 270 307 552 minecraft:black_concrete
fill 277 229 527 277 257 527 minecraft:black_concrete
setblock 235 230 519 minecraft:amethyst_block
fill 243 230 539 244 230 539 minecraft:bone_block
setblock 244 230 538 minecraft:bone_block
fill 245 230 543 245 233 543 minecraft:bone_block
setblock 245 230 552 minecraft:white_concrete
fill 246 230 539 246 231 540 minecraft:bone_block
fill 246 230 552 246 290 552 minecraft:black_concrete
setblock 247 230 539 minecraft:bone_block
fill 247 230 543 248 235 543 minecraft:bone_block
fill 248 230 541 248 234 542 minecraft:bone_block
setblock 250 230 510 minecraft:white_concrete
setblock 257 230 543 minecraft:amethyst_block
setblock 267 230 510 minecraft:crying_obsidian
setblock 277 230 525 minecraft:crying_obsidian
fill 235 231 519 235 258 519 minecraft:black_concrete
setblock 235 231 534 minecraft:white_concrete
setblock 239 231 510 minecraft:crying_obsidian
fill 241 231 544 243 231 544 minecraft:bone_block
fill 242 231 545 243 231 545 minecraft:bone_block
fill 244 231 539 244 231 541 minecraft:bone_block
fill 245 231 540 245 232 541 minecraft:bone_block
fill 245 231 552 245 266 552 minecraft:black_concrete
fill 246 231 544 248 234 544 minecraft:bone_block
fill 249 231 542 249 236 543 minecraft:bone_block
fill 250 231 510 250 244 510 minecraft:black_concrete
fill 250 231 529 251 231 529 minecraft:stone_bricks
fill 250 231 531 250 231 532 minecraft:stone_bricks
fill 251 231 530 251 231 531 minecraft:stone_bricks
fill 255 231 524 256 231 524 minecraft:stone_bricks
setblock 255 231 537 minecraft:stone_bricks
setblock 256 231 510 minecraft:amethyst_block
setblock 256 231 523 minecraft:stone_bricks
fill 257 231 538 258 231 539 minecraft:stone_bricks
fill 258 231 549 259 232 549 minecraft:bone_block
fill 259 231 523 260 231 524 minecraft:stone_bricks
fill 259 231 550 260 231 550 minecraft:bone_block
setblock 265 231 529 minecraft:stone_bricks
fill 265 231 531 266 231 532 minecraft:stone_bricks
setblock 266 231 533 minecraft:stone_bricks
fill 267 231 510 267 304 510 minecraft:black_concrete
fill 277 231 525 277 238 525 minecraft:black_concrete
setblock 235 232 525 minecraft:crying_obsidian
fill 235 232 534 235 233 534 minecraft:black_concrete
fill 239 232 510 239 233 510 minecraft:black_concrete
fill 243 232 544 244 232 545 minecraft:bone_block
setblock 244 232 541 minecraft:bone_block
fill 245 232 544 245 233 544 minecraft:bone_block
setblock 246 232 540 minecraft:bone_block
fill 248 232 545 248 236 545 minecraft:bone_block
fill 249 232 541 249 234 541 minecraft:bone_block
fill 249 232 544 249 237 544 minecraft:bone_block
fill 250 232 543 250 237 543 minecraft:bone_block
fill 256 232 510 256 294 510 minecraft:black_concrete
fill 257 232 548 257 233 549 minecraft:bone_block
fill 258 232 550 259 232 550 minecraft:bone_block
setblock 273 232 510 minecraft:crying_obsidian
setblock 277 232 522 minecraft:amethyst_block
setblock 277 232 541 minecraft:amethyst_block
fill 235 233 525 235 261 525 minecraft:black_concrete
setblock 235 233 540 minecraft:crying_obsidian
fill 235 233 541 235 273 542 minecraft:black_concrete
setblock 244 233 510 minecraft:white_concrete
fill 244 233 544 244 233 545 minecraft:bone_block
setblock 245 233 541 minecraft:bone_block
fill 245 233 545 247 233 545 minecraft:bone_block
fill 247 233 541 247 234 542 minecraft:bone_block
fill 249 233 545 250 237 545 minecraft:bone_block
fill 250 233 542 250 236 542 minecraft:bone_block
fill 250 233 544 251 238 544 minecraft:bone_block
fill 256 233 548 256 234 548 minecraft:bone_block
setblock 258 233 549 minecraft:bone_block
setblock 270 233 510 minecraft:crying_obsidian
fill 273 233 510 273 284 510 minecraft:black_concrete
fill 277 233 522 277 245 522 minecraft:black_concrete
fill 277 233 541 277 240 541 minecraft:black_concrete
fill 235 234 518 235 236 518 minecraft:purple_concrete
setblock 235 234 528 minecraft:crying_obsidian
fill 235 234 534 235 236 534 minecraft:purple_concrete
fill 235 234 540 235 307 540 minecraft:black_concrete
fill 235 234 549 235 307 549 minecraft:black_concrete
fill 235 234 550 235 236 550 minecraft:purple_concrete
fill 239 234 510 239 236 510 minecraft:purple_concrete
setblock 240 234 552 minecraft:crying_obsidian
fill 241 234 520 242 235 520 minecraft:amethyst_block
fill 244 234 510 244 264 510 minecraft:black_concrete
setblock 246 234 542 minecraft:bone_block
fill 246 234 545 247 234 545 minecraft:bone_block
setblock 247 234 510 minecraft:white_concrete
fill 249 234 546 250 236 546 minecraft:bone_block
fill 249 234 552 249 236 552 minecraft:purple_concrete
fill 250 234 525 254 234 526 minecraft:dark_oak_planks
fill 250 234 536 254 234 537 minecraft:dark_oak_planks
fill 251 234 524 254 234 524 minecraft:dark_oak_planks
fill 251 234 527 254 234 527 minecraft:dark_oak_planks
fill 251 234 535 254 234 535 minecraft:dark_oak_planks
fill 251 234 538 254 234 538 minecraft:dark_oak_planks
fill 251 234 543 251 238 543 minecraft:bone_block
fill 251 234 545 251 239 545 minecraft:bone_block
fill 252 234 523 253 234 523 minecraft:dark_oak_planks
fill 252 234 539 253 234 539 minecraft:dark_oak_planks
fill 252 234 544 252 240 544 minecraft:bone_block
fill 254 234 547 256 234 547 minecraft:bone_block
fill 255 234 510 255 236 510 minecraft:purple_concrete
setblock 255 234 548 minecraft:bone_block
setblock 256 234 552 minecraft:crying_obsidian
fill 262 234 524 265 234 527 minecraft:dark_oak_planks
fill 262 234 535 265 234 538 minecraft:dark_oak_planks
fill 263 234 523 264 234 523 minecraft:dark_oak_planks
fill 263 234 539 264 234 539 minecraft:dark_oak_planks
fill 265 234 552 265 236 552 minecraft:purple_concrete
fill 266 234 525 266 234 526 minecraft:dark_oak_planks
fill 266 234 536 266 234 537 minecraft:dark_oak_planks
fill 270 234 510 270 297 510 minecraft:black_concrete
fill 271 234 510 271 236 510 minecraft:purple_concrete
fill 277 234 520 277 236 520 minecraft:purple_concrete
fill 277 234 536 277 236 536 minecraft:purple_concrete
setblock 277 234 546 minecraft:white_concrete
setblock 277 234 547 minecraft:crying_obsidian
fill 235 235 528 235 307 528 minecraft:black_concrete
setblock 238 235 513 minecraft:light[level=12]
setblock 238 235 521 minecraft:light[level=12]
setblock 238 235 529 minecraft:light[level=12]
setblock 238 235 537 minecraft:light[level=12]
setblock 238 235 545 minecraft:light[level=12]
fill 240 235 552 240 247 552 minecraft:black_concrete
setblock 246 235 513 minecraft:light[level=12]
setblock 246 235 521 minecraft:light[level=12]
setblock 246 235 529 minecraft:light[level=12]
setblock 246 235 537 minecraft:light[level=12]
setblock 246 235 545 minecraft:light[level=12]
fill 247 235 510 247 307 510 minecraft:black_concrete
fill 247 235 542 248 235 542 minecraft:bone_block
fill 247 235 544 247 235 545 minecraft:bone_block
fill 248 235 544 248 236 544 minecraft:bone_block
fill 251 235 524 253 235 526 minecraft:dark_oak_planks
fill 251 235 536 253 235 538 minecraft:dark_oak_planks
fill 251 235 542 251 236 542 minecraft:bone_block
fill 251 235 546 254 239 546 minecraft:bone_block
fill 252 235 527 253 235 527 minecraft:dark_oak_planks
fill 252 235 535 253 235 535 minecraft:dark_oak_planks
fill 252 235 543 252 239 543 minecraft:bone_block
fill 252 235 545 252 240 545 minecraft:bone_block
setblock 254 235 513 minecraft:light[level=12]
setblock 254 235 521 minecraft:light[level=12]
fill 254 235 525 254 235 526 minecraft:dark_oak_planks
setblock 254 235 529 minecraft:light[level=12]
fill 254 235 536 254 235 537 minecraft:dark_oak_planks
setblock 254 235 545 minecraft:light[level=12]
fill 254 235 547 255 235 547 minecraft:bone_block
fill 256 235 552 256 242 552 minecraft:black_concrete
setblock 262 235 513 minecraft:light[level=12]
setblock 262 235 521 minecraft:light[level=12]
fill 262 235 525 265 235 526 minecraft:dark_oak_planks
setblock 262 235 529 minecraft:light[level=12]
fill 262 235 536 265 235 537 minecraft:dark_oak_planks
setblock 262 235 545 minecraft:light[level=12]
fill 263 235 524 265 235 524 minecraft:dark_oak_planks
fill 263 235 527 264 235 527 minecraft:dark_oak_planks
fill 263 235 535 264 235 535 minecraft:dark_oak_planks
fill 263 235 538 265 235 538 minecraft:dark_oak_planks
setblock 267 235 552 minecraft:amethyst_block
setblock 270 235 513 minecraft:light[level=12]
setblock 270 235 521 minecraft:light[level=12]
setblock 270 235 529 minecraft:light[level=12]
setblock 270 235 537 minecraft:light[level=12]
setblock 270 235 545 minecraft:light[level=12]
setblock 277 235 521 minecraft:crying_obsidian
fill 277 235 546 277 243 547 minecraft:black_concrete
setblock 248 236 543 minecraft:bone_block
fill 251 236 525 253 236 526 minecraft:dark_oak_planks
fill 251 236 536 253 236 537 minecraft:dark_oak_planks
fill 252 236 524 253 236 524 minecraft:dark_oak_planks
fill 252 236 538 253 236 538 minecraft:dark_oak_planks
fill 253 236 544 253 241 545 minecraft:bone_block
fill 254 236 545 254 242 545 minecraft:bone_block
fill 263 236 524 264 236 526 minecraft:dark_oak_planks
fill 263 236 536 264 236 538 minecraft:dark_oak_planks
fill 265 236 525 265 236 526 minecraft:dark_oak_planks
fill 265 236 536 265 236 537 minecraft:dark_oak_planks
fill 267 236 552 267 307 552 minecraft:black_concrete
setblock 277 236 517 minecraft:amethyst_block
fill 277 236 521 277 261 521 minecraft:black_concrete
setblock 277 236 526 minecraft:white_concrete
setblock 277 236 544 minecraft:white_concrete
fill 235 237 518 235 242 518 minecraft:black_concrete
setblock 235 237 534 minecraft:black_concrete
fill 235 237 550 235 242 550 minecraft:black_concrete
fill 239 237 510 239 242 510 minecraft:black_concrete
setblock 249 237 543 minecraft:bone_block
fill 249 237 552 249 242 552 minecraft:black_concrete
fill 250 237 546 250 238 546 minecraft:bone_block
fill 251 237 547 253 237 547 minecraft:bone_block
fill 252 237 525 253 237 526 minecraft:dark_oak_planks
fill 252 237 536 253 237 537 minecraft:dark_oak_planks
fill 253 237 543 253 239 543 minecraft:bone_block
fill 254 237 544 254 241 544 minecraft:bone_block
fill 255 237 510 255 242 510 minecraft:black_concrete
fill 255 237 545 255 243 545 minecraft:bone_block
fill 263 237 525 264 237 526 minecraft:dark_oak_planks
fill 263 237 536 264 237 537 minecraft:dark_oak_planks
fill 265 237 552 265 242 552 minecraft:black_concrete
fill 271 237 510 271 242 510 minecraft:black_concrete
setblock 272 237 510 minecraft:white_concrete
fill 277 237 517 277 259 517 minecraft:black_concrete
fill 277 237 520 277 242 520 minecraft:black_concrete
fill 277 237 526 277 241 526 minecraft:black_concrete
fill 277 237 536 277 242 536 minecraft:black_concrete
fill 277 237 544 277 307 544 minecraft:black_concrete
setblock 235 238 534 minecraft:white_concrete
setblock 235 238 551 minecraft:white_concrete
setblock 250 238 545 minecraft:bone_block
setblock 252 238 525 minecraft:dark_oak_planks
setblock 252 238 537 minecraft:dark_oak_planks
fill 252 238 547 255 239 547 minecraft:bone_block
fill 254 238 543 254 239 543 minecraft:bone_block
fill 255 238 544 255 242 544 minecraft:bone_block
fill 255 238 546 256 243 546 minecraft:bone_block
fill 256 238 545 256 244 545 minecraft:bone_block
setblock 262 238 510 minecraft:crying_obsidian
setblock 264 238 525 minecraft:dark_oak_planks
setblock 264 238 537 minecraft:dark_oak_planks
fill 272 238 510 272 260 510 minecraft:black_concrete
fill 235 239 534 235 242 534 minecraft:black_concrete
fill 235 239 551 235 259 551 minecraft:black_concrete
fill 251 239 510 251 246 510 minecraft:black_concrete
setblock 251 239 544 minecraft:bone_block
setblock 252 239 510 minecraft:amethyst_block
fill 252 239 550 253 240 550 minecraft:bone_block
fill 256 239 544 256 243 544 minecraft:bone_block
fill 256 239 547 256 243 547 minecraft:bone_block
fill 257 239 545 257 245 546 minecraft:bone_block
setblock 259 239 552 minecraft:white_concrete
fill 262 239 510 262 293 510 minecraft:black_concrete
fill 270 239 544 270 240 545 minecraft:bone_block
setblock 277 239 515 minecraft:crying_obsidian
setblock 277 239 525 minecraft:white_concrete
setblock 277 239 540 minecraft:amethyst_block
fill 252 240 510 252 248 510 minecraft:black_concrete
fill 252 240 546 254 240 546 minecraft:bone_block
setblock 253 240 510 minecraft:amethyst_block
fill 253 240 547 255 240 547 minecraft:bone_block
fill 253 240 549 254 240 549 minecraft:bone_block
setblock 254 240 550 minecraft:bone_block
fill 257 240 544 257 244 544 minecraft:bone_block
fill 257 240 547 257 244 547 minecraft:bone_block
fill 258 240 545 258 246 546 minecraft:bone_block
fill 259 240 552 259 307 552 minecraft:black_concrete
setblock 261 240 510 minecraft:amethyst_block
setblock 266 240 510 minecraft:crying_obsidian
fill 268 240 544 269 240 545 minecraft:bone_block
fill 274 240 510 274 241 510 minecraft:crying_obsidian
fill 277 240 515 277 246 515 minecraft:black_concrete
fill 277 240 525 277 264 525 minecraft:black_concrete
setblock 277 240 528 minecraft:white_concrete
fill 277 240 540 277 261 540 minecraft:black_concrete
setblock 240 241 510 minecraft:amethyst_block
fill 253 241 510 253 256 510 minecraft:black_concrete
fill 253 241 546 254 241 546 minecraft:bone_block
fill 254 241 547 255 241 549 minecraft:bone_block
fill 256 241 548 256 243 548 minecraft:bone_block
fill 258 241 544 258 246 544 minecraft:bone_block
fill 258 241 547 258 245 547 minecraft:bone_block
fill 259 241 545 259 246 546 minecraft:bone_block
fill 261 241 510 261 284 510 minecraft:black_concrete
fill 266 241 510 266 307 510 minecraft:black_concrete
fill 267 241 544 268 241 545 minecraft:bone_block
fill 277 241 528 277 277 528 minecraft:black_concrete
setblock 277 241 541 minecraft:crying_obsidian
setblock 277 241 545 minecraft:amethyst_block
fill 240 242 510 240 289 510 minecraft:black_concrete
fill 241 242 544 241 242 550 minecraft:amethyst_block
setblock 254 242 546 minecraft:bone_block
fill 255 242 547 255 242 549 minecraft:bone_block
fill 259 242 544 259 247 544 minecraft:bone_block
fill 259 242 547 259 245 547 minecraft:bone_block
fill 260 242 545 260 247 546 minecraft:bone_block
fill 265 242 544 267 242 545 minecraft:bone_block
fill 274 242 510 274 307 510 minecraft:black_concrete
setblock 277 242 526 minecraft:white_concrete
fill 277 242 541 277 245 541 minecraft:black_concrete
fill 277 242 545 277 307 545 minecraft:black_concrete
fill 235 243 518 235 245 518 minecraft:purple_concrete
fill 235 243 534 235 245 534 minecraft:purple_concrete
fill 235 243 550 235 245 550 minecraft:purple_concrete
setblock 238 243 513 minecraft:light[level=12]
setblock 238 243 521 minecraft:light[level=12]
setblock 238 243 529 minecraft:light[level=12]
setblock 238 243 537 minecraft:light[level=12]
setblock 238 243 545 minecraft:light[level=12]
fill 239 243 510 239 245 510 minecraft:purple_concrete
setblock 239 243 552 minecraft:amethyst_block
fill 240 243 548 242 243 551 minecraft:amethyst_block
fill 241 243 545 241 243 547 minecraft:amethyst_block
fill 243 243 519 244 244 520 minecraft:amethyst_block
setblock 246 243 510 minecraft:amethyst_block
setblock 246 243 513 minecraft:light[level=12]
setblock 246 243 521 minecraft:light[level=12]
setblock 246 243 529 minecraft:light[level=12]
setblock 246 243 537 minecraft:light[level=12]
setblock 246 243 545 minecraft:light[level=12]
fill 249 243 552 249 245 552 minecraft:purple_concrete
setblock 254 243 513 minecraft:light[level=12]
setblock 254 243 521 minecraft:light[level=12]
setblock 254 243 529 minecraft:light[level=12]
setblock 254 243 537 minecraft:light[level=12]
setblock 254 243 545 minecraft:light[level=12]
fill 255 243 510 255 245 510 minecraft:purple_concrete
setblock 256 243 552 minecraft:crying_obsidian
setblock 257 243 548 minecraft:bone_block
fill 258 243 543 259 244 543 minecraft:bone_block
fill 260 243 544 261 248 544 minecraft:bone_block
fill 260 243 547 260 246 547 minecraft:bone_block
fill 261 243 545 261 248 546 minecraft:bone_block
setblock 262 243 513 minecraft:light[level=12]
setblock 262 243 521 minecraft:light[level=12]
setblock 262 243 529 minecraft:light[level=12]
setblock 262 243 537 minecraft:light[level=12]
setblock 262 243 545 minecraft:light[level=12]
fill 263 243 545 265 243 545 minecraft:bone_block
fill 264 243 544 265 243 544 minecraft:bone_block
fill 265 243 552 265 245 552 minecraft:purple_concrete
setblock 270 243 513 minecraft:light[level=12]
setblock 270 243 521 minecraft:light[level=12]
setblock 270 243 529 minecraft:light[level=12]
setblock 270 243 537 minecraft:light[level=12]
setblock 270 243 545 minecraft:light[level=12]
fill 271 243 510 271 245 510 minecraft:purple_concrete
fill 277 243 520 277 245 520 minecraft:purple_concrete
fill 277 243 526 277 272 526 minecraft:black_concrete
fill 277 243 536 277 245 536 minecraft:purple_concrete
fill 239 244 552 239 307 552 minecraft:black_concrete
fill 240 244 549 242 244 551 minecraft:amethyst_block
fill 241 244 547 241 244 548 minecraft:amethyst_block
fill 246 244 510 246 256 510 minecraft:black_concrete
setblock 256 244 546 minecraft:bone_block
fill 256 244 552 256 265 552 minecraft:black_concrete
fill 260 244 543 261 247 543 minecraft:bone_block
fill 262 244 544 263 249 545 minecraft:bone_block
setblock 264 244 545 minecraft:bone_block
fill 268 244 510 268 307 510 minecraft:black_concrete
setblock 269 244 510 minecraft:amethyst_block
setblock 277 244 546 minecraft:crying_obsidian
fill 277 244 547 277 281 547 minecraft:black_concrete
setblock 238 245 552 minecraft:amethyst_block
setblock 241 245 550 minecraft:amethyst_block
setblock 250 245 510 minecraft:amethyst_block
setblock 250 245 552 minecraft:amethyst_block
fill 259 245 543 259 246 543 minecraft:bone_block
fill 261 245 547 261 246 547 minecraft:bone_block
fill 262 245 543 262 250 543 minecraft:bone_block
fill 262 245 546 262 248 546 minecraft:bone_block
fill 269 245 510 269 307 510 minecraft:black_concrete
setblock 277 245 511 minecraft:white_concrete
fill 277 245 546 277 271 546 minecraft:black_concrete
fill 235 246 518 235 251 518 minecraft:black_concrete
setblock 235 246 534 minecraft:black_concrete
fill 235 246 550 235 251 550 minecraft:black_concrete
fill 238 246 552 238 307 552 minecraft:black_concrete
fill 239 246 510 239 249 510 minecraft:black_concrete
fill 249 246 552 250 251 552 minecraft:black_concrete
fill 250 246 510 250 307 510 minecraft:black_concrete
fill 255 246 510 255 251 510 minecraft:black_concrete
fill 262 246 542 262 250 542 minecraft:bone_block
fill 263 246 543 264 251 543 minecraft:bone_block
fill 263 246 546 263 248 546 minecraft:bone_block
fill 264 246 544 264 250 545 minecraft:bone_block
fill 265 246 552 265 251 552 minecraft:black_concrete
fill 271 246 510 271 251 510 minecraft:black_concrete
fill 277 246 511 277 307 511 minecraft:black_concrete
fill 277 246 520 277 251 520 minecraft:black_concrete
setblock 277 246 522 minecraft:white_concrete
fill 277 246 536 277 251 536 minecraft:black_concrete
setblock 277 246 541 minecraft:amethyst_block
setblock 235 247 534 minecraft:amethyst_block
setblock 251 247 510 minecraft:crying_obsidian
setblock 259 247 545 minecraft:bone_block
setblock 261 247 542 minecraft:bone_block
fill 263 247 542 264 251 542 minecraft:bone_block
fill 265 247 543 265 252 544 minecraft:bone_block
setblock 277 247 515 minecraft:crying_obsidian
fill 277 247 522 277 271 522 minecraft:black_concrete
fill 277 247 541 277 307 541 minecraft:black_concrete
fill 235 248 534 235 251 534 minecraft:black_concrete
setblock 240 248 552 minecraft:crying_obsidian
fill 251 248 510 251 269 510 minecraft:black_concrete
setblock 260 248 545 minecraft:bone_block
fill 261 248 543 261 249 543 minecraft:bone_block
fill 264 248 541 264 252 541 minecraft:bone_block
fill 264 248 548 265 248 549 minecraft:bone_block
fill 265 248 542 266 253 542 minecraft:bone_block
fill 265 248 545 265 250 545 minecraft:bone_block
fill 265 248 547 265 250 547 minecraft:bone_block
fill 266 248 543 266 253 543 minecraft:bone_block
fill 274 248 534 276 248 534 minecraft:bone_block
fill 275 248 533 276 248 533 minecraft:bone_block
fill 277 248 515 277 250 515 minecraft:black_concrete
setblock 236 249 510 minecraft:amethyst_block
fill 240 249 552 240 255 552 minecraft:black_concrete
setblock 252 249 510 minecraft:amethyst_block
fill 261 249 544 261 249 545 minecraft:bone_block
fill 263 249 541 263 250 541 minecraft:bone_block
setblock 264 249 510 minecraft:crying_obsidian
fill 264 249 547 264 249 548 minecraft:bone_block
fill 265 249 541 266 254 541 minecraft:bone_block
fill 265 249 546 265 250 546 minecraft:bone_block
setblock 265 249 548 minecraft:bone_block
fill 266 249 544 266 252 544 minecraft:bone_block
fill 267 249 542 267 254 542 minecraft:bone_block
fill 273 249 535 274 250 535 minecraft:bone_block
fill 274 249 534 275 249 534 minecraft:bone_block
setblock 235 250 516 minecraft:amethyst_block
setblock 235 250 545 minecraft:crying_obsidian
fill 236 250 510 236 276 510 minecraft:black_concrete
setblock 239 250 510 minecraft:amethyst_block
fill 252 250 510 252 307 510 minecraft:black_concrete
fill 262 250 541 262 251 541 minecraft:white_concrete
fill 262 250 544 263 250 544 minecraft:bone_block
setblock 263 250 545 minecraft:bone_block
fill 264 250 510 264 253 510 minecraft:black_concrete
fill 265 250 540 267 254 540 minecraft:bone_block
fill 266 250 545 266 250 546 minecraft:bone_block
fill 267 250 541 267 255 541 minecraft:bone_block
fill 267 250 543 267 253 543 minecraft:bone_block
fill 271 250 537 272 250 538 minecraft:white_concrete
fill 272 250 536 273 250 536 minecraft:bone_block
fill 235 251 516 235 253 516 minecraft:black_concrete
fill 235 251 545 235 307 545 minecraft:black_concrete
setblock 238 251 513 minecraft:light[level=12]
setblock 238 251 521 minecraft:light[level=12]
setblock 238 251 529 minecraft:light[level=12]
setblock 238 251 537 minecraft:light[level=12]
setblock 238 251 545 minecraft:light[level=12]
setblock 239 251 510 minecraft:black_concrete
setblock 246 251 513 minecraft:light[level=12]
setblock 246 251 521 minecraft:light[level=12]
setblock 246 251 529 minecraft:light[level=12]
setblock 246 251 537 minecraft:light[level=12]
setblock 246 251 545 minecraft:light[level=12]
setblock 254 251 513 minecraft:light[level=12]
setblock 254 251 521 minecraft:light[level=12]
setblock 254 251 529 minecraft:light[level=12]
setblock 254 251 537 minecraft:light[level=12]
setblock 254 251 545 minecraft:light[level=12]
setblock 262 251 513 minecraft:light[level=12]
setblock 262 251 521 minecraft:light[level=12]
setblock 262 251 529 minecraft:light[level=12]
setblock 262 251 537 minecraft:light[level=12]
setblock 262 251 542 minecraft:white_concrete
setblock 262 251 545 minecraft:light[level=12]
setblock 263 251 541 minecraft:white_concrete
fill 263 251 544 264 251 544 minecraft:bone_block
fill 266 251 539 267 255 539 minecraft:bone_block
setblock 266 251 545 minecraft:bone_block
fill 268 251 540 268 254 542 minecraft:bone_block
setblock 270 251 513 minecraft:light[level=12]
setblock 270 251 521 minecraft:light[level=12]
setblock 270 251 529 minecraft:light[level=12]
setblock 270 251 537 minecraft:light[level=12]
setblock 270 251 545 minecraft:light[level=12]
fill 271 251 536 272 251 537 minecraft:bone_block
fill 271 251 538 272 251 538 minecraft:white_concrete
setblock 277 251 515 minecraft:crying_obsidian
setblock 235 252 515 minecraft:crying_obsidian
fill 235 252 518 235 254 518 minecraft:purple_concrete
setblock 235 252 531 minecraft:crying_obsidian
fill 235 252 534 235 254 534 minecraft:purple_concrete
fill 235 252 550 235 254 550 minecraft:purple_concrete
fill 239 252 510 239 254 510 minecraft:purple_concrete
fill 249 252 552 249 254 552 minecraft:purple_concrete
fill 250 252 552 250 307 552 minecraft:black_concrete
fill 255 252 510 255 254 510 minecraft:purple_concrete
fill 264 252 542 264 252 543 minecraft:bone_block
fill 265 252 552 265 254 552 minecraft:purple_concrete
fill 268 252 539 269 257 539 minecraft:bone_block
fill 269 252 538 271 252 538 minecraft:bone_block
fill 269 252 540 269 255 541 minecraft:bone_block
fill 270 252 537 271 252 537 minecraft:bone_block
fill 271 252 510 271 254 510 minecraft:purple_concrete
fill 277 252 515 277 307 515 minecraft:black_concrete
fill 277 252 520 277 254 520 minecraft:purple_concrete
fill 277 252 536 277 254 536 minecraft:purple_concrete
setblock 235 253 511 minecraft:amethyst_block
fill 235 253 515 235 262 515 minecraft:black_concrete
fill 235 253 531 235 256 531 minecraft:black_concrete
setblock 265 253 539 minecraft:bone_block
setblock 265 253 543 minecraft:bone_block
fill 267 253 538 270 257 538 minecraft:bone_block
fill 235 254 511 235 294 511 minecraft:black_concrete
setblock 235 254 516 minecraft:white_concrete
setblock 249 254 510 minecraft:white_concrete
setblock 264 254 510 minecraft:white_concrete
fill 266 254 538 266 255 538 minecraft:bone_block
setblock 266 254 542 minecraft:bone_block
fill 267 254 537 270 257 537 minecraft:bone_block
fill 270 254 539 270 255 540 minecraft:bone_block
fill 235 255 516 235 295 516 minecraft:black_concrete
fill 235 255 518 235 271 518 minecraft:black_concrete
fill 235 255 534 235 287 534 minecraft:black_concrete
fill 235 255 550 235 281 550 minecraft:black_concrete
fill 239 255 510 239 265 510 minecraft:black_concrete
fill 249 255 510 249 307 510 minecraft:black_concrete
fill 249 255 552 249 272 552 minecraft:black_concrete
fill 253 255 522 254 256 523 minecraft:amethyst_block
fill 255 255 510 255 272 510 minecraft:black_concrete
fill 264 255 510 264 256 510 minecraft:black_concrete
fill 265 255 552 265 287 552 minecraft:black_concrete
fill 266 255 540 266 255 541 minecraft:bone_block
fill 267 255 540 268 256 540 minecraft:bone_block
fill 268 255 536 270 259 536 minecraft:bone_block
setblock 268 255 541 minecraft:bone_block
fill 271 255 510 271 287 510 minecraft:black_concrete
fill 277 255 520 277 273 520 minecraft:black_concrete
setblock 277 255 535 minecraft:white_concrete
fill 277 255 536 277 287 536 minecraft:black_concrete
setblock 235 256 538 minecraft:white_concrete
setblock 240 256 552 minecraft:white_concrete
fill 257 256 543 258 257 545 minecraft:white_concrete
fill 267 256 539 267 257 539 minecraft:bone_block
fill 268 256 535 270 260 535 minecraft:bone_block
setblock 269 256 540 minecraft:bone_block
fill 270 256 539 270 257 539 minecraft:bone_block
fill 271 256 536 271 258 538 minecraft:bone_block
fill 273 256 521 273 257 522 minecraft:bone_block
fill 273 256 540 273 257 541 minecraft:bone_block
fill 277 256 535 277 307 535 minecraft:black_concrete
setblock 235 257 531 minecraft:amethyst_block
fill 235 257 538 235 266 538 minecraft:black_concrete
setblock 238 257 510 minecraft:crying_obsidian
fill 240 257 552 240 274 552 minecraft:black_concrete
setblock 246 257 510 minecraft:crying_obsidian
setblock 253 257 510 minecraft:crying_obsidian
setblock 260 257 552 minecraft:white_concrete
setblock 264 257 510 minecraft:crying_obsidian
fill 269 257 534 271 260 534 minecraft:bone_block
fill 271 257 535 271 260 535 minecraft:bone_block
fill 272 257 523 273 258 523 minecraft:bone_block
fill 272 257 539 273 258 539 minecraft:bone_block
fill 235 258 531 235 275 531 minecraft:black_concrete
fill 238 258 510 238 307 510 minecraft:black_concrete
fill 246 258 510 246 307 510 minecraft:black_concrete
fill 253 258 510 253 281 510 minecraft:black_concrete
fill 260 258 552 260 277 552 minecraft:black_concrete
setblock 264 258 510 minecraft:amethyst_block
fill 268 258 534 268 260 534 minecraft:bone_block
fill 268 258 537 270 258 538 minecraft:bone_block
fill 269 258 533 271 260 533 minecraft:bone_block
setblock 269 258 539 minecraft:bone_block
fill 272 258 524 272 259 525 minecraft:bone_block
fill 272 258 534 272 259 538 minecraft:bone_block
setblock 273 258 524 minecraft:bone_block
setblock 273 258 538 minecraft:bone_block
setblock 277 258 527 minecraft:amethyst_block
setblock 277 258 542 minecraft:white_concrete
setblock 235 259 519 minecraft:white_concrete
setblock 238 259 513 minecraft:light[level=12]
setblock 238 259 521 minecraft:light[level=12]
setblock 238 259 529 minecraft:light[level=12]
setblock 238 259 537 minecraft:light[level=12]
setblock 238 259 545 minecraft:light[level=12]
setblock 246 259 513 minecraft:light[level=12]
setblock 246 259 521 minecraft:light[level=12]
setblock 246 259 529 minecraft:light[level=12]
setblock 246 259 537 minecraft:light[level=12]
setblock 246 259 545 minecraft:light[level=12]
setblock 254 259 513 minecraft:light[level=12]
setblock 254 259 521 minecraft:light[level=12]
setblock 254 259 529 minecraft:light[level=12]
setblock 254 259 537 minecraft:light[level=12]
setblock 254 259 545 minecraft:light[level=12]
setblock 262 259 513 minecraft:light[level=12]
setblock 262 259 521 minecraft:light[level=12]
setblock 262 259 529 minecraft:light[level=12]
setblock 262 259 537 minecraft:light[level=12]
setblock 262 259 545 minecraft:light[level=12]
fill 264 259 510 264 277 510 minecraft:black_concrete
fill 268 259 537 271 259 537 minecraft:bone_block
fill 269 259 532 271 260 532 minecraft:bone_block
fill 269 259 538 270 259 538 minecraft:bone_block
setblock 270 259 513 minecraft:light[level=12]
setblock 270 259 521 minecraft:light[level=12]
setblock 270 259 529 minecraft:light[level=12]
setblock 270 259 545 minecraft:light[level=12]
fill 271 259 536 271 260 536 minecraft:bone_block
fill 272 259 526 272 260 527 minecraft:bone_block
fill 272 259 533 272 260 533 minecraft:bone_block
setblock 273 259 525 minecraft:bone_block
setblock 273 259 537 minecraft:bone_block
fill 277 259 527 277 276 527 minecraft:black_concrete
fill 277 259 542 277 275 542 minecraft:black_concrete
fill 235 260 519 235 307 519 minecraft:black_concrete
setblock 235 260 551 minecraft:white_concrete
setblock 252 260 552 minecraft:white_concrete
setblock 264 260 552 minecraft:crying_obsidian
setblock 268 260 533 minecraft:bone_block
fill 269 260 531 271 260 531 minecraft:bone_block
fill 269 260 536 270 260 536 minecraft:bone_block
setblock 270 260 537 minecraft:bone_block
fill 271 260 527 271 260 528 minecraft:bone_block
setblock 272 260 528 minecraft:bone_block
setblock 272 260 532 minecraft:bone_block
fill 272 260 534 272 260 536 minecraft:bone_block
setblock 277 260 517 minecraft:crying_obsidian
fill 235 261 535 235 264 535 minecraft:black_concrete
setblock 235 261 536 minecraft:white_concrete
fill 235 261 551 235 303 551 minecraft:black_concrete
fill 252 261 552 252 262 552 minecraft:black_concrete
setblock 254 261 552 minecraft:white_concrete
fill 264 261 552 264 272 552 minecraft:black_concrete
setblock 272 261 510 minecraft:amethyst_block
fill 277 261 517 277 307 517 minecraft:black_concrete
setblock 277 261 530 minecraft:white_concrete
setblock 277 261 543 minecraft:white_concrete
setblock 235 262 525 minecraft:white_concrete
fill 235 262 536 235 307 536 minecraft:black_concrete
setblock 235 262 546 minecraft:crying_obsidian
fill 254 262 552 254 307 552 minecraft:black_concrete
fill 272 262 510 272 307 510 minecraft:black_concrete
setblock 277 262 521 minecraft:amethyst_block
fill 277 262 530 277 297 530 minecraft:black_concrete
setblock 277 262 540 minecraft:white_concrete
fill 277 262 543 277 300 543 minecraft:black_concrete
setblock 235 263 515 minecraft:amethyst_block
fill 235 263 525 235 275 525 minecraft:black_concrete
fill 235 263 546 235 307 546 minecraft:black_concrete
setblock 252 263 552 minecraft:white_concrete
setblock 276 263 552 minecraft:white_concrete
fill 277 263 521 277 297 521 minecraft:black_concrete
fill 277 263 540 277 307 540 minecraft:black_concrete
setblock 235 264 515 minecraft:crying_obsidian
setblock 235 264 523 minecraft:white_concrete
fill 252 264 552 252 307 552 minecraft:black_concrete
setblock 261 264 552 minecraft:amethyst_block
fill 276 264 552 276 294 552 minecraft:black_concrete
fill 235 265 515 235 295 515 minecraft:black_concrete
fill 235 265 523 235 280 523 minecraft:black_concrete
setblock 235 265 527 minecraft:amethyst_block
setblock 235 265 535 minecraft:crying_obsidian
setblock 235 265 547 minecraft:crying_obsidian
setblock 244 265 510 minecraft:white_concrete
setblock 247 265 552 minecraft:crying_obsidian
fill 261 265 552 261 307 552 minecraft:black_concrete
fill 277 265 518 277 290 518 minecraft:black_concrete
setblock 277 265 519 minecraft:amethyst_block
setblock 277 265 525 minecraft:crying_obsidian
fill 235 266 527 255 266 527 minecraft:black_concrete
fill 235 266 535 276 266 535 minecraft:black_concrete
fill 235 266 547 276 266 547 minecraft:black_concrete
fill 236 266 511 276 266 526 minecraft:black_concrete
fill 236 266 528 253 266 534 minecraft:black_concrete
fill 236 266 536 276 266 546 minecraft:black_concrete
fill 236 266 548 276 266 551 minecraft:black_concrete
setblock 239 266 510 minecraft:amethyst_block
fill 244 266 510 244 289 510 minecraft:black_concrete
setblock 244 266 552 minecraft:white_concrete
fill 247 266 552 247 288 552 minecraft:black_concrete
setblock 253 266 552 minecraft:amethyst_block
setblock 254 266 528 minecraft:black_concrete
fill 254 266 530 254 266 534 minecraft:black_concrete
fill 255 266 531 255 266 534 minecraft:black_concrete
fill 256 266 532 276 266 534 minecraft:black_concrete
setblock 256 266 552 minecraft:crying_obsidian
fill 257 266 527 276 266 527 minecraft:black_concrete
fill 257 266 531 276 266 531 minecraft:black_concrete
fill 258 266 528 276 266 528 minecraft:black_concrete
fill 258 266 530 276 266 530 minecraft:black_concrete
fill 259 266 529 276 266 529 minecraft:black_concrete
setblock 277 266 512 minecraft:crying_obsidian
fill 277 266 519 277 301 519 minecraft:black_concrete
fill 277 266 525 277 307 525 minecraft:black_concrete
fill 235 267 527 236 292 527 minecraft:black_concrete
fill 235 267 535 236 292 535 minecraft:black_concrete
setblock 235 267 538 minecraft:white_concrete
fill 235 267 547 236 285 547 minecraft:black_concrete
fill 236 267 511 236 279 526 minecraft:black_concrete
fill 236 267 528 236 292 534 minecraft:black_concrete
fill 236 267 536 236 286 546 minecraft:black_concrete
fill 236 267 548 236 279 551 minecraft:black_concrete
fill 237 267 511 276 279 511 minecraft:black_concrete
fill 237 267 512 253 279 550 minecraft:obsidian
fill 237 267 551 276 279 551 minecraft:black_concrete
fill 239 267 510 239 287 510 minecraft:black_concrete
fill 244 267 552 244 307 552 minecraft:black_concrete
setblock 245 267 552 minecraft:crying_obsidian
setblock 253 267 552 minecraft:black_concrete
fill 254 267 512 254 278 528 minecraft:obsidian
fill 254 267 530 254 278 550 minecraft:obsidian
fill 255 267 512 255 278 527 minecraft:obsidian
fill 255 267 531 255 278 550 minecraft:obsidian
fill 256 267 512 275 279 526 minecraft:obsidian
fill 256 267 532 275 279 550 minecraft:obsidian
fill 256 267 552 256 275 552 minecraft:black_concrete
fill 257 267 527 275 278 527 minecraft:obsidian
fill 257 267 531 275 278 531 minecraft:obsidian
fill 258 267 528 275 278 528 minecraft:obsidian
fill 258 267 530 275 278 530 minecraft:obsidian
fill 259 267 529 275 279 529 minecraft:obsidian
fill 276 267 512 276 280 550 minecraft:black_concrete
fill 277 267 512 277 307 512 minecraft:black_concrete
setblock 277 267 514 minecraft:amethyst_block
fill 235 268 538 235 305 538 minecraft:black_concrete
fill 245 268 552 245 284 552 minecraft:black_concrete
setblock 253 268 552 minecraft:crying_obsidian
setblock 255 268 552 minecraft:crying_obsidian
setblock 262 268 552 minecraft:crying_obsidian
fill 277 268 514 277 307 514 minecraft:black_concrete
setblock 277 268 534 minecraft:amethyst_block
setblock 277 268 548 minecraft:amethyst_block
fill 253 269 552 253 307 552 minecraft:black_concrete
setblock 254 269 510 minecraft:amethyst_block
fill 255 269 552 255 307 552 minecraft:black_concrete
fill 262 269 552 262 303 552 minecraft:black_concrete
setblock 277 269 532 minecraft:amethyst_block
fill 277 269 534 277 307 534 minecraft:black_concrete
fill 277 269 548 277 307 548 minecraft:black_concrete
setblock 235 270 524 minecraft:white_concrete
setblock 241 270 552 minecraft:amethyst_block
setblock 251 270 510 minecraft:white_concrete
fill 254 270 510 254 307 510 minecraft:black_concrete
fill 275 270 510 275 271 510 minecraft:crying_obsidian
fill 277 270 532 277 272 532 minecraft:black_concrete
fill 235 271 524 235 292 524 minecraft:black_concrete
fill 241 271 552 241 307 552 minecraft:black_concrete
setblock 242 271 552 minecraft:crying_obsidian
fill 251 271 510 251 285 510 minecraft:black_concrete
setblock 263 271 552 minecraft:crying_obsidian
setblock 235 272 518 minecraft:white_concrete
fill 242 272 552 242 307 552 minecraft:black_concrete
fill 263 272 552 263 307 552 minecraft:black_concrete
fill 275 272 510 275 307 510 minecraft:black_concrete
setblock 277 272 522 minecraft:amethyst_block
setblock 277 272 546 minecraft:amethyst_block
fill 235 273 518 235 287 518 minecraft:black_concrete
setblock 249 273 552 minecraft:crying_obsidian
setblock 255 273 510 minecraft:amethyst_block
setblock 264 273 552 minecraft:amethyst_block
fill 277 273 522 277 307 522 minecraft:black_concrete
setblock 277 273 526 minecraft:crying_obsidian
setblock 277 273 532 minecraft:amethyst_block
fill 277 273 546 277 307 546 minecraft:black_concrete
fill 235 274 541 235 290 541 minecraft:black_concrete
setblock 235 274 542 minecraft:crying_obsidian
fill 249 274 552 249 275 552 minecraft:black_concrete
fill 255 274 510 255 287 510 minecraft:black_concrete
fill 264 274 552 264 297 552 minecraft:black_concrete
setblock 277 274 520 minecraft:crying_obsidian
fill 277 274 526 277 295 526 minecraft:black_concrete
fill 277 274 532 277 307 532 minecraft:black_concrete
fill 235 275 542 235 307 542 minecraft:black_concrete
setblock 240 275 552 minecraft:white_concrete
fill 277 275 520 277 287 520 minecraft:black_concrete
setblock 235 276 525 minecraft:white_concrete
setblock 235 276 531 minecraft:amethyst_block
fill 240 276 552 240 277 552 minecraft:black_concrete
setblock 249 276 552 minecraft:white_concrete
setblock 256 276 552 minecraft:crying_obsidian
setblock 277 276 542 minecraft:white_concrete
fill 235 277 525 235 299 525 minecraft:black_concrete
fill 235 277 531 235 296 531 minecraft:black_concrete
setblock 236 277 510 minecraft:amethyst_block
fill 249 277 552 249 287 552 minecraft:black_concrete
fill 256 277 552 256 307 552 minecraft:black_concrete
setblock 277 277 527 minecraft:crying_obsidian
fill 277 277 542 277 307 542 minecraft:black_concrete
fill 236 278 510 236 307 510 minecraft:black_concrete
setblock 237 278 552 minecraft:crying_obsidian
setblock 240 278 552 minecraft:white_concrete
setblock 260 278 552 minecraft:white_concrete
setblock 264 278 510 minecraft:crying_obsidian
fill 277 278 527 277 307 527 minecraft:black_concrete
setblock 277 278 528 minecraft:crying_obsidian
fill 237 279 552 237 294 552 minecraft:black_concrete
fill 240 279 552 240 307 552 minecraft:black_concrete
fill 254 279 512 254 279 527 minecraft:obsidian
fill 254 279 528 254 280 528 minecraft:crying_obsidian
fill 254 279 530 254 280 530 minecraft:crying_obsidian
fill 254 279 531 254 279 550 minecraft:obsidian
fill 255 279 512 255 279 526 minecraft:obsidian
fill 255 279 527 255 280 527 minecraft:crying_obsidian
fill 255 279 531 255 280 531 minecraft:crying_obsidian
fill 255 279 532 255 279 550 minecraft:obsidian
fill 257 279 527 257 280 527 minecraft:crying_obsidian
fill 257 279 531 257 280 531 minecraft:crying_obsidian
setblock 257 279 552 minecraft:white_concrete
fill 258 279 527 275 279 527 minecraft:obsidian
fill 258 279 528 258 280 528 minecraft:crying_obsidian
fill 258 279 530 258 280 530 minecraft:crying_obsidian
fill 258 279 531 275 279 531 minecraft:obsidian
fill 259 279 528 275 279 528 minecraft:obsidian
fill 259 279 530 275 279 530 minecraft:obsidian
fill 260 279 552 260 290 552 minecraft:black_concrete
fill 264 279 510 264 283 510 minecraft:black_concrete
fill 277 279 528 277 291 528 minecraft:black_concrete
setblock 236 280 511 minecraft:obsidian
fill 236 280 512 236 280 526 minecraft:black_concrete
fill 236 280 548 236 280 550 minecraft:black_concrete
setblock 236 280 551 minecraft:obsidian
fill 237 280 511 275 280 511 minecraft:black_concrete
fill 237 280 512 252 280 550 minecraft:obsidian
fill 237 280 551 275 280 551 minecraft:black_concrete
fill 253 280 512 253 280 527 minecraft:obsidian
fill 253 280 528 253 280 530 minecraft:crying_obsidian
fill 253 280 531 253 280 550 minecraft:obsidian
fill 254 280 512 254 280 526 minecraft:obsidian
setblock 254 280 527 minecraft:crying_obsidian
setblock 254 280 531 minecraft:crying_obsidian
setblock 254 280 532 minecraft:purple_concrete
fill 254 280 533 275 280 550 minecraft:obsidian
fill 255 280 512 275 280 525 minecraft:obsidian
fill 255 280 526 257 280 526 minecraft:crying_obsidian
fill 255 280 532 257 280 532 minecraft:crying_obsidian
fill 257 280 552 257 291 552 minecraft:black_concrete
fill 258 280 526 275 280 526 minecraft:obsidian
setblock 258 280 527 minecraft:crying_obsidian
setblock 258 280 531 minecraft:crying_obsidian
setblock 258 280 532 minecraft:purple_concrete
fill 259 280 527 275 280 527 minecraft:obsidian
fill 259 280 528 259 280 530 minecraft:crying_obsidian
fill 259 280 531 275 280 532 minecraft:obsidian
fill 260 280 528 275 280 530 minecraft:obsidian
setblock 276 280 511 minecraft:obsidian
setblock 276 280 551 minecraft:obsidian
setblock 235 281 523 minecraft:white_concrete
setblock 235 281 539 minecraft:crying_obsidian
fill 236 281 513 236 282 526 minecraft:black_concrete
fill 236 281 548 236 282 549 minecraft:black_concrete
fill 237 281 512 237 282 512 minecraft:black_concrete
fill 237 281 513 251 281 549 minecraft:obsidian
fill 237 281 550 237 282 550 minecraft:black_concrete
fill 238 281 511 274 282 511 minecraft:black_concrete
fill 238 281 512 274 282 512 minecraft:obsidian
fill 238 281 550 274 282 550 minecraft:obsidian
fill 238 281 551 274 282 551 minecraft:black_concrete
fill 252 281 513 252 281 527 minecraft:obsidian
fill 252 281 528 252 281 530 minecraft:purple_concrete
fill 252 281 531 252 281 549 minecraft:obsidian
fill 253 281 513 253 281 526 minecraft:obsidian
setblock 253 281 527 minecraft:purple_concrete
fill 253 281 531 253 281 532 minecraft:purple_concrete
fill 253 281 533 253 281 549 minecraft:obsidian
fill 254 281 513 254 281 525 minecraft:obsidian
setblock 254 281 526 minecraft:purple_concrete
fill 254 281 533 258 281 533 minecraft:purple_concrete
fill 254 281 534 275 281 549 minecraft:obsidian
fill 255 281 513 275 281 524 minecraft:obsidian
fill 255 281 525 257 281 525 minecraft:purple_concrete
fill 258 281 525 275 281 525 minecraft:obsidian
setblock 258 281 526 minecraft:purple_concrete
setblock 258 281 552 minecraft:amethyst_block
fill 259 281 526 275 281 526 minecraft:obsidian
setblock 259 281 527 minecraft:purple_concrete
fill 259 281 531 259 281 532 minecraft:purple_concrete
fill 259 281 533 275 281 533 minecraft:obsidian
fill 260 281 527 275 281 527 minecraft:obsidian
fill 260 281 528 260 281 530 minecraft:purple_concrete
fill 260 281 531 275 281 532 minecraft:obsidian
fill 261 281 528 275 281 530 minecraft:obsidian
fill 275 281 512 275 282 512 minecraft:black_concrete
fill 275 281 550 275 282 550 minecraft:black_concrete
fill 276 281 513 276 282 549 minecraft:black_concrete
fill 235 282 523 235 307 523 minecraft:black_concrete
fill 235 282 539 235 295 539 minecraft:black_concrete
setblock 235 282 550 minecraft:amethyst_block
fill 237 282 513 250 282 549 minecraft:obsidian
fill 251 282 513 251 282 527 minecraft:obsidian
fill 251 282 528 251 282 530 minecraft:crying_obsidian
fill 251 282 531 251 282 549 minecraft:obsidian
fill 252 282 513 252 282 526 minecraft:obsidian
setblock 252 282 527 minecraft:crying_obsidian
fill 252 282 531 252 282 532 minecraft:crying_obsidian
fill 252 282 533 252 282 549 minecraft:obsidian
setblock 253 282 510 minecraft:crying_obsidian
fill 253 282 513 253 282 525 minecraft:obsidian
setblock 253 282 526 minecraft:crying_obsidian
setblock 253 282 533 minecraft:crying_obsidian
fill 253 282 534 253 282 549 minecraft:obsidian
fill 254 282 513 255 282 524 minecraft:obsidian
fill 254 282 525 255 282 525 minecraft:crying_obsidian
fill 254 282 534 258 282 534 minecraft:crying_obsidian
fill 254 282 535 275 282 549 minecraft:obsidian
fill 256 282 513 275 282 523 minecraft:obsidian
setblock 256 282 524 minecraft:crying_obsidian
fill 257 282 524 275 282 524 minecraft:obsidian
fill 257 282 525 258 282 525 minecraft:crying_obsidian
fill 258 282 552 258 307 552 minecraft:black_concrete
fill 259 282 525 275 282 525 minecraft:obsidian
setblock 259 282 526 minecraft:crying_obsidian
setblock 259 282 533 minecraft:crying_obsidian
fill 259 282 534 275 282 534 minecraft:obsidian
fill 260 282 526 275 282 526 minecraft:obsidian
setblock 260 282 527 minecraft:crying_obsidian
fill 260 282 531 260 282 532 minecraft:crying_obsidian
fill 260 282 533 275 282 533 minecraft:obsidian
fill 261 282 527 275 282 527 minecraft:obsidian
fill 261 282 528 261 282 530 minecraft:crying_obsidian
fill 261 282 531 275 282 532 minecraft:obsidian
fill 262 282 528 275 282 530 minecraft:obsidian
setblock 277 282 547 minecraft:crying_obsidian
fill 235 283 550 235 287 550 minecraft:black_concrete
fill 236 283 514 236 283 526 minecraft:black_concrete
setblock 236 283 548 minecraft:black_concrete
setblock 237 283 513 minecraft:black_concrete
fill 237 283 514 249 283 548 minecraft:obsidian
setblock 237 283 549 minecraft:black_concrete
setblock 238 283 512 minecraft:black_concrete
fill 238 283 513 274 283 513 minecraft:obsidian
fill 238 283 549 274 283 549 minecraft:obsidian
setblock 238 283 550 minecraft:black_concrete
fill 239 283 511 273 283 511 minecraft:black_concrete
fill 239 283 512 273 283 512 minecraft:obsidian
fill 239 283 550 273 283 550 minecraft:obsidian
fill 239 283 551 273 283 551 minecraft:black_concrete
fill 250 283 514 250 283 528 minecraft:obsidian
fill 250 283 529 250 283 530 minecraft:purple_concrete
fill 250 283 531 250 283 548 minecraft:obsidian
fill 251 283 514 251 283 526 minecraft:obsidian
fill 251 283 527 251 283 528 minecraft:purple_concrete
fill 251 283 531 251 283 532 minecraft:purple_concrete
fill 251 283 533 251 283 548 minecraft:obsidian
fill 252 283 514 252 283 525 minecraft:obsidian
setblock 252 283 526 minecraft:purple_concrete
fill 252 283 533 252 283 534 minecraft:purple_concrete
fill 252 283 535 253 283 548 minecraft:obsidian
fill 253 283 510 253 307 510 minecraft:black_concrete
fill 253 283 514 253 283 524 minecraft:obsidian
setblock 253 283 525 minecraft:purple_concrete
setblock 253 283 534 minecraft:purple_concrete
fill 254 283 514 275 283 523 minecraft:obsidian
fill 254 283 524 258 283 524 minecraft:purple_concrete
setblock 254 283 529 minecraft:light[level=12]
fill 254 283 535 258 283 535 minecraft:purple_concrete
fill 254 283 536 275 283 548 minecraft:obsidian
fill 259 283 524 275 283 524 minecraft:obsidian
setblock 259 283 525 minecraft:purple_concrete
fill 259 283 534 260 283 534 minecraft:purple_concrete
fill 259 283 535 275 283 535 minecraft:obsidian
fill 260 283 525 275 283 525 minecraft:obsidian
setblock 260 283 526 minecraft:purple_concrete
setblock 260 283 533 minecraft:purple_concrete
fill 261 283 526 275 283 526 minecraft:obsidian
fill 261 283 527 261 283 528 minecraft:purple_concrete
fill 261 283 531 261 283 532 minecraft:purple_concrete
fill 261 283 533 275 283 534 minecraft:obsidian
fill 262 283 527 275 283 528 minecraft:obsidian
fill 262 283 529 262 283 530 minecraft:purple_concrete
fill 262 283 531 275 283 532 minecraft:obsidian
fill 263 283 529 275 283 530 minecraft:obsidian
setblock 274 283 512 minecraft:black_concrete
setblock 274 283 550 minecraft:black_concrete
setblock 275 283 513 minecraft:black_concrete
setblock 275 283 549 minecraft:black_concrete
fill 276 283 514 276 283 548 minecraft:black_concrete
setblock 277 283 539 minecraft:crying_obsidian
fill 277 283 547 277 307 547 minecraft:black_concrete
setblock 235 284 526 minecraft:white_concrete
fill 236 284 515 236 285 526 minecraft:black_concrete
fill 237 284 514 237 285 514 minecraft:black_concrete
fill 237 284 515 248 285 547 minecraft:obsidian
fill 237 284 548 237 285 548 minecraft:black_concrete
fill 238 284 513 238 285 513 minecraft:black_concrete
fill 238 284 514 274 285 514 minecraft:obsidian
fill 238 284 548 274 285 548 minecraft:obsidian
fill 238 284 549 238 285 549 minecraft:black_concrete
fill 239 284 512 239 285 512 minecraft:black_concrete
fill 239 284 513 273 285 513 minecraft:obsidian
fill 239 284 549 273 285 549 minecraft:obsidian
fill 239 284 550 239 285 550 minecraft:black_concrete
fill 240 284 511 272 285 511 minecraft:black_concrete
fill 240 284 512 272 285 512 minecraft:obsidian
fill 240 284 550 272 285 550 minecraft:obsidian
fill 240 284 551 272 285 551 minecraft:black_concrete
fill 249 284 515 249 284 528 minecraft:obsidian
fill 249 284 529 249 284 530 minecraft:purple_concrete
fill 249 284 531 249 284 547 minecraft:obsidian
fill 250 284 515 250 284 526 minecraft:obsidian
fill 250 284 527 250 284 528 minecraft:purple_concrete
fill 250 284 531 250 284 533 minecraft:purple_concrete
fill 250 284 534 250 284 547 minecraft:obsidian
fill 251 284 515 252 284 524 minecraft:obsidian
fill 251 284 525 251 284 526 minecraft:purple_concrete
fill 251 284 533 251 284 534 minecraft:purple_concrete
fill 251 284 535 251 284 547 minecraft:obsidian
setblock 252 284 525 minecraft:purple_concrete
fill 252 284 535 253 284 535 minecraft:purple_concrete
fill 252 284 536 253 284 547 minecraft:obsidian
fill 253 284 515 253 284 523 minecraft:obsidian
setblock 253 284 524 minecraft:purple_concrete
fill 254 284 515 275 284 522 minecraft:obsidian
fill 254 284 523 258 284 523 minecraft:purple_concrete
fill 254 284 536 258 284 536 minecraft:purple_concrete
fill 254 284 537 275 284 547 minecraft:obsidian
fill 259 284 523 275 284 523 minecraft:obsidian
setblock 259 284 524 minecraft:purple_concrete
fill 259 284 535 260 284 535 minecraft:purple_concrete
fill 259 284 536 275 284 536 minecraft:obsidian
fill 260 284 524 275 284 524 minecraft:obsidian
fill 260 284 525 261 284 525 minecraft:purple_concrete
setblock 261 284 526 minecraft:purple_concrete
fill 261 284 533 261 284 534 minecraft:purple_concrete
fill 261 284 535 275 284 535 minecraft:obsidian
fill 262 284 525 275 284 526 minecraft:obsidian
fill 262 284 527 262 284 528 minecraft:purple_concrete
fill 262 284 531 262 284 533 minecraft:purple_concrete
fill 262 284 534 275 284 534 minecraft:obsidian
fill 263 284 527 275 284 528 minecraft:obsidian
fill 263 284 529 263 284 530 minecraft:purple_concrete
fill 263 284 531 275 284 533 minecraft:obsidian
setblock 264 284 510 minecraft:white_concrete
fill 264 284 529 275 285 530 minecraft:obsidian
fill 273 284 512 273 285 512 minecraft:black_concrete
fill 273 284 550 273 285 550 minecraft:black_concrete
fill 274 284 513 274 285 513 minecraft:black_concrete
fill 274 284 549 274 285 549 minecraft:black_concrete
fill 275 284 514 275 285 514 minecraft:black_concrete
fill 275 284 548 275 285 548 minecraft:black_concrete
fill 276 284 515 276 285 547 minecraft:black_concrete
fill 277 284 539 277 303 539 minecraft:black_concrete
fill 235 285 526 235 307 526 minecraft:black_concrete
setblock 245 285 552 minecraft:crying_obsidian
fill 249 285 515 249 285 526 minecraft:obsidian
fill 249 285 527 249 285 533 minecraft:crying_obsidian
fill 249 285 534 249 285 547 minecraft:obsidian
fill 250 285 515 250 285 524 minecraft:obsidian
fill 250 285 525 250 285 526 minecraft:crying_obsidian
setblock 250 285 534 minecraft:crying_obsidian
fill 250 285 535 250 285 547 minecraft:obsidian
fill 251 285 515 252 285 523 minecraft:obsidian
fill 251 285 524 252 285 524 minecraft:crying_obsidian
setblock 251 285 535 minecraft:crying_obsidian
fill 251 285 536 251 285 547 minecraft:obsidian
fill 252 285 536 253 285 536 minecraft:crying_obsidian
fill 252 285 537 252 285 547 minecraft:obsidian
fill 253 285 515 254 285 522 minecraft:obsidian
fill 253 285 523 254 285 523 minecraft:crying_obsidian
fill 253 285 537 259 285 537 minecraft:crying_obsidian
fill 253 285 538 275 285 547 minecraft:obsidian
fill 255 285 515 275 285 521 minecraft:obsidian
fill 255 285 522 257 285 522 minecraft:crying_obsidian
fill 258 285 522 275 285 522 minecraft:obsidian
fill 258 285 523 259 285 523 minecraft:crying_obsidian
fill 259 285 536 260 285 536 minecraft:crying_obsidian
fill 260 285 523 275 285 523 minecraft:obsidian
fill 260 285 524 261 285 524 minecraft:crying_obsidian
fill 260 285 537 275 285 537 minecraft:obsidian
setblock 261 285 510 minecraft:amethyst_block
setblock 261 285 535 minecraft:crying_obsidian
fill 261 285 536 275 285 536 minecraft:obsidian
fill 262 285 524 275 285 524 minecraft:obsidian
fill 262 285 525 262 285 526 minecraft:crying_obsidian
setblock 262 285 534 minecraft:crying_obsidian
fill 262 285 535 275 285 535 minecraft:obsidian
fill 263 285 525 275 285 526 minecraft:obsidian
fill 263 285 527 263 285 533 minecraft:crying_obsidian
fill 263 285 534 275 285 534 minecraft:obsidian
fill 264 285 510 264 306 510 minecraft:black_concrete
fill 264 285 527 275 285 528 minecraft:obsidian
fill 264 285 531 275 285 533 minecraft:obsidian
setblock 273 285 510 minecraft:white_concrete
fill 235 286 547 235 293 547 minecraft:black_concrete
fill 236 286 516 236 286 526 minecraft:black_concrete
setblock 237 286 515 minecraft:black_concrete
fill 237 286 516 247 286 546 minecraft:obsidian
setblock 237 286 547 minecraft:black_concrete
setblock 238 286 514 minecraft:black_concrete
fill 238 286 515 274 286 515 minecraft:obsidian
fill 238 286 547 274 286 547 minecraft:obsidian
setblock 238 286 548 minecraft:black_concrete
setblock 239 286 513 minecraft:black_concrete
fill 239 286 514 273 286 514 minecraft:obsidian
fill 239 286 548 273 286 548 minecraft:obsidian
setblock 239 286 549 minecraft:black_concrete
setblock 240 286 512 minecraft:black_concrete
fill 240 286 513 272 286 513 minecraft:obsidian
fill 240 286 549 272 286 549 minecraft:obsidian
setblock 240 286 550 minecraft:black_concrete
fill 241 286 511 271 286 511 minecraft:black_concrete
fill 241 286 512 271 286 512 minecraft:obsidian
fill 241 286 550 271 286 550 minecraft:obsidian
fill 241 286 551 271 286 551 minecraft:black_concrete
fill 245 286 552 245 295 552 minecraft:black_concrete
fill 248 286 516 248 286 526 minecraft:obsidian
fill 248 286 527 248 286 533 minecraft:purple_concrete
fill 248 286 534 248 286 546 minecraft:obsidian
fill 249 286 516 249 286 524 minecraft:obsidian
fill 249 286 525 249 286 526 minecraft:purple_concrete
setblock 249 286 534 minecraft:purple_concrete
fill 249 286 535 249 286 546 minecraft:obsidian
fill 250 286 516 250 286 523 minecraft:obsidian
setblock 250 286 524 minecraft:purple_concrete
fill 250 286 535 250 286 536 minecraft:purple_concrete
fill 250 286 537 251 286 546 minecraft:obsidian
setblock 251 286 510 minecraft:crying_obsidian
fill 251 286 516 252 286 522 minecraft:obsidian
fill 251 286 523 252 286 523 minecraft:purple_concrete
setblock 251 286 536 minecraft:purple_concrete
setblock 252 286 537 minecraft:purple_concrete
fill 252 286 538 252 286 546 minecraft:obsidian
fill 253 286 516 275 286 521 minecraft:obsidian
fill 253 286 522 259 286 522 minecraft:purple_concrete
fill 253 286 538 259 286 538 minecraft:purple_concrete
fill 253 286 539 275 286 546 minecraft:obsidian
setblock 257 286 510 minecraft:white_concrete
fill 260 286 522 275 286 522 minecraft:obsidian
fill 260 286 523 261 286 523 minecraft:purple_concrete
setblock 260 286 537 minecraft:purple_concrete
fill 260 286 538 275 286 538 minecraft:obsidian
fill 261 286 510 261 307 510 minecraft:black_concrete
fill 261 286 536 262 286 536 minecraft:purple_concrete
fill 261 286 537 275 286 537 minecraft:obsidian
fill 262 286 523 275 286 523 minecraft:obsidian
setblock 262 286 524 minecraft:purple_concrete
setblock 262 286 535 minecraft:purple_concrete
fill 263 286 524 275 286 524 minecraft:obsidian
fill 263 286 525 263 286 526 minecraft:purple_concrete
setblock 263 286 534 minecraft:purple_concrete
fill 263 286 535 275 286 536 minecraft:obsidian
fill 264 286 525 275 286 526 minecraft:obsidian
fill 264 286 527 264 286 533 minecraft:purple_concrete
fill 264 286 534 275 286 534 minecraft:obsidian
fill 265 286 527 275 286 533 minecraft:obsidian
setblock 272 286 512 minecraft:black_concrete
setblock 272 286 550 minecraft:black_concrete
fill 273 286 510 273 302 510 minecraft:black_concrete
setblock 273 286 513 minecraft:black_concrete
setblock 273 286 549 minecraft:black_concrete
setblock 274 286 514 minecraft:black_concrete
setblock 274 286 548 minecraft:black_concrete
setblock 275 286 515 minecraft:black_concrete
setblock 275 286 547 minecraft:black_concrete
fill 276 286 516 276 286 546 minecraft:black_concrete
fill 236 287 517 236 287 526 minecraft:black_concrete
fill 236 287 536 236 287 545 minecraft:black_concrete
setblock 237 287 510 minecraft:amethyst_block
setblock 237 287 516 minecraft:black_concrete
fill 237 287 517 246 287 545 minecraft:obsidian
setblock 237 287 546 minecraft:black_concrete
setblock 238 287 515 minecraft:black_concrete
fill 238 287 516 274 287 516 minecraft:obsidian
fill 238 287 546 274 287 546 minecraft:obsidian
setblock 238 287 547 minecraft:black_concrete
setblock 239 287 514 minecraft:black_concrete
fill 239 287 515 273 287 515 minecraft:obsidian
fill 239 287 547 273 287 547 minecraft:obsidian
setblock 239 287 548 minecraft:black_concrete
setblock 240 287 513 minecraft:black_concrete
fill 240 287 514 272 287 514 minecraft:obsidian
fill 240 287 548 272 287 548 minecraft:obsidian
setblock 240 287 549 minecraft:black_concrete
setblock 241 287 512 minecraft:black_concrete
fill 241 287 513 271 287 513 minecraft:obsidian
fill 241 287 549 271 287 549 minecraft:obsidian
setblock 241 287 550 minecraft:black_concrete
fill 242 287 511 270 287 511 minecraft:black_concrete
fill 242 287 512 270 287 512 minecraft:obsidian
fill 242 287 550 270 287 550 minecraft:obsidian
fill 242 287 551 270 287 551 minecraft:black_concrete
fill 247 287 517 247 287 526 minecraft:obsidian
fill 247 287 527 247 287 533 minecraft:purple_concrete
fill 247 287 534 247 287 545 minecraft:obsidian
fill 248 287 517 248 287 525 minecraft:obsidian
setblock 248 287 526 minecraft:purple_concrete
fill 248 287 534 248 287 535 minecraft:purple_concrete
fill 248 287 536 248 287 545 minecraft:obsidian
fill 249 287 517 249 287 523 minecraft:obsidian
fill 249 287 524 249 287 525 minecraft:purple_concrete
fill 249 287 535 249 287 536 minecraft:purple_concrete
fill 249 287 537 249 287 545 minecraft:obsidian
fill 250 287 517 251 287 522 minecraft:obsidian
fill 250 287 523 251 287 523 minecraft:purple_concrete
fill 250 287 537 251 287 537 minecraft:purple_concrete
fill 250 287 538 250 287 545 minecraft:obsidian
fill 251 287 510 251 307 510 minecraft:black_concrete
fill 251 287 538 252 287 538 minecraft:purple_concrete
fill 251 287 539 252 287 545 minecraft:obsidian
fill 252 287 517 252 287 521 minecraft:obsidian
setblock 252 287 522 minecraft:purple_concrete
fill 253 287 517 275 287 520 minecraft:obsidian
fill 253 287 521 259 287 521 minecraft:purple_concrete
fill 253 287 539 259 287 539 minecraft:purple_concrete
fill 253 287 540 275 287 545 minecraft:obsidian
fill 257 287 510 257 307 510 minecraft:black_concrete
fill 260 287 521 275 287 521 minecraft:obsidian
setblock 260 287 522 minecraft:purple_concrete
fill 260 287 538 261 287 538 minecraft:purple_concrete
fill 260 287 539 275 287 539 minecraft:obsidian
fill 261 287 522 275 287 522 minecraft:obsidian
fill 261 287 523 262 287 523 minecraft:purple_concrete
fill 261 287 537 262 287 537 minecraft:purple_concrete
fill 262 287 538 275 287 538 minecraft:obsidian
fill 263 287 523 275 287 523 minecraft:obsidian
fill 263 287 524 263 287 525 minecraft:purple_concrete
fill 263 287 535 263 287 536 minecraft:purple_concrete
fill 263 287 537 275 287 537 minecraft:obsidian
fill 264 287 524 275 287 525 minecraft:obsidian
setblock 264 287 526 minecraft:purple_concrete
fill 264 287 534 264 287 535 minecraft:purple_concrete
fill 264 287 536 275 287 536 minecraft:obsidian
fill 265 287 526 275 287 526 minecraft:obsidian
fill 265 287 527 265 287 533 minecraft:purple_concrete
fill 265 287 534 275 287 535 minecraft:obsidian
fill 266 287 527 275 287 533 minecraft:obsidian
setblock 271 287 512 minecraft:black_concrete
setblock 271 287 550 minecraft:black_concrete
setblock 272 287 513 minecraft:black_concrete
setblock 272 287 549 minecraft:black_concrete
setblock 273 287 514 minecraft:black_concrete
setblock 273 287 548 minecraft:black_concrete
setblock 274 287 515 minecraft:black_concrete
setblock 274 287 547 minecraft:black_concrete
setblock 275 287 516 minecraft:black_concrete
setblock 275 287 546 minecraft:black_concrete
fill 276 287 517 276 287 545 minecraft:black_concrete
setblock 277 287 524 minecraft:white_concrete
fill 235 288 518 235 290 518 minecraft:purple_concrete
fill 235 288 534 235 290 534 minecraft:purple_concrete
fill 235 288 550 235 290 550 minecraft:purple_concrete
fill 236 288 518 236 288 526 minecraft:black_concrete
fill 236 288 536 236 288 544 minecraft:black_concrete
fill 237 288 510 237 307 510 minecraft:black_concrete
setblock 237 288 517 minecraft:black_concrete
fill 237 288 518 245 288 544 minecraft:obsidian
setblock 237 288 545 minecraft:black_concrete
setblock 238 288 516 minecraft:black_concrete
fill 238 288 517 274 288 517 minecraft:obsidian
fill 238 288 545 274 288 545 minecraft:obsidian
setblock 238 288 546 minecraft:black_concrete
fill 239 288 510 239 290 510 minecraft:purple_concrete
setblock 239 288 515 minecraft:black_concrete
fill 239 288 516 273 288 516 minecraft:obsidian
fill 239 288 546 273 288 546 minecraft:obsidian
setblock 239 288 547 minecraft:black_concrete
setblock 240 288 514 minecraft:black_concrete
fill 240 288 515 272 288 515 minecraft:obsidian
fill 240 288 547 272 288 547 minecraft:obsidian
setblock 240 288 548 minecraft:black_concrete
setblock 241 288 513 minecraft:black_concrete
fill 241 288 514 271 288 514 minecraft:obsidian
fill 241 288 548 271 288 548 minecraft:obsidian
setblock 241 288 549 minecraft:black_concrete
setblock 242 288 512 minecraft:black_concrete
fill 242 288 513 270 288 513 minecraft:obsidian
fill 242 288 549 270 288 549 minecraft:obsidian
setblock 242 288 550 minecraft:black_concrete
fill 243 288 511 269 288 511 minecraft:black_concrete
fill 243 288 512 269 288 512 minecraft:obsidian
fill 243 288 550 269 288 550 minecraft:obsidian
fill 243 288 551 269 288 551 minecraft:black_concrete
setblock 243 288 552 minecraft:white_concrete
fill 246 288 518 246 288 527 minecraft:obsidian
fill 246 288 528 246 288 533 minecraft:crying_obsidian
fill 246 288 534 246 288 544 minecraft:obsidian
fill 247 288 518 247 288 525 minecraft:obsidian
fill 247 288 526 247 288 527 minecraft:crying_obsidian
fill 247 288 534 247 288 535 minecraft:crying_obsidian
fill 247 288 536 247 288 544 minecraft:obsidian
fill 248 288 518 248 288 523 minecraft:obsidian
fill 248 288 524 248 288 525 minecraft:crying_obsidian
setblock 248 288 536 minecraft:crying_obsidian
fill 248 288 537 248 288 544 minecraft:obsidian
fill 249 288 518 249 288 522 minecraft:obsidian
setblock 249 288 523 minecraft:crying_obsidian
setblock 249 288 537 minecraft:crying_obsidian
fill 249 288 538 249 288 544 minecraft:obsidian
fill 249 288 552 249 290 552 minecraft:purple_concrete
fill 250 288 518 251 288 521 minecraft:obsidian
fill 250 288 522 251 288 522 minecraft:crying_obsidian
setblock 250 288 538 minecraft:crying_obsidian
fill 250 288 539 250 288 544 minecraft:obsidian
fill 251 288 539 252 288 539 minecraft:crying_obsidian
fill 251 288 540 252 288 544 minecraft:obsidian
fill 252 288 518 253 288 520 minecraft:obsidian
fill 252 288 521 253 288 521 minecraft:crying_obsidian
fill 253 288 540 259 288 540 minecraft:crying_obsidian
fill 253 288 541 275 288 544 minecraft:obsidian
fill 254 288 518 275 288 519 minecraft:obsidian
fill 254 288 520 258 288 520 minecraft:crying_obsidian
fill 255 288 510 255 290 510 minecraft:purple_concrete
fill 259 288 520 275 288 520 minecraft:obsidian
fill 259 288 521 260 288 521 minecraft:crying_obsidian
fill 260 288 539 261 288 539 minecraft:crying_obsidian
fill 260 288 540 275 288 540 minecraft:obsidian
fill 261 288 521 275 288 521 minecraft:obsidian
fill 261 288 522 262 288 522 minecraft:crying_obsidian
setblock 262 288 538 minecraft:crying_obsidian
fill 262 288 539 275 288 539 minecraft:obsidian
fill 263 288 522 275 288 522 minecraft:obsidian
setblock 263 288 523 minecraft:crying_obsidian
setblock 263 288 537 minecraft:crying_obsidian
fill 263 288 538 275 288 538 minecraft:obsidian
fill 264 288 523 275 288 523 minecraft:obsidian
fill 264 288 524 264 288 525 minecraft:crying_obsidian
setblock 264 288 536 minecraft:crying_obsidian
fill 264 288 537 275 288 537 minecraft:obsidian
fill 265 288 524 275 288 525 minecraft:obsidian
fill 265 288 526 265 288 527 minecraft:crying_obsidian
fill 265 288 534 265 288 535 minecraft:crying_obsidian
fill 265 288 536 275 288 536 minecraft:obsidian
fill 265 288 552 265 290 552 minecraft:purple_concrete
fill 266 288 526 275 288 527 minecraft:obsidian
fill 266 288 528 266 288 533 minecraft:crying_obsidian
fill 266 288 534 275 288 535 minecraft:obsidian
fill 267 288 528 275 288 533 minecraft:obsidian
setblock 270 288 512 minecraft:black_concrete
setblock 270 288 550 minecraft:black_concrete
fill 271 288 510 271 290 510 minecraft:purple_concrete
setblock 271 288 513 minecraft:black_concrete
setblock 271 288 549 minecraft:black_concrete
setblock 272 288 514 minecraft:black_concrete
setblock 272 288 548 minecraft:black_concrete
setblock 273 288 515 minecraft:black_concrete
setblock 273 288 547 minecraft:black_concrete
setblock 273 288 552 minecraft:white_concrete
setblock 274 288 516 minecraft:black_concrete
setblock 274 288 546 minecraft:black_concrete
setblock 275 288 517 minecraft:black_concrete
setblock 275 288 545 minecraft:black_concrete
fill 276 288 518 276 288 544 minecraft:black_concrete
fill 277 288 520 277 290 520 minecraft:purple_concrete
fill 277 288 524 277 307 524 minecraft:black_concrete
fill 277 288 536 277 290 536 minecraft:purple_concrete
fill 236 289 516 238 293 516 minecraft:amethyst_block
fill 236 289 519 236 289 526 minecraft:black_concrete
fill 236 289 536 236 289 543 minecraft:black_concrete
setblock 237 289 518 minecraft:black_concrete
fill 237 289 519 244 289 543 minecraft:obsidian
setblock 237 289 544 minecraft:black_concrete
fill 238 289 515 239 291 515 minecraft:amethyst_block
setblock 238 289 517 minecraft:black_concrete
fill 238 289 518 274 289 518 minecraft:obsidian
fill 238 289 544 274 289 544 minecraft:obsidian
setblock 238 289 545 minecraft:black_concrete
setblock 239 289 516 minecraft:black_concrete
fill 239 289 517 273 289 517 minecraft:obsidian
fill 239 289 545 273 289 545 minecraft:obsidian
setblock 239 289 546 minecraft:black_concrete
fill 240 289 515 240 290 515 minecraft:black_concrete
fill 240 289 516 272 289 516 minecraft:obsidian
fill 240 289 546 272 289 546 minecraft:obsidian
fill 240 289 547 240 290 547 minecraft:black_concrete
setblock 241 289 514 minecraft:black_concrete
fill 241 289 515 271 289 515 minecraft:obsidian
fill 241 289 547 271 289 547 minecraft:obsidian
setblock 241 289 548 minecraft:black_concrete
setblock 242 289 513 minecraft:black_concrete
fill 242 289 514 270 289 514 minecraft:obsidian
fill 242 289 548 270 289 548 minecraft:obsidian
setblock 242 289 549 minecraft:black_concrete
setblock 243 289 512 minecraft:black_concrete
fill 243 289 513 269 289 513 minecraft:obsidian
fill 243 289 549 269 289 549 minecraft:obsidian
setblock 243 289 550 minecraft:black_concrete
fill 243 289 552 243 307 552 minecraft:black_concrete
fill 244 289 511 268 289 511 minecraft:black_concrete
fill 244 289 512 268 289 512 minecraft:obsidian
fill 244 289 550 268 289 550 minecraft:obsidian
fill 244 289 551 268 289 551 minecraft:black_concrete
fill 245 289 519 245 289 527 minecraft:obsidian
fill 245 289 528 245 289 532 minecraft:purple_concrete
fill 245 289 533 245 289 543 minecraft:obsidian
fill 246 289 519 246 289 525 minecraft:obsidian
fill 246 289 526 246 289 527 minecraft:purple_concrete
fill 246 289 533 246 289 535 minecraft:purple_concrete
fill 246 289 536 246 289 543 minecraft:obsidian
fill 247 289 519 247 289 523 minecraft:obsidian
fill 247 289 524 247 289 525 minecraft:purple_concrete
setblock 247 289 536 minecraft:purple_concrete
fill 247 289 537 247 289 543 minecraft:obsidian
setblock 247 289 552 minecraft:white_concrete
fill 248 289 519 248 289 522 minecraft:obsidian
setblock 248 289 523 minecraft:purple_concrete
fill 248 289 537 248 289 538 minecraft:purple_concrete
fill 248 289 539 248 289 543 minecraft:obsidian
fill 249 289 519 249 289 521 minecraft:obsidian
setblock 249 289 522 minecraft:purple_concrete
fill 249 289 538 249 289 539 minecraft:purple_concrete
fill 249 289 540 250 289 543 minecraft:obsidian
fill 250 289 519 251 289 520 minecraft:obsidian
fill 250 289 521 251 289 521 minecraft:purple_concrete
setblock 250 289 539 minecraft:purple_concrete
fill 251 289 540 252 289 540 minecraft:purple_concrete
fill 251 289 541 252 289 543 minecraft:obsidian
fill 252 289 519 255 289 519 minecraft:obsidian
fill 252 289 520 255 289 520 minecraft:purple_concrete
fill 253 289 541 259 289 541 minecraft:purple_concrete
fill 253 289 542 275 289 543 minecraft:obsidian
fill 256 289 519 256 290 519 minecraft:purple_concrete
fill 257 289 519 275 289 519 minecraft:obsidian
fill 257 289 520 260 289 520 minecraft:purple_concrete
fill 260 289 540 261 289 540 minecraft:purple_concrete
fill 260 289 541 275 289 541 minecraft:obsidian
fill 261 289 520 275 289 520 minecraft:obsidian
fill 261 289 521 262 289 521 minecraft:purple_concrete
fill 262 289 539 263 289 539 minecraft:purple_concrete
fill 262 289 540 275 289 540 minecraft:obsidian
fill 263 289 521 275 289 521 minecraft:obsidian
setblock 263 289 522 minecraft:purple_concrete
fill 263 289 538 264 289 538 minecraft:purple_concrete
fill 264 289 522 275 289 522 minecraft:obsidian
setblock 264 289 523 minecraft:purple_concrete
setblock 264 289 537 minecraft:purple_concrete
fill 264 289 539 275 289 539 minecraft:obsidian
fill 265 289 523 275 289 523 minecraft:obsidian
fill 265 289 524 265 289 525 minecraft:purple_concrete
setblock 265 289 536 minecraft:purple_concrete
fill 265 289 537 275 289 538 minecraft:obsidian
fill 266 289 524 275 289 525 minecraft:obsidian
fill 266 289 526 266 289 527 minecraft:purple_concrete
fill 266 289 533 266 289 535 minecraft:purple_concrete
fill 266 289 536 275 289 536 minecraft:obsidian
fill 267 289 526 275 289 527 minecraft:obsidian
fill 267 289 528 267 289 532 minecraft:purple_concrete
fill 267 289 533 275 289 535 minecraft:obsidian
fill 268 289 528 275 289 532 minecraft:obsidian
setblock 269 289 512 minecraft:black_concrete
setblock 269 289 550 minecraft:black_concrete
setblock 269 289 552 minecraft:crying_obsidian
setblock 270 289 513 minecraft:black_concrete
setblock 270 289 549 minecraft:black_concrete
setblock 271 289 514 minecraft:black_concrete
setblock 271 289 548 minecraft:black_concrete
fill 272 289 515 272 290 515 minecraft:black_concrete
fill 272 289 547 272 290 547 minecraft:black_concrete
setblock 273 289 516 minecraft:black_concrete
setblock 273 289 546 minecraft:black_concrete
fill 273 289 552 273 307 552 minecraft:black_concrete
setblock 274 289 517 minecraft:black_concrete
setblock 274 289 545 minecraft:black_concrete
setblock 275 289 518 minecraft:black_concrete
setblock 275 289 544 minecraft:black_concrete
fill 276 289 519 276 289 543 minecraft:black_concrete
fill 236 290 514 236 293 515 minecraft:amethyst_block
fill 236 290 517 236 293 518 minecraft:amethyst_block
fill 236 290 521 236 290 526 minecraft:black_concrete
fill 236 290 536 236 290 541 minecraft:black_concrete
fill 237 290 515 237 293 515 minecraft:amethyst_block
fill 237 290 517 238 292 517 minecraft:amethyst_block
fill 237 290 519 237 290 520 minecraft:black_concrete
schedule function dropper:buildpart/125_3 1t
