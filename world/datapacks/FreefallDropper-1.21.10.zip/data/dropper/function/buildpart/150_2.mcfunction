fill 316 152 604 316 164 604 minecraft:purple_concrete
fill 324 152 618 324 159 618 minecraft:purple_concrete
fill 282 153 631 282 161 631 minecraft:purple_concrete
setblock 284 153 604 minecraft:pearlescent_froglight
fill 293 153 646 293 159 646 minecraft:purple_concrete
fill 310 153 604 310 163 604 minecraft:purple_concrete
fill 282 154 612 282 155 612 minecraft:gold_block
setblock 282 154 626 minecraft:pearlescent_froglight
fill 282 154 628 282 155 628 minecraft:gold_block
fill 282 154 644 282 155 644 minecraft:gold_block
fill 284 154 604 284 163 604 minecraft:purple_concrete
fill 286 154 604 286 155 604 minecraft:gold_block
fill 296 154 646 296 155 646 minecraft:gold_block
setblock 298 154 646 minecraft:amethyst_block
fill 299 154 646 299 163 646 minecraft:purple_concrete
setblock 301 154 604 minecraft:amethyst_block
fill 302 154 604 302 155 604 minecraft:gold_block
fill 312 154 646 312 155 646 minecraft:gold_block
setblock 313 154 646 minecraft:white_concrete
fill 318 154 604 318 155 604 minecraft:gold_block
fill 324 154 614 324 155 614 minecraft:gold_block
fill 324 154 630 324 155 630 minecraft:gold_block
setblock 282 155 619 minecraft:amethyst_block
fill 282 155 626 282 160 626 minecraft:purple_concrete
setblock 288 155 604 minecraft:white_concrete
fill 298 155 646 298 159 646 minecraft:purple_concrete
fill 301 155 604 301 163 604 minecraft:purple_concrete
fill 313 155 646 313 163 646 minecraft:purple_concrete
fill 282 156 612 282 160 612 minecraft:purple_concrete
fill 282 156 619 282 163 619 minecraft:purple_concrete
fill 282 156 628 282 161 628 minecraft:purple_concrete
setblock 282 156 633 minecraft:white_concrete
fill 282 156 644 282 161 644 minecraft:purple_concrete
fill 286 156 604 286 161 604 minecraft:purple_concrete
fill 288 156 604 288 160 604 minecraft:purple_concrete
fill 296 156 646 296 161 646 minecraft:purple_concrete
fill 302 156 604 302 161 604 minecraft:purple_concrete
fill 312 156 646 312 161 646 minecraft:purple_concrete
fill 318 156 604 318 160 604 minecraft:purple_concrete
fill 324 156 614 324 161 614 minecraft:purple_concrete
fill 324 156 630 324 160 630 minecraft:purple_concrete
setblock 324 156 638 minecraft:amethyst_block
fill 324 156 639 324 162 641 minecraft:purple_concrete
fill 282 157 633 282 163 633 minecraft:purple_concrete
setblock 309 157 646 minecraft:white_concrete
fill 310 157 646 310 163 646 minecraft:purple_concrete
setblock 315 157 604 minecraft:pearlescent_froglight
setblock 320 157 604 minecraft:amethyst_block
fill 324 157 638 324 163 638 minecraft:purple_concrete
setblock 285 158 607 minecraft:light[level=13]
setblock 285 158 615 minecraft:light[level=13]
setblock 285 158 623 minecraft:light[level=13]
setblock 285 158 631 minecraft:light[level=13]
setblock 285 158 639 minecraft:light[level=13]
setblock 287 158 646 minecraft:pearlescent_froglight
setblock 293 158 607 minecraft:light[level=13]
setblock 293 158 615 minecraft:light[level=13]
setblock 293 158 623 minecraft:light[level=13]
setblock 293 158 631 minecraft:light[level=13]
setblock 293 158 639 minecraft:light[level=13]
setblock 301 158 607 minecraft:light[level=13]
setblock 301 158 615 minecraft:light[level=13]
setblock 301 158 623 minecraft:light[level=13]
setblock 301 158 631 minecraft:light[level=13]
setblock 301 158 639 minecraft:light[level=13]
setblock 309 158 607 minecraft:light[level=13]
setblock 309 158 615 minecraft:light[level=13]
setblock 309 158 623 minecraft:light[level=13]
setblock 309 158 631 minecraft:light[level=13]
setblock 309 158 639 minecraft:light[level=13]
fill 309 158 646 309 163 646 minecraft:purple_concrete
fill 315 158 604 315 163 604 minecraft:purple_concrete
setblock 317 158 607 minecraft:light[level=13]
setblock 317 158 615 minecraft:light[level=13]
setblock 317 158 623 minecraft:light[level=13]
setblock 317 158 631 minecraft:light[level=13]
setblock 317 158 639 minecraft:light[level=13]
setblock 320 158 604 minecraft:purple_concrete
setblock 287 159 646 minecraft:purple_concrete
setblock 303 159 604 minecraft:amethyst_block
fill 305 159 646 306 159 646 minecraft:pearlescent_froglight
fill 306 159 633 307 160 634 minecraft:white_concrete
setblock 320 159 604 minecraft:white_concrete
setblock 324 159 609 minecraft:amethyst_block
setblock 282 160 623 minecraft:light_blue_concrete
setblock 282 160 645 minecraft:light_blue_concrete
setblock 287 160 646 minecraft:light_blue_concrete
fill 292 160 646 293 160 646 minecraft:light_blue_concrete
setblock 295 160 646 minecraft:light_blue_concrete
setblock 298 160 646 minecraft:light_blue_concrete
fill 299 160 604 299 161 604 minecraft:light_blue_concrete
setblock 302 160 646 minecraft:light_blue_concrete
fill 303 160 604 303 163 604 minecraft:purple_concrete
setblock 304 160 646 minecraft:light_blue_concrete
fill 305 160 646 306 163 646 minecraft:purple_concrete
setblock 314 160 604 minecraft:pearlescent_froglight
setblock 314 160 646 minecraft:light_blue_concrete
setblock 319 160 646 minecraft:light_blue_concrete
fill 320 160 604 320 161 604 minecraft:purple_concrete
setblock 320 160 646 minecraft:purple_concrete
fill 321 160 646 322 160 646 minecraft:light_blue_concrete
fill 324 160 609 324 163 609 minecraft:purple_concrete
setblock 324 160 612 minecraft:light_blue_concrete
setblock 324 160 618 minecraft:light_blue_concrete
setblock 324 160 626 minecraft:light_blue_concrete
setblock 282 161 608 minecraft:light_blue_concrete
setblock 282 161 612 minecraft:light_blue_concrete
fill 282 161 623 282 163 623 minecraft:purple_concrete
setblock 282 161 626 minecraft:light_blue_concrete
fill 282 161 636 282 162 636 minecraft:light_blue_concrete
fill 282 161 645 282 163 645 minecraft:purple_concrete
setblock 282 161 646 minecraft:light_blue_concrete
setblock 283 161 646 minecraft:white_concrete
fill 287 161 646 287 163 646 minecraft:purple_concrete
setblock 288 161 604 minecraft:amethyst_block
setblock 292 161 604 minecraft:white_concrete
setblock 292 161 646 minecraft:purple_concrete
setblock 293 161 604 minecraft:light_blue_concrete
setblock 293 161 646 minecraft:light_blue_concrete
fill 295 161 646 295 164 646 minecraft:purple_concrete
fill 298 161 646 298 163 646 minecraft:purple_concrete
setblock 301 161 646 minecraft:light_blue_concrete
fill 302 161 646 302 163 646 minecraft:purple_concrete
setblock 304 161 646 minecraft:purple_concrete
fill 308 161 604 309 161 604 minecraft:light_blue_concrete
fill 314 161 604 314 163 604 minecraft:purple_concrete
fill 314 161 646 314 163 646 minecraft:purple_concrete
setblock 318 161 604 minecraft:light_blue_concrete
fill 319 161 646 319 164 646 minecraft:purple_concrete
setblock 320 161 646 minecraft:white_concrete
fill 321 161 646 322 163 646 minecraft:purple_concrete
setblock 323 161 646 minecraft:light_blue_concrete
fill 324 161 605 324 162 605 minecraft:light_blue_concrete
setblock 324 161 611 minecraft:light_blue_concrete
fill 324 161 612 324 164 612 minecraft:purple_concrete
setblock 324 161 613 minecraft:light_blue_concrete
fill 324 161 618 324 163 618 minecraft:purple_concrete
fill 324 161 626 324 163 626 minecraft:purple_concrete
setblock 324 161 630 minecraft:light_blue_concrete
fill 324 161 635 324 163 635 minecraft:purple_concrete
setblock 324 161 636 minecraft:light_blue_concrete
fill 282 162 608 282 163 608 minecraft:purple_concrete
fill 282 162 612 282 164 612 minecraft:gold_block
fill 282 162 626 282 163 626 minecraft:purple_concrete
fill 282 162 628 282 164 628 minecraft:gold_block
setblock 282 162 631 minecraft:white_concrete
fill 282 162 644 282 164 644 minecraft:gold_block
fill 282 162 646 283 164 646 minecraft:purple_concrete
setblock 285 162 646 minecraft:light_blue_concrete
fill 286 162 604 286 164 604 minecraft:gold_block
fill 288 162 604 288 163 604 minecraft:purple_concrete
setblock 289 162 646 minecraft:light_blue_concrete
setblock 292 162 604 minecraft:light_blue_concrete
setblock 292 162 646 minecraft:white_concrete
fill 293 162 604 293 163 604 minecraft:purple_concrete
fill 293 162 646 293 164 646 minecraft:purple_concrete
fill 296 162 646 296 164 646 minecraft:gold_block
setblock 297 162 646 minecraft:light_blue_concrete
fill 299 162 604 299 163 604 minecraft:purple_concrete
setblock 300 162 604 minecraft:light_blue_concrete
fill 301 162 646 301 164 646 minecraft:purple_concrete
fill 302 162 604 302 164 604 minecraft:gold_block
setblock 304 162 646 minecraft:light_blue_concrete
fill 308 162 604 309 163 604 minecraft:purple_concrete
setblock 308 162 646 minecraft:light_blue_concrete
setblock 311 162 604 minecraft:light_blue_concrete
setblock 311 162 646 minecraft:light_blue_concrete
fill 312 162 646 312 164 646 minecraft:gold_block
fill 318 162 604 318 164 604 minecraft:gold_block
setblock 320 162 604 minecraft:light_blue_concrete
fill 320 162 646 320 163 646 minecraft:purple_concrete
fill 323 162 646 323 164 646 minecraft:purple_concrete
fill 324 162 611 324 164 611 minecraft:purple_concrete
fill 324 162 613 324 163 613 minecraft:purple_concrete
fill 324 162 614 324 164 614 minecraft:gold_block
fill 324 162 620 324 162 621 minecraft:light_blue_concrete
fill 324 162 630 324 164 630 minecraft:gold_block
setblock 324 162 631 minecraft:light_blue_concrete
fill 324 162 636 324 163 636 minecraft:purple_concrete
setblock 324 162 637 minecraft:pearlescent_froglight
setblock 282 163 631 minecraft:purple_concrete
setblock 282 163 632 minecraft:pearlescent_froglight
setblock 282 163 636 minecraft:purple_concrete
setblock 285 163 646 minecraft:purple_concrete
setblock 289 163 646 minecraft:purple_concrete
setblock 292 163 604 minecraft:purple_concrete
setblock 292 163 646 minecraft:purple_concrete
setblock 297 163 646 minecraft:purple_concrete
setblock 300 163 604 minecraft:purple_concrete
setblock 304 163 646 minecraft:purple_concrete
setblock 308 163 646 minecraft:purple_concrete
setblock 311 163 604 minecraft:purple_concrete
setblock 311 163 646 minecraft:purple_concrete
setblock 320 163 604 minecraft:purple_concrete
setblock 324 163 605 minecraft:purple_concrete
fill 324 163 620 324 163 621 minecraft:purple_concrete
setblock 324 163 631 minecraft:purple_concrete
setblock 324 163 637 minecraft:purple_concrete
setblock 324 163 639 minecraft:pearlescent_froglight
fill 324 163 640 324 163 641 minecraft:purple_concrete
setblock 324 163 642 minecraft:pearlescent_froglight
fill 282 164 604 282 165 606 minecraft:light_blue_concrete
fill 282 164 608 282 164 611 minecraft:light_blue_concrete
fill 282 164 613 282 165 615 minecraft:light_blue_concrete
fill 282 164 617 282 164 619 minecraft:light_blue_concrete
fill 282 164 621 282 165 627 minecraft:light_blue_concrete
fill 282 164 629 282 164 632 minecraft:light_blue_concrete
setblock 282 164 633 minecraft:pearlescent_froglight
fill 282 164 634 282 164 643 minecraft:light_blue_concrete
fill 282 164 645 282 183 645 minecraft:light_blue_concrete
fill 283 164 604 284 164 604 minecraft:light_blue_concrete
fill 284 164 646 285 235 646 minecraft:light_blue_concrete
setblock 286 164 646 minecraft:amethyst_block
fill 287 164 604 289 187 604 minecraft:light_blue_concrete
fill 287 164 646 292 164 646 minecraft:light_blue_concrete
fill 290 164 604 291 164 604 minecraft:purple_concrete
fill 292 164 604 301 164 604 minecraft:light_blue_concrete
fill 294 164 646 294 236 646 minecraft:light_blue_concrete
fill 297 164 646 300 165 646 minecraft:light_blue_concrete
fill 302 164 646 305 165 646 minecraft:light_blue_concrete
fill 303 164 604 312 164 604 minecraft:light_blue_concrete
fill 306 164 646 306 165 646 minecraft:purple_concrete
fill 307 164 646 311 164 646 minecraft:light_blue_concrete
fill 313 164 646 314 215 646 minecraft:light_blue_concrete
fill 314 164 604 315 164 604 minecraft:light_blue_concrete
fill 316 164 646 318 165 646 minecraft:light_blue_concrete
fill 317 164 604 317 175 604 minecraft:light_blue_concrete
fill 319 164 604 324 164 604 minecraft:light_blue_concrete
fill 320 164 646 322 164 646 minecraft:light_blue_concrete
fill 324 164 605 324 164 610 minecraft:light_blue_concrete
fill 324 164 613 324 235 613 minecraft:light_blue_concrete
fill 324 164 615 324 164 629 minecraft:light_blue_concrete
fill 324 164 631 324 179 633 minecraft:light_blue_concrete
setblock 324 164 634 minecraft:amethyst_block
fill 324 164 635 324 165 646 minecraft:light_blue_concrete
fill 282 165 607 282 165 610 minecraft:light_blue_concrete
fill 282 165 611 282 165 612 minecraft:purple_concrete
fill 282 165 616 282 202 616 minecraft:light_blue_concrete
setblock 282 165 617 minecraft:amethyst_block
fill 282 165 618 282 181 618 minecraft:light_blue_concrete
setblock 282 165 619 minecraft:purple_concrete
fill 282 165 620 282 174 620 minecraft:light_blue_concrete
fill 282 165 628 282 165 629 minecraft:light_blue_concrete
fill 282 165 630 282 165 631 minecraft:purple_concrete
fill 282 165 632 282 166 633 minecraft:light_blue_concrete
fill 282 165 634 282 165 635 minecraft:purple_concrete
fill 282 165 636 282 183 638 minecraft:light_blue_concrete
setblock 282 165 639 minecraft:purple_concrete
fill 282 165 640 282 165 644 minecraft:light_blue_concrete
fill 282 165 646 283 232 646 minecraft:light_blue_concrete
setblock 283 165 604 minecraft:purple_concrete
fill 284 165 604 286 170 604 minecraft:light_blue_concrete
fill 286 165 646 286 235 646 minecraft:light_blue_concrete
setblock 287 165 646 minecraft:amethyst_block
setblock 288 165 646 minecraft:purple_concrete
fill 289 165 646 293 165 646 minecraft:light_blue_concrete
fill 290 165 604 298 165 604 minecraft:light_blue_concrete
fill 295 165 646 295 224 646 minecraft:light_blue_concrete
setblock 296 165 646 minecraft:purple_concrete
fill 299 165 604 300 165 604 minecraft:purple_concrete
fill 301 165 604 309 165 604 minecraft:light_blue_concrete
fill 301 165 646 301 229 646 minecraft:light_blue_concrete
fill 307 165 646 310 165 646 minecraft:light_blue_concrete
fill 310 165 604 310 166 604 minecraft:purple_concrete
fill 311 165 604 314 172 604 minecraft:light_blue_concrete
setblock 311 165 646 minecraft:purple_concrete
fill 312 165 646 312 188 646 minecraft:light_blue_concrete
setblock 315 165 604 minecraft:purple_concrete
fill 315 165 646 315 172 646 minecraft:light_blue_concrete
fill 316 165 604 316 186 604 minecraft:light_blue_concrete
fill 318 165 604 318 188 604 minecraft:light_blue_concrete
setblock 319 165 604 minecraft:purple_concrete
fill 319 165 646 321 172 646 minecraft:light_blue_concrete
fill 320 165 604 324 169 604 minecraft:light_blue_concrete
setblock 322 165 646 minecraft:purple_concrete
fill 323 165 646 323 236 646 minecraft:light_blue_concrete
fill 324 165 605 324 228 605 minecraft:light_blue_concrete
setblock 324 165 606 minecraft:purple_concrete
fill 324 165 607 324 165 612 minecraft:light_blue_concrete
fill 324 165 614 324 165 620 minecraft:light_blue_concrete
fill 324 165 621 324 165 622 minecraft:purple_concrete
fill 324 165 623 324 169 627 minecraft:light_blue_concrete
setblock 324 165 628 minecraft:purple_concrete
fill 324 165 629 324 167 630 minecraft:light_blue_concrete
fill 324 165 634 324 166 634 minecraft:light_blue_concrete
setblock 282 166 604 minecraft:purple_concrete
fill 282 166 605 282 176 608 minecraft:light_blue_concrete
setblock 282 166 609 minecraft:purple_concrete
fill 282 166 610 282 235 611 minecraft:light_blue_concrete
setblock 282 166 612 minecraft:purple_concrete
fill 282 166 613 282 167 613 minecraft:light_blue_concrete
setblock 282 166 614 minecraft:purple_concrete
fill 282 166 615 282 235 615 minecraft:light_blue_concrete
fill 282 166 617 282 235 617 minecraft:light_blue_concrete
fill 282 166 619 282 235 619 minecraft:light_blue_concrete
fill 282 166 621 282 232 621 minecraft:light_blue_concrete
setblock 282 166 622 minecraft:purple_concrete
fill 282 166 623 282 222 624 minecraft:light_blue_concrete
setblock 282 166 625 minecraft:purple_concrete
fill 282 166 626 282 175 628 minecraft:light_blue_concrete
setblock 282 166 629 minecraft:purple_concrete
fill 282 166 630 282 180 631 minecraft:light_blue_concrete
fill 282 166 634 282 179 635 minecraft:light_blue_concrete
fill 282 166 639 282 233 639 minecraft:light_blue_concrete
setblock 282 166 640 minecraft:purple_concrete
fill 282 166 641 282 167 643 minecraft:light_blue_concrete
setblock 282 166 644 minecraft:purple_concrete
fill 283 166 604 283 180 604 minecraft:light_blue_concrete
setblock 285 166 607 minecraft:light[level=13]
setblock 285 166 615 minecraft:light[level=13]
setblock 285 166 623 minecraft:light[level=13]
setblock 285 166 631 minecraft:light[level=13]
setblock 285 166 639 minecraft:light[level=13]
fill 287 166 646 292 195 646 minecraft:light_blue_concrete
fill 290 166 604 291 191 604 minecraft:light_blue_concrete
setblock 292 166 604 minecraft:purple_concrete
fill 293 166 604 299 173 604 minecraft:light_blue_concrete
setblock 293 166 607 minecraft:light[level=13]
setblock 293 166 615 minecraft:light[level=13]
setblock 293 166 623 minecraft:light[level=13]
setblock 293 166 631 minecraft:light[level=13]
setblock 293 166 639 minecraft:light[level=13]
setblock 293 166 646 minecraft:purple_concrete
fill 296 166 646 298 174 646 minecraft:light_blue_concrete
setblock 299 166 646 minecraft:purple_concrete
setblock 300 166 604 minecraft:purple_concrete
fill 300 166 646 300 206 646 minecraft:light_blue_concrete
fill 301 166 604 307 187 604 minecraft:light_blue_concrete
setblock 301 166 607 minecraft:light[level=13]
setblock 301 166 615 minecraft:light[level=13]
setblock 301 166 623 minecraft:light[level=13]
setblock 301 166 631 minecraft:light[level=13]
setblock 301 166 639 minecraft:light[level=13]
fill 302 166 646 304 175 646 minecraft:light_blue_concrete
setblock 305 166 646 minecraft:amethyst_block
fill 306 166 646 306 202 646 minecraft:light_blue_concrete
setblock 307 166 646 minecraft:purple_concrete
setblock 308 166 604 minecraft:purple_concrete
fill 308 166 646 311 194 646 minecraft:light_blue_concrete
fill 309 166 604 309 188 604 minecraft:light_blue_concrete
setblock 309 166 607 minecraft:light[level=13]
setblock 309 166 615 minecraft:light[level=13]
setblock 309 166 623 minecraft:light[level=13]
setblock 309 166 631 minecraft:light[level=13]
setblock 309 166 639 minecraft:light[level=13]
fill 315 166 604 315 169 604 minecraft:light_blue_concrete
fill 316 166 646 317 188 646 minecraft:light_blue_concrete
setblock 317 166 607 minecraft:light[level=13]
setblock 317 166 615 minecraft:light[level=13]
setblock 317 166 623 minecraft:light[level=13]
setblock 317 166 631 minecraft:light[level=13]
setblock 317 166 639 minecraft:light[level=13]
setblock 318 166 646 minecraft:purple_concrete
fill 319 166 604 319 235 604 minecraft:light_blue_concrete
fill 322 166 646 322 224 646 minecraft:light_blue_concrete
fill 324 166 606 324 178 606 minecraft:light_blue_concrete
setblock 324 166 607 minecraft:purple_concrete
fill 324 166 608 324 171 611 minecraft:light_blue_concrete
setblock 324 166 612 minecraft:white_concrete
fill 324 166 614 324 181 615 minecraft:light_blue_concrete
setblock 324 166 616 minecraft:white_concrete
fill 324 166 617 324 179 622 minecraft:light_blue_concrete
fill 324 166 628 324 176 628 minecraft:light_blue_concrete
fill 324 166 635 324 182 640 minecraft:light_blue_concrete
setblock 324 166 641 minecraft:purple_concrete
fill 324 166 642 324 191 646 minecraft:light_blue_concrete
fill 282 167 604 282 231 604 minecraft:light_blue_concrete
fill 282 167 609 282 235 609 minecraft:light_blue_concrete
fill 282 167 612 282 168 612 minecraft:light_blue_concrete
fill 282 167 614 282 235 614 minecraft:light_blue_concrete
fill 282 167 622 282 172 622 minecraft:light_blue_concrete
fill 282 167 625 282 197 625 minecraft:light_blue_concrete
fill 282 167 629 282 210 629 minecraft:light_blue_concrete
setblock 282 167 632 minecraft:white_concrete
fill 282 167 633 282 170 633 minecraft:light_blue_concrete
fill 282 167 640 282 173 640 minecraft:light_blue_concrete
fill 282 167 644 282 186 644 minecraft:light_blue_concrete
fill 292 167 604 292 203 604 minecraft:light_blue_concrete
fill 293 167 646 293 194 646 minecraft:light_blue_concrete
fill 299 167 646 299 231 646 minecraft:light_blue_concrete
fill 300 167 604 300 179 604 minecraft:light_blue_concrete
fill 305 167 646 305 224 646 minecraft:light_blue_concrete
fill 307 167 646 307 209 646 minecraft:light_blue_concrete
fill 308 167 604 308 226 604 minecraft:light_blue_concrete
fill 310 167 604 310 235 604 minecraft:light_blue_concrete
fill 318 167 646 318 232 646 minecraft:light_blue_concrete
fill 324 167 607 324 235 607 minecraft:light_blue_concrete
fill 324 167 612 324 233 612 minecraft:light_blue_concrete
fill 324 167 616 324 221 616 minecraft:light_blue_concrete
setblock 324 167 634 minecraft:amethyst_block
fill 324 167 641 324 171 641 minecraft:light_blue_concrete
setblock 282 168 613 minecraft:pearlescent_froglight
fill 282 168 632 282 235 632 minecraft:light_blue_concrete
fill 282 168 641 282 180 642 minecraft:light_blue_concrete
setblock 282 168 643 minecraft:pearlescent_froglight
fill 324 168 629 324 185 629 minecraft:light_blue_concrete
setblock 324 168 630 minecraft:amethyst_block
fill 324 168 634 324 219 634 minecraft:light_blue_concrete
setblock 282 169 612 minecraft:pearlescent_froglight
fill 282 169 613 282 235 613 minecraft:light_blue_concrete
fill 282 169 643 282 182 643 minecraft:light_blue_concrete
setblock 324 169 630 minecraft:light_blue_concrete
fill 282 170 612 282 188 612 minecraft:light_blue_concrete
fill 301 170 624 303 170 624 minecraft:shroomlight
fill 302 170 622 302 170 623 minecraft:shroomlight
fill 302 170 625 305 170 626 minecraft:shroomlight
setblock 303 170 622 minecraft:shroomlight
fill 305 170 622 305 170 624 minecraft:shroomlight
setblock 306 170 624 minecraft:shroomlight
setblock 315 170 604 minecraft:amethyst_block
setblock 320 170 604 minecraft:pearlescent_froglight
fill 321 170 604 324 178 604 minecraft:light_blue_concrete
setblock 324 170 623 minecraft:white_concrete
fill 324 170 624 324 173 627 minecraft:light_blue_concrete
setblock 324 170 630 minecraft:white_concrete
setblock 282 171 633 minecraft:white_concrete
fill 284 171 604 284 196 604 minecraft:light_blue_concrete
setblock 285 171 604 minecraft:white_concrete
fill 286 171 604 286 188 604 minecraft:light_blue_concrete
fill 300 171 622 300 171 626 minecraft:shroomlight
fill 301 171 621 301 171 623 minecraft:shroomlight
fill 301 171 624 302 180 624 minecraft:gold_block
fill 301 171 625 301 171 627 minecraft:shroomlight
fill 302 171 620 305 171 621 minecraft:shroomlight
fill 302 171 622 302 180 623 minecraft:gold_block
fill 302 171 625 305 180 626 minecraft:gold_block
fill 302 171 627 305 171 628 minecraft:shroomlight
fill 306 171 621 306 171 623 minecraft:shroomlight
fill 306 171 624 306 180 624 minecraft:gold_block
fill 306 171 625 306 171 627 minecraft:shroomlight
fill 307 171 622 307 171 626 minecraft:shroomlight
fill 315 171 604 315 235 604 minecraft:light_blue_concrete
fill 320 171 604 320 191 604 minecraft:light_blue_concrete
fill 324 171 623 324 178 623 minecraft:light_blue_concrete
fill 324 171 630 324 183 630 minecraft:light_blue_concrete
setblock 282 172 633 minecraft:pearlescent_froglight
fill 285 172 604 285 231 604 minecraft:light_blue_concrete
fill 299 172 622 299 172 626 minecraft:shroomlight
fill 300 172 620 300 172 621 minecraft:shroomlight
fill 300 172 622 300 178 626 minecraft:gold_block
fill 300 172 627 300 172 628 minecraft:shroomlight
setblock 301 172 620 minecraft:shroomlight
fill 301 172 621 301 180 623 minecraft:gold_block
fill 301 172 625 301 180 627 minecraft:gold_block
setblock 301 172 628 minecraft:shroomlight
fill 302 172 619 305 172 619 minecraft:shroomlight
fill 302 172 620 305 180 621 minecraft:gold_block
fill 302 172 627 305 178 628 minecraft:gold_block
fill 302 172 629 305 172 629 minecraft:shroomlight
fill 306 172 620 307 172 620 minecraft:shroomlight
fill 306 172 621 306 180 623 minecraft:gold_block
fill 306 172 625 306 180 627 minecraft:gold_block
fill 306 172 628 307 172 628 minecraft:shroomlight
setblock 307 172 621 minecraft:shroomlight
fill 307 172 622 307 178 626 minecraft:gold_block
setblock 307 172 627 minecraft:shroomlight
fill 308 172 622 308 172 626 minecraft:shroomlight
fill 324 172 608 324 231 610 minecraft:light_blue_concrete
setblock 324 172 611 minecraft:white_concrete
setblock 324 172 641 minecraft:pearlescent_froglight
setblock 282 173 622 minecraft:white_concrete
fill 282 173 633 282 231 633 minecraft:light_blue_concrete
fill 298 173 622 298 173 626 minecraft:shroomlight
fill 299 173 620 299 173 621 minecraft:shroomlight
fill 299 173 622 299 178 626 minecraft:gold_block
fill 299 173 627 299 173 628 minecraft:shroomlight
setblock 300 173 620 minecraft:shroomlight
fill 300 173 621 300 180 621 minecraft:gold_block
fill 300 173 627 300 180 627 minecraft:gold_block
setblock 300 173 628 minecraft:shroomlight
fill 301 173 619 302 173 619 minecraft:shroomlight
fill 301 173 620 301 180 620 minecraft:gold_block
fill 301 173 628 301 180 628 minecraft:gold_block
fill 301 173 629 302 173 629 minecraft:shroomlight
fill 303 173 618 304 180 618 minecraft:shroomlight
fill 303 173 619 304 180 619 minecraft:gold_block
fill 303 173 629 304 178 629 minecraft:gold_block
fill 303 173 630 304 180 630 minecraft:shroomlight
fill 305 173 619 306 173 619 minecraft:shroomlight
fill 305 173 629 306 173 629 minecraft:shroomlight
fill 306 173 620 306 178 620 minecraft:gold_block
fill 306 173 628 306 180 628 minecraft:gold_block
fill 307 173 620 308 173 620 minecraft:shroomlight
fill 307 173 621 307 180 621 minecraft:gold_block
fill 307 173 627 307 178 627 minecraft:gold_block
fill 307 173 628 308 173 628 minecraft:shroomlight
setblock 308 173 621 minecraft:shroomlight
fill 308 173 622 308 178 626 minecraft:gold_block
setblock 308 173 627 minecraft:shroomlight
fill 309 173 622 309 173 626 minecraft:shroomlight
fill 311 173 604 312 218 604 minecraft:light_blue_concrete
setblock 313 173 604 minecraft:white_concrete
fill 314 173 604 314 225 604 minecraft:light_blue_concrete
setblock 315 173 646 minecraft:white_concrete
setblock 319 173 646 minecraft:pearlescent_froglight
fill 320 173 646 321 180 646 minecraft:light_blue_concrete
fill 324 173 611 324 185 611 minecraft:light_blue_concrete
fill 324 173 641 324 199 641 minecraft:light_blue_concrete
fill 282 174 622 282 185 622 minecraft:light_blue_concrete
setblock 282 174 640 minecraft:pearlescent_froglight
setblock 285 174 607 minecraft:light[level=13]
setblock 285 174 615 minecraft:light[level=13]
setblock 285 174 623 minecraft:light[level=13]
setblock 285 174 631 minecraft:light[level=13]
setblock 285 174 639 minecraft:light[level=13]
fill 293 174 604 296 191 604 minecraft:light_blue_concrete
setblock 293 174 607 minecraft:light[level=13]
setblock 293 174 615 minecraft:light[level=13]
setblock 293 174 623 minecraft:light[level=13]
setblock 293 174 631 minecraft:light[level=13]
setblock 293 174 639 minecraft:light[level=13]
setblock 297 174 604 minecraft:amethyst_block
fill 297 174 624 297 179 624 minecraft:shroomlight
fill 298 174 604 299 210 604 minecraft:light_blue_concrete
fill 298 174 621 298 174 623 minecraft:shroomlight
fill 298 174 624 298 178 624 minecraft:gold_block
fill 298 174 625 298 174 627 minecraft:shroomlight
setblock 299 174 620 minecraft:shroomlight
fill 299 174 621 299 179 621 minecraft:gold_block
fill 299 174 627 299 179 627 minecraft:gold_block
setblock 299 174 628 minecraft:shroomlight
fill 300 174 619 300 175 619 minecraft:shroomlight
fill 300 174 620 300 179 620 minecraft:gold_block
fill 300 174 628 300 179 628 minecraft:gold_block
fill 300 174 629 300 175 629 minecraft:shroomlight
setblock 301 174 607 minecraft:light[level=13]
setblock 301 174 615 minecraft:light[level=13]
fill 301 174 618 302 179 618 minecraft:shroomlight
fill 301 174 619 302 179 619 minecraft:gold_block
fill 301 174 629 302 178 629 minecraft:gold_block
fill 301 174 630 302 179 630 minecraft:shroomlight
setblock 301 174 631 minecraft:light[level=13]
setblock 301 174 639 minecraft:light[level=13]
fill 305 174 618 306 178 618 minecraft:shroomlight
fill 305 174 619 306 178 619 minecraft:gold_block
fill 305 174 629 306 179 629 minecraft:gold_block
fill 305 174 630 306 179 630 minecraft:shroomlight
fill 307 174 619 307 175 619 minecraft:shroomlight
fill 307 174 620 307 178 620 minecraft:gold_block
fill 307 174 628 307 179 628 minecraft:gold_block
fill 307 174 629 307 175 629 minecraft:shroomlight
setblock 308 174 620 minecraft:shroomlight
fill 308 174 621 308 179 621 minecraft:gold_block
fill 308 174 627 308 178 627 minecraft:gold_block
setblock 308 174 628 minecraft:shroomlight
setblock 309 174 607 minecraft:light[level=13]
setblock 309 174 615 minecraft:light[level=13]
fill 309 174 621 309 174 623 minecraft:shroomlight
fill 309 174 624 309 179 624 minecraft:gold_block
fill 309 174 625 309 174 627 minecraft:shroomlight
setblock 309 174 631 minecraft:light[level=13]
setblock 309 174 639 minecraft:light[level=13]
fill 310 174 624 310 179 624 minecraft:shroomlight
fill 313 174 604 313 235 604 minecraft:light_blue_concrete
fill 315 174 646 315 233 646 minecraft:light_blue_concrete
setblock 317 174 607 minecraft:light[level=13]
setblock 317 174 615 minecraft:light[level=13]
setblock 317 174 623 minecraft:light[level=13]
setblock 317 174 631 minecraft:light[level=13]
setblock 317 174 639 minecraft:light[level=13]
fill 319 174 646 319 232 646 minecraft:light_blue_concrete
fill 324 174 624 324 201 625 minecraft:light_blue_concrete
setblock 324 174 626 minecraft:pearlescent_froglight
fill 324 174 627 324 210 627 minecraft:light_blue_concrete
setblock 282 175 620 minecraft:amethyst_block
fill 282 175 640 282 205 640 minecraft:light_blue_concrete
setblock 296 175 646 minecraft:amethyst_block
fill 297 175 604 297 187 604 minecraft:light_blue_concrete
fill 297 175 622 297 178 623 minecraft:shroomlight
fill 297 175 625 297 178 626 minecraft:shroomlight
fill 297 175 646 298 200 646 minecraft:light_blue_concrete
fill 298 175 620 298 178 621 minecraft:shroomlight
fill 298 175 622 298 178 623 minecraft:gold_block
fill 298 175 625 298 178 626 minecraft:gold_block
fill 298 175 627 298 178 628 minecraft:shroomlight
fill 299 175 619 299 178 619 minecraft:shroomlight
fill 299 175 620 299 178 620 minecraft:gold_block
fill 299 175 628 299 178 628 minecraft:gold_block
fill 299 175 629 299 178 629 minecraft:shroomlight
fill 308 175 619 308 178 619 minecraft:shroomlight
fill 308 175 620 308 178 620 minecraft:gold_block
fill 308 175 628 308 178 628 minecraft:gold_block
fill 308 175 629 308 178 629 minecraft:shroomlight
fill 309 175 620 309 178 621 minecraft:shroomlight
fill 309 175 622 309 178 623 minecraft:gold_block
fill 309 175 625 309 178 626 minecraft:gold_block
fill 309 175 627 309 178 628 minecraft:shroomlight
fill 310 175 622 310 178 623 minecraft:shroomlight
fill 310 175 625 310 178 626 minecraft:shroomlight
fill 324 175 626 324 232 626 minecraft:light_blue_concrete
fill 282 176 620 282 218 620 minecraft:light_blue_concrete
fill 282 176 626 282 185 627 minecraft:light_blue_concrete
setblock 282 176 628 minecraft:white_concrete
fill 296 176 646 296 188 646 minecraft:light_blue_concrete
fill 300 176 618 300 177 618 minecraft:shroomlight
fill 300 176 619 300 177 619 minecraft:gold_block
fill 300 176 629 300 177 629 minecraft:gold_block
fill 300 176 630 300 177 630 minecraft:shroomlight
setblock 302 176 646 minecraft:white_concrete
fill 303 176 646 304 180 646 minecraft:light_blue_concrete
fill 307 176 618 307 177 618 minecraft:shroomlight
fill 307 176 619 307 177 619 minecraft:gold_block
fill 307 176 629 307 177 629 minecraft:gold_block
fill 307 176 630 307 177 630 minecraft:shroomlight
setblock 317 176 604 minecraft:white_concrete
fill 282 177 605 282 195 606 minecraft:light_blue_concrete
setblock 282 177 607 minecraft:amethyst_block
fill 282 177 608 282 192 608 minecraft:light_blue_concrete
fill 282 177 628 282 188 628 minecraft:light_blue_concrete
fill 302 177 646 302 235 646 minecraft:light_blue_concrete
fill 317 177 604 317 235 604 minecraft:light_blue_concrete
setblock 324 177 628 minecraft:white_concrete
fill 282 178 607 282 179 607 minecraft:light_blue_concrete
fill 300 178 619 300 179 619 minecraft:shroomlight
fill 300 178 629 300 179 629 minecraft:shroomlight
setblock 307 178 619 minecraft:shroomlight
fill 307 178 629 307 179 629 minecraft:shroomlight
fill 324 178 628 324 227 628 minecraft:light_blue_concrete
setblock 298 179 621 minecraft:shroomlight
fill 298 179 622 300 179 624 minecraft:redstone_block
fill 298 179 625 298 179 627 minecraft:shroomlight
fill 299 179 620 299 180 620 minecraft:shroomlight
fill 299 179 625 300 180 626 minecraft:gold_block
fill 299 179 628 299 180 628 minecraft:shroomlight
setblock 301 179 629 minecraft:gold_block
fill 302 179 627 304 179 629 minecraft:redstone_block
setblock 305 179 618 minecraft:shroomlight
setblock 305 179 619 minecraft:gold_block
fill 305 179 627 305 180 628 minecraft:gold_block
fill 306 179 618 308 179 620 minecraft:redstone_block
fill 307 179 622 308 180 624 minecraft:gold_block
fill 307 179 625 309 179 627 minecraft:redstone_block
fill 308 179 628 308 180 628 minecraft:shroomlight
fill 309 179 621 309 179 623 minecraft:shroomlight
fill 321 179 604 321 235 604 minecraft:light_blue_concrete
setblock 322 179 604 minecraft:pearlescent_froglight
fill 323 179 604 324 181 604 minecraft:light_blue_concrete
setblock 324 179 606 minecraft:pearlescent_froglight
setblock 324 179 623 minecraft:white_concrete
setblock 282 180 607 minecraft:amethyst_block
setblock 282 180 634 minecraft:pearlescent_froglight
fill 282 180 635 282 228 635 minecraft:light_blue_concrete
fill 298 180 625 298 180 626 minecraft:shroomlight
setblock 299 180 621 minecraft:shroomlight
setblock 299 180 627 minecraft:shroomlight
setblock 300 180 604 minecraft:white_concrete
fill 300 180 620 300 181 620 minecraft:shroomlight
fill 300 180 628 300 181 628 minecraft:shroomlight
fill 301 180 619 302 180 619 minecraft:shroomlight
setblock 301 180 629 minecraft:shroomlight
setblock 305 180 619 minecraft:shroomlight
fill 305 180 629 306 180 629 minecraft:shroomlight
setblock 307 180 628 minecraft:shroomlight
setblock 308 180 621 minecraft:shroomlight
fill 309 180 622 309 180 624 minecraft:shroomlight
fill 322 180 604 322 226 604 minecraft:light_blue_concrete
fill 324 180 606 324 184 606 minecraft:light_blue_concrete
setblock 324 180 617 minecraft:white_concrete
fill 324 180 618 324 180 620 minecraft:light_blue_concrete
setblock 324 180 621 minecraft:white_concrete
fill 324 180 622 324 194 623 minecraft:light_blue_concrete
setblock 324 180 631 minecraft:amethyst_block
fill 324 180 632 324 202 633 minecraft:light_blue_concrete
fill 282 181 607 282 236 607 minecraft:light_blue_concrete
fill 282 181 630 282 204 630 minecraft:light_blue_concrete
setblock 282 181 631 minecraft:white_concrete
fill 282 181 634 282 230 634 minecraft:light_blue_concrete
setblock 282 181 641 minecraft:amethyst_block
fill 282 181 642 282 187 642 minecraft:light_blue_concrete
setblock 283 181 604 minecraft:white_concrete
fill 283 181 605 296 181 645 minecraft:obsidian
fill 297 181 605 299 181 620 minecraft:obsidian
fill 297 181 621 297 181 625 minecraft:pearlescent_froglight
fill 297 181 626 298 181 645 minecraft:obsidian
fill 298 181 621 309 181 621 minecraft:pearlescent_froglight
fill 298 181 622 300 181 624 minecraft:obsidian
fill 298 181 625 306 181 625 minecraft:pearlescent_froglight
setblock 299 181 626 minecraft:shroomlight
fill 299 181 627 299 181 645 minecraft:obsidian
fill 300 181 604 300 203 604 minecraft:light_blue_concrete
fill 300 181 605 301 181 619 minecraft:obsidian
setblock 300 181 626 minecraft:gold_block
setblock 300 181 627 minecraft:shroomlight
fill 300 181 629 300 181 645 minecraft:obsidian
setblock 301 181 620 minecraft:shroomlight
fill 301 181 622 302 181 624 minecraft:pearlescent_froglight
fill 301 181 626 301 181 630 minecraft:pearlescent_froglight
fill 301 181 631 323 181 645 minecraft:obsidian
fill 302 181 605 304 181 618 minecraft:obsidian
fill 302 181 619 304 181 619 minecraft:shroomlight
fill 302 181 620 304 181 620 minecraft:gold_block
fill 302 181 626 306 181 626 minecraft:pearlescent_froglight
fill 302 181 627 304 181 629 minecraft:obsidian
fill 302 181 630 305 181 630 minecraft:pearlescent_froglight
setblock 303 181 646 minecraft:pearlescent_froglight
fill 304 181 646 304 231 646 minecraft:light_blue_concrete
fill 305 181 605 323 181 616 minecraft:obsidian
fill 305 181 617 305 181 620 minecraft:pearlescent_froglight
fill 305 181 627 305 181 629 minecraft:pearlescent_froglight
fill 306 181 617 309 181 617 minecraft:pearlescent_froglight
fill 306 181 618 308 181 620 minecraft:obsidian
fill 306 181 622 306 181 624 minecraft:pearlescent_froglight
fill 306 181 627 306 181 628 minecraft:pearlescent_froglight
fill 306 181 629 323 181 630 minecraft:obsidian
fill 307 181 622 307 181 623 minecraft:gold_block
fill 307 181 624 310 181 624 minecraft:pearlescent_froglight
fill 307 181 625 309 181 627 minecraft:obsidian
fill 307 181 628 310 181 628 minecraft:pearlescent_froglight
fill 308 181 622 308 181 623 minecraft:shroomlight
fill 309 181 618 309 181 620 minecraft:pearlescent_froglight
fill 309 181 622 323 181 623 minecraft:obsidian
fill 310 181 617 323 181 621 minecraft:obsidian
fill 310 181 625 310 181 627 minecraft:pearlescent_froglight
fill 311 181 624 323 181 628 minecraft:obsidian
setblock 320 181 646 minecraft:pearlescent_froglight
fill 321 181 646 321 189 646 minecraft:light_blue_concrete
fill 324 181 617 324 235 618 minecraft:light_blue_concrete
setblock 324 181 619 minecraft:amethyst_block
fill 324 181 620 324 218 621 minecraft:light_blue_concrete
fill 324 181 631 324 222 631 minecraft:light_blue_concrete
setblock 282 182 618 minecraft:amethyst_block
fill 282 182 631 282 191 631 minecraft:light_blue_concrete
fill 282 182 641 282 235 641 minecraft:light_blue_concrete
fill 283 182 604 283 227 604 minecraft:light_blue_concrete
setblock 285 182 607 minecraft:light[level=13]
setblock 285 182 615 minecraft:light[level=13]
setblock 285 182 623 minecraft:light[level=13]
setblock 285 182 631 minecraft:light[level=13]
setblock 285 182 639 minecraft:light[level=13]
setblock 293 182 607 minecraft:light[level=13]
setblock 293 182 615 minecraft:light[level=13]
setblock 293 182 623 minecraft:light[level=13]
setblock 293 182 631 minecraft:light[level=13]
setblock 293 182 639 minecraft:light[level=13]
fill 300 182 622 300 182 626 minecraft:shroomlight
setblock 301 182 607 minecraft:light[level=13]
setblock 301 182 615 minecraft:light[level=13]
fill 301 182 621 301 182 623 minecraft:shroomlight
fill 301 182 624 302 182 624 minecraft:gold_block
fill 301 182 625 301 182 627 minecraft:shroomlight
setblock 301 182 631 minecraft:light[level=13]
setblock 301 182 639 minecraft:light[level=13]
fill 302 182 620 305 182 621 minecraft:shroomlight
fill 302 182 622 302 182 623 minecraft:gold_block
fill 302 182 625 305 182 626 minecraft:gold_block
fill 302 182 627 305 182 628 minecraft:shroomlight
fill 303 182 646 303 207 646 minecraft:light_blue_concrete
fill 306 182 621 306 182 623 minecraft:shroomlight
setblock 306 182 624 minecraft:gold_block
fill 306 182 625 306 182 627 minecraft:shroomlight
fill 307 182 622 307 182 626 minecraft:shroomlight
setblock 309 182 607 minecraft:light[level=13]
setblock 309 182 615 minecraft:light[level=13]
setblock 309 182 623 minecraft:light[level=13]
setblock 309 182 631 minecraft:light[level=13]
setblock 309 182 639 minecraft:light[level=13]
setblock 317 182 607 minecraft:light[level=13]
setblock 317 182 615 minecraft:light[level=13]
setblock 317 182 623 minecraft:light[level=13]
setblock 317 182 631 minecraft:light[level=13]
setblock 317 182 639 minecraft:light[level=13]
fill 320 182 646 320 231 646 minecraft:light_blue_concrete
setblock 323 182 604 minecraft:pearlescent_froglight
fill 324 182 604 324 233 604 minecraft:light_blue_concrete
setblock 324 182 614 minecraft:amethyst_block
fill 324 182 615 324 233 615 minecraft:light_blue_concrete
fill 324 182 619 324 195 619 minecraft:light_blue_concrete
fill 282 183 618 282 235 618 minecraft:light_blue_concrete
setblock 282 183 643 minecraft:white_concrete
fill 301 183 624 302 183 624 minecraft:shroomlight
fill 302 183 622 302 183 623 minecraft:shroomlight
fill 302 183 625 305 183 626 minecraft:shroomlight
setblock 306 183 624 minecraft:shroomlight
fill 323 183 604 323 235 604 minecraft:light_blue_concrete
fill 324 183 614 324 188 614 minecraft:light_blue_concrete
fill 324 183 635 324 235 635 minecraft:light_blue_concrete
setblock 324 183 636 minecraft:amethyst_block
fill 324 183 637 324 184 640 minecraft:light_blue_concrete
setblock 282 184 636 minecraft:white_concrete
fill 282 184 637 282 208 638 minecraft:light_blue_concrete
fill 282 184 643 282 232 643 minecraft:light_blue_concrete
setblock 282 184 645 minecraft:white_concrete
setblock 324 184 630 minecraft:white_concrete
fill 324 184 636 324 208 636 minecraft:light_blue_concrete
fill 282 185 636 282 235 636 minecraft:light_blue_concrete
fill 282 185 645 282 235 645 minecraft:light_blue_concrete
setblock 324 185 606 minecraft:pearlescent_froglight
fill 324 185 630 324 188 630 minecraft:light_blue_concrete
setblock 324 185 637 minecraft:white_concrete
fill 324 185 638 324 231 640 minecraft:light_blue_concrete
setblock 282 186 622 minecraft:pearlescent_froglight
fill 282 186 626 282 233 626 minecraft:light_blue_concrete
setblock 282 186 627 minecraft:amethyst_block
fill 296 186 638 298 193 639 minecraft:yellow_concrete
fill 297 186 637 297 193 637 minecraft:yellow_concrete
fill 297 186 640 297 193 640 minecraft:yellow_concrete
fill 324 186 606 324 231 606 minecraft:light_blue_concrete
setblock 324 186 611 minecraft:pearlescent_froglight
setblock 324 186 629 minecraft:pearlescent_froglight
fill 324 186 637 324 201 637 minecraft:light_blue_concrete
fill 282 187 622 282 229 622 minecraft:light_blue_concrete
fill 282 187 627 282 200 627 minecraft:light_blue_concrete
setblock 282 187 644 minecraft:white_concrete
fill 295 187 637 295 192 640 minecraft:yellow_concrete
fill 296 187 636 296 192 637 minecraft:yellow_concrete
fill 296 187 640 296 192 641 minecraft:yellow_concrete
fill 297 187 636 298 192 636 minecraft:yellow_concrete
fill 297 187 641 298 192 641 minecraft:yellow_concrete
fill 298 187 637 299 192 637 minecraft:yellow_concrete
fill 298 187 640 299 192 640 minecraft:yellow_concrete
fill 299 187 638 300 192 639 minecraft:yellow_concrete
setblock 316 187 604 minecraft:pearlescent_froglight
fill 324 187 611 324 233 611 minecraft:light_blue_concrete
fill 324 187 629 324 210 629 minecraft:light_blue_concrete
setblock 282 188 642 minecraft:white_concrete
setblock 282 188 644 minecraft:light_blue_concrete
setblock 287 188 604 minecraft:pearlescent_froglight
fill 288 188 604 289 222 604 minecraft:light_blue_concrete
fill 294 188 637 294 191 640 minecraft:yellow_concrete
fill 295 188 636 295 191 636 minecraft:yellow_concrete
fill 295 188 641 295 191 641 minecraft:yellow_concrete
setblock 297 188 604 minecraft:amethyst_block
fill 297 188 635 297 191 635 minecraft:yellow_concrete
fill 297 188 642 297 191 642 minecraft:yellow_concrete
fill 299 188 636 299 191 636 minecraft:yellow_concrete
fill 299 188 641 299 191 641 minecraft:yellow_concrete
fill 300 188 637 300 191 637 minecraft:yellow_concrete
fill 300 188 640 300 191 640 minecraft:yellow_concrete
fill 301 188 604 303 188 604 minecraft:light_blue_concrete
setblock 304 188 604 minecraft:pearlescent_froglight
fill 305 188 604 307 197 604 minecraft:light_blue_concrete
fill 316 188 604 316 231 604 minecraft:light_blue_concrete
fill 321 188 627 321 189 629 minecraft:white_concrete
fill 322 188 628 322 189 628 minecraft:white_concrete
fill 282 189 612 282 191 612 minecraft:gold_block
fill 282 189 628 282 191 628 minecraft:gold_block
fill 282 189 642 282 204 642 minecraft:light_blue_concrete
fill 282 189 644 282 191 644 minecraft:gold_block
fill 286 189 604 286 191 604 minecraft:gold_block
fill 287 189 604 287 235 604 minecraft:light_blue_concrete
fill 295 189 616 297 190 616 minecraft:white_concrete
fill 296 189 615 297 190 615 minecraft:white_concrete
fill 296 189 635 296 190 635 minecraft:yellow_concrete
fill 296 189 642 296 190 642 minecraft:yellow_concrete
fill 296 189 646 296 191 646 minecraft:gold_block
fill 297 189 604 297 235 604 minecraft:light_blue_concrete
fill 298 189 635 298 190 635 minecraft:yellow_concrete
fill 298 189 642 298 190 642 minecraft:yellow_concrete
fill 300 189 636 300 190 636 minecraft:yellow_concrete
fill 300 189 641 300 190 641 minecraft:yellow_concrete
fill 301 189 604 301 235 604 minecraft:light_blue_concrete
fill 302 189 604 302 191 604 minecraft:gold_block
fill 303 189 604 304 217 604 minecraft:light_blue_concrete
setblock 309 189 604 minecraft:pearlescent_froglight
fill 312 189 646 312 191 646 minecraft:gold_block
setblock 316 189 646 minecraft:pearlescent_froglight
fill 317 189 646 317 233 646 minecraft:light_blue_concrete
fill 318 189 604 318 191 604 minecraft:gold_block
fill 324 189 614 324 191 614 minecraft:gold_block
fill 324 189 630 324 191 630 minecraft:gold_block
setblock 285 190 607 minecraft:light[level=13]
setblock 285 190 615 minecraft:light[level=13]
setblock 285 190 623 minecraft:light[level=13]
setblock 285 190 631 minecraft:light[level=13]
setblock 285 190 639 minecraft:light[level=13]
setblock 293 190 607 minecraft:light[level=13]
setblock 293 190 615 minecraft:light[level=13]
setblock 293 190 623 minecraft:light[level=13]
setblock 293 190 631 minecraft:light[level=13]
setblock 293 190 639 minecraft:light[level=13]
setblock 301 190 607 minecraft:light[level=13]
setblock 301 190 615 minecraft:light[level=13]
setblock 301 190 623 minecraft:light[level=13]
setblock 301 190 631 minecraft:light[level=13]
setblock 301 190 639 minecraft:light[level=13]
fill 309 190 604 309 235 604 minecraft:light_blue_concrete
setblock 309 190 607 minecraft:light[level=13]
setblock 309 190 615 minecraft:light[level=13]
setblock 309 190 623 minecraft:light[level=13]
setblock 309 190 631 minecraft:light[level=13]
setblock 309 190 639 minecraft:light[level=13]
fill 316 190 646 316 235 646 minecraft:light_blue_concrete
setblock 317 190 607 minecraft:light[level=13]
setblock 317 190 615 minecraft:light[level=13]
setblock 317 190 623 minecraft:light[level=13]
setblock 317 190 631 minecraft:light[level=13]
setblock 317 190 639 minecraft:light[level=13]
setblock 321 190 646 minecraft:amethyst_block
fill 321 191 646 321 235 646 minecraft:light_blue_concrete
fill 282 192 612 282 197 612 minecraft:light_blue_concrete
fill 282 192 628 282 197 628 minecraft:light_blue_concrete
setblock 282 192 631 minecraft:white_concrete
fill 282 192 644 282 197 644 minecraft:light_blue_concrete
fill 286 192 604 286 197 604 minecraft:light_blue_concrete
fill 290 192 604 290 207 604 minecraft:light_blue_concrete
setblock 291 192 604 minecraft:amethyst_block
fill 293 192 604 294 214 604 minecraft:light_blue_concrete
setblock 295 192 604 minecraft:pearlescent_froglight
fill 296 192 604 296 233 604 minecraft:light_blue_concrete
fill 296 192 646 296 195 646 minecraft:light_blue_concrete
fill 302 192 604 302 197 604 minecraft:light_blue_concrete
fill 312 192 646 312 197 646 minecraft:light_blue_concrete
fill 318 192 604 318 197 604 minecraft:light_blue_concrete
setblock 320 192 604 minecraft:white_concrete
fill 324 192 614 324 197 614 minecraft:light_blue_concrete
fill 324 192 630 324 197 630 minecraft:light_blue_concrete
setblock 324 192 642 minecraft:pearlescent_froglight
fill 324 192 643 324 233 646 minecraft:light_blue_concrete
setblock 282 193 608 minecraft:pearlescent_froglight
fill 282 193 631 282 199 631 minecraft:light_blue_concrete
fill 291 193 604 291 223 604 minecraft:light_blue_concrete
fill 295 193 604 295 231 604 minecraft:light_blue_concrete
fill 320 193 604 320 210 604 minecraft:light_blue_concrete
fill 324 193 642 324 231 642 minecraft:light_blue_concrete
fill 282 194 608 282 204 608 minecraft:light_blue_concrete
fill 288 194 633 289 195 634 minecraft:white_concrete
fill 321 194 610 323 197 612 minecraft:amethyst_block
setblock 293 195 646 minecraft:amethyst_block
fill 308 195 646 308 235 646 minecraft:light_blue_concrete
setblock 309 195 646 minecraft:amethyst_block
fill 310 195 646 311 235 646 minecraft:light_blue_concrete
fill 313 195 619 313 196 619 minecraft:obsidian
fill 320 195 610 320 198 612 minecraft:amethyst_block
fill 321 195 609 323 196 609 minecraft:amethyst_block
fill 321 195 613 323 196 613 minecraft:amethyst_block
setblock 324 195 622 minecraft:pearlescent_froglight
fill 324 195 623 324 205 623 minecraft:light_blue_concrete
setblock 282 196 605 minecraft:white_concrete
fill 282 196 606 282 235 606 minecraft:light_blue_concrete
setblock 287 196 646 minecraft:white_concrete
fill 288 196 646 293 212 646 minecraft:light_blue_concrete
setblock 296 196 646 minecraft:white_concrete
fill 297 196 630 297 197 630 minecraft:obsidian
fill 309 196 646 309 235 646 minecraft:light_blue_concrete
fill 319 196 610 319 198 612 minecraft:amethyst_block
setblock 324 196 619 minecraft:amethyst_block
fill 324 196 622 324 235 622 minecraft:light_blue_concrete
fill 282 197 605 282 214 605 minecraft:light_blue_concrete
setblock 284 197 604 minecraft:pearlescent_froglight
fill 287 197 646 287 235 646 minecraft:light_blue_concrete
setblock 296 197 646 minecraft:light_blue_concrete
fill 300 197 634 302 198 634 minecraft:end_stone
fill 301 197 633 302 198 633 minecraft:end_stone
fill 316 197 616 316 198 616 minecraft:obsidian
fill 317 197 611 318 198 611 minecraft:amethyst_block
fill 318 197 610 318 198 610 minecraft:amethyst_block
fill 318 197 612 318 198 612 minecraft:amethyst_block
fill 324 197 619 324 235 619 minecraft:light_blue_concrete
fill 282 198 612 282 200 612 minecraft:gold_block
setblock 282 198 625 minecraft:amethyst_block
fill 282 198 628 282 200 628 minecraft:gold_block
fill 282 198 644 282 200 644 minecraft:gold_block
fill 284 198 604 284 235 604 minecraft:light_blue_concrete
setblock 285 198 607 minecraft:light[level=13]
setblock 285 198 615 minecraft:light[level=13]
setblock 285 198 623 minecraft:light[level=13]
setblock 285 198 631 minecraft:light[level=13]
setblock 285 198 639 minecraft:light[level=13]
fill 286 198 604 286 200 604 minecraft:gold_block
setblock 293 198 607 minecraft:light[level=13]
setblock 293 198 615 minecraft:light[level=13]
setblock 293 198 623 minecraft:light[level=13]
setblock 293 198 631 minecraft:light[level=13]
setblock 293 198 639 minecraft:light[level=13]
fill 296 198 646 296 200 646 minecraft:gold_block
setblock 301 198 607 minecraft:light[level=13]
setblock 301 198 615 minecraft:light[level=13]
setblock 301 198 623 minecraft:light[level=13]
setblock 301 198 631 minecraft:light[level=13]
setblock 301 198 639 minecraft:light[level=13]
fill 302 198 604 302 200 604 minecraft:gold_block
fill 305 198 604 306 229 604 minecraft:light_blue_concrete
setblock 307 198 604 minecraft:white_concrete
setblock 309 198 607 minecraft:light[level=13]
setblock 309 198 615 minecraft:light[level=13]
setblock 309 198 623 minecraft:light[level=13]
setblock 309 198 631 minecraft:light[level=13]
setblock 309 198 639 minecraft:light[level=13]
fill 312 198 646 312 200 646 minecraft:gold_block
fill 316 198 611 316 199 611 minecraft:amethyst_block
setblock 317 198 607 minecraft:light[level=13]
setblock 317 198 610 minecraft:amethyst_block
setblock 317 198 612 minecraft:amethyst_block
setblock 317 198 615 minecraft:light[level=13]
setblock 317 198 623 minecraft:light[level=13]
setblock 317 198 631 minecraft:light[level=13]
setblock 317 198 639 minecraft:light[level=13]
fill 318 198 604 318 200 604 minecraft:gold_block
setblock 321 198 611 minecraft:amethyst_block
fill 324 198 614 324 200 614 minecraft:gold_block
fill 324 198 630 324 200 630 minecraft:gold_block
fill 282 199 625 282 207 625 minecraft:light_blue_concrete
fill 295 199 639 296 200 640 minecraft:gold_block
fill 307 199 604 307 227 604 minecraft:light_blue_concrete
setblock 282 200 631 minecraft:pearlescent_froglight
setblock 324 200 641 minecraft:white_concrete
fill 282 201 612 282 206 612 minecraft:light_blue_concrete
setblock 282 201 627 minecraft:pearlescent_froglight
fill 282 201 628 282 206 628 minecraft:light_blue_concrete
setblock 282 201 631 minecraft:light_blue_concrete
fill 282 201 644 282 206 644 minecraft:light_blue_concrete
fill 286 201 604 286 206 604 minecraft:light_blue_concrete
fill 296 201 646 296 206 646 minecraft:light_blue_concrete
setblock 297 201 646 minecraft:pearlescent_froglight
setblock 298 201 646 minecraft:white_concrete
fill 302 201 604 302 206 604 minecraft:light_blue_concrete
fill 310 201 632 316 203 638 minecraft:stone
setblock 312 201 646 minecraft:white_concrete
fill 318 201 604 318 206 604 minecraft:light_blue_concrete
fill 324 201 614 324 206 614 minecraft:light_blue_concrete
fill 324 201 630 324 206 630 minecraft:light_blue_concrete
fill 324 201 641 324 238 641 minecraft:light_blue_concrete
fill 282 202 627 282 235 627 minecraft:light_blue_concrete
setblock 282 202 631 minecraft:pearlescent_froglight
fill 297 202 646 298 235 646 minecraft:light_blue_concrete
fill 312 202 646 312 206 646 minecraft:light_blue_concrete
setblock 324 202 624 minecraft:amethyst_block
fill 324 202 625 324 235 625 minecraft:light_blue_concrete
setblock 324 202 637 minecraft:amethyst_block
setblock 282 203 616 minecraft:white_concrete
fill 282 203 631 282 235 631 minecraft:light_blue_concrete
setblock 306 203 646 minecraft:pearlescent_froglight
fill 324 203 624 324 235 624 minecraft:light_blue_concrete
setblock 324 203 632 minecraft:white_concrete
fill 324 203 633 324 224 633 minecraft:light_blue_concrete
fill 324 203 637 324 235 637 minecraft:light_blue_concrete
fill 282 204 616 282 235 616 minecraft:light_blue_concrete
setblock 292 204 604 minecraft:white_concrete
setblock 300 204 604 minecraft:amethyst_block
fill 306 204 646 306 236 646 minecraft:light_blue_concrete
fill 310 204 632 316 206 638 minecraft:dirt
fill 320 204 640 323 207 640 minecraft:amethyst_block
fill 321 204 639 323 207 639 minecraft:amethyst_block
fill 321 204 641 323 207 641 minecraft:amethyst_block
fill 324 204 632 324 235 632 minecraft:light_blue_concrete
setblock 282 205 608 minecraft:white_concrete
setblock 282 205 630 minecraft:amethyst_block
setblock 282 205 642 minecraft:pearlescent_froglight
setblock 292 205 604 minecraft:pearlescent_froglight
fill 292 205 634 292 206 634 minecraft:amethyst_block
fill 300 205 604 300 208 604 minecraft:light_blue_concrete
fill 319 205 639 319 207 641 minecraft:amethyst_block
fill 320 205 639 320 207 639 minecraft:amethyst_block
fill 320 205 641 320 207 641 minecraft:amethyst_block
fill 322 205 638 322 206 638 minecraft:amethyst_block
fill 322 205 642 322 206 642 minecraft:amethyst_block
fill 282 206 608 282 235 608 minecraft:light_blue_concrete
fill 282 206 630 282 231 630 minecraft:light_blue_concrete
setblock 282 206 640 minecraft:pearlescent_froglight
fill 282 206 642 282 228 642 minecraft:light_blue_concrete
setblock 285 206 607 minecraft:light[level=13]
setblock 285 206 615 minecraft:light[level=13]
setblock 285 206 623 minecraft:light[level=13]
setblock 285 206 631 minecraft:light[level=13]
setblock 285 206 639 minecraft:light[level=13]
fill 292 206 604 292 231 604 minecraft:light_blue_concrete
setblock 293 206 607 minecraft:light[level=13]
setblock 293 206 615 minecraft:light[level=13]
setblock 293 206 623 minecraft:light[level=13]
setblock 293 206 631 minecraft:light[level=13]
setblock 293 206 639 minecraft:light[level=13]
setblock 301 206 607 minecraft:light[level=13]
setblock 301 206 615 minecraft:light[level=13]
setblock 301 206 623 minecraft:light[level=13]
setblock 301 206 631 minecraft:light[level=13]
setblock 301 206 639 minecraft:light[level=13]
setblock 309 206 607 minecraft:light[level=13]
setblock 309 206 615 minecraft:light[level=13]
setblock 309 206 623 minecraft:light[level=13]
setblock 309 206 631 minecraft:light[level=13]
setblock 309 206 639 minecraft:light[level=13]
setblock 317 206 607 minecraft:light[level=13]
setblock 317 206 615 minecraft:light[level=13]
setblock 317 206 623 minecraft:light[level=13]
setblock 317 206 631 minecraft:light[level=13]
setblock 317 206 639 minecraft:light[level=13]
fill 317 206 640 318 207 640 minecraft:amethyst_block
fill 318 206 639 318 207 639 minecraft:amethyst_block
fill 318 206 641 318 207 641 minecraft:amethyst_block
setblock 324 206 623 minecraft:pearlescent_froglight
fill 282 207 612 282 209 612 minecraft:gold_block
fill 282 207 628 282 209 628 minecraft:gold_block
fill 282 207 640 282 236 640 minecraft:light_blue_concrete
fill 282 207 644 282 209 644 minecraft:gold_block
fill 286 207 604 286 209 604 minecraft:gold_block
fill 286 207 626 292 209 632 minecraft:stone
fill 292 207 634 292 215 634 minecraft:black_concrete
fill 296 207 646 296 209 646 minecraft:gold_block
setblock 300 207 646 minecraft:amethyst_block
fill 302 207 604 302 209 604 minecraft:gold_block
fill 310 207 613 310 208 613 minecraft:gold_block
fill 310 207 632 316 207 638 minecraft:moss_block
fill 312 207 646 312 209 646 minecraft:gold_block
setblock 316 207 640 minecraft:amethyst_block
fill 318 207 604 318 209 604 minecraft:gold_block
fill 324 207 614 324 209 614 minecraft:gold_block
fill 324 207 623 324 231 623 minecraft:light_blue_concrete
fill 324 207 630 324 209 630 minecraft:gold_block
setblock 282 208 625 minecraft:amethyst_block
setblock 290 208 604 minecraft:amethyst_block
fill 300 208 646 300 235 646 minecraft:light_blue_concrete
setblock 303 208 646 minecraft:white_concrete
fill 313 208 635 313 212 635 minecraft:oak_log
fill 282 209 625 282 235 625 minecraft:light_blue_concrete
fill 282 209 637 282 226 637 minecraft:light_blue_concrete
setblock 282 209 638 minecraft:amethyst_block
fill 290 209 604 290 235 604 minecraft:light_blue_concrete
fill 292 209 633 293 215 633 minecraft:black_concrete
fill 293 209 634 293 215 634 minecraft:black_concrete
setblock 300 209 604 minecraft:white_concrete
fill 303 209 646 303 210 646 minecraft:light_blue_concrete
setblock 324 209 636 minecraft:amethyst_block
fill 282 210 612 282 215 612 minecraft:light_blue_concrete
fill 282 210 628 282 215 628 minecraft:light_blue_concrete
fill 282 210 638 282 233 638 minecraft:light_blue_concrete
fill 282 210 644 282 215 644 minecraft:light_blue_concrete
fill 286 210 604 286 215 604 minecraft:light_blue_concrete
fill 286 210 626 292 212 632 minecraft:dirt
fill 291 210 633 291 215 634 minecraft:black_concrete
fill 292 210 635 293 215 635 minecraft:black_concrete
fill 296 210 646 296 215 646 minecraft:light_blue_concrete
fill 300 210 604 300 231 604 minecraft:light_blue_concrete
fill 302 210 604 302 215 604 minecraft:light_blue_concrete
setblock 307 210 646 minecraft:pearlescent_froglight
fill 312 210 646 312 215 646 minecraft:light_blue_concrete
fill 318 210 604 318 215 604 minecraft:light_blue_concrete
fill 324 210 614 324 215 614 minecraft:light_blue_concrete
fill 324 210 630 324 215 630 minecraft:light_blue_concrete
fill 324 210 636 324 235 636 minecraft:light_blue_concrete
setblock 282 211 629 minecraft:white_concrete
fill 291 211 635 291 215 635 minecraft:black_concrete
fill 293 211 632 293 215 632 minecraft:black_concrete
fill 294 211 633 294 215 634 minecraft:black_concrete
fill 298 211 604 298 236 604 minecraft:light_blue_concrete
setblock 299 211 604 minecraft:white_concrete
setblock 303 211 646 minecraft:amethyst_block
fill 307 211 646 307 236 646 minecraft:light_blue_concrete
fill 313 211 614 315 218 616 minecraft:yellow_concrete
setblock 320 211 604 minecraft:white_concrete
setblock 324 211 627 minecraft:amethyst_block
setblock 324 211 629 minecraft:white_concrete
fill 282 212 629 282 231 629 minecraft:light_blue_concrete
fill 290 212 633 290 215 634 minecraft:black_concrete
fill 292 212 636 293 215 636 minecraft:black_concrete
fill 294 212 632 294 215 632 minecraft:black_concrete
fill 294 212 635 294 215 635 minecraft:black_concrete
fill 299 212 604 299 232 604 minecraft:light_blue_concrete
fill 303 212 646 303 228 646 minecraft:light_blue_concrete
fill 312 212 613 312 217 617 minecraft:yellow_concrete
fill 313 212 613 316 217 613 minecraft:yellow_concrete
fill 313 212 617 316 217 617 minecraft:yellow_concrete
fill 314 212 635 314 216 635 minecraft:oak_leaves[persistent=true]
fill 316 212 614 316 217 616 minecraft:yellow_concrete
fill 317 212 615 317 217 615 minecraft:yellow_concrete
fill 320 212 604 320 235 604 minecraft:light_blue_concrete
fill 324 212 627 324 228 627 minecraft:light_blue_concrete
fill 324 212 629 324 224 629 minecraft:light_blue_concrete
fill 286 213 626 292 213 632 minecraft:moss_block
fill 288 213 646 291 231 646 minecraft:light_blue_concrete
fill 290 213 635 290 215 635 minecraft:black_concrete
fill 291 213 636 291 215 636 minecraft:black_concrete
setblock 292 213 646 minecraft:amethyst_block
fill 293 213 631 293 215 631 minecraft:black_concrete
fill 293 213 646 293 235 646 minecraft:light_blue_concrete
fill 294 213 636 294 215 636 minecraft:black_concrete
fill 295 213 633 295 215 634 minecraft:black_concrete
fill 297 213 608 303 215 614 minecraft:stone
fill 311 213 614 311 216 616 minecraft:yellow_concrete
fill 312 213 634 313 215 636 minecraft:oak_leaves[persistent=true]
fill 313 213 612 315 216 612 minecraft:yellow_concrete
fill 313 213 618 316 216 618 minecraft:yellow_concrete
fill 313 213 637 313 215 637 minecraft:oak_leaves[persistent=true]
fill 314 213 634 314 215 634 minecraft:oak_leaves[persistent=true]
fill 314 213 636 315 215 636 minecraft:oak_leaves[persistent=true]
fill 315 213 635 315 215 635 minecraft:oak_leaves[persistent=true]
fill 317 213 614 317 216 614 minecraft:yellow_concrete
fill 317 213 616 317 216 617 minecraft:yellow_concrete
setblock 285 214 607 minecraft:light[level=13]
setblock 285 214 615 minecraft:light[level=13]
setblock 285 214 623 minecraft:light[level=13]
setblock 285 214 631 minecraft:light[level=13]
setblock 285 214 639 minecraft:light[level=13]
fill 289 214 629 289 216 629 minecraft:oak_log
fill 289 214 633 289 215 635 minecraft:black_concrete
fill 290 214 631 292 215 632 minecraft:black_concrete
fill 290 214 636 290 215 636 minecraft:black_concrete
fill 292 214 637 293 215 637 minecraft:black_concrete
fill 292 214 646 292 235 646 minecraft:light_blue_concrete
setblock 293 214 607 minecraft:light[level=13]
setblock 293 214 615 minecraft:light[level=13]
setblock 293 214 623 minecraft:light[level=13]
setblock 293 214 639 minecraft:light[level=13]
fill 294 214 631 294 215 631 minecraft:black_concrete
fill 295 214 632 295 215 632 minecraft:black_concrete
fill 295 214 635 295 215 635 minecraft:black_concrete
setblock 301 214 607 minecraft:light[level=13]
setblock 301 214 615 minecraft:light[level=13]
setblock 301 214 623 minecraft:light[level=13]
setblock 301 214 631 minecraft:light[level=13]
setblock 301 214 639 minecraft:light[level=13]
setblock 309 214 607 minecraft:light[level=13]
setblock 309 214 615 minecraft:light[level=13]
setblock 309 214 623 minecraft:light[level=13]
setblock 309 214 631 minecraft:light[level=13]
setblock 309 214 639 minecraft:light[level=13]
fill 311 214 613 311 215 613 minecraft:yellow_concrete
fill 311 214 617 311 215 617 minecraft:yellow_concrete
fill 312 214 612 312 215 612 minecraft:yellow_concrete
fill 312 214 618 312 215 618 minecraft:yellow_concrete
setblock 313 214 633 minecraft:oak_leaves[persistent=true]
setblock 314 214 637 minecraft:oak_leaves[persistent=true]
setblock 315 214 634 minecraft:oak_leaves[persistent=true]
fill 316 214 612 316 215 612 minecraft:yellow_concrete
setblock 317 214 607 minecraft:light[level=13]
fill 317 214 613 317 215 613 minecraft:yellow_concrete
setblock 317 214 623 minecraft:light[level=13]
setblock 317 214 631 minecraft:light[level=13]
setblock 317 214 639 minecraft:light[level=13]
setblock 282 215 605 minecraft:pearlescent_froglight
fill 289 215 626 290 222 626 minecraft:light_blue_concrete
setblock 289 215 632 minecraft:black_concrete
setblock 289 215 636 minecraft:black_concrete
fill 290 215 625 290 222 625 minecraft:light_blue_concrete
fill 291 215 630 293 215 630 minecraft:black_concrete
setblock 291 215 637 minecraft:black_concrete
fill 293 215 604 293 231 604 minecraft:light_blue_concrete
setblock 294 215 604 minecraft:amethyst_block
setblock 294 215 637 minecraft:black_concrete
setblock 295 215 631 minecraft:black_concrete
setblock 295 215 636 minecraft:black_concrete
fill 296 215 633 296 215 635 minecraft:black_concrete
fill 282 216 605 282 232 605 minecraft:light_blue_concrete
fill 282 216 612 282 218 612 minecraft:gold_block
fill 282 216 628 282 218 628 minecraft:gold_block
fill 282 216 644 282 218 644 minecraft:gold_block
fill 286 216 604 286 218 604 minecraft:gold_block
fill 288 216 624 288 221 627 minecraft:light_blue_concrete
fill 289 216 624 289 221 625 minecraft:light_blue_concrete
fill 289 216 627 291 221 628 minecraft:light_blue_concrete
fill 290 216 624 291 221 624 minecraft:light_blue_concrete
fill 291 216 625 292 221 626 minecraft:light_blue_concrete
fill 291 216 634 293 216 634 minecraft:amethyst_block
fill 292 216 627 292 221 627 minecraft:light_blue_concrete
fill 292 216 633 293 217 633 minecraft:amethyst_block
fill 294 216 604 294 227 604 minecraft:light_blue_concrete
fill 296 216 646 296 218 646 minecraft:gold_block
fill 297 216 608 303 218 614 minecraft:dirt
fill 302 216 604 302 218 604 minecraft:gold_block
fill 312 216 646 312 218 646 minecraft:gold_block
setblock 313 216 635 minecraft:oak_leaves[persistent=true]
setblock 313 216 646 minecraft:pearlescent_froglight
fill 314 216 646 314 235 646 minecraft:light_blue_concrete
fill 318 216 604 318 218 604 minecraft:gold_block
fill 324 216 614 324 218 614 minecraft:gold_block
fill 324 216 630 324 218 630 minecraft:gold_block
fill 287 217 625 287 220 627 minecraft:light_blue_concrete
fill 288 217 628 288 220 628 minecraft:light_blue_concrete
fill 289 217 623 291 220 623 minecraft:light_blue_concrete
fill 289 217 629 290 220 629 minecraft:light_blue_concrete
fill 292 217 624 292 220 624 minecraft:light_blue_concrete
fill 292 217 628 292 220 628 minecraft:light_blue_concrete
fill 292 217 634 293 217 634 minecraft:amethyst_block
fill 293 217 626 293 220 626 minecraft:light_blue_concrete
fill 300 217 616 300 218 618 minecraft:white_concrete
fill 301 217 616 301 218 617 minecraft:white_concrete
fill 313 217 646 313 235 646 minecraft:light_blue_concrete
fill 287 218 624 287 219 624 minecraft:light_blue_concrete
fill 287 218 628 287 219 628 minecraft:light_blue_concrete
fill 288 218 623 288 219 623 minecraft:light_blue_concrete
fill 288 218 629 288 219 629 minecraft:light_blue_concrete
fill 289 218 630 289 222 630 minecraft:oak_leaves[persistent=true]
fill 291 218 629 291 219 629 minecraft:light_blue_concrete
fill 292 218 633 292 218 634 minecraft:amethyst_block
fill 293 218 625 293 219 625 minecraft:light_blue_concrete
fill 293 218 627 293 219 627 minecraft:light_blue_concrete
fill 303 218 604 303 235 604 minecraft:light_blue_concrete
setblock 304 218 604 minecraft:pearlescent_froglight
setblock 282 219 612 minecraft:light_blue_concrete
setblock 282 219 620 minecraft:amethyst_block
fill 282 219 628 282 224 628 minecraft:light_blue_concrete
fill 282 219 644 282 224 644 minecraft:light_blue_concrete
fill 286 219 604 286 224 604 minecraft:light_blue_concrete
fill 288 219 630 288 221 630 minecraft:oak_leaves[persistent=true]
fill 289 219 631 290 221 631 minecraft:oak_leaves[persistent=true]
fill 290 219 630 290 221 630 minecraft:oak_leaves[persistent=true]
setblock 292 219 634 minecraft:amethyst_block
fill 296 219 646 296 224 646 minecraft:light_blue_concrete
fill 297 219 608 303 219 614 minecraft:moss_block
fill 302 219 604 302 224 604 minecraft:light_blue_concrete
fill 304 219 604 304 235 604 minecraft:light_blue_concrete
setblock 311 219 604 minecraft:pearlescent_froglight
fill 312 219 604 312 233 604 minecraft:light_blue_concrete
fill 312 219 646 312 224 646 minecraft:light_blue_concrete
fill 318 219 604 318 224 604 minecraft:light_blue_concrete
fill 324 219 614 324 224 614 minecraft:light_blue_concrete
setblock 324 219 620 minecraft:amethyst_block
fill 324 219 621 324 236 621 minecraft:light_blue_concrete
fill 324 219 630 324 224 630 minecraft:light_blue_concrete
setblock 282 220 612 minecraft:white_concrete
fill 282 220 620 282 231 620 minecraft:light_blue_concrete
fill 287 220 629 288 220 629 minecraft:oak_leaves[persistent=true]
setblock 288 220 631 minecraft:oak_leaves[persistent=true]
fill 291 220 629 291 220 630 minecraft:oak_leaves[persistent=true]
fill 300 220 611 300 224 611 minecraft:oak_log
fill 311 220 604 311 221 604 minecraft:light_blue_concrete
fill 324 220 620 324 235 620 minecraft:light_blue_concrete
setblock 324 220 634 minecraft:amethyst_block
fill 282 221 612 282 224 612 minecraft:light_blue_concrete
fill 288 221 628 288 221 629 minecraft:oak_leaves[persistent=true]
fill 289 221 629 291 221 629 minecraft:oak_leaves[persistent=true]
fill 324 221 634 324 235 634 minecraft:light_blue_concrete
setblock 285 222 607 minecraft:light[level=13]
setblock 285 222 615 minecraft:light[level=13]
setblock 285 222 623 minecraft:light[level=13]
setblock 285 222 631 minecraft:light[level=13]
setblock 285 222 639 minecraft:light[level=13]
fill 289 222 629 290 222 629 minecraft:oak_leaves[persistent=true]
setblock 293 222 607 minecraft:light[level=13]
setblock 293 222 615 minecraft:light[level=13]
setblock 293 222 623 minecraft:light[level=13]
setblock 293 222 631 minecraft:light[level=13]
setblock 293 222 639 minecraft:light[level=13]
setblock 301 222 607 minecraft:light[level=13]
setblock 301 222 615 minecraft:light[level=13]
setblock 301 222 623 minecraft:light[level=13]
setblock 301 222 631 minecraft:light[level=13]
setblock 301 222 639 minecraft:light[level=13]
setblock 309 222 607 minecraft:light[level=13]
setblock 309 222 615 minecraft:light[level=13]
setblock 309 222 623 minecraft:light[level=13]
setblock 309 222 631 minecraft:light[level=13]
setblock 309 222 639 minecraft:light[level=13]
setblock 311 222 604 minecraft:pearlescent_froglight
setblock 317 222 607 minecraft:light[level=13]
setblock 317 222 615 minecraft:light[level=13]
setblock 317 222 623 minecraft:light[level=13]
setblock 317 222 631 minecraft:light[level=13]
setblock 317 222 639 minecraft:light[level=13]
setblock 324 222 616 minecraft:amethyst_block
setblock 282 223 623 minecraft:pearlescent_froglight
fill 282 223 624 282 235 624 minecraft:light_blue_concrete
setblock 288 223 604 minecraft:amethyst_block
fill 289 223 604 289 235 604 minecraft:light_blue_concrete
fill 311 223 604 311 233 604 minecraft:light_blue_concrete
fill 324 223 616 324 235 616 minecraft:light_blue_concrete
setblock 324 223 631 minecraft:amethyst_block
fill 282 224 623 282 225 623 minecraft:light_blue_concrete
fill 288 224 604 288 235 604 minecraft:light_blue_concrete
setblock 291 224 604 minecraft:white_concrete
fill 299 224 611 299 228 611 minecraft:oak_leaves[persistent=true]
fill 300 224 610 300 228 610 minecraft:oak_leaves[persistent=true]
fill 324 224 631 324 236 631 minecraft:light_blue_concrete
fill 282 225 612 282 227 612 minecraft:gold_block
fill 282 225 628 282 227 628 minecraft:gold_block
fill 282 225 644 282 227 644 minecraft:gold_block
fill 286 225 604 286 227 604 minecraft:gold_block
fill 291 225 604 291 235 604 minecraft:light_blue_concrete
setblock 295 225 646 minecraft:amethyst_block
fill 296 225 646 296 227 646 minecraft:gold_block
fill 298 225 611 298 227 611 minecraft:oak_leaves[persistent=true]
fill 299 225 610 299 227 610 minecraft:oak_leaves[persistent=true]
fill 299 225 612 301 227 612 minecraft:oak_leaves[persistent=true]
fill 300 225 609 300 227 609 minecraft:oak_leaves[persistent=true]
fill 300 225 611 301 227 611 minecraft:oak_leaves[persistent=true]
fill 301 225 610 301 227 610 minecraft:oak_leaves[persistent=true]
fill 302 225 604 302 227 604 minecraft:gold_block
setblock 305 225 646 minecraft:white_concrete
fill 312 225 646 312 227 646 minecraft:gold_block
fill 318 225 604 318 227 604 minecraft:gold_block
setblock 322 225 646 minecraft:pearlescent_froglight
fill 324 225 614 324 227 614 minecraft:gold_block
setblock 324 225 629 minecraft:white_concrete
fill 324 225 630 324 227 630 minecraft:gold_block
setblock 324 225 633 minecraft:white_concrete
setblock 282 226 623 minecraft:white_concrete
fill 295 226 646 295 233 646 minecraft:light_blue_concrete
setblock 298 226 610 minecraft:oak_leaves[persistent=true]
setblock 298 226 612 minecraft:oak_leaves[persistent=true]
setblock 299 226 609 minecraft:oak_leaves[persistent=true]
setblock 300 226 613 minecraft:oak_leaves[persistent=true]
setblock 301 226 609 minecraft:oak_leaves[persistent=true]
setblock 302 226 611 minecraft:oak_leaves[persistent=true]
fill 305 226 646 305 235 646 minecraft:light_blue_concrete
setblock 314 226 604 minecraft:white_concrete
fill 322 226 646 322 232 646 minecraft:light_blue_concrete
fill 324 226 629 324 235 629 minecraft:light_blue_concrete
fill 324 226 633 324 235 633 minecraft:light_blue_concrete
fill 282 227 623 282 228 623 minecraft:light_blue_concrete
setblock 282 227 637 minecraft:white_concrete
setblock 308 227 604 minecraft:white_concrete
fill 314 227 604 314 233 604 minecraft:light_blue_concrete
setblock 322 227 604 minecraft:amethyst_block
fill 282 228 612 282 235 612 minecraft:light_blue_concrete
fill 282 228 628 282 235 628 minecraft:light_blue_concrete
fill 282 228 637 282 237 637 minecraft:light_blue_concrete
fill 282 228 644 282 235 644 minecraft:light_blue_concrete
setblock 283 228 604 minecraft:pearlescent_froglight
fill 286 228 604 286 231 604 minecraft:light_blue_concrete
setblock 294 228 604 minecraft:amethyst_block
fill 296 228 646 296 235 646 minecraft:light_blue_concrete
setblock 300 228 611 minecraft:oak_leaves[persistent=true]
fill 302 228 604 302 235 604 minecraft:light_blue_concrete
setblock 307 228 604 minecraft:amethyst_block
fill 308 228 604 308 231 604 minecraft:light_blue_concrete
fill 312 228 646 312 235 646 minecraft:light_blue_concrete
fill 318 228 604 318 235 604 minecraft:light_blue_concrete
fill 322 228 604 322 235 604 minecraft:light_blue_concrete
fill 324 228 614 324 232 614 minecraft:light_blue_concrete
setblock 324 228 628 minecraft:pearlescent_froglight
fill 324 228 630 324 231 630 minecraft:light_blue_concrete
setblock 282 229 623 minecraft:white_concrete
setblock 282 229 635 minecraft:white_concrete
setblock 282 229 642 minecraft:pearlescent_froglight
fill 283 229 604 283 236 604 minecraft:light_blue_concrete
fill 294 229 604 294 235 604 minecraft:light_blue_concrete
setblock 303 229 646 minecraft:amethyst_block
fill 307 229 604 307 235 604 minecraft:light_blue_concrete
setblock 324 229 605 minecraft:amethyst_block
setblock 324 229 627 minecraft:amethyst_block
fill 324 229 628 324 233 628 minecraft:light_blue_concrete
setblock 282 230 622 minecraft:white_concrete
fill 282 230 623 282 235 623 minecraft:light_blue_concrete
fill 282 230 635 282 232 635 minecraft:light_blue_concrete
fill 282 230 642 282 235 642 minecraft:light_blue_concrete
setblock 285 230 607 minecraft:light[level=13]
setblock 285 230 615 minecraft:light[level=13]
setblock 285 230 623 minecraft:light[level=13]
setblock 285 230 631 minecraft:light[level=13]
setblock 285 230 639 minecraft:light[level=13]
setblock 293 230 607 minecraft:light[level=13]
setblock 293 230 615 minecraft:light[level=13]
setblock 293 230 623 minecraft:light[level=13]
setblock 293 230 631 minecraft:light[level=13]
setblock 293 230 639 minecraft:light[level=13]
setblock 301 230 607 minecraft:light[level=13]
setblock 301 230 615 minecraft:light[level=13]
setblock 301 230 623 minecraft:light[level=13]
setblock 301 230 631 minecraft:light[level=13]
setblock 301 230 639 minecraft:light[level=13]
setblock 301 230 646 minecraft:amethyst_block
fill 303 230 646 303 235 646 minecraft:light_blue_concrete
setblock 305 230 604 minecraft:white_concrete
fill 306 230 604 306 235 604 minecraft:light_blue_concrete
setblock 309 230 607 minecraft:light[level=13]
setblock 309 230 615 minecraft:light[level=13]
setblock 309 230 623 minecraft:light[level=13]
setblock 309 230 631 minecraft:light[level=13]
setblock 309 230 639 minecraft:light[level=13]
setblock 317 230 607 minecraft:light[level=13]
setblock 317 230 615 minecraft:light[level=13]
setblock 317 230 623 minecraft:light[level=13]
setblock 317 230 631 minecraft:light[level=13]
setblock 317 230 639 minecraft:light[level=13]
fill 324 230 605 324 235 605 minecraft:light_blue_concrete
fill 324 230 627 324 235 627 minecraft:light_blue_concrete
fill 282 231 622 282 235 622 minecraft:light_blue_concrete
setblock 282 231 634 minecraft:amethyst_block
fill 301 231 646 301 235 646 minecraft:light_blue_concrete
fill 305 231 604 305 235 604 minecraft:light_blue_concrete
setblock 282 232 604 minecraft:white_concrete
setblock 282 232 620 minecraft:white_concrete
setblock 282 232 629 minecraft:pearlescent_froglight
setblock 282 232 630 minecraft:white_concrete
setblock 282 232 633 minecraft:white_concrete
fill 282 232 634 282 234 634 minecraft:light_blue_concrete
fill 285 232 604 286 232 604 minecraft:white_concrete
setblock 288 232 646 minecraft:white_concrete
fill 289 232 646 290 235 646 minecraft:light_blue_concrete
setblock 291 232 646 minecraft:white_concrete
setblock 292 232 604 minecraft:amethyst_block
setblock 293 232 604 minecraft:white_concrete
setblock 295 232 604 minecraft:white_concrete
setblock 299 232 646 minecraft:white_concrete
setblock 300 232 604 minecraft:white_concrete
setblock 304 232 646 minecraft:white_concrete
setblock 308 232 604 minecraft:white_concrete
setblock 316 232 604 minecraft:white_concrete
setblock 320 232 646 minecraft:white_concrete
setblock 324 232 606 minecraft:white_concrete
fill 324 232 608 324 235 609 minecraft:light_blue_concrete
setblock 324 232 610 minecraft:white_concrete
setblock 324 232 623 minecraft:white_concrete
setblock 324 232 630 minecraft:white_concrete
fill 324 232 638 324 235 639 minecraft:light_blue_concrete
setblock 324 232 640 minecraft:white_concrete
setblock 324 232 642 minecraft:white_concrete
fill 282 233 604 282 235 604 minecraft:light_blue_concrete
setblock 282 233 605 minecraft:white_concrete
fill 282 233 620 282 235 620 minecraft:light_blue_concrete
fill 282 233 621 282 234 621 minecraft:white_concrete
fill 282 233 629 282 235 630 minecraft:light_blue_concrete
fill 282 233 633 282 235 633 minecraft:light_blue_concrete
setblock 282 233 635 minecraft:white_concrete
setblock 282 233 643 minecraft:white_concrete
setblock 282 233 646 minecraft:white_concrete
fill 283 233 646 283 237 646 minecraft:light_blue_concrete
fill 285 233 604 286 235 604 minecraft:light_blue_concrete
fill 288 233 646 288 235 646 minecraft:light_blue_concrete
fill 291 233 646 291 235 646 minecraft:light_blue_concrete
fill 292 233 604 293 233 604 minecraft:light_blue_concrete
fill 295 233 604 295 235 604 minecraft:light_blue_concrete
setblock 299 233 604 minecraft:white_concrete
fill 299 233 646 299 236 646 minecraft:light_blue_concrete
fill 300 233 604 300 235 604 minecraft:light_blue_concrete
fill 304 233 646 304 237 646 minecraft:light_blue_concrete
fill 308 233 604 308 235 604 minecraft:light_blue_concrete
fill 316 233 604 316 235 604 minecraft:light_blue_concrete
fill 318 233 646 319 233 646 minecraft:white_concrete
fill 320 233 646 320 236 646 minecraft:light_blue_concrete
setblock 322 233 646 minecraft:white_concrete
setblock 324 233 606 minecraft:light_blue_concrete
fill 324 233 610 324 236 610 minecraft:light_blue_concrete
setblock 324 233 614 minecraft:white_concrete
fill 324 233 623 324 235 623 minecraft:light_blue_concrete
setblock 324 233 626 minecraft:white_concrete
fill 324 233 630 324 235 630 minecraft:light_blue_concrete
fill 324 233 640 324 236 640 minecraft:light_blue_concrete
fill 324 233 642 324 235 642 minecraft:light_blue_concrete
fill 282 234 605 282 235 605 minecraft:light_blue_concrete
setblock 282 234 626 minecraft:white_concrete
fill 282 234 635 282 235 635 minecraft:light_blue_concrete
fill 282 234 638 282 234 639 minecraft:white_concrete
fill 282 234 643 282 235 643 minecraft:light_blue_concrete
fill 282 234 646 282 235 646 minecraft:light_blue_concrete
setblock 292 234 604 minecraft:white_concrete
fill 293 234 604 293 235 604 minecraft:light_blue_concrete
setblock 295 234 646 minecraft:white_concrete
setblock 296 234 604 minecraft:white_concrete
fill 299 234 604 299 235 604 minecraft:light_blue_concrete
setblock 311 234 604 minecraft:white_concrete
setblock 312 234 604 minecraft:amethyst_block
setblock 314 234 604 minecraft:white_concrete
setblock 315 234 646 minecraft:white_concrete
setblock 317 234 646 minecraft:white_concrete
fill 318 234 646 319 235 646 minecraft:light_blue_concrete
fill 322 234 646 322 235 646 minecraft:light_blue_concrete
setblock 324 234 604 minecraft:white_concrete
setblock 324 234 606 minecraft:white_concrete
setblock 324 234 611 minecraft:white_concrete
setblock 324 234 612 minecraft:amethyst_block
fill 324 234 614 324 235 614 minecraft:light_blue_concrete
setblock 324 234 615 minecraft:white_concrete
fill 324 234 626 324 235 626 minecraft:light_blue_concrete
setblock 324 234 628 minecraft:white_concrete
fill 324 234 643 324 234 645 minecraft:light_blue_concrete
setblock 324 234 646 minecraft:white_concrete
setblock 282 235 621 minecraft:light_blue_concrete
setblock 282 235 626 minecraft:light_blue_concrete
setblock 282 235 634 minecraft:amethyst_block
fill 282 235 638 282 235 639 minecraft:light_blue_concrete
setblock 292 235 604 minecraft:light_blue_concrete
setblock 295 235 646 minecraft:light_blue_concrete
setblock 296 235 604 minecraft:light_blue_concrete
fill 311 235 604 312 235 604 minecraft:light_blue_concrete
setblock 314 235 604 minecraft:light_blue_concrete
setblock 315 235 646 minecraft:light_blue_concrete
setblock 317 235 646 minecraft:light_blue_concrete
setblock 324 235 604 minecraft:light_blue_concrete
setblock 324 235 606 minecraft:light_blue_concrete
fill 324 235 611 324 235 612 minecraft:light_blue_concrete
setblock 324 235 615 minecraft:light_blue_concrete
setblock 324 235 628 minecraft:light_blue_concrete
fill 324 235 643 324 236 643 minecraft:light_blue_concrete
fill 324 235 644 324 292 644 minecraft:white_concrete
fill 324 235 645 324 235 646 minecraft:light_blue_concrete
fill 282 236 604 282 236 606 minecraft:white_concrete
fill 282 236 608 282 236 636 minecraft:white_concrete
fill 282 236 638 282 300 638 minecraft:white_concrete
setblock 282 236 639 minecraft:light_blue_concrete
fill 282 236 641 282 237 646 minecraft:white_concrete
fill 283 236 605 284 237 607 minecraft:moss_block
fill 283 236 608 284 236 611 minecraft:stone
fill 283 236 612 284 236 615 minecraft:moss_block
fill 283 236 616 284 236 619 minecraft:stone
fill 283 236 620 284 236 623 minecraft:moss_block
fill 283 236 624 284 236 627 minecraft:stone
fill 283 236 628 284 236 631 minecraft:moss_block
fill 283 236 632 284 236 635 minecraft:stone
fill 283 236 636 284 236 639 minecraft:moss_block
fill 283 236 640 284 236 643 minecraft:stone
fill 283 236 644 284 236 645 minecraft:moss_block
fill 284 236 604 297 236 604 minecraft:white_concrete
fill 284 236 646 293 236 646 minecraft:white_concrete
fill 285 236 605 288 236 607 minecraft:stone
fill 285 236 608 288 236 611 minecraft:moss_block
fill 285 236 612 288 236 615 minecraft:stone
fill 285 236 616 288 236 619 minecraft:moss_block
fill 285 236 620 288 236 623 minecraft:stone
fill 285 236 624 288 236 627 minecraft:moss_block
fill 285 236 628 288 236 631 minecraft:stone
fill 285 236 632 288 236 635 minecraft:moss_block
fill 285 236 636 288 236 639 minecraft:stone
fill 285 236 640 288 236 643 minecraft:moss_block
fill 285 236 644 288 236 645 minecraft:stone
fill 289 236 605 292 236 607 minecraft:moss_block
fill 289 236 608 292 236 611 minecraft:stone
fill 289 236 612 292 236 615 minecraft:moss_block
fill 289 236 616 292 236 619 minecraft:stone
fill 289 236 620 292 236 623 minecraft:moss_block
fill 289 236 624 292 236 627 minecraft:stone
fill 289 236 628 292 236 631 minecraft:moss_block
fill 289 236 632 292 236 635 minecraft:stone
fill 289 236 636 292 236 639 minecraft:moss_block
fill 289 236 640 292 236 643 minecraft:stone
fill 289 236 644 292 236 645 minecraft:moss_block
fill 293 236 605 296 236 607 minecraft:stone
fill 293 236 608 296 236 611 minecraft:moss_block
fill 293 236 612 296 236 615 minecraft:stone
fill 293 236 616 296 236 619 minecraft:moss_block
fill 293 236 620 296 236 623 minecraft:stone
fill 293 236 624 296 236 627 minecraft:moss_block
fill 293 236 628 296 236 631 minecraft:stone
fill 293 236 632 296 236 635 minecraft:moss_block
fill 293 236 636 296 236 639 minecraft:stone
fill 293 236 640 296 236 643 minecraft:moss_block
fill 293 236 644 296 236 645 minecraft:stone
fill 295 236 646 298 239 646 minecraft:white_concrete
fill 297 236 605 300 236 607 minecraft:moss_block
fill 297 236 608 300 236 611 minecraft:stone
fill 297 236 612 300 236 615 minecraft:moss_block
fill 297 236 616 300 236 619 minecraft:stone
fill 297 236 620 300 236 623 minecraft:moss_block
fill 297 236 624 300 236 627 minecraft:stone
fill 297 236 628 300 236 631 minecraft:moss_block
fill 297 236 632 300 236 635 minecraft:stone
fill 297 236 636 300 236 639 minecraft:moss_block
fill 297 236 640 300 236 643 minecraft:stone
fill 297 236 644 300 236 645 minecraft:moss_block
fill 299 236 604 324 236 604 minecraft:white_concrete
fill 300 236 646 303 237 646 minecraft:white_concrete
fill 301 236 605 304 236 607 minecraft:stone
fill 301 236 608 304 236 611 minecraft:moss_block
fill 301 236 612 304 236 615 minecraft:stone
fill 301 236 616 304 236 619 minecraft:moss_block
fill 301 236 620 303 236 623 minecraft:stone
fill 301 236 624 302 236 627 minecraft:moss_block
fill 301 236 628 304 236 631 minecraft:stone
fill 301 236 632 304 236 635 minecraft:moss_block
fill 301 236 636 304 236 639 minecraft:stone
fill 301 236 640 304 236 643 minecraft:moss_block
fill 301 236 644 304 236 645 minecraft:stone
fill 303 236 625 303 236 627 minecraft:moss_block
fill 304 236 620 304 236 622 minecraft:stone
fill 304 236 626 304 236 627 minecraft:moss_block
fill 305 236 605 308 236 607 minecraft:moss_block
fill 305 236 608 308 236 611 minecraft:stone
fill 305 236 612 308 236 615 minecraft:moss_block
fill 305 236 616 308 236 619 minecraft:stone
fill 305 236 620 308 236 621 minecraft:moss_block
fill 305 236 627 308 236 627 minecraft:stone
fill 305 236 628 308 236 631 minecraft:moss_block
fill 305 236 632 308 236 635 minecraft:stone
fill 305 236 636 308 236 639 minecraft:moss_block
fill 305 236 640 308 236 643 minecraft:stone
fill 305 236 644 308 236 645 minecraft:moss_block
fill 305 236 646 305 237 646 minecraft:white_concrete
fill 306 236 622 308 236 622 minecraft:moss_block
fill 306 236 626 308 236 626 minecraft:stone
fill 307 236 623 308 236 623 minecraft:moss_block
fill 307 236 625 308 236 625 minecraft:stone
setblock 308 236 624 minecraft:stone
fill 308 236 646 319 236 646 minecraft:white_concrete
fill 309 236 605 312 236 607 minecraft:stone
fill 309 236 608 312 236 611 minecraft:moss_block
fill 309 236 612 312 236 615 minecraft:stone
fill 309 236 616 312 236 619 minecraft:moss_block
fill 309 236 620 312 236 623 minecraft:stone
fill 309 236 624 312 236 627 minecraft:moss_block
fill 309 236 628 312 236 631 minecraft:stone
fill 309 236 632 312 236 635 minecraft:moss_block
fill 309 236 636 312 236 639 minecraft:stone
fill 309 236 640 312 236 643 minecraft:moss_block
fill 309 236 644 312 236 645 minecraft:stone
fill 313 236 605 316 236 607 minecraft:moss_block
fill 313 236 608 316 236 611 minecraft:stone
fill 313 236 612 316 236 615 minecraft:moss_block
fill 313 236 616 316 236 619 minecraft:stone
fill 313 236 620 316 236 623 minecraft:moss_block
fill 313 236 624 316 236 627 minecraft:stone
fill 313 236 628 316 236 631 minecraft:moss_block
fill 313 236 632 316 236 635 minecraft:stone
fill 313 236 636 316 236 639 minecraft:moss_block
fill 313 236 640 316 236 643 minecraft:stone
fill 313 236 644 316 236 645 minecraft:moss_block
fill 317 236 605 320 236 607 minecraft:stone
fill 317 236 608 320 236 611 minecraft:moss_block
fill 317 236 612 320 236 615 minecraft:stone
fill 317 236 616 320 236 619 minecraft:moss_block
fill 317 236 620 320 236 623 minecraft:stone
fill 317 236 624 320 236 627 minecraft:moss_block
fill 317 236 628 320 236 631 minecraft:stone
fill 317 236 632 320 236 635 minecraft:moss_block
fill 317 236 636 320 236 639 minecraft:stone
fill 317 236 640 320 236 643 minecraft:moss_block
fill 317 236 644 320 236 645 minecraft:stone
fill 321 236 605 323 236 607 minecraft:moss_block
fill 321 236 608 323 236 611 minecraft:stone
fill 321 236 612 323 236 615 minecraft:moss_block
fill 321 236 616 323 236 619 minecraft:stone
fill 321 236 620 323 236 623 minecraft:moss_block
fill 321 236 624 323 236 627 minecraft:stone
fill 321 236 628 323 236 631 minecraft:moss_block
fill 321 236 632 323 236 635 minecraft:stone
fill 321 236 636 323 236 639 minecraft:moss_block
fill 321 236 640 323 236 643 minecraft:stone
fill 321 236 644 323 236 645 minecraft:moss_block
fill 321 236 646 322 307 646 minecraft:white_concrete
fill 324 236 605 324 236 609 minecraft:white_concrete
fill 324 236 611 324 236 620 minecraft:white_concrete
fill 324 236 622 324 236 627 minecraft:white_concrete
setblock 324 236 628 minecraft:amethyst_block
fill 324 236 629 324 237 630 minecraft:white_concrete
fill 324 236 632 324 236 639 minecraft:white_concrete
fill 324 236 642 324 307 642 minecraft:white_concrete
fill 324 236 645 324 275 645 minecraft:white_concrete
setblock 324 236 646 minecraft:light_blue_concrete
setblock 282 237 604 minecraft:light_blue_concrete
fill 282 237 605 282 237 611 minecraft:white_concrete
setblock 282 237 612 minecraft:light_blue_concrete
fill 282 237 613 282 238 620 minecraft:white_concrete
fill 282 237 621 282 238 621 minecraft:light_blue_concrete
fill 282 237 622 282 242 634 minecraft:white_concrete
setblock 282 237 635 minecraft:light_blue_concrete
fill 282 237 636 282 307 636 minecraft:white_concrete
fill 282 237 639 282 307 640 minecraft:white_concrete
fill 283 237 604 288 238 604 minecraft:white_concrete
fill 283 237 608 323 237 608 minecraft:dirt
fill 283 237 609 284 237 611 minecraft:stone
fill 283 237 612 323 237 612 minecraft:dirt
fill 283 237 613 284 237 615 minecraft:moss_block
fill 283 237 616 323 237 616 minecraft:dirt
fill 283 237 617 284 237 619 minecraft:stone
fill 283 237 620 323 237 620 minecraft:dirt
fill 283 237 621 284 237 623 minecraft:moss_block
fill 283 237 624 301 237 624 minecraft:dirt
fill 283 237 625 284 237 627 minecraft:stone
fill 283 237 628 323 237 628 minecraft:dirt
fill 283 237 629 284 237 631 minecraft:moss_block
fill 283 237 632 323 237 632 minecraft:dirt
fill 283 237 633 284 237 635 minecraft:stone
fill 283 237 636 323 237 636 minecraft:dirt
fill 283 237 637 284 237 639 minecraft:moss_block
fill 283 237 640 323 237 640 minecraft:dirt
fill 283 237 641 284 237 643 minecraft:stone
fill 283 237 644 323 237 644 minecraft:dirt
fill 283 237 645 284 237 645 minecraft:moss_block
fill 284 237 646 285 297 646 minecraft:white_concrete
fill 285 237 605 285 237 607 minecraft:dirt
fill 285 237 609 285 237 611 minecraft:dirt
fill 285 237 613 285 237 615 minecraft:dirt
fill 285 237 617 285 237 619 minecraft:dirt
fill 285 237 621 285 237 623 minecraft:dirt
fill 285 237 625 285 237 627 minecraft:dirt
fill 285 237 629 285 237 631 minecraft:dirt
fill 285 237 633 285 237 635 minecraft:dirt
fill 285 237 637 285 237 639 minecraft:dirt
fill 285 237 641 285 237 643 minecraft:dirt
setblock 285 237 645 minecraft:dirt
fill 286 237 605 288 237 607 minecraft:stone
fill 286 237 609 288 237 611 minecraft:moss_block
fill 286 237 613 288 237 615 minecraft:stone
fill 286 237 617 288 237 619 minecraft:moss_block
fill 286 237 621 288 237 623 minecraft:stone
fill 286 237 625 288 237 627 minecraft:moss_block
fill 286 237 629 288 237 631 minecraft:stone
fill 286 237 633 288 237 635 minecraft:moss_block
fill 286 237 637 288 237 639 minecraft:stone
fill 286 237 641 288 237 643 minecraft:moss_block
fill 286 237 645 288 237 645 minecraft:stone
setblock 286 237 646 minecraft:light_blue_concrete
fill 287 237 646 294 249 646 minecraft:white_concrete
setblock 289 237 604 minecraft:light_blue_concrete
fill 289 237 605 289 237 607 minecraft:dirt
fill 289 237 609 289 237 611 minecraft:dirt
fill 289 237 613 289 237 615 minecraft:dirt
fill 289 237 617 289 237 619 minecraft:dirt
fill 289 237 621 289 237 623 minecraft:dirt
fill 289 237 625 289 237 627 minecraft:dirt
fill 289 237 629 289 237 631 minecraft:dirt
fill 289 237 633 289 237 635 minecraft:dirt
fill 289 237 637 289 237 639 minecraft:dirt
fill 289 237 641 289 237 643 minecraft:dirt
setblock 289 237 645 minecraft:dirt
fill 290 237 604 295 237 604 minecraft:white_concrete
fill 290 237 605 292 237 607 minecraft:moss_block
fill 290 237 609 292 237 611 minecraft:stone
fill 290 237 613 292 237 615 minecraft:moss_block
fill 290 237 617 292 237 619 minecraft:stone
fill 290 237 621 292 237 623 minecraft:moss_block
fill 290 237 625 292 237 627 minecraft:stone
fill 290 237 629 292 237 631 minecraft:moss_block
fill 290 237 633 292 237 635 minecraft:stone
fill 290 237 637 292 237 639 minecraft:moss_block
fill 290 237 641 292 237 643 minecraft:stone
fill 290 237 645 292 237 645 minecraft:moss_block
fill 293 237 605 293 237 607 minecraft:dirt
fill 293 237 609 293 237 611 minecraft:dirt
fill 293 237 613 293 237 615 minecraft:dirt
fill 293 237 617 293 237 619 minecraft:dirt
fill 293 237 621 293 237 623 minecraft:dirt
fill 293 237 625 293 237 627 minecraft:dirt
fill 293 237 629 293 237 631 minecraft:dirt
fill 293 237 633 293 237 635 minecraft:dirt
fill 293 237 637 293 237 639 minecraft:dirt
fill 293 237 641 293 237 643 minecraft:dirt
setblock 293 237 645 minecraft:dirt
fill 294 237 605 296 237 607 minecraft:stone
fill 294 237 609 296 237 611 minecraft:moss_block
fill 294 237 613 296 237 615 minecraft:stone
fill 294 237 617 296 237 619 minecraft:moss_block
fill 294 237 621 296 237 623 minecraft:stone
fill 294 237 625 296 237 627 minecraft:moss_block
fill 294 237 629 296 237 631 minecraft:stone
fill 294 237 633 296 237 635 minecraft:moss_block
fill 294 237 637 296 237 639 minecraft:stone
fill 294 237 641 296 237 643 minecraft:moss_block
fill 294 237 645 296 237 645 minecraft:stone
fill 296 237 604 296 238 604 minecraft:light_blue_concrete
fill 297 237 604 301 305 604 minecraft:white_concrete
fill 297 237 605 297 237 607 minecraft:dirt
fill 297 237 609 297 237 611 minecraft:dirt
fill 297 237 613 297 237 615 minecraft:dirt
fill 297 237 617 297 237 619 minecraft:dirt
fill 297 237 621 297 237 623 minecraft:dirt
fill 297 237 625 297 237 627 minecraft:dirt
fill 297 237 629 297 237 631 minecraft:dirt
fill 297 237 633 297 237 635 minecraft:dirt
fill 297 237 637 297 237 639 minecraft:dirt
fill 297 237 641 297 237 643 minecraft:dirt
setblock 297 237 645 minecraft:dirt
fill 298 237 605 300 237 607 minecraft:moss_block
fill 298 237 609 300 237 611 minecraft:stone
fill 298 237 613 300 237 615 minecraft:moss_block
fill 298 237 617 300 237 619 minecraft:stone
fill 298 237 621 300 237 623 minecraft:moss_block
fill 298 237 625 300 237 627 minecraft:stone
fill 298 237 629 300 237 631 minecraft:moss_block
fill 298 237 633 300 237 635 minecraft:stone
fill 298 237 637 300 237 639 minecraft:moss_block
fill 298 237 641 300 237 643 minecraft:stone
fill 298 237 645 300 237 645 minecraft:moss_block
fill 299 237 646 299 307 646 minecraft:white_concrete
fill 301 237 605 301 237 607 minecraft:dirt
fill 301 237 609 301 237 611 minecraft:dirt
fill 301 237 613 301 237 615 minecraft:dirt
fill 301 237 617 301 237 619 minecraft:dirt
fill 301 237 621 301 237 623 minecraft:dirt
fill 301 237 625 301 237 627 minecraft:dirt
fill 301 237 629 301 237 631 minecraft:dirt
fill 301 237 633 301 237 635 minecraft:dirt
fill 301 237 637 301 237 639 minecraft:dirt
fill 301 237 641 301 237 643 minecraft:dirt
setblock 301 237 645 minecraft:dirt
setblock 302 237 604 minecraft:light_blue_concrete
fill 302 237 605 304 237 607 minecraft:stone
fill 302 237 609 304 237 611 minecraft:moss_block
fill 302 237 613 304 237 615 minecraft:stone
fill 302 237 617 304 237 619 minecraft:moss_block
fill 302 237 621 302 237 622 minecraft:stone
setblock 302 237 623 minecraft:red_nether_bricks
fill 302 237 624 302 239 624 minecraft:quartz_block
setblock 302 237 625 minecraft:red_nether_bricks
fill 302 237 626 302 237 627 minecraft:moss_block
fill 302 237 629 304 237 631 minecraft:stone
fill 302 237 633 304 237 635 minecraft:moss_block
fill 302 237 637 304 237 639 minecraft:stone
fill 302 237 641 304 237 643 minecraft:moss_block
fill 302 237 645 304 237 645 minecraft:stone
fill 303 237 604 323 237 604 minecraft:white_concrete
setblock 303 237 621 minecraft:stone
fill 303 237 622 303 237 623 minecraft:shroomlight
fill 303 237 625 303 237 626 minecraft:shroomlight
setblock 303 237 627 minecraft:moss_block
setblock 304 237 621 minecraft:pearlescent_froglight
setblock 304 237 622 minecraft:shroomlight
setblock 304 237 626 minecraft:shroomlight
setblock 304 237 627 minecraft:pearlescent_froglight
fill 305 237 605 305 237 607 minecraft:dirt
fill 305 237 609 305 237 611 minecraft:dirt
fill 305 237 613 305 237 615 minecraft:dirt
fill 305 237 617 305 237 619 minecraft:dirt
fill 305 237 621 305 239 621 minecraft:quartz_block
fill 305 237 627 305 239 627 minecraft:quartz_block
fill 305 237 629 305 237 631 minecraft:dirt
fill 305 237 633 305 237 635 minecraft:dirt
fill 305 237 637 305 237 639 minecraft:dirt
fill 305 237 641 305 237 643 minecraft:dirt
setblock 305 237 645 minecraft:dirt
fill 306 237 605 308 237 607 minecraft:moss_block
fill 306 237 609 308 237 611 minecraft:stone
fill 306 237 613 308 237 615 minecraft:moss_block
fill 306 237 617 308 237 619 minecraft:stone
setblock 306 237 621 minecraft:pearlescent_froglight
fill 306 237 622 307 237 622 minecraft:shroomlight
fill 306 237 626 307 237 626 minecraft:shroomlight
setblock 306 237 627 minecraft:pearlescent_froglight
fill 306 237 629 308 237 631 minecraft:moss_block
fill 306 237 633 308 237 635 minecraft:stone
fill 306 237 637 308 237 639 minecraft:moss_block
fill 306 237 641 308 237 643 minecraft:stone
fill 306 237 645 308 237 645 minecraft:moss_block
fill 306 237 646 308 237 646 minecraft:white_concrete
fill 307 237 621 308 237 621 minecraft:moss_block
setblock 307 237 623 minecraft:shroomlight
setblock 307 237 625 minecraft:shroomlight
fill 307 237 627 308 237 627 minecraft:stone
setblock 308 237 622 minecraft:moss_block
setblock 308 237 623 minecraft:red_nether_bricks
fill 308 237 624 308 239 624 minecraft:quartz_block
setblock 308 237 625 minecraft:red_nether_bricks
setblock 308 237 626 minecraft:stone
fill 309 237 605 309 237 607 minecraft:dirt
fill 309 237 609 309 237 611 minecraft:dirt
fill 309 237 613 309 237 615 minecraft:dirt
fill 309 237 617 309 237 619 minecraft:dirt
fill 309 237 621 309 237 627 minecraft:dirt
fill 309 237 629 309 237 631 minecraft:dirt
fill 309 237 633 309 237 635 minecraft:dirt
fill 309 237 637 309 237 639 minecraft:dirt
fill 309 237 641 309 237 643 minecraft:dirt
setblock 309 237 645 minecraft:dirt
fill 309 237 646 309 238 646 minecraft:light_blue_concrete
fill 310 237 605 312 237 607 minecraft:stone
fill 310 237 609 312 237 611 minecraft:moss_block
fill 310 237 613 312 237 615 minecraft:stone
fill 310 237 617 312 237 619 minecraft:moss_block
fill 310 237 621 312 237 623 minecraft:stone
fill 310 237 624 323 237 624 minecraft:dirt
fill 310 237 625 312 237 627 minecraft:moss_block
fill 310 237 629 312 237 631 minecraft:stone
fill 310 237 633 312 237 635 minecraft:moss_block
fill 310 237 637 312 237 639 minecraft:stone
fill 310 237 641 312 237 643 minecraft:moss_block
fill 310 237 645 312 237 645 minecraft:stone
fill 310 237 646 313 242 646 minecraft:white_concrete
fill 313 237 605 313 237 607 minecraft:dirt
fill 313 237 609 313 237 611 minecraft:dirt
fill 313 237 613 313 237 615 minecraft:dirt
fill 313 237 617 313 237 619 minecraft:dirt
fill 313 237 621 313 237 623 minecraft:dirt
fill 313 237 625 313 237 627 minecraft:dirt
fill 313 237 629 313 237 631 minecraft:dirt
fill 313 237 633 313 237 635 minecraft:dirt
fill 313 237 637 313 237 639 minecraft:dirt
fill 313 237 641 313 237 643 minecraft:dirt
setblock 313 237 645 minecraft:dirt
fill 314 237 605 316 237 607 minecraft:moss_block
fill 314 237 609 316 237 611 minecraft:stone
fill 314 237 613 316 237 615 minecraft:moss_block
fill 314 237 617 316 237 619 minecraft:stone
fill 314 237 621 316 237 623 minecraft:moss_block
fill 314 237 625 316 237 627 minecraft:stone
fill 314 237 629 316 237 631 minecraft:moss_block
fill 314 237 633 316 237 635 minecraft:stone
fill 314 237 637 316 237 639 minecraft:moss_block
fill 314 237 641 316 237 643 minecraft:stone
fill 314 237 645 316 237 645 minecraft:moss_block
setblock 314 237 646 minecraft:light_blue_concrete
fill 315 237 646 316 256 646 minecraft:white_concrete
fill 317 237 605 317 237 607 minecraft:dirt
fill 317 237 609 317 237 611 minecraft:dirt
fill 317 237 613 317 237 615 minecraft:dirt
fill 317 237 617 317 237 619 minecraft:dirt
fill 317 237 621 317 237 623 minecraft:dirt
fill 317 237 625 317 237 627 minecraft:dirt
fill 317 237 629 317 237 631 minecraft:dirt
fill 317 237 633 317 237 635 minecraft:dirt
fill 317 237 637 317 237 639 minecraft:dirt
fill 317 237 641 317 237 643 minecraft:dirt
setblock 317 237 645 minecraft:dirt
setblock 317 237 646 minecraft:pearlescent_froglight
fill 318 237 605 320 237 607 minecraft:stone
fill 318 237 609 320 237 611 minecraft:moss_block
fill 318 237 613 320 237 615 minecraft:stone
fill 318 237 617 320 237 619 minecraft:moss_block
fill 318 237 621 320 237 623 minecraft:stone
fill 318 237 625 320 237 627 minecraft:moss_block
fill 318 237 629 320 237 631 minecraft:stone
fill 318 237 633 320 237 635 minecraft:moss_block
fill 318 237 637 320 237 639 minecraft:stone
fill 318 237 641 320 237 643 minecraft:moss_block
fill 318 237 645 320 237 645 minecraft:stone
fill 318 237 646 320 266 646 minecraft:white_concrete
fill 321 237 605 321 237 607 minecraft:dirt
fill 321 237 609 321 237 611 minecraft:dirt
fill 321 237 613 321 237 615 minecraft:dirt
fill 321 237 617 321 237 619 minecraft:dirt
fill 321 237 621 321 237 623 minecraft:dirt
fill 321 237 625 321 237 627 minecraft:dirt
fill 321 237 629 321 237 631 minecraft:dirt
fill 321 237 633 321 237 635 minecraft:dirt
fill 321 237 637 321 237 639 minecraft:dirt
fill 321 237 641 321 237 643 minecraft:dirt
setblock 321 237 645 minecraft:dirt
fill 322 237 605 323 237 607 minecraft:moss_block
fill 322 237 609 323 237 611 minecraft:stone
fill 322 237 613 323 237 615 minecraft:moss_block
fill 322 237 617 323 237 619 minecraft:stone
fill 322 237 621 323 237 623 minecraft:moss_block
fill 322 237 625 323 237 627 minecraft:stone
fill 322 237 629 323 237 631 minecraft:moss_block
fill 322 237 633 323 237 635 minecraft:stone
fill 322 237 637 323 237 639 minecraft:moss_block
fill 322 237 641 323 237 643 minecraft:stone
fill 322 237 645 323 237 645 minecraft:moss_block
fill 323 237 646 324 307 646 minecraft:white_concrete
fill 324 237 604 324 238 604 minecraft:light_blue_concrete
fill 324 237 605 324 247 607 minecraft:white_concrete
fill 324 237 608 324 238 608 minecraft:light_blue_concrete
fill 324 237 609 324 262 612 minecraft:white_concrete
setblock 324 237 613 minecraft:light_blue_concrete
setblock 324 237 614 minecraft:amethyst_block
fill 324 237 615 324 248 623 minecraft:white_concrete
setblock 324 237 624 minecraft:light_blue_concrete
fill 324 237 625 324 245 628 minecraft:white_concrete
fill 324 237 631 324 307 631 minecraft:white_concrete
fill 324 237 632 324 237 634 minecraft:light_blue_concrete
fill 324 237 635 324 266 640 minecraft:white_concrete
fill 324 237 643 324 307 643 minecraft:white_concrete
fill 282 238 604 282 257 605 minecraft:white_concrete
setblock 282 238 606 minecraft:light_blue_concrete
fill 282 238 607 282 265 609 minecraft:white_concrete
setblock 282 238 610 minecraft:light_blue_concrete
fill 282 238 611 282 242 612 minecraft:white_concrete
setblock 282 238 635 minecraft:amethyst_block
fill 282 238 637 282 303 637 minecraft:white_concrete
fill 282 238 641 282 307 643 minecraft:white_concrete
setblock 282 238 644 minecraft:light_blue_concrete
fill 282 238 645 282 307 646 minecraft:white_concrete
fill 283 238 646 283 307 646 minecraft:white_concrete
setblock 285 238 607 minecraft:light[level=13]
setblock 285 238 615 minecraft:light[level=13]
setblock 285 238 623 minecraft:light[level=13]
setblock 285 238 631 minecraft:light[level=13]
setblock 285 238 639 minecraft:light[level=13]
fill 286 238 646 286 307 646 minecraft:white_concrete
fill 289 238 604 294 243 604 minecraft:white_concrete
setblock 293 238 607 minecraft:light[level=13]
setblock 293 238 615 minecraft:light[level=13]
setblock 293 238 623 minecraft:light[level=13]
setblock 293 238 631 minecraft:light[level=13]
setblock 293 238 639 minecraft:light[level=13]
setblock 295 238 604 minecraft:light_blue_concrete
fill 299 238 624 301 238 624 minecraft:red_nether_bricks
fill 300 238 622 301 238 623 minecraft:red_nether_bricks
fill 300 238 625 301 238 626 minecraft:red_nether_bricks
fill 300 238 646 301 243 646 minecraft:white_concrete
setblock 301 238 607 minecraft:light[level=13]
setblock 301 238 615 minecraft:light[level=13]
fill 301 238 621 302 240 621 minecraft:red_nether_bricks
fill 301 238 627 302 240 627 minecraft:red_nether_bricks
setblock 301 238 631 minecraft:light[level=13]
setblock 301 238 639 minecraft:light[level=13]
fill 302 238 604 319 241 604 minecraft:white_concrete
fill 302 238 620 308 238 620 minecraft:red_nether_bricks
fill 302 238 622 302 239 623 minecraft:quartz_block
fill 302 238 625 302 239 626 minecraft:quartz_block
fill 302 238 628 308 238 628 minecraft:red_nether_bricks
setblock 302 238 646 minecraft:light_blue_concrete
fill 303 238 621 304 239 621 minecraft:quartz_block
setblock 303 238 622 minecraft:red_nether_bricks
setblock 303 238 626 minecraft:red_nether_bricks
fill 303 238 627 304 239 627 minecraft:quartz_block
fill 303 238 646 304 263 646 minecraft:white_concrete
fill 305 238 646 306 238 646 minecraft:light_blue_concrete
fill 306 238 621 307 239 621 minecraft:quartz_block
fill 306 238 627 307 239 627 minecraft:quartz_block
setblock 307 238 622 minecraft:red_nether_bricks
setblock 307 238 626 minecraft:red_nether_bricks
fill 307 238 646 308 293 646 minecraft:white_concrete
fill 308 238 621 309 243 621 minecraft:red_nether_bricks
fill 308 238 622 308 239 623 minecraft:quartz_block
fill 308 238 625 308 239 626 minecraft:quartz_block
fill 308 238 627 309 243 627 minecraft:red_nether_bricks
setblock 309 238 607 minecraft:light[level=13]
setblock 309 238 615 minecraft:light[level=13]
fill 309 238 622 310 238 626 minecraft:red_nether_bricks
setblock 309 238 631 minecraft:light[level=13]
setblock 309 238 639 minecraft:light[level=13]
fill 311 238 624 311 249 624 minecraft:red_nether_bricks
fill 314 238 646 314 277 646 minecraft:white_concrete
setblock 317 238 607 minecraft:light[level=13]
setblock 317 238 615 minecraft:light[level=13]
setblock 317 238 623 minecraft:light[level=13]
setblock 317 238 631 minecraft:light[level=13]
setblock 317 238 639 minecraft:light[level=13]
setblock 317 238 646 minecraft:light_blue_concrete
setblock 320 238 604 minecraft:amethyst_block
fill 321 238 604 323 273 604 minecraft:white_concrete
fill 324 238 613 324 242 614 minecraft:white_concrete
fill 324 238 624 324 307 624 minecraft:white_concrete
fill 324 238 629 324 307 629 minecraft:white_concrete
setblock 324 238 630 minecraft:light_blue_concrete
fill 324 238 632 324 249 634 minecraft:white_concrete
fill 282 239 606 282 240 606 minecraft:white_concrete
fill 282 239 610 282 292 610 minecraft:white_concrete
fill 282 239 613 282 279 618 minecraft:white_concrete
setblock 282 239 619 minecraft:amethyst_block
fill 282 239 620 282 307 621 minecraft:white_concrete
fill 282 239 635 282 307 635 minecraft:white_concrete
fill 282 239 644 282 242 644 minecraft:white_concrete
fill 283 239 604 283 240 604 minecraft:white_concrete
setblock 284 239 604 minecraft:amethyst_block
fill 285 239 604 288 242 604 minecraft:white_concrete
fill 294 239 623 300 245 625 minecraft:nether_bricks
fill 295 239 604 296 261 604 minecraft:white_concrete
fill 295 239 622 299 245 622 minecraft:nether_bricks
fill 295 239 626 299 245 626 minecraft:nether_bricks
fill 299 239 621 300 239 621 minecraft:red_nether_bricks
fill 299 239 627 300 239 627 minecraft:red_nether_bricks
fill 300 239 620 302 246 620 minecraft:red_nether_bricks
setblock 300 239 622 minecraft:red_nether_bricks
setblock 300 239 626 minecraft:red_nether_bricks
fill 300 239 628 302 246 628 minecraft:red_nether_bricks
fill 301 239 619 309 246 619 minecraft:red_nether_bricks
setblock 301 239 622 minecraft:quartz_block
setblock 301 239 623 minecraft:red_nether_bricks
setblock 301 239 624 minecraft:quartz_block
setblock 301 239 625 minecraft:red_nether_bricks
setblock 301 239 626 minecraft:quartz_block
fill 301 239 629 309 246 629 minecraft:red_nether_bricks
setblock 302 239 646 minecraft:white_concrete
setblock 303 239 620 minecraft:quartz_block
setblock 303 239 628 minecraft:quartz_block
fill 304 239 618 306 248 618 minecraft:red_nether_bricks
fill 304 239 620 304 243 620 minecraft:red_nether_bricks
fill 304 239 628 304 243 628 minecraft:red_nether_bricks
fill 304 239 630 306 248 630 minecraft:red_nether_bricks
setblock 305 239 620 minecraft:quartz_block
setblock 305 239 628 minecraft:quartz_block
fill 305 239 646 306 287 646 minecraft:white_concrete
fill 306 239 620 306 243 620 minecraft:red_nether_bricks
fill 306 239 628 306 243 628 minecraft:red_nether_bricks
setblock 307 239 620 minecraft:quartz_block
setblock 307 239 628 minecraft:quartz_block
fill 308 239 620 310 246 620 minecraft:red_nether_bricks
fill 308 239 628 310 246 628 minecraft:red_nether_bricks
setblock 309 239 622 minecraft:quartz_block
fill 309 239 623 312 243 623 minecraft:red_nether_bricks
setblock 309 239 624 minecraft:quartz_block
fill 309 239 625 312 243 625 minecraft:red_nether_bricks
setblock 309 239 626 minecraft:quartz_block
fill 309 239 646 309 299 646 minecraft:white_concrete
fill 310 239 621 311 247 622 minecraft:red_nether_bricks
fill 310 239 624 310 246 624 minecraft:red_nether_bricks
fill 310 239 626 311 247 627 minecraft:red_nether_bricks
fill 312 239 622 312 248 622 minecraft:red_nether_bricks
fill 312 239 624 312 248 624 minecraft:red_nether_bricks
fill 312 239 626 312 248 626 minecraft:red_nether_bricks
fill 317 239 646 317 242 646 minecraft:white_concrete
fill 320 239 604 320 284 604 minecraft:white_concrete
fill 324 239 604 324 307 604 minecraft:white_concrete
fill 324 239 608 324 244 608 minecraft:white_concrete
fill 324 239 630 324 242 630 minecraft:white_concrete
fill 324 239 641 324 307 641 minecraft:white_concrete
fill 282 240 619 282 254 619 minecraft:white_concrete
fill 284 240 604 284 307 604 minecraft:white_concrete
fill 292 240 624 293 244 624 minecraft:nether_bricks
fill 293 240 622 293 242 623 minecraft:nether_bricks
fill 293 240 625 293 242 626 minecraft:nether_bricks
fill 294 240 621 294 244 622 minecraft:nether_bricks
fill 294 240 626 294 244 627 minecraft:nether_bricks
fill 295 240 621 300 244 621 minecraft:nether_bricks
fill 295 240 627 300 244 627 minecraft:nether_bricks
fill 295 240 646 296 242 646 minecraft:white_concrete
setblock 297 240 646 minecraft:pearlescent_froglight
fill 298 240 646 298 307 646 minecraft:white_concrete
setblock 299 240 620 minecraft:red_nether_bricks
setblock 299 240 628 minecraft:red_nether_bricks
fill 300 240 619 300 248 619 minecraft:red_nether_bricks
fill 300 240 622 301 244 622 minecraft:nether_bricks
fill 300 240 626 301 244 626 minecraft:nether_bricks
fill 300 240 629 300 248 629 minecraft:red_nether_bricks
fill 301 240 618 303 247 618 minecraft:red_nether_bricks
fill 301 240 623 301 242 625 minecraft:nether_bricks
fill 301 240 630 303 247 630 minecraft:red_nether_bricks
fill 302 240 622 302 240 623 minecraft:red_nether_bricks
fill 302 240 625 302 240 626 minecraft:red_nether_bricks
setblock 302 240 646 minecraft:amethyst_block
fill 303 240 620 303 241 621 minecraft:red_nether_bricks
fill 303 240 627 303 241 628 minecraft:red_nether_bricks
setblock 304 240 621 minecraft:red_nether_bricks
setblock 304 240 627 minecraft:red_nether_bricks
fill 305 240 620 305 242 620 minecraft:red_nether_bricks
fill 305 240 628 305 242 628 minecraft:red_nether_bricks
fill 306 240 621 307 240 621 minecraft:red_nether_bricks
fill 306 240 627 307 240 627 minecraft:red_nether_bricks
fill 307 240 618 309 247 618 minecraft:red_nether_bricks
fill 307 240 620 307 244 620 minecraft:red_nether_bricks
fill 307 240 628 307 244 628 minecraft:red_nether_bricks
fill 307 240 630 309 247 630 minecraft:red_nether_bricks
fill 308 240 622 308 240 623 minecraft:red_nether_bricks
fill 308 240 625 308 240 626 minecraft:red_nether_bricks
fill 309 240 622 309 244 622 minecraft:red_nether_bricks
fill 309 240 624 309 242 624 minecraft:red_nether_bricks
fill 309 240 626 309 244 626 minecraft:red_nether_bricks
fill 310 240 619 310 248 619 minecraft:red_nether_bricks
fill 310 240 629 310 248 629 minecraft:red_nether_bricks
fill 311 240 620 311 248 620 minecraft:red_nether_bricks
fill 311 240 628 311 248 628 minecraft:red_nether_bricks
fill 312 240 621 312 248 621 minecraft:red_nether_bricks
fill 312 240 627 312 248 627 minecraft:red_nether_bricks
fill 313 240 622 313 247 626 minecraft:red_nether_bricks
setblock 282 241 606 minecraft:pearlescent_froglight
setblock 283 241 604 minecraft:pearlescent_froglight
fill 292 241 622 292 243 623 minecraft:nether_bricks
fill 292 241 625 292 243 626 minecraft:nether_bricks
fill 293 241 621 293 243 621 minecraft:nether_bricks
fill 293 241 627 293 243 627 minecraft:nether_bricks
fill 295 241 620 299 243 620 minecraft:nether_bricks
fill 295 241 628 299 243 628 minecraft:nether_bricks
fill 297 241 646 297 307 646 minecraft:white_concrete
fill 299 241 619 299 247 619 minecraft:red_nether_bricks
fill 299 241 629 299 247 629 minecraft:red_nether_bricks
fill 300 241 618 300 246 618 minecraft:red_nether_bricks
fill 300 241 630 300 246 630 minecraft:red_nether_bricks
fill 301 241 621 301 243 621 minecraft:nether_bricks
fill 301 241 627 301 243 627 minecraft:nether_bricks
fill 302 241 617 308 245 617 minecraft:red_nether_bricks
fill 302 241 621 302 243 621 minecraft:red_nether_bricks
setblock 302 241 622 minecraft:nether_bricks
setblock 302 241 626 minecraft:nether_bricks
fill 302 241 627 302 243 627 minecraft:red_nether_bricks
fill 302 241 631 308 245 631 minecraft:red_nether_bricks
fill 302 241 646 302 261 646 minecraft:white_concrete
setblock 307 241 621 minecraft:red_nether_bricks
setblock 307 241 627 minecraft:red_nether_bricks
setblock 308 241 622 minecraft:red_nether_bricks
setblock 308 241 626 minecraft:red_nether_bricks
fill 310 241 618 310 246 618 minecraft:red_nether_bricks
fill 310 241 630 310 246 630 minecraft:red_nether_bricks
fill 310 241 632 317 241 636 minecraft:red_terracotta
fill 311 241 619 311 247 619 minecraft:red_nether_bricks
fill 311 241 629 311 247 629 minecraft:red_nether_bricks
fill 311 241 631 316 242 631 minecraft:red_terracotta
fill 311 241 637 317 241 637 minecraft:red_terracotta
fill 312 241 620 312 247 620 minecraft:red_nether_bricks
fill 312 241 628 312 247 628 minecraft:red_nether_bricks
fill 312 241 638 315 241 638 minecraft:red_terracotta
fill 313 241 621 313 247 621 minecraft:red_nether_bricks
fill 313 241 627 313 247 627 minecraft:red_nether_bricks
fill 313 241 630 315 241 630 minecraft:red_terracotta
fill 314 241 623 314 246 625 minecraft:red_nether_bricks
fill 318 241 633 318 241 635 minecraft:red_terracotta
fill 282 242 606 282 307 606 minecraft:white_concrete
fill 283 242 604 283 307 604 minecraft:white_concrete
fill 298 242 619 298 246 619 minecraft:red_nether_bricks
fill 298 242 629 298 246 629 minecraft:red_nether_bricks
fill 299 242 618 299 245 618 minecraft:red_nether_bricks
fill 299 242 630 299 245 630 minecraft:red_nether_bricks
fill 301 242 617 301 245 617 minecraft:red_nether_bricks
fill 301 242 631 301 245 631 minecraft:red_nether_bricks
fill 302 242 604 311 242 604 minecraft:white_concrete
fill 303 242 620 303 244 620 minecraft:red_nether_bricks
fill 303 242 628 303 244 628 minecraft:red_nether_bricks
fill 309 242 617 309 245 617 minecraft:red_nether_bricks
fill 309 242 631 309 245 631 minecraft:red_nether_bricks
fill 310 242 633 317 242 635 minecraft:red_terracotta
fill 311 242 618 311 245 618 minecraft:red_nether_bricks
fill 311 242 630 311 245 630 minecraft:red_nether_bricks
fill 311 242 632 317 242 632 minecraft:red_terracotta
fill 311 242 636 316 242 637 minecraft:red_terracotta
setblock 312 242 604 minecraft:pearlescent_froglight
fill 312 242 619 312 246 619 minecraft:red_nether_bricks
fill 312 242 629 312 246 629 minecraft:red_nether_bricks
fill 313 242 604 319 242 604 minecraft:white_concrete
fill 313 242 620 313 246 620 minecraft:red_nether_bricks
fill 313 242 628 313 246 628 minecraft:red_nether_bricks
fill 313 242 630 314 242 630 minecraft:red_terracotta
fill 313 242 638 315 242 638 minecraft:red_terracotta
fill 314 242 622 314 246 622 minecraft:red_nether_bricks
fill 314 242 626 314 246 626 minecraft:red_nether_bricks
fill 317 242 636 317 243 636 minecraft:red_terracotta
setblock 318 242 634 minecraft:red_terracotta
fill 282 243 611 282 303 611 minecraft:white_concrete
fill 282 243 612 282 245 612 minecraft:gold_block
fill 282 243 622 282 244 627 minecraft:white_concrete
fill 282 243 628 282 245 628 minecraft:gold_block
fill 282 243 629 282 307 634 minecraft:white_concrete
fill 282 243 644 282 245 644 minecraft:gold_block
fill 285 243 604 285 274 604 minecraft:white_concrete
fill 286 243 604 286 245 604 minecraft:gold_block
fill 287 243 604 288 283 604 minecraft:white_concrete
fill 293 243 622 293 244 622 minecraft:black_concrete
fill 293 243 623 293 244 623 minecraft:nether_bricks
fill 293 243 625 293 244 625 minecraft:nether_bricks
fill 293 243 626 293 244 626 minecraft:black_concrete
fill 295 243 646 295 307 646 minecraft:white_concrete
fill 296 243 646 296 245 646 minecraft:gold_block
setblock 301 243 623 minecraft:nether_bricks
setblock 301 243 625 minecraft:nether_bricks
fill 302 243 604 302 245 604 minecraft:gold_block
fill 303 243 604 314 259 604 minecraft:white_concrete
fill 310 243 646 311 253 646 minecraft:white_concrete
fill 311 243 632 316 243 636 minecraft:red_terracotta
fill 312 243 631 315 243 631 minecraft:red_terracotta
fill 312 243 637 316 243 637 minecraft:red_terracotta
fill 312 243 646 312 245 646 minecraft:gold_block
fill 313 243 646 313 307 646 minecraft:white_concrete
fill 314 243 621 314 245 621 minecraft:red_nether_bricks
fill 314 243 627 314 245 627 minecraft:red_nether_bricks
setblock 315 243 604 minecraft:amethyst_block
fill 316 243 604 317 265 604 minecraft:white_concrete
fill 317 243 633 317 243 635 minecraft:red_terracotta
setblock 317 243 646 minecraft:pearlescent_froglight
fill 318 243 604 318 245 604 minecraft:gold_block
fill 319 243 604 319 245 604 minecraft:white_concrete
fill 324 243 613 324 293 613 minecraft:white_concrete
fill 324 243 614 324 245 614 minecraft:gold_block
fill 324 243 630 324 245 630 minecraft:gold_block
fill 289 244 604 290 261 604 minecraft:white_concrete
setblock 291 244 604 minecraft:amethyst_block
setblock 292 244 604 minecraft:pearlescent_froglight
setblock 292 244 623 minecraft:nether_bricks
setblock 292 244 625 minecraft:nether_bricks
fill 293 244 604 294 307 604 minecraft:white_concrete
fill 297 244 620 299 246 620 minecraft:red_nether_bricks
fill 297 244 628 299 246 628 minecraft:red_nether_bricks
setblock 300 244 646 minecraft:amethyst_block
fill 301 244 621 301 246 621 minecraft:red_nether_bricks
fill 301 244 627 301 246 627 minecraft:red_nether_bricks
fill 301 244 646 301 290 646 minecraft:white_concrete
fill 309 244 621 309 246 621 minecraft:red_nether_bricks
fill 309 244 627 309 246 627 minecraft:red_nether_bricks
fill 310 244 623 312 246 623 minecraft:red_nether_bricks
fill 310 244 625 312 246 625 minecraft:red_nether_bricks
fill 312 244 633 315 244 636 minecraft:red_terracotta
fill 313 244 632 315 244 632 minecraft:red_terracotta
fill 315 244 604 315 307 604 minecraft:white_concrete
fill 316 244 633 316 244 635 minecraft:red_terracotta
fill 317 244 646 317 286 646 minecraft:white_concrete
fill 282 245 622 282 307 622 minecraft:white_concrete
setblock 282 245 623 minecraft:amethyst_block
fill 282 245 624 282 278 627 minecraft:white_concrete
fill 291 245 604 292 258 604 minecraft:white_concrete
setblock 293 245 624 minecraft:nether_bricks
setblock 294 245 622 minecraft:nether_bricks
setblock 294 245 626 minecraft:nether_bricks
fill 296 245 621 298 245 621 minecraft:nether_bricks
fill 296 245 627 298 245 627 minecraft:nether_bricks
fill 299 245 621 300 248 621 minecraft:red_nether_bricks
fill 299 245 627 300 248 627 minecraft:red_nether_bricks
setblock 300 245 622 minecraft:nether_bricks
setblock 300 245 626 minecraft:nether_bricks
fill 300 245 646 300 267 646 minecraft:white_concrete
setblock 324 245 608 minecraft:amethyst_block
fill 282 246 612 282 251 612 minecraft:white_concrete
fill 282 246 623 282 279 623 minecraft:white_concrete
fill 282 246 628 282 251 628 minecraft:white_concrete
fill 282 246 644 282 251 644 minecraft:white_concrete
setblock 285 246 607 minecraft:light[level=13]
setblock 285 246 615 minecraft:light[level=13]
setblock 285 246 623 minecraft:light[level=13]
setblock 285 246 631 minecraft:light[level=13]
setblock 285 246 639 minecraft:light[level=13]
fill 286 246 604 286 251 604 minecraft:white_concrete
setblock 293 246 607 minecraft:light[level=13]
setblock 293 246 615 minecraft:light[level=13]
setblock 293 246 623 minecraft:light[level=13]
setblock 293 246 631 minecraft:light[level=13]
setblock 293 246 639 minecraft:light[level=13]
fill 296 246 622 300 246 623 minecraft:red_nether_bricks
fill 296 246 624 298 246 624 minecraft:nether_bricks
fill 296 246 625 300 246 626 minecraft:red_nether_bricks
fill 296 246 646 296 251 646 minecraft:white_concrete
fill 297 246 621 298 247 621 minecraft:red_nether_bricks
fill 297 246 627 298 247 627 minecraft:red_nether_bricks
fill 299 246 624 300 246 624 minecraft:red_nether_bricks
setblock 301 246 607 minecraft:light[level=13]
setblock 301 246 615 minecraft:light[level=13]
setblock 301 246 631 minecraft:light[level=13]
setblock 301 246 639 minecraft:light[level=13]
fill 302 246 604 302 251 604 minecraft:white_concrete
fill 302 246 617 306 246 617 minecraft:red_nether_bricks
fill 302 246 631 306 246 631 minecraft:red_nether_bricks
setblock 307 246 617 minecraft:black_concrete
setblock 307 246 631 minecraft:black_concrete
setblock 308 246 617 minecraft:red_nether_bricks
setblock 308 246 631 minecraft:red_nether_bricks
setblock 309 246 607 minecraft:light[level=13]
setblock 309 246 615 minecraft:light[level=13]
setblock 309 246 631 minecraft:light[level=13]
setblock 309 246 639 minecraft:light[level=13]
fill 312 246 646 312 251 646 minecraft:white_concrete
setblock 317 246 607 minecraft:light[level=13]
setblock 317 246 615 minecraft:light[level=13]
setblock 317 246 623 minecraft:light[level=13]
setblock 317 246 631 minecraft:light[level=13]
setblock 317 246 639 minecraft:light[level=13]
fill 318 246 604 318 251 604 minecraft:white_concrete
setblock 319 246 604 minecraft:amethyst_block
fill 324 246 608 324 257 608 minecraft:white_concrete
fill 324 246 614 324 251 614 minecraft:white_concrete
fill 324 246 625 324 267 625 minecraft:white_concrete
setblock 324 246 626 minecraft:pearlescent_froglight
fill 324 246 627 324 252 628 minecraft:white_concrete
fill 324 246 630 324 251 630 minecraft:white_concrete
fill 283 247 607 284 250 609 minecraft:amethyst_block
fill 297 247 622 299 247 626 minecraft:red_nether_bricks
fill 298 247 620 301 247 620 minecraft:red_nether_bricks
fill 298 247 628 301 247 628 minecraft:red_nether_bricks
setblock 300 247 622 minecraft:red_nether_bricks
setblock 300 247 626 minecraft:red_nether_bricks
setblock 301 247 619 minecraft:red_nether_bricks
setblock 301 247 629 minecraft:red_nether_bricks
fill 302 247 619 302 248 619 minecraft:shroomlight
fill 302 247 629 302 248 629 minecraft:shroomlight
setblock 303 247 619 minecraft:red_nether_bricks
setblock 303 247 629 minecraft:red_nether_bricks
fill 304 247 617 306 247 617 minecraft:red_nether_bricks
fill 304 247 631 306 247 631 minecraft:red_nether_bricks
fill 307 247 616 310 247 616 minecraft:black_concrete
fill 307 247 619 309 247 619 minecraft:red_nether_bricks
fill 307 247 629 309 247 629 minecraft:red_nether_bricks
fill 307 247 632 310 247 632 minecraft:black_concrete
fill 309 247 620 310 248 620 minecraft:red_nether_bricks
fill 309 247 628 310 248 628 minecraft:red_nether_bricks
fill 311 247 623 312 248 623 minecraft:red_nether_bricks
fill 311 247 625 312 248 625 minecraft:red_nether_bricks
fill 319 247 604 319 307 604 minecraft:white_concrete
fill 324 247 626 324 265 626 minecraft:white_concrete
fill 283 248 606 284 249 606 minecraft:amethyst_block
fill 283 248 610 284 249 610 minecraft:amethyst_block
fill 285 248 607 285 251 609 minecraft:amethyst_block
fill 297 248 624 299 248 624 minecraft:red_nether_bricks
fill 298 248 621 298 248 623 minecraft:red_nether_bricks
fill 298 248 625 298 248 627 minecraft:red_nether_bricks
fill 299 248 620 300 248 620 minecraft:red_nether_bricks
fill 299 248 622 299 249 623 minecraft:red_nether_bricks
fill 299 248 625 299 249 626 minecraft:red_nether_bricks
fill 299 248 628 300 248 628 minecraft:red_nether_bricks
fill 301 248 619 301 248 620 minecraft:shroomlight
fill 301 248 628 301 248 629 minecraft:shroomlight
setblock 303 248 618 minecraft:red_nether_bricks
setblock 303 248 630 minecraft:red_nether_bricks
setblock 307 248 616 minecraft:black_concrete
setblock 307 248 618 minecraft:red_nether_bricks
setblock 307 248 630 minecraft:red_nether_bricks
setblock 307 248 632 minecraft:black_concrete
fill 308 248 615 312 248 615 minecraft:black_concrete
fill 308 248 619 309 248 619 minecraft:red_nether_bricks
fill 308 248 629 309 248 629 minecraft:red_nether_bricks
fill 308 248 633 312 248 633 minecraft:black_concrete
fill 309 248 642 310 249 642 minecraft:end_stone
fill 310 248 621 311 248 621 minecraft:red_nether_bricks
fill 310 248 627 311 248 627 minecraft:red_nether_bricks
fill 311 248 614 313 248 614 minecraft:black_concrete
fill 311 248 622 311 249 622 minecraft:red_nether_bricks
fill 311 248 626 311 249 626 minecraft:red_nether_bricks
fill 311 248 634 313 248 634 minecraft:black_concrete
setblock 313 248 624 minecraft:red_nether_bricks
setblock 324 248 605 minecraft:pearlescent_froglight
fill 324 248 606 324 307 607 minecraft:white_concrete
fill 286 249 607 286 251 609 minecraft:amethyst_block
setblock 299 249 624 minecraft:red_nether_bricks
setblock 307 249 615 minecraft:black_concrete
setblock 307 249 633 minecraft:black_concrete
setblock 308 249 614 minecraft:black_concrete
setblock 308 249 634 minecraft:black_concrete
fill 310 249 614 311 249 614 minecraft:black_concrete
fill 310 249 634 311 249 634 minecraft:black_concrete
setblock 311 249 623 minecraft:red_nether_bricks
setblock 311 249 625 minecraft:red_nether_bricks
setblock 312 249 613 minecraft:black_concrete
setblock 312 249 635 minecraft:black_concrete
setblock 315 249 613 minecraft:black_concrete
setblock 315 249 635 minecraft:black_concrete
fill 324 249 605 324 298 605 minecraft:white_concrete
fill 324 249 615 324 307 617 minecraft:white_concrete
setblock 324 249 618 minecraft:pearlescent_froglight
fill 324 249 619 324 303 623 minecraft:white_concrete
fill 287 250 608 287 252 608 minecraft:amethyst_block
fill 287 250 646 289 267 646 minecraft:white_concrete
setblock 290 250 646 minecraft:amethyst_block
fill 291 250 646 294 252 646 minecraft:white_concrete
fill 307 250 614 307 251 614 minecraft:black_concrete
fill 307 250 634 307 251 634 minecraft:black_concrete
fill 309 250 613 309 251 613 minecraft:black_concrete
setblock 309 250 619 minecraft:blackstone
setblock 309 250 629 minecraft:blackstone
fill 309 250 635 309 251 635 minecraft:black_concrete
setblock 311 250 613 minecraft:black_concrete
setblock 311 250 635 minecraft:black_concrete
fill 313 250 612 314 250 612 minecraft:black_concrete
fill 313 250 636 314 250 636 minecraft:black_concrete
fill 317 250 612 318 250 612 minecraft:black_concrete
fill 317 250 636 318 250 636 minecraft:black_concrete
fill 318 250 611 319 250 611 minecraft:black_concrete
fill 318 250 637 319 250 637 minecraft:black_concrete
fill 324 250 618 324 271 618 minecraft:white_concrete
setblock 324 250 632 minecraft:pearlescent_froglight
fill 324 250 633 324 307 634 minecraft:white_concrete
fill 283 251 608 284 251 608 minecraft:amethyst_block
setblock 287 251 607 minecraft:amethyst_block
setblock 287 251 609 minecraft:amethyst_block
fill 288 251 608 288 252 608 minecraft:amethyst_block
fill 290 251 646 290 275 646 minecraft:white_concrete
fill 307 251 613 307 252 613 minecraft:black_concrete
fill 307 251 635 307 252 635 minecraft:black_concrete
fill 309 251 612 309 252 612 minecraft:black_concrete
schedule function dropper:buildpart/150_3 1t
