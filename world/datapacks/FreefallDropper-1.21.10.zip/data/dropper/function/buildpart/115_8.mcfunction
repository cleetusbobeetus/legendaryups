setblock 366 263 497 minecraft:red_nether_bricks
fill 366 263 498 366 265 498 minecraft:pink_terracotta
setblock 366 263 502 minecraft:red_nether_bricks
fill 366 263 503 366 266 503 minecraft:pink_terracotta
fill 367 263 492 367 264 492 minecraft:pink_terracotta
setblock 367 263 496 minecraft:red_nether_bricks
fill 367 263 497 367 266 497 minecraft:pink_terracotta
setblock 367 263 501 minecraft:red_nether_bricks
fill 367 263 502 367 266 502 minecraft:pink_terracotta
setblock 368 263 474 minecraft:pink_terracotta
setblock 368 263 475 minecraft:red_nether_bricks
fill 368 263 476 368 266 476 minecraft:pink_terracotta
setblock 368 263 479 minecraft:pink_terracotta
setblock 368 263 480 minecraft:red_nether_bricks
setblock 368 263 490 minecraft:red_nether_bricks
fill 368 263 491 368 265 491 minecraft:pink_terracotta
setblock 368 263 495 minecraft:red_nether_bricks
fill 368 263 496 368 266 496 minecraft:pink_terracotta
setblock 368 263 500 minecraft:red_nether_bricks
fill 368 263 501 368 266 501 minecraft:pink_terracotta
setblock 369 263 474 minecraft:red_nether_bricks
fill 369 263 475 369 266 475 minecraft:pink_terracotta
setblock 369 263 479 minecraft:red_nether_bricks
fill 369 263 480 369 263 483 minecraft:pink_terracotta
setblock 369 263 484 minecraft:red_nether_bricks
fill 369 263 485 369 266 485 minecraft:pink_terracotta
setblock 369 263 489 minecraft:red_nether_bricks
fill 369 263 490 369 266 490 minecraft:pink_terracotta
setblock 369 263 494 minecraft:red_nether_bricks
fill 369 263 495 369 266 495 minecraft:pink_terracotta
setblock 369 263 499 minecraft:red_nether_bricks
fill 369 263 500 369 266 500 minecraft:pink_terracotta
setblock 369 263 504 minecraft:red_nether_bricks
setblock 370 263 469 minecraft:pink_terracotta
setblock 370 263 473 minecraft:red_nether_bricks
fill 370 263 474 370 266 474 minecraft:pink_terracotta
setblock 370 263 478 minecraft:red_nether_bricks
fill 370 263 479 370 266 479 minecraft:pink_terracotta
setblock 370 263 483 minecraft:red_nether_bricks
fill 370 263 484 370 266 484 minecraft:pink_terracotta
setblock 370 263 488 minecraft:red_nether_bricks
fill 370 263 489 370 266 489 minecraft:pink_terracotta
setblock 370 263 493 minecraft:red_nether_bricks
fill 370 263 494 370 266 494 minecraft:pink_terracotta
setblock 370 263 498 minecraft:red_nether_bricks
fill 370 263 499 370 266 499 minecraft:pink_terracotta
setblock 370 263 503 minecraft:red_nether_bricks
fill 370 263 504 370 266 504 minecraft:pink_terracotta
fill 330 264 468 330 265 468 minecraft:pink_terracotta
setblock 330 264 472 minecraft:red_nether_bricks
fill 330 264 473 330 264 476 minecraft:pink_terracotta
setblock 330 264 477 minecraft:red_nether_bricks
fill 330 264 478 330 264 481 minecraft:pink_terracotta
setblock 330 264 482 minecraft:red_nether_bricks
fill 330 264 483 330 267 483 minecraft:pink_terracotta
setblock 330 264 487 minecraft:red_nether_bricks
fill 330 264 488 330 266 488 minecraft:pink_terracotta
setblock 330 264 492 minecraft:red_nether_bricks
fill 330 264 493 330 266 493 minecraft:pink_terracotta
setblock 330 264 497 minecraft:red_nether_bricks
fill 330 264 498 330 267 498 minecraft:pink_terracotta
setblock 330 264 501 minecraft:pink_terracotta
setblock 330 264 502 minecraft:red_nether_bricks
fill 330 264 503 330 267 503 minecraft:pink_terracotta
setblock 331 264 471 minecraft:red_nether_bricks
fill 331 264 472 331 266 472 minecraft:pink_terracotta
setblock 331 264 476 minecraft:red_nether_bricks
fill 331 264 477 331 267 477 minecraft:pink_terracotta
setblock 331 264 481 minecraft:red_nether_bricks
fill 331 264 482 331 267 482 minecraft:pink_terracotta
setblock 331 264 496 minecraft:red_nether_bricks
fill 331 264 497 331 265 497 minecraft:pink_terracotta
setblock 332 264 475 minecraft:red_nether_bricks
fill 332 264 476 332 266 476 minecraft:pink_terracotta
setblock 332 264 480 minecraft:red_nether_bricks
fill 339 264 464 342 264 464 minecraft:pink_terracotta
fill 340 264 504 342 264 504 minecraft:pink_terracotta
setblock 341 264 465 minecraft:pink_terracotta
setblock 342 264 465 minecraft:red_nether_bricks
fill 342 264 503 343 264 503 minecraft:pink_terracotta
setblock 343 264 464 minecraft:red_nether_bricks
fill 343 264 465 343 267 465 minecraft:pink_terracotta
setblock 343 264 504 minecraft:red_nether_bricks
fill 344 264 464 347 264 464 minecraft:pink_terracotta
fill 344 264 466 345 264 466 minecraft:pink_terracotta
setblock 344 264 502 minecraft:pink_terracotta
setblock 344 264 503 minecraft:red_nether_bricks
fill 344 264 504 344 267 504 minecraft:pink_terracotta
setblock 345 264 502 minecraft:red_nether_bricks
fill 345 264 503 345 267 503 minecraft:pink_terracotta
setblock 346 264 466 minecraft:red_nether_bricks
fill 346 264 502 349 264 502 minecraft:pink_terracotta
setblock 347 264 465 minecraft:red_nether_bricks
setblock 347 264 466 minecraft:pink_terracotta
setblock 348 264 464 minecraft:red_nether_bricks
fill 348 264 465 348 267 465 minecraft:pink_terracotta
setblock 348 264 503 minecraft:pink_terracotta
setblock 348 264 504 minecraft:red_nether_bricks
fill 349 264 464 349 267 464 minecraft:pink_terracotta
setblock 349 264 503 minecraft:red_nether_bricks
fill 349 264 504 349 267 504 minecraft:pink_terracotta
setblock 350 264 502 minecraft:red_nether_bricks
fill 350 264 503 350 267 503 minecraft:pink_terracotta
fill 351 264 502 351 267 502 minecraft:pink_terracotta
setblock 353 264 464 minecraft:red_nether_bricks
setblock 353 264 504 minecraft:red_nether_bricks
setblock 354 264 503 minecraft:red_nether_bricks
fill 354 264 504 357 264 504 minecraft:pink_terracotta
fill 355 264 503 358 264 503 minecraft:pink_terracotta
setblock 358 264 504 minecraft:red_nether_bricks
setblock 359 264 502 minecraft:pink_terracotta
setblock 359 264 503 minecraft:red_nether_bricks
fill 359 264 504 359 267 504 minecraft:pink_terracotta
setblock 360 264 502 minecraft:red_nether_bricks
fill 360 264 503 363 264 503 minecraft:pink_terracotta
fill 361 264 464 362 264 464 minecraft:pink_terracotta
fill 361 264 502 364 264 502 minecraft:pink_terracotta
fill 362 264 501 365 264 501 minecraft:pink_terracotta
setblock 363 264 464 minecraft:red_nether_bricks
setblock 363 264 504 minecraft:red_nether_bricks
fill 364 264 464 364 267 464 minecraft:pink_terracotta
setblock 364 264 503 minecraft:red_nether_bricks
fill 364 264 504 364 267 504 minecraft:pink_terracotta
setblock 365 264 502 minecraft:red_nether_bricks
fill 365 264 503 365 267 503 minecraft:pink_terracotta
setblock 366 264 495 minecraft:pink_terracotta
setblock 366 264 496 minecraft:red_nether_bricks
fill 366 264 497 366 265 497 minecraft:pink_terracotta
fill 366 264 499 366 265 499 minecraft:pink_terracotta
setblock 366 264 501 minecraft:red_nether_bricks
fill 366 264 502 366 267 502 minecraft:pink_terracotta
setblock 367 264 495 minecraft:red_nether_bricks
fill 367 264 496 367 266 496 minecraft:pink_terracotta
setblock 367 264 500 minecraft:red_nether_bricks
fill 367 264 501 367 266 501 minecraft:pink_terracotta
setblock 368 264 474 minecraft:red_nether_bricks
fill 368 264 475 368 265 475 minecraft:pink_terracotta
setblock 368 264 479 minecraft:red_nether_bricks
fill 368 264 480 369 264 482 minecraft:pink_terracotta
setblock 368 264 489 minecraft:red_nether_bricks
fill 368 264 490 368 265 490 minecraft:pink_terracotta
setblock 368 264 494 minecraft:red_nether_bricks
fill 368 264 495 368 267 495 minecraft:pink_terracotta
setblock 368 264 499 minecraft:red_nether_bricks
fill 368 264 500 368 267 500 minecraft:pink_terracotta
setblock 368 264 504 minecraft:red_nether_bricks
setblock 369 264 473 minecraft:red_nether_bricks
fill 369 264 474 369 266 474 minecraft:pink_terracotta
setblock 369 264 478 minecraft:red_nether_bricks
fill 369 264 479 369 267 479 minecraft:pink_terracotta
setblock 369 264 483 minecraft:red_nether_bricks
fill 369 264 484 369 267 484 minecraft:pink_terracotta
setblock 369 264 488 minecraft:red_nether_bricks
fill 369 264 489 369 266 489 minecraft:pink_terracotta
setblock 369 264 493 minecraft:red_nether_bricks
fill 369 264 494 369 267 494 minecraft:pink_terracotta
setblock 369 264 498 minecraft:red_nether_bricks
fill 369 264 499 369 267 499 minecraft:pink_terracotta
setblock 369 264 503 minecraft:red_nether_bricks
fill 369 264 504 369 267 504 minecraft:pink_terracotta
setblock 370 264 466 minecraft:white_concrete
setblock 370 264 472 minecraft:red_nether_bricks
fill 370 264 473 370 267 473 minecraft:pink_terracotta
setblock 370 264 477 minecraft:red_nether_bricks
fill 370 264 478 370 267 478 minecraft:pink_terracotta
setblock 370 264 482 minecraft:red_nether_bricks
fill 370 264 483 370 267 483 minecraft:pink_terracotta
setblock 370 264 487 minecraft:red_nether_bricks
fill 370 264 488 370 267 488 minecraft:pink_terracotta
setblock 370 264 492 minecraft:red_nether_bricks
fill 370 264 493 370 267 493 minecraft:pink_terracotta
setblock 370 264 497 minecraft:red_nether_bricks
fill 370 264 498 370 267 498 minecraft:pink_terracotta
setblock 370 264 502 minecraft:red_nether_bricks
fill 370 264 503 370 267 503 minecraft:pink_terracotta
setblock 330 265 464 minecraft:white_concrete
setblock 330 265 471 minecraft:red_nether_bricks
fill 330 265 472 330 265 475 minecraft:pink_terracotta
setblock 330 265 476 minecraft:red_nether_bricks
fill 330 265 477 330 265 480 minecraft:pink_terracotta
setblock 330 265 481 minecraft:red_nether_bricks
fill 330 265 482 330 268 482 minecraft:pink_terracotta
setblock 330 265 486 minecraft:red_nether_bricks
fill 330 265 487 330 267 487 minecraft:pink_terracotta
setblock 330 265 491 minecraft:red_nether_bricks
fill 330 265 492 330 266 492 minecraft:pink_terracotta
setblock 330 265 496 minecraft:red_nether_bricks
fill 330 265 497 330 267 497 minecraft:pink_terracotta
setblock 330 265 501 minecraft:red_nether_bricks
fill 330 265 502 330 268 502 minecraft:pink_terracotta
setblock 331 265 471 minecraft:pink_terracotta
setblock 331 265 475 minecraft:red_nether_bricks
fill 331 265 476 331 268 476 minecraft:pink_terracotta
setblock 331 265 479 minecraft:pink_terracotta
setblock 331 265 480 minecraft:red_nether_bricks
fill 331 265 481 331 268 481 minecraft:pink_terracotta
setblock 332 265 466 minecraft:light[level=12]
setblock 332 265 474 minecraft:red_nether_bricks
fill 332 265 475 332 266 475 minecraft:pink_terracotta
setblock 332 265 479 minecraft:red_nether_bricks
fill 332 265 480 332 267 480 minecraft:pink_terracotta
setblock 332 265 482 minecraft:light[level=12]
setblock 332 265 490 minecraft:light[level=12]
setblock 332 265 498 minecraft:light[level=12]
setblock 334 265 504 minecraft:white_concrete
fill 338 265 464 341 265 464 minecraft:pink_terracotta
fill 339 265 504 341 265 504 minecraft:pink_terracotta
setblock 340 265 466 minecraft:light[level=12]
setblock 340 265 474 minecraft:light[level=12]
setblock 340 265 482 minecraft:light[level=12]
setblock 340 265 490 minecraft:light[level=12]
setblock 340 265 498 minecraft:light[level=12]
setblock 341 265 465 minecraft:red_nether_bricks
fill 341 265 503 342 265 503 minecraft:pink_terracotta
setblock 342 265 464 minecraft:red_nether_bricks
fill 342 265 465 342 268 465 minecraft:pink_terracotta
setblock 342 265 504 minecraft:red_nether_bricks
fill 343 265 464 346 265 464 minecraft:pink_terracotta
fill 343 265 466 344 265 466 minecraft:pink_terracotta
setblock 343 265 502 minecraft:pink_terracotta
setblock 343 265 503 minecraft:red_nether_bricks
fill 343 265 504 343 268 504 minecraft:pink_terracotta
setblock 344 265 502 minecraft:red_nether_bricks
fill 344 265 503 344 268 503 minecraft:pink_terracotta
setblock 345 265 466 minecraft:red_nether_bricks
fill 345 265 502 348 265 502 minecraft:pink_terracotta
setblock 346 265 465 minecraft:red_nether_bricks
fill 346 265 466 346 266 466 minecraft:pink_terracotta
fill 346 265 501 346 267 501 minecraft:pink_terracotta
setblock 347 265 464 minecraft:red_nether_bricks
fill 347 265 465 347 268 465 minecraft:pink_terracotta
fill 347 265 493 347 266 493 minecraft:red_concrete
setblock 347 265 504 minecraft:red_nether_bricks
fill 348 265 464 348 268 464 minecraft:pink_terracotta
setblock 348 265 466 minecraft:light[level=12]
setblock 348 265 474 minecraft:light[level=12]
setblock 348 265 482 minecraft:light[level=12]
setblock 348 265 490 minecraft:light[level=12]
setblock 348 265 498 minecraft:light[level=12]
setblock 348 265 503 minecraft:red_nether_bricks
fill 348 265 504 348 268 504 minecraft:pink_terracotta
setblock 349 265 502 minecraft:red_nether_bricks
fill 349 265 503 349 268 503 minecraft:pink_terracotta
fill 350 265 502 350 268 502 minecraft:pink_terracotta
setblock 352 265 464 minecraft:red_nether_bricks
setblock 352 265 504 minecraft:red_nether_bricks
fill 353 265 464 353 266 464 minecraft:pink_terracotta
setblock 353 265 503 minecraft:red_nether_bricks
fill 353 265 504 356 265 504 minecraft:pink_terracotta
fill 354 265 503 357 265 503 minecraft:pink_terracotta
setblock 356 265 466 minecraft:light[level=12]
setblock 356 265 474 minecraft:light[level=12]
setblock 356 265 482 minecraft:light[level=12]
setblock 356 265 490 minecraft:light[level=12]
setblock 356 265 498 minecraft:light[level=12]
setblock 357 265 504 minecraft:red_nether_bricks
setblock 358 265 502 minecraft:pink_terracotta
setblock 358 265 503 minecraft:red_nether_bricks
fill 358 265 504 358 268 504 minecraft:pink_terracotta
setblock 359 265 502 minecraft:red_nether_bricks
fill 359 265 503 362 265 503 minecraft:pink_terracotta
fill 360 265 464 361 265 464 minecraft:pink_terracotta
setblock 360 265 501 minecraft:red_nether_bricks
fill 360 265 502 363 265 502 minecraft:pink_terracotta
fill 361 265 501 364 265 501 minecraft:pink_terracotta
setblock 362 265 464 minecraft:red_nether_bricks
setblock 362 265 504 minecraft:red_nether_bricks
fill 363 265 464 363 268 464 minecraft:pink_terracotta
setblock 363 265 503 minecraft:red_nether_bricks
fill 363 265 504 363 268 504 minecraft:pink_terracotta
setblock 364 265 466 minecraft:light[level=12]
setblock 364 265 474 minecraft:light[level=12]
setblock 364 265 482 minecraft:light[level=12]
setblock 364 265 490 minecraft:light[level=12]
setblock 364 265 498 minecraft:light[level=12]
fill 364 265 500 365 265 500 minecraft:pink_terracotta
setblock 364 265 502 minecraft:red_nether_bricks
fill 364 265 503 364 268 503 minecraft:pink_terracotta
setblock 365 265 501 minecraft:red_nether_bricks
fill 365 265 502 365 268 502 minecraft:pink_terracotta
setblock 366 265 464 minecraft:pink_terracotta
setblock 366 265 496 minecraft:pink_terracotta
fill 366 265 501 366 267 501 minecraft:pink_terracotta
setblock 367 265 464 minecraft:red_nether_bricks
setblock 367 265 494 minecraft:red_nether_bricks
fill 367 265 495 367 266 495 minecraft:pink_terracotta
setblock 367 265 499 minecraft:red_nether_bricks
fill 367 265 500 367 267 500 minecraft:pink_terracotta
setblock 367 265 504 minecraft:red_nether_bricks
setblock 368 265 477 minecraft:pink_terracotta
setblock 368 265 478 minecraft:red_nether_bricks
fill 368 265 479 368 265 482 minecraft:pink_terracotta
setblock 368 265 483 minecraft:red_nether_bricks
fill 368 265 484 368 267 484 minecraft:pink_terracotta
setblock 368 265 493 minecraft:red_nether_bricks
fill 368 265 494 368 267 494 minecraft:pink_terracotta
setblock 368 265 498 minecraft:red_nether_bricks
fill 368 265 499 368 268 499 minecraft:pink_terracotta
setblock 368 265 503 minecraft:red_nether_bricks
fill 368 265 504 368 268 504 minecraft:pink_terracotta
setblock 369 265 473 minecraft:pink_terracotta
setblock 369 265 477 minecraft:red_nether_bricks
fill 369 265 478 369 268 478 minecraft:pink_terracotta
fill 369 265 480 369 265 481 minecraft:pink_terracotta
setblock 369 265 482 minecraft:red_nether_bricks
fill 369 265 483 369 268 483 minecraft:pink_terracotta
setblock 369 265 487 minecraft:red_nether_bricks
fill 369 265 488 369 267 488 minecraft:pink_terracotta
setblock 369 265 492 minecraft:red_nether_bricks
fill 369 265 493 369 267 493 minecraft:pink_terracotta
setblock 369 265 497 minecraft:red_nether_bricks
fill 369 265 498 369 268 498 minecraft:pink_terracotta
setblock 369 265 502 minecraft:red_nether_bricks
fill 369 265 503 369 268 503 minecraft:pink_terracotta
setblock 370 265 471 minecraft:red_nether_bricks
fill 370 265 472 370 266 472 minecraft:pink_terracotta
setblock 370 265 476 minecraft:red_nether_bricks
fill 370 265 477 370 268 477 minecraft:pink_terracotta
setblock 370 265 481 minecraft:red_nether_bricks
fill 370 265 482 370 268 482 minecraft:pink_terracotta
setblock 370 265 486 minecraft:red_nether_bricks
fill 370 265 487 370 268 487 minecraft:pink_terracotta
setblock 370 265 491 minecraft:red_nether_bricks
fill 370 265 492 370 268 492 minecraft:pink_terracotta
setblock 370 265 496 minecraft:red_nether_bricks
fill 370 265 497 370 268 497 minecraft:pink_terracotta
setblock 370 265 501 minecraft:red_nether_bricks
fill 370 265 502 370 268 502 minecraft:pink_terracotta
setblock 330 266 470 minecraft:red_nether_bricks
fill 330 266 471 330 266 474 minecraft:pink_terracotta
setblock 330 266 475 minecraft:red_nether_bricks
fill 330 266 476 330 266 479 minecraft:pink_terracotta
setblock 330 266 480 minecraft:red_nether_bricks
fill 330 266 481 330 269 481 minecraft:pink_terracotta
setblock 330 266 484 minecraft:pink_terracotta
setblock 330 266 485 minecraft:red_nether_bricks
fill 330 266 486 330 269 486 minecraft:pink_terracotta
setblock 330 266 490 minecraft:red_nether_bricks
setblock 330 266 491 minecraft:pink_terracotta
setblock 330 266 495 minecraft:red_nether_bricks
fill 330 266 496 330 267 496 minecraft:pink_terracotta
setblock 330 266 500 minecraft:red_nether_bricks
fill 330 266 501 330 268 501 minecraft:pink_terracotta
setblock 331 266 474 minecraft:red_nether_bricks
fill 331 266 475 331 268 475 minecraft:pink_terracotta
setblock 331 266 479 minecraft:red_nether_bricks
fill 331 266 480 331 269 480 minecraft:pink_terracotta
setblock 331 266 484 minecraft:red_nether_bricks
setblock 332 266 478 minecraft:red_nether_bricks
fill 332 266 479 332 267 479 minecraft:pink_terracotta
setblock 335 266 464 minecraft:white_concrete
fill 338 266 464 340 266 464 minecraft:pink_terracotta
fill 338 266 504 340 266 504 minecraft:pink_terracotta
setblock 340 266 465 minecraft:red_nether_bricks
fill 340 266 503 341 266 503 minecraft:pink_terracotta
setblock 341 266 464 minecraft:red_nether_bricks
fill 341 266 465 341 269 465 minecraft:pink_terracotta
setblock 341 266 504 minecraft:red_nether_bricks
fill 342 266 464 345 266 464 minecraft:pink_terracotta
setblock 342 266 502 minecraft:pink_terracotta
setblock 342 266 503 minecraft:red_nether_bricks
fill 342 266 504 342 269 504 minecraft:pink_terracotta
setblock 343 266 466 minecraft:pink_terracotta
setblock 343 266 502 minecraft:red_nether_bricks
fill 343 266 503 343 269 503 minecraft:pink_terracotta
setblock 344 266 466 minecraft:red_nether_bricks
fill 344 266 502 347 266 502 minecraft:pink_terracotta
setblock 345 266 465 minecraft:red_nether_bricks
fill 345 266 466 345 267 466 minecraft:pink_terracotta
fill 345 266 501 345 267 501 minecraft:pink_terracotta
setblock 346 266 464 minecraft:red_nether_bricks
fill 346 266 465 346 269 465 minecraft:pink_terracotta
setblock 346 266 504 minecraft:red_nether_bricks
fill 347 266 464 347 269 464 minecraft:pink_terracotta
setblock 347 266 501 minecraft:pink_terracotta
setblock 347 266 503 minecraft:red_nether_bricks
fill 347 266 504 347 269 504 minecraft:pink_terracotta
setblock 348 266 502 minecraft:red_nether_bricks
fill 348 266 503 348 269 503 minecraft:pink_terracotta
fill 349 266 502 349 269 502 minecraft:pink_terracotta
setblock 351 266 464 minecraft:red_nether_bricks
setblock 351 266 504 minecraft:red_nether_bricks
fill 352 266 464 352 268 464 minecraft:pink_terracotta
setblock 352 266 502 minecraft:pink_terracotta
setblock 352 266 503 minecraft:red_nether_bricks
fill 352 266 504 355 266 504 minecraft:pink_terracotta
fill 353 266 503 356 266 503 minecraft:pink_terracotta
setblock 356 266 504 minecraft:red_nether_bricks
setblock 357 266 502 minecraft:pink_terracotta
setblock 357 266 503 minecraft:red_nether_bricks
fill 357 266 504 357 269 504 minecraft:pink_terracotta
setblock 358 266 502 minecraft:red_nether_bricks
fill 358 266 503 361 266 503 minecraft:pink_terracotta
fill 359 266 464 360 266 464 minecraft:pink_terracotta
fill 359 266 502 362 266 502 minecraft:pink_terracotta
fill 360 266 501 363 266 501 minecraft:pink_terracotta
setblock 361 266 464 minecraft:red_nether_bricks
setblock 361 266 504 minecraft:red_nether_bricks
fill 362 266 464 362 269 464 minecraft:pink_terracotta
setblock 362 266 503 minecraft:red_nether_bricks
fill 362 266 504 362 269 504 minecraft:pink_terracotta
fill 363 266 500 364 266 500 minecraft:pink_terracotta
setblock 363 266 502 minecraft:red_nether_bricks
fill 363 266 503 363 269 503 minecraft:pink_terracotta
setblock 364 266 501 minecraft:red_nether_bricks
fill 364 266 502 364 269 502 minecraft:pink_terracotta
fill 365 266 501 365 268 501 minecraft:pink_terracotta
setblock 366 266 464 minecraft:red_nether_bricks
setblock 366 266 504 minecraft:red_nether_bricks
fill 367 266 464 367 267 464 minecraft:pink_terracotta
setblock 367 266 498 minecraft:red_nether_bricks
fill 367 266 499 367 267 499 minecraft:pink_terracotta
setblock 367 266 503 minecraft:red_nether_bricks
fill 367 266 504 367 269 504 minecraft:pink_terracotta
setblock 368 266 477 minecraft:red_nether_bricks
fill 368 266 478 368 266 481 minecraft:pink_terracotta
setblock 368 266 482 minecraft:red_nether_bricks
fill 368 266 483 368 269 483 minecraft:pink_terracotta
setblock 368 266 492 minecraft:red_nether_bricks
setblock 368 266 493 minecraft:pink_terracotta
setblock 368 266 497 minecraft:red_nether_bricks
fill 368 266 498 368 268 498 minecraft:pink_terracotta
setblock 368 266 502 minecraft:red_nether_bricks
fill 368 266 503 368 269 503 minecraft:pink_terracotta
setblock 369 266 476 minecraft:red_nether_bricks
fill 369 266 477 369 269 477 minecraft:pink_terracotta
setblock 369 266 480 minecraft:pink_terracotta
setblock 369 266 481 minecraft:red_nether_bricks
fill 369 266 482 369 269 482 minecraft:pink_terracotta
setblock 369 266 486 minecraft:red_nether_bricks
fill 369 266 487 369 267 487 minecraft:pink_terracotta
setblock 369 266 491 minecraft:red_nether_bricks
fill 369 266 492 369 267 492 minecraft:pink_terracotta
setblock 369 266 496 minecraft:red_nether_bricks
fill 369 266 497 369 268 497 minecraft:pink_terracotta
setblock 369 266 501 minecraft:red_nether_bricks
fill 369 266 502 369 268 502 minecraft:pink_terracotta
setblock 370 266 475 minecraft:red_nether_bricks
fill 370 266 476 370 269 476 minecraft:pink_terracotta
setblock 370 266 480 minecraft:red_nether_bricks
fill 370 266 481 370 269 481 minecraft:pink_terracotta
setblock 370 266 485 minecraft:red_nether_bricks
fill 370 266 486 370 269 486 minecraft:pink_terracotta
setblock 370 266 490 minecraft:red_nether_bricks
fill 370 266 491 370 268 491 minecraft:pink_terracotta
setblock 370 266 495 minecraft:red_nether_bricks
fill 370 266 496 370 269 496 minecraft:pink_terracotta
setblock 370 266 500 minecraft:red_nether_bricks
fill 370 266 501 370 269 501 minecraft:pink_terracotta
fill 330 267 470 330 267 473 minecraft:pink_terracotta
setblock 330 267 474 minecraft:red_nether_bricks
fill 330 267 475 330 267 478 minecraft:pink_terracotta
setblock 330 267 479 minecraft:red_nether_bricks
fill 330 267 480 330 270 480 minecraft:pink_terracotta
setblock 330 267 484 minecraft:red_nether_bricks
fill 330 267 485 330 270 485 minecraft:pink_terracotta
setblock 330 267 495 minecraft:pink_terracotta
setblock 330 267 499 minecraft:red_nether_bricks
fill 330 267 500 330 268 500 minecraft:pink_terracotta
setblock 331 267 473 minecraft:red_nether_bricks
setblock 331 267 474 minecraft:pink_terracotta
setblock 331 267 478 minecraft:red_nether_bricks
fill 331 267 479 331 270 479 minecraft:pink_terracotta
setblock 331 267 483 minecraft:red_nether_bricks
setblock 332 267 477 minecraft:red_nether_bricks
setblock 332 267 478 minecraft:pink_terracotta
fill 337 267 464 339 267 464 minecraft:pink_terracotta
fill 337 267 504 339 267 504 minecraft:pink_terracotta
setblock 339 267 465 minecraft:red_nether_bricks
fill 339 267 503 340 267 503 minecraft:pink_terracotta
setblock 340 267 464 minecraft:red_nether_bricks
fill 340 267 465 340 270 465 minecraft:pink_terracotta
setblock 340 267 504 minecraft:red_nether_bricks
fill 341 267 464 344 267 464 minecraft:pink_terracotta
setblock 341 267 502 minecraft:pink_terracotta
setblock 341 267 503 minecraft:red_nether_bricks
fill 341 267 504 341 270 504 minecraft:pink_terracotta
setblock 342 267 502 minecraft:red_nether_bricks
fill 342 267 503 342 270 503 minecraft:pink_terracotta
setblock 343 267 466 minecraft:red_nether_bricks
fill 343 267 502 346 267 502 minecraft:pink_terracotta
setblock 344 267 465 minecraft:red_nether_bricks
fill 344 267 466 344 268 466 minecraft:pink_terracotta
setblock 345 267 464 minecraft:red_nether_bricks
fill 345 267 465 345 270 465 minecraft:pink_terracotta
setblock 345 267 504 minecraft:red_nether_bricks
fill 346 267 464 346 270 464 minecraft:pink_terracotta
setblock 346 267 503 minecraft:red_nether_bricks
fill 346 267 504 346 270 504 minecraft:pink_terracotta
setblock 347 267 502 minecraft:red_nether_bricks
fill 347 267 503 347 270 503 minecraft:pink_terracotta
fill 348 267 502 348 269 502 minecraft:pink_terracotta
setblock 349 267 465 minecraft:red_nether_bricks
setblock 350 267 464 minecraft:red_nether_bricks
setblock 350 267 504 minecraft:red_nether_bricks
fill 351 267 464 351 269 464 minecraft:pink_terracotta
setblock 351 267 503 minecraft:red_nether_bricks
fill 351 267 504 354 267 504 minecraft:pink_terracotta
fill 352 267 503 355 267 503 minecraft:pink_terracotta
setblock 354 267 464 minecraft:white_concrete
setblock 355 267 504 minecraft:red_nether_bricks
setblock 356 267 502 minecraft:pink_terracotta
setblock 356 267 503 minecraft:red_nether_bricks
fill 356 267 504 356 270 504 minecraft:pink_terracotta
setblock 357 267 502 minecraft:red_nether_bricks
fill 357 267 503 360 267 503 minecraft:pink_terracotta
fill 358 267 502 361 267 502 minecraft:pink_terracotta
setblock 359 267 464 minecraft:pink_terracotta
fill 359 267 501 362 267 501 minecraft:pink_terracotta
setblock 360 267 464 minecraft:red_nether_bricks
setblock 360 267 504 minecraft:red_nether_bricks
fill 361 267 464 361 270 464 minecraft:pink_terracotta
setblock 361 267 503 minecraft:red_nether_bricks
fill 361 267 504 361 270 504 minecraft:pink_terracotta
setblock 362 267 502 minecraft:red_nether_bricks
fill 362 267 503 362 270 503 minecraft:pink_terracotta
setblock 363 267 501 minecraft:red_nether_bricks
fill 363 267 502 363 270 502 minecraft:pink_terracotta
fill 364 267 501 364 269 501 minecraft:pink_terracotta
setblock 365 267 464 minecraft:red_nether_bricks
setblock 365 267 504 minecraft:red_nether_bricks
fill 366 267 464 366 268 464 minecraft:pink_terracotta
setblock 366 267 503 minecraft:red_nether_bricks
fill 366 267 504 366 270 504 minecraft:pink_terracotta
setblock 367 267 497 minecraft:red_nether_bricks
setblock 367 267 498 minecraft:pink_terracotta
setblock 367 267 502 minecraft:red_nether_bricks
fill 367 267 503 367 270 503 minecraft:pink_terracotta
fill 368 267 477 368 267 480 minecraft:pink_terracotta
setblock 368 267 481 minecraft:red_nether_bricks
fill 368 267 482 368 269 482 minecraft:pink_terracotta
setblock 368 267 496 minecraft:red_nether_bricks
fill 368 267 497 368 268 497 minecraft:pink_terracotta
setblock 368 267 501 minecraft:red_nether_bricks
setblock 368 267 502 minecraft:pink_terracotta
setblock 369 267 475 minecraft:red_nether_bricks
fill 369 267 476 369 268 476 minecraft:pink_terracotta
setblock 369 267 480 minecraft:red_nether_bricks
fill 369 267 481 369 270 481 minecraft:pink_terracotta
setblock 369 267 485 minecraft:red_nether_bricks
fill 369 267 486 369 269 486 minecraft:pink_terracotta
setblock 369 267 490 minecraft:red_nether_bricks
setblock 369 267 491 minecraft:pink_terracotta
setblock 369 267 495 minecraft:red_nether_bricks
fill 369 267 496 369 268 496 minecraft:pink_terracotta
setblock 369 267 500 minecraft:red_nether_bricks
fill 369 267 501 369 269 501 minecraft:pink_terracotta
setblock 370 267 467 minecraft:white_concrete
setblock 370 267 474 minecraft:red_nether_bricks
fill 370 267 475 370 269 475 minecraft:pink_terracotta
setblock 370 267 479 minecraft:red_nether_bricks
fill 370 267 480 370 270 480 minecraft:pink_terracotta
setblock 370 267 484 minecraft:red_nether_bricks
fill 370 267 485 370 270 485 minecraft:pink_terracotta
setblock 370 267 489 minecraft:red_nether_bricks
fill 370 267 490 370 268 490 minecraft:pink_terracotta
setblock 370 267 494 minecraft:red_nether_bricks
fill 370 267 495 370 269 495 minecraft:pink_terracotta
setblock 370 267 499 minecraft:red_nether_bricks
fill 370 267 500 370 270 500 minecraft:pink_terracotta
setblock 370 267 504 minecraft:red_nether_bricks
setblock 330 268 472 minecraft:pink_terracotta
setblock 330 268 473 minecraft:red_nether_bricks
fill 330 268 474 330 268 477 minecraft:pink_terracotta
setblock 330 268 478 minecraft:red_nether_bricks
fill 330 268 479 330 271 479 minecraft:pink_terracotta
setblock 330 268 483 minecraft:red_nether_bricks
fill 330 268 484 330 271 484 minecraft:pink_terracotta
setblock 330 268 498 minecraft:red_nether_bricks
setblock 330 268 499 minecraft:pink_terracotta
setblock 331 268 477 minecraft:red_nether_bricks
fill 331 268 478 331 270 478 minecraft:pink_terracotta
setblock 331 268 482 minecraft:red_nether_bricks
setblock 331 268 483 minecraft:pink_terracotta
setblock 333 268 504 minecraft:white_concrete
fill 336 268 464 338 268 464 minecraft:pink_terracotta
fill 337 268 504 338 268 504 minecraft:pink_terracotta
setblock 339 268 464 minecraft:red_nether_bricks
fill 339 268 465 339 271 465 minecraft:pink_terracotta
setblock 339 268 503 minecraft:pink_terracotta
setblock 339 268 504 minecraft:red_nether_bricks
fill 340 268 464 343 268 464 minecraft:pink_terracotta
setblock 340 268 503 minecraft:red_nether_bricks
fill 340 268 504 340 271 504 minecraft:pink_terracotta
setblock 341 268 502 minecraft:red_nether_bricks
fill 341 268 503 341 271 503 minecraft:pink_terracotta
fill 342 268 502 345 268 502 minecraft:pink_terracotta
setblock 343 268 465 minecraft:red_nether_bricks
setblock 343 268 466 minecraft:pink_terracotta
setblock 344 268 464 minecraft:red_nether_bricks
fill 344 268 465 344 271 465 minecraft:pink_terracotta
setblock 344 268 504 minecraft:red_nether_bricks
fill 345 268 464 345 271 464 minecraft:pink_terracotta
setblock 345 268 503 minecraft:red_nether_bricks
fill 345 268 504 345 271 504 minecraft:pink_terracotta
setblock 346 268 502 minecraft:red_nether_bricks
fill 346 268 503 346 271 503 minecraft:pink_terracotta
fill 347 268 502 347 270 502 minecraft:pink_terracotta
setblock 348 268 465 minecraft:red_nether_bricks
setblock 349 268 464 minecraft:red_nether_bricks
setblock 349 268 504 minecraft:red_nether_bricks
fill 350 268 464 350 271 464 minecraft:pink_terracotta
setblock 350 268 503 minecraft:red_nether_bricks
fill 350 268 504 353 268 504 minecraft:pink_terracotta
fill 351 268 503 354 268 503 minecraft:pink_terracotta
setblock 354 268 504 minecraft:red_nether_bricks
setblock 355 268 503 minecraft:red_nether_bricks
fill 355 268 504 355 271 504 minecraft:pink_terracotta
setblock 356 268 502 minecraft:red_nether_bricks
fill 356 268 503 359 268 503 minecraft:pink_terracotta
fill 357 268 502 360 268 502 minecraft:pink_terracotta
setblock 358 268 464 minecraft:pink_terracotta
setblock 359 268 464 minecraft:red_nether_bricks
fill 359 268 501 361 268 501 minecraft:pink_terracotta
setblock 359 268 504 minecraft:red_nether_bricks
fill 360 268 464 360 271 464 minecraft:pink_terracotta
setblock 360 268 503 minecraft:red_nether_bricks
fill 360 268 504 360 271 504 minecraft:pink_terracotta
setblock 361 268 502 minecraft:red_nether_bricks
fill 361 268 503 361 271 503 minecraft:pink_terracotta
setblock 362 268 501 minecraft:red_nether_bricks
fill 362 268 502 362 271 502 minecraft:pink_terracotta
fill 363 268 501 363 269 501 minecraft:pink_terracotta
setblock 364 268 464 minecraft:red_nether_bricks
setblock 364 268 504 minecraft:red_nether_bricks
fill 365 268 464 365 271 464 minecraft:pink_terracotta
setblock 365 268 503 minecraft:red_nether_bricks
fill 365 268 504 365 271 504 minecraft:pink_terracotta
setblock 366 268 502 minecraft:red_nether_bricks
fill 366 268 503 366 271 503 minecraft:pink_terracotta
setblock 367 268 464 minecraft:white_concrete
setblock 367 268 502 minecraft:pink_terracotta
fill 368 268 478 368 268 479 minecraft:pink_terracotta
setblock 368 268 480 minecraft:red_nether_bricks
fill 368 268 481 368 269 481 minecraft:pink_terracotta
setblock 368 268 500 minecraft:red_nether_bricks
setblock 368 268 501 minecraft:pink_terracotta
setblock 369 268 479 minecraft:red_nether_bricks
fill 369 268 480 369 271 480 minecraft:pink_terracotta
setblock 369 268 484 minecraft:red_nether_bricks
fill 369 268 485 369 271 485 minecraft:pink_terracotta
setblock 369 268 495 minecraft:pink_terracotta
setblock 369 268 499 minecraft:red_nether_bricks
fill 369 268 500 369 269 500 minecraft:pink_terracotta
setblock 369 268 504 minecraft:red_nether_bricks
setblock 370 268 474 minecraft:pink_terracotta
setblock 370 268 478 minecraft:red_nether_bricks
fill 370 268 479 370 271 479 minecraft:pink_terracotta
setblock 370 268 483 minecraft:red_nether_bricks
fill 370 268 484 370 271 484 minecraft:pink_terracotta
setblock 370 268 488 minecraft:red_nether_bricks
setblock 370 268 489 minecraft:pink_terracotta
setblock 370 268 493 minecraft:red_nether_bricks
setblock 370 268 494 minecraft:pink_terracotta
setblock 370 268 498 minecraft:red_nether_bricks
fill 370 268 499 370 270 499 minecraft:pink_terracotta
setblock 370 268 503 minecraft:red_nether_bricks
setblock 370 268 504 minecraft:pink_terracotta
setblock 330 269 469 minecraft:white_concrete
fill 330 269 473 330 269 476 minecraft:pink_terracotta
setblock 330 269 477 minecraft:red_nether_bricks
fill 330 269 478 330 272 478 minecraft:pink_terracotta
setblock 330 269 482 minecraft:red_nether_bricks
fill 330 269 483 330 272 483 minecraft:pink_terracotta
setblock 330 269 488 minecraft:white_concrete
setblock 331 269 476 minecraft:red_nether_bricks
setblock 331 269 477 minecraft:pink_terracotta
setblock 331 269 481 minecraft:red_nether_bricks
fill 331 269 482 331 270 482 minecraft:pink_terracotta
fill 336 269 464 337 269 464 minecraft:pink_terracotta
fill 336 269 504 337 269 504 minecraft:pink_terracotta
setblock 338 269 464 minecraft:red_nether_bricks
fill 338 269 465 338 272 465 minecraft:pink_terracotta
setblock 338 269 503 minecraft:pink_terracotta
setblock 338 269 504 minecraft:red_nether_bricks
fill 339 269 464 342 269 464 minecraft:pink_terracotta
setblock 339 269 503 minecraft:red_nether_bricks
fill 339 269 504 339 272 504 minecraft:pink_terracotta
fill 340 269 503 340 272 503 minecraft:pink_terracotta
fill 341 269 502 344 269 502 minecraft:pink_terracotta
setblock 342 269 465 minecraft:red_nether_bricks
setblock 343 269 464 minecraft:red_nether_bricks
fill 343 269 465 343 272 465 minecraft:pink_terracotta
setblock 343 269 504 minecraft:red_nether_bricks
fill 344 269 464 344 272 464 minecraft:pink_terracotta
setblock 344 269 503 minecraft:red_nether_bricks
fill 344 269 504 344 272 504 minecraft:pink_terracotta
setblock 345 269 502 minecraft:red_nether_bricks
fill 345 269 503 345 272 503 minecraft:pink_terracotta
fill 346 269 502 346 271 502 minecraft:pink_terracotta
setblock 347 269 465 minecraft:red_nether_bricks
setblock 348 269 464 minecraft:red_nether_bricks
setblock 348 269 504 minecraft:red_nether_bricks
fill 349 269 464 349 272 464 minecraft:pink_terracotta
setblock 349 269 503 minecraft:red_nether_bricks
fill 349 269 504 352 269 504 minecraft:pink_terracotta
fill 350 269 503 353 269 503 minecraft:pink_terracotta
setblock 353 269 504 minecraft:red_nether_bricks
setblock 354 269 503 minecraft:red_nether_bricks
fill 354 269 504 354 272 504 minecraft:pink_terracotta
fill 355 269 503 358 269 503 minecraft:pink_terracotta
fill 356 269 502 359 269 502 minecraft:pink_terracotta
setblock 358 269 464 minecraft:red_nether_bricks
setblock 358 269 504 minecraft:red_nether_bricks
fill 359 269 464 359 272 464 minecraft:pink_terracotta
setblock 359 269 503 minecraft:red_nether_bricks
fill 359 269 504 359 272 504 minecraft:pink_terracotta
setblock 360 269 501 minecraft:pink_terracotta
setblock 360 269 502 minecraft:red_nether_bricks
fill 360 269 503 360 272 503 minecraft:pink_terracotta
setblock 361 269 501 minecraft:red_nether_bricks
fill 361 269 502 361 272 502 minecraft:pink_terracotta
fill 362 269 501 362 270 501 minecraft:pink_terracotta
setblock 363 269 464 minecraft:red_nether_bricks
setblock 363 269 504 minecraft:red_nether_bricks
fill 364 269 464 364 272 464 minecraft:pink_terracotta
setblock 364 269 503 minecraft:red_nether_bricks
fill 364 269 504 364 272 504 minecraft:pink_terracotta
setblock 365 269 502 minecraft:red_nether_bricks
fill 365 269 503 365 272 503 minecraft:pink_terracotta
setblock 366 269 502 minecraft:pink_terracotta
setblock 368 269 480 minecraft:pink_terracotta
setblock 368 269 504 minecraft:red_nether_bricks
setblock 369 269 478 minecraft:red_nether_bricks
fill 369 269 479 369 271 479 minecraft:pink_terracotta
setblock 369 269 483 minecraft:red_nether_bricks
fill 369 269 484 369 272 484 minecraft:pink_terracotta
setblock 369 269 499 minecraft:pink_terracotta
fill 369 269 504 369 270 504 minecraft:pink_terracotta
setblock 370 269 477 minecraft:red_nether_bricks
fill 370 269 478 370 272 478 minecraft:pink_terracotta
setblock 370 269 482 minecraft:red_nether_bricks
fill 370 269 483 370 272 483 minecraft:pink_terracotta
setblock 370 269 487 minecraft:red_nether_bricks
setblock 370 269 488 minecraft:pink_terracotta
setblock 370 269 497 minecraft:red_nether_bricks
setblock 370 269 498 minecraft:pink_terracotta
setblock 370 269 502 minecraft:red_nether_bricks
setblock 370 269 503 minecraft:pink_terracotta
fill 330 270 474 330 270 475 minecraft:pink_terracotta
setblock 330 270 476 minecraft:red_nether_bricks
fill 330 270 477 330 272 477 minecraft:pink_terracotta
setblock 330 270 481 minecraft:red_nether_bricks
fill 330 270 482 330 273 482 minecraft:pink_terracotta
setblock 330 270 494 minecraft:white_concrete
setblock 331 270 480 minecraft:red_nether_bricks
setblock 331 270 481 minecraft:pink_terracotta
fill 335 270 464 336 270 464 minecraft:pink_terracotta
setblock 336 270 504 minecraft:pink_terracotta
setblock 337 270 464 minecraft:red_nether_bricks
fill 337 270 491 339 270 491 minecraft:white_concrete
fill 337 270 493 337 272 493 minecraft:white_concrete
setblock 337 270 504 minecraft:red_nether_bricks
fill 338 270 464 341 270 464 minecraft:pink_terracotta
setblock 338 270 503 minecraft:red_nether_bricks
fill 338 270 504 338 273 504 minecraft:pink_terracotta
fill 339 270 492 339 271 493 minecraft:white_concrete
fill 339 270 503 339 273 503 minecraft:pink_terracotta
setblock 341 270 465 minecraft:red_nether_bricks
fill 341 270 502 343 270 502 minecraft:pink_terracotta
setblock 342 270 464 minecraft:red_nether_bricks
fill 342 270 465 342 273 465 minecraft:pink_terracotta
setblock 342 270 504 minecraft:red_nether_bricks
fill 343 270 464 343 273 464 minecraft:pink_terracotta
setblock 343 270 503 minecraft:red_nether_bricks
fill 343 270 504 343 273 504 minecraft:pink_terracotta
setblock 344 270 502 minecraft:red_nether_bricks
fill 344 270 503 344 273 503 minecraft:pink_terracotta
fill 345 270 502 345 272 502 minecraft:pink_terracotta
setblock 346 270 465 minecraft:red_nether_bricks
setblock 347 270 464 minecraft:red_nether_bricks
setblock 347 270 465 minecraft:pink_terracotta
setblock 347 270 504 minecraft:red_nether_bricks
fill 348 270 464 348 273 464 minecraft:pink_terracotta
setblock 348 270 503 minecraft:red_nether_bricks
fill 348 270 504 351 270 504 minecraft:pink_terracotta
fill 349 270 503 352 270 503 minecraft:pink_terracotta
setblock 352 270 504 minecraft:red_nether_bricks
setblock 353 270 503 minecraft:red_nether_bricks
fill 353 270 504 353 273 504 minecraft:pink_terracotta
fill 354 270 503 357 270 503 minecraft:pink_terracotta
setblock 355 270 464 minecraft:white_concrete
setblock 357 270 464 minecraft:red_nether_bricks
fill 357 270 502 358 270 502 minecraft:pink_terracotta
setblock 357 270 504 minecraft:red_nether_bricks
fill 358 270 464 358 273 464 minecraft:pink_terracotta
setblock 358 270 503 minecraft:red_nether_bricks
fill 358 270 504 358 273 504 minecraft:pink_terracotta
setblock 359 270 502 minecraft:red_nether_bricks
fill 359 270 503 359 273 503 minecraft:pink_terracotta
fill 360 270 502 360 273 502 minecraft:pink_terracotta
setblock 361 270 501 minecraft:pink_terracotta
setblock 362 270 464 minecraft:red_nether_bricks
setblock 362 270 504 minecraft:red_nether_bricks
fill 363 270 464 363 273 464 minecraft:pink_terracotta
setblock 363 270 503 minecraft:red_nether_bricks
fill 363 270 504 363 273 504 minecraft:pink_terracotta
setblock 364 270 502 minecraft:red_nether_bricks
fill 364 270 503 364 273 503 minecraft:pink_terracotta
setblock 365 270 502 minecraft:pink_terracotta
setblock 367 270 504 minecraft:red_nether_bricks
fill 368 270 504 368 271 504 minecraft:pink_terracotta
setblock 369 270 478 minecraft:pink_terracotta
setblock 369 270 482 minecraft:red_nether_bricks
fill 369 270 483 369 273 483 minecraft:pink_terracotta
setblock 370 270 474 minecraft:white_concrete
setblock 370 270 476 minecraft:red_nether_bricks
fill 370 270 477 370 271 477 minecraft:pink_terracotta
setblock 370 270 481 minecraft:red_nether_bricks
fill 370 270 482 370 273 482 minecraft:pink_terracotta
setblock 370 270 486 minecraft:red_nether_bricks
fill 370 270 487 370 273 487 minecraft:pink_terracotta
setblock 370 270 493 minecraft:white_concrete
setblock 370 270 501 minecraft:red_nether_bricks
setblock 370 270 502 minecraft:pink_terracotta
setblock 330 271 476 minecraft:pink_terracotta
setblock 330 271 480 minecraft:red_nether_bricks
fill 330 271 481 330 273 481 minecraft:pink_terracotta
setblock 330 271 485 minecraft:red_nether_bricks
setblock 330 271 500 minecraft:white_concrete
fill 334 271 464 335 271 464 minecraft:pink_terracotta
setblock 335 271 504 minecraft:pink_terracotta
setblock 336 271 464 minecraft:red_nether_bricks
setblock 336 271 504 minecraft:red_nether_bricks
fill 337 271 464 337 273 465 minecraft:pink_terracotta
fill 337 271 491 338 271 491 minecraft:white_concrete
fill 337 271 504 337 273 504 minecraft:pink_terracotta
fill 338 271 464 340 271 464 minecraft:pink_terracotta
fill 338 271 503 338 273 503 minecraft:pink_terracotta
setblock 340 271 465 minecraft:red_nether_bricks
setblock 341 271 464 minecraft:red_nether_bricks
fill 341 271 465 341 273 465 minecraft:pink_terracotta
fill 341 271 502 342 271 502 minecraft:pink_terracotta
setblock 341 271 504 minecraft:red_nether_bricks
fill 342 271 464 342 273 464 minecraft:pink_terracotta
setblock 342 271 503 minecraft:red_nether_bricks
fill 342 271 504 342 273 504 minecraft:pink_terracotta
setblock 343 271 502 minecraft:red_nether_bricks
fill 343 271 503 343 273 503 minecraft:pink_terracotta
fill 344 271 502 344 273 502 minecraft:pink_terracotta
setblock 345 271 465 minecraft:red_nether_bricks
setblock 346 271 464 minecraft:red_nether_bricks
fill 346 271 465 346 273 465 minecraft:pink_terracotta
setblock 346 271 504 minecraft:red_nether_bricks
fill 347 271 464 347 273 464 minecraft:pink_terracotta
setblock 347 271 503 minecraft:red_nether_bricks
fill 347 271 504 350 271 504 minecraft:pink_terracotta
fill 348 271 503 351 271 503 minecraft:pink_terracotta
setblock 351 271 504 minecraft:red_nether_bricks
setblock 352 271 503 minecraft:red_nether_bricks
fill 352 271 504 352 273 504 minecraft:pink_terracotta
fill 353 271 503 356 271 503 minecraft:pink_terracotta
setblock 356 271 504 minecraft:red_nether_bricks
fill 357 271 464 357 273 464 minecraft:pink_terracotta
setblock 357 271 502 minecraft:pink_terracotta
setblock 357 271 503 minecraft:red_nether_bricks
fill 357 271 504 357 273 504 minecraft:pink_terracotta
setblock 358 271 502 minecraft:red_nether_bricks
fill 358 271 503 358 273 503 minecraft:pink_terracotta
fill 359 271 502 359 273 502 minecraft:pink_terracotta
setblock 361 271 464 minecraft:red_nether_bricks
setblock 361 271 504 minecraft:red_nether_bricks
fill 362 271 464 362 273 464 minecraft:pink_terracotta
setblock 362 271 503 minecraft:red_nether_bricks
fill 362 271 504 362 273 504 minecraft:pink_terracotta
setblock 363 271 502 minecraft:red_nether_bricks
fill 363 271 503 363 273 503 minecraft:pink_terracotta
setblock 364 271 502 minecraft:pink_terracotta
setblock 366 271 504 minecraft:red_nether_bricks
fill 367 271 504 367 273 504 minecraft:pink_terracotta
setblock 369 271 481 minecraft:red_nether_bricks
fill 369 271 482 369 273 482 minecraft:pink_terracotta
setblock 370 271 468 minecraft:white_concrete
setblock 370 271 480 minecraft:red_nether_bricks
fill 370 271 481 370 273 481 minecraft:pink_terracotta
setblock 370 271 485 minecraft:red_nether_bricks
fill 370 271 486 370 273 486 minecraft:pink_terracotta
setblock 370 271 504 minecraft:white_concrete
setblock 330 272 479 minecraft:red_nether_bricks
fill 330 272 480 330 273 480 minecraft:pink_terracotta
setblock 330 272 484 minecraft:red_nether_bricks
fill 330 272 485 330 273 485 minecraft:pink_terracotta
setblock 330 272 487 minecraft:white_concrete
setblock 332 272 504 minecraft:white_concrete
fill 333 272 464 334 272 464 minecraft:pink_terracotta
setblock 335 272 464 minecraft:red_nether_bricks
setblock 335 272 504 minecraft:red_nether_bricks
fill 336 272 464 336 273 465 minecraft:pink_terracotta
fill 336 272 504 336 273 504 minecraft:pink_terracotta
fill 337 272 503 337 273 503 minecraft:pink_terracotta
fill 338 272 464 339 272 464 minecraft:pink_terracotta
setblock 338 272 491 minecraft:white_concrete
setblock 339 272 465 minecraft:red_nether_bricks
setblock 339 272 492 minecraft:white_concrete
setblock 340 272 464 minecraft:red_nether_bricks
fill 340 272 465 340 273 466 minecraft:pink_terracotta
fill 340 272 502 341 272 502 minecraft:pink_terracotta
setblock 340 272 504 minecraft:red_nether_bricks
fill 341 272 464 341 273 464 minecraft:pink_terracotta
fill 341 272 466 342 272 466 minecraft:pink_terracotta
setblock 341 272 503 minecraft:red_nether_bricks
fill 341 272 504 341 273 504 minecraft:pink_terracotta
setblock 342 272 502 minecraft:red_nether_bricks
fill 342 272 503 342 273 503 minecraft:pink_terracotta
fill 343 272 502 343 273 502 minecraft:pink_terracotta
setblock 344 272 465 minecraft:red_nether_bricks
setblock 345 272 464 minecraft:red_nether_bricks
fill 345 272 465 345 273 465 minecraft:pink_terracotta
setblock 345 272 504 minecraft:red_nether_bricks
fill 346 272 464 346 273 464 minecraft:pink_terracotta
setblock 346 272 503 minecraft:red_nether_bricks
fill 346 272 504 349 272 504 minecraft:pink_terracotta
fill 347 272 503 350 272 503 minecraft:pink_terracotta
setblock 350 272 464 minecraft:red_nether_bricks
setblock 350 272 504 minecraft:red_nether_bricks
setblock 351 272 503 minecraft:red_nether_bricks
fill 351 272 504 351 273 504 minecraft:pink_terracotta
fill 352 272 503 355 272 503 minecraft:pink_terracotta
setblock 355 272 464 minecraft:red_nether_bricks
setblock 355 272 504 minecraft:red_nether_bricks
fill 356 272 464 356 273 464 minecraft:pink_terracotta
setblock 356 272 503 minecraft:red_nether_bricks
fill 356 272 504 356 273 504 minecraft:pink_terracotta
setblock 357 272 502 minecraft:red_nether_bricks
fill 357 272 503 357 273 503 minecraft:pink_terracotta
fill 358 272 502 358 273 502 minecraft:pink_terracotta
setblock 360 272 464 minecraft:red_nether_bricks
setblock 360 272 504 minecraft:red_nether_bricks
fill 361 272 464 361 273 464 minecraft:pink_terracotta
setblock 361 272 503 minecraft:red_nether_bricks
fill 361 272 504 361 273 504 minecraft:pink_terracotta
setblock 362 272 502 minecraft:red_nether_bricks
fill 362 272 503 362 273 503 minecraft:pink_terracotta
setblock 363 272 502 minecraft:pink_terracotta
setblock 365 272 504 minecraft:red_nether_bricks
fill 366 272 504 366 273 504 minecraft:pink_terracotta
setblock 368 272 464 minecraft:white_concrete
setblock 369 272 480 minecraft:red_nether_bricks
fill 369 272 481 369 273 481 minecraft:pink_terracotta
setblock 369 272 485 minecraft:red_nether_bricks
setblock 370 272 479 minecraft:red_nether_bricks
fill 370 272 480 370 273 480 minecraft:pink_terracotta
setblock 370 272 484 minecraft:red_nether_bricks
fill 370 272 485 370 273 485 minecraft:pink_terracotta
setblock 330 273 468 minecraft:white_concrete
setblock 330 273 478 minecraft:red_nether_bricks
setblock 330 273 479 minecraft:pink_terracotta
setblock 330 273 483 minecraft:red_nether_bricks
setblock 330 273 484 minecraft:pink_terracotta
setblock 330 273 493 minecraft:white_concrete
fill 332 273 464 333 273 464 minecraft:pink_terracotta
setblock 332 273 466 minecraft:light[level=12]
setblock 332 273 474 minecraft:light[level=12]
setblock 332 273 482 minecraft:light[level=12]
setblock 332 273 490 minecraft:light[level=12]
setblock 332 273 498 minecraft:light[level=12]
setblock 334 273 464 minecraft:red_nether_bricks
setblock 334 273 504 minecraft:red_nether_bricks
fill 335 273 464 335 273 465 minecraft:pink_terracotta
setblock 335 273 504 minecraft:pink_terracotta
setblock 338 273 464 minecraft:pink_terracotta
setblock 338 273 465 minecraft:red_nether_bricks
fill 338 273 466 339 273 466 minecraft:pink_terracotta
setblock 339 273 464 minecraft:red_nether_bricks
setblock 339 273 465 minecraft:pink_terracotta
setblock 339 273 504 minecraft:red_nether_bricks
setblock 340 273 464 minecraft:pink_terracotta
setblock 340 273 474 minecraft:light[level=12]
setblock 340 273 482 minecraft:light[level=12]
setblock 340 273 490 minecraft:light[level=12]
setblock 340 273 498 minecraft:light[level=12]
setblock 340 273 502 minecraft:pink_terracotta
setblock 340 273 503 minecraft:red_nether_bricks
setblock 340 273 504 minecraft:pink_terracotta
setblock 341 273 466 minecraft:pink_terracotta
setblock 341 273 502 minecraft:red_nether_bricks
setblock 341 273 503 minecraft:pink_terracotta
setblock 342 273 466 minecraft:red_nether_bricks
setblock 342 273 502 minecraft:pink_terracotta
setblock 343 273 465 minecraft:red_nether_bricks
setblock 343 273 466 minecraft:pink_terracotta
setblock 344 273 464 minecraft:red_nether_bricks
setblock 344 273 465 minecraft:pink_terracotta
setblock 344 273 504 minecraft:red_nether_bricks
setblock 345 273 464 minecraft:pink_terracotta
setblock 345 273 503 minecraft:red_nether_bricks
fill 345 273 504 348 273 504 minecraft:pink_terracotta
fill 346 273 503 349 273 503 minecraft:pink_terracotta
setblock 348 273 466 minecraft:light[level=12]
setblock 348 273 474 minecraft:light[level=12]
setblock 348 273 482 minecraft:light[level=12]
setblock 348 273 490 minecraft:light[level=12]
setblock 348 273 498 minecraft:light[level=12]
setblock 349 273 464 minecraft:red_nether_bricks
setblock 349 273 504 minecraft:red_nether_bricks
fill 350 273 464 353 273 464 minecraft:pink_terracotta
setblock 350 273 503 minecraft:red_nether_bricks
setblock 350 273 504 minecraft:pink_terracotta
fill 351 273 503 354 273 503 minecraft:pink_terracotta
setblock 354 273 464 minecraft:red_nether_bricks
setblock 354 273 504 minecraft:red_nether_bricks
setblock 355 273 464 minecraft:pink_terracotta
setblock 355 273 503 minecraft:red_nether_bricks
setblock 355 273 504 minecraft:pink_terracotta
setblock 356 273 466 minecraft:light[level=12]
setblock 356 273 474 minecraft:light[level=12]
setblock 356 273 482 minecraft:light[level=12]
setblock 356 273 490 minecraft:light[level=12]
setblock 356 273 498 minecraft:light[level=12]
setblock 356 273 503 minecraft:pink_terracotta
setblock 357 273 502 minecraft:pink_terracotta
setblock 359 273 464 minecraft:red_nether_bricks
setblock 359 273 504 minecraft:red_nether_bricks
setblock 360 273 464 minecraft:pink_terracotta
setblock 360 273 503 minecraft:red_nether_bricks
setblock 360 273 504 minecraft:pink_terracotta
setblock 361 273 502 minecraft:red_nether_bricks
setblock 361 273 503 minecraft:pink_terracotta
setblock 362 273 502 minecraft:pink_terracotta
setblock 364 273 464 minecraft:red_nether_bricks
setblock 364 273 466 minecraft:light[level=12]
setblock 364 273 474 minecraft:light[level=12]
setblock 364 273 482 minecraft:light[level=12]
setblock 364 273 490 minecraft:light[level=12]
setblock 364 273 498 minecraft:light[level=12]
setblock 364 273 504 minecraft:red_nether_bricks
setblock 365 273 464 minecraft:pink_terracotta
setblock 365 273 503 minecraft:red_nether_bricks
setblock 365 273 504 minecraft:pink_terracotta
setblock 369 273 484 minecraft:red_nether_bricks
setblock 369 273 485 minecraft:pink_terracotta
setblock 370 273 475 minecraft:white_concrete
setblock 370 273 478 minecraft:red_nether_bricks
setblock 370 273 479 minecraft:pink_terracotta
setblock 370 273 483 minecraft:red_nether_bricks
setblock 370 273 484 minecraft:pink_terracotta
setblock 370 273 488 minecraft:red_nether_bricks
setblock 370 273 500 minecraft:white_concrete
fill 330 279 464 330 280 475 minecraft:pink_terracotta
fill 330 279 476 330 280 476 minecraft:red_terracotta
fill 330 279 477 330 280 490 minecraft:pink_terracotta
fill 330 279 491 330 280 492 minecraft:red_terracotta
fill 330 279 493 331 280 504 minecraft:pink_terracotta
fill 331 279 464 331 280 473 minecraft:pink_terracotta
fill 331 279 474 331 280 475 minecraft:red_terracotta
fill 331 279 476 331 280 489 minecraft:pink_terracotta
fill 331 279 490 331 280 490 minecraft:red_terracotta
fill 331 279 491 339 280 492 minecraft:pink_terracotta
fill 332 279 464 332 280 472 minecraft:pink_terracotta
fill 332 279 473 332 280 473 minecraft:red_terracotta
fill 332 279 474 332 280 487 minecraft:pink_terracotta
fill 332 279 488 332 280 489 minecraft:red_terracotta
fill 332 279 490 341 280 490 minecraft:pink_terracotta
fill 332 279 493 332 280 503 minecraft:pink_terracotta
fill 332 279 504 332 280 504 minecraft:red_terracotta
fill 333 279 464 333 280 470 minecraft:pink_terracotta
fill 333 279 471 333 280 472 minecraft:red_terracotta
fill 333 279 473 333 280 486 minecraft:pink_terracotta
fill 333 279 487 333 280 487 minecraft:red_terracotta
fill 333 279 488 341 280 489 minecraft:pink_terracotta
fill 333 279 493 333 280 502 minecraft:pink_terracotta
fill 333 279 503 333 280 503 minecraft:red_terracotta
fill 333 279 504 342 280 504 minecraft:pink_terracotta
fill 334 279 464 334 280 469 minecraft:pink_terracotta
fill 334 279 470 334 280 470 minecraft:red_terracotta
fill 334 279 471 334 280 484 minecraft:pink_terracotta
fill 334 279 485 334 280 486 minecraft:red_terracotta
fill 334 279 487 343 280 487 minecraft:pink_terracotta
fill 334 279 493 334 280 500 minecraft:pink_terracotta
fill 334 279 501 334 280 502 minecraft:red_terracotta
fill 334 279 503 342 280 503 minecraft:pink_terracotta
fill 335 279 464 335 280 467 minecraft:pink_terracotta
fill 335 279 468 335 280 469 minecraft:red_terracotta
fill 335 279 470 335 280 483 minecraft:pink_terracotta
fill 335 279 484 335 280 484 minecraft:red_terracotta
fill 335 279 485 343 280 486 minecraft:pink_terracotta
fill 335 279 493 335 280 499 minecraft:pink_terracotta
fill 335 279 500 335 280 500 minecraft:red_terracotta
fill 335 279 501 343 280 502 minecraft:pink_terracotta
fill 336 279 464 336 280 466 minecraft:pink_terracotta
fill 336 279 467 336 280 467 minecraft:red_terracotta
fill 336 279 468 336 280 481 minecraft:pink_terracotta
fill 336 279 482 336 280 483 minecraft:red_terracotta
fill 336 279 484 345 279 484 minecraft:pink_terracotta
fill 336 279 493 336 280 497 minecraft:pink_terracotta
fill 336 279 498 336 280 499 minecraft:red_terracotta
fill 336 279 500 344 280 500 minecraft:pink_terracotta
fill 337 279 464 337 280 464 minecraft:pink_terracotta
fill 337 279 465 337 280 466 minecraft:red_terracotta
fill 337 279 467 337 280 480 minecraft:pink_terracotta
fill 337 279 481 337 280 481 minecraft:red_terracotta
fill 337 279 482 345 279 483 minecraft:pink_terracotta
fill 337 279 493 337 280 496 minecraft:pink_terracotta
fill 337 279 497 337 280 497 minecraft:red_terracotta
fill 337 279 498 345 280 499 minecraft:pink_terracotta
fill 338 279 464 338 280 464 minecraft:red_terracotta
fill 338 279 465 338 280 478 minecraft:pink_terracotta
fill 338 279 479 338 280 480 minecraft:red_terracotta
fill 338 279 481 347 280 481 minecraft:pink_terracotta
fill 338 279 493 338 280 494 minecraft:pink_terracotta
fill 338 279 495 338 280 496 minecraft:red_terracotta
fill 338 279 497 346 280 497 minecraft:pink_terracotta
fill 339 279 464 339 280 477 minecraft:pink_terracotta
fill 339 279 478 339 280 478 minecraft:red_terracotta
fill 339 279 479 347 280 480 minecraft:pink_terracotta
fill 339 279 493 339 280 493 minecraft:pink_terracotta
fill 339 279 494 339 280 494 minecraft:red_terracotta
fill 339 279 495 347 280 496 minecraft:pink_terracotta
fill 340 279 464 340 280 475 minecraft:pink_terracotta
fill 340 279 476 340 280 477 minecraft:red_terracotta
fill 340 279 478 349 280 478 minecraft:pink_terracotta
fill 340 279 491 340 280 491 minecraft:pink_terracotta
fill 340 279 492 340 280 493 minecraft:red_terracotta
fill 340 279 494 348 280 494 minecraft:pink_terracotta
fill 341 279 464 341 280 474 minecraft:pink_terracotta
fill 341 279 475 341 280 475 minecraft:red_terracotta
fill 341 279 476 349 280 477 minecraft:pink_terracotta
fill 341 279 491 341 280 491 minecraft:red_terracotta
fill 341 279 492 349 280 493 minecraft:pink_terracotta
fill 342 279 464 342 280 472 minecraft:pink_terracotta
fill 342 279 473 342 280 474 minecraft:red_terracotta
fill 342 279 475 351 280 475 minecraft:pink_terracotta
fill 342 279 488 342 280 488 minecraft:pink_terracotta
fill 342 279 489 342 280 490 minecraft:red_terracotta
fill 342 279 491 350 280 491 minecraft:pink_terracotta
fill 343 279 464 343 280 471 minecraft:pink_terracotta
fill 343 279 472 343 280 472 minecraft:red_terracotta
fill 343 279 473 351 280 474 minecraft:pink_terracotta
fill 343 279 488 343 280 488 minecraft:red_terracotta
fill 343 279 489 351 280 490 minecraft:pink_terracotta
fill 343 279 503 343 280 504 minecraft:red_terracotta
fill 344 279 464 344 280 469 minecraft:pink_terracotta
fill 344 279 470 344 280 471 minecraft:red_terracotta
fill 344 279 472 353 280 472 minecraft:pink_terracotta
setblock 344 279 485 minecraft:pink_terracotta
fill 344 279 486 344 279 487 minecraft:red_terracotta
fill 344 279 488 352 279 488 minecraft:pink_terracotta
fill 344 279 501 344 280 501 minecraft:pink_terracotta
fill 344 279 502 344 280 502 minecraft:red_terracotta
fill 344 279 503 352 280 504 minecraft:pink_terracotta
fill 345 279 464 345 280 468 minecraft:pink_terracotta
fill 345 279 469 345 280 469 minecraft:red_terracotta
fill 345 279 470 353 280 471 minecraft:pink_terracotta
fill 345 279 486 345 279 487 minecraft:pink_terracotta
fill 345 279 500 345 280 501 minecraft:red_terracotta
fill 345 279 502 354 280 502 minecraft:pink_terracotta
fill 346 279 464 346 280 466 minecraft:pink_terracotta
fill 346 279 467 346 280 468 minecraft:red_terracotta
fill 346 279 469 355 280 469 minecraft:pink_terracotta
setblock 346 279 482 minecraft:pink_terracotta
setblock 346 279 483 minecraft:red_terracotta
setblock 346 279 487 minecraft:pink_terracotta
fill 346 279 498 346 280 498 minecraft:pink_terracotta
fill 346 279 499 346 280 499 minecraft:red_terracotta
fill 346 279 500 354 280 501 minecraft:pink_terracotta
fill 347 279 464 347 280 465 minecraft:pink_terracotta
fill 347 279 466 347 280 466 minecraft:red_terracotta
fill 347 279 467 355 280 468 minecraft:pink_terracotta
setblock 347 279 482 minecraft:red_terracotta
fill 347 279 497 347 280 498 minecraft:red_terracotta
fill 347 279 499 356 280 499 minecraft:pink_terracotta
fill 348 279 464 348 280 465 minecraft:red_terracotta
fill 348 279 466 357 280 466 minecraft:pink_terracotta
fill 348 279 479 348 280 479 minecraft:pink_terracotta
fill 348 279 480 348 280 481 minecraft:red_terracotta
fill 348 279 482 356 279 483 minecraft:pink_terracotta
fill 348 279 487 353 279 487 minecraft:pink_terracotta
fill 348 279 495 348 280 495 minecraft:pink_terracotta
fill 348 279 496 348 280 496 minecraft:red_terracotta
fill 348 279 497 356 280 498 minecraft:pink_terracotta
fill 349 279 464 357 280 465 minecraft:pink_terracotta
fill 349 279 479 349 280 479 minecraft:red_terracotta
fill 349 279 480 357 280 481 minecraft:pink_terracotta
fill 349 279 484 355 279 484 minecraft:pink_terracotta
fill 349 279 486 354 279 486 minecraft:pink_terracotta
fill 349 279 494 349 280 495 minecraft:red_terracotta
fill 349 279 496 358 280 496 minecraft:pink_terracotta
fill 350 279 476 350 280 476 minecraft:pink_terracotta
fill 350 279 477 350 280 478 minecraft:red_terracotta
fill 350 279 479 358 280 479 minecraft:pink_terracotta
fill 350 279 485 354 279 485 minecraft:pink_terracotta
fill 350 279 492 350 280 492 minecraft:pink_terracotta
fill 350 279 493 350 280 493 minecraft:red_terracotta
fill 350 279 494 358 280 495 minecraft:pink_terracotta
fill 351 279 476 351 280 476 minecraft:red_terracotta
fill 351 279 477 359 280 478 minecraft:pink_terracotta
fill 351 279 491 351 280 492 minecraft:red_terracotta
fill 351 279 493 360 280 493 minecraft:pink_terracotta
fill 352 279 473 352 280 473 minecraft:pink_terracotta
fill 352 279 474 352 280 475 minecraft:red_terracotta
fill 352 279 476 360 280 476 minecraft:pink_terracotta
fill 352 279 489 352 280 489 minecraft:pink_terracotta
fill 352 279 490 352 280 490 minecraft:red_terracotta
fill 352 279 491 360 280 492 minecraft:pink_terracotta
fill 353 279 473 353 280 473 minecraft:red_terracotta
fill 353 279 474 361 280 475 minecraft:pink_terracotta
fill 353 279 488 353 280 489 minecraft:red_terracotta
fill 353 279 490 362 280 490 minecraft:pink_terracotta
fill 353 279 503 353 280 503 minecraft:pink_terracotta
fill 353 279 504 353 280 504 minecraft:red_terracotta
fill 354 279 470 354 280 470 minecraft:pink_terracotta
fill 354 279 471 354 280 472 minecraft:red_terracotta
fill 354 279 473 362 280 473 minecraft:pink_terracotta
fill 354 279 487 354 280 487 minecraft:red_terracotta
fill 354 279 488 362 280 489 minecraft:pink_terracotta
fill 354 279 503 354 280 503 minecraft:red_terracotta
fill 354 279 504 363 280 504 minecraft:pink_terracotta
fill 355 279 470 355 280 470 minecraft:red_terracotta
fill 355 279 471 363 280 472 minecraft:pink_terracotta
fill 355 279 485 355 280 486 minecraft:red_terracotta
fill 355 279 487 364 280 487 minecraft:pink_terracotta
fill 355 279 500 355 280 500 minecraft:pink_terracotta
fill 355 279 501 355 280 502 minecraft:red_terracotta
fill 355 279 503 363 280 503 minecraft:pink_terracotta
fill 356 279 467 356 280 467 minecraft:pink_terracotta
fill 356 279 468 356 280 469 minecraft:red_terracotta
fill 356 279 470 364 280 470 minecraft:pink_terracotta
fill 356 279 484 356 280 484 minecraft:red_terracotta
fill 356 279 485 364 280 486 minecraft:pink_terracotta
fill 356 279 500 356 280 500 minecraft:red_terracotta
fill 356 279 501 364 280 502 minecraft:pink_terracotta
fill 357 279 467 357 280 467 minecraft:red_terracotta
fill 357 279 468 365 280 469 minecraft:pink_terracotta
fill 357 279 482 357 280 483 minecraft:red_terracotta
fill 357 279 484 366 280 484 minecraft:pink_terracotta
fill 357 279 497 357 280 497 minecraft:pink_terracotta
fill 357 279 498 357 280 499 minecraft:red_terracotta
fill 357 279 500 365 280 500 minecraft:pink_terracotta
fill 358 279 464 358 280 464 minecraft:pink_terracotta
fill 358 279 465 358 280 466 minecraft:red_terracotta
fill 358 279 467 366 280 467 minecraft:pink_terracotta
fill 358 279 480 358 280 480 minecraft:pink_terracotta
fill 358 279 481 358 280 481 minecraft:red_terracotta
fill 358 279 482 366 280 483 minecraft:pink_terracotta
fill 358 279 497 358 280 497 minecraft:red_terracotta
fill 358 279 498 366 280 499 minecraft:pink_terracotta
fill 359 279 464 359 280 464 minecraft:red_terracotta
fill 359 279 465 367 280 466 minecraft:pink_terracotta
fill 359 279 479 359 280 480 minecraft:red_terracotta
fill 359 279 481 368 280 481 minecraft:pink_terracotta
fill 359 279 494 359 280 494 minecraft:pink_terracotta
fill 359 279 495 359 280 496 minecraft:red_terracotta
fill 359 279 497 367 280 497 minecraft:pink_terracotta
fill 360 279 464 368 280 464 minecraft:pink_terracotta
fill 360 279 477 360 280 477 minecraft:pink_terracotta
fill 360 279 478 360 280 478 minecraft:red_terracotta
fill 360 279 479 368 280 480 minecraft:pink_terracotta
fill 360 279 494 360 280 494 minecraft:red_terracotta
fill 360 279 495 368 280 496 minecraft:pink_terracotta
fill 361 279 476 361 280 477 minecraft:red_terracotta
fill 361 279 478 370 280 478 minecraft:pink_terracotta
fill 361 279 491 361 280 491 minecraft:pink_terracotta
fill 361 279 492 361 280 493 minecraft:red_terracotta
fill 361 279 494 369 280 494 minecraft:pink_terracotta
fill 362 279 474 362 280 474 minecraft:pink_terracotta
fill 362 279 475 362 280 475 minecraft:red_terracotta
fill 362 279 476 370 280 477 minecraft:pink_terracotta
fill 362 279 491 362 280 491 minecraft:red_terracotta
fill 362 279 492 370 280 493 minecraft:pink_terracotta
fill 363 279 473 363 280 474 minecraft:red_terracotta
fill 363 279 475 370 280 475 minecraft:pink_terracotta
fill 363 279 488 363 280 488 minecraft:pink_terracotta
fill 363 279 489 363 280 490 minecraft:red_terracotta
fill 363 279 491 370 280 491 minecraft:pink_terracotta
fill 364 279 471 364 280 471 minecraft:pink_terracotta
fill 364 279 472 364 280 472 minecraft:red_terracotta
fill 364 279 473 370 280 474 minecraft:pink_terracotta
fill 364 279 488 364 280 488 minecraft:red_terracotta
fill 364 279 489 370 280 490 minecraft:pink_terracotta
fill 364 279 503 364 280 504 minecraft:red_terracotta
fill 365 279 470 365 280 471 minecraft:red_terracotta
fill 365 279 472 370 280 472 minecraft:pink_terracotta
fill 365 279 485 365 280 485 minecraft:pink_terracotta
fill 365 279 486 365 280 487 minecraft:red_terracotta
fill 365 279 488 370 280 488 minecraft:pink_terracotta
fill 365 279 501 365 280 501 minecraft:pink_terracotta
fill 365 279 502 365 280 502 minecraft:red_terracotta
fill 365 279 503 370 280 504 minecraft:pink_terracotta
fill 366 279 468 366 280 468 minecraft:pink_terracotta
fill 366 279 469 366 280 469 minecraft:red_terracotta
fill 366 279 470 370 280 471 minecraft:pink_terracotta
fill 366 279 485 366 280 485 minecraft:red_terracotta
fill 366 279 486 370 280 487 minecraft:pink_terracotta
fill 366 279 500 366 280 501 minecraft:red_terracotta
fill 366 279 502 370 280 502 minecraft:pink_terracotta
fill 367 279 467 367 280 468 minecraft:red_terracotta
fill 367 279 469 370 280 469 minecraft:pink_terracotta
fill 367 279 482 367 280 482 minecraft:pink_terracotta
fill 367 279 483 367 280 484 minecraft:red_terracotta
fill 367 279 485 370 280 485 minecraft:pink_terracotta
fill 367 279 498 367 280 498 minecraft:pink_terracotta
fill 367 279 499 367 280 499 minecraft:red_terracotta
fill 367 279 500 370 280 501 minecraft:pink_terracotta
fill 368 279 465 368 280 465 minecraft:pink_terracotta
fill 368 279 466 368 280 466 minecraft:red_terracotta
fill 368 279 467 370 280 468 minecraft:pink_terracotta
fill 368 279 482 368 280 482 minecraft:red_terracotta
fill 368 279 483 370 280 484 minecraft:pink_terracotta
fill 368 279 497 368 280 498 minecraft:red_terracotta
fill 368 279 499 370 280 499 minecraft:pink_terracotta
fill 369 279 464 369 280 465 minecraft:red_terracotta
fill 369 279 466 370 280 466 minecraft:pink_terracotta
fill 369 279 479 369 280 479 minecraft:pink_terracotta
fill 369 279 480 369 280 481 minecraft:red_terracotta
fill 369 279 482 370 280 482 minecraft:pink_terracotta
fill 369 279 495 369 280 495 minecraft:pink_terracotta
fill 369 279 496 369 280 496 minecraft:red_terracotta
fill 369 279 497 370 280 498 minecraft:pink_terracotta
fill 370 279 464 370 280 465 minecraft:pink_terracotta
fill 370 279 479 370 280 479 minecraft:red_terracotta
fill 370 279 480 370 280 481 minecraft:pink_terracotta
fill 370 279 494 370 280 495 minecraft:red_terracotta
fill 370 279 496 370 280 496 minecraft:pink_terracotta
fill 336 280 484 343 280 484 minecraft:pink_terracotta
fill 337 280 482 344 280 483 minecraft:pink_terracotta
fill 344 280 484 344 280 486 minecraft:shroomlight
setblock 344 280 487 minecraft:red_terracotta
fill 344 280 488 345 280 488 minecraft:pink_terracotta
setblock 345 280 482 minecraft:pink_terracotta
fill 345 280 483 345 280 484 minecraft:shroomlight
fill 345 280 486 345 280 487 minecraft:shroomlight
fill 346 280 482 346 280 483 minecraft:shroomlight
fill 346 280 487 346 280 488 minecraft:shroomlight
fill 347 280 482 348 280 482 minecraft:shroomlight
fill 347 280 488 348 280 488 minecraft:shroomlight
fill 348 280 483 349 280 483 minecraft:shroomlight
fill 348 280 487 349 280 487 minecraft:shroomlight
fill 349 280 482 356 280 482 minecraft:pink_terracotta
fill 349 280 484 350 280 484 minecraft:shroomlight
fill 349 280 486 350 280 486 minecraft:shroomlight
fill 349 280 488 352 280 488 minecraft:pink_terracotta
fill 350 280 483 356 280 483 minecraft:pink_terracotta
setblock 350 280 485 minecraft:shroomlight
fill 350 280 487 353 280 487 minecraft:pink_terracotta
fill 351 280 484 354 280 486 minecraft:pink_terracotta
setblock 355 280 484 minecraft:pink_terracotta
setblock 332 281 466 minecraft:light[level=12]
setblock 332 281 474 minecraft:light[level=12]
setblock 332 281 482 minecraft:light[level=12]
setblock 332 281 490 minecraft:light[level=12]
setblock 332 281 498 minecraft:light[level=12]
setblock 340 281 466 minecraft:light[level=12]
setblock 340 281 474 minecraft:light[level=12]
setblock 340 281 482 minecraft:light[level=12]
setblock 340 281 490 minecraft:light[level=12]
setblock 340 281 498 minecraft:light[level=12]
setblock 348 281 466 minecraft:light[level=12]
setblock 348 281 474 minecraft:light[level=12]
setblock 348 281 482 minecraft:light[level=12]
setblock 348 281 490 minecraft:light[level=12]
setblock 348 281 498 minecraft:light[level=12]
setblock 356 281 466 minecraft:light[level=12]
setblock 356 281 474 minecraft:light[level=12]
setblock 356 281 482 minecraft:light[level=12]
setblock 356 281 490 minecraft:light[level=12]
setblock 356 281 498 minecraft:light[level=12]
setblock 364 281 466 minecraft:light[level=12]
setblock 364 281 474 minecraft:light[level=12]
setblock 364 281 482 minecraft:light[level=12]
setblock 364 281 490 minecraft:light[level=12]
setblock 364 281 498 minecraft:light[level=12]
fill 330 284 464 330 284 466 minecraft:pink_terracotta
setblock 330 284 467 minecraft:red_nether_bricks
fill 330 284 468 330 284 471 minecraft:pink_terracotta
setblock 330 284 472 minecraft:red_nether_bricks
fill 330 284 473 330 284 476 minecraft:pink_terracotta
setblock 330 284 477 minecraft:red_nether_bricks
setblock 330 284 486 minecraft:pink_terracotta
setblock 330 284 487 minecraft:red_nether_bricks
fill 330 284 488 330 284 491 minecraft:pink_terracotta
setblock 330 284 492 minecraft:red_nether_bricks
fill 330 284 493 330 286 494 minecraft:pink_terracotta
setblock 330 284 496 minecraft:white_concrete
fill 331 284 464 331 284 465 minecraft:pink_terracotta
setblock 331 284 466 minecraft:red_nether_bricks
fill 331 284 467 331 284 470 minecraft:pink_terracotta
setblock 331 284 471 minecraft:red_nether_bricks
fill 331 284 472 331 284 475 minecraft:pink_terracotta
fill 331 284 504 332 284 504 minecraft:pink_terracotta
setblock 332 284 464 minecraft:pink_terracotta
setblock 332 284 465 minecraft:red_nether_bricks
fill 332 284 466 332 284 469 minecraft:pink_terracotta
setblock 332 284 470 minecraft:red_nether_bricks
fill 332 284 471 332 285 473 minecraft:pink_terracotta
setblock 333 284 464 minecraft:red_nether_bricks
fill 333 284 465 333 284 468 minecraft:pink_terracotta
setblock 333 284 469 minecraft:red_nether_bricks
fill 333 284 470 333 284 471 minecraft:pink_terracotta
setblock 333 284 504 minecraft:red_nether_bricks
fill 334 284 464 334 284 467 minecraft:pink_terracotta
fill 334 284 504 337 284 504 minecraft:pink_terracotta
fill 335 284 464 335 284 466 minecraft:pink_terracotta
setblock 335 284 467 minecraft:red_nether_bricks
fill 335 284 503 336 284 503 minecraft:pink_terracotta
fill 336 284 464 336 284 465 minecraft:pink_terracotta
setblock 336 284 466 minecraft:red_nether_bricks
setblock 336 284 467 minecraft:pink_terracotta
setblock 337 284 464 minecraft:pink_terracotta
setblock 337 284 465 minecraft:red_nether_bricks
fill 337 284 466 338 284 466 minecraft:pink_terracotta
setblock 338 284 464 minecraft:red_nether_bricks
fill 338 284 465 340 284 465 minecraft:pink_terracotta
setblock 338 284 504 minecraft:red_nether_bricks
fill 339 284 464 342 284 464 minecraft:pink_terracotta
fill 339 284 504 341 284 504 minecraft:pink_terracotta
fill 349 284 504 352 284 504 minecraft:pink_terracotta
fill 350 284 464 352 284 464 minecraft:pink_terracotta
setblock 353 284 464 minecraft:red_nether_bricks
setblock 353 284 504 minecraft:red_nether_bricks
fill 354 284 464 357 284 464 minecraft:pink_terracotta
fill 354 284 504 357 284 504 minecraft:pink_terracotta
setblock 358 284 464 minecraft:red_nether_bricks
setblock 359 284 464 minecraft:white_concrete
setblock 366 284 504 minecraft:white_concrete
fill 369 284 464 370 284 464 minecraft:pink_terracotta
setblock 369 284 467 minecraft:pink_terracotta
setblock 369 284 468 minecraft:red_nether_bricks
fill 369 284 469 369 284 472 minecraft:pink_terracotta
setblock 369 284 473 minecraft:red_nether_bricks
fill 369 284 474 370 286 474 minecraft:pink_terracotta
setblock 369 284 488 minecraft:red_nether_bricks
fill 369 284 489 370 284 490 minecraft:pink_terracotta
fill 370 284 465 370 284 466 minecraft:pink_terracotta
setblock 370 284 467 minecraft:red_nether_bricks
fill 370 284 468 370 284 471 minecraft:pink_terracotta
setblock 370 284 472 minecraft:red_nether_bricks
fill 370 284 473 370 287 473 minecraft:pink_terracotta
fill 370 284 475 370 284 476 minecraft:pink_terracotta
setblock 370 284 477 minecraft:red_nether_bricks
fill 370 284 478 370 284 481 minecraft:pink_terracotta
setblock 370 284 482 minecraft:red_nether_bricks
fill 370 284 483 370 284 486 minecraft:pink_terracotta
setblock 370 284 487 minecraft:red_nether_bricks
fill 370 284 488 370 287 488 minecraft:pink_terracotta
setblock 370 284 491 minecraft:pink_terracotta
setblock 370 284 492 minecraft:red_nether_bricks
fill 370 284 493 370 286 494 minecraft:pink_terracotta
setblock 370 284 497 minecraft:white_concrete
fill 330 285 464 330 285 465 minecraft:pink_terracotta
setblock 330 285 466 minecraft:red_nether_bricks
fill 330 285 467 330 285 470 minecraft:pink_terracotta
setblock 330 285 471 minecraft:red_nether_bricks
fill 330 285 472 330 285 475 minecraft:pink_terracotta
setblock 330 285 476 minecraft:red_nether_bricks
fill 330 285 477 330 288 477 minecraft:pink_terracotta
fill 330 285 488 330 285 490 minecraft:pink_terracotta
setblock 330 285 491 minecraft:red_nether_bricks
fill 330 285 492 330 288 492 minecraft:pink_terracotta
setblock 330 285 495 minecraft:pink_terracotta
setblock 330 285 502 minecraft:white_concrete
setblock 331 285 464 minecraft:pink_terracotta
setblock 331 285 465 minecraft:red_nether_bricks
fill 331 285 466 331 285 469 minecraft:pink_terracotta
setblock 331 285 470 minecraft:red_nether_bricks
fill 331 285 471 331 285 474 minecraft:pink_terracotta
setblock 331 285 475 minecraft:red_nether_bricks
setblock 331 285 504 minecraft:pink_terracotta
setblock 332 285 464 minecraft:red_nether_bricks
fill 332 285 465 332 285 468 minecraft:pink_terracotta
setblock 332 285 469 minecraft:red_nether_bricks
fill 332 285 470 333 285 470 minecraft:pink_terracotta
setblock 332 285 504 minecraft:red_nether_bricks
fill 333 285 464 333 285 467 minecraft:pink_terracotta
setblock 333 285 468 minecraft:red_nether_bricks
setblock 333 285 469 minecraft:pink_terracotta
fill 333 285 504 336 285 504 minecraft:pink_terracotta
fill 334 285 464 334 285 466 minecraft:pink_terracotta
setblock 334 285 467 minecraft:red_nether_bricks
fill 335 285 464 335 285 465 minecraft:pink_terracotta
setblock 335 285 466 minecraft:red_nether_bricks
setblock 336 285 464 minecraft:pink_terracotta
setblock 336 285 465 minecraft:red_nether_bricks
fill 336 285 466 337 285 466 minecraft:pink_terracotta
setblock 337 285 464 minecraft:red_nether_bricks
fill 337 285 465 339 285 465 minecraft:pink_terracotta
setblock 337 285 504 minecraft:red_nether_bricks
fill 338 285 464 341 285 464 minecraft:pink_terracotta
fill 338 285 504 340 285 504 minecraft:pink_terracotta
setblock 347 285 464 minecraft:white_concrete
setblock 347 285 504 minecraft:white_concrete
setblock 351 285 504 minecraft:pink_terracotta
setblock 352 285 464 minecraft:red_nether_bricks
setblock 352 285 504 minecraft:red_nether_bricks
fill 353 285 464 355 285 464 minecraft:pink_terracotta
fill 353 285 504 355 285 504 minecraft:pink_terracotta
fill 356 285 479 357 300 480 minecraft:red_nether_bricks
setblock 369 285 467 minecraft:red_nether_bricks
fill 369 285 468 369 285 471 minecraft:pink_terracotta
setblock 369 285 472 minecraft:red_nether_bricks
fill 369 285 473 369 288 473 minecraft:pink_terracotta
fill 369 285 475 370 285 475 minecraft:pink_terracotta
fill 370 285 464 370 285 465 minecraft:pink_terracotta
setblock 370 285 466 minecraft:red_nether_bricks
fill 370 285 467 370 285 470 minecraft:pink_terracotta
setblock 370 285 471 minecraft:red_nether_bricks
fill 370 285 472 370 288 472 minecraft:pink_terracotta
setblock 370 285 476 minecraft:red_nether_bricks
fill 370 285 477 370 285 480 minecraft:pink_terracotta
setblock 370 285 481 minecraft:red_nether_bricks
fill 370 285 482 370 285 485 minecraft:pink_terracotta
setblock 370 285 486 minecraft:red_nether_bricks
fill 370 285 487 370 288 487 minecraft:pink_terracotta
fill 370 285 489 370 285 490 minecraft:pink_terracotta
setblock 370 285 491 minecraft:red_nether_bricks
fill 370 285 492 370 288 492 minecraft:pink_terracotta
setblock 370 285 495 minecraft:pink_terracotta
setblock 330 286 464 minecraft:pink_terracotta
setblock 330 286 465 minecraft:red_nether_bricks
fill 330 286 466 330 286 469 minecraft:pink_terracotta
setblock 330 286 470 minecraft:red_nether_bricks
fill 330 286 471 330 286 474 minecraft:pink_terracotta
setblock 330 286 475 minecraft:red_nether_bricks
fill 330 286 476 331 288 476 minecraft:pink_terracotta
fill 330 286 478 330 287 478 minecraft:pink_terracotta
setblock 330 286 483 minecraft:white_concrete
setblock 330 286 489 minecraft:pink_terracotta
setblock 330 286 490 minecraft:red_nether_bricks
fill 330 286 491 330 289 491 minecraft:pink_terracotta
setblock 330 286 495 minecraft:red_nether_bricks
fill 330 286 496 330 288 497 minecraft:pink_terracotta
setblock 331 286 464 minecraft:red_nether_bricks
fill 331 286 465 331 286 468 minecraft:pink_terracotta
setblock 331 286 469 minecraft:red_nether_bricks
fill 331 286 470 331 286 473 minecraft:pink_terracotta
setblock 331 286 474 minecraft:red_nether_bricks
fill 331 286 475 331 289 475 minecraft:pink_terracotta
setblock 331 286 504 minecraft:red_nether_bricks
fill 332 286 464 332 286 467 minecraft:pink_terracotta
setblock 332 286 468 minecraft:red_nether_bricks
fill 332 286 469 332 286 472 minecraft:pink_terracotta
setblock 332 286 473 minecraft:red_nether_bricks
fill 332 286 504 335 286 504 minecraft:pink_terracotta
fill 333 286 464 333 286 466 minecraft:pink_terracotta
fill 334 286 464 334 286 465 minecraft:pink_terracotta
setblock 334 286 466 minecraft:red_nether_bricks
setblock 335 286 464 minecraft:pink_terracotta
setblock 335 286 465 minecraft:red_nether_bricks
setblock 335 286 466 minecraft:pink_terracotta
setblock 336 286 464 minecraft:red_nether_bricks
fill 336 286 465 337 286 465 minecraft:pink_terracotta
setblock 336 286 504 minecraft:red_nether_bricks
fill 337 286 464 339 286 464 minecraft:pink_terracotta
fill 337 286 504 338 287 504 minecraft:pink_terracotta
setblock 341 286 464 minecraft:white_concrete
setblock 351 286 504 minecraft:red_nether_bricks
fill 352 286 504 353 286 504 minecraft:pink_terracotta
fill 355 286 479 355 287 480 minecraft:red_terracotta
fill 356 286 478 357 287 478 minecraft:red_terracotta
fill 356 286 481 357 287 481 minecraft:red_terracotta
fill 358 286 479 358 287 480 minecraft:red_terracotta
setblock 359 286 504 minecraft:white_concrete
setblock 366 286 464 minecraft:white_concrete
fill 369 286 467 369 286 470 minecraft:pink_terracotta
setblock 369 286 471 minecraft:red_nether_bricks
fill 369 286 472 369 289 472 minecraft:pink_terracotta
setblock 369 286 475 minecraft:pink_terracotta
setblock 369 286 476 minecraft:red_nether_bricks
setblock 370 286 464 minecraft:pink_terracotta
setblock 370 286 465 minecraft:red_nether_bricks
fill 370 286 466 370 286 469 minecraft:pink_terracotta
setblock 370 286 470 minecraft:red_nether_bricks
fill 370 286 471 370 289 471 minecraft:pink_terracotta
setblock 370 286 475 minecraft:red_nether_bricks
fill 370 286 476 370 286 479 minecraft:pink_terracotta
setblock 370 286 480 minecraft:red_nether_bricks
fill 370 286 481 370 288 482 minecraft:pink_terracotta
setblock 370 286 484 minecraft:pink_terracotta
setblock 370 286 485 minecraft:red_nether_bricks
fill 370 286 486 370 289 486 minecraft:pink_terracotta
setblock 370 286 489 minecraft:pink_terracotta
setblock 370 286 490 minecraft:red_nether_bricks
fill 370 286 491 370 289 491 minecraft:pink_terracotta
setblock 370 286 495 minecraft:red_nether_bricks
setblock 330 287 464 minecraft:red_nether_bricks
fill 330 287 465 330 287 468 minecraft:pink_terracotta
setblock 330 287 469 minecraft:red_nether_bricks
fill 330 287 470 330 287 473 minecraft:pink_terracotta
setblock 330 287 474 minecraft:red_nether_bricks
fill 330 287 475 330 290 475 minecraft:pink_terracotta
setblock 330 287 489 minecraft:red_nether_bricks
fill 330 287 490 330 290 490 minecraft:pink_terracotta
setblock 330 287 493 minecraft:pink_terracotta
setblock 330 287 494 minecraft:red_nether_bricks
fill 330 287 495 331 289 495 minecraft:pink_terracotta
setblock 330 287 498 minecraft:pink_terracotta
setblock 330 287 499 minecraft:red_nether_bricks
fill 331 287 464 331 287 467 minecraft:pink_terracotta
setblock 331 287 468 minecraft:red_nether_bricks
fill 331 287 469 331 287 472 minecraft:pink_terracotta
setblock 331 287 473 minecraft:red_nether_bricks
fill 331 287 474 332 289 474 minecraft:pink_terracotta
setblock 331 287 492 minecraft:pink_terracotta
setblock 331 287 493 minecraft:red_nether_bricks
fill 331 287 494 331 290 494 minecraft:pink_terracotta
fill 331 287 504 334 287 504 minecraft:pink_terracotta
fill 332 287 464 332 287 466 minecraft:pink_terracotta
setblock 332 287 467 minecraft:red_nether_bricks
fill 332 287 468 332 287 471 minecraft:pink_terracotta
setblock 332 287 472 minecraft:red_nether_bricks
fill 332 287 473 332 290 473 minecraft:pink_terracotta
fill 333 287 464 333 287 465 minecraft:pink_terracotta
setblock 333 287 466 minecraft:red_nether_bricks
setblock 334 287 464 minecraft:pink_terracotta
setblock 334 287 465 minecraft:red_nether_bricks
setblock 334 287 466 minecraft:pink_terracotta
setblock 335 287 464 minecraft:red_nether_bricks
fill 335 287 465 336 287 465 minecraft:pink_terracotta
setblock 335 287 504 minecraft:red_nether_bricks
fill 336 287 464 338 287 464 minecraft:pink_terracotta
fill 336 287 504 336 290 504 minecraft:pink_terracotta
setblock 340 287 504 minecraft:white_concrete
fill 352 287 504 352 289 504 minecraft:pink_terracotta
setblock 355 287 481 minecraft:red_terracotta
setblock 358 287 478 minecraft:red_terracotta
setblock 358 287 481 minecraft:red_terracotta
setblock 360 287 464 minecraft:white_concrete
fill 360 287 484 361 300 486 minecraft:red_nether_bricks
setblock 365 287 504 minecraft:white_concrete
fill 369 287 467 369 287 469 minecraft:pink_terracotta
setblock 369 287 470 minecraft:red_nether_bricks
fill 369 287 471 369 290 471 minecraft:pink_terracotta
setblock 369 287 474 minecraft:pink_terracotta
setblock 369 287 475 minecraft:red_nether_bricks
fill 369 287 476 370 288 477 minecraft:pink_terracotta
setblock 370 287 464 minecraft:red_nether_bricks
fill 370 287 465 370 287 468 minecraft:pink_terracotta
setblock 370 287 469 minecraft:red_nether_bricks
fill 370 287 470 370 290 470 minecraft:pink_terracotta
setblock 370 287 474 minecraft:red_nether_bricks
fill 370 287 475 370 290 475 minecraft:pink_terracotta
setblock 370 287 478 minecraft:pink_terracotta
setblock 370 287 479 minecraft:red_nether_bricks
fill 370 287 480 370 290 480 minecraft:pink_terracotta
fill 370 287 485 370 290 485 minecraft:pink_terracotta
setblock 370 287 489 minecraft:red_nether_bricks
fill 370 287 490 370 290 490 minecraft:pink_terracotta
setblock 370 287 493 minecraft:pink_terracotta
setblock 370 287 494 minecraft:red_nether_bricks
fill 370 287 495 370 289 496 minecraft:pink_terracotta
setblock 370 287 498 minecraft:white_concrete
fill 330 288 464 330 288 467 minecraft:pink_terracotta
setblock 330 288 468 minecraft:red_nether_bricks
fill 330 288 469 330 288 472 minecraft:pink_terracotta
setblock 330 288 473 minecraft:red_nether_bricks
fill 330 288 474 330 291 474 minecraft:pink_terracotta
setblock 330 288 478 minecraft:red_nether_bricks
fill 330 288 479 330 291 479 minecraft:pink_terracotta
fill 330 288 489 330 291 489 minecraft:pink_terracotta
setblock 330 288 493 minecraft:red_nether_bricks
fill 330 288 494 330 291 494 minecraft:pink_terracotta
setblock 330 288 498 minecraft:red_nether_bricks
fill 330 288 499 330 288 502 minecraft:pink_terracotta
setblock 330 288 503 minecraft:red_nether_bricks
fill 330 288 504 333 288 504 minecraft:pink_terracotta
fill 331 288 464 331 288 466 minecraft:pink_terracotta
setblock 331 288 467 minecraft:red_nether_bricks
fill 331 288 468 331 288 471 minecraft:pink_terracotta
setblock 331 288 472 minecraft:red_nether_bricks
fill 331 288 473 331 291 473 minecraft:pink_terracotta
setblock 331 288 477 minecraft:red_nether_bricks
setblock 331 288 492 minecraft:red_nether_bricks
fill 331 288 493 331 291 493 minecraft:pink_terracotta
setblock 331 288 496 minecraft:pink_terracotta
setblock 331 288 497 minecraft:red_nether_bricks
fill 331 288 498 331 291 498 minecraft:pink_terracotta
fill 332 288 464 332 288 465 minecraft:pink_terracotta
setblock 332 288 466 minecraft:red_nether_bricks
fill 332 288 467 332 288 470 minecraft:pink_terracotta
setblock 332 288 471 minecraft:red_nether_bricks
fill 332 288 472 332 291 472 minecraft:pink_terracotta
setblock 333 288 464 minecraft:pink_terracotta
setblock 333 288 465 minecraft:red_nether_bricks
setblock 333 288 466 minecraft:pink_terracotta
setblock 334 288 464 minecraft:red_nether_bricks
fill 334 288 465 335 289 465 minecraft:pink_terracotta
setblock 334 288 504 minecraft:red_nether_bricks
fill 335 288 464 337 289 464 minecraft:pink_terracotta
fill 335 288 504 335 291 504 minecraft:pink_terracotta
fill 337 288 504 337 289 504 minecraft:pink_terracotta
setblock 346 288 504 minecraft:white_concrete
fill 351 288 504 351 290 504 minecraft:pink_terracotta
setblock 354 288 464 minecraft:white_concrete
fill 359 288 485 359 289 485 minecraft:red_terracotta
fill 362 288 485 362 289 485 minecraft:red_terracotta
fill 367 288 468 368 291 468 minecraft:white_concrete
fill 368 288 467 368 291 467 minecraft:white_concrete
fill 368 288 469 368 289 469 minecraft:white_concrete
fill 368 288 471 368 288 474 minecraft:pink_terracotta
setblock 369 288 464 minecraft:red_nether_bricks
setblock 369 288 466 minecraft:white_concrete
fill 369 288 467 369 288 468 minecraft:pink_terracotta
setblock 369 288 469 minecraft:red_nether_bricks
fill 369 288 470 369 291 470 minecraft:pink_terracotta
setblock 369 288 474 minecraft:red_nether_bricks
fill 369 288 475 369 291 475 minecraft:pink_terracotta
setblock 369 288 478 minecraft:pink_terracotta
fill 370 288 464 370 288 467 minecraft:pink_terracotta
setblock 370 288 468 minecraft:red_nether_bricks
fill 370 288 469 370 291 469 minecraft:pink_terracotta
setblock 370 288 473 minecraft:red_nether_bricks
fill 370 288 474 370 291 474 minecraft:pink_terracotta
setblock 370 288 478 minecraft:red_nether_bricks
fill 370 288 479 370 291 479 minecraft:pink_terracotta
setblock 370 288 483 minecraft:red_nether_bricks
setblock 370 288 488 minecraft:red_nether_bricks
fill 370 288 489 370 291 489 minecraft:pink_terracotta
setblock 370 288 493 minecraft:red_nether_bricks
fill 370 288 494 370 291 494 minecraft:pink_terracotta
setblock 370 288 497 minecraft:pink_terracotta
setblock 370 288 498 minecraft:red_nether_bricks
fill 330 289 464 330 289 466 minecraft:pink_terracotta
setblock 330 289 467 minecraft:red_nether_bricks
fill 330 289 468 330 289 471 minecraft:pink_terracotta
setblock 330 289 472 minecraft:red_nether_bricks
fill 330 289 473 330 292 473 minecraft:pink_terracotta
setblock 330 289 476 minecraft:pink_terracotta
setblock 330 289 477 minecraft:red_nether_bricks
fill 330 289 478 331 291 478 minecraft:pink_terracotta
fill 330 289 480 330 290 480 minecraft:pink_terracotta
setblock 330 289 482 minecraft:white_concrete
setblock 330 289 492 minecraft:red_nether_bricks
fill 330 289 493 330 292 493 minecraft:pink_terracotta
setblock 330 289 496 minecraft:pink_terracotta
setblock 330 289 497 minecraft:red_nether_bricks
fill 330 289 498 330 289 501 minecraft:pink_terracotta
setblock 330 289 502 minecraft:red_nether_bricks
fill 330 289 503 330 291 504 minecraft:pink_terracotta
fill 331 289 464 331 289 465 minecraft:pink_terracotta
setblock 331 289 466 minecraft:red_nether_bricks
fill 331 289 467 331 289 470 minecraft:pink_terracotta
setblock 331 289 471 minecraft:red_nether_bricks
fill 331 289 472 331 292 472 minecraft:pink_terracotta
setblock 331 289 476 minecraft:red_nether_bricks
fill 331 289 477 331 292 477 minecraft:pink_terracotta
fill 331 289 492 331 292 492 minecraft:pink_terracotta
setblock 331 289 496 minecraft:red_nether_bricks
fill 331 289 497 331 292 497 minecraft:pink_terracotta
fill 331 289 499 331 289 500 minecraft:pink_terracotta
setblock 331 289 501 minecraft:red_nether_bricks
fill 331 289 502 331 292 502 minecraft:pink_terracotta
fill 331 289 504 332 289 504 minecraft:pink_terracotta
setblock 332 289 464 minecraft:pink_terracotta
setblock 332 289 465 minecraft:red_nether_bricks
setblock 332 289 466 minecraft:light[level=12]
fill 332 289 467 332 289 469 minecraft:pink_terracotta
setblock 332 289 470 minecraft:red_nether_bricks
fill 332 289 471 332 292 471 minecraft:pink_terracotta
setblock 332 289 475 minecraft:red_nether_bricks
setblock 332 289 482 minecraft:light[level=12]
setblock 332 289 490 minecraft:light[level=12]
setblock 332 289 498 minecraft:light[level=12]
fill 332 289 503 333 289 503 minecraft:pink_terracotta
setblock 333 289 464 minecraft:red_nether_bricks
fill 333 289 465 333 292 465 minecraft:pink_terracotta
setblock 333 289 504 minecraft:red_nether_bricks
fill 334 289 464 334 292 464 minecraft:pink_terracotta
setblock 334 289 503 minecraft:red_nether_bricks
fill 334 289 504 334 292 504 minecraft:pink_terracotta
setblock 340 289 466 minecraft:light[level=12]
setblock 340 289 474 minecraft:light[level=12]
setblock 340 289 482 minecraft:light[level=12]
setblock 340 289 490 minecraft:light[level=12]
setblock 340 289 498 minecraft:light[level=12]
setblock 348 289 464 minecraft:white_concrete
setblock 348 289 466 minecraft:light[level=12]
setblock 348 289 474 minecraft:light[level=12]
setblock 348 289 482 minecraft:light[level=12]
setblock 348 289 490 minecraft:light[level=12]
setblock 348 289 498 minecraft:light[level=12]
fill 349 289 504 350 291 504 minecraft:pink_terracotta
setblock 356 289 466 minecraft:light[level=12]
setblock 356 289 474 minecraft:light[level=12]
setblock 356 289 482 minecraft:light[level=12]
setblock 356 289 490 minecraft:light[level=12]
setblock 356 289 498 minecraft:light[level=12]
setblock 359 289 484 minecraft:red_terracotta
setblock 359 289 486 minecraft:red_terracotta
fill 360 289 483 361 289 483 minecraft:red_terracotta
fill 360 289 487 361 289 487 minecraft:red_terracotta
setblock 362 289 484 minecraft:red_terracotta
setblock 362 289 486 minecraft:red_terracotta
setblock 364 289 466 minecraft:light[level=12]
setblock 364 289 474 minecraft:light[level=12]
setblock 364 289 482 minecraft:light[level=12]
setblock 364 289 490 minecraft:light[level=12]
setblock 364 289 498 minecraft:light[level=12]
setblock 367 289 464 minecraft:white_concrete
fill 367 289 467 367 290 467 minecraft:white_concrete
fill 367 289 469 367 290 469 minecraft:white_concrete
fill 368 289 466 368 290 466 minecraft:white_concrete
fill 368 289 470 368 289 473 minecraft:pink_terracotta
setblock 368 289 474 minecraft:red_nether_bricks
fill 368 289 475 368 291 476 minecraft:pink_terracotta
fill 369 289 464 370 291 464 minecraft:pink_terracotta
fill 369 289 466 369 289 467 minecraft:pink_terracotta
setblock 369 289 468 minecraft:red_nether_bricks
fill 369 289 469 369 292 469 minecraft:pink_terracotta
setblock 369 289 473 minecraft:red_nether_bricks
fill 369 289 474 369 292 474 minecraft:pink_terracotta
fill 369 289 476 369 289 477 minecraft:pink_terracotta
setblock 369 289 478 minecraft:red_nether_bricks
fill 369 289 479 369 291 480 minecraft:pink_terracotta
fill 370 289 465 370 289 466 minecraft:pink_terracotta
setblock 370 289 467 minecraft:red_nether_bricks
fill 370 289 468 370 292 468 minecraft:pink_terracotta
setblock 370 289 472 minecraft:red_nether_bricks
fill 370 289 473 370 292 473 minecraft:pink_terracotta
setblock 370 289 476 minecraft:pink_terracotta
setblock 370 289 477 minecraft:red_nether_bricks
fill 370 289 478 370 292 478 minecraft:pink_terracotta
setblock 370 289 481 minecraft:pink_terracotta
setblock 370 289 482 minecraft:red_nether_bricks
fill 370 289 483 370 291 484 minecraft:pink_terracotta
setblock 370 289 487 minecraft:red_nether_bricks
fill 370 289 488 370 292 488 minecraft:pink_terracotta
setblock 370 289 492 minecraft:red_nether_bricks
fill 370 289 493 370 292 493 minecraft:pink_terracotta
setblock 370 289 497 minecraft:red_nether_bricks
fill 370 289 498 370 290 500 minecraft:pink_terracotta
fill 330 290 464 330 290 465 minecraft:pink_terracotta
setblock 330 290 466 minecraft:red_nether_bricks
fill 330 290 467 330 290 470 minecraft:pink_terracotta
setblock 330 290 471 minecraft:red_nether_bricks
fill 330 290 472 330 293 472 minecraft:pink_terracotta
setblock 330 290 476 minecraft:red_nether_bricks
fill 330 290 477 330 293 477 minecraft:pink_terracotta
setblock 330 290 481 minecraft:red_nether_bricks
setblock 330 290 488 minecraft:white_concrete
setblock 330 290 491 minecraft:red_nether_bricks
fill 330 290 492 330 293 492 minecraft:pink_terracotta
setblock 330 290 495 minecraft:pink_terracotta
setblock 330 290 496 minecraft:red_nether_bricks
fill 330 290 497 330 290 500 minecraft:pink_terracotta
setblock 330 290 501 minecraft:red_nether_bricks
fill 330 290 502 330 293 502 minecraft:pink_terracotta
setblock 331 290 464 minecraft:pink_terracotta
setblock 331 290 465 minecraft:red_nether_bricks
fill 331 290 466 331 290 469 minecraft:pink_terracotta
setblock 331 290 470 minecraft:red_nether_bricks
fill 331 290 471 331 293 471 minecraft:pink_terracotta
setblock 331 290 474 minecraft:pink_terracotta
setblock 331 290 475 minecraft:red_nether_bricks
fill 331 290 476 332 292 476 minecraft:pink_terracotta
fill 331 290 491 331 293 491 minecraft:pink_terracotta
setblock 331 290 495 minecraft:red_nether_bricks
fill 331 290 496 332 292 496 minecraft:pink_terracotta
setblock 331 290 499 minecraft:pink_terracotta
setblock 331 290 500 minecraft:red_nether_bricks
fill 331 290 501 331 293 501 minecraft:pink_terracotta
fill 331 290 503 331 290 504 minecraft:pink_terracotta
setblock 332 290 464 minecraft:red_nether_bricks
fill 332 290 465 332 293 465 minecraft:pink_terracotta
fill 332 290 467 332 290 468 minecraft:pink_terracotta
setblock 332 290 469 minecraft:red_nether_bricks
fill 332 290 470 332 293 470 minecraft:pink_terracotta
setblock 332 290 474 minecraft:red_nether_bricks
fill 332 290 475 332 293 475 minecraft:pink_terracotta
setblock 332 290 494 minecraft:red_nether_bricks
fill 332 290 495 332 293 495 minecraft:pink_terracotta
fill 332 290 497 332 290 498 minecraft:pink_terracotta
setblock 332 290 499 minecraft:red_nether_bricks
fill 332 290 500 332 293 500 minecraft:pink_terracotta
setblock 332 290 503 minecraft:pink_terracotta
setblock 332 290 504 minecraft:red_nether_bricks
fill 333 290 464 333 293 464 minecraft:pink_terracotta
setblock 333 290 503 minecraft:red_nether_bricks
fill 333 290 504 333 293 504 minecraft:pink_terracotta
fill 334 290 465 334 291 465 minecraft:pink_terracotta
fill 334 290 503 335 292 503 minecraft:pink_terracotta
fill 335 290 464 336 290 464 minecraft:pink_terracotta
setblock 337 290 504 minecraft:red_nether_bricks
fill 338 290 504 338 293 504 minecraft:pink_terracotta
setblock 339 290 504 minecraft:white_concrete
setblock 342 290 464 minecraft:white_concrete
setblock 347 290 504 minecraft:red_nether_bricks
fill 348 290 504 348 293 504 minecraft:pink_terracotta
setblock 352 290 504 minecraft:red_nether_bricks
fill 353 290 504 353 293 504 minecraft:pink_terracotta
setblock 358 290 504 minecraft:white_concrete
setblock 361 290 464 minecraft:white_concrete
setblock 366 290 468 minecraft:black_concrete
fill 368 290 464 368 293 464 minecraft:pink_terracotta
fill 368 290 469 368 290 472 minecraft:pink_terracotta
setblock 368 290 473 minecraft:red_nether_bricks
fill 368 290 474 368 293 474 minecraft:pink_terracotta
setblock 368 290 477 minecraft:pink_terracotta
setblock 368 290 478 minecraft:red_nether_bricks
setblock 369 290 466 minecraft:pink_terracotta
setblock 369 290 467 minecraft:red_nether_bricks
fill 369 290 468 369 293 468 minecraft:pink_terracotta
setblock 369 290 472 minecraft:red_nether_bricks
fill 369 290 473 369 293 473 minecraft:pink_terracotta
setblock 369 290 476 minecraft:pink_terracotta
setblock 369 290 477 minecraft:red_nether_bricks
fill 369 290 478 369 293 478 minecraft:pink_terracotta
setblock 369 290 481 minecraft:pink_terracotta
setblock 369 290 492 minecraft:red_nether_bricks
fill 369 290 493 369 290 496 minecraft:pink_terracotta
setblock 369 290 497 minecraft:red_nether_bricks
setblock 370 290 465 minecraft:pink_terracotta
setblock 370 290 466 minecraft:red_nether_bricks
fill 370 290 467 370 293 467 minecraft:pink_terracotta
setblock 370 290 471 minecraft:red_nether_bricks
fill 370 290 472 370 293 472 minecraft:pink_terracotta
setblock 370 290 476 minecraft:red_nether_bricks
fill 370 290 477 370 293 477 minecraft:pink_terracotta
setblock 370 290 481 minecraft:red_nether_bricks
fill 370 290 482 370 293 482 minecraft:pink_terracotta
setblock 370 290 486 minecraft:red_nether_bricks
fill 370 290 487 370 293 487 minecraft:pink_terracotta
setblock 370 290 491 minecraft:red_nether_bricks
fill 370 290 492 370 293 492 minecraft:pink_terracotta
setblock 370 290 495 minecraft:pink_terracotta
setblock 370 290 496 minecraft:red_nether_bricks
fill 370 290 497 370 293 497 minecraft:pink_terracotta
setblock 370 290 501 minecraft:red_nether_bricks
fill 370 290 502 370 292 503 minecraft:pink_terracotta
setblock 330 291 464 minecraft:pink_terracotta
setblock 330 291 465 minecraft:red_nether_bricks
fill 330 291 466 330 291 469 minecraft:pink_terracotta
setblock 330 291 470 minecraft:red_nether_bricks
fill 330 291 471 330 294 471 minecraft:pink_terracotta
setblock 330 291 475 minecraft:red_nether_bricks
fill 330 291 476 330 294 476 minecraft:pink_terracotta
setblock 330 291 480 minecraft:red_nether_bricks
fill 330 291 481 330 293 482 minecraft:pink_terracotta
fill 330 291 488 330 292 488 minecraft:pink_terracotta
setblock 330 291 490 minecraft:red_nether_bricks
fill 330 291 491 330 294 491 minecraft:pink_terracotta
setblock 330 291 495 minecraft:red_nether_bricks
fill 330 291 496 330 291 499 minecraft:pink_terracotta
setblock 330 291 500 minecraft:red_nether_bricks
fill 330 291 501 330 294 501 minecraft:pink_terracotta
setblock 331 291 464 minecraft:red_nether_bricks
fill 331 291 465 331 291 468 minecraft:pink_terracotta
setblock 331 291 469 minecraft:red_nether_bricks
fill 331 291 470 331 294 470 minecraft:pink_terracotta
setblock 331 291 474 minecraft:red_nether_bricks
fill 331 291 475 331 294 475 minecraft:pink_terracotta
setblock 331 291 479 minecraft:red_nether_bricks
setblock 331 291 494 minecraft:red_nether_bricks
fill 331 291 495 331 294 495 minecraft:pink_terracotta
setblock 331 291 499 minecraft:red_nether_bricks
fill 331 291 500 331 294 500 minecraft:pink_terracotta
setblock 331 291 503 minecraft:pink_terracotta
setblock 331 291 504 minecraft:red_nether_bricks
fill 332 291 464 332 294 464 minecraft:pink_terracotta
setblock 332 291 467 minecraft:pink_terracotta
setblock 332 291 468 minecraft:red_nether_bricks
fill 332 291 469 332 292 469 minecraft:pink_terracotta
setblock 332 291 473 minecraft:red_nether_bricks
fill 332 291 474 332 294 474 minecraft:pink_terracotta
fill 332 291 494 332 294 494 minecraft:pink_terracotta
setblock 332 291 497 minecraft:pink_terracotta
setblock 332 291 498 minecraft:red_nether_bricks
fill 332 291 499 332 294 499 minecraft:pink_terracotta
fill 332 291 501 332 291 502 minecraft:pink_terracotta
setblock 332 291 503 minecraft:red_nether_bricks
fill 332 291 504 332 294 504 minecraft:pink_terracotta
setblock 333 291 502 minecraft:red_nether_bricks
fill 333 291 503 333 294 503 minecraft:pink_terracotta
setblock 335 291 464 minecraft:pink_terracotta
setblock 336 291 464 minecraft:red_nether_bricks
setblock 336 291 503 minecraft:pink_terracotta
setblock 336 291 504 minecraft:red_nether_bricks
fill 337 291 504 337 294 504 minecraft:pink_terracotta
fill 339 291 504 339 292 504 minecraft:pink_terracotta
fill 344 291 504 345 291 504 minecraft:pink_terracotta
setblock 346 291 504 minecraft:red_nether_bricks
setblock 347 291 503 minecraft:red_nether_bricks
fill 347 291 504 347 294 504 minecraft:pink_terracotta
fill 348 291 503 351 291 503 minecraft:pink_terracotta
setblock 351 291 504 minecraft:red_nether_bricks
fill 352 291 504 352 294 504 minecraft:pink_terracotta
setblock 355 291 464 minecraft:white_concrete
setblock 364 291 504 minecraft:white_concrete
fill 367 291 464 367 294 464 minecraft:pink_terracotta
setblock 367 291 473 minecraft:red_nether_bricks
fill 367 291 474 367 292 476 minecraft:pink_terracotta
fill 368 291 469 368 291 471 minecraft:pink_terracotta
setblock 368 291 472 minecraft:red_nether_bricks
fill 368 291 473 368 294 473 minecraft:pink_terracotta
setblock 368 291 477 minecraft:red_nether_bricks
fill 368 291 478 368 293 479 minecraft:pink_terracotta
setblock 369 291 465 minecraft:pink_terracotta
setblock 369 291 466 minecraft:red_nether_bricks
fill 369 291 467 369 294 467 minecraft:pink_terracotta
setblock 369 291 471 minecraft:red_nether_bricks
fill 369 291 472 369 294 472 minecraft:pink_terracotta
setblock 369 291 476 minecraft:red_nether_bricks
fill 369 291 477 369 294 477 minecraft:pink_terracotta
setblock 369 291 481 minecraft:red_nether_bricks
fill 369 291 482 369 294 482 minecraft:pink_terracotta
fill 369 291 490 369 296 490 minecraft:white_concrete
fill 369 291 492 369 291 495 minecraft:pink_terracotta
setblock 369 291 496 minecraft:red_nether_bricks
fill 369 291 497 369 292 499 minecraft:pink_terracotta
fill 369 291 504 370 291 504 minecraft:pink_terracotta
setblock 370 291 465 minecraft:red_nether_bricks
fill 370 291 466 370 294 466 minecraft:pink_terracotta
setblock 370 291 470 minecraft:red_nether_bricks
fill 370 291 471 370 294 471 minecraft:pink_terracotta
setblock 370 291 475 minecraft:red_nether_bricks
fill 370 291 476 370 294 476 minecraft:pink_terracotta
setblock 370 291 480 minecraft:red_nether_bricks
fill 370 291 481 370 294 481 minecraft:pink_terracotta
setblock 370 291 485 minecraft:red_nether_bricks
fill 370 291 486 370 294 486 minecraft:pink_terracotta
setblock 370 291 490 minecraft:red_nether_bricks
fill 370 291 491 370 294 491 minecraft:pink_terracotta
setblock 370 291 495 minecraft:red_nether_bricks
fill 370 291 496 370 294 496 minecraft:pink_terracotta
fill 370 291 498 370 291 499 minecraft:pink_terracotta
setblock 370 291 500 minecraft:red_nether_bricks
fill 370 291 501 370 294 501 minecraft:pink_terracotta
setblock 330 292 464 minecraft:red_nether_bricks
fill 330 292 465 330 292 468 minecraft:pink_terracotta
setblock 330 292 469 minecraft:red_nether_bricks
fill 330 292 470 330 295 470 minecraft:pink_terracotta
setblock 330 292 474 minecraft:red_nether_bricks
fill 330 292 475 330 295 475 minecraft:pink_terracotta
setblock 330 292 478 minecraft:pink_terracotta
setblock 330 292 479 minecraft:red_nether_bricks
fill 330 292 480 331 294 480 minecraft:pink_terracotta
setblock 330 292 483 minecraft:pink_terracotta
setblock 330 292 484 minecraft:red_nether_bricks
setblock 330 292 489 minecraft:red_nether_bricks
fill 330 292 490 330 295 490 minecraft:pink_terracotta
setblock 330 292 494 minecraft:red_nether_bricks
fill 330 292 495 330 292 498 minecraft:pink_terracotta
setblock 330 292 499 minecraft:red_nether_bricks
fill 330 292 500 330 295 500 minecraft:pink_terracotta
setblock 330 292 503 minecraft:pink_terracotta
setblock 330 292 504 minecraft:red_nether_bricks
fill 331 292 464 331 292 467 minecraft:pink_terracotta
setblock 331 292 468 minecraft:red_nether_bricks
fill 331 292 469 331 295 469 minecraft:pink_terracotta
setblock 331 292 473 minecraft:red_nether_bricks
fill 331 292 474 331 295 474 minecraft:pink_terracotta
setblock 331 292 478 minecraft:red_nether_bricks
fill 331 292 479 331 295 479 minecraft:pink_terracotta
setblock 331 292 493 minecraft:red_nether_bricks
fill 331 292 494 331 295 494 minecraft:pink_terracotta
setblock 331 292 498 minecraft:red_nether_bricks
fill 331 292 499 331 295 499 minecraft:pink_terracotta
setblock 331 292 503 minecraft:red_nether_bricks
fill 331 292 504 331 295 504 minecraft:pink_terracotta
setblock 332 292 468 minecraft:pink_terracotta
setblock 332 292 472 minecraft:red_nether_bricks
fill 332 292 473 332 294 473 minecraft:pink_terracotta
setblock 332 292 477 minecraft:red_nether_bricks
setblock 332 292 497 minecraft:red_nether_bricks
fill 332 292 498 332 295 498 minecraft:pink_terracotta
setblock 332 292 501 minecraft:pink_terracotta
setblock 332 292 502 minecraft:red_nether_bricks
fill 332 292 503 332 295 503 minecraft:pink_terracotta
fill 333 292 502 334 294 502 minecraft:pink_terracotta
setblock 334 292 465 minecraft:red_nether_bricks
setblock 335 292 464 minecraft:red_nether_bricks
setblock 335 292 504 minecraft:red_nether_bricks
fill 336 292 464 336 293 464 minecraft:pink_terracotta
setblock 336 292 503 minecraft:red_nether_bricks
fill 336 292 504 336 295 504 minecraft:pink_terracotta
fill 337 292 503 337 295 503 minecraft:pink_terracotta
setblock 340 292 504 minecraft:red_nether_bricks
fill 341 292 504 344 292 504 minecraft:pink_terracotta
setblock 345 292 503 minecraft:pink_terracotta
setblock 345 292 504 minecraft:red_nether_bricks
setblock 346 292 503 minecraft:red_nether_bricks
fill 346 292 504 346 295 504 minecraft:pink_terracotta
fill 347 292 503 350 292 503 minecraft:pink_terracotta
fill 348 292 502 350 293 502 minecraft:pink_terracotta
setblock 349 292 464 minecraft:white_concrete
setblock 349 292 504 minecraft:pink_terracotta
setblock 350 292 504 minecraft:red_nether_bricks
setblock 351 292 503 minecraft:red_nether_bricks
fill 351 292 504 351 295 504 minecraft:pink_terracotta
fill 352 292 503 352 295 503 minecraft:pink_terracotta
setblock 354 292 504 minecraft:pink_terracotta
fill 366 292 464 366 295 464 minecraft:pink_terracotta
setblock 367 292 472 minecraft:red_nether_bricks
fill 367 292 473 367 295 473 minecraft:pink_terracotta
setblock 367 292 477 minecraft:red_nether_bricks
fill 367 292 490 368 295 490 minecraft:white_concrete
fill 367 292 504 369 292 504 minecraft:pink_terracotta
setblock 368 292 465 minecraft:pink_terracotta
fill 368 292 468 368 292 470 minecraft:pink_terracotta
setblock 368 292 471 minecraft:red_nether_bricks
fill 368 292 472 368 295 472 minecraft:pink_terracotta
setblock 368 292 475 minecraft:pink_terracotta
setblock 368 292 476 minecraft:red_nether_bricks
fill 368 292 477 368 295 477 minecraft:pink_terracotta
setblock 368 292 480 minecraft:pink_terracotta
fill 368 292 489 369 295 489 minecraft:white_concrete
fill 368 292 491 369 295 491 minecraft:white_concrete
setblock 369 292 464 minecraft:pink_terracotta
setblock 369 292 465 minecraft:red_nether_bricks
fill 369 292 466 369 295 466 minecraft:pink_terracotta
setblock 369 292 470 minecraft:red_nether_bricks
fill 369 292 471 369 295 471 minecraft:pink_terracotta
setblock 369 292 475 minecraft:red_nether_bricks
fill 369 292 476 369 295 476 minecraft:pink_terracotta
setblock 369 292 479 minecraft:pink_terracotta
setblock 369 292 480 minecraft:red_nether_bricks
fill 369 292 481 369 295 481 minecraft:pink_terracotta
fill 369 292 483 370 292 483 minecraft:pink_terracotta
fill 369 292 488 369 295 488 minecraft:white_concrete
fill 369 292 492 369 292 494 minecraft:pink_terracotta
setblock 369 292 495 minecraft:red_nether_bricks
fill 369 292 496 369 295 496 minecraft:pink_terracotta
setblock 369 292 500 minecraft:red_nether_bricks
fill 369 292 501 369 294 502 minecraft:pink_terracotta
setblock 370 292 464 minecraft:red_nether_bricks
fill 370 292 465 370 295 465 minecraft:pink_terracotta
setblock 370 292 469 minecraft:red_nether_bricks
fill 370 292 470 370 295 470 minecraft:pink_terracotta
setblock 370 292 474 minecraft:red_nether_bricks
fill 370 292 475 370 295 475 minecraft:pink_terracotta
setblock 370 292 479 minecraft:red_nether_bricks
fill 370 292 480 370 295 480 minecraft:pink_terracotta
setblock 370 292 484 minecraft:red_nether_bricks
fill 370 292 485 370 295 485 minecraft:pink_terracotta
setblock 370 292 489 minecraft:red_nether_bricks
fill 370 292 490 370 295 490 minecraft:pink_terracotta
setblock 370 292 494 minecraft:red_nether_bricks
fill 370 292 495 370 295 495 minecraft:pink_terracotta
setblock 370 292 498 minecraft:pink_terracotta
setblock 370 292 499 minecraft:red_nether_bricks
fill 370 292 500 370 295 500 minecraft:pink_terracotta
setblock 370 292 504 minecraft:red_nether_bricks
fill 330 293 464 330 293 467 minecraft:pink_terracotta
setblock 330 293 468 minecraft:red_nether_bricks
fill 330 293 469 330 296 469 minecraft:pink_terracotta
setblock 330 293 473 minecraft:red_nether_bricks
fill 330 293 474 330 296 474 minecraft:pink_terracotta
setblock 330 293 478 minecraft:red_nether_bricks
fill 330 293 479 330 296 479 minecraft:pink_terracotta
setblock 330 293 483 minecraft:red_nether_bricks
fill 330 293 484 330 295 485 minecraft:pink_terracotta
setblock 330 293 487 minecraft:pink_terracotta
setblock 330 293 488 minecraft:red_nether_bricks
fill 330 293 489 330 295 489 minecraft:pink_terracotta
setblock 330 293 493 minecraft:red_nether_bricks
fill 330 293 494 330 293 497 minecraft:pink_terracotta
setblock 330 293 498 minecraft:red_nether_bricks
fill 330 293 499 330 296 499 minecraft:pink_terracotta
setblock 330 293 503 minecraft:red_nether_bricks
fill 330 293 504 330 296 504 minecraft:pink_terracotta
fill 331 293 464 331 293 466 minecraft:pink_terracotta
setblock 331 293 467 minecraft:red_nether_bricks
fill 331 293 468 331 295 468 minecraft:pink_terracotta
setblock 331 293 472 minecraft:red_nether_bricks
fill 331 293 473 331 296 473 minecraft:pink_terracotta
setblock 331 293 476 minecraft:pink_terracotta
setblock 331 293 477 minecraft:red_nether_bricks
fill 331 293 478 331 296 478 minecraft:pink_terracotta
setblock 331 293 481 minecraft:pink_terracotta
setblock 331 293 492 minecraft:red_nether_bricks
fill 331 293 493 331 296 493 minecraft:pink_terracotta
setblock 331 293 496 minecraft:pink_terracotta
setblock 331 293 497 minecraft:red_nether_bricks
fill 331 293 498 331 296 498 minecraft:pink_terracotta
setblock 331 293 502 minecraft:red_nether_bricks
fill 331 293 503 331 296 503 minecraft:pink_terracotta
setblock 332 293 471 minecraft:red_nether_bricks
fill 332 293 472 332 294 472 minecraft:pink_terracotta
setblock 332 293 476 minecraft:red_nether_bricks
fill 332 293 477 332 294 477 minecraft:pink_terracotta
setblock 332 293 496 minecraft:red_nether_bricks
fill 332 293 497 333 293 497 minecraft:pink_terracotta
setblock 332 293 501 minecraft:red_nether_bricks
fill 332 293 502 332 296 502 minecraft:pink_terracotta
setblock 333 293 465 minecraft:red_nether_bricks
fill 333 293 498 333 293 499 minecraft:pink_terracotta
setblock 333 293 500 minecraft:red_nether_bricks
setblock 334 293 464 minecraft:red_nether_bricks
setblock 334 293 503 minecraft:pink_terracotta
setblock 334 293 504 minecraft:red_nether_bricks
fill 335 293 464 335 295 464 minecraft:pink_terracotta
setblock 335 293 502 minecraft:pink_terracotta
setblock 335 293 503 minecraft:red_nether_bricks
fill 335 293 504 335 296 504 minecraft:pink_terracotta
fill 336 293 503 336 296 503 minecraft:pink_terracotta
fill 338 293 503 338 294 503 minecraft:pink_terracotta
setblock 339 293 504 minecraft:red_nether_bricks
fill 340 293 504 343 293 504 minecraft:pink_terracotta
setblock 343 293 464 minecraft:white_concrete
fill 343 293 503 344 293 503 minecraft:pink_terracotta
setblock 344 293 504 minecraft:red_nether_bricks
setblock 345 293 502 minecraft:pink_terracotta
setblock 345 293 503 minecraft:red_nether_bricks
fill 345 293 504 345 296 504 minecraft:pink_terracotta
setblock 346 293 502 minecraft:red_nether_bricks
fill 346 293 503 349 293 503 minecraft:pink_terracotta
fill 347 293 502 347 296 502 minecraft:pink_terracotta
setblock 349 293 464 minecraft:red_nether_bricks
setblock 349 293 504 minecraft:red_nether_bricks
fill 350 293 464 350 296 464 minecraft:pink_terracotta
setblock 350 293 503 minecraft:red_nether_bricks
fill 350 293 504 350 296 504 minecraft:pink_terracotta
setblock 351 293 502 minecraft:red_nether_bricks
fill 351 293 503 351 296 503 minecraft:pink_terracotta
fill 353 293 503 353 294 503 minecraft:pink_terracotta
setblock 354 293 504 minecraft:red_nether_bricks
setblock 357 293 504 minecraft:white_concrete
fill 362 293 464 362 294 464 minecraft:white_concrete
fill 365 293 464 365 296 464 minecraft:pink_terracotta
fill 366 293 504 368 293 504 minecraft:pink_terracotta
setblock 367 293 465 minecraft:pink_terracotta
setblock 367 293 471 minecraft:red_nether_bricks
fill 367 293 472 367 295 472 minecraft:pink_terracotta
fill 367 293 474 367 293 475 minecraft:pink_terracotta
setblock 367 293 476 minecraft:red_nether_bricks
fill 367 293 477 367 294 479 minecraft:pink_terracotta
fill 367 293 489 367 294 489 minecraft:white_concrete
fill 367 293 491 367 294 491 minecraft:white_concrete
setblock 368 293 465 minecraft:red_nether_bricks
fill 368 293 468 368 293 469 minecraft:pink_terracotta
setblock 368 293 470 minecraft:red_nether_bricks
fill 368 293 471 368 296 471 minecraft:pink_terracotta
setblock 368 293 475 minecraft:red_nether_bricks
fill 368 293 476 368 296 476 minecraft:pink_terracotta
setblock 368 293 480 minecraft:red_nether_bricks
fill 368 293 481 368 296 481 minecraft:pink_terracotta
fill 368 293 488 368 294 488 minecraft:white_concrete
fill 368 293 492 368 294 492 minecraft:white_concrete
fill 368 293 503 369 293 503 minecraft:pink_terracotta
setblock 369 293 464 minecraft:red_nether_bricks
fill 369 293 465 369 296 465 minecraft:pink_terracotta
setblock 369 293 469 minecraft:red_nether_bricks
fill 369 293 470 369 296 470 minecraft:pink_terracotta
setblock 369 293 474 minecraft:red_nether_bricks
fill 369 293 475 369 296 475 minecraft:pink_terracotta
setblock 369 293 479 minecraft:red_nether_bricks
fill 369 293 480 369 296 480 minecraft:pink_terracotta
setblock 369 293 483 minecraft:pink_terracotta
setblock 369 293 484 minecraft:red_nether_bricks
fill 369 293 492 369 293 493 minecraft:pink_terracotta
setblock 369 293 494 minecraft:red_nether_bricks
fill 369 293 495 369 296 495 minecraft:pink_terracotta
fill 369 293 497 369 293 498 minecraft:pink_terracotta
setblock 369 293 499 minecraft:red_nether_bricks
fill 369 293 500 369 296 500 minecraft:pink_terracotta
setblock 369 293 504 minecraft:red_nether_bricks
fill 370 293 464 370 296 464 minecraft:pink_terracotta
setblock 370 293 468 minecraft:red_nether_bricks
fill 370 293 469 370 296 469 minecraft:pink_terracotta
setblock 370 293 473 minecraft:red_nether_bricks
fill 370 293 474 370 296 474 minecraft:pink_terracotta
setblock 370 293 478 minecraft:red_nether_bricks
fill 370 293 479 370 296 479 minecraft:pink_terracotta
setblock 370 293 483 minecraft:red_nether_bricks
fill 370 293 484 370 296 484 minecraft:pink_terracotta
setblock 370 293 488 minecraft:red_nether_bricks
fill 370 293 489 370 295 489 minecraft:pink_terracotta
setblock 370 293 493 minecraft:red_nether_bricks
fill 370 293 494 370 296 494 minecraft:pink_terracotta
setblock 370 293 498 minecraft:red_nether_bricks
fill 370 293 499 370 296 499 minecraft:pink_terracotta
setblock 370 293 502 minecraft:pink_terracotta
setblock 370 293 503 minecraft:red_nether_bricks
fill 370 293 504 370 296 504 minecraft:pink_terracotta
fill 330 294 464 330 294 466 minecraft:pink_terracotta
setblock 330 294 467 minecraft:red_nether_bricks
fill 330 294 468 330 297 468 minecraft:pink_terracotta
setblock 330 294 472 minecraft:red_nether_bricks
fill 330 294 473 330 297 473 minecraft:pink_terracotta
setblock 330 294 477 minecraft:red_nether_bricks
fill 330 294 478 330 297 478 minecraft:pink_terracotta
setblock 330 294 481 minecraft:pink_terracotta
setblock 330 294 482 minecraft:red_nether_bricks
fill 330 294 483 330 297 483 minecraft:pink_terracotta
setblock 330 294 486 minecraft:pink_terracotta
setblock 330 294 487 minecraft:red_nether_bricks
fill 330 294 488 330 295 488 minecraft:pink_terracotta
setblock 330 294 492 minecraft:red_nether_bricks
fill 330 294 493 330 294 496 minecraft:pink_terracotta
setblock 330 294 497 minecraft:red_nether_bricks
fill 330 294 498 330 297 498 minecraft:pink_terracotta
setblock 330 294 502 minecraft:red_nether_bricks
fill 330 294 503 330 297 503 minecraft:pink_terracotta
fill 331 294 464 331 294 465 minecraft:pink_terracotta
setblock 331 294 466 minecraft:red_nether_bricks
fill 331 294 467 331 296 467 minecraft:pink_terracotta
setblock 331 294 471 minecraft:red_nether_bricks
fill 331 294 472 331 296 472 minecraft:pink_terracotta
setblock 331 294 476 minecraft:red_nether_bricks
fill 331 294 477 331 297 477 minecraft:pink_terracotta
setblock 331 294 481 minecraft:red_nether_bricks
fill 331 294 492 331 295 492 minecraft:pink_terracotta
setblock 331 294 496 minecraft:red_nether_bricks
fill 331 294 497 332 296 497 minecraft:pink_terracotta
setblock 331 294 501 minecraft:red_nether_bricks
fill 331 294 502 331 297 502 minecraft:pink_terracotta
setblock 332 294 465 minecraft:red_nether_bricks
setblock 332 294 475 minecraft:red_nether_bricks
setblock 332 294 476 minecraft:pink_terracotta
setblock 332 294 495 minecraft:red_nether_bricks
fill 332 294 496 332 296 496 minecraft:pink_terracotta
setblock 332 294 500 minecraft:red_nether_bricks
fill 332 294 501 333 295 501 minecraft:pink_terracotta
setblock 333 294 464 minecraft:red_nether_bricks
setblock 333 294 465 minecraft:pink_terracotta
setblock 333 294 498 minecraft:pink_terracotta
setblock 333 294 499 minecraft:red_nether_bricks
fill 333 294 500 333 295 500 minecraft:pink_terracotta
setblock 333 294 504 minecraft:red_nether_bricks
fill 334 294 464 334 297 464 minecraft:pink_terracotta
setblock 334 294 503 minecraft:red_nether_bricks
fill 334 294 504 334 297 504 minecraft:pink_terracotta
setblock 335 294 502 minecraft:red_nether_bricks
fill 335 294 503 335 297 503 minecraft:pink_terracotta
fill 336 294 502 336 295 502 minecraft:pink_terracotta
setblock 337 294 464 minecraft:white_concrete
setblock 338 294 504 minecraft:red_nether_bricks
setblock 339 294 503 minecraft:red_nether_bricks
fill 339 294 504 342 294 504 minecraft:pink_terracotta
fill 340 294 503 343 294 503 minecraft:pink_terracotta
setblock 343 294 504 minecraft:red_nether_bricks
setblock 344 294 502 minecraft:pink_terracotta
setblock 344 294 503 minecraft:red_nether_bricks
fill 344 294 504 344 297 504 minecraft:pink_terracotta
setblock 345 294 502 minecraft:red_nether_bricks
fill 345 294 503 348 294 503 minecraft:pink_terracotta
fill 346 294 502 346 297 502 minecraft:pink_terracotta
setblock 347 294 464 minecraft:pink_terracotta
fill 347 294 501 349 295 501 minecraft:pink_terracotta
setblock 348 294 464 minecraft:red_nether_bricks
fill 348 294 502 349 294 502 minecraft:pink_terracotta
setblock 348 294 504 minecraft:red_nether_bricks
fill 349 294 464 349 297 464 minecraft:pink_terracotta
setblock 349 294 503 minecraft:red_nether_bricks
fill 349 294 504 349 297 504 minecraft:pink_terracotta
setblock 350 294 502 minecraft:red_nether_bricks
fill 350 294 503 350 297 503 minecraft:pink_terracotta
fill 351 294 502 351 296 502 minecraft:pink_terracotta
setblock 353 294 504 minecraft:red_nether_bricks
fill 354 294 504 354 296 504 minecraft:pink_terracotta
setblock 356 294 464 minecraft:white_concrete
setblock 363 294 504 minecraft:white_concrete
fill 364 294 464 364 297 464 minecraft:pink_terracotta
fill 365 294 504 367 294 504 minecraft:pink_terracotta
setblock 366 294 465 minecraft:pink_terracotta
setblock 366 294 490 minecraft:black_concrete
setblock 367 294 465 minecraft:red_nether_bricks
setblock 367 294 471 minecraft:pink_terracotta
setblock 367 294 474 minecraft:pink_terracotta
setblock 367 294 475 minecraft:red_nether_bricks
fill 367 294 476 367 297 476 minecraft:pink_terracotta
setblock 367 294 480 minecraft:red_nether_bricks
fill 367 294 503 368 294 503 minecraft:pink_terracotta
setblock 368 294 464 minecraft:red_nether_bricks
fill 368 294 465 368 297 465 minecraft:pink_terracotta
fill 368 294 467 368 294 468 minecraft:pink_terracotta
setblock 368 294 469 minecraft:red_nether_bricks
fill 368 294 470 368 297 470 minecraft:pink_terracotta
setblock 368 294 474 minecraft:red_nether_bricks
fill 368 294 475 368 297 475 minecraft:pink_terracotta
setblock 368 294 478 minecraft:pink_terracotta
setblock 368 294 479 minecraft:red_nether_bricks
fill 368 294 480 368 297 480 minecraft:pink_terracotta
fill 368 294 482 368 295 482 minecraft:pink_terracotta
fill 368 294 497 368 294 498 minecraft:pink_terracotta
setblock 368 294 499 minecraft:red_nether_bricks
fill 368 294 500 368 297 500 minecraft:pink_terracotta
setblock 368 294 504 minecraft:red_nether_bricks
fill 369 294 464 369 297 464 minecraft:pink_terracotta
setblock 369 294 468 minecraft:red_nether_bricks
fill 369 294 469 369 297 469 minecraft:pink_terracotta
setblock 369 294 473 minecraft:red_nether_bricks
fill 369 294 474 369 297 474 minecraft:pink_terracotta
setblock 369 294 478 minecraft:red_nether_bricks
fill 369 294 479 369 297 479 minecraft:pink_terracotta
setblock 369 294 483 minecraft:red_nether_bricks
fill 369 294 484 369 297 484 minecraft:pink_terracotta
setblock 369 294 492 minecraft:pink_terracotta
setblock 369 294 493 minecraft:red_nether_bricks
fill 369 294 494 369 295 494 minecraft:pink_terracotta
setblock 369 294 497 minecraft:pink_terracotta
setblock 369 294 498 minecraft:red_nether_bricks
fill 369 294 499 369 297 499 minecraft:pink_terracotta
setblock 369 294 503 minecraft:red_nether_bricks
fill 369 294 504 369 297 504 minecraft:pink_terracotta
setblock 370 294 467 minecraft:red_nether_bricks
fill 370 294 468 370 297 468 minecraft:pink_terracotta
setblock 370 294 472 minecraft:red_nether_bricks
fill 370 294 473 370 297 473 minecraft:pink_terracotta
setblock 370 294 477 minecraft:red_nether_bricks
fill 370 294 478 370 297 478 minecraft:pink_terracotta
setblock 370 294 482 minecraft:red_nether_bricks
fill 370 294 483 370 297 483 minecraft:pink_terracotta
setblock 370 294 487 minecraft:red_nether_bricks
fill 370 294 488 370 295 488 minecraft:pink_terracotta
setblock 370 294 492 minecraft:red_nether_bricks
fill 370 294 493 370 297 493 minecraft:pink_terracotta
setblock 370 294 497 minecraft:red_nether_bricks
fill 370 294 498 370 297 498 minecraft:pink_terracotta
setblock 370 294 502 minecraft:red_nether_bricks
fill 370 294 503 370 297 503 minecraft:pink_terracotta
fill 330 295 464 330 295 465 minecraft:pink_terracotta
setblock 330 295 466 minecraft:red_nether_bricks
fill 330 295 467 330 298 467 minecraft:pink_terracotta
setblock 330 295 471 minecraft:red_nether_bricks
fill 330 295 472 330 298 472 minecraft:pink_terracotta
setblock 330 295 476 minecraft:red_nether_bricks
fill 330 295 477 330 298 477 minecraft:pink_terracotta
setblock 330 295 480 minecraft:pink_terracotta
setblock 330 295 481 minecraft:red_nether_bricks
fill 330 295 482 330 298 482 minecraft:pink_terracotta
setblock 330 295 486 minecraft:red_nether_bricks
setblock 330 295 491 minecraft:red_nether_bricks
fill 330 295 492 330 295 495 minecraft:pink_terracotta
setblock 330 295 496 minecraft:red_nether_bricks
fill 330 295 497 330 298 497 minecraft:pink_terracotta
setblock 330 295 501 minecraft:red_nether_bricks
fill 330 295 502 330 298 502 minecraft:pink_terracotta
setblock 331 295 464 minecraft:pink_terracotta
setblock 331 295 465 minecraft:red_nether_bricks
fill 331 295 466 331 296 466 minecraft:pink_terracotta
setblock 331 295 470 minecraft:red_nether_bricks
fill 331 295 471 331 296 471 minecraft:pink_terracotta
setblock 331 295 475 minecraft:red_nether_bricks
fill 331 295 476 331 297 476 minecraft:pink_terracotta
setblock 331 295 480 minecraft:red_nether_bricks
fill 331 295 481 331 296 481 minecraft:pink_terracotta
setblock 331 295 495 minecraft:red_nether_bricks
fill 331 295 496 331 298 496 minecraft:pink_terracotta
setblock 331 295 500 minecraft:red_nether_bricks
fill 331 295 501 331 298 501 minecraft:pink_terracotta
setblock 332 295 464 minecraft:red_nether_bricks
setblock 332 295 465 minecraft:pink_terracotta
setblock 332 295 495 minecraft:pink_terracotta
setblock 332 295 499 minecraft:red_nether_bricks
fill 332 295 500 332 298 500 minecraft:pink_terracotta
setblock 332 295 504 minecraft:red_nether_bricks
fill 333 295 464 333 298 464 minecraft:pink_terracotta
setblock 333 295 498 minecraft:red_nether_bricks
setblock 333 295 499 minecraft:pink_terracotta
setblock 333 295 502 minecraft:pink_terracotta
setblock 333 295 503 minecraft:red_nether_bricks
fill 333 295 504 333 298 504 minecraft:pink_terracotta
setblock 334 295 502 minecraft:red_nether_bricks
fill 334 295 503 334 298 503 minecraft:pink_terracotta
fill 335 295 502 335 297 502 minecraft:pink_terracotta
setblock 337 295 504 minecraft:red_nether_bricks
setblock 338 295 503 minecraft:red_nether_bricks
fill 338 295 504 341 295 504 minecraft:pink_terracotta
fill 339 295 503 342 295 503 minecraft:pink_terracotta
fill 342 295 502 343 295 502 minecraft:pink_terracotta
setblock 342 295 504 minecraft:red_nether_bricks
setblock 343 295 503 minecraft:red_nether_bricks
fill 343 295 504 343 298 504 minecraft:pink_terracotta
setblock 344 295 502 minecraft:red_nether_bricks
fill 344 295 503 347 295 503 minecraft:pink_terracotta
setblock 345 295 501 minecraft:red_nether_bricks
fill 345 295 502 345 298 502 minecraft:pink_terracotta
fill 346 295 501 346 297 501 minecraft:pink_terracotta
setblock 347 295 464 minecraft:red_nether_bricks
setblock 347 295 504 minecraft:red_nether_bricks
fill 348 295 464 348 298 464 minecraft:pink_terracotta
setblock 348 295 502 minecraft:pink_terracotta
setblock 348 295 503 minecraft:red_nether_bricks
fill 348 295 504 348 298 504 minecraft:pink_terracotta
setblock 349 295 502 minecraft:red_nether_bricks
fill 349 295 503 349 298 503 minecraft:pink_terracotta
fill 350 295 502 350 297 502 minecraft:pink_terracotta
setblock 352 295 504 minecraft:red_nether_bricks
setblock 353 295 503 minecraft:red_nether_bricks
fill 353 295 504 353 297 504 minecraft:pink_terracotta
fill 364 295 504 366 295 504 minecraft:pink_terracotta
setblock 366 295 465 minecraft:red_nether_bricks
fill 366 295 503 367 295 503 minecraft:pink_terracotta
setblock 367 295 464 minecraft:red_nether_bricks
fill 367 295 465 367 298 465 minecraft:pink_terracotta
setblock 367 295 474 minecraft:red_nether_bricks
fill 367 295 475 367 297 475 minecraft:pink_terracotta
fill 367 295 477 367 295 478 minecraft:pink_terracotta
setblock 367 295 479 minecraft:red_nether_bricks
fill 367 295 480 367 297 480 minecraft:pink_terracotta
setblock 367 295 504 minecraft:red_nether_bricks
fill 368 295 464 368 298 464 minecraft:pink_terracotta
setblock 368 295 467 minecraft:pink_terracotta
setblock 368 295 468 minecraft:red_nether_bricks
fill 368 295 469 368 296 469 minecraft:pink_terracotta
setblock 368 295 473 minecraft:red_nether_bricks
fill 368 295 474 368 298 474 minecraft:pink_terracotta
setblock 368 295 478 minecraft:red_nether_bricks
fill 368 295 479 368 298 479 minecraft:pink_terracotta
setblock 368 295 497 minecraft:pink_terracotta
setblock 368 295 498 minecraft:red_nether_bricks
fill 368 295 499 368 297 499 minecraft:pink_terracotta
fill 368 295 501 368 295 502 minecraft:pink_terracotta
setblock 368 295 503 minecraft:red_nether_bricks
fill 368 295 504 368 298 504 minecraft:pink_terracotta
setblock 369 295 467 minecraft:red_nether_bricks
fill 369 295 468 369 298 468 minecraft:pink_terracotta
setblock 369 295 472 minecraft:red_nether_bricks
fill 369 295 473 369 298 473 minecraft:pink_terracotta
setblock 369 295 477 minecraft:red_nether_bricks
fill 369 295 478 369 298 478 minecraft:pink_terracotta
schedule function dropper:buildpart/115_9 1t
