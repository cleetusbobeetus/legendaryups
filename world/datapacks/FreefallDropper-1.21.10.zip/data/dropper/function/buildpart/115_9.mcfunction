setblock 369 295 482 minecraft:red_nether_bricks
fill 369 295 483 369 298 483 minecraft:pink_terracotta
setblock 369 295 492 minecraft:white_concrete
setblock 369 295 493 minecraft:pink_terracotta
setblock 369 295 497 minecraft:red_nether_bricks
fill 369 295 498 369 298 498 minecraft:pink_terracotta
setblock 369 295 501 minecraft:pink_terracotta
setblock 369 295 502 minecraft:red_nether_bricks
fill 369 295 503 369 298 503 minecraft:pink_terracotta
setblock 370 295 466 minecraft:red_nether_bricks
fill 370 295 467 370 298 467 minecraft:pink_terracotta
setblock 370 295 471 minecraft:red_nether_bricks
fill 370 295 472 370 298 472 minecraft:pink_terracotta
setblock 370 295 476 minecraft:red_nether_bricks
fill 370 295 477 370 298 477 minecraft:pink_terracotta
setblock 370 295 481 minecraft:red_nether_bricks
fill 370 295 482 370 298 482 minecraft:pink_terracotta
setblock 370 295 486 minecraft:red_nether_bricks
fill 370 295 487 370 296 487 minecraft:pink_terracotta
setblock 370 295 491 minecraft:red_nether_bricks
fill 370 295 492 370 296 492 minecraft:pink_terracotta
setblock 370 295 496 minecraft:red_nether_bricks
fill 370 295 497 370 298 497 minecraft:pink_terracotta
setblock 370 295 501 minecraft:red_nether_bricks
fill 370 295 502 370 298 502 minecraft:pink_terracotta
setblock 330 296 464 minecraft:pink_terracotta
setblock 330 296 465 minecraft:red_nether_bricks
fill 330 296 466 330 299 466 minecraft:pink_terracotta
setblock 330 296 470 minecraft:red_nether_bricks
fill 330 296 471 330 298 471 minecraft:pink_terracotta
setblock 330 296 475 minecraft:red_nether_bricks
fill 330 296 476 330 299 476 minecraft:pink_terracotta
setblock 330 296 480 minecraft:red_nether_bricks
fill 330 296 481 330 299 481 minecraft:pink_terracotta
setblock 330 296 484 minecraft:pink_terracotta
setblock 330 296 485 minecraft:red_nether_bricks
fill 330 296 486 330 297 486 minecraft:white_concrete
setblock 330 296 490 minecraft:red_nether_bricks
fill 330 296 491 330 296 494 minecraft:pink_terracotta
setblock 330 296 495 minecraft:red_nether_bricks
fill 330 296 496 330 299 496 minecraft:pink_terracotta
setblock 330 296 500 minecraft:red_nether_bricks
fill 330 296 501 330 299 501 minecraft:pink_terracotta
setblock 331 296 464 minecraft:red_nether_bricks
fill 331 296 465 331 297 465 minecraft:pink_terracotta
setblock 331 296 470 minecraft:pink_terracotta
setblock 331 296 474 minecraft:red_nether_bricks
fill 331 296 475 331 297 475 minecraft:pink_terracotta
setblock 331 296 479 minecraft:red_nether_bricks
fill 331 296 480 331 297 480 minecraft:pink_terracotta
setblock 331 296 494 minecraft:red_nether_bricks
fill 331 296 495 331 297 495 minecraft:pink_terracotta
setblock 331 296 499 minecraft:red_nether_bricks
fill 331 296 500 331 299 500 minecraft:pink_terracotta
setblock 331 296 504 minecraft:red_nether_bricks
fill 332 296 464 332 299 464 minecraft:pink_terracotta
setblock 332 296 498 minecraft:red_nether_bricks
fill 332 296 499 332 298 499 minecraft:pink_terracotta
fill 332 296 501 332 297 501 minecraft:pink_terracotta
setblock 332 296 503 minecraft:red_nether_bricks
fill 332 296 504 332 299 504 minecraft:pink_terracotta
setblock 333 296 502 minecraft:red_nether_bricks
fill 333 296 503 333 299 503 minecraft:pink_terracotta
fill 334 296 502 334 298 502 minecraft:pink_terracotta
setblock 336 296 504 minecraft:red_nether_bricks
setblock 337 296 503 minecraft:red_nether_bricks
fill 337 296 504 340 296 504 minecraft:pink_terracotta
fill 338 296 503 341 296 503 minecraft:pink_terracotta
setblock 341 296 504 minecraft:red_nether_bricks
setblock 342 296 502 minecraft:pink_terracotta
setblock 342 296 503 minecraft:red_nether_bricks
fill 342 296 504 342 299 504 minecraft:pink_terracotta
setblock 343 296 502 minecraft:red_nether_bricks
fill 343 296 503 346 296 503 minecraft:pink_terracotta
setblock 344 296 464 minecraft:white_concrete
fill 344 296 502 344 299 502 minecraft:pink_terracotta
fill 345 296 501 345 297 501 minecraft:pink_terracotta
setblock 346 296 464 minecraft:red_nether_bricks
setblock 346 296 504 minecraft:red_nether_bricks
fill 347 296 464 347 299 464 minecraft:pink_terracotta
fill 347 296 501 348 296 501 minecraft:pink_terracotta
setblock 347 296 503 minecraft:red_nether_bricks
fill 347 296 504 347 299 504 minecraft:pink_terracotta
setblock 348 296 502 minecraft:red_nether_bricks
fill 348 296 503 348 299 503 minecraft:pink_terracotta
setblock 349 296 501 minecraft:red_nether_bricks
fill 349 296 502 349 298 502 minecraft:pink_terracotta
setblock 351 296 504 minecraft:red_nether_bricks
setblock 352 296 503 minecraft:red_nether_bricks
fill 352 296 504 352 299 504 minecraft:pink_terracotta
setblock 356 296 504 minecraft:white_concrete
fill 363 296 464 363 298 464 minecraft:pink_terracotta
fill 363 296 504 365 296 504 minecraft:pink_terracotta
setblock 365 296 465 minecraft:red_nether_bricks
fill 365 296 503 366 296 503 minecraft:pink_terracotta
setblock 366 296 464 minecraft:red_nether_bricks
fill 366 296 465 366 299 465 minecraft:pink_terracotta
setblock 366 296 504 minecraft:red_nether_bricks
fill 367 296 464 367 299 464 minecraft:pink_terracotta
setblock 367 296 473 minecraft:red_nether_bricks
fill 367 296 474 367 297 474 minecraft:pink_terracotta
setblock 367 296 477 minecraft:pink_terracotta
setblock 367 296 478 minecraft:red_nether_bricks
fill 367 296 479 367 298 479 minecraft:pink_terracotta
setblock 367 296 502 minecraft:pink_terracotta
setblock 367 296 503 minecraft:red_nether_bricks
fill 367 296 504 367 299 504 minecraft:pink_terracotta
setblock 368 296 468 minecraft:pink_terracotta
setblock 368 296 472 minecraft:red_nether_bricks
fill 368 296 473 368 298 473 minecraft:pink_terracotta
setblock 368 296 477 minecraft:red_nether_bricks
fill 368 296 478 368 299 478 minecraft:pink_terracotta
setblock 368 296 482 minecraft:red_nether_bricks
setblock 368 296 498 minecraft:pink_terracotta
setblock 368 296 501 minecraft:pink_terracotta
setblock 368 296 502 minecraft:red_nether_bricks
fill 368 296 503 368 299 503 minecraft:pink_terracotta
setblock 369 296 466 minecraft:red_nether_bricks
fill 369 296 467 369 299 467 minecraft:pink_terracotta
setblock 369 296 471 minecraft:red_nether_bricks
fill 369 296 472 369 299 472 minecraft:pink_terracotta
setblock 369 296 476 minecraft:red_nether_bricks
fill 369 296 477 369 299 477 minecraft:pink_terracotta
setblock 369 296 481 minecraft:red_nether_bricks
fill 369 296 482 369 299 482 minecraft:pink_terracotta
setblock 369 296 496 minecraft:red_nether_bricks
fill 369 296 497 369 298 497 minecraft:pink_terracotta
setblock 369 296 501 minecraft:red_nether_bricks
fill 369 296 502 369 299 502 minecraft:pink_terracotta
setblock 370 296 465 minecraft:red_nether_bricks
fill 370 296 466 370 299 466 minecraft:pink_terracotta
setblock 370 296 470 minecraft:red_nether_bricks
fill 370 296 471 370 299 471 minecraft:pink_terracotta
setblock 370 296 475 minecraft:red_nether_bricks
fill 370 296 476 370 299 476 minecraft:pink_terracotta
setblock 370 296 480 minecraft:red_nether_bricks
fill 370 296 481 370 299 481 minecraft:pink_terracotta
setblock 370 296 485 minecraft:red_nether_bricks
fill 370 296 486 370 297 486 minecraft:pink_terracotta
setblock 370 296 491 minecraft:pink_terracotta
setblock 370 296 495 minecraft:red_nether_bricks
fill 370 296 496 370 299 496 minecraft:pink_terracotta
setblock 370 296 500 minecraft:red_nether_bricks
fill 370 296 501 370 299 501 minecraft:pink_terracotta
setblock 330 297 464 minecraft:red_nether_bricks
fill 330 297 465 330 300 465 minecraft:pink_terracotta
setblock 330 297 469 minecraft:red_nether_bricks
fill 330 297 470 330 298 470 minecraft:pink_terracotta
setblock 330 297 474 minecraft:red_nether_bricks
fill 330 297 475 330 299 475 minecraft:pink_terracotta
setblock 330 297 479 minecraft:red_nether_bricks
fill 330 297 480 330 300 480 minecraft:pink_terracotta
setblock 330 297 484 minecraft:red_nether_bricks
setblock 330 297 485 minecraft:pink_terracotta
fill 330 297 491 330 297 493 minecraft:pink_terracotta
setblock 330 297 494 minecraft:red_nether_bricks
fill 330 297 495 330 300 495 minecraft:pink_terracotta
setblock 330 297 499 minecraft:red_nether_bricks
fill 330 297 500 330 300 500 minecraft:pink_terracotta
setblock 330 297 504 minecraft:red_nether_bricks
fill 331 297 464 331 300 464 minecraft:pink_terracotta
setblock 331 297 474 minecraft:pink_terracotta
setblock 331 297 478 minecraft:red_nether_bricks
setblock 331 297 479 minecraft:pink_terracotta
setblock 331 297 494 minecraft:pink_terracotta
setblock 331 297 497 minecraft:pink_terracotta
setblock 331 297 498 minecraft:red_nether_bricks
fill 331 297 499 331 300 499 minecraft:pink_terracotta
setblock 331 297 503 minecraft:red_nether_bricks
fill 331 297 504 331 300 504 minecraft:pink_terracotta
setblock 332 297 466 minecraft:light[level=12]
setblock 332 297 474 minecraft:light[level=12]
setblock 332 297 482 minecraft:light[level=12]
setblock 332 297 490 minecraft:light[level=12]
setblock 332 297 497 minecraft:red_nether_bricks
fill 332 297 498 332 298 498 minecraft:pink_terracotta
setblock 332 297 502 minecraft:red_nether_bricks
fill 332 297 503 332 300 503 minecraft:pink_terracotta
fill 333 297 502 333 298 502 minecraft:pink_terracotta
setblock 335 297 504 minecraft:red_nether_bricks
setblock 336 297 503 minecraft:red_nether_bricks
fill 336 297 504 339 297 504 minecraft:pink_terracotta
fill 337 297 503 340 297 503 minecraft:pink_terracotta
setblock 338 297 464 minecraft:white_concrete
setblock 340 297 466 minecraft:light[level=12]
setblock 340 297 474 minecraft:light[level=12]
setblock 340 297 482 minecraft:light[level=12]
setblock 340 297 490 minecraft:light[level=12]
setblock 340 297 498 minecraft:light[level=12]
setblock 340 297 504 minecraft:red_nether_bricks
setblock 341 297 503 minecraft:red_nether_bricks
fill 341 297 504 341 300 504 minecraft:pink_terracotta
setblock 342 297 502 minecraft:red_nether_bricks
fill 342 297 503 345 297 503 minecraft:pink_terracotta
fill 343 297 502 343 300 502 minecraft:pink_terracotta
setblock 345 297 504 minecraft:red_nether_bricks
fill 346 297 464 346 300 464 minecraft:pink_terracotta
setblock 346 297 503 minecraft:red_nether_bricks
fill 346 297 504 346 300 504 minecraft:pink_terracotta
setblock 347 297 501 minecraft:pink_terracotta
setblock 347 297 502 minecraft:red_nether_bricks
fill 347 297 503 347 300 503 minecraft:pink_terracotta
setblock 348 297 466 minecraft:light[level=12]
setblock 348 297 474 minecraft:light[level=12]
setblock 348 297 482 minecraft:light[level=12]
setblock 348 297 490 minecraft:light[level=12]
setblock 348 297 498 minecraft:light[level=12]
fill 348 297 502 348 299 502 minecraft:pink_terracotta
setblock 350 297 504 minecraft:red_nether_bricks
setblock 351 297 503 minecraft:red_nether_bricks
fill 351 297 504 351 300 504 minecraft:pink_terracotta
fill 355 297 478 355 297 481 minecraft:white_concrete
setblock 356 297 466 minecraft:light[level=12]
setblock 356 297 474 minecraft:light[level=12]
fill 356 297 478 358 297 478 minecraft:white_concrete
fill 356 297 481 358 298 481 minecraft:white_concrete
setblock 356 297 482 minecraft:light[level=12]
setblock 356 297 490 minecraft:light[level=12]
setblock 356 297 498 minecraft:light[level=12]
fill 358 297 479 359 297 480 minecraft:white_concrete
fill 359 297 484 359 298 486 minecraft:white_concrete
fill 360 297 483 361 297 483 minecraft:white_concrete
fill 360 297 487 361 297 487 minecraft:white_concrete
fill 362 297 464 362 299 464 minecraft:pink_terracotta
fill 362 297 484 362 297 486 minecraft:white_concrete
fill 362 297 504 364 297 504 minecraft:pink_terracotta
setblock 364 297 466 minecraft:light[level=12]
setblock 364 297 474 minecraft:light[level=12]
setblock 364 297 482 minecraft:light[level=12]
setblock 364 297 490 minecraft:light[level=12]
setblock 364 297 498 minecraft:light[level=12]
fill 364 297 503 365 297 503 minecraft:pink_terracotta
setblock 365 297 464 minecraft:red_nether_bricks
fill 365 297 465 365 300 465 minecraft:pink_terracotta
setblock 365 297 504 minecraft:red_nether_bricks
fill 366 297 464 366 300 464 minecraft:pink_terracotta
setblock 366 297 503 minecraft:red_nether_bricks
fill 366 297 504 366 300 504 minecraft:pink_terracotta
setblock 367 297 477 minecraft:red_nether_bricks
fill 367 297 478 367 298 478 minecraft:pink_terracotta
setblock 367 297 502 minecraft:red_nether_bricks
fill 367 297 503 367 300 503 minecraft:pink_terracotta
setblock 368 297 471 minecraft:red_nether_bricks
fill 368 297 472 368 298 472 minecraft:pink_terracotta
setblock 368 297 476 minecraft:red_nether_bricks
fill 368 297 477 368 299 477 minecraft:pink_terracotta
setblock 368 297 481 minecraft:red_nether_bricks
fill 368 297 482 368 298 482 minecraft:pink_terracotta
setblock 368 297 501 minecraft:red_nether_bricks
fill 368 297 502 368 300 502 minecraft:pink_terracotta
setblock 369 297 465 minecraft:red_nether_bricks
fill 369 297 466 369 300 466 minecraft:pink_terracotta
setblock 369 297 470 minecraft:red_nether_bricks
fill 369 297 471 369 299 471 minecraft:pink_terracotta
setblock 369 297 475 minecraft:red_nether_bricks
fill 369 297 476 369 300 476 minecraft:pink_terracotta
setblock 369 297 480 minecraft:red_nether_bricks
fill 369 297 481 369 300 481 minecraft:pink_terracotta
setblock 369 297 496 minecraft:pink_terracotta
setblock 369 297 500 minecraft:red_nether_bricks
fill 369 297 501 369 300 501 minecraft:pink_terracotta
setblock 370 297 464 minecraft:red_nether_bricks
fill 370 297 465 370 300 465 minecraft:pink_terracotta
setblock 370 297 469 minecraft:red_nether_bricks
fill 370 297 470 370 300 470 minecraft:pink_terracotta
setblock 370 297 474 minecraft:red_nether_bricks
fill 370 297 475 370 300 475 minecraft:pink_terracotta
setblock 370 297 479 minecraft:red_nether_bricks
fill 370 297 480 370 300 480 minecraft:pink_terracotta
setblock 370 297 484 minecraft:red_nether_bricks
fill 370 297 485 370 299 485 minecraft:pink_terracotta
setblock 370 297 494 minecraft:red_nether_bricks
fill 370 297 495 370 298 495 minecraft:pink_terracotta
setblock 370 297 499 minecraft:red_nether_bricks
fill 370 297 500 370 300 500 minecraft:pink_terracotta
setblock 370 297 504 minecraft:red_nether_bricks
fill 330 298 464 330 300 464 minecraft:pink_terracotta
setblock 330 298 468 minecraft:red_nether_bricks
setblock 330 298 469 minecraft:pink_terracotta
setblock 330 298 473 minecraft:red_nether_bricks
fill 330 298 474 330 299 474 minecraft:pink_terracotta
setblock 330 298 478 minecraft:red_nether_bricks
fill 330 298 479 330 300 479 minecraft:pink_terracotta
setblock 330 298 483 minecraft:red_nether_bricks
fill 330 298 484 330 300 484 minecraft:pink_terracotta
setblock 330 298 493 minecraft:red_nether_bricks
fill 330 298 494 330 299 494 minecraft:pink_terracotta
setblock 330 298 498 minecraft:red_nether_bricks
fill 330 298 499 330 300 499 minecraft:pink_terracotta
setblock 330 298 503 minecraft:red_nether_bricks
fill 330 298 504 330 300 504 minecraft:pink_terracotta
setblock 331 298 497 minecraft:red_nether_bricks
fill 331 298 498 331 300 498 minecraft:pink_terracotta
setblock 331 298 502 minecraft:red_nether_bricks
fill 331 298 503 331 300 503 minecraft:pink_terracotta
setblock 332 298 501 minecraft:red_nether_bricks
fill 332 298 502 332 299 502 minecraft:pink_terracotta
setblock 334 298 504 minecraft:red_nether_bricks
setblock 335 298 503 minecraft:red_nether_bricks
fill 335 298 504 338 298 504 minecraft:pink_terracotta
fill 336 298 503 339 298 503 minecraft:pink_terracotta
setblock 339 298 504 minecraft:red_nether_bricks
setblock 340 298 503 minecraft:red_nether_bricks
fill 340 298 504 340 300 504 minecraft:pink_terracotta
fill 341 298 503 344 298 503 minecraft:pink_terracotta
fill 342 298 502 342 300 502 minecraft:pink_terracotta
setblock 344 298 504 minecraft:red_nether_bricks
fill 345 298 464 345 300 464 minecraft:pink_terracotta
setblock 345 298 503 minecraft:red_nether_bricks
fill 345 298 504 345 300 504 minecraft:pink_terracotta
setblock 346 298 502 minecraft:red_nether_bricks
fill 346 298 503 346 300 503 minecraft:pink_terracotta
fill 347 298 502 347 300 502 minecraft:pink_terracotta
setblock 349 298 464 minecraft:red_nether_bricks
setblock 349 298 504 minecraft:red_nether_bricks
setblock 350 298 503 minecraft:red_nether_bricks
fill 350 298 504 350 300 504 minecraft:pink_terracotta
setblock 351 298 503 minecraft:pink_terracotta
fill 355 298 479 355 298 480 minecraft:white_concrete
fill 356 298 478 357 298 478 minecraft:white_concrete
setblock 357 298 464 minecraft:white_concrete
fill 358 298 479 358 299 480 minecraft:white_concrete
fill 362 298 484 362 298 485 minecraft:white_concrete
fill 362 298 504 363 298 504 minecraft:pink_terracotta
setblock 364 298 464 minecraft:red_nether_bricks
fill 364 298 465 364 300 465 minecraft:pink_terracotta
setblock 364 298 503 minecraft:pink_terracotta
setblock 364 298 504 minecraft:red_nether_bricks
fill 365 298 464 365 300 464 minecraft:pink_terracotta
setblock 365 298 503 minecraft:red_nether_bricks
fill 365 298 504 365 300 504 minecraft:pink_terracotta
fill 366 298 503 366 300 503 minecraft:pink_terracotta
setblock 367 298 476 minecraft:red_nether_bricks
setblock 367 298 477 minecraft:pink_terracotta
fill 367 298 502 367 299 502 minecraft:pink_terracotta
setblock 368 298 465 minecraft:red_nether_bricks
setblock 368 298 475 minecraft:red_nether_bricks
fill 368 298 476 368 299 476 minecraft:pink_terracotta
setblock 368 298 480 minecraft:red_nether_bricks
fill 368 298 481 368 299 481 minecraft:pink_terracotta
setblock 368 298 500 minecraft:red_nether_bricks
fill 368 298 501 368 299 501 minecraft:pink_terracotta
setblock 369 298 464 minecraft:red_nether_bricks
fill 369 298 465 369 300 465 minecraft:pink_terracotta
setblock 369 298 469 minecraft:red_nether_bricks
fill 369 298 470 369 299 470 minecraft:pink_terracotta
setblock 369 298 474 minecraft:red_nether_bricks
fill 369 298 475 369 300 475 minecraft:pink_terracotta
setblock 369 298 479 minecraft:red_nether_bricks
fill 369 298 480 369 300 480 minecraft:pink_terracotta
setblock 369 298 484 minecraft:red_nether_bricks
setblock 369 298 499 minecraft:red_nether_bricks
fill 369 298 500 369 300 500 minecraft:pink_terracotta
setblock 369 298 504 minecraft:red_nether_bricks
fill 370 298 464 370 300 464 minecraft:pink_terracotta
setblock 370 298 468 minecraft:red_nether_bricks
fill 370 298 469 370 300 469 minecraft:pink_terracotta
setblock 370 298 473 minecraft:red_nether_bricks
fill 370 298 474 370 300 474 minecraft:pink_terracotta
setblock 370 298 478 minecraft:red_nether_bricks
fill 370 298 479 370 300 479 minecraft:pink_terracotta
setblock 370 298 483 minecraft:red_nether_bricks
fill 370 298 484 370 300 484 minecraft:pink_terracotta
setblock 370 298 498 minecraft:red_nether_bricks
fill 370 298 499 370 300 499 minecraft:pink_terracotta
setblock 370 298 503 minecraft:red_nether_bricks
fill 370 298 504 370 300 504 minecraft:pink_terracotta
setblock 330 299 467 minecraft:red_nether_bricks
setblock 330 299 477 minecraft:red_nether_bricks
fill 330 299 478 330 300 478 minecraft:pink_terracotta
setblock 330 299 482 minecraft:red_nether_bricks
fill 330 299 483 330 300 483 minecraft:pink_terracotta
setblock 330 299 497 minecraft:red_nether_bricks
fill 330 299 498 330 300 498 minecraft:pink_terracotta
setblock 330 299 502 minecraft:red_nether_bricks
fill 330 299 503 330 300 503 minecraft:pink_terracotta
setblock 331 299 497 minecraft:pink_terracotta
setblock 331 299 501 minecraft:red_nether_bricks
fill 331 299 502 331 300 502 minecraft:pink_terracotta
setblock 332 299 500 minecraft:red_nether_bricks
setblock 332 299 501 minecraft:pink_terracotta
setblock 333 299 464 minecraft:red_nether_bricks
setblock 333 299 504 minecraft:red_nether_bricks
setblock 334 299 503 minecraft:red_nether_bricks
fill 334 299 504 337 299 504 minecraft:pink_terracotta
fill 335 299 503 338 299 503 minecraft:pink_terracotta
setblock 338 299 504 minecraft:red_nether_bricks
setblock 339 299 503 minecraft:red_nether_bricks
fill 339 299 504 339 300 504 minecraft:pink_terracotta
fill 340 299 503 343 299 503 minecraft:pink_terracotta
setblock 343 299 504 minecraft:red_nether_bricks
setblock 344 299 503 minecraft:red_nether_bricks
fill 344 299 504 344 300 504 minecraft:pink_terracotta
setblock 345 299 502 minecraft:red_nether_bricks
fill 345 299 503 345 300 503 minecraft:pink_terracotta
fill 346 299 502 346 300 502 minecraft:pink_terracotta
setblock 348 299 464 minecraft:red_nether_bricks
setblock 348 299 504 minecraft:red_nether_bricks
setblock 349 299 503 minecraft:red_nether_bricks
fill 349 299 504 349 300 504 minecraft:pink_terracotta
setblock 350 299 503 minecraft:pink_terracotta
setblock 351 299 464 minecraft:white_concrete
fill 356 299 481 357 299 481 minecraft:white_concrete
setblock 357 299 478 minecraft:white_concrete
setblock 359 299 485 minecraft:white_concrete
fill 361 299 464 361 300 464 minecraft:pink_terracotta
fill 361 299 504 362 299 504 minecraft:pink_terracotta
setblock 363 299 464 minecraft:red_nether_bricks
setblock 363 299 504 minecraft:red_nether_bricks
fill 364 299 464 364 300 464 minecraft:pink_terracotta
setblock 364 299 503 minecraft:red_nether_bricks
fill 364 299 504 364 300 504 minecraft:pink_terracotta
fill 365 299 503 365 300 503 minecraft:pink_terracotta
setblock 367 299 465 minecraft:red_nether_bricks
setblock 368 299 464 minecraft:red_nether_bricks
fill 368 299 465 368 300 465 minecraft:pink_terracotta
setblock 368 299 475 minecraft:pink_terracotta
setblock 368 299 479 minecraft:red_nether_bricks
fill 368 299 480 368 300 480 minecraft:pink_terracotta
setblock 368 299 504 minecraft:red_nether_bricks
fill 369 299 464 369 300 464 minecraft:pink_terracotta
setblock 369 299 468 minecraft:red_nether_bricks
setblock 369 299 469 minecraft:pink_terracotta
setblock 369 299 473 minecraft:red_nether_bricks
fill 369 299 474 369 300 474 minecraft:pink_terracotta
setblock 369 299 478 minecraft:red_nether_bricks
fill 369 299 479 369 300 479 minecraft:pink_terracotta
setblock 369 299 483 minecraft:red_nether_bricks
setblock 369 299 498 minecraft:red_nether_bricks
fill 369 299 499 369 300 499 minecraft:pink_terracotta
setblock 369 299 503 minecraft:red_nether_bricks
fill 369 299 504 369 300 504 minecraft:pink_terracotta
setblock 370 299 467 minecraft:red_nether_bricks
fill 370 299 468 370 300 468 minecraft:pink_terracotta
setblock 370 299 472 minecraft:red_nether_bricks
fill 370 299 473 370 300 473 minecraft:pink_terracotta
setblock 370 299 477 minecraft:red_nether_bricks
fill 370 299 478 370 300 478 minecraft:pink_terracotta
setblock 370 299 482 minecraft:red_nether_bricks
fill 370 299 483 370 300 483 minecraft:pink_terracotta
setblock 370 299 489 minecraft:white_concrete
setblock 370 299 497 minecraft:red_nether_bricks
fill 370 299 498 370 300 498 minecraft:pink_terracotta
setblock 370 299 502 minecraft:red_nether_bricks
fill 370 299 503 370 300 503 minecraft:pink_terracotta
setblock 330 300 466 minecraft:red_nether_bricks
setblock 330 300 477 minecraft:pink_terracotta
setblock 330 300 481 minecraft:red_nether_bricks
setblock 330 300 482 minecraft:pink_terracotta
setblock 330 300 485 minecraft:white_concrete
setblock 330 300 496 minecraft:red_nether_bricks
setblock 330 300 497 minecraft:pink_terracotta
setblock 330 300 501 minecraft:red_nether_bricks
setblock 330 300 502 minecraft:pink_terracotta
setblock 331 300 500 minecraft:red_nether_bricks
setblock 331 300 501 minecraft:pink_terracotta
setblock 332 300 464 minecraft:red_nether_bricks
setblock 332 300 504 minecraft:red_nether_bricks
setblock 333 300 503 minecraft:red_nether_bricks
fill 333 300 504 336 300 504 minecraft:pink_terracotta
fill 334 300 503 337 300 503 minecraft:pink_terracotta
setblock 337 300 504 minecraft:red_nether_bricks
setblock 338 300 503 minecraft:red_nether_bricks
setblock 338 300 504 minecraft:pink_terracotta
fill 339 300 503 342 300 503 minecraft:pink_terracotta
setblock 342 300 504 minecraft:red_nether_bricks
setblock 343 300 503 minecraft:red_nether_bricks
setblock 343 300 504 minecraft:pink_terracotta
setblock 344 300 464 minecraft:pink_terracotta
setblock 344 300 502 minecraft:red_nether_bricks
setblock 344 300 503 minecraft:pink_terracotta
setblock 345 300 502 minecraft:pink_terracotta
setblock 347 300 464 minecraft:red_nether_bricks
setblock 347 300 504 minecraft:red_nether_bricks
setblock 348 300 464 minecraft:pink_terracotta
setblock 348 300 503 minecraft:red_nether_bricks
setblock 348 300 504 minecraft:pink_terracotta
setblock 349 300 503 minecraft:pink_terracotta
setblock 355 300 504 minecraft:white_concrete
setblock 361 300 504 minecraft:pink_terracotta
setblock 362 300 464 minecraft:red_nether_bricks
setblock 362 300 504 minecraft:red_nether_bricks
fill 363 300 464 363 300 465 minecraft:pink_terracotta
setblock 363 300 503 minecraft:red_nether_bricks
setblock 363 300 504 minecraft:pink_terracotta
setblock 364 300 503 minecraft:pink_terracotta
setblock 366 300 465 minecraft:red_nether_bricks
setblock 367 300 464 minecraft:red_nether_bricks
setblock 367 300 465 minecraft:pink_terracotta
setblock 367 300 504 minecraft:red_nether_bricks
setblock 368 300 464 minecraft:pink_terracotta
setblock 368 300 478 minecraft:red_nether_bricks
setblock 368 300 479 minecraft:pink_terracotta
setblock 368 300 503 minecraft:red_nether_bricks
setblock 368 300 504 minecraft:pink_terracotta
setblock 369 300 467 minecraft:red_nether_bricks
setblock 369 300 477 minecraft:red_nether_bricks
setblock 369 300 478 minecraft:pink_terracotta
setblock 369 300 482 minecraft:red_nether_bricks
setblock 369 300 483 minecraft:pink_terracotta
setblock 369 300 502 minecraft:red_nether_bricks
setblock 369 300 503 minecraft:pink_terracotta
setblock 370 300 466 minecraft:red_nether_bricks
setblock 370 300 467 minecraft:pink_terracotta
setblock 370 300 471 minecraft:red_nether_bricks
setblock 370 300 472 minecraft:pink_terracotta
setblock 370 300 476 minecraft:red_nether_bricks
setblock 370 300 477 minecraft:pink_terracotta
setblock 370 300 481 minecraft:red_nether_bricks
setblock 370 300 482 minecraft:pink_terracotta
setblock 370 300 497 minecraft:pink_terracotta
setblock 370 300 501 minecraft:red_nether_bricks
setblock 370 300 502 minecraft:pink_terracotta
