setblock 158 234 278 minecraft:light[level=12]
setblock 158 234 285 minecraft:light[level=12]
setblock 158 234 299 minecraft:light[level=12]
setblock 158 234 306 minecraft:light[level=12]
setblock 158 234 313 minecraft:light[level=12]
setblock 159 234 277 minecraft:snow_block
setblock 160 234 276 minecraft:snow_block
fill 160 234 277 163 234 277 minecraft:packed_ice
setblock 160 234 316 minecraft:snow_block
fill 161 234 276 161 237 276 minecraft:packed_ice
setblock 161 234 315 minecraft:snow_block
fill 161 234 316 161 237 316 minecraft:packed_ice
setblock 162 234 275 minecraft:light_blue_concrete
setblock 162 234 278 minecraft:packed_ice
setblock 162 234 314 minecraft:snow_block
fill 162 234 315 162 237 315 minecraft:packed_ice
setblock 163 234 278 minecraft:snow_block
fill 163 234 314 163 236 314 minecraft:packed_ice
setblock 164 234 277 minecraft:snow_block
fill 164 234 278 165 235 278 minecraft:packed_ice
setblock 165 234 276 minecraft:snow_block
fill 165 234 277 165 237 277 minecraft:packed_ice
setblock 165 234 285 minecraft:light[level=12]
setblock 165 234 292 minecraft:light[level=12]
setblock 165 234 299 minecraft:light[level=12]
setblock 165 234 306 minecraft:light[level=12]
setblock 165 234 313 minecraft:light[level=12]
setblock 165 234 316 minecraft:snow_block
fill 166 234 276 166 237 276 minecraft:packed_ice
setblock 166 234 315 minecraft:snow_block
fill 166 234 316 166 237 316 minecraft:packed_ice
setblock 167 234 314 minecraft:snow_block
fill 167 234 315 167 236 315 minecraft:packed_ice
fill 168 234 317 168 237 317 minecraft:packed_ice
setblock 169 234 277 minecraft:snow_block
setblock 170 234 276 minecraft:snow_block
setblock 170 234 316 minecraft:snow_block
fill 171 234 276 171 236 276 minecraft:packed_ice
fill 171 234 316 171 235 316 minecraft:packed_ice
setblock 172 234 285 minecraft:light[level=12]
setblock 172 234 292 minecraft:light[level=12]
setblock 172 234 299 minecraft:light[level=12]
setblock 172 234 306 minecraft:light[level=12]
setblock 172 234 313 minecraft:light[level=12]
setblock 173 234 317 minecraft:snow_block
setblock 174 234 276 minecraft:packed_ice
fill 174 234 287 174 243 287 minecraft:packed_ice
setblock 175 234 276 minecraft:snow_block
fill 176 234 276 176 237 276 minecraft:packed_ice
setblock 178 234 277 minecraft:packed_ice
setblock 179 234 277 minecraft:snow_block
setblock 179 234 278 minecraft:light[level=12]
setblock 179 234 285 minecraft:light[level=12]
setblock 179 234 292 minecraft:light[level=12]
setblock 179 234 299 minecraft:light[level=12]
setblock 179 234 306 minecraft:light[level=12]
setblock 179 234 313 minecraft:light[level=12]
setblock 180 234 276 minecraft:snow_block
fill 180 234 277 180 234 280 minecraft:packed_ice
setblock 180 234 291 minecraft:snow_block
fill 180 234 292 180 235 292 minecraft:packed_ice
setblock 180 234 295 minecraft:packed_ice
setblock 180 234 296 minecraft:snow_block
fill 180 234 297 180 237 297 minecraft:packed_ice
setblock 180 234 301 minecraft:snow_block
setblock 180 234 316 minecraft:snow_block
fill 181 234 276 181 234 279 minecraft:packed_ice
setblock 181 234 280 minecraft:snow_block
fill 181 234 281 181 234 284 minecraft:packed_ice
setblock 181 234 285 minecraft:snow_block
fill 181 234 286 181 237 286 minecraft:packed_ice
setblock 181 234 290 minecraft:snow_block
fill 181 234 291 181 237 291 minecraft:packed_ice
setblock 181 234 295 minecraft:snow_block
fill 181 234 296 181 237 296 minecraft:packed_ice
setblock 181 234 299 minecraft:packed_ice
setblock 181 234 300 minecraft:snow_block
fill 181 234 301 181 237 301 minecraft:packed_ice
fill 181 234 316 181 237 316 minecraft:packed_ice
fill 182 234 276 182 234 278 minecraft:packed_ice
setblock 182 234 279 minecraft:snow_block
fill 182 234 280 182 237 280 minecraft:packed_ice
setblock 182 234 284 minecraft:snow_block
fill 182 234 285 182 237 285 minecraft:packed_ice
setblock 182 234 289 minecraft:snow_block
fill 182 234 290 182 237 290 minecraft:packed_ice
setblock 182 234 294 minecraft:snow_block
fill 182 234 295 182 237 295 minecraft:packed_ice
setblock 182 234 299 minecraft:snow_block
fill 182 234 300 182 237 300 minecraft:packed_ice
setblock 182 234 304 minecraft:snow_block
fill 182 234 305 182 237 305 minecraft:packed_ice
fill 182 234 307 182 235 307 minecraft:packed_ice
setblock 182 234 311 minecraft:packed_ice
fill 182 234 314 183 234 314 minecraft:snow_block
fill 182 234 315 182 237 315 minecraft:packed_ice
setblock 183 234 280 minecraft:snow_block
fill 183 234 281 183 237 282 minecraft:packed_ice
setblock 183 234 291 minecraft:snow_block
setblock 183 234 300 minecraft:snow_block
setblock 183 234 315 minecraft:snow_block
fill 183 234 317 183 235 317 minecraft:snow_block
setblock 141 235 275 minecraft:snow_block
setblock 141 235 282 minecraft:packed_ice
fill 141 235 283 142 235 283 minecraft:snow_block
setblock 141 235 285 minecraft:snow_block
fill 141 235 293 142 235 293 minecraft:snow_block
setblock 141 235 295 minecraft:white_concrete
setblock 141 235 299 minecraft:snow_block
fill 142 235 275 142 237 275 minecraft:packed_ice
setblock 142 235 278 minecraft:snow_block
fill 142 235 279 142 238 279 minecraft:packed_ice
fill 142 235 284 142 238 284 minecraft:packed_ice
setblock 142 235 288 minecraft:snow_block
fill 142 235 289 142 238 289 minecraft:packed_ice
fill 142 235 294 142 238 294 minecraft:packed_ice
setblock 142 235 298 minecraft:snow_block
fill 142 235 299 142 238 299 minecraft:packed_ice
setblock 142 235 303 minecraft:snow_block
fill 142 235 304 142 235 307 minecraft:packed_ice
setblock 142 235 308 minecraft:snow_block
fill 142 235 309 142 238 309 minecraft:packed_ice
setblock 142 235 312 minecraft:packed_ice
setblock 142 235 313 minecraft:snow_block
fill 142 235 314 142 238 314 minecraft:packed_ice
setblock 143 235 277 minecraft:snow_block
fill 143 235 278 143 238 278 minecraft:packed_ice
setblock 143 235 282 minecraft:snow_block
fill 143 235 283 143 238 283 minecraft:packed_ice
setblock 143 235 287 minecraft:snow_block
fill 143 235 288 143 236 288 minecraft:packed_ice
setblock 143 235 292 minecraft:snow_block
fill 143 235 293 143 236 293 minecraft:packed_ice
setblock 143 235 297 minecraft:snow_block
fill 143 235 298 143 238 298 minecraft:packed_ice
setblock 143 235 302 minecraft:snow_block
fill 143 235 303 143 237 304 minecraft:packed_ice
setblock 143 235 312 minecraft:snow_block
fill 143 235 313 143 237 313 minecraft:packed_ice
setblock 144 235 276 minecraft:snow_block
fill 144 235 277 144 238 277 minecraft:packed_ice
setblock 144 235 280 minecraft:packed_ice
setblock 144 235 281 minecraft:snow_block
fill 144 235 282 144 238 282 minecraft:packed_ice
setblock 144 235 296 minecraft:snow_block
setblock 144 235 297 minecraft:packed_ice
setblock 144 235 316 minecraft:snow_block
fill 145 235 276 145 238 276 minecraft:packed_ice
setblock 145 235 279 minecraft:packed_ice
setblock 145 235 280 minecraft:snow_block
fill 145 235 281 145 237 281 minecraft:packed_ice
setblock 145 235 315 minecraft:snow_block
fill 145 235 316 145 238 316 minecraft:packed_ice
fill 146 235 275 148 235 275 minecraft:snow_block
setblock 146 235 279 minecraft:snow_block
setblock 146 235 314 minecraft:snow_block
fill 146 235 315 149 235 315 minecraft:packed_ice
setblock 147 235 278 minecraft:snow_block
fill 147 235 279 147 236 279 minecraft:packed_ice
setblock 148 235 277 minecraft:snow_block
fill 148 235 278 148 237 278 minecraft:packed_ice
setblock 149 235 276 minecraft:snow_block
fill 149 235 277 149 238 277 minecraft:packed_ice
setblock 149 235 316 minecraft:snow_block
fill 150 235 276 153 235 276 minecraft:packed_ice
setblock 150 235 278 minecraft:packed_ice
setblock 150 235 315 minecraft:snow_block
fill 150 235 316 153 235 316 minecraft:packed_ice
fill 151 235 275 151 236 275 minecraft:snow_block
fill 151 235 315 154 235 315 minecraft:packed_ice
setblock 151 235 317 minecraft:snow_block
setblock 153 235 275 minecraft:white_concrete
setblock 153 235 277 minecraft:snow_block
setblock 154 235 276 minecraft:snow_block
fill 154 235 277 154 236 277 minecraft:packed_ice
fill 154 235 316 154 235 317 minecraft:snow_block
fill 155 235 276 155 238 276 minecraft:packed_ice
setblock 155 235 315 minecraft:snow_block
fill 155 235 316 155 238 316 minecraft:packed_ice
setblock 155 235 317 minecraft:snow_block
fill 156 235 315 156 236 315 minecraft:packed_ice
setblock 157 235 275 minecraft:snow_block
setblock 158 235 276 minecraft:packed_ice
setblock 158 235 277 minecraft:snow_block
setblock 159 235 276 minecraft:snow_block
fill 159 235 277 162 235 277 minecraft:packed_ice
fill 159 235 316 159 235 317 minecraft:snow_block
fill 160 235 276 160 238 276 minecraft:packed_ice
setblock 160 235 315 minecraft:snow_block
fill 160 235 316 160 238 316 minecraft:packed_ice
setblock 161 235 278 minecraft:packed_ice
setblock 161 235 314 minecraft:snow_block
fill 161 235 315 161 238 315 minecraft:packed_ice
fill 162 235 275 162 237 275 minecraft:packed_ice
setblock 162 235 278 minecraft:snow_block
fill 162 235 314 162 236 314 minecraft:packed_ice
setblock 163 235 277 minecraft:snow_block
fill 163 235 278 163 236 278 minecraft:packed_ice
setblock 163 235 317 minecraft:snow_block
setblock 164 235 276 minecraft:snow_block
fill 164 235 277 164 238 277 minecraft:packed_ice
setblock 164 235 316 minecraft:snow_block
fill 165 235 276 165 238 276 minecraft:packed_ice
setblock 165 235 315 minecraft:snow_block
fill 165 235 316 165 238 316 minecraft:packed_ice
fill 166 235 315 166 236 315 minecraft:packed_ice
setblock 168 235 277 minecraft:snow_block
setblock 169 235 276 minecraft:snow_block
setblock 169 235 277 minecraft:packed_ice
setblock 169 235 316 minecraft:snow_block
fill 170 235 276 170 236 276 minecraft:packed_ice
setblock 170 235 316 minecraft:packed_ice
fill 173 235 286 173 243 287 minecraft:packed_ice
fill 173 235 317 173 237 317 minecraft:packed_ice
setblock 174 235 276 minecraft:snow_block
fill 174 235 286 174 243 286 minecraft:packed_ice
fill 175 235 276 175 238 276 minecraft:packed_ice
setblock 177 235 277 minecraft:packed_ice
setblock 178 235 277 minecraft:snow_block
setblock 179 235 276 minecraft:snow_block
fill 179 235 277 181 235 278 minecraft:packed_ice
setblock 179 235 316 minecraft:snow_block
fill 180 235 276 182 236 276 minecraft:packed_ice
setblock 180 235 279 minecraft:packed_ice
setblock 180 235 280 minecraft:snow_block
fill 180 235 281 181 235 283 minecraft:packed_ice
setblock 180 235 295 minecraft:snow_block
fill 180 235 296 180 238 296 minecraft:packed_ice
setblock 180 235 300 minecraft:snow_block
fill 180 235 301 180 238 301 minecraft:packed_ice
fill 180 235 316 180 238 316 minecraft:packed_ice
setblock 181 235 279 minecraft:snow_block
fill 181 235 280 181 238 280 minecraft:packed_ice
setblock 181 235 284 minecraft:snow_block
fill 181 235 285 181 238 285 minecraft:packed_ice
setblock 181 235 289 minecraft:snow_block
fill 181 235 290 181 238 290 minecraft:packed_ice
setblock 181 235 294 minecraft:snow_block
fill 181 235 295 181 238 295 minecraft:packed_ice
setblock 181 235 299 minecraft:snow_block
fill 181 235 300 181 238 300 minecraft:packed_ice
setblock 181 235 304 minecraft:snow_block
setblock 182 235 275 minecraft:snow_block
setblock 182 235 277 minecraft:packed_ice
setblock 182 235 278 minecraft:snow_block
fill 182 235 279 182 238 279 minecraft:packed_ice
setblock 182 235 283 minecraft:snow_block
fill 182 235 284 182 238 284 minecraft:packed_ice
setblock 182 235 288 minecraft:snow_block
fill 182 235 289 182 238 289 minecraft:packed_ice
setblock 182 235 293 minecraft:snow_block
fill 182 235 294 182 238 294 minecraft:packed_ice
setblock 182 235 298 minecraft:snow_block
fill 182 235 299 182 238 299 minecraft:packed_ice
setblock 182 235 303 minecraft:snow_block
fill 182 235 304 182 238 304 minecraft:packed_ice
setblock 182 235 313 minecraft:snow_block
fill 182 235 314 183 237 314 minecraft:packed_ice
fill 183 235 280 183 237 280 minecraft:packed_ice
setblock 183 235 289 minecraft:light_blue_concrete
fill 183 235 291 183 237 291 minecraft:packed_ice
setblock 183 235 296 minecraft:snow_block
fill 183 235 300 183 238 300 minecraft:packed_ice
setblock 183 235 312 minecraft:snow_block
fill 183 235 315 183 237 315 minecraft:packed_ice
fill 141 236 275 141 237 275 minecraft:packed_ice
fill 141 236 280 141 237 280 minecraft:packed_ice
fill 141 236 282 142 236 282 minecraft:snow_block
fill 141 236 283 142 237 283 minecraft:packed_ice
fill 141 236 285 141 238 285 minecraft:packed_ice
setblock 141 236 288 minecraft:snow_block
fill 141 236 289 141 237 289 minecraft:packed_ice
setblock 141 236 290 minecraft:snow_block
fill 141 236 292 141 237 293 minecraft:packed_ice
fill 141 236 295 141 237 295 minecraft:packed_ice
fill 141 236 299 141 237 299 minecraft:packed_ice
fill 141 236 302 141 237 302 minecraft:packed_ice
setblock 141 236 303 minecraft:snow_block
fill 141 236 304 142 238 304 minecraft:packed_ice
setblock 141 236 315 minecraft:snow_block
fill 141 236 316 141 237 316 minecraft:packed_ice
setblock 142 236 277 minecraft:snow_block
fill 142 236 278 142 239 278 minecraft:packed_ice
setblock 142 236 287 minecraft:snow_block
fill 142 236 288 142 239 288 minecraft:packed_ice
setblock 142 236 292 minecraft:snow_block
fill 142 236 293 142 238 293 minecraft:packed_ice
setblock 142 236 297 minecraft:snow_block
fill 142 236 298 142 239 298 minecraft:packed_ice
setblock 142 236 301 minecraft:packed_ice
setblock 142 236 302 minecraft:snow_block
fill 142 236 303 142 239 303 minecraft:packed_ice
fill 142 236 305 142 236 306 minecraft:packed_ice
setblock 142 236 307 minecraft:snow_block
fill 142 236 308 142 239 308 minecraft:packed_ice
setblock 142 236 312 minecraft:snow_block
fill 142 236 313 142 239 313 minecraft:packed_ice
setblock 142 236 317 minecraft:snow_block
setblock 143 236 276 minecraft:snow_block
fill 143 236 277 143 239 277 minecraft:packed_ice
setblock 143 236 281 minecraft:snow_block
fill 143 236 282 143 239 282 minecraft:packed_ice
setblock 143 236 286 minecraft:snow_block
fill 143 236 287 143 237 287 minecraft:packed_ice
setblock 143 236 291 minecraft:snow_block
setblock 143 236 292 minecraft:packed_ice
setblock 143 236 296 minecraft:snow_block
fill 143 236 297 143 238 297 minecraft:packed_ice
setblock 143 236 301 minecraft:snow_block
fill 143 236 302 143 239 302 minecraft:packed_ice
setblock 143 236 316 minecraft:snow_block
fill 143 236 317 143 237 317 minecraft:packed_ice
fill 144 236 276 144 239 276 minecraft:packed_ice
setblock 144 236 280 minecraft:snow_block
fill 144 236 281 144 239 281 minecraft:packed_ice
setblock 144 236 315 minecraft:snow_block
fill 144 236 316 144 239 316 minecraft:packed_ice
setblock 145 236 279 minecraft:snow_block
fill 145 236 280 145 237 280 minecraft:packed_ice
fill 145 236 315 148 236 315 minecraft:packed_ice
setblock 146 236 275 minecraft:snow_block
setblock 146 236 278 minecraft:snow_block
fill 146 236 279 146 237 279 minecraft:packed_ice
fill 147 236 275 148 237 275 minecraft:packed_ice
setblock 147 236 277 minecraft:snow_block
fill 147 236 278 147 238 278 minecraft:packed_ice
setblock 148 236 276 minecraft:snow_block
fill 148 236 277 148 239 277 minecraft:packed_ice
setblock 148 236 316 minecraft:snow_block
setblock 149 236 275 minecraft:snow_block
fill 149 236 276 152 236 276 minecraft:packed_ice
setblock 149 236 315 minecraft:snow_block
fill 149 236 316 152 236 316 minecraft:packed_ice
fill 150 236 315 151 236 315 minecraft:packed_ice
fill 151 236 317 151 237 317 minecraft:packed_ice
setblock 152 236 277 minecraft:snow_block
fill 152 236 298 152 237 298 minecraft:snow_block
fill 153 236 275 153 237 275 minecraft:packed_ice
setblock 153 236 276 minecraft:snow_block
setblock 153 236 277 minecraft:packed_ice
setblock 153 236 316 minecraft:snow_block
setblock 154 236 275 minecraft:snow_block
fill 154 236 276 154 239 276 minecraft:packed_ice
fill 154 236 316 154 237 317 minecraft:packed_ice
setblock 155 236 315 minecraft:packed_ice
fill 155 236 317 155 237 317 minecraft:packed_ice
setblock 156 236 275 minecraft:white_concrete
setblock 156 236 277 minecraft:packed_ice
fill 157 236 275 157 237 275 minecraft:packed_ice
setblock 157 236 277 minecraft:snow_block
setblock 158 236 276 minecraft:snow_block
fill 158 236 277 161 236 277 minecraft:packed_ice
fill 158 236 316 158 236 317 minecraft:snow_block
fill 159 236 276 159 239 276 minecraft:packed_ice
setblock 159 236 315 minecraft:snow_block
fill 159 236 316 159 237 317 minecraft:packed_ice
setblock 160 236 314 minecraft:snow_block
fill 160 236 315 160 239 315 minecraft:packed_ice
setblock 161 236 278 minecraft:snow_block
setblock 161 236 314 minecraft:packed_ice
fill 161 236 317 162 236 317 minecraft:snow_block
setblock 162 236 277 minecraft:snow_block
setblock 162 236 278 minecraft:packed_ice
fill 162 236 289 163 272 289 minecraft:snow_block
setblock 163 236 276 minecraft:snow_block
fill 163 236 277 163 239 277 minecraft:packed_ice
fill 163 236 290 163 272 290 minecraft:snow_block
setblock 163 236 316 minecraft:snow_block
fill 163 236 317 163 237 317 minecraft:packed_ice
fill 164 236 276 164 239 276 minecraft:packed_ice
setblock 164 236 278 minecraft:packed_ice
setblock 164 236 315 minecraft:snow_block
fill 164 236 316 164 239 316 minecraft:packed_ice
fill 165 236 315 165 237 315 minecraft:packed_ice
setblock 166 236 275 minecraft:snow_block
setblock 167 236 277 minecraft:snow_block
fill 168 236 275 168 236 276 minecraft:snow_block
setblock 168 236 277 minecraft:packed_ice
setblock 168 236 316 minecraft:snow_block
fill 169 236 275 169 237 276 minecraft:packed_ice
setblock 169 236 316 minecraft:packed_ice
setblock 173 236 276 minecraft:snow_block
fill 173 236 288 174 243 288 minecraft:packed_ice
setblock 174 236 276 minecraft:packed_ice
fill 175 236 287 175 243 287 minecraft:packed_ice
setblock 176 236 317 minecraft:snow_block
setblock 177 236 277 minecraft:snow_block
fill 177 236 310 177 237 310 minecraft:packed_ice
fill 177 236 317 178 237 317 minecraft:packed_ice
setblock 178 236 276 minecraft:snow_block
fill 178 236 277 181 236 277 minecraft:packed_ice
fill 178 236 309 178 237 309 minecraft:packed_ice
fill 178 236 311 178 237 311 minecraft:packed_ice
fill 179 236 276 179 239 276 minecraft:packed_ice
fill 179 236 278 180 236 278 minecraft:packed_ice
fill 179 236 310 179 237 310 minecraft:packed_ice
fill 179 236 316 179 237 316 minecraft:packed_ice
setblock 180 236 279 minecraft:snow_block
fill 180 236 280 180 236 283 minecraft:packed_ice
setblock 180 236 284 minecraft:snow_block
setblock 180 236 294 minecraft:snow_block
fill 180 236 295 180 237 295 minecraft:packed_ice
setblock 180 236 299 minecraft:snow_block
fill 180 236 300 180 239 300 minecraft:packed_ice
fill 180 236 302 181 236 302 minecraft:packed_ice
setblock 181 236 278 minecraft:snow_block
fill 181 236 279 181 239 279 minecraft:packed_ice
fill 181 236 281 181 236 282 minecraft:packed_ice
setblock 181 236 283 minecraft:snow_block
fill 181 236 284 181 239 284 minecraft:packed_ice
setblock 181 236 288 minecraft:snow_block
fill 181 236 289 181 239 289 minecraft:packed_ice
setblock 181 236 293 minecraft:snow_block
fill 181 236 294 181 239 294 minecraft:packed_ice
setblock 181 236 298 minecraft:snow_block
fill 181 236 299 181 239 299 minecraft:packed_ice
setblock 181 236 303 minecraft:snow_block
fill 181 236 304 181 239 304 minecraft:packed_ice
fill 182 236 275 182 237 275 minecraft:packed_ice
fill 182 236 277 183 236 277 minecraft:snow_block
fill 182 236 278 182 239 278 minecraft:packed_ice
setblock 182 236 282 minecraft:snow_block
fill 182 236 283 182 239 283 minecraft:packed_ice
setblock 182 236 287 minecraft:snow_block
fill 182 236 288 182 239 288 minecraft:packed_ice
setblock 182 236 292 minecraft:snow_block
fill 182 236 293 182 239 293 minecraft:packed_ice
setblock 182 236 297 minecraft:snow_block
fill 182 236 298 182 239 298 minecraft:packed_ice
setblock 182 236 302 minecraft:snow_block
fill 182 236 303 182 239 303 minecraft:packed_ice
setblock 182 236 307 minecraft:snow_block
fill 182 236 308 182 237 308 minecraft:packed_ice
setblock 182 236 312 minecraft:snow_block
setblock 182 236 313 minecraft:packed_ice
setblock 183 236 276 minecraft:snow_block
setblock 183 236 279 minecraft:light_blue_concrete
setblock 183 236 285 minecraft:snow_block
fill 183 236 286 183 237 286 minecraft:packed_ice
fill 183 236 289 183 237 289 minecraft:packed_ice
fill 183 236 294 183 237 294 minecraft:packed_ice
setblock 183 236 295 minecraft:snow_block
fill 183 236 296 183 237 296 minecraft:packed_ice
fill 183 236 312 183 237 312 minecraft:packed_ice
setblock 183 236 313 minecraft:snow_block
fill 183 236 317 183 237 317 minecraft:packed_ice
fill 141 237 282 142 237 282 minecraft:packed_ice
setblock 141 237 288 minecraft:packed_ice
setblock 141 237 290 minecraft:packed_ice
setblock 141 237 303 minecraft:packed_ice
setblock 141 237 315 minecraft:packed_ice
setblock 142 237 276 minecraft:snow_block
fill 142 237 277 142 240 277 minecraft:packed_ice
setblock 142 237 281 minecraft:snow_block
setblock 142 237 286 minecraft:snow_block
fill 142 237 287 142 240 287 minecraft:packed_ice
setblock 142 237 291 minecraft:snow_block
fill 142 237 292 142 238 292 minecraft:packed_ice
setblock 142 237 296 minecraft:snow_block
fill 142 237 297 142 240 297 minecraft:packed_ice
setblock 142 237 301 minecraft:snow_block
fill 142 237 302 142 240 302 minecraft:packed_ice
setblock 142 237 305 minecraft:packed_ice
setblock 142 237 306 minecraft:snow_block
fill 142 237 307 142 240 307 minecraft:packed_ice
setblock 142 237 311 minecraft:snow_block
fill 142 237 312 142 240 312 minecraft:packed_ice
setblock 142 237 316 minecraft:snow_block
setblock 142 237 317 minecraft:packed_ice
fill 143 237 276 143 240 276 minecraft:packed_ice
setblock 143 237 280 minecraft:snow_block
fill 143 237 281 143 240 281 minecraft:packed_ice
setblock 143 237 285 minecraft:snow_block
fill 143 237 286 143 239 286 minecraft:packed_ice
setblock 143 237 295 minecraft:snow_block
setblock 143 237 296 minecraft:packed_ice
setblock 143 237 300 minecraft:snow_block
fill 143 237 301 143 239 301 minecraft:packed_ice
setblock 143 237 305 minecraft:snow_block
setblock 143 237 315 minecraft:snow_block
fill 143 237 316 143 240 316 minecraft:packed_ice
setblock 144 237 279 minecraft:snow_block
fill 144 237 280 144 240 280 minecraft:packed_ice
setblock 144 237 284 minecraft:snow_block
fill 144 237 315 147 237 315 minecraft:packed_ice
setblock 145 237 278 minecraft:snow_block
fill 145 237 279 145 238 279 minecraft:packed_ice
setblock 146 237 275 minecraft:packed_ice
setblock 146 237 277 minecraft:snow_block
fill 146 237 278 146 239 278 minecraft:packed_ice
setblock 147 237 276 minecraft:snow_block
fill 147 237 277 147 240 277 minecraft:packed_ice
setblock 147 237 316 minecraft:snow_block
fill 148 237 276 151 237 276 minecraft:packed_ice
setblock 148 237 315 minecraft:snow_block
fill 148 237 316 151 237 316 minecraft:packed_ice
setblock 149 237 275 minecraft:packed_ice
setblock 151 237 275 minecraft:packed_ice
setblock 151 237 277 minecraft:snow_block
setblock 152 237 276 minecraft:snow_block
setblock 152 237 277 minecraft:packed_ice
setblock 152 237 316 minecraft:snow_block
fill 153 237 276 153 239 276 minecraft:packed_ice
fill 153 237 316 153 238 316 minecraft:packed_ice
setblock 154 237 275 minecraft:packed_ice
setblock 156 237 275 minecraft:packed_ice
setblock 156 237 277 minecraft:snow_block
setblock 157 237 276 minecraft:snow_block
fill 157 237 277 160 237 277 minecraft:packed_ice
setblock 157 237 316 minecraft:snow_block
fill 158 237 276 158 240 276 minecraft:packed_ice
setblock 158 237 315 minecraft:snow_block
fill 158 237 316 158 237 317 minecraft:packed_ice
fill 159 237 315 159 238 315 minecraft:packed_ice
setblock 161 237 277 minecraft:snow_block
fill 161 237 317 162 237 317 minecraft:packed_ice
setblock 162 237 276 minecraft:snow_block
fill 162 237 277 162 239 277 minecraft:packed_ice
setblock 162 237 316 minecraft:snow_block
fill 163 237 276 163 240 276 minecraft:packed_ice
setblock 163 237 315 minecraft:snow_block
fill 163 237 316 163 240 316 minecraft:packed_ice
setblock 164 237 315 minecraft:packed_ice
fill 166 237 275 166 238 275 minecraft:packed_ice
setblock 166 237 277 minecraft:snow_block
setblock 167 237 276 minecraft:snow_block
setblock 167 237 316 minecraft:snow_block
fill 168 237 275 168 237 276 minecraft:packed_ice
setblock 168 237 316 minecraft:packed_ice
fill 172 237 286 172 243 287 minecraft:packed_ice
setblock 172 237 317 minecraft:light_blue_concrete
fill 173 237 285 174 243 285 minecraft:packed_ice
fill 175 237 286 175 243 286 minecraft:packed_ice
fill 175 237 288 175 243 288 minecraft:packed_ice
setblock 176 237 317 minecraft:light_blue_concrete
setblock 177 237 276 minecraft:snow_block
fill 177 237 277 180 237 277 minecraft:packed_ice
fill 178 237 276 178 240 276 minecraft:packed_ice
fill 178 237 278 179 237 278 minecraft:packed_ice
fill 180 237 276 181 237 276 minecraft:packed_ice
setblock 180 237 278 minecraft:snow_block
fill 180 237 279 180 237 282 minecraft:packed_ice
setblock 180 237 283 minecraft:snow_block
fill 180 237 284 180 239 285 minecraft:packed_ice
setblock 180 237 294 minecraft:packed_ice
setblock 180 237 298 minecraft:snow_block
fill 180 237 299 180 239 299 minecraft:packed_ice
setblock 180 237 302 minecraft:packed_ice
setblock 181 237 277 minecraft:snow_block
fill 181 237 278 181 240 278 minecraft:packed_ice
setblock 181 237 281 minecraft:packed_ice
setblock 181 237 282 minecraft:snow_block
fill 181 237 283 181 240 283 minecraft:packed_ice
setblock 181 237 287 minecraft:snow_block
fill 181 237 288 181 240 288 minecraft:packed_ice
setblock 181 237 292 minecraft:snow_block
fill 181 237 293 181 239 293 minecraft:packed_ice
setblock 181 237 297 minecraft:snow_block
fill 181 237 298 181 240 298 minecraft:packed_ice
setblock 181 237 302 minecraft:snow_block
fill 181 237 303 181 240 303 minecraft:packed_ice
fill 181 237 305 181 238 305 minecraft:packed_ice
setblock 182 237 276 minecraft:snow_block
fill 182 237 277 183 238 277 minecraft:packed_ice
setblock 182 237 281 minecraft:snow_block
fill 182 237 282 182 240 282 minecraft:packed_ice
setblock 182 237 286 minecraft:snow_block
fill 182 237 287 182 240 287 minecraft:packed_ice
setblock 182 237 291 minecraft:snow_block
fill 182 237 292 182 240 292 minecraft:packed_ice
setblock 182 237 296 minecraft:snow_block
fill 182 237 297 182 240 297 minecraft:packed_ice
setblock 182 237 301 minecraft:snow_block
fill 182 237 302 182 240 302 minecraft:packed_ice
setblock 182 237 306 minecraft:snow_block
fill 182 237 307 182 240 307 minecraft:packed_ice
setblock 182 237 316 minecraft:snow_block
setblock 183 237 276 minecraft:packed_ice
setblock 183 237 279 minecraft:packed_ice
setblock 183 237 285 minecraft:packed_ice
setblock 183 237 295 minecraft:packed_ice
setblock 183 237 313 minecraft:packed_ice
fill 141 238 275 141 238 284 minecraft:snow_block
fill 141 238 286 141 238 290 minecraft:snow_block
fill 141 238 292 141 239 295 minecraft:snow_block
fill 141 238 296 142 238 296 minecraft:packed_ice
fill 141 238 297 141 241 303 minecraft:snow_block
fill 141 238 305 141 238 317 minecraft:snow_block
fill 142 238 275 143 238 275 minecraft:snow_block
fill 142 238 276 142 241 276 minecraft:packed_ice
setblock 142 238 280 minecraft:snow_block
fill 142 238 281 142 239 283 minecraft:packed_ice
setblock 142 238 285 minecraft:snow_block
fill 142 238 286 142 241 286 minecraft:packed_ice
setblock 142 238 290 minecraft:snow_block
setblock 142 238 291 minecraft:packed_ice
setblock 142 238 295 minecraft:snow_block
setblock 142 238 300 minecraft:snow_block
fill 142 238 301 142 241 301 minecraft:packed_ice
setblock 142 238 305 minecraft:snow_block
fill 142 238 306 142 241 306 minecraft:packed_ice
setblock 142 238 310 minecraft:snow_block
fill 142 238 311 142 241 311 minecraft:packed_ice
setblock 142 238 315 minecraft:snow_block
fill 142 238 316 142 241 316 minecraft:packed_ice
fill 142 238 317 146 238 317 minecraft:snow_block
setblock 143 238 279 minecraft:snow_block
fill 143 238 280 143 241 280 minecraft:packed_ice
setblock 143 238 284 minecraft:snow_block
fill 143 238 285 143 241 285 minecraft:packed_ice
setblock 143 238 299 minecraft:snow_block
fill 143 238 300 143 239 300 minecraft:packed_ice
setblock 143 238 303 minecraft:packed_ice
setblock 143 238 304 minecraft:snow_block
fill 143 238 305 143 239 305 minecraft:packed_ice
setblock 143 238 314 minecraft:snow_block
fill 143 238 315 146 238 315 minecraft:packed_ice
setblock 144 238 278 minecraft:snow_block
fill 144 238 279 144 241 279 minecraft:packed_ice
setblock 144 238 283 minecraft:snow_block
fill 145 238 275 165 238 275 minecraft:snow_block
setblock 145 238 277 minecraft:snow_block
fill 145 238 278 145 240 278 minecraft:packed_ice
setblock 146 238 276 minecraft:snow_block
fill 146 238 277 146 240 277 minecraft:packed_ice
setblock 146 238 316 minecraft:snow_block
fill 147 238 276 150 238 276 minecraft:packed_ice
fill 147 238 316 150 238 316 minecraft:packed_ice
fill 148 238 317 149 254 317 minecraft:snow_block
setblock 150 238 277 minecraft:snow_block
setblock 151 238 276 minecraft:snow_block
fill 151 238 316 151 238 317 minecraft:snow_block
fill 152 238 276 152 239 276 minecraft:packed_ice
setblock 152 238 316 minecraft:packed_ice
fill 153 238 317 155 270 317 minecraft:snow_block
fill 154 238 316 154 239 316 minecraft:packed_ice
setblock 156 238 276 minecraft:snow_block
setblock 156 238 316 minecraft:snow_block
fill 157 238 276 157 238 277 minecraft:packed_ice
fill 157 238 316 159 239 316 minecraft:packed_ice
fill 157 238 317 180 238 317 minecraft:snow_block
fill 158 238 277 159 238 277 minecraft:packed_ice
setblock 158 238 315 minecraft:packed_ice
setblock 160 238 277 minecraft:snow_block
setblock 161 238 276 minecraft:snow_block
fill 161 238 277 161 239 277 minecraft:packed_ice
setblock 161 238 316 minecraft:snow_block
fill 162 238 276 162 241 276 minecraft:packed_ice
setblock 162 238 315 minecraft:snow_block
fill 162 238 316 162 241 316 minecraft:packed_ice
setblock 163 238 315 minecraft:packed_ice
setblock 165 238 277 minecraft:snow_block
setblock 166 238 276 minecraft:snow_block
setblock 166 238 316 minecraft:snow_block
fill 167 238 275 183 238 275 minecraft:snow_block
setblock 167 238 276 minecraft:packed_ice
fill 172 238 285 172 243 285 minecraft:packed_ice
fill 172 238 288 172 243 288 minecraft:packed_ice
fill 173 238 289 174 243 289 minecraft:packed_ice
fill 175 238 285 175 243 285 minecraft:packed_ice
setblock 176 238 276 minecraft:snow_block
fill 176 238 287 176 243 287 minecraft:packed_ice
fill 177 238 276 177 240 277 minecraft:packed_ice
fill 178 238 277 178 238 278 minecraft:packed_ice
setblock 179 238 277 minecraft:packed_ice
setblock 179 238 278 minecraft:snow_block
setblock 180 238 276 minecraft:packed_ice
setblock 180 238 277 minecraft:snow_block
fill 180 238 278 180 238 281 minecraft:packed_ice
setblock 180 238 282 minecraft:snow_block
fill 180 238 283 180 241 283 minecraft:packed_ice
setblock 180 238 297 minecraft:snow_block
setblock 180 238 298 minecraft:packed_ice
setblock 180 238 302 minecraft:snow_block
setblock 181 238 276 minecraft:snow_block
fill 181 238 277 181 241 277 minecraft:packed_ice
setblock 181 238 281 minecraft:snow_block
fill 181 238 282 181 241 282 minecraft:packed_ice
setblock 181 238 286 minecraft:snow_block
fill 181 238 287 181 241 287 minecraft:packed_ice
setblock 181 238 291 minecraft:snow_block
fill 181 238 292 181 239 292 minecraft:packed_ice
setblock 181 238 296 minecraft:snow_block
fill 181 238 297 181 240 297 minecraft:packed_ice
setblock 181 238 301 minecraft:snow_block
fill 181 238 302 181 241 302 minecraft:packed_ice
setblock 181 238 316 minecraft:snow_block
fill 182 238 276 182 241 276 minecraft:packed_ice
fill 182 238 280 183 238 280 minecraft:snow_block
fill 182 238 281 182 241 281 minecraft:packed_ice
fill 182 238 285 183 238 285 minecraft:snow_block
fill 182 238 286 182 241 286 minecraft:packed_ice
fill 182 238 290 183 238 290 minecraft:snow_block
fill 182 238 291 182 241 291 minecraft:packed_ice
fill 182 238 295 183 238 295 minecraft:snow_block
fill 182 238 296 182 241 296 minecraft:packed_ice
setblock 182 238 300 minecraft:snow_block
fill 182 238 301 182 241 301 minecraft:packed_ice
fill 182 238 305 183 238 305 minecraft:snow_block
fill 182 238 306 182 241 306 minecraft:packed_ice
fill 182 238 315 183 238 315 minecraft:snow_block
fill 182 238 316 182 240 316 minecraft:packed_ice
fill 182 238 317 183 239 317 minecraft:snow_block
fill 183 238 276 183 306 276 minecraft:snow_block
fill 183 238 279 183 241 279 minecraft:snow_block
fill 183 238 281 183 258 284 minecraft:snow_block
fill 183 238 286 183 251 289 minecraft:snow_block
fill 183 238 291 183 238 294 minecraft:snow_block
fill 183 238 296 183 308 296 minecraft:snow_block
fill 183 238 298 183 238 299 minecraft:snow_block
fill 183 238 301 183 239 303 minecraft:snow_block
fill 183 238 306 183 239 313 minecraft:snow_block
setblock 183 238 314 minecraft:packed_ice
setblock 183 238 316 minecraft:snow_block
fill 141 239 275 141 308 276 minecraft:snow_block
setblock 141 239 277 minecraft:packed_ice
setblock 141 239 278 minecraft:white_concrete
fill 141 239 279 141 293 280 minecraft:snow_block
setblock 141 239 281 minecraft:packed_ice
fill 141 239 282 141 252 286 minecraft:snow_block
setblock 141 239 287 minecraft:packed_ice
fill 141 239 288 141 239 289 minecraft:snow_block
fill 141 239 290 142 239 290 minecraft:packed_ice
fill 141 239 291 141 308 291 minecraft:snow_block
fill 141 239 296 141 254 296 minecraft:snow_block
setblock 141 239 304 minecraft:light_blue_concrete
fill 141 239 305 141 239 307 minecraft:snow_block
setblock 141 239 308 minecraft:packed_ice
fill 141 239 309 142 239 309 minecraft:snow_block
fill 141 239 310 142 239 310 minecraft:packed_ice
fill 141 239 311 141 239 313 minecraft:snow_block
setblock 141 239 314 minecraft:packed_ice
fill 141 239 315 141 251 316 minecraft:snow_block
setblock 141 239 317 minecraft:packed_ice
fill 142 239 275 142 240 275 minecraft:packed_ice
setblock 142 239 279 minecraft:snow_block
fill 142 239 280 142 242 280 minecraft:packed_ice
setblock 142 239 284 minecraft:snow_block
fill 142 239 285 142 242 285 minecraft:packed_ice
setblock 142 239 289 minecraft:snow_block
setblock 142 239 294 minecraft:snow_block
fill 142 239 295 142 239 296 minecraft:packed_ice
setblock 142 239 299 minecraft:snow_block
fill 142 239 300 142 242 300 minecraft:packed_ice
setblock 142 239 304 minecraft:snow_block
fill 142 239 305 142 242 305 minecraft:packed_ice
setblock 142 239 314 minecraft:snow_block
fill 142 239 315 143 239 315 minecraft:packed_ice
fill 142 239 317 144 282 317 minecraft:snow_block
fill 143 239 275 164 239 275 minecraft:snow_block
setblock 143 239 278 minecraft:snow_block
fill 143 239 279 143 242 279 minecraft:packed_ice
setblock 143 239 283 minecraft:snow_block
fill 143 239 284 143 242 284 minecraft:packed_ice
setblock 143 239 299 minecraft:packed_ice
setblock 143 239 303 minecraft:snow_block
fill 143 239 304 143 241 304 minecraft:packed_ice
setblock 144 239 277 minecraft:snow_block
fill 144 239 278 144 240 278 minecraft:packed_ice
setblock 144 239 282 minecraft:snow_block
setblock 144 239 283 minecraft:packed_ice
setblock 145 239 276 minecraft:snow_block
fill 145 239 277 145 241 277 minecraft:packed_ice
setblock 145 239 316 minecraft:snow_block
setblock 145 239 317 minecraft:packed_ice
fill 146 239 276 149 239 276 minecraft:packed_ice
fill 146 239 316 149 239 316 minecraft:packed_ice
fill 146 239 317 147 308 317 minecraft:snow_block
setblock 150 239 276 minecraft:snow_block
fill 150 239 317 152 239 317 minecraft:snow_block
setblock 151 239 276 minecraft:packed_ice
setblock 155 239 276 minecraft:snow_block
setblock 155 239 316 minecraft:snow_block
fill 156 239 276 157 240 276 minecraft:packed_ice
fill 156 239 316 156 242 316 minecraft:packed_ice
fill 156 239 317 164 239 317 minecraft:snow_block
setblock 159 239 277 minecraft:snow_block
setblock 160 239 276 minecraft:snow_block
setblock 160 239 277 minecraft:packed_ice
setblock 160 239 316 minecraft:snow_block
fill 161 239 276 161 241 276 minecraft:packed_ice
setblock 161 239 315 minecraft:snow_block
fill 161 239 316 161 242 316 minecraft:packed_ice
setblock 165 239 275 minecraft:packed_ice
setblock 165 239 276 minecraft:snow_block
setblock 165 239 316 minecraft:snow_block
fill 165 239 317 166 239 317 minecraft:packed_ice
fill 166 239 275 182 239 275 minecraft:snow_block
fill 167 239 317 171 296 317 minecraft:snow_block
fill 171 239 286 171 243 288 minecraft:packed_ice
fill 172 239 289 172 243 289 minecraft:packed_ice
setblock 172 239 317 minecraft:packed_ice
fill 173 239 284 174 243 284 minecraft:packed_ice
fill 173 239 317 174 308 317 minecraft:snow_block
fill 175 239 289 175 243 289 minecraft:packed_ice
setblock 175 239 317 minecraft:packed_ice
fill 176 239 276 176 242 276 minecraft:packed_ice
fill 176 239 286 176 243 286 minecraft:packed_ice
fill 176 239 288 176 243 288 minecraft:packed_ice
fill 176 239 317 176 308 317 minecraft:snow_block
setblock 177 239 317 minecraft:packed_ice
setblock 178 239 277 minecraft:packed_ice
setblock 178 239 278 minecraft:snow_block
fill 178 239 317 179 308 317 minecraft:snow_block
setblock 179 239 277 minecraft:snow_block
fill 179 239 278 180 241 278 minecraft:packed_ice
setblock 180 239 276 minecraft:snow_block
fill 180 239 277 180 242 277 minecraft:packed_ice
fill 180 239 279 180 239 280 minecraft:packed_ice
setblock 180 239 281 minecraft:snow_block
fill 180 239 282 180 242 282 minecraft:packed_ice
setblock 180 239 286 minecraft:snow_block
setblock 180 239 301 minecraft:snow_block
setblock 180 239 317 minecraft:packed_ice
fill 181 239 276 181 242 276 minecraft:packed_ice
setblock 181 239 280 minecraft:snow_block
fill 181 239 281 181 242 281 minecraft:packed_ice
setblock 181 239 285 minecraft:snow_block
fill 181 239 286 181 242 286 minecraft:packed_ice
setblock 181 239 290 minecraft:snow_block
setblock 181 239 291 minecraft:packed_ice
setblock 181 239 295 minecraft:snow_block
fill 181 239 296 181 240 296 minecraft:packed_ice
setblock 181 239 300 minecraft:snow_block
fill 181 239 301 181 242 301 minecraft:packed_ice
setblock 181 239 305 minecraft:snow_block
setblock 181 239 316 minecraft:packed_ice
fill 181 239 317 181 248 317 minecraft:snow_block
fill 182 239 277 182 240 277 minecraft:packed_ice
setblock 182 239 279 minecraft:snow_block
fill 182 239 280 182 242 280 minecraft:packed_ice
setblock 182 239 284 minecraft:snow_block
fill 182 239 285 182 242 285 minecraft:packed_ice
setblock 182 239 289 minecraft:snow_block
fill 182 239 290 182 242 290 minecraft:packed_ice
fill 182 239 294 183 239 294 minecraft:snow_block
fill 182 239 295 182 242 295 minecraft:packed_ice
fill 182 239 299 183 239 299 minecraft:snow_block
fill 182 239 300 182 242 300 minecraft:packed_ice
fill 182 239 304 183 239 304 minecraft:snow_block
fill 182 239 305 182 242 305 minecraft:packed_ice
setblock 183 239 275 minecraft:packed_ice
fill 183 239 277 183 245 278 minecraft:snow_block
setblock 183 239 280 minecraft:snow_block
fill 183 239 285 183 305 285 minecraft:snow_block
fill 183 239 290 183 308 290 minecraft:snow_block
setblock 183 239 291 minecraft:packed_ice
fill 183 239 292 183 239 293 minecraft:snow_block
fill 183 239 295 183 308 295 minecraft:snow_block
fill 183 239 297 183 294 297 minecraft:snow_block
setblock 183 239 298 minecraft:white_concrete
fill 183 239 300 183 262 300 minecraft:snow_block
fill 183 239 305 183 256 305 minecraft:snow_block
fill 183 239 314 183 308 315 minecraft:snow_block
setblock 183 239 316 minecraft:packed_ice
fill 141 240 277 141 240 278 minecraft:snow_block
fill 141 240 281 141 308 281 minecraft:snow_block
fill 141 240 287 141 308 287 minecraft:snow_block
setblock 141 240 288 minecraft:packed_ice
fill 141 240 289 141 283 290 minecraft:snow_block
fill 141 240 292 141 267 292 minecraft:snow_block
setblock 141 240 293 minecraft:white_concrete
fill 141 240 294 141 255 295 minecraft:snow_block
fill 141 240 304 141 282 305 minecraft:snow_block
fill 141 240 306 141 240 307 minecraft:packed_ice
fill 141 240 308 141 242 312 minecraft:snow_block
setblock 141 240 313 minecraft:packed_ice
fill 141 240 314 141 308 314 minecraft:snow_block
fill 141 240 317 141 308 317 minecraft:snow_block
setblock 142 240 278 minecraft:snow_block
fill 142 240 279 142 243 279 minecraft:packed_ice
fill 142 240 281 142 240 282 minecraft:packed_ice
setblock 142 240 283 minecraft:snow_block
fill 142 240 284 142 243 284 minecraft:packed_ice
setblock 142 240 288 minecraft:snow_block
setblock 142 240 289 minecraft:packed_ice
setblock 142 240 298 minecraft:snow_block
fill 142 240 299 142 242 299 minecraft:packed_ice
setblock 142 240 303 minecraft:snow_block
fill 142 240 304 142 243 304 minecraft:packed_ice
setblock 142 240 308 minecraft:snow_block
fill 142 240 309 142 242 310 minecraft:packed_ice
setblock 142 240 313 minecraft:snow_block
fill 142 240 314 142 242 315 minecraft:packed_ice
fill 143 240 275 148 245 275 minecraft:snow_block
setblock 143 240 277 minecraft:snow_block
fill 143 240 278 143 243 278 minecraft:packed_ice
setblock 143 240 282 minecraft:snow_block
fill 143 240 283 143 243 283 minecraft:packed_ice
setblock 143 240 302 minecraft:snow_block
setblock 143 240 303 minecraft:packed_ice
setblock 144 240 276 minecraft:snow_block
fill 144 240 277 144 242 277 minecraft:packed_ice
setblock 144 240 281 minecraft:snow_block
setblock 144 240 282 minecraft:packed_ice
setblock 144 240 285 minecraft:light[level=12]
setblock 144 240 286 minecraft:light[level=15]
setblock 144 240 292 minecraft:light[level=12]
setblock 144 240 294 minecraft:light[level=15]
setblock 144 240 299 minecraft:light[level=12]
setblock 144 240 302 minecraft:light[level=15]
setblock 144 240 306 minecraft:light[level=12]
setblock 144 240 310 minecraft:light[level=15]
setblock 144 240 313 minecraft:light[level=12]
setblock 144 240 316 minecraft:snow_block
fill 145 240 276 148 240 276 minecraft:packed_ice
fill 145 240 281 145 242 281 minecraft:blue_ice
fill 145 240 316 147 240 316 minecraft:packed_ice
fill 145 240 317 145 308 317 minecraft:snow_block
setblock 149 240 275 minecraft:packed_ice
setblock 149 240 276 minecraft:snow_block
fill 150 240 275 158 255 275 minecraft:snow_block
fill 150 240 317 151 243 317 minecraft:snow_block
setblock 151 240 278 minecraft:light[level=12]
setblock 151 240 285 minecraft:light[level=12]
setblock 151 240 292 minecraft:light[level=12]
setblock 151 240 299 minecraft:light[level=12]
setblock 151 240 306 minecraft:light[level=12]
setblock 151 240 313 minecraft:light[level=12]
setblock 152 240 278 minecraft:light[level=15]
setblock 152 240 286 minecraft:light[level=15]
setblock 152 240 294 minecraft:light[level=15]
setblock 152 240 302 minecraft:light[level=15]
setblock 152 240 310 minecraft:light[level=15]
setblock 152 240 317 minecraft:packed_ice
setblock 155 240 316 minecraft:packed_ice
setblock 156 240 317 minecraft:packed_ice
fill 157 240 316 158 240 316 minecraft:packed_ice
fill 157 240 317 163 268 317 minecraft:snow_block
setblock 158 240 278 minecraft:light[level=12]
setblock 158 240 285 minecraft:light[level=12]
setblock 158 240 299 minecraft:light[level=12]
setblock 158 240 306 minecraft:light[level=12]
setblock 158 240 313 minecraft:light[level=12]
setblock 159 240 275 minecraft:packed_ice
setblock 159 240 276 minecraft:snow_block
setblock 159 240 316 minecraft:snow_block
fill 160 240 275 177 242 275 minecraft:snow_block
fill 160 240 276 160 242 276 minecraft:packed_ice
setblock 160 240 278 minecraft:light[level=15]
setblock 160 240 286 minecraft:light[level=15]
setblock 160 240 294 minecraft:light[level=15]
setblock 160 240 302 minecraft:light[level=15]
setblock 160 240 310 minecraft:light[level=15]
fill 160 240 316 160 243 316 minecraft:packed_ice
setblock 164 240 276 minecraft:snow_block
setblock 164 240 317 minecraft:packed_ice
setblock 165 240 278 minecraft:light[level=12]
setblock 165 240 285 minecraft:light[level=12]
setblock 165 240 292 minecraft:light[level=12]
setblock 165 240 299 minecraft:light[level=12]
setblock 165 240 306 minecraft:light[level=12]
setblock 165 240 313 minecraft:light[level=12]
fill 165 240 317 166 247 317 minecraft:snow_block
setblock 168 240 278 minecraft:light[level=15]
setblock 168 240 286 minecraft:light[level=15]
setblock 168 240 294 minecraft:light[level=15]
setblock 168 240 302 minecraft:light[level=15]
setblock 168 240 310 minecraft:light[level=15]
fill 171 240 285 171 243 285 minecraft:packed_ice
fill 171 240 289 171 243 289 minecraft:packed_ice
setblock 172 240 278 minecraft:light[level=12]
fill 172 240 284 172 243 284 minecraft:packed_ice
setblock 172 240 292 minecraft:light[level=12]
setblock 172 240 299 minecraft:light[level=12]
setblock 172 240 306 minecraft:light[level=12]
setblock 172 240 313 minecraft:light[level=12]
fill 172 240 317 172 308 317 minecraft:snow_block
fill 173 240 290 174 243 290 minecraft:packed_ice
fill 175 240 284 175 243 284 minecraft:packed_ice
fill 175 240 317 175 259 317 minecraft:snow_block
setblock 176 240 278 minecraft:light[level=15]
fill 176 240 285 176 243 285 minecraft:packed_ice
fill 176 240 289 176 243 289 minecraft:packed_ice
setblock 176 240 294 minecraft:light[level=15]
setblock 176 240 302 minecraft:light[level=15]
setblock 176 240 310 minecraft:light[level=15]
fill 177 240 287 177 243 287 minecraft:packed_ice
fill 177 240 317 177 308 317 minecraft:snow_block
fill 178 240 275 179 240 275 minecraft:packed_ice
setblock 178 240 277 minecraft:snow_block
setblock 179 240 276 minecraft:snow_block
fill 179 240 277 179 243 277 minecraft:packed_ice
setblock 179 240 285 minecraft:light[level=12]
setblock 179 240 292 minecraft:light[level=12]
setblock 179 240 299 minecraft:light[level=12]
setblock 179 240 306 minecraft:light[level=12]
setblock 179 240 313 minecraft:light[level=12]
fill 180 240 275 181 308 275 minecraft:snow_block
fill 180 240 276 180 243 276 minecraft:packed_ice
setblock 180 240 279 minecraft:packed_ice
setblock 180 240 280 minecraft:snow_block
fill 180 240 281 180 243 281 minecraft:packed_ice
setblock 180 240 284 minecraft:packed_ice
setblock 180 240 285 minecraft:snow_block
fill 180 240 286 180 243 286 minecraft:packed_ice
fill 180 240 317 180 308 317 minecraft:snow_block
setblock 181 240 279 minecraft:snow_block
fill 181 240 280 181 243 280 minecraft:packed_ice
setblock 181 240 284 minecraft:snow_block
fill 181 240 285 181 243 285 minecraft:packed_ice
setblock 181 240 289 minecraft:snow_block
fill 181 240 290 181 243 290 minecraft:packed_ice
setblock 181 240 295 minecraft:packed_ice
setblock 181 240 299 minecraft:snow_block
fill 181 240 300 181 242 300 minecraft:packed_ice
setblock 181 240 304 minecraft:snow_block
fill 181 240 305 181 243 305 minecraft:packed_ice
setblock 182 240 275 minecraft:packed_ice
setblock 182 240 278 minecraft:snow_block
fill 182 240 279 182 243 279 minecraft:packed_ice
setblock 182 240 283 minecraft:snow_block
fill 182 240 284 182 243 284 minecraft:packed_ice
setblock 182 240 288 minecraft:snow_block
fill 182 240 289 182 243 289 minecraft:packed_ice
fill 182 240 293 183 240 293 minecraft:snow_block
fill 182 240 294 182 242 294 minecraft:packed_ice
fill 182 240 298 183 240 298 minecraft:snow_block
fill 182 240 299 182 243 299 minecraft:packed_ice
setblock 182 240 303 minecraft:snow_block
fill 182 240 304 182 243 304 minecraft:packed_ice
fill 182 240 317 182 246 317 minecraft:snow_block
fill 183 240 275 183 308 275 minecraft:snow_block
setblock 183 240 280 minecraft:packed_ice
fill 183 240 291 183 308 291 minecraft:snow_block
setblock 183 240 292 minecraft:packed_ice
fill 183 240 294 183 243 294 minecraft:snow_block
fill 183 240 299 183 308 299 minecraft:snow_block
fill 183 240 301 183 246 302 minecraft:snow_block
setblock 183 240 303 minecraft:packed_ice
fill 183 240 304 183 247 304 minecraft:snow_block
fill 183 240 306 183 261 308 minecraft:snow_block
setblock 183 240 309 minecraft:packed_ice
fill 183 240 310 183 240 312 minecraft:snow_block
setblock 183 240 313 minecraft:packed_ice
fill 183 240 316 183 304 316 minecraft:snow_block
setblock 183 240 317 minecraft:packed_ice
setblock 141 241 277 minecraft:light_blue_concrete
fill 141 241 278 141 292 278 minecraft:snow_block
fill 141 241 288 141 308 288 minecraft:snow_block
fill 141 241 293 141 308 293 minecraft:snow_block
fill 141 241 306 141 263 307 minecraft:snow_block
fill 141 241 313 141 308 313 minecraft:snow_block
fill 142 241 275 142 276 275 minecraft:snow_block
setblock 142 241 277 minecraft:snow_block
fill 142 241 278 142 244 278 minecraft:packed_ice
setblock 142 241 281 minecraft:packed_ice
setblock 142 241 282 minecraft:snow_block
fill 142 241 283 142 244 283 minecraft:packed_ice
setblock 142 241 287 minecraft:snow_block
fill 142 241 288 142 244 288 minecraft:packed_ice
setblock 142 241 298 minecraft:packed_ice
setblock 142 241 302 minecraft:snow_block
fill 142 241 303 142 244 303 minecraft:packed_ice
setblock 142 241 307 minecraft:snow_block
fill 142 241 308 142 244 308 minecraft:packed_ice
setblock 142 241 312 minecraft:snow_block
fill 142 241 313 142 244 313 minecraft:packed_ice
setblock 143 241 276 minecraft:snow_block
fill 143 241 277 143 244 277 minecraft:packed_ice
setblock 143 241 281 minecraft:snow_block
fill 143 241 282 143 244 282 minecraft:packed_ice
setblock 143 241 316 minecraft:snow_block
fill 144 241 276 147 241 276 minecraft:packed_ice
setblock 144 241 280 minecraft:snow_block
setblock 144 241 281 minecraft:packed_ice
fill 144 241 282 145 241 282 minecraft:blue_ice
fill 144 241 316 145 241 316 minecraft:packed_ice
setblock 145 241 280 minecraft:blue_ice
fill 146 241 281 147 242 281 minecraft:blue_ice
fill 149 241 275 149 308 275 minecraft:snow_block
fill 152 241 317 152 285 317 minecraft:snow_block
setblock 156 241 317 minecraft:snow_block
setblock 157 241 276 minecraft:packed_ice
setblock 157 241 316 minecraft:packed_ice
setblock 158 241 276 minecraft:snow_block
setblock 158 241 316 minecraft:snow_block
fill 159 241 275 159 280 275 minecraft:snow_block
fill 159 241 276 159 242 276 minecraft:packed_ice
fill 159 241 316 159 244 316 minecraft:packed_ice
fill 164 241 317 164 293 317 minecraft:snow_block
fill 170 241 286 170 243 288 minecraft:packed_ice
fill 171 241 284 171 243 284 minecraft:packed_ice
fill 172 241 290 172 243 290 minecraft:packed_ice
fill 173 241 283 174 243 283 minecraft:packed_ice
fill 175 241 290 175 243 290 minecraft:packed_ice
fill 176 241 284 176 243 284 minecraft:packed_ice
setblock 177 241 276 minecraft:packed_ice
setblock 177 241 277 minecraft:snow_block
fill 177 241 285 177 243 286 minecraft:packed_ice
fill 177 241 288 177 243 288 minecraft:packed_ice
fill 178 241 275 178 241 276 minecraft:snow_block
fill 178 241 277 178 244 277 minecraft:packed_ice
fill 179 241 275 179 308 275 minecraft:snow_block
fill 179 241 276 179 244 276 minecraft:packed_ice
fill 179 241 281 179 243 282 minecraft:packed_ice
setblock 180 241 279 minecraft:snow_block
fill 180 241 280 180 244 280 minecraft:packed_ice
setblock 180 241 284 minecraft:snow_block
fill 180 241 285 180 244 285 minecraft:packed_ice
fill 180 241 287 180 242 287 minecraft:packed_ice
setblock 181 241 278 minecraft:snow_block
fill 181 241 279 181 244 279 minecraft:packed_ice
setblock 181 241 283 minecraft:snow_block
fill 181 241 284 181 244 284 minecraft:packed_ice
setblock 181 241 288 minecraft:snow_block
fill 181 241 289 181 244 289 minecraft:packed_ice
setblock 181 241 298 minecraft:snow_block
setblock 181 241 299 minecraft:packed_ice
setblock 181 241 303 minecraft:snow_block
fill 181 241 304 181 244 304 minecraft:packed_ice
fill 182 241 275 182 307 275 minecraft:snow_block
setblock 182 241 277 minecraft:snow_block
fill 182 241 278 182 244 278 minecraft:packed_ice
setblock 182 241 282 minecraft:snow_block
fill 182 241 283 182 244 283 minecraft:packed_ice
setblock 182 241 287 minecraft:snow_block
fill 182 241 288 182 244 288 minecraft:packed_ice
fill 182 241 292 183 241 292 minecraft:snow_block
fill 182 241 293 182 242 293 minecraft:packed_ice
setblock 182 241 297 minecraft:snow_block
fill 182 241 298 182 243 298 minecraft:packed_ice
setblock 182 241 302 minecraft:snow_block
fill 182 241 303 182 244 303 minecraft:packed_ice
setblock 182 241 307 minecraft:snow_block
fill 182 241 308 182 244 308 minecraft:packed_ice
fill 183 241 280 183 251 280 minecraft:snow_block
fill 183 241 293 183 243 293 minecraft:snow_block
fill 183 241 298 183 276 298 minecraft:snow_block
fill 183 241 303 183 308 303 minecraft:snow_block
fill 183 241 309 183 308 309 minecraft:snow_block
setblock 183 241 310 minecraft:white_concrete
fill 183 241 311 183 245 313 minecraft:snow_block
fill 183 241 317 183 308 317 minecraft:snow_block
fill 141 242 277 141 256 277 minecraft:snow_block
setblock 141 242 297 minecraft:light_blue_concrete
fill 141 242 298 141 245 303 minecraft:snow_block
setblock 142 242 276 minecraft:snow_block
fill 142 242 277 142 245 277 minecraft:packed_ice
setblock 142 242 281 minecraft:snow_block
fill 142 242 282 142 245 282 minecraft:packed_ice
setblock 142 242 286 minecraft:snow_block
fill 142 242 287 142 245 287 minecraft:packed_ice
setblock 142 242 301 minecraft:snow_block
fill 142 242 302 142 245 302 minecraft:packed_ice
setblock 142 242 306 minecraft:snow_block
fill 142 242 307 142 245 307 minecraft:packed_ice
setblock 142 242 311 minecraft:snow_block
fill 142 242 312 142 245 312 minecraft:packed_ice
setblock 142 242 316 minecraft:snow_block
fill 143 242 276 146 242 276 minecraft:packed_ice
setblock 143 242 280 minecraft:snow_block
fill 143 242 281 143 245 281 minecraft:packed_ice
setblock 143 242 285 minecraft:snow_block
setblock 143 242 305 minecraft:snow_block
fill 143 242 316 144 244 316 minecraft:packed_ice
setblock 144 242 281 minecraft:blue_ice
setblock 156 242 317 minecraft:white_concrete
setblock 157 242 316 minecraft:snow_block
setblock 158 242 276 minecraft:packed_ice
fill 158 242 316 158 245 316 minecraft:packed_ice
fill 170 242 285 170 243 285 minecraft:packed_ice
fill 170 242 289 170 243 289 minecraft:packed_ice
fill 171 242 290 171 243 290 minecraft:packed_ice
fill 172 242 283 172 243 283 minecraft:packed_ice
fill 173 242 291 174 243 291 minecraft:packed_ice
fill 175 242 283 175 243 283 minecraft:packed_ice
fill 176 242 290 176 243 290 minecraft:packed_ice
setblock 177 242 276 minecraft:snow_block
fill 177 242 277 177 245 277 minecraft:packed_ice
fill 177 242 284 177 243 284 minecraft:packed_ice
fill 177 242 289 177 243 289 minecraft:packed_ice
fill 178 242 275 178 308 275 minecraft:snow_block
fill 178 242 276 178 245 276 minecraft:packed_ice
fill 178 242 287 178 243 287 minecraft:packed_ice
setblock 179 242 278 minecraft:packed_ice
setblock 179 242 283 minecraft:packed_ice
setblock 179 242 284 minecraft:snow_block
setblock 180 242 278 minecraft:snow_block
fill 180 242 279 180 245 279 minecraft:packed_ice
setblock 180 242 283 minecraft:snow_block
fill 180 242 284 180 245 284 minecraft:packed_ice
setblock 181 242 277 minecraft:snow_block
fill 181 242 278 181 245 278 minecraft:packed_ice
setblock 181 242 282 minecraft:snow_block
fill 181 242 283 181 245 283 minecraft:packed_ice
setblock 181 242 287 minecraft:snow_block
fill 181 242 288 181 245 288 minecraft:packed_ice
setblock 181 242 302 minecraft:snow_block
fill 181 242 303 181 245 303 minecraft:packed_ice
setblock 182 242 276 minecraft:snow_block
fill 182 242 277 182 245 277 minecraft:packed_ice
setblock 182 242 281 minecraft:snow_block
fill 182 242 282 182 245 282 minecraft:packed_ice
setblock 182 242 286 minecraft:snow_block
fill 182 242 287 182 245 287 minecraft:packed_ice
setblock 182 242 291 minecraft:snow_block
fill 182 242 292 182 245 292 minecraft:packed_ice
setblock 182 242 296 minecraft:snow_block
setblock 182 242 297 minecraft:packed_ice
setblock 182 242 301 minecraft:snow_block
fill 182 242 302 182 245 302 minecraft:packed_ice
setblock 182 242 306 minecraft:snow_block
fill 182 242 307 182 245 307 minecraft:packed_ice
setblock 183 242 279 minecraft:light_blue_concrete
fill 183 242 292 183 254 292 minecraft:snow_block
fill 183 242 310 183 295 310 minecraft:snow_block
fill 141 243 297 141 256 297 minecraft:snow_block
fill 141 243 308 141 257 311 minecraft:snow_block
setblock 141 243 312 minecraft:light_blue_concrete
fill 142 243 276 145 243 276 minecraft:packed_ice
setblock 142 243 280 minecraft:snow_block
fill 142 243 281 142 246 281 minecraft:packed_ice
setblock 142 243 285 minecraft:snow_block
fill 142 243 286 142 246 286 minecraft:packed_ice
setblock 142 243 300 minecraft:snow_block
fill 142 243 301 142 246 301 minecraft:packed_ice
setblock 142 243 305 minecraft:snow_block
fill 142 243 306 143 245 306 minecraft:packed_ice
setblock 142 243 309 minecraft:packed_ice
setblock 142 243 310 minecraft:snow_block
fill 142 243 311 142 246 311 minecraft:packed_ice
setblock 142 243 314 minecraft:packed_ice
setblock 142 243 315 minecraft:snow_block
fill 142 243 316 142 246 316 minecraft:packed_ice
setblock 143 243 279 minecraft:snow_block
fill 143 243 280 143 246 280 minecraft:packed_ice
setblock 143 243 284 minecraft:snow_block
fill 143 243 285 143 246 285 minecraft:packed_ice
setblock 143 243 304 minecraft:snow_block
fill 143 243 305 143 246 305 minecraft:packed_ice
fill 143 243 307 143 244 307 minecraft:packed_ice
fill 156 243 316 156 243 317 minecraft:snow_block
fill 157 243 316 157 246 316 minecraft:packed_ice
fill 160 243 275 174 246 275 minecraft:snow_block
fill 169 243 285 169 243 288 minecraft:packed_ice
setblock 170 243 284 minecraft:packed_ice
setblock 170 243 290 minecraft:packed_ice
setblock 171 243 283 minecraft:packed_ice
setblock 172 243 291 minecraft:packed_ice
fill 173 243 282 174 243 282 minecraft:packed_ice
setblock 175 243 275 minecraft:white_concrete
fill 175 243 291 176 243 291 minecraft:packed_ice
fill 176 243 275 176 243 276 minecraft:snow_block
fill 177 243 275 177 291 275 minecraft:snow_block
fill 177 243 276 177 246 276 minecraft:packed_ice
setblock 177 243 290 minecraft:packed_ice
setblock 178 243 278 minecraft:packed_ice
fill 178 243 285 178 243 286 minecraft:packed_ice
setblock 178 243 288 minecraft:packed_ice
setblock 179 243 278 minecraft:snow_block
setblock 179 243 283 minecraft:snow_block
fill 179 243 284 179 245 285 minecraft:packed_ice
setblock 180 243 277 minecraft:snow_block
fill 180 243 278 180 246 278 minecraft:packed_ice
setblock 180 243 282 minecraft:snow_block
fill 180 243 283 180 246 283 minecraft:packed_ice
setblock 180 243 287 minecraft:snow_block
fill 180 243 288 180 246 288 minecraft:packed_ice
setblock 181 243 276 minecraft:snow_block
fill 181 243 277 181 246 277 minecraft:packed_ice
setblock 181 243 281 minecraft:snow_block
fill 181 243 282 181 246 282 minecraft:packed_ice
setblock 181 243 286 minecraft:snow_block
fill 181 243 287 181 246 287 minecraft:packed_ice
setblock 181 243 302 minecraft:packed_ice
setblock 181 243 306 minecraft:snow_block
fill 182 243 276 182 246 276 minecraft:packed_ice
setblock 182 243 280 minecraft:snow_block
fill 182 243 281 182 246 281 minecraft:packed_ice
setblock 182 243 285 minecraft:snow_block
fill 182 243 286 182 246 286 minecraft:packed_ice
setblock 182 243 290 minecraft:snow_block
fill 182 243 291 182 246 291 minecraft:packed_ice
setblock 182 243 300 minecraft:snow_block
fill 182 243 301 182 246 301 minecraft:packed_ice
setblock 182 243 305 minecraft:snow_block
fill 182 243 306 182 246 306 minecraft:packed_ice
setblock 182 243 309 minecraft:packed_ice
fill 183 243 279 183 259 279 minecraft:snow_block
setblock 141 244 312 minecraft:white_concrete
fill 142 244 276 144 244 276 minecraft:packed_ice
setblock 142 244 279 minecraft:snow_block
fill 142 244 280 142 247 280 minecraft:packed_ice
setblock 142 244 284 minecraft:snow_block
fill 142 244 285 142 247 285 minecraft:packed_ice
setblock 142 244 289 minecraft:snow_block
setblock 142 244 304 minecraft:snow_block
fill 142 244 305 142 247 305 minecraft:packed_ice
setblock 142 244 309 minecraft:snow_block
fill 142 244 310 142 247 310 minecraft:packed_ice
setblock 142 244 314 minecraft:snow_block
fill 142 244 315 142 247 315 minecraft:packed_ice
setblock 143 244 278 minecraft:snow_block
fill 143 244 279 143 245 279 minecraft:packed_ice
setblock 143 244 283 minecraft:snow_block
fill 143 244 284 143 247 284 minecraft:packed_ice
fill 143 244 304 143 247 304 minecraft:packed_ice
setblock 143 244 308 minecraft:snow_block
fill 143 244 309 143 247 309 minecraft:packed_ice
setblock 145 244 276 minecraft:snow_block
setblock 150 244 317 minecraft:white_concrete
fill 151 244 317 151 308 317 minecraft:snow_block
setblock 154 244 316 minecraft:packed_ice
setblock 155 244 316 minecraft:snow_block
fill 156 244 316 156 247 316 minecraft:packed_ice
fill 156 244 317 156 308 317 minecraft:snow_block
setblock 160 244 316 minecraft:snow_block
fill 173 244 286 174 245 287 minecraft:blue_ice
fill 175 244 275 175 244 276 minecraft:snow_block
fill 176 244 275 176 308 275 minecraft:snow_block
fill 176 244 276 176 246 277 minecraft:packed_ice
setblock 178 244 278 minecraft:snow_block
setblock 179 244 277 minecraft:snow_block
fill 179 244 278 179 247 278 minecraft:packed_ice
fill 179 244 280 179 244 281 minecraft:packed_ice
setblock 179 244 282 minecraft:snow_block
fill 179 244 283 179 247 283 minecraft:packed_ice
setblock 179 244 286 minecraft:packed_ice
setblock 180 244 276 minecraft:snow_block
fill 180 244 277 180 247 277 minecraft:packed_ice
setblock 180 244 281 minecraft:snow_block
fill 180 244 282 180 247 282 minecraft:packed_ice
setblock 180 244 286 minecraft:snow_block
fill 180 244 287 180 247 287 minecraft:packed_ice
fill 180 244 289 180 245 289 minecraft:packed_ice
fill 180 244 300 180 252 300 minecraft:packed_ice
fill 181 244 276 181 247 276 minecraft:packed_ice
setblock 181 244 280 minecraft:snow_block
fill 181 244 281 181 247 281 minecraft:packed_ice
setblock 181 244 285 minecraft:snow_block
fill 181 244 286 181 247 286 minecraft:packed_ice
setblock 181 244 290 minecraft:snow_block
setblock 181 244 305 minecraft:snow_block
fill 181 244 306 181 246 307 minecraft:packed_ice
setblock 182 244 279 minecraft:snow_block
fill 182 244 280 182 247 280 minecraft:packed_ice
setblock 182 244 284 minecraft:snow_block
fill 182 244 285 182 247 285 minecraft:packed_ice
setblock 182 244 289 minecraft:snow_block
fill 182 244 290 182 247 290 minecraft:packed_ice
setblock 182 244 299 minecraft:snow_block
fill 182 244 300 182 245 300 minecraft:packed_ice
setblock 182 244 304 minecraft:snow_block
fill 182 244 305 182 247 305 minecraft:packed_ice
setblock 182 244 309 minecraft:snow_block
fill 182 244 310 182 246 311 minecraft:packed_ice
setblock 183 244 293 minecraft:light_blue_concrete
setblock 183 244 294 minecraft:white_concrete
fill 141 245 312 141 308 312 minecraft:snow_block
fill 142 245 276 143 245 276 minecraft:packed_ice
setblock 142 245 278 minecraft:snow_block
fill 142 245 279 142 248 279 minecraft:packed_ice
setblock 142 245 283 minecraft:snow_block
fill 142 245 284 142 248 284 minecraft:packed_ice
setblock 142 245 288 minecraft:snow_block
fill 142 245 289 142 248 289 minecraft:packed_ice
setblock 142 245 303 minecraft:snow_block
fill 142 245 304 142 248 304 minecraft:packed_ice
setblock 142 245 308 minecraft:snow_block
fill 142 245 309 142 248 309 minecraft:packed_ice
setblock 142 245 313 minecraft:snow_block
fill 142 245 314 142 248 314 minecraft:packed_ice
setblock 143 245 278 minecraft:packed_ice
setblock 143 245 282 minecraft:snow_block
fill 143 245 283 143 247 283 minecraft:packed_ice
setblock 143 245 286 minecraft:packed_ice
setblock 143 245 307 minecraft:snow_block
fill 143 245 308 143 248 308 minecraft:packed_ice
fill 143 245 310 143 245 311 minecraft:packed_ice
setblock 143 245 316 minecraft:packed_ice
setblock 144 245 276 minecraft:snow_block
setblock 144 245 316 minecraft:snow_block
fill 150 245 317 150 308 317 minecraft:snow_block
setblock 153 245 316 minecraft:packed_ice
setblock 154 245 316 minecraft:snow_block
fill 155 245 316 155 248 316 minecraft:packed_ice
setblock 159 245 316 minecraft:snow_block
fill 160 245 316 160 248 316 minecraft:packed_ice
setblock 174 245 276 minecraft:snow_block
fill 175 245 275 175 270 275 minecraft:snow_block
fill 175 245 276 175 248 276 minecraft:packed_ice
setblock 177 245 278 minecraft:snow_block
setblock 178 245 277 minecraft:snow_block
fill 178 245 278 178 248 278 minecraft:packed_ice
setblock 179 245 276 minecraft:snow_block
fill 179 245 277 179 248 277 minecraft:packed_ice
setblock 179 245 280 minecraft:packed_ice
setblock 179 245 281 minecraft:snow_block
fill 179 245 282 179 248 282 minecraft:packed_ice
setblock 179 245 286 minecraft:snow_block
fill 179 245 287 179 248 287 minecraft:packed_ice
setblock 179 245 316 minecraft:snow_block
fill 180 245 276 180 248 276 minecraft:packed_ice
setblock 180 245 280 minecraft:snow_block
fill 180 245 281 180 248 281 minecraft:packed_ice
setblock 180 245 285 minecraft:snow_block
fill 180 245 286 180 248 286 minecraft:packed_ice
fill 180 245 316 181 247 316 minecraft:packed_ice
setblock 181 245 279 minecraft:snow_block
fill 181 245 280 181 248 280 minecraft:packed_ice
setblock 181 245 284 minecraft:snow_block
fill 181 245 285 181 248 285 minecraft:packed_ice
setblock 181 245 289 minecraft:snow_block
fill 181 245 290 181 247 291 minecraft:packed_ice
setblock 181 245 304 minecraft:snow_block
fill 181 245 305 181 248 305 minecraft:packed_ice
setblock 181 245 308 minecraft:packed_ice
setblock 182 245 278 minecraft:snow_block
fill 182 245 279 182 248 279 minecraft:packed_ice
setblock 182 245 283 minecraft:snow_block
fill 182 245 284 182 248 284 minecraft:packed_ice
setblock 182 245 288 minecraft:snow_block
fill 182 245 289 182 248 289 minecraft:packed_ice
setblock 182 245 303 minecraft:snow_block
fill 182 245 304 182 248 304 minecraft:packed_ice
setblock 182 245 308 minecraft:snow_block
fill 182 245 309 182 248 309 minecraft:packed_ice
setblock 182 245 312 minecraft:packed_ice
setblock 182 245 313 minecraft:snow_block
fill 183 245 293 183 297 294 minecraft:snow_block
fill 141 246 298 141 256 300 minecraft:snow_block
setblock 141 246 301 minecraft:light_blue_concrete
fill 141 246 302 141 271 303 minecraft:snow_block
setblock 142 246 276 minecraft:packed_ice
setblock 142 246 277 minecraft:snow_block
fill 142 246 278 142 249 278 minecraft:packed_ice
setblock 142 246 282 minecraft:snow_block
fill 142 246 283 142 249 283 minecraft:packed_ice
setblock 142 246 287 minecraft:snow_block
fill 142 246 288 142 249 288 minecraft:packed_ice
fill 142 246 290 142 247 290 minecraft:packed_ice
setblock 142 246 302 minecraft:snow_block
fill 142 246 303 142 249 303 minecraft:packed_ice
setblock 142 246 306 minecraft:packed_ice
setblock 142 246 307 minecraft:snow_block
fill 142 246 308 142 249 308 minecraft:packed_ice
setblock 142 246 312 minecraft:snow_block
fill 142 246 313 143 248 313 minecraft:packed_ice
fill 143 246 275 143 246 276 minecraft:snow_block
setblock 143 246 281 minecraft:snow_block
fill 143 246 282 143 247 282 minecraft:packed_ice
setblock 143 246 286 minecraft:snow_block
setblock 143 246 306 minecraft:snow_block
fill 143 246 307 143 249 307 minecraft:packed_ice
setblock 143 246 310 minecraft:packed_ice
setblock 143 246 311 minecraft:snow_block
fill 143 246 312 143 249 312 minecraft:packed_ice
setblock 143 246 316 minecraft:snow_block
fill 144 246 275 145 308 275 minecraft:snow_block
setblock 144 246 276 minecraft:packed_ice
setblock 144 246 278 minecraft:light[level=12]
setblock 144 246 285 minecraft:light[level=12]
setblock 144 246 292 minecraft:light[level=12]
setblock 144 246 299 minecraft:light[level=12]
setblock 144 246 306 minecraft:light[level=12]
setblock 144 246 313 minecraft:light[level=12]
fill 144 246 316 145 248 316 minecraft:packed_ice
setblock 146 246 275 minecraft:white_concrete
fill 147 246 275 148 259 275 minecraft:snow_block
setblock 151 246 278 minecraft:light[level=12]
setblock 151 246 285 minecraft:light[level=12]
setblock 151 246 292 minecraft:light[level=12]
setblock 151 246 299 minecraft:light[level=12]
setblock 151 246 306 minecraft:light[level=12]
setblock 151 246 313 minecraft:light[level=12]
fill 151 246 316 152 246 316 minecraft:packed_ice
setblock 153 246 316 minecraft:snow_block
fill 154 246 316 154 249 316 minecraft:packed_ice
fill 155 246 315 158 246 315 minecraft:packed_ice
setblock 157 246 276 minecraft:packed_ice
setblock 158 246 278 minecraft:light[level=12]
setblock 158 246 285 minecraft:light[level=12]
setblock 158 246 292 minecraft:light[level=12]
setblock 158 246 299 minecraft:light[level=12]
setblock 158 246 306 minecraft:light[level=12]
setblock 158 246 313 minecraft:light[level=12]
setblock 158 246 316 minecraft:snow_block
fill 159 246 316 159 249 316 minecraft:packed_ice
setblock 165 246 278 minecraft:light[level=12]
setblock 165 246 285 minecraft:light[level=12]
setblock 165 246 292 minecraft:light[level=12]
setblock 165 246 299 minecraft:light[level=12]
setblock 165 246 306 minecraft:light[level=12]
setblock 165 246 313 minecraft:light[level=12]
setblock 172 246 278 minecraft:light[level=12]
setblock 172 246 285 minecraft:light[level=12]
setblock 172 246 292 minecraft:light[level=12]
setblock 172 246 299 minecraft:light[level=12]
setblock 172 246 306 minecraft:light[level=12]
setblock 172 246 313 minecraft:light[level=12]
fill 173 246 287 174 246 287 minecraft:blue_ice
fill 174 246 276 174 249 276 minecraft:packed_ice
fill 175 246 277 175 247 277 minecraft:packed_ice
setblock 177 246 277 minecraft:snow_block
fill 177 246 278 177 249 278 minecraft:packed_ice
setblock 177 246 316 minecraft:packed_ice
setblock 178 246 276 minecraft:snow_block
fill 178 246 277 178 249 277 minecraft:packed_ice
fill 178 246 284 178 246 285 minecraft:packed_ice
setblock 178 246 316 minecraft:snow_block
fill 179 246 276 179 249 276 minecraft:packed_ice
setblock 179 246 280 minecraft:snow_block
fill 179 246 281 179 248 281 minecraft:packed_ice
setblock 179 246 284 minecraft:packed_ice
setblock 179 246 285 minecraft:snow_block
fill 179 246 286 179 249 286 minecraft:packed_ice
fill 179 246 288 179 247 288 minecraft:packed_ice
setblock 179 246 292 minecraft:light[level=12]
setblock 179 246 299 minecraft:light[level=12]
setblock 179 246 306 minecraft:light[level=12]
setblock 179 246 313 minecraft:light[level=12]
fill 179 246 316 179 249 316 minecraft:packed_ice
setblock 180 246 279 minecraft:snow_block
fill 180 246 280 180 249 280 minecraft:packed_ice
setblock 180 246 284 minecraft:snow_block
fill 180 246 285 180 249 285 minecraft:packed_ice
setblock 180 246 289 minecraft:snow_block
fill 180 246 290 180 249 290 minecraft:packed_ice
setblock 181 246 278 minecraft:snow_block
fill 181 246 279 181 249 279 minecraft:packed_ice
setblock 181 246 283 minecraft:snow_block
fill 181 246 284 181 249 284 minecraft:packed_ice
setblock 181 246 288 minecraft:snow_block
fill 181 246 289 181 249 289 minecraft:packed_ice
fill 181 246 304 181 247 304 minecraft:packed_ice
setblock 181 246 308 minecraft:snow_block
fill 181 246 309 181 248 310 minecraft:packed_ice
setblock 182 246 277 minecraft:snow_block
fill 182 246 278 182 249 278 minecraft:packed_ice
setblock 182 246 282 minecraft:snow_block
fill 182 246 283 182 249 283 minecraft:packed_ice
setblock 182 246 287 minecraft:snow_block
fill 182 246 288 182 249 288 minecraft:packed_ice
setblock 182 246 292 minecraft:snow_block
fill 182 246 293 182 249 293 minecraft:packed_ice
setblock 182 246 302 minecraft:snow_block
fill 182 246 303 182 248 303 minecraft:packed_ice
setblock 182 246 307 minecraft:snow_block
fill 182 246 308 182 249 308 minecraft:packed_ice
fill 182 246 312 183 246 312 minecraft:snow_block
fill 182 246 313 182 246 316 minecraft:packed_ice
setblock 183 246 277 minecraft:white_concrete
fill 183 246 278 183 286 278 minecraft:snow_block
fill 183 246 311 183 295 311 minecraft:snow_block
setblock 183 246 313 minecraft:white_concrete
fill 141 247 301 141 308 301 minecraft:snow_block
setblock 142 247 276 minecraft:snow_block
fill 142 247 277 142 249 277 minecraft:packed_ice
setblock 142 247 281 minecraft:snow_block
fill 142 247 282 142 250 282 minecraft:packed_ice
setblock 142 247 286 minecraft:snow_block
fill 142 247 287 142 250 287 minecraft:packed_ice
fill 142 247 302 142 248 302 minecraft:packed_ice
setblock 142 247 306 minecraft:snow_block
fill 142 247 307 142 250 307 minecraft:packed_ice
setblock 142 247 311 minecraft:snow_block
fill 142 247 312 142 250 312 minecraft:packed_ice
setblock 142 247 316 minecraft:snow_block
fill 143 247 275 143 308 275 minecraft:snow_block
fill 143 247 276 143 248 276 minecraft:packed_ice
setblock 143 247 285 minecraft:snow_block
setblock 143 247 286 minecraft:packed_ice
setblock 143 247 305 minecraft:snow_block
fill 143 247 306 143 250 306 minecraft:packed_ice
setblock 143 247 310 minecraft:snow_block
fill 143 247 311 143 250 311 minecraft:packed_ice
setblock 143 247 314 minecraft:packed_ice
fill 143 247 316 143 250 316 minecraft:packed_ice
fill 146 247 275 146 271 275 minecraft:snow_block
setblock 146 247 316 minecraft:packed_ice
setblock 147 247 316 minecraft:snow_block
fill 148 247 316 151 247 316 minecraft:packed_ice
setblock 152 247 315 minecraft:packed_ice
setblock 152 247 316 minecraft:snow_block
setblock 153 247 315 minecraft:snow_block
fill 153 247 316 153 250 316 minecraft:packed_ice
fill 154 247 315 157 247 315 minecraft:packed_ice
fill 155 247 276 156 247 276 minecraft:packed_ice
setblock 157 247 276 minecraft:snow_block
setblock 157 247 316 minecraft:snow_block
setblock 158 247 315 minecraft:snow_block
fill 158 247 316 158 250 316 minecraft:packed_ice
fill 159 247 315 159 250 315 minecraft:packed_ice
fill 160 247 275 164 260 275 minecraft:snow_block
setblock 165 247 275 minecraft:light_blue_concrete
fill 166 247 275 174 250 275 minecraft:snow_block
fill 173 247 276 173 250 276 minecraft:packed_ice
fill 174 247 277 174 248 277 minecraft:packed_ice
setblock 174 247 287 minecraft:blue_ice
fill 175 247 316 176 247 316 minecraft:packed_ice
setblock 176 247 276 minecraft:packed_ice
setblock 176 247 277 minecraft:snow_block
fill 176 247 278 176 250 278 minecraft:packed_ice
setblock 177 247 276 minecraft:snow_block
fill 177 247 277 177 250 277 minecraft:packed_ice
setblock 177 247 316 minecraft:snow_block
fill 178 247 276 178 250 276 minecraft:packed_ice
setblock 178 247 284 minecraft:packed_ice
setblock 178 247 285 minecraft:snow_block
fill 178 247 286 178 249 286 minecraft:packed_ice
fill 178 247 316 178 250 316 minecraft:packed_ice
setblock 179 247 280 minecraft:packed_ice
setblock 179 247 284 minecraft:snow_block
fill 179 247 285 179 250 285 minecraft:packed_ice
setblock 179 247 289 minecraft:snow_block
setblock 180 247 278 minecraft:snow_block
fill 180 247 279 180 248 279 minecraft:packed_ice
setblock 180 247 283 minecraft:snow_block
fill 180 247 284 180 250 284 minecraft:packed_ice
setblock 180 247 288 minecraft:snow_block
fill 180 247 289 180 250 289 minecraft:packed_ice
setblock 181 247 277 minecraft:snow_block
fill 181 247 278 181 250 278 minecraft:packed_ice
setblock 181 247 282 minecraft:snow_block
fill 181 247 283 181 250 283 minecraft:packed_ice
setblock 181 247 287 minecraft:snow_block
fill 181 247 288 181 250 288 minecraft:packed_ice
setblock 181 247 292 minecraft:snow_block
setblock 181 247 306 minecraft:packed_ice
setblock 181 247 307 minecraft:snow_block
fill 181 247 308 181 250 308 minecraft:packed_ice
setblock 181 247 311 minecraft:packed_ice
setblock 181 247 312 minecraft:snow_block
setblock 182 247 276 minecraft:snow_block
fill 182 247 277 182 250 277 minecraft:packed_ice
setblock 182 247 281 minecraft:snow_block
fill 182 247 282 182 250 282 minecraft:packed_ice
setblock 182 247 286 minecraft:snow_block
fill 182 247 287 182 250 287 minecraft:packed_ice
setblock 182 247 291 minecraft:snow_block
fill 182 247 292 182 250 292 minecraft:packed_ice
setblock 182 247 302 minecraft:packed_ice
setblock 182 247 306 minecraft:snow_block
fill 182 247 307 182 250 307 minecraft:packed_ice
setblock 182 247 310 minecraft:packed_ice
setblock 182 247 311 minecraft:snow_block
fill 182 247 312 182 247 315 minecraft:packed_ice
setblock 182 247 316 minecraft:snow_block
setblock 182 247 317 minecraft:white_concrete
fill 183 247 277 183 262 277 minecraft:snow_block
fill 183 247 301 183 308 301 minecraft:snow_block
setblock 183 247 302 minecraft:white_concrete
fill 183 247 312 183 253 313 minecraft:snow_block
fill 142 248 276 142 250 276 minecraft:packed_ice
setblock 142 248 280 minecraft:snow_block
fill 142 248 281 142 250 281 minecraft:packed_ice
setblock 142 248 285 minecraft:snow_block
fill 142 248 286 142 251 286 minecraft:packed_ice
setblock 142 248 290 minecraft:snow_block
fill 142 248 291 142 250 291 minecraft:packed_ice
setblock 142 248 305 minecraft:snow_block
fill 142 248 306 142 251 306 minecraft:packed_ice
setblock 142 248 310 minecraft:snow_block
fill 142 248 311 142 251 311 minecraft:packed_ice
setblock 142 248 315 minecraft:snow_block
fill 142 248 316 142 251 316 minecraft:packed_ice
setblock 143 248 284 minecraft:snow_block
setblock 143 248 285 minecraft:packed_ice
fill 143 248 305 143 249 305 minecraft:packed_ice
setblock 143 248 309 minecraft:snow_block
fill 143 248 310 143 251 310 minecraft:packed_ice
setblock 143 248 314 minecraft:snow_block
fill 143 248 315 143 251 315 minecraft:packed_ice
setblock 144 248 278 minecraft:light[level=15]
setblock 144 248 286 minecraft:light[level=15]
setblock 144 248 294 minecraft:light[level=15]
setblock 144 248 302 minecraft:light[level=15]
fill 144 248 309 144 249 309 minecraft:packed_ice
setblock 144 248 310 minecraft:light[level=15]
setblock 146 248 316 minecraft:snow_block
fill 147 248 316 150 248 316 minecraft:packed_ice
fill 149 248 296 149 249 297 minecraft:snow_block
setblock 151 248 315 minecraft:packed_ice
setblock 151 248 316 minecraft:snow_block
setblock 152 248 278 minecraft:light[level=15]
setblock 152 248 286 minecraft:light[level=15]
setblock 152 248 294 minecraft:light[level=15]
setblock 152 248 302 minecraft:light[level=15]
setblock 152 248 310 minecraft:light[level=15]
setblock 152 248 315 minecraft:snow_block
fill 152 248 316 152 251 316 minecraft:packed_ice
setblock 153 248 314 minecraft:snow_block
fill 153 248 315 156 248 315 minecraft:packed_ice
fill 154 248 276 155 248 276 minecraft:packed_ice
fill 154 248 314 157 248 314 minecraft:packed_ice
setblock 156 248 276 minecraft:snow_block
setblock 156 248 316 minecraft:snow_block
fill 157 248 276 157 249 276 minecraft:packed_ice
setblock 157 248 315 minecraft:snow_block
fill 157 248 316 157 251 316 minecraft:packed_ice
fill 158 248 315 158 251 315 minecraft:packed_ice
setblock 160 248 278 minecraft:light[level=15]
setblock 160 248 286 minecraft:light[level=15]
setblock 160 248 302 minecraft:light[level=15]
setblock 160 248 310 minecraft:light[level=15]
fill 165 248 275 165 297 275 minecraft:snow_block
setblock 165 248 317 minecraft:light_blue_concrete
fill 166 248 317 166 308 317 minecraft:snow_block
setblock 168 248 278 minecraft:light[level=15]
setblock 168 248 286 minecraft:light[level=15]
setblock 168 248 294 minecraft:light[level=15]
setblock 168 248 302 minecraft:light[level=15]
setblock 168 248 310 minecraft:light[level=15]
fill 172 248 276 172 251 276 minecraft:packed_ice
fill 174 248 316 175 248 316 minecraft:packed_ice
setblock 175 248 277 minecraft:snow_block
setblock 176 248 276 minecraft:snow_block
fill 176 248 277 176 251 277 minecraft:packed_ice
setblock 176 248 286 minecraft:light[level=15]
setblock 176 248 294 minecraft:light[level=15]
setblock 176 248 302 minecraft:light[level=15]
setblock 176 248 310 minecraft:light[level=15]
setblock 176 248 316 minecraft:snow_block
fill 177 248 276 177 251 276 minecraft:packed_ice
setblock 177 248 315 minecraft:snow_block
fill 177 248 316 177 251 316 minecraft:packed_ice
setblock 178 248 284 minecraft:snow_block
fill 178 248 285 178 249 285 minecraft:packed_ice
fill 178 248 287 178 249 287 minecraft:packed_ice
fill 178 248 315 179 250 315 minecraft:packed_ice
setblock 179 248 278 minecraft:snow_block
setblock 179 248 283 minecraft:snow_block
fill 179 248 284 179 250 284 minecraft:packed_ice
setblock 179 248 288 minecraft:snow_block
fill 179 248 289 179 250 289 minecraft:packed_ice
fill 179 248 300 179 252 300 minecraft:packed_ice
setblock 180 248 277 minecraft:snow_block
setblock 180 248 282 minecraft:snow_block
fill 180 248 283 180 250 283 minecraft:packed_ice
setblock 180 248 287 minecraft:snow_block
fill 180 248 288 180 251 288 minecraft:packed_ice
setblock 180 248 291 minecraft:packed_ice
fill 180 248 299 180 252 299 minecraft:packed_ice
fill 180 248 301 180 252 301 minecraft:packed_ice
setblock 180 248 316 minecraft:packed_ice
setblock 181 248 276 minecraft:snow_block
fill 181 248 277 181 250 277 minecraft:packed_ice
setblock 181 248 281 minecraft:snow_block
fill 181 248 282 181 251 282 minecraft:packed_ice
setblock 181 248 286 minecraft:snow_block
fill 181 248 287 181 251 287 minecraft:packed_ice
setblock 181 248 290 minecraft:packed_ice
setblock 181 248 291 minecraft:snow_block
fill 181 248 292 181 250 292 minecraft:packed_ice
fill 181 248 300 181 252 300 minecraft:packed_ice
setblock 181 248 306 minecraft:snow_block
fill 181 248 307 181 250 307 minecraft:packed_ice
setblock 181 248 311 minecraft:snow_block
fill 181 248 312 182 249 313 minecraft:packed_ice
setblock 181 248 316 minecraft:snow_block
fill 182 248 276 182 251 276 minecraft:packed_ice
setblock 182 248 280 minecraft:snow_block
fill 182 248 281 182 251 281 minecraft:packed_ice
setblock 182 248 285 minecraft:snow_block
fill 182 248 286 182 251 286 minecraft:packed_ice
setblock 182 248 290 minecraft:snow_block
fill 182 248 291 182 251 291 minecraft:packed_ice
setblock 182 248 305 minecraft:snow_block
fill 182 248 306 182 250 306 minecraft:packed_ice
setblock 182 248 310 minecraft:snow_block
fill 182 248 311 182 251 311 minecraft:packed_ice
setblock 182 248 314 minecraft:packed_ice
setblock 182 248 315 minecraft:snow_block
fill 182 248 316 182 251 316 minecraft:packed_ice
fill 182 248 317 182 308 317 minecraft:snow_block
fill 183 248 302 183 308 302 minecraft:snow_block
setblock 183 248 304 minecraft:light_blue_concrete
setblock 142 249 279 minecraft:snow_block
setblock 142 249 280 minecraft:packed_ice
setblock 142 249 284 minecraft:snow_block
fill 142 249 285 142 251 285 minecraft:packed_ice
setblock 142 249 289 minecraft:snow_block
fill 142 249 290 142 251 290 minecraft:packed_ice
setblock 142 249 304 minecraft:snow_block
fill 142 249 305 142 252 305 minecraft:packed_ice
setblock 142 249 309 minecraft:snow_block
fill 142 249 310 142 252 310 minecraft:packed_ice
setblock 142 249 313 minecraft:packed_ice
setblock 142 249 314 minecraft:snow_block
fill 142 249 315 142 252 315 minecraft:packed_ice
setblock 143 249 308 minecraft:snow_block
fill 143 249 309 143 252 309 minecraft:packed_ice
setblock 143 249 313 minecraft:snow_block
fill 143 249 314 143 252 314 minecraft:packed_ice
fill 144 249 310 144 250 310 minecraft:packed_ice
fill 144 249 315 144 249 316 minecraft:packed_ice
setblock 145 249 316 minecraft:snow_block
fill 146 249 316 149 249 316 minecraft:packed_ice
fill 149 249 315 150 249 315 minecraft:packed_ice
setblock 150 249 316 minecraft:snow_block
setblock 151 249 315 minecraft:snow_block
fill 151 249 316 151 252 316 minecraft:packed_ice
setblock 152 249 314 minecraft:snow_block
fill 152 249 315 155 249 315 minecraft:packed_ice
fill 153 249 314 156 249 314 minecraft:packed_ice
setblock 154 249 276 minecraft:packed_ice
setblock 155 249 276 minecraft:snow_block
setblock 155 249 316 minecraft:snow_block
fill 156 249 276 156 250 276 minecraft:packed_ice
setblock 156 249 315 minecraft:snow_block
fill 156 249 316 156 252 316 minecraft:packed_ice
setblock 157 249 314 minecraft:snow_block
fill 157 249 315 157 252 315 minecraft:packed_ice
setblock 160 249 316 minecraft:snow_block
fill 165 249 317 165 300 317 minecraft:snow_block
setblock 173 249 277 minecraft:packed_ice
fill 173 249 316 174 249 316 minecraft:packed_ice
setblock 174 249 277 minecraft:snow_block
setblock 175 249 276 minecraft:snow_block
fill 175 249 277 175 252 277 minecraft:packed_ice
setblock 175 249 315 minecraft:packed_ice
setblock 175 249 316 minecraft:snow_block
fill 176 249 276 176 252 276 minecraft:packed_ice
setblock 176 249 315 minecraft:snow_block
fill 176 249 316 176 252 316 minecraft:packed_ice
fill 177 249 315 177 252 315 minecraft:packed_ice
setblock 178 249 278 minecraft:snow_block
setblock 179 249 277 minecraft:snow_block
fill 179 249 282 179 272 282 minecraft:snow_block
setblock 179 249 283 minecraft:packed_ice
setblock 179 249 287 minecraft:snow_block
fill 179 249 288 179 250 288 minecraft:packed_ice
fill 179 249 299 179 252 299 minecraft:packed_ice
fill 179 249 301 179 252 301 minecraft:packed_ice
setblock 180 249 276 minecraft:snow_block
fill 180 249 277 180 251 277 minecraft:packed_ice
setblock 180 249 281 minecraft:snow_block
fill 180 249 282 180 250 282 minecraft:packed_ice
setblock 180 249 286 minecraft:snow_block
fill 180 249 287 180 251 287 minecraft:packed_ice
setblock 180 249 291 minecraft:snow_block
setblock 180 249 315 minecraft:packed_ice
setblock 180 249 316 minecraft:snow_block
fill 181 249 276 181 252 276 minecraft:packed_ice
setblock 181 249 280 minecraft:snow_block
fill 181 249 281 181 251 281 minecraft:packed_ice
setblock 181 249 285 minecraft:snow_block
fill 181 249 286 181 252 286 minecraft:packed_ice
setblock 181 249 290 minecraft:snow_block
fill 181 249 291 181 251 291 minecraft:packed_ice
fill 181 249 299 181 252 299 minecraft:packed_ice
fill 181 249 301 181 252 301 minecraft:packed_ice
setblock 181 249 306 minecraft:packed_ice
setblock 181 249 309 minecraft:packed_ice
setblock 181 249 310 minecraft:snow_block
fill 181 249 311 181 252 311 minecraft:packed_ice
setblock 181 249 314 minecraft:packed_ice
fill 181 249 316 181 252 316 minecraft:packed_ice
setblock 181 249 317 minecraft:light_blue_concrete
setblock 182 249 279 minecraft:snow_block
fill 182 249 280 182 251 280 minecraft:packed_ice
setblock 182 249 284 minecraft:snow_block
fill 182 249 285 182 252 285 minecraft:packed_ice
setblock 182 249 289 minecraft:snow_block
fill 182 249 290 182 252 290 minecraft:packed_ice
fill 182 249 304 183 249 304 minecraft:snow_block
fill 182 249 305 182 250 305 minecraft:packed_ice
setblock 182 249 309 minecraft:snow_block
fill 182 249 310 182 252 310 minecraft:packed_ice
setblock 182 249 314 minecraft:snow_block
fill 182 249 315 182 252 315 minecraft:packed_ice
setblock 142 250 283 minecraft:snow_block
setblock 142 250 284 minecraft:packed_ice
setblock 142 250 288 minecraft:snow_block
fill 142 250 289 142 251 289 minecraft:packed_ice
setblock 142 250 303 minecraft:snow_block
fill 142 250 304 142 251 304 minecraft:packed_ice
setblock 142 250 308 minecraft:snow_block
fill 142 250 309 142 253 309 minecraft:packed_ice
setblock 142 250 313 minecraft:snow_block
fill 142 250 314 142 253 314 minecraft:packed_ice
setblock 143 250 307 minecraft:snow_block
fill 143 250 308 143 252 308 minecraft:packed_ice
setblock 143 250 312 minecraft:snow_block
fill 143 250 313 143 253 313 minecraft:packed_ice
setblock 144 250 311 minecraft:snow_block
setblock 144 250 315 minecraft:packed_ice
setblock 144 250 316 minecraft:snow_block
fill 145 250 316 148 250 316 minecraft:packed_ice
fill 147 250 315 149 250 315 minecraft:packed_ice
setblock 149 250 316 minecraft:snow_block
setblock 150 250 314 minecraft:packed_ice
setblock 150 250 315 minecraft:snow_block
fill 150 250 316 150 253 316 minecraft:packed_ice
setblock 151 250 314 minecraft:snow_block
fill 151 250 315 154 250 315 minecraft:packed_ice
fill 152 250 314 155 250 314 minecraft:packed_ice
fill 153 250 313 155 251 313 minecraft:packed_ice
setblock 154 250 276 minecraft:snow_block
setblock 154 250 316 minecraft:snow_block
fill 155 250 276 155 251 276 minecraft:packed_ice
fill 155 250 290 157 251 290 minecraft:snow_block
setblock 155 250 315 minecraft:snow_block
fill 155 250 316 155 253 316 minecraft:packed_ice
fill 156 250 289 156 251 289 minecraft:snow_block
fill 156 250 291 156 251 291 minecraft:snow_block
setblock 156 250 314 minecraft:snow_block
fill 156 250 315 156 253 315 minecraft:packed_ice
fill 157 250 314 157 251 314 minecraft:packed_ice
setblock 159 250 316 minecraft:snow_block
setblock 160 250 316 minecraft:packed_ice
fill 171 250 276 171 252 276 minecraft:packed_ice
fill 172 250 316 173 250 316 minecraft:packed_ice
setblock 173 250 277 minecraft:snow_block
setblock 174 250 276 minecraft:snow_block
fill 174 250 277 174 253 277 minecraft:packed_ice
fill 174 250 294 174 251 294 minecraft:white_concrete
setblock 174 250 315 minecraft:packed_ice
setblock 174 250 316 minecraft:snow_block
fill 175 250 276 175 253 276 minecraft:packed_ice
setblock 175 250 315 minecraft:snow_block
fill 175 250 316 175 253 316 minecraft:packed_ice
fill 176 250 315 176 253 315 minecraft:packed_ice
setblock 177 250 278 minecraft:snow_block
setblock 178 250 277 minecraft:snow_block
setblock 179 250 276 minecraft:snow_block
fill 179 250 277 179 252 277 minecraft:packed_ice
setblock 179 250 286 minecraft:snow_block
setblock 179 250 287 minecraft:packed_ice
setblock 179 250 316 minecraft:snow_block
fill 180 250 276 180 253 276 minecraft:packed_ice
setblock 180 250 281 minecraft:packed_ice
setblock 180 250 285 minecraft:snow_block
fill 180 250 286 180 251 286 minecraft:packed_ice
setblock 180 250 290 minecraft:snow_block
setblock 180 250 315 minecraft:snow_block
fill 180 250 316 180 253 316 minecraft:packed_ice
setblock 181 250 279 minecraft:snow_block
setblock 181 250 280 minecraft:packed_ice
setblock 181 250 284 minecraft:snow_block
fill 181 250 285 181 252 285 minecraft:packed_ice
setblock 181 250 289 minecraft:snow_block
fill 181 250 290 181 252 290 minecraft:packed_ice
setblock 181 250 309 minecraft:snow_block
fill 181 250 310 181 251 310 minecraft:packed_ice
fill 181 250 312 181 250 313 minecraft:packed_ice
setblock 181 250 314 minecraft:snow_block
fill 181 250 315 181 251 315 minecraft:packed_ice
fill 181 250 317 181 301 317 minecraft:snow_block
setblock 182 250 278 minecraft:snow_block
fill 182 250 279 182 251 279 minecraft:packed_ice
setblock 182 250 283 minecraft:snow_block
fill 182 250 284 182 252 284 minecraft:packed_ice
setblock 182 250 288 minecraft:snow_block
fill 182 250 289 182 253 289 minecraft:packed_ice
setblock 182 250 293 minecraft:snow_block
setblock 182 250 308 minecraft:snow_block
fill 182 250 309 182 253 309 minecraft:packed_ice
setblock 182 250 312 minecraft:packed_ice
setblock 182 250 313 minecraft:snow_block
fill 182 250 314 182 253 314 minecraft:packed_ice
fill 183 250 304 183 265 304 minecraft:snow_block
setblock 142 251 287 minecraft:snow_block
setblock 142 251 288 minecraft:packed_ice
setblock 142 251 307 minecraft:snow_block
fill 142 251 308 142 254 308 minecraft:packed_ice
setblock 142 251 312 minecraft:snow_block
fill 142 251 313 142 254 313 minecraft:packed_ice
setblock 143 251 307 minecraft:packed_ice
setblock 143 251 311 minecraft:snow_block
fill 143 251 312 143 254 312 minecraft:packed_ice
setblock 143 251 316 minecraft:snow_block
setblock 144 251 315 minecraft:snow_block
fill 144 251 316 147 251 316 minecraft:packed_ice
fill 145 251 315 148 251 315 minecraft:packed_ice
setblock 148 251 316 minecraft:snow_block
setblock 149 251 315 minecraft:snow_block
fill 149 251 316 149 254 316 minecraft:packed_ice
setblock 150 251 314 minecraft:snow_block
fill 150 251 315 153 251 315 minecraft:packed_ice
fill 151 251 314 154 251 314 minecraft:packed_ice
fill 152 251 313 152 252 313 minecraft:packed_ice
setblock 153 251 316 minecraft:snow_block
setblock 154 251 276 minecraft:packed_ice
setblock 154 251 315 minecraft:snow_block
fill 154 251 316 154 254 316 minecraft:packed_ice
setblock 155 251 314 minecraft:snow_block
fill 155 251 315 155 254 315 minecraft:packed_ice
fill 156 251 314 156 252 314 minecraft:packed_ice
setblock 158 251 316 minecraft:snow_block
fill 159 251 316 159 252 316 minecraft:packed_ice
fill 166 251 275 170 251 275 minecraft:snow_block
setblock 171 251 275 minecraft:light_blue_concrete
fill 171 251 314 172 251 315 minecraft:blue_ice
fill 171 251 316 172 251 316 minecraft:packed_ice
fill 172 251 275 174 251 275 minecraft:snow_block
setblock 173 251 276 minecraft:snow_block
fill 173 251 277 173 254 277 minecraft:packed_ice
fill 173 251 314 173 254 314 minecraft:blue_ice
setblock 173 251 315 minecraft:packed_ice
setblock 173 251 316 minecraft:snow_block
fill 174 251 276 174 254 276 minecraft:packed_ice
setblock 174 251 315 minecraft:snow_block
fill 174 251 316 174 254 316 minecraft:packed_ice
fill 175 251 315 175 254 315 minecraft:packed_ice
setblock 177 251 277 minecraft:snow_block
setblock 178 251 276 minecraft:snow_block
fill 178 251 277 178 253 277 minecraft:packed_ice
setblock 178 251 315 minecraft:packed_ice
setblock 178 251 316 minecraft:snow_block
fill 179 251 276 179 254 276 minecraft:packed_ice
setblock 179 251 315 minecraft:snow_block
fill 179 251 316 179 254 316 minecraft:packed_ice
setblock 180 251 284 minecraft:snow_block
setblock 180 251 285 minecraft:packed_ice
setblock 180 251 289 minecraft:snow_block
fill 180 251 315 180 253 315 minecraft:packed_ice
setblock 181 251 283 minecraft:snow_block
setblock 181 251 284 minecraft:packed_ice
setblock 181 251 288 minecraft:snow_block
fill 181 251 289 181 252 289 minecraft:packed_ice
setblock 181 251 309 minecraft:packed_ice
setblock 181 251 312 minecraft:packed_ice
setblock 181 251 313 minecraft:snow_block
fill 181 251 314 181 252 314 minecraft:packed_ice
setblock 182 251 277 minecraft:snow_block
setblock 182 251 278 minecraft:packed_ice
setblock 182 251 282 minecraft:snow_block
fill 182 251 283 182 252 283 minecraft:packed_ice
setblock 182 251 287 minecraft:snow_block
fill 182 251 288 182 253 288 minecraft:packed_ice
setblock 182 251 292 minecraft:snow_block
setblock 182 251 307 minecraft:snow_block
fill 182 251 308 182 252 308 minecraft:packed_ice
setblock 182 251 312 minecraft:snow_block
fill 182 251 313 182 254 313 minecraft:packed_ice
setblock 141 252 315 minecraft:white_concrete
fill 141 252 316 142 252 316 minecraft:snow_block
setblock 142 252 306 minecraft:snow_block
fill 142 252 307 142 253 307 minecraft:packed_ice
setblock 142 252 311 minecraft:snow_block
fill 142 252 312 142 255 312 minecraft:packed_ice
setblock 143 252 310 minecraft:snow_block
fill 143 252 311 143 255 311 minecraft:packed_ice
setblock 143 252 315 minecraft:snow_block
fill 143 252 316 146 252 316 minecraft:packed_ice
setblock 144 252 278 minecraft:light[level=12]
setblock 144 252 285 minecraft:light[level=12]
setblock 144 252 292 minecraft:light[level=12]
setblock 144 252 299 minecraft:light[level=12]
setblock 144 252 306 minecraft:light[level=12]
setblock 144 252 313 minecraft:light[level=12]
fill 144 252 315 147 252 315 minecraft:packed_ice
setblock 147 252 316 minecraft:snow_block
setblock 148 252 315 minecraft:snow_block
fill 148 252 316 148 255 316 minecraft:packed_ice
setblock 149 252 314 minecraft:snow_block
fill 149 252 315 152 252 315 minecraft:packed_ice
fill 150 252 314 153 252 314 minecraft:packed_ice
setblock 151 252 278 minecraft:light[level=12]
setblock 151 252 285 minecraft:light[level=12]
setblock 151 252 292 minecraft:light[level=12]
setblock 151 252 299 minecraft:light[level=12]
setblock 151 252 306 minecraft:light[level=12]
setblock 151 252 313 minecraft:light[level=12]
setblock 152 252 316 minecraft:snow_block
fill 153 252 313 154 252 313 minecraft:packed_ice
setblock 153 252 315 minecraft:snow_block
fill 153 252 316 153 255 316 minecraft:packed_ice
setblock 154 252 314 minecraft:snow_block
fill 154 252 315 154 255 315 minecraft:packed_ice
fill 155 252 314 155 254 314 minecraft:packed_ice
setblock 157 252 316 minecraft:snow_block
setblock 158 252 278 minecraft:light[level=12]
setblock 158 252 285 minecraft:light[level=12]
setblock 158 252 292 minecraft:light[level=12]
setblock 158 252 299 minecraft:light[level=12]
setblock 158 252 306 minecraft:light[level=12]
setblock 158 252 313 minecraft:light[level=12]
setblock 158 252 315 minecraft:snow_block
fill 158 252 316 158 254 316 minecraft:packed_ice
fill 161 252 287 161 253 288 minecraft:white_concrete
setblock 165 252 278 minecraft:light[level=12]
setblock 165 252 285 minecraft:light[level=12]
setblock 165 252 292 minecraft:light[level=12]
setblock 165 252 299 minecraft:light[level=12]
setblock 165 252 306 minecraft:light[level=12]
setblock 165 252 313 minecraft:light[level=12]
fill 166 252 275 169 267 275 minecraft:snow_block
setblock 170 252 275 minecraft:light_blue_concrete
fill 170 252 276 170 253 276 minecraft:packed_ice
fill 170 252 315 171 253 315 minecraft:blue_ice
fill 170 252 316 171 252 316 minecraft:packed_ice
fill 171 252 275 172 297 275 minecraft:snow_block
fill 171 252 313 172 254 314 minecraft:blue_ice
setblock 172 252 276 minecraft:snow_block
setblock 172 252 278 minecraft:light[level=12]
setblock 172 252 285 minecraft:light[level=12]
setblock 172 252 292 minecraft:light[level=12]
setblock 172 252 299 minecraft:light[level=12]
setblock 172 252 306 minecraft:light[level=12]
fill 172 252 312 172 254 312 minecraft:blue_ice
setblock 172 252 315 minecraft:packed_ice
setblock 172 252 316 minecraft:snow_block
setblock 173 252 275 minecraft:light_blue_concrete
fill 173 252 276 173 255 276 minecraft:packed_ice
fill 173 252 313 173 254 313 minecraft:blue_ice
setblock 173 252 315 minecraft:snow_block
fill 173 252 316 173 255 316 minecraft:packed_ice
fill 174 252 275 174 280 275 minecraft:snow_block
fill 174 252 315 174 255 315 minecraft:packed_ice
setblock 176 252 277 minecraft:snow_block
setblock 177 252 276 minecraft:snow_block
fill 177 252 277 177 254 277 minecraft:packed_ice
setblock 177 252 316 minecraft:snow_block
fill 178 252 276 178 255 276 minecraft:packed_ice
setblock 178 252 300 minecraft:packed_ice
setblock 178 252 315 minecraft:snow_block
fill 178 252 316 178 255 316 minecraft:packed_ice
setblock 179 252 278 minecraft:light[level=12]
setblock 179 252 285 minecraft:light[level=12]
setblock 179 252 292 minecraft:light[level=12]
setblock 179 252 306 minecraft:light[level=12]
setblock 179 252 313 minecraft:light[level=12]
fill 179 252 315 179 255 315 minecraft:packed_ice
setblock 180 252 298 minecraft:packed_ice
setblock 180 252 302 minecraft:packed_ice
setblock 181 252 287 minecraft:snow_block
setblock 181 252 288 minecraft:packed_ice
setblock 181 252 312 minecraft:snow_block
fill 181 252 313 181 253 313 minecraft:packed_ice
setblock 182 252 276 minecraft:snow_block
setblock 182 252 277 minecraft:packed_ice
setblock 182 252 281 minecraft:snow_block
setblock 182 252 282 minecraft:packed_ice
fill 182 252 286 183 252 286 minecraft:snow_block
fill 182 252 287 182 253 287 minecraft:packed_ice
setblock 182 252 291 minecraft:snow_block
setblock 182 252 292 minecraft:packed_ice
setblock 182 252 300 minecraft:packed_ice
setblock 182 252 311 minecraft:snow_block
fill 182 252 312 182 255 312 minecraft:packed_ice
setblock 182 252 316 minecraft:snow_block
setblock 183 252 280 minecraft:white_concrete
fill 183 252 287 183 308 287 minecraft:snow_block
setblock 183 252 288 minecraft:light_blue_concrete
fill 183 252 289 183 283 289 minecraft:snow_block
fill 141 253 282 141 265 284 minecraft:snow_block
setblock 141 253 285 minecraft:light_blue_concrete
fill 141 253 286 141 280 286 minecraft:snow_block
fill 141 253 315 141 308 316 minecraft:snow_block
setblock 142 253 310 minecraft:snow_block
fill 142 253 311 142 256 311 minecraft:packed_ice
setblock 142 253 315 minecraft:snow_block
fill 142 253 316 145 253 316 minecraft:packed_ice
setblock 143 253 309 minecraft:snow_block
fill 143 253 310 143 254 310 minecraft:packed_ice
setblock 143 253 314 minecraft:snow_block
fill 143 253 315 146 253 315 minecraft:packed_ice
setblock 146 253 316 minecraft:snow_block
setblock 147 253 315 minecraft:snow_block
fill 147 253 316 147 256 316 minecraft:packed_ice
fill 148 253 315 151 253 315 minecraft:packed_ice
fill 149 253 314 152 253 314 minecraft:packed_ice
setblock 151 253 316 minecraft:snow_block
setblock 152 253 315 minecraft:snow_block
fill 152 253 316 152 256 316 minecraft:packed_ice
setblock 153 253 314 minecraft:snow_block
fill 153 253 315 153 256 315 minecraft:packed_ice
fill 154 253 314 154 255 314 minecraft:packed_ice
setblock 156 253 316 minecraft:snow_block
setblock 157 253 315 minecraft:snow_block
fill 157 253 316 157 256 316 minecraft:packed_ice
fill 162 253 290 162 272 290 minecraft:snow_block
fill 170 253 275 170 308 275 minecraft:snow_block
setblock 170 253 316 minecraft:packed_ice
setblock 171 253 276 minecraft:snow_block
fill 171 253 311 171 253 312 minecraft:blue_ice
setblock 171 253 316 minecraft:snow_block
fill 172 253 276 172 255 277 minecraft:packed_ice
fill 172 253 310 172 254 311 minecraft:blue_ice
setblock 172 253 315 minecraft:snow_block
fill 172 253 316 172 256 316 minecraft:packed_ice
fill 173 253 275 173 308 275 minecraft:snow_block
fill 173 253 311 173 253 312 minecraft:blue_ice
fill 173 253 315 173 256 315 minecraft:packed_ice
setblock 175 253 277 minecraft:snow_block
setblock 176 253 276 minecraft:snow_block
fill 176 253 277 176 256 277 minecraft:packed_ice
setblock 176 253 316 minecraft:snow_block
fill 177 253 276 177 256 276 minecraft:packed_ice
setblock 177 253 315 minecraft:snow_block
fill 177 253 316 177 256 316 minecraft:packed_ice
fill 178 253 315 178 256 315 minecraft:packed_ice
setblock 181 253 276 minecraft:snow_block
setblock 181 253 316 minecraft:snow_block
setblock 182 253 285 minecraft:snow_block
setblock 182 253 286 minecraft:packed_ice
setblock 182 253 290 minecraft:snow_block
setblock 182 253 291 minecraft:packed_ice
setblock 182 253 310 minecraft:snow_block
fill 182 253 311 182 256 311 minecraft:packed_ice
setblock 182 253 315 minecraft:snow_block
fill 182 253 316 182 256 316 minecraft:packed_ice
fill 183 253 280 183 276 280 minecraft:snow_block
fill 183 253 286 183 281 286 minecraft:snow_block
fill 183 253 288 183 308 288 minecraft:snow_block
fill 141 254 285 141 283 285 minecraft:snow_block
setblock 142 254 309 minecraft:snow_block
fill 142 254 310 142 257 310 minecraft:packed_ice
setblock 142 254 314 minecraft:snow_block
fill 142 254 315 142 256 316 minecraft:packed_ice
setblock 143 254 313 minecraft:snow_block
fill 143 254 314 143 257 314 minecraft:packed_ice
fill 143 254 316 144 254 316 minecraft:packed_ice
setblock 145 254 315 minecraft:packed_ice
setblock 145 254 316 minecraft:snow_block
setblock 146 254 315 minecraft:snow_block
fill 146 254 316 146 257 316 minecraft:packed_ice
fill 147 254 315 150 254 315 minecraft:packed_ice
fill 149 254 314 151 254 314 minecraft:packed_ice
setblock 150 254 316 minecraft:snow_block
setblock 151 254 315 minecraft:snow_block
fill 151 254 316 151 257 316 minecraft:packed_ice
setblock 152 254 314 minecraft:snow_block
fill 152 254 315 152 257 315 minecraft:packed_ice
fill 153 254 314 153 257 314 minecraft:packed_ice
setblock 155 254 316 minecraft:snow_block
setblock 156 254 315 minecraft:snow_block
fill 156 254 316 156 257 316 minecraft:packed_ice
setblock 169 254 276 minecraft:packed_ice
setblock 169 254 316 minecraft:packed_ice
setblock 170 254 276 minecraft:snow_block
setblock 170 254 316 minecraft:snow_block
fill 171 254 276 171 257 276 minecraft:packed_ice
setblock 171 254 315 minecraft:snow_block
fill 171 254 316 171 257 316 minecraft:packed_ice
setblock 172 254 309 minecraft:blue_ice
fill 172 254 315 172 257 315 minecraft:packed_ice
setblock 174 254 277 minecraft:snow_block
setblock 175 254 276 minecraft:snow_block
fill 175 254 277 175 257 277 minecraft:packed_ice
setblock 175 254 316 minecraft:snow_block
fill 176 254 276 176 257 276 minecraft:packed_ice
setblock 176 254 315 minecraft:snow_block
fill 176 254 316 176 257 316 minecraft:packed_ice
fill 177 254 315 177 257 315 minecraft:packed_ice
setblock 180 254 276 minecraft:snow_block
setblock 180 254 316 minecraft:snow_block
setblock 181 254 276 minecraft:packed_ice
fill 181 254 316 181 257 316 minecraft:packed_ice
setblock 182 254 310 minecraft:packed_ice
setblock 182 254 314 minecraft:snow_block
fill 182 254 315 182 257 315 minecraft:packed_ice
fill 183 254 312 183 308 312 minecraft:snow_block
setblock 183 254 313 minecraft:white_concrete
setblock 141 255 296 minecraft:light_blue_concrete
setblock 142 255 308 minecraft:snow_block
fill 142 255 309 142 258 309 minecraft:packed_ice
setblock 142 255 313 minecraft:snow_block
fill 142 255 314 142 258 314 minecraft:packed_ice
setblock 143 255 312 minecraft:snow_block
fill 143 255 313 143 258 313 minecraft:packed_ice
setblock 143 255 316 minecraft:packed_ice
setblock 144 255 316 minecraft:snow_block
setblock 145 255 315 minecraft:snow_block
fill 145 255 316 145 258 316 minecraft:packed_ice
fill 146 255 315 149 255 315 minecraft:packed_ice
setblock 148 255 317 minecraft:white_concrete
fill 149 255 314 150 255 314 minecraft:packed_ice
fill 149 255 316 149 255 317 minecraft:snow_block
setblock 150 255 315 minecraft:snow_block
fill 150 255 316 150 258 316 minecraft:packed_ice
setblock 151 255 314 minecraft:snow_block
fill 151 255 315 151 258 315 minecraft:packed_ice
fill 152 255 314 152 258 314 minecraft:packed_ice
setblock 154 255 316 minecraft:snow_block
setblock 155 255 315 minecraft:snow_block
fill 155 255 316 155 258 316 minecraft:packed_ice
setblock 156 255 315 minecraft:packed_ice
setblock 169 255 276 minecraft:snow_block
setblock 169 255 316 minecraft:snow_block
fill 170 255 276 170 258 276 minecraft:packed_ice
fill 170 255 316 170 258 316 minecraft:packed_ice
fill 171 255 277 171 256 277 minecraft:packed_ice
fill 171 255 294 171 256 294 minecraft:white_concrete
fill 171 255 315 171 258 315 minecraft:packed_ice
setblock 173 255 277 minecraft:snow_block
setblock 174 255 276 minecraft:snow_block
fill 174 255 277 174 258 277 minecraft:packed_ice
fill 174 255 283 175 256 284 minecraft:white_concrete
setblock 174 255 316 minecraft:snow_block
fill 175 255 276 175 258 276 minecraft:packed_ice
setblock 175 255 315 minecraft:snow_block
fill 175 255 316 175 258 316 minecraft:packed_ice
fill 176 255 315 176 258 315 minecraft:packed_ice
fill 178 255 304 178 261 304 minecraft:packed_ice
setblock 179 255 276 minecraft:snow_block
setblock 179 255 316 minecraft:snow_block
fill 180 255 276 180 258 276 minecraft:packed_ice
fill 180 255 316 180 258 316 minecraft:packed_ice
fill 182 255 313 183 255 313 minecraft:snow_block
fill 182 255 314 182 258 314 minecraft:packed_ice
setblock 183 255 292 minecraft:white_concrete
setblock 141 256 294 minecraft:light_blue_concrete
fill 141 256 295 141 263 296 minecraft:snow_block
setblock 142 256 312 minecraft:snow_block
fill 142 256 313 142 259 313 minecraft:packed_ice
fill 143 256 312 143 259 312 minecraft:packed_ice
setblock 143 256 315 minecraft:packed_ice
setblock 143 256 316 minecraft:snow_block
setblock 144 256 278 minecraft:light[level=15]
setblock 144 256 286 minecraft:light[level=15]
setblock 144 256 294 minecraft:light[level=15]
setblock 144 256 302 minecraft:light[level=15]
setblock 144 256 310 minecraft:light[level=15]
setblock 144 256 315 minecraft:snow_block
fill 144 256 316 144 259 316 minecraft:packed_ice
fill 145 256 315 148 256 315 minecraft:packed_ice
fill 148 256 314 149 256 314 minecraft:packed_ice
fill 148 256 316 148 256 317 minecraft:snow_block
setblock 149 256 315 minecraft:snow_block
fill 149 256 316 149 259 316 minecraft:packed_ice
fill 149 256 317 149 308 317 minecraft:snow_block
fill 150 256 275 156 258 275 minecraft:snow_block
setblock 150 256 314 minecraft:snow_block
fill 150 256 315 150 259 315 minecraft:packed_ice
fill 151 256 314 151 259 314 minecraft:packed_ice
setblock 152 256 276 minecraft:packed_ice
setblock 152 256 278 minecraft:light[level=15]
setblock 152 256 286 minecraft:light[level=15]
setblock 152 256 294 minecraft:light[level=15]
setblock 152 256 302 minecraft:light[level=15]
setblock 152 256 310 minecraft:light[level=15]
setblock 153 256 316 minecraft:snow_block
setblock 154 256 315 minecraft:snow_block
fill 154 256 316 154 259 316 minecraft:packed_ice
fill 155 256 315 155 258 315 minecraft:packed_ice
setblock 157 256 275 minecraft:light_blue_concrete
fill 158 256 275 158 308 275 minecraft:snow_block
setblock 160 256 278 minecraft:light[level=15]
setblock 160 256 286 minecraft:light[level=15]
setblock 160 256 302 minecraft:light[level=15]
setblock 160 256 310 minecraft:light[level=15]
setblock 168 256 276 minecraft:snow_block
setblock 168 256 278 minecraft:light[level=15]
setblock 168 256 286 minecraft:light[level=15]
setblock 168 256 294 minecraft:light[level=15]
setblock 168 256 302 minecraft:light[level=15]
setblock 168 256 310 minecraft:light[level=15]
setblock 168 256 316 minecraft:snow_block
fill 169 256 276 169 259 276 minecraft:packed_ice
fill 169 256 316 169 259 316 minecraft:packed_ice
fill 170 256 277 170 257 277 minecraft:packed_ice
fill 170 256 315 170 259 315 minecraft:packed_ice
setblock 172 256 276 minecraft:packed_ice
setblock 172 256 277 minecraft:snow_block
setblock 173 256 276 minecraft:snow_block
fill 173 256 277 173 259 277 minecraft:packed_ice
setblock 173 256 316 minecraft:snow_block
fill 174 256 276 174 259 276 minecraft:packed_ice
setblock 174 256 315 minecraft:snow_block
fill 174 256 316 174 259 316 minecraft:packed_ice
fill 175 256 315 175 259 315 minecraft:packed_ice
setblock 176 256 278 minecraft:light[level=15]
setblock 176 256 286 minecraft:light[level=15]
setblock 176 256 294 minecraft:light[level=15]
setblock 176 256 302 minecraft:light[level=15]
setblock 176 256 310 minecraft:light[level=15]
setblock 178 256 276 minecraft:snow_block
setblock 178 256 316 minecraft:snow_block
fill 179 256 276 179 259 276 minecraft:packed_ice
setblock 179 256 315 minecraft:snow_block
fill 179 256 316 179 259 316 minecraft:packed_ice
fill 181 256 276 181 257 276 minecraft:packed_ice
setblock 182 256 312 minecraft:snow_block
fill 182 256 313 182 259 313 minecraft:packed_ice
fill 183 256 292 183 306 292 minecraft:snow_block
fill 183 256 313 183 308 313 minecraft:snow_block
setblock 141 257 277 minecraft:white_concrete
fill 141 257 294 141 302 294 minecraft:snow_block
setblock 141 257 297 minecraft:white_concrete
fill 141 257 298 141 308 299 minecraft:snow_block
setblock 141 257 300 minecraft:white_concrete
setblock 142 257 311 minecraft:snow_block
fill 142 257 312 142 260 312 minecraft:packed_ice
setblock 142 257 315 minecraft:packed_ice
setblock 142 257 316 minecraft:snow_block
setblock 143 257 315 minecraft:snow_block
fill 143 257 316 143 260 316 minecraft:packed_ice
fill 144 257 315 147 257 315 minecraft:packed_ice
setblock 147 257 316 minecraft:snow_block
setblock 148 257 314 minecraft:packed_ice
setblock 148 257 315 minecraft:snow_block
fill 148 257 316 148 260 316 minecraft:packed_ice
fill 148 257 317 148 308 317 minecraft:snow_block
fill 149 257 276 151 257 276 minecraft:packed_ice
setblock 149 257 314 minecraft:snow_block
fill 149 257 315 149 260 315 minecraft:packed_ice
fill 150 257 314 150 260 314 minecraft:packed_ice
setblock 152 257 276 minecraft:snow_block
setblock 152 257 316 minecraft:snow_block
fill 153 257 276 153 260 276 minecraft:packed_ice
setblock 153 257 315 minecraft:snow_block
fill 153 257 316 153 260 316 minecraft:packed_ice
fill 154 257 315 154 260 315 minecraft:packed_ice
setblock 157 257 275 minecraft:snow_block
setblock 157 257 316 minecraft:snow_block
setblock 167 257 276 minecraft:snow_block
setblock 167 257 316 minecraft:snow_block
fill 168 257 276 168 260 276 minecraft:packed_ice
fill 168 257 316 168 260 316 minecraft:packed_ice
fill 169 257 277 169 258 277 minecraft:packed_ice
fill 169 257 315 169 260 315 minecraft:packed_ice
setblock 171 257 277 minecraft:snow_block
setblock 172 257 276 minecraft:snow_block
fill 172 257 277 172 260 277 minecraft:packed_ice
setblock 172 257 316 minecraft:snow_block
fill 173 257 276 173 260 276 minecraft:packed_ice
setblock 173 257 315 minecraft:snow_block
fill 173 257 316 173 260 316 minecraft:packed_ice
fill 174 257 315 174 260 315 minecraft:packed_ice
setblock 176 257 277 minecraft:snow_block
setblock 177 257 276 minecraft:snow_block
setblock 177 257 316 minecraft:snow_block
fill 178 257 276 178 260 276 minecraft:packed_ice
setblock 178 257 315 minecraft:snow_block
fill 178 257 316 178 260 316 minecraft:packed_ice
fill 179 257 315 179 260 315 minecraft:packed_ice
setblock 182 257 276 minecraft:snow_block
setblock 182 257 311 minecraft:snow_block
fill 182 257 312 182 260 312 minecraft:packed_ice
setblock 182 257 316 minecraft:snow_block
setblock 183 257 305 minecraft:light_blue_concrete
fill 141 258 277 141 291 277 minecraft:snow_block
fill 141 258 297 141 300 297 minecraft:snow_block
fill 141 258 300 141 306 300 minecraft:snow_block
setblock 141 258 308 minecraft:white_concrete
fill 141 258 309 141 263 311 minecraft:snow_block
setblock 142 258 310 minecraft:snow_block
fill 142 258 311 142 261 311 minecraft:packed_ice
setblock 142 258 315 minecraft:snow_block
fill 142 258 316 142 261 316 minecraft:packed_ice
setblock 143 258 314 minecraft:snow_block
fill 143 258 315 146 258 315 minecraft:packed_ice
setblock 144 258 278 minecraft:light[level=12]
setblock 144 258 285 minecraft:light[level=12]
setblock 144 258 292 minecraft:light[level=12]
setblock 144 258 299 minecraft:light[level=12]
setblock 144 258 306 minecraft:light[level=12]
setblock 144 258 313 minecraft:light[level=12]
setblock 146 258 316 minecraft:snow_block
fill 147 258 276 150 258 276 minecraft:packed_ice
setblock 147 258 314 minecraft:packed_ice
setblock 147 258 315 minecraft:snow_block
fill 147 258 316 147 261 316 minecraft:packed_ice
setblock 148 258 314 minecraft:snow_block
fill 148 258 315 148 261 315 minecraft:packed_ice
fill 149 258 314 149 261 314 minecraft:packed_ice
setblock 151 258 276 minecraft:snow_block
setblock 151 258 278 minecraft:light[level=12]
setblock 151 258 285 minecraft:light[level=12]
setblock 151 258 292 minecraft:light[level=12]
setblock 151 258 299 minecraft:light[level=12]
setblock 151 258 306 minecraft:light[level=12]
setblock 151 258 313 minecraft:light[level=12]
setblock 151 258 316 minecraft:snow_block
fill 152 258 276 152 261 276 minecraft:packed_ice
setblock 152 258 315 minecraft:snow_block
fill 152 258 316 152 261 316 minecraft:packed_ice
fill 153 258 315 153 261 315 minecraft:packed_ice
fill 154 258 276 154 259 276 minecraft:packed_ice
setblock 156 258 316 minecraft:snow_block
setblock 157 258 275 minecraft:white_concrete
fill 157 258 316 157 261 316 minecraft:packed_ice
setblock 158 258 278 minecraft:light[level=12]
setblock 158 258 285 minecraft:light[level=12]
setblock 158 258 292 minecraft:light[level=12]
setblock 158 258 299 minecraft:light[level=12]
setblock 158 258 306 minecraft:light[level=12]
setblock 158 258 313 minecraft:light[level=12]
setblock 165 258 276 minecraft:packed_ice
setblock 165 258 278 minecraft:light[level=12]
setblock 165 258 285 minecraft:light[level=12]
setblock 165 258 292 minecraft:light[level=12]
setblock 165 258 299 minecraft:light[level=12]
setblock 165 258 306 minecraft:light[level=12]
setblock 165 258 313 minecraft:light[level=12]
setblock 166 258 276 minecraft:snow_block
setblock 166 258 316 minecraft:snow_block
fill 167 258 276 167 261 276 minecraft:packed_ice
fill 167 258 316 167 261 316 minecraft:packed_ice
fill 168 258 277 168 259 277 minecraft:packed_ice
fill 168 258 315 168 261 315 minecraft:packed_ice
setblock 170 258 277 minecraft:snow_block
setblock 171 258 276 minecraft:snow_block
fill 171 258 277 171 261 277 minecraft:packed_ice
setblock 171 258 316 minecraft:snow_block
fill 172 258 276 172 261 276 minecraft:packed_ice
fill 172 258 278 172 259 278 minecraft:packed_ice
setblock 172 258 285 minecraft:light[level=12]
setblock 172 258 292 minecraft:light[level=12]
setblock 172 258 299 minecraft:light[level=12]
setblock 172 258 306 minecraft:light[level=12]
setblock 172 258 313 minecraft:light[level=12]
setblock 172 258 315 minecraft:snow_block
fill 172 258 316 172 261 316 minecraft:packed_ice
fill 173 258 315 173 261 315 minecraft:packed_ice
setblock 175 258 277 minecraft:snow_block
schedule function dropper:buildpart/63_10 1t
