setblock 252 51 299 minecraft:light[level=12]
setblock 252 51 306 minecraft:light[level=12]
setblock 252 51 313 minecraft:light[level=12]
setblock 259 51 278 minecraft:light[level=12]
setblock 259 51 285 minecraft:light[level=12]
setblock 259 51 292 minecraft:light[level=12]
setblock 259 51 299 minecraft:light[level=12]
setblock 259 51 306 minecraft:light[level=12]
setblock 259 51 313 minecraft:light[level=12]
setblock 266 51 278 minecraft:light[level=12]
setblock 266 51 285 minecraft:light[level=12]
setblock 266 51 292 minecraft:light[level=12]
setblock 266 51 299 minecraft:light[level=12]
setblock 266 51 306 minecraft:light[level=12]
setblock 266 51 313 minecraft:light[level=12]
fill 270 51 289 275 51 295 minecraft:chiseled_sandstone
setblock 273 51 278 minecraft:light[level=12]
setblock 273 51 285 minecraft:light[level=12]
setblock 273 51 299 minecraft:light[level=12]
setblock 273 51 306 minecraft:light[level=12]
setblock 273 51 313 minecraft:light[level=12]
fill 274 51 300 274 52 306 minecraft:iron_block
fill 277 51 293 277 83 293 minecraft:smooth_sandstone
fill 235 52 275 235 92 278 minecraft:smooth_sandstone
setblock 235 52 279 minecraft:lapis_block
fill 235 52 281 235 65 281 minecraft:smooth_sandstone
fill 235 52 282 235 52 283 minecraft:glowstone
fill 235 52 284 235 65 284 minecraft:smooth_sandstone
fill 235 52 293 235 65 293 minecraft:smooth_sandstone
fill 235 52 294 235 52 295 minecraft:glowstone
fill 235 52 296 235 65 296 minecraft:smooth_sandstone
fill 235 52 305 235 65 305 minecraft:smooth_sandstone
fill 235 52 306 235 52 307 minecraft:glowstone
fill 235 52 308 235 65 308 minecraft:smooth_sandstone
fill 235 52 317 235 65 317 minecraft:smooth_sandstone
fill 236 52 317 237 52 317 minecraft:glowstone
fill 238 52 317 238 65 317 minecraft:smooth_sandstone
fill 242 52 275 242 65 275 minecraft:smooth_sandstone
fill 243 52 275 244 52 275 minecraft:glowstone
fill 245 52 275 245 65 275 minecraft:smooth_sandstone
fill 247 52 317 247 65 317 minecraft:smooth_sandstone
fill 248 52 317 249 52 317 minecraft:glowstone
fill 250 52 317 250 65 317 minecraft:smooth_sandstone
fill 254 52 275 254 65 275 minecraft:smooth_sandstone
fill 255 52 275 256 52 275 minecraft:glowstone
fill 257 52 275 257 65 275 minecraft:smooth_sandstone
fill 259 52 317 259 65 317 minecraft:smooth_sandstone
fill 260 52 317 261 52 317 minecraft:glowstone
fill 262 52 317 262 65 317 minecraft:smooth_sandstone
fill 266 52 275 266 65 275 minecraft:smooth_sandstone
fill 267 52 275 268 52 275 minecraft:glowstone
setblock 268 52 317 minecraft:black_terracotta
fill 269 52 275 269 65 275 minecraft:smooth_sandstone
fill 270 52 289 275 52 295 minecraft:cut_sandstone
fill 271 52 317 271 61 317 minecraft:smooth_sandstone
fill 272 52 317 273 52 317 minecraft:glowstone
fill 274 52 317 274 65 317 minecraft:smooth_sandstone
setblock 276 52 275 minecraft:lapis_block
fill 277 52 275 277 65 276 minecraft:smooth_sandstone
fill 277 52 277 277 52 278 minecraft:glowstone
fill 277 52 279 277 65 279 minecraft:smooth_sandstone
fill 277 52 288 277 65 288 minecraft:smooth_sandstone
fill 277 52 289 277 52 290 minecraft:glowstone
fill 277 52 291 277 65 291 minecraft:smooth_sandstone
fill 277 52 295 277 52 297 minecraft:smooth_sandstone
setblock 277 52 298 minecraft:orange_terracotta
fill 277 52 300 277 65 300 minecraft:smooth_sandstone
fill 277 52 301 277 52 302 minecraft:glowstone
fill 277 52 303 277 55 303 minecraft:smooth_sandstone
fill 277 52 312 277 65 312 minecraft:smooth_sandstone
fill 277 52 313 277 52 314 minecraft:glowstone
fill 277 52 315 277 65 315 minecraft:smooth_sandstone
fill 235 53 279 235 92 279 minecraft:smooth_sandstone
fill 235 53 282 235 65 283 minecraft:smooth_sandstone
fill 235 53 294 235 65 295 minecraft:smooth_sandstone
fill 235 53 306 235 65 307 minecraft:smooth_sandstone
fill 236 53 317 237 65 317 minecraft:smooth_sandstone
fill 239 53 297 240 54 298 minecraft:smooth_sandstone
fill 243 53 275 244 65 275 minecraft:smooth_sandstone
fill 248 53 317 249 65 317 minecraft:smooth_sandstone
fill 255 53 275 256 65 275 minecraft:smooth_sandstone
fill 260 53 317 261 65 317 minecraft:smooth_sandstone
fill 267 53 275 268 65 275 minecraft:smooth_sandstone
fill 268 53 317 268 75 317 minecraft:smooth_sandstone
fill 269 53 277 269 62 277 minecraft:blue_wool
fill 270 53 289 270 53 295 minecraft:lapis_block
fill 272 53 317 273 65 317 minecraft:smooth_sandstone
fill 276 53 275 276 95 275 minecraft:smooth_sandstone
fill 276 53 291 276 56 293 minecraft:glowstone
fill 277 53 277 277 65 278 minecraft:smooth_sandstone
fill 277 53 289 277 65 290 minecraft:smooth_sandstone
setblock 277 53 295 minecraft:orange_terracotta
fill 277 53 296 277 62 298 minecraft:smooth_sandstone
setblock 277 53 299 minecraft:black_terracotta
fill 277 53 301 277 57 302 minecraft:smooth_sandstone
fill 277 53 313 277 53 314 minecraft:smooth_sandstone
setblock 260 54 275 minecraft:blue_terracotta
fill 267 54 277 268 62 277 minecraft:blue_wool
fill 270 54 277 271 59 277 minecraft:blue_wool
setblock 270 54 289 minecraft:cut_sandstone
setblock 270 54 292 minecraft:cut_sandstone
setblock 270 54 295 minecraft:cut_sandstone
fill 277 54 295 277 89 295 minecraft:smooth_sandstone
fill 277 54 299 277 78 299 minecraft:smooth_sandstone
setblock 277 54 313 minecraft:blue_terracotta
fill 277 54 314 277 65 314 minecraft:smooth_sandstone
setblock 238 55 278 minecraft:light[level=15]
setblock 238 55 286 minecraft:light[level=15]
setblock 238 55 294 minecraft:light[level=15]
setblock 238 55 302 minecraft:light[level=15]
setblock 238 55 310 minecraft:light[level=15]
setblock 246 55 278 minecraft:light[level=15]
setblock 246 55 286 minecraft:light[level=15]
setblock 246 55 294 minecraft:light[level=15]
setblock 246 55 302 minecraft:light[level=15]
setblock 246 55 310 minecraft:light[level=15]
setblock 254 55 278 minecraft:light[level=15]
setblock 254 55 286 minecraft:light[level=15]
setblock 254 55 294 minecraft:light[level=15]
setblock 254 55 302 minecraft:light[level=15]
setblock 254 55 310 minecraft:light[level=15]
fill 260 55 275 260 95 275 minecraft:smooth_sandstone
setblock 262 55 278 minecraft:light[level=15]
setblock 262 55 286 minecraft:light[level=15]
setblock 262 55 294 minecraft:light[level=15]
setblock 262 55 302 minecraft:light[level=15]
setblock 262 55 310 minecraft:light[level=15]
setblock 270 55 275 minecraft:orange_terracotta
setblock 270 55 278 minecraft:light[level=15]
setblock 270 55 286 minecraft:light[level=15]
setblock 270 55 294 minecraft:light[level=15]
setblock 270 55 302 minecraft:light[level=15]
setblock 270 55 310 minecraft:light[level=15]
setblock 277 55 311 minecraft:blue_terracotta
fill 277 55 313 277 65 313 minecraft:smooth_sandstone
setblock 243 56 317 minecraft:blue_terracotta
fill 270 56 275 270 88 275 minecraft:smooth_sandstone
setblock 274 56 275 minecraft:lapis_block
setblock 277 56 303 minecraft:orange_terracotta
fill 277 56 311 277 62 311 minecraft:smooth_sandstone
setblock 238 57 278 minecraft:light[level=12]
setblock 238 57 285 minecraft:light[level=12]
setblock 238 57 292 minecraft:light[level=12]
setblock 238 57 299 minecraft:light[level=12]
setblock 238 57 306 minecraft:light[level=12]
setblock 238 57 313 minecraft:light[level=12]
setblock 241 57 275 minecraft:lapis_block
fill 243 57 317 243 95 317 minecraft:smooth_sandstone
setblock 245 57 278 minecraft:light[level=12]
setblock 245 57 285 minecraft:light[level=12]
setblock 245 57 292 minecraft:light[level=12]
setblock 245 57 299 minecraft:light[level=12]
setblock 245 57 306 minecraft:light[level=12]
setblock 245 57 313 minecraft:light[level=12]
fill 250 57 275 251 95 275 minecraft:smooth_sandstone
setblock 252 57 275 minecraft:blue_terracotta
setblock 252 57 278 minecraft:light[level=12]
setblock 252 57 285 minecraft:light[level=12]
setblock 252 57 292 minecraft:light[level=12]
setblock 252 57 299 minecraft:light[level=12]
setblock 252 57 306 minecraft:light[level=12]
setblock 252 57 313 minecraft:light[level=12]
setblock 259 57 278 minecraft:light[level=12]
setblock 259 57 285 minecraft:light[level=12]
setblock 259 57 292 minecraft:light[level=12]
setblock 259 57 299 minecraft:light[level=12]
setblock 259 57 306 minecraft:light[level=12]
setblock 259 57 313 minecraft:light[level=12]
setblock 266 57 278 minecraft:light[level=12]
setblock 266 57 285 minecraft:light[level=12]
setblock 266 57 292 minecraft:light[level=12]
setblock 266 57 299 minecraft:light[level=12]
setblock 266 57 306 minecraft:light[level=12]
setblock 266 57 313 minecraft:light[level=12]
setblock 273 57 278 minecraft:light[level=12]
setblock 273 57 285 minecraft:light[level=12]
setblock 273 57 292 minecraft:light[level=12]
setblock 273 57 299 minecraft:light[level=12]
setblock 273 57 306 minecraft:light[level=12]
setblock 273 57 313 minecraft:light[level=12]
fill 274 57 275 274 91 275 minecraft:smooth_sandstone
fill 277 57 303 277 65 303 minecraft:smooth_sandstone
fill 241 58 275 241 95 275 minecraft:smooth_sandstone
fill 252 58 275 252 67 275 minecraft:smooth_sandstone
fill 277 58 301 277 65 301 minecraft:smooth_sandstone
setblock 277 58 302 minecraft:orange_terracotta
fill 237 59 280 237 59 281 minecraft:chiseled_sandstone
setblock 238 59 279 minecraft:chiseled_sandstone
fill 238 59 282 241 59 282 minecraft:chiseled_sandstone
fill 239 59 278 240 59 278 minecraft:chiseled_sandstone
setblock 241 59 279 minecraft:chiseled_sandstone
fill 277 59 302 277 65 302 minecraft:smooth_sandstone
fill 237 60 285 237 65 287 minecraft:cut_sandstone
fill 237 60 297 237 65 299 minecraft:cut_sandstone
fill 237 60 309 237 65 311 minecraft:cut_sandstone
fill 243 60 315 245 65 315 minecraft:cut_sandstone
fill 247 60 277 249 65 277 minecraft:cut_sandstone
fill 255 60 315 257 65 315 minecraft:cut_sandstone
fill 259 60 277 261 65 277 minecraft:cut_sandstone
fill 267 60 315 269 65 315 minecraft:cut_sandstone
fill 270 60 277 270 62 277 minecraft:blue_wool
fill 271 60 277 273 65 277 minecraft:cut_sandstone
setblock 273 60 275 minecraft:blue_terracotta
fill 275 60 285 275 65 287 minecraft:cut_sandstone
fill 275 60 297 275 65 299 minecraft:cut_sandstone
fill 275 60 309 275 65 311 minecraft:cut_sandstone
setblock 235 61 304 minecraft:black_terracotta
setblock 263 61 275 minecraft:blue_terracotta
fill 273 61 275 273 93 275 minecraft:smooth_sandstone
fill 235 62 304 235 78 304 minecraft:smooth_sandstone
setblock 235 62 310 minecraft:blue_terracotta
fill 263 62 275 263 79 275 minecraft:smooth_sandstone
setblock 271 62 317 minecraft:black_terracotta
fill 235 63 310 235 93 310 minecraft:smooth_sandstone
setblock 238 63 278 minecraft:light[level=15]
setblock 238 63 285 minecraft:light[level=12]
setblock 238 63 286 minecraft:light[level=15]
setblock 238 63 292 minecraft:light[level=12]
setblock 238 63 294 minecraft:light[level=15]
setblock 238 63 299 minecraft:light[level=12]
setblock 238 63 302 minecraft:light[level=15]
setblock 238 63 306 minecraft:light[level=12]
setblock 238 63 310 minecraft:light[level=15]
setblock 238 63 313 minecraft:light[level=12]
setblock 245 63 278 minecraft:light[level=12]
setblock 245 63 285 minecraft:light[level=12]
setblock 245 63 292 minecraft:light[level=12]
setblock 245 63 299 minecraft:light[level=12]
setblock 245 63 306 minecraft:light[level=12]
setblock 245 63 313 minecraft:light[level=12]
setblock 246 63 278 minecraft:light[level=15]
setblock 246 63 286 minecraft:light[level=15]
setblock 246 63 294 minecraft:light[level=15]
setblock 246 63 302 minecraft:light[level=15]
setblock 246 63 310 minecraft:light[level=15]
setblock 252 63 278 minecraft:light[level=12]
setblock 252 63 285 minecraft:light[level=12]
setblock 252 63 292 minecraft:light[level=12]
setblock 252 63 299 minecraft:light[level=12]
setblock 252 63 306 minecraft:light[level=12]
setblock 252 63 313 minecraft:light[level=12]
setblock 254 63 278 minecraft:light[level=15]
setblock 254 63 286 minecraft:light[level=15]
setblock 254 63 294 minecraft:light[level=15]
setblock 254 63 302 minecraft:light[level=15]
setblock 254 63 310 minecraft:light[level=15]
setblock 259 63 278 minecraft:light[level=12]
setblock 259 63 285 minecraft:light[level=12]
setblock 259 63 292 minecraft:light[level=12]
setblock 259 63 299 minecraft:light[level=12]
setblock 259 63 306 minecraft:light[level=12]
setblock 259 63 313 minecraft:light[level=12]
setblock 262 63 278 minecraft:light[level=15]
setblock 262 63 286 minecraft:light[level=15]
setblock 262 63 294 minecraft:light[level=15]
setblock 262 63 302 minecraft:light[level=15]
setblock 262 63 310 minecraft:light[level=15]
fill 266 63 277 270 64 277 minecraft:iron_block
setblock 266 63 278 minecraft:light[level=12]
setblock 266 63 285 minecraft:light[level=12]
setblock 266 63 292 minecraft:light[level=12]
setblock 266 63 299 minecraft:light[level=12]
setblock 266 63 306 minecraft:light[level=12]
setblock 266 63 313 minecraft:light[level=12]
setblock 270 63 278 minecraft:light[level=15]
setblock 270 63 286 minecraft:light[level=15]
setblock 270 63 294 minecraft:light[level=15]
setblock 270 63 302 minecraft:light[level=15]
setblock 270 63 310 minecraft:light[level=15]
fill 271 63 317 271 65 317 minecraft:smooth_sandstone
setblock 273 63 278 minecraft:light[level=12]
setblock 273 63 285 minecraft:light[level=12]
setblock 273 63 292 minecraft:light[level=12]
setblock 273 63 299 minecraft:light[level=12]
setblock 273 63 306 minecraft:light[level=12]
setblock 273 63 313 minecraft:light[level=12]
setblock 277 63 287 minecraft:black_terracotta
fill 277 63 296 277 95 297 minecraft:smooth_sandstone
setblock 277 63 298 minecraft:black_terracotta
setblock 277 63 311 minecraft:orange_terracotta
fill 277 64 287 277 95 287 minecraft:smooth_sandstone
fill 277 64 298 277 91 298 minecraft:smooth_sandstone
fill 277 64 311 277 95 311 minecraft:smooth_sandstone
fill 235 65 299 235 65 300 minecraft:black_terracotta
fill 236 65 279 236 65 284 minecraft:chiseled_sandstone
fill 236 65 291 236 65 296 minecraft:chiseled_sandstone
fill 236 65 303 236 65 308 minecraft:chiseled_sandstone
fill 236 65 315 236 65 316 minecraft:chiseled_sandstone
fill 237 65 316 240 65 316 minecraft:chiseled_sandstone
fill 240 65 276 245 65 276 minecraft:chiseled_sandstone
fill 247 65 316 252 65 316 minecraft:chiseled_sandstone
fill 252 65 276 257 65 276 minecraft:chiseled_sandstone
fill 259 65 316 264 65 316 minecraft:chiseled_sandstone
fill 264 65 276 269 65 276 minecraft:chiseled_sandstone
fill 271 65 316 276 65 316 minecraft:chiseled_sandstone
fill 276 65 276 276 65 281 minecraft:chiseled_sandstone
fill 276 65 288 276 65 293 minecraft:chiseled_sandstone
fill 276 65 300 276 65 305 minecraft:chiseled_sandstone
fill 276 65 312 276 65 315 minecraft:chiseled_sandstone
fill 235 66 281 235 71 284 minecraft:glowstone
fill 235 66 293 235 71 296 minecraft:glowstone
fill 235 66 299 235 77 300 minecraft:smooth_sandstone
fill 235 66 305 235 71 308 minecraft:glowstone
fill 235 66 317 238 71 317 minecraft:glowstone
fill 242 66 275 245 71 275 minecraft:glowstone
fill 247 66 317 250 71 317 minecraft:glowstone
fill 254 66 275 257 71 275 minecraft:glowstone
fill 259 66 317 262 71 317 minecraft:glowstone
fill 266 66 275 269 71 275 minecraft:glowstone
fill 271 66 317 274 71 317 minecraft:glowstone
fill 277 66 275 277 95 275 minecraft:smooth_sandstone
fill 277 66 276 277 71 279 minecraft:glowstone
fill 277 66 288 277 71 291 minecraft:glowstone
fill 277 66 300 277 71 303 minecraft:glowstone
setblock 277 66 306 minecraft:blue_terracotta
fill 277 66 307 277 92 307 minecraft:smooth_sandstone
fill 277 66 312 277 71 315 minecraft:glowstone
fill 236 67 275 236 95 275 minecraft:smooth_sandstone
setblock 237 67 275 minecraft:black_terracotta
fill 237 67 280 237 67 281 minecraft:chiseled_sandstone
fill 238 67 275 238 91 275 minecraft:smooth_sandstone
setblock 238 67 279 minecraft:chiseled_sandstone
fill 238 67 282 241 67 282 minecraft:chiseled_sandstone
fill 239 67 278 240 67 278 minecraft:chiseled_sandstone
setblock 241 67 279 minecraft:chiseled_sandstone
setblock 272 67 275 minecraft:lapis_block
fill 277 67 306 277 71 306 minecraft:smooth_sandstone
fill 237 68 275 237 80 275 minecraft:smooth_sandstone
setblock 252 68 275 minecraft:black_terracotta
setblock 252 68 317 minecraft:black_terracotta
fill 272 68 275 272 93 275 minecraft:smooth_sandstone
setblock 238 69 278 minecraft:light[level=12]
setblock 238 69 285 minecraft:light[level=12]
setblock 238 69 292 minecraft:light[level=12]
setblock 238 69 299 minecraft:light[level=12]
setblock 238 69 306 minecraft:light[level=12]
setblock 238 69 313 minecraft:light[level=12]
setblock 245 69 278 minecraft:light[level=12]
setblock 245 69 285 minecraft:light[level=12]
setblock 245 69 292 minecraft:light[level=12]
setblock 245 69 299 minecraft:light[level=12]
setblock 245 69 306 minecraft:light[level=12]
setblock 245 69 313 minecraft:light[level=12]
fill 252 69 275 252 95 275 minecraft:smooth_sandstone
setblock 252 69 278 minecraft:light[level=12]
setblock 252 69 285 minecraft:light[level=12]
setblock 252 69 292 minecraft:light[level=12]
setblock 252 69 299 minecraft:light[level=12]
setblock 252 69 306 minecraft:light[level=12]
setblock 252 69 313 minecraft:light[level=12]
fill 252 69 317 252 96 317 minecraft:smooth_sandstone
setblock 259 69 278 minecraft:light[level=12]
setblock 259 69 285 minecraft:light[level=12]
setblock 259 69 292 minecraft:light[level=12]
setblock 259 69 299 minecraft:light[level=12]
setblock 259 69 306 minecraft:light[level=12]
setblock 259 69 313 minecraft:light[level=12]
setblock 261 69 275 minecraft:black_terracotta
setblock 266 69 278 minecraft:light[level=12]
setblock 266 69 285 minecraft:light[level=12]
setblock 266 69 292 minecraft:light[level=12]
setblock 266 69 299 minecraft:light[level=12]
setblock 266 69 306 minecraft:light[level=12]
setblock 266 69 313 minecraft:light[level=12]
setblock 273 69 278 minecraft:light[level=12]
setblock 273 69 285 minecraft:light[level=12]
setblock 273 69 292 minecraft:light[level=12]
setblock 273 69 299 minecraft:light[level=12]
setblock 273 69 306 minecraft:light[level=12]
setblock 273 69 313 minecraft:light[level=12]
fill 261 70 275 261 86 275 minecraft:smooth_sandstone
fill 235 71 285 235 95 286 minecraft:smooth_sandstone
setblock 235 71 287 minecraft:black_terracotta
setblock 238 71 278 minecraft:light[level=15]
setblock 238 71 286 minecraft:light[level=15]
setblock 238 71 294 minecraft:light[level=15]
setblock 238 71 302 minecraft:light[level=15]
setblock 238 71 310 minecraft:light[level=15]
setblock 244 71 317 minecraft:orange_terracotta
setblock 246 71 278 minecraft:light[level=15]
setblock 246 71 286 minecraft:light[level=15]
setblock 246 71 294 minecraft:light[level=15]
setblock 246 71 302 minecraft:light[level=15]
setblock 246 71 310 minecraft:light[level=15]
setblock 254 71 278 minecraft:light[level=15]
setblock 254 71 286 minecraft:light[level=15]
setblock 254 71 294 minecraft:light[level=15]
setblock 254 71 302 minecraft:light[level=15]
setblock 254 71 310 minecraft:light[level=15]
setblock 262 71 278 minecraft:light[level=15]
setblock 262 71 286 minecraft:light[level=15]
setblock 262 71 294 minecraft:light[level=15]
setblock 262 71 302 minecraft:light[level=15]
setblock 262 71 310 minecraft:light[level=15]
setblock 270 71 278 minecraft:light[level=15]
setblock 270 71 286 minecraft:light[level=15]
setblock 270 71 294 minecraft:light[level=15]
setblock 270 71 302 minecraft:light[level=15]
setblock 270 71 310 minecraft:light[level=15]
setblock 235 72 280 minecraft:blue_terracotta
fill 235 72 281 235 85 281 minecraft:smooth_sandstone
fill 235 72 282 235 72 283 minecraft:glowstone
fill 235 72 284 235 85 284 minecraft:smooth_sandstone
fill 235 72 287 235 90 287 minecraft:smooth_sandstone
setblock 235 72 290 minecraft:orange_terracotta
fill 235 72 293 235 85 293 minecraft:smooth_sandstone
fill 235 72 294 235 72 295 minecraft:glowstone
fill 235 72 296 235 85 296 minecraft:smooth_sandstone
fill 235 72 305 235 85 305 minecraft:smooth_sandstone
fill 235 72 306 235 72 307 minecraft:glowstone
fill 235 72 308 235 85 308 minecraft:smooth_sandstone
fill 235 72 317 235 85 317 minecraft:smooth_sandstone
fill 236 72 317 237 72 317 minecraft:glowstone
fill 238 72 307 238 74 307 minecraft:shroomlight
fill 238 72 317 238 85 317 minecraft:smooth_sandstone
fill 242 72 275 242 85 275 minecraft:smooth_sandstone
fill 243 72 275 244 72 275 minecraft:glowstone
fill 244 72 317 244 78 317 minecraft:smooth_sandstone
fill 245 72 275 245 85 275 minecraft:smooth_sandstone
fill 247 72 317 247 85 317 minecraft:smooth_sandstone
fill 248 72 317 249 72 317 minecraft:glowstone
fill 250 72 317 250 85 317 minecraft:smooth_sandstone
fill 254 72 275 254 74 275 minecraft:smooth_sandstone
fill 255 72 275 256 72 275 minecraft:glowstone
fill 257 72 275 257 85 275 minecraft:smooth_sandstone
fill 259 72 317 259 85 317 minecraft:smooth_sandstone
fill 260 72 317 261 72 317 minecraft:glowstone
fill 262 72 317 262 85 317 minecraft:smooth_sandstone
setblock 265 72 317 minecraft:lapis_block
fill 266 72 275 266 74 275 minecraft:smooth_sandstone
fill 267 72 275 268 72 275 minecraft:glowstone
fill 269 72 275 269 85 275 minecraft:smooth_sandstone
fill 271 72 317 271 85 317 minecraft:smooth_sandstone
fill 272 72 317 273 72 317 minecraft:glowstone
fill 274 72 317 274 85 317 minecraft:smooth_sandstone
fill 277 72 276 277 85 276 minecraft:smooth_sandstone
fill 277 72 277 277 72 278 minecraft:glowstone
fill 277 72 279 277 85 279 minecraft:smooth_sandstone
fill 277 72 288 277 82 288 minecraft:smooth_sandstone
fill 277 72 289 277 72 290 minecraft:glowstone
fill 277 72 291 277 85 291 minecraft:smooth_sandstone
fill 277 72 300 277 85 300 minecraft:smooth_sandstone
fill 277 72 301 277 72 302 minecraft:glowstone
fill 277 72 303 277 85 303 minecraft:smooth_sandstone
setblock 277 72 306 minecraft:lapis_block
fill 277 72 312 277 75 312 minecraft:smooth_sandstone
fill 277 72 313 277 72 314 minecraft:glowstone
fill 277 72 315 277 85 315 minecraft:smooth_sandstone
fill 235 73 280 235 76 280 minecraft:smooth_sandstone
fill 235 73 282 235 85 283 minecraft:smooth_sandstone
fill 235 73 290 235 80 290 minecraft:smooth_sandstone
fill 235 73 294 235 81 295 minecraft:smooth_sandstone
fill 235 73 306 235 76 307 minecraft:smooth_sandstone
fill 236 73 317 237 85 317 minecraft:smooth_sandstone
fill 238 73 279 238 74 279 minecraft:lapis_block
fill 238 73 282 241 74 282 minecraft:lapis_block
fill 239 73 278 240 74 278 minecraft:lapis_block
fill 241 73 279 241 74 279 minecraft:lapis_block
fill 243 73 275 244 85 275 minecraft:smooth_sandstone
fill 248 73 317 249 85 317 minecraft:smooth_sandstone
fill 255 73 275 256 85 275 minecraft:smooth_sandstone
fill 260 73 317 261 85 317 minecraft:smooth_sandstone
fill 265 73 317 265 95 317 minecraft:smooth_sandstone
fill 267 73 275 268 85 275 minecraft:smooth_sandstone
fill 272 73 317 273 81 317 minecraft:smooth_sandstone
fill 274 73 305 274 74 305 minecraft:blue_wool
fill 277 73 277 277 85 278 minecraft:smooth_sandstone
fill 277 73 289 277 85 290 minecraft:smooth_sandstone
fill 277 73 301 277 79 302 minecraft:smooth_sandstone
fill 277 73 306 277 95 306 minecraft:smooth_sandstone
fill 277 73 313 277 85 314 minecraft:smooth_sandstone
fill 274 74 303 274 74 304 minecraft:blue_wool
fill 274 74 306 274 74 307 minecraft:blue_wool
setblock 238 75 278 minecraft:light[level=12]
setblock 238 75 285 minecraft:light[level=12]
setblock 238 75 292 minecraft:light[level=12]
setblock 238 75 299 minecraft:light[level=12]
setblock 238 75 306 minecraft:light[level=12]
setblock 238 75 313 minecraft:light[level=12]
setblock 245 75 278 minecraft:light[level=12]
setblock 245 75 285 minecraft:light[level=12]
setblock 245 75 292 minecraft:light[level=12]
setblock 245 75 299 minecraft:light[level=12]
setblock 245 75 306 minecraft:light[level=12]
setblock 245 75 313 minecraft:light[level=12]
setblock 252 75 278 minecraft:light[level=12]
setblock 252 75 285 minecraft:light[level=12]
setblock 252 75 292 minecraft:light[level=12]
setblock 252 75 299 minecraft:light[level=12]
setblock 252 75 306 minecraft:light[level=12]
setblock 252 75 313 minecraft:light[level=12]
setblock 254 75 275 minecraft:blue_terracotta
setblock 259 75 278 minecraft:light[level=12]
setblock 259 75 285 minecraft:light[level=12]
setblock 259 75 292 minecraft:light[level=12]
setblock 259 75 299 minecraft:light[level=12]
setblock 259 75 306 minecraft:light[level=12]
setblock 259 75 313 minecraft:light[level=12]
setblock 266 75 275 minecraft:orange_terracotta
setblock 266 75 278 minecraft:light[level=12]
setblock 266 75 285 minecraft:light[level=12]
setblock 266 75 292 minecraft:light[level=12]
setblock 266 75 299 minecraft:light[level=12]
setblock 266 75 306 minecraft:light[level=12]
setblock 266 75 313 minecraft:light[level=12]
setblock 273 75 278 minecraft:light[level=12]
setblock 273 75 285 minecraft:light[level=12]
setblock 273 75 292 minecraft:light[level=12]
setblock 273 75 299 minecraft:light[level=12]
setblock 273 75 306 minecraft:light[level=12]
setblock 273 75 313 minecraft:light[level=12]
fill 254 76 275 254 85 275 minecraft:smooth_sandstone
fill 266 76 275 266 85 275 minecraft:smooth_sandstone
setblock 268 76 317 minecraft:orange_terracotta
setblock 277 76 284 minecraft:lapis_block
setblock 277 76 312 minecraft:lapis_block
setblock 235 77 280 minecraft:blue_terracotta
setblock 235 77 306 minecraft:orange_terracotta
fill 235 77 307 235 85 307 minecraft:smooth_sandstone
setblock 235 77 311 minecraft:orange_terracotta
fill 268 77 317 268 96 317 minecraft:smooth_sandstone
fill 277 77 284 277 95 284 minecraft:smooth_sandstone
fill 277 77 312 277 85 312 minecraft:smooth_sandstone
fill 235 78 280 235 96 280 minecraft:smooth_sandstone
fill 235 78 299 235 90 299 minecraft:smooth_sandstone
setblock 235 78 300 minecraft:black_terracotta
fill 235 78 306 235 85 306 minecraft:smooth_sandstone
fill 235 78 311 235 85 311 minecraft:smooth_sandstone
setblock 235 78 314 minecraft:black_terracotta
setblock 239 78 317 minecraft:blue_terracotta
setblock 276 78 317 minecraft:orange_terracotta
fill 235 79 300 235 95 300 minecraft:smooth_sandstone
setblock 235 79 304 minecraft:lapis_block
fill 235 79 314 235 93 314 minecraft:smooth_sandstone
setblock 238 79 278 minecraft:light[level=15]
setblock 238 79 286 minecraft:light[level=15]
setblock 238 79 294 minecraft:light[level=15]
setblock 238 79 302 minecraft:light[level=15]
setblock 238 79 310 minecraft:light[level=15]
setblock 239 79 317 minecraft:smooth_sandstone
setblock 244 79 317 minecraft:black_terracotta
setblock 246 79 278 minecraft:light[level=15]
setblock 246 79 286 minecraft:light[level=15]
setblock 246 79 294 minecraft:light[level=15]
setblock 246 79 302 minecraft:light[level=15]
setblock 246 79 310 minecraft:light[level=15]
setblock 254 79 278 minecraft:light[level=15]
setblock 254 79 286 minecraft:light[level=15]
setblock 254 79 294 minecraft:light[level=15]
setblock 254 79 302 minecraft:light[level=15]
setblock 254 79 310 minecraft:light[level=15]
setblock 258 79 317 minecraft:blue_terracotta
setblock 262 79 278 minecraft:light[level=15]
setblock 262 79 286 minecraft:light[level=15]
setblock 262 79 294 minecraft:light[level=15]
setblock 262 79 302 minecraft:light[level=15]
setblock 262 79 310 minecraft:light[level=15]
setblock 270 79 278 minecraft:light[level=15]
setblock 270 79 286 minecraft:light[level=15]
setblock 270 79 294 minecraft:light[level=15]
setblock 270 79 302 minecraft:light[level=15]
setblock 270 79 310 minecraft:light[level=15]
fill 276 79 317 276 95 317 minecraft:smooth_sandstone
setblock 277 79 299 minecraft:blue_terracotta
setblock 277 79 316 minecraft:blue_terracotta
fill 235 80 304 235 95 304 minecraft:smooth_sandstone
setblock 239 80 317 minecraft:orange_terracotta
fill 244 80 297 252 80 297 minecraft:cyan_terracotta
fill 244 80 317 244 91 317 minecraft:smooth_sandstone
fill 245 80 296 251 81 296 minecraft:cyan_terracotta
fill 245 80 298 251 81 298 minecraft:cyan_terracotta
fill 246 80 295 250 81 295 minecraft:cyan_terracotta
fill 246 80 299 250 81 299 minecraft:cyan_terracotta
fill 251 80 294 253 80 295 minecraft:lapis_block
fill 251 80 299 253 80 300 minecraft:lapis_block
fill 252 80 293 260 80 293 minecraft:lapis_block
fill 252 80 296 253 80 296 minecraft:lapis_block
fill 252 80 298 253 80 298 minecraft:lapis_block
fill 252 80 301 260 80 301 minecraft:lapis_block
fill 253 80 292 259 80 292 minecraft:lapis_block
fill 253 80 302 259 80 302 minecraft:lapis_block
fill 254 80 294 255 80 294 minecraft:lapis_block
fill 254 80 300 255 80 300 minecraft:lapis_block
fill 256 80 291 256 81 291 minecraft:lapis_block
fill 256 80 303 256 81 303 minecraft:lapis_block
fill 257 80 294 261 80 294 minecraft:lapis_block
fill 257 80 300 261 80 300 minecraft:lapis_block
fill 258 80 317 258 95 317 minecraft:smooth_sandstone
fill 259 80 295 260 80 296 minecraft:lapis_block
fill 259 80 298 260 80 299 minecraft:lapis_block
fill 260 80 297 268 80 297 minecraft:cyan_terracotta
setblock 261 80 295 minecraft:lapis_block
fill 261 80 296 267 81 296 minecraft:cyan_terracotta
fill 261 80 298 267 81 298 minecraft:cyan_terracotta
setblock 261 80 299 minecraft:lapis_block
fill 262 80 295 266 81 295 minecraft:cyan_terracotta
fill 262 80 299 266 81 299 minecraft:cyan_terracotta
setblock 263 80 275 minecraft:orange_terracotta
fill 277 80 299 277 95 299 minecraft:smooth_sandstone
setblock 277 80 301 minecraft:orange_terracotta
fill 277 80 302 277 85 302 minecraft:smooth_sandstone
fill 277 80 316 277 91 316 minecraft:smooth_sandstone
setblock 235 81 290 minecraft:black_terracotta
fill 236 81 276 236 81 277 minecraft:sandstone
setblock 236 81 278 minecraft:orange_terracotta
fill 236 81 279 236 81 281 minecraft:sandstone
setblock 236 81 282 minecraft:orange_terracotta
fill 236 81 283 236 81 285 minecraft:sandstone
setblock 236 81 286 minecraft:orange_terracotta
fill 236 81 287 236 81 289 minecraft:sandstone
setblock 236 81 290 minecraft:orange_terracotta
fill 236 81 291 236 81 293 minecraft:sandstone
setblock 236 81 294 minecraft:orange_terracotta
fill 236 81 295 236 81 297 minecraft:sandstone
setblock 236 81 298 minecraft:orange_terracotta
fill 236 81 299 236 81 301 minecraft:sandstone
setblock 236 81 302 minecraft:orange_terracotta
fill 236 81 303 236 81 305 minecraft:sandstone
setblock 236 81 306 minecraft:orange_terracotta
fill 236 81 307 236 81 309 minecraft:sandstone
setblock 236 81 310 minecraft:orange_terracotta
fill 236 81 311 236 81 313 minecraft:sandstone
setblock 236 81 314 minecraft:orange_terracotta
fill 236 81 315 237 81 316 minecraft:sandstone
setblock 237 81 275 minecraft:lapis_block
setblock 237 81 276 minecraft:sandstone
setblock 237 81 277 minecraft:orange_terracotta
fill 237 81 278 237 81 280 minecraft:sandstone
setblock 237 81 281 minecraft:orange_terracotta
fill 237 81 282 237 81 284 minecraft:sandstone
setblock 237 81 285 minecraft:orange_terracotta
fill 237 81 286 237 81 288 minecraft:sandstone
setblock 237 81 289 minecraft:orange_terracotta
fill 237 81 290 237 81 292 minecraft:sandstone
setblock 237 81 293 minecraft:orange_terracotta
fill 237 81 294 237 81 296 minecraft:sandstone
setblock 237 81 297 minecraft:orange_terracotta
fill 237 81 298 237 81 300 minecraft:sandstone
setblock 237 81 301 minecraft:orange_terracotta
fill 237 81 302 237 81 304 minecraft:sandstone
setblock 237 81 305 minecraft:orange_terracotta
fill 237 81 306 237 81 308 minecraft:sandstone
setblock 237 81 309 minecraft:orange_terracotta
fill 237 81 310 237 81 312 minecraft:sandstone
setblock 237 81 313 minecraft:orange_terracotta
fill 237 81 314 239 81 314 minecraft:sandstone
setblock 238 81 276 minecraft:orange_terracotta
fill 238 81 277 238 81 279 minecraft:sandstone
setblock 238 81 280 minecraft:orange_terracotta
fill 238 81 281 238 81 283 minecraft:sandstone
setblock 238 81 284 minecraft:orange_terracotta
fill 238 81 285 238 81 287 minecraft:sandstone
setblock 238 81 288 minecraft:orange_terracotta
fill 238 81 289 238 81 291 minecraft:sandstone
setblock 238 81 292 minecraft:orange_terracotta
fill 238 81 293 238 81 295 minecraft:sandstone
setblock 238 81 296 minecraft:orange_terracotta
fill 238 81 297 238 81 299 minecraft:sandstone
setblock 238 81 300 minecraft:orange_terracotta
fill 238 81 301 238 81 303 minecraft:sandstone
setblock 238 81 304 minecraft:orange_terracotta
fill 238 81 305 238 81 307 minecraft:sandstone
setblock 238 81 308 minecraft:orange_terracotta
fill 238 81 309 238 81 311 minecraft:sandstone
setblock 238 81 312 minecraft:orange_terracotta
fill 238 81 313 240 81 313 minecraft:sandstone
setblock 238 81 315 minecraft:sandstone
setblock 238 81 316 minecraft:orange_terracotta
fill 239 81 276 239 81 278 minecraft:sandstone
setblock 239 81 279 minecraft:orange_terracotta
fill 239 81 280 239 81 282 minecraft:sandstone
setblock 239 81 283 minecraft:orange_terracotta
fill 239 81 284 239 81 286 minecraft:sandstone
setblock 239 81 287 minecraft:orange_terracotta
fill 239 81 288 239 81 290 minecraft:sandstone
setblock 239 81 291 minecraft:orange_terracotta
fill 239 81 292 239 81 294 minecraft:sandstone
setblock 239 81 295 minecraft:orange_terracotta
fill 239 81 296 239 81 298 minecraft:sandstone
setblock 239 81 299 minecraft:orange_terracotta
fill 239 81 300 239 81 302 minecraft:sandstone
setblock 239 81 303 minecraft:orange_terracotta
fill 239 81 304 239 81 306 minecraft:sandstone
setblock 239 81 307 minecraft:orange_terracotta
fill 239 81 308 239 81 310 minecraft:sandstone
setblock 239 81 311 minecraft:orange_terracotta
fill 239 81 312 241 81 312 minecraft:sandstone
setblock 239 81 315 minecraft:orange_terracotta
fill 239 81 316 241 81 316 minecraft:sandstone
fill 239 81 317 239 91 317 minecraft:smooth_sandstone
fill 240 81 276 240 81 277 minecraft:sandstone
setblock 240 81 278 minecraft:orange_terracotta
fill 240 81 279 240 81 281 minecraft:sandstone
setblock 240 81 282 minecraft:orange_terracotta
fill 240 81 283 240 81 285 minecraft:sandstone
setblock 240 81 286 minecraft:orange_terracotta
fill 240 81 287 240 81 289 minecraft:sandstone
setblock 240 81 290 minecraft:orange_terracotta
fill 240 81 291 240 81 293 minecraft:sandstone
setblock 240 81 294 minecraft:orange_terracotta
fill 240 81 295 240 81 297 minecraft:sandstone
setblock 240 81 298 minecraft:orange_terracotta
fill 240 81 299 240 81 301 minecraft:sandstone
setblock 240 81 302 minecraft:orange_terracotta
fill 240 81 303 240 81 305 minecraft:sandstone
setblock 240 81 306 minecraft:orange_terracotta
fill 240 81 307 240 81 309 minecraft:sandstone
setblock 240 81 310 minecraft:orange_terracotta
fill 240 81 311 242 81 311 minecraft:sandstone
setblock 240 81 314 minecraft:orange_terracotta
fill 240 81 315 242 81 315 minecraft:sandstone
setblock 241 81 276 minecraft:sandstone
setblock 241 81 277 minecraft:orange_terracotta
fill 241 81 278 241 81 280 minecraft:sandstone
setblock 241 81 281 minecraft:orange_terracotta
fill 241 81 282 242 81 283 minecraft:sandstone
fill 241 81 284 241 83 284 minecraft:shroomlight
setblock 241 81 285 minecraft:orange_terracotta
fill 241 81 286 241 81 288 minecraft:sandstone
setblock 241 81 289 minecraft:orange_terracotta
fill 241 81 290 241 81 292 minecraft:sandstone
setblock 241 81 293 minecraft:orange_terracotta
fill 241 81 294 241 81 296 minecraft:sandstone
setblock 241 81 297 minecraft:orange_terracotta
fill 241 81 298 241 81 300 minecraft:sandstone
setblock 241 81 301 minecraft:orange_terracotta
fill 241 81 302 241 81 304 minecraft:sandstone
setblock 241 81 305 minecraft:orange_terracotta
fill 241 81 306 241 81 308 minecraft:sandstone
setblock 241 81 309 minecraft:orange_terracotta
fill 241 81 310 243 81 310 minecraft:sandstone
setblock 241 81 313 minecraft:orange_terracotta
fill 241 81 314 243 81 314 minecraft:sandstone
setblock 242 81 276 minecraft:orange_terracotta
fill 242 81 277 242 81 279 minecraft:sandstone
setblock 242 81 280 minecraft:orange_terracotta
fill 242 81 281 244 81 281 minecraft:sandstone
setblock 242 81 284 minecraft:orange_terracotta
fill 242 81 285 242 81 287 minecraft:sandstone
setblock 242 81 288 minecraft:orange_terracotta
fill 242 81 289 242 81 291 minecraft:sandstone
setblock 242 81 292 minecraft:orange_terracotta
fill 242 81 293 242 81 295 minecraft:sandstone
setblock 242 81 296 minecraft:orange_terracotta
fill 242 81 297 242 81 299 minecraft:sandstone
setblock 242 81 300 minecraft:orange_terracotta
fill 242 81 301 242 81 303 minecraft:sandstone
setblock 242 81 304 minecraft:orange_terracotta
fill 242 81 305 242 81 307 minecraft:sandstone
setblock 242 81 308 minecraft:orange_terracotta
fill 242 81 309 244 81 309 minecraft:sandstone
setblock 242 81 312 minecraft:orange_terracotta
fill 242 81 313 244 81 313 minecraft:sandstone
setblock 242 81 316 minecraft:orange_terracotta
fill 243 81 276 243 81 278 minecraft:sandstone
setblock 243 81 279 minecraft:orange_terracotta
fill 243 81 280 245 81 280 minecraft:sandstone
setblock 243 81 282 minecraft:sandstone
setblock 243 81 283 minecraft:orange_terracotta
fill 243 81 284 243 81 286 minecraft:sandstone
setblock 243 81 287 minecraft:orange_terracotta
fill 243 81 288 243 81 290 minecraft:sandstone
setblock 243 81 291 minecraft:orange_terracotta
fill 243 81 292 243 81 294 minecraft:sandstone
setblock 243 81 295 minecraft:orange_terracotta
fill 243 81 296 243 81 298 minecraft:sandstone
setblock 243 81 299 minecraft:orange_terracotta
fill 243 81 300 243 81 302 minecraft:sandstone
setblock 243 81 303 minecraft:orange_terracotta
fill 243 81 304 243 81 306 minecraft:sandstone
setblock 243 81 307 minecraft:orange_terracotta
fill 243 81 308 245 81 308 minecraft:sandstone
setblock 243 81 311 minecraft:orange_terracotta
fill 243 81 312 245 81 312 minecraft:sandstone
setblock 243 81 315 minecraft:orange_terracotta
fill 243 81 316 245 81 316 minecraft:sandstone
fill 244 81 276 244 81 277 minecraft:sandstone
setblock 244 81 278 minecraft:orange_terracotta
fill 244 81 279 246 81 279 minecraft:sandstone
setblock 244 81 282 minecraft:orange_terracotta
fill 244 81 283 244 81 285 minecraft:sandstone
setblock 244 81 286 minecraft:orange_terracotta
fill 244 81 287 244 81 289 minecraft:sandstone
setblock 244 81 290 minecraft:orange_terracotta
fill 244 81 291 244 81 293 minecraft:sandstone
setblock 244 81 294 minecraft:orange_terracotta
fill 244 81 295 244 81 296 minecraft:sandstone
fill 244 81 297 251 81 297 minecraft:cyan_terracotta
setblock 244 81 298 minecraft:orange_terracotta
fill 244 81 299 244 81 301 minecraft:sandstone
setblock 244 81 302 minecraft:orange_terracotta
fill 244 81 303 244 81 305 minecraft:sandstone
setblock 244 81 306 minecraft:orange_terracotta
fill 244 81 307 246 81 307 minecraft:sandstone
setblock 244 81 310 minecraft:orange_terracotta
fill 244 81 311 246 81 311 minecraft:sandstone
setblock 244 81 314 minecraft:orange_terracotta
fill 244 81 315 246 81 315 minecraft:sandstone
setblock 245 81 276 minecraft:sandstone
setblock 245 81 277 minecraft:orange_terracotta
fill 245 81 278 247 81 278 minecraft:sandstone
setblock 245 81 281 minecraft:orange_terracotta
fill 245 81 282 245 81 284 minecraft:sandstone
setblock 245 81 285 minecraft:orange_terracotta
fill 245 81 286 245 81 288 minecraft:sandstone
setblock 245 81 289 minecraft:orange_terracotta
fill 245 81 290 245 81 292 minecraft:sandstone
setblock 245 81 293 minecraft:orange_terracotta
fill 245 81 294 245 81 295 minecraft:sandstone
fill 245 81 299 245 81 300 minecraft:sandstone
setblock 245 81 301 minecraft:orange_terracotta
fill 245 81 302 245 81 304 minecraft:sandstone
setblock 245 81 305 minecraft:orange_terracotta
fill 245 81 306 247 81 306 minecraft:sandstone
setblock 245 81 309 minecraft:orange_terracotta
fill 245 81 310 247 81 310 minecraft:sandstone
setblock 245 81 313 minecraft:orange_terracotta
fill 245 81 314 247 81 314 minecraft:sandstone
setblock 246 81 276 minecraft:orange_terracotta
fill 246 81 277 248 81 277 minecraft:sandstone
setblock 246 81 280 minecraft:orange_terracotta
fill 246 81 281 246 81 283 minecraft:sandstone
setblock 246 81 284 minecraft:orange_terracotta
fill 246 81 285 246 81 287 minecraft:sandstone
setblock 246 81 288 minecraft:orange_terracotta
fill 246 81 289 246 81 291 minecraft:sandstone
setblock 246 81 292 minecraft:orange_terracotta
fill 246 81 293 247 81 294 minecraft:sandstone
setblock 246 81 300 minecraft:orange_terracotta
fill 246 81 301 246 81 303 minecraft:sandstone
setblock 246 81 304 minecraft:orange_terracotta
fill 246 81 305 248 81 305 minecraft:sandstone
setblock 246 81 308 minecraft:orange_terracotta
fill 246 81 309 248 81 309 minecraft:sandstone
setblock 246 81 312 minecraft:orange_terracotta
fill 246 81 313 248 81 313 minecraft:sandstone
setblock 246 81 316 minecraft:orange_terracotta
fill 247 81 276 249 81 276 minecraft:sandstone
setblock 247 81 279 minecraft:orange_terracotta
fill 247 81 280 247 81 282 minecraft:sandstone
setblock 247 81 283 minecraft:orange_terracotta
fill 247 81 284 247 81 286 minecraft:sandstone
setblock 247 81 287 minecraft:orange_terracotta
fill 247 81 288 247 81 290 minecraft:sandstone
setblock 247 81 291 minecraft:orange_terracotta
fill 247 81 292 249 81 292 minecraft:sandstone
fill 247 81 300 247 81 302 minecraft:sandstone
setblock 247 81 303 minecraft:orange_terracotta
fill 247 81 304 249 81 304 minecraft:sandstone
setblock 247 81 307 minecraft:orange_terracotta
fill 247 81 308 249 81 308 minecraft:sandstone
setblock 247 81 311 minecraft:orange_terracotta
fill 247 81 312 249 81 312 minecraft:sandstone
setblock 247 81 315 minecraft:orange_terracotta
fill 247 81 316 249 81 316 minecraft:sandstone
setblock 248 81 278 minecraft:orange_terracotta
fill 248 81 279 248 81 281 minecraft:sandstone
setblock 248 81 282 minecraft:orange_terracotta
fill 248 81 283 248 81 285 minecraft:sandstone
setblock 248 81 286 minecraft:orange_terracotta
fill 248 81 287 248 81 289 minecraft:sandstone
setblock 248 81 290 minecraft:orange_terracotta
fill 248 81 291 250 81 291 minecraft:sandstone
setblock 248 81 293 minecraft:sandstone
setblock 248 81 294 minecraft:orange_terracotta
fill 248 81 300 248 81 301 minecraft:sandstone
setblock 248 81 302 minecraft:orange_terracotta
fill 248 81 303 250 81 303 minecraft:sandstone
setblock 248 81 306 minecraft:orange_terracotta
fill 248 81 307 250 81 307 minecraft:sandstone
setblock 248 81 310 minecraft:orange_terracotta
fill 248 81 311 250 81 311 minecraft:sandstone
setblock 248 81 314 minecraft:orange_terracotta
fill 248 81 315 250 81 315 minecraft:sandstone
setblock 249 81 277 minecraft:orange_terracotta
fill 249 81 278 249 81 280 minecraft:sandstone
setblock 249 81 281 minecraft:orange_terracotta
fill 249 81 282 249 81 284 minecraft:sandstone
setblock 249 81 285 minecraft:orange_terracotta
fill 249 81 286 249 81 288 minecraft:sandstone
setblock 249 81 289 minecraft:orange_terracotta
fill 249 81 290 251 81 290 minecraft:sandstone
setblock 249 81 293 minecraft:orange_terracotta
fill 249 81 294 250 81 294 minecraft:sandstone
setblock 249 81 300 minecraft:sandstone
setblock 249 81 301 minecraft:orange_terracotta
fill 249 81 302 251 81 302 minecraft:sandstone
setblock 249 81 305 minecraft:orange_terracotta
fill 249 81 306 251 81 306 minecraft:sandstone
setblock 249 81 309 minecraft:orange_terracotta
fill 249 81 310 251 81 310 minecraft:sandstone
setblock 249 81 313 minecraft:orange_terracotta
fill 249 81 314 251 81 314 minecraft:sandstone
setblock 250 81 276 minecraft:orange_terracotta
fill 250 81 277 250 81 279 minecraft:sandstone
setblock 250 81 280 minecraft:orange_terracotta
fill 250 81 281 250 81 283 minecraft:sandstone
setblock 250 81 284 minecraft:orange_terracotta
fill 250 81 285 250 81 287 minecraft:sandstone
setblock 250 81 288 minecraft:orange_terracotta
fill 250 81 289 252 81 289 minecraft:sandstone
setblock 250 81 292 minecraft:orange_terracotta
fill 250 81 293 251 81 293 minecraft:sandstone
setblock 250 81 300 minecraft:orange_terracotta
fill 250 81 301 251 81 301 minecraft:sandstone
setblock 250 81 304 minecraft:orange_terracotta
fill 250 81 305 252 81 305 minecraft:sandstone
setblock 250 81 308 minecraft:orange_terracotta
fill 250 81 309 252 81 309 minecraft:sandstone
setblock 250 81 312 minecraft:orange_terracotta
fill 250 81 313 252 81 313 minecraft:sandstone
setblock 250 81 316 minecraft:orange_terracotta
fill 251 81 276 251 81 278 minecraft:sandstone
setblock 251 81 279 minecraft:orange_terracotta
fill 251 81 280 251 81 282 minecraft:sandstone
setblock 251 81 283 minecraft:orange_terracotta
fill 251 81 284 251 81 286 minecraft:sandstone
setblock 251 81 287 minecraft:orange_terracotta
fill 251 81 288 253 81 288 minecraft:sandstone
setblock 251 81 291 minecraft:orange_terracotta
fill 251 81 292 252 81 292 minecraft:sandstone
fill 251 81 294 251 81 295 minecraft:gold_block
fill 251 81 299 251 81 300 minecraft:gold_block
setblock 251 81 303 minecraft:orange_terracotta
fill 251 81 304 253 81 304 minecraft:sandstone
setblock 251 81 307 minecraft:orange_terracotta
fill 251 81 308 253 81 308 minecraft:sandstone
setblock 251 81 311 minecraft:orange_terracotta
fill 251 81 312 253 81 312 minecraft:sandstone
setblock 251 81 315 minecraft:orange_terracotta
fill 251 81 316 253 81 316 minecraft:sandstone
fill 252 81 276 252 81 277 minecraft:sandstone
setblock 252 81 278 minecraft:orange_terracotta
fill 252 81 279 252 81 281 minecraft:sandstone
setblock 252 81 282 minecraft:orange_terracotta
fill 252 81 283 252 81 285 minecraft:sandstone
setblock 252 81 286 minecraft:orange_terracotta
fill 252 81 287 254 81 287 minecraft:sandstone
setblock 252 81 290 minecraft:orange_terracotta
fill 252 81 291 254 81 291 minecraft:sandstone
setblock 252 81 293 minecraft:gold_block
fill 252 81 294 252 81 295 minecraft:lapis_block
fill 252 81 296 252 81 298 minecraft:gold_block
fill 252 81 299 252 81 300 minecraft:lapis_block
setblock 252 81 301 minecraft:gold_block
setblock 252 81 302 minecraft:orange_terracotta
fill 252 81 303 254 81 303 minecraft:sandstone
setblock 252 81 306 minecraft:orange_terracotta
fill 252 81 307 254 81 307 minecraft:sandstone
setblock 252 81 310 minecraft:orange_terracotta
fill 252 81 311 254 81 311 minecraft:sandstone
setblock 252 81 314 minecraft:orange_terracotta
fill 252 81 315 254 81 315 minecraft:sandstone
setblock 253 81 276 minecraft:sandstone
setblock 253 81 277 minecraft:orange_terracotta
fill 253 81 278 253 81 280 minecraft:sandstone
setblock 253 81 281 minecraft:orange_terracotta
fill 253 81 282 253 81 284 minecraft:sandstone
setblock 253 81 285 minecraft:orange_terracotta
fill 253 81 286 255 81 286 minecraft:sandstone
setblock 253 81 289 minecraft:orange_terracotta
fill 253 81 290 255 81 290 minecraft:sandstone
fill 253 81 292 255 81 292 minecraft:gold_block
fill 253 81 293 254 81 293 minecraft:lapis_block
fill 253 81 294 253 81 296 minecraft:gold_block
fill 253 81 298 253 81 300 minecraft:gold_block
fill 253 81 301 254 81 301 minecraft:lapis_block
fill 253 81 302 255 81 302 minecraft:gold_block
setblock 253 81 305 minecraft:orange_terracotta
fill 253 81 306 255 81 306 minecraft:sandstone
setblock 253 81 309 minecraft:orange_terracotta
fill 253 81 310 255 81 310 minecraft:sandstone
setblock 253 81 313 minecraft:orange_terracotta
fill 253 81 314 255 81 314 minecraft:sandstone
setblock 254 81 276 minecraft:orange_terracotta
fill 254 81 277 254 81 279 minecraft:sandstone
setblock 254 81 280 minecraft:orange_terracotta
fill 254 81 281 254 81 283 minecraft:sandstone
setblock 254 81 284 minecraft:orange_terracotta
fill 254 81 285 256 81 285 minecraft:sandstone
setblock 254 81 288 minecraft:orange_terracotta
fill 254 81 289 256 81 289 minecraft:sandstone
fill 254 81 294 255 81 294 minecraft:gold_block
fill 254 81 300 255 81 300 minecraft:gold_block
setblock 254 81 304 minecraft:orange_terracotta
fill 254 81 305 256 81 305 minecraft:sandstone
setblock 254 81 308 minecraft:orange_terracotta
fill 254 81 309 256 81 309 minecraft:sandstone
setblock 254 81 312 minecraft:orange_terracotta
fill 254 81 313 256 81 313 minecraft:sandstone
setblock 254 81 316 minecraft:orange_terracotta
fill 255 81 276 255 81 278 minecraft:sandstone
setblock 255 81 279 minecraft:orange_terracotta
fill 255 81 280 255 81 282 minecraft:sandstone
setblock 255 81 283 minecraft:orange_terracotta
fill 255 81 284 257 81 284 minecraft:sandstone
setblock 255 81 287 minecraft:orange_terracotta
fill 255 81 288 257 81 288 minecraft:sandstone
setblock 255 81 291 minecraft:orange_terracotta
fill 255 81 293 257 81 293 minecraft:gold_block
fill 255 81 301 257 81 301 minecraft:gold_block
setblock 255 81 303 minecraft:orange_terracotta
fill 255 81 304 257 81 304 minecraft:sandstone
setblock 255 81 307 minecraft:orange_terracotta
fill 255 81 308 257 81 308 minecraft:sandstone
setblock 255 81 311 minecraft:orange_terracotta
fill 255 81 312 257 81 312 minecraft:sandstone
setblock 255 81 315 minecraft:orange_terracotta
fill 255 81 316 257 81 316 minecraft:sandstone
fill 256 81 276 256 81 277 minecraft:sandstone
setblock 256 81 278 minecraft:orange_terracotta
fill 256 81 279 256 81 281 minecraft:sandstone
setblock 256 81 282 minecraft:orange_terracotta
fill 256 81 283 258 81 283 minecraft:sandstone
setblock 256 81 286 minecraft:orange_terracotta
fill 256 81 287 258 81 287 minecraft:sandstone
setblock 256 81 290 minecraft:orange_terracotta
setblock 256 81 292 minecraft:lapis_block
setblock 256 81 302 minecraft:lapis_block
setblock 256 81 306 minecraft:orange_terracotta
fill 256 81 307 258 81 307 minecraft:sandstone
setblock 256 81 310 minecraft:orange_terracotta
fill 256 81 311 258 81 311 minecraft:sandstone
setblock 256 81 314 minecraft:orange_terracotta
fill 256 81 315 258 81 315 minecraft:sandstone
setblock 257 81 276 minecraft:sandstone
setblock 257 81 277 minecraft:orange_terracotta
fill 257 81 278 257 81 280 minecraft:sandstone
setblock 257 81 281 minecraft:orange_terracotta
fill 257 81 282 259 81 282 minecraft:sandstone
setblock 257 81 285 minecraft:orange_terracotta
fill 257 81 286 259 81 286 minecraft:sandstone
setblock 257 81 289 minecraft:orange_terracotta
fill 257 81 290 258 81 291 minecraft:sandstone
fill 257 81 292 259 81 292 minecraft:gold_block
fill 257 81 294 259 81 294 minecraft:gold_block
fill 257 81 300 259 81 300 minecraft:gold_block
fill 257 81 302 259 81 302 minecraft:gold_block
fill 257 81 303 258 81 303 minecraft:sandstone
setblock 257 81 305 minecraft:orange_terracotta
fill 257 81 306 259 81 306 minecraft:sandstone
setblock 257 81 309 minecraft:orange_terracotta
fill 257 81 310 259 81 310 minecraft:sandstone
setblock 257 81 313 minecraft:orange_terracotta
fill 257 81 314 259 81 314 minecraft:sandstone
setblock 258 81 276 minecraft:orange_terracotta
fill 258 81 277 258 81 279 minecraft:sandstone
setblock 258 81 280 minecraft:orange_terracotta
fill 258 81 281 260 81 281 minecraft:sandstone
setblock 258 81 284 minecraft:orange_terracotta
fill 258 81 285 260 81 285 minecraft:sandstone
setblock 258 81 288 minecraft:orange_terracotta
fill 258 81 289 260 81 289 minecraft:sandstone
fill 258 81 293 259 81 293 minecraft:lapis_block
fill 258 81 301 259 81 301 minecraft:lapis_block
setblock 258 81 304 minecraft:orange_terracotta
fill 258 81 305 260 81 305 minecraft:sandstone
setblock 258 81 308 minecraft:orange_terracotta
fill 258 81 309 260 81 309 minecraft:sandstone
setblock 258 81 312 minecraft:orange_terracotta
fill 258 81 313 260 81 313 minecraft:sandstone
setblock 258 81 316 minecraft:orange_terracotta
fill 259 81 276 259 81 278 minecraft:sandstone
setblock 259 81 279 minecraft:orange_terracotta
fill 259 81 280 261 81 280 minecraft:sandstone
setblock 259 81 283 minecraft:orange_terracotta
fill 259 81 284 261 81 284 minecraft:sandstone
setblock 259 81 287 minecraft:orange_terracotta
fill 259 81 288 261 81 288 minecraft:sandstone
setblock 259 81 290 minecraft:sandstone
setblock 259 81 291 minecraft:orange_terracotta
fill 259 81 295 259 81 296 minecraft:gold_block
fill 259 81 298 259 81 299 minecraft:gold_block
setblock 259 81 303 minecraft:orange_terracotta
fill 259 81 304 261 81 304 minecraft:sandstone
setblock 259 81 307 minecraft:orange_terracotta
fill 259 81 308 261 81 308 minecraft:sandstone
setblock 259 81 311 minecraft:orange_terracotta
fill 259 81 312 261 81 312 minecraft:sandstone
setblock 259 81 315 minecraft:orange_terracotta
fill 259 81 316 261 81 316 minecraft:sandstone
fill 260 81 276 260 81 277 minecraft:sandstone
setblock 260 81 278 minecraft:orange_terracotta
fill 260 81 279 262 81 279 minecraft:sandstone
setblock 260 81 282 minecraft:orange_terracotta
fill 260 81 283 262 81 283 minecraft:sandstone
setblock 260 81 286 minecraft:orange_terracotta
fill 260 81 287 262 81 287 minecraft:sandstone
setblock 260 81 290 minecraft:orange_terracotta
fill 260 81 291 261 81 292 minecraft:sandstone
setblock 260 81 293 minecraft:gold_block
fill 260 81 294 260 81 295 minecraft:lapis_block
fill 260 81 296 260 81 298 minecraft:gold_block
fill 260 81 299 260 81 300 minecraft:lapis_block
setblock 260 81 301 minecraft:gold_block
setblock 260 81 302 minecraft:orange_terracotta
fill 260 81 303 262 81 303 minecraft:sandstone
setblock 260 81 306 minecraft:orange_terracotta
fill 260 81 307 262 81 307 minecraft:sandstone
setblock 260 81 310 minecraft:orange_terracotta
fill 260 81 311 262 81 311 minecraft:sandstone
setblock 260 81 314 minecraft:orange_terracotta
fill 260 81 315 262 81 315 minecraft:sandstone
setblock 261 81 276 minecraft:sandstone
setblock 261 81 277 minecraft:orange_terracotta
fill 261 81 278 263 81 278 minecraft:sandstone
setblock 261 81 281 minecraft:orange_terracotta
fill 261 81 282 263 81 282 minecraft:sandstone
setblock 261 81 285 minecraft:orange_terracotta
fill 261 81 286 263 81 286 minecraft:sandstone
setblock 261 81 289 minecraft:orange_terracotta
fill 261 81 290 263 81 290 minecraft:sandstone
setblock 261 81 293 minecraft:orange_terracotta
fill 261 81 294 261 81 295 minecraft:gold_block
fill 261 81 297 268 81 297 minecraft:cyan_terracotta
fill 261 81 299 261 81 300 minecraft:gold_block
setblock 261 81 301 minecraft:orange_terracotta
fill 261 81 302 263 81 302 minecraft:sandstone
setblock 261 81 305 minecraft:orange_terracotta
fill 261 81 306 263 81 306 minecraft:sandstone
setblock 261 81 309 minecraft:orange_terracotta
fill 261 81 310 263 81 310 minecraft:sandstone
setblock 261 81 313 minecraft:orange_terracotta
fill 261 81 314 263 81 314 minecraft:sandstone
setblock 262 81 276 minecraft:orange_terracotta
fill 262 81 277 264 81 277 minecraft:sandstone
setblock 262 81 280 minecraft:orange_terracotta
fill 262 81 281 264 81 281 minecraft:sandstone
setblock 262 81 284 minecraft:orange_terracotta
fill 262 81 285 264 81 285 minecraft:sandstone
setblock 262 81 288 minecraft:orange_terracotta
fill 262 81 289 264 81 289 minecraft:sandstone
setblock 262 81 291 minecraft:sandstone
setblock 262 81 292 minecraft:orange_terracotta
fill 262 81 293 263 81 294 minecraft:sandstone
setblock 262 81 300 minecraft:orange_terracotta
fill 262 81 301 264 81 301 minecraft:sandstone
setblock 262 81 304 minecraft:orange_terracotta
fill 262 81 305 264 81 305 minecraft:sandstone
setblock 262 81 308 minecraft:orange_terracotta
fill 262 81 309 264 81 309 minecraft:sandstone
setblock 262 81 312 minecraft:orange_terracotta
fill 262 81 313 264 81 313 minecraft:sandstone
setblock 262 81 316 minecraft:orange_terracotta
fill 263 81 275 263 95 275 minecraft:smooth_sandstone
fill 263 81 276 265 81 276 minecraft:sandstone
setblock 263 81 279 minecraft:orange_terracotta
fill 263 81 280 265 81 280 minecraft:sandstone
setblock 263 81 283 minecraft:orange_terracotta
fill 263 81 284 265 81 284 minecraft:sandstone
setblock 263 81 287 minecraft:orange_terracotta
fill 263 81 288 265 81 288 minecraft:sandstone
setblock 263 81 291 minecraft:orange_terracotta
fill 263 81 292 265 81 292 minecraft:sandstone
fill 263 81 300 265 81 300 minecraft:sandstone
setblock 263 81 303 minecraft:orange_terracotta
fill 263 81 304 265 81 304 minecraft:sandstone
setblock 263 81 307 minecraft:orange_terracotta
fill 263 81 308 265 81 308 minecraft:sandstone
setblock 263 81 311 minecraft:orange_terracotta
fill 263 81 312 265 81 312 minecraft:sandstone
setblock 263 81 315 minecraft:orange_terracotta
fill 263 81 316 265 81 316 minecraft:sandstone
setblock 264 81 278 minecraft:orange_terracotta
fill 264 81 279 266 81 279 minecraft:sandstone
setblock 264 81 282 minecraft:orange_terracotta
fill 264 81 283 266 81 283 minecraft:sandstone
setblock 264 81 286 minecraft:orange_terracotta
fill 264 81 287 266 81 287 minecraft:sandstone
setblock 264 81 290 minecraft:orange_terracotta
fill 264 81 291 266 81 291 minecraft:sandstone
setblock 264 81 293 minecraft:sandstone
setblock 264 81 294 minecraft:orange_terracotta
setblock 264 81 302 minecraft:orange_terracotta
fill 264 81 303 266 81 303 minecraft:sandstone
setblock 264 81 306 minecraft:orange_terracotta
fill 264 81 307 266 81 307 minecraft:sandstone
setblock 264 81 310 minecraft:orange_terracotta
fill 264 81 311 266 81 311 minecraft:sandstone
setblock 264 81 314 minecraft:orange_terracotta
fill 264 81 315 266 81 315 minecraft:sandstone
setblock 265 81 277 minecraft:orange_terracotta
fill 265 81 278 267 81 278 minecraft:sandstone
setblock 265 81 281 minecraft:orange_terracotta
fill 265 81 282 267 81 282 minecraft:sandstone
setblock 265 81 285 minecraft:orange_terracotta
fill 265 81 286 267 81 286 minecraft:sandstone
setblock 265 81 289 minecraft:orange_terracotta
fill 265 81 290 267 81 290 minecraft:sandstone
setblock 265 81 293 minecraft:orange_terracotta
fill 265 81 294 267 81 294 minecraft:sandstone
setblock 265 81 301 minecraft:orange_terracotta
fill 265 81 302 267 81 302 minecraft:sandstone
setblock 265 81 305 minecraft:orange_terracotta
fill 265 81 306 267 81 306 minecraft:sandstone
setblock 265 81 309 minecraft:orange_terracotta
fill 265 81 310 267 81 310 minecraft:sandstone
setblock 265 81 313 minecraft:orange_terracotta
fill 265 81 314 267 81 314 minecraft:sandstone
setblock 266 81 276 minecraft:orange_terracotta
fill 266 81 277 268 81 277 minecraft:sandstone
setblock 266 81 280 minecraft:orange_terracotta
fill 266 81 281 268 81 281 minecraft:sandstone
setblock 266 81 284 minecraft:orange_terracotta
fill 266 81 285 268 81 285 minecraft:sandstone
setblock 266 81 288 minecraft:orange_terracotta
fill 266 81 289 268 81 289 minecraft:sandstone
setblock 266 81 292 minecraft:orange_terracotta
fill 266 81 293 268 81 293 minecraft:sandstone
setblock 266 81 300 minecraft:orange_terracotta
fill 266 81 301 268 81 301 minecraft:sandstone
setblock 266 81 304 minecraft:orange_terracotta
fill 266 81 305 268 81 305 minecraft:sandstone
setblock 266 81 308 minecraft:orange_terracotta
fill 266 81 309 268 81 309 minecraft:sandstone
setblock 266 81 312 minecraft:orange_terracotta
fill 266 81 313 268 81 313 minecraft:sandstone
setblock 266 81 316 minecraft:orange_terracotta
fill 267 81 276 269 81 276 minecraft:sandstone
setblock 267 81 279 minecraft:orange_terracotta
fill 267 81 280 269 81 280 minecraft:sandstone
setblock 267 81 283 minecraft:orange_terracotta
fill 267 81 284 269 81 284 minecraft:sandstone
setblock 267 81 287 minecraft:orange_terracotta
fill 267 81 288 269 81 288 minecraft:sandstone
setblock 267 81 291 minecraft:orange_terracotta
fill 267 81 292 269 81 292 minecraft:sandstone
setblock 267 81 295 minecraft:orange_terracotta
setblock 267 81 299 minecraft:orange_terracotta
fill 267 81 300 269 81 300 minecraft:sandstone
setblock 267 81 303 minecraft:orange_terracotta
fill 267 81 304 269 81 304 minecraft:sandstone
setblock 267 81 307 minecraft:orange_terracotta
fill 267 81 308 269 81 308 minecraft:sandstone
setblock 267 81 311 minecraft:orange_terracotta
fill 267 81 312 269 81 312 minecraft:sandstone
setblock 267 81 315 minecraft:orange_terracotta
fill 267 81 316 269 81 316 minecraft:sandstone
setblock 268 81 278 minecraft:orange_terracotta
fill 268 81 279 270 81 279 minecraft:sandstone
setblock 268 81 282 minecraft:orange_terracotta
fill 268 81 283 270 81 283 minecraft:sandstone
setblock 268 81 286 minecraft:orange_terracotta
fill 268 81 287 270 81 287 minecraft:sandstone
setblock 268 81 290 minecraft:orange_terracotta
fill 268 81 291 270 81 291 minecraft:sandstone
setblock 268 81 294 minecraft:orange_terracotta
fill 268 81 295 269 81 296 minecraft:sandstone
setblock 268 81 298 minecraft:orange_terracotta
fill 268 81 299 270 81 299 minecraft:sandstone
setblock 268 81 302 minecraft:orange_terracotta
fill 268 81 303 270 81 303 minecraft:sandstone
setblock 268 81 306 minecraft:orange_terracotta
fill 268 81 307 270 81 307 minecraft:sandstone
setblock 268 81 310 minecraft:orange_terracotta
fill 268 81 311 270 81 311 minecraft:sandstone
setblock 268 81 314 minecraft:orange_terracotta
fill 268 81 315 270 81 315 minecraft:sandstone
setblock 269 81 277 minecraft:orange_terracotta
fill 269 81 278 271 81 278 minecraft:sandstone
setblock 269 81 281 minecraft:orange_terracotta
fill 269 81 282 271 81 282 minecraft:sandstone
setblock 269 81 285 minecraft:orange_terracotta
fill 269 81 286 271 81 286 minecraft:sandstone
setblock 269 81 289 minecraft:orange_terracotta
fill 269 81 290 271 81 290 minecraft:sandstone
setblock 269 81 293 minecraft:orange_terracotta
fill 269 81 294 271 81 294 minecraft:sandstone
setblock 269 81 297 minecraft:orange_terracotta
fill 269 81 298 271 81 298 minecraft:sandstone
setblock 269 81 301 minecraft:orange_terracotta
fill 269 81 302 271 81 302 minecraft:sandstone
setblock 269 81 305 minecraft:orange_terracotta
fill 269 81 306 271 81 306 minecraft:sandstone
setblock 269 81 309 minecraft:orange_terracotta
fill 269 81 310 271 81 310 minecraft:sandstone
setblock 269 81 313 minecraft:orange_terracotta
fill 269 81 314 271 81 314 minecraft:sandstone
setblock 270 81 276 minecraft:orange_terracotta
fill 270 81 277 272 81 277 minecraft:sandstone
setblock 270 81 280 minecraft:orange_terracotta
fill 270 81 281 272 81 281 minecraft:sandstone
setblock 270 81 284 minecraft:orange_terracotta
fill 270 81 285 272 81 285 minecraft:sandstone
setblock 270 81 288 minecraft:orange_terracotta
fill 270 81 289 272 81 289 minecraft:sandstone
setblock 270 81 292 minecraft:orange_terracotta
fill 270 81 293 272 81 293 minecraft:sandstone
setblock 270 81 295 minecraft:sandstone
setblock 270 81 296 minecraft:orange_terracotta
fill 270 81 297 272 81 297 minecraft:sandstone
setblock 270 81 300 minecraft:orange_terracotta
fill 270 81 301 272 81 301 minecraft:sandstone
setblock 270 81 304 minecraft:orange_terracotta
fill 270 81 305 272 81 305 minecraft:sandstone
setblock 270 81 308 minecraft:orange_terracotta
fill 270 81 309 272 81 309 minecraft:sandstone
setblock 270 81 312 minecraft:orange_terracotta
fill 270 81 313 272 81 313 minecraft:sandstone
setblock 270 81 316 minecraft:orange_terracotta
fill 271 81 276 273 81 276 minecraft:sandstone
setblock 271 81 279 minecraft:orange_terracotta
fill 271 81 280 273 81 280 minecraft:sandstone
setblock 271 81 283 minecraft:orange_terracotta
fill 271 81 284 273 81 284 minecraft:sandstone
setblock 271 81 287 minecraft:orange_terracotta
fill 271 81 288 273 81 288 minecraft:sandstone
setblock 271 81 291 minecraft:orange_terracotta
fill 271 81 292 273 81 292 minecraft:sandstone
setblock 271 81 295 minecraft:orange_terracotta
fill 271 81 296 273 81 296 minecraft:sandstone
setblock 271 81 299 minecraft:orange_terracotta
fill 271 81 300 273 81 300 minecraft:sandstone
setblock 271 81 303 minecraft:orange_terracotta
fill 271 81 304 273 81 304 minecraft:sandstone
setblock 271 81 307 minecraft:orange_terracotta
fill 271 81 308 273 81 308 minecraft:sandstone
setblock 271 81 311 minecraft:orange_terracotta
fill 271 81 312 273 81 312 minecraft:sandstone
setblock 271 81 315 minecraft:orange_terracotta
fill 271 81 316 273 81 316 minecraft:sandstone
setblock 272 81 278 minecraft:orange_terracotta
fill 272 81 279 274 81 279 minecraft:sandstone
setblock 272 81 282 minecraft:orange_terracotta
fill 272 81 283 274 81 283 minecraft:sandstone
setblock 272 81 286 minecraft:orange_terracotta
fill 272 81 287 274 81 287 minecraft:sandstone
setblock 272 81 290 minecraft:orange_terracotta
fill 272 81 291 274 81 291 minecraft:sandstone
setblock 272 81 294 minecraft:orange_terracotta
fill 272 81 295 274 81 295 minecraft:sandstone
setblock 272 81 298 minecraft:orange_terracotta
fill 272 81 299 274 81 299 minecraft:sandstone
setblock 272 81 302 minecraft:orange_terracotta
fill 272 81 303 274 81 303 minecraft:sandstone
setblock 272 81 306 minecraft:orange_terracotta
fill 272 81 307 274 81 307 minecraft:sandstone
setblock 272 81 310 minecraft:orange_terracotta
fill 272 81 311 274 81 311 minecraft:sandstone
setblock 272 81 314 minecraft:orange_terracotta
fill 272 81 315 274 81 315 minecraft:sandstone
setblock 273 81 277 minecraft:orange_terracotta
fill 273 81 278 275 81 278 minecraft:sandstone
setblock 273 81 281 minecraft:orange_terracotta
fill 273 81 282 275 81 282 minecraft:sandstone
setblock 273 81 285 minecraft:orange_terracotta
fill 273 81 286 275 81 286 minecraft:sandstone
setblock 273 81 289 minecraft:orange_terracotta
fill 273 81 290 275 81 290 minecraft:sandstone
setblock 273 81 293 minecraft:orange_terracotta
fill 273 81 294 275 81 294 minecraft:sandstone
setblock 273 81 297 minecraft:orange_terracotta
fill 273 81 298 275 81 298 minecraft:sandstone
setblock 273 81 301 minecraft:orange_terracotta
fill 273 81 302 275 81 302 minecraft:sandstone
setblock 273 81 305 minecraft:orange_terracotta
fill 273 81 306 275 81 306 minecraft:sandstone
setblock 273 81 309 minecraft:orange_terracotta
fill 273 81 310 275 81 310 minecraft:sandstone
setblock 273 81 313 minecraft:orange_terracotta
fill 273 81 314 275 81 314 minecraft:sandstone
setblock 274 81 276 minecraft:orange_terracotta
fill 274 81 277 276 81 277 minecraft:sandstone
setblock 274 81 280 minecraft:orange_terracotta
fill 274 81 281 276 81 281 minecraft:sandstone
setblock 274 81 284 minecraft:orange_terracotta
fill 274 81 285 276 81 285 minecraft:sandstone
setblock 274 81 288 minecraft:orange_terracotta
fill 274 81 289 276 81 289 minecraft:sandstone
setblock 274 81 292 minecraft:orange_terracotta
fill 274 81 293 276 81 293 minecraft:sandstone
setblock 274 81 296 minecraft:orange_terracotta
fill 274 81 297 276 81 297 minecraft:sandstone
setblock 274 81 300 minecraft:orange_terracotta
fill 274 81 301 276 81 301 minecraft:sandstone
setblock 274 81 304 minecraft:orange_terracotta
fill 274 81 305 276 81 305 minecraft:sandstone
setblock 274 81 308 minecraft:orange_terracotta
fill 274 81 309 276 81 309 minecraft:sandstone
setblock 274 81 312 minecraft:orange_terracotta
fill 274 81 313 276 81 313 minecraft:sandstone
setblock 274 81 316 minecraft:orange_terracotta
fill 275 81 276 276 81 276 minecraft:sandstone
setblock 275 81 279 minecraft:orange_terracotta
fill 275 81 280 276 81 280 minecraft:sandstone
setblock 275 81 283 minecraft:orange_terracotta
fill 275 81 284 276 81 284 minecraft:sandstone
setblock 275 81 287 minecraft:orange_terracotta
fill 275 81 288 276 81 288 minecraft:sandstone
setblock 275 81 291 minecraft:orange_terracotta
fill 275 81 292 276 81 292 minecraft:sandstone
setblock 275 81 295 minecraft:orange_terracotta
fill 275 81 296 276 81 296 minecraft:sandstone
setblock 275 81 299 minecraft:orange_terracotta
fill 275 81 300 276 81 300 minecraft:sandstone
setblock 275 81 303 minecraft:orange_terracotta
fill 275 81 304 276 81 304 minecraft:sandstone
setblock 275 81 307 minecraft:orange_terracotta
fill 275 81 308 276 81 308 minecraft:sandstone
setblock 275 81 311 minecraft:orange_terracotta
fill 275 81 312 276 81 312 minecraft:sandstone
setblock 275 81 315 minecraft:orange_terracotta
fill 275 81 316 276 81 316 minecraft:sandstone
setblock 276 81 278 minecraft:orange_terracotta
setblock 276 81 279 minecraft:sandstone
setblock 276 81 282 minecraft:orange_terracotta
setblock 276 81 283 minecraft:sandstone
setblock 276 81 286 minecraft:orange_terracotta
setblock 276 81 287 minecraft:sandstone
setblock 276 81 290 minecraft:orange_terracotta
setblock 276 81 291 minecraft:sandstone
setblock 276 81 294 minecraft:orange_terracotta
setblock 276 81 295 minecraft:sandstone
setblock 276 81 298 minecraft:orange_terracotta
setblock 276 81 299 minecraft:sandstone
setblock 276 81 302 minecraft:orange_terracotta
setblock 276 81 303 minecraft:sandstone
setblock 276 81 306 minecraft:orange_terracotta
setblock 276 81 307 minecraft:sandstone
setblock 276 81 310 minecraft:orange_terracotta
setblock 276 81 311 minecraft:sandstone
setblock 276 81 314 minecraft:orange_terracotta
setblock 276 81 315 minecraft:sandstone
fill 277 81 301 277 82 301 minecraft:smooth_sandstone
fill 235 82 290 235 92 290 minecraft:smooth_sandstone
setblock 235 82 294 minecraft:blue_terracotta
fill 235 82 295 235 85 295 minecraft:smooth_sandstone
fill 237 82 275 237 95 275 minecraft:smooth_sandstone
fill 257 82 312 257 84 312 minecraft:shroomlight
setblock 272 82 317 minecraft:orange_terracotta
fill 273 82 317 273 85 317 minecraft:smooth_sandstone
setblock 277 82 292 minecraft:lapis_block
fill 235 83 294 235 85 294 minecraft:smooth_sandstone
fill 272 83 317 272 85 317 minecraft:smooth_sandstone
setblock 277 83 288 minecraft:orange_terracotta
fill 277 83 292 277 95 292 minecraft:smooth_sandstone
setblock 277 83 301 minecraft:black_terracotta
setblock 235 84 292 minecraft:black_terracotta
fill 277 84 288 277 85 288 minecraft:smooth_sandstone
setblock 277 84 293 minecraft:blue_terracotta
fill 277 84 301 277 85 301 minecraft:smooth_sandstone
fill 235 85 292 235 96 292 minecraft:smooth_sandstone
fill 236 85 276 239 97 278 minecraft:cut_sandstone
fill 236 85 279 236 85 284 minecraft:chiseled_sandstone
fill 236 85 286 236 186 288 minecraft:cut_sandstone
fill 236 85 291 236 85 296 minecraft:chiseled_sandstone
fill 236 85 298 236 186 300 minecraft:cut_sandstone
fill 236 85 303 236 85 308 minecraft:chiseled_sandstone
fill 236 85 310 236 186 312 minecraft:cut_sandstone
fill 236 85 315 236 85 316 minecraft:chiseled_sandstone
fill 237 85 279 237 85 287 minecraft:cut_sandstone
fill 237 85 296 238 85 296 minecraft:chiseled_sandstone
fill 237 85 297 237 85 299 minecraft:cut_sandstone
fill 237 85 309 237 85 311 minecraft:cut_sandstone
fill 237 85 316 240 85 316 minecraft:chiseled_sandstone
fill 238 85 279 245 97 284 minecraft:cut_sandstone
fill 240 85 276 245 85 276 minecraft:chiseled_sandstone
fill 240 85 277 245 97 278 minecraft:cut_sandstone
fill 242 85 316 244 186 316 minecraft:cut_sandstone
fill 243 85 315 245 85 315 minecraft:cut_sandstone
fill 245 85 313 245 85 314 minecraft:chiseled_sandstone
setblock 246 85 275 minecraft:black_terracotta
fill 247 85 277 249 85 277 minecraft:cut_sandstone
fill 247 85 316 252 85 316 minecraft:chiseled_sandstone
fill 248 85 276 250 186 276 minecraft:cut_sandstone
setblock 251 85 317 minecraft:blue_terracotta
fill 252 85 276 257 85 276 minecraft:chiseled_sandstone
fill 252 85 313 253 85 314 minecraft:chiseled_sandstone
fill 254 85 316 256 186 316 minecraft:cut_sandstone
fill 255 85 315 257 85 315 minecraft:cut_sandstone
fill 259 85 277 261 85 277 minecraft:cut_sandstone
fill 259 85 316 264 85 316 minecraft:chiseled_sandstone
fill 260 85 276 262 186 276 minecraft:cut_sandstone
fill 264 85 276 269 85 276 minecraft:chiseled_sandstone
fill 266 85 316 268 186 316 minecraft:cut_sandstone
fill 267 85 315 269 85 315 minecraft:cut_sandstone
fill 271 85 277 273 85 277 minecraft:cut_sandstone
fill 271 85 316 276 85 316 minecraft:chiseled_sandstone
fill 272 85 276 274 186 276 minecraft:cut_sandstone
fill 274 85 303 274 86 307 minecraft:blue_wool
fill 275 85 285 275 85 287 minecraft:cut_sandstone
fill 275 85 297 275 85 299 minecraft:cut_sandstone
fill 275 85 309 275 85 311 minecraft:cut_sandstone
fill 276 85 276 276 85 281 minecraft:chiseled_sandstone
fill 276 85 284 276 186 286 minecraft:cut_sandstone
fill 276 85 288 276 85 293 minecraft:chiseled_sandstone
fill 276 85 296 276 186 298 minecraft:cut_sandstone
fill 276 85 300 276 85 305 minecraft:chiseled_sandstone
fill 276 85 308 276 186 310 minecraft:cut_sandstone
fill 276 85 312 276 85 315 minecraft:chiseled_sandstone
fill 277 85 293 277 95 293 minecraft:smooth_sandstone
fill 235 86 281 235 91 284 minecraft:glowstone
fill 235 86 293 235 91 296 minecraft:glowstone
fill 235 86 305 235 91 308 minecraft:glowstone
setblock 235 86 311 minecraft:black_terracotta
fill 235 86 317 238 91 317 minecraft:glowstone
fill 236 86 279 237 97 284 minecraft:cut_sandstone
fill 236 86 296 237 86 296 minecraft:chiseled_sandstone
fill 240 86 276 245 97 276 minecraft:cut_sandstone
fill 242 86 275 245 91 275 minecraft:glowstone
fill 244 86 298 244 87 298 minecraft:sandstone
fill 245 86 314 245 86 315 minecraft:chiseled_sandstone
fill 246 86 275 246 95 275 minecraft:smooth_sandstone
fill 247 86 317 250 91 317 minecraft:glowstone
fill 251 86 317 251 93 317 minecraft:smooth_sandstone
fill 252 86 314 253 86 315 minecraft:chiseled_sandstone
fill 254 86 275 257 91 275 minecraft:glowstone
fill 259 86 317 262 91 317 minecraft:glowstone
fill 266 86 275 269 91 275 minecraft:glowstone
fill 271 86 317 274 91 317 minecraft:glowstone
fill 277 86 276 277 91 279 minecraft:glowstone
fill 277 86 288 277 91 291 minecraft:glowstone
fill 277 86 300 277 91 303 minecraft:glowstone
fill 277 86 312 277 91 315 minecraft:glowstone
fill 235 87 311 235 95 311 minecraft:smooth_sandstone
setblock 236 87 296 minecraft:chiseled_sandstone
setblock 238 87 285 minecraft:light[level=12]
setblock 238 87 286 minecraft:light[level=15]
setblock 238 87 292 minecraft:light[level=12]
setblock 238 87 294 minecraft:light[level=15]
setblock 238 87 299 minecraft:light[level=12]
setblock 238 87 302 minecraft:light[level=15]
setblock 238 87 306 minecraft:light[level=12]
setblock 238 87 310 minecraft:light[level=15]
setblock 238 87 313 minecraft:light[level=12]
setblock 243 87 285 minecraft:glowstone
setblock 243 87 291 minecraft:glowstone
setblock 243 87 297 minecraft:glowstone
setblock 243 87 303 minecraft:glowstone
setblock 243 87 309 minecraft:glowstone
setblock 245 87 285 minecraft:light[level=12]
setblock 245 87 292 minecraft:light[level=12]
setblock 245 87 299 minecraft:light[level=12]
setblock 245 87 306 minecraft:light[level=12]
setblock 245 87 313 minecraft:light[level=12]
setblock 245 87 315 minecraft:chiseled_sandstone
setblock 246 87 278 minecraft:light[level=15]
setblock 246 87 286 minecraft:light[level=15]
setblock 246 87 294 minecraft:light[level=15]
setblock 246 87 302 minecraft:light[level=15]
setblock 246 87 310 minecraft:light[level=15]
setblock 249 87 309 minecraft:glowstone
setblock 251 87 283 minecraft:glowstone
setblock 252 87 278 minecraft:light[level=12]
setblock 252 87 285 minecraft:light[level=12]
setblock 252 87 292 minecraft:light[level=12]
setblock 252 87 299 minecraft:light[level=12]
setblock 252 87 306 minecraft:light[level=12]
setblock 252 87 313 minecraft:light[level=12]
fill 252 87 315 253 87 315 minecraft:chiseled_sandstone
setblock 254 87 278 minecraft:light[level=15]
setblock 254 87 286 minecraft:light[level=15]
setblock 254 87 294 minecraft:light[level=15]
setblock 254 87 302 minecraft:light[level=15]
setblock 254 87 310 minecraft:light[level=15]
setblock 255 87 309 minecraft:glowstone
setblock 257 87 283 minecraft:glowstone
setblock 259 87 278 minecraft:light[level=12]
setblock 259 87 285 minecraft:light[level=12]
setblock 259 87 292 minecraft:light[level=12]
setblock 259 87 299 minecraft:light[level=12]
setblock 259 87 306 minecraft:light[level=12]
setblock 259 87 313 minecraft:light[level=12]
setblock 261 87 275 minecraft:lapis_block
setblock 261 87 309 minecraft:glowstone
setblock 262 87 278 minecraft:light[level=15]
setblock 262 87 286 minecraft:light[level=15]
setblock 262 87 294 minecraft:light[level=15]
setblock 262 87 302 minecraft:light[level=15]
setblock 262 87 310 minecraft:light[level=15]
setblock 263 87 283 minecraft:glowstone
setblock 266 87 278 minecraft:light[level=12]
setblock 266 87 285 minecraft:light[level=12]
setblock 266 87 292 minecraft:light[level=12]
setblock 266 87 299 minecraft:light[level=12]
setblock 266 87 306 minecraft:light[level=12]
setblock 266 87 313 minecraft:light[level=12]
setblock 267 87 309 minecraft:glowstone
setblock 269 87 283 minecraft:glowstone
setblock 269 87 289 minecraft:glowstone
setblock 269 87 295 minecraft:glowstone
setblock 269 87 301 minecraft:glowstone
setblock 269 87 307 minecraft:glowstone
setblock 270 87 278 minecraft:light[level=15]
setblock 270 87 286 minecraft:light[level=15]
setblock 270 87 294 minecraft:light[level=15]
setblock 270 87 302 minecraft:light[level=15]
setblock 270 87 310 minecraft:light[level=15]
setblock 273 87 278 minecraft:light[level=12]
setblock 273 87 285 minecraft:light[level=12]
setblock 273 87 292 minecraft:light[level=12]
setblock 273 87 299 minecraft:light[level=12]
setblock 273 87 306 minecraft:light[level=12]
setblock 273 87 313 minecraft:light[level=12]
fill 274 87 302 274 87 308 minecraft:iron_block
setblock 235 88 309 minecraft:blue_terracotta
fill 236 88 285 243 88 285 minecraft:cut_sandstone
fill 236 88 289 243 88 297 minecraft:cut_sandstone
fill 236 88 301 243 88 309 minecraft:cut_sandstone
fill 236 88 313 241 88 316 minecraft:cut_sandstone
fill 237 88 286 243 88 288 minecraft:cut_sandstone
fill 237 88 298 243 88 300 minecraft:cut_sandstone
fill 237 88 310 275 88 312 minecraft:cut_sandstone
fill 242 88 313 276 88 315 minecraft:cut_sandstone
fill 244 88 309 275 88 309 minecraft:cut_sandstone
fill 245 88 316 253 88 316 minecraft:cut_sandstone
fill 246 88 276 247 88 283 minecraft:cut_sandstone
fill 248 88 277 276 88 283 minecraft:cut_sandstone
fill 249 88 290 250 89 291 minecraft:smooth_sandstone
fill 251 88 276 259 88 276 minecraft:cut_sandstone
fill 257 88 316 265 88 316 minecraft:cut_sandstone
fill 261 88 275 261 95 275 minecraft:smooth_sandstone
fill 263 88 276 271 88 276 minecraft:cut_sandstone
fill 269 88 284 275 88 308 minecraft:cut_sandstone
fill 269 88 316 276 88 316 minecraft:cut_sandstone
fill 275 88 276 276 88 276 minecraft:cut_sandstone
fill 276 88 287 276 88 295 minecraft:cut_sandstone
fill 276 88 299 276 88 307 minecraft:cut_sandstone
fill 276 88 311 276 88 312 minecraft:cut_sandstone
fill 235 89 309 235 91 309 minecraft:smooth_sandstone
fill 243 89 285 243 89 309 minecraft:lapis_block
fill 244 89 309 269 89 309 minecraft:lapis_block
fill 246 89 283 269 89 283 minecraft:lapis_block
fill 252 89 313 253 90 314 minecraft:smooth_sandstone
fill 269 89 284 269 89 308 minecraft:lapis_block
setblock 270 89 275 minecraft:orange_terracotta
setblock 270 89 299 minecraft:smooth_sandstone
fill 270 90 275 270 93 275 minecraft:smooth_sandstone
setblock 277 90 295 minecraft:lapis_block
setblock 235 91 287 minecraft:blue_terracotta
setblock 235 91 299 minecraft:black_terracotta
fill 277 91 295 277 95 295 minecraft:smooth_sandstone
fill 235 92 281 235 95 281 minecraft:smooth_sandstone
fill 235 92 282 235 92 283 minecraft:glowstone
setblock 235 92 284 minecraft:sandstone
fill 235 92 287 235 95 287 minecraft:smooth_sandstone
setblock 235 92 288 minecraft:orange_terracotta
setblock 235 92 293 minecraft:smooth_sandstone
fill 235 92 294 235 92 295 minecraft:glowstone
fill 235 92 296 235 96 296 minecraft:smooth_sandstone
setblock 235 92 298 minecraft:sandstone
fill 235 92 299 235 93 299 minecraft:smooth_sandstone
fill 235 92 305 235 95 305 minecraft:smooth_sandstone
fill 235 92 306 235 92 307 minecraft:glowstone
fill 235 92 308 235 95 308 minecraft:smooth_sandstone
setblock 235 92 309 minecraft:sandstone
fill 235 92 316 235 92 317 minecraft:sandstone
fill 236 92 317 237 92 317 minecraft:glowstone
setblock 238 92 275 minecraft:sandstone
fill 238 92 317 238 95 317 minecraft:smooth_sandstone
setblock 239 92 317 minecraft:sandstone
fill 242 92 275 242 95 275 minecraft:smooth_sandstone
fill 243 92 275 244 92 275 minecraft:glowstone
fill 244 92 317 245 92 317 minecraft:sandstone
fill 245 92 275 245 95 275 minecraft:smooth_sandstone
fill 247 92 317 247 95 317 minecraft:smooth_sandstone
fill 248 92 317 249 92 317 minecraft:glowstone
fill 249 92 275 249 93 275 minecraft:sandstone
fill 250 92 317 250 93 317 minecraft:sandstone
fill 254 92 275 254 95 275 minecraft:smooth_sandstone
fill 255 92 275 256 92 275 minecraft:glowstone
fill 257 92 275 257 95 275 minecraft:smooth_sandstone
setblock 257 92 317 minecraft:sandstone
fill 259 92 317 259 95 317 minecraft:smooth_sandstone
fill 260 92 317 261 92 317 minecraft:glowstone
fill 262 92 317 262 95 317 minecraft:smooth_sandstone
fill 266 92 275 266 95 275 minecraft:smooth_sandstone
fill 267 92 275 268 92 275 minecraft:glowstone
fill 269 92 275 269 95 275 minecraft:smooth_sandstone
setblock 271 92 275 minecraft:sandstone
fill 271 92 317 271 95 317 minecraft:smooth_sandstone
fill 272 92 317 273 92 317 minecraft:glowstone
fill 274 92 275 275 92 275 minecraft:sandstone
fill 274 92 317 274 95 317 minecraft:smooth_sandstone
fill 277 92 276 277 95 276 minecraft:smooth_sandstone
fill 277 92 277 277 92 278 minecraft:glowstone
fill 277 92 279 277 95 279 minecraft:smooth_sandstone
fill 277 92 280 277 93 280 minecraft:sandstone
setblock 277 92 282 minecraft:sandstone
fill 277 92 288 277 95 288 minecraft:smooth_sandstone
fill 277 92 289 277 92 290 minecraft:glowstone
fill 277 92 291 277 95 291 minecraft:smooth_sandstone
setblock 277 92 298 minecraft:sandstone
fill 277 92 300 277 95 300 minecraft:smooth_sandstone
fill 277 92 301 277 92 302 minecraft:glowstone
fill 277 92 303 277 96 303 minecraft:smooth_sandstone
setblock 277 92 305 minecraft:sandstone
fill 277 92 309 277 92 310 minecraft:sandstone
fill 277 92 312 277 96 312 minecraft:smooth_sandstone
fill 277 92 313 277 92 314 minecraft:glowstone
setblock 277 92 315 minecraft:smooth_sandstone
setblock 277 92 316 minecraft:sandstone
setblock 235 93 275 minecraft:sandstone
fill 235 93 276 235 95 278 minecraft:smooth_sandstone
setblock 235 93 279 minecraft:sandstone
fill 235 93 282 235 95 283 minecraft:smooth_sandstone
setblock 235 93 284 minecraft:black_terracotta
fill 235 93 288 235 95 288 minecraft:smooth_sandstone
setblock 235 93 290 minecraft:sandstone
setblock 235 93 293 minecraft:sandstone
fill 235 93 294 235 95 294 minecraft:smooth_sandstone
setblock 235 93 295 minecraft:sandstone
fill 235 93 298 235 96 298 minecraft:smooth_sandstone
setblock 235 93 301 minecraft:sandstone
setblock 235 93 303 minecraft:sandstone
fill 235 93 306 235 93 307 minecraft:smooth_sandstone
fill 235 93 309 235 95 309 minecraft:smooth_sandstone
setblock 235 93 313 minecraft:sandstone
fill 235 93 316 235 95 317 minecraft:smooth_sandstone
fill 236 93 317 237 93 317 minecraft:smooth_sandstone
fill 238 93 275 238 96 275 minecraft:smooth_sandstone
setblock 238 93 285 minecraft:light[level=12]
setblock 238 93 292 minecraft:light[level=12]
setblock 238 93 299 minecraft:light[level=12]
setblock 238 93 306 minecraft:light[level=12]
setblock 238 93 313 minecraft:light[level=12]
fill 239 93 317 239 95 317 minecraft:smooth_sandstone
fill 243 93 275 244 93 275 minecraft:smooth_sandstone
setblock 244 93 317 minecraft:sandstone
setblock 245 93 285 minecraft:light[level=12]
setblock 245 93 292 minecraft:light[level=12]
setblock 245 93 299 minecraft:light[level=12]
setblock 245 93 306 minecraft:light[level=12]
setblock 245 93 313 minecraft:light[level=12]
fill 245 93 317 245 95 317 minecraft:smooth_sandstone
fill 248 93 317 249 95 317 minecraft:smooth_sandstone
setblock 252 93 278 minecraft:light[level=12]
setblock 252 93 285 minecraft:light[level=12]
setblock 252 93 292 minecraft:light[level=12]
setblock 252 93 299 minecraft:light[level=12]
setblock 252 93 306 minecraft:light[level=12]
setblock 252 93 313 minecraft:light[level=12]
setblock 253 93 275 minecraft:sandstone
fill 255 93 275 256 95 275 minecraft:smooth_sandstone
setblock 255 93 317 minecraft:sandstone
fill 257 93 317 257 95 317 minecraft:smooth_sandstone
setblock 259 93 278 minecraft:light[level=12]
setblock 259 93 285 minecraft:light[level=12]
setblock 259 93 292 minecraft:light[level=12]
setblock 259 93 299 minecraft:light[level=12]
setblock 259 93 306 minecraft:light[level=12]
setblock 259 93 313 minecraft:light[level=12]
fill 260 93 317 261 93 317 minecraft:smooth_sandstone
setblock 266 93 278 minecraft:light[level=12]
setblock 266 93 285 minecraft:light[level=12]
setblock 266 93 292 minecraft:light[level=12]
setblock 266 93 299 minecraft:light[level=12]
setblock 266 93 306 minecraft:light[level=12]
setblock 266 93 313 minecraft:light[level=12]
fill 267 93 275 268 94 275 minecraft:smooth_sandstone
setblock 270 93 317 minecraft:sandstone
fill 271 93 275 271 97 275 minecraft:smooth_sandstone
fill 272 93 317 273 95 317 minecraft:smooth_sandstone
setblock 273 93 278 minecraft:light[level=12]
setblock 273 93 285 minecraft:light[level=12]
setblock 273 93 292 minecraft:light[level=12]
setblock 273 93 299 minecraft:light[level=12]
setblock 273 93 306 minecraft:light[level=12]
setblock 273 93 313 minecraft:light[level=12]
fill 274 93 275 274 96 275 minecraft:smooth_sandstone
setblock 275 93 275 minecraft:sandstone
fill 277 93 277 277 95 278 minecraft:smooth_sandstone
setblock 277 93 281 minecraft:sandstone
fill 277 93 282 277 96 282 minecraft:smooth_sandstone
fill 277 93 289 277 93 290 minecraft:smooth_sandstone
setblock 277 93 298 minecraft:smooth_sandstone
setblock 277 93 301 minecraft:sandstone
fill 277 93 302 277 95 302 minecraft:smooth_sandstone
setblock 277 93 304 minecraft:orange_terracotta
fill 277 93 305 277 95 305 minecraft:smooth_sandstone
setblock 277 93 307 minecraft:sandstone
fill 277 93 309 277 95 309 minecraft:smooth_sandstone
setblock 277 93 310 minecraft:lapis_block
fill 277 93 313 277 95 314 minecraft:smooth_sandstone
setblock 277 93 315 minecraft:sandstone
setblock 277 93 316 minecraft:smooth_sandstone
fill 235 94 275 235 96 275 minecraft:smooth_sandstone
fill 235 94 279 235 95 279 minecraft:smooth_sandstone
fill 235 94 284 235 95 284 minecraft:smooth_sandstone
setblock 235 94 289 minecraft:sandstone
fill 235 94 290 235 95 290 minecraft:smooth_sandstone
fill 235 94 293 235 95 293 minecraft:smooth_sandstone
fill 235 94 295 235 95 295 minecraft:smooth_sandstone
setblock 235 94 299 minecraft:sandstone
fill 235 94 301 235 95 301 minecraft:smooth_sandstone
fill 235 94 303 235 95 303 minecraft:smooth_sandstone
fill 235 94 306 235 95 306 minecraft:smooth_sandstone
setblock 235 94 307 minecraft:sandstone
setblock 235 94 310 minecraft:sandstone
fill 235 94 313 235 95 313 minecraft:smooth_sandstone
setblock 235 94 314 minecraft:sandstone
setblock 236 94 317 minecraft:sandstone
fill 237 94 317 237 95 317 minecraft:smooth_sandstone
fill 243 94 275 243 95 275 minecraft:smooth_sandstone
setblock 244 94 275 minecraft:sandstone
fill 244 94 317 244 95 317 minecraft:smooth_sandstone
fill 249 94 275 249 95 275 minecraft:smooth_sandstone
fill 250 94 317 250 96 317 minecraft:smooth_sandstone
setblock 251 94 317 minecraft:sandstone
fill 253 94 275 253 96 275 minecraft:smooth_sandstone
fill 255 94 317 255 95 317 minecraft:smooth_sandstone
setblock 260 94 317 minecraft:sandstone
fill 261 94 317 261 95 317 minecraft:smooth_sandstone
setblock 270 94 275 minecraft:sandstone
fill 270 94 317 270 95 317 minecraft:smooth_sandstone
fill 272 94 275 273 94 275 minecraft:sandstone
fill 275 94 275 275 95 275 minecraft:smooth_sandstone
fill 277 94 280 277 95 281 minecraft:smooth_sandstone
setblock 277 94 283 minecraft:orange_terracotta
setblock 277 94 289 minecraft:sandstone
fill 277 94 290 277 96 290 minecraft:smooth_sandstone
setblock 277 94 298 minecraft:black_terracotta
fill 277 94 301 277 95 301 minecraft:smooth_sandstone
fill 277 94 304 277 95 304 minecraft:smooth_sandstone
fill 277 94 307 277 95 307 minecraft:smooth_sandstone
fill 277 94 310 277 96 310 minecraft:smooth_sandstone
fill 277 94 315 277 95 315 minecraft:smooth_sandstone
setblock 277 94 316 minecraft:lapis_block
setblock 235 95 289 minecraft:smooth_sandstone
setblock 235 95 299 minecraft:smooth_sandstone
setblock 235 95 307 minecraft:smooth_sandstone
setblock 235 95 310 minecraft:smooth_sandstone
setblock 235 95 314 minecraft:smooth_sandstone
setblock 236 95 317 minecraft:smooth_sandstone
setblock 238 95 286 minecraft:light[level=15]
setblock 238 95 294 minecraft:light[level=15]
setblock 238 95 302 minecraft:light[level=15]
setblock 238 95 310 minecraft:light[level=15]
setblock 244 95 275 minecraft:smooth_sandstone
fill 246 95 276 246 95 281 minecraft:chiseled_sandstone
setblock 246 95 286 minecraft:light[level=15]
setblock 246 95 294 minecraft:light[level=15]
setblock 246 95 302 minecraft:light[level=15]
setblock 246 95 310 minecraft:light[level=15]
setblock 251 95 317 minecraft:smooth_sandstone
setblock 254 95 278 minecraft:light[level=15]
setblock 254 95 286 minecraft:light[level=15]
setblock 254 95 294 minecraft:light[level=15]
setblock 254 95 302 minecraft:light[level=15]
setblock 254 95 310 minecraft:light[level=15]
setblock 260 95 317 minecraft:smooth_sandstone
setblock 262 95 278 minecraft:light[level=15]
setblock 262 95 286 minecraft:light[level=15]
setblock 262 95 294 minecraft:light[level=15]
setblock 262 95 302 minecraft:light[level=15]
setblock 262 95 310 minecraft:light[level=15]
setblock 267 95 275 minecraft:smooth_sandstone
setblock 268 95 275 minecraft:blue_terracotta
setblock 270 95 275 minecraft:smooth_sandstone
setblock 270 95 278 minecraft:light[level=15]
setblock 270 95 286 minecraft:light[level=15]
setblock 270 95 294 minecraft:light[level=15]
setblock 270 95 302 minecraft:light[level=15]
setblock 270 95 310 minecraft:light[level=15]
fill 272 95 275 273 95 275 minecraft:smooth_sandstone
setblock 277 95 283 minecraft:smooth_sandstone
setblock 277 95 289 minecraft:smooth_sandstone
setblock 277 95 298 minecraft:smooth_sandstone
setblock 277 95 316 minecraft:smooth_sandstone
fill 235 96 276 235 120 279 minecraft:sandstone
fill 235 96 281 235 105 281 minecraft:sandstone
setblock 235 96 282 minecraft:smooth_sandstone
fill 235 96 283 235 105 291 minecraft:sandstone
fill 235 96 293 235 100 295 minecraft:sandstone
fill 235 96 297 235 165 297 minecraft:sandstone
fill 235 96 299 235 96 317 minecraft:sandstone
fill 236 96 275 237 131 275 minecraft:sandstone
fill 236 96 317 248 96 317 minecraft:sandstone
fill 239 96 275 252 96 275 minecraft:sandstone
fill 246 96 276 246 96 281 minecraft:cut_sandstone
setblock 249 96 317 minecraft:smooth_sandstone
fill 251 96 317 251 155 317 minecraft:sandstone
fill 253 96 317 267 96 317 minecraft:sandstone
fill 254 96 275 254 105 275 minecraft:sandstone
setblock 255 96 275 minecraft:smooth_sandstone
fill 256 96 275 259 96 275 minecraft:sandstone
setblock 260 96 275 minecraft:lapis_block
fill 261 96 275 266 105 275 minecraft:sandstone
setblock 267 96 275 minecraft:lapis_block
fill 268 96 275 270 105 275 minecraft:sandstone
fill 269 96 317 272 96 317 minecraft:sandstone
setblock 272 96 275 minecraft:smooth_sandstone
fill 273 96 275 273 202 275 minecraft:sandstone
setblock 273 96 317 minecraft:smooth_sandstone
fill 274 96 317 276 96 317 minecraft:sandstone
fill 275 96 275 277 195 275 minecraft:sandstone
fill 277 96 276 277 96 281 minecraft:sandstone
fill 277 96 283 277 96 285 minecraft:sandstone
fill 277 96 287 277 105 289 minecraft:sandstone
fill 277 96 291 277 96 302 minecraft:sandstone
fill 277 96 304 277 96 309 minecraft:sandstone
fill 277 96 311 277 97 311 minecraft:sandstone
fill 277 96 313 277 97 316 minecraft:sandstone
fill 235 97 275 235 198 275 minecraft:sandstone
fill 235 97 280 235 178 280 minecraft:sandstone
fill 235 97 282 235 105 282 minecraft:sandstone
fill 235 97 292 235 183 292 minecraft:sandstone
fill 235 97 296 235 105 296 minecraft:sandstone
fill 235 97 298 235 108 301 minecraft:sandstone
setblock 235 97 302 minecraft:smooth_sandstone
fill 235 97 303 235 97 316 minecraft:sandstone
setblock 235 97 317 minecraft:smooth_sandstone
fill 236 97 317 238 97 317 minecraft:sandstone
fill 238 97 275 238 157 275 minecraft:sandstone
setblock 239 97 275 minecraft:smooth_sandstone
setblock 239 97 317 minecraft:smooth_sandstone
fill 240 97 275 240 118 275 minecraft:sandstone
fill 240 97 317 250 100 317 minecraft:sandstone
fill 241 97 275 241 98 275 minecraft:smooth_sandstone
fill 242 97 275 244 100 275 minecraft:glowstone
fill 245 97 275 249 97 275 minecraft:sandstone
setblock 246 97 281 minecraft:lapis_block
setblock 250 97 275 minecraft:smooth_sandstone
fill 251 97 275 253 109 275 minecraft:sandstone
fill 251 97 308 251 98 308 minecraft:sandstone
fill 252 97 317 260 97 317 minecraft:sandstone
fill 255 97 275 255 103 275 minecraft:sandstone
fill 256 97 275 256 98 275 minecraft:smooth_sandstone
fill 257 97 275 260 105 275 minecraft:sandstone
setblock 261 97 317 minecraft:smooth_sandstone
fill 262 97 317 269 98 317 minecraft:sandstone
fill 267 97 275 267 105 275 minecraft:sandstone
setblock 270 97 317 minecraft:smooth_sandstone
fill 271 97 317 274 97 317 minecraft:sandstone
fill 272 97 275 272 202 275 minecraft:sandstone
fill 274 97 275 274 128 275 minecraft:sandstone
setblock 275 97 317 minecraft:smooth_sandstone
fill 276 97 317 276 171 317 minecraft:sandstone
fill 277 97 276 277 103 279 minecraft:sandstone
setblock 277 97 280 minecraft:smooth_sandstone
fill 277 97 281 277 143 282 minecraft:sandstone
setblock 277 97 283 minecraft:smooth_sandstone
fill 277 97 284 277 136 286 minecraft:sandstone
fill 277 97 290 277 100 294 minecraft:sandstone
fill 277 97 295 277 97 296 minecraft:smooth_sandstone
fill 277 97 297 277 105 301 minecraft:sandstone
setblock 277 97 302 minecraft:smooth_sandstone
fill 277 97 303 277 99 303 minecraft:sandstone
setblock 277 97 304 minecraft:smooth_sandstone
fill 277 97 305 277 99 310 minecraft:sandstone
fill 277 97 312 277 105 312 minecraft:sandstone
fill 235 98 302 235 102 310 minecraft:sandstone
setblock 235 98 311 minecraft:smooth_sandstone
fill 235 98 312 235 112 312 minecraft:sandstone
setblock 235 98 313 minecraft:smooth_sandstone
setblock 235 98 314 minecraft:blue_terracotta
fill 235 98 315 235 105 317 minecraft:sandstone
fill 236 98 276 238 186 276 minecraft:cut_sandstone
fill 236 98 317 236 105 317 minecraft:sandstone
fill 237 98 277 244 98 283 minecraft:lapis_block
setblock 237 98 317 minecraft:smooth_sandstone
fill 238 98 317 239 105 317 minecraft:sandstone
fill 239 98 275 239 134 275 minecraft:sandstone
fill 239 98 276 244 98 276 minecraft:lapis_block
fill 240 98 290 240 100 290 minecraft:shroomlight
fill 245 98 275 246 99 275 minecraft:sandstone
setblock 246 98 281 minecraft:cut_sandstone
setblock 247 98 275 minecraft:smooth_sandstone
fill 248 98 275 250 109 275 minecraft:sandstone
fill 252 98 317 254 103 317 minecraft:sandstone
setblock 255 98 317 minecraft:blue_terracotta
fill 256 98 317 257 98 317 minecraft:smooth_sandstone
fill 258 98 317 261 105 317 minecraft:sandstone
fill 270 98 317 273 105 317 minecraft:sandstone
fill 271 98 275 271 202 275 minecraft:sandstone
setblock 274 98 317 minecraft:smooth_sandstone
fill 275 98 317 275 114 317 minecraft:sandstone
fill 277 98 280 277 141 280 minecraft:sandstone
fill 277 98 283 277 202 283 minecraft:sandstone
fill 277 98 295 277 140 296 minecraft:sandstone
fill 277 98 302 277 105 302 minecraft:sandstone
fill 277 98 304 277 138 304 minecraft:sandstone
setblock 277 98 311 minecraft:smooth_sandstone
fill 277 98 313 277 99 315 minecraft:sandstone
setblock 277 98 316 minecraft:smooth_sandstone
fill 277 98 317 277 202 317 minecraft:sandstone
fill 235 99 311 235 204 311 minecraft:sandstone
fill 235 99 313 235 137 314 minecraft:sandstone
fill 237 99 317 237 105 317 minecraft:sandstone
fill 238 99 277 243 99 282 minecraft:lapis_block
setblock 238 99 285 minecraft:light[level=12]
setblock 238 99 292 minecraft:light[level=12]
setblock 238 99 299 minecraft:light[level=12]
setblock 238 99 306 minecraft:light[level=12]
setblock 238 99 313 minecraft:light[level=12]
fill 239 99 276 243 99 276 minecraft:lapis_block
fill 241 99 275 241 202 275 minecraft:sandstone
setblock 245 99 278 minecraft:light[level=12]
setblock 245 99 285 minecraft:light[level=12]
setblock 245 99 292 minecraft:light[level=12]
setblock 245 99 299 minecraft:light[level=12]
setblock 245 99 306 minecraft:light[level=12]
setblock 245 99 313 minecraft:light[level=12]
fill 247 99 275 247 171 275 minecraft:sandstone
setblock 252 99 278 minecraft:light[level=12]
setblock 252 99 285 minecraft:light[level=12]
setblock 252 99 292 minecraft:light[level=12]
setblock 252 99 299 minecraft:light[level=12]
setblock 252 99 306 minecraft:light[level=12]
setblock 252 99 313 minecraft:light[level=12]
fill 255 99 317 257 117 317 minecraft:sandstone
fill 256 99 275 256 101 275 minecraft:sandstone
setblock 259 99 278 minecraft:light[level=12]
setblock 259 99 285 minecraft:light[level=12]
setblock 259 99 292 minecraft:light[level=12]
setblock 259 99 299 minecraft:light[level=12]
setblock 259 99 306 minecraft:light[level=12]
setblock 259 99 313 minecraft:light[level=12]
fill 262 99 317 268 105 317 minecraft:sandstone
setblock 266 99 278 minecraft:light[level=12]
setblock 266 99 285 minecraft:light[level=12]
setblock 266 99 292 minecraft:light[level=12]
setblock 266 99 299 minecraft:light[level=12]
setblock 266 99 306 minecraft:light[level=12]
setblock 266 99 313 minecraft:light[level=12]
setblock 269 99 317 minecraft:orange_terracotta
setblock 273 99 278 minecraft:light[level=12]
setblock 273 99 285 minecraft:light[level=12]
setblock 273 99 292 minecraft:light[level=12]
setblock 273 99 299 minecraft:light[level=12]
setblock 273 99 306 minecraft:light[level=12]
setblock 273 99 313 minecraft:light[level=12]
fill 274 99 317 274 105 317 minecraft:sandstone
fill 277 99 311 277 142 311 minecraft:sandstone
fill 277 99 316 277 139 316 minecraft:sandstone
fill 237 100 285 237 105 287 minecraft:cut_sandstone
fill 237 100 297 237 105 299 minecraft:cut_sandstone
fill 237 100 309 237 105 311 minecraft:cut_sandstone
fill 239 100 276 242 100 281 minecraft:lapis_block
fill 243 100 315 245 105 315 minecraft:cut_sandstone
setblock 245 100 275 minecraft:orange_terracotta
fill 246 100 275 246 174 275 minecraft:sandstone
fill 247 100 277 249 105 277 minecraft:cut_sandstone
fill 255 100 315 257 105 315 minecraft:cut_sandstone
fill 259 100 277 261 105 277 minecraft:cut_sandstone
fill 267 100 315 269 105 315 minecraft:cut_sandstone
fill 269 100 317 269 125 317 minecraft:sandstone
fill 271 100 277 273 105 277 minecraft:cut_sandstone
fill 275 100 285 275 105 287 minecraft:cut_sandstone
fill 275 100 297 275 105 299 minecraft:cut_sandstone
fill 275 100 309 275 105 311 minecraft:cut_sandstone
setblock 277 100 303 minecraft:lapis_block
fill 277 100 305 277 102 308 minecraft:sandstone
setblock 277 100 309 minecraft:blue_terracotta
fill 277 100 310 277 202 310 minecraft:sandstone
fill 277 100 313 277 105 314 minecraft:sandstone
setblock 277 100 315 minecraft:black_terracotta
fill 235 101 293 235 105 293 minecraft:sandstone
setblock 235 101 294 minecraft:black_terracotta
fill 235 101 295 235 105 295 minecraft:sandstone
fill 240 101 276 241 101 280 minecraft:lapis_block
setblock 240 101 317 minecraft:lapis_block
fill 241 101 317 250 102 317 minecraft:sandstone
fill 242 101 275 245 105 275 minecraft:sandstone
fill 277 101 290 277 105 293 minecraft:sandstone
setblock 277 101 294 minecraft:lapis_block
fill 277 101 303 277 105 303 minecraft:sandstone
fill 277 101 309 277 109 309 minecraft:sandstone
fill 277 101 315 277 105 315 minecraft:sandstone
fill 235 102 294 235 105 294 minecraft:sandstone
fill 240 102 317 240 103 317 minecraft:sandstone
setblock 256 102 275 minecraft:lapis_block
fill 277 102 294 277 117 294 minecraft:sandstone
fill 235 103 302 235 105 308 minecraft:sandstone
setblock 235 103 309 minecraft:orange_terracotta
fill 235 103 310 235 116 310 minecraft:sandstone
setblock 238 103 278 minecraft:light[level=15]
setblock 238 103 286 minecraft:light[level=15]
setblock 238 103 294 minecraft:light[level=15]
setblock 238 103 302 minecraft:light[level=15]
setblock 238 103 310 minecraft:light[level=15]
fill 241 103 317 242 154 317 minecraft:sandstone
setblock 243 103 317 minecraft:blue_terracotta
fill 244 103 317 250 105 317 minecraft:sandstone
setblock 246 103 278 minecraft:light[level=15]
setblock 246 103 286 minecraft:light[level=15]
setblock 246 103 294 minecraft:light[level=15]
setblock 246 103 302 minecraft:light[level=15]
setblock 246 103 310 minecraft:light[level=15]
setblock 254 103 278 minecraft:light[level=15]
setblock 254 103 286 minecraft:light[level=15]
setblock 254 103 294 minecraft:light[level=15]
setblock 254 103 302 minecraft:light[level=15]
setblock 254 103 310 minecraft:light[level=15]
fill 256 103 275 256 105 275 minecraft:sandstone
setblock 262 103 278 minecraft:light[level=15]
setblock 262 103 286 minecraft:light[level=15]
setblock 262 103 294 minecraft:light[level=15]
setblock 262 103 302 minecraft:light[level=15]
setblock 262 103 310 minecraft:light[level=15]
setblock 270 103 278 minecraft:light[level=15]
setblock 270 103 286 minecraft:light[level=15]
setblock 270 103 294 minecraft:light[level=15]
setblock 270 103 302 minecraft:light[level=15]
setblock 270 103 310 minecraft:light[level=15]
setblock 277 103 305 minecraft:orange_terracotta
fill 277 103 306 277 117 308 minecraft:sandstone
fill 235 104 309 235 155 309 minecraft:sandstone
setblock 240 104 317 minecraft:black_terracotta
fill 243 104 317 243 175 317 minecraft:sandstone
fill 250 104 279 250 107 279 minecraft:iron_block
setblock 252 104 317 minecraft:blue_terracotta
fill 253 104 317 254 121 317 minecraft:sandstone
setblock 255 104 275 minecraft:black_terracotta
setblock 277 104 276 minecraft:black_terracotta
fill 277 104 277 277 105 279 minecraft:sandstone
fill 277 104 305 277 202 305 minecraft:sandstone
fill 236 105 279 236 105 284 minecraft:chiseled_sandstone
fill 236 105 291 236 105 296 minecraft:chiseled_sandstone
fill 236 105 303 236 105 308 minecraft:chiseled_sandstone
fill 236 105 315 236 105 316 minecraft:chiseled_sandstone
fill 237 105 316 240 105 316 minecraft:chiseled_sandstone
setblock 238 105 278 minecraft:light[level=12]
setblock 238 105 285 minecraft:light[level=12]
setblock 238 105 292 minecraft:light[level=12]
setblock 238 105 299 minecraft:light[level=12]
setblock 238 105 306 minecraft:light[level=12]
setblock 238 105 313 minecraft:light[level=12]
fill 240 105 276 245 105 276 minecraft:chiseled_sandstone
fill 240 105 317 240 200 317 minecraft:sandstone
setblock 245 105 278 minecraft:light[level=12]
setblock 245 105 285 minecraft:light[level=12]
setblock 245 105 292 minecraft:light[level=12]
setblock 245 105 299 minecraft:light[level=12]
setblock 245 105 306 minecraft:light[level=12]
setblock 245 105 313 minecraft:light[level=12]
fill 247 105 316 252 105 316 minecraft:chiseled_sandstone
fill 252 105 276 257 105 276 minecraft:chiseled_sandstone
setblock 252 105 278 minecraft:light[level=12]
setblock 252 105 285 minecraft:light[level=12]
setblock 252 105 292 minecraft:light[level=12]
setblock 252 105 299 minecraft:light[level=12]
setblock 252 105 306 minecraft:light[level=12]
setblock 252 105 313 minecraft:light[level=12]
fill 252 105 317 252 122 317 minecraft:sandstone
setblock 255 105 275 minecraft:sandstone
setblock 259 105 278 minecraft:light[level=12]
setblock 259 105 285 minecraft:light[level=12]
setblock 259 105 292 minecraft:light[level=12]
setblock 259 105 299 minecraft:light[level=12]
setblock 259 105 306 minecraft:light[level=12]
setblock 259 105 313 minecraft:light[level=12]
fill 259 105 316 264 105 316 minecraft:chiseled_sandstone
fill 264 105 276 269 105 276 minecraft:chiseled_sandstone
setblock 266 105 278 minecraft:light[level=12]
setblock 266 105 285 minecraft:light[level=12]
setblock 266 105 292 minecraft:light[level=12]
setblock 266 105 299 minecraft:light[level=12]
setblock 266 105 306 minecraft:light[level=12]
setblock 266 105 313 minecraft:light[level=12]
fill 271 105 316 276 105 316 minecraft:chiseled_sandstone
setblock 273 105 278 minecraft:light[level=12]
setblock 273 105 285 minecraft:light[level=12]
setblock 273 105 292 minecraft:light[level=12]
setblock 273 105 299 minecraft:light[level=12]
setblock 273 105 306 minecraft:light[level=12]
setblock 273 105 313 minecraft:light[level=12]
fill 276 105 276 276 105 281 minecraft:chiseled_sandstone
fill 276 105 288 276 105 293 minecraft:chiseled_sandstone
fill 276 105 300 276 105 305 minecraft:chiseled_sandstone
fill 276 105 312 276 105 315 minecraft:chiseled_sandstone
setblock 277 105 276 minecraft:sandstone
fill 235 106 281 235 111 284 minecraft:glowstone
fill 235 106 285 235 106 291 minecraft:sandstone
fill 235 106 293 235 111 296 minecraft:glowstone
fill 235 106 302 235 122 304 minecraft:sandstone
fill 235 106 305 235 111 308 minecraft:glowstone
fill 235 106 315 235 202 316 minecraft:sandstone
fill 235 106 317 238 111 317 minecraft:glowstone
fill 239 106 317 239 149 317 minecraft:sandstone
fill 242 106 275 245 111 275 minecraft:glowstone
fill 244 106 317 246 114 317 minecraft:sandstone
fill 247 106 317 250 111 317 minecraft:glowstone
fill 254 106 275 257 111 275 minecraft:glowstone
fill 258 106 275 265 110 275 minecraft:sandstone
fill 258 106 317 258 159 317 minecraft:sandstone
fill 259 106 317 262 111 317 minecraft:glowstone
fill 263 106 317 268 122 317 minecraft:sandstone
fill 266 106 275 269 111 275 minecraft:glowstone
fill 270 106 275 270 139 275 minecraft:sandstone
fill 270 106 317 270 198 317 minecraft:sandstone
fill 271 106 317 274 111 317 minecraft:glowstone
fill 277 106 276 277 111 279 minecraft:glowstone
fill 277 106 287 277 202 287 minecraft:sandstone
fill 277 106 288 277 111 291 minecraft:glowstone
fill 277 106 292 277 202 293 minecraft:sandstone
fill 277 106 297 277 106 299 minecraft:sandstone
fill 277 106 300 277 111 303 minecraft:glowstone
fill 277 106 312 277 111 315 minecraft:glowstone
fill 235 107 285 235 124 288 minecraft:sandstone
setblock 235 107 289 minecraft:black_terracotta
fill 235 107 290 235 119 291 minecraft:sandstone
fill 277 107 297 277 135 298 minecraft:sandstone
setblock 277 107 299 minecraft:black_terracotta
fill 235 108 289 235 203 289 minecraft:sandstone
fill 237 108 299 242 108 299 minecraft:chiseled_sandstone
fill 238 108 297 242 109 298 minecraft:chiseled_sandstone
fill 238 108 300 242 109 301 minecraft:chiseled_sandstone
fill 246 108 276 247 108 279 minecraft:chiseled_sandstone
fill 248 108 277 254 108 279 minecraft:chiseled_sandstone
fill 251 108 276 254 108 276 minecraft:chiseled_sandstone
fill 277 108 299 277 149 299 minecraft:sandstone
fill 235 109 298 235 116 298 minecraft:sandstone
setblock 235 109 299 minecraft:blue_terracotta
fill 235 109 300 235 109 301 minecraft:sandstone
fill 237 109 286 242 109 286 minecraft:chiseled_sandstone
fill 238 109 284 242 110 285 minecraft:chiseled_sandstone
fill 238 109 287 242 110 288 minecraft:chiseled_sandstone
fill 238 109 299 242 109 299 minecraft:chiseled_sandstone
fill 246 109 276 247 109 279 minecraft:cut_sandstone
fill 248 109 277 254 109 279 minecraft:cut_sandstone
fill 251 109 276 254 109 276 minecraft:cut_sandstone
fill 235 110 299 235 135 300 minecraft:sandstone
setblock 235 110 301 minecraft:orange_terracotta
fill 238 110 286 242 110 286 minecraft:chiseled_sandstone
fill 239 110 298 241 111 300 minecraft:cut_sandstone
fill 246 110 279 254 110 279 minecraft:lapis_block
fill 248 110 275 248 151 275 minecraft:sandstone
fill 249 110 275 251 113 275 minecraft:glowstone
fill 252 110 275 253 202 275 minecraft:sandstone
setblock 277 110 309 minecraft:blue_terracotta
fill 235 111 301 235 118 301 minecraft:sandstone
setblock 238 111 278 minecraft:light[level=15]
setblock 238 111 285 minecraft:light[level=12]
setblock 238 111 286 minecraft:light[level=15]
setblock 238 111 292 minecraft:light[level=12]
setblock 238 111 294 minecraft:light[level=15]
setblock 238 111 299 minecraft:light[level=12]
setblock 238 111 302 minecraft:light[level=15]
setblock 238 111 306 minecraft:light[level=12]
setblock 238 111 310 minecraft:light[level=15]
setblock 238 111 313 minecraft:light[level=12]
fill 239 111 285 241 112 287 minecraft:cut_sandstone
setblock 245 111 278 minecraft:light[level=12]
setblock 245 111 285 minecraft:light[level=12]
setblock 245 111 292 minecraft:light[level=12]
setblock 245 111 299 minecraft:light[level=12]
setblock 245 111 306 minecraft:light[level=12]
setblock 245 111 313 minecraft:light[level=12]
setblock 246 111 278 minecraft:light[level=15]
setblock 246 111 279 minecraft:cut_sandstone
setblock 246 111 286 minecraft:light[level=15]
setblock 246 111 294 minecraft:light[level=15]
setblock 246 111 302 minecraft:light[level=15]
setblock 246 111 310 minecraft:light[level=15]
setblock 250 111 279 minecraft:cut_sandstone
setblock 252 111 278 minecraft:light[level=12]
setblock 252 111 285 minecraft:light[level=12]
setblock 252 111 292 minecraft:light[level=12]
setblock 252 111 299 minecraft:light[level=12]
setblock 252 111 306 minecraft:light[level=12]
setblock 252 111 313 minecraft:light[level=12]
setblock 254 111 278 minecraft:light[level=15]
setblock 254 111 279 minecraft:cut_sandstone
setblock 254 111 286 minecraft:light[level=15]
setblock 254 111 294 minecraft:light[level=15]
setblock 254 111 302 minecraft:light[level=15]
setblock 254 111 310 minecraft:light[level=15]
fill 258 111 275 258 136 275 minecraft:sandstone
setblock 259 111 275 minecraft:orange_terracotta
setblock 259 111 278 minecraft:light[level=12]
setblock 259 111 285 minecraft:light[level=12]
setblock 259 111 292 minecraft:light[level=12]
setblock 259 111 299 minecraft:light[level=12]
setblock 259 111 306 minecraft:light[level=12]
setblock 259 111 313 minecraft:light[level=12]
fill 260 111 275 261 202 275 minecraft:sandstone
setblock 262 111 275 minecraft:black_terracotta
setblock 262 111 278 minecraft:light[level=15]
setblock 262 111 286 minecraft:light[level=15]
setblock 262 111 294 minecraft:light[level=15]
setblock 262 111 302 minecraft:light[level=15]
setblock 262 111 310 minecraft:light[level=15]
fill 263 111 275 265 137 275 minecraft:sandstone
setblock 266 111 278 minecraft:light[level=12]
setblock 266 111 285 minecraft:light[level=12]
setblock 266 111 292 minecraft:light[level=12]
setblock 266 111 299 minecraft:light[level=12]
setblock 266 111 306 minecraft:light[level=12]
setblock 266 111 313 minecraft:light[level=12]
setblock 270 111 278 minecraft:light[level=15]
setblock 270 111 286 minecraft:light[level=15]
setblock 270 111 294 minecraft:light[level=15]
setblock 270 111 302 minecraft:light[level=15]
setblock 270 111 310 minecraft:light[level=15]
setblock 273 111 278 minecraft:light[level=12]
setblock 273 111 285 minecraft:light[level=12]
setblock 273 111 292 minecraft:light[level=12]
setblock 273 111 299 minecraft:light[level=12]
setblock 273 111 306 minecraft:light[level=12]
setblock 273 111 313 minecraft:light[level=12]
fill 277 111 309 277 202 309 minecraft:sandstone
fill 235 112 281 235 125 281 minecraft:sandstone
fill 235 112 282 235 112 283 minecraft:glowstone
fill 235 112 284 235 120 284 minecraft:sandstone
fill 235 112 293 235 125 293 minecraft:sandstone
fill 235 112 294 235 112 295 minecraft:glowstone
fill 235 112 296 235 125 296 minecraft:sandstone
fill 235 112 305 235 125 305 minecraft:sandstone
fill 235 112 306 235 112 307 minecraft:glowstone
fill 235 112 308 235 125 308 minecraft:sandstone
fill 235 112 317 235 125 317 minecraft:sandstone
fill 236 112 317 237 112 317 minecraft:glowstone
fill 238 112 317 238 125 317 minecraft:sandstone
fill 239 112 299 241 114 299 minecraft:cut_sandstone
fill 240 112 298 240 114 298 minecraft:cut_sandstone
fill 240 112 300 240 114 300 minecraft:cut_sandstone
fill 242 112 275 242 125 275 minecraft:sandstone
fill 243 112 275 244 112 275 minecraft:glowstone
fill 245 112 275 245 125 275 minecraft:sandstone
fill 247 112 317 247 116 317 minecraft:sandstone
fill 248 112 317 249 112 317 minecraft:glowstone
fill 250 112 317 250 125 317 minecraft:sandstone
fill 254 112 275 254 125 275 minecraft:sandstone
fill 255 112 275 256 112 275 minecraft:glowstone
fill 257 112 275 257 125 275 minecraft:sandstone
fill 259 112 275 259 194 275 minecraft:sandstone
fill 259 112 317 259 125 317 minecraft:sandstone
fill 260 112 317 261 112 317 minecraft:glowstone
fill 262 112 275 262 115 275 minecraft:sandstone
fill 262 112 317 262 125 317 minecraft:sandstone
fill 266 112 275 266 125 275 minecraft:sandstone
fill 267 112 275 268 112 275 minecraft:glowstone
fill 269 112 275 269 125 275 minecraft:sandstone
fill 271 112 317 271 125 317 minecraft:sandstone
fill 272 112 317 273 112 317 minecraft:glowstone
fill 274 112 317 274 125 317 minecraft:sandstone
fill 277 112 276 277 125 276 minecraft:sandstone
fill 277 112 277 277 112 278 minecraft:glowstone
fill 277 112 279 277 122 279 minecraft:sandstone
fill 277 112 288 277 125 288 minecraft:sandstone
fill 277 112 289 277 112 290 minecraft:glowstone
fill 277 112 291 277 125 291 minecraft:sandstone
fill 277 112 300 277 125 300 minecraft:sandstone
fill 277 112 301 277 112 302 minecraft:glowstone
fill 277 112 303 277 125 303 minecraft:sandstone
fill 277 112 312 277 125 312 minecraft:sandstone
fill 277 112 313 277 112 314 minecraft:glowstone
fill 277 112 315 277 125 315 minecraft:sandstone
fill 235 113 282 235 115 283 minecraft:sandstone
fill 235 113 294 235 125 295 minecraft:sandstone
fill 235 113 306 235 125 307 minecraft:sandstone
setblock 235 113 312 minecraft:black_terracotta
fill 236 113 317 237 118 317 minecraft:sandstone
fill 239 113 286 241 115 286 minecraft:cut_sandstone
fill 240 113 285 240 115 285 minecraft:cut_sandstone
fill 240 113 287 240 115 287 minecraft:cut_sandstone
fill 243 113 275 244 125 275 minecraft:sandstone
fill 248 113 317 249 125 317 minecraft:sandstone
fill 255 113 275 256 125 275 minecraft:sandstone
fill 260 113 317 261 125 317 minecraft:sandstone
fill 267 113 275 268 117 275 minecraft:sandstone
fill 272 113 317 273 113 317 minecraft:sandstone
fill 277 113 277 277 125 278 minecraft:sandstone
fill 277 113 289 277 125 290 minecraft:sandstone
fill 277 113 301 277 113 302 minecraft:sandstone
fill 277 113 313 277 125 314 minecraft:sandstone
fill 235 114 312 235 135 312 minecraft:sandstone
fill 249 114 275 251 118 275 minecraft:sandstone
fill 255 114 282 255 115 282 minecraft:chiseled_sandstone
fill 269 114 289 269 115 289 minecraft:chiseled_sandstone
fill 269 114 291 269 115 291 minecraft:chiseled_sandstone
fill 269 114 293 269 115 293 minecraft:chiseled_sandstone
setblock 272 114 317 minecraft:blue_terracotta
fill 273 114 317 273 125 317 minecraft:sandstone
setblock 277 114 301 minecraft:orange_terracotta
fill 277 114 302 277 118 302 minecraft:sandstone
fill 240 115 299 240 119 299 minecraft:cut_sandstone
fill 244 115 317 244 170 317 minecraft:sandstone
setblock 245 115 317 minecraft:lapis_block
fill 246 115 317 246 202 317 minecraft:sandstone
fill 255 115 281 255 116 281 minecraft:chiseled_sandstone
fill 270 115 289 270 116 289 minecraft:chiseled_sandstone
fill 270 115 291 270 116 291 minecraft:chiseled_sandstone
fill 270 115 293 270 116 293 minecraft:chiseled_sandstone
fill 272 115 317 272 125 317 minecraft:sandstone
setblock 275 115 317 minecraft:black_terracotta
fill 277 115 301 277 125 301 minecraft:sandstone
setblock 235 116 282 minecraft:blue_terracotta
fill 235 116 283 235 125 283 minecraft:sandstone
fill 236 116 304 242 116 304 minecraft:chiseled_sandstone
fill 238 116 302 242 117 303 minecraft:chiseled_sandstone
fill 238 116 305 242 117 306 minecraft:chiseled_sandstone
fill 240 116 286 240 120 286 minecraft:cut_sandstone
fill 245 116 317 245 202 317 minecraft:sandstone
fill 249 116 287 249 117 287 minecraft:smooth_sandstone
fill 255 116 280 255 117 280 minecraft:chiseled_sandstone
setblock 262 116 275 minecraft:blue_terracotta
fill 271 116 289 271 117 289 minecraft:chiseled_sandstone
fill 271 116 291 271 117 291 minecraft:chiseled_sandstone
fill 271 116 293 271 117 293 minecraft:chiseled_sandstone
fill 275 116 317 275 202 317 minecraft:sandstone
fill 235 117 282 235 125 282 minecraft:sandstone
setblock 235 117 298 minecraft:lapis_block
setblock 235 117 310 minecraft:orange_terracotta
setblock 238 117 278 minecraft:light[level=12]
setblock 238 117 285 minecraft:light[level=12]
setblock 238 117 292 minecraft:light[level=12]
setblock 238 117 299 minecraft:light[level=12]
fill 238 117 304 242 117 304 minecraft:chiseled_sandstone
setblock 238 117 313 minecraft:light[level=12]
setblock 245 117 278 minecraft:light[level=12]
setblock 245 117 285 minecraft:light[level=12]
setblock 245 117 292 minecraft:light[level=12]
setblock 245 117 299 minecraft:light[level=12]
setblock 245 117 306 minecraft:light[level=12]
setblock 245 117 313 minecraft:light[level=12]
fill 247 117 312 247 120 312 minecraft:iron_block
setblock 247 117 317 minecraft:black_terracotta
setblock 252 117 278 minecraft:light[level=12]
setblock 252 117 285 minecraft:light[level=12]
setblock 252 117 292 minecraft:light[level=12]
setblock 252 117 299 minecraft:light[level=12]
setblock 252 117 306 minecraft:light[level=12]
setblock 252 117 313 minecraft:light[level=12]
fill 255 117 279 255 118 279 minecraft:chiseled_sandstone
setblock 259 117 278 minecraft:light[level=12]
setblock 259 117 285 minecraft:light[level=12]
setblock 259 117 292 minecraft:light[level=12]
setblock 259 117 299 minecraft:light[level=12]
setblock 259 117 306 minecraft:light[level=12]
setblock 259 117 313 minecraft:light[level=12]
fill 262 117 275 262 145 275 minecraft:sandstone
setblock 266 117 278 minecraft:light[level=12]
setblock 266 117 285 minecraft:light[level=12]
setblock 266 117 292 minecraft:light[level=12]
setblock 266 117 299 minecraft:light[level=12]
setblock 266 117 306 minecraft:light[level=12]
setblock 266 117 313 minecraft:light[level=12]
fill 272 117 289 272 118 289 minecraft:chiseled_sandstone
fill 272 117 291 272 118 291 minecraft:chiseled_sandstone
fill 272 117 293 272 118 293 minecraft:chiseled_sandstone
setblock 273 117 278 minecraft:light[level=12]
setblock 273 117 285 minecraft:light[level=12]
setblock 273 117 292 minecraft:light[level=12]
setblock 273 117 299 minecraft:light[level=12]
setblock 273 117 306 minecraft:light[level=12]
setblock 273 117 313 minecraft:light[level=12]
fill 235 118 298 235 144 298 minecraft:sandstone
fill 235 118 310 235 147 310 minecraft:sandstone
fill 239 118 303 241 119 305 minecraft:cut_sandstone
fill 247 118 317 247 125 317 minecraft:sandstone
fill 255 118 278 255 119 278 minecraft:chiseled_sandstone
fill 255 118 317 256 173 317 minecraft:sandstone
setblock 257 118 317 minecraft:lapis_block
fill 258 118 314 258 121 314 minecraft:blue_wool
fill 267 118 275 267 125 275 minecraft:sandstone
setblock 268 118 275 minecraft:black_terracotta
fill 273 118 289 273 119 289 minecraft:chiseled_sandstone
fill 273 118 291 273 119 291 minecraft:chiseled_sandstone
fill 273 118 293 273 119 293 minecraft:chiseled_sandstone
setblock 277 118 294 minecraft:lapis_block
fill 277 118 306 277 128 307 minecraft:sandstone
setblock 277 118 308 minecraft:blue_terracotta
setblock 235 119 301 minecraft:orange_terracotta
setblock 236 119 317 minecraft:orange_terracotta
fill 237 119 317 237 125 317 minecraft:sandstone
setblock 238 119 278 minecraft:light[level=15]
setblock 238 119 286 minecraft:light[level=15]
setblock 238 119 294 minecraft:light[level=15]
setblock 238 119 302 minecraft:light[level=15]
setblock 238 119 310 minecraft:light[level=15]
setblock 240 119 275 minecraft:orange_terracotta
setblock 246 119 278 minecraft:light[level=15]
setblock 246 119 286 minecraft:light[level=15]
setblock 246 119 294 minecraft:light[level=15]
setblock 246 119 302 minecraft:light[level=15]
setblock 246 119 310 minecraft:light[level=15]
fill 249 119 275 250 120 275 minecraft:sandstone
setblock 251 119 275 minecraft:orange_terracotta
setblock 254 119 278 minecraft:light[level=15]
setblock 254 119 286 minecraft:light[level=15]
setblock 254 119 294 minecraft:light[level=15]
setblock 254 119 302 minecraft:light[level=15]
setblock 254 119 310 minecraft:light[level=15]
fill 255 119 277 255 120 277 minecraft:chiseled_sandstone
fill 256 119 314 257 121 314 minecraft:blue_wool
fill 257 119 317 257 169 317 minecraft:sandstone
fill 259 119 314 260 121 314 minecraft:blue_wool
setblock 262 119 278 minecraft:light[level=15]
setblock 262 119 286 minecraft:light[level=15]
setblock 262 119 294 minecraft:light[level=15]
setblock 262 119 302 minecraft:light[level=15]
setblock 262 119 310 minecraft:light[level=15]
fill 268 119 275 268 125 275 minecraft:sandstone
setblock 270 119 278 minecraft:light[level=15]
setblock 270 119 286 minecraft:light[level=15]
setblock 270 119 294 minecraft:light[level=15]
setblock 270 119 302 minecraft:light[level=15]
setblock 270 119 310 minecraft:light[level=15]
fill 274 119 289 274 120 289 minecraft:chiseled_sandstone
fill 274 119 291 274 120 291 minecraft:chiseled_sandstone
fill 274 119 293 274 120 293 minecraft:chiseled_sandstone
fill 277 119 294 277 154 294 minecraft:sandstone
setblock 277 119 302 minecraft:lapis_block
fill 277 119 308 277 202 308 minecraft:sandstone
fill 235 120 290 235 198 290 minecraft:sandstone
setblock 235 120 291 minecraft:blue_terracotta
fill 235 120 301 235 152 301 minecraft:sandstone
fill 236 120 317 236 125 317 minecraft:sandstone
schedule function dropper:buildpart/65_2 1t
