setblock 314 148 485 minecraft:shroomlight
fill 314 148 486 314 160 486 minecraft:polished_blackstone_bricks
setblock 314 148 487 minecraft:shroomlight
fill 314 148 488 314 160 488 minecraft:polished_blackstone_bricks
setblock 314 148 489 minecraft:shroomlight
fill 314 148 490 314 160 490 minecraft:polished_blackstone_bricks
setblock 314 148 491 minecraft:shroomlight
fill 314 148 492 314 160 492 minecraft:polished_blackstone_bricks
setblock 315 148 480 minecraft:shroomlight
fill 315 148 481 315 160 481 minecraft:polished_blackstone_bricks
setblock 315 148 482 minecraft:shroomlight
fill 315 148 483 315 160 483 minecraft:polished_blackstone_bricks
setblock 315 148 484 minecraft:shroomlight
fill 315 148 485 315 160 485 minecraft:polished_blackstone_bricks
setblock 315 148 486 minecraft:shroomlight
fill 315 148 487 315 160 487 minecraft:polished_blackstone_bricks
setblock 315 148 488 minecraft:shroomlight
fill 315 148 489 315 160 489 minecraft:polished_blackstone_bricks
setblock 315 148 490 minecraft:shroomlight
fill 315 148 491 315 160 491 minecraft:polished_blackstone_bricks
setblock 315 148 492 minecraft:shroomlight
fill 316 148 480 316 160 480 minecraft:polished_blackstone_bricks
setblock 316 148 481 minecraft:shroomlight
fill 316 148 482 316 160 482 minecraft:polished_blackstone_bricks
setblock 316 148 483 minecraft:shroomlight
fill 316 148 484 316 160 484 minecraft:polished_blackstone_bricks
setblock 316 148 485 minecraft:shroomlight
fill 316 148 486 316 160 486 minecraft:polished_blackstone_bricks
setblock 316 148 487 minecraft:shroomlight
fill 316 148 488 316 160 488 minecraft:polished_blackstone_bricks
setblock 316 148 489 minecraft:shroomlight
fill 316 148 490 316 160 490 minecraft:polished_blackstone_bricks
setblock 316 148 491 minecraft:shroomlight
setblock 317 148 480 minecraft:shroomlight
fill 317 148 481 317 160 481 minecraft:polished_blackstone_bricks
setblock 317 148 482 minecraft:shroomlight
fill 317 148 483 317 160 483 minecraft:polished_blackstone_bricks
setblock 317 148 484 minecraft:shroomlight
fill 317 148 485 317 160 485 minecraft:polished_blackstone_bricks
setblock 317 148 486 minecraft:shroomlight
fill 317 148 487 317 160 487 minecraft:polished_blackstone_bricks
setblock 317 148 488 minecraft:shroomlight
fill 317 148 489 317 160 489 minecraft:polished_blackstone_bricks
setblock 317 148 490 minecraft:shroomlight
fill 317 148 491 317 160 491 minecraft:polished_blackstone_bricks
setblock 317 148 492 minecraft:shroomlight
fill 318 148 480 318 160 480 minecraft:polished_blackstone_bricks
setblock 318 148 481 minecraft:shroomlight
fill 318 148 482 318 160 482 minecraft:polished_blackstone_bricks
setblock 318 148 483 minecraft:shroomlight
fill 318 148 484 318 160 484 minecraft:polished_blackstone_bricks
setblock 318 148 485 minecraft:shroomlight
fill 318 148 486 318 160 486 minecraft:polished_blackstone_bricks
setblock 318 148 487 minecraft:shroomlight
fill 318 148 488 318 160 488 minecraft:polished_blackstone_bricks
setblock 318 148 489 minecraft:shroomlight
fill 318 148 490 318 160 490 minecraft:polished_blackstone_bricks
setblock 318 148 491 minecraft:shroomlight
fill 318 148 492 318 160 492 minecraft:polished_blackstone_bricks
setblock 319 148 480 minecraft:shroomlight
fill 319 148 481 319 160 481 minecraft:polished_blackstone_bricks
setblock 319 148 482 minecraft:shroomlight
fill 319 148 483 319 160 483 minecraft:polished_blackstone_bricks
setblock 319 148 484 minecraft:shroomlight
fill 319 148 485 319 160 485 minecraft:polished_blackstone_bricks
setblock 319 148 486 minecraft:shroomlight
fill 319 148 487 319 160 487 minecraft:polished_blackstone_bricks
setblock 319 148 488 minecraft:shroomlight
fill 319 148 489 319 160 489 minecraft:polished_blackstone_bricks
setblock 319 148 490 minecraft:shroomlight
fill 319 148 491 319 160 491 minecraft:polished_blackstone_bricks
setblock 319 148 492 minecraft:shroomlight
fill 320 148 480 320 160 480 minecraft:polished_blackstone_bricks
setblock 320 148 481 minecraft:shroomlight
fill 320 148 482 320 160 482 minecraft:polished_blackstone_bricks
setblock 320 148 483 minecraft:shroomlight
fill 320 148 484 320 160 484 minecraft:polished_blackstone_bricks
setblock 320 148 485 minecraft:shroomlight
fill 320 148 486 320 160 486 minecraft:polished_blackstone_bricks
setblock 320 148 487 minecraft:shroomlight
fill 320 148 488 320 160 488 minecraft:polished_blackstone_bricks
setblock 320 148 489 minecraft:shroomlight
fill 320 148 490 320 160 490 minecraft:polished_blackstone_bricks
setblock 320 148 491 minecraft:shroomlight
fill 320 148 492 320 160 492 minecraft:polished_blackstone_bricks
setblock 321 148 480 minecraft:shroomlight
fill 321 148 481 321 160 481 minecraft:polished_blackstone_bricks
setblock 321 148 482 minecraft:shroomlight
fill 321 148 483 321 160 483 minecraft:polished_blackstone_bricks
setblock 321 148 484 minecraft:shroomlight
fill 321 148 485 321 160 485 minecraft:polished_blackstone_bricks
setblock 321 148 486 minecraft:shroomlight
fill 321 148 487 321 160 487 minecraft:polished_blackstone_bricks
setblock 321 148 488 minecraft:shroomlight
fill 321 148 489 321 160 489 minecraft:polished_blackstone_bricks
setblock 321 148 490 minecraft:shroomlight
fill 321 148 491 321 160 491 minecraft:polished_blackstone_bricks
setblock 321 148 492 minecraft:shroomlight
fill 322 148 480 322 160 480 minecraft:polished_blackstone_bricks
setblock 322 148 481 minecraft:shroomlight
fill 322 148 482 322 160 482 minecraft:polished_blackstone_bricks
setblock 322 148 483 minecraft:shroomlight
fill 322 148 484 322 160 484 minecraft:polished_blackstone_bricks
setblock 322 148 485 minecraft:shroomlight
fill 322 148 486 322 165 486 minecraft:polished_blackstone_bricks
setblock 322 148 487 minecraft:shroomlight
fill 322 148 488 322 160 488 minecraft:polished_blackstone_bricks
setblock 322 148 489 minecraft:shroomlight
fill 322 148 490 322 160 490 minecraft:polished_blackstone_bricks
setblock 322 148 491 minecraft:shroomlight
fill 322 148 492 322 160 492 minecraft:polished_blackstone_bricks
setblock 323 148 480 minecraft:shroomlight
fill 323 148 481 323 160 481 minecraft:polished_blackstone_bricks
setblock 323 148 482 minecraft:shroomlight
fill 323 148 483 323 160 483 minecraft:polished_blackstone_bricks
setblock 323 148 484 minecraft:shroomlight
fill 323 148 485 323 188 485 minecraft:polished_blackstone_bricks
setblock 323 148 486 minecraft:shroomlight
fill 323 148 487 323 160 487 minecraft:polished_blackstone_bricks
setblock 323 148 488 minecraft:shroomlight
fill 323 148 489 323 160 489 minecraft:polished_blackstone_bricks
setblock 323 148 490 minecraft:shroomlight
fill 323 148 491 323 160 491 minecraft:polished_blackstone_bricks
setblock 323 148 492 minecraft:shroomlight
fill 283 149 466 283 150 466 minecraft:polished_blackstone_bricks
fill 283 149 468 283 150 468 minecraft:polished_blackstone_bricks
fill 283 149 470 283 150 470 minecraft:polished_blackstone_bricks
fill 283 149 472 283 150 472 minecraft:polished_blackstone_bricks
fill 283 149 474 283 150 474 minecraft:polished_blackstone_bricks
fill 284 149 465 284 150 465 minecraft:polished_blackstone_bricks
fill 284 149 467 284 150 467 minecraft:polished_blackstone_bricks
fill 284 149 469 284 150 469 minecraft:polished_blackstone_bricks
fill 284 149 471 284 150 471 minecraft:polished_blackstone_bricks
fill 284 149 473 284 150 473 minecraft:polished_blackstone_bricks
fill 284 149 475 284 150 475 minecraft:polished_blackstone_bricks
fill 285 149 466 285 150 466 minecraft:polished_blackstone_bricks
fill 285 149 468 285 150 468 minecraft:polished_blackstone_bricks
fill 285 149 470 285 150 470 minecraft:polished_blackstone_bricks
fill 285 149 472 285 150 472 minecraft:polished_blackstone_bricks
fill 285 149 474 285 150 474 minecraft:polished_blackstone_bricks
fill 286 149 465 286 150 465 minecraft:polished_blackstone_bricks
fill 286 149 467 286 150 467 minecraft:polished_blackstone_bricks
fill 286 149 469 286 150 469 minecraft:polished_blackstone_bricks
fill 286 149 471 286 150 471 minecraft:polished_blackstone_bricks
fill 286 149 473 286 150 473 minecraft:polished_blackstone_bricks
fill 286 149 475 286 150 475 minecraft:polished_blackstone_bricks
fill 287 149 466 287 150 466 minecraft:polished_blackstone_bricks
fill 287 149 468 287 150 468 minecraft:polished_blackstone_bricks
fill 287 149 470 287 150 470 minecraft:polished_blackstone_bricks
fill 287 149 472 287 150 472 minecraft:polished_blackstone_bricks
fill 287 149 474 287 150 474 minecraft:polished_blackstone_bricks
fill 288 149 465 288 150 465 minecraft:polished_blackstone_bricks
fill 288 149 467 288 150 467 minecraft:polished_blackstone_bricks
fill 288 149 469 288 150 469 minecraft:polished_blackstone_bricks
fill 288 149 471 288 150 471 minecraft:polished_blackstone_bricks
fill 288 149 473 288 150 473 minecraft:polished_blackstone_bricks
fill 288 149 475 288 150 475 minecraft:polished_blackstone_bricks
fill 289 149 466 289 150 466 minecraft:polished_blackstone_bricks
fill 289 149 468 289 150 468 minecraft:polished_blackstone_bricks
fill 289 149 470 289 150 470 minecraft:polished_blackstone_bricks
fill 289 149 472 289 150 472 minecraft:polished_blackstone_bricks
fill 289 149 474 289 150 474 minecraft:polished_blackstone_bricks
fill 290 149 465 290 150 465 minecraft:polished_blackstone_bricks
fill 290 149 467 290 150 467 minecraft:polished_blackstone_bricks
fill 290 149 469 290 150 469 minecraft:polished_blackstone_bricks
fill 290 149 471 290 150 471 minecraft:polished_blackstone_bricks
fill 290 149 473 290 150 473 minecraft:polished_blackstone_bricks
fill 290 149 475 290 150 475 minecraft:polished_blackstone_bricks
fill 313 149 480 313 150 480 minecraft:polished_blackstone_bricks
fill 313 149 482 313 150 482 minecraft:polished_blackstone_bricks
fill 313 149 484 313 150 484 minecraft:polished_blackstone_bricks
fill 313 149 486 313 150 486 minecraft:polished_blackstone_bricks
fill 313 149 488 313 150 488 minecraft:polished_blackstone_bricks
fill 313 149 490 313 150 490 minecraft:polished_blackstone_bricks
fill 313 149 492 313 150 492 minecraft:polished_blackstone_bricks
fill 314 149 481 314 150 481 minecraft:polished_blackstone_bricks
fill 314 149 483 314 150 483 minecraft:polished_blackstone_bricks
fill 314 149 485 314 150 485 minecraft:polished_blackstone_bricks
fill 314 149 487 314 150 487 minecraft:polished_blackstone_bricks
fill 314 149 489 314 150 489 minecraft:polished_blackstone_bricks
fill 314 149 491 314 150 491 minecraft:polished_blackstone_bricks
fill 315 149 480 315 150 480 minecraft:polished_blackstone_bricks
fill 315 149 482 315 150 482 minecraft:polished_blackstone_bricks
fill 315 149 484 315 150 484 minecraft:polished_blackstone_bricks
fill 315 149 486 315 150 486 minecraft:polished_blackstone_bricks
fill 315 149 488 315 150 488 minecraft:polished_blackstone_bricks
fill 315 149 490 315 150 490 minecraft:polished_blackstone_bricks
fill 315 149 492 315 150 492 minecraft:polished_blackstone_bricks
fill 316 149 481 316 150 481 minecraft:polished_blackstone_bricks
fill 316 149 483 316 150 483 minecraft:polished_blackstone_bricks
fill 316 149 485 316 150 485 minecraft:polished_blackstone_bricks
fill 316 149 487 316 150 487 minecraft:polished_blackstone_bricks
fill 316 149 489 316 150 489 minecraft:polished_blackstone_bricks
fill 316 149 491 316 150 491 minecraft:polished_blackstone_bricks
fill 317 149 480 317 150 480 minecraft:polished_blackstone_bricks
fill 317 149 482 317 150 482 minecraft:polished_blackstone_bricks
fill 317 149 484 317 150 484 minecraft:polished_blackstone_bricks
fill 317 149 486 317 150 486 minecraft:polished_blackstone_bricks
fill 317 149 488 317 150 488 minecraft:polished_blackstone_bricks
fill 317 149 490 317 150 490 minecraft:polished_blackstone_bricks
fill 317 149 492 317 150 492 minecraft:polished_blackstone_bricks
fill 318 149 481 318 150 481 minecraft:polished_blackstone_bricks
fill 318 149 483 318 150 483 minecraft:polished_blackstone_bricks
fill 318 149 485 318 150 485 minecraft:polished_blackstone_bricks
fill 318 149 487 318 150 487 minecraft:polished_blackstone_bricks
fill 318 149 489 318 150 489 minecraft:polished_blackstone_bricks
fill 318 149 491 318 150 491 minecraft:polished_blackstone_bricks
fill 319 149 480 319 150 480 minecraft:polished_blackstone_bricks
fill 319 149 482 319 150 482 minecraft:polished_blackstone_bricks
fill 319 149 484 319 150 484 minecraft:polished_blackstone_bricks
fill 319 149 486 319 150 486 minecraft:polished_blackstone_bricks
fill 319 149 488 319 150 488 minecraft:polished_blackstone_bricks
fill 319 149 490 319 150 490 minecraft:polished_blackstone_bricks
fill 319 149 492 319 150 492 minecraft:polished_blackstone_bricks
fill 320 149 481 320 150 481 minecraft:polished_blackstone_bricks
fill 320 149 483 320 150 483 minecraft:polished_blackstone_bricks
fill 320 149 485 320 150 485 minecraft:polished_blackstone_bricks
fill 320 149 487 320 150 487 minecraft:polished_blackstone_bricks
fill 320 149 489 320 150 489 minecraft:polished_blackstone_bricks
fill 320 149 491 320 150 491 minecraft:polished_blackstone_bricks
fill 321 149 480 321 150 480 minecraft:polished_blackstone_bricks
fill 321 149 482 321 150 482 minecraft:polished_blackstone_bricks
fill 321 149 484 321 150 484 minecraft:polished_blackstone_bricks
fill 321 149 486 321 150 486 minecraft:polished_blackstone_bricks
fill 321 149 488 321 150 488 minecraft:polished_blackstone_bricks
fill 321 149 490 321 150 490 minecraft:polished_blackstone_bricks
fill 321 149 492 321 150 492 minecraft:polished_blackstone_bricks
fill 322 149 481 322 150 481 minecraft:polished_blackstone_bricks
fill 322 149 483 322 150 483 minecraft:polished_blackstone_bricks
fill 322 149 485 322 150 485 minecraft:polished_blackstone_bricks
fill 322 149 487 322 150 487 minecraft:polished_blackstone_bricks
fill 322 149 489 322 150 489 minecraft:polished_blackstone_bricks
fill 322 149 491 322 150 491 minecraft:polished_blackstone_bricks
fill 323 149 480 323 150 480 minecraft:polished_blackstone_bricks
fill 323 149 482 323 150 482 minecraft:polished_blackstone_bricks
fill 323 149 484 323 150 484 minecraft:polished_blackstone_bricks
fill 323 149 486 323 150 486 minecraft:polished_blackstone_bricks
fill 323 149 488 323 150 488 minecraft:polished_blackstone_bricks
fill 323 149 490 323 150 490 minecraft:polished_blackstone_bricks
fill 323 149 492 323 150 492 minecraft:polished_blackstone_bricks
setblock 283 151 466 minecraft:shroomlight
setblock 283 151 468 minecraft:shroomlight
setblock 283 151 470 minecraft:shroomlight
setblock 283 151 472 minecraft:shroomlight
setblock 283 151 474 minecraft:shroomlight
setblock 284 151 465 minecraft:shroomlight
setblock 284 151 467 minecraft:shroomlight
setblock 284 151 469 minecraft:shroomlight
setblock 284 151 471 minecraft:shroomlight
setblock 284 151 473 minecraft:shroomlight
setblock 284 151 475 minecraft:shroomlight
setblock 285 151 466 minecraft:shroomlight
setblock 285 151 468 minecraft:shroomlight
setblock 285 151 470 minecraft:shroomlight
setblock 285 151 472 minecraft:shroomlight
setblock 285 151 474 minecraft:shroomlight
setblock 285 151 482 minecraft:light[level=14]
setblock 285 151 490 minecraft:light[level=14]
setblock 285 151 498 minecraft:light[level=14]
setblock 286 151 465 minecraft:shroomlight
setblock 286 151 467 minecraft:shroomlight
setblock 286 151 469 minecraft:shroomlight
setblock 286 151 471 minecraft:shroomlight
setblock 286 151 473 minecraft:shroomlight
setblock 286 151 475 minecraft:shroomlight
setblock 287 151 466 minecraft:shroomlight
setblock 287 151 468 minecraft:shroomlight
setblock 287 151 470 minecraft:shroomlight
setblock 287 151 472 minecraft:shroomlight
setblock 287 151 474 minecraft:shroomlight
setblock 288 151 465 minecraft:shroomlight
setblock 288 151 467 minecraft:shroomlight
setblock 288 151 469 minecraft:shroomlight
setblock 288 151 471 minecraft:shroomlight
setblock 288 151 473 minecraft:shroomlight
setblock 288 151 475 minecraft:shroomlight
setblock 289 151 466 minecraft:shroomlight
setblock 289 151 468 minecraft:shroomlight
setblock 289 151 470 minecraft:shroomlight
setblock 289 151 472 minecraft:shroomlight
setblock 289 151 474 minecraft:shroomlight
setblock 290 151 465 minecraft:shroomlight
setblock 290 151 467 minecraft:shroomlight
setblock 290 151 469 minecraft:shroomlight
setblock 290 151 471 minecraft:shroomlight
setblock 290 151 473 minecraft:shroomlight
setblock 290 151 475 minecraft:shroomlight
setblock 293 151 466 minecraft:light[level=14]
setblock 293 151 474 minecraft:light[level=14]
setblock 293 151 482 minecraft:light[level=14]
setblock 293 151 490 minecraft:light[level=14]
setblock 293 151 498 minecraft:light[level=14]
setblock 301 151 466 minecraft:light[level=14]
setblock 301 151 474 minecraft:light[level=14]
setblock 301 151 482 minecraft:light[level=14]
setblock 301 151 490 minecraft:light[level=14]
setblock 301 151 498 minecraft:light[level=14]
setblock 309 151 466 minecraft:light[level=14]
setblock 309 151 474 minecraft:light[level=14]
setblock 309 151 482 minecraft:light[level=14]
setblock 309 151 490 minecraft:light[level=14]
setblock 309 151 498 minecraft:light[level=14]
setblock 313 151 480 minecraft:shroomlight
setblock 313 151 482 minecraft:shroomlight
setblock 313 151 484 minecraft:shroomlight
setblock 313 151 486 minecraft:shroomlight
setblock 313 151 488 minecraft:shroomlight
setblock 313 151 490 minecraft:shroomlight
setblock 313 151 492 minecraft:shroomlight
setblock 314 151 481 minecraft:shroomlight
setblock 314 151 483 minecraft:shroomlight
setblock 314 151 485 minecraft:shroomlight
setblock 314 151 487 minecraft:shroomlight
setblock 314 151 489 minecraft:shroomlight
setblock 314 151 491 minecraft:shroomlight
setblock 315 151 480 minecraft:shroomlight
setblock 315 151 482 minecraft:shroomlight
setblock 315 151 484 minecraft:shroomlight
setblock 315 151 486 minecraft:shroomlight
setblock 315 151 488 minecraft:shroomlight
setblock 315 151 490 minecraft:shroomlight
setblock 315 151 492 minecraft:shroomlight
setblock 316 151 481 minecraft:shroomlight
setblock 316 151 483 minecraft:shroomlight
setblock 316 151 485 minecraft:shroomlight
setblock 316 151 487 minecraft:shroomlight
setblock 316 151 489 minecraft:shroomlight
setblock 316 151 491 minecraft:shroomlight
setblock 317 151 466 minecraft:light[level=14]
setblock 317 151 474 minecraft:light[level=14]
setblock 317 151 480 minecraft:shroomlight
setblock 317 151 482 minecraft:shroomlight
setblock 317 151 484 minecraft:shroomlight
setblock 317 151 486 minecraft:shroomlight
setblock 317 151 488 minecraft:shroomlight
setblock 317 151 490 minecraft:shroomlight
setblock 317 151 492 minecraft:shroomlight
setblock 317 151 498 minecraft:light[level=14]
setblock 318 151 481 minecraft:shroomlight
setblock 318 151 483 minecraft:shroomlight
setblock 318 151 485 minecraft:shroomlight
setblock 318 151 487 minecraft:shroomlight
setblock 318 151 489 minecraft:shroomlight
setblock 318 151 491 minecraft:shroomlight
setblock 319 151 480 minecraft:shroomlight
setblock 319 151 482 minecraft:shroomlight
setblock 319 151 484 minecraft:shroomlight
setblock 319 151 486 minecraft:shroomlight
setblock 319 151 488 minecraft:shroomlight
setblock 319 151 490 minecraft:shroomlight
setblock 319 151 492 minecraft:shroomlight
setblock 320 151 481 minecraft:shroomlight
setblock 320 151 483 minecraft:shroomlight
setblock 320 151 485 minecraft:shroomlight
setblock 320 151 487 minecraft:shroomlight
setblock 320 151 489 minecraft:shroomlight
setblock 320 151 491 minecraft:shroomlight
setblock 321 151 480 minecraft:shroomlight
setblock 321 151 482 minecraft:shroomlight
setblock 321 151 484 minecraft:shroomlight
setblock 321 151 486 minecraft:shroomlight
setblock 321 151 488 minecraft:shroomlight
setblock 321 151 490 minecraft:shroomlight
setblock 321 151 492 minecraft:shroomlight
setblock 322 151 481 minecraft:shroomlight
setblock 322 151 483 minecraft:shroomlight
setblock 322 151 485 minecraft:shroomlight
setblock 322 151 487 minecraft:shroomlight
setblock 322 151 489 minecraft:shroomlight
setblock 322 151 491 minecraft:shroomlight
setblock 323 151 480 minecraft:shroomlight
setblock 323 151 482 minecraft:shroomlight
setblock 323 151 484 minecraft:shroomlight
setblock 323 151 486 minecraft:shroomlight
setblock 323 151 488 minecraft:shroomlight
setblock 323 151 490 minecraft:shroomlight
setblock 323 151 492 minecraft:shroomlight
fill 282 152 469 282 165 469 minecraft:nether_bricks
fill 282 152 470 282 152 471 minecraft:shroomlight
fill 282 152 472 282 165 472 minecraft:nether_bricks
fill 282 152 481 282 165 481 minecraft:nether_bricks
fill 282 152 482 282 152 483 minecraft:shroomlight
fill 282 152 484 282 165 484 minecraft:nether_bricks
fill 282 152 493 282 165 493 minecraft:nether_bricks
fill 282 152 494 282 152 495 minecraft:shroomlight
fill 282 152 496 282 165 496 minecraft:nether_bricks
fill 282 152 505 282 165 505 minecraft:nether_bricks
fill 283 152 466 283 153 466 minecraft:polished_blackstone_bricks
fill 283 152 468 283 153 468 minecraft:polished_blackstone_bricks
fill 283 152 470 283 153 470 minecraft:polished_blackstone_bricks
fill 283 152 472 283 153 472 minecraft:polished_blackstone_bricks
fill 283 152 474 283 153 474 minecraft:polished_blackstone_bricks
fill 283 152 505 284 152 505 minecraft:shroomlight
fill 284 152 465 284 153 465 minecraft:polished_blackstone_bricks
fill 284 152 467 284 153 467 minecraft:polished_blackstone_bricks
fill 284 152 469 284 153 469 minecraft:polished_blackstone_bricks
fill 284 152 471 284 153 471 minecraft:polished_blackstone_bricks
fill 284 152 473 284 153 473 minecraft:polished_blackstone_bricks
fill 284 152 475 284 153 475 minecraft:polished_blackstone_bricks
fill 285 152 466 285 153 466 minecraft:polished_blackstone_bricks
fill 285 152 468 285 153 468 minecraft:polished_blackstone_bricks
fill 285 152 470 285 153 470 minecraft:polished_blackstone_bricks
fill 285 152 472 285 153 472 minecraft:polished_blackstone_bricks
fill 285 152 474 285 153 474 minecraft:polished_blackstone_bricks
fill 285 152 505 285 165 505 minecraft:nether_bricks
fill 286 152 465 286 153 465 minecraft:polished_blackstone_bricks
fill 286 152 467 286 153 467 minecraft:polished_blackstone_bricks
fill 286 152 469 286 153 469 minecraft:polished_blackstone_bricks
fill 286 152 471 286 153 471 minecraft:polished_blackstone_bricks
fill 286 152 473 286 153 473 minecraft:polished_blackstone_bricks
fill 286 152 475 286 153 475 minecraft:polished_blackstone_bricks
fill 287 152 466 287 153 466 minecraft:polished_blackstone_bricks
fill 287 152 468 287 153 468 minecraft:polished_blackstone_bricks
fill 287 152 470 287 153 470 minecraft:polished_blackstone_bricks
fill 287 152 472 287 153 472 minecraft:polished_blackstone_bricks
fill 287 152 474 287 153 474 minecraft:polished_blackstone_bricks
fill 288 152 465 288 153 465 minecraft:polished_blackstone_bricks
fill 288 152 467 288 153 467 minecraft:polished_blackstone_bricks
fill 288 152 469 288 153 469 minecraft:polished_blackstone_bricks
fill 288 152 471 288 153 471 minecraft:polished_blackstone_bricks
fill 288 152 473 288 153 473 minecraft:polished_blackstone_bricks
fill 288 152 475 288 153 475 minecraft:polished_blackstone_bricks
fill 289 152 463 289 165 463 minecraft:nether_bricks
fill 289 152 466 289 153 466 minecraft:polished_blackstone_bricks
fill 289 152 468 289 153 468 minecraft:polished_blackstone_bricks
fill 289 152 470 289 153 470 minecraft:polished_blackstone_bricks
fill 289 152 472 289 153 472 minecraft:polished_blackstone_bricks
fill 289 152 474 289 153 474 minecraft:polished_blackstone_bricks
fill 290 152 463 291 152 463 minecraft:shroomlight
fill 290 152 465 290 153 465 minecraft:polished_blackstone_bricks
fill 290 152 467 290 153 467 minecraft:polished_blackstone_bricks
fill 290 152 469 290 153 469 minecraft:polished_blackstone_bricks
fill 290 152 471 290 153 471 minecraft:polished_blackstone_bricks
fill 290 152 473 290 153 473 minecraft:polished_blackstone_bricks
fill 290 152 475 290 153 475 minecraft:polished_blackstone_bricks
fill 292 152 463 292 165 463 minecraft:nether_bricks
fill 294 152 505 294 165 505 minecraft:nether_bricks
fill 295 152 505 296 152 505 minecraft:shroomlight
fill 297 152 505 297 165 505 minecraft:nether_bricks
fill 301 152 463 301 165 463 minecraft:nether_bricks
fill 302 152 463 303 152 463 minecraft:shroomlight
fill 304 152 463 304 165 463 minecraft:nether_bricks
fill 306 152 505 306 165 505 minecraft:nether_bricks
fill 307 152 505 308 152 505 minecraft:shroomlight
fill 309 152 505 309 165 505 minecraft:nether_bricks
fill 313 152 463 313 165 463 minecraft:nether_bricks
fill 313 152 480 313 153 480 minecraft:polished_blackstone_bricks
fill 313 152 482 313 153 482 minecraft:polished_blackstone_bricks
fill 313 152 484 313 153 484 minecraft:polished_blackstone_bricks
fill 313 152 486 313 153 486 minecraft:polished_blackstone_bricks
fill 313 152 488 313 153 488 minecraft:polished_blackstone_bricks
fill 313 152 490 313 153 490 minecraft:polished_blackstone_bricks
fill 313 152 492 313 153 492 minecraft:polished_blackstone_bricks
fill 314 152 463 315 152 463 minecraft:shroomlight
fill 314 152 481 314 153 481 minecraft:polished_blackstone_bricks
fill 314 152 483 314 153 483 minecraft:polished_blackstone_bricks
fill 314 152 485 314 153 485 minecraft:polished_blackstone_bricks
fill 314 152 487 314 153 487 minecraft:polished_blackstone_bricks
fill 314 152 489 314 153 489 minecraft:polished_blackstone_bricks
fill 314 152 491 314 153 491 minecraft:polished_blackstone_bricks
fill 315 152 480 315 153 480 minecraft:polished_blackstone_bricks
fill 315 152 482 315 153 482 minecraft:polished_blackstone_bricks
fill 315 152 484 315 153 484 minecraft:polished_blackstone_bricks
fill 315 152 486 315 153 486 minecraft:polished_blackstone_bricks
fill 315 152 488 315 153 488 minecraft:polished_blackstone_bricks
fill 315 152 490 315 153 490 minecraft:polished_blackstone_bricks
fill 315 152 492 315 153 492 minecraft:polished_blackstone_bricks
fill 316 152 463 316 165 463 minecraft:nether_bricks
fill 316 152 481 316 153 481 minecraft:polished_blackstone_bricks
fill 316 152 483 316 153 483 minecraft:polished_blackstone_bricks
fill 316 152 485 316 153 485 minecraft:polished_blackstone_bricks
fill 316 152 487 316 153 487 minecraft:polished_blackstone_bricks
fill 316 152 489 316 153 489 minecraft:polished_blackstone_bricks
fill 316 152 491 316 153 491 minecraft:polished_blackstone_bricks
fill 317 152 480 317 153 480 minecraft:polished_blackstone_bricks
fill 317 152 482 317 153 482 minecraft:polished_blackstone_bricks
fill 317 152 484 317 153 484 minecraft:polished_blackstone_bricks
fill 317 152 486 317 153 486 minecraft:polished_blackstone_bricks
fill 317 152 488 317 153 488 minecraft:polished_blackstone_bricks
fill 317 152 490 317 153 490 minecraft:polished_blackstone_bricks
fill 317 152 492 317 153 492 minecraft:polished_blackstone_bricks
fill 318 152 481 318 153 481 minecraft:polished_blackstone_bricks
fill 318 152 483 318 153 483 minecraft:polished_blackstone_bricks
fill 318 152 485 318 153 485 minecraft:polished_blackstone_bricks
fill 318 152 487 318 153 487 minecraft:polished_blackstone_bricks
fill 318 152 489 318 153 489 minecraft:polished_blackstone_bricks
fill 318 152 491 318 153 491 minecraft:polished_blackstone_bricks
fill 318 152 505 318 165 505 minecraft:nether_bricks
fill 319 152 480 319 153 480 minecraft:polished_blackstone_bricks
fill 319 152 482 319 153 482 minecraft:polished_blackstone_bricks
fill 319 152 484 319 153 484 minecraft:polished_blackstone_bricks
fill 319 152 486 319 153 486 minecraft:polished_blackstone_bricks
fill 319 152 488 319 153 488 minecraft:polished_blackstone_bricks
fill 319 152 490 319 153 490 minecraft:polished_blackstone_bricks
fill 319 152 492 319 153 492 minecraft:polished_blackstone_bricks
fill 319 152 505 320 152 505 minecraft:shroomlight
fill 320 152 481 320 153 481 minecraft:polished_blackstone_bricks
fill 320 152 483 320 153 483 minecraft:polished_blackstone_bricks
fill 320 152 485 320 153 485 minecraft:polished_blackstone_bricks
fill 320 152 487 320 153 487 minecraft:polished_blackstone_bricks
fill 320 152 489 320 153 489 minecraft:polished_blackstone_bricks
fill 320 152 491 320 153 491 minecraft:polished_blackstone_bricks
fill 321 152 480 321 153 480 minecraft:polished_blackstone_bricks
fill 321 152 482 321 153 482 minecraft:polished_blackstone_bricks
fill 321 152 484 321 153 484 minecraft:polished_blackstone_bricks
fill 321 152 486 321 153 486 minecraft:polished_blackstone_bricks
fill 321 152 488 321 153 488 minecraft:polished_blackstone_bricks
fill 321 152 490 321 153 490 minecraft:polished_blackstone_bricks
fill 321 152 492 321 153 492 minecraft:polished_blackstone_bricks
fill 321 152 505 321 165 505 minecraft:nether_bricks
fill 322 152 481 322 153 481 minecraft:polished_blackstone_bricks
fill 322 152 483 322 153 483 minecraft:polished_blackstone_bricks
fill 322 152 485 322 153 485 minecraft:polished_blackstone_bricks
fill 322 152 487 322 153 487 minecraft:polished_blackstone_bricks
fill 322 152 489 322 153 489 minecraft:polished_blackstone_bricks
fill 322 152 491 322 153 491 minecraft:polished_blackstone_bricks
fill 323 152 480 323 153 480 minecraft:polished_blackstone_bricks
fill 323 152 482 323 153 482 minecraft:polished_blackstone_bricks
fill 323 152 484 323 153 484 minecraft:polished_blackstone_bricks
fill 323 152 486 323 153 486 minecraft:polished_blackstone_bricks
fill 323 152 488 323 153 488 minecraft:polished_blackstone_bricks
fill 323 152 490 323 153 490 minecraft:polished_blackstone_bricks
fill 323 152 492 323 153 492 minecraft:polished_blackstone_bricks
fill 324 152 464 324 165 464 minecraft:nether_bricks
fill 324 152 465 324 152 466 minecraft:shroomlight
fill 324 152 467 324 165 467 minecraft:nether_bricks
fill 324 152 476 324 165 476 minecraft:nether_bricks
fill 324 152 477 324 152 478 minecraft:shroomlight
fill 324 152 479 324 165 479 minecraft:nether_bricks
fill 324 152 488 324 165 488 minecraft:nether_bricks
fill 324 152 489 324 152 490 minecraft:shroomlight
fill 324 152 491 324 165 491 minecraft:nether_bricks
fill 324 152 500 324 165 500 minecraft:nether_bricks
fill 324 152 501 324 152 502 minecraft:shroomlight
fill 324 152 503 324 165 503 minecraft:nether_bricks
fill 282 153 470 282 165 471 minecraft:nether_bricks
fill 282 153 482 282 165 483 minecraft:nether_bricks
fill 282 153 494 282 165 495 minecraft:nether_bricks
fill 283 153 505 284 165 505 minecraft:nether_bricks
fill 290 153 463 291 165 463 minecraft:nether_bricks
fill 295 153 505 296 165 505 minecraft:nether_bricks
fill 302 153 463 303 165 463 minecraft:nether_bricks
fill 307 153 505 308 165 505 minecraft:nether_bricks
fill 314 153 463 315 165 463 minecraft:nether_bricks
fill 319 153 505 320 165 505 minecraft:nether_bricks
fill 324 153 465 324 165 466 minecraft:nether_bricks
fill 324 153 477 324 165 478 minecraft:nether_bricks
fill 324 153 489 324 165 490 minecraft:nether_bricks
fill 324 153 501 324 165 502 minecraft:nether_bricks
setblock 283 154 466 minecraft:shroomlight
setblock 283 154 468 minecraft:shroomlight
setblock 283 154 470 minecraft:shroomlight
setblock 283 154 472 minecraft:shroomlight
setblock 283 154 474 minecraft:shroomlight
setblock 284 154 465 minecraft:shroomlight
setblock 284 154 467 minecraft:shroomlight
setblock 284 154 469 minecraft:shroomlight
setblock 284 154 471 minecraft:shroomlight
setblock 284 154 473 minecraft:shroomlight
setblock 284 154 475 minecraft:shroomlight
setblock 285 154 466 minecraft:shroomlight
setblock 285 154 468 minecraft:shroomlight
setblock 285 154 470 minecraft:shroomlight
setblock 285 154 472 minecraft:shroomlight
setblock 285 154 474 minecraft:shroomlight
setblock 286 154 465 minecraft:shroomlight
setblock 286 154 467 minecraft:shroomlight
setblock 286 154 469 minecraft:shroomlight
setblock 286 154 471 minecraft:shroomlight
setblock 286 154 473 minecraft:shroomlight
setblock 286 154 475 minecraft:shroomlight
setblock 287 154 466 minecraft:shroomlight
setblock 287 154 468 minecraft:shroomlight
setblock 287 154 470 minecraft:shroomlight
setblock 287 154 472 minecraft:shroomlight
setblock 287 154 474 minecraft:shroomlight
setblock 288 154 465 minecraft:shroomlight
setblock 288 154 467 minecraft:shroomlight
setblock 288 154 469 minecraft:shroomlight
setblock 288 154 471 minecraft:shroomlight
setblock 288 154 473 minecraft:shroomlight
setblock 288 154 475 minecraft:shroomlight
setblock 289 154 466 minecraft:shroomlight
setblock 289 154 468 minecraft:shroomlight
setblock 289 154 470 minecraft:shroomlight
setblock 289 154 472 minecraft:shroomlight
setblock 289 154 474 minecraft:shroomlight
setblock 290 154 465 minecraft:shroomlight
setblock 290 154 467 minecraft:shroomlight
setblock 290 154 469 minecraft:shroomlight
setblock 290 154 471 minecraft:shroomlight
setblock 290 154 473 minecraft:shroomlight
setblock 290 154 475 minecraft:shroomlight
setblock 313 154 480 minecraft:shroomlight
setblock 313 154 482 minecraft:shroomlight
setblock 313 154 484 minecraft:shroomlight
setblock 313 154 486 minecraft:shroomlight
setblock 313 154 488 minecraft:shroomlight
setblock 313 154 490 minecraft:shroomlight
setblock 313 154 492 minecraft:shroomlight
setblock 314 154 481 minecraft:shroomlight
setblock 314 154 483 minecraft:shroomlight
setblock 314 154 485 minecraft:shroomlight
setblock 314 154 487 minecraft:shroomlight
setblock 314 154 489 minecraft:shroomlight
setblock 314 154 491 minecraft:shroomlight
setblock 315 154 480 minecraft:shroomlight
setblock 315 154 482 minecraft:shroomlight
setblock 315 154 484 minecraft:shroomlight
setblock 315 154 486 minecraft:shroomlight
setblock 315 154 488 minecraft:shroomlight
setblock 315 154 490 minecraft:shroomlight
setblock 315 154 492 minecraft:shroomlight
setblock 316 154 481 minecraft:shroomlight
setblock 316 154 483 minecraft:shroomlight
setblock 316 154 485 minecraft:shroomlight
setblock 316 154 487 minecraft:shroomlight
setblock 316 154 489 minecraft:shroomlight
setblock 316 154 491 minecraft:shroomlight
setblock 317 154 480 minecraft:shroomlight
setblock 317 154 482 minecraft:shroomlight
setblock 317 154 484 minecraft:shroomlight
setblock 317 154 486 minecraft:shroomlight
setblock 317 154 488 minecraft:shroomlight
setblock 317 154 490 minecraft:shroomlight
setblock 317 154 492 minecraft:shroomlight
setblock 318 154 481 minecraft:shroomlight
setblock 318 154 483 minecraft:shroomlight
setblock 318 154 485 minecraft:shroomlight
setblock 318 154 487 minecraft:shroomlight
setblock 318 154 489 minecraft:shroomlight
setblock 318 154 491 minecraft:shroomlight
setblock 319 154 480 minecraft:shroomlight
setblock 319 154 482 minecraft:shroomlight
setblock 319 154 484 minecraft:shroomlight
setblock 319 154 486 minecraft:shroomlight
setblock 319 154 488 minecraft:shroomlight
setblock 319 154 490 minecraft:shroomlight
setblock 319 154 492 minecraft:shroomlight
setblock 320 154 481 minecraft:shroomlight
setblock 320 154 483 minecraft:shroomlight
setblock 320 154 485 minecraft:shroomlight
setblock 320 154 487 minecraft:shroomlight
setblock 320 154 489 minecraft:shroomlight
setblock 320 154 491 minecraft:shroomlight
setblock 321 154 480 minecraft:shroomlight
setblock 321 154 482 minecraft:shroomlight
setblock 321 154 484 minecraft:shroomlight
setblock 321 154 486 minecraft:shroomlight
setblock 321 154 488 minecraft:shroomlight
setblock 321 154 490 minecraft:shroomlight
setblock 321 154 492 minecraft:shroomlight
setblock 322 154 481 minecraft:shroomlight
setblock 322 154 483 minecraft:shroomlight
setblock 322 154 485 minecraft:shroomlight
setblock 322 154 487 minecraft:shroomlight
setblock 322 154 489 minecraft:shroomlight
setblock 322 154 491 minecraft:shroomlight
setblock 323 154 480 minecraft:shroomlight
setblock 323 154 482 minecraft:shroomlight
setblock 323 154 484 minecraft:shroomlight
setblock 323 154 486 minecraft:shroomlight
setblock 323 154 488 minecraft:shroomlight
setblock 323 154 490 minecraft:shroomlight
setblock 323 154 492 minecraft:shroomlight
fill 283 155 466 283 156 466 minecraft:polished_blackstone_bricks
fill 283 155 468 283 156 468 minecraft:polished_blackstone_bricks
fill 283 155 470 283 156 470 minecraft:polished_blackstone_bricks
fill 283 155 472 283 156 472 minecraft:polished_blackstone_bricks
fill 283 155 474 283 156 474 minecraft:polished_blackstone_bricks
fill 284 155 465 284 156 465 minecraft:polished_blackstone_bricks
fill 284 155 467 284 156 467 minecraft:polished_blackstone_bricks
fill 284 155 469 284 156 469 minecraft:polished_blackstone_bricks
fill 284 155 471 284 156 471 minecraft:polished_blackstone_bricks
fill 284 155 473 284 156 473 minecraft:polished_blackstone_bricks
fill 284 155 475 284 156 475 minecraft:polished_blackstone_bricks
fill 285 155 466 285 156 466 minecraft:polished_blackstone_bricks
fill 285 155 468 285 156 468 minecraft:polished_blackstone_bricks
fill 285 155 470 285 156 470 minecraft:polished_blackstone_bricks
fill 285 155 472 285 156 472 minecraft:polished_blackstone_bricks
fill 285 155 474 285 156 474 minecraft:polished_blackstone_bricks
fill 286 155 465 286 156 465 minecraft:polished_blackstone_bricks
fill 286 155 467 286 156 467 minecraft:polished_blackstone_bricks
fill 286 155 469 286 156 469 minecraft:polished_blackstone_bricks
fill 286 155 471 286 156 471 minecraft:polished_blackstone_bricks
fill 286 155 473 286 156 473 minecraft:polished_blackstone_bricks
fill 286 155 475 286 156 475 minecraft:polished_blackstone_bricks
fill 287 155 466 287 156 466 minecraft:polished_blackstone_bricks
fill 287 155 468 287 156 468 minecraft:polished_blackstone_bricks
fill 287 155 470 287 156 470 minecraft:polished_blackstone_bricks
fill 287 155 472 287 156 472 minecraft:polished_blackstone_bricks
fill 287 155 474 287 156 474 minecraft:polished_blackstone_bricks
fill 288 155 465 288 156 465 minecraft:polished_blackstone_bricks
fill 288 155 467 288 156 467 minecraft:polished_blackstone_bricks
fill 288 155 469 288 156 469 minecraft:polished_blackstone_bricks
fill 288 155 471 288 156 471 minecraft:polished_blackstone_bricks
fill 288 155 473 288 156 473 minecraft:polished_blackstone_bricks
fill 288 155 475 288 156 475 minecraft:polished_blackstone_bricks
fill 289 155 466 289 156 466 minecraft:polished_blackstone_bricks
fill 289 155 468 289 156 468 minecraft:polished_blackstone_bricks
fill 289 155 470 289 156 470 minecraft:polished_blackstone_bricks
fill 289 155 472 289 156 472 minecraft:polished_blackstone_bricks
fill 289 155 474 289 156 474 minecraft:polished_blackstone_bricks
fill 290 155 465 290 156 465 minecraft:polished_blackstone_bricks
fill 290 155 467 290 156 467 minecraft:polished_blackstone_bricks
fill 290 155 469 290 156 469 minecraft:polished_blackstone_bricks
fill 290 155 471 290 156 471 minecraft:polished_blackstone_bricks
fill 290 155 473 290 156 473 minecraft:polished_blackstone_bricks
fill 290 155 475 290 156 475 minecraft:polished_blackstone_bricks
fill 313 155 480 313 156 480 minecraft:polished_blackstone_bricks
fill 313 155 482 313 156 482 minecraft:polished_blackstone_bricks
fill 313 155 484 313 156 484 minecraft:polished_blackstone_bricks
fill 313 155 486 313 156 486 minecraft:polished_blackstone_bricks
fill 313 155 488 313 156 488 minecraft:polished_blackstone_bricks
fill 313 155 490 313 156 490 minecraft:polished_blackstone_bricks
fill 313 155 492 313 156 492 minecraft:polished_blackstone_bricks
fill 314 155 481 314 156 481 minecraft:polished_blackstone_bricks
fill 314 155 483 314 156 483 minecraft:polished_blackstone_bricks
fill 314 155 485 314 156 485 minecraft:polished_blackstone_bricks
fill 314 155 487 314 156 487 minecraft:polished_blackstone_bricks
fill 314 155 489 314 156 489 minecraft:polished_blackstone_bricks
fill 314 155 491 314 156 491 minecraft:polished_blackstone_bricks
fill 315 155 480 315 156 480 minecraft:polished_blackstone_bricks
fill 315 155 482 315 156 482 minecraft:polished_blackstone_bricks
fill 315 155 484 315 156 484 minecraft:polished_blackstone_bricks
fill 315 155 486 315 156 486 minecraft:polished_blackstone_bricks
fill 315 155 488 315 156 488 minecraft:polished_blackstone_bricks
fill 315 155 490 315 156 490 minecraft:polished_blackstone_bricks
fill 315 155 492 315 156 492 minecraft:polished_blackstone_bricks
fill 316 155 481 316 156 481 minecraft:polished_blackstone_bricks
fill 316 155 483 316 156 483 minecraft:polished_blackstone_bricks
fill 316 155 485 316 156 485 minecraft:polished_blackstone_bricks
fill 316 155 487 316 156 487 minecraft:polished_blackstone_bricks
fill 316 155 489 316 156 489 minecraft:polished_blackstone_bricks
fill 316 155 491 316 156 491 minecraft:polished_blackstone_bricks
fill 317 155 480 317 156 480 minecraft:polished_blackstone_bricks
fill 317 155 482 317 156 482 minecraft:polished_blackstone_bricks
fill 317 155 484 317 156 484 minecraft:polished_blackstone_bricks
fill 317 155 486 317 156 486 minecraft:polished_blackstone_bricks
fill 317 155 488 317 156 488 minecraft:polished_blackstone_bricks
fill 317 155 490 317 156 490 minecraft:polished_blackstone_bricks
fill 317 155 492 317 156 492 minecraft:polished_blackstone_bricks
fill 318 155 481 318 156 481 minecraft:polished_blackstone_bricks
fill 318 155 483 318 156 483 minecraft:polished_blackstone_bricks
fill 318 155 485 318 156 485 minecraft:polished_blackstone_bricks
fill 318 155 487 318 156 487 minecraft:polished_blackstone_bricks
fill 318 155 489 318 156 489 minecraft:polished_blackstone_bricks
fill 318 155 491 318 156 491 minecraft:polished_blackstone_bricks
fill 319 155 480 319 156 480 minecraft:polished_blackstone_bricks
fill 319 155 482 319 156 482 minecraft:polished_blackstone_bricks
fill 319 155 484 319 156 484 minecraft:polished_blackstone_bricks
fill 319 155 486 319 156 486 minecraft:polished_blackstone_bricks
fill 319 155 488 319 156 488 minecraft:polished_blackstone_bricks
fill 319 155 490 319 156 490 minecraft:polished_blackstone_bricks
fill 319 155 492 319 156 492 minecraft:polished_blackstone_bricks
fill 320 155 481 320 156 481 minecraft:polished_blackstone_bricks
fill 320 155 483 320 156 483 minecraft:polished_blackstone_bricks
fill 320 155 485 320 156 485 minecraft:polished_blackstone_bricks
fill 320 155 487 320 156 487 minecraft:polished_blackstone_bricks
fill 320 155 489 320 156 489 minecraft:polished_blackstone_bricks
fill 320 155 491 320 156 491 minecraft:polished_blackstone_bricks
fill 321 155 480 321 156 480 minecraft:polished_blackstone_bricks
fill 321 155 482 321 156 482 minecraft:polished_blackstone_bricks
fill 321 155 484 321 156 484 minecraft:polished_blackstone_bricks
fill 321 155 486 321 156 486 minecraft:polished_blackstone_bricks
fill 321 155 488 321 156 488 minecraft:polished_blackstone_bricks
fill 321 155 490 321 156 490 minecraft:polished_blackstone_bricks
fill 321 155 492 321 156 492 minecraft:polished_blackstone_bricks
fill 322 155 481 322 156 481 minecraft:polished_blackstone_bricks
fill 322 155 483 322 156 483 minecraft:polished_blackstone_bricks
fill 322 155 485 322 156 485 minecraft:polished_blackstone_bricks
fill 322 155 487 322 156 487 minecraft:polished_blackstone_bricks
fill 322 155 489 322 156 489 minecraft:polished_blackstone_bricks
fill 322 155 491 322 156 491 minecraft:polished_blackstone_bricks
fill 323 155 480 323 156 480 minecraft:polished_blackstone_bricks
fill 323 155 482 323 156 482 minecraft:polished_blackstone_bricks
fill 323 155 484 323 156 484 minecraft:polished_blackstone_bricks
fill 323 155 486 323 156 486 minecraft:polished_blackstone_bricks
fill 323 155 488 323 156 488 minecraft:polished_blackstone_bricks
fill 323 155 490 323 156 490 minecraft:polished_blackstone_bricks
fill 323 155 492 323 156 492 minecraft:polished_blackstone_bricks
setblock 283 157 466 minecraft:shroomlight
setblock 283 157 468 minecraft:shroomlight
setblock 283 157 470 minecraft:shroomlight
setblock 283 157 472 minecraft:shroomlight
setblock 283 157 474 minecraft:shroomlight
setblock 284 157 465 minecraft:shroomlight
setblock 284 157 467 minecraft:shroomlight
setblock 284 157 469 minecraft:shroomlight
setblock 284 157 471 minecraft:shroomlight
setblock 284 157 473 minecraft:shroomlight
setblock 284 157 475 minecraft:shroomlight
setblock 285 157 466 minecraft:shroomlight
setblock 285 157 468 minecraft:shroomlight
setblock 285 157 470 minecraft:shroomlight
setblock 285 157 472 minecraft:shroomlight
setblock 285 157 474 minecraft:shroomlight
setblock 286 157 465 minecraft:shroomlight
setblock 286 157 467 minecraft:shroomlight
setblock 286 157 469 minecraft:shroomlight
setblock 286 157 471 minecraft:shroomlight
setblock 286 157 473 minecraft:shroomlight
setblock 286 157 475 minecraft:shroomlight
setblock 287 157 466 minecraft:shroomlight
setblock 287 157 468 minecraft:shroomlight
setblock 287 157 470 minecraft:shroomlight
setblock 287 157 472 minecraft:shroomlight
setblock 287 157 474 minecraft:shroomlight
setblock 288 157 465 minecraft:shroomlight
setblock 288 157 467 minecraft:shroomlight
setblock 288 157 469 minecraft:shroomlight
setblock 288 157 471 minecraft:shroomlight
setblock 288 157 473 minecraft:shroomlight
setblock 288 157 475 minecraft:shroomlight
setblock 289 157 466 minecraft:shroomlight
setblock 289 157 468 minecraft:shroomlight
setblock 289 157 470 minecraft:shroomlight
setblock 289 157 472 minecraft:shroomlight
setblock 289 157 474 minecraft:shroomlight
setblock 290 157 465 minecraft:shroomlight
setblock 290 157 467 minecraft:shroomlight
setblock 290 157 469 minecraft:shroomlight
setblock 290 157 471 minecraft:shroomlight
setblock 290 157 473 minecraft:shroomlight
setblock 290 157 475 minecraft:shroomlight
setblock 313 157 480 minecraft:shroomlight
setblock 313 157 482 minecraft:shroomlight
setblock 313 157 484 minecraft:shroomlight
setblock 313 157 486 minecraft:shroomlight
setblock 313 157 488 minecraft:shroomlight
setblock 313 157 490 minecraft:shroomlight
setblock 313 157 492 minecraft:shroomlight
setblock 314 157 481 minecraft:shroomlight
setblock 314 157 483 minecraft:shroomlight
setblock 314 157 485 minecraft:shroomlight
setblock 314 157 487 minecraft:shroomlight
setblock 314 157 489 minecraft:shroomlight
setblock 314 157 491 minecraft:shroomlight
setblock 315 157 480 minecraft:shroomlight
setblock 315 157 482 minecraft:shroomlight
setblock 315 157 484 minecraft:shroomlight
setblock 315 157 486 minecraft:shroomlight
setblock 315 157 488 minecraft:shroomlight
setblock 315 157 490 minecraft:shroomlight
setblock 315 157 492 minecraft:shroomlight
setblock 316 157 481 minecraft:shroomlight
setblock 316 157 483 minecraft:shroomlight
setblock 316 157 485 minecraft:shroomlight
setblock 316 157 487 minecraft:shroomlight
setblock 316 157 489 minecraft:shroomlight
setblock 316 157 491 minecraft:shroomlight
setblock 317 157 480 minecraft:shroomlight
setblock 317 157 482 minecraft:shroomlight
setblock 317 157 484 minecraft:shroomlight
setblock 317 157 486 minecraft:shroomlight
setblock 317 157 488 minecraft:shroomlight
setblock 317 157 490 minecraft:shroomlight
setblock 317 157 492 minecraft:shroomlight
setblock 318 157 481 minecraft:shroomlight
setblock 318 157 483 minecraft:shroomlight
setblock 318 157 485 minecraft:shroomlight
setblock 318 157 487 minecraft:shroomlight
setblock 318 157 489 minecraft:shroomlight
setblock 318 157 491 minecraft:shroomlight
setblock 319 157 480 minecraft:shroomlight
setblock 319 157 482 minecraft:shroomlight
setblock 319 157 484 minecraft:shroomlight
setblock 319 157 486 minecraft:shroomlight
setblock 319 157 488 minecraft:shroomlight
setblock 319 157 490 minecraft:shroomlight
setblock 319 157 492 minecraft:shroomlight
setblock 320 157 481 minecraft:shroomlight
setblock 320 157 483 minecraft:shroomlight
setblock 320 157 485 minecraft:shroomlight
setblock 320 157 487 minecraft:shroomlight
setblock 320 157 489 minecraft:shroomlight
setblock 320 157 491 minecraft:shroomlight
fill 321 157 471 321 167 471 minecraft:red_wool
setblock 321 157 480 minecraft:shroomlight
setblock 321 157 482 minecraft:shroomlight
setblock 321 157 484 minecraft:shroomlight
setblock 321 157 486 minecraft:shroomlight
setblock 321 157 488 minecraft:shroomlight
setblock 321 157 490 minecraft:shroomlight
setblock 321 157 492 minecraft:shroomlight
setblock 322 157 481 minecraft:shroomlight
setblock 322 157 483 minecraft:shroomlight
setblock 322 157 485 minecraft:shroomlight
setblock 322 157 487 minecraft:shroomlight
setblock 322 157 489 minecraft:shroomlight
setblock 322 157 491 minecraft:shroomlight
setblock 323 157 480 minecraft:shroomlight
setblock 323 157 482 minecraft:shroomlight
setblock 323 157 484 minecraft:shroomlight
setblock 323 157 486 minecraft:shroomlight
setblock 323 157 488 minecraft:shroomlight
setblock 323 157 490 minecraft:shroomlight
setblock 323 157 492 minecraft:shroomlight
fill 283 158 466 283 159 466 minecraft:polished_blackstone_bricks
fill 283 158 468 283 159 468 minecraft:polished_blackstone_bricks
fill 283 158 470 283 159 470 minecraft:polished_blackstone_bricks
fill 283 158 472 283 159 472 minecraft:polished_blackstone_bricks
fill 283 158 474 283 159 474 minecraft:polished_blackstone_bricks
fill 284 158 465 284 159 465 minecraft:polished_blackstone_bricks
fill 284 158 467 284 159 467 minecraft:polished_blackstone_bricks
fill 284 158 469 284 159 469 minecraft:polished_blackstone_bricks
fill 284 158 471 284 159 471 minecraft:polished_blackstone_bricks
fill 284 158 473 284 159 473 minecraft:polished_blackstone_bricks
fill 284 158 475 284 159 475 minecraft:polished_blackstone_bricks
fill 285 158 466 285 159 466 minecraft:polished_blackstone_bricks
fill 285 158 468 285 159 468 minecraft:polished_blackstone_bricks
fill 285 158 470 285 159 470 minecraft:polished_blackstone_bricks
fill 285 158 472 285 159 472 minecraft:polished_blackstone_bricks
fill 285 158 474 285 159 474 minecraft:polished_blackstone_bricks
fill 286 158 465 286 159 465 minecraft:polished_blackstone_bricks
fill 286 158 467 286 159 467 minecraft:polished_blackstone_bricks
fill 286 158 469 286 159 469 minecraft:polished_blackstone_bricks
fill 286 158 471 286 159 471 minecraft:polished_blackstone_bricks
fill 286 158 473 286 159 473 minecraft:polished_blackstone_bricks
fill 286 158 475 286 159 475 minecraft:polished_blackstone_bricks
fill 287 158 466 287 159 466 minecraft:polished_blackstone_bricks
fill 287 158 468 287 159 468 minecraft:polished_blackstone_bricks
fill 287 158 470 287 159 470 minecraft:polished_blackstone_bricks
fill 287 158 472 287 159 472 minecraft:polished_blackstone_bricks
fill 287 158 474 287 159 474 minecraft:polished_blackstone_bricks
fill 288 158 465 288 159 465 minecraft:polished_blackstone_bricks
fill 288 158 467 288 159 467 minecraft:polished_blackstone_bricks
fill 288 158 469 288 159 469 minecraft:polished_blackstone_bricks
fill 288 158 471 288 159 471 minecraft:polished_blackstone_bricks
fill 288 158 473 288 159 473 minecraft:polished_blackstone_bricks
fill 288 158 475 288 159 475 minecraft:polished_blackstone_bricks
fill 289 158 466 289 159 466 minecraft:polished_blackstone_bricks
fill 289 158 468 289 159 468 minecraft:polished_blackstone_bricks
fill 289 158 470 289 159 470 minecraft:polished_blackstone_bricks
fill 289 158 472 289 159 472 minecraft:polished_blackstone_bricks
fill 289 158 474 289 159 474 minecraft:polished_blackstone_bricks
fill 290 158 465 290 159 465 minecraft:polished_blackstone_bricks
fill 290 158 467 290 159 467 minecraft:polished_blackstone_bricks
fill 290 158 469 290 159 469 minecraft:polished_blackstone_bricks
fill 290 158 471 290 159 471 minecraft:polished_blackstone_bricks
fill 290 158 473 290 159 473 minecraft:polished_blackstone_bricks
fill 290 158 475 290 159 475 minecraft:polished_blackstone_bricks
fill 313 158 480 313 160 480 minecraft:polished_blackstone_bricks
fill 313 158 482 313 160 482 minecraft:polished_blackstone_bricks
fill 313 158 484 313 160 484 minecraft:polished_blackstone_bricks
fill 313 158 486 313 160 486 minecraft:polished_blackstone_bricks
fill 313 158 488 313 160 488 minecraft:polished_blackstone_bricks
fill 313 158 490 313 160 490 minecraft:polished_blackstone_bricks
fill 313 158 492 313 160 492 minecraft:polished_blackstone_bricks
fill 314 158 481 314 160 481 minecraft:polished_blackstone_bricks
fill 314 158 483 314 160 483 minecraft:polished_blackstone_bricks
fill 314 158 485 314 160 485 minecraft:polished_blackstone_bricks
fill 314 158 487 314 160 487 minecraft:polished_blackstone_bricks
fill 314 158 489 314 160 489 minecraft:polished_blackstone_bricks
fill 314 158 491 314 160 491 minecraft:polished_blackstone_bricks
fill 315 158 480 315 160 480 minecraft:polished_blackstone_bricks
fill 315 158 482 315 160 482 minecraft:polished_blackstone_bricks
fill 315 158 484 315 160 484 minecraft:polished_blackstone_bricks
fill 315 158 486 315 160 486 minecraft:polished_blackstone_bricks
fill 315 158 488 315 160 488 minecraft:polished_blackstone_bricks
fill 315 158 490 315 160 490 minecraft:polished_blackstone_bricks
fill 315 158 492 315 160 492 minecraft:polished_blackstone_bricks
fill 316 158 481 316 160 481 minecraft:polished_blackstone_bricks
fill 316 158 483 316 160 483 minecraft:polished_blackstone_bricks
fill 316 158 485 316 160 485 minecraft:polished_blackstone_bricks
fill 316 158 487 316 160 487 minecraft:polished_blackstone_bricks
fill 316 158 489 316 160 489 minecraft:polished_blackstone_bricks
fill 316 158 491 316 160 491 minecraft:polished_blackstone_bricks
fill 317 158 480 317 160 480 minecraft:polished_blackstone_bricks
fill 317 158 482 317 160 482 minecraft:polished_blackstone_bricks
fill 317 158 484 317 160 484 minecraft:polished_blackstone_bricks
fill 317 158 486 317 160 486 minecraft:polished_blackstone_bricks
fill 317 158 488 317 160 488 minecraft:polished_blackstone_bricks
fill 317 158 490 317 160 490 minecraft:polished_blackstone_bricks
fill 317 158 492 317 160 492 minecraft:polished_blackstone_bricks
fill 318 158 481 318 160 481 minecraft:polished_blackstone_bricks
fill 318 158 483 318 160 483 minecraft:polished_blackstone_bricks
fill 318 158 485 318 160 485 minecraft:polished_blackstone_bricks
fill 318 158 487 318 160 487 minecraft:polished_blackstone_bricks
fill 318 158 489 318 160 489 minecraft:polished_blackstone_bricks
fill 318 158 491 318 160 491 minecraft:polished_blackstone_bricks
fill 319 158 480 319 160 480 minecraft:polished_blackstone_bricks
fill 319 158 482 319 160 482 minecraft:polished_blackstone_bricks
fill 319 158 484 319 160 484 minecraft:polished_blackstone_bricks
fill 319 158 486 319 160 486 minecraft:polished_blackstone_bricks
fill 319 158 488 319 160 488 minecraft:polished_blackstone_bricks
fill 319 158 490 319 160 490 minecraft:polished_blackstone_bricks
fill 319 158 492 319 160 492 minecraft:polished_blackstone_bricks
fill 320 158 481 320 160 481 minecraft:polished_blackstone_bricks
fill 320 158 483 320 160 483 minecraft:polished_blackstone_bricks
fill 320 158 485 320 160 485 minecraft:polished_blackstone_bricks
fill 320 158 487 320 160 487 minecraft:polished_blackstone_bricks
fill 320 158 489 320 160 489 minecraft:polished_blackstone_bricks
fill 320 158 491 320 160 491 minecraft:polished_blackstone_bricks
fill 321 158 469 321 167 470 minecraft:red_wool
fill 321 158 472 321 167 473 minecraft:red_wool
fill 321 158 480 321 160 480 minecraft:polished_blackstone_bricks
fill 321 158 482 321 160 482 minecraft:polished_blackstone_bricks
fill 321 158 484 321 160 484 minecraft:polished_blackstone_bricks
fill 321 158 486 321 160 486 minecraft:polished_blackstone_bricks
fill 321 158 488 321 160 488 minecraft:polished_blackstone_bricks
fill 321 158 490 321 160 490 minecraft:polished_blackstone_bricks
fill 321 158 492 321 160 492 minecraft:polished_blackstone_bricks
fill 322 158 481 322 160 481 minecraft:polished_blackstone_bricks
fill 322 158 483 322 160 483 minecraft:polished_blackstone_bricks
fill 322 158 485 322 165 485 minecraft:polished_blackstone_bricks
fill 322 158 487 322 165 487 minecraft:polished_blackstone_bricks
fill 322 158 489 322 160 489 minecraft:polished_blackstone_bricks
fill 322 158 491 322 160 491 minecraft:polished_blackstone_bricks
fill 323 158 480 323 160 480 minecraft:polished_blackstone_bricks
fill 323 158 482 323 160 482 minecraft:polished_blackstone_bricks
fill 323 158 484 323 188 484 minecraft:polished_blackstone_bricks
fill 323 158 486 323 188 486 minecraft:polished_blackstone_bricks
fill 323 158 488 323 160 488 minecraft:polished_blackstone_bricks
fill 323 158 490 323 160 490 minecraft:polished_blackstone_bricks
fill 323 158 492 323 160 492 minecraft:polished_blackstone_bricks
setblock 285 159 482 minecraft:light[level=14]
setblock 285 159 490 minecraft:light[level=14]
setblock 285 159 498 minecraft:light[level=14]
setblock 293 159 466 minecraft:light[level=14]
setblock 293 159 474 minecraft:light[level=14]
setblock 293 159 482 minecraft:light[level=14]
setblock 293 159 490 minecraft:light[level=14]
setblock 293 159 498 minecraft:light[level=14]
setblock 301 159 466 minecraft:light[level=14]
setblock 301 159 474 minecraft:light[level=14]
setblock 301 159 482 minecraft:light[level=14]
setblock 301 159 490 minecraft:light[level=14]
setblock 301 159 498 minecraft:light[level=14]
setblock 309 159 466 minecraft:light[level=14]
setblock 309 159 474 minecraft:light[level=14]
setblock 309 159 482 minecraft:light[level=14]
setblock 309 159 490 minecraft:light[level=14]
setblock 309 159 498 minecraft:light[level=14]
setblock 317 159 466 minecraft:light[level=14]
setblock 317 159 474 minecraft:light[level=14]
setblock 317 159 498 minecraft:light[level=14]
setblock 283 160 466 minecraft:shroomlight
setblock 283 160 468 minecraft:shroomlight
setblock 283 160 470 minecraft:shroomlight
setblock 283 160 472 minecraft:shroomlight
setblock 283 160 474 minecraft:shroomlight
setblock 284 160 465 minecraft:shroomlight
setblock 284 160 467 minecraft:shroomlight
setblock 284 160 469 minecraft:shroomlight
setblock 284 160 471 minecraft:shroomlight
setblock 284 160 473 minecraft:shroomlight
setblock 284 160 475 minecraft:shroomlight
fill 284 160 485 284 165 487 minecraft:polished_blackstone_bricks
fill 284 160 497 284 165 499 minecraft:polished_blackstone_bricks
setblock 285 160 466 minecraft:shroomlight
setblock 285 160 468 minecraft:shroomlight
setblock 285 160 470 minecraft:shroomlight
setblock 285 160 472 minecraft:shroomlight
setblock 285 160 474 minecraft:shroomlight
setblock 286 160 465 minecraft:shroomlight
setblock 286 160 467 minecraft:shroomlight
setblock 286 160 469 minecraft:shroomlight
setblock 286 160 471 minecraft:shroomlight
setblock 286 160 473 minecraft:shroomlight
setblock 286 160 475 minecraft:shroomlight
setblock 287 160 466 minecraft:shroomlight
setblock 287 160 468 minecraft:shroomlight
setblock 287 160 470 minecraft:shroomlight
setblock 287 160 472 minecraft:shroomlight
setblock 287 160 474 minecraft:shroomlight
setblock 288 160 465 minecraft:shroomlight
setblock 288 160 467 minecraft:shroomlight
setblock 288 160 469 minecraft:shroomlight
setblock 288 160 471 minecraft:shroomlight
setblock 288 160 473 minecraft:shroomlight
setblock 288 160 475 minecraft:shroomlight
setblock 289 160 466 minecraft:shroomlight
setblock 289 160 468 minecraft:shroomlight
setblock 289 160 470 minecraft:shroomlight
setblock 289 160 472 minecraft:shroomlight
setblock 289 160 474 minecraft:shroomlight
setblock 290 160 465 minecraft:shroomlight
setblock 290 160 467 minecraft:shroomlight
setblock 290 160 469 minecraft:shroomlight
setblock 290 160 471 minecraft:shroomlight
setblock 290 160 473 minecraft:shroomlight
setblock 290 160 475 minecraft:shroomlight
fill 290 160 503 292 165 503 minecraft:polished_blackstone_bricks
fill 294 160 465 296 165 465 minecraft:polished_blackstone_bricks
fill 302 160 503 304 165 503 minecraft:polished_blackstone_bricks
fill 306 160 465 308 165 465 minecraft:polished_blackstone_bricks
fill 314 160 503 316 165 503 minecraft:polished_blackstone_bricks
fill 318 160 465 320 165 465 minecraft:polished_blackstone_bricks
fill 322 160 473 322 165 475 minecraft:polished_blackstone_bricks
fill 322 160 497 322 165 499 minecraft:polished_blackstone_bricks
fill 283 161 466 283 162 466 minecraft:polished_blackstone_bricks
fill 283 161 468 283 162 468 minecraft:polished_blackstone_bricks
fill 283 161 470 283 162 470 minecraft:polished_blackstone_bricks
fill 283 161 472 283 162 472 minecraft:polished_blackstone_bricks
fill 283 161 474 283 162 474 minecraft:polished_blackstone_bricks
fill 284 161 465 284 162 465 minecraft:polished_blackstone_bricks
fill 284 161 467 284 162 467 minecraft:polished_blackstone_bricks
fill 284 161 469 284 162 469 minecraft:polished_blackstone_bricks
fill 284 161 471 284 162 471 minecraft:polished_blackstone_bricks
fill 284 161 473 284 162 473 minecraft:polished_blackstone_bricks
fill 284 161 475 284 162 475 minecraft:polished_blackstone_bricks
fill 285 161 466 285 162 466 minecraft:polished_blackstone_bricks
fill 285 161 468 285 162 468 minecraft:polished_blackstone_bricks
fill 285 161 470 285 162 470 minecraft:polished_blackstone_bricks
fill 285 161 472 285 162 472 minecraft:polished_blackstone_bricks
fill 285 161 474 285 162 474 minecraft:polished_blackstone_bricks
fill 286 161 465 286 162 465 minecraft:polished_blackstone_bricks
fill 286 161 467 286 162 467 minecraft:polished_blackstone_bricks
fill 286 161 469 286 162 469 minecraft:polished_blackstone_bricks
fill 286 161 471 286 162 471 minecraft:polished_blackstone_bricks
fill 286 161 473 286 162 473 minecraft:polished_blackstone_bricks
fill 286 161 475 286 162 475 minecraft:polished_blackstone_bricks
fill 287 161 466 287 162 466 minecraft:polished_blackstone_bricks
fill 287 161 468 287 162 468 minecraft:polished_blackstone_bricks
fill 287 161 470 287 162 470 minecraft:polished_blackstone_bricks
fill 287 161 472 287 162 472 minecraft:polished_blackstone_bricks
fill 287 161 474 287 162 474 minecraft:polished_blackstone_bricks
fill 288 161 465 288 162 465 minecraft:polished_blackstone_bricks
fill 288 161 467 288 162 467 minecraft:polished_blackstone_bricks
fill 288 161 469 288 162 469 minecraft:polished_blackstone_bricks
fill 288 161 471 288 162 471 minecraft:polished_blackstone_bricks
fill 288 161 473 288 162 473 minecraft:polished_blackstone_bricks
fill 288 161 475 288 162 475 minecraft:polished_blackstone_bricks
fill 289 161 466 289 162 466 minecraft:polished_blackstone_bricks
fill 289 161 468 289 162 468 minecraft:polished_blackstone_bricks
fill 289 161 470 289 162 470 minecraft:polished_blackstone_bricks
fill 289 161 472 289 162 472 minecraft:polished_blackstone_bricks
fill 289 161 474 289 162 474 minecraft:polished_blackstone_bricks
fill 290 161 465 290 162 465 minecraft:polished_blackstone_bricks
fill 290 161 467 290 162 467 minecraft:polished_blackstone_bricks
fill 290 161 469 290 162 469 minecraft:polished_blackstone_bricks
fill 290 161 471 290 162 471 minecraft:polished_blackstone_bricks
fill 290 161 473 290 162 473 minecraft:polished_blackstone_bricks
fill 290 161 475 290 162 475 minecraft:polished_blackstone_bricks
fill 314 161 481 321 161 491 minecraft:gold_block
fill 322 161 481 322 161 484 minecraft:gold_block
fill 322 161 488 322 161 491 minecraft:gold_block
fill 302 162 497 306 163 501 minecraft:nether_bricks
setblock 304 162 502 minecraft:nether_bricks
fill 315 162 482 321 162 490 minecraft:gold_block
setblock 283 163 466 minecraft:shroomlight
setblock 283 163 468 minecraft:shroomlight
setblock 283 163 470 minecraft:shroomlight
setblock 283 163 472 minecraft:shroomlight
setblock 283 163 474 minecraft:shroomlight
setblock 284 163 465 minecraft:shroomlight
setblock 284 163 467 minecraft:shroomlight
setblock 284 163 469 minecraft:shroomlight
setblock 284 163 471 minecraft:shroomlight
setblock 284 163 473 minecraft:shroomlight
setblock 284 163 475 minecraft:shroomlight
setblock 285 163 466 minecraft:shroomlight
setblock 285 163 468 minecraft:shroomlight
setblock 285 163 470 minecraft:shroomlight
setblock 285 163 472 minecraft:shroomlight
setblock 285 163 474 minecraft:shroomlight
setblock 286 163 465 minecraft:shroomlight
setblock 286 163 467 minecraft:shroomlight
setblock 286 163 469 minecraft:shroomlight
setblock 286 163 471 minecraft:shroomlight
setblock 286 163 473 minecraft:shroomlight
setblock 286 163 475 minecraft:shroomlight
setblock 287 163 466 minecraft:shroomlight
setblock 287 163 468 minecraft:shroomlight
setblock 287 163 470 minecraft:shroomlight
setblock 287 163 472 minecraft:shroomlight
setblock 287 163 474 minecraft:shroomlight
setblock 288 163 465 minecraft:shroomlight
setblock 288 163 467 minecraft:shroomlight
setblock 288 163 469 minecraft:shroomlight
setblock 288 163 471 minecraft:shroomlight
setblock 288 163 473 minecraft:shroomlight
setblock 288 163 475 minecraft:shroomlight
setblock 289 163 466 minecraft:shroomlight
setblock 289 163 468 minecraft:shroomlight
setblock 289 163 470 minecraft:shroomlight
setblock 289 163 472 minecraft:shroomlight
setblock 289 163 474 minecraft:shroomlight
setblock 290 163 465 minecraft:shroomlight
setblock 290 163 467 minecraft:shroomlight
setblock 290 163 469 minecraft:shroomlight
setblock 290 163 471 minecraft:shroomlight
setblock 290 163 473 minecraft:shroomlight
setblock 290 163 475 minecraft:shroomlight
fill 316 163 483 320 163 489 minecraft:gold_block
fill 283 164 466 283 165 466 minecraft:polished_blackstone_bricks
setblock 283 164 468 minecraft:polished_blackstone_bricks
setblock 283 164 470 minecraft:polished_blackstone_bricks
setblock 283 164 472 minecraft:polished_blackstone_bricks
fill 283 164 474 283 188 474 minecraft:polished_blackstone_bricks
fill 284 164 465 284 165 465 minecraft:polished_blackstone_bricks
fill 284 164 467 284 165 467 minecraft:polished_blackstone_bricks
fill 284 164 469 284 165 469 minecraft:polished_blackstone_bricks
fill 284 164 471 284 165 471 minecraft:polished_blackstone_bricks
fill 284 164 473 284 165 473 minecraft:polished_blackstone_bricks
fill 284 164 475 284 165 475 minecraft:polished_blackstone_bricks
fill 285 164 466 285 165 466 minecraft:polished_blackstone_bricks
fill 285 164 468 285 165 468 minecraft:polished_blackstone_bricks
fill 285 164 470 285 165 470 minecraft:polished_blackstone_bricks
fill 285 164 472 285 165 472 minecraft:polished_blackstone_bricks
fill 285 164 474 285 165 474 minecraft:polished_blackstone_bricks
fill 286 164 465 286 165 465 minecraft:polished_blackstone_bricks
fill 286 164 467 286 165 467 minecraft:polished_blackstone_bricks
fill 286 164 469 286 165 469 minecraft:polished_blackstone_bricks
fill 286 164 471 286 165 471 minecraft:polished_blackstone_bricks
fill 286 164 473 286 165 473 minecraft:polished_blackstone_bricks
fill 286 164 475 286 165 475 minecraft:polished_blackstone_bricks
fill 287 164 466 287 165 466 minecraft:polished_blackstone_bricks
fill 287 164 468 287 165 468 minecraft:polished_blackstone_bricks
fill 287 164 470 287 165 470 minecraft:polished_blackstone_bricks
fill 287 164 472 287 165 472 minecraft:polished_blackstone_bricks
fill 287 164 474 287 165 474 minecraft:polished_blackstone_bricks
fill 288 164 465 288 165 465 minecraft:polished_blackstone_bricks
fill 288 164 467 288 165 467 minecraft:polished_blackstone_bricks
fill 288 164 469 288 165 469 minecraft:polished_blackstone_bricks
fill 288 164 471 288 165 471 minecraft:polished_blackstone_bricks
fill 288 164 473 288 165 473 minecraft:polished_blackstone_bricks
fill 288 164 475 288 165 475 minecraft:polished_blackstone_bricks
fill 289 164 466 289 165 466 minecraft:polished_blackstone_bricks
fill 289 164 468 289 165 468 minecraft:polished_blackstone_bricks
fill 289 164 470 289 165 470 minecraft:polished_blackstone_bricks
fill 289 164 472 289 165 472 minecraft:polished_blackstone_bricks
fill 289 164 474 289 165 474 minecraft:polished_blackstone_bricks
fill 290 164 465 290 165 465 minecraft:polished_blackstone_bricks
fill 290 164 467 290 165 467 minecraft:polished_blackstone_bricks
fill 290 164 469 290 165 469 minecraft:polished_blackstone_bricks
fill 290 164 471 290 165 471 minecraft:polished_blackstone_bricks
fill 290 164 473 290 165 473 minecraft:polished_blackstone_bricks
fill 290 164 475 290 165 475 minecraft:polished_blackstone_bricks
fill 304 164 499 304 169 499 minecraft:bone_block
fill 317 164 484 319 164 488 minecraft:gold_block
fill 283 165 467 283 165 472 minecraft:nether_bricks
fill 283 165 479 283 165 484 minecraft:nether_bricks
fill 283 165 491 283 165 496 minecraft:nether_bricks
fill 283 165 503 283 165 504 minecraft:nether_bricks
fill 284 165 504 287 165 504 minecraft:nether_bricks
fill 287 165 464 292 165 464 minecraft:nether_bricks
fill 294 165 504 299 165 504 minecraft:nether_bricks
fill 299 165 464 304 165 464 minecraft:nether_bricks
fill 302 165 498 303 168 500 minecraft:bone_block
fill 303 165 497 305 168 497 minecraft:bone_block
fill 303 165 501 305 168 501 minecraft:bone_block
fill 304 165 498 306 168 498 minecraft:bone_block
fill 304 165 500 306 168 500 minecraft:bone_block
fill 305 165 499 306 168 499 minecraft:bone_block
fill 306 165 504 311 165 504 minecraft:nether_bricks
fill 311 165 464 316 165 464 minecraft:nether_bricks
fill 318 165 504 323 165 504 minecraft:nether_bricks
fill 323 165 464 323 165 469 minecraft:nether_bricks
fill 323 165 476 323 165 481 minecraft:nether_bricks
fill 323 165 488 323 165 493 minecraft:nether_bricks
fill 323 165 500 323 165 503 minecraft:nether_bricks
fill 282 166 469 282 171 472 minecraft:shroomlight
fill 282 166 481 282 171 484 minecraft:shroomlight
fill 282 166 493 282 171 496 minecraft:shroomlight
fill 282 166 505 285 171 505 minecraft:shroomlight
fill 283 166 464 283 188 464 minecraft:polished_blackstone_bricks
fill 284 166 466 289 166 474 minecraft:gold_block
fill 289 166 463 292 171 463 minecraft:shroomlight
fill 294 166 505 297 171 505 minecraft:shroomlight
fill 301 166 463 304 171 463 minecraft:shroomlight
fill 306 166 505 309 171 505 minecraft:shroomlight
fill 313 166 463 316 171 463 minecraft:shroomlight
fill 318 166 505 321 171 505 minecraft:shroomlight
fill 324 166 464 324 171 467 minecraft:shroomlight
fill 324 166 476 324 171 479 minecraft:shroomlight
fill 324 166 488 324 171 491 minecraft:shroomlight
fill 324 166 500 324 171 503 minecraft:shroomlight
setblock 285 167 466 minecraft:light[level=14]
fill 285 167 467 288 167 473 minecraft:gold_block
setblock 285 167 474 minecraft:light[level=14]
setblock 285 167 482 minecraft:light[level=14]
setblock 285 167 490 minecraft:light[level=14]
setblock 285 167 498 minecraft:light[level=14]
setblock 293 167 466 minecraft:light[level=14]
setblock 293 167 474 minecraft:light[level=14]
setblock 293 167 482 minecraft:light[level=14]
setblock 293 167 490 minecraft:light[level=14]
setblock 293 167 498 minecraft:light[level=14]
setblock 301 167 466 minecraft:light[level=14]
setblock 301 167 474 minecraft:light[level=14]
setblock 301 167 482 minecraft:light[level=14]
setblock 301 167 490 minecraft:light[level=14]
setblock 301 167 498 minecraft:light[level=14]
setblock 309 167 466 minecraft:light[level=14]
setblock 309 167 474 minecraft:light[level=14]
setblock 309 167 482 minecraft:light[level=14]
setblock 309 167 490 minecraft:light[level=14]
setblock 309 167 498 minecraft:light[level=14]
setblock 317 167 466 minecraft:light[level=14]
setblock 317 167 474 minecraft:light[level=14]
setblock 317 167 482 minecraft:light[level=14]
setblock 317 167 490 minecraft:light[level=14]
setblock 317 167 498 minecraft:light[level=14]
fill 286 168 468 287 168 472 minecraft:gold_block
fill 321 168 468 321 169 474 minecraft:gilded_blackstone
fill 286 169 469 287 169 471 minecraft:gold_block
fill 282 172 469 282 185 469 minecraft:nether_bricks
fill 282 172 470 282 172 471 minecraft:shroomlight
fill 282 172 472 282 185 472 minecraft:nether_bricks
fill 282 172 481 282 185 481 minecraft:nether_bricks
fill 282 172 482 282 172 483 minecraft:shroomlight
fill 282 172 484 282 185 484 minecraft:nether_bricks
fill 282 172 493 282 185 493 minecraft:nether_bricks
fill 282 172 494 282 172 495 minecraft:shroomlight
fill 282 172 496 282 185 496 minecraft:nether_bricks
fill 282 172 505 282 185 505 minecraft:nether_bricks
fill 283 172 505 284 172 505 minecraft:shroomlight
fill 285 172 505 285 185 505 minecraft:nether_bricks
fill 289 172 463 289 185 463 minecraft:nether_bricks
fill 290 172 463 291 172 463 minecraft:shroomlight
fill 292 172 463 292 185 463 minecraft:nether_bricks
fill 294 172 505 294 185 505 minecraft:nether_bricks
fill 295 172 505 296 172 505 minecraft:shroomlight
fill 297 172 505 297 185 505 minecraft:nether_bricks
fill 301 172 463 301 185 463 minecraft:nether_bricks
fill 302 172 463 303 172 463 minecraft:shroomlight
fill 304 172 463 304 185 463 minecraft:nether_bricks
fill 306 172 505 306 185 505 minecraft:nether_bricks
fill 307 172 505 308 172 505 minecraft:shroomlight
fill 309 172 505 309 185 505 minecraft:nether_bricks
fill 313 172 463 313 185 463 minecraft:nether_bricks
fill 314 172 463 315 172 463 minecraft:shroomlight
fill 316 172 463 316 185 463 minecraft:nether_bricks
fill 318 172 505 318 185 505 minecraft:nether_bricks
fill 319 172 505 320 172 505 minecraft:shroomlight
fill 321 172 505 321 185 505 minecraft:nether_bricks
fill 324 172 464 324 185 464 minecraft:nether_bricks
fill 324 172 465 324 172 466 minecraft:shroomlight
fill 324 172 467 324 185 467 minecraft:nether_bricks
fill 324 172 476 324 185 476 minecraft:nether_bricks
fill 324 172 477 324 172 478 minecraft:shroomlight
fill 324 172 479 324 185 479 minecraft:nether_bricks
fill 324 172 488 324 185 488 minecraft:nether_bricks
fill 324 172 489 324 172 490 minecraft:shroomlight
fill 324 172 491 324 185 491 minecraft:nether_bricks
fill 324 172 500 324 185 500 minecraft:nether_bricks
fill 324 172 501 324 172 502 minecraft:shroomlight
fill 324 172 503 324 185 503 minecraft:nether_bricks
fill 282 173 470 282 185 471 minecraft:nether_bricks
fill 282 173 482 282 185 483 minecraft:nether_bricks
fill 282 173 494 282 185 495 minecraft:nether_bricks
fill 283 173 505 284 185 505 minecraft:nether_bricks
fill 290 173 463 291 185 463 minecraft:nether_bricks
fill 295 173 505 296 185 505 minecraft:nether_bricks
fill 302 173 463 303 185 463 minecraft:nether_bricks
fill 307 173 505 308 185 505 minecraft:nether_bricks
fill 314 173 463 315 185 463 minecraft:nether_bricks
fill 319 173 505 320 185 505 minecraft:nether_bricks
fill 324 173 465 324 185 466 minecraft:nether_bricks
fill 324 173 477 324 185 478 minecraft:nether_bricks
fill 324 173 489 324 185 490 minecraft:nether_bricks
fill 324 173 501 324 185 502 minecraft:nether_bricks
setblock 285 175 466 minecraft:light[level=14]
setblock 285 175 474 minecraft:light[level=14]
setblock 285 175 482 minecraft:light[level=14]
setblock 285 175 490 minecraft:light[level=14]
setblock 285 175 498 minecraft:light[level=14]
setblock 293 175 466 minecraft:light[level=14]
setblock 293 175 474 minecraft:light[level=14]
setblock 293 175 482 minecraft:light[level=14]
setblock 293 175 490 minecraft:light[level=14]
setblock 293 175 498 minecraft:light[level=14]
setblock 301 175 466 minecraft:light[level=14]
setblock 301 175 474 minecraft:light[level=14]
setblock 301 175 482 minecraft:light[level=14]
setblock 301 175 490 minecraft:light[level=14]
setblock 301 175 498 minecraft:light[level=14]
setblock 309 175 466 minecraft:light[level=14]
setblock 309 175 474 minecraft:light[level=14]
setblock 309 175 482 minecraft:light[level=14]
setblock 309 175 490 minecraft:light[level=14]
setblock 309 175 498 minecraft:light[level=14]
setblock 317 175 466 minecraft:light[level=14]
setblock 317 175 474 minecraft:light[level=14]
setblock 317 175 482 minecraft:light[level=14]
setblock 317 175 490 minecraft:light[level=14]
setblock 317 175 498 minecraft:light[level=14]
fill 305 178 467 305 186 467 minecraft:gilded_blackstone
fill 283 180 477 289 180 477 minecraft:nether_bricks
fill 284 180 473 284 185 475 minecraft:polished_blackstone_bricks
fill 284 180 485 284 185 487 minecraft:polished_blackstone_bricks
fill 284 180 497 284 185 499 minecraft:polished_blackstone_bricks
fill 285 180 475 289 181 476 minecraft:nether_bricks
fill 285 180 478 289 181 479 minecraft:nether_bricks
fill 290 180 503 292 185 503 minecraft:polished_blackstone_bricks
fill 294 180 465 296 185 465 minecraft:polished_blackstone_bricks
fill 302 180 503 304 185 503 minecraft:polished_blackstone_bricks
fill 306 180 465 308 185 465 minecraft:polished_blackstone_bricks
fill 314 180 503 316 185 503 minecraft:polished_blackstone_bricks
fill 318 180 465 320 185 465 minecraft:polished_blackstone_bricks
fill 322 180 473 322 185 475 minecraft:polished_blackstone_bricks
fill 322 180 485 322 185 487 minecraft:polished_blackstone_bricks
fill 322 180 497 322 185 499 minecraft:polished_blackstone_bricks
fill 285 181 477 289 181 477 minecraft:nether_bricks
fill 287 182 477 287 187 477 minecraft:bone_block
setblock 285 183 466 minecraft:light[level=14]
setblock 285 183 474 minecraft:light[level=14]
fill 285 183 476 286 186 478 minecraft:bone_block
setblock 285 183 482 minecraft:light[level=14]
setblock 285 183 490 minecraft:light[level=14]
setblock 285 183 498 minecraft:light[level=14]
fill 286 183 475 288 186 475 minecraft:bone_block
fill 286 183 479 288 186 479 minecraft:bone_block
fill 287 183 464 289 184 464 minecraft:polished_blackstone_bricks
fill 287 183 476 289 186 476 minecraft:bone_block
fill 287 183 478 289 186 478 minecraft:bone_block
fill 287 183 503 288 184 504 minecraft:polished_blackstone_bricks
fill 288 183 477 289 186 477 minecraft:bone_block
fill 289 183 503 289 184 503 minecraft:polished_blackstone_bricks
setblock 293 183 466 minecraft:light[level=14]
setblock 293 183 474 minecraft:light[level=14]
setblock 293 183 482 minecraft:light[level=14]
setblock 293 183 490 minecraft:light[level=14]
setblock 293 183 498 minecraft:light[level=14]
setblock 301 183 466 minecraft:light[level=14]
setblock 301 183 474 minecraft:light[level=14]
setblock 301 183 482 minecraft:light[level=14]
setblock 301 183 490 minecraft:light[level=14]
setblock 301 183 498 minecraft:light[level=14]
setblock 309 183 466 minecraft:light[level=14]
setblock 309 183 474 minecraft:light[level=14]
setblock 309 183 482 minecraft:light[level=14]
setblock 309 183 490 minecraft:light[level=14]
setblock 309 183 498 minecraft:light[level=14]
setblock 317 183 466 minecraft:light[level=14]
setblock 317 183 474 minecraft:light[level=14]
setblock 317 183 482 minecraft:light[level=14]
setblock 317 183 490 minecraft:light[level=14]
setblock 317 183 498 minecraft:light[level=14]
fill 287 184 465 289 185 465 minecraft:polished_blackstone_bricks
fill 287 184 502 289 185 502 minecraft:polished_blackstone_bricks
fill 288 184 466 288 187 466 minecraft:polished_blackstone_bricks
fill 288 184 501 288 187 501 minecraft:polished_blackstone_bricks
fill 283 185 467 283 185 472 minecraft:nether_bricks
fill 283 185 479 283 185 484 minecraft:nether_bricks
fill 283 185 491 283 185 496 minecraft:nether_bricks
fill 283 185 503 283 185 504 minecraft:nether_bricks
fill 284 185 504 287 185 504 minecraft:nether_bricks
fill 287 185 464 292 185 464 minecraft:nether_bricks
fill 287 185 466 287 186 466 minecraft:polished_blackstone_bricks
fill 287 185 501 287 186 501 minecraft:polished_blackstone_bricks
fill 288 185 467 288 187 467 minecraft:polished_blackstone_bricks
fill 288 185 500 288 187 500 minecraft:polished_blackstone_bricks
setblock 288 185 503 minecraft:polished_blackstone_bricks
setblock 288 185 504 minecraft:gold_block
fill 289 185 466 289 186 466 minecraft:polished_blackstone_bricks
fill 289 185 501 289 186 501 minecraft:polished_blackstone_bricks
fill 294 185 504 299 185 504 minecraft:nether_bricks
fill 299 185 464 304 185 464 minecraft:nether_bricks
fill 306 185 504 311 185 504 minecraft:nether_bricks
fill 311 185 464 316 185 464 minecraft:nether_bricks
fill 318 185 504 323 185 504 minecraft:nether_bricks
fill 323 185 464 323 185 469 minecraft:nether_bricks
fill 323 185 476 323 185 481 minecraft:nether_bricks
fill 323 185 488 323 185 493 minecraft:nether_bricks
fill 323 185 500 323 185 503 minecraft:nether_bricks
fill 282 186 469 282 188 472 minecraft:shroomlight
fill 282 186 481 282 188 484 minecraft:shroomlight
fill 282 186 493 282 188 496 minecraft:shroomlight
fill 282 186 505 285 188 505 minecraft:shroomlight
fill 287 186 467 287 187 468 minecraft:polished_blackstone_bricks
fill 287 186 499 287 187 500 minecraft:polished_blackstone_bricks
setblock 288 186 464 minecraft:gold_block
setblock 288 186 465 minecraft:polished_blackstone_bricks
fill 288 186 468 289 187 468 minecraft:polished_blackstone_bricks
fill 288 186 499 289 187 499 minecraft:polished_blackstone_bricks
setblock 288 186 502 minecraft:polished_blackstone_bricks
setblock 288 186 503 minecraft:gold_block
fill 289 186 463 292 188 463 minecraft:shroomlight
fill 289 186 467 289 187 467 minecraft:polished_blackstone_bricks
fill 289 186 500 289 187 500 minecraft:polished_blackstone_bricks
fill 294 186 505 297 188 505 minecraft:shroomlight
fill 301 186 463 304 188 463 minecraft:shroomlight
fill 306 186 505 309 188 505 minecraft:shroomlight
fill 313 186 463 316 188 463 minecraft:shroomlight
fill 318 186 505 321 188 505 minecraft:shroomlight
fill 324 186 464 324 188 467 minecraft:shroomlight
fill 324 186 476 324 188 479 minecraft:shroomlight
fill 324 186 488 324 188 491 minecraft:shroomlight
fill 324 186 500 324 188 503 minecraft:shroomlight
fill 287 187 469 289 188 469 minecraft:polished_blackstone_bricks
fill 287 187 498 289 188 498 minecraft:polished_blackstone_bricks
setblock 288 187 465 minecraft:gold_block
fill 288 187 470 288 188 470 minecraft:polished_blackstone_bricks
fill 288 187 497 288 188 497 minecraft:polished_blackstone_bricks
setblock 288 187 502 minecraft:gold_block
setblock 287 188 470 minecraft:polished_blackstone_bricks
setblock 287 188 497 minecraft:polished_blackstone_bricks
setblock 288 188 467 minecraft:gold_block
setblock 288 188 468 minecraft:polished_blackstone_bricks
setblock 288 188 471 minecraft:polished_blackstone_bricks
setblock 288 188 496 minecraft:polished_blackstone_bricks
setblock 288 188 499 minecraft:polished_blackstone_bricks
setblock 288 188 500 minecraft:gold_block
setblock 289 188 470 minecraft:polished_blackstone_bricks
setblock 289 188 497 minecraft:polished_blackstone_bricks
fill 282 189 469 282 205 472 minecraft:nether_bricks
fill 282 189 481 282 205 484 minecraft:nether_bricks
fill 282 189 493 282 205 496 minecraft:nether_bricks
fill 282 189 505 285 205 505 minecraft:nether_bricks
fill 289 189 463 292 205 463 minecraft:nether_bricks
fill 294 189 505 297 205 505 minecraft:nether_bricks
fill 301 189 463 304 205 463 minecraft:nether_bricks
fill 306 189 505 309 205 505 minecraft:nether_bricks
fill 313 189 463 316 205 463 minecraft:nether_bricks
fill 318 189 505 321 205 505 minecraft:nether_bricks
fill 324 189 464 324 205 467 minecraft:nether_bricks
fill 324 189 476 324 205 479 minecraft:nether_bricks
fill 324 189 488 324 205 491 minecraft:nether_bricks
fill 324 189 500 324 205 503 minecraft:nether_bricks
setblock 285 191 466 minecraft:light[level=14]
setblock 285 191 474 minecraft:light[level=14]
setblock 285 191 482 minecraft:light[level=14]
setblock 285 191 490 minecraft:light[level=14]
setblock 285 191 498 minecraft:light[level=14]
setblock 293 191 466 minecraft:light[level=14]
setblock 293 191 474 minecraft:light[level=14]
setblock 293 191 482 minecraft:light[level=14]
setblock 293 191 490 minecraft:light[level=14]
setblock 293 191 498 minecraft:light[level=14]
setblock 301 191 466 minecraft:light[level=14]
setblock 301 191 474 minecraft:light[level=14]
setblock 301 191 482 minecraft:light[level=14]
setblock 301 191 490 minecraft:light[level=14]
setblock 301 191 498 minecraft:light[level=14]
setblock 309 191 466 minecraft:light[level=14]
setblock 309 191 474 minecraft:light[level=14]
setblock 309 191 482 minecraft:light[level=14]
setblock 309 191 490 minecraft:light[level=14]
setblock 309 191 498 minecraft:light[level=14]
setblock 317 191 466 minecraft:light[level=14]
setblock 317 191 474 minecraft:light[level=14]
setblock 317 191 482 minecraft:light[level=14]
setblock 317 191 490 minecraft:light[level=14]
setblock 317 191 498 minecraft:light[level=14]
fill 295 193 485 297 193 487 minecraft:redstone_block
fill 301 193 480 303 193 482 minecraft:redstone_block
fill 303 193 489 305 193 491 minecraft:redstone_block
fill 305 193 484 307 193 486 minecraft:redstone_block
fill 290 194 478 295 195 479 minecraft:red_concrete
fill 290 194 493 295 195 494 minecraft:red_concrete
fill 291 194 480 300 194 482 minecraft:red_concrete
fill 291 194 490 302 194 492 minecraft:red_concrete
fill 292 194 483 310 194 483 minecraft:red_concrete
fill 292 194 489 302 194 489 minecraft:red_concrete
fill 293 194 484 304 194 484 minecraft:red_concrete
fill 293 194 488 312 194 488 minecraft:red_concrete
setblock 294 194 485 minecraft:red_concrete
setblock 294 194 487 minecraft:red_concrete
fill 296 194 479 297 195 479 minecraft:red_concrete
fill 296 194 493 297 195 493 minecraft:red_concrete
fill 298 194 485 299 194 487 minecraft:red_concrete
fill 300 194 478 306 194 479 minecraft:red_concrete
fill 300 194 493 306 194 494 minecraft:red_concrete
fill 301 194 476 306 194 477 minecraft:red_concrete
fill 301 194 495 306 194 496 minecraft:red_concrete
fill 302 194 475 306 195 475 minecraft:red_concrete
fill 302 194 497 306 195 497 minecraft:red_concrete
fill 303 194 474 306 195 474 minecraft:red_concrete
fill 303 194 485 304 194 487 minecraft:red_concrete
fill 303 194 492 306 194 492 minecraft:red_concrete
fill 303 194 498 306 195 498 minecraft:red_concrete
fill 304 194 480 306 194 482 minecraft:red_concrete
fill 305 194 473 305 195 473 minecraft:red_concrete
fill 305 194 487 314 194 487 minecraft:red_concrete
fill 305 194 499 305 195 499 minecraft:red_concrete
fill 306 194 489 306 194 491 minecraft:red_concrete
fill 307 194 489 310 195 489 minecraft:red_concrete
fill 308 194 484 312 194 486 minecraft:red_concrete
fill 313 194 485 314 195 486 minecraft:red_concrete
fill 315 194 486 315 195 486 minecraft:red_concrete
fill 283 195 464 289 195 504 minecraft:nether_bricks
fill 290 195 464 300 195 477 minecraft:nether_bricks
fill 290 195 480 290 195 492 minecraft:nether_bricks
fill 290 195 495 300 195 504 minecraft:nether_bricks
fill 291 195 480 293 195 482 minecraft:red_concrete
fill 291 195 483 291 195 489 minecraft:nether_bricks
fill 291 195 490 293 195 492 minecraft:red_concrete
fill 292 195 483 293 195 483 minecraft:red_concrete
fill 292 195 484 292 195 488 minecraft:nether_bricks
fill 292 195 489 293 195 489 minecraft:red_concrete
setblock 293 195 484 minecraft:red_concrete
fill 293 195 485 293 195 487 minecraft:nether_bricks
setblock 293 195 488 minecraft:red_concrete
fill 294 195 480 299 195 480 minecraft:red_concrete
fill 294 195 481 298 195 483 minecraft:gold_block
fill 294 195 484 294 195 488 minecraft:shroomlight
fill 294 195 489 298 195 491 minecraft:gold_block
fill 294 195 492 300 195 492 minecraft:red_concrete
fill 295 195 484 299 195 484 minecraft:shroomlight
fill 295 195 485 297 195 487 minecraft:nether_bricks
fill 295 195 488 299 195 488 minecraft:shroomlight
fill 296 195 478 299 195 478 minecraft:nether_bricks
fill 296 195 494 299 195 494 minecraft:nether_bricks
fill 298 195 479 299 195 479 minecraft:nether_bricks
fill 298 195 485 298 195 487 minecraft:shroomlight
fill 298 195 493 299 195 493 minecraft:nether_bricks
setblock 299 195 481 minecraft:red_concrete
setblock 299 195 482 minecraft:gold_block
setblock 299 195 483 minecraft:magma_block
fill 299 195 485 299 195 487 minecraft:sea_lantern
fill 299 195 489 301 195 489 minecraft:magma_block
fill 299 195 490 300 195 490 minecraft:gold_block
setblock 299 195 491 minecraft:red_concrete
fill 300 195 478 301 195 478 minecraft:red_concrete
fill 300 195 479 300 195 483 minecraft:shroomlight
fill 300 195 484 302 195 484 minecraft:sea_lantern
fill 300 195 488 302 195 488 minecraft:sea_lantern
fill 300 195 491 301 195 491 minecraft:gold_block
fill 300 195 493 300 195 494 minecraft:red_concrete
fill 301 195 464 301 195 475 minecraft:nether_bricks
fill 301 195 476 303 195 477 minecraft:red_concrete
fill 301 195 479 304 195 479 minecraft:shroomlight
fill 301 195 480 303 195 482 minecraft:nether_bricks
fill 301 195 483 308 195 483 minecraft:shroomlight
setblock 301 195 490 minecraft:magma_block
fill 301 195 492 301 195 493 minecraft:gold_block
fill 301 195 494 301 195 496 minecraft:red_concrete
fill 301 195 497 301 195 504 minecraft:nether_bricks
fill 302 195 464 302 195 474 minecraft:nether_bricks
fill 302 195 478 304 195 478 minecraft:gold_block
fill 302 195 489 302 195 492 minecraft:shroomlight
fill 302 195 493 304 195 494 minecraft:gold_block
fill 302 195 495 303 195 496 minecraft:red_concrete
fill 302 195 498 302 195 504 minecraft:nether_bricks
fill 303 195 464 304 195 473 minecraft:nether_bricks
fill 303 195 484 304 195 484 minecraft:shroomlight
fill 303 195 485 303 195 487 minecraft:sea_lantern
fill 303 195 488 306 195 488 minecraft:shroomlight
fill 303 195 489 305 195 491 minecraft:nether_bricks
fill 303 195 492 306 195 492 minecraft:shroomlight
fill 303 195 499 304 195 504 minecraft:nether_bricks
fill 304 195 476 306 195 476 minecraft:red_concrete
setblock 304 195 477 minecraft:gold_block
fill 304 195 480 304 195 482 minecraft:shroomlight
fill 304 195 485 304 195 487 minecraft:shroomlight
setblock 304 195 495 minecraft:gold_block
fill 304 195 496 306 195 496 minecraft:red_concrete
fill 305 195 464 323 195 472 minecraft:nether_bricks
fill 305 195 477 306 195 479 minecraft:red_concrete
fill 305 195 480 305 195 482 minecraft:gold_block
fill 305 195 484 307 195 486 minecraft:nether_bricks
fill 305 195 487 308 195 487 minecraft:shroomlight
fill 305 195 493 306 195 495 minecraft:red_concrete
fill 305 195 500 323 195 504 minecraft:nether_bricks
fill 306 195 473 323 195 473 minecraft:nether_bricks
fill 306 195 480 306 195 482 minecraft:red_concrete
fill 306 195 489 306 195 491 minecraft:shroomlight
fill 306 195 499 323 195 499 minecraft:nether_bricks
fill 307 195 474 323 195 482 minecraft:nether_bricks
fill 307 195 488 308 195 488 minecraft:gold_block
fill 307 195 490 323 195 498 minecraft:nether_bricks
fill 308 195 484 308 195 486 minecraft:shroomlight
fill 309 195 483 310 195 484 minecraft:red_concrete
fill 309 195 485 309 195 487 minecraft:gold_block
fill 309 195 488 312 195 488 minecraft:red_concrete
fill 310 195 485 312 195 485 minecraft:red_concrete
setblock 310 195 486 minecraft:gold_block
fill 310 195 487 314 195 487 minecraft:red_concrete
fill 311 195 483 323 195 483 minecraft:nether_bricks
fill 311 195 484 312 195 484 minecraft:red_concrete
fill 311 195 486 312 195 486 minecraft:red_concrete
fill 311 195 489 323 195 489 minecraft:nether_bricks
fill 313 195 484 323 195 484 minecraft:nether_bricks
fill 313 195 488 323 195 488 minecraft:nether_bricks
fill 315 195 485 323 195 485 minecraft:nether_bricks
fill 315 195 487 323 195 487 minecraft:nether_bricks
fill 316 195 486 323 195 486 minecraft:nether_bricks
fill 289 196 474 299 196 498 minecraft:prismarine_bricks
fill 300 196 474 301 196 484 minecraft:prismarine_bricks
fill 300 196 488 313 196 498 minecraft:prismarine_bricks
fill 302 196 474 313 197 483 minecraft:prismarine_bricks
fill 303 196 484 313 197 484 minecraft:prismarine_bricks
fill 303 196 486 313 196 487 minecraft:prismarine_bricks
fill 304 196 485 313 197 485 minecraft:prismarine_bricks
fill 289 197 474 298 197 498 minecraft:prismarine_bricks
fill 299 197 474 299 197 485 minecraft:prismarine_bricks
fill 299 197 487 299 197 498 minecraft:prismarine_bricks
fill 300 197 474 300 197 484 minecraft:prismarine_bricks
fill 300 197 488 300 197 498 minecraft:prismarine_bricks
fill 301 197 474 301 197 483 minecraft:prismarine_bricks
fill 301 197 489 313 197 498 minecraft:prismarine_bricks
fill 302 197 488 313 197 488 minecraft:prismarine_bricks
fill 303 197 487 313 197 487 minecraft:prismarine_bricks
fill 304 197 486 313 197 486 minecraft:prismarine_bricks
fill 290 198 475 290 199 475 minecraft:sea_lantern
fill 290 198 497 290 199 497 minecraft:sea_lantern
fill 291 198 476 298 199 496 minecraft:dark_prismarine
fill 299 198 476 299 199 484 minecraft:dark_prismarine
fill 299 198 488 299 199 496 minecraft:dark_prismarine
fill 300 198 476 311 199 483 minecraft:dark_prismarine
fill 300 198 489 311 199 496 minecraft:dark_prismarine
fill 303 198 484 311 199 484 minecraft:dark_prismarine
fill 303 198 488 311 199 488 minecraft:dark_prismarine
fill 304 198 485 311 199 487 minecraft:dark_prismarine
fill 312 198 475 312 199 475 minecraft:sea_lantern
fill 312 198 497 312 199 497 minecraft:sea_lantern
fill 283 199 464 285 235 464 minecraft:polished_blackstone_bricks
fill 283 199 474 283 235 476 minecraft:polished_blackstone_bricks
fill 283 199 486 283 235 488 minecraft:polished_blackstone_bricks
fill 283 199 498 283 235 500 minecraft:polished_blackstone_bricks
setblock 285 199 466 minecraft:light[level=14]
setblock 285 199 474 minecraft:light[level=14]
setblock 285 199 482 minecraft:light[level=14]
setblock 285 199 490 minecraft:light[level=14]
setblock 285 199 498 minecraft:light[level=14]
fill 287 199 465 291 203 465 minecraft:red_wool
fill 289 199 504 291 235 504 minecraft:polished_blackstone_bricks
setblock 293 199 466 minecraft:light[level=14]
setblock 293 199 474 minecraft:light[level=14]
setblock 293 199 498 minecraft:light[level=14]
fill 295 199 464 297 235 464 minecraft:polished_blackstone_bricks
setblock 301 199 466 minecraft:light[level=14]
setblock 301 199 474 minecraft:light[level=14]
setblock 301 199 498 minecraft:light[level=14]
fill 301 199 504 303 235 504 minecraft:polished_blackstone_bricks
fill 307 199 464 309 235 464 minecraft:polished_blackstone_bricks
setblock 309 199 466 minecraft:light[level=14]
setblock 309 199 474 minecraft:light[level=14]
setblock 309 199 498 minecraft:light[level=14]
fill 311 199 464 317 201 473 minecraft:polished_blackstone_bricks
fill 313 199 504 315 235 504 minecraft:polished_blackstone_bricks
setblock 317 199 474 minecraft:light[level=14]
setblock 317 199 482 minecraft:light[level=14]
setblock 317 199 490 minecraft:light[level=14]
setblock 317 199 498 minecraft:light[level=14]
fill 319 199 464 321 235 464 minecraft:polished_blackstone_bricks
fill 319 199 481 319 215 481 minecraft:gilded_blackstone
fill 323 199 472 323 235 474 minecraft:polished_blackstone_bricks
fill 323 199 484 323 235 486 minecraft:polished_blackstone_bricks
fill 323 199 496 323 235 498 minecraft:polished_blackstone_bricks
fill 284 200 473 284 205 475 minecraft:polished_blackstone_bricks
fill 284 200 485 284 205 487 minecraft:polished_blackstone_bricks
fill 284 200 497 284 205 499 minecraft:polished_blackstone_bricks
fill 290 200 503 292 205 503 minecraft:polished_blackstone_bricks
fill 293 200 478 298 201 494 minecraft:prismarine_bricks
fill 294 200 465 296 205 465 minecraft:polished_blackstone_bricks
fill 299 200 478 299 201 484 minecraft:prismarine_bricks
fill 299 200 488 299 201 494 minecraft:prismarine_bricks
fill 300 200 478 309 201 483 minecraft:prismarine_bricks
fill 300 200 489 309 201 494 minecraft:prismarine_bricks
fill 302 200 503 304 205 503 minecraft:polished_blackstone_bricks
fill 303 200 484 309 201 484 minecraft:prismarine_bricks
fill 303 200 488 309 201 488 minecraft:prismarine_bricks
fill 304 200 485 309 201 487 minecraft:prismarine_bricks
fill 306 200 465 308 205 465 minecraft:polished_blackstone_bricks
fill 314 200 503 316 205 503 minecraft:polished_blackstone_bricks
fill 318 200 465 320 205 465 minecraft:polished_blackstone_bricks
fill 322 200 473 322 205 475 minecraft:polished_blackstone_bricks
fill 322 200 485 322 205 487 minecraft:polished_blackstone_bricks
fill 322 200 497 322 205 499 minecraft:polished_blackstone_bricks
fill 295 202 480 298 202 492 minecraft:dark_prismarine
fill 299 202 480 307 202 483 minecraft:dark_prismarine
fill 299 202 489 307 202 492 minecraft:dark_prismarine
fill 304 202 484 307 202 488 minecraft:dark_prismarine
setblock 311 202 464 minecraft:shroomlight
fill 311 202 465 311 223 465 minecraft:polished_blackstone_bricks
setblock 311 202 466 minecraft:shroomlight
fill 311 202 467 311 223 467 minecraft:polished_blackstone_bricks
setblock 311 202 468 minecraft:shroomlight
fill 311 202 469 311 223 469 minecraft:polished_blackstone_bricks
setblock 311 202 470 minecraft:shroomlight
fill 311 202 471 311 223 471 minecraft:polished_blackstone_bricks
setblock 311 202 472 minecraft:shroomlight
fill 311 202 473 311 223 473 minecraft:polished_blackstone_bricks
fill 312 202 464 312 204 464 minecraft:polished_blackstone_bricks
setblock 312 202 465 minecraft:shroomlight
fill 312 202 466 312 223 466 minecraft:polished_blackstone_bricks
setblock 312 202 467 minecraft:shroomlight
fill 312 202 468 312 223 468 minecraft:polished_blackstone_bricks
setblock 312 202 469 minecraft:shroomlight
fill 312 202 470 312 223 470 minecraft:polished_blackstone_bricks
setblock 312 202 471 minecraft:shroomlight
fill 312 202 472 312 223 472 minecraft:polished_blackstone_bricks
setblock 312 202 473 minecraft:shroomlight
setblock 313 202 464 minecraft:shroomlight
fill 313 202 465 313 223 465 minecraft:polished_blackstone_bricks
setblock 313 202 466 minecraft:shroomlight
fill 313 202 467 313 223 467 minecraft:polished_blackstone_bricks
setblock 313 202 468 minecraft:shroomlight
fill 313 202 469 313 223 469 minecraft:polished_blackstone_bricks
setblock 313 202 470 minecraft:shroomlight
fill 313 202 471 313 223 471 minecraft:polished_blackstone_bricks
setblock 313 202 472 minecraft:shroomlight
fill 313 202 473 313 223 473 minecraft:polished_blackstone_bricks
fill 314 202 464 314 204 464 minecraft:polished_blackstone_bricks
setblock 314 202 465 minecraft:shroomlight
fill 314 202 466 314 223 466 minecraft:polished_blackstone_bricks
setblock 314 202 467 minecraft:shroomlight
fill 314 202 468 314 223 468 minecraft:polished_blackstone_bricks
setblock 314 202 469 minecraft:shroomlight
fill 314 202 470 314 223 470 minecraft:polished_blackstone_bricks
setblock 314 202 471 minecraft:shroomlight
fill 314 202 472 314 223 472 minecraft:polished_blackstone_bricks
setblock 314 202 473 minecraft:shroomlight
setblock 315 202 464 minecraft:shroomlight
fill 315 202 465 315 223 465 minecraft:polished_blackstone_bricks
setblock 315 202 466 minecraft:shroomlight
fill 315 202 467 315 223 467 minecraft:polished_blackstone_bricks
setblock 315 202 468 minecraft:shroomlight
fill 315 202 469 315 223 469 minecraft:polished_blackstone_bricks
setblock 315 202 470 minecraft:shroomlight
fill 315 202 471 315 223 471 minecraft:polished_blackstone_bricks
setblock 315 202 472 minecraft:shroomlight
fill 315 202 473 315 223 473 minecraft:polished_blackstone_bricks
fill 316 202 464 316 204 464 minecraft:polished_blackstone_bricks
setblock 316 202 465 minecraft:shroomlight
fill 316 202 466 316 223 466 minecraft:polished_blackstone_bricks
setblock 316 202 467 minecraft:shroomlight
fill 316 202 468 316 223 468 minecraft:polished_blackstone_bricks
setblock 316 202 469 minecraft:shroomlight
fill 316 202 470 316 223 470 minecraft:polished_blackstone_bricks
setblock 316 202 471 minecraft:shroomlight
fill 316 202 472 316 223 472 minecraft:polished_blackstone_bricks
setblock 316 202 473 minecraft:shroomlight
setblock 317 202 464 minecraft:shroomlight
fill 317 202 465 317 223 465 minecraft:polished_blackstone_bricks
setblock 317 202 466 minecraft:shroomlight
fill 317 202 467 317 223 467 minecraft:polished_blackstone_bricks
setblock 317 202 468 minecraft:shroomlight
fill 317 202 469 317 223 469 minecraft:polished_blackstone_bricks
setblock 317 202 470 minecraft:shroomlight
fill 317 202 471 317 223 471 minecraft:polished_blackstone_bricks
setblock 317 202 472 minecraft:shroomlight
fill 317 202 473 317 223 473 minecraft:polished_blackstone_bricks
fill 295 203 480 297 203 492 minecraft:dark_prismarine
fill 298 203 480 298 203 485 minecraft:dark_prismarine
fill 298 203 487 298 203 492 minecraft:dark_prismarine
fill 299 203 480 300 203 483 minecraft:dark_prismarine
fill 299 203 489 300 203 492 minecraft:dark_prismarine
fill 301 203 480 307 203 482 minecraft:dark_prismarine
fill 301 203 490 307 203 492 minecraft:dark_prismarine
fill 302 203 483 307 203 483 minecraft:dark_prismarine
fill 302 203 489 307 203 489 minecraft:dark_prismarine
fill 304 203 484 307 203 485 minecraft:dark_prismarine
fill 304 203 487 307 203 488 minecraft:dark_prismarine
fill 305 203 486 307 203 486 minecraft:dark_prismarine
fill 311 203 464 311 204 464 minecraft:polished_blackstone_bricks
fill 311 203 466 311 204 466 minecraft:polished_blackstone_bricks
fill 311 203 468 311 204 468 minecraft:polished_blackstone_bricks
fill 311 203 470 311 204 470 minecraft:polished_blackstone_bricks
fill 311 203 472 311 204 472 minecraft:polished_blackstone_bricks
fill 312 203 465 312 204 465 minecraft:polished_blackstone_bricks
fill 312 203 467 312 204 467 minecraft:polished_blackstone_bricks
fill 312 203 469 312 204 469 minecraft:polished_blackstone_bricks
fill 312 203 471 312 204 471 minecraft:polished_blackstone_bricks
fill 312 203 473 312 204 473 minecraft:polished_blackstone_bricks
fill 313 203 464 313 204 464 minecraft:polished_blackstone_bricks
fill 313 203 466 313 204 466 minecraft:polished_blackstone_bricks
fill 313 203 468 313 204 468 minecraft:polished_blackstone_bricks
fill 313 203 470 313 204 470 minecraft:polished_blackstone_bricks
fill 313 203 472 313 204 472 minecraft:polished_blackstone_bricks
fill 314 203 465 314 204 465 minecraft:polished_blackstone_bricks
fill 314 203 467 314 204 467 minecraft:polished_blackstone_bricks
fill 314 203 469 314 204 469 minecraft:polished_blackstone_bricks
fill 314 203 471 314 204 471 minecraft:polished_blackstone_bricks
fill 314 203 473 314 204 473 minecraft:polished_blackstone_bricks
fill 315 203 464 315 204 464 minecraft:polished_blackstone_bricks
fill 315 203 466 315 204 466 minecraft:polished_blackstone_bricks
fill 315 203 468 315 204 468 minecraft:polished_blackstone_bricks
fill 315 203 470 315 204 470 minecraft:polished_blackstone_bricks
fill 315 203 472 315 204 472 minecraft:polished_blackstone_bricks
fill 316 203 465 316 204 465 minecraft:polished_blackstone_bricks
fill 316 203 467 316 204 467 minecraft:polished_blackstone_bricks
fill 316 203 469 316 204 469 minecraft:polished_blackstone_bricks
fill 316 203 471 316 204 471 minecraft:polished_blackstone_bricks
fill 316 203 473 316 204 473 minecraft:polished_blackstone_bricks
fill 317 203 464 317 204 464 minecraft:polished_blackstone_bricks
fill 317 203 466 317 204 466 minecraft:polished_blackstone_bricks
fill 317 203 468 317 204 468 minecraft:polished_blackstone_bricks
fill 317 203 470 317 204 470 minecraft:polished_blackstone_bricks
fill 317 203 472 317 204 472 minecraft:polished_blackstone_bricks
fill 285 204 484 285 219 484 minecraft:gilded_blackstone
fill 286 204 465 292 205 465 minecraft:gilded_blackstone
fill 297 204 482 297 205 490 minecraft:prismarine_bricks
fill 298 204 482 298 205 484 minecraft:prismarine_bricks
fill 298 204 488 298 205 490 minecraft:prismarine_bricks
fill 299 204 482 299 205 483 minecraft:prismarine_bricks
fill 299 204 489 299 205 490 minecraft:prismarine_bricks
fill 300 204 482 305 205 482 minecraft:prismarine_bricks
fill 300 204 490 305 205 490 minecraft:prismarine_bricks
fill 303 204 483 305 205 483 minecraft:prismarine_bricks
fill 303 204 489 305 205 489 minecraft:prismarine_bricks
fill 304 204 484 305 205 484 minecraft:prismarine_bricks
fill 304 204 488 305 205 488 minecraft:prismarine_bricks
fill 305 204 485 305 205 487 minecraft:prismarine_bricks
fill 283 205 467 283 205 472 minecraft:nether_bricks
fill 283 205 479 283 205 484 minecraft:nether_bricks
fill 283 205 491 283 205 496 minecraft:nether_bricks
fill 283 205 503 283 205 504 minecraft:nether_bricks
fill 284 205 504 287 205 504 minecraft:nether_bricks
fill 287 205 464 292 205 464 minecraft:nether_bricks
fill 294 205 504 299 205 504 minecraft:nether_bricks
fill 299 205 464 304 205 464 minecraft:nether_bricks
fill 306 205 504 311 205 504 minecraft:nether_bricks
setblock 311 205 464 minecraft:shroomlight
setblock 311 205 466 minecraft:shroomlight
setblock 311 205 468 minecraft:shroomlight
setblock 311 205 470 minecraft:shroomlight
setblock 311 205 472 minecraft:shroomlight
setblock 312 205 464 minecraft:nether_bricks
setblock 312 205 465 minecraft:shroomlight
setblock 312 205 467 minecraft:shroomlight
setblock 312 205 469 minecraft:shroomlight
setblock 312 205 471 minecraft:shroomlight
setblock 312 205 473 minecraft:shroomlight
fill 312 205 502 312 214 502 minecraft:red_wool
setblock 313 205 464 minecraft:shroomlight
setblock 313 205 466 minecraft:shroomlight
setblock 313 205 468 minecraft:shroomlight
setblock 313 205 470 minecraft:shroomlight
setblock 313 205 472 minecraft:shroomlight
setblock 314 205 464 minecraft:nether_bricks
setblock 314 205 465 minecraft:shroomlight
setblock 314 205 467 minecraft:shroomlight
setblock 314 205 469 minecraft:shroomlight
setblock 314 205 471 minecraft:shroomlight
setblock 314 205 473 minecraft:shroomlight
setblock 315 205 464 minecraft:shroomlight
setblock 315 205 466 minecraft:shroomlight
setblock 315 205 468 minecraft:shroomlight
setblock 315 205 470 minecraft:shroomlight
setblock 315 205 472 minecraft:shroomlight
setblock 316 205 464 minecraft:nether_bricks
setblock 316 205 465 minecraft:shroomlight
setblock 316 205 467 minecraft:shroomlight
setblock 316 205 469 minecraft:shroomlight
setblock 316 205 471 minecraft:shroomlight
setblock 316 205 473 minecraft:shroomlight
setblock 317 205 464 minecraft:shroomlight
setblock 317 205 466 minecraft:shroomlight
setblock 317 205 468 minecraft:shroomlight
setblock 317 205 470 minecraft:shroomlight
setblock 317 205 472 minecraft:shroomlight
fill 318 205 504 323 205 504 minecraft:nether_bricks
fill 321 205 474 321 217 474 minecraft:red_wool
fill 323 205 464 323 205 469 minecraft:nether_bricks
fill 323 205 476 323 205 481 minecraft:nether_bricks
fill 323 205 488 323 205 493 minecraft:nether_bricks
fill 323 205 500 323 205 503 minecraft:nether_bricks
fill 282 206 469 282 211 472 minecraft:shroomlight
fill 282 206 481 282 211 484 minecraft:shroomlight
fill 282 206 493 282 211 496 minecraft:shroomlight
fill 282 206 505 285 211 505 minecraft:shroomlight
fill 289 206 463 292 211 463 minecraft:shroomlight
fill 294 206 505 297 211 505 minecraft:shroomlight
fill 301 206 463 304 211 463 minecraft:shroomlight
fill 306 206 505 309 211 505 minecraft:shroomlight
fill 310 206 502 311 214 502 minecraft:red_wool
fill 311 206 464 317 207 464 minecraft:polished_blackstone_bricks
fill 311 206 466 311 207 466 minecraft:polished_blackstone_bricks
fill 311 206 468 311 207 468 minecraft:polished_blackstone_bricks
fill 311 206 470 311 207 470 minecraft:polished_blackstone_bricks
fill 311 206 472 311 207 472 minecraft:polished_blackstone_bricks
fill 312 206 465 312 207 465 minecraft:polished_blackstone_bricks
fill 312 206 467 312 207 467 minecraft:polished_blackstone_bricks
fill 312 206 469 312 207 469 minecraft:polished_blackstone_bricks
fill 312 206 471 312 207 471 minecraft:polished_blackstone_bricks
fill 312 206 473 312 207 473 minecraft:polished_blackstone_bricks
fill 313 206 463 316 211 463 minecraft:shroomlight
fill 313 206 466 313 207 466 minecraft:polished_blackstone_bricks
fill 313 206 468 313 207 468 minecraft:polished_blackstone_bricks
fill 313 206 470 313 207 470 minecraft:polished_blackstone_bricks
fill 313 206 472 313 207 472 minecraft:polished_blackstone_bricks
fill 313 206 502 314 214 502 minecraft:red_wool
fill 314 206 465 314 207 465 minecraft:polished_blackstone_bricks
fill 314 206 467 314 207 467 minecraft:polished_blackstone_bricks
fill 314 206 469 314 207 469 minecraft:polished_blackstone_bricks
fill 314 206 471 314 207 471 minecraft:polished_blackstone_bricks
fill 314 206 473 314 207 473 minecraft:polished_blackstone_bricks
fill 315 206 466 315 207 466 minecraft:polished_blackstone_bricks
fill 315 206 468 315 207 468 minecraft:polished_blackstone_bricks
fill 315 206 470 315 207 470 minecraft:polished_blackstone_bricks
fill 315 206 472 315 207 472 minecraft:polished_blackstone_bricks
fill 316 206 465 316 207 465 minecraft:polished_blackstone_bricks
fill 316 206 467 316 207 467 minecraft:polished_blackstone_bricks
fill 316 206 469 316 207 469 minecraft:polished_blackstone_bricks
fill 316 206 471 316 207 471 minecraft:polished_blackstone_bricks
fill 316 206 473 316 207 473 minecraft:polished_blackstone_bricks
fill 317 206 466 317 207 466 minecraft:polished_blackstone_bricks
fill 317 206 468 317 207 468 minecraft:polished_blackstone_bricks
fill 317 206 470 317 207 470 minecraft:polished_blackstone_bricks
fill 317 206 472 317 207 472 minecraft:polished_blackstone_bricks
fill 318 206 505 321 211 505 minecraft:shroomlight
fill 321 206 472 321 217 473 minecraft:red_wool
fill 321 206 475 321 217 476 minecraft:red_wool
fill 324 206 464 324 211 467 minecraft:shroomlight
fill 324 206 476 324 211 479 minecraft:shroomlight
fill 324 206 488 324 211 491 minecraft:shroomlight
fill 324 206 500 324 211 503 minecraft:shroomlight
setblock 285 207 466 minecraft:light[level=14]
setblock 285 207 474 minecraft:light[level=14]
setblock 285 207 482 minecraft:light[level=14]
setblock 285 207 490 minecraft:light[level=14]
setblock 285 207 498 minecraft:light[level=14]
setblock 293 207 466 minecraft:light[level=14]
setblock 293 207 474 minecraft:light[level=14]
setblock 293 207 482 minecraft:light[level=14]
setblock 293 207 490 minecraft:light[level=14]
setblock 293 207 498 minecraft:light[level=14]
setblock 301 207 466 minecraft:light[level=14]
setblock 301 207 474 minecraft:light[level=14]
setblock 301 207 482 minecraft:light[level=14]
setblock 301 207 490 minecraft:light[level=14]
setblock 301 207 498 minecraft:light[level=14]
setblock 309 207 466 minecraft:light[level=14]
setblock 309 207 474 minecraft:light[level=14]
setblock 309 207 482 minecraft:light[level=14]
setblock 309 207 490 minecraft:light[level=14]
setblock 309 207 498 minecraft:light[level=14]
setblock 317 207 474 minecraft:light[level=14]
setblock 317 207 482 minecraft:light[level=14]
setblock 317 207 490 minecraft:light[level=14]
setblock 317 207 498 minecraft:light[level=14]
setblock 311 208 464 minecraft:shroomlight
setblock 311 208 466 minecraft:shroomlight
setblock 311 208 468 minecraft:shroomlight
setblock 311 208 470 minecraft:shroomlight
setblock 311 208 472 minecraft:shroomlight
fill 312 208 464 312 223 464 minecraft:polished_blackstone_bricks
setblock 312 208 465 minecraft:shroomlight
setblock 312 208 467 minecraft:shroomlight
setblock 312 208 469 minecraft:shroomlight
setblock 312 208 471 minecraft:shroomlight
setblock 312 208 473 minecraft:shroomlight
setblock 313 208 464 minecraft:shroomlight
setblock 313 208 466 minecraft:shroomlight
setblock 313 208 468 minecraft:shroomlight
setblock 313 208 470 minecraft:shroomlight
setblock 313 208 472 minecraft:shroomlight
fill 314 208 464 314 223 464 minecraft:polished_blackstone_bricks
setblock 314 208 465 minecraft:shroomlight
setblock 314 208 467 minecraft:shroomlight
setblock 314 208 469 minecraft:shroomlight
setblock 314 208 471 minecraft:shroomlight
setblock 314 208 473 minecraft:shroomlight
setblock 315 208 464 minecraft:shroomlight
setblock 315 208 466 minecraft:shroomlight
setblock 315 208 468 minecraft:shroomlight
setblock 315 208 470 minecraft:shroomlight
setblock 315 208 472 minecraft:shroomlight
fill 316 208 464 316 223 464 minecraft:polished_blackstone_bricks
setblock 316 208 465 minecraft:shroomlight
setblock 316 208 467 minecraft:shroomlight
setblock 316 208 469 minecraft:shroomlight
setblock 316 208 471 minecraft:shroomlight
setblock 316 208 473 minecraft:shroomlight
setblock 317 208 464 minecraft:shroomlight
setblock 317 208 466 minecraft:shroomlight
setblock 317 208 468 minecraft:shroomlight
setblock 317 208 470 minecraft:shroomlight
setblock 317 208 472 minecraft:shroomlight
fill 311 209 464 311 210 464 minecraft:polished_blackstone_bricks
fill 311 209 466 311 210 466 minecraft:polished_blackstone_bricks
fill 311 209 468 311 210 468 minecraft:polished_blackstone_bricks
fill 311 209 470 311 210 470 minecraft:polished_blackstone_bricks
fill 311 209 472 311 210 472 minecraft:polished_blackstone_bricks
fill 312 209 465 312 210 465 minecraft:polished_blackstone_bricks
fill 312 209 467 312 210 467 minecraft:polished_blackstone_bricks
fill 312 209 469 312 210 469 minecraft:polished_blackstone_bricks
fill 312 209 471 312 210 471 minecraft:polished_blackstone_bricks
fill 312 209 473 312 210 473 minecraft:polished_blackstone_bricks
fill 313 209 464 313 210 464 minecraft:polished_blackstone_bricks
fill 313 209 466 313 210 466 minecraft:polished_blackstone_bricks
fill 313 209 468 313 210 468 minecraft:polished_blackstone_bricks
fill 313 209 470 313 210 470 minecraft:polished_blackstone_bricks
fill 313 209 472 313 210 472 minecraft:polished_blackstone_bricks
fill 314 209 465 314 210 465 minecraft:polished_blackstone_bricks
fill 314 209 467 314 210 467 minecraft:polished_blackstone_bricks
fill 314 209 469 314 210 469 minecraft:polished_blackstone_bricks
fill 314 209 471 314 210 471 minecraft:polished_blackstone_bricks
fill 314 209 473 314 210 473 minecraft:polished_blackstone_bricks
fill 315 209 464 315 210 464 minecraft:polished_blackstone_bricks
fill 315 209 466 315 210 466 minecraft:polished_blackstone_bricks
fill 315 209 468 315 210 468 minecraft:polished_blackstone_bricks
fill 315 209 470 315 210 470 minecraft:polished_blackstone_bricks
fill 315 209 472 315 210 472 minecraft:polished_blackstone_bricks
fill 316 209 465 316 210 465 minecraft:polished_blackstone_bricks
fill 316 209 467 316 210 467 minecraft:polished_blackstone_bricks
fill 316 209 469 316 210 469 minecraft:polished_blackstone_bricks
fill 316 209 471 316 210 471 minecraft:polished_blackstone_bricks
fill 316 209 473 316 210 473 minecraft:polished_blackstone_bricks
fill 317 209 464 317 210 464 minecraft:polished_blackstone_bricks
fill 317 209 466 317 210 466 minecraft:polished_blackstone_bricks
fill 317 209 468 317 210 468 minecraft:polished_blackstone_bricks
fill 317 209 470 317 210 470 minecraft:polished_blackstone_bricks
fill 317 209 472 317 210 472 minecraft:polished_blackstone_bricks
setblock 311 211 464 minecraft:shroomlight
setblock 311 211 466 minecraft:shroomlight
setblock 311 211 468 minecraft:shroomlight
setblock 311 211 470 minecraft:shroomlight
setblock 311 211 472 minecraft:shroomlight
setblock 312 211 465 minecraft:shroomlight
setblock 312 211 467 minecraft:shroomlight
setblock 312 211 469 minecraft:shroomlight
setblock 312 211 471 minecraft:shroomlight
setblock 312 211 473 minecraft:shroomlight
setblock 313 211 464 minecraft:shroomlight
setblock 313 211 466 minecraft:shroomlight
setblock 313 211 468 minecraft:shroomlight
setblock 313 211 470 minecraft:shroomlight
setblock 313 211 472 minecraft:shroomlight
setblock 314 211 465 minecraft:shroomlight
setblock 314 211 467 minecraft:shroomlight
setblock 314 211 469 minecraft:shroomlight
setblock 314 211 471 minecraft:shroomlight
setblock 314 211 473 minecraft:shroomlight
setblock 315 211 464 minecraft:shroomlight
setblock 315 211 466 minecraft:shroomlight
setblock 315 211 468 minecraft:shroomlight
setblock 315 211 470 minecraft:shroomlight
setblock 315 211 472 minecraft:shroomlight
setblock 316 211 465 minecraft:shroomlight
setblock 316 211 467 minecraft:shroomlight
setblock 316 211 469 minecraft:shroomlight
setblock 316 211 471 minecraft:shroomlight
setblock 316 211 473 minecraft:shroomlight
setblock 317 211 464 minecraft:shroomlight
setblock 317 211 466 minecraft:shroomlight
setblock 317 211 468 minecraft:shroomlight
setblock 317 211 470 minecraft:shroomlight
setblock 317 211 472 minecraft:shroomlight
fill 282 212 469 282 222 469 minecraft:nether_bricks
fill 282 212 470 282 212 471 minecraft:shroomlight
fill 282 212 472 282 222 472 minecraft:nether_bricks
fill 282 212 481 282 222 481 minecraft:nether_bricks
fill 282 212 482 282 212 483 minecraft:shroomlight
fill 282 212 484 282 222 484 minecraft:nether_bricks
fill 282 212 493 282 222 493 minecraft:nether_bricks
fill 282 212 494 282 212 495 minecraft:shroomlight
fill 282 212 496 282 222 496 minecraft:nether_bricks
fill 282 212 505 282 222 505 minecraft:nether_bricks
fill 283 212 505 284 212 505 minecraft:shroomlight
fill 285 212 505 285 219 505 minecraft:nether_bricks
fill 289 212 463 289 222 463 minecraft:nether_bricks
fill 290 212 463 291 212 463 minecraft:shroomlight
fill 292 212 463 292 219 463 minecraft:nether_bricks
fill 294 212 505 294 222 505 minecraft:nether_bricks
fill 295 212 505 296 212 505 minecraft:shroomlight
fill 297 212 505 297 222 505 minecraft:nether_bricks
fill 301 212 463 301 222 463 minecraft:nether_bricks
fill 302 212 463 303 212 463 minecraft:shroomlight
fill 304 212 463 304 223 463 minecraft:nether_bricks
fill 306 212 505 306 222 505 minecraft:nether_bricks
fill 307 212 505 308 212 505 minecraft:shroomlight
fill 309 212 505 309 220 505 minecraft:nether_bricks
fill 311 212 464 311 213 464 minecraft:polished_blackstone_bricks
fill 311 212 466 311 213 466 minecraft:polished_blackstone_bricks
fill 311 212 468 311 213 468 minecraft:polished_blackstone_bricks
fill 311 212 470 311 213 470 minecraft:polished_blackstone_bricks
fill 311 212 472 311 213 472 minecraft:polished_blackstone_bricks
fill 312 212 465 312 213 465 minecraft:polished_blackstone_bricks
fill 312 212 467 312 213 467 minecraft:polished_blackstone_bricks
fill 312 212 469 312 213 469 minecraft:polished_blackstone_bricks
fill 312 212 471 312 213 471 minecraft:polished_blackstone_bricks
fill 312 212 473 312 213 473 minecraft:polished_blackstone_bricks
fill 313 212 463 313 222 463 minecraft:nether_bricks
fill 313 212 464 313 213 464 minecraft:polished_blackstone_bricks
fill 313 212 466 313 213 466 minecraft:polished_blackstone_bricks
fill 313 212 468 313 213 468 minecraft:polished_blackstone_bricks
fill 313 212 470 313 213 470 minecraft:polished_blackstone_bricks
fill 313 212 472 313 213 472 minecraft:polished_blackstone_bricks
fill 314 212 463 315 212 463 minecraft:shroomlight
fill 314 212 465 314 213 465 minecraft:polished_blackstone_bricks
fill 314 212 467 314 213 467 minecraft:polished_blackstone_bricks
fill 314 212 469 314 213 469 minecraft:polished_blackstone_bricks
fill 314 212 471 314 213 471 minecraft:polished_blackstone_bricks
fill 314 212 473 314 213 473 minecraft:polished_blackstone_bricks
fill 315 212 464 315 213 464 minecraft:polished_blackstone_bricks
fill 315 212 466 315 213 466 minecraft:polished_blackstone_bricks
fill 315 212 468 315 213 468 minecraft:polished_blackstone_bricks
fill 315 212 470 315 213 470 minecraft:polished_blackstone_bricks
fill 315 212 472 315 213 472 minecraft:polished_blackstone_bricks
fill 316 212 463 316 222 463 minecraft:nether_bricks
fill 316 212 465 316 213 465 minecraft:polished_blackstone_bricks
fill 316 212 467 316 213 467 minecraft:polished_blackstone_bricks
fill 316 212 469 316 213 469 minecraft:polished_blackstone_bricks
fill 316 212 471 316 213 471 minecraft:polished_blackstone_bricks
fill 316 212 473 316 213 473 minecraft:polished_blackstone_bricks
fill 317 212 464 317 213 464 minecraft:polished_blackstone_bricks
fill 317 212 466 317 213 466 minecraft:polished_blackstone_bricks
fill 317 212 468 317 213 468 minecraft:polished_blackstone_bricks
fill 317 212 470 317 213 470 minecraft:polished_blackstone_bricks
fill 317 212 472 317 213 472 minecraft:polished_blackstone_bricks
fill 318 212 505 318 222 505 minecraft:nether_bricks
fill 319 212 505 320 212 505 minecraft:shroomlight
fill 321 212 505 321 218 505 minecraft:nether_bricks
fill 324 212 464 324 222 464 minecraft:nether_bricks
fill 324 212 465 324 212 466 minecraft:shroomlight
fill 324 212 467 324 222 467 minecraft:nether_bricks
fill 324 212 476 324 222 476 minecraft:nether_bricks
fill 324 212 477 324 212 478 minecraft:shroomlight
fill 324 212 479 324 220 479 minecraft:nether_bricks
fill 324 212 488 324 222 488 minecraft:nether_bricks
fill 324 212 489 324 212 490 minecraft:shroomlight
fill 324 212 491 324 220 491 minecraft:nether_bricks
fill 324 212 500 324 218 500 minecraft:nether_bricks
fill 324 212 501 324 212 502 minecraft:shroomlight
fill 324 212 503 324 222 503 minecraft:nether_bricks
fill 282 213 470 282 222 471 minecraft:nether_bricks
fill 282 213 482 282 218 483 minecraft:nether_bricks
fill 282 213 494 282 219 495 minecraft:nether_bricks
fill 283 213 505 284 218 505 minecraft:nether_bricks
fill 290 213 463 291 222 463 minecraft:nether_bricks
fill 295 213 505 296 222 505 minecraft:nether_bricks
fill 302 213 463 303 222 463 minecraft:nether_bricks
fill 307 213 505 308 218 505 minecraft:nether_bricks
fill 314 213 463 315 218 463 minecraft:nether_bricks
fill 319 213 488 319 228 488 minecraft:gilded_blackstone
fill 319 213 505 320 222 505 minecraft:nether_bricks
fill 321 213 497 321 224 497 minecraft:red_wool
fill 324 213 465 324 219 466 minecraft:nether_bricks
fill 324 213 477 324 220 478 minecraft:nether_bricks
fill 324 213 489 324 218 490 minecraft:nether_bricks
fill 324 213 501 324 218 502 minecraft:nether_bricks
setblock 311 214 464 minecraft:shroomlight
setblock 311 214 466 minecraft:shroomlight
setblock 311 214 468 minecraft:shroomlight
setblock 311 214 470 minecraft:shroomlight
setblock 311 214 472 minecraft:shroomlight
setblock 312 214 465 minecraft:shroomlight
setblock 312 214 467 minecraft:shroomlight
setblock 312 214 469 minecraft:shroomlight
setblock 312 214 471 minecraft:shroomlight
setblock 312 214 473 minecraft:shroomlight
setblock 313 214 464 minecraft:shroomlight
setblock 313 214 466 minecraft:shroomlight
setblock 313 214 468 minecraft:shroomlight
setblock 313 214 470 minecraft:shroomlight
setblock 313 214 472 minecraft:shroomlight
setblock 314 214 465 minecraft:shroomlight
setblock 314 214 467 minecraft:shroomlight
setblock 314 214 469 minecraft:shroomlight
setblock 314 214 471 minecraft:shroomlight
setblock 314 214 473 minecraft:shroomlight
setblock 315 214 464 minecraft:shroomlight
setblock 315 214 466 minecraft:shroomlight
setblock 315 214 468 minecraft:shroomlight
setblock 315 214 470 minecraft:shroomlight
setblock 315 214 472 minecraft:shroomlight
setblock 316 214 465 minecraft:shroomlight
setblock 316 214 467 minecraft:shroomlight
setblock 316 214 469 minecraft:shroomlight
setblock 316 214 471 minecraft:shroomlight
setblock 316 214 473 minecraft:shroomlight
fill 316 214 492 320 215 496 minecraft:nether_bricks
setblock 317 214 464 minecraft:shroomlight
setblock 317 214 466 minecraft:shroomlight
setblock 317 214 468 minecraft:shroomlight
setblock 317 214 470 minecraft:shroomlight
setblock 317 214 472 minecraft:shroomlight
fill 321 214 494 322 214 494 minecraft:nether_bricks
fill 321 214 495 321 224 496 minecraft:red_wool
fill 321 214 498 321 224 499 minecraft:red_wool
setblock 285 215 466 minecraft:light[level=14]
setblock 285 215 474 minecraft:light[level=14]
setblock 285 215 482 minecraft:light[level=14]
setblock 285 215 490 minecraft:light[level=14]
setblock 285 215 498 minecraft:light[level=14]
setblock 293 215 466 minecraft:light[level=14]
setblock 293 215 474 minecraft:light[level=14]
setblock 293 215 482 minecraft:light[level=14]
setblock 293 215 490 minecraft:light[level=14]
setblock 293 215 498 minecraft:light[level=14]
setblock 301 215 466 minecraft:light[level=14]
setblock 301 215 474 minecraft:light[level=14]
setblock 301 215 482 minecraft:light[level=14]
setblock 301 215 490 minecraft:light[level=14]
setblock 301 215 498 minecraft:light[level=14]
setblock 309 215 466 minecraft:light[level=14]
setblock 309 215 474 minecraft:light[level=14]
setblock 309 215 482 minecraft:light[level=14]
setblock 309 215 490 minecraft:light[level=14]
setblock 309 215 498 minecraft:light[level=14]
fill 309 215 502 315 216 502 minecraft:gilded_blackstone
fill 311 215 464 311 216 464 minecraft:polished_blackstone_bricks
fill 311 215 466 311 216 466 minecraft:polished_blackstone_bricks
fill 311 215 468 311 216 468 minecraft:polished_blackstone_bricks
fill 311 215 470 311 216 470 minecraft:polished_blackstone_bricks
fill 311 215 472 311 216 472 minecraft:polished_blackstone_bricks
fill 312 215 465 312 216 465 minecraft:polished_blackstone_bricks
fill 312 215 467 312 216 467 minecraft:polished_blackstone_bricks
fill 312 215 469 312 216 469 minecraft:polished_blackstone_bricks
fill 312 215 471 312 216 471 minecraft:polished_blackstone_bricks
fill 312 215 473 312 216 473 minecraft:polished_blackstone_bricks
fill 313 215 464 313 216 464 minecraft:polished_blackstone_bricks
fill 313 215 466 313 216 466 minecraft:polished_blackstone_bricks
fill 313 215 468 313 216 468 minecraft:polished_blackstone_bricks
fill 313 215 470 313 216 470 minecraft:polished_blackstone_bricks
fill 313 215 472 313 216 472 minecraft:polished_blackstone_bricks
fill 314 215 465 314 216 465 minecraft:polished_blackstone_bricks
fill 314 215 467 314 216 467 minecraft:polished_blackstone_bricks
fill 314 215 469 314 216 469 minecraft:polished_blackstone_bricks
fill 314 215 471 314 216 471 minecraft:polished_blackstone_bricks
fill 314 215 473 314 216 473 minecraft:polished_blackstone_bricks
fill 315 215 464 315 216 464 minecraft:polished_blackstone_bricks
fill 315 215 466 315 216 466 minecraft:polished_blackstone_bricks
fill 315 215 468 315 216 468 minecraft:polished_blackstone_bricks
fill 315 215 470 315 216 470 minecraft:polished_blackstone_bricks
fill 315 215 472 315 216 472 minecraft:polished_blackstone_bricks
fill 316 215 465 316 216 465 minecraft:polished_blackstone_bricks
fill 316 215 467 316 216 467 minecraft:polished_blackstone_bricks
fill 316 215 469 316 216 469 minecraft:polished_blackstone_bricks
fill 316 215 471 316 216 471 minecraft:polished_blackstone_bricks
fill 316 215 473 316 216 473 minecraft:polished_blackstone_bricks
fill 317 215 464 317 216 464 minecraft:polished_blackstone_bricks
fill 317 215 466 317 216 466 minecraft:polished_blackstone_bricks
fill 317 215 468 317 216 468 minecraft:polished_blackstone_bricks
fill 317 215 470 317 216 470 minecraft:polished_blackstone_bricks
fill 317 215 472 317 216 472 minecraft:polished_blackstone_bricks
setblock 317 215 474 minecraft:light[level=14]
setblock 317 215 482 minecraft:light[level=14]
setblock 317 215 490 minecraft:light[level=14]
setblock 317 215 498 minecraft:light[level=14]
fill 318 216 494 318 221 494 minecraft:bone_block
setblock 311 217 464 minecraft:shroomlight
setblock 311 217 466 minecraft:shroomlight
setblock 311 217 468 minecraft:shroomlight
setblock 311 217 470 minecraft:shroomlight
setblock 311 217 472 minecraft:shroomlight
setblock 312 217 465 minecraft:shroomlight
setblock 312 217 467 minecraft:shroomlight
setblock 312 217 469 minecraft:shroomlight
setblock 312 217 471 minecraft:shroomlight
setblock 312 217 473 minecraft:shroomlight
setblock 313 217 464 minecraft:shroomlight
setblock 313 217 466 minecraft:shroomlight
setblock 313 217 468 minecraft:shroomlight
setblock 313 217 470 minecraft:shroomlight
setblock 313 217 472 minecraft:shroomlight
setblock 314 217 465 minecraft:shroomlight
setblock 314 217 467 minecraft:shroomlight
setblock 314 217 469 minecraft:shroomlight
setblock 314 217 471 minecraft:shroomlight
setblock 314 217 473 minecraft:shroomlight
setblock 315 217 464 minecraft:shroomlight
setblock 315 217 466 minecraft:shroomlight
setblock 315 217 468 minecraft:shroomlight
setblock 315 217 470 minecraft:shroomlight
setblock 315 217 472 minecraft:shroomlight
setblock 316 217 465 minecraft:shroomlight
setblock 316 217 467 minecraft:shroomlight
setblock 316 217 469 minecraft:shroomlight
setblock 316 217 471 minecraft:shroomlight
setblock 316 217 473 minecraft:shroomlight
fill 316 217 493 317 220 495 minecraft:bone_block
setblock 317 217 464 minecraft:shroomlight
setblock 317 217 466 minecraft:shroomlight
setblock 317 217 468 minecraft:shroomlight
setblock 317 217 470 minecraft:shroomlight
setblock 317 217 472 minecraft:shroomlight
fill 317 217 492 319 220 492 minecraft:bone_block
fill 317 217 496 319 220 496 minecraft:bone_block
fill 318 217 493 320 220 493 minecraft:bone_block
fill 318 217 495 320 220 495 minecraft:bone_block
fill 319 217 494 320 220 494 minecraft:bone_block
fill 311 218 464 311 219 464 minecraft:polished_blackstone_bricks
fill 311 218 466 311 219 466 minecraft:polished_blackstone_bricks
fill 311 218 468 311 219 468 minecraft:polished_blackstone_bricks
fill 311 218 470 311 219 470 minecraft:polished_blackstone_bricks
fill 311 218 472 311 219 472 minecraft:polished_blackstone_bricks
fill 312 218 465 312 219 465 minecraft:polished_blackstone_bricks
fill 312 218 467 312 219 467 minecraft:polished_blackstone_bricks
fill 312 218 469 312 219 469 minecraft:polished_blackstone_bricks
fill 312 218 471 312 219 471 minecraft:polished_blackstone_bricks
fill 312 218 473 312 219 473 minecraft:polished_blackstone_bricks
fill 313 218 464 313 219 464 minecraft:polished_blackstone_bricks
fill 313 218 466 313 219 466 minecraft:polished_blackstone_bricks
fill 313 218 468 313 219 468 minecraft:polished_blackstone_bricks
fill 313 218 470 313 219 470 minecraft:polished_blackstone_bricks
fill 313 218 472 313 219 472 minecraft:polished_blackstone_bricks
fill 314 218 465 314 219 465 minecraft:polished_blackstone_bricks
fill 314 218 467 314 219 467 minecraft:polished_blackstone_bricks
fill 314 218 469 314 219 469 minecraft:polished_blackstone_bricks
fill 314 218 471 314 219 471 minecraft:polished_blackstone_bricks
fill 314 218 473 314 219 473 minecraft:polished_blackstone_bricks
fill 315 218 464 315 219 464 minecraft:polished_blackstone_bricks
fill 315 218 466 315 219 466 minecraft:polished_blackstone_bricks
fill 315 218 468 315 219 468 minecraft:polished_blackstone_bricks
fill 315 218 470 315 219 470 minecraft:polished_blackstone_bricks
fill 315 218 472 315 219 472 minecraft:polished_blackstone_bricks
fill 316 218 465 316 219 465 minecraft:polished_blackstone_bricks
fill 316 218 467 316 219 467 minecraft:polished_blackstone_bricks
fill 316 218 469 316 219 469 minecraft:polished_blackstone_bricks
fill 316 218 471 316 219 471 minecraft:polished_blackstone_bricks
fill 316 218 473 316 219 473 minecraft:polished_blackstone_bricks
fill 317 218 464 317 219 464 minecraft:polished_blackstone_bricks
fill 317 218 466 317 219 466 minecraft:polished_blackstone_bricks
fill 317 218 468 317 219 468 minecraft:polished_blackstone_bricks
fill 317 218 470 317 219 470 minecraft:polished_blackstone_bricks
fill 317 218 472 317 219 472 minecraft:polished_blackstone_bricks
fill 321 218 471 321 219 477 minecraft:gilded_blackstone
fill 282 219 465 282 222 467 minecraft:nether_bricks
setblock 282 219 468 minecraft:red_nether_bricks
fill 282 219 482 282 222 482 minecraft:nether_bricks
setblock 282 219 483 minecraft:red_nether_bricks
fill 282 219 486 282 222 486 minecraft:nether_bricks
setblock 282 219 487 minecraft:red_nether_bricks
fill 282 219 488 282 219 489 minecraft:nether_bricks
setblock 282 219 499 minecraft:red_nether_bricks
setblock 283 219 505 minecraft:red_nether_bricks
fill 284 219 505 284 222 505 minecraft:nether_bricks
fill 293 219 463 293 222 463 minecraft:nether_bricks
setblock 294 219 463 minecraft:red_nether_bricks
fill 299 219 505 299 222 505 minecraft:nether_bricks
setblock 300 219 505 minecraft:red_nether_bricks
fill 301 219 505 305 219 505 minecraft:nether_bricks
fill 307 219 505 307 223 505 minecraft:nether_bricks
setblock 308 219 505 minecraft:red_nether_bricks
setblock 310 219 505 minecraft:nether_bricks
setblock 311 219 505 minecraft:red_nether_bricks
setblock 314 219 463 minecraft:red_nether_bricks
fill 315 219 463 315 222 463 minecraft:nether_bricks
setblock 321 219 505 minecraft:red_nether_bricks
fill 324 219 468 324 222 468 minecraft:nether_bricks
setblock 324 219 469 minecraft:red_nether_bricks
fill 324 219 480 324 222 480 minecraft:nether_bricks
setblock 324 219 481 minecraft:red_nether_bricks
setblock 324 219 482 minecraft:nether_bricks
fill 324 219 489 324 220 489 minecraft:nether_bricks
setblock 324 219 490 minecraft:red_nether_bricks
setblock 324 219 500 minecraft:red_nether_bricks
fill 324 219 501 324 222 501 minecraft:nether_bricks
setblock 324 219 502 minecraft:red_nether_bricks
setblock 324 219 504 minecraft:red_nether_bricks
fill 282 220 468 282 222 468 minecraft:nether_bricks
fill 282 220 476 282 222 477 minecraft:nether_bricks
setblock 282 220 478 minecraft:red_nether_bricks
fill 282 220 479 282 220 480 minecraft:nether_bricks
fill 282 220 483 282 222 483 minecraft:nether_bricks
fill 282 220 487 282 222 487 minecraft:nether_bricks
setblock 282 220 488 minecraft:red_nether_bricks
fill 282 220 489 282 222 489 minecraft:nether_bricks
setblock 282 220 494 minecraft:nether_bricks
setblock 282 220 495 minecraft:red_nether_bricks
fill 282 220 499 282 222 499 minecraft:nether_bricks
setblock 283 220 505 minecraft:nether_bricks
fill 284 220 473 284 225 475 minecraft:polished_blackstone_bricks
fill 284 220 485 284 225 487 minecraft:polished_blackstone_bricks
fill 284 220 497 284 225 499 minecraft:polished_blackstone_bricks
fill 285 220 463 286 220 463 minecraft:nether_bricks
setblock 285 220 505 minecraft:red_nether_bricks
setblock 287 220 463 minecraft:red_nether_bricks
fill 288 220 463 288 222 463 minecraft:nether_bricks
fill 288 220 505 292 220 505 minecraft:nether_bricks
fill 290 220 503 292 225 503 minecraft:polished_blackstone_bricks
setblock 292 220 463 minecraft:red_nether_bricks
setblock 293 220 505 minecraft:red_nether_bricks
fill 294 220 463 297 222 463 minecraft:nether_bricks
fill 294 220 465 296 225 465 minecraft:polished_blackstone_bricks
setblock 298 220 463 minecraft:red_nether_bricks
fill 299 220 463 299 222 463 minecraft:nether_bricks
fill 300 220 505 302 222 505 minecraft:nether_bricks
fill 302 220 503 304 225 503 minecraft:polished_blackstone_bricks
fill 303 220 505 303 221 505 minecraft:red_nether_bricks
fill 304 220 505 304 222 505 minecraft:nether_bricks
setblock 305 220 505 minecraft:red_nether_bricks
fill 306 220 465 308 225 465 minecraft:polished_blackstone_bricks
fill 308 220 505 308 222 505 minecraft:nether_bricks
setblock 310 220 463 minecraft:nether_bricks
setblock 310 220 505 minecraft:red_nether_bricks
fill 311 220 463 312 220 463 minecraft:red_nether_bricks
setblock 311 220 464 minecraft:shroomlight
setblock 311 220 466 minecraft:shroomlight
setblock 311 220 468 minecraft:shroomlight
setblock 311 220 470 minecraft:shroomlight
setblock 311 220 472 minecraft:shroomlight
fill 311 220 505 311 222 505 minecraft:nether_bricks
setblock 312 220 465 minecraft:shroomlight
setblock 312 220 467 minecraft:shroomlight
setblock 312 220 469 minecraft:shroomlight
setblock 312 220 471 minecraft:shroomlight
setblock 312 220 473 minecraft:shroomlight
setblock 313 220 464 minecraft:shroomlight
setblock 313 220 466 minecraft:shroomlight
setblock 313 220 468 minecraft:shroomlight
setblock 313 220 470 minecraft:shroomlight
setblock 313 220 472 minecraft:shroomlight
fill 314 220 463 314 222 463 minecraft:nether_bricks
setblock 314 220 465 minecraft:shroomlight
setblock 314 220 467 minecraft:shroomlight
setblock 314 220 469 minecraft:shroomlight
setblock 314 220 471 minecraft:shroomlight
setblock 314 220 473 minecraft:shroomlight
fill 314 220 503 316 225 503 minecraft:polished_blackstone_bricks
setblock 315 220 464 minecraft:shroomlight
setblock 315 220 466 minecraft:shroomlight
setblock 315 220 468 minecraft:shroomlight
setblock 315 220 470 minecraft:shroomlight
setblock 315 220 472 minecraft:shroomlight
setblock 316 220 465 minecraft:shroomlight
setblock 316 220 467 minecraft:shroomlight
setblock 316 220 469 minecraft:shroomlight
setblock 316 220 471 minecraft:shroomlight
setblock 316 220 473 minecraft:shroomlight
setblock 317 220 464 minecraft:shroomlight
setblock 317 220 466 minecraft:shroomlight
setblock 317 220 468 minecraft:shroomlight
schedule function dropper:buildpart/114_2 1t
