setblock 511 7 286 minecraft:cobbled_deepslate
fill 511 7 287 511 10 287 minecraft:deepslate_tiles
setblock 511 7 291 minecraft:cobbled_deepslate
fill 511 7 292 511 10 292 minecraft:deepslate_tiles
setblock 511 7 296 minecraft:cobbled_deepslate
fill 511 7 297 511 10 297 minecraft:deepslate_tiles
setblock 511 7 301 minecraft:cobbled_deepslate
fill 511 7 302 511 10 302 minecraft:deepslate_tiles
setblock 511 7 306 minecraft:cobbled_deepslate
fill 511 7 307 511 10 307 minecraft:deepslate_tiles
fill 471 8 276 471 8 279 minecraft:deepslate_tiles
setblock 471 8 280 minecraft:cobbled_deepslate
fill 471 8 281 471 11 281 minecraft:deepslate_tiles
setblock 471 8 285 minecraft:cobbled_deepslate
fill 471 8 286 471 11 286 minecraft:deepslate_tiles
setblock 471 8 290 minecraft:cobbled_deepslate
fill 471 8 291 471 11 291 minecraft:deepslate_tiles
setblock 471 8 295 minecraft:cobbled_deepslate
fill 471 8 296 471 11 296 minecraft:deepslate_tiles
setblock 471 8 300 minecraft:cobbled_deepslate
fill 471 8 301 471 11 301 minecraft:deepslate_tiles
setblock 471 8 305 minecraft:cobbled_deepslate
fill 471 8 306 471 11 306 minecraft:deepslate_tiles
fill 472 8 276 472 8 278 minecraft:deepslate_tiles
setblock 472 8 279 minecraft:cobbled_deepslate
fill 472 8 280 472 11 280 minecraft:deepslate_tiles
setblock 472 8 284 minecraft:cobbled_deepslate
fill 472 8 285 472 11 285 minecraft:deepslate_tiles
setblock 472 8 289 minecraft:cobbled_deepslate
setblock 472 8 290 minecraft:deepslate_tiles
setblock 472 8 295 minecraft:deepslate_tiles
setblock 472 8 299 minecraft:cobbled_deepslate
fill 472 8 300 472 10 300 minecraft:deepslate_tiles
setblock 472 8 304 minecraft:cobbled_deepslate
setblock 473 8 278 minecraft:cobbled_deepslate
fill 473 8 279 473 11 279 minecraft:deepslate_tiles
setblock 473 8 283 minecraft:cobbled_deepslate
fill 473 8 284 473 11 284 minecraft:deepslate_tiles
setblock 474 8 277 minecraft:cobbled_deepslate
fill 474 8 278 474 11 278 minecraft:deepslate_tiles
fill 474 8 282 475 8 282 minecraft:cobbled_deepslate
setblock 475 8 276 minecraft:cobbled_deepslate
fill 475 8 277 475 11 277 minecraft:deepslate_tiles
setblock 475 8 286 minecraft:cobbled_deepslate
fill 476 8 276 479 8 276 minecraft:deepslate_tiles
setblock 477 8 284 minecraft:cobbled_deepslate
setblock 479 8 277 minecraft:cobbled_deepslate
setblock 480 8 276 minecraft:cobbled_deepslate
setblock 480 8 277 minecraft:deepslate_tiles
fill 481 8 276 484 8 276 minecraft:deepslate_tiles
fill 483 8 275 483 13 275 minecraft:cobbled_deepslate
setblock 485 8 276 minecraft:cobbled_deepslate
setblock 485 8 277 minecraft:deepslate_tiles
fill 486 8 276 489 8 276 minecraft:deepslate_tiles
fill 486 8 316 489 8 316 minecraft:deepslate_tiles
fill 488 8 317 489 94 317 minecraft:cobbled_deepslate
setblock 489 8 277 minecraft:cobbled_deepslate
setblock 490 8 276 minecraft:cobbled_deepslate
fill 490 8 277 490 11 277 minecraft:deepslate_tiles
setblock 490 8 315 minecraft:deepslate_tiles
setblock 490 8 316 minecraft:cobbled_deepslate
setblock 490 8 317 minecraft:redstone_block
fill 491 8 276 491 11 276 minecraft:deepslate_tiles
setblock 491 8 315 minecraft:cobbled_deepslate
fill 491 8 316 494 8 316 minecraft:deepslate_tiles
fill 491 8 317 497 26 317 minecraft:cobbled_deepslate
fill 492 8 315 492 11 315 minecraft:deepslate_tiles
setblock 494 8 277 minecraft:cobbled_deepslate
setblock 495 8 276 minecraft:cobbled_deepslate
setblock 495 8 277 minecraft:deepslate_tiles
setblock 495 8 316 minecraft:cobbled_deepslate
fill 496 8 276 496 9 276 minecraft:deepslate_tiles
fill 496 8 316 496 9 316 minecraft:deepslate_tiles
setblock 498 8 317 minecraft:redstone_block
fill 499 8 317 505 37 317 minecraft:cobbled_deepslate
fill 501 8 275 501 79 275 minecraft:cobbled_deepslate
fill 503 8 294 503 11 295 minecraft:white_terracotta
fill 504 8 295 504 11 295 minecraft:white_terracotta
fill 509 8 298 509 9 298 minecraft:deepslate_tiles
setblock 509 8 302 minecraft:cobbled_deepslate
fill 509 8 303 509 11 303 minecraft:deepslate_tiles
setblock 510 8 276 minecraft:cobbled_deepslate
setblock 510 8 280 minecraft:deepslate_tiles
setblock 510 8 281 minecraft:cobbled_deepslate
fill 510 8 282 510 11 282 minecraft:deepslate_tiles
setblock 510 8 286 minecraft:cobbled_deepslate
setblock 510 8 296 minecraft:cobbled_deepslate
fill 510 8 297 510 11 297 minecraft:deepslate_tiles
setblock 510 8 301 minecraft:cobbled_deepslate
fill 510 8 302 510 11 302 minecraft:deepslate_tiles
setblock 510 8 306 minecraft:cobbled_deepslate
fill 510 8 307 510 11 307 minecraft:deepslate_tiles
fill 511 8 276 511 11 276 minecraft:deepslate_tiles
setblock 511 8 280 minecraft:cobbled_deepslate
fill 511 8 281 511 11 281 minecraft:deepslate_tiles
setblock 511 8 285 minecraft:cobbled_deepslate
fill 511 8 286 511 11 286 minecraft:deepslate_tiles
setblock 511 8 290 minecraft:cobbled_deepslate
fill 511 8 291 511 11 291 minecraft:deepslate_tiles
setblock 511 8 295 minecraft:cobbled_deepslate
fill 511 8 296 511 11 296 minecraft:deepslate_tiles
setblock 511 8 300 minecraft:cobbled_deepslate
fill 511 8 301 511 11 301 minecraft:deepslate_tiles
setblock 511 8 305 minecraft:cobbled_deepslate
fill 511 8 306 511 11 306 minecraft:deepslate_tiles
fill 471 9 276 471 9 278 minecraft:deepslate_tiles
setblock 471 9 279 minecraft:cobbled_deepslate
fill 471 9 280 471 12 280 minecraft:deepslate_tiles
setblock 471 9 284 minecraft:cobbled_deepslate
fill 471 9 285 471 12 285 minecraft:deepslate_tiles
setblock 471 9 289 minecraft:cobbled_deepslate
fill 471 9 290 471 12 290 minecraft:deepslate_tiles
setblock 471 9 294 minecraft:cobbled_deepslate
fill 471 9 295 471 12 295 minecraft:deepslate_tiles
setblock 471 9 299 minecraft:cobbled_deepslate
fill 471 9 300 471 12 300 minecraft:deepslate_tiles
setblock 471 9 304 minecraft:cobbled_deepslate
fill 471 9 305 471 12 305 minecraft:deepslate_tiles
setblock 471 9 308 minecraft:deepslate_tiles
fill 472 9 276 472 9 277 minecraft:deepslate_tiles
setblock 472 9 278 minecraft:cobbled_deepslate
fill 472 9 279 472 12 279 minecraft:deepslate_tiles
setblock 472 9 283 minecraft:cobbled_deepslate
fill 472 9 284 472 12 284 minecraft:deepslate_tiles
setblock 472 9 288 minecraft:cobbled_deepslate
fill 472 9 289 472 12 289 minecraft:deepslate_tiles
setblock 472 9 298 minecraft:cobbled_deepslate
fill 472 9 299 472 10 299 minecraft:deepslate_tiles
setblock 472 9 303 minecraft:cobbled_deepslate
fill 472 9 304 472 12 304 minecraft:deepslate_tiles
setblock 473 9 277 minecraft:cobbled_deepslate
fill 473 9 278 473 12 278 minecraft:deepslate_tiles
setblock 473 9 282 minecraft:cobbled_deepslate
fill 473 9 283 473 12 283 minecraft:deepslate_tiles
setblock 474 9 276 minecraft:cobbled_deepslate
fill 474 9 277 474 12 277 minecraft:deepslate_tiles
setblock 474 9 281 minecraft:cobbled_deepslate
fill 475 9 276 478 9 276 minecraft:deepslate_tiles
setblock 478 9 277 minecraft:cobbled_deepslate
setblock 479 9 276 minecraft:cobbled_deepslate
fill 480 9 276 483 9 276 minecraft:deepslate_tiles
setblock 484 9 276 minecraft:cobbled_deepslate
fill 485 9 276 488 9 276 minecraft:deepslate_tiles
fill 486 9 316 488 9 316 minecraft:deepslate_tiles
setblock 488 9 277 minecraft:cobbled_deepslate
setblock 489 9 276 minecraft:cobbled_deepslate
fill 489 9 277 489 12 277 minecraft:deepslate_tiles
setblock 489 9 316 minecraft:cobbled_deepslate
fill 490 9 276 490 12 276 minecraft:deepslate_tiles
setblock 490 9 315 minecraft:cobbled_deepslate
fill 490 9 316 493 9 316 minecraft:deepslate_tiles
fill 490 9 317 490 95 317 minecraft:cobbled_deepslate
fill 491 9 315 491 12 315 minecraft:deepslate_tiles
setblock 493 9 277 minecraft:cobbled_deepslate
setblock 494 9 276 minecraft:cobbled_deepslate
setblock 494 9 277 minecraft:deepslate_tiles
setblock 494 9 316 minecraft:cobbled_deepslate
fill 495 9 276 495 10 276 minecraft:deepslate_tiles
fill 495 9 316 495 10 316 minecraft:deepslate_tiles
fill 498 9 317 498 95 317 minecraft:cobbled_deepslate
fill 502 9 295 502 10 295 minecraft:white_terracotta
fill 503 9 296 504 10 296 minecraft:white_terracotta
fill 504 9 294 504 10 294 minecraft:white_terracotta
setblock 509 9 301 minecraft:cobbled_deepslate
fill 509 9 302 509 12 302 minecraft:deepslate_tiles
fill 510 9 276 510 12 276 minecraft:deepslate_tiles
setblock 510 9 280 minecraft:cobbled_deepslate
fill 510 9 281 510 12 281 minecraft:deepslate_tiles
fill 510 9 283 510 9 284 minecraft:deepslate_tiles
setblock 510 9 285 minecraft:cobbled_deepslate
fill 510 9 286 510 10 288 minecraft:deepslate_tiles
setblock 510 9 295 minecraft:cobbled_deepslate
fill 510 9 296 510 12 296 minecraft:deepslate_tiles
setblock 510 9 300 minecraft:cobbled_deepslate
fill 510 9 301 510 12 301 minecraft:deepslate_tiles
setblock 510 9 305 minecraft:cobbled_deepslate
fill 510 9 306 510 12 306 minecraft:deepslate_tiles
setblock 511 9 279 minecraft:cobbled_deepslate
fill 511 9 280 511 12 280 minecraft:deepslate_tiles
setblock 511 9 284 minecraft:cobbled_deepslate
fill 511 9 285 511 12 285 minecraft:deepslate_tiles
setblock 511 9 289 minecraft:cobbled_deepslate
fill 511 9 290 511 12 290 minecraft:deepslate_tiles
setblock 511 9 294 minecraft:cobbled_deepslate
fill 511 9 295 511 12 295 minecraft:deepslate_tiles
setblock 511 9 299 minecraft:cobbled_deepslate
fill 511 9 300 511 12 300 minecraft:deepslate_tiles
setblock 511 9 304 minecraft:cobbled_deepslate
fill 511 9 305 511 12 305 minecraft:deepslate_tiles
setblock 511 9 309 minecraft:cobbled_deepslate
fill 471 10 276 471 10 277 minecraft:deepslate_tiles
setblock 471 10 278 minecraft:cobbled_deepslate
fill 471 10 279 471 13 279 minecraft:deepslate_tiles
setblock 471 10 283 minecraft:cobbled_deepslate
fill 471 10 284 471 13 284 minecraft:deepslate_tiles
setblock 471 10 288 minecraft:cobbled_deepslate
fill 471 10 289 471 13 289 minecraft:deepslate_tiles
setblock 471 10 293 minecraft:cobbled_deepslate
fill 471 10 294 471 13 294 minecraft:deepslate_tiles
setblock 471 10 298 minecraft:cobbled_deepslate
fill 471 10 299 471 13 299 minecraft:deepslate_tiles
setblock 471 10 303 minecraft:cobbled_deepslate
fill 471 10 304 471 13 304 minecraft:deepslate_tiles
setblock 471 10 308 minecraft:cobbled_deepslate
setblock 472 10 276 minecraft:deepslate_tiles
setblock 472 10 277 minecraft:cobbled_deepslate
fill 472 10 278 472 13 278 minecraft:deepslate_tiles
setblock 472 10 282 minecraft:cobbled_deepslate
fill 472 10 283 472 13 283 minecraft:deepslate_tiles
setblock 472 10 287 minecraft:cobbled_deepslate
fill 472 10 288 472 13 288 minecraft:deepslate_tiles
fill 472 10 290 472 11 290 minecraft:deepslate_tiles
setblock 472 10 302 minecraft:cobbled_deepslate
fill 472 10 303 472 13 303 minecraft:deepslate_tiles
fill 472 10 305 472 11 305 minecraft:deepslate_tiles
setblock 473 10 276 minecraft:cobbled_deepslate
fill 473 10 277 473 13 277 minecraft:deepslate_tiles
setblock 473 10 281 minecraft:cobbled_deepslate
fill 473 10 282 473 13 282 minecraft:deepslate_tiles
setblock 473 10 286 minecraft:cobbled_deepslate
fill 474 10 276 477 10 276 minecraft:deepslate_tiles
setblock 477 10 277 minecraft:cobbled_deepslate
setblock 478 10 276 minecraft:cobbled_deepslate
fill 479 10 276 482 10 276 minecraft:deepslate_tiles
fill 480 10 306 480 11 307 minecraft:white_wool
setblock 483 10 276 minecraft:cobbled_deepslate
fill 484 10 276 487 10 276 minecraft:deepslate_tiles
fill 486 10 316 487 10 316 minecraft:deepslate_tiles
setblock 487 10 277 minecraft:cobbled_deepslate
setblock 488 10 276 minecraft:cobbled_deepslate
fill 488 10 277 488 13 277 minecraft:deepslate_tiles
setblock 488 10 316 minecraft:cobbled_deepslate
fill 489 10 276 489 13 276 minecraft:deepslate_tiles
fill 489 10 316 492 10 316 minecraft:deepslate_tiles
fill 490 10 315 490 13 315 minecraft:deepslate_tiles
setblock 492 10 277 minecraft:cobbled_deepslate
setblock 493 10 276 minecraft:cobbled_deepslate
setblock 493 10 316 minecraft:cobbled_deepslate
fill 494 10 276 494 11 276 minecraft:deepslate_tiles
fill 494 10 316 494 13 316 minecraft:deepslate_tiles
setblock 509 10 300 minecraft:cobbled_deepslate
fill 509 10 301 509 13 301 minecraft:deepslate_tiles
setblock 509 10 305 minecraft:cobbled_deepslate
setblock 510 10 279 minecraft:cobbled_deepslate
fill 510 10 280 510 13 280 minecraft:deepslate_tiles
setblock 510 10 283 minecraft:deepslate_tiles
setblock 510 10 284 minecraft:cobbled_deepslate
fill 510 10 285 510 13 285 minecraft:deepslate_tiles
setblock 510 10 289 minecraft:cobbled_deepslate
fill 510 10 290 510 11 292 minecraft:deepslate_tiles
setblock 510 10 294 minecraft:cobbled_deepslate
fill 510 10 295 510 13 295 minecraft:deepslate_tiles
setblock 510 10 299 minecraft:cobbled_deepslate
fill 510 10 300 510 13 300 minecraft:deepslate_tiles
setblock 510 10 304 minecraft:cobbled_deepslate
fill 510 10 305 510 13 305 minecraft:deepslate_tiles
setblock 511 10 278 minecraft:cobbled_deepslate
fill 511 10 279 511 13 279 minecraft:deepslate_tiles
setblock 511 10 283 minecraft:cobbled_deepslate
fill 511 10 284 511 13 284 minecraft:deepslate_tiles
setblock 511 10 288 minecraft:cobbled_deepslate
fill 511 10 289 511 13 289 minecraft:deepslate_tiles
setblock 511 10 293 minecraft:cobbled_deepslate
fill 511 10 294 511 13 294 minecraft:deepslate_tiles
setblock 511 10 298 minecraft:cobbled_deepslate
fill 511 10 299 511 13 299 minecraft:deepslate_tiles
setblock 511 10 303 minecraft:cobbled_deepslate
fill 511 10 304 511 13 304 minecraft:deepslate_tiles
setblock 511 10 308 minecraft:cobbled_deepslate
fill 511 10 309 511 12 310 minecraft:deepslate_tiles
setblock 471 11 276 minecraft:deepslate_tiles
setblock 471 11 277 minecraft:cobbled_deepslate
fill 471 11 278 471 14 278 minecraft:deepslate_tiles
setblock 471 11 282 minecraft:cobbled_deepslate
fill 471 11 283 471 14 283 minecraft:deepslate_tiles
setblock 471 11 287 minecraft:cobbled_deepslate
fill 471 11 288 471 14 288 minecraft:deepslate_tiles
setblock 471 11 292 minecraft:cobbled_deepslate
fill 471 11 293 471 14 293 minecraft:deepslate_tiles
setblock 471 11 297 minecraft:cobbled_deepslate
fill 471 11 298 471 14 298 minecraft:deepslate_tiles
setblock 471 11 302 minecraft:cobbled_deepslate
fill 471 11 303 471 14 303 minecraft:deepslate_tiles
setblock 471 11 307 minecraft:cobbled_deepslate
fill 471 11 308 471 13 309 minecraft:deepslate_tiles
setblock 472 11 276 minecraft:cobbled_deepslate
fill 472 11 277 472 14 277 minecraft:deepslate_tiles
setblock 472 11 281 minecraft:cobbled_deepslate
fill 472 11 282 472 14 282 minecraft:deepslate_tiles
setblock 472 11 286 minecraft:cobbled_deepslate
fill 472 11 287 473 13 287 minecraft:deepslate_tiles
setblock 472 11 301 minecraft:cobbled_deepslate
fill 472 11 302 472 12 302 minecraft:deepslate_tiles
fill 473 11 276 476 11 276 minecraft:deepslate_tiles
setblock 473 11 280 minecraft:cobbled_deepslate
fill 473 11 281 473 14 281 minecraft:deepslate_tiles
setblock 473 11 285 minecraft:cobbled_deepslate
fill 473 11 286 473 14 286 minecraft:deepslate_tiles
fill 475 11 281 475 25 281 minecraft:white_wool
setblock 476 11 277 minecraft:cobbled_deepslate
setblock 477 11 276 minecraft:cobbled_deepslate
fill 478 11 276 479 11 276 minecraft:deepslate_tiles
fill 483 11 276 486 11 276 minecraft:deepslate_tiles
fill 485 11 316 486 11 316 minecraft:deepslate_tiles
setblock 487 11 276 minecraft:cobbled_deepslate
fill 487 11 277 487 14 277 minecraft:deepslate_tiles
setblock 487 11 316 minecraft:cobbled_deepslate
fill 488 11 276 488 14 276 minecraft:deepslate_tiles
fill 488 11 316 491 11 316 minecraft:deepslate_tiles
fill 489 11 315 489 14 315 minecraft:deepslate_tiles
setblock 491 11 277 minecraft:cobbled_deepslate
setblock 492 11 276 minecraft:cobbled_deepslate
setblock 492 11 316 minecraft:cobbled_deepslate
fill 493 11 276 493 12 276 minecraft:deepslate_tiles
fill 493 11 316 493 14 316 minecraft:deepslate_tiles
fill 505 11 294 505 14 294 minecraft:black_concrete
fill 506 11 293 506 14 293 minecraft:black_concrete
fill 506 11 295 506 14 295 minecraft:black_concrete
fill 507 11 294 507 14 294 minecraft:black_concrete
fill 509 11 276 509 13 276 minecraft:deepslate_tiles
fill 509 11 282 509 11 283 minecraft:deepslate_tiles
setblock 509 11 284 minecraft:cobbled_deepslate
fill 509 11 285 509 13 286 minecraft:deepslate_tiles
setblock 509 11 299 minecraft:cobbled_deepslate
fill 509 11 300 509 14 300 minecraft:deepslate_tiles
setblock 509 11 304 minecraft:cobbled_deepslate
fill 509 11 305 509 13 306 minecraft:deepslate_tiles
setblock 510 11 278 minecraft:cobbled_deepslate
fill 510 11 279 510 14 279 minecraft:deepslate_tiles
setblock 510 11 283 minecraft:cobbled_deepslate
fill 510 11 284 510 14 284 minecraft:deepslate_tiles
fill 510 11 286 510 11 287 minecraft:deepslate_tiles
setblock 510 11 288 minecraft:cobbled_deepslate
fill 510 11 289 510 14 289 minecraft:deepslate_tiles
setblock 510 11 293 minecraft:cobbled_deepslate
fill 510 11 294 510 14 294 minecraft:deepslate_tiles
setblock 510 11 298 minecraft:cobbled_deepslate
fill 510 11 299 510 14 299 minecraft:deepslate_tiles
setblock 510 11 303 minecraft:cobbled_deepslate
fill 510 11 304 510 14 304 minecraft:deepslate_tiles
setblock 510 11 308 minecraft:cobbled_deepslate
setblock 511 11 277 minecraft:cobbled_deepslate
fill 511 11 278 511 14 278 minecraft:deepslate_tiles
setblock 511 11 282 minecraft:cobbled_deepslate
fill 511 11 283 511 14 283 minecraft:deepslate_tiles
setblock 511 11 287 minecraft:cobbled_deepslate
fill 511 11 288 511 14 288 minecraft:deepslate_tiles
setblock 511 11 292 minecraft:cobbled_deepslate
fill 511 11 293 511 14 293 minecraft:deepslate_tiles
setblock 511 11 297 minecraft:cobbled_deepslate
fill 511 11 298 511 14 298 minecraft:deepslate_tiles
setblock 511 11 302 minecraft:cobbled_deepslate
fill 511 11 303 511 14 303 minecraft:deepslate_tiles
setblock 511 11 307 minecraft:cobbled_deepslate
fill 511 11 308 511 14 308 minecraft:deepslate_tiles
setblock 471 12 276 minecraft:cobbled_deepslate
fill 471 12 277 471 15 277 minecraft:deepslate_tiles
setblock 471 12 281 minecraft:cobbled_deepslate
fill 471 12 282 471 15 282 minecraft:deepslate_tiles
setblock 471 12 286 minecraft:cobbled_deepslate
fill 471 12 287 471 15 287 minecraft:deepslate_tiles
setblock 471 12 291 minecraft:cobbled_deepslate
fill 471 12 292 471 15 292 minecraft:deepslate_tiles
setblock 471 12 296 minecraft:cobbled_deepslate
fill 471 12 297 471 15 297 minecraft:deepslate_tiles
setblock 471 12 301 minecraft:cobbled_deepslate
fill 471 12 302 471 15 302 minecraft:deepslate_tiles
setblock 471 12 306 minecraft:cobbled_deepslate
fill 471 12 307 471 15 307 minecraft:deepslate_tiles
setblock 471 12 310 minecraft:deepslate_tiles
setblock 471 12 311 minecraft:cobbled_deepslate
fill 472 12 276 475 12 276 minecraft:deepslate_tiles
setblock 472 12 280 minecraft:cobbled_deepslate
fill 472 12 281 472 15 281 minecraft:deepslate_tiles
setblock 472 12 285 minecraft:cobbled_deepslate
fill 472 12 286 472 15 286 minecraft:deepslate_tiles
setblock 472 12 290 minecraft:cobbled_deepslate
setblock 472 12 305 minecraft:cobbled_deepslate
fill 472 12 306 472 15 306 minecraft:deepslate_tiles
setblock 473 12 279 minecraft:cobbled_deepslate
fill 473 12 280 473 15 280 minecraft:deepslate_tiles
setblock 473 12 284 minecraft:cobbled_deepslate
fill 473 12 285 473 15 285 minecraft:deepslate_tiles
setblock 475 12 277 minecraft:cobbled_deepslate
setblock 476 12 276 minecraft:cobbled_deepslate
fill 477 12 276 478 14 276 minecraft:deepslate_tiles
fill 483 12 276 485 12 276 minecraft:deepslate_tiles
setblock 485 12 316 minecraft:deepslate_tiles
setblock 486 12 276 minecraft:cobbled_deepslate
setblock 486 12 316 minecraft:cobbled_deepslate
fill 487 12 276 487 15 276 minecraft:deepslate_tiles
setblock 487 12 315 minecraft:cobbled_deepslate
fill 487 12 316 490 12 316 minecraft:deepslate_tiles
fill 488 12 315 488 15 315 minecraft:deepslate_tiles
setblock 490 12 277 minecraft:cobbled_deepslate
setblock 491 12 276 minecraft:cobbled_deepslate
setblock 491 12 277 minecraft:deepslate_tiles
setblock 491 12 316 minecraft:cobbled_deepslate
fill 492 12 276 492 15 276 minecraft:deepslate_tiles
setblock 492 12 315 minecraft:cobbled_deepslate
fill 492 12 316 492 15 316 minecraft:deepslate_tiles
fill 503 12 295 503 15 295 minecraft:white_wool
fill 509 12 281 509 12 282 minecraft:deepslate_tiles
setblock 509 12 283 minecraft:cobbled_deepslate
fill 509 12 284 509 15 284 minecraft:deepslate_tiles
setblock 509 12 287 minecraft:deepslate_tiles
setblock 509 12 288 minecraft:cobbled_deepslate
fill 509 12 289 509 15 289 minecraft:deepslate_tiles
fill 509 12 299 509 15 299 minecraft:deepslate_tiles
setblock 509 12 303 minecraft:cobbled_deepslate
fill 509 12 304 509 15 304 minecraft:deepslate_tiles
setblock 509 12 307 minecraft:deepslate_tiles
fill 510 12 278 510 15 278 minecraft:deepslate_tiles
setblock 510 12 282 minecraft:cobbled_deepslate
fill 510 12 283 510 15 283 minecraft:deepslate_tiles
setblock 510 12 286 minecraft:deepslate_tiles
setblock 510 12 287 minecraft:cobbled_deepslate
fill 510 12 288 510 15 288 minecraft:deepslate_tiles
fill 510 12 290 510 12 291 minecraft:deepslate_tiles
setblock 510 12 292 minecraft:cobbled_deepslate
fill 510 12 293 510 15 293 minecraft:deepslate_tiles
setblock 510 12 297 minecraft:cobbled_deepslate
fill 510 12 298 510 15 298 minecraft:deepslate_tiles
setblock 510 12 302 minecraft:cobbled_deepslate
fill 510 12 303 510 15 303 minecraft:deepslate_tiles
setblock 510 12 307 minecraft:cobbled_deepslate
fill 510 12 308 510 14 309 minecraft:deepslate_tiles
setblock 511 12 276 minecraft:cobbled_deepslate
fill 511 12 277 511 15 277 minecraft:deepslate_tiles
setblock 511 12 281 minecraft:cobbled_deepslate
fill 511 12 282 511 15 282 minecraft:deepslate_tiles
setblock 511 12 286 minecraft:cobbled_deepslate
fill 511 12 287 511 15 287 minecraft:deepslate_tiles
setblock 511 12 291 minecraft:cobbled_deepslate
fill 511 12 292 511 15 292 minecraft:deepslate_tiles
setblock 511 12 296 minecraft:cobbled_deepslate
fill 511 12 297 511 15 297 minecraft:deepslate_tiles
setblock 511 12 301 minecraft:cobbled_deepslate
fill 511 12 302 511 15 302 minecraft:deepslate_tiles
setblock 511 12 306 minecraft:cobbled_deepslate
fill 511 12 307 511 15 307 minecraft:deepslate_tiles
setblock 511 12 311 minecraft:cobbled_deepslate
fill 471 13 276 474 13 276 minecraft:deepslate_tiles
setblock 471 13 280 minecraft:cobbled_deepslate
fill 471 13 281 471 16 281 minecraft:deepslate_tiles
setblock 471 13 285 minecraft:cobbled_deepslate
fill 471 13 286 471 16 286 minecraft:deepslate_tiles
setblock 471 13 290 minecraft:cobbled_deepslate
fill 471 13 291 472 15 291 minecraft:deepslate_tiles
setblock 471 13 295 minecraft:cobbled_deepslate
fill 471 13 296 471 16 296 minecraft:deepslate_tiles
setblock 471 13 300 minecraft:cobbled_deepslate
fill 471 13 301 471 16 301 minecraft:deepslate_tiles
setblock 471 13 305 minecraft:cobbled_deepslate
fill 471 13 306 471 16 306 minecraft:deepslate_tiles
setblock 471 13 310 minecraft:cobbled_deepslate
fill 471 13 311 471 13 314 minecraft:deepslate_tiles
fill 471 13 316 471 16 316 minecraft:deepslate_tiles
setblock 472 13 279 minecraft:cobbled_deepslate
fill 472 13 280 472 16 280 minecraft:deepslate_tiles
setblock 472 13 284 minecraft:cobbled_deepslate
fill 472 13 285 472 16 285 minecraft:deepslate_tiles
setblock 472 13 289 minecraft:cobbled_deepslate
fill 472 13 290 472 16 290 minecraft:deepslate_tiles
setblock 472 13 304 minecraft:cobbled_deepslate
fill 472 13 305 472 16 305 minecraft:deepslate_tiles
fill 472 13 307 472 13 308 minecraft:deepslate_tiles
setblock 473 13 278 minecraft:light[level=13]
fill 473 13 279 473 14 279 minecraft:deepslate_tiles
setblock 473 13 283 minecraft:cobbled_deepslate
fill 473 13 284 473 16 284 minecraft:deepslate_tiles
setblock 473 13 288 minecraft:cobbled_deepslate
setblock 473 13 292 minecraft:light[level=12]
setblock 473 13 294 minecraft:light[level=13]
setblock 473 13 299 minecraft:light[level=12]
setblock 473 13 302 minecraft:light[level=13]
setblock 473 13 306 minecraft:light[level=12]
setblock 473 13 310 minecraft:light[level=13]
setblock 473 13 313 minecraft:light[level=12]
setblock 474 13 277 minecraft:cobbled_deepslate
setblock 475 13 276 minecraft:cobbled_deepslate
setblock 475 13 277 minecraft:deepslate_tiles
fill 476 13 276 476 16 276 minecraft:deepslate_tiles
setblock 480 13 278 minecraft:light[level=12]
setblock 480 13 285 minecraft:light[level=12]
setblock 480 13 292 minecraft:light[level=12]
setblock 480 13 299 minecraft:light[level=12]
setblock 480 13 306 minecraft:light[level=12]
setblock 480 13 313 minecraft:light[level=12]
setblock 481 13 278 minecraft:light[level=13]
setblock 481 13 286 minecraft:light[level=13]
setblock 481 13 294 minecraft:light[level=13]
setblock 481 13 302 minecraft:light[level=13]
setblock 481 13 310 minecraft:light[level=13]
fill 482 13 276 484 13 276 minecraft:deepslate_tiles
fill 483 13 316 484 13 316 minecraft:deepslate_tiles
setblock 485 13 276 minecraft:cobbled_deepslate
setblock 485 13 316 minecraft:cobbled_deepslate
fill 486 13 276 486 15 277 minecraft:deepslate_tiles
setblock 486 13 315 minecraft:cobbled_deepslate
fill 486 13 316 489 13 316 minecraft:deepslate_tiles
setblock 487 13 278 minecraft:light[level=12]
setblock 487 13 285 minecraft:light[level=12]
setblock 487 13 292 minecraft:light[level=12]
setblock 487 13 299 minecraft:light[level=12]
setblock 487 13 306 minecraft:light[level=12]
setblock 487 13 313 minecraft:light[level=12]
fill 487 13 315 487 16 315 minecraft:deepslate_tiles
setblock 489 13 277 minecraft:cobbled_deepslate
setblock 489 13 278 minecraft:light[level=13]
setblock 489 13 286 minecraft:light[level=13]
setblock 489 13 294 minecraft:light[level=13]
setblock 489 13 302 minecraft:light[level=13]
setblock 489 13 310 minecraft:light[level=13]
setblock 490 13 276 minecraft:cobbled_deepslate
setblock 490 13 277 minecraft:deepslate_tiles
setblock 490 13 316 minecraft:cobbled_deepslate
fill 491 13 276 491 16 276 minecraft:deepslate_tiles
setblock 491 13 315 minecraft:cobbled_deepslate
fill 491 13 316 491 16 316 minecraft:deepslate_tiles
fill 492 13 315 492 16 315 minecraft:deepslate_tiles
setblock 494 13 278 minecraft:light[level=12]
setblock 494 13 285 minecraft:light[level=12]
setblock 494 13 292 minecraft:light[level=12]
setblock 494 13 299 minecraft:light[level=12]
setblock 494 13 306 minecraft:light[level=12]
setblock 494 13 313 minecraft:light[level=12]
fill 495 13 306 495 14 307 minecraft:white_wool
setblock 497 13 278 minecraft:light[level=13]
setblock 497 13 286 minecraft:light[level=13]
setblock 497 13 294 minecraft:light[level=13]
setblock 497 13 302 minecraft:light[level=13]
setblock 497 13 310 minecraft:light[level=13]
setblock 501 13 278 minecraft:light[level=12]
setblock 501 13 285 minecraft:light[level=12]
setblock 501 13 292 minecraft:light[level=12]
setblock 501 13 299 minecraft:light[level=12]
setblock 501 13 306 minecraft:light[level=12]
setblock 501 13 313 minecraft:light[level=12]
setblock 505 13 278 minecraft:light[level=13]
setblock 505 13 286 minecraft:light[level=13]
setblock 505 13 302 minecraft:light[level=13]
setblock 505 13 310 minecraft:light[level=13]
fill 507 13 279 507 34 279 minecraft:white_wool
fill 508 13 276 508 14 276 minecraft:deepslate_tiles
setblock 508 13 278 minecraft:light[level=12]
setblock 508 13 285 minecraft:light[level=12]
fill 508 13 292 508 15 292 minecraft:black_concrete
setblock 508 13 299 minecraft:light[level=12]
setblock 508 13 306 minecraft:light[level=12]
setblock 508 13 313 minecraft:light[level=12]
fill 509 13 280 509 13 281 minecraft:deepslate_tiles
setblock 509 13 282 minecraft:cobbled_deepslate
fill 509 13 283 509 16 283 minecraft:deepslate_tiles
setblock 509 13 287 minecraft:cobbled_deepslate
fill 509 13 288 509 16 288 minecraft:deepslate_tiles
fill 509 13 290 509 13 291 minecraft:deepslate_tiles
setblock 509 13 302 minecraft:cobbled_deepslate
fill 509 13 303 509 16 303 minecraft:deepslate_tiles
setblock 509 13 307 minecraft:cobbled_deepslate
fill 509 13 308 509 16 308 minecraft:deepslate_tiles
setblock 510 13 276 minecraft:cobbled_deepslate
setblock 510 13 281 minecraft:cobbled_deepslate
fill 510 13 282 510 16 282 minecraft:deepslate_tiles
setblock 510 13 286 minecraft:cobbled_deepslate
fill 510 13 287 510 16 287 minecraft:deepslate_tiles
setblock 510 13 290 minecraft:deepslate_tiles
setblock 510 13 291 minecraft:cobbled_deepslate
fill 510 13 292 510 16 292 minecraft:deepslate_tiles
setblock 510 13 296 minecraft:cobbled_deepslate
fill 510 13 297 510 16 297 minecraft:deepslate_tiles
setblock 510 13 301 minecraft:cobbled_deepslate
fill 510 13 302 510 16 302 minecraft:deepslate_tiles
setblock 510 13 306 minecraft:cobbled_deepslate
fill 510 13 307 510 16 307 minecraft:deepslate_tiles
setblock 510 13 310 minecraft:deepslate_tiles
fill 511 13 276 511 16 276 minecraft:deepslate_tiles
setblock 511 13 280 minecraft:cobbled_deepslate
fill 511 13 281 511 16 281 minecraft:deepslate_tiles
setblock 511 13 285 minecraft:cobbled_deepslate
fill 511 13 286 511 16 286 minecraft:deepslate_tiles
fill 511 13 290 512 13 290 minecraft:cobbled_deepslate
fill 511 13 291 511 16 291 minecraft:deepslate_tiles
setblock 511 13 295 minecraft:cobbled_deepslate
fill 511 13 296 511 16 296 minecraft:deepslate_tiles
setblock 511 13 300 minecraft:cobbled_deepslate
fill 511 13 301 511 16 301 minecraft:deepslate_tiles
setblock 511 13 305 minecraft:cobbled_deepslate
fill 511 13 306 511 16 306 minecraft:deepslate_tiles
setblock 511 13 309 minecraft:deepslate_tiles
setblock 511 13 310 minecraft:cobbled_deepslate
fill 511 13 311 511 15 312 minecraft:deepslate_tiles
setblock 512 13 291 minecraft:white_wool
fill 471 14 276 473 14 276 minecraft:deepslate_tiles
setblock 471 14 279 minecraft:cobbled_deepslate
fill 471 14 280 471 17 280 minecraft:deepslate_tiles
setblock 471 14 284 minecraft:cobbled_deepslate
fill 471 14 285 471 17 285 minecraft:deepslate_tiles
setblock 471 14 289 minecraft:cobbled_deepslate
fill 471 14 290 471 17 290 minecraft:deepslate_tiles
setblock 471 14 294 minecraft:cobbled_deepslate
fill 471 14 295 471 17 295 minecraft:deepslate_tiles
setblock 471 14 299 minecraft:cobbled_deepslate
fill 471 14 300 471 16 300 minecraft:deepslate_tiles
setblock 471 14 304 minecraft:cobbled_deepslate
fill 471 14 305 471 17 305 minecraft:deepslate_tiles
setblock 471 14 308 minecraft:deepslate_tiles
setblock 471 14 309 minecraft:cobbled_deepslate
fill 471 14 310 471 14 313 minecraft:deepslate_tiles
setblock 471 14 314 minecraft:cobbled_deepslate
fill 471 14 315 471 17 315 minecraft:deepslate_tiles
setblock 472 14 278 minecraft:cobbled_deepslate
fill 472 14 279 472 17 279 minecraft:deepslate_tiles
setblock 472 14 283 minecraft:cobbled_deepslate
fill 472 14 284 472 17 284 minecraft:deepslate_tiles
setblock 472 14 287 minecraft:deepslate_tiles
setblock 472 14 288 minecraft:cobbled_deepslate
fill 472 14 289 472 17 289 minecraft:deepslate_tiles
setblock 472 14 303 minecraft:cobbled_deepslate
fill 472 14 304 472 15 304 minecraft:deepslate_tiles
setblock 472 14 307 minecraft:deepslate_tiles
setblock 472 14 308 minecraft:cobbled_deepslate
fill 472 14 309 472 17 309 minecraft:deepslate_tiles
fill 472 14 316 473 14 316 minecraft:deepslate_tiles
setblock 473 14 277 minecraft:cobbled_deepslate
setblock 473 14 282 minecraft:cobbled_deepslate
fill 473 14 283 473 17 283 minecraft:deepslate_tiles
setblock 473 14 287 minecraft:cobbled_deepslate
fill 473 14 288 473 17 288 minecraft:deepslate_tiles
setblock 474 14 276 minecraft:cobbled_deepslate
fill 474 14 277 474 15 277 minecraft:deepslate_tiles
fill 475 14 276 475 17 276 minecraft:deepslate_tiles
fill 481 14 276 483 14 276 minecraft:deepslate_tiles
fill 482 14 316 483 14 316 minecraft:deepslate_tiles
setblock 483 14 275 minecraft:redstone_block
setblock 484 14 276 minecraft:cobbled_deepslate
setblock 484 14 316 minecraft:cobbled_deepslate
fill 485 14 276 485 16 277 minecraft:deepslate_tiles
setblock 485 14 315 minecraft:cobbled_deepslate
fill 485 14 316 488 14 316 minecraft:deepslate_tiles
fill 486 14 315 486 17 315 minecraft:deepslate_tiles
fill 487 14 314 490 14 314 minecraft:deepslate_tiles
setblock 488 14 277 minecraft:cobbled_deepslate
setblock 489 14 276 minecraft:cobbled_deepslate
fill 489 14 277 489 15 277 minecraft:deepslate_tiles
setblock 489 14 316 minecraft:cobbled_deepslate
fill 490 14 276 490 17 276 minecraft:deepslate_tiles
setblock 490 14 315 minecraft:cobbled_deepslate
fill 490 14 316 490 17 316 minecraft:deepslate_tiles
fill 491 14 314 492 14 314 minecraft:white_wool
fill 491 14 315 491 17 315 minecraft:deepslate_tiles
setblock 494 14 316 minecraft:cobbled_deepslate
setblock 505 14 293 minecraft:black_concrete
setblock 505 14 295 minecraft:black_concrete
fill 507 14 276 507 15 276 minecraft:deepslate_tiles
setblock 507 14 293 minecraft:black_concrete
setblock 507 14 295 minecraft:black_concrete
fill 508 14 283 508 14 286 minecraft:deepslate_tiles
setblock 508 14 287 minecraft:cobbled_deepslate
fill 508 14 288 508 16 289 minecraft:deepslate_tiles
setblock 509 14 276 minecraft:cobbled_deepslate
setblock 509 14 280 minecraft:deepslate_tiles
setblock 509 14 281 minecraft:cobbled_deepslate
fill 509 14 282 509 17 282 minecraft:deepslate_tiles
setblock 509 14 285 minecraft:deepslate_tiles
setblock 509 14 286 minecraft:cobbled_deepslate
fill 509 14 287 509 17 287 minecraft:deepslate_tiles
setblock 509 14 290 minecraft:deepslate_tiles
setblock 509 14 291 minecraft:cobbled_deepslate
fill 509 14 292 509 16 293 minecraft:deepslate_tiles
setblock 509 14 301 minecraft:cobbled_deepslate
fill 509 14 302 509 16 302 minecraft:deepslate_tiles
setblock 509 14 305 minecraft:deepslate_tiles
setblock 509 14 306 minecraft:cobbled_deepslate
fill 509 14 307 509 17 307 minecraft:deepslate_tiles
fill 509 14 309 509 15 309 minecraft:deepslate_tiles
fill 510 14 276 510 17 276 minecraft:deepslate_tiles
setblock 510 14 280 minecraft:cobbled_deepslate
fill 510 14 281 510 17 281 minecraft:deepslate_tiles
setblock 510 14 285 minecraft:cobbled_deepslate
fill 510 14 286 510 17 286 minecraft:deepslate_tiles
setblock 510 14 290 minecraft:cobbled_deepslate
fill 510 14 291 510 17 291 minecraft:deepslate_tiles
setblock 510 14 295 minecraft:cobbled_deepslate
fill 510 14 296 510 17 296 minecraft:deepslate_tiles
setblock 510 14 300 minecraft:cobbled_deepslate
fill 510 14 301 510 17 301 minecraft:deepslate_tiles
setblock 510 14 305 minecraft:cobbled_deepslate
fill 510 14 306 510 17 306 minecraft:deepslate_tiles
setblock 510 14 310 minecraft:cobbled_deepslate
fill 510 14 311 510 17 311 minecraft:deepslate_tiles
setblock 511 14 279 minecraft:cobbled_deepslate
fill 511 14 280 511 17 280 minecraft:deepslate_tiles
setblock 511 14 284 minecraft:cobbled_deepslate
fill 511 14 285 511 17 285 minecraft:deepslate_tiles
setblock 511 14 289 minecraft:cobbled_deepslate
fill 511 14 290 511 17 290 minecraft:deepslate_tiles
setblock 511 14 294 minecraft:cobbled_deepslate
fill 511 14 295 511 17 295 minecraft:deepslate_tiles
setblock 511 14 299 minecraft:cobbled_deepslate
fill 511 14 300 511 17 300 minecraft:deepslate_tiles
setblock 511 14 304 minecraft:cobbled_deepslate
fill 511 14 305 511 17 305 minecraft:deepslate_tiles
setblock 511 14 309 minecraft:cobbled_deepslate
fill 511 14 310 511 17 310 minecraft:deepslate_tiles
setblock 511 14 313 minecraft:deepslate_tiles
fill 512 14 290 512 90 291 minecraft:cobbled_deepslate
fill 470 15 275 470 69 279 minecraft:cobbled_deepslate
setblock 470 15 280 minecraft:redstone_block
fill 470 15 281 470 90 284 minecraft:cobbled_deepslate
fill 471 15 276 472 15 276 minecraft:deepslate_tiles
setblock 471 15 278 minecraft:cobbled_deepslate
fill 471 15 279 471 18 279 minecraft:deepslate_tiles
setblock 471 15 283 minecraft:cobbled_deepslate
fill 471 15 284 471 18 284 minecraft:deepslate_tiles
setblock 471 15 288 minecraft:cobbled_deepslate
fill 471 15 289 471 18 289 minecraft:deepslate_tiles
setblock 471 15 293 minecraft:cobbled_deepslate
fill 471 15 294 471 18 294 minecraft:deepslate_tiles
setblock 471 15 298 minecraft:cobbled_deepslate
fill 471 15 299 471 16 299 minecraft:deepslate_tiles
setblock 471 15 303 minecraft:cobbled_deepslate
fill 471 15 304 471 18 304 minecraft:deepslate_tiles
setblock 471 15 308 minecraft:cobbled_deepslate
fill 471 15 309 471 15 312 minecraft:deepslate_tiles
setblock 471 15 313 minecraft:cobbled_deepslate
fill 471 15 314 471 18 314 minecraft:deepslate_tiles
setblock 472 15 277 minecraft:cobbled_deepslate
fill 472 15 278 472 18 278 minecraft:deepslate_tiles
setblock 472 15 282 minecraft:cobbled_deepslate
fill 472 15 283 472 18 283 minecraft:deepslate_tiles
setblock 472 15 287 minecraft:cobbled_deepslate
fill 472 15 288 472 18 288 minecraft:deepslate_tiles
setblock 472 15 292 minecraft:cobbled_deepslate
setblock 472 15 307 minecraft:cobbled_deepslate
fill 472 15 308 472 18 308 minecraft:deepslate_tiles
fill 472 15 310 472 15 311 minecraft:deepslate_tiles
setblock 472 15 316 minecraft:deepslate_tiles
setblock 473 15 276 minecraft:cobbled_deepslate
fill 473 15 277 473 16 277 minecraft:deepslate_tiles
setblock 473 15 281 minecraft:cobbled_deepslate
fill 473 15 282 473 17 282 minecraft:deepslate_tiles
setblock 473 15 286 minecraft:cobbled_deepslate
fill 473 15 287 473 18 287 minecraft:deepslate_tiles
setblock 473 15 316 minecraft:cobbled_deepslate
fill 474 15 276 474 18 276 minecraft:deepslate_tiles
setblock 477 15 276 minecraft:deepslate_tiles
setblock 478 15 276 minecraft:cobbled_deepslate
fill 479 15 276 482 15 276 minecraft:deepslate_tiles
fill 480 15 316 482 15 316 minecraft:deepslate_tiles
fill 483 15 275 483 15 276 minecraft:cobbled_deepslate
setblock 483 15 315 minecraft:deepslate_tiles
setblock 483 15 316 minecraft:cobbled_deepslate
fill 484 15 276 484 18 276 minecraft:deepslate_tiles
setblock 484 15 315 minecraft:cobbled_deepslate
fill 484 15 316 487 15 316 minecraft:deepslate_tiles
setblock 485 15 314 minecraft:cobbled_deepslate
fill 485 15 315 485 18 315 minecraft:deepslate_tiles
fill 486 15 314 489 15 314 minecraft:deepslate_tiles
setblock 487 15 277 minecraft:cobbled_deepslate
setblock 488 15 276 minecraft:cobbled_deepslate
fill 488 15 277 488 16 277 minecraft:deepslate_tiles
setblock 488 15 316 minecraft:cobbled_deepslate
fill 489 15 276 489 18 276 minecraft:deepslate_tiles
setblock 489 15 315 minecraft:cobbled_deepslate
fill 489 15 316 489 18 316 minecraft:deepslate_tiles
setblock 490 15 314 minecraft:cobbled_deepslate
fill 490 15 315 490 18 315 minecraft:deepslate_tiles
fill 491 15 314 491 18 314 minecraft:deepslate_tiles
setblock 492 15 314 minecraft:white_wool
setblock 493 15 315 minecraft:deepslate_tiles
setblock 493 15 316 minecraft:cobbled_deepslate
fill 494 15 316 494 17 316 minecraft:deepslate_tiles
fill 496 15 302 498 16 302 minecraft:white_wool
fill 497 15 301 497 16 301 minecraft:white_wool
fill 497 15 303 497 16 303 minecraft:white_wool
setblock 508 15 276 minecraft:cobbled_deepslate
fill 508 15 283 508 15 285 minecraft:deepslate_tiles
setblock 508 15 286 minecraft:cobbled_deepslate
fill 508 15 287 508 18 287 minecraft:deepslate_tiles
setblock 508 15 290 minecraft:deepslate_tiles
setblock 508 15 291 minecraft:cobbled_deepslate
setblock 508 15 316 minecraft:cobbled_deepslate
fill 509 15 276 509 18 276 minecraft:deepslate_tiles
setblock 509 15 280 minecraft:cobbled_deepslate
fill 509 15 281 509 18 281 minecraft:deepslate_tiles
setblock 509 15 285 minecraft:cobbled_deepslate
fill 509 15 286 509 18 286 minecraft:deepslate_tiles
setblock 509 15 290 minecraft:cobbled_deepslate
fill 509 15 291 509 18 291 minecraft:deepslate_tiles
setblock 509 15 294 minecraft:deepslate_tiles
setblock 509 15 295 minecraft:cobbled_deepslate
setblock 509 15 300 minecraft:cobbled_deepslate
fill 509 15 301 509 16 301 minecraft:deepslate_tiles
setblock 509 15 305 minecraft:cobbled_deepslate
fill 509 15 306 509 18 306 minecraft:deepslate_tiles
fill 509 15 316 509 18 316 minecraft:deepslate_tiles
fill 510 15 277 510 16 277 minecraft:deepslate_tiles
setblock 510 15 279 minecraft:cobbled_deepslate
fill 510 15 280 510 18 280 minecraft:deepslate_tiles
setblock 510 15 284 minecraft:cobbled_deepslate
fill 510 15 285 510 18 285 minecraft:deepslate_tiles
setblock 510 15 289 minecraft:cobbled_deepslate
fill 510 15 290 510 18 290 minecraft:deepslate_tiles
setblock 510 15 294 minecraft:cobbled_deepslate
fill 510 15 295 510 18 295 minecraft:deepslate_tiles
setblock 510 15 299 minecraft:cobbled_deepslate
fill 510 15 300 510 17 300 minecraft:deepslate_tiles
setblock 510 15 304 minecraft:cobbled_deepslate
fill 510 15 305 510 18 305 minecraft:deepslate_tiles
setblock 510 15 308 minecraft:deepslate_tiles
setblock 510 15 309 minecraft:cobbled_deepslate
fill 510 15 310 510 18 310 minecraft:deepslate_tiles
fill 510 15 312 510 16 312 minecraft:deepslate_tiles
setblock 511 15 278 minecraft:cobbled_deepslate
fill 511 15 279 511 18 279 minecraft:deepslate_tiles
setblock 511 15 283 minecraft:cobbled_deepslate
fill 511 15 284 511 18 284 minecraft:deepslate_tiles
setblock 511 15 288 minecraft:cobbled_deepslate
fill 511 15 289 511 18 289 minecraft:deepslate_tiles
setblock 511 15 293 minecraft:cobbled_deepslate
fill 511 15 294 511 18 294 minecraft:deepslate_tiles
setblock 511 15 298 minecraft:cobbled_deepslate
fill 511 15 299 511 18 299 minecraft:deepslate_tiles
setblock 511 15 303 minecraft:cobbled_deepslate
fill 511 15 304 511 18 304 minecraft:deepslate_tiles
setblock 511 15 308 minecraft:cobbled_deepslate
fill 511 15 309 511 18 309 minecraft:deepslate_tiles
setblock 511 15 313 minecraft:cobbled_deepslate
fill 511 15 314 511 18 314 minecraft:deepslate_tiles
fill 470 16 280 470 90 280 minecraft:cobbled_deepslate
setblock 471 16 276 minecraft:deepslate_tiles
setblock 471 16 277 minecraft:cobbled_deepslate
fill 471 16 278 471 19 278 minecraft:deepslate_tiles
setblock 471 16 282 minecraft:cobbled_deepslate
fill 471 16 283 471 19 283 minecraft:deepslate_tiles
setblock 471 16 287 minecraft:cobbled_deepslate
fill 471 16 288 471 19 288 minecraft:deepslate_tiles
setblock 471 16 291 minecraft:deepslate_tiles
setblock 471 16 292 minecraft:cobbled_deepslate
fill 471 16 293 471 19 293 minecraft:deepslate_tiles
setblock 471 16 302 minecraft:cobbled_deepslate
fill 471 16 303 471 17 303 minecraft:deepslate_tiles
setblock 471 16 307 minecraft:cobbled_deepslate
fill 471 16 308 471 16 311 minecraft:deepslate_tiles
setblock 471 16 312 minecraft:cobbled_deepslate
fill 471 16 313 471 19 313 minecraft:deepslate_tiles
fill 472 16 275 472 16 276 minecraft:cobbled_deepslate
fill 472 16 277 472 17 277 minecraft:deepslate_tiles
setblock 472 16 281 minecraft:cobbled_deepslate
fill 472 16 282 472 19 282 minecraft:deepslate_tiles
setblock 472 16 286 minecraft:cobbled_deepslate
fill 472 16 287 472 19 287 minecraft:deepslate_tiles
setblock 472 16 291 minecraft:cobbled_deepslate
fill 472 16 292 472 17 292 minecraft:deepslate_tiles
setblock 472 16 306 minecraft:cobbled_deepslate
fill 472 16 307 472 17 307 minecraft:deepslate_tiles
setblock 472 16 310 minecraft:deepslate_tiles
setblock 472 16 311 minecraft:cobbled_deepslate
fill 472 16 312 472 19 312 minecraft:deepslate_tiles
setblock 472 16 316 minecraft:cobbled_deepslate
fill 473 16 275 473 81 275 minecraft:cobbled_deepslate
fill 473 16 276 473 19 276 minecraft:deepslate_tiles
setblock 473 16 281 minecraft:deepslate_tiles
setblock 473 16 285 minecraft:cobbled_deepslate
fill 473 16 286 473 18 286 minecraft:deepslate_tiles
fill 473 16 316 475 17 316 minecraft:deepslate_tiles
setblock 474 16 275 minecraft:redstone_block
fill 475 16 275 483 32 275 minecraft:cobbled_deepslate
setblock 477 16 276 minecraft:cobbled_deepslate
fill 478 16 276 481 16 276 minecraft:deepslate_tiles
fill 479 16 316 481 16 316 minecraft:deepslate_tiles
setblock 482 16 276 minecraft:cobbled_deepslate
setblock 482 16 315 minecraft:deepslate_tiles
setblock 482 16 316 minecraft:cobbled_deepslate
fill 483 16 276 483 19 276 minecraft:deepslate_tiles
setblock 483 16 315 minecraft:cobbled_deepslate
fill 483 16 316 486 16 316 minecraft:deepslate_tiles
setblock 484 16 314 minecraft:cobbled_deepslate
fill 484 16 315 484 19 315 minecraft:deepslate_tiles
fill 485 16 314 488 16 314 minecraft:deepslate_tiles
setblock 486 16 276 minecraft:deepslate_tiles
setblock 486 16 277 minecraft:cobbled_deepslate
fill 486 16 313 489 16 313 minecraft:deepslate_tiles
setblock 487 16 276 minecraft:cobbled_deepslate
fill 487 16 277 487 17 277 minecraft:deepslate_tiles
setblock 487 16 316 minecraft:cobbled_deepslate
fill 488 16 276 488 19 276 minecraft:deepslate_tiles
setblock 488 16 315 minecraft:cobbled_deepslate
fill 488 16 316 488 19 316 minecraft:deepslate_tiles
setblock 489 16 314 minecraft:cobbled_deepslate
fill 489 16 315 489 19 315 minecraft:deepslate_tiles
setblock 490 16 313 minecraft:cobbled_deepslate
fill 490 16 314 490 19 314 minecraft:deepslate_tiles
setblock 492 16 316 minecraft:cobbled_deepslate
setblock 493 16 315 minecraft:cobbled_deepslate
fill 493 16 316 493 19 316 minecraft:deepslate_tiles
setblock 506 16 276 minecraft:deepslate_tiles
setblock 506 16 316 minecraft:deepslate_tiles
setblock 507 16 276 minecraft:cobbled_deepslate
fill 507 16 292 507 18 292 minecraft:black_concrete
setblock 507 16 316 minecraft:cobbled_deepslate
fill 508 16 276 508 19 276 minecraft:deepslate_tiles
fill 508 16 282 508 16 284 minecraft:deepslate_tiles
setblock 508 16 285 minecraft:cobbled_deepslate
fill 508 16 286 508 19 286 minecraft:deepslate_tiles
setblock 508 16 290 minecraft:cobbled_deepslate
fill 508 16 291 508 18 292 minecraft:deepslate_tiles
setblock 508 16 293 minecraft:black_concrete
fill 508 16 316 508 19 316 minecraft:deepslate_tiles
setblock 509 16 277 minecraft:deepslate_tiles
fill 509 16 280 509 17 280 minecraft:deepslate_tiles
setblock 509 16 284 minecraft:cobbled_deepslate
fill 509 16 285 509 19 285 minecraft:deepslate_tiles
setblock 509 16 289 minecraft:cobbled_deepslate
fill 509 16 290 509 19 290 minecraft:deepslate_tiles
setblock 509 16 294 minecraft:cobbled_deepslate
fill 509 16 295 509 18 295 minecraft:deepslate_tiles
setblock 509 16 304 minecraft:cobbled_deepslate
fill 509 16 305 509 17 305 minecraft:deepslate_tiles
setblock 509 16 309 minecraft:cobbled_deepslate
fill 509 16 310 509 18 310 minecraft:deepslate_tiles
setblock 510 16 278 minecraft:cobbled_deepslate
fill 510 16 279 510 18 279 minecraft:deepslate_tiles
setblock 510 16 283 minecraft:cobbled_deepslate
fill 510 16 284 510 19 284 minecraft:deepslate_tiles
setblock 510 16 288 minecraft:cobbled_deepslate
fill 510 16 289 510 19 289 minecraft:deepslate_tiles
setblock 510 16 293 minecraft:cobbled_deepslate
fill 510 16 294 510 19 294 minecraft:deepslate_tiles
setblock 510 16 298 minecraft:cobbled_deepslate
fill 510 16 299 510 17 299 minecraft:deepslate_tiles
setblock 510 16 303 minecraft:cobbled_deepslate
fill 510 16 304 510 18 304 minecraft:deepslate_tiles
setblock 510 16 308 minecraft:cobbled_deepslate
fill 510 16 309 510 19 309 minecraft:deepslate_tiles
fill 510 16 316 510 17 316 minecraft:deepslate_tiles
setblock 511 16 277 minecraft:cobbled_deepslate
fill 511 16 278 511 19 278 minecraft:deepslate_tiles
setblock 511 16 282 minecraft:cobbled_deepslate
fill 511 16 283 511 19 283 minecraft:deepslate_tiles
setblock 511 16 287 minecraft:cobbled_deepslate
fill 511 16 288 511 19 288 minecraft:deepslate_tiles
setblock 511 16 292 minecraft:cobbled_deepslate
fill 511 16 293 511 19 293 minecraft:deepslate_tiles
setblock 511 16 297 minecraft:cobbled_deepslate
fill 511 16 298 511 19 298 minecraft:deepslate_tiles
setblock 511 16 302 minecraft:cobbled_deepslate
fill 511 16 303 511 19 303 minecraft:deepslate_tiles
setblock 511 16 307 minecraft:cobbled_deepslate
fill 511 16 308 511 19 308 minecraft:deepslate_tiles
setblock 511 16 311 minecraft:deepslate_tiles
setblock 511 16 312 minecraft:cobbled_deepslate
fill 511 16 313 511 19 313 minecraft:deepslate_tiles
fill 511 16 315 511 17 315 minecraft:deepslate_tiles
setblock 471 17 276 minecraft:cobbled_deepslate
fill 471 17 277 471 20 277 minecraft:deepslate_tiles
setblock 471 17 281 minecraft:cobbled_deepslate
fill 471 17 282 471 20 282 minecraft:deepslate_tiles
setblock 471 17 286 minecraft:cobbled_deepslate
fill 471 17 287 471 20 287 minecraft:deepslate_tiles
setblock 471 17 291 minecraft:cobbled_deepslate
fill 471 17 292 471 20 292 minecraft:deepslate_tiles
setblock 471 17 302 minecraft:deepslate_tiles
setblock 471 17 306 minecraft:cobbled_deepslate
fill 471 17 307 471 17 310 minecraft:deepslate_tiles
setblock 471 17 311 minecraft:cobbled_deepslate
fill 471 17 312 471 20 312 minecraft:deepslate_tiles
setblock 471 17 316 minecraft:cobbled_deepslate
fill 472 17 275 472 94 275 minecraft:cobbled_deepslate
fill 472 17 276 472 20 276 minecraft:deepslate_tiles
setblock 472 17 280 minecraft:cobbled_deepslate
fill 472 17 281 472 19 281 minecraft:deepslate_tiles
setblock 472 17 285 minecraft:cobbled_deepslate
fill 472 17 286 472 20 286 minecraft:deepslate_tiles
setblock 472 17 290 minecraft:cobbled_deepslate
fill 472 17 291 472 19 291 minecraft:deepslate_tiles
setblock 472 17 306 minecraft:deepslate_tiles
setblock 472 17 310 minecraft:cobbled_deepslate
fill 472 17 311 472 19 311 minecraft:deepslate_tiles
fill 472 17 313 472 18 313 minecraft:deepslate_tiles
fill 472 17 316 472 20 316 minecraft:deepslate_tiles
setblock 473 17 284 minecraft:cobbled_deepslate
fill 473 17 285 473 18 285 minecraft:deepslate_tiles
fill 474 17 275 474 94 275 minecraft:cobbled_deepslate
fill 475 17 301 475 18 301 minecraft:white_wool
setblock 476 17 276 minecraft:cobbled_deepslate
setblock 476 17 316 minecraft:cobbled_deepslate
setblock 477 17 276 minecraft:deepslate_tiles
fill 477 17 316 480 17 316 minecraft:deepslate_tiles
fill 479 17 276 480 17 276 minecraft:deepslate_tiles
setblock 481 17 276 minecraft:cobbled_deepslate
setblock 481 17 315 minecraft:deepslate_tiles
setblock 481 17 316 minecraft:cobbled_deepslate
fill 482 17 276 482 20 276 minecraft:deepslate_tiles
setblock 482 17 315 minecraft:cobbled_deepslate
fill 482 17 316 485 17 316 minecraft:deepslate_tiles
setblock 483 17 314 minecraft:cobbled_deepslate
fill 483 17 315 483 20 315 minecraft:deepslate_tiles
fill 484 17 314 487 17 314 minecraft:deepslate_tiles
setblock 485 17 276 minecraft:deepslate_tiles
setblock 485 17 277 minecraft:cobbled_deepslate
fill 485 17 313 488 17 313 minecraft:deepslate_tiles
setblock 486 17 276 minecraft:cobbled_deepslate
setblock 486 17 277 minecraft:deepslate_tiles
setblock 486 17 316 minecraft:cobbled_deepslate
fill 487 17 276 487 20 276 minecraft:deepslate_tiles
setblock 487 17 315 minecraft:cobbled_deepslate
fill 487 17 316 487 20 316 minecraft:deepslate_tiles
setblock 488 17 314 minecraft:cobbled_deepslate
fill 488 17 315 488 20 315 minecraft:deepslate_tiles
setblock 489 17 313 minecraft:cobbled_deepslate
fill 489 17 314 489 20 314 minecraft:deepslate_tiles
fill 490 17 313 490 18 313 minecraft:deepslate_tiles
setblock 491 17 316 minecraft:cobbled_deepslate
setblock 492 17 315 minecraft:cobbled_deepslate
fill 492 17 316 492 20 316 minecraft:deepslate_tiles
setblock 505 17 276 minecraft:deepslate_tiles
setblock 505 17 316 minecraft:deepslate_tiles
setblock 506 17 276 minecraft:cobbled_deepslate
setblock 506 17 316 minecraft:cobbled_deepslate
fill 507 17 276 507 20 276 minecraft:deepslate_tiles
fill 507 17 286 507 17 289 minecraft:deepslate_tiles
fill 507 17 291 507 18 291 minecraft:black_concrete
fill 507 17 293 507 18 293 minecraft:black_concrete
fill 507 17 316 507 20 316 minecraft:deepslate_tiles
setblock 508 17 283 minecraft:deepslate_tiles
setblock 508 17 284 minecraft:cobbled_deepslate
fill 508 17 285 508 20 285 minecraft:deepslate_tiles
setblock 508 17 288 minecraft:deepslate_tiles
setblock 508 17 289 minecraft:cobbled_deepslate
fill 508 17 290 508 20 290 minecraft:deepslate_tiles
setblock 508 17 293 minecraft:deepslate_tiles
setblock 509 17 283 minecraft:cobbled_deepslate
fill 509 17 284 509 20 284 minecraft:deepslate_tiles
setblock 509 17 288 minecraft:cobbled_deepslate
fill 509 17 289 509 20 289 minecraft:deepslate_tiles
setblock 509 17 292 minecraft:deepslate_tiles
setblock 509 17 293 minecraft:cobbled_deepslate
fill 509 17 294 509 20 294 minecraft:deepslate_tiles
setblock 509 17 303 minecraft:cobbled_deepslate
setblock 509 17 304 minecraft:deepslate_tiles
setblock 509 17 308 minecraft:cobbled_deepslate
fill 509 17 309 509 18 309 minecraft:deepslate_tiles
setblock 510 17 278 minecraft:deepslate_tiles
setblock 510 17 282 minecraft:cobbled_deepslate
fill 510 17 283 510 20 283 minecraft:deepslate_tiles
setblock 510 17 287 minecraft:cobbled_deepslate
fill 510 17 288 510 20 288 minecraft:deepslate_tiles
setblock 510 17 292 minecraft:cobbled_deepslate
fill 510 17 293 510 20 293 minecraft:deepslate_tiles
setblock 510 17 297 minecraft:cobbled_deepslate
setblock 510 17 298 minecraft:deepslate_tiles
setblock 510 17 302 minecraft:cobbled_deepslate
fill 510 17 303 510 18 303 minecraft:deepslate_tiles
setblock 510 17 307 minecraft:cobbled_deepslate
fill 510 17 308 510 19 308 minecraft:deepslate_tiles
setblock 510 17 312 minecraft:cobbled_deepslate
fill 510 17 313 510 18 313 minecraft:deepslate_tiles
setblock 511 17 276 minecraft:cobbled_deepslate
fill 511 17 277 511 20 277 minecraft:deepslate_tiles
setblock 511 17 281 minecraft:cobbled_deepslate
fill 511 17 282 511 20 282 minecraft:deepslate_tiles
setblock 511 17 286 minecraft:cobbled_deepslate
fill 511 17 287 511 20 287 minecraft:deepslate_tiles
setblock 511 17 291 minecraft:cobbled_deepslate
fill 511 17 292 511 20 292 minecraft:deepslate_tiles
setblock 511 17 296 minecraft:cobbled_deepslate
fill 511 17 297 511 20 297 minecraft:deepslate_tiles
setblock 511 17 301 minecraft:cobbled_deepslate
fill 511 17 302 511 18 302 minecraft:deepslate_tiles
setblock 511 17 306 minecraft:cobbled_deepslate
fill 511 17 307 511 20 307 minecraft:deepslate_tiles
setblock 511 17 311 minecraft:cobbled_deepslate
fill 511 17 312 511 20 312 minecraft:deepslate_tiles
setblock 511 17 316 minecraft:cobbled_deepslate
fill 471 18 276 471 21 276 minecraft:deepslate_tiles
setblock 471 18 280 minecraft:cobbled_deepslate
fill 471 18 281 471 21 281 minecraft:deepslate_tiles
setblock 471 18 285 minecraft:cobbled_deepslate
fill 471 18 286 471 21 286 minecraft:deepslate_tiles
setblock 471 18 290 minecraft:cobbled_deepslate
fill 471 18 291 471 21 291 minecraft:deepslate_tiles
setblock 471 18 295 minecraft:cobbled_deepslate
setblock 471 18 305 minecraft:cobbled_deepslate
fill 471 18 306 471 18 309 minecraft:deepslate_tiles
setblock 471 18 310 minecraft:cobbled_deepslate
fill 471 18 311 471 21 311 minecraft:deepslate_tiles
setblock 471 18 315 minecraft:cobbled_deepslate
fill 471 18 316 471 21 316 minecraft:deepslate_tiles
setblock 472 18 279 minecraft:cobbled_deepslate
setblock 472 18 280 minecraft:deepslate_tiles
setblock 472 18 284 minecraft:cobbled_deepslate
fill 472 18 285 472 20 285 minecraft:deepslate_tiles
setblock 472 18 289 minecraft:cobbled_deepslate
fill 472 18 290 472 20 290 minecraft:deepslate_tiles
setblock 472 18 309 minecraft:cobbled_deepslate
fill 472 18 310 472 19 310 minecraft:deepslate_tiles
fill 473 18 316 474 18 316 minecraft:deepslate_tiles
setblock 475 18 276 minecraft:cobbled_deepslate
setblock 475 18 316 minecraft:cobbled_deepslate
fill 476 18 316 479 18 316 minecraft:deepslate_tiles
setblock 479 18 276 minecraft:deepslate_tiles
setblock 480 18 276 minecraft:cobbled_deepslate
setblock 480 18 315 minecraft:deepslate_tiles
setblock 480 18 316 minecraft:cobbled_deepslate
fill 481 18 276 481 21 276 minecraft:deepslate_tiles
setblock 481 18 315 minecraft:cobbled_deepslate
fill 481 18 316 484 18 316 minecraft:deepslate_tiles
setblock 482 18 314 minecraft:cobbled_deepslate
fill 482 18 315 482 21 315 minecraft:deepslate_tiles
fill 483 18 314 486 18 314 minecraft:deepslate_tiles
fill 484 18 313 487 18 313 minecraft:deepslate_tiles
setblock 485 18 276 minecraft:cobbled_deepslate
setblock 485 18 316 minecraft:cobbled_deepslate
fill 486 18 276 486 21 276 minecraft:deepslate_tiles
setblock 486 18 315 minecraft:cobbled_deepslate
fill 486 18 316 486 21 316 minecraft:deepslate_tiles
setblock 487 18 314 minecraft:cobbled_deepslate
fill 487 18 315 487 21 315 minecraft:deepslate_tiles
setblock 488 18 313 minecraft:cobbled_deepslate
fill 488 18 314 488 21 314 minecraft:deepslate_tiles
fill 489 18 313 489 19 313 minecraft:deepslate_tiles
setblock 490 18 276 minecraft:cobbled_deepslate
setblock 490 18 316 minecraft:cobbled_deepslate
setblock 491 18 315 minecraft:cobbled_deepslate
fill 491 18 316 491 21 316 minecraft:deepslate_tiles
fill 492 18 315 492 19 315 minecraft:deepslate_tiles
setblock 504 18 316 minecraft:deepslate_tiles
setblock 505 18 276 minecraft:cobbled_deepslate
setblock 505 18 316 minecraft:cobbled_deepslate
fill 506 18 276 506 21 276 minecraft:deepslate_tiles
setblock 506 18 292 minecraft:black_concrete
fill 506 18 305 506 19 305 minecraft:white_wool
fill 506 18 316 506 21 316 minecraft:deepslate_tiles
fill 507 18 286 507 18 288 minecraft:deepslate_tiles
setblock 507 18 289 minecraft:cobbled_deepslate
fill 507 18 290 507 19 290 minecraft:deepslate_tiles
setblock 508 18 283 minecraft:cobbled_deepslate
fill 508 18 284 508 19 284 minecraft:deepslate_tiles
setblock 508 18 288 minecraft:cobbled_deepslate
fill 508 18 289 508 21 289 minecraft:deepslate_tiles
setblock 508 18 293 minecraft:cobbled_deepslate
setblock 508 18 294 minecraft:black_concrete
setblock 509 18 282 minecraft:cobbled_deepslate
fill 509 18 283 509 20 283 minecraft:deepslate_tiles
setblock 509 18 287 minecraft:cobbled_deepslate
fill 509 18 288 509 21 288 minecraft:deepslate_tiles
setblock 509 18 292 minecraft:cobbled_deepslate
fill 509 18 293 509 21 293 minecraft:deepslate_tiles
setblock 509 18 307 minecraft:cobbled_deepslate
setblock 509 18 308 minecraft:deepslate_tiles
setblock 510 18 276 minecraft:cobbled_deepslate
setblock 510 18 281 minecraft:cobbled_deepslate
fill 510 18 282 510 20 282 minecraft:deepslate_tiles
setblock 510 18 286 minecraft:cobbled_deepslate
fill 510 18 287 510 21 287 minecraft:deepslate_tiles
setblock 510 18 291 minecraft:cobbled_deepslate
fill 510 18 292 510 21 292 minecraft:deepslate_tiles
setblock 510 18 296 minecraft:cobbled_deepslate
setblock 510 18 297 minecraft:deepslate_tiles
setblock 510 18 302 minecraft:deepslate_tiles
setblock 510 18 306 minecraft:cobbled_deepslate
fill 510 18 307 510 19 307 minecraft:deepslate_tiles
setblock 510 18 311 minecraft:cobbled_deepslate
fill 510 18 312 510 19 312 minecraft:deepslate_tiles
setblock 510 18 316 minecraft:cobbled_deepslate
fill 511 18 276 511 20 276 minecraft:deepslate_tiles
setblock 511 18 280 minecraft:cobbled_deepslate
fill 511 18 281 511 21 281 minecraft:deepslate_tiles
setblock 511 18 285 minecraft:cobbled_deepslate
fill 511 18 286 511 21 286 minecraft:deepslate_tiles
setblock 511 18 290 minecraft:cobbled_deepslate
fill 511 18 291 511 21 291 minecraft:deepslate_tiles
setblock 511 18 295 minecraft:cobbled_deepslate
fill 511 18 296 511 21 296 minecraft:deepslate_tiles
setblock 511 18 300 minecraft:cobbled_deepslate
setblock 511 18 301 minecraft:deepslate_tiles
setblock 511 18 305 minecraft:cobbled_deepslate
fill 511 18 306 511 20 306 minecraft:deepslate_tiles
setblock 511 18 310 minecraft:cobbled_deepslate
fill 511 18 311 511 21 311 minecraft:deepslate_tiles
setblock 511 18 315 minecraft:cobbled_deepslate
setblock 511 18 316 minecraft:deepslate_tiles
fill 470 19 288 470 34 294 minecraft:cobbled_deepslate
setblock 470 19 295 minecraft:redstone_block
fill 470 19 296 470 29 303 minecraft:cobbled_deepslate
setblock 471 19 279 minecraft:cobbled_deepslate
fill 471 19 280 471 21 280 minecraft:deepslate_tiles
setblock 471 19 284 minecraft:cobbled_deepslate
fill 471 19 285 471 22 285 minecraft:deepslate_tiles
setblock 471 19 289 minecraft:cobbled_deepslate
fill 471 19 290 471 22 290 minecraft:deepslate_tiles
setblock 471 19 294 minecraft:cobbled_deepslate
fill 471 19 305 471 19 308 minecraft:deepslate_tiles
setblock 471 19 309 minecraft:cobbled_deepslate
fill 471 19 310 471 22 310 minecraft:deepslate_tiles
setblock 471 19 314 minecraft:cobbled_deepslate
fill 471 19 315 471 22 315 minecraft:deepslate_tiles
setblock 472 19 283 minecraft:cobbled_deepslate
fill 472 19 284 472 20 284 minecraft:deepslate_tiles
setblock 472 19 288 minecraft:cobbled_deepslate
fill 472 19 289 472 20 289 minecraft:deepslate_tiles
setblock 472 19 309 minecraft:deepslate_tiles
setblock 472 19 313 minecraft:cobbled_deepslate
setblock 473 19 278 minecraft:light[level=12]
setblock 473 19 285 minecraft:light[level=12]
setblock 473 19 292 minecraft:light[level=12]
setblock 473 19 299 minecraft:light[level=12]
setblock 473 19 306 minecraft:light[level=12]
setblock 473 19 313 minecraft:light[level=12]
setblock 473 19 316 minecraft:deepslate_tiles
setblock 474 19 276 minecraft:cobbled_deepslate
setblock 474 19 316 minecraft:cobbled_deepslate
fill 475 19 316 478 19 316 minecraft:deepslate_tiles
setblock 479 19 276 minecraft:cobbled_deepslate
setblock 479 19 315 minecraft:deepslate_tiles
setblock 479 19 316 minecraft:cobbled_deepslate
fill 480 19 276 480 22 276 minecraft:deepslate_tiles
setblock 480 19 278 minecraft:light[level=12]
setblock 480 19 285 minecraft:light[level=12]
setblock 480 19 292 minecraft:light[level=12]
setblock 480 19 299 minecraft:light[level=12]
setblock 480 19 306 minecraft:light[level=12]
setblock 480 19 313 minecraft:light[level=12]
setblock 480 19 315 minecraft:cobbled_deepslate
fill 480 19 316 483 19 316 minecraft:deepslate_tiles
setblock 481 19 314 minecraft:cobbled_deepslate
fill 481 19 315 481 22 315 minecraft:deepslate_tiles
fill 482 19 314 485 19 314 minecraft:deepslate_tiles
fill 483 19 313 486 19 313 minecraft:deepslate_tiles
setblock 484 19 276 minecraft:cobbled_deepslate
setblock 484 19 316 minecraft:cobbled_deepslate
fill 485 19 276 485 22 276 minecraft:deepslate_tiles
setblock 485 19 315 minecraft:cobbled_deepslate
fill 485 19 316 485 22 316 minecraft:deepslate_tiles
setblock 486 19 314 minecraft:cobbled_deepslate
fill 486 19 315 486 22 315 minecraft:deepslate_tiles
setblock 487 19 278 minecraft:light[level=12]
setblock 487 19 285 minecraft:light[level=12]
setblock 487 19 292 minecraft:light[level=12]
setblock 487 19 299 minecraft:light[level=12]
setblock 487 19 306 minecraft:light[level=12]
setblock 487 19 313 minecraft:cobbled_deepslate
fill 487 19 314 487 22 314 minecraft:deepslate_tiles
fill 488 19 275 495 42 275 minecraft:cobbled_deepslate
fill 488 19 313 488 20 313 minecraft:deepslate_tiles
setblock 489 19 276 minecraft:cobbled_deepslate
fill 489 19 279 493 35 281 minecraft:white_wool
setblock 489 19 316 minecraft:cobbled_deepslate
fill 490 19 278 492 35 278 minecraft:white_wool
fill 490 19 282 492 35 282 minecraft:white_wool
setblock 490 19 315 minecraft:cobbled_deepslate
fill 490 19 316 490 22 316 minecraft:deepslate_tiles
setblock 491 19 314 minecraft:cobbled_deepslate
fill 491 19 315 491 21 315 minecraft:deepslate_tiles
setblock 494 19 278 minecraft:light[level=12]
setblock 494 19 285 minecraft:light[level=12]
setblock 494 19 292 minecraft:light[level=12]
setblock 494 19 299 minecraft:light[level=12]
setblock 494 19 306 minecraft:light[level=12]
setblock 494 19 313 minecraft:light[level=12]
setblock 496 19 275 minecraft:white_wool
fill 497 19 275 500 78 275 minecraft:cobbled_deepslate
setblock 501 19 278 minecraft:light[level=12]
setblock 501 19 285 minecraft:light[level=12]
setblock 501 19 292 minecraft:light[level=12]
setblock 501 19 299 minecraft:light[level=12]
setblock 501 19 306 minecraft:light[level=12]
setblock 501 19 313 minecraft:light[level=12]
setblock 503 19 316 minecraft:deepslate_tiles
setblock 504 19 316 minecraft:cobbled_deepslate
fill 505 19 276 505 22 276 minecraft:deepslate_tiles
fill 505 19 316 505 22 316 minecraft:deepslate_tiles
setblock 507 19 288 minecraft:cobbled_deepslate
setblock 507 19 289 minecraft:deepslate_tiles
setblock 508 19 278 minecraft:light[level=12]
setblock 508 19 287 minecraft:cobbled_deepslate
fill 508 19 288 508 21 288 minecraft:deepslate_tiles
setblock 508 19 291 minecraft:deepslate_tiles
setblock 508 19 292 minecraft:cobbled_deepslate
setblock 508 19 293 minecraft:deepslate_tiles
setblock 508 19 299 minecraft:light[level=12]
setblock 508 19 306 minecraft:light[level=12]
setblock 508 19 313 minecraft:light[level=12]
setblock 509 19 276 minecraft:cobbled_deepslate
setblock 509 19 282 minecraft:deepslate_tiles
setblock 509 19 286 minecraft:cobbled_deepslate
fill 509 19 287 509 22 287 minecraft:deepslate_tiles
setblock 509 19 291 minecraft:cobbled_deepslate
fill 509 19 292 509 22 292 minecraft:deepslate_tiles
setblock 509 19 316 minecraft:cobbled_deepslate
fill 510 19 276 510 21 276 minecraft:deepslate_tiles
setblock 510 19 280 minecraft:cobbled_deepslate
fill 510 19 281 510 20 281 minecraft:deepslate_tiles
setblock 510 19 285 minecraft:cobbled_deepslate
fill 510 19 286 510 22 286 minecraft:deepslate_tiles
setblock 510 19 290 minecraft:cobbled_deepslate
fill 510 19 291 510 22 291 minecraft:deepslate_tiles
setblock 510 19 295 minecraft:cobbled_deepslate
setblock 510 19 296 minecraft:deepslate_tiles
setblock 510 19 306 minecraft:deepslate_tiles
setblock 510 19 310 minecraft:cobbled_deepslate
fill 510 19 311 510 20 311 minecraft:deepslate_tiles
fill 510 19 316 510 20 316 minecraft:deepslate_tiles
setblock 511 19 279 minecraft:cobbled_deepslate
fill 511 19 280 511 21 280 minecraft:deepslate_tiles
setblock 511 19 284 minecraft:cobbled_deepslate
fill 511 19 285 511 22 285 minecraft:deepslate_tiles
setblock 511 19 289 minecraft:cobbled_deepslate
fill 511 19 290 511 22 290 minecraft:deepslate_tiles
setblock 511 19 294 minecraft:cobbled_deepslate
fill 511 19 295 511 22 295 minecraft:deepslate_tiles
setblock 511 19 304 minecraft:cobbled_deepslate
setblock 511 19 305 minecraft:deepslate_tiles
setblock 511 19 309 minecraft:cobbled_deepslate
fill 511 19 310 511 21 310 minecraft:deepslate_tiles
setblock 511 19 314 minecraft:cobbled_deepslate
fill 511 19 315 511 20 315 minecraft:deepslate_tiles
fill 470 20 295 470 94 295 minecraft:cobbled_deepslate
setblock 471 20 278 minecraft:cobbled_deepslate
fill 471 20 279 471 21 279 minecraft:deepslate_tiles
setblock 471 20 283 minecraft:cobbled_deepslate
fill 471 20 284 471 22 284 minecraft:deepslate_tiles
setblock 471 20 288 minecraft:cobbled_deepslate
fill 471 20 289 471 23 289 minecraft:deepslate_tiles
setblock 471 20 293 minecraft:cobbled_deepslate
setblock 471 20 294 minecraft:deepslate_tiles
setblock 471 20 307 minecraft:deepslate_tiles
setblock 471 20 308 minecraft:cobbled_deepslate
fill 471 20 309 471 21 309 minecraft:deepslate_tiles
setblock 471 20 313 minecraft:cobbled_deepslate
fill 471 20 314 471 23 314 minecraft:deepslate_tiles
setblock 472 20 287 minecraft:cobbled_deepslate
setblock 472 20 288 minecraft:deepslate_tiles
setblock 472 20 312 minecraft:cobbled_deepslate
setblock 473 20 276 minecraft:cobbled_deepslate
setblock 473 20 316 minecraft:cobbled_deepslate
fill 474 20 316 477 20 316 minecraft:deepslate_tiles
setblock 478 20 315 minecraft:deepslate_tiles
setblock 478 20 316 minecraft:cobbled_deepslate
setblock 479 20 315 minecraft:cobbled_deepslate
fill 479 20 316 482 20 316 minecraft:deepslate_tiles
setblock 480 20 314 minecraft:cobbled_deepslate
fill 480 20 315 480 23 315 minecraft:deepslate_tiles
fill 481 20 314 484 20 314 minecraft:deepslate_tiles
setblock 483 20 276 minecraft:cobbled_deepslate
fill 483 20 313 485 20 313 minecraft:deepslate_tiles
setblock 483 20 316 minecraft:cobbled_deepslate
fill 484 20 276 484 23 276 minecraft:deepslate_tiles
setblock 484 20 315 minecraft:cobbled_deepslate
fill 484 20 316 484 23 316 minecraft:deepslate_tiles
setblock 485 20 314 minecraft:cobbled_deepslate
fill 485 20 315 485 23 315 minecraft:deepslate_tiles
setblock 486 20 313 minecraft:cobbled_deepslate
fill 486 20 314 486 23 314 minecraft:deepslate_tiles
fill 487 20 313 487 22 313 minecraft:deepslate_tiles
setblock 488 20 276 minecraft:cobbled_deepslate
fill 488 20 278 488 34 282 minecraft:white_wool
setblock 488 20 316 minecraft:cobbled_deepslate
fill 489 20 277 489 34 278 minecraft:white_wool
fill 489 20 282 489 34 283 minecraft:white_wool
setblock 489 20 315 minecraft:cobbled_deepslate
fill 489 20 316 489 23 316 minecraft:deepslate_tiles
fill 490 20 277 493 32 277 minecraft:white_wool
fill 490 20 283 493 33 283 minecraft:white_wool
setblock 490 20 314 minecraft:cobbled_deepslate
fill 490 20 315 490 22 315 minecraft:deepslate_tiles
fill 493 20 278 494 34 278 minecraft:white_wool
fill 493 20 282 494 34 282 minecraft:white_wool
fill 494 20 279 494 34 281 minecraft:white_wool
fill 496 20 275 496 25 275 minecraft:cobbled_deepslate
setblock 503 20 316 minecraft:cobbled_deepslate
fill 504 20 316 504 23 316 minecraft:deepslate_tiles
setblock 508 20 276 minecraft:cobbled_deepslate
setblock 508 20 286 minecraft:cobbled_deepslate
fill 508 20 287 508 21 287 minecraft:deepslate_tiles
setblock 508 20 291 minecraft:cobbled_deepslate
fill 508 20 292 508 21 292 minecraft:deepslate_tiles
setblock 508 20 316 minecraft:cobbled_deepslate
fill 509 20 276 509 23 276 minecraft:deepslate_tiles
setblock 509 20 285 minecraft:cobbled_deepslate
fill 509 20 286 509 22 286 minecraft:deepslate_tiles
setblock 509 20 290 minecraft:cobbled_deepslate
fill 509 20 291 509 23 291 minecraft:deepslate_tiles
fill 509 20 316 509 23 316 minecraft:deepslate_tiles
setblock 510 20 284 minecraft:cobbled_deepslate
fill 510 20 285 510 22 285 minecraft:deepslate_tiles
setblock 510 20 289 minecraft:cobbled_deepslate
fill 510 20 290 510 23 290 minecraft:deepslate_tiles
setblock 510 20 294 minecraft:cobbled_deepslate
fill 510 20 295 510 21 295 minecraft:deepslate_tiles
setblock 510 20 310 minecraft:deepslate_tiles
setblock 511 20 278 minecraft:cobbled_deepslate
setblock 511 20 279 minecraft:deepslate_tiles
setblock 511 20 283 minecraft:cobbled_deepslate
fill 511 20 284 511 23 284 minecraft:deepslate_tiles
setblock 511 20 288 minecraft:cobbled_deepslate
fill 511 20 289 511 23 289 minecraft:deepslate_tiles
setblock 511 20 293 minecraft:cobbled_deepslate
fill 511 20 294 511 23 294 minecraft:deepslate_tiles
setblock 511 20 308 minecraft:cobbled_deepslate
fill 511 20 309 511 21 309 minecraft:deepslate_tiles
setblock 511 20 313 minecraft:cobbled_deepslate
fill 511 20 314 511 21 314 minecraft:deepslate_tiles
setblock 471 21 277 minecraft:cobbled_deepslate
setblock 471 21 278 minecraft:deepslate_tiles
setblock 471 21 282 minecraft:cobbled_deepslate
setblock 471 21 283 minecraft:deepslate_tiles
setblock 471 21 287 minecraft:cobbled_deepslate
fill 471 21 288 471 23 288 minecraft:deepslate_tiles
setblock 471 21 292 minecraft:cobbled_deepslate
setblock 471 21 293 minecraft:deepslate_tiles
setblock 471 21 308 minecraft:deepslate_tiles
setblock 471 21 312 minecraft:cobbled_deepslate
fill 471 21 313 471 24 313 minecraft:deepslate_tiles
setblock 472 21 276 minecraft:cobbled_deepslate
setblock 472 21 316 minecraft:cobbled_deepslate
setblock 473 21 278 minecraft:light[level=13]
setblock 473 21 286 minecraft:light[level=13]
setblock 473 21 294 minecraft:light[level=13]
setblock 473 21 302 minecraft:light[level=13]
setblock 473 21 310 minecraft:light[level=13]
fill 473 21 316 476 21 316 minecraft:deepslate_tiles
setblock 477 21 316 minecraft:cobbled_deepslate
setblock 478 21 315 minecraft:cobbled_deepslate
fill 478 21 316 481 21 316 minecraft:deepslate_tiles
fill 479 21 315 479 24 315 minecraft:deepslate_tiles
fill 480 21 314 483 21 314 minecraft:deepslate_tiles
setblock 481 21 278 minecraft:light[level=13]
setblock 481 21 286 minecraft:light[level=13]
setblock 481 21 294 minecraft:light[level=13]
setblock 481 21 302 minecraft:light[level=13]
setblock 481 21 310 minecraft:light[level=13]
setblock 482 21 276 minecraft:cobbled_deepslate
fill 482 21 313 484 21 313 minecraft:deepslate_tiles
setblock 482 21 316 minecraft:cobbled_deepslate
fill 483 21 276 483 24 276 minecraft:deepslate_tiles
setblock 483 21 315 minecraft:cobbled_deepslate
fill 483 21 316 483 24 316 minecraft:deepslate_tiles
setblock 484 21 314 minecraft:cobbled_deepslate
fill 484 21 315 484 24 315 minecraft:deepslate_tiles
setblock 485 21 313 minecraft:cobbled_deepslate
fill 485 21 314 485 24 314 minecraft:deepslate_tiles
fill 486 21 313 486 23 313 minecraft:deepslate_tiles
setblock 487 21 276 minecraft:cobbled_deepslate
fill 487 21 278 487 33 282 minecraft:white_wool
setblock 487 21 316 minecraft:cobbled_deepslate
fill 488 21 277 488 33 277 minecraft:white_wool
fill 488 21 283 488 33 283 minecraft:white_wool
setblock 488 21 315 minecraft:cobbled_deepslate
fill 488 21 316 488 24 316 minecraft:deepslate_tiles
fill 489 21 276 493 29 276 minecraft:white_wool
fill 489 21 284 493 33 284 minecraft:white_wool
setblock 489 21 286 minecraft:light[level=13]
setblock 489 21 294 minecraft:light[level=13]
setblock 489 21 302 minecraft:light[level=13]
setblock 489 21 310 minecraft:light[level=13]
setblock 489 21 314 minecraft:cobbled_deepslate
fill 489 21 315 489 24 315 minecraft:deepslate_tiles
setblock 492 21 316 minecraft:cobbled_deepslate
fill 494 21 277 494 31 277 minecraft:white_wool
fill 494 21 283 494 33 283 minecraft:white_wool
fill 495 21 278 495 33 282 minecraft:white_wool
setblock 497 21 278 minecraft:light[level=13]
setblock 497 21 286 minecraft:light[level=13]
setblock 497 21 294 minecraft:light[level=13]
setblock 497 21 302 minecraft:light[level=13]
setblock 497 21 310 minecraft:light[level=13]
setblock 502 21 316 minecraft:cobbled_deepslate
fill 503 21 316 503 24 316 minecraft:deepslate_tiles
fill 504 21 276 504 23 276 minecraft:deepslate_tiles
setblock 505 21 278 minecraft:light[level=13]
setblock 505 21 286 minecraft:light[level=13]
setblock 505 21 294 minecraft:light[level=13]
setblock 505 21 302 minecraft:light[level=13]
setblock 505 21 310 minecraft:light[level=13]
setblock 507 21 276 minecraft:cobbled_deepslate
setblock 507 21 316 minecraft:cobbled_deepslate
fill 508 21 276 508 24 276 minecraft:deepslate_tiles
setblock 508 21 290 minecraft:cobbled_deepslate
setblock 508 21 291 minecraft:deepslate_tiles
fill 508 21 316 508 24 316 minecraft:deepslate_tiles
setblock 509 21 285 minecraft:deepslate_tiles
setblock 509 21 289 minecraft:cobbled_deepslate
fill 509 21 290 509 23 290 minecraft:deepslate_tiles
setblock 510 21 283 minecraft:cobbled_deepslate
fill 510 21 284 510 22 284 minecraft:deepslate_tiles
setblock 510 21 288 minecraft:cobbled_deepslate
fill 510 21 289 510 24 289 minecraft:deepslate_tiles
setblock 510 21 293 minecraft:cobbled_deepslate
fill 510 21 294 510 23 294 minecraft:deepslate_tiles
setblock 511 21 282 minecraft:cobbled_deepslate
fill 511 21 283 511 22 283 minecraft:deepslate_tiles
setblock 511 21 287 minecraft:cobbled_deepslate
fill 511 21 288 511 24 288 minecraft:deepslate_tiles
setblock 511 21 292 minecraft:cobbled_deepslate
fill 511 21 293 511 24 293 minecraft:deepslate_tiles
setblock 511 21 312 minecraft:cobbled_deepslate
setblock 511 21 313 minecraft:deepslate_tiles
fill 470 22 305 470 31 312 minecraft:cobbled_deepslate
setblock 470 22 313 minecraft:redstone_block
fill 470 22 314 470 94 314 minecraft:cobbled_deepslate
setblock 471 22 276 minecraft:cobbled_deepslate
setblock 471 22 286 minecraft:cobbled_deepslate
setblock 471 22 287 minecraft:deepslate_tiles
setblock 471 22 291 minecraft:cobbled_deepslate
setblock 471 22 292 minecraft:deepslate_tiles
setblock 471 22 311 minecraft:cobbled_deepslate
fill 471 22 312 471 25 312 minecraft:deepslate_tiles
setblock 471 22 316 minecraft:cobbled_deepslate
fill 472 22 316 475 22 316 minecraft:deepslate_tiles
setblock 476 22 316 minecraft:cobbled_deepslate
setblock 477 22 315 minecraft:cobbled_deepslate
fill 477 22 316 480 22 316 minecraft:deepslate_tiles
fill 478 22 315 478 24 315 minecraft:deepslate_tiles
fill 479 22 276 479 23 276 minecraft:deepslate_tiles
fill 480 22 314 482 22 314 minecraft:deepslate_tiles
setblock 481 22 276 minecraft:cobbled_deepslate
setblock 481 22 316 minecraft:cobbled_deepslate
fill 482 22 276 482 25 276 minecraft:deepslate_tiles
fill 482 22 313 483 22 313 minecraft:deepslate_tiles
setblock 482 22 315 minecraft:cobbled_deepslate
fill 482 22 316 482 25 316 minecraft:deepslate_tiles
setblock 483 22 314 minecraft:cobbled_deepslate
fill 483 22 315 483 25 315 minecraft:deepslate_tiles
setblock 484 22 313 minecraft:cobbled_deepslate
fill 484 22 314 484 25 314 minecraft:deepslate_tiles
setblock 484 22 317 minecraft:white_wool
fill 485 22 313 485 24 313 minecraft:deepslate_tiles
setblock 486 22 276 minecraft:cobbled_deepslate
fill 486 22 279 486 32 281 minecraft:white_wool
setblock 486 22 316 minecraft:cobbled_deepslate
fill 487 22 277 487 32 277 minecraft:white_wool
fill 487 22 283 487 32 283 minecraft:white_wool
setblock 487 22 315 minecraft:cobbled_deepslate
fill 487 22 316 487 25 316 minecraft:deepslate_tiles
fill 488 22 276 488 28 276 minecraft:white_wool
fill 488 22 284 488 32 284 minecraft:white_wool
setblock 488 22 314 minecraft:cobbled_deepslate
fill 488 22 315 488 25 315 minecraft:deepslate_tiles
setblock 489 22 314 minecraft:deepslate_tiles
fill 490 22 285 492 32 285 minecraft:white_wool
setblock 491 22 316 minecraft:cobbled_deepslate
fill 494 22 276 494 28 276 minecraft:white_wool
fill 494 22 284 494 32 284 minecraft:white_wool
fill 495 22 277 495 30 277 minecraft:white_wool
fill 495 22 283 495 32 283 minecraft:white_wool
fill 496 22 279 496 32 281 minecraft:white_wool
setblock 501 22 316 minecraft:cobbled_deepslate
fill 502 22 316 502 25 316 minecraft:deepslate_tiles
setblock 506 22 276 minecraft:cobbled_deepslate
setblock 506 22 316 minecraft:cobbled_deepslate
fill 507 22 276 507 25 276 minecraft:deepslate_tiles
fill 507 22 316 507 25 316 minecraft:deepslate_tiles
setblock 508 22 290 minecraft:deepslate_tiles
setblock 509 22 288 minecraft:cobbled_deepslate
fill 509 22 289 509 23 289 minecraft:deepslate_tiles
setblock 509 22 293 minecraft:cobbled_deepslate
setblock 510 22 287 minecraft:cobbled_deepslate
fill 510 22 288 510 24 288 minecraft:deepslate_tiles
setblock 510 22 292 minecraft:cobbled_deepslate
fill 510 22 293 510 25 293 minecraft:deepslate_tiles
setblock 511 22 282 minecraft:deepslate_tiles
setblock 511 22 286 minecraft:cobbled_deepslate
fill 511 22 287 511 25 287 minecraft:deepslate_tiles
setblock 511 22 291 minecraft:cobbled_deepslate
fill 511 22 292 511 25 292 minecraft:deepslate_tiles
fill 470 23 313 470 94 313 minecraft:cobbled_deepslate
fill 471 23 276 471 26 276 minecraft:deepslate_tiles
setblock 471 23 290 minecraft:cobbled_deepslate
setblock 471 23 291 minecraft:deepslate_tiles
fill 471 23 311 471 24 311 minecraft:deepslate_tiles
setblock 471 23 315 minecraft:cobbled_deepslate
fill 471 23 316 474 23 316 minecraft:deepslate_tiles
setblock 475 23 316 minecraft:cobbled_deepslate
setblock 476 23 315 minecraft:cobbled_deepslate
fill 476 23 316 479 23 316 minecraft:deepslate_tiles
fill 477 23 315 477 26 315 minecraft:deepslate_tiles
fill 478 23 276 478 24 276 minecraft:deepslate_tiles
fill 479 23 301 480 24 302 minecraft:white_wool
fill 479 23 314 481 23 314 minecraft:deepslate_tiles
setblock 480 23 276 minecraft:cobbled_deepslate
setblock 480 23 316 minecraft:cobbled_deepslate
fill 481 23 276 481 26 276 minecraft:deepslate_tiles
setblock 481 23 315 minecraft:cobbled_deepslate
fill 481 23 316 481 26 316 minecraft:deepslate_tiles
setblock 482 23 313 minecraft:deepslate_tiles
setblock 482 23 314 minecraft:cobbled_deepslate
fill 482 23 315 482 26 315 minecraft:deepslate_tiles
setblock 483 23 313 minecraft:cobbled_deepslate
fill 483 23 314 483 26 314 minecraft:deepslate_tiles
fill 484 23 313 484 26 313 minecraft:deepslate_tiles
fill 484 23 317 484 94 317 minecraft:cobbled_deepslate
setblock 485 23 276 minecraft:cobbled_deepslate
setblock 485 23 316 minecraft:cobbled_deepslate
fill 486 23 276 486 26 276 minecraft:deepslate_tiles
fill 486 23 278 486 31 278 minecraft:white_wool
fill 486 23 282 486 31 282 minecraft:white_wool
setblock 486 23 315 minecraft:cobbled_deepslate
fill 486 23 316 486 26 316 minecraft:deepslate_tiles
fill 487 23 276 487 26 276 minecraft:white_wool
fill 487 23 284 487 31 284 minecraft:white_wool
setblock 487 23 314 minecraft:cobbled_deepslate
fill 487 23 315 487 26 315 minecraft:deepslate_tiles
setblock 488 23 314 minecraft:deepslate_tiles
fill 489 23 285 489 31 285 minecraft:white_wool
setblock 490 23 316 minecraft:cobbled_deepslate
fill 491 23 316 491 24 316 minecraft:deepslate_tiles
fill 493 23 285 493 31 285 minecraft:white_wool
fill 495 23 276 495 28 276 minecraft:white_wool
fill 495 23 284 495 31 284 minecraft:white_wool
fill 496 23 278 496 31 278 minecraft:white_wool
fill 496 23 282 496 31 282 minecraft:white_wool
fill 501 23 316 501 26 316 minecraft:deepslate_tiles
fill 503 23 276 503 24 276 minecraft:deepslate_tiles
setblock 505 23 276 minecraft:cobbled_deepslate
setblock 505 23 316 minecraft:cobbled_deepslate
fill 506 23 276 506 26 276 minecraft:deepslate_tiles
fill 506 23 316 506 26 316 minecraft:deepslate_tiles
setblock 509 23 288 minecraft:deepslate_tiles
setblock 509 23 292 minecraft:cobbled_deepslate
setblock 510 23 286 minecraft:cobbled_deepslate
setblock 510 23 287 minecraft:deepslate_tiles
setblock 510 23 291 minecraft:cobbled_deepslate
fill 510 23 292 510 26 292 minecraft:deepslate_tiles
setblock 511 23 285 minecraft:cobbled_deepslate
fill 511 23 286 511 24 286 minecraft:deepslate_tiles
setblock 511 23 290 minecraft:cobbled_deepslate
fill 511 23 291 511 26 291 minecraft:deepslate_tiles
setblock 511 23 295 minecraft:cobbled_deepslate
setblock 471 24 314 minecraft:cobbled_deepslate
fill 471 24 315 471 26 316 minecraft:deepslate_tiles
fill 472 24 316 473 24 316 minecraft:deepslate_tiles
setblock 474 24 316 minecraft:cobbled_deepslate
fill 475 24 316 478 24 316 minecraft:deepslate_tiles
fill 476 24 315 476 27 315 minecraft:deepslate_tiles
fill 477 24 276 477 25 276 minecraft:deepslate_tiles
fill 478 24 314 480 24 314 minecraft:deepslate_tiles
setblock 479 24 276 minecraft:cobbled_deepslate
setblock 479 24 316 minecraft:cobbled_deepslate
fill 480 24 276 480 27 276 minecraft:deepslate_tiles
setblock 480 24 315 minecraft:cobbled_deepslate
fill 480 24 316 480 27 316 minecraft:deepslate_tiles
setblock 481 24 313 minecraft:deepslate_tiles
setblock 481 24 314 minecraft:cobbled_deepslate
fill 481 24 315 481 27 315 minecraft:deepslate_tiles
setblock 482 24 313 minecraft:cobbled_deepslate
fill 482 24 314 482 27 314 minecraft:deepslate_tiles
fill 483 24 313 483 27 313 minecraft:deepslate_tiles
setblock 484 24 276 minecraft:cobbled_deepslate
setblock 484 24 316 minecraft:cobbled_deepslate
fill 485 24 276 485 27 276 minecraft:deepslate_tiles
setblock 485 24 279 minecraft:crying_obsidian
fill 485 24 280 485 30 280 minecraft:white_wool
setblock 485 24 281 minecraft:crying_obsidian
setblock 485 24 315 minecraft:cobbled_deepslate
fill 485 24 316 485 27 316 minecraft:deepslate_tiles
fill 486 24 277 486 30 277 minecraft:white_wool
fill 486 24 283 486 30 283 minecraft:white_wool
setblock 486 24 314 minecraft:cobbled_deepslate
fill 486 24 315 486 27 315 minecraft:deepslate_tiles
fill 487 24 314 487 26 314 minecraft:deepslate_tiles
fill 488 24 285 488 30 285 minecraft:white_wool
setblock 489 24 316 minecraft:cobbled_deepslate
setblock 490 24 286 minecraft:crying_obsidian
fill 490 24 316 490 27 316 minecraft:deepslate_tiles
fill 491 24 286 491 30 286 minecraft:white_wool
setblock 492 24 286 minecraft:crying_obsidian
fill 494 24 285 494 30 285 minecraft:white_wool
fill 496 24 277 496 29 277 minecraft:white_wool
fill 496 24 283 496 30 283 minecraft:white_wool
setblock 497 24 279 minecraft:crying_obsidian
fill 497 24 280 497 30 280 minecraft:white_wool
setblock 497 24 281 minecraft:crying_obsidian
fill 500 24 316 500 27 316 minecraft:deepslate_tiles
fill 502 24 276 502 25 276 minecraft:deepslate_tiles
setblock 504 24 276 minecraft:cobbled_deepslate
setblock 504 24 315 minecraft:deepslate_tiles
setblock 504 24 316 minecraft:cobbled_deepslate
fill 505 24 276 505 27 276 minecraft:deepslate_tiles
fill 505 24 316 505 27 316 minecraft:deepslate_tiles
setblock 509 24 276 minecraft:cobbled_deepslate
setblock 509 24 316 minecraft:cobbled_deepslate
setblock 510 24 290 minecraft:cobbled_deepslate
fill 510 24 291 510 25 291 minecraft:deepslate_tiles
setblock 511 24 285 minecraft:deepslate_tiles
setblock 511 24 289 minecraft:cobbled_deepslate
fill 511 24 290 511 27 290 minecraft:deepslate_tiles
setblock 511 24 294 minecraft:cobbled_deepslate
fill 511 24 295 511 27 295 minecraft:deepslate_tiles
setblock 471 25 313 minecraft:cobbled_deepslate
fill 471 25 314 471 28 314 minecraft:deepslate_tiles
setblock 472 25 276 minecraft:deepslate_tiles
setblock 472 25 316 minecraft:deepslate_tiles
setblock 473 25 276 minecraft:cobbled_deepslate
setblock 473 25 278 minecraft:light[level=12]
setblock 473 25 285 minecraft:light[level=12]
setblock 473 25 292 minecraft:light[level=12]
setblock 473 25 299 minecraft:light[level=12]
setblock 473 25 306 minecraft:light[level=12]
setblock 473 25 313 minecraft:light[level=12]
setblock 473 25 316 minecraft:cobbled_deepslate
fill 474 25 276 476 26 276 minecraft:deepslate_tiles
setblock 474 25 315 minecraft:cobbled_deepslate
fill 474 25 316 477 25 316 minecraft:deepslate_tiles
setblock 475 25 312 minecraft:white_wool
fill 475 25 315 475 28 315 minecraft:deepslate_tiles
setblock 476 25 313 minecraft:white_wool
setblock 477 25 314 minecraft:white_wool
setblock 478 25 276 minecraft:cobbled_deepslate
fill 478 25 314 479 25 314 minecraft:deepslate_tiles
setblock 478 25 315 minecraft:white_wool
setblock 478 25 316 minecraft:cobbled_deepslate
fill 479 25 276 479 28 276 minecraft:deepslate_tiles
setblock 479 25 315 minecraft:cobbled_deepslate
fill 479 25 316 479 28 316 minecraft:deepslate_tiles
setblock 480 25 278 minecraft:light[level=12]
setblock 480 25 285 minecraft:light[level=12]
setblock 480 25 292 minecraft:light[level=12]
setblock 480 25 299 minecraft:light[level=12]
setblock 480 25 306 minecraft:light[level=12]
setblock 480 25 313 minecraft:light[level=12]
setblock 480 25 314 minecraft:cobbled_deepslate
fill 480 25 315 480 28 315 minecraft:deepslate_tiles
setblock 481 25 313 minecraft:cobbled_deepslate
fill 481 25 314 481 28 314 minecraft:deepslate_tiles
fill 482 25 313 482 28 313 minecraft:deepslate_tiles
setblock 483 25 276 minecraft:cobbled_deepslate
setblock 483 25 316 minecraft:cobbled_deepslate
fill 484 25 276 484 28 276 minecraft:deepslate_tiles
setblock 484 25 315 minecraft:cobbled_deepslate
fill 484 25 316 484 28 316 minecraft:deepslate_tiles
setblock 485 25 278 minecraft:crying_obsidian
fill 485 25 279 485 29 279 minecraft:white_wool
fill 485 25 281 485 29 281 minecraft:white_wool
setblock 485 25 282 minecraft:crying_obsidian
setblock 485 25 314 minecraft:cobbled_deepslate
fill 485 25 315 485 28 315 minecraft:deepslate_tiles
fill 486 25 314 486 28 314 minecraft:deepslate_tiles
setblock 487 25 275 minecraft:white_wool
setblock 487 25 285 minecraft:light[level=12]
setblock 487 25 292 minecraft:light[level=12]
setblock 487 25 299 minecraft:light[level=12]
setblock 487 25 306 minecraft:light[level=12]
setblock 487 25 313 minecraft:light[level=12]
setblock 488 25 316 minecraft:cobbled_deepslate
setblock 489 25 286 minecraft:crying_obsidian
setblock 489 25 315 minecraft:cobbled_deepslate
fill 489 25 316 489 28 316 minecraft:deepslate_tiles
fill 490 25 286 490 29 286 minecraft:white_wool
fill 492 25 286 492 29 286 minecraft:white_wool
setblock 493 25 286 minecraft:crying_obsidian
setblock 494 25 292 minecraft:light[level=12]
setblock 494 25 299 minecraft:light[level=12]
setblock 494 25 306 minecraft:light[level=12]
setblock 494 25 313 minecraft:light[level=12]
setblock 497 25 278 minecraft:crying_obsidian
fill 497 25 279 497 29 279 minecraft:white_wool
fill 497 25 281 497 29 281 minecraft:white_wool
setblock 497 25 282 minecraft:crying_obsidian
setblock 498 25 316 minecraft:cobbled_deepslate
fill 499 25 316 499 28 316 minecraft:deepslate_tiles
fill 500 25 276 501 26 276 minecraft:deepslate_tiles
setblock 501 25 278 minecraft:light[level=12]
setblock 501 25 285 minecraft:light[level=12]
setblock 501 25 292 minecraft:light[level=12]
setblock 501 25 299 minecraft:light[level=12]
setblock 501 25 306 minecraft:light[level=12]
setblock 501 25 313 minecraft:light[level=12]
fill 502 25 315 503 25 315 minecraft:deepslate_tiles
setblock 503 25 276 minecraft:cobbled_deepslate
setblock 503 25 316 minecraft:cobbled_deepslate
fill 504 25 276 504 28 276 minecraft:deepslate_tiles
setblock 504 25 315 minecraft:cobbled_deepslate
fill 504 25 316 504 28 316 minecraft:deepslate_tiles
fill 505 25 315 505 28 315 minecraft:deepslate_tiles
fill 507 25 290 507 39 290 minecraft:white_wool
setblock 508 25 276 minecraft:cobbled_deepslate
setblock 508 25 278 minecraft:light[level=12]
setblock 508 25 285 minecraft:light[level=12]
setblock 508 25 292 minecraft:light[level=12]
setblock 508 25 299 minecraft:light[level=12]
setblock 508 25 306 minecraft:light[level=12]
setblock 508 25 313 minecraft:light[level=12]
setblock 508 25 316 minecraft:cobbled_deepslate
fill 509 25 276 511 26 276 minecraft:deepslate_tiles
fill 509 25 316 509 28 316 minecraft:deepslate_tiles
setblock 510 25 289 minecraft:cobbled_deepslate
setblock 510 25 290 minecraft:deepslate_tiles
setblock 511 25 288 minecraft:cobbled_deepslate
fill 511 25 289 511 28 289 minecraft:deepslate_tiles
setblock 511 25 293 minecraft:cobbled_deepslate
fill 511 25 294 511 28 294 minecraft:deepslate_tiles
setblock 471 26 277 minecraft:cobbled_deepslate
setblock 471 26 308 minecraft:white_wool
setblock 471 26 312 minecraft:cobbled_deepslate
fill 471 26 313 471 29 313 minecraft:deepslate_tiles
setblock 472 26 276 minecraft:cobbled_deepslate
setblock 472 26 309 minecraft:white_wool
setblock 472 26 315 minecraft:deepslate_tiles
setblock 472 26 316 minecraft:cobbled_deepslate
fill 473 26 276 473 29 276 minecraft:deepslate_tiles
setblock 473 26 310 minecraft:white_wool
setblock 473 26 315 minecraft:cobbled_deepslate
fill 473 26 316 476 26 316 minecraft:deepslate_tiles
setblock 474 26 311 minecraft:white_wool
fill 474 26 315 474 29 315 minecraft:deepslate_tiles
setblock 477 26 276 minecraft:cobbled_deepslate
fill 477 26 314 478 26 314 minecraft:deepslate_tiles
setblock 477 26 316 minecraft:cobbled_deepslate
fill 478 26 276 478 29 276 minecraft:deepslate_tiles
setblock 478 26 315 minecraft:cobbled_deepslate
fill 478 26 316 478 29 316 minecraft:deepslate_tiles
setblock 479 26 314 minecraft:cobbled_deepslate
fill 479 26 315 479 29 315 minecraft:deepslate_tiles
setblock 480 26 313 minecraft:cobbled_deepslate
fill 480 26 314 480 29 314 minecraft:deepslate_tiles
setblock 481 26 277 minecraft:cobbled_deepslate
fill 481 26 313 481 29 313 minecraft:deepslate_tiles
setblock 482 26 276 minecraft:cobbled_deepslate
setblock 482 26 316 minecraft:cobbled_deepslate
fill 483 26 276 483 29 276 minecraft:deepslate_tiles
setblock 483 26 315 minecraft:cobbled_deepslate
fill 483 26 316 483 29 316 minecraft:deepslate_tiles
setblock 484 26 314 minecraft:cobbled_deepslate
fill 484 26 315 484 29 315 minecraft:deepslate_tiles
fill 485 26 278 485 28 278 minecraft:white_wool
fill 485 26 282 485 28 282 minecraft:white_wool
fill 485 26 314 485 29 314 minecraft:deepslate_tiles
fill 486 26 284 486 28 284 minecraft:crying_obsidian
fill 487 26 275 487 44 275 minecraft:cobbled_deepslate
fill 487 26 285 487 28 285 minecraft:crying_obsidian
setblock 487 26 316 minecraft:cobbled_deepslate
setblock 488 26 315 minecraft:cobbled_deepslate
fill 488 26 316 488 29 316 minecraft:deepslate_tiles
fill 489 26 286 489 28 286 minecraft:white_wool
setblock 489 26 315 minecraft:deepslate_tiles
setblock 491 26 316 minecraft:deepslate_tiles
fill 493 26 286 493 28 286 minecraft:white_wool
fill 495 26 285 495 28 285 minecraft:crying_obsidian
setblock 496 26 275 minecraft:redstone_block
fill 496 26 276 496 27 276 minecraft:crying_obsidian
fill 496 26 284 496 28 284 minecraft:crying_obsidian
fill 497 26 278 497 28 278 minecraft:white_wool
fill 497 26 282 497 28 282 minecraft:white_wool
setblock 497 26 316 minecraft:cobbled_deepslate
fill 498 26 316 498 29 316 minecraft:deepslate_tiles
fill 499 26 276 499 28 276 minecraft:deepslate_tiles
fill 500 26 315 502 26 315 minecraft:deepslate_tiles
setblock 502 26 276 minecraft:cobbled_deepslate
fill 502 26 277 505 26 277 minecraft:deepslate_tiles
setblock 502 26 316 minecraft:cobbled_deepslate
fill 503 26 276 503 29 276 minecraft:deepslate_tiles
setblock 503 26 315 minecraft:cobbled_deepslate
fill 503 26 316 503 29 316 minecraft:deepslate_tiles
fill 504 26 315 504 29 315 minecraft:deepslate_tiles
setblock 506 26 277 minecraft:cobbled_deepslate
setblock 507 26 276 minecraft:cobbled_deepslate
setblock 507 26 316 minecraft:cobbled_deepslate
fill 508 26 276 508 29 276 minecraft:deepslate_tiles
fill 508 26 316 508 29 316 minecraft:deepslate_tiles
fill 510 26 316 511 26 316 minecraft:deepslate_tiles
setblock 511 26 277 minecraft:cobbled_deepslate
fill 511 26 288 511 27 288 minecraft:deepslate_tiles
setblock 511 26 292 minecraft:cobbled_deepslate
fill 511 26 293 511 29 293 minecraft:deepslate_tiles
setblock 471 27 276 minecraft:cobbled_deepslate
fill 471 27 277 471 29 278 minecraft:deepslate_tiles
fill 471 27 312 471 30 312 minecraft:deepslate_tiles
setblock 471 27 315 minecraft:deepslate_tiles
setblock 471 27 316 minecraft:cobbled_deepslate
fill 472 27 276 472 30 276 minecraft:deepslate_tiles
setblock 472 27 314 minecraft:deepslate_tiles
setblock 472 27 315 minecraft:cobbled_deepslate
fill 472 27 316 475 27 316 minecraft:deepslate_tiles
fill 473 27 315 473 30 315 minecraft:deepslate_tiles
fill 474 27 276 475 27 276 minecraft:deepslate_tiles
setblock 476 27 276 minecraft:cobbled_deepslate
fill 476 27 314 477 27 314 minecraft:deepslate_tiles
setblock 476 27 316 minecraft:cobbled_deepslate
fill 477 27 276 477 29 277 minecraft:deepslate_tiles
setblock 477 27 315 minecraft:cobbled_deepslate
fill 477 27 316 477 30 316 minecraft:deepslate_tiles
fill 478 27 277 479 27 277 minecraft:deepslate_tiles
setblock 478 27 314 minecraft:cobbled_deepslate
fill 478 27 315 478 30 315 minecraft:deepslate_tiles
setblock 479 27 313 minecraft:cobbled_deepslate
fill 479 27 314 479 30 314 minecraft:deepslate_tiles
setblock 480 27 277 minecraft:cobbled_deepslate
fill 480 27 313 480 30 313 minecraft:deepslate_tiles
setblock 481 27 276 minecraft:cobbled_deepslate
fill 481 27 277 483 28 277 minecraft:deepslate_tiles
setblock 481 27 316 minecraft:cobbled_deepslate
fill 482 27 276 482 30 276 minecraft:deepslate_tiles
setblock 482 27 315 minecraft:cobbled_deepslate
fill 482 27 316 482 30 316 minecraft:deepslate_tiles
setblock 483 27 314 minecraft:cobbled_deepslate
fill 483 27 315 483 30 315 minecraft:deepslate_tiles
setblock 484 27 313 minecraft:cobbled_deepslate
fill 484 27 314 484 30 314 minecraft:deepslate_tiles
setblock 486 27 276 minecraft:cobbled_deepslate
setblock 486 27 316 minecraft:cobbled_deepslate
fill 487 27 276 487 30 276 minecraft:deepslate_tiles
setblock 487 27 315 minecraft:cobbled_deepslate
fill 487 27 316 487 30 316 minecraft:deepslate_tiles
fill 488 27 315 488 29 315 minecraft:deepslate_tiles
setblock 491 27 316 minecraft:cobbled_deepslate
setblock 491 27 317 minecraft:redstone_block
fill 492 27 317 497 27 317 minecraft:cobbled_deepslate
setblock 495 27 316 minecraft:deepslate_tiles
fill 496 27 275 496 83 275 minecraft:cobbled_deepslate
setblock 496 27 316 minecraft:cobbled_deepslate
fill 497 27 276 498 29 276 minecraft:deepslate_tiles
fill 497 27 316 497 30 316 minecraft:deepslate_tiles
fill 499 27 315 501 27 315 minecraft:deepslate_tiles
setblock 500 27 276 minecraft:deepslate_tiles
setblock 500 27 277 minecraft:cobbled_deepslate
setblock 501 27 276 minecraft:cobbled_deepslate
fill 501 27 277 504 27 277 minecraft:deepslate_tiles
setblock 501 27 316 minecraft:cobbled_deepslate
fill 502 27 276 502 30 276 minecraft:deepslate_tiles
setblock 502 27 315 minecraft:cobbled_deepslate
fill 502 27 316 502 30 316 minecraft:deepslate_tiles
fill 503 27 315 503 30 315 minecraft:deepslate_tiles
setblock 505 27 277 minecraft:cobbled_deepslate
setblock 506 27 276 minecraft:cobbled_deepslate
fill 506 27 277 508 28 277 minecraft:deepslate_tiles
setblock 506 27 315 minecraft:deepslate_tiles
setblock 506 27 316 minecraft:cobbled_deepslate
fill 507 27 276 507 30 276 minecraft:deepslate_tiles
fill 507 27 316 507 30 316 minecraft:deepslate_tiles
fill 509 27 276 510 27 276 minecraft:deepslate_tiles
setblock 510 27 316 minecraft:deepslate_tiles
setblock 511 27 276 minecraft:cobbled_deepslate
fill 511 27 277 511 28 279 minecraft:deepslate_tiles
setblock 511 27 291 minecraft:cobbled_deepslate
fill 511 27 292 511 30 292 minecraft:deepslate_tiles
setblock 511 27 315 minecraft:deepslate_tiles
setblock 511 27 316 minecraft:cobbled_deepslate
fill 471 28 276 471 31 276 minecraft:deepslate_tiles
setblock 471 28 279 minecraft:deepslate_tiles
fill 471 28 311 471 31 311 minecraft:deepslate_tiles
setblock 471 28 315 minecraft:cobbled_deepslate
fill 471 28 316 474 28 316 minecraft:deepslate_tiles
setblock 472 28 314 minecraft:cobbled_deepslate
fill 472 28 315 472 31 315 minecraft:deepslate_tiles
setblock 474 28 276 minecraft:deepslate_tiles
setblock 475 28 276 minecraft:cobbled_deepslate
fill 475 28 277 476 30 277 minecraft:deepslate_tiles
fill 475 28 314 476 28 314 minecraft:deepslate_tiles
setblock 475 28 316 minecraft:cobbled_deepslate
fill 476 28 276 476 31 276 minecraft:deepslate_tiles
setblock 476 28 315 minecraft:cobbled_deepslate
fill 476 28 316 476 31 316 minecraft:deepslate_tiles
setblock 477 28 314 minecraft:cobbled_deepslate
fill 477 28 315 477 31 315 minecraft:deepslate_tiles
setblock 478 28 277 minecraft:deepslate_tiles
setblock 478 28 313 minecraft:cobbled_deepslate
fill 478 28 314 478 31 314 minecraft:deepslate_tiles
setblock 479 28 277 minecraft:cobbled_deepslate
fill 479 28 313 479 31 313 minecraft:deepslate_tiles
setblock 480 28 276 minecraft:cobbled_deepslate
fill 480 28 277 480 31 277 minecraft:deepslate_tiles
setblock 480 28 316 minecraft:cobbled_deepslate
fill 481 28 276 481 31 276 minecraft:deepslate_tiles
setblock 481 28 315 minecraft:cobbled_deepslate
fill 481 28 316 481 31 316 minecraft:deepslate_tiles
setblock 482 28 314 minecraft:cobbled_deepslate
fill 482 28 315 482 31 315 minecraft:deepslate_tiles
setblock 483 28 313 minecraft:cobbled_deepslate
fill 483 28 314 483 31 314 minecraft:deepslate_tiles
setblock 484 28 277 minecraft:cobbled_deepslate
setblock 485 28 276 minecraft:cobbled_deepslate
setblock 485 28 316 minecraft:cobbled_deepslate
fill 486 28 276 486 31 276 minecraft:deepslate_tiles
setblock 486 28 315 minecraft:cobbled_deepslate
fill 486 28 316 486 31 316 minecraft:deepslate_tiles
fill 487 28 315 487 30 315 minecraft:deepslate_tiles
setblock 490 28 316 minecraft:cobbled_deepslate
fill 491 28 316 494 28 316 minecraft:deepslate_tiles
fill 491 28 317 491 94 317 minecraft:cobbled_deepslate
fill 492 28 317 492 29 317 minecraft:white_wool
fill 493 28 317 497 36 317 minecraft:cobbled_deepslate
setblock 495 28 316 minecraft:cobbled_deepslate
fill 496 28 276 496 31 276 minecraft:deepslate_tiles
fill 496 28 316 496 31 316 minecraft:deepslate_tiles
fill 498 28 315 500 28 315 minecraft:deepslate_tiles
setblock 499 28 277 minecraft:cobbled_deepslate
setblock 500 28 276 minecraft:cobbled_deepslate
fill 500 28 277 503 28 277 minecraft:deepslate_tiles
setblock 500 28 316 minecraft:cobbled_deepslate
fill 501 28 276 501 31 276 minecraft:deepslate_tiles
setblock 501 28 315 minecraft:cobbled_deepslate
fill 501 28 316 501 31 316 minecraft:deepslate_tiles
fill 502 28 315 502 31 315 minecraft:deepslate_tiles
setblock 503 28 278 minecraft:cobbled_deepslate
setblock 504 28 277 minecraft:cobbled_deepslate
setblock 505 28 276 minecraft:cobbled_deepslate
fill 505 28 277 505 31 277 minecraft:deepslate_tiles
setblock 505 28 316 minecraft:cobbled_deepslate
fill 506 28 276 506 31 276 minecraft:deepslate_tiles
setblock 506 28 315 minecraft:cobbled_deepslate
fill 506 28 316 506 31 316 minecraft:deepslate_tiles
setblock 509 28 276 minecraft:deepslate_tiles
setblock 509 28 277 minecraft:cobbled_deepslate
setblock 510 28 276 minecraft:cobbled_deepslate
fill 510 28 277 510 31 277 minecraft:deepslate_tiles
setblock 510 28 316 minecraft:cobbled_deepslate
fill 511 28 276 511 31 276 minecraft:deepslate_tiles
setblock 511 28 280 minecraft:cobbled_deepslate
setblock 511 28 290 minecraft:cobbled_deepslate
fill 511 28 291 511 30 291 minecraft:deepslate_tiles
setblock 511 28 295 minecraft:cobbled_deepslate
fill 511 28 296 511 31 296 minecraft:deepslate_tiles
setblock 511 28 314 minecraft:deepslate_tiles
setblock 511 28 315 minecraft:cobbled_deepslate
fill 511 28 316 511 31 316 minecraft:deepslate_tiles
setblock 471 29 279 minecraft:cobbled_deepslate
fill 471 29 280 471 32 280 minecraft:deepslate_tiles
setblock 471 29 314 minecraft:cobbled_deepslate
fill 471 29 315 471 31 316 minecraft:deepslate_tiles
setblock 472 29 277 minecraft:deepslate_tiles
setblock 472 29 313 minecraft:cobbled_deepslate
fill 472 29 314 472 32 314 minecraft:deepslate_tiles
fill 472 29 316 473 29 316 minecraft:deepslate_tiles
setblock 473 29 277 minecraft:cobbled_deepslate
setblock 473 29 278 minecraft:light[level=13]
setblock 473 29 286 minecraft:light[level=13]
setblock 473 29 294 minecraft:light[level=13]
setblock 473 29 302 minecraft:light[level=13]
setblock 473 29 310 minecraft:light[level=13]
setblock 474 29 276 minecraft:cobbled_deepslate
fill 474 29 277 474 32 277 minecraft:deepslate_tiles
fill 474 29 314 475 29 314 minecraft:deepslate_tiles
setblock 474 29 316 minecraft:cobbled_deepslate
fill 475 29 276 475 32 276 minecraft:deepslate_tiles
setblock 475 29 315 minecraft:cobbled_deepslate
fill 475 29 316 475 32 316 minecraft:deepslate_tiles
setblock 476 29 314 minecraft:cobbled_deepslate
fill 476 29 315 476 32 315 minecraft:deepslate_tiles
fill 477 29 314 477 32 314 minecraft:deepslate_tiles
setblock 478 29 277 minecraft:cobbled_deepslate
fill 478 29 313 478 31 313 minecraft:deepslate_tiles
setblock 479 29 276 minecraft:cobbled_deepslate
fill 479 29 277 479 32 277 minecraft:deepslate_tiles
setblock 479 29 316 minecraft:cobbled_deepslate
fill 480 29 276 480 32 276 minecraft:deepslate_tiles
setblock 480 29 315 minecraft:cobbled_deepslate
fill 480 29 316 480 32 316 minecraft:deepslate_tiles
fill 481 29 277 482 29 277 minecraft:deepslate_tiles
setblock 481 29 278 minecraft:light[level=13]
setblock 481 29 286 minecraft:light[level=13]
setblock 481 29 294 minecraft:light[level=13]
setblock 481 29 302 minecraft:light[level=13]
setblock 481 29 310 minecraft:light[level=13]
setblock 481 29 314 minecraft:cobbled_deepslate
fill 481 29 315 481 32 315 minecraft:deepslate_tiles
setblock 482 29 313 minecraft:cobbled_deepslate
fill 482 29 314 482 32 314 minecraft:deepslate_tiles
setblock 483 29 277 minecraft:cobbled_deepslate
setblock 483 29 313 minecraft:deepslate_tiles
setblock 484 29 276 minecraft:cobbled_deepslate
fill 484 29 277 484 32 277 minecraft:deepslate_tiles
setblock 484 29 316 minecraft:cobbled_deepslate
fill 485 29 276 485 32 276 minecraft:deepslate_tiles
setblock 485 29 278 minecraft:crying_obsidian
setblock 485 29 282 minecraft:crying_obsidian
setblock 485 29 315 minecraft:cobbled_deepslate
fill 485 29 316 485 32 316 minecraft:deepslate_tiles
fill 486 29 315 486 31 315 minecraft:deepslate_tiles
setblock 488 29 276 minecraft:deepslate_tiles
setblock 489 29 286 minecraft:crying_obsidian
setblock 489 29 294 minecraft:light[level=13]
setblock 489 29 302 minecraft:light[level=13]
setblock 489 29 310 minecraft:light[level=13]
setblock 489 29 316 minecraft:cobbled_deepslate
fill 490 29 316 493 29 316 minecraft:deepslate_tiles
setblock 493 29 286 minecraft:crying_obsidian
setblock 494 29 276 minecraft:cobbled_deepslate
setblock 494 29 316 minecraft:cobbled_deepslate
fill 495 29 276 495 32 276 minecraft:deepslate_tiles
fill 495 29 316 495 32 316 minecraft:deepslate_tiles
setblock 497 29 277 minecraft:deepslate_tiles
setblock 497 29 278 minecraft:crying_obsidian
setblock 497 29 282 minecraft:crying_obsidian
setblock 497 29 286 minecraft:light[level=13]
setblock 497 29 294 minecraft:light[level=13]
setblock 497 29 302 minecraft:light[level=13]
setblock 497 29 310 minecraft:light[level=13]
fill 497 29 315 499 29 315 minecraft:deepslate_tiles
setblock 498 29 277 minecraft:cobbled_deepslate
setblock 499 29 276 minecraft:cobbled_deepslate
fill 499 29 277 502 29 277 minecraft:deepslate_tiles
setblock 499 29 316 minecraft:cobbled_deepslate
fill 500 29 276 500 32 276 minecraft:deepslate_tiles
fill 500 29 278 501 29 278 minecraft:deepslate_tiles
setblock 500 29 315 minecraft:cobbled_deepslate
fill 500 29 316 500 32 316 minecraft:deepslate_tiles
fill 501 29 315 501 32 315 minecraft:deepslate_tiles
setblock 502 29 278 minecraft:cobbled_deepslate
setblock 503 29 277 minecraft:cobbled_deepslate
fill 503 29 278 505 30 278 minecraft:deepslate_tiles
setblock 504 29 276 minecraft:cobbled_deepslate
fill 504 29 277 504 32 277 minecraft:deepslate_tiles
setblock 504 29 316 minecraft:cobbled_deepslate
fill 505 29 276 505 32 276 minecraft:deepslate_tiles
setblock 505 29 286 minecraft:light[level=13]
setblock 505 29 294 minecraft:light[level=13]
setblock 505 29 302 minecraft:light[level=13]
setblock 505 29 310 minecraft:light[level=13]
setblock 505 29 315 minecraft:cobbled_deepslate
fill 505 29 316 505 32 316 minecraft:deepslate_tiles
fill 506 29 277 507 29 277 minecraft:deepslate_tiles
setblock 506 29 315 minecraft:deepslate_tiles
setblock 508 29 277 minecraft:cobbled_deepslate
setblock 509 29 276 minecraft:cobbled_deepslate
fill 509 29 277 509 32 277 minecraft:deepslate_tiles
setblock 509 29 316 minecraft:cobbled_deepslate
fill 510 29 276 510 32 276 minecraft:deepslate_tiles
fill 510 29 278 511 29 278 minecraft:deepslate_tiles
fill 510 29 316 510 32 316 minecraft:deepslate_tiles
fill 511 29 277 511 30 277 minecraft:deepslate_tiles
setblock 511 29 279 minecraft:cobbled_deepslate
fill 511 29 280 511 30 282 minecraft:deepslate_tiles
setblock 511 29 290 minecraft:deepslate_tiles
setblock 511 29 294 minecraft:cobbled_deepslate
fill 511 29 295 511 32 295 minecraft:deepslate_tiles
fill 511 29 297 511 30 297 minecraft:deepslate_tiles
setblock 511 29 314 minecraft:cobbled_deepslate
fill 511 29 315 511 32 315 minecraft:deepslate_tiles
fill 470 30 296 470 81 297 minecraft:cobbled_deepslate
setblock 470 30 298 minecraft:white_wool
fill 470 30 299 470 41 303 minecraft:cobbled_deepslate
setblock 471 30 277 minecraft:deepslate_tiles
setblock 471 30 278 minecraft:cobbled_deepslate
fill 471 30 279 471 33 279 minecraft:deepslate_tiles
fill 471 30 296 471 30 297 minecraft:deepslate_tiles
setblock 471 30 313 minecraft:cobbled_deepslate
fill 471 30 314 471 33 314 minecraft:deepslate_tiles
setblock 472 30 277 minecraft:cobbled_deepslate
fill 472 30 278 472 33 278 minecraft:deepslate_tiles
fill 472 30 313 472 33 313 minecraft:deepslate_tiles
setblock 472 30 316 minecraft:deepslate_tiles
setblock 473 30 276 minecraft:cobbled_deepslate
fill 473 30 277 473 33 277 minecraft:deepslate_tiles
setblock 473 30 316 minecraft:cobbled_deepslate
fill 474 30 276 474 33 276 minecraft:deepslate_tiles
setblock 474 30 314 minecraft:deepslate_tiles
setblock 474 30 315 minecraft:cobbled_deepslate
fill 474 30 316 474 33 316 minecraft:deepslate_tiles
setblock 475 30 314 minecraft:cobbled_deepslate
fill 475 30 315 475 33 315 minecraft:deepslate_tiles
fill 476 30 314 476 33 314 minecraft:deepslate_tiles
setblock 477 30 276 minecraft:deepslate_tiles
setblock 477 30 277 minecraft:cobbled_deepslate
fill 477 30 278 480 30 278 minecraft:deepslate_tiles
setblock 478 30 276 minecraft:cobbled_deepslate
fill 478 30 277 478 33 277 minecraft:deepslate_tiles
setblock 478 30 316 minecraft:cobbled_deepslate
fill 479 30 276 479 33 276 minecraft:deepslate_tiles
setblock 479 30 315 minecraft:cobbled_deepslate
fill 479 30 316 479 33 316 minecraft:deepslate_tiles
setblock 480 30 314 minecraft:cobbled_deepslate
fill 480 30 315 480 33 315 minecraft:deepslate_tiles
setblock 481 30 277 minecraft:deepslate_tiles
setblock 481 30 278 minecraft:cobbled_deepslate
setblock 481 30 313 minecraft:cobbled_deepslate
fill 481 30 314 481 33 314 minecraft:deepslate_tiles
setblock 482 30 277 minecraft:cobbled_deepslate
setblock 482 30 313 minecraft:deepslate_tiles
setblock 483 30 276 minecraft:cobbled_deepslate
fill 483 30 277 483 33 277 minecraft:deepslate_tiles
setblock 483 30 316 minecraft:cobbled_deepslate
fill 484 30 276 484 33 276 minecraft:deepslate_tiles
setblock 484 30 315 minecraft:cobbled_deepslate
fill 484 30 316 484 33 316 minecraft:deepslate_tiles
setblock 485 30 277 minecraft:deepslate_tiles
setblock 485 30 279 minecraft:crying_obsidian
setblock 485 30 281 minecraft:crying_obsidian
fill 485 30 288 485 31 289 minecraft:white_wool
setblock 485 30 314 minecraft:cobbled_deepslate
fill 485 30 315 485 32 315 minecraft:deepslate_tiles
setblock 488 30 276 minecraft:cobbled_deepslate
setblock 488 30 316 minecraft:cobbled_deepslate
fill 489 30 276 491 30 276 minecraft:white_wool
fill 489 30 316 492 30 316 minecraft:deepslate_tiles
setblock 490 30 286 minecraft:crying_obsidian
setblock 492 30 276 minecraft:deepslate_tiles
setblock 492 30 286 minecraft:crying_obsidian
fill 492 30 317 492 43 317 minecraft:cobbled_deepslate
setblock 493 30 276 minecraft:cobbled_deepslate
setblock 493 30 316 minecraft:cobbled_deepslate
fill 494 30 276 494 33 276 minecraft:deepslate_tiles
fill 494 30 316 494 33 316 minecraft:deepslate_tiles
setblock 496 30 277 minecraft:deepslate_tiles
fill 496 30 315 498 30 315 minecraft:deepslate_tiles
setblock 497 30 276 minecraft:deepslate_tiles
setblock 497 30 277 minecraft:cobbled_deepslate
setblock 497 30 279 minecraft:crying_obsidian
setblock 497 30 281 minecraft:crying_obsidian
setblock 498 30 276 minecraft:cobbled_deepslate
fill 498 30 277 500 30 278 minecraft:deepslate_tiles
setblock 498 30 316 minecraft:cobbled_deepslate
fill 499 30 276 499 33 276 minecraft:deepslate_tiles
setblock 499 30 315 minecraft:cobbled_deepslate
fill 499 30 316 499 33 316 minecraft:deepslate_tiles
fill 500 30 315 500 33 315 minecraft:deepslate_tiles
setblock 501 30 277 minecraft:deepslate_tiles
setblock 501 30 278 minecraft:cobbled_deepslate
setblock 502 30 277 minecraft:cobbled_deepslate
fill 502 30 278 502 33 278 minecraft:deepslate_tiles
setblock 503 30 276 minecraft:cobbled_deepslate
fill 503 30 277 503 33 277 minecraft:deepslate_tiles
setblock 503 30 316 minecraft:cobbled_deepslate
fill 504 30 276 504 33 276 minecraft:deepslate_tiles
setblock 504 30 315 minecraft:cobbled_deepslate
fill 504 30 316 504 33 316 minecraft:deepslate_tiles
fill 505 30 315 505 31 315 minecraft:deepslate_tiles
setblock 506 30 277 minecraft:deepslate_tiles
setblock 506 30 278 minecraft:cobbled_deepslate
setblock 507 30 277 minecraft:cobbled_deepslate
setblock 508 30 276 minecraft:cobbled_deepslate
fill 508 30 277 508 33 277 minecraft:deepslate_tiles
setblock 508 30 316 minecraft:cobbled_deepslate
fill 509 30 276 509 33 276 minecraft:deepslate_tiles
fill 509 30 316 509 33 316 minecraft:deepslate_tiles
setblock 510 30 278 minecraft:deepslate_tiles
setblock 510 30 279 minecraft:cobbled_deepslate
fill 510 30 280 510 33 280 minecraft:deepslate_tiles
setblock 511 30 278 minecraft:cobbled_deepslate
fill 511 30 279 511 33 279 minecraft:deepslate_tiles
setblock 511 30 283 minecraft:cobbled_deepslate
setblock 511 30 293 minecraft:cobbled_deepslate
fill 511 30 294 511 32 294 minecraft:deepslate_tiles
setblock 511 30 298 minecraft:cobbled_deepslate
fill 511 30 314 511 33 314 minecraft:deepslate_tiles
fill 470 31 298 470 92 298 minecraft:cobbled_deepslate
setblock 471 31 277 minecraft:cobbled_deepslate
fill 471 31 278 471 34 278 minecraft:deepslate_tiles
setblock 471 31 281 minecraft:deepslate_tiles
fill 471 31 295 471 31 296 minecraft:deepslate_tiles
setblock 471 31 297 minecraft:cobbled_deepslate
fill 471 31 298 471 33 299 minecraft:deepslate_tiles
setblock 471 31 312 minecraft:cobbled_deepslate
fill 471 31 313 471 34 313 minecraft:deepslate_tiles
setblock 472 31 276 minecraft:cobbled_deepslate
fill 472 31 277 472 34 277 minecraft:deepslate_tiles
fill 472 31 279 472 32 279 minecraft:deepslate_tiles
setblock 472 31 316 minecraft:cobbled_deepslate
fill 473 31 276 473 34 276 minecraft:deepslate_tiles
setblock 473 31 278 minecraft:light[level=12]
setblock 473 31 285 minecraft:light[level=12]
setblock 473 31 292 minecraft:light[level=12]
setblock 473 31 299 minecraft:light[level=12]
setblock 473 31 306 minecraft:light[level=12]
setblock 473 31 313 minecraft:light[level=12]
setblock 473 31 315 minecraft:cobbled_deepslate
fill 473 31 316 473 34 316 minecraft:deepslate_tiles
setblock 474 31 314 minecraft:cobbled_deepslate
fill 474 31 315 474 34 315 minecraft:deepslate_tiles
setblock 475 31 277 minecraft:deepslate_tiles
setblock 475 31 278 minecraft:cobbled_deepslate
fill 475 31 314 475 34 314 minecraft:deepslate_tiles
setblock 476 31 277 minecraft:cobbled_deepslate
fill 476 31 278 479 31 278 minecraft:deepslate_tiles
setblock 477 31 276 minecraft:cobbled_deepslate
fill 477 31 277 477 34 277 minecraft:deepslate_tiles
setblock 477 31 316 minecraft:cobbled_deepslate
fill 478 31 276 478 34 276 minecraft:deepslate_tiles
setblock 478 31 315 minecraft:cobbled_deepslate
fill 478 31 316 478 34 316 minecraft:deepslate_tiles
setblock 479 31 314 minecraft:cobbled_deepslate
fill 479 31 315 479 34 315 minecraft:deepslate_tiles
setblock 480 31 278 minecraft:cobbled_deepslate
setblock 480 31 285 minecraft:light[level=12]
setblock 480 31 292 minecraft:light[level=12]
setblock 480 31 299 minecraft:light[level=12]
setblock 480 31 306 minecraft:light[level=12]
setblock 480 31 313 minecraft:cobbled_deepslate
fill 480 31 314 480 34 314 minecraft:deepslate_tiles
setblock 481 31 277 minecraft:cobbled_deepslate
fill 481 31 278 481 32 278 minecraft:deepslate_tiles
setblock 481 31 313 minecraft:deepslate_tiles
setblock 482 31 276 minecraft:cobbled_deepslate
fill 482 31 277 482 34 277 minecraft:deepslate_tiles
setblock 482 31 316 minecraft:cobbled_deepslate
fill 483 31 276 483 34 276 minecraft:deepslate_tiles
setblock 483 31 315 minecraft:cobbled_deepslate
fill 483 31 316 483 34 316 minecraft:deepslate_tiles
setblock 484 31 314 minecraft:cobbled_deepslate
fill 484 31 315 484 33 315 minecraft:deepslate_tiles
setblock 487 31 276 minecraft:cobbled_deepslate
setblock 487 31 285 minecraft:light[level=12]
setblock 487 31 292 minecraft:light[level=12]
setblock 487 31 299 minecraft:light[level=12]
setblock 487 31 306 minecraft:light[level=12]
setblock 487 31 313 minecraft:light[level=12]
setblock 487 31 316 minecraft:cobbled_deepslate
fill 488 31 276 491 31 276 minecraft:deepslate_tiles
fill 488 31 316 491 31 316 minecraft:deepslate_tiles
setblock 492 31 276 minecraft:cobbled_deepslate
setblock 492 31 316 minecraft:cobbled_deepslate
fill 493 31 276 493 34 276 minecraft:deepslate_tiles
fill 493 31 316 493 33 316 minecraft:deepslate_tiles
setblock 494 31 285 minecraft:light[level=12]
setblock 494 31 292 minecraft:light[level=12]
setblock 494 31 299 minecraft:light[level=12]
setblock 494 31 306 minecraft:light[level=12]
setblock 494 31 313 minecraft:light[level=12]
setblock 495 31 277 minecraft:deepslate_tiles
setblock 496 31 277 minecraft:cobbled_deepslate
fill 496 31 315 497 31 315 minecraft:deepslate_tiles
setblock 497 31 276 minecraft:cobbled_deepslate
fill 497 31 277 499 31 278 minecraft:deepslate_tiles
setblock 497 31 316 minecraft:cobbled_deepslate
fill 498 31 276 498 34 276 minecraft:deepslate_tiles
setblock 498 31 315 minecraft:cobbled_deepslate
fill 498 31 316 498 34 316 minecraft:deepslate_tiles
fill 499 31 315 499 33 315 minecraft:deepslate_tiles
setblock 500 31 277 minecraft:deepslate_tiles
setblock 500 31 278 minecraft:cobbled_deepslate
setblock 501 31 277 minecraft:cobbled_deepslate
fill 501 31 278 501 33 279 minecraft:deepslate_tiles
setblock 501 31 285 minecraft:light[level=12]
setblock 501 31 292 minecraft:light[level=12]
setblock 501 31 299 minecraft:light[level=12]
setblock 501 31 306 minecraft:light[level=12]
setblock 501 31 313 minecraft:light[level=12]
setblock 502 31 276 minecraft:cobbled_deepslate
fill 502 31 277 502 34 277 minecraft:deepslate_tiles
setblock 502 31 316 minecraft:cobbled_deepslate
fill 503 31 276 503 34 276 minecraft:deepslate_tiles
fill 503 31 278 504 31 278 minecraft:deepslate_tiles
setblock 503 31 315 minecraft:cobbled_deepslate
fill 503 31 316 503 34 316 minecraft:deepslate_tiles
setblock 504 31 315 minecraft:deepslate_tiles
setblock 505 31 278 minecraft:cobbled_deepslate
setblock 506 31 277 minecraft:cobbled_deepslate
fill 506 31 278 507 33 278 minecraft:deepslate_tiles
setblock 507 31 276 minecraft:cobbled_deepslate
fill 507 31 277 507 34 277 minecraft:deepslate_tiles
setblock 507 31 316 minecraft:cobbled_deepslate
fill 508 31 276 508 34 276 minecraft:deepslate_tiles
setblock 508 31 278 minecraft:light[level=12]
setblock 508 31 285 minecraft:light[level=12]
setblock 508 31 292 minecraft:light[level=12]
setblock 508 31 299 minecraft:light[level=12]
setblock 508 31 306 minecraft:light[level=12]
setblock 508 31 313 minecraft:light[level=12]
fill 508 31 316 508 34 316 minecraft:deepslate_tiles
setblock 510 31 278 minecraft:cobbled_deepslate
fill 510 31 279 510 34 279 minecraft:deepslate_tiles
setblock 511 31 277 minecraft:cobbled_deepslate
fill 511 31 278 511 34 278 minecraft:deepslate_tiles
fill 511 31 280 511 31 281 minecraft:deepslate_tiles
setblock 511 31 282 minecraft:cobbled_deepslate
fill 511 31 283 511 34 283 minecraft:deepslate_tiles
setblock 511 31 292 minecraft:cobbled_deepslate
fill 511 31 293 511 32 293 minecraft:deepslate_tiles
setblock 511 31 297 minecraft:cobbled_deepslate
fill 511 31 298 511 34 298 minecraft:deepslate_tiles
fill 470 32 305 470 64 306 minecraft:cobbled_deepslate
setblock 470 32 307 minecraft:white_wool
fill 470 32 308 470 34 312 minecraft:cobbled_deepslate
setblock 471 32 276 minecraft:cobbled_deepslate
fill 471 32 277 471 35 277 minecraft:deepslate_tiles
setblock 471 32 281 minecraft:cobbled_deepslate
setblock 471 32 296 minecraft:cobbled_deepslate
fill 471 32 297 471 35 297 minecraft:deepslate_tiles
setblock 471 32 300 minecraft:deepslate_tiles
setblock 471 32 301 minecraft:cobbled_deepslate
setblock 471 32 311 minecraft:cobbled_deepslate
fill 471 32 312 471 35 312 minecraft:deepslate_tiles
setblock 471 32 315 minecraft:deepslate_tiles
setblock 471 32 316 minecraft:cobbled_deepslate
fill 472 32 276 472 35 276 minecraft:deepslate_tiles
setblock 472 32 315 minecraft:cobbled_deepslate
fill 472 32 316 472 35 316 minecraft:deepslate_tiles
fill 473 32 315 473 35 315 minecraft:deepslate_tiles
setblock 474 32 278 minecraft:cobbled_deepslate
fill 474 32 314 474 33 314 minecraft:deepslate_tiles
setblock 475 32 277 minecraft:cobbled_deepslate
fill 475 32 278 478 32 278 minecraft:deepslate_tiles
setblock 476 32 276 minecraft:cobbled_deepslate
fill 476 32 277 476 35 277 minecraft:deepslate_tiles
setblock 476 32 316 minecraft:cobbled_deepslate
fill 477 32 276 477 35 276 minecraft:deepslate_tiles
setblock 477 32 315 minecraft:cobbled_deepslate
fill 477 32 316 477 35 316 minecraft:deepslate_tiles
setblock 478 32 314 minecraft:cobbled_deepslate
fill 478 32 315 478 35 315 minecraft:deepslate_tiles
setblock 479 32 278 minecraft:cobbled_deepslate
fill 479 32 314 479 34 314 minecraft:deepslate_tiles
setblock 480 32 277 minecraft:cobbled_deepslate
fill 480 32 278 480 33 278 minecraft:deepslate_tiles
setblock 481 32 276 minecraft:cobbled_deepslate
fill 481 32 277 481 35 277 minecraft:deepslate_tiles
setblock 481 32 316 minecraft:cobbled_deepslate
fill 482 32 276 482 35 276 minecraft:deepslate_tiles
setblock 482 32 315 minecraft:cobbled_deepslate
fill 482 32 316 482 35 316 minecraft:deepslate_tiles
setblock 483 32 314 minecraft:cobbled_deepslate
fill 483 32 315 483 33 315 minecraft:deepslate_tiles
setblock 486 32 276 minecraft:cobbled_deepslate
setblock 486 32 316 minecraft:cobbled_deepslate
fill 487 32 276 490 32 276 minecraft:deepslate_tiles
fill 487 32 316 490 32 316 minecraft:deepslate_tiles
setblock 491 32 276 minecraft:cobbled_deepslate
setblock 491 32 316 minecraft:cobbled_deepslate
fill 492 32 276 492 35 276 minecraft:deepslate_tiles
setblock 492 32 316 minecraft:deepslate_tiles
setblock 494 32 277 minecraft:deepslate_tiles
setblock 495 32 277 minecraft:cobbled_deepslate
setblock 496 32 276 minecraft:cobbled_deepslate
fill 496 32 277 498 32 278 minecraft:deepslate_tiles
setblock 496 32 315 minecraft:deepslate_tiles
setblock 496 32 316 minecraft:cobbled_deepslate
fill 497 32 276 497 35 276 minecraft:deepslate_tiles
setblock 497 32 315 minecraft:cobbled_deepslate
fill 497 32 316 497 35 316 minecraft:deepslate_tiles
fill 498 32 315 498 33 315 minecraft:deepslate_tiles
setblock 499 32 277 minecraft:deepslate_tiles
setblock 499 32 278 minecraft:cobbled_deepslate
fill 499 32 279 500 34 279 minecraft:deepslate_tiles
setblock 500 32 277 minecraft:cobbled_deepslate
fill 500 32 278 500 35 278 minecraft:deepslate_tiles
setblock 501 32 276 minecraft:cobbled_deepslate
fill 501 32 277 501 35 277 minecraft:deepslate_tiles
setblock 501 32 316 minecraft:cobbled_deepslate
fill 502 32 276 502 35 276 minecraft:deepslate_tiles
setblock 502 32 279 minecraft:deepslate_tiles
setblock 502 32 315 minecraft:cobbled_deepslate
fill 502 32 316 502 35 316 minecraft:deepslate_tiles
setblock 503 32 278 minecraft:deepslate_tiles
setblock 503 32 315 minecraft:deepslate_tiles
setblock 504 32 278 minecraft:cobbled_deepslate
setblock 505 32 277 minecraft:cobbled_deepslate
fill 505 32 278 505 34 278 minecraft:deepslate_tiles
setblock 506 32 276 minecraft:cobbled_deepslate
fill 506 32 277 506 35 277 minecraft:deepslate_tiles
setblock 506 32 316 minecraft:cobbled_deepslate
fill 507 32 276 507 35 276 minecraft:deepslate_tiles
fill 507 32 316 507 33 316 minecraft:deepslate_tiles
setblock 508 32 278 minecraft:deepslate_tiles
setblock 510 32 277 minecraft:cobbled_deepslate
fill 510 32 278 510 35 278 minecraft:deepslate_tiles
setblock 510 32 281 minecraft:deepslate_tiles
setblock 511 32 276 minecraft:cobbled_deepslate
fill 511 32 277 511 35 277 minecraft:deepslate_tiles
setblock 511 32 280 minecraft:deepslate_tiles
setblock 511 32 281 minecraft:cobbled_deepslate
fill 511 32 282 511 35 282 minecraft:deepslate_tiles
fill 511 32 284 511 33 284 minecraft:deepslate_tiles
setblock 511 32 296 minecraft:cobbled_deepslate
fill 511 32 297 511 33 297 minecraft:deepslate_tiles
fill 511 32 299 511 33 299 minecraft:deepslate_tiles
setblock 511 32 316 minecraft:cobbled_deepslate
fill 470 33 307 470 36 307 minecraft:cobbled_deepslate
fill 471 33 276 471 36 276 minecraft:deepslate_tiles
setblock 471 33 280 minecraft:cobbled_deepslate
fill 471 33 281 471 35 282 minecraft:deepslate_tiles
setblock 471 33 296 minecraft:deepslate_tiles
setblock 471 33 300 minecraft:cobbled_deepslate
fill 471 33 301 471 34 303 minecraft:deepslate_tiles
setblock 471 33 311 minecraft:deepslate_tiles
setblock 471 33 315 minecraft:cobbled_deepslate
fill 471 33 316 471 36 316 minecraft:deepslate_tiles
setblock 472 33 279 minecraft:cobbled_deepslate
fill 472 33 280 472 36 280 minecraft:deepslate_tiles
setblock 472 33 314 minecraft:cobbled_deepslate
fill 472 33 315 472 35 315 minecraft:deepslate_tiles
setblock 474 33 277 minecraft:cobbled_deepslate
fill 474 33 278 477 33 278 minecraft:deepslate_tiles
fill 475 33 275 475 33 276 minecraft:cobbled_deepslate
fill 475 33 277 475 36 277 minecraft:deepslate_tiles
setblock 475 33 316 minecraft:cobbled_deepslate
fill 476 33 275 480 58 275 minecraft:cobbled_deepslate
fill 476 33 276 476 36 276 minecraft:deepslate_tiles
setblock 476 33 315 minecraft:cobbled_deepslate
fill 476 33 316 476 36 316 minecraft:deepslate_tiles
setblock 477 33 314 minecraft:cobbled_deepslate
fill 477 33 315 477 36 315 minecraft:deepslate_tiles
setblock 478 33 278 minecraft:cobbled_deepslate
fill 478 33 314 478 34 314 minecraft:deepslate_tiles
setblock 479 33 277 minecraft:cobbled_deepslate
fill 479 33 278 479 34 278 minecraft:deepslate_tiles
setblock 480 33 276 minecraft:cobbled_deepslate
fill 480 33 277 480 36 277 minecraft:deepslate_tiles
setblock 480 33 316 minecraft:cobbled_deepslate
setblock 481 33 275 minecraft:redstone_block
fill 481 33 276 481 36 276 minecraft:deepslate_tiles
setblock 481 33 315 minecraft:cobbled_deepslate
fill 481 33 316 481 36 316 minecraft:deepslate_tiles
fill 482 33 275 483 94 275 minecraft:cobbled_deepslate
fill 482 33 315 482 34 315 minecraft:deepslate_tiles
setblock 485 33 276 minecraft:cobbled_deepslate
setblock 485 33 316 minecraft:cobbled_deepslate
fill 486 33 276 487 33 276 minecraft:deepslate_tiles
fill 486 33 316 487 33 316 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_2 1t
