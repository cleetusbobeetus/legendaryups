fill 330 -6 188 330 -6 190 minecraft:polished_basalt
fill 330 -6 192 330 -6 194 minecraft:polished_basalt
fill 330 -6 196 330 -6 198 minecraft:polished_basalt
fill 330 -6 200 330 -6 202 minecraft:polished_basalt
fill 330 -6 204 330 -6 206 minecraft:polished_basalt
fill 330 -6 208 330 -6 210 minecraft:polished_basalt
fill 330 -6 212 330 -6 214 minecraft:polished_basalt
fill 330 -6 216 330 -6 218 minecraft:polished_basalt
fill 330 -6 220 330 -6 222 minecraft:polished_basalt
setblock 331 -6 181 minecraft:bone_block
fill 331 -6 223 332 -1 223 minecraft:smooth_basalt
fill 332 -6 181 333 -1 181 minecraft:smooth_basalt
fill 332 -6 222 334 -6 222 minecraft:polished_basalt
fill 334 -6 181 335 -5 181 minecraft:bone_block
fill 334 -6 182 336 -6 182 minecraft:polished_basalt
fill 336 -6 222 338 -6 222 minecraft:polished_basalt
fill 338 -6 182 340 -6 182 minecraft:polished_basalt
fill 338 -6 223 338 -5 223 minecraft:bone_block
fill 339 -6 223 340 -5 223 minecraft:smooth_basalt
fill 340 -6 181 341 -1 181 minecraft:smooth_basalt
fill 340 -6 222 342 -6 222 minecraft:polished_basalt
fill 341 -6 223 342 -6 223 minecraft:bone_block
fill 342 -6 181 343 -6 181 minecraft:bone_block
fill 342 -6 182 344 -6 182 minecraft:polished_basalt
fill 343 -6 223 343 -1 223 minecraft:smooth_basalt
fill 344 -6 181 344 -1 181 minecraft:smooth_basalt
fill 344 -6 222 346 -6 222 minecraft:polished_basalt
fill 346 -6 182 348 -6 182 minecraft:polished_basalt
fill 348 -6 222 350 -6 222 minecraft:polished_basalt
fill 349 -6 223 350 -5 223 minecraft:bone_block
fill 350 -6 182 352 -6 182 minecraft:polished_basalt
fill 351 -6 223 352 -1 223 minecraft:smooth_basalt
fill 352 -6 181 353 -1 181 minecraft:smooth_basalt
fill 352 -6 222 354 -6 222 minecraft:polished_basalt
fill 354 -6 181 355 -5 181 minecraft:bone_block
fill 354 -6 182 356 -6 182 minecraft:polished_basalt
fill 356 -6 222 358 -6 222 minecraft:polished_basalt
fill 358 -6 182 360 -6 182 minecraft:polished_basalt
fill 360 -6 222 362 -6 222 minecraft:polished_basalt
fill 360 -6 223 360 -1 223 minecraft:smooth_basalt
fill 361 -6 181 361 -1 181 minecraft:smooth_basalt
fill 361 -6 223 362 -6 223 minecraft:bone_block
fill 362 -6 182 364 -6 182 minecraft:polished_basalt
setblock 363 -6 181 minecraft:bone_block
fill 363 -6 223 364 -1 223 minecraft:smooth_basalt
fill 364 -6 181 365 -1 181 minecraft:smooth_basalt
fill 364 -6 222 366 -6 222 minecraft:polished_basalt
fill 366 -6 181 366 -5 181 minecraft:bone_block
fill 366 -6 182 368 -6 182 minecraft:polished_basalt
fill 368 -6 222 370 -6 222 minecraft:polished_basalt
fill 369 -6 223 370 -5 223 minecraft:bone_block
fill 370 -6 182 370 -6 184 minecraft:polished_basalt
fill 370 -6 186 370 -6 188 minecraft:polished_basalt
fill 370 -6 190 370 -6 192 minecraft:polished_basalt
fill 370 -6 194 370 -6 196 minecraft:polished_basalt
fill 370 -6 198 370 -6 200 minecraft:polished_basalt
fill 370 -6 202 370 -6 204 minecraft:polished_basalt
fill 370 -6 206 370 -6 208 minecraft:polished_basalt
fill 370 -6 210 370 -6 212 minecraft:polished_basalt
fill 370 -6 214 370 -6 216 minecraft:polished_basalt
fill 370 -6 218 370 -6 220 minecraft:polished_basalt
fill 371 -6 182 371 -1 183 minecraft:smooth_basalt
fill 371 -6 184 371 -6 185 minecraft:bone_block
fill 371 -6 194 371 -1 195 minecraft:smooth_basalt
fill 371 -6 196 371 -5 197 minecraft:bone_block
fill 371 -6 203 371 -1 203 minecraft:smooth_basalt
fill 371 -6 204 371 -6 205 minecraft:bone_block
fill 371 -6 206 371 -1 206 minecraft:smooth_basalt
fill 371 -6 208 371 -5 208 minecraft:bone_block
fill 371 -6 214 371 -1 215 minecraft:smooth_basalt
fill 371 -6 216 371 -5 217 minecraft:bone_block
fill 371 -6 223 371 -1 223 minecraft:smooth_basalt
fill 329 -5 183 329 -2 183 minecraft:smooth_basalt
fill 329 -5 199 329 -5 200 minecraft:bone_block
setblock 329 -5 203 minecraft:bone_block
fill 329 -5 204 329 -2 204 minecraft:smooth_basalt
fill 329 -5 215 329 -2 215 minecraft:smooth_basalt
setblock 329 -5 220 minecraft:bone_block
fill 331 -5 181 331 -2 181 minecraft:smooth_basalt
setblock 337 -5 223 minecraft:bone_block
fill 341 -5 223 342 -3 223 minecraft:smooth_basalt
fill 342 -5 181 342 -2 181 minecraft:smooth_basalt
setblock 343 -5 181 minecraft:bone_block
fill 346 -5 181 347 -5 181 minecraft:bone_block
fill 357 -5 223 358 -5 223 minecraft:bone_block
setblock 361 -5 223 minecraft:bone_block
fill 362 -5 223 362 -2 223 minecraft:smooth_basalt
fill 363 -5 181 363 -2 181 minecraft:smooth_basalt
setblock 367 -5 181 minecraft:bone_block
fill 371 -5 184 371 -2 184 minecraft:smooth_basalt
setblock 371 -5 185 minecraft:bone_block
setblock 371 -5 188 minecraft:bone_block
fill 371 -5 204 371 -2 205 minecraft:smooth_basalt
setblock 371 -5 209 minecraft:bone_block
setblock 371 -5 220 minecraft:bone_block
fill 329 -4 189 329 -4 190 minecraft:bone_block
fill 329 -4 191 329 1 192 minecraft:smooth_basalt
fill 329 -4 198 329 -3 198 minecraft:bone_block
fill 329 -4 199 329 1 200 minecraft:smooth_basalt
setblock 329 -4 201 minecraft:bone_block
fill 329 -4 203 329 1 203 minecraft:smooth_basalt
fill 329 -4 209 329 -3 210 minecraft:bone_block
fill 329 -4 211 329 1 212 minecraft:smooth_basalt
fill 329 -4 220 329 1 220 minecraft:smooth_basalt
fill 329 -4 221 329 -4 222 minecraft:bone_block
fill 329 -4 223 330 -2 223 minecraft:smooth_basalt
fill 334 -4 181 335 1 181 minecraft:smooth_basalt
fill 335 -4 223 336 -3 223 minecraft:bone_block
fill 336 -4 181 337 -3 181 minecraft:bone_block
fill 337 -4 223 338 1 223 minecraft:smooth_basalt
setblock 339 -4 223 minecraft:bone_block
fill 340 -4 223 340 -1 223 minecraft:smooth_basalt
fill 343 -4 181 343 1 181 minecraft:smooth_basalt
setblock 345 -4 181 minecraft:bone_block
fill 346 -4 181 347 1 181 minecraft:smooth_basalt
fill 347 -4 223 348 -3 223 minecraft:bone_block
fill 348 -4 181 348 -3 181 minecraft:bone_block
fill 349 -4 223 350 1 223 minecraft:smooth_basalt
fill 354 -4 181 355 1 181 minecraft:smooth_basalt
fill 356 -4 181 357 -4 181 minecraft:bone_block
fill 356 -4 223 356 -3 223 minecraft:bone_block
fill 357 -4 223 358 1 223 minecraft:smooth_basalt
setblock 359 -4 223 minecraft:bone_block
fill 361 -4 223 361 1 223 minecraft:smooth_basalt
fill 366 -4 181 367 1 181 minecraft:smooth_basalt
fill 367 -4 223 368 -3 223 minecraft:bone_block
fill 368 -4 181 369 -3 181 minecraft:bone_block
fill 369 -4 223 370 1 223 minecraft:smooth_basalt
fill 371 -4 185 371 1 185 minecraft:smooth_basalt
fill 371 -4 186 371 -4 187 minecraft:bone_block
fill 371 -4 188 371 1 188 minecraft:smooth_basalt
fill 371 -4 190 371 -3 190 minecraft:bone_block
fill 371 -4 196 371 1 197 minecraft:smooth_basalt
fill 371 -4 198 371 -3 199 minecraft:bone_block
setblock 371 -4 207 minecraft:bone_block
fill 371 -4 208 371 1 209 minecraft:smooth_basalt
fill 371 -4 210 371 -3 211 minecraft:bone_block
fill 371 -4 216 371 1 217 minecraft:smooth_basalt
fill 371 -4 218 371 -4 219 minecraft:bone_block
fill 371 -4 220 371 1 220 minecraft:smooth_basalt
setblock 329 -3 186 minecraft:bone_block
setblock 329 -3 189 minecraft:bone_block
fill 329 -3 190 329 0 190 minecraft:smooth_basalt
setblock 329 -3 197 minecraft:bone_block
fill 329 -3 201 329 0 201 minecraft:smooth_basalt
fill 329 -3 217 329 -3 218 minecraft:bone_block
setblock 329 -3 221 minecraft:bone_block
fill 329 -3 222 329 0 222 minecraft:smooth_basalt
fill 339 -3 223 339 -1 223 minecraft:smooth_basalt
setblock 344 -3 223 minecraft:bone_block
fill 345 -3 181 345 0 181 minecraft:smooth_basalt
setblock 349 -3 181 minecraft:bone_block
setblock 355 -3 223 minecraft:bone_block
fill 356 -3 181 356 0 181 minecraft:smooth_basalt
setblock 357 -3 181 minecraft:bone_block
fill 359 -3 223 359 0 223 minecraft:smooth_basalt
setblock 360 -3 181 minecraft:bone_block
fill 371 -3 186 371 0 187 minecraft:smooth_basalt
setblock 371 -3 191 minecraft:bone_block
setblock 371 -3 202 minecraft:bone_block
fill 371 -3 207 371 0 207 minecraft:smooth_basalt
fill 371 -3 218 371 0 218 minecraft:smooth_basalt
setblock 371 -3 219 minecraft:bone_block
setblock 371 -3 222 minecraft:bone_block
fill 329 -2 184 329 -1 184 minecraft:bone_block
fill 329 -2 186 329 3 186 minecraft:smooth_basalt
fill 329 -2 187 329 -2 188 minecraft:bone_block
fill 329 -2 189 329 3 189 minecraft:smooth_basalt
fill 329 -2 195 329 -1 196 minecraft:bone_block
fill 329 -2 197 329 3 198 minecraft:smooth_basalt
fill 329 -2 207 329 -2 208 minecraft:bone_block
fill 329 -2 209 329 3 210 minecraft:smooth_basalt
fill 329 -2 216 329 -1 216 minecraft:bone_block
fill 329 -2 217 329 3 218 minecraft:smooth_basalt
setblock 329 -2 219 minecraft:bone_block
fill 329 -2 221 329 0 221 minecraft:smooth_basalt
fill 330 -2 181 330 -1 181 minecraft:bone_block
fill 333 -2 223 334 -1 223 minecraft:bone_block
fill 335 -2 223 336 3 223 minecraft:smooth_basalt
fill 336 -2 181 337 3 181 minecraft:smooth_basalt
fill 338 -2 181 339 -2 181 minecraft:bone_block
setblock 341 -2 223 minecraft:smooth_basalt
fill 342 -2 223 342 -1 223 minecraft:bone_block
fill 344 -2 223 344 3 223 minecraft:smooth_basalt
fill 345 -2 223 346 -2 223 minecraft:bone_block
fill 347 -2 223 348 0 223 minecraft:smooth_basalt
fill 348 -2 181 349 3 181 minecraft:smooth_basalt
fill 350 -2 181 351 -1 181 minecraft:bone_block
fill 353 -2 223 354 -1 223 minecraft:bone_block
fill 355 -2 223 356 3 223 minecraft:smooth_basalt
fill 357 -2 181 357 3 181 minecraft:smooth_basalt
fill 358 -2 181 359 -2 181 minecraft:bone_block
fill 360 -2 181 360 3 181 minecraft:smooth_basalt
fill 362 -2 181 362 -1 181 minecraft:bone_block
fill 365 -2 223 366 -2 223 minecraft:bone_block
fill 367 -2 223 368 3 223 minecraft:smooth_basalt
fill 368 -2 181 369 3 181 minecraft:smooth_basalt
fill 370 -2 181 371 -1 181 minecraft:bone_block
setblock 371 -2 189 minecraft:bone_block
fill 371 -2 190 371 3 191 minecraft:smooth_basalt
fill 371 -2 192 371 -1 193 minecraft:bone_block
fill 371 -2 198 371 3 199 minecraft:smooth_basalt
fill 371 -2 200 371 -2 201 minecraft:bone_block
fill 371 -2 202 371 3 202 minecraft:smooth_basalt
fill 371 -2 210 371 3 211 minecraft:smooth_basalt
fill 371 -2 212 371 -1 213 minecraft:bone_block
fill 371 -2 219 371 3 219 minecraft:smooth_basalt
setblock 371 -2 221 minecraft:bone_block
fill 371 -2 222 371 3 222 minecraft:smooth_basalt
setblock 329 -1 183 minecraft:bone_block
fill 329 -1 187 329 2 188 minecraft:smooth_basalt
setblock 329 -1 204 minecraft:bone_block
setblock 329 -1 207 minecraft:bone_block
fill 329 -1 208 329 2 208 minecraft:smooth_basalt
setblock 329 -1 215 minecraft:bone_block
fill 329 -1 219 329 2 219 minecraft:smooth_basalt
fill 329 -1 223 329 1 223 minecraft:smooth_basalt
setblock 330 -1 223 minecraft:bone_block
setblock 331 -1 181 minecraft:bone_block
fill 338 -1 181 338 2 181 minecraft:smooth_basalt
setblock 339 -1 181 minecraft:bone_block
setblock 341 -1 223 minecraft:bone_block
setblock 342 -1 181 minecraft:bone_block
setblock 345 -1 223 minecraft:bone_block
fill 346 -1 223 346 2 223 minecraft:smooth_basalt
fill 358 -1 181 359 2 181 minecraft:smooth_basalt
setblock 362 -1 223 minecraft:bone_block
setblock 363 -1 181 minecraft:bone_block
setblock 365 -1 223 minecraft:bone_block
fill 366 -1 223 366 2 223 minecraft:smooth_basalt
setblock 371 -1 184 minecraft:bone_block
fill 371 -1 189 371 2 189 minecraft:smooth_basalt
fill 371 -1 200 371 2 200 minecraft:smooth_basalt
setblock 371 -1 201 minecraft:bone_block
fill 371 -1 204 371 -1 205 minecraft:bone_block
fill 371 -1 221 371 2 221 minecraft:smooth_basalt
fill 329 0 181 329 1 182 minecraft:bone_block
fill 329 0 183 329 5 184 minecraft:smooth_basalt
setblock 329 0 185 minecraft:bone_block
fill 329 0 193 329 1 194 minecraft:bone_block
fill 329 0 195 329 5 196 minecraft:smooth_basalt
fill 329 0 202 329 1 202 minecraft:bone_block
fill 329 0 204 329 5 204 minecraft:smooth_basalt
fill 329 0 205 329 0 206 minecraft:bone_block
fill 329 0 207 329 5 207 minecraft:smooth_basalt
fill 329 0 213 329 1 214 minecraft:bone_block
fill 329 0 215 329 5 216 minecraft:smooth_basalt
fill 330 0 181 331 5 181 minecraft:smooth_basalt
fill 330 0 182 332 0 182 minecraft:polished_basalt
fill 330 0 184 330 0 186 minecraft:polished_basalt
fill 330 0 188 330 0 190 minecraft:polished_basalt
fill 330 0 192 330 0 194 minecraft:polished_basalt
fill 330 0 196 330 0 198 minecraft:polished_basalt
fill 330 0 200 330 0 202 minecraft:polished_basalt
fill 330 0 204 330 0 206 minecraft:polished_basalt
fill 330 0 208 330 0 210 minecraft:polished_basalt
fill 330 0 212 330 0 214 minecraft:polished_basalt
fill 330 0 216 330 0 218 minecraft:polished_basalt
fill 330 0 220 330 0 222 minecraft:polished_basalt
fill 330 0 223 330 1 223 minecraft:smooth_basalt
fill 331 0 223 332 0 223 minecraft:bone_block
fill 332 0 181 333 1 181 minecraft:bone_block
fill 332 0 222 334 0 222 minecraft:polished_basalt
fill 333 0 223 334 5 223 minecraft:smooth_basalt
fill 334 0 182 336 0 182 minecraft:polished_basalt
fill 336 0 222 338 0 222 minecraft:polished_basalt
fill 338 0 182 340 0 182 minecraft:polished_basalt
fill 339 0 181 339 5 181 minecraft:smooth_basalt
fill 339 0 223 340 1 223 minecraft:bone_block
fill 340 0 181 341 0 181 minecraft:bone_block
fill 340 0 222 342 0 222 minecraft:polished_basalt
fill 341 0 223 342 5 223 minecraft:smooth_basalt
fill 342 0 181 342 5 181 minecraft:smooth_basalt
fill 342 0 182 344 0 182 minecraft:polished_basalt
setblock 343 0 223 minecraft:bone_block
fill 344 0 181 344 1 181 minecraft:bone_block
fill 344 0 222 346 0 222 minecraft:polished_basalt
fill 345 0 223 345 2 223 minecraft:smooth_basalt
fill 346 0 182 348 0 182 minecraft:polished_basalt
fill 348 0 222 350 0 222 minecraft:polished_basalt
fill 350 0 181 351 5 181 minecraft:smooth_basalt
fill 350 0 182 352 0 182 minecraft:polished_basalt
fill 351 0 223 352 1 223 minecraft:bone_block
fill 352 0 181 353 1 181 minecraft:bone_block
fill 352 0 222 354 0 222 minecraft:polished_basalt
fill 353 0 223 354 5 223 minecraft:smooth_basalt
fill 354 0 182 356 0 182 minecraft:polished_basalt
fill 356 0 222 358 0 222 minecraft:polished_basalt
fill 358 0 182 360 0 182 minecraft:polished_basalt
fill 360 0 222 362 0 222 minecraft:polished_basalt
fill 360 0 223 360 1 223 minecraft:bone_block
setblock 361 0 181 minecraft:bone_block
fill 362 0 181 363 5 181 minecraft:smooth_basalt
fill 362 0 182 364 0 182 minecraft:polished_basalt
fill 362 0 223 362 5 223 minecraft:smooth_basalt
fill 363 0 223 364 0 223 minecraft:bone_block
fill 364 0 181 365 1 181 minecraft:bone_block
fill 364 0 222 366 0 222 minecraft:polished_basalt
fill 365 0 223 365 5 223 minecraft:smooth_basalt
fill 366 0 182 368 0 182 minecraft:polished_basalt
fill 368 0 222 370 0 222 minecraft:polished_basalt
fill 370 0 181 371 5 181 minecraft:smooth_basalt
fill 370 0 182 370 0 184 minecraft:polished_basalt
fill 370 0 186 370 0 188 minecraft:polished_basalt
fill 370 0 190 370 0 192 minecraft:polished_basalt
fill 370 0 194 370 0 196 minecraft:polished_basalt
fill 370 0 198 370 0 200 minecraft:polished_basalt
fill 370 0 202 370 0 204 minecraft:polished_basalt
fill 370 0 206 370 0 208 minecraft:polished_basalt
fill 370 0 210 370 0 212 minecraft:polished_basalt
fill 370 0 214 370 0 216 minecraft:polished_basalt
fill 370 0 218 370 0 220 minecraft:polished_basalt
fill 371 0 182 371 0 183 minecraft:bone_block
fill 371 0 184 371 5 184 minecraft:smooth_basalt
fill 371 0 192 371 5 193 minecraft:smooth_basalt
fill 371 0 194 371 1 195 minecraft:bone_block
fill 371 0 201 371 5 201 minecraft:smooth_basalt
setblock 371 0 203 minecraft:bone_block
fill 371 0 204 371 5 205 minecraft:smooth_basalt
fill 371 0 206 371 1 206 minecraft:bone_block
fill 371 0 212 371 5 213 minecraft:smooth_basalt
fill 371 0 214 371 0 215 minecraft:bone_block
fill 371 0 223 371 1 223 minecraft:bone_block
fill 329 1 185 329 4 185 minecraft:smooth_basalt
setblock 329 1 190 minecraft:bone_block
setblock 329 1 201 minecraft:bone_block
fill 329 1 205 329 4 206 minecraft:smooth_basalt
fill 329 1 221 329 1 222 minecraft:bone_block
setblock 331 1 223 minecraft:bone_block
setblock 332 1 184 minecraft:light[level=12]
setblock 332 1 192 minecraft:light[level=12]
setblock 332 1 200 minecraft:light[level=12]
setblock 332 1 208 minecraft:light[level=12]
setblock 332 1 216 minecraft:light[level=12]
fill 332 1 223 332 4 223 minecraft:smooth_basalt
fill 340 1 181 341 4 181 minecraft:smooth_basalt
setblock 340 1 184 minecraft:light[level=12]
setblock 340 1 192 minecraft:light[level=12]
setblock 340 1 200 minecraft:light[level=12]
setblock 340 1 208 minecraft:light[level=12]
setblock 340 1 216 minecraft:light[level=12]
fill 343 1 223 343 4 223 minecraft:smooth_basalt
setblock 345 1 181 minecraft:bone_block
fill 347 1 223 347 3 223 minecraft:smooth_basalt
setblock 348 1 184 minecraft:light[level=12]
setblock 348 1 192 minecraft:light[level=12]
setblock 348 1 200 minecraft:light[level=12]
setblock 348 1 208 minecraft:light[level=12]
setblock 348 1 216 minecraft:light[level=12]
setblock 348 1 223 minecraft:bone_block
setblock 356 1 181 minecraft:bone_block
setblock 356 1 184 minecraft:light[level=12]
setblock 356 1 192 minecraft:light[level=12]
setblock 356 1 200 minecraft:light[level=12]
setblock 356 1 208 minecraft:light[level=12]
setblock 356 1 216 minecraft:light[level=12]
setblock 359 1 223 minecraft:bone_block
fill 361 1 181 361 4 181 minecraft:smooth_basalt
fill 363 1 223 364 4 223 minecraft:smooth_basalt
setblock 364 1 184 minecraft:light[level=12]
setblock 364 1 192 minecraft:light[level=12]
setblock 364 1 200 minecraft:light[level=12]
setblock 364 1 208 minecraft:light[level=12]
setblock 364 1 216 minecraft:light[level=12]
fill 371 1 182 371 4 182 minecraft:smooth_basalt
setblock 371 1 183 minecraft:bone_block
fill 371 1 186 371 1 187 minecraft:bone_block
fill 371 1 203 371 4 203 minecraft:smooth_basalt
setblock 371 1 207 minecraft:bone_block
fill 371 1 214 371 4 214 minecraft:smooth_basalt
setblock 371 1 215 minecraft:bone_block
setblock 371 1 218 minecraft:bone_block
fill 329 2 181 329 7 182 minecraft:smooth_basalt
fill 329 2 190 329 7 190 minecraft:smooth_basalt
fill 329 2 191 329 2 192 minecraft:bone_block
fill 329 2 193 329 7 194 minecraft:smooth_basalt
fill 329 2 199 329 3 200 minecraft:bone_block
fill 329 2 201 329 7 202 minecraft:smooth_basalt
setblock 329 2 203 minecraft:bone_block
fill 329 2 211 329 3 212 minecraft:bone_block
fill 329 2 213 329 7 214 minecraft:smooth_basalt
fill 329 2 220 329 3 220 minecraft:bone_block
fill 329 2 221 329 3 222 minecraft:smooth_basalt
fill 329 2 223 330 2 223 minecraft:bone_block
fill 331 2 223 331 7 223 minecraft:smooth_basalt
fill 332 2 181 333 7 181 minecraft:smooth_basalt
fill 334 2 181 335 3 181 minecraft:bone_block
fill 337 2 223 338 3 223 minecraft:bone_block
fill 339 2 223 340 7 223 minecraft:smooth_basalt
setblock 343 2 181 minecraft:bone_block
fill 344 2 181 345 7 181 minecraft:smooth_basalt
fill 346 2 181 347 3 181 minecraft:bone_block
fill 348 2 223 348 7 223 minecraft:smooth_basalt
fill 349 2 223 350 2 223 minecraft:bone_block
fill 351 2 223 352 7 223 minecraft:smooth_basalt
fill 352 2 181 353 7 181 minecraft:smooth_basalt
fill 354 2 181 355 2 181 minecraft:bone_block
fill 356 2 181 356 7 181 minecraft:smooth_basalt
fill 357 2 223 358 3 223 minecraft:bone_block
fill 359 2 223 360 7 223 minecraft:smooth_basalt
setblock 361 2 223 minecraft:bone_block
fill 364 2 181 365 7 181 minecraft:smooth_basalt
fill 366 2 181 367 3 181 minecraft:bone_block
fill 369 2 223 370 3 223 minecraft:bone_block
fill 371 2 183 371 7 183 minecraft:smooth_basalt
setblock 371 2 185 minecraft:bone_block
fill 371 2 186 371 7 187 minecraft:smooth_basalt
fill 371 2 188 371 3 188 minecraft:bone_block
fill 371 2 194 371 7 195 minecraft:smooth_basalt
fill 371 2 196 371 2 197 minecraft:bone_block
fill 371 2 206 371 7 207 minecraft:smooth_basalt
fill 371 2 208 371 3 209 minecraft:bone_block
fill 371 2 215 371 7 215 minecraft:smooth_basalt
fill 371 2 216 371 2 217 minecraft:bone_block
fill 371 2 218 371 7 218 minecraft:smooth_basalt
fill 371 2 220 371 3 220 minecraft:bone_block
fill 371 2 223 371 7 223 minecraft:smooth_basalt
fill 329 3 187 329 3 188 minecraft:bone_block
setblock 329 3 191 minecraft:bone_block
fill 329 3 192 329 6 192 minecraft:smooth_basalt
fill 329 3 203 329 6 203 minecraft:smooth_basalt
setblock 329 3 208 minecraft:bone_block
setblock 329 3 219 minecraft:bone_block
fill 329 3 223 330 5 223 minecraft:smooth_basalt
setblock 338 3 181 minecraft:bone_block
fill 343 3 181 343 6 181 minecraft:smooth_basalt
fill 345 3 223 346 3 223 minecraft:bone_block
setblock 349 3 223 minecraft:bone_block
fill 350 3 223 350 6 223 minecraft:smooth_basalt
fill 354 3 181 354 6 181 minecraft:smooth_basalt
setblock 355 3 181 minecraft:bone_block
fill 358 3 181 359 3 181 minecraft:bone_block
fill 361 3 223 361 6 223 minecraft:smooth_basalt
setblock 366 3 223 minecraft:bone_block
fill 371 3 185 371 6 185 minecraft:smooth_basalt
setblock 371 3 189 minecraft:bone_block
fill 371 3 196 371 6 196 minecraft:smooth_basalt
setblock 371 3 197 minecraft:bone_block
setblock 371 3 200 minecraft:bone_block
fill 371 3 216 371 6 217 minecraft:smooth_basalt
setblock 371 3 221 minecraft:bone_block
fill 329 4 186 329 5 186 minecraft:bone_block
fill 329 4 187 329 9 188 minecraft:smooth_basalt
setblock 329 4 189 minecraft:bone_block
fill 329 4 191 329 9 191 minecraft:smooth_basalt
fill 329 4 197 329 5 198 minecraft:bone_block
fill 329 4 199 329 9 200 minecraft:smooth_basalt
fill 329 4 208 329 9 208 minecraft:smooth_basalt
fill 329 4 209 329 4 210 minecraft:bone_block
fill 329 4 211 329 6 212 minecraft:smooth_basalt
fill 329 4 217 329 5 218 minecraft:bone_block
fill 329 4 219 329 9 220 minecraft:smooth_basalt
setblock 329 4 221 minecraft:bone_block
fill 329 4 222 329 7 222 minecraft:smooth_basalt
fill 334 4 181 335 9 181 minecraft:smooth_basalt
fill 335 4 223 336 5 223 minecraft:bone_block
fill 336 4 181 337 4 181 minecraft:bone_block
fill 337 4 223 338 9 223 minecraft:smooth_basalt
fill 338 4 181 338 9 181 minecraft:smooth_basalt
fill 344 4 223 344 5 223 minecraft:bone_block
fill 345 4 223 346 9 223 minecraft:smooth_basalt
fill 346 4 181 347 9 181 minecraft:smooth_basalt
setblock 347 4 223 minecraft:bone_block
fill 348 4 181 349 5 181 minecraft:bone_block
fill 349 4 223 349 9 223 minecraft:smooth_basalt
fill 355 4 181 355 9 181 minecraft:smooth_basalt
fill 355 4 223 356 5 223 minecraft:bone_block
setblock 357 4 181 minecraft:bone_block
fill 357 4 223 358 9 223 minecraft:smooth_basalt
fill 358 4 181 359 9 181 minecraft:smooth_basalt
fill 360 4 181 360 5 181 minecraft:bone_block
fill 366 4 181 367 9 181 minecraft:smooth_basalt
fill 366 4 223 366 9 223 minecraft:smooth_basalt
fill 367 4 223 368 4 223 minecraft:bone_block
fill 368 4 181 369 4 181 minecraft:bone_block
fill 369 4 223 370 9 223 minecraft:smooth_basalt
fill 371 4 188 371 9 189 minecraft:smooth_basalt
fill 371 4 190 371 5 191 minecraft:bone_block
fill 371 4 197 371 9 197 minecraft:smooth_basalt
fill 371 4 198 371 4 199 minecraft:bone_block
fill 371 4 200 371 9 200 minecraft:smooth_basalt
fill 371 4 202 371 5 202 minecraft:bone_block
fill 371 4 208 371 9 209 minecraft:smooth_basalt
fill 371 4 210 371 5 211 minecraft:bone_block
setblock 371 4 219 minecraft:bone_block
fill 371 4 220 371 9 221 minecraft:smooth_basalt
fill 371 4 222 371 5 222 minecraft:bone_block
setblock 329 5 185 minecraft:bone_block
fill 329 5 189 329 8 189 minecraft:smooth_basalt
fill 329 5 205 329 5 206 minecraft:bone_block
setblock 329 5 209 minecraft:bone_block
fill 329 5 210 329 8 210 minecraft:smooth_basalt
fill 329 5 221 329 7 221 minecraft:smooth_basalt
setblock 332 5 223 minecraft:bone_block
fill 336 5 181 336 8 181 minecraft:smooth_basalt
setblock 337 5 181 minecraft:bone_block
fill 340 5 181 341 5 181 minecraft:bone_block
setblock 343 5 223 minecraft:bone_block
fill 347 5 223 347 8 223 minecraft:smooth_basalt
fill 357 5 181 357 8 181 minecraft:smooth_basalt
setblock 361 5 181 minecraft:bone_block
fill 363 5 223 364 5 223 minecraft:bone_block
setblock 367 5 223 minecraft:bone_block
fill 368 5 181 368 8 181 minecraft:smooth_basalt
fill 368 5 223 368 8 223 minecraft:smooth_basalt
setblock 369 5 181 minecraft:bone_block
setblock 371 5 182 minecraft:bone_block
fill 371 5 198 371 8 199 minecraft:smooth_basalt
setblock 371 5 203 minecraft:bone_block
setblock 371 5 214 minecraft:bone_block
fill 371 5 219 371 8 219 minecraft:smooth_basalt
fill 329 6 183 329 7 184 minecraft:bone_block
fill 329 6 185 329 11 186 minecraft:smooth_basalt
fill 329 6 195 329 6 196 minecraft:bone_block
fill 329 6 197 329 11 198 minecraft:smooth_basalt
fill 329 6 204 329 7 204 minecraft:bone_block
fill 329 6 205 329 11 206 minecraft:smooth_basalt
setblock 329 6 207 minecraft:bone_block
fill 329 6 209 329 8 209 minecraft:smooth_basalt
fill 329 6 215 329 7 216 minecraft:bone_block
fill 329 6 217 329 11 218 minecraft:smooth_basalt
setblock 329 6 223 minecraft:smooth_basalt
fill 330 6 181 331 7 181 minecraft:bone_block
fill 330 6 182 332 6 182 minecraft:polished_basalt
fill 330 6 184 330 6 186 minecraft:polished_basalt
fill 330 6 188 330 6 190 minecraft:polished_basalt
fill 330 6 192 330 6 194 minecraft:polished_basalt
fill 330 6 196 330 6 198 minecraft:polished_basalt
fill 330 6 200 330 6 202 minecraft:polished_basalt
fill 330 6 204 330 6 206 minecraft:polished_basalt
fill 330 6 208 330 6 210 minecraft:polished_basalt
fill 330 6 212 330 6 214 minecraft:polished_basalt
fill 330 6 216 330 6 218 minecraft:polished_basalt
fill 330 6 220 330 6 222 minecraft:polished_basalt
fill 330 6 223 330 7 223 minecraft:bone_block
fill 332 6 222 334 6 222 minecraft:polished_basalt
fill 332 6 223 332 11 223 minecraft:smooth_basalt
fill 333 6 223 334 6 223 minecraft:bone_block
fill 334 6 182 336 6 182 minecraft:polished_basalt
fill 335 6 223 336 8 223 minecraft:smooth_basalt
fill 336 6 222 338 6 222 minecraft:polished_basalt
fill 337 6 181 337 11 181 minecraft:smooth_basalt
fill 338 6 182 340 6 182 minecraft:polished_basalt
setblock 339 6 181 minecraft:bone_block
fill 340 6 181 341 11 181 minecraft:smooth_basalt
fill 340 6 222 342 6 222 minecraft:polished_basalt
fill 341 6 223 342 7 223 minecraft:bone_block
fill 342 6 181 342 7 181 minecraft:bone_block
fill 342 6 182 344 6 182 minecraft:polished_basalt
fill 343 6 223 344 11 223 minecraft:smooth_basalt
fill 344 6 222 346 6 222 minecraft:polished_basalt
fill 346 6 182 348 6 182 minecraft:polished_basalt
fill 348 6 181 349 11 181 minecraft:smooth_basalt
fill 348 6 222 350 6 222 minecraft:polished_basalt
fill 350 6 181 351 6 181 minecraft:bone_block
fill 350 6 182 352 6 182 minecraft:polished_basalt
fill 352 6 222 354 6 222 minecraft:polished_basalt
fill 353 6 223 354 6 223 minecraft:bone_block
fill 354 6 182 356 6 182 minecraft:polished_basalt
fill 355 6 223 356 11 223 minecraft:smooth_basalt
fill 356 6 222 358 6 222 minecraft:polished_basalt
fill 358 6 182 360 6 182 minecraft:polished_basalt
fill 360 6 181 361 11 181 minecraft:smooth_basalt
fill 360 6 222 362 6 222 minecraft:polished_basalt
fill 362 6 181 363 7 181 minecraft:bone_block
fill 362 6 182 364 6 182 minecraft:polished_basalt
fill 362 6 223 362 7 223 minecraft:bone_block
fill 363 6 223 364 11 223 minecraft:smooth_basalt
fill 364 6 222 366 6 222 minecraft:polished_basalt
setblock 365 6 223 minecraft:bone_block
fill 366 6 182 368 6 182 minecraft:polished_basalt
fill 367 6 223 367 11 223 minecraft:smooth_basalt
fill 368 6 222 370 6 222 minecraft:polished_basalt
fill 369 6 181 369 11 181 minecraft:smooth_basalt
fill 370 6 181 371 6 181 minecraft:bone_block
fill 370 6 182 370 6 184 minecraft:polished_basalt
fill 370 6 186 370 6 188 minecraft:polished_basalt
fill 370 6 190 370 6 192 minecraft:polished_basalt
fill 370 6 194 370 6 196 minecraft:polished_basalt
fill 370 6 198 370 6 200 minecraft:polished_basalt
fill 370 6 202 370 6 204 minecraft:polished_basalt
fill 370 6 206 370 6 208 minecraft:polished_basalt
fill 370 6 210 370 6 212 minecraft:polished_basalt
fill 370 6 214 370 6 216 minecraft:polished_basalt
fill 370 6 218 370 6 220 minecraft:polished_basalt
fill 371 6 182 371 11 182 minecraft:smooth_basalt
fill 371 6 184 371 7 184 minecraft:bone_block
fill 371 6 190 371 11 191 minecraft:smooth_basalt
fill 371 6 192 371 7 193 minecraft:bone_block
setblock 371 6 201 minecraft:bone_block
fill 371 6 202 371 11 203 minecraft:smooth_basalt
fill 371 6 204 371 7 205 minecraft:bone_block
fill 371 6 210 371 11 211 minecraft:smooth_basalt
fill 371 6 212 371 6 213 minecraft:bone_block
fill 371 6 214 371 11 214 minecraft:smooth_basalt
fill 371 6 222 371 11 222 minecraft:smooth_basalt
setblock 329 7 192 minecraft:bone_block
setblock 329 7 195 minecraft:bone_block
fill 329 7 196 329 10 196 minecraft:smooth_basalt
setblock 329 7 203 minecraft:bone_block
fill 329 7 207 329 10 207 minecraft:smooth_basalt
fill 329 7 211 329 9 211 minecraft:smooth_basalt
setblock 329 7 212 minecraft:bone_block
setblock 329 7 223 minecraft:bone_block
setblock 333 7 223 minecraft:bone_block
fill 334 7 223 334 10 223 minecraft:smooth_basalt
fill 339 7 181 339 10 181 minecraft:smooth_basalt
setblock 343 7 181 minecraft:bone_block
fill 350 7 181 350 10 181 minecraft:smooth_basalt
setblock 350 7 223 minecraft:bone_block
setblock 351 7 181 minecraft:bone_block
setblock 353 7 223 minecraft:bone_block
setblock 354 7 181 minecraft:bone_block
fill 354 7 223 354 10 223 minecraft:smooth_basalt
setblock 361 7 223 minecraft:bone_block
fill 365 7 223 365 10 223 minecraft:smooth_basalt
fill 370 7 181 371 10 181 minecraft:smooth_basalt
setblock 371 7 185 minecraft:bone_block
setblock 371 7 196 minecraft:bone_block
fill 371 7 201 371 10 201 minecraft:smooth_basalt
fill 371 7 212 371 10 212 minecraft:smooth_basalt
setblock 371 7 213 minecraft:bone_block
fill 371 7 216 371 7 217 minecraft:bone_block
fill 329 8 181 329 9 182 minecraft:bone_block
fill 329 8 183 329 13 184 minecraft:smooth_basalt
fill 329 8 190 329 9 190 minecraft:bone_block
fill 329 8 192 329 13 192 minecraft:smooth_basalt
fill 329 8 193 329 8 194 minecraft:bone_block
fill 329 8 195 329 13 195 minecraft:smooth_basalt
fill 329 8 201 329 9 202 minecraft:bone_block
fill 329 8 203 329 13 204 minecraft:smooth_basalt
fill 329 8 212 329 9 212 minecraft:smooth_basalt
fill 329 8 213 329 8 214 minecraft:bone_block
fill 329 8 215 329 13 216 minecraft:smooth_basalt
fill 329 8 221 329 9 222 minecraft:bone_block
fill 329 8 223 330 13 223 minecraft:smooth_basalt
fill 330 8 181 331 13 181 minecraft:smooth_basalt
setblock 331 8 223 minecraft:bone_block
fill 332 8 181 333 8 181 minecraft:bone_block
fill 333 8 223 333 10 223 minecraft:smooth_basalt
fill 339 8 223 340 9 223 minecraft:bone_block
fill 341 8 223 342 13 223 minecraft:smooth_basalt
fill 342 8 181 343 13 181 minecraft:smooth_basalt
fill 344 8 181 345 9 181 minecraft:bone_block
fill 348 8 223 348 9 223 minecraft:bone_block
fill 350 8 223 350 13 223 minecraft:smooth_basalt
fill 351 8 181 351 13 181 minecraft:smooth_basalt
fill 351 8 223 352 8 223 minecraft:bone_block
fill 352 8 181 353 8 181 minecraft:bone_block
fill 353 8 223 353 13 223 minecraft:smooth_basalt
fill 354 8 181 354 13 181 minecraft:smooth_basalt
fill 356 8 181 356 9 181 minecraft:bone_block
fill 359 8 223 360 9 223 minecraft:bone_block
fill 361 8 223 362 13 223 minecraft:smooth_basalt
fill 362 8 181 363 13 181 minecraft:smooth_basalt
fill 364 8 181 365 9 181 minecraft:bone_block
setblock 371 8 183 minecraft:bone_block
fill 371 8 184 371 13 185 minecraft:smooth_basalt
fill 371 8 186 371 9 187 minecraft:bone_block
fill 371 8 192 371 13 193 minecraft:smooth_basalt
fill 371 8 194 371 8 195 minecraft:bone_block
fill 371 8 196 371 13 196 minecraft:smooth_basalt
fill 371 8 204 371 13 205 minecraft:smooth_basalt
fill 371 8 206 371 9 207 minecraft:bone_block
fill 371 8 213 371 13 213 minecraft:smooth_basalt
setblock 371 8 215 minecraft:bone_block
fill 371 8 216 371 13 217 minecraft:smooth_basalt
fill 371 8 218 371 9 218 minecraft:bone_block
fill 371 8 223 371 9 223 minecraft:bone_block
setblock 329 9 189 minecraft:bone_block
fill 329 9 193 329 12 194 minecraft:smooth_basalt
fill 329 9 209 329 9 210 minecraft:bone_block
setblock 329 9 213 minecraft:bone_block
fill 329 9 214 329 12 214 minecraft:smooth_basalt
fill 331 9 223 331 12 223 minecraft:smooth_basalt
fill 332 9 181 332 12 181 minecraft:smooth_basalt
setblock 332 9 184 minecraft:light[level=12]
setblock 332 9 192 minecraft:light[level=12]
setblock 332 9 200 minecraft:light[level=12]
setblock 332 9 208 minecraft:light[level=12]
setblock 332 9 216 minecraft:light[level=12]
setblock 333 9 181 minecraft:bone_block
fill 335 9 223 335 11 223 minecraft:smooth_basalt
setblock 336 9 181 minecraft:bone_block
setblock 336 9 223 minecraft:bone_block
setblock 340 9 184 minecraft:light[level=12]
setblock 340 9 192 minecraft:light[level=12]
setblock 340 9 200 minecraft:light[level=12]
setblock 340 9 208 minecraft:light[level=12]
setblock 340 9 216 minecraft:light[level=12]
setblock 347 9 223 minecraft:bone_block
setblock 348 9 184 minecraft:light[level=12]
setblock 348 9 192 minecraft:light[level=12]
setblock 348 9 200 minecraft:light[level=12]
setblock 348 9 208 minecraft:light[level=12]
setblock 348 9 216 minecraft:light[level=12]
fill 351 9 223 352 12 223 minecraft:smooth_basalt
fill 352 9 181 353 12 181 minecraft:smooth_basalt
setblock 356 9 184 minecraft:light[level=12]
setblock 356 9 192 minecraft:light[level=12]
setblock 356 9 200 minecraft:light[level=12]
setblock 356 9 208 minecraft:light[level=12]
setblock 356 9 216 minecraft:light[level=12]
setblock 357 9 181 minecraft:bone_block
setblock 364 9 184 minecraft:light[level=12]
setblock 364 9 192 minecraft:light[level=12]
setblock 364 9 200 minecraft:light[level=12]
setblock 364 9 208 minecraft:light[level=12]
setblock 364 9 216 minecraft:light[level=12]
setblock 368 9 181 minecraft:bone_block
setblock 368 9 223 minecraft:bone_block
fill 371 9 183 371 12 183 minecraft:smooth_basalt
fill 371 9 194 371 12 194 minecraft:smooth_basalt
setblock 371 9 195 minecraft:bone_block
fill 371 9 198 371 9 199 minecraft:bone_block
fill 371 9 215 371 12 215 minecraft:smooth_basalt
setblock 371 9 219 minecraft:bone_block
fill 329 10 181 329 15 182 minecraft:smooth_basalt
fill 329 10 187 329 11 188 minecraft:bone_block
fill 329 10 189 329 15 190 minecraft:smooth_basalt
setblock 329 10 191 minecraft:bone_block
fill 329 10 199 329 11 200 minecraft:bone_block
fill 329 10 201 329 15 202 minecraft:smooth_basalt
fill 329 10 208 329 11 208 minecraft:bone_block
fill 329 10 209 329 11 210 minecraft:smooth_basalt
fill 329 10 211 329 10 212 minecraft:bone_block
fill 329 10 213 329 15 213 minecraft:smooth_basalt
fill 329 10 219 329 11 220 minecraft:bone_block
fill 329 10 221 329 15 222 minecraft:smooth_basalt
fill 333 10 181 333 15 181 minecraft:smooth_basalt
fill 334 10 181 335 10 181 minecraft:bone_block
fill 336 10 181 336 15 181 minecraft:smooth_basalt
fill 336 10 223 336 15 223 minecraft:smooth_basalt
fill 337 10 223 338 10 223 minecraft:bone_block
fill 338 10 181 338 11 181 minecraft:bone_block
fill 339 10 223 340 15 223 minecraft:smooth_basalt
fill 344 10 181 345 15 181 minecraft:smooth_basalt
fill 345 10 223 346 11 223 minecraft:bone_block
fill 346 10 181 347 11 181 minecraft:bone_block
fill 347 10 223 348 15 223 minecraft:smooth_basalt
setblock 349 10 223 minecraft:bone_block
setblock 355 10 181 minecraft:bone_block
fill 356 10 181 357 15 181 minecraft:smooth_basalt
fill 357 10 223 358 11 223 minecraft:bone_block
fill 358 10 181 359 11 181 minecraft:bone_block
fill 359 10 223 360 15 223 minecraft:smooth_basalt
fill 364 10 181 365 15 181 minecraft:smooth_basalt
fill 366 10 181 367 10 181 minecraft:bone_block
fill 366 10 223 366 11 223 minecraft:bone_block
fill 368 10 181 368 15 181 minecraft:smooth_basalt
fill 368 10 223 368 15 223 minecraft:smooth_basalt
fill 369 10 223 370 10 223 minecraft:bone_block
fill 371 10 186 371 15 187 minecraft:smooth_basalt
fill 371 10 188 371 11 189 minecraft:bone_block
fill 371 10 195 371 15 195 minecraft:smooth_basalt
setblock 371 10 197 minecraft:bone_block
fill 371 10 198 371 15 199 minecraft:smooth_basalt
fill 371 10 200 371 11 200 minecraft:bone_block
fill 371 10 206 371 15 207 minecraft:smooth_basalt
fill 371 10 208 371 10 209 minecraft:bone_block
fill 371 10 218 371 15 219 minecraft:smooth_basalt
fill 371 10 220 371 11 221 minecraft:bone_block
fill 371 10 223 371 15 223 minecraft:smooth_basalt
fill 329 11 191 329 14 191 minecraft:smooth_basalt
setblock 329 11 196 minecraft:bone_block
setblock 329 11 207 minecraft:bone_block
fill 329 11 211 329 13 212 minecraft:smooth_basalt
fill 333 11 223 334 11 223 minecraft:bone_block
fill 334 11 181 335 14 181 minecraft:smooth_basalt
setblock 337 11 223 minecraft:bone_block
fill 338 11 223 338 14 223 minecraft:smooth_basalt
setblock 339 11 181 minecraft:bone_block
fill 343 11 191 344 12 192 minecraft:bone_block
fill 349 11 223 349 14 223 minecraft:smooth_basalt
setblock 350 11 181 minecraft:bone_block
setblock 354 11 223 minecraft:bone_block
fill 355 11 181 355 14 181 minecraft:smooth_basalt
fill 360 11 217 360 12 218 minecraft:bone_block
setblock 365 11 223 minecraft:bone_block
fill 366 11 181 366 14 181 minecraft:smooth_basalt
setblock 367 11 181 minecraft:bone_block
fill 369 11 223 370 14 223 minecraft:smooth_basalt
fill 370 11 181 371 11 181 minecraft:bone_block
fill 371 11 197 371 14 197 minecraft:smooth_basalt
setblock 371 11 201 minecraft:bone_block
fill 371 11 208 371 14 208 minecraft:smooth_basalt
setblock 371 11 209 minecraft:bone_block
setblock 371 11 212 minecraft:bone_block
fill 329 12 185 329 13 186 minecraft:bone_block
fill 329 12 187 329 17 188 minecraft:smooth_basalt
fill 329 12 196 329 17 196 minecraft:smooth_basalt
fill 329 12 197 329 12 198 minecraft:bone_block
fill 329 12 199 329 14 200 minecraft:smooth_basalt
fill 329 12 205 329 13 206 minecraft:bone_block
fill 329 12 207 329 17 208 minecraft:smooth_basalt
setblock 329 12 209 minecraft:bone_block
fill 329 12 210 329 15 210 minecraft:smooth_basalt
fill 329 12 217 329 13 218 minecraft:bone_block
fill 329 12 219 329 17 220 minecraft:smooth_basalt
fill 330 12 182 332 12 182 minecraft:polished_basalt
fill 330 12 184 330 12 186 minecraft:polished_basalt
fill 330 12 188 330 12 190 minecraft:polished_basalt
fill 330 12 192 330 12 194 minecraft:polished_basalt
fill 330 12 196 330 12 198 minecraft:polished_basalt
fill 330 12 200 330 12 202 minecraft:polished_basalt
fill 330 12 204 330 12 206 minecraft:polished_basalt
fill 330 12 208 330 12 210 minecraft:polished_basalt
fill 330 12 212 330 12 214 minecraft:polished_basalt
fill 330 12 216 330 12 218 minecraft:polished_basalt
fill 330 12 220 330 12 222 minecraft:polished_basalt
fill 332 12 222 334 12 222 minecraft:polished_basalt
fill 332 12 223 332 13 223 minecraft:bone_block
fill 333 12 223 334 17 223 minecraft:smooth_basalt
fill 334 12 182 336 12 182 minecraft:polished_basalt
setblock 335 12 223 minecraft:bone_block
fill 336 12 222 338 12 222 minecraft:polished_basalt
setblock 337 12 181 minecraft:bone_block
fill 337 12 223 337 17 223 minecraft:smooth_basalt
fill 338 12 181 339 17 181 minecraft:smooth_basalt
fill 338 12 182 340 12 182 minecraft:polished_basalt
fill 340 12 181 341 13 181 minecraft:bone_block
fill 340 12 222 342 12 222 minecraft:polished_basalt
fill 342 12 182 344 12 182 minecraft:polished_basalt
fill 343 12 223 344 13 223 minecraft:bone_block
fill 344 12 222 346 12 222 minecraft:polished_basalt
fill 345 12 223 346 17 223 minecraft:smooth_basalt
fill 346 12 181 347 17 181 minecraft:smooth_basalt
fill 346 12 182 348 12 182 minecraft:polished_basalt
fill 348 12 181 349 12 181 minecraft:bone_block
fill 348 12 222 350 12 222 minecraft:polished_basalt
fill 350 12 181 350 17 181 minecraft:smooth_basalt
fill 350 12 182 352 12 182 minecraft:polished_basalt
fill 352 12 222 354 12 222 minecraft:polished_basalt
fill 354 12 182 356 12 182 minecraft:polished_basalt
fill 354 12 223 354 17 223 minecraft:smooth_basalt
fill 355 12 223 356 12 223 minecraft:bone_block
fill 356 12 222 358 12 222 minecraft:polished_basalt
fill 357 12 223 358 17 223 minecraft:smooth_basalt
fill 358 12 181 359 17 181 minecraft:smooth_basalt
fill 358 12 182 360 12 182 minecraft:polished_basalt
fill 360 12 181 361 13 181 minecraft:bone_block
fill 360 12 222 362 12 222 minecraft:polished_basalt
fill 362 12 182 364 12 182 minecraft:polished_basalt
fill 363 12 223 364 13 223 minecraft:bone_block
fill 364 12 222 366 12 222 minecraft:polished_basalt
fill 365 12 223 366 17 223 minecraft:smooth_basalt
fill 366 12 182 368 12 182 minecraft:polished_basalt
fill 367 12 181 367 17 181 minecraft:smooth_basalt
setblock 367 12 223 minecraft:bone_block
fill 368 12 222 370 12 222 minecraft:polished_basalt
setblock 369 12 181 minecraft:bone_block
fill 370 12 181 371 17 181 minecraft:smooth_basalt
fill 370 12 182 370 12 184 minecraft:polished_basalt
fill 370 12 186 370 12 188 minecraft:polished_basalt
fill 370 12 190 370 12 192 minecraft:polished_basalt
fill 370 12 194 370 12 196 minecraft:polished_basalt
fill 370 12 198 370 12 200 minecraft:polished_basalt
fill 370 12 202 370 12 204 minecraft:polished_basalt
fill 370 12 206 370 12 208 minecraft:polished_basalt
fill 370 12 210 370 12 212 minecraft:polished_basalt
fill 370 12 214 370 12 216 minecraft:polished_basalt
fill 370 12 218 370 12 220 minecraft:polished_basalt
fill 371 12 182 371 13 182 minecraft:bone_block
fill 371 12 188 371 17 189 minecraft:smooth_basalt
fill 371 12 190 371 12 191 minecraft:bone_block
fill 371 12 200 371 17 201 minecraft:smooth_basalt
fill 371 12 202 371 13 203 minecraft:bone_block
fill 371 12 209 371 17 209 minecraft:smooth_basalt
fill 371 12 210 371 12 211 minecraft:bone_block
fill 371 12 212 371 17 212 minecraft:smooth_basalt
fill 371 12 214 371 13 214 minecraft:bone_block
fill 371 12 220 371 17 221 minecraft:smooth_basalt
fill 371 12 222 371 13 222 minecraft:bone_block
fill 329 13 193 329 13 194 minecraft:bone_block
setblock 329 13 197 minecraft:bone_block
fill 329 13 198 329 16 198 minecraft:smooth_basalt
fill 329 13 209 329 15 209 minecraft:smooth_basalt
setblock 329 13 214 minecraft:bone_block
setblock 331 13 223 minecraft:bone_block
setblock 332 13 181 minecraft:bone_block
fill 335 13 223 335 16 223 minecraft:smooth_basalt
fill 337 13 181 337 16 181 minecraft:smooth_basalt
fill 348 13 181 348 16 181 minecraft:smooth_basalt
setblock 349 13 181 minecraft:bone_block
fill 351 13 223 352 13 223 minecraft:bone_block
fill 352 13 181 353 13 181 minecraft:bone_block
setblock 355 13 223 minecraft:bone_block
fill 356 13 223 356 16 223 minecraft:smooth_basalt
fill 367 13 223 367 16 223 minecraft:smooth_basalt
fill 369 13 181 369 16 181 minecraft:smooth_basalt
setblock 371 13 183 minecraft:bone_block
fill 371 13 190 371 16 190 minecraft:smooth_basalt
setblock 371 13 191 minecraft:bone_block
setblock 371 13 194 minecraft:bone_block
fill 371 13 210 371 16 211 minecraft:smooth_basalt
setblock 371 13 215 minecraft:bone_block
fill 329 14 183 329 14 184 minecraft:bone_block
fill 329 14 185 329 19 186 minecraft:smooth_basalt
fill 329 14 192 329 15 192 minecraft:bone_block
fill 329 14 193 329 19 194 minecraft:smooth_basalt
setblock 329 14 195 minecraft:bone_block
fill 329 14 197 329 16 197 minecraft:smooth_basalt
fill 329 14 203 329 15 204 minecraft:bone_block
fill 329 14 205 329 19 206 minecraft:smooth_basalt
setblock 329 14 211 minecraft:smooth_basalt
fill 329 14 212 329 15 212 minecraft:bone_block
fill 329 14 214 329 19 214 minecraft:smooth_basalt
fill 329 14 215 329 14 216 minecraft:bone_block
fill 329 14 217 329 16 218 minecraft:smooth_basalt
fill 329 14 223 330 15 223 minecraft:bone_block
fill 330 14 181 331 14 181 minecraft:bone_block
fill 331 14 223 332 19 223 minecraft:smooth_basalt
fill 332 14 181 332 19 181 minecraft:smooth_basalt
fill 340 14 181 341 19 181 minecraft:smooth_basalt
fill 341 14 223 342 14 223 minecraft:bone_block
fill 342 14 181 343 15 181 minecraft:bone_block
fill 343 14 223 344 19 223 minecraft:smooth_basalt
fill 349 14 181 349 19 181 minecraft:smooth_basalt
fill 350 14 223 350 15 223 minecraft:bone_block
setblock 351 14 181 minecraft:bone_block
fill 351 14 223 352 19 223 minecraft:smooth_basalt
fill 352 14 181 353 19 181 minecraft:smooth_basalt
setblock 353 14 223 minecraft:bone_block
fill 354 14 181 354 15 181 minecraft:bone_block
fill 355 14 223 355 19 223 minecraft:smooth_basalt
fill 360 14 181 361 19 181 minecraft:smooth_basalt
fill 361 14 223 362 15 223 minecraft:bone_block
fill 362 14 181 363 14 181 minecraft:bone_block
fill 363 14 223 364 19 223 minecraft:smooth_basalt
fill 371 14 182 371 19 183 minecraft:smooth_basalt
fill 371 14 184 371 15 185 minecraft:bone_block
fill 371 14 191 371 19 191 minecraft:smooth_basalt
fill 371 14 192 371 14 193 minecraft:bone_block
fill 371 14 194 371 19 194 minecraft:smooth_basalt
fill 371 14 196 371 15 196 minecraft:bone_block
fill 371 14 202 371 19 203 minecraft:smooth_basalt
fill 371 14 204 371 15 205 minecraft:bone_block
setblock 371 14 213 minecraft:bone_block
fill 371 14 214 371 19 215 minecraft:smooth_basalt
fill 371 14 216 371 15 217 minecraft:bone_block
fill 371 14 222 371 19 222 minecraft:smooth_basalt
setblock 329 15 183 minecraft:bone_block
fill 329 15 184 329 18 184 minecraft:smooth_basalt
setblock 329 15 191 minecraft:bone_block
fill 329 15 195 329 18 195 minecraft:smooth_basalt
fill 329 15 199 329 17 199 minecraft:smooth_basalt
setblock 329 15 200 minecraft:bone_block
setblock 329 15 211 minecraft:bone_block
setblock 329 15 215 minecraft:bone_block
fill 329 15 216 329 18 216 minecraft:smooth_basalt
fill 330 15 181 330 18 181 minecraft:smooth_basalt
setblock 331 15 181 minecraft:bone_block
fill 334 15 181 335 15 181 minecraft:bone_block
setblock 338 15 223 minecraft:bone_block
setblock 341 15 223 minecraft:bone_block
fill 342 15 223 342 18 223 minecraft:smooth_basalt
setblock 349 15 223 minecraft:bone_block
fill 351 15 181 351 18 181 minecraft:smooth_basalt
fill 353 15 223 353 18 223 minecraft:smooth_basalt
setblock 355 15 181 minecraft:bone_block
fill 362 15 181 362 18 181 minecraft:smooth_basalt
setblock 363 15 181 minecraft:bone_block
setblock 366 15 181 minecraft:bone_block
fill 369 15 223 370 15 223 minecraft:bone_block
fill 371 15 192 371 18 193 minecraft:smooth_basalt
setblock 371 15 197 minecraft:bone_block
setblock 371 15 208 minecraft:bone_block
fill 371 15 213 371 18 213 minecraft:smooth_basalt
fill 329 16 181 329 16 182 minecraft:bone_block
fill 329 16 183 329 21 183 minecraft:smooth_basalt
fill 329 16 189 329 17 190 minecraft:bone_block
fill 329 16 191 329 21 192 minecraft:smooth_basalt
fill 329 16 200 329 17 200 minecraft:smooth_basalt
fill 329 16 201 329 16 202 minecraft:bone_block
fill 329 16 203 329 21 204 minecraft:smooth_basalt
fill 329 16 209 329 17 210 minecraft:bone_block
fill 329 16 211 329 21 212 minecraft:smooth_basalt
setblock 329 16 213 minecraft:bone_block
fill 329 16 215 329 18 215 minecraft:smooth_basalt
fill 329 16 221 329 17 222 minecraft:bone_block
fill 329 16 223 330 21 223 minecraft:smooth_basalt
fill 331 16 181 331 21 181 minecraft:smooth_basalt
setblock 333 16 181 minecraft:bone_block
fill 334 16 181 335 21 181 minecraft:smooth_basalt
fill 336 16 181 336 17 181 minecraft:bone_block
fill 336 16 223 336 17 223 minecraft:bone_block
fill 338 16 223 338 21 223 minecraft:smooth_basalt
fill 339 16 223 340 16 223 minecraft:bone_block
fill 341 16 223 341 21 223 minecraft:smooth_basalt
fill 342 16 181 343 21 181 minecraft:smooth_basalt
fill 344 16 181 345 16 181 minecraft:bone_block
fill 347 16 223 348 17 223 minecraft:bone_block
fill 349 16 223 350 21 223 minecraft:smooth_basalt
fill 354 16 181 355 21 181 minecraft:smooth_basalt
fill 356 16 181 357 17 181 minecraft:bone_block
fill 359 16 223 360 16 223 minecraft:bone_block
fill 361 16 223 362 21 223 minecraft:smooth_basalt
fill 363 16 181 363 21 181 minecraft:smooth_basalt
fill 364 16 181 365 16 181 minecraft:bone_block
fill 366 16 181 366 21 181 minecraft:smooth_basalt
fill 368 16 181 368 17 181 minecraft:bone_block
fill 368 16 223 368 17 223 minecraft:bone_block
fill 369 16 223 370 21 223 minecraft:smooth_basalt
fill 371 16 184 371 21 185 minecraft:smooth_basalt
fill 371 16 186 371 17 187 minecraft:bone_block
setblock 371 16 195 minecraft:bone_block
fill 371 16 196 371 21 197 minecraft:smooth_basalt
fill 371 16 198 371 17 199 minecraft:bone_block
fill 371 16 204 371 21 205 minecraft:smooth_basalt
fill 371 16 206 371 16 207 minecraft:bone_block
fill 371 16 208 371 21 208 minecraft:smooth_basalt
fill 371 16 216 371 21 217 minecraft:smooth_basalt
fill 371 16 218 371 17 219 minecraft:bone_block
setblock 371 16 223 minecraft:bone_block
fill 329 17 181 329 20 182 minecraft:smooth_basalt
fill 329 17 197 329 17 198 minecraft:bone_block
setblock 329 17 201 minecraft:bone_block
fill 329 17 202 329 20 202 minecraft:smooth_basalt
fill 329 17 213 329 20 213 minecraft:smooth_basalt
fill 329 17 217 329 19 217 minecraft:smooth_basalt
setblock 329 17 218 minecraft:bone_block
setblock 332 17 184 minecraft:light[level=12]
setblock 332 17 192 minecraft:light[level=12]
setblock 332 17 200 minecraft:light[level=12]
setblock 332 17 208 minecraft:light[level=12]
setblock 332 17 216 minecraft:light[level=12]
fill 333 17 181 333 20 181 minecraft:smooth_basalt
setblock 335 17 223 minecraft:bone_block
setblock 337 17 181 minecraft:bone_block
fill 339 17 223 340 20 223 minecraft:smooth_basalt
setblock 340 17 184 minecraft:light[level=12]
setblock 340 17 192 minecraft:light[level=12]
setblock 340 17 200 minecraft:light[level=12]
setblock 340 17 208 minecraft:light[level=12]
setblock 340 17 216 minecraft:light[level=12]
fill 344 17 181 344 20 181 minecraft:smooth_basalt
setblock 345 17 181 minecraft:bone_block
setblock 348 17 181 minecraft:bone_block
setblock 348 17 184 minecraft:light[level=12]
setblock 348 17 192 minecraft:light[level=12]
setblock 348 17 200 minecraft:light[level=12]
setblock 348 17 208 minecraft:light[level=12]
setblock 348 17 216 minecraft:light[level=12]
setblock 356 17 184 minecraft:light[level=12]
setblock 356 17 192 minecraft:light[level=12]
setblock 356 17 200 minecraft:light[level=12]
setblock 356 17 208 minecraft:light[level=12]
setblock 356 17 216 minecraft:light[level=12]
setblock 356 17 223 minecraft:bone_block
setblock 359 17 223 minecraft:bone_block
fill 360 17 223 360 20 223 minecraft:smooth_basalt
fill 364 17 181 365 20 181 minecraft:smooth_basalt
setblock 364 17 184 minecraft:light[level=12]
setblock 364 17 192 minecraft:light[level=12]
setblock 364 17 200 minecraft:light[level=12]
setblock 364 17 208 minecraft:light[level=12]
setblock 364 17 216 minecraft:light[level=12]
setblock 367 17 223 minecraft:bone_block
setblock 369 17 181 minecraft:bone_block
setblock 371 17 190 minecraft:bone_block
fill 371 17 195 371 20 195 minecraft:smooth_basalt
fill 371 17 206 371 20 206 minecraft:smooth_basalt
setblock 371 17 207 minecraft:bone_block
fill 371 17 210 371 17 211 minecraft:bone_block
fill 371 17 223 371 20 223 minecraft:smooth_basalt
fill 329 18 187 329 19 188 minecraft:bone_block
fill 329 18 189 329 35 190 minecraft:smooth_basalt
fill 329 18 196 329 19 196 minecraft:bone_block
fill 329 18 197 329 19 198 minecraft:smooth_basalt
fill 329 18 199 329 18 200 minecraft:bone_block
fill 329 18 201 329 35 201 minecraft:smooth_basalt
fill 329 18 207 329 19 208 minecraft:bone_block
fill 329 18 209 329 36 210 minecraft:smooth_basalt
fill 329 18 218 329 39 218 minecraft:smooth_basalt
fill 329 18 219 329 18 220 minecraft:bone_block
fill 329 18 221 329 35 222 minecraft:smooth_basalt
fill 330 18 182 332 18 182 minecraft:polished_basalt
fill 330 18 184 330 18 186 minecraft:polished_basalt
fill 330 18 188 330 18 190 minecraft:polished_basalt
fill 330 18 192 330 18 194 minecraft:polished_basalt
fill 330 18 196 330 18 198 minecraft:polished_basalt
fill 330 18 200 330 18 202 minecraft:polished_basalt
fill 330 18 204 330 18 206 minecraft:polished_basalt
fill 330 18 208 330 18 210 minecraft:polished_basalt
fill 330 18 212 330 18 214 minecraft:polished_basalt
fill 330 18 216 330 18 218 minecraft:polished_basalt
fill 330 18 220 330 18 222 minecraft:polished_basalt
fill 332 18 222 334 18 222 minecraft:polished_basalt
fill 333 18 223 334 19 223 minecraft:bone_block
fill 334 18 182 336 18 182 minecraft:polished_basalt
fill 335 18 223 336 36 223 minecraft:smooth_basalt
fill 336 18 181 337 36 181 minecraft:smooth_basalt
fill 336 18 222 338 18 222 minecraft:polished_basalt
setblock 337 18 223 minecraft:bone_block
fill 338 18 181 339 19 181 minecraft:bone_block
fill 338 18 182 340 18 182 minecraft:polished_basalt
fill 338 18 195 339 19 196 minecraft:bone_block
fill 340 18 196 340 19 196 minecraft:bone_block
fill 340 18 222 342 18 222 minecraft:polished_basalt
fill 342 18 182 344 18 182 minecraft:polished_basalt
fill 344 18 222 346 18 222 minecraft:polished_basalt
fill 345 18 181 345 35 181 minecraft:smooth_basalt
fill 345 18 223 346 19 223 minecraft:bone_block
fill 346 18 181 347 18 181 minecraft:bone_block
fill 346 18 182 348 18 182 minecraft:polished_basalt
fill 347 18 223 348 35 223 minecraft:smooth_basalt
fill 348 18 181 348 39 181 minecraft:smooth_basalt
fill 348 18 222 350 18 222 minecraft:polished_basalt
fill 350 18 181 350 19 181 minecraft:bone_block
fill 350 18 182 352 18 182 minecraft:polished_basalt
fill 352 18 222 354 18 222 minecraft:polished_basalt
fill 354 18 182 356 18 182 minecraft:polished_basalt
fill 354 18 223 354 19 223 minecraft:bone_block
fill 356 18 181 357 35 181 minecraft:smooth_basalt
fill 356 18 222 358 18 222 minecraft:polished_basalt
fill 356 18 223 356 39 223 minecraft:smooth_basalt
fill 357 18 223 358 18 223 minecraft:bone_block
fill 358 18 181 359 19 181 minecraft:bone_block
fill 358 18 182 360 18 182 minecraft:polished_basalt
fill 359 18 223 359 35 223 minecraft:smooth_basalt
fill 360 18 222 362 18 222 minecraft:polished_basalt
fill 362 18 182 364 18 182 minecraft:polished_basalt
fill 364 18 222 366 18 222 minecraft:polished_basalt
fill 365 18 223 366 19 223 minecraft:bone_block
fill 366 18 182 368 18 182 minecraft:polished_basalt
setblock 367 18 181 minecraft:bone_block
fill 367 18 223 368 36 223 minecraft:smooth_basalt
fill 368 18 181 369 36 181 minecraft:smooth_basalt
fill 368 18 222 370 18 222 minecraft:polished_basalt
fill 370 18 181 371 19 181 minecraft:bone_block
fill 370 18 182 370 18 184 minecraft:polished_basalt
fill 370 18 186 370 18 188 minecraft:polished_basalt
fill 370 18 190 370 18 192 minecraft:polished_basalt
fill 370 18 194 370 18 196 minecraft:polished_basalt
fill 370 18 198 370 18 200 minecraft:polished_basalt
fill 370 18 202 370 18 204 minecraft:polished_basalt
fill 370 18 206 370 18 208 minecraft:polished_basalt
fill 370 18 210 370 18 212 minecraft:polished_basalt
fill 370 18 214 370 18 216 minecraft:polished_basalt
fill 370 18 218 370 18 220 minecraft:polished_basalt
fill 371 18 186 371 35 187 minecraft:smooth_basalt
fill 371 18 188 371 18 189 minecraft:bone_block
fill 371 18 190 371 39 190 minecraft:smooth_basalt
fill 371 18 198 371 36 199 minecraft:smooth_basalt
fill 371 18 200 371 19 201 minecraft:bone_block
fill 371 18 207 371 35 207 minecraft:smooth_basalt
setblock 371 18 209 minecraft:bone_block
fill 371 18 210 371 39 211 minecraft:smooth_basalt
fill 371 18 212 371 19 212 minecraft:bone_block
fill 371 18 218 371 35 219 minecraft:smooth_basalt
fill 371 18 220 371 18 221 minecraft:bone_block
setblock 329 19 184 minecraft:bone_block
setblock 329 19 195 minecraft:bone_block
fill 329 19 199 329 21 200 minecraft:smooth_basalt
fill 329 19 215 329 19 216 minecraft:bone_block
setblock 329 19 219 minecraft:bone_block
fill 329 19 220 329 22 220 minecraft:smooth_basalt
setblock 330 19 181 minecraft:bone_block
fill 337 19 223 337 22 223 minecraft:smooth_basalt
setblock 342 19 223 minecraft:bone_block
fill 346 19 181 347 22 181 minecraft:smooth_basalt
setblock 351 19 181 minecraft:bone_block
setblock 353 19 223 minecraft:bone_block
fill 357 19 223 358 22 223 minecraft:smooth_basalt
setblock 362 19 181 minecraft:bone_block
fill 367 19 181 367 22 181 minecraft:smooth_basalt
fill 371 19 188 371 22 188 minecraft:smooth_basalt
setblock 371 19 189 minecraft:bone_block
fill 371 19 192 371 19 193 minecraft:bone_block
fill 371 19 209 371 22 209 minecraft:smooth_basalt
setblock 371 19 213 minecraft:bone_block
fill 371 19 220 371 22 220 minecraft:smooth_basalt
setblock 371 19 221 minecraft:bone_block
fill 329 20 184 329 33 184 minecraft:smooth_basalt
fill 329 20 185 329 20 186 minecraft:bone_block
fill 329 20 187 329 22 188 minecraft:smooth_basalt
fill 329 20 193 329 21 194 minecraft:bone_block
fill 329 20 195 329 33 196 minecraft:smooth_basalt
setblock 329 20 197 minecraft:bone_block
fill 329 20 198 329 39 198 minecraft:smooth_basalt
fill 329 20 205 329 21 206 minecraft:bone_block
fill 329 20 207 329 33 208 minecraft:smooth_basalt
fill 329 20 214 329 21 214 minecraft:bone_block
fill 329 20 215 329 33 216 minecraft:smooth_basalt
setblock 329 20 217 minecraft:bone_block
fill 329 20 219 329 37 219 minecraft:smooth_basalt
fill 330 20 181 330 33 181 minecraft:smooth_basalt
fill 331 20 223 332 21 223 minecraft:bone_block
fill 332 20 181 332 21 181 minecraft:bone_block
fill 333 20 223 334 33 223 minecraft:smooth_basalt
fill 338 20 181 339 33 181 minecraft:smooth_basalt
fill 340 20 181 341 21 181 minecraft:bone_block
fill 342 20 223 342 33 223 minecraft:smooth_basalt
fill 343 20 223 344 20 223 minecraft:bone_block
fill 345 20 223 346 37 223 minecraft:smooth_basalt
setblock 349 20 181 minecraft:bone_block
fill 350 20 181 351 33 181 minecraft:smooth_basalt
fill 351 20 223 352 21 223 minecraft:bone_block
fill 352 20 181 353 21 181 minecraft:bone_block
fill 353 20 223 354 33 223 minecraft:smooth_basalt
setblock 355 20 223 minecraft:bone_block
fill 358 20 181 359 37 181 minecraft:smooth_basalt
fill 360 20 181 361 20 181 minecraft:bone_block
fill 362 20 181 362 33 181 minecraft:smooth_basalt
fill 363 20 223 364 21 223 minecraft:bone_block
fill 365 20 223 366 33 223 minecraft:smooth_basalt
fill 370 20 181 371 33 181 minecraft:smooth_basalt
fill 371 20 182 371 21 183 minecraft:bone_block
fill 371 20 189 371 37 189 minecraft:smooth_basalt
setblock 371 20 191 minecraft:bone_block
fill 371 20 192 371 33 193 minecraft:smooth_basalt
fill 371 20 194 371 21 194 minecraft:bone_block
fill 371 20 200 371 33 201 minecraft:smooth_basalt
fill 371 20 202 371 20 203 minecraft:bone_block
fill 371 20 212 371 33 213 minecraft:smooth_basalt
fill 371 20 214 371 21 215 minecraft:bone_block
fill 371 20 221 371 37 221 minecraft:smooth_basalt
setblock 371 20 222 minecraft:bone_block
fill 329 21 181 329 21 182 minecraft:bone_block
setblock 329 21 185 minecraft:bone_block
fill 329 21 186 329 39 186 minecraft:smooth_basalt
fill 329 21 197 329 39 197 minecraft:smooth_basalt
setblock 329 21 202 minecraft:bone_block
setblock 329 21 213 minecraft:bone_block
fill 329 21 217 329 39 217 minecraft:smooth_basalt
setblock 333 21 181 minecraft:bone_block
fill 339 21 223 340 21 223 minecraft:bone_block
setblock 343 21 223 minecraft:bone_block
setblock 344 21 181 minecraft:bone_block
fill 344 21 223 344 39 223 minecraft:smooth_basalt
fill 349 21 181 349 39 181 minecraft:smooth_basalt
fill 355 21 223 355 39 223 minecraft:smooth_basalt
fill 360 21 181 360 39 181 minecraft:smooth_basalt
setblock 360 21 223 minecraft:bone_block
setblock 361 21 181 minecraft:bone_block
fill 364 21 181 365 21 181 minecraft:bone_block
fill 371 21 191 371 39 191 minecraft:smooth_basalt
setblock 371 21 195 minecraft:bone_block
fill 371 21 202 371 39 202 minecraft:smooth_basalt
setblock 371 21 203 minecraft:bone_block
setblock 371 21 206 minecraft:bone_block
fill 371 21 222 371 39 222 minecraft:smooth_basalt
setblock 371 21 223 minecraft:bone_block
fill 329 22 181 329 35 182 minecraft:smooth_basalt
setblock 329 22 183 minecraft:bone_block
fill 329 22 185 329 39 185 minecraft:smooth_basalt
fill 329 22 191 329 23 192 minecraft:bone_block
fill 329 22 193 329 35 194 minecraft:smooth_basalt
setblock 329 22 199 minecraft:smooth_basalt
fill 329 22 200 329 23 200 minecraft:bone_block
fill 329 22 202 329 35 202 minecraft:smooth_basalt
fill 329 22 203 329 22 204 minecraft:bone_block
fill 329 22 205 329 39 206 minecraft:smooth_basalt
fill 329 22 211 329 23 212 minecraft:bone_block
fill 329 22 213 329 35 214 minecraft:smooth_basalt
fill 329 22 223 330 22 223 minecraft:bone_block
setblock 331 22 181 minecraft:bone_block
fill 331 22 223 332 35 223 minecraft:smooth_basalt
fill 332 22 181 333 35 181 minecraft:smooth_basalt
fill 334 22 181 335 23 181 minecraft:bone_block
fill 338 22 223 338 23 223 minecraft:bone_block
fill 339 22 223 340 35 223 minecraft:smooth_basalt
fill 340 22 181 341 39 181 minecraft:smooth_basalt
setblock 341 22 223 minecraft:bone_block
fill 342 22 181 343 22 181 minecraft:bone_block
fill 343 22 223 343 39 223 minecraft:smooth_basalt
fill 344 22 181 344 35 181 minecraft:smooth_basalt
fill 349 22 223 350 23 223 minecraft:bone_block
fill 351 22 223 352 35 223 minecraft:smooth_basalt
fill 352 22 181 353 35 181 minecraft:smooth_basalt
fill 354 22 181 355 23 181 minecraft:bone_block
fill 360 22 223 360 35 223 minecraft:smooth_basalt
fill 361 22 181 361 39 181 minecraft:smooth_basalt
fill 361 22 223 362 22 223 minecraft:bone_block
setblock 363 22 181 minecraft:bone_block
fill 363 22 223 364 39 223 minecraft:smooth_basalt
fill 364 22 181 365 35 181 minecraft:smooth_basalt
fill 366 22 181 366 23 181 minecraft:bone_block
fill 369 22 223 370 23 223 minecraft:bone_block
fill 371 22 182 371 35 183 minecraft:smooth_basalt
fill 371 22 184 371 22 185 minecraft:bone_block
fill 371 22 194 371 35 195 minecraft:smooth_basalt
fill 371 22 196 371 23 197 minecraft:bone_block
fill 371 22 203 371 39 203 minecraft:smooth_basalt
fill 371 22 204 371 22 205 minecraft:bone_block
fill 371 22 206 371 35 206 minecraft:smooth_basalt
fill 371 22 208 371 23 208 minecraft:bone_block
fill 371 22 214 371 35 215 minecraft:smooth_basalt
fill 371 22 216 371 23 217 minecraft:bone_block
fill 371 22 223 371 35 223 minecraft:smooth_basalt
fill 329 23 183 329 33 183 minecraft:smooth_basalt
fill 329 23 187 329 37 187 minecraft:smooth_basalt
setblock 329 23 188 minecraft:bone_block
setblock 329 23 199 minecraft:bone_block
setblock 329 23 203 minecraft:bone_block
fill 329 23 204 329 33 204 minecraft:smooth_basalt
setblock 329 23 220 minecraft:bone_block
setblock 329 23 223 minecraft:bone_block
fill 330 23 223 330 33 223 minecraft:smooth_basalt
fill 331 23 181 331 33 181 minecraft:smooth_basalt
setblock 337 23 223 minecraft:bone_block
fill 341 23 223 341 33 223 minecraft:smooth_basalt
fill 342 23 181 342 33 181 minecraft:smooth_basalt
setblock 343 23 181 minecraft:bone_block
fill 346 23 181 347 23 181 minecraft:bone_block
fill 357 23 223 358 23 223 minecraft:bone_block
setblock 361 23 223 minecraft:bone_block
fill 362 23 223 362 33 223 minecraft:smooth_basalt
fill 363 23 181 363 33 181 minecraft:smooth_basalt
setblock 367 23 181 minecraft:bone_block
fill 371 23 184 371 33 184 minecraft:smooth_basalt
setblock 371 23 185 minecraft:bone_block
setblock 371 23 188 minecraft:bone_block
fill 371 23 204 371 33 205 minecraft:smooth_basalt
setblock 371 23 209 minecraft:bone_block
setblock 371 23 220 minecraft:bone_block
fill 329 24 188 329 37 188 minecraft:smooth_basalt
fill 329 24 191 329 34 192 minecraft:smooth_basalt
fill 329 24 199 329 37 200 minecraft:smooth_basalt
fill 329 24 203 329 33 203 minecraft:smooth_basalt
fill 329 24 211 329 34 212 minecraft:smooth_basalt
fill 329 24 220 329 37 220 minecraft:smooth_basalt
fill 329 24 223 329 34 223 minecraft:smooth_basalt
fill 334 24 181 335 34 181 minecraft:smooth_basalt
fill 337 24 223 338 37 223 minecraft:smooth_basalt
fill 343 24 181 343 34 181 minecraft:smooth_basalt
fill 346 24 181 347 37 181 minecraft:smooth_basalt
fill 349 24 223 350 34 223 minecraft:smooth_basalt
fill 354 24 181 355 34 181 minecraft:smooth_basalt
fill 357 24 223 358 37 223 minecraft:smooth_basalt
fill 361 24 223 361 34 223 minecraft:smooth_basalt
fill 366 24 181 367 37 181 minecraft:smooth_basalt
fill 369 24 223 370 37 223 minecraft:smooth_basalt
fill 371 24 185 371 34 185 minecraft:smooth_basalt
fill 371 24 188 371 37 188 minecraft:smooth_basalt
fill 371 24 196 371 34 197 minecraft:smooth_basalt
fill 371 24 208 371 37 209 minecraft:smooth_basalt
fill 371 24 216 371 34 217 minecraft:smooth_basalt
fill 371 24 220 371 37 220 minecraft:smooth_basalt
setblock 332 25 184 minecraft:light[level=12]
setblock 332 25 192 minecraft:light[level=12]
setblock 332 25 200 minecraft:light[level=12]
setblock 332 25 208 minecraft:light[level=12]
setblock 332 25 216 minecraft:light[level=12]
setblock 340 25 184 minecraft:light[level=12]
setblock 340 25 192 minecraft:light[level=12]
setblock 340 25 200 minecraft:light[level=12]
setblock 340 25 208 minecraft:light[level=12]
setblock 340 25 216 minecraft:light[level=12]
setblock 348 25 184 minecraft:light[level=12]
setblock 348 25 192 minecraft:light[level=12]
setblock 348 25 200 minecraft:light[level=12]
setblock 348 25 208 minecraft:light[level=12]
setblock 348 25 216 minecraft:light[level=12]
setblock 356 25 184 minecraft:light[level=12]
setblock 356 25 192 minecraft:light[level=12]
setblock 356 25 200 minecraft:light[level=12]
setblock 356 25 208 minecraft:light[level=12]
setblock 356 25 216 minecraft:light[level=12]
setblock 364 25 184 minecraft:light[level=12]
setblock 364 25 192 minecraft:light[level=12]
setblock 364 25 200 minecraft:light[level=12]
setblock 364 25 208 minecraft:light[level=12]
setblock 364 25 216 minecraft:light[level=12]
fill 340 29 201 346 29 209 minecraft:calcite
fill 341 29 199 349 29 200 minecraft:calcite
fill 341 29 210 359 30 210 minecraft:calcite
fill 342 29 198 358 30 198 minecraft:calcite
fill 342 29 211 358 30 211 minecraft:calcite
fill 343 29 197 357 30 197 minecraft:calcite
fill 343 29 212 357 30 212 minecraft:calcite
fill 344 29 191 356 29 196 minecraft:calcite
fill 344 29 213 356 30 213 minecraft:calcite
fill 346 29 214 354 30 214 minecraft:calcite
fill 347 29 201 347 29 202 minecraft:calcite
fill 347 29 204 347 29 209 minecraft:calcite
fill 348 29 206 349 29 209 minecraft:calcite
fill 349 29 215 351 30 215 minecraft:calcite
fill 350 29 199 359 29 199 minecraft:calcite
fill 350 29 207 360 29 209 minecraft:calcite
fill 351 29 200 359 29 200 minecraft:calcite
fill 351 29 206 360 29 206 minecraft:calcite
fill 353 29 201 360 29 202 minecraft:calcite
fill 353 29 204 360 29 205 minecraft:calcite
fill 354 29 203 360 29 203 minecraft:calcite
fill 330 30 182 339 30 222 minecraft:smooth_basalt
fill 340 30 182 340 30 200 minecraft:smooth_basalt
fill 340 30 201 343 30 209 minecraft:calcite
fill 340 30 210 340 30 222 minecraft:smooth_basalt
fill 341 30 182 341 30 198 minecraft:smooth_basalt
fill 341 30 199 346 30 200 minecraft:calcite
fill 341 30 211 341 30 222 minecraft:smooth_basalt
fill 342 30 182 342 30 197 minecraft:smooth_basalt
fill 342 30 212 342 30 222 minecraft:smooth_basalt
fill 343 30 182 343 30 196 minecraft:smooth_basalt
fill 343 30 213 343 30 222 minecraft:smooth_basalt
fill 344 30 182 370 30 190 minecraft:smooth_basalt
fill 344 30 191 344 30 196 minecraft:calcite
fill 344 30 201 344 30 203 minecraft:calcite
fill 344 30 204 347 30 207 minecraft:ochre_froglight
fill 344 30 208 360 30 209 minecraft:calcite
fill 344 30 214 345 30 222 minecraft:smooth_basalt
fill 345 30 191 356 30 194 minecraft:calcite
fill 345 30 195 345 30 196 minecraft:smooth_basalt
fill 345 30 201 345 30 202 minecraft:calcite
fill 345 30 203 346 30 203 minecraft:ochre_froglight
fill 346 30 195 346 30 196 minecraft:calcite
setblock 346 30 201 minecraft:calcite
fill 346 30 202 347 30 202 minecraft:ochre_froglight
fill 346 30 215 348 30 222 minecraft:smooth_basalt
fill 347 30 195 347 30 196 minecraft:smooth_basalt
fill 347 30 199 348 30 199 minecraft:calcite
fill 347 30 200 347 30 201 minecraft:ochre_froglight
fill 348 30 195 348 30 196 minecraft:calcite
fill 348 30 200 349 30 200 minecraft:ochre_froglight
fill 348 30 206 349 30 206 minecraft:ochre_froglight
setblock 348 30 207 minecraft:calcite
fill 349 30 195 349 30 196 minecraft:smooth_basalt
fill 349 30 199 351 30 199 minecraft:ochre_froglight
fill 349 30 207 351 30 207 minecraft:ochre_froglight
fill 349 30 216 370 30 222 minecraft:smooth_basalt
fill 350 30 195 350 30 196 minecraft:calcite
fill 351 30 195 351 30 196 minecraft:smooth_basalt
fill 351 30 200 353 30 200 minecraft:ochre_froglight
fill 351 30 206 356 30 206 minecraft:ochre_froglight
fill 352 30 195 352 30 196 minecraft:calcite
fill 352 30 199 359 30 199 minecraft:calcite
setblock 352 30 207 minecraft:calcite
fill 352 30 215 370 30 215 minecraft:smooth_basalt
fill 353 30 195 353 30 196 minecraft:smooth_basalt
fill 353 30 201 353 30 202 minecraft:ochre_froglight
fill 353 30 204 356 30 205 minecraft:ochre_froglight
fill 353 30 207 356 30 207 minecraft:ochre_froglight
fill 354 30 195 354 30 196 minecraft:calcite
fill 354 30 200 359 30 201 minecraft:calcite
fill 354 30 202 354 30 203 minecraft:ochre_froglight
fill 355 30 195 355 30 196 minecraft:smooth_basalt
fill 355 30 202 360 30 202 minecraft:calcite
setblock 355 30 203 minecraft:ochre_froglight
fill 355 30 214 370 30 214 minecraft:smooth_basalt
fill 356 30 195 356 30 196 minecraft:calcite
fill 356 30 203 360 30 203 minecraft:calcite
fill 357 30 191 370 30 196 minecraft:smooth_basalt
fill 357 30 204 360 30 207 minecraft:calcite
fill 357 30 213 370 30 213 minecraft:smooth_basalt
fill 358 30 197 370 30 197 minecraft:smooth_basalt
fill 358 30 212 370 30 212 minecraft:smooth_basalt
fill 359 30 198 370 30 198 minecraft:smooth_basalt
fill 359 30 211 370 30 211 minecraft:smooth_basalt
fill 360 30 199 370 30 200 minecraft:smooth_basalt
setblock 360 30 201 minecraft:calcite
fill 360 30 210 370 30 210 minecraft:smooth_basalt
fill 361 30 201 370 30 209 minecraft:smooth_basalt
setblock 332 33 184 minecraft:light[level=12]
setblock 332 33 192 minecraft:light[level=12]
setblock 332 33 200 minecraft:light[level=12]
setblock 332 33 208 minecraft:light[level=12]
setblock 332 33 216 minecraft:light[level=12]
setblock 340 33 184 minecraft:light[level=12]
setblock 340 33 192 minecraft:light[level=12]
setblock 340 33 200 minecraft:light[level=12]
setblock 340 33 208 minecraft:light[level=12]
setblock 340 33 216 minecraft:light[level=12]
setblock 348 33 184 minecraft:light[level=12]
setblock 348 33 192 minecraft:light[level=12]
setblock 348 33 200 minecraft:light[level=12]
setblock 348 33 208 minecraft:light[level=12]
setblock 348 33 216 minecraft:light[level=12]
setblock 356 33 184 minecraft:light[level=12]
setblock 356 33 192 minecraft:light[level=12]
setblock 356 33 200 minecraft:light[level=12]
setblock 356 33 208 minecraft:light[level=12]
setblock 356 33 216 minecraft:light[level=12]
setblock 364 33 184 minecraft:light[level=12]
setblock 364 33 192 minecraft:light[level=12]
setblock 364 33 200 minecraft:light[level=12]
setblock 364 33 208 minecraft:light[level=12]
setblock 364 33 216 minecraft:light[level=12]
fill 329 34 183 329 35 184 minecraft:bone_block
fill 329 34 195 329 34 196 minecraft:bone_block
fill 329 34 203 329 35 204 minecraft:bone_block
setblock 329 34 207 minecraft:bone_block
fill 329 34 208 329 37 208 minecraft:smooth_basalt
fill 329 34 215 329 35 216 minecraft:bone_block
fill 330 34 181 331 35 181 minecraft:bone_block
fill 330 34 223 330 35 223 minecraft:bone_block
fill 333 34 223 334 34 223 minecraft:bone_block
fill 338 34 181 338 37 181 minecraft:smooth_basalt
setblock 339 34 181 minecraft:bone_block
fill 341 34 223 342 35 223 minecraft:bone_block
fill 342 34 181 342 35 181 minecraft:bone_block
fill 350 34 181 351 34 181 minecraft:bone_block
fill 353 34 223 354 34 223 minecraft:bone_block
fill 362 34 181 363 35 181 minecraft:bone_block
fill 362 34 223 362 35 223 minecraft:bone_block
setblock 365 34 223 minecraft:bone_block
fill 366 34 223 366 37 223 minecraft:smooth_basalt
fill 370 34 181 371 34 181 minecraft:bone_block
fill 371 34 184 371 35 184 minecraft:bone_block
fill 371 34 192 371 35 193 minecraft:bone_block
fill 371 34 200 371 37 200 minecraft:smooth_basalt
setblock 371 34 201 minecraft:bone_block
fill 371 34 204 371 35 205 minecraft:bone_block
fill 371 34 212 371 34 213 minecraft:bone_block
fill 329 35 191 329 35 192 minecraft:bone_block
setblock 329 35 195 minecraft:bone_block
fill 329 35 196 329 38 196 minecraft:smooth_basalt
fill 329 35 207 329 38 207 minecraft:smooth_basalt
fill 329 35 211 329 37 211 minecraft:smooth_basalt
setblock 329 35 212 minecraft:bone_block
setblock 329 35 223 minecraft:bone_block
fill 333 35 223 334 38 223 minecraft:smooth_basalt
setblock 334 35 181 minecraft:bone_block
fill 335 35 181 335 37 181 minecraft:smooth_basalt
fill 339 35 181 339 38 181 minecraft:smooth_basalt
setblock 343 35 181 minecraft:bone_block
fill 349 35 223 349 37 223 minecraft:smooth_basalt
fill 350 35 181 350 38 181 minecraft:smooth_basalt
setblock 350 35 223 minecraft:bone_block
setblock 351 35 181 minecraft:bone_block
setblock 353 35 223 minecraft:bone_block
setblock 354 35 181 minecraft:bone_block
fill 354 35 223 354 38 223 minecraft:smooth_basalt
fill 355 35 181 355 37 181 minecraft:smooth_basalt
setblock 361 35 223 minecraft:bone_block
fill 365 35 223 365 38 223 minecraft:smooth_basalt
fill 370 35 181 371 38 181 minecraft:smooth_basalt
setblock 371 35 185 minecraft:bone_block
setblock 371 35 196 minecraft:bone_block
fill 371 35 197 371 37 197 minecraft:smooth_basalt
fill 371 35 201 371 38 201 minecraft:smooth_basalt
fill 371 35 212 371 38 212 minecraft:smooth_basalt
setblock 371 35 213 minecraft:bone_block
fill 371 35 216 371 35 217 minecraft:bone_block
fill 329 36 181 329 37 182 minecraft:bone_block
fill 329 36 183 329 41 184 minecraft:smooth_basalt
setblock 329 36 189 minecraft:smooth_basalt
fill 329 36 190 329 37 190 minecraft:bone_block
fill 329 36 191 329 41 192 minecraft:smooth_basalt
setblock 329 36 193 minecraft:bone_block
fill 329 36 194 329 39 195 minecraft:smooth_basalt
fill 329 36 201 329 37 202 minecraft:bone_block
fill 329 36 203 329 41 204 minecraft:smooth_basalt
fill 329 36 212 329 41 212 minecraft:smooth_basalt
fill 329 36 213 329 36 214 minecraft:bone_block
fill 329 36 215 329 41 216 minecraft:smooth_basalt
fill 329 36 221 329 37 222 minecraft:bone_block
fill 329 36 223 330 41 223 minecraft:smooth_basalt
fill 330 36 181 331 41 181 minecraft:smooth_basalt
fill 330 36 182 332 36 182 minecraft:polished_basalt
fill 330 36 184 330 36 186 minecraft:polished_basalt
fill 330 36 188 330 36 190 minecraft:polished_basalt
fill 330 36 192 330 36 194 minecraft:polished_basalt
fill 330 36 196 330 36 198 minecraft:polished_basalt
fill 330 36 200 330 36 202 minecraft:polished_basalt
fill 330 36 204 330 36 206 minecraft:polished_basalt
fill 330 36 208 330 36 210 minecraft:polished_basalt
fill 330 36 212 330 36 214 minecraft:polished_basalt
fill 330 36 216 330 36 218 minecraft:polished_basalt
fill 330 36 220 330 36 222 minecraft:polished_basalt
setblock 331 36 223 minecraft:bone_block
fill 332 36 181 333 36 181 minecraft:bone_block
fill 332 36 222 334 36 222 minecraft:polished_basalt
fill 332 36 223 332 39 223 minecraft:smooth_basalt
fill 334 36 181 334 37 181 minecraft:smooth_basalt
fill 334 36 182 336 36 182 minecraft:polished_basalt
fill 336 36 222 338 36 222 minecraft:polished_basalt
fill 338 36 182 340 36 182 minecraft:polished_basalt
fill 339 36 223 340 37 223 minecraft:bone_block
fill 340 36 222 342 36 222 minecraft:polished_basalt
fill 341 36 223 342 41 223 minecraft:smooth_basalt
fill 342 36 181 343 41 181 minecraft:smooth_basalt
fill 342 36 182 344 36 182 minecraft:polished_basalt
fill 344 36 181 345 37 181 minecraft:bone_block
fill 344 36 222 346 36 222 minecraft:polished_basalt
fill 346 36 182 348 36 182 minecraft:polished_basalt
setblock 347 36 223 minecraft:smooth_basalt
fill 348 36 222 350 36 222 minecraft:polished_basalt
fill 348 36 223 348 37 223 minecraft:bone_block
fill 350 36 182 352 36 182 minecraft:polished_basalt
fill 350 36 223 350 41 223 minecraft:smooth_basalt
fill 351 36 181 351 41 181 minecraft:smooth_basalt
fill 351 36 223 352 36 223 minecraft:bone_block
fill 352 36 181 353 36 181 minecraft:bone_block
fill 352 36 222 354 36 222 minecraft:polished_basalt
fill 353 36 223 353 41 223 minecraft:smooth_basalt
fill 354 36 181 354 41 181 minecraft:smooth_basalt
fill 354 36 182 356 36 182 minecraft:polished_basalt
fill 356 36 181 356 37 181 minecraft:bone_block
fill 356 36 222 358 36 222 minecraft:polished_basalt
setblock 357 36 181 minecraft:smooth_basalt
fill 358 36 182 360 36 182 minecraft:polished_basalt
fill 359 36 223 360 37 223 minecraft:bone_block
fill 360 36 222 362 36 222 minecraft:polished_basalt
fill 361 36 223 362 41 223 minecraft:smooth_basalt
fill 362 36 181 363 41 181 minecraft:smooth_basalt
fill 362 36 182 364 36 182 minecraft:polished_basalt
fill 364 36 181 365 37 181 minecraft:bone_block
fill 364 36 222 366 36 222 minecraft:polished_basalt
fill 366 36 182 368 36 182 minecraft:polished_basalt
fill 368 36 222 370 36 222 minecraft:polished_basalt
fill 370 36 182 370 36 184 minecraft:polished_basalt
fill 370 36 186 370 36 188 minecraft:polished_basalt
fill 370 36 190 370 36 192 minecraft:polished_basalt
fill 370 36 194 370 36 196 minecraft:polished_basalt
fill 370 36 198 370 36 200 minecraft:polished_basalt
fill 370 36 202 370 36 204 minecraft:polished_basalt
fill 370 36 206 370 36 208 minecraft:polished_basalt
fill 370 36 210 370 36 212 minecraft:polished_basalt
fill 370 36 214 370 36 216 minecraft:polished_basalt
fill 370 36 218 370 36 220 minecraft:polished_basalt
fill 371 36 182 371 39 182 minecraft:smooth_basalt
setblock 371 36 183 minecraft:bone_block
fill 371 36 184 371 41 185 minecraft:smooth_basalt
fill 371 36 186 371 37 187 minecraft:bone_block
fill 371 36 192 371 41 193 minecraft:smooth_basalt
fill 371 36 194 371 36 195 minecraft:bone_block
fill 371 36 196 371 41 196 minecraft:smooth_basalt
fill 371 36 204 371 41 205 minecraft:smooth_basalt
fill 371 36 206 371 37 207 minecraft:bone_block
fill 371 36 213 371 39 214 minecraft:smooth_basalt
setblock 371 36 215 minecraft:bone_block
fill 371 36 216 371 41 217 minecraft:smooth_basalt
fill 371 36 218 371 37 218 minecraft:bone_block
setblock 371 36 219 minecraft:smooth_basalt
fill 371 36 223 371 37 223 minecraft:bone_block
setblock 329 37 189 minecraft:bone_block
fill 329 37 193 329 40 193 minecraft:smooth_basalt
fill 329 37 209 329 37 210 minecraft:bone_block
setblock 329 37 213 minecraft:bone_block
fill 329 37 214 329 40 214 minecraft:smooth_basalt
fill 331 37 223 331 40 223 minecraft:smooth_basalt
fill 332 37 181 332 40 181 minecraft:smooth_basalt
setblock 333 37 181 minecraft:bone_block
fill 335 37 223 335 39 223 minecraft:smooth_basalt
fill 336 37 181 337 37 181 minecraft:bone_block
setblock 336 37 223 minecraft:bone_block
setblock 347 37 223 minecraft:bone_block
fill 351 37 223 352 40 223 minecraft:smooth_basalt
fill 352 37 181 353 40 181 minecraft:smooth_basalt
setblock 357 37 181 minecraft:bone_block
fill 360 37 215 361 38 217 minecraft:calcite
fill 367 37 223 367 39 223 minecraft:smooth_basalt
setblock 368 37 181 minecraft:bone_block
setblock 368 37 223 minecraft:bone_block
fill 369 37 181 369 39 181 minecraft:smooth_basalt
fill 371 37 183 371 40 183 minecraft:smooth_basalt
fill 371 37 194 371 40 194 minecraft:smooth_basalt
setblock 371 37 195 minecraft:bone_block
fill 371 37 198 371 37 199 minecraft:bone_block
fill 371 37 215 371 40 215 minecraft:smooth_basalt
setblock 371 37 219 minecraft:bone_block
fill 329 38 181 329 40 182 minecraft:smooth_basalt
fill 329 38 187 329 39 188 minecraft:bone_block
fill 329 38 189 329 43 190 minecraft:smooth_basalt
fill 329 38 199 329 38 200 minecraft:bone_block
fill 329 38 201 329 43 202 minecraft:smooth_basalt
fill 329 38 208 329 39 208 minecraft:bone_block
fill 329 38 209 329 43 210 minecraft:smooth_basalt
setblock 329 38 211 minecraft:bone_block
fill 329 38 213 329 43 213 minecraft:smooth_basalt
fill 329 38 219 329 39 220 minecraft:bone_block
fill 329 38 221 329 43 222 minecraft:smooth_basalt
fill 333 38 181 333 43 181 minecraft:smooth_basalt
fill 334 38 181 335 38 181 minecraft:bone_block
fill 336 38 181 337 39 181 minecraft:smooth_basalt
fill 336 38 223 336 43 223 minecraft:smooth_basalt
fill 337 38 223 338 38 223 minecraft:bone_block
fill 338 38 181 338 39 181 minecraft:bone_block
fill 339 38 223 340 43 223 minecraft:smooth_basalt
fill 344 38 181 345 43 181 minecraft:smooth_basalt
fill 345 38 223 346 39 223 minecraft:bone_block
fill 346 38 181 347 39 181 minecraft:bone_block
fill 347 38 223 348 43 223 minecraft:smooth_basalt
setblock 349 38 223 minecraft:bone_block
setblock 355 38 181 minecraft:bone_block
fill 356 38 181 357 43 181 minecraft:smooth_basalt
fill 357 38 223 358 39 223 minecraft:bone_block
fill 358 38 181 359 39 181 minecraft:bone_block
fill 359 38 223 360 43 223 minecraft:smooth_basalt
fill 364 38 181 365 43 181 minecraft:smooth_basalt
fill 366 38 181 367 38 181 minecraft:bone_block
fill 366 38 223 366 39 223 minecraft:bone_block
fill 368 38 181 368 43 181 minecraft:smooth_basalt
fill 368 38 223 368 43 223 minecraft:smooth_basalt
fill 369 38 223 370 38 223 minecraft:bone_block
fill 371 38 186 371 43 187 minecraft:smooth_basalt
fill 371 38 188 371 39 189 minecraft:bone_block
fill 371 38 195 371 43 195 minecraft:smooth_basalt
setblock 371 38 197 minecraft:bone_block
fill 371 38 198 371 43 199 minecraft:smooth_basalt
fill 371 38 200 371 39 200 minecraft:bone_block
fill 371 38 206 371 43 207 minecraft:smooth_basalt
fill 371 38 208 371 38 209 minecraft:bone_block
fill 371 38 218 371 43 219 minecraft:smooth_basalt
fill 371 38 220 371 39 221 minecraft:bone_block
fill 371 38 223 371 43 223 minecraft:smooth_basalt
setblock 329 39 196 minecraft:bone_block
setblock 329 39 199 minecraft:bone_block
fill 329 39 200 329 42 200 minecraft:smooth_basalt
setblock 329 39 207 minecraft:bone_block
fill 329 39 211 329 42 211 minecraft:smooth_basalt
fill 333 39 223 334 39 223 minecraft:bone_block
fill 334 39 181 335 41 181 minecraft:smooth_basalt
setblock 337 39 223 minecraft:bone_block
fill 338 39 223 338 42 223 minecraft:smooth_basalt
setblock 339 39 181 minecraft:bone_block
fill 349 39 223 349 42 223 minecraft:smooth_basalt
setblock 350 39 181 minecraft:bone_block
setblock 354 39 223 minecraft:bone_block
fill 355 39 181 355 42 181 minecraft:smooth_basalt
setblock 365 39 223 minecraft:bone_block
fill 366 39 181 366 42 181 minecraft:smooth_basalt
setblock 367 39 181 minecraft:bone_block
fill 369 39 223 370 42 223 minecraft:smooth_basalt
fill 370 39 181 371 39 181 minecraft:bone_block
fill 371 39 197 371 42 197 minecraft:smooth_basalt
setblock 371 39 201 minecraft:bone_block
fill 371 39 208 371 42 208 minecraft:smooth_basalt
setblock 371 39 209 minecraft:bone_block
setblock 371 39 212 minecraft:bone_block
fill 329 40 185 329 41 186 minecraft:bone_block
fill 329 40 187 329 45 188 minecraft:smooth_basalt
fill 329 40 194 329 41 194 minecraft:bone_block
fill 329 40 195 329 41 196 minecraft:smooth_basalt
fill 329 40 197 329 40 198 minecraft:bone_block
fill 329 40 199 329 45 199 minecraft:smooth_basalt
fill 329 40 205 329 41 206 minecraft:bone_block
fill 329 40 207 329 45 208 minecraft:smooth_basalt
fill 329 40 217 329 40 218 minecraft:bone_block
fill 329 40 219 329 45 220 minecraft:smooth_basalt
fill 332 40 223 332 41 223 minecraft:bone_block
fill 333 40 223 334 45 223 minecraft:smooth_basalt
setblock 335 40 223 minecraft:bone_block
fill 336 40 181 336 43 181 minecraft:smooth_basalt
setblock 337 40 181 minecraft:bone_block
fill 337 40 223 337 45 223 minecraft:smooth_basalt
fill 338 40 181 339 45 181 minecraft:smooth_basalt
fill 340 40 181 341 41 181 minecraft:bone_block
fill 343 40 223 344 41 223 minecraft:bone_block
fill 345 40 223 346 45 223 minecraft:smooth_basalt
fill 346 40 181 347 42 181 minecraft:smooth_basalt
fill 348 40 181 349 40 181 minecraft:bone_block
fill 350 40 181 350 45 181 minecraft:smooth_basalt
fill 354 40 223 354 45 223 minecraft:smooth_basalt
fill 355 40 223 356 40 223 minecraft:bone_block
fill 357 40 223 358 45 223 minecraft:smooth_basalt
fill 358 40 181 359 45 181 minecraft:smooth_basalt
fill 360 40 181 361 41 181 minecraft:bone_block
fill 363 40 223 364 41 223 minecraft:bone_block
fill 365 40 223 366 45 223 minecraft:smooth_basalt
fill 367 40 181 367 45 181 minecraft:smooth_basalt
setblock 367 40 223 minecraft:bone_block
setblock 369 40 181 minecraft:bone_block
fill 370 40 181 371 45 181 minecraft:smooth_basalt
fill 371 40 182 371 41 182 minecraft:bone_block
fill 371 40 188 371 45 189 minecraft:smooth_basalt
fill 371 40 190 371 40 191 minecraft:bone_block
fill 371 40 200 371 45 201 minecraft:smooth_basalt
fill 371 40 202 371 41 203 minecraft:bone_block
fill 371 40 209 371 45 209 minecraft:smooth_basalt
fill 371 40 210 371 40 211 minecraft:bone_block
fill 371 40 212 371 41 213 minecraft:smooth_basalt
fill 371 40 214 371 41 214 minecraft:bone_block
fill 371 40 220 371 45 221 minecraft:smooth_basalt
fill 371 40 222 371 41 222 minecraft:bone_block
fill 329 41 181 329 43 181 minecraft:smooth_basalt
setblock 329 41 182 minecraft:bone_block
setblock 329 41 193 minecraft:bone_block
fill 329 41 197 329 44 198 minecraft:smooth_basalt
setblock 329 41 214 minecraft:bone_block
setblock 329 41 217 minecraft:bone_block
fill 329 41 218 329 44 218 minecraft:smooth_basalt
setblock 331 41 223 minecraft:bone_block
setblock 332 41 181 minecraft:bone_block
setblock 332 41 184 minecraft:light[level=12]
setblock 332 41 192 minecraft:light[level=12]
setblock 332 41 200 minecraft:light[level=12]
setblock 332 41 208 minecraft:light[level=12]
setblock 332 41 216 minecraft:light[level=12]
fill 335 41 223 335 44 223 minecraft:smooth_basalt
fill 337 41 181 337 43 181 minecraft:smooth_basalt
setblock 340 41 184 minecraft:light[level=12]
setblock 340 41 192 minecraft:light[level=12]
setblock 340 41 200 minecraft:light[level=12]
setblock 340 41 208 minecraft:light[level=12]
setblock 340 41 216 minecraft:light[level=12]
fill 348 41 181 348 44 181 minecraft:smooth_basalt
setblock 348 41 184 minecraft:light[level=12]
setblock 348 41 192 minecraft:light[level=12]
setblock 348 41 200 minecraft:light[level=12]
setblock 348 41 208 minecraft:light[level=12]
setblock 348 41 216 minecraft:light[level=12]
setblock 349 41 181 minecraft:bone_block
fill 351 41 223 352 41 223 minecraft:bone_block
fill 352 41 181 353 41 181 minecraft:bone_block
setblock 355 41 223 minecraft:bone_block
setblock 356 41 184 minecraft:light[level=12]
setblock 356 41 192 minecraft:light[level=12]
setblock 356 41 200 minecraft:light[level=12]
setblock 356 41 208 minecraft:light[level=12]
setblock 356 41 216 minecraft:light[level=12]
fill 356 41 223 356 44 223 minecraft:smooth_basalt
setblock 364 41 184 minecraft:light[level=12]
setblock 364 41 192 minecraft:light[level=12]
setblock 364 41 200 minecraft:light[level=12]
setblock 364 41 208 minecraft:light[level=12]
setblock 364 41 216 minecraft:light[level=12]
fill 367 41 223 367 44 223 minecraft:smooth_basalt
fill 369 41 181 369 44 181 minecraft:smooth_basalt
setblock 371 41 183 minecraft:bone_block
fill 371 41 190 371 44 190 minecraft:smooth_basalt
setblock 371 41 191 minecraft:bone_block
setblock 371 41 194 minecraft:bone_block
fill 371 41 210 371 44 211 minecraft:smooth_basalt
setblock 371 41 215 minecraft:bone_block
fill 329 42 182 329 47 182 minecraft:smooth_basalt
fill 329 42 183 329 42 184 minecraft:bone_block
fill 329 42 185 329 47 186 minecraft:smooth_basalt
fill 329 42 191 329 43 192 minecraft:bone_block
fill 329 42 193 329 47 194 minecraft:smooth_basalt
setblock 329 42 195 minecraft:bone_block
fill 329 42 196 329 45 196 minecraft:smooth_basalt
fill 329 42 203 329 43 204 minecraft:bone_block
fill 329 42 205 329 47 206 minecraft:smooth_basalt
fill 329 42 212 329 43 212 minecraft:bone_block
fill 329 42 214 329 47 214 minecraft:smooth_basalt
fill 329 42 215 329 42 216 minecraft:bone_block
fill 329 42 217 329 47 217 minecraft:smooth_basalt
fill 329 42 223 330 43 223 minecraft:bone_block
fill 330 42 181 331 42 181 minecraft:bone_block
fill 330 42 182 332 42 182 minecraft:polished_basalt
fill 330 42 184 330 42 186 minecraft:polished_basalt
fill 330 42 188 330 42 190 minecraft:polished_basalt
fill 330 42 192 330 42 194 minecraft:polished_basalt
fill 330 42 196 330 42 198 minecraft:polished_basalt
fill 330 42 200 330 42 202 minecraft:polished_basalt
fill 330 42 204 330 42 206 minecraft:polished_basalt
fill 330 42 208 330 42 210 minecraft:polished_basalt
fill 330 42 212 330 42 214 minecraft:polished_basalt
fill 330 42 216 330 42 218 minecraft:polished_basalt
fill 330 42 220 330 42 222 minecraft:polished_basalt
fill 331 42 223 332 47 223 minecraft:smooth_basalt
fill 332 42 181 332 47 181 minecraft:smooth_basalt
fill 332 42 222 334 42 222 minecraft:polished_basalt
fill 334 42 181 334 43 181 minecraft:bone_block
fill 334 42 182 336 42 182 minecraft:polished_basalt
setblock 335 42 181 minecraft:smooth_basalt
fill 336 42 222 338 42 222 minecraft:polished_basalt
fill 338 42 182 340 42 182 minecraft:polished_basalt
fill 340 42 181 341 47 181 minecraft:smooth_basalt
fill 340 42 222 342 42 222 minecraft:polished_basalt
fill 341 42 223 342 42 223 minecraft:bone_block
fill 342 42 181 343 43 181 minecraft:bone_block
fill 342 42 182 344 42 182 minecraft:polished_basalt
fill 343 42 223 344 47 223 minecraft:smooth_basalt
fill 344 42 222 346 42 222 minecraft:polished_basalt
fill 346 42 182 348 42 182 minecraft:polished_basalt
fill 348 42 222 350 42 222 minecraft:polished_basalt
fill 349 42 181 349 44 181 minecraft:smooth_basalt
fill 350 42 182 352 42 182 minecraft:polished_basalt
fill 350 42 223 350 43 223 minecraft:bone_block
setblock 351 42 181 minecraft:bone_block
fill 351 42 223 352 47 223 minecraft:smooth_basalt
fill 352 42 181 353 47 181 minecraft:smooth_basalt
fill 352 42 222 354 42 222 minecraft:polished_basalt
setblock 353 42 223 minecraft:bone_block
fill 354 42 181 354 43 181 minecraft:bone_block
fill 354 42 182 356 42 182 minecraft:polished_basalt
fill 355 42 223 355 47 223 minecraft:smooth_basalt
fill 356 42 222 358 42 222 minecraft:polished_basalt
fill 358 42 182 360 42 182 minecraft:polished_basalt
fill 360 42 181 361 47 181 minecraft:smooth_basalt
fill 360 42 222 362 42 222 minecraft:polished_basalt
fill 361 42 223 362 43 223 minecraft:bone_block
fill 362 42 181 363 42 181 minecraft:bone_block
fill 362 42 182 364 42 182 minecraft:polished_basalt
fill 363 42 223 364 47 223 minecraft:smooth_basalt
fill 364 42 222 366 42 222 minecraft:polished_basalt
fill 366 42 182 368 42 182 minecraft:polished_basalt
fill 368 42 222 370 42 222 minecraft:polished_basalt
fill 370 42 182 370 42 184 minecraft:polished_basalt
fill 370 42 186 370 42 188 minecraft:polished_basalt
fill 370 42 190 370 42 192 minecraft:polished_basalt
fill 370 42 194 370 42 196 minecraft:polished_basalt
fill 370 42 198 370 42 200 minecraft:polished_basalt
fill 370 42 202 370 42 204 minecraft:polished_basalt
fill 370 42 206 370 42 208 minecraft:polished_basalt
fill 370 42 210 370 42 212 minecraft:polished_basalt
fill 370 42 214 370 42 216 minecraft:polished_basalt
fill 370 42 218 370 42 220 minecraft:polished_basalt
fill 371 42 182 371 47 183 minecraft:smooth_basalt
fill 371 42 184 371 43 185 minecraft:bone_block
fill 371 42 191 371 47 191 minecraft:smooth_basalt
fill 371 42 192 371 42 193 minecraft:bone_block
fill 371 42 194 371 47 194 minecraft:smooth_basalt
fill 371 42 196 371 43 196 minecraft:bone_block
fill 371 42 202 371 47 203 minecraft:smooth_basalt
fill 371 42 204 371 43 205 minecraft:bone_block
fill 371 42 212 371 45 212 minecraft:smooth_basalt
setblock 371 42 213 minecraft:bone_block
fill 371 42 214 371 47 215 minecraft:smooth_basalt
fill 371 42 216 371 43 217 minecraft:bone_block
fill 371 42 222 371 47 222 minecraft:smooth_basalt
setblock 329 43 183 minecraft:bone_block
fill 329 43 184 329 46 184 minecraft:smooth_basalt
fill 329 43 195 329 46 195 minecraft:smooth_basalt
setblock 329 43 200 minecraft:bone_block
setblock 329 43 211 minecraft:bone_block
fill 329 43 215 329 46 216 minecraft:smooth_basalt
fill 330 43 181 330 46 181 minecraft:smooth_basalt
setblock 331 43 181 minecraft:bone_block
setblock 335 43 181 minecraft:bone_block
setblock 338 43 223 minecraft:bone_block
setblock 341 43 223 minecraft:bone_block
fill 342 43 223 342 46 223 minecraft:smooth_basalt
setblock 346 43 181 minecraft:bone_block
fill 347 43 181 347 45 181 minecraft:smooth_basalt
setblock 349 43 223 minecraft:bone_block
fill 351 43 181 351 46 181 minecraft:smooth_basalt
fill 353 43 223 353 46 223 minecraft:smooth_basalt
setblock 355 43 181 minecraft:bone_block
fill 362 43 181 362 46 181 minecraft:smooth_basalt
setblock 363 43 181 minecraft:bone_block
setblock 366 43 181 minecraft:bone_block
fill 369 43 223 370 43 223 minecraft:bone_block
fill 371 43 192 371 46 193 minecraft:smooth_basalt
setblock 371 43 197 minecraft:bone_block
setblock 371 43 208 minecraft:bone_block
fill 371 43 213 371 46 213 minecraft:smooth_basalt
setblock 329 44 181 minecraft:bone_block
fill 329 44 183 329 49 183 minecraft:smooth_basalt
fill 329 44 189 329 45 190 minecraft:bone_block
fill 329 44 191 329 49 192 minecraft:smooth_basalt
fill 329 44 200 329 49 200 minecraft:smooth_basalt
fill 329 44 201 329 44 202 minecraft:bone_block
fill 329 44 203 329 49 204 minecraft:smooth_basalt
fill 329 44 209 329 45 210 minecraft:bone_block
fill 329 44 211 329 49 212 minecraft:smooth_basalt
setblock 329 44 213 minecraft:bone_block
fill 329 44 221 329 45 222 minecraft:bone_block
fill 329 44 223 330 49 223 minecraft:smooth_basalt
fill 331 44 181 331 46 181 minecraft:smooth_basalt
setblock 333 44 181 minecraft:bone_block
fill 334 44 181 335 49 181 minecraft:smooth_basalt
fill 336 44 181 337 45 181 minecraft:bone_block
fill 336 44 223 336 45 223 minecraft:bone_block
fill 338 44 223 338 49 223 minecraft:smooth_basalt
fill 339 44 223 340 44 223 minecraft:bone_block
fill 341 44 223 341 49 223 minecraft:smooth_basalt
fill 342 44 181 343 49 181 minecraft:smooth_basalt
fill 344 44 181 345 44 181 minecraft:bone_block
fill 346 44 181 346 45 181 minecraft:smooth_basalt
fill 347 44 223 348 45 223 minecraft:bone_block
fill 349 44 223 350 49 223 minecraft:smooth_basalt
fill 354 44 181 355 49 181 minecraft:smooth_basalt
fill 356 44 181 357 45 181 minecraft:bone_block
fill 359 44 223 360 44 223 minecraft:bone_block
fill 361 44 223 362 49 223 minecraft:smooth_basalt
fill 363 44 181 363 49 181 minecraft:smooth_basalt
fill 364 44 181 365 44 181 minecraft:bone_block
fill 366 44 181 366 49 181 minecraft:smooth_basalt
fill 368 44 181 368 45 181 minecraft:bone_block
fill 368 44 223 368 45 223 minecraft:bone_block
fill 369 44 223 370 49 223 minecraft:smooth_basalt
fill 371 44 184 371 49 185 minecraft:smooth_basalt
fill 371 44 186 371 45 187 minecraft:bone_block
setblock 371 44 195 minecraft:bone_block
fill 371 44 196 371 49 197 minecraft:smooth_basalt
fill 371 44 198 371 45 199 minecraft:bone_block
fill 371 44 204 371 49 205 minecraft:smooth_basalt
fill 371 44 206 371 44 207 minecraft:bone_block
fill 371 44 208 371 49 208 minecraft:smooth_basalt
fill 371 44 216 371 49 217 minecraft:smooth_basalt
fill 371 44 218 371 45 219 minecraft:bone_block
setblock 371 44 223 minecraft:bone_block
fill 329 45 181 329 48 181 minecraft:smooth_basalt
fill 329 45 197 329 45 198 minecraft:bone_block
setblock 329 45 201 minecraft:bone_block
fill 329 45 202 329 48 202 minecraft:smooth_basalt
fill 329 45 213 329 48 213 minecraft:smooth_basalt
setblock 329 45 218 minecraft:bone_block
fill 333 45 181 333 48 181 minecraft:smooth_basalt
setblock 335 45 223 minecraft:bone_block
fill 339 45 223 340 48 223 minecraft:smooth_basalt
fill 344 45 181 344 48 181 minecraft:smooth_basalt
setblock 345 45 181 minecraft:bone_block
fill 348 45 181 349 45 181 minecraft:bone_block
fill 352 45 210 352 46 210 minecraft:calcite
setblock 356 45 223 minecraft:bone_block
setblock 359 45 223 minecraft:bone_block
fill 360 45 223 360 48 223 minecraft:smooth_basalt
fill 364 45 181 365 48 181 minecraft:smooth_basalt
setblock 367 45 223 minecraft:bone_block
setblock 369 45 181 minecraft:bone_block
setblock 371 45 190 minecraft:bone_block
fill 371 45 195 371 48 195 minecraft:smooth_basalt
fill 371 45 206 371 48 206 minecraft:smooth_basalt
setblock 371 45 207 minecraft:bone_block
fill 371 45 210 371 45 211 minecraft:bone_block
fill 371 45 223 371 48 223 minecraft:smooth_basalt
fill 329 46 187 329 46 188 minecraft:bone_block
fill 329 46 189 329 51 190 minecraft:smooth_basalt
fill 329 46 196 329 47 196 minecraft:bone_block
fill 329 46 197 329 51 198 minecraft:smooth_basalt
setblock 329 46 199 minecraft:bone_block
fill 329 46 201 329 51 201 minecraft:smooth_basalt
fill 329 46 207 329 47 208 minecraft:bone_block
fill 329 46 209 329 51 210 minecraft:smooth_basalt
fill 329 46 218 329 51 218 minecraft:smooth_basalt
fill 329 46 219 329 46 220 minecraft:bone_block
fill 329 46 221 329 51 222 minecraft:smooth_basalt
fill 333 46 223 334 47 223 minecraft:bone_block
fill 335 46 223 336 51 223 minecraft:smooth_basalt
fill 336 46 181 337 51 181 minecraft:smooth_basalt
setblock 337 46 223 minecraft:bone_block
fill 338 46 181 339 47 181 minecraft:bone_block
fill 345 46 181 345 51 181 minecraft:smooth_basalt
fill 345 46 223 346 47 223 minecraft:bone_block
fill 346 46 181 347 46 181 minecraft:bone_block
fill 347 46 223 348 51 223 minecraft:smooth_basalt
fill 348 46 181 349 47 181 minecraft:smooth_basalt
fill 350 46 181 350 47 181 minecraft:bone_block
fill 354 46 223 354 47 223 minecraft:bone_block
fill 356 46 181 357 51 181 minecraft:smooth_basalt
fill 356 46 223 356 51 223 minecraft:smooth_basalt
fill 357 46 223 358 46 223 minecraft:bone_block
fill 358 46 181 359 47 181 minecraft:bone_block
fill 359 46 223 359 51 223 minecraft:smooth_basalt
fill 365 46 223 366 47 223 minecraft:bone_block
setblock 367 46 181 minecraft:bone_block
fill 367 46 223 368 51 223 minecraft:smooth_basalt
fill 368 46 181 369 51 181 minecraft:smooth_basalt
fill 370 46 181 371 47 181 minecraft:bone_block
fill 371 46 186 371 51 187 minecraft:smooth_basalt
fill 371 46 188 371 46 189 minecraft:bone_block
fill 371 46 190 371 51 190 minecraft:smooth_basalt
fill 371 46 198 371 51 199 minecraft:smooth_basalt
fill 371 46 200 371 47 201 minecraft:bone_block
fill 371 46 207 371 51 207 minecraft:smooth_basalt
setblock 371 46 209 minecraft:bone_block
fill 371 46 210 371 51 211 minecraft:smooth_basalt
fill 371 46 212 371 47 212 minecraft:bone_block
fill 371 46 218 371 51 219 minecraft:smooth_basalt
fill 371 46 220 371 46 221 minecraft:bone_block
setblock 329 47 184 minecraft:bone_block
setblock 329 47 187 minecraft:bone_block
fill 329 47 188 329 50 188 minecraft:smooth_basalt
setblock 329 47 195 minecraft:bone_block
fill 329 47 199 329 50 199 minecraft:smooth_basalt
fill 329 47 215 329 47 216 minecraft:bone_block
setblock 329 47 219 minecraft:bone_block
fill 329 47 220 329 50 220 minecraft:smooth_basalt
fill 330 47 181 331 47 181 minecraft:bone_block
fill 337 47 223 337 50 223 minecraft:smooth_basalt
setblock 342 47 223 minecraft:bone_block
fill 346 47 181 347 49 181 minecraft:smooth_basalt
setblock 351 47 181 minecraft:bone_block
setblock 353 47 223 minecraft:bone_block
fill 357 47 223 358 50 223 minecraft:smooth_basalt
setblock 362 47 181 minecraft:bone_block
fill 367 47 181 367 50 181 minecraft:smooth_basalt
fill 371 47 188 371 50 188 minecraft:smooth_basalt
setblock 371 47 189 minecraft:bone_block
fill 371 47 192 371 47 193 minecraft:bone_block
fill 371 47 209 371 50 209 minecraft:smooth_basalt
setblock 371 47 213 minecraft:bone_block
fill 371 47 220 371 50 220 minecraft:smooth_basalt
setblock 371 47 221 minecraft:bone_block
fill 329 48 182 329 49 182 minecraft:bone_block
fill 329 48 184 329 53 184 minecraft:smooth_basalt
fill 329 48 185 329 48 186 minecraft:bone_block
fill 329 48 187 329 53 187 minecraft:smooth_basalt
fill 329 48 193 329 49 194 minecraft:bone_block
fill 329 48 195 329 53 196 minecraft:smooth_basalt
fill 329 48 205 329 48 206 minecraft:bone_block
fill 329 48 207 329 53 208 minecraft:smooth_basalt
fill 329 48 214 329 49 214 minecraft:bone_block
fill 329 48 215 329 53 216 minecraft:smooth_basalt
setblock 329 48 217 minecraft:bone_block
fill 329 48 219 329 53 219 minecraft:smooth_basalt
fill 330 48 181 331 49 181 minecraft:smooth_basalt
fill 330 48 182 332 48 182 minecraft:polished_basalt
fill 330 48 184 330 48 186 minecraft:polished_basalt
fill 330 48 188 330 48 190 minecraft:polished_basalt
fill 330 48 192 330 48 194 minecraft:polished_basalt
fill 330 48 196 330 48 198 minecraft:polished_basalt
fill 330 48 200 330 48 202 minecraft:polished_basalt
fill 330 48 204 330 48 206 minecraft:polished_basalt
fill 330 48 208 330 48 210 minecraft:polished_basalt
fill 330 48 212 330 48 214 minecraft:polished_basalt
fill 330 48 216 330 48 218 minecraft:polished_basalt
fill 330 48 220 330 48 222 minecraft:polished_basalt
fill 331 48 223 332 49 223 minecraft:bone_block
fill 332 48 181 332 49 181 minecraft:bone_block
fill 332 48 222 334 48 222 minecraft:polished_basalt
fill 333 48 223 334 53 223 minecraft:smooth_basalt
fill 334 48 182 336 48 182 minecraft:polished_basalt
fill 336 48 222 338 48 222 minecraft:polished_basalt
fill 338 48 181 339 53 181 minecraft:smooth_basalt
fill 338 48 182 340 48 182 minecraft:polished_basalt
fill 340 48 181 341 49 181 minecraft:bone_block
fill 340 48 222 342 48 222 minecraft:polished_basalt
fill 342 48 182 344 48 182 minecraft:polished_basalt
fill 342 48 223 342 53 223 minecraft:smooth_basalt
fill 343 48 223 344 48 223 minecraft:bone_block
fill 344 48 222 346 48 222 minecraft:polished_basalt
fill 345 48 223 346 53 223 minecraft:smooth_basalt
fill 346 48 182 348 48 182 minecraft:polished_basalt
fill 348 48 181 348 51 181 minecraft:smooth_basalt
fill 348 48 222 350 48 222 minecraft:polished_basalt
setblock 349 48 181 minecraft:bone_block
fill 350 48 181 351 53 181 minecraft:smooth_basalt
fill 350 48 182 352 48 182 minecraft:polished_basalt
fill 351 48 223 352 49 223 minecraft:bone_block
fill 352 48 181 353 49 181 minecraft:bone_block
fill 352 48 222 354 48 222 minecraft:polished_basalt
fill 353 48 185 354 49 185 minecraft:bone_block
fill 353 48 223 354 53 223 minecraft:smooth_basalt
fill 354 48 182 356 48 182 minecraft:polished_basalt
setblock 355 48 223 minecraft:bone_block
fill 356 48 222 358 48 222 minecraft:polished_basalt
fill 358 48 181 359 50 181 minecraft:smooth_basalt
fill 358 48 182 360 48 182 minecraft:polished_basalt
fill 360 48 181 361 48 181 minecraft:bone_block
fill 360 48 222 362 48 222 minecraft:polished_basalt
fill 362 48 181 362 53 181 minecraft:smooth_basalt
fill 362 48 182 364 48 182 minecraft:polished_basalt
fill 363 48 223 364 49 223 minecraft:bone_block
fill 364 48 222 366 48 222 minecraft:polished_basalt
fill 365 48 223 366 53 223 minecraft:smooth_basalt
fill 366 48 182 368 48 182 minecraft:polished_basalt
fill 368 48 222 370 48 222 minecraft:polished_basalt
fill 370 48 181 371 53 181 minecraft:smooth_basalt
fill 370 48 182 370 48 184 minecraft:polished_basalt
fill 370 48 186 370 48 188 minecraft:polished_basalt
fill 370 48 190 370 48 192 minecraft:polished_basalt
fill 370 48 194 370 48 196 minecraft:polished_basalt
fill 370 48 198 370 48 200 minecraft:polished_basalt
fill 370 48 202 370 48 204 minecraft:polished_basalt
fill 370 48 206 370 48 208 minecraft:polished_basalt
fill 370 48 210 370 48 212 minecraft:polished_basalt
fill 370 48 214 370 48 216 minecraft:polished_basalt
fill 370 48 218 370 48 220 minecraft:polished_basalt
fill 371 48 182 371 49 183 minecraft:bone_block
fill 371 48 189 371 53 189 minecraft:smooth_basalt
setblock 371 48 191 minecraft:bone_block
fill 371 48 192 371 53 193 minecraft:smooth_basalt
fill 371 48 194 371 49 194 minecraft:bone_block
fill 371 48 200 371 53 201 minecraft:smooth_basalt
fill 371 48 202 371 48 203 minecraft:bone_block
fill 371 48 212 371 53 213 minecraft:smooth_basalt
fill 371 48 214 371 49 215 minecraft:bone_block
fill 371 48 221 371 53 221 minecraft:smooth_basalt
setblock 371 48 222 minecraft:bone_block
setblock 329 49 181 minecraft:bone_block
fill 329 49 185 329 52 186 minecraft:smooth_basalt
setblock 329 49 202 minecraft:bone_block
setblock 329 49 205 minecraft:bone_block
fill 329 49 206 329 52 206 minecraft:smooth_basalt
setblock 329 49 213 minecraft:bone_block
fill 329 49 217 329 52 217 minecraft:smooth_basalt
setblock 332 49 184 minecraft:light[level=12]
setblock 332 49 192 minecraft:light[level=12]
setblock 332 49 200 minecraft:light[level=12]
setblock 332 49 208 minecraft:light[level=12]
setblock 332 49 216 minecraft:light[level=12]
setblock 333 49 181 minecraft:bone_block
fill 339 49 223 340 49 223 minecraft:bone_block
setblock 340 49 184 minecraft:light[level=12]
setblock 340 49 192 minecraft:light[level=12]
setblock 340 49 200 minecraft:light[level=12]
setblock 340 49 208 minecraft:light[level=12]
setblock 340 49 216 minecraft:light[level=12]
setblock 343 49 223 minecraft:bone_block
setblock 344 49 181 minecraft:bone_block
fill 344 49 223 344 52 223 minecraft:smooth_basalt
setblock 348 49 184 minecraft:light[level=12]
setblock 348 49 192 minecraft:light[level=12]
setblock 348 49 200 minecraft:light[level=12]
setblock 348 49 208 minecraft:light[level=12]
setblock 348 49 216 minecraft:light[level=12]
fill 349 49 181 349 51 181 minecraft:smooth_basalt
fill 355 49 223 355 52 223 minecraft:smooth_basalt
setblock 356 49 184 minecraft:light[level=12]
setblock 356 49 192 minecraft:light[level=12]
setblock 356 49 200 minecraft:light[level=12]
setblock 356 49 208 minecraft:light[level=12]
setblock 356 49 216 minecraft:light[level=12]
fill 360 49 181 360 52 181 minecraft:smooth_basalt
setblock 360 49 223 minecraft:bone_block
setblock 361 49 181 minecraft:bone_block
fill 364 49 181 365 49 181 minecraft:bone_block
setblock 364 49 184 minecraft:light[level=12]
setblock 364 49 192 minecraft:light[level=12]
setblock 364 49 200 minecraft:light[level=12]
setblock 364 49 208 minecraft:light[level=12]
setblock 364 49 216 minecraft:light[level=12]
fill 371 49 191 371 52 191 minecraft:smooth_basalt
setblock 371 49 195 minecraft:bone_block
fill 371 49 202 371 52 202 minecraft:smooth_basalt
setblock 371 49 203 minecraft:bone_block
setblock 371 49 206 minecraft:bone_block
fill 371 49 222 371 52 222 minecraft:smooth_basalt
setblock 371 49 223 minecraft:bone_block
fill 329 50 181 329 55 182 minecraft:smooth_basalt
setblock 329 50 183 minecraft:bone_block
fill 329 50 191 329 51 192 minecraft:bone_block
fill 329 50 193 329 55 194 minecraft:smooth_basalt
fill 329 50 200 329 51 200 minecraft:bone_block
fill 329 50 202 329 55 202 minecraft:smooth_basalt
fill 329 50 203 329 50 204 minecraft:bone_block
fill 329 50 205 329 55 205 minecraft:smooth_basalt
fill 329 50 211 329 51 212 minecraft:bone_block
fill 329 50 213 329 55 214 minecraft:smooth_basalt
fill 329 50 223 330 50 223 minecraft:bone_block
fill 330 50 181 330 53 181 minecraft:smooth_basalt
setblock 331 50 181 minecraft:bone_block
fill 331 50 223 332 55 223 minecraft:smooth_basalt
fill 332 50 181 333 55 181 minecraft:smooth_basalt
fill 334 50 181 335 51 181 minecraft:bone_block
fill 338 50 223 338 51 223 minecraft:bone_block
fill 339 50 223 340 55 223 minecraft:smooth_basalt
fill 340 50 181 341 52 181 minecraft:smooth_basalt
setblock 341 50 223 minecraft:bone_block
fill 342 50 181 343 50 181 minecraft:bone_block
fill 343 50 223 343 55 223 minecraft:smooth_basalt
fill 344 50 181 344 55 181 minecraft:smooth_basalt
fill 346 50 181 346 51 181 minecraft:bone_block
setblock 347 50 181 minecraft:smooth_basalt
fill 349 50 223 350 51 223 minecraft:bone_block
fill 351 50 223 352 55 223 minecraft:smooth_basalt
fill 352 50 181 353 55 181 minecraft:smooth_basalt
fill 354 50 181 355 51 181 minecraft:bone_block
fill 360 50 223 360 55 223 minecraft:smooth_basalt
fill 361 50 181 361 52 181 minecraft:smooth_basalt
fill 361 50 223 362 50 223 minecraft:bone_block
setblock 363 50 181 minecraft:bone_block
fill 363 50 223 364 55 223 minecraft:smooth_basalt
fill 364 50 181 365 55 181 minecraft:smooth_basalt
fill 366 50 181 366 51 181 minecraft:bone_block
fill 369 50 223 370 51 223 minecraft:bone_block
fill 371 50 182 371 55 183 minecraft:smooth_basalt
fill 371 50 184 371 50 185 minecraft:bone_block
fill 371 50 194 371 55 195 minecraft:smooth_basalt
fill 371 50 196 371 51 197 minecraft:bone_block
fill 371 50 203 371 55 203 minecraft:smooth_basalt
fill 371 50 204 371 50 205 minecraft:bone_block
fill 371 50 206 371 55 206 minecraft:smooth_basalt
fill 371 50 208 371 51 208 minecraft:bone_block
fill 371 50 214 371 55 215 minecraft:smooth_basalt
fill 371 50 216 371 51 217 minecraft:bone_block
fill 371 50 223 371 55 223 minecraft:smooth_basalt
fill 329 51 183 329 54 183 minecraft:smooth_basalt
setblock 329 51 188 minecraft:bone_block
setblock 329 51 199 minecraft:bone_block
fill 329 51 203 329 54 204 minecraft:smooth_basalt
setblock 329 51 220 minecraft:bone_block
setblock 329 51 223 minecraft:bone_block
fill 330 51 223 330 54 223 minecraft:smooth_basalt
fill 331 51 181 331 53 181 minecraft:smooth_basalt
setblock 337 51 223 minecraft:bone_block
fill 341 51 223 341 54 223 minecraft:smooth_basalt
fill 342 51 181 342 54 181 minecraft:smooth_basalt
setblock 343 51 181 minecraft:bone_block
setblock 347 51 181 minecraft:bone_block
fill 357 51 223 358 51 223 minecraft:bone_block
setblock 358 51 181 minecraft:bone_block
fill 359 51 181 359 53 181 minecraft:smooth_basalt
setblock 361 51 223 minecraft:bone_block
fill 362 51 223 362 54 223 minecraft:smooth_basalt
fill 363 51 181 363 54 181 minecraft:smooth_basalt
setblock 367 51 181 minecraft:bone_block
fill 371 51 184 371 54 184 minecraft:smooth_basalt
setblock 371 51 185 minecraft:bone_block
setblock 371 51 188 minecraft:bone_block
fill 371 51 204 371 54 205 minecraft:smooth_basalt
setblock 371 51 209 minecraft:bone_block
setblock 371 51 220 minecraft:bone_block
fill 329 52 188 329 57 188 minecraft:smooth_basalt
fill 329 52 189 329 52 190 minecraft:bone_block
fill 329 52 191 329 57 192 minecraft:smooth_basalt
fill 329 52 197 329 53 198 minecraft:bone_block
fill 329 52 199 329 57 200 minecraft:smooth_basalt
setblock 329 52 201 minecraft:bone_block
fill 329 52 209 329 53 210 minecraft:bone_block
fill 329 52 211 329 57 212 minecraft:smooth_basalt
fill 329 52 218 329 53 218 minecraft:bone_block
fill 329 52 220 329 57 220 minecraft:smooth_basalt
fill 329 52 221 329 52 222 minecraft:bone_block
fill 329 52 223 329 57 223 minecraft:smooth_basalt
fill 334 52 181 335 57 181 minecraft:smooth_basalt
fill 335 52 223 336 53 223 minecraft:bone_block
fill 336 52 181 337 53 181 minecraft:bone_block
fill 337 52 223 338 57 223 minecraft:smooth_basalt
fill 343 52 181 343 54 181 minecraft:smooth_basalt
setblock 345 52 181 minecraft:bone_block
fill 346 52 181 347 57 181 minecraft:smooth_basalt
fill 347 52 223 348 52 223 minecraft:bone_block
fill 348 52 181 349 53 181 minecraft:bone_block
fill 349 52 223 350 57 223 minecraft:smooth_basalt
fill 354 52 181 355 57 181 minecraft:smooth_basalt
fill 356 52 181 357 52 181 minecraft:bone_block
fill 356 52 223 356 53 223 minecraft:bone_block
fill 357 52 223 358 57 223 minecraft:smooth_basalt
fill 358 52 181 358 53 181 minecraft:smooth_basalt
setblock 359 52 223 minecraft:bone_block
fill 361 52 223 361 57 223 minecraft:smooth_basalt
fill 366 52 181 367 57 181 minecraft:smooth_basalt
fill 367 52 223 368 53 223 minecraft:bone_block
fill 368 52 181 369 53 181 minecraft:bone_block
fill 369 52 223 370 57 223 minecraft:smooth_basalt
fill 371 52 185 371 57 185 minecraft:smooth_basalt
fill 371 52 186 371 52 187 minecraft:bone_block
fill 371 52 188 371 57 188 minecraft:smooth_basalt
fill 371 52 190 371 53 190 minecraft:bone_block
fill 371 52 196 371 57 197 minecraft:smooth_basalt
fill 371 52 198 371 53 199 minecraft:bone_block
setblock 371 52 207 minecraft:bone_block
fill 371 52 208 371 57 209 minecraft:smooth_basalt
fill 371 52 210 371 53 211 minecraft:bone_block
fill 371 52 216 371 57 217 minecraft:smooth_basalt
fill 371 52 218 371 52 219 minecraft:bone_block
fill 371 52 220 371 57 220 minecraft:smooth_basalt
fill 329 53 185 329 53 186 minecraft:bone_block
setblock 329 53 189 minecraft:bone_block
fill 329 53 190 329 56 190 minecraft:smooth_basalt
fill 329 53 201 329 56 201 minecraft:smooth_basalt
setblock 329 53 206 minecraft:bone_block
setblock 329 53 217 minecraft:bone_block
fill 329 53 221 329 56 222 minecraft:smooth_basalt
setblock 340 53 181 minecraft:bone_block
fill 341 53 181 341 55 181 minecraft:smooth_basalt
setblock 344 53 223 minecraft:bone_block
fill 345 53 181 345 56 181 minecraft:smooth_basalt
setblock 347 53 223 minecraft:bone_block
fill 348 53 223 348 56 223 minecraft:smooth_basalt
setblock 355 53 223 minecraft:bone_block
fill 356 53 181 356 56 181 minecraft:smooth_basalt
setblock 357 53 181 minecraft:bone_block
fill 359 53 223 359 56 223 minecraft:smooth_basalt
fill 360 53 181 361 53 181 minecraft:bone_block
fill 371 53 186 371 56 187 minecraft:smooth_basalt
setblock 371 53 191 minecraft:bone_block
setblock 371 53 202 minecraft:bone_block
fill 371 53 207 371 56 207 minecraft:smooth_basalt
fill 371 53 218 371 56 218 minecraft:smooth_basalt
setblock 371 53 219 minecraft:bone_block
setblock 371 53 222 minecraft:bone_block
fill 329 54 184 329 55 184 minecraft:bone_block
fill 329 54 185 329 59 186 minecraft:smooth_basalt
setblock 329 54 187 minecraft:bone_block
fill 329 54 189 329 59 189 minecraft:smooth_basalt
fill 329 54 195 329 55 196 minecraft:bone_block
fill 329 54 197 329 59 198 minecraft:smooth_basalt
fill 329 54 206 329 59 206 minecraft:smooth_basalt
fill 329 54 207 329 54 208 minecraft:bone_block
fill 329 54 209 329 59 210 minecraft:smooth_basalt
fill 329 54 215 329 55 216 minecraft:bone_block
fill 329 54 217 329 59 218 minecraft:smooth_basalt
setblock 329 54 219 minecraft:bone_block
fill 330 54 181 331 55 181 minecraft:bone_block
fill 330 54 182 332 54 182 minecraft:polished_basalt
fill 330 54 184 330 54 186 minecraft:polished_basalt
fill 330 54 188 330 54 190 minecraft:polished_basalt
fill 330 54 192 330 54 194 minecraft:polished_basalt
fill 330 54 196 330 54 198 minecraft:polished_basalt
fill 330 54 200 330 54 202 minecraft:polished_basalt
fill 330 54 204 330 54 206 minecraft:polished_basalt
fill 330 54 208 330 54 210 minecraft:polished_basalt
fill 330 54 212 330 54 214 minecraft:polished_basalt
fill 330 54 216 330 54 218 minecraft:polished_basalt
fill 330 54 220 330 54 222 minecraft:polished_basalt
fill 332 54 222 334 54 222 minecraft:polished_basalt
fill 333 54 223 334 55 223 minecraft:bone_block
fill 334 54 182 336 54 182 minecraft:polished_basalt
fill 335 54 223 336 59 223 minecraft:smooth_basalt
fill 336 54 181 337 59 181 minecraft:smooth_basalt
fill 336 54 222 338 54 222 minecraft:polished_basalt
fill 338 54 181 339 54 181 minecraft:bone_block
fill 338 54 182 340 54 182 minecraft:polished_basalt
fill 340 54 181 340 55 181 minecraft:smooth_basalt
fill 340 54 222 342 54 222 minecraft:polished_basalt
fill 342 54 182 344 54 182 minecraft:polished_basalt
fill 342 54 223 342 55 223 minecraft:bone_block
fill 344 54 222 346 54 222 minecraft:polished_basalt
fill 344 54 223 344 59 223 minecraft:smooth_basalt
fill 345 54 223 346 54 223 minecraft:bone_block
fill 346 54 182 348 54 182 minecraft:polished_basalt
fill 347 54 223 347 59 223 minecraft:smooth_basalt
fill 348 54 181 349 59 181 minecraft:smooth_basalt
fill 348 54 222 350 54 222 minecraft:polished_basalt
fill 350 54 181 351 55 181 minecraft:bone_block
fill 350 54 182 352 54 182 minecraft:polished_basalt
fill 352 54 222 354 54 222 minecraft:polished_basalt
fill 353 54 223 354 55 223 minecraft:bone_block
fill 354 54 182 356 54 182 minecraft:polished_basalt
fill 355 54 223 356 59 223 minecraft:smooth_basalt
fill 356 54 222 358 54 222 minecraft:polished_basalt
fill 357 54 181 357 59 181 minecraft:smooth_basalt
fill 358 54 181 359 54 181 minecraft:bone_block
fill 358 54 182 360 54 182 minecraft:polished_basalt
fill 360 54 181 361 55 181 minecraft:smooth_basalt
fill 360 54 222 362 54 222 minecraft:polished_basalt
fill 362 54 181 362 55 181 minecraft:bone_block
fill 362 54 182 364 54 182 minecraft:polished_basalt
fill 364 54 222 366 54 222 minecraft:polished_basalt
fill 365 54 223 366 54 223 minecraft:bone_block
fill 366 54 182 368 54 182 minecraft:polished_basalt
fill 367 54 223 368 59 223 minecraft:smooth_basalt
fill 368 54 181 369 59 181 minecraft:smooth_basalt
fill 368 54 222 370 54 222 minecraft:polished_basalt
fill 370 54 181 371 55 181 minecraft:bone_block
fill 370 54 182 370 54 184 minecraft:polished_basalt
fill 370 54 186 370 54 188 minecraft:polished_basalt
fill 370 54 190 370 54 192 minecraft:polished_basalt
fill 370 54 194 370 54 196 minecraft:polished_basalt
fill 370 54 198 370 54 200 minecraft:polished_basalt
fill 370 54 202 370 54 204 minecraft:polished_basalt
fill 370 54 206 370 54 208 minecraft:polished_basalt
fill 370 54 210 370 54 212 minecraft:polished_basalt
fill 370 54 214 370 54 216 minecraft:polished_basalt
fill 370 54 218 370 54 220 minecraft:polished_basalt
setblock 371 54 189 minecraft:bone_block
fill 371 54 190 371 59 191 minecraft:smooth_basalt
fill 371 54 192 371 55 193 minecraft:bone_block
fill 371 54 198 371 59 199 minecraft:smooth_basalt
fill 371 54 200 371 54 201 minecraft:bone_block
fill 371 54 202 371 59 202 minecraft:smooth_basalt
fill 371 54 210 371 59 211 minecraft:smooth_basalt
fill 371 54 212 371 55 213 minecraft:bone_block
fill 371 54 219 371 59 219 minecraft:smooth_basalt
setblock 371 54 221 minecraft:bone_block
fill 371 54 222 371 59 222 minecraft:smooth_basalt
setblock 329 55 183 minecraft:bone_block
fill 329 55 187 329 58 187 minecraft:smooth_basalt
fill 329 55 203 329 55 204 minecraft:bone_block
setblock 329 55 207 minecraft:bone_block
fill 329 55 208 329 58 208 minecraft:smooth_basalt
fill 329 55 219 329 58 219 minecraft:smooth_basalt
setblock 330 55 223 minecraft:bone_block
fill 338 55 181 338 58 181 minecraft:smooth_basalt
setblock 339 55 181 minecraft:bone_block
setblock 341 55 223 minecraft:bone_block
fill 342 55 181 343 55 181 minecraft:bone_block
fill 345 55 223 346 58 223 minecraft:smooth_basalt
fill 358 55 181 359 57 181 minecraft:smooth_basalt
setblock 362 55 223 minecraft:bone_block
setblock 363 55 181 minecraft:bone_block
setblock 365 55 223 minecraft:bone_block
fill 366 55 223 366 58 223 minecraft:smooth_basalt
setblock 371 55 184 minecraft:bone_block
fill 371 55 189 371 58 189 minecraft:smooth_basalt
fill 371 55 200 371 58 200 minecraft:smooth_basalt
setblock 371 55 201 minecraft:bone_block
fill 371 55 204 371 55 205 minecraft:bone_block
fill 371 55 221 371 58 221 minecraft:smooth_basalt
fill 329 56 181 329 57 182 minecraft:bone_block
fill 329 56 183 329 61 184 minecraft:smooth_basalt
fill 329 56 193 329 56 194 minecraft:bone_block
fill 329 56 195 329 61 196 minecraft:smooth_basalt
fill 329 56 202 329 57 202 minecraft:bone_block
fill 329 56 203 329 61 204 minecraft:smooth_basalt
setblock 329 56 205 minecraft:bone_block
fill 329 56 207 329 61 207 minecraft:smooth_basalt
fill 329 56 213 329 57 214 minecraft:bone_block
fill 329 56 215 329 61 216 minecraft:smooth_basalt
fill 330 56 181 331 61 181 minecraft:smooth_basalt
fill 330 56 223 330 61 223 minecraft:smooth_basalt
fill 331 56 223 332 56 223 minecraft:bone_block
fill 332 56 181 333 57 181 minecraft:bone_block
fill 333 56 223 334 61 223 minecraft:smooth_basalt
fill 339 56 181 339 61 181 minecraft:smooth_basalt
fill 339 56 223 340 57 223 minecraft:bone_block
fill 340 56 181 341 56 181 minecraft:bone_block
fill 341 56 223 342 61 223 minecraft:smooth_basalt
fill 342 56 181 343 57 181 minecraft:smooth_basalt
setblock 343 56 223 minecraft:bone_block
fill 344 56 181 344 57 181 minecraft:bone_block
fill 350 56 181 351 61 181 minecraft:smooth_basalt
fill 351 56 223 352 57 223 minecraft:bone_block
fill 352 56 181 353 57 181 minecraft:bone_block
fill 353 56 223 354 60 223 minecraft:smooth_basalt
fill 360 56 181 360 59 181 minecraft:smooth_basalt
fill 360 56 223 360 57 223 minecraft:bone_block
setblock 361 56 181 minecraft:bone_block
fill 362 56 181 363 61 181 minecraft:smooth_basalt
fill 362 56 223 362 61 223 minecraft:smooth_basalt
fill 363 56 223 364 56 223 minecraft:bone_block
fill 364 56 181 365 57 181 minecraft:bone_block
fill 365 56 223 365 61 223 minecraft:smooth_basalt
fill 370 56 181 371 58 181 minecraft:smooth_basalt
fill 371 56 182 371 56 183 minecraft:bone_block
fill 371 56 184 371 61 184 minecraft:smooth_basalt
fill 371 56 192 371 61 193 minecraft:smooth_basalt
fill 371 56 194 371 57 195 minecraft:bone_block
fill 371 56 201 371 61 201 minecraft:smooth_basalt
setblock 371 56 203 minecraft:bone_block
fill 371 56 204 371 61 205 minecraft:smooth_basalt
fill 371 56 206 371 57 206 minecraft:bone_block
schedule function dropper:buildpart/43_2 1t
