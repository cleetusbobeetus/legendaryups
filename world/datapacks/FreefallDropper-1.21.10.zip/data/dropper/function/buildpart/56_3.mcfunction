setblock 407 230 228 minecraft:moss_block
fill 407 230 236 417 230 236 minecraft:oak_leaves[persistent=true]
fill 407 230 239 407 231 239 minecraft:green_terracotta
fill 407 230 258 407 232 258 minecraft:green_terracotta
fill 407 230 260 408 230 260 minecraft:oak_leaves[persistent=true]
fill 407 230 270 408 230 270 minecraft:lime_terracotta
fill 408 230 228 411 230 228 minecraft:lime_terracotta
setblock 408 230 238 minecraft:oak_leaves[persistent=true]
setblock 408 230 239 minecraft:brown_terracotta
fill 408 230 255 408 231 255 minecraft:green_terracotta
setblock 408 230 257 minecraft:green_terracotta
fill 408 230 258 417 230 258 minecraft:oak_leaves[persistent=true]
fill 408 230 261 408 230 262 minecraft:jungle_leaves[persistent=true]
fill 409 230 238 409 231 238 minecraft:green_concrete
fill 409 230 239 409 230 240 minecraft:oak_leaves[persistent=true]
fill 409 230 241 409 230 242 minecraft:green_terracotta
setblock 409 230 243 minecraft:lime_terracotta
fill 409 230 244 409 232 244 minecraft:green_terracotta
fill 409 230 252 409 232 252 minecraft:green_terracotta
setblock 409 230 255 minecraft:lime_terracotta
fill 409 230 256 411 230 257 minecraft:oak_leaves[persistent=true]
setblock 409 230 260 minecraft:green_concrete
setblock 409 230 261 minecraft:jungle_leaves[persistent=true]
fill 409 230 270 409 235 270 minecraft:azalea_leaves[persistent=true]
fill 410 230 239 410 232 239 minecraft:jungle_leaves[persistent=true]
fill 410 230 240 411 230 244 minecraft:oak_leaves[persistent=true]
fill 410 230 245 410 230 247 minecraft:green_terracotta
setblock 410 230 248 minecraft:lime_terracotta
fill 410 230 249 410 230 251 minecraft:green_terracotta
fill 410 230 252 410 230 255 minecraft:oak_leaves[persistent=true]
fill 410 230 260 417 230 261 minecraft:oak_leaves[persistent=true]
setblock 410 230 270 minecraft:lime_terracotta
setblock 411 230 238 minecraft:jungle_leaves[persistent=true]
fill 411 230 239 417 230 239 minecraft:oak_leaves[persistent=true]
fill 411 230 245 411 230 253 minecraft:oak_leaves[persistent=true]
fill 411 230 254 412 230 254 minecraft:green_concrete
fill 411 230 255 411 231 255 minecraft:jungle_leaves[persistent=true]
fill 412 230 238 417 230 238 minecraft:oak_leaves[persistent=true]
fill 412 230 240 412 230 242 minecraft:oak_leaves[persistent=true]
fill 412 230 243 412 230 244 minecraft:green_concrete
fill 412 230 245 417 230 246 minecraft:oak_leaves[persistent=true]
fill 412 230 247 413 231 247 minecraft:azalea_leaves[persistent=true]
fill 412 230 248 412 231 248 minecraft:green_concrete
fill 412 230 249 412 230 253 minecraft:oak_leaves[persistent=true]
fill 412 230 257 417 230 257 minecraft:oak_leaves[persistent=true]
fill 412 230 270 417 230 270 minecraft:lime_terracotta
fill 413 230 228 414 243 228 minecraft:lime_terracotta
fill 413 230 240 417 230 241 minecraft:oak_leaves[persistent=true]
fill 413 230 244 417 230 244 minecraft:oak_leaves[persistent=true]
fill 413 230 249 413 231 249 minecraft:azalea_leaves[persistent=true]
fill 413 230 250 417 230 254 minecraft:oak_leaves[persistent=true]
fill 414 230 247 417 230 247 minecraft:oak_leaves[persistent=true]
fill 414 230 249 417 230 249 minecraft:oak_leaves[persistent=true]
fill 416 230 228 418 231 228 minecraft:lime_terracotta
fill 418 230 229 418 239 231 minecraft:lime_terracotta
setblock 418 230 232 minecraft:green_terracotta
fill 418 230 233 418 230 243 minecraft:lime_terracotta
fill 418 230 246 418 230 265 minecraft:lime_terracotta
fill 418 230 267 418 249 267 minecraft:lime_terracotta
fill 418 230 268 418 230 269 minecraft:green_terracotta
fill 376 231 228 376 231 229 minecraft:green_terracotta
fill 376 231 230 376 236 232 minecraft:lime_terracotta
fill 376 231 233 383 232 233 minecraft:jungle_log
fill 376 231 234 376 231 242 minecraft:lime_terracotta
setblock 376 231 243 minecraft:green_terracotta
fill 376 231 244 376 231 251 minecraft:lime_terracotta
setblock 376 231 252 minecraft:green_terracotta
fill 376 231 253 376 231 260 minecraft:lime_terracotta
setblock 376 231 265 minecraft:lime_terracotta
fill 376 231 266 383 232 267 minecraft:jungle_log
fill 376 231 268 376 231 269 minecraft:lime_terracotta
fill 377 231 231 383 279 232 minecraft:jungle_log
fill 377 231 234 377 237 234 minecraft:green_wool
fill 377 231 265 383 279 265 minecraft:jungle_log
setblock 377 231 270 minecraft:green_terracotta
fill 378 231 230 382 279 230 minecraft:jungle_log
fill 378 231 234 384 231 234 minecraft:jungle_log
fill 378 231 260 382 233 260 minecraft:azalea_leaves[persistent=true]
fill 378 231 264 383 232 264 minecraft:jungle_log
fill 378 231 268 382 279 268 minecraft:jungle_log
fill 379 231 228 379 243 228 minecraft:lime_terracotta
fill 379 231 229 381 279 229 minecraft:jungle_log
fill 379 231 235 381 279 235 minecraft:jungle_log
fill 379 231 258 381 234 259 minecraft:azalea_leaves[persistent=true]
fill 379 231 263 381 279 263 minecraft:jungle_log
fill 379 231 269 381 279 269 minecraft:jungle_log
fill 380 231 228 381 231 228 minecraft:green_terracotta
fill 380 231 240 380 243 240 minecraft:green_wool
fill 380 231 257 381 233 257 minecraft:azalea_leaves[persistent=true]
fill 380 231 261 380 231 262 minecraft:jungle_log
fill 381 231 261 381 232 261 minecraft:azalea_leaves[persistent=true]
fill 382 231 228 393 231 228 minecraft:lime_terracotta
fill 382 231 244 382 235 244 minecraft:dirt
fill 383 231 235 383 232 235 minecraft:jungle_log
fill 383 231 242 384 232 242 minecraft:dirt
fill 383 231 246 383 232 246 minecraft:green_concrete
fill 383 231 249 383 233 249 minecraft:jungle_leaves[persistent=true]
fill 383 231 250 384 232 250 minecraft:green_concrete
fill 383 231 254 384 231 254 minecraft:green_concrete
fill 383 231 263 383 232 263 minecraft:jungle_log
fill 384 231 235 384 234 237 minecraft:jungle_leaves[persistent=true]
fill 384 231 239 384 232 239 minecraft:azalea_leaves[persistent=true]
setblock 384 231 240 minecraft:jungle_leaves[persistent=true]
fill 384 231 243 384 232 243 minecraft:azalea_leaves[persistent=true]
fill 384 231 244 384 232 244 minecraft:green_concrete
fill 384 231 245 384 233 245 minecraft:azalea_leaves[persistent=true]
setblock 384 231 246 minecraft:green_terracotta
setblock 384 231 249 minecraft:lime_terracotta
setblock 384 231 252 minecraft:green_terracotta
fill 384 231 255 384 232 255 minecraft:jungle_leaves[persistent=true]
fill 384 231 256 384 231 257 minecraft:azalea_leaves[persistent=true]
fill 384 231 260 385 233 263 minecraft:oak_leaves[persistent=true]
fill 385 231 233 386 233 236 minecraft:jungle_leaves[persistent=true]
setblock 385 231 238 minecraft:azalea_leaves[persistent=true]
fill 385 231 239 386 231 239 minecraft:jungle_leaves[persistent=true]
setblock 385 231 241 minecraft:green_terracotta
setblock 385 231 242 minecraft:lime_terracotta
setblock 385 231 243 minecraft:green_terracotta
setblock 385 231 253 minecraft:green_terracotta
setblock 385 231 254 minecraft:lime_terracotta
fill 385 231 255 385 232 255 minecraft:green_terracotta
fill 386 231 237 386 232 237 minecraft:azalea_leaves[persistent=true]
setblock 386 231 238 minecraft:jungle_leaves[persistent=true]
fill 386 231 240 386 233 240 minecraft:green_terracotta
fill 386 231 260 388 232 260 minecraft:green_concrete
fill 386 231 262 386 231 263 minecraft:oak_leaves[persistent=true]
fill 387 231 234 387 234 236 minecraft:jungle_leaves[persistent=true]
setblock 387 231 237 minecraft:brown_terracotta
fill 387 231 259 388 231 259 minecraft:green_terracotta
setblock 387 231 262 minecraft:jungle_leaves[persistent=true]
fill 388 231 234 388 233 235 minecraft:jungle_leaves[persistent=true]
fill 388 231 237 388 232 237 minecraft:green_terracotta
fill 388 231 261 388 231 262 minecraft:azalea_leaves[persistent=true]
fill 389 231 260 389 232 260 minecraft:green_terracotta
fill 389 231 261 389 232 261 minecraft:azalea_leaves[persistent=true]
fill 390 231 249 391 232 249 minecraft:green_terracotta
setblock 390 231 251 minecraft:green_terracotta
fill 390 231 252 390 231 256 minecraft:pink_terracotta
setblock 390 231 261 minecraft:green_terracotta
fill 390 231 262 391 232 262 minecraft:green_concrete
fill 390 231 270 391 269 270 minecraft:lime_terracotta
fill 391 231 233 391 234 233 minecraft:brown_terracotta
fill 391 231 234 391 234 234 minecraft:green_terracotta
fill 391 231 250 391 231 251 minecraft:pink_terracotta
fill 391 231 257 391 231 258 minecraft:pink_terracotta
setblock 391 231 263 minecraft:green_concrete
setblock 392 231 234 minecraft:jungle_leaves[persistent=true]
fill 392 231 236 392 239 236 minecraft:green_terracotta
fill 392 231 249 393 231 249 minecraft:pink_terracotta
setblock 392 231 259 minecraft:pink_terracotta
fill 392 231 262 392 232 262 minecraft:azalea_leaves[persistent=true]
setblock 392 231 270 minecraft:green_terracotta
fill 393 231 232 393 234 232 minecraft:brown_terracotta
fill 393 231 233 394 234 233 minecraft:green_terracotta
fill 393 231 234 394 231 234 minecraft:azalea_leaves[persistent=true]
fill 393 231 235 393 231 236 minecraft:green_concrete
setblock 393 231 248 minecraft:green_terracotta
fill 393 231 260 394 231 260 minecraft:pink_terracotta
fill 393 231 262 393 232 263 minecraft:jungle_leaves[persistent=true]
fill 393 231 264 394 231 264 minecraft:green_terracotta
fill 393 231 270 402 231 270 minecraft:lime_terracotta
setblock 394 231 235 minecraft:azalea_leaves[persistent=true]
setblock 394 231 236 minecraft:green_terracotta
setblock 394 231 248 minecraft:pink_terracotta
setblock 394 231 262 minecraft:azalea_leaves[persistent=true]
setblock 394 231 265 minecraft:jungle_leaves[persistent=true]
fill 395 231 236 395 233 236 minecraft:jungle_leaves[persistent=true]
fill 395 231 261 396 231 261 minecraft:pink_terracotta
fill 395 231 262 395 232 262 minecraft:green_terracotta
fill 396 231 228 396 291 228 minecraft:lime_terracotta
fill 396 231 233 396 236 233 minecraft:green_terracotta
setblock 396 231 234 minecraft:jungle_leaves[persistent=true]
fill 396 231 235 396 232 236 minecraft:green_terracotta
fill 396 231 248 397 231 248 minecraft:pink_terracotta
setblock 397 231 228 minecraft:green_terracotta
fill 397 231 235 398 232 235 minecraft:jungle_leaves[persistent=true]
fill 397 231 236 400 231 236 minecraft:green_terracotta
fill 397 231 260 398 231 260 minecraft:pink_terracotta
fill 397 231 261 397 232 261 minecraft:green_terracotta
fill 397 231 264 397 232 265 minecraft:azalea_leaves[persistent=true]
fill 398 231 228 400 249 228 minecraft:lime_terracotta
fill 398 231 234 399 238 234 minecraft:green_terracotta
fill 398 231 249 399 231 249 minecraft:pink_terracotta
setblock 399 231 235 minecraft:green_terracotta
setblock 399 231 259 minecraft:pink_terracotta
setblock 399 231 264 minecraft:lime_terracotta
fill 399 231 267 399 237 267 minecraft:jungle_leaves[persistent=true]
fill 400 231 234 400 231 235 minecraft:jungle_leaves[persistent=true]
setblock 400 231 249 minecraft:green_terracotta
fill 400 231 250 400 231 251 minecraft:pink_terracotta
fill 400 231 257 400 231 258 minecraft:pink_terracotta
setblock 400 231 264 minecraft:green_terracotta
setblock 401 231 228 minecraft:green_terracotta
fill 401 231 232 401 234 232 minecraft:brown_terracotta
fill 401 231 233 401 234 233 minecraft:green_terracotta
fill 401 231 236 401 232 236 minecraft:green_concrete
fill 401 231 250 401 231 251 minecraft:green_terracotta
fill 401 231 252 401 231 255 minecraft:pink_terracotta
setblock 401 231 263 minecraft:green_terracotta
fill 402 231 228 407 246 228 minecraft:lime_terracotta
fill 402 231 234 403 234 234 minecraft:green_terracotta
fill 402 231 236 403 232 236 minecraft:jungle_leaves[persistent=true]
fill 402 231 251 402 232 252 minecraft:green_terracotta
setblock 402 231 263 minecraft:lime_terracotta
setblock 402 231 266 minecraft:iron_block
fill 403 231 230 403 240 230 minecraft:iron_block
fill 403 231 233 403 234 233 minecraft:brown_terracotta
fill 403 231 252 403 234 252 minecraft:green_terracotta
setblock 403 231 263 minecraft:green_terracotta
fill 403 231 264 403 232 264 minecraft:green_concrete
fill 403 231 270 403 232 270 minecraft:green_terracotta
fill 404 231 262 404 231 263 minecraft:azalea_leaves[persistent=true]
fill 404 231 270 407 231 270 minecraft:lime_terracotta
fill 405 231 262 405 233 262 minecraft:azalea_leaves[persistent=true]
fill 406 231 237 406 234 237 minecraft:green_terracotta
setblock 406 231 260 minecraft:green_terracotta
setblock 406 231 261 minecraft:green_concrete
fill 407 231 237 407 234 237 minecraft:brown_terracotta
setblock 407 231 259 minecraft:green_terracotta
fill 407 231 261 408 231 261 minecraft:jungle_leaves[persistent=true]
setblock 408 231 228 minecraft:green_terracotta
fill 408 231 238 408 231 239 minecraft:green_concrete
setblock 408 231 257 minecraft:lime_terracotta
fill 408 231 260 408 232 260 minecraft:green_concrete
setblock 408 231 262 minecraft:green_concrete
fill 408 231 263 410 231 266 minecraft:dirt
fill 408 231 269 408 234 270 minecraft:azalea_leaves[persistent=true]
fill 409 231 228 412 239 228 minecraft:lime_terracotta
fill 409 231 239 409 232 239 minecraft:jungle_leaves[persistent=true]
setblock 409 231 241 minecraft:green_terracotta
setblock 409 231 242 minecraft:lime_terracotta
fill 409 231 243 409 233 243 minecraft:green_terracotta
setblock 409 231 253 minecraft:green_terracotta
fill 409 231 254 410 231 254 minecraft:jungle_leaves[persistent=true]
setblock 409 231 255 minecraft:green_terracotta
setblock 409 231 259 minecraft:green_concrete
fill 409 231 260 409 231 261 minecraft:azalea_leaves[persistent=true]
fill 409 231 262 412 231 262 minecraft:dirt
fill 409 231 269 410 233 269 minecraft:azalea_leaves[persistent=true]
fill 410 231 240 411 232 240 minecraft:jungle_leaves[persistent=true]
fill 410 231 244 410 231 246 minecraft:green_terracotta
setblock 410 231 247 minecraft:lime_terracotta
fill 410 231 248 410 231 250 minecraft:green_terracotta
setblock 410 231 251 minecraft:lime_terracotta
setblock 410 231 252 minecraft:green_terracotta
fill 410 231 253 411 232 253 minecraft:green_concrete
setblock 410 231 255 minecraft:jungle_leaves[persistent=true]
fill 410 231 270 410 235 270 minecraft:azalea_leaves[persistent=true]
fill 411 231 231 417 253 233 minecraft:jungle_log
setblock 411 231 239 minecraft:jungle_leaves[persistent=true]
fill 411 231 243 411 232 245 minecraft:azalea_leaves[persistent=true]
setblock 411 231 247 minecraft:azalea_leaves[persistent=true]
fill 411 231 248 411 232 249 minecraft:green_concrete
setblock 411 231 254 minecraft:green_concrete
fill 411 231 263 411 231 264 minecraft:dirt
fill 411 231 265 411 232 269 minecraft:jungle_log
fill 411 231 270 415 231 270 minecraft:lime_terracotta
fill 412 231 230 416 279 230 minecraft:jungle_log
fill 412 231 234 416 279 234 minecraft:jungle_log
setblock 412 231 243 minecraft:azalea_leaves[persistent=true]
fill 412 231 244 412 231 245 minecraft:green_concrete
fill 412 231 249 412 232 249 minecraft:azalea_leaves[persistent=true]
setblock 412 231 263 minecraft:dirt
fill 412 231 264 416 279 268 minecraft:jungle_log
fill 413 231 229 415 279 229 minecraft:jungle_log
fill 413 231 235 416 232 235 minecraft:jungle_log
setblock 413 231 244 minecraft:green_concrete
fill 413 231 263 415 279 263 minecraft:jungle_log
fill 413 231 269 415 279 269 minecraft:jungle_log
fill 414 231 259 418 232 260 minecraft:oak_leaves[persistent=true]
fill 415 231 228 415 232 228 minecraft:jungle_log
fill 415 231 236 416 231 236 minecraft:jungle_log
fill 415 231 238 418 233 239 minecraft:oak_leaves[persistent=true]
fill 415 231 252 415 237 252 minecraft:jungle_leaves[persistent=true]
fill 415 231 258 417 234 258 minecraft:oak_leaves[persistent=true]
fill 415 231 261 418 233 261 minecraft:oak_leaves[persistent=true]
fill 415 231 262 415 232 262 minecraft:jungle_log
fill 416 231 237 418 234 237 minecraft:oak_leaves[persistent=true]
fill 416 231 240 418 233 240 minecraft:oak_leaves[persistent=true]
fill 416 231 257 416 236 257 minecraft:moss_block
fill 416 231 270 416 232 270 minecraft:green_terracotta
fill 417 231 264 417 232 267 minecraft:jungle_log
fill 417 231 270 418 256 270 minecraft:lime_terracotta
fill 418 231 232 418 231 233 minecraft:jungle_log
fill 418 231 234 418 243 236 minecraft:lime_terracotta
setblock 418 231 241 minecraft:green_terracotta
fill 418 231 242 418 308 242 minecraft:lime_terracotta
setblock 418 231 243 minecraft:green_terracotta
fill 418 231 244 418 231 255 minecraft:lime_terracotta
fill 418 231 256 418 231 257 minecraft:green_terracotta
fill 418 231 258 418 256 258 minecraft:lime_terracotta
fill 418 231 262 418 234 262 minecraft:oak_leaves[persistent=true]
setblock 418 231 263 minecraft:lime_terracotta
fill 418 231 264 418 232 264 minecraft:jungle_log
setblock 418 231 265 minecraft:green_terracotta
fill 418 231 266 418 269 266 minecraft:lime_terracotta
fill 418 231 268 418 231 269 minecraft:lime_terracotta
fill 376 232 228 376 243 229 minecraft:lime_terracotta
setblock 376 232 234 minecraft:jungle_log
fill 376 232 235 376 235 236 minecraft:lime_terracotta
fill 376 232 237 376 232 238 minecraft:green_terracotta
fill 376 232 239 376 256 244 minecraft:lime_terracotta
setblock 376 232 245 minecraft:green_terracotta
fill 376 232 246 376 249 251 minecraft:lime_terracotta
setblock 376 232 252 minecraft:moss_block
setblock 376 232 253 minecraft:green_terracotta
fill 376 232 254 376 236 260 minecraft:lime_terracotta
fill 376 232 264 376 308 264 minecraft:lime_terracotta
setblock 376 232 265 minecraft:green_terracotta
setblock 376 232 268 minecraft:green_terracotta
fill 376 232 269 376 282 270 minecraft:lime_terracotta
fill 377 232 270 384 239 270 minecraft:lime_terracotta
fill 378 232 234 383 232 234 minecraft:jungle_log
fill 378 232 258 378 233 259 minecraft:azalea_leaves[persistent=true]
fill 379 232 257 379 234 257 minecraft:azalea_leaves[persistent=true]
fill 379 232 261 380 234 261 minecraft:azalea_leaves[persistent=true]
fill 380 232 228 381 252 228 minecraft:lime_terracotta
setblock 380 232 262 minecraft:jungle_log
setblock 382 232 228 minecraft:green_terracotta
fill 382 232 243 383 235 243 minecraft:dirt
fill 382 232 245 382 235 246 minecraft:dirt
setblock 382 232 249 minecraft:jungle_leaves[persistent=true]
fill 382 232 258 382 234 259 minecraft:azalea_leaves[persistent=true]
fill 383 232 228 393 239 228 minecraft:lime_terracotta
setblock 383 232 236 minecraft:jungle_leaves[persistent=true]
fill 383 232 244 383 235 244 minecraft:dirt
setblock 383 232 245 minecraft:azalea_leaves[persistent=true]
fill 383 232 247 383 235 247 minecraft:dirt
fill 383 232 248 384 233 248 minecraft:jungle_leaves[persistent=true]
setblock 383 232 255 minecraft:jungle_leaves[persistent=true]
fill 383 232 261 383 233 262 minecraft:oak_leaves[persistent=true]
fill 384 232 234 384 233 234 minecraft:jungle_leaves[persistent=true]
fill 384 232 240 385 233 240 minecraft:azalea_leaves[persistent=true]
fill 384 232 241 384 233 241 minecraft:jungle_leaves[persistent=true]
fill 384 232 246 384 234 246 minecraft:azalea_leaves[persistent=true]
fill 384 232 247 384 234 247 minecraft:green_concrete
fill 384 232 249 384 233 249 minecraft:jungle_leaves[persistent=true]
setblock 384 232 252 minecraft:lime_terracotta
fill 384 232 253 385 232 253 minecraft:green_concrete
fill 384 232 254 384 233 254 minecraft:jungle_leaves[persistent=true]
fill 384 232 256 385 232 256 minecraft:azalea_leaves[persistent=true]
fill 385 232 237 385 235 237 minecraft:jungle_leaves[persistent=true]
setblock 385 232 238 minecraft:green_concrete
setblock 385 232 239 minecraft:azalea_leaves[persistent=true]
setblock 385 232 241 minecraft:lime_terracotta
fill 385 232 242 385 232 243 minecraft:azalea_leaves[persistent=true]
fill 385 232 244 385 232 245 minecraft:green_concrete
fill 385 232 249 385 233 249 minecraft:green_terracotta
fill 385 232 250 385 233 250 minecraft:green_concrete
fill 385 232 251 385 237 251 minecraft:green_terracotta
fill 385 232 254 385 234 254 minecraft:green_terracotta
fill 385 232 259 385 233 259 minecraft:oak_leaves[persistent=true]
setblock 385 232 270 minecraft:green_terracotta
setblock 386 232 238 minecraft:azalea_leaves[persistent=true]
fill 386 232 239 387 232 239 minecraft:jungle_leaves[persistent=true]
fill 386 232 245 386 233 245 minecraft:green_concrete
setblock 386 232 246 minecraft:green_terracotta
fill 386 232 248 386 233 248 minecraft:green_terracotta
fill 386 232 249 386 233 249 minecraft:bone_block
setblock 386 232 250 minecraft:green_terracotta
fill 386 232 259 389 233 259 minecraft:green_concrete
fill 386 232 261 387 232 262 minecraft:oak_leaves[persistent=true]
fill 386 232 263 386 233 263 minecraft:bone_block
fill 386 232 270 386 242 270 minecraft:lime_terracotta
fill 387 232 233 387 234 233 minecraft:jungle_leaves[persistent=true]
fill 387 232 237 387 233 237 minecraft:azalea_leaves[persistent=true]
fill 387 232 263 387 233 263 minecraft:oak_leaves[persistent=true]
setblock 387 232 270 minecraft:green_terracotta
setblock 388 232 261 minecraft:azalea_leaves[persistent=true]
fill 388 232 262 389 232 262 minecraft:jungle_leaves[persistent=true]
fill 388 232 270 389 244 270 minecraft:lime_terracotta
fill 389 232 248 389 237 248 minecraft:green_terracotta
fill 389 232 249 389 233 249 minecraft:bone_block
fill 389 232 263 389 233 263 minecraft:bone_block
fill 390 232 251 390 233 256 minecraft:red_terracotta
fill 390 232 261 390 233 261 minecraft:azalea_leaves[persistent=true]
fill 391 232 238 401 232 238 minecraft:green_terracotta
setblock 391 232 250 minecraft:red_terracotta
fill 391 232 257 391 233 258 minecraft:red_terracotta
setblock 391 232 263 minecraft:lime_terracotta
fill 392 232 234 392 236 235 minecraft:green_terracotta
fill 392 232 237 392 240 237 minecraft:green_terracotta
setblock 392 232 248 minecraft:green_terracotta
fill 392 232 249 392 233 249 minecraft:bone_block
fill 392 232 259 392 233 259 minecraft:red_terracotta
setblock 392 232 261 minecraft:green_terracotta
fill 392 232 263 392 233 263 minecraft:bone_block
fill 392 232 270 392 244 270 minecraft:lime_terracotta
fill 393 232 234 397 237 234 minecraft:green_terracotta
fill 393 232 235 395 232 235 minecraft:jungle_leaves[persistent=true]
fill 393 232 236 393 232 237 minecraft:green_concrete
setblock 393 232 247 minecraft:green_terracotta
setblock 393 232 248 minecraft:red_terracotta
fill 393 232 260 394 232 260 minecraft:red_terracotta
fill 393 232 261 393 233 261 minecraft:green_concrete
setblock 393 232 264 minecraft:green_terracotta
setblock 393 232 270 minecraft:green_terracotta
fill 394 232 236 394 234 237 minecraft:jungle_leaves[persistent=true]
fill 394 232 247 397 232 247 minecraft:red_terracotta
setblock 394 232 261 minecraft:green_terracotta
fill 394 232 262 394 233 264 minecraft:jungle_leaves[persistent=true]
fill 394 232 270 402 232 270 minecraft:lime_terracotta
fill 395 232 237 401 232 237 minecraft:green_terracotta
fill 395 232 249 395 233 249 minecraft:bone_block
fill 395 232 261 396 232 261 minecraft:red_terracotta
fill 395 232 263 395 233 263 minecraft:bone_block
fill 395 232 264 396 232 264 minecraft:jungle_leaves[persistent=true]
fill 396 232 263 397 232 263 minecraft:green_terracotta
setblock 396 232 265 minecraft:jungle_leaves[persistent=true]
fill 397 232 228 397 249 228 minecraft:lime_terracotta
fill 397 232 236 397 233 236 minecraft:green_terracotta
fill 397 232 260 398 232 260 minecraft:red_terracotta
fill 398 232 236 399 233 236 minecraft:jungle_leaves[persistent=true]
fill 398 232 248 399 232 248 minecraft:red_terracotta
fill 398 232 249 398 233 249 minecraft:bone_block
fill 398 232 263 398 233 263 minecraft:bone_block
fill 398 232 264 398 233 264 minecraft:azalea_leaves[persistent=true]
fill 399 232 235 400 232 235 minecraft:jungle_leaves[persistent=true]
fill 399 232 259 399 233 259 minecraft:red_terracotta
fill 399 232 264 399 234 264 minecraft:green_terracotta
setblock 400 232 234 minecraft:green_concrete
setblock 400 232 236 minecraft:green_concrete
fill 400 232 249 400 232 250 minecraft:red_terracotta
fill 400 232 258 400 233 258 minecraft:red_terracotta
setblock 400 232 264 minecraft:lime_terracotta
fill 401 232 228 401 291 228 minecraft:lime_terracotta
fill 401 232 234 401 237 234 minecraft:green_terracotta
fill 401 232 248 401 233 248 minecraft:green_terracotta
fill 401 232 249 401 233 249 minecraft:bone_block
setblock 401 232 250 minecraft:green_terracotta
fill 401 232 251 401 232 255 minecraft:red_terracotta
fill 401 232 257 401 233 257 minecraft:red_terracotta
fill 401 232 263 401 233 263 minecraft:bone_block
setblock 401 232 264 minecraft:green_terracotta
fill 402 232 235 402 238 235 minecraft:green_terracotta
fill 402 232 237 403 232 237 minecraft:jungle_leaves[persistent=true]
fill 402 232 238 402 233 238 minecraft:azalea_leaves[persistent=true]
fill 402 232 249 403 234 249 minecraft:green_terracotta
fill 402 232 263 402 232 264 minecraft:green_concrete
setblock 403 232 238 minecraft:green_terracotta
setblock 403 232 263 minecraft:green_concrete
fill 404 232 248 404 238 248 minecraft:green_terracotta
fill 404 232 249 404 233 249 minecraft:bone_block
fill 404 232 261 405 233 261 minecraft:azalea_leaves[persistent=true]
setblock 404 232 262 minecraft:green_concrete
fill 404 232 263 404 233 263 minecraft:bone_block
fill 404 232 270 405 234 270 minecraft:lime_terracotta
setblock 405 232 260 minecraft:green_terracotta
setblock 405 232 263 minecraft:azalea_leaves[persistent=true]
fill 406 232 254 406 232 255 minecraft:green_terracotta
fill 406 232 256 409 238 256 minecraft:bone_block
fill 406 232 260 407 232 261 minecraft:jungle_leaves[persistent=true]
fill 406 232 263 408 233 263 minecraft:bone_block
fill 406 232 265 408 233 265 minecraft:bone_block
setblock 406 232 270 minecraft:green_terracotta
fill 407 232 239 408 232 239 minecraft:green_concrete
setblock 407 232 254 minecraft:green_terracotta
fill 407 232 255 410 238 255 minecraft:bone_block
fill 407 232 257 409 239 257 minecraft:bone_block
setblock 407 232 259 minecraft:lime_terracotta
fill 407 232 264 407 233 264 minecraft:bone_block
fill 407 232 269 407 234 270 minecraft:azalea_leaves[persistent=true]
fill 408 232 228 408 268 228 minecraft:lime_terracotta
setblock 408 232 240 minecraft:lime_terracotta
fill 408 232 254 409 238 254 minecraft:bone_block
fill 408 232 258 408 232 259 minecraft:green_concrete
fill 409 232 240 409 233 240 minecraft:jungle_leaves[persistent=true]
setblock 409 232 241 minecraft:lime_terracotta
fill 409 232 242 409 234 242 minecraft:green_terracotta
setblock 409 232 253 minecraft:jungle_leaves[persistent=true]
setblock 409 232 258 minecraft:green_concrete
fill 409 232 259 409 232 260 minecraft:azalea_leaves[persistent=true]
fill 410 232 241 410 233 242 minecraft:jungle_leaves[persistent=true]
fill 410 232 244 410 233 246 minecraft:azalea_leaves[persistent=true]
fill 410 232 247 411 232 247 minecraft:green_concrete
setblock 410 232 248 minecraft:green_terracotta
fill 410 232 249 410 233 249 minecraft:green_concrete
setblock 410 232 250 minecraft:lime_terracotta
setblock 410 232 251 minecraft:green_terracotta
fill 410 232 252 410 233 252 minecraft:green_concrete
fill 410 232 257 413 232 261 minecraft:dirt
fill 411 232 241 411 233 241 minecraft:jungle_leaves[persistent=true]
setblock 411 232 246 minecraft:azalea_leaves[persistent=true]
fill 411 232 250 412 232 250 minecraft:azalea_leaves[persistent=true]
fill 411 232 270 414 232 270 minecraft:lime_terracotta
fill 412 232 245 412 232 246 minecraft:green_concrete
setblock 412 232 247 minecraft:azalea_leaves[persistent=true]
fill 414 232 257 414 233 257 minecraft:dirt
fill 414 232 258 414 233 258 minecraft:oak_leaves[persistent=true]
fill 414 232 261 414 233 261 minecraft:dirt
setblock 415 232 236 minecraft:jungle_log
fill 415 232 237 415 234 237 minecraft:oak_leaves[persistent=true]
fill 415 232 257 415 233 257 minecraft:oak_leaves[persistent=true]
setblock 415 232 270 minecraft:green_terracotta
fill 416 232 228 417 233 228 minecraft:azalea_leaves[persistent=true]
fill 416 232 236 416 233 236 minecraft:oak_leaves[persistent=true]
fill 416 232 262 416 234 262 minecraft:oak_leaves[persistent=true]
fill 417 232 235 417 237 235 minecraft:moss_block
setblock 417 232 263 minecraft:jungle_log
fill 418 232 228 418 308 228 minecraft:lime_terracotta
setblock 418 232 232 minecraft:jungle_log
fill 418 232 233 418 233 233 minecraft:jungle_leaves[persistent=true]
fill 418 232 241 418 234 241 minecraft:lime_terracotta
fill 418 232 243 418 234 254 minecraft:lime_terracotta
setblock 418 232 255 minecraft:green_terracotta
fill 418 232 256 418 242 257 minecraft:lime_terracotta
fill 418 232 263 418 234 263 minecraft:oak_leaves[persistent=true]
fill 418 232 265 418 268 265 minecraft:lime_terracotta
fill 418 232 268 418 295 268 minecraft:lime_terracotta
setblock 418 232 269 minecraft:green_terracotta
fill 376 233 233 376 268 234 minecraft:lime_terracotta
setblock 376 233 237 minecraft:moss_block
fill 376 233 238 376 256 238 minecraft:lime_terracotta
fill 376 233 245 376 247 245 minecraft:lime_terracotta
fill 376 233 252 376 251 253 minecraft:lime_terracotta
fill 376 233 265 376 269 268 minecraft:lime_terracotta
fill 377 233 233 383 279 233 minecraft:jungle_log
fill 377 233 266 383 279 267 minecraft:jungle_log
fill 378 233 234 382 279 234 minecraft:jungle_log
setblock 378 233 261 minecraft:azalea_leaves[persistent=true]
fill 378 233 264 382 279 264 minecraft:jungle_log
setblock 379 233 239 minecraft:light[level=15]
setblock 379 233 247 minecraft:light[level=15]
setblock 379 233 255 minecraft:light[level=15]
fill 381 233 244 381 235 245 minecraft:dirt
fill 382 233 228 382 242 228 minecraft:lime_terracotta
fill 382 233 242 383 235 242 minecraft:dirt
fill 382 233 247 382 235 247 minecraft:dirt
fill 383 233 241 383 235 241 minecraft:dirt
fill 383 233 245 383 235 246 minecraft:dirt
setblock 383 233 259 minecraft:azalea_leaves[persistent=true]
fill 384 233 238 385 233 238 minecraft:jungle_leaves[persistent=true]
fill 384 233 242 384 234 242 minecraft:jungle_leaves[persistent=true]
fill 384 233 243 384 235 243 minecraft:dirt
fill 384 233 244 385 234 244 minecraft:green_terracotta
setblock 384 233 250 minecraft:green_terracotta
setblock 384 233 251 minecraft:lime_terracotta
fill 384 233 252 384 234 252 minecraft:green_terracotta
fill 384 233 253 385 234 253 minecraft:jungle_leaves[persistent=true]
fill 385 233 241 385 233 242 minecraft:azalea_leaves[persistent=true]
setblock 385 233 243 minecraft:green_terracotta
fill 385 233 245 385 233 246 minecraft:azalea_leaves[persistent=true]
setblock 385 233 247 minecraft:green_concrete
setblock 385 233 248 minecraft:jungle_leaves[persistent=true]
setblock 385 233 252 minecraft:green_concrete
fill 385 233 255 385 233 256 minecraft:azalea_leaves[persistent=true]
fill 385 233 270 385 242 270 minecraft:lime_terracotta
fill 386 233 237 386 234 237 minecraft:jungle_leaves[persistent=true]
setblock 386 233 238 minecraft:green_concrete
fill 386 233 239 386 235 239 minecraft:brown_terracotta
fill 386 233 242 386 236 242 minecraft:azalea_leaves[persistent=true]
setblock 386 233 244 minecraft:green_concrete
fill 386 233 246 386 235 246 minecraft:azalea_leaves[persistent=true]
fill 386 233 250 386 235 250 minecraft:bone_block
setblock 386 233 257 minecraft:lime_terracotta
fill 386 233 258 386 235 258 minecraft:green_concrete
fill 386 233 260 387 233 261 minecraft:oak_leaves[persistent=true]
fill 386 233 262 386 235 262 minecraft:bone_block
setblock 387 233 231 minecraft:light[level=15]
setblock 387 233 238 minecraft:azalea_leaves[persistent=true]
fill 387 233 239 388 233 240 minecraft:jungle_leaves[persistent=true]
fill 387 233 243 387 239 244 minecraft:green_terracotta
fill 387 233 245 387 234 245 minecraft:green_concrete
setblock 387 233 258 minecraft:lime_terracotta
fill 387 233 262 387 234 262 minecraft:oak_leaves[persistent=true]
fill 387 233 270 387 243 270 minecraft:lime_terracotta
fill 388 233 237 388 234 237 minecraft:azalea_leaves[persistent=true]
fill 388 233 241 388 240 241 minecraft:green_terracotta
fill 388 233 258 390 233 258 minecraft:green_concrete
fill 388 233 260 388 235 260 minecraft:green_terracotta
fill 389 233 250 389 235 250 minecraft:bone_block
fill 389 233 251 389 234 252 minecraft:green_terracotta
fill 389 233 260 389 234 260 minecraft:green_concrete
setblock 389 233 261 minecraft:jungle_leaves[persistent=true]
fill 389 233 262 389 235 262 minecraft:bone_block
fill 390 233 239 401 238 239 minecraft:green_terracotta
setblock 390 233 249 minecraft:green_terracotta
setblock 390 233 250 minecraft:red_terracotta
fill 390 233 260 391 233 260 minecraft:azalea_leaves[persistent=true]
fill 390 233 262 391 235 262 minecraft:green_terracotta
fill 391 233 238 392 240 238 minecraft:green_terracotta
setblock 391 233 249 minecraft:red_terracotta
fill 391 233 261 392 233 261 minecraft:azalea_leaves[persistent=true]
fill 391 233 263 391 234 263 minecraft:green_terracotta
setblock 392 233 248 minecraft:red_terracotta
fill 392 233 250 392 235 250 minecraft:bone_block
fill 392 233 262 392 235 262 minecraft:bone_block
fill 393 233 235 394 238 235 minecraft:green_terracotta
setblock 393 233 236 minecraft:green_concrete
fill 393 233 237 393 236 238 minecraft:jungle_leaves[persistent=true]
setblock 393 233 247 minecraft:red_terracotta
fill 393 233 260 393 234 260 minecraft:green_concrete
fill 393 233 262 393 235 262 minecraft:jungle_leaves[persistent=true]
fill 393 233 263 393 237 263 minecraft:green_terracotta
setblock 393 233 264 minecraft:lime_terracotta
fill 393 233 270 397 235 270 minecraft:lime_terracotta
setblock 394 233 238 minecraft:green_terracotta
fill 394 233 246 397 233 246 minecraft:red_terracotta
setblock 394 233 260 minecraft:red_terracotta
fill 394 233 261 394 234 261 minecraft:jungle_leaves[persistent=true]
setblock 395 233 231 minecraft:light[level=15]
fill 395 233 235 396 233 235 minecraft:azalea_leaves[persistent=true]
fill 395 233 237 395 233 238 minecraft:azalea_leaves[persistent=true]
setblock 395 233 247 minecraft:light[level=15]
fill 395 233 250 395 235 250 minecraft:bone_block
setblock 395 233 255 minecraft:light[level=15]
setblock 395 233 261 minecraft:azalea_leaves[persistent=true]
fill 395 233 262 395 235 262 minecraft:bone_block
fill 395 233 264 395 234 264 minecraft:green_terracotta
fill 396 233 236 396 234 236 minecraft:azalea_leaves[persistent=true]
fill 396 233 237 398 234 238 minecraft:green_terracotta
fill 396 233 261 397 233 261 minecraft:red_terracotta
fill 396 233 263 396 233 264 minecraft:jungle_leaves[persistent=true]
fill 397 233 235 397 239 235 minecraft:green_terracotta
fill 397 233 262 397 237 263 minecraft:green_terracotta
setblock 397 233 264 minecraft:lime_terracotta
fill 398 233 235 399 233 235 minecraft:jungle_leaves[persistent=true]
fill 398 233 247 399 233 247 minecraft:red_terracotta
fill 398 233 250 398 235 250 minecraft:bone_block
setblock 398 233 260 minecraft:red_terracotta
fill 398 233 262 398 235 262 minecraft:bone_block
setblock 398 233 270 minecraft:green_concrete
fill 399 233 237 399 235 237 minecraft:jungle_leaves[persistent=true]
fill 399 233 238 399 241 238 minecraft:green_terracotta
fill 399 233 262 399 239 262 minecraft:green_terracotta
fill 399 233 263 399 234 263 minecraft:azalea_leaves[persistent=true]
fill 399 233 270 403 235 270 minecraft:lime_terracotta
fill 400 233 234 400 237 234 minecraft:green_terracotta
setblock 400 233 235 minecraft:green_concrete
fill 400 233 236 403 238 236 minecraft:green_terracotta
fill 400 233 237 400 234 238 minecraft:green_concrete
setblock 400 233 248 minecraft:red_terracotta
fill 400 233 264 400 235 264 minecraft:green_terracotta
fill 401 233 235 401 238 235 minecraft:green_terracotta
setblock 401 233 237 minecraft:green_concrete
fill 401 233 238 401 241 238 minecraft:green_terracotta
fill 401 233 250 401 235 250 minecraft:bone_block
setblock 401 233 251 minecraft:red_terracotta
fill 401 233 262 401 235 262 minecraft:bone_block
setblock 401 233 264 minecraft:lime_terracotta
setblock 402 233 237 minecraft:azalea_leaves[persistent=true]
fill 402 233 239 402 234 239 minecraft:azalea_leaves[persistent=true]
setblock 402 233 251 minecraft:green_terracotta
fill 402 233 252 402 233 255 minecraft:red_terracotta
setblock 402 233 256 minecraft:green_terracotta
setblock 402 233 263 minecraft:green_concrete
setblock 403 233 231 minecraft:light[level=15]
fill 403 233 237 403 233 239 minecraft:jungle_leaves[persistent=true]
fill 403 233 250 403 235 250 minecraft:green_terracotta
fill 403 233 253 404 234 253 minecraft:green_terracotta
fill 403 233 260 403 233 261 minecraft:azalea_leaves[persistent=true]
fill 403 233 262 403 234 262 minecraft:green_concrete
fill 403 233 263 403 234 263 minecraft:green_terracotta
fill 404 233 239 404 240 239 minecraft:green_terracotta
fill 404 233 250 404 235 250 minecraft:bone_block
fill 404 233 260 405 234 260 minecraft:azalea_leaves[persistent=true]
fill 404 233 262 404 235 262 minecraft:bone_block
fill 405 233 250 405 239 250 minecraft:green_terracotta
fill 405 233 256 405 237 257 minecraft:bone_block
fill 406 233 239 406 233 240 minecraft:green_concrete
fill 406 233 254 406 238 255 minecraft:bone_block
fill 406 233 257 406 238 258 minecraft:bone_block
fill 406 233 260 406 233 261 minecraft:jungle_leaves[persistent=true]
setblock 406 233 270 minecraft:azalea_leaves[persistent=true]
setblock 407 233 239 minecraft:green_concrete
fill 407 233 250 407 239 251 minecraft:green_terracotta
fill 407 233 252 408 233 252 minecraft:jungle_leaves[persistent=true]
fill 407 233 253 407 237 254 minecraft:bone_block
fill 407 233 258 409 238 258 minecraft:bone_block
setblock 407 233 259 minecraft:green_terracotta
fill 408 233 239 408 235 239 minecraft:brown_terracotta
fill 408 233 240 408 233 241 minecraft:jungle_leaves[persistent=true]
setblock 408 233 251 minecraft:green_terracotta
fill 408 233 253 410 236 253 minecraft:bone_block
setblock 408 233 259 minecraft:green_concrete
fill 408 233 264 409 234 264 minecraft:bone_block
fill 409 233 241 409 234 241 minecraft:jungle_leaves[persistent=true]
fill 409 233 244 409 235 244 minecraft:azalea_leaves[persistent=true]
fill 409 233 245 409 234 245 minecraft:green_concrete
fill 409 233 246 409 234 246 minecraft:azalea_leaves[persistent=true]
fill 409 233 247 410 233 247 minecraft:green_concrete
setblock 409 233 248 minecraft:green_terracotta
fill 409 233 249 409 233 252 minecraft:green_concrete
fill 409 233 259 410 233 259 minecraft:azalea_leaves[persistent=true]
setblock 410 233 243 minecraft:azalea_leaves[persistent=true]
setblock 410 233 248 minecraft:green_concrete
fill 410 233 250 410 235 250 minecraft:green_terracotta
fill 410 233 251 411 234 251 minecraft:azalea_leaves[persistent=true]
fill 410 233 254 410 237 254 minecraft:bone_block
fill 410 233 256 410 238 257 minecraft:bone_block
fill 410 233 258 413 233 258 minecraft:dirt
fill 410 233 260 413 233 261 minecraft:dirt
setblock 411 233 239 minecraft:light[level=15]
fill 411 233 242 411 234 242 minecraft:jungle_leaves[persistent=true]
fill 411 233 245 411 235 245 minecraft:azalea_leaves[persistent=true]
fill 411 233 246 412 233 246 minecraft:green_concrete
setblock 411 233 247 minecraft:light[level=15]
setblock 411 233 250 minecraft:azalea_leaves[persistent=true]
fill 411 233 255 411 237 256 minecraft:bone_block
fill 411 233 257 413 233 257 minecraft:dirt
fill 411 233 259 413 233 259 minecraft:dirt
setblock 411 233 263 minecraft:light[level=15]
fill 411 233 265 411 279 267 minecraft:jungle_log
fill 411 233 270 411 234 270 minecraft:azalea_leaves[persistent=true]
fill 412 233 270 416 253 270 minecraft:lime_terracotta
fill 413 233 235 415 279 235 minecraft:jungle_log
fill 414 233 259 418 233 259 minecraft:oak_leaves[persistent=true]
setblock 414 233 260 minecraft:dirt
fill 415 233 228 415 243 228 minecraft:lime_terracotta
setblock 415 233 236 minecraft:oak_leaves[persistent=true]
fill 415 233 260 418 234 260 minecraft:oak_leaves[persistent=true]
fill 417 233 241 417 234 241 minecraft:oak_leaves[persistent=true]
setblock 417 233 262 minecraft:oak_leaves[persistent=true]
fill 417 233 265 417 279 267 minecraft:jungle_log
setblock 418 233 232 minecraft:lime_terracotta
fill 418 233 255 418 308 255 minecraft:lime_terracotta
setblock 418 233 264 minecraft:oak_leaves[persistent=true]
fill 418 233 269 418 252 269 minecraft:lime_terracotta
fill 376 234 237 376 258 237 minecraft:lime_terracotta
setblock 379 234 238 minecraft:light[level=12]
setblock 379 234 245 minecraft:light[level=12]
setblock 379 234 252 minecraft:light[level=12]
fill 379 234 260 381 234 260 minecraft:azalea_leaves[persistent=true]
setblock 380 234 257 minecraft:azalea_leaves[persistent=true]
fill 381 234 243 381 235 243 minecraft:dirt
fill 381 234 246 381 235 246 minecraft:dirt
fill 382 234 241 382 235 241 minecraft:dirt
fill 382 234 248 383 235 248 minecraft:dirt
fill 384 234 240 384 235 241 minecraft:dirt
fill 384 234 245 386 234 245 minecraft:green_terracotta
fill 384 234 248 386 234 248 minecraft:green_concrete
setblock 384 234 249 minecraft:green_terracotta
setblock 384 234 250 minecraft:lime_terracotta
fill 384 234 251 384 235 251 minecraft:green_terracotta
fill 384 234 260 385 234 262 minecraft:oak_leaves[persistent=true]
fill 385 234 234 386 234 236 minecraft:jungle_leaves[persistent=true]
fill 385 234 238 386 234 238 minecraft:jungle_leaves[persistent=true]
fill 385 234 240 385 234 241 minecraft:azalea_leaves[persistent=true]
setblock 385 234 242 minecraft:green_terracotta
setblock 385 234 243 minecraft:lime_terracotta
fill 385 234 246 385 235 247 minecraft:azalea_leaves[persistent=true]
setblock 385 234 249 minecraft:green_concrete
fill 385 234 250 385 238 250 minecraft:green_terracotta
fill 385 234 252 385 235 252 minecraft:jungle_leaves[persistent=true]
setblock 385 234 255 minecraft:lime_terracotta
fill 385 234 263 386 234 263 minecraft:oak_leaves[persistent=true]
setblock 386 234 231 minecraft:light[level=12]
setblock 386 234 240 minecraft:lime_terracotta
fill 386 234 244 386 237 244 minecraft:green_terracotta
fill 386 234 247 386 236 247 minecraft:azalea_leaves[persistent=true]
fill 386 234 249 386 239 249 minecraft:green_terracotta
fill 386 234 255 386 237 255 minecraft:bone_block
fill 386 234 257 386 237 257 minecraft:bone_block
setblock 386 234 259 minecraft:light[level=12]
fill 386 234 260 386 234 261 minecraft:oak_leaves[persistent=true]
setblock 386 234 266 minecraft:light[level=12]
fill 387 234 237 387 234 238 minecraft:brown_terracotta
fill 387 234 239 388 234 239 minecraft:green_concrete
fill 387 234 240 387 238 240 minecraft:green_terracotta
fill 387 234 256 387 235 256 minecraft:azalea_leaves[persistent=true]
setblock 387 234 257 minecraft:green_terracotta
fill 387 234 258 388 234 258 minecraft:green_concrete
fill 387 234 259 389 234 259 minecraft:green_terracotta
setblock 387 234 261 minecraft:oak_leaves[persistent=true]
setblock 388 234 235 minecraft:jungle_leaves[persistent=true]
setblock 388 234 238 minecraft:azalea_leaves[persistent=true]
setblock 388 234 240 minecraft:jungle_leaves[persistent=true]
fill 388 234 257 388 235 257 minecraft:green_concrete
fill 389 234 237 389 235 237 minecraft:azalea_leaves[persistent=true]
fill 389 234 249 389 236 249 minecraft:green_terracotta
fill 389 234 254 389 235 254 minecraft:green_terracotta
fill 389 234 255 389 237 255 minecraft:bone_block
fill 389 234 257 389 237 257 minecraft:bone_block
fill 389 234 258 389 236 258 minecraft:green_terracotta
setblock 389 234 261 minecraft:green_terracotta
fill 390 234 248 390 235 248 minecraft:green_terracotta
fill 390 234 249 390 234 256 minecraft:pink_terracotta
setblock 390 234 258 minecraft:green_concrete
fill 390 234 260 390 237 260 minecraft:green_terracotta
fill 390 234 261 391 234 261 minecraft:jungle_leaves[persistent=true]
fill 391 234 246 392 234 246 minecraft:green_terracotta
setblock 391 234 248 minecraft:pink_terracotta
fill 391 234 257 391 234 258 minecraft:pink_terracotta
fill 391 234 260 392 234 260 minecraft:azalea_leaves[persistent=true]
setblock 392 234 247 minecraft:pink_terracotta
fill 392 234 255 392 237 255 minecraft:bone_block
fill 392 234 257 392 237 257 minecraft:bone_block
setblock 392 234 259 minecraft:pink_terracotta
setblock 392 234 261 minecraft:azalea_leaves[persistent=true]
fill 392 234 263 392 236 263 minecraft:green_terracotta
setblock 393 234 231 minecraft:light[level=12]
fill 393 234 236 393 239 236 minecraft:green_terracotta
setblock 393 234 246 minecraft:pink_terracotta
setblock 393 234 252 minecraft:light[level=12]
fill 393 234 259 393 235 259 minecraft:green_concrete
fill 393 234 261 393 239 261 minecraft:green_terracotta
setblock 393 234 264 minecraft:green_terracotta
setblock 393 234 266 minecraft:light[level=12]
fill 394 234 238 394 235 238 minecraft:green_concrete
fill 394 234 245 397 234 245 minecraft:pink_terracotta
fill 394 234 260 395 234 260 minecraft:jungle_leaves[persistent=true]
fill 394 234 262 394 234 263 minecraft:jungle_leaves[persistent=true]
setblock 394 234 264 minecraft:lime_terracotta
fill 395 234 235 395 239 236 minecraft:green_terracotta
fill 395 234 237 395 235 237 minecraft:jungle_leaves[persistent=true]
setblock 395 234 238 minecraft:azalea_leaves[persistent=true]
fill 395 234 255 395 237 255 minecraft:bone_block
fill 395 234 257 395 237 257 minecraft:bone_block
setblock 395 234 261 minecraft:jungle_leaves[persistent=true]
fill 395 234 263 395 238 263 minecraft:green_terracotta
fill 396 234 235 396 239 235 minecraft:green_terracotta
fill 396 234 261 397 234 261 minecraft:pink_terracotta
fill 396 234 262 396 234 263 minecraft:jungle_leaves[persistent=true]
fill 396 234 264 397 235 264 minecraft:green_terracotta
fill 397 234 236 398 234 236 minecraft:jungle_leaves[persistent=true]
fill 398 234 235 398 239 235 minecraft:green_terracotta
fill 398 234 246 399 234 246 minecraft:pink_terracotta
fill 398 234 255 398 237 255 minecraft:bone_block
fill 398 234 257 398 237 257 minecraft:bone_block
fill 398 234 260 399 234 260 minecraft:pink_terracotta
fill 398 234 263 398 238 263 minecraft:green_terracotta
setblock 398 234 264 minecraft:lime_terracotta
fill 398 234 270 398 271 270 minecraft:lime_terracotta
fill 399 234 235 399 234 236 minecraft:green_concrete
setblock 400 234 231 minecraft:light[level=12]
fill 400 234 235 400 239 235 minecraft:green_terracotta
fill 400 234 246 401 234 246 minecraft:green_terracotta
setblock 400 234 247 minecraft:pink_terracotta
setblock 400 234 252 minecraft:light[level=12]
setblock 400 234 259 minecraft:pink_terracotta
fill 400 234 262 400 235 262 minecraft:green_concrete
setblock 400 234 266 minecraft:light[level=12]
fill 401 234 237 403 239 237 minecraft:green_terracotta
fill 401 234 248 401 234 249 minecraft:pink_terracotta
fill 401 234 255 401 237 255 minecraft:bone_block
fill 401 234 257 401 237 257 minecraft:bone_block
setblock 401 234 258 minecraft:pink_terracotta
fill 401 234 259 401 236 259 minecraft:green_terracotta
setblock 401 234 263 minecraft:green_concrete
setblock 401 234 264 minecraft:green_terracotta
fill 402 234 238 402 240 238 minecraft:green_terracotta
fill 402 234 250 402 234 256 minecraft:pink_terracotta
fill 402 234 257 403 235 257 minecraft:green_terracotta
setblock 402 234 263 minecraft:green_terracotta
fill 403 234 238 403 234 239 minecraft:jungle_leaves[persistent=true]
setblock 403 234 260 minecraft:azalea_leaves[persistent=true]
fill 403 234 261 404 234 261 minecraft:green_concrete
fill 404 234 249 404 237 249 minecraft:green_terracotta
fill 404 234 255 405 237 255 minecraft:bone_block
fill 404 234 257 404 237 257 minecraft:bone_block
fill 405 234 258 405 237 258 minecraft:bone_block
setblock 405 234 261 minecraft:azalea_leaves[persistent=true]
fill 406 234 239 407 235 239 minecraft:green_terracotta
setblock 406 234 240 minecraft:green_concrete
fill 406 234 253 406 237 253 minecraft:bone_block
fill 406 234 259 409 237 259 minecraft:bone_block
setblock 406 234 260 minecraft:lime_terracotta
fill 406 234 270 406 243 270 minecraft:lime_terracotta
setblock 407 234 231 minecraft:light[level=12]
fill 407 234 242 408 235 242 minecraft:jungle_leaves[persistent=true]
setblock 407 234 252 minecraft:jungle_leaves[persistent=true]
setblock 407 234 266 minecraft:light[level=12]
fill 408 234 240 408 235 240 minecraft:green_terracotta
fill 408 234 241 408 235 241 minecraft:jungle_leaves[persistent=true]
fill 408 234 243 408 234 244 minecraft:green_terracotta
setblock 408 234 245 minecraft:green_concrete
fill 408 234 247 409 235 247 minecraft:green_concrete
fill 408 234 251 409 235 251 minecraft:green_concrete
fill 408 234 252 409 235 252 minecraft:bone_block
setblock 409 234 243 minecraft:lime_terracotta
setblock 409 234 248 minecraft:green_concrete
fill 409 234 249 410 235 249 minecraft:green_terracotta
setblock 409 234 250 minecraft:green_concrete
setblock 409 234 269 minecraft:azalea_leaves[persistent=true]
fill 410 234 242 410 234 243 minecraft:jungle_leaves[persistent=true]
fill 410 234 244 410 235 245 minecraft:azalea_leaves[persistent=true]
fill 410 234 246 410 234 247 minecraft:green_terracotta
setblock 410 234 248 minecraft:lime_terracotta
setblock 410 234 252 minecraft:lime_terracotta
fill 410 234 258 410 238 258 minecraft:bone_block
fill 410 234 264 410 235 264 minecraft:bone_block
fill 411 234 243 411 235 243 minecraft:jungle_leaves[persistent=true]
setblock 411 234 246 minecraft:azalea_leaves[persistent=true]
fill 411 234 247 411 235 248 minecraft:green_concrete
fill 411 234 254 411 236 254 minecraft:bone_block
fill 411 234 257 411 238 257 minecraft:bone_block
fill 411 234 259 413 240 259 minecraft:jungle_log
setblock 412 234 247 minecraft:green_concrete
fill 412 234 258 412 240 258 minecraft:jungle_log
fill 412 234 260 412 240 260 minecraft:jungle_log
setblock 414 234 238 minecraft:light[level=12]
setblock 414 234 245 minecraft:light[level=12]
setblock 414 234 252 minecraft:light[level=12]
fill 414 234 259 417 234 259 minecraft:oak_leaves[persistent=true]
setblock 415 234 236 minecraft:iron_block
fill 415 234 238 418 234 238 minecraft:oak_leaves[persistent=true]
fill 415 234 261 417 234 261 minecraft:oak_leaves[persistent=true]
fill 416 234 228 417 243 228 minecraft:lime_terracotta
fill 416 234 239 417 234 240 minecraft:oak_leaves[persistent=true]
setblock 418 234 232 minecraft:jungle_leaves[persistent=true]
fill 418 234 233 418 295 233 minecraft:lime_terracotta
setblock 418 234 239 minecraft:oak_leaves[persistent=true]
fill 418 234 240 418 243 240 minecraft:lime_terracotta
fill 418 234 259 418 256 259 minecraft:lime_terracotta
fill 418 234 261 418 256 261 minecraft:lime_terracotta
setblock 418 234 264 minecraft:green_concrete
fill 380 235 244 380 235 245 minecraft:dirt
setblock 380 235 259 minecraft:azalea_leaves[persistent=true]
setblock 381 235 242 minecraft:dirt
setblock 381 235 247 minecraft:dirt
setblock 383 235 240 minecraft:dirt
setblock 383 235 249 minecraft:dirt
setblock 384 235 242 minecraft:dirt
setblock 384 235 244 minecraft:dirt
setblock 384 235 245 minecraft:lime_terracotta
setblock 384 235 246 minecraft:green_terracotta
setblock 384 235 247 minecraft:jungle_leaves[persistent=true]
setblock 384 235 248 minecraft:green_terracotta
setblock 384 235 249 minecraft:lime_terracotta
setblock 384 235 250 minecraft:green_terracotta
fill 385 235 236 387 235 236 minecraft:jungle_leaves[persistent=true]
fill 385 235 239 385 235 240 minecraft:dirt
fill 385 235 241 385 235 242 minecraft:azalea_leaves[persistent=true]
fill 385 235 243 385 235 245 minecraft:green_terracotta
fill 385 235 248 386 235 248 minecraft:green_concrete
setblock 385 235 249 minecraft:green_terracotta
fill 385 235 253 386 235 253 minecraft:green_terracotta
setblock 385 235 254 minecraft:lime_terracotta
setblock 385 235 255 minecraft:green_terracotta
fill 385 235 261 385 235 262 minecraft:oak_leaves[persistent=true]
fill 385 235 263 385 237 263 minecraft:jungle_leaves[persistent=true]
setblock 386 235 235 minecraft:jungle_leaves[persistent=true]
fill 386 235 240 386 236 240 minecraft:green_terracotta
fill 386 235 245 387 239 245 minecraft:green_terracotta
fill 386 235 251 386 236 251 minecraft:bone_block
setblock 386 235 252 minecraft:green_terracotta
fill 386 235 256 386 236 256 minecraft:green_terracotta
fill 386 235 261 386 236 261 minecraft:bone_block
fill 387 235 238 387 236 238 minecraft:brown_terracotta
setblock 387 235 239 minecraft:green_terracotta
fill 387 235 254 387 239 254 minecraft:green_terracotta
fill 387 235 255 387 236 255 minecraft:azalea_leaves[persistent=true]
setblock 387 235 257 minecraft:green_concrete
fill 387 235 258 388 236 258 minecraft:green_terracotta
fill 388 235 237 388 237 237 minecraft:brown_terracotta
fill 388 235 238 388 236 238 minecraft:green_terracotta
setblock 388 235 239 minecraft:green_concrete
fill 388 235 240 388 239 240 minecraft:green_terracotta
fill 388 235 259 389 236 259 minecraft:green_terracotta
fill 389 235 251 389 236 251 minecraft:bone_block
fill 389 235 252 389 235 253 minecraft:red_terracotta
fill 389 235 256 389 236 256 minecraft:green_terracotta
setblock 389 235 260 minecraft:green_terracotta
fill 389 235 261 389 236 261 minecraft:bone_block
fill 390 235 249 390 235 251 minecraft:red_terracotta
fill 390 235 254 390 235 256 minecraft:red_terracotta
fill 390 235 258 390 239 258 minecraft:green_terracotta
fill 390 235 261 390 236 261 minecraft:green_terracotta
fill 391 235 234 391 237 234 minecraft:brown_terracotta
setblock 391 235 246 minecraft:green_terracotta
fill 391 235 247 391 235 248 minecraft:red_terracotta
fill 391 235 257 391 235 258 minecraft:red_terracotta
fill 391 235 260 391 238 260 minecraft:green_terracotta
setblock 391 235 261 minecraft:jungle_leaves[persistent=true]
setblock 392 235 246 minecraft:red_terracotta
fill 392 235 251 392 236 251 minecraft:bone_block
fill 392 235 259 392 235 260 minecraft:azalea_leaves[persistent=true]
fill 392 235 261 392 236 261 minecraft:bone_block
fill 393 235 233 393 237 233 minecraft:brown_terracotta
fill 393 235 244 394 235 244 minecraft:green_terracotta
fill 393 235 245 394 235 245 minecraft:red_terracotta
fill 393 235 260 394 236 260 minecraft:red_terracotta
setblock 394 235 233 minecraft:green_terracotta
fill 394 235 236 394 240 236 minecraft:green_terracotta
setblock 394 235 237 minecraft:jungle_leaves[persistent=true]
fill 394 235 261 394 235 264 minecraft:green_terracotta
fill 395 235 238 395 236 238 minecraft:jungle_leaves[persistent=true]
fill 395 235 244 397 235 244 minecraft:red_terracotta
fill 395 235 251 395 236 251 minecraft:bone_block
setblock 395 235 260 minecraft:jungle_leaves[persistent=true]
fill 395 235 261 395 236 261 minecraft:bone_block
setblock 395 235 264 minecraft:lime_terracotta
fill 396 235 236 396 240 238 minecraft:green_terracotta
fill 396 235 261 396 236 262 minecraft:jungle_leaves[persistent=true]
fill 396 235 263 396 236 263 minecraft:green_terracotta
setblock 397 235 236 minecraft:jungle_leaves[persistent=true]
fill 397 235 237 397 241 238 minecraft:green_terracotta
fill 397 235 261 397 236 261 minecraft:red_terracotta
fill 398 235 236 398 235 237 minecraft:green_concrete
fill 398 235 238 398 241 238 minecraft:green_terracotta
fill 398 235 244 399 235 244 minecraft:green_terracotta
fill 398 235 245 399 235 245 minecraft:red_terracotta
fill 398 235 251 398 236 251 minecraft:bone_block
fill 398 235 260 399 235 260 minecraft:red_terracotta
fill 398 235 261 398 236 261 minecraft:bone_block
fill 398 235 264 398 236 264 minecraft:green_terracotta
fill 399 235 235 399 239 236 minecraft:green_terracotta
fill 399 235 263 399 238 263 minecraft:green_terracotta
setblock 399 235 264 minecraft:lime_terracotta
setblock 400 235 237 minecraft:jungle_leaves[persistent=true]
setblock 400 235 238 minecraft:green_concrete
setblock 400 235 245 minecraft:green_terracotta
setblock 400 235 246 minecraft:red_terracotta
fill 400 235 259 400 236 259 minecraft:red_terracotta
fill 401 235 233 401 237 233 minecraft:brown_terracotta
setblock 401 235 246 minecraft:green_terracotta
fill 401 235 247 401 235 248 minecraft:red_terracotta
fill 401 235 251 401 236 251 minecraft:bone_block
fill 401 235 258 401 236 258 minecraft:red_terracotta
setblock 401 235 260 minecraft:green_terracotta
fill 401 235 261 401 236 261 minecraft:bone_block
fill 401 235 263 401 237 263 minecraft:green_terracotta
fill 402 235 234 402 236 234 minecraft:green_terracotta
fill 402 235 239 403 240 239 minecraft:green_terracotta
fill 402 235 249 402 235 251 minecraft:red_terracotta
fill 402 235 254 402 235 256 minecraft:red_terracotta
setblock 402 235 263 minecraft:lime_terracotta
fill 403 235 234 403 237 234 minecraft:brown_terracotta
fill 403 235 238 403 240 238 minecraft:green_terracotta
setblock 403 235 249 minecraft:green_terracotta
fill 403 235 252 403 236 253 minecraft:red_terracotta
fill 403 235 254 404 235 254 minecraft:green_terracotta
fill 403 235 260 403 235 261 minecraft:green_concrete
fill 403 235 262 403 236 262 minecraft:green_terracotta
fill 404 235 251 404 236 251 minecraft:bone_block
fill 404 235 253 404 236 253 minecraft:green_terracotta
setblock 404 235 260 minecraft:jungle_leaves[persistent=true]
fill 404 235 261 404 236 261 minecraft:bone_block
setblock 404 235 270 minecraft:moss_block
fill 405 235 251 406 239 251 minecraft:green_terracotta
fill 405 235 254 405 237 254 minecraft:bone_block
setblock 405 235 260 minecraft:azalea_leaves[persistent=true]
setblock 405 235 261 minecraft:green_terracotta
fill 405 235 270 405 279 270 minecraft:lime_terracotta
fill 406 235 237 406 237 237 minecraft:brown_terracotta
fill 406 235 240 406 240 240 minecraft:green_terracotta
setblock 406 235 260 minecraft:green_terracotta
fill 407 235 252 407 240 252 minecraft:green_terracotta
fill 407 235 270 408 243 270 minecraft:lime_terracotta
fill 408 235 243 409 237 243 minecraft:green_terracotta
fill 408 235 244 408 236 245 minecraft:azalea_leaves[persistent=true]
setblock 409 235 241 minecraft:green_terracotta
setblock 409 235 242 minecraft:lime_terracotta
fill 409 235 245 409 235 246 minecraft:green_terracotta
fill 409 235 248 410 236 248 minecraft:green_terracotta
fill 409 235 250 409 238 250 minecraft:green_terracotta
setblock 410 235 243 minecraft:jungle_leaves[persistent=true]
setblock 410 235 246 minecraft:green_terracotta
setblock 410 235 247 minecraft:lime_terracotta
setblock 410 235 251 minecraft:azalea_leaves[persistent=true]
fill 410 235 259 410 237 259 minecraft:bone_block
fill 411 235 258 411 237 258 minecraft:bone_block
fill 411 235 264 411 236 264 minecraft:bone_block
fill 411 235 270 411 243 270 minecraft:lime_terracotta
fill 416 235 259 416 235 261 minecraft:oak_leaves[persistent=true]
fill 417 235 238 417 235 239 minecraft:oak_leaves[persistent=true]
fill 418 235 232 418 306 232 minecraft:lime_terracotta
fill 418 235 237 418 242 239 minecraft:lime_terracotta
setblock 418 235 241 minecraft:jungle_leaves[persistent=true]
fill 418 235 243 418 252 244 minecraft:lime_terracotta
setblock 418 235 245 minecraft:jungle_leaves[persistent=true]
fill 418 235 246 418 260 254 minecraft:lime_terracotta
fill 418 235 260 418 255 260 minecraft:lime_terracotta
fill 418 235 262 418 257 264 minecraft:lime_terracotta
setblock 376 236 235 minecraft:jungle_leaves[persistent=true]
fill 376 236 236 376 268 236 minecraft:lime_terracotta
setblock 384 236 248 minecraft:lime_terracotta
setblock 385 236 242 minecraft:azalea_leaves[persistent=true]
fill 385 236 243 385 236 244 minecraft:green_terracotta
setblock 385 236 245 minecraft:lime_terracotta
fill 385 236 246 386 238 246 minecraft:green_terracotta
setblock 385 236 247 minecraft:jungle_leaves[persistent=true]
fill 385 236 248 386 236 248 minecraft:green_terracotta
setblock 385 236 249 minecraft:lime_terracotta
setblock 385 236 252 minecraft:green_terracotta
setblock 385 236 253 minecraft:lime_terracotta
setblock 385 236 254 minecraft:green_terracotta
fill 386 236 250 386 239 250 minecraft:green_terracotta
fill 386 236 252 386 237 252 minecraft:bone_block
setblock 386 236 253 minecraft:green_terracotta
fill 386 236 260 386 237 260 minecraft:bone_block
fill 387 236 239 387 237 239 minecraft:brown_terracotta
fill 387 236 256 387 236 257 minecraft:green_terracotta
fill 388 236 239 388 237 239 minecraft:green_terracotta
fill 388 236 257 388 238 257 minecraft:green_terracotta
fill 389 236 236 389 237 236 minecraft:brown_terracotta
fill 389 236 237 389 237 237 minecraft:green_terracotta
setblock 389 236 250 minecraft:red_terracotta
fill 389 236 252 389 237 252 minecraft:bone_block
fill 389 236 253 389 236 254 minecraft:red_terracotta
fill 389 236 260 389 237 260 minecraft:bone_block
fill 390 236 235 390 237 235 minecraft:brown_terracotta
fill 390 236 245 391 236 245 minecraft:green_terracotta
fill 390 236 248 390 236 249 minecraft:red_terracotta
fill 390 236 255 390 236 257 minecraft:red_terracotta
fill 391 236 246 391 236 247 minecraft:red_terracotta
setblock 391 236 258 minecraft:red_terracotta
fill 391 236 261 391 236 262 minecraft:green_terracotta
fill 392 236 243 393 236 243 minecraft:green_terracotta
setblock 392 236 245 minecraft:red_terracotta
fill 392 236 252 392 237 252 minecraft:bone_block
setblock 392 236 259 minecraft:azalea_leaves[persistent=true]
fill 392 236 260 392 237 260 minecraft:bone_block
fill 392 236 262 395 237 262 minecraft:green_terracotta
fill 393 236 244 394 236 244 minecraft:red_terracotta
fill 393 236 246 393 237 246 minecraft:white_terracotta
fill 393 236 248 393 237 248 minecraft:white_terracotta
fill 393 236 250 393 237 250 minecraft:white_terracotta
fill 393 236 252 393 237 252 minecraft:white_terracotta
fill 393 236 270 393 292 270 minecraft:lime_terracotta
fill 394 236 233 394 237 233 minecraft:brown_terracotta
fill 394 236 237 394 240 238 minecraft:green_terracotta
fill 394 236 243 394 237 243 minecraft:white_terracotta
fill 394 236 255 394 237 255 minecraft:white_terracotta
fill 394 236 261 394 237 261 minecraft:green_terracotta
fill 394 236 263 394 237 263 minecraft:green_terracotta
setblock 394 236 270 minecraft:mossy_cobblestone
fill 395 236 237 395 241 237 minecraft:green_terracotta
fill 395 236 242 395 237 242 minecraft:green_terracotta
fill 395 236 243 397 236 243 minecraft:red_terracotta
fill 395 236 252 395 237 252 minecraft:bone_block
fill 395 236 260 395 237 260 minecraft:bone_block
setblock 395 236 264 minecraft:green_terracotta
fill 395 236 270 397 240 270 minecraft:lime_terracotta
fill 396 236 242 398 237 242 minecraft:white_terracotta
fill 396 236 256 398 236 256 minecraft:white_terracotta
setblock 396 236 264 minecraft:lime_terracotta
fill 397 236 233 399 236 233 minecraft:green_terracotta
fill 397 236 236 398 240 236 minecraft:green_terracotta
fill 397 236 241 397 238 241 minecraft:white_terracotta
fill 397 236 257 397 238 257 minecraft:white_terracotta
setblock 397 236 264 minecraft:green_terracotta
fill 398 236 237 400 240 237 minecraft:green_terracotta
setblock 398 236 243 minecraft:green_terracotta
fill 398 236 244 399 236 244 minecraft:red_terracotta
fill 398 236 252 398 237 252 minecraft:bone_block
fill 398 236 260 398 237 260 minecraft:bone_block
fill 398 236 262 398 239 262 minecraft:green_terracotta
setblock 399 236 260 minecraft:red_terracotta
setblock 399 236 264 minecraft:green_terracotta
fill 399 236 270 399 290 270 minecraft:lime_terracotta
fill 400 236 233 400 237 233 minecraft:brown_terracotta
fill 400 236 238 400 241 238 minecraft:green_terracotta
fill 400 236 243 400 237 243 minecraft:white_terracotta
setblock 400 236 245 minecraft:red_terracotta
fill 400 236 255 400 237 255 minecraft:white_terracotta
fill 400 236 262 401 237 262 minecraft:green_terracotta
setblock 400 236 270 minecraft:green_concrete
fill 401 236 243 402 237 243 minecraft:green_terracotta
fill 401 236 246 401 237 246 minecraft:white_terracotta
fill 401 236 248 401 237 248 minecraft:white_terracotta
fill 401 236 250 401 237 250 minecraft:white_terracotta
fill 401 236 252 401 237 252 minecraft:bone_block
fill 401 236 260 401 237 260 minecraft:bone_block
fill 401 236 270 404 266 270 minecraft:lime_terracotta
fill 402 236 247 402 236 248 minecraft:red_terracotta
fill 402 236 256 402 236 257 minecraft:red_terracotta
setblock 402 236 263 minecraft:green_terracotta
setblock 403 236 248 minecraft:green_terracotta
fill 403 236 249 403 236 251 minecraft:red_terracotta
fill 403 236 254 403 236 255 minecraft:red_terracotta
fill 403 236 257 403 238 257 minecraft:green_terracotta
setblock 403 236 260 minecraft:green_concrete
fill 403 236 261 403 237 261 minecraft:green_terracotta
fill 404 236 235 404 237 235 minecraft:brown_terracotta
fill 404 236 250 404 237 250 minecraft:green_terracotta
fill 404 236 252 404 237 252 minecraft:bone_block
setblock 404 236 254 minecraft:green_terracotta
setblock 404 236 256 minecraft:green_terracotta
fill 404 236 260 404 237 260 minecraft:bone_block
fill 405 236 236 405 237 236 minecraft:brown_terracotta
setblock 405 236 260 minecraft:green_terracotta
fill 406 236 239 406 237 239 minecraft:green_terracotta
fill 407 236 239 407 237 239 minecraft:brown_terracotta
fill 407 236 242 407 239 242 minecraft:green_terracotta
setblock 408 236 240 minecraft:lime_terracotta
fill 408 236 241 408 237 241 minecraft:green_terracotta
setblock 408 236 242 minecraft:jungle_leaves[persistent=true]
fill 408 236 247 409 237 247 minecraft:green_terracotta
fill 408 236 251 409 236 252 minecraft:green_terracotta
setblock 408 236 260 minecraft:bone_block
setblock 409 236 242 minecraft:green_terracotta
setblock 409 236 244 minecraft:green_terracotta
setblock 409 236 245 minecraft:lime_terracotta
fill 409 236 246 409 238 246 minecraft:green_terracotta
setblock 409 236 249 minecraft:lime_terracotta
fill 409 236 270 410 238 270 minecraft:lime_terracotta
setblock 410 236 244 minecraft:azalea_leaves[persistent=true]
fill 412 236 263 412 237 263 minecraft:bone_block
fill 418 236 241 418 308 241 minecraft:lime_terracotta
fill 418 236 245 418 308 245 minecraft:lime_terracotta
fill 376 237 230 376 256 231 minecraft:lime_terracotta
setblock 376 237 232 minecraft:green_concrete
fill 376 237 235 376 269 235 minecraft:lime_terracotta
fill 376 237 254 376 244 259 minecraft:lime_terracotta
setblock 376 237 260 minecraft:jungle_leaves[persistent=true]
fill 384 237 256 404 238 256 minecraft:bone_block
setblock 385 237 243 minecraft:green_terracotta
setblock 385 237 244 minecraft:lime_terracotta
setblock 385 237 245 minecraft:green_terracotta
fill 385 237 247 386 237 247 minecraft:green_terracotta
setblock 385 237 248 minecraft:lime_terracotta
fill 385 237 249 385 238 249 minecraft:green_terracotta
setblock 385 237 252 minecraft:lime_terracotta
setblock 385 237 253 minecraft:green_terracotta
setblock 386 237 241 minecraft:lime_terracotta
fill 386 237 242 386 238 242 minecraft:green_terracotta
fill 386 237 248 386 240 248 minecraft:green_terracotta
fill 386 237 251 386 238 251 minecraft:green_terracotta
fill 386 237 253 386 237 254 minecraft:bone_block
fill 386 237 258 386 237 259 minecraft:bone_block
fill 387 237 255 387 239 255 minecraft:green_terracotta
setblock 387 237 257 minecraft:green_terracotta
fill 388 237 238 388 238 238 minecraft:brown_terracotta
setblock 388 237 258 minecraft:green_terracotta
setblock 388 237 259 minecraft:lime_terracotta
fill 389 237 249 389 237 251 minecraft:pink_terracotta
fill 389 237 253 389 237 254 minecraft:bone_block
fill 389 237 258 389 237 259 minecraft:bone_block
fill 390 237 245 390 238 245 minecraft:green_terracotta
fill 390 237 247 390 237 248 minecraft:pink_terracotta
setblock 390 237 255 minecraft:pink_terracotta
setblock 390 237 257 minecraft:pink_terracotta
setblock 390 237 261 minecraft:lime_terracotta
fill 391 237 245 391 237 246 minecraft:pink_terracotta
setblock 391 237 258 minecraft:pink_terracotta
fill 391 237 261 392 237 261 minecraft:green_terracotta
setblock 391 237 262 minecraft:lime_terracotta
fill 392 237 234 392 238 234 minecraft:brown_terracotta
fill 392 237 235 392 238 235 minecraft:green_terracotta
setblock 392 237 243 minecraft:green_terracotta
setblock 392 237 244 minecraft:pink_terracotta
fill 392 237 246 392 239 246 minecraft:white_terracotta
fill 392 237 248 392 239 248 minecraft:white_terracotta
fill 392 237 250 392 239 250 minecraft:white_terracotta
fill 392 237 253 392 237 254 minecraft:bone_block
fill 392 237 258 392 237 259 minecraft:bone_block
fill 393 237 237 393 240 238 minecraft:green_terracotta
setblock 393 237 243 minecraft:pink_terracotta
fill 393 237 244 393 239 244 minecraft:white_terracotta
fill 393 237 254 393 239 254 minecraft:white_terracotta
fill 393 237 260 394 237 260 minecraft:pink_terracotta
setblock 394 237 241 minecraft:green_terracotta
fill 394 237 242 394 239 242 minecraft:white_terracotta
fill 394 237 270 394 308 270 minecraft:lime_terracotta
fill 395 237 233 399 238 233 minecraft:brown_terracotta
fill 395 237 238 395 241 238 minecraft:green_terracotta
fill 395 237 241 396 239 241 minecraft:white_terracotta
setblock 395 237 243 minecraft:pink_terracotta
fill 395 237 258 395 237 259 minecraft:bone_block
fill 395 237 261 398 237 261 minecraft:pink_terracotta
fill 396 237 257 396 239 257 minecraft:white_terracotta
fill 396 237 262 396 239 262 minecraft:green_terracotta
setblock 396 237 263 minecraft:lime_terracotta
fill 398 237 241 399 239 241 minecraft:white_terracotta
fill 398 237 243 399 237 243 minecraft:pink_terracotta
fill 398 237 253 398 237 254 minecraft:bone_block
fill 398 237 258 398 237 259 minecraft:bone_block
setblock 399 237 242 minecraft:green_terracotta
fill 399 237 257 399 239 257 minecraft:white_terracotta
setblock 399 237 260 minecraft:pink_terracotta
setblock 400 237 241 minecraft:green_terracotta
fill 400 237 242 400 239 242 minecraft:white_terracotta
setblock 400 237 244 minecraft:pink_terracotta
setblock 400 237 259 minecraft:pink_terracotta
setblock 400 237 263 minecraft:lime_terracotta
fill 400 237 270 400 244 270 minecraft:lime_terracotta
setblock 401 237 242 minecraft:green_terracotta
fill 401 237 244 401 239 244 minecraft:white_terracotta
setblock 401 237 245 minecraft:pink_terracotta
fill 401 237 253 401 237 254 minecraft:bone_block
fill 401 237 258 401 237 259 minecraft:bone_block
fill 401 237 261 401 239 261 minecraft:green_terracotta
fill 402 237 234 402 238 234 minecraft:brown_terracotta
fill 402 237 244 403 238 244 minecraft:green_terracotta
fill 402 237 246 402 239 246 minecraft:white_terracotta
setblock 402 237 247 minecraft:pink_terracotta
fill 402 237 248 402 239 248 minecraft:white_terracotta
fill 402 237 250 402 239 250 minecraft:white_terracotta
fill 402 237 252 402 239 252 minecraft:white_terracotta
setblock 402 237 257 minecraft:pink_terracotta
fill 403 237 248 403 237 255 minecraft:pink_terracotta
fill 403 237 260 403 238 260 minecraft:green_terracotta
setblock 403 237 262 minecraft:lime_terracotta
setblock 404 237 251 minecraft:green_terracotta
fill 404 237 253 404 237 254 minecraft:bone_block
fill 404 237 258 404 237 259 minecraft:bone_block
setblock 404 237 261 minecraft:green_terracotta
setblock 405 237 260 minecraft:lime_terracotta
fill 406 237 238 406 238 238 minecraft:brown_terracotta
setblock 408 237 242 minecraft:green_terracotta
fill 408 237 244 408 238 245 minecraft:green_terracotta
fill 408 237 251 408 239 252 minecraft:green_terracotta
fill 408 237 253 409 237 253 minecraft:bone_block
setblock 409 237 244 minecraft:lime_terracotta
setblock 409 237 245 minecraft:green_terracotta
setblock 409 237 248 minecraft:lime_terracotta
fill 409 237 249 409 238 249 minecraft:green_terracotta
setblock 409 237 251 minecraft:green_terracotta
setblock 409 237 252 minecraft:lime_terracotta
fill 376 238 232 376 256 232 minecraft:lime_terracotta
fill 376 238 260 376 282 260 minecraft:lime_terracotta
setblock 385 238 244 minecraft:jungle_log
setblock 385 238 247 minecraft:lime_terracotta
setblock 385 238 248 minecraft:green_terracotta
setblock 386 238 244 minecraft:lime_terracotta
setblock 386 238 247 minecraft:green_terracotta
setblock 386 238 252 minecraft:lime_terracotta
fill 386 238 253 386 238 254 minecraft:green_terracotta
setblock 387 238 241 minecraft:lime_terracotta
fill 388 238 239 388 239 239 minecraft:brown_terracotta
fill 388 238 246 389 239 246 minecraft:green_terracotta
setblock 388 238 258 minecraft:lime_terracotta
setblock 389 238 237 minecraft:brown_terracotta
fill 389 238 248 389 239 255 minecraft:red_terracotta
fill 389 238 257 389 238 258 minecraft:green_terracotta
setblock 389 238 259 minecraft:lime_terracotta
setblock 390 238 236 minecraft:brown_terracotta
fill 390 238 246 390 238 247 minecraft:red_terracotta
fill 390 238 257 390 239 257 minecraft:red_terracotta
setblock 390 238 260 minecraft:lime_terracotta
setblock 391 238 235 minecraft:brown_terracotta
fill 391 238 242 392 238 242 minecraft:green_terracotta
fill 391 238 245 391 239 248 minecraft:white_terracotta
fill 391 238 250 391 239 253 minecraft:white_terracotta
fill 391 238 258 391 239 258 minecraft:red_terracotta
setblock 391 238 261 minecraft:lime_terracotta
fill 392 238 243 393 239 243 minecraft:white_terracotta
setblock 392 238 244 minecraft:red_terracotta
fill 392 238 245 392 239 245 minecraft:white_terracotta
fill 392 238 252 392 239 253 minecraft:white_terracotta
fill 392 238 255 393 239 255 minecraft:white_terracotta
fill 392 238 259 392 239 259 minecraft:red_terracotta
fill 392 238 260 392 238 261 minecraft:green_terracotta
setblock 392 238 262 minecraft:lime_terracotta
fill 393 238 234 394 238 234 minecraft:brown_terracotta
fill 393 238 240 394 238 240 minecraft:green_terracotta
fill 393 238 241 393 239 242 minecraft:white_terracotta
fill 393 238 257 395 239 257 minecraft:white_terracotta
fill 393 238 260 393 239 260 minecraft:red_terracotta
fill 393 238 262 395 238 262 minecraft:green_terracotta
fill 394 238 241 394 239 241 minecraft:white_terracotta
fill 394 238 261 398 239 261 minecraft:red_terracotta
fill 395 238 234 397 238 234 minecraft:green_terracotta
fill 395 238 240 399 239 240 minecraft:white_terracotta
setblock 395 238 242 minecraft:red_terracotta
fill 395 238 258 399 239 258 minecraft:white_terracotta
setblock 396 238 263 minecraft:green_terracotta
setblock 397 238 262 minecraft:green_terracotta
setblock 397 238 263 minecraft:lime_terracotta
fill 398 238 242 399 238 242 minecraft:red_terracotta
fill 398 238 257 398 239 257 minecraft:white_terracotta
fill 399 238 260 400 238 260 minecraft:red_terracotta
fill 400 238 234 401 238 234 minecraft:brown_terracotta
fill 400 238 241 401 239 241 minecraft:white_terracotta
setblock 400 238 243 minecraft:red_terracotta
fill 400 238 257 401 239 257 minecraft:white_terracotta
setblock 400 238 262 minecraft:lime_terracotta
fill 401 238 242 401 239 243 minecraft:white_terracotta
fill 401 238 254 401 239 255 minecraft:white_terracotta
fill 401 238 259 401 239 259 minecraft:red_terracotta
fill 401 238 260 401 240 260 minecraft:green_terracotta
setblock 401 238 262 minecraft:green_terracotta
fill 402 238 243 402 239 243 minecraft:white_terracotta
fill 402 238 245 403 239 245 minecraft:white_terracotta
fill 402 238 253 403 239 253 minecraft:white_terracotta
fill 402 238 255 402 239 255 minecraft:white_terracotta
fill 402 238 257 402 238 258 minecraft:red_terracotta
setblock 403 238 235 minecraft:brown_terracotta
fill 403 238 246 403 239 248 minecraft:white_terracotta
fill 403 238 250 403 239 252 minecraft:white_terracotta
fill 403 238 254 403 238 255 minecraft:red_terracotta
setblock 403 238 261 minecraft:lime_terracotta
setblock 404 238 236 minecraft:brown_terracotta
fill 404 238 245 404 239 246 minecraft:green_terracotta
fill 404 238 249 404 238 253 minecraft:red_terracotta
fill 404 238 254 404 238 255 minecraft:green_terracotta
fill 404 238 257 404 238 260 minecraft:green_terracotta
setblock 405 238 237 minecraft:brown_terracotta
fill 405 238 246 405 241 246 minecraft:green_terracotta
fill 405 238 254 405 241 254 minecraft:green_terracotta
fill 405 238 255 405 238 256 minecraft:bone_block
fill 405 238 257 405 238 258 minecraft:green_terracotta
setblock 405 238 259 minecraft:lime_terracotta
fill 406 238 239 406 239 239 minecraft:brown_terracotta
fill 406 238 253 408 238 253 minecraft:green_terracotta
setblock 407 238 241 minecraft:lime_terracotta
setblock 407 238 254 minecraft:bone_block
fill 407 238 259 409 238 259 minecraft:bone_block
setblock 408 238 242 minecraft:lime_terracotta
setblock 408 238 243 minecraft:green_terracotta
fill 408 238 247 408 239 247 minecraft:green_terracotta
setblock 409 238 247 minecraft:lime_terracotta
setblock 409 238 248 minecraft:green_terracotta
setblock 411 238 256 minecraft:bone_block
fill 377 239 264 377 246 264 minecraft:green_wool
fill 384 239 243 385 240 245 minecraft:jungle_leaves[persistent=true]
fill 385 239 246 385 241 246 minecraft:jungle_leaves[persistent=true]
fill 386 239 237 386 240 237 minecraft:verdant_froglight
setblock 386 239 243 minecraft:jungle_leaves[persistent=true]
setblock 386 239 244 minecraft:green_terracotta
setblock 386 239 246 minecraft:green_terracotta
setblock 386 239 247 minecraft:lime_terracotta
setblock 386 239 251 minecraft:lime_terracotta
setblock 386 239 252 minecraft:green_terracotta
setblock 387 239 241 minecraft:green_terracotta
fill 388 239 256 389 239 256 minecraft:green_terracotta
setblock 388 239 257 minecraft:lime_terracotta
setblock 389 239 238 minecraft:brown_terracotta
fill 389 239 244 390 239 244 minecraft:green_terracotta
setblock 389 239 247 minecraft:red_terracotta
setblock 389 239 257 minecraft:green_terracotta
setblock 389 239 258 minecraft:lime_terracotta
setblock 390 239 237 minecraft:brown_terracotta
fill 390 239 239 394 240 239 minecraft:green_terracotta
fill 390 239 245 390 239 246 minecraft:red_terracotta
fill 390 239 247 390 239 248 minecraft:white_terracotta
fill 390 239 250 390 239 251 minecraft:white_terracotta
setblock 390 239 256 minecraft:red_terracotta
setblock 390 239 259 minecraft:lime_terracotta
setblock 391 239 236 minecraft:brown_terracotta
fill 391 239 242 391 240 242 minecraft:green_terracotta
setblock 391 239 244 minecraft:white_terracotta
setblock 391 239 254 minecraft:white_terracotta
setblock 391 239 260 minecraft:lime_terracotta
fill 392 239 235 393 239 235 minecraft:brown_terracotta
setblock 392 239 242 minecraft:white_terracotta
fill 392 239 256 394 239 256 minecraft:white_terracotta
setblock 392 239 260 minecraft:green_terracotta
setblock 392 239 261 minecraft:lime_terracotta
fill 393 239 240 393 240 240 minecraft:green_terracotta
fill 394 239 234 400 239 234 minecraft:brown_terracotta
setblock 394 239 235 minecraft:green_terracotta
setblock 394 239 240 minecraft:white_terracotta
setblock 394 239 258 minecraft:white_terracotta
fill 394 239 262 395 239 262 minecraft:green_terracotta
fill 395 239 239 399 239 239 minecraft:white_terracotta
fill 395 239 259 399 239 259 minecraft:white_terracotta
setblock 397 239 241 minecraft:red_terracotta
setblock 397 239 262 minecraft:lime_terracotta
setblock 399 239 261 minecraft:red_terracotta
fill 400 239 236 402 239 236 minecraft:green_terracotta
fill 400 239 239 401 241 239 minecraft:green_terracotta
setblock 400 239 240 minecraft:white_terracotta
fill 400 239 256 402 239 256 minecraft:white_terracotta
setblock 400 239 258 minecraft:white_terracotta
setblock 400 239 260 minecraft:red_terracotta
fill 400 239 261 400 239 262 minecraft:green_terracotta
fill 401 239 235 402 239 235 minecraft:brown_terracotta
setblock 402 239 242 minecraft:white_terracotta
setblock 402 239 244 minecraft:red_terracotta
setblock 402 239 258 minecraft:red_terracotta
setblock 403 239 236 minecraft:brown_terracotta
setblock 403 239 244 minecraft:white_terracotta
setblock 403 239 254 minecraft:white_terracotta
fill 403 239 256 403 239 257 minecraft:red_terracotta
setblock 403 239 260 minecraft:lime_terracotta
setblock 404 239 237 minecraft:brown_terracotta
fill 404 239 247 404 239 248 minecraft:white_terracotta
setblock 404 239 249 minecraft:red_terracotta
fill 404 239 250 404 239 251 minecraft:white_terracotta
fill 404 239 252 404 239 255 minecraft:red_terracotta
fill 404 239 256 404 239 259 minecraft:green_terracotta
setblock 405 239 238 minecraft:brown_terracotta
fill 405 239 255 405 239 257 minecraft:green_terracotta
setblock 405 239 258 minecraft:lime_terracotta
fill 406 239 253 407 239 254 minecraft:green_terracotta
fill 406 239 255 408 239 255 minecraft:bone_block
fill 406 239 256 406 239 257 minecraft:green_terracotta
setblock 407 239 241 minecraft:green_terracotta
fill 407 239 256 409 239 256 minecraft:bone_block
setblock 408 239 244 minecraft:green_terracotta
setblock 408 239 245 minecraft:lime_terracotta
setblock 408 239 249 minecraft:lime_terracotta
fill 408 239 258 409 239 258 minecraft:bone_block
fill 409 239 270 409 242 270 minecraft:lime_terracotta
setblock 410 239 257 minecraft:bone_block
setblock 410 239 270 minecraft:moss_block
fill 377 240 270 378 285 270 minecraft:lime_terracotta
setblock 379 240 238 minecraft:light[level=12]
setblock 379 240 239 minecraft:light[level=15]
setblock 379 240 245 minecraft:light[level=12]
setblock 379 240 247 minecraft:light[level=15]
setblock 379 240 252 minecraft:light[level=12]
setblock 379 240 255 minecraft:light[level=15]
setblock 379 240 259 minecraft:light[level=12]
setblock 379 240 270 minecraft:jungle_leaves[persistent=true]
fill 380 240 270 384 243 270 minecraft:lime_terracotta
fill 383 240 228 390 282 228 minecraft:lime_terracotta
setblock 383 240 244 minecraft:jungle_leaves[persistent=true]
setblock 384 240 246 minecraft:jungle_leaves[persistent=true]
fill 385 240 242 386 243 242 minecraft:orange_concrete
setblock 386 240 231 minecraft:light[level=12]
setblock 386 240 238 minecraft:light[level=12]
fill 386 240 241 386 243 241 minecraft:orange_concrete
fill 386 240 243 386 243 243 minecraft:orange_concrete
fill 386 240 244 386 240 246 minecraft:jungle_leaves[persistent=true]
setblock 386 240 252 minecraft:light[level=12]
setblock 386 240 259 minecraft:light[level=12]
setblock 386 240 266 minecraft:light[level=12]
setblock 387 240 231 minecraft:light[level=15]
setblock 387 240 239 minecraft:light[level=15]
fill 387 240 241 387 243 243 minecraft:black_concrete
fill 387 240 244 387 240 245 minecraft:green_terracotta
setblock 387 240 247 minecraft:lime_terracotta
setblock 387 240 250 minecraft:green_terracotta
setblock 387 240 251 minecraft:lime_terracotta
setblock 387 240 252 minecraft:green_terracotta
setblock 387 240 255 minecraft:light[level=15]
setblock 387 240 263 minecraft:light[level=15]
setblock 388 240 240 minecraft:lime_terracotta
fill 388 240 242 388 243 242 minecraft:orange_concrete
fill 388 240 243 389 240 243 minecraft:green_terracotta
fill 388 240 246 388 241 246 minecraft:green_terracotta
setblock 388 240 256 minecraft:lime_terracotta
setblock 389 240 239 minecraft:brown_terracotta
setblock 389 240 240 minecraft:green_terracotta
fill 389 240 242 389 241 242 minecraft:green_terracotta
fill 389 240 244 389 241 244 minecraft:green_terracotta
fill 389 240 246 389 240 255 minecraft:pink_terracotta
setblock 389 240 256 minecraft:green_terracotta
setblock 389 240 257 minecraft:lime_terracotta
setblock 390 240 238 minecraft:brown_terracotta
fill 390 240 244 390 240 245 minecraft:pink_terracotta
fill 390 240 256 390 240 257 minecraft:pink_terracotta
setblock 390 240 258 minecraft:lime_terracotta
setblock 391 240 228 minecraft:green_concrete
setblock 391 240 237 minecraft:brown_terracotta
setblock 391 240 243 minecraft:pink_terracotta
setblock 391 240 258 minecraft:pink_terracotta
setblock 391 240 259 minecraft:lime_terracotta
fill 392 240 228 393 308 228 minecraft:lime_terracotta
fill 392 240 236 393 240 236 minecraft:brown_terracotta
setblock 392 240 242 minecraft:pink_terracotta
setblock 392 240 259 minecraft:pink_terracotta
setblock 392 240 260 minecraft:lime_terracotta
setblock 393 240 231 minecraft:light[level=12]
setblock 393 240 241 minecraft:pink_terracotta
setblock 393 240 245 minecraft:light[level=12]
setblock 393 240 252 minecraft:light[level=12]
setblock 393 240 259 minecraft:light[level=12]
setblock 393 240 260 minecraft:pink_terracotta
setblock 393 240 266 minecraft:light[level=12]
fill 394 240 235 400 240 235 minecraft:brown_terracotta
fill 394 240 240 399 240 240 minecraft:pink_terracotta
fill 394 240 261 399 240 261 minecraft:pink_terracotta
setblock 395 240 231 minecraft:light[level=15]
setblock 395 240 236 minecraft:green_terracotta
fill 395 240 239 399 240 239 minecraft:green_terracotta
setblock 395 240 247 minecraft:light[level=15]
setblock 395 240 255 minecraft:light[level=15]
setblock 395 240 263 minecraft:light[level=15]
fill 399 240 236 400 240 236 minecraft:green_terracotta
setblock 400 240 231 minecraft:light[level=12]
setblock 400 240 240 minecraft:green_terracotta
setblock 400 240 241 minecraft:pink_terracotta
setblock 400 240 245 minecraft:light[level=12]
setblock 400 240 252 minecraft:light[level=12]
setblock 400 240 259 minecraft:light[level=12]
setblock 400 240 260 minecraft:pink_terracotta
setblock 400 240 261 minecraft:green_terracotta
setblock 400 240 266 minecraft:light[level=12]
fill 401 240 236 402 240 236 minecraft:brown_terracotta
fill 401 240 237 402 240 237 minecraft:green_terracotta
setblock 401 240 241 minecraft:green_terracotta
setblock 401 240 242 minecraft:pink_terracotta
setblock 401 240 259 minecraft:pink_terracotta
setblock 402 240 242 minecraft:green_terracotta
setblock 402 240 243 minecraft:pink_terracotta
setblock 402 240 258 minecraft:pink_terracotta
setblock 403 240 231 minecraft:light[level=15]
setblock 403 240 237 minecraft:brown_terracotta
fill 403 240 244 403 240 245 minecraft:pink_terracotta
setblock 403 240 247 minecraft:light[level=15]
setblock 403 240 255 minecraft:light[level=15]
fill 403 240 256 403 240 257 minecraft:pink_terracotta
setblock 403 240 259 minecraft:lime_terracotta
setblock 403 240 263 minecraft:light[level=15]
setblock 404 240 238 minecraft:brown_terracotta
setblock 404 240 245 minecraft:green_terracotta
fill 404 240 246 404 240 248 minecraft:pink_terracotta
fill 404 240 253 404 240 255 minecraft:pink_terracotta
fill 404 240 256 404 240 258 minecraft:green_terracotta
setblock 405 240 239 minecraft:brown_terracotta
setblock 405 240 240 minecraft:green_terracotta
fill 405 240 249 405 240 252 minecraft:pink_terracotta
fill 405 240 255 406 240 256 minecraft:green_terracotta
setblock 405 240 257 minecraft:lime_terracotta
fill 406 240 242 407 243 242 minecraft:orange_concrete
fill 406 240 251 406 240 253 minecraft:green_terracotta
setblock 406 240 254 minecraft:lime_terracotta
setblock 407 240 231 minecraft:light[level=12]
setblock 407 240 238 minecraft:light[level=12]
fill 407 240 241 407 243 241 minecraft:orange_concrete
fill 407 240 243 407 243 243 minecraft:orange_concrete
fill 407 240 244 407 240 245 minecraft:green_terracotta
setblock 407 240 247 minecraft:lime_terracotta
setblock 407 240 250 minecraft:green_terracotta
setblock 407 240 251 minecraft:lime_terracotta
setblock 407 240 253 minecraft:green_terracotta
setblock 407 240 259 minecraft:light[level=12]
setblock 407 240 266 minecraft:light[level=12]
fill 408 240 241 408 243 243 minecraft:black_concrete
setblock 408 240 248 minecraft:lime_terracotta
fill 409 240 228 411 244 228 minecraft:lime_terracotta
fill 409 240 242 409 243 242 minecraft:orange_concrete
fill 410 240 270 410 242 270 minecraft:lime_terracotta
setblock 411 240 239 minecraft:light[level=15]
setblock 411 240 247 minecraft:light[level=15]
setblock 411 240 255 minecraft:light[level=15]
setblock 411 240 263 minecraft:light[level=15]
setblock 412 240 228 minecraft:green_concrete
setblock 414 240 238 minecraft:light[level=12]
setblock 414 240 245 minecraft:light[level=12]
setblock 414 240 252 minecraft:light[level=12]
setblock 414 240 259 minecraft:light[level=12]
fill 418 240 229 418 244 230 minecraft:lime_terracotta
setblock 418 240 231 minecraft:moss_block
fill 377 241 241 377 248 241 minecraft:jungle_leaves[persistent=true]
fill 379 241 270 379 262 270 minecraft:lime_terracotta
fill 384 241 243 384 241 245 minecraft:jungle_leaves[persistent=true]
fill 385 241 241 385 242 241 minecraft:orange_concrete
fill 385 241 243 385 242 243 minecraft:orange_concrete
fill 385 241 244 385 241 245 minecraft:jungle_leaves[persistent=true]
fill 386 241 237 387 243 237 minecraft:dirt
fill 386 241 240 387 242 240 minecraft:orange_concrete
fill 386 241 244 387 242 244 minecraft:orange_concrete
fill 386 241 245 386 241 246 minecraft:jungle_leaves[persistent=true]
setblock 387 241 245 minecraft:jungle_leaves[persistent=true]
setblock 387 241 246 minecraft:lime_terracotta
setblock 387 241 247 minecraft:green_terracotta
setblock 387 241 250 minecraft:lime_terracotta
fill 388 241 241 388 242 241 minecraft:orange_concrete
fill 388 241 243 388 242 243 minecraft:orange_concrete
fill 388 241 249 388 241 251 minecraft:red_terracotta
setblock 389 241 243 minecraft:green_terracotta
fill 389 241 245 389 241 248 minecraft:red_terracotta
fill 389 241 252 389 241 255 minecraft:red_terracotta
fill 390 241 239 391 241 239 minecraft:brown_terracotta
fill 390 241 243 390 241 244 minecraft:red_terracotta
fill 390 241 256 390 241 257 minecraft:red_terracotta
setblock 391 241 228 minecraft:mossy_cobblestone
fill 391 241 238 392 241 238 minecraft:brown_terracotta
setblock 391 241 242 minecraft:red_terracotta
fill 391 241 245 391 244 245 minecraft:bone_block
fill 391 241 247 392 241 247 minecraft:bone_block
fill 391 241 249 392 241 249 minecraft:bone_block
fill 391 241 251 392 241 251 minecraft:bone_block
fill 391 241 253 391 244 253 minecraft:bone_block
setblock 391 241 258 minecraft:red_terracotta
fill 392 241 237 394 241 237 minecraft:brown_terracotta
fill 392 241 239 393 241 239 minecraft:green_terracotta
setblock 392 241 241 minecraft:red_terracotta
fill 392 241 244 392 242 244 minecraft:bone_block
setblock 392 241 246 minecraft:bone_block
setblock 392 241 252 minecraft:bone_block
fill 392 241 254 392 242 254 minecraft:bone_block
setblock 392 241 259 minecraft:red_terracotta
fill 393 241 238 394 241 238 minecraft:green_terracotta
setblock 393 241 240 minecraft:red_terracotta
fill 393 241 242 393 241 243 minecraft:bone_block
fill 393 241 255 393 241 256 minecraft:bone_block
setblock 394 241 228 minecraft:green_concrete
fill 394 241 236 400 241 236 minecraft:brown_terracotta
fill 394 241 239 399 241 239 minecraft:red_terracotta
fill 394 241 241 394 241 242 minecraft:bone_block
fill 394 241 256 394 241 257 minecraft:bone_block
fill 394 241 262 394 242 263 minecraft:black_concrete
fill 395 241 228 395 308 228 minecraft:lime_terracotta
fill 395 241 240 395 241 241 minecraft:bone_block
fill 395 241 257 395 241 258 minecraft:bone_block
setblock 395 241 270 minecraft:moss_block
fill 396 241 237 396 241 238 minecraft:green_terracotta
fill 396 241 240 396 242 240 minecraft:bone_block
fill 396 241 258 396 242 258 minecraft:bone_block
fill 396 241 270 397 266 270 minecraft:lime_terracotta
fill 398 241 237 399 241 237 minecraft:green_terracotta
fill 398 241 240 399 242 240 minecraft:bone_block
fill 398 241 258 399 242 258 minecraft:bone_block
fill 399 241 241 400 241 241 minecraft:bone_block
fill 399 241 257 400 241 257 minecraft:bone_block
fill 400 241 237 402 241 237 minecraft:brown_terracotta
fill 400 241 240 401 241 240 minecraft:red_terracotta
fill 400 241 242 401 241 242 minecraft:bone_block
fill 400 241 256 401 241 256 minecraft:bone_block
setblock 400 241 260 minecraft:red_terracotta
fill 400 241 262 400 242 263 minecraft:black_concrete
fill 401 241 241 402 241 241 minecraft:red_terracotta
setblock 401 241 243 minecraft:bone_block
setblock 401 241 255 minecraft:bone_block
fill 402 241 238 403 241 238 minecraft:brown_terracotta
fill 402 241 239 402 241 240 minecraft:green_terracotta
setblock 402 241 242 minecraft:red_terracotta
fill 402 241 244 402 242 244 minecraft:bone_block
fill 402 241 246 402 241 247 minecraft:bone_block
fill 402 241 249 403 241 249 minecraft:bone_block
fill 402 241 251 402 241 252 minecraft:bone_block
fill 402 241 254 402 242 254 minecraft:bone_block
fill 402 241 258 402 241 259 minecraft:red_terracotta
fill 403 241 239 404 241 239 minecraft:brown_terracotta
fill 403 241 240 403 241 241 minecraft:green_terracotta
setblock 403 241 243 minecraft:red_terracotta
fill 403 241 245 403 244 245 minecraft:bone_block
fill 403 241 247 403 243 247 minecraft:bone_block
fill 403 241 251 403 243 251 minecraft:bone_block
fill 403 241 253 403 244 253 minecraft:bone_block
setblock 403 241 257 minecraft:red_terracotta
setblock 403 241 258 minecraft:lime_terracotta
fill 404 241 241 404 242 241 minecraft:green_terracotta
fill 404 241 243 405 241 243 minecraft:green_terracotta
fill 404 241 244 404 241 246 minecraft:red_terracotta
fill 404 241 254 404 241 256 minecraft:red_terracotta
setblock 404 241 257 minecraft:green_terracotta
fill 405 241 247 405 242 253 minecraft:red_terracotta
setblock 405 241 255 minecraft:green_terracotta
fill 406 241 241 406 242 241 minecraft:orange_concrete
fill 406 241 243 406 242 243 minecraft:orange_concrete
setblock 406 241 245 minecraft:lime_terracotta
fill 406 241 247 407 241 248 minecraft:green_terracotta
fill 406 241 251 406 241 252 minecraft:green_terracotta
setblock 406 241 253 minecraft:lime_terracotta
setblock 406 241 254 minecraft:green_terracotta
fill 407 241 240 408 242 240 minecraft:orange_concrete
fill 407 241 244 408 242 244 minecraft:orange_concrete
setblock 407 241 246 minecraft:lime_terracotta
setblock 407 241 250 minecraft:lime_terracotta
fill 409 241 241 409 242 241 minecraft:orange_concrete
fill 409 241 243 409 242 243 minecraft:orange_concrete
fill 410 241 257 411 244 261 minecraft:jungle_leaves[persistent=true]
fill 412 241 228 412 297 228 minecraft:lime_terracotta
fill 412 241 257 414 244 258 minecraft:jungle_leaves[persistent=true]
setblock 412 241 259 minecraft:jungle_log
fill 412 241 260 414 244 261 minecraft:jungle_leaves[persistent=true]
fill 413 241 259 414 244 259 minecraft:jungle_leaves[persistent=true]
fill 418 241 231 418 282 231 minecraft:lime_terracotta
fill 379 242 251 383 242 251 minecraft:orange_terracotta
fill 380 242 247 380 242 250 minecraft:brown_terracotta
fill 380 242 252 380 242 254 minecraft:brown_terracotta
fill 381 242 247 381 242 249 minecraft:brown_terracotta
setblock 381 242 250 minecraft:orange_terracotta
setblock 381 242 252 minecraft:orange_terracotta
fill 381 242 253 381 242 254 minecraft:brown_terracotta
setblock 388 242 246 minecraft:lime_terracotta
fill 388 242 247 388 242 250 minecraft:red_terracotta
setblock 389 242 243 minecraft:lime_terracotta
fill 389 242 244 389 242 246 minecraft:red_terracotta
setblock 389 242 253 minecraft:red_terracotta
setblock 390 242 241 minecraft:green_terracotta
fill 390 242 242 390 242 243 minecraft:red_terracotta
fill 390 242 247 391 243 247 minecraft:bone_block
fill 390 242 249 391 243 249 minecraft:bone_block
fill 390 242 251 391 243 251 minecraft:bone_block
fill 391 242 228 391 252 228 minecraft:lime_terracotta
setblock 391 242 240 minecraft:green_terracotta
setblock 391 242 241 minecraft:red_terracotta
fill 391 242 243 392 243 243 minecraft:bone_block
fill 391 242 255 392 243 255 minecraft:bone_block
setblock 392 242 239 minecraft:brown_terracotta
setblock 392 242 240 minecraft:red_terracotta
fill 392 242 242 393 242 242 minecraft:bone_block
fill 392 242 256 393 242 256 minecraft:bone_block
fill 393 242 238 394 242 238 minecraft:brown_terracotta
fill 393 242 239 394 242 239 minecraft:red_terracotta
fill 393 242 240 394 242 241 minecraft:bone_block
fill 393 242 257 394 242 258 minecraft:bone_block
fill 394 242 228 394 308 228 minecraft:lime_terracotta
fill 395 242 237 399 242 237 minecraft:brown_terracotta
fill 395 242 238 399 242 238 minecraft:red_terracotta
fill 395 242 239 395 243 240 minecraft:bone_block
fill 395 242 258 395 243 259 minecraft:bone_block
fill 395 242 270 395 308 270 minecraft:lime_terracotta
fill 396 242 239 399 243 239 minecraft:bone_block
fill 396 242 259 399 243 259 minecraft:bone_block
fill 400 242 238 401 242 238 minecraft:brown_terracotta
fill 400 242 239 401 242 239 minecraft:red_terracotta
fill 400 242 240 401 242 241 minecraft:bone_block
fill 400 242 257 401 242 258 minecraft:bone_block
fill 401 242 242 402 242 242 minecraft:bone_block
fill 401 242 256 402 242 256 minecraft:bone_block
setblock 402 242 239 minecraft:brown_terracotta
setblock 402 242 240 minecraft:red_terracotta
fill 402 242 243 403 243 243 minecraft:bone_block
fill 402 242 255 403 243 255 minecraft:bone_block
setblock 403 242 240 minecraft:green_terracotta
fill 403 242 241 403 242 242 minecraft:red_terracotta
fill 403 242 249 404 243 249 minecraft:bone_block
setblock 404 242 242 minecraft:lime_terracotta
fill 404 242 243 404 242 244 minecraft:red_terracotta
fill 404 242 247 404 244 247 minecraft:bone_block
fill 404 242 251 404 244 251 minecraft:bone_block
setblock 404 242 255 minecraft:red_terracotta
setblock 405 242 243 minecraft:lime_terracotta
setblock 405 242 244 minecraft:green_terracotta
fill 405 242 245 405 242 246 minecraft:red_terracotta
setblock 406 242 247 minecraft:green_terracotta
setblock 406 242 248 minecraft:lime_terracotta
setblock 406 242 249 minecraft:green_terracotta
fill 409 242 258 409 243 260 minecraft:jungle_leaves[persistent=true]
fill 411 242 256 413 243 256 minecraft:jungle_leaves[persistent=true]
fill 411 242 262 413 243 262 minecraft:jungle_leaves[persistent=true]
fill 412 242 259 412 245 259 minecraft:jungle_leaves[persistent=true]
fill 415 242 258 415 243 260 minecraft:jungle_leaves[persistent=true]
fill 380 243 244 381 243 247 minecraft:brown_terracotta
fill 380 243 254 381 243 257 minecraft:brown_terracotta
setblock 382 243 228 minecraft:green_concrete
fill 385 243 236 385 248 236 minecraft:oak_leaves[persistent=true]
fill 385 243 270 386 243 270 minecraft:azalea_leaves[persistent=true]
setblock 386 243 236 minecraft:dirt
setblock 386 243 238 minecraft:dirt
fill 386 243 268 387 248 268 minecraft:jungle_leaves[persistent=true]
fill 387 243 269 387 247 269 minecraft:jungle_leaves[persistent=true]
fill 389 243 246 389 244 252 minecraft:bone_block
fill 390 243 242 390 244 246 minecraft:bone_block
fill 390 243 248 390 244 248 minecraft:bone_block
fill 390 243 250 390 244 250 minecraft:bone_block
fill 390 243 252 390 244 256 minecraft:bone_block
fill 390 243 269 390 252 269 minecraft:green_wool
fill 391 243 241 392 244 242 minecraft:bone_block
fill 391 243 244 391 244 244 minecraft:bone_block
fill 391 243 254 391 244 254 minecraft:bone_block
fill 391 243 256 392 244 257 minecraft:bone_block
fill 392 243 240 394 244 240 minecraft:bone_block
fill 392 243 258 394 244 258 minecraft:bone_block
fill 393 243 239 394 244 239 minecraft:bone_block
fill 393 243 241 393 244 241 minecraft:bone_block
fill 393 243 257 393 244 257 minecraft:bone_block
fill 393 243 259 394 244 259 minecraft:bone_block
fill 394 243 238 400 244 238 minecraft:bone_block
fill 394 243 260 400 244 260 minecraft:bone_block
fill 396 243 237 396 244 237 minecraft:bone_block
fill 396 243 261 396 244 261 minecraft:bone_block
fill 398 243 237 398 244 237 minecraft:bone_block
fill 398 243 261 398 244 261 minecraft:bone_block
fill 399 243 240 402 243 240 minecraft:bone_block
fill 399 243 258 402 243 258 minecraft:bone_block
fill 400 243 239 401 244 239 minecraft:bone_block
fill 400 243 259 401 244 259 minecraft:bone_block
fill 401 243 241 403 244 241 minecraft:bone_block
fill 401 243 257 403 244 257 minecraft:bone_block
fill 402 243 242 404 244 242 minecraft:bone_block
fill 402 243 256 404 244 256 minecraft:bone_block
fill 403 243 244 404 244 244 minecraft:bone_block
fill 403 243 254 404 244 254 minecraft:bone_block
fill 404 243 243 404 244 243 minecraft:bone_block
fill 404 243 245 404 244 246 minecraft:bone_block
fill 404 243 248 405 244 248 minecraft:bone_block
fill 404 243 250 405 244 250 minecraft:bone_block
fill 404 243 252 404 244 253 minecraft:bone_block
fill 404 243 255 404 244 255 minecraft:bone_block
fill 405 243 246 405 244 247 minecraft:bone_block
fill 405 243 249 405 244 249 minecraft:bone_block
fill 405 243 251 405 244 252 minecraft:bone_block
fill 407 243 269 407 244 269 minecraft:oak_leaves[persistent=true]
fill 409 243 270 410 247 270 minecraft:azalea_leaves[persistent=true]
fill 417 243 237 417 247 238 minecraft:oak_leaves[persistent=true]
setblock 418 243 237 minecraft:lime_terracotta
fill 418 243 238 418 247 238 minecraft:oak_leaves[persistent=true]
setblock 418 243 239 minecraft:lime_terracotta
fill 418 243 256 418 290 256 minecraft:lime_terracotta
setblock 418 243 257 minecraft:green_concrete
fill 376 244 228 376 244 229 minecraft:azalea_leaves[persistent=true]
setblock 377 244 228 minecraft:azalea_leaves[persistent=true]
fill 377 244 229 377 244 230 minecraft:jungle_log
fill 378 244 228 378 245 229 minecraft:jungle_log
fill 379 244 228 379 245 228 minecraft:jungle_log
fill 380 244 270 380 270 270 minecraft:lime_terracotta
fill 381 244 270 382 245 270 minecraft:jungle_log
fill 382 244 228 382 308 228 minecraft:lime_terracotta
fill 382 244 235 383 244 235 minecraft:jungle_log
fill 382 244 269 384 244 269 minecraft:jungle_log
setblock 383 244 234 minecraft:jungle_log
fill 383 244 236 384 246 238 minecraft:oak_leaves[persistent=true]
fill 383 244 268 384 245 268 minecraft:jungle_log
setblock 383 244 270 minecraft:lime_terracotta
fill 384 244 267 384 245 267 minecraft:jungle_log
fill 384 244 270 385 244 270 minecraft:azalea_leaves[persistent=true]
fill 385 244 237 385 247 239 minecraft:oak_leaves[persistent=true]
fill 385 244 243 385 245 244 minecraft:brown_terracotta
fill 385 244 267 385 247 269 minecraft:jungle_leaves[persistent=true]
fill 386 244 236 386 247 238 minecraft:oak_leaves[persistent=true]
fill 386 244 240 386 244 243 minecraft:brown_terracotta
fill 386 244 266 386 246 267 minecraft:jungle_leaves[persistent=true]
fill 386 244 269 386 247 270 minecraft:jungle_leaves[persistent=true]
fill 387 244 236 387 244 238 minecraft:dirt
fill 387 244 239 387 244 241 minecraft:brown_terracotta
fill 387 244 267 388 247 267 minecraft:jungle_leaves[persistent=true]
fill 387 244 270 387 247 270 minecraft:jungle_leaves[persistent=true]
fill 388 244 237 388 251 237 minecraft:dirt
fill 388 244 239 388 244 240 minecraft:brown_terracotta
fill 388 244 246 388 244 247 minecraft:bone_block
setblock 388 244 249 minecraft:bone_block
fill 388 244 251 388 244 252 minecraft:bone_block
fill 388 244 268 388 247 269 minecraft:jungle_leaves[persistent=true]
fill 389 244 244 389 244 245 minecraft:bone_block
fill 389 244 253 389 244 254 minecraft:bone_block
setblock 390 244 247 minecraft:bone_block
setblock 390 244 249 minecraft:bone_block
setblock 390 244 251 minecraft:bone_block
setblock 391 244 240 minecraft:bone_block
setblock 391 244 243 minecraft:bone_block
setblock 391 244 255 minecraft:bone_block
setblock 391 244 258 minecraft:bone_block
setblock 392 244 239 minecraft:bone_block
setblock 392 244 259 minecraft:bone_block
setblock 393 244 238 minecraft:bone_block
setblock 393 244 260 minecraft:bone_block
fill 394 244 237 395 244 237 minecraft:bone_block
fill 394 244 261 395 244 261 minecraft:bone_block
fill 395 244 239 396 244 239 minecraft:bone_block
fill 395 244 259 396 244 259 minecraft:bone_block
setblock 397 244 237 minecraft:bone_block
setblock 397 244 261 minecraft:bone_block
fill 398 244 239 399 244 239 minecraft:bone_block
fill 398 244 259 399 244 259 minecraft:bone_block
fill 399 244 237 400 244 237 minecraft:bone_block
fill 399 244 261 400 244 261 minecraft:bone_block
fill 400 244 240 403 244 240 minecraft:bone_block
fill 400 244 258 403 244 258 minecraft:bone_block
setblock 401 244 238 minecraft:bone_block
setblock 401 244 260 minecraft:bone_block
setblock 402 244 239 minecraft:bone_block
setblock 402 244 259 minecraft:bone_block
setblock 403 244 243 minecraft:bone_block
setblock 403 244 255 minecraft:bone_block
setblock 404 244 249 minecraft:bone_block
fill 405 244 244 405 244 245 minecraft:bone_block
fill 405 244 253 405 244 254 minecraft:bone_block
fill 405 244 268 409 244 268 minecraft:oak_leaves[persistent=true]
fill 406 244 239 407 244 240 minecraft:brown_terracotta
fill 406 244 246 406 244 247 minecraft:bone_block
setblock 406 244 249 minecraft:bone_block
fill 406 244 251 406 244 252 minecraft:bone_block
fill 406 244 267 409 246 267 minecraft:oak_leaves[persistent=true]
fill 406 244 269 406 244 270 minecraft:oak_leaves[persistent=true]
fill 407 244 241 408 245 241 minecraft:brown_terracotta
fill 407 244 270 408 247 270 minecraft:azalea_leaves[persistent=true]
setblock 408 244 240 minecraft:brown_terracotta
fill 408 244 242 408 245 243 minecraft:brown_terracotta
fill 408 244 269 410 247 269 minecraft:azalea_leaves[persistent=true]
fill 409 244 243 409 245 244 minecraft:brown_terracotta
fill 410 244 267 410 245 267 minecraft:jungle_log
fill 411 244 268 411 245 269 minecraft:jungle_log
fill 411 244 270 411 246 270 minecraft:azalea_leaves[persistent=true]
setblock 412 244 269 minecraft:jungle_log
fill 413 244 228 413 245 228 minecraft:jungle_log
fill 414 244 228 414 247 228 minecraft:lime_terracotta
fill 415 244 228 416 244 228 minecraft:jungle_log
fill 416 244 229 416 245 229 minecraft:jungle_log
fill 416 244 235 416 245 236 minecraft:jungle_log
fill 416 244 237 416 247 239 minecraft:oak_leaves[persistent=true]
fill 417 244 228 417 246 228 minecraft:jungle_leaves[persistent=true]
fill 417 244 236 418 245 236 minecraft:oak_leaves[persistent=true]
fill 417 244 239 418 246 240 minecraft:oak_leaves[persistent=true]
fill 418 244 234 418 252 235 minecraft:lime_terracotta
fill 418 244 237 418 247 237 minecraft:oak_leaves[persistent=true]
fill 418 244 257 418 283 257 minecraft:lime_terracotta
fill 376 245 228 377 246 228 minecraft:oak_leaves[persistent=true]
fill 376 245 229 376 246 229 minecraft:azalea_leaves[persistent=true]
setblock 376 245 254 minecraft:green_concrete
fill 376 245 255 376 246 259 minecraft:lime_terracotta
setblock 377 245 229 minecraft:jungle_log
fill 382 245 236 382 245 237 minecraft:oak_leaves[persistent=true]
fill 383 245 235 384 245 235 minecraft:jungle_log
fill 383 245 239 384 245 239 minecraft:oak_leaves[persistent=true]
setblock 383 245 269 minecraft:jungle_log
fill 383 245 270 384 246 270 minecraft:azalea_leaves[persistent=true]
setblock 384 245 244 minecraft:brown_terracotta
fill 384 245 269 384 247 269 minecraft:azalea_leaves[persistent=true]
fill 385 245 235 386 246 235 minecraft:oak_leaves[persistent=true]
fill 385 245 242 386 245 242 minecraft:brown_terracotta
setblock 385 245 245 minecraft:brown_terracotta
fill 385 245 266 385 246 266 minecraft:jungle_leaves[persistent=true]
fill 385 245 270 385 246 270 minecraft:jungle_leaves[persistent=true]
fill 386 245 239 386 247 239 minecraft:oak_leaves[persistent=true]
fill 386 245 241 387 245 241 minecraft:brown_terracotta
fill 386 245 243 386 245 244 minecraft:brown_terracotta
fill 387 245 236 387 246 238 minecraft:oak_leaves[persistent=true]
fill 387 245 239 387 251 239 minecraft:dirt
setblock 387 245 240 minecraft:brown_terracotta
fill 387 245 266 387 246 266 minecraft:jungle_leaves[persistent=true]
fill 388 245 236 388 251 236 minecraft:dirt
fill 388 245 238 388 251 238 minecraft:dirt
fill 388 245 270 388 247 270 minecraft:jungle_leaves[persistent=true]
fill 389 245 268 389 246 269 minecraft:jungle_leaves[persistent=true]
fill 389 245 270 389 284 270 minecraft:lime_terracotta
setblock 392 245 270 minecraft:green_concrete
setblock 400 245 270 minecraft:jungle_leaves[persistent=true]
fill 405 245 268 407 246 268 minecraft:oak_leaves[persistent=true]
fill 406 245 269 406 247 269 minecraft:oak_leaves[persistent=true]
setblock 406 245 270 minecraft:azalea_leaves[persistent=true]
setblock 407 245 240 minecraft:brown_terracotta
fill 407 245 266 409 245 266 minecraft:oak_leaves[persistent=true]
fill 407 245 269 407 247 269 minecraft:azalea_leaves[persistent=true]
setblock 408 245 244 minecraft:brown_terracotta
fill 408 245 268 409 246 268 minecraft:azalea_leaves[persistent=true]
fill 409 245 228 410 269 228 minecraft:lime_terracotta
setblock 409 245 242 minecraft:brown_terracotta
setblock 409 245 245 minecraft:brown_terracotta
setblock 410 245 244 minecraft:brown_terracotta
setblock 410 245 268 minecraft:oak_leaves[persistent=true]
setblock 411 245 228 minecraft:moss_block
fill 415 245 228 416 245 228 minecraft:jungle_leaves[persistent=true]
fill 415 245 238 415 246 238 minecraft:oak_leaves[persistent=true]
fill 416 245 240 416 247 240 minecraft:oak_leaves[persistent=true]
fill 417 245 241 417 246 241 minecraft:oak_leaves[persistent=true]
setblock 418 245 229 minecraft:moss_block
fill 418 245 230 418 308 230 minecraft:lime_terracotta
fill 376 246 254 376 295 254 minecraft:lime_terracotta
setblock 376 246 261 minecraft:mossy_cobblestone
fill 376 246 262 376 250 263 minecraft:lime_terracotta
fill 378 246 228 379 251 228 minecraft:lime_terracotta
setblock 379 246 238 minecraft:light[level=12]
setblock 379 246 245 minecraft:light[level=12]
setblock 379 246 252 minecraft:light[level=12]
setblock 379 246 259 minecraft:light[level=12]
fill 381 246 270 382 264 270 minecraft:lime_terracotta
fill 384 246 235 384 247 235 minecraft:oak_leaves[persistent=true]
setblock 384 246 239 minecraft:oak_leaves[persistent=true]
setblock 385 246 244 minecraft:brown_terracotta
setblock 386 246 231 minecraft:light[level=12]
setblock 386 246 245 minecraft:light[level=12]
setblock 386 246 252 minecraft:light[level=12]
setblock 386 246 259 minecraft:light[level=12]
fill 387 246 235 388 251 235 minecraft:dirt
fill 388 246 239 388 251 239 minecraft:dirt
fill 389 246 237 389 251 237 minecraft:dirt
fill 392 246 270 392 308 270 minecraft:lime_terracotta
setblock 393 246 231 minecraft:light[level=12]
setblock 393 246 238 minecraft:light[level=12]
setblock 393 246 245 minecraft:light[level=12]
setblock 393 246 252 minecraft:light[level=12]
setblock 393 246 259 minecraft:light[level=12]
setblock 393 246 266 minecraft:light[level=12]
setblock 400 246 231 minecraft:light[level=12]
setblock 400 246 238 minecraft:light[level=12]
setblock 400 246 245 minecraft:light[level=12]
setblock 400 246 252 minecraft:light[level=12]
setblock 400 246 259 minecraft:light[level=12]
setblock 400 246 266 minecraft:light[level=12]
fill 400 246 270 400 258 270 minecraft:lime_terracotta
fill 401 246 232 401 258 232 minecraft:jungle_leaves[persistent=true]
setblock 405 246 269 minecraft:oak_leaves[persistent=true]
fill 406 246 270 406 295 270 minecraft:lime_terracotta
setblock 407 246 231 minecraft:light[level=12]
setblock 407 246 238 minecraft:light[level=12]
setblock 407 246 245 minecraft:light[level=12]
setblock 407 246 252 minecraft:light[level=12]
setblock 407 246 259 minecraft:light[level=12]
fill 407 246 266 408 247 266 minecraft:oak_leaves[persistent=true]
setblock 409 246 244 minecraft:brown_terracotta
fill 411 246 228 411 308 228 minecraft:lime_terracotta
fill 411 246 243 415 246 243 minecraft:orange_terracotta
fill 412 246 239 412 246 242 minecraft:brown_terracotta
fill 412 246 244 412 246 246 minecraft:brown_terracotta
fill 413 246 228 413 256 228 minecraft:lime_terracotta
fill 413 246 239 413 246 241 minecraft:brown_terracotta
setblock 413 246 242 minecraft:orange_terracotta
setblock 413 246 244 minecraft:orange_terracotta
fill 413 246 245 413 246 246 minecraft:brown_terracotta
setblock 414 246 238 minecraft:light[level=12]
setblock 414 246 245 minecraft:light[level=12]
setblock 414 246 252 minecraft:light[level=12]
setblock 414 246 259 minecraft:light[level=12]
fill 415 246 228 415 295 228 minecraft:lime_terracotta
setblock 415 246 237 minecraft:oak_leaves[persistent=true]
setblock 416 246 228 minecraft:jungle_leaves[persistent=true]
fill 418 246 229 418 269 229 minecraft:lime_terracotta
setblock 418 246 236 minecraft:oak_leaves[persistent=true]
setblock 376 247 228 minecraft:azalea_leaves[persistent=true]
fill 376 247 229 376 266 229 minecraft:lime_terracotta
fill 376 247 255 376 256 258 minecraft:lime_terracotta
setblock 376 247 259 minecraft:jungle_leaves[persistent=true]
fill 376 247 261 376 283 261 minecraft:lime_terracotta
setblock 377 247 228 minecraft:oak_leaves[persistent=true]
setblock 379 247 239 minecraft:light[level=15]
setblock 379 247 247 minecraft:light[level=15]
setblock 379 247 255 minecraft:light[level=15]
fill 383 247 237 384 247 237 minecraft:oak_leaves[persistent=true]
setblock 383 247 270 minecraft:moss_block
setblock 384 247 236 minecraft:oak_leaves[persistent=true]
setblock 384 247 238 minecraft:oak_leaves[persistent=true]
fill 384 247 270 385 247 270 minecraft:azalea_leaves[persistent=true]
setblock 385 247 235 minecraft:oak_leaves[persistent=true]
fill 386 247 234 386 251 235 minecraft:dirt
fill 386 247 240 387 251 240 minecraft:dirt
setblock 386 247 267 minecraft:jungle_leaves[persistent=true]
setblock 387 247 231 minecraft:light[level=15]
fill 387 247 236 387 251 238 minecraft:dirt
setblock 387 247 247 minecraft:light[level=15]
setblock 387 247 255 minecraft:light[level=15]
setblock 387 247 263 minecraft:light[level=15]
fill 389 247 236 389 251 236 minecraft:dirt
fill 389 247 238 389 251 238 minecraft:dirt
setblock 395 247 231 minecraft:light[level=15]
setblock 395 247 239 minecraft:light[level=15]
setblock 395 247 247 minecraft:light[level=15]
setblock 395 247 255 minecraft:light[level=15]
setblock 395 247 263 minecraft:light[level=15]
setblock 402 247 228 minecraft:mossy_cobblestone
fill 403 247 228 407 266 228 minecraft:lime_terracotta
setblock 403 247 231 minecraft:light[level=15]
setblock 403 247 239 minecraft:light[level=15]
setblock 403 247 247 minecraft:light[level=15]
setblock 403 247 255 minecraft:light[level=15]
setblock 403 247 263 minecraft:light[level=15]
fill 406 247 267 408 247 268 minecraft:oak_leaves[persistent=true]
setblock 409 247 268 minecraft:oak_leaves[persistent=true]
setblock 411 247 239 minecraft:light[level=15]
setblock 411 247 247 minecraft:light[level=15]
setblock 411 247 255 minecraft:light[level=15]
setblock 411 247 263 minecraft:light[level=15]
fill 411 247 270 411 256 270 minecraft:lime_terracotta
fill 412 247 236 413 247 239 minecraft:brown_terracotta
fill 412 247 246 413 247 249 minecraft:brown_terracotta
fill 416 247 228 417 296 228 minecraft:lime_terracotta
fill 417 247 239 417 247 240 minecraft:oak_leaves[persistent=true]
fill 418 247 236 418 257 236 minecraft:lime_terracotta
fill 418 247 239 418 248 239 minecraft:oak_leaves[persistent=true]
fill 418 247 240 418 256 240 minecraft:lime_terracotta
fill 376 248 228 377 248 228 minecraft:lime_terracotta
setblock 376 248 245 minecraft:mossy_cobblestone
fill 376 248 259 376 258 259 minecraft:lime_terracotta
fill 383 248 237 384 251 237 minecraft:dirt
fill 383 248 270 385 252 270 minecraft:lime_terracotta
fill 384 248 235 384 251 236 minecraft:dirt
fill 384 248 238 386 251 239 minecraft:dirt
fill 385 248 234 385 251 235 minecraft:dirt
setblock 385 248 237 minecraft:oak_leaves[persistent=true]
fill 385 248 240 385 251 240 minecraft:dirt
setblock 385 248 268 minecraft:jungle_leaves[persistent=true]
fill 386 248 236 386 251 237 minecraft:dirt
setblock 386 248 269 minecraft:jungle_leaves[persistent=true]
setblock 386 248 270 minecraft:azalea_leaves[persistent=true]
fill 387 248 234 388 251 234 minecraft:dirt
fill 387 248 270 388 248 270 minecraft:lime_terracotta
fill 388 248 240 388 251 240 minecraft:dirt
fill 389 248 235 389 251 235 minecraft:dirt
fill 389 248 239 389 251 239 minecraft:dirt
fill 402 248 228 402 308 228 minecraft:lime_terracotta
fill 407 248 267 407 248 269 minecraft:oak_leaves[persistent=true]
fill 407 248 270 407 272 270 minecraft:lime_terracotta
setblock 408 248 270 minecraft:azalea_leaves[persistent=true]
fill 409 248 270 410 250 270 minecraft:lime_terracotta
setblock 414 248 228 minecraft:jungle_leaves[persistent=true]
setblock 417 248 237 minecraft:oak_leaves[persistent=true]
fill 418 248 237 418 256 238 minecraft:lime_terracotta
fill 376 249 228 376 296 228 minecraft:lime_terracotta
fill 376 249 245 376 306 245 minecraft:lime_terracotta
setblock 377 249 228 minecraft:mossy_cobblestone
fill 383 249 235 383 251 236 minecraft:dirt
fill 383 249 238 383 251 239 minecraft:dirt
fill 384 249 234 384 251 234 minecraft:dirt
fill 384 249 240 384 251 240 minecraft:dirt
fill 385 249 236 385 251 237 minecraft:dirt
fill 386 249 233 386 251 233 minecraft:dirt
fill 386 249 241 387 251 241 minecraft:dirt
fill 386 249 270 386 252 270 minecraft:lime_terracotta
setblock 387 249 270 minecraft:moss_block
fill 388 249 270 388 256 270 minecraft:lime_terracotta
fill 389 249 234 389 251 234 minecraft:dirt
fill 389 249 240 389 251 240 minecraft:dirt
fill 390 249 236 390 251 238 minecraft:dirt
fill 408 249 270 408 295 270 minecraft:lime_terracotta
fill 411 249 253 411 256 253 minecraft:jungle_leaves[persistent=true]
fill 414 249 228 414 256 228 minecraft:lime_terracotta
fill 417 249 242 417 257 242 minecraft:moss_block
fill 418 249 239 418 256 239 minecraft:lime_terracotta
fill 376 250 246 376 254 247 minecraft:lime_terracotta
setblock 376 250 248 minecraft:moss_block
fill 376 250 249 376 266 251 minecraft:lime_terracotta
fill 377 250 228 377 287 228 minecraft:lime_terracotta
fill 382 250 237 382 251 237 minecraft:dirt
fill 385 250 233 385 251 233 minecraft:dirt
fill 385 250 241 385 251 241 minecraft:dirt
fill 387 250 233 388 251 233 minecraft:dirt
fill 387 250 270 387 256 270 minecraft:lime_terracotta
fill 388 250 241 388 251 241 minecraft:dirt
fill 390 250 235 390 251 235 minecraft:dirt
fill 390 250 239 390 251 239 minecraft:dirt
setblock 397 250 228 minecraft:mossy_cobblestone
fill 398 250 228 398 259 228 minecraft:lime_terracotta
setblock 399 250 228 minecraft:moss_block
fill 400 250 228 400 263 228 minecraft:lime_terracotta
setblock 418 250 267 minecraft:mossy_cobblestone
fill 376 251 248 376 308 248 minecraft:lime_terracotta
fill 376 251 262 376 308 262 minecraft:lime_terracotta
setblock 376 251 263 minecraft:green_concrete
fill 382 251 235 382 251 236 minecraft:dirt
fill 382 251 238 382 251 239 minecraft:dirt
setblock 383 251 234 minecraft:dirt
setblock 383 251 240 minecraft:dirt
setblock 384 251 233 minecraft:dirt
setblock 384 251 241 minecraft:dirt
fill 386 251 242 387 251 242 minecraft:dirt
setblock 389 251 233 minecraft:dirt
setblock 389 251 241 minecraft:dirt
setblock 390 251 234 minecraft:dirt
setblock 390 251 240 minecraft:dirt
fill 391 251 235 391 251 239 minecraft:dirt
fill 397 251 228 397 308 228 minecraft:lime_terracotta
fill 399 251 228 399 274 228 minecraft:lime_terracotta
fill 409 251 270 409 257 270 minecraft:lime_terracotta
setblock 410 251 270 minecraft:moss_block
fill 418 251 267 418 284 267 minecraft:lime_terracotta
setblock 376 252 252 minecraft:mossy_cobblestone
fill 376 252 253 376 308 253 minecraft:lime_terracotta
fill 376 252 263 376 308 263 minecraft:lime_terracotta
setblock 378 252 228 minecraft:mossy_cobblestone
fill 379 252 228 379 284 228 minecraft:lime_terracotta
setblock 379 252 238 minecraft:light[level=12]
setblock 379 252 245 minecraft:light[level=12]
setblock 379 252 252 minecraft:light[level=12]
setblock 379 252 259 minecraft:light[level=12]
setblock 386 252 231 minecraft:light[level=12]
fill 386 252 237 387 254 237 minecraft:jungle_log
setblock 386 252 238 minecraft:light[level=12]
setblock 386 252 245 minecraft:light[level=12]
setblock 386 252 252 minecraft:light[level=12]
setblock 386 252 259 minecraft:light[level=12]
setblock 386 252 266 minecraft:light[level=12]
setblock 393 252 231 minecraft:light[level=12]
setblock 393 252 238 minecraft:light[level=12]
setblock 393 252 245 minecraft:light[level=12]
setblock 393 252 252 minecraft:light[level=12]
setblock 393 252 259 minecraft:light[level=12]
setblock 393 252 266 minecraft:light[level=12]
setblock 400 252 231 minecraft:light[level=12]
setblock 400 252 238 minecraft:light[level=12]
setblock 400 252 245 minecraft:light[level=12]
setblock 400 252 252 minecraft:light[level=12]
setblock 400 252 259 minecraft:light[level=12]
setblock 400 252 266 minecraft:light[level=12]
setblock 407 252 231 minecraft:light[level=12]
setblock 407 252 238 minecraft:light[level=12]
setblock 407 252 245 minecraft:light[level=12]
setblock 407 252 252 minecraft:light[level=12]
setblock 407 252 259 minecraft:light[level=12]
setblock 407 252 266 minecraft:light[level=12]
fill 410 252 270 410 256 270 minecraft:lime_terracotta
fill 411 252 249 415 252 249 minecraft:orange_terracotta
fill 412 252 245 412 252 248 minecraft:brown_terracotta
fill 412 252 250 412 252 252 minecraft:brown_terracotta
fill 413 252 245 413 252 247 minecraft:brown_terracotta
setblock 413 252 248 minecraft:orange_terracotta
setblock 413 252 250 minecraft:orange_terracotta
fill 413 252 251 413 252 252 minecraft:brown_terracotta
setblock 414 252 238 minecraft:light[level=12]
setblock 414 252 245 minecraft:light[level=12]
setblock 414 252 252 minecraft:light[level=12]
setblock 414 252 259 minecraft:light[level=12]
fill 376 253 252 376 308 252 minecraft:lime_terracotta
fill 378 253 228 378 308 228 minecraft:lime_terracotta
setblock 380 253 228 minecraft:lime_terracotta
setblock 381 253 228 minecraft:mossy_cobblestone
fill 383 253 270 384 256 270 minecraft:lime_terracotta
setblock 385 253 270 minecraft:moss_block
setblock 386 253 270 minecraft:mossy_cobblestone
setblock 391 253 228 minecraft:mossy_cobblestone
fill 412 253 242 413 253 245 minecraft:brown_terracotta
fill 412 253 252 413 253 255 minecraft:brown_terracotta
fill 418 253 234 418 283 234 minecraft:lime_terracotta
setblock 418 253 235 minecraft:mossy_cobblestone
setblock 418 253 243 minecraft:lime_terracotta
setblock 418 253 244 minecraft:moss_block
setblock 418 253 269 minecraft:mossy_cobblestone
setblock 379 254 239 minecraft:light[level=15]
setblock 379 254 247 minecraft:light[level=15]
setblock 379 254 255 minecraft:light[level=15]
setblock 380 254 228 minecraft:mossy_cobblestone
fill 381 254 228 381 256 228 minecraft:lime_terracotta
fill 385 254 270 386 255 270 minecraft:lime_terracotta
setblock 387 254 231 minecraft:light[level=15]
setblock 387 254 239 minecraft:light[level=15]
setblock 387 254 247 minecraft:light[level=15]
setblock 387 254 255 minecraft:light[level=15]
setblock 387 254 263 minecraft:light[level=15]
fill 391 254 228 391 308 228 minecraft:lime_terracotta
setblock 395 254 231 minecraft:light[level=15]
setblock 395 254 239 minecraft:light[level=15]
setblock 395 254 247 minecraft:light[level=15]
setblock 395 254 255 minecraft:light[level=15]
setblock 395 254 263 minecraft:light[level=15]
setblock 403 254 231 minecraft:light[level=15]
setblock 403 254 239 minecraft:light[level=15]
setblock 403 254 247 minecraft:light[level=15]
setblock 403 254 255 minecraft:light[level=15]
setblock 403 254 263 minecraft:light[level=15]
fill 411 254 231 413 279 233 minecraft:jungle_log
setblock 411 254 239 minecraft:light[level=15]
setblock 411 254 247 minecraft:light[level=15]
setblock 411 254 255 minecraft:light[level=15]
setblock 411 254 263 minecraft:light[level=15]
fill 412 254 270 414 256 270 minecraft:lime_terracotta
fill 414 254 231 414 270 231 minecraft:jungle_leaves[persistent=true]
fill 414 254 232 417 279 233 minecraft:jungle_log
fill 415 254 231 417 279 231 minecraft:jungle_log
setblock 415 254 270 minecraft:green_concrete
fill 416 254 270 416 263 270 minecraft:lime_terracotta
fill 418 254 235 418 270 235 minecraft:lime_terracotta
setblock 418 254 243 minecraft:green_concrete
fill 418 254 244 418 271 244 minecraft:lime_terracotta
fill 418 254 269 418 256 269 minecraft:lime_terracotta
setblock 376 255 246 minecraft:jungle_leaves[persistent=true]
fill 376 255 247 376 302 247 minecraft:lime_terracotta
fill 380 255 228 380 280 228 minecraft:lime_terracotta
fill 385 255 236 388 257 238 minecraft:jungle_leaves[persistent=true]
fill 415 255 270 415 308 270 minecraft:lime_terracotta
setblock 418 255 243 minecraft:mossy_cobblestone
fill 376 256 246 376 266 246 minecraft:lime_terracotta
fill 377 256 238 377 261 239 minecraft:oak_leaves[persistent=true]
fill 378 256 239 379 260 239 minecraft:oak_leaves[persistent=true]
fill 379 256 259 380 261 259 minecraft:jungle_leaves[persistent=true]
fill 380 256 260 380 260 260 minecraft:jungle_leaves[persistent=true]
setblock 385 256 270 minecraft:lime_terracotta
fill 386 256 234 386 261 234 minecraft:azalea_leaves[persistent=true]
fill 386 256 235 387 256 235 minecraft:jungle_leaves[persistent=true]
fill 386 256 239 387 256 239 minecraft:jungle_leaves[persistent=true]
fill 386 256 269 386 260 270 minecraft:oak_leaves[persistent=true]
fill 387 256 269 387 260 269 minecraft:oak_leaves[persistent=true]
fill 388 256 233 388 260 234 minecraft:azalea_leaves[persistent=true]
fill 408 256 232 408 260 232 minecraft:jungle_leaves[persistent=true]
fill 417 256 238 417 261 239 minecraft:azalea_leaves[persistent=true]
fill 417 256 260 418 261 260 minecraft:jungle_leaves[persistent=true]
fill 418 256 243 418 308 243 minecraft:lime_terracotta
fill 376 257 230 376 295 230 minecraft:lime_terracotta
fill 376 257 231 376 258 232 minecraft:jungle_log
fill 376 257 238 376 260 239 minecraft:oak_leaves[persistent=true]
fill 376 257 240 376 258 244 minecraft:lime_terracotta
fill 376 257 255 376 262 257 minecraft:lime_terracotta
setblock 376 257 258 minecraft:green_concrete
fill 377 257 237 379 259 237 minecraft:oak_leaves[persistent=true]
fill 377 257 240 379 260 240 minecraft:oak_leaves[persistent=true]
fill 377 257 259 378 259 260 minecraft:jungle_leaves[persistent=true]
fill 378 257 236 379 257 236 minecraft:jungle_log
fill 378 257 238 379 260 238 minecraft:oak_leaves[persistent=true]
fill 378 257 241 378 259 241 minecraft:oak_leaves[persistent=true]
fill 378 257 258 381 260 258 minecraft:jungle_leaves[persistent=true]
fill 379 257 249 379 264 249 minecraft:jungle_leaves[persistent=true]
fill 379 257 257 380 260 257 minecraft:jungle_leaves[persistent=true]
fill 379 257 260 379 260 261 minecraft:jungle_leaves[persistent=true]
fill 379 257 262 380 258 262 minecraft:jungle_log
fill 380 257 261 380 260 261 minecraft:jungle_leaves[persistent=true]
setblock 381 257 228 minecraft:jungle_leaves[persistent=true]
fill 381 257 259 381 260 260 minecraft:jungle_leaves[persistent=true]
fill 383 257 268 384 258 268 minecraft:jungle_log
fill 383 257 270 383 296 270 minecraft:lime_terracotta
fill 384 257 233 384 258 233 minecraft:jungle_log
fill 384 257 270 385 259 270 minecraft:oak_leaves[persistent=true]
fill 385 257 233 385 259 234 minecraft:azalea_leaves[persistent=true]
fill 385 257 268 385 260 269 minecraft:oak_leaves[persistent=true]
fill 386 257 232 387 260 233 minecraft:azalea_leaves[persistent=true]
fill 386 257 235 388 260 235 minecraft:azalea_leaves[persistent=true]
fill 386 257 268 387 260 268 minecraft:oak_leaves[persistent=true]
fill 387 257 234 387 260 234 minecraft:azalea_leaves[persistent=true]
fill 387 257 270 388 260 270 minecraft:oak_leaves[persistent=true]
fill 388 257 232 388 260 232 minecraft:azalea_leaves[persistent=true]
fill 388 257 269 388 260 269 minecraft:oak_leaves[persistent=true]
fill 405 257 232 407 260 232 minecraft:jungle_leaves[persistent=true]
fill 406 257 231 409 259 231 minecraft:jungle_leaves[persistent=true]
fill 406 257 233 408 260 233 minecraft:jungle_leaves[persistent=true]
fill 407 257 230 408 259 230 minecraft:jungle_leaves[persistent=true]
fill 409 257 232 409 260 232 minecraft:jungle_leaves[persistent=true]
fill 410 257 232 410 258 232 minecraft:jungle_log
fill 410 257 270 411 260 270 minecraft:azalea_leaves[persistent=true]
fill 412 257 269 412 258 270 minecraft:jungle_log
fill 413 257 228 414 258 228 minecraft:jungle_log
fill 413 257 270 414 308 270 minecraft:lime_terracotta
fill 415 257 238 416 260 238 minecraft:azalea_leaves[persistent=true]
fill 415 257 260 416 259 260 minecraft:jungle_leaves[persistent=true]
fill 416 257 235 416 258 236 minecraft:jungle_log
fill 416 257 237 418 260 237 minecraft:azalea_leaves[persistent=true]
fill 416 257 239 416 260 240 minecraft:azalea_leaves[persistent=true]
fill 416 257 259 418 260 259 minecraft:jungle_leaves[persistent=true]
fill 416 257 261 418 260 261 minecraft:jungle_leaves[persistent=true]
fill 416 257 262 416 258 263 minecraft:jungle_log
fill 417 257 240 418 260 240 minecraft:azalea_leaves[persistent=true]
fill 417 257 258 418 260 258 minecraft:jungle_leaves[persistent=true]
fill 417 257 268 417 258 269 minecraft:jungle_log
fill 417 257 270 417 258 270 minecraft:lime_terracotta
fill 418 257 238 418 260 239 minecraft:azalea_leaves[persistent=true]
fill 418 257 269 418 260 270 minecraft:oak_leaves[persistent=true]
fill 376 258 258 376 283 258 minecraft:lime_terracotta
fill 377 258 241 377 259 241 minecraft:oak_leaves[persistent=true]
fill 377 258 258 377 259 258 minecraft:jungle_leaves[persistent=true]
fill 378 258 236 379 258 236 minecraft:oak_leaves[persistent=true]
fill 378 258 261 378 259 261 minecraft:jungle_leaves[persistent=true]
setblock 379 258 241 minecraft:oak_leaves[persistent=true]
setblock 379 258 245 minecraft:light[level=12]
setblock 379 258 252 minecraft:light[level=12]
fill 381 258 228 381 286 228 minecraft:lime_terracotta
fill 381 258 257 381 260 257 minecraft:jungle_leaves[persistent=true]
fill 381 258 261 381 259 261 minecraft:jungle_leaves[persistent=true]
fill 384 258 269 384 260 269 minecraft:oak_leaves[persistent=true]
fill 385 258 232 385 259 232 minecraft:azalea_leaves[persistent=true]
setblock 386 258 231 minecraft:light[level=12]
setblock 386 258 238 minecraft:light[level=12]
setblock 386 258 245 minecraft:light[level=12]
setblock 386 258 252 minecraft:light[level=12]
setblock 386 258 259 minecraft:light[level=12]
setblock 386 258 266 minecraft:light[level=12]
fill 386 258 267 387 258 267 minecraft:oak_leaves[persistent=true]
fill 387 258 231 388 259 231 minecraft:azalea_leaves[persistent=true]
fill 387 258 236 388 259 236 minecraft:azalea_leaves[persistent=true]
fill 388 258 268 388 259 268 minecraft:oak_leaves[persistent=true]
fill 389 258 232 389 259 233 minecraft:azalea_leaves[persistent=true]
setblock 393 258 231 minecraft:light[level=12]
setblock 393 258 238 minecraft:light[level=12]
setblock 393 258 245 minecraft:light[level=12]
setblock 393 258 252 minecraft:light[level=12]
setblock 393 258 259 minecraft:light[level=12]
setblock 393 258 266 minecraft:light[level=12]
setblock 400 258 231 minecraft:light[level=12]
setblock 400 258 238 minecraft:light[level=12]
setblock 400 258 245 minecraft:light[level=12]
setblock 400 258 252 minecraft:light[level=12]
setblock 400 258 259 minecraft:light[level=12]
setblock 400 258 266 minecraft:light[level=12]
fill 405 258 231 405 260 231 minecraft:jungle_leaves[persistent=true]
fill 405 258 233 405 259 233 minecraft:jungle_leaves[persistent=true]
fill 406 258 230 406 260 230 minecraft:jungle_leaves[persistent=true]
fill 406 258 234 407 259 234 minecraft:jungle_leaves[persistent=true]
setblock 407 258 238 minecraft:light[level=12]
setblock 407 258 245 minecraft:light[level=12]
setblock 407 258 252 minecraft:light[level=12]
setblock 407 258 259 minecraft:light[level=12]
setblock 407 258 266 minecraft:light[level=12]
setblock 409 258 230 minecraft:jungle_leaves[persistent=true]
fill 409 258 233 409 260 233 minecraft:jungle_leaves[persistent=true]
fill 409 258 270 409 259 270 minecraft:azalea_leaves[persistent=true]
setblock 414 258 238 minecraft:light[level=12]
setblock 414 258 245 minecraft:light[level=12]
setblock 414 258 252 minecraft:light[level=12]
setblock 414 258 259 minecraft:light[level=12]
setblock 415 258 236 minecraft:jungle_log
fill 415 258 237 415 259 237 minecraft:azalea_leaves[persistent=true]
fill 415 258 239 415 259 240 minecraft:azalea_leaves[persistent=true]
fill 415 258 259 415 259 259 minecraft:jungle_leaves[persistent=true]
fill 416 258 258 416 260 258 minecraft:jungle_leaves[persistent=true]
fill 417 258 236 418 259 236 minecraft:azalea_leaves[persistent=true]
fill 417 258 262 418 259 262 minecraft:jungle_leaves[persistent=true]
fill 418 258 263 418 282 264 minecraft:lime_terracotta
fill 376 259 231 376 271 232 minecraft:lime_terracotta
fill 376 259 237 376 260 237 minecraft:oak_leaves[persistent=true]
fill 376 259 240 376 260 240 minecraft:oak_leaves[persistent=true]
fill 376 259 241 376 277 244 minecraft:lime_terracotta
setblock 376 259 259 minecraft:jungle_leaves[persistent=true]
setblock 378 259 236 minecraft:oak_leaves[persistent=true]
setblock 378 259 257 minecraft:jungle_leaves[persistent=true]
fill 380 259 238 380 259 239 minecraft:oak_leaves[persistent=true]
setblock 384 259 268 minecraft:oak_leaves[persistent=true]
setblock 386 259 236 minecraft:azalea_leaves[persistent=true]
setblock 400 259 270 minecraft:mossy_cobblestone
fill 412 259 270 412 268 270 minecraft:lime_terracotta
fill 413 259 228 414 289 228 minecraft:lime_terracotta
setblock 415 259 261 minecraft:jungle_leaves[persistent=true]
setblock 416 259 262 minecraft:jungle_leaves[persistent=true]
setblock 417 259 257 minecraft:jungle_leaves[persistent=true]
setblock 417 259 270 minecraft:oak_leaves[persistent=true]
fill 376 260 259 376 268 259 minecraft:lime_terracotta
fill 377 260 237 378 260 237 minecraft:oak_leaves[persistent=true]
fill 377 260 259 378 260 259 minecraft:jungle_leaves[persistent=true]
setblock 378 260 260 minecraft:jungle_leaves[persistent=true]
setblock 380 260 239 minecraft:oak_leaves[persistent=true]
fill 384 260 270 384 295 270 minecraft:lime_terracotta
setblock 385 260 233 minecraft:azalea_leaves[persistent=true]
setblock 385 260 270 minecraft:oak_leaves[persistent=true]
setblock 398 260 228 minecraft:moss_block
fill 400 260 270 400 308 270 minecraft:lime_terracotta
setblock 405 260 230 minecraft:jungle_leaves[persistent=true]
fill 406 260 231 408 260 231 minecraft:jungle_leaves[persistent=true]
setblock 407 260 230 minecraft:jungle_leaves[persistent=true]
fill 409 260 270 409 270 270 minecraft:lime_terracotta
setblock 415 260 239 minecraft:azalea_leaves[persistent=true]
setblock 416 260 260 minecraft:jungle_leaves[persistent=true]
fill 417 260 270 417 308 270 minecraft:lime_terracotta
fill 418 260 236 418 269 236 minecraft:lime_terracotta
fill 418 260 262 418 282 262 minecraft:lime_terracotta
fill 376 261 237 376 264 240 minecraft:lime_terracotta
setblock 379 261 239 minecraft:light[level=15]
setblock 379 261 247 minecraft:light[level=15]
setblock 379 261 255 minecraft:light[level=15]
setblock 379 261 258 minecraft:jungle_leaves[persistent=true]
setblock 379 261 260 minecraft:jungle_leaves[persistent=true]
fill 385 261 270 386 283 270 minecraft:lime_terracotta
setblock 386 261 269 minecraft:oak_leaves[persistent=true]
setblock 387 261 231 minecraft:light[level=15]
setblock 387 261 239 minecraft:light[level=15]
setblock 387 261 247 minecraft:light[level=15]
setblock 387 261 255 minecraft:light[level=15]
setblock 387 261 263 minecraft:light[level=15]
setblock 387 261 270 minecraft:oak_leaves[persistent=true]
setblock 388 261 234 minecraft:azalea_leaves[persistent=true]
fill 388 261 270 388 283 270 minecraft:lime_terracotta
setblock 395 261 231 minecraft:light[level=15]
setblock 395 261 239 minecraft:light[level=15]
setblock 395 261 247 minecraft:light[level=15]
setblock 395 261 255 minecraft:light[level=15]
setblock 395 261 263 minecraft:light[level=15]
fill 398 261 228 398 272 228 minecraft:lime_terracotta
setblock 403 261 231 minecraft:light[level=15]
schedule function dropper:buildpart/56_4 1t
