fill 376 215 594 376 218 596 minecraft:black_concrete
fill 376 215 599 376 217 599 minecraft:black_concrete
setblock 378 215 557 minecraft:purple_concrete
fill 379 215 557 382 215 557 minecraft:black_concrete
fill 387 215 557 388 215 557 minecraft:black_concrete
fill 388 215 563 388 219 566 minecraft:purple_concrete
setblock 389 215 557 minecraft:purple_concrete
fill 389 215 562 389 217 562 minecraft:purple_concrete
fill 389 215 566 389 221 566 minecraft:purple_concrete
setblock 389 215 599 minecraft:purple_concrete
fill 390 215 557 391 216 557 minecraft:black_concrete
setblock 390 215 599 minecraft:black_concrete
setblock 392 215 599 minecraft:purple_concrete
fill 393 215 599 393 218 599 minecraft:black_concrete
fill 394 215 557 394 218 557 minecraft:black_concrete
setblock 399 215 599 minecraft:black_concrete
setblock 400 215 599 minecraft:purple_concrete
fill 404 215 599 404 218 599 minecraft:black_concrete
fill 405 215 557 405 218 557 minecraft:black_concrete
setblock 406 215 557 minecraft:purple_concrete
setblock 408 215 557 minecraft:black_concrete
fill 409 215 557 410 215 557 minecraft:purple_concrete
fill 409 215 599 409 217 599 minecraft:black_concrete
fill 411 215 557 412 215 557 minecraft:black_concrete
fill 417 215 599 418 215 599 minecraft:black_concrete
fill 418 215 565 418 218 565 minecraft:black_concrete
setblock 418 215 569 minecraft:purple_concrete
setblock 418 215 580 minecraft:purple_concrete
fill 418 215 585 418 217 585 minecraft:black_concrete
fill 418 215 596 418 218 596 minecraft:black_concrete
setblock 418 215 597 minecraft:purple_concrete
fill 376 216 557 378 216 557 minecraft:black_concrete
fill 376 216 558 376 217 558 minecraft:purple_concrete
fill 376 216 559 376 242 560 minecraft:black_concrete
setblock 376 216 561 minecraft:purple_concrete
fill 376 216 563 376 241 563 minecraft:black_concrete
fill 376 216 568 376 217 568 minecraft:black_concrete
fill 376 216 569 376 217 570 minecraft:purple_concrete
fill 376 216 571 376 241 572 minecraft:black_concrete
fill 376 216 580 376 242 580 minecraft:black_concrete
fill 376 216 581 376 216 582 minecraft:purple_concrete
fill 376 216 583 376 241 584 minecraft:black_concrete
fill 376 216 587 376 217 588 minecraft:black_concrete
fill 376 216 589 376 217 590 minecraft:purple_concrete
fill 376 216 591 376 241 592 minecraft:black_concrete
setblock 376 216 593 minecraft:purple_concrete
fill 377 216 558 379 216 558 minecraft:obsidian
fill 377 216 560 377 216 562 minecraft:obsidian
fill 377 216 564 377 216 566 minecraft:obsidian
fill 377 216 568 377 216 570 minecraft:obsidian
fill 377 216 572 377 216 574 minecraft:obsidian
fill 377 216 576 377 216 578 minecraft:obsidian
fill 377 216 580 377 216 582 minecraft:obsidian
fill 377 216 584 377 216 586 minecraft:obsidian
fill 377 216 588 377 216 590 minecraft:obsidian
fill 377 216 592 377 216 594 minecraft:obsidian
fill 377 216 596 377 216 598 minecraft:obsidian
fill 377 216 599 377 217 599 minecraft:black_concrete
fill 378 216 599 379 217 599 minecraft:purple_concrete
fill 379 216 557 380 217 557 minecraft:purple_concrete
fill 379 216 598 381 216 598 minecraft:obsidian
fill 380 216 599 381 241 599 minecraft:black_concrete
fill 381 216 557 382 217 557 minecraft:black_concrete
fill 381 216 558 383 216 558 minecraft:obsidian
fill 383 216 598 385 216 598 minecraft:obsidian
fill 385 216 557 386 241 557 minecraft:black_concrete
fill 385 216 558 387 216 558 minecraft:obsidian
setblock 386 216 599 minecraft:black_concrete
fill 387 216 557 388 216 557 minecraft:purple_concrete
fill 387 216 564 387 218 566 minecraft:purple_concrete
fill 387 216 598 389 216 598 minecraft:obsidian
fill 387 216 599 387 217 599 minecraft:purple_concrete
fill 388 216 567 390 219 567 minecraft:purple_concrete
fill 388 216 599 389 217 599 minecraft:black_concrete
fill 389 216 557 389 242 557 minecraft:black_concrete
fill 389 216 558 391 216 558 minecraft:obsidian
fill 390 216 599 391 216 599 minecraft:purple_concrete
fill 391 216 598 393 216 598 minecraft:obsidian
fill 392 216 599 392 241 599 minecraft:black_concrete
fill 393 216 558 395 216 558 minecraft:obsidian
setblock 393 216 562 minecraft:purple_concrete
fill 393 216 564 393 216 565 minecraft:purple_concrete
fill 394 216 562 394 218 562 minecraft:amethyst_block
setblock 394 216 564 minecraft:purple_concrete
fill 395 216 598 397 216 598 minecraft:obsidian
fill 397 216 557 398 241 557 minecraft:black_concrete
fill 397 216 558 399 216 558 minecraft:obsidian
fill 398 216 599 399 217 599 minecraft:purple_concrete
fill 399 216 557 400 217 557 minecraft:purple_concrete
fill 399 216 598 401 216 598 minecraft:obsidian
fill 400 216 599 401 241 599 minecraft:black_concrete
fill 401 216 557 402 217 557 minecraft:black_concrete
fill 401 216 558 403 216 558 minecraft:obsidian
fill 403 216 598 405 216 598 minecraft:obsidian
fill 405 216 558 407 216 558 minecraft:obsidian
fill 406 216 557 406 241 557 minecraft:black_concrete
fill 407 216 598 409 216 598 minecraft:obsidian
setblock 408 216 557 minecraft:purple_concrete
fill 409 216 557 410 242 557 minecraft:black_concrete
fill 409 216 558 411 216 558 minecraft:obsidian
fill 410 216 599 411 216 599 minecraft:purple_concrete
fill 411 216 557 411 217 557 minecraft:purple_concrete
fill 411 216 598 413 216 598 minecraft:obsidian
setblock 412 216 557 minecraft:black_concrete
fill 412 216 599 413 241 599 minecraft:black_concrete
fill 413 216 558 415 216 558 minecraft:obsidian
fill 415 216 598 417 216 598 minecraft:obsidian
fill 417 216 557 418 241 557 minecraft:black_concrete
fill 417 216 558 417 216 560 minecraft:obsidian
fill 417 216 562 417 216 564 minecraft:obsidian
fill 417 216 566 417 216 568 minecraft:obsidian
fill 417 216 570 417 216 572 minecraft:obsidian
fill 417 216 574 417 216 576 minecraft:obsidian
fill 417 216 578 417 216 580 minecraft:obsidian
fill 417 216 582 417 216 584 minecraft:obsidian
fill 417 216 586 417 216 588 minecraft:obsidian
fill 417 216 590 417 216 592 minecraft:obsidian
fill 417 216 594 417 216 596 minecraft:obsidian
fill 417 216 599 417 217 599 minecraft:black_concrete
fill 418 216 558 418 216 559 minecraft:purple_concrete
fill 418 216 560 418 217 560 minecraft:black_concrete
fill 418 216 568 418 241 569 minecraft:black_concrete
fill 418 216 570 418 217 571 minecraft:purple_concrete
fill 418 216 572 418 217 572 minecraft:black_concrete
fill 418 216 576 418 218 577 minecraft:black_concrete
fill 418 216 578 418 216 579 minecraft:purple_concrete
fill 418 216 580 418 242 580 minecraft:black_concrete
fill 418 216 582 418 217 582 minecraft:purple_concrete
setblock 418 216 583 minecraft:black_concrete
fill 418 216 588 418 241 589 minecraft:black_concrete
fill 418 216 590 418 217 591 minecraft:purple_concrete
fill 418 216 592 418 217 593 minecraft:black_concrete
fill 418 216 597 418 218 597 minecraft:black_concrete
fill 418 216 599 418 217 599 minecraft:purple_concrete
setblock 376 217 557 minecraft:purple_concrete
fill 376 217 561 376 220 561 minecraft:black_concrete
fill 376 217 577 376 217 578 minecraft:purple_concrete
setblock 376 217 581 minecraft:purple_concrete
fill 376 217 582 376 220 582 minecraft:black_concrete
fill 376 217 593 376 220 593 minecraft:black_concrete
setblock 376 217 598 minecraft:purple_concrete
fill 377 217 557 378 241 557 minecraft:black_concrete
fill 386 217 565 386 218 567 minecraft:purple_concrete
setblock 386 217 599 minecraft:purple_concrete
fill 387 217 557 387 220 557 minecraft:black_concrete
fill 387 217 563 387 218 563 minecraft:purple_concrete
fill 387 217 567 387 218 567 minecraft:purple_concrete
setblock 388 217 557 minecraft:purple_concrete
fill 388 217 568 388 219 568 minecraft:purple_concrete
setblock 390 217 557 minecraft:black_concrete
fill 390 217 599 391 220 599 minecraft:black_concrete
fill 391 217 557 392 217 557 minecraft:purple_concrete
setblock 393 217 557 minecraft:black_concrete
fill 393 217 563 393 217 564 minecraft:purple_concrete
fill 394 217 563 394 219 563 minecraft:amethyst_block
setblock 407 217 599 minecraft:purple_concrete
fill 408 217 557 408 220 557 minecraft:black_concrete
setblock 410 217 599 minecraft:purple_concrete
fill 411 217 599 411 220 599 minecraft:black_concrete
setblock 412 217 557 minecraft:purple_concrete
fill 418 217 558 418 220 558 minecraft:black_concrete
setblock 418 217 559 minecraft:purple_concrete
setblock 418 217 561 minecraft:black_concrete
setblock 418 217 562 minecraft:purple_concrete
fill 418 217 578 418 220 578 minecraft:black_concrete
setblock 418 217 579 minecraft:purple_concrete
setblock 418 217 583 minecraft:purple_concrete
setblock 418 217 594 minecraft:purple_concrete
fill 418 217 595 418 219 595 minecraft:black_concrete
fill 376 218 557 376 243 558 minecraft:black_concrete
fill 376 218 567 376 218 568 minecraft:purple_concrete
fill 376 218 569 376 243 570 minecraft:black_concrete
fill 376 218 576 376 219 576 minecraft:purple_concrete
fill 376 218 577 376 244 578 minecraft:black_concrete
setblock 376 218 579 minecraft:purple_concrete
fill 376 218 581 376 243 581 minecraft:black_concrete
fill 376 218 587 376 219 588 minecraft:purple_concrete
fill 376 218 589 376 243 590 minecraft:black_concrete
fill 376 218 598 376 244 598 minecraft:black_concrete
fill 376 218 599 377 218 599 minecraft:purple_concrete
fill 378 218 599 379 243 599 minecraft:black_concrete
fill 379 218 557 380 243 557 minecraft:black_concrete
fill 381 218 557 382 219 557 minecraft:purple_concrete
fill 384 218 599 385 219 599 minecraft:purple_concrete
fill 385 218 565 385 218 567 minecraft:purple_concrete
fill 386 218 564 386 220 564 minecraft:purple_concrete
fill 386 218 568 387 218 568 minecraft:purple_concrete
fill 386 218 599 387 243 599 minecraft:black_concrete
fill 388 218 557 388 243 557 minecraft:black_concrete
setblock 388 218 599 minecraft:purple_concrete
fill 389 218 568 389 220 568 minecraft:purple_concrete
fill 389 218 599 389 242 599 minecraft:black_concrete
setblock 390 218 557 minecraft:purple_concrete
fill 391 218 557 392 244 557 minecraft:black_concrete
fill 391 218 563 391 218 564 minecraft:purple_concrete
setblock 392 218 564 minecraft:purple_concrete
fill 393 218 557 393 219 557 minecraft:purple_concrete
fill 393 218 563 393 219 563 minecraft:amethyst_block
fill 396 218 599 397 219 599 minecraft:purple_concrete
fill 398 218 599 399 243 599 minecraft:black_concrete
fill 399 218 557 400 243 557 minecraft:black_concrete
fill 401 218 557 402 218 557 minecraft:purple_concrete
fill 405 218 599 405 219 599 minecraft:purple_concrete
fill 406 218 599 407 219 599 minecraft:black_concrete
fill 408 218 599 409 218 599 minecraft:purple_concrete
fill 410 218 599 410 243 599 minecraft:black_concrete
fill 411 218 557 412 243 557 minecraft:black_concrete
fill 413 218 557 414 219 557 minecraft:purple_concrete
fill 416 218 599 417 219 599 minecraft:purple_concrete
fill 418 218 559 418 243 559 minecraft:black_concrete
fill 418 218 560 418 218 561 minecraft:purple_concrete
fill 418 218 562 418 219 563 minecraft:black_concrete
fill 418 218 564 418 219 564 minecraft:purple_concrete
fill 418 218 570 418 243 571 minecraft:black_concrete
fill 418 218 572 418 219 573 minecraft:purple_concrete
fill 418 218 579 418 220 579 minecraft:black_concrete
setblock 418 218 581 minecraft:purple_concrete
fill 418 218 582 418 243 583 minecraft:black_concrete
fill 418 218 584 418 219 585 minecraft:purple_concrete
fill 418 218 590 418 243 591 minecraft:black_concrete
fill 418 218 592 418 218 593 minecraft:purple_concrete
fill 418 218 594 418 219 594 minecraft:black_concrete
fill 418 218 599 418 243 599 minecraft:black_concrete
setblock 376 219 564 minecraft:purple_concrete
setblock 376 219 567 minecraft:purple_concrete
fill 376 219 568 376 245 568 minecraft:black_concrete
setblock 376 219 575 minecraft:purple_concrete
fill 376 219 579 376 245 579 minecraft:black_concrete
setblock 376 219 594 minecraft:black_concrete
fill 376 219 595 376 219 596 minecraft:purple_concrete
setblock 376 219 599 minecraft:purple_concrete
fill 377 219 599 377 245 599 minecraft:black_concrete
setblock 384 219 566 minecraft:purple_concrete
fill 384 219 567 387 221 568 minecraft:black_concrete
fill 385 219 565 387 219 565 minecraft:purple_concrete
fill 385 219 566 387 221 566 minecraft:black_concrete
fill 385 219 569 387 221 569 minecraft:black_concrete
fill 387 219 564 387 220 564 minecraft:purple_concrete
fill 388 219 599 388 242 599 minecraft:black_concrete
fill 390 219 557 390 245 557 minecraft:black_concrete
fill 390 219 566 390 220 566 minecraft:purple_concrete
setblock 391 219 564 minecraft:purple_concrete
fill 393 219 586 394 220 587 minecraft:amethyst_block
setblock 393 219 599 minecraft:purple_concrete
setblock 394 219 557 minecraft:purple_concrete
fill 401 219 557 401 245 557 minecraft:black_concrete
setblock 402 219 557 minecraft:purple_concrete
setblock 404 219 599 minecraft:purple_concrete
setblock 405 219 557 minecraft:purple_concrete
fill 408 219 599 409 242 599 minecraft:black_concrete
fill 418 219 560 418 245 561 minecraft:black_concrete
setblock 418 219 565 minecraft:purple_concrete
setblock 418 219 576 minecraft:purple_concrete
fill 418 219 577 418 241 577 minecraft:black_concrete
fill 418 219 581 418 245 581 minecraft:black_concrete
fill 418 219 592 418 245 592 minecraft:black_concrete
setblock 418 219 593 minecraft:purple_concrete
fill 418 219 596 418 219 597 minecraft:purple_concrete
fill 376 220 562 376 221 562 minecraft:purple_concrete
fill 376 220 564 376 241 564 minecraft:black_concrete
fill 376 220 565 376 220 566 minecraft:purple_concrete
fill 376 220 567 376 245 567 minecraft:black_concrete
fill 376 220 573 376 221 574 minecraft:purple_concrete
fill 376 220 575 376 241 576 minecraft:black_concrete
fill 376 220 585 376 220 586 minecraft:purple_concrete
fill 376 220 587 376 245 588 minecraft:black_concrete
fill 376 220 594 376 221 594 minecraft:purple_concrete
fill 376 220 595 376 241 596 minecraft:black_concrete
setblock 376 220 597 minecraft:purple_concrete
fill 376 220 599 376 245 599 minecraft:black_concrete
fill 381 220 557 382 245 557 minecraft:black_concrete
fill 382 220 599 383 221 599 minecraft:purple_concrete
fill 383 220 557 384 220 557 minecraft:purple_concrete
fill 383 220 568 383 221 568 minecraft:black_concrete
fill 384 220 566 384 221 566 minecraft:black_concrete
fill 384 220 569 384 221 570 minecraft:black_concrete
fill 384 220 599 385 245 599 minecraft:black_concrete
fill 385 220 565 387 221 565 minecraft:black_concrete
fill 385 220 570 386 221 570 minecraft:black_concrete
fill 388 220 564 389 220 565 minecraft:purple_concrete
fill 388 220 566 388 221 568 minecraft:black_concrete
setblock 388 220 569 minecraft:purple_concrete
fill 389 220 567 389 221 567 minecraft:purple_concrete
setblock 390 220 565 minecraft:purple_concrete
fill 393 220 557 394 241 557 minecraft:black_concrete
fill 393 220 599 393 241 599 minecraft:black_concrete
fill 394 220 599 395 220 599 minecraft:purple_concrete
fill 395 220 557 396 221 557 minecraft:purple_concrete
fill 396 220 599 397 245 599 minecraft:black_concrete
fill 402 220 557 402 245 557 minecraft:black_concrete
fill 402 220 599 403 221 599 minecraft:purple_concrete
fill 403 220 557 404 220 557 minecraft:purple_concrete
fill 404 220 599 405 241 599 minecraft:black_concrete
fill 405 220 557 405 241 557 minecraft:black_concrete
setblock 406 220 599 minecraft:purple_concrete
fill 407 220 557 407 221 557 minecraft:purple_concrete
fill 407 220 599 407 244 599 minecraft:black_concrete
fill 413 220 557 414 245 557 minecraft:black_concrete
fill 414 220 599 415 221 599 minecraft:purple_concrete
fill 415 220 557 416 221 557 minecraft:purple_concrete
fill 416 220 599 417 245 599 minecraft:black_concrete
fill 418 220 562 418 244 562 minecraft:black_concrete
setblock 418 220 563 minecraft:purple_concrete
fill 418 220 564 418 241 565 minecraft:black_concrete
fill 418 220 566 418 221 567 minecraft:purple_concrete
fill 418 220 572 418 245 573 minecraft:black_concrete
fill 418 220 574 418 220 575 minecraft:purple_concrete
fill 418 220 576 418 241 576 minecraft:black_concrete
fill 418 220 584 418 245 585 minecraft:black_concrete
fill 418 220 586 418 221 587 minecraft:purple_concrete
fill 418 220 593 418 245 593 minecraft:black_concrete
fill 418 220 594 418 220 595 minecraft:purple_concrete
fill 418 220 596 418 241 597 minecraft:black_concrete
fill 418 220 598 418 221 598 minecraft:purple_concrete
setblock 376 221 561 minecraft:purple_concrete
fill 376 221 565 376 240 566 minecraft:black_concrete
setblock 376 221 582 minecraft:purple_concrete
setblock 376 221 585 minecraft:purple_concrete
fill 376 221 586 376 240 586 minecraft:black_concrete
setblock 376 221 593 minecraft:purple_concrete
fill 376 221 597 376 240 597 minecraft:black_concrete
setblock 379 221 560 minecraft:light[level=12]
setblock 379 221 568 minecraft:light[level=12]
setblock 379 221 576 minecraft:light[level=12]
setblock 379 221 584 minecraft:light[level=12]
setblock 379 221 592 minecraft:light[level=12]
fill 383 221 557 383 240 557 minecraft:black_concrete
setblock 383 221 567 minecraft:black_concrete
fill 383 221 569 383 221 570 minecraft:black_concrete
setblock 384 221 557 minecraft:purple_concrete
fill 384 221 571 385 221 571 minecraft:black_concrete
setblock 387 221 557 minecraft:purple_concrete
setblock 387 221 560 minecraft:light[level=12]
setblock 387 221 570 minecraft:black_concrete
setblock 387 221 576 minecraft:light[level=12]
setblock 387 221 584 minecraft:light[level=12]
setblock 387 221 592 minecraft:light[level=12]
fill 388 221 565 389 221 565 minecraft:purple_concrete
setblock 388 221 569 minecraft:black_concrete
fill 390 221 599 391 221 599 minecraft:purple_concrete
setblock 394 221 599 minecraft:purple_concrete
setblock 395 221 560 minecraft:light[level=12]
setblock 395 221 568 minecraft:light[level=12]
setblock 395 221 576 minecraft:light[level=12]
setblock 395 221 584 minecraft:light[level=12]
setblock 395 221 592 minecraft:light[level=12]
fill 395 221 599 395 240 599 minecraft:black_concrete
fill 403 221 557 404 240 557 minecraft:black_concrete
setblock 403 221 560 minecraft:light[level=12]
setblock 403 221 568 minecraft:light[level=12]
setblock 403 221 576 minecraft:light[level=12]
setblock 403 221 584 minecraft:light[level=12]
setblock 403 221 592 minecraft:light[level=12]
fill 406 221 599 406 240 599 minecraft:black_concrete
setblock 408 221 557 minecraft:purple_concrete
setblock 411 221 560 minecraft:light[level=12]
setblock 411 221 568 minecraft:light[level=12]
setblock 411 221 576 minecraft:light[level=12]
setblock 411 221 584 minecraft:light[level=12]
setblock 411 221 592 minecraft:light[level=12]
setblock 411 221 599 minecraft:purple_concrete
setblock 418 221 558 minecraft:purple_concrete
fill 418 221 563 418 240 563 minecraft:black_concrete
fill 418 221 574 418 240 574 minecraft:black_concrete
setblock 418 221 575 minecraft:purple_concrete
fill 418 221 578 418 221 579 minecraft:purple_concrete
fill 418 221 594 418 240 595 minecraft:black_concrete
fill 376 222 561 376 240 562 minecraft:black_concrete
fill 376 222 573 376 240 574 minecraft:black_concrete
fill 376 222 582 376 243 582 minecraft:black_concrete
fill 376 222 585 376 240 585 minecraft:black_concrete
fill 376 222 593 376 240 594 minecraft:black_concrete
fill 382 222 599 383 240 599 minecraft:black_concrete
fill 384 222 557 384 240 557 minecraft:black_concrete
fill 387 222 557 387 243 557 minecraft:black_concrete
fill 390 222 599 391 240 599 minecraft:black_concrete
fill 394 222 599 394 240 599 minecraft:black_concrete
fill 395 222 557 396 240 557 minecraft:black_concrete
fill 402 222 599 403 240 599 minecraft:black_concrete
fill 407 222 557 408 240 557 minecraft:black_concrete
fill 411 222 599 411 243 599 minecraft:black_concrete
fill 414 222 599 415 240 599 minecraft:black_concrete
fill 415 222 557 416 240 557 minecraft:black_concrete
fill 418 222 558 418 243 558 minecraft:black_concrete
fill 418 222 566 418 240 567 minecraft:black_concrete
fill 418 222 575 418 240 575 minecraft:black_concrete
fill 418 222 578 418 243 579 minecraft:black_concrete
fill 418 222 586 418 240 587 minecraft:black_concrete
fill 418 222 598 418 240 598 minecraft:black_concrete
fill 377 227 559 396 228 597 minecraft:black_concrete
fill 378 227 558 416 228 558 minecraft:black_concrete
fill 378 227 598 416 228 598 minecraft:black_concrete
fill 397 227 559 397 235 572 minecraft:black_concrete
fill 397 227 574 397 235 597 minecraft:black_concrete
fill 398 227 559 398 235 571 minecraft:black_concrete
fill 398 227 575 398 235 597 minecraft:black_concrete
fill 399 227 559 417 228 570 minecraft:black_concrete
fill 399 227 576 417 228 597 minecraft:black_concrete
fill 400 227 571 417 235 571 minecraft:black_concrete
fill 400 227 575 417 235 575 minecraft:black_concrete
fill 401 227 572 417 235 572 minecraft:black_concrete
fill 401 227 574 417 235 574 minecraft:black_concrete
fill 402 227 573 417 236 573 minecraft:black_concrete
fill 377 229 560 396 230 596 minecraft:black_concrete
fill 378 229 559 396 230 559 minecraft:black_concrete
fill 378 229 597 396 230 597 minecraft:black_concrete
fill 379 229 558 415 230 558 minecraft:black_concrete
fill 379 229 598 415 230 598 minecraft:black_concrete
fill 399 229 559 416 230 570 minecraft:black_concrete
fill 399 229 576 416 230 597 minecraft:black_concrete
fill 417 229 560 417 230 570 minecraft:black_concrete
fill 417 229 576 417 230 596 minecraft:black_concrete
fill 377 231 561 396 232 595 minecraft:black_concrete
fill 378 231 560 396 232 560 minecraft:black_concrete
fill 378 231 596 396 232 596 minecraft:black_concrete
fill 379 231 559 396 232 559 minecraft:black_concrete
fill 379 231 597 396 232 597 minecraft:black_concrete
fill 380 231 558 414 232 558 minecraft:black_concrete
fill 380 231 598 414 232 598 minecraft:black_concrete
fill 399 231 559 415 232 570 minecraft:black_concrete
fill 399 231 576 415 232 597 minecraft:black_concrete
fill 416 231 560 416 232 570 minecraft:black_concrete
fill 416 231 576 416 232 596 minecraft:black_concrete
fill 417 231 561 417 232 570 minecraft:black_concrete
fill 417 231 576 417 232 595 minecraft:black_concrete
fill 377 233 562 396 233 594 minecraft:black_concrete
fill 378 233 561 396 234 561 minecraft:black_concrete
fill 378 233 595 396 234 595 minecraft:black_concrete
fill 379 233 560 396 234 560 minecraft:black_concrete
fill 379 233 596 396 234 596 minecraft:black_concrete
fill 380 233 559 396 234 559 minecraft:black_concrete
fill 380 233 597 396 234 597 minecraft:black_concrete
fill 381 233 558 413 233 558 minecraft:black_concrete
fill 381 233 598 413 233 598 minecraft:black_concrete
fill 399 233 559 414 234 570 minecraft:black_concrete
fill 399 233 576 414 234 597 minecraft:black_concrete
fill 415 233 560 415 234 570 minecraft:black_concrete
fill 415 233 576 415 234 596 minecraft:black_concrete
fill 416 233 561 416 234 570 minecraft:black_concrete
fill 416 233 576 416 234 595 minecraft:black_concrete
fill 417 233 562 417 233 570 minecraft:black_concrete
fill 417 233 576 417 233 594 minecraft:black_concrete
fill 377 234 563 396 235 593 minecraft:black_concrete
fill 378 234 562 396 235 562 minecraft:black_concrete
fill 378 234 594 396 235 594 minecraft:black_concrete
fill 382 234 558 412 235 558 minecraft:black_concrete
fill 382 234 598 412 235 598 minecraft:black_concrete
fill 417 234 563 417 235 570 minecraft:black_concrete
fill 417 234 576 417 235 593 minecraft:black_concrete
fill 379 235 561 396 235 561 minecraft:black_concrete
fill 379 235 595 396 235 595 minecraft:black_concrete
fill 380 235 560 396 235 560 minecraft:black_concrete
fill 380 235 596 396 235 596 minecraft:black_concrete
fill 381 235 559 396 235 559 minecraft:black_concrete
fill 381 235 597 396 235 597 minecraft:black_concrete
fill 399 235 559 413 235 570 minecraft:black_concrete
fill 399 235 576 413 235 597 minecraft:black_concrete
fill 414 235 560 414 235 570 minecraft:black_concrete
fill 414 235 576 414 235 596 minecraft:black_concrete
fill 415 235 561 415 235 570 minecraft:black_concrete
fill 415 235 576 415 235 595 minecraft:black_concrete
fill 416 235 562 416 235 570 minecraft:black_concrete
fill 416 235 576 416 235 594 minecraft:black_concrete
fill 377 236 564 396 236 592 minecraft:black_concrete
fill 378 236 563 416 236 563 minecraft:black_concrete
fill 378 236 593 416 236 593 minecraft:black_concrete
fill 379 236 562 415 237 562 minecraft:black_concrete
fill 379 236 594 415 237 594 minecraft:black_concrete
fill 380 236 561 414 237 561 minecraft:black_concrete
fill 380 236 595 414 237 595 minecraft:black_concrete
fill 381 236 560 413 237 560 minecraft:black_concrete
fill 381 236 596 413 237 596 minecraft:black_concrete
fill 382 236 559 412 236 559 minecraft:black_concrete
fill 382 236 597 412 236 597 minecraft:black_concrete
fill 383 236 558 411 236 558 minecraft:black_concrete
fill 383 236 598 411 236 598 minecraft:black_concrete
fill 397 236 564 397 236 571 minecraft:black_concrete
setblock 397 236 572 minecraft:purple_concrete
fill 397 236 574 397 236 575 minecraft:purple_concrete
fill 397 236 576 417 236 592 minecraft:black_concrete
fill 398 236 564 417 236 570 minecraft:black_concrete
setblock 398 236 571 minecraft:purple_concrete
setblock 398 236 575 minecraft:purple_concrete
setblock 400 236 571 minecraft:purple_concrete
setblock 400 236 575 minecraft:purple_concrete
fill 401 236 571 417 236 571 minecraft:black_concrete
setblock 401 236 572 minecraft:purple_concrete
setblock 401 236 574 minecraft:purple_concrete
fill 401 236 575 417 236 575 minecraft:black_concrete
fill 402 236 572 417 236 572 minecraft:black_concrete
fill 402 236 574 417 236 574 minecraft:black_concrete
fill 377 237 558 377 237 564 minecraft:obsidian
fill 377 237 565 395 237 591 minecraft:black_concrete
fill 377 237 592 377 237 598 minecraft:obsidian
fill 378 237 558 378 237 563 minecraft:obsidian
fill 378 237 564 416 238 564 minecraft:black_concrete
fill 378 237 592 416 238 592 minecraft:black_concrete
fill 378 237 593 378 237 598 minecraft:obsidian
fill 379 237 558 379 237 561 minecraft:obsidian
fill 379 237 563 415 238 563 minecraft:black_concrete
fill 379 237 593 415 238 593 minecraft:black_concrete
fill 379 237 595 379 237 598 minecraft:obsidian
fill 380 237 558 380 237 560 minecraft:obsidian
fill 380 237 596 380 237 598 minecraft:obsidian
fill 381 237 558 382 237 559 minecraft:obsidian
fill 381 237 597 382 237 598 minecraft:obsidian
setblock 383 237 558 minecraft:obsidian
fill 383 237 559 411 238 559 minecraft:black_concrete
fill 383 237 597 411 238 597 minecraft:black_concrete
setblock 383 237 598 minecraft:obsidian
fill 384 237 558 410 237 558 minecraft:black_concrete
fill 384 237 598 410 237 598 minecraft:black_concrete
fill 396 237 565 396 237 571 minecraft:black_concrete
setblock 396 237 572 minecraft:red_nether_bricks
fill 396 237 573 396 239 573 minecraft:quartz_block
setblock 396 237 574 minecraft:red_nether_bricks
fill 396 237 575 396 237 576 minecraft:crying_obsidian
fill 396 237 577 397 237 591 minecraft:black_concrete
fill 397 237 565 397 237 570 minecraft:black_concrete
fill 397 237 571 397 237 572 minecraft:shroomlight
fill 397 237 574 397 237 575 minecraft:shroomlight
fill 397 237 576 398 237 576 minecraft:crying_obsidian
fill 398 237 565 417 237 569 minecraft:black_concrete
setblock 398 237 570 minecraft:crying_obsidian
setblock 398 237 571 minecraft:shroomlight
setblock 398 237 575 minecraft:shroomlight
fill 398 237 577 400 237 577 minecraft:crying_obsidian
fill 398 237 578 417 237 591 minecraft:black_concrete
fill 399 237 570 399 239 570 minecraft:quartz_block
fill 399 237 576 399 239 576 minecraft:quartz_block
setblock 400 237 570 minecraft:crying_obsidian
fill 400 237 571 401 237 571 minecraft:shroomlight
fill 400 237 575 401 237 575 minecraft:shroomlight
fill 400 237 576 401 237 576 minecraft:crying_obsidian
fill 401 237 570 417 237 570 minecraft:black_concrete
setblock 401 237 572 minecraft:shroomlight
setblock 401 237 574 minecraft:shroomlight
fill 401 237 577 417 237 577 minecraft:black_concrete
fill 402 237 571 417 237 571 minecraft:black_concrete
setblock 402 237 572 minecraft:red_nether_bricks
fill 402 237 573 402 239 573 minecraft:quartz_block
setblock 402 237 574 minecraft:red_nether_bricks
setblock 402 237 575 minecraft:crying_obsidian
fill 402 237 576 417 237 576 minecraft:black_concrete
fill 403 237 572 417 237 575 minecraft:black_concrete
fill 411 237 558 417 237 558 minecraft:obsidian
fill 411 237 598 417 237 598 minecraft:obsidian
fill 412 237 559 417 237 559 minecraft:obsidian
fill 412 237 597 417 237 597 minecraft:obsidian
fill 414 237 560 417 237 560 minecraft:obsidian
fill 414 237 596 417 237 596 minecraft:obsidian
fill 415 237 561 417 237 561 minecraft:obsidian
fill 415 237 595 417 237 595 minecraft:obsidian
fill 416 237 562 417 237 563 minecraft:obsidian
fill 416 237 593 417 237 594 minecraft:obsidian
setblock 417 237 564 minecraft:obsidian
setblock 417 237 592 minecraft:obsidian
fill 377 238 566 392 238 590 minecraft:black_concrete
fill 378 238 565 416 239 565 minecraft:black_concrete
fill 378 238 591 416 239 591 minecraft:black_concrete
fill 380 238 562 414 238 562 minecraft:black_concrete
fill 380 238 594 414 238 594 minecraft:black_concrete
fill 381 238 561 413 238 561 minecraft:black_concrete
fill 381 238 595 413 238 595 minecraft:black_concrete
fill 382 238 560 412 238 560 minecraft:black_concrete
fill 382 238 596 412 238 596 minecraft:black_concrete
fill 385 238 558 409 238 558 minecraft:black_concrete
fill 385 238 598 409 238 598 minecraft:black_concrete
fill 393 238 566 393 238 572 minecraft:black_concrete
fill 393 238 573 395 238 573 minecraft:red_nether_bricks
fill 393 238 574 393 238 590 minecraft:black_concrete
fill 394 238 566 394 238 570 minecraft:black_concrete
fill 394 238 571 395 238 572 minecraft:red_nether_bricks
fill 394 238 574 395 238 575 minecraft:red_nether_bricks
fill 394 238 576 394 238 590 minecraft:black_concrete
fill 395 238 566 395 238 569 minecraft:black_concrete
fill 395 238 570 396 240 570 minecraft:red_nether_bricks
fill 395 238 576 396 240 576 minecraft:red_nether_bricks
setblock 395 238 577 minecraft:purple_concrete
fill 395 238 578 395 238 590 minecraft:black_concrete
fill 396 238 566 417 238 568 minecraft:black_concrete
fill 396 238 569 402 238 569 minecraft:red_nether_bricks
fill 396 238 571 396 239 572 minecraft:quartz_block
fill 396 238 574 396 239 575 minecraft:quartz_block
fill 396 238 577 402 238 577 minecraft:red_nether_bricks
fill 396 238 578 401 238 578 minecraft:purple_concrete
fill 396 238 579 417 238 590 minecraft:black_concrete
fill 397 238 570 398 239 570 minecraft:quartz_block
setblock 397 238 571 minecraft:red_nether_bricks
setblock 397 238 575 minecraft:red_nether_bricks
fill 397 238 576 398 239 576 minecraft:quartz_block
fill 400 238 570 401 239 570 minecraft:quartz_block
fill 400 238 576 401 239 576 minecraft:quartz_block
setblock 401 238 571 minecraft:red_nether_bricks
setblock 401 238 575 minecraft:red_nether_bricks
fill 402 238 570 403 243 570 minecraft:red_nether_bricks
fill 402 238 571 402 239 572 minecraft:quartz_block
fill 402 238 574 402 239 575 minecraft:quartz_block
fill 402 238 576 403 243 576 minecraft:red_nether_bricks
fill 402 238 578 417 238 578 minecraft:black_concrete
fill 403 238 569 417 238 569 minecraft:black_concrete
fill 403 238 571 404 238 575 minecraft:red_nether_bricks
fill 403 238 577 417 238 577 minecraft:black_concrete
fill 404 238 570 417 238 570 minecraft:black_concrete
fill 404 238 576 417 238 576 minecraft:black_concrete
fill 405 238 571 417 238 572 minecraft:black_concrete
fill 405 238 573 405 249 573 minecraft:red_nether_bricks
fill 405 238 574 417 238 575 minecraft:black_concrete
fill 406 238 573 417 238 573 minecraft:black_concrete
fill 377 239 567 387 239 589 minecraft:black_concrete
fill 378 239 566 416 240 566 minecraft:black_concrete
fill 378 239 590 416 240 590 minecraft:black_concrete
fill 379 239 564 415 239 564 minecraft:black_concrete
fill 379 239 592 415 239 592 minecraft:black_concrete
fill 380 239 563 414 239 563 minecraft:black_concrete
fill 380 239 593 414 239 593 minecraft:black_concrete
fill 381 239 562 413 239 562 minecraft:black_concrete
fill 381 239 594 413 239 594 minecraft:black_concrete
fill 382 239 561 412 239 561 minecraft:black_concrete
fill 382 239 595 412 239 595 minecraft:black_concrete
fill 383 239 560 411 239 560 minecraft:black_concrete
fill 383 239 596 411 239 596 minecraft:black_concrete
fill 384 239 559 410 239 559 minecraft:black_concrete
fill 384 239 597 410 239 597 minecraft:black_concrete
fill 386 239 558 408 239 558 minecraft:black_concrete
fill 386 239 598 408 239 598 minecraft:black_concrete
fill 388 239 567 388 239 571 minecraft:black_concrete
fill 388 239 572 394 245 574 minecraft:nether_bricks
fill 388 239 575 388 239 589 minecraft:black_concrete
fill 389 239 567 392 239 570 minecraft:black_concrete
fill 389 239 571 393 245 571 minecraft:nether_bricks
fill 389 239 575 393 245 575 minecraft:nether_bricks
fill 389 239 576 392 239 589 minecraft:black_concrete
fill 393 239 567 393 239 569 minecraft:black_concrete
fill 393 239 570 394 239 570 minecraft:red_nether_bricks
fill 393 239 576 394 239 576 minecraft:red_nether_bricks
fill 393 239 577 393 239 589 minecraft:black_concrete
fill 394 239 567 394 239 568 minecraft:black_concrete
fill 394 239 569 396 246 569 minecraft:red_nether_bricks
setblock 394 239 571 minecraft:red_nether_bricks
setblock 394 239 575 minecraft:red_nether_bricks
fill 394 239 577 396 246 577 minecraft:red_nether_bricks
setblock 394 239 578 minecraft:purple_concrete
fill 394 239 579 394 239 589 minecraft:black_concrete
fill 395 239 567 397 239 567 minecraft:black_concrete
fill 395 239 568 403 246 568 minecraft:red_nether_bricks
setblock 395 239 571 minecraft:quartz_block
setblock 395 239 572 minecraft:red_nether_bricks
setblock 395 239 573 minecraft:quartz_block
setblock 395 239 574 minecraft:red_nether_bricks
setblock 395 239 575 minecraft:quartz_block
fill 395 239 578 403 246 578 minecraft:red_nether_bricks
fill 395 239 579 397 239 579 minecraft:purple_concrete
fill 395 239 580 396 239 589 minecraft:black_concrete
setblock 397 239 569 minecraft:quartz_block
setblock 397 239 577 minecraft:quartz_block
fill 397 239 580 399 239 580 minecraft:purple_concrete
fill 397 239 581 417 239 589 minecraft:black_concrete
fill 398 239 567 400 248 567 minecraft:red_nether_bricks
fill 398 239 569 398 243 569 minecraft:red_nether_bricks
fill 398 239 577 398 243 577 minecraft:red_nether_bricks
fill 398 239 579 400 248 579 minecraft:red_nether_bricks
setblock 399 239 569 minecraft:quartz_block
setblock 399 239 577 minecraft:quartz_block
fill 400 239 569 400 243 569 minecraft:red_nether_bricks
fill 400 239 577 400 243 577 minecraft:red_nether_bricks
fill 400 239 580 417 239 580 minecraft:black_concrete
fill 401 239 567 417 239 567 minecraft:black_concrete
setblock 401 239 569 minecraft:quartz_block
setblock 401 239 577 minecraft:quartz_block
setblock 401 239 579 minecraft:purple_concrete
fill 402 239 569 404 246 569 minecraft:red_nether_bricks
fill 402 239 577 404 246 577 minecraft:red_nether_bricks
fill 402 239 579 417 239 579 minecraft:black_concrete
setblock 403 239 571 minecraft:quartz_block
fill 403 239 572 406 243 572 minecraft:red_nether_bricks
setblock 403 239 573 minecraft:quartz_block
fill 403 239 574 406 243 574 minecraft:red_nether_bricks
setblock 403 239 575 minecraft:quartz_block
fill 404 239 568 417 239 568 minecraft:black_concrete
fill 404 239 570 405 247 571 minecraft:red_nether_bricks
fill 404 239 573 404 246 573 minecraft:red_nether_bricks
fill 404 239 575 405 247 576 minecraft:red_nether_bricks
fill 404 239 578 417 239 578 minecraft:black_concrete
fill 405 239 569 417 239 569 minecraft:black_concrete
fill 405 239 577 417 239 577 minecraft:black_concrete
fill 406 239 570 417 239 570 minecraft:black_concrete
fill 406 239 571 406 248 571 minecraft:red_nether_bricks
fill 406 239 573 406 248 573 minecraft:red_nether_bricks
fill 406 239 575 406 248 575 minecraft:red_nether_bricks
fill 406 239 576 417 239 576 minecraft:black_concrete
fill 407 239 571 417 239 575 minecraft:black_concrete
fill 377 240 568 385 240 588 minecraft:black_concrete
fill 378 240 567 394 240 567 minecraft:black_concrete
fill 378 240 589 416 241 589 minecraft:black_concrete
fill 379 240 565 415 240 565 minecraft:black_concrete
fill 379 240 591 415 240 591 minecraft:black_concrete
fill 380 240 564 414 240 564 minecraft:black_concrete
fill 380 240 592 414 240 592 minecraft:black_concrete
fill 381 240 563 413 241 563 minecraft:black_concrete
fill 381 240 593 413 241 593 minecraft:black_concrete
fill 382 240 562 412 241 562 minecraft:black_concrete
fill 382 240 594 412 241 594 minecraft:black_concrete
fill 383 240 561 411 240 561 minecraft:black_concrete
fill 383 240 595 411 240 595 minecraft:black_concrete
fill 384 240 560 410 240 560 minecraft:black_concrete
fill 384 240 596 410 240 596 minecraft:black_concrete
fill 385 240 559 409 240 559 minecraft:black_concrete
fill 385 240 597 409 240 597 minecraft:black_concrete
fill 386 240 568 386 240 572 minecraft:black_concrete
fill 386 240 573 387 244 573 minecraft:nether_bricks
fill 386 240 574 386 240 588 minecraft:black_concrete
fill 387 240 558 407 240 558 minecraft:black_concrete
fill 387 240 568 387 240 570 minecraft:black_concrete
fill 387 240 571 387 242 572 minecraft:nether_bricks
fill 387 240 574 387 242 575 minecraft:nether_bricks
fill 387 240 576 387 240 588 minecraft:black_concrete
fill 387 240 598 407 240 598 minecraft:black_concrete
fill 388 240 568 392 240 569 minecraft:black_concrete
fill 388 240 570 388 244 571 minecraft:nether_bricks
fill 388 240 575 388 244 576 minecraft:nether_bricks
fill 388 240 577 391 240 588 minecraft:black_concrete
fill 389 240 570 394 244 570 minecraft:nether_bricks
fill 389 240 576 394 244 576 minecraft:nether_bricks
setblock 392 240 577 minecraft:crying_obsidian
fill 392 240 578 392 240 588 minecraft:black_concrete
setblock 393 240 568 minecraft:black_concrete
setblock 393 240 569 minecraft:red_nether_bricks
setblock 393 240 577 minecraft:red_nether_bricks
fill 393 240 578 393 240 579 minecraft:crying_obsidian
fill 393 240 580 393 240 588 minecraft:black_concrete
fill 394 240 568 394 248 568 minecraft:red_nether_bricks
fill 394 240 571 395 244 571 minecraft:nether_bricks
fill 394 240 575 395 244 575 minecraft:nether_bricks
fill 394 240 578 394 248 578 minecraft:red_nether_bricks
fill 394 240 579 394 240 580 minecraft:crying_obsidian
fill 394 240 581 395 240 588 minecraft:black_concrete
fill 395 240 567 397 247 567 minecraft:red_nether_bricks
fill 395 240 572 395 242 574 minecraft:nether_bricks
fill 395 240 579 397 247 579 minecraft:red_nether_bricks
fill 395 240 580 396 240 580 minecraft:crying_obsidian
fill 396 240 571 396 240 572 minecraft:red_nether_bricks
fill 396 240 574 396 240 575 minecraft:red_nether_bricks
fill 396 240 581 401 240 581 minecraft:crying_obsidian
fill 396 240 582 417 240 588 minecraft:black_concrete
fill 397 240 569 397 241 570 minecraft:red_nether_bricks
fill 397 240 576 397 241 577 minecraft:red_nether_bricks
setblock 398 240 570 minecraft:red_nether_bricks
setblock 398 240 576 minecraft:red_nether_bricks
fill 399 240 569 399 242 569 minecraft:red_nether_bricks
fill 399 240 577 399 242 577 minecraft:red_nether_bricks
fill 400 240 570 401 240 570 minecraft:red_nether_bricks
fill 400 240 576 401 240 576 minecraft:red_nether_bricks
fill 400 240 580 402 240 580 minecraft:crying_obsidian
fill 401 240 567 403 247 567 minecraft:red_nether_bricks
fill 401 240 569 401 244 569 minecraft:red_nether_bricks
fill 401 240 577 401 244 577 minecraft:red_nether_bricks
fill 401 240 579 403 247 579 minecraft:red_nether_bricks
fill 402 240 571 402 240 572 minecraft:red_nether_bricks
fill 402 240 574 402 240 575 minecraft:red_nether_bricks
fill 402 240 581 417 240 581 minecraft:black_concrete
fill 403 240 571 403 244 571 minecraft:red_nether_bricks
fill 403 240 573 403 242 573 minecraft:red_nether_bricks
fill 403 240 575 403 244 575 minecraft:red_nether_bricks
fill 403 240 580 417 240 580 minecraft:black_concrete
fill 404 240 567 416 240 567 minecraft:black_concrete
fill 404 240 568 404 248 568 minecraft:red_nether_bricks
fill 404 240 578 404 248 578 minecraft:red_nether_bricks
fill 404 240 579 417 240 579 minecraft:black_concrete
fill 405 240 568 417 240 568 minecraft:black_concrete
fill 405 240 569 405 248 569 minecraft:red_nether_bricks
fill 405 240 577 405 248 577 minecraft:red_nether_bricks
fill 405 240 578 417 240 578 minecraft:black_concrete
fill 406 240 569 417 240 569 minecraft:black_concrete
fill 406 240 570 406 248 570 minecraft:red_nether_bricks
fill 406 240 576 406 248 576 minecraft:red_nether_bricks
fill 406 240 577 417 240 577 minecraft:black_concrete
fill 407 240 570 417 240 570 minecraft:black_concrete
fill 407 240 571 407 247 575 minecraft:red_nether_bricks
fill 407 240 576 417 240 576 minecraft:black_concrete
fill 408 240 571 417 240 575 minecraft:black_concrete
fill 376 241 561 376 243 561 minecraft:black_concrete
setblock 376 241 562 minecraft:purple_concrete
fill 376 241 565 376 241 566 minecraft:purple_concrete
fill 376 241 573 376 241 574 minecraft:purple_concrete
fill 376 241 585 376 241 586 minecraft:purple_concrete
fill 376 241 593 376 243 593 minecraft:black_concrete
setblock 376 241 594 minecraft:purple_concrete
setblock 376 241 597 minecraft:purple_concrete
fill 377 241 569 385 241 587 minecraft:black_concrete
fill 378 241 567 392 241 568 minecraft:black_concrete
fill 378 241 588 416 241 588 minecraft:black_concrete
fill 379 241 566 395 241 566 minecraft:black_concrete
fill 379 241 590 415 241 590 minecraft:black_concrete
fill 380 241 565 414 241 565 minecraft:black_concrete
fill 380 241 591 414 241 591 minecraft:black_concrete
fill 381 241 564 413 242 564 minecraft:black_concrete
fill 381 241 592 413 242 592 minecraft:black_concrete
fill 382 241 599 383 241 599 minecraft:purple_concrete
fill 383 241 557 384 241 557 minecraft:purple_concrete
fill 384 241 561 410 241 561 minecraft:black_concrete
fill 384 241 595 410 241 595 minecraft:black_concrete
fill 385 241 560 409 241 560 minecraft:black_concrete
fill 385 241 596 409 241 596 minecraft:black_concrete
fill 386 241 559 408 241 559 minecraft:black_concrete
fill 386 241 569 386 247 570 minecraft:black_concrete
fill 386 241 571 386 243 572 minecraft:nether_bricks
fill 386 241 574 386 243 575 minecraft:nether_bricks
fill 386 241 576 386 244 587 minecraft:black_concrete
fill 386 241 597 408 241 597 minecraft:black_concrete
fill 387 241 569 388 246 569 minecraft:black_concrete
fill 387 241 570 387 243 570 minecraft:nether_bricks
fill 387 241 576 387 243 576 minecraft:nether_bricks
fill 387 241 577 388 243 587 minecraft:black_concrete
fill 388 241 558 406 241 558 minecraft:black_concrete
fill 388 241 598 406 241 598 minecraft:black_concrete
fill 389 241 569 393 243 569 minecraft:nether_bricks
fill 389 241 577 393 243 577 minecraft:nether_bricks
fill 389 241 578 390 241 587 minecraft:black_concrete
fill 390 241 599 390 243 599 minecraft:black_concrete
fill 391 241 578 392 241 578 minecraft:purple_concrete
fill 391 241 579 391 241 587 minecraft:black_concrete
setblock 391 241 599 minecraft:purple_concrete
fill 392 241 579 392 241 580 minecraft:purple_concrete
fill 392 241 581 392 241 587 minecraft:black_concrete
setblock 393 241 567 minecraft:black_concrete
fill 393 241 568 393 247 568 minecraft:red_nether_bricks
fill 393 241 578 393 247 578 minecraft:red_nether_bricks
fill 393 241 580 393 241 581 minecraft:purple_concrete
fill 393 241 582 394 241 587 minecraft:black_concrete
fill 394 241 567 394 246 567 minecraft:red_nether_bricks
fill 394 241 579 394 246 579 minecraft:red_nether_bricks
fill 394 241 581 395 241 581 minecraft:purple_concrete
fill 394 241 599 395 241 599 minecraft:purple_concrete
fill 395 241 557 396 241 557 minecraft:purple_concrete
fill 395 241 570 395 243 570 minecraft:nether_bricks
fill 395 241 576 395 243 576 minecraft:nether_bricks
fill 395 241 582 401 241 582 minecraft:purple_concrete
fill 395 241 583 396 241 587 minecraft:black_concrete
fill 396 241 566 402 245 566 minecraft:red_nether_bricks
fill 396 241 570 396 243 570 minecraft:red_nether_bricks
setblock 396 241 571 minecraft:nether_bricks
setblock 396 241 575 minecraft:nether_bricks
fill 396 241 576 396 243 576 minecraft:red_nether_bricks
fill 396 241 580 402 245 580 minecraft:red_nether_bricks
fill 397 241 583 399 241 583 minecraft:purple_concrete
fill 397 241 584 417 241 587 minecraft:black_concrete
fill 400 241 583 417 241 583 minecraft:black_concrete
setblock 401 241 570 minecraft:red_nether_bricks
setblock 401 241 576 minecraft:red_nether_bricks
setblock 402 241 571 minecraft:red_nether_bricks
setblock 402 241 575 minecraft:red_nether_bricks
fill 402 241 581 403 241 581 minecraft:purple_concrete
fill 402 241 582 417 241 582 minecraft:black_concrete
fill 402 241 599 403 241 599 minecraft:purple_concrete
fill 403 241 557 404 241 557 minecraft:purple_concrete
fill 403 241 566 415 241 566 minecraft:black_concrete
fill 403 241 580 404 241 580 minecraft:purple_concrete
fill 404 241 567 404 246 567 minecraft:red_nether_bricks
fill 404 241 579 404 246 579 minecraft:red_nether_bricks
fill 404 241 581 417 241 581 minecraft:black_concrete
fill 405 241 567 416 241 567 minecraft:black_concrete
fill 405 241 568 405 247 568 minecraft:red_nether_bricks
fill 405 241 578 405 247 578 minecraft:red_nether_bricks
fill 405 241 579 417 241 580 minecraft:black_concrete
fill 406 241 568 416 241 568 minecraft:black_concrete
fill 406 241 569 406 247 569 minecraft:red_nether_bricks
fill 406 241 577 406 247 577 minecraft:red_nether_bricks
fill 406 241 578 417 241 578 minecraft:black_concrete
setblock 406 241 599 minecraft:purple_concrete
setblock 407 241 557 minecraft:purple_concrete
fill 407 241 569 417 241 569 minecraft:black_concrete
fill 407 241 570 407 247 570 minecraft:red_nether_bricks
fill 407 241 576 407 247 576 minecraft:red_nether_bricks
fill 407 241 577 417 241 577 minecraft:black_concrete
fill 408 241 557 408 243 557 minecraft:black_concrete
fill 408 241 570 417 241 571 minecraft:black_concrete
fill 408 241 572 408 246 574 minecraft:red_nether_bricks
fill 408 241 575 417 241 576 minecraft:black_concrete
fill 409 241 572 417 242 574 minecraft:black_concrete
fill 414 241 599 415 241 599 minecraft:purple_concrete
fill 415 241 557 416 241 557 minecraft:purple_concrete
setblock 418 241 563 minecraft:purple_concrete
fill 418 241 566 418 241 567 minecraft:purple_concrete
fill 418 241 574 418 241 575 minecraft:purple_concrete
fill 418 241 586 418 241 587 minecraft:purple_concrete
fill 418 241 594 418 244 594 minecraft:black_concrete
setblock 418 241 595 minecraft:purple_concrete
setblock 418 241 598 minecraft:purple_concrete
fill 376 242 562 376 247 562 minecraft:black_concrete
fill 376 242 563 376 242 564 minecraft:purple_concrete
fill 376 242 565 376 247 566 minecraft:black_concrete
fill 376 242 571 376 243 572 minecraft:purple_concrete
fill 376 242 573 385 243 574 minecraft:black_concrete
setblock 376 242 575 minecraft:purple_concrete
fill 376 242 576 385 243 576 minecraft:black_concrete
fill 376 242 583 376 243 584 minecraft:purple_concrete
fill 376 242 585 376 247 586 minecraft:black_concrete
setblock 376 242 591 minecraft:black_concrete
fill 376 242 592 376 243 592 minecraft:purple_concrete
fill 376 242 594 376 247 594 minecraft:black_concrete
fill 376 242 595 376 242 596 minecraft:purple_concrete
fill 376 242 597 376 247 597 minecraft:black_concrete
fill 377 242 557 377 243 557 minecraft:purple_concrete
fill 377 242 571 385 242 572 minecraft:black_concrete
fill 377 242 575 385 243 575 minecraft:black_concrete
fill 377 242 577 385 242 585 minecraft:black_concrete
setblock 378 242 557 minecraft:black_concrete
fill 378 242 569 385 242 570 minecraft:black_concrete
fill 378 242 586 385 242 587 minecraft:black_concrete
fill 379 242 567 391 242 568 minecraft:black_concrete
fill 379 242 588 415 242 589 minecraft:black_concrete
fill 380 242 566 394 242 566 minecraft:black_concrete
fill 380 242 590 414 242 590 minecraft:black_concrete
fill 380 242 599 381 243 599 minecraft:purple_concrete
fill 381 242 565 413 243 565 minecraft:black_concrete
fill 381 242 591 413 243 591 minecraft:black_concrete
fill 382 242 563 412 242 563 minecraft:black_concrete
fill 382 242 593 412 242 593 minecraft:black_concrete
fill 382 242 599 383 247 599 minecraft:black_concrete
fill 383 242 557 384 247 557 minecraft:black_concrete
fill 383 242 562 411 242 562 minecraft:black_concrete
fill 383 242 594 411 242 594 minecraft:black_concrete
fill 385 242 557 386 243 557 minecraft:purple_concrete
fill 385 242 561 409 242 561 minecraft:black_concrete
fill 385 242 595 409 242 595 minecraft:black_concrete
fill 386 242 560 408 242 560 minecraft:black_concrete
fill 386 242 596 408 242 596 minecraft:black_concrete
fill 388 242 559 406 242 559 minecraft:black_concrete
fill 388 242 597 406 242 597 minecraft:black_concrete
fill 389 242 578 389 242 587 minecraft:black_concrete
fill 390 242 558 404 242 558 minecraft:black_concrete
fill 390 242 578 390 242 579 minecraft:purple_concrete
fill 390 242 580 390 242 587 minecraft:black_concrete
fill 390 242 598 404 242 598 minecraft:black_concrete
fill 391 242 579 391 242 581 minecraft:purple_concrete
fill 391 242 582 391 242 587 minecraft:black_concrete
fill 391 242 599 391 243 599 minecraft:black_concrete
fill 392 242 567 392 244 567 minecraft:black_concrete
fill 392 242 568 392 246 568 minecraft:red_nether_bricks
fill 392 242 578 392 246 578 minecraft:red_nether_bricks
fill 392 242 581 392 242 582 minecraft:purple_concrete
fill 392 242 583 392 242 587 minecraft:black_concrete
fill 392 242 599 393 242 599 minecraft:purple_concrete
fill 393 242 557 393 245 557 minecraft:black_concrete
fill 393 242 567 393 245 567 minecraft:red_nether_bricks
fill 393 242 579 393 245 579 minecraft:red_nether_bricks
fill 393 242 582 394 242 583 minecraft:purple_concrete
fill 393 242 584 394 242 587 minecraft:black_concrete
setblock 394 242 557 minecraft:purple_concrete
fill 394 242 599 395 247 599 minecraft:black_concrete
fill 395 242 557 396 247 557 minecraft:black_concrete
fill 395 242 566 395 245 566 minecraft:red_nether_bricks
fill 395 242 580 395 245 580 minecraft:red_nether_bricks
fill 395 242 583 396 242 584 minecraft:purple_concrete
fill 395 242 585 416 242 587 minecraft:black_concrete
fill 397 242 557 398 243 557 minecraft:purple_concrete
fill 397 242 569 397 244 569 minecraft:red_nether_bricks
fill 397 242 577 397 244 577 minecraft:red_nether_bricks
fill 397 242 584 400 242 584 minecraft:purple_concrete
fill 400 242 583 402 242 583 minecraft:purple_concrete
fill 400 242 599 401 243 599 minecraft:purple_concrete
fill 401 242 584 417 242 584 minecraft:black_concrete
fill 402 242 582 403 242 582 minecraft:purple_concrete
fill 402 242 599 403 247 599 minecraft:black_concrete
fill 403 242 557 404 247 557 minecraft:black_concrete
fill 403 242 566 403 245 566 minecraft:red_nether_bricks
fill 403 242 580 403 245 580 minecraft:red_nether_bricks
fill 403 242 583 417 242 583 minecraft:black_concrete
fill 404 242 566 414 242 566 minecraft:black_concrete
setblock 404 242 581 minecraft:purple_concrete
fill 404 242 582 417 242 582 minecraft:black_concrete
setblock 404 242 599 minecraft:purple_concrete
fill 405 242 557 406 242 557 minecraft:purple_concrete
fill 405 242 567 405 245 567 minecraft:red_nether_bricks
fill 405 242 579 405 245 579 minecraft:red_nether_bricks
setblock 405 242 580 minecraft:purple_concrete
fill 405 242 581 417 242 581 minecraft:black_concrete
fill 405 242 599 406 244 599 minecraft:black_concrete
fill 406 242 567 415 242 567 minecraft:black_concrete
fill 406 242 568 406 246 568 minecraft:red_nether_bricks
fill 406 242 578 406 246 578 minecraft:red_nether_bricks
fill 406 242 579 417 242 580 minecraft:black_concrete
fill 407 242 557 407 247 557 minecraft:black_concrete
fill 407 242 568 415 243 568 minecraft:black_concrete
fill 407 242 569 407 246 569 minecraft:red_nether_bricks
fill 407 242 577 407 246 577 minecraft:red_nether_bricks
fill 407 242 578 417 242 578 minecraft:black_concrete
fill 408 242 569 416 242 570 minecraft:black_concrete
fill 408 242 571 408 246 571 minecraft:red_nether_bricks
fill 408 242 575 408 246 575 minecraft:red_nether_bricks
fill 408 242 576 417 242 577 minecraft:black_concrete
fill 409 242 571 417 242 571 minecraft:black_concrete
fill 409 242 575 418 243 575 minecraft:black_concrete
fill 412 242 599 413 243 599 minecraft:purple_concrete
fill 414 242 599 415 247 599 minecraft:black_concrete
fill 415 242 557 416 247 557 minecraft:black_concrete
fill 417 242 557 418 243 557 minecraft:purple_concrete
setblock 417 242 585 minecraft:black_concrete
fill 418 242 563 418 245 564 minecraft:black_concrete
setblock 418 242 565 minecraft:purple_concrete
fill 418 242 566 418 247 567 minecraft:black_concrete
fill 418 242 568 418 243 568 minecraft:purple_concrete
setblock 418 242 569 minecraft:black_concrete
fill 418 242 574 418 247 574 minecraft:black_concrete
fill 418 242 576 418 242 577 minecraft:purple_concrete
fill 418 242 586 418 247 587 minecraft:black_concrete
fill 418 242 588 418 243 589 minecraft:purple_concrete
fill 418 242 595 418 247 595 minecraft:black_concrete
fill 418 242 596 418 242 597 minecraft:purple_concrete
fill 418 242 598 418 247 598 minecraft:black_concrete
fill 376 243 559 376 243 560 minecraft:purple_concrete
setblock 376 243 563 minecraft:purple_concrete
fill 376 243 564 376 246 564 minecraft:black_concrete
fill 376 243 575 376 246 575 minecraft:black_concrete
setblock 376 243 580 minecraft:purple_concrete
setblock 376 243 591 minecraft:purple_concrete
fill 376 243 595 376 245 596 minecraft:black_concrete
fill 377 243 577 385 243 583 minecraft:black_concrete
setblock 378 243 557 minecraft:purple_concrete
fill 378 243 570 385 243 572 minecraft:black_concrete
fill 378 243 584 385 243 586 minecraft:black_concrete
fill 379 243 568 385 243 569 minecraft:black_concrete
fill 379 243 587 385 243 588 minecraft:black_concrete
fill 380 243 567 391 243 567 minecraft:black_concrete
fill 380 243 589 414 243 589 minecraft:black_concrete
fill 381 243 566 394 243 566 minecraft:black_concrete
fill 381 243 590 413 243 590 minecraft:black_concrete
fill 382 243 564 412 243 564 minecraft:black_concrete
fill 382 243 592 412 243 592 minecraft:black_concrete
fill 383 243 563 411 243 563 minecraft:black_concrete
fill 383 243 593 411 243 593 minecraft:black_concrete
fill 384 243 562 410 243 562 minecraft:black_concrete
fill 384 243 594 410 243 594 minecraft:black_concrete
fill 386 243 561 408 243 561 minecraft:black_concrete
fill 386 243 568 391 244 568 minecraft:black_concrete
fill 386 243 588 415 243 588 minecraft:black_concrete
fill 386 243 595 408 243 595 minecraft:black_concrete
fill 387 243 560 407 243 560 minecraft:black_concrete
fill 387 243 571 387 245 571 minecraft:black_concrete
fill 387 243 572 387 244 572 minecraft:nether_bricks
fill 387 243 574 387 244 574 minecraft:nether_bricks
fill 387 243 575 387 244 575 minecraft:black_concrete
fill 387 243 596 407 243 596 minecraft:black_concrete
fill 388 243 599 389 243 599 minecraft:purple_concrete
setblock 389 243 557 minecraft:purple_concrete
fill 389 243 559 405 243 559 minecraft:black_concrete
fill 389 243 578 389 243 580 minecraft:crying_obsidian
fill 389 243 581 389 243 587 minecraft:black_concrete
fill 389 243 597 405 243 597 minecraft:black_concrete
fill 390 243 580 390 243 582 minecraft:crying_obsidian
fill 390 243 583 390 243 587 minecraft:black_concrete
fill 391 243 582 391 243 583 minecraft:crying_obsidian
fill 391 243 584 391 243 587 minecraft:black_concrete
fill 392 243 558 402 243 558 minecraft:black_concrete
fill 392 243 583 392 243 584 minecraft:crying_obsidian
fill 392 243 585 393 243 587 minecraft:black_concrete
fill 392 243 598 402 243 598 minecraft:black_concrete
setblock 392 243 599 minecraft:purple_concrete
fill 393 243 584 394 243 584 minecraft:crying_obsidian
fill 393 243 599 393 246 599 minecraft:black_concrete
fill 394 243 557 394 246 557 minecraft:black_concrete
fill 394 243 585 401 243 585 minecraft:crying_obsidian
fill 394 243 586 415 243 587 minecraft:black_concrete
setblock 395 243 572 minecraft:nether_bricks
setblock 395 243 574 minecraft:nether_bricks
fill 401 243 584 403 243 584 minecraft:crying_obsidian
fill 402 243 585 416 243 585 minecraft:black_concrete
fill 403 243 583 404 243 583 minecraft:crying_obsidian
fill 404 243 566 413 243 566 minecraft:black_concrete
fill 404 243 582 405 243 582 minecraft:crying_obsidian
fill 404 243 584 416 243 584 minecraft:black_concrete
fill 404 243 599 404 246 599 minecraft:black_concrete
fill 405 243 557 405 246 557 minecraft:black_concrete
fill 405 243 581 406 243 581 minecraft:crying_obsidian
fill 405 243 583 417 243 583 minecraft:black_concrete
setblock 406 243 557 minecraft:purple_concrete
fill 406 243 567 414 243 567 minecraft:black_concrete
fill 406 243 579 406 243 580 minecraft:crying_obsidian
fill 406 243 582 417 243 582 minecraft:black_concrete
setblock 407 243 578 minecraft:crying_obsidian
fill 407 243 579 417 243 581 minecraft:black_concrete
fill 408 243 569 415 243 569 minecraft:black_concrete
fill 408 243 570 408 245 570 minecraft:red_nether_bricks
fill 408 243 576 408 245 576 minecraft:red_nether_bricks
fill 408 243 577 417 243 578 minecraft:black_concrete
fill 408 243 599 408 245 599 minecraft:black_concrete
fill 409 243 557 410 243 557 minecraft:purple_concrete
fill 409 243 570 416 243 574 minecraft:black_concrete
fill 409 243 576 418 243 576 minecraft:black_concrete
setblock 409 243 599 minecraft:purple_concrete
setblock 416 243 586 minecraft:black_concrete
fill 417 243 573 417 243 574 minecraft:black_concrete
fill 418 243 565 418 246 565 minecraft:black_concrete
setblock 418 243 569 minecraft:purple_concrete
setblock 418 243 577 minecraft:purple_concrete
setblock 418 243 580 minecraft:purple_concrete
fill 418 243 596 418 246 597 minecraft:black_concrete
fill 376 244 557 378 244 557 minecraft:black_concrete
fill 376 244 558 376 245 558 minecraft:purple_concrete
fill 376 244 559 376 249 560 minecraft:black_concrete
setblock 376 244 561 minecraft:purple_concrete
fill 376 244 563 376 249 563 minecraft:black_concrete
fill 376 244 569 376 245 570 minecraft:purple_concrete
fill 376 244 571 376 247 574 minecraft:black_concrete
fill 376 244 576 376 245 576 minecraft:black_concrete
fill 376 244 580 376 249 580 minecraft:black_concrete
fill 376 244 581 376 244 582 minecraft:purple_concrete
fill 376 244 583 376 249 584 minecraft:black_concrete
fill 376 244 589 376 245 590 minecraft:purple_concrete
fill 376 244 591 376 249 592 minecraft:black_concrete
setblock 376 244 593 minecraft:purple_concrete
fill 378 244 573 385 244 583 minecraft:black_concrete
fill 378 244 599 379 245 599 minecraft:purple_concrete
fill 379 244 557 380 245 557 minecraft:purple_concrete
fill 379 244 570 385 244 572 minecraft:black_concrete
fill 379 244 584 385 244 586 minecraft:black_concrete
fill 380 244 568 385 244 569 minecraft:black_concrete
fill 380 244 587 385 244 588 minecraft:black_concrete
fill 380 244 599 381 249 599 minecraft:black_concrete
fill 381 244 567 391 244 567 minecraft:black_concrete
fill 381 244 589 413 244 589 minecraft:black_concrete
fill 382 244 565 394 244 566 minecraft:black_concrete
fill 382 244 590 412 244 591 minecraft:black_concrete
fill 383 244 564 411 244 564 minecraft:black_concrete
fill 383 244 592 411 244 592 minecraft:black_concrete
fill 384 244 563 410 244 563 minecraft:black_concrete
fill 384 244 593 410 244 593 minecraft:black_concrete
fill 385 244 557 386 249 557 minecraft:black_concrete
fill 386 244 562 408 244 562 minecraft:black_concrete
fill 386 244 571 386 246 571 minecraft:black_concrete
setblock 386 244 572 minecraft:nether_bricks
setblock 386 244 574 minecraft:nether_bricks
setblock 386 244 575 minecraft:black_concrete
fill 386 244 588 414 244 588 minecraft:black_concrete
fill 386 244 594 408 244 594 minecraft:black_concrete
setblock 386 244 599 minecraft:black_concrete
fill 387 244 557 388 244 557 minecraft:purple_concrete
fill 387 244 561 407 244 561 minecraft:black_concrete
fill 387 244 570 387 246 570 minecraft:black_concrete
fill 387 244 576 387 244 578 minecraft:purple_concrete
fill 387 244 579 387 244 587 minecraft:black_concrete
fill 387 244 595 407 244 595 minecraft:black_concrete
fill 387 244 599 387 245 599 minecraft:purple_concrete
fill 388 244 577 388 244 581 minecraft:purple_concrete
fill 388 244 582 388 244 587 minecraft:black_concrete
fill 388 244 599 389 245 599 minecraft:black_concrete
fill 389 244 557 389 249 557 minecraft:black_concrete
fill 389 244 560 405 244 560 minecraft:black_concrete
fill 389 244 569 390 244 569 minecraft:black_concrete
fill 389 244 581 389 244 583 minecraft:purple_concrete
fill 389 244 584 389 244 587 minecraft:black_concrete
fill 389 244 596 405 244 596 minecraft:black_concrete
fill 390 244 583 390 244 584 minecraft:purple_concrete
fill 390 244 585 390 244 587 minecraft:black_concrete
fill 390 244 599 391 244 599 minecraft:purple_concrete
fill 391 244 569 393 246 569 minecraft:red_nether_bricks
fill 391 244 577 393 246 577 minecraft:red_nether_bricks
fill 391 244 584 391 244 585 minecraft:purple_concrete
fill 391 244 586 392 244 587 minecraft:black_concrete
fill 392 244 559 402 244 559 minecraft:black_concrete
fill 392 244 585 393 244 585 minecraft:purple_concrete
fill 392 244 597 402 244 597 minecraft:black_concrete
fill 392 244 599 392 249 599 minecraft:black_concrete
fill 393 244 586 402 244 586 minecraft:purple_concrete
fill 393 244 587 394 244 587 minecraft:black_concrete
fill 395 244 565 412 244 565 minecraft:black_concrete
fill 395 244 570 395 246 570 minecraft:red_nether_bricks
fill 395 244 576 395 246 576 minecraft:red_nether_bricks
fill 395 244 587 400 244 587 minecraft:purple_concrete
fill 397 244 557 398 249 557 minecraft:black_concrete
fill 398 244 599 399 245 599 minecraft:purple_concrete
fill 399 244 557 400 245 557 minecraft:purple_concrete
fill 400 244 599 401 249 599 minecraft:black_concrete
fill 401 244 587 414 244 587 minecraft:black_concrete
fill 402 244 585 404 244 585 minecraft:purple_concrete
fill 403 244 570 403 246 570 minecraft:red_nether_bricks
fill 403 244 576 403 246 576 minecraft:red_nether_bricks
fill 403 244 586 415 244 586 minecraft:black_concrete
fill 404 244 566 412 244 566 minecraft:black_concrete
fill 404 244 572 406 246 572 minecraft:red_nether_bricks
fill 404 244 574 406 246 574 minecraft:red_nether_bricks
fill 404 244 584 405 244 584 minecraft:purple_concrete
fill 405 244 583 406 244 583 minecraft:purple_concrete
fill 405 244 585 415 244 585 minecraft:black_concrete
fill 406 244 557 406 249 557 minecraft:black_concrete
fill 406 244 567 413 244 567 minecraft:black_concrete
setblock 406 244 582 minecraft:purple_concrete
fill 406 244 584 415 244 584 minecraft:black_concrete
fill 407 244 568 414 244 568 minecraft:black_concrete
fill 407 244 579 407 244 581 minecraft:purple_concrete
fill 407 244 582 416 244 583 minecraft:black_concrete
setblock 408 244 557 minecraft:purple_concrete
fill 408 244 569 414 244 569 minecraft:black_concrete
fill 408 244 577 408 245 578 minecraft:purple_concrete
fill 408 244 579 416 244 581 minecraft:black_concrete
fill 409 244 557 410 249 557 minecraft:black_concrete
fill 409 244 570 415 244 578 minecraft:black_concrete
fill 409 244 599 409 249 599 minecraft:black_concrete
fill 410 244 599 411 244 599 minecraft:purple_concrete
fill 411 244 557 411 245 557 minecraft:purple_concrete
setblock 412 244 557 minecraft:black_concrete
fill 412 244 599 413 249 599 minecraft:black_concrete
fill 416 244 573 416 244 578 minecraft:black_concrete
fill 417 244 557 418 249 557 minecraft:black_concrete
fill 418 244 558 418 244 559 minecraft:purple_concrete
fill 418 244 568 418 249 569 minecraft:black_concrete
fill 418 244 570 418 245 571 minecraft:purple_concrete
fill 418 244 575 418 246 577 minecraft:black_concrete
fill 418 244 578 418 244 579 minecraft:purple_concrete
fill 418 244 580 418 249 580 minecraft:black_concrete
fill 418 244 582 418 245 582 minecraft:purple_concrete
setblock 418 244 583 minecraft:black_concrete
fill 418 244 588 418 249 589 minecraft:black_concrete
fill 418 244 590 418 245 591 minecraft:purple_concrete
fill 418 244 599 418 245 599 minecraft:purple_concrete
setblock 376 245 557 minecraft:purple_concrete
fill 376 245 561 376 248 561 minecraft:black_concrete
fill 376 245 577 376 245 578 minecraft:purple_concrete
setblock 376 245 581 minecraft:purple_concrete
fill 376 245 582 376 248 582 minecraft:black_concrete
fill 376 245 593 376 247 593 minecraft:black_concrete
setblock 376 245 598 minecraft:purple_concrete
fill 377 245 557 378 249 557 minecraft:black_concrete
setblock 379 245 560 minecraft:light[level=12]
setblock 379 245 568 minecraft:light[level=12]
fill 379 245 573 385 245 583 minecraft:black_concrete
setblock 379 245 584 minecraft:light[level=12]
setblock 379 245 592 minecraft:light[level=12]
fill 380 245 570 385 245 572 minecraft:black_concrete
fill 380 245 584 387 245 586 minecraft:black_concrete
fill 381 245 568 385 245 569 minecraft:black_concrete
fill 381 245 587 391 245 588 minecraft:black_concrete
fill 382 245 567 391 245 567 minecraft:black_concrete
fill 382 245 589 412 245 589 minecraft:black_concrete
fill 383 245 566 393 245 566 minecraft:black_concrete
fill 383 245 590 411 245 590 minecraft:black_concrete
fill 384 245 565 410 245 565 minecraft:black_concrete
fill 384 245 591 410 245 591 minecraft:black_concrete
fill 385 245 564 409 245 564 minecraft:black_concrete
fill 385 245 592 409 245 592 minecraft:black_concrete
fill 386 245 563 408 245 563 minecraft:black_concrete
fill 386 245 568 390 245 568 minecraft:black_concrete
fill 386 245 572 386 245 574 minecraft:black_concrete
fill 386 245 575 386 245 579 minecraft:purple_concrete
fill 386 245 580 386 245 583 minecraft:black_concrete
fill 386 245 593 408 245 593 minecraft:black_concrete
setblock 386 245 599 minecraft:purple_concrete
fill 387 245 557 387 248 557 minecraft:black_concrete
setblock 387 245 560 minecraft:light[level=12]
fill 387 245 562 407 245 562 minecraft:black_concrete
setblock 387 245 572 minecraft:black_concrete
setblock 387 245 573 minecraft:nether_bricks
fill 387 245 574 387 245 575 minecraft:purple_concrete
setblock 387 245 576 minecraft:light[level=12]
fill 387 245 579 387 245 582 minecraft:purple_concrete
setblock 387 245 583 minecraft:black_concrete
fill 387 245 594 407 245 594 minecraft:black_concrete
setblock 388 245 557 minecraft:purple_concrete
setblock 388 245 570 minecraft:black_concrete
setblock 388 245 571 minecraft:nether_bricks
setblock 388 245 575 minecraft:nether_bricks
fill 388 245 582 388 245 584 minecraft:purple_concrete
fill 388 245 585 388 245 586 minecraft:black_concrete
fill 389 245 561 405 245 561 minecraft:black_concrete
setblock 389 245 569 minecraft:black_concrete
setblock 389 245 570 minecraft:purple_concrete
fill 389 245 578 390 245 578 minecraft:white_concrete
fill 389 245 584 389 245 585 minecraft:purple_concrete
setblock 389 245 586 minecraft:black_concrete
fill 389 245 595 405 245 595 minecraft:black_concrete
setblock 390 245 569 minecraft:purple_concrete
fill 390 245 570 392 245 570 minecraft:nether_bricks
fill 390 245 576 392 245 576 minecraft:nether_bricks
fill 390 245 580 391 245 580 minecraft:white_concrete
fill 390 245 585 390 245 586 minecraft:purple_concrete
fill 390 245 599 391 247 599 minecraft:black_concrete
fill 391 245 557 392 245 557 minecraft:purple_concrete
setblock 391 245 568 minecraft:purple_concrete
fill 391 245 582 391 246 583 minecraft:white_concrete
fill 391 245 586 392 245 586 minecraft:purple_concrete
fill 392 245 560 402 245 560 minecraft:black_concrete
setblock 392 245 567 minecraft:purple_concrete
setblock 392 245 582 minecraft:white_concrete
fill 392 245 584 393 246 584 minecraft:white_concrete
fill 392 245 587 394 245 587 minecraft:purple_concrete
setblock 392 245 588 minecraft:black_concrete
fill 392 245 596 402 245 596 minecraft:black_concrete
fill 393 245 570 394 248 570 minecraft:red_nether_bricks
fill 393 245 576 394 248 576 minecraft:red_nether_bricks
setblock 393 245 583 minecraft:white_concrete
fill 393 245 588 401 245 588 minecraft:purple_concrete
setblock 394 245 566 minecraft:purple_concrete
setblock 394 245 571 minecraft:nether_bricks
setblock 394 245 575 minecraft:nether_bricks
fill 395 245 584 395 245 585 minecraft:white_concrete
fill 397 245 585 397 245 586 minecraft:white_concrete
fill 399 245 584 399 245 585 minecraft:white_concrete
fill 401 245 583 401 245 584 minecraft:white_concrete
fill 401 245 587 403 245 587 minecraft:purple_concrete
fill 402 245 582 403 245 582 minecraft:white_concrete
fill 402 245 584 402 246 584 minecraft:white_concrete
fill 402 245 588 413 245 588 minecraft:black_concrete
setblock 403 245 560 minecraft:light[level=12]
fill 403 245 583 403 246 583 minecraft:white_concrete
setblock 403 245 584 minecraft:light[level=12]
fill 403 245 586 404 245 586 minecraft:purple_concrete
fill 404 245 566 411 245 566 minecraft:black_concrete
fill 404 245 580 404 246 580 minecraft:white_concrete
fill 404 245 587 413 245 587 minecraft:black_concrete
setblock 405 245 585 minecraft:purple_concrete
fill 405 245 586 414 245 586 minecraft:black_concrete
setblock 405 245 599 minecraft:black_concrete
fill 406 245 567 412 245 567 minecraft:black_concrete
setblock 406 245 584 minecraft:purple_concrete
fill 406 245 585 414 245 585 minecraft:black_concrete
fill 406 245 599 407 245 599 minecraft:purple_concrete
fill 407 245 568 413 245 568 minecraft:black_concrete
fill 407 245 582 407 245 583 minecraft:purple_concrete
fill 407 245 584 414 245 584 minecraft:black_concrete
fill 408 245 557 408 248 557 minecraft:black_concrete
fill 408 245 569 413 245 569 minecraft:black_concrete
fill 408 245 579 408 245 581 minecraft:purple_concrete
fill 408 245 582 415 245 583 minecraft:black_concrete
fill 409 245 570 414 245 581 minecraft:black_concrete
setblock 410 245 599 minecraft:purple_concrete
setblock 411 245 560 minecraft:light[level=12]
setblock 411 245 592 minecraft:light[level=12]
fill 411 245 599 411 248 599 minecraft:black_concrete
setblock 412 245 557 minecraft:purple_concrete
fill 415 245 573 415 245 581 minecraft:black_concrete
fill 418 245 558 418 248 558 minecraft:black_concrete
setblock 418 245 559 minecraft:purple_concrete
setblock 418 245 562 minecraft:purple_concrete
fill 418 245 578 418 248 579 minecraft:black_concrete
setblock 418 245 583 minecraft:purple_concrete
setblock 418 245 594 minecraft:purple_concrete
fill 376 246 557 376 251 558 minecraft:black_concrete
fill 376 246 567 376 246 568 minecraft:purple_concrete
fill 376 246 569 376 251 570 minecraft:black_concrete
fill 376 246 576 376 247 576 minecraft:purple_concrete
fill 376 246 577 376 251 578 minecraft:black_concrete
setblock 376 246 579 minecraft:purple_concrete
fill 376 246 581 376 251 581 minecraft:black_concrete
fill 376 246 587 376 247 588 minecraft:purple_concrete
fill 376 246 589 376 251 590 minecraft:black_concrete
setblock 376 246 595 minecraft:black_concrete
fill 376 246 596 376 247 596 minecraft:purple_concrete
fill 376 246 598 376 251 598 minecraft:black_concrete
fill 376 246 599 377 246 599 minecraft:purple_concrete
fill 377 246 558 379 246 558 minecraft:obsidian
fill 377 246 560 377 246 562 minecraft:obsidian
fill 377 246 564 377 246 566 minecraft:obsidian
fill 377 246 568 377 246 570 minecraft:obsidian
fill 377 246 572 377 246 574 minecraft:obsidian
fill 377 246 576 377 246 578 minecraft:obsidian
fill 377 246 580 377 246 582 minecraft:obsidian
fill 377 246 584 377 246 586 minecraft:obsidian
fill 377 246 588 377 246 590 minecraft:obsidian
fill 377 246 592 377 246 594 minecraft:obsidian
fill 377 246 596 377 246 598 minecraft:obsidian
fill 378 246 599 379 248 599 minecraft:black_concrete
fill 379 246 557 380 251 557 minecraft:black_concrete
fill 379 246 598 381 246 598 minecraft:obsidian
fill 380 246 573 384 246 583 minecraft:black_concrete
fill 381 246 557 382 247 557 minecraft:purple_concrete
fill 381 246 558 383 246 558 minecraft:obsidian
fill 381 246 571 385 246 572 minecraft:black_concrete
fill 381 246 584 386 246 585 minecraft:black_concrete
fill 382 246 569 385 246 570 minecraft:black_concrete
fill 382 246 586 387 246 587 minecraft:black_concrete
fill 383 246 567 389 246 568 minecraft:black_concrete
fill 383 246 588 389 246 589 minecraft:black_concrete
fill 383 246 598 385 246 598 minecraft:obsidian
fill 384 246 566 392 246 566 minecraft:black_concrete
fill 384 246 590 394 246 590 minecraft:black_concrete
fill 384 246 599 385 247 599 minecraft:purple_concrete
fill 385 246 558 387 246 558 minecraft:obsidian
fill 385 246 565 395 246 565 minecraft:black_concrete
fill 385 246 573 385 246 574 minecraft:black_concrete
fill 385 246 575 385 246 580 minecraft:crying_obsidian
fill 385 246 581 385 246 583 minecraft:black_concrete
fill 385 246 591 409 246 591 minecraft:black_concrete
fill 386 246 564 408 246 564 minecraft:black_concrete
fill 386 246 572 386 246 574 minecraft:crying_obsidian
fill 386 246 580 386 246 583 minecraft:crying_obsidian
fill 386 246 592 408 246 592 minecraft:black_concrete
fill 386 246 599 387 251 599 minecraft:black_concrete
fill 387 246 571 387 246 572 minecraft:crying_obsidian
fill 387 246 575 389 246 575 minecraft:white_concrete
fill 387 246 578 389 246 578 minecraft:white_concrete
fill 387 246 581 389 246 581 minecraft:white_concrete
fill 387 246 583 387 246 585 minecraft:crying_obsidian
fill 387 246 593 406 246 593 minecraft:black_concrete
fill 387 246 598 389 246 598 minecraft:obsidian
fill 388 246 557 388 251 557 minecraft:black_concrete
fill 388 246 563 406 246 563 minecraft:black_concrete
setblock 388 246 570 minecraft:crying_obsidian
fill 388 246 585 388 246 586 minecraft:crying_obsidian
setblock 388 246 587 minecraft:black_concrete
setblock 388 246 599 minecraft:purple_concrete
fill 389 246 558 391 246 558 minecraft:obsidian
setblock 389 246 569 minecraft:crying_obsidian
fill 389 246 572 389 247 573 minecraft:white_concrete
fill 389 246 576 390 246 576 minecraft:white_concrete
fill 389 246 580 390 246 580 minecraft:white_concrete
fill 389 246 583 390 246 584 minecraft:white_concrete
fill 389 246 586 389 246 587 minecraft:crying_obsidian
fill 389 246 594 404 246 594 minecraft:black_concrete
fill 389 246 599 389 249 599 minecraft:black_concrete
setblock 390 246 557 minecraft:purple_concrete
fill 390 246 562 404 246 562 minecraft:black_concrete
setblock 390 246 567 minecraft:black_concrete
setblock 390 246 568 minecraft:crying_obsidian
fill 390 246 571 394 246 572 minecraft:red_nether_bricks
fill 390 246 573 392 246 573 minecraft:nether_bricks
fill 390 246 574 394 246 575 minecraft:red_nether_bricks
fill 390 246 587 391 246 588 minecraft:crying_obsidian
fill 390 246 589 391 246 589 minecraft:black_concrete
fill 391 246 557 392 251 557 minecraft:black_concrete
fill 391 246 567 392 246 567 minecraft:crying_obsidian
fill 391 246 570 392 247 570 minecraft:red_nether_bricks
fill 391 246 576 392 247 576 minecraft:red_nether_bricks
fill 391 246 585 392 246 586 minecraft:white_concrete
fill 391 246 598 393 246 598 minecraft:obsidian
fill 392 246 561 402 246 561 minecraft:black_concrete
fill 392 246 588 392 246 589 minecraft:crying_obsidian
fill 392 246 595 402 246 595 minecraft:black_concrete
fill 393 246 557 393 247 557 minecraft:purple_concrete
fill 393 246 558 395 246 558 minecraft:obsidian
fill 393 246 566 395 246 566 minecraft:crying_obsidian
fill 393 246 573 394 246 573 minecraft:red_nether_bricks
fill 393 246 589 402 246 589 minecraft:crying_obsidian
fill 394 246 586 394 246 588 minecraft:white_concrete
fill 395 246 585 395 246 586 minecraft:white_concrete
fill 395 246 590 399 246 590 minecraft:crying_obsidian
fill 395 246 598 397 246 598 minecraft:obsidian
fill 396 246 565 399 246 565 minecraft:crying_obsidian
fill 396 246 566 400 246 566 minecraft:red_nether_bricks
fill 396 246 580 400 246 580 minecraft:red_nether_bricks
fill 396 246 599 397 247 599 minecraft:purple_concrete
fill 397 246 558 399 246 558 minecraft:obsidian
fill 397 246 586 397 246 588 minecraft:white_concrete
fill 398 246 599 399 251 599 minecraft:black_concrete
fill 399 246 557 400 251 557 minecraft:black_concrete
fill 399 246 585 399 246 586 minecraft:white_concrete
fill 399 246 598 401 246 598 minecraft:obsidian
fill 400 246 565 409 246 565 minecraft:black_concrete
fill 400 246 586 400 246 588 minecraft:white_concrete
fill 400 246 590 410 246 590 minecraft:black_concrete
fill 401 246 557 402 246 557 minecraft:purple_concrete
fill 401 246 558 403 246 558 minecraft:obsidian
setblock 401 246 566 minecraft:black_concrete
setblock 401 246 580 minecraft:black_concrete
setblock 401 246 584 minecraft:white_concrete
setblock 402 246 566 minecraft:red_nether_bricks
setblock 402 246 580 minecraft:red_nether_bricks
fill 402 246 585 403 246 586 minecraft:white_concrete
fill 402 246 588 404 246 588 minecraft:crying_obsidian
fill 403 246 566 410 246 566 minecraft:black_concrete
setblock 403 246 582 minecraft:white_concrete
fill 403 246 589 411 246 589 minecraft:black_concrete
fill 403 246 598 405 246 598 minecraft:obsidian
fill 404 246 583 405 246 584 minecraft:white_concrete
fill 404 246 587 405 246 587 minecraft:crying_obsidian
fill 405 246 558 407 246 558 minecraft:obsidian
fill 405 246 567 411 246 567 minecraft:black_concrete
fill 405 246 580 405 246 581 minecraft:white_concrete
fill 405 246 586 406 246 586 minecraft:crying_obsidian
fill 405 246 588 411 246 588 minecraft:black_concrete
fill 405 246 599 405 247 599 minecraft:purple_concrete
fill 406 246 581 407 247 581 minecraft:white_concrete
fill 406 246 585 407 246 585 minecraft:crying_obsidian
fill 406 246 587 412 246 587 minecraft:black_concrete
fill 406 246 599 407 251 599 minecraft:black_concrete
fill 407 246 568 411 246 568 minecraft:black_concrete
fill 407 246 578 407 247 578 minecraft:white_concrete
setblock 407 246 584 minecraft:crying_obsidian
fill 407 246 586 412 246 586 minecraft:black_concrete
fill 407 246 598 409 246 598 minecraft:obsidian
fill 408 246 569 412 246 570 minecraft:black_concrete
fill 408 246 582 408 246 583 minecraft:crying_obsidian
fill 408 246 584 413 246 585 minecraft:black_concrete
setblock 408 246 599 minecraft:purple_concrete
fill 409 246 558 411 246 558 minecraft:obsidian
fill 409 246 571 413 246 573 minecraft:black_concrete
fill 409 246 574 409 246 581 minecraft:crying_obsidian
fill 409 246 582 414 246 583 minecraft:black_concrete
fill 410 246 574 414 246 581 minecraft:black_concrete
fill 410 246 599 410 251 599 minecraft:black_concrete
fill 411 246 557 412 251 557 minecraft:black_concrete
fill 411 246 598 413 246 598 minecraft:obsidian
fill 413 246 557 414 247 557 minecraft:purple_concrete
fill 413 246 558 415 246 558 minecraft:obsidian
setblock 414 246 573 minecraft:black_concrete
fill 415 246 598 417 246 598 minecraft:obsidian
fill 416 246 599 417 247 599 minecraft:purple_concrete
fill 417 246 558 417 246 560 minecraft:obsidian
fill 417 246 562 417 246 564 minecraft:obsidian
fill 417 246 566 417 246 568 minecraft:obsidian
fill 417 246 570 417 246 572 minecraft:obsidian
fill 417 246 574 417 246 576 minecraft:obsidian
fill 417 246 578 417 246 580 minecraft:obsidian
fill 417 246 582 417 246 584 minecraft:obsidian
fill 417 246 586 417 246 588 minecraft:obsidian
fill 417 246 590 417 246 592 minecraft:obsidian
fill 417 246 594 417 246 596 minecraft:obsidian
fill 418 246 559 418 251 559 minecraft:black_concrete
fill 418 246 560 418 246 561 minecraft:purple_concrete
fill 418 246 562 418 247 563 minecraft:black_concrete
fill 418 246 564 418 247 564 minecraft:purple_concrete
fill 418 246 570 418 251 571 minecraft:black_concrete
fill 418 246 572 418 247 573 minecraft:purple_concrete
setblock 418 246 581 minecraft:purple_concrete
fill 418 246 582 418 251 583 minecraft:black_concrete
fill 418 246 584 418 247 585 minecraft:purple_concrete
fill 418 246 590 418 251 591 minecraft:black_concrete
fill 418 246 592 418 246 593 minecraft:purple_concrete
fill 418 246 594 418 251 594 minecraft:black_concrete
fill 418 246 599 418 251 599 minecraft:black_concrete
setblock 376 247 564 minecraft:purple_concrete
setblock 376 247 567 minecraft:purple_concrete
fill 376 247 568 376 250 568 minecraft:black_concrete
setblock 376 247 575 minecraft:purple_concrete
fill 376 247 579 376 250 579 minecraft:black_concrete
setblock 376 247 595 minecraft:purple_concrete
setblock 376 247 599 minecraft:purple_concrete
fill 377 247 599 377 250 599 minecraft:black_concrete
fill 381 247 576 383 247 580 minecraft:black_concrete
fill 382 247 572 383 247 575 minecraft:black_concrete
fill 382 247 581 384 247 584 minecraft:black_concrete
fill 383 247 570 385 247 571 minecraft:black_concrete
fill 383 247 585 385 247 586 minecraft:black_concrete
fill 384 247 569 385 247 569 minecraft:black_concrete
fill 384 247 572 384 247 574 minecraft:black_concrete
fill 384 247 575 384 247 580 minecraft:purple_concrete
fill 384 247 587 387 247 587 minecraft:black_concrete
fill 385 247 568 388 247 568 minecraft:black_concrete
fill 385 247 572 385 247 573 minecraft:purple_concrete
fill 385 247 574 387 247 575 minecraft:white_concrete
fill 385 247 577 387 247 579 minecraft:white_concrete
fill 385 247 581 387 247 582 minecraft:white_concrete
setblock 385 247 583 minecraft:purple_concrete
setblock 385 247 584 minecraft:black_concrete
fill 385 247 588 388 247 588 minecraft:black_concrete
fill 386 247 567 389 247 567 minecraft:black_concrete
setblock 386 247 571 minecraft:purple_concrete
fill 386 247 584 386 247 585 minecraft:purple_concrete
setblock 386 247 586 minecraft:black_concrete
fill 386 247 589 389 247 589 minecraft:black_concrete
fill 387 247 566 390 247 566 minecraft:black_concrete
setblock 387 247 569 minecraft:black_concrete
fill 387 247 570 388 248 572 minecraft:white_concrete
fill 387 247 584 388 248 586 minecraft:white_concrete
fill 387 247 590 391 247 592 minecraft:black_concrete
fill 388 247 565 392 247 565 minecraft:black_concrete
setblock 388 247 569 minecraft:purple_concrete
setblock 388 247 575 minecraft:white_concrete
setblock 388 247 578 minecraft:white_concrete
setblock 388 247 581 minecraft:white_concrete
setblock 388 247 587 minecraft:purple_concrete
fill 388 247 593 403 247 593 minecraft:black_concrete
fill 388 247 599 388 249 599 minecraft:black_concrete
fill 389 247 564 405 247 564 minecraft:black_concrete
fill 389 247 568 391 248 569 minecraft:white_concrete
setblock 389 247 571 minecraft:white_concrete
fill 389 247 583 389 247 585 minecraft:white_concrete
fill 389 247 587 391 248 588 minecraft:white_concrete
fill 389 247 594 399 247 594 minecraft:black_concrete
fill 390 247 557 390 250 557 minecraft:black_concrete
setblock 390 247 567 minecraft:purple_concrete
setblock 390 247 570 minecraft:white_concrete
setblock 390 247 572 minecraft:white_concrete
setblock 390 247 584 minecraft:white_concrete
fill 390 247 586 392 247 586 minecraft:white_concrete
fill 390 247 589 391 247 589 minecraft:purple_concrete
fill 391 247 563 403 247 563 minecraft:black_concrete
fill 391 247 566 392 247 566 minecraft:purple_concrete
fill 391 247 571 393 247 575 minecraft:red_nether_bricks
setblock 391 247 585 minecraft:white_concrete
fill 392 247 569 395 247 569 minecraft:red_nether_bricks
fill 392 247 577 395 247 577 minecraft:red_nether_bricks
setblock 392 247 590 minecraft:purple_concrete
fill 392 247 591 394 247 592 minecraft:black_concrete
fill 393 247 565 400 247 565 minecraft:purple_concrete
fill 393 247 566 394 248 567 minecraft:white_concrete
fill 393 247 588 394 247 590 minecraft:white_concrete
setblock 393 247 599 minecraft:purple_concrete
setblock 394 247 557 minecraft:purple_concrete
setblock 394 247 571 minecraft:red_nether_bricks
setblock 394 247 575 minecraft:red_nether_bricks
setblock 394 247 587 minecraft:white_concrete
fill 395 247 562 399 247 562 minecraft:black_concrete
setblock 395 247 568 minecraft:red_nether_bricks
setblock 395 247 578 minecraft:red_nether_bricks
fill 395 247 591 399 247 591 minecraft:purple_concrete
fill 395 247 592 405 247 592 minecraft:black_concrete
fill 396 247 566 397 248 566 minecraft:white_concrete
fill 396 247 568 396 248 568 minecraft:shroomlight
fill 396 247 578 396 248 578 minecraft:shroomlight
fill 396 247 588 398 247 590 minecraft:white_concrete
setblock 397 247 568 minecraft:red_nether_bricks
setblock 397 247 578 minecraft:red_nether_bricks
setblock 397 247 587 minecraft:white_concrete
fill 398 247 566 400 247 566 minecraft:red_nether_bricks
fill 398 247 580 400 247 580 minecraft:red_nether_bricks
fill 400 247 587 400 247 590 minecraft:white_concrete
fill 400 247 591 406 247 591 minecraft:black_concrete
fill 401 247 557 401 250 557 minecraft:black_concrete
fill 401 247 565 406 247 565 minecraft:black_concrete
fill 401 247 566 401 248 566 minecraft:white_concrete
fill 401 247 568 403 247 568 minecraft:red_nether_bricks
fill 401 247 578 403 247 578 minecraft:red_nether_bricks
fill 401 247 581 404 247 581 minecraft:black_concrete
fill 401 247 588 401 248 590 minecraft:white_concrete
setblock 402 247 557 minecraft:purple_concrete
fill 402 247 566 403 247 566 minecraft:purple_concrete
fill 402 247 586 404 247 586 minecraft:white_concrete
setblock 402 247 590 minecraft:purple_concrete
fill 403 247 569 404 248 569 minecraft:red_nether_bricks
fill 403 247 577 404 248 577 minecraft:red_nether_bricks
setblock 403 247 585 minecraft:white_concrete
fill 403 247 587 405 248 588 minecraft:white_concrete
fill 403 247 589 404 247 589 minecraft:purple_concrete
fill 403 247 590 407 247 590 minecraft:black_concrete
fill 404 247 566 407 247 566 minecraft:black_concrete
setblock 404 247 567 minecraft:purple_concrete
fill 404 247 584 407 247 584 minecraft:white_concrete
setblock 404 247 599 minecraft:purple_concrete
setblock 405 247 557 minecraft:purple_concrete
fill 405 247 567 408 247 567 minecraft:black_concrete
fill 405 247 572 406 248 572 minecraft:red_nether_bricks
fill 405 247 574 406 248 574 minecraft:red_nether_bricks
setblock 405 247 583 minecraft:white_concrete
fill 405 247 585 407 247 585 minecraft:white_concrete
fill 405 247 589 408 247 589 minecraft:black_concrete
setblock 406 247 568 minecraft:purple_concrete
setblock 406 247 578 minecraft:white_concrete
fill 406 247 586 407 248 586 minecraft:white_concrete
setblock 406 247 587 minecraft:purple_concrete
fill 406 247 588 409 247 588 minecraft:black_concrete
fill 407 247 568 409 247 568 minecraft:black_concrete
setblock 407 247 569 minecraft:purple_concrete
fill 407 247 577 409 247 577 minecraft:white_concrete
fill 407 247 579 409 247 579 minecraft:white_concrete
fill 407 247 582 409 248 582 minecraft:white_concrete
fill 407 247 587 410 247 587 minecraft:black_concrete
fill 408 247 569 410 247 570 minecraft:black_concrete
setblock 408 247 571 minecraft:purple_concrete
fill 408 247 574 409 248 575 minecraft:white_concrete
fill 408 247 578 409 248 578 minecraft:white_concrete
fill 408 247 581 409 248 581 minecraft:white_concrete
fill 408 247 584 408 247 585 minecraft:purple_concrete
fill 408 247 586 411 247 586 minecraft:black_concrete
fill 408 247 599 408 250 599 minecraft:black_concrete
fill 409 247 571 411 247 571 minecraft:black_concrete
fill 409 247 572 409 247 573 minecraft:purple_concrete
setblock 409 247 583 minecraft:purple_concrete
fill 409 247 584 411 247 585 minecraft:black_concrete
fill 410 247 572 412 247 573 minecraft:black_concrete
fill 410 247 574 410 247 581 minecraft:purple_concrete
fill 410 247 582 412 247 583 minecraft:black_concrete
setblock 411 247 570 minecraft:black_concrete
fill 411 247 574 412 247 581 minecraft:black_concrete
setblock 412 247 584 minecraft:black_concrete
fill 413 247 576 413 247 580 minecraft:black_concrete
fill 418 247 560 418 250 561 minecraft:black_concrete
setblock 418 247 565 minecraft:purple_concrete
setblock 418 247 575 minecraft:black_concrete
setblock 418 247 576 minecraft:purple_concrete
fill 418 247 577 418 249 577 minecraft:black_concrete
fill 418 247 581 418 250 581 minecraft:black_concrete
fill 418 247 592 418 250 592 minecraft:black_concrete
setblock 418 247 593 minecraft:purple_concrete
fill 418 247 596 418 247 597 minecraft:purple_concrete
fill 376 248 562 376 249 562 minecraft:purple_concrete
fill 376 248 564 376 253 564 minecraft:black_concrete
fill 376 248 565 376 248 566 minecraft:purple_concrete
fill 376 248 567 376 253 567 minecraft:black_concrete
fill 376 248 571 376 249 572 minecraft:black_concrete
fill 376 248 573 376 249 574 minecraft:purple_concrete
fill 376 248 575 376 253 576 minecraft:black_concrete
fill 376 248 585 376 248 586 minecraft:purple_concrete
fill 376 248 587 376 253 588 minecraft:black_concrete
fill 376 248 593 376 249 594 minecraft:purple_concrete
fill 376 248 595 376 253 596 minecraft:black_concrete
setblock 376 248 597 minecraft:purple_concrete
fill 376 248 599 376 250 599 minecraft:black_concrete
fill 381 248 557 382 253 557 minecraft:black_concrete
fill 382 248 599 383 249 599 minecraft:purple_concrete
fill 383 248 557 384 248 557 minecraft:purple_concrete
fill 383 248 578 386 248 578 minecraft:white_concrete
fill 384 248 573 385 248 575 minecraft:white_concrete
fill 384 248 577 386 248 577 minecraft:white_concrete
fill 384 248 579 386 248 579 minecraft:white_concrete
fill 384 248 581 385 248 583 minecraft:white_concrete
fill 384 248 599 385 253 599 minecraft:black_concrete
fill 386 248 570 386 248 571 minecraft:white_concrete
fill 386 248 574 386 248 575 minecraft:white_concrete
fill 386 248 581 386 248 582 minecraft:white_concrete
fill 386 248 585 386 248 586 minecraft:white_concrete
setblock 387 248 574 minecraft:white_concrete
setblock 387 248 582 minecraft:white_concrete
fill 388 248 591 391 248 592 minecraft:black_concrete
fill 389 248 567 390 248 567 minecraft:white_concrete
fill 389 248 589 390 248 589 minecraft:white_concrete
fill 389 248 590 391 248 590 minecraft:black_concrete
fill 389 248 593 391 248 594 minecraft:black_concrete
setblock 390 248 599 minecraft:black_concrete
fill 391 248 573 393 248 573 minecraft:red_nether_bricks
fill 391 248 595 392 248 595 minecraft:black_concrete
fill 391 248 599 391 249 599 minecraft:purple_concrete
fill 392 248 565 392 248 566 minecraft:white_concrete
fill 392 248 570 392 248 572 minecraft:red_nether_bricks
fill 392 248 574 392 248 576 minecraft:red_nether_bricks
fill 392 248 590 394 248 591 minecraft:white_concrete
fill 392 248 592 395 251 594 minecraft:purple_concrete
fill 393 248 557 394 253 557 minecraft:black_concrete
fill 393 248 565 394 248 565 minecraft:white_concrete
setblock 393 248 568 minecraft:white_concrete
fill 393 248 569 394 248 569 minecraft:red_nether_bricks
fill 393 248 571 393 249 572 minecraft:red_nether_bricks
fill 393 248 574 393 249 575 minecraft:red_nether_bricks
fill 393 248 577 394 248 577 minecraft:red_nether_bricks
fill 393 248 588 393 248 589 minecraft:white_concrete
fill 393 248 595 394 252 595 minecraft:purple_concrete
fill 393 248 599 393 253 599 minecraft:black_concrete
setblock 394 248 589 minecraft:white_concrete
fill 394 248 599 395 248 599 minecraft:purple_concrete
fill 395 248 557 396 249 557 minecraft:purple_concrete
fill 395 248 568 395 248 569 minecraft:shroomlight
fill 395 248 577 395 248 578 minecraft:shroomlight
fill 396 248 565 398 248 565 minecraft:white_concrete
setblock 396 248 567 minecraft:white_concrete
fill 396 248 589 398 248 591 minecraft:white_concrete
fill 396 248 599 397 250 599 minecraft:black_concrete
setblock 397 248 564 minecraft:white_concrete
setblock 397 248 567 minecraft:red_nether_bricks
setblock 397 248 579 minecraft:red_nether_bricks
setblock 397 248 592 minecraft:white_concrete
setblock 398 248 566 minecraft:white_concrete
fill 400 248 565 400 248 566 minecraft:white_concrete
fill 400 248 589 400 248 591 minecraft:white_concrete
setblock 401 248 565 minecraft:black_concrete
setblock 401 248 567 minecraft:red_nether_bricks
setblock 401 248 579 minecraft:red_nether_bricks
setblock 401 248 581 minecraft:black_concrete
fill 401 248 591 402 248 591 minecraft:white_concrete
fill 402 248 557 402 253 557 minecraft:black_concrete
fill 402 248 564 406 248 564 minecraft:black_concrete
fill 402 248 565 402 248 566 minecraft:white_concrete
fill 402 248 568 403 248 568 minecraft:red_nether_bricks
fill 402 248 578 403 248 578 minecraft:red_nether_bricks
fill 402 248 582 406 248 582 minecraft:black_concrete
setblock 402 248 590 minecraft:white_concrete
fill 402 248 599 403 249 599 minecraft:purple_concrete
fill 403 248 557 404 248 557 minecraft:purple_concrete
fill 404 248 567 405 248 567 minecraft:white_concrete
fill 404 248 570 405 248 570 minecraft:red_nether_bricks
fill 404 248 576 405 248 576 minecraft:red_nether_bricks
fill 404 248 589 405 248 589 minecraft:white_concrete
fill 404 248 599 405 253 599 minecraft:black_concrete
fill 405 248 557 405 253 557 minecraft:black_concrete
fill 405 248 563 407 248 563 minecraft:black_concrete
setblock 405 248 568 minecraft:white_concrete
fill 405 248 571 405 249 571 minecraft:red_nether_bricks
fill 405 248 575 405 249 575 minecraft:red_nether_bricks
fill 405 248 583 407 248 583 minecraft:black_concrete
fill 406 248 584 407 248 585 minecraft:white_concrete
fill 407 248 557 407 249 557 minecraft:purple_concrete
fill 407 248 570 407 248 572 minecraft:white_concrete
setblock 407 248 573 minecraft:red_nether_bricks
setblock 407 248 574 minecraft:white_concrete
fill 408 248 570 408 248 571 minecraft:white_concrete
fill 408 248 577 410 248 577 minecraft:white_concrete
fill 408 248 579 410 248 579 minecraft:white_concrete
fill 408 248 585 408 248 586 minecraft:white_concrete
fill 409 248 573 410 248 573 minecraft:white_concrete
fill 409 248 583 410 248 583 minecraft:white_concrete
fill 410 248 574 410 248 575 minecraft:white_concrete
fill 410 248 578 411 248 578 minecraft:white_concrete
fill 410 248 581 410 248 582 minecraft:white_concrete
fill 413 248 557 414 253 557 minecraft:black_concrete
fill 414 248 599 415 248 599 minecraft:purple_concrete
fill 415 248 557 416 249 557 minecraft:purple_concrete
fill 416 248 599 417 253 599 minecraft:black_concrete
fill 418 248 562 418 251 562 minecraft:black_concrete
setblock 418 248 563 minecraft:purple_concrete
fill 418 248 564 418 253 565 minecraft:black_concrete
fill 418 248 566 418 249 567 minecraft:purple_concrete
fill 418 248 572 418 253 573 minecraft:black_concrete
fill 418 248 574 418 248 575 minecraft:purple_concrete
fill 418 248 576 418 253 576 minecraft:black_concrete
fill 418 248 584 418 253 585 minecraft:black_concrete
fill 418 248 586 418 249 587 minecraft:purple_concrete
fill 418 248 593 418 253 593 minecraft:black_concrete
setblock 418 248 595 minecraft:purple_concrete
fill 418 248 596 418 253 597 minecraft:black_concrete
fill 418 248 598 418 249 598 minecraft:purple_concrete
setblock 376 249 561 minecraft:purple_concrete
fill 376 249 565 376 252 566 minecraft:black_concrete
setblock 376 249 582 minecraft:purple_concrete
setblock 376 249 585 minecraft:purple_concrete
fill 376 249 586 376 252 586 minecraft:black_concrete
fill 376 249 597 376 252 597 minecraft:black_concrete
fill 378 249 599 378 251 599 minecraft:black_concrete
setblock 379 249 599 minecraft:purple_concrete
fill 383 249 557 383 252 557 minecraft:black_concrete
setblock 384 249 557 minecraft:purple_concrete
setblock 387 249 557 minecraft:purple_concrete
fill 389 249 591 390 249 593 minecraft:black_concrete
setblock 390 249 594 minecraft:black_concrete
setblock 390 249 599 minecraft:purple_concrete
fill 391 249 590 391 249 592 minecraft:black_concrete
fill 391 249 593 391 250 594 minecraft:purple_concrete
setblock 391 249 595 minecraft:black_concrete
fill 392 249 590 393 249 590 minecraft:black_concrete
fill 392 249 591 395 250 591 minecraft:purple_concrete
fill 392 249 595 392 251 595 minecraft:purple_concrete
setblock 393 249 573 minecraft:red_nether_bricks
setblock 394 249 599 minecraft:purple_concrete
fill 395 249 595 395 254 595 minecraft:purple_concrete
fill 395 249 599 395 252 599 minecraft:black_concrete
fill 396 249 592 396 255 594 minecraft:purple_concrete
setblock 401 249 564 minecraft:black_concrete
setblock 401 249 582 minecraft:black_concrete
setblock 402 249 563 minecraft:black_concrete
setblock 402 249 583 minecraft:black_concrete
fill 403 249 557 404 252 557 minecraft:black_concrete
fill 404 249 563 405 249 563 minecraft:black_concrete
fill 404 249 583 405 249 583 minecraft:black_concrete
setblock 405 249 572 minecraft:red_nether_bricks
setblock 405 249 574 minecraft:red_nether_bricks
setblock 406 249 562 minecraft:black_concrete
setblock 406 249 584 minecraft:black_concrete
setblock 408 249 557 minecraft:purple_concrete
setblock 409 249 562 minecraft:black_concrete
setblock 409 249 584 minecraft:black_concrete
setblock 411 249 599 minecraft:purple_concrete
setblock 414 249 599 minecraft:purple_concrete
fill 415 249 599 415 252 599 minecraft:black_concrete
setblock 418 249 558 minecraft:purple_concrete
fill 418 249 563 418 252 563 minecraft:black_concrete
fill 418 249 574 418 252 574 minecraft:black_concrete
setblock 418 249 575 minecraft:purple_concrete
fill 418 249 578 418 249 579 minecraft:purple_concrete
fill 418 249 595 418 252 595 minecraft:black_concrete
fill 376 250 559 376 251 560 minecraft:purple_concrete
fill 376 250 561 376 255 562 minecraft:black_concrete
setblock 376 250 563 minecraft:purple_concrete
fill 376 250 571 376 251 572 minecraft:purple_concrete
fill 376 250 573 376 255 574 minecraft:black_concrete
fill 376 250 580 376 251 580 minecraft:purple_concrete
fill 376 250 582 376 255 582 minecraft:black_concrete
fill 376 250 583 376 250 584 minecraft:purple_concrete
fill 376 250 585 376 255 585 minecraft:black_concrete
fill 376 250 591 376 251 592 minecraft:purple_concrete
fill 376 250 593 376 255 594 minecraft:black_concrete
fill 377 250 557 378 251 557 minecraft:purple_concrete
fill 379 250 599 379 251 599 minecraft:black_concrete
fill 380 250 599 381 250 599 minecraft:purple_concrete
fill 382 250 599 383 255 599 minecraft:black_concrete
fill 384 250 557 384 255 557 minecraft:black_concrete
fill 385 250 557 386 250 557 minecraft:purple_concrete
fill 387 250 557 387 255 557 minecraft:black_concrete
fill 388 250 599 389 251 599 minecraft:purple_concrete
fill 389 250 557 389 251 557 minecraft:purple_concrete
fill 390 250 592 390 250 593 minecraft:black_concrete
fill 390 250 599 391 255 599 minecraft:black_concrete
setblock 391 250 591 minecraft:black_concrete
setblock 391 250 592 minecraft:purple_concrete
setblock 392 250 599 minecraft:purple_concrete
fill 394 250 599 394 252 599 minecraft:black_concrete
fill 395 250 557 396 255 557 minecraft:black_concrete
fill 396 250 591 396 254 591 minecraft:purple_concrete
fill 396 250 595 397 255 595 minecraft:purple_concrete
fill 397 250 557 398 251 557 minecraft:purple_concrete
fill 397 250 592 397 256 594 minecraft:purple_concrete
fill 400 250 599 401 251 599 minecraft:purple_concrete
fill 401 250 563 401 251 563 minecraft:black_concrete
fill 401 250 583 401 251 583 minecraft:black_concrete
fill 402 250 599 403 255 599 minecraft:black_concrete
fill 403 250 562 403 251 562 minecraft:black_concrete
setblock 403 250 568 minecraft:blackstone
setblock 403 250 578 minecraft:blackstone
fill 403 250 584 403 251 584 minecraft:black_concrete
setblock 405 250 562 minecraft:black_concrete
setblock 405 250 584 minecraft:black_concrete
setblock 406 250 557 minecraft:purple_concrete
fill 407 250 557 408 255 557 minecraft:black_concrete
fill 407 250 561 408 250 561 minecraft:black_concrete
fill 407 250 585 408 250 585 minecraft:black_concrete
fill 409 250 557 410 251 557 minecraft:purple_concrete
fill 409 250 599 409 251 599 minecraft:purple_concrete
fill 411 250 561 412 250 561 minecraft:black_concrete
fill 411 250 585 412 250 585 minecraft:black_concrete
fill 411 250 599 411 255 599 minecraft:black_concrete
fill 412 250 560 413 250 560 minecraft:black_concrete
fill 412 250 586 413 250 586 minecraft:black_concrete
fill 412 250 599 413 250 599 minecraft:purple_concrete
fill 414 250 599 414 255 599 minecraft:black_concrete
fill 415 250 557 416 255 557 minecraft:black_concrete
fill 417 250 557 418 250 557 minecraft:purple_concrete
fill 418 250 558 418 255 558 minecraft:black_concrete
fill 418 250 566 418 255 567 minecraft:black_concrete
fill 418 250 568 418 251 569 minecraft:purple_concrete
fill 418 250 575 418 255 575 minecraft:black_concrete
setblock 418 250 577 minecraft:purple_concrete
fill 418 250 578 418 255 579 minecraft:black_concrete
fill 418 250 580 418 251 580 minecraft:purple_concrete
fill 418 250 586 418 255 587 minecraft:black_concrete
fill 418 250 588 418 250 589 minecraft:purple_concrete
fill 418 250 598 418 255 598 minecraft:black_concrete
fill 376 251 563 376 254 563 minecraft:black_concrete
setblock 376 251 568 minecraft:purple_concrete
setblock 376 251 579 minecraft:purple_concrete
fill 376 251 583 376 253 584 minecraft:black_concrete
fill 376 251 599 377 251 599 minecraft:purple_concrete
setblock 380 251 599 minecraft:purple_concrete
fill 381 251 599 381 254 599 minecraft:black_concrete
fill 385 251 557 386 254 557 minecraft:black_concrete
setblock 390 251 557 minecraft:purple_concrete
setblock 391 251 592 minecraft:black_concrete
setblock 391 251 593 minecraft:purple_concrete
setblock 392 251 591 minecraft:black_concrete
fill 392 251 599 392 254 599 minecraft:black_concrete
fill 393 251 591 395 251 591 minecraft:purple_concrete
setblock 395 251 596 minecraft:purple_concrete
fill 396 251 599 396 253 599 minecraft:black_concrete
fill 397 251 591 397 254 591 minecraft:purple_concrete
setblock 397 251 599 minecraft:purple_concrete
fill 398 251 592 398 256 595 minecraft:purple_concrete
fill 399 251 593 399 258 593 minecraft:purple_concrete
setblock 401 251 557 minecraft:purple_concrete
fill 401 251 562 401 252 562 minecraft:black_concrete
fill 401 251 584 401 252 584 minecraft:black_concrete
fill 403 251 561 403 252 561 minecraft:black_concrete
fill 403 251 567 404 252 567 minecraft:blackstone
fill 403 251 579 404 252 579 minecraft:blackstone
fill 403 251 585 403 252 585 minecraft:black_concrete
fill 404 251 568 404 253 568 minecraft:blackstone
fill 404 251 578 404 253 578 minecraft:blackstone
fill 406 251 557 406 254 557 minecraft:black_concrete
fill 406 251 561 406 252 561 minecraft:black_concrete
fill 406 251 585 406 252 585 minecraft:black_concrete
setblock 408 251 599 minecraft:purple_concrete
setblock 409 251 560 minecraft:black_concrete
setblock 409 251 586 minecraft:black_concrete
fill 410 251 559 410 252 559 minecraft:black_concrete
fill 410 251 587 410 252 587 minecraft:black_concrete
fill 412 251 599 413 254 599 minecraft:black_concrete
setblock 413 251 560 minecraft:black_concrete
setblock 413 251 586 minecraft:black_concrete
fill 417 251 557 417 254 557 minecraft:black_concrete
setblock 418 251 557 minecraft:purple_concrete
fill 418 251 560 418 251 561 minecraft:purple_concrete
fill 418 251 577 418 254 577 minecraft:black_concrete
setblock 418 251 581 minecraft:purple_concrete
fill 418 251 588 418 254 588 minecraft:black_concrete
setblock 418 251 589 minecraft:purple_concrete
setblock 418 251 592 minecraft:purple_concrete
fill 376 252 557 376 253 558 minecraft:purple_concrete
fill 376 252 559 376 257 560 minecraft:black_concrete
fill 376 252 568 376 257 568 minecraft:black_concrete
fill 376 252 569 376 252 570 minecraft:purple_concrete
fill 376 252 571 376 257 572 minecraft:black_concrete
fill 376 252 577 376 253 578 minecraft:purple_concrete
fill 376 252 579 376 257 580 minecraft:black_concrete
setblock 376 252 581 minecraft:purple_concrete
fill 376 252 589 376 253 590 minecraft:purple_concrete
fill 376 252 591 376 257 592 minecraft:black_concrete
fill 376 252 598 376 253 598 minecraft:purple_concrete
fill 376 252 599 377 253 599 minecraft:black_concrete
fill 377 252 557 378 257 557 minecraft:black_concrete
fill 377 252 558 379 252 558 minecraft:obsidian
fill 377 252 560 377 252 562 minecraft:obsidian
fill 377 252 564 377 252 566 minecraft:obsidian
fill 377 252 568 377 252 570 minecraft:obsidian
fill 377 252 572 377 252 574 minecraft:obsidian
fill 377 252 576 377 252 578 minecraft:obsidian
fill 377 252 580 377 252 582 minecraft:obsidian
fill 377 252 584 377 252 586 minecraft:obsidian
fill 377 252 588 377 252 590 minecraft:obsidian
fill 377 252 592 377 252 594 minecraft:obsidian
fill 377 252 596 377 252 598 minecraft:obsidian
fill 378 252 599 379 252 599 minecraft:purple_concrete
fill 379 252 557 380 253 557 minecraft:purple_concrete
fill 379 252 598 381 252 598 minecraft:obsidian
fill 380 252 599 380 257 599 minecraft:black_concrete
fill 381 252 558 383 252 558 minecraft:obsidian
fill 383 252 598 385 252 598 minecraft:obsidian
fill 385 252 558 387 252 558 minecraft:obsidian
fill 386 252 599 387 253 599 minecraft:purple_concrete
fill 387 252 598 389 252 598 minecraft:obsidian
setblock 388 252 557 minecraft:purple_concrete
fill 388 252 599 389 257 599 minecraft:black_concrete
fill 389 252 557 390 257 557 minecraft:black_concrete
fill 389 252 558 391 252 558 minecraft:obsidian
fill 391 252 557 392 253 557 minecraft:purple_concrete
fill 391 252 598 393 252 598 minecraft:obsidian
fill 392 252 593 395 252 593 minecraft:purple_concrete
fill 393 252 558 395 252 558 minecraft:obsidian
fill 393 252 592 395 252 592 minecraft:purple_concrete
fill 393 252 594 395 252 594 minecraft:purple_concrete
fill 394 252 591 395 252 591 minecraft:purple_concrete
fill 395 252 598 397 252 598 minecraft:obsidian
fill 396 252 596 397 253 596 minecraft:purple_concrete
fill 397 252 557 398 257 557 minecraft:black_concrete
fill 397 252 558 399 252 558 minecraft:obsidian
fill 397 252 599 397 257 599 minecraft:black_concrete
fill 398 252 591 398 256 591 minecraft:purple_concrete
fill 398 252 599 399 252 599 minecraft:purple_concrete
fill 399 252 557 400 252 557 minecraft:purple_concrete
fill 399 252 592 399 258 592 minecraft:purple_concrete
fill 399 252 594 399 257 595 minecraft:purple_concrete
fill 399 252 598 401 252 598 minecraft:obsidian
fill 400 252 593 400 257 594 minecraft:purple_concrete
fill 400 252 599 401 257 599 minecraft:black_concrete
fill 401 252 557 401 257 557 minecraft:black_concrete
fill 401 252 558 403 252 558 minecraft:obsidian
fill 403 252 598 405 252 598 minecraft:obsidian
fill 405 252 558 407 252 558 minecraft:obsidian
fill 405 252 567 405 254 567 minecraft:blackstone
fill 405 252 579 405 254 579 minecraft:blackstone
fill 406 252 599 407 253 599 minecraft:purple_concrete
fill 407 252 560 407 253 560 minecraft:black_concrete
fill 407 252 586 407 253 586 minecraft:black_concrete
fill 407 252 598 409 252 598 minecraft:obsidian
fill 408 252 599 409 257 599 minecraft:black_concrete
fill 409 252 557 410 257 557 minecraft:black_concrete
fill 409 252 558 411 252 558 minecraft:obsidian
setblock 410 252 599 minecraft:purple_concrete
fill 411 252 557 412 253 557 minecraft:purple_concrete
fill 411 252 598 413 252 598 minecraft:obsidian
fill 413 252 558 415 252 558 minecraft:obsidian
fill 415 252 598 417 252 598 minecraft:obsidian
fill 417 252 558 417 252 560 minecraft:obsidian
fill 417 252 562 417 252 564 minecraft:obsidian
fill 417 252 566 417 252 568 minecraft:obsidian
fill 417 252 570 417 252 572 minecraft:obsidian
fill 417 252 574 417 252 576 minecraft:obsidian
fill 417 252 578 417 252 580 minecraft:obsidian
fill 417 252 582 417 252 584 minecraft:obsidian
fill 417 252 586 417 252 588 minecraft:obsidian
fill 417 252 590 417 252 592 minecraft:obsidian
fill 417 252 594 417 252 596 minecraft:obsidian
fill 418 252 557 418 257 557 minecraft:black_concrete
setblock 418 252 559 minecraft:purple_concrete
fill 418 252 560 418 257 561 minecraft:black_concrete
fill 418 252 562 418 253 562 minecraft:purple_concrete
fill 418 252 568 418 257 569 minecraft:black_concrete
fill 418 252 570 418 252 571 minecraft:purple_concrete
fill 418 252 580 418 257 581 minecraft:black_concrete
fill 418 252 582 418 253 583 minecraft:purple_concrete
fill 418 252 589 418 257 589 minecraft:black_concrete
fill 418 252 590 418 252 591 minecraft:purple_concrete
fill 418 252 592 418 257 592 minecraft:black_concrete
fill 418 252 594 418 253 594 minecraft:purple_concrete
fill 418 252 599 418 253 599 minecraft:purple_concrete
fill 376 253 565 376 253 566 minecraft:purple_concrete
setblock 376 253 569 minecraft:purple_concrete
fill 376 253 570 376 256 570 minecraft:black_concrete
fill 376 253 581 376 255 581 minecraft:black_concrete
setblock 376 253 586 minecraft:purple_concrete
setblock 376 253 597 minecraft:purple_concrete
fill 378 253 599 379 255 599 minecraft:black_concrete
setblock 379 253 560 minecraft:light[level=12]
setblock 379 253 568 minecraft:light[level=12]
setblock 379 253 576 minecraft:light[level=12]
setblock 379 253 584 minecraft:light[level=12]
setblock 379 253 592 minecraft:light[level=12]
setblock 383 253 557 minecraft:purple_concrete
setblock 387 253 560 minecraft:light[level=12]
setblock 387 253 568 minecraft:light[level=12]
setblock 387 253 576 minecraft:light[level=12]
setblock 387 253 584 minecraft:light[level=12]
setblock 387 253 592 minecraft:light[level=12]
fill 388 253 557 388 256 557 minecraft:black_concrete
fill 393 253 593 395 253 593 minecraft:purple_concrete
fill 394 253 592 395 253 592 minecraft:purple_concrete
fill 394 253 594 394 253 595 minecraft:purple_concrete
fill 394 253 599 395 253 599 minecraft:purple_concrete
setblock 395 253 560 minecraft:light[level=12]
setblock 395 253 584 minecraft:light[level=12]
setblock 395 253 591 minecraft:purple_concrete
fill 395 253 594 395 254 594 minecraft:purple_concrete
fill 398 253 596 398 255 596 minecraft:purple_concrete
setblock 398 253 599 minecraft:purple_concrete
fill 399 253 557 399 256 557 minecraft:black_concrete
fill 399 253 591 399 257 591 minecraft:purple_concrete
fill 399 253 599 399 256 599 minecraft:black_concrete
setblock 400 253 557 minecraft:purple_concrete
fill 400 253 592 400 257 592 minecraft:purple_concrete
fill 400 253 595 400 257 595 minecraft:purple_concrete
setblock 401 253 561 minecraft:black_concrete
setblock 401 253 585 minecraft:black_concrete
fill 401 253 593 401 255 594 minecraft:purple_concrete
fill 403 253 557 404 253 557 minecraft:purple_concrete
setblock 403 253 560 minecraft:light[level=12]
setblock 403 253 584 minecraft:light[level=12]
setblock 403 253 592 minecraft:light[level=12]
fill 404 253 559 404 253 560 minecraft:black_concrete
fill 404 253 566 404 253 567 minecraft:blackstone
fill 404 253 579 404 253 580 minecraft:blackstone
fill 404 253 586 404 253 587 minecraft:black_concrete
fill 405 253 566 405 255 566 minecraft:blackstone
fill 405 253 580 405 255 580 minecraft:blackstone
fill 410 253 599 410 256 599 minecraft:black_concrete
setblock 411 253 560 minecraft:light[level=12]
setblock 411 253 568 minecraft:light[level=12]
fill 411 253 573 412 254 573 minecraft:amethyst_block
setblock 411 253 576 minecraft:light[level=12]
setblock 411 253 584 minecraft:light[level=12]
setblock 411 253 592 minecraft:light[level=12]
setblock 415 253 599 minecraft:purple_concrete
fill 418 253 559 418 256 559 minecraft:black_concrete
setblock 418 253 563 minecraft:purple_concrete
fill 418 253 570 418 256 570 minecraft:black_concrete
setblock 418 253 571 minecraft:purple_concrete
setblock 418 253 574 minecraft:purple_concrete
fill 418 253 590 418 256 591 minecraft:black_concrete
setblock 418 253 595 minecraft:purple_concrete
fill 376 254 557 376 259 558 minecraft:black_concrete
fill 376 254 564 376 255 564 minecraft:purple_concrete
fill 376 254 565 376 259 566 minecraft:black_concrete
setblock 376 254 567 minecraft:purple_concrete
fill 376 254 569 376 259 569 minecraft:black_concrete
fill 376 254 575 376 255 576 minecraft:purple_concrete
fill 376 254 577 376 259 578 minecraft:black_concrete
setblock 376 254 583 minecraft:black_concrete
fill 376 254 584 376 255 584 minecraft:purple_concrete
fill 376 254 586 376 259 586 minecraft:black_concrete
fill 376 254 587 376 254 588 minecraft:purple_concrete
fill 376 254 589 376 256 590 minecraft:black_concrete
fill 376 254 595 376 255 596 minecraft:purple_concrete
fill 376 254 597 376 259 598 minecraft:black_concrete
setblock 376 254 599 minecraft:purple_concrete
fill 377 254 599 377 257 599 minecraft:black_concrete
fill 379 254 557 380 259 557 minecraft:black_concrete
fill 381 254 557 382 254 557 minecraft:purple_concrete
fill 383 254 557 383 259 557 minecraft:black_concrete
fill 384 254 599 385 255 599 minecraft:purple_concrete
fill 386 254 599 387 259 599 minecraft:black_concrete
fill 391 254 557 392 259 557 minecraft:black_concrete
fill 393 254 557 394 255 557 minecraft:purple_concrete
fill 393 254 593 394 256 593 minecraft:amethyst_block
fill 393 254 599 393 255 599 minecraft:purple_concrete
fill 394 254 599 395 259 599 minecraft:black_concrete
fill 395 254 592 395 254 593 minecraft:purple_concrete
setblock 396 254 599 minecraft:purple_concrete
setblock 397 254 596 minecraft:purple_concrete
fill 398 254 599 398 259 599 minecraft:black_concrete
fill 399 254 596 399 255 596 minecraft:purple_concrete
fill 400 254 557 400 259 557 minecraft:black_concrete
fill 400 254 591 401 256 591 minecraft:purple_concrete
fill 401 254 560 401 255 560 minecraft:black_concrete
fill 401 254 586 401 255 586 minecraft:black_concrete
fill 401 254 592 402 255 592 minecraft:purple_concrete
fill 401 254 595 401 258 595 minecraft:purple_concrete
setblock 402 254 557 minecraft:purple_concrete
fill 402 254 593 402 255 594 minecraft:purple_concrete
fill 403 254 557 404 259 557 minecraft:black_concrete
setblock 404 254 559 minecraft:black_concrete
setblock 404 254 567 minecraft:blackstone
setblock 404 254 579 minecraft:blackstone
setblock 404 254 587 minecraft:black_concrete
fill 404 254 599 405 255 599 minecraft:purple_concrete
fill 405 254 557 405 255 557 minecraft:purple_concrete
fill 406 254 566 406 255 567 minecraft:blackstone
fill 406 254 579 406 255 580 minecraft:blackstone
fill 406 254 599 407 259 599 minecraft:black_concrete
fill 411 254 557 412 259 557 minecraft:black_concrete
fill 413 254 557 414 254 557 minecraft:purple_concrete
fill 415 254 599 415 259 599 minecraft:black_concrete
fill 416 254 599 417 254 599 minecraft:purple_concrete
fill 418 254 562 418 259 563 minecraft:black_concrete
fill 418 254 564 418 255 565 minecraft:purple_concrete
fill 418 254 571 418 259 571 minecraft:black_concrete
fill 418 254 572 418 254 573 minecraft:purple_concrete
fill 418 254 574 418 259 574 minecraft:black_concrete
fill 418 254 576 418 255 576 minecraft:purple_concrete
fill 418 254 582 418 259 583 minecraft:black_concrete
fill 418 254 584 418 255 585 minecraft:purple_concrete
setblock 418 254 593 minecraft:purple_concrete
fill 418 254 594 418 259 595 minecraft:black_concrete
fill 418 254 596 418 255 597 minecraft:purple_concrete
fill 418 254 599 418 259 599 minecraft:black_concrete
setblock 376 255 563 minecraft:purple_concrete
fill 376 255 567 376 258 567 minecraft:black_concrete
setblock 376 255 583 minecraft:purple_concrete
setblock 376 255 587 minecraft:purple_concrete
fill 376 255 588 376 258 588 minecraft:black_concrete
fill 376 255 599 376 257 599 minecraft:black_concrete
fill 381 255 557 381 258 557 minecraft:black_concrete
setblock 381 255 599 minecraft:purple_concrete
setblock 382 255 557 minecraft:purple_concrete
fill 385 255 557 386 255 557 minecraft:purple_concrete
setblock 392 255 599 minecraft:purple_concrete
fill 396 255 599 396 258 599 minecraft:black_concrete
fill 402 255 557 402 258 557 minecraft:black_concrete
setblock 402 255 591 minecraft:purple_concrete
fill 402 255 595 402 257 595 minecraft:purple_concrete
fill 403 255 592 403 255 594 minecraft:purple_concrete
setblock 406 255 557 minecraft:purple_concrete
fill 406 255 565 407 256 565 minecraft:blackstone
fill 406 255 581 407 256 581 minecraft:blackstone
fill 407 255 566 407 256 566 minecraft:blackstone
fill 407 255 580 407 256 580 minecraft:blackstone
fill 412 255 599 413 255 599 minecraft:purple_concrete
fill 413 255 557 413 258 557 minecraft:black_concrete
setblock 414 255 557 minecraft:purple_concrete
setblock 416 255 599 minecraft:purple_concrete
setblock 417 255 557 minecraft:purple_concrete
fill 417 255 599 417 258 599 minecraft:black_concrete
fill 418 255 572 418 258 573 minecraft:black_concrete
setblock 418 255 577 minecraft:purple_concrete
setblock 418 255 588 minecraft:purple_concrete
fill 418 255 593 418 258 593 minecraft:black_concrete
fill 376 256 561 376 257 562 minecraft:purple_concrete
fill 376 256 563 376 261 564 minecraft:black_concrete
fill 376 256 573 376 256 574 minecraft:purple_concrete
fill 376 256 575 376 261 576 minecraft:black_concrete
fill 376 256 581 376 257 582 minecraft:purple_concrete
fill 376 256 583 376 261 584 minecraft:black_concrete
setblock 376 256 585 minecraft:purple_concrete
fill 376 256 587 376 258 587 minecraft:black_concrete
fill 376 256 593 376 257 594 minecraft:purple_concrete
fill 376 256 595 376 261 596 minecraft:black_concrete
setblock 378 256 599 minecraft:black_concrete
fill 379 256 599 379 257 599 minecraft:purple_concrete
fill 381 256 599 381 261 599 minecraft:black_concrete
fill 382 256 557 382 261 557 minecraft:black_concrete
fill 382 256 599 383 256 599 minecraft:purple_concrete
setblock 384 256 557 minecraft:purple_concrete
fill 384 256 599 385 258 599 minecraft:black_concrete
fill 385 256 557 386 261 557 minecraft:black_concrete
fill 387 256 557 387 257 557 minecraft:purple_concrete
fill 390 256 599 391 257 599 minecraft:purple_concrete
fill 392 256 599 393 261 599 minecraft:black_concrete
fill 393 256 557 394 261 557 minecraft:black_concrete
fill 395 256 557 396 256 557 minecraft:purple_concrete
fill 401 256 592 404 260 593 minecraft:black_concrete
setblock 401 256 594 minecraft:purple_concrete
fill 402 256 591 403 261 591 minecraft:black_concrete
fill 402 256 594 403 260 594 minecraft:black_concrete
fill 402 256 599 403 256 599 minecraft:purple_concrete
fill 404 256 599 405 261 599 minecraft:black_concrete
fill 405 256 557 406 261 557 minecraft:black_concrete
setblock 406 256 566 minecraft:blackstone
setblock 406 256 580 minecraft:blackstone
fill 407 256 557 408 257 557 minecraft:purple_concrete
fill 411 256 599 411 257 599 minecraft:purple_concrete
fill 412 256 599 413 261 599 minecraft:black_concrete
fill 414 256 557 414 261 557 minecraft:black_concrete
setblock 414 256 599 minecraft:purple_concrete
fill 415 256 557 416 256 557 minecraft:purple_concrete
fill 416 256 599 416 261 599 minecraft:black_concrete
fill 417 256 557 417 261 557 minecraft:black_concrete
fill 418 256 558 418 257 558 minecraft:purple_concrete
fill 418 256 564 418 261 565 minecraft:black_concrete
fill 418 256 566 418 257 567 minecraft:purple_concrete
setblock 418 256 575 minecraft:purple_concrete
fill 418 256 576 418 261 577 minecraft:black_concrete
fill 418 256 578 418 257 579 minecraft:purple_concrete
fill 418 256 584 418 261 585 minecraft:black_concrete
fill 418 256 586 418 256 587 minecraft:purple_concrete
fill 418 256 588 418 261 588 minecraft:black_concrete
fill 418 256 596 418 261 597 minecraft:black_concrete
fill 418 256 598 418 257 598 minecraft:purple_concrete
setblock 376 257 570 minecraft:purple_concrete
setblock 376 257 573 minecraft:purple_concrete
fill 376 257 574 376 260 574 minecraft:black_concrete
fill 376 257 585 376 260 585 minecraft:black_concrete
fill 376 257 589 376 259 589 minecraft:black_concrete
setblock 376 257 590 minecraft:purple_concrete
setblock 378 257 599 minecraft:purple_concrete
setblock 382 257 599 minecraft:purple_concrete
fill 383 257 599 383 260 599 minecraft:black_concrete
fill 384 257 557 384 260 557 minecraft:black_concrete
fill 385 257 583 387 258 583 minecraft:obsidian
fill 386 257 582 386 258 582 minecraft:obsidian
fill 386 257 584 386 258 584 minecraft:obsidian
setblock 388 257 557 minecraft:purple_concrete
fill 395 257 557 395 260 557 minecraft:black_concrete
setblock 396 257 557 minecraft:purple_concrete
fill 398 257 592 398 257 594 minecraft:purple_concrete
setblock 399 257 557 minecraft:purple_concrete
setblock 399 257 599 minecraft:purple_concrete
fill 400 257 591 400 258 591 minecraft:purple_concrete
setblock 401 257 590 minecraft:purple_concrete
fill 401 257 591 401 259 591 minecraft:black_concrete
fill 401 257 594 401 259 594 minecraft:black_concrete
fill 402 257 590 404 260 590 minecraft:black_concrete
setblock 402 257 599 minecraft:purple_concrete
fill 403 257 595 403 259 595 minecraft:black_concrete
fill 403 257 599 403 260 599 minecraft:black_concrete
fill 404 257 591 405 260 591 minecraft:black_concrete
fill 404 257 594 404 260 594 minecraft:black_concrete
fill 405 257 592 405 260 593 minecraft:black_concrete
setblock 407 257 565 minecraft:blackstone
setblock 407 257 581 minecraft:blackstone
setblock 410 257 599 minecraft:purple_concrete
fill 414 257 599 414 260 599 minecraft:black_concrete
fill 415 257 557 416 260 557 minecraft:black_concrete
setblock 418 257 559 minecraft:purple_concrete
setblock 418 257 570 minecraft:purple_concrete
fill 418 257 575 418 260 575 minecraft:black_concrete
fill 418 257 586 418 260 586 minecraft:black_concrete
setblock 418 257 587 minecraft:purple_concrete
fill 418 257 590 418 257 591 minecraft:purple_concrete
fill 376 258 559 376 259 560 minecraft:purple_concrete
fill 376 258 561 376 263 562 minecraft:black_concrete
fill 376 258 568 376 259 568 minecraft:purple_concrete
fill 376 258 570 376 263 570 minecraft:black_concrete
fill 376 258 571 376 258 572 minecraft:purple_concrete
fill 376 258 573 376 263 573 minecraft:black_concrete
fill 376 258 579 376 259 580 minecraft:purple_concrete
fill 376 258 581 376 263 582 minecraft:black_concrete
fill 376 258 590 376 259 590 minecraft:black_concrete
fill 376 258 591 376 258 592 minecraft:purple_concrete
fill 376 258 593 376 263 594 minecraft:black_concrete
fill 376 258 599 377 259 599 minecraft:purple_concrete
fill 377 258 557 378 258 557 minecraft:purple_concrete
fill 377 258 558 379 258 558 minecraft:obsidian
fill 377 258 560 377 258 562 minecraft:obsidian
fill 377 258 564 377 258 566 minecraft:obsidian
fill 377 258 568 377 258 570 minecraft:obsidian
fill 377 258 572 377 258 574 minecraft:obsidian
fill 377 258 576 377 258 578 minecraft:obsidian
fill 377 258 580 377 258 582 minecraft:obsidian
fill 377 258 584 377 258 586 minecraft:obsidian
fill 377 258 588 377 258 590 minecraft:obsidian
fill 377 258 592 377 258 594 minecraft:obsidian
fill 377 258 596 377 258 598 minecraft:obsidian
fill 378 258 599 379 263 599 minecraft:black_concrete
fill 379 258 598 381 258 598 minecraft:obsidian
setblock 380 258 599 minecraft:purple_concrete
fill 381 258 558 383 258 558 minecraft:obsidian
fill 382 258 599 382 260 599 minecraft:black_concrete
fill 383 258 598 385 258 598 minecraft:obsidian
fill 385 258 558 387 258 558 minecraft:obsidian
fill 387 258 557 388 263 557 minecraft:black_concrete
fill 387 258 598 389 258 598 minecraft:obsidian
fill 388 258 599 389 259 599 minecraft:purple_concrete
fill 389 258 557 390 259 557 minecraft:purple_concrete
fill 389 258 558 391 258 558 minecraft:obsidian
fill 390 258 599 391 263 599 minecraft:black_concrete
fill 391 258 598 393 258 598 minecraft:obsidian
fill 393 258 558 395 258 558 minecraft:obsidian
fill 395 258 598 397 258 598 minecraft:obsidian
fill 396 258 557 396 263 557 minecraft:black_concrete
fill 397 258 557 398 258 557 minecraft:purple_concrete
fill 397 258 558 399 258 558 minecraft:obsidian
fill 397 258 599 397 259 599 minecraft:purple_concrete
fill 399 258 557 399 263 557 minecraft:black_concrete
fill 399 258 594 400 258 594 minecraft:purple_concrete
fill 399 258 598 401 258 598 minecraft:obsidian
fill 399 258 599 399 263 599 minecraft:black_concrete
fill 400 258 592 400 258 593 minecraft:black_concrete
fill 400 258 599 401 258 599 minecraft:purple_concrete
fill 401 258 557 401 259 557 minecraft:purple_concrete
fill 401 258 558 403 258 558 minecraft:obsidian
setblock 402 258 595 minecraft:black_concrete
fill 402 258 599 402 263 599 minecraft:black_concrete
fill 403 258 598 405 258 598 minecraft:obsidian
fill 405 258 558 407 258 558 minecraft:obsidian
fill 405 258 590 406 259 590 minecraft:black_concrete
fill 405 258 594 405 260 594 minecraft:black_concrete
fill 406 258 591 406 259 593 minecraft:black_concrete
fill 407 258 557 408 263 557 minecraft:black_concrete
fill 407 258 598 409 258 598 minecraft:obsidian
fill 408 258 599 409 259 599 minecraft:purple_concrete
fill 409 258 557 410 259 557 minecraft:purple_concrete
fill 409 258 558 411 258 558 minecraft:obsidian
fill 410 258 599 411 263 599 minecraft:black_concrete
fill 411 258 598 413 258 598 minecraft:obsidian
fill 413 258 558 415 258 558 minecraft:obsidian
fill 415 258 598 417 258 598 minecraft:obsidian
fill 417 258 558 417 258 560 minecraft:obsidian
fill 417 258 562 417 258 564 minecraft:obsidian
fill 417 258 566 417 258 568 minecraft:obsidian
fill 417 258 570 417 258 572 minecraft:obsidian
fill 417 258 574 417 258 576 minecraft:obsidian
fill 417 258 578 417 258 580 minecraft:obsidian
fill 417 258 582 417 258 584 minecraft:obsidian
fill 417 258 586 417 258 588 minecraft:obsidian
fill 417 258 590 417 258 592 minecraft:obsidian
fill 417 258 594 417 258 596 minecraft:obsidian
setblock 418 258 557 minecraft:purple_concrete
fill 418 258 558 418 263 559 minecraft:black_concrete
fill 418 258 560 418 259 561 minecraft:purple_concrete
fill 418 258 566 418 263 567 minecraft:black_concrete
fill 418 258 568 418 258 569 minecraft:purple_concrete
fill 418 258 570 418 263 570 minecraft:black_concrete
fill 418 258 578 418 263 579 minecraft:black_concrete
fill 418 258 580 418 259 581 minecraft:purple_concrete
fill 418 258 587 418 263 587 minecraft:black_concrete
setblock 418 258 589 minecraft:purple_concrete
fill 418 258 590 418 263 591 minecraft:black_concrete
fill 418 258 592 418 259 592 minecraft:purple_concrete
fill 418 258 598 418 263 598 minecraft:black_concrete
setblock 376 259 567 minecraft:purple_concrete
fill 376 259 571 376 261 572 minecraft:black_concrete
fill 376 259 587 376 259 588 minecraft:purple_concrete
setblock 376 259 591 minecraft:purple_concrete
fill 376 259 592 376 262 592 minecraft:black_concrete
fill 377 259 557 377 262 557 minecraft:black_concrete
setblock 378 259 557 minecraft:purple_concrete
fill 380 259 599 380 262 599 minecraft:black_concrete
setblock 381 259 557 minecraft:purple_concrete
fill 384 259 599 384 261 599 minecraft:black_concrete
setblock 385 259 599 minecraft:purple_concrete
setblock 396 259 599 minecraft:purple_concrete
fill 397 259 557 398 262 557 minecraft:black_concrete
fill 400 259 592 400 259 593 minecraft:purple_concrete
fill 400 259 599 401 262 599 minecraft:black_concrete
setblock 402 259 557 minecraft:purple_concrete
fill 404 259 589 406 259 589 minecraft:black_concrete
fill 407 259 590 407 259 592 minecraft:black_concrete
setblock 413 259 557 minecraft:purple_concrete
setblock 417 259 599 minecraft:purple_concrete
fill 418 259 557 418 262 557 minecraft:black_concrete
fill 418 259 568 418 262 568 minecraft:black_concrete
setblock 418 259 569 minecraft:purple_concrete
fill 418 259 572 418 259 573 minecraft:purple_concrete
fill 418 259 589 418 262 589 minecraft:black_concrete
setblock 418 259 593 minecraft:purple_concrete
fill 376 260 557 376 260 558 minecraft:purple_concrete
fill 376 260 559 376 265 560 minecraft:black_concrete
fill 376 260 565 376 261 566 minecraft:purple_concrete
fill 376 260 567 376 265 568 minecraft:black_concrete
setblock 376 260 569 minecraft:purple_concrete
fill 376 260 577 376 261 578 minecraft:purple_concrete
fill 376 260 579 376 265 580 minecraft:black_concrete
fill 376 260 586 376 261 586 minecraft:purple_concrete
fill 376 260 587 376 261 588 minecraft:black_concrete
fill 376 260 589 376 260 590 minecraft:purple_concrete
fill 376 260 591 376 265 591 minecraft:black_concrete
fill 376 260 597 376 261 598 minecraft:purple_concrete
fill 376 260 599 377 265 599 minecraft:black_concrete
fill 378 260 557 378 265 557 minecraft:black_concrete
fill 379 260 557 380 260 557 minecraft:purple_concrete
fill 381 260 557 381 265 557 minecraft:black_concrete
fill 383 260 557 383 261 557 minecraft:purple_concrete
fill 385 260 599 385 265 599 minecraft:black_concrete
fill 386 260 575 386 261 576 minecraft:obsidian
fill 386 260 599 387 260 599 minecraft:purple_concrete
fill 388 260 599 389 265 599 minecraft:black_concrete
fill 389 260 557 390 265 557 minecraft:black_concrete
fill 391 260 557 392 261 557 minecraft:purple_concrete
fill 394 260 599 395 261 599 minecraft:purple_concrete
fill 396 260 599 397 265 599 minecraft:black_concrete
setblock 398 260 599 minecraft:purple_concrete
setblock 400 260 557 minecraft:purple_concrete
fill 401 260 557 402 265 557 minecraft:black_concrete
fill 403 260 557 404 261 557 minecraft:purple_concrete
fill 404 260 589 405 260 589 minecraft:black_concrete
fill 405 260 590 408 264 590 minecraft:purple_concrete
fill 406 260 589 408 265 589 minecraft:purple_concrete
fill 406 260 591 408 264 591 minecraft:purple_concrete
fill 406 260 592 407 260 593 minecraft:black_concrete
fill 406 260 599 407 261 599 minecraft:purple_concrete
fill 408 260 599 409 265 599 minecraft:black_concrete
fill 409 260 557 410 265 557 minecraft:black_concrete
fill 411 260 557 412 260 557 minecraft:purple_concrete
fill 413 260 557 413 265 557 minecraft:black_concrete
fill 415 260 599 415 261 599 minecraft:purple_concrete
fill 417 260 599 417 265 599 minecraft:black_concrete
fill 418 260 560 418 265 561 minecraft:black_concrete
fill 418 260 562 418 261 563 minecraft:purple_concrete
fill 418 260 569 418 265 569 minecraft:black_concrete
setblock 418 260 571 minecraft:purple_concrete
fill 418 260 572 418 265 573 minecraft:black_concrete
fill 418 260 574 418 261 574 minecraft:purple_concrete
fill 418 260 580 418 265 581 minecraft:black_concrete
fill 418 260 582 418 260 583 minecraft:purple_concrete
fill 418 260 592 418 265 593 minecraft:black_concrete
fill 418 260 594 418 261 595 minecraft:purple_concrete
setblock 418 260 599 minecraft:purple_concrete
setblock 376 261 557 minecraft:purple_concrete
fill 376 261 558 376 264 558 minecraft:black_concrete
fill 376 261 569 376 263 569 minecraft:black_concrete
setblock 376 261 574 minecraft:purple_concrete
setblock 376 261 585 minecraft:purple_concrete
fill 376 261 589 376 263 590 minecraft:black_concrete
fill 379 261 557 380 264 557 minecraft:black_concrete
setblock 379 261 560 minecraft:light[level=12]
setblock 379 261 568 minecraft:light[level=12]
setblock 379 261 576 minecraft:light[level=12]
setblock 379 261 584 minecraft:light[level=12]
setblock 379 261 592 minecraft:light[level=12]
fill 382 261 599 383 261 599 minecraft:purple_concrete
setblock 384 261 557 minecraft:purple_concrete
fill 385 261 593 387 262 593 minecraft:amethyst_block
fill 386 261 592 386 262 592 minecraft:amethyst_block
fill 386 261 594 386 262 594 minecraft:amethyst_block
setblock 386 261 599 minecraft:purple_concrete
setblock 387 261 560 minecraft:light[level=12]
setblock 387 261 568 minecraft:light[level=12]
setblock 387 261 576 minecraft:light[level=12]
schedule function dropper:buildpart/140_5 1t
