setblock 324 292 252 minecraft:brown_terracotta
setblock 324 292 255 minecraft:brown_terracotta
setblock 324 292 264 minecraft:light_gray_terracotta
fill 324 292 265 324 292 266 minecraft:brown_terracotta
setblock 324 292 267 minecraft:orange_terracotta
setblock 282 293 228 minecraft:brown_terracotta
fill 282 293 229 282 300 229 minecraft:gray_concrete
setblock 282 293 230 minecraft:brown_terracotta
fill 282 293 231 282 293 232 minecraft:gray_concrete
setblock 282 293 233 minecraft:orange_terracotta
fill 282 293 234 282 296 235 minecraft:gray_concrete
fill 282 293 237 282 298 237 minecraft:gray_concrete
setblock 282 293 238 minecraft:brown_terracotta
setblock 282 293 239 minecraft:orange_terracotta
fill 282 293 240 282 294 251 minecraft:gray_concrete
setblock 282 293 252 minecraft:brown_terracotta
fill 282 293 253 282 296 253 minecraft:gray_concrete
setblock 282 293 254 minecraft:gray_terracotta
fill 282 293 255 282 294 259 minecraft:gray_concrete
fill 282 293 261 282 293 267 minecraft:gray_concrete
fill 282 293 269 282 300 270 minecraft:gray_concrete
setblock 283 293 228 minecraft:orange_terracotta
fill 283 293 270 293 293 270 minecraft:gray_concrete
fill 285 293 228 288 293 228 minecraft:gray_concrete
fill 287 293 231 287 294 232 minecraft:white_wool
fill 288 293 234 290 293 234 minecraft:white_wool
fill 291 293 228 291 294 228 minecraft:white_wool
fill 292 293 228 305 293 228 minecraft:gray_concrete
fill 292 293 229 292 295 229 minecraft:white_wool
fill 292 293 233 292 295 233 minecraft:white_wool
fill 292 293 266 292 293 268 minecraft:gray_wool
setblock 294 293 270 minecraft:light_gray_terracotta
fill 295 293 270 297 293 270 minecraft:gray_concrete
fill 299 293 270 302 293 270 minecraft:gray_concrete
fill 304 293 270 308 297 270 minecraft:gray_concrete
setblock 306 293 228 minecraft:brown_terracotta
fill 307 293 228 310 293 228 minecraft:gray_concrete
fill 307 293 239 307 296 239 minecraft:blackstone
fill 309 293 241 310 298 241 minecraft:blackstone
setblock 309 293 270 minecraft:orange_terracotta
fill 310 293 236 311 296 236 minecraft:blackstone
fill 310 293 270 314 294 270 minecraft:gray_concrete
fill 312 293 228 313 297 228 minecraft:gray_concrete
fill 312 293 237 312 298 240 minecraft:blackstone
setblock 314 293 228 minecraft:brown_terracotta
fill 315 293 228 315 297 228 minecraft:gray_concrete
setblock 315 293 270 minecraft:brown_terracotta
setblock 316 293 228 minecraft:orange_terracotta
fill 316 293 270 320 296 270 minecraft:gray_concrete
fill 317 293 228 317 296 228 minecraft:gray_concrete
setblock 318 293 228 minecraft:gray_terracotta
fill 318 293 254 318 295 255 minecraft:white_wool
fill 319 293 228 324 293 228 minecraft:gray_concrete
fill 319 293 253 319 297 253 minecraft:white_wool
fill 319 293 256 321 296 256 minecraft:white_wool
fill 320 293 252 320 296 252 minecraft:white_wool
fill 321 293 251 322 295 251 minecraft:white_wool
setblock 321 293 270 minecraft:brown_terracotta
fill 322 293 270 323 297 270 minecraft:gray_concrete
fill 323 293 252 323 296 254 minecraft:white_wool
fill 323 293 256 323 295 256 minecraft:white_wool
fill 324 293 229 324 294 231 minecraft:gray_concrete
setblock 324 293 232 minecraft:brown_terracotta
setblock 324 293 233 minecraft:gray_concrete
setblock 324 293 234 minecraft:gray_terracotta
fill 324 293 235 324 293 236 minecraft:gray_concrete
setblock 324 293 238 minecraft:light_gray_terracotta
fill 324 293 239 324 294 241 minecraft:gray_concrete
setblock 324 293 242 minecraft:brown_terracotta
fill 324 293 243 324 293 252 minecraft:gray_concrete
fill 324 293 255 324 293 259 minecraft:gray_concrete
setblock 324 293 260 minecraft:brown_terracotta
fill 324 293 261 324 293 262 minecraft:gray_concrete
setblock 324 293 263 minecraft:brown_terracotta
fill 324 293 264 324 293 269 minecraft:gray_concrete
fill 282 294 228 284 296 228 minecraft:gray_concrete
fill 282 294 230 282 297 230 minecraft:gray_concrete
setblock 282 294 231 minecraft:gray_terracotta
fill 282 294 232 282 300 232 minecraft:gray_concrete
setblock 282 294 233 minecraft:gray_terracotta
fill 282 294 236 282 300 236 minecraft:gray_concrete
fill 282 294 238 282 294 239 minecraft:gray_concrete
setblock 282 294 252 minecraft:gray_terracotta
setblock 282 294 254 minecraft:gray_concrete
fill 282 294 260 282 296 260 minecraft:gray_concrete
setblock 282 294 261 minecraft:light_gray_terracotta
setblock 282 294 262 minecraft:brown_terracotta
fill 282 294 263 282 296 263 minecraft:gray_concrete
setblock 282 294 264 minecraft:brown_terracotta
fill 282 294 265 282 294 268 minecraft:gray_concrete
fill 283 294 270 287 297 270 minecraft:gray_concrete
setblock 285 294 228 minecraft:light_gray_terracotta
fill 286 294 228 288 294 228 minecraft:gray_concrete
fill 288 294 266 289 294 269 minecraft:gray_wool
setblock 288 294 270 minecraft:brown_terracotta
fill 289 294 234 291 294 234 minecraft:white_wool
setblock 289 294 265 minecraft:gray_wool
fill 289 294 270 296 294 270 minecraft:gray_concrete
fill 290 294 266 290 294 268 minecraft:gray_wool
setblock 291 294 267 minecraft:gray_wool
fill 292 294 228 296 294 228 minecraft:gray_concrete
setblock 297 294 228 minecraft:brown_terracotta
setblock 297 294 270 minecraft:brown_terracotta
fill 298 294 228 299 297 228 minecraft:gray_concrete
fill 299 294 270 300 297 270 minecraft:gray_concrete
setblock 300 294 228 minecraft:brown_terracotta
fill 301 294 228 307 296 228 minecraft:gray_concrete
fill 301 294 270 301 295 270 minecraft:brown_terracotta
fill 302 294 270 303 294 270 minecraft:gray_concrete
fill 307 294 240 307 296 240 minecraft:blackstone
setblock 308 294 228 minecraft:brown_terracotta
fill 308 294 241 308 298 241 minecraft:blackstone
fill 309 294 228 311 297 228 minecraft:gray_concrete
fill 309 294 270 309 300 270 minecraft:gray_concrete
fill 311 294 241 311 298 241 minecraft:blackstone
fill 314 294 228 314 301 228 minecraft:gray_concrete
fill 315 294 270 315 300 270 minecraft:gray_concrete
fill 316 294 228 316 299 228 minecraft:gray_concrete
fill 318 294 228 323 294 228 minecraft:gray_concrete
fill 319 294 252 319 296 252 minecraft:white_wool
fill 320 294 257 321 295 257 minecraft:white_wool
fill 321 294 270 321 300 270 minecraft:gray_concrete
setblock 324 294 228 minecraft:brown_terracotta
setblock 324 294 232 minecraft:gray_concrete
setblock 324 294 233 minecraft:gray_terracotta
fill 324 294 234 324 300 234 minecraft:gray_concrete
setblock 324 294 235 minecraft:gray_terracotta
setblock 324 294 236 minecraft:brown_terracotta
setblock 324 294 237 minecraft:gray_concrete
setblock 324 294 238 minecraft:brown_terracotta
fill 324 294 242 324 297 244 minecraft:gray_concrete
fill 324 294 245 324 295 245 minecraft:brown_terracotta
fill 324 294 246 324 301 246 minecraft:gray_concrete
setblock 324 294 247 minecraft:brown_terracotta
fill 324 294 248 324 296 252 minecraft:gray_concrete
fill 324 294 253 324 295 255 minecraft:white_wool
fill 324 294 256 324 295 260 minecraft:gray_concrete
setblock 324 294 261 minecraft:gray_terracotta
setblock 324 294 262 minecraft:brown_terracotta
fill 324 294 263 324 295 268 minecraft:gray_concrete
setblock 324 294 269 minecraft:brown_terracotta
setblock 282 295 231 minecraft:brown_terracotta
fill 282 295 233 282 300 233 minecraft:gray_concrete
setblock 282 295 238 minecraft:brown_terracotta
fill 282 295 239 282 300 241 minecraft:gray_concrete
setblock 282 295 242 minecraft:brown_terracotta
fill 282 295 243 282 295 252 minecraft:gray_concrete
setblock 282 295 254 minecraft:brown_terracotta
fill 282 295 255 282 300 255 minecraft:gray_concrete
setblock 282 295 256 minecraft:light_gray_terracotta
fill 282 295 257 282 296 259 minecraft:gray_concrete
fill 282 295 261 282 300 262 minecraft:gray_concrete
setblock 282 295 264 minecraft:light_gray_terracotta
setblock 282 295 265 minecraft:brown_terracotta
fill 282 295 266 282 298 268 minecraft:gray_concrete
setblock 285 295 228 minecraft:brown_terracotta
fill 286 295 228 287 298 228 minecraft:gray_concrete
setblock 288 295 228 minecraft:brown_terracotta
fill 288 295 230 288 295 232 minecraft:white_wool
fill 288 295 270 291 296 270 minecraft:gray_concrete
fill 289 295 228 289 297 228 minecraft:gray_concrete
setblock 289 295 229 minecraft:white_wool
setblock 290 295 228 minecraft:orange_terracotta
fill 290 295 234 291 295 234 minecraft:white_wool
fill 291 295 228 294 296 228 minecraft:gray_concrete
setblock 292 295 270 minecraft:orange_terracotta
fill 293 295 270 293 300 270 minecraft:gray_concrete
setblock 294 295 270 minecraft:brown_terracotta
setblock 295 295 228 minecraft:gray_terracotta
fill 295 295 270 298 295 270 minecraft:gray_concrete
fill 296 295 228 297 296 228 minecraft:gray_concrete
fill 300 295 228 300 297 228 minecraft:gray_concrete
fill 302 295 270 302 296 270 minecraft:gray_concrete
setblock 303 295 270 minecraft:brown_terracotta
fill 306 295 238 306 296 240 minecraft:blackstone
fill 307 295 241 307 298 241 minecraft:blackstone
fill 308 295 228 308 300 228 minecraft:gray_concrete
fill 308 295 242 311 298 242 minecraft:blackstone
fill 310 295 235 311 296 235 minecraft:blackstone
fill 310 295 270 310 296 270 minecraft:gray_concrete
setblock 311 295 270 minecraft:brown_terracotta
fill 312 295 236 312 296 236 minecraft:blackstone
fill 312 295 241 312 298 241 minecraft:blackstone
fill 312 295 270 314 296 270 minecraft:gray_concrete
fill 313 295 237 313 298 240 minecraft:blackstone
fill 318 295 228 322 296 228 minecraft:gray_concrete
setblock 318 295 253 minecraft:white_wool
fill 318 295 256 318 296 258 minecraft:magma_block
fill 319 295 257 319 296 258 minecraft:magma_block
setblock 323 295 228 minecraft:brown_terracotta
fill 324 295 228 324 297 230 minecraft:gray_concrete
fill 324 295 231 324 295 232 minecraft:brown_terracotta
fill 324 295 233 324 300 233 minecraft:gray_concrete
fill 324 295 235 324 296 236 minecraft:gray_concrete
setblock 324 295 237 minecraft:brown_terracotta
fill 324 295 238 324 296 239 minecraft:gray_concrete
setblock 324 295 240 minecraft:brown_terracotta
fill 324 295 241 324 300 241 minecraft:gray_concrete
fill 324 295 247 324 300 247 minecraft:gray_concrete
fill 324 295 261 324 300 262 minecraft:gray_concrete
fill 324 295 269 324 297 270 minecraft:gray_concrete
fill 282 296 231 282 298 231 minecraft:gray_concrete
fill 282 296 238 282 300 238 minecraft:gray_concrete
fill 282 296 242 282 298 245 minecraft:gray_concrete
setblock 282 296 246 minecraft:gray_terracotta
fill 282 296 247 282 296 252 minecraft:gray_concrete
fill 282 296 254 282 300 254 minecraft:gray_concrete
fill 282 296 256 282 301 256 minecraft:gray_concrete
fill 282 296 264 282 296 265 minecraft:gray_concrete
fill 284 296 233 286 300 235 minecraft:light_gray_wool
fill 285 296 228 285 297 228 minecraft:gray_concrete
setblock 288 296 228 minecraft:gray_concrete
fill 288 296 230 291 296 231 minecraft:white_wool
fill 290 296 228 290 300 228 minecraft:gray_concrete
fill 290 296 232 291 296 233 minecraft:white_wool
fill 292 296 270 292 300 270 minecraft:gray_concrete
fill 294 296 270 296 297 270 minecraft:gray_concrete
fill 295 296 228 295 299 228 minecraft:gray_concrete
setblock 297 296 270 minecraft:light_gray_terracotta
fill 298 296 270 298 298 270 minecraft:gray_concrete
fill 301 296 270 301 301 270 minecraft:gray_concrete
fill 303 296 270 303 299 270 minecraft:gray_concrete
fill 306 296 241 306 298 241 minecraft:blackstone
fill 307 296 242 307 298 242 minecraft:blackstone
fill 311 296 270 311 300 270 minecraft:gray_concrete
setblock 312 296 235 minecraft:blackstone
fill 312 296 242 312 298 242 minecraft:blackstone
fill 313 296 236 313 298 236 minecraft:blackstone
fill 313 296 241 313 298 241 minecraft:blackstone
setblock 320 296 257 minecraft:white_wool
fill 323 296 228 323 300 228 minecraft:gray_concrete
fill 324 296 231 324 297 232 minecraft:gray_concrete
fill 324 296 237 324 300 237 minecraft:gray_concrete
fill 324 296 240 324 298 240 minecraft:gray_concrete
fill 324 296 245 324 300 245 minecraft:gray_concrete
fill 324 296 253 324 296 254 minecraft:white_wool
fill 324 296 255 324 296 256 minecraft:gray_concrete
setblock 324 296 257 minecraft:light_gray_terracotta
setblock 324 296 258 minecraft:orange_terracotta
fill 324 296 259 324 300 260 minecraft:gray_concrete
fill 324 296 263 324 296 266 minecraft:gray_concrete
setblock 324 296 267 minecraft:orange_terracotta
fill 324 296 268 324 300 268 minecraft:gray_concrete
fill 282 297 228 283 298 228 minecraft:gray_concrete
setblock 282 297 234 minecraft:light_gray_concrete
fill 282 297 235 283 299 235 minecraft:light_gray_wool
fill 282 297 246 282 299 247 minecraft:gray_concrete
setblock 282 297 248 minecraft:light_gray_concrete
fill 282 297 249 282 297 252 minecraft:gray_concrete
setblock 282 297 253 minecraft:orange_terracotta
fill 282 297 257 282 300 258 minecraft:gray_concrete
fill 282 297 259 282 297 260 minecraft:light_gray_concrete
setblock 282 297 263 minecraft:light_gray_terracotta
setblock 282 297 264 minecraft:light_gray_concrete
fill 282 297 265 282 298 265 minecraft:gray_concrete
fill 283 297 233 283 300 234 minecraft:light_gray_wool
fill 283 297 236 285 299 236 minecraft:light_gray_wool
setblock 284 297 228 minecraft:light_gray_concrete
fill 284 297 232 286 300 232 minecraft:light_gray_wool
fill 285 297 231 285 298 231 minecraft:light[level=12]
setblock 285 297 238 minecraft:light[level=12]
setblock 285 297 245 minecraft:light[level=12]
setblock 285 297 252 minecraft:light[level=12]
setblock 285 297 259 minecraft:light[level=12]
setblock 285 297 266 minecraft:light[level=12]
fill 287 297 233 287 300 235 minecraft:light_gray_wool
setblock 288 297 228 minecraft:light_gray_concrete
fill 288 297 234 288 299 234 minecraft:light_gray_wool
fill 288 297 270 288 300 270 minecraft:gray_concrete
setblock 289 297 270 minecraft:light_gray_concrete
fill 290 297 270 291 300 270 minecraft:gray_concrete
fill 291 297 228 293 300 228 minecraft:gray_concrete
setblock 292 297 231 minecraft:light[level=12]
setblock 292 297 238 minecraft:light[level=12]
setblock 292 297 245 minecraft:light[level=12]
setblock 292 297 252 minecraft:light[level=12]
setblock 292 297 259 minecraft:light[level=12]
setblock 292 297 266 minecraft:light[level=12]
fill 293 297 259 293 297 262 minecraft:orange_concrete
setblock 294 297 228 minecraft:light_gray_concrete
fill 294 297 231 295 297 234 minecraft:orange_concrete
fill 294 297 258 294 297 259 minecraft:orange_concrete
fill 294 297 262 296 297 263 minecraft:orange_concrete
fill 295 297 229 296 297 230 minecraft:orange_concrete
fill 295 297 235 301 297 235 minecraft:orange_concrete
fill 295 297 258 297 297 258 minecraft:orange_concrete
setblock 296 297 228 minecraft:light_gray_concrete
fill 296 297 234 296 299 234 minecraft:orange_concrete
fill 297 297 228 297 300 228 minecraft:gray_concrete
fill 297 297 229 300 297 229 minecraft:orange_concrete
fill 297 297 236 299 297 236 minecraft:orange_concrete
fill 297 297 259 297 298 262 minecraft:orange_concrete
fill 297 297 270 297 300 270 minecraft:gray_concrete
fill 298 297 259 298 297 261 minecraft:orange_concrete
fill 299 297 230 301 297 230 minecraft:orange_concrete
setblock 299 297 238 minecraft:light[level=12]
setblock 299 297 245 minecraft:light[level=12]
setblock 299 297 252 minecraft:light[level=12]
setblock 299 297 259 minecraft:light[level=12]
setblock 299 297 266 minecraft:light[level=12]
fill 300 297 231 302 297 231 minecraft:orange_concrete
fill 300 297 233 301 297 234 minecraft:orange_concrete
fill 301 297 228 302 297 228 minecraft:gray_concrete
fill 301 297 232 302 297 232 minecraft:orange_concrete
setblock 302 297 233 minecraft:orange_concrete
setblock 302 297 270 minecraft:light_gray_concrete
setblock 303 297 228 minecraft:light_gray_concrete
fill 303 297 234 304 297 237 minecraft:orange_concrete
fill 304 297 228 305 300 228 minecraft:gray_concrete
fill 304 297 233 311 297 233 minecraft:orange_concrete
fill 304 297 238 306 297 239 minecraft:orange_concrete
fill 305 297 232 310 297 232 minecraft:orange_concrete
fill 305 297 234 305 299 234 minecraft:orange_concrete
fill 305 297 237 305 299 237 minecraft:orange_concrete
fill 305 297 240 309 297 240 minecraft:orange_concrete
setblock 306 297 228 minecraft:light_gray_concrete
setblock 306 297 231 minecraft:light[level=12]
setblock 306 297 245 minecraft:light[level=12]
setblock 306 297 252 minecraft:light[level=12]
setblock 306 297 259 minecraft:light[level=12]
setblock 306 297 266 minecraft:light[level=12]
fill 307 297 228 307 300 228 minecraft:gray_concrete
fill 307 297 239 310 297 239 minecraft:orange_concrete
fill 308 297 243 311 298 243 minecraft:blackstone
fill 309 297 238 311 297 238 minecraft:orange_concrete
fill 309 297 259 310 297 260 minecraft:orange_concrete
fill 310 297 234 311 297 237 minecraft:orange_concrete
fill 310 297 240 310 298 240 minecraft:blackstone
fill 310 297 258 313 298 258 minecraft:orange_concrete
fill 310 297 261 311 298 261 minecraft:orange_concrete
setblock 310 297 270 minecraft:light_gray_concrete
fill 311 297 239 311 298 239 minecraft:blackstone
fill 311 297 257 312 297 257 minecraft:orange_concrete
fill 311 297 262 313 297 262 minecraft:orange_concrete
fill 312 297 235 312 297 236 minecraft:orange_concrete
fill 312 297 270 312 300 270 minecraft:gray_concrete
setblock 313 297 231 minecraft:light[level=12]
setblock 313 297 245 minecraft:light[level=12]
setblock 313 297 252 minecraft:light[level=12]
fill 313 297 259 314 297 259 minecraft:orange_concrete
fill 313 297 261 314 297 261 minecraft:orange_concrete
setblock 313 297 266 minecraft:light[level=12]
setblock 313 297 270 minecraft:orange_terracotta
fill 314 297 237 314 298 240 minecraft:blackstone
setblock 314 297 260 minecraft:orange_concrete
setblock 314 297 270 minecraft:gray_concrete
fill 316 297 270 318 300 270 minecraft:gray_concrete
setblock 317 297 228 minecraft:gray_terracotta
fill 318 297 228 318 300 228 minecraft:gray_concrete
setblock 319 297 228 minecraft:gray_terracotta
fill 319 297 270 319 298 270 minecraft:light_gray_concrete
fill 320 297 228 321 297 228 minecraft:gray_concrete
setblock 320 297 231 minecraft:light[level=12]
setblock 320 297 238 minecraft:light[level=12]
setblock 320 297 245 minecraft:light[level=12]
setblock 320 297 252 minecraft:light[level=12]
fill 320 297 256 321 297 256 minecraft:white_wool
setblock 320 297 259 minecraft:light[level=12]
setblock 320 297 266 minecraft:light[level=12]
fill 320 297 270 320 299 270 minecraft:gray_concrete
setblock 322 297 228 minecraft:gray_terracotta
fill 323 297 253 323 297 254 minecraft:white_wool
fill 324 297 235 324 300 235 minecraft:gray_concrete
setblock 324 297 236 minecraft:light_gray_concrete
setblock 324 297 238 minecraft:light_gray_concrete
setblock 324 297 239 minecraft:gray_concrete
fill 324 297 248 324 297 249 minecraft:gray_concrete
setblock 324 297 250 minecraft:light_gray_terracotta
fill 324 297 251 324 300 251 minecraft:gray_concrete
setblock 324 297 252 minecraft:light_gray_concrete
fill 324 297 253 324 297 254 minecraft:gray_concrete
setblock 324 297 255 minecraft:light_gray_concrete
fill 324 297 256 324 300 258 minecraft:gray_concrete
setblock 324 297 263 minecraft:light_gray_concrete
fill 324 297 264 324 298 267 minecraft:gray_concrete
setblock 282 298 230 minecraft:gray_terracotta
fill 282 298 234 282 299 234 minecraft:light_gray_wool
fill 282 298 248 282 298 251 minecraft:gray_concrete
setblock 282 298 252 minecraft:light_gray_concrete
fill 282 298 253 282 300 253 minecraft:gray_concrete
fill 282 298 259 282 300 260 minecraft:gray_concrete
setblock 282 298 263 minecraft:light_gray_concrete
fill 282 298 264 282 300 264 minecraft:gray_concrete
fill 283 298 232 283 300 232 minecraft:light_gray_wool
setblock 283 298 270 minecraft:gray_concrete
fill 284 298 228 284 301 228 minecraft:gray_concrete
setblock 284 298 270 minecraft:light_gray_concrete
setblock 285 298 228 minecraft:orange_terracotta
setblock 285 298 239 minecraft:light[level=12]
setblock 285 298 247 minecraft:light[level=12]
setblock 285 298 255 minecraft:light[level=12]
setblock 285 298 263 minecraft:light[level=12]
fill 285 298 270 287 300 270 minecraft:gray_concrete
fill 286 298 236 286 301 236 minecraft:light_gray_wool
fill 287 298 232 287 299 232 minecraft:light_gray_wool
fill 288 298 228 288 299 228 minecraft:gray_concrete
setblock 288 298 233 minecraft:light_gray_wool
setblock 289 298 228 minecraft:light_gray_concrete
fill 289 298 270 289 300 270 minecraft:gray_concrete
setblock 293 298 231 minecraft:light[level=12]
setblock 293 298 239 minecraft:light[level=12]
setblock 293 298 247 minecraft:light[level=12]
setblock 293 298 255 minecraft:light[level=12]
fill 293 298 260 293 298 261 minecraft:orange_concrete
setblock 293 298 263 minecraft:light[level=12]
setblock 294 298 228 minecraft:gray_terracotta
fill 294 298 259 294 299 259 minecraft:orange_concrete
fill 294 298 262 296 298 262 minecraft:orange_concrete
fill 294 298 270 294 301 270 minecraft:gray_concrete
fill 295 298 230 295 298 234 minecraft:orange_concrete
fill 295 298 258 296 298 258 minecraft:orange_concrete
setblock 295 298 270 minecraft:light_gray_concrete
fill 296 298 228 296 300 228 minecraft:gray_concrete
fill 296 298 229 296 298 230 minecraft:orange_concrete
fill 296 298 235 300 298 235 minecraft:orange_concrete
fill 296 298 270 296 300 270 minecraft:gray_concrete
fill 297 298 229 299 298 229 minecraft:orange_concrete
fill 298 298 228 298 300 228 minecraft:gray_concrete
fill 299 298 228 301 298 228 minecraft:light_gray_concrete
fill 299 298 230 300 299 230 minecraft:orange_concrete
fill 299 298 270 299 302 270 minecraft:gray_concrete
fill 300 298 231 301 298 231 minecraft:orange_concrete
fill 300 298 233 300 299 234 minecraft:orange_concrete
setblock 300 298 270 minecraft:light_gray_concrete
fill 301 298 232 301 298 233 minecraft:orange_concrete
setblock 301 298 239 minecraft:light[level=12]
setblock 301 298 247 minecraft:light[level=12]
setblock 301 298 255 minecraft:light[level=12]
setblock 301 298 263 minecraft:light[level=12]
fill 302 298 228 303 300 228 minecraft:gray_concrete
fill 302 298 270 302 300 270 minecraft:gray_concrete
fill 304 298 234 304 298 238 minecraft:orange_concrete
fill 304 298 270 307 298 270 minecraft:gray_concrete
fill 305 298 233 310 298 233 minecraft:orange_concrete
fill 305 298 238 306 298 239 minecraft:orange_concrete
fill 305 298 240 305 298 241 minecraft:blackstone
fill 306 298 228 306 301 228 minecraft:gray_concrete
fill 306 298 240 309 298 240 minecraft:blackstone
setblock 306 298 242 minecraft:blackstone
fill 307 298 232 308 298 232 minecraft:orange_concrete
fill 307 298 239 309 298 239 minecraft:orange_concrete
setblock 307 298 243 minecraft:blackstone
setblock 308 298 270 minecraft:light_gray_concrete
fill 309 298 228 310 298 228 minecraft:gray_concrete
setblock 309 298 231 minecraft:light[level=12]
fill 309 298 238 310 298 238 minecraft:orange_concrete
setblock 309 298 247 minecraft:light[level=12]
setblock 309 298 255 minecraft:light[level=12]
setblock 309 298 263 minecraft:light[level=12]
fill 310 298 234 310 299 237 minecraft:orange_concrete
setblock 310 298 239 minecraft:blackstone
fill 310 298 259 310 299 260 minecraft:orange_concrete
fill 310 298 270 310 300 270 minecraft:gray_concrete
setblock 311 298 228 minecraft:gray_terracotta
fill 311 298 234 312 298 234 minecraft:blackstone
fill 311 298 235 311 298 237 minecraft:orange_concrete
setblock 311 298 238 minecraft:blackstone
setblock 312 298 228 minecraft:gray_concrete
fill 312 298 235 312 298 236 minecraft:blackstone
setblock 312 298 243 minecraft:blackstone
setblock 313 298 228 minecraft:light_gray_concrete
setblock 313 298 235 minecraft:blackstone
setblock 313 298 242 minecraft:blackstone
fill 313 298 259 313 299 259 minecraft:orange_concrete
setblock 313 298 261 minecraft:orange_concrete
setblock 313 298 270 minecraft:gray_terracotta
setblock 314 298 236 minecraft:blackstone
setblock 314 298 241 minecraft:blackstone
setblock 314 298 270 minecraft:light_gray_concrete
setblock 315 298 228 minecraft:orange_terracotta
fill 317 298 228 317 300 228 minecraft:gray_concrete
setblock 317 298 231 minecraft:light[level=12]
setblock 317 298 239 minecraft:light[level=12]
setblock 317 298 247 minecraft:light[level=12]
setblock 317 298 255 minecraft:light[level=12]
setblock 317 298 263 minecraft:light[level=12]
setblock 319 298 228 minecraft:light_gray_concrete
fill 320 298 228 320 300 228 minecraft:gray_concrete
setblock 321 298 228 minecraft:light_gray_concrete
setblock 321 298 254 minecraft:white_wool
fill 322 298 228 322 300 228 minecraft:gray_concrete
setblock 322 298 270 minecraft:light_gray_concrete
fill 323 298 270 323 300 270 minecraft:gray_concrete
fill 324 298 228 324 298 229 minecraft:gray_concrete
setblock 324 298 230 minecraft:light_gray_terracotta
setblock 324 298 231 minecraft:light_gray_concrete
fill 324 298 232 324 300 232 minecraft:gray_concrete
setblock 324 298 236 minecraft:gray_concrete
fill 324 298 238 324 300 238 minecraft:gray_concrete
setblock 324 298 239 minecraft:light_gray_concrete
fill 324 298 242 324 300 243 minecraft:gray_concrete
setblock 324 298 244 minecraft:light_gray_concrete
setblock 324 298 248 minecraft:gray_concrete
setblock 324 298 249 minecraft:light_gray_concrete
fill 324 298 250 324 300 250 minecraft:gray_concrete
setblock 324 298 252 minecraft:gray_concrete
setblock 324 298 253 minecraft:light_gray_terracotta
setblock 324 298 254 minecraft:light_gray_concrete
fill 324 298 255 324 300 255 minecraft:gray_concrete
fill 324 298 263 324 300 263 minecraft:gray_concrete
fill 324 298 269 324 300 269 minecraft:gray_concrete
setblock 324 298 270 minecraft:light_gray_concrete
setblock 282 299 228 minecraft:light_gray_concrete
fill 282 299 230 282 300 230 minecraft:gray_concrete
setblock 282 299 231 minecraft:gray_terracotta
setblock 282 299 237 minecraft:light_gray_concrete
fill 282 299 242 282 299 243 minecraft:gray_concrete
setblock 282 299 244 minecraft:orange_terracotta
fill 282 299 245 282 300 245 minecraft:gray_concrete
fill 282 299 248 282 300 248 minecraft:gray_concrete
setblock 282 299 249 minecraft:light_gray_concrete
fill 282 299 250 282 300 252 minecraft:gray_concrete
fill 282 299 263 282 301 263 minecraft:gray_concrete
setblock 282 299 265 minecraft:light_gray_concrete
setblock 282 299 266 minecraft:gray_concrete
setblock 282 299 267 minecraft:light_gray_terracotta
setblock 282 299 268 minecraft:gray_concrete
fill 283 299 228 283 300 228 minecraft:gray_concrete
setblock 283 299 270 minecraft:light_gray_concrete
fill 284 299 270 284 300 270 minecraft:gray_concrete
fill 285 299 228 286 300 228 minecraft:gray_concrete
setblock 287 299 228 minecraft:light_gray_terracotta
fill 287 299 236 287 300 236 minecraft:light_gray_wool
fill 289 299 228 289 300 228 minecraft:gray_concrete
fill 294 299 228 294 300 228 minecraft:gray_concrete
setblock 295 299 232 minecraft:orange_concrete
fill 295 299 262 296 299 262 minecraft:orange_concrete
fill 295 299 270 295 300 270 minecraft:gray_concrete
setblock 296 299 230 minecraft:orange_concrete
fill 297 299 259 297 299 261 minecraft:orange_concrete
setblock 298 299 235 minecraft:orange_concrete
setblock 298 299 270 minecraft:light_gray_concrete
fill 299 299 228 301 300 228 minecraft:gray_concrete
setblock 300 299 231 minecraft:orange_concrete
fill 300 299 270 300 301 270 minecraft:gray_concrete
fill 304 299 270 306 300 270 minecraft:gray_concrete
fill 305 299 238 306 299 238 minecraft:orange_concrete
fill 306 299 233 308 299 233 minecraft:orange_concrete
fill 307 299 239 308 299 239 minecraft:orange_concrete
setblock 307 299 270 minecraft:light_gray_terracotta
fill 308 299 270 308 300 270 minecraft:gray_concrete
setblock 309 299 228 minecraft:light_gray_concrete
setblock 309 299 238 minecraft:orange_concrete
fill 309 299 239 310 300 239 minecraft:magma_block
fill 310 299 228 311 300 228 minecraft:gray_concrete
fill 310 299 238 310 300 238 minecraft:magma_block
fill 311 299 258 312 299 258 minecraft:orange_concrete
setblock 311 299 261 minecraft:orange_concrete
setblock 312 299 228 minecraft:light_gray_concrete
fill 313 299 228 313 300 228 minecraft:gray_concrete
fill 313 299 270 314 300 270 minecraft:gray_concrete
fill 315 299 228 315 300 228 minecraft:gray_concrete
setblock 319 299 228 minecraft:light_gray_terracotta
fill 319 299 270 319 300 270 minecraft:gray_concrete
fill 321 299 228 321 300 228 minecraft:gray_concrete
fill 322 299 270 322 300 270 minecraft:gray_concrete
setblock 324 299 228 minecraft:light_gray_concrete
fill 324 299 229 324 300 231 minecraft:gray_concrete
setblock 324 299 236 minecraft:light_gray_concrete
fill 324 299 239 324 300 239 minecraft:gray_concrete
setblock 324 299 240 minecraft:light_gray_concrete
fill 324 299 244 324 300 244 minecraft:gray_concrete
setblock 324 299 248 minecraft:light_gray_concrete
setblock 324 299 249 minecraft:light_gray_terracotta
setblock 324 299 252 minecraft:light_gray_concrete
fill 324 299 253 324 300 254 minecraft:gray_concrete
fill 324 299 264 324 300 266 minecraft:gray_concrete
setblock 324 299 267 minecraft:light_gray_concrete
fill 324 299 270 324 300 270 minecraft:gray_concrete
setblock 282 300 228 minecraft:gray_concrete
setblock 282 300 231 minecraft:gray_concrete
fill 282 300 234 282 300 235 minecraft:gray_concrete
setblock 282 300 237 minecraft:gray_concrete
setblock 282 300 242 minecraft:gray_concrete
setblock 282 300 243 minecraft:gray_terracotta
setblock 282 300 244 minecraft:gray_concrete
setblock 282 300 246 minecraft:orange_terracotta
setblock 282 300 247 minecraft:gray_concrete
setblock 282 300 249 minecraft:gray_concrete
setblock 282 300 265 minecraft:gray_concrete
setblock 282 300 266 minecraft:light_gray_terracotta
setblock 282 300 267 minecraft:gray_concrete
setblock 282 300 268 minecraft:gray_terracotta
setblock 283 300 235 minecraft:light_gray_wool
setblock 283 300 270 minecraft:gray_concrete
fill 284 300 236 285 300 236 minecraft:light_gray_wool
setblock 287 300 228 minecraft:gray_concrete
setblock 288 300 228 minecraft:gray_terracotta
setblock 295 300 228 minecraft:gray_terracotta
setblock 298 300 270 minecraft:gray_concrete
setblock 303 300 270 minecraft:light_gray_terracotta
fill 307 300 270 307 301 270 minecraft:gray_concrete
setblock 309 300 228 minecraft:gray_concrete
setblock 309 300 238 minecraft:magma_block
setblock 312 300 228 minecraft:gray_concrete
setblock 316 300 228 minecraft:light_gray_terracotta
setblock 319 300 228 minecraft:gray_concrete
setblock 320 300 270 minecraft:gray_terracotta
setblock 324 300 228 minecraft:gray_concrete
setblock 324 300 236 minecraft:gray_concrete
setblock 324 300 240 minecraft:orange_terracotta
fill 324 300 248 324 301 249 minecraft:gray_concrete
fill 324 300 252 324 301 252 minecraft:gray_concrete
setblock 324 300 267 minecraft:light_gray_terracotta
fill 282 301 228 282 301 237 minecraft:light_gray_concrete
setblock 282 301 238 minecraft:light_gray_terracotta
setblock 282 301 239 minecraft:gray_concrete
fill 282 301 240 282 301 255 minecraft:light_gray_concrete
fill 282 301 257 282 308 258 minecraft:light_gray_concrete
setblock 282 301 259 minecraft:gray_concrete
fill 282 301 260 282 306 262 minecraft:light_gray_concrete
fill 282 301 264 282 301 267 minecraft:light_gray_concrete
setblock 282 301 268 minecraft:gray_concrete
fill 282 301 269 282 302 270 minecraft:light_gray_concrete
fill 283 301 228 283 308 228 minecraft:light_gray_concrete
fill 283 301 270 284 302 270 minecraft:light_gray_concrete
fill 284 301 233 286 301 234 minecraft:light_gray_wool
fill 285 301 228 305 301 228 minecraft:light_gray_concrete
setblock 285 301 232 minecraft:light_gray_wool
fill 285 301 235 285 301 236 minecraft:light_gray_wool
setblock 285 301 270 minecraft:gray_concrete
setblock 286 301 235 minecraft:light_gray_wool
fill 286 301 270 293 301 270 minecraft:light_gray_concrete
fill 295 301 270 298 301 270 minecraft:light_gray_concrete
fill 302 301 270 306 302 270 minecraft:light_gray_concrete
fill 307 301 228 313 301 228 minecraft:light_gray_concrete
fill 308 301 270 313 301 270 minecraft:light_gray_concrete
setblock 314 301 270 minecraft:gray_concrete
setblock 315 301 228 minecraft:light_gray_terracotta
fill 315 301 270 324 301 270 minecraft:light_gray_concrete
fill 316 301 228 324 301 228 minecraft:light_gray_concrete
fill 324 301 229 324 302 240 minecraft:light_gray_concrete
setblock 324 301 241 minecraft:gray_terracotta
fill 324 301 242 324 301 244 minecraft:light_gray_concrete
setblock 324 301 245 minecraft:orange_terracotta
setblock 324 301 247 minecraft:light_gray_concrete
fill 324 301 250 324 308 251 minecraft:light_gray_concrete
fill 324 301 253 324 302 257 minecraft:light_gray_concrete
setblock 324 301 258 minecraft:gray_concrete
fill 324 301 259 324 301 269 minecraft:light_gray_concrete
fill 282 302 228 282 308 228 minecraft:light_gray_concrete
setblock 282 302 229 minecraft:gray_concrete
fill 282 302 230 282 308 231 minecraft:light_gray_concrete
setblock 282 302 232 minecraft:gray_concrete
fill 282 302 233 282 305 233 minecraft:light_gray_concrete
fill 282 302 234 282 302 235 minecraft:gray_concrete
fill 282 302 236 282 308 237 minecraft:light_gray_concrete
setblock 282 302 238 minecraft:gray_concrete
fill 282 302 239 282 308 240 minecraft:light_gray_concrete
fill 282 302 241 282 302 242 minecraft:gray_concrete
fill 282 302 243 282 308 243 minecraft:light_gray_concrete
setblock 282 302 244 minecraft:gray_concrete
setblock 282 302 245 minecraft:light_gray_concrete
setblock 282 302 246 minecraft:gray_concrete
fill 282 302 247 282 306 250 minecraft:light_gray_concrete
setblock 282 302 251 minecraft:gray_concrete
fill 282 302 252 282 305 256 minecraft:light_gray_concrete
fill 282 302 259 282 308 259 minecraft:light_gray_concrete
fill 282 302 263 282 308 263 minecraft:light_gray_concrete
setblock 282 302 264 minecraft:gray_concrete
fill 282 302 265 282 305 268 minecraft:light_gray_concrete
fill 284 302 228 290 305 228 minecraft:light_gray_concrete
fill 285 302 270 289 306 270 minecraft:light_gray_concrete
setblock 290 302 270 minecraft:gray_terracotta
setblock 291 302 228 minecraft:light_gray_terracotta
fill 291 302 270 294 302 270 minecraft:light_gray_concrete
fill 292 302 228 308 302 228 minecraft:light_gray_concrete
setblock 295 302 270 minecraft:gray_concrete
setblock 296 302 270 minecraft:orange_terracotta
fill 297 302 270 298 302 270 minecraft:light_gray_concrete
fill 300 302 270 301 302 270 minecraft:light_gray_concrete
fill 307 302 270 308 302 270 minecraft:light_gray_concrete
setblock 309 302 228 minecraft:gray_concrete
setblock 309 302 270 minecraft:gray_terracotta
fill 310 302 228 319 302 228 minecraft:light_gray_concrete
fill 310 302 270 312 307 270 minecraft:light_gray_concrete
setblock 313 302 270 minecraft:gray_concrete
fill 314 302 270 319 302 270 minecraft:light_gray_concrete
setblock 320 302 228 minecraft:gray_concrete
setblock 320 302 270 minecraft:orange_terracotta
fill 321 302 228 321 308 228 minecraft:light_gray_concrete
fill 321 302 270 323 302 270 minecraft:light_gray_concrete
setblock 322 302 228 minecraft:gray_concrete
fill 323 302 228 324 308 228 minecraft:light_gray_concrete
setblock 324 302 241 minecraft:light_gray_terracotta
setblock 324 302 242 minecraft:gray_concrete
fill 324 302 243 324 302 246 minecraft:light_gray_concrete
setblock 324 302 247 minecraft:light_gray_terracotta
fill 324 302 248 324 302 249 minecraft:light_gray_concrete
setblock 324 302 252 minecraft:light_gray_concrete
fill 324 302 258 324 303 262 minecraft:light_gray_concrete
setblock 324 302 263 minecraft:light_gray_terracotta
fill 324 302 264 324 302 267 minecraft:light_gray_concrete
setblock 324 302 268 minecraft:gray_concrete
fill 324 302 269 324 304 269 minecraft:light_gray_concrete
setblock 324 302 270 minecraft:gray_concrete
fill 282 303 229 282 308 229 minecraft:light_gray_concrete
fill 282 303 232 282 306 232 minecraft:light_gray_concrete
fill 282 303 234 282 308 235 minecraft:light_gray_concrete
fill 282 303 238 282 306 238 minecraft:light_gray_concrete
fill 282 303 241 282 308 242 minecraft:light_gray_concrete
fill 282 303 244 282 308 244 minecraft:light_gray_concrete
setblock 282 303 245 minecraft:orange_terracotta
fill 282 303 246 282 308 246 minecraft:light_gray_concrete
fill 282 303 251 282 308 251 minecraft:light_gray_concrete
fill 282 303 264 282 308 264 minecraft:light_gray_concrete
setblock 282 303 269 minecraft:orange_terracotta
fill 282 303 270 283 308 270 minecraft:light_gray_concrete
setblock 284 303 270 minecraft:gray_concrete
setblock 285 303 231 minecraft:light[level=12]
setblock 285 303 238 minecraft:light[level=12]
setblock 285 303 245 minecraft:light[level=12]
setblock 285 303 252 minecraft:light[level=12]
setblock 285 303 259 minecraft:light[level=12]
setblock 285 303 266 minecraft:light[level=12]
fill 290 303 270 293 304 270 minecraft:light_gray_concrete
setblock 291 303 228 minecraft:gray_terracotta
setblock 292 303 228 minecraft:light_gray_terracotta
setblock 292 303 231 minecraft:light[level=12]
setblock 292 303 238 minecraft:light[level=12]
setblock 292 303 245 minecraft:light[level=12]
setblock 292 303 252 minecraft:light[level=12]
setblock 292 303 259 minecraft:light[level=12]
setblock 292 303 266 minecraft:light[level=12]
fill 293 303 228 298 308 228 minecraft:light_gray_concrete
setblock 294 303 270 minecraft:orange_terracotta
fill 295 303 270 296 303 270 minecraft:light_gray_concrete
setblock 297 303 270 minecraft:gray_concrete
fill 298 303 270 300 303 270 minecraft:light_gray_concrete
setblock 299 303 228 minecraft:gray_concrete
setblock 299 303 231 minecraft:light[level=12]
setblock 299 303 238 minecraft:light[level=12]
setblock 299 303 245 minecraft:light[level=12]
setblock 299 303 252 minecraft:light[level=12]
setblock 299 303 259 minecraft:light[level=12]
setblock 299 303 266 minecraft:light[level=12]
fill 300 303 228 300 308 228 minecraft:light_gray_concrete
setblock 301 303 228 minecraft:orange_terracotta
setblock 301 303 270 minecraft:light_gray_terracotta
fill 302 303 228 302 308 228 minecraft:light_gray_concrete
setblock 302 303 270 minecraft:gray_concrete
setblock 303 303 228 minecraft:orange_terracotta
fill 303 303 270 306 303 270 minecraft:light_gray_concrete
fill 304 303 228 306 308 228 minecraft:light_gray_concrete
setblock 306 303 231 minecraft:light[level=12]
setblock 306 303 238 minecraft:light[level=12]
setblock 306 303 245 minecraft:light[level=12]
setblock 306 303 252 minecraft:light[level=12]
setblock 306 303 259 minecraft:light[level=12]
setblock 306 303 266 minecraft:light[level=12]
setblock 307 303 228 minecraft:gray_concrete
setblock 307 303 270 minecraft:gray_terracotta
fill 308 303 228 314 306 228 minecraft:light_gray_concrete
fill 308 303 270 309 308 270 minecraft:light_gray_concrete
setblock 313 303 231 minecraft:light[level=12]
setblock 313 303 238 minecraft:light[level=12]
setblock 313 303 245 minecraft:light[level=12]
setblock 313 303 252 minecraft:light[level=12]
setblock 313 303 259 minecraft:light[level=12]
setblock 313 303 266 minecraft:light[level=12]
fill 313 303 270 314 304 270 minecraft:light_gray_concrete
setblock 315 303 228 minecraft:gray_concrete
setblock 315 303 270 minecraft:gray_concrete
fill 316 303 228 320 308 228 minecraft:light_gray_concrete
fill 316 303 270 321 305 270 minecraft:light_gray_concrete
setblock 320 303 231 minecraft:light[level=12]
setblock 320 303 238 minecraft:light[level=12]
setblock 320 303 245 minecraft:light[level=12]
setblock 320 303 252 minecraft:light[level=12]
setblock 320 303 259 minecraft:light[level=12]
setblock 320 303 266 minecraft:light[level=12]
fill 322 303 228 322 308 228 minecraft:light_gray_concrete
setblock 322 303 270 minecraft:gray_concrete
fill 323 303 270 324 308 270 minecraft:light_gray_concrete
fill 324 303 229 324 304 231 minecraft:light_gray_concrete
fill 324 303 232 324 303 233 minecraft:gray_concrete
fill 324 303 234 324 304 235 minecraft:light_gray_concrete
setblock 324 303 236 minecraft:gray_concrete
fill 324 303 237 324 308 237 minecraft:light_gray_concrete
fill 324 303 238 324 303 239 minecraft:gray_concrete
fill 324 303 240 324 303 242 minecraft:light_gray_concrete
setblock 324 303 243 minecraft:gray_concrete
fill 324 303 244 324 308 247 minecraft:light_gray_concrete
setblock 324 303 248 minecraft:gray_concrete
fill 324 303 249 324 308 249 minecraft:light_gray_concrete
setblock 324 303 252 minecraft:light_gray_terracotta
fill 324 303 253 324 304 256 minecraft:light_gray_concrete
setblock 324 303 257 minecraft:light_gray_terracotta
fill 324 303 263 324 308 263 minecraft:light_gray_concrete
setblock 324 303 264 minecraft:gray_concrete
fill 324 303 265 324 305 268 minecraft:light_gray_concrete
setblock 282 304 245 minecraft:light_gray_concrete
fill 282 304 269 282 308 269 minecraft:light_gray_concrete
fill 284 304 270 284 308 270 minecraft:light_gray_concrete
setblock 291 304 228 minecraft:orange_terracotta
fill 292 304 228 292 305 228 minecraft:light_gray_concrete
fill 294 304 270 295 304 270 minecraft:light_gray_concrete
setblock 296 304 270 minecraft:orange_terracotta
fill 297 304 270 299 305 270 minecraft:light_gray_concrete
fill 299 304 228 299 308 228 minecraft:light_gray_concrete
setblock 300 304 270 minecraft:light_gray_terracotta
fill 301 304 228 301 308 228 minecraft:light_gray_concrete
fill 301 304 270 302 308 270 minecraft:light_gray_concrete
fill 303 304 228 303 308 228 minecraft:light_gray_concrete
setblock 303 304 270 minecraft:light_gray_terracotta
fill 304 304 270 307 304 270 minecraft:light_gray_concrete
fill 307 304 228 307 308 228 minecraft:light_gray_concrete
fill 315 304 228 315 308 228 minecraft:light_gray_concrete
fill 315 304 270 315 308 270 minecraft:light_gray_concrete
fill 322 304 270 322 308 270 minecraft:light_gray_concrete
fill 324 304 232 324 308 233 minecraft:light_gray_concrete
fill 324 304 236 324 308 236 minecraft:light_gray_concrete
fill 324 304 238 324 308 241 minecraft:light_gray_concrete
setblock 324 304 242 minecraft:gray_terracotta
fill 324 304 243 324 308 243 minecraft:light_gray_concrete
fill 324 304 248 324 307 248 minecraft:light_gray_concrete
fill 324 304 252 324 305 252 minecraft:light_gray_concrete
fill 324 304 257 324 308 259 minecraft:light_gray_concrete
setblock 324 304 260 minecraft:light_gray_terracotta
fill 324 304 261 324 308 262 minecraft:light_gray_concrete
fill 324 304 264 324 308 264 minecraft:light_gray_concrete
setblock 282 305 245 minecraft:light_gray_terracotta
fill 290 305 270 290 308 270 minecraft:light_gray_concrete
fill 291 305 228 291 308 228 minecraft:light_gray_concrete
setblock 291 305 270 minecraft:orange_terracotta
fill 292 305 270 294 308 270 minecraft:light_gray_concrete
setblock 295 305 270 minecraft:light_gray_terracotta
fill 296 305 270 296 308 270 minecraft:light_gray_concrete
fill 300 305 270 300 308 270 minecraft:light_gray_concrete
fill 303 305 270 305 305 270 minecraft:light_gray_concrete
setblock 306 305 270 minecraft:gray_terracotta
fill 307 305 270 307 308 270 minecraft:light_gray_concrete
setblock 313 305 270 minecraft:orange_terracotta
fill 314 305 270 314 308 270 minecraft:light_gray_concrete
setblock 324 305 229 minecraft:gray_terracotta
fill 324 305 230 324 308 231 minecraft:light_gray_concrete
setblock 324 305 234 minecraft:light_gray_terracotta
fill 324 305 235 324 308 235 minecraft:light_gray_concrete
fill 324 305 242 324 308 242 minecraft:light_gray_concrete
fill 324 305 253 324 308 254 minecraft:light_gray_concrete
setblock 324 305 255 minecraft:orange_terracotta
fill 324 305 256 324 308 256 minecraft:light_gray_concrete
fill 324 305 260 324 308 260 minecraft:light_gray_concrete
setblock 324 305 269 minecraft:orange_terracotta
setblock 282 306 233 minecraft:orange_terracotta
fill 282 306 245 282 308 245 minecraft:light_gray_concrete
fill 282 306 252 282 308 255 minecraft:light_gray_concrete
setblock 282 306 256 minecraft:light_gray_terracotta
setblock 282 306 265 minecraft:light_gray_concrete
setblock 282 306 266 minecraft:gray_terracotta
fill 282 306 267 282 307 268 minecraft:light_gray_concrete
fill 284 306 228 286 308 228 minecraft:light_gray_concrete
setblock 287 306 228 minecraft:light_gray_terracotta
fill 288 306 228 290 306 228 minecraft:light_gray_concrete
fill 291 306 270 291 308 270 minecraft:light_gray_concrete
setblock 292 306 228 minecraft:gray_terracotta
fill 295 306 270 295 308 270 minecraft:light_gray_concrete
setblock 297 306 270 minecraft:orange_terracotta
fill 298 306 270 299 306 270 minecraft:light_gray_concrete
fill 303 306 270 304 308 270 minecraft:light_gray_concrete
setblock 305 306 270 minecraft:light_gray_terracotta
setblock 306 306 270 minecraft:orange_terracotta
fill 313 306 270 313 308 270 minecraft:light_gray_concrete
fill 316 306 270 316 308 270 minecraft:light_gray_concrete
setblock 317 306 270 minecraft:orange_terracotta
fill 318 306 270 318 308 270 minecraft:light_gray_concrete
setblock 319 306 270 minecraft:gray_terracotta
fill 320 306 270 320 308 270 minecraft:light_gray_concrete
setblock 321 306 270 minecraft:gray_terracotta
fill 324 306 229 324 308 229 minecraft:light_gray_concrete
fill 324 306 234 324 308 234 minecraft:light_gray_concrete
setblock 324 306 252 minecraft:light_gray_terracotta
fill 324 306 255 324 308 255 minecraft:light_gray_concrete
setblock 324 306 265 minecraft:gray_terracotta
fill 324 306 266 324 308 269 minecraft:light_gray_concrete
setblock 282 307 232 minecraft:light_gray_terracotta
fill 282 307 233 282 308 233 minecraft:light_gray_concrete
setblock 282 307 238 minecraft:orange_terracotta
fill 282 307 247 282 308 249 minecraft:light_gray_concrete
setblock 282 307 250 minecraft:gray_terracotta
fill 282 307 256 282 308 256 minecraft:light_gray_concrete
fill 282 307 260 282 308 261 minecraft:light_gray_concrete
setblock 282 307 262 minecraft:light_gray_terracotta
setblock 282 307 265 minecraft:light_gray_terracotta
fill 282 307 266 282 308 266 minecraft:light_gray_concrete
fill 285 307 270 286 308 270 minecraft:light_gray_concrete
setblock 287 307 228 minecraft:gray_terracotta
setblock 287 307 270 minecraft:orange_terracotta
fill 288 307 228 288 308 228 minecraft:light_gray_concrete
fill 288 307 270 289 308 270 minecraft:light_gray_concrete
setblock 289 307 228 minecraft:gray_terracotta
fill 290 307 228 290 308 228 minecraft:light_gray_concrete
fill 292 307 228 292 308 228 minecraft:light_gray_concrete
fill 297 307 270 297 308 270 minecraft:light_gray_concrete
setblock 298 307 270 minecraft:light_gray_terracotta
fill 299 307 270 299 308 270 minecraft:light_gray_concrete
fill 305 307 270 306 308 270 minecraft:light_gray_concrete
fill 308 307 228 310 308 228 minecraft:light_gray_concrete
setblock 311 307 228 minecraft:orange_terracotta
fill 312 307 228 314 307 228 minecraft:light_gray_concrete
fill 317 307 270 317 308 270 minecraft:light_gray_concrete
fill 319 307 270 319 308 270 minecraft:light_gray_concrete
fill 321 307 270 321 308 270 minecraft:light_gray_concrete
fill 324 307 252 324 308 252 minecraft:light_gray_concrete
fill 324 307 265 324 308 265 minecraft:light_gray_concrete
setblock 282 308 232 minecraft:light_gray_concrete
setblock 282 308 238 minecraft:light_gray_concrete
setblock 282 308 250 minecraft:light_gray_concrete
setblock 282 308 262 minecraft:light_gray_concrete
setblock 282 308 265 minecraft:light_gray_concrete
setblock 282 308 267 minecraft:light_gray_terracotta
setblock 282 308 268 minecraft:light_gray_concrete
setblock 287 308 228 minecraft:light_gray_concrete
setblock 287 308 270 minecraft:light_gray_concrete
setblock 289 308 228 minecraft:light_gray_concrete
setblock 298 308 270 minecraft:light_gray_concrete
setblock 310 308 270 minecraft:light_gray_concrete
setblock 311 308 228 minecraft:light_gray_concrete
setblock 311 308 270 minecraft:orange_terracotta
setblock 312 308 228 minecraft:gray_terracotta
setblock 312 308 270 minecraft:light_gray_concrete
fill 313 308 228 314 308 228 minecraft:light_gray_concrete
setblock 324 308 248 minecraft:light_gray_terracotta
