setblock 355 184 540 minecraft:ochre_froglight
fill 356 184 540 357 189 540 minecraft:dark_oak_planks
setblock 357 184 526 minecraft:ochre_froglight
fill 358 184 526 359 189 526 minecraft:dark_oak_planks
setblock 358 184 540 minecraft:ochre_froglight
fill 359 184 532 359 185 534 minecraft:glass
fill 359 184 540 360 189 540 minecraft:dark_oak_planks
setblock 360 184 526 minecraft:ochre_froglight
fill 361 184 526 362 189 526 minecraft:dark_oak_planks
setblock 361 184 540 minecraft:ochre_froglight
fill 362 184 540 363 189 540 minecraft:dark_oak_planks
setblock 363 184 526 minecraft:ochre_froglight
fill 363 184 527 363 189 528 minecraft:dark_oak_planks
setblock 363 184 529 minecraft:ochre_froglight
fill 363 184 530 363 189 531 minecraft:dark_oak_planks
setblock 363 184 532 minecraft:ochre_froglight
fill 363 184 533 363 189 534 minecraft:dark_oak_planks
setblock 363 184 535 minecraft:ochre_froglight
fill 363 184 536 363 189 537 minecraft:dark_oak_planks
setblock 363 184 538 minecraft:ochre_froglight
fill 363 184 539 363 189 539 minecraft:dark_oak_planks
fill 330 185 511 332 229 511 minecraft:gold_block
fill 330 185 514 330 185 519 minecraft:cut_sandstone
fill 330 185 521 330 229 523 minecraft:gold_block
fill 330 185 526 330 185 531 minecraft:cut_sandstone
fill 330 185 533 330 229 535 minecraft:gold_block
fill 330 185 538 330 185 543 minecraft:cut_sandstone
fill 330 185 545 330 229 547 minecraft:gold_block
fill 330 185 550 330 185 551 minecraft:cut_sandstone
fill 331 185 520 331 185 522 minecraft:gold_block
fill 331 185 532 331 185 534 minecraft:gold_block
fill 331 185 544 331 185 546 minecraft:gold_block
fill 331 185 551 334 185 551 minecraft:cut_sandstone
setblock 332 185 513 minecraft:light[level=14]
setblock 332 185 521 minecraft:light[level=14]
setblock 332 185 529 minecraft:light[level=14]
setblock 332 185 537 minecraft:light[level=14]
setblock 332 185 545 minecraft:light[level=14]
fill 334 185 511 339 185 511 minecraft:cut_sandstone
fill 336 185 551 338 229 551 minecraft:gold_block
fill 337 185 550 339 185 550 minecraft:gold_block
setblock 340 185 513 minecraft:light[level=14]
setblock 340 185 521 minecraft:light[level=14]
setblock 340 185 529 minecraft:light[level=14]
setblock 340 185 537 minecraft:light[level=14]
setblock 340 185 545 minecraft:light[level=14]
fill 341 185 512 343 185 512 minecraft:gold_block
fill 341 185 551 346 185 551 minecraft:cut_sandstone
fill 342 185 511 344 229 511 minecraft:gold_block
fill 345 185 526 345 187 526 minecraft:dark_oak_planks
fill 345 185 529 345 187 529 minecraft:dark_oak_planks
fill 345 185 532 345 187 532 minecraft:dark_oak_planks
fill 345 185 535 345 187 535 minecraft:dark_oak_planks
fill 345 185 538 345 187 538 minecraft:dark_oak_planks
fill 346 185 511 351 185 511 minecraft:cut_sandstone
fill 346 185 540 346 187 540 minecraft:dark_oak_planks
setblock 348 185 513 minecraft:light[level=14]
setblock 348 185 521 minecraft:light[level=14]
fill 348 185 526 348 187 526 minecraft:dark_oak_planks
setblock 348 185 529 minecraft:light[level=14]
fill 348 185 532 348 186 534 minecraft:glass
setblock 348 185 537 minecraft:light[level=14]
setblock 348 185 545 minecraft:light[level=14]
fill 348 185 551 350 229 551 minecraft:gold_block
fill 349 185 530 349 185 531 minecraft:glass
fill 349 185 535 349 185 536 minecraft:glass
fill 349 185 540 349 187 540 minecraft:dark_oak_planks
fill 349 185 550 351 185 550 minecraft:gold_block
fill 350 185 529 350 185 530 minecraft:glass
fill 350 185 536 350 185 537 minecraft:glass
fill 351 185 526 351 187 526 minecraft:dark_oak_planks
fill 351 185 528 351 185 529 minecraft:glass
fill 351 185 538 352 185 538 minecraft:glass
setblock 352 185 528 minecraft:glass
fill 352 185 540 352 187 540 minecraft:dark_oak_planks
fill 353 185 512 355 185 512 minecraft:gold_block
fill 353 185 527 355 186 527 minecraft:glass
fill 353 185 539 355 186 539 minecraft:glass
fill 353 185 551 358 185 551 minecraft:cut_sandstone
fill 354 185 511 356 229 511 minecraft:gold_block
fill 354 185 526 354 187 526 minecraft:dark_oak_planks
fill 355 185 540 355 187 540 minecraft:dark_oak_planks
setblock 356 185 513 minecraft:light[level=14]
setblock 356 185 521 minecraft:light[level=14]
fill 356 185 528 357 185 528 minecraft:glass
setblock 356 185 529 minecraft:light[level=14]
fill 356 185 538 357 185 538 minecraft:glass
setblock 356 185 545 minecraft:light[level=14]
fill 357 185 526 357 187 526 minecraft:dark_oak_planks
fill 357 185 529 358 185 529 minecraft:glass
fill 358 185 511 363 185 511 minecraft:cut_sandstone
fill 358 185 540 358 187 540 minecraft:dark_oak_planks
fill 359 185 530 359 185 531 minecraft:glass
fill 359 185 535 359 185 536 minecraft:glass
fill 360 185 526 360 187 526 minecraft:dark_oak_planks
fill 360 185 532 360 186 534 minecraft:glass
fill 360 185 551 362 229 551 minecraft:gold_block
fill 361 185 540 361 187 540 minecraft:dark_oak_planks
fill 361 185 550 363 185 550 minecraft:gold_block
fill 363 185 526 363 187 526 minecraft:dark_oak_planks
fill 363 185 529 363 187 529 minecraft:dark_oak_planks
fill 363 185 532 363 187 532 minecraft:dark_oak_planks
fill 363 185 535 363 187 535 minecraft:dark_oak_planks
fill 363 185 538 363 187 538 minecraft:dark_oak_planks
fill 363 185 545 363 185 547 minecraft:cut_sandstone
setblock 364 185 513 minecraft:light[level=14]
setblock 364 185 521 minecraft:light[level=14]
setblock 364 185 529 minecraft:light[level=14]
setblock 364 185 537 minecraft:light[level=14]
fill 364 185 544 366 185 544 minecraft:cut_sandstone
fill 364 185 545 366 229 547 minecraft:gold_block
fill 364 185 548 367 185 548 minecraft:cut_sandstone
fill 365 185 512 367 185 512 minecraft:gold_block
fill 365 185 551 370 185 551 minecraft:cut_sandstone
fill 366 185 511 368 229 511 minecraft:gold_block
fill 367 185 545 367 185 547 minecraft:cut_sandstone
fill 369 185 520 369 185 522 minecraft:gold_block
fill 369 185 532 369 185 534 minecraft:gold_block
fill 369 185 544 369 185 546 minecraft:gold_block
fill 370 185 511 370 185 516 minecraft:cut_sandstone
fill 370 185 519 370 229 521 minecraft:gold_block
fill 370 185 523 370 185 528 minecraft:cut_sandstone
fill 370 185 531 370 229 533 minecraft:gold_block
fill 370 185 535 370 185 540 minecraft:cut_sandstone
fill 370 185 543 370 229 545 minecraft:gold_block
fill 370 185 547 370 185 550 minecraft:cut_sandstone
fill 329 186 516 329 191 519 minecraft:ochre_froglight
fill 329 186 528 329 191 531 minecraft:ochre_froglight
fill 329 186 540 329 191 543 minecraft:ochre_froglight
fill 329 186 552 332 191 552 minecraft:ochre_froglight
fill 336 186 510 339 191 510 minecraft:ochre_froglight
fill 341 186 552 344 191 552 minecraft:ochre_froglight
fill 347 186 532 347 187 534 minecraft:glass
fill 348 186 510 351 191 510 minecraft:ochre_froglight
fill 348 186 530 348 186 531 minecraft:glass
fill 348 186 535 348 186 536 minecraft:glass
fill 349 186 528 349 186 530 minecraft:glass
fill 349 186 536 349 186 538 minecraft:glass
fill 350 186 528 351 186 528 minecraft:glass
fill 350 186 538 351 186 538 minecraft:glass
fill 351 186 527 352 186 527 minecraft:glass
fill 351 186 539 352 186 539 minecraft:glass
fill 353 186 552 356 191 552 minecraft:ochre_froglight
fill 356 186 527 357 186 527 minecraft:glass
fill 356 186 539 357 186 539 minecraft:glass
fill 357 186 528 359 186 528 minecraft:glass
fill 357 186 538 359 186 538 minecraft:glass
fill 359 186 529 359 186 530 minecraft:glass
fill 359 186 536 359 186 537 minecraft:glass
fill 360 186 510 363 191 510 minecraft:ochre_froglight
fill 360 186 530 360 186 531 minecraft:glass
fill 360 186 535 360 186 536 minecraft:glass
fill 361 186 532 361 187 534 minecraft:glass
fill 365 186 552 368 191 552 minecraft:ochre_froglight
fill 371 186 511 371 191 514 minecraft:ochre_froglight
fill 371 186 523 371 191 526 minecraft:ochre_froglight
fill 371 186 535 371 191 538 minecraft:ochre_froglight
fill 371 186 547 371 191 550 minecraft:ochre_froglight
fill 346 187 532 346 188 534 minecraft:glass
fill 347 187 529 347 187 531 minecraft:glass
fill 347 187 535 347 187 537 minecraft:glass
fill 348 187 528 348 187 529 minecraft:glass
fill 348 187 537 348 187 538 minecraft:glass
fill 349 187 527 349 187 528 minecraft:glass
fill 349 187 538 349 187 539 minecraft:glass
setblock 350 187 527 minecraft:glass
setblock 350 187 539 minecraft:glass
fill 353 187 525 355 188 525 minecraft:glass
fill 353 187 541 355 188 541 minecraft:glass
fill 358 187 527 359 187 527 minecraft:glass
fill 358 187 539 359 187 539 minecraft:glass
fill 359 187 528 360 187 528 minecraft:glass
fill 359 187 538 360 187 538 minecraft:glass
fill 360 187 529 361 187 529 minecraft:glass
fill 360 187 537 361 187 537 minecraft:glass
fill 361 187 530 361 187 531 minecraft:glass
fill 361 187 535 361 187 536 minecraft:glass
fill 362 187 532 362 188 534 minecraft:glass
setblock 345 188 526 minecraft:ochre_froglight
setblock 345 188 529 minecraft:ochre_froglight
setblock 345 188 532 minecraft:ochre_froglight
setblock 345 188 535 minecraft:ochre_froglight
setblock 345 188 538 minecraft:ochre_froglight
fill 346 188 529 346 188 531 minecraft:glass
fill 346 188 535 346 188 537 minecraft:glass
setblock 346 188 540 minecraft:ochre_froglight
fill 347 188 528 347 188 529 minecraft:glass
fill 347 188 537 347 188 538 minecraft:glass
setblock 348 188 526 minecraft:ochre_froglight
fill 348 188 527 348 188 528 minecraft:glass
fill 348 188 538 348 188 539 minecraft:glass
setblock 349 188 527 minecraft:glass
setblock 349 188 539 minecraft:glass
setblock 349 188 540 minecraft:ochre_froglight
fill 350 188 525 352 188 525 minecraft:glass
fill 350 188 541 352 188 541 minecraft:glass
setblock 351 188 526 minecraft:ochre_froglight
setblock 352 188 540 minecraft:ochre_froglight
fill 353 188 524 355 189 524 minecraft:glass
fill 353 188 542 355 189 542 minecraft:glass
setblock 354 188 526 minecraft:ochre_froglight
setblock 355 188 540 minecraft:ochre_froglight
fill 356 188 525 358 188 525 minecraft:glass
fill 356 188 541 358 188 541 minecraft:glass
setblock 357 188 526 minecraft:ochre_froglight
setblock 358 188 540 minecraft:ochre_froglight
fill 359 188 527 360 188 527 minecraft:glass
fill 359 188 539 360 188 539 minecraft:glass
setblock 360 188 526 minecraft:ochre_froglight
fill 360 188 528 361 188 528 minecraft:glass
fill 360 188 538 361 188 538 minecraft:glass
fill 361 188 529 362 188 529 minecraft:glass
fill 361 188 537 362 188 537 minecraft:glass
setblock 361 188 540 minecraft:ochre_froglight
fill 362 188 530 362 188 531 minecraft:glass
fill 362 188 535 362 188 536 minecraft:glass
setblock 363 188 526 minecraft:ochre_froglight
setblock 363 188 529 minecraft:ochre_froglight
setblock 363 188 532 minecraft:ochre_froglight
setblock 363 188 535 minecraft:ochre_froglight
setblock 363 188 538 minecraft:ochre_froglight
fill 344 189 532 344 189 534 minecraft:glass
setblock 345 189 526 minecraft:dark_oak_planks
fill 345 189 529 363 189 529 minecraft:dark_oak_planks
fill 345 189 532 350 189 532 minecraft:dark_oak_planks
fill 345 189 535 350 189 535 minecraft:dark_oak_planks
fill 345 189 538 363 189 538 minecraft:dark_oak_planks
fill 346 189 527 362 189 528 minecraft:dark_oak_planks
fill 346 189 530 350 189 531 minecraft:dark_oak_planks
fill 346 189 533 350 189 534 minecraft:dark_oak_planks
fill 346 189 536 350 189 537 minecraft:dark_oak_planks
fill 346 189 539 346 189 540 minecraft:dark_oak_planks
fill 347 189 539 362 189 539 minecraft:dark_oak_planks
fill 348 189 525 350 189 525 minecraft:glass
setblock 348 189 526 minecraft:dark_oak_planks
fill 348 189 541 350 189 541 minecraft:glass
setblock 349 189 540 minecraft:dark_oak_planks
fill 350 189 524 352 189 524 minecraft:glass
fill 350 189 542 352 189 542 minecraft:glass
setblock 351 189 526 minecraft:dark_oak_planks
setblock 352 189 540 minecraft:dark_oak_planks
fill 353 189 523 355 189 523 minecraft:glass
fill 353 189 543 355 189 543 minecraft:glass
setblock 354 189 526 minecraft:dark_oak_planks
setblock 355 189 540 minecraft:dark_oak_planks
fill 356 189 524 358 189 524 minecraft:glass
fill 356 189 542 358 189 542 minecraft:glass
setblock 357 189 526 minecraft:dark_oak_planks
fill 358 189 525 360 189 525 minecraft:glass
setblock 358 189 540 minecraft:dark_oak_planks
fill 358 189 541 360 189 541 minecraft:glass
fill 359 189 530 362 189 537 minecraft:dark_oak_planks
setblock 360 189 526 minecraft:dark_oak_planks
setblock 361 189 540 minecraft:dark_oak_planks
setblock 363 189 526 minecraft:dark_oak_planks
setblock 363 189 532 minecraft:dark_oak_planks
setblock 363 189 535 minecraft:dark_oak_planks
fill 364 189 532 364 189 534 minecraft:glass
fill 344 190 531 344 191 535 minecraft:gold_block
fill 345 190 526 350 190 540 minecraft:deepslate_tiles
fill 348 190 525 351 191 525 minecraft:gold_block
fill 348 190 541 351 191 541 minecraft:gold_block
fill 350 190 524 358 191 524 minecraft:gold_block
fill 350 190 542 358 191 542 minecraft:gold_block
fill 351 190 526 363 190 529 minecraft:deepslate_tiles
fill 351 190 538 363 190 540 minecraft:deepslate_tiles
fill 352 190 523 356 191 523 minecraft:gold_block
fill 352 190 543 356 191 543 minecraft:gold_block
fill 357 190 525 360 191 525 minecraft:gold_block
fill 357 190 541 360 191 541 minecraft:gold_block
fill 359 190 530 363 190 537 minecraft:deepslate_tiles
fill 364 190 531 364 191 535 minecraft:gold_block
fill 345 191 529 345 191 537 minecraft:gold_block
fill 346 191 527 350 191 539 minecraft:deepslate_tiles
fill 347 191 526 349 191 526 minecraft:gold_block
fill 347 191 540 349 191 540 minecraft:gold_block
fill 351 191 527 362 191 529 minecraft:deepslate_tiles
fill 351 191 538 362 191 539 minecraft:deepslate_tiles
fill 359 191 526 361 191 526 minecraft:gold_block
fill 359 191 530 362 191 537 minecraft:deepslate_tiles
fill 359 191 540 361 191 540 minecraft:gold_block
fill 363 191 529 363 191 537 minecraft:gold_block
fill 329 192 516 329 205 516 minecraft:cut_sandstone
fill 329 192 517 329 192 518 minecraft:ochre_froglight
fill 329 192 519 329 205 519 minecraft:cut_sandstone
fill 329 192 528 329 205 528 minecraft:cut_sandstone
fill 329 192 529 329 192 530 minecraft:ochre_froglight
fill 329 192 531 329 205 531 minecraft:cut_sandstone
fill 329 192 540 329 205 540 minecraft:cut_sandstone
fill 329 192 541 329 192 542 minecraft:ochre_froglight
fill 329 192 543 329 205 543 minecraft:cut_sandstone
fill 329 192 552 329 205 552 minecraft:cut_sandstone
fill 330 192 552 331 192 552 minecraft:ochre_froglight
fill 332 192 552 332 205 552 minecraft:cut_sandstone
fill 336 192 510 336 205 510 minecraft:cut_sandstone
fill 337 192 510 338 192 510 minecraft:ochre_froglight
fill 339 192 510 339 205 510 minecraft:cut_sandstone
fill 341 192 552 341 205 552 minecraft:cut_sandstone
fill 342 192 552 343 192 552 minecraft:ochre_froglight
fill 344 192 552 344 205 552 minecraft:cut_sandstone
fill 347 192 528 350 192 538 minecraft:deepslate_tiles
fill 348 192 510 348 205 510 minecraft:cut_sandstone
fill 349 192 510 350 192 510 minecraft:ochre_froglight
fill 351 192 510 351 205 510 minecraft:cut_sandstone
fill 351 192 528 361 192 529 minecraft:deepslate_tiles
fill 351 192 538 361 192 538 minecraft:deepslate_tiles
fill 353 192 552 353 205 552 minecraft:cut_sandstone
fill 354 192 552 355 192 552 minecraft:ochre_froglight
fill 356 192 552 356 205 552 minecraft:cut_sandstone
fill 359 192 530 361 192 537 minecraft:deepslate_tiles
fill 360 192 510 360 205 510 minecraft:cut_sandstone
fill 361 192 510 362 192 510 minecraft:ochre_froglight
fill 363 192 510 363 205 510 minecraft:cut_sandstone
fill 365 192 552 365 205 552 minecraft:cut_sandstone
fill 366 192 552 367 192 552 minecraft:ochre_froglight
fill 368 192 552 368 205 552 minecraft:cut_sandstone
fill 371 192 511 371 205 511 minecraft:cut_sandstone
fill 371 192 512 371 192 513 minecraft:ochre_froglight
fill 371 192 514 371 205 514 minecraft:cut_sandstone
fill 371 192 523 371 205 523 minecraft:cut_sandstone
fill 371 192 524 371 192 525 minecraft:ochre_froglight
fill 371 192 526 371 205 526 minecraft:cut_sandstone
fill 371 192 535 371 205 535 minecraft:cut_sandstone
fill 371 192 536 371 192 537 minecraft:ochre_froglight
fill 371 192 538 371 205 538 minecraft:cut_sandstone
fill 371 192 547 371 205 547 minecraft:cut_sandstone
fill 371 192 548 371 192 549 minecraft:ochre_froglight
fill 371 192 550 371 205 550 minecraft:cut_sandstone
fill 329 193 517 329 205 518 minecraft:cut_sandstone
fill 329 193 529 329 205 530 minecraft:cut_sandstone
fill 329 193 541 329 205 542 minecraft:cut_sandstone
fill 330 193 552 331 205 552 minecraft:cut_sandstone
setblock 332 193 513 minecraft:light[level=14]
setblock 332 193 521 minecraft:light[level=14]
setblock 332 193 529 minecraft:light[level=14]
setblock 332 193 537 minecraft:light[level=14]
setblock 332 193 545 minecraft:light[level=14]
fill 337 193 510 338 205 510 minecraft:cut_sandstone
setblock 340 193 513 minecraft:light[level=14]
setblock 340 193 521 minecraft:light[level=14]
setblock 340 193 529 minecraft:light[level=14]
setblock 340 193 537 minecraft:light[level=14]
setblock 340 193 545 minecraft:light[level=14]
fill 342 193 552 343 205 552 minecraft:cut_sandstone
setblock 348 193 513 minecraft:light[level=14]
setblock 348 193 521 minecraft:light[level=14]
fill 348 193 529 350 193 537 minecraft:deepslate_tiles
setblock 348 193 545 minecraft:light[level=14]
fill 349 193 510 350 205 510 minecraft:cut_sandstone
fill 351 193 529 360 193 529 minecraft:deepslate_tiles
fill 354 193 552 355 205 552 minecraft:cut_sandstone
setblock 356 193 513 minecraft:light[level=14]
setblock 356 193 521 minecraft:light[level=14]
setblock 356 193 545 minecraft:light[level=14]
fill 359 193 530 360 193 537 minecraft:deepslate_tiles
fill 361 193 510 362 205 510 minecraft:cut_sandstone
fill 363 193 545 363 193 547 minecraft:cut_sandstone
setblock 364 193 513 minecraft:light[level=14]
setblock 364 193 521 minecraft:light[level=14]
setblock 364 193 529 minecraft:light[level=14]
setblock 364 193 537 minecraft:light[level=14]
fill 364 193 544 366 193 544 minecraft:cut_sandstone
fill 364 193 548 367 193 548 minecraft:cut_sandstone
fill 366 193 552 367 205 552 minecraft:cut_sandstone
fill 367 193 545 367 193 547 minecraft:cut_sandstone
fill 371 193 512 371 205 513 minecraft:cut_sandstone
fill 371 193 524 371 205 525 minecraft:cut_sandstone
fill 371 193 536 371 205 537 minecraft:cut_sandstone
fill 371 193 548 371 205 549 minecraft:cut_sandstone
fill 349 194 530 350 194 536 minecraft:deepslate_tiles
fill 359 194 530 359 194 536 minecraft:deepslate_tiles
fill 350 195 531 350 195 535 minecraft:deepslate_tiles
fill 343 199 516 343 200 516 minecraft:sandstone
fill 331 200 520 331 205 522 minecraft:gold_block
fill 331 200 532 331 205 534 minecraft:gold_block
fill 331 200 544 331 205 546 minecraft:gold_block
fill 337 200 550 339 205 550 minecraft:gold_block
fill 341 200 512 343 205 512 minecraft:gold_block
fill 349 200 550 351 205 550 minecraft:gold_block
fill 353 200 512 355 205 512 minecraft:gold_block
fill 361 200 550 363 205 550 minecraft:gold_block
fill 365 200 512 367 205 512 minecraft:gold_block
fill 369 200 520 369 205 522 minecraft:gold_block
fill 369 200 532 369 205 534 minecraft:gold_block
fill 369 200 544 369 205 546 minecraft:gold_block
setblock 332 201 513 minecraft:light[level=14]
setblock 332 201 521 minecraft:light[level=14]
setblock 332 201 529 minecraft:light[level=14]
setblock 332 201 537 minecraft:light[level=14]
setblock 332 201 545 minecraft:light[level=14]
setblock 340 201 513 minecraft:light[level=14]
setblock 340 201 521 minecraft:light[level=14]
setblock 340 201 529 minecraft:light[level=14]
setblock 340 201 537 minecraft:light[level=14]
setblock 340 201 545 minecraft:light[level=14]
setblock 348 201 513 minecraft:light[level=14]
setblock 348 201 521 minecraft:light[level=14]
setblock 348 201 529 minecraft:light[level=14]
setblock 348 201 537 minecraft:light[level=14]
setblock 348 201 545 minecraft:light[level=14]
fill 350 201 540 351 202 540 minecraft:yellow_concrete
setblock 356 201 513 minecraft:light[level=14]
setblock 356 201 521 minecraft:light[level=14]
setblock 356 201 529 minecraft:light[level=14]
setblock 356 201 537 minecraft:light[level=14]
setblock 356 201 545 minecraft:light[level=14]
fill 363 201 545 363 201 547 minecraft:cut_sandstone
setblock 364 201 513 minecraft:light[level=14]
setblock 364 201 521 minecraft:light[level=14]
setblock 364 201 529 minecraft:light[level=14]
setblock 364 201 537 minecraft:light[level=14]
fill 364 201 544 366 201 544 minecraft:cut_sandstone
fill 364 201 548 367 201 548 minecraft:cut_sandstone
fill 367 201 545 367 201 547 minecraft:cut_sandstone
fill 341 203 532 341 204 533 minecraft:sandstone
fill 356 203 513 360 204 517 minecraft:cut_sandstone
fill 358 203 511 358 203 512 minecraft:cut_sandstone
fill 330 205 514 330 205 519 minecraft:cut_sandstone
fill 330 205 526 330 205 531 minecraft:cut_sandstone
fill 330 205 538 330 205 543 minecraft:cut_sandstone
fill 330 205 550 330 205 551 minecraft:cut_sandstone
fill 331 205 551 334 205 551 minecraft:cut_sandstone
fill 334 205 511 339 205 511 minecraft:cut_sandstone
fill 341 205 551 346 205 551 minecraft:cut_sandstone
fill 346 205 511 351 205 511 minecraft:cut_sandstone
fill 353 205 551 358 205 551 minecraft:cut_sandstone
fill 357 205 514 359 206 516 minecraft:gold_block
fill 358 205 511 363 205 511 minecraft:cut_sandstone
fill 365 205 551 370 205 551 minecraft:cut_sandstone
fill 370 205 511 370 205 516 minecraft:cut_sandstone
fill 370 205 523 370 205 528 minecraft:cut_sandstone
fill 370 205 535 370 205 540 minecraft:cut_sandstone
fill 370 205 547 370 205 550 minecraft:cut_sandstone
fill 329 206 516 329 211 519 minecraft:ochre_froglight
fill 329 206 528 329 211 531 minecraft:ochre_froglight
fill 329 206 540 329 211 543 minecraft:ochre_froglight
fill 329 206 552 332 211 552 minecraft:ochre_froglight
fill 336 206 510 339 211 510 minecraft:ochre_froglight
fill 341 206 552 344 211 552 minecraft:ochre_froglight
fill 348 206 510 351 211 510 minecraft:ochre_froglight
fill 353 206 552 356 211 552 minecraft:ochre_froglight
fill 360 206 510 363 211 510 minecraft:ochre_froglight
fill 365 206 552 368 211 552 minecraft:ochre_froglight
fill 371 206 511 371 211 514 minecraft:ochre_froglight
fill 371 206 523 371 211 526 minecraft:ochre_froglight
fill 371 206 535 371 211 538 minecraft:ochre_froglight
fill 371 206 547 371 211 550 minecraft:ochre_froglight
fill 357 207 515 359 209 515 minecraft:gold_block
fill 358 207 514 358 209 514 minecraft:gold_block
fill 358 207 516 358 209 516 minecraft:gold_block
fill 329 209 510 332 209 510 minecraft:cut_sandstone
setblock 329 209 511 minecraft:sandstone
fill 329 209 512 329 210 515 minecraft:cut_sandstone
fill 329 209 520 329 212 522 minecraft:cut_sandstone
setblock 329 209 523 minecraft:sandstone
fill 329 209 524 329 212 525 minecraft:cut_sandstone
setblock 332 209 513 minecraft:light[level=14]
setblock 332 209 521 minecraft:light[level=14]
setblock 332 209 529 minecraft:light[level=14]
setblock 332 209 537 minecraft:light[level=14]
setblock 332 209 545 minecraft:light[level=14]
setblock 333 209 510 minecraft:sandstone
fill 334 209 510 335 212 510 minecraft:cut_sandstone
setblock 340 209 513 minecraft:light[level=14]
setblock 340 209 521 minecraft:light[level=14]
setblock 340 209 529 minecraft:light[level=14]
setblock 340 209 537 minecraft:light[level=14]
setblock 340 209 545 minecraft:light[level=14]
setblock 342 209 510 minecraft:sandstone
fill 343 209 510 343 212 510 minecraft:cut_sandstone
fill 345 209 510 346 212 510 minecraft:cut_sandstone
setblock 347 209 510 minecraft:sandstone
setblock 348 209 513 minecraft:light[level=14]
setblock 348 209 521 minecraft:light[level=14]
setblock 348 209 529 minecraft:light[level=14]
setblock 348 209 537 minecraft:light[level=14]
setblock 348 209 545 minecraft:light[level=14]
setblock 356 209 513 minecraft:light[level=14]
setblock 356 209 521 minecraft:light[level=14]
setblock 356 209 529 minecraft:light[level=14]
setblock 356 209 537 minecraft:light[level=14]
setblock 356 209 545 minecraft:light[level=14]
fill 363 209 545 363 209 547 minecraft:cut_sandstone
setblock 364 209 513 minecraft:light[level=14]
setblock 364 209 521 minecraft:light[level=14]
setblock 364 209 529 minecraft:light[level=14]
setblock 364 209 537 minecraft:light[level=14]
fill 364 209 544 366 209 544 minecraft:cut_sandstone
fill 364 209 548 367 209 548 minecraft:cut_sandstone
fill 367 209 510 367 212 510 minecraft:cut_sandstone
fill 367 209 545 367 209 547 minecraft:cut_sandstone
setblock 368 209 510 minecraft:sandstone
fill 369 209 510 370 210 510 minecraft:cut_sandstone
fill 371 209 516 371 212 517 minecraft:cut_sandstone
setblock 371 209 518 minecraft:sandstone
fill 371 209 519 371 212 519 minecraft:cut_sandstone
setblock 371 209 522 minecraft:sandstone
setblock 371 209 528 minecraft:sandstone
fill 371 209 529 371 212 529 minecraft:cut_sandstone
setblock 371 209 530 minecraft:sandstone
setblock 371 209 533 minecraft:sandstone
fill 371 209 534 371 210 534 minecraft:cut_sandstone
fill 371 209 539 371 212 543 minecraft:cut_sandstone
setblock 371 209 544 minecraft:sandstone
fill 371 209 545 371 210 546 minecraft:cut_sandstone
fill 329 210 510 329 212 511 minecraft:cut_sandstone
fill 329 210 523 329 212 523 minecraft:cut_sandstone
setblock 329 210 544 minecraft:sandstone
fill 329 210 545 329 212 546 minecraft:cut_sandstone
setblock 329 210 547 minecraft:sandstone
setblock 329 210 551 minecraft:sandstone
setblock 330 210 510 minecraft:sandstone
fill 331 210 510 333 212 510 minecraft:cut_sandstone
fill 333 210 552 333 213 552 minecraft:cut_sandstone
setblock 334 210 552 minecraft:sandstone
fill 335 210 552 338 212 552 minecraft:cut_sandstone
setblock 339 210 552 minecraft:sandstone
fill 342 210 510 342 213 510 minecraft:cut_sandstone
fill 347 210 510 347 212 510 minecraft:cut_sandstone
fill 356 210 510 356 211 510 minecraft:sandstone
fill 357 210 510 359 212 510 minecraft:cut_sandstone
fill 358 210 515 358 214 515 minecraft:gold_block
fill 365 210 538 365 211 539 minecraft:yellow_concrete
setblock 368 210 510 minecraft:cut_sandstone
setblock 369 210 552 minecraft:cut_sandstone
setblock 370 210 552 minecraft:sandstone
setblock 371 210 510 minecraft:sandstone
fill 371 210 518 371 212 518 minecraft:cut_sandstone
fill 371 210 522 371 212 522 minecraft:cut_sandstone
fill 371 210 528 371 212 528 minecraft:cut_sandstone
fill 371 210 530 371 212 530 minecraft:cut_sandstone
fill 371 210 533 371 212 533 minecraft:cut_sandstone
fill 371 210 544 371 212 544 minecraft:cut_sandstone
setblock 371 210 552 minecraft:cut_sandstone
fill 329 211 512 329 211 513 minecraft:sandstone
fill 329 211 514 329 212 515 minecraft:cut_sandstone
fill 329 211 536 329 214 536 minecraft:cut_sandstone
setblock 329 211 537 minecraft:sandstone
fill 329 211 538 329 212 538 minecraft:cut_sandstone
fill 329 211 544 329 212 544 minecraft:cut_sandstone
fill 329 211 547 329 212 547 minecraft:cut_sandstone
setblock 329 211 548 minecraft:sandstone
fill 329 211 551 329 212 551 minecraft:cut_sandstone
fill 330 211 510 330 212 510 minecraft:cut_sandstone
fill 334 211 552 334 212 552 minecraft:cut_sandstone
fill 339 211 552 339 212 552 minecraft:cut_sandstone
setblock 345 211 552 minecraft:sandstone
fill 346 211 552 346 212 552 minecraft:cut_sandstone
setblock 347 211 552 minecraft:sandstone
fill 348 211 552 348 212 552 minecraft:cut_sandstone
fill 357 211 552 358 212 552 minecraft:cut_sandstone
fill 359 211 552 360 211 552 minecraft:sandstone
fill 361 211 552 364 212 552 minecraft:cut_sandstone
setblock 368 211 510 minecraft:sandstone
fill 369 211 510 369 212 510 minecraft:cut_sandstone
setblock 369 211 552 minecraft:sandstone
setblock 370 211 510 minecraft:sandstone
fill 370 211 552 370 212 552 minecraft:cut_sandstone
fill 371 211 510 371 214 510 minecraft:cut_sandstone
fill 371 211 520 371 212 520 minecraft:cut_sandstone
setblock 371 211 521 minecraft:sandstone
setblock 371 211 534 minecraft:sandstone
fill 371 211 545 371 211 546 minecraft:sandstone
setblock 371 211 552 minecraft:sandstone
fill 329 212 512 329 212 513 minecraft:cut_sandstone
fill 329 212 516 329 213 516 minecraft:cut_sandstone
fill 329 212 517 329 212 518 minecraft:ochre_froglight
setblock 329 212 519 minecraft:cut_sandstone
fill 329 212 528 329 213 528 minecraft:cut_sandstone
fill 329 212 529 329 212 530 minecraft:ochre_froglight
setblock 329 212 531 minecraft:cut_sandstone
setblock 329 212 537 minecraft:cut_sandstone
setblock 329 212 540 minecraft:cut_sandstone
fill 329 212 541 329 212 542 minecraft:ochre_froglight
fill 329 212 543 329 214 543 minecraft:cut_sandstone
setblock 329 212 548 minecraft:cut_sandstone
setblock 329 212 552 minecraft:cut_sandstone
fill 330 212 552 331 212 552 minecraft:ochre_froglight
setblock 332 212 552 minecraft:cut_sandstone
setblock 336 212 510 minecraft:cut_sandstone
fill 337 212 510 338 212 510 minecraft:ochre_froglight
fill 339 212 510 339 213 510 minecraft:cut_sandstone
setblock 341 212 552 minecraft:cut_sandstone
fill 342 212 552 343 212 552 minecraft:ochre_froglight
fill 344 212 552 345 212 552 minecraft:cut_sandstone
setblock 347 212 552 minecraft:cut_sandstone
setblock 348 212 510 minecraft:cut_sandstone
fill 349 212 510 350 212 510 minecraft:ochre_froglight
fill 351 212 510 351 213 510 minecraft:cut_sandstone
setblock 353 212 552 minecraft:cut_sandstone
fill 354 212 552 355 212 552 minecraft:ochre_froglight
setblock 356 212 510 minecraft:cut_sandstone
fill 356 212 552 356 213 552 minecraft:cut_sandstone
fill 359 212 552 360 212 552 minecraft:cut_sandstone
setblock 360 212 510 minecraft:cut_sandstone
fill 361 212 510 362 212 510 minecraft:ochre_froglight
setblock 363 212 510 minecraft:cut_sandstone
setblock 365 212 552 minecraft:cut_sandstone
fill 366 212 552 367 212 552 minecraft:ochre_froglight
setblock 368 212 510 minecraft:cut_sandstone
fill 368 212 552 369 212 552 minecraft:cut_sandstone
setblock 370 212 510 minecraft:cut_sandstone
setblock 371 212 511 minecraft:cut_sandstone
fill 371 212 512 371 212 513 minecraft:ochre_froglight
setblock 371 212 514 minecraft:cut_sandstone
fill 371 212 521 371 213 521 minecraft:cut_sandstone
setblock 371 212 523 minecraft:cut_sandstone
fill 371 212 524 371 212 525 minecraft:ochre_froglight
setblock 371 212 526 minecraft:cut_sandstone
fill 371 212 534 371 212 535 minecraft:cut_sandstone
fill 371 212 536 371 212 537 minecraft:ochre_froglight
setblock 371 212 538 minecraft:cut_sandstone
fill 371 212 545 371 212 547 minecraft:cut_sandstone
fill 371 212 548 371 212 549 minecraft:ochre_froglight
setblock 371 212 550 minecraft:cut_sandstone
setblock 371 212 552 minecraft:cut_sandstone
fill 329 213 510 329 213 515 minecraft:sandstone
fill 329 213 517 329 213 527 minecraft:sandstone
fill 329 213 529 329 225 535 minecraft:sandstone
fill 329 213 537 329 214 542 minecraft:sandstone
fill 329 213 544 329 214 552 minecraft:sandstone
fill 330 213 510 338 213 510 minecraft:sandstone
fill 330 213 552 332 225 552 minecraft:sandstone
fill 334 213 540 334 214 541 minecraft:sandstone
fill 334 213 552 344 213 552 minecraft:sandstone
fill 340 213 510 341 307 510 minecraft:sandstone
fill 343 213 510 348 225 510 minecraft:sandstone
setblock 345 213 552 minecraft:cut_sandstone
fill 346 213 552 355 213 552 minecraft:sandstone
setblock 349 213 510 minecraft:cut_sandstone
fill 350 213 510 350 225 510 minecraft:sandstone
setblock 352 213 510 minecraft:cut_sandstone
fill 353 213 510 370 214 510 minecraft:sandstone
fill 357 213 552 371 213 552 minecraft:sandstone
fill 371 213 511 371 225 516 minecraft:sandstone
setblock 371 213 517 minecraft:cut_sandstone
fill 371 213 518 371 213 520 minecraft:sandstone
fill 371 213 522 371 225 526 minecraft:sandstone
fill 371 213 528 371 213 531 minecraft:sandstone
setblock 371 213 532 minecraft:cut_sandstone
fill 371 213 533 371 225 538 minecraft:sandstone
fill 371 213 539 371 215 539 minecraft:cut_sandstone
fill 371 213 540 371 213 547 minecraft:sandstone
setblock 371 213 548 minecraft:cut_sandstone
fill 371 213 549 371 225 551 minecraft:sandstone
fill 329 214 510 329 214 514 minecraft:sandstone
setblock 329 214 515 minecraft:cut_sandstone
fill 329 214 516 329 225 518 minecraft:sandstone
setblock 329 214 519 minecraft:cut_sandstone
fill 329 214 520 329 214 528 minecraft:sandstone
setblock 330 214 510 minecraft:cut_sandstone
fill 331 214 510 339 214 510 minecraft:sandstone
fill 333 214 552 337 214 552 minecraft:sandstone
fill 338 214 552 339 214 552 minecraft:cut_sandstone
fill 340 214 552 343 214 552 minecraft:sandstone
fill 342 214 510 342 307 510 minecraft:sandstone
setblock 344 214 552 minecraft:cut_sandstone
fill 345 214 552 350 214 552 minecraft:sandstone
fill 349 214 510 349 225 510 minecraft:sandstone
fill 351 214 510 352 225 510 minecraft:sandstone
setblock 351 214 552 minecraft:cut_sandstone
fill 352 214 552 359 225 552 minecraft:sandstone
setblock 360 214 552 minecraft:cut_sandstone
fill 361 214 552 363 307 552 minecraft:sandstone
setblock 364 214 552 minecraft:cut_sandstone
fill 365 214 552 371 214 552 minecraft:sandstone
fill 371 214 517 371 307 517 minecraft:sandstone
setblock 371 214 518 minecraft:cut_sandstone
fill 371 214 519 371 214 521 minecraft:sandstone
fill 371 214 528 371 307 528 minecraft:sandstone
setblock 371 214 529 minecraft:cut_sandstone
fill 371 214 530 371 307 530 minecraft:sandstone
setblock 371 214 531 minecraft:cut_sandstone
fill 371 214 532 371 307 532 minecraft:sandstone
fill 371 214 540 371 307 544 minecraft:sandstone
setblock 371 214 545 minecraft:cut_sandstone
fill 371 214 546 371 214 548 minecraft:sandstone
fill 329 215 510 329 307 513 minecraft:sandstone
setblock 329 215 514 minecraft:cut_sandstone
fill 329 215 515 329 307 515 minecraft:sandstone
fill 329 215 519 329 225 519 minecraft:sandstone
fill 329 215 520 329 215 521 minecraft:cut_sandstone
fill 329 215 522 329 307 523 minecraft:sandstone
setblock 329 215 524 minecraft:cut_sandstone
fill 329 215 525 329 307 525 minecraft:sandstone
setblock 329 215 526 minecraft:cut_sandstone
fill 329 215 527 329 225 528 minecraft:sandstone
fill 329 215 536 329 307 536 minecraft:sandstone
setblock 329 215 537 minecraft:cut_sandstone
fill 329 215 538 329 225 543 minecraft:sandstone
setblock 329 215 544 minecraft:cut_sandstone
fill 329 215 545 329 225 552 minecraft:sandstone
fill 330 215 510 333 307 510 minecraft:sandstone
fill 333 215 552 335 307 552 minecraft:sandstone
setblock 334 215 510 minecraft:cut_sandstone
fill 335 215 510 339 225 510 minecraft:sandstone
setblock 336 215 552 minecraft:cut_sandstone
fill 337 215 552 337 307 552 minecraft:sandstone
setblock 338 215 552 minecraft:cut_sandstone
fill 339 215 552 339 307 552 minecraft:sandstone
setblock 340 215 552 minecraft:cut_sandstone
fill 341 215 552 346 225 552 minecraft:sandstone
setblock 347 215 552 minecraft:cut_sandstone
fill 348 215 552 351 307 552 minecraft:sandstone
fill 353 215 510 353 307 510 minecraft:sandstone
setblock 354 215 510 minecraft:cut_sandstone
fill 355 215 510 365 225 510 minecraft:sandstone
setblock 358 215 515 minecraft:ochre_froglight
fill 360 215 552 360 307 552 minecraft:sandstone
fill 364 215 552 370 225 552 minecraft:sandstone
setblock 366 215 510 minecraft:cut_sandstone
fill 367 215 510 371 307 510 minecraft:sandstone
fill 371 215 518 371 307 519 minecraft:sandstone
setblock 371 215 520 minecraft:cut_sandstone
fill 371 215 521 371 307 521 minecraft:sandstone
fill 371 215 527 371 307 527 minecraft:sandstone
fill 371 215 529 371 307 529 minecraft:sandstone
fill 371 215 531 371 307 531 minecraft:sandstone
fill 371 215 545 371 225 547 minecraft:sandstone
setblock 371 215 548 minecraft:cut_sandstone
setblock 371 215 552 minecraft:cut_sandstone
fill 329 216 514 329 307 514 minecraft:sandstone
fill 329 216 520 329 307 521 minecraft:sandstone
fill 329 216 524 329 307 524 minecraft:sandstone
fill 329 216 526 329 307 526 minecraft:sandstone
fill 329 216 537 329 307 537 minecraft:sandstone
fill 329 216 544 329 307 544 minecraft:sandstone
fill 334 216 510 334 307 510 minecraft:sandstone
fill 336 216 552 336 307 552 minecraft:sandstone
fill 338 216 552 338 307 552 minecraft:sandstone
fill 340 216 552 340 307 552 minecraft:sandstone
fill 347 216 552 347 307 552 minecraft:sandstone
fill 354 216 510 354 307 510 minecraft:sandstone
fill 366 216 510 366 307 510 minecraft:sandstone
fill 371 216 520 371 307 520 minecraft:sandstone
fill 371 216 539 371 307 539 minecraft:sandstone
fill 371 216 548 371 225 548 minecraft:sandstone
fill 371 216 552 371 307 552 minecraft:sandstone
setblock 332 217 513 minecraft:light[level=14]
setblock 332 217 521 minecraft:light[level=14]
setblock 332 217 529 minecraft:light[level=14]
setblock 332 217 537 minecraft:light[level=14]
setblock 332 217 545 minecraft:light[level=14]
setblock 340 217 513 minecraft:light[level=14]
setblock 340 217 521 minecraft:light[level=14]
setblock 340 217 529 minecraft:light[level=14]
setblock 340 217 537 minecraft:light[level=14]
setblock 340 217 545 minecraft:light[level=14]
setblock 348 217 513 minecraft:light[level=14]
setblock 348 217 521 minecraft:light[level=14]
setblock 348 217 529 minecraft:light[level=14]
setblock 348 217 537 minecraft:light[level=14]
setblock 348 217 545 minecraft:light[level=14]
setblock 356 217 513 minecraft:light[level=14]
setblock 356 217 521 minecraft:light[level=14]
setblock 356 217 529 minecraft:light[level=14]
setblock 356 217 537 minecraft:light[level=14]
setblock 356 217 545 minecraft:light[level=14]
fill 363 217 545 363 217 547 minecraft:cut_sandstone
setblock 364 217 513 minecraft:light[level=14]
setblock 364 217 521 minecraft:light[level=14]
setblock 364 217 529 minecraft:light[level=14]
setblock 364 217 537 minecraft:light[level=14]
fill 364 217 544 366 217 544 minecraft:cut_sandstone
fill 364 217 548 367 217 548 minecraft:cut_sandstone
fill 367 217 545 367 217 547 minecraft:cut_sandstone
fill 331 220 520 331 225 522 minecraft:gold_block
fill 331 220 532 331 225 534 minecraft:gold_block
fill 331 220 544 331 225 546 minecraft:gold_block
fill 337 220 550 339 225 550 minecraft:gold_block
fill 341 220 512 343 225 512 minecraft:gold_block
fill 349 220 550 351 225 550 minecraft:gold_block
fill 353 220 512 355 225 512 minecraft:gold_block
fill 361 220 550 363 225 550 minecraft:gold_block
fill 365 220 512 367 225 512 minecraft:gold_block
fill 369 220 520 369 225 522 minecraft:gold_block
fill 369 220 532 369 225 534 minecraft:gold_block
fill 369 220 544 369 225 546 minecraft:gold_block
fill 344 223 522 344 224 522 minecraft:sandstone
fill 330 225 514 330 225 519 minecraft:cut_sandstone
fill 330 225 526 330 225 531 minecraft:cut_sandstone
fill 330 225 538 330 225 543 minecraft:cut_sandstone
fill 330 225 550 330 225 551 minecraft:cut_sandstone
fill 331 225 551 334 225 551 minecraft:cut_sandstone
setblock 332 225 513 minecraft:light[level=14]
setblock 332 225 521 minecraft:light[level=14]
setblock 332 225 529 minecraft:light[level=14]
setblock 332 225 537 minecraft:light[level=14]
setblock 332 225 545 minecraft:light[level=14]
fill 334 225 511 339 225 511 minecraft:cut_sandstone
setblock 340 225 513 minecraft:light[level=14]
setblock 340 225 521 minecraft:light[level=14]
setblock 340 225 529 minecraft:light[level=14]
setblock 340 225 537 minecraft:light[level=14]
setblock 340 225 545 minecraft:light[level=14]
fill 341 225 551 346 225 551 minecraft:cut_sandstone
fill 346 225 511 351 225 511 minecraft:cut_sandstone
setblock 348 225 513 minecraft:light[level=14]
setblock 348 225 521 minecraft:light[level=14]
setblock 348 225 529 minecraft:light[level=14]
setblock 348 225 537 minecraft:light[level=14]
setblock 348 225 545 minecraft:light[level=14]
fill 353 225 551 358 225 551 minecraft:cut_sandstone
setblock 356 225 513 minecraft:light[level=14]
setblock 356 225 521 minecraft:light[level=14]
setblock 356 225 529 minecraft:light[level=14]
setblock 356 225 537 minecraft:light[level=14]
setblock 356 225 545 minecraft:light[level=14]
fill 358 225 511 363 225 511 minecraft:cut_sandstone
fill 363 225 545 363 225 547 minecraft:cut_sandstone
setblock 364 225 513 minecraft:light[level=14]
setblock 364 225 521 minecraft:light[level=14]
setblock 364 225 529 minecraft:light[level=14]
setblock 364 225 537 minecraft:light[level=14]
fill 364 225 544 366 225 544 minecraft:cut_sandstone
fill 364 225 548 367 225 548 minecraft:cut_sandstone
fill 365 225 551 370 225 551 minecraft:cut_sandstone
fill 367 225 545 367 225 547 minecraft:cut_sandstone
fill 370 225 511 370 225 516 minecraft:cut_sandstone
fill 370 225 523 370 225 528 minecraft:cut_sandstone
fill 370 225 535 370 225 540 minecraft:cut_sandstone
fill 370 225 547 370 225 550 minecraft:cut_sandstone
fill 329 226 516 329 229 519 minecraft:ochre_froglight
fill 329 226 527 329 307 527 minecraft:sandstone
fill 329 226 528 329 229 531 minecraft:ochre_froglight
fill 329 226 532 329 307 535 minecraft:sandstone
fill 329 226 538 329 307 539 minecraft:sandstone
fill 329 226 540 329 229 543 minecraft:ochre_froglight
fill 329 226 545 329 307 551 minecraft:sandstone
fill 329 226 552 332 229 552 minecraft:ochre_froglight
fill 335 226 510 335 307 510 minecraft:sandstone
fill 336 226 510 339 229 510 minecraft:ochre_froglight
fill 341 226 552 344 229 552 minecraft:ochre_froglight
fill 343 226 510 347 307 510 minecraft:sandstone
fill 345 226 552 346 307 552 minecraft:sandstone
fill 348 226 510 351 229 510 minecraft:ochre_froglight
fill 352 226 510 352 307 510 minecraft:sandstone
fill 352 226 552 352 307 552 minecraft:sandstone
fill 353 226 552 356 229 552 minecraft:ochre_froglight
fill 355 226 510 359 307 510 minecraft:sandstone
fill 357 226 552 359 307 552 minecraft:sandstone
fill 360 226 510 363 229 510 minecraft:ochre_froglight
fill 364 226 510 365 307 510 minecraft:sandstone
fill 364 226 552 364 307 552 minecraft:sandstone
fill 365 226 552 368 229 552 minecraft:ochre_froglight
fill 369 226 552 370 307 552 minecraft:sandstone
fill 371 226 511 371 229 514 minecraft:ochre_froglight
fill 371 226 515 371 307 516 minecraft:sandstone
fill 371 226 522 371 307 522 minecraft:sandstone
fill 371 226 523 371 229 526 minecraft:ochre_froglight
fill 371 226 533 371 307 534 minecraft:sandstone
fill 371 226 535 371 229 538 minecraft:ochre_froglight
fill 371 226 545 371 307 546 minecraft:sandstone
fill 371 226 547 371 229 550 minecraft:ochre_froglight
fill 371 226 551 371 307 551 minecraft:sandstone
fill 363 228 546 363 229 547 minecraft:sandstone
fill 364 228 548 366 229 548 minecraft:sandstone
fill 365 228 544 366 229 544 minecraft:sandstone
fill 367 228 545 367 229 547 minecraft:sandstone
fill 329 230 516 329 245 519 minecraft:sandstone
fill 329 230 528 329 245 531 minecraft:sandstone
fill 329 230 540 329 245 543 minecraft:sandstone
fill 329 230 552 332 245 552 minecraft:sandstone
fill 336 230 510 339 245 510 minecraft:sandstone
fill 341 230 552 344 245 552 minecraft:sandstone
fill 348 230 510 351 245 510 minecraft:sandstone
fill 353 230 552 356 245 552 minecraft:sandstone
fill 360 230 510 363 245 510 minecraft:sandstone
fill 365 230 552 368 245 552 minecraft:sandstone
fill 371 230 511 371 245 514 minecraft:sandstone
fill 371 230 523 371 245 526 minecraft:sandstone
fill 371 230 535 371 245 538 minecraft:sandstone
fill 371 230 547 371 245 550 minecraft:sandstone
setblock 332 233 513 minecraft:light[level=14]
setblock 332 233 521 minecraft:light[level=14]
setblock 332 233 529 minecraft:light[level=14]
setblock 332 233 537 minecraft:light[level=14]
setblock 332 233 545 minecraft:light[level=14]
setblock 340 233 513 minecraft:light[level=14]
setblock 340 233 521 minecraft:light[level=14]
setblock 340 233 529 minecraft:light[level=14]
setblock 340 233 537 minecraft:light[level=14]
setblock 340 233 545 minecraft:light[level=14]
setblock 348 233 513 minecraft:light[level=14]
setblock 348 233 521 minecraft:light[level=14]
setblock 348 233 529 minecraft:light[level=14]
setblock 348 233 537 minecraft:light[level=14]
setblock 348 233 545 minecraft:light[level=14]
setblock 356 233 513 minecraft:light[level=14]
setblock 356 233 521 minecraft:light[level=14]
setblock 356 233 529 minecraft:light[level=14]
setblock 356 233 537 minecraft:light[level=14]
setblock 356 233 545 minecraft:light[level=14]
setblock 364 233 513 minecraft:light[level=14]
setblock 364 233 521 minecraft:light[level=14]
setblock 364 233 529 minecraft:light[level=14]
setblock 364 233 537 minecraft:light[level=14]
setblock 364 233 545 minecraft:light[level=14]
fill 336 235 532 338 236 532 minecraft:yellow_concrete
fill 337 235 527 339 236 531 minecraft:yellow_concrete
fill 337 235 533 338 236 537 minecraft:yellow_concrete
fill 338 235 525 338 236 525 minecraft:sandstone
fill 338 235 526 343 236 526 minecraft:yellow_concrete
fill 338 235 538 338 236 539 minecraft:yellow_concrete
fill 339 235 523 339 236 524 minecraft:sandstone
fill 339 235 525 345 236 525 minecraft:yellow_concrete
fill 339 235 532 344 236 539 minecraft:sandstone
fill 339 235 540 339 236 541 minecraft:yellow_concrete
fill 340 235 522 340 236 523 minecraft:sandstone
fill 340 235 524 355 236 524 minecraft:yellow_concrete
fill 340 235 527 340 236 529 minecraft:yellow_concrete
fill 340 235 530 346 236 531 minecraft:sandstone
fill 340 235 540 346 236 541 minecraft:sandstone
fill 340 235 542 340 236 542 minecraft:yellow_concrete
fill 341 235 521 342 236 522 minecraft:sandstone
fill 341 235 523 354 236 523 minecraft:yellow_concrete
fill 341 235 527 341 236 528 minecraft:yellow_concrete
fill 341 235 529 349 236 529 minecraft:sandstone
fill 341 235 542 349 236 543 minecraft:sandstone
fill 342 235 520 360 236 520 minecraft:sandstone
fill 342 235 527 342 236 527 minecraft:yellow_concrete
fill 342 235 528 353 236 528 minecraft:sandstone
fill 342 235 544 360 236 544 minecraft:sandstone
fill 343 235 521 344 236 521 minecraft:sandstone
fill 343 235 522 352 236 522 minecraft:yellow_concrete
fill 343 235 527 352 236 527 minecraft:sandstone
fill 344 235 519 358 236 519 minecraft:sandstone
fill 344 235 526 351 236 526 minecraft:sandstone
fill 344 235 545 358 236 545 minecraft:sandstone
fill 345 235 521 350 236 521 minecraft:yellow_concrete
fill 345 235 532 345 236 534 minecraft:sandstone
fill 345 235 535 348 236 535 minecraft:yellow_concrete
fill 345 235 536 345 236 539 minecraft:sandstone
fill 346 235 518 356 236 518 minecraft:sandstone
fill 346 235 525 349 236 525 minecraft:sandstone
fill 346 235 532 347 236 534 minecraft:yellow_concrete
fill 346 235 536 348 236 538 minecraft:yellow_concrete
fill 346 235 539 346 236 539 minecraft:sandstone
fill 346 235 546 356 236 546 minecraft:sandstone
fill 347 235 530 348 236 530 minecraft:sandstone
fill 347 235 531 347 236 531 minecraft:yellow_concrete
fill 347 235 539 352 236 540 minecraft:yellow_concrete
fill 347 235 541 347 236 541 minecraft:sandstone
fill 348 235 531 348 235 533 minecraft:gold_block
fill 348 235 534 348 236 534 minecraft:yellow_concrete
fill 348 235 541 361 236 541 minecraft:yellow_concrete
fill 349 235 530 349 235 531 minecraft:gold_block
fill 349 235 533 349 235 534 minecraft:gold_block
fill 349 235 535 349 236 536 minecraft:sandstone
fill 349 235 537 349 236 538 minecraft:yellow_concrete
fill 350 235 525 355 236 525 minecraft:yellow_concrete
fill 350 235 529 350 235 530 minecraft:gold_block
fill 350 235 534 350 235 535 minecraft:gold_block
fill 350 235 536 359 236 537 minecraft:sandstone
fill 350 235 538 350 236 538 minecraft:yellow_concrete
fill 350 235 542 359 236 542 minecraft:yellow_concrete
fill 350 235 543 351 236 543 minecraft:sandstone
fill 351 235 517 351 236 517 minecraft:sandstone
fill 351 235 521 361 236 521 minecraft:sandstone
fill 351 235 529 352 235 529 minecraft:gold_block
fill 351 235 535 352 235 535 minecraft:gold_block
fill 351 235 538 358 236 538 minecraft:sandstone
fill 351 235 547 351 236 547 minecraft:sandstone
fill 352 235 526 356 236 526 minecraft:yellow_concrete
fill 352 235 530 353 235 530 minecraft:gold_block
fill 352 235 534 353 235 534 minecraft:gold_block
fill 352 235 543 357 236 543 minecraft:yellow_concrete
fill 353 235 522 361 236 522 minecraft:sandstone
fill 353 235 527 356 236 527 minecraft:yellow_concrete
fill 353 235 529 353 236 529 minecraft:sandstone
fill 353 235 531 354 235 531 minecraft:gold_block
fill 353 235 533 354 235 533 minecraft:gold_block
fill 353 235 535 361 236 535 minecraft:sandstone
fill 353 235 539 356 236 539 minecraft:sandstone
fill 353 235 540 362 236 540 minecraft:yellow_concrete
fill 354 235 528 356 236 530 minecraft:yellow_concrete
setblock 354 235 532 minecraft:gold_block
fill 354 235 534 362 236 534 minecraft:sandstone
fill 355 235 523 362 236 523 minecraft:sandstone
fill 355 235 531 355 236 533 minecraft:yellow_concrete
fill 356 235 524 362 236 525 minecraft:sandstone
fill 356 235 531 356 236 532 minecraft:yellow_concrete
fill 356 235 533 362 236 533 minecraft:sandstone
fill 357 235 526 363 236 528 minecraft:sandstone
fill 357 235 529 357 236 529 minecraft:yellow_concrete
fill 357 235 530 363 236 532 minecraft:sandstone
fill 357 235 539 363 236 539 minecraft:yellow_concrete
fill 358 235 529 363 236 529 minecraft:sandstone
fill 358 235 543 361 236 543 minecraft:sandstone
fill 359 235 538 364 236 538 minecraft:yellow_concrete
fill 360 235 536 360 236 536 minecraft:sandstone
fill 360 235 537 365 236 537 minecraft:yellow_concrete
fill 360 235 542 362 236 542 minecraft:sandstone
fill 361 235 536 365 236 536 minecraft:yellow_concrete
fill 362 235 522 362 236 522 minecraft:yellow_concrete
fill 362 235 535 365 236 535 minecraft:yellow_concrete
fill 362 235 541 363 236 541 minecraft:sandstone
fill 363 235 523 363 236 524 minecraft:yellow_concrete
fill 363 235 525 363 236 525 minecraft:sandstone
fill 363 235 533 365 236 534 minecraft:yellow_concrete
fill 363 235 540 363 236 540 minecraft:sandstone
fill 364 235 525 364 236 532 minecraft:yellow_concrete
fill 364 235 539 364 236 539 minecraft:sandstone
fill 365 235 527 365 236 532 minecraft:yellow_concrete
fill 366 235 532 366 236 532 minecraft:yellow_concrete
fill 330 236 511 335 236 551 minecraft:cut_sandstone
fill 336 236 511 336 236 531 minecraft:cut_sandstone
fill 336 236 533 336 236 551 minecraft:cut_sandstone
fill 337 236 511 337 236 526 minecraft:cut_sandstone
fill 337 236 538 337 236 551 minecraft:cut_sandstone
fill 338 236 511 338 236 524 minecraft:cut_sandstone
fill 338 236 540 338 236 551 minecraft:cut_sandstone
fill 339 236 511 339 236 522 minecraft:cut_sandstone
fill 339 236 542 339 236 551 minecraft:cut_sandstone
fill 340 236 511 340 236 521 minecraft:cut_sandstone
fill 340 236 543 340 236 551 minecraft:cut_sandstone
fill 341 236 511 341 236 520 minecraft:cut_sandstone
fill 341 236 544 341 236 551 minecraft:cut_sandstone
fill 342 236 511 343 236 519 minecraft:cut_sandstone
fill 342 236 545 343 236 551 minecraft:cut_sandstone
fill 344 236 511 345 236 518 minecraft:cut_sandstone
fill 344 236 546 345 236 551 minecraft:cut_sandstone
fill 346 236 511 350 236 517 minecraft:cut_sandstone
fill 346 236 547 350 236 551 minecraft:cut_sandstone
fill 348 236 531 348 236 533 minecraft:ochre_froglight
fill 349 236 530 349 236 531 minecraft:ochre_froglight
fill 349 236 533 349 236 534 minecraft:ochre_froglight
fill 350 236 529 350 236 530 minecraft:ochre_froglight
fill 350 236 534 350 236 535 minecraft:ochre_froglight
fill 351 236 511 370 236 516 minecraft:cut_sandstone
fill 351 236 529 352 236 529 minecraft:ochre_froglight
fill 351 236 535 352 236 535 minecraft:ochre_froglight
fill 351 236 548 370 236 551 minecraft:cut_sandstone
fill 352 236 517 370 236 517 minecraft:cut_sandstone
fill 352 236 530 353 236 530 minecraft:ochre_froglight
fill 352 236 534 353 236 534 minecraft:ochre_froglight
fill 352 236 547 370 236 547 minecraft:cut_sandstone
fill 353 236 531 354 236 531 minecraft:ochre_froglight
fill 353 236 533 354 236 533 minecraft:ochre_froglight
setblock 354 236 532 minecraft:ochre_froglight
fill 357 236 518 370 236 518 minecraft:cut_sandstone
fill 357 236 546 370 236 546 minecraft:cut_sandstone
fill 359 236 519 370 236 519 minecraft:cut_sandstone
fill 359 236 545 370 236 545 minecraft:cut_sandstone
fill 361 236 520 370 236 520 minecraft:cut_sandstone
fill 361 236 544 370 236 544 minecraft:cut_sandstone
fill 362 236 521 370 236 521 minecraft:cut_sandstone
fill 362 236 543 370 236 543 minecraft:cut_sandstone
fill 363 236 522 370 236 522 minecraft:cut_sandstone
fill 363 236 542 370 236 542 minecraft:cut_sandstone
fill 364 236 523 370 236 524 minecraft:cut_sandstone
fill 364 236 540 370 236 541 minecraft:cut_sandstone
fill 365 236 525 370 236 526 minecraft:cut_sandstone
fill 365 236 538 370 236 539 minecraft:cut_sandstone
fill 366 236 527 370 236 531 minecraft:cut_sandstone
fill 366 236 533 370 236 537 minecraft:cut_sandstone
fill 367 236 532 370 236 532 minecraft:cut_sandstone
fill 330 240 511 332 273 511 minecraft:gold_block
fill 330 240 521 330 273 523 minecraft:gold_block
fill 330 240 533 330 273 535 minecraft:gold_block
fill 330 240 545 330 273 547 minecraft:gold_block
fill 331 240 520 331 245 522 minecraft:gold_block
fill 331 240 532 331 245 534 minecraft:gold_block
fill 331 240 544 331 245 546 minecraft:gold_block
fill 336 240 551 338 273 551 minecraft:gold_block
fill 337 240 550 339 245 550 minecraft:gold_block
fill 341 240 512 343 245 512 minecraft:gold_block
fill 342 240 511 344 273 511 minecraft:gold_block
fill 348 240 551 350 273 551 minecraft:gold_block
fill 349 240 550 351 245 550 minecraft:gold_block
fill 353 240 512 355 245 512 minecraft:gold_block
fill 353 240 514 354 241 515 minecraft:sandstone
fill 354 240 511 356 273 511 minecraft:gold_block
fill 354 240 538 354 240 539 minecraft:yellow_concrete
fill 360 240 551 362 273 551 minecraft:gold_block
fill 361 240 550 363 245 550 minecraft:gold_block
fill 365 240 512 367 245 512 minecraft:gold_block
fill 366 240 511 368 273 511 minecraft:gold_block
fill 369 240 520 369 245 522 minecraft:gold_block
fill 369 240 532 369 245 534 minecraft:gold_block
fill 369 240 544 369 245 546 minecraft:gold_block
fill 370 240 519 370 273 521 minecraft:gold_block
fill 370 240 531 370 273 533 minecraft:gold_block
fill 370 240 543 370 273 545 minecraft:gold_block
setblock 332 241 513 minecraft:light[level=14]
setblock 332 241 521 minecraft:light[level=14]
setblock 332 241 529 minecraft:light[level=14]
setblock 332 241 537 minecraft:light[level=14]
setblock 332 241 545 minecraft:light[level=14]
setblock 340 241 513 minecraft:light[level=14]
setblock 340 241 521 minecraft:light[level=14]
setblock 340 241 529 minecraft:light[level=14]
setblock 340 241 537 minecraft:light[level=14]
setblock 340 241 545 minecraft:light[level=14]
setblock 348 241 513 minecraft:light[level=14]
setblock 348 241 521 minecraft:light[level=14]
setblock 348 241 529 minecraft:light[level=14]
setblock 348 241 537 minecraft:light[level=14]
setblock 348 241 545 minecraft:light[level=14]
setblock 356 241 513 minecraft:light[level=14]
setblock 356 241 521 minecraft:light[level=14]
setblock 356 241 529 minecraft:light[level=14]
setblock 356 241 537 minecraft:light[level=14]
setblock 356 241 545 minecraft:light[level=14]
setblock 364 241 513 minecraft:light[level=14]
setblock 364 241 521 minecraft:light[level=14]
setblock 364 241 529 minecraft:light[level=14]
setblock 364 241 537 minecraft:light[level=14]
setblock 364 241 545 minecraft:light[level=14]
fill 332 244 525 332 245 537 minecraft:gold_block
fill 333 244 523 333 245 530 minecraft:gold_block
fill 333 244 532 333 245 539 minecraft:gold_block
fill 334 244 521 334 245 525 minecraft:gold_block
fill 334 244 537 334 245 541 minecraft:gold_block
fill 335 244 520 335 245 522 minecraft:gold_block
fill 335 244 540 335 245 542 minecraft:gold_block
fill 336 244 519 336 245 521 minecraft:gold_block
fill 336 244 541 336 245 543 minecraft:gold_block
fill 337 244 518 337 245 520 minecraft:gold_block
fill 337 244 542 337 245 544 minecraft:gold_block
fill 338 244 517 339 245 518 minecraft:gold_block
fill 338 244 544 339 245 545 minecraft:gold_block
fill 339 244 516 341 245 516 minecraft:gold_block
fill 339 244 546 341 245 546 minecraft:gold_block
fill 340 244 515 344 245 515 minecraft:gold_block
fill 340 244 517 340 245 517 minecraft:gold_block
fill 340 244 545 340 245 545 minecraft:gold_block
fill 340 244 547 344 245 547 minecraft:gold_block
fill 342 244 514 349 245 514 minecraft:gold_block
fill 342 244 548 349 245 548 minecraft:gold_block
fill 344 244 513 356 245 513 minecraft:gold_block
fill 344 244 549 356 245 549 minecraft:gold_block
fill 351 244 514 358 245 514 minecraft:gold_block
fill 351 244 548 358 245 548 minecraft:gold_block
fill 356 244 515 360 245 515 minecraft:gold_block
fill 356 244 547 360 245 547 minecraft:gold_block
fill 359 244 516 361 245 516 minecraft:gold_block
fill 359 244 546 361 245 546 minecraft:gold_block
fill 360 244 517 362 245 517 minecraft:gold_block
fill 360 244 545 362 245 545 minecraft:gold_block
fill 361 244 518 363 245 518 minecraft:gold_block
fill 361 244 544 363 245 544 minecraft:gold_block
fill 363 244 519 364 245 520 minecraft:gold_block
fill 363 244 542 364 245 543 minecraft:gold_block
fill 364 244 521 366 245 521 minecraft:gold_block
fill 364 244 541 366 245 541 minecraft:gold_block
fill 365 244 520 365 245 520 minecraft:gold_block
fill 365 244 522 366 245 522 minecraft:gold_block
fill 365 244 540 366 245 540 minecraft:gold_block
fill 365 244 542 365 245 542 minecraft:gold_block
fill 366 244 523 367 245 525 minecraft:gold_block
fill 366 244 537 367 245 539 minecraft:gold_block
fill 367 244 526 368 245 530 minecraft:gold_block
fill 367 244 532 368 245 536 minecraft:gold_block
fill 368 244 525 368 245 525 minecraft:gold_block
fill 368 244 531 368 245 531 minecraft:gold_block
fill 368 244 537 368 245 537 minecraft:gold_block
fill 330 245 514 330 245 519 minecraft:cut_sandstone
fill 330 245 526 330 245 531 minecraft:cut_sandstone
fill 330 245 538 330 245 543 minecraft:cut_sandstone
fill 330 245 550 330 245 551 minecraft:cut_sandstone
fill 331 245 551 334 245 551 minecraft:cut_sandstone
fill 334 245 511 339 245 511 minecraft:cut_sandstone
fill 341 245 551 346 245 551 minecraft:cut_sandstone
fill 346 245 511 351 245 511 minecraft:cut_sandstone
fill 353 245 551 358 245 551 minecraft:cut_sandstone
fill 358 245 511 363 245 511 minecraft:cut_sandstone
fill 365 245 551 370 245 551 minecraft:cut_sandstone
fill 370 245 511 370 245 516 minecraft:cut_sandstone
fill 370 245 523 370 245 528 minecraft:cut_sandstone
fill 370 245 535 370 245 540 minecraft:cut_sandstone
fill 370 245 547 370 245 550 minecraft:cut_sandstone
fill 329 246 516 329 251 519 minecraft:ochre_froglight
fill 329 246 528 329 251 531 minecraft:ochre_froglight
fill 329 246 540 329 251 543 minecraft:ochre_froglight
fill 329 246 552 332 251 552 minecraft:ochre_froglight
setblock 333 246 523 minecraft:ochre_froglight
fill 334 246 521 334 246 522 minecraft:ochre_froglight
setblock 335 246 520 minecraft:ochre_froglight
setblock 335 246 542 minecraft:ochre_froglight
fill 336 246 510 339 251 510 minecraft:ochre_froglight
setblock 336 246 519 minecraft:ochre_froglight
setblock 336 246 543 minecraft:ochre_froglight
setblock 337 246 518 minecraft:ochre_froglight
setblock 337 246 544 minecraft:ochre_froglight
setblock 338 246 517 minecraft:ochre_froglight
setblock 338 246 545 minecraft:ochre_froglight
setblock 339 246 516 minecraft:ochre_froglight
setblock 339 246 546 minecraft:ochre_froglight
fill 340 246 515 341 246 515 minecraft:ochre_froglight
fill 340 246 547 341 246 547 minecraft:ochre_froglight
fill 341 246 552 344 251 552 minecraft:ochre_froglight
fill 342 246 514 343 246 514 minecraft:ochre_froglight
fill 342 246 548 343 246 548 minecraft:ochre_froglight
fill 344 246 513 348 246 513 minecraft:ochre_froglight
fill 344 246 549 348 246 549 minecraft:ochre_froglight
fill 348 246 510 351 251 510 minecraft:ochre_froglight
fill 349 246 512 351 246 512 minecraft:ochre_froglight
fill 349 246 550 351 246 550 minecraft:ochre_froglight
fill 352 246 513 356 246 513 minecraft:ochre_froglight
fill 352 246 549 356 246 549 minecraft:ochre_froglight
fill 353 246 552 356 251 552 minecraft:ochre_froglight
fill 357 246 514 358 246 514 minecraft:ochre_froglight
fill 357 246 548 358 246 548 minecraft:ochre_froglight
fill 359 246 515 360 246 515 minecraft:ochre_froglight
fill 359 246 547 360 246 547 minecraft:ochre_froglight
fill 360 246 510 363 251 510 minecraft:ochre_froglight
setblock 361 246 516 minecraft:ochre_froglight
setblock 361 246 546 minecraft:ochre_froglight
setblock 362 246 517 minecraft:ochre_froglight
setblock 362 246 545 minecraft:ochre_froglight
setblock 363 246 518 minecraft:ochre_froglight
setblock 363 246 544 minecraft:ochre_froglight
setblock 364 246 519 minecraft:ochre_froglight
setblock 364 246 543 minecraft:ochre_froglight
setblock 365 246 520 minecraft:ochre_froglight
setblock 365 246 542 minecraft:ochre_froglight
fill 365 246 552 368 251 552 minecraft:ochre_froglight
fill 366 246 521 366 246 522 minecraft:ochre_froglight
fill 366 246 540 366 246 541 minecraft:ochre_froglight
fill 367 246 523 367 246 524 minecraft:ochre_froglight
fill 367 246 538 367 246 539 minecraft:ochre_froglight
fill 368 246 525 368 246 529 minecraft:ochre_froglight
fill 368 246 533 368 246 537 minecraft:ochre_froglight
fill 369 246 530 369 246 532 minecraft:ochre_froglight
fill 371 246 511 371 251 514 minecraft:ochre_froglight
fill 371 246 523 371 251 526 minecraft:ochre_froglight
fill 371 246 535 371 251 538 minecraft:ochre_froglight
fill 371 246 547 371 251 550 minecraft:ochre_froglight
fill 357 248 535 357 249 536 minecraft:yellow_concrete
setblock 332 249 513 minecraft:light[level=14]
setblock 332 249 521 minecraft:light[level=14]
setblock 332 249 529 minecraft:light[level=14]
setblock 332 249 537 minecraft:light[level=14]
setblock 332 249 545 minecraft:light[level=14]
setblock 340 249 513 minecraft:light[level=14]
setblock 340 249 521 minecraft:light[level=14]
setblock 340 249 529 minecraft:light[level=14]
setblock 340 249 537 minecraft:light[level=14]
setblock 340 249 545 minecraft:light[level=14]
setblock 348 249 513 minecraft:light[level=14]
setblock 348 249 521 minecraft:light[level=14]
setblock 348 249 529 minecraft:light[level=14]
setblock 348 249 537 minecraft:light[level=14]
setblock 348 249 545 minecraft:light[level=14]
setblock 356 249 513 minecraft:light[level=14]
setblock 356 249 521 minecraft:light[level=14]
setblock 356 249 529 minecraft:light[level=14]
setblock 356 249 537 minecraft:light[level=14]
setblock 356 249 545 minecraft:light[level=14]
fill 363 249 522 367 250 526 minecraft:cut_sandstone
setblock 364 249 513 minecraft:light[level=14]
setblock 364 249 521 minecraft:light[level=14]
setblock 364 249 529 minecraft:light[level=14]
setblock 364 249 537 minecraft:light[level=14]
setblock 364 249 545 minecraft:light[level=14]
fill 368 249 524 369 249 524 minecraft:cut_sandstone
fill 364 251 523 366 252 525 minecraft:gold_block
fill 329 252 516 329 265 516 minecraft:sandstone
fill 329 252 517 329 252 518 minecraft:ochre_froglight
fill 329 252 519 329 265 519 minecraft:sandstone
fill 329 252 528 329 265 528 minecraft:sandstone
fill 329 252 529 329 252 530 minecraft:ochre_froglight
fill 329 252 531 329 265 531 minecraft:sandstone
fill 329 252 540 329 265 540 minecraft:sandstone
fill 329 252 541 329 252 542 minecraft:ochre_froglight
fill 329 252 543 329 265 543 minecraft:sandstone
fill 329 252 552 329 265 552 minecraft:sandstone
fill 330 252 552 331 252 552 minecraft:ochre_froglight
fill 332 252 552 332 265 552 minecraft:sandstone
fill 336 252 510 336 265 510 minecraft:sandstone
fill 337 252 510 338 252 510 minecraft:ochre_froglight
fill 339 252 510 339 265 510 minecraft:sandstone
fill 341 252 552 341 265 552 minecraft:sandstone
fill 342 252 552 343 252 552 minecraft:ochre_froglight
fill 344 252 552 344 265 552 minecraft:sandstone
fill 348 252 510 348 265 510 minecraft:sandstone
fill 349 252 510 350 252 510 minecraft:ochre_froglight
fill 351 252 510 351 265 510 minecraft:sandstone
fill 353 252 552 353 265 552 minecraft:sandstone
fill 354 252 552 355 252 552 minecraft:ochre_froglight
fill 356 252 552 356 265 552 minecraft:sandstone
fill 360 252 510 360 265 510 minecraft:sandstone
fill 361 252 510 362 252 510 minecraft:ochre_froglight
fill 363 252 510 363 265 510 minecraft:sandstone
fill 365 252 552 365 265 552 minecraft:sandstone
fill 366 252 552 367 252 552 minecraft:ochre_froglight
fill 368 252 552 368 265 552 minecraft:sandstone
fill 371 252 511 371 265 511 minecraft:sandstone
fill 371 252 512 371 252 513 minecraft:ochre_froglight
fill 371 252 514 371 265 514 minecraft:sandstone
fill 371 252 523 371 265 523 minecraft:sandstone
fill 371 252 524 371 252 525 minecraft:ochre_froglight
fill 371 252 526 371 265 526 minecraft:sandstone
fill 371 252 535 371 265 535 minecraft:sandstone
fill 371 252 536 371 252 537 minecraft:ochre_froglight
fill 371 252 538 371 265 538 minecraft:sandstone
fill 371 252 547 371 265 547 minecraft:sandstone
fill 371 252 548 371 252 549 minecraft:ochre_froglight
fill 371 252 550 371 265 550 minecraft:sandstone
fill 329 253 517 329 265 518 minecraft:sandstone
fill 329 253 529 329 265 530 minecraft:sandstone
fill 329 253 541 329 265 542 minecraft:sandstone
fill 330 253 552 331 265 552 minecraft:sandstone
fill 337 253 510 338 265 510 minecraft:sandstone
fill 340 253 521 340 254 521 minecraft:sandstone
fill 342 253 552 343 265 552 minecraft:sandstone
fill 349 253 510 350 265 510 minecraft:sandstone
fill 354 253 552 355 265 552 minecraft:sandstone
fill 361 253 510 362 265 510 minecraft:sandstone
fill 364 253 524 366 255 524 minecraft:gold_block
fill 365 253 523 365 255 523 minecraft:gold_block
fill 365 253 525 365 255 525 minecraft:gold_block
fill 366 253 552 367 265 552 minecraft:sandstone
fill 371 253 512 371 265 513 minecraft:sandstone
fill 371 253 524 371 265 525 minecraft:sandstone
fill 371 253 536 371 265 537 minecraft:sandstone
fill 371 253 548 371 265 549 minecraft:sandstone
fill 365 256 524 365 260 524 minecraft:gold_block
setblock 332 257 513 minecraft:light[level=14]
setblock 332 257 521 minecraft:light[level=14]
setblock 332 257 529 minecraft:light[level=14]
setblock 332 257 537 minecraft:light[level=14]
setblock 332 257 545 minecraft:light[level=14]
setblock 340 257 513 minecraft:light[level=14]
setblock 340 257 521 minecraft:light[level=14]
setblock 340 257 529 minecraft:light[level=14]
setblock 340 257 537 minecraft:light[level=14]
setblock 340 257 545 minecraft:light[level=14]
setblock 348 257 513 minecraft:light[level=14]
setblock 348 257 521 minecraft:light[level=14]
setblock 348 257 529 minecraft:light[level=14]
setblock 348 257 537 minecraft:light[level=14]
setblock 348 257 545 minecraft:light[level=14]
setblock 356 257 513 minecraft:light[level=14]
setblock 356 257 521 minecraft:light[level=14]
setblock 356 257 529 minecraft:light[level=14]
setblock 356 257 537 minecraft:light[level=14]
setblock 356 257 545 minecraft:light[level=14]
setblock 364 257 513 minecraft:light[level=14]
setblock 364 257 521 minecraft:light[level=14]
setblock 364 257 529 minecraft:light[level=14]
setblock 364 257 537 minecraft:light[level=14]
setblock 364 257 545 minecraft:light[level=14]
fill 352 259 539 353 260 540 minecraft:yellow_concrete
fill 331 260 520 331 265 522 minecraft:gold_block
fill 331 260 532 331 265 534 minecraft:gold_block
fill 331 260 544 331 265 546 minecraft:gold_block
fill 337 260 550 339 265 550 minecraft:gold_block
fill 341 260 512 343 265 512 minecraft:gold_block
fill 349 260 550 351 265 550 minecraft:gold_block
fill 353 260 512 355 265 512 minecraft:gold_block
fill 361 260 550 363 265 550 minecraft:gold_block
fill 365 260 512 367 265 512 minecraft:gold_block
fill 369 260 520 369 265 522 minecraft:gold_block
fill 369 260 532 369 265 534 minecraft:gold_block
fill 369 260 544 369 265 546 minecraft:gold_block
setblock 365 261 524 minecraft:ochre_froglight
fill 360 263 540 361 264 541 minecraft:yellow_concrete
fill 330 265 514 330 265 519 minecraft:cut_sandstone
fill 330 265 526 330 265 531 minecraft:cut_sandstone
fill 330 265 538 330 265 543 minecraft:cut_sandstone
fill 330 265 550 330 265 551 minecraft:cut_sandstone
fill 331 265 551 334 265 551 minecraft:cut_sandstone
setblock 332 265 513 minecraft:light[level=14]
setblock 332 265 521 minecraft:light[level=14]
setblock 332 265 529 minecraft:light[level=14]
setblock 332 265 537 minecraft:light[level=14]
setblock 332 265 545 minecraft:light[level=14]
fill 334 265 511 339 265 511 minecraft:cut_sandstone
setblock 340 265 513 minecraft:light[level=14]
setblock 340 265 521 minecraft:light[level=14]
setblock 340 265 529 minecraft:light[level=14]
setblock 340 265 537 minecraft:light[level=14]
setblock 340 265 545 minecraft:light[level=14]
fill 341 265 551 346 265 551 minecraft:cut_sandstone
fill 346 265 511 351 265 511 minecraft:cut_sandstone
setblock 348 265 513 minecraft:light[level=14]
setblock 348 265 521 minecraft:light[level=14]
setblock 348 265 529 minecraft:light[level=14]
setblock 348 265 537 minecraft:light[level=14]
setblock 348 265 545 minecraft:light[level=14]
fill 353 265 551 358 265 551 minecraft:cut_sandstone
setblock 356 265 513 minecraft:light[level=14]
setblock 356 265 521 minecraft:light[level=14]
setblock 356 265 529 minecraft:light[level=14]
setblock 356 265 537 minecraft:light[level=14]
setblock 356 265 545 minecraft:light[level=14]
fill 358 265 511 363 265 511 minecraft:cut_sandstone
setblock 364 265 513 minecraft:light[level=14]
setblock 364 265 521 minecraft:light[level=14]
setblock 364 265 529 minecraft:light[level=14]
setblock 364 265 537 minecraft:light[level=14]
setblock 364 265 545 minecraft:light[level=14]
fill 365 265 551 370 265 551 minecraft:cut_sandstone
fill 370 265 511 370 265 516 minecraft:cut_sandstone
fill 370 265 523 370 265 528 minecraft:cut_sandstone
fill 370 265 535 370 265 540 minecraft:cut_sandstone
fill 370 265 547 370 265 550 minecraft:cut_sandstone
fill 329 266 516 329 271 519 minecraft:ochre_froglight
fill 329 266 528 329 271 531 minecraft:ochre_froglight
fill 329 266 540 329 271 543 minecraft:ochre_froglight
fill 329 266 552 332 271 552 minecraft:ochre_froglight
fill 336 266 510 339 271 510 minecraft:ochre_froglight
fill 341 266 552 344 271 552 minecraft:ochre_froglight
fill 348 266 510 351 271 510 minecraft:ochre_froglight
fill 353 266 552 356 271 552 minecraft:ochre_froglight
fill 360 266 510 363 271 510 minecraft:ochre_froglight
fill 365 266 552 368 271 552 minecraft:ochre_froglight
fill 371 266 511 371 271 514 minecraft:ochre_froglight
fill 371 266 523 371 271 526 minecraft:ochre_froglight
fill 371 266 535 371 271 538 minecraft:ochre_froglight
fill 371 266 547 371 271 550 minecraft:ochre_froglight
fill 332 270 534 333 271 534 minecraft:yellow_concrete
fill 329 272 516 329 285 516 minecraft:sandstone
fill 329 272 517 329 272 518 minecraft:ochre_froglight
fill 329 272 519 329 285 519 minecraft:sandstone
fill 329 272 528 329 285 528 minecraft:sandstone
fill 329 272 529 329 272 530 minecraft:ochre_froglight
fill 329 272 531 329 285 531 minecraft:sandstone
fill 329 272 540 329 285 540 minecraft:sandstone
fill 329 272 541 329 272 542 minecraft:ochre_froglight
fill 329 272 543 329 285 543 minecraft:sandstone
fill 329 272 552 329 285 552 minecraft:sandstone
fill 330 272 552 331 272 552 minecraft:ochre_froglight
fill 332 272 552 332 285 552 minecraft:sandstone
fill 336 272 510 336 285 510 minecraft:sandstone
fill 337 272 510 338 272 510 minecraft:ochre_froglight
fill 339 272 510 339 285 510 minecraft:sandstone
fill 341 272 552 341 285 552 minecraft:sandstone
fill 342 272 552 343 272 552 minecraft:ochre_froglight
fill 344 272 552 344 285 552 minecraft:sandstone
fill 348 272 510 348 285 510 minecraft:sandstone
fill 349 272 510 350 272 510 minecraft:ochre_froglight
fill 351 272 510 351 285 510 minecraft:sandstone
fill 353 272 552 353 285 552 minecraft:sandstone
fill 354 272 552 355 272 552 minecraft:ochre_froglight
fill 356 272 552 356 285 552 minecraft:sandstone
fill 360 272 510 360 285 510 minecraft:sandstone
fill 361 272 510 362 272 510 minecraft:ochre_froglight
fill 363 272 510 363 285 510 minecraft:sandstone
fill 365 272 552 365 285 552 minecraft:sandstone
fill 366 272 552 367 272 552 minecraft:ochre_froglight
fill 368 272 552 368 285 552 minecraft:sandstone
fill 371 272 511 371 285 511 minecraft:sandstone
fill 371 272 512 371 272 513 minecraft:ochre_froglight
fill 371 272 514 371 285 514 minecraft:sandstone
fill 371 272 523 371 285 523 minecraft:sandstone
fill 371 272 524 371 272 525 minecraft:ochre_froglight
fill 371 272 526 371 285 526 minecraft:sandstone
fill 371 272 535 371 285 535 minecraft:sandstone
fill 371 272 536 371 272 537 minecraft:ochre_froglight
fill 371 272 538 371 285 538 minecraft:sandstone
fill 371 272 547 371 285 547 minecraft:sandstone
fill 371 272 548 371 272 549 minecraft:ochre_froglight
fill 371 272 550 371 285 550 minecraft:sandstone
fill 329 273 517 329 285 518 minecraft:sandstone
fill 329 273 529 329 285 530 minecraft:sandstone
fill 329 273 541 329 285 542 minecraft:sandstone
fill 330 273 552 331 285 552 minecraft:sandstone
setblock 332 273 513 minecraft:light[level=14]
setblock 332 273 521 minecraft:light[level=14]
setblock 332 273 529 minecraft:light[level=14]
setblock 332 273 537 minecraft:light[level=14]
setblock 332 273 545 minecraft:light[level=14]
fill 337 273 510 338 285 510 minecraft:sandstone
setblock 340 273 513 minecraft:light[level=14]
setblock 340 273 521 minecraft:light[level=14]
setblock 340 273 529 minecraft:light[level=14]
setblock 340 273 537 minecraft:light[level=14]
setblock 340 273 545 minecraft:light[level=14]
fill 342 273 552 343 285 552 minecraft:sandstone
setblock 348 273 513 minecraft:light[level=14]
setblock 348 273 521 minecraft:light[level=14]
setblock 348 273 529 minecraft:light[level=14]
setblock 348 273 537 minecraft:light[level=14]
setblock 348 273 545 minecraft:light[level=14]
fill 349 273 510 350 285 510 minecraft:sandstone
fill 354 273 552 355 285 552 minecraft:sandstone
setblock 356 273 513 minecraft:light[level=14]
setblock 356 273 521 minecraft:light[level=14]
setblock 356 273 529 minecraft:light[level=14]
setblock 356 273 537 minecraft:light[level=14]
setblock 356 273 545 minecraft:light[level=14]
fill 361 273 510 362 285 510 minecraft:sandstone
setblock 364 273 513 minecraft:light[level=14]
setblock 364 273 521 minecraft:light[level=14]
setblock 364 273 529 minecraft:light[level=14]
setblock 364 273 537 minecraft:light[level=14]
setblock 364 273 545 minecraft:light[level=14]
fill 366 273 552 367 285 552 minecraft:sandstone
fill 371 273 512 371 285 513 minecraft:sandstone
fill 371 273 524 371 285 525 minecraft:sandstone
fill 371 273 536 371 285 537 minecraft:sandstone
fill 371 273 548 371 285 549 minecraft:sandstone
fill 335 279 532 346 279 536 minecraft:gold_block
fill 336 279 529 362 279 531 minecraft:gold_block
fill 336 279 537 362 279 539 minecraft:gold_block
fill 337 279 527 361 279 528 minecraft:gold_block
fill 337 279 540 361 279 541 minecraft:gold_block
fill 338 279 526 360 279 526 minecraft:gold_block
fill 338 279 542 360 279 542 minecraft:gold_block
fill 339 279 524 359 279 525 minecraft:gold_block
fill 339 279 543 359 279 544 minecraft:gold_block
fill 341 279 523 357 279 523 minecraft:gold_block
fill 341 279 545 357 279 545 minecraft:gold_block
fill 342 279 522 356 280 522 minecraft:gold_block
fill 342 279 546 356 280 546 minecraft:gold_block
fill 344 279 521 354 280 521 minecraft:gold_block
fill 344 279 547 354 280 547 minecraft:gold_block
fill 347 279 520 351 280 520 minecraft:gold_block
fill 347 279 532 347 279 533 minecraft:gold_block
fill 347 279 535 347 279 536 minecraft:gold_block
fill 347 279 548 351 280 548 minecraft:gold_block
setblock 348 279 532 minecraft:gold_block
setblock 348 279 536 minecraft:gold_block
fill 350 279 532 363 279 532 minecraft:gold_block
fill 350 279 536 363 279 536 minecraft:gold_block
fill 351 279 533 363 279 533 minecraft:gold_block
fill 351 279 535 363 279 535 minecraft:gold_block
fill 352 279 534 363 279 534 minecraft:gold_block
fill 330 280 511 334 280 551 minecraft:smooth_sandstone
fill 335 280 511 335 280 531 minecraft:smooth_sandstone
fill 335 280 532 337 280 536 minecraft:gold_block
fill 335 280 537 335 280 551 minecraft:smooth_sandstone
fill 336 280 511 336 280 528 minecraft:smooth_sandstone
fill 336 280 529 338 280 531 minecraft:gold_block
fill 336 280 537 338 280 539 minecraft:gold_block
fill 336 280 540 336 280 551 minecraft:smooth_sandstone
fill 337 280 511 337 280 526 minecraft:smooth_sandstone
fill 337 280 527 339 280 528 minecraft:gold_block
fill 337 280 540 339 280 541 minecraft:gold_block
fill 337 280 542 337 280 551 minecraft:smooth_sandstone
fill 338 280 511 338 280 525 minecraft:smooth_sandstone
fill 338 280 526 341 280 526 minecraft:gold_block
fill 338 280 532 338 280 533 minecraft:gold_block
fill 338 280 534 345 280 534 minecraft:sandstone
fill 338 280 535 338 280 536 minecraft:gold_block
fill 338 280 542 341 280 542 minecraft:gold_block
fill 338 280 543 338 280 551 minecraft:smooth_sandstone
fill 339 280 511 340 280 523 minecraft:smooth_sandstone
fill 339 280 524 342 280 525 minecraft:gold_block
setblock 339 280 529 minecraft:gold_block
fill 339 280 530 345 280 533 minecraft:sandstone
fill 339 280 535 345 280 538 minecraft:sandstone
setblock 339 280 539 minecraft:gold_block
fill 339 280 543 342 280 544 minecraft:gold_block
fill 339 280 545 340 280 551 minecraft:smooth_sandstone
setblock 340 280 527 minecraft:gold_block
fill 340 280 528 358 280 529 minecraft:sandstone
fill 340 280 539 358 280 540 minecraft:sandstone
setblock 340 280 541 minecraft:gold_block
fill 341 280 511 341 280 522 minecraft:smooth_sandstone
fill 341 280 523 348 280 523 minecraft:gold_block
fill 341 280 527 357 280 527 minecraft:sandstone
fill 341 280 541 357 280 541 minecraft:sandstone
fill 341 280 545 348 280 545 minecraft:gold_block
fill 341 280 546 341 280 551 minecraft:smooth_sandstone
fill 342 280 511 343 280 521 minecraft:smooth_sandstone
fill 342 280 526 356 280 526 minecraft:sandstone
fill 342 280 542 356 280 542 minecraft:sandstone
fill 342 280 547 343 280 551 minecraft:smooth_sandstone
fill 343 280 524 344 280 524 minecraft:gold_block
fill 343 280 525 355 280 525 minecraft:sandstone
fill 343 280 543 355 280 543 minecraft:sandstone
fill 343 280 544 344 280 544 minecraft:gold_block
fill 344 280 511 346 280 520 minecraft:smooth_sandstone
fill 344 280 548 346 280 551 minecraft:smooth_sandstone
fill 345 280 524 353 280 524 minecraft:sandstone
fill 345 280 544 353 280 544 minecraft:sandstone
fill 346 280 530 346 280 532 minecraft:sandstone
fill 346 280 533 346 280 535 minecraft:ochre_froglight
fill 346 280 536 346 280 538 minecraft:sandstone
fill 347 280 511 370 280 519 minecraft:smooth_sandstone
fill 347 280 530 347 280 531 minecraft:sandstone
fill 347 280 532 347 280 533 minecraft:ochre_froglight
fill 347 280 535 347 280 536 minecraft:ochre_froglight
fill 347 280 537 347 280 538 minecraft:sandstone
fill 347 280 549 370 280 551 minecraft:smooth_sandstone
fill 348 280 530 359 280 530 minecraft:sandstone
fill 348 280 531 348 280 532 minecraft:ochre_froglight
fill 348 280 536 348 280 537 minecraft:ochre_froglight
fill 348 280 538 359 280 538 minecraft:sandstone
setblock 349 280 523 minecraft:sandstone
fill 349 280 531 350 280 531 minecraft:ochre_froglight
fill 349 280 537 350 280 537 minecraft:ochre_froglight
setblock 349 280 545 minecraft:sandstone
fill 350 280 523 357 280 523 minecraft:gold_block
fill 350 280 532 351 280 532 minecraft:ochre_froglight
fill 350 280 536 351 280 536 minecraft:ochre_froglight
fill 350 280 545 357 280 545 minecraft:gold_block
fill 351 280 531 359 280 531 minecraft:sandstone
fill 351 280 533 352 280 533 minecraft:ochre_froglight
fill 351 280 535 352 280 535 minecraft:ochre_froglight
fill 351 280 537 359 280 537 minecraft:sandstone
fill 352 280 520 370 280 520 minecraft:smooth_sandstone
fill 352 280 532 359 280 532 minecraft:sandstone
setblock 352 280 534 minecraft:ochre_froglight
fill 352 280 536 359 280 536 minecraft:sandstone
fill 352 280 548 370 280 548 minecraft:smooth_sandstone
fill 353 280 533 359 280 535 minecraft:sandstone
fill 354 280 524 359 280 524 minecraft:gold_block
fill 354 280 544 359 280 544 minecraft:gold_block
fill 355 280 521 370 280 521 minecraft:smooth_sandstone
fill 355 280 547 370 280 547 minecraft:smooth_sandstone
fill 356 280 525 359 280 525 minecraft:gold_block
fill 356 280 543 359 280 543 minecraft:gold_block
fill 357 280 522 370 280 522 minecraft:smooth_sandstone
fill 357 280 526 360 280 526 minecraft:gold_block
fill 357 280 542 360 280 542 minecraft:gold_block
fill 357 280 546 370 280 546 minecraft:smooth_sandstone
fill 358 280 523 370 280 523 minecraft:smooth_sandstone
fill 358 280 527 361 280 527 minecraft:gold_block
fill 358 280 541 361 280 541 minecraft:gold_block
fill 358 280 545 370 280 545 minecraft:smooth_sandstone
fill 359 280 528 361 280 529 minecraft:gold_block
fill 359 280 539 361 280 540 minecraft:gold_block
fill 360 280 524 370 280 525 minecraft:smooth_sandstone
fill 360 280 530 362 280 533 minecraft:gold_block
setblock 360 280 534 minecraft:sandstone
fill 360 280 535 362 280 538 minecraft:gold_block
fill 360 280 543 370 280 544 minecraft:smooth_sandstone
fill 361 280 526 370 280 526 minecraft:smooth_sandstone
fill 361 280 534 363 280 534 minecraft:gold_block
fill 361 280 542 370 280 542 minecraft:smooth_sandstone
fill 362 280 527 370 280 528 minecraft:smooth_sandstone
setblock 362 280 529 minecraft:gold_block
setblock 362 280 539 minecraft:gold_block
fill 362 280 540 370 280 541 minecraft:smooth_sandstone
fill 363 280 529 370 280 531 minecraft:smooth_sandstone
fill 363 280 532 363 280 533 minecraft:gold_block
fill 363 280 535 363 280 536 minecraft:gold_block
fill 363 280 537 370 280 539 minecraft:smooth_sandstone
fill 364 280 532 370 280 536 minecraft:smooth_sandstone
setblock 332 281 513 minecraft:light[level=14]
setblock 332 281 521 minecraft:light[level=14]
setblock 332 281 529 minecraft:light[level=14]
setblock 332 281 537 minecraft:light[level=14]
setblock 332 281 545 minecraft:light[level=14]
setblock 340 281 513 minecraft:light[level=14]
setblock 340 281 521 minecraft:light[level=14]
setblock 340 281 529 minecraft:light[level=14]
setblock 340 281 537 minecraft:light[level=14]
setblock 340 281 545 minecraft:light[level=14]
fill 345 281 534 346 281 534 minecraft:glass
fill 346 281 532 346 281 533 minecraft:glass
fill 346 281 535 346 281 536 minecraft:glass
fill 347 281 531 347 281 532 minecraft:glass
fill 347 281 536 347 281 537 minecraft:glass
setblock 348 281 513 minecraft:light[level=14]
setblock 348 281 521 minecraft:light[level=14]
setblock 348 281 529 minecraft:light[level=14]
fill 348 281 531 351 281 531 minecraft:glass
fill 348 281 537 351 281 537 minecraft:glass
setblock 348 281 545 minecraft:light[level=14]
setblock 349 281 530 minecraft:glass
setblock 349 281 538 minecraft:glass
fill 351 281 532 352 281 532 minecraft:glass
fill 351 281 536 352 281 536 minecraft:glass
fill 352 281 533 352 281 535 minecraft:glass
setblock 353 281 534 minecraft:glass
setblock 356 281 513 minecraft:light[level=14]
setblock 356 281 521 minecraft:light[level=14]
setblock 356 281 529 minecraft:light[level=14]
setblock 356 281 537 minecraft:light[level=14]
setblock 356 281 545 minecraft:light[level=14]
setblock 364 281 513 minecraft:light[level=14]
setblock 364 281 521 minecraft:light[level=14]
setblock 364 281 529 minecraft:light[level=14]
setblock 364 281 537 minecraft:light[level=14]
setblock 364 281 545 minecraft:light[level=14]
fill 344 282 532 344 282 536 minecraft:glass
fill 345 282 531 345 282 532 minecraft:glass
fill 345 282 536 345 282 537 minecraft:glass
fill 346 282 530 346 282 531 minecraft:glass
fill 346 282 537 346 282 538 minecraft:glass
fill 347 282 529 347 282 530 minecraft:glass
fill 347 282 538 347 282 539 minecraft:glass
fill 348 282 529 351 282 529 minecraft:glass
fill 348 282 539 351 282 539 minecraft:glass
fill 351 282 530 352 282 530 minecraft:glass
fill 351 282 538 352 282 538 minecraft:glass
fill 352 282 531 353 282 531 minecraft:glass
fill 352 282 537 353 282 537 minecraft:glass
fill 353 282 532 354 282 532 minecraft:glass
fill 353 282 536 354 282 536 minecraft:glass
fill 354 282 533 354 282 535 minecraft:glass
fill 343 283 531 343 283 537 minecraft:glass
fill 344 283 530 344 283 531 minecraft:glass
fill 344 283 537 344 283 538 minecraft:glass
fill 345 283 529 345 283 530 minecraft:glass
fill 345 283 538 345 283 539 minecraft:glass
fill 346 283 528 346 283 529 minecraft:glass
fill 346 283 539 346 283 540 minecraft:glass
fill 347 283 528 352 283 528 minecraft:glass
fill 347 283 540 352 283 540 minecraft:glass
fill 352 283 529 353 283 529 minecraft:glass
fill 352 283 539 353 283 539 minecraft:glass
fill 353 283 530 354 283 530 minecraft:glass
fill 353 283 538 354 283 538 minecraft:glass
fill 354 283 531 355 283 531 minecraft:glass
fill 354 283 537 355 283 537 minecraft:glass
fill 355 283 532 355 283 536 minecraft:glass
fill 330 284 511 332 300 511 minecraft:gold_block
fill 330 284 521 330 300 523 minecraft:gold_block
fill 330 284 533 330 300 535 minecraft:gold_block
fill 330 284 545 330 300 547 minecraft:gold_block
fill 331 284 520 331 285 522 minecraft:gold_block
fill 331 284 532 331 285 534 minecraft:gold_block
fill 331 284 544 331 285 546 minecraft:gold_block
fill 336 284 551 338 300 551 minecraft:gold_block
fill 337 284 550 339 285 550 minecraft:gold_block
fill 341 284 512 343 285 512 minecraft:gold_block
fill 341 284 520 341 285 520 minecraft:sandstone
fill 341 284 532 341 284 536 minecraft:glass
fill 342 284 511 344 300 511 minecraft:gold_block
fill 342 284 530 342 284 532 minecraft:glass
fill 342 284 536 342 284 538 minecraft:glass
fill 343 284 529 343 284 530 minecraft:glass
fill 343 284 538 343 284 539 minecraft:glass
fill 344 284 528 345 284 528 minecraft:glass
fill 344 284 540 345 284 540 minecraft:glass
fill 345 284 527 347 284 527 minecraft:glass
fill 345 284 541 347 284 541 minecraft:glass
fill 347 284 526 351 284 526 minecraft:glass
fill 347 284 542 351 284 542 minecraft:glass
fill 348 284 551 350 300 551 minecraft:gold_block
fill 349 284 550 351 285 550 minecraft:gold_block
fill 351 284 527 353 284 527 minecraft:glass
fill 351 284 541 353 284 541 minecraft:glass
fill 353 284 512 355 285 512 minecraft:gold_block
fill 353 284 528 354 284 528 minecraft:glass
fill 353 284 540 354 284 540 minecraft:glass
fill 354 284 511 356 300 511 minecraft:gold_block
fill 355 284 529 355 284 530 minecraft:glass
fill 355 284 538 355 284 539 minecraft:glass
fill 356 284 530 356 284 532 minecraft:glass
fill 356 284 536 356 284 538 minecraft:glass
fill 357 284 532 357 284 536 minecraft:glass
fill 360 284 551 362 300 551 minecraft:gold_block
fill 361 284 550 363 285 550 minecraft:gold_block
fill 365 284 512 367 285 512 minecraft:gold_block
fill 366 284 511 368 300 511 minecraft:gold_block
fill 369 284 520 369 285 522 minecraft:gold_block
fill 369 284 532 369 285 534 minecraft:gold_block
fill 369 284 544 369 285 546 minecraft:gold_block
fill 370 284 519 370 300 521 minecraft:gold_block
fill 370 284 531 370 300 533 minecraft:gold_block
fill 370 284 543 370 300 545 minecraft:gold_block
fill 330 285 514 330 285 519 minecraft:cut_sandstone
fill 330 285 526 330 285 531 minecraft:cut_sandstone
fill 330 285 538 330 285 543 minecraft:cut_sandstone
fill 330 285 550 330 285 551 minecraft:cut_sandstone
fill 331 285 551 334 285 551 minecraft:cut_sandstone
fill 334 285 511 339 285 511 minecraft:cut_sandstone
fill 340 285 531 340 285 537 minecraft:glass
fill 341 285 529 341 285 531 minecraft:glass
fill 341 285 537 341 285 539 minecraft:glass
fill 341 285 551 346 285 551 minecraft:cut_sandstone
fill 342 285 528 342 285 529 minecraft:glass
fill 342 285 539 342 285 540 minecraft:glass
fill 343 285 527 344 285 527 minecraft:glass
fill 343 285 541 344 285 541 minecraft:glass
fill 344 285 526 346 285 526 minecraft:glass
fill 344 285 542 346 285 542 minecraft:glass
fill 346 285 511 351 285 511 minecraft:cut_sandstone
fill 346 285 525 352 285 525 minecraft:glass
fill 346 285 543 352 285 543 minecraft:glass
fill 352 285 526 354 285 526 minecraft:glass
fill 352 285 542 354 285 542 minecraft:glass
fill 353 285 551 358 285 551 minecraft:cut_sandstone
fill 354 285 527 355 285 527 minecraft:glass
fill 354 285 541 355 285 541 minecraft:glass
fill 356 285 528 356 285 529 minecraft:glass
fill 356 285 539 356 285 540 minecraft:glass
fill 357 285 529 357 285 531 minecraft:glass
fill 357 285 537 357 285 539 minecraft:glass
fill 358 285 511 363 285 511 minecraft:cut_sandstone
fill 358 285 531 358 285 537 minecraft:glass
fill 362 285 543 362 286 545 minecraft:yellow_concrete
fill 363 285 543 363 286 544 minecraft:yellow_concrete
fill 365 285 551 370 285 551 minecraft:cut_sandstone
fill 370 285 511 370 285 516 minecraft:cut_sandstone
fill 370 285 523 370 285 528 minecraft:cut_sandstone
fill 370 285 535 370 285 540 minecraft:cut_sandstone
fill 370 285 547 370 285 550 minecraft:cut_sandstone
fill 329 286 516 329 291 519 minecraft:ochre_froglight
fill 329 286 528 329 291 531 minecraft:ochre_froglight
fill 329 286 540 329 291 543 minecraft:ochre_froglight
fill 329 286 552 332 291 552 minecraft:ochre_froglight
fill 336 286 510 339 291 510 minecraft:ochre_froglight
fill 338 286 532 339 286 536 minecraft:glass
fill 339 286 529 339 286 531 minecraft:glass
fill 339 286 537 339 286 539 minecraft:glass
fill 340 286 528 340 286 529 minecraft:glass
fill 340 286 539 340 286 540 minecraft:glass
fill 341 286 527 341 286 528 minecraft:glass
fill 341 286 540 341 286 541 minecraft:glass
fill 341 286 552 344 291 552 minecraft:ochre_froglight
fill 342 286 526 343 286 526 minecraft:glass
fill 342 286 542 343 286 542 minecraft:glass
fill 343 286 525 344 286 525 minecraft:glass
fill 343 286 543 344 286 543 minecraft:glass
fill 344 286 524 354 286 524 minecraft:glass
fill 344 286 544 354 286 544 minecraft:glass
fill 347 286 523 351 286 523 minecraft:glass
fill 347 286 545 351 286 545 minecraft:glass
fill 348 286 510 351 291 510 minecraft:ochre_froglight
fill 353 286 552 356 291 552 minecraft:ochre_froglight
fill 354 286 525 355 286 525 minecraft:glass
fill 354 286 543 355 286 543 minecraft:glass
fill 355 286 526 356 286 526 minecraft:glass
fill 355 286 542 356 286 542 minecraft:glass
fill 357 286 527 357 286 528 minecraft:glass
fill 357 286 540 357 286 541 minecraft:glass
fill 358 286 528 358 286 529 minecraft:glass
fill 358 286 539 358 286 540 minecraft:glass
fill 359 286 529 359 286 539 minecraft:glass
fill 360 286 510 363 291 510 minecraft:ochre_froglight
fill 360 286 532 360 286 536 minecraft:glass
fill 365 286 552 368 291 552 minecraft:ochre_froglight
fill 371 286 511 371 291 514 minecraft:ochre_froglight
fill 371 286 523 371 291 526 minecraft:ochre_froglight
fill 371 286 535 371 291 538 minecraft:ochre_froglight
fill 371 286 547 371 291 550 minecraft:ochre_froglight
fill 337 287 530 337 287 538 minecraft:glass
fill 338 287 528 338 287 530 minecraft:glass
fill 338 287 538 338 287 540 minecraft:glass
fill 339 287 527 339 287 528 minecraft:glass
fill 339 287 540 339 287 541 minecraft:glass
setblock 340 287 526 minecraft:glass
setblock 340 287 542 minecraft:glass
setblock 341 287 525 minecraft:glass
setblock 341 287 543 minecraft:glass
fill 342 287 524 343 287 524 minecraft:glass
fill 342 287 544 343 287 544 minecraft:glass
fill 343 287 523 345 287 523 minecraft:glass
fill 343 287 545 345 287 545 minecraft:glass
fill 345 287 522 353 287 522 minecraft:glass
fill 345 287 546 353 287 546 minecraft:glass
fill 353 287 523 355 287 523 minecraft:glass
fill 353 287 545 355 287 545 minecraft:glass
fill 355 287 524 356 287 524 minecraft:glass
fill 355 287 544 356 287 544 minecraft:glass
setblock 357 287 525 minecraft:glass
setblock 357 287 543 minecraft:glass
setblock 358 287 526 minecraft:glass
setblock 358 287 542 minecraft:glass
fill 359 287 527 359 287 528 minecraft:glass
fill 359 287 540 359 287 541 minecraft:glass
fill 360 287 528 360 287 530 minecraft:glass
fill 360 287 538 360 287 540 minecraft:glass
fill 361 287 530 361 287 538 minecraft:glass
fill 335 288 532 336 288 536 minecraft:glass
fill 336 288 529 336 288 531 minecraft:glass
fill 336 288 537 336 288 539 minecraft:glass
fill 337 288 527 337 288 529 minecraft:glass
fill 337 288 539 337 288 541 minecraft:glass
fill 338 288 526 338 288 527 minecraft:glass
fill 338 288 541 338 288 542 minecraft:glass
fill 339 288 524 339 288 525 minecraft:glass
fill 339 288 543 339 288 544 minecraft:glass
setblock 340 288 524 minecraft:glass
setblock 340 288 544 minecraft:glass
fill 341 288 523 342 288 523 minecraft:glass
fill 341 288 545 342 288 545 minecraft:glass
fill 342 288 522 344 288 522 minecraft:glass
fill 342 288 546 344 288 546 minecraft:glass
fill 344 288 521 354 288 521 minecraft:glass
fill 344 288 547 354 288 547 minecraft:glass
fill 347 288 520 351 288 520 minecraft:glass
fill 347 288 548 351 288 548 minecraft:glass
fill 354 288 522 356 288 522 minecraft:glass
fill 354 288 523 355 288 523 minecraft:yellow_concrete
fill 354 288 546 356 288 546 minecraft:glass
fill 356 288 523 357 288 523 minecraft:glass
fill 356 288 545 357 288 545 minecraft:glass
fill 358 288 524 359 288 524 minecraft:glass
fill 358 288 544 359 288 544 minecraft:glass
setblock 359 288 525 minecraft:glass
setblock 359 288 543 minecraft:glass
fill 360 288 526 360 288 527 minecraft:glass
fill 360 288 541 360 288 542 minecraft:glass
fill 361 288 527 361 288 529 minecraft:glass
fill 361 288 539 361 288 541 minecraft:glass
fill 362 288 529 362 288 539 minecraft:glass
fill 363 288 532 363 288 536 minecraft:glass
setblock 332 289 513 minecraft:light[level=14]
setblock 332 289 521 minecraft:light[level=14]
setblock 332 289 529 minecraft:light[level=14]
setblock 332 289 537 minecraft:light[level=14]
setblock 332 289 545 minecraft:light[level=14]
fill 335 289 532 336 290 536 minecraft:gold_block
fill 336 289 529 336 290 531 minecraft:gold_block
fill 336 289 537 336 290 539 minecraft:gold_block
fill 337 289 527 337 290 530 minecraft:gold_block
fill 337 289 538 337 290 541 minecraft:gold_block
fill 338 289 526 338 290 528 minecraft:gold_block
fill 338 289 540 338 290 542 minecraft:gold_block
fill 339 289 524 339 290 526 minecraft:gold_block
fill 339 289 542 339 290 544 minecraft:gold_block
setblock 340 289 513 minecraft:light[level=14]
setblock 340 289 521 minecraft:light[level=14]
fill 340 289 524 340 290 525 minecraft:gold_block
setblock 340 289 529 minecraft:light[level=14]
setblock 340 289 537 minecraft:light[level=14]
fill 340 289 543 340 290 544 minecraft:gold_block
setblock 340 289 545 minecraft:light[level=14]
fill 341 289 523 341 290 524 minecraft:gold_block
fill 341 289 544 341 290 545 minecraft:gold_block
fill 342 289 522 343 290 523 minecraft:gold_block
fill 342 289 545 343 290 546 minecraft:gold_block
fill 344 289 521 345 290 522 minecraft:gold_block
fill 344 289 546 345 290 547 minecraft:gold_block
fill 346 289 521 354 290 521 minecraft:gold_block
fill 346 289 547 354 290 547 minecraft:gold_block
fill 347 289 520 351 290 520 minecraft:gold_block
fill 347 289 548 351 290 548 minecraft:gold_block
setblock 348 289 513 minecraft:light[level=14]
setblock 348 289 529 minecraft:light[level=14]
setblock 348 289 537 minecraft:light[level=14]
setblock 348 289 545 minecraft:light[level=14]
fill 353 289 522 356 290 522 minecraft:gold_block
fill 353 289 546 356 290 546 minecraft:gold_block
setblock 354 289 523 minecraft:yellow_concrete
fill 355 289 523 357 290 523 minecraft:gold_block
fill 355 289 545 357 290 545 minecraft:gold_block
setblock 356 289 513 minecraft:light[level=14]
setblock 356 289 521 minecraft:light[level=14]
setblock 356 289 529 minecraft:light[level=14]
setblock 356 289 537 minecraft:light[level=14]
fill 357 289 524 359 290 524 minecraft:gold_block
fill 357 289 544 359 290 544 minecraft:gold_block
fill 358 289 525 359 290 525 minecraft:gold_block
fill 358 289 543 359 290 543 minecraft:gold_block
fill 359 289 526 360 290 526 minecraft:gold_block
fill 359 289 542 360 290 542 minecraft:gold_block
fill 360 289 527 361 290 528 minecraft:gold_block
fill 360 289 540 361 290 541 minecraft:gold_block
fill 361 289 529 362 290 530 minecraft:gold_block
fill 361 289 538 362 290 539 minecraft:gold_block
fill 362 289 531 362 290 537 minecraft:gold_block
fill 363 289 532 363 290 536 minecraft:gold_block
setblock 364 289 513 minecraft:light[level=14]
setblock 364 289 521 minecraft:light[level=14]
setblock 364 289 529 minecraft:light[level=14]
setblock 364 289 537 minecraft:light[level=14]
setblock 364 289 545 minecraft:light[level=14]
fill 329 292 516 329 307 516 minecraft:sandstone
fill 329 292 517 329 292 518 minecraft:ochre_froglight
fill 329 292 519 329 307 519 minecraft:sandstone
fill 329 292 528 329 307 528 minecraft:sandstone
fill 329 292 529 329 292 530 minecraft:ochre_froglight
fill 329 292 531 329 307 531 minecraft:sandstone
fill 329 292 540 329 307 540 minecraft:sandstone
fill 329 292 541 329 292 542 minecraft:ochre_froglight
fill 329 292 543 329 307 543 minecraft:sandstone
fill 329 292 552 329 307 552 minecraft:sandstone
fill 330 292 552 331 292 552 minecraft:ochre_froglight
fill 332 292 552 332 307 552 minecraft:sandstone
fill 336 292 510 336 307 510 minecraft:sandstone
fill 337 292 510 338 292 510 minecraft:ochre_froglight
fill 339 292 510 339 307 510 minecraft:sandstone
fill 341 292 552 341 307 552 minecraft:sandstone
fill 342 292 552 343 292 552 minecraft:ochre_froglight
fill 344 292 552 344 307 552 minecraft:sandstone
fill 348 292 510 348 307 510 minecraft:sandstone
fill 349 292 510 350 292 510 minecraft:ochre_froglight
fill 351 292 510 351 307 510 minecraft:sandstone
fill 353 292 552 353 307 552 minecraft:sandstone
fill 354 292 552 355 292 552 minecraft:ochre_froglight
fill 356 292 552 356 307 552 minecraft:sandstone
fill 360 292 510 360 307 510 minecraft:sandstone
fill 361 292 510 362 292 510 minecraft:ochre_froglight
fill 363 292 510 363 307 510 minecraft:sandstone
fill 365 292 552 365 307 552 minecraft:sandstone
fill 366 292 552 367 292 552 minecraft:ochre_froglight
fill 368 292 552 368 307 552 minecraft:sandstone
fill 371 292 511 371 307 511 minecraft:sandstone
fill 371 292 512 371 292 513 minecraft:ochre_froglight
fill 371 292 514 371 307 514 minecraft:sandstone
fill 371 292 523 371 307 523 minecraft:sandstone
fill 371 292 524 371 292 525 minecraft:ochre_froglight
fill 371 292 526 371 307 526 minecraft:sandstone
fill 371 292 535 371 307 535 minecraft:sandstone
fill 371 292 536 371 292 537 minecraft:ochre_froglight
fill 371 292 538 371 307 538 minecraft:sandstone
fill 371 292 547 371 307 547 minecraft:sandstone
fill 371 292 548 371 292 549 minecraft:ochre_froglight
fill 371 292 550 371 307 550 minecraft:sandstone
fill 329 293 517 329 307 518 minecraft:sandstone
fill 329 293 529 329 307 530 minecraft:sandstone
fill 329 293 541 329 307 542 minecraft:sandstone
fill 330 293 552 331 307 552 minecraft:sandstone
fill 337 293 510 338 307 510 minecraft:sandstone
fill 342 293 552 343 307 552 minecraft:sandstone
fill 349 293 510 350 307 510 minecraft:sandstone
fill 354 293 552 355 307 552 minecraft:sandstone
fill 361 293 510 362 307 510 minecraft:sandstone
fill 366 293 552 367 307 552 minecraft:sandstone
fill 371 293 512 371 307 513 minecraft:sandstone
fill 371 293 524 371 307 525 minecraft:sandstone
fill 371 293 536 371 307 537 minecraft:sandstone
fill 371 293 548 371 307 549 minecraft:sandstone
setblock 332 297 513 minecraft:light[level=14]
setblock 332 297 521 minecraft:light[level=14]
setblock 332 297 529 minecraft:light[level=14]
setblock 332 297 537 minecraft:light[level=14]
setblock 332 297 545 minecraft:light[level=14]
setblock 340 297 513 minecraft:light[level=14]
setblock 340 297 521 minecraft:light[level=14]
setblock 340 297 529 minecraft:light[level=14]
setblock 340 297 537 minecraft:light[level=14]
setblock 340 297 545 minecraft:light[level=14]
setblock 348 297 513 minecraft:light[level=14]
setblock 348 297 521 minecraft:light[level=14]
setblock 348 297 529 minecraft:light[level=14]
setblock 348 297 537 minecraft:light[level=14]
setblock 348 297 545 minecraft:light[level=14]
setblock 356 297 513 minecraft:light[level=14]
setblock 356 297 521 minecraft:light[level=14]
setblock 356 297 529 minecraft:light[level=14]
setblock 356 297 537 minecraft:light[level=14]
setblock 356 297 545 minecraft:light[level=14]
setblock 364 297 513 minecraft:light[level=14]
setblock 364 297 521 minecraft:light[level=14]
setblock 364 297 529 minecraft:light[level=14]
setblock 364 297 537 minecraft:light[level=14]
setblock 364 297 545 minecraft:light[level=14]
fill 331 300 520 331 300 522 minecraft:gold_block
fill 331 300 532 331 300 534 minecraft:gold_block
fill 331 300 544 331 300 546 minecraft:gold_block
fill 337 300 550 339 300 550 minecraft:gold_block
fill 341 300 512 343 300 512 minecraft:gold_block
fill 349 300 550 351 300 550 minecraft:gold_block
fill 353 300 512 355 300 512 minecraft:gold_block
fill 361 300 550 363 300 550 minecraft:gold_block
fill 365 300 512 367 300 512 minecraft:gold_block
fill 369 300 520 369 300 522 minecraft:gold_block
fill 369 300 532 369 300 534 minecraft:gold_block
fill 369 300 544 369 300 546 minecraft:gold_block
