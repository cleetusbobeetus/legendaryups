fill 493 248 451 493 254 453 minecraft:red_nether_bricks
fill 496 248 416 496 253 416 minecraft:netherrack
fill 496 248 458 497 249 458 minecraft:orange_concrete
fill 497 248 416 498 248 416 minecraft:orange_concrete
setblock 497 248 419 minecraft:light[level=14]
setblock 497 248 427 minecraft:light[level=14]
setblock 497 248 435 minecraft:light[level=14]
setblock 497 248 443 minecraft:light[level=14]
setblock 497 248 451 minecraft:light[level=14]
fill 498 248 458 499 253 458 minecraft:netherrack
fill 499 248 416 499 253 416 minecraft:netherrack
fill 501 248 416 501 249 416 minecraft:orange_concrete
setblock 505 248 419 minecraft:light[level=14]
setblock 505 248 427 minecraft:light[level=14]
setblock 505 248 435 minecraft:light[level=14]
setblock 505 248 443 minecraft:light[level=14]
setblock 505 248 451 minecraft:light[level=14]
fill 507 248 416 508 253 416 minecraft:netherrack
fill 508 248 458 509 248 458 minecraft:orange_concrete
fill 509 248 416 510 249 416 minecraft:orange_concrete
fill 510 248 458 511 253 458 minecraft:netherrack
setblock 512 248 422 minecraft:orange_concrete
fill 512 248 423 512 253 424 minecraft:netherrack
fill 512 248 425 512 249 426 minecraft:orange_concrete
fill 512 248 431 512 253 432 minecraft:netherrack
fill 512 248 433 512 248 434 minecraft:orange_concrete
fill 512 248 435 512 253 435 minecraft:netherrack
fill 512 248 443 512 253 444 minecraft:netherrack
fill 512 248 445 512 249 446 minecraft:orange_concrete
fill 512 248 452 512 253 452 minecraft:netherrack
setblock 512 248 454 minecraft:orange_concrete
fill 512 248 455 512 253 456 minecraft:netherrack
fill 512 248 457 512 249 457 minecraft:orange_concrete
setblock 470 249 420 minecraft:orange_concrete
fill 470 249 424 470 252 425 minecraft:netherrack
setblock 470 249 441 minecraft:orange_concrete
setblock 470 249 444 minecraft:orange_concrete
fill 470 249 445 470 252 445 minecraft:netherrack
fill 470 249 456 470 252 456 minecraft:netherrack
fill 472 249 458 472 251 458 minecraft:netherrack
setblock 473 249 458 minecraft:orange_concrete
fill 477 249 416 477 252 416 minecraft:netherrack
setblock 478 249 416 minecraft:orange_concrete
setblock 481 249 416 minecraft:orange_concrete
setblock 484 249 458 minecraft:orange_concrete
setblock 488 249 453 minecraft:red_nether_bricks
setblock 488 249 458 minecraft:orange_concrete
fill 489 249 458 489 252 458 minecraft:netherrack
fill 492 249 454 492 252 454 minecraft:red_nether_bricks
fill 493 249 450 493 254 450 minecraft:red_nether_bricks
fill 494 249 451 494 255 453 minecraft:red_nether_bricks
fill 497 249 416 498 252 416 minecraft:netherrack
setblock 502 249 416 minecraft:orange_concrete
setblock 505 249 458 minecraft:orange_concrete
setblock 508 249 458 minecraft:orange_concrete
fill 509 249 458 509 252 458 minecraft:netherrack
setblock 512 249 417 minecraft:orange_concrete
fill 512 249 422 512 252 422 minecraft:netherrack
fill 512 249 433 512 252 433 minecraft:netherrack
setblock 512 249 434 minecraft:orange_concrete
fill 512 249 437 512 249 438 minecraft:orange_concrete
fill 512 249 454 512 252 454 minecraft:netherrack
fill 470 250 418 470 251 419 minecraft:orange_concrete
fill 470 250 420 470 255 421 minecraft:netherrack
setblock 470 250 422 minecraft:orange_concrete
fill 470 250 430 470 251 431 minecraft:orange_concrete
fill 470 250 432 470 255 433 minecraft:netherrack
fill 470 250 439 470 251 439 minecraft:orange_concrete
fill 470 250 441 470 255 441 minecraft:netherrack
fill 470 250 442 470 250 443 minecraft:orange_concrete
fill 470 250 444 470 255 444 minecraft:netherrack
fill 470 250 450 470 251 451 minecraft:orange_concrete
fill 470 250 452 470 255 453 minecraft:netherrack
fill 471 250 416 472 251 416 minecraft:orange_concrete
fill 473 250 458 473 251 458 minecraft:netherrack
fill 474 250 458 475 250 458 minecraft:orange_concrete
fill 476 250 458 477 255 458 minecraft:netherrack
fill 478 250 416 478 255 416 minecraft:netherrack
fill 478 250 434 478 251 434 minecraft:magma_block
fill 479 250 416 480 250 416 minecraft:orange_concrete
fill 481 250 416 481 255 416 minecraft:netherrack
fill 482 250 458 483 251 458 minecraft:orange_concrete
fill 483 250 416 483 251 416 minecraft:orange_concrete
fill 484 250 458 485 255 458 minecraft:netherrack
setblock 486 250 458 minecraft:orange_concrete
fill 488 250 458 488 252 458 minecraft:netherrack
fill 489 250 416 490 255 416 minecraft:netherrack
fill 491 250 416 492 251 416 minecraft:orange_concrete
fill 493 250 454 493 253 454 minecraft:red_nether_bricks
fill 494 250 450 494 256 450 minecraft:red_nether_bricks
fill 494 250 458 495 251 458 minecraft:orange_concrete
fill 495 250 451 495 256 452 minecraft:red_nether_bricks
fill 496 250 458 497 255 458 minecraft:netherrack
setblock 500 250 416 minecraft:orange_concrete
fill 501 250 416 502 255 416 minecraft:netherrack
fill 503 250 416 504 251 416 minecraft:orange_concrete
fill 503 250 458 503 251 458 minecraft:orange_concrete
fill 505 250 458 505 255 458 minecraft:netherrack
fill 506 250 458 507 250 458 minecraft:orange_concrete
fill 508 250 458 508 255 458 minecraft:netherrack
fill 509 250 416 510 255 416 minecraft:netherrack
fill 511 250 416 512 250 416 minecraft:orange_concrete
fill 512 250 417 512 255 417 minecraft:netherrack
fill 512 250 425 512 255 426 minecraft:netherrack
fill 512 250 427 512 251 428 minecraft:orange_concrete
fill 512 250 434 512 255 434 minecraft:netherrack
setblock 512 250 436 minecraft:orange_concrete
fill 512 250 437 512 255 438 minecraft:netherrack
fill 512 250 439 512 251 439 minecraft:orange_concrete
fill 512 250 445 512 255 446 minecraft:netherrack
fill 512 250 447 512 250 448 minecraft:orange_concrete
fill 512 250 457 512 255 457 minecraft:netherrack
fill 470 251 422 470 254 422 minecraft:netherrack
setblock 470 251 427 minecraft:orange_concrete
setblock 470 251 438 minecraft:orange_concrete
fill 470 251 442 470 253 443 minecraft:netherrack
fill 470 251 458 471 251 458 minecraft:orange_concrete
setblock 474 251 458 minecraft:orange_concrete
fill 475 251 458 475 254 458 minecraft:netherrack
fill 479 251 416 480 254 416 minecraft:netherrack
setblock 484 251 416 minecraft:orange_concrete
fill 486 251 458 486 254 458 minecraft:netherrack
fill 490 251 458 490 253 458 minecraft:netherrack
setblock 491 251 458 minecraft:orange_concrete
fill 494 251 454 494 253 454 minecraft:red_nether_bricks
setblock 495 251 416 minecraft:orange_concrete
fill 495 251 450 495 257 450 minecraft:red_nether_bricks
fill 495 251 453 495 255 453 minecraft:red_nether_bricks
fill 496 251 430 498 252 430 minecraft:netherrack
fill 496 251 451 496 257 452 minecraft:red_nether_bricks
fill 497 251 429 498 252 429 minecraft:netherrack
fill 500 251 416 500 254 416 minecraft:netherrack
setblock 502 251 458 minecraft:orange_concrete
fill 506 251 458 507 254 458 minecraft:netherrack
fill 511 251 416 511 254 416 minecraft:netherrack
setblock 512 251 416 minecraft:orange_concrete
fill 512 251 419 512 251 420 minecraft:orange_concrete
fill 512 251 436 512 254 436 minecraft:netherrack
setblock 512 251 440 minecraft:orange_concrete
fill 512 251 447 512 254 447 minecraft:netherrack
setblock 512 251 448 minecraft:orange_concrete
setblock 512 251 451 minecraft:orange_concrete
fill 470 252 416 470 253 417 minecraft:orange_concrete
fill 470 252 418 470 257 419 minecraft:netherrack
fill 470 252 427 470 257 427 minecraft:netherrack
fill 470 252 428 470 252 429 minecraft:orange_concrete
fill 470 252 430 470 257 431 minecraft:netherrack
fill 470 252 436 470 253 437 minecraft:orange_concrete
fill 470 252 438 470 257 439 minecraft:netherrack
setblock 470 252 440 minecraft:orange_concrete
fill 470 252 448 470 253 449 minecraft:orange_concrete
fill 470 252 450 470 257 451 minecraft:netherrack
fill 470 252 457 470 253 457 minecraft:orange_concrete
fill 470 252 458 471 253 458 minecraft:netherrack
fill 471 252 416 472 257 416 minecraft:netherrack
fill 471 252 417 473 252 417 minecraft:red_nether_bricks
fill 471 252 419 471 252 421 minecraft:red_nether_bricks
fill 471 252 423 471 252 425 minecraft:red_nether_bricks
fill 471 252 427 471 252 429 minecraft:red_nether_bricks
fill 471 252 431 471 252 433 minecraft:red_nether_bricks
fill 471 252 435 471 252 437 minecraft:red_nether_bricks
fill 471 252 439 471 252 441 minecraft:red_nether_bricks
fill 471 252 443 471 252 445 minecraft:red_nether_bricks
fill 471 252 447 471 252 449 minecraft:red_nether_bricks
fill 471 252 451 471 252 453 minecraft:red_nether_bricks
fill 471 252 455 471 252 457 minecraft:red_nether_bricks
fill 472 252 458 473 252 458 minecraft:orange_concrete
fill 473 252 416 474 253 416 minecraft:orange_concrete
fill 473 252 457 475 252 457 minecraft:red_nether_bricks
fill 474 252 458 474 257 458 minecraft:netherrack
fill 475 252 417 477 252 417 minecraft:red_nether_bricks
fill 477 252 457 479 252 457 minecraft:red_nether_bricks
fill 479 252 417 481 252 417 minecraft:red_nether_bricks
fill 480 252 458 481 253 458 minecraft:orange_concrete
fill 481 252 457 483 252 457 minecraft:red_nether_bricks
setblock 482 252 416 minecraft:orange_concrete
fill 482 252 458 483 257 458 minecraft:netherrack
fill 483 252 416 484 257 416 minecraft:netherrack
fill 483 252 417 485 252 417 minecraft:red_nether_bricks
fill 485 252 416 486 253 416 minecraft:orange_concrete
fill 485 252 457 487 252 457 minecraft:red_nether_bricks
fill 487 252 417 489 252 417 minecraft:red_nether_bricks
fill 489 252 457 491 252 457 minecraft:red_nether_bricks
fill 491 252 416 492 257 416 minecraft:netherrack
fill 491 252 417 493 252 417 minecraft:red_nether_bricks
fill 491 252 458 491 257 458 minecraft:netherrack
fill 492 252 458 493 252 458 minecraft:orange_concrete
fill 493 252 416 494 252 416 minecraft:orange_concrete
fill 493 252 457 495 252 457 minecraft:red_nether_bricks
fill 494 252 458 495 257 458 minecraft:netherrack
fill 495 252 416 495 257 416 minecraft:netherrack
fill 495 252 417 497 252 417 minecraft:red_nether_bricks
fill 496 252 450 496 258 450 minecraft:red_nether_bricks
fill 496 252 453 496 256 453 minecraft:red_nether_bricks
fill 497 252 451 497 259 451 minecraft:red_nether_bricks
fill 497 252 457 499 252 457 minecraft:red_nether_bricks
fill 499 252 417 501 252 417 minecraft:red_nether_bricks
fill 500 252 458 501 253 458 minecraft:orange_concrete
fill 501 252 457 503 252 457 minecraft:red_nether_bricks
fill 502 252 458 503 257 458 minecraft:netherrack
fill 503 252 416 504 257 416 minecraft:netherrack
fill 503 252 417 505 252 417 minecraft:red_nether_bricks
setblock 504 252 458 minecraft:orange_concrete
fill 505 252 416 506 253 416 minecraft:orange_concrete
fill 505 252 457 507 252 457 minecraft:red_nether_bricks
fill 507 252 417 509 252 417 minecraft:red_nether_bricks
fill 509 252 457 511 252 457 minecraft:red_nether_bricks
fill 511 252 417 511 252 419 minecraft:red_nether_bricks
fill 511 252 421 511 252 423 minecraft:red_nether_bricks
fill 511 252 425 511 252 427 minecraft:red_nether_bricks
fill 511 252 429 511 252 431 minecraft:red_nether_bricks
fill 511 252 433 511 252 435 minecraft:red_nether_bricks
fill 511 252 437 511 252 439 minecraft:red_nether_bricks
fill 511 252 441 511 252 443 minecraft:red_nether_bricks
fill 511 252 445 511 252 447 minecraft:red_nether_bricks
fill 511 252 449 511 252 451 minecraft:red_nether_bricks
fill 511 252 453 511 252 455 minecraft:red_nether_bricks
fill 512 252 416 512 257 416 minecraft:netherrack
setblock 512 252 418 minecraft:orange_concrete
fill 512 252 419 512 257 420 minecraft:netherrack
fill 512 252 421 512 253 421 minecraft:orange_concrete
fill 512 252 427 512 257 428 minecraft:netherrack
fill 512 252 429 512 252 430 minecraft:orange_concrete
fill 512 252 439 512 257 440 minecraft:netherrack
fill 512 252 441 512 253 442 minecraft:orange_concrete
fill 512 252 448 512 257 448 minecraft:netherrack
fill 512 252 449 512 252 450 minecraft:orange_concrete
fill 512 252 451 512 257 451 minecraft:netherrack
fill 512 252 453 512 253 453 minecraft:orange_concrete
fill 512 252 458 512 253 458 minecraft:orange_concrete
fill 470 253 424 470 253 425 minecraft:orange_concrete
setblock 470 253 428 minecraft:orange_concrete
fill 470 253 429 470 256 429 minecraft:netherrack
fill 470 253 440 470 255 440 minecraft:netherrack
setblock 470 253 445 minecraft:orange_concrete
setblock 470 253 456 minecraft:orange_concrete
fill 472 253 458 473 255 458 minecraft:netherrack
setblock 477 253 416 minecraft:orange_concrete
fill 482 253 416 482 256 416 minecraft:netherrack
fill 488 253 458 489 253 458 minecraft:orange_concrete
setblock 492 253 458 minecraft:orange_concrete
fill 493 253 416 493 256 416 minecraft:netherrack
fill 493 253 458 493 256 458 minecraft:netherrack
setblock 494 253 416 minecraft:orange_concrete
fill 494 253 449 496 254 449 minecraft:red_nether_bricks
fill 497 253 416 498 253 416 minecraft:orange_concrete
fill 497 253 450 497 259 450 minecraft:red_nether_bricks
fill 497 253 452 497 258 452 minecraft:red_nether_bricks
fill 504 253 458 504 256 458 minecraft:netherrack
setblock 509 253 458 minecraft:orange_concrete
fill 512 253 418 512 256 418 minecraft:netherrack
setblock 512 253 422 minecraft:orange_concrete
fill 512 253 429 512 256 429 minecraft:netherrack
setblock 512 253 430 minecraft:orange_concrete
setblock 512 253 433 minecraft:orange_concrete
fill 512 253 449 512 256 450 minecraft:netherrack
setblock 512 253 454 minecraft:orange_concrete
fill 470 254 416 470 259 417 minecraft:netherrack
fill 470 254 423 470 255 423 minecraft:orange_concrete
fill 470 254 424 470 259 425 minecraft:netherrack
setblock 470 254 426 minecraft:orange_concrete
fill 470 254 428 470 259 428 minecraft:netherrack
fill 470 254 434 470 255 435 minecraft:orange_concrete
fill 470 254 436 470 259 437 minecraft:netherrack
setblock 470 254 442 minecraft:netherrack
fill 470 254 443 470 255 443 minecraft:orange_concrete
fill 470 254 445 470 259 445 minecraft:netherrack
fill 470 254 446 470 254 447 minecraft:orange_concrete
fill 470 254 448 470 256 449 minecraft:netherrack
fill 470 254 454 470 255 455 minecraft:orange_concrete
fill 470 254 456 470 259 457 minecraft:netherrack
setblock 470 254 458 minecraft:orange_concrete
fill 471 254 458 471 257 458 minecraft:netherrack
fill 473 254 416 474 259 416 minecraft:netherrack
fill 475 254 416 476 254 416 minecraft:orange_concrete
fill 477 254 416 477 259 416 minecraft:netherrack
fill 478 254 458 479 255 458 minecraft:orange_concrete
fill 480 254 458 481 259 458 minecraft:netherrack
fill 485 254 416 486 259 416 minecraft:netherrack
fill 487 254 416 488 255 416 minecraft:orange_concrete
fill 487 254 458 487 255 458 minecraft:orange_concrete
fill 488 254 458 489 259 458 minecraft:netherrack
setblock 490 254 458 minecraft:orange_concrete
fill 492 254 458 492 259 458 minecraft:netherrack
fill 494 254 416 494 259 416 minecraft:netherrack
setblock 496 254 416 minecraft:orange_concrete
fill 497 254 416 498 259 416 minecraft:netherrack
fill 497 254 449 498 259 449 minecraft:red_nether_bricks
fill 497 254 453 497 256 453 minecraft:red_nether_bricks
fill 498 254 450 498 259 452 minecraft:red_nether_bricks
fill 498 254 458 499 255 458 minecraft:orange_concrete
fill 499 254 416 499 255 416 minecraft:orange_concrete
fill 500 254 458 501 259 458 minecraft:netherrack
fill 505 254 416 506 259 416 minecraft:netherrack
fill 507 254 416 508 254 416 minecraft:orange_concrete
fill 509 254 458 509 259 458 minecraft:netherrack
fill 510 254 458 511 254 458 minecraft:orange_concrete
fill 512 254 421 512 259 422 minecraft:netherrack
fill 512 254 423 512 255 424 minecraft:orange_concrete
fill 512 254 430 512 259 430 minecraft:netherrack
fill 512 254 431 512 254 432 minecraft:orange_concrete
fill 512 254 433 512 259 433 minecraft:netherrack
fill 512 254 435 512 255 435 minecraft:orange_concrete
fill 512 254 441 512 259 442 minecraft:netherrack
fill 512 254 443 512 255 444 minecraft:orange_concrete
setblock 512 254 452 minecraft:orange_concrete
fill 512 254 453 512 259 454 minecraft:netherrack
fill 512 254 455 512 255 456 minecraft:orange_concrete
fill 512 254 458 512 259 458 minecraft:netherrack
setblock 470 255 422 minecraft:orange_concrete
fill 470 255 426 470 258 426 minecraft:netherrack
setblock 470 255 442 minecraft:orange_concrete
setblock 470 255 446 minecraft:orange_concrete
fill 470 255 447 470 258 447 minecraft:netherrack
fill 470 255 458 470 257 458 minecraft:netherrack
fill 475 255 416 475 258 416 minecraft:netherrack
setblock 475 255 458 minecraft:orange_concrete
setblock 476 255 416 minecraft:orange_concrete
fill 479 255 416 480 255 416 minecraft:orange_concrete
setblock 486 255 458 minecraft:orange_concrete
fill 487 255 452 488 256 453 minecraft:magma_block
fill 490 255 458 490 258 458 minecraft:netherrack
fill 493 255 451 493 255 452 minecraft:red_nether_bricks
fill 495 255 449 496 256 449 minecraft:red_nether_bricks
fill 496 255 416 496 258 416 minecraft:netherrack
fill 499 255 449 499 259 452 minecraft:red_nether_bricks
setblock 500 255 416 minecraft:orange_concrete
fill 503 255 417 503 256 422 minecraft:magma_block
fill 506 255 458 507 255 458 minecraft:orange_concrete
fill 507 255 416 507 258 416 minecraft:netherrack
setblock 508 255 416 minecraft:orange_concrete
setblock 510 255 458 minecraft:orange_concrete
setblock 511 255 416 minecraft:orange_concrete
fill 511 255 458 511 258 458 minecraft:netherrack
fill 512 255 431 512 258 432 minecraft:netherrack
setblock 512 255 436 minecraft:orange_concrete
setblock 512 255 447 minecraft:orange_concrete
fill 512 255 452 512 258 452 minecraft:netherrack
fill 470 256 420 470 257 421 minecraft:orange_concrete
fill 470 256 422 470 261 423 minecraft:netherrack
fill 470 256 432 470 256 433 minecraft:orange_concrete
fill 470 256 434 470 261 435 minecraft:netherrack
fill 470 256 440 470 257 441 minecraft:orange_concrete
fill 470 256 442 470 261 443 minecraft:netherrack
setblock 470 256 444 minecraft:orange_concrete
fill 470 256 446 470 258 446 minecraft:netherrack
fill 470 256 452 470 257 453 minecraft:orange_concrete
fill 470 256 454 470 261 455 minecraft:netherrack
setblock 472 256 458 minecraft:netherrack
setblock 473 256 419 minecraft:light[level=14]
setblock 473 256 427 minecraft:light[level=14]
setblock 473 256 435 minecraft:light[level=14]
setblock 473 256 443 minecraft:light[level=14]
setblock 473 256 451 minecraft:light[level=14]
fill 473 256 458 473 257 458 minecraft:orange_concrete
fill 475 256 458 475 261 458 minecraft:netherrack
fill 476 256 416 476 261 416 minecraft:netherrack
fill 476 256 458 477 256 458 minecraft:orange_concrete
setblock 478 256 416 minecraft:orange_concrete
fill 478 256 458 479 258 458 minecraft:netherrack
fill 479 256 416 480 261 416 minecraft:netherrack
fill 481 256 416 481 257 416 minecraft:orange_concrete
setblock 481 256 419 minecraft:light[level=14]
setblock 481 256 427 minecraft:light[level=14]
setblock 481 256 435 minecraft:light[level=14]
setblock 481 256 443 minecraft:light[level=14]
setblock 481 256 451 minecraft:light[level=14]
fill 484 256 458 485 257 458 minecraft:orange_concrete
fill 486 256 458 487 261 458 minecraft:netherrack
fill 487 256 416 488 261 416 minecraft:netherrack
fill 489 256 416 490 256 416 minecraft:orange_concrete
setblock 489 256 419 minecraft:light[level=14]
setblock 489 256 427 minecraft:light[level=14]
setblock 489 256 435 minecraft:light[level=14]
setblock 489 256 443 minecraft:light[level=14]
setblock 489 256 451 minecraft:light[level=14]
fill 493 256 452 493 258 452 minecraft:magma_block
fill 494 256 451 494 256 452 minecraft:red_nether_bricks
fill 496 256 458 497 256 458 minecraft:orange_concrete
setblock 497 256 419 minecraft:light[level=14]
setblock 497 256 427 minecraft:light[level=14]
setblock 497 256 435 minecraft:light[level=14]
setblock 497 256 443 minecraft:light[level=14]
fill 497 256 448 499 258 448 minecraft:red_nether_bricks
fill 498 256 458 499 261 458 minecraft:netherrack
fill 499 256 416 500 261 416 minecraft:netherrack
fill 500 256 449 500 260 451 minecraft:red_nether_bricks
fill 501 256 416 502 257 416 minecraft:orange_concrete
fill 502 256 417 502 256 419 minecraft:magma_block
fill 504 256 417 504 256 419 minecraft:magma_block
setblock 505 256 419 minecraft:light[level=14]
setblock 505 256 427 minecraft:light[level=14]
setblock 505 256 435 minecraft:light[level=14]
setblock 505 256 443 minecraft:light[level=14]
setblock 505 256 451 minecraft:light[level=14]
fill 505 256 458 505 257 458 minecraft:orange_concrete
fill 506 256 458 507 261 458 minecraft:netherrack
fill 508 256 416 508 261 416 minecraft:netherrack
setblock 508 256 458 minecraft:orange_concrete
fill 509 256 416 510 256 416 minecraft:orange_concrete
fill 510 256 458 510 261 458 minecraft:netherrack
fill 511 256 416 511 261 416 minecraft:netherrack
fill 512 256 417 512 257 417 minecraft:orange_concrete
fill 512 256 423 512 261 424 minecraft:netherrack
fill 512 256 425 512 257 426 minecraft:orange_concrete
setblock 512 256 434 minecraft:orange_concrete
fill 512 256 435 512 261 436 minecraft:netherrack
fill 512 256 437 512 257 438 minecraft:orange_concrete
fill 512 256 443 512 261 444 minecraft:netherrack
fill 512 256 445 512 256 446 minecraft:orange_concrete
fill 512 256 447 512 261 447 minecraft:netherrack
fill 512 256 455 512 261 456 minecraft:netherrack
fill 512 256 457 512 257 457 minecraft:orange_concrete
setblock 470 257 429 minecraft:orange_concrete
setblock 470 257 432 minecraft:orange_concrete
fill 470 257 433 470 260 433 minecraft:netherrack
fill 470 257 444 470 260 444 minecraft:netherrack
fill 470 257 448 470 259 448 minecraft:netherrack
setblock 470 257 449 minecraft:orange_concrete
setblock 472 257 458 minecraft:orange_concrete
setblock 476 257 458 minecraft:orange_concrete
fill 477 257 458 477 260 458 minecraft:netherrack
fill 478 257 416 478 260 416 minecraft:netherrack
setblock 482 257 416 minecraft:orange_concrete
fill 489 257 416 489 260 416 minecraft:netherrack
setblock 490 257 416 minecraft:orange_concrete
setblock 493 257 416 minecraft:orange_concrete
setblock 493 257 458 minecraft:orange_concrete
fill 494 257 452 494 258 452 minecraft:magma_block
setblock 495 257 451 minecraft:red_nether_bricks
fill 496 257 449 496 258 449 minecraft:red_nether_bricks
setblock 496 257 458 minecraft:orange_concrete
fill 497 257 458 497 260 458 minecraft:netherrack
fill 500 257 448 500 263 448 minecraft:red_nether_bricks
fill 500 257 452 500 258 452 minecraft:red_nether_bricks
fill 501 257 449 501 262 450 minecraft:red_nether_bricks
fill 502 257 417 504 257 418 minecraft:magma_block
setblock 503 257 419 minecraft:magma_block
setblock 504 257 458 minecraft:orange_concrete
fill 508 257 458 508 260 458 minecraft:netherrack
fill 509 257 416 510 260 416 minecraft:netherrack
setblock 512 257 418 minecraft:orange_concrete
setblock 512 257 429 minecraft:orange_concrete
fill 512 257 434 512 260 434 minecraft:netherrack
fill 512 257 445 512 260 445 minecraft:netherrack
setblock 512 257 446 minecraft:orange_concrete
fill 512 257 449 512 257 450 minecraft:orange_concrete
fill 470 258 418 470 259 419 minecraft:orange_concrete
fill 470 258 420 470 263 421 minecraft:netherrack
fill 470 258 427 470 259 427 minecraft:orange_concrete
fill 470 258 429 470 263 429 minecraft:netherrack
fill 470 258 430 470 258 431 minecraft:orange_concrete
fill 470 258 432 470 263 432 minecraft:netherrack
fill 470 258 438 470 259 439 minecraft:orange_concrete
fill 470 258 440 470 263 441 minecraft:netherrack
fill 470 258 449 470 259 449 minecraft:netherrack
fill 470 258 450 470 258 451 minecraft:orange_concrete
fill 470 258 452 470 263 453 minecraft:netherrack
fill 470 258 458 471 259 458 minecraft:orange_concrete
fill 471 258 416 472 258 416 minecraft:orange_concrete
fill 471 258 417 473 258 417 minecraft:red_nether_bricks
fill 471 258 419 471 258 421 minecraft:red_nether_bricks
fill 471 258 423 471 258 425 minecraft:red_nether_bricks
fill 471 258 427 471 258 429 minecraft:red_nether_bricks
fill 471 258 431 471 258 433 minecraft:red_nether_bricks
fill 471 258 435 471 258 437 minecraft:red_nether_bricks
fill 471 258 439 471 258 441 minecraft:red_nether_bricks
fill 471 258 443 471 258 445 minecraft:red_nether_bricks
fill 471 258 447 471 258 449 minecraft:red_nether_bricks
fill 471 258 451 471 258 453 minecraft:red_nether_bricks
fill 471 258 455 471 258 457 minecraft:red_nether_bricks
fill 472 258 458 473 263 458 minecraft:netherrack
fill 473 258 457 475 258 457 minecraft:red_nether_bricks
setblock 474 258 458 minecraft:orange_concrete
fill 475 258 417 477 258 417 minecraft:red_nether_bricks
fill 476 258 458 476 260 458 minecraft:netherrack
fill 477 258 457 479 258 457 minecraft:red_nether_bricks
fill 479 258 417 481 258 417 minecraft:red_nether_bricks
fill 481 258 416 482 263 416 minecraft:netherrack
fill 481 258 457 483 258 457 minecraft:red_nether_bricks
fill 482 258 458 483 259 458 minecraft:orange_concrete
fill 483 258 416 484 259 416 minecraft:orange_concrete
fill 483 258 417 485 258 417 minecraft:red_nether_bricks
fill 484 258 458 485 263 458 minecraft:netherrack
fill 485 258 457 487 258 457 minecraft:red_nether_bricks
fill 487 258 417 489 258 417 minecraft:red_nether_bricks
fill 489 258 457 491 258 457 minecraft:red_nether_bricks
fill 490 258 416 490 263 416 minecraft:netherrack
fill 491 258 416 492 258 416 minecraft:orange_concrete
fill 491 258 417 493 258 417 minecraft:red_nether_bricks
fill 491 258 458 491 259 458 minecraft:orange_concrete
fill 493 258 416 493 263 416 minecraft:netherrack
fill 493 258 457 495 258 457 minecraft:red_nether_bricks
fill 493 258 458 493 263 458 minecraft:netherrack
fill 494 258 458 495 258 458 minecraft:orange_concrete
fill 495 258 416 495 259 416 minecraft:orange_concrete
fill 495 258 417 497 258 417 minecraft:red_nether_bricks
setblock 496 258 451 minecraft:red_nether_bricks
fill 496 258 458 496 263 458 minecraft:netherrack
fill 497 258 457 499 258 457 minecraft:red_nether_bricks
fill 499 258 417 501 258 417 minecraft:red_nether_bricks
fill 499 258 447 500 262 447 minecraft:red_nether_bricks
fill 501 258 416 502 263 416 minecraft:netherrack
fill 501 258 448 501 264 448 minecraft:red_nether_bricks
fill 501 258 451 501 260 451 minecraft:red_nether_bricks
fill 501 258 457 503 258 457 minecraft:red_nether_bricks
fill 502 258 458 503 259 458 minecraft:orange_concrete
fill 503 258 416 504 259 416 minecraft:orange_concrete
fill 503 258 417 505 258 417 minecraft:red_nether_bricks
fill 504 258 458 505 263 458 minecraft:netherrack
fill 505 258 457 507 258 457 minecraft:red_nether_bricks
fill 507 258 417 509 258 417 minecraft:red_nether_bricks
fill 509 258 457 511 258 457 minecraft:red_nether_bricks
fill 511 258 417 511 258 419 minecraft:red_nether_bricks
fill 511 258 421 511 258 423 minecraft:red_nether_bricks
fill 511 258 425 511 258 427 minecraft:red_nether_bricks
fill 511 258 429 511 258 431 minecraft:red_nether_bricks
fill 511 258 433 511 258 435 minecraft:red_nether_bricks
fill 511 258 437 511 258 439 minecraft:red_nether_bricks
fill 511 258 441 511 258 443 minecraft:red_nether_bricks
fill 511 258 445 511 258 447 minecraft:red_nether_bricks
fill 511 258 449 511 258 451 minecraft:red_nether_bricks
fill 511 258 453 511 258 455 minecraft:red_nether_bricks
setblock 512 258 416 minecraft:orange_concrete
fill 512 258 417 512 263 418 minecraft:netherrack
fill 512 258 419 512 259 420 minecraft:orange_concrete
fill 512 258 425 512 263 426 minecraft:netherrack
fill 512 258 427 512 258 428 minecraft:orange_concrete
fill 512 258 429 512 263 429 minecraft:netherrack
fill 512 258 437 512 263 438 minecraft:netherrack
fill 512 258 439 512 259 440 minecraft:orange_concrete
fill 512 258 446 512 263 446 minecraft:netherrack
setblock 512 258 448 minecraft:orange_concrete
fill 512 258 449 512 263 450 minecraft:netherrack
fill 512 258 451 512 259 451 minecraft:orange_concrete
fill 512 258 457 512 263 457 minecraft:netherrack
setblock 470 259 426 minecraft:orange_concrete
fill 470 259 430 470 261 431 minecraft:netherrack
fill 470 259 446 470 259 447 minecraft:orange_concrete
setblock 470 259 450 minecraft:orange_concrete
fill 470 259 451 470 262 451 minecraft:netherrack
fill 471 259 416 471 262 416 minecraft:netherrack
setblock 472 259 416 minecraft:orange_concrete
fill 474 259 458 474 262 458 minecraft:netherrack
setblock 475 259 416 minecraft:orange_concrete
fill 478 259 458 478 261 458 minecraft:netherrack
setblock 479 259 458 minecraft:orange_concrete
setblock 490 259 458 minecraft:orange_concrete
fill 491 259 416 492 262 416 minecraft:netherrack
fill 494 259 458 495 262 458 minecraft:netherrack
setblock 496 259 416 minecraft:orange_concrete
fill 498 259 448 499 261 448 minecraft:red_nether_bricks
fill 501 259 447 502 265 447 minecraft:red_nether_bricks
fill 502 259 444 503 260 445 minecraft:netherrack
fill 502 259 448 502 262 450 minecraft:red_nether_bricks
setblock 507 259 416 minecraft:orange_concrete
setblock 511 259 458 minecraft:orange_concrete
fill 512 259 416 512 262 416 minecraft:netherrack
fill 512 259 427 512 262 427 minecraft:netherrack
setblock 512 259 428 minecraft:orange_concrete
fill 512 259 431 512 259 432 minecraft:orange_concrete
fill 512 259 448 512 262 448 minecraft:netherrack
setblock 512 259 452 minecraft:orange_concrete
fill 470 260 416 470 260 417 minecraft:orange_concrete
fill 470 260 418 470 265 419 minecraft:netherrack
fill 470 260 424 470 261 425 minecraft:orange_concrete
fill 470 260 426 470 265 427 minecraft:netherrack
setblock 470 260 428 minecraft:orange_concrete
fill 470 260 436 470 261 437 minecraft:orange_concrete
fill 470 260 438 470 265 439 minecraft:netherrack
fill 470 260 445 470 261 445 minecraft:orange_concrete
fill 470 260 446 470 261 447 minecraft:netherrack
fill 470 260 448 470 260 449 minecraft:orange_concrete
fill 470 260 450 470 265 450 minecraft:netherrack
fill 470 260 456 470 261 457 minecraft:orange_concrete
fill 470 260 458 471 265 458 minecraft:netherrack
fill 472 260 416 472 265 416 minecraft:netherrack
fill 473 260 416 474 260 416 minecraft:orange_concrete
fill 475 260 416 475 265 416 minecraft:netherrack
fill 477 260 416 477 261 416 minecraft:orange_concrete
fill 479 260 458 479 265 458 minecraft:netherrack
fill 480 260 458 481 260 458 minecraft:orange_concrete
fill 482 260 458 483 265 458 minecraft:netherrack
fill 483 260 416 484 265 416 minecraft:netherrack
fill 485 260 416 486 261 416 minecraft:orange_concrete
fill 488 260 458 489 261 458 minecraft:orange_concrete
fill 490 260 458 491 265 458 minecraft:netherrack
setblock 492 260 458 minecraft:orange_concrete
setblock 494 260 416 minecraft:orange_concrete
fill 495 260 416 496 265 416 minecraft:netherrack
fill 497 260 416 498 261 416 minecraft:orange_concrete
fill 497 260 429 497 261 430 minecraft:magma_block
fill 498 260 429 498 261 429 minecraft:magma_block
fill 498 260 449 499 260 451 minecraft:red_nether_bricks
fill 500 260 446 502 263 446 minecraft:red_nether_bricks
fill 500 260 458 501 261 458 minecraft:orange_concrete
fill 502 260 458 503 265 458 minecraft:netherrack
fill 503 260 416 504 265 416 minecraft:netherrack
fill 503 260 447 503 264 449 minecraft:red_nether_bricks
fill 505 260 416 506 260 416 minecraft:orange_concrete
fill 507 260 416 507 265 416 minecraft:netherrack
fill 509 260 458 509 261 458 minecraft:orange_concrete
fill 511 260 458 511 265 458 minecraft:netherrack
fill 512 260 419 512 265 420 minecraft:netherrack
fill 512 260 421 512 261 422 minecraft:orange_concrete
fill 512 260 428 512 265 428 minecraft:netherrack
setblock 512 260 430 minecraft:orange_concrete
fill 512 260 431 512 265 432 minecraft:netherrack
fill 512 260 433 512 261 433 minecraft:orange_concrete
fill 512 260 439 512 265 440 minecraft:netherrack
fill 512 260 441 512 260 442 minecraft:orange_concrete
fill 512 260 451 512 265 452 minecraft:netherrack
fill 512 260 453 512 261 454 minecraft:orange_concrete
setblock 512 260 458 minecraft:orange_concrete
setblock 470 261 416 minecraft:orange_concrete
fill 470 261 417 470 264 417 minecraft:netherrack
fill 470 261 428 470 263 428 minecraft:netherrack
setblock 470 261 433 minecraft:orange_concrete
setblock 470 261 444 minecraft:orange_concrete
fill 470 261 448 470 263 449 minecraft:netherrack
fill 473 261 416 474 264 416 minecraft:netherrack
fill 476 261 458 477 261 458 minecraft:orange_concrete
setblock 478 261 416 minecraft:orange_concrete
setblock 480 261 458 minecraft:orange_concrete
fill 481 261 458 481 264 458 minecraft:netherrack
setblock 489 261 416 minecraft:orange_concrete
fill 492 261 458 492 264 458 minecraft:netherrack
fill 494 261 416 494 264 416 minecraft:netherrack
setblock 497 261 458 minecraft:orange_concrete
fill 498 261 449 500 261 449 minecraft:red_nether_bricks
fill 499 261 450 500 261 450 minecraft:red_nether_bricks
fill 502 261 445 502 267 445 minecraft:red_nether_bricks
fill 503 261 446 503 267 446 minecraft:red_nether_bricks
fill 504 261 447 504 266 447 minecraft:red_nether_bricks
fill 505 261 416 505 264 416 minecraft:netherrack
setblock 506 261 416 minecraft:orange_concrete
setblock 508 261 458 minecraft:orange_concrete
fill 509 261 416 510 261 416 minecraft:orange_concrete
fill 512 261 430 512 264 430 minecraft:netherrack
setblock 512 261 434 minecraft:orange_concrete
fill 512 261 441 512 264 441 minecraft:netherrack
setblock 512 261 442 minecraft:orange_concrete
setblock 512 261 445 minecraft:orange_concrete
fill 512 261 458 512 264 458 minecraft:netherrack
fill 470 262 416 470 267 416 minecraft:netherrack
fill 470 262 422 470 263 423 minecraft:orange_concrete
fill 470 262 424 470 267 425 minecraft:netherrack
setblock 470 262 430 minecraft:netherrack
fill 470 262 431 470 263 431 minecraft:orange_concrete
fill 470 262 433 470 267 433 minecraft:netherrack
fill 470 262 434 470 262 435 minecraft:orange_concrete
fill 470 262 436 470 264 437 minecraft:netherrack
fill 470 262 442 470 263 443 minecraft:orange_concrete
fill 470 262 444 470 267 445 minecraft:netherrack
setblock 470 262 446 minecraft:orange_concrete
fill 470 262 447 470 265 447 minecraft:netherrack
fill 470 262 454 470 263 455 minecraft:orange_concrete
fill 470 262 456 470 267 457 minecraft:netherrack
fill 475 262 458 475 263 458 minecraft:orange_concrete
setblock 476 262 416 minecraft:orange_concrete
fill 476 262 458 477 267 458 minecraft:netherrack
fill 477 262 416 478 267 416 minecraft:netherrack
setblock 478 262 458 minecraft:orange_concrete
fill 479 262 416 480 263 416 minecraft:orange_concrete
fill 480 262 458 480 267 458 minecraft:netherrack
fill 485 262 416 486 267 416 minecraft:netherrack
fill 486 262 458 487 263 458 minecraft:orange_concrete
fill 487 262 416 488 262 416 minecraft:orange_concrete
fill 488 262 458 489 267 458 minecraft:netherrack
fill 489 262 416 489 267 416 minecraft:netherrack
fill 497 262 416 498 267 416 minecraft:netherrack
fill 497 262 458 497 267 458 minecraft:netherrack
fill 498 262 458 499 262 458 minecraft:orange_concrete
fill 499 262 416 500 263 416 minecraft:orange_concrete
fill 499 262 448 499 262 449 minecraft:red_nether_bricks
fill 500 262 449 500 262 450 minecraft:red_nether_bricks
fill 500 262 458 501 267 458 minecraft:netherrack
fill 501 262 445 501 266 445 minecraft:red_nether_bricks
fill 503 262 445 504 268 445 minecraft:red_nether_bricks
fill 504 262 446 504 268 446 minecraft:red_nether_bricks
fill 504 262 448 504 265 448 minecraft:red_nether_bricks
fill 506 262 416 506 267 416 minecraft:netherrack
fill 506 262 458 507 263 458 minecraft:orange_concrete
setblock 508 262 416 minecraft:orange_concrete
fill 508 262 458 509 267 458 minecraft:netherrack
fill 509 262 416 510 267 416 minecraft:netherrack
setblock 510 262 458 minecraft:orange_concrete
fill 511 262 416 511 263 416 minecraft:orange_concrete
fill 512 262 421 512 267 422 minecraft:netherrack
fill 512 262 423 512 262 424 minecraft:orange_concrete
fill 512 262 433 512 267 434 minecraft:netherrack
fill 512 262 435 512 263 436 minecraft:orange_concrete
fill 512 262 442 512 267 442 minecraft:netherrack
fill 512 262 443 512 262 444 minecraft:orange_concrete
fill 512 262 445 512 267 445 minecraft:netherrack
fill 512 262 447 512 263 447 minecraft:orange_concrete
fill 512 262 453 512 267 454 minecraft:netherrack
fill 512 262 455 512 263 456 minecraft:orange_concrete
setblock 470 263 430 minecraft:orange_concrete
setblock 470 263 434 minecraft:orange_concrete
fill 470 263 435 470 266 435 minecraft:netherrack
fill 470 263 446 470 265 446 minecraft:netherrack
setblock 470 263 451 minecraft:orange_concrete
setblock 471 263 416 minecraft:orange_concrete
setblock 474 263 458 minecraft:orange_concrete
fill 476 263 416 476 266 416 minecraft:netherrack
fill 478 263 458 478 266 458 minecraft:netherrack
fill 487 263 416 487 266 416 minecraft:netherrack
setblock 488 263 416 minecraft:orange_concrete
fill 491 263 416 492 263 416 minecraft:orange_concrete
fill 494 263 458 495 263 458 minecraft:orange_concrete
setblock 498 263 458 minecraft:orange_concrete
fill 499 263 458 499 266 458 minecraft:netherrack
fill 500 263 447 500 264 447 minecraft:red_nether_bricks
fill 500 263 449 502 263 449 minecraft:red_nether_bricks
fill 502 263 444 504 268 444 minecraft:red_nether_bricks
fill 502 263 448 502 265 448 minecraft:red_nether_bricks
fill 505 263 445 505 265 447 minecraft:red_nether_bricks
fill 508 263 416 508 266 416 minecraft:netherrack
fill 510 263 458 510 266 458 minecraft:netherrack
setblock 512 263 416 minecraft:orange_concrete
fill 512 263 423 512 266 423 minecraft:netherrack
setblock 512 263 424 minecraft:orange_concrete
setblock 512 263 427 minecraft:orange_concrete
fill 512 263 443 512 266 444 minecraft:netherrack
setblock 512 263 448 minecraft:orange_concrete
fill 470 264 420 470 264 421 minecraft:orange_concrete
fill 470 264 422 470 269 423 minecraft:netherrack
fill 470 264 428 470 265 429 minecraft:orange_concrete
fill 470 264 430 470 269 431 minecraft:netherrack
setblock 470 264 432 minecraft:orange_concrete
fill 470 264 434 470 266 434 minecraft:netherrack
fill 470 264 440 470 265 441 minecraft:orange_concrete
fill 470 264 442 470 269 443 minecraft:netherrack
setblock 470 264 448 minecraft:netherrack
fill 470 264 449 470 265 449 minecraft:orange_concrete
fill 470 264 451 470 269 451 minecraft:netherrack
fill 470 264 452 470 264 453 minecraft:orange_concrete
fill 470 264 454 470 266 455 minecraft:netherrack
fill 471 264 416 471 269 416 minecraft:netherrack
fill 471 264 417 473 264 417 minecraft:red_nether_bricks
fill 471 264 419 471 264 421 minecraft:red_nether_bricks
fill 471 264 423 471 264 425 minecraft:red_nether_bricks
fill 471 264 427 471 264 429 minecraft:red_nether_bricks
fill 471 264 431 471 264 433 minecraft:red_nether_bricks
fill 471 264 435 471 264 437 minecraft:red_nether_bricks
fill 471 264 439 471 264 441 minecraft:red_nether_bricks
fill 471 264 443 471 264 445 minecraft:red_nether_bricks
fill 471 264 447 471 264 449 minecraft:red_nether_bricks
fill 471 264 451 471 264 453 minecraft:red_nether_bricks
fill 471 264 455 471 264 457 minecraft:red_nether_bricks
fill 472 264 458 473 265 458 minecraft:orange_concrete
setblock 473 264 419 minecraft:light[level=14]
setblock 473 264 427 minecraft:light[level=14]
setblock 473 264 435 minecraft:light[level=14]
setblock 473 264 443 minecraft:light[level=14]
setblock 473 264 451 minecraft:light[level=14]
fill 473 264 457 475 264 457 minecraft:red_nether_bricks
fill 474 264 458 475 269 458 minecraft:netherrack
fill 475 264 417 477 264 417 minecraft:red_nether_bricks
fill 477 264 457 479 264 457 minecraft:red_nether_bricks
fill 479 264 416 480 269 416 minecraft:netherrack
fill 479 264 417 481 264 417 minecraft:red_nether_bricks
fill 481 264 416 482 265 416 minecraft:orange_concrete
setblock 481 264 419 minecraft:light[level=14]
setblock 481 264 427 minecraft:light[level=14]
setblock 481 264 435 minecraft:light[level=14]
setblock 481 264 443 minecraft:light[level=14]
setblock 481 264 451 minecraft:light[level=14]
fill 481 264 457 483 264 457 minecraft:red_nether_bricks
fill 483 264 417 485 264 417 minecraft:red_nether_bricks
fill 484 264 458 485 264 458 minecraft:orange_concrete
fill 485 264 457 487 264 457 minecraft:red_nether_bricks
fill 486 264 458 487 269 458 minecraft:netherrack
fill 487 264 417 489 264 417 minecraft:red_nether_bricks
fill 488 264 416 488 269 416 minecraft:netherrack
setblock 489 264 419 minecraft:light[level=14]
setblock 489 264 427 minecraft:light[level=14]
setblock 489 264 435 minecraft:light[level=14]
setblock 489 264 443 minecraft:light[level=14]
setblock 489 264 451 minecraft:light[level=14]
fill 489 264 457 491 264 457 minecraft:red_nether_bricks
setblock 490 264 416 minecraft:orange_concrete
fill 491 264 416 492 269 416 minecraft:netherrack
fill 491 264 417 493 264 417 minecraft:red_nether_bricks
fill 493 264 416 493 265 416 minecraft:orange_concrete
fill 493 264 457 495 264 457 minecraft:red_nether_bricks
fill 493 264 458 493 265 458 minecraft:orange_concrete
fill 494 264 458 495 269 458 minecraft:netherrack
fill 495 264 417 497 264 417 minecraft:red_nether_bricks
setblock 496 264 458 minecraft:orange_concrete
setblock 497 264 419 minecraft:light[level=14]
setblock 497 264 427 minecraft:light[level=14]
setblock 497 264 435 minecraft:light[level=14]
setblock 497 264 443 minecraft:light[level=14]
setblock 497 264 451 minecraft:light[level=14]
fill 497 264 457 499 264 457 minecraft:red_nether_bricks
fill 498 264 458 498 269 458 minecraft:netherrack
fill 499 264 416 500 269 416 minecraft:netherrack
fill 499 264 417 501 264 417 minecraft:red_nether_bricks
fill 501 264 416 502 264 416 minecraft:orange_concrete
fill 501 264 446 502 266 446 minecraft:red_nether_bricks
fill 501 264 457 503 264 457 minecraft:red_nether_bricks
setblock 502 264 449 minecraft:red_nether_bricks
fill 503 264 417 505 264 417 minecraft:red_nether_bricks
fill 503 264 443 504 270 443 minecraft:red_nether_bricks
fill 504 264 458 505 265 458 minecraft:orange_concrete
setblock 505 264 419 minecraft:light[level=14]
setblock 505 264 427 minecraft:light[level=14]
setblock 505 264 435 minecraft:light[level=14]
setblock 505 264 443 minecraft:light[level=14]
fill 505 264 444 505 270 444 minecraft:red_nether_bricks
setblock 505 264 451 minecraft:light[level=14]
fill 505 264 457 507 264 457 minecraft:red_nether_bricks
fill 506 264 458 507 269 458 minecraft:netherrack
fill 507 264 417 509 264 417 minecraft:red_nether_bricks
fill 509 264 457 511 264 457 minecraft:red_nether_bricks
fill 511 264 416 512 269 416 minecraft:netherrack
fill 511 264 417 511 264 419 minecraft:red_nether_bricks
fill 511 264 421 511 264 423 minecraft:red_nether_bricks
fill 511 264 425 511 264 427 minecraft:red_nether_bricks
fill 511 264 429 511 264 431 minecraft:red_nether_bricks
fill 511 264 433 511 264 435 minecraft:red_nether_bricks
fill 511 264 437 511 264 439 minecraft:red_nether_bricks
fill 511 264 441 511 264 443 minecraft:red_nether_bricks
fill 511 264 445 511 264 447 minecraft:red_nether_bricks
fill 511 264 449 511 264 451 minecraft:red_nether_bricks
fill 511 264 453 511 264 455 minecraft:red_nether_bricks
fill 512 264 417 512 265 418 minecraft:orange_concrete
fill 512 264 424 512 269 424 minecraft:netherrack
fill 512 264 425 512 264 426 minecraft:orange_concrete
fill 512 264 427 512 269 427 minecraft:netherrack
fill 512 264 429 512 265 429 minecraft:orange_concrete
fill 512 264 435 512 269 436 minecraft:netherrack
fill 512 264 437 512 265 438 minecraft:orange_concrete
setblock 512 264 446 minecraft:orange_concrete
fill 512 264 447 512 269 448 minecraft:netherrack
fill 512 264 449 512 265 450 minecraft:orange_concrete
fill 512 264 455 512 269 456 minecraft:netherrack
setblock 512 264 457 minecraft:orange_concrete
setblock 470 265 417 minecraft:orange_concrete
setblock 470 265 420 minecraft:orange_concrete
fill 470 265 421 470 268 421 minecraft:netherrack
fill 470 265 432 470 268 432 minecraft:netherrack
fill 470 265 436 470 267 436 minecraft:netherrack
setblock 470 265 437 minecraft:orange_concrete
setblock 470 265 448 minecraft:orange_concrete
setblock 470 265 452 minecraft:orange_concrete
fill 470 265 453 470 268 453 minecraft:netherrack
fill 473 265 416 474 265 416 minecraft:orange_concrete
setblock 481 265 458 minecraft:orange_concrete
setblock 484 265 458 minecraft:orange_concrete
fill 485 265 458 485 268 458 minecraft:netherrack
fill 490 265 416 490 268 416 minecraft:netherrack
setblock 492 265 458 minecraft:orange_concrete
setblock 494 265 416 minecraft:orange_concrete
fill 496 265 458 496 268 458 minecraft:netherrack
fill 501 265 416 501 268 416 minecraft:netherrack
setblock 502 265 416 minecraft:orange_concrete
fill 502 265 443 502 268 443 minecraft:red_nether_bricks
fill 503 265 447 503 265 448 minecraft:red_nether_bricks
fill 504 265 442 504 272 442 minecraft:red_nether_bricks
setblock 505 265 416 minecraft:orange_concrete
fill 505 265 443 505 271 443 minecraft:red_nether_bricks
fill 506 265 444 506 268 445 minecraft:red_nether_bricks
fill 512 265 425 512 268 426 minecraft:netherrack
setblock 512 265 430 minecraft:orange_concrete
setblock 512 265 441 minecraft:orange_concrete
fill 512 265 446 512 268 446 minecraft:netherrack
fill 512 265 457 512 268 457 minecraft:netherrack
setblock 512 265 458 minecraft:orange_concrete
fill 470 266 417 470 271 417 minecraft:netherrack
fill 470 266 418 470 266 419 minecraft:orange_concrete
fill 470 266 420 470 271 420 minecraft:netherrack
fill 470 266 426 470 267 427 minecraft:orange_concrete
fill 470 266 428 470 271 429 minecraft:netherrack
fill 470 266 437 470 267 437 minecraft:netherrack
fill 470 266 438 470 266 439 minecraft:orange_concrete
fill 470 266 440 470 271 441 minecraft:netherrack
fill 470 266 446 470 267 447 minecraft:orange_concrete
fill 470 266 448 470 271 449 minecraft:netherrack
setblock 470 266 450 minecraft:orange_concrete
fill 470 266 452 470 268 452 minecraft:netherrack
fill 470 266 458 471 267 458 minecraft:orange_concrete
setblock 472 266 416 minecraft:orange_concrete
fill 472 266 458 473 271 458 minecraft:netherrack
fill 473 266 416 474 271 416 minecraft:netherrack
fill 475 266 416 475 267 416 minecraft:orange_concrete
fill 479 266 458 479 267 458 minecraft:orange_concrete
fill 481 266 416 482 271 416 minecraft:netherrack
fill 481 266 458 481 271 458 minecraft:netherrack
fill 482 266 458 483 266 458 minecraft:orange_concrete
fill 483 266 416 484 266 416 minecraft:orange_concrete
fill 484 266 458 484 271 458 minecraft:netherrack
fill 489 266 446 489 267 447 minecraft:shroomlight
fill 490 266 458 491 267 458 minecraft:orange_concrete
fill 492 266 458 493 271 458 minecraft:netherrack
fill 493 266 416 494 271 416 minecraft:netherrack
fill 495 266 416 496 267 416 minecraft:orange_concrete
fill 502 266 416 502 271 416 minecraft:netherrack
fill 502 266 447 503 266 447 minecraft:red_nether_bricks
fill 502 266 458 503 266 458 minecraft:orange_concrete
fill 503 266 416 504 266 416 minecraft:orange_concrete
fill 503 266 429 504 267 429 minecraft:shroomlight
fill 503 266 442 503 270 442 minecraft:red_nether_bricks
fill 504 266 458 505 271 458 minecraft:netherrack
fill 505 266 416 505 271 416 minecraft:netherrack
fill 505 266 442 506 272 442 minecraft:red_nether_bricks
fill 505 266 445 505 267 446 minecraft:red_nether_bricks
fill 506 266 443 506 271 443 minecraft:red_nether_bricks
fill 507 266 416 507 267 416 minecraft:orange_concrete
fill 511 266 458 511 267 458 minecraft:orange_concrete
fill 512 266 417 512 271 418 minecraft:netherrack
fill 512 266 419 512 267 420 minecraft:orange_concrete
setblock 512 266 428 minecraft:orange_concrete
fill 512 266 429 512 271 430 minecraft:netherrack
fill 512 266 431 512 267 432 minecraft:orange_concrete
fill 512 266 437 512 271 438 minecraft:netherrack
fill 512 266 439 512 266 440 minecraft:orange_concrete
fill 512 266 441 512 271 441 minecraft:netherrack
fill 512 266 449 512 271 450 minecraft:netherrack
fill 512 266 451 512 267 452 minecraft:orange_concrete
fill 512 266 458 512 271 458 minecraft:netherrack
fill 470 267 418 470 269 419 minecraft:netherrack
fill 470 267 434 470 267 435 minecraft:orange_concrete
setblock 470 267 438 minecraft:orange_concrete
fill 470 267 439 470 270 439 minecraft:netherrack
fill 470 267 450 470 270 450 minecraft:netherrack
fill 470 267 454 470 269 454 minecraft:netherrack
setblock 470 267 455 minecraft:orange_concrete
fill 472 267 416 472 270 416 minecraft:netherrack
setblock 476 267 416 minecraft:orange_concrete
setblock 478 267 458 minecraft:orange_concrete
fill 482 267 458 483 270 458 minecraft:netherrack
fill 483 267 416 483 270 416 minecraft:netherrack
setblock 484 267 416 minecraft:orange_concrete
setblock 487 267 416 minecraft:orange_concrete
setblock 499 267 458 minecraft:orange_concrete
setblock 502 267 446 minecraft:red_nether_bricks
fill 502 267 447 503 269 447 minecraft:magma_block
setblock 502 267 458 minecraft:orange_concrete
fill 503 267 416 504 270 416 minecraft:netherrack
fill 503 267 458 503 270 458 minecraft:netherrack
fill 504 267 441 506 273 441 minecraft:red_nether_bricks
fill 507 267 442 507 270 443 minecraft:red_nether_bricks
setblock 508 267 416 minecraft:orange_concrete
setblock 510 267 458 minecraft:orange_concrete
setblock 512 267 423 minecraft:orange_concrete
fill 512 267 428 512 270 428 minecraft:netherrack
fill 512 267 439 512 270 439 minecraft:netherrack
setblock 512 267 440 minecraft:orange_concrete
fill 512 267 443 512 267 444 minecraft:orange_concrete
setblock 470 268 416 minecraft:orange_concrete
fill 470 268 424 470 269 425 minecraft:orange_concrete
fill 470 268 426 470 285 427 minecraft:netherrack
fill 470 268 433 470 269 433 minecraft:orange_concrete
fill 470 268 434 470 269 435 minecraft:netherrack
fill 470 268 436 470 268 437 minecraft:orange_concrete
fill 470 268 438 470 285 438 minecraft:netherrack
fill 470 268 444 470 269 445 minecraft:orange_concrete
fill 470 268 446 470 286 447 minecraft:netherrack
fill 470 268 455 470 289 455 minecraft:netherrack
fill 470 268 456 470 268 457 minecraft:orange_concrete
fill 470 268 458 471 285 458 minecraft:netherrack
fill 475 268 416 476 286 416 minecraft:netherrack
fill 476 268 458 477 269 458 minecraft:orange_concrete
fill 477 268 416 478 269 416 minecraft:orange_concrete
fill 478 268 458 479 286 458 minecraft:netherrack
setblock 480 268 458 minecraft:orange_concrete
fill 484 268 416 484 285 416 minecraft:netherrack
fill 485 268 416 486 268 416 minecraft:orange_concrete
fill 487 268 416 487 289 416 minecraft:netherrack
fill 488 268 458 489 269 458 minecraft:orange_concrete
fill 489 268 416 489 269 416 minecraft:orange_concrete
fill 490 268 458 491 285 458 minecraft:netherrack
fill 494 268 417 494 268 421 minecraft:magma_block
fill 495 268 416 496 285 416 minecraft:netherrack
fill 497 268 416 498 269 416 minecraft:orange_concrete
fill 497 268 458 497 269 458 minecraft:orange_concrete
fill 499 268 458 499 289 458 minecraft:netherrack
fill 500 268 458 501 268 458 minecraft:orange_concrete
fill 502 268 446 503 268 446 minecraft:magma_block
fill 502 268 458 502 285 458 minecraft:netherrack
fill 503 268 441 503 271 441 minecraft:red_nether_bricks
fill 504 268 440 506 273 440 minecraft:red_nether_bricks
fill 505 268 445 505 269 445 minecraft:red_nether_bricks
setblock 506 268 416 minecraft:orange_concrete
fill 507 268 416 508 286 416 minecraft:netherrack
fill 507 268 441 507 273 441 minecraft:red_nether_bricks
setblock 507 268 444 minecraft:red_nether_bricks
fill 508 268 458 509 269 458 minecraft:orange_concrete
fill 509 268 416 510 269 416 minecraft:orange_concrete
fill 510 268 458 511 286 458 minecraft:netherrack
fill 512 268 419 512 285 420 minecraft:netherrack
fill 512 268 421 512 268 422 minecraft:orange_concrete
fill 512 268 423 512 289 423 minecraft:netherrack
fill 512 268 431 512 286 432 minecraft:netherrack
fill 512 268 433 512 269 434 minecraft:orange_concrete
fill 512 268 440 512 285 440 minecraft:netherrack
setblock 512 268 442 minecraft:orange_concrete
fill 512 268 443 512 289 444 minecraft:netherrack
fill 512 268 445 512 269 445 minecraft:orange_concrete
fill 512 268 451 512 285 452 minecraft:netherrack
fill 512 268 453 512 268 454 minecraft:orange_concrete
fill 470 269 416 470 271 416 minecraft:netherrack
setblock 470 269 421 minecraft:orange_concrete
setblock 470 269 432 minecraft:orange_concrete
fill 470 269 436 470 271 437 minecraft:netherrack
fill 470 269 452 470 269 453 minecraft:orange_concrete
setblock 470 269 456 minecraft:orange_concrete
fill 470 269 457 470 272 457 minecraft:netherrack
fill 480 269 458 480 272 458 minecraft:netherrack
fill 485 269 416 486 272 416 minecraft:netherrack
setblock 485 269 458 minecraft:orange_concrete
setblock 490 269 416 minecraft:orange_concrete
fill 490 269 448 490 270 450 minecraft:netherrack
fill 491 269 448 491 270 449 minecraft:netherrack
fill 493 269 417 495 269 419 minecraft:magma_block
setblock 494 269 420 minecraft:magma_block
setblock 496 269 458 minecraft:orange_concrete
fill 500 269 458 501 272 458 minecraft:netherrack
setblock 501 269 416 minecraft:orange_concrete
setblock 502 269 446 minecraft:magma_block
fill 503 269 444 504 269 444 minecraft:red_nether_bricks
fill 504 269 439 506 273 439 minecraft:red_nether_bricks
setblock 504 269 445 minecraft:red_nether_bricks
fill 506 269 416 506 272 416 minecraft:netherrack
fill 506 269 444 506 270 444 minecraft:red_nether_bricks
fill 507 269 440 507 273 440 minecraft:red_nether_bricks
fill 512 269 421 512 272 421 minecraft:netherrack
setblock 512 269 422 minecraft:orange_concrete
fill 512 269 425 512 269 426 minecraft:orange_concrete
fill 512 269 442 512 272 442 minecraft:netherrack
setblock 512 269 446 minecraft:orange_concrete
fill 512 269 453 512 272 453 minecraft:netherrack
setblock 512 269 454 minecraft:orange_concrete
setblock 512 269 457 minecraft:orange_concrete
setblock 470 270 418 minecraft:netherrack
fill 470 270 419 470 271 419 minecraft:orange_concrete
fill 470 270 421 470 283 421 minecraft:netherrack
fill 470 270 422 470 270 423 minecraft:orange_concrete
fill 470 270 424 470 272 425 minecraft:netherrack
fill 470 270 430 470 271 431 minecraft:orange_concrete
fill 470 270 432 470 283 433 minecraft:netherrack
setblock 470 270 434 minecraft:orange_concrete
fill 470 270 435 470 289 435 minecraft:netherrack
fill 470 270 442 470 271 443 minecraft:orange_concrete
fill 470 270 444 470 283 445 minecraft:netherrack
fill 470 270 451 470 271 451 minecraft:orange_concrete
fill 470 270 452 470 283 453 minecraft:netherrack
setblock 470 270 454 minecraft:orange_concrete
fill 470 270 456 470 287 456 minecraft:netherrack
fill 471 270 416 471 271 416 minecraft:orange_concrete
fill 471 270 417 473 270 417 minecraft:red_nether_bricks
fill 471 270 419 471 270 421 minecraft:red_nether_bricks
fill 471 270 423 471 270 425 minecraft:red_nether_bricks
fill 471 270 427 471 270 429 minecraft:red_nether_bricks
fill 471 270 431 471 270 433 minecraft:red_nether_bricks
fill 471 270 435 471 270 437 minecraft:red_nether_bricks
fill 471 270 439 471 270 441 minecraft:red_nether_bricks
fill 471 270 443 471 270 445 minecraft:red_nether_bricks
fill 471 270 447 471 270 449 minecraft:red_nether_bricks
fill 471 270 451 471 270 453 minecraft:red_nether_bricks
fill 471 270 455 471 270 457 minecraft:red_nether_bricks
fill 473 270 457 475 270 457 minecraft:red_nether_bricks
fill 474 270 458 475 271 458 minecraft:orange_concrete
fill 475 270 417 477 270 417 minecraft:red_nether_bricks
fill 476 270 458 477 283 458 minecraft:netherrack
fill 477 270 416 478 283 416 minecraft:netherrack
fill 477 270 457 479 270 457 minecraft:red_nether_bricks
fill 479 270 416 480 271 416 minecraft:orange_concrete
fill 479 270 417 481 270 417 minecraft:red_nether_bricks
fill 481 270 457 483 270 457 minecraft:red_nether_bricks
fill 483 270 417 485 270 417 minecraft:red_nether_bricks
fill 485 270 457 487 270 457 minecraft:red_nether_bricks
fill 485 270 458 485 283 458 minecraft:netherrack
fill 486 270 458 487 270 458 minecraft:orange_concrete
fill 487 270 417 489 270 417 minecraft:red_nether_bricks
setblock 488 270 416 minecraft:orange_concrete
fill 488 270 458 489 287 458 minecraft:netherrack
fill 489 270 416 490 283 416 minecraft:netherrack
fill 489 270 457 491 270 457 minecraft:red_nether_bricks
fill 491 270 416 492 271 416 minecraft:orange_concrete
fill 491 270 417 493 270 417 minecraft:red_nether_bricks
fill 493 270 418 495 270 418 minecraft:magma_block
fill 493 270 457 495 270 457 minecraft:red_nether_bricks
fill 494 270 417 494 271 417 minecraft:magma_block
setblock 494 270 419 minecraft:magma_block
fill 494 270 458 495 271 458 minecraft:orange_concrete
fill 495 270 417 497 270 417 minecraft:red_nether_bricks
fill 496 270 458 497 283 458 minecraft:netherrack
fill 497 270 416 498 287 416 minecraft:netherrack
fill 497 270 457 499 270 457 minecraft:red_nether_bricks
setblock 498 270 458 minecraft:orange_concrete
fill 499 270 416 500 270 416 minecraft:orange_concrete
fill 499 270 417 501 270 417 minecraft:red_nether_bricks
fill 501 270 416 501 283 416 minecraft:netherrack
fill 501 270 457 503 270 457 minecraft:red_nether_bricks
fill 503 270 417 505 270 417 minecraft:red_nether_bricks
fill 503 270 440 503 272 440 minecraft:red_nether_bricks
setblock 504 270 444 minecraft:red_nether_bricks
fill 505 270 438 506 273 438 minecraft:red_nether_bricks
fill 505 270 457 507 270 457 minecraft:red_nether_bricks
fill 506 270 458 507 271 458 minecraft:orange_concrete
fill 507 270 417 509 270 417 minecraft:red_nether_bricks
fill 507 270 439 507 273 439 minecraft:red_nether_bricks
fill 508 270 458 509 283 458 minecraft:netherrack
fill 509 270 416 510 283 416 minecraft:netherrack
fill 509 270 457 511 270 457 minecraft:red_nether_bricks
fill 511 270 416 512 271 416 minecraft:orange_concrete
fill 511 270 417 511 270 419 minecraft:red_nether_bricks
fill 511 270 421 511 270 423 minecraft:red_nether_bricks
fill 511 270 425 511 270 427 minecraft:red_nether_bricks
fill 511 270 429 511 270 431 minecraft:red_nether_bricks
fill 511 270 433 511 270 435 minecraft:red_nether_bricks
fill 511 270 437 511 270 439 minecraft:red_nether_bricks
fill 511 270 441 511 270 443 minecraft:red_nether_bricks
fill 511 270 445 511 270 447 minecraft:red_nether_bricks
fill 511 270 449 511 270 451 minecraft:red_nether_bricks
fill 511 270 453 511 270 455 minecraft:red_nether_bricks
fill 512 270 422 512 287 422 minecraft:netherrack
setblock 512 270 424 minecraft:orange_concrete
fill 512 270 425 512 283 426 minecraft:netherrack
fill 512 270 427 512 271 427 minecraft:orange_concrete
fill 512 270 433 512 283 434 minecraft:netherrack
fill 512 270 435 512 270 436 minecraft:orange_concrete
fill 512 270 445 512 283 446 minecraft:netherrack
fill 512 270 447 512 271 448 minecraft:orange_concrete
fill 512 270 454 512 287 454 minecraft:netherrack
fill 512 270 455 512 270 456 minecraft:orange_concrete
fill 512 270 457 512 283 457 minecraft:netherrack
setblock 470 271 418 minecraft:orange_concrete
setblock 470 271 422 minecraft:orange_concrete
fill 470 271 423 470 289 423 minecraft:netherrack
fill 470 271 434 470 289 434 minecraft:netherrack
setblock 470 271 439 minecraft:orange_concrete
setblock 470 271 450 minecraft:orange_concrete
fill 470 271 454 470 289 454 minecraft:netherrack
setblock 472 271 416 minecraft:orange_concrete
fill 482 271 458 483 271 458 minecraft:orange_concrete
setblock 483 271 416 minecraft:orange_concrete
setblock 486 271 458 minecraft:orange_concrete
fill 487 271 458 487 289 458 minecraft:netherrack
fill 488 271 416 488 289 416 minecraft:netherrack
fill 498 271 458 498 289 458 minecraft:netherrack
fill 499 271 416 499 289 416 minecraft:netherrack
setblock 500 271 416 minecraft:orange_concrete
fill 503 271 416 504 271 416 minecraft:orange_concrete
setblock 503 271 458 minecraft:orange_concrete
fill 504 271 438 504 273 438 minecraft:red_nether_bricks
setblock 504 271 443 minecraft:red_nether_bricks
fill 505 271 437 506 273 437 minecraft:red_nether_bricks
fill 507 271 438 507 273 438 minecraft:red_nether_bricks
fill 507 271 442 507 272 442 minecraft:red_nether_bricks
fill 508 271 440 508 272 440 minecraft:red_nether_bricks
fill 512 271 424 512 289 424 minecraft:netherrack
setblock 512 271 428 minecraft:orange_concrete
fill 512 271 435 512 289 435 minecraft:netherrack
setblock 512 271 436 minecraft:orange_concrete
setblock 512 271 439 minecraft:orange_concrete
fill 512 271 455 512 289 456 minecraft:netherrack
fill 470 272 416 470 273 417 minecraft:orange_concrete
fill 470 272 418 470 285 419 minecraft:netherrack
setblock 470 272 420 minecraft:orange_concrete
fill 470 272 422 470 289 422 minecraft:netherrack
fill 470 272 428 470 273 429 minecraft:orange_concrete
fill 470 272 430 470 285 431 minecraft:netherrack
setblock 470 272 436 minecraft:netherrack
fill 470 272 437 470 273 437 minecraft:orange_concrete
fill 470 272 439 470 285 439 minecraft:netherrack
fill 470 272 440 470 272 441 minecraft:orange_concrete
fill 470 272 442 470 289 443 minecraft:netherrack
fill 470 272 448 470 273 449 minecraft:orange_concrete
fill 470 272 450 470 285 451 minecraft:netherrack
fill 471 272 416 472 285 416 minecraft:netherrack
fill 472 272 458 473 272 458 minecraft:orange_concrete
fill 473 272 416 474 273 416 minecraft:orange_concrete
setblock 473 272 419 minecraft:light[level=14]
setblock 473 272 427 minecraft:light[level=14]
setblock 473 272 435 minecraft:light[level=14]
setblock 473 272 443 minecraft:light[level=14]
setblock 473 272 451 minecraft:light[level=14]
fill 474 272 458 475 285 458 minecraft:netherrack
fill 479 272 416 480 289 416 minecraft:netherrack
fill 481 272 416 482 272 416 minecraft:orange_concrete
setblock 481 272 419 minecraft:light[level=14]
setblock 481 272 427 minecraft:light[level=14]
setblock 481 272 435 minecraft:light[level=14]
setblock 481 272 443 minecraft:light[level=14]
setblock 481 272 451 minecraft:light[level=14]
fill 481 272 458 481 273 458 minecraft:orange_concrete
fill 482 272 458 483 285 458 minecraft:netherrack
fill 483 272 416 483 285 416 minecraft:netherrack
setblock 484 272 458 minecraft:orange_concrete
fill 486 272 458 486 289 458 minecraft:netherrack
setblock 489 272 419 minecraft:light[level=14]
setblock 489 272 427 minecraft:light[level=14]
setblock 489 272 435 minecraft:light[level=14]
setblock 489 272 443 minecraft:light[level=14]
setblock 489 272 451 minecraft:light[level=14]
fill 491 272 416 492 285 416 minecraft:netherrack
fill 492 272 458 493 273 458 minecraft:orange_concrete
fill 493 272 416 494 273 416 minecraft:orange_concrete
fill 494 272 458 495 285 458 minecraft:netherrack
setblock 497 272 419 minecraft:light[level=14]
setblock 497 272 427 minecraft:light[level=14]
setblock 497 272 435 minecraft:light[level=14]
setblock 497 272 443 minecraft:light[level=14]
setblock 497 272 451 minecraft:light[level=14]
fill 500 272 416 500 289 416 minecraft:netherrack
setblock 502 272 416 minecraft:orange_concrete
fill 503 272 416 504 285 416 minecraft:netherrack
fill 503 272 458 503 285 458 minecraft:netherrack
fill 504 272 437 504 273 437 minecraft:red_nether_bricks
fill 504 272 458 505 272 458 minecraft:orange_concrete
fill 505 272 416 505 273 416 minecraft:orange_concrete
setblock 505 272 419 minecraft:light[level=14]
setblock 505 272 427 minecraft:light[level=14]
setblock 505 272 435 minecraft:light[level=14]
fill 505 272 436 506 273 436 minecraft:red_nether_bricks
setblock 505 272 443 minecraft:light[level=14]
setblock 505 272 451 minecraft:light[level=14]
fill 506 272 458 507 289 458 minecraft:netherrack
fill 507 272 437 507 273 437 minecraft:red_nether_bricks
fill 508 272 438 508 273 439 minecraft:red_nether_bricks
fill 511 272 416 512 285 416 minecraft:netherrack
fill 512 272 417 512 272 418 minecraft:orange_concrete
fill 512 272 427 512 285 428 minecraft:netherrack
fill 512 272 429 512 273 430 minecraft:orange_concrete
fill 512 272 436 512 289 436 minecraft:netherrack
fill 512 272 437 512 272 438 minecraft:orange_concrete
fill 512 272 439 512 285 439 minecraft:netherrack
fill 512 272 441 512 273 441 minecraft:orange_concrete
fill 512 272 447 512 285 448 minecraft:netherrack
fill 512 272 449 512 273 450 minecraft:orange_concrete
fill 512 272 458 512 273 458 minecraft:orange_concrete
fill 470 273 420 470 283 420 minecraft:netherrack
fill 470 273 424 470 287 424 minecraft:netherrack
setblock 470 273 425 minecraft:orange_concrete
setblock 470 273 436 minecraft:orange_concrete
setblock 470 273 440 minecraft:orange_concrete
fill 470 273 441 470 283 441 minecraft:netherrack
setblock 470 273 457 minecraft:orange_concrete
setblock 472 273 458 minecraft:orange_concrete
fill 473 273 458 473 283 458 minecraft:netherrack
setblock 480 273 458 minecraft:orange_concrete
fill 481 273 416 481 283 416 minecraft:netherrack
setblock 482 273 416 minecraft:orange_concrete
fill 484 273 458 484 283 458 minecraft:netherrack
fill 485 273 416 486 273 416 minecraft:orange_concrete
fill 500 273 458 501 273 458 minecraft:orange_concrete
fill 502 273 416 502 283 416 minecraft:netherrack
setblock 504 273 458 minecraft:orange_concrete
fill 505 273 458 505 283 458 minecraft:netherrack
setblock 506 273 416 minecraft:orange_concrete
setblock 506 273 435 minecraft:red_nether_bricks
setblock 507 273 436 minecraft:red_nether_bricks
setblock 508 273 437 minecraft:red_nether_bricks
fill 512 273 417 512 283 417 minecraft:netherrack
setblock 512 273 418 minecraft:orange_concrete
setblock 512 273 421 minecraft:orange_concrete
fill 512 273 437 512 283 438 minecraft:netherrack
setblock 512 273 442 minecraft:orange_concrete
setblock 512 273 453 minecraft:orange_concrete
fill 470 274 416 470 287 417 minecraft:netherrack
fill 470 274 425 470 287 425 minecraft:netherrack
fill 470 274 428 470 284 429 minecraft:netherrack
fill 470 274 436 470 287 437 minecraft:netherrack
fill 470 274 440 470 283 440 minecraft:netherrack
fill 470 274 448 470 284 449 minecraft:netherrack
fill 470 274 457 470 287 457 minecraft:netherrack
fill 472 274 458 472 284 458 minecraft:netherrack
fill 473 274 416 474 284 416 minecraft:netherrack
fill 480 274 458 481 287 458 minecraft:netherrack
fill 482 274 416 482 284 416 minecraft:netherrack
fill 485 274 416 486 287 416 minecraft:netherrack
fill 492 274 458 493 284 458 minecraft:netherrack
fill 493 274 416 494 284 416 minecraft:netherrack
fill 500 274 458 501 287 458 minecraft:netherrack
fill 504 274 458 504 284 458 minecraft:netherrack
fill 505 274 416 506 287 416 minecraft:netherrack
fill 512 274 418 512 284 418 minecraft:netherrack
fill 512 274 421 512 287 421 minecraft:netherrack
fill 512 274 429 512 284 430 minecraft:netherrack
fill 512 274 441 512 287 442 minecraft:netherrack
fill 512 274 449 512 284 450 minecraft:netherrack
fill 512 274 453 512 287 453 minecraft:netherrack
fill 512 274 458 512 287 458 minecraft:netherrack
fill 471 279 423 489 279 451 minecraft:nether_bricks
fill 472 279 422 510 279 422 minecraft:nether_bricks
fill 472 279 452 510 279 452 minecraft:nether_bricks
fill 473 279 421 509 279 421 minecraft:nether_bricks
fill 473 279 453 509 279 453 minecraft:nether_bricks
fill 474 279 420 508 279 420 minecraft:nether_bricks
fill 474 279 454 508 279 454 minecraft:nether_bricks
fill 475 279 419 507 279 419 minecraft:nether_bricks
fill 475 279 455 507 279 455 minecraft:nether_bricks
fill 476 279 418 506 279 418 minecraft:nether_bricks
fill 476 279 456 506 279 456 minecraft:nether_bricks
fill 477 279 417 505 279 417 minecraft:nether_bricks
fill 477 279 457 505 279 457 minecraft:nether_bricks
fill 490 279 423 490 279 435 minecraft:nether_bricks
fill 490 279 436 490 279 438 minecraft:magma_block
fill 490 279 439 490 279 451 minecraft:nether_bricks
fill 491 279 423 491 279 434 minecraft:nether_bricks
setblock 491 279 435 minecraft:magma_block
setblock 491 279 439 minecraft:magma_block
fill 491 279 440 491 279 451 minecraft:nether_bricks
fill 492 279 423 511 279 433 minecraft:nether_bricks
fill 492 279 434 493 279 434 minecraft:magma_block
fill 492 279 440 493 279 440 minecraft:magma_block
fill 492 279 441 511 279 451 minecraft:nether_bricks
fill 494 279 434 511 279 434 minecraft:nether_bricks
fill 494 279 440 511 279 440 minecraft:nether_bricks
setblock 495 279 435 minecraft:magma_block
setblock 495 279 439 minecraft:magma_block
fill 496 279 435 511 279 436 minecraft:nether_bricks
setblock 496 279 437 minecraft:magma_block
fill 496 279 438 511 279 439 minecraft:nether_bricks
fill 497 279 437 511 279 437 minecraft:nether_bricks
fill 471 280 417 471 280 423 minecraft:netherrack
fill 471 280 424 471 280 450 minecraft:nether_bricks
fill 471 280 451 471 280 457 minecraft:netherrack
fill 472 280 417 472 280 422 minecraft:netherrack
fill 472 280 423 472 281 423 minecraft:nether_bricks
fill 472 280 424 488 280 450 minecraft:red_nether_bricks
fill 472 280 451 472 281 451 minecraft:nether_bricks
fill 472 280 452 472 280 457 minecraft:netherrack
fill 473 280 417 473 280 420 minecraft:netherrack
fill 473 280 421 473 280 422 minecraft:nether_bricks
fill 473 280 423 509 281 423 minecraft:red_nether_bricks
fill 473 280 451 509 281 451 minecraft:red_nether_bricks
fill 473 280 452 473 280 453 minecraft:nether_bricks
fill 473 280 454 473 280 457 minecraft:netherrack
fill 474 280 417 474 280 419 minecraft:netherrack
setblock 474 280 420 minecraft:nether_bricks
fill 474 280 421 508 280 422 minecraft:red_nether_bricks
fill 474 280 452 508 280 453 minecraft:red_nether_bricks
setblock 474 280 454 minecraft:nether_bricks
fill 474 280 455 474 280 457 minecraft:netherrack
fill 475 280 417 476 280 418 minecraft:netherrack
fill 475 280 419 476 280 419 minecraft:nether_bricks
fill 475 280 420 507 280 420 minecraft:red_nether_bricks
fill 475 280 454 507 280 454 minecraft:red_nether_bricks
fill 475 280 455 476 280 455 minecraft:nether_bricks
fill 475 280 456 476 280 457 minecraft:netherrack
setblock 477 280 417 minecraft:netherrack
fill 477 280 418 477 281 418 minecraft:nether_bricks
fill 477 280 419 505 281 419 minecraft:red_nether_bricks
fill 477 280 455 505 281 455 minecraft:red_nether_bricks
fill 477 280 456 477 281 456 minecraft:nether_bricks
setblock 477 280 457 minecraft:netherrack
fill 478 280 417 504 280 417 minecraft:nether_bricks
fill 478 280 418 504 280 418 minecraft:red_nether_bricks
fill 478 280 456 504 280 456 minecraft:red_nether_bricks
fill 478 280 457 504 280 457 minecraft:nether_bricks
fill 489 280 424 489 280 435 minecraft:red_nether_bricks
fill 489 280 436 489 280 438 minecraft:magma_block
fill 489 280 439 489 280 450 minecraft:red_nether_bricks
fill 490 280 424 491 280 433 minecraft:red_nether_bricks
setblock 490 280 434 minecraft:magma_block
fill 490 280 435 490 280 439 minecraft:shroomlight
setblock 490 280 440 minecraft:magma_block
fill 490 280 441 491 280 450 minecraft:red_nether_bricks
fill 491 280 434 491 280 435 minecraft:shroomlight
fill 491 280 439 491 280 440 minecraft:shroomlight
fill 492 280 424 510 280 432 minecraft:red_nether_bricks
fill 492 280 433 493 280 433 minecraft:magma_block
fill 492 280 434 495 280 434 minecraft:shroomlight
fill 492 280 440 495 280 440 minecraft:shroomlight
fill 492 280 441 493 280 441 minecraft:magma_block
fill 492 280 442 510 280 450 minecraft:red_nether_bricks
fill 494 280 433 510 280 433 minecraft:red_nether_bricks
fill 494 280 441 510 280 441 minecraft:red_nether_bricks
fill 495 280 435 496 280 435 minecraft:shroomlight
fill 495 280 439 496 280 439 minecraft:shroomlight
fill 496 280 434 510 280 434 minecraft:red_nether_bricks
fill 496 280 436 496 280 438 minecraft:shroomlight
fill 496 280 440 510 280 440 minecraft:red_nether_bricks
fill 497 280 435 510 280 436 minecraft:red_nether_bricks
fill 497 280 437 497 281 437 minecraft:magma_block
fill 497 280 438 510 280 439 minecraft:red_nether_bricks
fill 498 280 437 510 281 437 minecraft:red_nether_bricks
fill 505 280 417 511 280 417 minecraft:netherrack
fill 505 280 418 505 281 418 minecraft:nether_bricks
fill 505 280 456 505 281 456 minecraft:nether_bricks
fill 505 280 457 511 280 457 minecraft:netherrack
fill 506 280 418 511 280 418 minecraft:netherrack
fill 506 280 419 507 280 419 minecraft:nether_bricks
fill 506 280 455 507 280 455 minecraft:nether_bricks
fill 506 280 456 511 280 456 minecraft:netherrack
fill 508 280 419 511 280 419 minecraft:netherrack
setblock 508 280 420 minecraft:nether_bricks
setblock 508 280 454 minecraft:nether_bricks
fill 508 280 455 511 280 455 minecraft:netherrack
fill 509 280 420 511 280 420 minecraft:netherrack
fill 509 280 421 509 280 422 minecraft:nether_bricks
fill 509 280 452 509 280 453 minecraft:nether_bricks
fill 509 280 454 511 280 454 minecraft:netherrack
fill 510 280 421 511 280 422 minecraft:netherrack
fill 510 280 423 510 281 423 minecraft:nether_bricks
fill 510 280 451 510 281 451 minecraft:nether_bricks
fill 510 280 452 511 280 453 minecraft:netherrack
setblock 511 280 423 minecraft:netherrack
fill 511 280 424 511 280 450 minecraft:nether_bricks
setblock 511 280 451 minecraft:netherrack
fill 471 281 425 471 281 449 minecraft:nether_bricks
fill 472 281 424 472 282 424 minecraft:nether_bricks
fill 472 281 425 487 281 449 minecraft:red_nether_bricks
fill 472 281 450 472 282 450 minecraft:nether_bricks
setblock 473 281 422 minecraft:nether_bricks
fill 473 281 424 509 282 424 minecraft:red_nether_bricks
fill 473 281 450 509 282 450 minecraft:red_nether_bricks
setblock 473 281 452 minecraft:nether_bricks
setblock 474 281 421 minecraft:nether_bricks
fill 474 281 422 508 281 422 minecraft:red_nether_bricks
fill 474 281 452 508 281 452 minecraft:red_nether_bricks
setblock 474 281 453 minecraft:nether_bricks
setblock 475 281 420 minecraft:nether_bricks
fill 475 281 421 507 281 421 minecraft:red_nether_bricks
fill 475 281 453 507 281 453 minecraft:red_nether_bricks
setblock 475 281 454 minecraft:nether_bricks
setblock 476 281 419 minecraft:nether_bricks
fill 476 281 420 506 281 420 minecraft:red_nether_bricks
fill 476 281 454 506 281 454 minecraft:red_nether_bricks
setblock 476 281 455 minecraft:nether_bricks
fill 478 281 418 478 282 418 minecraft:nether_bricks
fill 478 281 456 478 282 456 minecraft:nether_bricks
fill 479 281 417 503 281 417 minecraft:nether_bricks
fill 479 281 418 503 281 418 minecraft:red_nether_bricks
fill 479 281 456 503 281 456 minecraft:red_nether_bricks
fill 479 281 457 503 281 457 minecraft:nether_bricks
fill 488 281 425 488 281 434 minecraft:red_nether_bricks
fill 488 281 435 488 281 439 minecraft:magma_block
fill 488 281 440 488 281 449 minecraft:red_nether_bricks
fill 489 281 425 489 281 433 minecraft:red_nether_bricks
fill 489 281 434 489 281 435 minecraft:magma_block
fill 489 281 439 489 281 440 minecraft:magma_block
fill 489 281 441 489 281 449 minecraft:red_nether_bricks
fill 490 281 425 491 281 432 minecraft:red_nether_bricks
fill 490 281 433 491 281 433 minecraft:magma_block
fill 490 281 441 491 281 441 minecraft:magma_block
fill 490 281 442 491 281 449 minecraft:red_nether_bricks
fill 492 281 425 510 281 431 minecraft:red_nether_bricks
fill 492 281 432 493 281 432 minecraft:magma_block
fill 492 281 442 493 281 442 minecraft:magma_block
fill 492 281 443 510 281 449 minecraft:red_nether_bricks
fill 494 281 432 510 281 432 minecraft:red_nether_bricks
fill 494 281 433 495 281 433 minecraft:magma_block
fill 494 281 441 495 281 441 minecraft:magma_block
fill 494 281 442 510 281 442 minecraft:red_nether_bricks
fill 496 281 433 510 281 433 minecraft:red_nether_bricks
setblock 496 281 434 minecraft:magma_block
setblock 496 281 440 minecraft:magma_block
fill 496 281 441 510 281 441 minecraft:red_nether_bricks
fill 497 281 434 510 281 434 minecraft:red_nether_bricks
fill 497 281 435 497 281 436 minecraft:magma_block
fill 497 281 438 497 281 439 minecraft:magma_block
fill 497 281 440 510 281 440 minecraft:red_nether_bricks
fill 498 281 435 510 281 436 minecraft:red_nether_bricks
fill 498 281 438 510 281 439 minecraft:red_nether_bricks
fill 504 281 418 504 282 418 minecraft:nether_bricks
fill 504 281 456 504 282 456 minecraft:nether_bricks
setblock 506 281 419 minecraft:nether_bricks
setblock 506 281 455 minecraft:nether_bricks
setblock 507 281 420 minecraft:nether_bricks
setblock 507 281 454 minecraft:nether_bricks
setblock 508 281 421 minecraft:nether_bricks
setblock 508 281 453 minecraft:nether_bricks
setblock 509 281 422 minecraft:nether_bricks
setblock 509 281 452 minecraft:nether_bricks
fill 510 281 424 510 282 424 minecraft:nether_bricks
fill 510 281 450 510 282 450 minecraft:nether_bricks
fill 511 281 425 511 281 449 minecraft:nether_bricks
fill 471 282 426 471 282 448 minecraft:nether_bricks
fill 472 282 425 472 283 425 minecraft:nether_bricks
fill 472 282 426 486 282 448 minecraft:red_nether_bricks
fill 472 282 449 472 283 449 minecraft:nether_bricks
setblock 473 282 423 minecraft:nether_bricks
fill 473 282 425 509 283 425 minecraft:red_nether_bricks
fill 473 282 449 509 283 449 minecraft:red_nether_bricks
setblock 473 282 451 minecraft:nether_bricks
setblock 474 282 422 minecraft:nether_bricks
fill 474 282 423 508 282 423 minecraft:red_nether_bricks
fill 474 282 451 508 282 451 minecraft:red_nether_bricks
setblock 474 282 452 minecraft:nether_bricks
setblock 475 282 421 minecraft:nether_bricks
fill 475 282 422 507 282 422 minecraft:red_nether_bricks
fill 475 282 452 507 282 452 minecraft:red_nether_bricks
setblock 475 282 453 minecraft:nether_bricks
setblock 476 282 420 minecraft:nether_bricks
fill 476 282 421 506 282 421 minecraft:red_nether_bricks
fill 476 282 453 506 282 453 minecraft:red_nether_bricks
setblock 476 282 454 minecraft:nether_bricks
setblock 477 282 419 minecraft:nether_bricks
fill 477 282 420 505 282 420 minecraft:red_nether_bricks
fill 477 282 454 505 282 454 minecraft:red_nether_bricks
setblock 477 282 455 minecraft:nether_bricks
fill 478 282 419 504 282 419 minecraft:red_nether_bricks
fill 478 282 455 504 282 455 minecraft:red_nether_bricks
fill 479 282 418 479 283 418 minecraft:nether_bricks
fill 479 282 456 479 283 456 minecraft:nether_bricks
fill 480 282 417 502 282 417 minecraft:nether_bricks
fill 480 282 418 502 282 418 minecraft:red_nether_bricks
fill 480 282 456 502 282 456 minecraft:red_nether_bricks
fill 480 282 457 502 282 457 minecraft:nether_bricks
fill 487 282 426 487 282 434 minecraft:red_nether_bricks
fill 487 282 435 487 282 439 minecraft:magma_block
fill 487 282 440 487 282 448 minecraft:red_nether_bricks
fill 488 282 426 489 282 432 minecraft:red_nether_bricks
fill 488 282 433 488 282 434 minecraft:magma_block
fill 488 282 440 488 282 441 minecraft:magma_block
fill 488 282 442 489 282 448 minecraft:red_nether_bricks
setblock 489 282 433 minecraft:magma_block
setblock 489 282 441 minecraft:magma_block
fill 490 282 426 491 282 431 minecraft:red_nether_bricks
fill 490 282 432 491 282 432 minecraft:magma_block
fill 490 282 442 491 282 442 minecraft:magma_block
fill 490 282 443 491 282 448 minecraft:red_nether_bricks
fill 492 282 426 510 282 430 minecraft:red_nether_bricks
fill 492 282 431 493 283 431 minecraft:magma_block
fill 492 282 443 493 283 443 minecraft:magma_block
fill 492 282 444 510 282 448 minecraft:red_nether_bricks
fill 494 282 431 510 282 431 minecraft:red_nether_bricks
fill 494 282 432 495 282 432 minecraft:magma_block
fill 494 282 442 495 282 442 minecraft:magma_block
fill 494 282 443 510 282 443 minecraft:red_nether_bricks
fill 496 282 432 510 282 432 minecraft:red_nether_bricks
setblock 496 282 433 minecraft:magma_block
setblock 496 282 441 minecraft:magma_block
fill 496 282 442 510 282 442 minecraft:red_nether_bricks
fill 497 282 433 510 282 433 minecraft:red_nether_bricks
setblock 497 282 434 minecraft:magma_block
setblock 497 282 440 minecraft:magma_block
fill 497 282 441 510 282 441 minecraft:red_nether_bricks
fill 498 282 434 510 282 434 minecraft:red_nether_bricks
fill 498 282 435 498 282 439 minecraft:magma_block
fill 498 282 440 510 282 440 minecraft:red_nether_bricks
fill 499 282 435 510 282 439 minecraft:red_nether_bricks
fill 503 282 418 503 283 418 minecraft:nether_bricks
fill 503 282 456 503 283 456 minecraft:nether_bricks
setblock 505 282 419 minecraft:nether_bricks
setblock 505 282 455 minecraft:nether_bricks
setblock 506 282 420 minecraft:nether_bricks
setblock 506 282 454 minecraft:nether_bricks
setblock 507 282 421 minecraft:nether_bricks
setblock 507 282 453 minecraft:nether_bricks
setblock 508 282 422 minecraft:nether_bricks
setblock 508 282 452 minecraft:nether_bricks
setblock 509 282 423 minecraft:nether_bricks
setblock 509 282 451 minecraft:nether_bricks
fill 510 282 425 510 283 425 minecraft:nether_bricks
fill 510 282 449 510 283 449 minecraft:nether_bricks
fill 511 282 426 511 282 448 minecraft:nether_bricks
fill 471 283 427 471 283 447 minecraft:nether_bricks
fill 472 283 426 472 284 426 minecraft:nether_bricks
fill 472 283 427 485 283 447 minecraft:red_nether_bricks
fill 472 283 448 472 284 448 minecraft:nether_bricks
setblock 473 283 424 minecraft:nether_bricks
fill 473 283 426 509 284 426 minecraft:red_nether_bricks
fill 473 283 448 509 284 448 minecraft:red_nether_bricks
setblock 473 283 450 minecraft:nether_bricks
setblock 474 283 423 minecraft:nether_bricks
fill 474 283 424 508 283 424 minecraft:red_nether_bricks
fill 474 283 450 508 283 450 minecraft:red_nether_bricks
setblock 474 283 451 minecraft:nether_bricks
fill 475 283 422 475 284 422 minecraft:nether_bricks
fill 475 283 423 507 283 423 minecraft:red_nether_bricks
fill 475 283 451 507 283 451 minecraft:red_nether_bricks
fill 475 283 452 475 284 452 minecraft:nether_bricks
fill 476 283 421 476 284 421 minecraft:nether_bricks
fill 476 283 422 506 284 422 minecraft:red_nether_bricks
fill 476 283 452 506 284 452 minecraft:red_nether_bricks
fill 476 283 453 476 284 453 minecraft:nether_bricks
setblock 477 283 420 minecraft:nether_bricks
fill 477 283 421 505 283 421 minecraft:red_nether_bricks
fill 477 283 453 505 283 453 minecraft:red_nether_bricks
setblock 477 283 454 minecraft:nether_bricks
setblock 478 283 419 minecraft:nether_bricks
fill 478 283 420 504 283 420 minecraft:red_nether_bricks
fill 478 283 454 504 283 454 minecraft:red_nether_bricks
setblock 478 283 455 minecraft:nether_bricks
fill 479 283 419 503 283 419 minecraft:red_nether_bricks
fill 479 283 455 503 283 455 minecraft:red_nether_bricks
fill 480 283 418 480 284 418 minecraft:nether_bricks
fill 480 283 456 480 284 456 minecraft:nether_bricks
fill 481 283 417 501 283 417 minecraft:nether_bricks
fill 481 283 418 501 283 418 minecraft:red_nether_bricks
fill 481 283 456 501 283 456 minecraft:red_nether_bricks
fill 481 283 457 501 283 457 minecraft:nether_bricks
fill 486 283 427 486 283 433 minecraft:red_nether_bricks
fill 486 283 434 486 283 440 minecraft:magma_block
fill 486 283 441 486 283 447 minecraft:red_nether_bricks
fill 487 283 427 487 283 432 minecraft:red_nether_bricks
fill 487 283 433 487 283 434 minecraft:magma_block
fill 487 283 440 487 283 441 minecraft:magma_block
fill 487 283 442 487 283 447 minecraft:red_nether_bricks
fill 488 283 427 488 283 431 minecraft:red_nether_bricks
fill 488 283 432 489 283 432 minecraft:magma_block
fill 488 283 442 489 283 442 minecraft:magma_block
fill 488 283 443 488 283 447 minecraft:red_nether_bricks
fill 489 283 427 510 283 430 minecraft:red_nether_bricks
fill 489 283 431 491 283 431 minecraft:magma_block
fill 489 283 443 491 283 443 minecraft:magma_block
fill 489 283 444 510 283 447 minecraft:red_nether_bricks
fill 494 283 431 495 283 431 minecraft:magma_block
fill 494 283 443 495 283 443 minecraft:magma_block
fill 496 283 431 510 283 431 minecraft:red_nether_bricks
setblock 496 283 432 minecraft:magma_block
setblock 496 283 442 minecraft:magma_block
fill 496 283 443 510 283 443 minecraft:red_nether_bricks
fill 497 283 432 510 283 432 minecraft:red_nether_bricks
setblock 497 283 433 minecraft:magma_block
setblock 497 283 441 minecraft:magma_block
fill 497 283 442 510 283 442 minecraft:red_nether_bricks
fill 498 283 433 510 283 433 minecraft:red_nether_bricks
fill 498 283 434 498 283 435 minecraft:magma_block
fill 498 283 439 498 283 440 minecraft:magma_block
fill 498 283 441 510 283 441 minecraft:red_nether_bricks
fill 499 283 434 510 283 435 minecraft:red_nether_bricks
fill 499 283 436 499 283 438 minecraft:magma_block
fill 499 283 439 510 283 440 minecraft:red_nether_bricks
fill 500 283 436 510 283 438 minecraft:red_nether_bricks
fill 502 283 418 502 284 418 minecraft:nether_bricks
fill 502 283 456 502 284 456 minecraft:nether_bricks
setblock 504 283 419 minecraft:nether_bricks
setblock 504 283 455 minecraft:nether_bricks
setblock 505 283 420 minecraft:nether_bricks
setblock 505 283 454 minecraft:nether_bricks
fill 506 283 421 506 284 421 minecraft:nether_bricks
fill 506 283 453 506 284 453 minecraft:nether_bricks
fill 507 283 422 507 284 422 minecraft:nether_bricks
fill 507 283 452 507 284 452 minecraft:nether_bricks
setblock 508 283 423 minecraft:nether_bricks
setblock 508 283 451 minecraft:nether_bricks
setblock 509 283 424 minecraft:nether_bricks
setblock 509 283 450 minecraft:nether_bricks
fill 510 283 426 510 284 426 minecraft:nether_bricks
fill 510 283 448 510 284 448 minecraft:nether_bricks
fill 511 283 427 511 283 447 minecraft:nether_bricks
fill 470 284 420 470 285 421 minecraft:orange_concrete
fill 470 284 432 470 284 433 minecraft:orange_concrete
fill 470 284 440 470 285 441 minecraft:orange_concrete
setblock 470 284 444 minecraft:orange_concrete
fill 470 284 445 470 287 445 minecraft:netherrack
fill 470 284 452 470 285 453 minecraft:orange_concrete
fill 471 284 428 471 284 446 minecraft:nether_bricks
setblock 472 284 427 minecraft:nether_bricks
fill 472 284 428 484 284 446 minecraft:red_nether_bricks
setblock 472 284 447 minecraft:nether_bricks
setblock 473 284 425 minecraft:nether_bricks
fill 473 284 427 509 284 427 minecraft:red_nether_bricks
fill 473 284 447 509 284 447 minecraft:red_nether_bricks
setblock 473 284 449 minecraft:nether_bricks
fill 473 284 458 473 285 458 minecraft:orange_concrete
setblock 474 284 424 minecraft:nether_bricks
fill 474 284 425 508 284 425 minecraft:red_nether_bricks
fill 474 284 449 508 284 449 minecraft:red_nether_bricks
setblock 474 284 450 minecraft:nether_bricks
fill 475 284 423 475 285 423 minecraft:nether_bricks
fill 475 284 424 507 284 424 minecraft:red_nether_bricks
fill 475 284 450 507 284 450 minecraft:red_nether_bricks
fill 475 284 451 475 285 451 minecraft:nether_bricks
fill 476 284 423 506 285 423 minecraft:red_nether_bricks
fill 476 284 451 506 285 451 minecraft:red_nether_bricks
fill 476 284 458 477 284 458 minecraft:orange_concrete
fill 477 284 416 477 287 416 minecraft:netherrack
fill 477 284 421 477 285 421 minecraft:nether_bricks
fill 477 284 453 477 285 453 minecraft:nether_bricks
setblock 478 284 416 minecraft:orange_concrete
setblock 478 284 420 minecraft:nether_bricks
fill 478 284 421 504 284 421 minecraft:red_nether_bricks
fill 478 284 453 504 284 453 minecraft:red_nether_bricks
setblock 478 284 454 minecraft:nether_bricks
setblock 479 284 419 minecraft:nether_bricks
fill 479 284 420 503 284 420 minecraft:red_nether_bricks
fill 479 284 454 503 284 454 minecraft:red_nether_bricks
setblock 479 284 455 minecraft:nether_bricks
fill 480 284 419 502 284 419 minecraft:red_nether_bricks
fill 480 284 455 502 284 455 minecraft:red_nether_bricks
fill 481 284 416 481 285 416 minecraft:orange_concrete
setblock 481 284 418 minecraft:nether_bricks
setblock 481 284 456 minecraft:nether_bricks
fill 482 284 417 500 284 417 minecraft:nether_bricks
fill 482 284 418 500 284 418 minecraft:red_nether_bricks
fill 482 284 456 500 284 456 minecraft:red_nether_bricks
fill 482 284 457 500 284 457 minecraft:nether_bricks
fill 484 284 458 485 285 458 minecraft:orange_concrete
fill 485 284 428 485 284 433 minecraft:red_nether_bricks
fill 485 284 434 485 284 440 minecraft:magma_block
fill 485 284 441 485 284 446 minecraft:red_nether_bricks
fill 486 284 428 486 284 431 minecraft:red_nether_bricks
fill 486 284 432 486 284 433 minecraft:magma_block
fill 486 284 441 486 284 442 minecraft:magma_block
fill 486 284 443 486 284 446 minecraft:red_nether_bricks
fill 487 284 428 488 284 430 minecraft:red_nether_bricks
fill 487 284 431 487 284 432 minecraft:magma_block
fill 487 284 442 487 284 443 minecraft:magma_block
fill 487 284 444 488 284 446 minecraft:red_nether_bricks
setblock 488 284 431 minecraft:magma_block
setblock 488 284 443 minecraft:magma_block
fill 489 284 416 490 284 416 minecraft:orange_concrete
fill 489 284 428 510 284 429 minecraft:red_nether_bricks
fill 489 284 430 495 284 430 minecraft:magma_block
fill 489 284 444 495 284 444 minecraft:magma_block
fill 489 284 445 510 284 446 minecraft:red_nether_bricks
fill 496 284 430 510 284 430 minecraft:red_nether_bricks
fill 496 284 431 497 284 431 minecraft:magma_block
fill 496 284 443 497 284 443 minecraft:magma_block
fill 496 284 444 510 284 444 minecraft:red_nether_bricks
fill 496 284 458 497 284 458 minecraft:orange_concrete
fill 497 284 432 498 284 432 minecraft:magma_block
fill 497 284 442 498 284 442 minecraft:magma_block
fill 498 284 431 510 284 431 minecraft:red_nether_bricks
setblock 498 284 433 minecraft:magma_block
setblock 498 284 441 minecraft:magma_block
fill 498 284 443 510 284 443 minecraft:red_nether_bricks
fill 499 284 432 510 284 433 minecraft:red_nether_bricks
fill 499 284 434 499 284 435 minecraft:magma_block
fill 499 284 439 499 284 440 minecraft:magma_block
fill 499 284 441 510 284 442 minecraft:red_nether_bricks
fill 500 284 434 510 284 435 minecraft:red_nether_bricks
fill 500 284 436 500 285 438 minecraft:magma_block
fill 500 284 439 510 284 440 minecraft:red_nether_bricks
fill 501 284 416 502 285 416 minecraft:orange_concrete
setblock 501 284 418 minecraft:nether_bricks
fill 501 284 436 510 285 438 minecraft:red_nether_bricks
setblock 501 284 456 minecraft:nether_bricks
setblock 503 284 419 minecraft:nether_bricks
setblock 503 284 455 minecraft:nether_bricks
setblock 504 284 420 minecraft:nether_bricks
setblock 504 284 454 minecraft:nether_bricks
fill 505 284 421 505 285 421 minecraft:nether_bricks
fill 505 284 453 505 285 453 minecraft:nether_bricks
fill 505 284 458 505 285 458 minecraft:orange_concrete
fill 507 284 423 507 285 423 minecraft:nether_bricks
fill 507 284 451 507 285 451 minecraft:nether_bricks
setblock 508 284 424 minecraft:nether_bricks
setblock 508 284 450 minecraft:nether_bricks
setblock 508 284 458 minecraft:orange_concrete
fill 509 284 416 510 284 416 minecraft:orange_concrete
setblock 509 284 425 minecraft:nether_bricks
setblock 509 284 449 minecraft:nether_bricks
fill 509 284 458 509 287 458 minecraft:netherrack
setblock 510 284 427 minecraft:nether_bricks
setblock 510 284 447 minecraft:nether_bricks
fill 511 284 428 511 284 446 minecraft:nether_bricks
fill 512 284 417 512 285 417 minecraft:orange_concrete
fill 512 284 425 512 285 426 minecraft:orange_concrete
fill 512 284 433 512 287 433 minecraft:netherrack
setblock 512 284 434 minecraft:orange_concrete
fill 512 284 437 512 285 438 minecraft:orange_concrete
fill 512 284 445 512 284 446 minecraft:orange_concrete
fill 512 284 457 512 285 457 minecraft:orange_concrete
fill 470 285 428 470 285 429 minecraft:orange_concrete
setblock 470 285 432 minecraft:orange_concrete
fill 470 285 433 470 288 433 minecraft:netherrack
fill 470 285 444 470 288 444 minecraft:netherrack
fill 470 285 448 470 287 448 minecraft:netherrack
setblock 470 285 449 minecraft:orange_concrete
fill 471 285 430 471 285 444 minecraft:nether_bricks
fill 472 285 428 472 285 429 minecraft:nether_bricks
fill 472 285 430 483 285 444 minecraft:red_nether_bricks
fill 472 285 445 472 285 446 minecraft:nether_bricks
setblock 472 285 458 minecraft:orange_concrete
setblock 473 285 416 minecraft:orange_concrete
fill 473 285 426 473 285 427 minecraft:nether_bricks
fill 473 285 428 488 285 429 minecraft:red_nether_bricks
fill 473 285 445 488 285 446 minecraft:red_nether_bricks
fill 473 285 447 473 285 448 minecraft:nether_bricks
fill 474 285 416 474 287 416 minecraft:netherrack
setblock 474 285 425 minecraft:nether_bricks
fill 474 285 426 508 285 427 minecraft:red_nether_bricks
fill 474 285 447 508 285 448 minecraft:red_nether_bricks
setblock 474 285 449 minecraft:nether_bricks
fill 475 285 424 475 286 424 minecraft:nether_bricks
fill 475 285 425 507 285 425 minecraft:red_nether_bricks
fill 475 285 449 507 285 449 minecraft:red_nether_bricks
fill 475 285 450 475 286 450 minecraft:nether_bricks
setblock 476 285 422 minecraft:nether_bricks
fill 476 285 424 506 286 424 minecraft:red_nether_bricks
fill 476 285 450 506 286 450 minecraft:red_nether_bricks
setblock 476 285 452 minecraft:nether_bricks
fill 476 285 458 477 288 458 minecraft:netherrack
fill 477 285 422 505 285 422 minecraft:red_nether_bricks
fill 477 285 452 505 285 452 minecraft:red_nether_bricks
fill 478 285 416 478 288 416 minecraft:netherrack
fill 478 285 421 478 286 421 minecraft:nether_bricks
fill 478 285 453 478 286 453 minecraft:nether_bricks
setblock 479 285 420 minecraft:nether_bricks
fill 479 285 421 503 285 421 minecraft:red_nether_bricks
fill 479 285 453 503 285 453 minecraft:red_nether_bricks
setblock 479 285 454 minecraft:nether_bricks
fill 480 285 419 481 285 419 minecraft:nether_bricks
fill 480 285 420 502 285 420 minecraft:red_nether_bricks
fill 480 285 454 502 285 454 minecraft:red_nether_bricks
fill 480 285 455 481 285 455 minecraft:nether_bricks
setblock 482 285 416 minecraft:orange_concrete
fill 482 285 418 483 285 418 minecraft:nether_bricks
fill 482 285 419 500 285 419 minecraft:red_nether_bricks
fill 482 285 455 500 285 455 minecraft:red_nether_bricks
fill 482 285 456 483 285 456 minecraft:nether_bricks
fill 484 285 417 498 285 417 minecraft:nether_bricks
fill 484 285 418 498 285 418 minecraft:red_nether_bricks
fill 484 285 430 484 285 432 minecraft:red_nether_bricks
fill 484 285 433 484 285 441 minecraft:magma_block
fill 484 285 442 484 285 444 minecraft:red_nether_bricks
fill 484 285 456 498 285 456 minecraft:red_nether_bricks
fill 484 285 457 498 285 457 minecraft:nether_bricks
fill 485 285 430 485 285 431 minecraft:red_nether_bricks
fill 485 285 432 485 285 433 minecraft:magma_block
fill 485 285 441 485 285 442 minecraft:magma_block
fill 485 285 443 485 285 444 minecraft:red_nether_bricks
setblock 486 285 430 minecraft:red_nether_bricks
setblock 486 285 431 minecraft:magma_block
setblock 486 285 443 minecraft:magma_block
setblock 486 285 444 minecraft:red_nether_bricks
fill 487 285 430 488 285 430 minecraft:magma_block
fill 487 285 444 488 285 444 minecraft:magma_block
fill 489 285 416 489 288 416 minecraft:netherrack
fill 489 285 428 509 285 428 minecraft:red_nether_bricks
fill 489 285 429 495 285 429 minecraft:magma_block
fill 489 285 445 495 285 445 minecraft:magma_block
fill 489 285 446 509 285 446 minecraft:red_nether_bricks
setblock 490 285 416 minecraft:orange_concrete
fill 492 285 458 492 287 458 minecraft:netherrack
setblock 493 285 416 minecraft:orange_concrete
setblock 493 285 458 minecraft:orange_concrete
fill 494 285 416 494 287 416 minecraft:netherrack
fill 496 285 429 509 285 429 minecraft:red_nether_bricks
fill 496 285 430 497 285 430 minecraft:magma_block
fill 496 285 444 497 285 444 minecraft:magma_block
fill 496 285 445 509 285 445 minecraft:red_nether_bricks
setblock 496 285 458 minecraft:orange_concrete
fill 497 285 458 497 288 458 minecraft:netherrack
fill 498 285 430 510 285 430 minecraft:red_nether_bricks
setblock 498 285 431 minecraft:magma_block
setblock 498 285 443 minecraft:magma_block
fill 498 285 444 510 285 444 minecraft:red_nether_bricks
fill 499 285 418 500 285 418 minecraft:nether_bricks
fill 499 285 431 510 285 431 minecraft:red_nether_bricks
fill 499 285 432 499 285 433 minecraft:magma_block
fill 499 285 441 499 285 442 minecraft:magma_block
fill 499 285 443 510 285 443 minecraft:red_nether_bricks
fill 499 285 456 500 285 456 minecraft:nether_bricks
fill 500 285 432 510 285 433 minecraft:red_nether_bricks
fill 500 285 434 500 285 435 minecraft:magma_block
fill 500 285 439 500 285 440 minecraft:magma_block
fill 500 285 441 510 285 442 minecraft:red_nether_bricks
fill 501 285 419 502 285 419 minecraft:nether_bricks
fill 501 285 434 510 285 435 minecraft:red_nether_bricks
fill 501 285 439 510 285 440 minecraft:red_nether_bricks
fill 501 285 455 502 285 455 minecraft:nether_bricks
setblock 503 285 420 minecraft:nether_bricks
setblock 503 285 454 minecraft:nether_bricks
fill 504 285 421 504 286 421 minecraft:nether_bricks
fill 504 285 453 504 286 453 minecraft:nether_bricks
setblock 504 285 458 minecraft:orange_concrete
setblock 506 285 422 minecraft:nether_bricks
setblock 506 285 452 minecraft:nether_bricks
fill 507 285 424 507 286 424 minecraft:nether_bricks
fill 507 285 450 507 286 450 minecraft:nether_bricks
setblock 508 285 425 minecraft:nether_bricks
setblock 508 285 449 minecraft:nether_bricks
fill 508 285 458 508 288 458 minecraft:netherrack
fill 509 285 416 510 288 416 minecraft:netherrack
fill 509 285 426 509 285 427 minecraft:nether_bricks
fill 509 285 447 509 285 448 minecraft:nether_bricks
fill 510 285 428 510 285 429 minecraft:nether_bricks
fill 510 285 445 510 285 446 minecraft:nether_bricks
fill 511 285 430 511 285 444 minecraft:nether_bricks
setblock 512 285 418 minecraft:orange_concrete
setblock 512 285 429 minecraft:orange_concrete
fill 512 285 430 512 287 430 minecraft:netherrack
fill 512 285 434 512 288 434 minecraft:netherrack
fill 512 285 445 512 288 445 minecraft:netherrack
setblock 512 285 446 minecraft:orange_concrete
fill 512 285 449 512 285 450 minecraft:orange_concrete
fill 470 286 418 470 287 419 minecraft:orange_concrete
fill 470 286 420 470 291 421 minecraft:netherrack
setblock 470 286 426 minecraft:netherrack
fill 470 286 427 470 287 427 minecraft:orange_concrete
fill 470 286 428 470 291 429 minecraft:netherrack
setblock 470 286 430 minecraft:orange_concrete
fill 470 286 431 470 289 432 minecraft:netherrack
fill 470 286 438 470 287 439 minecraft:orange_concrete
fill 470 286 440 470 291 441 minecraft:netherrack
fill 470 286 449 470 291 449 minecraft:netherrack
fill 470 286 450 470 286 451 minecraft:orange_concrete
fill 470 286 452 470 291 453 minecraft:netherrack
fill 470 286 458 471 287 458 minecraft:orange_concrete
fill 471 286 416 472 286 416 minecraft:orange_concrete
fill 471 286 432 471 286 442 minecraft:nether_bricks
fill 472 286 429 472 286 431 minecraft:nether_bricks
fill 472 286 432 481 286 442 minecraft:red_nether_bricks
fill 472 286 443 472 286 445 minecraft:nether_bricks
fill 472 286 458 473 291 458 minecraft:netherrack
fill 473 286 416 473 287 416 minecraft:netherrack
fill 473 286 427 473 286 428 minecraft:nether_bricks
fill 473 286 429 483 286 431 minecraft:red_nether_bricks
fill 473 286 443 483 286 445 minecraft:red_nether_bricks
fill 473 286 446 473 286 447 minecraft:nether_bricks
setblock 474 286 426 minecraft:nether_bricks
fill 474 286 427 487 286 428 minecraft:red_nether_bricks
fill 474 286 446 487 286 447 minecraft:red_nether_bricks
setblock 474 286 448 minecraft:nether_bricks
setblock 474 286 458 minecraft:orange_concrete
setblock 475 286 425 minecraft:nether_bricks
fill 475 286 426 507 286 426 minecraft:red_nether_bricks
fill 475 286 448 507 286 448 minecraft:red_nether_bricks
setblock 475 286 449 minecraft:nether_bricks
fill 475 286 458 475 289 458 minecraft:netherrack
setblock 476 286 423 minecraft:nether_bricks
fill 476 286 425 506 286 425 minecraft:red_nether_bricks
fill 476 286 449 506 286 449 minecraft:red_nether_bricks
setblock 476 286 451 minecraft:nether_bricks
setblock 477 286 422 minecraft:nether_bricks
fill 477 286 423 505 286 423 minecraft:red_nether_bricks
fill 477 286 451 505 286 451 minecraft:red_nether_bricks
setblock 477 286 452 minecraft:nether_bricks
fill 478 286 422 504 286 422 minecraft:red_nether_bricks
fill 478 286 452 504 286 452 minecraft:red_nether_bricks
setblock 479 286 421 minecraft:nether_bricks
setblock 479 286 453 minecraft:nether_bricks
setblock 480 286 420 minecraft:nether_bricks
fill 480 286 421 502 286 421 minecraft:red_nether_bricks
fill 480 286 453 502 286 453 minecraft:red_nether_bricks
setblock 480 286 454 minecraft:nether_bricks
fill 481 286 416 482 291 416 minecraft:netherrack
fill 481 286 419 482 286 419 minecraft:nether_bricks
fill 481 286 420 501 286 420 minecraft:red_nether_bricks
fill 481 286 454 501 286 454 minecraft:red_nether_bricks
fill 481 286 455 482 286 455 minecraft:nether_bricks
fill 482 286 432 482 286 435 minecraft:red_nether_bricks
fill 482 286 436 483 286 438 minecraft:magma_block
fill 482 286 439 482 286 442 minecraft:red_nether_bricks
fill 482 286 458 483 287 458 minecraft:orange_concrete
fill 483 286 416 484 287 416 minecraft:orange_concrete
fill 483 286 418 485 286 418 minecraft:nether_bricks
fill 483 286 419 499 286 419 minecraft:red_nether_bricks
setblock 483 286 432 minecraft:red_nether_bricks
fill 483 286 433 483 286 435 minecraft:magma_block
fill 483 286 439 483 286 441 minecraft:magma_block
setblock 483 286 442 minecraft:red_nether_bricks
fill 483 286 455 499 286 455 minecraft:red_nether_bricks
fill 483 286 456 485 286 456 minecraft:nether_bricks
fill 484 286 429 484 286 430 minecraft:red_nether_bricks
fill 484 286 431 484 286 432 minecraft:magma_block
fill 484 286 442 484 286 443 minecraft:magma_block
fill 484 286 444 484 286 445 minecraft:red_nether_bricks
fill 484 286 458 485 291 458 minecraft:netherrack
fill 485 286 429 486 286 429 minecraft:red_nether_bricks
fill 485 286 430 485 286 431 minecraft:magma_block
fill 485 286 443 485 286 444 minecraft:magma_block
fill 485 286 445 486 286 445 minecraft:red_nether_bricks
fill 486 286 417 496 286 417 minecraft:nether_bricks
fill 486 286 418 496 286 418 minecraft:red_nether_bricks
setblock 486 286 430 minecraft:magma_block
setblock 486 286 444 minecraft:magma_block
fill 486 286 456 496 286 456 minecraft:red_nether_bricks
fill 486 286 457 496 286 457 minecraft:nether_bricks
fill 487 286 429 488 286 429 minecraft:magma_block
fill 487 286 445 488 286 445 minecraft:magma_block
fill 488 286 427 508 286 427 minecraft:red_nether_bricks
fill 488 286 428 495 286 428 minecraft:magma_block
fill 488 286 446 495 286 446 minecraft:magma_block
fill 488 286 447 508 286 447 minecraft:red_nether_bricks
fill 490 286 416 490 291 416 minecraft:netherrack
setblock 490 286 458 minecraft:netherrack
fill 491 286 416 492 286 416 minecraft:orange_concrete
fill 491 286 458 491 287 458 minecraft:orange_concrete
fill 493 286 416 493 291 416 minecraft:netherrack
fill 493 286 458 493 291 458 minecraft:netherrack
fill 494 286 458 495 286 458 minecraft:orange_concrete
fill 495 286 416 495 287 416 minecraft:orange_concrete
setblock 496 286 416 minecraft:netherrack
fill 496 286 428 508 286 428 minecraft:red_nether_bricks
fill 496 286 429 497 286 429 minecraft:magma_block
fill 496 286 445 497 286 445 minecraft:magma_block
fill 496 286 446 508 286 446 minecraft:red_nether_bricks
fill 496 286 458 496 291 458 minecraft:netherrack
fill 497 286 418 499 286 418 minecraft:nether_bricks
fill 497 286 456 499 286 456 minecraft:nether_bricks
fill 498 286 429 509 286 429 minecraft:red_nether_bricks
setblock 498 286 430 minecraft:magma_block
setblock 498 286 444 minecraft:magma_block
fill 498 286 445 509 286 445 minecraft:red_nether_bricks
fill 499 286 430 509 286 430 minecraft:red_nether_bricks
setblock 499 286 431 minecraft:magma_block
setblock 499 286 443 minecraft:magma_block
fill 499 286 444 509 286 444 minecraft:red_nether_bricks
fill 500 286 419 501 286 419 minecraft:nether_bricks
fill 500 286 431 509 286 431 minecraft:red_nether_bricks
fill 500 286 432 500 286 433 minecraft:magma_block
fill 500 286 441 500 286 442 minecraft:magma_block
fill 500 286 443 509 286 443 minecraft:red_nether_bricks
fill 500 286 455 501 286 455 minecraft:nether_bricks
fill 501 286 416 502 291 416 minecraft:netherrack
fill 501 286 432 510 286 433 minecraft:red_nether_bricks
fill 501 286 434 501 286 440 minecraft:magma_block
fill 501 286 441 510 286 442 minecraft:red_nether_bricks
setblock 502 286 420 minecraft:nether_bricks
fill 502 286 434 510 286 440 minecraft:red_nether_bricks
setblock 502 286 454 minecraft:nether_bricks
fill 502 286 458 503 287 458 minecraft:orange_concrete
fill 503 286 416 504 287 416 minecraft:orange_concrete
setblock 503 286 421 minecraft:nether_bricks
setblock 503 286 453 minecraft:nether_bricks
fill 504 286 458 505 291 458 minecraft:netherrack
setblock 505 286 422 minecraft:nether_bricks
setblock 505 286 452 minecraft:nether_bricks
setblock 506 286 423 minecraft:nether_bricks
setblock 506 286 451 minecraft:nether_bricks
setblock 507 286 425 minecraft:nether_bricks
setblock 507 286 449 minecraft:nether_bricks
setblock 508 286 426 minecraft:nether_bricks
setblock 508 286 448 minecraft:nether_bricks
fill 509 286 427 509 286 428 minecraft:nether_bricks
fill 509 286 446 509 286 447 minecraft:nether_bricks
fill 510 286 429 510 286 431 minecraft:nether_bricks
fill 510 286 443 510 286 445 minecraft:nether_bricks
fill 511 286 416 511 289 416 minecraft:netherrack
fill 511 286 432 511 286 442 minecraft:nether_bricks
setblock 512 286 416 minecraft:orange_concrete
fill 512 286 417 512 291 418 minecraft:netherrack
fill 512 286 419 512 287 420 minecraft:orange_concrete
fill 512 286 425 512 291 426 minecraft:netherrack
fill 512 286 427 512 286 428 minecraft:orange_concrete
fill 512 286 429 512 291 429 minecraft:netherrack
fill 512 286 437 512 291 438 minecraft:netherrack
fill 512 286 439 512 287 440 minecraft:orange_concrete
fill 512 286 446 512 289 447 minecraft:netherrack
setblock 512 286 448 minecraft:orange_concrete
fill 512 286 449 512 291 450 minecraft:netherrack
fill 512 286 451 512 287 451 minecraft:orange_concrete
setblock 512 286 452 minecraft:netherrack
fill 512 286 457 512 291 457 minecraft:netherrack
setblock 470 287 426 minecraft:orange_concrete
fill 470 287 430 470 290 430 minecraft:netherrack
fill 470 287 446 470 287 447 minecraft:orange_concrete
setblock 470 287 450 minecraft:orange_concrete
fill 470 287 451 470 290 451 minecraft:netherrack
fill 471 287 416 471 290 416 minecraft:netherrack
setblock 472 287 416 minecraft:orange_concrete
fill 472 287 432 472 287 442 minecraft:nether_bricks
fill 473 287 429 473 287 431 minecraft:nether_bricks
fill 473 287 432 480 287 442 minecraft:red_nether_bricks
fill 473 287 443 473 287 445 minecraft:nether_bricks
fill 474 287 427 474 287 428 minecraft:nether_bricks
fill 474 287 429 482 287 431 minecraft:red_nether_bricks
fill 474 287 443 482 287 445 minecraft:red_nether_bricks
fill 474 287 446 474 287 447 minecraft:nether_bricks
fill 474 287 458 474 290 458 minecraft:netherrack
fill 475 287 416 476 287 416 minecraft:orange_concrete
setblock 475 287 426 minecraft:nether_bricks
fill 475 287 427 485 287 428 minecraft:red_nether_bricks
fill 475 287 446 485 287 447 minecraft:red_nether_bricks
setblock 475 287 448 minecraft:nether_bricks
fill 476 287 424 476 287 425 minecraft:nether_bricks
fill 476 287 426 506 287 426 minecraft:red_nether_bricks
fill 476 287 448 506 287 448 minecraft:red_nether_bricks
fill 476 287 449 476 287 450 minecraft:nether_bricks
fill 477 287 423 477 287 424 minecraft:nether_bricks
fill 477 287 425 505 287 425 minecraft:red_nether_bricks
fill 477 287 449 505 287 449 minecraft:red_nether_bricks
fill 477 287 450 477 287 451 minecraft:nether_bricks
fill 478 287 422 478 287 423 minecraft:nether_bricks
fill 478 287 424 504 287 424 minecraft:red_nether_bricks
fill 478 287 450 504 287 450 minecraft:red_nether_bricks
fill 478 287 451 478 287 452 minecraft:nether_bricks
fill 478 287 458 478 289 458 minecraft:netherrack
setblock 479 287 422 minecraft:nether_bricks
fill 479 287 423 503 287 423 minecraft:red_nether_bricks
fill 479 287 451 503 287 451 minecraft:red_nether_bricks
setblock 479 287 452 minecraft:nether_bricks
setblock 479 287 458 minecraft:orange_concrete
setblock 480 287 421 minecraft:nether_bricks
fill 480 287 422 502 287 422 minecraft:red_nether_bricks
fill 480 287 452 502 287 452 minecraft:red_nether_bricks
setblock 480 287 453 minecraft:nether_bricks
fill 481 287 420 482 287 420 minecraft:nether_bricks
fill 481 287 421 501 287 421 minecraft:red_nether_bricks
fill 481 287 432 481 287 434 minecraft:red_nether_bricks
fill 481 287 435 481 287 439 minecraft:magma_block
fill 481 287 440 481 287 442 minecraft:red_nether_bricks
fill 481 287 453 501 287 453 minecraft:red_nether_bricks
fill 481 287 454 482 287 454 minecraft:nether_bricks
setblock 482 287 432 minecraft:red_nether_bricks
fill 482 287 433 482 287 435 minecraft:magma_block
fill 482 287 439 482 287 441 minecraft:magma_block
setblock 482 287 442 minecraft:red_nether_bricks
fill 483 287 419 485 287 419 minecraft:nether_bricks
fill 483 287 420 499 287 420 minecraft:red_nether_bricks
fill 483 287 429 483 287 430 minecraft:red_nether_bricks
fill 483 287 431 483 287 432 minecraft:magma_block
fill 483 287 442 483 287 443 minecraft:magma_block
fill 483 287 444 483 287 445 minecraft:red_nether_bricks
fill 483 287 454 499 287 454 minecraft:red_nether_bricks
fill 483 287 455 485 287 455 minecraft:nether_bricks
setblock 484 287 429 minecraft:red_nether_bricks
setblock 484 287 430 minecraft:magma_block
setblock 484 287 444 minecraft:magma_block
setblock 484 287 445 minecraft:red_nether_bricks
fill 485 287 429 486 287 429 minecraft:magma_block
fill 485 287 445 486 287 445 minecraft:magma_block
fill 486 287 418 496 287 418 minecraft:nether_bricks
fill 486 287 419 496 287 419 minecraft:red_nether_bricks
fill 486 287 427 487 287 427 minecraft:red_nether_bricks
fill 486 287 428 487 287 428 minecraft:magma_block
fill 486 287 446 487 287 446 minecraft:magma_block
fill 486 287 447 487 287 447 minecraft:red_nether_bricks
fill 486 287 455 496 287 455 minecraft:red_nether_bricks
fill 486 287 456 496 287 456 minecraft:nether_bricks
fill 488 287 427 495 287 427 minecraft:magma_block
fill 488 287 447 495 287 447 minecraft:magma_block
setblock 490 287 458 minecraft:orange_concrete
fill 491 287 416 492 290 416 minecraft:netherrack
fill 494 287 458 495 290 458 minecraft:netherrack
setblock 496 287 416 minecraft:orange_concrete
fill 496 287 427 507 287 427 minecraft:red_nether_bricks
fill 496 287 428 497 287 428 minecraft:magma_block
fill 496 287 446 497 287 446 minecraft:magma_block
fill 496 287 447 507 287 447 minecraft:red_nether_bricks
fill 497 287 419 499 287 419 minecraft:nether_bricks
fill 497 287 455 499 287 455 minecraft:nether_bricks
fill 498 287 428 507 287 428 minecraft:red_nether_bricks
setblock 498 287 429 minecraft:magma_block
setblock 498 287 445 minecraft:magma_block
fill 498 287 446 507 287 446 minecraft:red_nether_bricks
fill 499 287 429 508 287 429 minecraft:red_nether_bricks
setblock 499 287 430 minecraft:magma_block
setblock 499 287 444 minecraft:magma_block
fill 499 287 445 508 287 445 minecraft:red_nether_bricks
fill 500 287 420 501 287 420 minecraft:nether_bricks
fill 500 287 430 508 287 430 minecraft:red_nether_bricks
fill 500 287 431 500 287 432 minecraft:magma_block
fill 500 287 442 500 287 443 minecraft:magma_block
fill 500 287 444 508 287 444 minecraft:red_nether_bricks
fill 500 287 454 501 287 454 minecraft:nether_bricks
fill 501 287 431 508 287 432 minecraft:red_nether_bricks
fill 501 287 433 501 287 434 minecraft:magma_block
fill 501 287 440 501 287 441 minecraft:magma_block
fill 501 287 442 508 287 443 minecraft:red_nether_bricks
setblock 502 287 421 minecraft:nether_bricks
fill 502 287 433 509 287 434 minecraft:red_nether_bricks
fill 502 287 435 502 287 439 minecraft:magma_block
fill 502 287 440 509 287 441 minecraft:red_nether_bricks
setblock 502 287 453 minecraft:nether_bricks
fill 503 287 422 504 287 422 minecraft:nether_bricks
fill 503 287 435 509 287 439 minecraft:red_nether_bricks
fill 503 287 452 504 287 452 minecraft:nether_bricks
fill 504 287 423 505 287 423 minecraft:nether_bricks
fill 504 287 451 505 287 451 minecraft:nether_bricks
fill 505 287 424 506 287 424 minecraft:nether_bricks
fill 505 287 450 506 287 450 minecraft:nether_bricks
setblock 506 287 425 minecraft:nether_bricks
setblock 506 287 449 minecraft:nether_bricks
setblock 507 287 416 minecraft:orange_concrete
setblock 507 287 426 minecraft:nether_bricks
setblock 507 287 448 minecraft:nether_bricks
fill 508 287 416 508 289 416 minecraft:netherrack
fill 508 287 427 508 287 428 minecraft:nether_bricks
fill 508 287 446 508 287 447 minecraft:nether_bricks
fill 509 287 429 509 287 431 minecraft:nether_bricks
setblock 509 287 432 minecraft:red_nether_bricks
setblock 509 287 442 minecraft:red_nether_bricks
fill 509 287 443 509 287 445 minecraft:nether_bricks
fill 510 287 432 510 287 442 minecraft:nether_bricks
fill 510 287 458 510 289 458 minecraft:netherrack
setblock 511 287 458 minecraft:orange_concrete
fill 512 287 416 512 290 416 minecraft:netherrack
fill 512 287 427 512 290 427 minecraft:netherrack
setblock 512 287 428 minecraft:orange_concrete
fill 512 287 431 512 287 432 minecraft:orange_concrete
fill 512 287 448 512 290 448 minecraft:netherrack
setblock 512 287 452 minecraft:orange_concrete
fill 470 288 416 470 288 417 minecraft:orange_concrete
fill 470 288 418 470 290 419 minecraft:netherrack
fill 470 288 424 470 289 425 minecraft:orange_concrete
fill 470 288 426 470 293 427 minecraft:netherrack
fill 470 288 436 470 288 437 minecraft:orange_concrete
fill 470 288 438 470 293 439 minecraft:netherrack
fill 470 288 445 470 289 445 minecraft:orange_concrete
fill 470 288 446 470 293 447 minecraft:netherrack
setblock 470 288 448 minecraft:orange_concrete
fill 470 288 450 470 293 450 minecraft:netherrack
fill 470 288 456 470 289 457 minecraft:orange_concrete
fill 470 288 458 471 293 458 minecraft:netherrack
fill 471 288 417 473 288 417 minecraft:red_nether_bricks
fill 471 288 419 471 288 421 minecraft:red_nether_bricks
fill 471 288 423 471 288 425 minecraft:red_nether_bricks
fill 471 288 427 471 288 429 minecraft:red_nether_bricks
fill 471 288 431 471 288 433 minecraft:red_nether_bricks
fill 471 288 435 471 288 437 minecraft:red_nether_bricks
fill 471 288 439 471 288 441 minecraft:red_nether_bricks
fill 471 288 443 471 288 445 minecraft:red_nether_bricks
fill 471 288 447 471 288 449 minecraft:red_nether_bricks
fill 471 288 451 471 288 453 minecraft:red_nether_bricks
fill 471 288 455 471 288 457 minecraft:red_nether_bricks
fill 472 288 416 472 293 416 minecraft:netherrack
fill 473 288 416 474 288 416 minecraft:orange_concrete
setblock 473 288 419 minecraft:light[level=14]
setblock 473 288 427 minecraft:light[level=14]
fill 473 288 432 473 288 442 minecraft:nether_bricks
setblock 473 288 443 minecraft:light[level=14]
setblock 473 288 451 minecraft:light[level=14]
fill 473 288 457 475 288 457 minecraft:red_nether_bricks
fill 474 288 429 474 288 431 minecraft:nether_bricks
fill 474 288 432 479 288 442 minecraft:red_nether_bricks
fill 474 288 443 474 288 445 minecraft:nether_bricks
fill 475 288 416 476 289 416 minecraft:netherrack
fill 475 288 417 477 288 417 minecraft:red_nether_bricks
fill 475 288 427 475 288 429 minecraft:nether_bricks
fill 475 288 430 481 288 431 minecraft:red_nether_bricks
fill 475 288 443 481 288 444 minecraft:red_nether_bricks
fill 475 288 445 475 288 447 minecraft:nether_bricks
fill 476 288 426 476 288 427 minecraft:nether_bricks
fill 476 288 428 482 288 429 minecraft:red_nether_bricks
fill 476 288 445 482 288 446 minecraft:red_nether_bricks
fill 476 288 447 476 288 448 minecraft:nether_bricks
fill 477 288 416 477 289 416 minecraft:orange_concrete
setblock 477 288 425 minecraft:nether_bricks
fill 477 288 426 485 288 427 minecraft:red_nether_bricks
fill 477 288 447 485 288 448 minecraft:red_nether_bricks
setblock 477 288 449 minecraft:nether_bricks
fill 477 288 457 479 288 457 minecraft:red_nether_bricks
setblock 478 288 424 minecraft:nether_bricks
fill 478 288 425 504 288 425 minecraft:red_nether_bricks
fill 478 288 449 504 288 449 minecraft:red_nether_bricks
setblock 478 288 450 minecraft:nether_bricks
fill 479 288 417 481 288 417 minecraft:red_nether_bricks
setblock 479 288 423 minecraft:nether_bricks
fill 479 288 424 503 288 424 minecraft:red_nether_bricks
fill 479 288 450 503 288 450 minecraft:red_nether_bricks
setblock 479 288 451 minecraft:nether_bricks
fill 479 288 458 479 293 458 minecraft:netherrack
fill 480 288 422 481 288 422 minecraft:nether_bricks
fill 480 288 423 502 288 423 minecraft:red_nether_bricks
fill 480 288 432 480 288 434 minecraft:red_nether_bricks
fill 480 288 435 480 288 439 minecraft:magma_block
fill 480 288 440 480 288 442 minecraft:red_nether_bricks
fill 480 288 451 502 288 451 minecraft:red_nether_bricks
fill 480 288 452 481 288 452 minecraft:nether_bricks
fill 480 288 458 481 288 458 minecraft:orange_concrete
setblock 481 288 419 minecraft:light[level=14]
fill 481 288 421 483 288 421 minecraft:nether_bricks
fill 481 288 432 481 288 434 minecraft:magma_block
setblock 481 288 435 minecraft:light[level=14]
fill 481 288 440 481 288 442 minecraft:magma_block
fill 481 288 453 483 288 453 minecraft:nether_bricks
fill 481 288 457 483 288 457 minecraft:red_nether_bricks
fill 482 288 422 500 288 422 minecraft:red_nether_bricks
setblock 482 288 430 minecraft:red_nether_bricks
fill 482 288 431 482 288 432 minecraft:magma_block
fill 482 288 437 483 289 437 minecraft:bone_block
fill 482 288 442 482 288 443 minecraft:magma_block
setblock 482 288 444 minecraft:red_nether_bricks
fill 482 288 452 500 288 452 minecraft:red_nether_bricks
fill 482 288 458 483 293 458 minecraft:netherrack
fill 483 288 416 484 293 416 minecraft:netherrack
fill 483 288 417 485 288 417 minecraft:red_nether_bricks
fill 483 288 420 485 288 420 minecraft:nether_bricks
setblock 483 288 428 minecraft:red_nether_bricks
fill 483 288 429 483 288 430 minecraft:magma_block
fill 483 288 434 483 289 435 minecraft:bone_block
fill 483 288 439 483 289 440 minecraft:bone_block
fill 483 288 444 483 288 445 minecraft:magma_block
setblock 483 288 446 minecraft:red_nether_bricks
fill 483 288 454 485 288 454 minecraft:nether_bricks
fill 484 288 421 498 288 421 minecraft:red_nether_bricks
fill 484 288 428 484 288 429 minecraft:magma_block
fill 484 288 432 485 288 432 minecraft:bone_block
setblock 484 288 435 minecraft:bone_block
setblock 484 288 439 minecraft:bone_block
fill 484 288 442 485 288 442 minecraft:bone_block
fill 484 288 445 484 288 446 minecraft:magma_block
fill 484 288 453 498 288 453 minecraft:red_nether_bricks
fill 485 288 416 486 289 416 minecraft:orange_concrete
setblock 485 288 428 minecraft:magma_block
setblock 485 288 446 minecraft:magma_block
fill 485 288 457 487 288 457 minecraft:red_nether_bricks
fill 486 288 419 496 288 419 minecraft:nether_bricks
fill 486 288 420 496 288 420 minecraft:red_nether_bricks
fill 486 288 426 487 288 426 minecraft:red_nether_bricks
fill 486 288 427 487 288 427 minecraft:magma_block
fill 486 288 430 486 288 431 minecraft:bone_block
fill 486 288 443 486 288 444 minecraft:bone_block
fill 486 288 447 487 288 447 minecraft:magma_block
fill 486 288 448 487 288 448 minecraft:red_nether_bricks
fill 486 288 454 496 288 454 minecraft:red_nether_bricks
fill 486 288 455 496 288 455 minecraft:nether_bricks
fill 487 288 417 489 288 417 minecraft:red_nether_bricks
fill 488 288 426 495 288 426 minecraft:magma_block
fill 488 288 429 489 289 429 minecraft:bone_block
fill 488 288 445 489 289 445 minecraft:bone_block
fill 488 288 448 495 288 448 minecraft:magma_block
fill 488 288 458 489 289 458 minecraft:orange_concrete
setblock 489 288 427 minecraft:light[level=14]
setblock 489 288 430 minecraft:bone_block
setblock 489 288 435 minecraft:light[level=14]
setblock 489 288 443 minecraft:light[level=14]
setblock 489 288 444 minecraft:bone_block
fill 489 288 457 491 288 457 minecraft:red_nether_bricks
fill 490 288 458 491 293 458 minecraft:netherrack
fill 491 288 417 493 288 417 minecraft:red_nether_bricks
fill 491 288 428 491 289 429 minecraft:bone_block
fill 491 288 445 491 289 446 minecraft:bone_block
setblock 492 288 458 minecraft:orange_concrete
fill 493 288 429 493 288 430 minecraft:bone_block
fill 493 288 444 493 288 445 minecraft:bone_block
fill 493 288 457 495 288 457 minecraft:red_nether_bricks
setblock 494 288 416 minecraft:orange_concrete
fill 494 288 429 494 289 429 minecraft:bone_block
fill 494 288 445 494 289 445 minecraft:bone_block
fill 495 288 416 496 293 416 minecraft:netherrack
fill 495 288 417 497 288 417 minecraft:red_nether_bricks
fill 496 288 426 505 288 426 minecraft:red_nether_bricks
fill 496 288 427 497 288 427 minecraft:magma_block
fill 496 288 430 496 288 431 minecraft:bone_block
fill 496 288 443 496 288 444 minecraft:bone_block
fill 496 288 447 497 288 447 minecraft:magma_block
fill 496 288 448 505 288 448 minecraft:red_nether_bricks
fill 497 288 416 498 289 416 minecraft:orange_concrete
setblock 497 288 419 minecraft:light[level=14]
fill 497 288 420 499 288 420 minecraft:nether_bricks
fill 497 288 432 498 288 432 minecraft:bone_block
setblock 497 288 435 minecraft:light[level=14]
fill 497 288 442 498 288 442 minecraft:bone_block
setblock 497 288 443 minecraft:light[level=14]
fill 497 288 454 499 288 454 minecraft:nether_bricks
fill 497 288 457 499 288 457 minecraft:red_nether_bricks
fill 498 288 427 505 288 427 minecraft:red_nether_bricks
setblock 498 288 428 minecraft:magma_block
fill 498 288 435 499 288 435 minecraft:bone_block
fill 498 288 439 499 288 439 minecraft:bone_block
setblock 498 288 446 minecraft:magma_block
fill 498 288 447 505 288 447 minecraft:red_nether_bricks
fill 499 288 417 501 288 417 minecraft:red_nether_bricks
fill 499 288 421 501 288 421 minecraft:nether_bricks
fill 499 288 428 506 288 428 minecraft:red_nether_bricks
setblock 499 288 429 minecraft:magma_block
fill 499 288 434 499 289 434 minecraft:bone_block
fill 499 288 437 500 289 437 minecraft:bone_block
fill 499 288 440 499 289 440 minecraft:bone_block
setblock 499 288 445 minecraft:magma_block
fill 499 288 446 506 288 446 minecraft:red_nether_bricks
fill 499 288 453 501 288 453 minecraft:nether_bricks
fill 500 288 429 506 288 429 minecraft:red_nether_bricks
setblock 500 288 430 minecraft:magma_block
setblock 500 288 444 minecraft:magma_block
fill 500 288 445 506 288 445 minecraft:red_nether_bricks
fill 500 288 458 501 289 458 minecraft:orange_concrete
fill 501 288 422 502 288 422 minecraft:nether_bricks
fill 501 288 430 507 288 430 minecraft:red_nether_bricks
fill 501 288 431 501 288 432 minecraft:magma_block
fill 501 288 442 501 288 443 minecraft:magma_block
fill 501 288 444 507 288 444 minecraft:red_nether_bricks
fill 501 288 452 502 288 452 minecraft:nether_bricks
fill 501 288 457 503 288 457 minecraft:red_nether_bricks
fill 502 288 431 507 288 432 minecraft:red_nether_bricks
fill 502 288 433 502 288 435 minecraft:magma_block
fill 502 288 439 502 288 441 minecraft:magma_block
fill 502 288 442 507 288 443 minecraft:red_nether_bricks
fill 502 288 458 503 293 458 minecraft:netherrack
fill 503 288 416 504 293 416 minecraft:netherrack
fill 503 288 417 505 288 417 minecraft:red_nether_bricks
setblock 503 288 423 minecraft:nether_bricks
fill 503 288 433 508 288 435 minecraft:red_nether_bricks
fill 503 288 436 503 289 438 minecraft:magma_block
fill 503 288 439 508 288 441 minecraft:red_nether_bricks
setblock 503 288 451 minecraft:nether_bricks
setblock 504 288 424 minecraft:nether_bricks
fill 504 288 436 508 288 438 minecraft:red_nether_bricks
setblock 504 288 450 minecraft:nether_bricks
fill 505 288 416 506 288 416 minecraft:orange_concrete
setblock 505 288 419 minecraft:light[level=14]
setblock 505 288 425 minecraft:nether_bricks
setblock 505 288 449 minecraft:nether_bricks
setblock 505 288 451 minecraft:light[level=14]
fill 505 288 457 507 288 457 minecraft:red_nether_bricks
fill 506 288 426 506 288 427 minecraft:nether_bricks
fill 506 288 447 506 288 448 minecraft:nether_bricks
fill 507 288 416 507 293 416 minecraft:netherrack
fill 507 288 417 509 288 417 minecraft:red_nether_bricks
fill 507 288 427 507 288 429 minecraft:nether_bricks
fill 507 288 445 507 288 447 minecraft:nether_bricks
fill 508 288 429 508 288 431 minecraft:nether_bricks
setblock 508 288 432 minecraft:red_nether_bricks
setblock 508 288 442 minecraft:red_nether_bricks
fill 508 288 443 508 288 445 minecraft:nether_bricks
fill 509 288 432 509 288 442 minecraft:nether_bricks
fill 509 288 457 511 288 457 minecraft:red_nether_bricks
fill 509 288 458 509 289 458 minecraft:orange_concrete
fill 511 288 417 511 288 419 minecraft:red_nether_bricks
fill 511 288 421 511 288 423 minecraft:red_nether_bricks
fill 511 288 425 511 288 427 minecraft:red_nether_bricks
fill 511 288 429 511 288 431 minecraft:red_nether_bricks
fill 511 288 433 511 288 435 minecraft:red_nether_bricks
fill 511 288 437 511 288 439 minecraft:red_nether_bricks
fill 511 288 441 511 288 443 minecraft:red_nether_bricks
fill 511 288 445 511 288 447 minecraft:red_nether_bricks
fill 511 288 449 511 288 451 minecraft:red_nether_bricks
fill 511 288 453 511 288 455 minecraft:red_nether_bricks
fill 511 288 458 511 293 458 minecraft:netherrack
fill 512 288 419 512 293 420 minecraft:netherrack
fill 512 288 421 512 289 422 minecraft:orange_concrete
fill 512 288 428 512 293 428 minecraft:netherrack
setblock 512 288 430 minecraft:orange_concrete
fill 512 288 431 512 293 432 minecraft:netherrack
fill 512 288 433 512 289 433 minecraft:orange_concrete
fill 512 288 439 512 293 440 minecraft:netherrack
fill 512 288 441 512 288 442 minecraft:orange_concrete
fill 512 288 451 512 293 452 minecraft:netherrack
fill 512 288 453 512 289 454 minecraft:orange_concrete
setblock 512 288 458 minecraft:orange_concrete
setblock 470 289 416 minecraft:orange_concrete
fill 470 289 417 470 292 417 minecraft:netherrack
setblock 470 289 433 minecraft:orange_concrete
setblock 470 289 436 minecraft:orange_concrete
fill 470 289 437 470 292 437 minecraft:netherrack
setblock 470 289 444 minecraft:orange_concrete
fill 470 289 448 470 292 448 minecraft:netherrack
fill 473 289 416 474 291 416 minecraft:netherrack
fill 474 289 432 474 289 442 minecraft:nether_bricks
fill 475 289 430 475 289 434 minecraft:nether_bricks
fill 475 289 435 478 289 439 minecraft:red_nether_bricks
fill 475 289 440 475 289 444 minecraft:nether_bricks
fill 476 289 428 476 289 430 minecraft:nether_bricks
fill 476 289 431 478 289 434 minecraft:red_nether_bricks
fill 476 289 440 478 289 443 minecraft:red_nether_bricks
fill 476 289 444 476 289 446 minecraft:nether_bricks
fill 476 289 458 477 289 458 minecraft:orange_concrete
fill 477 289 426 477 289 428 minecraft:nether_bricks
fill 477 289 429 480 289 430 minecraft:red_nether_bricks
fill 477 289 444 480 289 445 minecraft:red_nether_bricks
fill 477 289 446 477 289 448 minecraft:nether_bricks
setblock 478 289 416 minecraft:orange_concrete
fill 478 289 425 478 289 427 minecraft:nether_bricks
fill 478 289 428 482 289 428 minecraft:red_nether_bricks
fill 478 289 446 482 289 446 minecraft:red_nether_bricks
fill 478 289 447 478 289 449 minecraft:nether_bricks
fill 479 289 424 479 289 426 minecraft:nether_bricks
fill 479 289 427 483 289 427 minecraft:red_nether_bricks
fill 479 289 431 479 289 433 minecraft:red_nether_bricks
fill 479 289 434 479 289 440 minecraft:magma_block
fill 479 289 441 479 289 443 minecraft:red_nether_bricks
fill 479 289 447 483 289 447 minecraft:red_nether_bricks
fill 479 289 448 479 289 450 minecraft:nether_bricks
fill 480 289 423 480 289 425 minecraft:nether_bricks
fill 480 289 426 485 289 426 minecraft:red_nether_bricks
setblock 480 289 431 minecraft:red_nether_bricks
fill 480 289 432 480 289 434 minecraft:magma_block
fill 480 289 437 481 290 437 minecraft:bone_block
fill 480 289 440 480 289 442 minecraft:magma_block
setblock 480 289 443 minecraft:red_nether_bricks
fill 480 289 448 485 289 448 minecraft:red_nether_bricks
fill 480 289 449 480 289 451 minecraft:nether_bricks
setblock 480 289 458 minecraft:orange_concrete
fill 481 289 423 481 289 424 minecraft:nether_bricks
fill 481 289 425 487 289 425 minecraft:red_nether_bricks
setblock 481 289 429 minecraft:red_nether_bricks
fill 481 289 430 481 289 431 minecraft:magma_block
fill 481 289 433 481 290 434 minecraft:bone_block
fill 481 289 440 481 290 441 minecraft:bone_block
fill 481 289 443 481 289 444 minecraft:magma_block
setblock 481 289 445 minecraft:red_nether_bricks
fill 481 289 449 487 289 449 minecraft:red_nether_bricks
fill 481 289 450 481 289 451 minecraft:nether_bricks
fill 481 289 458 481 292 458 minecraft:netherrack
fill 482 289 422 482 289 423 minecraft:nether_bricks
fill 482 289 424 500 289 424 minecraft:red_nether_bricks
fill 482 289 429 482 289 430 minecraft:magma_block
fill 482 289 431 484 289 431 minecraft:bone_block
fill 482 289 434 482 290 434 minecraft:bone_block
fill 482 289 440 482 290 440 minecraft:bone_block
fill 482 289 443 484 289 443 minecraft:bone_block
fill 482 289 444 482 289 445 minecraft:magma_block
fill 482 289 450 500 289 450 minecraft:red_nether_bricks
fill 482 289 451 482 289 452 minecraft:nether_bricks
fill 483 289 422 484 289 422 minecraft:nether_bricks
fill 483 289 423 499 289 423 minecraft:red_nether_bricks
setblock 483 289 428 minecraft:magma_block
fill 483 289 432 484 289 432 minecraft:bone_block
fill 483 289 442 484 289 442 minecraft:bone_block
setblock 483 289 446 minecraft:magma_block
fill 483 289 451 499 289 451 minecraft:red_nether_bricks
fill 483 289 452 484 289 452 minecraft:nether_bricks
fill 484 289 421 488 289 421 minecraft:nether_bricks
fill 484 289 427 485 289 427 minecraft:magma_block
fill 484 289 447 485 289 447 minecraft:magma_block
fill 484 289 453 488 289 453 minecraft:nether_bricks
fill 485 289 422 497 289 422 minecraft:red_nether_bricks
fill 485 289 428 485 289 430 minecraft:bone_block
fill 485 289 444 485 289 446 minecraft:bone_block
fill 485 289 452 497 289 452 minecraft:red_nether_bricks
fill 486 289 420 496 289 420 minecraft:nether_bricks
fill 486 289 426 487 289 426 minecraft:magma_block
fill 486 289 429 486 289 430 minecraft:bone_block
fill 486 289 444 486 289 445 minecraft:bone_block
fill 486 289 448 487 289 448 minecraft:magma_block
schedule function dropper:buildpart/106_7 1t
