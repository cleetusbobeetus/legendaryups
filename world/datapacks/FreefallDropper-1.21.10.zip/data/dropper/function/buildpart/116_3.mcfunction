fill 379 263 498 379 264 498 minecraft:black_concrete
fill 379 263 500 379 264 500 minecraft:black_concrete
fill 379 263 502 379 264 502 minecraft:black_concrete
fill 379 263 504 379 264 504 minecraft:black_concrete
fill 380 263 499 380 264 499 minecraft:black_concrete
fill 380 263 501 380 264 501 minecraft:black_concrete
fill 380 263 503 380 264 503 minecraft:black_concrete
fill 381 263 498 381 264 498 minecraft:black_concrete
fill 381 263 500 381 264 500 minecraft:black_concrete
fill 381 263 502 381 264 502 minecraft:black_concrete
fill 381 263 504 381 264 504 minecraft:black_concrete
fill 382 263 499 382 264 499 minecraft:black_concrete
fill 382 263 501 382 264 501 minecraft:black_concrete
fill 382 263 503 382 264 503 minecraft:black_concrete
fill 383 263 498 383 264 498 minecraft:black_concrete
fill 383 263 500 383 264 500 minecraft:black_concrete
fill 383 263 502 383 264 502 minecraft:black_concrete
fill 383 263 504 383 264 504 minecraft:black_concrete
fill 384 263 499 384 264 499 minecraft:black_concrete
fill 384 263 501 384 264 501 minecraft:black_concrete
fill 384 263 503 384 264 503 minecraft:black_concrete
fill 408 263 495 408 264 495 minecraft:black_concrete
fill 408 263 497 408 264 497 minecraft:black_concrete
fill 408 263 499 408 264 499 minecraft:black_concrete
fill 408 263 501 408 264 501 minecraft:black_concrete
fill 408 263 503 408 264 503 minecraft:black_concrete
fill 408 263 505 408 264 505 minecraft:magenta_concrete
fill 409 263 494 409 264 494 minecraft:black_concrete
fill 409 263 496 409 264 496 minecraft:black_concrete
fill 409 263 498 409 264 498 minecraft:black_concrete
fill 409 263 500 409 264 500 minecraft:black_concrete
fill 409 263 502 409 264 502 minecraft:black_concrete
fill 409 263 504 409 264 504 minecraft:black_concrete
fill 410 263 495 410 264 495 minecraft:black_concrete
fill 410 263 497 410 264 497 minecraft:black_concrete
fill 410 263 499 410 264 499 minecraft:black_concrete
fill 410 263 501 410 264 501 minecraft:black_concrete
fill 410 263 503 410 264 503 minecraft:black_concrete
fill 410 263 505 410 264 505 minecraft:magenta_concrete
fill 411 263 494 411 264 494 minecraft:black_concrete
fill 411 263 496 411 264 496 minecraft:black_concrete
fill 411 263 498 411 264 498 minecraft:black_concrete
fill 411 263 500 411 264 500 minecraft:black_concrete
fill 411 263 502 411 264 502 minecraft:black_concrete
fill 411 263 504 411 264 504 minecraft:black_concrete
fill 412 263 495 412 264 495 minecraft:black_concrete
fill 412 263 497 412 264 497 minecraft:black_concrete
fill 412 263 499 412 264 499 minecraft:black_concrete
fill 412 263 501 412 264 501 minecraft:black_concrete
fill 412 263 503 412 264 503 minecraft:black_concrete
fill 412 263 505 412 264 505 minecraft:magenta_concrete
fill 413 263 494 413 264 494 minecraft:black_concrete
fill 413 263 496 413 264 496 minecraft:black_concrete
fill 413 263 498 413 264 498 minecraft:black_concrete
fill 413 263 500 413 264 500 minecraft:black_concrete
fill 413 263 502 413 264 502 minecraft:black_concrete
fill 413 263 504 413 264 504 minecraft:black_concrete
fill 414 263 495 414 264 495 minecraft:black_concrete
fill 414 263 497 414 264 497 minecraft:black_concrete
fill 414 263 499 414 264 499 minecraft:black_concrete
fill 414 263 501 414 264 501 minecraft:black_concrete
fill 414 263 503 414 264 503 minecraft:black_concrete
fill 414 263 505 414 264 505 minecraft:magenta_concrete
fill 415 263 494 415 264 494 minecraft:black_concrete
fill 415 263 496 415 264 496 minecraft:black_concrete
fill 415 263 498 415 264 498 minecraft:black_concrete
fill 415 263 500 415 264 500 minecraft:black_concrete
fill 415 263 502 415 264 502 minecraft:black_concrete
fill 415 263 504 415 264 504 minecraft:black_concrete
fill 416 263 495 416 264 495 minecraft:black_concrete
fill 416 263 497 416 264 497 minecraft:black_concrete
fill 416 263 499 416 264 499 minecraft:black_concrete
fill 416 263 501 416 264 501 minecraft:black_concrete
fill 416 263 503 416 264 503 minecraft:black_concrete
fill 416 263 505 416 264 505 minecraft:magenta_concrete
fill 417 263 494 417 264 494 minecraft:black_concrete
fill 417 263 496 417 264 496 minecraft:black_concrete
fill 417 263 498 417 264 498 minecraft:black_concrete
fill 417 263 500 417 264 500 minecraft:black_concrete
fill 417 263 502 417 264 502 minecraft:black_concrete
fill 417 263 504 417 264 504 minecraft:black_concrete
setblock 379 264 466 minecraft:light[level=14]
setblock 379 264 474 minecraft:light[level=14]
setblock 379 264 482 minecraft:light[level=14]
setblock 379 264 490 minecraft:light[level=14]
setblock 387 264 466 minecraft:light[level=14]
setblock 387 264 474 minecraft:light[level=14]
setblock 387 264 482 minecraft:light[level=14]
setblock 387 264 490 minecraft:light[level=14]
setblock 387 264 498 minecraft:light[level=14]
setblock 395 264 466 minecraft:light[level=14]
setblock 395 264 474 minecraft:light[level=14]
setblock 395 264 482 minecraft:light[level=14]
setblock 395 264 490 minecraft:light[level=14]
setblock 395 264 498 minecraft:light[level=14]
setblock 403 264 466 minecraft:light[level=14]
setblock 403 264 474 minecraft:light[level=14]
setblock 403 264 482 minecraft:light[level=14]
setblock 403 264 490 minecraft:light[level=14]
setblock 403 264 498 minecraft:light[level=14]
setblock 411 264 466 minecraft:light[level=14]
setblock 411 264 474 minecraft:light[level=14]
setblock 411 264 482 minecraft:light[level=14]
setblock 411 264 490 minecraft:light[level=14]
setblock 376 265 499 minecraft:sea_lantern
setblock 376 265 501 minecraft:sea_lantern
setblock 376 265 503 minecraft:sea_lantern
setblock 377 265 498 minecraft:sea_lantern
setblock 377 265 500 minecraft:sea_lantern
setblock 377 265 502 minecraft:sea_lantern
setblock 377 265 504 minecraft:sea_lantern
setblock 378 265 499 minecraft:sea_lantern
setblock 378 265 501 minecraft:sea_lantern
setblock 378 265 503 minecraft:sea_lantern
setblock 379 265 498 minecraft:sea_lantern
setblock 379 265 500 minecraft:sea_lantern
setblock 379 265 502 minecraft:sea_lantern
setblock 379 265 504 minecraft:sea_lantern
setblock 380 265 499 minecraft:sea_lantern
setblock 380 265 501 minecraft:sea_lantern
setblock 380 265 503 minecraft:sea_lantern
setblock 381 265 498 minecraft:sea_lantern
setblock 381 265 500 minecraft:sea_lantern
setblock 381 265 502 minecraft:sea_lantern
setblock 381 265 504 minecraft:sea_lantern
setblock 382 265 499 minecraft:sea_lantern
setblock 382 265 501 minecraft:sea_lantern
setblock 382 265 503 minecraft:sea_lantern
setblock 383 265 498 minecraft:sea_lantern
setblock 383 265 500 minecraft:sea_lantern
setblock 383 265 502 minecraft:sea_lantern
setblock 383 265 504 minecraft:sea_lantern
setblock 384 265 499 minecraft:sea_lantern
setblock 384 265 501 minecraft:sea_lantern
setblock 384 265 503 minecraft:sea_lantern
setblock 408 265 495 minecraft:sea_lantern
setblock 408 265 497 minecraft:sea_lantern
setblock 408 265 499 minecraft:sea_lantern
setblock 408 265 501 minecraft:sea_lantern
setblock 408 265 503 minecraft:sea_lantern
setblock 408 265 505 minecraft:sea_lantern
setblock 409 265 494 minecraft:sea_lantern
setblock 409 265 496 minecraft:sea_lantern
setblock 409 265 498 minecraft:sea_lantern
setblock 409 265 500 minecraft:sea_lantern
setblock 409 265 502 minecraft:sea_lantern
setblock 409 265 504 minecraft:sea_lantern
setblock 410 265 495 minecraft:sea_lantern
setblock 410 265 497 minecraft:sea_lantern
setblock 410 265 499 minecraft:sea_lantern
setblock 410 265 501 minecraft:sea_lantern
setblock 410 265 503 minecraft:sea_lantern
setblock 410 265 505 minecraft:sea_lantern
setblock 411 265 494 minecraft:sea_lantern
setblock 411 265 496 minecraft:sea_lantern
setblock 411 265 498 minecraft:sea_lantern
setblock 411 265 500 minecraft:sea_lantern
setblock 411 265 502 minecraft:sea_lantern
setblock 411 265 504 minecraft:sea_lantern
setblock 412 265 495 minecraft:sea_lantern
setblock 412 265 497 minecraft:sea_lantern
setblock 412 265 499 minecraft:sea_lantern
setblock 412 265 501 minecraft:sea_lantern
setblock 412 265 503 minecraft:sea_lantern
setblock 412 265 505 minecraft:sea_lantern
setblock 413 265 494 minecraft:sea_lantern
setblock 413 265 496 minecraft:sea_lantern
setblock 413 265 498 minecraft:sea_lantern
setblock 413 265 500 minecraft:sea_lantern
setblock 413 265 502 minecraft:sea_lantern
setblock 413 265 504 minecraft:sea_lantern
setblock 414 265 495 minecraft:sea_lantern
setblock 414 265 497 minecraft:sea_lantern
setblock 414 265 499 minecraft:sea_lantern
setblock 414 265 501 minecraft:sea_lantern
setblock 414 265 503 minecraft:sea_lantern
setblock 414 265 505 minecraft:sea_lantern
setblock 415 265 494 minecraft:sea_lantern
setblock 415 265 496 minecraft:sea_lantern
setblock 415 265 498 minecraft:sea_lantern
setblock 415 265 500 minecraft:sea_lantern
setblock 415 265 502 minecraft:sea_lantern
setblock 415 265 504 minecraft:sea_lantern
setblock 416 265 495 minecraft:sea_lantern
setblock 416 265 497 minecraft:sea_lantern
setblock 416 265 499 minecraft:sea_lantern
setblock 416 265 501 minecraft:sea_lantern
setblock 416 265 503 minecraft:sea_lantern
setblock 416 265 505 minecraft:sea_lantern
setblock 417 265 494 minecraft:sea_lantern
setblock 417 265 496 minecraft:sea_lantern
setblock 417 265 498 minecraft:sea_lantern
setblock 417 265 500 minecraft:sea_lantern
setblock 417 265 502 minecraft:sea_lantern
setblock 417 265 504 minecraft:sea_lantern
fill 376 266 499 376 267 499 minecraft:magenta_concrete
fill 376 266 501 376 267 501 minecraft:magenta_concrete
fill 376 266 503 376 267 503 minecraft:magenta_concrete
fill 377 266 464 377 267 469 minecraft:black_concrete
fill 377 266 472 378 266 477 minecraft:black_concrete
fill 377 266 480 378 266 485 minecraft:black_concrete
fill 377 266 488 378 266 493 minecraft:black_concrete
fill 377 266 496 377 267 498 minecraft:black_concrete
fill 377 266 500 377 267 500 minecraft:black_concrete
fill 377 266 502 377 267 502 minecraft:black_concrete
fill 377 266 504 377 267 504 minecraft:black_concrete
fill 378 266 465 378 266 471 minecraft:black_concrete
fill 378 266 478 378 266 479 minecraft:black_concrete
fill 378 266 486 378 266 487 minecraft:black_concrete
fill 378 266 494 378 266 497 minecraft:black_concrete
fill 378 266 499 378 267 499 minecraft:black_concrete
fill 378 266 501 378 267 501 minecraft:black_concrete
fill 378 266 503 378 267 503 minecraft:black_concrete
fill 379 266 465 416 266 465 minecraft:black_concrete
fill 379 266 498 379 267 498 minecraft:black_concrete
fill 379 266 500 379 267 500 minecraft:black_concrete
fill 379 266 502 379 267 502 minecraft:black_concrete
fill 379 266 504 379 267 504 minecraft:black_concrete
fill 380 266 464 385 267 464 minecraft:black_concrete
fill 380 266 499 380 267 499 minecraft:black_concrete
fill 380 266 501 380 267 501 minecraft:black_concrete
fill 380 266 503 380 267 503 minecraft:black_concrete
fill 381 266 498 381 267 498 minecraft:black_concrete
fill 381 266 500 381 267 500 minecraft:black_concrete
fill 381 266 502 381 267 502 minecraft:black_concrete
fill 381 266 504 381 267 504 minecraft:black_concrete
fill 382 266 499 382 267 499 minecraft:black_concrete
fill 382 266 501 382 267 501 minecraft:black_concrete
fill 382 266 503 382 267 503 minecraft:black_concrete
fill 383 266 498 383 267 498 minecraft:black_concrete
fill 383 266 500 383 267 500 minecraft:black_concrete
fill 383 266 502 383 267 502 minecraft:black_concrete
fill 383 266 504 383 267 504 minecraft:black_concrete
fill 384 266 499 384 267 499 minecraft:black_concrete
fill 384 266 501 384 267 501 minecraft:black_concrete
fill 384 266 503 408 266 503 minecraft:black_concrete
fill 385 266 504 390 267 504 minecraft:black_concrete
fill 388 266 464 393 267 464 minecraft:black_concrete
fill 393 266 504 398 267 504 minecraft:black_concrete
fill 396 266 464 401 267 464 minecraft:black_concrete
fill 401 266 504 406 267 504 minecraft:black_concrete
fill 404 266 464 409 267 464 minecraft:black_concrete
fill 408 266 495 408 267 495 minecraft:black_concrete
fill 408 266 497 408 267 497 minecraft:black_concrete
fill 408 266 499 408 267 499 minecraft:black_concrete
fill 408 266 501 408 267 501 minecraft:black_concrete
fill 408 266 505 408 267 505 minecraft:magenta_concrete
fill 409 266 494 409 267 494 minecraft:black_concrete
fill 409 266 496 409 267 496 minecraft:black_concrete
fill 409 266 498 409 267 498 minecraft:black_concrete
fill 409 266 500 409 267 500 minecraft:black_concrete
fill 409 266 502 409 267 502 minecraft:black_concrete
fill 409 266 504 409 267 504 minecraft:black_concrete
fill 410 266 495 410 267 495 minecraft:black_concrete
fill 410 266 497 410 267 497 minecraft:black_concrete
fill 410 266 499 410 267 499 minecraft:black_concrete
fill 410 266 501 410 267 501 minecraft:black_concrete
fill 410 266 503 410 267 503 minecraft:black_concrete
fill 410 266 505 410 267 505 minecraft:magenta_concrete
fill 411 266 494 411 267 494 minecraft:black_concrete
fill 411 266 496 411 267 496 minecraft:black_concrete
fill 411 266 498 411 267 498 minecraft:black_concrete
fill 411 266 500 411 267 500 minecraft:black_concrete
fill 411 266 502 411 267 502 minecraft:black_concrete
fill 411 266 504 411 267 504 minecraft:black_concrete
fill 412 266 464 417 267 464 minecraft:black_concrete
fill 412 266 495 412 267 495 minecraft:black_concrete
fill 412 266 497 412 267 497 minecraft:black_concrete
fill 412 266 499 412 267 499 minecraft:black_concrete
fill 412 266 501 412 267 501 minecraft:black_concrete
fill 412 266 503 412 267 503 minecraft:black_concrete
fill 412 266 505 412 267 505 minecraft:magenta_concrete
fill 413 266 494 413 267 494 minecraft:black_concrete
fill 413 266 496 413 267 496 minecraft:black_concrete
fill 413 266 498 413 267 498 minecraft:black_concrete
fill 413 266 500 413 267 500 minecraft:black_concrete
fill 413 266 502 413 267 502 minecraft:black_concrete
fill 413 266 504 413 267 504 minecraft:black_concrete
fill 414 266 495 414 267 495 minecraft:black_concrete
fill 414 266 497 414 267 497 minecraft:black_concrete
fill 414 266 499 414 267 499 minecraft:black_concrete
fill 414 266 501 414 267 501 minecraft:black_concrete
fill 414 266 503 414 267 503 minecraft:black_concrete
fill 414 266 505 414 267 505 minecraft:magenta_concrete
fill 415 266 494 415 267 494 minecraft:black_concrete
fill 415 266 496 415 267 496 minecraft:black_concrete
fill 415 266 498 415 267 498 minecraft:black_concrete
fill 415 266 500 415 267 500 minecraft:black_concrete
fill 415 266 502 415 267 502 minecraft:black_concrete
fill 415 266 504 415 267 504 minecraft:black_concrete
fill 416 266 466 416 266 493 minecraft:black_concrete
fill 416 266 495 416 267 495 minecraft:black_concrete
fill 416 266 497 416 267 497 minecraft:black_concrete
fill 416 266 499 416 267 499 minecraft:black_concrete
fill 416 266 501 416 267 501 minecraft:black_concrete
fill 416 266 503 416 267 503 minecraft:black_concrete
fill 416 266 505 416 267 505 minecraft:magenta_concrete
fill 417 266 467 417 267 472 minecraft:black_concrete
fill 417 266 475 417 267 480 minecraft:black_concrete
fill 417 266 483 417 267 488 minecraft:black_concrete
fill 417 266 491 417 267 494 minecraft:black_concrete
fill 417 266 496 417 267 496 minecraft:black_concrete
fill 417 266 498 417 267 498 minecraft:black_concrete
fill 417 266 500 417 267 500 minecraft:black_concrete
fill 417 266 502 417 267 502 minecraft:black_concrete
fill 417 266 504 417 267 504 minecraft:black_concrete
fill 377 267 472 377 267 477 minecraft:black_concrete
fill 377 267 480 377 267 485 minecraft:black_concrete
fill 377 267 488 377 267 493 minecraft:black_concrete
setblock 384 267 503 minecraft:black_concrete
setblock 408 267 503 minecraft:black_concrete
setblock 376 268 499 minecraft:sea_lantern
setblock 376 268 501 minecraft:sea_lantern
setblock 376 268 503 minecraft:sea_lantern
setblock 377 268 498 minecraft:sea_lantern
setblock 377 268 500 minecraft:sea_lantern
setblock 377 268 502 minecraft:sea_lantern
setblock 377 268 504 minecraft:sea_lantern
setblock 378 268 499 minecraft:sea_lantern
setblock 378 268 501 minecraft:sea_lantern
setblock 378 268 503 minecraft:sea_lantern
setblock 379 268 498 minecraft:sea_lantern
setblock 379 268 500 minecraft:sea_lantern
setblock 379 268 502 minecraft:sea_lantern
setblock 379 268 504 minecraft:sea_lantern
setblock 380 268 499 minecraft:sea_lantern
setblock 380 268 501 minecraft:sea_lantern
setblock 380 268 503 minecraft:sea_lantern
setblock 381 268 498 minecraft:sea_lantern
setblock 381 268 500 minecraft:sea_lantern
setblock 381 268 502 minecraft:sea_lantern
setblock 381 268 504 minecraft:sea_lantern
setblock 382 268 499 minecraft:sea_lantern
setblock 382 268 501 minecraft:sea_lantern
setblock 382 268 503 minecraft:sea_lantern
setblock 383 268 498 minecraft:sea_lantern
setblock 383 268 500 minecraft:sea_lantern
setblock 383 268 502 minecraft:sea_lantern
setblock 383 268 504 minecraft:sea_lantern
setblock 384 268 499 minecraft:sea_lantern
setblock 384 268 501 minecraft:sea_lantern
setblock 384 268 503 minecraft:sea_lantern
setblock 408 268 495 minecraft:sea_lantern
setblock 408 268 497 minecraft:sea_lantern
setblock 408 268 499 minecraft:sea_lantern
setblock 408 268 501 minecraft:sea_lantern
setblock 408 268 503 minecraft:sea_lantern
setblock 408 268 505 minecraft:sea_lantern
setblock 409 268 494 minecraft:sea_lantern
setblock 409 268 496 minecraft:sea_lantern
setblock 409 268 498 minecraft:sea_lantern
setblock 409 268 500 minecraft:sea_lantern
setblock 409 268 502 minecraft:sea_lantern
setblock 409 268 504 minecraft:sea_lantern
setblock 410 268 495 minecraft:sea_lantern
setblock 410 268 497 minecraft:sea_lantern
setblock 410 268 499 minecraft:sea_lantern
setblock 410 268 501 minecraft:sea_lantern
setblock 410 268 503 minecraft:sea_lantern
setblock 410 268 505 minecraft:sea_lantern
setblock 411 268 494 minecraft:sea_lantern
setblock 411 268 496 minecraft:sea_lantern
setblock 411 268 498 minecraft:sea_lantern
setblock 411 268 500 minecraft:sea_lantern
setblock 411 268 502 minecraft:sea_lantern
setblock 411 268 504 minecraft:sea_lantern
setblock 412 268 495 minecraft:sea_lantern
setblock 412 268 497 minecraft:sea_lantern
setblock 412 268 499 minecraft:sea_lantern
setblock 412 268 501 minecraft:sea_lantern
setblock 412 268 503 minecraft:sea_lantern
setblock 412 268 505 minecraft:sea_lantern
setblock 413 268 494 minecraft:sea_lantern
setblock 413 268 496 minecraft:sea_lantern
setblock 413 268 498 minecraft:sea_lantern
setblock 413 268 500 minecraft:sea_lantern
setblock 413 268 502 minecraft:sea_lantern
setblock 413 268 504 minecraft:sea_lantern
setblock 414 268 495 minecraft:sea_lantern
setblock 414 268 497 minecraft:sea_lantern
setblock 414 268 499 minecraft:sea_lantern
setblock 414 268 501 minecraft:sea_lantern
setblock 414 268 503 minecraft:sea_lantern
setblock 414 268 505 minecraft:sea_lantern
setblock 415 268 494 minecraft:sea_lantern
setblock 415 268 496 minecraft:sea_lantern
setblock 415 268 498 minecraft:sea_lantern
setblock 415 268 500 minecraft:sea_lantern
setblock 415 268 502 minecraft:sea_lantern
setblock 415 268 504 minecraft:sea_lantern
setblock 416 268 495 minecraft:sea_lantern
setblock 416 268 497 minecraft:sea_lantern
setblock 416 268 499 minecraft:sea_lantern
setblock 416 268 501 minecraft:sea_lantern
setblock 416 268 503 minecraft:sea_lantern
setblock 416 268 505 minecraft:sea_lantern
setblock 417 268 494 minecraft:sea_lantern
setblock 417 268 496 minecraft:sea_lantern
setblock 417 268 498 minecraft:sea_lantern
setblock 417 268 500 minecraft:sea_lantern
setblock 417 268 502 minecraft:sea_lantern
setblock 417 268 504 minecraft:sea_lantern
fill 376 269 499 376 270 499 minecraft:magenta_concrete
fill 376 269 501 376 270 501 minecraft:magenta_concrete
fill 376 269 503 376 270 503 minecraft:magenta_concrete
fill 377 269 498 377 270 498 minecraft:black_concrete
fill 377 269 500 377 270 500 minecraft:black_concrete
fill 377 269 502 377 270 502 minecraft:black_concrete
fill 377 269 504 377 270 504 minecraft:black_concrete
fill 378 269 499 378 270 499 minecraft:black_concrete
fill 378 269 501 378 270 501 minecraft:black_concrete
fill 378 269 503 378 270 503 minecraft:black_concrete
fill 379 269 498 379 270 498 minecraft:black_concrete
fill 379 269 500 379 270 500 minecraft:black_concrete
fill 379 269 502 379 270 502 minecraft:black_concrete
fill 379 269 504 379 270 504 minecraft:black_concrete
fill 380 269 499 380 270 499 minecraft:black_concrete
fill 380 269 501 380 270 501 minecraft:black_concrete
fill 380 269 503 380 270 503 minecraft:black_concrete
fill 381 269 498 381 270 498 minecraft:black_concrete
fill 381 269 500 381 270 500 minecraft:black_concrete
fill 381 269 502 381 270 502 minecraft:black_concrete
fill 381 269 504 381 270 504 minecraft:black_concrete
fill 382 269 499 382 270 499 minecraft:black_concrete
fill 382 269 501 382 270 501 minecraft:black_concrete
fill 382 269 503 382 270 503 minecraft:black_concrete
fill 383 269 498 383 270 498 minecraft:black_concrete
fill 383 269 500 383 270 500 minecraft:black_concrete
fill 383 269 502 383 270 502 minecraft:black_concrete
fill 383 269 504 383 270 504 minecraft:black_concrete
fill 384 269 499 384 270 499 minecraft:black_concrete
fill 384 269 501 384 270 501 minecraft:black_concrete
fill 384 269 503 384 270 503 minecraft:black_concrete
fill 391 269 474 393 271 476 minecraft:magenta_concrete
fill 408 269 495 408 270 495 minecraft:black_concrete
fill 408 269 497 408 270 497 minecraft:black_concrete
fill 408 269 499 408 270 499 minecraft:black_concrete
fill 408 269 501 408 270 501 minecraft:black_concrete
fill 408 269 503 408 270 503 minecraft:black_concrete
fill 408 269 505 408 270 505 minecraft:magenta_concrete
fill 409 269 494 409 270 494 minecraft:black_concrete
fill 409 269 496 409 270 496 minecraft:black_concrete
fill 409 269 498 409 270 498 minecraft:black_concrete
fill 409 269 500 409 270 500 minecraft:black_concrete
fill 409 269 502 409 270 502 minecraft:black_concrete
fill 409 269 504 409 270 504 minecraft:black_concrete
fill 410 269 495 410 270 495 minecraft:black_concrete
fill 410 269 497 410 270 497 minecraft:black_concrete
fill 410 269 499 410 270 499 minecraft:black_concrete
fill 410 269 501 410 270 501 minecraft:black_concrete
fill 410 269 503 410 270 503 minecraft:black_concrete
fill 410 269 505 410 270 505 minecraft:magenta_concrete
fill 411 269 494 411 270 494 minecraft:black_concrete
fill 411 269 496 411 270 496 minecraft:black_concrete
fill 411 269 498 411 270 498 minecraft:black_concrete
fill 411 269 500 411 270 500 minecraft:black_concrete
fill 411 269 502 411 270 502 minecraft:black_concrete
fill 411 269 504 411 270 504 minecraft:black_concrete
fill 412 269 495 412 270 495 minecraft:black_concrete
fill 412 269 497 412 270 497 minecraft:black_concrete
fill 412 269 499 412 270 499 minecraft:black_concrete
fill 412 269 501 412 270 501 minecraft:black_concrete
fill 412 269 503 412 270 503 minecraft:black_concrete
fill 412 269 505 412 270 505 minecraft:magenta_concrete
fill 413 269 494 413 270 494 minecraft:black_concrete
fill 413 269 496 413 270 496 minecraft:black_concrete
fill 413 269 498 413 270 498 minecraft:black_concrete
fill 413 269 500 413 270 500 minecraft:black_concrete
fill 413 269 502 413 270 502 minecraft:black_concrete
fill 413 269 504 413 270 504 minecraft:black_concrete
fill 414 269 495 414 270 495 minecraft:black_concrete
fill 414 269 497 414 270 497 minecraft:black_concrete
fill 414 269 499 414 270 499 minecraft:black_concrete
fill 414 269 501 414 270 501 minecraft:black_concrete
fill 414 269 503 414 270 503 minecraft:black_concrete
fill 414 269 505 414 270 505 minecraft:magenta_concrete
fill 415 269 494 415 270 494 minecraft:black_concrete
fill 415 269 496 415 270 496 minecraft:black_concrete
fill 415 269 498 415 270 498 minecraft:black_concrete
fill 415 269 500 415 270 500 minecraft:black_concrete
fill 415 269 502 415 270 502 minecraft:black_concrete
fill 415 269 504 415 270 504 minecraft:black_concrete
fill 416 269 495 416 270 495 minecraft:black_concrete
fill 416 269 497 416 270 497 minecraft:black_concrete
fill 416 269 499 416 270 499 minecraft:black_concrete
fill 416 269 501 416 270 501 minecraft:black_concrete
fill 416 269 503 416 270 503 minecraft:black_concrete
fill 416 269 505 416 270 505 minecraft:magenta_concrete
fill 417 269 494 417 270 494 minecraft:black_concrete
fill 417 269 496 417 270 496 minecraft:black_concrete
fill 417 269 498 417 270 498 minecraft:black_concrete
fill 417 269 500 417 270 500 minecraft:black_concrete
fill 417 269 502 417 270 502 minecraft:black_concrete
fill 417 269 504 417 270 504 minecraft:black_concrete
fill 376 270 468 376 273 468 minecraft:sea_lantern
fill 376 270 476 376 273 476 minecraft:sea_lantern
fill 376 270 484 376 273 484 minecraft:sea_lantern
fill 376 270 492 376 273 492 minecraft:sea_lantern
fill 376 270 500 376 273 500 minecraft:sea_lantern
fill 379 270 505 379 273 505 minecraft:sea_lantern
fill 383 270 463 383 273 463 minecraft:sea_lantern
fill 387 270 505 387 273 505 minecraft:sea_lantern
fill 391 270 463 391 273 463 minecraft:sea_lantern
fill 395 270 505 395 273 505 minecraft:sea_lantern
fill 399 270 463 399 273 463 minecraft:sea_lantern
fill 403 270 505 403 273 505 minecraft:sea_lantern
fill 407 270 463 407 273 463 minecraft:sea_lantern
fill 411 270 505 411 273 505 minecraft:sea_lantern
fill 415 270 463 415 273 463 minecraft:sea_lantern
fill 418 270 468 418 273 468 minecraft:sea_lantern
fill 418 270 476 418 273 476 minecraft:sea_lantern
fill 418 270 484 418 273 484 minecraft:sea_lantern
fill 418 270 492 418 273 492 minecraft:sea_lantern
fill 418 270 500 418 273 500 minecraft:sea_lantern
setblock 376 271 499 minecraft:sea_lantern
setblock 376 271 501 minecraft:sea_lantern
setblock 376 271 503 minecraft:sea_lantern
setblock 377 271 498 minecraft:sea_lantern
setblock 377 271 500 minecraft:sea_lantern
setblock 377 271 502 minecraft:sea_lantern
setblock 377 271 504 minecraft:sea_lantern
setblock 378 271 499 minecraft:sea_lantern
setblock 378 271 501 minecraft:sea_lantern
setblock 378 271 503 minecraft:sea_lantern
setblock 379 271 498 minecraft:sea_lantern
setblock 379 271 500 minecraft:sea_lantern
setblock 379 271 502 minecraft:sea_lantern
setblock 379 271 504 minecraft:sea_lantern
setblock 380 271 499 minecraft:sea_lantern
setblock 380 271 501 minecraft:sea_lantern
setblock 380 271 503 minecraft:sea_lantern
setblock 381 271 498 minecraft:sea_lantern
setblock 381 271 500 minecraft:sea_lantern
setblock 381 271 502 minecraft:sea_lantern
setblock 381 271 504 minecraft:sea_lantern
setblock 382 271 499 minecraft:sea_lantern
setblock 382 271 501 minecraft:sea_lantern
setblock 382 271 503 minecraft:sea_lantern
setblock 383 271 498 minecraft:sea_lantern
setblock 383 271 500 minecraft:sea_lantern
setblock 383 271 502 minecraft:sea_lantern
setblock 383 271 504 minecraft:sea_lantern
setblock 384 271 499 minecraft:sea_lantern
setblock 384 271 501 minecraft:sea_lantern
setblock 384 271 503 minecraft:sea_lantern
fill 397 271 485 400 273 488 minecraft:white_concrete
setblock 408 271 495 minecraft:sea_lantern
setblock 408 271 497 minecraft:sea_lantern
setblock 408 271 499 minecraft:sea_lantern
setblock 408 271 501 minecraft:sea_lantern
setblock 408 271 503 minecraft:sea_lantern
setblock 408 271 505 minecraft:sea_lantern
setblock 409 271 494 minecraft:sea_lantern
setblock 409 271 496 minecraft:sea_lantern
setblock 409 271 498 minecraft:sea_lantern
setblock 409 271 500 minecraft:sea_lantern
setblock 409 271 502 minecraft:sea_lantern
setblock 409 271 504 minecraft:sea_lantern
setblock 410 271 495 minecraft:sea_lantern
setblock 410 271 497 minecraft:sea_lantern
setblock 410 271 499 minecraft:sea_lantern
setblock 410 271 501 minecraft:sea_lantern
setblock 410 271 503 minecraft:sea_lantern
setblock 410 271 505 minecraft:sea_lantern
setblock 411 271 494 minecraft:sea_lantern
setblock 411 271 496 minecraft:sea_lantern
setblock 411 271 498 minecraft:sea_lantern
setblock 411 271 500 minecraft:sea_lantern
setblock 411 271 502 minecraft:sea_lantern
setblock 411 271 504 minecraft:sea_lantern
setblock 412 271 495 minecraft:sea_lantern
setblock 412 271 497 minecraft:sea_lantern
setblock 412 271 499 minecraft:sea_lantern
setblock 412 271 501 minecraft:sea_lantern
setblock 412 271 503 minecraft:sea_lantern
setblock 412 271 505 minecraft:sea_lantern
setblock 413 271 494 minecraft:sea_lantern
setblock 413 271 496 minecraft:sea_lantern
setblock 413 271 498 minecraft:sea_lantern
setblock 413 271 500 minecraft:sea_lantern
setblock 413 271 502 minecraft:sea_lantern
setblock 413 271 504 minecraft:sea_lantern
setblock 414 271 495 minecraft:sea_lantern
setblock 414 271 497 minecraft:sea_lantern
setblock 414 271 499 minecraft:sea_lantern
setblock 414 271 501 minecraft:sea_lantern
setblock 414 271 503 minecraft:sea_lantern
setblock 414 271 505 minecraft:sea_lantern
setblock 415 271 494 minecraft:sea_lantern
setblock 415 271 496 minecraft:sea_lantern
setblock 415 271 498 minecraft:sea_lantern
setblock 415 271 500 minecraft:sea_lantern
setblock 415 271 502 minecraft:sea_lantern
setblock 415 271 504 minecraft:sea_lantern
setblock 416 271 495 minecraft:sea_lantern
setblock 416 271 497 minecraft:sea_lantern
setblock 416 271 499 minecraft:sea_lantern
setblock 416 271 501 minecraft:sea_lantern
setblock 416 271 503 minecraft:sea_lantern
setblock 416 271 505 minecraft:sea_lantern
setblock 417 271 494 minecraft:sea_lantern
setblock 417 271 496 minecraft:sea_lantern
setblock 417 271 498 minecraft:sea_lantern
setblock 417 271 500 minecraft:sea_lantern
setblock 417 271 502 minecraft:sea_lantern
setblock 417 271 504 minecraft:sea_lantern
fill 376 272 499 376 307 499 minecraft:magenta_concrete
fill 376 272 501 376 307 501 minecraft:magenta_concrete
fill 376 272 503 376 307 503 minecraft:magenta_concrete
fill 377 272 498 377 273 498 minecraft:black_concrete
fill 377 272 500 377 273 500 minecraft:black_concrete
fill 377 272 502 377 273 502 minecraft:black_concrete
fill 377 272 504 377 273 504 minecraft:black_concrete
fill 378 272 499 378 273 499 minecraft:black_concrete
fill 378 272 501 378 273 501 minecraft:black_concrete
fill 378 272 503 378 273 503 minecraft:black_concrete
setblock 379 272 466 minecraft:light[level=14]
setblock 379 272 474 minecraft:light[level=14]
setblock 379 272 482 minecraft:light[level=14]
setblock 379 272 490 minecraft:light[level=14]
fill 379 272 498 379 273 498 minecraft:black_concrete
fill 379 272 500 379 273 500 minecraft:black_concrete
fill 379 272 502 379 273 502 minecraft:black_concrete
fill 379 272 504 379 273 504 minecraft:black_concrete
fill 380 272 499 380 273 499 minecraft:black_concrete
fill 380 272 501 380 273 501 minecraft:black_concrete
fill 380 272 503 380 273 503 minecraft:black_concrete
fill 381 272 498 381 273 498 minecraft:black_concrete
fill 381 272 500 381 273 500 minecraft:black_concrete
fill 381 272 502 381 273 502 minecraft:black_concrete
fill 381 272 504 381 273 504 minecraft:black_concrete
fill 382 272 499 382 273 499 minecraft:black_concrete
fill 382 272 501 382 273 501 minecraft:black_concrete
fill 382 272 503 382 273 503 minecraft:black_concrete
fill 383 272 498 383 273 498 minecraft:black_concrete
fill 383 272 500 383 273 500 minecraft:black_concrete
fill 383 272 502 383 273 502 minecraft:black_concrete
fill 383 272 504 383 273 504 minecraft:black_concrete
fill 384 272 499 384 273 499 minecraft:black_concrete
fill 384 272 501 384 273 501 minecraft:black_concrete
fill 384 272 503 384 273 503 minecraft:black_concrete
setblock 387 272 466 minecraft:light[level=14]
setblock 387 272 474 minecraft:light[level=14]
setblock 387 272 482 minecraft:light[level=14]
setblock 387 272 490 minecraft:light[level=14]
setblock 387 272 498 minecraft:light[level=14]
setblock 395 272 466 minecraft:light[level=14]
setblock 395 272 474 minecraft:light[level=14]
setblock 395 272 482 minecraft:light[level=14]
setblock 395 272 490 minecraft:light[level=14]
setblock 395 272 498 minecraft:light[level=14]
setblock 403 272 466 minecraft:light[level=14]
setblock 403 272 474 minecraft:light[level=14]
setblock 403 272 482 minecraft:light[level=14]
setblock 403 272 490 minecraft:light[level=14]
setblock 403 272 498 minecraft:light[level=14]
fill 408 272 495 408 273 495 minecraft:black_concrete
fill 408 272 497 408 273 497 minecraft:black_concrete
fill 408 272 499 408 273 499 minecraft:black_concrete
fill 408 272 501 408 273 501 minecraft:black_concrete
fill 408 272 503 408 273 503 minecraft:black_concrete
fill 408 272 505 408 307 505 minecraft:magenta_concrete
fill 409 272 494 409 273 494 minecraft:black_concrete
fill 409 272 496 409 273 496 minecraft:black_concrete
fill 409 272 498 409 273 498 minecraft:black_concrete
fill 409 272 500 409 273 500 minecraft:black_concrete
fill 409 272 502 409 273 502 minecraft:black_concrete
fill 409 272 504 409 273 504 minecraft:black_concrete
fill 410 272 495 410 273 495 minecraft:black_concrete
fill 410 272 497 410 273 497 minecraft:black_concrete
fill 410 272 499 410 273 499 minecraft:black_concrete
fill 410 272 501 410 273 501 minecraft:black_concrete
fill 410 272 503 410 273 503 minecraft:black_concrete
fill 410 272 505 410 307 505 minecraft:magenta_concrete
setblock 411 272 466 minecraft:light[level=14]
setblock 411 272 474 minecraft:light[level=14]
setblock 411 272 482 minecraft:light[level=14]
setblock 411 272 490 minecraft:light[level=14]
fill 411 272 494 411 273 494 minecraft:black_concrete
fill 411 272 496 411 273 496 minecraft:black_concrete
fill 411 272 498 411 273 498 minecraft:black_concrete
fill 411 272 500 411 273 500 minecraft:black_concrete
fill 411 272 502 411 273 502 minecraft:black_concrete
fill 411 272 504 411 273 504 minecraft:black_concrete
fill 412 272 495 412 273 495 minecraft:black_concrete
fill 412 272 497 412 273 497 minecraft:black_concrete
fill 412 272 499 412 273 499 minecraft:black_concrete
fill 412 272 501 412 273 501 minecraft:black_concrete
fill 412 272 503 412 273 503 minecraft:black_concrete
fill 412 272 505 412 307 505 minecraft:magenta_concrete
fill 413 272 494 413 273 494 minecraft:black_concrete
fill 413 272 496 413 273 496 minecraft:black_concrete
fill 413 272 498 413 273 498 minecraft:black_concrete
fill 413 272 500 413 273 500 minecraft:black_concrete
fill 413 272 502 413 273 502 minecraft:black_concrete
fill 413 272 504 413 273 504 minecraft:black_concrete
fill 414 272 495 414 273 495 minecraft:black_concrete
fill 414 272 497 414 273 497 minecraft:black_concrete
fill 414 272 499 414 273 499 minecraft:black_concrete
fill 414 272 501 414 273 501 minecraft:black_concrete
fill 414 272 503 414 273 503 minecraft:black_concrete
fill 414 272 505 414 307 505 minecraft:magenta_concrete
fill 415 272 494 415 273 494 minecraft:black_concrete
fill 415 272 496 415 273 496 minecraft:black_concrete
fill 415 272 498 415 273 498 minecraft:black_concrete
fill 415 272 500 415 273 500 minecraft:black_concrete
fill 415 272 502 415 273 502 minecraft:black_concrete
fill 415 272 504 415 273 504 minecraft:black_concrete
fill 416 272 495 416 273 495 minecraft:black_concrete
fill 416 272 497 416 273 497 minecraft:black_concrete
fill 416 272 499 416 273 499 minecraft:black_concrete
fill 416 272 501 416 273 501 minecraft:black_concrete
fill 416 272 503 416 273 503 minecraft:black_concrete
fill 416 272 505 416 307 505 minecraft:magenta_concrete
fill 417 272 494 417 273 494 minecraft:black_concrete
fill 417 272 496 417 273 496 minecraft:black_concrete
fill 417 272 498 417 273 498 minecraft:black_concrete
fill 417 272 500 417 273 500 minecraft:black_concrete
fill 417 272 502 417 273 502 minecraft:black_concrete
fill 417 272 504 417 273 504 minecraft:black_concrete
fill 376 274 468 376 283 468 minecraft:magenta_concrete
fill 376 274 476 376 283 476 minecraft:magenta_concrete
fill 376 274 484 376 283 484 minecraft:magenta_concrete
fill 376 274 492 376 283 492 minecraft:magenta_concrete
fill 376 274 500 376 283 500 minecraft:magenta_concrete
fill 379 274 505 379 283 505 minecraft:magenta_concrete
fill 383 274 463 383 283 463 minecraft:magenta_concrete
fill 387 274 505 387 283 505 minecraft:magenta_concrete
fill 391 274 463 391 283 463 minecraft:magenta_concrete
fill 395 274 505 395 283 505 minecraft:magenta_concrete
fill 399 274 463 399 283 463 minecraft:magenta_concrete
fill 403 274 505 403 283 505 minecraft:magenta_concrete
fill 407 274 463 407 283 463 minecraft:magenta_concrete
fill 411 274 505 411 283 505 minecraft:magenta_concrete
fill 415 274 463 415 283 463 minecraft:magenta_concrete
fill 418 274 468 418 283 468 minecraft:magenta_concrete
fill 418 274 476 418 283 476 minecraft:magenta_concrete
fill 418 274 484 418 283 484 minecraft:magenta_concrete
fill 418 274 492 418 283 492 minecraft:magenta_concrete
fill 418 274 500 418 283 500 minecraft:magenta_concrete
fill 377 279 464 380 280 465 minecraft:black_concrete
fill 377 279 466 380 280 469 minecraft:magenta_concrete
fill 377 279 470 380 280 473 minecraft:black_concrete
fill 377 279 474 380 280 477 minecraft:magenta_concrete
fill 377 279 478 380 280 481 minecraft:black_concrete
fill 377 279 482 380 280 485 minecraft:magenta_concrete
fill 377 279 486 380 280 489 minecraft:black_concrete
fill 377 279 490 380 280 493 minecraft:magenta_concrete
fill 377 279 494 380 280 497 minecraft:black_concrete
fill 377 279 498 380 280 501 minecraft:magenta_concrete
fill 377 279 502 380 280 504 minecraft:black_concrete
fill 381 279 464 384 280 465 minecraft:magenta_concrete
fill 381 279 466 384 280 469 minecraft:black_concrete
fill 381 279 470 384 280 473 minecraft:magenta_concrete
fill 381 279 474 384 280 477 minecraft:black_concrete
fill 381 279 478 384 280 481 minecraft:magenta_concrete
fill 381 279 482 384 280 485 minecraft:black_concrete
fill 381 279 486 384 280 489 minecraft:magenta_concrete
fill 381 279 490 384 280 493 minecraft:black_concrete
fill 381 279 494 384 280 497 minecraft:magenta_concrete
fill 381 279 498 384 280 501 minecraft:black_concrete
fill 381 279 502 384 280 504 minecraft:magenta_concrete
fill 385 279 464 388 280 465 minecraft:black_concrete
fill 385 279 466 388 280 469 minecraft:magenta_concrete
fill 385 279 470 388 280 473 minecraft:black_concrete
fill 385 279 474 388 280 477 minecraft:magenta_concrete
fill 385 279 478 388 280 481 minecraft:black_concrete
fill 385 279 482 388 280 485 minecraft:magenta_concrete
fill 385 279 486 388 280 489 minecraft:black_concrete
fill 385 279 490 388 280 493 minecraft:magenta_concrete
fill 385 279 494 388 280 497 minecraft:black_concrete
fill 385 279 498 388 280 501 minecraft:magenta_concrete
fill 385 279 502 388 280 504 minecraft:black_concrete
fill 389 279 464 392 280 465 minecraft:magenta_concrete
fill 389 279 466 392 280 469 minecraft:black_concrete
fill 389 279 470 392 280 473 minecraft:magenta_concrete
fill 389 279 474 392 280 477 minecraft:black_concrete
fill 389 279 478 392 280 481 minecraft:magenta_concrete
fill 389 279 482 392 280 485 minecraft:black_concrete
fill 389 279 486 392 280 489 minecraft:magenta_concrete
fill 389 279 490 392 280 493 minecraft:black_concrete
fill 389 279 494 392 280 497 minecraft:magenta_concrete
fill 389 279 498 392 280 501 minecraft:black_concrete
fill 389 279 502 392 280 504 minecraft:magenta_concrete
fill 393 279 464 396 280 465 minecraft:black_concrete
fill 393 279 466 396 280 469 minecraft:magenta_concrete
fill 393 279 470 396 280 473 minecraft:black_concrete
fill 393 279 474 396 280 477 minecraft:magenta_concrete
fill 393 279 478 395 279 481 minecraft:black_concrete
fill 393 279 482 394 279 485 minecraft:magenta_concrete
fill 393 279 486 396 280 489 minecraft:black_concrete
fill 393 279 490 396 280 493 minecraft:magenta_concrete
fill 393 279 494 396 280 497 minecraft:black_concrete
fill 393 279 498 396 280 501 minecraft:magenta_concrete
fill 393 279 502 396 280 504 minecraft:black_concrete
fill 395 279 483 395 279 485 minecraft:magenta_concrete
fill 396 279 478 396 279 480 minecraft:black_concrete
fill 396 279 484 396 279 485 minecraft:magenta_concrete
fill 397 279 464 400 280 465 minecraft:magenta_concrete
fill 397 279 466 400 280 469 minecraft:black_concrete
fill 397 279 470 400 280 473 minecraft:magenta_concrete
fill 397 279 474 400 280 477 minecraft:black_concrete
fill 397 279 478 400 279 479 minecraft:magenta_concrete
fill 397 279 485 400 279 485 minecraft:black_concrete
fill 397 279 486 400 280 489 minecraft:magenta_concrete
fill 397 279 490 400 280 493 minecraft:black_concrete
fill 397 279 494 400 280 497 minecraft:magenta_concrete
fill 397 279 498 400 280 501 minecraft:black_concrete
fill 397 279 502 400 280 504 minecraft:magenta_concrete
fill 398 279 480 400 279 480 minecraft:magenta_concrete
fill 398 279 484 400 279 484 minecraft:black_concrete
fill 399 279 481 400 279 481 minecraft:magenta_concrete
fill 399 279 483 400 279 483 minecraft:black_concrete
setblock 400 279 482 minecraft:black_concrete
fill 401 279 464 404 280 465 minecraft:black_concrete
fill 401 279 466 404 280 469 minecraft:magenta_concrete
fill 401 279 470 404 280 473 minecraft:black_concrete
fill 401 279 474 404 280 477 minecraft:magenta_concrete
fill 401 279 478 404 280 481 minecraft:black_concrete
fill 401 279 482 404 280 485 minecraft:magenta_concrete
fill 401 279 486 404 280 489 minecraft:black_concrete
fill 401 279 490 404 280 493 minecraft:magenta_concrete
fill 401 279 494 404 280 497 minecraft:black_concrete
fill 401 279 498 404 280 501 minecraft:magenta_concrete
fill 401 279 502 404 280 504 minecraft:black_concrete
fill 405 279 464 408 280 465 minecraft:magenta_concrete
fill 405 279 466 408 280 469 minecraft:black_concrete
fill 405 279 470 408 280 473 minecraft:magenta_concrete
fill 405 279 474 408 280 477 minecraft:black_concrete
fill 405 279 478 408 280 481 minecraft:magenta_concrete
fill 405 279 482 408 280 485 minecraft:black_concrete
fill 405 279 486 408 280 489 minecraft:magenta_concrete
fill 405 279 490 408 280 493 minecraft:black_concrete
fill 405 279 494 408 280 497 minecraft:magenta_concrete
fill 405 279 498 408 280 501 minecraft:black_concrete
fill 405 279 502 408 280 504 minecraft:magenta_concrete
fill 409 279 464 412 280 465 minecraft:black_concrete
fill 409 279 466 412 280 469 minecraft:magenta_concrete
fill 409 279 470 412 280 473 minecraft:black_concrete
fill 409 279 474 412 280 477 minecraft:magenta_concrete
fill 409 279 478 412 280 481 minecraft:black_concrete
fill 409 279 482 412 280 485 minecraft:magenta_concrete
fill 409 279 486 412 280 489 minecraft:black_concrete
fill 409 279 490 412 280 493 minecraft:magenta_concrete
fill 409 279 494 412 280 497 minecraft:black_concrete
fill 409 279 498 412 280 501 minecraft:magenta_concrete
fill 409 279 502 412 280 504 minecraft:black_concrete
fill 413 279 464 416 280 465 minecraft:magenta_concrete
fill 413 279 466 416 280 469 minecraft:black_concrete
fill 413 279 470 416 280 473 minecraft:magenta_concrete
fill 413 279 474 416 280 477 minecraft:black_concrete
fill 413 279 478 416 280 481 minecraft:magenta_concrete
fill 413 279 482 416 280 485 minecraft:black_concrete
fill 413 279 486 416 280 489 minecraft:magenta_concrete
fill 413 279 490 416 280 493 minecraft:black_concrete
fill 413 279 494 416 280 497 minecraft:magenta_concrete
fill 413 279 498 416 280 501 minecraft:black_concrete
fill 413 279 502 416 280 504 minecraft:magenta_concrete
fill 417 279 464 417 280 465 minecraft:black_concrete
fill 417 279 466 417 280 469 minecraft:magenta_concrete
fill 417 279 470 417 280 473 minecraft:black_concrete
fill 417 279 474 417 280 477 minecraft:magenta_concrete
fill 417 279 478 417 280 481 minecraft:black_concrete
fill 417 279 482 417 280 485 minecraft:magenta_concrete
fill 417 279 486 417 280 489 minecraft:black_concrete
fill 417 279 490 417 280 493 minecraft:magenta_concrete
fill 417 279 494 417 280 497 minecraft:black_concrete
fill 417 279 498 417 280 501 minecraft:magenta_concrete
fill 417 279 502 417 280 504 minecraft:black_concrete
fill 393 280 478 393 280 481 minecraft:black_concrete
fill 393 280 482 393 280 485 minecraft:magenta_concrete
fill 394 280 478 394 280 480 minecraft:black_concrete
fill 394 280 481 394 280 483 minecraft:sea_lantern
fill 394 280 484 394 280 485 minecraft:magenta_concrete
fill 395 280 478 395 280 479 minecraft:black_concrete
fill 395 280 480 395 280 481 minecraft:sea_lantern
fill 395 280 483 395 280 484 minecraft:sea_lantern
setblock 395 280 485 minecraft:magenta_concrete
setblock 396 280 478 minecraft:black_concrete
fill 396 280 479 396 280 480 minecraft:sea_lantern
fill 396 280 484 396 280 485 minecraft:sea_lantern
fill 397 280 478 400 280 478 minecraft:magenta_concrete
fill 397 280 479 398 280 479 minecraft:sea_lantern
fill 397 280 485 398 280 485 minecraft:sea_lantern
fill 398 280 480 399 280 480 minecraft:sea_lantern
fill 398 280 484 399 280 484 minecraft:sea_lantern
fill 399 280 479 400 280 479 minecraft:magenta_concrete
fill 399 280 481 400 280 481 minecraft:sea_lantern
fill 399 280 483 400 280 483 minecraft:sea_lantern
fill 399 280 485 400 280 485 minecraft:black_concrete
setblock 400 280 480 minecraft:magenta_concrete
setblock 400 280 482 minecraft:sea_lantern
setblock 400 280 484 minecraft:black_concrete
fill 376 284 468 376 289 468 minecraft:sea_lantern
fill 376 284 476 376 289 476 minecraft:sea_lantern
fill 376 284 484 376 289 484 minecraft:sea_lantern
fill 376 284 492 376 289 492 minecraft:sea_lantern
fill 376 284 500 376 289 500 minecraft:sea_lantern
fill 377 284 470 377 300 471 minecraft:black_concrete
fill 377 284 478 377 300 479 minecraft:black_concrete
fill 377 284 486 377 300 487 minecraft:black_concrete
fill 377 284 494 377 298 504 minecraft:black_concrete
fill 378 284 464 379 300 464 minecraft:black_concrete
fill 378 284 496 388 285 504 minecraft:black_concrete
fill 379 284 505 379 289 505 minecraft:sea_lantern
fill 380 284 468 382 286 470 minecraft:black_concrete
fill 383 284 463 383 289 463 minecraft:sea_lantern
fill 386 284 464 387 300 464 minecraft:black_concrete
fill 387 284 505 387 289 505 minecraft:sea_lantern
fill 389 284 499 394 285 504 minecraft:black_concrete
fill 391 284 463 391 289 463 minecraft:sea_lantern
fill 394 284 464 395 300 464 minecraft:black_concrete
fill 395 284 505 395 289 505 minecraft:sea_lantern
fill 399 284 463 399 289 463 minecraft:sea_lantern
fill 399 284 504 400 300 504 minecraft:black_concrete
fill 402 284 464 403 300 464 minecraft:black_concrete
fill 403 284 505 403 289 505 minecraft:sea_lantern
fill 407 284 463 407 289 463 minecraft:sea_lantern
fill 407 284 504 408 300 504 minecraft:black_concrete
fill 410 284 464 411 300 464 minecraft:black_concrete
fill 411 284 505 411 289 505 minecraft:sea_lantern
fill 412 284 472 415 284 474 minecraft:magenta_concrete
fill 412 284 475 417 285 485 minecraft:black_concrete
fill 413 284 471 414 284 471 minecraft:magenta_concrete
fill 415 284 463 415 289 463 minecraft:sea_lantern
fill 415 284 504 416 300 504 minecraft:black_concrete
setblock 416 284 473 minecraft:magenta_concrete
fill 417 284 465 417 300 466 minecraft:black_concrete
fill 417 284 473 417 285 474 minecraft:black_concrete
fill 417 284 489 417 300 490 minecraft:black_concrete
fill 417 284 497 417 300 498 minecraft:black_concrete
fill 418 284 468 418 289 468 minecraft:sea_lantern
fill 418 284 476 418 289 476 minecraft:sea_lantern
fill 418 284 484 418 289 484 minecraft:sea_lantern
fill 418 284 492 418 289 492 minecraft:sea_lantern
fill 418 284 500 418 289 500 minecraft:sea_lantern
fill 411 285 467 411 285 479 minecraft:black_concrete
fill 412 285 467 416 285 474 minecraft:black_concrete
fill 417 285 467 417 285 472 minecraft:black_concrete
fill 378 286 496 387 298 504 minecraft:black_concrete
fill 388 286 496 388 298 498 minecraft:black_concrete
setblock 388 286 499 minecraft:sea_lantern
fill 388 286 500 388 300 500 minecraft:black_concrete
setblock 388 286 501 minecraft:sea_lantern
fill 388 286 502 388 300 502 minecraft:black_concrete
setblock 388 286 503 minecraft:sea_lantern
fill 388 286 504 388 300 504 minecraft:black_concrete
fill 389 286 499 389 300 499 minecraft:black_concrete
setblock 389 286 500 minecraft:sea_lantern
fill 389 286 501 389 300 501 minecraft:black_concrete
setblock 389 286 502 minecraft:sea_lantern
fill 389 286 503 389 300 503 minecraft:black_concrete
setblock 389 286 504 minecraft:sea_lantern
setblock 390 286 499 minecraft:sea_lantern
fill 390 286 500 390 300 500 minecraft:black_concrete
setblock 390 286 501 minecraft:sea_lantern
fill 390 286 502 390 300 502 minecraft:black_concrete
setblock 390 286 503 minecraft:sea_lantern
fill 390 286 504 390 300 504 minecraft:black_concrete
fill 391 286 499 391 300 499 minecraft:black_concrete
setblock 391 286 500 minecraft:sea_lantern
fill 391 286 501 391 300 501 minecraft:black_concrete
setblock 391 286 502 minecraft:sea_lantern
fill 391 286 503 391 300 503 minecraft:black_concrete
setblock 391 286 504 minecraft:sea_lantern
setblock 392 286 499 minecraft:sea_lantern
fill 392 286 500 392 300 500 minecraft:black_concrete
setblock 392 286 501 minecraft:sea_lantern
fill 392 286 502 392 300 502 minecraft:black_concrete
setblock 392 286 503 minecraft:sea_lantern
fill 392 286 504 392 300 504 minecraft:black_concrete
fill 393 286 499 393 300 499 minecraft:black_concrete
setblock 393 286 500 minecraft:sea_lantern
fill 393 286 501 393 300 501 minecraft:black_concrete
setblock 393 286 502 minecraft:sea_lantern
fill 393 286 503 393 300 503 minecraft:black_concrete
setblock 393 286 504 minecraft:sea_lantern
setblock 394 286 499 minecraft:sea_lantern
fill 394 286 500 394 300 500 minecraft:black_concrete
setblock 394 286 501 minecraft:sea_lantern
fill 394 286 502 394 300 502 minecraft:black_concrete
setblock 394 286 503 minecraft:sea_lantern
fill 394 286 504 394 300 504 minecraft:black_concrete
fill 411 286 467 411 300 467 minecraft:black_concrete
setblock 411 286 468 minecraft:sea_lantern
fill 411 286 469 411 300 469 minecraft:black_concrete
setblock 411 286 470 minecraft:sea_lantern
fill 411 286 471 411 300 471 minecraft:black_concrete
setblock 411 286 472 minecraft:sea_lantern
fill 411 286 473 411 300 473 minecraft:black_concrete
setblock 411 286 474 minecraft:sea_lantern
fill 411 286 475 411 300 475 minecraft:black_concrete
setblock 411 286 476 minecraft:sea_lantern
fill 411 286 477 411 300 477 minecraft:black_concrete
setblock 411 286 478 minecraft:sea_lantern
fill 411 286 479 411 300 479 minecraft:black_concrete
setblock 412 286 467 minecraft:sea_lantern
fill 412 286 468 412 300 468 minecraft:black_concrete
setblock 412 286 469 minecraft:sea_lantern
fill 412 286 470 412 300 470 minecraft:black_concrete
setblock 412 286 471 minecraft:sea_lantern
fill 412 286 472 412 299 472 minecraft:black_concrete
setblock 412 286 473 minecraft:sea_lantern
fill 412 286 474 412 299 474 minecraft:black_concrete
setblock 412 286 475 minecraft:sea_lantern
fill 412 286 476 412 300 476 minecraft:black_concrete
setblock 412 286 477 minecraft:sea_lantern
fill 412 286 478 412 300 478 minecraft:black_concrete
setblock 412 286 479 minecraft:sea_lantern
fill 412 286 480 412 300 480 minecraft:black_concrete
setblock 412 286 481 minecraft:sea_lantern
fill 412 286 482 412 300 482 minecraft:black_concrete
setblock 412 286 483 minecraft:sea_lantern
fill 412 286 484 412 300 484 minecraft:black_concrete
setblock 412 286 485 minecraft:sea_lantern
fill 413 286 467 413 300 467 minecraft:black_concrete
setblock 413 286 468 minecraft:sea_lantern
fill 413 286 469 413 300 469 minecraft:black_concrete
setblock 413 286 470 minecraft:sea_lantern
fill 413 286 471 413 299 471 minecraft:black_concrete
setblock 413 286 472 minecraft:sea_lantern
fill 413 286 473 413 299 473 minecraft:black_concrete
setblock 413 286 474 minecraft:sea_lantern
fill 413 286 475 413 300 475 minecraft:black_concrete
setblock 413 286 476 minecraft:sea_lantern
fill 413 286 477 413 300 477 minecraft:black_concrete
setblock 413 286 478 minecraft:sea_lantern
fill 413 286 479 413 300 479 minecraft:black_concrete
setblock 413 286 480 minecraft:sea_lantern
fill 413 286 481 413 300 481 minecraft:black_concrete
setblock 413 286 482 minecraft:sea_lantern
fill 413 286 483 413 300 483 minecraft:black_concrete
setblock 413 286 484 minecraft:sea_lantern
fill 413 286 485 413 300 485 minecraft:black_concrete
setblock 414 286 467 minecraft:sea_lantern
fill 414 286 468 414 300 468 minecraft:black_concrete
setblock 414 286 469 minecraft:sea_lantern
fill 414 286 470 414 300 470 minecraft:black_concrete
setblock 414 286 471 minecraft:sea_lantern
fill 414 286 472 414 299 472 minecraft:black_concrete
setblock 414 286 473 minecraft:sea_lantern
fill 414 286 474 414 299 474 minecraft:black_concrete
setblock 414 286 475 minecraft:sea_lantern
fill 414 286 476 414 300 476 minecraft:black_concrete
setblock 414 286 477 minecraft:sea_lantern
fill 414 286 478 414 300 478 minecraft:black_concrete
setblock 414 286 479 minecraft:sea_lantern
fill 414 286 480 414 300 480 minecraft:black_concrete
setblock 414 286 481 minecraft:sea_lantern
fill 414 286 482 414 300 482 minecraft:black_concrete
setblock 414 286 483 minecraft:sea_lantern
fill 414 286 484 414 300 484 minecraft:black_concrete
setblock 414 286 485 minecraft:sea_lantern
fill 415 286 467 415 300 467 minecraft:black_concrete
setblock 415 286 468 minecraft:sea_lantern
fill 415 286 469 415 300 469 minecraft:black_concrete
setblock 415 286 470 minecraft:sea_lantern
fill 415 286 471 415 299 471 minecraft:black_concrete
setblock 415 286 472 minecraft:sea_lantern
fill 415 286 473 415 299 473 minecraft:black_concrete
setblock 415 286 474 minecraft:sea_lantern
fill 415 286 475 415 300 475 minecraft:black_concrete
setblock 415 286 476 minecraft:sea_lantern
fill 415 286 477 415 300 477 minecraft:black_concrete
setblock 415 286 478 minecraft:sea_lantern
fill 415 286 479 415 300 479 minecraft:black_concrete
setblock 415 286 480 minecraft:sea_lantern
fill 415 286 481 415 300 481 minecraft:black_concrete
setblock 415 286 482 minecraft:sea_lantern
fill 415 286 483 415 300 483 minecraft:black_concrete
setblock 415 286 484 minecraft:sea_lantern
fill 415 286 485 415 300 485 minecraft:black_concrete
setblock 416 286 467 minecraft:sea_lantern
fill 416 286 468 416 300 468 minecraft:black_concrete
setblock 416 286 469 minecraft:sea_lantern
fill 416 286 470 416 300 470 minecraft:black_concrete
setblock 416 286 471 minecraft:sea_lantern
fill 416 286 472 416 300 472 minecraft:black_concrete
setblock 416 286 473 minecraft:sea_lantern
fill 416 286 474 416 300 474 minecraft:black_concrete
setblock 416 286 475 minecraft:sea_lantern
fill 416 286 476 416 300 476 minecraft:black_concrete
setblock 416 286 477 minecraft:sea_lantern
fill 416 286 478 416 300 478 minecraft:black_concrete
setblock 416 286 479 minecraft:sea_lantern
fill 416 286 480 416 300 480 minecraft:black_concrete
setblock 416 286 481 minecraft:sea_lantern
fill 416 286 482 416 300 482 minecraft:black_concrete
setblock 416 286 483 minecraft:sea_lantern
fill 416 286 484 416 300 484 minecraft:black_concrete
setblock 416 286 485 minecraft:sea_lantern
fill 417 286 467 417 300 467 minecraft:black_concrete
setblock 417 286 468 minecraft:sea_lantern
fill 417 286 469 417 300 469 minecraft:black_concrete
setblock 417 286 470 minecraft:sea_lantern
fill 417 286 471 417 300 471 minecraft:black_concrete
setblock 417 286 472 minecraft:sea_lantern
fill 417 286 473 417 300 473 minecraft:black_concrete
setblock 417 286 474 minecraft:sea_lantern
fill 417 286 475 417 300 475 minecraft:black_concrete
setblock 417 286 476 minecraft:sea_lantern
fill 417 286 477 417 300 477 minecraft:black_concrete
setblock 417 286 478 minecraft:sea_lantern
fill 417 286 479 417 300 479 minecraft:black_concrete
setblock 417 286 480 minecraft:sea_lantern
fill 417 286 481 417 300 481 minecraft:black_concrete
setblock 417 286 482 minecraft:sea_lantern
fill 417 286 483 417 300 483 minecraft:black_concrete
setblock 417 286 484 minecraft:sea_lantern
fill 417 286 485 417 300 485 minecraft:black_concrete
fill 388 287 499 388 288 499 minecraft:black_concrete
fill 388 287 501 388 288 501 minecraft:black_concrete
fill 388 287 503 388 288 503 minecraft:black_concrete
fill 389 287 500 389 288 500 minecraft:black_concrete
fill 389 287 502 389 288 502 minecraft:black_concrete
fill 389 287 504 389 288 504 minecraft:black_concrete
fill 390 287 499 390 288 499 minecraft:black_concrete
fill 390 287 501 390 288 501 minecraft:black_concrete
fill 390 287 503 390 288 503 minecraft:black_concrete
fill 391 287 500 391 288 500 minecraft:black_concrete
fill 391 287 502 391 288 502 minecraft:black_concrete
fill 391 287 504 391 288 504 minecraft:black_concrete
fill 392 287 499 392 288 499 minecraft:black_concrete
fill 392 287 501 392 288 501 minecraft:black_concrete
fill 392 287 503 392 288 503 minecraft:black_concrete
fill 393 287 500 393 288 500 minecraft:black_concrete
fill 393 287 502 393 288 502 minecraft:black_concrete
fill 393 287 504 393 288 504 minecraft:black_concrete
fill 394 287 499 394 288 499 minecraft:black_concrete
fill 394 287 501 394 288 501 minecraft:black_concrete
fill 394 287 503 394 288 503 minecraft:black_concrete
fill 411 287 468 411 288 468 minecraft:black_concrete
fill 411 287 470 411 288 470 minecraft:black_concrete
fill 411 287 472 411 288 472 minecraft:black_concrete
fill 411 287 474 411 288 474 minecraft:black_concrete
fill 411 287 476 411 288 476 minecraft:black_concrete
fill 411 287 478 411 288 478 minecraft:black_concrete
fill 412 287 467 412 288 467 minecraft:black_concrete
fill 412 287 469 412 288 469 minecraft:black_concrete
fill 412 287 471 412 288 471 minecraft:black_concrete
fill 412 287 473 412 288 473 minecraft:black_concrete
fill 412 287 475 412 288 475 minecraft:black_concrete
fill 412 287 477 412 288 477 minecraft:black_concrete
fill 412 287 479 412 288 479 minecraft:black_concrete
fill 412 287 481 412 288 481 minecraft:black_concrete
fill 412 287 483 412 288 483 minecraft:black_concrete
fill 412 287 485 412 288 485 minecraft:black_concrete
fill 413 287 468 413 288 468 minecraft:black_concrete
fill 413 287 470 413 288 470 minecraft:black_concrete
fill 413 287 472 413 288 472 minecraft:black_concrete
fill 413 287 474 413 288 474 minecraft:black_concrete
fill 413 287 476 413 288 476 minecraft:black_concrete
fill 413 287 478 413 288 478 minecraft:black_concrete
fill 413 287 480 413 288 480 minecraft:black_concrete
fill 413 287 482 413 288 482 minecraft:black_concrete
fill 413 287 484 413 288 484 minecraft:black_concrete
fill 414 287 467 414 288 467 minecraft:black_concrete
fill 414 287 469 414 288 469 minecraft:black_concrete
fill 414 287 471 414 288 471 minecraft:black_concrete
fill 414 287 473 414 288 473 minecraft:black_concrete
fill 414 287 475 414 288 475 minecraft:black_concrete
fill 414 287 477 414 288 477 minecraft:black_concrete
fill 414 287 479 414 288 479 minecraft:black_concrete
fill 414 287 481 414 288 481 minecraft:black_concrete
fill 414 287 483 414 288 483 minecraft:black_concrete
fill 414 287 485 414 288 485 minecraft:black_concrete
fill 415 287 468 415 288 468 minecraft:black_concrete
fill 415 287 470 415 288 470 minecraft:black_concrete
fill 415 287 472 415 288 472 minecraft:black_concrete
fill 415 287 474 415 288 474 minecraft:black_concrete
fill 415 287 476 415 288 476 minecraft:black_concrete
fill 415 287 478 415 288 478 minecraft:black_concrete
fill 415 287 480 415 288 480 minecraft:black_concrete
fill 415 287 482 415 288 482 minecraft:black_concrete
fill 415 287 484 415 288 484 minecraft:black_concrete
fill 416 287 467 416 288 467 minecraft:black_concrete
fill 416 287 469 416 288 469 minecraft:black_concrete
fill 416 287 471 416 288 471 minecraft:black_concrete
fill 416 287 473 416 288 473 minecraft:black_concrete
fill 416 287 475 416 288 475 minecraft:black_concrete
fill 416 287 477 416 288 477 minecraft:black_concrete
fill 416 287 479 416 288 479 minecraft:black_concrete
fill 416 287 481 416 288 481 minecraft:black_concrete
fill 416 287 483 416 288 483 minecraft:black_concrete
fill 416 287 485 416 288 485 minecraft:black_concrete
fill 417 287 468 417 288 468 minecraft:black_concrete
fill 417 287 470 417 288 470 minecraft:black_concrete
fill 417 287 472 417 288 472 minecraft:black_concrete
fill 417 287 474 417 288 474 minecraft:black_concrete
fill 417 287 476 417 288 476 minecraft:black_concrete
fill 417 287 478 417 288 478 minecraft:black_concrete
fill 417 287 480 417 288 480 minecraft:black_concrete
fill 417 287 482 417 288 482 minecraft:black_concrete
fill 417 287 484 417 288 484 minecraft:black_concrete
setblock 379 288 466 minecraft:light[level=14]
setblock 379 288 474 minecraft:light[level=14]
setblock 379 288 482 minecraft:light[level=14]
setblock 379 288 490 minecraft:light[level=14]
setblock 387 288 466 minecraft:light[level=14]
setblock 387 288 474 minecraft:light[level=14]
setblock 387 288 482 minecraft:light[level=14]
setblock 387 288 490 minecraft:light[level=14]
setblock 395 288 466 minecraft:light[level=14]
setblock 395 288 474 minecraft:light[level=14]
setblock 395 288 482 minecraft:light[level=14]
setblock 395 288 490 minecraft:light[level=14]
setblock 395 288 498 minecraft:light[level=14]
setblock 403 288 466 minecraft:light[level=14]
setblock 403 288 474 minecraft:light[level=14]
setblock 403 288 482 minecraft:light[level=14]
setblock 403 288 490 minecraft:light[level=14]
setblock 403 288 498 minecraft:light[level=14]
setblock 411 288 466 minecraft:light[level=14]
setblock 411 288 482 minecraft:light[level=14]
setblock 411 288 490 minecraft:light[level=14]
setblock 411 288 498 minecraft:light[level=14]
setblock 388 289 499 minecraft:sea_lantern
setblock 388 289 501 minecraft:sea_lantern
setblock 388 289 503 minecraft:sea_lantern
setblock 389 289 500 minecraft:sea_lantern
setblock 389 289 502 minecraft:sea_lantern
setblock 389 289 504 minecraft:sea_lantern
setblock 390 289 499 minecraft:sea_lantern
setblock 390 289 501 minecraft:sea_lantern
setblock 390 289 503 minecraft:sea_lantern
setblock 391 289 500 minecraft:sea_lantern
setblock 391 289 502 minecraft:sea_lantern
setblock 391 289 504 minecraft:sea_lantern
setblock 392 289 499 minecraft:sea_lantern
setblock 392 289 501 minecraft:sea_lantern
setblock 392 289 503 minecraft:sea_lantern
setblock 393 289 500 minecraft:sea_lantern
setblock 393 289 502 minecraft:sea_lantern
setblock 393 289 504 minecraft:sea_lantern
setblock 394 289 499 minecraft:sea_lantern
setblock 394 289 501 minecraft:sea_lantern
setblock 394 289 503 minecraft:sea_lantern
setblock 411 289 468 minecraft:sea_lantern
setblock 411 289 470 minecraft:sea_lantern
setblock 411 289 472 minecraft:sea_lantern
setblock 411 289 474 minecraft:sea_lantern
setblock 411 289 476 minecraft:sea_lantern
setblock 411 289 478 minecraft:sea_lantern
setblock 412 289 467 minecraft:sea_lantern
setblock 412 289 469 minecraft:sea_lantern
setblock 412 289 471 minecraft:sea_lantern
setblock 412 289 473 minecraft:sea_lantern
setblock 412 289 475 minecraft:sea_lantern
setblock 412 289 477 minecraft:sea_lantern
setblock 412 289 479 minecraft:sea_lantern
setblock 412 289 481 minecraft:sea_lantern
setblock 412 289 483 minecraft:sea_lantern
setblock 412 289 485 minecraft:sea_lantern
setblock 413 289 468 minecraft:sea_lantern
setblock 413 289 470 minecraft:sea_lantern
setblock 413 289 472 minecraft:sea_lantern
setblock 413 289 474 minecraft:sea_lantern
setblock 413 289 476 minecraft:sea_lantern
setblock 413 289 478 minecraft:sea_lantern
setblock 413 289 480 minecraft:sea_lantern
setblock 413 289 482 minecraft:sea_lantern
setblock 413 289 484 minecraft:sea_lantern
setblock 414 289 467 minecraft:sea_lantern
setblock 414 289 469 minecraft:sea_lantern
setblock 414 289 471 minecraft:sea_lantern
setblock 414 289 473 minecraft:sea_lantern
setblock 414 289 475 minecraft:sea_lantern
setblock 414 289 477 minecraft:sea_lantern
setblock 414 289 479 minecraft:sea_lantern
setblock 414 289 481 minecraft:sea_lantern
setblock 414 289 483 minecraft:sea_lantern
setblock 414 289 485 minecraft:sea_lantern
setblock 415 289 468 minecraft:sea_lantern
setblock 415 289 470 minecraft:sea_lantern
setblock 415 289 472 minecraft:sea_lantern
setblock 415 289 474 minecraft:sea_lantern
setblock 415 289 476 minecraft:sea_lantern
setblock 415 289 478 minecraft:sea_lantern
setblock 415 289 480 minecraft:sea_lantern
setblock 415 289 482 minecraft:sea_lantern
setblock 415 289 484 minecraft:sea_lantern
setblock 416 289 467 minecraft:sea_lantern
setblock 416 289 469 minecraft:sea_lantern
setblock 416 289 471 minecraft:sea_lantern
setblock 416 289 473 minecraft:sea_lantern
setblock 416 289 475 minecraft:sea_lantern
setblock 416 289 477 minecraft:sea_lantern
setblock 416 289 479 minecraft:sea_lantern
setblock 416 289 481 minecraft:sea_lantern
setblock 416 289 483 minecraft:sea_lantern
setblock 416 289 485 minecraft:sea_lantern
setblock 417 289 468 minecraft:sea_lantern
setblock 417 289 470 minecraft:sea_lantern
setblock 417 289 472 minecraft:sea_lantern
setblock 417 289 474 minecraft:sea_lantern
setblock 417 289 476 minecraft:sea_lantern
setblock 417 289 478 minecraft:sea_lantern
setblock 417 289 480 minecraft:sea_lantern
setblock 417 289 482 minecraft:sea_lantern
setblock 417 289 484 minecraft:sea_lantern
fill 376 290 468 376 297 468 minecraft:magenta_concrete
fill 376 290 476 376 297 476 minecraft:magenta_concrete
fill 376 290 484 376 297 484 minecraft:magenta_concrete
fill 376 290 492 376 297 492 minecraft:magenta_concrete
fill 376 290 500 376 297 500 minecraft:magenta_concrete
fill 379 290 505 379 297 505 minecraft:magenta_concrete
fill 383 290 463 383 297 463 minecraft:magenta_concrete
fill 387 290 505 387 297 505 minecraft:magenta_concrete
fill 388 290 499 388 291 499 minecraft:black_concrete
fill 388 290 501 388 291 501 minecraft:black_concrete
fill 388 290 503 388 291 503 minecraft:black_concrete
fill 389 290 500 389 291 500 minecraft:black_concrete
fill 389 290 502 389 291 502 minecraft:black_concrete
fill 389 290 504 389 291 504 minecraft:black_concrete
fill 390 290 499 390 291 499 minecraft:black_concrete
fill 390 290 501 390 291 501 minecraft:black_concrete
fill 390 290 503 390 291 503 minecraft:black_concrete
fill 391 290 463 391 297 463 minecraft:magenta_concrete
fill 391 290 500 391 291 500 minecraft:black_concrete
fill 391 290 502 391 291 502 minecraft:black_concrete
fill 391 290 504 391 291 504 minecraft:black_concrete
fill 392 290 499 392 291 499 minecraft:black_concrete
fill 392 290 501 392 291 501 minecraft:black_concrete
fill 392 290 503 392 291 503 minecraft:black_concrete
fill 393 290 500 393 291 500 minecraft:black_concrete
fill 393 290 502 393 291 502 minecraft:black_concrete
fill 393 290 504 393 291 504 minecraft:black_concrete
fill 394 290 499 394 291 499 minecraft:black_concrete
fill 394 290 501 394 291 501 minecraft:black_concrete
fill 394 290 503 394 291 503 minecraft:black_concrete
fill 395 290 505 395 297 505 minecraft:magenta_concrete
fill 399 290 463 399 297 463 minecraft:magenta_concrete
fill 403 290 505 403 297 505 minecraft:magenta_concrete
fill 407 290 463 407 297 463 minecraft:magenta_concrete
fill 411 290 468 411 291 468 minecraft:black_concrete
fill 411 290 470 411 291 470 minecraft:black_concrete
fill 411 290 472 411 291 472 minecraft:black_concrete
fill 411 290 474 411 291 474 minecraft:black_concrete
fill 411 290 476 411 291 476 minecraft:black_concrete
fill 411 290 478 411 291 478 minecraft:black_concrete
fill 411 290 505 411 297 505 minecraft:magenta_concrete
fill 412 290 467 412 291 467 minecraft:black_concrete
fill 412 290 469 412 291 469 minecraft:black_concrete
fill 412 290 471 412 291 471 minecraft:black_concrete
fill 412 290 473 412 291 473 minecraft:black_concrete
fill 412 290 475 412 291 475 minecraft:black_concrete
fill 412 290 477 412 291 477 minecraft:black_concrete
fill 412 290 479 412 291 479 minecraft:black_concrete
fill 412 290 481 412 291 481 minecraft:black_concrete
fill 412 290 483 412 291 483 minecraft:black_concrete
fill 412 290 485 412 291 485 minecraft:black_concrete
fill 413 290 468 413 291 468 minecraft:black_concrete
fill 413 290 470 413 291 470 minecraft:black_concrete
fill 413 290 472 413 291 472 minecraft:black_concrete
fill 413 290 474 413 291 474 minecraft:black_concrete
fill 413 290 476 413 291 476 minecraft:black_concrete
fill 413 290 478 413 291 478 minecraft:black_concrete
fill 413 290 480 413 291 480 minecraft:black_concrete
fill 413 290 482 413 291 482 minecraft:black_concrete
fill 413 290 484 413 291 484 minecraft:black_concrete
fill 414 290 467 414 291 467 minecraft:black_concrete
fill 414 290 469 414 291 469 minecraft:black_concrete
fill 414 290 471 414 291 471 minecraft:black_concrete
fill 414 290 473 414 291 473 minecraft:black_concrete
fill 414 290 475 414 291 475 minecraft:black_concrete
fill 414 290 477 414 291 477 minecraft:black_concrete
fill 414 290 479 414 291 479 minecraft:black_concrete
fill 414 290 481 414 291 481 minecraft:black_concrete
fill 414 290 483 414 291 483 minecraft:black_concrete
fill 414 290 485 414 291 485 minecraft:black_concrete
fill 415 290 463 415 297 463 minecraft:magenta_concrete
fill 415 290 468 415 291 468 minecraft:black_concrete
fill 415 290 470 415 291 470 minecraft:black_concrete
fill 415 290 472 415 291 472 minecraft:black_concrete
fill 415 290 474 415 291 474 minecraft:black_concrete
fill 415 290 476 415 291 476 minecraft:black_concrete
fill 415 290 478 415 291 478 minecraft:black_concrete
fill 415 290 480 415 291 480 minecraft:black_concrete
fill 415 290 482 415 291 482 minecraft:black_concrete
fill 415 290 484 415 291 484 minecraft:black_concrete
fill 416 290 467 416 291 467 minecraft:black_concrete
fill 416 290 469 416 291 469 minecraft:black_concrete
fill 416 290 471 416 291 471 minecraft:black_concrete
fill 416 290 473 416 291 473 minecraft:black_concrete
fill 416 290 475 416 291 475 minecraft:black_concrete
fill 416 290 477 416 291 477 minecraft:black_concrete
fill 416 290 479 416 291 479 minecraft:black_concrete
fill 416 290 481 416 291 481 minecraft:black_concrete
fill 416 290 483 416 291 483 minecraft:black_concrete
fill 416 290 485 416 291 485 minecraft:black_concrete
fill 417 290 468 417 291 468 minecraft:black_concrete
fill 417 290 470 417 291 470 minecraft:black_concrete
fill 417 290 472 417 291 472 minecraft:black_concrete
fill 417 290 474 417 291 474 minecraft:black_concrete
fill 417 290 476 417 291 476 minecraft:black_concrete
fill 417 290 478 417 291 478 minecraft:black_concrete
fill 417 290 480 417 291 480 minecraft:black_concrete
fill 417 290 482 417 291 482 minecraft:black_concrete
fill 417 290 484 417 291 484 minecraft:black_concrete
fill 418 290 468 418 297 468 minecraft:magenta_concrete
fill 418 290 476 418 297 476 minecraft:magenta_concrete
fill 418 290 484 418 297 484 minecraft:magenta_concrete
fill 418 290 492 418 297 492 minecraft:magenta_concrete
fill 418 290 500 418 297 500 minecraft:magenta_concrete
setblock 388 292 499 minecraft:sea_lantern
setblock 388 292 501 minecraft:sea_lantern
setblock 388 292 503 minecraft:sea_lantern
setblock 389 292 500 minecraft:sea_lantern
setblock 389 292 502 minecraft:sea_lantern
setblock 389 292 504 minecraft:sea_lantern
setblock 390 292 499 minecraft:sea_lantern
setblock 390 292 501 minecraft:sea_lantern
setblock 390 292 503 minecraft:sea_lantern
setblock 391 292 500 minecraft:sea_lantern
setblock 391 292 502 minecraft:sea_lantern
setblock 391 292 504 minecraft:sea_lantern
setblock 392 292 499 minecraft:sea_lantern
setblock 392 292 501 minecraft:sea_lantern
setblock 392 292 503 minecraft:sea_lantern
setblock 393 292 500 minecraft:sea_lantern
setblock 393 292 502 minecraft:sea_lantern
setblock 393 292 504 minecraft:sea_lantern
setblock 394 292 499 minecraft:sea_lantern
setblock 394 292 501 minecraft:sea_lantern
setblock 394 292 503 minecraft:sea_lantern
setblock 411 292 468 minecraft:sea_lantern
setblock 411 292 470 minecraft:sea_lantern
setblock 411 292 472 minecraft:sea_lantern
setblock 411 292 474 minecraft:sea_lantern
setblock 411 292 476 minecraft:sea_lantern
setblock 411 292 478 minecraft:sea_lantern
setblock 412 292 467 minecraft:sea_lantern
setblock 412 292 469 minecraft:sea_lantern
setblock 412 292 471 minecraft:sea_lantern
setblock 412 292 473 minecraft:sea_lantern
setblock 412 292 475 minecraft:sea_lantern
setblock 412 292 477 minecraft:sea_lantern
setblock 412 292 479 minecraft:sea_lantern
setblock 412 292 481 minecraft:sea_lantern
setblock 412 292 483 minecraft:sea_lantern
setblock 412 292 485 minecraft:sea_lantern
setblock 413 292 468 minecraft:sea_lantern
setblock 413 292 470 minecraft:sea_lantern
setblock 413 292 472 minecraft:sea_lantern
setblock 413 292 474 minecraft:sea_lantern
setblock 413 292 476 minecraft:sea_lantern
setblock 413 292 478 minecraft:sea_lantern
setblock 413 292 480 minecraft:sea_lantern
setblock 413 292 482 minecraft:sea_lantern
setblock 413 292 484 minecraft:sea_lantern
setblock 414 292 467 minecraft:sea_lantern
setblock 414 292 469 minecraft:sea_lantern
setblock 414 292 471 minecraft:sea_lantern
setblock 414 292 473 minecraft:sea_lantern
setblock 414 292 475 minecraft:sea_lantern
setblock 414 292 477 minecraft:sea_lantern
setblock 414 292 479 minecraft:sea_lantern
setblock 414 292 481 minecraft:sea_lantern
setblock 414 292 483 minecraft:sea_lantern
setblock 414 292 485 minecraft:sea_lantern
setblock 415 292 468 minecraft:sea_lantern
setblock 415 292 470 minecraft:sea_lantern
setblock 415 292 472 minecraft:sea_lantern
setblock 415 292 474 minecraft:sea_lantern
setblock 415 292 476 minecraft:sea_lantern
setblock 415 292 478 minecraft:sea_lantern
setblock 415 292 480 minecraft:sea_lantern
setblock 415 292 482 minecraft:sea_lantern
setblock 415 292 484 minecraft:sea_lantern
setblock 416 292 467 minecraft:sea_lantern
setblock 416 292 469 minecraft:sea_lantern
setblock 416 292 471 minecraft:sea_lantern
setblock 416 292 473 minecraft:sea_lantern
setblock 416 292 475 minecraft:sea_lantern
setblock 416 292 477 minecraft:sea_lantern
setblock 416 292 479 minecraft:sea_lantern
setblock 416 292 481 minecraft:sea_lantern
setblock 416 292 483 minecraft:sea_lantern
setblock 416 292 485 minecraft:sea_lantern
setblock 417 292 468 minecraft:sea_lantern
setblock 417 292 470 minecraft:sea_lantern
setblock 417 292 472 minecraft:sea_lantern
setblock 417 292 474 minecraft:sea_lantern
setblock 417 292 476 minecraft:sea_lantern
setblock 417 292 478 minecraft:sea_lantern
setblock 417 292 480 minecraft:sea_lantern
setblock 417 292 482 minecraft:sea_lantern
setblock 417 292 484 minecraft:sea_lantern
fill 388 293 499 388 294 499 minecraft:black_concrete
fill 388 293 501 388 294 501 minecraft:black_concrete
fill 388 293 503 388 294 503 minecraft:black_concrete
fill 389 293 500 389 294 500 minecraft:black_concrete
fill 389 293 502 389 294 502 minecraft:black_concrete
fill 389 293 504 389 294 504 minecraft:black_concrete
fill 390 293 499 390 294 499 minecraft:black_concrete
fill 390 293 501 390 294 501 minecraft:black_concrete
fill 390 293 503 390 294 503 minecraft:black_concrete
fill 391 293 500 391 294 500 minecraft:black_concrete
fill 391 293 502 391 294 502 minecraft:black_concrete
fill 391 293 504 391 294 504 minecraft:black_concrete
fill 392 293 499 392 294 499 minecraft:black_concrete
fill 392 293 501 392 294 501 minecraft:black_concrete
fill 392 293 503 392 294 503 minecraft:black_concrete
fill 393 293 500 393 294 500 minecraft:black_concrete
fill 393 293 502 393 294 502 minecraft:black_concrete
fill 393 293 504 393 294 504 minecraft:black_concrete
fill 394 293 499 394 294 499 minecraft:black_concrete
fill 394 293 501 394 294 501 minecraft:black_concrete
fill 394 293 503 394 294 503 minecraft:black_concrete
fill 411 293 468 411 294 468 minecraft:black_concrete
fill 411 293 470 411 294 470 minecraft:black_concrete
fill 411 293 472 411 294 472 minecraft:black_concrete
fill 411 293 474 411 294 474 minecraft:black_concrete
fill 411 293 476 411 294 476 minecraft:black_concrete
fill 411 293 478 411 294 478 minecraft:black_concrete
fill 412 293 467 412 294 467 minecraft:black_concrete
fill 412 293 469 412 294 469 minecraft:black_concrete
fill 412 293 471 412 294 471 minecraft:black_concrete
fill 412 293 473 412 294 473 minecraft:black_concrete
fill 412 293 475 412 294 475 minecraft:black_concrete
fill 412 293 477 412 294 477 minecraft:black_concrete
fill 412 293 479 412 294 479 minecraft:black_concrete
fill 412 293 481 412 294 481 minecraft:black_concrete
fill 412 293 483 412 294 483 minecraft:black_concrete
fill 412 293 485 412 294 485 minecraft:black_concrete
fill 413 293 468 413 294 468 minecraft:black_concrete
fill 413 293 470 413 294 470 minecraft:black_concrete
fill 413 293 472 413 294 472 minecraft:black_concrete
fill 413 293 474 413 294 474 minecraft:black_concrete
fill 413 293 476 413 294 476 minecraft:black_concrete
fill 413 293 478 413 294 478 minecraft:black_concrete
fill 413 293 480 413 294 480 minecraft:black_concrete
fill 413 293 482 413 294 482 minecraft:black_concrete
fill 413 293 484 413 294 484 minecraft:black_concrete
fill 414 293 467 414 294 467 minecraft:black_concrete
fill 414 293 469 414 294 469 minecraft:black_concrete
fill 414 293 471 414 294 471 minecraft:black_concrete
fill 414 293 473 414 294 473 minecraft:black_concrete
fill 414 293 475 414 294 475 minecraft:black_concrete
fill 414 293 477 414 294 477 minecraft:black_concrete
fill 414 293 479 414 294 479 minecraft:black_concrete
fill 414 293 481 414 294 481 minecraft:black_concrete
fill 414 293 483 414 294 483 minecraft:black_concrete
fill 414 293 485 414 294 485 minecraft:black_concrete
fill 415 293 468 415 294 468 minecraft:black_concrete
fill 415 293 470 415 294 470 minecraft:black_concrete
fill 415 293 472 415 294 472 minecraft:black_concrete
fill 415 293 474 415 294 474 minecraft:black_concrete
fill 415 293 476 415 294 476 minecraft:black_concrete
fill 415 293 478 415 294 478 minecraft:black_concrete
fill 415 293 480 415 294 480 minecraft:black_concrete
fill 415 293 482 415 294 482 minecraft:black_concrete
fill 415 293 484 415 294 484 minecraft:black_concrete
fill 416 293 467 416 294 467 minecraft:black_concrete
fill 416 293 469 416 294 469 minecraft:black_concrete
fill 416 293 471 416 294 471 minecraft:black_concrete
fill 416 293 473 416 294 473 minecraft:black_concrete
fill 416 293 475 416 294 475 minecraft:black_concrete
fill 416 293 477 416 294 477 minecraft:black_concrete
fill 416 293 479 416 294 479 minecraft:black_concrete
fill 416 293 481 416 294 481 minecraft:black_concrete
fill 416 293 483 416 294 483 minecraft:black_concrete
fill 416 293 485 416 294 485 minecraft:black_concrete
fill 417 293 468 417 294 468 minecraft:black_concrete
fill 417 293 470 417 294 470 minecraft:black_concrete
fill 417 293 472 417 294 472 minecraft:black_concrete
fill 417 293 474 417 294 474 minecraft:black_concrete
fill 417 293 476 417 294 476 minecraft:black_concrete
fill 417 293 478 417 294 478 minecraft:black_concrete
fill 417 293 480 417 294 480 minecraft:black_concrete
fill 417 293 482 417 294 482 minecraft:black_concrete
fill 417 293 484 417 294 484 minecraft:black_concrete
fill 377 294 464 377 295 469 minecraft:black_concrete
fill 377 294 472 378 294 477 minecraft:black_concrete
fill 377 294 480 378 294 485 minecraft:black_concrete
fill 377 294 488 378 294 493 minecraft:black_concrete
fill 378 294 465 378 294 471 minecraft:black_concrete
fill 378 294 478 378 294 479 minecraft:black_concrete
fill 378 294 486 378 294 487 minecraft:black_concrete
fill 378 294 494 378 294 495 minecraft:black_concrete
fill 379 294 465 416 294 465 minecraft:black_concrete
fill 380 294 464 385 295 464 minecraft:black_concrete
fill 388 294 464 393 295 464 minecraft:black_concrete
fill 395 294 503 398 294 504 minecraft:black_concrete
fill 396 294 464 401 295 464 minecraft:black_concrete
fill 399 294 503 417 294 503 minecraft:black_concrete
fill 401 294 504 406 295 504 minecraft:black_concrete
fill 404 294 464 409 295 464 minecraft:black_concrete
fill 409 294 504 414 295 504 minecraft:black_concrete
fill 412 294 464 417 295 464 minecraft:black_concrete
setblock 416 294 466 minecraft:black_concrete
fill 416 294 486 416 294 502 minecraft:black_concrete
fill 417 294 486 417 295 488 minecraft:black_concrete
fill 417 294 491 417 295 496 minecraft:black_concrete
fill 417 294 499 417 295 502 minecraft:black_concrete
fill 417 294 504 417 295 504 minecraft:black_concrete
fill 377 295 472 377 295 477 minecraft:black_concrete
fill 377 295 480 377 295 485 minecraft:black_concrete
fill 377 295 488 377 295 493 minecraft:black_concrete
setblock 388 295 499 minecraft:sea_lantern
setblock 388 295 501 minecraft:sea_lantern
setblock 388 295 503 minecraft:sea_lantern
setblock 389 295 500 minecraft:sea_lantern
setblock 389 295 502 minecraft:sea_lantern
setblock 389 295 504 minecraft:sea_lantern
setblock 390 295 499 minecraft:sea_lantern
setblock 390 295 501 minecraft:sea_lantern
setblock 390 295 503 minecraft:sea_lantern
setblock 391 295 500 minecraft:sea_lantern
setblock 391 295 502 minecraft:sea_lantern
setblock 391 295 504 minecraft:sea_lantern
setblock 392 295 499 minecraft:sea_lantern
setblock 392 295 501 minecraft:sea_lantern
setblock 392 295 503 minecraft:sea_lantern
setblock 393 295 500 minecraft:sea_lantern
setblock 393 295 502 minecraft:sea_lantern
setblock 393 295 504 minecraft:sea_lantern
setblock 394 295 499 minecraft:sea_lantern
setblock 394 295 501 minecraft:sea_lantern
setblock 394 295 503 minecraft:sea_lantern
fill 395 295 504 398 295 504 minecraft:black_concrete
setblock 411 295 468 minecraft:sea_lantern
setblock 411 295 470 minecraft:sea_lantern
setblock 411 295 472 minecraft:sea_lantern
setblock 411 295 474 minecraft:sea_lantern
setblock 411 295 476 minecraft:sea_lantern
setblock 411 295 478 minecraft:sea_lantern
setblock 412 295 467 minecraft:sea_lantern
setblock 412 295 469 minecraft:sea_lantern
setblock 412 295 471 minecraft:sea_lantern
setblock 412 295 473 minecraft:sea_lantern
setblock 412 295 475 minecraft:sea_lantern
setblock 412 295 477 minecraft:sea_lantern
setblock 412 295 479 minecraft:sea_lantern
setblock 412 295 481 minecraft:sea_lantern
setblock 412 295 483 minecraft:sea_lantern
setblock 412 295 485 minecraft:sea_lantern
setblock 413 295 468 minecraft:sea_lantern
setblock 413 295 470 minecraft:sea_lantern
setblock 413 295 472 minecraft:sea_lantern
setblock 413 295 474 minecraft:sea_lantern
setblock 413 295 476 minecraft:sea_lantern
setblock 413 295 478 minecraft:sea_lantern
setblock 413 295 480 minecraft:sea_lantern
setblock 413 295 482 minecraft:sea_lantern
setblock 413 295 484 minecraft:sea_lantern
setblock 414 295 467 minecraft:sea_lantern
setblock 414 295 469 minecraft:sea_lantern
setblock 414 295 471 minecraft:sea_lantern
setblock 414 295 473 minecraft:sea_lantern
setblock 414 295 475 minecraft:sea_lantern
setblock 414 295 477 minecraft:sea_lantern
setblock 414 295 479 minecraft:sea_lantern
setblock 414 295 481 minecraft:sea_lantern
setblock 414 295 483 minecraft:sea_lantern
setblock 414 295 485 minecraft:sea_lantern
fill 414 295 496 415 296 497 minecraft:magenta_concrete
setblock 415 295 468 minecraft:sea_lantern
setblock 415 295 470 minecraft:sea_lantern
setblock 415 295 472 minecraft:sea_lantern
setblock 415 295 474 minecraft:sea_lantern
setblock 415 295 476 minecraft:sea_lantern
setblock 415 295 478 minecraft:sea_lantern
setblock 415 295 480 minecraft:sea_lantern
setblock 415 295 482 minecraft:sea_lantern
setblock 415 295 484 minecraft:sea_lantern
setblock 416 295 467 minecraft:sea_lantern
setblock 416 295 469 minecraft:sea_lantern
setblock 416 295 471 minecraft:sea_lantern
setblock 416 295 473 minecraft:sea_lantern
setblock 416 295 475 minecraft:sea_lantern
setblock 416 295 477 minecraft:sea_lantern
setblock 416 295 479 minecraft:sea_lantern
setblock 416 295 481 minecraft:sea_lantern
setblock 416 295 483 minecraft:sea_lantern
setblock 416 295 485 minecraft:sea_lantern
setblock 417 295 468 minecraft:sea_lantern
setblock 417 295 470 minecraft:sea_lantern
setblock 417 295 472 minecraft:sea_lantern
setblock 417 295 474 minecraft:sea_lantern
setblock 417 295 476 minecraft:sea_lantern
setblock 417 295 478 minecraft:sea_lantern
setblock 417 295 480 minecraft:sea_lantern
setblock 417 295 482 minecraft:sea_lantern
setblock 417 295 484 minecraft:sea_lantern
setblock 417 295 503 minecraft:black_concrete
setblock 379 296 466 minecraft:light[level=14]
setblock 379 296 474 minecraft:light[level=14]
setblock 379 296 482 minecraft:light[level=14]
setblock 379 296 490 minecraft:light[level=14]
setblock 387 296 466 minecraft:light[level=14]
setblock 387 296 474 minecraft:light[level=14]
setblock 387 296 482 minecraft:light[level=14]
setblock 387 296 490 minecraft:light[level=14]
fill 388 296 499 388 297 499 minecraft:black_concrete
fill 388 296 501 388 297 501 minecraft:black_concrete
fill 388 296 503 388 297 503 minecraft:black_concrete
fill 389 296 500 389 297 500 minecraft:black_concrete
fill 389 296 502 389 297 502 minecraft:black_concrete
fill 389 296 504 389 297 504 minecraft:black_concrete
fill 390 296 499 390 297 499 minecraft:black_concrete
fill 390 296 501 390 297 501 minecraft:black_concrete
fill 390 296 503 390 297 503 minecraft:black_concrete
fill 391 296 500 391 297 500 minecraft:black_concrete
fill 391 296 502 391 297 502 minecraft:black_concrete
fill 391 296 504 391 297 504 minecraft:black_concrete
fill 392 296 499 392 297 499 minecraft:black_concrete
fill 392 296 501 392 297 501 minecraft:black_concrete
fill 392 296 503 392 297 503 minecraft:black_concrete
fill 393 296 500 393 297 500 minecraft:black_concrete
fill 393 296 502 393 297 502 minecraft:black_concrete
fill 393 296 504 393 297 504 minecraft:black_concrete
fill 394 296 499 394 297 499 minecraft:black_concrete
fill 394 296 501 394 297 501 minecraft:black_concrete
fill 394 296 503 394 297 503 minecraft:black_concrete
setblock 395 296 466 minecraft:light[level=14]
setblock 395 296 474 minecraft:light[level=14]
setblock 395 296 482 minecraft:light[level=14]
setblock 395 296 490 minecraft:light[level=14]
setblock 395 296 498 minecraft:light[level=14]
setblock 403 296 466 minecraft:light[level=14]
setblock 403 296 474 minecraft:light[level=14]
setblock 403 296 482 minecraft:light[level=14]
setblock 403 296 490 minecraft:light[level=14]
setblock 403 296 498 minecraft:light[level=14]
fill 407 296 493 409 298 495 minecraft:gold_block
setblock 411 296 466 minecraft:light[level=14]
fill 411 296 468 411 297 468 minecraft:black_concrete
fill 411 296 470 411 297 470 minecraft:black_concrete
fill 411 296 472 411 297 472 minecraft:black_concrete
fill 411 296 474 411 297 474 minecraft:black_concrete
fill 411 296 476 411 297 476 minecraft:black_concrete
fill 411 296 478 411 297 478 minecraft:black_concrete
setblock 411 296 482 minecraft:light[level=14]
setblock 411 296 490 minecraft:light[level=14]
setblock 411 296 498 minecraft:light[level=14]
fill 412 296 467 412 297 467 minecraft:black_concrete
fill 412 296 469 412 297 469 minecraft:black_concrete
fill 412 296 471 412 297 471 minecraft:black_concrete
fill 412 296 473 412 297 473 minecraft:black_concrete
fill 412 296 475 412 297 475 minecraft:black_concrete
fill 412 296 477 412 297 477 minecraft:black_concrete
fill 412 296 479 412 297 479 minecraft:black_concrete
fill 412 296 481 412 297 481 minecraft:black_concrete
fill 412 296 483 412 297 483 minecraft:black_concrete
fill 412 296 485 412 297 485 minecraft:black_concrete
fill 413 296 468 413 297 468 minecraft:black_concrete
fill 413 296 470 413 297 470 minecraft:black_concrete
fill 413 296 472 413 297 472 minecraft:black_concrete
fill 413 296 474 413 297 474 minecraft:black_concrete
fill 413 296 476 413 297 476 minecraft:black_concrete
fill 413 296 478 413 297 478 minecraft:black_concrete
fill 413 296 480 413 297 480 minecraft:black_concrete
fill 413 296 482 413 297 482 minecraft:black_concrete
fill 413 296 484 413 297 484 minecraft:black_concrete
fill 414 296 467 414 297 467 minecraft:black_concrete
fill 414 296 469 414 297 469 minecraft:black_concrete
fill 414 296 471 414 297 471 minecraft:black_concrete
fill 414 296 473 414 297 473 minecraft:black_concrete
fill 414 296 475 414 297 475 minecraft:black_concrete
fill 414 296 477 414 297 477 minecraft:black_concrete
fill 414 296 479 414 297 479 minecraft:black_concrete
fill 414 296 481 414 297 481 minecraft:black_concrete
fill 414 296 483 414 297 483 minecraft:black_concrete
fill 414 296 485 414 297 485 minecraft:black_concrete
fill 415 296 468 415 297 468 minecraft:black_concrete
fill 415 296 470 415 297 470 minecraft:black_concrete
fill 415 296 472 415 297 472 minecraft:black_concrete
fill 415 296 474 415 297 474 minecraft:black_concrete
fill 415 296 476 415 297 476 minecraft:black_concrete
fill 415 296 478 415 297 478 minecraft:black_concrete
fill 415 296 480 415 297 480 minecraft:black_concrete
fill 415 296 482 415 297 482 minecraft:black_concrete
fill 415 296 484 415 297 484 minecraft:black_concrete
fill 416 296 467 416 297 467 minecraft:black_concrete
fill 416 296 469 416 297 469 minecraft:black_concrete
fill 416 296 471 416 297 471 minecraft:black_concrete
fill 416 296 473 416 297 473 minecraft:black_concrete
fill 416 296 475 416 297 475 minecraft:black_concrete
fill 416 296 477 416 297 477 minecraft:black_concrete
fill 416 296 479 416 297 479 minecraft:black_concrete
fill 416 296 481 416 297 481 minecraft:black_concrete
fill 416 296 483 416 297 483 minecraft:black_concrete
fill 416 296 485 416 297 485 minecraft:black_concrete
fill 417 296 468 417 297 468 minecraft:black_concrete
fill 417 296 470 417 297 470 minecraft:black_concrete
fill 417 296 472 417 297 472 minecraft:black_concrete
fill 417 296 474 417 297 474 minecraft:black_concrete
fill 417 296 476 417 297 476 minecraft:black_concrete
fill 417 296 478 417 297 478 minecraft:black_concrete
fill 417 296 480 417 297 480 minecraft:black_concrete
fill 417 296 482 417 297 482 minecraft:black_concrete
fill 417 296 484 417 297 484 minecraft:black_concrete
fill 376 298 468 376 300 468 minecraft:sea_lantern
fill 376 298 476 376 300 476 minecraft:sea_lantern
fill 376 298 484 376 300 484 minecraft:sea_lantern
fill 376 298 492 376 300 492 minecraft:sea_lantern
fill 376 298 500 376 300 500 minecraft:sea_lantern
fill 379 298 505 379 300 505 minecraft:sea_lantern
fill 383 298 463 383 300 463 minecraft:sea_lantern
fill 387 298 505 387 300 505 minecraft:sea_lantern
setblock 388 298 499 minecraft:sea_lantern
setblock 388 298 501 minecraft:sea_lantern
setblock 388 298 503 minecraft:sea_lantern
setblock 389 298 500 minecraft:sea_lantern
setblock 389 298 502 minecraft:sea_lantern
setblock 389 298 504 minecraft:sea_lantern
setblock 390 298 499 minecraft:sea_lantern
setblock 390 298 501 minecraft:sea_lantern
setblock 390 298 503 minecraft:sea_lantern
fill 391 298 463 391 300 463 minecraft:sea_lantern
setblock 391 298 500 minecraft:sea_lantern
setblock 391 298 502 minecraft:sea_lantern
setblock 391 298 504 minecraft:sea_lantern
setblock 392 298 499 minecraft:sea_lantern
setblock 392 298 501 minecraft:sea_lantern
setblock 392 298 503 minecraft:sea_lantern
setblock 393 298 500 minecraft:sea_lantern
setblock 393 298 502 minecraft:sea_lantern
setblock 393 298 504 minecraft:sea_lantern
setblock 394 298 499 minecraft:sea_lantern
setblock 394 298 501 minecraft:sea_lantern
setblock 394 298 503 minecraft:sea_lantern
fill 395 298 505 395 300 505 minecraft:sea_lantern
fill 399 298 463 399 300 463 minecraft:sea_lantern
fill 403 298 505 403 300 505 minecraft:sea_lantern
fill 407 298 463 407 300 463 minecraft:sea_lantern
setblock 411 298 468 minecraft:sea_lantern
setblock 411 298 470 minecraft:sea_lantern
setblock 411 298 472 minecraft:sea_lantern
setblock 411 298 474 minecraft:sea_lantern
setblock 411 298 476 minecraft:sea_lantern
setblock 411 298 478 minecraft:sea_lantern
fill 411 298 505 411 300 505 minecraft:sea_lantern
setblock 412 298 467 minecraft:sea_lantern
setblock 412 298 469 minecraft:sea_lantern
setblock 412 298 471 minecraft:sea_lantern
setblock 412 298 473 minecraft:sea_lantern
setblock 412 298 475 minecraft:sea_lantern
setblock 412 298 477 minecraft:sea_lantern
setblock 412 298 479 minecraft:sea_lantern
setblock 412 298 481 minecraft:sea_lantern
setblock 412 298 483 minecraft:sea_lantern
setblock 412 298 485 minecraft:sea_lantern
setblock 413 298 468 minecraft:sea_lantern
setblock 413 298 470 minecraft:sea_lantern
setblock 413 298 472 minecraft:sea_lantern
setblock 413 298 474 minecraft:sea_lantern
setblock 413 298 476 minecraft:sea_lantern
setblock 413 298 478 minecraft:sea_lantern
setblock 413 298 480 minecraft:sea_lantern
setblock 413 298 482 minecraft:sea_lantern
setblock 413 298 484 minecraft:sea_lantern
setblock 414 298 467 minecraft:sea_lantern
setblock 414 298 469 minecraft:sea_lantern
setblock 414 298 471 minecraft:sea_lantern
setblock 414 298 473 minecraft:sea_lantern
setblock 414 298 475 minecraft:sea_lantern
setblock 414 298 477 minecraft:sea_lantern
setblock 414 298 479 minecraft:sea_lantern
setblock 414 298 481 minecraft:sea_lantern
setblock 414 298 483 minecraft:sea_lantern
setblock 414 298 485 minecraft:sea_lantern
fill 415 298 463 415 300 463 minecraft:sea_lantern
setblock 415 298 468 minecraft:sea_lantern
setblock 415 298 470 minecraft:sea_lantern
setblock 415 298 472 minecraft:sea_lantern
setblock 415 298 474 minecraft:sea_lantern
setblock 415 298 476 minecraft:sea_lantern
setblock 415 298 478 minecraft:sea_lantern
setblock 415 298 480 minecraft:sea_lantern
setblock 415 298 482 minecraft:sea_lantern
setblock 415 298 484 minecraft:sea_lantern
setblock 416 298 467 minecraft:sea_lantern
setblock 416 298 469 minecraft:sea_lantern
setblock 416 298 471 minecraft:sea_lantern
setblock 416 298 473 minecraft:sea_lantern
setblock 416 298 475 minecraft:sea_lantern
setblock 416 298 477 minecraft:sea_lantern
setblock 416 298 479 minecraft:sea_lantern
setblock 416 298 481 minecraft:sea_lantern
setblock 416 298 483 minecraft:sea_lantern
setblock 416 298 485 minecraft:sea_lantern
fill 417 298 468 418 298 468 minecraft:sea_lantern
setblock 417 298 470 minecraft:sea_lantern
setblock 417 298 472 minecraft:sea_lantern
setblock 417 298 474 minecraft:sea_lantern
fill 417 298 476 418 298 476 minecraft:sea_lantern
setblock 417 298 478 minecraft:sea_lantern
setblock 417 298 480 minecraft:sea_lantern
setblock 417 298 482 minecraft:sea_lantern
fill 417 298 484 418 298 484 minecraft:sea_lantern
fill 418 298 492 418 300 492 minecraft:sea_lantern
fill 418 298 500 418 300 500 minecraft:sea_lantern
fill 377 299 494 377 300 495 minecraft:black_concrete
fill 377 299 502 377 300 503 minecraft:black_concrete
fill 383 299 504 384 300 504 minecraft:black_concrete
fill 388 299 499 388 300 499 minecraft:black_concrete
fill 388 299 501 388 300 501 minecraft:black_concrete
fill 388 299 503 388 300 503 minecraft:black_concrete
fill 389 299 500 389 300 500 minecraft:black_concrete
fill 389 299 502 389 300 502 minecraft:black_concrete
fill 389 299 504 389 300 504 minecraft:black_concrete
fill 390 299 499 390 300 499 minecraft:black_concrete
fill 390 299 501 390 300 501 minecraft:black_concrete
fill 390 299 503 390 300 503 minecraft:black_concrete
fill 391 299 500 391 300 500 minecraft:black_concrete
fill 391 299 502 391 300 502 minecraft:black_concrete
fill 391 299 504 391 300 504 minecraft:black_concrete
fill 392 299 499 392 300 499 minecraft:black_concrete
fill 392 299 501 392 300 501 minecraft:black_concrete
fill 392 299 503 392 300 503 minecraft:black_concrete
fill 393 299 500 393 300 500 minecraft:black_concrete
fill 393 299 502 393 300 502 minecraft:black_concrete
fill 393 299 504 393 300 504 minecraft:black_concrete
fill 394 299 499 394 300 499 minecraft:black_concrete
fill 394 299 501 394 300 501 minecraft:black_concrete
fill 394 299 503 394 300 503 minecraft:black_concrete
fill 411 299 468 411 300 468 minecraft:black_concrete
fill 411 299 470 411 300 470 minecraft:black_concrete
fill 411 299 472 411 300 472 minecraft:black_concrete
fill 411 299 474 411 300 474 minecraft:black_concrete
fill 411 299 476 411 300 476 minecraft:black_concrete
fill 411 299 478 411 300 478 minecraft:black_concrete
fill 412 299 467 412 300 467 minecraft:black_concrete
fill 412 299 469 412 300 469 minecraft:black_concrete
setblock 412 299 471 minecraft:black_concrete
setblock 412 299 473 minecraft:black_concrete
fill 412 299 475 412 300 475 minecraft:black_concrete
fill 412 299 477 412 300 477 minecraft:black_concrete
fill 412 299 479 412 300 479 minecraft:black_concrete
fill 412 299 481 412 300 481 minecraft:black_concrete
fill 412 299 483 412 300 483 minecraft:black_concrete
fill 412 299 485 412 300 485 minecraft:black_concrete
fill 413 299 468 413 300 468 minecraft:black_concrete
fill 413 299 470 413 300 470 minecraft:black_concrete
setblock 413 299 472 minecraft:black_concrete
setblock 413 299 474 minecraft:black_concrete
fill 413 299 476 413 300 476 minecraft:black_concrete
fill 413 299 478 413 300 478 minecraft:black_concrete
fill 413 299 480 413 300 480 minecraft:black_concrete
fill 413 299 482 413 300 482 minecraft:black_concrete
fill 413 299 484 413 300 484 minecraft:black_concrete
fill 414 299 467 414 300 467 minecraft:black_concrete
fill 414 299 469 414 300 469 minecraft:black_concrete
setblock 414 299 471 minecraft:black_concrete
setblock 414 299 473 minecraft:black_concrete
fill 414 299 475 414 300 475 minecraft:black_concrete
fill 414 299 477 414 300 477 minecraft:black_concrete
fill 414 299 479 414 300 479 minecraft:black_concrete
fill 414 299 481 414 300 481 minecraft:black_concrete
fill 414 299 483 414 300 483 minecraft:black_concrete
fill 414 299 485 414 300 485 minecraft:black_concrete
fill 415 299 468 415 300 468 minecraft:black_concrete
fill 415 299 470 415 300 470 minecraft:black_concrete
setblock 415 299 472 minecraft:black_concrete
setblock 415 299 474 minecraft:black_concrete
fill 415 299 476 415 300 476 minecraft:black_concrete
fill 415 299 478 415 300 478 minecraft:black_concrete
fill 415 299 480 415 300 480 minecraft:black_concrete
fill 415 299 482 415 300 482 minecraft:black_concrete
fill 415 299 484 415 300 484 minecraft:black_concrete
fill 416 299 467 416 300 467 minecraft:black_concrete
fill 416 299 469 416 300 469 minecraft:black_concrete
fill 416 299 471 416 300 471 minecraft:black_concrete
fill 416 299 473 416 300 473 minecraft:black_concrete
fill 416 299 475 416 300 475 minecraft:black_concrete
fill 416 299 477 416 300 477 minecraft:black_concrete
fill 416 299 479 416 300 479 minecraft:black_concrete
fill 416 299 481 416 300 481 minecraft:black_concrete
fill 416 299 483 416 300 483 minecraft:black_concrete
fill 416 299 485 416 300 485 minecraft:black_concrete
fill 417 299 468 417 300 468 minecraft:black_concrete
fill 417 299 470 417 300 470 minecraft:black_concrete
fill 417 299 472 417 300 472 minecraft:black_concrete
fill 417 299 474 417 300 474 minecraft:black_concrete
fill 417 299 476 417 300 476 minecraft:black_concrete
fill 417 299 478 417 300 478 minecraft:black_concrete
fill 417 299 480 417 300 480 minecraft:black_concrete
fill 417 299 482 417 300 482 minecraft:black_concrete
fill 417 299 484 417 300 484 minecraft:black_concrete
fill 418 299 468 418 300 468 minecraft:sea_lantern
fill 418 299 476 418 300 476 minecraft:sea_lantern
fill 418 299 484 418 300 484 minecraft:sea_lantern
fill 412 300 471 415 300 474 minecraft:white_concrete
fill 376 301 468 376 307 468 minecraft:magenta_concrete
fill 376 301 476 376 307 476 minecraft:magenta_concrete
fill 376 301 484 376 307 484 minecraft:magenta_concrete
fill 376 301 492 376 307 492 minecraft:magenta_concrete
fill 376 301 500 376 307 500 minecraft:magenta_concrete
fill 379 301 505 379 307 505 minecraft:magenta_concrete
fill 383 301 463 383 307 463 minecraft:magenta_concrete
fill 387 301 505 387 307 505 minecraft:magenta_concrete
fill 391 301 463 391 307 463 minecraft:magenta_concrete
fill 395 301 505 395 307 505 minecraft:magenta_concrete
fill 399 301 463 399 307 463 minecraft:magenta_concrete
fill 403 301 505 403 307 505 minecraft:magenta_concrete
fill 407 301 463 407 307 463 minecraft:magenta_concrete
fill 411 301 505 411 307 505 minecraft:magenta_concrete
fill 415 301 463 415 307 463 minecraft:magenta_concrete
fill 418 301 468 418 307 468 minecraft:magenta_concrete
fill 418 301 476 418 307 476 minecraft:magenta_concrete
fill 418 301 484 418 307 484 minecraft:magenta_concrete
fill 418 301 492 418 307 492 minecraft:magenta_concrete
fill 418 301 500 418 307 500 minecraft:magenta_concrete
