setblock 172 70 313 minecraft:snow_block
fill 172 70 314 172 73 314 minecraft:packed_ice
fill 173 70 313 175 71 313 minecraft:packed_ice
setblock 174 70 276 minecraft:snow_block
setblock 174 70 316 minecraft:snow_block
fill 175 70 276 175 73 276 minecraft:packed_ice
setblock 175 70 315 minecraft:snow_block
fill 175 70 316 175 73 316 minecraft:packed_ice
setblock 176 70 314 minecraft:snow_block
fill 176 70 315 176 73 315 minecraft:packed_ice
fill 177 70 314 177 73 314 minecraft:packed_ice
setblock 179 70 316 minecraft:snow_block
setblock 180 70 310 minecraft:snow_block
setblock 181 70 304 minecraft:snow_block
fill 181 70 305 181 72 305 minecraft:packed_ice
setblock 181 70 309 minecraft:snow_block
fill 181 70 310 181 73 310 minecraft:packed_ice
fill 181 70 312 181 71 312 minecraft:packed_ice
setblock 182 70 288 minecraft:snow_block
fill 182 70 289 182 72 290 minecraft:packed_ice
setblock 182 70 303 minecraft:snow_block
fill 182 70 304 182 73 304 minecraft:packed_ice
setblock 182 70 308 minecraft:snow_block
fill 182 70 309 182 73 309 minecraft:packed_ice
setblock 182 70 313 minecraft:snow_block
fill 182 70 314 182 73 314 minecraft:packed_ice
setblock 141 71 278 minecraft:light_blue_concrete
fill 141 71 279 141 79 280 minecraft:packed_ice
setblock 142 71 287 minecraft:snow_block
fill 142 71 288 142 74 288 minecraft:packed_ice
setblock 142 71 292 minecraft:snow_block
fill 142 71 293 143 73 293 minecraft:packed_ice
fill 142 71 295 142 71 296 minecraft:packed_ice
setblock 142 71 303 minecraft:packed_ice
setblock 142 71 307 minecraft:snow_block
fill 142 71 308 142 74 308 minecraft:packed_ice
setblock 142 71 312 minecraft:snow_block
setblock 143 71 286 minecraft:snow_block
fill 143 71 287 143 74 287 minecraft:packed_ice
setblock 143 71 291 minecraft:snow_block
fill 143 71 292 143 74 292 minecraft:packed_ice
fill 144 71 294 144 76 294 minecraft:packed_ice
fill 145 71 275 145 89 275 minecraft:packed_ice
fill 145 71 292 145 77 292 minecraft:packed_ice
fill 146 71 296 147 75 296 minecraft:packed_ice
fill 149 71 276 152 71 276 minecraft:packed_ice
fill 149 71 293 149 75 294 minecraft:packed_ice
fill 149 71 316 149 74 317 minecraft:packed_ice
fill 150 71 316 152 71 316 minecraft:packed_ice
setblock 151 71 277 minecraft:packed_ice
setblock 152 71 277 minecraft:snow_block
fill 152 71 315 153 71 315 minecraft:packed_ice
setblock 153 71 276 minecraft:snow_block
fill 153 71 277 153 74 277 minecraft:packed_ice
setblock 153 71 316 minecraft:snow_block
fill 154 71 276 154 74 276 minecraft:packed_ice
setblock 154 71 315 minecraft:snow_block
fill 154 71 316 154 74 317 minecraft:packed_ice
fill 155 71 315 155 74 315 minecraft:packed_ice
setblock 157 71 316 minecraft:packed_ice
setblock 158 71 276 minecraft:snow_block
setblock 158 71 316 minecraft:snow_block
fill 159 71 276 160 73 276 minecraft:packed_ice
fill 159 71 316 162 71 316 minecraft:packed_ice
setblock 163 71 316 minecraft:snow_block
fill 164 71 316 164 74 316 minecraft:packed_ice
fill 165 71 276 167 71 276 minecraft:packed_ice
fill 166 71 315 168 71 315 minecraft:packed_ice
setblock 167 71 316 minecraft:packed_ice
setblock 168 71 276 minecraft:snow_block
fill 168 71 314 169 71 314 minecraft:packed_ice
setblock 168 71 316 minecraft:snow_block
fill 169 71 276 169 74 276 minecraft:packed_ice
setblock 169 71 315 minecraft:snow_block
fill 169 71 316 169 74 316 minecraft:packed_ice
setblock 170 71 313 minecraft:packed_ice
setblock 170 71 314 minecraft:snow_block
fill 170 71 315 170 74 315 minecraft:packed_ice
setblock 171 71 313 minecraft:snow_block
fill 171 71 314 171 74 314 minecraft:packed_ice
fill 172 71 313 172 74 313 minecraft:packed_ice
setblock 173 71 276 minecraft:snow_block
setblock 173 71 316 minecraft:snow_block
fill 174 71 276 174 74 276 minecraft:packed_ice
setblock 174 71 314 minecraft:packed_ice
setblock 174 71 315 minecraft:snow_block
fill 174 71 316 174 74 316 minecraft:packed_ice
setblock 175 71 314 minecraft:snow_block
fill 175 71 315 175 74 315 minecraft:packed_ice
fill 176 71 276 176 72 276 minecraft:packed_ice
setblock 176 71 313 minecraft:snow_block
fill 176 71 314 176 74 314 minecraft:packed_ice
setblock 178 71 316 minecraft:snow_block
fill 179 71 316 180 73 316 minecraft:packed_ice
setblock 180 71 308 minecraft:packed_ice
setblock 180 71 309 minecraft:snow_block
fill 180 71 310 180 73 311 minecraft:packed_ice
setblock 181 71 308 minecraft:snow_block
fill 181 71 309 181 74 309 minecraft:packed_ice
setblock 181 71 313 minecraft:snow_block
setblock 182 71 287 minecraft:snow_block
fill 182 71 288 182 74 288 minecraft:packed_ice
setblock 182 71 291 minecraft:packed_ice
setblock 182 71 292 minecraft:snow_block
fill 182 71 293 182 74 293 minecraft:packed_ice
setblock 182 71 302 minecraft:snow_block
fill 182 71 303 182 74 303 minecraft:packed_ice
setblock 182 71 307 minecraft:snow_block
fill 182 71 308 182 74 308 minecraft:packed_ice
setblock 182 71 312 minecraft:snow_block
fill 182 71 313 182 74 313 minecraft:packed_ice
fill 141 72 278 141 93 278 minecraft:packed_ice
setblock 142 72 286 minecraft:snow_block
fill 142 72 287 142 75 287 minecraft:packed_ice
setblock 142 72 291 minecraft:snow_block
fill 142 72 292 142 75 292 minecraft:packed_ice
setblock 142 72 295 minecraft:packed_ice
setblock 142 72 296 minecraft:snow_block
fill 142 72 297 142 75 297 minecraft:packed_ice
setblock 142 72 306 minecraft:snow_block
fill 142 72 307 142 74 307 minecraft:packed_ice
setblock 142 72 311 minecraft:snow_block
fill 142 72 312 142 75 312 minecraft:packed_ice
setblock 143 72 285 minecraft:snow_block
fill 143 72 286 143 75 286 minecraft:packed_ice
setblock 143 72 290 minecraft:snow_block
fill 143 72 291 148 73 291 minecraft:packed_ice
setblock 143 72 294 minecraft:packed_ice
setblock 144 72 278 minecraft:light[level=15]
setblock 144 72 285 minecraft:light[level=12]
setblock 144 72 286 minecraft:light[level=15]
setblock 144 72 288 minecraft:packed_ice
setblock 144 72 289 minecraft:snow_block
fill 144 72 290 144 75 290 minecraft:packed_ice
fill 144 72 292 144 72 293 minecraft:packed_ice
fill 144 72 295 144 75 295 minecraft:packed_ice
setblock 144 72 299 minecraft:light[level=12]
setblock 144 72 302 minecraft:light[level=15]
setblock 144 72 306 minecraft:light[level=12]
setblock 144 72 310 minecraft:light[level=15]
setblock 144 72 313 minecraft:light[level=12]
fill 145 72 296 145 75 296 minecraft:packed_ice
setblock 147 72 316 minecraft:snow_block
fill 148 72 276 151 72 276 minecraft:packed_ice
fill 148 72 296 148 75 296 minecraft:packed_ice
fill 148 72 316 148 75 316 minecraft:packed_ice
fill 149 72 292 149 75 292 minecraft:packed_ice
fill 149 72 295 149 75 295 minecraft:packed_ice
fill 149 72 315 152 72 315 minecraft:packed_ice
setblock 150 72 277 minecraft:packed_ice
fill 150 72 316 151 72 316 minecraft:packed_ice
setblock 151 72 277 minecraft:snow_block
setblock 151 72 278 minecraft:light[level=12]
setblock 151 72 285 minecraft:light[level=12]
setblock 151 72 292 minecraft:light[level=12]
setblock 151 72 299 minecraft:light[level=12]
setblock 151 72 306 minecraft:light[level=12]
setblock 151 72 313 minecraft:light[level=12]
setblock 152 72 276 minecraft:snow_block
fill 152 72 277 152 75 277 minecraft:packed_ice
setblock 152 72 278 minecraft:light[level=15]
setblock 152 72 286 minecraft:light[level=15]
setblock 152 72 294 minecraft:light[level=15]
setblock 152 72 302 minecraft:light[level=15]
setblock 152 72 310 minecraft:light[level=15]
setblock 152 72 316 minecraft:snow_block
fill 153 72 276 153 75 276 minecraft:packed_ice
setblock 153 72 315 minecraft:snow_block
fill 153 72 316 153 75 316 minecraft:packed_ice
fill 154 72 315 154 75 315 minecraft:packed_ice
setblock 156 72 277 minecraft:snow_block
fill 156 72 315 157 72 315 minecraft:packed_ice
setblock 157 72 276 minecraft:snow_block
setblock 157 72 316 minecraft:snow_block
fill 158 72 276 158 75 276 minecraft:packed_ice
setblock 158 72 278 minecraft:light[level=12]
setblock 158 72 285 minecraft:light[level=12]
setblock 158 72 292 minecraft:light[level=12]
setblock 158 72 299 minecraft:light[level=12]
setblock 158 72 306 minecraft:light[level=12]
setblock 158 72 313 minecraft:light[level=12]
fill 158 72 316 161 72 316 minecraft:packed_ice
setblock 160 72 278 minecraft:light[level=15]
setblock 160 72 286 minecraft:light[level=15]
setblock 160 72 294 minecraft:light[level=15]
setblock 160 72 302 minecraft:light[level=15]
setblock 160 72 310 minecraft:light[level=15]
setblock 161 72 276 minecraft:packed_ice
setblock 162 72 276 minecraft:snow_block
setblock 162 72 316 minecraft:snow_block
fill 163 72 276 166 72 276 minecraft:packed_ice
fill 163 72 316 163 75 316 minecraft:packed_ice
fill 164 72 315 167 72 315 minecraft:packed_ice
setblock 165 72 278 minecraft:light[level=12]
setblock 165 72 285 minecraft:light[level=12]
setblock 165 72 292 minecraft:light[level=12]
setblock 165 72 299 minecraft:light[level=12]
setblock 165 72 306 minecraft:light[level=12]
setblock 165 72 313 minecraft:light[level=12]
fill 166 72 314 168 72 314 minecraft:packed_ice
setblock 167 72 276 minecraft:snow_block
setblock 167 72 316 minecraft:snow_block
fill 168 72 276 168 75 276 minecraft:packed_ice
setblock 168 72 278 minecraft:light[level=15]
setblock 168 72 286 minecraft:light[level=15]
setblock 168 72 294 minecraft:light[level=15]
setblock 168 72 302 minecraft:light[level=15]
setblock 168 72 310 minecraft:light[level=15]
fill 168 72 313 169 72 313 minecraft:packed_ice
setblock 168 72 315 minecraft:snow_block
fill 168 72 316 168 75 316 minecraft:packed_ice
fill 169 72 277 170 72 277 minecraft:packed_ice
setblock 169 72 314 minecraft:snow_block
fill 169 72 315 169 75 315 minecraft:packed_ice
setblock 170 72 313 minecraft:snow_block
fill 170 72 314 170 75 314 minecraft:packed_ice
setblock 171 72 277 minecraft:snow_block
setblock 171 72 312 minecraft:snow_block
fill 171 72 313 171 75 313 minecraft:packed_ice
setblock 172 72 276 minecraft:snow_block
fill 172 72 277 172 75 277 minecraft:packed_ice
setblock 172 72 278 minecraft:light[level=12]
setblock 172 72 285 minecraft:light[level=12]
setblock 172 72 292 minecraft:light[level=12]
setblock 172 72 299 minecraft:light[level=12]
setblock 172 72 306 minecraft:light[level=12]
fill 172 72 312 174 73 312 minecraft:packed_ice
setblock 172 72 316 minecraft:snow_block
fill 173 72 276 173 75 276 minecraft:packed_ice
fill 173 72 313 174 72 313 minecraft:packed_ice
setblock 173 72 315 minecraft:snow_block
fill 173 72 316 173 75 316 minecraft:packed_ice
setblock 174 72 314 minecraft:snow_block
fill 174 72 315 174 75 315 minecraft:packed_ice
setblock 175 72 313 minecraft:snow_block
fill 175 72 314 175 75 314 minecraft:packed_ice
setblock 176 72 278 minecraft:light[level=15]
setblock 176 72 286 minecraft:light[level=15]
setblock 176 72 294 minecraft:light[level=15]
setblock 176 72 302 minecraft:light[level=15]
setblock 176 72 310 minecraft:light[level=15]
fill 176 72 313 176 74 313 minecraft:packed_ice
setblock 177 72 315 minecraft:packed_ice
setblock 177 72 316 minecraft:snow_block
setblock 178 72 315 minecraft:snow_block
fill 178 72 316 178 75 316 minecraft:packed_ice
setblock 179 72 278 minecraft:light[level=12]
setblock 179 72 285 minecraft:light[level=12]
setblock 179 72 292 minecraft:light[level=12]
setblock 179 72 299 minecraft:light[level=12]
setblock 179 72 306 minecraft:light[level=12]
setblock 179 72 313 minecraft:light[level=12]
fill 179 72 315 179 75 315 minecraft:packed_ice
setblock 180 72 308 minecraft:snow_block
setblock 180 72 309 minecraft:packed_ice
setblock 181 72 307 minecraft:snow_block
fill 181 72 308 181 75 308 minecraft:packed_ice
setblock 181 72 312 minecraft:snow_block
fill 181 72 313 181 75 313 minecraft:packed_ice
setblock 182 72 286 minecraft:snow_block
fill 182 72 287 182 75 287 minecraft:packed_ice
setblock 182 72 291 minecraft:snow_block
fill 182 72 292 182 75 292 minecraft:packed_ice
fill 182 72 294 182 72 295 minecraft:packed_ice
setblock 182 72 296 minecraft:snow_block
fill 182 72 302 182 75 302 minecraft:packed_ice
setblock 182 72 306 minecraft:snow_block
fill 182 72 307 182 75 307 minecraft:packed_ice
setblock 182 72 311 minecraft:snow_block
fill 182 72 312 182 75 312 minecraft:packed_ice
setblock 182 72 315 minecraft:packed_ice
setblock 183 72 307 minecraft:white_concrete
setblock 183 72 312 minecraft:light_blue_concrete
setblock 142 73 285 minecraft:snow_block
fill 142 73 286 142 76 286 minecraft:packed_ice
setblock 142 73 289 minecraft:packed_ice
setblock 142 73 290 minecraft:snow_block
fill 142 73 291 142 76 291 minecraft:packed_ice
setblock 142 73 295 minecraft:snow_block
fill 142 73 296 142 76 296 minecraft:packed_ice
fill 142 73 298 142 74 298 minecraft:packed_ice
setblock 142 73 305 minecraft:snow_block
setblock 142 73 306 minecraft:packed_ice
setblock 142 73 310 minecraft:snow_block
fill 142 73 311 142 76 311 minecraft:packed_ice
fill 142 73 313 142 74 313 minecraft:packed_ice
fill 143 73 285 143 74 285 minecraft:packed_ice
setblock 143 73 289 minecraft:snow_block
fill 143 73 290 143 76 290 minecraft:packed_ice
setblock 143 73 294 minecraft:snow_block
fill 143 73 295 143 76 295 minecraft:packed_ice
setblock 144 73 287 minecraft:packed_ice
setblock 144 73 288 minecraft:snow_block
fill 144 73 289 144 76 289 minecraft:packed_ice
setblock 144 73 292 minecraft:packed_ice
setblock 144 73 293 minecraft:snow_block
fill 144 73 296 144 75 296 minecraft:packed_ice
setblock 146 73 276 minecraft:snow_block
fill 146 73 297 147 75 297 minecraft:packed_ice
setblock 146 73 316 minecraft:snow_block
fill 147 73 276 150 73 276 minecraft:packed_ice
fill 147 73 316 147 76 316 minecraft:packed_ice
fill 148 73 315 151 73 315 minecraft:packed_ice
setblock 149 73 277 minecraft:packed_ice
fill 149 73 291 149 75 291 minecraft:packed_ice
fill 149 73 296 149 75 296 minecraft:packed_ice
setblock 150 73 277 minecraft:snow_block
fill 150 73 293 150 75 294 minecraft:packed_ice
setblock 150 73 316 minecraft:packed_ice
setblock 151 73 276 minecraft:snow_block
fill 151 73 277 151 76 277 minecraft:packed_ice
fill 151 73 314 152 73 314 minecraft:packed_ice
setblock 151 73 316 minecraft:snow_block
fill 152 73 276 152 76 276 minecraft:packed_ice
setblock 152 73 315 minecraft:snow_block
fill 152 73 316 152 76 316 minecraft:packed_ice
setblock 153 73 314 minecraft:snow_block
fill 153 73 315 153 76 315 minecraft:packed_ice
setblock 155 73 277 minecraft:snow_block
setblock 156 73 276 minecraft:snow_block
fill 156 73 277 156 75 277 minecraft:packed_ice
setblock 156 73 315 minecraft:packed_ice
setblock 156 73 316 minecraft:snow_block
fill 157 73 276 157 76 276 minecraft:packed_ice
setblock 157 73 315 minecraft:snow_block
fill 157 73 316 160 73 316 minecraft:packed_ice
fill 158 73 315 158 76 315 minecraft:packed_ice
setblock 161 73 276 minecraft:snow_block
setblock 161 73 316 minecraft:snow_block
fill 162 73 276 165 73 276 minecraft:packed_ice
setblock 162 73 315 minecraft:snow_block
fill 162 73 316 162 76 316 minecraft:packed_ice
fill 163 73 315 166 73 315 minecraft:packed_ice
fill 165 73 314 167 73 314 minecraft:packed_ice
setblock 165 73 316 minecraft:packed_ice
setblock 166 73 276 minecraft:snow_block
setblock 166 73 316 minecraft:snow_block
fill 167 73 276 167 76 276 minecraft:packed_ice
fill 167 73 313 168 73 313 minecraft:packed_ice
setblock 167 73 315 minecraft:snow_block
fill 167 73 316 167 76 316 minecraft:packed_ice
setblock 167 73 317 minecraft:light_blue_concrete
fill 168 73 277 169 73 277 minecraft:packed_ice
setblock 168 73 314 minecraft:snow_block
fill 168 73 315 168 76 315 minecraft:packed_ice
fill 169 73 275 170 93 275 minecraft:packed_ice
setblock 169 73 313 minecraft:snow_block
fill 169 73 314 169 76 314 minecraft:packed_ice
setblock 170 73 277 minecraft:snow_block
setblock 170 73 312 minecraft:snow_block
fill 170 73 313 170 76 313 minecraft:packed_ice
setblock 171 73 275 minecraft:light_blue_concrete
setblock 171 73 276 minecraft:snow_block
fill 171 73 277 171 76 277 minecraft:packed_ice
fill 171 73 312 171 76 312 minecraft:packed_ice
setblock 171 73 316 minecraft:snow_block
fill 172 73 275 172 76 276 minecraft:packed_ice
setblock 172 73 315 minecraft:snow_block
fill 172 73 316 172 76 316 minecraft:packed_ice
fill 173 73 275 175 77 275 minecraft:packed_ice
setblock 173 73 313 minecraft:packed_ice
setblock 173 73 314 minecraft:snow_block
fill 173 73 315 173 76 315 minecraft:packed_ice
setblock 174 73 313 minecraft:snow_block
fill 174 73 314 174 76 314 minecraft:packed_ice
fill 175 73 313 175 75 313 minecraft:packed_ice
setblock 176 73 276 minecraft:snow_block
setblock 176 73 316 minecraft:snow_block
setblock 177 73 315 minecraft:snow_block
fill 177 73 316 177 76 316 minecraft:packed_ice
setblock 178 73 314 minecraft:snow_block
fill 178 73 315 178 76 315 minecraft:packed_ice
setblock 181 73 306 minecraft:snow_block
fill 181 73 307 181 74 307 minecraft:packed_ice
setblock 181 73 311 minecraft:snow_block
fill 181 73 312 181 76 312 minecraft:packed_ice
fill 181 73 314 181 74 314 minecraft:packed_ice
setblock 181 73 316 minecraft:snow_block
setblock 182 73 286 minecraft:packed_ice
setblock 182 73 289 minecraft:packed_ice
setblock 182 73 290 minecraft:snow_block
fill 182 73 291 182 76 291 minecraft:packed_ice
setblock 182 73 294 minecraft:packed_ice
setblock 182 73 295 minecraft:snow_block
fill 182 73 296 182 73 299 minecraft:packed_ice
fill 182 73 301 182 76 301 minecraft:packed_ice
setblock 182 73 305 minecraft:snow_block
fill 182 73 306 182 76 306 minecraft:packed_ice
setblock 182 73 310 minecraft:snow_block
fill 182 73 311 182 76 311 minecraft:packed_ice
setblock 182 73 315 minecraft:snow_block
fill 182 73 316 182 76 316 minecraft:packed_ice
fill 183 73 307 183 93 307 minecraft:packed_ice
fill 183 73 312 183 93 312 minecraft:packed_ice
setblock 142 74 284 minecraft:snow_block
fill 142 74 285 142 77 285 minecraft:packed_ice
setblock 142 74 289 minecraft:snow_block
fill 142 74 290 142 77 290 minecraft:packed_ice
setblock 142 74 293 minecraft:packed_ice
setblock 142 74 294 minecraft:snow_block
fill 142 74 295 142 77 295 minecraft:packed_ice
setblock 142 74 299 minecraft:snow_block
setblock 142 74 309 minecraft:snow_block
fill 142 74 310 142 75 310 minecraft:packed_ice
setblock 142 74 314 minecraft:snow_block
fill 143 74 275 143 89 275 minecraft:packed_ice
setblock 143 74 288 minecraft:snow_block
fill 143 74 289 143 77 289 minecraft:packed_ice
fill 143 74 291 144 74 291 minecraft:packed_ice
setblock 143 74 293 minecraft:snow_block
fill 143 74 294 143 77 294 minecraft:packed_ice
fill 143 74 296 143 75 296 minecraft:packed_ice
setblock 144 74 275 minecraft:white_concrete
setblock 144 74 287 minecraft:snow_block
fill 144 74 288 144 77 288 minecraft:packed_ice
setblock 144 74 292 minecraft:snow_block
fill 144 74 293 144 77 293 minecraft:packed_ice
fill 145 74 289 145 74 290 minecraft:packed_ice
setblock 145 74 291 minecraft:snow_block
fill 145 74 297 145 75 297 minecraft:packed_ice
setblock 145 74 316 minecraft:snow_block
fill 146 74 276 149 74 276 minecraft:packed_ice
fill 146 74 290 148 75 291 minecraft:packed_ice
fill 146 74 316 146 77 316 minecraft:packed_ice
fill 147 74 315 150 74 315 minecraft:packed_ice
setblock 148 74 277 minecraft:packed_ice
fill 148 74 297 148 75 297 minecraft:packed_ice
setblock 149 74 277 minecraft:snow_block
setblock 150 74 276 minecraft:snow_block
fill 150 74 277 150 77 277 minecraft:packed_ice
fill 150 74 292 150 75 292 minecraft:packed_ice
fill 150 74 295 150 75 295 minecraft:packed_ice
fill 150 74 314 151 74 314 minecraft:packed_ice
setblock 150 74 316 minecraft:snow_block
fill 151 74 276 151 77 276 minecraft:packed_ice
setblock 151 74 315 minecraft:snow_block
fill 151 74 316 151 77 316 minecraft:packed_ice
setblock 152 74 314 minecraft:snow_block
fill 152 74 315 152 77 315 minecraft:packed_ice
fill 153 74 314 154 74 314 minecraft:packed_ice
setblock 154 74 277 minecraft:snow_block
setblock 155 74 276 minecraft:snow_block
fill 155 74 277 155 77 277 minecraft:packed_ice
setblock 155 74 316 minecraft:snow_block
fill 156 74 276 156 77 276 minecraft:packed_ice
setblock 156 74 315 minecraft:snow_block
fill 156 74 316 159 74 316 minecraft:packed_ice
fill 157 74 315 157 77 315 minecraft:packed_ice
setblock 159 74 276 minecraft:packed_ice
fill 159 74 315 160 74 315 minecraft:packed_ice
setblock 160 74 276 minecraft:snow_block
setblock 160 74 316 minecraft:snow_block
fill 161 74 276 164 74 276 minecraft:packed_ice
setblock 161 74 315 minecraft:snow_block
fill 161 74 316 161 77 316 minecraft:packed_ice
fill 162 74 315 165 74 315 minecraft:packed_ice
fill 164 74 314 166 74 314 minecraft:packed_ice
setblock 165 74 276 minecraft:snow_block
setblock 165 74 316 minecraft:snow_block
fill 166 74 276 166 77 276 minecraft:packed_ice
fill 166 74 313 167 74 313 minecraft:packed_ice
setblock 166 74 315 minecraft:snow_block
fill 166 74 316 166 77 316 minecraft:packed_ice
fill 167 74 277 168 74 277 minecraft:packed_ice
setblock 167 74 314 minecraft:snow_block
fill 167 74 315 167 77 315 minecraft:packed_ice
fill 167 74 317 167 93 317 minecraft:packed_ice
setblock 168 74 313 minecraft:snow_block
fill 168 74 314 168 77 314 minecraft:packed_ice
setblock 169 74 277 minecraft:snow_block
setblock 169 74 312 minecraft:snow_block
fill 169 74 313 169 77 313 minecraft:packed_ice
setblock 170 74 276 minecraft:snow_block
fill 170 74 277 170 77 277 minecraft:packed_ice
fill 170 74 312 170 76 312 minecraft:packed_ice
setblock 170 74 316 minecraft:snow_block
fill 171 74 275 171 77 276 minecraft:packed_ice
setblock 171 74 315 minecraft:snow_block
fill 171 74 316 171 77 316 minecraft:packed_ice
fill 172 74 312 173 74 312 minecraft:packed_ice
setblock 172 74 314 minecraft:snow_block
fill 172 74 315 172 77 315 minecraft:packed_ice
setblock 173 74 313 minecraft:snow_block
fill 173 74 314 173 77 314 minecraft:packed_ice
fill 174 74 313 174 76 313 minecraft:packed_ice
setblock 175 74 276 minecraft:snow_block
setblock 175 74 316 minecraft:snow_block
setblock 176 74 315 minecraft:snow_block
fill 176 74 316 176 77 316 minecraft:packed_ice
setblock 177 74 314 minecraft:snow_block
fill 177 74 315 177 77 315 minecraft:packed_ice
setblock 179 74 316 minecraft:packed_ice
setblock 180 74 316 minecraft:snow_block
setblock 181 74 290 minecraft:snow_block
fill 181 74 291 181 75 293 minecraft:packed_ice
setblock 181 74 310 minecraft:snow_block
fill 181 74 311 181 76 311 minecraft:packed_ice
fill 181 74 316 181 77 316 minecraft:packed_ice
setblock 182 74 289 minecraft:snow_block
fill 182 74 290 182 77 290 minecraft:packed_ice
setblock 182 74 294 minecraft:snow_block
fill 182 74 295 182 74 298 minecraft:packed_ice
setblock 182 74 299 minecraft:snow_block
fill 182 74 300 182 77 300 minecraft:packed_ice
setblock 182 74 304 minecraft:snow_block
fill 182 74 305 182 76 305 minecraft:packed_ice
setblock 182 74 309 minecraft:snow_block
fill 182 74 310 182 77 310 minecraft:packed_ice
setblock 182 74 314 minecraft:snow_block
fill 182 74 315 182 77 315 minecraft:packed_ice
setblock 183 74 286 minecraft:white_concrete
setblock 183 74 306 minecraft:white_concrete
setblock 142 75 284 minecraft:packed_ice
setblock 142 75 288 minecraft:snow_block
fill 142 75 289 142 78 289 minecraft:packed_ice
setblock 142 75 293 minecraft:snow_block
fill 142 75 294 142 78 294 minecraft:packed_ice
setblock 142 75 298 minecraft:snow_block
fill 142 75 299 142 78 299 minecraft:packed_ice
setblock 142 75 308 minecraft:snow_block
setblock 142 75 309 minecraft:packed_ice
setblock 142 75 313 minecraft:snow_block
fill 142 75 314 142 77 314 minecraft:packed_ice
setblock 143 75 287 minecraft:snow_block
fill 143 75 288 143 78 288 minecraft:packed_ice
setblock 143 75 291 minecraft:packed_ice
setblock 143 75 292 minecraft:snow_block
fill 143 75 293 143 78 293 minecraft:packed_ice
setblock 143 75 297 minecraft:snow_block
fill 144 75 275 144 93 275 minecraft:packed_ice
setblock 144 75 287 minecraft:packed_ice
setblock 144 75 291 minecraft:snow_block
fill 144 75 292 144 78 292 minecraft:packed_ice
setblock 144 75 297 minecraft:packed_ice
setblock 144 75 316 minecraft:snow_block
fill 145 75 276 148 75 276 minecraft:packed_ice
setblock 145 75 289 minecraft:packed_ice
setblock 145 75 290 minecraft:snow_block
fill 145 75 291 145 77 291 minecraft:packed_ice
fill 145 75 316 145 78 316 minecraft:packed_ice
fill 146 75 298 148 75 298 minecraft:packed_ice
fill 146 75 315 149 75 315 minecraft:packed_ice
setblock 147 75 277 minecraft:packed_ice
setblock 148 75 277 minecraft:snow_block
fill 149 75 275 150 91 275 minecraft:packed_ice
setblock 149 75 276 minecraft:snow_block
fill 149 75 277 149 78 277 minecraft:packed_ice
setblock 149 75 290 minecraft:packed_ice
setblock 149 75 297 minecraft:packed_ice
fill 149 75 311 149 78 311 minecraft:snow_block
fill 149 75 314 150 75 314 minecraft:packed_ice
setblock 149 75 316 minecraft:snow_block
fill 149 75 317 149 93 317 minecraft:packed_ice
fill 150 75 276 150 78 276 minecraft:packed_ice
setblock 150 75 291 minecraft:packed_ice
setblock 150 75 296 minecraft:packed_ice
fill 150 75 310 150 78 310 minecraft:snow_block
fill 150 75 312 150 78 312 minecraft:snow_block
setblock 150 75 315 minecraft:snow_block
fill 150 75 316 150 78 316 minecraft:packed_ice
setblock 151 75 275 minecraft:white_concrete
fill 151 75 293 151 75 294 minecraft:packed_ice
fill 151 75 311 151 78 311 minecraft:snow_block
setblock 151 75 314 minecraft:snow_block
fill 151 75 315 151 78 315 minecraft:packed_ice
fill 152 75 314 153 75 314 minecraft:packed_ice
setblock 153 75 277 minecraft:snow_block
setblock 154 75 276 minecraft:snow_block
fill 154 75 277 154 78 277 minecraft:packed_ice
setblock 154 75 316 minecraft:snow_block
fill 154 75 317 154 91 317 minecraft:packed_ice
fill 155 75 276 155 78 276 minecraft:packed_ice
setblock 155 75 315 minecraft:snow_block
fill 155 75 316 158 75 316 minecraft:packed_ice
fill 156 75 315 156 78 315 minecraft:packed_ice
setblock 159 75 276 minecraft:snow_block
setblock 159 75 315 minecraft:packed_ice
setblock 159 75 316 minecraft:snow_block
fill 160 75 276 163 75 276 minecraft:packed_ice
setblock 160 75 315 minecraft:snow_block
fill 160 75 316 160 78 316 minecraft:packed_ice
fill 161 75 315 164 75 315 minecraft:packed_ice
fill 163 75 314 165 75 314 minecraft:packed_ice
setblock 164 75 276 minecraft:snow_block
setblock 164 75 316 minecraft:snow_block
fill 165 75 276 165 78 276 minecraft:packed_ice
setblock 165 75 315 minecraft:snow_block
fill 165 75 316 165 78 316 minecraft:packed_ice
setblock 166 75 275 minecraft:white_concrete
fill 166 75 277 167 75 277 minecraft:packed_ice
setblock 166 75 313 minecraft:packed_ice
setblock 166 75 314 minecraft:snow_block
fill 166 75 315 166 78 315 minecraft:packed_ice
setblock 167 75 313 minecraft:snow_block
fill 167 75 314 167 78 314 minecraft:packed_ice
setblock 168 75 277 minecraft:snow_block
fill 168 75 313 168 78 313 minecraft:packed_ice
setblock 169 75 276 minecraft:snow_block
fill 169 75 277 169 78 277 minecraft:packed_ice
fill 169 75 312 169 76 312 minecraft:packed_ice
setblock 169 75 316 minecraft:snow_block
fill 170 75 276 170 78 276 minecraft:packed_ice
setblock 170 75 315 minecraft:snow_block
fill 170 75 316 170 78 316 minecraft:packed_ice
setblock 171 75 314 minecraft:snow_block
fill 171 75 315 171 78 315 minecraft:packed_ice
setblock 172 75 312 minecraft:packed_ice
setblock 172 75 313 minecraft:snow_block
fill 172 75 314 172 78 314 minecraft:packed_ice
fill 173 75 313 173 77 313 minecraft:packed_ice
setblock 174 75 276 minecraft:snow_block
setblock 174 75 316 minecraft:snow_block
setblock 175 75 276 minecraft:packed_ice
setblock 175 75 315 minecraft:snow_block
fill 175 75 316 175 78 316 minecraft:packed_ice
setblock 176 75 314 minecraft:snow_block
fill 176 75 315 176 78 315 minecraft:packed_ice
setblock 177 75 314 minecraft:packed_ice
setblock 179 75 316 minecraft:snow_block
fill 180 75 316 180 78 316 minecraft:packed_ice
setblock 181 75 290 minecraft:packed_ice
setblock 181 75 294 minecraft:snow_block
fill 181 75 295 182 77 295 minecraft:packed_ice
setblock 181 75 309 minecraft:snow_block
setblock 181 75 310 minecraft:packed_ice
setblock 182 75 288 minecraft:snow_block
fill 182 75 289 182 78 289 minecraft:packed_ice
setblock 182 75 293 minecraft:snow_block
fill 182 75 294 182 78 294 minecraft:packed_ice
fill 182 75 296 182 75 297 minecraft:packed_ice
setblock 182 75 298 minecraft:snow_block
fill 182 75 299 182 78 299 minecraft:packed_ice
setblock 182 75 303 minecraft:snow_block
setblock 182 75 304 minecraft:packed_ice
setblock 182 75 308 minecraft:snow_block
fill 182 75 309 183 78 309 minecraft:packed_ice
setblock 182 75 313 minecraft:snow_block
fill 182 75 314 182 78 314 minecraft:packed_ice
setblock 183 75 276 minecraft:light_blue_concrete
fill 183 75 286 183 78 286 minecraft:packed_ice
fill 183 75 306 183 91 306 minecraft:packed_ice
fill 183 75 308 183 89 308 minecraft:packed_ice
setblock 183 75 310 minecraft:white_concrete
setblock 142 76 287 minecraft:snow_block
fill 142 76 288 142 79 288 minecraft:packed_ice
setblock 142 76 292 minecraft:snow_block
fill 142 76 293 142 79 293 minecraft:packed_ice
setblock 142 76 297 minecraft:snow_block
fill 142 76 298 142 79 298 minecraft:packed_ice
setblock 142 76 312 minecraft:snow_block
fill 142 76 313 142 77 313 minecraft:packed_ice
setblock 143 76 286 minecraft:snow_block
fill 143 76 287 143 78 287 minecraft:packed_ice
setblock 143 76 291 minecraft:snow_block
fill 143 76 292 143 79 292 minecraft:packed_ice
setblock 143 76 296 minecraft:snow_block
fill 143 76 297 143 79 297 minecraft:packed_ice
setblock 143 76 316 minecraft:snow_block
fill 144 76 276 147 76 276 minecraft:packed_ice
setblock 144 76 290 minecraft:snow_block
fill 144 76 291 144 79 291 minecraft:packed_ice
setblock 144 76 295 minecraft:snow_block
fill 144 76 316 144 79 316 minecraft:packed_ice
setblock 145 76 290 minecraft:packed_ice
fill 146 76 293 147 77 294 minecraft:blue_ice
fill 146 76 315 148 76 315 minecraft:packed_ice
setblock 147 76 277 minecraft:snow_block
setblock 148 76 276 minecraft:snow_block
fill 148 76 277 148 79 277 minecraft:packed_ice
setblock 148 76 316 minecraft:snow_block
fill 149 76 276 149 79 276 minecraft:packed_ice
setblock 149 76 314 minecraft:packed_ice
setblock 149 76 315 minecraft:snow_block
fill 149 76 316 149 79 316 minecraft:packed_ice
setblock 150 76 314 minecraft:snow_block
fill 150 76 315 150 79 315 minecraft:packed_ice
setblock 150 76 317 minecraft:white_concrete
fill 151 76 275 151 90 275 minecraft:packed_ice
fill 151 76 314 152 76 314 minecraft:packed_ice
setblock 152 76 277 minecraft:snow_block
setblock 153 76 276 minecraft:snow_block
fill 153 76 277 153 79 277 minecraft:packed_ice
setblock 153 76 316 minecraft:snow_block
fill 154 76 276 154 79 276 minecraft:packed_ice
setblock 154 76 315 minecraft:snow_block
fill 154 76 316 157 76 316 minecraft:packed_ice
fill 155 76 315 155 78 315 minecraft:packed_ice
setblock 158 76 276 minecraft:snow_block
fill 158 76 280 158 82 280 minecraft:packed_ice
setblock 158 76 316 minecraft:snow_block
fill 159 76 276 162 76 276 minecraft:packed_ice
setblock 159 76 315 minecraft:snow_block
fill 159 76 316 159 79 316 minecraft:packed_ice
fill 160 76 315 163 76 315 minecraft:packed_ice
setblock 163 76 276 minecraft:snow_block
fill 163 76 314 164 76 314 minecraft:packed_ice
setblock 163 76 316 minecraft:snow_block
fill 164 76 276 164 79 276 minecraft:packed_ice
setblock 164 76 315 minecraft:snow_block
fill 164 76 316 164 79 316 minecraft:packed_ice
fill 165 76 277 166 76 277 minecraft:packed_ice
setblock 165 76 314 minecraft:snow_block
fill 165 76 315 165 79 315 minecraft:packed_ice
fill 166 76 275 166 94 275 minecraft:packed_ice
setblock 166 76 313 minecraft:snow_block
fill 166 76 314 166 79 314 minecraft:packed_ice
setblock 167 76 277 minecraft:snow_block
fill 167 76 313 167 79 313 minecraft:packed_ice
setblock 168 76 276 minecraft:snow_block
fill 168 76 277 168 79 277 minecraft:packed_ice
setblock 168 76 316 minecraft:snow_block
fill 169 76 276 169 79 276 minecraft:packed_ice
setblock 169 76 315 minecraft:snow_block
fill 169 76 316 169 79 316 minecraft:packed_ice
setblock 170 76 314 minecraft:snow_block
fill 170 76 315 170 79 315 minecraft:packed_ice
setblock 171 76 313 minecraft:snow_block
fill 171 76 314 171 79 314 minecraft:packed_ice
fill 172 76 313 172 77 313 minecraft:packed_ice
setblock 173 76 276 minecraft:snow_block
setblock 173 76 316 minecraft:snow_block
fill 174 76 276 174 77 276 minecraft:packed_ice
setblock 174 76 315 minecraft:snow_block
fill 174 76 316 174 79 316 minecraft:packed_ice
setblock 175 76 314 minecraft:snow_block
fill 175 76 315 175 79 315 minecraft:packed_ice
setblock 176 76 314 minecraft:packed_ice
setblock 178 76 316 minecraft:snow_block
fill 179 76 316 179 78 316 minecraft:packed_ice
fill 181 76 291 181 76 292 minecraft:packed_ice
setblock 181 76 293 minecraft:snow_block
fill 181 76 294 181 79 294 minecraft:packed_ice
setblock 181 76 313 minecraft:snow_block
setblock 182 76 287 minecraft:snow_block
fill 182 76 288 182 78 288 minecraft:packed_ice
setblock 182 76 292 minecraft:snow_block
fill 182 76 293 182 79 293 minecraft:packed_ice
setblock 182 76 296 minecraft:packed_ice
setblock 182 76 297 minecraft:snow_block
fill 182 76 298 182 79 298 minecraft:packed_ice
setblock 182 76 307 minecraft:snow_block
fill 182 76 308 182 77 308 minecraft:packed_ice
setblock 182 76 312 minecraft:snow_block
fill 182 76 313 182 79 313 minecraft:packed_ice
fill 183 76 276 183 93 276 minecraft:packed_ice
setblock 183 76 282 minecraft:light_blue_concrete
fill 183 76 310 183 93 310 minecraft:packed_ice
setblock 142 77 286 minecraft:snow_block
fill 142 77 287 142 80 287 minecraft:packed_ice
setblock 142 77 291 minecraft:snow_block
fill 142 77 292 142 80 292 minecraft:packed_ice
setblock 142 77 296 minecraft:snow_block
fill 142 77 297 142 80 297 minecraft:packed_ice
fill 143 77 276 146 77 276 minecraft:packed_ice
setblock 143 77 290 minecraft:snow_block
fill 143 77 291 143 80 291 minecraft:packed_ice
setblock 143 77 295 minecraft:snow_block
fill 143 77 296 143 80 296 minecraft:packed_ice
fill 143 77 316 143 80 316 minecraft:packed_ice
setblock 144 77 289 minecraft:snow_block
fill 144 77 290 144 79 290 minecraft:packed_ice
setblock 144 77 294 minecraft:snow_block
fill 144 77 295 144 80 295 minecraft:packed_ice
fill 145 77 315 147 77 315 minecraft:packed_ice
setblock 146 77 277 minecraft:snow_block
setblock 147 77 276 minecraft:snow_block
fill 147 77 277 147 80 277 minecraft:packed_ice
setblock 147 77 316 minecraft:snow_block
fill 148 77 276 148 80 276 minecraft:packed_ice
setblock 148 77 315 minecraft:snow_block
fill 148 77 316 148 80 316 minecraft:packed_ice
fill 149 77 315 149 80 315 minecraft:packed_ice
setblock 150 77 314 minecraft:packed_ice
fill 150 77 317 150 93 317 minecraft:packed_ice
setblock 151 77 277 minecraft:snow_block
setblock 152 77 276 minecraft:snow_block
fill 152 77 277 152 80 277 minecraft:packed_ice
setblock 152 77 316 minecraft:snow_block
fill 153 77 276 153 80 276 minecraft:packed_ice
setblock 153 77 315 minecraft:snow_block
fill 153 77 316 156 77 316 minecraft:packed_ice
fill 154 77 315 154 79 315 minecraft:packed_ice
setblock 157 77 276 minecraft:snow_block
setblock 157 77 316 minecraft:snow_block
fill 158 77 276 161 77 276 minecraft:packed_ice
setblock 158 77 315 minecraft:snow_block
fill 158 77 316 158 80 316 minecraft:packed_ice
fill 159 77 315 162 77 315 minecraft:packed_ice
setblock 162 77 276 minecraft:snow_block
setblock 162 77 316 minecraft:snow_block
fill 163 77 276 163 80 276 minecraft:packed_ice
setblock 163 77 314 minecraft:packed_ice
setblock 163 77 315 minecraft:snow_block
fill 163 77 316 163 80 316 minecraft:packed_ice
setblock 164 77 314 minecraft:snow_block
fill 164 77 315 164 80 315 minecraft:packed_ice
setblock 165 77 277 minecraft:packed_ice
fill 165 77 314 165 80 314 minecraft:packed_ice
setblock 166 77 277 minecraft:snow_block
fill 166 77 313 166 78 313 minecraft:packed_ice
setblock 167 77 276 minecraft:snow_block
fill 167 77 277 167 80 277 minecraft:packed_ice
setblock 167 77 316 minecraft:snow_block
fill 168 77 276 168 80 276 minecraft:packed_ice
setblock 168 77 315 minecraft:snow_block
fill 168 77 316 168 80 316 minecraft:packed_ice
setblock 169 77 314 minecraft:snow_block
fill 169 77 315 169 80 315 minecraft:packed_ice
setblock 170 77 313 minecraft:snow_block
fill 170 77 314 170 80 314 minecraft:packed_ice
fill 171 77 313 171 78 313 minecraft:packed_ice
fill 172 77 275 172 91 275 minecraft:packed_ice
setblock 172 77 276 minecraft:snow_block
setblock 172 77 316 minecraft:snow_block
fill 173 77 276 173 79 276 minecraft:packed_ice
setblock 173 77 315 minecraft:snow_block
fill 173 77 316 173 80 316 minecraft:packed_ice
setblock 174 77 314 minecraft:snow_block
fill 174 77 315 174 80 315 minecraft:packed_ice
setblock 175 77 314 minecraft:packed_ice
setblock 177 77 316 minecraft:snow_block
fill 178 77 316 178 78 316 minecraft:packed_ice
fill 180 77 285 182 80 287 minecraft:blue_ice
setblock 181 77 291 minecraft:packed_ice
setblock 181 77 292 minecraft:snow_block
fill 181 77 293 181 80 293 minecraft:packed_ice
setblock 181 77 296 minecraft:packed_ice
setblock 182 77 291 minecraft:snow_block
fill 182 77 292 182 80 292 minecraft:packed_ice
setblock 182 77 296 minecraft:snow_block
fill 182 77 297 182 80 297 minecraft:packed_ice
setblock 182 77 301 minecraft:snow_block
setblock 182 77 307 minecraft:packed_ice
setblock 182 77 311 minecraft:snow_block
fill 182 77 312 182 79 312 minecraft:packed_ice
setblock 182 77 316 minecraft:snow_block
fill 183 77 282 183 93 282 minecraft:packed_ice
setblock 141 78 276 minecraft:white_concrete
setblock 141 78 290 minecraft:white_concrete
fill 141 78 291 141 90 295 minecraft:packed_ice
fill 142 78 286 142 81 286 minecraft:packed_ice
setblock 142 78 290 minecraft:snow_block
fill 142 78 291 142 81 291 minecraft:packed_ice
setblock 142 78 295 minecraft:snow_block
fill 142 78 296 142 81 296 minecraft:packed_ice
fill 143 78 276 145 78 276 minecraft:packed_ice
setblock 143 78 289 minecraft:snow_block
fill 143 78 290 143 81 290 minecraft:packed_ice
setblock 143 78 294 minecraft:snow_block
fill 143 78 295 143 81 295 minecraft:packed_ice
setblock 144 78 278 minecraft:light[level=12]
setblock 144 78 285 minecraft:light[level=12]
setblock 144 78 289 minecraft:packed_ice
setblock 144 78 293 minecraft:snow_block
fill 144 78 294 144 81 294 minecraft:packed_ice
setblock 144 78 299 minecraft:light[level=12]
setblock 144 78 306 minecraft:light[level=12]
setblock 144 78 313 minecraft:light[level=12]
setblock 145 78 277 minecraft:snow_block
fill 145 78 315 146 78 315 minecraft:packed_ice
setblock 146 78 276 minecraft:snow_block
fill 146 78 277 146 81 277 minecraft:packed_ice
fill 146 78 294 147 78 294 minecraft:blue_ice
setblock 146 78 316 minecraft:snow_block
fill 147 78 276 147 81 276 minecraft:packed_ice
setblock 147 78 293 minecraft:blue_ice
setblock 147 78 315 minecraft:snow_block
fill 147 78 316 147 81 316 minecraft:packed_ice
fill 148 78 315 148 81 315 minecraft:packed_ice
setblock 150 78 277 minecraft:snow_block
setblock 151 78 276 minecraft:snow_block
fill 151 78 277 151 81 277 minecraft:packed_ice
setblock 151 78 278 minecraft:light[level=12]
setblock 151 78 285 minecraft:light[level=12]
setblock 151 78 292 minecraft:light[level=12]
setblock 151 78 299 minecraft:light[level=12]
setblock 151 78 306 minecraft:light[level=12]
setblock 151 78 313 minecraft:light[level=12]
setblock 151 78 316 minecraft:snow_block
fill 152 78 276 152 81 276 minecraft:packed_ice
setblock 152 78 315 minecraft:snow_block
fill 152 78 316 155 78 316 minecraft:packed_ice
fill 153 78 315 153 79 315 minecraft:packed_ice
setblock 156 78 276 minecraft:snow_block
setblock 156 78 316 minecraft:snow_block
fill 157 78 276 160 78 276 minecraft:packed_ice
fill 157 78 316 157 81 316 minecraft:packed_ice
setblock 158 78 278 minecraft:light[level=12]
setblock 158 78 285 minecraft:light[level=12]
setblock 158 78 292 minecraft:light[level=12]
setblock 158 78 299 minecraft:light[level=12]
setblock 158 78 306 minecraft:light[level=12]
setblock 158 78 313 minecraft:light[level=12]
fill 159 78 315 161 78 315 minecraft:packed_ice
setblock 161 78 276 minecraft:snow_block
setblock 161 78 316 minecraft:snow_block
fill 162 78 276 162 81 276 minecraft:packed_ice
setblock 162 78 315 minecraft:snow_block
fill 162 78 316 162 81 316 minecraft:packed_ice
setblock 163 78 314 minecraft:snow_block
fill 163 78 315 163 81 315 minecraft:packed_ice
setblock 164 78 277 minecraft:packed_ice
fill 164 78 314 164 81 314 minecraft:packed_ice
setblock 165 78 277 minecraft:snow_block
setblock 165 78 278 minecraft:light[level=12]
setblock 165 78 285 minecraft:light[level=12]
setblock 165 78 292 minecraft:light[level=12]
setblock 165 78 299 minecraft:light[level=12]
setblock 165 78 306 minecraft:light[level=12]
setblock 165 78 313 minecraft:light[level=12]
setblock 166 78 276 minecraft:snow_block
fill 166 78 277 166 81 277 minecraft:packed_ice
setblock 166 78 316 minecraft:snow_block
fill 167 78 276 167 81 276 minecraft:packed_ice
setblock 167 78 315 minecraft:snow_block
fill 167 78 316 167 81 316 minecraft:packed_ice
setblock 168 78 314 minecraft:snow_block
fill 168 78 315 168 81 315 minecraft:packed_ice
setblock 169 78 313 minecraft:snow_block
fill 169 78 314 169 81 314 minecraft:packed_ice
setblock 170 78 277 minecraft:snow_block
fill 170 78 313 170 79 313 minecraft:packed_ice
fill 171 78 275 171 94 275 minecraft:packed_ice
setblock 171 78 276 minecraft:snow_block
setblock 171 78 316 minecraft:snow_block
fill 172 78 276 172 81 276 minecraft:packed_ice
setblock 172 78 278 minecraft:light[level=12]
setblock 172 78 285 minecraft:light[level=12]
setblock 172 78 292 minecraft:light[level=12]
setblock 172 78 299 minecraft:light[level=12]
setblock 172 78 306 minecraft:light[level=12]
setblock 172 78 313 minecraft:light[level=12]
setblock 172 78 315 minecraft:snow_block
fill 172 78 316 172 81 316 minecraft:packed_ice
setblock 173 78 275 minecraft:light_blue_concrete
setblock 173 78 314 minecraft:snow_block
fill 173 78 315 173 81 315 minecraft:packed_ice
fill 174 78 275 175 89 275 minecraft:packed_ice
setblock 174 78 314 minecraft:packed_ice
setblock 176 78 316 minecraft:snow_block
fill 177 78 316 177 79 316 minecraft:packed_ice
setblock 179 78 278 minecraft:light[level=12]
fill 179 78 285 179 80 287 minecraft:blue_ice
setblock 179 78 292 minecraft:light[level=12]
setblock 179 78 299 minecraft:light[level=12]
setblock 179 78 306 minecraft:light[level=12]
setblock 179 78 313 minecraft:light[level=12]
fill 180 78 284 182 79 284 minecraft:blue_ice
fill 180 78 288 181 79 288 minecraft:blue_ice
fill 181 78 292 181 81 292 minecraft:packed_ice
setblock 181 78 295 minecraft:packed_ice
setblock 181 78 296 minecraft:snow_block
fill 181 78 297 181 81 297 minecraft:packed_ice
setblock 181 78 316 minecraft:snow_block
setblock 182 78 290 minecraft:snow_block
fill 182 78 291 182 81 291 minecraft:packed_ice
setblock 182 78 295 minecraft:snow_block
fill 182 78 296 182 81 296 minecraft:packed_ice
setblock 182 78 300 minecraft:snow_block
fill 182 78 301 182 81 301 minecraft:packed_ice
setblock 182 78 310 minecraft:snow_block
setblock 182 78 311 minecraft:packed_ice
setblock 182 78 315 minecraft:snow_block
fill 182 78 316 182 81 316 minecraft:packed_ice
fill 141 79 276 144 79 276 minecraft:packed_ice
fill 141 79 290 142 82 290 minecraft:packed_ice
setblock 142 79 289 minecraft:snow_block
setblock 142 79 294 minecraft:snow_block
fill 142 79 295 142 82 295 minecraft:packed_ice
setblock 142 79 299 minecraft:snow_block
setblock 143 79 288 minecraft:snow_block
fill 143 79 289 143 82 289 minecraft:packed_ice
setblock 143 79 293 minecraft:snow_block
fill 143 79 294 143 82 294 minecraft:packed_ice
setblock 143 79 298 minecraft:snow_block
setblock 144 79 292 minecraft:snow_block
fill 144 79 293 144 82 293 minecraft:packed_ice
setblock 144 79 296 minecraft:packed_ice
setblock 145 79 276 minecraft:snow_block
fill 145 79 277 145 82 277 minecraft:packed_ice
setblock 145 79 315 minecraft:packed_ice
setblock 145 79 316 minecraft:snow_block
fill 146 79 276 146 82 276 minecraft:packed_ice
setblock 146 79 315 minecraft:snow_block
fill 146 79 316 146 82 316 minecraft:packed_ice
setblock 147 79 294 minecraft:blue_ice
fill 147 79 315 147 82 315 minecraft:packed_ice
setblock 149 79 277 minecraft:snow_block
setblock 150 79 276 minecraft:snow_block
fill 150 79 277 150 82 277 minecraft:packed_ice
setblock 150 79 316 minecraft:snow_block
fill 151 79 276 151 82 276 minecraft:packed_ice
setblock 151 79 315 minecraft:snow_block
fill 151 79 316 154 79 316 minecraft:packed_ice
fill 152 79 315 152 80 315 minecraft:packed_ice
setblock 154 79 277 minecraft:snow_block
setblock 155 79 276 minecraft:snow_block
setblock 155 79 316 minecraft:snow_block
fill 155 79 317 157 89 317 minecraft:packed_ice
fill 156 79 276 159 79 276 minecraft:packed_ice
fill 156 79 316 156 82 316 minecraft:packed_ice
setblock 158 79 317 minecraft:light_blue_concrete
fill 159 79 286 159 80 286 minecraft:blue_ice
setblock 160 79 276 minecraft:snow_block
setblock 160 79 315 minecraft:packed_ice
setblock 160 79 316 minecraft:snow_block
fill 161 79 276 161 82 276 minecraft:packed_ice
setblock 161 79 315 minecraft:snow_block
fill 161 79 316 161 82 316 minecraft:packed_ice
fill 162 79 315 162 82 315 minecraft:packed_ice
fill 163 79 314 163 82 314 minecraft:packed_ice
setblock 164 79 277 minecraft:snow_block
setblock 165 79 276 minecraft:snow_block
fill 165 79 277 165 82 277 minecraft:packed_ice
setblock 165 79 316 minecraft:snow_block
fill 166 79 276 166 82 276 minecraft:packed_ice
setblock 166 79 315 minecraft:snow_block
fill 166 79 316 166 82 316 minecraft:packed_ice
setblock 167 79 314 minecraft:snow_block
fill 167 79 315 167 82 315 minecraft:packed_ice
setblock 168 79 313 minecraft:snow_block
fill 168 79 314 168 82 314 minecraft:packed_ice
setblock 169 79 277 minecraft:snow_block
setblock 169 79 313 minecraft:packed_ice
setblock 170 79 276 minecraft:snow_block
setblock 170 79 316 minecraft:snow_block
fill 171 79 276 171 82 276 minecraft:packed_ice
setblock 171 79 315 minecraft:snow_block
fill 171 79 316 171 82 316 minecraft:packed_ice
setblock 172 79 314 minecraft:snow_block
fill 172 79 315 172 82 315 minecraft:packed_ice
fill 173 79 275 173 93 275 minecraft:packed_ice
setblock 173 79 314 minecraft:packed_ice
setblock 175 79 316 minecraft:snow_block
fill 176 79 316 176 80 316 minecraft:packed_ice
fill 177 79 286 178 81 286 minecraft:blue_ice
fill 178 79 285 178 80 285 minecraft:blue_ice
fill 178 79 287 178 80 287 minecraft:blue_ice
setblock 181 79 295 minecraft:snow_block
fill 181 79 296 181 82 296 minecraft:packed_ice
setblock 182 79 288 minecraft:blue_ice
setblock 182 79 289 minecraft:snow_block
fill 182 79 290 182 82 290 minecraft:packed_ice
setblock 182 79 294 minecraft:snow_block
fill 182 79 295 182 82 295 minecraft:packed_ice
setblock 182 79 299 minecraft:snow_block
fill 182 79 300 182 82 300 minecraft:packed_ice
setblock 182 79 314 minecraft:snow_block
fill 182 79 315 182 82 315 minecraft:packed_ice
setblock 183 79 286 minecraft:light_blue_concrete
fill 183 79 309 183 91 309 minecraft:packed_ice
fill 141 80 276 143 80 276 minecraft:packed_ice
setblock 141 80 279 minecraft:light_blue_concrete
fill 141 80 280 141 93 280 minecraft:packed_ice
setblock 142 80 277 minecraft:packed_ice
setblock 142 80 278 minecraft:snow_block
fill 142 80 279 142 83 279 minecraft:packed_ice
setblock 142 80 288 minecraft:snow_block
fill 142 80 289 142 83 289 minecraft:packed_ice
setblock 142 80 293 minecraft:snow_block
fill 142 80 294 142 83 294 minecraft:packed_ice
setblock 142 80 298 minecraft:snow_block
fill 142 80 299 142 82 300 minecraft:packed_ice
fill 142 80 316 142 81 316 minecraft:packed_ice
fill 143 80 288 143 83 288 minecraft:packed_ice
setblock 143 80 292 minecraft:snow_block
fill 143 80 293 143 83 293 minecraft:packed_ice
setblock 143 80 297 minecraft:snow_block
fill 143 80 298 143 83 298 minecraft:packed_ice
setblock 144 80 276 minecraft:snow_block
fill 144 80 277 144 83 277 minecraft:packed_ice
setblock 144 80 278 minecraft:light[level=15]
setblock 144 80 286 minecraft:light[level=15]
setblock 144 80 291 minecraft:snow_block
fill 144 80 292 144 83 292 minecraft:packed_ice
setblock 144 80 296 minecraft:snow_block
setblock 144 80 302 minecraft:light[level=15]
setblock 144 80 310 minecraft:light[level=15]
setblock 144 80 316 minecraft:snow_block
fill 145 80 276 145 83 276 minecraft:packed_ice
setblock 145 80 315 minecraft:snow_block
fill 145 80 316 145 83 316 minecraft:packed_ice
fill 146 80 315 146 83 315 minecraft:packed_ice
setblock 147 80 278 minecraft:snow_block
setblock 148 80 277 minecraft:snow_block
fill 148 80 278 149 82 278 minecraft:packed_ice
setblock 149 80 276 minecraft:snow_block
fill 149 80 277 149 83 277 minecraft:packed_ice
setblock 149 80 316 minecraft:snow_block
fill 150 80 276 150 83 276 minecraft:packed_ice
setblock 150 80 315 minecraft:snow_block
fill 150 80 316 153 80 316 minecraft:packed_ice
fill 151 80 315 151 81 315 minecraft:packed_ice
setblock 152 80 278 minecraft:light[level=15]
setblock 152 80 286 minecraft:light[level=15]
setblock 152 80 294 minecraft:light[level=15]
setblock 152 80 302 minecraft:light[level=15]
setblock 152 80 310 minecraft:light[level=15]
setblock 152 80 317 minecraft:light_blue_concrete
setblock 153 80 277 minecraft:snow_block
setblock 154 80 276 minecraft:snow_block
fill 154 80 277 154 83 277 minecraft:packed_ice
setblock 154 80 316 minecraft:snow_block
fill 155 80 276 158 80 276 minecraft:packed_ice
fill 155 80 316 155 83 316 minecraft:packed_ice
fill 158 80 317 158 89 317 minecraft:packed_ice
setblock 159 80 276 minecraft:snow_block
setblock 159 80 316 minecraft:snow_block
fill 160 80 276 160 83 276 minecraft:packed_ice
setblock 160 80 278 minecraft:light[level=15]
setblock 160 80 286 minecraft:light[level=15]
setblock 160 80 294 minecraft:light[level=15]
setblock 160 80 302 minecraft:light[level=15]
setblock 160 80 310 minecraft:light[level=15]
setblock 160 80 315 minecraft:snow_block
fill 160 80 316 160 83 316 minecraft:packed_ice
fill 161 80 315 161 83 315 minecraft:packed_ice
setblock 163 80 277 minecraft:snow_block
setblock 164 80 276 minecraft:snow_block
fill 164 80 277 164 83 277 minecraft:packed_ice
setblock 164 80 316 minecraft:snow_block
fill 165 80 276 165 83 276 minecraft:packed_ice
setblock 165 80 315 minecraft:snow_block
fill 165 80 316 165 83 316 minecraft:packed_ice
setblock 166 80 314 minecraft:snow_block
fill 166 80 315 166 83 315 minecraft:packed_ice
setblock 167 80 275 minecraft:white_concrete
fill 167 80 314 167 83 314 minecraft:packed_ice
setblock 168 80 277 minecraft:snow_block
setblock 168 80 278 minecraft:light[level=15]
setblock 168 80 286 minecraft:light[level=15]
setblock 168 80 294 minecraft:light[level=15]
setblock 168 80 302 minecraft:light[level=15]
setblock 168 80 310 minecraft:light[level=15]
setblock 169 80 276 minecraft:snow_block
fill 169 80 277 169 83 277 minecraft:packed_ice
setblock 169 80 316 minecraft:snow_block
fill 170 80 276 170 83 276 minecraft:packed_ice
setblock 170 80 315 minecraft:snow_block
fill 170 80 316 170 83 316 minecraft:packed_ice
setblock 171 80 314 minecraft:snow_block
fill 171 80 315 171 83 315 minecraft:packed_ice
setblock 174 80 316 minecraft:snow_block
fill 175 80 316 175 82 316 minecraft:packed_ice
setblock 176 80 278 minecraft:light[level=15]
fill 176 80 286 176 81 286 minecraft:blue_ice
setblock 176 80 294 minecraft:light[level=15]
setblock 176 80 302 minecraft:light[level=15]
setblock 176 80 310 minecraft:light[level=15]
setblock 177 80 285 minecraft:blue_ice
setblock 177 80 287 minecraft:blue_ice
fill 177 80 317 181 86 317 minecraft:packed_ice
setblock 181 80 294 minecraft:snow_block
fill 181 80 295 181 83 295 minecraft:packed_ice
setblock 181 80 298 minecraft:packed_ice
fill 182 80 289 182 83 289 minecraft:packed_ice
setblock 182 80 293 minecraft:snow_block
fill 182 80 294 182 83 294 minecraft:packed_ice
setblock 182 80 298 minecraft:snow_block
fill 182 80 299 182 83 299 minecraft:packed_ice
setblock 182 80 302 minecraft:packed_ice
setblock 182 80 313 minecraft:snow_block
fill 182 80 314 182 83 314 minecraft:packed_ice
setblock 182 80 317 minecraft:white_concrete
fill 183 80 286 183 93 286 minecraft:packed_ice
fill 183 80 317 183 93 317 minecraft:packed_ice
fill 141 81 276 142 81 276 minecraft:packed_ice
fill 141 81 279 141 91 279 minecraft:packed_ice
setblock 142 81 277 minecraft:snow_block
fill 142 81 278 143 83 278 minecraft:packed_ice
fill 142 81 280 142 81 281 minecraft:packed_ice
setblock 142 81 282 minecraft:snow_block
fill 142 81 285 142 82 285 minecraft:packed_ice
setblock 142 81 287 minecraft:snow_block
fill 142 81 288 142 84 288 minecraft:packed_ice
setblock 142 81 292 minecraft:snow_block
fill 142 81 293 142 84 293 minecraft:packed_ice
setblock 142 81 297 minecraft:snow_block
fill 142 81 298 142 84 298 minecraft:packed_ice
setblock 142 81 301 minecraft:packed_ice
fill 142 81 315 142 82 315 minecraft:packed_ice
setblock 143 81 276 minecraft:snow_block
fill 143 81 277 143 84 277 minecraft:packed_ice
setblock 143 81 291 minecraft:snow_block
fill 143 81 292 143 84 292 minecraft:packed_ice
setblock 143 81 296 minecraft:snow_block
fill 143 81 297 143 84 297 minecraft:packed_ice
fill 143 81 299 143 82 299 minecraft:packed_ice
setblock 143 81 316 minecraft:snow_block
fill 144 81 276 144 84 276 minecraft:packed_ice
setblock 144 81 291 minecraft:packed_ice
setblock 144 81 295 minecraft:snow_block
fill 144 81 296 144 84 296 minecraft:packed_ice
fill 144 81 316 144 84 316 minecraft:packed_ice
fill 145 81 315 145 84 315 minecraft:packed_ice
setblock 146 81 278 minecraft:snow_block
setblock 147 81 277 minecraft:snow_block
fill 147 81 278 147 84 278 minecraft:packed_ice
setblock 148 81 276 minecraft:snow_block
fill 148 81 277 148 84 277 minecraft:packed_ice
setblock 148 81 316 minecraft:snow_block
fill 149 81 276 149 84 276 minecraft:packed_ice
setblock 149 81 315 minecraft:snow_block
fill 149 81 316 152 81 316 minecraft:packed_ice
fill 150 81 315 150 83 315 minecraft:packed_ice
setblock 152 81 277 minecraft:snow_block
fill 152 81 317 152 93 317 minecraft:packed_ice
setblock 153 81 276 minecraft:snow_block
fill 153 81 277 153 84 277 minecraft:packed_ice
setblock 153 81 316 minecraft:snow_block
fill 154 81 276 157 81 276 minecraft:packed_ice
fill 154 81 316 154 84 316 minecraft:packed_ice
fill 157 81 280 157 82 280 minecraft:packed_ice
setblock 158 81 276 minecraft:snow_block
fill 158 81 279 158 82 279 minecraft:packed_ice
fill 158 81 281 158 82 281 minecraft:packed_ice
setblock 158 81 316 minecraft:snow_block
fill 159 81 276 159 84 276 minecraft:packed_ice
fill 159 81 280 159 82 280 minecraft:packed_ice
fill 159 81 286 159 90 286 minecraft:packed_ice
fill 159 81 316 159 84 316 minecraft:packed_ice
fill 160 81 315 160 84 315 minecraft:packed_ice
setblock 162 81 277 minecraft:snow_block
setblock 163 81 276 minecraft:snow_block
fill 163 81 277 163 84 277 minecraft:packed_ice
setblock 163 81 316 minecraft:snow_block
fill 164 81 276 164 84 276 minecraft:packed_ice
setblock 164 81 315 minecraft:snow_block
fill 164 81 316 164 84 316 minecraft:packed_ice
setblock 165 81 314 minecraft:snow_block
fill 165 81 315 165 84 315 minecraft:packed_ice
fill 166 81 314 166 84 314 minecraft:packed_ice
fill 167 81 275 167 94 275 minecraft:packed_ice
setblock 167 81 277 minecraft:snow_block
setblock 168 81 276 minecraft:snow_block
fill 168 81 277 168 84 277 minecraft:packed_ice
setblock 168 81 316 minecraft:snow_block
fill 169 81 276 169 84 276 minecraft:packed_ice
setblock 169 81 315 minecraft:snow_block
fill 169 81 316 169 84 316 minecraft:packed_ice
setblock 170 81 314 minecraft:snow_block
fill 170 81 315 170 84 315 minecraft:packed_ice
setblock 173 81 316 minecraft:snow_block
fill 174 81 316 174 84 316 minecraft:packed_ice
setblock 179 81 286 minecraft:blue_ice
setblock 181 81 293 minecraft:snow_block
fill 181 81 294 181 84 294 minecraft:packed_ice
setblock 181 81 298 minecraft:snow_block
fill 181 81 299 181 84 299 minecraft:packed_ice
setblock 182 81 292 minecraft:snow_block
fill 182 81 293 182 84 293 minecraft:packed_ice
setblock 182 81 297 minecraft:snow_block
fill 182 81 298 182 84 298 minecraft:packed_ice
setblock 182 81 302 minecraft:snow_block
fill 182 81 303 182 84 303 minecraft:packed_ice
fill 182 81 317 182 94 317 minecraft:packed_ice
fill 141 82 276 141 93 276 minecraft:packed_ice
fill 141 82 308 141 89 308 minecraft:packed_ice
setblock 141 82 309 minecraft:light_blue_concrete
fill 141 82 310 141 93 310 minecraft:packed_ice
setblock 142 82 276 minecraft:snow_block
fill 142 82 277 142 85 277 minecraft:packed_ice
setblock 142 82 280 minecraft:packed_ice
setblock 142 82 281 minecraft:snow_block
fill 142 82 282 142 83 284 minecraft:packed_ice
setblock 142 82 286 minecraft:snow_block
fill 142 82 287 142 85 287 minecraft:packed_ice
setblock 142 82 291 minecraft:snow_block
fill 142 82 292 142 85 292 minecraft:packed_ice
setblock 142 82 296 minecraft:snow_block
fill 142 82 297 142 85 297 minecraft:packed_ice
setblock 142 82 301 minecraft:snow_block
setblock 142 82 316 minecraft:snow_block
setblock 142 82 317 minecraft:light_blue_concrete
fill 143 82 276 143 85 276 minecraft:packed_ice
setblock 143 82 279 minecraft:packed_ice
setblock 143 82 280 minecraft:snow_block
fill 143 82 281 143 85 281 minecraft:packed_ice
setblock 143 82 290 minecraft:snow_block
fill 143 82 291 143 85 291 minecraft:packed_ice
setblock 143 82 295 minecraft:snow_block
fill 143 82 296 143 85 296 minecraft:packed_ice
setblock 143 82 300 minecraft:snow_block
fill 143 82 316 143 85 316 minecraft:packed_ice
setblock 144 82 278 minecraft:packed_ice
setblock 144 82 294 minecraft:snow_block
fill 144 82 295 144 85 295 minecraft:packed_ice
fill 144 82 297 144 83 297 minecraft:packed_ice
setblock 145 82 278 minecraft:snow_block
setblock 146 82 277 minecraft:snow_block
fill 146 82 278 146 85 278 minecraft:packed_ice
setblock 147 82 276 minecraft:snow_block
fill 147 82 277 147 85 277 minecraft:packed_ice
setblock 147 82 316 minecraft:snow_block
fill 148 82 276 148 85 276 minecraft:packed_ice
setblock 148 82 315 minecraft:snow_block
fill 148 82 316 151 82 316 minecraft:packed_ice
fill 149 82 315 149 85 315 minecraft:packed_ice
setblock 150 82 278 minecraft:snow_block
setblock 151 82 277 minecraft:snow_block
setblock 152 82 276 minecraft:snow_block
fill 152 82 277 152 85 277 minecraft:packed_ice
setblock 152 82 316 minecraft:snow_block
fill 153 82 276 156 82 276 minecraft:packed_ice
fill 153 82 316 153 85 316 minecraft:packed_ice
setblock 157 82 276 minecraft:snow_block
setblock 157 82 316 minecraft:snow_block
fill 158 82 276 158 85 276 minecraft:packed_ice
fill 158 82 285 158 90 286 minecraft:packed_ice
fill 158 82 316 158 85 316 minecraft:packed_ice
fill 159 82 285 159 90 285 minecraft:packed_ice
fill 159 82 315 159 85 315 minecraft:packed_ice
setblock 160 82 277 minecraft:packed_ice
setblock 161 82 277 minecraft:snow_block
setblock 162 82 276 minecraft:snow_block
fill 162 82 277 162 85 277 minecraft:packed_ice
setblock 162 82 316 minecraft:snow_block
fill 163 82 276 163 85 276 minecraft:packed_ice
setblock 163 82 315 minecraft:snow_block
fill 163 82 316 163 85 316 minecraft:packed_ice
setblock 164 82 314 minecraft:snow_block
fill 164 82 315 164 85 315 minecraft:packed_ice
fill 165 82 314 165 85 314 minecraft:packed_ice
setblock 166 82 277 minecraft:snow_block
setblock 167 82 276 minecraft:snow_block
fill 167 82 277 167 85 277 minecraft:packed_ice
setblock 167 82 316 minecraft:snow_block
fill 168 82 276 168 85 276 minecraft:packed_ice
setblock 168 82 315 minecraft:snow_block
fill 168 82 316 168 85 316 minecraft:packed_ice
setblock 169 82 314 minecraft:snow_block
fill 169 82 315 169 85 315 minecraft:packed_ice
setblock 172 82 276 minecraft:snow_block
setblock 172 82 316 minecraft:snow_block
fill 173 82 316 173 85 316 minecraft:packed_ice
setblock 181 82 292 minecraft:snow_block
fill 181 82 293 181 85 293 minecraft:packed_ice
setblock 181 82 297 minecraft:snow_block
fill 181 82 298 181 85 298 minecraft:packed_ice
fill 181 82 300 181 83 300 minecraft:packed_ice
setblock 181 82 316 minecraft:packed_ice
setblock 182 82 276 minecraft:snow_block
fill 182 82 277 182 85 277 minecraft:packed_ice
setblock 182 82 291 minecraft:snow_block
fill 182 82 292 182 85 292 minecraft:packed_ice
setblock 182 82 296 minecraft:snow_block
fill 182 82 297 182 85 297 minecraft:packed_ice
setblock 182 82 301 minecraft:snow_block
fill 182 82 302 182 85 302 minecraft:packed_ice
fill 182 82 304 182 83 304 minecraft:packed_ice
setblock 182 82 316 minecraft:snow_block
setblock 183 82 314 minecraft:light_blue_concrete
fill 141 83 290 141 89 290 minecraft:packed_ice
fill 141 83 309 141 93 309 minecraft:packed_ice
fill 142 83 276 142 86 276 minecraft:packed_ice
setblock 142 83 280 minecraft:snow_block
fill 142 83 281 142 86 281 minecraft:packed_ice
setblock 142 83 285 minecraft:snow_block
fill 142 83 286 143 85 286 minecraft:packed_ice
setblock 142 83 290 minecraft:snow_block
fill 142 83 291 142 86 291 minecraft:packed_ice
setblock 142 83 295 minecraft:snow_block
fill 142 83 296 142 86 296 minecraft:packed_ice
setblock 142 83 299 minecraft:packed_ice
setblock 142 83 300 minecraft:snow_block
fill 142 83 301 142 85 302 minecraft:packed_ice
setblock 142 83 314 minecraft:packed_ice
setblock 142 83 315 minecraft:snow_block
fill 142 83 316 142 86 317 minecraft:packed_ice
setblock 143 83 279 minecraft:snow_block
fill 143 83 280 144 85 280 minecraft:packed_ice
fill 143 83 282 143 83 283 minecraft:packed_ice
setblock 143 83 284 minecraft:snow_block
fill 143 83 285 143 86 285 minecraft:packed_ice
fill 143 83 287 143 84 287 minecraft:packed_ice
setblock 143 83 289 minecraft:snow_block
fill 143 83 290 143 86 290 minecraft:packed_ice
setblock 143 83 294 minecraft:snow_block
fill 143 83 295 143 86 295 minecraft:packed_ice
setblock 143 83 299 minecraft:snow_block
fill 143 83 300 143 86 300 minecraft:packed_ice
setblock 144 83 278 minecraft:snow_block
fill 144 83 279 144 86 279 minecraft:packed_ice
setblock 144 83 293 minecraft:snow_block
fill 144 83 294 144 86 294 minecraft:packed_ice
setblock 144 83 298 minecraft:snow_block
fill 144 83 315 144 85 315 minecraft:packed_ice
setblock 145 83 277 minecraft:snow_block
fill 145 83 278 145 86 278 minecraft:packed_ice
setblock 146 83 276 minecraft:snow_block
fill 146 83 277 146 86 277 minecraft:packed_ice
setblock 146 83 316 minecraft:snow_block
fill 147 83 276 147 86 276 minecraft:packed_ice
setblock 147 83 315 minecraft:snow_block
fill 147 83 316 150 83 316 minecraft:packed_ice
setblock 148 83 278 minecraft:packed_ice
fill 148 83 315 148 86 315 minecraft:packed_ice
setblock 149 83 278 minecraft:snow_block
setblock 150 83 277 minecraft:snow_block
fill 150 83 278 151 85 278 minecraft:packed_ice
setblock 151 83 276 minecraft:snow_block
fill 151 83 277 151 86 277 minecraft:packed_ice
setblock 151 83 316 minecraft:snow_block
fill 152 83 276 155 83 276 minecraft:packed_ice
fill 152 83 316 152 86 316 minecraft:packed_ice
setblock 155 83 277 minecraft:snow_block
setblock 156 83 276 minecraft:snow_block
fill 156 83 277 159 83 277 minecraft:packed_ice
setblock 156 83 316 minecraft:snow_block
fill 157 83 276 157 86 276 minecraft:packed_ice
fill 157 83 316 157 86 316 minecraft:packed_ice
fill 158 83 287 159 90 287 minecraft:packed_ice
setblock 160 83 277 minecraft:snow_block
setblock 161 83 276 minecraft:snow_block
fill 161 83 277 161 86 277 minecraft:packed_ice
setblock 161 83 316 minecraft:snow_block
fill 162 83 276 162 86 276 minecraft:packed_ice
setblock 162 83 314 minecraft:packed_ice
setblock 162 83 315 minecraft:snow_block
fill 162 83 316 162 86 316 minecraft:packed_ice
setblock 163 83 314 minecraft:snow_block
fill 163 83 315 163 86 315 minecraft:packed_ice
fill 164 83 314 164 86 314 minecraft:packed_ice
setblock 165 83 277 minecraft:snow_block
setblock 166 83 276 minecraft:snow_block
fill 166 83 277 166 86 277 minecraft:packed_ice
setblock 166 83 316 minecraft:snow_block
fill 167 83 276 167 86 276 minecraft:packed_ice
setblock 167 83 315 minecraft:snow_block
fill 167 83 316 167 86 316 minecraft:packed_ice
setblock 168 83 314 minecraft:snow_block
fill 168 83 315 168 86 315 minecraft:packed_ice
setblock 169 83 314 minecraft:packed_ice
setblock 169 83 317 minecraft:light_blue_concrete
setblock 171 83 276 minecraft:snow_block
setblock 171 83 316 minecraft:snow_block
fill 172 83 276 172 86 276 minecraft:packed_ice
fill 172 83 316 172 86 316 minecraft:packed_ice
setblock 180 83 296 minecraft:packed_ice
setblock 180 83 297 minecraft:snow_block
fill 180 83 298 180 86 298 minecraft:packed_ice
setblock 181 83 276 minecraft:snow_block
fill 181 83 292 181 86 292 minecraft:packed_ice
setblock 181 83 296 minecraft:snow_block
fill 181 83 297 181 86 297 minecraft:packed_ice
setblock 181 83 301 minecraft:snow_block
fill 181 83 302 181 86 302 minecraft:packed_ice
setblock 181 83 316 minecraft:snow_block
fill 182 83 276 182 86 276 minecraft:packed_ice
fill 182 83 278 182 83 279 minecraft:packed_ice
setblock 182 83 280 minecraft:snow_block
fill 182 83 281 182 86 281 minecraft:packed_ice
fill 182 83 288 182 84 288 minecraft:packed_ice
setblock 182 83 290 minecraft:snow_block
fill 182 83 291 182 86 291 minecraft:packed_ice
setblock 182 83 295 minecraft:snow_block
fill 182 83 296 182 86 296 minecraft:packed_ice
setblock 182 83 300 minecraft:snow_block
fill 182 83 301 182 86 301 minecraft:packed_ice
setblock 182 83 305 minecraft:snow_block
setblock 182 83 315 minecraft:snow_block
fill 182 83 316 182 86 316 minecraft:packed_ice
fill 183 83 314 183 91 314 minecraft:packed_ice
setblock 142 84 278 minecraft:packed_ice
setblock 142 84 279 minecraft:snow_block
fill 142 84 280 142 87 280 minecraft:packed_ice
fill 142 84 282 142 84 283 minecraft:packed_ice
setblock 142 84 284 minecraft:snow_block
fill 142 84 285 142 87 285 minecraft:packed_ice
setblock 142 84 289 minecraft:snow_block
fill 142 84 290 142 87 290 minecraft:packed_ice
setblock 142 84 294 minecraft:snow_block
fill 142 84 295 142 87 295 minecraft:packed_ice
setblock 142 84 299 minecraft:snow_block
fill 142 84 300 142 87 300 minecraft:packed_ice
setblock 142 84 303 minecraft:packed_ice
setblock 142 84 304 minecraft:snow_block
setblock 142 84 314 minecraft:snow_block
fill 142 84 315 142 87 315 minecraft:packed_ice
setblock 143 84 278 minecraft:snow_block
fill 143 84 279 143 87 279 minecraft:packed_ice
setblock 143 84 282 minecraft:packed_ice
setblock 143 84 283 minecraft:snow_block
fill 143 84 284 143 87 284 minecraft:packed_ice
setblock 143 84 288 minecraft:snow_block
fill 143 84 289 143 87 289 minecraft:packed_ice
setblock 143 84 293 minecraft:snow_block
fill 143 84 294 143 87 294 minecraft:packed_ice
setblock 143 84 298 minecraft:snow_block
fill 143 84 299 144 86 299 minecraft:packed_ice
fill 143 84 301 143 84 302 minecraft:packed_ice
setblock 144 84 277 minecraft:snow_block
fill 144 84 278 144 87 278 minecraft:packed_ice
setblock 144 84 281 minecraft:packed_ice
setblock 144 84 282 minecraft:snow_block
fill 144 84 283 144 87 283 minecraft:packed_ice
setblock 144 84 285 minecraft:light[level=12]
setblock 144 84 292 minecraft:snow_block
fill 144 84 293 144 87 293 minecraft:packed_ice
setblock 144 84 297 minecraft:snow_block
fill 144 84 298 144 87 298 minecraft:packed_ice
setblock 144 84 306 minecraft:light[level=12]
setblock 144 84 313 minecraft:light[level=12]
setblock 145 84 276 minecraft:snow_block
fill 145 84 277 145 87 277 minecraft:packed_ice
fill 145 84 279 146 84 279 minecraft:packed_ice
setblock 145 84 316 minecraft:snow_block
fill 146 84 276 146 87 276 minecraft:packed_ice
setblock 146 84 315 minecraft:snow_block
fill 146 84 316 149 84 316 minecraft:packed_ice
setblock 147 84 279 minecraft:snow_block
fill 147 84 315 147 87 315 minecraft:packed_ice
setblock 148 84 278 minecraft:snow_block
setblock 149 84 277 minecraft:snow_block
fill 149 84 278 149 87 278 minecraft:packed_ice
setblock 150 84 276 minecraft:snow_block
fill 150 84 277 150 87 277 minecraft:packed_ice
setblock 150 84 316 minecraft:snow_block
fill 151 84 276 154 84 276 minecraft:packed_ice
setblock 151 84 285 minecraft:light[level=12]
setblock 151 84 292 minecraft:light[level=12]
setblock 151 84 299 minecraft:light[level=12]
setblock 151 84 306 minecraft:light[level=12]
setblock 151 84 313 minecraft:light[level=12]
fill 151 84 316 151 87 316 minecraft:packed_ice
setblock 154 84 277 minecraft:snow_block
setblock 155 84 276 minecraft:snow_block
fill 155 84 277 158 84 277 minecraft:packed_ice
setblock 155 84 316 minecraft:snow_block
fill 156 84 276 156 87 276 minecraft:packed_ice
fill 156 84 316 156 87 316 minecraft:packed_ice
fill 157 84 285 157 90 286 minecraft:packed_ice
setblock 158 84 278 minecraft:light[level=12]
fill 158 84 284 159 90 284 minecraft:packed_ice
setblock 158 84 292 minecraft:light[level=12]
setblock 158 84 299 minecraft:light[level=12]
setblock 158 84 306 minecraft:light[level=12]
setblock 158 84 313 minecraft:light[level=12]
fill 158 84 315 158 86 315 minecraft:packed_ice
setblock 159 84 277 minecraft:snow_block
setblock 160 84 276 minecraft:snow_block
fill 160 84 277 160 87 277 minecraft:packed_ice
fill 160 84 285 160 90 286 minecraft:packed_ice
setblock 160 84 316 minecraft:snow_block
setblock 161 84 275 minecraft:white_concrete
fill 161 84 276 161 87 276 minecraft:packed_ice
setblock 161 84 315 minecraft:snow_block
fill 161 84 316 161 87 316 minecraft:packed_ice
setblock 162 84 278 minecraft:packed_ice
setblock 162 84 314 minecraft:snow_block
fill 162 84 315 162 87 315 minecraft:packed_ice
setblock 163 84 278 minecraft:snow_block
fill 163 84 314 163 87 314 minecraft:packed_ice
setblock 164 84 277 minecraft:snow_block
fill 164 84 278 165 86 278 minecraft:packed_ice
setblock 165 84 276 minecraft:snow_block
fill 165 84 277 165 87 277 minecraft:packed_ice
setblock 165 84 285 minecraft:light[level=12]
setblock 165 84 292 minecraft:light[level=12]
setblock 165 84 299 minecraft:light[level=12]
setblock 165 84 306 minecraft:light[level=12]
setblock 165 84 313 minecraft:light[level=12]
setblock 165 84 316 minecraft:snow_block
fill 166 84 276 166 87 276 minecraft:packed_ice
setblock 166 84 315 minecraft:snow_block
fill 166 84 316 166 87 316 minecraft:packed_ice
fill 167 84 278 167 90 278 minecraft:packed_ice
setblock 167 84 314 minecraft:snow_block
fill 167 84 315 167 87 315 minecraft:packed_ice
fill 168 84 314 168 85 314 minecraft:packed_ice
setblock 169 84 277 minecraft:snow_block
fill 169 84 317 169 93 317 minecraft:packed_ice
setblock 170 84 276 minecraft:snow_block
setblock 170 84 316 minecraft:snow_block
fill 171 84 276 171 87 276 minecraft:packed_ice
setblock 171 84 315 minecraft:snow_block
fill 171 84 316 171 87 316 minecraft:packed_ice
setblock 172 84 278 minecraft:light[level=12]
setblock 172 84 285 minecraft:light[level=12]
setblock 172 84 292 minecraft:light[level=12]
setblock 172 84 299 minecraft:light[level=12]
setblock 172 84 306 minecraft:light[level=12]
setblock 172 84 313 minecraft:light[level=12]
setblock 179 84 276 minecraft:packed_ice
setblock 179 84 278 minecraft:light[level=12]
setblock 179 84 285 minecraft:light[level=12]
setblock 179 84 292 minecraft:light[level=12]
fill 179 84 293 179 90 293 minecraft:packed_ice
setblock 179 84 299 minecraft:light[level=12]
setblock 179 84 306 minecraft:light[level=12]
setblock 179 84 313 minecraft:light[level=12]
setblock 180 84 276 minecraft:snow_block
setblock 180 84 295 minecraft:packed_ice
setblock 180 84 296 minecraft:snow_block
fill 180 84 297 180 87 297 minecraft:packed_ice
fill 180 84 299 180 84 300 minecraft:packed_ice
setblock 180 84 316 minecraft:snow_block
fill 181 84 276 181 87 276 minecraft:packed_ice
fill 181 84 291 181 87 291 minecraft:packed_ice
setblock 181 84 295 minecraft:snow_block
fill 181 84 296 181 87 296 minecraft:packed_ice
setblock 181 84 300 minecraft:snow_block
fill 181 84 301 181 87 301 minecraft:packed_ice
fill 181 84 303 181 85 303 minecraft:packed_ice
fill 181 84 316 181 87 316 minecraft:packed_ice
setblock 182 84 278 minecraft:packed_ice
setblock 182 84 279 minecraft:snow_block
fill 182 84 280 182 87 280 minecraft:packed_ice
fill 182 84 282 182 84 283 minecraft:packed_ice
setblock 182 84 284 minecraft:snow_block
fill 182 84 285 182 85 287 minecraft:packed_ice
setblock 182 84 289 minecraft:snow_block
fill 182 84 290 182 87 290 minecraft:packed_ice
setblock 182 84 294 minecraft:snow_block
fill 182 84 295 182 87 295 minecraft:packed_ice
setblock 182 84 299 minecraft:snow_block
fill 182 84 300 182 87 300 minecraft:packed_ice
setblock 182 84 304 minecraft:snow_block
fill 182 84 305 182 86 306 minecraft:packed_ice
setblock 182 84 314 minecraft:snow_block
fill 182 84 315 182 87 315 minecraft:packed_ice
setblock 141 85 289 minecraft:light_blue_concrete
setblock 142 85 278 minecraft:snow_block
fill 142 85 279 142 88 279 minecraft:packed_ice
setblock 142 85 282 minecraft:packed_ice
setblock 142 85 283 minecraft:snow_block
fill 142 85 284 142 88 284 minecraft:packed_ice
setblock 142 85 288 minecraft:snow_block
fill 142 85 289 142 88 289 minecraft:packed_ice
setblock 142 85 293 minecraft:snow_block
fill 142 85 294 142 88 294 minecraft:packed_ice
setblock 142 85 298 minecraft:snow_block
fill 142 85 299 142 88 299 minecraft:packed_ice
setblock 142 85 303 minecraft:snow_block
fill 142 85 304 142 87 305 minecraft:packed_ice
setblock 142 85 313 minecraft:snow_block
fill 142 85 314 142 88 314 minecraft:packed_ice
setblock 143 85 277 minecraft:snow_block
fill 143 85 278 143 88 278 minecraft:packed_ice
setblock 143 85 282 minecraft:snow_block
fill 143 85 283 143 88 283 minecraft:packed_ice
setblock 143 85 287 minecraft:snow_block
fill 143 85 288 143 88 288 minecraft:packed_ice
setblock 143 85 292 minecraft:snow_block
fill 143 85 293 143 88 293 minecraft:packed_ice
setblock 143 85 297 minecraft:snow_block
fill 143 85 298 143 88 298 minecraft:packed_ice
setblock 143 85 301 minecraft:packed_ice
setblock 143 85 302 minecraft:snow_block
fill 143 85 303 143 88 303 minecraft:packed_ice
fill 143 85 315 143 86 315 minecraft:packed_ice
setblock 144 85 276 minecraft:snow_block
fill 144 85 277 144 88 277 minecraft:packed_ice
setblock 144 85 281 minecraft:snow_block
fill 144 85 282 144 88 282 minecraft:packed_ice
fill 144 85 284 144 85 285 minecraft:packed_ice
fill 144 85 292 144 86 292 minecraft:packed_ice
setblock 144 85 296 minecraft:snow_block
fill 144 85 297 144 88 297 minecraft:packed_ice
setblock 144 85 300 minecraft:packed_ice
fill 144 85 305 144 91 305 minecraft:packed_ice
setblock 144 85 316 minecraft:snow_block
fill 145 85 276 145 88 276 minecraft:packed_ice
setblock 145 85 279 minecraft:packed_ice
setblock 145 85 280 minecraft:snow_block
fill 145 85 281 145 88 281 minecraft:packed_ice
setblock 145 85 315 minecraft:snow_block
fill 145 85 316 148 85 316 minecraft:packed_ice
setblock 146 85 279 minecraft:snow_block
fill 146 85 315 146 88 315 minecraft:packed_ice
setblock 147 85 278 minecraft:snow_block
fill 147 85 279 148 87 279 minecraft:packed_ice
setblock 148 85 277 minecraft:snow_block
fill 148 85 278 148 88 278 minecraft:packed_ice
setblock 149 85 276 minecraft:snow_block
fill 149 85 277 149 88 277 minecraft:packed_ice
setblock 149 85 316 minecraft:snow_block
fill 150 85 276 153 85 276 minecraft:packed_ice
fill 150 85 316 150 88 316 minecraft:packed_ice
setblock 152 85 278 minecraft:snow_block
setblock 153 85 277 minecraft:snow_block
setblock 154 85 276 minecraft:snow_block
fill 154 85 277 157 85 277 minecraft:packed_ice
setblock 154 85 316 minecraft:snow_block
fill 155 85 276 155 88 276 minecraft:packed_ice
fill 155 85 316 155 88 316 minecraft:packed_ice
fill 157 85 284 157 90 284 minecraft:packed_ice
fill 157 85 287 157 90 287 minecraft:packed_ice
fill 157 85 315 157 87 315 minecraft:packed_ice
setblock 158 85 277 minecraft:snow_block
fill 158 85 288 159 90 288 minecraft:packed_ice
setblock 159 85 276 minecraft:snow_block
fill 159 85 277 159 88 277 minecraft:packed_ice
setblock 159 85 316 minecraft:snow_block
fill 160 85 276 160 88 276 minecraft:packed_ice
fill 160 85 278 161 85 278 minecraft:packed_ice
fill 160 85 284 160 90 284 minecraft:packed_ice
setblock 160 85 315 minecraft:snow_block
fill 160 85 316 160 88 316 minecraft:packed_ice
fill 161 85 275 161 93 275 minecraft:packed_ice
setblock 161 85 314 minecraft:snow_block
fill 161 85 315 161 88 315 minecraft:packed_ice
setblock 162 85 278 minecraft:snow_block
fill 162 85 314 162 88 314 minecraft:packed_ice
setblock 162 85 317 minecraft:white_concrete
setblock 163 85 277 minecraft:snow_block
fill 163 85 278 163 88 278 minecraft:packed_ice
setblock 164 85 276 minecraft:snow_block
fill 164 85 277 164 88 277 minecraft:packed_ice
setblock 164 85 316 minecraft:snow_block
fill 165 85 276 165 88 276 minecraft:packed_ice
setblock 165 85 315 minecraft:snow_block
fill 165 85 316 165 88 316 minecraft:packed_ice
setblock 166 85 278 minecraft:packed_ice
setblock 166 85 314 minecraft:snow_block
fill 166 85 315 166 88 315 minecraft:packed_ice
fill 167 85 314 167 86 314 minecraft:packed_ice
setblock 168 85 277 minecraft:snow_block
setblock 169 85 276 minecraft:snow_block
fill 169 85 277 169 87 277 minecraft:packed_ice
setblock 169 85 316 minecraft:snow_block
fill 170 85 276 170 88 276 minecraft:packed_ice
setblock 170 85 315 minecraft:snow_block
fill 170 85 316 170 88 316 minecraft:packed_ice
setblock 178 85 276 minecraft:packed_ice
setblock 179 85 276 minecraft:snow_block
setblock 179 85 316 minecraft:snow_block
fill 180 85 276 180 88 276 minecraft:packed_ice
setblock 180 85 294 minecraft:packed_ice
setblock 180 85 295 minecraft:snow_block
fill 180 85 296 180 88 296 minecraft:packed_ice
setblock 180 85 299 minecraft:packed_ice
setblock 180 85 300 minecraft:snow_block
fill 180 85 301 180 88 301 minecraft:packed_ice
fill 180 85 316 180 88 316 minecraft:packed_ice
fill 181 85 277 181 85 278 minecraft:packed_ice
setblock 181 85 279 minecraft:snow_block
fill 181 85 280 181 87 281 minecraft:packed_ice
fill 181 85 290 181 88 290 minecraft:packed_ice
setblock 181 85 294 minecraft:snow_block
fill 181 85 295 181 88 295 minecraft:packed_ice
setblock 181 85 299 minecraft:snow_block
fill 181 85 300 181 88 300 minecraft:packed_ice
setblock 181 85 304 minecraft:snow_block
setblock 182 85 278 minecraft:snow_block
fill 182 85 279 182 88 279 minecraft:packed_ice
setblock 182 85 282 minecraft:packed_ice
setblock 182 85 283 minecraft:snow_block
fill 182 85 284 182 88 284 minecraft:packed_ice
setblock 182 85 288 minecraft:snow_block
fill 182 85 289 182 88 289 minecraft:packed_ice
setblock 182 85 293 minecraft:snow_block
fill 182 85 294 182 88 294 minecraft:packed_ice
setblock 182 85 298 minecraft:snow_block
fill 182 85 299 182 88 299 minecraft:packed_ice
setblock 182 85 303 minecraft:snow_block
fill 182 85 304 182 88 304 minecraft:packed_ice
setblock 182 85 307 minecraft:packed_ice
setblock 182 85 308 minecraft:snow_block
setblock 182 85 313 minecraft:snow_block
fill 182 85 314 182 88 314 minecraft:packed_ice
fill 141 86 289 141 88 289 minecraft:packed_ice
setblock 142 86 277 minecraft:snow_block
fill 142 86 278 142 89 278 minecraft:packed_ice
setblock 142 86 282 minecraft:snow_block
fill 142 86 283 142 89 283 minecraft:packed_ice
setblock 142 86 286 minecraft:packed_ice
setblock 142 86 287 minecraft:snow_block
fill 142 86 288 142 89 288 minecraft:packed_ice
setblock 142 86 292 minecraft:snow_block
fill 142 86 293 142 89 293 minecraft:packed_ice
setblock 142 86 297 minecraft:snow_block
fill 142 86 298 142 89 298 minecraft:packed_ice
setblock 142 86 301 minecraft:packed_ice
setblock 142 86 302 minecraft:snow_block
fill 142 86 303 142 89 303 minecraft:packed_ice
setblock 142 86 306 minecraft:packed_ice
fill 142 86 313 142 89 313 minecraft:packed_ice
setblock 143 86 276 minecraft:snow_block
fill 143 86 277 143 89 277 minecraft:packed_ice
setblock 143 86 280 minecraft:packed_ice
setblock 143 86 281 minecraft:snow_block
fill 143 86 282 143 89 282 minecraft:packed_ice
setblock 143 86 286 minecraft:snow_block
fill 143 86 287 143 89 287 minecraft:packed_ice
setblock 143 86 291 minecraft:snow_block
fill 143 86 292 143 89 292 minecraft:packed_ice
setblock 143 86 296 minecraft:snow_block
fill 143 86 297 143 89 297 minecraft:packed_ice
setblock 143 86 301 minecraft:snow_block
fill 143 86 302 143 89 302 minecraft:packed_ice
fill 143 86 304 143 87 304 minecraft:packed_ice
setblock 143 86 316 minecraft:snow_block
fill 144 86 276 144 89 276 minecraft:packed_ice
setblock 144 86 280 minecraft:snow_block
fill 144 86 281 144 89 281 minecraft:packed_ice
setblock 144 86 284 minecraft:packed_ice
setblock 144 86 285 minecraft:snow_block
fill 144 86 286 144 89 286 minecraft:packed_ice
setblock 144 86 295 minecraft:snow_block
fill 144 86 296 144 88 296 minecraft:packed_ice
setblock 144 86 300 minecraft:snow_block
fill 144 86 301 144 89 301 minecraft:packed_ice
setblock 144 86 315 minecraft:snow_block
fill 144 86 316 147 86 316 minecraft:packed_ice
setblock 145 86 279 minecraft:snow_block
fill 145 86 280 145 89 280 minecraft:packed_ice
fill 145 86 282 145 87 282 minecraft:packed_ice
fill 145 86 315 145 88 315 minecraft:packed_ice
setblock 146 86 278 minecraft:snow_block
fill 146 86 279 146 89 279 minecraft:packed_ice
setblock 147 86 277 minecraft:snow_block
fill 147 86 278 147 89 278 minecraft:packed_ice
setblock 148 86 276 minecraft:snow_block
fill 148 86 277 148 89 277 minecraft:packed_ice
setblock 148 86 316 minecraft:snow_block
fill 149 86 276 152 86 276 minecraft:packed_ice
setblock 149 86 279 minecraft:packed_ice
setblock 149 86 315 minecraft:snow_block
fill 149 86 316 149 89 316 minecraft:packed_ice
setblock 150 86 278 minecraft:packed_ice
setblock 151 86 278 minecraft:snow_block
setblock 152 86 277 minecraft:snow_block
fill 152 86 278 152 88 278 minecraft:packed_ice
setblock 153 86 276 minecraft:snow_block
fill 153 86 277 156 86 277 minecraft:packed_ice
setblock 153 86 316 minecraft:snow_block
fill 154 86 276 154 89 276 minecraft:packed_ice
fill 154 86 316 154 89 316 minecraft:packed_ice
fill 156 86 285 156 90 287 minecraft:packed_ice
setblock 157 86 277 minecraft:snow_block
fill 157 86 288 157 90 288 minecraft:packed_ice
setblock 158 86 276 minecraft:snow_block
fill 158 86 277 158 88 278 minecraft:packed_ice
fill 158 86 283 159 90 283 minecraft:packed_ice
setblock 158 86 316 minecraft:snow_block
fill 159 86 276 159 89 276 minecraft:packed_ice
fill 159 86 278 160 86 278 minecraft:packed_ice
setblock 159 86 315 minecraft:snow_block
fill 159 86 316 159 89 316 minecraft:packed_ice
fill 160 86 315 160 89 315 minecraft:packed_ice
setblock 161 86 278 minecraft:snow_block
fill 161 86 285 161 90 285 minecraft:packed_ice
fill 161 86 314 161 89 314 minecraft:packed_ice
setblock 162 86 277 minecraft:snow_block
fill 162 86 278 162 89 278 minecraft:packed_ice
fill 162 86 317 162 89 317 minecraft:packed_ice
setblock 163 86 276 minecraft:snow_block
fill 163 86 277 163 89 277 minecraft:packed_ice
setblock 163 86 316 minecraft:snow_block
fill 164 86 276 164 89 276 minecraft:packed_ice
setblock 164 86 315 minecraft:snow_block
fill 164 86 316 164 89 316 minecraft:packed_ice
setblock 165 86 314 minecraft:snow_block
fill 165 86 315 165 89 315 minecraft:packed_ice
setblock 166 86 278 minecraft:snow_block
fill 166 86 314 166 87 314 minecraft:packed_ice
setblock 167 86 277 minecraft:snow_block
setblock 168 86 276 minecraft:snow_block
fill 168 86 277 168 88 277 minecraft:packed_ice
setblock 168 86 316 minecraft:snow_block
fill 169 86 276 169 89 276 minecraft:packed_ice
setblock 169 86 315 minecraft:snow_block
fill 169 86 316 169 89 316 minecraft:packed_ice
setblock 170 86 315 minecraft:packed_ice
setblock 173 86 316 minecraft:snow_block
setblock 177 86 276 minecraft:packed_ice
setblock 178 86 276 minecraft:snow_block
fill 179 86 276 179 89 276 minecraft:packed_ice
fill 179 86 316 179 89 316 minecraft:packed_ice
fill 180 86 277 181 86 277 minecraft:packed_ice
setblock 180 86 293 minecraft:packed_ice
setblock 180 86 294 minecraft:snow_block
fill 180 86 295 180 89 295 minecraft:packed_ice
setblock 180 86 299 minecraft:snow_block
fill 180 86 300 180 89 300 minecraft:packed_ice
fill 180 86 302 180 86 303 minecraft:packed_ice
setblock 181 86 278 minecraft:snow_block
fill 181 86 279 181 89 279 minecraft:packed_ice
setblock 181 86 282 minecraft:packed_ice
setblock 181 86 283 minecraft:snow_block
fill 181 86 284 181 88 285 minecraft:packed_ice
setblock 181 86 288 minecraft:snow_block
fill 181 86 289 181 89 289 minecraft:packed_ice
setblock 181 86 293 minecraft:snow_block
fill 181 86 294 181 89 294 minecraft:packed_ice
setblock 181 86 298 minecraft:snow_block
fill 181 86 299 181 89 299 minecraft:packed_ice
setblock 181 86 303 minecraft:snow_block
fill 181 86 304 181 88 305 minecraft:packed_ice
setblock 182 86 277 minecraft:snow_block
fill 182 86 278 182 89 278 minecraft:packed_ice
setblock 182 86 282 minecraft:snow_block
fill 182 86 283 182 89 283 minecraft:packed_ice
fill 182 86 285 182 86 286 minecraft:packed_ice
setblock 182 86 287 minecraft:snow_block
fill 182 86 288 182 89 288 minecraft:packed_ice
setblock 182 86 292 minecraft:snow_block
fill 182 86 293 182 89 293 minecraft:packed_ice
setblock 182 86 297 minecraft:snow_block
fill 182 86 298 182 89 298 minecraft:packed_ice
setblock 182 86 302 minecraft:snow_block
fill 182 86 303 182 89 303 minecraft:packed_ice
setblock 182 86 307 minecraft:snow_block
fill 182 86 308 182 87 310 minecraft:packed_ice
setblock 182 86 312 minecraft:snow_block
fill 182 86 313 182 89 313 minecraft:packed_ice
setblock 141 87 304 minecraft:white_concrete
fill 141 87 305 141 93 306 minecraft:packed_ice
setblock 142 87 276 minecraft:snow_block
fill 142 87 277 142 90 277 minecraft:packed_ice
setblock 142 87 281 minecraft:snow_block
fill 142 87 282 142 90 282 minecraft:packed_ice
setblock 142 87 286 minecraft:snow_block
fill 142 87 287 142 90 287 minecraft:packed_ice
setblock 142 87 291 minecraft:snow_block
fill 142 87 292 142 90 292 minecraft:packed_ice
setblock 142 87 296 minecraft:snow_block
fill 142 87 297 142 90 297 minecraft:packed_ice
setblock 142 87 301 minecraft:snow_block
fill 142 87 302 142 90 302 minecraft:packed_ice
setblock 142 87 306 minecraft:snow_block
fill 142 87 307 142 89 308 minecraft:packed_ice
fill 142 87 312 142 90 312 minecraft:packed_ice
setblock 142 87 316 minecraft:snow_block
fill 142 87 317 142 91 317 minecraft:packed_ice
fill 143 87 276 143 90 276 minecraft:packed_ice
setblock 143 87 280 minecraft:snow_block
fill 143 87 281 143 90 281 minecraft:packed_ice
setblock 143 87 285 minecraft:snow_block
fill 143 87 286 143 90 286 minecraft:packed_ice
setblock 143 87 290 minecraft:snow_block
fill 143 87 291 143 90 291 minecraft:packed_ice
setblock 143 87 295 minecraft:snow_block
fill 143 87 296 143 90 296 minecraft:packed_ice
setblock 143 87 299 minecraft:packed_ice
setblock 143 87 300 minecraft:snow_block
fill 143 87 301 143 90 301 minecraft:packed_ice
setblock 143 87 305 minecraft:snow_block
setblock 143 87 315 minecraft:snow_block
fill 143 87 316 146 87 316 minecraft:packed_ice
setblock 144 87 279 minecraft:snow_block
fill 144 87 280 144 90 280 minecraft:packed_ice
setblock 144 87 284 minecraft:snow_block
fill 144 87 285 144 90 285 minecraft:packed_ice
fill 144 87 287 144 88 287 minecraft:packed_ice
setblock 144 87 294 minecraft:snow_block
fill 144 87 295 144 88 295 minecraft:packed_ice
setblock 144 87 299 minecraft:snow_block
fill 144 87 300 144 89 300 minecraft:packed_ice
fill 144 87 302 144 88 302 minecraft:packed_ice
fill 144 87 315 144 89 315 minecraft:packed_ice
setblock 145 87 278 minecraft:snow_block
fill 145 87 279 145 90 279 minecraft:packed_ice
setblock 145 87 283 minecraft:snow_block
setblock 146 87 277 minecraft:snow_block
fill 146 87 278 146 90 278 minecraft:packed_ice
setblock 147 87 276 minecraft:snow_block
fill 147 87 277 147 90 277 minecraft:packed_ice
setblock 147 87 316 minecraft:snow_block
fill 148 87 276 151 87 276 minecraft:packed_ice
setblock 148 87 315 minecraft:snow_block
fill 148 87 316 148 90 316 minecraft:packed_ice
setblock 149 87 279 minecraft:snow_block
setblock 150 87 278 minecraft:snow_block
setblock 151 87 277 minecraft:snow_block
fill 151 87 278 151 89 278 minecraft:packed_ice
setblock 152 87 276 minecraft:snow_block
fill 152 87 277 155 87 277 minecraft:packed_ice
setblock 152 87 316 minecraft:snow_block
fill 153 87 276 153 90 276 minecraft:packed_ice
setblock 153 87 278 minecraft:packed_ice
fill 153 87 316 153 90 316 minecraft:packed_ice
setblock 156 87 277 minecraft:snow_block
fill 156 87 284 156 90 284 minecraft:packed_ice
setblock 157 87 276 minecraft:snow_block
fill 157 87 277 157 89 278 minecraft:packed_ice
fill 157 87 283 157 90 283 minecraft:packed_ice
setblock 157 87 316 minecraft:snow_block
fill 158 87 276 158 90 276 minecraft:packed_ice
fill 158 87 289 159 90 289 minecraft:packed_ice
setblock 158 87 315 minecraft:snow_block
fill 158 87 316 158 90 316 minecraft:packed_ice
setblock 159 87 278 minecraft:packed_ice
fill 159 87 315 159 90 315 minecraft:packed_ice
setblock 160 87 278 minecraft:snow_block
fill 160 87 283 160 90 283 minecraft:packed_ice
fill 160 87 314 160 89 314 minecraft:packed_ice
setblock 161 87 277 minecraft:snow_block
fill 161 87 278 161 90 278 minecraft:packed_ice
fill 161 87 284 161 90 284 minecraft:packed_ice
setblock 162 87 276 minecraft:snow_block
fill 162 87 277 162 90 277 minecraft:packed_ice
setblock 162 87 316 minecraft:snow_block
fill 163 87 276 163 90 276 minecraft:packed_ice
setblock 163 87 315 minecraft:snow_block
fill 163 87 316 163 90 316 minecraft:packed_ice
setblock 164 87 278 minecraft:packed_ice
setblock 164 87 314 minecraft:snow_block
fill 164 87 315 164 90 315 minecraft:packed_ice
setblock 165 87 278 minecraft:snow_block
fill 165 87 314 165 88 314 minecraft:packed_ice
setblock 166 87 277 minecraft:snow_block
fill 166 87 278 166 90 278 minecraft:packed_ice
setblock 167 87 276 minecraft:snow_block
fill 167 87 277 167 90 277 minecraft:packed_ice
setblock 167 87 316 minecraft:snow_block
fill 168 87 276 168 90 276 minecraft:packed_ice
setblock 168 87 315 minecraft:snow_block
fill 168 87 316 168 90 316 minecraft:packed_ice
setblock 169 87 315 minecraft:packed_ice
setblock 172 87 276 minecraft:snow_block
setblock 172 87 316 minecraft:snow_block
setblock 176 87 276 minecraft:packed_ice
setblock 177 87 276 minecraft:snow_block
fill 177 87 317 177 91 317 minecraft:packed_ice
fill 178 87 276 178 90 276 minecraft:packed_ice
setblock 178 87 317 minecraft:light_blue_concrete
fill 179 87 277 180 87 277 minecraft:packed_ice
setblock 179 87 298 minecraft:packed_ice
setblock 179 87 299 minecraft:snow_block
fill 179 87 300 179 90 300 minecraft:packed_ice
fill 179 87 317 181 87 317 minecraft:packed_ice
setblock 180 87 293 minecraft:snow_block
fill 180 87 294 180 90 294 minecraft:packed_ice
setblock 180 87 298 minecraft:snow_block
fill 180 87 299 180 90 299 minecraft:packed_ice
setblock 180 87 302 minecraft:packed_ice
setblock 180 87 303 minecraft:snow_block
fill 180 87 304 180 90 304 minecraft:packed_ice
setblock 181 87 277 minecraft:snow_block
fill 181 87 278 181 90 278 minecraft:packed_ice
setblock 181 87 282 minecraft:snow_block
fill 181 87 283 181 90 283 minecraft:packed_ice
setblock 181 87 286 minecraft:packed_ice
setblock 181 87 287 minecraft:snow_block
fill 181 87 288 181 90 288 minecraft:packed_ice
setblock 181 87 292 minecraft:snow_block
fill 181 87 293 181 90 293 minecraft:packed_ice
setblock 181 87 297 minecraft:snow_block
fill 181 87 298 181 90 298 minecraft:packed_ice
setblock 181 87 302 minecraft:snow_block
fill 181 87 303 181 90 303 minecraft:packed_ice
setblock 181 87 306 minecraft:packed_ice
setblock 182 87 276 minecraft:snow_block
fill 182 87 277 182 90 277 minecraft:packed_ice
setblock 182 87 281 minecraft:snow_block
fill 182 87 282 182 90 282 minecraft:packed_ice
setblock 182 87 285 minecraft:packed_ice
setblock 182 87 286 minecraft:snow_block
fill 182 87 287 182 90 287 minecraft:packed_ice
setblock 182 87 291 minecraft:snow_block
fill 182 87 292 182 90 292 minecraft:packed_ice
setblock 182 87 296 minecraft:snow_block
fill 182 87 297 182 90 297 minecraft:packed_ice
setblock 182 87 301 minecraft:snow_block
fill 182 87 302 182 90 302 minecraft:packed_ice
setblock 182 87 305 minecraft:packed_ice
setblock 182 87 306 minecraft:snow_block
fill 182 87 307 182 90 307 minecraft:packed_ice
setblock 182 87 311 minecraft:snow_block
fill 182 87 312 182 89 312 minecraft:packed_ice
setblock 182 87 316 minecraft:snow_block
fill 141 88 304 142 88 304 minecraft:packed_ice
setblock 142 88 275 minecraft:light_blue_concrete
fill 142 88 276 142 91 276 minecraft:packed_ice
setblock 142 88 280 minecraft:snow_block
fill 142 88 281 142 91 281 minecraft:packed_ice
setblock 142 88 285 minecraft:snow_block
fill 142 88 286 142 91 286 minecraft:packed_ice
setblock 142 88 290 minecraft:snow_block
fill 142 88 291 142 91 291 minecraft:packed_ice
setblock 142 88 295 minecraft:snow_block
fill 142 88 296 142 91 296 minecraft:packed_ice
setblock 142 88 300 minecraft:snow_block
fill 142 88 301 142 91 301 minecraft:packed_ice
setblock 142 88 305 minecraft:snow_block
fill 142 88 306 143 90 306 minecraft:packed_ice
setblock 142 88 309 minecraft:packed_ice
setblock 142 88 310 minecraft:snow_block
fill 142 88 311 142 91 311 minecraft:packed_ice
setblock 142 88 315 minecraft:snow_block
fill 142 88 316 145 88 316 minecraft:packed_ice
setblock 143 88 279 minecraft:snow_block
fill 143 88 280 143 91 280 minecraft:packed_ice
setblock 143 88 284 minecraft:snow_block
fill 143 88 285 143 91 285 minecraft:packed_ice
setblock 143 88 289 minecraft:snow_block
fill 143 88 290 143 91 290 minecraft:packed_ice
setblock 143 88 294 minecraft:snow_block
fill 143 88 295 143 90 295 minecraft:packed_ice
setblock 143 88 299 minecraft:snow_block
fill 143 88 300 143 91 300 minecraft:packed_ice
setblock 143 88 304 minecraft:snow_block
fill 143 88 305 143 91 305 minecraft:packed_ice
fill 143 88 315 143 89 315 minecraft:packed_ice
setblock 143 88 317 minecraft:white_concrete
setblock 144 88 278 minecraft:snow_block
fill 144 88 279 144 91 279 minecraft:packed_ice
setblock 144 88 283 minecraft:snow_block
fill 144 88 284 145 89 284 minecraft:packed_ice
setblock 144 88 294 minecraft:light[level=15]
setblock 144 88 298 minecraft:snow_block
fill 144 88 299 144 89 299 minecraft:packed_ice
setblock 144 88 310 minecraft:light[level=15]
fill 144 88 317 144 94 317 minecraft:packed_ice
setblock 145 88 277 minecraft:snow_block
fill 145 88 278 145 91 278 minecraft:packed_ice
setblock 145 88 282 minecraft:snow_block
fill 145 88 283 145 91 283 minecraft:packed_ice
setblock 146 88 276 minecraft:snow_block
fill 146 88 277 146 91 277 minecraft:packed_ice
setblock 146 88 316 minecraft:snow_block
fill 147 88 276 150 88 276 minecraft:packed_ice
setblock 147 88 279 minecraft:packed_ice
fill 147 88 316 147 91 316 minecraft:packed_ice
setblock 148 88 279 minecraft:snow_block
setblock 149 88 278 minecraft:snow_block
setblock 150 88 277 minecraft:snow_block
fill 150 88 278 150 89 278 minecraft:packed_ice
setblock 151 88 276 minecraft:snow_block
fill 151 88 277 154 88 277 minecraft:packed_ice
setblock 151 88 316 minecraft:snow_block
fill 152 88 276 152 91 276 minecraft:packed_ice
setblock 152 88 286 minecraft:light[level=15]
setblock 152 88 294 minecraft:light[level=15]
setblock 152 88 302 minecraft:light[level=15]
setblock 152 88 310 minecraft:light[level=15]
fill 152 88 316 152 90 316 minecraft:packed_ice
setblock 155 88 277 minecraft:snow_block
fill 155 88 285 155 90 287 minecraft:packed_ice
setblock 156 88 276 minecraft:snow_block
fill 156 88 277 156 89 278 minecraft:packed_ice
fill 156 88 283 156 90 283 minecraft:packed_ice
fill 156 88 288 156 90 288 minecraft:packed_ice
setblock 156 88 316 minecraft:snow_block
fill 157 88 276 157 91 276 minecraft:packed_ice
fill 157 88 289 157 90 289 minecraft:packed_ice
setblock 157 88 315 minecraft:snow_block
fill 157 88 316 157 91 316 minecraft:packed_ice
fill 158 88 282 159 90 282 minecraft:packed_ice
fill 158 88 315 158 91 315 minecraft:packed_ice
setblock 159 88 278 minecraft:snow_block
setblock 160 88 277 minecraft:snow_block
fill 160 88 278 160 91 278 minecraft:packed_ice
setblock 160 88 294 minecraft:light[level=15]
setblock 160 88 302 minecraft:light[level=15]
setblock 160 88 310 minecraft:light[level=15]
setblock 161 88 276 minecraft:snow_block
fill 161 88 277 161 91 277 minecraft:packed_ice
fill 161 88 283 161 90 283 minecraft:packed_ice
setblock 161 88 316 minecraft:snow_block
fill 162 88 276 162 91 276 minecraft:packed_ice
fill 162 88 284 162 90 285 minecraft:packed_ice
setblock 162 88 315 minecraft:snow_block
fill 162 88 316 162 91 316 minecraft:packed_ice
setblock 163 88 314 minecraft:snow_block
fill 163 88 315 163 91 315 minecraft:packed_ice
setblock 164 88 278 minecraft:snow_block
fill 164 88 314 164 89 314 minecraft:packed_ice
setblock 165 88 277 minecraft:snow_block
fill 165 88 278 165 89 278 minecraft:packed_ice
setblock 166 88 276 minecraft:snow_block
fill 166 88 277 166 90 277 minecraft:packed_ice
setblock 166 88 316 minecraft:snow_block
fill 167 88 276 167 90 276 minecraft:packed_ice
fill 167 88 279 167 90 279 minecraft:packed_ice
setblock 167 88 315 minecraft:snow_block
fill 167 88 316 167 91 316 minecraft:packed_ice
fill 168 88 278 168 90 278 minecraft:packed_ice
setblock 168 88 286 minecraft:light[level=15]
setblock 168 88 294 minecraft:light[level=15]
setblock 168 88 302 minecraft:light[level=15]
setblock 168 88 310 minecraft:light[level=15]
setblock 168 88 315 minecraft:packed_ice
setblock 171 88 276 minecraft:snow_block
setblock 171 88 316 minecraft:snow_block
setblock 176 88 276 minecraft:snow_block
setblock 176 88 278 minecraft:light[level=15]
setblock 176 88 286 minecraft:light[level=15]
setblock 176 88 294 minecraft:light[level=15]
setblock 176 88 302 minecraft:light[level=15]
setblock 176 88 310 minecraft:light[level=15]
fill 177 88 276 177 91 276 minecraft:packed_ice
fill 178 88 277 179 88 277 minecraft:packed_ice
fill 178 88 317 180 93 317 minecraft:packed_ice
setblock 179 88 297 minecraft:packed_ice
setblock 179 88 298 minecraft:snow_block
fill 179 88 299 179 90 299 minecraft:packed_ice
fill 179 88 301 179 88 302 minecraft:packed_ice
setblock 180 88 277 minecraft:snow_block
fill 180 88 278 180 88 281 minecraft:packed_ice
setblock 180 88 282 minecraft:snow_block
fill 180 88 283 180 91 283 minecraft:packed_ice
fill 180 88 293 180 90 293 minecraft:packed_ice
setblock 180 88 297 minecraft:snow_block
fill 180 88 298 180 91 298 minecraft:packed_ice
setblock 180 88 302 minecraft:snow_block
fill 180 88 303 180 91 303 minecraft:packed_ice
fill 180 88 305 180 89 305 minecraft:packed_ice
setblock 181 88 276 minecraft:snow_block
fill 181 88 277 181 91 277 minecraft:packed_ice
setblock 181 88 280 minecraft:packed_ice
setblock 181 88 281 minecraft:snow_block
fill 181 88 282 181 91 282 minecraft:packed_ice
setblock 181 88 286 minecraft:snow_block
fill 181 88 287 181 91 287 minecraft:packed_ice
setblock 181 88 291 minecraft:snow_block
fill 181 88 292 181 91 292 minecraft:packed_ice
setblock 181 88 296 minecraft:snow_block
fill 181 88 297 181 91 297 minecraft:packed_ice
setblock 181 88 301 minecraft:snow_block
fill 181 88 302 181 91 302 minecraft:packed_ice
setblock 181 88 306 minecraft:snow_block
fill 181 88 307 181 91 307 minecraft:packed_ice
setblock 181 88 316 minecraft:snow_block
setblock 181 88 317 minecraft:white_concrete
fill 182 88 276 182 91 276 minecraft:packed_ice
setblock 182 88 280 minecraft:snow_block
fill 182 88 281 182 91 281 minecraft:packed_ice
setblock 182 88 285 minecraft:snow_block
fill 182 88 286 182 91 286 minecraft:packed_ice
setblock 182 88 290 minecraft:snow_block
fill 182 88 291 182 91 291 minecraft:packed_ice
setblock 182 88 295 minecraft:snow_block
fill 182 88 296 182 91 296 minecraft:packed_ice
setblock 182 88 300 minecraft:snow_block
fill 182 88 301 182 91 301 minecraft:packed_ice
setblock 182 88 305 minecraft:snow_block
fill 182 88 306 182 91 306 minecraft:packed_ice
fill 182 88 308 182 88 309 minecraft:packed_ice
setblock 182 88 310 minecraft:snow_block
fill 182 88 311 182 91 311 minecraft:packed_ice
setblock 182 88 315 minecraft:snow_block
fill 182 88 316 182 91 316 minecraft:packed_ice
setblock 141 89 289 minecraft:light_blue_concrete
fill 141 89 304 141 94 304 minecraft:packed_ice
fill 142 89 275 142 93 275 minecraft:packed_ice
setblock 142 89 279 minecraft:snow_block
fill 142 89 280 142 92 280 minecraft:packed_ice
setblock 142 89 284 minecraft:snow_block
fill 142 89 285 142 92 285 minecraft:packed_ice
setblock 142 89 289 minecraft:snow_block
fill 142 89 290 142 92 290 minecraft:packed_ice
setblock 142 89 294 minecraft:snow_block
fill 142 89 295 142 92 295 minecraft:packed_ice
setblock 142 89 299 minecraft:snow_block
fill 142 89 300 142 92 300 minecraft:packed_ice
setblock 142 89 304 minecraft:snow_block
fill 142 89 305 142 92 305 minecraft:packed_ice
setblock 142 89 309 minecraft:snow_block
fill 142 89 310 142 92 310 minecraft:packed_ice
setblock 142 89 314 minecraft:snow_block
fill 142 89 315 142 91 316 minecraft:packed_ice
setblock 143 89 278 minecraft:snow_block
fill 143 89 279 143 92 279 minecraft:packed_ice
setblock 143 89 283 minecraft:snow_block
fill 143 89 284 143 92 284 minecraft:packed_ice
setblock 143 89 288 minecraft:snow_block
fill 143 89 289 143 92 289 minecraft:packed_ice
setblock 143 89 293 minecraft:snow_block
fill 143 89 294 143 90 294 minecraft:packed_ice
setblock 143 89 298 minecraft:snow_block
fill 143 89 299 143 91 299 minecraft:packed_ice
setblock 143 89 303 minecraft:snow_block
fill 143 89 304 143 92 304 minecraft:packed_ice
fill 143 89 316 143 90 317 minecraft:packed_ice
setblock 144 89 277 minecraft:snow_block
fill 144 89 278 144 92 278 minecraft:packed_ice
setblock 144 89 282 minecraft:snow_block
fill 144 89 283 144 92 283 minecraft:packed_ice
setblock 144 89 287 minecraft:snow_block
setblock 144 89 298 minecraft:packed_ice
setblock 144 89 302 minecraft:snow_block
setblock 144 89 316 minecraft:packed_ice
setblock 145 89 276 minecraft:snow_block
fill 145 89 277 145 92 277 minecraft:packed_ice
setblock 145 89 281 minecraft:snow_block
fill 145 89 282 145 91 282 minecraft:packed_ice
setblock 145 89 316 minecraft:snow_block
fill 146 89 276 149 89 276 minecraft:packed_ice
fill 146 89 316 146 91 316 minecraft:packed_ice
setblock 147 89 275 minecraft:light_blue_concrete
setblock 147 89 279 minecraft:snow_block
fill 148 89 275 148 93 275 minecraft:packed_ice
setblock 148 89 278 minecraft:snow_block
setblock 148 89 279 minecraft:packed_ice
setblock 149 89 277 minecraft:snow_block
fill 149 89 278 149 90 278 minecraft:packed_ice
setblock 150 89 276 minecraft:snow_block
fill 150 89 277 153 89 277 minecraft:packed_ice
setblock 150 89 316 minecraft:snow_block
fill 151 89 276 151 92 276 minecraft:packed_ice
fill 151 89 316 151 90 316 minecraft:packed_ice
setblock 154 89 277 minecraft:snow_block
setblock 155 89 276 minecraft:snow_block
fill 155 89 277 155 91 277 minecraft:packed_ice
fill 155 89 284 155 90 284 minecraft:packed_ice
fill 155 89 288 155 90 288 minecraft:packed_ice
setblock 155 89 316 minecraft:snow_block
fill 156 89 276 156 92 276 minecraft:packed_ice
fill 156 89 289 156 90 289 minecraft:packed_ice
fill 156 89 316 156 92 316 minecraft:packed_ice
fill 157 89 282 157 90 282 minecraft:packed_ice
fill 157 89 315 157 91 315 minecraft:packed_ice
setblock 158 89 277 minecraft:packed_ice
setblock 158 89 278 minecraft:snow_block
fill 158 89 290 159 90 290 minecraft:packed_ice
setblock 159 89 277 minecraft:snow_block
fill 159 89 278 159 91 278 minecraft:packed_ice
setblock 160 89 276 minecraft:snow_block
fill 160 89 277 160 92 277 minecraft:packed_ice
fill 160 89 282 160 90 282 minecraft:packed_ice
setblock 160 89 316 minecraft:snow_block
fill 161 89 276 161 92 276 minecraft:packed_ice
setblock 161 89 315 minecraft:snow_block
fill 161 89 316 161 92 316 minecraft:packed_ice
setblock 162 89 314 minecraft:snow_block
fill 162 89 315 162 92 315 minecraft:packed_ice
setblock 163 89 278 minecraft:snow_block
setblock 163 89 314 minecraft:packed_ice
setblock 164 89 277 minecraft:snow_block
fill 164 89 278 164 90 278 minecraft:packed_ice
setblock 165 89 276 minecraft:snow_block
fill 165 89 277 165 91 277 minecraft:packed_ice
setblock 165 89 316 minecraft:snow_block
fill 166 89 276 166 91 276 minecraft:packed_ice
setblock 166 89 315 minecraft:snow_block
fill 166 89 316 166 91 316 minecraft:packed_ice
setblock 167 89 315 minecraft:packed_ice
fill 168 89 313 168 95 313 minecraft:packed_ice
setblock 170 89 276 minecraft:snow_block
setblock 176 89 276 minecraft:packed_ice
setblock 178 89 277 minecraft:packed_ice
fill 178 89 293 178 90 293 minecraft:packed_ice
fill 178 89 315 178 92 315 minecraft:blue_ice
setblock 179 89 277 minecraft:snow_block
fill 179 89 292 179 90 292 minecraft:packed_ice
fill 179 89 294 179 90 294 minecraft:packed_ice
setblock 179 89 298 minecraft:packed_ice
setblock 179 89 301 minecraft:packed_ice
setblock 179 89 302 minecraft:snow_block
setblock 180 89 276 minecraft:snow_block
fill 180 89 277 180 89 280 minecraft:packed_ice
setblock 180 89 281 minecraft:snow_block
fill 180 89 282 180 92 282 minecraft:packed_ice
fill 180 89 284 180 89 285 minecraft:packed_ice
setblock 180 89 286 minecraft:snow_block
setblock 180 89 296 minecraft:snow_block
fill 180 89 297 180 92 297 minecraft:packed_ice
setblock 180 89 301 minecraft:snow_block
fill 180 89 302 180 92 302 minecraft:packed_ice
setblock 180 89 316 minecraft:snow_block
fill 181 89 276 181 92 276 minecraft:packed_ice
setblock 181 89 280 minecraft:snow_block
fill 181 89 281 181 92 281 minecraft:packed_ice
setblock 181 89 284 minecraft:packed_ice
setblock 181 89 285 minecraft:snow_block
fill 181 89 286 181 92 286 minecraft:packed_ice
setblock 181 89 290 minecraft:snow_block
fill 181 89 291 181 92 291 minecraft:packed_ice
setblock 181 89 295 minecraft:snow_block
fill 181 89 296 181 92 296 minecraft:packed_ice
setblock 181 89 300 minecraft:snow_block
fill 181 89 301 181 92 301 minecraft:packed_ice
setblock 181 89 304 minecraft:packed_ice
setblock 181 89 305 minecraft:snow_block
fill 181 89 306 181 92 306 minecraft:packed_ice
fill 181 89 308 182 89 308 minecraft:packed_ice
fill 181 89 316 181 90 317 minecraft:packed_ice
setblock 182 89 279 minecraft:snow_block
fill 182 89 280 182 92 280 minecraft:packed_ice
setblock 182 89 284 minecraft:snow_block
fill 182 89 285 182 92 285 minecraft:packed_ice
setblock 182 89 289 minecraft:snow_block
fill 182 89 290 182 92 290 minecraft:packed_ice
setblock 182 89 294 minecraft:snow_block
fill 182 89 295 182 92 295 minecraft:packed_ice
setblock 182 89 299 minecraft:snow_block
fill 182 89 300 182 92 300 minecraft:packed_ice
setblock 182 89 304 minecraft:snow_block
fill 182 89 305 182 92 305 minecraft:packed_ice
setblock 182 89 309 minecraft:snow_block
fill 182 89 310 182 92 310 minecraft:packed_ice
setblock 182 89 314 minecraft:snow_block
fill 182 89 315 182 90 315 minecraft:packed_ice
fill 141 90 289 142 93 289 minecraft:packed_ice
fill 141 90 290 141 91 290 minecraft:blue_ice
setblock 141 90 308 minecraft:blue_ice
fill 141 90 316 141 93 316 minecraft:packed_ice
fill 141 90 317 141 91 317 minecraft:blue_ice
setblock 142 90 278 minecraft:snow_block
fill 142 90 279 142 93 279 minecraft:packed_ice
setblock 142 90 283 minecraft:snow_block
fill 142 90 284 142 93 284 minecraft:packed_ice
setblock 142 90 288 minecraft:snow_block
setblock 142 90 293 minecraft:snow_block
fill 142 90 294 142 92 294 minecraft:packed_ice
setblock 142 90 298 minecraft:snow_block
fill 142 90 299 142 93 299 minecraft:packed_ice
setblock 142 90 303 minecraft:snow_block
fill 142 90 304 142 93 304 minecraft:packed_ice
setblock 142 90 307 minecraft:packed_ice
setblock 142 90 308 minecraft:snow_block
fill 142 90 309 142 93 309 minecraft:packed_ice
setblock 142 90 313 minecraft:snow_block
fill 142 90 314 142 92 314 minecraft:packed_ice
setblock 143 90 275 minecraft:blue_ice
setblock 143 90 277 minecraft:snow_block
fill 143 90 278 143 93 278 minecraft:packed_ice
setblock 143 90 282 minecraft:snow_block
fill 143 90 283 143 93 283 minecraft:packed_ice
setblock 143 90 287 minecraft:snow_block
fill 143 90 288 143 93 288 minecraft:packed_ice
setblock 143 90 292 minecraft:snow_block
setblock 143 90 293 minecraft:packed_ice
setblock 143 90 297 minecraft:snow_block
fill 143 90 298 143 91 298 minecraft:packed_ice
setblock 143 90 302 minecraft:snow_block
fill 143 90 303 143 92 303 minecraft:packed_ice
fill 143 90 307 143 91 308 minecraft:blue_ice
setblock 144 90 276 minecraft:snow_block
fill 144 90 277 144 93 277 minecraft:packed_ice
setblock 144 90 281 minecraft:snow_block
fill 144 90 282 144 93 282 minecraft:packed_ice
fill 144 90 284 144 91 284 minecraft:packed_ice
setblock 144 90 286 minecraft:snow_block
setblock 144 90 287 minecraft:packed_ice
setblock 144 90 292 minecraft:light[level=12]
setblock 144 90 299 minecraft:light[level=12]
fill 144 90 304 144 91 304 minecraft:packed_ice
fill 144 90 306 144 91 306 minecraft:packed_ice
fill 144 90 307 146 91 307 minecraft:blue_ice
setblock 144 90 313 minecraft:light[level=12]
setblock 144 90 316 minecraft:snow_block
setblock 145 90 275 minecraft:blue_ice
fill 145 90 276 148 90 276 minecraft:packed_ice
setblock 145 90 280 minecraft:snow_block
fill 145 90 281 145 91 281 minecraft:packed_ice
fill 145 90 305 145 91 305 minecraft:packed_ice
fill 145 90 316 145 92 316 minecraft:packed_ice
setblock 146 90 279 minecraft:snow_block
fill 147 90 275 147 91 275 minecraft:packed_ice
setblock 147 90 278 minecraft:snow_block
setblock 147 90 279 minecraft:packed_ice
setblock 148 90 277 minecraft:snow_block
fill 148 90 278 148 91 278 minecraft:packed_ice
fill 148 90 307 149 91 307 minecraft:blue_ice
setblock 149 90 276 minecraft:snow_block
fill 149 90 277 152 90 277 minecraft:packed_ice
setblock 149 90 316 minecraft:snow_block
fill 150 90 276 150 92 276 minecraft:packed_ice
fill 150 90 297 151 91 298 minecraft:snow_block
setblock 150 90 316 minecraft:packed_ice
setblock 151 90 278 minecraft:light[level=12]
setblock 151 90 285 minecraft:light[level=12]
setblock 151 90 292 minecraft:light[level=12]
fill 151 90 296 151 91 296 minecraft:snow_block
setblock 151 90 299 minecraft:light[level=12]
setblock 151 90 306 minecraft:light[level=12]
setblock 151 90 313 minecraft:light[level=12]
setblock 153 90 277 minecraft:snow_block
fill 154 90 275 154 91 275 minecraft:blue_ice
setblock 154 90 276 minecraft:snow_block
fill 154 90 277 154 91 277 minecraft:packed_ice
fill 154 90 285 154 90 287 minecraft:packed_ice
setblock 154 90 316 minecraft:snow_block
fill 155 90 276 155 93 276 minecraft:packed_ice
setblock 155 90 283 minecraft:packed_ice
fill 155 90 316 155 93 316 minecraft:packed_ice
setblock 155 90 317 minecraft:blue_ice
fill 156 90 277 157 90 277 minecraft:packed_ice
setblock 156 90 282 minecraft:packed_ice
fill 156 90 317 157 93 317 minecraft:packed_ice
setblock 157 90 278 minecraft:snow_block
setblock 157 90 290 minecraft:packed_ice
setblock 158 90 275 minecraft:blue_ice
setblock 158 90 277 minecraft:snow_block
fill 158 90 278 158 91 278 minecraft:packed_ice
fill 158 90 281 159 90 281 minecraft:packed_ice
setblock 158 90 292 minecraft:light[level=12]
setblock 158 90 299 minecraft:light[level=12]
setblock 158 90 306 minecraft:light[level=12]
setblock 158 90 313 minecraft:light[level=12]
setblock 158 90 317 minecraft:blue_ice
setblock 159 90 276 minecraft:snow_block
fill 159 90 277 159 93 277 minecraft:packed_ice
setblock 159 90 316 minecraft:snow_block
fill 160 90 276 160 93 276 minecraft:packed_ice
setblock 160 90 290 minecraft:packed_ice
setblock 160 90 315 minecraft:snow_block
fill 160 90 316 160 93 316 minecraft:packed_ice
setblock 161 90 282 minecraft:packed_ice
setblock 161 90 314 minecraft:snow_block
fill 161 90 315 161 93 315 minecraft:packed_ice
setblock 162 90 278 minecraft:snow_block
setblock 162 90 283 minecraft:packed_ice
setblock 162 90 314 minecraft:packed_ice
setblock 162 90 317 minecraft:blue_ice
setblock 163 90 277 minecraft:snow_block
schedule function dropper:buildpart/63_3 1t
