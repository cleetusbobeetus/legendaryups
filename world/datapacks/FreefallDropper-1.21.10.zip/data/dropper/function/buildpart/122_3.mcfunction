setblock 95 52 551 minecraft:smooth_basalt
fill 96 52 511 96 54 511 minecraft:blackstone
setblock 96 52 515 minecraft:smooth_basalt
fill 96 52 516 96 55 516 minecraft:blackstone
setblock 96 52 520 minecraft:smooth_basalt
fill 96 52 521 96 55 521 minecraft:blackstone
setblock 96 52 530 minecraft:smooth_basalt
fill 96 52 531 96 55 531 minecraft:blackstone
setblock 96 52 535 minecraft:smooth_basalt
fill 96 52 536 96 55 536 minecraft:blackstone
setblock 96 52 540 minecraft:smooth_basalt
fill 96 52 541 96 55 541 minecraft:blackstone
setblock 96 52 545 minecraft:smooth_basalt
fill 96 52 546 96 55 546 minecraft:blackstone
fill 96 52 551 96 54 551 minecraft:blackstone
setblock 97 52 534 minecraft:smooth_basalt
fill 97 52 535 97 55 535 minecraft:blackstone
setblock 97 52 539 minecraft:smooth_basalt
fill 97 52 540 97 55 540 minecraft:blackstone
setblock 98 52 538 minecraft:smooth_basalt
setblock 108 52 512 minecraft:blackstone
setblock 109 52 512 minecraft:smooth_basalt
fill 109 52 513 109 55 513 minecraft:blackstone
setblock 110 52 511 minecraft:smooth_basalt
fill 110 52 512 110 55 512 minecraft:blackstone
fill 111 52 511 111 55 511 minecraft:blackstone
setblock 111 52 514 minecraft:blackstone
fill 111 52 551 111 55 551 minecraft:blackstone
setblock 112 52 514 minecraft:smooth_basalt
setblock 113 52 513 minecraft:smooth_basalt
fill 113 52 514 113 55 514 minecraft:blackstone
setblock 114 52 512 minecraft:smooth_basalt
fill 114 52 513 114 55 513 minecraft:blackstone
fill 114 52 515 115 52 515 minecraft:blackstone
setblock 115 52 511 minecraft:smooth_basalt
fill 115 52 512 115 55 512 minecraft:blackstone
setblock 115 52 551 minecraft:smooth_basalt
fill 116 52 511 119 52 511 minecraft:blackstone
fill 116 52 551 116 55 551 minecraft:blackstone
setblock 117 52 514 minecraft:smooth_basalt
setblock 118 52 513 minecraft:smooth_basalt
fill 118 52 514 118 53 514 minecraft:blackstone
setblock 119 52 512 minecraft:smooth_basalt
fill 119 52 513 119 54 513 minecraft:blackstone
setblock 120 52 511 minecraft:smooth_basalt
fill 120 52 512 120 55 512 minecraft:blackstone
fill 121 52 511 121 55 511 minecraft:blackstone
setblock 124 52 512 minecraft:smooth_basalt
setblock 125 52 511 minecraft:smooth_basalt
fill 125 52 512 125 55 512 minecraft:blackstone
setblock 125 52 551 minecraft:smooth_basalt
fill 126 52 511 126 55 511 minecraft:blackstone
fill 126 52 551 126 55 551 minecraft:blackstone
setblock 128 52 513 minecraft:smooth_basalt
setblock 129 52 512 minecraft:smooth_basalt
fill 129 52 513 129 55 513 minecraft:blackstone
fill 129 52 550 129 53 550 minecraft:blackstone
setblock 130 52 511 minecraft:smooth_basalt
fill 130 52 512 130 55 512 minecraft:blackstone
setblock 130 52 551 minecraft:smooth_basalt
fill 131 52 511 131 55 511 minecraft:blackstone
setblock 131 52 550 minecraft:smooth_basalt
fill 131 52 551 131 55 551 minecraft:blackstone
setblock 132 52 538 minecraft:blackstone
setblock 132 52 539 minecraft:smooth_basalt
fill 132 52 540 134 53 540 minecraft:blackstone
fill 132 52 550 132 55 550 minecraft:blackstone
setblock 133 52 513 minecraft:smooth_basalt
fill 133 52 514 133 55 514 minecraft:blackstone
setblock 133 52 518 minecraft:smooth_basalt
fill 133 52 534 133 52 537 minecraft:blackstone
setblock 133 52 538 minecraft:smooth_basalt
fill 133 52 539 134 54 539 minecraft:blackstone
fill 133 52 541 133 52 542 minecraft:blackstone
setblock 133 52 543 minecraft:smooth_basalt
fill 133 52 544 133 52 547 minecraft:blackstone
setblock 133 52 548 minecraft:smooth_basalt
fill 133 52 549 133 55 549 minecraft:blackstone
setblock 134 52 512 minecraft:smooth_basalt
fill 134 52 513 134 55 513 minecraft:blackstone
setblock 134 52 516 minecraft:blackstone
setblock 134 52 517 minecraft:smooth_basalt
fill 134 52 518 134 55 518 minecraft:blackstone
fill 134 52 520 134 53 520 minecraft:blackstone
setblock 134 52 532 minecraft:smooth_basalt
fill 134 52 533 134 55 533 minecraft:blackstone
setblock 134 52 537 minecraft:smooth_basalt
fill 134 52 538 134 55 538 minecraft:blackstone
setblock 134 52 541 minecraft:blackstone
setblock 134 52 542 minecraft:smooth_basalt
fill 134 52 543 134 55 543 minecraft:blackstone
setblock 134 52 547 minecraft:smooth_basalt
fill 134 52 548 134 55 548 minecraft:blackstone
setblock 135 52 511 minecraft:smooth_basalt
fill 135 52 512 135 55 512 minecraft:blackstone
setblock 135 52 516 minecraft:smooth_basalt
fill 135 52 517 135 55 517 minecraft:blackstone
setblock 135 52 521 minecraft:smooth_basalt
fill 135 52 522 135 53 524 minecraft:blackstone
setblock 135 52 531 minecraft:smooth_basalt
fill 135 52 532 135 55 532 minecraft:blackstone
setblock 135 52 536 minecraft:smooth_basalt
fill 135 52 537 135 55 537 minecraft:blackstone
setblock 135 52 541 minecraft:smooth_basalt
fill 135 52 542 135 55 542 minecraft:blackstone
setblock 135 52 546 minecraft:smooth_basalt
fill 135 52 547 135 55 547 minecraft:blackstone
setblock 135 52 551 minecraft:smooth_basalt
fill 95 53 511 95 55 511 minecraft:blackstone
setblock 95 53 515 minecraft:smooth_basalt
fill 95 53 516 95 56 516 minecraft:blackstone
setblock 95 53 520 minecraft:smooth_basalt
fill 95 53 521 95 53 524 minecraft:blackstone
setblock 95 53 525 minecraft:smooth_basalt
fill 95 53 526 95 56 526 minecraft:blackstone
setblock 95 53 530 minecraft:smooth_basalt
fill 95 53 531 95 56 531 minecraft:blackstone
setblock 95 53 535 minecraft:smooth_basalt
fill 95 53 536 95 56 536 minecraft:blackstone
setblock 95 53 540 minecraft:smooth_basalt
fill 95 53 541 95 56 541 minecraft:blackstone
setblock 95 53 545 minecraft:smooth_basalt
fill 95 53 546 95 56 546 minecraft:blackstone
setblock 95 53 550 minecraft:smooth_basalt
fill 95 53 551 95 55 551 minecraft:blackstone
setblock 96 53 514 minecraft:smooth_basalt
fill 96 53 515 96 55 515 minecraft:blackstone
setblock 96 53 519 minecraft:smooth_basalt
fill 96 53 520 96 56 520 minecraft:blackstone
fill 96 53 522 96 53 523 minecraft:blackstone
setblock 96 53 529 minecraft:smooth_basalt
fill 96 53 530 96 55 530 minecraft:blackstone
setblock 96 53 534 minecraft:smooth_basalt
fill 96 53 535 96 56 535 minecraft:blackstone
setblock 96 53 539 minecraft:smooth_basalt
fill 96 53 540 96 56 540 minecraft:blackstone
setblock 96 53 544 minecraft:smooth_basalt
fill 96 53 545 96 56 545 minecraft:blackstone
setblock 97 53 513 minecraft:light[level=12]
setblock 97 53 521 minecraft:light[level=12]
setblock 97 53 529 minecraft:light[level=12]
setblock 97 53 533 minecraft:smooth_basalt
fill 97 53 534 97 55 534 minecraft:blackstone
setblock 97 53 537 minecraft:blackstone
setblock 97 53 538 minecraft:smooth_basalt
fill 97 53 539 97 56 539 minecraft:blackstone
setblock 97 53 543 minecraft:smooth_basalt
setblock 97 53 545 minecraft:light[level=12]
setblock 98 53 537 minecraft:smooth_basalt
setblock 98 53 538 minecraft:blackstone
setblock 105 53 513 minecraft:light[level=12]
setblock 105 53 521 minecraft:light[level=12]
setblock 105 53 529 minecraft:light[level=12]
setblock 105 53 537 minecraft:light[level=12]
setblock 105 53 545 minecraft:light[level=12]
fill 106 53 511 106 55 511 minecraft:blackstone
setblock 108 53 512 minecraft:smooth_basalt
setblock 109 53 511 minecraft:smooth_basalt
fill 109 53 512 109 56 512 minecraft:blackstone
fill 110 53 511 110 56 511 minecraft:blackstone
setblock 110 53 514 minecraft:blackstone
setblock 111 53 514 minecraft:smooth_basalt
setblock 112 53 513 minecraft:smooth_basalt
fill 112 53 514 112 54 515 minecraft:blackstone
setblock 113 53 512 minecraft:smooth_basalt
fill 113 53 513 113 56 513 minecraft:blackstone
fill 113 53 515 114 53 515 minecraft:blackstone
setblock 113 53 521 minecraft:light[level=12]
setblock 113 53 529 minecraft:light[level=12]
setblock 113 53 537 minecraft:light[level=12]
setblock 113 53 545 minecraft:light[level=12]
setblock 114 53 511 minecraft:smooth_basalt
fill 114 53 512 114 56 512 minecraft:blackstone
setblock 114 53 551 minecraft:smooth_basalt
fill 115 53 511 118 53 511 minecraft:blackstone
setblock 115 53 515 minecraft:smooth_basalt
fill 115 53 551 115 56 551 minecraft:blackstone
setblock 116 53 514 minecraft:smooth_basalt
setblock 117 53 513 minecraft:smooth_basalt
fill 117 53 514 117 54 514 minecraft:blackstone
setblock 118 53 512 minecraft:smooth_basalt
fill 118 53 513 118 55 513 minecraft:blackstone
setblock 119 53 511 minecraft:smooth_basalt
fill 119 53 512 119 55 512 minecraft:blackstone
setblock 119 53 551 minecraft:smooth_basalt
fill 120 53 511 120 56 511 minecraft:blackstone
setblock 121 53 513 minecraft:light[level=12]
setblock 121 53 521 minecraft:light[level=12]
setblock 121 53 529 minecraft:light[level=12]
setblock 121 53 537 minecraft:light[level=12]
setblock 121 53 545 minecraft:light[level=12]
setblock 123 53 512 minecraft:smooth_basalt
setblock 124 53 511 minecraft:smooth_basalt
fill 124 53 512 124 55 512 minecraft:blackstone
fill 125 53 511 125 56 511 minecraft:blackstone
fill 125 53 551 125 56 551 minecraft:blackstone
setblock 128 53 512 minecraft:smooth_basalt
fill 128 53 513 128 54 513 minecraft:blackstone
fill 128 53 550 128 54 550 minecraft:blackstone
setblock 129 53 511 minecraft:smooth_basalt
fill 129 53 512 129 56 512 minecraft:blackstone
setblock 129 53 521 minecraft:light[level=12]
setblock 129 53 529 minecraft:light[level=12]
setblock 129 53 537 minecraft:light[level=12]
setblock 129 53 551 minecraft:smooth_basalt
fill 130 53 511 130 56 511 minecraft:blackstone
setblock 130 53 550 minecraft:smooth_basalt
fill 130 53 551 130 56 551 minecraft:blackstone
fill 131 53 550 131 56 550 minecraft:blackstone
setblock 132 53 513 minecraft:smooth_basalt
setblock 132 53 537 minecraft:blackstone
setblock 132 53 538 minecraft:smooth_basalt
fill 132 53 539 132 56 539 minecraft:blackstone
fill 132 53 541 132 53 542 minecraft:blackstone
setblock 132 53 543 minecraft:smooth_basalt
fill 132 53 549 132 56 549 minecraft:blackstone
setblock 133 53 512 minecraft:smooth_basalt
fill 133 53 513 133 55 513 minecraft:blackstone
setblock 133 53 517 minecraft:smooth_basalt
fill 133 53 518 133 55 519 minecraft:blackstone
fill 133 53 534 133 53 536 minecraft:blackstone
setblock 133 53 537 minecraft:smooth_basalt
fill 133 53 538 133 56 538 minecraft:blackstone
setblock 133 53 541 minecraft:blackstone
setblock 133 53 542 minecraft:smooth_basalt
fill 133 53 543 133 53 546 minecraft:blackstone
setblock 133 53 547 minecraft:smooth_basalt
fill 133 53 548 133 56 548 minecraft:blackstone
setblock 134 53 511 minecraft:smooth_basalt
fill 134 53 512 134 55 512 minecraft:blackstone
setblock 134 53 516 minecraft:smooth_basalt
fill 134 53 517 134 56 517 minecraft:blackstone
setblock 134 53 521 minecraft:smooth_basalt
setblock 134 53 531 minecraft:smooth_basalt
fill 134 53 532 134 55 532 minecraft:blackstone
setblock 134 53 536 minecraft:smooth_basalt
fill 134 53 537 134 56 537 minecraft:blackstone
setblock 134 53 541 minecraft:smooth_basalt
fill 134 53 542 134 56 542 minecraft:blackstone
setblock 134 53 546 minecraft:smooth_basalt
fill 134 53 547 134 56 547 minecraft:blackstone
setblock 134 53 551 minecraft:smooth_basalt
fill 135 53 511 135 56 511 minecraft:blackstone
setblock 135 53 515 minecraft:smooth_basalt
fill 135 53 516 135 56 516 minecraft:blackstone
setblock 135 53 520 minecraft:smooth_basalt
fill 135 53 521 135 56 521 minecraft:blackstone
setblock 135 53 525 minecraft:smooth_basalt
fill 135 53 526 135 55 527 minecraft:blackstone
setblock 135 53 530 minecraft:smooth_basalt
fill 135 53 531 135 56 531 minecraft:blackstone
setblock 135 53 535 minecraft:smooth_basalt
fill 135 53 536 135 56 536 minecraft:blackstone
setblock 135 53 540 minecraft:smooth_basalt
fill 135 53 541 135 56 541 minecraft:blackstone
setblock 135 53 545 minecraft:smooth_basalt
fill 135 53 546 135 56 546 minecraft:blackstone
setblock 135 53 550 minecraft:smooth_basalt
fill 135 53 551 135 56 551 minecraft:blackstone
setblock 95 54 514 minecraft:smooth_basalt
fill 95 54 515 95 57 515 minecraft:blackstone
setblock 95 54 518 minecraft:blackstone
setblock 95 54 519 minecraft:smooth_basalt
fill 95 54 520 95 54 523 minecraft:blackstone
setblock 95 54 524 minecraft:smooth_basalt
fill 95 54 525 95 57 525 minecraft:blackstone
setblock 95 54 528 minecraft:blackstone
setblock 95 54 529 minecraft:smooth_basalt
fill 95 54 530 95 57 530 minecraft:blackstone
setblock 95 54 534 minecraft:smooth_basalt
fill 95 54 535 95 57 535 minecraft:blackstone
setblock 95 54 539 minecraft:smooth_basalt
fill 95 54 540 95 57 540 minecraft:blackstone
setblock 95 54 544 minecraft:smooth_basalt
fill 95 54 545 95 57 545 minecraft:blackstone
setblock 95 54 549 minecraft:smooth_basalt
fill 95 54 550 95 55 550 minecraft:blackstone
setblock 96 54 514 minecraft:blackstone
setblock 96 54 518 minecraft:smooth_basalt
fill 96 54 519 96 57 519 minecraft:blackstone
setblock 96 54 522 minecraft:blackstone
setblock 96 54 523 minecraft:smooth_basalt
fill 96 54 524 96 57 524 minecraft:blackstone
setblock 96 54 528 minecraft:smooth_basalt
setblock 96 54 529 minecraft:blackstone
setblock 96 54 533 minecraft:smooth_basalt
fill 96 54 534 96 57 534 minecraft:blackstone
setblock 96 54 538 minecraft:smooth_basalt
fill 96 54 539 96 57 539 minecraft:blackstone
setblock 96 54 542 minecraft:blackstone
setblock 96 54 543 minecraft:smooth_basalt
fill 96 54 544 96 57 544 minecraft:blackstone
setblock 97 54 533 minecraft:blackstone
setblock 97 54 537 minecraft:smooth_basalt
fill 97 54 538 97 56 538 minecraft:blackstone
setblock 97 54 542 minecraft:smooth_basalt
setblock 97 54 543 minecraft:blackstone
fill 101 54 522 103 55 522 minecraft:gilded_blackstone
fill 102 54 523 103 55 523 minecraft:gilded_blackstone
setblock 107 54 512 minecraft:smooth_basalt
setblock 108 54 511 minecraft:smooth_basalt
fill 108 54 512 108 55 513 minecraft:blackstone
fill 109 54 511 109 57 511 minecraft:blackstone
setblock 110 54 514 minecraft:smooth_basalt
fill 110 54 551 110 56 551 minecraft:blackstone
setblock 111 54 513 minecraft:smooth_basalt
fill 111 54 514 111 56 514 minecraft:blackstone
setblock 112 54 512 minecraft:smooth_basalt
fill 112 54 513 112 57 513 minecraft:blackstone
setblock 113 54 511 minecraft:smooth_basalt
fill 113 54 512 113 57 512 minecraft:blackstone
setblock 113 54 515 minecraft:blackstone
setblock 113 54 551 minecraft:smooth_basalt
fill 114 54 511 117 54 511 minecraft:blackstone
setblock 114 54 515 minecraft:smooth_basalt
fill 114 54 551 114 57 551 minecraft:blackstone
setblock 115 54 514 minecraft:smooth_basalt
setblock 116 54 513 minecraft:smooth_basalt
fill 116 54 514 116 55 514 minecraft:blackstone
setblock 117 54 512 minecraft:smooth_basalt
fill 117 54 513 117 55 513 minecraft:blackstone
setblock 118 54 511 minecraft:smooth_basalt
fill 118 54 512 118 56 512 minecraft:blackstone
setblock 118 54 551 minecraft:smooth_basalt
fill 119 54 511 119 57 511 minecraft:blackstone
setblock 122 54 512 minecraft:smooth_basalt
setblock 123 54 511 minecraft:smooth_basalt
setblock 123 54 512 minecraft:blackstone
fill 124 54 511 124 57 511 minecraft:blackstone
fill 124 54 551 124 57 551 minecraft:blackstone
setblock 127 54 512 minecraft:smooth_basalt
setblock 128 54 511 minecraft:smooth_basalt
fill 128 54 512 128 57 512 minecraft:blackstone
setblock 128 54 551 minecraft:smooth_basalt
fill 129 54 511 129 57 511 minecraft:blackstone
setblock 129 54 550 minecraft:smooth_basalt
fill 129 54 551 129 57 551 minecraft:blackstone
fill 130 54 550 130 57 550 minecraft:blackstone
setblock 131 54 513 minecraft:smooth_basalt
fill 131 54 549 131 57 549 minecraft:blackstone
setblock 132 54 512 minecraft:smooth_basalt
fill 132 54 513 132 55 513 minecraft:blackstone
setblock 132 54 536 minecraft:blackstone
setblock 132 54 537 minecraft:smooth_basalt
fill 132 54 538 132 57 538 minecraft:blackstone
fill 132 54 540 132 54 541 minecraft:blackstone
setblock 132 54 542 minecraft:smooth_basalt
fill 132 54 543 133 55 544 minecraft:blackstone
setblock 133 54 511 minecraft:smooth_basalt
fill 133 54 512 133 56 512 minecraft:blackstone
setblock 133 54 516 minecraft:smooth_basalt
fill 133 54 517 133 56 517 minecraft:blackstone
fill 133 54 534 133 54 535 minecraft:blackstone
setblock 133 54 536 minecraft:smooth_basalt
fill 133 54 537 133 57 537 minecraft:blackstone
setblock 133 54 540 minecraft:blackstone
setblock 133 54 541 minecraft:smooth_basalt
fill 133 54 542 133 57 542 minecraft:blackstone
setblock 133 54 545 minecraft:blackstone
setblock 133 54 546 minecraft:smooth_basalt
fill 133 54 547 133 57 547 minecraft:blackstone
setblock 133 54 551 minecraft:smooth_basalt
fill 134 54 511 134 57 511 minecraft:blackstone
setblock 134 54 515 minecraft:smooth_basalt
fill 134 54 516 134 57 516 minecraft:blackstone
setblock 134 54 520 minecraft:smooth_basalt
fill 134 54 521 134 56 522 minecraft:blackstone
setblock 134 54 531 minecraft:blackstone
setblock 134 54 535 minecraft:smooth_basalt
fill 134 54 536 134 57 536 minecraft:blackstone
setblock 134 54 540 minecraft:smooth_basalt
fill 134 54 541 134 57 541 minecraft:blackstone
setblock 134 54 545 minecraft:smooth_basalt
fill 134 54 546 134 57 546 minecraft:blackstone
setblock 134 54 550 minecraft:smooth_basalt
fill 134 54 551 134 57 551 minecraft:blackstone
setblock 135 54 514 minecraft:smooth_basalt
fill 135 54 515 135 57 515 minecraft:blackstone
setblock 135 54 519 minecraft:smooth_basalt
fill 135 54 520 135 57 520 minecraft:blackstone
fill 135 54 522 135 54 523 minecraft:blackstone
setblock 135 54 524 minecraft:smooth_basalt
fill 135 54 525 135 57 525 minecraft:blackstone
setblock 135 54 529 minecraft:smooth_basalt
fill 135 54 530 135 56 530 minecraft:blackstone
setblock 135 54 534 minecraft:smooth_basalt
fill 135 54 535 135 57 535 minecraft:blackstone
setblock 135 54 539 minecraft:smooth_basalt
fill 135 54 540 135 57 540 minecraft:blackstone
setblock 135 54 544 minecraft:smooth_basalt
fill 135 54 545 135 57 545 minecraft:blackstone
setblock 135 54 549 minecraft:smooth_basalt
fill 135 54 550 135 57 550 minecraft:blackstone
setblock 95 55 513 minecraft:smooth_basalt
fill 95 55 514 95 57 514 minecraft:blackstone
setblock 95 55 518 minecraft:smooth_basalt
fill 95 55 519 95 55 522 minecraft:blackstone
setblock 95 55 523 minecraft:smooth_basalt
fill 95 55 524 95 58 524 minecraft:blackstone
setblock 95 55 528 minecraft:smooth_basalt
fill 95 55 529 95 58 529 minecraft:blackstone
setblock 95 55 533 minecraft:smooth_basalt
fill 95 55 534 95 58 534 minecraft:blackstone
setblock 95 55 538 minecraft:smooth_basalt
fill 95 55 539 95 58 539 minecraft:blackstone
setblock 95 55 543 minecraft:smooth_basalt
fill 95 55 544 95 58 544 minecraft:blackstone
setblock 95 55 548 minecraft:smooth_basalt
fill 95 55 549 95 56 549 minecraft:blackstone
setblock 96 55 517 minecraft:smooth_basalt
fill 96 55 518 96 57 518 minecraft:blackstone
setblock 96 55 522 minecraft:smooth_basalt
fill 96 55 523 96 58 523 minecraft:blackstone
setblock 96 55 525 minecraft:blackstone
setblock 96 55 532 minecraft:smooth_basalt
fill 96 55 533 96 56 533 minecraft:blackstone
setblock 96 55 537 minecraft:smooth_basalt
fill 96 55 538 96 58 538 minecraft:blackstone
setblock 96 55 542 minecraft:smooth_basalt
fill 96 55 543 96 58 543 minecraft:blackstone
setblock 97 55 536 minecraft:smooth_basalt
fill 97 55 537 97 56 537 minecraft:blackstone
setblock 97 55 541 minecraft:smooth_basalt
fill 97 55 542 97 56 542 minecraft:blackstone
fill 99 55 534 101 55 534 minecraft:gold_block
fill 100 55 531 101 55 533 minecraft:gold_block
fill 100 55 535 101 55 536 minecraft:gold_block
fill 101 55 530 107 55 530 minecraft:gold_block
fill 101 55 537 108 55 537 minecraft:gold_block
fill 102 55 531 102 56 532 minecraft:gold_block
fill 102 55 536 102 57 536 minecraft:gold_block
fill 102 55 538 107 55 538 minecraft:gold_block
fill 103 55 529 106 55 529 minecraft:gold_block
fill 103 55 531 108 55 531 minecraft:gold_block
setblock 104 55 539 minecraft:gold_block
fill 106 55 536 108 55 536 minecraft:gold_block
setblock 107 55 511 minecraft:smooth_basalt
fill 107 55 512 107 56 512 minecraft:blackstone
fill 107 55 532 109 55 535 minecraft:gold_block
fill 108 55 511 108 58 511 minecraft:blackstone
setblock 110 55 513 minecraft:smooth_basalt
fill 110 55 514 110 56 514 minecraft:blackstone
setblock 111 55 512 minecraft:smooth_basalt
fill 111 55 513 111 58 513 minecraft:blackstone
setblock 112 55 511 minecraft:smooth_basalt
fill 112 55 512 112 58 512 minecraft:blackstone
fill 112 55 514 112 56 514 minecraft:blackstone
setblock 112 55 551 minecraft:smooth_basalt
fill 113 55 511 116 55 511 minecraft:blackstone
fill 113 55 551 113 58 551 minecraft:blackstone
setblock 114 55 514 minecraft:smooth_basalt
setblock 115 55 513 minecraft:smooth_basalt
setblock 115 55 514 minecraft:blackstone
setblock 116 55 512 minecraft:smooth_basalt
fill 116 55 513 116 56 513 minecraft:blackstone
setblock 117 55 511 minecraft:smooth_basalt
fill 117 55 512 117 56 512 minecraft:blackstone
setblock 117 55 551 minecraft:smooth_basalt
fill 118 55 511 118 57 511 minecraft:blackstone
setblock 121 55 512 minecraft:smooth_basalt
setblock 122 55 511 minecraft:smooth_basalt
fill 122 55 522 123 55 524 minecraft:gold_block
fill 123 55 511 123 57 511 minecraft:blackstone
fill 123 55 521 127 55 521 minecraft:gold_block
fill 123 55 525 124 55 526 minecraft:gold_block
fill 124 55 522 124 57 522 minecraft:gold_block
fill 125 55 520 126 55 520 minecraft:gold_block
fill 125 55 526 125 55 527 minecraft:gold_block
setblock 126 55 512 minecraft:smooth_basalt
fill 126 55 526 127 55 526 minecraft:gold_block
fill 126 55 544 127 55 546 minecraft:gold_block
setblock 127 55 511 minecraft:smooth_basalt
fill 127 55 512 127 56 512 minecraft:blackstone
fill 127 55 522 128 55 522 minecraft:gold_block
fill 127 55 525 128 55 525 minecraft:gold_block
fill 127 55 543 131 55 543 minecraft:gold_block
fill 127 55 547 131 55 547 minecraft:gold_block
setblock 127 55 550 minecraft:blackstone
setblock 127 55 551 minecraft:smooth_basalt
fill 128 55 511 128 58 511 minecraft:blackstone
fill 128 55 523 128 56 524 minecraft:gold_block
fill 128 55 542 130 55 542 minecraft:gold_block
fill 128 55 548 130 55 548 minecraft:gold_block
setblock 128 55 550 minecraft:smooth_basalt
fill 128 55 551 128 58 551 minecraft:blackstone
fill 129 55 550 129 58 550 minecraft:blackstone
setblock 130 55 513 minecraft:smooth_basalt
fill 130 55 549 130 58 549 minecraft:blackstone
setblock 131 55 512 minecraft:smooth_basalt
setblock 131 55 513 minecraft:blackstone
fill 131 55 544 131 57 546 minecraft:gold_block
setblock 132 55 511 minecraft:smooth_basalt
fill 132 55 512 132 56 512 minecraft:blackstone
fill 132 55 537 132 56 537 minecraft:blackstone
setblock 132 55 540 minecraft:blackstone
setblock 132 55 541 minecraft:smooth_basalt
fill 132 55 542 132 58 542 minecraft:blackstone
setblock 132 55 545 minecraft:blackstone
setblock 132 55 546 minecraft:gold_block
setblock 132 55 551 minecraft:smooth_basalt
fill 133 55 511 133 57 511 minecraft:blackstone
setblock 133 55 515 minecraft:smooth_basalt
setblock 133 55 516 minecraft:blackstone
setblock 133 55 534 minecraft:blackstone
setblock 133 55 535 minecraft:smooth_basalt
fill 133 55 536 133 57 536 minecraft:blackstone
setblock 133 55 539 minecraft:blackstone
setblock 133 55 540 minecraft:smooth_basalt
fill 133 55 541 133 58 541 minecraft:blackstone
setblock 133 55 545 minecraft:smooth_basalt
fill 133 55 546 133 58 546 minecraft:blackstone
setblock 133 55 550 minecraft:smooth_basalt
fill 133 55 551 133 58 551 minecraft:blackstone
setblock 134 55 514 minecraft:smooth_basalt
fill 134 55 515 134 56 515 minecraft:blackstone
setblock 134 55 519 minecraft:smooth_basalt
fill 134 55 520 134 58 520 minecraft:blackstone
setblock 134 55 534 minecraft:smooth_basalt
fill 134 55 535 134 58 535 minecraft:blackstone
setblock 134 55 539 minecraft:smooth_basalt
fill 134 55 540 134 58 540 minecraft:blackstone
setblock 134 55 544 minecraft:smooth_basalt
fill 134 55 545 134 58 545 minecraft:blackstone
setblock 134 55 549 minecraft:smooth_basalt
fill 134 55 550 134 57 550 minecraft:blackstone
setblock 135 55 513 minecraft:smooth_basalt
fill 135 55 514 135 57 514 minecraft:blackstone
setblock 135 55 518 minecraft:smooth_basalt
fill 135 55 519 135 58 519 minecraft:blackstone
setblock 135 55 522 minecraft:blackstone
setblock 135 55 523 minecraft:smooth_basalt
fill 135 55 524 135 58 524 minecraft:blackstone
setblock 135 55 528 minecraft:smooth_basalt
fill 135 55 529 135 56 529 minecraft:blackstone
setblock 135 55 533 minecraft:smooth_basalt
fill 135 55 534 135 58 534 minecraft:blackstone
setblock 135 55 538 minecraft:smooth_basalt
fill 135 55 539 135 58 539 minecraft:blackstone
setblock 135 55 543 minecraft:smooth_basalt
fill 135 55 544 135 58 544 minecraft:blackstone
setblock 135 55 548 minecraft:smooth_basalt
fill 135 55 549 135 58 549 minecraft:blackstone
setblock 95 56 513 minecraft:blackstone
setblock 95 56 517 minecraft:smooth_basalt
fill 95 56 518 95 56 521 minecraft:blackstone
setblock 95 56 522 minecraft:smooth_basalt
fill 95 56 523 95 58 523 minecraft:blackstone
setblock 95 56 527 minecraft:smooth_basalt
fill 95 56 528 95 58 528 minecraft:blackstone
setblock 95 56 532 minecraft:smooth_basalt
fill 95 56 533 95 58 533 minecraft:blackstone
setblock 95 56 537 minecraft:smooth_basalt
fill 95 56 538 95 58 538 minecraft:blackstone
setblock 95 56 542 minecraft:smooth_basalt
fill 95 56 543 95 58 543 minecraft:blackstone
setblock 95 56 547 minecraft:smooth_basalt
fill 95 56 548 95 57 548 minecraft:blackstone
setblock 96 56 516 minecraft:smooth_basalt
setblock 96 56 517 minecraft:blackstone
setblock 96 56 521 minecraft:smooth_basalt
fill 96 56 522 96 58 522 minecraft:blackstone
setblock 96 56 531 minecraft:smooth_basalt
setblock 96 56 532 minecraft:blackstone
setblock 96 56 536 minecraft:smooth_basalt
fill 96 56 537 96 58 537 minecraft:blackstone
setblock 96 56 541 minecraft:smooth_basalt
fill 96 56 542 96 58 542 minecraft:blackstone
setblock 97 56 536 minecraft:blackstone
setblock 97 56 540 minecraft:smooth_basalt
setblock 97 56 541 minecraft:blackstone
fill 100 56 533 101 56 535 minecraft:gold_block
fill 101 56 531 101 56 532 minecraft:gold_block
setblock 101 56 536 minecraft:gold_block
fill 102 56 537 107 56 537 minecraft:gold_block
fill 103 56 530 106 56 531 minecraft:gold_block
fill 103 56 538 105 56 538 minecraft:gold_block
setblock 106 56 511 minecraft:smooth_basalt
fill 106 56 517 106 57 518 minecraft:gold_block
fill 106 56 536 107 57 536 minecraft:gold_block
fill 107 56 511 107 58 511 minecraft:blackstone
fill 107 56 531 107 56 535 minecraft:gold_block
fill 108 56 512 108 57 512 minecraft:blackstone
fill 108 56 532 108 56 535 minecraft:gold_block
setblock 109 56 513 minecraft:smooth_basalt
setblock 110 56 512 minecraft:smooth_basalt
fill 110 56 513 110 57 513 minecraft:blackstone
setblock 111 56 511 minecraft:smooth_basalt
fill 111 56 512 111 58 512 minecraft:blackstone
setblock 111 56 551 minecraft:smooth_basalt
fill 112 56 511 115 56 511 minecraft:blackstone
fill 112 56 551 112 58 551 minecraft:blackstone
setblock 113 56 514 minecraft:smooth_basalt
setblock 114 56 513 minecraft:smooth_basalt
setblock 114 56 514 minecraft:blackstone
setblock 115 56 512 minecraft:smooth_basalt
setblock 115 56 513 minecraft:blackstone
setblock 116 56 511 minecraft:smooth_basalt
fill 116 56 512 116 57 512 minecraft:blackstone
setblock 116 56 551 minecraft:smooth_basalt
fill 117 56 511 117 58 511 minecraft:blackstone
setblock 121 56 511 minecraft:smooth_basalt
setblock 122 56 511 minecraft:blackstone
fill 123 56 522 123 56 525 minecraft:gold_block
fill 124 56 521 127 56 521 minecraft:gold_block
fill 124 56 525 124 56 526 minecraft:gold_block
fill 125 56 526 126 56 526 minecraft:gold_block
setblock 126 56 511 minecraft:smooth_basalt
setblock 126 56 512 minecraft:blackstone
setblock 126 56 551 minecraft:smooth_basalt
fill 127 56 511 127 58 511 minecraft:blackstone
fill 127 56 522 127 57 522 minecraft:gold_block
fill 127 56 525 127 57 525 minecraft:gold_block
fill 127 56 544 127 56 546 minecraft:gold_block
setblock 127 56 550 minecraft:smooth_basalt
fill 127 56 551 127 58 551 minecraft:blackstone
fill 128 56 543 131 56 543 minecraft:gold_block
fill 128 56 547 130 56 547 minecraft:gold_block
fill 128 56 550 128 58 550 minecraft:blackstone
setblock 130 56 512 minecraft:smooth_basalt
setblock 131 56 511 minecraft:smooth_basalt
fill 131 56 512 131 57 512 minecraft:blackstone
setblock 131 56 551 minecraft:smooth_basalt
fill 132 56 511 132 58 511 minecraft:blackstone
setblock 132 56 540 minecraft:smooth_basalt
fill 132 56 541 132 58 541 minecraft:blackstone
fill 132 56 543 132 56 544 minecraft:blackstone
setblock 132 56 545 minecraft:smooth_basalt
setblock 132 56 550 minecraft:smooth_basalt
fill 132 56 551 132 58 551 minecraft:blackstone
setblock 133 56 518 minecraft:blackstone
setblock 133 56 519 minecraft:smooth_basalt
fill 133 56 533 133 57 533 minecraft:gold_block
setblock 133 56 535 minecraft:blackstone
setblock 133 56 539 minecraft:smooth_basalt
fill 133 56 540 133 58 540 minecraft:blackstone
setblock 133 56 543 minecraft:blackstone
setblock 133 56 544 minecraft:smooth_basalt
fill 133 56 545 133 58 545 minecraft:blackstone
setblock 133 56 549 minecraft:smooth_basalt
fill 133 56 550 133 58 550 minecraft:blackstone
setblock 134 56 513 minecraft:smooth_basalt
setblock 134 56 514 minecraft:blackstone
setblock 134 56 518 minecraft:smooth_basalt
fill 134 56 519 134 57 519 minecraft:blackstone
setblock 134 56 533 minecraft:smooth_basalt
fill 134 56 534 134 57 534 minecraft:blackstone
setblock 134 56 538 minecraft:smooth_basalt
fill 134 56 539 134 58 539 minecraft:blackstone
setblock 134 56 543 minecraft:smooth_basalt
fill 134 56 544 134 58 544 minecraft:blackstone
setblock 134 56 548 minecraft:smooth_basalt
fill 134 56 549 134 58 549 minecraft:blackstone
setblock 135 56 512 minecraft:smooth_basalt
fill 135 56 513 135 57 513 minecraft:blackstone
setblock 135 56 517 minecraft:smooth_basalt
fill 135 56 518 135 58 518 minecraft:blackstone
setblock 135 56 522 minecraft:smooth_basalt
fill 135 56 523 135 58 523 minecraft:blackstone
setblock 135 56 526 minecraft:blackstone
setblock 135 56 532 minecraft:smooth_basalt
fill 135 56 533 135 58 533 minecraft:blackstone
setblock 135 56 537 minecraft:smooth_basalt
fill 135 56 538 135 58 538 minecraft:blackstone
setblock 135 56 542 minecraft:smooth_basalt
fill 135 56 543 135 58 543 minecraft:blackstone
setblock 135 56 547 minecraft:smooth_basalt
fill 135 56 548 135 58 548 minecraft:blackstone
setblock 95 57 516 minecraft:smooth_basalt
fill 95 57 517 95 57 520 minecraft:blackstone
setblock 95 57 521 minecraft:smooth_basalt
fill 95 57 522 95 58 522 minecraft:blackstone
setblock 95 57 526 minecraft:smooth_basalt
fill 95 57 527 95 58 527 minecraft:blackstone
setblock 95 57 531 minecraft:smooth_basalt
fill 95 57 532 95 58 532 minecraft:blackstone
setblock 95 57 536 minecraft:smooth_basalt
fill 95 57 537 95 58 537 minecraft:blackstone
setblock 95 57 541 minecraft:smooth_basalt
fill 95 57 542 95 58 542 minecraft:blackstone
setblock 95 57 546 minecraft:smooth_basalt
fill 95 57 547 95 58 547 minecraft:blackstone
setblock 96 57 520 minecraft:smooth_basalt
fill 96 57 521 96 58 521 minecraft:blackstone
setblock 96 57 535 minecraft:smooth_basalt
fill 96 57 536 96 58 536 minecraft:blackstone
setblock 96 57 540 minecraft:smooth_basalt
fill 96 57 541 96 58 541 minecraft:blackstone
setblock 96 57 545 minecraft:smooth_basalt
fill 101 57 533 101 57 535 minecraft:gold_block
setblock 102 57 532 minecraft:gold_block
fill 103 57 531 106 57 531 minecraft:gold_block
fill 103 57 537 105 57 537 minecraft:gold_block
fill 107 57 532 107 57 535 minecraft:gold_block
setblock 109 57 512 minecraft:smooth_basalt
setblock 109 57 513 minecraft:blackstone
setblock 110 57 511 minecraft:smooth_basalt
fill 110 57 512 110 58 512 minecraft:blackstone
setblock 110 57 551 minecraft:smooth_basalt
fill 111 57 511 114 57 511 minecraft:blackstone
fill 111 57 551 111 58 551 minecraft:blackstone
setblock 113 57 513 minecraft:smooth_basalt
setblock 114 57 512 minecraft:smooth_basalt
setblock 114 57 513 minecraft:blackstone
setblock 115 57 511 minecraft:smooth_basalt
setblock 115 57 512 minecraft:blackstone
fill 116 57 511 116 58 511 minecraft:blackstone
setblock 120 57 511 minecraft:smooth_basalt
fill 123 57 523 123 57 524 minecraft:gold_block
setblock 124 57 525 minecraft:gold_block
setblock 125 57 511 minecraft:smooth_basalt
setblock 125 57 521 minecraft:gold_block
setblock 125 57 551 minecraft:smooth_basalt
fill 126 57 511 126 58 511 minecraft:blackstone
fill 126 57 551 126 58 551 minecraft:blackstone
setblock 127 57 545 minecraft:gold_block
fill 127 57 550 127 58 550 minecraft:blackstone
fill 128 57 543 130 57 543 minecraft:gold_block
setblock 129 57 512 minecraft:smooth_basalt
fill 129 57 547 130 57 547 minecraft:gold_block
setblock 130 57 511 minecraft:smooth_basalt
setblock 130 57 512 minecraft:blackstone
setblock 130 57 551 minecraft:smooth_basalt
fill 131 57 511 131 58 511 minecraft:blackstone
setblock 131 57 550 minecraft:smooth_basalt
fill 131 57 551 131 58 551 minecraft:blackstone
setblock 132 57 539 minecraft:smooth_basalt
fill 132 57 540 132 58 540 minecraft:blackstone
setblock 132 57 543 minecraft:blackstone
setblock 132 57 544 minecraft:smooth_basalt
fill 132 57 545 132 58 545 minecraft:blackstone
setblock 132 57 549 minecraft:smooth_basalt
fill 132 57 550 132 58 550 minecraft:blackstone
setblock 133 57 538 minecraft:smooth_basalt
fill 133 57 539 133 58 539 minecraft:blackstone
setblock 133 57 543 minecraft:smooth_basalt
fill 133 57 544 133 58 544 minecraft:blackstone
setblock 133 57 548 minecraft:smooth_basalt
setblock 134 57 517 minecraft:smooth_basalt
setblock 134 57 518 minecraft:blackstone
setblock 134 57 521 minecraft:blackstone
setblock 134 57 522 minecraft:smooth_basalt
setblock 134 57 537 minecraft:smooth_basalt
fill 134 57 538 134 58 538 minecraft:blackstone
setblock 134 57 542 minecraft:smooth_basalt
fill 134 57 543 134 58 543 minecraft:blackstone
setblock 134 57 547 minecraft:smooth_basalt
fill 134 57 548 134 58 548 minecraft:blackstone
setblock 135 57 516 minecraft:smooth_basalt
fill 135 57 517 135 58 517 minecraft:blackstone
setblock 135 57 521 minecraft:smooth_basalt
fill 135 57 522 135 58 522 minecraft:blackstone
setblock 135 57 531 minecraft:smooth_basalt
setblock 135 57 532 minecraft:blackstone
setblock 135 57 536 minecraft:smooth_basalt
fill 135 57 537 135 58 537 minecraft:blackstone
setblock 135 57 541 minecraft:smooth_basalt
fill 135 57 542 135 58 542 minecraft:blackstone
setblock 135 57 546 minecraft:smooth_basalt
fill 135 57 547 135 58 547 minecraft:blackstone
setblock 135 57 551 minecraft:smooth_basalt
fill 95 58 516 95 58 519 minecraft:blackstone
setblock 95 58 520 minecraft:smooth_basalt
setblock 95 58 521 minecraft:blackstone
setblock 95 58 525 minecraft:smooth_basalt
setblock 95 58 526 minecraft:blackstone
setblock 95 58 530 minecraft:smooth_basalt
setblock 95 58 531 minecraft:blackstone
setblock 95 58 535 minecraft:smooth_basalt
setblock 95 58 536 minecraft:blackstone
setblock 95 58 540 minecraft:smooth_basalt
setblock 95 58 541 minecraft:blackstone
setblock 95 58 545 minecraft:smooth_basalt
setblock 95 58 546 minecraft:blackstone
setblock 96 58 520 minecraft:blackstone
setblock 96 58 524 minecraft:smooth_basalt
setblock 96 58 539 minecraft:smooth_basalt
setblock 96 58 540 minecraft:blackstone
setblock 96 58 544 minecraft:smooth_basalt
setblock 108 58 512 minecraft:smooth_basalt
setblock 109 58 511 minecraft:smooth_basalt
setblock 109 58 512 minecraft:blackstone
fill 110 58 511 113 58 511 minecraft:blackstone
setblock 110 58 551 minecraft:blackstone
setblock 113 58 512 minecraft:smooth_basalt
setblock 114 58 511 minecraft:smooth_basalt
setblock 114 58 512 minecraft:blackstone
setblock 115 58 511 minecraft:blackstone
setblock 124 58 551 minecraft:smooth_basalt
setblock 125 58 511 minecraft:blackstone
setblock 125 58 551 minecraft:blackstone
setblock 129 58 511 minecraft:smooth_basalt
setblock 129 58 549 minecraft:blackstone
setblock 129 58 551 minecraft:smooth_basalt
setblock 130 58 511 minecraft:blackstone
setblock 130 58 550 minecraft:smooth_basalt
setblock 130 58 551 minecraft:blackstone
setblock 131 58 549 minecraft:smooth_basalt
setblock 131 58 550 minecraft:blackstone
setblock 132 58 539 minecraft:blackstone
setblock 132 58 543 minecraft:smooth_basalt
setblock 132 58 544 minecraft:blackstone
setblock 133 58 537 minecraft:smooth_basalt
setblock 133 58 538 minecraft:blackstone
setblock 133 58 542 minecraft:smooth_basalt
setblock 133 58 543 minecraft:blackstone
setblock 133 58 547 minecraft:smooth_basalt
setblock 134 58 536 minecraft:smooth_basalt
setblock 134 58 537 minecraft:blackstone
setblock 134 58 541 minecraft:smooth_basalt
setblock 134 58 542 minecraft:blackstone
setblock 134 58 546 minecraft:smooth_basalt
setblock 134 58 547 minecraft:blackstone
setblock 134 58 551 minecraft:smooth_basalt
setblock 135 58 516 minecraft:blackstone
setblock 135 58 520 minecraft:smooth_basalt
setblock 135 58 521 minecraft:blackstone
setblock 135 58 525 minecraft:smooth_basalt
setblock 135 58 535 minecraft:smooth_basalt
setblock 135 58 536 minecraft:blackstone
setblock 135 58 540 minecraft:smooth_basalt
setblock 135 58 541 minecraft:blackstone
setblock 135 58 545 minecraft:smooth_basalt
setblock 135 58 546 minecraft:blackstone
setblock 135 58 550 minecraft:smooth_basalt
setblock 135 58 551 minecraft:blackstone
setblock 97 61 513 minecraft:light[level=12]
setblock 97 61 521 minecraft:light[level=12]
setblock 97 61 529 minecraft:light[level=12]
setblock 97 61 537 minecraft:light[level=12]
setblock 97 61 545 minecraft:light[level=12]
setblock 105 61 513 minecraft:light[level=12]
setblock 105 61 521 minecraft:light[level=12]
setblock 105 61 529 minecraft:light[level=12]
setblock 105 61 537 minecraft:light[level=12]
setblock 105 61 545 minecraft:light[level=12]
setblock 113 61 513 minecraft:light[level=12]
setblock 113 61 521 minecraft:light[level=12]
setblock 113 61 529 minecraft:light[level=12]
setblock 113 61 537 minecraft:light[level=12]
setblock 113 61 545 minecraft:light[level=12]
setblock 121 61 513 minecraft:light[level=12]
setblock 121 61 521 minecraft:light[level=12]
setblock 121 61 529 minecraft:light[level=12]
setblock 121 61 537 minecraft:light[level=12]
setblock 121 61 545 minecraft:light[level=12]
setblock 129 61 513 minecraft:light[level=12]
setblock 129 61 521 minecraft:light[level=12]
setblock 129 61 529 minecraft:light[level=12]
setblock 129 61 537 minecraft:light[level=12]
setblock 129 61 545 minecraft:light[level=12]
fill 109 63 524 111 63 526 minecraft:redstone_block
fill 113 63 519 115 63 521 minecraft:redstone_block
fill 114 63 529 116 63 531 minecraft:redstone_block
fill 95 64 510 103 79 510 minecraft:gilded_blackstone
fill 96 64 525 108 64 525 minecraft:blackstone
fill 97 64 519 108 64 524 minecraft:blackstone
fill 97 64 526 108 64 531 minecraft:blackstone
fill 98 64 517 132 64 518 minecraft:blackstone
fill 98 64 532 132 64 533 minecraft:blackstone
fill 99 64 515 131 64 516 minecraft:blackstone
fill 99 64 534 131 64 535 minecraft:blackstone
fill 100 64 514 130 64 514 minecraft:blackstone
fill 100 64 536 130 64 536 minecraft:blackstone
fill 101 64 513 129 64 513 minecraft:blackstone
fill 101 64 537 129 64 537 minecraft:blackstone
fill 102 64 512 128 64 512 minecraft:blackstone
fill 102 64 538 128 64 538 minecraft:blackstone
fill 103 64 511 127 64 511 minecraft:blackstone
fill 103 64 539 127 64 539 minecraft:blackstone
fill 104 64 510 126 64 510 minecraft:blackstone
fill 104 64 540 126 64 540 minecraft:blackstone
fill 105 64 541 125 64 541 minecraft:blackstone
fill 107 64 542 123 64 542 minecraft:blackstone
fill 109 64 519 112 64 523 minecraft:blackstone
fill 109 64 527 113 64 531 minecraft:blackstone
fill 109 64 543 121 64 543 minecraft:blackstone
fill 112 64 524 113 64 526 minecraft:blackstone
fill 113 64 522 133 64 523 minecraft:blackstone
fill 114 64 527 133 64 528 minecraft:blackstone
fill 115 64 544 115 71 544 minecraft:blackstone
fill 116 64 519 133 64 521 minecraft:blackstone
fill 117 64 524 133 64 526 minecraft:blackstone
fill 117 64 529 133 64 531 minecraft:blackstone
fill 127 64 510 136 79 510 minecraft:gilded_blackstone
fill 134 64 525 134 71 525 minecraft:blackstone
fill 95 65 511 95 65 551 minecraft:basalt
fill 96 65 511 96 65 524 minecraft:basalt
fill 96 65 525 107 68 525 minecraft:blackstone
fill 96 65 526 96 65 551 minecraft:basalt
fill 97 65 511 97 65 518 minecraft:basalt
fill 97 65 519 97 71 522 minecraft:blackstone
fill 97 65 523 97 71 523 minecraft:gold_block
fill 97 65 524 107 68 524 minecraft:blackstone
fill 97 65 526 97 71 531 minecraft:blackstone
fill 97 65 532 97 65 551 minecraft:basalt
fill 98 65 511 98 65 516 minecraft:basalt
fill 98 65 517 100 71 521 minecraft:blackstone
fill 98 65 522 99 71 522 minecraft:gold_block
fill 98 65 523 107 68 523 minecraft:blackstone
fill 98 65 526 98 71 530 minecraft:blackstone
fill 98 65 531 98 71 531 minecraft:gold_block
fill 98 65 532 103 70 533 minecraft:blackstone
fill 98 65 534 98 65 551 minecraft:basalt
fill 99 65 511 99 65 514 minecraft:basalt
fill 99 65 515 99 71 516 minecraft:blackstone
fill 99 65 526 99 71 528 minecraft:blackstone
fill 99 65 529 99 71 529 minecraft:gold_block
fill 99 65 530 104 70 531 minecraft:blackstone
fill 99 65 534 102 71 535 minecraft:blackstone
fill 99 65 536 99 65 551 minecraft:basalt
fill 100 65 511 100 65 513 minecraft:basalt
fill 100 65 514 111 69 514 minecraft:blackstone
fill 100 65 515 102 71 515 minecraft:gold_block
fill 100 65 516 105 70 516 minecraft:blackstone
fill 100 65 522 111 66 522 minecraft:blackstone
fill 100 65 526 100 71 527 minecraft:blackstone
fill 100 65 528 100 71 528 minecraft:gold_block
fill 100 65 529 105 69 529 minecraft:blackstone
fill 100 65 536 107 70 536 minecraft:blackstone
fill 100 65 537 100 65 551 minecraft:basalt
fill 101 65 511 101 65 512 minecraft:basalt
fill 101 65 513 110 70 513 minecraft:blackstone
fill 101 65 517 108 68 520 minecraft:blackstone
fill 101 65 521 102 70 521 minecraft:gold_block
fill 101 65 526 102 70 526 minecraft:blackstone
fill 101 65 527 101 70 527 minecraft:gold_block
fill 101 65 528 106 68 528 minecraft:blackstone
fill 101 65 537 101 71 537 minecraft:blackstone
fill 101 65 538 101 65 551 minecraft:basalt
setblock 102 65 511 minecraft:basalt
fill 102 65 512 109 71 512 minecraft:blackstone
fill 102 65 527 107 68 527 minecraft:blackstone
fill 102 65 537 102 71 538 minecraft:gold_block
fill 102 65 539 102 65 551 minecraft:basalt
fill 103 65 511 115 71 511 minecraft:blackstone
fill 103 65 515 112 69 515 minecraft:blackstone
fill 103 65 521 108 68 521 minecraft:blackstone
fill 103 65 526 103 70 526 minecraft:gold_block
fill 103 65 534 103 71 534 minecraft:gold_block
fill 103 65 535 107 70 535 minecraft:blackstone
fill 103 65 537 107 71 539 minecraft:blackstone
fill 103 65 540 103 65 551 minecraft:basalt
fill 104 65 510 105 71 510 minecraft:blackstone
fill 104 65 526 107 68 526 minecraft:blackstone
fill 104 65 532 104 70 532 minecraft:gold_block
fill 104 65 533 115 68 534 minecraft:blackstone
fill 104 65 540 122 71 540 minecraft:blackstone
fill 104 65 541 104 65 551 minecraft:basalt
fill 105 65 530 105 69 530 minecraft:gold_block
fill 105 65 531 112 67 532 minecraft:blackstone
fill 105 65 541 114 71 541 minecraft:blackstone
fill 105 65 542 106 65 551 minecraft:basalt
fill 106 65 510 107 71 510 minecraft:gold_block
fill 106 65 516 107 70 516 minecraft:gold_block
fill 106 65 529 106 69 529 minecraft:gold_block
fill 106 65 530 112 67 530 minecraft:blackstone
fill 107 65 528 107 68 528 minecraft:gold_block
fill 107 65 529 112 66 529 minecraft:blackstone
fill 107 65 542 108 71 542 minecraft:blackstone
fill 107 65 543 108 65 551 minecraft:basalt
fill 108 65 510 126 71 510 minecraft:blackstone
fill 108 65 516 126 68 516 minecraft:blackstone
fill 108 65 523 108 65 527 minecraft:shroomlight
fill 108 65 528 111 66 528 minecraft:blackstone
fill 108 65 535 108 70 539 minecraft:gold_block
fill 109 65 517 109 69 517 minecraft:gold_block
fill 109 65 518 111 67 520 minecraft:blackstone
fill 109 65 521 109 67 521 minecraft:gold_block
fill 109 65 523 117 65 523 minecraft:shroomlight
fill 109 65 524 111 65 526 minecraft:basalt
fill 109 65 527 117 65 527 minecraft:shroomlight
fill 109 65 535 112 69 539 minecraft:blackstone
fill 109 65 542 109 71 543 minecraft:gold_block
fill 109 65 544 114 65 551 minecraft:basalt
fill 110 65 512 110 70 512 minecraft:gold_block
fill 110 65 517 113 68 517 minecraft:blackstone
fill 110 65 521 111 67 521 minecraft:blackstone
fill 110 65 542 115 71 543 minecraft:blackstone
fill 111 65 512 121 70 512 minecraft:blackstone
fill 111 65 513 111 70 513 minecraft:gold_block
fill 112 65 513 116 69 513 minecraft:blackstone
fill 112 65 514 112 69 514 minecraft:gold_block
fill 112 65 518 112 65 522 minecraft:shroomlight
fill 112 65 524 113 65 526 minecraft:shroomlight
fill 112 65 528 112 66 528 minecraft:magma_block
fill 113 65 514 116 69 514 minecraft:blackstone
fill 113 65 515 113 69 515 minecraft:gold_block
fill 113 65 518 116 65 518 minecraft:shroomlight
fill 113 65 519 115 65 521 minecraft:basalt
fill 113 65 522 116 65 522 minecraft:shroomlight
fill 113 65 528 113 65 532 minecraft:shroomlight
fill 113 65 535 116 69 535 minecraft:blackstone
fill 113 65 536 113 69 537 minecraft:gold_block
fill 113 65 538 113 70 539 minecraft:blackstone
fill 114 65 515 121 69 515 minecraft:blackstone
fill 114 65 517 114 68 517 minecraft:gold_block
fill 114 65 528 117 65 528 minecraft:shroomlight
fill 114 65 529 116 65 531 minecraft:basalt
fill 114 65 532 117 65 532 minecraft:shroomlight
fill 114 65 536 117 69 538 minecraft:blackstone
fill 114 65 539 114 70 539 minecraft:gold_block
fill 115 65 517 132 68 517 minecraft:blackstone
fill 115 65 539 127 70 539 minecraft:blackstone
fill 115 65 541 115 71 541 minecraft:gold_block
fill 115 65 545 135 65 551 minecraft:basalt
fill 116 65 511 116 70 511 minecraft:gold_block
fill 116 65 519 116 65 521 minecraft:shroomlight
fill 116 65 533 116 68 533 minecraft:gold_block
fill 116 65 534 122 68 534 minecraft:blackstone
fill 116 65 541 125 71 541 minecraft:blackstone
fill 116 65 542 116 71 542 minecraft:gold_block
fill 116 65 543 116 71 543 minecraft:blackstone
fill 116 65 544 135 65 544 minecraft:basalt
fill 117 65 511 121 71 511 minecraft:blackstone
fill 117 65 513 117 69 514 minecraft:gold_block
fill 117 65 518 124 67 520 minecraft:blackstone
fill 117 65 521 117 66 522 minecraft:magma_block
fill 117 65 524 117 65 526 minecraft:shroomlight
fill 117 65 529 117 65 531 minecraft:shroomlight
fill 117 65 533 120 68 533 minecraft:blackstone
fill 117 65 535 117 69 535 minecraft:gold_block
fill 117 65 542 123 71 542 minecraft:blackstone
fill 117 65 543 117 71 543 minecraft:gold_block
fill 118 65 513 121 69 514 minecraft:blackstone
fill 118 65 521 123 66 521 minecraft:blackstone
fill 118 65 522 118 66 528 minecraft:magma_block
fill 118 65 529 120 66 532 minecraft:blackstone
fill 118 65 535 127 69 535 minecraft:blackstone
fill 118 65 536 118 69 536 minecraft:gold_block
fill 118 65 537 118 70 538 minecraft:blackstone
fill 118 65 543 121 71 543 minecraft:blackstone
fill 119 65 522 122 66 522 minecraft:blackstone
fill 119 65 523 119 66 527 minecraft:magma_block
fill 119 65 528 130 66 528 minecraft:blackstone
fill 119 65 536 130 69 536 minecraft:blackstone
fill 119 65 537 119 70 537 minecraft:gold_block
fill 119 65 538 119 70 538 minecraft:blackstone
fill 120 65 523 121 66 527 minecraft:blackstone
fill 120 65 537 129 70 537 minecraft:blackstone
fill 120 65 538 120 70 538 minecraft:gold_block
fill 121 65 529 121 67 529 minecraft:gold_block
fill 121 65 530 132 68 532 minecraft:blackstone
fill 121 65 533 121 69 533 minecraft:gold_block
fill 121 65 538 128 70 538 minecraft:blackstone
fill 122 65 511 122 70 515 minecraft:gold_block
fill 122 65 523 126 67 525 minecraft:blackstone
fill 122 65 526 122 67 526 minecraft:gold_block
fill 122 65 527 132 67 527 minecraft:blackstone
fill 122 65 529 127 68 529 minecraft:blackstone
fill 122 65 533 132 69 533 minecraft:blackstone
fill 122 65 543 135 65 543 minecraft:basalt
fill 123 65 511 127 70 515 minecraft:blackstone
fill 123 65 522 123 68 522 minecraft:gold_block
fill 123 65 526 133 68 526 minecraft:blackstone
fill 123 65 534 124 70 534 minecraft:gold_block
fill 123 65 540 124 71 540 minecraft:gold_block
fill 124 65 521 124 69 521 minecraft:gold_block
fill 124 65 522 129 68 522 minecraft:blackstone
fill 124 65 542 135 65 542 minecraft:basalt
fill 125 65 518 125 69 519 minecraft:blackstone
fill 125 65 520 125 69 520 minecraft:gold_block
fill 125 65 521 130 69 521 minecraft:blackstone
fill 125 65 534 131 70 534 minecraft:blackstone
fill 125 65 540 126 71 540 minecraft:blackstone
fill 126 65 518 126 70 518 minecraft:gold_block
fill 126 65 519 131 70 520 minecraft:blackstone
fill 126 65 541 135 65 541 minecraft:basalt
fill 127 65 516 127 71 516 minecraft:gold_block
fill 127 65 518 132 70 518 minecraft:blackstone
fill 127 65 523 128 70 523 minecraft:blackstone
fill 127 65 524 127 70 524 minecraft:gold_block
fill 127 65 525 133 69 525 minecraft:blackstone
fill 127 65 540 135 65 540 minecraft:basalt
fill 128 65 511 135 65 511 minecraft:basalt
fill 128 65 512 128 71 513 minecraft:gold_block
fill 128 65 514 130 71 516 minecraft:blackstone
fill 128 65 524 133 70 524 minecraft:blackstone
fill 128 65 529 129 70 529 minecraft:gold_block
fill 128 65 535 130 71 535 minecraft:gold_block
fill 128 65 539 135 65 539 minecraft:basalt
fill 129 65 512 135 65 512 minecraft:basalt
fill 129 65 513 129 71 513 minecraft:blackstone
fill 129 65 523 129 70 523 minecraft:gold_block
fill 129 65 538 135 65 538 minecraft:basalt
fill 130 65 513 135 65 513 minecraft:basalt
fill 130 65 522 130 71 522 minecraft:gold_block
fill 130 65 523 133 71 523 minecraft:blackstone
fill 130 65 529 133 71 529 minecraft:blackstone
fill 130 65 537 135 65 537 minecraft:basalt
fill 131 65 514 135 65 514 minecraft:basalt
fill 131 65 515 131 71 516 minecraft:blackstone
fill 131 65 521 131 71 521 minecraft:gold_block
fill 131 65 522 133 71 522 minecraft:blackstone
fill 131 65 528 132 71 528 minecraft:gold_block
fill 131 65 535 131 71 535 minecraft:blackstone
fill 131 65 536 135 65 536 minecraft:basalt
fill 132 65 515 135 65 516 minecraft:basalt
fill 132 65 519 132 71 519 minecraft:gold_block
fill 132 65 520 133 71 521 minecraft:blackstone
fill 132 65 534 135 65 535 minecraft:basalt
fill 133 65 517 135 65 518 minecraft:basalt
fill 133 65 519 133 71 519 minecraft:blackstone
fill 133 65 527 133 71 527 minecraft:gold_block
fill 133 65 528 133 71 528 minecraft:blackstone
fill 133 65 530 133 71 531 minecraft:blackstone
fill 133 65 532 135 65 533 minecraft:basalt
fill 134 65 519 135 65 524 minecraft:basalt
fill 134 65 526 135 65 531 minecraft:basalt
setblock 135 65 525 minecraft:basalt
fill 108 66 523 110 67 523 minecraft:blackstone
fill 108 66 524 108 67 524 minecraft:gold_block
fill 108 66 525 110 66 527 minecraft:blackstone
fill 109 66 524 110 67 524 minecraft:blackstone
fill 111 66 523 112 66 527 minecraft:magma_block
fill 112 66 518 112 66 521 minecraft:blackstone
fill 112 66 522 116 66 522 minecraft:magma_block
fill 113 66 518 114 67 520 minecraft:blackstone
fill 113 66 521 116 66 521 minecraft:magma_block
setblock 113 66 523 minecraft:magma_block
fill 113 66 527 113 66 529 minecraft:magma_block
fill 113 66 530 114 67 532 minecraft:blackstone
fill 114 66 528 117 66 529 minecraft:magma_block
fill 115 66 518 116 67 519 minecraft:blackstone
setblock 115 66 520 minecraft:gold_block
setblock 115 66 530 minecraft:gold_block
fill 115 66 531 117 67 532 minecraft:blackstone
fill 116 66 520 116 67 520 minecraft:blackstone
fill 116 66 530 117 67 530 minecraft:blackstone
setblock 117 66 523 minecraft:magma_block
setblock 117 66 527 minecraft:magma_block
fill 100 67 522 110 67 522 minecraft:blackstone
fill 107 67 529 111 67 529 minecraft:blackstone
fill 108 67 525 109 67 528 minecraft:blackstone
fill 110 67 526 110 67 528 minecraft:blackstone
fill 112 67 518 112 67 520 minecraft:blackstone
fill 118 67 530 120 67 532 minecraft:blackstone
fill 119 67 521 123 67 521 minecraft:blackstone
fill 119 67 529 120 67 529 minecraft:blackstone
fill 120 67 522 121 67 524 minecraft:blackstone
fill 120 67 526 121 67 528 minecraft:blackstone
setblock 121 67 525 minecraft:blackstone
fill 122 67 522 122 68 522 minecraft:blackstone
fill 122 67 528 130 68 528 minecraft:blackstone
fill 100 68 522 108 68 522 minecraft:blackstone
fill 105 68 531 110 68 532 minecraft:blackstone
fill 106 68 530 109 68 530 minecraft:blackstone
fill 107 68 529 108 68 529 minecraft:blackstone
setblock 108 68 528 minecraft:blackstone
fill 109 68 518 109 68 520 minecraft:blackstone
fill 110 68 518 110 68 519 minecraft:blackstone
fill 111 68 518 112 68 518 minecraft:blackstone
fill 111 68 532 112 68 532 minecraft:blackstone
fill 118 68 518 124 68 518 minecraft:blackstone
fill 118 68 532 120 68 532 minecraft:blackstone
fill 120 68 519 124 68 519 minecraft:blackstone
setblock 120 68 531 minecraft:blackstone
fill 121 68 520 124 68 520 minecraft:blackstone
fill 122 68 521 123 68 521 minecraft:blackstone
fill 123 68 523 126 68 525 minecraft:blackstone
fill 123 68 527 132 68 527 minecraft:blackstone
fill 95 69 520 95 69 523 minecraft:blackstone
setblock 95 69 524 minecraft:smooth_basalt
fill 95 69 525 95 69 528 minecraft:blackstone
setblock 95 69 529 minecraft:smooth_basalt
fill 95 69 530 95 69 533 minecraft:blackstone
setblock 95 69 534 minecraft:smooth_basalt
fill 95 69 535 95 72 535 minecraft:blackstone
setblock 95 69 548 minecraft:blackstone
setblock 95 69 549 minecraft:smooth_basalt
fill 95 69 550 95 70 550 minecraft:blackstone
fill 96 69 511 97 69 511 minecraft:blackstone
setblock 96 69 522 minecraft:blackstone
setblock 96 69 523 minecraft:smooth_basalt
fill 96 69 524 96 69 527 minecraft:blackstone
setblock 96 69 528 minecraft:smooth_basalt
fill 96 69 529 96 69 532 minecraft:blackstone
fill 96 69 551 97 69 551 minecraft:blackstone
setblock 97 69 513 minecraft:light[level=12]
fill 97 69 524 105 69 525 minecraft:blackstone
setblock 97 69 537 minecraft:light[level=12]
setblock 97 69 545 minecraft:light[level=12]
setblock 98 69 511 minecraft:smooth_basalt
fill 98 69 523 105 69 523 minecraft:blackstone
setblock 98 69 551 minecraft:smooth_basalt
fill 99 69 511 101 69 512 minecraft:blackstone
setblock 99 69 550 minecraft:smooth_basalt
fill 99 69 551 102 69 551 minecraft:blackstone
fill 100 69 522 105 69 522 minecraft:blackstone
fill 100 69 550 103 69 550 minecraft:blackstone
fill 101 69 517 106 69 520 minecraft:blackstone
fill 101 69 528 105 69 528 minecraft:blackstone
setblock 102 69 511 minecraft:blackstone
fill 102 69 527 105 69 527 minecraft:blackstone
fill 102 69 549 104 69 549 minecraft:blackstone
fill 103 69 521 106 69 521 minecraft:blackstone
setblock 103 69 551 minecraft:smooth_basalt
fill 104 69 526 105 69 526 minecraft:blackstone
fill 104 69 533 109 69 534 minecraft:blackstone
setblock 104 69 550 minecraft:smooth_basalt
fill 104 69 551 107 69 551 minecraft:blackstone
fill 105 69 531 107 69 532 minecraft:blackstone
setblock 105 69 545 minecraft:light[level=12]
setblock 105 69 549 minecraft:smooth_basalt
fill 105 69 550 108 69 550 minecraft:blackstone
setblock 106 69 530 minecraft:blackstone
fill 106 69 549 109 69 549 minecraft:blackstone
fill 107 69 517 107 69 519 minecraft:blackstone
fill 108 69 516 108 69 518 minecraft:blackstone
setblock 108 69 532 minecraft:blackstone
setblock 108 69 551 minecraft:smooth_basalt
fill 109 69 516 111 69 516 minecraft:blackstone
setblock 109 69 550 minecraft:smooth_basalt
fill 109 69 551 112 69 551 minecraft:blackstone
fill 110 69 534 111 69 534 minecraft:blackstone
setblock 110 69 549 minecraft:smooth_basalt
fill 110 69 550 113 69 550 minecraft:blackstone
setblock 113 69 521 minecraft:light[level=12]
setblock 113 69 529 minecraft:light[level=12]
setblock 113 69 545 minecraft:light[level=12]
setblock 113 69 551 minecraft:smooth_basalt
setblock 114 69 550 minecraft:smooth_basalt
fill 114 69 551 117 69 551 minecraft:blackstone
fill 115 69 550 118 69 550 minecraft:blackstone
fill 116 69 549 119 69 549 minecraft:blackstone
setblock 118 69 551 minecraft:smooth_basalt
fill 119 69 516 126 69 516 minecraft:blackstone
fill 119 69 534 122 69 534 minecraft:blackstone
fill 119 69 548 120 69 548 minecraft:blackstone
setblock 119 69 550 minecraft:smooth_basalt
fill 119 69 551 122 69 551 minecraft:blackstone
setblock 120 69 549 minecraft:smooth_basalt
fill 120 69 550 123 69 550 minecraft:blackstone
fill 121 69 517 132 69 517 minecraft:blackstone
setblock 121 69 521 minecraft:light[level=12]
setblock 121 69 529 minecraft:light[level=12]
setblock 121 69 545 minecraft:light[level=12]
setblock 121 69 548 minecraft:smooth_basalt
fill 121 69 549 124 69 549 minecraft:blackstone
fill 122 69 518 124 69 518 minecraft:blackstone
fill 122 69 532 132 69 532 minecraft:blackstone
fill 122 69 548 125 69 548 minecraft:blackstone
fill 123 69 519 124 69 519 minecraft:blackstone
fill 123 69 531 132 69 531 minecraft:blackstone
fill 123 69 547 125 69 547 minecraft:blackstone
setblock 123 69 551 minecraft:smooth_basalt
setblock 124 69 520 minecraft:blackstone
fill 124 69 529 127 69 530 minecraft:blackstone
setblock 124 69 550 minecraft:smooth_basalt
fill 124 69 551 127 69 551 minecraft:blackstone
fill 125 69 522 126 69 528 minecraft:blackstone
setblock 125 69 549 minecraft:smooth_basalt
fill 125 69 550 128 69 550 minecraft:blackstone
setblock 126 69 548 minecraft:smooth_basalt
fill 126 69 549 129 69 549 minecraft:blackstone
fill 127 69 522 129 70 522 minecraft:blackstone
fill 127 69 526 130 70 528 minecraft:blackstone
fill 127 69 548 128 69 548 minecraft:blackstone
setblock 128 69 511 minecraft:smooth_basalt
fill 128 69 530 132 70 530 minecraft:blackstone
setblock 128 69 551 minecraft:smooth_basalt
fill 129 69 511 130 70 511 minecraft:blackstone
setblock 129 69 545 minecraft:light[level=12]
setblock 129 69 550 minecraft:smooth_basalt
fill 129 69 551 132 69 551 minecraft:blackstone
setblock 130 69 549 minecraft:smooth_basalt
fill 130 69 550 133 69 550 minecraft:blackstone
fill 131 69 526 132 71 527 minecraft:blackstone
fill 133 69 526 135 70 526 minecraft:blackstone
setblock 133 69 551 minecraft:smooth_basalt
fill 134 69 527 134 69 529 minecraft:blackstone
setblock 134 69 530 minecraft:smooth_basalt
fill 134 69 531 135 69 533 minecraft:blackstone
fill 134 69 547 135 69 548 minecraft:blackstone
fill 134 69 551 135 71 551 minecraft:blackstone
setblock 135 69 523 minecraft:blackstone
setblock 135 69 524 minecraft:smooth_basalt
fill 135 69 525 135 72 525 minecraft:blackstone
fill 135 69 527 135 69 528 minecraft:blackstone
setblock 135 69 529 minecraft:smooth_basalt
fill 135 69 530 135 72 530 minecraft:blackstone
setblock 135 69 534 minecraft:smooth_basalt
fill 135 69 535 135 70 537 minecraft:blackstone
fill 135 69 542 135 69 543 minecraft:blackstone
setblock 135 69 544 minecraft:smooth_basalt
fill 135 69 545 135 70 546 minecraft:blackstone
setblock 135 69 549 minecraft:smooth_basalt
fill 135 69 550 135 72 550 minecraft:blackstone
fill 95 70 511 96 70 511 minecraft:blackstone
fill 95 70 520 95 70 522 minecraft:blackstone
setblock 95 70 523 minecraft:smooth_basalt
fill 95 70 524 95 70 527 minecraft:blackstone
setblock 95 70 528 minecraft:smooth_basalt
fill 95 70 529 95 70 532 minecraft:blackstone
setblock 95 70 533 minecraft:smooth_basalt
fill 95 70 534 95 73 534 minecraft:blackstone
setblock 95 70 549 minecraft:blackstone
fill 95 70 551 96 70 551 minecraft:blackstone
fill 96 70 523 96 70 526 minecraft:blackstone
setblock 96 70 527 minecraft:smooth_basalt
fill 96 70 528 96 70 531 minecraft:blackstone
setblock 96 70 532 minecraft:smooth_basalt
fill 96 70 533 96 73 533 minecraft:blackstone
setblock 97 70 511 minecraft:smooth_basalt
fill 97 70 524 102 70 525 minecraft:blackstone
setblock 97 70 551 minecraft:smooth_basalt
fill 98 70 511 100 70 512 minecraft:blackstone
fill 98 70 523 103 70 523 minecraft:blackstone
fill 98 70 551 101 70 551 minecraft:blackstone
fill 99 70 550 102 70 550 minecraft:blackstone
fill 100 70 514 110 70 514 minecraft:blackstone
fill 100 70 522 103 70 522 minecraft:blackstone
fill 100 70 529 103 70 529 minecraft:blackstone
setblock 101 70 511 minecraft:blackstone
setblock 101 70 512 minecraft:smooth_basalt
fill 101 70 517 104 70 520 minecraft:blackstone
fill 101 70 528 103 70 528 minecraft:blackstone
setblock 102 70 511 minecraft:smooth_basalt
fill 102 70 527 103 70 527 minecraft:blackstone
fill 102 70 549 103 70 549 minecraft:blackstone
setblock 102 70 551 minecraft:smooth_basalt
fill 103 70 515 108 70 515 minecraft:blackstone
setblock 103 70 521 minecraft:blackstone
setblock 103 70 524 minecraft:blackstone
setblock 103 70 550 minecraft:smooth_basalt
fill 103 70 551 106 70 551 minecraft:blackstone
fill 104 70 533 106 70 534 minecraft:blackstone
setblock 104 70 549 minecraft:smooth_basalt
fill 104 70 550 107 70 550 minecraft:blackstone
fill 105 70 517 105 70 518 minecraft:blackstone
setblock 105 70 532 minecraft:blackstone
fill 105 70 549 108 70 549 minecraft:blackstone
setblock 106 70 517 minecraft:blackstone
setblock 107 70 534 minecraft:blackstone
setblock 107 70 551 minecraft:smooth_basalt
setblock 108 70 550 minecraft:smooth_basalt
fill 108 70 551 111 70 551 minecraft:blackstone
fill 109 70 536 110 70 539 minecraft:blackstone
setblock 109 70 549 minecraft:smooth_basalt
fill 109 70 550 112 70 550 minecraft:blackstone
fill 111 70 537 112 70 539 minecraft:blackstone
fill 112 70 513 114 70 513 minecraft:blackstone
setblock 112 70 551 minecraft:smooth_basalt
setblock 113 70 537 minecraft:gold_block
setblock 113 70 550 minecraft:smooth_basalt
fill 113 70 551 116 70 551 minecraft:blackstone
fill 114 70 537 114 70 538 minecraft:blackstone
fill 114 70 550 117 70 550 minecraft:blackstone
fill 115 70 538 117 70 538 minecraft:blackstone
setblock 116 70 513 minecraft:blackstone
fill 116 70 537 117 70 537 minecraft:blackstone
fill 116 70 549 118 70 549 minecraft:blackstone
setblock 117 70 513 minecraft:gold_block
setblock 117 70 551 minecraft:smooth_basalt
fill 118 70 513 121 70 513 minecraft:blackstone
setblock 118 70 550 minecraft:smooth_basalt
fill 118 70 551 121 70 551 minecraft:blackstone
setblock 119 70 548 minecraft:blackstone
setblock 119 70 549 minecraft:smooth_basalt
fill 119 70 550 122 70 550 minecraft:blackstone
fill 120 70 514 121 70 514 minecraft:blackstone
fill 120 70 536 130 70 536 minecraft:blackstone
setblock 120 70 548 minecraft:smooth_basalt
fill 120 70 549 123 70 549 minecraft:blackstone
fill 121 70 548 124 70 548 minecraft:blackstone
fill 122 70 535 127 70 535 minecraft:blackstone
setblock 122 70 551 minecraft:smooth_basalt
fill 123 70 516 126 70 516 minecraft:blackstone
setblock 123 70 550 minecraft:smooth_basalt
fill 123 70 551 126 70 551 minecraft:blackstone
fill 124 70 517 132 70 517 minecraft:blackstone
fill 124 70 533 132 70 533 minecraft:blackstone
setblock 124 70 549 minecraft:smooth_basalt
fill 124 70 550 127 70 550 minecraft:blackstone
setblock 125 70 518 minecraft:blackstone
fill 125 70 532 132 70 532 minecraft:blackstone
setblock 125 70 548 minecraft:smooth_basalt
fill 125 70 549 128 70 549 minecraft:blackstone
fill 126 70 530 127 70 531 minecraft:blackstone
fill 126 70 548 127 70 548 minecraft:blackstone
fill 127 70 521 130 70 521 minecraft:blackstone
setblock 127 70 529 minecraft:blackstone
setblock 127 70 551 minecraft:smooth_basalt
fill 128 70 511 128 73 511 minecraft:blackstone
fill 128 70 525 133 70 525 minecraft:blackstone
fill 128 70 531 132 70 531 minecraft:blackstone
setblock 128 70 550 minecraft:smooth_basalt
fill 128 70 551 131 70 551 minecraft:blackstone
setblock 129 70 549 minecraft:smooth_basalt
fill 129 70 550 132 70 550 minecraft:blackstone
setblock 130 70 549 minecraft:blackstone
setblock 132 70 551 minecraft:smooth_basalt
fill 133 70 551 133 72 551 minecraft:blackstone
fill 134 70 527 134 70 528 minecraft:blackstone
setblock 134 70 529 minecraft:smooth_basalt
fill 134 70 530 134 70 533 minecraft:blackstone
setblock 134 70 534 minecraft:smooth_basalt
setblock 135 70 523 minecraft:smooth_basalt
fill 135 70 524 135 72 524 minecraft:blackstone
setblock 135 70 527 minecraft:blackstone
setblock 135 70 528 minecraft:smooth_basalt
fill 135 70 529 135 73 529 minecraft:blackstone
fill 135 70 531 135 70 532 minecraft:blackstone
setblock 135 70 533 minecraft:smooth_basalt
fill 135 70 534 135 73 534 minecraft:blackstone
setblock 135 70 544 minecraft:blackstone
setblock 135 70 547 minecraft:blackstone
setblock 135 70 548 minecraft:smooth_basalt
fill 135 70 549 135 72 549 minecraft:blackstone
setblock 95 71 511 minecraft:blackstone
setblock 95 71 512 minecraft:smooth_basalt
fill 95 71 513 95 74 513 minecraft:blackstone
setblock 95 71 521 minecraft:blackstone
setblock 95 71 522 minecraft:smooth_basalt
fill 95 71 523 95 71 526 minecraft:blackstone
setblock 95 71 527 minecraft:smooth_basalt
fill 95 71 528 95 71 531 minecraft:blackstone
setblock 95 71 532 minecraft:smooth_basalt
fill 95 71 533 95 74 533 minecraft:blackstone
setblock 95 71 551 minecraft:blackstone
setblock 96 71 511 minecraft:smooth_basalt
fill 96 71 523 96 71 525 minecraft:blackstone
setblock 96 71 526 minecraft:smooth_basalt
fill 96 71 527 96 71 530 minecraft:blackstone
setblock 96 71 531 minecraft:smooth_basalt
fill 96 71 532 96 74 532 minecraft:blackstone
setblock 96 71 551 minecraft:smooth_basalt
fill 97 71 511 99 71 512 minecraft:blackstone
fill 97 71 524 100 71 525 minecraft:blackstone
fill 97 71 551 100 71 551 minecraft:blackstone
fill 98 71 523 100 71 523 minecraft:blackstone
fill 98 71 532 102 71 533 minecraft:blackstone
fill 99 71 530 101 71 531 minecraft:blackstone
fill 99 71 550 101 71 550 minecraft:blackstone
setblock 100 71 511 minecraft:blackstone
setblock 100 71 512 minecraft:smooth_basalt
fill 100 71 513 105 71 514 minecraft:blackstone
fill 100 71 516 103 71 516 minecraft:blackstone
setblock 100 71 522 minecraft:blackstone
fill 100 71 529 101 71 529 minecraft:blackstone
fill 100 71 536 105 71 536 minecraft:blackstone
setblock 101 71 511 minecraft:smooth_basalt
fill 101 71 512 101 74 512 minecraft:blackstone
fill 101 71 517 101 71 520 minecraft:blackstone
setblock 101 71 521 minecraft:gold_block
setblock 101 71 551 minecraft:smooth_basalt
fill 102 71 511 102 74 511 minecraft:blackstone
fill 102 71 517 102 71 518 minecraft:blackstone
setblock 102 71 549 minecraft:blackstone
setblock 102 71 550 minecraft:smooth_basalt
fill 102 71 551 105 71 551 minecraft:blackstone
fill 103 71 515 104 71 515 minecraft:blackstone
setblock 103 71 517 minecraft:blackstone
setblock 103 71 533 minecraft:blackstone
fill 103 71 535 104 71 535 minecraft:blackstone
setblock 103 71 549 minecraft:smooth_basalt
fill 103 71 550 106 71 550 minecraft:blackstone
fill 104 71 549 107 71 549 minecraft:blackstone
fill 106 71 513 108 71 513 minecraft:blackstone
setblock 106 71 551 minecraft:smooth_basalt
setblock 107 71 550 minecraft:smooth_basalt
fill 107 71 551 110 71 551 minecraft:blackstone
fill 108 71 538 108 71 539 minecraft:gold_block
fill 108 71 550 111 71 550 minecraft:blackstone
fill 109 71 539 111 71 539 minecraft:blackstone
setblock 110 71 512 minecraft:smooth_basalt
fill 111 71 512 113 71 512 minecraft:blackstone
setblock 111 71 551 minecraft:smooth_basalt
setblock 112 71 550 minecraft:smooth_basalt
fill 112 71 551 115 71 551 minecraft:blackstone
fill 113 71 550 116 71 550 minecraft:blackstone
setblock 116 71 511 minecraft:smooth_basalt
fill 116 71 512 119 71 512 minecraft:blackstone
fill 116 71 549 117 71 549 minecraft:blackstone
setblock 116 71 551 minecraft:smooth_basalt
setblock 117 71 550 minecraft:smooth_basalt
fill 117 71 551 120 71 551 minecraft:blackstone
setblock 118 71 549 minecraft:smooth_basalt
fill 118 71 550 121 71 550 minecraft:blackstone
fill 119 71 539 127 71 539 minecraft:blackstone
fill 119 71 549 122 71 549 minecraft:blackstone
setblock 120 71 512 minecraft:smooth_basalt
fill 120 71 548 123 71 548 minecraft:blackstone
fill 121 71 512 121 74 512 minecraft:blackstone
setblock 121 71 551 minecraft:smooth_basalt
fill 122 71 511 122 71 512 minecraft:gold_block
fill 122 71 538 128 71 538 minecraft:blackstone
setblock 122 71 550 minecraft:smooth_basalt
fill 122 71 551 125 71 551 minecraft:blackstone
fill 123 71 511 127 71 513 minecraft:blackstone
fill 123 71 537 129 71 537 minecraft:blackstone
setblock 123 71 549 minecraft:smooth_basalt
fill 123 71 550 126 71 550 minecraft:blackstone
setblock 124 71 548 minecraft:smooth_basalt
fill 124 71 549 127 71 549 minecraft:blackstone
fill 125 71 514 127 71 514 minecraft:blackstone
fill 125 71 536 130 71 536 minecraft:blackstone
fill 125 71 548 126 71 548 minecraft:blackstone
fill 126 71 515 127 71 515 minecraft:blackstone
fill 126 71 535 127 71 535 minecraft:blackstone
setblock 126 71 551 minecraft:smooth_basalt
fill 127 71 517 132 71 517 minecraft:blackstone
fill 127 71 533 131 71 534 minecraft:blackstone
setblock 127 71 550 minecraft:smooth_basalt
fill 127 71 551 130 71 551 minecraft:blackstone
fill 128 71 518 132 71 518 minecraft:blackstone
fill 128 71 532 132 71 532 minecraft:blackstone
setblock 128 71 549 minecraft:smooth_basalt
fill 128 71 550 131 71 550 minecraft:blackstone
fill 129 71 511 129 72 511 minecraft:blackstone
fill 129 71 519 130 71 521 minecraft:blackstone
setblock 129 71 529 minecraft:gold_block
fill 129 71 530 132 71 531 minecraft:blackstone
fill 130 71 524 130 71 528 minecraft:blackstone
fill 131 71 519 131 71 520 minecraft:blackstone
fill 131 71 524 133 71 525 minecraft:blackstone
setblock 131 71 551 minecraft:smooth_basalt
setblock 132 71 533 minecraft:blackstone
fill 132 71 551 132 72 551 minecraft:blackstone
setblock 133 71 526 minecraft:blackstone
setblock 134 71 527 minecraft:blackstone
setblock 134 71 528 minecraft:smooth_basalt
fill 134 71 529 134 71 532 minecraft:blackstone
setblock 134 71 533 minecraft:smooth_basalt
fill 134 71 534 134 74 534 minecraft:blackstone
setblock 135 71 526 minecraft:blackstone
setblock 135 71 527 minecraft:smooth_basalt
fill 135 71 528 135 74 528 minecraft:blackstone
setblock 135 71 531 minecraft:blackstone
setblock 135 71 532 minecraft:smooth_basalt
fill 135 71 533 135 74 533 minecraft:blackstone
fill 135 71 535 135 71 536 minecraft:blackstone
setblock 135 71 537 minecraft:smooth_basalt
setblock 135 71 547 minecraft:smooth_basalt
setblock 135 71 548 minecraft:blackstone
setblock 95 72 511 minecraft:smooth_basalt
fill 95 72 512 95 75 512 minecraft:blackstone
fill 95 72 514 95 73 514 minecraft:blackstone
fill 95 72 522 95 72 525 minecraft:blackstone
setblock 95 72 526 minecraft:smooth_basalt
fill 95 72 527 95 72 530 minecraft:blackstone
setblock 95 72 531 minecraft:smooth_basalt
fill 95 72 532 95 75 532 minecraft:blackstone
fill 96 72 511 99 72 511 minecraft:blackstone
setblock 96 72 524 minecraft:blackstone
setblock 96 72 525 minecraft:smooth_basalt
fill 96 72 526 96 72 529 minecraft:blackstone
setblock 96 72 530 minecraft:smooth_basalt
fill 96 72 531 97 72 531 minecraft:blackstone
fill 96 72 551 99 72 551 minecraft:blackstone
fill 97 72 512 98 72 512 minecraft:blackstone
fill 97 72 527 97 72 528 minecraft:blackstone
setblock 97 72 529 minecraft:smooth_basalt
fill 97 72 530 97 73 530 minecraft:blackstone
setblock 99 72 512 minecraft:smooth_basalt
fill 99 72 513 102 72 513 minecraft:blackstone
fill 99 72 550 100 72 550 minecraft:blackstone
setblock 100 72 511 minecraft:smooth_basalt
fill 100 72 512 100 75 512 minecraft:blackstone
setblock 100 72 551 minecraft:smooth_basalt
fill 101 72 511 101 75 511 minecraft:blackstone
setblock 101 72 550 minecraft:smooth_basalt
fill 101 72 551 104 72 551 minecraft:blackstone
fill 102 72 512 103 72 512 minecraft:blackstone
fill 102 72 550 105 72 550 minecraft:blackstone
fill 103 72 511 104 72 511 minecraft:blackstone
setblock 103 72 513 minecraft:smooth_basalt
fill 103 72 549 105 72 549 minecraft:blackstone
fill 104 72 510 126 79 510 minecraft:gilded_blackstone
setblock 104 72 512 minecraft:smooth_basalt
fill 104 72 513 107 72 513 minecraft:blackstone
setblock 105 72 511 minecraft:smooth_basalt
fill 105 72 512 108 72 512 minecraft:blackstone
setblock 105 72 551 minecraft:smooth_basalt
fill 106 72 511 109 72 511 minecraft:blackstone
setblock 106 72 550 minecraft:smooth_basalt
fill 106 72 551 109 72 551 minecraft:blackstone
fill 107 72 550 110 72 550 minecraft:blackstone
setblock 109 72 512 minecraft:smooth_basalt
setblock 110 72 511 minecraft:smooth_basalt
fill 110 72 512 112 72 512 minecraft:blackstone
setblock 110 72 551 minecraft:smooth_basalt
fill 111 72 511 114 72 511 minecraft:blackstone
setblock 111 72 550 minecraft:smooth_basalt
fill 111 72 551 114 72 551 minecraft:blackstone
fill 112 72 550 115 72 550 minecraft:blackstone
setblock 115 72 511 minecraft:smooth_basalt
setblock 115 72 551 minecraft:smooth_basalt
fill 116 72 511 118 72 512 minecraft:blackstone
setblock 116 72 550 minecraft:smooth_basalt
fill 116 72 551 119 72 551 minecraft:blackstone
setblock 117 72 549 minecraft:smooth_basalt
fill 117 72 550 120 72 550 minecraft:blackstone
fill 118 72 549 121 72 549 minecraft:blackstone
setblock 119 72 511 minecraft:blackstone
setblock 119 72 512 minecraft:smooth_basalt
setblock 120 72 511 minecraft:smooth_basalt
fill 120 72 512 120 75 512 minecraft:blackstone
fill 120 72 548 122 72 548 minecraft:blackstone
setblock 120 72 551 minecraft:smooth_basalt
fill 121 72 511 124 72 511 minecraft:blackstone
setblock 121 72 550 minecraft:smooth_basalt
fill 121 72 551 124 72 551 minecraft:blackstone
fill 122 72 512 123 72 512 minecraft:blackstone
setblock 122 72 549 minecraft:smooth_basalt
fill 122 72 550 125 72 550 minecraft:blackstone
setblock 123 72 548 minecraft:smooth_basalt
fill 123 72 549 126 72 549 minecraft:blackstone
setblock 124 72 512 minecraft:smooth_basalt
setblock 124 72 548 minecraft:blackstone
setblock 125 72 511 minecraft:smooth_basalt
fill 125 72 512 125 73 512 minecraft:blackstone
setblock 125 72 551 minecraft:smooth_basalt
fill 126 72 511 127 74 511 minecraft:blackstone
setblock 126 72 550 minecraft:smooth_basalt
fill 126 72 551 129 72 551 minecraft:blackstone
setblock 127 72 549 minecraft:smooth_basalt
fill 127 72 550 129 72 550 minecraft:blackstone
setblock 130 72 551 minecraft:smooth_basalt
fill 131 72 551 131 73 551 minecraft:blackstone
setblock 134 72 527 minecraft:smooth_basalt
fill 134 72 528 134 72 531 minecraft:blackstone
setblock 134 72 532 minecraft:smooth_basalt
fill 134 72 533 134 75 533 minecraft:blackstone
setblock 134 72 551 minecraft:blackstone
setblock 135 72 526 minecraft:smooth_basalt
fill 135 72 527 135 75 527 minecraft:blackstone
setblock 135 72 531 minecraft:smooth_basalt
fill 135 72 532 135 75 532 minecraft:blackstone
setblock 135 72 535 minecraft:blackstone
setblock 135 72 536 minecraft:smooth_basalt
fill 135 72 537 135 75 537 minecraft:blackstone
setblock 135 72 551 minecraft:smooth_basalt
fill 95 73 511 98 73 511 minecraft:blackstone
setblock 95 73 515 minecraft:smooth_basalt
fill 95 73 522 95 73 524 minecraft:blackstone
setblock 95 73 525 minecraft:smooth_basalt
fill 95 73 526 95 73 529 minecraft:blackstone
setblock 95 73 530 minecraft:smooth_basalt
fill 95 73 531 96 75 531 minecraft:blackstone
setblock 95 73 535 minecraft:smooth_basalt
fill 96 73 512 97 73 512 minecraft:blackstone
fill 96 73 525 96 73 528 minecraft:blackstone
setblock 96 73 529 minecraft:smooth_basalt
fill 96 73 530 96 76 530 minecraft:blackstone
fill 96 73 551 98 73 551 minecraft:blackstone
setblock 97 73 528 minecraft:smooth_basalt
setblock 97 73 529 minecraft:blackstone
setblock 98 73 512 minecraft:smooth_basalt
setblock 99 73 511 minecraft:smooth_basalt
fill 99 73 512 99 75 513 minecraft:blackstone
setblock 99 73 550 minecraft:blackstone
setblock 99 73 551 minecraft:smooth_basalt
fill 100 73 511 100 76 511 minecraft:blackstone
fill 100 73 513 101 73 513 minecraft:blackstone
setblock 100 73 550 minecraft:smooth_basalt
fill 100 73 551 103 73 551 minecraft:blackstone
fill 101 73 550 104 73 550 minecraft:blackstone
setblock 102 73 512 minecraft:blackstone
setblock 102 73 513 minecraft:smooth_basalt
setblock 103 73 511 minecraft:blackstone
setblock 103 73 512 minecraft:smooth_basalt
fill 103 73 513 106 73 513 minecraft:blackstone
setblock 104 73 511 minecraft:smooth_basalt
fill 104 73 512 107 73 512 minecraft:blackstone
setblock 104 73 551 minecraft:smooth_basalt
fill 105 73 511 108 73 511 minecraft:blackstone
setblock 105 73 550 minecraft:smooth_basalt
fill 105 73 551 108 73 551 minecraft:blackstone
fill 106 73 550 109 73 550 minecraft:blackstone
setblock 108 73 512 minecraft:smooth_basalt
setblock 109 73 511 minecraft:smooth_basalt
fill 109 73 512 111 73 512 minecraft:blackstone
setblock 109 73 551 minecraft:smooth_basalt
fill 110 73 511 113 73 511 minecraft:blackstone
setblock 110 73 550 minecraft:smooth_basalt
fill 110 73 551 113 73 551 minecraft:blackstone
fill 111 73 550 114 73 550 minecraft:blackstone
setblock 114 73 511 minecraft:smooth_basalt
setblock 114 73 551 minecraft:smooth_basalt
fill 115 73 511 117 73 512 minecraft:blackstone
setblock 115 73 550 minecraft:smooth_basalt
fill 115 73 551 118 73 551 minecraft:blackstone
fill 116 73 550 119 73 550 minecraft:blackstone
fill 117 73 549 120 73 549 minecraft:blackstone
setblock 118 73 511 minecraft:blackstone
setblock 118 73 512 minecraft:smooth_basalt
setblock 119 73 511 minecraft:smooth_basalt
fill 119 73 512 119 76 512 minecraft:blackstone
setblock 119 73 551 minecraft:smooth_basalt
fill 120 73 511 123 73 511 minecraft:blackstone
setblock 120 73 550 minecraft:smooth_basalt
fill 120 73 551 123 73 551 minecraft:blackstone
setblock 121 73 549 minecraft:smooth_basalt
fill 121 73 550 124 73 550 minecraft:blackstone
setblock 122 73 512 minecraft:blackstone
fill 122 73 549 125 73 549 minecraft:blackstone
setblock 123 73 512 minecraft:smooth_basalt
setblock 124 73 511 minecraft:smooth_basalt
fill 124 73 512 124 74 512 minecraft:blackstone
setblock 124 73 551 minecraft:smooth_basalt
fill 125 73 511 125 76 511 minecraft:blackstone
setblock 125 73 550 minecraft:smooth_basalt
fill 125 73 551 128 73 551 minecraft:blackstone
setblock 126 73 549 minecraft:smooth_basalt
fill 126 73 550 128 73 550 minecraft:blackstone
setblock 129 73 551 minecraft:smooth_basalt
setblock 130 73 551 minecraft:blackstone
fill 134 73 528 134 73 530 minecraft:blackstone
setblock 134 73 531 minecraft:smooth_basalt
fill 134 73 532 134 76 532 minecraft:blackstone
setblock 135 73 525 minecraft:smooth_basalt
fill 135 73 526 135 76 526 minecraft:blackstone
setblock 135 73 530 minecraft:smooth_basalt
fill 135 73 531 135 76 531 minecraft:blackstone
setblock 135 73 535 minecraft:smooth_basalt
fill 135 73 536 135 76 536 minecraft:blackstone
fill 95 74 511 97 74 511 minecraft:blackstone
setblock 95 74 514 minecraft:smooth_basalt
fill 95 74 515 95 75 517 minecraft:blackstone
setblock 95 74 523 minecraft:blackstone
setblock 95 74 524 minecraft:smooth_basalt
fill 95 74 525 95 74 528 minecraft:blackstone
setblock 95 74 529 minecraft:smooth_basalt
fill 95 74 530 95 77 530 minecraft:blackstone
setblock 95 74 534 minecraft:smooth_basalt
fill 95 74 535 95 77 535 minecraft:blackstone
setblock 96 74 512 minecraft:blackstone
setblock 96 74 513 minecraft:smooth_basalt
fill 96 74 514 96 77 514 minecraft:blackstone
fill 96 74 526 96 74 527 minecraft:blackstone
setblock 96 74 528 minecraft:smooth_basalt
fill 96 74 529 96 77 529 minecraft:blackstone
setblock 96 74 533 minecraft:smooth_basalt
fill 96 74 551 97 74 551 minecraft:blackstone
setblock 97 74 512 minecraft:smooth_basalt
setblock 98 74 511 minecraft:smooth_basalt
fill 98 74 512 98 76 513 minecraft:blackstone
setblock 98 74 551 minecraft:smooth_basalt
fill 99 74 511 99 77 511 minecraft:blackstone
setblock 99 74 550 minecraft:smooth_basalt
fill 99 74 551 102 74 551 minecraft:blackstone
setblock 100 74 513 minecraft:blackstone
fill 100 74 550 103 74 550 minecraft:blackstone
setblock 101 74 513 minecraft:smooth_basalt
setblock 102 74 512 minecraft:smooth_basalt
fill 102 74 513 105 74 513 minecraft:blackstone
setblock 103 74 511 minecraft:smooth_basalt
fill 103 74 512 106 74 512 minecraft:blackstone
setblock 103 74 551 minecraft:smooth_basalt
fill 104 74 511 107 74 511 minecraft:blackstone
setblock 104 74 550 minecraft:smooth_basalt
fill 104 74 551 107 74 551 minecraft:blackstone
fill 105 74 550 107 74 550 minecraft:blackstone
setblock 106 74 513 minecraft:smooth_basalt
setblock 107 74 512 minecraft:smooth_basalt
setblock 108 74 511 minecraft:smooth_basalt
fill 108 74 512 110 74 512 minecraft:blackstone
setblock 108 74 551 minecraft:smooth_basalt
fill 109 74 511 112 74 511 minecraft:blackstone
fill 109 74 551 112 74 551 minecraft:blackstone
setblock 113 74 511 minecraft:smooth_basalt
setblock 113 74 551 minecraft:smooth_basalt
fill 114 74 511 117 74 511 minecraft:blackstone
setblock 114 74 550 minecraft:smooth_basalt
fill 114 74 551 117 74 551 minecraft:blackstone
fill 115 74 512 116 74 512 minecraft:blackstone
fill 115 74 550 118 74 550 minecraft:blackstone
setblock 117 74 512 minecraft:smooth_basalt
setblock 118 74 511 minecraft:smooth_basalt
fill 118 74 512 118 77 512 minecraft:blackstone
fill 118 74 549 119 74 549 minecraft:blackstone
setblock 118 74 551 minecraft:smooth_basalt
fill 119 74 511 122 74 511 minecraft:blackstone
setblock 119 74 550 minecraft:smooth_basalt
fill 119 74 551 122 74 551 minecraft:blackstone
setblock 120 74 549 minecraft:smooth_basalt
fill 120 74 550 123 74 550 minecraft:blackstone
fill 121 74 549 124 74 549 minecraft:blackstone
setblock 122 74 512 minecraft:smooth_basalt
setblock 123 74 511 minecraft:smooth_basalt
fill 123 74 512 123 77 512 minecraft:blackstone
setblock 123 74 551 minecraft:smooth_basalt
fill 124 74 511 124 77 511 minecraft:blackstone
setblock 124 74 550 minecraft:smooth_basalt
fill 124 74 551 127 74 551 minecraft:blackstone
fill 125 74 550 127 74 550 minecraft:blackstone
setblock 128 74 551 minecraft:smooth_basalt
setblock 129 74 551 minecraft:blackstone
setblock 134 74 529 minecraft:blackstone
setblock 134 74 530 minecraft:smooth_basalt
fill 134 74 531 134 77 531 minecraft:blackstone
setblock 135 74 525 minecraft:blackstone
setblock 135 74 529 minecraft:smooth_basalt
fill 135 74 530 135 77 530 minecraft:blackstone
setblock 135 74 534 minecraft:smooth_basalt
fill 135 74 535 135 77 535 minecraft:blackstone
fill 95 75 511 96 75 511 minecraft:blackstone
setblock 95 75 513 minecraft:smooth_basalt
fill 95 75 514 95 78 514 minecraft:blackstone
setblock 95 75 518 minecraft:smooth_basalt
fill 95 75 524 95 75 527 minecraft:blackstone
setblock 95 75 528 minecraft:smooth_basalt
fill 95 75 529 95 78 529 minecraft:blackstone
setblock 95 75 533 minecraft:smooth_basalt
fill 95 75 534 96 77 534 minecraft:blackstone
fill 95 75 536 95 76 536 minecraft:blackstone
setblock 96 75 512 minecraft:smooth_basalt
fill 96 75 513 96 78 513 minecraft:blackstone
fill 96 75 515 96 76 515 minecraft:blackstone
setblock 96 75 527 minecraft:smooth_basalt
fill 96 75 528 96 78 528 minecraft:blackstone
setblock 96 75 532 minecraft:smooth_basalt
fill 96 75 533 96 78 533 minecraft:blackstone
setblock 96 75 551 minecraft:blackstone
setblock 97 75 511 minecraft:smooth_basalt
fill 97 75 512 97 78 512 minecraft:blackstone
setblock 97 75 551 minecraft:smooth_basalt
fill 98 75 511 98 78 511 minecraft:blackstone
fill 98 75 551 101 75 551 minecraft:blackstone
setblock 100 75 513 minecraft:smooth_basalt
fill 100 75 550 102 75 550 minecraft:blackstone
setblock 101 75 512 minecraft:smooth_basalt
fill 101 75 513 104 75 513 minecraft:blackstone
setblock 102 75 511 minecraft:smooth_basalt
fill 102 75 512 105 75 512 minecraft:blackstone
setblock 102 75 551 minecraft:smooth_basalt
fill 103 75 511 106 75 511 minecraft:blackstone
setblock 103 75 550 minecraft:smooth_basalt
fill 103 75 551 106 75 551 minecraft:blackstone
fill 104 75 550 105 75 550 minecraft:blackstone
setblock 105 75 513 minecraft:smooth_basalt
setblock 106 75 512 minecraft:smooth_basalt
setblock 107 75 511 minecraft:smooth_basalt
fill 107 75 512 109 76 512 minecraft:blackstone
setblock 107 75 551 minecraft:smooth_basalt
fill 108 75 511 111 75 511 minecraft:blackstone
fill 108 75 551 111 75 551 minecraft:blackstone
setblock 112 75 511 minecraft:smooth_basalt
setblock 112 75 551 minecraft:smooth_basalt
fill 113 75 511 116 75 511 minecraft:blackstone
fill 113 75 551 116 75 551 minecraft:blackstone
fill 114 75 550 117 75 550 minecraft:blackstone
setblock 115 75 512 minecraft:blackstone
setblock 116 75 512 minecraft:smooth_basalt
setblock 117 75 511 minecraft:smooth_basalt
fill 117 75 512 117 78 512 minecraft:blackstone
setblock 117 75 551 minecraft:smooth_basalt
fill 118 75 511 121 75 511 minecraft:blackstone
setblock 118 75 550 minecraft:smooth_basalt
fill 118 75 551 121 75 551 minecraft:blackstone
setblock 119 75 549 minecraft:smooth_basalt
fill 119 75 550 122 75 550 minecraft:blackstone
fill 120 75 549 122 75 549 minecraft:blackstone
setblock 121 75 512 minecraft:smooth_basalt
setblock 122 75 511 minecraft:smooth_basalt
fill 122 75 512 122 78 512 minecraft:blackstone
setblock 122 75 551 minecraft:smooth_basalt
fill 123 75 511 123 78 511 minecraft:blackstone
setblock 123 75 550 minecraft:smooth_basalt
fill 123 75 551 126 75 551 minecraft:blackstone
fill 124 75 550 125 75 550 minecraft:blackstone
setblock 126 75 511 minecraft:blackstone
setblock 127 75 551 minecraft:smooth_basalt
setblock 128 75 551 minecraft:blackstone
setblock 134 75 529 minecraft:smooth_basalt
fill 134 75 530 134 78 530 minecraft:blackstone
setblock 134 75 534 minecraft:smooth_basalt
fill 134 75 535 134 78 535 minecraft:blackstone
setblock 135 75 528 minecraft:smooth_basalt
fill 135 75 529 135 78 529 minecraft:blackstone
setblock 135 75 533 minecraft:smooth_basalt
fill 135 75 534 135 78 534 minecraft:blackstone
setblock 135 75 538 minecraft:smooth_basalt
setblock 95 76 511 minecraft:blackstone
setblock 95 76 512 minecraft:smooth_basalt
fill 95 76 513 95 79 513 minecraft:blackstone
fill 95 76 515 95 76 516 minecraft:blackstone
setblock 95 76 517 minecraft:smooth_basalt
fill 95 76 518 95 76 521 minecraft:blackstone
fill 95 76 524 95 76 526 minecraft:blackstone
setblock 95 76 527 minecraft:smooth_basalt
fill 95 76 528 95 79 528 minecraft:blackstone
setblock 95 76 531 minecraft:blackstone
setblock 95 76 532 minecraft:smooth_basalt
fill 95 76 533 95 79 533 minecraft:blackstone
setblock 96 76 511 minecraft:smooth_basalt
fill 96 76 512 96 79 512 minecraft:blackstone
setblock 96 76 516 minecraft:smooth_basalt
fill 96 76 517 96 79 517 minecraft:blackstone
setblock 96 76 531 minecraft:smooth_basalt
fill 96 76 532 96 79 532 minecraft:blackstone
setblock 96 76 551 minecraft:smooth_basalt
fill 97 76 511 97 79 511 minecraft:blackstone
fill 97 76 513 97 76 514 minecraft:blackstone
setblock 97 76 515 minecraft:smooth_basalt
fill 97 76 551 100 76 551 minecraft:blackstone
setblock 99 76 512 minecraft:blackstone
setblock 99 76 513 minecraft:smooth_basalt
setblock 100 76 512 minecraft:smooth_basalt
fill 100 76 513 103 76 513 minecraft:blackstone
fill 100 76 550 101 76 550 minecraft:blackstone
setblock 101 76 511 minecraft:smooth_basalt
fill 101 76 512 104 76 512 minecraft:blackstone
setblock 101 76 551 minecraft:smooth_basalt
fill 102 76 511 105 76 511 minecraft:blackstone
setblock 102 76 550 minecraft:smooth_basalt
fill 102 76 551 105 76 551 minecraft:blackstone
setblock 103 76 550 minecraft:blackstone
setblock 104 76 513 minecraft:smooth_basalt
setblock 105 76 512 minecraft:smooth_basalt
fill 105 76 513 105 79 513 minecraft:blackstone
setblock 106 76 511 minecraft:smooth_basalt
fill 106 76 512 106 79 512 minecraft:blackstone
setblock 106 76 551 minecraft:smooth_basalt
fill 107 76 511 110 76 511 minecraft:blackstone
fill 107 76 551 110 76 551 minecraft:blackstone
setblock 111 76 511 minecraft:smooth_basalt
setblock 111 76 551 minecraft:smooth_basalt
fill 112 76 511 115 76 511 minecraft:blackstone
fill 112 76 551 115 76 551 minecraft:blackstone
setblock 114 76 512 minecraft:blackstone
setblock 115 76 512 minecraft:smooth_basalt
fill 115 76 550 116 76 550 minecraft:blackstone
setblock 116 76 511 minecraft:smooth_basalt
fill 116 76 512 116 79 512 minecraft:blackstone
setblock 116 76 551 minecraft:smooth_basalt
fill 117 76 511 120 76 511 minecraft:blackstone
setblock 117 76 550 minecraft:smooth_basalt
fill 117 76 551 120 76 551 minecraft:blackstone
fill 118 76 550 121 76 550 minecraft:blackstone
setblock 120 76 512 minecraft:smooth_basalt
setblock 120 76 549 minecraft:blackstone
setblock 121 76 511 minecraft:smooth_basalt
fill 121 76 512 121 79 512 minecraft:blackstone
setblock 121 76 551 minecraft:smooth_basalt
fill 122 76 511 122 79 511 minecraft:blackstone
setblock 122 76 550 minecraft:smooth_basalt
fill 122 76 551 125 76 551 minecraft:blackstone
fill 123 76 550 124 76 550 minecraft:blackstone
setblock 126 76 511 minecraft:smooth_basalt
setblock 126 76 551 minecraft:smooth_basalt
setblock 127 76 551 minecraft:blackstone
fill 134 76 529 134 79 529 minecraft:blackstone
setblock 134 76 533 minecraft:smooth_basalt
fill 134 76 534 134 79 534 minecraft:blackstone
fill 134 76 536 134 77 536 minecraft:blackstone
setblock 135 76 511 minecraft:blackstone
setblock 135 76 512 minecraft:smooth_basalt
fill 135 76 513 135 78 514 minecraft:blackstone
setblock 135 76 527 minecraft:smooth_basalt
fill 135 76 528 135 79 528 minecraft:blackstone
setblock 135 76 532 minecraft:smooth_basalt
fill 135 76 533 135 79 533 minecraft:blackstone
setblock 135 76 537 minecraft:smooth_basalt
fill 135 76 538 135 79 538 minecraft:blackstone
setblock 95 77 511 minecraft:smooth_basalt
fill 95 77 512 95 80 512 minecraft:blackstone
setblock 95 77 515 minecraft:blackstone
setblock 95 77 516 minecraft:smooth_basalt
fill 95 77 517 95 77 520 minecraft:blackstone
setblock 95 77 521 minecraft:smooth_basalt
fill 95 77 522 95 77 525 minecraft:blackstone
setblock 95 77 526 minecraft:smooth_basalt
fill 95 77 527 95 80 527 minecraft:blackstone
setblock 95 77 531 minecraft:smooth_basalt
fill 95 77 532 95 80 532 minecraft:blackstone
setblock 95 77 536 minecraft:smooth_basalt
fill 95 77 537 95 80 537 minecraft:blackstone
fill 96 77 511 96 80 511 minecraft:blackstone
setblock 96 77 515 minecraft:smooth_basalt
fill 96 77 516 97 79 516 minecraft:blackstone
fill 96 77 518 96 77 519 minecraft:blackstone
setblock 96 77 530 minecraft:smooth_basalt
fill 96 77 531 96 80 531 minecraft:blackstone
setblock 96 77 535 minecraft:smooth_basalt
fill 96 77 551 99 77 551 minecraft:blackstone
setblock 97 77 513 minecraft:blackstone
setblock 97 77 514 minecraft:smooth_basalt
fill 97 77 515 97 80 515 minecraft:blackstone
fill 97 77 517 97 78 517 minecraft:blackstone
setblock 97 77 521 minecraft:light[level=12]
setblock 97 77 529 minecraft:light[level=12]
setblock 97 77 537 minecraft:light[level=12]
setblock 97 77 545 minecraft:light[level=12]
setblock 98 77 512 minecraft:blackstone
setblock 98 77 513 minecraft:smooth_basalt
setblock 99 77 512 minecraft:smooth_basalt
fill 99 77 513 101 77 514 minecraft:blackstone
setblock 100 77 511 minecraft:smooth_basalt
fill 100 77 512 103 77 512 minecraft:blackstone
setblock 100 77 551 minecraft:smooth_basalt
fill 101 77 511 104 77 511 minecraft:blackstone
fill 101 77 551 104 77 551 minecraft:blackstone
setblock 102 77 513 minecraft:blackstone
setblock 103 77 513 minecraft:smooth_basalt
setblock 104 77 512 minecraft:smooth_basalt
fill 104 77 513 104 80 513 minecraft:blackstone
setblock 105 77 511 minecraft:smooth_basalt
fill 105 77 512 105 80 512 minecraft:blackstone
setblock 105 77 521 minecraft:light[level=12]
setblock 105 77 529 minecraft:light[level=12]
setblock 105 77 537 minecraft:light[level=12]
setblock 105 77 545 minecraft:light[level=12]
setblock 105 77 551 minecraft:smooth_basalt
fill 106 77 511 109 77 511 minecraft:blackstone
fill 106 77 551 109 77 551 minecraft:blackstone
fill 107 77 512 108 77 512 minecraft:blackstone
setblock 109 77 512 minecraft:smooth_basalt
setblock 110 77 511 minecraft:smooth_basalt
setblock 110 77 551 minecraft:smooth_basalt
fill 111 77 511 114 77 511 minecraft:blackstone
fill 111 77 551 114 77 551 minecraft:blackstone
setblock 113 77 513 minecraft:light[level=12]
setblock 113 77 521 minecraft:light[level=12]
setblock 113 77 529 minecraft:light[level=12]
setblock 113 77 537 minecraft:light[level=12]
setblock 113 77 545 minecraft:light[level=12]
setblock 114 77 512 minecraft:smooth_basalt
setblock 115 77 511 minecraft:smooth_basalt
fill 115 77 512 115 80 512 minecraft:blackstone
setblock 115 77 550 minecraft:blackstone
setblock 115 77 551 minecraft:smooth_basalt
fill 116 77 511 119 77 511 minecraft:blackstone
setblock 116 77 550 minecraft:smooth_basalt
fill 116 77 551 119 77 551 minecraft:blackstone
fill 117 77 550 120 77 550 minecraft:blackstone
setblock 119 77 512 minecraft:smooth_basalt
setblock 120 77 511 minecraft:smooth_basalt
fill 120 77 512 120 80 512 minecraft:blackstone
setblock 120 77 551 minecraft:smooth_basalt
fill 121 77 511 121 80 511 minecraft:blackstone
setblock 121 77 513 minecraft:light[level=12]
setblock 121 77 521 minecraft:light[level=12]
setblock 121 77 529 minecraft:light[level=12]
setblock 121 77 537 minecraft:light[level=12]
setblock 121 77 545 minecraft:light[level=12]
setblock 121 77 550 minecraft:smooth_basalt
fill 121 77 551 124 77 551 minecraft:blackstone
fill 122 77 550 123 77 550 minecraft:blackstone
setblock 125 77 511 minecraft:smooth_basalt
setblock 125 77 551 minecraft:smooth_basalt
setblock 126 77 551 minecraft:blackstone
setblock 129 77 513 minecraft:light[level=12]
setblock 129 77 521 minecraft:light[level=12]
setblock 129 77 529 minecraft:light[level=12]
setblock 129 77 537 minecraft:light[level=12]
setblock 129 77 545 minecraft:light[level=12]
setblock 134 77 532 minecraft:smooth_basalt
fill 134 77 533 134 80 533 minecraft:blackstone
setblock 134 77 537 minecraft:smooth_basalt
setblock 135 77 511 minecraft:smooth_basalt
fill 135 77 512 135 80 512 minecraft:blackstone
setblock 135 77 515 minecraft:blackstone
setblock 135 77 516 minecraft:smooth_basalt
fill 135 77 517 135 80 517 minecraft:blackstone
setblock 135 77 525 minecraft:blackstone
setblock 135 77 526 minecraft:smooth_basalt
fill 135 77 527 135 80 527 minecraft:blackstone
setblock 135 77 531 minecraft:smooth_basalt
fill 135 77 532 135 80 532 minecraft:blackstone
setblock 135 77 536 minecraft:smooth_basalt
fill 135 77 537 135 80 537 minecraft:blackstone
fill 135 77 539 135 78 539 minecraft:blackstone
fill 95 78 511 95 81 511 minecraft:blackstone
setblock 95 78 515 minecraft:smooth_basalt
fill 95 78 516 95 78 519 minecraft:blackstone
setblock 95 78 520 minecraft:smooth_basalt
fill 95 78 521 95 78 524 minecraft:blackstone
setblock 95 78 525 minecraft:smooth_basalt
fill 95 78 526 95 81 526 minecraft:blackstone
setblock 95 78 530 minecraft:smooth_basalt
fill 95 78 531 95 81 531 minecraft:blackstone
setblock 95 78 534 minecraft:blackstone
setblock 95 78 535 minecraft:smooth_basalt
fill 95 78 536 96 80 536 minecraft:blackstone
fill 95 78 538 95 79 538 minecraft:blackstone
setblock 96 78 514 minecraft:smooth_basalt
fill 96 78 515 96 81 515 minecraft:blackstone
setblock 96 78 518 minecraft:blackstone
setblock 96 78 519 minecraft:smooth_basalt
fill 96 78 520 96 80 521 minecraft:blackstone
setblock 96 78 529 minecraft:smooth_basalt
fill 96 78 530 96 81 530 minecraft:blackstone
setblock 96 78 534 minecraft:smooth_basalt
fill 96 78 535 96 81 535 minecraft:blackstone
fill 96 78 551 98 78 551 minecraft:blackstone
setblock 97 78 513 minecraft:smooth_basalt
fill 97 78 514 100 78 514 minecraft:blackstone
setblock 97 78 518 minecraft:smooth_basalt
setblock 98 78 512 minecraft:smooth_basalt
fill 98 78 513 101 78 513 minecraft:blackstone
fill 98 78 515 98 79 515 minecraft:blackstone
setblock 99 78 511 minecraft:smooth_basalt
fill 99 78 512 102 78 512 minecraft:blackstone
setblock 99 78 551 minecraft:smooth_basalt
fill 100 78 511 103 78 511 minecraft:blackstone
fill 100 78 551 103 78 551 minecraft:blackstone
setblock 101 78 514 minecraft:smooth_basalt
setblock 102 78 513 minecraft:smooth_basalt
fill 102 78 514 102 81 514 minecraft:blackstone
setblock 103 78 512 minecraft:smooth_basalt
fill 103 78 513 103 81 513 minecraft:blackstone
setblock 104 78 511 minecraft:smooth_basalt
fill 104 78 512 104 81 512 minecraft:blackstone
setblock 104 78 551 minecraft:smooth_basalt
fill 105 78 511 108 78 511 minecraft:blackstone
fill 105 78 551 108 78 551 minecraft:blackstone
setblock 107 78 512 minecraft:blackstone
setblock 108 78 512 minecraft:smooth_basalt
setblock 109 78 511 minecraft:smooth_basalt
fill 109 78 512 109 81 512 minecraft:blackstone
setblock 109 78 551 minecraft:smooth_basalt
fill 110 78 511 113 78 511 minecraft:blackstone
fill 110 78 551 113 78 551 minecraft:blackstone
setblock 112 78 512 minecraft:blackstone
setblock 113 78 512 minecraft:smooth_basalt
setblock 114 78 511 minecraft:smooth_basalt
fill 114 78 512 114 81 512 minecraft:blackstone
setblock 114 78 550 minecraft:blackstone
setblock 114 78 551 minecraft:smooth_basalt
fill 115 78 511 118 78 511 minecraft:blackstone
setblock 115 78 550 minecraft:smooth_basalt
fill 115 78 551 118 78 551 minecraft:blackstone
fill 116 78 550 119 78 550 minecraft:blackstone
setblock 118 78 512 minecraft:smooth_basalt
setblock 119 78 511 minecraft:smooth_basalt
fill 119 78 512 119 81 512 minecraft:blackstone
setblock 119 78 551 minecraft:smooth_basalt
fill 120 78 511 120 81 511 minecraft:blackstone
setblock 120 78 550 minecraft:smooth_basalt
fill 120 78 551 123 78 551 minecraft:blackstone
fill 121 78 550 122 79 550 minecraft:blackstone
setblock 124 78 511 minecraft:smooth_basalt
setblock 124 78 551 minecraft:smooth_basalt
setblock 125 78 511 minecraft:blackstone
setblock 125 78 551 minecraft:blackstone
setblock 134 78 511 minecraft:smooth_basalt
setblock 134 78 531 minecraft:smooth_basalt
fill 134 78 532 134 81 532 minecraft:blackstone
setblock 134 78 536 minecraft:smooth_basalt
fill 134 78 537 134 80 538 minecraft:blackstone
fill 135 78 511 135 81 511 minecraft:blackstone
setblock 135 78 515 minecraft:smooth_basalt
fill 135 78 516 135 81 516 minecraft:blackstone
fill 135 78 518 135 78 519 minecraft:blackstone
setblock 135 78 520 minecraft:smooth_basalt
fill 135 78 521 135 78 524 minecraft:blackstone
setblock 135 78 525 minecraft:smooth_basalt
fill 135 78 526 135 81 526 minecraft:blackstone
setblock 135 78 530 minecraft:smooth_basalt
fill 135 78 531 135 81 531 minecraft:blackstone
setblock 135 78 535 minecraft:smooth_basalt
fill 135 78 536 135 81 536 minecraft:blackstone
setblock 135 78 540 minecraft:smooth_basalt
setblock 95 79 514 minecraft:smooth_basalt
fill 95 79 515 95 79 518 minecraft:blackstone
setblock 95 79 519 minecraft:smooth_basalt
fill 95 79 520 95 79 523 minecraft:blackstone
setblock 95 79 524 minecraft:smooth_basalt
fill 95 79 525 95 82 525 minecraft:blackstone
setblock 95 79 529 minecraft:smooth_basalt
fill 95 79 530 95 82 530 minecraft:blackstone
setblock 95 79 534 minecraft:smooth_basalt
fill 95 79 535 95 82 535 minecraft:blackstone
setblock 95 79 539 minecraft:smooth_basalt
fill 95 79 540 95 82 540 minecraft:blackstone
fill 95 79 551 97 79 551 minecraft:blackstone
setblock 96 79 513 minecraft:smooth_basalt
fill 96 79 514 99 79 514 minecraft:blackstone
setblock 96 79 518 minecraft:smooth_basalt
fill 96 79 519 97 81 519 minecraft:blackstone
setblock 96 79 522 minecraft:blackstone
setblock 96 79 523 minecraft:smooth_basalt
setblock 96 79 528 minecraft:smooth_basalt
fill 96 79 529 96 82 529 minecraft:blackstone
setblock 96 79 533 minecraft:smooth_basalt
fill 96 79 534 96 82 534 minecraft:blackstone
setblock 96 79 537 minecraft:blackstone
setblock 96 79 538 minecraft:smooth_basalt
setblock 97 79 512 minecraft:smooth_basalt
fill 97 79 513 100 79 513 minecraft:blackstone
setblock 97 79 517 minecraft:smooth_basalt
fill 97 79 518 97 82 518 minecraft:blackstone
fill 97 79 520 97 80 520 minecraft:blackstone
setblock 98 79 511 minecraft:smooth_basalt
fill 98 79 512 101 79 512 minecraft:blackstone
setblock 98 79 516 minecraft:smooth_basalt
fill 98 79 517 98 82 517 minecraft:blackstone
setblock 98 79 551 minecraft:smooth_basalt
fill 99 79 511 102 79 511 minecraft:blackstone
fill 99 79 551 102 79 551 minecraft:blackstone
setblock 100 79 514 minecraft:smooth_basalt
setblock 101 79 513 minecraft:smooth_basalt
fill 101 79 514 101 82 514 minecraft:blackstone
setblock 102 79 512 minecraft:smooth_basalt
fill 102 79 513 102 82 513 minecraft:blackstone
setblock 103 79 511 minecraft:smooth_basalt
fill 103 79 512 103 82 512 minecraft:blackstone
setblock 103 79 551 minecraft:smooth_basalt
fill 104 79 511 107 79 511 minecraft:blackstone
fill 104 79 551 107 79 551 minecraft:blackstone
setblock 107 79 512 minecraft:smooth_basalt
setblock 108 79 511 minecraft:smooth_basalt
fill 108 79 512 108 82 512 minecraft:blackstone
setblock 108 79 551 minecraft:smooth_basalt
fill 109 79 511 112 79 511 minecraft:blackstone
fill 109 79 551 112 79 551 minecraft:blackstone
fill 110 79 512 111 79 512 minecraft:blackstone
setblock 112 79 512 minecraft:smooth_basalt
setblock 113 79 511 minecraft:smooth_basalt
fill 113 79 512 113 82 512 minecraft:blackstone
setblock 113 79 551 minecraft:smooth_basalt
fill 114 79 511 117 79 511 minecraft:blackstone
setblock 114 79 550 minecraft:smooth_basalt
fill 114 79 551 117 79 551 minecraft:blackstone
fill 115 79 550 118 79 550 minecraft:blackstone
setblock 117 79 512 minecraft:smooth_basalt
setblock 118 79 511 minecraft:smooth_basalt
fill 118 79 512 118 81 513 minecraft:blackstone
setblock 118 79 551 minecraft:smooth_basalt
fill 119 79 511 119 82 511 minecraft:blackstone
setblock 119 79 550 minecraft:smooth_basalt
fill 119 79 551 122 79 551 minecraft:blackstone
fill 120 79 550 120 82 550 minecraft:blackstone
setblock 122 79 512 minecraft:smooth_basalt
setblock 123 79 511 minecraft:smooth_basalt
setblock 123 79 551 minecraft:smooth_basalt
fill 124 79 511 124 80 511 minecraft:blackstone
fill 124 79 551 124 80 551 minecraft:blackstone
setblock 133 79 511 minecraft:smooth_basalt
fill 133 79 534 133 79 535 minecraft:blackstone
fill 134 79 511 134 82 511 minecraft:blackstone
setblock 134 79 514 minecraft:blackstone
setblock 134 79 515 minecraft:smooth_basalt
fill 134 79 516 134 82 516 minecraft:blackstone
setblock 134 79 530 minecraft:smooth_basalt
fill 134 79 531 134 82 531 minecraft:blackstone
setblock 134 79 535 minecraft:smooth_basalt
fill 134 79 536 134 82 536 minecraft:blackstone
setblock 134 79 539 minecraft:blackstone
setblock 135 79 513 minecraft:blackstone
setblock 135 79 514 minecraft:smooth_basalt
fill 135 79 515 135 82 515 minecraft:blackstone
setblock 135 79 518 minecraft:blackstone
setblock 135 79 519 minecraft:smooth_basalt
fill 135 79 520 135 79 523 minecraft:blackstone
setblock 135 79 524 minecraft:smooth_basalt
fill 135 79 525 135 82 525 minecraft:blackstone
setblock 135 79 529 minecraft:smooth_basalt
fill 135 79 530 135 82 530 minecraft:blackstone
setblock 135 79 534 minecraft:smooth_basalt
fill 135 79 535 135 82 535 minecraft:blackstone
setblock 135 79 539 minecraft:smooth_basalt
fill 135 79 540 135 81 541 minecraft:blackstone
setblock 94 80 510 minecraft:blackstone
fill 94 80 511 94 80 527 minecraft:gilded_blackstone
setblock 94 80 528 minecraft:blackstone
fill 94 80 529 94 81 531 minecraft:gilded_blackstone
setblock 94 80 532 minecraft:blackstone
fill 94 80 533 94 83 541 minecraft:gilded_blackstone
setblock 94 80 542 minecraft:blackstone
fill 94 80 543 94 80 545 minecraft:gilded_blackstone
fill 94 80 546 94 82 546 minecraft:blackstone
fill 94 80 547 94 80 552 minecraft:gilded_blackstone
fill 95 80 510 99 83 510 minecraft:gilded_blackstone
setblock 95 80 513 minecraft:smooth_basalt
fill 95 80 514 95 80 517 minecraft:blackstone
setblock 95 80 518 minecraft:smooth_basalt
fill 95 80 519 95 80 522 minecraft:blackstone
setblock 95 80 523 minecraft:smooth_basalt
fill 95 80 524 96 82 524 minecraft:blackstone
setblock 95 80 528 minecraft:smooth_basalt
fill 95 80 529 95 83 529 minecraft:blackstone
setblock 95 80 533 minecraft:smooth_basalt
fill 95 80 534 95 83 534 minecraft:blackstone
setblock 95 80 538 minecraft:smooth_basalt
fill 95 80 539 96 82 539 minecraft:blackstone
fill 95 80 541 95 81 541 minecraft:blackstone
fill 95 80 550 95 81 551 minecraft:blackstone
fill 95 80 552 95 81 552 minecraft:gilded_blackstone
setblock 96 80 512 minecraft:smooth_basalt
fill 96 80 513 98 80 514 minecraft:blackstone
setblock 96 80 516 minecraft:blackstone
setblock 96 80 517 minecraft:smooth_basalt
fill 96 80 518 96 83 518 minecraft:blackstone
setblock 96 80 522 minecraft:smooth_basalt
fill 96 80 523 96 83 523 minecraft:blackstone
fill 96 80 525 96 80 526 minecraft:blackstone
setblock 96 80 527 minecraft:smooth_basalt
fill 96 80 528 96 83 528 minecraft:blackstone
setblock 96 80 532 minecraft:smooth_basalt
fill 96 80 533 96 83 533 minecraft:blackstone
setblock 96 80 537 minecraft:smooth_basalt
fill 96 80 538 96 83 538 minecraft:blackstone
fill 96 80 551 96 80 552 minecraft:blackstone
setblock 97 80 511 minecraft:smooth_basalt
fill 97 80 512 100 80 512 minecraft:blackstone
setblock 97 80 516 minecraft:smooth_basalt
fill 97 80 517 97 83 517 minecraft:blackstone
setblock 97 80 521 minecraft:smooth_basalt
fill 97 80 534 97 80 535 minecraft:blackstone
setblock 97 80 551 minecraft:smooth_basalt
fill 97 80 552 108 80 552 minecraft:gilded_blackstone
fill 98 80 511 101 80 511 minecraft:blackstone
setblock 98 80 515 minecraft:smooth_basalt
fill 98 80 516 98 83 516 minecraft:blackstone
fill 98 80 518 98 81 518 minecraft:blackstone
fill 98 80 551 101 80 551 minecraft:blackstone
setblock 99 80 513 minecraft:blackstone
setblock 99 80 514 minecraft:smooth_basalt
setblock 100 80 510 minecraft:blackstone
setblock 100 80 513 minecraft:smooth_basalt
fill 100 80 514 100 83 514 minecraft:blackstone
fill 101 80 510 103 80 510 minecraft:gilded_blackstone
setblock 101 80 512 minecraft:smooth_basalt
fill 101 80 513 101 83 513 minecraft:blackstone
setblock 102 80 511 minecraft:smooth_basalt
fill 102 80 512 102 83 512 minecraft:blackstone
setblock 102 80 551 minecraft:smooth_basalt
fill 103 80 511 106 80 511 minecraft:blackstone
fill 103 80 551 106 80 551 minecraft:blackstone
fill 104 80 510 104 81 510 minecraft:blackstone
fill 105 80 510 111 81 510 minecraft:gilded_blackstone
setblock 105 80 513 minecraft:smooth_basalt
setblock 106 80 512 minecraft:smooth_basalt
setblock 107 80 511 minecraft:smooth_basalt
fill 107 80 512 107 83 512 minecraft:blackstone
setblock 107 80 551 minecraft:smooth_basalt
fill 108 80 511 111 80 511 minecraft:blackstone
fill 108 80 551 111 80 551 minecraft:blackstone
setblock 109 80 552 minecraft:blackstone
setblock 110 80 512 minecraft:blackstone
fill 110 80 552 136 80 552 minecraft:gilded_blackstone
setblock 111 80 512 minecraft:smooth_basalt
setblock 112 80 510 minecraft:blackstone
setblock 112 80 511 minecraft:smooth_basalt
fill 112 80 512 112 83 512 minecraft:blackstone
setblock 112 80 551 minecraft:smooth_basalt
fill 113 80 510 117 81 510 minecraft:gilded_blackstone
fill 113 80 511 116 80 511 minecraft:blackstone
setblock 113 80 550 minecraft:smooth_basalt
fill 113 80 551 116 80 551 minecraft:blackstone
fill 114 80 550 117 80 550 minecraft:blackstone
setblock 116 80 512 minecraft:smooth_basalt
fill 116 80 513 117 82 513 minecraft:blackstone
setblock 117 80 511 minecraft:smooth_basalt
fill 117 80 512 117 83 512 minecraft:blackstone
setblock 117 80 551 minecraft:smooth_basalt
fill 118 80 510 118 80 511 minecraft:blackstone
setblock 118 80 550 minecraft:smooth_basalt
fill 118 80 551 121 80 551 minecraft:blackstone
fill 119 80 510 130 80 510 minecraft:gilded_blackstone
setblock 119 80 513 minecraft:blackstone
fill 119 80 550 119 83 550 minecraft:blackstone
setblock 121 80 512 minecraft:smooth_basalt
fill 121 80 550 121 81 550 minecraft:blackstone
setblock 122 80 511 minecraft:smooth_basalt
setblock 122 80 512 minecraft:blackstone
setblock 122 80 551 minecraft:smooth_basalt
fill 123 80 511 123 82 511 minecraft:blackstone
fill 123 80 551 123 81 551 minecraft:blackstone
setblock 131 80 510 minecraft:blackstone
fill 132 80 510 135 83 510 minecraft:gilded_blackstone
fill 133 80 511 133 83 511 minecraft:blackstone
fill 133 80 532 133 80 534 minecraft:blackstone
setblock 133 80 535 minecraft:smooth_basalt
fill 133 80 536 133 82 537 minecraft:blackstone
fill 134 80 512 134 80 513 minecraft:blackstone
setblock 134 80 514 minecraft:smooth_basalt
fill 134 80 515 134 83 515 minecraft:blackstone
fill 134 80 517 134 80 518 minecraft:blackstone
setblock 134 80 519 minecraft:smooth_basalt
fill 134 80 520 135 81 521 minecraft:blackstone
fill 134 80 527 134 80 528 minecraft:blackstone
setblock 134 80 529 minecraft:smooth_basalt
fill 134 80 530 134 83 530 minecraft:blackstone
setblock 134 80 534 minecraft:smooth_basalt
fill 134 80 535 134 83 535 minecraft:blackstone
setblock 134 80 539 minecraft:smooth_basalt
fill 134 80 540 134 83 540 minecraft:blackstone
setblock 135 80 513 minecraft:smooth_basalt
fill 135 80 514 135 83 514 minecraft:blackstone
setblock 135 80 518 minecraft:smooth_basalt
fill 135 80 519 136 80 519 minecraft:blackstone
setblock 135 80 522 minecraft:blackstone
setblock 135 80 523 minecraft:smooth_basalt
fill 135 80 524 135 83 524 minecraft:blackstone
setblock 135 80 528 minecraft:smooth_basalt
fill 135 80 529 135 83 529 minecraft:blackstone
setblock 135 80 533 minecraft:smooth_basalt
fill 135 80 534 135 83 534 minecraft:blackstone
setblock 135 80 538 minecraft:smooth_basalt
fill 135 80 539 136 80 539 minecraft:blackstone
setblock 135 80 542 minecraft:blackstone
setblock 135 80 543 minecraft:smooth_basalt
setblock 136 80 510 minecraft:blackstone
fill 136 80 511 136 80 514 minecraft:gilded_blackstone
setblock 136 80 515 minecraft:blackstone
fill 136 80 516 136 83 518 minecraft:gilded_blackstone
fill 136 80 520 136 81 525 minecraft:gilded_blackstone
setblock 136 80 526 minecraft:blackstone
fill 136 80 527 136 80 538 minecraft:gilded_blackstone
fill 136 80 540 136 83 542 minecraft:gilded_blackstone
fill 136 80 543 136 82 543 minecraft:blackstone
fill 136 80 544 136 80 551 minecraft:gilded_blackstone
fill 94 81 510 94 83 511 minecraft:gilded_blackstone
fill 94 81 512 94 82 512 minecraft:blackstone
fill 94 81 513 94 81 522 minecraft:gilded_blackstone
fill 94 81 523 95 81 523 minecraft:blackstone
fill 94 81 524 94 83 528 minecraft:gilded_blackstone
fill 94 81 532 94 83 532 minecraft:gilded_blackstone
fill 94 81 542 94 83 544 minecraft:gilded_blackstone
setblock 94 81 545 minecraft:blackstone
fill 94 81 547 94 83 549 minecraft:gilded_blackstone
setblock 94 81 550 minecraft:blackstone
fill 94 81 551 94 83 552 minecraft:gilded_blackstone
setblock 95 81 512 minecraft:smooth_basalt
fill 95 81 513 95 81 516 minecraft:blackstone
setblock 95 81 517 minecraft:smooth_basalt
fill 95 81 518 95 81 521 minecraft:blackstone
setblock 95 81 522 minecraft:smooth_basalt
setblock 95 81 527 minecraft:smooth_basalt
fill 95 81 528 95 84 528 minecraft:blackstone
setblock 95 81 532 minecraft:smooth_basalt
fill 95 81 533 95 84 533 minecraft:blackstone
setblock 95 81 536 minecraft:blackstone
setblock 95 81 537 minecraft:smooth_basalt
fill 95 81 538 95 84 538 minecraft:blackstone
setblock 95 81 542 minecraft:smooth_basalt
fill 95 81 543 95 84 543 minecraft:blackstone
setblock 96 81 511 minecraft:smooth_basalt
fill 96 81 512 97 81 514 minecraft:blackstone
setblock 96 81 516 minecraft:smooth_basalt
fill 96 81 517 96 84 517 minecraft:blackstone
setblock 96 81 520 minecraft:blackstone
setblock 96 81 521 minecraft:smooth_basalt
fill 96 81 522 97 83 522 minecraft:blackstone
setblock 96 81 525 minecraft:blackstone
setblock 96 81 526 minecraft:smooth_basalt
fill 96 81 527 96 84 527 minecraft:blackstone
setblock 96 81 531 minecraft:smooth_basalt
fill 96 81 532 96 84 532 minecraft:blackstone
setblock 96 81 536 minecraft:smooth_basalt
fill 96 81 537 97 83 537 minecraft:blackstone
setblock 96 81 540 minecraft:blackstone
setblock 96 81 541 minecraft:smooth_basalt
setblock 96 81 551 minecraft:smooth_basalt
fill 96 81 552 107 81 552 minecraft:gilded_blackstone
fill 97 81 511 100 81 511 minecraft:blackstone
setblock 97 81 515 minecraft:smooth_basalt
fill 97 81 516 97 84 516 minecraft:blackstone
setblock 97 81 520 minecraft:smooth_basalt
fill 97 81 521 97 84 521 minecraft:blackstone
setblock 97 81 534 minecraft:blackstone
setblock 97 81 535 minecraft:smooth_basalt
fill 97 81 536 97 83 536 minecraft:blackstone
fill 97 81 551 100 81 551 minecraft:blackstone
fill 98 81 512 98 81 513 minecraft:blackstone
setblock 98 81 514 minecraft:smooth_basalt
fill 98 81 515 99 83 515 minecraft:blackstone
setblock 98 81 519 minecraft:smooth_basalt
fill 98 81 550 99 83 550 minecraft:blackstone
setblock 99 81 512 minecraft:blackstone
setblock 99 81 513 minecraft:smooth_basalt
fill 99 81 514 99 84 514 minecraft:blackstone
fill 99 81 516 99 82 516 minecraft:blackstone
fill 100 81 510 100 83 510 minecraft:gilded_blackstone
setblock 100 81 512 minecraft:smooth_basalt
fill 100 81 513 100 84 513 minecraft:blackstone
setblock 101 81 510 minecraft:blackstone
setblock 101 81 511 minecraft:smooth_basalt
fill 101 81 512 101 84 512 minecraft:blackstone
setblock 101 81 551 minecraft:smooth_basalt
fill 102 81 510 103 83 510 minecraft:gilded_blackstone
fill 102 81 511 105 81 511 minecraft:blackstone
fill 102 81 551 105 81 551 minecraft:blackstone
setblock 104 81 513 minecraft:smooth_basalt
setblock 105 81 512 minecraft:smooth_basalt
setblock 105 81 513 minecraft:blackstone
setblock 106 81 511 minecraft:smooth_basalt
fill 106 81 512 106 83 512 minecraft:blackstone
setblock 106 81 551 minecraft:smooth_basalt
fill 107 81 511 110 81 511 minecraft:blackstone
fill 107 81 551 110 81 551 minecraft:blackstone
setblock 108 81 552 minecraft:blackstone
fill 109 81 552 117 81 552 minecraft:gilded_blackstone
setblock 110 81 512 minecraft:smooth_basalt
setblock 111 81 511 minecraft:smooth_basalt
fill 111 81 512 111 84 512 minecraft:blackstone
setblock 111 81 551 minecraft:smooth_basalt
fill 112 81 510 112 83 510 minecraft:gilded_blackstone
fill 112 81 511 115 81 511 minecraft:blackstone
fill 112 81 551 115 81 551 minecraft:blackstone
fill 113 81 550 116 81 550 minecraft:blackstone
setblock 114 81 513 minecraft:smooth_basalt
setblock 115 81 512 minecraft:smooth_basalt
fill 115 81 513 115 83 513 minecraft:blackstone
setblock 116 81 511 minecraft:smooth_basalt
fill 116 81 512 116 84 512 minecraft:blackstone
setblock 116 81 551 minecraft:smooth_basalt
schedule function dropper:buildpart/122_4 1t
