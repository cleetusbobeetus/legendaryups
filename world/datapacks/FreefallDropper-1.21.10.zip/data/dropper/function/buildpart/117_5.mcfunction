setblock 434 150 482 minecraft:light[level=11]
setblock 434 150 490 minecraft:light[level=11]
setblock 434 150 498 minecraft:light[level=11]
setblock 440 150 504 minecraft:blackstone
setblock 441 150 504 minecraft:polished_blackstone_bricks
fill 442 150 464 442 153 464 minecraft:blackstone
setblock 442 150 466 minecraft:light[level=11]
setblock 442 150 474 minecraft:light[level=11]
setblock 442 150 482 minecraft:light[level=11]
setblock 442 150 490 minecraft:light[level=11]
setblock 442 150 498 minecraft:light[level=11]
setblock 442 150 503 minecraft:polished_blackstone_bricks
fill 442 150 504 445 150 504 minecraft:blackstone
fill 443 150 503 446 150 503 minecraft:blackstone
setblock 445 150 465 minecraft:polished_blackstone_bricks
setblock 446 150 464 minecraft:polished_blackstone_bricks
fill 446 150 465 446 153 465 minecraft:blackstone
setblock 446 150 504 minecraft:polished_blackstone_bricks
fill 447 150 464 447 153 464 minecraft:blackstone
setblock 447 150 503 minecraft:polished_blackstone_bricks
fill 447 150 504 447 153 504 minecraft:blackstone
fill 448 150 503 448 153 503 minecraft:blackstone
setblock 450 150 466 minecraft:light[level=11]
setblock 450 150 474 minecraft:light[level=11]
setblock 450 150 482 minecraft:light[level=11]
setblock 450 150 490 minecraft:light[level=11]
setblock 450 150 498 minecraft:light[level=11]
setblock 450 150 504 minecraft:blackstone
setblock 451 150 464 minecraft:polished_blackstone_bricks
setblock 451 150 504 minecraft:polished_blackstone_bricks
fill 452 150 464 455 150 464 minecraft:blackstone
fill 452 150 504 455 150 504 minecraft:blackstone
setblock 456 150 464 minecraft:polished_blackstone_bricks
setblock 456 150 504 minecraft:polished_blackstone_bricks
fill 457 150 464 457 153 464 minecraft:blackstone
fill 457 150 504 457 153 504 minecraft:blackstone
setblock 458 150 466 minecraft:light[level=11]
setblock 458 150 474 minecraft:light[level=11]
setblock 458 150 482 minecraft:light[level=11]
setblock 458 150 490 minecraft:light[level=11]
setblock 458 150 498 minecraft:light[level=11]
fill 458 150 503 458 153 503 minecraft:blackstone
fill 460 150 502 460 152 502 minecraft:blackstone
setblock 461 150 464 minecraft:polished_blackstone_bricks
fill 461 150 465 461 153 465 minecraft:blackstone
setblock 461 150 504 minecraft:polished_blackstone_bricks
fill 462 150 464 462 153 464 minecraft:blackstone
setblock 462 150 497 minecraft:blackstone
setblock 462 150 498 minecraft:polished_blackstone_bricks
fill 462 150 499 462 153 499 minecraft:blackstone
setblock 462 150 503 minecraft:polished_blackstone_bricks
fill 462 150 504 462 153 504 minecraft:blackstone
setblock 463 150 466 minecraft:blackstone
setblock 463 150 467 minecraft:polished_blackstone_bricks
fill 463 150 468 463 151 468 minecraft:blackstone
setblock 463 150 472 minecraft:polished_blackstone_bricks
fill 463 150 473 463 151 473 minecraft:blackstone
setblock 463 150 477 minecraft:polished_blackstone_bricks
fill 463 150 478 463 153 478 minecraft:blackstone
setblock 463 150 482 minecraft:polished_blackstone_bricks
setblock 463 150 493 minecraft:blackstone
setblock 463 150 497 minecraft:polished_blackstone_bricks
fill 463 150 498 463 153 498 minecraft:blackstone
setblock 463 150 502 minecraft:polished_blackstone_bricks
fill 463 150 503 463 153 503 minecraft:blackstone
setblock 464 150 466 minecraft:polished_blackstone_bricks
fill 464 150 467 464 153 467 minecraft:blackstone
setblock 464 150 471 minecraft:polished_blackstone_bricks
fill 464 150 472 464 153 472 minecraft:blackstone
setblock 464 150 476 minecraft:polished_blackstone_bricks
fill 464 150 477 464 153 477 minecraft:blackstone
setblock 464 150 481 minecraft:polished_blackstone_bricks
fill 464 150 482 464 153 482 minecraft:blackstone
setblock 464 150 486 minecraft:polished_blackstone_bricks
fill 464 150 487 464 152 488 minecraft:blackstone
setblock 464 150 491 minecraft:polished_blackstone_bricks
fill 464 150 492 464 153 492 minecraft:blackstone
setblock 464 150 496 minecraft:polished_blackstone_bricks
fill 464 150 497 464 153 497 minecraft:blackstone
setblock 464 150 501 minecraft:polished_blackstone_bricks
fill 464 150 502 464 153 502 minecraft:blackstone
setblock 424 151 465 minecraft:polished_blackstone_bricks
fill 424 151 466 424 154 466 minecraft:blackstone
setblock 424 151 470 minecraft:polished_blackstone_bricks
setblock 424 151 471 minecraft:blackstone
setblock 424 151 475 minecraft:polished_blackstone_bricks
fill 424 151 476 424 154 476 minecraft:blackstone
setblock 424 151 480 minecraft:polished_blackstone_bricks
fill 424 151 481 424 154 481 minecraft:blackstone
setblock 424 151 484 minecraft:blackstone
setblock 424 151 485 minecraft:polished_blackstone_bricks
fill 424 151 486 424 154 486 minecraft:blackstone
setblock 424 151 490 minecraft:polished_blackstone_bricks
fill 424 151 491 424 154 491 minecraft:blackstone
setblock 424 151 495 minecraft:polished_blackstone_bricks
fill 424 151 496 424 154 496 minecraft:blackstone
setblock 424 151 500 minecraft:polished_blackstone_bricks
fill 424 151 501 424 154 501 minecraft:blackstone
setblock 425 151 464 minecraft:polished_blackstone_bricks
setblock 425 151 474 minecraft:polished_blackstone_bricks
fill 425 151 475 425 152 475 minecraft:blackstone
setblock 425 151 478 minecraft:blackstone
setblock 425 151 479 minecraft:polished_blackstone_bricks
fill 425 151 480 425 154 480 minecraft:blackstone
setblock 425 151 484 minecraft:polished_blackstone_bricks
fill 425 151 485 425 154 485 minecraft:blackstone
setblock 425 151 489 minecraft:polished_blackstone_bricks
fill 425 151 490 425 154 490 minecraft:blackstone
setblock 425 151 494 minecraft:polished_blackstone_bricks
fill 425 151 495 425 154 495 minecraft:blackstone
setblock 425 151 499 minecraft:polished_blackstone_bricks
fill 425 151 500 425 154 500 minecraft:blackstone
setblock 425 151 504 minecraft:polished_blackstone_bricks
fill 426 151 464 426 154 464 minecraft:blackstone
setblock 426 151 478 minecraft:polished_blackstone_bricks
fill 426 151 479 426 152 479 minecraft:blackstone
setblock 426 151 482 minecraft:blackstone
setblock 426 151 483 minecraft:polished_blackstone_bricks
setblock 426 151 493 minecraft:polished_blackstone_bricks
fill 426 151 494 426 152 494 minecraft:blackstone
setblock 426 151 498 minecraft:polished_blackstone_bricks
fill 426 151 499 426 154 499 minecraft:blackstone
setblock 426 151 503 minecraft:polished_blackstone_bricks
fill 426 151 504 426 154 504 minecraft:blackstone
setblock 427 151 497 minecraft:polished_blackstone_bricks
fill 427 151 498 427 152 498 minecraft:blackstone
setblock 427 151 502 minecraft:polished_blackstone_bricks
fill 427 151 503 427 154 503 minecraft:blackstone
setblock 428 151 501 minecraft:polished_blackstone_bricks
fill 428 151 502 428 153 502 minecraft:blackstone
setblock 430 151 504 minecraft:polished_blackstone_bricks
setblock 431 151 503 minecraft:polished_blackstone_bricks
fill 431 151 504 431 153 504 minecraft:blackstone
setblock 439 151 504 minecraft:blackstone
setblock 440 151 504 minecraft:polished_blackstone_bricks
fill 441 151 464 441 154 464 minecraft:blackstone
fill 441 151 504 444 151 504 minecraft:blackstone
fill 442 151 503 445 151 503 minecraft:blackstone
setblock 444 151 465 minecraft:polished_blackstone_bricks
setblock 445 151 464 minecraft:polished_blackstone_bricks
fill 445 151 465 445 154 465 minecraft:blackstone
setblock 445 151 504 minecraft:polished_blackstone_bricks
fill 446 151 464 446 154 464 minecraft:blackstone
setblock 446 151 503 minecraft:polished_blackstone_bricks
fill 446 151 504 446 154 504 minecraft:blackstone
fill 447 151 503 447 154 503 minecraft:blackstone
setblock 449 151 465 minecraft:polished_blackstone_bricks
setblock 450 151 464 minecraft:polished_blackstone_bricks
setblock 450 151 504 minecraft:polished_blackstone_bricks
fill 451 151 464 454 151 464 minecraft:blackstone
fill 451 151 504 454 151 504 minecraft:blackstone
setblock 455 151 464 minecraft:polished_blackstone_bricks
setblock 455 151 504 minecraft:polished_blackstone_bricks
fill 456 151 464 456 154 464 minecraft:blackstone
fill 456 151 504 456 154 504 minecraft:blackstone
fill 457 151 471 461 152 475 minecraft:blackstone
fill 457 151 503 457 154 503 minecraft:blackstone
setblock 460 151 464 minecraft:polished_blackstone_bricks
fill 460 151 465 460 154 465 minecraft:blackstone
setblock 460 151 503 minecraft:blackstone
setblock 460 151 504 minecraft:polished_blackstone_bricks
fill 461 151 464 461 154 464 minecraft:blackstone
setblock 461 151 503 minecraft:polished_blackstone_bricks
fill 461 151 504 461 154 504 minecraft:blackstone
setblock 462 151 473 minecraft:blackstone
setblock 462 151 497 minecraft:polished_blackstone_bricks
fill 462 151 498 462 154 498 minecraft:blackstone
setblock 462 151 501 minecraft:blackstone
setblock 462 151 502 minecraft:polished_blackstone_bricks
fill 462 151 503 462 154 503 minecraft:blackstone
setblock 463 151 466 minecraft:polished_blackstone_bricks
fill 463 151 467 463 152 467 minecraft:blackstone
setblock 463 151 471 minecraft:polished_blackstone_bricks
setblock 463 151 472 minecraft:blackstone
setblock 463 151 476 minecraft:polished_blackstone_bricks
fill 463 151 477 463 153 477 minecraft:blackstone
setblock 463 151 481 minecraft:polished_blackstone_bricks
fill 463 151 482 463 154 482 minecraft:blackstone
setblock 463 151 496 minecraft:polished_blackstone_bricks
fill 463 151 497 463 154 497 minecraft:blackstone
setblock 463 151 501 minecraft:polished_blackstone_bricks
fill 463 151 502 463 154 502 minecraft:blackstone
setblock 464 151 465 minecraft:polished_blackstone_bricks
fill 464 151 466 464 154 466 minecraft:blackstone
setblock 464 151 470 minecraft:polished_blackstone_bricks
fill 464 151 471 464 153 471 minecraft:blackstone
setblock 464 151 475 minecraft:polished_blackstone_bricks
fill 464 151 476 464 154 476 minecraft:blackstone
setblock 464 151 480 minecraft:polished_blackstone_bricks
fill 464 151 481 464 154 481 minecraft:blackstone
setblock 464 151 485 minecraft:polished_blackstone_bricks
fill 464 151 486 464 154 486 minecraft:blackstone
setblock 464 151 490 minecraft:polished_blackstone_bricks
fill 464 151 491 464 154 491 minecraft:blackstone
setblock 464 151 495 minecraft:polished_blackstone_bricks
fill 464 151 496 464 154 496 minecraft:blackstone
setblock 464 151 500 minecraft:polished_blackstone_bricks
fill 464 151 501 464 154 501 minecraft:blackstone
setblock 424 152 464 minecraft:polished_blackstone_bricks
fill 424 152 465 424 155 465 minecraft:blackstone
setblock 424 152 474 minecraft:polished_blackstone_bricks
fill 424 152 475 424 154 475 minecraft:blackstone
setblock 424 152 479 minecraft:polished_blackstone_bricks
fill 424 152 480 424 155 480 minecraft:blackstone
setblock 424 152 484 minecraft:polished_blackstone_bricks
fill 424 152 485 424 155 485 minecraft:blackstone
setblock 424 152 489 minecraft:polished_blackstone_bricks
fill 424 152 490 424 155 490 minecraft:blackstone
setblock 424 152 494 minecraft:polished_blackstone_bricks
fill 424 152 495 424 155 495 minecraft:blackstone
setblock 424 152 499 minecraft:polished_blackstone_bricks
fill 424 152 500 424 155 500 minecraft:blackstone
setblock 424 152 504 minecraft:polished_blackstone_bricks
fill 425 152 464 425 155 464 minecraft:blackstone
setblock 425 152 478 minecraft:polished_blackstone_bricks
fill 425 152 479 425 155 479 minecraft:blackstone
setblock 425 152 483 minecraft:polished_blackstone_bricks
fill 425 152 484 425 155 484 minecraft:blackstone
setblock 425 152 488 minecraft:polished_blackstone_bricks
fill 425 152 489 425 155 489 minecraft:blackstone
setblock 425 152 493 minecraft:polished_blackstone_bricks
fill 425 152 494 425 155 494 minecraft:blackstone
setblock 425 152 498 minecraft:polished_blackstone_bricks
fill 425 152 499 425 155 499 minecraft:blackstone
setblock 425 152 503 minecraft:polished_blackstone_bricks
fill 425 152 504 425 155 504 minecraft:blackstone
setblock 426 152 482 minecraft:polished_blackstone_bricks
fill 426 152 483 426 153 483 minecraft:blackstone
setblock 426 152 497 minecraft:polished_blackstone_bricks
fill 426 152 498 426 154 498 minecraft:blackstone
setblock 426 152 502 minecraft:polished_blackstone_bricks
fill 426 152 503 426 155 503 minecraft:blackstone
setblock 427 152 501 minecraft:polished_blackstone_bricks
fill 427 152 502 427 154 502 minecraft:blackstone
setblock 429 152 504 minecraft:polished_blackstone_bricks
setblock 430 152 503 minecraft:polished_blackstone_bricks
fill 430 152 504 430 155 504 minecraft:blackstone
setblock 439 152 504 minecraft:polished_blackstone_bricks
fill 440 152 504 443 152 504 minecraft:blackstone
fill 441 152 503 444 152 503 minecraft:blackstone
setblock 444 152 464 minecraft:polished_blackstone_bricks
fill 444 152 465 444 155 465 minecraft:blackstone
setblock 444 152 504 minecraft:polished_blackstone_bricks
fill 445 152 464 445 155 464 minecraft:blackstone
setblock 445 152 503 minecraft:polished_blackstone_bricks
fill 445 152 504 445 155 504 minecraft:blackstone
fill 446 152 503 446 154 503 minecraft:blackstone
setblock 448 152 465 minecraft:polished_blackstone_bricks
setblock 449 152 464 minecraft:polished_blackstone_bricks
setblock 449 152 503 minecraft:blackstone
setblock 449 152 504 minecraft:polished_blackstone_bricks
fill 450 152 464 453 152 464 minecraft:blackstone
fill 450 152 504 453 152 504 minecraft:blackstone
setblock 454 152 464 minecraft:polished_blackstone_bricks
setblock 454 152 504 minecraft:polished_blackstone_bricks
fill 455 152 464 455 155 464 minecraft:blackstone
fill 455 152 504 455 155 504 minecraft:blackstone
setblock 459 152 464 minecraft:polished_blackstone_bricks
setblock 459 152 504 minecraft:polished_blackstone_bricks
fill 460 152 464 460 155 464 minecraft:blackstone
setblock 460 152 503 minecraft:polished_blackstone_bricks
fill 460 152 504 460 155 504 minecraft:blackstone
setblock 461 152 502 minecraft:polished_blackstone_bricks
fill 461 152 503 461 155 503 minecraft:blackstone
setblock 462 152 497 minecraft:blackstone
setblock 462 152 501 minecraft:polished_blackstone_bricks
fill 462 152 502 462 155 502 minecraft:blackstone
setblock 463 152 465 minecraft:polished_blackstone_bricks
fill 463 152 466 463 155 466 minecraft:blackstone
setblock 463 152 475 minecraft:polished_blackstone_bricks
fill 463 152 476 463 153 476 minecraft:blackstone
setblock 463 152 480 minecraft:polished_blackstone_bricks
fill 463 152 481 463 155 481 minecraft:blackstone
fill 463 152 483 463 153 483 minecraft:blackstone
setblock 463 152 495 minecraft:polished_blackstone_bricks
fill 463 152 496 463 155 496 minecraft:blackstone
setblock 463 152 500 minecraft:polished_blackstone_bricks
fill 463 152 501 463 155 501 minecraft:blackstone
setblock 464 152 464 minecraft:polished_blackstone_bricks
fill 464 152 465 464 155 465 minecraft:blackstone
setblock 464 152 469 minecraft:polished_blackstone_bricks
fill 464 152 470 464 153 470 minecraft:blackstone
setblock 464 152 474 minecraft:polished_blackstone_bricks
fill 464 152 475 464 154 475 minecraft:blackstone
setblock 464 152 479 minecraft:polished_blackstone_bricks
fill 464 152 480 464 155 480 minecraft:blackstone
setblock 464 152 484 minecraft:polished_blackstone_bricks
fill 464 152 485 464 155 485 minecraft:blackstone
setblock 464 152 489 minecraft:polished_blackstone_bricks
fill 464 152 490 464 155 490 minecraft:blackstone
setblock 464 152 494 minecraft:polished_blackstone_bricks
fill 464 152 495 464 155 495 minecraft:blackstone
setblock 464 152 499 minecraft:polished_blackstone_bricks
fill 464 152 500 464 155 500 minecraft:blackstone
setblock 464 152 504 minecraft:polished_blackstone_bricks
fill 424 153 464 424 156 464 minecraft:blackstone
setblock 424 153 474 minecraft:blackstone
setblock 424 153 478 minecraft:polished_blackstone_bricks
fill 424 153 479 424 156 479 minecraft:blackstone
setblock 424 153 483 minecraft:polished_blackstone_bricks
fill 424 153 484 424 156 484 minecraft:blackstone
setblock 424 153 488 minecraft:polished_blackstone_bricks
fill 424 153 489 424 156 489 minecraft:blackstone
setblock 424 153 493 minecraft:polished_blackstone_bricks
fill 424 153 494 424 156 494 minecraft:blackstone
setblock 424 153 498 minecraft:polished_blackstone_bricks
fill 424 153 499 424 156 499 minecraft:blackstone
setblock 424 153 503 minecraft:polished_blackstone_bricks
fill 424 153 504 424 156 504 minecraft:blackstone
setblock 425 153 477 minecraft:polished_blackstone_bricks
fill 425 153 478 425 154 478 minecraft:blackstone
setblock 425 153 482 minecraft:polished_blackstone_bricks
fill 425 153 483 425 156 483 minecraft:blackstone
setblock 425 153 487 minecraft:polished_blackstone_bricks
fill 425 153 488 425 156 488 minecraft:blackstone
setblock 425 153 492 minecraft:polished_blackstone_bricks
fill 425 153 493 425 154 493 minecraft:blackstone
setblock 425 153 497 minecraft:polished_blackstone_bricks
fill 425 153 498 425 156 498 minecraft:blackstone
setblock 425 153 502 minecraft:polished_blackstone_bricks
fill 425 153 503 425 156 503 minecraft:blackstone
setblock 426 153 481 minecraft:polished_blackstone_bricks
setblock 426 153 482 minecraft:blackstone
setblock 426 153 496 minecraft:polished_blackstone_bricks
setblock 426 153 497 minecraft:blackstone
setblock 426 153 501 minecraft:polished_blackstone_bricks
fill 426 153 502 426 155 502 minecraft:blackstone
setblock 428 153 504 minecraft:polished_blackstone_bricks
setblock 429 153 503 minecraft:polished_blackstone_bricks
fill 429 153 504 429 156 504 minecraft:blackstone
fill 439 153 504 442 153 504 minecraft:blackstone
fill 440 153 464 440 155 464 minecraft:blackstone
fill 441 153 503 443 153 503 minecraft:blackstone
setblock 443 153 464 minecraft:polished_blackstone_bricks
fill 443 153 465 443 156 465 minecraft:blackstone
setblock 443 153 504 minecraft:polished_blackstone_bricks
fill 444 153 464 444 156 464 minecraft:blackstone
setblock 444 153 503 minecraft:polished_blackstone_bricks
fill 444 153 504 444 156 504 minecraft:blackstone
fill 445 153 503 445 156 503 minecraft:blackstone
setblock 447 153 465 minecraft:polished_blackstone_bricks
setblock 448 153 464 minecraft:polished_blackstone_bricks
setblock 448 153 465 minecraft:blackstone
setblock 448 153 504 minecraft:polished_blackstone_bricks
fill 449 153 464 452 153 464 minecraft:blackstone
fill 449 153 504 452 153 504 minecraft:blackstone
setblock 453 153 464 minecraft:polished_blackstone_bricks
setblock 453 153 504 minecraft:polished_blackstone_bricks
fill 454 153 464 454 156 464 minecraft:blackstone
fill 454 153 504 454 156 504 minecraft:blackstone
setblock 458 153 464 minecraft:polished_blackstone_bricks
fill 458 153 473 460 156 473 minecraft:polished_blackstone_bricks
setblock 458 153 504 minecraft:polished_blackstone_bricks
fill 459 153 464 459 155 465 minecraft:blackstone
fill 459 153 472 459 156 472 minecraft:polished_blackstone_bricks
fill 459 153 474 459 156 474 minecraft:polished_blackstone_bricks
setblock 459 153 502 minecraft:blackstone
setblock 459 153 503 minecraft:polished_blackstone_bricks
fill 459 153 504 459 156 504 minecraft:blackstone
setblock 460 153 502 minecraft:polished_blackstone_bricks
fill 460 153 503 460 156 503 minecraft:blackstone
fill 461 153 502 461 156 502 minecraft:blackstone
setblock 462 153 465 minecraft:polished_blackstone_bricks
setblock 462 153 500 minecraft:polished_blackstone_bricks
fill 462 153 501 462 156 501 minecraft:blackstone
setblock 463 153 464 minecraft:polished_blackstone_bricks
fill 463 153 465 463 156 465 minecraft:blackstone
setblock 463 153 479 minecraft:polished_blackstone_bricks
fill 463 153 480 463 155 480 minecraft:blackstone
setblock 463 153 495 minecraft:blackstone
setblock 463 153 499 minecraft:polished_blackstone_bricks
fill 463 153 500 463 156 500 minecraft:blackstone
setblock 463 153 504 minecraft:polished_blackstone_bricks
fill 464 153 464 464 156 464 minecraft:blackstone
setblock 464 153 468 minecraft:polished_blackstone_bricks
fill 464 153 469 464 154 469 minecraft:blackstone
setblock 464 153 473 minecraft:polished_blackstone_bricks
fill 464 153 474 464 154 474 minecraft:blackstone
setblock 464 153 478 minecraft:polished_blackstone_bricks
fill 464 153 479 464 156 479 minecraft:blackstone
setblock 464 153 483 minecraft:polished_blackstone_bricks
fill 464 153 484 464 156 484 minecraft:blackstone
setblock 464 153 487 minecraft:blackstone
setblock 464 153 488 minecraft:polished_blackstone_bricks
fill 464 153 489 464 156 489 minecraft:blackstone
setblock 464 153 493 minecraft:polished_blackstone_bricks
fill 464 153 494 464 156 494 minecraft:blackstone
setblock 464 153 498 minecraft:polished_blackstone_bricks
fill 464 153 499 464 156 499 minecraft:blackstone
setblock 464 153 503 minecraft:polished_blackstone_bricks
fill 464 153 504 464 156 504 minecraft:blackstone
setblock 424 154 477 minecraft:polished_blackstone_bricks
fill 424 154 478 424 157 478 minecraft:blackstone
setblock 424 154 482 minecraft:polished_blackstone_bricks
fill 424 154 483 424 157 483 minecraft:blackstone
setblock 424 154 487 minecraft:polished_blackstone_bricks
fill 424 154 488 424 157 488 minecraft:blackstone
setblock 424 154 492 minecraft:polished_blackstone_bricks
fill 424 154 493 424 157 493 minecraft:blackstone
setblock 424 154 497 minecraft:polished_blackstone_bricks
fill 424 154 498 424 157 498 minecraft:blackstone
setblock 424 154 502 minecraft:polished_blackstone_bricks
fill 424 154 503 424 157 503 minecraft:blackstone
setblock 425 154 481 minecraft:polished_blackstone_bricks
fill 425 154 482 425 157 482 minecraft:blackstone
setblock 425 154 486 minecraft:polished_blackstone_bricks
fill 425 154 487 425 157 487 minecraft:blackstone
setblock 425 154 491 minecraft:polished_blackstone_bricks
setblock 425 154 492 minecraft:blackstone
setblock 425 154 496 minecraft:polished_blackstone_bricks
fill 425 154 497 425 156 497 minecraft:blackstone
setblock 425 154 501 minecraft:polished_blackstone_bricks
fill 425 154 502 425 157 502 minecraft:blackstone
setblock 426 154 500 minecraft:polished_blackstone_bricks
fill 426 154 501 426 155 501 minecraft:blackstone
setblock 427 154 504 minecraft:polished_blackstone_bricks
setblock 428 154 503 minecraft:polished_blackstone_bricks
fill 428 154 504 428 157 504 minecraft:blackstone
setblock 429 154 503 minecraft:blackstone
fill 438 154 504 441 154 504 minecraft:blackstone
fill 439 154 464 439 156 464 minecraft:blackstone
fill 441 154 503 442 154 503 minecraft:blackstone
setblock 442 154 464 minecraft:polished_blackstone_bricks
setblock 442 154 504 minecraft:polished_blackstone_bricks
fill 443 154 464 443 157 464 minecraft:blackstone
setblock 443 154 503 minecraft:polished_blackstone_bricks
fill 443 154 504 443 157 504 minecraft:blackstone
fill 444 154 503 444 157 503 minecraft:blackstone
setblock 446 154 465 minecraft:polished_blackstone_bricks
setblock 447 154 464 minecraft:polished_blackstone_bricks
fill 447 154 465 447 157 465 minecraft:blackstone
setblock 447 154 504 minecraft:polished_blackstone_bricks
fill 448 154 464 451 154 464 minecraft:blackstone
fill 448 154 504 451 154 504 minecraft:blackstone
setblock 452 154 464 minecraft:polished_blackstone_bricks
setblock 452 154 504 minecraft:polished_blackstone_bricks
fill 453 154 464 453 157 464 minecraft:blackstone
fill 453 154 504 453 157 504 minecraft:blackstone
setblock 457 154 464 minecraft:polished_blackstone_bricks
setblock 457 154 504 minecraft:polished_blackstone_bricks
fill 458 154 464 458 157 464 minecraft:blackstone
setblock 458 154 503 minecraft:polished_blackstone_bricks
fill 458 154 504 458 157 504 minecraft:blackstone
setblock 459 154 502 minecraft:polished_blackstone_bricks
fill 459 154 503 459 157 503 minecraft:blackstone
fill 460 154 502 460 157 502 minecraft:blackstone
setblock 461 154 465 minecraft:polished_blackstone_bricks
setblock 462 154 464 minecraft:polished_blackstone_bricks
fill 462 154 465 462 157 465 minecraft:blackstone
setblock 462 154 499 minecraft:polished_blackstone_bricks
fill 462 154 500 462 157 500 minecraft:blackstone
setblock 462 154 504 minecraft:polished_blackstone_bricks
fill 463 154 464 463 157 464 minecraft:blackstone
setblock 463 154 478 minecraft:polished_blackstone_bricks
setblock 463 154 479 minecraft:blackstone
setblock 463 154 483 minecraft:polished_blackstone_bricks
setblock 463 154 498 minecraft:polished_blackstone_bricks
fill 463 154 499 463 157 499 minecraft:blackstone
setblock 463 154 503 minecraft:polished_blackstone_bricks
fill 463 154 504 463 157 504 minecraft:blackstone
setblock 464 154 467 minecraft:polished_blackstone_bricks
fill 464 154 468 464 157 468 minecraft:blackstone
setblock 464 154 477 minecraft:polished_blackstone_bricks
fill 464 154 478 464 157 478 minecraft:blackstone
setblock 464 154 482 minecraft:polished_blackstone_bricks
fill 464 154 483 464 157 483 minecraft:blackstone
setblock 464 154 487 minecraft:polished_blackstone_bricks
fill 464 154 488 464 157 488 minecraft:blackstone
setblock 464 154 492 minecraft:polished_blackstone_bricks
fill 464 154 493 464 157 493 minecraft:blackstone
setblock 464 154 497 minecraft:polished_blackstone_bricks
fill 464 154 498 464 157 498 minecraft:blackstone
setblock 464 154 502 minecraft:polished_blackstone_bricks
fill 464 154 503 464 157 503 minecraft:blackstone
setblock 424 155 476 minecraft:polished_blackstone_bricks
fill 424 155 477 424 157 477 minecraft:blackstone
setblock 424 155 481 minecraft:polished_blackstone_bricks
fill 424 155 482 424 158 482 minecraft:blackstone
setblock 424 155 486 minecraft:polished_blackstone_bricks
fill 424 155 487 424 158 487 minecraft:blackstone
setblock 424 155 491 minecraft:polished_blackstone_bricks
fill 424 155 492 424 158 492 minecraft:blackstone
setblock 424 155 496 minecraft:polished_blackstone_bricks
fill 424 155 497 424 158 497 minecraft:blackstone
setblock 424 155 501 minecraft:polished_blackstone_bricks
fill 424 155 502 424 158 502 minecraft:blackstone
setblock 425 155 480 minecraft:polished_blackstone_bricks
fill 425 155 481 425 158 481 minecraft:blackstone
setblock 425 155 485 minecraft:polished_blackstone_bricks
fill 425 155 486 425 158 486 minecraft:blackstone
setblock 425 155 495 minecraft:polished_blackstone_bricks
fill 425 155 496 425 156 496 minecraft:blackstone
setblock 425 155 500 minecraft:polished_blackstone_bricks
fill 425 155 501 425 158 501 minecraft:blackstone
setblock 426 155 464 minecraft:polished_blackstone_bricks
setblock 426 155 504 minecraft:polished_blackstone_bricks
setblock 427 155 503 minecraft:polished_blackstone_bricks
fill 427 155 504 427 158 504 minecraft:blackstone
setblock 428 155 503 minecraft:blackstone
fill 438 155 504 440 155 504 minecraft:blackstone
setblock 441 155 464 minecraft:polished_blackstone_bricks
setblock 441 155 503 minecraft:blackstone
setblock 441 155 504 minecraft:polished_blackstone_bricks
fill 442 155 464 442 157 465 minecraft:blackstone
setblock 442 155 503 minecraft:polished_blackstone_bricks
fill 442 155 504 442 158 504 minecraft:blackstone
fill 443 155 503 443 158 503 minecraft:blackstone
setblock 445 155 465 minecraft:polished_blackstone_bricks
setblock 446 155 464 minecraft:polished_blackstone_bricks
fill 446 155 465 446 158 465 minecraft:blackstone
setblock 446 155 504 minecraft:polished_blackstone_bricks
fill 447 155 464 450 155 464 minecraft:blackstone
fill 447 155 504 450 155 504 minecraft:blackstone
setblock 451 155 464 minecraft:polished_blackstone_bricks
setblock 451 155 504 minecraft:polished_blackstone_bricks
fill 452 155 464 452 158 464 minecraft:blackstone
fill 452 155 504 452 158 504 minecraft:blackstone
setblock 456 155 464 minecraft:polished_blackstone_bricks
setblock 456 155 503 minecraft:blackstone
setblock 456 155 504 minecraft:polished_blackstone_bricks
fill 457 155 464 457 158 464 minecraft:blackstone
setblock 457 155 503 minecraft:polished_blackstone_bricks
fill 457 155 504 457 158 504 minecraft:blackstone
fill 458 155 465 458 156 465 minecraft:blackstone
fill 458 155 503 458 158 503 minecraft:blackstone
fill 459 155 502 459 158 502 minecraft:blackstone
setblock 460 155 465 minecraft:polished_blackstone_bricks
setblock 461 155 464 minecraft:polished_blackstone_bricks
fill 461 155 465 461 158 465 minecraft:blackstone
setblock 461 155 504 minecraft:polished_blackstone_bricks
fill 462 155 464 462 158 464 minecraft:blackstone
fill 462 155 499 462 157 499 minecraft:blackstone
setblock 462 155 503 minecraft:polished_blackstone_bricks
fill 462 155 504 462 158 504 minecraft:blackstone
setblock 463 155 482 minecraft:polished_blackstone_bricks
fill 463 155 483 463 157 484 minecraft:blackstone
setblock 463 155 497 minecraft:polished_blackstone_bricks
fill 463 155 498 463 158 498 minecraft:blackstone
setblock 463 155 502 minecraft:polished_blackstone_bricks
fill 463 155 503 463 158 503 minecraft:blackstone
setblock 464 155 466 minecraft:polished_blackstone_bricks
fill 464 155 467 464 158 467 minecraft:blackstone
setblock 464 155 476 minecraft:polished_blackstone_bricks
fill 464 155 477 464 156 477 minecraft:blackstone
setblock 464 155 481 minecraft:polished_blackstone_bricks
fill 464 155 482 464 158 482 minecraft:blackstone
setblock 464 155 486 minecraft:polished_blackstone_bricks
fill 464 155 487 464 158 487 minecraft:blackstone
setblock 464 155 491 minecraft:polished_blackstone_bricks
fill 464 155 492 464 158 492 minecraft:blackstone
setblock 464 155 496 minecraft:polished_blackstone_bricks
fill 464 155 497 464 158 497 minecraft:blackstone
setblock 464 155 501 minecraft:polished_blackstone_bricks
fill 464 155 502 464 158 502 minecraft:blackstone
setblock 424 156 465 minecraft:polished_blackstone_bricks
fill 424 156 466 424 159 466 minecraft:blackstone
setblock 424 156 480 minecraft:polished_blackstone_bricks
fill 424 156 481 424 159 481 minecraft:blackstone
setblock 424 156 485 minecraft:polished_blackstone_bricks
fill 424 156 486 424 159 486 minecraft:blackstone
setblock 424 156 490 minecraft:polished_blackstone_bricks
fill 424 156 491 424 159 491 minecraft:blackstone
setblock 424 156 495 minecraft:polished_blackstone_bricks
fill 424 156 496 424 159 496 minecraft:blackstone
setblock 424 156 500 minecraft:polished_blackstone_bricks
fill 424 156 501 424 159 501 minecraft:blackstone
setblock 425 156 464 minecraft:polished_blackstone_bricks
setblock 425 156 479 minecraft:polished_blackstone_bricks
fill 425 156 480 425 159 480 minecraft:blackstone
setblock 425 156 484 minecraft:polished_blackstone_bricks
fill 425 156 485 425 159 485 minecraft:blackstone
setblock 425 156 489 minecraft:polished_blackstone_bricks
fill 425 156 490 425 159 490 minecraft:blackstone
setblock 425 156 499 minecraft:polished_blackstone_bricks
fill 425 156 500 425 158 500 minecraft:blackstone
setblock 425 156 504 minecraft:polished_blackstone_bricks
fill 426 156 464 426 159 464 minecraft:blackstone
setblock 426 156 503 minecraft:polished_blackstone_bricks
fill 426 156 504 426 159 504 minecraft:blackstone
setblock 427 156 503 minecraft:blackstone
fill 437 156 504 439 156 504 minecraft:blackstone
fill 438 156 464 438 157 464 minecraft:blackstone
setblock 440 156 464 minecraft:polished_blackstone_bricks
fill 440 156 465 441 158 465 minecraft:blackstone
setblock 440 156 504 minecraft:polished_blackstone_bricks
fill 441 156 464 441 159 464 minecraft:blackstone
setblock 441 156 503 minecraft:polished_blackstone_bricks
fill 441 156 504 441 159 504 minecraft:blackstone
fill 442 156 503 442 159 503 minecraft:blackstone
setblock 444 156 465 minecraft:polished_blackstone_bricks
setblock 445 156 464 minecraft:polished_blackstone_bricks
fill 445 156 465 445 159 465 minecraft:blackstone
setblock 445 156 504 minecraft:polished_blackstone_bricks
fill 446 156 464 449 156 464 minecraft:blackstone
fill 446 156 504 449 156 504 minecraft:blackstone
setblock 450 156 464 minecraft:polished_blackstone_bricks
setblock 450 156 504 minecraft:polished_blackstone_bricks
fill 451 156 464 451 159 464 minecraft:blackstone
fill 451 156 504 451 159 504 minecraft:blackstone
setblock 455 156 464 minecraft:polished_blackstone_bricks
setblock 455 156 504 minecraft:polished_blackstone_bricks
fill 456 156 464 456 159 464 minecraft:blackstone
setblock 456 156 503 minecraft:polished_blackstone_bricks
fill 456 156 504 456 159 504 minecraft:blackstone
fill 457 156 465 457 157 465 minecraft:blackstone
fill 457 156 503 457 159 503 minecraft:blackstone
setblock 459 156 464 minecraft:blackstone
setblock 459 156 465 minecraft:polished_blackstone_bricks
setblock 460 156 464 minecraft:polished_blackstone_bricks
fill 460 156 465 460 159 465 minecraft:blackstone
setblock 460 156 504 minecraft:polished_blackstone_bricks
fill 461 156 464 461 159 464 minecraft:blackstone
setblock 461 156 503 minecraft:polished_blackstone_bricks
fill 461 156 504 461 159 504 minecraft:blackstone
setblock 462 156 502 minecraft:polished_blackstone_bricks
fill 462 156 503 462 159 503 minecraft:blackstone
setblock 463 156 466 minecraft:polished_blackstone_bricks
setblock 463 156 481 minecraft:polished_blackstone_bricks
fill 463 156 482 463 159 482 minecraft:blackstone
setblock 463 156 485 minecraft:blackstone
fill 463 156 497 463 159 497 minecraft:blackstone
setblock 463 156 501 minecraft:polished_blackstone_bricks
fill 463 156 502 463 159 502 minecraft:blackstone
setblock 464 156 465 minecraft:polished_blackstone_bricks
fill 464 156 466 464 159 466 minecraft:blackstone
setblock 464 156 480 minecraft:polished_blackstone_bricks
fill 464 156 481 464 159 481 minecraft:blackstone
setblock 464 156 485 minecraft:polished_blackstone_bricks
fill 464 156 486 464 159 486 minecraft:blackstone
setblock 464 156 490 minecraft:polished_blackstone_bricks
fill 464 156 491 464 159 491 minecraft:blackstone
setblock 464 156 495 minecraft:polished_blackstone_bricks
fill 464 156 496 464 159 496 minecraft:blackstone
setblock 464 156 500 minecraft:polished_blackstone_bricks
fill 464 156 501 464 159 501 minecraft:blackstone
setblock 424 157 464 minecraft:polished_blackstone_bricks
fill 424 157 465 424 160 465 minecraft:blackstone
setblock 424 157 479 minecraft:polished_blackstone_bricks
fill 424 157 480 424 160 480 minecraft:blackstone
setblock 424 157 484 minecraft:polished_blackstone_bricks
fill 424 157 485 424 160 485 minecraft:blackstone
setblock 424 157 489 minecraft:polished_blackstone_bricks
fill 424 157 490 424 160 490 minecraft:blackstone
setblock 424 157 494 minecraft:polished_blackstone_bricks
fill 424 157 495 424 160 495 minecraft:blackstone
setblock 424 157 499 minecraft:polished_blackstone_bricks
fill 424 157 500 424 160 500 minecraft:blackstone
setblock 424 157 504 minecraft:polished_blackstone_bricks
fill 425 157 464 425 160 464 minecraft:blackstone
setblock 425 157 483 minecraft:polished_blackstone_bricks
fill 425 157 484 425 160 484 minecraft:blackstone
setblock 425 157 488 minecraft:polished_blackstone_bricks
fill 425 157 489 425 160 489 minecraft:blackstone
setblock 425 157 498 minecraft:polished_blackstone_bricks
setblock 425 157 499 minecraft:blackstone
setblock 425 157 503 minecraft:polished_blackstone_bricks
fill 425 157 504 425 160 504 minecraft:blackstone
fill 426 157 503 426 158 503 minecraft:blackstone
fill 437 157 464 437 158 464 minecraft:blackstone
fill 437 157 504 438 157 504 minecraft:blackstone
setblock 439 157 464 minecraft:polished_blackstone_bricks
fill 439 157 465 439 160 465 minecraft:blackstone
setblock 439 157 504 minecraft:polished_blackstone_bricks
fill 440 157 464 440 160 464 minecraft:blackstone
fill 440 157 504 440 160 504 minecraft:blackstone
fill 441 157 503 441 160 503 minecraft:blackstone
setblock 443 157 465 minecraft:polished_blackstone_bricks
setblock 444 157 464 minecraft:polished_blackstone_bricks
fill 444 157 465 444 160 465 minecraft:blackstone
setblock 444 157 504 minecraft:polished_blackstone_bricks
fill 445 157 464 448 157 464 minecraft:blackstone
fill 445 157 504 448 157 504 minecraft:blackstone
setblock 448 157 465 minecraft:polished_blackstone_bricks
setblock 449 157 464 minecraft:polished_blackstone_bricks
setblock 449 157 504 minecraft:polished_blackstone_bricks
fill 450 157 464 450 160 464 minecraft:blackstone
fill 450 157 504 450 160 504 minecraft:blackstone
setblock 454 157 464 minecraft:polished_blackstone_bricks
setblock 454 157 504 minecraft:polished_blackstone_bricks
fill 455 157 464 455 159 465 minecraft:blackstone
setblock 455 157 503 minecraft:polished_blackstone_bricks
fill 455 157 504 455 160 504 minecraft:blackstone
fill 456 157 465 456 158 465 minecraft:blackstone
fill 456 157 503 456 160 503 minecraft:blackstone
fill 457 157 470 461 158 474 minecraft:blackstone
setblock 458 157 465 minecraft:polished_blackstone_bricks
fill 458 157 502 458 159 502 minecraft:blackstone
setblock 459 157 464 minecraft:polished_blackstone_bricks
fill 459 157 465 459 160 465 minecraft:blackstone
setblock 459 157 504 minecraft:polished_blackstone_bricks
fill 460 157 464 460 160 464 minecraft:blackstone
setblock 460 157 503 minecraft:polished_blackstone_bricks
fill 460 157 504 460 160 504 minecraft:blackstone
setblock 461 157 502 minecraft:polished_blackstone_bricks
fill 461 157 503 461 160 503 minecraft:blackstone
fill 462 157 472 463 157 472 minecraft:blackstone
setblock 462 157 501 minecraft:polished_blackstone_bricks
fill 462 157 502 462 160 502 minecraft:blackstone
setblock 463 157 465 minecraft:polished_blackstone_bricks
fill 463 157 466 463 159 467 minecraft:blackstone
setblock 463 157 481 minecraft:blackstone
setblock 463 157 485 minecraft:polished_blackstone_bricks
fill 463 157 486 463 159 487 minecraft:blackstone
setblock 463 157 500 minecraft:polished_blackstone_bricks
fill 463 157 501 463 160 501 minecraft:blackstone
setblock 464 157 464 minecraft:polished_blackstone_bricks
fill 464 157 465 464 160 465 minecraft:blackstone
setblock 464 157 479 minecraft:polished_blackstone_bricks
fill 464 157 480 464 160 480 minecraft:blackstone
setblock 464 157 484 minecraft:polished_blackstone_bricks
fill 464 157 485 464 160 485 minecraft:blackstone
setblock 464 157 489 minecraft:polished_blackstone_bricks
fill 464 157 490 464 160 490 minecraft:blackstone
setblock 464 157 494 minecraft:polished_blackstone_bricks
fill 464 157 495 464 160 495 minecraft:blackstone
setblock 464 157 499 minecraft:polished_blackstone_bricks
fill 464 157 500 464 160 500 minecraft:blackstone
setblock 464 157 504 minecraft:polished_blackstone_bricks
fill 424 158 464 424 160 464 minecraft:blackstone
setblock 424 158 478 minecraft:polished_blackstone_bricks
fill 424 158 479 424 160 479 minecraft:blackstone
setblock 424 158 483 minecraft:polished_blackstone_bricks
fill 424 158 484 424 160 484 minecraft:blackstone
setblock 424 158 488 minecraft:polished_blackstone_bricks
fill 424 158 489 424 160 489 minecraft:blackstone
setblock 424 158 493 minecraft:polished_blackstone_bricks
fill 424 158 494 424 160 494 minecraft:blackstone
setblock 424 158 498 minecraft:polished_blackstone_bricks
fill 424 158 499 424 160 499 minecraft:blackstone
setblock 424 158 503 minecraft:polished_blackstone_bricks
fill 424 158 504 424 160 504 minecraft:blackstone
setblock 425 158 482 minecraft:polished_blackstone_bricks
fill 425 158 483 425 160 483 minecraft:blackstone
setblock 425 158 487 minecraft:polished_blackstone_bricks
fill 425 158 488 425 160 488 minecraft:blackstone
setblock 425 158 491 minecraft:blackstone
setblock 425 158 502 minecraft:polished_blackstone_bricks
fill 425 158 503 425 160 503 minecraft:blackstone
setblock 426 158 466 minecraft:light[level=11]
setblock 426 158 474 minecraft:light[level=11]
setblock 426 158 482 minecraft:light[level=11]
setblock 426 158 485 minecraft:blackstone
setblock 426 158 490 minecraft:light[level=11]
setblock 426 158 498 minecraft:light[level=11]
setblock 428 158 504 minecraft:polished_blackstone_bricks
setblock 434 158 466 minecraft:light[level=11]
setblock 434 158 474 minecraft:light[level=11]
setblock 434 158 482 minecraft:light[level=11]
setblock 434 158 490 minecraft:light[level=11]
setblock 434 158 498 minecraft:light[level=11]
fill 435 158 464 436 159 464 minecraft:blackstone
fill 436 158 504 437 158 504 minecraft:blackstone
setblock 438 158 464 minecraft:polished_blackstone_bricks
fill 438 158 465 438 160 465 minecraft:blackstone
setblock 438 158 504 minecraft:polished_blackstone_bricks
fill 439 158 464 439 160 464 minecraft:blackstone
fill 439 158 504 439 160 504 minecraft:blackstone
fill 440 158 503 440 160 503 minecraft:blackstone
setblock 441 158 466 minecraft:polished_blackstone_bricks
setblock 442 158 464 minecraft:blackstone
setblock 442 158 465 minecraft:polished_blackstone_bricks
fill 442 158 466 444 159 466 minecraft:blackstone
setblock 442 158 474 minecraft:light[level=11]
setblock 442 158 482 minecraft:light[level=11]
setblock 442 158 490 minecraft:light[level=11]
setblock 442 158 498 minecraft:light[level=11]
setblock 443 158 464 minecraft:polished_blackstone_bricks
fill 443 158 465 443 160 465 minecraft:blackstone
setblock 443 158 504 minecraft:polished_blackstone_bricks
fill 444 158 464 447 158 464 minecraft:blackstone
fill 444 158 504 447 158 504 minecraft:blackstone
setblock 447 158 465 minecraft:polished_blackstone_bricks
setblock 448 158 464 minecraft:polished_blackstone_bricks
fill 448 158 465 450 159 465 minecraft:blackstone
setblock 448 158 504 minecraft:polished_blackstone_bricks
fill 449 158 464 449 160 464 minecraft:blackstone
fill 449 158 504 449 160 504 minecraft:blackstone
setblock 450 158 466 minecraft:light[level=11]
setblock 450 158 474 minecraft:light[level=11]
setblock 450 158 482 minecraft:light[level=11]
setblock 450 158 490 minecraft:light[level=11]
setblock 450 158 498 minecraft:light[level=11]
setblock 453 158 464 minecraft:polished_blackstone_bricks
fill 453 158 465 454 160 465 minecraft:blackstone
setblock 453 158 504 minecraft:polished_blackstone_bricks
fill 454 158 464 454 160 464 minecraft:blackstone
fill 454 158 504 454 160 504 minecraft:blackstone
fill 455 158 503 455 160 503 minecraft:blackstone
setblock 457 158 465 minecraft:polished_blackstone_bricks
setblock 458 158 464 minecraft:polished_blackstone_bricks
fill 458 158 465 458 160 465 minecraft:blackstone
setblock 458 158 466 minecraft:light[level=11]
setblock 458 158 482 minecraft:light[level=11]
setblock 458 158 490 minecraft:light[level=11]
setblock 458 158 498 minecraft:light[level=11]
setblock 458 158 504 minecraft:polished_blackstone_bricks
fill 459 158 464 459 160 464 minecraft:blackstone
fill 459 158 466 460 158 466 minecraft:blackstone
setblock 459 158 503 minecraft:polished_blackstone_bricks
fill 459 158 504 459 160 504 minecraft:blackstone
setblock 460 158 502 minecraft:polished_blackstone_bricks
fill 460 158 503 460 160 503 minecraft:blackstone
setblock 461 158 466 minecraft:polished_blackstone_bricks
fill 461 158 502 461 160 502 minecraft:blackstone
setblock 462 158 465 minecraft:polished_blackstone_bricks
setblock 462 158 500 minecraft:polished_blackstone_bricks
fill 462 158 501 462 160 501 minecraft:blackstone
setblock 463 158 464 minecraft:polished_blackstone_bricks
fill 463 158 465 463 160 465 minecraft:blackstone
setblock 463 158 483 minecraft:blackstone
setblock 463 158 484 minecraft:polished_blackstone_bricks
fill 463 158 485 463 160 485 minecraft:blackstone
setblock 463 158 488 minecraft:blackstone
setblock 463 158 489 minecraft:polished_blackstone_bricks
setblock 463 158 499 minecraft:polished_blackstone_bricks
fill 463 158 500 463 160 500 minecraft:blackstone
setblock 463 158 504 minecraft:polished_blackstone_bricks
fill 464 158 464 464 160 464 minecraft:blackstone
setblock 464 158 468 minecraft:polished_blackstone_bricks
fill 464 158 469 464 160 469 minecraft:blackstone
fill 464 158 479 464 159 479 minecraft:blackstone
setblock 464 158 483 minecraft:polished_blackstone_bricks
fill 464 158 484 464 160 484 minecraft:blackstone
setblock 464 158 488 minecraft:polished_blackstone_bricks
fill 464 158 489 464 160 489 minecraft:blackstone
setblock 464 158 493 minecraft:polished_blackstone_bricks
fill 464 158 494 464 160 494 minecraft:blackstone
setblock 464 158 498 minecraft:polished_blackstone_bricks
fill 464 158 499 464 160 499 minecraft:blackstone
setblock 464 158 503 minecraft:polished_blackstone_bricks
fill 464 158 504 464 160 504 minecraft:blackstone
setblock 424 159 467 minecraft:polished_blackstone_bricks
fill 424 159 478 424 160 478 minecraft:blackstone
setblock 424 159 482 minecraft:polished_blackstone_bricks
fill 424 159 483 424 160 483 minecraft:blackstone
setblock 424 159 487 minecraft:polished_blackstone_bricks
fill 424 159 488 424 160 488 minecraft:blackstone
setblock 424 159 492 minecraft:polished_blackstone_bricks
fill 424 159 493 424 160 493 minecraft:blackstone
setblock 424 159 497 minecraft:polished_blackstone_bricks
fill 424 159 498 424 160 498 minecraft:blackstone
setblock 424 159 502 minecraft:polished_blackstone_bricks
fill 424 159 503 424 160 503 minecraft:blackstone
setblock 425 159 481 minecraft:polished_blackstone_bricks
fill 425 159 482 425 160 482 minecraft:blackstone
setblock 425 159 486 minecraft:polished_blackstone_bricks
fill 425 159 487 426 160 487 minecraft:blackstone
setblock 425 159 491 minecraft:polished_blackstone_bricks
fill 425 159 492 425 160 492 minecraft:blackstone
setblock 425 159 501 minecraft:polished_blackstone_bricks
setblock 425 159 502 minecraft:blackstone
setblock 426 159 484 minecraft:blackstone
setblock 426 159 485 minecraft:polished_blackstone_bricks
fill 426 159 486 426 160 486 minecraft:blackstone
setblock 427 159 504 minecraft:polished_blackstone_bricks
setblock 428 159 504 minecraft:blackstone
fill 434 159 464 434 160 464 minecraft:blackstone
fill 435 159 504 436 159 504 minecraft:blackstone
setblock 436 159 465 minecraft:polished_blackstone_bricks
setblock 437 159 464 minecraft:polished_blackstone_bricks
fill 437 159 465 437 160 465 minecraft:blackstone
setblock 437 159 504 minecraft:polished_blackstone_bricks
fill 438 159 464 438 160 464 minecraft:blackstone
fill 438 159 504 438 160 504 minecraft:blackstone
setblock 439 159 466 minecraft:blackstone
fill 439 159 503 439 160 503 minecraft:blackstone
setblock 440 159 465 minecraft:blackstone
setblock 440 159 466 minecraft:polished_blackstone_bricks
setblock 441 159 465 minecraft:polished_blackstone_bricks
fill 441 159 466 441 160 466 minecraft:blackstone
setblock 442 159 464 minecraft:polished_blackstone_bricks
fill 442 159 465 442 160 465 minecraft:blackstone
setblock 442 159 504 minecraft:polished_blackstone_bricks
fill 443 159 464 446 159 464 minecraft:blackstone
setblock 443 159 503 minecraft:polished_blackstone_bricks
fill 443 159 504 446 159 504 minecraft:blackstone
setblock 445 159 466 minecraft:polished_blackstone_bricks
setblock 446 159 465 minecraft:polished_blackstone_bricks
setblock 447 159 464 minecraft:polished_blackstone_bricks
fill 447 159 465 447 160 465 minecraft:blackstone
setblock 447 159 504 minecraft:polished_blackstone_bricks
fill 448 159 464 448 160 464 minecraft:blackstone
fill 448 159 504 448 160 504 minecraft:blackstone
setblock 451 159 465 minecraft:polished_blackstone_bricks
setblock 452 159 464 minecraft:polished_blackstone_bricks
fill 452 159 465 452 160 465 minecraft:blackstone
setblock 452 159 504 minecraft:polished_blackstone_bricks
fill 453 159 464 453 160 464 minecraft:blackstone
fill 453 159 504 453 160 504 minecraft:blackstone
fill 454 159 503 454 160 503 minecraft:blackstone
setblock 456 159 465 minecraft:polished_blackstone_bricks
setblock 457 159 464 minecraft:polished_blackstone_bricks
fill 457 159 465 457 160 466 minecraft:blackstone
fill 457 159 502 457 160 502 minecraft:blackstone
setblock 457 159 504 minecraft:polished_blackstone_bricks
fill 458 159 464 458 160 464 minecraft:blackstone
fill 458 159 466 459 159 466 minecraft:blackstone
fill 458 159 472 460 159 473 minecraft:polished_blackstone_bricks
setblock 458 159 503 minecraft:polished_blackstone_bricks
fill 458 159 504 458 160 504 minecraft:blackstone
setblock 459 159 474 minecraft:polished_blackstone_bricks
setblock 459 159 502 minecraft:polished_blackstone_bricks
fill 459 159 503 459 160 503 minecraft:blackstone
setblock 460 159 466 minecraft:polished_blackstone_bricks
fill 460 159 502 460 160 502 minecraft:blackstone
setblock 461 159 465 minecraft:polished_blackstone_bricks
fill 461 159 466 462 160 466 minecraft:blackstone
setblock 462 159 464 minecraft:polished_blackstone_bricks
fill 462 159 465 462 160 465 minecraft:blackstone
fill 462 159 500 462 160 500 minecraft:blackstone
setblock 462 159 504 minecraft:polished_blackstone_bricks
fill 463 159 464 463 160 464 minecraft:blackstone
setblock 463 159 468 minecraft:polished_blackstone_bricks
setblock 463 159 483 minecraft:polished_blackstone_bricks
fill 463 159 484 463 160 484 minecraft:blackstone
setblock 463 159 488 minecraft:polished_blackstone_bricks
fill 463 159 489 463 159 492 minecraft:blackstone
fill 463 159 496 463 160 496 minecraft:blackstone
setblock 463 159 498 minecraft:polished_blackstone_bricks
fill 463 159 499 463 160 499 minecraft:blackstone
setblock 463 159 503 minecraft:polished_blackstone_bricks
fill 463 159 504 463 160 504 minecraft:blackstone
setblock 464 159 467 minecraft:polished_blackstone_bricks
fill 464 159 468 464 160 468 minecraft:blackstone
setblock 464 159 482 minecraft:polished_blackstone_bricks
fill 464 159 483 464 160 483 minecraft:blackstone
setblock 464 159 487 minecraft:polished_blackstone_bricks
fill 464 159 488 464 160 488 minecraft:blackstone
setblock 464 159 492 minecraft:polished_blackstone_bricks
fill 464 159 493 464 160 493 minecraft:blackstone
setblock 464 159 497 minecraft:polished_blackstone_bricks
fill 464 159 498 464 160 498 minecraft:blackstone
setblock 464 159 502 minecraft:polished_blackstone_bricks
fill 464 159 503 464 160 503 minecraft:blackstone
setblock 424 160 466 minecraft:polished_blackstone_bricks
fill 424 160 467 424 160 468 minecraft:blackstone
setblock 424 160 481 minecraft:polished_blackstone_bricks
setblock 424 160 482 minecraft:blackstone
setblock 424 160 486 minecraft:polished_blackstone_bricks
setblock 424 160 487 minecraft:blackstone
setblock 424 160 491 minecraft:polished_blackstone_bricks
setblock 424 160 492 minecraft:blackstone
setblock 424 160 496 minecraft:polished_blackstone_bricks
setblock 424 160 497 minecraft:blackstone
setblock 424 160 501 minecraft:polished_blackstone_bricks
setblock 424 160 502 minecraft:blackstone
setblock 425 160 481 minecraft:blackstone
setblock 425 160 485 minecraft:polished_blackstone_bricks
setblock 425 160 486 minecraft:blackstone
setblock 425 160 490 minecraft:polished_blackstone_bricks
setblock 425 160 491 minecraft:blackstone
setblock 426 160 464 minecraft:polished_blackstone_bricks
setblock 426 160 484 minecraft:polished_blackstone_bricks
setblock 426 160 485 minecraft:blackstone
setblock 426 160 488 minecraft:blackstone
setblock 426 160 504 minecraft:polished_blackstone_bricks
setblock 427 160 504 minecraft:blackstone
setblock 433 160 464 minecraft:blackstone
fill 434 160 504 435 160 504 minecraft:blackstone
setblock 435 160 464 minecraft:blackstone
setblock 435 160 465 minecraft:polished_blackstone_bricks
setblock 436 160 464 minecraft:polished_blackstone_bricks
setblock 436 160 465 minecraft:blackstone
setblock 436 160 504 minecraft:polished_blackstone_bricks
setblock 437 160 464 minecraft:blackstone
fill 437 160 466 438 160 466 minecraft:blackstone
setblock 437 160 504 minecraft:blackstone
setblock 439 160 466 minecraft:polished_blackstone_bricks
setblock 440 160 465 minecraft:polished_blackstone_bricks
setblock 440 160 466 minecraft:blackstone
setblock 441 160 464 minecraft:polished_blackstone_bricks
setblock 441 160 465 minecraft:blackstone
setblock 441 160 504 minecraft:polished_blackstone_bricks
fill 442 160 464 445 160 464 minecraft:blackstone
fill 442 160 466 443 160 466 minecraft:blackstone
setblock 442 160 503 minecraft:polished_blackstone_bricks
fill 442 160 504 445 160 504 minecraft:blackstone
setblock 443 160 503 minecraft:blackstone
setblock 444 160 466 minecraft:polished_blackstone_bricks
setblock 445 160 465 minecraft:polished_blackstone_bricks
fill 445 160 466 446 160 466 minecraft:blackstone
setblock 446 160 464 minecraft:polished_blackstone_bricks
setblock 446 160 465 minecraft:blackstone
setblock 446 160 504 minecraft:polished_blackstone_bricks
setblock 447 160 464 minecraft:blackstone
setblock 447 160 504 minecraft:blackstone
fill 448 160 465 449 160 465 minecraft:blackstone
setblock 450 160 465 minecraft:polished_blackstone_bricks
setblock 451 160 464 minecraft:polished_blackstone_bricks
setblock 451 160 465 minecraft:blackstone
setblock 451 160 504 minecraft:polished_blackstone_bricks
setblock 452 160 464 minecraft:blackstone
setblock 452 160 504 minecraft:blackstone
setblock 453 160 503 minecraft:blackstone
setblock 454 160 466 minecraft:polished_blackstone_bricks
setblock 455 160 464 minecraft:blackstone
setblock 455 160 465 minecraft:polished_blackstone_bricks
fill 455 160 466 456 160 466 minecraft:blackstone
setblock 456 160 464 minecraft:polished_blackstone_bricks
setblock 456 160 465 minecraft:blackstone
setblock 456 160 504 minecraft:polished_blackstone_bricks
setblock 457 160 464 minecraft:blackstone
fill 457 160 471 457 160 475 minecraft:warped_wart_block
setblock 457 160 503 minecraft:polished_blackstone_bricks
setblock 457 160 504 minecraft:blackstone
setblock 458 160 466 minecraft:blackstone
fill 458 160 471 461 160 471 minecraft:warped_wart_block
fill 458 160 472 460 160 472 minecraft:polished_blackstone_bricks
fill 458 160 473 458 160 475 minecraft:warped_wart_block
setblock 458 160 502 minecraft:polished_blackstone_bricks
setblock 458 160 503 minecraft:blackstone
setblock 459 160 466 minecraft:polished_blackstone_bricks
setblock 459 160 473 minecraft:polished_blackstone_bricks
fill 459 160 474 461 160 475 minecraft:warped_wart_block
setblock 459 160 502 minecraft:blackstone
setblock 460 160 465 minecraft:polished_blackstone_bricks
setblock 460 160 466 minecraft:blackstone
fill 460 160 473 461 160 473 minecraft:warped_wart_block
setblock 461 160 464 minecraft:polished_blackstone_bricks
setblock 461 160 465 minecraft:blackstone
setblock 461 160 472 minecraft:warped_wart_block
setblock 461 160 504 minecraft:polished_blackstone_bricks
setblock 462 160 464 minecraft:blackstone
setblock 462 160 467 minecraft:blackstone
fill 462 160 485 462 160 487 minecraft:blackstone
setblock 462 160 488 minecraft:polished_blackstone_bricks
setblock 462 160 503 minecraft:polished_blackstone_bricks
setblock 462 160 504 minecraft:blackstone
setblock 463 160 466 minecraft:blackstone
setblock 463 160 467 minecraft:polished_blackstone_bricks
setblock 463 160 468 minecraft:blackstone
setblock 463 160 482 minecraft:polished_blackstone_bricks
setblock 463 160 483 minecraft:blackstone
setblock 463 160 486 minecraft:blackstone
setblock 463 160 487 minecraft:polished_blackstone_bricks
fill 463 160 488 463 160 491 minecraft:blackstone
setblock 463 160 492 minecraft:polished_blackstone_bricks
fill 463 160 493 463 160 495 minecraft:blackstone
setblock 463 160 497 minecraft:polished_blackstone_bricks
setblock 463 160 498 minecraft:blackstone
setblock 463 160 502 minecraft:polished_blackstone_bricks
setblock 463 160 503 minecraft:blackstone
setblock 464 160 466 minecraft:polished_blackstone_bricks
setblock 464 160 467 minecraft:blackstone
setblock 464 160 470 minecraft:blackstone
setblock 464 160 481 minecraft:polished_blackstone_bricks
setblock 464 160 482 minecraft:blackstone
setblock 464 160 486 minecraft:polished_blackstone_bricks
setblock 464 160 487 minecraft:blackstone
setblock 464 160 491 minecraft:polished_blackstone_bricks
setblock 464 160 492 minecraft:blackstone
setblock 464 160 496 minecraft:polished_blackstone_bricks
setblock 464 160 497 minecraft:blackstone
setblock 464 160 501 minecraft:polished_blackstone_bricks
setblock 464 160 502 minecraft:blackstone
fill 441 165 479 443 165 481 minecraft:redstone_block
fill 443 165 488 445 165 490 minecraft:redstone_block
fill 447 165 479 449 165 481 minecraft:redstone_block
setblock 426 166 466 minecraft:light[level=11]
setblock 426 166 474 minecraft:light[level=11]
setblock 426 166 482 minecraft:light[level=11]
setblock 426 166 490 minecraft:light[level=11]
setblock 426 166 498 minecraft:light[level=11]
setblock 434 166 466 minecraft:light[level=11]
setblock 434 166 474 minecraft:light[level=11]
setblock 434 166 482 minecraft:light[level=11]
setblock 434 166 490 minecraft:light[level=11]
setblock 434 166 498 minecraft:light[level=11]
fill 437 166 482 437 167 486 minecraft:cyan_concrete
fill 438 166 480 438 167 483 minecraft:cyan_concrete
fill 438 166 484 438 167 484 minecraft:light_blue_concrete
fill 438 166 485 438 167 488 minecraft:cyan_concrete
fill 439 166 479 439 167 480 minecraft:cyan_concrete
fill 439 166 481 439 167 482 minecraft:soul_soil
fill 439 166 483 439 167 483 minecraft:light_blue_concrete
fill 439 166 484 439 167 485 minecraft:soul_soil
fill 439 166 486 439 167 486 minecraft:light_blue_concrete
fill 439 166 487 440 167 487 minecraft:soul_soil
fill 439 166 488 439 167 489 minecraft:cyan_concrete
fill 440 166 478 440 166 479 minecraft:cyan_concrete
fill 440 166 480 440 166 481 minecraft:soul_soil
setblock 440 166 482 minecraft:light_blue_concrete
fill 440 166 483 440 167 484 minecraft:soul_soil
fill 440 166 485 440 167 485 minecraft:light_blue_concrete
fill 440 166 486 441 167 486 minecraft:soul_soil
fill 440 166 488 440 167 488 minecraft:light_blue_concrete
fill 440 166 489 440 167 490 minecraft:cyan_concrete
fill 441 166 477 441 166 478 minecraft:cyan_concrete
fill 441 166 482 441 166 483 minecraft:soul_soil
fill 441 166 484 441 167 484 minecraft:light_blue_concrete
fill 441 166 485 442 167 485 minecraft:soul_soil
fill 441 166 487 441 167 487 minecraft:light_blue_concrete
fill 441 166 488 441 167 489 minecraft:soul_soil
fill 441 166 490 441 167 491 minecraft:cyan_concrete
setblock 442 166 466 minecraft:light[level=11]
setblock 442 166 474 minecraft:light[level=11]
fill 442 166 477 444 167 477 minecraft:cyan_concrete
fill 442 166 478 443 166 478 minecraft:soul_soil
setblock 442 166 482 minecraft:soul_soil
fill 442 166 483 442 167 483 minecraft:light_blue_concrete
fill 442 166 484 443 166 484 minecraft:soul_soil
fill 442 166 486 442 167 486 minecraft:light_blue_concrete
fill 442 166 487 442 166 488 minecraft:soul_soil
setblock 442 166 489 minecraft:light_blue_concrete
setblock 442 166 490 minecraft:soul_soil
fill 442 166 491 444 166 491 minecraft:cyan_concrete
setblock 442 166 498 minecraft:light[level=11]
fill 443 166 476 447 168 476 minecraft:cyan_concrete
setblock 443 166 482 minecraft:light_blue_concrete
setblock 443 166 483 minecraft:soul_soil
setblock 443 166 485 minecraft:light_blue_concrete
fill 443 166 486 443 166 487 minecraft:soul_soil
fill 443 166 492 447 168 492 minecraft:cyan_concrete
setblock 444 166 478 minecraft:light_blue_concrete
fill 444 166 479 444 166 480 minecraft:soul_soil
setblock 444 166 481 minecraft:light_blue_concrete
fill 444 166 482 445 166 482 minecraft:soul_soil
setblock 444 166 486 minecraft:soul_soil
setblock 444 166 487 minecraft:light_blue_concrete
fill 445 166 477 445 167 477 minecraft:light_blue_concrete
fill 445 166 478 445 167 479 minecraft:soul_soil
fill 445 166 480 445 167 480 minecraft:light_blue_concrete
fill 445 166 481 446 166 481 minecraft:soul_soil
setblock 445 166 486 minecraft:light_blue_concrete
fill 445 166 487 446 166 487 minecraft:soul_soil
setblock 445 166 491 minecraft:soul_soil
fill 446 166 477 449 167 477 minecraft:cyan_concrete
setblock 446 166 478 minecraft:soul_soil
setblock 446 166 479 minecraft:light_blue_concrete
setblock 446 166 480 minecraft:soul_soil
setblock 446 166 482 minecraft:light_blue_concrete
fill 446 166 486 447 166 486 minecraft:soul_soil
setblock 446 166 488 minecraft:light_blue_concrete
fill 446 166 489 446 166 490 minecraft:soul_soil
fill 446 166 491 449 166 491 minecraft:cyan_concrete
setblock 447 166 478 minecraft:light_blue_concrete
fill 447 166 482 447 166 483 minecraft:soul_soil
setblock 447 166 484 minecraft:light_blue_concrete
fill 447 166 485 448 166 485 minecraft:soul_soil
fill 447 166 487 447 167 487 minecraft:light_blue_concrete
fill 447 166 488 447 167 489 minecraft:soul_soil
fill 447 166 490 447 167 490 minecraft:light_blue_concrete
setblock 448 166 478 minecraft:soul_soil
setblock 448 166 482 minecraft:soul_soil
fill 448 166 483 448 167 483 minecraft:light_blue_concrete
fill 448 166 484 449 167 484 minecraft:soul_soil
fill 448 166 486 448 167 486 minecraft:light_blue_concrete
fill 448 166 487 448 167 488 minecraft:soul_soil
fill 448 166 489 448 167 489 minecraft:light_blue_concrete
fill 448 166 490 448 167 490 minecraft:soul_soil
fill 449 166 478 450 166 478 minecraft:cyan_concrete
setblock 449 166 482 minecraft:light_blue_concrete
fill 449 166 483 450 167 483 minecraft:soul_soil
fill 449 166 485 449 167 485 minecraft:light_blue_concrete
fill 449 166 486 449 167 487 minecraft:soul_soil
fill 449 166 488 449 167 488 minecraft:light_blue_concrete
fill 449 166 489 449 167 489 minecraft:soul_soil
fill 449 166 490 450 167 490 minecraft:cyan_concrete
setblock 450 166 466 minecraft:light[level=11]
setblock 450 166 474 minecraft:light[level=11]
fill 450 166 479 451 166 479 minecraft:cyan_concrete
setblock 450 166 480 minecraft:soul_soil
setblock 450 166 481 minecraft:light_blue_concrete
fill 450 166 482 451 166 482 minecraft:soul_soil
fill 450 166 484 450 167 484 minecraft:light_blue_concrete
fill 450 166 485 450 167 486 minecraft:soul_soil
fill 450 166 487 450 167 487 minecraft:light_blue_concrete
fill 450 166 488 450 167 488 minecraft:soul_soil
fill 450 166 489 451 167 489 minecraft:cyan_concrete
setblock 450 166 498 minecraft:light[level=11]
fill 451 166 480 452 167 480 minecraft:cyan_concrete
fill 451 166 481 451 167 481 minecraft:soul_soil
fill 451 166 483 451 167 483 minecraft:light_blue_concrete
fill 451 166 484 451 167 485 minecraft:soul_soil
fill 451 166 486 451 167 486 minecraft:light_blue_concrete
fill 451 166 487 451 167 487 minecraft:soul_soil
fill 451 166 488 452 167 488 minecraft:cyan_concrete
fill 452 166 481 452 167 483 minecraft:cyan_concrete
fill 452 166 484 452 167 484 minecraft:soul_soil
fill 452 166 485 452 167 487 minecraft:cyan_concrete
fill 453 166 482 453 167 486 minecraft:cyan_concrete
setblock 458 166 466 minecraft:light[level=11]
setblock 458 166 474 minecraft:light[level=11]
setblock 458 166 482 minecraft:light[level=11]
setblock 458 166 490 minecraft:light[level=11]
setblock 458 166 498 minecraft:light[level=11]
fill 424 167 464 436 167 504 minecraft:basalt
fill 437 167 464 437 167 480 minecraft:basalt
setblock 437 167 481 minecraft:cyan_concrete
setblock 437 167 487 minecraft:cyan_concrete
fill 437 167 488 437 167 504 minecraft:basalt
fill 438 167 464 438 167 479 minecraft:basalt
fill 438 167 489 438 167 504 minecraft:basalt
fill 439 167 464 440 167 477 minecraft:basalt
setblock 439 167 478 minecraft:cyan_concrete
setblock 439 167 490 minecraft:cyan_concrete
fill 439 167 491 440 167 504 minecraft:basalt
fill 440 167 478 440 167 482 minecraft:sea_lantern
fill 441 167 464 441 167 476 minecraft:basalt
setblock 441 167 477 minecraft:cyan_concrete
fill 441 167 478 444 167 478 minecraft:sea_lantern
fill 441 167 479 443 167 481 minecraft:basalt
fill 441 167 482 443 167 482 minecraft:sea_lantern
setblock 441 167 483 minecraft:soul_soil
fill 441 167 492 441 167 504 minecraft:basalt
fill 442 167 464 464 167 475 minecraft:basalt
setblock 442 167 476 minecraft:cyan_concrete
setblock 442 167 484 minecraft:soul_soil
fill 442 167 487 442 167 491 minecraft:sea_lantern
setblock 442 167 492 minecraft:cyan_concrete
fill 442 167 493 464 167 504 minecraft:basalt
fill 443 167 483 443 167 485 minecraft:pearlescent_froglight
fill 443 167 486 443 167 487 minecraft:sea_lantern
fill 443 167 488 445 167 490 minecraft:basalt
fill 443 167 491 446 167 491 minecraft:sea_lantern
fill 444 167 479 444 167 481 minecraft:sea_lantern
fill 444 167 482 446 167 482 minecraft:pearlescent_froglight
fill 444 167 486 446 167 486 minecraft:pearlescent_froglight
fill 444 167 487 446 167 487 minecraft:sea_lantern
setblock 445 167 481 minecraft:soul_soil
fill 446 167 478 446 167 481 minecraft:sea_lantern
fill 446 167 488 446 167 490 minecraft:sea_lantern
fill 447 167 478 450 167 478 minecraft:sea_lantern
fill 447 167 479 449 167 481 minecraft:basalt
fill 447 167 482 450 167 482 minecraft:sea_lantern
fill 447 167 483 447 167 485 minecraft:pearlescent_froglight
setblock 447 167 486 minecraft:sea_lantern
fill 447 167 491 449 167 491 minecraft:cyan_concrete
setblock 448 167 476 minecraft:cyan_concrete
setblock 448 167 485 minecraft:soul_soil
setblock 448 167 492 minecraft:cyan_concrete
fill 449 167 476 464 167 476 minecraft:basalt
fill 449 167 492 464 167 492 minecraft:basalt
fill 450 167 477 464 167 477 minecraft:basalt
fill 450 167 479 450 167 481 minecraft:sea_lantern
fill 450 167 491 464 167 491 minecraft:basalt
fill 451 167 478 451 167 479 minecraft:cyan_concrete
setblock 451 167 482 minecraft:soul_soil
setblock 451 167 490 minecraft:cyan_concrete
fill 452 167 478 464 167 479 minecraft:basalt
fill 452 167 489 464 167 490 minecraft:basalt
fill 453 167 480 464 167 480 minecraft:basalt
setblock 453 167 481 minecraft:cyan_concrete
setblock 453 167 487 minecraft:cyan_concrete
fill 453 167 488 464 167 488 minecraft:basalt
fill 454 167 481 464 167 487 minecraft:basalt
fill 433 168 484 433 169 485 minecraft:cobblestone
fill 435 168 477 435 169 478 minecraft:cobblestone
fill 435 168 492 435 169 493 minecraft:cobblestone
fill 436 168 477 441 168 491 minecraft:dark_oak_planks
fill 442 168 473 442 169 474 minecraft:cobblestone
fill 442 168 477 454 168 480 minecraft:dark_oak_planks
fill 442 168 489 454 168 491 minecraft:dark_oak_planks
fill 442 168 496 442 169 497 minecraft:cobblestone
fill 449 168 473 449 169 474 minecraft:cobblestone
fill 449 168 496 449 169 497 minecraft:cobblestone
fill 450 168 481 454 168 488 minecraft:dark_oak_planks
fill 456 168 477 456 169 478 minecraft:cobblestone
fill 456 168 492 456 169 493 minecraft:cobblestone
fill 458 168 484 458 169 485 minecraft:cobblestone
fill 436 169 477 436 169 491 minecraft:dark_oak_planks
fill 437 169 477 454 169 477 minecraft:dark_oak_planks
fill 437 169 491 454 169 491 minecraft:dark_oak_planks
fill 454 169 478 454 169 490 minecraft:dark_oak_planks
fill 436 170 477 436 175 478 minecraft:dark_oak_planks
setblock 436 170 479 minecraft:ochre_froglight
fill 436 170 480 436 175 481 minecraft:dark_oak_planks
setblock 436 170 482 minecraft:ochre_froglight
fill 436 170 483 436 175 484 minecraft:dark_oak_planks
setblock 436 170 485 minecraft:ochre_froglight
fill 436 170 486 436 175 487 minecraft:dark_oak_planks
setblock 436 170 488 minecraft:ochre_froglight
fill 436 170 489 436 175 490 minecraft:dark_oak_planks
setblock 436 170 491 minecraft:ochre_froglight
fill 437 170 477 437 175 477 minecraft:dark_oak_planks
fill 437 170 491 438 175 491 minecraft:dark_oak_planks
setblock 438 170 477 minecraft:ochre_froglight
fill 439 170 477 440 175 477 minecraft:dark_oak_planks
setblock 439 170 491 minecraft:ochre_froglight
fill 440 170 491 441 175 491 minecraft:dark_oak_planks
setblock 441 170 477 minecraft:ochre_froglight
fill 442 170 477 443 175 477 minecraft:dark_oak_planks
setblock 442 170 491 minecraft:ochre_froglight
fill 443 170 491 444 175 491 minecraft:dark_oak_planks
setblock 444 170 477 minecraft:ochre_froglight
fill 445 170 477 446 175 477 minecraft:dark_oak_planks
setblock 445 170 491 minecraft:ochre_froglight
fill 446 170 491 447 175 491 minecraft:dark_oak_planks
setblock 447 170 477 minecraft:ochre_froglight
fill 448 170 477 449 175 477 minecraft:dark_oak_planks
setblock 448 170 491 minecraft:ochre_froglight
fill 449 170 491 450 175 491 minecraft:dark_oak_planks
setblock 450 170 477 minecraft:ochre_froglight
fill 451 170 477 452 175 477 minecraft:dark_oak_planks
setblock 451 170 491 minecraft:ochre_froglight
fill 452 170 491 453 175 491 minecraft:dark_oak_planks
setblock 453 170 477 minecraft:ochre_froglight
fill 454 170 477 454 175 478 minecraft:dark_oak_planks
setblock 454 170 479 minecraft:ochre_froglight
fill 454 170 480 454 175 481 minecraft:dark_oak_planks
setblock 454 170 482 minecraft:ochre_froglight
fill 454 170 483 454 175 484 minecraft:dark_oak_planks
setblock 454 170 485 minecraft:ochre_froglight
fill 454 170 486 454 175 487 minecraft:dark_oak_planks
setblock 454 170 488 minecraft:ochre_froglight
fill 454 170 489 454 175 490 minecraft:dark_oak_planks
setblock 454 170 491 minecraft:ochre_froglight
fill 424 171 472 424 171 474 minecraft:blackstone
fill 424 171 488 424 171 489 minecraft:blackstone
setblock 424 171 490 minecraft:polished_blackstone_bricks
fill 424 171 491 424 171 494 minecraft:blackstone
setblock 424 171 495 minecraft:polished_blackstone_bricks
fill 432 171 464 434 171 464 minecraft:blackstone
setblock 433 171 465 minecraft:blackstone
setblock 434 171 465 minecraft:polished_blackstone_bricks
setblock 435 171 464 minecraft:polished_blackstone_bricks
fill 435 171 465 437 171 465 minecraft:blackstone
fill 436 171 464 439 171 464 minecraft:blackstone
fill 436 171 479 436 173 479 minecraft:dark_oak_planks
fill 436 171 482 436 173 482 minecraft:dark_oak_planks
fill 436 171 485 436 173 485 minecraft:dark_oak_planks
fill 436 171 488 436 173 488 minecraft:dark_oak_planks
fill 436 171 491 436 173 491 minecraft:dark_oak_planks
fill 438 171 477 438 173 477 minecraft:dark_oak_planks
fill 439 171 491 439 173 491 minecraft:dark_oak_planks
setblock 440 171 464 minecraft:polished_blackstone_bricks
fill 441 171 477 441 173 477 minecraft:dark_oak_planks
fill 442 171 491 442 173 491 minecraft:dark_oak_planks
fill 444 171 477 444 173 477 minecraft:dark_oak_planks
fill 444 171 502 445 171 503 minecraft:cyan_stained_glass
fill 445 171 491 445 173 491 minecraft:dark_oak_planks
setblock 446 171 503 minecraft:cyan_stained_glass
fill 447 171 477 447 173 477 minecraft:dark_oak_planks
fill 448 171 491 448 173 491 minecraft:dark_oak_planks
setblock 449 171 464 minecraft:blackstone
setblock 450 171 464 minecraft:polished_blackstone_bricks
fill 450 171 477 450 173 477 minecraft:dark_oak_planks
setblock 450 171 504 minecraft:polished_blackstone_bricks
fill 451 171 464 454 171 464 minecraft:blackstone
fill 451 171 491 451 173 491 minecraft:dark_oak_planks
fill 451 171 504 454 171 504 minecraft:blackstone
fill 452 171 465 453 171 465 minecraft:blackstone
fill 453 171 477 453 173 477 minecraft:dark_oak_planks
fill 453 171 503 455 171 503 minecraft:blackstone
fill 454 171 479 454 173 479 minecraft:dark_oak_planks
fill 454 171 482 454 173 482 minecraft:dark_oak_planks
fill 454 171 485 454 173 485 minecraft:dark_oak_planks
fill 454 171 488 454 173 488 minecraft:dark_oak_planks
fill 454 171 491 454 173 491 minecraft:dark_oak_planks
setblock 455 171 464 minecraft:polished_blackstone_bricks
setblock 455 171 504 minecraft:polished_blackstone_bricks
fill 456 171 464 457 171 464 minecraft:blackstone
fill 456 171 504 458 172 504 minecraft:blackstone
setblock 463 171 491 minecraft:polished_blackstone_bricks
fill 463 171 492 463 171 495 minecraft:blackstone
setblock 464 171 489 minecraft:blackstone
setblock 464 171 490 minecraft:polished_blackstone_bricks
fill 464 171 491 464 171 494 minecraft:blackstone
setblock 464 171 495 minecraft:polished_blackstone_bricks
fill 464 171 496 464 173 497 minecraft:blackstone
fill 424 172 471 424 172 473 minecraft:blackstone
setblock 424 172 474 minecraft:polished_blackstone_bricks
fill 424 172 475 424 174 476 minecraft:blackstone
setblock 424 172 489 minecraft:polished_blackstone_bricks
fill 424 172 490 424 172 493 minecraft:blackstone
setblock 424 172 494 minecraft:polished_blackstone_bricks
fill 424 172 495 424 175 495 minecraft:blackstone
fill 431 172 464 433 172 464 minecraft:blackstone
setblock 433 172 465 minecraft:polished_blackstone_bricks
setblock 434 172 464 minecraft:polished_blackstone_bricks
fill 434 172 465 436 173 465 minecraft:blackstone
fill 435 172 464 438 172 464 minecraft:blackstone
setblock 439 172 464 minecraft:polished_blackstone_bricks
setblock 448 172 464 minecraft:blackstone
setblock 449 172 464 minecraft:polished_blackstone_bricks
setblock 449 172 504 minecraft:polished_blackstone_bricks
fill 450 172 464 453 172 464 minecraft:blackstone
fill 450 172 504 453 172 504 minecraft:blackstone
fill 452 172 503 454 172 503 minecraft:blackstone
setblock 454 172 464 minecraft:polished_blackstone_bricks
setblock 454 172 504 minecraft:polished_blackstone_bricks
fill 455 172 464 456 172 464 minecraft:blackstone
setblock 455 172 503 minecraft:polished_blackstone_bricks
fill 455 172 504 455 175 504 minecraft:blackstone
fill 456 172 503 456 175 503 minecraft:blackstone
fill 463 172 492 463 172 494 minecraft:blackstone
setblock 463 172 495 minecraft:polished_blackstone_bricks
setblock 464 172 489 minecraft:polished_blackstone_bricks
fill 464 172 490 464 172 493 minecraft:blackstone
setblock 464 172 494 minecraft:polished_blackstone_bricks
fill 464 172 495 464 175 495 minecraft:blackstone
setblock 464 172 498 minecraft:blackstone
fill 424 173 471 424 173 472 minecraft:blackstone
setblock 424 173 473 minecraft:polished_blackstone_bricks
fill 424 173 474 425 175 474 minecraft:blackstone
setblock 424 173 477 minecraft:blackstone
setblock 424 173 478 minecraft:polished_blackstone_bricks
fill 424 173 479 424 176 479 minecraft:blackstone
fill 424 173 489 424 173 492 minecraft:blackstone
setblock 424 173 493 minecraft:polished_blackstone_bricks
fill 424 173 494 424 176 494 minecraft:blackstone
fill 424 173 496 424 174 496 minecraft:blackstone
fill 425 173 473 425 176 473 minecraft:blackstone
fill 425 173 475 425 174 475 minecraft:blackstone
fill 431 173 464 432 173 464 minecraft:blackstone
setblock 433 173 464 minecraft:polished_blackstone_bricks
fill 433 173 465 433 176 465 minecraft:blackstone
fill 434 173 464 437 173 464 minecraft:blackstone
setblock 438 173 464 minecraft:polished_blackstone_bricks
fill 439 173 464 439 176 464 minecraft:blackstone
setblock 448 173 464 minecraft:polished_blackstone_bricks
setblock 448 173 504 minecraft:polished_blackstone_bricks
fill 449 173 464 452 173 464 minecraft:blackstone
fill 449 173 504 452 173 504 minecraft:blackstone
fill 450 173 503 453 173 503 minecraft:blackstone
setblock 453 173 464 minecraft:polished_blackstone_bricks
setblock 453 173 504 minecraft:polished_blackstone_bricks
fill 454 173 464 455 175 464 minecraft:blackstone
setblock 454 173 503 minecraft:polished_blackstone_bricks
fill 454 173 504 454 176 504 minecraft:blackstone
fill 455 173 503 455 176 503 minecraft:blackstone
fill 456 173 504 457 173 504 minecraft:blackstone
setblock 458 173 504 minecraft:polished_blackstone_bricks
fill 463 173 492 463 173 493 minecraft:blackstone
setblock 463 173 494 minecraft:polished_blackstone_bricks
fill 463 173 495 463 175 496 minecraft:blackstone
fill 464 173 489 464 173 492 minecraft:blackstone
setblock 464 173 493 minecraft:polished_blackstone_bricks
fill 464 173 494 464 176 494 minecraft:blackstone
setblock 464 173 498 minecraft:polished_blackstone_bricks
fill 464 173 499 464 176 499 minecraft:blackstone
fill 424 174 470 424 174 471 minecraft:blackstone
setblock 424 174 472 minecraft:polished_blackstone_bricks
fill 424 174 473 424 177 473 minecraft:blackstone
setblock 424 174 477 minecraft:polished_blackstone_bricks
fill 424 174 478 425 176 478 minecraft:blackstone
fill 424 174 480 424 174 481 minecraft:blackstone
fill 424 174 489 424 174 491 minecraft:blackstone
setblock 424 174 492 minecraft:polished_blackstone_bricks
fill 424 174 493 424 177 493 minecraft:blackstone
setblock 424 174 497 minecraft:polished_blackstone_bricks
fill 425 174 472 425 177 472 minecraft:blackstone
setblock 425 174 476 minecraft:polished_blackstone_bricks
fill 425 174 477 425 177 477 minecraft:blackstone
setblock 426 174 466 minecraft:light[level=11]
setblock 426 174 474 minecraft:light[level=11]
setblock 426 174 482 minecraft:light[level=11]
setblock 426 174 490 minecraft:light[level=11]
setblock 426 174 498 minecraft:light[level=11]
fill 430 174 464 431 174 464 minecraft:blackstone
setblock 432 174 464 minecraft:polished_blackstone_bricks
fill 432 174 465 432 177 465 minecraft:blackstone
fill 433 174 464 436 174 464 minecraft:blackstone
fill 433 174 504 434 176 504 minecraft:blackstone
fill 434 174 465 435 174 465 minecraft:blackstone
setblock 434 174 466 minecraft:light[level=11]
setblock 434 174 474 minecraft:light[level=11]
setblock 434 174 482 minecraft:light[level=11]
setblock 434 174 490 minecraft:light[level=11]
setblock 434 174 498 minecraft:light[level=11]
setblock 436 174 465 minecraft:polished_blackstone_bricks
setblock 436 174 479 minecraft:ochre_froglight
setblock 436 174 482 minecraft:ochre_froglight
setblock 436 174 485 minecraft:ochre_froglight
setblock 436 174 488 minecraft:ochre_froglight
setblock 436 174 491 minecraft:ochre_froglight
setblock 437 174 464 minecraft:polished_blackstone_bricks
fill 438 174 464 438 177 464 minecraft:blackstone
setblock 438 174 477 minecraft:ochre_froglight
setblock 439 174 491 minecraft:ochre_froglight
setblock 441 174 477 minecraft:ochre_froglight
setblock 442 174 466 minecraft:light[level=11]
setblock 442 174 474 minecraft:light[level=11]
setblock 442 174 490 minecraft:light[level=11]
setblock 442 174 491 minecraft:ochre_froglight
setblock 442 174 498 minecraft:light[level=11]
setblock 444 174 477 minecraft:ochre_froglight
setblock 445 174 491 minecraft:ochre_froglight
setblock 446 174 504 minecraft:blackstone
setblock 447 174 464 minecraft:polished_blackstone_bricks
setblock 447 174 477 minecraft:ochre_froglight
setblock 447 174 504 minecraft:polished_blackstone_bricks
fill 448 174 464 451 174 464 minecraft:blackstone
setblock 448 174 491 minecraft:ochre_froglight
fill 448 174 504 451 174 504 minecraft:blackstone
fill 449 174 503 452 174 503 minecraft:blackstone
setblock 450 174 466 minecraft:light[level=11]
setblock 450 174 474 minecraft:light[level=11]
setblock 450 174 477 minecraft:ochre_froglight
setblock 450 174 482 minecraft:light[level=11]
setblock 450 174 490 minecraft:light[level=11]
setblock 450 174 498 minecraft:light[level=11]
setblock 451 174 491 minecraft:ochre_froglight
fill 451 174 502 453 174 502 minecraft:blackstone
setblock 452 174 464 minecraft:polished_blackstone_bricks
setblock 452 174 504 minecraft:polished_blackstone_bricks
fill 453 174 464 453 177 464 minecraft:blackstone
setblock 453 174 477 minecraft:ochre_froglight
setblock 453 174 503 minecraft:polished_blackstone_bricks
fill 453 174 504 453 177 504 minecraft:blackstone
setblock 454 174 479 minecraft:ochre_froglight
setblock 454 174 482 minecraft:ochre_froglight
setblock 454 174 485 minecraft:ochre_froglight
setblock 454 174 488 minecraft:ochre_froglight
setblock 454 174 491 minecraft:ochre_froglight
setblock 454 174 502 minecraft:polished_blackstone_bricks
fill 454 174 503 454 177 503 minecraft:blackstone
setblock 456 174 504 minecraft:blackstone
setblock 457 174 504 minecraft:polished_blackstone_bricks
setblock 458 174 466 minecraft:light[level=11]
setblock 458 174 474 minecraft:light[level=11]
setblock 458 174 482 minecraft:light[level=11]
setblock 458 174 490 minecraft:light[level=11]
setblock 458 174 498 minecraft:light[level=11]
fill 458 174 504 458 177 504 minecraft:blackstone
setblock 463 174 492 minecraft:blackstone
setblock 463 174 493 minecraft:polished_blackstone_bricks
fill 463 174 494 463 177 494 minecraft:blackstone
setblock 463 174 497 minecraft:blackstone
fill 464 174 474 464 174 476 minecraft:blackstone
fill 464 174 488 464 174 491 minecraft:blackstone
setblock 464 174 492 minecraft:polished_blackstone_bricks
fill 464 174 493 464 177 493 minecraft:blackstone
setblock 464 174 496 minecraft:blackstone
setblock 464 174 497 minecraft:polished_blackstone_bricks
fill 464 174 498 464 177 498 minecraft:blackstone
fill 464 174 500 464 175 500 minecraft:blackstone
setblock 424 175 470 minecraft:blackstone
setblock 424 175 471 minecraft:polished_blackstone_bricks
fill 424 175 472 424 178 472 minecraft:blackstone
setblock 424 175 475 minecraft:blackstone
setblock 424 175 476 minecraft:polished_blackstone_bricks
fill 424 175 477 424 178 477 minecraft:blackstone
setblock 424 175 480 minecraft:blackstone
setblock 424 175 481 minecraft:polished_blackstone_bricks
fill 424 175 482 424 177 483 minecraft:blackstone
fill 424 175 489 424 175 490 minecraft:blackstone
setblock 424 175 491 minecraft:polished_blackstone_bricks
fill 424 175 492 424 178 492 minecraft:blackstone
setblock 424 175 496 minecraft:polished_blackstone_bricks
fill 424 175 497 424 177 498 minecraft:blackstone
fill 425 175 471 425 178 471 minecraft:blackstone
setblock 425 175 475 minecraft:polished_blackstone_bricks
fill 425 175 476 426 177 476 minecraft:blackstone
setblock 425 175 479 minecraft:blackstone
setblock 425 175 480 minecraft:polished_blackstone_bricks
fill 426 175 472 426 175 473 minecraft:blackstone
setblock 426 175 474 minecraft:polished_blackstone_bricks
fill 426 175 475 426 178 475 minecraft:blackstone
fill 426 175 477 426 175 478 minecraft:blackstone
fill 429 175 464 430 175 464 minecraft:blackstone
setblock 430 175 504 minecraft:blackstone
setblock 431 175 464 minecraft:polished_blackstone_bricks
fill 431 175 465 431 178 465 minecraft:blackstone
setblock 431 175 504 minecraft:polished_blackstone_bricks
fill 432 175 464 435 175 464 minecraft:blackstone
fill 432 175 504 432 178 504 minecraft:blackstone
setblock 434 175 465 minecraft:blackstone
setblock 435 175 465 minecraft:polished_blackstone_bricks
setblock 435 175 504 minecraft:blackstone
setblock 436 175 464 minecraft:polished_blackstone_bricks
fill 436 175 465 436 176 465 minecraft:blackstone
fill 436 175 479 454 175 479 minecraft:dark_oak_planks
fill 436 175 482 441 175 482 minecraft:dark_oak_planks
fill 436 175 485 441 175 485 minecraft:dark_oak_planks
fill 436 175 488 441 175 488 minecraft:dark_oak_planks
setblock 436 175 491 minecraft:dark_oak_planks
setblock 436 175 504 minecraft:polished_blackstone_bricks
fill 437 175 464 437 178 464 minecraft:blackstone
fill 437 175 478 453 175 478 minecraft:dark_oak_planks
fill 437 175 480 441 175 481 minecraft:dark_oak_planks
fill 437 175 483 441 175 484 minecraft:dark_oak_planks
fill 437 175 486 441 175 487 minecraft:dark_oak_planks
fill 437 175 489 453 175 490 minecraft:dark_oak_planks
setblock 438 175 477 minecraft:dark_oak_planks
setblock 439 175 491 minecraft:dark_oak_planks
setblock 441 175 477 minecraft:dark_oak_planks
fill 442 175 480 453 175 480 minecraft:dark_oak_planks
setblock 442 175 491 minecraft:dark_oak_planks
setblock 444 175 477 minecraft:dark_oak_planks
setblock 445 175 464 minecraft:blackstone
setblock 445 175 491 minecraft:dark_oak_planks
setblock 445 175 504 minecraft:blackstone
setblock 446 175 464 minecraft:polished_blackstone_bricks
setblock 446 175 504 minecraft:polished_blackstone_bricks
fill 447 175 464 450 175 464 minecraft:blackstone
setblock 447 175 477 minecraft:dark_oak_planks
setblock 447 175 503 minecraft:polished_blackstone_bricks
fill 447 175 504 450 175 504 minecraft:blackstone
setblock 448 175 491 minecraft:dark_oak_planks
fill 448 175 503 451 175 503 minecraft:blackstone
fill 449 175 502 452 175 502 minecraft:blackstone
setblock 450 175 477 minecraft:dark_oak_planks
fill 450 175 481 453 175 488 minecraft:dark_oak_planks
setblock 451 175 464 minecraft:polished_blackstone_bricks
fill 451 175 465 451 178 465 minecraft:blackstone
setblock 451 175 491 minecraft:dark_oak_planks
fill 451 175 501 453 175 501 minecraft:blackstone
setblock 451 175 504 minecraft:polished_blackstone_bricks
fill 452 175 464 452 178 464 minecraft:blackstone
setblock 452 175 503 minecraft:polished_blackstone_bricks
fill 452 175 504 452 178 504 minecraft:blackstone
setblock 453 175 477 minecraft:dark_oak_planks
setblock 453 175 502 minecraft:polished_blackstone_bricks
fill 453 175 503 453 178 503 minecraft:blackstone
setblock 454 175 482 minecraft:dark_oak_planks
setblock 454 175 485 minecraft:dark_oak_planks
setblock 454 175 488 minecraft:dark_oak_planks
setblock 454 175 491 minecraft:dark_oak_planks
fill 454 175 502 455 177 502 minecraft:blackstone
setblock 456 175 504 minecraft:polished_blackstone_bricks
setblock 457 175 503 minecraft:polished_blackstone_bricks
fill 457 175 504 457 178 504 minecraft:blackstone
fill 458 175 499 461 224 500 minecraft:polished_blackstone_bricks
fill 459 175 498 460 224 498 minecraft:polished_blackstone_bricks
fill 459 175 501 460 224 501 minecraft:polished_blackstone_bricks
setblock 463 175 492 minecraft:polished_blackstone_bricks
fill 463 175 493 463 178 493 minecraft:blackstone
setblock 463 175 497 minecraft:polished_blackstone_bricks
fill 463 175 498 463 178 498 minecraft:blackstone
fill 464 175 473 464 175 475 minecraft:blackstone
setblock 464 175 476 minecraft:polished_blackstone_bricks
fill 464 175 477 464 175 480 minecraft:blackstone
fill 464 175 488 464 175 490 minecraft:blackstone
setblock 464 175 491 minecraft:polished_blackstone_bricks
fill 464 175 492 464 178 492 minecraft:blackstone
setblock 464 175 496 minecraft:polished_blackstone_bricks
fill 464 175 497 464 178 497 minecraft:blackstone
setblock 464 175 501 minecraft:polished_blackstone_bricks
setblock 424 176 469 minecraft:blackstone
setblock 424 176 470 minecraft:polished_blackstone_bricks
fill 424 176 471 424 179 471 minecraft:blackstone
setblock 424 176 474 minecraft:blackstone
setblock 424 176 475 minecraft:polished_blackstone_bricks
fill 424 176 476 424 179 476 minecraft:blackstone
setblock 424 176 480 minecraft:polished_blackstone_bricks
fill 424 176 481 425 178 481 minecraft:blackstone
setblock 424 176 484 minecraft:blackstone
setblock 424 176 485 minecraft:polished_blackstone_bricks
fill 424 176 486 424 179 486 minecraft:blackstone
fill 424 176 488 424 176 489 minecraft:blackstone
setblock 424 176 490 minecraft:polished_blackstone_bricks
fill 424 176 491 424 179 491 minecraft:blackstone
setblock 424 176 495 minecraft:polished_blackstone_bricks
fill 424 176 496 425 178 496 minecraft:blackstone
setblock 424 176 499 minecraft:blackstone
setblock 424 176 500 minecraft:polished_blackstone_bricks
fill 425 176 470 425 179 470 minecraft:blackstone
setblock 425 176 474 minecraft:polished_blackstone_bricks
fill 425 176 475 425 179 475 minecraft:blackstone
setblock 425 176 479 minecraft:polished_blackstone_bricks
fill 425 176 480 426 178 480 minecraft:blackstone
fill 425 176 482 425 177 482 minecraft:blackstone
setblock 425 176 494 minecraft:polished_blackstone_bricks
fill 425 176 495 425 178 495 minecraft:blackstone
setblock 426 176 472 minecraft:blackstone
setblock 426 176 473 minecraft:polished_blackstone_bricks
fill 426 176 474 427 178 474 minecraft:blackstone
setblock 426 176 477 minecraft:blackstone
setblock 426 176 478 minecraft:polished_blackstone_bricks
fill 426 176 479 426 179 479 minecraft:blackstone
fill 427 176 473 427 179 473 minecraft:blackstone
fill 427 176 475 427 176 476 minecraft:blackstone
setblock 427 176 477 minecraft:polished_blackstone_bricks
fill 427 176 478 427 179 478 minecraft:blackstone
fill 428 176 464 429 176 464 minecraft:blackstone
setblock 429 176 504 minecraft:blackstone
setblock 430 176 464 minecraft:polished_blackstone_bricks
fill 430 176 465 430 179 465 minecraft:blackstone
setblock 430 176 504 minecraft:polished_blackstone_bricks
fill 431 176 464 434 176 464 minecraft:blackstone
fill 431 176 504 431 179 504 minecraft:blackstone
fill 432 176 503 433 178 503 minecraft:blackstone
setblock 434 176 465 minecraft:polished_blackstone_bricks
setblock 435 176 464 minecraft:polished_blackstone_bricks
fill 435 176 465 435 179 465 minecraft:blackstone
setblock 435 176 504 minecraft:polished_blackstone_bricks
fill 436 176 464 436 179 464 minecraft:blackstone
fill 436 176 477 441 176 491 minecraft:deepslate_tiles
fill 436 176 504 438 177 504 minecraft:blackstone
fill 441 176 492 442 177 492 minecraft:light_blue_stained_glass
fill 442 176 477 454 176 480 minecraft:deepslate_tiles
fill 442 176 489 454 176 491 minecraft:deepslate_tiles
fill 442 176 504 444 176 504 minecraft:blackstone
setblock 444 176 464 minecraft:blackstone
setblock 445 176 464 minecraft:polished_blackstone_bricks
setblock 445 176 503 minecraft:blackstone
setblock 445 176 504 minecraft:polished_blackstone_bricks
fill 446 176 464 449 176 464 minecraft:blackstone
setblock 446 176 503 minecraft:polished_blackstone_bricks
fill 446 176 504 449 176 504 minecraft:blackstone
setblock 447 176 502 minecraft:polished_blackstone_bricks
fill 447 176 503 450 176 503 minecraft:blackstone
fill 448 176 502 451 176 502 minecraft:blackstone
setblock 449 176 465 minecraft:polished_blackstone_bricks
fill 449 176 501 452 176 501 minecraft:blackstone
setblock 450 176 464 minecraft:polished_blackstone_bricks
fill 450 176 465 450 179 465 minecraft:blackstone
fill 450 176 481 454 176 488 minecraft:deepslate_tiles
setblock 450 176 504 minecraft:polished_blackstone_bricks
fill 451 176 464 451 179 464 minecraft:blackstone
setblock 451 176 503 minecraft:polished_blackstone_bricks
fill 451 176 504 451 179 504 minecraft:blackstone
setblock 452 176 502 minecraft:polished_blackstone_bricks
fill 452 176 503 452 179 503 minecraft:blackstone
setblock 453 176 501 minecraft:polished_blackstone_bricks
fill 453 176 502 453 179 502 minecraft:blackstone
setblock 454 176 464 minecraft:blackstone
fill 454 176 501 454 179 501 minecraft:blackstone
setblock 455 176 464 minecraft:polished_blackstone_bricks
setblock 455 176 504 minecraft:polished_blackstone_bricks
setblock 456 176 502 minecraft:blackstone
setblock 456 176 503 minecraft:polished_blackstone_bricks
fill 456 176 504 456 179 504 minecraft:blackstone
fill 457 176 499 457 177 500 minecraft:blackstone
fill 457 176 503 457 179 503 minecraft:blackstone
fill 458 176 498 458 177 498 minecraft:blackstone
fill 458 176 501 458 177 501 minecraft:blackstone
fill 459 176 497 460 177 497 minecraft:blackstone
fill 459 176 502 460 177 502 minecraft:blackstone
fill 461 176 498 461 177 498 minecraft:blackstone
fill 461 176 501 461 177 501 minecraft:blackstone
fill 462 176 499 462 177 500 minecraft:blackstone
fill 463 176 492 463 178 492 minecraft:blackstone
setblock 463 176 495 minecraft:blackstone
setblock 463 176 496 minecraft:polished_blackstone_bricks
fill 463 176 497 463 179 497 minecraft:blackstone
fill 463 176 499 463 177 499 minecraft:blackstone
fill 464 176 472 464 176 474 minecraft:blackstone
setblock 464 176 475 minecraft:polished_blackstone_bricks
fill 464 176 476 464 176 479 minecraft:blackstone
setblock 464 176 480 minecraft:polished_blackstone_bricks
fill 464 176 481 464 176 484 minecraft:blackstone
setblock 464 176 485 minecraft:polished_blackstone_bricks
fill 464 176 486 464 176 489 minecraft:blackstone
setblock 464 176 490 minecraft:polished_blackstone_bricks
fill 464 176 491 464 179 491 minecraft:blackstone
setblock 464 176 495 minecraft:polished_blackstone_bricks
fill 464 176 496 464 179 496 minecraft:blackstone
setblock 464 176 500 minecraft:polished_blackstone_bricks
fill 464 176 501 464 178 502 minecraft:blackstone
setblock 424 177 469 minecraft:polished_blackstone_bricks
fill 424 177 470 424 180 470 minecraft:blackstone
setblock 424 177 474 minecraft:polished_blackstone_bricks
fill 424 177 475 424 180 475 minecraft:blackstone
setblock 424 177 478 minecraft:blackstone
setblock 424 177 479 minecraft:polished_blackstone_bricks
fill 424 177 480 424 180 480 minecraft:blackstone
setblock 424 177 484 minecraft:polished_blackstone_bricks
fill 424 177 485 424 180 485 minecraft:blackstone
fill 424 177 487 424 177 488 minecraft:blackstone
setblock 424 177 489 minecraft:polished_blackstone_bricks
fill 424 177 490 424 179 490 minecraft:blackstone
setblock 424 177 494 minecraft:polished_blackstone_bricks
fill 424 177 495 424 180 495 minecraft:blackstone
setblock 424 177 499 minecraft:polished_blackstone_bricks
fill 424 177 500 424 179 501 minecraft:blackstone
setblock 425 177 473 minecraft:polished_blackstone_bricks
fill 425 177 474 425 180 474 minecraft:blackstone
setblock 425 177 478 minecraft:polished_blackstone_bricks
fill 425 177 479 425 180 479 minecraft:blackstone
setblock 425 177 483 minecraft:polished_blackstone_bricks
setblock 425 177 494 minecraft:blackstone
setblock 425 177 497 minecraft:blackstone
setblock 425 177 498 minecraft:polished_blackstone_bricks
setblock 426 177 471 minecraft:blackstone
setblock 426 177 472 minecraft:polished_blackstone_bricks
fill 426 177 473 426 180 473 minecraft:blackstone
setblock 426 177 477 minecraft:polished_blackstone_bricks
fill 426 177 478 426 180 478 minecraft:blackstone
setblock 426 177 481 minecraft:blackstone
fill 427 177 464 428 177 464 minecraft:blackstone
setblock 427 177 475 minecraft:blackstone
setblock 427 177 476 minecraft:polished_blackstone_bricks
fill 427 177 477 427 180 477 minecraft:blackstone
fill 427 177 479 427 178 479 minecraft:blackstone
fill 427 177 504 428 177 504 minecraft:blackstone
fill 428 177 476 428 179 476 minecraft:blackstone
setblock 429 177 464 minecraft:polished_blackstone_bricks
fill 429 177 465 429 180 465 minecraft:blackstone
setblock 429 177 503 minecraft:blackstone
setblock 429 177 504 minecraft:polished_blackstone_bricks
fill 430 177 464 433 177 464 minecraft:blackstone
setblock 430 177 503 minecraft:polished_blackstone_bricks
fill 430 177 504 430 180 504 minecraft:blackstone
fill 431 177 503 431 180 503 minecraft:blackstone
setblock 433 177 465 minecraft:polished_blackstone_bricks
setblock 433 177 504 minecraft:blackstone
setblock 434 177 464 minecraft:polished_blackstone_bricks
fill 434 177 465 434 180 465 minecraft:blackstone
setblock 434 177 503 minecraft:blackstone
setblock 434 177 504 minecraft:polished_blackstone_bricks
fill 435 177 464 435 180 464 minecraft:blackstone
setblock 435 177 503 minecraft:polished_blackstone_bricks
fill 435 177 504 435 180 504 minecraft:blackstone
fill 437 177 478 441 177 490 minecraft:deepslate_tiles
setblock 439 177 464 minecraft:polished_blackstone_bricks
setblock 439 177 504 minecraft:polished_blackstone_bricks
fill 440 177 464 443 177 464 minecraft:blackstone
fill 440 177 504 443 177 504 minecraft:blackstone
fill 441 177 491 442 177 491 minecraft:light_blue_stained_glass
fill 442 177 478 453 177 480 minecraft:deepslate_tiles
fill 442 177 489 453 177 490 minecraft:deepslate_tiles
setblock 444 177 464 minecraft:polished_blackstone_bricks
setblock 444 177 503 minecraft:blackstone
setblock 444 177 504 minecraft:polished_blackstone_bricks
fill 445 177 464 448 177 464 minecraft:blackstone
setblock 445 177 503 minecraft:polished_blackstone_bricks
fill 445 177 504 448 177 504 minecraft:blackstone
setblock 446 177 502 minecraft:polished_blackstone_bricks
fill 446 177 503 449 177 503 minecraft:blackstone
fill 447 177 502 450 177 502 minecraft:blackstone
setblock 448 177 465 minecraft:polished_blackstone_bricks
fill 448 177 501 451 177 501 minecraft:blackstone
setblock 449 177 464 minecraft:polished_blackstone_bricks
fill 449 177 465 449 180 465 minecraft:blackstone
setblock 449 177 504 minecraft:polished_blackstone_bricks
fill 450 177 464 450 180 464 minecraft:blackstone
fill 450 177 481 453 177 488 minecraft:deepslate_tiles
fill 450 177 500 452 177 500 minecraft:blackstone
setblock 450 177 503 minecraft:polished_blackstone_bricks
fill 450 177 504 450 180 504 minecraft:blackstone
setblock 451 177 502 minecraft:polished_blackstone_bricks
fill 451 177 503 451 180 503 minecraft:blackstone
setblock 452 177 501 minecraft:polished_blackstone_bricks
fill 452 177 502 452 180 502 minecraft:blackstone
fill 453 177 501 453 180 501 minecraft:blackstone
setblock 454 177 464 minecraft:polished_blackstone_bricks
setblock 454 177 504 minecraft:polished_blackstone_bricks
fill 455 177 501 455 178 501 minecraft:blackstone
setblock 455 177 503 minecraft:polished_blackstone_bricks
fill 455 177 504 455 180 504 minecraft:blackstone
fill 456 177 499 456 177 500 minecraft:blackstone
setblock 456 177 502 minecraft:polished_blackstone_bricks
fill 456 177 503 456 180 503 minecraft:blackstone
fill 457 177 497 457 177 498 minecraft:blackstone
fill 457 177 501 457 177 502 minecraft:blackstone
setblock 458 177 497 minecraft:blackstone
setblock 458 177 502 minecraft:blackstone
fill 459 177 496 460 177 496 minecraft:blackstone
fill 459 177 503 460 177 503 minecraft:blackstone
setblock 459 177 504 minecraft:polished_blackstone_bricks
fill 461 177 497 462 177 497 minecraft:blackstone
setblock 461 177 502 minecraft:blackstone
setblock 462 177 498 minecraft:blackstone
setblock 462 177 501 minecraft:blackstone
fill 463 177 476 463 177 479 minecraft:blackstone
setblock 463 177 495 minecraft:polished_blackstone_bricks
fill 463 177 496 463 180 496 minecraft:blackstone
setblock 463 177 500 minecraft:polished_blackstone_bricks
fill 464 177 472 464 177 473 minecraft:blackstone
setblock 464 177 474 minecraft:polished_blackstone_bricks
fill 464 177 475 464 177 478 minecraft:blackstone
setblock 464 177 479 minecraft:polished_blackstone_bricks
fill 464 177 480 464 177 483 minecraft:blackstone
setblock 464 177 484 minecraft:polished_blackstone_bricks
fill 464 177 485 464 177 488 minecraft:blackstone
setblock 464 177 489 minecraft:polished_blackstone_bricks
fill 464 177 490 464 180 490 minecraft:blackstone
setblock 464 177 494 minecraft:polished_blackstone_bricks
fill 464 177 495 464 180 495 minecraft:blackstone
setblock 464 177 499 minecraft:polished_blackstone_bricks
fill 464 177 500 464 180 500 minecraft:blackstone
setblock 424 178 468 minecraft:polished_blackstone_bricks
fill 424 178 469 424 181 469 minecraft:blackstone
setblock 424 178 473 minecraft:polished_blackstone_bricks
fill 424 178 474 424 181 474 minecraft:blackstone
setblock 424 178 478 minecraft:polished_blackstone_bricks
fill 424 178 479 424 181 479 minecraft:blackstone
setblock 424 178 482 minecraft:blackstone
setblock 424 178 483 minecraft:polished_blackstone_bricks
fill 424 178 484 425 180 484 minecraft:blackstone
setblock 424 178 487 minecraft:blackstone
setblock 424 178 488 minecraft:polished_blackstone_bricks
fill 424 178 489 424 179 489 minecraft:blackstone
setblock 424 178 493 minecraft:polished_blackstone_bricks
fill 424 178 494 424 180 494 minecraft:blackstone
setblock 424 178 497 minecraft:blackstone
setblock 424 178 498 minecraft:polished_blackstone_bricks
fill 424 178 499 425 180 499 minecraft:blackstone
setblock 424 178 502 minecraft:blackstone
setblock 425 178 472 minecraft:polished_blackstone_bricks
fill 425 178 473 425 181 473 minecraft:blackstone
setblock 425 178 476 minecraft:blackstone
setblock 425 178 477 minecraft:polished_blackstone_bricks
fill 425 178 478 425 181 478 minecraft:blackstone
setblock 425 178 482 minecraft:polished_blackstone_bricks
fill 425 178 483 425 181 483 minecraft:blackstone
setblock 425 178 497 minecraft:polished_blackstone_bricks
fill 425 178 498 425 181 498 minecraft:blackstone
fill 425 178 500 425 179 500 minecraft:blackstone
fill 426 178 464 427 178 464 minecraft:blackstone
setblock 426 178 471 minecraft:polished_blackstone_bricks
fill 426 178 472 426 181 472 minecraft:blackstone
setblock 426 178 476 minecraft:polished_blackstone_bricks
fill 426 178 477 426 181 477 minecraft:blackstone
setblock 426 178 481 minecraft:polished_blackstone_bricks
fill 426 178 482 426 181 482 minecraft:blackstone
fill 426 178 504 427 178 504 minecraft:blackstone
setblock 427 178 475 minecraft:polished_blackstone_bricks
fill 427 178 476 427 181 476 minecraft:blackstone
setblock 427 178 480 minecraft:polished_blackstone_bricks
setblock 428 178 464 minecraft:polished_blackstone_bricks
fill 428 178 465 428 181 465 minecraft:blackstone
fill 428 178 475 428 179 475 minecraft:blackstone
fill 428 178 477 428 178 478 minecraft:blackstone
setblock 428 178 503 minecraft:blackstone
setblock 428 178 504 minecraft:polished_blackstone_bricks
fill 429 178 464 432 178 464 minecraft:blackstone
setblock 429 178 503 minecraft:polished_blackstone_bricks
fill 429 178 504 429 181 504 minecraft:blackstone
fill 430 178 503 430 181 503 minecraft:blackstone
setblock 432 178 465 minecraft:polished_blackstone_bricks
setblock 433 178 464 minecraft:polished_blackstone_bricks
fill 433 178 465 433 181 465 minecraft:blackstone
setblock 433 178 504 minecraft:polished_blackstone_bricks
fill 434 178 464 434 181 464 minecraft:blackstone
setblock 434 178 503 minecraft:polished_blackstone_bricks
fill 434 178 504 434 181 504 minecraft:blackstone
fill 435 178 503 436 180 503 minecraft:blackstone
fill 436 178 504 437 178 504 minecraft:blackstone
setblock 438 178 464 minecraft:polished_blackstone_bricks
fill 438 178 479 441 178 489 minecraft:deepslate_tiles
setblock 438 178 504 minecraft:polished_blackstone_bricks
fill 439 178 464 442 178 464 minecraft:blackstone
fill 439 178 504 442 178 504 minecraft:blackstone
fill 440 178 495 440 179 496 minecraft:cyan_stained_glass
fill 442 178 479 452 178 480 minecraft:deepslate_tiles
fill 442 178 489 452 178 489 minecraft:deepslate_tiles
fill 442 178 503 443 178 503 minecraft:blackstone
setblock 443 178 464 minecraft:polished_blackstone_bricks
setblock 443 178 504 minecraft:polished_blackstone_bricks
fill 444 178 464 447 178 464 minecraft:blackstone
setblock 444 178 503 minecraft:polished_blackstone_bricks
fill 444 178 504 447 178 504 minecraft:blackstone
setblock 445 178 502 minecraft:polished_blackstone_bricks
fill 445 178 503 448 178 503 minecraft:blackstone
setblock 446 178 501 minecraft:polished_blackstone_bricks
fill 446 178 502 449 178 502 minecraft:blackstone
setblock 447 178 465 minecraft:polished_blackstone_bricks
fill 447 178 501 450 178 501 minecraft:blackstone
setblock 448 178 464 minecraft:polished_blackstone_bricks
fill 448 178 465 448 181 465 minecraft:blackstone
setblock 448 178 504 minecraft:polished_blackstone_bricks
fill 449 178 464 449 181 464 minecraft:blackstone
fill 449 178 500 451 178 500 minecraft:blackstone
setblock 449 178 503 minecraft:polished_blackstone_bricks
fill 449 178 504 449 181 504 minecraft:blackstone
fill 450 178 481 452 178 488 minecraft:deepslate_tiles
setblock 450 178 502 minecraft:polished_blackstone_bricks
fill 450 178 503 450 181 503 minecraft:blackstone
setblock 451 178 501 minecraft:polished_blackstone_bricks
fill 451 178 502 451 181 502 minecraft:blackstone
setblock 452 178 500 minecraft:polished_blackstone_bricks
fill 452 178 501 452 181 501 minecraft:blackstone
setblock 453 178 464 minecraft:polished_blackstone_bricks
setblock 453 178 504 minecraft:polished_blackstone_bricks
fill 454 178 464 454 179 464 minecraft:blackstone
setblock 454 178 502 minecraft:blackstone
setblock 454 178 503 minecraft:polished_blackstone_bricks
fill 454 178 504 454 181 504 minecraft:blackstone
setblock 455 178 502 minecraft:polished_blackstone_bricks
fill 455 178 503 455 181 503 minecraft:blackstone
fill 456 178 502 456 179 502 minecraft:blackstone
setblock 458 178 504 minecraft:polished_blackstone_bricks
fill 459 178 504 459 180 504 minecraft:blackstone
fill 463 178 475 463 178 478 minecraft:blackstone
setblock 463 178 479 minecraft:polished_blackstone_bricks
fill 463 178 480 464 178 482 minecraft:blackstone
setblock 463 178 494 minecraft:polished_blackstone_bricks
fill 463 178 495 463 180 495 minecraft:blackstone
setblock 463 178 499 minecraft:polished_blackstone_bricks
fill 463 178 500 463 180 501 minecraft:blackstone
setblock 464 178 472 minecraft:blackstone
setblock 464 178 473 minecraft:polished_blackstone_bricks
fill 464 178 474 464 178 477 minecraft:blackstone
setblock 464 178 478 minecraft:polished_blackstone_bricks
fill 464 178 479 464 181 479 minecraft:blackstone
setblock 464 178 483 minecraft:polished_blackstone_bricks
fill 464 178 484 464 178 487 minecraft:blackstone
setblock 464 178 488 minecraft:polished_blackstone_bricks
fill 464 178 489 464 181 489 minecraft:blackstone
setblock 464 178 493 minecraft:polished_blackstone_bricks
fill 464 178 494 464 181 494 minecraft:blackstone
setblock 464 178 498 minecraft:polished_blackstone_bricks
fill 464 178 499 464 181 499 minecraft:blackstone
setblock 464 178 503 minecraft:polished_blackstone_bricks
fill 424 179 468 424 182 468 minecraft:blackstone
setblock 424 179 472 minecraft:polished_blackstone_bricks
fill 424 179 473 424 182 473 minecraft:blackstone
setblock 424 179 477 minecraft:polished_blackstone_bricks
fill 424 179 478 424 182 478 minecraft:blackstone
setblock 424 179 481 minecraft:blackstone
setblock 424 179 482 minecraft:polished_blackstone_bricks
fill 424 179 483 424 182 483 minecraft:blackstone
setblock 424 179 487 minecraft:polished_blackstone_bricks
fill 424 179 488 424 182 488 minecraft:blackstone
setblock 424 179 492 minecraft:polished_blackstone_bricks
fill 424 179 493 424 180 493 minecraft:blackstone
setblock 424 179 496 minecraft:blackstone
setblock 424 179 497 minecraft:polished_blackstone_bricks
fill 424 179 498 424 182 498 minecraft:blackstone
setblock 424 179 502 minecraft:polished_blackstone_bricks
fill 424 179 503 424 182 503 minecraft:blackstone
fill 425 179 464 426 179 464 minecraft:blackstone
setblock 425 179 471 minecraft:polished_blackstone_bricks
fill 425 179 472 425 182 472 minecraft:blackstone
setblock 425 179 476 minecraft:polished_blackstone_bricks
fill 425 179 477 425 182 477 minecraft:blackstone
setblock 425 179 480 minecraft:blackstone
setblock 425 179 481 minecraft:polished_blackstone_bricks
fill 425 179 482 425 182 482 minecraft:blackstone
setblock 425 179 485 minecraft:blackstone
setblock 425 179 496 minecraft:polished_blackstone_bricks
fill 425 179 497 425 180 497 minecraft:blackstone
setblock 425 179 501 minecraft:polished_blackstone_bricks
fill 425 179 504 426 179 504 minecraft:blackstone
setblock 426 179 471 minecraft:blackstone
setblock 426 179 474 minecraft:blackstone
setblock 426 179 475 minecraft:polished_blackstone_bricks
fill 426 179 476 426 182 476 minecraft:blackstone
setblock 426 179 480 minecraft:polished_blackstone_bricks
fill 426 179 481 427 181 481 minecraft:blackstone
fill 426 179 483 426 180 483 minecraft:blackstone
setblock 427 179 464 minecraft:polished_blackstone_bricks
fill 427 179 465 427 182 465 minecraft:blackstone
setblock 427 179 474 minecraft:polished_blackstone_bricks
fill 427 179 475 427 181 475 minecraft:blackstone
setblock 427 179 479 minecraft:polished_blackstone_bricks
fill 427 179 480 427 182 480 minecraft:blackstone
setblock 427 179 503 minecraft:blackstone
setblock 427 179 504 minecraft:polished_blackstone_bricks
fill 428 179 464 431 179 464 minecraft:blackstone
setblock 428 179 477 minecraft:blackstone
setblock 428 179 478 minecraft:polished_blackstone_bricks
setblock 428 179 503 minecraft:polished_blackstone_bricks
fill 428 179 504 428 182 504 minecraft:blackstone
fill 429 179 503 429 182 503 minecraft:blackstone
fill 430 179 502 431 180 502 minecraft:blackstone
setblock 431 179 465 minecraft:polished_blackstone_bricks
setblock 432 179 464 minecraft:polished_blackstone_bricks
fill 432 179 465 432 182 465 minecraft:blackstone
setblock 432 179 503 minecraft:blackstone
setblock 432 179 504 minecraft:polished_blackstone_bricks
fill 433 179 464 433 182 464 minecraft:blackstone
setblock 433 179 503 minecraft:polished_blackstone_bricks
fill 433 179 504 433 182 504 minecraft:blackstone
fill 434 179 503 434 182 503 minecraft:blackstone
setblock 436 179 504 minecraft:blackstone
setblock 437 179 464 minecraft:polished_blackstone_bricks
setblock 437 179 504 minecraft:polished_blackstone_bricks
fill 438 179 464 441 179 464 minecraft:blackstone
fill 438 179 504 441 179 504 minecraft:blackstone
fill 439 179 480 441 179 488 minecraft:deepslate_tiles
fill 441 179 503 442 179 503 minecraft:blackstone
setblock 442 179 464 minecraft:polished_blackstone_bricks
fill 442 179 480 451 179 480 minecraft:deepslate_tiles
setblock 442 179 504 minecraft:polished_blackstone_bricks
fill 443 179 464 446 179 464 minecraft:blackstone
setblock 443 179 503 minecraft:polished_blackstone_bricks
fill 443 179 504 446 179 504 minecraft:blackstone
setblock 444 179 502 minecraft:polished_blackstone_bricks
fill 444 179 503 447 179 503 minecraft:blackstone
fill 445 179 502 448 179 502 minecraft:blackstone
fill 446 179 501 449 179 501 minecraft:blackstone
setblock 447 179 464 minecraft:polished_blackstone_bricks
fill 447 179 465 447 182 465 minecraft:blackstone
setblock 447 179 504 minecraft:polished_blackstone_bricks
fill 448 179 464 448 182 464 minecraft:blackstone
fill 448 179 500 450 179 500 minecraft:blackstone
setblock 448 179 503 minecraft:polished_blackstone_bricks
fill 448 179 504 448 182 504 minecraft:blackstone
setblock 449 179 502 minecraft:polished_blackstone_bricks
fill 449 179 503 449 182 503 minecraft:blackstone
fill 450 179 481 451 179 488 minecraft:deepslate_tiles
setblock 450 179 501 minecraft:polished_blackstone_bricks
fill 450 179 502 450 182 502 minecraft:blackstone
setblock 451 179 500 minecraft:polished_blackstone_bricks
fill 451 179 501 451 182 501 minecraft:blackstone
setblock 452 179 464 minecraft:polished_blackstone_bricks
setblock 452 179 500 minecraft:blackstone
setblock 452 179 504 minecraft:polished_blackstone_bricks
fill 453 179 464 453 181 464 minecraft:blackstone
setblock 453 179 503 minecraft:polished_blackstone_bricks
fill 453 179 504 453 182 504 minecraft:blackstone
setblock 454 179 502 minecraft:polished_blackstone_bricks
fill 454 179 503 454 182 503 minecraft:blackstone
fill 455 179 502 455 180 502 minecraft:blackstone
setblock 457 179 504 minecraft:polished_blackstone_bricks
fill 458 179 504 458 181 504 minecraft:blackstone
fill 463 179 475 463 179 477 minecraft:blackstone
setblock 463 179 478 minecraft:polished_blackstone_bricks
fill 463 179 479 463 179 482 minecraft:blackstone
setblock 463 179 483 minecraft:polished_blackstone_bricks
setblock 463 179 493 minecraft:polished_blackstone_bricks
fill 463 179 494 463 180 494 minecraft:blackstone
setblock 463 179 498 minecraft:polished_blackstone_bricks
fill 463 179 499 463 182 499 minecraft:blackstone
setblock 464 179 472 minecraft:polished_blackstone_bricks
fill 464 179 473 464 179 476 minecraft:blackstone
setblock 464 179 477 minecraft:polished_blackstone_bricks
fill 464 179 478 464 182 478 minecraft:blackstone
fill 464 179 480 464 179 481 minecraft:blackstone
setblock 464 179 482 minecraft:polished_blackstone_bricks
fill 464 179 483 464 179 486 minecraft:blackstone
setblock 464 179 487 minecraft:polished_blackstone_bricks
fill 464 179 488 464 182 488 minecraft:blackstone
setblock 464 179 492 minecraft:polished_blackstone_bricks
fill 464 179 493 464 182 493 minecraft:blackstone
setblock 464 179 497 minecraft:polished_blackstone_bricks
fill 464 179 498 464 182 498 minecraft:blackstone
setblock 464 179 501 minecraft:blackstone
setblock 464 179 502 minecraft:polished_blackstone_bricks
fill 464 179 503 464 181 504 minecraft:blackstone
fill 424 180 467 424 183 467 minecraft:blackstone
setblock 424 180 471 minecraft:polished_blackstone_bricks
fill 424 180 472 424 183 472 minecraft:blackstone
setblock 424 180 476 minecraft:polished_blackstone_bricks
fill 424 180 477 424 183 477 minecraft:blackstone
setblock 424 180 481 minecraft:polished_blackstone_bricks
fill 424 180 482 424 183 482 minecraft:blackstone
setblock 424 180 486 minecraft:polished_blackstone_bricks
fill 424 180 487 424 183 487 minecraft:blackstone
setblock 424 180 496 minecraft:polished_blackstone_bricks
fill 424 180 497 424 182 497 minecraft:blackstone
setblock 424 180 500 minecraft:blackstone
setblock 424 180 501 minecraft:polished_blackstone_bricks
fill 424 180 502 425 182 502 minecraft:blackstone
fill 424 180 504 425 180 504 minecraft:blackstone
setblock 425 180 464 minecraft:blackstone
setblock 425 180 470 minecraft:polished_blackstone_bricks
fill 425 180 471 425 183 471 minecraft:blackstone
setblock 425 180 475 minecraft:polished_blackstone_bricks
fill 425 180 476 425 183 476 minecraft:blackstone
setblock 425 180 480 minecraft:polished_blackstone_bricks
fill 425 180 481 425 183 481 minecraft:blackstone
setblock 425 180 485 minecraft:polished_blackstone_bricks
setblock 425 180 500 minecraft:polished_blackstone_bricks
fill 425 180 501 425 183 501 minecraft:blackstone
setblock 426 180 464 minecraft:polished_blackstone_bricks
setblock 426 180 474 minecraft:polished_blackstone_bricks
fill 426 180 475 426 183 475 minecraft:blackstone
setblock 426 180 479 minecraft:polished_blackstone_bricks
fill 426 180 480 426 183 480 minecraft:blackstone
setblock 426 180 503 minecraft:blackstone
setblock 426 180 504 minecraft:polished_blackstone_bricks
fill 427 180 464 430 180 464 minecraft:blackstone
setblock 427 180 473 minecraft:polished_blackstone_bricks
fill 427 180 474 427 181 474 minecraft:blackstone
setblock 427 180 478 minecraft:polished_blackstone_bricks
fill 427 180 479 427 183 479 minecraft:blackstone
setblock 427 180 503 minecraft:polished_blackstone_bricks
fill 427 180 504 427 183 504 minecraft:blackstone
setblock 428 180 477 minecraft:polished_blackstone_bricks
setblock 428 180 478 minecraft:blackstone
fill 428 180 503 428 183 503 minecraft:blackstone
setblock 429 180 502 minecraft:blackstone
setblock 430 180 465 minecraft:polished_blackstone_bricks
setblock 431 180 464 minecraft:polished_blackstone_bricks
fill 431 180 465 431 183 465 minecraft:blackstone
setblock 431 180 504 minecraft:polished_blackstone_bricks
fill 432 180 464 432 183 464 minecraft:blackstone
setblock 432 180 503 minecraft:polished_blackstone_bricks
fill 432 180 504 432 183 504 minecraft:blackstone
fill 433 180 503 433 183 503 minecraft:blackstone
setblock 436 180 464 minecraft:polished_blackstone_bricks
setblock 436 180 504 minecraft:polished_blackstone_bricks
fill 437 180 464 440 180 464 minecraft:blackstone
fill 437 180 504 440 180 504 minecraft:blackstone
fill 440 180 481 441 180 487 minecraft:deepslate_tiles
fill 440 180 503 441 180 503 minecraft:blackstone
setblock 441 180 464 minecraft:polished_blackstone_bricks
setblock 441 180 504 minecraft:polished_blackstone_bricks
fill 442 180 464 445 180 464 minecraft:blackstone
setblock 442 180 503 minecraft:polished_blackstone_bricks
fill 442 180 504 445 180 504 minecraft:blackstone
setblock 443 180 502 minecraft:polished_blackstone_bricks
fill 443 180 503 446 180 503 minecraft:blackstone
fill 444 180 502 447 180 502 minecraft:blackstone
fill 445 180 501 448 180 501 minecraft:blackstone
setblock 446 180 464 minecraft:polished_blackstone_bricks
fill 446 180 465 446 181 465 minecraft:blackstone
setblock 446 180 504 minecraft:polished_blackstone_bricks
fill 447 180 464 447 183 464 minecraft:blackstone
setblock 447 180 503 minecraft:polished_blackstone_bricks
fill 447 180 504 447 183 504 minecraft:blackstone
fill 448 180 500 449 180 500 minecraft:blackstone
setblock 448 180 502 minecraft:polished_blackstone_bricks
fill 448 180 503 448 183 503 minecraft:blackstone
setblock 449 180 501 minecraft:polished_blackstone_bricks
fill 449 180 502 449 183 502 minecraft:blackstone
fill 450 180 481 450 180 487 minecraft:deepslate_tiles
setblock 450 180 500 minecraft:polished_blackstone_bricks
fill 450 180 501 450 183 501 minecraft:blackstone
setblock 451 180 464 minecraft:polished_blackstone_bricks
setblock 451 180 500 minecraft:blackstone
setblock 451 180 504 minecraft:polished_blackstone_bricks
fill 452 180 464 452 182 464 minecraft:blackstone
setblock 452 180 503 minecraft:polished_blackstone_bricks
fill 452 180 504 452 183 504 minecraft:blackstone
setblock 453 180 502 minecraft:polished_blackstone_bricks
fill 453 180 503 453 183 503 minecraft:blackstone
fill 454 180 502 454 181 502 minecraft:blackstone
setblock 456 180 504 minecraft:polished_blackstone_bricks
setblock 457 180 503 minecraft:polished_blackstone_bricks
fill 457 180 504 457 182 504 minecraft:blackstone
fill 463 180 475 463 180 476 minecraft:blackstone
setblock 463 180 477 minecraft:polished_blackstone_bricks
fill 463 180 478 463 180 481 minecraft:blackstone
setblock 463 180 482 minecraft:polished_blackstone_bricks
fill 463 180 483 464 181 484 minecraft:blackstone
setblock 463 180 497 minecraft:polished_blackstone_bricks
fill 463 180 498 463 182 498 minecraft:blackstone
fill 463 180 504 463 182 504 minecraft:blackstone
fill 464 180 472 464 180 475 minecraft:blackstone
setblock 464 180 476 minecraft:polished_blackstone_bricks
fill 464 180 477 464 183 477 minecraft:blackstone
setblock 464 180 480 minecraft:blackstone
setblock 464 180 481 minecraft:polished_blackstone_bricks
fill 464 180 482 464 183 482 minecraft:blackstone
setblock 464 180 485 minecraft:blackstone
setblock 464 180 486 minecraft:polished_blackstone_bricks
fill 464 180 487 464 183 487 minecraft:blackstone
setblock 464 180 491 minecraft:polished_blackstone_bricks
fill 464 180 492 464 183 492 minecraft:blackstone
setblock 464 180 496 minecraft:polished_blackstone_bricks
fill 464 180 497 464 183 497 minecraft:blackstone
setblock 464 180 501 minecraft:polished_blackstone_bricks
fill 464 180 502 464 183 502 minecraft:blackstone
setblock 424 181 464 minecraft:blackstone
setblock 424 181 465 minecraft:polished_blackstone_bricks
fill 424 181 466 424 184 466 minecraft:blackstone
setblock 424 181 470 minecraft:polished_blackstone_bricks
fill 424 181 471 424 184 471 minecraft:blackstone
setblock 424 181 475 minecraft:polished_blackstone_bricks
fill 424 181 476 424 184 476 minecraft:blackstone
setblock 424 181 480 minecraft:polished_blackstone_bricks
fill 424 181 481 424 184 481 minecraft:blackstone
setblock 424 181 484 minecraft:blackstone
setblock 424 181 485 minecraft:polished_blackstone_bricks
fill 424 181 486 424 184 486 minecraft:blackstone
setblock 424 181 495 minecraft:polished_blackstone_bricks
fill 424 181 496 424 182 496 minecraft:blackstone
setblock 424 181 499 minecraft:blackstone
setblock 424 181 500 minecraft:polished_blackstone_bricks
fill 424 181 501 424 184 501 minecraft:blackstone
setblock 424 181 504 minecraft:blackstone
setblock 425 181 464 minecraft:polished_blackstone_bricks
setblock 425 181 470 minecraft:blackstone
setblock 425 181 474 minecraft:polished_blackstone_bricks
fill 425 181 475 425 184 475 minecraft:blackstone
setblock 425 181 479 minecraft:polished_blackstone_bricks
fill 425 181 480 425 184 480 minecraft:blackstone
setblock 425 181 484 minecraft:polished_blackstone_bricks
fill 425 181 485 425 184 485 minecraft:blackstone
setblock 425 181 499 minecraft:polished_blackstone_bricks
fill 425 181 500 425 182 500 minecraft:blackstone
setblock 425 181 504 minecraft:polished_blackstone_bricks
fill 426 181 464 426 183 465 minecraft:blackstone
setblock 426 181 473 minecraft:polished_blackstone_bricks
fill 426 181 474 426 183 474 minecraft:blackstone
setblock 426 181 478 minecraft:polished_blackstone_bricks
fill 426 181 479 426 184 479 minecraft:blackstone
setblock 426 181 483 minecraft:polished_blackstone_bricks
setblock 426 181 503 minecraft:polished_blackstone_bricks
fill 426 181 504 426 184 504 minecraft:blackstone
fill 427 181 464 429 181 464 minecraft:blackstone
setblock 427 181 477 minecraft:polished_blackstone_bricks
fill 427 181 478 427 183 478 minecraft:blackstone
fill 427 181 503 427 184 503 minecraft:blackstone
setblock 429 181 465 minecraft:polished_blackstone_bricks
setblock 430 181 464 minecraft:polished_blackstone_bricks
fill 430 181 465 430 184 465 minecraft:blackstone
setblock 430 181 504 minecraft:polished_blackstone_bricks
fill 431 181 464 431 184 464 minecraft:blackstone
setblock 431 181 503 minecraft:polished_blackstone_bricks
fill 431 181 504 431 184 504 minecraft:blackstone
fill 432 181 503 432 184 503 minecraft:blackstone
setblock 435 181 464 minecraft:polished_blackstone_bricks
setblock 435 181 503 minecraft:blackstone
setblock 435 181 504 minecraft:polished_blackstone_bricks
fill 436 181 464 439 181 464 minecraft:blackstone
setblock 436 181 503 minecraft:polished_blackstone_bricks
fill 436 181 504 439 181 504 minecraft:blackstone
fill 439 181 503 440 181 503 minecraft:blackstone
setblock 440 181 464 minecraft:polished_blackstone_bricks
setblock 440 181 504 minecraft:polished_blackstone_bricks
fill 441 181 464 444 181 464 minecraft:blackstone
fill 441 181 482 441 181 486 minecraft:deepslate_tiles
setblock 441 181 503 minecraft:polished_blackstone_bricks
fill 441 181 504 444 181 504 minecraft:blackstone
fill 442 181 503 445 181 503 minecraft:blackstone
fill 443 181 502 446 181 502 minecraft:blackstone
setblock 445 181 464 minecraft:polished_blackstone_bricks
fill 445 181 501 447 181 501 minecraft:blackstone
setblock 445 181 504 minecraft:polished_blackstone_bricks
fill 446 181 464 446 184 464 minecraft:blackstone
setblock 446 181 503 minecraft:polished_blackstone_bricks
fill 446 181 504 446 184 504 minecraft:blackstone
setblock 447 181 502 minecraft:polished_blackstone_bricks
fill 447 181 503 447 184 503 minecraft:blackstone
setblock 448 181 501 minecraft:polished_blackstone_bricks
fill 448 181 502 448 184 502 minecraft:blackstone
setblock 449 181 500 minecraft:polished_blackstone_bricks
fill 449 181 501 449 184 501 minecraft:blackstone
setblock 450 181 464 minecraft:polished_blackstone_bricks
setblock 450 181 504 minecraft:polished_blackstone_bricks
fill 451 181 464 451 184 464 minecraft:blackstone
setblock 451 181 503 minecraft:polished_blackstone_bricks
fill 451 181 504 451 184 504 minecraft:blackstone
setblock 452 181 502 minecraft:polished_blackstone_bricks
fill 452 181 503 452 184 503 minecraft:blackstone
fill 453 181 495 455 224 495 minecraft:polished_blackstone_bricks
setblock 453 181 501 minecraft:polished_blackstone_bricks
fill 453 181 502 453 182 502 minecraft:blackstone
fill 454 181 494 455 224 494 minecraft:polished_blackstone_bricks
fill 454 181 496 455 224 496 minecraft:polished_blackstone_bricks
setblock 455 181 504 minecraft:polished_blackstone_bricks
setblock 456 181 503 minecraft:polished_blackstone_bricks
fill 456 181 504 456 184 504 minecraft:blackstone
fill 462 181 504 462 183 504 minecraft:blackstone
setblock 463 181 475 minecraft:blackstone
setblock 463 181 476 minecraft:polished_blackstone_bricks
fill 463 181 477 463 181 480 minecraft:blackstone
setblock 463 181 481 minecraft:polished_blackstone_bricks
fill 463 181 482 463 184 482 minecraft:blackstone
setblock 463 181 485 minecraft:blackstone
setblock 463 181 496 minecraft:polished_blackstone_bricks
setblock 463 181 497 minecraft:blackstone
setblock 463 181 500 minecraft:blackstone
setblock 463 181 501 minecraft:polished_blackstone_bricks
fill 464 181 472 464 181 474 minecraft:blackstone
setblock 464 181 475 minecraft:polished_blackstone_bricks
fill 464 181 476 464 184 476 minecraft:blackstone
setblock 464 181 480 minecraft:polished_blackstone_bricks
fill 464 181 481 464 184 481 minecraft:blackstone
setblock 464 181 485 minecraft:polished_blackstone_bricks
fill 464 181 486 464 184 486 minecraft:blackstone
setblock 464 181 490 minecraft:polished_blackstone_bricks
fill 464 181 491 464 184 491 minecraft:blackstone
setblock 464 181 495 minecraft:polished_blackstone_bricks
fill 464 181 496 464 184 496 minecraft:blackstone
setblock 464 181 500 minecraft:polished_blackstone_bricks
fill 464 181 501 464 184 501 minecraft:blackstone
setblock 424 182 464 minecraft:polished_blackstone_bricks
fill 424 182 465 424 185 465 minecraft:blackstone
setblock 424 182 469 minecraft:polished_blackstone_bricks
fill 424 182 470 424 185 470 minecraft:blackstone
setblock 424 182 474 minecraft:polished_blackstone_bricks
fill 424 182 475 424 185 475 minecraft:blackstone
setblock 424 182 479 minecraft:polished_blackstone_bricks
fill 424 182 480 424 185 480 minecraft:blackstone
setblock 424 182 484 minecraft:polished_blackstone_bricks
fill 424 182 485 424 185 485 minecraft:blackstone
setblock 424 182 499 minecraft:polished_blackstone_bricks
fill 424 182 500 424 185 500 minecraft:blackstone
setblock 424 182 504 minecraft:polished_blackstone_bricks
fill 425 182 464 425 185 464 minecraft:blackstone
setblock 425 182 473 minecraft:polished_blackstone_bricks
fill 425 182 474 425 185 474 minecraft:blackstone
setblock 425 182 478 minecraft:polished_blackstone_bricks
fill 425 182 479 425 185 479 minecraft:blackstone
setblock 425 182 483 minecraft:polished_blackstone_bricks
fill 425 182 484 426 184 484 minecraft:blackstone
setblock 425 182 503 minecraft:polished_blackstone_bricks
fill 425 182 504 425 185 504 minecraft:blackstone
setblock 426 182 466 minecraft:light[level=11]
setblock 426 182 473 minecraft:blackstone
setblock 426 182 477 minecraft:polished_blackstone_bricks
fill 426 182 478 426 185 478 minecraft:blackstone
setblock 426 182 481 minecraft:blackstone
setblock 426 182 482 minecraft:polished_blackstone_bricks
fill 426 182 483 426 185 483 minecraft:blackstone
setblock 426 182 490 minecraft:light[level=11]
setblock 426 182 498 minecraft:light[level=11]
fill 426 182 503 426 185 503 minecraft:blackstone
fill 427 182 464 428 182 464 minecraft:blackstone
setblock 427 182 476 minecraft:polished_blackstone_bricks
setblock 427 182 477 minecraft:blackstone
setblock 427 182 481 minecraft:polished_blackstone_bricks
setblock 428 182 465 minecraft:polished_blackstone_bricks
setblock 429 182 464 minecraft:polished_blackstone_bricks
fill 429 182 465 429 185 465 minecraft:blackstone
setblock 429 182 504 minecraft:polished_blackstone_bricks
fill 430 182 464 430 185 464 minecraft:blackstone
setblock 430 182 503 minecraft:polished_blackstone_bricks
fill 430 182 504 430 185 504 minecraft:blackstone
fill 431 182 503 431 185 503 minecraft:blackstone
setblock 433 182 465 minecraft:polished_blackstone_bricks
setblock 434 182 464 minecraft:polished_blackstone_bricks
setblock 434 182 466 minecraft:light[level=11]
setblock 434 182 474 minecraft:light[level=11]
setblock 434 182 482 minecraft:light[level=11]
setblock 434 182 490 minecraft:light[level=11]
setblock 434 182 498 minecraft:light[level=11]
setblock 434 182 504 minecraft:polished_blackstone_bricks
fill 435 182 464 438 182 464 minecraft:blackstone
fill 435 182 504 438 182 504 minecraft:blackstone
setblock 439 182 464 minecraft:polished_blackstone_bricks
setblock 439 182 503 minecraft:blackstone
setblock 439 182 504 minecraft:polished_blackstone_bricks
fill 440 182 464 443 182 464 minecraft:blackstone
setblock 440 182 503 minecraft:polished_blackstone_bricks
fill 440 182 504 443 182 504 minecraft:blackstone
fill 441 182 503 444 182 503 minecraft:blackstone
setblock 442 182 466 minecraft:light[level=11]
setblock 442 182 474 minecraft:light[level=11]
setblock 442 182 490 minecraft:light[level=11]
setblock 442 182 498 minecraft:light[level=11]
fill 442 182 502 445 182 502 minecraft:blackstone
setblock 444 182 464 minecraft:polished_blackstone_bricks
setblock 444 182 504 minecraft:polished_blackstone_bricks
fill 445 182 464 445 185 464 minecraft:blackstone
fill 445 182 501 446 182 501 minecraft:blackstone
setblock 445 182 503 minecraft:polished_blackstone_bricks
fill 445 182 504 445 185 504 minecraft:blackstone
setblock 446 182 502 minecraft:polished_blackstone_bricks
fill 446 182 503 446 185 503 minecraft:blackstone
setblock 447 182 501 minecraft:polished_blackstone_bricks
fill 447 182 502 447 185 502 minecraft:blackstone
fill 448 182 501 448 184 501 minecraft:blackstone
setblock 449 182 464 minecraft:polished_blackstone_bricks
setblock 449 182 504 minecraft:polished_blackstone_bricks
fill 450 182 464 450 185 464 minecraft:blackstone
setblock 450 182 466 minecraft:light[level=11]
setblock 450 182 474 minecraft:light[level=11]
setblock 450 182 482 minecraft:light[level=11]
setblock 450 182 490 minecraft:light[level=11]
setblock 450 182 498 minecraft:light[level=11]
setblock 450 182 503 minecraft:polished_blackstone_bricks
fill 450 182 504 450 185 504 minecraft:blackstone
setblock 451 182 502 minecraft:polished_blackstone_bricks
fill 451 182 503 451 185 503 minecraft:blackstone
fill 452 182 502 452 184 502 minecraft:blackstone
fill 453 182 494 453 183 494 minecraft:blackstone
fill 453 182 496 453 183 496 minecraft:blackstone
fill 454 182 493 455 183 493 minecraft:blackstone
setblock 454 182 504 minecraft:polished_blackstone_bricks
setblock 455 182 503 minecraft:polished_blackstone_bricks
fill 455 182 504 455 185 504 minecraft:blackstone
fill 456 182 494 456 183 495 minecraft:blackstone
setblock 458 182 466 minecraft:light[level=11]
setblock 458 182 474 minecraft:light[level=11]
setblock 458 182 482 minecraft:light[level=11]
setblock 458 182 490 minecraft:light[level=11]
setblock 458 182 498 minecraft:light[level=11]
fill 463 182 476 463 182 479 minecraft:blackstone
setblock 463 182 480 minecraft:polished_blackstone_bricks
fill 463 182 481 463 185 481 minecraft:blackstone
fill 463 182 483 463 182 484 minecraft:blackstone
setblock 463 182 485 minecraft:polished_blackstone_bricks
fill 463 182 486 463 185 486 minecraft:blackstone
setblock 463 182 500 minecraft:polished_blackstone_bricks
setblock 464 182 473 minecraft:blackstone
setblock 464 182 474 minecraft:polished_blackstone_bricks
fill 464 182 475 464 185 475 minecraft:blackstone
setblock 464 182 479 minecraft:polished_blackstone_bricks
fill 464 182 480 464 185 480 minecraft:blackstone
setblock 464 182 483 minecraft:blackstone
setblock 464 182 484 minecraft:polished_blackstone_bricks
fill 464 182 485 464 185 485 minecraft:blackstone
setblock 464 182 489 minecraft:polished_blackstone_bricks
fill 464 182 490 464 185 490 minecraft:blackstone
setblock 464 182 494 minecraft:polished_blackstone_bricks
fill 464 182 495 464 184 495 minecraft:blackstone
setblock 464 182 499 minecraft:polished_blackstone_bricks
fill 464 182 500 464 185 500 minecraft:blackstone
setblock 464 182 503 minecraft:blackstone
setblock 464 182 504 minecraft:polished_blackstone_bricks
fill 424 183 464 424 186 464 minecraft:blackstone
setblock 424 183 468 minecraft:polished_blackstone_bricks
fill 424 183 469 424 186 469 minecraft:blackstone
setblock 424 183 473 minecraft:polished_blackstone_bricks
fill 424 183 474 424 186 474 minecraft:blackstone
setblock 424 183 478 minecraft:polished_blackstone_bricks
fill 424 183 479 424 186 479 minecraft:blackstone
setblock 424 183 483 minecraft:polished_blackstone_bricks
fill 424 183 484 424 186 484 minecraft:blackstone
setblock 424 183 488 minecraft:polished_blackstone_bricks
setblock 424 183 498 minecraft:polished_blackstone_bricks
fill 424 183 499 424 186 499 minecraft:blackstone
setblock 424 183 502 minecraft:blackstone
setblock 424 183 503 minecraft:polished_blackstone_bricks
fill 424 183 504 424 186 504 minecraft:blackstone
fill 425 183 465 425 184 465 minecraft:blackstone
setblock 425 183 472 minecraft:polished_blackstone_bricks
fill 425 183 473 425 186 473 minecraft:blackstone
setblock 425 183 477 minecraft:polished_blackstone_bricks
fill 425 183 478 425 186 478 minecraft:blackstone
setblock 425 183 482 minecraft:polished_blackstone_bricks
fill 425 183 483 425 186 483 minecraft:blackstone
setblock 425 183 486 minecraft:blackstone
setblock 425 183 502 minecraft:polished_blackstone_bricks
fill 425 183 503 425 186 503 minecraft:blackstone
setblock 426 183 476 minecraft:polished_blackstone_bricks
fill 426 183 477 426 186 477 minecraft:blackstone
setblock 426 183 481 minecraft:polished_blackstone_bricks
fill 426 183 482 426 186 482 minecraft:blackstone
setblock 427 183 464 minecraft:blackstone
setblock 427 183 465 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/117_6 1t
