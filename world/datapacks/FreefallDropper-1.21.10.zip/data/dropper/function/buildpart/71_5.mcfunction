setblock 559 234 290 minecraft:brown_terracotta
setblock 559 234 293 minecraft:white_concrete
setblock 559 234 297 minecraft:white_concrete
setblock 559 234 301 minecraft:white_concrete
setblock 559 234 302 minecraft:brown_terracotta
setblock 559 234 305 minecraft:white_concrete
setblock 559 234 309 minecraft:white_concrete
setblock 559 234 313 minecraft:white_concrete
setblock 559 234 314 minecraft:brown_terracotta
setblock 559 234 317 minecraft:white_concrete
setblock 517 235 276 minecraft:white_concrete
fill 517 235 277 517 242 277 minecraft:brown_terracotta
setblock 517 235 278 minecraft:white_concrete
setblock 517 235 280 minecraft:white_concrete
fill 517 235 281 517 242 281 minecraft:brown_terracotta
setblock 517 235 282 minecraft:white_concrete
setblock 517 235 283 minecraft:brown_terracotta
setblock 517 235 284 minecraft:white_concrete
fill 517 235 285 517 242 285 minecraft:brown_terracotta
setblock 517 235 286 minecraft:white_concrete
setblock 517 235 288 minecraft:white_concrete
fill 517 235 289 517 242 289 minecraft:brown_terracotta
setblock 517 235 290 minecraft:white_concrete
setblock 517 235 292 minecraft:white_concrete
fill 517 235 293 517 242 293 minecraft:brown_terracotta
setblock 517 235 294 minecraft:white_concrete
setblock 517 235 295 minecraft:brown_terracotta
setblock 517 235 296 minecraft:white_concrete
fill 517 235 297 517 242 297 minecraft:brown_terracotta
setblock 517 235 298 minecraft:white_concrete
setblock 517 235 300 minecraft:white_concrete
fill 517 235 301 517 242 301 minecraft:brown_terracotta
setblock 517 235 302 minecraft:white_concrete
setblock 517 235 304 minecraft:white_concrete
fill 517 235 305 517 242 305 minecraft:brown_terracotta
setblock 517 235 306 minecraft:white_concrete
setblock 517 235 307 minecraft:brown_terracotta
setblock 517 235 308 minecraft:white_concrete
fill 517 235 309 517 242 309 minecraft:brown_terracotta
setblock 517 235 310 minecraft:white_concrete
setblock 517 235 312 minecraft:white_concrete
fill 517 235 313 517 242 313 minecraft:brown_terracotta
setblock 517 235 314 minecraft:white_concrete
setblock 517 235 316 minecraft:white_concrete
setblock 517 235 317 minecraft:brown_terracotta
setblock 518 235 275 minecraft:white_concrete
setblock 518 235 282 minecraft:shroomlight
setblock 518 235 284 minecraft:shroomlight
setblock 518 235 286 minecraft:shroomlight
setblock 518 235 288 minecraft:shroomlight
setblock 518 235 290 minecraft:shroomlight
fill 518 235 313 519 235 313 minecraft:white_concrete
setblock 518 235 317 minecraft:white_concrete
fill 519 235 275 519 242 275 minecraft:brown_terracotta
setblock 519 235 281 minecraft:shroomlight
setblock 519 235 283 minecraft:shroomlight
setblock 519 235 285 minecraft:shroomlight
setblock 519 235 287 minecraft:shroomlight
setblock 519 235 289 minecraft:shroomlight
setblock 519 235 291 minecraft:shroomlight
fill 519 235 311 519 236 312 minecraft:white_concrete
fill 519 235 317 519 242 317 minecraft:brown_terracotta
setblock 520 235 275 minecraft:white_concrete
setblock 520 235 278 minecraft:light[level=15]
setblock 520 235 282 minecraft:shroomlight
setblock 520 235 284 minecraft:shroomlight
setblock 520 235 286 minecraft:shroomlight
setblock 520 235 288 minecraft:shroomlight
setblock 520 235 290 minecraft:shroomlight
setblock 520 235 294 minecraft:light[level=15]
setblock 520 235 302 minecraft:light[level=15]
setblock 520 235 310 minecraft:light[level=15]
fill 520 235 312 520 238 312 minecraft:white_concrete
setblock 520 235 317 minecraft:white_concrete
setblock 521 235 281 minecraft:shroomlight
setblock 521 235 283 minecraft:shroomlight
setblock 521 235 285 minecraft:shroomlight
setblock 521 235 287 minecraft:shroomlight
setblock 521 235 289 minecraft:shroomlight
setblock 521 235 291 minecraft:shroomlight
setblock 522 235 275 minecraft:white_concrete
setblock 522 235 276 minecraft:shroomlight
setblock 522 235 278 minecraft:shroomlight
setblock 522 235 280 minecraft:shroomlight
setblock 522 235 282 minecraft:shroomlight
setblock 522 235 284 minecraft:shroomlight
setblock 522 235 286 minecraft:shroomlight
setblock 522 235 288 minecraft:shroomlight
setblock 522 235 290 minecraft:shroomlight
setblock 522 235 317 minecraft:white_concrete
fill 523 235 275 523 242 275 minecraft:brown_terracotta
setblock 523 235 277 minecraft:shroomlight
setblock 523 235 279 minecraft:shroomlight
setblock 523 235 281 minecraft:shroomlight
setblock 523 235 283 minecraft:shroomlight
setblock 523 235 285 minecraft:shroomlight
setblock 523 235 287 minecraft:shroomlight
setblock 523 235 289 minecraft:shroomlight
setblock 523 235 291 minecraft:shroomlight
fill 523 235 317 523 242 317 minecraft:brown_terracotta
setblock 524 235 275 minecraft:white_concrete
setblock 524 235 276 minecraft:shroomlight
setblock 524 235 278 minecraft:shroomlight
setblock 524 235 280 minecraft:shroomlight
setblock 524 235 317 minecraft:white_concrete
setblock 525 235 275 minecraft:brown_terracotta
setblock 525 235 277 minecraft:shroomlight
setblock 525 235 279 minecraft:shroomlight
setblock 526 235 275 minecraft:white_concrete
setblock 526 235 276 minecraft:shroomlight
setblock 526 235 278 minecraft:shroomlight
setblock 526 235 280 minecraft:shroomlight
setblock 526 235 317 minecraft:white_concrete
fill 527 235 275 527 242 275 minecraft:brown_terracotta
setblock 527 235 277 minecraft:shroomlight
setblock 527 235 279 minecraft:shroomlight
fill 527 235 317 527 242 317 minecraft:brown_terracotta
setblock 528 235 275 minecraft:white_concrete
setblock 528 235 276 minecraft:shroomlight
setblock 528 235 278 minecraft:shroomlight
setblock 528 235 280 minecraft:shroomlight
setblock 528 235 286 minecraft:light[level=15]
setblock 528 235 294 minecraft:light[level=15]
setblock 528 235 302 minecraft:light[level=15]
setblock 528 235 310 minecraft:light[level=15]
setblock 528 235 317 minecraft:white_concrete
setblock 530 235 275 minecraft:white_concrete
setblock 530 235 317 minecraft:white_concrete
fill 531 235 275 531 242 275 minecraft:brown_terracotta
fill 531 235 317 531 242 317 minecraft:brown_terracotta
setblock 532 235 275 minecraft:white_concrete
setblock 532 235 317 minecraft:white_concrete
setblock 534 235 275 minecraft:white_concrete
fill 534 235 282 534 238 282 minecraft:brown_terracotta
fill 534 235 285 534 238 285 minecraft:brown_terracotta
setblock 534 235 317 minecraft:white_concrete
fill 535 235 275 535 242 275 minecraft:brown_terracotta
fill 535 235 317 535 242 317 minecraft:brown_terracotta
setblock 536 235 275 minecraft:white_concrete
setblock 536 235 278 minecraft:light[level=15]
setblock 536 235 286 minecraft:light[level=15]
setblock 536 235 294 minecraft:light[level=15]
setblock 536 235 302 minecraft:light[level=15]
setblock 536 235 310 minecraft:light[level=15]
setblock 536 235 317 minecraft:white_concrete
setblock 537 235 275 minecraft:brown_terracotta
setblock 538 235 275 minecraft:white_concrete
setblock 538 235 317 minecraft:white_concrete
fill 539 235 275 539 242 275 minecraft:brown_terracotta
fill 539 235 317 539 242 317 minecraft:brown_terracotta
setblock 540 235 275 minecraft:white_concrete
setblock 540 235 317 minecraft:white_concrete
setblock 542 235 275 minecraft:white_concrete
setblock 542 235 317 minecraft:white_concrete
fill 543 235 275 543 242 275 minecraft:brown_terracotta
fill 543 235 312 543 236 312 minecraft:white_concrete
fill 543 235 317 543 242 317 minecraft:brown_terracotta
setblock 544 235 275 minecraft:white_concrete
setblock 544 235 278 minecraft:light[level=15]
setblock 544 235 286 minecraft:light[level=15]
setblock 544 235 294 minecraft:light[level=15]
setblock 544 235 302 minecraft:light[level=15]
setblock 544 235 310 minecraft:light[level=15]
setblock 544 235 317 minecraft:white_concrete
setblock 546 235 275 minecraft:white_concrete
setblock 546 235 317 minecraft:white_concrete
fill 547 235 275 547 242 275 minecraft:brown_terracotta
fill 547 235 317 547 242 317 minecraft:brown_terracotta
setblock 548 235 275 minecraft:white_concrete
setblock 548 235 317 minecraft:white_concrete
setblock 549 235 275 minecraft:brown_terracotta
setblock 550 235 275 minecraft:white_concrete
setblock 550 235 317 minecraft:white_concrete
fill 551 235 275 551 242 275 minecraft:brown_terracotta
fill 551 235 317 551 242 317 minecraft:brown_terracotta
setblock 552 235 275 minecraft:white_concrete
setblock 552 235 278 minecraft:light[level=15]
setblock 552 235 286 minecraft:light[level=15]
setblock 552 235 294 minecraft:light[level=15]
setblock 552 235 302 minecraft:light[level=15]
setblock 552 235 310 minecraft:light[level=15]
setblock 552 235 317 minecraft:white_concrete
setblock 554 235 275 minecraft:white_concrete
setblock 554 235 317 minecraft:white_concrete
fill 555 235 275 555 242 275 minecraft:brown_terracotta
fill 555 235 312 556 237 312 minecraft:white_concrete
fill 555 235 317 555 242 317 minecraft:brown_terracotta
setblock 556 235 275 minecraft:white_concrete
fill 556 235 311 556 236 311 minecraft:white_concrete
fill 556 235 313 556 236 313 minecraft:white_concrete
setblock 556 235 317 minecraft:white_concrete
setblock 558 235 275 minecraft:white_concrete
setblock 558 235 317 minecraft:white_concrete
setblock 559 235 275 minecraft:brown_terracotta
setblock 559 235 276 minecraft:white_concrete
fill 559 235 277 559 242 277 minecraft:brown_terracotta
setblock 559 235 278 minecraft:white_concrete
setblock 559 235 280 minecraft:white_concrete
fill 559 235 281 559 242 281 minecraft:brown_terracotta
setblock 559 235 282 minecraft:white_concrete
setblock 559 235 284 minecraft:white_concrete
fill 559 235 285 559 242 285 minecraft:brown_terracotta
setblock 559 235 286 minecraft:white_concrete
setblock 559 235 288 minecraft:white_concrete
fill 559 235 289 559 242 289 minecraft:brown_terracotta
setblock 559 235 290 minecraft:white_concrete
setblock 559 235 292 minecraft:white_concrete
fill 559 235 293 559 242 293 minecraft:brown_terracotta
setblock 559 235 294 minecraft:white_concrete
setblock 559 235 296 minecraft:white_concrete
fill 559 235 297 559 242 297 minecraft:brown_terracotta
setblock 559 235 298 minecraft:white_concrete
setblock 559 235 300 minecraft:white_concrete
fill 559 235 301 559 242 301 minecraft:brown_terracotta
setblock 559 235 302 minecraft:white_concrete
setblock 559 235 304 minecraft:white_concrete
fill 559 235 305 559 242 305 minecraft:brown_terracotta
setblock 559 235 306 minecraft:white_concrete
setblock 559 235 308 minecraft:white_concrete
fill 559 235 309 559 242 309 minecraft:brown_terracotta
setblock 559 235 310 minecraft:white_concrete
setblock 559 235 312 minecraft:white_concrete
fill 559 235 313 559 242 313 minecraft:brown_terracotta
setblock 559 235 314 minecraft:white_concrete
setblock 559 235 316 minecraft:white_concrete
fill 559 235 317 559 242 317 minecraft:brown_terracotta
setblock 517 236 275 minecraft:white_concrete
fill 517 236 276 517 243 276 minecraft:brown_terracotta
fill 517 236 278 517 243 278 minecraft:brown_terracotta
setblock 517 236 279 minecraft:white_concrete
fill 517 236 280 517 243 280 minecraft:brown_terracotta
fill 517 236 282 517 243 282 minecraft:brown_terracotta
setblock 517 236 283 minecraft:white_concrete
fill 517 236 284 517 243 284 minecraft:brown_terracotta
fill 517 236 286 517 243 286 minecraft:brown_terracotta
setblock 517 236 287 minecraft:white_concrete
fill 517 236 288 517 243 288 minecraft:brown_terracotta
fill 517 236 290 517 243 290 minecraft:brown_terracotta
setblock 517 236 291 minecraft:white_concrete
fill 517 236 292 517 243 292 minecraft:brown_terracotta
fill 517 236 294 517 243 294 minecraft:brown_terracotta
setblock 517 236 295 minecraft:white_concrete
fill 517 236 296 517 243 296 minecraft:brown_terracotta
fill 517 236 298 517 243 298 minecraft:brown_terracotta
setblock 517 236 299 minecraft:white_concrete
fill 517 236 300 517 243 300 minecraft:brown_terracotta
fill 517 236 302 517 243 302 minecraft:brown_terracotta
setblock 517 236 303 minecraft:white_concrete
fill 517 236 304 517 243 304 minecraft:brown_terracotta
fill 517 236 306 517 243 306 minecraft:brown_terracotta
setblock 517 236 307 minecraft:white_concrete
fill 517 236 308 517 243 308 minecraft:brown_terracotta
fill 517 236 310 517 243 310 minecraft:brown_terracotta
setblock 517 236 311 minecraft:white_concrete
fill 517 236 312 517 243 312 minecraft:brown_terracotta
fill 517 236 314 517 243 314 minecraft:brown_terracotta
setblock 517 236 315 minecraft:white_concrete
fill 517 236 316 517 243 316 minecraft:brown_terracotta
setblock 517 236 317 minecraft:white_concrete
fill 518 236 275 518 243 275 minecraft:brown_terracotta
fill 518 236 282 518 237 282 minecraft:white_concrete
fill 518 236 284 518 237 284 minecraft:white_concrete
fill 518 236 286 518 237 286 minecraft:white_concrete
fill 518 236 288 518 237 288 minecraft:white_concrete
fill 518 236 290 518 237 290 minecraft:white_concrete
fill 518 236 317 518 243 317 minecraft:brown_terracotta
fill 519 236 281 519 237 281 minecraft:white_concrete
fill 519 236 283 519 237 283 minecraft:white_concrete
fill 519 236 285 519 237 285 minecraft:white_concrete
fill 519 236 287 519 237 287 minecraft:white_concrete
fill 519 236 289 519 237 289 minecraft:white_concrete
fill 519 236 291 519 237 291 minecraft:white_concrete
fill 519 236 313 520 236 313 minecraft:white_concrete
fill 520 236 275 520 243 275 minecraft:brown_terracotta
fill 520 236 282 520 237 282 minecraft:white_concrete
fill 520 236 284 520 237 284 minecraft:white_concrete
fill 520 236 286 520 237 286 minecraft:white_concrete
fill 520 236 288 520 237 288 minecraft:white_concrete
fill 520 236 290 520 237 290 minecraft:white_concrete
fill 520 236 311 520 237 311 minecraft:white_concrete
fill 520 236 317 520 243 317 minecraft:brown_terracotta
setblock 521 236 275 minecraft:white_concrete
fill 521 236 281 521 237 281 minecraft:white_concrete
fill 521 236 283 521 237 283 minecraft:white_concrete
fill 521 236 285 521 237 285 minecraft:white_concrete
fill 521 236 287 521 237 287 minecraft:white_concrete
fill 521 236 289 521 237 289 minecraft:white_concrete
fill 521 236 291 521 237 291 minecraft:white_concrete
fill 521 236 312 521 238 312 minecraft:white_concrete
setblock 521 236 317 minecraft:white_concrete
fill 522 236 275 522 243 275 minecraft:brown_terracotta
fill 522 236 276 522 237 276 minecraft:white_concrete
fill 522 236 278 522 237 278 minecraft:white_concrete
fill 522 236 280 522 237 280 minecraft:white_concrete
fill 522 236 282 522 237 282 minecraft:white_concrete
fill 522 236 284 522 237 284 minecraft:white_concrete
fill 522 236 286 522 237 286 minecraft:white_concrete
fill 522 236 288 522 237 288 minecraft:white_concrete
fill 522 236 290 522 237 290 minecraft:white_concrete
fill 522 236 317 522 243 317 minecraft:brown_terracotta
fill 523 236 277 523 237 277 minecraft:white_concrete
fill 523 236 279 523 237 279 minecraft:white_concrete
fill 523 236 281 523 237 281 minecraft:white_concrete
fill 523 236 283 523 237 283 minecraft:white_concrete
fill 523 236 285 523 237 285 minecraft:white_concrete
fill 523 236 287 523 237 287 minecraft:white_concrete
fill 523 236 289 523 237 289 minecraft:white_concrete
fill 523 236 291 523 237 291 minecraft:white_concrete
fill 524 236 275 524 243 275 minecraft:brown_terracotta
fill 524 236 276 524 237 276 minecraft:white_concrete
fill 524 236 278 524 237 278 minecraft:white_concrete
fill 524 236 280 524 237 280 minecraft:white_concrete
fill 524 236 317 524 243 317 minecraft:brown_terracotta
setblock 525 236 275 minecraft:white_concrete
fill 525 236 277 525 237 277 minecraft:white_concrete
fill 525 236 279 525 237 279 minecraft:white_concrete
setblock 525 236 317 minecraft:white_concrete
fill 526 236 275 526 243 275 minecraft:brown_terracotta
fill 526 236 276 526 237 276 minecraft:white_concrete
fill 526 236 278 526 237 278 minecraft:white_concrete
fill 526 236 280 526 237 280 minecraft:white_concrete
fill 526 236 317 526 243 317 minecraft:brown_terracotta
fill 527 236 277 527 237 277 minecraft:white_concrete
fill 527 236 279 527 237 279 minecraft:white_concrete
fill 528 236 275 528 243 275 minecraft:brown_terracotta
fill 528 236 276 528 237 276 minecraft:white_concrete
fill 528 236 278 528 237 278 minecraft:white_concrete
fill 528 236 280 528 237 280 minecraft:white_concrete
fill 528 236 317 528 243 317 minecraft:brown_terracotta
setblock 529 236 275 minecraft:white_concrete
fill 529 236 277 534 237 277 minecraft:iron_block
setblock 529 236 317 minecraft:white_concrete
fill 530 236 275 530 243 275 minecraft:brown_terracotta
fill 530 236 317 530 243 317 minecraft:brown_terracotta
fill 532 236 275 532 243 275 minecraft:brown_terracotta
fill 532 236 283 532 238 284 minecraft:brown_terracotta
fill 532 236 317 532 243 317 minecraft:brown_terracotta
setblock 533 236 275 minecraft:white_concrete
fill 533 236 282 533 238 282 minecraft:brown_terracotta
fill 533 236 285 533 238 285 minecraft:brown_terracotta
setblock 533 236 317 minecraft:white_concrete
fill 534 236 275 534 243 275 minecraft:brown_terracotta
fill 534 236 317 534 243 317 minecraft:brown_terracotta
fill 535 236 282 535 238 282 minecraft:brown_terracotta
fill 535 236 285 535 238 285 minecraft:brown_terracotta
fill 536 236 275 536 243 275 minecraft:brown_terracotta
fill 536 236 283 536 238 284 minecraft:brown_terracotta
fill 536 236 317 536 243 317 minecraft:brown_terracotta
setblock 537 236 275 minecraft:white_concrete
setblock 537 236 317 minecraft:white_concrete
fill 538 236 275 538 243 275 minecraft:brown_terracotta
fill 538 236 317 538 243 317 minecraft:brown_terracotta
fill 540 236 275 540 243 275 minecraft:brown_terracotta
fill 540 236 317 540 243 317 minecraft:brown_terracotta
setblock 541 236 275 minecraft:white_concrete
setblock 541 236 317 minecraft:white_concrete
fill 542 236 275 542 243 275 minecraft:brown_terracotta
fill 542 236 317 542 243 317 minecraft:brown_terracotta
fill 544 236 275 544 243 275 minecraft:brown_terracotta
fill 544 236 317 544 243 317 minecraft:brown_terracotta
setblock 545 236 275 minecraft:white_concrete
setblock 545 236 317 minecraft:white_concrete
fill 546 236 275 546 243 275 minecraft:brown_terracotta
fill 546 236 317 546 243 317 minecraft:brown_terracotta
fill 548 236 275 548 243 275 minecraft:brown_terracotta
fill 548 236 317 548 243 317 minecraft:brown_terracotta
setblock 549 236 275 minecraft:white_concrete
setblock 549 236 317 minecraft:white_concrete
fill 550 236 275 550 243 275 minecraft:brown_terracotta
fill 550 236 317 550 243 317 minecraft:brown_terracotta
fill 552 236 275 552 243 275 minecraft:brown_terracotta
fill 552 236 317 552 243 317 minecraft:brown_terracotta
setblock 553 236 275 minecraft:white_concrete
setblock 553 236 317 minecraft:white_concrete
fill 554 236 275 554 243 275 minecraft:brown_terracotta
fill 554 236 312 554 238 312 minecraft:white_concrete
fill 554 236 317 554 243 317 minecraft:brown_terracotta
fill 555 236 311 555 237 311 minecraft:white_concrete
fill 555 236 313 555 237 313 minecraft:white_concrete
fill 556 236 275 556 243 275 minecraft:brown_terracotta
fill 556 236 317 556 243 317 minecraft:brown_terracotta
setblock 557 236 275 minecraft:white_concrete
setblock 557 236 312 minecraft:white_concrete
setblock 557 236 317 minecraft:white_concrete
fill 558 236 275 558 243 275 minecraft:brown_terracotta
setblock 558 236 312 minecraft:red_concrete
fill 558 236 317 558 243 317 minecraft:brown_terracotta
setblock 559 236 275 minecraft:white_concrete
fill 559 236 276 559 243 276 minecraft:brown_terracotta
fill 559 236 278 559 243 278 minecraft:brown_terracotta
setblock 559 236 279 minecraft:white_concrete
fill 559 236 280 559 243 280 minecraft:brown_terracotta
fill 559 236 282 559 243 282 minecraft:brown_terracotta
setblock 559 236 283 minecraft:white_concrete
fill 559 236 284 559 243 284 minecraft:brown_terracotta
fill 559 236 286 559 243 286 minecraft:brown_terracotta
setblock 559 236 287 minecraft:white_concrete
fill 559 236 288 559 243 288 minecraft:brown_terracotta
fill 559 236 290 559 243 290 minecraft:brown_terracotta
setblock 559 236 291 minecraft:white_concrete
fill 559 236 292 559 243 292 minecraft:brown_terracotta
fill 559 236 294 559 243 294 minecraft:brown_terracotta
setblock 559 236 295 minecraft:white_concrete
fill 559 236 296 559 243 296 minecraft:brown_terracotta
fill 559 236 298 559 243 298 minecraft:brown_terracotta
setblock 559 236 299 minecraft:white_concrete
fill 559 236 300 559 243 300 minecraft:brown_terracotta
fill 559 236 302 559 243 302 minecraft:brown_terracotta
setblock 559 236 303 minecraft:white_concrete
fill 559 236 304 559 243 304 minecraft:brown_terracotta
fill 559 236 306 559 243 306 minecraft:brown_terracotta
setblock 559 236 307 minecraft:white_concrete
fill 559 236 308 559 243 308 minecraft:brown_terracotta
fill 559 236 310 559 243 310 minecraft:brown_terracotta
setblock 559 236 311 minecraft:white_concrete
fill 559 236 312 559 243 312 minecraft:brown_terracotta
fill 559 236 314 559 243 314 minecraft:brown_terracotta
setblock 559 236 315 minecraft:white_concrete
fill 559 236 316 559 243 316 minecraft:brown_terracotta
fill 517 237 275 517 244 275 minecraft:brown_terracotta
fill 517 237 279 517 244 279 minecraft:brown_terracotta
fill 517 237 283 517 244 283 minecraft:brown_terracotta
fill 517 237 287 517 244 287 minecraft:brown_terracotta
fill 517 237 291 517 244 291 minecraft:brown_terracotta
fill 517 237 295 517 244 295 minecraft:brown_terracotta
fill 517 237 299 517 244 299 minecraft:brown_terracotta
fill 517 237 303 517 244 303 minecraft:brown_terracotta
fill 517 237 307 517 244 307 minecraft:brown_terracotta
fill 517 237 311 517 244 311 minecraft:brown_terracotta
fill 517 237 315 517 244 315 minecraft:brown_terracotta
fill 517 237 317 517 242 317 minecraft:brown_terracotta
setblock 519 237 312 minecraft:white_concrete
setblock 520 237 278 minecraft:light[level=12]
setblock 520 237 292 minecraft:light[level=12]
setblock 520 237 299 minecraft:light[level=12]
setblock 520 237 306 minecraft:light[level=12]
fill 520 237 313 522 237 313 minecraft:white_concrete
fill 521 237 275 521 244 275 minecraft:brown_terracotta
fill 521 237 299 533 238 300 minecraft:iron_block
fill 521 237 311 522 238 311 minecraft:white_concrete
fill 521 237 317 521 244 317 minecraft:brown_terracotta
fill 522 237 312 522 239 312 minecraft:white_concrete
fill 525 237 275 525 244 275 minecraft:brown_terracotta
fill 525 237 317 525 244 317 minecraft:brown_terracotta
setblock 527 237 285 minecraft:light[level=12]
setblock 527 237 292 minecraft:light[level=12]
fill 527 237 298 527 238 298 minecraft:lime_concrete
setblock 527 237 306 minecraft:light[level=12]
setblock 527 237 313 minecraft:light[level=12]
fill 529 237 275 529 244 275 minecraft:brown_terracotta
fill 529 237 317 529 244 317 minecraft:brown_terracotta
fill 532 237 282 532 238 282 minecraft:brown_terracotta
fill 532 237 285 532 238 285 minecraft:brown_terracotta
fill 533 237 275 533 244 275 minecraft:brown_terracotta
fill 533 237 317 533 244 317 minecraft:brown_terracotta
setblock 534 237 278 minecraft:light[level=12]
fill 534 237 286 534 238 286 minecraft:brown_terracotta
setblock 534 237 292 minecraft:light[level=12]
fill 534 237 299 547 238 299 minecraft:iron_block
setblock 534 237 306 minecraft:light[level=12]
setblock 534 237 313 minecraft:light[level=12]
fill 536 237 285 536 238 285 minecraft:brown_terracotta
fill 536 237 300 547 237 300 minecraft:iron_block
fill 537 237 275 537 244 275 minecraft:brown_terracotta
fill 537 237 317 537 244 317 minecraft:brown_terracotta
fill 541 237 275 541 244 275 minecraft:brown_terracotta
setblock 541 237 278 minecraft:light[level=12]
setblock 541 237 285 minecraft:light[level=12]
setblock 541 237 292 minecraft:light[level=12]
setblock 541 237 306 minecraft:light[level=12]
setblock 541 237 313 minecraft:light[level=12]
fill 541 237 317 541 244 317 minecraft:brown_terracotta
fill 545 237 275 545 244 275 minecraft:brown_terracotta
fill 545 237 317 545 244 317 minecraft:brown_terracotta
setblock 548 237 278 minecraft:light[level=12]
setblock 548 237 285 minecraft:light[level=12]
setblock 548 237 292 minecraft:light[level=12]
setblock 548 237 299 minecraft:light[level=12]
setblock 548 237 306 minecraft:light[level=12]
setblock 548 237 313 minecraft:light[level=12]
fill 549 237 275 549 244 275 minecraft:brown_terracotta
fill 549 237 317 549 244 317 minecraft:brown_terracotta
fill 553 237 275 553 244 275 minecraft:brown_terracotta
fill 553 237 311 553 238 313 minecraft:white_concrete
fill 553 237 317 553 244 317 minecraft:brown_terracotta
fill 554 237 311 554 238 311 minecraft:white_concrete
fill 554 237 313 554 238 313 minecraft:white_concrete
setblock 555 237 278 minecraft:light[level=12]
setblock 555 237 285 minecraft:light[level=12]
setblock 555 237 292 minecraft:light[level=12]
setblock 555 237 299 minecraft:light[level=12]
setblock 555 237 306 minecraft:light[level=12]
fill 557 237 275 557 244 275 minecraft:brown_terracotta
setblock 557 237 312 minecraft:red_concrete
fill 557 237 317 557 244 317 minecraft:brown_terracotta
fill 559 237 275 559 242 275 minecraft:brown_terracotta
fill 559 237 279 559 244 279 minecraft:brown_terracotta
fill 559 237 283 559 244 283 minecraft:brown_terracotta
fill 559 237 287 559 244 287 minecraft:brown_terracotta
fill 559 237 291 559 244 291 minecraft:brown_terracotta
fill 559 237 295 559 244 295 minecraft:brown_terracotta
fill 559 237 299 559 244 299 minecraft:brown_terracotta
fill 559 237 303 559 244 303 minecraft:brown_terracotta
fill 559 237 307 559 244 307 minecraft:brown_terracotta
fill 559 237 311 559 244 311 minecraft:brown_terracotta
fill 559 237 315 559 244 315 minecraft:brown_terracotta
setblock 518 238 282 minecraft:shroomlight
setblock 518 238 284 minecraft:shroomlight
setblock 518 238 286 minecraft:shroomlight
setblock 518 238 288 minecraft:shroomlight
setblock 518 238 290 minecraft:shroomlight
setblock 519 238 281 minecraft:shroomlight
setblock 519 238 283 minecraft:shroomlight
setblock 519 238 285 minecraft:shroomlight
setblock 519 238 287 minecraft:shroomlight
setblock 519 238 289 minecraft:shroomlight
setblock 519 238 291 minecraft:shroomlight
fill 519 238 292 519 239 292 minecraft:iron_block
setblock 519 238 312 minecraft:red_concrete
setblock 520 238 282 minecraft:shroomlight
setblock 520 238 284 minecraft:shroomlight
setblock 520 238 286 minecraft:shroomlight
setblock 520 238 288 minecraft:shroomlight
setblock 520 238 290 minecraft:shroomlight
setblock 521 238 281 minecraft:shroomlight
setblock 521 238 283 minecraft:shroomlight
setblock 521 238 285 minecraft:shroomlight
setblock 521 238 287 minecraft:shroomlight
setblock 521 238 289 minecraft:shroomlight
setblock 521 238 291 minecraft:shroomlight
fill 521 238 313 523 238 313 minecraft:white_concrete
setblock 522 238 276 minecraft:shroomlight
setblock 522 238 278 minecraft:shroomlight
setblock 522 238 280 minecraft:shroomlight
setblock 522 238 282 minecraft:shroomlight
setblock 522 238 284 minecraft:shroomlight
setblock 522 238 286 minecraft:shroomlight
setblock 522 238 288 minecraft:shroomlight
setblock 522 238 290 minecraft:shroomlight
setblock 523 238 277 minecraft:shroomlight
setblock 523 238 279 minecraft:shroomlight
setblock 523 238 281 minecraft:shroomlight
setblock 523 238 283 minecraft:shroomlight
setblock 523 238 285 minecraft:shroomlight
setblock 523 238 287 minecraft:shroomlight
setblock 523 238 289 minecraft:shroomlight
setblock 523 238 291 minecraft:shroomlight
fill 523 238 311 523 239 312 minecraft:white_concrete
setblock 524 238 276 minecraft:shroomlight
setblock 524 238 278 minecraft:shroomlight
setblock 524 238 280 minecraft:shroomlight
fill 524 238 312 524 240 312 minecraft:white_concrete
setblock 525 238 277 minecraft:shroomlight
setblock 525 238 279 minecraft:shroomlight
setblock 526 238 276 minecraft:shroomlight
setblock 526 238 278 minecraft:shroomlight
setblock 526 238 280 minecraft:shroomlight
setblock 527 238 277 minecraft:shroomlight
setblock 527 238 279 minecraft:shroomlight
setblock 528 238 276 minecraft:shroomlight
setblock 528 238 278 minecraft:shroomlight
setblock 528 238 280 minecraft:shroomlight
setblock 531 238 284 minecraft:brown_terracotta
fill 533 238 281 535 238 281 minecraft:brown_terracotta
setblock 533 238 286 minecraft:brown_terracotta
setblock 535 238 286 minecraft:brown_terracotta
setblock 536 238 282 minecraft:brown_terracotta
fill 537 238 300 547 238 300 minecraft:iron_block
fill 551 238 312 552 240 312 minecraft:white_concrete
fill 552 238 311 552 239 311 minecraft:white_concrete
fill 552 238 313 552 239 313 minecraft:white_concrete
setblock 555 238 312 minecraft:white_concrete
setblock 556 238 312 minecraft:red_concrete
fill 518 239 282 518 240 282 minecraft:white_concrete
fill 518 239 284 518 240 284 minecraft:white_concrete
fill 518 239 286 518 240 286 minecraft:white_concrete
fill 518 239 288 518 240 288 minecraft:white_concrete
fill 518 239 290 518 240 290 minecraft:white_concrete
fill 519 239 281 519 240 281 minecraft:white_concrete
fill 519 239 283 519 240 283 minecraft:white_concrete
fill 519 239 285 519 240 285 minecraft:white_concrete
fill 519 239 287 519 240 287 minecraft:white_concrete
fill 519 239 289 519 240 289 minecraft:white_concrete
fill 519 239 291 519 240 291 minecraft:white_concrete
fill 520 239 282 520 240 282 minecraft:white_concrete
fill 520 239 284 520 240 284 minecraft:white_concrete
fill 520 239 286 520 240 286 minecraft:white_concrete
fill 520 239 288 520 240 288 minecraft:white_concrete
fill 520 239 290 520 240 290 minecraft:white_concrete
fill 521 239 281 521 240 281 minecraft:white_concrete
fill 521 239 283 521 240 283 minecraft:white_concrete
fill 521 239 285 521 240 285 minecraft:white_concrete
fill 521 239 287 521 240 287 minecraft:white_concrete
fill 521 239 289 521 240 289 minecraft:white_concrete
fill 521 239 291 521 240 291 minecraft:white_concrete
setblock 521 239 312 minecraft:red_concrete
fill 522 239 276 522 240 276 minecraft:white_concrete
fill 522 239 278 522 240 278 minecraft:white_concrete
fill 522 239 280 522 240 280 minecraft:white_concrete
fill 522 239 282 522 240 282 minecraft:white_concrete
fill 522 239 284 522 240 284 minecraft:white_concrete
fill 522 239 286 522 240 286 minecraft:white_concrete
fill 522 239 288 522 240 288 minecraft:white_concrete
fill 522 239 290 522 240 290 minecraft:white_concrete
fill 523 239 277 523 240 277 minecraft:white_concrete
fill 523 239 279 523 240 279 minecraft:white_concrete
fill 523 239 281 523 240 281 minecraft:white_concrete
fill 523 239 283 523 240 283 minecraft:white_concrete
fill 523 239 285 523 240 285 minecraft:white_concrete
fill 523 239 287 523 240 287 minecraft:white_concrete
fill 523 239 289 523 240 289 minecraft:white_concrete
fill 523 239 291 523 240 291 minecraft:white_concrete
fill 523 239 313 524 239 313 minecraft:white_concrete
fill 524 239 276 524 240 276 minecraft:white_concrete
fill 524 239 278 524 240 278 minecraft:white_concrete
fill 524 239 280 524 240 280 minecraft:white_concrete
fill 524 239 311 524 240 311 minecraft:white_concrete
fill 525 239 277 525 240 277 minecraft:white_concrete
fill 525 239 279 525 240 279 minecraft:white_concrete
fill 525 239 312 525 241 312 minecraft:white_concrete
fill 526 239 276 526 240 276 minecraft:white_concrete
fill 526 239 278 526 240 278 minecraft:white_concrete
fill 526 239 280 526 240 280 minecraft:white_concrete
fill 527 239 277 527 240 277 minecraft:white_concrete
fill 527 239 279 527 240 279 minecraft:white_concrete
fill 528 239 276 528 240 276 minecraft:white_concrete
fill 528 239 278 528 240 278 minecraft:white_concrete
fill 528 239 280 528 240 280 minecraft:white_concrete
fill 534 239 283 534 241 284 minecraft:white_concrete
fill 550 239 312 550 241 312 minecraft:white_concrete
fill 551 239 311 551 240 311 minecraft:white_concrete
fill 551 239 313 551 240 313 minecraft:white_concrete
setblock 553 239 312 minecraft:white_concrete
setblock 554 239 312 minecraft:red_concrete
fill 519 240 297 519 245 299 minecraft:white_concrete
fill 519 240 309 519 245 311 minecraft:white_concrete
setblock 522 240 312 minecraft:red_concrete
setblock 523 240 312 minecraft:white_concrete
fill 524 240 313 526 240 313 minecraft:white_concrete
fill 525 240 311 526 240 311 minecraft:white_concrete
fill 525 240 315 527 245 315 minecraft:white_concrete
fill 526 240 312 527 242 312 minecraft:white_concrete
fill 529 240 277 531 245 277 minecraft:white_concrete
fill 531 240 291 532 241 291 minecraft:lime_concrete
fill 534 240 288 535 241 288 minecraft:white_concrete
fill 537 240 315 539 242 315 minecraft:white_concrete
fill 541 240 277 543 245 277 minecraft:white_concrete
fill 548 240 312 549 242 312 minecraft:white_concrete
fill 549 240 311 550 240 311 minecraft:white_concrete
fill 549 240 313 550 240 313 minecraft:white_concrete
fill 549 240 315 551 245 315 minecraft:white_concrete
fill 553 240 277 555 245 277 minecraft:white_concrete
setblock 553 240 312 minecraft:red_concrete
fill 557 240 285 557 245 287 minecraft:white_concrete
fill 557 240 297 557 245 299 minecraft:white_concrete
fill 557 240 309 557 245 311 minecraft:white_concrete
setblock 518 241 282 minecraft:shroomlight
setblock 518 241 284 minecraft:shroomlight
setblock 518 241 286 minecraft:shroomlight
setblock 518 241 288 minecraft:shroomlight
setblock 518 241 290 minecraft:shroomlight
setblock 519 241 281 minecraft:shroomlight
setblock 519 241 283 minecraft:shroomlight
setblock 519 241 285 minecraft:shroomlight
setblock 519 241 287 minecraft:shroomlight
setblock 519 241 289 minecraft:shroomlight
setblock 519 241 291 minecraft:shroomlight
setblock 520 241 282 minecraft:shroomlight
setblock 520 241 284 minecraft:shroomlight
setblock 520 241 286 minecraft:shroomlight
setblock 520 241 288 minecraft:shroomlight
setblock 520 241 290 minecraft:shroomlight
setblock 521 241 281 minecraft:shroomlight
setblock 521 241 283 minecraft:shroomlight
setblock 521 241 285 minecraft:shroomlight
setblock 521 241 287 minecraft:shroomlight
setblock 521 241 289 minecraft:shroomlight
setblock 521 241 291 minecraft:shroomlight
setblock 522 241 276 minecraft:shroomlight
setblock 522 241 278 minecraft:shroomlight
setblock 522 241 280 minecraft:shroomlight
setblock 522 241 282 minecraft:shroomlight
setblock 522 241 284 minecraft:shroomlight
setblock 522 241 286 minecraft:shroomlight
setblock 522 241 288 minecraft:shroomlight
setblock 522 241 290 minecraft:shroomlight
setblock 523 241 277 minecraft:shroomlight
setblock 523 241 279 minecraft:shroomlight
setblock 523 241 281 minecraft:shroomlight
setblock 523 241 283 minecraft:shroomlight
setblock 523 241 285 minecraft:shroomlight
setblock 523 241 287 minecraft:shroomlight
setblock 523 241 289 minecraft:shroomlight
setblock 523 241 291 minecraft:shroomlight
setblock 524 241 276 minecraft:shroomlight
setblock 524 241 278 minecraft:shroomlight
setblock 524 241 280 minecraft:shroomlight
setblock 524 241 312 minecraft:red_concrete
setblock 525 241 277 minecraft:shroomlight
setblock 525 241 279 minecraft:shroomlight
setblock 526 241 276 minecraft:shroomlight
setblock 526 241 278 minecraft:shroomlight
setblock 526 241 280 minecraft:shroomlight
fill 526 241 311 528 241 311 minecraft:white_concrete
fill 526 241 313 528 241 313 minecraft:white_concrete
setblock 527 241 277 minecraft:shroomlight
setblock 527 241 279 minecraft:shroomlight
setblock 528 241 276 minecraft:shroomlight
setblock 528 241 278 minecraft:shroomlight
setblock 528 241 280 minecraft:shroomlight
fill 528 241 312 529 243 312 minecraft:white_concrete
fill 546 241 312 547 243 312 minecraft:white_concrete
fill 547 241 311 549 241 311 minecraft:white_concrete
fill 547 241 313 549 241 313 minecraft:white_concrete
setblock 551 241 312 minecraft:red_concrete
fill 518 242 282 518 244 282 minecraft:white_concrete
fill 518 242 284 518 244 284 minecraft:white_concrete
fill 518 242 286 518 271 286 minecraft:white_concrete
fill 518 242 288 518 271 288 minecraft:white_concrete
fill 518 242 290 518 244 290 minecraft:white_concrete
fill 519 242 281 519 244 281 minecraft:white_concrete
fill 519 242 283 519 244 283 minecraft:white_concrete
fill 519 242 285 519 245 285 minecraft:white_concrete
fill 519 242 287 519 245 287 minecraft:white_concrete
fill 519 242 289 519 244 289 minecraft:white_concrete
fill 519 242 291 519 244 291 minecraft:white_concrete
fill 520 242 282 520 244 282 minecraft:white_concrete
fill 520 242 284 520 244 284 minecraft:white_concrete
fill 520 242 286 520 244 286 minecraft:white_concrete
fill 520 242 288 520 244 288 minecraft:white_concrete
fill 520 242 290 520 244 290 minecraft:white_concrete
fill 521 242 281 521 244 281 minecraft:white_concrete
fill 521 242 283 521 244 283 minecraft:white_concrete
fill 521 242 285 521 244 285 minecraft:white_concrete
fill 521 242 287 521 244 287 minecraft:white_concrete
fill 521 242 289 521 244 289 minecraft:white_concrete
fill 521 242 291 521 244 291 minecraft:white_concrete
setblock 522 242 276 minecraft:white_concrete
setblock 522 242 278 minecraft:white_concrete
setblock 522 242 280 minecraft:white_concrete
fill 522 242 282 522 244 282 minecraft:white_concrete
fill 522 242 284 522 244 284 minecraft:white_concrete
fill 522 242 286 522 244 286 minecraft:white_concrete
fill 522 242 288 522 244 288 minecraft:white_concrete
fill 522 242 290 522 244 290 minecraft:white_concrete
setblock 523 242 277 minecraft:white_concrete
setblock 523 242 279 minecraft:white_concrete
fill 523 242 281 523 244 281 minecraft:white_concrete
fill 523 242 283 523 244 283 minecraft:white_concrete
fill 523 242 285 523 244 285 minecraft:white_concrete
fill 523 242 287 523 244 287 minecraft:white_concrete
fill 523 242 289 523 244 289 minecraft:white_concrete
fill 523 242 291 523 244 291 minecraft:white_concrete
setblock 524 242 276 minecraft:white_concrete
setblock 524 242 278 minecraft:white_concrete
setblock 524 242 280 minecraft:white_concrete
setblock 525 242 277 minecraft:white_concrete
setblock 525 242 279 minecraft:white_concrete
setblock 525 242 312 minecraft:red_concrete
setblock 526 242 276 minecraft:white_concrete
setblock 526 242 278 minecraft:white_concrete
setblock 526 242 280 minecraft:white_concrete
setblock 527 242 277 minecraft:white_concrete
setblock 527 242 279 minecraft:white_concrete
fill 527 242 311 530 242 311 minecraft:white_concrete
fill 527 242 313 530 242 313 minecraft:white_concrete
setblock 528 242 276 minecraft:white_concrete
setblock 528 242 278 minecraft:white_concrete
setblock 528 242 280 minecraft:white_concrete
fill 530 242 312 531 244 312 minecraft:white_concrete
fill 533 242 282 535 244 285 minecraft:spruce_leaves[persistent=true]
fill 544 242 312 545 244 312 minecraft:white_concrete
fill 545 242 311 548 242 311 minecraft:white_concrete
fill 545 242 313 548 242 313 minecraft:white_concrete
setblock 550 242 312 minecraft:red_concrete
setblock 517 243 277 minecraft:white_concrete
setblock 517 243 281 minecraft:white_concrete
setblock 517 243 285 minecraft:white_concrete
setblock 517 243 289 minecraft:white_concrete
setblock 517 243 293 minecraft:white_concrete
setblock 517 243 297 minecraft:white_concrete
setblock 517 243 301 minecraft:white_concrete
setblock 517 243 305 minecraft:white_concrete
setblock 517 243 309 minecraft:white_concrete
setblock 517 243 313 minecraft:white_concrete
setblock 517 243 317 minecraft:white_concrete
setblock 519 243 275 minecraft:white_concrete
setblock 519 243 317 minecraft:white_concrete
setblock 520 243 278 minecraft:light[level=15]
setblock 520 243 292 minecraft:light[level=12]
setblock 520 243 294 minecraft:light[level=15]
setblock 520 243 299 minecraft:light[level=12]
setblock 520 243 302 minecraft:light[level=15]
setblock 520 243 306 minecraft:light[level=12]
setblock 520 243 310 minecraft:light[level=15]
setblock 520 243 313 minecraft:light[level=12]
setblock 523 243 275 minecraft:white_concrete
fill 523 243 277 527 243 279 minecraft:red_concrete
setblock 523 243 317 minecraft:white_concrete
setblock 527 243 275 minecraft:white_concrete
setblock 527 243 285 minecraft:light[level=12]
setblock 527 243 292 minecraft:light[level=12]
setblock 527 243 299 minecraft:light[level=12]
setblock 527 243 306 minecraft:light[level=12]
setblock 527 243 312 minecraft:red_concrete
setblock 527 243 313 minecraft:light[level=12]
setblock 527 243 317 minecraft:white_concrete
setblock 528 243 278 minecraft:light[level=15]
setblock 528 243 286 minecraft:light[level=15]
setblock 528 243 294 minecraft:light[level=15]
setblock 528 243 302 minecraft:light[level=15]
setblock 528 243 310 minecraft:light[level=15]
fill 529 243 311 532 243 311 minecraft:white_concrete
fill 529 243 313 532 243 313 minecraft:white_concrete
setblock 531 243 275 minecraft:white_concrete
setblock 531 243 317 minecraft:white_concrete
fill 532 243 283 532 243 284 minecraft:spruce_leaves[persistent=true]
fill 532 243 312 532 244 312 minecraft:white_concrete
fill 533 243 312 537 243 316 minecraft:orange_terracotta
setblock 534 243 278 minecraft:light[level=12]
setblock 534 243 292 minecraft:light[level=12]
setblock 534 243 299 minecraft:light[level=12]
setblock 534 243 306 minecraft:light[level=12]
setblock 535 243 275 minecraft:white_concrete
setblock 535 243 317 minecraft:white_concrete
setblock 536 243 278 minecraft:light[level=15]
fill 536 243 283 536 243 284 minecraft:spruce_leaves[persistent=true]
setblock 536 243 286 minecraft:light[level=15]
setblock 536 243 294 minecraft:light[level=15]
setblock 536 243 302 minecraft:light[level=15]
setblock 536 243 310 minecraft:light[level=15]
fill 538 243 315 538 245 316 minecraft:white_concrete
setblock 539 243 275 minecraft:white_concrete
fill 539 243 315 539 245 315 minecraft:white_concrete
setblock 539 243 317 minecraft:white_concrete
fill 540 243 312 543 244 312 minecraft:white_concrete
setblock 541 243 278 minecraft:light[level=12]
setblock 541 243 285 minecraft:light[level=12]
setblock 541 243 292 minecraft:light[level=12]
setblock 541 243 299 minecraft:light[level=12]
setblock 541 243 306 minecraft:light[level=12]
setblock 541 243 313 minecraft:light[level=12]
setblock 543 243 275 minecraft:white_concrete
fill 543 243 311 546 243 311 minecraft:white_concrete
fill 543 243 313 546 243 313 minecraft:white_concrete
setblock 543 243 317 minecraft:white_concrete
setblock 544 243 278 minecraft:light[level=15]
setblock 544 243 286 minecraft:light[level=15]
setblock 544 243 294 minecraft:light[level=15]
setblock 544 243 302 minecraft:light[level=15]
setblock 544 243 310 minecraft:light[level=15]
setblock 547 243 275 minecraft:white_concrete
setblock 547 243 317 minecraft:white_concrete
setblock 548 243 278 minecraft:light[level=12]
setblock 548 243 285 minecraft:light[level=12]
setblock 548 243 292 minecraft:light[level=12]
setblock 548 243 299 minecraft:light[level=12]
setblock 548 243 306 minecraft:light[level=12]
setblock 548 243 312 minecraft:red_concrete
setblock 548 243 313 minecraft:light[level=12]
setblock 551 243 275 minecraft:white_concrete
setblock 551 243 317 minecraft:white_concrete
setblock 552 243 278 minecraft:light[level=15]
setblock 552 243 286 minecraft:light[level=15]
setblock 552 243 294 minecraft:light[level=15]
setblock 552 243 302 minecraft:light[level=15]
setblock 552 243 310 minecraft:light[level=15]
setblock 555 243 275 minecraft:white_concrete
setblock 555 243 278 minecraft:light[level=12]
setblock 555 243 285 minecraft:light[level=12]
setblock 555 243 292 minecraft:light[level=12]
setblock 555 243 299 minecraft:light[level=12]
setblock 555 243 306 minecraft:light[level=12]
setblock 555 243 313 minecraft:light[level=12]
setblock 555 243 317 minecraft:white_concrete
setblock 559 243 275 minecraft:white_concrete
setblock 559 243 277 minecraft:white_concrete
setblock 559 243 281 minecraft:white_concrete
setblock 559 243 285 minecraft:white_concrete
setblock 559 243 289 minecraft:white_concrete
setblock 559 243 293 minecraft:white_concrete
setblock 559 243 297 minecraft:white_concrete
setblock 559 243 301 minecraft:white_concrete
setblock 559 243 305 minecraft:white_concrete
setblock 559 243 309 minecraft:white_concrete
setblock 559 243 313 minecraft:white_concrete
setblock 559 243 317 minecraft:white_concrete
setblock 517 244 276 minecraft:white_concrete
fill 517 244 277 517 251 277 minecraft:brown_terracotta
setblock 517 244 278 minecraft:white_concrete
setblock 517 244 280 minecraft:white_concrete
fill 517 244 281 517 245 281 minecraft:brown_terracotta
setblock 517 244 282 minecraft:white_concrete
setblock 517 244 284 minecraft:white_concrete
fill 517 244 285 517 251 285 minecraft:brown_terracotta
setblock 517 244 286 minecraft:white_concrete
setblock 517 244 288 minecraft:white_concrete
fill 517 244 289 517 251 289 minecraft:brown_terracotta
setblock 517 244 290 minecraft:white_concrete
setblock 517 244 292 minecraft:white_concrete
fill 517 244 293 517 245 293 minecraft:brown_terracotta
setblock 517 244 294 minecraft:white_concrete
setblock 517 244 296 minecraft:white_concrete
fill 517 244 297 517 251 297 minecraft:brown_terracotta
setblock 517 244 298 minecraft:white_concrete
setblock 517 244 300 minecraft:white_concrete
fill 517 244 301 517 251 301 minecraft:brown_terracotta
setblock 517 244 302 minecraft:white_concrete
setblock 517 244 304 minecraft:white_concrete
fill 517 244 305 517 245 305 minecraft:brown_terracotta
setblock 517 244 306 minecraft:white_concrete
setblock 517 244 308 minecraft:white_concrete
fill 517 244 309 517 251 309 minecraft:brown_terracotta
setblock 517 244 310 minecraft:white_concrete
setblock 517 244 312 minecraft:white_concrete
fill 517 244 313 517 251 313 minecraft:brown_terracotta
setblock 517 244 314 minecraft:white_concrete
setblock 517 244 316 minecraft:white_concrete
setblock 517 244 317 minecraft:brown_terracotta
setblock 518 244 275 minecraft:white_concrete
setblock 518 244 317 minecraft:white_concrete
fill 519 244 275 519 251 275 minecraft:brown_terracotta
fill 519 244 317 519 245 317 minecraft:brown_terracotta
setblock 520 244 275 minecraft:white_concrete
setblock 520 244 317 minecraft:white_concrete
setblock 522 244 275 minecraft:white_concrete
setblock 522 244 317 minecraft:white_concrete
fill 523 244 275 523 251 275 minecraft:brown_terracotta
fill 523 244 317 523 251 317 minecraft:brown_terracotta
setblock 524 244 275 minecraft:white_concrete
fill 524 244 278 526 244 278 minecraft:red_concrete
setblock 524 244 317 minecraft:white_concrete
setblock 526 244 275 minecraft:white_concrete
setblock 526 244 317 minecraft:white_concrete
fill 527 244 275 527 245 275 minecraft:brown_terracotta
fill 527 244 317 527 251 317 minecraft:brown_terracotta
setblock 528 244 275 minecraft:white_concrete
fill 528 244 312 529 244 312 minecraft:red_concrete
setblock 528 244 317 minecraft:white_concrete
setblock 530 244 275 minecraft:white_concrete
setblock 530 244 317 minecraft:white_concrete
fill 531 244 275 531 251 275 minecraft:brown_terracotta
fill 531 244 317 531 245 317 minecraft:brown_terracotta
setblock 532 244 275 minecraft:white_concrete
fill 532 244 311 543 244 311 minecraft:white_concrete
setblock 532 244 313 minecraft:white_concrete
setblock 532 244 317 minecraft:white_concrete
fill 533 244 312 534 247 316 minecraft:orange_terracotta
setblock 534 244 275 minecraft:white_concrete
setblock 534 244 317 minecraft:white_concrete
fill 535 244 275 535 251 275 minecraft:brown_terracotta
fill 535 244 312 537 247 313 minecraft:orange_terracotta
fill 535 244 314 535 245 314 minecraft:ochre_froglight
fill 535 244 315 537 247 316 minecraft:orange_terracotta
fill 535 244 317 535 251 317 minecraft:brown_terracotta
setblock 536 244 275 minecraft:white_concrete
fill 536 244 314 537 247 314 minecraft:orange_terracotta
setblock 536 244 317 minecraft:white_concrete
setblock 538 244 275 minecraft:white_concrete
fill 538 244 312 539 245 313 minecraft:white_concrete
setblock 538 244 317 minecraft:white_concrete
fill 539 244 275 539 245 275 minecraft:brown_terracotta
fill 539 244 317 539 251 317 minecraft:brown_terracotta
setblock 540 244 275 minecraft:white_concrete
fill 540 244 313 543 244 313 minecraft:white_concrete
setblock 540 244 317 minecraft:white_concrete
setblock 542 244 275 minecraft:white_concrete
setblock 542 244 317 minecraft:white_concrete
fill 543 244 275 543 251 275 minecraft:brown_terracotta
fill 543 244 317 543 245 317 minecraft:brown_terracotta
setblock 544 244 275 minecraft:white_concrete
setblock 544 244 317 minecraft:white_concrete
setblock 546 244 275 minecraft:white_concrete
fill 546 244 312 547 244 312 minecraft:red_concrete
setblock 546 244 317 minecraft:white_concrete
fill 547 244 275 547 251 275 minecraft:brown_terracotta
fill 547 244 317 547 251 317 minecraft:brown_terracotta
setblock 548 244 275 minecraft:white_concrete
setblock 548 244 317 minecraft:white_concrete
setblock 550 244 275 minecraft:white_concrete
setblock 550 244 317 minecraft:white_concrete
fill 551 244 275 551 245 275 minecraft:brown_terracotta
fill 551 244 317 551 251 317 minecraft:brown_terracotta
setblock 552 244 275 minecraft:white_concrete
setblock 552 244 317 minecraft:white_concrete
setblock 554 244 275 minecraft:white_concrete
setblock 554 244 317 minecraft:white_concrete
fill 555 244 275 555 251 275 minecraft:brown_terracotta
fill 555 244 317 555 245 317 minecraft:brown_terracotta
setblock 556 244 275 minecraft:white_concrete
setblock 556 244 317 minecraft:white_concrete
setblock 558 244 275 minecraft:white_concrete
setblock 558 244 317 minecraft:white_concrete
setblock 559 244 275 minecraft:brown_terracotta
setblock 559 244 276 minecraft:white_concrete
fill 559 244 277 559 245 277 minecraft:brown_terracotta
setblock 559 244 278 minecraft:white_concrete
setblock 559 244 280 minecraft:white_concrete
fill 559 244 281 559 251 281 minecraft:brown_terracotta
setblock 559 244 282 minecraft:white_concrete
setblock 559 244 284 minecraft:white_concrete
fill 559 244 285 559 251 285 minecraft:brown_terracotta
setblock 559 244 286 minecraft:white_concrete
setblock 559 244 288 minecraft:white_concrete
fill 559 244 289 559 245 289 minecraft:brown_terracotta
setblock 559 244 290 minecraft:white_concrete
setblock 559 244 292 minecraft:white_concrete
fill 559 244 293 559 251 293 minecraft:brown_terracotta
setblock 559 244 294 minecraft:white_concrete
setblock 559 244 296 minecraft:white_concrete
fill 559 244 297 559 251 297 minecraft:brown_terracotta
setblock 559 244 298 minecraft:white_concrete
setblock 559 244 300 minecraft:white_concrete
fill 559 244 301 559 245 301 minecraft:brown_terracotta
setblock 559 244 302 minecraft:white_concrete
setblock 559 244 304 minecraft:white_concrete
fill 559 244 305 559 251 305 minecraft:brown_terracotta
setblock 559 244 306 minecraft:white_concrete
setblock 559 244 308 minecraft:white_concrete
fill 559 244 309 559 251 309 minecraft:brown_terracotta
setblock 559 244 310 minecraft:white_concrete
setblock 559 244 312 minecraft:white_concrete
fill 559 244 313 559 245 313 minecraft:brown_terracotta
setblock 559 244 314 minecraft:white_concrete
setblock 559 244 316 minecraft:white_concrete
fill 559 244 317 559 251 317 minecraft:brown_terracotta
setblock 517 245 275 minecraft:white_concrete
fill 517 245 276 517 252 276 minecraft:brown_terracotta
fill 517 245 278 517 252 278 minecraft:brown_terracotta
setblock 517 245 279 minecraft:white_concrete
fill 517 245 280 518 245 280 minecraft:brown_terracotta
fill 517 245 282 518 245 282 minecraft:brown_terracotta
setblock 517 245 283 minecraft:white_concrete
fill 517 245 284 518 245 284 minecraft:brown_terracotta
fill 517 245 286 517 252 286 minecraft:brown_terracotta
setblock 517 245 287 minecraft:white_concrete
fill 517 245 288 517 252 288 minecraft:brown_terracotta
fill 517 245 290 517 252 290 minecraft:brown_terracotta
setblock 517 245 291 minecraft:white_concrete
fill 517 245 292 518 245 292 minecraft:brown_terracotta
fill 517 245 294 518 245 294 minecraft:brown_terracotta
setblock 517 245 295 minecraft:white_concrete
fill 517 245 296 518 245 296 minecraft:brown_terracotta
fill 517 245 298 517 252 298 minecraft:brown_terracotta
setblock 517 245 299 minecraft:white_concrete
fill 517 245 300 517 252 300 minecraft:brown_terracotta
fill 517 245 302 517 252 302 minecraft:brown_terracotta
setblock 517 245 303 minecraft:white_concrete
fill 517 245 304 518 245 304 minecraft:brown_terracotta
fill 517 245 306 518 245 306 minecraft:brown_terracotta
setblock 517 245 307 minecraft:white_concrete
fill 517 245 308 518 245 308 minecraft:brown_terracotta
fill 517 245 310 517 252 310 minecraft:brown_terracotta
setblock 517 245 311 minecraft:white_concrete
fill 517 245 312 517 252 312 minecraft:brown_terracotta
fill 517 245 314 517 252 314 minecraft:brown_terracotta
setblock 517 245 315 minecraft:white_concrete
fill 517 245 316 522 245 316 minecraft:brown_terracotta
setblock 517 245 317 minecraft:white_concrete
fill 518 245 275 518 252 275 minecraft:brown_terracotta
setblock 518 245 279 minecraft:brown_terracotta
setblock 518 245 281 minecraft:brown_terracotta
setblock 518 245 283 minecraft:brown_terracotta
setblock 518 245 291 minecraft:brown_terracotta
setblock 518 245 293 minecraft:brown_terracotta
setblock 518 245 295 minecraft:brown_terracotta
setblock 518 245 303 minecraft:brown_terracotta
setblock 518 245 305 minecraft:brown_terracotta
setblock 518 245 307 minecraft:brown_terracotta
setblock 518 245 315 minecraft:brown_terracotta
setblock 518 245 317 minecraft:brown_terracotta
fill 519 245 282 522 245 284 minecraft:red_concrete
fill 519 245 288 522 245 290 minecraft:red_concrete
fill 520 245 275 520 252 275 minecraft:brown_terracotta
fill 520 245 285 522 245 287 minecraft:red_concrete
setblock 520 245 317 minecraft:brown_terracotta
setblock 521 245 275 minecraft:white_concrete
setblock 521 245 317 minecraft:white_concrete
fill 522 245 275 522 245 276 minecraft:brown_terracotta
fill 522 245 317 522 252 317 minecraft:brown_terracotta
fill 523 245 276 527 245 276 minecraft:brown_terracotta
setblock 524 245 275 minecraft:brown_terracotta
fill 524 245 317 524 252 317 minecraft:brown_terracotta
setblock 525 245 275 minecraft:white_concrete
fill 525 245 277 525 246 279 minecraft:red_concrete
setblock 525 245 317 minecraft:white_concrete
setblock 526 245 275 minecraft:brown_terracotta
fill 526 245 317 526 252 317 minecraft:brown_terracotta
fill 528 245 275 528 252 275 minecraft:brown_terracotta
fill 528 245 317 528 252 317 minecraft:brown_terracotta
setblock 529 245 275 minecraft:white_concrete
fill 529 245 316 532 245 316 minecraft:brown_terracotta
setblock 529 245 317 minecraft:white_concrete
fill 530 245 275 530 252 275 minecraft:brown_terracotta
setblock 530 245 317 minecraft:brown_terracotta
fill 531 245 312 532 245 312 minecraft:red_concrete
fill 532 245 275 532 252 275 minecraft:brown_terracotta
setblock 532 245 317 minecraft:brown_terracotta
setblock 533 245 275 minecraft:white_concrete
setblock 533 245 317 minecraft:white_concrete
fill 534 245 275 534 245 276 minecraft:brown_terracotta
fill 534 245 317 534 252 317 minecraft:brown_terracotta
fill 535 245 276 539 245 276 minecraft:brown_terracotta
fill 535 245 311 540 245 311 minecraft:white_concrete
setblock 536 245 275 minecraft:brown_terracotta
fill 536 245 317 536 252 317 minecraft:brown_terracotta
setblock 537 245 275 minecraft:white_concrete
setblock 537 245 317 minecraft:white_concrete
setblock 538 245 275 minecraft:brown_terracotta
fill 538 245 317 538 252 317 minecraft:brown_terracotta
fill 540 245 275 540 252 275 minecraft:brown_terracotta
fill 540 245 312 540 245 313 minecraft:white_concrete
fill 540 245 317 540 252 317 minecraft:brown_terracotta
setblock 541 245 275 minecraft:white_concrete
fill 541 245 312 542 245 312 minecraft:white_concrete
fill 541 245 316 546 245 316 minecraft:brown_terracotta
setblock 541 245 317 minecraft:white_concrete
fill 542 245 275 542 252 275 minecraft:brown_terracotta
setblock 542 245 317 minecraft:brown_terracotta
fill 543 245 312 544 245 312 minecraft:red_concrete
fill 544 245 275 544 252 275 minecraft:brown_terracotta
setblock 544 245 317 minecraft:brown_terracotta
setblock 545 245 275 minecraft:white_concrete
setblock 545 245 317 minecraft:white_concrete
fill 546 245 275 546 245 276 minecraft:brown_terracotta
fill 546 245 317 546 252 317 minecraft:brown_terracotta
fill 547 245 276 551 245 276 minecraft:brown_terracotta
setblock 548 245 275 minecraft:brown_terracotta
fill 548 245 317 548 252 317 minecraft:brown_terracotta
setblock 549 245 275 minecraft:white_concrete
setblock 549 245 317 minecraft:white_concrete
setblock 550 245 275 minecraft:brown_terracotta
fill 550 245 317 550 252 317 minecraft:brown_terracotta
fill 552 245 275 552 252 275 minecraft:brown_terracotta
fill 552 245 317 552 252 317 minecraft:brown_terracotta
setblock 553 245 275 minecraft:white_concrete
fill 553 245 316 559 245 316 minecraft:brown_terracotta
setblock 553 245 317 minecraft:white_concrete
fill 554 245 275 554 252 275 minecraft:brown_terracotta
setblock 554 245 317 minecraft:brown_terracotta
fill 556 245 275 556 252 275 minecraft:brown_terracotta
setblock 556 245 317 minecraft:brown_terracotta
setblock 557 245 275 minecraft:white_concrete
setblock 557 245 317 minecraft:white_concrete
fill 558 245 275 558 245 281 minecraft:brown_terracotta
fill 558 245 288 558 245 293 minecraft:brown_terracotta
fill 558 245 300 558 245 305 minecraft:brown_terracotta
fill 558 245 312 558 245 315 minecraft:brown_terracotta
fill 558 245 317 558 252 317 minecraft:brown_terracotta
setblock 559 245 275 minecraft:white_concrete
setblock 559 245 276 minecraft:brown_terracotta
setblock 559 245 278 minecraft:brown_terracotta
setblock 559 245 279 minecraft:white_concrete
fill 559 245 280 559 252 280 minecraft:brown_terracotta
fill 559 245 282 559 252 282 minecraft:brown_terracotta
setblock 559 245 283 minecraft:white_concrete
fill 559 245 284 559 252 284 minecraft:brown_terracotta
fill 559 245 286 559 252 286 minecraft:brown_terracotta
setblock 559 245 287 minecraft:white_concrete
setblock 559 245 288 minecraft:brown_terracotta
setblock 559 245 290 minecraft:brown_terracotta
setblock 559 245 291 minecraft:white_concrete
fill 559 245 292 559 252 292 minecraft:brown_terracotta
fill 559 245 294 559 252 294 minecraft:brown_terracotta
setblock 559 245 295 minecraft:white_concrete
fill 559 245 296 559 252 296 minecraft:brown_terracotta
fill 559 245 298 559 252 298 minecraft:brown_terracotta
setblock 559 245 299 minecraft:white_concrete
setblock 559 245 300 minecraft:brown_terracotta
setblock 559 245 302 minecraft:brown_terracotta
setblock 559 245 303 minecraft:white_concrete
fill 559 245 304 559 252 304 minecraft:brown_terracotta
fill 559 245 306 559 252 306 minecraft:brown_terracotta
setblock 559 245 307 minecraft:white_concrete
fill 559 245 308 559 252 308 minecraft:brown_terracotta
fill 559 245 310 559 252 310 minecraft:brown_terracotta
setblock 559 245 311 minecraft:white_concrete
setblock 559 245 312 minecraft:brown_terracotta
setblock 559 245 314 minecraft:brown_terracotta
setblock 559 245 315 minecraft:white_concrete
fill 517 246 275 517 253 275 minecraft:brown_terracotta
fill 517 246 279 517 252 280 minecraft:brown_terracotta
fill 517 246 281 517 251 284 minecraft:shroomlight
fill 517 246 287 517 253 287 minecraft:brown_terracotta
fill 517 246 291 517 252 292 minecraft:brown_terracotta
fill 517 246 293 517 251 296 minecraft:shroomlight
fill 517 246 299 517 253 299 minecraft:brown_terracotta
fill 517 246 303 517 252 304 minecraft:brown_terracotta
fill 517 246 305 517 251 308 minecraft:shroomlight
fill 517 246 311 517 253 311 minecraft:brown_terracotta
fill 517 246 315 517 252 316 minecraft:brown_terracotta
fill 517 246 317 520 251 317 minecraft:shroomlight
fill 520 246 283 521 246 289 minecraft:red_concrete
fill 521 246 275 522 252 275 minecraft:brown_terracotta
fill 521 246 317 521 253 317 minecraft:brown_terracotta
fill 524 246 275 527 251 275 minecraft:shroomlight
fill 524 246 276 524 246 280 minecraft:red_concrete
fill 525 246 276 526 246 276 minecraft:red_concrete
fill 525 246 280 526 246 280 minecraft:red_concrete
fill 525 246 317 525 253 317 minecraft:brown_terracotta
fill 526 246 277 526 246 279 minecraft:red_concrete
fill 529 246 275 529 253 275 minecraft:brown_terracotta
fill 529 246 317 532 251 317 minecraft:shroomlight
fill 533 246 275 534 252 275 minecraft:brown_terracotta
fill 533 246 317 533 253 317 minecraft:brown_terracotta
fill 535 246 314 535 247 314 minecraft:orange_terracotta
fill 536 246 275 539 251 275 minecraft:shroomlight
fill 537 246 317 537 253 317 minecraft:brown_terracotta
fill 538 246 312 542 246 312 minecraft:red_concrete
fill 538 246 316 538 271 316 minecraft:white_concrete
fill 541 246 275 541 253 275 minecraft:brown_terracotta
fill 541 246 317 544 251 317 minecraft:shroomlight
fill 545 246 275 546 252 275 minecraft:brown_terracotta
fill 545 246 317 545 253 317 minecraft:brown_terracotta
fill 548 246 275 551 251 275 minecraft:shroomlight
fill 549 246 317 549 253 317 minecraft:brown_terracotta
fill 553 246 275 553 253 275 minecraft:brown_terracotta
fill 553 246 317 556 251 317 minecraft:shroomlight
fill 557 246 275 559 251 275 minecraft:brown_terracotta
fill 557 246 317 557 253 317 minecraft:brown_terracotta
fill 559 246 276 559 251 279 minecraft:shroomlight
fill 559 246 283 559 253 283 minecraft:brown_terracotta
fill 559 246 287 559 253 287 minecraft:brown_terracotta
fill 559 246 288 559 251 291 minecraft:shroomlight
fill 559 246 295 559 253 295 minecraft:brown_terracotta
fill 559 246 299 559 253 299 minecraft:brown_terracotta
fill 559 246 300 559 251 303 minecraft:shroomlight
fill 559 246 307 559 253 307 minecraft:brown_terracotta
fill 559 246 311 559 253 311 minecraft:brown_terracotta
fill 559 246 312 559 251 315 minecraft:shroomlight
fill 559 246 316 559 252 316 minecraft:brown_terracotta
fill 520 247 284 521 247 288 minecraft:red_concrete
fill 519 248 285 522 248 287 minecraft:red_concrete
fill 523 248 310 523 249 310 minecraft:brown_terracotta
fill 533 248 312 537 248 316 minecraft:white_concrete
fill 539 248 281 539 249 281 minecraft:brown_terracotta
fill 548 248 281 548 249 281 minecraft:brown_terracotta
fill 552 248 291 552 249 292 minecraft:brown_terracotta
fill 552 248 312 552 249 312 minecraft:brown_terracotta
setblock 520 249 278 minecraft:light[level=12]
setblock 520 249 285 minecraft:light[level=12]
setblock 520 249 292 minecraft:light[level=12]
setblock 520 249 299 minecraft:light[level=12]
setblock 520 249 306 minecraft:light[level=12]
setblock 520 249 313 minecraft:light[level=12]
fill 522 249 310 522 250 310 minecraft:brown_terracotta
setblock 527 249 278 minecraft:light[level=12]
setblock 527 249 285 minecraft:light[level=12]
setblock 527 249 292 minecraft:light[level=12]
setblock 527 249 299 minecraft:light[level=12]
setblock 527 249 306 minecraft:light[level=12]
setblock 527 249 313 minecraft:light[level=12]
setblock 534 249 278 minecraft:light[level=12]
setblock 534 249 285 minecraft:light[level=12]
setblock 534 249 292 minecraft:light[level=12]
setblock 534 249 299 minecraft:light[level=12]
setblock 534 249 306 minecraft:light[level=12]
fill 534 249 312 536 249 316 minecraft:white_concrete
fill 537 249 316 537 271 316 minecraft:white_concrete
fill 539 249 280 539 250 280 minecraft:brown_terracotta
setblock 541 249 278 minecraft:light[level=12]
setblock 541 249 285 minecraft:light[level=12]
setblock 541 249 292 minecraft:light[level=12]
setblock 541 249 299 minecraft:light[level=12]
setblock 541 249 306 minecraft:light[level=12]
setblock 541 249 313 minecraft:light[level=12]
setblock 548 249 278 minecraft:light[level=12]
fill 548 249 280 548 250 280 minecraft:brown_terracotta
setblock 548 249 285 minecraft:light[level=12]
setblock 548 249 292 minecraft:light[level=12]
setblock 548 249 299 minecraft:light[level=12]
setblock 548 249 306 minecraft:light[level=12]
setblock 548 249 313 minecraft:light[level=12]
fill 553 249 291 553 250 292 minecraft:brown_terracotta
fill 553 249 312 553 250 312 minecraft:brown_terracotta
setblock 555 249 278 minecraft:light[level=12]
setblock 555 249 285 minecraft:light[level=12]
setblock 555 249 292 minecraft:light[level=12]
setblock 555 249 299 minecraft:light[level=12]
setblock 555 249 306 minecraft:light[level=12]
setblock 555 249 313 minecraft:light[level=12]
fill 521 250 310 521 251 310 minecraft:brown_terracotta
fill 535 250 312 535 250 316 minecraft:white_concrete
fill 536 250 316 536 271 316 minecraft:white_concrete
fill 539 250 279 539 251 279 minecraft:brown_terracotta
fill 548 250 279 548 251 279 minecraft:brown_terracotta
fill 554 250 291 554 251 292 minecraft:brown_terracotta
fill 554 250 312 554 251 312 minecraft:brown_terracotta
setblock 520 251 278 minecraft:light[level=15]
setblock 520 251 286 minecraft:light[level=15]
setblock 520 251 294 minecraft:light[level=15]
setblock 520 251 302 minecraft:light[level=15]
fill 520 251 310 520 252 310 minecraft:brown_terracotta
setblock 528 251 278 minecraft:light[level=15]
setblock 528 251 286 minecraft:light[level=15]
setblock 528 251 294 minecraft:light[level=15]
setblock 528 251 302 minecraft:light[level=15]
setblock 528 251 310 minecraft:light[level=15]
setblock 536 251 278 minecraft:light[level=15]
setblock 536 251 286 minecraft:light[level=15]
setblock 536 251 294 minecraft:light[level=15]
setblock 536 251 302 minecraft:light[level=15]
setblock 536 251 310 minecraft:light[level=15]
fill 539 251 278 539 252 278 minecraft:brown_terracotta
setblock 544 251 278 minecraft:light[level=15]
setblock 544 251 286 minecraft:light[level=15]
setblock 544 251 294 minecraft:light[level=15]
setblock 544 251 302 minecraft:light[level=15]
setblock 544 251 310 minecraft:light[level=15]
fill 548 251 278 548 252 278 minecraft:brown_terracotta
setblock 552 251 278 minecraft:light[level=15]
setblock 552 251 286 minecraft:light[level=15]
setblock 552 251 294 minecraft:light[level=15]
setblock 552 251 302 minecraft:light[level=15]
setblock 552 251 310 minecraft:light[level=15]
fill 555 251 291 555 252 292 minecraft:brown_terracotta
fill 555 251 312 555 252 312 minecraft:brown_terracotta
setblock 517 252 277 minecraft:white_concrete
setblock 517 252 281 minecraft:white_concrete
fill 517 252 282 517 252 283 minecraft:shroomlight
setblock 517 252 284 minecraft:brown_terracotta
setblock 517 252 285 minecraft:white_concrete
setblock 517 252 289 minecraft:white_concrete
setblock 517 252 293 minecraft:white_concrete
fill 517 252 294 517 252 295 minecraft:shroomlight
setblock 517 252 296 minecraft:brown_terracotta
setblock 517 252 297 minecraft:white_concrete
setblock 517 252 301 minecraft:white_concrete
setblock 517 252 305 minecraft:white_concrete
fill 517 252 306 517 252 307 minecraft:shroomlight
setblock 517 252 308 minecraft:brown_terracotta
setblock 517 252 309 minecraft:white_concrete
setblock 517 252 313 minecraft:white_concrete
setblock 517 252 317 minecraft:white_concrete
fill 518 252 317 519 252 317 minecraft:shroomlight
setblock 519 252 275 minecraft:white_concrete
fill 519 252 310 519 253 310 minecraft:brown_terracotta
setblock 520 252 317 minecraft:brown_terracotta
setblock 523 252 275 minecraft:white_concrete
setblock 523 252 317 minecraft:white_concrete
setblock 524 252 275 minecraft:brown_terracotta
fill 525 252 275 526 252 275 minecraft:shroomlight
setblock 527 252 275 minecraft:white_concrete
setblock 527 252 317 minecraft:white_concrete
fill 529 252 317 529 253 317 minecraft:brown_terracotta
fill 530 252 317 531 252 317 minecraft:shroomlight
setblock 531 252 275 minecraft:white_concrete
setblock 532 252 317 minecraft:brown_terracotta
setblock 535 252 275 minecraft:white_concrete
setblock 535 252 317 minecraft:white_concrete
setblock 536 252 275 minecraft:brown_terracotta
fill 537 252 275 538 252 275 minecraft:shroomlight
setblock 539 252 275 minecraft:white_concrete
fill 539 252 277 539 253 277 minecraft:brown_terracotta
setblock 539 252 317 minecraft:white_concrete
fill 541 252 317 541 253 317 minecraft:brown_terracotta
fill 542 252 317 543 252 317 minecraft:shroomlight
setblock 543 252 275 minecraft:white_concrete
setblock 544 252 317 minecraft:brown_terracotta
setblock 547 252 275 minecraft:white_concrete
setblock 547 252 317 minecraft:white_concrete
setblock 548 252 275 minecraft:brown_terracotta
fill 548 252 277 548 253 277 minecraft:brown_terracotta
fill 549 252 275 550 252 275 minecraft:shroomlight
setblock 551 252 275 minecraft:white_concrete
setblock 551 252 317 minecraft:white_concrete
fill 553 252 317 553 253 317 minecraft:brown_terracotta
fill 554 252 317 555 252 317 minecraft:shroomlight
setblock 555 252 275 minecraft:white_concrete
fill 556 252 291 556 253 292 minecraft:brown_terracotta
fill 556 252 312 556 253 312 minecraft:brown_terracotta
setblock 556 252 317 minecraft:brown_terracotta
fill 557 252 275 558 252 275 minecraft:brown_terracotta
setblock 559 252 275 minecraft:white_concrete
setblock 559 252 276 minecraft:brown_terracotta
fill 559 252 277 559 252 278 minecraft:shroomlight
fill 559 252 279 559 253 279 minecraft:brown_terracotta
setblock 559 252 281 minecraft:white_concrete
setblock 559 252 285 minecraft:white_concrete
setblock 559 252 288 minecraft:brown_terracotta
fill 559 252 289 559 252 290 minecraft:shroomlight
fill 559 252 291 559 253 291 minecraft:brown_terracotta
setblock 559 252 293 minecraft:white_concrete
setblock 559 252 297 minecraft:white_concrete
setblock 559 252 300 minecraft:brown_terracotta
fill 559 252 301 559 252 302 minecraft:shroomlight
fill 559 252 303 559 253 303 minecraft:brown_terracotta
setblock 559 252 305 minecraft:white_concrete
setblock 559 252 309 minecraft:white_concrete
setblock 559 252 312 minecraft:brown_terracotta
fill 559 252 313 559 252 314 minecraft:shroomlight
fill 559 252 315 559 253 315 minecraft:brown_terracotta
setblock 559 252 317 minecraft:white_concrete
setblock 517 253 276 minecraft:white_concrete
fill 517 253 277 517 260 277 minecraft:brown_terracotta
setblock 517 253 278 minecraft:white_concrete
setblock 517 253 279 minecraft:brown_terracotta
setblock 517 253 280 minecraft:white_concrete
fill 517 253 281 517 260 281 minecraft:brown_terracotta
setblock 517 253 282 minecraft:white_concrete
setblock 517 253 283 minecraft:brown_terracotta
setblock 517 253 284 minecraft:white_concrete
fill 517 253 285 517 260 285 minecraft:brown_terracotta
setblock 517 253 286 minecraft:white_concrete
setblock 517 253 288 minecraft:white_concrete
fill 517 253 289 517 260 289 minecraft:brown_terracotta
setblock 517 253 290 minecraft:white_concrete
setblock 517 253 291 minecraft:brown_terracotta
setblock 517 253 292 minecraft:white_concrete
fill 517 253 293 517 260 293 minecraft:brown_terracotta
setblock 517 253 294 minecraft:white_concrete
setblock 517 253 295 minecraft:brown_terracotta
setblock 517 253 296 minecraft:white_concrete
fill 517 253 297 517 260 297 minecraft:brown_terracotta
setblock 517 253 298 minecraft:white_concrete
setblock 517 253 300 minecraft:white_concrete
fill 517 253 301 517 260 301 minecraft:brown_terracotta
setblock 517 253 302 minecraft:white_concrete
setblock 517 253 303 minecraft:brown_terracotta
setblock 517 253 304 minecraft:white_concrete
fill 517 253 305 517 260 305 minecraft:brown_terracotta
setblock 517 253 306 minecraft:white_concrete
setblock 517 253 307 minecraft:brown_terracotta
setblock 517 253 308 minecraft:white_concrete
fill 517 253 309 517 260 309 minecraft:brown_terracotta
setblock 517 253 310 minecraft:white_concrete
setblock 517 253 312 minecraft:white_concrete
fill 517 253 313 517 260 313 minecraft:brown_terracotta
setblock 517 253 314 minecraft:white_concrete
setblock 517 253 315 minecraft:brown_terracotta
setblock 517 253 316 minecraft:white_concrete
setblock 517 253 317 minecraft:brown_terracotta
setblock 518 253 275 minecraft:white_concrete
setblock 518 253 317 minecraft:white_concrete
fill 519 253 275 519 260 275 minecraft:brown_terracotta
fill 519 253 317 519 260 317 minecraft:brown_terracotta
setblock 520 253 275 minecraft:white_concrete
setblock 520 253 317 minecraft:white_concrete
setblock 521 253 275 minecraft:brown_terracotta
setblock 522 253 275 minecraft:white_concrete
setblock 522 253 317 minecraft:white_concrete
fill 523 253 275 523 260 275 minecraft:brown_terracotta
fill 523 253 317 523 260 317 minecraft:brown_terracotta
setblock 524 253 275 minecraft:white_concrete
setblock 524 253 317 minecraft:white_concrete
setblock 525 253 275 minecraft:brown_terracotta
setblock 526 253 275 minecraft:white_concrete
setblock 526 253 317 minecraft:white_concrete
fill 527 253 275 527 260 275 minecraft:brown_terracotta
fill 527 253 317 527 260 317 minecraft:brown_terracotta
setblock 528 253 275 minecraft:white_concrete
setblock 528 253 317 minecraft:white_concrete
setblock 530 253 275 minecraft:white_concrete
setblock 530 253 317 minecraft:white_concrete
fill 531 253 275 531 260 275 minecraft:brown_terracotta
fill 531 253 317 531 260 317 minecraft:brown_terracotta
setblock 532 253 275 minecraft:white_concrete
setblock 532 253 317 minecraft:white_concrete
setblock 533 253 275 minecraft:brown_terracotta
setblock 534 253 275 minecraft:white_concrete
setblock 534 253 317 minecraft:white_concrete
fill 535 253 275 535 260 275 minecraft:brown_terracotta
fill 535 253 317 535 260 317 minecraft:brown_terracotta
setblock 536 253 275 minecraft:white_concrete
setblock 536 253 317 minecraft:white_concrete
setblock 537 253 275 minecraft:brown_terracotta
setblock 538 253 275 minecraft:white_concrete
setblock 538 253 317 minecraft:white_concrete
fill 539 253 275 539 254 276 minecraft:brown_terracotta
fill 539 253 317 539 260 317 minecraft:brown_terracotta
setblock 540 253 275 minecraft:white_concrete
setblock 540 253 317 minecraft:white_concrete
setblock 542 253 275 minecraft:white_concrete
setblock 542 253 317 minecraft:white_concrete
fill 543 253 275 543 260 275 minecraft:brown_terracotta
fill 543 253 317 543 260 317 minecraft:brown_terracotta
setblock 544 253 275 minecraft:white_concrete
setblock 544 253 317 minecraft:white_concrete
setblock 545 253 275 minecraft:brown_terracotta
setblock 546 253 275 minecraft:white_concrete
setblock 546 253 317 minecraft:white_concrete
fill 547 253 275 547 260 275 minecraft:brown_terracotta
fill 547 253 317 547 260 317 minecraft:brown_terracotta
setblock 548 253 275 minecraft:white_concrete
fill 548 253 276 548 254 276 minecraft:brown_terracotta
fill 548 253 312 548 254 312 minecraft:iron_block
setblock 548 253 317 minecraft:white_concrete
setblock 549 253 275 minecraft:brown_terracotta
setblock 550 253 275 minecraft:white_concrete
setblock 550 253 317 minecraft:white_concrete
fill 551 253 275 551 260 275 minecraft:brown_terracotta
fill 551 253 317 551 260 317 minecraft:brown_terracotta
setblock 552 253 275 minecraft:white_concrete
setblock 552 253 317 minecraft:white_concrete
setblock 554 253 275 minecraft:white_concrete
setblock 554 253 317 minecraft:white_concrete
fill 555 253 275 555 260 275 minecraft:brown_terracotta
fill 555 253 317 555 260 317 minecraft:brown_terracotta
setblock 556 253 275 minecraft:white_concrete
setblock 556 253 317 minecraft:white_concrete
setblock 557 253 275 minecraft:brown_terracotta
fill 557 253 291 557 254 292 minecraft:brown_terracotta
fill 557 253 312 557 254 312 minecraft:brown_terracotta
setblock 558 253 275 minecraft:white_concrete
setblock 558 253 317 minecraft:white_concrete
setblock 559 253 275 minecraft:brown_terracotta
setblock 559 253 276 minecraft:white_concrete
fill 559 253 277 559 260 277 minecraft:brown_terracotta
setblock 559 253 278 minecraft:white_concrete
setblock 559 253 280 minecraft:white_concrete
fill 559 253 281 559 260 281 minecraft:brown_terracotta
setblock 559 253 282 minecraft:white_concrete
setblock 559 253 284 minecraft:white_concrete
fill 559 253 285 559 260 285 minecraft:brown_terracotta
setblock 559 253 286 minecraft:white_concrete
setblock 559 253 288 minecraft:white_concrete
fill 559 253 289 559 260 289 minecraft:brown_terracotta
setblock 559 253 290 minecraft:white_concrete
setblock 559 253 292 minecraft:white_concrete
fill 559 253 293 559 260 293 minecraft:brown_terracotta
setblock 559 253 294 minecraft:white_concrete
setblock 559 253 296 minecraft:white_concrete
fill 559 253 297 559 260 297 minecraft:brown_terracotta
setblock 559 253 298 minecraft:white_concrete
setblock 559 253 300 minecraft:white_concrete
fill 559 253 301 559 260 301 minecraft:brown_terracotta
setblock 559 253 302 minecraft:white_concrete
setblock 559 253 304 minecraft:white_concrete
fill 559 253 305 559 260 305 minecraft:brown_terracotta
setblock 559 253 306 minecraft:white_concrete
setblock 559 253 308 minecraft:white_concrete
fill 559 253 309 559 260 309 minecraft:brown_terracotta
setblock 559 253 310 minecraft:white_concrete
setblock 559 253 312 minecraft:white_concrete
fill 559 253 313 559 260 313 minecraft:brown_terracotta
setblock 559 253 314 minecraft:white_concrete
setblock 559 253 316 minecraft:white_concrete
fill 559 253 317 559 260 317 minecraft:brown_terracotta
setblock 517 254 275 minecraft:white_concrete
fill 517 254 276 517 261 276 minecraft:brown_terracotta
fill 517 254 278 517 261 278 minecraft:brown_terracotta
setblock 517 254 279 minecraft:white_concrete
fill 517 254 280 517 261 280 minecraft:brown_terracotta
fill 517 254 282 517 261 282 minecraft:brown_terracotta
setblock 517 254 283 minecraft:white_concrete
fill 517 254 284 517 261 284 minecraft:brown_terracotta
fill 517 254 286 517 261 286 minecraft:brown_terracotta
setblock 517 254 287 minecraft:white_concrete
fill 517 254 288 517 261 288 minecraft:brown_terracotta
fill 517 254 290 517 261 290 minecraft:brown_terracotta
setblock 517 254 291 minecraft:white_concrete
fill 517 254 292 517 261 292 minecraft:brown_terracotta
fill 517 254 294 517 261 294 minecraft:brown_terracotta
setblock 517 254 295 minecraft:white_concrete
fill 517 254 296 517 261 296 minecraft:brown_terracotta
fill 517 254 298 517 261 298 minecraft:brown_terracotta
setblock 517 254 299 minecraft:white_concrete
fill 517 254 300 517 261 300 minecraft:brown_terracotta
fill 517 254 302 517 261 302 minecraft:brown_terracotta
setblock 517 254 303 minecraft:white_concrete
fill 517 254 304 517 261 304 minecraft:brown_terracotta
fill 517 254 306 517 261 306 minecraft:brown_terracotta
setblock 517 254 307 minecraft:white_concrete
fill 517 254 308 517 261 308 minecraft:brown_terracotta
fill 517 254 310 517 261 310 minecraft:brown_terracotta
setblock 517 254 311 minecraft:white_concrete
fill 517 254 312 517 261 312 minecraft:brown_terracotta
fill 517 254 314 517 261 314 minecraft:brown_terracotta
setblock 517 254 315 minecraft:white_concrete
fill 517 254 316 517 261 316 minecraft:brown_terracotta
setblock 517 254 317 minecraft:white_concrete
fill 518 254 275 518 261 275 minecraft:brown_terracotta
fill 518 254 317 518 261 317 minecraft:brown_terracotta
fill 520 254 275 520 261 275 minecraft:brown_terracotta
fill 520 254 317 520 261 317 minecraft:brown_terracotta
setblock 521 254 275 minecraft:white_concrete
setblock 521 254 317 minecraft:white_concrete
fill 522 254 275 522 261 275 minecraft:brown_terracotta
fill 522 254 317 522 261 317 minecraft:brown_terracotta
setblock 523 254 281 minecraft:shroomlight
setblock 523 254 287 minecraft:shroomlight
setblock 523 254 293 minecraft:shroomlight
setblock 523 254 299 minecraft:shroomlight
setblock 523 254 305 minecraft:shroomlight
setblock 523 254 311 minecraft:shroomlight
fill 524 254 275 524 261 275 minecraft:brown_terracotta
fill 524 254 317 524 261 317 minecraft:brown_terracotta
setblock 525 254 275 minecraft:white_concrete
setblock 525 254 317 minecraft:white_concrete
fill 526 254 275 526 261 275 minecraft:brown_terracotta
fill 526 254 317 526 261 317 minecraft:brown_terracotta
fill 527 254 296 528 255 296 minecraft:red_concrete
fill 528 254 275 528 261 275 minecraft:brown_terracotta
fill 528 254 295 528 255 295 minecraft:red_concrete
fill 528 254 297 528 255 297 minecraft:red_concrete
fill 528 254 317 528 261 317 minecraft:brown_terracotta
setblock 529 254 275 minecraft:white_concrete
setblock 529 254 281 minecraft:shroomlight
setblock 529 254 311 minecraft:shroomlight
setblock 529 254 317 minecraft:white_concrete
fill 530 254 275 530 261 275 minecraft:brown_terracotta
fill 530 254 317 530 261 317 minecraft:brown_terracotta
fill 532 254 275 532 261 275 minecraft:brown_terracotta
fill 532 254 317 532 261 317 minecraft:brown_terracotta
setblock 533 254 275 minecraft:white_concrete
setblock 533 254 317 minecraft:white_concrete
fill 534 254 275 534 261 275 minecraft:brown_terracotta
fill 534 254 317 534 261 317 minecraft:brown_terracotta
setblock 535 254 281 minecraft:shroomlight
setblock 535 254 311 minecraft:shroomlight
fill 536 254 275 536 261 275 minecraft:brown_terracotta
fill 536 254 317 536 261 317 minecraft:brown_terracotta
setblock 537 254 275 minecraft:white_concrete
setblock 537 254 317 minecraft:white_concrete
fill 538 254 275 538 261 275 minecraft:brown_terracotta
fill 538 254 317 538 261 317 minecraft:brown_terracotta
fill 540 254 275 540 261 275 minecraft:brown_terracotta
fill 540 254 317 540 261 317 minecraft:brown_terracotta
setblock 541 254 275 minecraft:white_concrete
setblock 541 254 281 minecraft:shroomlight
setblock 541 254 311 minecraft:shroomlight
setblock 541 254 317 minecraft:white_concrete
fill 542 254 275 542 261 275 minecraft:brown_terracotta
fill 542 254 317 542 261 317 minecraft:brown_terracotta
fill 544 254 275 544 261 275 minecraft:brown_terracotta
fill 544 254 317 544 261 317 minecraft:brown_terracotta
setblock 545 254 275 minecraft:white_concrete
setblock 545 254 317 minecraft:white_concrete
fill 546 254 275 546 261 275 minecraft:brown_terracotta
fill 546 254 317 546 261 317 minecraft:brown_terracotta
setblock 547 254 281 minecraft:shroomlight
setblock 547 254 311 minecraft:shroomlight
fill 548 254 275 548 261 275 minecraft:brown_terracotta
fill 548 254 317 548 261 317 minecraft:brown_terracotta
setblock 549 254 275 minecraft:white_concrete
setblock 549 254 317 minecraft:white_concrete
fill 550 254 275 550 261 275 minecraft:brown_terracotta
fill 550 254 317 550 261 317 minecraft:brown_terracotta
fill 552 254 275 552 261 275 minecraft:brown_terracotta
fill 552 254 317 552 261 317 minecraft:brown_terracotta
setblock 553 254 275 minecraft:white_concrete
setblock 553 254 281 minecraft:shroomlight
setblock 553 254 287 minecraft:shroomlight
setblock 553 254 293 minecraft:shroomlight
setblock 553 254 299 minecraft:shroomlight
setblock 553 254 305 minecraft:shroomlight
setblock 553 254 311 minecraft:shroomlight
setblock 553 254 317 minecraft:white_concrete
fill 554 254 275 554 261 275 minecraft:brown_terracotta
fill 554 254 317 554 261 317 minecraft:brown_terracotta
fill 556 254 275 556 261 275 minecraft:brown_terracotta
fill 556 254 317 556 261 317 minecraft:brown_terracotta
setblock 557 254 275 minecraft:white_concrete
setblock 557 254 317 minecraft:white_concrete
fill 558 254 275 558 261 275 minecraft:brown_terracotta
fill 558 254 317 558 261 317 minecraft:brown_terracotta
setblock 559 254 275 minecraft:white_concrete
fill 559 254 276 559 261 276 minecraft:brown_terracotta
fill 559 254 278 559 261 278 minecraft:brown_terracotta
setblock 559 254 279 minecraft:white_concrete
fill 559 254 280 559 261 280 minecraft:brown_terracotta
fill 559 254 282 559 261 282 minecraft:brown_terracotta
setblock 559 254 283 minecraft:white_concrete
fill 559 254 284 559 261 284 minecraft:brown_terracotta
fill 559 254 286 559 261 286 minecraft:brown_terracotta
setblock 559 254 287 minecraft:white_concrete
fill 559 254 288 559 261 288 minecraft:brown_terracotta
fill 559 254 290 559 261 290 minecraft:brown_terracotta
setblock 559 254 291 minecraft:white_concrete
fill 559 254 292 559 261 292 minecraft:brown_terracotta
fill 559 254 294 559 261 294 minecraft:brown_terracotta
setblock 559 254 295 minecraft:white_concrete
fill 559 254 296 559 261 296 minecraft:brown_terracotta
fill 559 254 298 559 261 298 minecraft:brown_terracotta
setblock 559 254 299 minecraft:white_concrete
fill 559 254 300 559 261 300 minecraft:brown_terracotta
fill 559 254 302 559 261 302 minecraft:brown_terracotta
setblock 559 254 303 minecraft:white_concrete
fill 559 254 304 559 261 304 minecraft:brown_terracotta
fill 559 254 306 559 261 306 minecraft:brown_terracotta
setblock 559 254 307 minecraft:white_concrete
fill 559 254 308 559 261 308 minecraft:brown_terracotta
fill 559 254 310 559 261 310 minecraft:brown_terracotta
setblock 559 254 311 minecraft:white_concrete
fill 559 254 312 559 261 312 minecraft:brown_terracotta
fill 559 254 314 559 261 314 minecraft:brown_terracotta
setblock 559 254 315 minecraft:white_concrete
fill 559 254 316 559 261 316 minecraft:brown_terracotta
fill 517 255 275 517 262 275 minecraft:brown_terracotta
fill 517 255 279 517 262 279 minecraft:brown_terracotta
fill 517 255 283 517 262 283 minecraft:brown_terracotta
fill 517 255 287 517 262 287 minecraft:brown_terracotta
fill 517 255 291 517 262 291 minecraft:brown_terracotta
fill 517 255 295 517 262 295 minecraft:brown_terracotta
fill 517 255 299 517 262 299 minecraft:brown_terracotta
fill 517 255 303 517 262 303 minecraft:brown_terracotta
fill 517 255 307 517 262 307 minecraft:brown_terracotta
fill 517 255 311 517 262 311 minecraft:brown_terracotta
fill 517 255 315 517 262 315 minecraft:brown_terracotta
fill 517 255 317 517 260 317 minecraft:brown_terracotta
fill 518 255 277 523 255 285 minecraft:white_concrete
fill 518 255 289 523 255 297 minecraft:white_concrete
fill 518 255 301 523 255 309 minecraft:white_concrete
fill 518 255 313 523 255 316 minecraft:white_concrete
fill 519 255 286 523 255 288 minecraft:white_concrete
fill 519 255 298 523 255 300 minecraft:white_concrete
fill 519 255 310 523 255 312 minecraft:white_concrete
fill 521 255 275 521 262 275 minecraft:brown_terracotta
fill 521 255 276 529 255 276 minecraft:white_concrete
fill 521 255 317 521 262 317 minecraft:brown_terracotta
fill 524 255 277 558 255 281 minecraft:white_concrete
fill 524 255 311 558 255 315 minecraft:white_concrete
fill 525 255 275 525 262 275 minecraft:brown_terracotta
fill 525 255 317 525 262 317 minecraft:brown_terracotta
setblock 527 255 285 minecraft:light[level=12]
setblock 527 255 292 minecraft:light[level=12]
setblock 527 255 299 minecraft:light[level=12]
setblock 527 255 306 minecraft:light[level=12]
fill 527 255 316 535 255 316 minecraft:white_concrete
fill 529 255 275 529 262 275 minecraft:brown_terracotta
fill 529 255 317 529 262 317 minecraft:brown_terracotta
fill 533 255 275 533 262 275 minecraft:brown_terracotta
fill 533 255 276 541 255 276 minecraft:white_concrete
fill 533 255 317 533 262 317 minecraft:brown_terracotta
setblock 534 255 285 minecraft:light[level=12]
setblock 534 255 292 minecraft:light[level=12]
setblock 534 255 299 minecraft:light[level=12]
setblock 534 255 306 minecraft:light[level=12]
fill 537 255 275 537 262 275 minecraft:brown_terracotta
fill 537 255 317 537 262 317 minecraft:brown_terracotta
fill 539 255 275 539 260 275 minecraft:brown_terracotta
fill 539 255 316 547 255 316 minecraft:white_concrete
fill 541 255 275 541 262 275 minecraft:brown_terracotta
setblock 541 255 285 minecraft:light[level=12]
setblock 541 255 292 minecraft:light[level=12]
setblock 541 255 299 minecraft:light[level=12]
setblock 541 255 306 minecraft:light[level=12]
fill 541 255 317 541 262 317 minecraft:brown_terracotta
fill 545 255 275 545 262 275 minecraft:brown_terracotta
fill 545 255 276 553 255 276 minecraft:white_concrete
fill 545 255 317 545 262 317 minecraft:brown_terracotta
setblock 548 255 285 minecraft:light[level=12]
setblock 548 255 292 minecraft:light[level=12]
setblock 548 255 299 minecraft:light[level=12]
setblock 548 255 306 minecraft:light[level=12]
fill 549 255 275 549 262 275 minecraft:brown_terracotta
fill 549 255 317 549 262 317 minecraft:brown_terracotta
fill 551 255 316 558 255 316 minecraft:white_concrete
fill 553 255 275 553 262 275 minecraft:brown_terracotta
fill 553 255 282 557 255 310 minecraft:white_concrete
fill 553 255 317 553 262 317 minecraft:brown_terracotta
fill 557 255 275 557 262 275 minecraft:brown_terracotta
fill 557 255 276 558 255 276 minecraft:white_concrete
fill 557 255 317 557 262 317 minecraft:brown_terracotta
fill 558 255 282 558 255 283 minecraft:white_concrete
fill 558 255 287 558 255 295 minecraft:white_concrete
fill 558 255 299 558 255 307 minecraft:white_concrete
fill 559 255 275 559 260 275 minecraft:brown_terracotta
fill 559 255 279 559 262 279 minecraft:brown_terracotta
fill 559 255 283 559 262 283 minecraft:brown_terracotta
fill 559 255 287 559 262 287 minecraft:brown_terracotta
fill 559 255 291 559 262 291 minecraft:brown_terracotta
fill 559 255 295 559 262 295 minecraft:brown_terracotta
fill 559 255 299 559 262 299 minecraft:brown_terracotta
fill 559 255 303 559 262 303 minecraft:brown_terracotta
fill 559 255 307 559 262 307 minecraft:brown_terracotta
fill 559 255 311 559 262 311 minecraft:brown_terracotta
fill 559 255 315 559 262 315 minecraft:brown_terracotta
fill 523 256 281 523 256 311 minecraft:red_concrete
fill 524 256 281 553 256 281 minecraft:red_concrete
fill 524 256 311 553 256 311 minecraft:red_concrete
fill 541 256 276 541 257 276 minecraft:white_concrete
fill 541 256 315 543 257 316 minecraft:white_concrete
setblock 548 256 312 minecraft:iron_block
fill 553 256 282 553 256 310 minecraft:red_concrete
fill 541 257 277 543 258 277 minecraft:white_concrete
fill 541 257 314 543 258 314 minecraft:white_concrete
fill 542 257 278 542 260 278 minecraft:white_concrete
fill 542 257 313 542 260 313 minecraft:white_concrete
fill 545 257 312 551 257 315 minecraft:brown_terracotta
fill 541 258 278 541 259 278 minecraft:white_concrete
fill 541 258 313 541 259 313 minecraft:white_concrete
fill 542 258 279 542 260 279 minecraft:white_concrete
fill 542 258 312 542 260 312 minecraft:white_concrete
setblock 542 258 315 minecraft:white_concrete
setblock 542 258 316 minecraft:red_concrete
fill 543 258 278 543 259 278 minecraft:white_concrete
fill 543 258 313 543 259 313 minecraft:white_concrete
fill 545 258 312 551 258 315 minecraft:white_concrete
setblock 520 259 278 minecraft:light[level=15]
setblock 520 259 286 minecraft:light[level=15]
setblock 520 259 294 minecraft:light[level=15]
setblock 520 259 302 minecraft:light[level=15]
setblock 520 259 310 minecraft:light[level=15]
setblock 528 259 278 minecraft:light[level=15]
setblock 528 259 286 minecraft:light[level=15]
setblock 528 259 294 minecraft:light[level=15]
setblock 528 259 302 minecraft:light[level=15]
setblock 528 259 310 minecraft:light[level=15]
setblock 536 259 278 minecraft:light[level=15]
setblock 536 259 286 minecraft:light[level=15]
setblock 536 259 294 minecraft:light[level=15]
setblock 536 259 302 minecraft:light[level=15]
setblock 536 259 310 minecraft:light[level=15]
fill 541 259 279 541 260 279 minecraft:white_concrete
fill 541 259 312 541 260 312 minecraft:white_concrete
fill 542 259 277 542 265 277 minecraft:white_concrete
fill 542 259 280 542 260 280 minecraft:white_concrete
fill 542 259 311 542 261 311 minecraft:white_concrete
setblock 542 259 314 minecraft:white_concrete
setblock 542 259 315 minecraft:red_concrete
fill 543 259 279 543 260 279 minecraft:white_concrete
fill 543 259 312 543 260 312 minecraft:white_concrete
setblock 544 259 278 minecraft:light[level=15]
setblock 544 259 286 minecraft:light[level=15]
setblock 544 259 294 minecraft:light[level=15]
setblock 544 259 302 minecraft:light[level=15]
setblock 544 259 310 minecraft:light[level=15]
fill 545 259 312 551 259 312 minecraft:red_concrete
fill 547 259 316 549 262 316 minecraft:shroomlight
fill 550 259 316 550 271 316 minecraft:white_concrete
setblock 552 259 278 minecraft:light[level=15]
setblock 552 259 286 minecraft:light[level=15]
setblock 552 259 294 minecraft:light[level=15]
setblock 552 259 302 minecraft:light[level=15]
setblock 552 259 310 minecraft:light[level=15]
fill 519 260 285 519 265 287 minecraft:white_concrete
fill 519 260 297 519 265 299 minecraft:white_concrete
fill 519 260 309 519 265 311 minecraft:white_concrete
fill 525 260 315 527 265 315 minecraft:white_concrete
fill 529 260 277 531 265 277 minecraft:white_concrete
fill 537 260 315 539 265 315 minecraft:white_concrete
fill 541 260 277 541 265 277 minecraft:white_concrete
fill 541 260 280 541 260 281 minecraft:white_concrete
fill 541 260 310 541 260 311 minecraft:white_concrete
fill 542 260 281 542 262 282 minecraft:white_concrete
fill 542 260 309 542 262 310 minecraft:white_concrete
setblock 542 260 314 minecraft:red_concrete
fill 543 260 277 543 265 277 minecraft:white_concrete
fill 543 260 280 543 260 281 minecraft:white_concrete
fill 543 260 310 543 260 311 minecraft:white_concrete
setblock 545 260 312 minecraft:white_concrete
setblock 548 260 312 minecraft:white_concrete
fill 549 260 315 551 265 315 minecraft:white_concrete
setblock 551 260 312 minecraft:white_concrete
fill 553 260 277 555 265 277 minecraft:white_concrete
fill 557 260 285 557 265 287 minecraft:white_concrete
fill 557 260 297 557 265 299 minecraft:white_concrete
fill 557 260 309 557 265 311 minecraft:white_concrete
setblock 517 261 277 minecraft:white_concrete
setblock 517 261 281 minecraft:white_concrete
setblock 517 261 285 minecraft:white_concrete
setblock 517 261 289 minecraft:white_concrete
setblock 517 261 293 minecraft:white_concrete
setblock 517 261 297 minecraft:white_concrete
setblock 517 261 301 minecraft:white_concrete
setblock 517 261 305 minecraft:white_concrete
setblock 517 261 309 minecraft:white_concrete
setblock 517 261 313 minecraft:white_concrete
setblock 517 261 317 minecraft:white_concrete
setblock 519 261 275 minecraft:white_concrete
setblock 519 261 317 minecraft:white_concrete
setblock 520 261 278 minecraft:light[level=12]
setblock 520 261 285 minecraft:light[level=12]
setblock 520 261 292 minecraft:light[level=12]
setblock 520 261 299 minecraft:light[level=12]
setblock 520 261 306 minecraft:light[level=12]
setblock 520 261 313 minecraft:light[level=12]
setblock 523 261 275 minecraft:white_concrete
setblock 523 261 317 minecraft:white_concrete
setblock 527 261 275 minecraft:white_concrete
setblock 527 261 278 minecraft:light[level=12]
setblock 527 261 285 minecraft:light[level=12]
setblock 527 261 292 minecraft:light[level=12]
setblock 527 261 299 minecraft:light[level=12]
setblock 527 261 306 minecraft:light[level=12]
setblock 527 261 313 minecraft:light[level=12]
setblock 527 261 317 minecraft:white_concrete
setblock 531 261 275 minecraft:white_concrete
setblock 531 261 317 minecraft:white_concrete
setblock 534 261 278 minecraft:light[level=12]
setblock 534 261 285 minecraft:light[level=12]
setblock 534 261 292 minecraft:light[level=12]
setblock 534 261 299 minecraft:light[level=12]
setblock 534 261 306 minecraft:light[level=12]
setblock 534 261 313 minecraft:light[level=12]
setblock 535 261 275 minecraft:white_concrete
setblock 535 261 317 minecraft:white_concrete
setblock 539 261 275 minecraft:white_concrete
setblock 539 261 317 minecraft:white_concrete
setblock 541 261 278 minecraft:light[level=12]
fill 541 261 281 541 261 282 minecraft:white_concrete
setblock 541 261 285 minecraft:light[level=12]
setblock 541 261 292 minecraft:light[level=12]
setblock 541 261 299 minecraft:light[level=12]
setblock 541 261 306 minecraft:light[level=12]
fill 541 261 309 541 261 310 minecraft:white_concrete
setblock 541 261 313 minecraft:light[level=12]
fill 542 261 279 542 261 280 minecraft:red_concrete
fill 542 261 283 542 263 283 minecraft:white_concrete
fill 542 261 308 542 263 308 minecraft:white_concrete
setblock 542 261 312 minecraft:red_concrete
setblock 543 261 275 minecraft:white_concrete
fill 543 261 281 543 261 282 minecraft:white_concrete
fill 543 261 309 543 261 310 minecraft:white_concrete
setblock 543 261 317 minecraft:white_concrete
setblock 547 261 275 minecraft:white_concrete
setblock 547 261 317 minecraft:white_concrete
setblock 548 261 278 minecraft:light[level=12]
setblock 548 261 285 minecraft:light[level=12]
setblock 548 261 292 minecraft:light[level=12]
setblock 548 261 299 minecraft:light[level=12]
setblock 548 261 306 minecraft:light[level=12]
setblock 548 261 313 minecraft:light[level=12]
setblock 551 261 275 minecraft:white_concrete
setblock 551 261 317 minecraft:white_concrete
setblock 555 261 275 minecraft:white_concrete
setblock 555 261 278 minecraft:light[level=12]
setblock 555 261 285 minecraft:light[level=12]
setblock 555 261 292 minecraft:light[level=12]
setblock 555 261 299 minecraft:light[level=12]
setblock 555 261 306 minecraft:light[level=12]
setblock 555 261 313 minecraft:light[level=12]
setblock 555 261 317 minecraft:white_concrete
setblock 559 261 275 minecraft:white_concrete
setblock 559 261 277 minecraft:white_concrete
setblock 559 261 281 minecraft:white_concrete
setblock 559 261 285 minecraft:white_concrete
setblock 559 261 289 minecraft:white_concrete
setblock 559 261 293 minecraft:white_concrete
setblock 559 261 297 minecraft:white_concrete
setblock 559 261 301 minecraft:white_concrete
setblock 559 261 305 minecraft:white_concrete
setblock 559 261 309 minecraft:white_concrete
setblock 559 261 313 minecraft:white_concrete
setblock 559 261 317 minecraft:white_concrete
setblock 517 262 276 minecraft:white_concrete
fill 517 262 277 517 269 277 minecraft:brown_terracotta
setblock 517 262 278 minecraft:white_concrete
setblock 517 262 280 minecraft:white_concrete
fill 517 262 281 517 265 281 minecraft:brown_terracotta
setblock 517 262 282 minecraft:white_concrete
setblock 517 262 284 minecraft:white_concrete
fill 517 262 285 517 269 285 minecraft:brown_terracotta
setblock 517 262 286 minecraft:white_concrete
setblock 517 262 288 minecraft:white_concrete
fill 517 262 289 517 269 289 minecraft:brown_terracotta
setblock 517 262 290 minecraft:white_concrete
setblock 517 262 292 minecraft:white_concrete
fill 517 262 293 517 265 293 minecraft:brown_terracotta
setblock 517 262 294 minecraft:white_concrete
setblock 517 262 296 minecraft:white_concrete
fill 517 262 297 517 269 297 minecraft:brown_terracotta
setblock 517 262 298 minecraft:white_concrete
setblock 517 262 300 minecraft:white_concrete
fill 517 262 301 517 269 301 minecraft:brown_terracotta
setblock 517 262 302 minecraft:white_concrete
setblock 517 262 304 minecraft:white_concrete
fill 517 262 305 517 265 305 minecraft:brown_terracotta
setblock 517 262 306 minecraft:white_concrete
setblock 517 262 308 minecraft:white_concrete
fill 517 262 309 517 269 309 minecraft:brown_terracotta
setblock 517 262 310 minecraft:white_concrete
setblock 517 262 312 minecraft:white_concrete
fill 517 262 313 517 269 313 minecraft:brown_terracotta
setblock 517 262 314 minecraft:white_concrete
setblock 517 262 316 minecraft:white_concrete
setblock 517 262 317 minecraft:brown_terracotta
setblock 518 262 275 minecraft:white_concrete
setblock 518 262 317 minecraft:white_concrete
fill 519 262 275 519 269 275 minecraft:brown_terracotta
fill 519 262 317 519 265 317 minecraft:brown_terracotta
setblock 520 262 275 minecraft:white_concrete
setblock 520 262 317 minecraft:white_concrete
setblock 522 262 275 minecraft:white_concrete
setblock 522 262 317 minecraft:white_concrete
fill 523 262 275 523 269 275 minecraft:brown_terracotta
fill 523 262 317 523 269 317 minecraft:brown_terracotta
setblock 524 262 275 minecraft:white_concrete
setblock 524 262 317 minecraft:white_concrete
setblock 526 262 275 minecraft:white_concrete
setblock 526 262 317 minecraft:white_concrete
fill 527 262 275 527 265 275 minecraft:brown_terracotta
fill 527 262 317 527 269 317 minecraft:brown_terracotta
setblock 528 262 275 minecraft:white_concrete
setblock 528 262 317 minecraft:white_concrete
fill 529 262 292 530 263 293 minecraft:lime_concrete
setblock 530 262 275 minecraft:white_concrete
setblock 530 262 317 minecraft:white_concrete
fill 531 262 275 531 269 275 minecraft:brown_terracotta
fill 531 262 293 531 263 293 minecraft:lime_concrete
fill 531 262 317 531 265 317 minecraft:brown_terracotta
setblock 532 262 275 minecraft:white_concrete
setblock 532 262 317 minecraft:white_concrete
setblock 534 262 275 minecraft:white_concrete
setblock 534 262 317 minecraft:white_concrete
fill 535 262 275 535 269 275 minecraft:brown_terracotta
fill 535 262 317 535 269 317 minecraft:brown_terracotta
setblock 536 262 275 minecraft:white_concrete
setblock 536 262 317 minecraft:white_concrete
setblock 538 262 275 minecraft:white_concrete
setblock 538 262 317 minecraft:white_concrete
fill 539 262 275 539 265 275 minecraft:brown_terracotta
fill 539 262 317 539 269 317 minecraft:brown_terracotta
setblock 540 262 275 minecraft:white_concrete
setblock 540 262 317 minecraft:white_concrete
fill 541 262 282 541 262 284 minecraft:white_concrete
fill 541 262 307 541 262 309 minecraft:white_concrete
setblock 542 262 275 minecraft:white_concrete
setblock 542 262 280 minecraft:red_concrete
fill 542 262 284 542 263 285 minecraft:white_concrete
fill 542 262 306 542 264 307 minecraft:white_concrete
setblock 542 262 311 minecraft:red_concrete
setblock 542 262 317 minecraft:white_concrete
fill 543 262 275 543 269 275 minecraft:brown_terracotta
fill 543 262 282 543 262 284 minecraft:white_concrete
fill 543 262 307 543 262 309 minecraft:white_concrete
fill 543 262 317 543 265 317 minecraft:brown_terracotta
setblock 544 262 275 minecraft:white_concrete
setblock 544 262 317 minecraft:white_concrete
setblock 546 262 275 minecraft:white_concrete
setblock 546 262 317 minecraft:white_concrete
fill 547 262 275 547 269 275 minecraft:brown_terracotta
fill 547 262 317 547 269 317 minecraft:brown_terracotta
setblock 548 262 275 minecraft:white_concrete
setblock 548 262 317 minecraft:white_concrete
setblock 550 262 275 minecraft:white_concrete
setblock 550 262 317 minecraft:white_concrete
fill 551 262 275 551 265 275 minecraft:brown_terracotta
fill 551 262 317 551 269 317 minecraft:brown_terracotta
setblock 552 262 275 minecraft:white_concrete
setblock 552 262 317 minecraft:white_concrete
setblock 554 262 275 minecraft:white_concrete
setblock 554 262 317 minecraft:white_concrete
fill 555 262 275 555 269 275 minecraft:brown_terracotta
fill 555 262 317 555 265 317 minecraft:brown_terracotta
setblock 556 262 275 minecraft:white_concrete
setblock 556 262 317 minecraft:white_concrete
setblock 558 262 275 minecraft:white_concrete
setblock 558 262 317 minecraft:white_concrete
setblock 559 262 275 minecraft:brown_terracotta
setblock 559 262 276 minecraft:white_concrete
fill 559 262 277 559 265 277 minecraft:brown_terracotta
setblock 559 262 278 minecraft:white_concrete
setblock 559 262 280 minecraft:white_concrete
fill 559 262 281 559 269 281 minecraft:brown_terracotta
setblock 559 262 282 minecraft:white_concrete
setblock 559 262 284 minecraft:white_concrete
fill 559 262 285 559 269 285 minecraft:brown_terracotta
setblock 559 262 286 minecraft:white_concrete
setblock 559 262 288 minecraft:white_concrete
fill 559 262 289 559 265 289 minecraft:brown_terracotta
setblock 559 262 290 minecraft:white_concrete
setblock 559 262 292 minecraft:white_concrete
fill 559 262 293 559 269 293 minecraft:brown_terracotta
setblock 559 262 294 minecraft:white_concrete
setblock 559 262 296 minecraft:white_concrete
fill 559 262 297 559 269 297 minecraft:brown_terracotta
setblock 559 262 298 minecraft:white_concrete
setblock 559 262 300 minecraft:white_concrete
fill 559 262 301 559 265 301 minecraft:brown_terracotta
setblock 559 262 302 minecraft:white_concrete
setblock 559 262 304 minecraft:white_concrete
fill 559 262 305 559 269 305 minecraft:brown_terracotta
setblock 559 262 306 minecraft:white_concrete
setblock 559 262 308 minecraft:white_concrete
fill 559 262 309 559 269 309 minecraft:brown_terracotta
setblock 559 262 310 minecraft:white_concrete
setblock 559 262 312 minecraft:white_concrete
fill 559 262 313 559 265 313 minecraft:brown_terracotta
setblock 559 262 314 minecraft:white_concrete
setblock 559 262 316 minecraft:white_concrete
fill 559 262 317 559 269 317 minecraft:brown_terracotta
setblock 517 263 275 minecraft:white_concrete
fill 517 263 276 517 270 276 minecraft:brown_terracotta
fill 517 263 278 517 270 278 minecraft:brown_terracotta
setblock 517 263 279 minecraft:white_concrete
fill 517 263 280 517 270 280 minecraft:brown_terracotta
fill 517 263 282 517 265 282 minecraft:brown_terracotta
setblock 517 263 283 minecraft:white_concrete
fill 517 263 284 517 265 284 minecraft:brown_terracotta
fill 517 263 286 517 270 286 minecraft:brown_terracotta
setblock 517 263 287 minecraft:white_concrete
fill 517 263 288 517 270 288 minecraft:brown_terracotta
fill 517 263 290 517 270 290 minecraft:brown_terracotta
setblock 517 263 291 minecraft:white_concrete
fill 517 263 292 517 270 292 minecraft:brown_terracotta
fill 517 263 294 517 265 294 minecraft:brown_terracotta
setblock 517 263 295 minecraft:white_concrete
fill 517 263 296 517 265 296 minecraft:brown_terracotta
fill 517 263 298 517 270 298 minecraft:brown_terracotta
setblock 517 263 299 minecraft:white_concrete
fill 517 263 300 517 270 300 minecraft:brown_terracotta
fill 517 263 302 517 270 302 minecraft:brown_terracotta
setblock 517 263 303 minecraft:white_concrete
fill 517 263 304 517 270 304 minecraft:brown_terracotta
fill 517 263 306 517 265 306 minecraft:brown_terracotta
setblock 517 263 307 minecraft:white_concrete
fill 517 263 308 517 265 308 minecraft:brown_terracotta
fill 517 263 310 517 270 310 minecraft:brown_terracotta
setblock 517 263 311 minecraft:white_concrete
fill 517 263 312 517 270 312 minecraft:brown_terracotta
fill 517 263 314 517 270 314 minecraft:brown_terracotta
setblock 517 263 315 minecraft:white_concrete
fill 517 263 316 517 270 316 minecraft:brown_terracotta
setblock 517 263 317 minecraft:white_concrete
fill 518 263 275 518 270 275 minecraft:brown_terracotta
fill 518 263 317 518 265 317 minecraft:brown_terracotta
fill 520 263 275 520 270 275 minecraft:brown_terracotta
fill 520 263 317 520 265 317 minecraft:brown_terracotta
setblock 521 263 275 minecraft:white_concrete
setblock 521 263 317 minecraft:white_concrete
fill 522 263 275 522 270 275 minecraft:brown_terracotta
fill 522 263 317 522 270 317 minecraft:brown_terracotta
fill 524 263 275 524 265 275 minecraft:brown_terracotta
fill 524 263 317 524 270 317 minecraft:brown_terracotta
setblock 525 263 275 minecraft:white_concrete
setblock 525 263 317 minecraft:white_concrete
fill 526 263 275 526 265 275 minecraft:brown_terracotta
fill 526 263 317 526 270 317 minecraft:brown_terracotta
fill 528 263 275 528 270 275 minecraft:brown_terracotta
fill 528 263 317 528 270 317 minecraft:brown_terracotta
setblock 529 263 275 minecraft:white_concrete
setblock 529 263 317 minecraft:white_concrete
fill 530 263 275 530 270 275 minecraft:brown_terracotta
fill 530 263 317 530 265 317 minecraft:brown_terracotta
fill 532 263 275 532 270 275 minecraft:brown_terracotta
fill 532 263 317 532 265 317 minecraft:brown_terracotta
setblock 533 263 275 minecraft:white_concrete
setblock 533 263 317 minecraft:white_concrete
fill 534 263 275 534 270 275 minecraft:brown_terracotta
fill 534 263 317 534 270 317 minecraft:brown_terracotta
fill 536 263 275 536 265 275 minecraft:brown_terracotta
fill 536 263 317 536 270 317 minecraft:brown_terracotta
setblock 537 263 275 minecraft:white_concrete
setblock 537 263 317 minecraft:white_concrete
fill 538 263 275 538 265 275 minecraft:brown_terracotta
fill 538 263 317 538 270 317 minecraft:brown_terracotta
fill 540 263 275 540 270 275 minecraft:brown_terracotta
fill 540 263 317 540 270 317 minecraft:brown_terracotta
setblock 541 263 275 minecraft:white_concrete
fill 541 263 284 541 263 286 minecraft:white_concrete
fill 541 263 305 541 263 307 minecraft:white_concrete
setblock 541 263 317 minecraft:white_concrete
fill 542 263 275 542 270 275 minecraft:brown_terracotta
setblock 542 263 282 minecraft:red_concrete
fill 542 263 286 542 265 287 minecraft:white_concrete
fill 542 263 304 542 265 305 minecraft:white_concrete
setblock 542 263 309 minecraft:red_concrete
fill 542 263 317 542 265 317 minecraft:brown_terracotta
fill 543 263 284 543 263 286 minecraft:white_concrete
fill 543 263 305 543 263 307 minecraft:white_concrete
fill 544 263 275 544 270 275 minecraft:brown_terracotta
fill 544 263 317 544 265 317 minecraft:brown_terracotta
setblock 545 263 275 minecraft:white_concrete
setblock 545 263 317 minecraft:white_concrete
fill 546 263 275 546 270 275 minecraft:brown_terracotta
fill 546 263 317 546 270 317 minecraft:brown_terracotta
fill 548 263 275 548 265 275 minecraft:brown_terracotta
fill 548 263 316 549 271 316 minecraft:white_concrete
fill 548 263 317 548 270 317 minecraft:brown_terracotta
setblock 549 263 275 minecraft:white_concrete
setblock 549 263 317 minecraft:white_concrete
fill 550 263 275 550 265 275 minecraft:brown_terracotta
fill 550 263 317 550 270 317 minecraft:brown_terracotta
fill 552 263 275 552 270 275 minecraft:brown_terracotta
fill 552 263 317 552 270 317 minecraft:brown_terracotta
setblock 553 263 275 minecraft:white_concrete
setblock 553 263 317 minecraft:white_concrete
fill 554 263 275 554 270 275 minecraft:brown_terracotta
fill 554 263 317 554 265 317 minecraft:brown_terracotta
fill 556 263 275 556 270 275 minecraft:brown_terracotta
fill 556 263 317 556 265 317 minecraft:brown_terracotta
setblock 557 263 275 minecraft:white_concrete
setblock 557 263 317 minecraft:white_concrete
fill 558 263 275 558 270 275 minecraft:brown_terracotta
fill 558 263 317 558 270 317 minecraft:brown_terracotta
setblock 559 263 275 minecraft:white_concrete
fill 559 263 276 559 265 276 minecraft:brown_terracotta
fill 559 263 278 559 265 278 minecraft:brown_terracotta
setblock 559 263 279 minecraft:white_concrete
fill 559 263 280 559 270 280 minecraft:brown_terracotta
fill 559 263 282 559 270 282 minecraft:brown_terracotta
setblock 559 263 283 minecraft:white_concrete
fill 559 263 284 559 270 284 minecraft:brown_terracotta
fill 559 263 286 559 270 286 minecraft:brown_terracotta
setblock 559 263 287 minecraft:white_concrete
fill 559 263 288 559 265 288 minecraft:brown_terracotta
fill 559 263 290 559 265 290 minecraft:brown_terracotta
setblock 559 263 291 minecraft:white_concrete
fill 559 263 292 559 270 292 minecraft:brown_terracotta
fill 559 263 294 559 270 294 minecraft:brown_terracotta
setblock 559 263 295 minecraft:white_concrete
fill 559 263 296 559 270 296 minecraft:brown_terracotta
fill 559 263 298 559 270 298 minecraft:brown_terracotta
setblock 559 263 299 minecraft:white_concrete
fill 559 263 300 559 265 300 minecraft:brown_terracotta
fill 559 263 302 559 265 302 minecraft:brown_terracotta
setblock 559 263 303 minecraft:white_concrete
fill 559 263 304 559 270 304 minecraft:brown_terracotta
fill 559 263 306 559 270 306 minecraft:brown_terracotta
setblock 559 263 307 minecraft:white_concrete
fill 559 263 308 559 270 308 minecraft:brown_terracotta
fill 559 263 310 559 270 310 minecraft:brown_terracotta
setblock 559 263 311 minecraft:white_concrete
fill 559 263 312 559 265 312 minecraft:brown_terracotta
fill 559 263 314 559 265 314 minecraft:brown_terracotta
setblock 559 263 315 minecraft:white_concrete
fill 559 263 316 559 270 316 minecraft:brown_terracotta
fill 517 264 275 517 271 275 minecraft:brown_terracotta
fill 517 264 279 517 271 279 minecraft:brown_terracotta
fill 517 264 283 517 265 283 minecraft:brown_terracotta
fill 517 264 287 517 271 287 minecraft:brown_terracotta
fill 517 264 291 517 271 291 minecraft:brown_terracotta
fill 517 264 295 517 265 295 minecraft:brown_terracotta
fill 517 264 299 517 271 299 minecraft:brown_terracotta
fill 517 264 303 517 271 303 minecraft:brown_terracotta
fill 517 264 307 517 265 307 minecraft:brown_terracotta
fill 517 264 311 517 271 311 minecraft:brown_terracotta
fill 517 264 315 517 271 315 minecraft:brown_terracotta
fill 517 264 317 517 265 317 minecraft:brown_terracotta
fill 521 264 275 521 271 275 minecraft:brown_terracotta
fill 521 264 317 521 271 317 minecraft:brown_terracotta
fill 525 264 275 525 265 275 minecraft:brown_terracotta
fill 525 264 317 525 271 317 minecraft:brown_terracotta
fill 529 264 275 529 271 275 minecraft:brown_terracotta
fill 529 264 317 529 265 317 minecraft:brown_terracotta
fill 533 264 275 533 271 275 minecraft:brown_terracotta
fill 533 264 317 533 271 317 minecraft:brown_terracotta
fill 537 264 275 537 265 275 minecraft:brown_terracotta
fill 537 264 317 537 271 317 minecraft:brown_terracotta
fill 541 264 275 541 271 275 minecraft:brown_terracotta
fill 541 264 285 541 264 288 minecraft:white_concrete
fill 541 264 303 541 264 306 minecraft:white_concrete
fill 541 264 317 541 265 317 minecraft:brown_terracotta
fill 542 264 283 542 264 284 minecraft:red_concrete
fill 542 264 285 543 264 285 minecraft:white_concrete
fill 542 264 288 542 265 289 minecraft:white_concrete
fill 542 264 302 542 266 303 minecraft:white_concrete
setblock 542 264 308 minecraft:red_concrete
fill 543 264 286 543 264 288 minecraft:white_concrete
fill 543 264 303 543 264 306 minecraft:white_concrete
fill 545 264 275 545 271 275 minecraft:brown_terracotta
fill 545 264 317 545 271 317 minecraft:brown_terracotta
fill 549 264 275 549 265 275 minecraft:brown_terracotta
fill 549 264 317 549 271 317 minecraft:brown_terracotta
fill 553 264 275 553 271 275 minecraft:brown_terracotta
fill 553 264 317 553 265 317 minecraft:brown_terracotta
fill 557 264 275 557 271 275 minecraft:brown_terracotta
fill 557 264 317 557 271 317 minecraft:brown_terracotta
fill 559 264 275 559 269 275 minecraft:brown_terracotta
fill 559 264 279 559 265 279 minecraft:brown_terracotta
fill 559 264 283 559 271 283 minecraft:brown_terracotta
fill 559 264 287 559 271 287 minecraft:brown_terracotta
fill 559 264 291 559 265 291 minecraft:brown_terracotta
fill 559 264 295 559 271 295 minecraft:brown_terracotta
fill 559 264 299 559 271 299 minecraft:brown_terracotta
fill 559 264 303 559 265 303 minecraft:brown_terracotta
fill 559 264 307 559 271 307 minecraft:brown_terracotta
fill 559 264 311 559 271 311 minecraft:brown_terracotta
fill 559 264 315 559 265 315 minecraft:brown_terracotta
fill 518 265 279 518 265 284 minecraft:brown_terracotta
fill 518 265 291 518 265 296 minecraft:brown_terracotta
fill 518 265 303 518 265 308 minecraft:brown_terracotta
fill 518 265 315 518 265 316 minecraft:brown_terracotta
fill 519 265 316 522 265 316 minecraft:brown_terracotta
fill 522 265 276 527 265 276 minecraft:brown_terracotta
fill 526 265 298 527 266 299 minecraft:red_concrete
fill 529 265 316 534 265 316 minecraft:brown_terracotta
fill 534 265 276 539 265 276 minecraft:brown_terracotta
fill 541 265 287 541 265 290 minecraft:white_concrete
fill 541 265 301 541 265 304 minecraft:white_concrete
fill 541 265 316 546 265 316 minecraft:brown_terracotta
setblock 542 265 285 minecraft:red_concrete
fill 542 265 290 542 266 293 minecraft:white_concrete
fill 542 265 298 542 266 301 minecraft:white_concrete
setblock 542 265 306 minecraft:red_concrete
fill 543 265 287 543 265 290 minecraft:white_concrete
fill 543 265 301 543 265 304 minecraft:white_concrete
fill 546 265 276 551 265 276 minecraft:brown_terracotta
fill 553 265 316 558 265 316 minecraft:brown_terracotta
fill 558 265 276 558 265 281 minecraft:brown_terracotta
fill 558 265 288 558 265 293 minecraft:brown_terracotta
fill 558 265 300 558 265 305 minecraft:brown_terracotta
fill 558 265 312 558 265 315 minecraft:brown_terracotta
fill 517 266 281 517 271 284 minecraft:shroomlight
fill 517 266 293 517 271 296 minecraft:shroomlight
fill 517 266 305 517 271 308 minecraft:shroomlight
fill 517 266 317 520 271 317 minecraft:shroomlight
fill 524 266 275 527 271 275 minecraft:shroomlight
fill 529 266 317 532 271 317 minecraft:shroomlight
fill 536 266 275 539 271 275 minecraft:shroomlight
fill 538 266 285 539 267 286 minecraft:red_concrete
fill 541 266 290 541 266 301 minecraft:white_concrete
fill 541 266 317 544 271 317 minecraft:shroomlight
fill 542 266 286 542 266 288 minecraft:red_concrete
setblock 542 266 289 minecraft:white_concrete
fill 542 266 294 543 267 297 minecraft:white_concrete
fill 542 266 304 542 266 305 minecraft:red_concrete
fill 543 266 290 543 266 293 minecraft:white_concrete
fill 543 266 298 543 266 301 minecraft:white_concrete
fill 548 266 275 551 271 275 minecraft:shroomlight
fill 553 266 317 556 271 317 minecraft:shroomlight
fill 559 266 276 559 271 279 minecraft:shroomlight
fill 559 266 288 559 271 291 minecraft:shroomlight
fill 559 266 300 559 271 303 minecraft:shroomlight
fill 559 266 312 559 271 315 minecraft:shroomlight
setblock 520 267 278 minecraft:light[level=15]
setblock 520 267 285 minecraft:light[level=12]
setblock 520 267 286 minecraft:light[level=15]
setblock 520 267 292 minecraft:light[level=12]
setblock 520 267 294 minecraft:light[level=15]
setblock 520 267 299 minecraft:light[level=12]
setblock 520 267 302 minecraft:light[level=15]
setblock 520 267 306 minecraft:light[level=12]
setblock 520 267 310 minecraft:light[level=15]
setblock 520 267 313 minecraft:light[level=12]
setblock 527 267 278 minecraft:light[level=12]
setblock 527 267 285 minecraft:light[level=12]
setblock 527 267 292 minecraft:light[level=12]
setblock 527 267 299 minecraft:light[level=12]
setblock 527 267 306 minecraft:light[level=12]
setblock 527 267 313 minecraft:light[level=12]
setblock 528 267 278 minecraft:light[level=15]
setblock 528 267 286 minecraft:light[level=15]
setblock 528 267 294 minecraft:light[level=15]
setblock 528 267 302 minecraft:light[level=15]
setblock 528 267 310 minecraft:light[level=15]
setblock 534 267 278 minecraft:light[level=12]
setblock 534 267 285 minecraft:light[level=12]
setblock 534 267 292 minecraft:light[level=12]
setblock 534 267 299 minecraft:light[level=12]
setblock 534 267 306 minecraft:light[level=12]
setblock 534 267 313 minecraft:light[level=12]
setblock 536 267 278 minecraft:light[level=15]
setblock 536 267 286 minecraft:light[level=15]
setblock 536 267 294 minecraft:light[level=15]
setblock 536 267 302 minecraft:light[level=15]
setblock 536 267 310 minecraft:light[level=15]
setblock 541 267 278 minecraft:light[level=12]
setblock 541 267 285 minecraft:light[level=12]
setblock 541 267 292 minecraft:light[level=12]
fill 541 267 294 541 267 297 minecraft:white_concrete
setblock 541 267 299 minecraft:light[level=12]
setblock 541 267 306 minecraft:light[level=12]
setblock 541 267 313 minecraft:light[level=12]
fill 542 267 288 542 267 290 minecraft:red_concrete
fill 542 267 291 542 267 293 minecraft:white_concrete
fill 542 267 298 542 267 300 minecraft:white_concrete
fill 542 267 301 542 267 303 minecraft:red_concrete
setblock 544 267 278 minecraft:light[level=15]
setblock 544 267 286 minecraft:light[level=15]
setblock 544 267 294 minecraft:light[level=15]
setblock 544 267 302 minecraft:light[level=15]
setblock 544 267 310 minecraft:light[level=15]
setblock 548 267 278 minecraft:light[level=12]
setblock 548 267 285 minecraft:light[level=12]
setblock 548 267 292 minecraft:light[level=12]
setblock 548 267 299 minecraft:light[level=12]
setblock 548 267 306 minecraft:light[level=12]
setblock 548 267 313 minecraft:light[level=12]
setblock 552 267 278 minecraft:light[level=15]
setblock 552 267 286 minecraft:light[level=15]
setblock 552 267 294 minecraft:light[level=15]
setblock 552 267 302 minecraft:light[level=15]
setblock 552 267 310 minecraft:light[level=15]
setblock 555 267 278 minecraft:light[level=12]
setblock 555 267 285 minecraft:light[level=12]
setblock 555 267 292 minecraft:light[level=12]
setblock 555 267 299 minecraft:light[level=12]
setblock 555 267 306 minecraft:light[level=12]
setblock 555 267 313 minecraft:light[level=12]
fill 542 268 291 542 268 300 minecraft:red_concrete
setblock 517 270 277 minecraft:white_concrete
setblock 517 270 285 minecraft:white_concrete
setblock 517 270 289 minecraft:white_concrete
setblock 517 270 297 minecraft:white_concrete
setblock 517 270 301 minecraft:white_concrete
setblock 517 270 309 minecraft:white_concrete
setblock 517 270 313 minecraft:white_concrete
setblock 519 270 275 minecraft:white_concrete
setblock 523 270 275 minecraft:white_concrete
setblock 523 270 317 minecraft:white_concrete
setblock 527 270 317 minecraft:white_concrete
setblock 531 270 275 minecraft:white_concrete
fill 532 270 309 532 271 309 minecraft:white_concrete
setblock 535 270 275 minecraft:white_concrete
setblock 535 270 317 minecraft:white_concrete
setblock 539 270 317 minecraft:white_concrete
setblock 543 270 275 minecraft:white_concrete
setblock 547 270 275 minecraft:white_concrete
setblock 547 270 317 minecraft:white_concrete
setblock 551 270 317 minecraft:white_concrete
setblock 555 270 275 minecraft:white_concrete
setblock 559 270 275 minecraft:white_concrete
setblock 559 270 281 minecraft:white_concrete
setblock 559 270 285 minecraft:white_concrete
setblock 559 270 293 minecraft:white_concrete
setblock 559 270 297 minecraft:white_concrete
setblock 559 270 305 minecraft:white_concrete
setblock 559 270 309 minecraft:white_concrete
setblock 559 270 317 minecraft:white_concrete
setblock 517 271 276 minecraft:white_concrete
fill 517 271 277 517 278 277 minecraft:brown_terracotta
setblock 517 271 278 minecraft:white_concrete
setblock 517 271 280 minecraft:white_concrete
fill 517 271 285 517 278 285 minecraft:brown_terracotta
setblock 517 271 286 minecraft:white_concrete
setblock 517 271 288 minecraft:white_concrete
fill 517 271 289 517 278 289 minecraft:brown_terracotta
setblock 517 271 290 minecraft:white_concrete
setblock 517 271 292 minecraft:white_concrete
fill 517 271 297 517 278 297 minecraft:brown_terracotta
setblock 517 271 298 minecraft:white_concrete
setblock 517 271 300 minecraft:white_concrete
fill 517 271 301 517 278 301 minecraft:brown_terracotta
setblock 517 271 302 minecraft:white_concrete
setblock 517 271 304 minecraft:white_concrete
fill 517 271 309 517 278 309 minecraft:brown_terracotta
setblock 517 271 310 minecraft:white_concrete
setblock 517 271 312 minecraft:white_concrete
fill 517 271 313 517 278 313 minecraft:brown_terracotta
setblock 517 271 314 minecraft:white_concrete
setblock 517 271 316 minecraft:white_concrete
setblock 518 271 275 minecraft:white_concrete
fill 519 271 275 519 278 275 minecraft:brown_terracotta
setblock 520 271 275 minecraft:white_concrete
setblock 522 271 275 minecraft:white_concrete
setblock 522 271 317 minecraft:white_concrete
fill 523 271 275 523 278 275 minecraft:brown_terracotta
fill 523 271 317 523 278 317 minecraft:brown_terracotta
setblock 524 271 317 minecraft:white_concrete
setblock 526 271 317 minecraft:white_concrete
fill 527 271 317 527 278 317 minecraft:brown_terracotta
setblock 528 271 275 minecraft:white_concrete
setblock 528 271 317 minecraft:white_concrete
setblock 530 271 275 minecraft:white_concrete
fill 531 271 275 531 278 275 minecraft:brown_terracotta
setblock 532 271 275 minecraft:white_concrete
setblock 534 271 275 minecraft:white_concrete
setblock 534 271 317 minecraft:white_concrete
fill 535 271 275 535 278 275 minecraft:brown_terracotta
fill 535 271 317 535 278 317 minecraft:brown_terracotta
setblock 536 271 317 minecraft:white_concrete
setblock 538 271 317 minecraft:white_concrete
fill 539 271 317 539 278 317 minecraft:brown_terracotta
setblock 540 271 275 minecraft:white_concrete
setblock 540 271 317 minecraft:white_concrete
setblock 542 271 275 minecraft:white_concrete
fill 543 271 275 543 278 275 minecraft:brown_terracotta
setblock 544 271 275 minecraft:white_concrete
setblock 546 271 275 minecraft:white_concrete
setblock 546 271 317 minecraft:white_concrete
fill 547 271 275 547 278 275 minecraft:brown_terracotta
fill 547 271 317 547 278 317 minecraft:brown_terracotta
setblock 548 271 317 minecraft:white_concrete
setblock 550 271 317 minecraft:white_concrete
fill 551 271 317 551 278 317 minecraft:brown_terracotta
setblock 552 271 275 minecraft:white_concrete
setblock 552 271 317 minecraft:white_concrete
setblock 554 271 275 minecraft:white_concrete
fill 555 271 275 555 278 275 minecraft:brown_terracotta
setblock 556 271 275 minecraft:white_concrete
setblock 558 271 275 minecraft:white_concrete
setblock 558 271 317 minecraft:white_concrete
setblock 559 271 275 minecraft:brown_terracotta
setblock 559 271 280 minecraft:white_concrete
fill 559 271 281 559 278 281 minecraft:brown_terracotta
setblock 559 271 282 minecraft:white_concrete
setblock 559 271 284 minecraft:white_concrete
fill 559 271 285 559 278 285 minecraft:brown_terracotta
setblock 559 271 286 minecraft:white_concrete
setblock 559 271 292 minecraft:white_concrete
fill 559 271 293 559 278 293 minecraft:brown_terracotta
setblock 559 271 294 minecraft:white_concrete
setblock 559 271 296 minecraft:white_concrete
fill 559 271 297 559 278 297 minecraft:brown_terracotta
setblock 559 271 298 minecraft:white_concrete
setblock 559 271 304 minecraft:white_concrete
fill 559 271 305 559 278 305 minecraft:brown_terracotta
setblock 559 271 306 minecraft:white_concrete
setblock 559 271 308 minecraft:white_concrete
fill 559 271 309 559 278 309 minecraft:brown_terracotta
setblock 559 271 310 minecraft:white_concrete
setblock 559 271 316 minecraft:white_concrete
fill 559 271 317 559 278 317 minecraft:brown_terracotta
setblock 517 272 275 minecraft:white_concrete
fill 517 272 276 517 279 276 minecraft:brown_terracotta
fill 517 272 278 517 279 278 minecraft:brown_terracotta
setblock 517 272 279 minecraft:white_concrete
fill 517 272 280 517 278 282 minecraft:brown_terracotta
setblock 517 272 283 minecraft:white_concrete
fill 517 272 284 517 279 284 minecraft:brown_terracotta
fill 517 272 286 517 279 286 minecraft:brown_terracotta
setblock 517 272 287 minecraft:white_concrete
fill 517 272 288 517 279 288 minecraft:brown_terracotta
fill 517 272 290 517 279 290 minecraft:brown_terracotta
setblock 517 272 291 minecraft:white_concrete
fill 517 272 292 517 278 294 minecraft:brown_terracotta
setblock 517 272 295 minecraft:white_concrete
schedule function dropper:buildpart/71_6 1t
