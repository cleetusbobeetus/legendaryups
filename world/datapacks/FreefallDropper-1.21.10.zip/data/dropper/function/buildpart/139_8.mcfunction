setblock 369 248 573 minecraft:oak_log
fill 369 248 574 369 251 574 minecraft:green_terracotta
setblock 369 248 577 minecraft:green_terracotta
setblock 369 248 578 minecraft:oak_log
fill 369 248 579 369 251 579 minecraft:green_terracotta
fill 369 248 581 369 249 581 minecraft:green_terracotta
setblock 369 248 592 minecraft:green_terracotta
setblock 369 248 593 minecraft:oak_log
fill 369 248 594 369 249 594 minecraft:green_terracotta
setblock 369 248 598 minecraft:oak_log
fill 370 248 558 370 248 561 minecraft:green_terracotta
setblock 370 248 562 minecraft:oak_log
fill 370 248 563 370 248 566 minecraft:green_terracotta
setblock 370 248 567 minecraft:oak_log
fill 370 248 568 370 251 568 minecraft:green_terracotta
setblock 370 248 572 minecraft:oak_log
fill 370 248 573 370 251 573 minecraft:green_terracotta
setblock 370 248 577 minecraft:oak_log
fill 370 248 578 370 251 578 minecraft:green_terracotta
setblock 370 248 582 minecraft:oak_log
fill 370 248 583 370 248 584 minecraft:green_terracotta
setblock 370 248 588 minecraft:green_terracotta
setblock 370 248 592 minecraft:oak_log
fill 370 248 593 370 250 593 minecraft:green_terracotta
setblock 370 248 597 minecraft:oak_log
fill 370 248 598 370 251 598 minecraft:green_terracotta
fill 330 249 558 330 249 560 minecraft:green_terracotta
setblock 330 249 561 minecraft:oak_log
fill 330 249 562 330 249 565 minecraft:green_terracotta
setblock 330 249 566 minecraft:oak_log
fill 330 249 567 330 249 570 minecraft:green_terracotta
setblock 330 249 571 minecraft:oak_log
fill 330 249 572 330 249 575 minecraft:green_terracotta
setblock 330 249 576 minecraft:oak_log
fill 330 249 577 330 252 577 minecraft:green_terracotta
setblock 330 249 588 minecraft:oak_leaves[persistent=true]
setblock 330 249 590 minecraft:green_terracotta
setblock 330 249 591 minecraft:oak_log
fill 330 249 592 330 249 595 minecraft:green_terracotta
setblock 330 249 596 minecraft:oak_log
fill 330 249 597 332 249 598 minecraft:green_terracotta
fill 331 249 558 331 249 559 minecraft:green_terracotta
setblock 331 249 560 minecraft:oak_log
setblock 331 249 561 minecraft:green_terracotta
fill 331 249 563 331 249 567 minecraft:dark_oak_log
setblock 331 249 570 minecraft:oak_log
setblock 331 249 571 minecraft:green_terracotta
setblock 331 249 575 minecraft:oak_log
setblock 331 249 576 minecraft:green_terracotta
setblock 331 249 595 minecraft:oak_log
fill 331 249 596 331 252 596 minecraft:green_terracotta
setblock 332 249 558 minecraft:green_terracotta
setblock 332 249 559 minecraft:oak_log
setblock 332 249 560 minecraft:light[level=14]
fill 332 249 568 333 249 568 minecraft:dark_oak_log
setblock 332 249 576 minecraft:light[level=14]
setblock 332 249 584 minecraft:light[level=14]
setblock 332 249 592 minecraft:light[level=14]
setblock 333 249 558 minecraft:oak_log
setblock 333 249 559 minecraft:green_terracotta
setblock 333 249 597 minecraft:green_terracotta
setblock 333 249 598 minecraft:oak_log
fill 334 249 558 337 249 558 minecraft:green_terracotta
fill 334 249 563 335 249 563 minecraft:dark_oak_log
setblock 334 249 597 minecraft:oak_log
fill 334 249 598 337 249 598 minecraft:green_terracotta
setblock 335 249 564 minecraft:dark_oak_log
setblock 335 249 567 minecraft:dark_oak_log
fill 335 249 597 338 249 597 minecraft:green_terracotta
setblock 338 249 558 minecraft:oak_log
setblock 338 249 598 minecraft:oak_log
fill 339 249 558 342 249 558 minecraft:green_terracotta
setblock 339 249 596 minecraft:green_terracotta
setblock 339 249 597 minecraft:oak_log
fill 339 249 598 342 249 598 minecraft:green_terracotta
setblock 340 249 560 minecraft:light[level=14]
setblock 340 249 568 minecraft:light[level=14]
setblock 340 249 576 minecraft:light[level=14]
setblock 340 249 584 minecraft:light[level=14]
setblock 340 249 592 minecraft:light[level=14]
setblock 340 249 596 minecraft:oak_log
fill 340 249 597 343 249 597 minecraft:green_terracotta
fill 341 249 596 344 249 596 minecraft:green_terracotta
setblock 343 249 558 minecraft:oak_log
fill 343 249 595 345 249 595 minecraft:green_terracotta
setblock 343 249 598 minecraft:oak_log
fill 344 249 558 347 249 558 minecraft:green_terracotta
setblock 344 249 597 minecraft:oak_log
fill 344 249 598 347 249 598 minecraft:green_terracotta
setblock 345 249 596 minecraft:oak_log
fill 345 249 597 348 249 597 minecraft:green_terracotta
setblock 346 249 595 minecraft:oak_log
fill 346 249 596 349 249 596 minecraft:green_terracotta
fill 347 249 595 347 250 595 minecraft:green_terracotta
setblock 348 249 558 minecraft:oak_log
setblock 348 249 560 minecraft:light[level=14]
setblock 348 249 568 minecraft:light[level=14]
setblock 348 249 576 minecraft:light[level=14]
setblock 348 249 582 minecraft:dark_oak_log
fill 348 249 584 348 249 585 minecraft:dark_oak_log
setblock 348 249 592 minecraft:light[level=14]
setblock 348 249 598 minecraft:oak_log
fill 349 249 558 349 252 558 minecraft:green_terracotta
setblock 349 249 581 minecraft:dark_oak_log
fill 349 249 586 352 249 586 minecraft:dark_oak_log
setblock 349 249 597 minecraft:oak_log
fill 349 249 598 349 252 598 minecraft:green_terracotta
setblock 350 249 596 minecraft:oak_log
fill 350 249 597 350 252 597 minecraft:green_terracotta
setblock 351 249 596 minecraft:green_terracotta
fill 353 249 582 353 249 585 minecraft:dark_oak_log
setblock 353 249 598 minecraft:oak_log
fill 354 249 598 354 250 598 minecraft:green_terracotta
setblock 355 249 558 minecraft:oak_leaves[persistent=true]
setblock 356 249 560 minecraft:light[level=14]
setblock 356 249 568 minecraft:light[level=14]
setblock 356 249 576 minecraft:light[level=14]
setblock 356 249 584 minecraft:light[level=14]
setblock 356 249 592 minecraft:light[level=14]
fill 357 249 591 360 273 592 minecraft:oak_log
fill 358 249 590 359 273 590 minecraft:oak_log
fill 358 249 593 359 273 593 minecraft:oak_log
fill 361 249 598 362 249 598 minecraft:green_terracotta
setblock 362 249 558 minecraft:green_terracotta
setblock 363 249 558 minecraft:oak_log
setblock 363 249 598 minecraft:oak_log
fill 364 249 558 367 249 558 minecraft:green_terracotta
setblock 364 249 560 minecraft:light[level=14]
setblock 364 249 568 minecraft:light[level=14]
setblock 364 249 576 minecraft:light[level=14]
setblock 364 249 584 minecraft:light[level=14]
setblock 364 249 592 minecraft:light[level=14]
setblock 364 249 597 minecraft:oak_log
fill 364 249 598 364 252 598 minecraft:green_terracotta
fill 365 249 559 366 249 559 minecraft:green_terracotta
fill 365 249 597 365 252 597 minecraft:green_terracotta
setblock 367 249 559 minecraft:oak_log
setblock 367 249 570 minecraft:green_terracotta
setblock 367 249 574 minecraft:oak_log
fill 367 249 575 367 251 575 minecraft:green_terracotta
setblock 368 249 558 minecraft:oak_log
fill 368 249 559 370 250 559 minecraft:green_terracotta
setblock 368 249 567 minecraft:green_terracotta
setblock 368 249 568 minecraft:oak_log
fill 368 249 569 368 250 569 minecraft:green_terracotta
setblock 368 249 573 minecraft:oak_log
fill 368 249 574 368 252 574 minecraft:green_terracotta
setblock 368 249 577 minecraft:green_terracotta
setblock 368 249 578 minecraft:oak_log
fill 368 249 579 368 250 579 minecraft:green_terracotta
setblock 368 249 598 minecraft:oak_log
fill 369 249 558 370 251 558 minecraft:green_terracotta
fill 369 249 560 369 249 561 minecraft:green_terracotta
setblock 369 249 562 minecraft:oak_log
fill 369 249 563 369 249 566 minecraft:green_terracotta
setblock 369 249 567 minecraft:oak_log
fill 369 249 568 369 251 568 minecraft:green_terracotta
setblock 369 249 572 minecraft:oak_log
fill 369 249 573 369 252 573 minecraft:green_terracotta
setblock 369 249 577 minecraft:oak_log
fill 369 249 578 369 252 578 minecraft:green_terracotta
setblock 369 249 593 minecraft:green_terracotta
setblock 369 249 597 minecraft:oak_log
fill 369 249 598 369 252 598 minecraft:green_terracotta
setblock 370 249 560 minecraft:green_terracotta
setblock 370 249 561 minecraft:oak_log
fill 370 249 562 370 249 565 minecraft:green_terracotta
setblock 370 249 566 minecraft:oak_log
fill 370 249 567 370 252 567 minecraft:green_terracotta
setblock 370 249 571 minecraft:oak_log
fill 370 249 572 370 252 572 minecraft:green_terracotta
setblock 370 249 576 minecraft:oak_log
fill 370 249 577 370 252 577 minecraft:green_terracotta
setblock 370 249 581 minecraft:oak_log
fill 370 249 582 370 250 582 minecraft:green_terracotta
setblock 370 249 587 minecraft:oak_leaves[persistent=true]
setblock 370 249 591 minecraft:oak_log
fill 370 249 592 370 250 592 minecraft:green_terracotta
setblock 370 249 596 minecraft:oak_log
fill 370 249 597 370 252 597 minecraft:green_terracotta
fill 330 250 558 330 250 559 minecraft:green_terracotta
setblock 330 250 560 minecraft:oak_log
fill 330 250 561 330 250 564 minecraft:green_terracotta
setblock 330 250 565 minecraft:oak_log
fill 330 250 566 330 250 569 minecraft:green_terracotta
setblock 330 250 570 minecraft:oak_log
fill 330 250 571 330 250 574 minecraft:green_terracotta
setblock 330 250 575 minecraft:oak_log
fill 330 250 576 330 252 576 minecraft:green_terracotta
fill 330 250 591 330 250 594 minecraft:green_terracotta
setblock 330 250 595 minecraft:oak_log
fill 330 250 596 330 251 598 minecraft:green_terracotta
setblock 331 250 558 minecraft:green_terracotta
setblock 331 250 559 minecraft:oak_log
setblock 331 250 560 minecraft:green_terracotta
setblock 331 250 594 minecraft:oak_log
fill 331 250 595 331 251 595 minecraft:green_terracotta
fill 331 250 597 331 250 598 minecraft:green_terracotta
setblock 332 250 558 minecraft:oak_log
setblock 332 250 559 minecraft:green_terracotta
setblock 332 250 597 minecraft:green_terracotta
setblock 332 250 598 minecraft:oak_log
fill 333 250 558 336 250 558 minecraft:green_terracotta
setblock 333 250 597 minecraft:oak_log
fill 333 250 598 336 250 598 minecraft:green_terracotta
fill 334 250 597 337 250 597 minecraft:green_terracotta
fill 335 250 564 335 251 564 minecraft:iron_block
setblock 337 250 558 minecraft:oak_log
setblock 337 250 598 minecraft:oak_log
fill 338 250 558 341 250 558 minecraft:green_terracotta
setblock 338 250 597 minecraft:oak_log
fill 338 250 598 341 250 598 minecraft:green_terracotta
fill 339 250 597 342 250 597 minecraft:green_terracotta
fill 340 250 596 343 250 596 minecraft:green_terracotta
setblock 342 250 558 minecraft:oak_log
setblock 342 250 598 minecraft:oak_log
fill 343 250 558 346 250 558 minecraft:green_terracotta
fill 343 250 595 344 250 595 minecraft:green_terracotta
setblock 343 250 597 minecraft:oak_log
fill 343 250 598 346 250 598 minecraft:green_terracotta
setblock 344 250 596 minecraft:oak_log
fill 344 250 597 347 250 597 minecraft:green_terracotta
setblock 345 250 595 minecraft:oak_log
fill 345 250 596 348 250 596 minecraft:green_terracotta
setblock 346 250 595 minecraft:green_terracotta
setblock 347 250 558 minecraft:oak_log
setblock 347 250 598 minecraft:oak_log
fill 348 250 558 348 253 558 minecraft:green_terracotta
setblock 348 250 597 minecraft:oak_log
fill 348 250 598 348 253 598 minecraft:green_terracotta
setblock 349 250 596 minecraft:oak_log
fill 349 250 597 349 253 597 minecraft:green_terracotta
setblock 350 250 596 minecraft:green_terracotta
setblock 352 250 598 minecraft:oak_log
fill 353 250 598 353 251 598 minecraft:green_terracotta
fill 356 250 591 356 251 592 minecraft:dark_oak_log
fill 357 250 590 357 251 590 minecraft:dark_oak_log
fill 357 250 593 357 251 593 minecraft:dark_oak_log
fill 358 250 594 359 251 594 minecraft:dark_oak_log
fill 360 250 590 360 251 590 minecraft:dark_oak_log
fill 360 250 593 360 251 593 minecraft:dark_oak_log
setblock 361 250 598 minecraft:green_terracotta
setblock 362 250 558 minecraft:oak_log
setblock 362 250 598 minecraft:oak_log
fill 363 250 558 366 250 558 minecraft:green_terracotta
fill 363 250 598 363 253 598 minecraft:green_terracotta
fill 364 250 559 365 250 559 minecraft:green_terracotta
fill 364 250 597 364 252 597 minecraft:green_terracotta
setblock 366 250 559 minecraft:oak_log
setblock 367 250 558 minecraft:oak_log
fill 367 250 559 367 253 559 minecraft:green_terracotta
setblock 367 250 573 minecraft:oak_log
fill 367 250 574 367 251 574 minecraft:green_terracotta
setblock 367 250 598 minecraft:oak_log
fill 368 250 558 368 253 558 minecraft:green_terracotta
setblock 368 250 572 minecraft:oak_log
fill 368 250 573 368 252 573 minecraft:green_terracotta
setblock 368 250 577 minecraft:oak_log
fill 368 250 578 368 251 578 minecraft:green_terracotta
setblock 368 250 597 minecraft:oak_log
fill 368 250 598 368 253 598 minecraft:green_terracotta
setblock 369 250 560 minecraft:green_terracotta
setblock 369 250 561 minecraft:oak_log
fill 369 250 562 369 250 565 minecraft:green_terracotta
setblock 369 250 566 minecraft:oak_log
fill 369 250 567 369 251 567 minecraft:green_terracotta
setblock 369 250 571 minecraft:oak_log
fill 369 250 572 369 253 572 minecraft:green_terracotta
setblock 369 250 576 minecraft:oak_log
fill 369 250 577 369 253 577 minecraft:green_terracotta
setblock 369 250 596 minecraft:oak_log
fill 369 250 597 369 251 597 minecraft:green_terracotta
setblock 370 250 560 minecraft:oak_log
fill 370 250 561 370 250 564 minecraft:green_terracotta
setblock 370 250 565 minecraft:oak_log
fill 370 250 566 370 253 566 minecraft:green_terracotta
setblock 370 250 570 minecraft:oak_log
fill 370 250 571 370 253 571 minecraft:green_terracotta
setblock 370 250 575 minecraft:oak_log
fill 370 250 576 370 253 576 minecraft:green_terracotta
setblock 370 250 580 minecraft:oak_log
fill 370 250 581 370 252 581 minecraft:green_terracotta
setblock 370 250 595 minecraft:oak_log
fill 370 250 596 370 253 596 minecraft:green_terracotta
setblock 330 251 558 minecraft:green_terracotta
setblock 330 251 559 minecraft:oak_log
fill 330 251 560 330 251 563 minecraft:green_terracotta
setblock 330 251 564 minecraft:oak_log
fill 330 251 570 330 251 573 minecraft:green_terracotta
setblock 330 251 574 minecraft:oak_log
fill 330 251 575 330 252 575 minecraft:green_terracotta
setblock 330 251 579 minecraft:oak_log
setblock 330 251 581 minecraft:oak_leaves[persistent=true]
fill 330 251 592 330 251 593 minecraft:green_terracotta
setblock 330 251 594 minecraft:oak_log
fill 330 251 595 330 254 595 minecraft:green_terracotta
setblock 331 251 558 minecraft:oak_log
fill 331 251 559 331 254 559 minecraft:green_terracotta
setblock 331 251 597 minecraft:green_terracotta
setblock 331 251 598 minecraft:oak_log
fill 332 251 558 335 251 558 minecraft:green_terracotta
setblock 332 251 597 minecraft:oak_log
fill 332 251 598 335 251 598 minecraft:green_terracotta
fill 333 251 597 336 251 597 minecraft:green_terracotta
setblock 336 251 558 minecraft:oak_log
setblock 336 251 598 minecraft:oak_log
fill 337 251 558 340 251 558 minecraft:green_terracotta
setblock 337 251 597 minecraft:oak_log
fill 337 251 598 340 251 598 minecraft:green_terracotta
fill 338 251 597 341 251 597 minecraft:green_terracotta
fill 340 251 596 342 251 596 minecraft:green_terracotta
setblock 341 251 558 minecraft:oak_log
setblock 341 251 598 minecraft:oak_log
fill 342 251 558 345 251 558 minecraft:green_terracotta
setblock 342 251 597 minecraft:oak_log
fill 342 251 598 345 251 598 minecraft:green_terracotta
setblock 343 251 596 minecraft:oak_log
fill 343 251 597 346 251 597 minecraft:green_terracotta
fill 344 251 596 347 251 596 minecraft:green_terracotta
setblock 346 251 558 minecraft:oak_log
setblock 346 251 598 minecraft:oak_log
fill 347 251 558 347 254 558 minecraft:green_terracotta
setblock 347 251 597 minecraft:oak_log
fill 347 251 598 347 254 598 minecraft:green_terracotta
setblock 348 251 596 minecraft:oak_log
fill 348 251 597 348 254 597 minecraft:green_terracotta
setblock 349 251 596 minecraft:green_terracotta
setblock 351 251 598 minecraft:oak_log
fill 352 251 598 352 252 598 minecraft:green_terracotta
setblock 356 251 590 minecraft:dark_oak_log
fill 356 251 593 356 251 594 minecraft:dark_oak_log
fill 357 251 589 360 251 589 minecraft:dark_oak_log
setblock 357 251 594 minecraft:dark_oak_log
fill 357 251 595 358 253 595 minecraft:oak_leaves[persistent=true]
setblock 357 251 598 minecraft:oak_leaves[persistent=true]
setblock 360 251 594 minecraft:dark_oak_log
setblock 361 251 558 minecraft:oak_log
fill 361 251 590 361 251 593 minecraft:dark_oak_log
setblock 361 251 598 minecraft:oak_log
fill 362 251 558 365 251 558 minecraft:green_terracotta
fill 362 251 598 362 254 598 minecraft:green_terracotta
setblock 364 251 559 minecraft:green_terracotta
setblock 365 251 559 minecraft:oak_log
setblock 366 251 558 minecraft:oak_log
fill 366 251 559 366 254 559 minecraft:green_terracotta
setblock 366 251 598 minecraft:oak_log
fill 367 251 558 367 254 558 minecraft:green_terracotta
setblock 367 251 597 minecraft:oak_log
fill 367 251 598 367 254 598 minecraft:green_terracotta
fill 368 251 559 369 251 559 minecraft:green_terracotta
setblock 368 251 571 minecraft:oak_log
setblock 368 251 572 minecraft:green_terracotta
setblock 368 251 576 minecraft:oak_log
fill 368 251 577 368 252 577 minecraft:green_terracotta
fill 368 251 597 368 252 597 minecraft:green_terracotta
setblock 369 251 560 minecraft:oak_log
fill 369 251 561 370 251 563 minecraft:green_terracotta
setblock 369 251 570 minecraft:oak_log
fill 369 251 571 369 252 571 minecraft:green_terracotta
setblock 369 251 575 minecraft:oak_log
fill 369 251 576 369 254 576 minecraft:green_terracotta
setblock 369 251 580 minecraft:oak_log
setblock 369 251 596 minecraft:green_terracotta
setblock 370 251 559 minecraft:oak_log
fill 370 251 560 370 254 560 minecraft:green_terracotta
setblock 370 251 564 minecraft:oak_log
fill 370 251 565 370 254 565 minecraft:green_terracotta
setblock 370 251 569 minecraft:oak_log
fill 370 251 570 370 253 570 minecraft:green_terracotta
setblock 370 251 574 minecraft:oak_log
fill 370 251 575 370 254 575 minecraft:green_terracotta
setblock 370 251 579 minecraft:oak_log
fill 370 251 580 370 254 580 minecraft:green_terracotta
setblock 370 251 594 minecraft:oak_log
fill 370 251 595 370 252 595 minecraft:green_terracotta
setblock 330 252 558 minecraft:oak_log
fill 330 252 559 330 252 562 minecraft:green_terracotta
setblock 330 252 563 minecraft:oak_log
setblock 330 252 574 minecraft:green_terracotta
setblock 330 252 578 minecraft:oak_log
setblock 330 252 587 minecraft:oak_leaves[persistent=true]
setblock 330 252 593 minecraft:oak_log
fill 330 252 594 330 254 594 minecraft:green_terracotta
fill 330 252 596 330 252 597 minecraft:green_terracotta
setblock 330 252 598 minecraft:oak_log
fill 331 252 558 334 252 558 minecraft:green_terracotta
setblock 331 252 597 minecraft:oak_log
fill 331 252 598 334 252 598 minecraft:green_terracotta
fill 332 252 597 335 252 597 minecraft:green_terracotta
setblock 335 252 558 minecraft:oak_log
setblock 335 252 598 minecraft:oak_log
fill 336 252 558 339 252 558 minecraft:green_terracotta
fill 336 252 589 337 273 591 minecraft:oak_log
setblock 336 252 597 minecraft:oak_log
fill 336 252 598 339 252 598 minecraft:green_terracotta
fill 337 252 597 340 252 597 minecraft:green_terracotta
fill 338 252 590 338 273 591 minecraft:oak_log
setblock 340 252 558 minecraft:oak_log
setblock 340 252 598 minecraft:oak_log
fill 341 252 558 344 252 558 minecraft:green_terracotta
setblock 341 252 596 minecraft:green_terracotta
setblock 341 252 597 minecraft:oak_log
fill 341 252 598 344 252 598 minecraft:green_terracotta
setblock 342 252 596 minecraft:oak_log
fill 342 252 597 345 252 597 minecraft:green_terracotta
fill 343 252 596 346 252 596 minecraft:green_terracotta
setblock 345 252 558 minecraft:oak_log
setblock 345 252 598 minecraft:oak_log
fill 346 252 558 346 255 558 minecraft:green_terracotta
setblock 346 252 597 minecraft:oak_log
fill 346 252 598 346 255 598 minecraft:green_terracotta
setblock 347 252 596 minecraft:oak_log
fill 347 252 597 347 255 597 minecraft:green_terracotta
setblock 348 252 596 minecraft:green_terracotta
setblock 350 252 598 minecraft:oak_log
fill 351 252 598 351 253 598 minecraft:green_terracotta
fill 353 252 582 355 261 585 minecraft:oak_log
fill 354 252 586 354 273 586 minecraft:oak_log
fill 355 252 593 357 252 594 minecraft:oak_leaves[persistent=true]
fill 356 252 583 356 273 585 minecraft:oak_log
fill 356 252 592 356 253 592 minecraft:oak_leaves[persistent=true]
setblock 356 252 595 minecraft:oak_leaves[persistent=true]
fill 358 252 594 359 253 594 minecraft:oak_leaves[persistent=true]
setblock 360 252 558 minecraft:oak_log
fill 361 252 558 364 252 558 minecraft:green_terracotta
fill 361 252 598 361 255 598 minecraft:green_terracotta
setblock 363 252 559 minecraft:green_terracotta
setblock 364 252 559 minecraft:oak_log
setblock 365 252 558 minecraft:oak_log
fill 365 252 559 365 255 559 minecraft:green_terracotta
setblock 365 252 598 minecraft:oak_log
fill 366 252 558 366 255 558 minecraft:green_terracotta
setblock 366 252 597 minecraft:oak_log
fill 366 252 598 366 255 598 minecraft:green_terracotta
fill 367 252 597 367 253 597 minecraft:green_terracotta
setblock 368 252 559 minecraft:green_terracotta
setblock 368 252 575 minecraft:oak_log
setblock 368 252 576 minecraft:green_terracotta
setblock 369 252 558 minecraft:green_terracotta
setblock 369 252 559 minecraft:oak_log
fill 369 252 560 369 253 562 minecraft:green_terracotta
setblock 369 252 570 minecraft:green_terracotta
setblock 369 252 574 minecraft:oak_log
fill 369 252 575 369 254 575 minecraft:green_terracotta
setblock 369 252 579 minecraft:oak_log
setblock 370 252 558 minecraft:oak_log
fill 370 252 559 370 255 559 minecraft:green_terracotta
fill 370 252 561 370 252 562 minecraft:green_terracotta
setblock 370 252 563 minecraft:oak_log
fill 370 252 564 370 255 564 minecraft:green_terracotta
setblock 370 252 568 minecraft:oak_log
fill 370 252 569 370 253 569 minecraft:green_terracotta
setblock 370 252 573 minecraft:oak_log
fill 370 252 574 370 255 574 minecraft:green_terracotta
setblock 370 252 578 minecraft:oak_log
fill 370 252 579 370 255 579 minecraft:green_terracotta
setblock 370 252 594 minecraft:oak_leaves[persistent=true]
setblock 370 252 598 minecraft:oak_log
fill 330 253 558 330 253 561 minecraft:green_terracotta
setblock 330 253 562 minecraft:oak_log
setblock 330 253 568 minecraft:oak_leaves[persistent=true]
setblock 330 253 593 minecraft:oak_leaves[persistent=true]
setblock 330 253 596 minecraft:green_terracotta
setblock 330 253 597 minecraft:oak_log
fill 330 253 598 333 253 598 minecraft:green_terracotta
fill 331 253 558 333 253 558 minecraft:green_terracotta
fill 331 253 597 332 253 597 minecraft:green_terracotta
setblock 334 253 558 minecraft:oak_log
setblock 334 253 598 minecraft:oak_log
fill 335 253 558 338 253 558 minecraft:green_terracotta
fill 335 253 589 335 254 591 minecraft:dark_oak_log
fill 335 253 598 338 253 598 minecraft:green_terracotta
fill 336 253 592 338 254 592 minecraft:dark_oak_log
fill 336 253 597 339 253 597 minecraft:green_terracotta
fill 338 253 589 338 254 589 minecraft:dark_oak_log
setblock 339 253 558 minecraft:oak_log
setblock 339 253 598 minecraft:oak_log
fill 340 253 558 343 253 558 minecraft:green_terracotta
setblock 340 253 597 minecraft:oak_log
fill 340 253 598 343 253 598 minecraft:green_terracotta
setblock 341 253 596 minecraft:oak_log
fill 341 253 597 344 253 597 minecraft:green_terracotta
fill 342 253 596 345 253 596 minecraft:green_terracotta
setblock 343 253 559 minecraft:oak_log
setblock 344 253 558 minecraft:oak_log
fill 344 253 559 344 256 559 minecraft:green_terracotta
setblock 344 253 598 minecraft:oak_log
fill 345 253 558 345 256 558 minecraft:green_terracotta
setblock 345 253 597 minecraft:oak_log
fill 345 253 598 345 256 598 minecraft:green_terracotta
setblock 346 253 596 minecraft:oak_log
fill 346 253 597 346 256 597 minecraft:green_terracotta
setblock 349 253 558 minecraft:oak_log
setblock 349 253 598 minecraft:oak_log
fill 350 253 558 350 254 558 minecraft:oak_leaves[persistent=true]
fill 350 253 598 350 255 598 minecraft:green_terracotta
fill 352 253 582 352 254 582 minecraft:dark_oak_log
fill 352 253 585 352 254 586 minecraft:dark_oak_log
fill 353 253 586 353 254 586 minecraft:dark_oak_log
fill 354 253 581 355 253 581 minecraft:dark_oak_log
fill 354 253 587 354 254 587 minecraft:dark_oak_log
fill 355 253 586 356 254 586 minecraft:dark_oak_log
setblock 356 253 558 minecraft:oak_leaves[persistent=true]
fill 356 253 582 356 254 582 minecraft:dark_oak_log
fill 356 253 593 357 253 594 minecraft:oak_leaves[persistent=true]
fill 357 253 583 357 254 585 minecraft:dark_oak_log
setblock 359 253 558 minecraft:oak_log
fill 360 253 558 363 253 558 minecraft:green_terracotta
fill 360 253 598 360 256 598 minecraft:green_terracotta
setblock 362 253 559 minecraft:green_terracotta
setblock 363 253 559 minecraft:oak_log
setblock 364 253 558 minecraft:oak_log
fill 364 253 559 364 256 559 minecraft:green_terracotta
setblock 364 253 598 minecraft:oak_log
fill 365 253 558 365 256 558 minecraft:green_terracotta
setblock 365 253 597 minecraft:oak_log
fill 365 253 598 365 256 598 minecraft:green_terracotta
setblock 366 253 560 minecraft:green_terracotta
fill 366 253 597 366 254 597 minecraft:green_terracotta
setblock 367 253 560 minecraft:oak_log
setblock 368 253 559 minecraft:oak_log
setblock 369 253 558 minecraft:oak_log
fill 369 253 559 369 256 559 minecraft:green_terracotta
setblock 369 253 573 minecraft:oak_log
setblock 369 253 574 minecraft:green_terracotta
setblock 369 253 578 minecraft:oak_log
setblock 369 253 579 minecraft:green_terracotta
setblock 369 253 598 minecraft:oak_log
fill 370 253 558 370 256 558 minecraft:green_terracotta
setblock 370 253 561 minecraft:green_terracotta
setblock 370 253 562 minecraft:oak_log
fill 370 253 563 370 256 563 minecraft:green_terracotta
setblock 370 253 572 minecraft:oak_log
fill 370 253 573 370 254 573 minecraft:green_terracotta
setblock 370 253 577 minecraft:oak_log
fill 370 253 578 370 256 578 minecraft:green_terracotta
setblock 370 253 588 minecraft:oak_leaves[persistent=true]
setblock 370 253 597 minecraft:oak_log
fill 370 253 598 370 256 598 minecraft:green_terracotta
fill 330 254 558 330 254 560 minecraft:green_terracotta
setblock 330 254 561 minecraft:oak_log
fill 330 254 562 330 257 562 minecraft:green_terracotta
setblock 330 254 574 minecraft:oak_leaves[persistent=true]
setblock 330 254 596 minecraft:oak_log
fill 330 254 597 331 254 598 minecraft:green_terracotta
fill 331 254 558 332 254 558 minecraft:green_terracotta
setblock 332 254 598 minecraft:green_terracotta
setblock 333 254 558 minecraft:oak_log
setblock 333 254 598 minecraft:oak_log
fill 334 254 558 337 254 558 minecraft:green_terracotta
fill 334 254 590 334 254 591 minecraft:dark_oak_log
fill 334 254 598 337 254 598 minecraft:green_terracotta
setblock 335 254 592 minecraft:dark_oak_log
fill 336 254 588 338 254 588 minecraft:dark_oak_log
fill 336 254 593 337 254 593 minecraft:dark_oak_log
fill 336 254 597 338 254 597 minecraft:green_terracotta
setblock 338 254 558 minecraft:oak_log
setblock 338 254 598 minecraft:oak_log
fill 339 254 558 342 254 558 minecraft:green_terracotta
fill 339 254 589 339 254 592 minecraft:dark_oak_log
setblock 339 254 597 minecraft:oak_log
fill 339 254 598 342 254 598 minecraft:green_terracotta
fill 340 254 597 343 254 597 minecraft:green_terracotta
setblock 341 254 559 minecraft:green_terracotta
fill 341 254 596 344 254 596 minecraft:green_terracotta
setblock 342 254 559 minecraft:oak_log
setblock 343 254 558 minecraft:oak_log
fill 343 254 559 343 257 559 minecraft:green_terracotta
setblock 343 254 598 minecraft:oak_log
fill 344 254 558 344 257 558 minecraft:green_terracotta
setblock 344 254 597 minecraft:oak_log
fill 344 254 598 344 257 598 minecraft:green_terracotta
fill 345 254 559 345 255 559 minecraft:green_terracotta
setblock 345 254 596 minecraft:oak_log
fill 345 254 597 345 257 597 minecraft:green_terracotta
setblock 348 254 558 minecraft:oak_log
setblock 348 254 598 minecraft:oak_log
fill 349 254 558 349 257 558 minecraft:green_terracotta
fill 349 254 598 349 257 598 minecraft:green_terracotta
fill 351 254 585 351 254 586 minecraft:dark_oak_log
fill 352 254 587 353 254 587 minecraft:dark_oak_log
fill 355 254 580 355 254 581 minecraft:dark_oak_log
fill 355 254 587 356 254 587 minecraft:dark_oak_log
fill 356 254 581 357 254 581 minecraft:dark_oak_log
setblock 357 254 582 minecraft:dark_oak_log
setblock 357 254 586 minecraft:dark_oak_log
fill 358 254 583 358 254 585 minecraft:dark_oak_log
fill 359 254 558 362 254 558 minecraft:green_terracotta
setblock 361 254 559 minecraft:green_terracotta
setblock 362 254 559 minecraft:oak_log
setblock 363 254 558 minecraft:oak_log
fill 363 254 559 363 257 559 minecraft:green_terracotta
setblock 363 254 598 minecraft:oak_log
fill 364 254 558 364 257 558 minecraft:green_terracotta
fill 364 254 560 365 254 560 minecraft:green_terracotta
fill 364 254 598 364 257 598 minecraft:green_terracotta
setblock 365 254 597 minecraft:green_terracotta
setblock 366 254 560 minecraft:oak_log
setblock 367 254 559 minecraft:oak_log
fill 367 254 560 369 255 560 minecraft:green_terracotta
setblock 368 254 558 minecraft:oak_log
fill 368 254 559 368 257 559 minecraft:green_terracotta
setblock 368 254 598 minecraft:oak_log
fill 369 254 558 369 257 558 minecraft:green_terracotta
setblock 369 254 561 minecraft:green_terracotta
setblock 369 254 562 minecraft:oak_log
fill 369 254 563 369 257 563 minecraft:green_terracotta
setblock 369 254 577 minecraft:oak_log
setblock 369 254 578 minecraft:green_terracotta
fill 369 254 598 369 257 598 minecraft:green_terracotta
setblock 370 254 561 minecraft:oak_log
fill 370 254 562 370 257 562 minecraft:green_terracotta
setblock 370 254 572 minecraft:green_terracotta
setblock 370 254 576 minecraft:oak_log
fill 370 254 577 370 257 577 minecraft:green_terracotta
setblock 370 254 582 minecraft:oak_leaves[persistent=true]
fill 370 254 597 370 257 597 minecraft:green_terracotta
fill 330 255 558 330 255 559 minecraft:green_terracotta
setblock 330 255 560 minecraft:oak_log
fill 330 255 561 330 258 561 minecraft:green_terracotta
fill 330 255 563 330 256 563 minecraft:green_terracotta
setblock 330 255 580 minecraft:oak_leaves[persistent=true]
setblock 330 255 595 minecraft:oak_log
fill 330 255 596 330 256 598 minecraft:green_terracotta
setblock 331 255 558 minecraft:green_terracotta
setblock 331 255 559 minecraft:oak_log
setblock 331 255 598 minecraft:green_terracotta
setblock 332 255 558 minecraft:oak_log
setblock 332 255 598 minecraft:oak_log
fill 333 255 558 336 255 558 minecraft:green_terracotta
fill 333 255 598 336 255 598 minecraft:green_terracotta
fill 336 255 597 337 255 597 minecraft:green_terracotta
setblock 337 255 558 minecraft:oak_log
setblock 337 255 598 minecraft:oak_log
fill 338 255 558 341 255 558 minecraft:green_terracotta
setblock 338 255 597 minecraft:oak_log
fill 338 255 598 341 255 598 minecraft:green_terracotta
fill 339 255 559 340 255 559 minecraft:green_terracotta
fill 339 255 597 342 255 597 minecraft:green_terracotta
setblock 341 255 559 minecraft:oak_log
fill 341 255 596 343 255 596 minecraft:green_terracotta
setblock 342 255 558 minecraft:oak_log
fill 342 255 559 342 258 559 minecraft:green_terracotta
setblock 342 255 598 minecraft:oak_log
fill 343 255 558 343 258 558 minecraft:green_terracotta
setblock 343 255 597 minecraft:oak_log
fill 343 255 598 343 258 598 minecraft:green_terracotta
setblock 344 255 596 minecraft:oak_log
fill 344 255 597 344 258 597 minecraft:green_terracotta
setblock 347 255 558 minecraft:oak_log
setblock 347 255 598 minecraft:oak_log
fill 348 255 558 348 258 558 minecraft:green_terracotta
fill 348 255 598 348 258 598 minecraft:green_terracotta
setblock 356 255 598 minecraft:oak_leaves[persistent=true]
setblock 357 255 558 minecraft:oak_log
fill 358 255 558 361 255 558 minecraft:green_terracotta
fill 359 255 598 359 257 598 minecraft:green_terracotta
setblock 360 255 559 minecraft:green_terracotta
setblock 361 255 559 minecraft:oak_log
setblock 362 255 558 minecraft:oak_log
fill 362 255 559 362 257 560 minecraft:green_terracotta
setblock 362 255 598 minecraft:oak_log
fill 363 255 558 363 258 558 minecraft:green_terracotta
fill 363 255 560 364 255 560 minecraft:green_terracotta
fill 363 255 598 363 258 598 minecraft:green_terracotta
setblock 365 255 560 minecraft:oak_log
setblock 366 255 559 minecraft:oak_log
fill 366 255 560 366 258 560 minecraft:green_terracotta
setblock 367 255 558 minecraft:oak_log
fill 367 255 559 367 258 559 minecraft:green_terracotta
setblock 367 255 598 minecraft:oak_log
fill 368 255 558 368 258 558 minecraft:green_terracotta
setblock 368 255 561 minecraft:green_terracotta
fill 368 255 598 368 258 598 minecraft:green_terracotta
setblock 369 255 561 minecraft:oak_log
fill 369 255 562 369 258 562 minecraft:green_terracotta
setblock 370 255 560 minecraft:oak_log
fill 370 255 561 370 258 561 minecraft:green_terracotta
setblock 370 255 565 minecraft:oak_log
setblock 370 255 570 minecraft:oak_leaves[persistent=true]
setblock 370 255 575 minecraft:oak_log
fill 370 255 576 370 256 576 minecraft:green_terracotta
setblock 370 255 580 minecraft:oak_log
setblock 370 255 595 minecraft:oak_leaves[persistent=true]
setblock 330 256 558 minecraft:green_terracotta
setblock 330 256 559 minecraft:oak_log
fill 330 256 560 331 258 560 minecraft:green_terracotta
setblock 330 256 567 minecraft:oak_leaves[persistent=true]
setblock 330 256 586 minecraft:oak_leaves[persistent=true]
fill 330 256 592 330 257 592 minecraft:oak_leaves[persistent=true]
fill 330 256 595 330 259 595 minecraft:green_terracotta
setblock 331 256 558 minecraft:oak_log
fill 331 256 559 332 258 559 minecraft:green_terracotta
setblock 331 256 598 minecraft:oak_log
fill 332 256 558 335 256 558 minecraft:green_terracotta
fill 332 256 598 335 256 598 minecraft:green_terracotta
fill 335 256 597 336 256 597 minecraft:green_terracotta
setblock 336 256 558 minecraft:oak_log
setblock 336 256 598 minecraft:oak_log
fill 337 256 558 339 256 559 minecraft:green_terracotta
setblock 337 256 597 minecraft:oak_log
fill 337 256 598 340 256 598 minecraft:green_terracotta
fill 338 256 597 341 256 597 minecraft:green_terracotta
setblock 340 256 558 minecraft:green_terracotta
setblock 340 256 559 minecraft:oak_log
fill 340 256 596 342 256 596 minecraft:green_terracotta
setblock 341 256 558 minecraft:oak_log
fill 341 256 559 341 259 559 minecraft:green_terracotta
setblock 341 256 598 minecraft:oak_log
fill 342 256 558 342 259 558 minecraft:green_terracotta
setblock 342 256 597 minecraft:oak_log
fill 342 256 598 342 259 598 minecraft:green_terracotta
setblock 343 256 596 minecraft:oak_log
fill 343 256 597 343 259 597 minecraft:green_terracotta
setblock 344 256 596 minecraft:green_terracotta
setblock 345 256 559 minecraft:oak_log
setblock 346 256 558 minecraft:oak_log
fill 346 256 559 346 259 559 minecraft:green_terracotta
setblock 346 256 598 minecraft:oak_log
fill 347 256 558 347 259 558 minecraft:green_terracotta
setblock 347 256 597 minecraft:oak_log
fill 347 256 598 347 259 598 minecraft:green_terracotta
setblock 356 256 558 minecraft:oak_log
fill 357 256 558 360 256 558 minecraft:green_terracotta
fill 358 256 559 359 256 559 minecraft:green_terracotta
setblock 360 256 559 minecraft:oak_log
fill 360 256 582 360 257 582 minecraft:glowstone
setblock 361 256 558 minecraft:oak_log
fill 361 256 559 361 258 560 minecraft:green_terracotta
setblock 361 256 598 minecraft:oak_log
fill 362 256 558 362 259 558 minecraft:green_terracotta
fill 362 256 598 362 259 598 minecraft:green_terracotta
setblock 363 256 560 minecraft:green_terracotta
setblock 364 256 560 minecraft:oak_log
setblock 365 256 559 minecraft:oak_log
fill 365 256 560 365 259 560 minecraft:green_terracotta
setblock 366 256 558 minecraft:oak_log
fill 366 256 559 366 259 559 minecraft:green_terracotta
setblock 366 256 598 minecraft:oak_log
fill 367 256 558 367 259 558 minecraft:green_terracotta
fill 367 256 560 368 256 560 minecraft:green_terracotta
fill 367 256 598 367 259 598 minecraft:green_terracotta
setblock 368 256 561 minecraft:oak_log
fill 368 256 562 368 259 562 minecraft:green_terracotta
setblock 369 256 560 minecraft:oak_log
fill 369 256 561 369 259 561 minecraft:green_terracotta
setblock 369 256 564 minecraft:green_terracotta
setblock 370 256 559 minecraft:oak_log
fill 370 256 560 370 259 560 minecraft:green_terracotta
setblock 370 256 564 minecraft:oak_log
fill 370 256 565 370 258 566 minecraft:green_terracotta
setblock 370 256 579 minecraft:oak_log
fill 370 256 580 370 258 581 minecraft:green_terracotta
setblock 370 256 589 minecraft:oak_leaves[persistent=true]
setblock 330 257 558 minecraft:oak_log
fill 330 257 559 330 260 559 minecraft:green_terracotta
setblock 330 257 563 minecraft:oak_log
setblock 330 257 573 minecraft:oak_leaves[persistent=true]
fill 330 257 596 330 257 597 minecraft:green_terracotta
setblock 330 257 598 minecraft:oak_log
fill 331 257 558 334 257 558 minecraft:green_terracotta
fill 331 257 598 334 257 598 minecraft:green_terracotta
setblock 332 257 560 minecraft:light[level=14]
setblock 332 257 568 minecraft:light[level=14]
setblock 332 257 576 minecraft:light[level=14]
setblock 332 257 584 minecraft:light[level=14]
setblock 332 257 592 minecraft:light[level=14]
setblock 333 257 559 minecraft:green_terracotta
setblock 334 257 559 minecraft:oak_log
setblock 335 257 558 minecraft:oak_log
fill 335 257 559 338 257 559 minecraft:green_terracotta
setblock 335 257 597 minecraft:green_terracotta
setblock 335 257 598 minecraft:oak_log
fill 336 257 558 339 257 558 minecraft:green_terracotta
setblock 336 257 597 minecraft:oak_log
fill 336 257 598 339 257 598 minecraft:green_terracotta
fill 337 257 597 340 257 597 minecraft:green_terracotta
setblock 339 257 559 minecraft:oak_log
setblock 340 257 558 minecraft:oak_log
fill 340 257 559 340 260 559 minecraft:green_terracotta
setblock 340 257 560 minecraft:light[level=14]
setblock 340 257 568 minecraft:light[level=14]
setblock 340 257 576 minecraft:light[level=14]
setblock 340 257 584 minecraft:light[level=14]
setblock 340 257 592 minecraft:light[level=14]
fill 340 257 596 341 257 596 minecraft:green_terracotta
setblock 340 257 598 minecraft:oak_log
fill 341 257 558 341 260 558 minecraft:green_terracotta
setblock 341 257 597 minecraft:oak_log
fill 341 257 598 341 260 598 minecraft:green_terracotta
setblock 342 257 596 minecraft:oak_log
fill 342 257 597 342 260 597 minecraft:green_terracotta
setblock 343 257 596 minecraft:green_terracotta
setblock 344 257 559 minecraft:oak_log
setblock 345 257 558 minecraft:oak_log
fill 345 257 559 345 260 559 minecraft:green_terracotta
setblock 345 257 598 minecraft:oak_log
fill 346 257 558 346 260 558 minecraft:green_terracotta
setblock 346 257 597 minecraft:oak_log
fill 346 257 598 346 260 598 minecraft:green_terracotta
setblock 348 257 560 minecraft:light[level=14]
setblock 348 257 568 minecraft:light[level=14]
setblock 348 257 576 minecraft:light[level=14]
setblock 348 257 584 minecraft:light[level=14]
setblock 348 257 592 minecraft:light[level=14]
setblock 351 257 558 minecraft:oak_leaves[persistent=true]
setblock 355 257 558 minecraft:oak_log
fill 356 257 558 359 257 558 minecraft:green_terracotta
setblock 356 257 560 minecraft:light[level=14]
setblock 356 257 568 minecraft:light[level=14]
setblock 356 257 576 minecraft:light[level=14]
setblock 356 257 592 minecraft:light[level=14]
fill 357 257 559 358 257 559 minecraft:green_terracotta
fill 358 257 598 358 258 598 minecraft:green_terracotta
setblock 359 257 559 minecraft:oak_log
fill 359 257 560 360 259 560 minecraft:green_terracotta
setblock 360 257 558 minecraft:oak_log
fill 360 257 559 360 260 559 minecraft:green_terracotta
setblock 360 257 598 minecraft:oak_log
fill 361 257 558 361 260 558 minecraft:green_terracotta
fill 361 257 598 361 260 598 minecraft:green_terracotta
setblock 362 257 561 minecraft:oak_log
setblock 363 257 560 minecraft:oak_log
fill 363 257 561 366 257 561 minecraft:green_terracotta
fill 363 257 597 364 257 597 minecraft:green_terracotta
setblock 364 257 559 minecraft:oak_log
fill 364 257 560 364 260 560 minecraft:green_terracotta
setblock 364 257 568 minecraft:light[level=14]
setblock 364 257 576 minecraft:light[level=14]
setblock 364 257 584 minecraft:light[level=14]
setblock 364 257 592 minecraft:light[level=14]
setblock 365 257 558 minecraft:oak_log
fill 365 257 559 365 260 559 minecraft:green_terracotta
setblock 365 257 598 minecraft:oak_log
fill 366 257 558 366 260 558 minecraft:green_terracotta
fill 366 257 598 366 260 598 minecraft:green_terracotta
setblock 367 257 560 minecraft:green_terracotta
setblock 368 257 560 minecraft:oak_log
fill 368 257 561 368 260 561 minecraft:green_terracotta
fill 368 257 563 368 258 563 minecraft:green_terracotta
setblock 369 257 559 minecraft:oak_log
fill 369 257 560 369 260 560 minecraft:green_terracotta
setblock 369 257 564 minecraft:oak_log
fill 369 257 565 369 260 565 minecraft:green_terracotta
setblock 370 257 558 minecraft:oak_log
fill 370 257 559 370 260 559 minecraft:green_terracotta
setblock 370 257 563 minecraft:oak_log
fill 370 257 564 370 260 564 minecraft:green_terracotta
setblock 370 257 578 minecraft:oak_log
fill 370 257 579 370 258 579 minecraft:green_terracotta
setblock 370 257 583 minecraft:oak_leaves[persistent=true]
setblock 370 257 598 minecraft:oak_log
fill 330 258 558 333 258 558 minecraft:green_terracotta
setblock 330 258 562 minecraft:oak_log
fill 330 258 563 330 260 564 minecraft:green_terracotta
setblock 330 258 579 minecraft:oak_leaves[persistent=true]
fill 330 258 580 330 258 581 minecraft:green_terracotta
setblock 330 258 582 minecraft:oak_log
fill 330 258 583 330 260 584 minecraft:green_terracotta
setblock 330 258 596 minecraft:green_terracotta
setblock 330 258 597 minecraft:oak_log
fill 330 258 598 333 258 598 minecraft:green_terracotta
setblock 331 258 561 minecraft:oak_log
setblock 333 258 559 minecraft:oak_log
setblock 334 258 558 minecraft:oak_log
fill 334 258 559 337 258 559 minecraft:green_terracotta
setblock 334 258 597 minecraft:green_terracotta
setblock 334 258 598 minecraft:oak_log
fill 335 258 558 338 258 558 minecraft:green_terracotta
setblock 335 258 597 minecraft:oak_log
fill 335 258 598 338 258 598 minecraft:green_terracotta
fill 336 258 597 339 258 597 minecraft:green_terracotta
setblock 338 258 559 minecraft:oak_log
setblock 339 258 558 minecraft:oak_log
fill 339 258 559 339 261 559 minecraft:green_terracotta
fill 339 258 596 340 258 596 minecraft:green_terracotta
setblock 339 258 598 minecraft:oak_log
fill 340 258 558 340 261 558 minecraft:green_terracotta
fill 340 258 560 341 258 560 minecraft:green_terracotta
setblock 340 258 597 minecraft:oak_log
fill 340 258 598 340 261 598 minecraft:green_terracotta
setblock 341 258 596 minecraft:oak_log
fill 341 258 597 341 261 597 minecraft:green_terracotta
setblock 342 258 560 minecraft:oak_log
fill 342 258 596 342 259 596 minecraft:green_terracotta
setblock 343 258 559 minecraft:oak_log
fill 343 258 560 343 259 560 minecraft:green_terracotta
setblock 344 258 558 minecraft:oak_log
fill 344 258 559 344 261 559 minecraft:green_terracotta
setblock 344 258 598 minecraft:oak_log
fill 345 258 558 345 261 558 minecraft:green_terracotta
setblock 345 258 597 minecraft:oak_log
fill 345 258 598 345 261 598 minecraft:green_terracotta
setblock 346 258 597 minecraft:green_terracotta
setblock 349 258 558 minecraft:oak_log
setblock 354 258 558 minecraft:oak_log
fill 355 258 558 358 258 558 minecraft:green_terracotta
setblock 355 258 598 minecraft:oak_leaves[persistent=true]
fill 356 258 559 357 258 559 minecraft:green_terracotta
setblock 358 258 559 minecraft:oak_log
fill 358 258 560 358 261 560 minecraft:green_terracotta
setblock 359 258 558 minecraft:oak_log
fill 359 258 559 359 261 559 minecraft:green_terracotta
setblock 359 258 598 minecraft:oak_log
fill 360 258 558 360 261 558 minecraft:green_terracotta
setblock 360 258 561 minecraft:green_terracotta
fill 360 258 581 360 266 582 minecraft:dark_oak_log
fill 360 258 598 360 261 598 minecraft:green_terracotta
setblock 361 258 561 minecraft:oak_log
setblock 362 258 559 minecraft:green_terracotta
setblock 362 258 560 minecraft:oak_log
fill 362 258 561 365 258 561 minecraft:green_terracotta
setblock 363 258 559 minecraft:oak_log
fill 363 258 560 363 261 560 minecraft:green_terracotta
setblock 363 258 597 minecraft:green_terracotta
setblock 364 258 558 minecraft:oak_log
fill 364 258 559 364 261 559 minecraft:green_terracotta
setblock 364 258 598 minecraft:oak_log
fill 365 258 558 365 261 558 minecraft:green_terracotta
fill 365 258 598 365 261 598 minecraft:green_terracotta
setblock 366 258 561 minecraft:oak_log
setblock 367 258 560 minecraft:oak_log
fill 367 258 561 367 260 561 minecraft:green_terracotta
setblock 368 258 559 minecraft:oak_log
fill 368 258 560 368 261 560 minecraft:green_terracotta
setblock 369 258 558 minecraft:oak_log
fill 369 258 559 369 261 559 minecraft:green_terracotta
setblock 369 258 563 minecraft:oak_log
fill 369 258 564 369 261 564 minecraft:green_terracotta
setblock 369 258 598 minecraft:oak_log
fill 370 258 558 370 261 558 minecraft:green_terracotta
setblock 370 258 562 minecraft:oak_log
fill 370 258 563 370 261 563 minecraft:green_terracotta
setblock 370 258 567 minecraft:oak_log
setblock 370 258 577 minecraft:oak_leaves[persistent=true]
setblock 370 258 578 minecraft:green_terracotta
setblock 370 258 582 minecraft:oak_log
setblock 370 258 596 minecraft:oak_leaves[persistent=true]
setblock 370 258 597 minecraft:oak_log
fill 370 258 598 370 261 598 minecraft:green_terracotta
fill 330 259 558 332 259 558 minecraft:green_terracotta
setblock 330 259 560 minecraft:green_terracotta
setblock 330 259 561 minecraft:oak_log
fill 330 259 562 330 262 562 minecraft:green_terracotta
setblock 330 259 566 minecraft:oak_leaves[persistent=true]
setblock 330 259 580 minecraft:green_terracotta
setblock 330 259 581 minecraft:oak_log
fill 330 259 582 330 262 582 minecraft:green_terracotta
setblock 330 259 585 minecraft:green_terracotta
setblock 330 259 586 minecraft:oak_log
fill 330 259 587 330 262 587 minecraft:green_terracotta
setblock 330 259 596 minecraft:oak_log
fill 330 259 597 330 261 598 minecraft:green_terracotta
setblock 331 259 559 minecraft:green_terracotta
setblock 331 259 560 minecraft:oak_log
fill 331 259 561 331 261 561 minecraft:green_terracotta
fill 331 259 598 332 259 598 minecraft:green_terracotta
setblock 332 259 559 minecraft:oak_log
setblock 333 259 558 minecraft:oak_log
fill 333 259 559 336 259 559 minecraft:green_terracotta
setblock 333 259 598 minecraft:oak_log
fill 334 259 558 337 259 558 minecraft:green_terracotta
setblock 334 259 597 minecraft:oak_log
fill 334 259 598 337 259 598 minecraft:green_terracotta
fill 335 259 597 338 259 597 minecraft:green_terracotta
setblock 337 259 559 minecraft:oak_log
setblock 338 259 558 minecraft:oak_log
fill 338 259 559 338 261 560 minecraft:green_terracotta
setblock 338 259 598 minecraft:oak_log
fill 339 259 558 339 262 558 minecraft:green_terracotta
fill 339 259 560 340 259 560 minecraft:green_terracotta
setblock 339 259 596 minecraft:green_terracotta
setblock 339 259 597 minecraft:oak_log
fill 339 259 598 339 262 598 minecraft:green_terracotta
setblock 340 259 596 minecraft:oak_log
fill 340 259 597 340 262 597 minecraft:green_terracotta
setblock 341 259 560 minecraft:oak_log
setblock 341 259 596 minecraft:green_terracotta
setblock 342 259 559 minecraft:oak_log
fill 342 259 560 342 261 560 minecraft:green_terracotta
setblock 343 259 558 minecraft:oak_log
fill 343 259 559 343 262 559 minecraft:green_terracotta
setblock 343 259 598 minecraft:oak_log
fill 344 259 558 344 262 558 minecraft:green_terracotta
setblock 344 259 597 minecraft:oak_log
fill 344 259 598 344 262 598 minecraft:green_terracotta
setblock 345 259 597 minecraft:green_terracotta
setblock 348 259 558 minecraft:oak_log
setblock 349 259 558 minecraft:green_terracotta
setblock 353 259 558 minecraft:oak_log
fill 354 259 558 357 259 558 minecraft:green_terracotta
fill 355 259 559 356 259 559 minecraft:green_terracotta
setblock 357 259 559 minecraft:oak_log
fill 357 259 560 357 262 560 minecraft:green_terracotta
setblock 357 259 598 minecraft:green_terracotta
setblock 358 259 558 minecraft:oak_log
fill 358 259 559 358 262 559 minecraft:green_terracotta
setblock 358 259 598 minecraft:oak_log
fill 359 259 558 359 262 558 minecraft:green_terracotta
setblock 359 259 561 minecraft:green_terracotta
fill 359 259 598 359 262 598 minecraft:green_terracotta
setblock 360 259 561 minecraft:oak_log
setblock 361 259 559 minecraft:green_terracotta
setblock 361 259 560 minecraft:oak_log
fill 361 259 561 364 259 561 minecraft:green_terracotta
setblock 362 259 559 minecraft:oak_log
fill 362 259 560 362 262 560 minecraft:green_terracotta
setblock 363 259 558 minecraft:oak_log
fill 363 259 559 363 262 559 minecraft:green_terracotta
setblock 363 259 598 minecraft:oak_log
fill 364 259 558 364 262 558 minecraft:green_terracotta
fill 364 259 598 364 262 598 minecraft:green_terracotta
setblock 365 259 561 minecraft:oak_log
setblock 366 259 560 minecraft:oak_log
fill 366 259 561 366 261 561 minecraft:green_terracotta
setblock 367 259 559 minecraft:oak_log
fill 367 259 560 367 262 560 minecraft:green_terracotta
setblock 368 259 558 minecraft:oak_log
fill 368 259 559 368 262 559 minecraft:green_terracotta
setblock 368 259 563 minecraft:oak_log
fill 368 259 564 368 262 564 minecraft:green_terracotta
setblock 368 259 598 minecraft:oak_log
fill 369 259 558 369 262 558 minecraft:green_terracotta
setblock 369 259 562 minecraft:oak_log
fill 369 259 563 369 262 563 minecraft:green_terracotta
setblock 369 259 566 minecraft:green_terracotta
fill 369 259 598 369 261 598 minecraft:green_terracotta
setblock 370 259 561 minecraft:oak_log
fill 370 259 562 370 262 562 minecraft:green_terracotta
setblock 370 259 565 minecraft:green_terracotta
setblock 370 259 566 minecraft:oak_log
fill 370 259 567 370 262 567 minecraft:green_terracotta
setblock 370 259 571 minecraft:oak_leaves[persistent=true]
setblock 370 259 580 minecraft:green_terracotta
setblock 370 259 581 minecraft:oak_log
fill 370 259 582 370 260 583 minecraft:green_terracotta
setblock 370 259 590 minecraft:oak_leaves[persistent=true]
fill 330 260 558 331 260 558 minecraft:green_terracotta
setblock 330 260 560 minecraft:oak_log
fill 330 260 561 330 263 561 minecraft:green_terracotta
setblock 330 260 565 minecraft:oak_log
setblock 330 260 572 minecraft:oak_leaves[persistent=true]
setblock 330 260 580 minecraft:oak_log
fill 330 260 581 330 262 581 minecraft:green_terracotta
setblock 330 260 585 minecraft:oak_log
fill 330 260 586 330 263 586 minecraft:green_terracotta
fill 330 260 588 330 260 589 minecraft:green_terracotta
setblock 330 260 591 minecraft:oak_leaves[persistent=true]
setblock 330 260 595 minecraft:oak_log
fill 330 260 596 330 261 596 minecraft:green_terracotta
setblock 331 260 559 minecraft:oak_log
fill 331 260 560 331 261 560 minecraft:green_terracotta
fill 331 260 562 331 261 562 minecraft:green_terracotta
setblock 331 260 598 minecraft:green_terracotta
setblock 332 260 558 minecraft:oak_log
fill 332 260 559 335 260 559 minecraft:green_terracotta
setblock 332 260 598 minecraft:oak_log
fill 333 260 558 336 260 558 minecraft:green_terracotta
fill 333 260 598 336 260 598 minecraft:green_terracotta
fill 334 260 597 337 260 597 minecraft:green_terracotta
setblock 336 260 559 minecraft:oak_log
setblock 337 260 558 minecraft:oak_log
fill 337 260 559 337 261 560 minecraft:green_terracotta
setblock 337 260 598 minecraft:oak_log
fill 338 260 558 338 263 558 minecraft:green_terracotta
setblock 338 260 597 minecraft:oak_log
fill 338 260 598 338 263 598 minecraft:green_terracotta
setblock 339 260 560 minecraft:green_terracotta
setblock 339 260 596 minecraft:oak_log
fill 339 260 597 339 263 597 minecraft:green_terracotta
setblock 340 260 560 minecraft:oak_log
setblock 340 260 596 minecraft:green_terracotta
setblock 341 260 559 minecraft:oak_log
fill 341 260 560 341 261 560 minecraft:green_terracotta
setblock 342 260 558 minecraft:oak_log
fill 342 260 559 342 262 559 minecraft:green_terracotta
setblock 342 260 598 minecraft:oak_log
fill 343 260 558 343 263 558 minecraft:green_terracotta
setblock 343 260 597 minecraft:oak_log
fill 343 260 598 343 263 598 minecraft:green_terracotta
setblock 344 260 597 minecraft:green_terracotta
setblock 347 260 558 minecraft:oak_log
fill 347 260 568 348 261 568 minecraft:oak_leaves[persistent=true]
setblock 348 260 558 minecraft:green_terracotta
setblock 348 260 598 minecraft:oak_leaves[persistent=true]
setblock 352 260 558 minecraft:oak_leaves[persistent=true]
fill 353 260 558 356 260 558 minecraft:green_terracotta
setblock 355 260 559 minecraft:green_terracotta
setblock 356 260 559 minecraft:oak_log
fill 356 260 560 356 263 560 minecraft:green_terracotta
setblock 357 260 558 minecraft:oak_log
fill 357 260 559 357 263 559 minecraft:green_terracotta
setblock 357 260 598 minecraft:oak_log
fill 358 260 558 358 263 558 minecraft:green_terracotta
setblock 358 260 561 minecraft:green_terracotta
fill 358 260 598 358 263 598 minecraft:green_terracotta
setblock 359 260 560 minecraft:green_terracotta
setblock 359 260 561 minecraft:oak_log
fill 359 260 582 359 266 582 minecraft:dark_oak_log
setblock 360 260 560 minecraft:oak_log
fill 360 260 561 363 260 561 minecraft:green_terracotta
setblock 361 260 559 minecraft:oak_log
fill 361 260 560 361 263 560 minecraft:green_terracotta
fill 361 260 562 362 260 562 minecraft:green_terracotta
fill 361 260 581 361 266 582 minecraft:dark_oak_log
setblock 362 260 558 minecraft:oak_log
fill 362 260 559 362 263 559 minecraft:green_terracotta
setblock 362 260 598 minecraft:oak_log
fill 363 260 558 363 263 558 minecraft:green_terracotta
setblock 363 260 562 minecraft:oak_log
fill 363 260 598 363 263 598 minecraft:green_terracotta
setblock 364 260 561 minecraft:oak_log
setblock 365 260 560 minecraft:oak_log
fill 365 260 561 365 262 561 minecraft:green_terracotta
setblock 366 260 559 minecraft:oak_log
fill 366 260 560 366 263 560 minecraft:green_terracotta
setblock 367 260 558 minecraft:oak_log
fill 367 260 559 367 263 559 minecraft:green_terracotta
setblock 367 260 562 minecraft:green_terracotta
setblock 367 260 598 minecraft:oak_log
fill 368 260 558 368 263 558 minecraft:green_terracotta
setblock 368 260 562 minecraft:oak_log
fill 368 260 563 368 262 563 minecraft:green_terracotta
fill 368 260 598 368 261 598 minecraft:green_terracotta
setblock 369 260 561 minecraft:oak_log
fill 369 260 562 369 263 562 minecraft:green_terracotta
setblock 369 260 566 minecraft:oak_log
setblock 370 260 560 minecraft:oak_log
fill 370 260 561 370 263 561 minecraft:green_terracotta
setblock 370 260 565 minecraft:oak_log
fill 370 260 566 370 263 566 minecraft:green_terracotta
fill 370 260 568 370 261 568 minecraft:green_terracotta
setblock 370 260 581 minecraft:green_terracotta
setblock 370 260 584 minecraft:green_terracotta
setblock 330 261 558 minecraft:green_terracotta
setblock 330 261 559 minecraft:oak_log
fill 330 261 560 330 264 560 minecraft:green_terracotta
setblock 330 261 563 minecraft:green_terracotta
setblock 330 261 564 minecraft:oak_log
fill 330 261 565 330 263 565 minecraft:green_terracotta
setblock 330 261 578 minecraft:oak_leaves[persistent=true]
setblock 330 261 583 minecraft:green_terracotta
setblock 330 261 584 minecraft:oak_log
fill 330 261 585 331 263 585 minecraft:green_terracotta
setblock 330 261 588 minecraft:green_terracotta
setblock 330 261 589 minecraft:oak_log
fill 330 261 590 330 264 590 minecraft:green_terracotta
setblock 331 261 558 minecraft:oak_log
fill 331 261 559 334 261 559 minecraft:green_terracotta
setblock 331 261 598 minecraft:oak_log
fill 332 261 558 335 261 558 minecraft:green_terracotta
fill 332 261 598 335 261 598 minecraft:green_terracotta
fill 334 261 597 336 261 597 minecraft:green_terracotta
setblock 335 261 559 minecraft:oak_log
setblock 336 261 558 minecraft:oak_log
fill 336 261 559 336 263 559 minecraft:green_terracotta
setblock 336 261 598 minecraft:oak_log
fill 337 261 558 337 264 558 minecraft:green_terracotta
setblock 337 261 597 minecraft:oak_log
fill 337 261 598 337 264 598 minecraft:green_terracotta
fill 338 261 597 338 264 597 minecraft:green_terracotta
setblock 339 261 560 minecraft:oak_log
setblock 340 261 559 minecraft:oak_log
setblock 340 261 560 minecraft:green_terracotta
setblock 341 261 558 minecraft:oak_log
fill 341 261 559 341 263 559 minecraft:green_terracotta
setblock 341 261 598 minecraft:oak_log
fill 342 261 558 342 263 558 minecraft:green_terracotta
setblock 342 261 597 minecraft:oak_log
fill 342 261 598 342 263 598 minecraft:green_terracotta
setblock 343 261 597 minecraft:green_terracotta
setblock 346 261 558 minecraft:oak_log
setblock 347 261 558 minecraft:green_terracotta
fill 353 261 558 355 261 558 minecraft:green_terracotta
setblock 354 261 559 minecraft:green_terracotta
setblock 354 261 598 minecraft:oak_leaves[persistent=true]
setblock 355 261 559 minecraft:oak_log
setblock 356 261 558 minecraft:oak_log
fill 356 261 559 356 264 559 minecraft:green_terracotta
fill 357 261 558 357 264 558 minecraft:green_terracotta
fill 357 261 598 357 262 598 minecraft:green_terracotta
setblock 358 261 561 minecraft:oak_log
setblock 359 261 560 minecraft:oak_log
fill 359 261 561 362 261 561 minecraft:green_terracotta
fill 359 261 581 359 266 581 minecraft:dark_oak_log
setblock 360 261 559 minecraft:oak_log
fill 360 261 560 360 264 560 minecraft:green_terracotta
fill 360 261 562 361 261 562 minecraft:green_terracotta
fill 360 261 580 360 266 580 minecraft:dark_oak_log
fill 360 261 583 360 266 583 minecraft:dark_oak_log
setblock 361 261 558 minecraft:oak_log
fill 361 261 559 361 264 559 minecraft:green_terracotta
setblock 361 261 598 minecraft:oak_log
fill 362 261 558 362 264 558 minecraft:green_terracotta
setblock 362 261 562 minecraft:oak_log
fill 362 261 598 362 263 598 minecraft:green_terracotta
setblock 363 261 561 minecraft:oak_log
setblock 363 261 562 minecraft:green_terracotta
setblock 364 261 560 minecraft:oak_log
fill 364 261 561 364 262 561 minecraft:green_terracotta
setblock 365 261 559 minecraft:oak_log
fill 365 261 560 365 263 560 minecraft:green_terracotta
setblock 366 261 558 minecraft:oak_log
fill 366 261 559 366 264 559 minecraft:green_terracotta
setblock 366 261 598 minecraft:oak_log
fill 367 261 558 367 264 558 minecraft:green_terracotta
setblock 367 261 598 minecraft:green_terracotta
setblock 368 261 561 minecraft:oak_log
fill 368 261 562 368 262 562 minecraft:green_terracotta
setblock 369 261 560 minecraft:oak_log
fill 369 261 561 369 264 561 minecraft:green_terracotta
setblock 369 261 565 minecraft:oak_log
fill 369 261 566 369 263 566 minecraft:green_terracotta
setblock 370 261 559 minecraft:oak_log
fill 370 261 560 370 264 560 minecraft:green_terracotta
setblock 370 261 564 minecraft:oak_log
fill 370 261 565 370 264 565 minecraft:green_terracotta
setblock 370 261 578 minecraft:oak_leaves[persistent=true]
setblock 370 261 583 minecraft:green_terracotta
setblock 370 261 584 minecraft:oak_log
setblock 330 262 558 minecraft:oak_log
fill 330 262 559 330 263 559 minecraft:green_terracotta
setblock 330 262 563 minecraft:oak_log
fill 330 262 564 330 264 564 minecraft:green_terracotta
setblock 330 262 583 minecraft:oak_log
fill 330 262 584 331 263 584 minecraft:green_terracotta
setblock 330 262 588 minecraft:oak_log
fill 330 262 589 330 265 589 minecraft:green_terracotta
fill 330 262 591 330 262 592 minecraft:green_terracotta
setblock 330 262 597 minecraft:green_terracotta
setblock 330 262 598 minecraft:oak_log
fill 331 262 558 334 262 558 minecraft:green_terracotta
setblock 331 262 586 minecraft:green_terracotta
setblock 331 262 587 minecraft:oak_log
fill 331 262 598 334 262 598 minecraft:green_terracotta
setblock 333 262 559 minecraft:green_terracotta
setblock 334 262 559 minecraft:oak_log
setblock 335 262 558 minecraft:oak_log
fill 335 262 559 335 263 559 minecraft:green_terracotta
setblock 335 262 597 minecraft:green_terracotta
setblock 335 262 598 minecraft:oak_log
fill 336 262 558 336 265 558 minecraft:green_terracotta
setblock 336 262 597 minecraft:oak_log
fill 336 262 598 336 265 598 minecraft:green_terracotta
fill 337 262 559 338 262 559 minecraft:green_terracotta
fill 337 262 597 337 264 597 minecraft:green_terracotta
setblock 339 262 559 minecraft:oak_log
setblock 339 262 560 minecraft:green_terracotta
setblock 340 262 558 minecraft:oak_log
fill 340 262 559 340 263 559 minecraft:green_terracotta
setblock 340 262 598 minecraft:oak_log
fill 341 262 558 341 264 558 minecraft:green_terracotta
setblock 341 262 597 minecraft:oak_log
fill 341 262 598 341 264 598 minecraft:green_terracotta
setblock 342 262 597 minecraft:green_terracotta
setblock 345 262 558 minecraft:oak_log
fill 353 262 558 354 262 558 minecraft:green_terracotta
fill 353 262 583 355 269 585 minecraft:oak_log
fill 354 262 582 355 273 582 minecraft:oak_log
setblock 355 262 558 minecraft:oak_log
fill 355 262 559 355 265 559 minecraft:green_terracotta
fill 356 262 558 356 265 558 minecraft:green_terracotta
setblock 357 262 561 minecraft:oak_log
setblock 358 262 560 minecraft:oak_log
fill 358 262 561 361 262 561 minecraft:green_terracotta
fill 358 262 582 358 266 582 minecraft:dark_oak_log
setblock 359 262 559 minecraft:oak_log
fill 359 262 560 359 265 560 minecraft:green_terracotta
fill 359 262 580 359 266 580 minecraft:dark_oak_log
fill 359 262 583 359 266 583 minecraft:dark_oak_log
setblock 360 262 558 minecraft:oak_log
fill 360 262 559 360 265 559 minecraft:green_terracotta
setblock 360 262 562 minecraft:green_terracotta
setblock 360 262 598 minecraft:oak_log
fill 361 262 558 361 265 558 minecraft:green_terracotta
setblock 361 262 562 minecraft:oak_log
fill 361 262 580 361 266 580 minecraft:dark_oak_log
fill 361 262 583 361 266 583 minecraft:dark_oak_log
fill 361 262 598 361 264 598 minecraft:green_terracotta
setblock 362 262 561 minecraft:oak_log
fill 362 262 581 362 266 582 minecraft:dark_oak_log
setblock 363 262 560 minecraft:oak_log
fill 363 262 561 363 263 561 minecraft:green_terracotta
setblock 364 262 559 minecraft:oak_log
fill 364 262 560 364 264 560 minecraft:green_terracotta
setblock 365 262 558 minecraft:oak_log
fill 365 262 559 365 264 559 minecraft:green_terracotta
setblock 365 262 598 minecraft:oak_log
fill 366 262 558 366 265 558 minecraft:green_terracotta
setblock 366 262 598 minecraft:green_terracotta
setblock 368 262 560 minecraft:oak_log
setblock 368 262 561 minecraft:green_terracotta
setblock 369 262 559 minecraft:oak_log
fill 369 262 560 369 264 560 minecraft:green_terracotta
setblock 369 262 564 minecraft:oak_log
fill 369 262 565 369 264 565 minecraft:green_terracotta
setblock 370 262 558 minecraft:oak_log
fill 370 262 559 370 265 559 minecraft:green_terracotta
setblock 370 262 563 minecraft:oak_log
fill 370 262 564 370 265 564 minecraft:green_terracotta
setblock 370 262 568 minecraft:oak_log
setblock 370 262 572 minecraft:oak_leaves[persistent=true]
setblock 370 262 597 minecraft:oak_leaves[persistent=true]
fill 330 263 558 333 263 558 minecraft:green_terracotta
setblock 330 263 562 minecraft:oak_log
fill 330 263 563 330 264 563 minecraft:green_terracotta
setblock 330 263 582 minecraft:oak_log
fill 330 263 583 330 265 583 minecraft:green_terracotta
setblock 330 263 587 minecraft:oak_log
fill 330 263 588 331 265 588 minecraft:green_terracotta
setblock 330 263 591 minecraft:green_terracotta
setblock 330 263 592 minecraft:oak_log
fill 330 263 598 333 263 598 minecraft:green_terracotta
setblock 331 263 586 minecraft:oak_log
fill 331 263 587 331 266 587 minecraft:green_terracotta
setblock 334 263 558 minecraft:oak_log
setblock 334 263 598 minecraft:oak_log
fill 335 263 558 335 265 558 minecraft:green_terracotta
fill 335 263 598 335 266 598 minecraft:green_terracotta
setblock 336 263 597 minecraft:green_terracotta
setblock 337 263 559 minecraft:green_terracotta
setblock 338 263 559 minecraft:oak_log
setblock 339 263 558 minecraft:oak_log
setblock 339 263 559 minecraft:green_terracotta
setblock 339 263 598 minecraft:oak_log
fill 340 263 558 340 264 558 minecraft:green_terracotta
setblock 340 263 597 minecraft:oak_log
fill 340 263 598 340 265 598 minecraft:green_terracotta
fill 353 263 558 353 264 558 minecraft:oak_leaves[persistent=true]
setblock 354 263 558 minecraft:oak_log
fill 355 263 558 355 266 558 minecraft:green_terracotta
setblock 357 263 560 minecraft:oak_log
setblock 358 263 559 minecraft:oak_log
fill 358 263 560 358 264 561 minecraft:green_terracotta
fill 358 263 580 358 266 581 minecraft:dark_oak_log
fill 358 263 583 358 266 583 minecraft:dark_oak_log
setblock 359 263 558 minecraft:oak_log
fill 359 263 559 359 266 559 minecraft:green_terracotta
fill 359 263 561 360 263 561 minecraft:green_terracotta
setblock 359 263 598 minecraft:oak_log
fill 360 263 558 360 266 558 minecraft:green_terracotta
fill 360 263 584 360 266 584 minecraft:dark_oak_log
fill 360 263 598 360 264 598 minecraft:green_terracotta
setblock 361 263 561 minecraft:oak_log
setblock 362 263 560 minecraft:oak_log
fill 362 263 561 362 264 561 minecraft:green_terracotta
fill 362 263 580 362 266 580 minecraft:dark_oak_log
fill 362 263 583 362 266 583 minecraft:dark_oak_log
setblock 363 263 559 minecraft:oak_log
fill 363 263 560 363 264 560 minecraft:green_terracotta
setblock 364 263 558 minecraft:oak_log
fill 364 263 559 364 265 559 minecraft:green_terracotta
setblock 364 263 598 minecraft:oak_log
fill 365 263 558 365 266 558 minecraft:green_terracotta
setblock 366 263 598 minecraft:oak_leaves[persistent=true]
setblock 368 263 559 minecraft:oak_log
setblock 369 263 558 minecraft:oak_log
setblock 369 263 559 minecraft:green_terracotta
setblock 369 263 563 minecraft:oak_log
fill 369 263 564 369 264 564 minecraft:green_terracotta
fill 370 263 558 370 265 558 minecraft:green_terracotta
setblock 370 263 562 minecraft:oak_log
fill 370 263 563 370 266 563 minecraft:green_terracotta
setblock 370 263 567 minecraft:oak_log
setblock 370 263 568 minecraft:green_terracotta
setblock 370 263 591 minecraft:oak_leaves[persistent=true]
setblock 330 264 561 minecraft:oak_log
setblock 330 264 562 minecraft:green_terracotta
setblock 330 264 571 minecraft:oak_leaves[persistent=true]
fill 330 264 584 330 264 585 minecraft:green_terracotta
setblock 330 264 586 minecraft:oak_log
fill 330 264 587 330 267 587 minecraft:green_terracotta
setblock 330 264 591 minecraft:oak_log
fill 330 264 592 330 267 592 minecraft:green_terracotta
setblock 330 264 596 minecraft:oak_leaves[persistent=true]
setblock 331 264 585 minecraft:oak_log
fill 331 264 586 331 267 586 minecraft:green_terracotta
setblock 331 264 589 minecraft:green_terracotta
setblock 332 264 598 minecraft:green_terracotta
setblock 333 264 558 minecraft:oak_log
setblock 333 264 598 minecraft:oak_log
setblock 334 264 558 minecraft:green_terracotta
fill 334 264 598 334 267 598 minecraft:green_terracotta
setblock 338 264 558 minecraft:oak_log
setblock 338 264 559 minecraft:green_terracotta
setblock 338 264 598 minecraft:oak_log
fill 339 264 558 339 265 558 minecraft:green_terracotta
fill 339 264 598 339 266 598 minecraft:green_terracotta
setblock 347 264 558 minecraft:oak_leaves[persistent=true]
setblock 347 264 598 minecraft:oak_leaves[persistent=true]
fill 354 264 558 354 265 558 minecraft:green_terracotta
setblock 356 264 560 minecraft:oak_log
setblock 357 264 559 minecraft:oak_log
fill 357 264 560 357 265 560 minecraft:green_terracotta
setblock 358 264 558 minecraft:oak_log
fill 358 264 559 358 267 559 minecraft:green_terracotta
fill 359 264 558 359 267 558 minecraft:green_terracotta
setblock 359 264 561 minecraft:green_terracotta
fill 359 264 579 361 266 579 minecraft:dark_oak_log
fill 359 264 584 359 266 584 minecraft:dark_oak_log
setblock 359 264 598 minecraft:green_terracotta
setblock 360 264 561 minecraft:oak_log
setblock 361 264 560 minecraft:oak_log
setblock 361 264 561 minecraft:green_terracotta
fill 361 264 584 361 266 584 minecraft:dark_oak_log
setblock 362 264 559 minecraft:oak_log
fill 362 264 560 362 265 560 minecraft:green_terracotta
setblock 363 264 558 minecraft:oak_log
fill 363 264 559 363 265 559 minecraft:green_terracotta
fill 363 264 581 363 266 582 minecraft:dark_oak_log
fill 364 264 558 364 266 558 minecraft:green_terracotta
setblock 367 264 559 minecraft:oak_log
setblock 368 264 558 minecraft:oak_log
fill 369 264 558 369 265 558 minecraft:green_terracotta
setblock 369 264 562 minecraft:oak_log
fill 369 264 563 369 265 563 minecraft:green_terracotta
setblock 370 264 561 minecraft:oak_log
fill 370 264 562 370 267 562 minecraft:green_terracotta
setblock 370 264 566 minecraft:oak_log
fill 370 264 567 370 267 567 minecraft:green_terracotta
fill 370 264 579 370 265 579 minecraft:oak_leaves[persistent=true]
setblock 370 264 585 minecraft:oak_leaves[persistent=true]
setblock 330 265 558 minecraft:oak_leaves[persistent=true]
setblock 330 265 577 minecraft:oak_leaves[persistent=true]
setblock 330 265 584 minecraft:green_terracotta
setblock 330 265 585 minecraft:oak_log
fill 330 265 586 330 268 586 minecraft:green_terracotta
setblock 330 265 590 minecraft:oak_log
fill 330 265 591 330 268 591 minecraft:green_terracotta
fill 330 265 593 330 266 593 minecraft:green_terracotta
fill 331 265 585 331 268 585 minecraft:green_terracotta
setblock 331 265 589 minecraft:oak_log
fill 331 265 590 331 268 590 minecraft:green_terracotta
setblock 332 265 560 minecraft:light[level=14]
setblock 332 265 568 minecraft:light[level=14]
setblock 332 265 576 minecraft:light[level=14]
setblock 332 265 584 minecraft:light[level=14]
setblock 332 265 592 minecraft:light[level=14]
fill 333 265 598 333 268 598 minecraft:green_terracotta
setblock 337 265 558 minecraft:oak_log
setblock 337 265 598 minecraft:oak_log
setblock 338 265 558 minecraft:green_terracotta
fill 338 265 598 338 267 598 minecraft:green_terracotta
setblock 340 265 560 minecraft:light[level=14]
setblock 340 265 568 minecraft:light[level=14]
setblock 340 265 576 minecraft:light[level=14]
setblock 340 265 584 minecraft:light[level=14]
setblock 340 265 592 minecraft:light[level=14]
setblock 341 265 558 minecraft:oak_leaves[persistent=true]
setblock 348 265 560 minecraft:light[level=14]
setblock 348 265 568 minecraft:light[level=14]
setblock 348 265 576 minecraft:light[level=14]
setblock 348 265 584 minecraft:light[level=14]
setblock 348 265 592 minecraft:light[level=14]
fill 350 265 582 350 273 582 minecraft:oak_log
setblock 353 265 598 minecraft:oak_leaves[persistent=true]
setblock 356 265 559 minecraft:oak_log
setblock 356 265 560 minecraft:light[level=14]
setblock 356 265 568 minecraft:light[level=14]
setblock 356 265 576 minecraft:light[level=14]
setblock 356 265 592 minecraft:light[level=14]
setblock 357 265 558 minecraft:oak_log
fill 357 265 559 357 268 559 minecraft:green_terracotta
fill 357 265 580 357 266 583 minecraft:dark_oak_log
fill 358 265 558 358 268 558 minecraft:green_terracotta
fill 358 265 560 358 266 560 minecraft:green_terracotta
fill 358 265 579 358 266 579 minecraft:dark_oak_log
fill 358 265 584 358 266 584 minecraft:dark_oak_log
fill 359 265 598 359 266 598 minecraft:oak_leaves[persistent=true]
setblock 360 265 560 minecraft:oak_log
fill 360 265 585 360 266 585 minecraft:dark_oak_log
setblock 361 265 559 minecraft:oak_log
setblock 361 265 560 minecraft:green_terracotta
setblock 362 265 558 minecraft:oak_log
fill 362 265 559 362 266 559 minecraft:green_terracotta
fill 362 265 579 362 266 579 minecraft:dark_oak_log
fill 362 265 584 362 266 584 minecraft:dark_oak_log
fill 363 265 558 363 267 558 minecraft:green_terracotta
fill 363 265 580 363 266 580 minecraft:dark_oak_log
fill 363 265 583 363 266 583 minecraft:dark_oak_log
setblock 364 265 560 minecraft:light[level=14]
setblock 364 265 568 minecraft:light[level=14]
setblock 364 265 576 minecraft:light[level=14]
setblock 364 265 584 minecraft:light[level=14]
setblock 364 265 592 minecraft:light[level=14]
setblock 367 265 558 minecraft:oak_log
setblock 368 265 558 minecraft:green_terracotta
setblock 370 265 560 minecraft:oak_log
fill 370 265 561 370 267 561 minecraft:green_terracotta
setblock 370 265 565 minecraft:oak_log
fill 370 265 566 370 268 566 minecraft:green_terracotta
setblock 370 265 573 minecraft:oak_leaves[persistent=true]
setblock 330 266 564 minecraft:oak_leaves[persistent=true]
setblock 330 266 583 minecraft:oak_leaves[persistent=true]
setblock 330 266 584 minecraft:oak_log
fill 330 266 585 330 269 585 minecraft:green_terracotta
setblock 330 266 588 minecraft:green_terracotta
setblock 330 266 589 minecraft:oak_log
fill 330 266 590 330 269 590 minecraft:green_terracotta
setblock 331 266 588 minecraft:oak_log
fill 331 266 589 331 269 589 minecraft:green_terracotta
fill 331 266 591 331 267 591 minecraft:green_terracotta
setblock 335 266 558 minecraft:oak_leaves[persistent=true]
setblock 336 266 598 minecraft:oak_log
fill 337 266 598 337 269 598 minecraft:green_terracotta
setblock 340 266 598 minecraft:oak_leaves[persistent=true]
setblock 356 266 558 minecraft:oak_log
fill 356 266 559 356 267 559 minecraft:green_terracotta
fill 357 266 558 357 269 558 minecraft:green_terracotta
setblock 357 266 579 minecraft:dark_oak_log
setblock 357 266 584 minecraft:dark_oak_log
setblock 359 266 560 minecraft:oak_log
fill 359 266 578 361 266 578 minecraft:dark_oak_log
setblock 359 266 585 minecraft:dark_oak_log
setblock 360 266 559 minecraft:oak_log
setblock 360 266 560 minecraft:green_terracotta
setblock 361 266 558 minecraft:oak_log
setblock 361 266 559 minecraft:green_terracotta
fill 361 266 585 362 266 585 minecraft:dark_oak_log
fill 362 266 558 362 268 558 minecraft:green_terracotta
setblock 363 266 579 minecraft:dark_oak_log
setblock 363 266 584 minecraft:dark_oak_log
setblock 365 266 598 minecraft:oak_leaves[persistent=true]
setblock 370 266 560 minecraft:green_terracotta
setblock 370 266 564 minecraft:oak_log
fill 370 266 565 370 269 565 minecraft:green_terracotta
setblock 370 266 592 minecraft:oak_leaves[persistent=true]
setblock 330 267 570 minecraft:oak_leaves[persistent=true]
fill 330 267 584 330 270 584 minecraft:green_terracotta
setblock 330 267 588 minecraft:oak_log
fill 330 267 589 330 270 589 minecraft:green_terracotta
setblock 330 267 593 minecraft:oak_log
fill 330 267 594 330 270 594 minecraft:green_terracotta
setblock 330 267 595 minecraft:oak_leaves[persistent=true]
setblock 331 267 587 minecraft:oak_log
fill 331 267 588 332 269 588 minecraft:green_terracotta
setblock 331 267 592 minecraft:oak_log
fill 332 267 587 332 270 587 minecraft:green_terracotta
fill 332 267 589 332 267 590 minecraft:green_terracotta
setblock 335 267 598 minecraft:oak_log
fill 336 267 598 336 270 598 minecraft:green_terracotta
setblock 346 267 598 minecraft:oak_leaves[persistent=true]
fill 350 267 569 350 268 570 minecraft:oak_leaves[persistent=true]
setblock 354 267 558 minecraft:oak_leaves[persistent=true]
setblock 355 267 558 minecraft:oak_log
fill 356 267 558 356 270 558 minecraft:green_terracotta
setblock 359 267 559 minecraft:oak_log
setblock 360 267 558 minecraft:oak_log
setblock 360 267 559 minecraft:green_terracotta
fill 360 267 581 360 269 582 minecraft:oak_log
fill 361 267 558 361 270 558 minecraft:green_terracotta
setblock 370 267 563 minecraft:oak_log
fill 370 267 564 370 270 564 minecraft:green_terracotta
setblock 370 267 586 minecraft:oak_leaves[persistent=true]
setblock 370 267 588 minecraft:oak_log
fill 370 267 589 370 268 591 minecraft:green_terracotta
setblock 330 268 576 minecraft:oak_leaves[persistent=true]
setblock 330 268 587 minecraft:oak_log
fill 330 268 588 330 271 588 minecraft:green_terracotta
setblock 330 268 592 minecraft:oak_log
fill 330 268 593 331 270 593 minecraft:green_terracotta
fill 330 268 595 330 269 595 minecraft:green_terracotta
setblock 331 268 586 minecraft:oak_log
fill 331 268 587 331 271 587 minecraft:green_terracotta
setblock 331 268 591 minecraft:oak_log
fill 331 268 592 331 271 592 minecraft:green_terracotta
setblock 332 268 589 minecraft:green_terracotta
setblock 332 268 590 minecraft:oak_log
fill 332 268 591 332 271 591 minecraft:green_terracotta
setblock 334 268 598 minecraft:oak_log
fill 335 268 598 335 271 598 minecraft:green_terracotta
setblock 348 268 558 minecraft:oak_leaves[persistent=true]
setblock 352 268 598 minecraft:oak_leaves[persistent=true]
setblock 354 268 558 minecraft:oak_log
fill 355 268 558 355 271 558 minecraft:green_terracotta
setblock 358 268 559 minecraft:oak_log
setblock 359 268 558 minecraft:oak_log
setblock 359 268 559 minecraft:green_terracotta
fill 360 268 558 360 271 558 minecraft:green_terracotta
setblock 367 268 558 minecraft:oak_leaves[persistent=true]
setblock 370 268 562 minecraft:oak_log
fill 370 268 563 370 271 563 minecraft:green_terracotta
setblock 370 268 567 minecraft:oak_log
fill 370 268 568 370 271 568 minecraft:green_terracotta
setblock 370 268 580 minecraft:oak_leaves[persistent=true]
setblock 370 268 587 minecraft:oak_log
fill 370 268 588 370 271 588 minecraft:green_terracotta
setblock 370 268 592 minecraft:oak_log
fill 370 268 593 370 271 593 minecraft:green_terracotta
setblock 330 269 563 minecraft:oak_leaves[persistent=true]
setblock 330 269 582 minecraft:oak_leaves[persistent=true]
setblock 330 269 586 minecraft:oak_log
fill 330 269 587 330 272 587 minecraft:green_terracotta
setblock 330 269 591 minecraft:oak_log
fill 330 269 592 330 272 592 minecraft:green_terracotta
setblock 330 269 596 minecraft:oak_log
fill 330 269 597 330 272 597 minecraft:green_terracotta
setblock 331 269 585 minecraft:oak_log
fill 331 269 586 332 271 586 minecraft:green_terracotta
setblock 331 269 590 minecraft:oak_log
fill 331 269 591 331 272 591 minecraft:green_terracotta
setblock 331 269 594 minecraft:green_terracotta
setblock 331 269 595 minecraft:oak_log
fill 331 269 598 332 269 598 minecraft:green_terracotta
setblock 332 269 589 minecraft:oak_log
fill 332 269 590 332 272 590 minecraft:green_terracotta
fill 332 269 592 332 269 593 minecraft:green_terracotta
fill 333 269 589 333 272 589 minecraft:green_terracotta
setblock 333 269 598 minecraft:oak_log
fill 334 269 598 334 272 598 minecraft:green_terracotta
setblock 339 269 598 minecraft:oak_leaves[persistent=true]
setblock 342 269 558 minecraft:oak_leaves[persistent=true]
fill 354 269 558 354 272 558 minecraft:green_terracotta
setblock 356 269 559 minecraft:green_terracotta
setblock 357 269 559 minecraft:oak_log
setblock 358 269 558 minecraft:oak_log
fill 358 269 559 358 272 559 minecraft:green_terracotta
setblock 358 269 598 minecraft:oak_leaves[persistent=true]
fill 359 269 558 359 272 558 minecraft:green_terracotta
fill 370 269 562 370 272 562 minecraft:green_terracotta
setblock 370 269 566 minecraft:oak_log
fill 370 269 567 370 272 567 minecraft:green_terracotta
fill 370 269 569 370 270 569 minecraft:green_terracotta
setblock 370 269 574 minecraft:oak_leaves[persistent=true]
fill 370 269 587 370 272 587 minecraft:green_terracotta
fill 370 269 589 370 269 590 minecraft:green_terracotta
setblock 370 269 591 minecraft:oak_log
fill 370 269 592 370 272 592 minecraft:green_terracotta
fill 370 269 594 370 269 595 minecraft:green_terracotta
setblock 370 269 596 minecraft:oak_log
fill 330 270 564 331 270 565 minecraft:oak_leaves[persistent=true]
fill 330 270 566 330 270 569 minecraft:green_terracotta
setblock 330 270 570 minecraft:oak_log
fill 330 270 583 330 271 583 minecraft:green_terracotta
setblock 330 270 585 minecraft:oak_log
fill 330 270 586 330 273 586 minecraft:green_terracotta
setblock 330 270 590 minecraft:oak_log
fill 330 270 591 330 273 591 minecraft:green_terracotta
setblock 330 270 595 minecraft:oak_log
fill 330 270 596 331 272 596 minecraft:green_terracotta
fill 330 270 598 331 270 598 minecraft:green_terracotta
fill 331 270 563 335 270 563 minecraft:oak_leaves[persistent=true]
fill 331 270 566 331 271 567 minecraft:oak_leaves[persistent=true]
setblock 331 270 584 minecraft:oak_log
fill 331 270 585 331 273 585 minecraft:green_terracotta
setblock 331 270 588 minecraft:green_terracotta
setblock 331 270 589 minecraft:oak_log
fill 331 270 590 331 273 590 minecraft:green_terracotta
setblock 331 270 594 minecraft:oak_log
fill 331 270 595 331 273 595 minecraft:green_terracotta
fill 332 270 567 334 270 568 minecraft:oak_leaves[persistent=true]
setblock 332 270 588 minecraft:oak_log
fill 332 270 589 332 273 589 minecraft:green_terracotta
setblock 332 270 592 minecraft:green_terracotta
setblock 332 270 593 minecraft:oak_log
fill 332 270 594 332 273 594 minecraft:green_terracotta
setblock 332 270 598 minecraft:oak_log
setblock 333 270 562 minecraft:oak_leaves[persistent=true]
fill 333 270 588 333 273 588 minecraft:green_terracotta
fill 333 270 590 333 270 591 minecraft:green_terracotta
setblock 333 270 592 minecraft:oak_log
setblock 333 270 597 minecraft:oak_log
fill 333 270 598 333 273 598 minecraft:green_terracotta
fill 334 270 590 335 270 591 minecraft:oak_leaves[persistent=true]
fill 334 270 597 335 272 597 minecraft:green_terracotta
fill 335 270 564 335 270 567 minecraft:oak_leaves[persistent=true]
fill 335 270 588 335 270 589 minecraft:oak_leaves[persistent=true]
fill 335 270 592 339 270 592 minecraft:oak_leaves[persistent=true]
setblock 336 270 558 minecraft:oak_leaves[persistent=true]
setblock 336 270 565 minecraft:oak_leaves[persistent=true]
fill 336 270 588 338 270 588 minecraft:oak_leaves[persistent=true]
fill 336 270 593 338 270 593 minecraft:oak_leaves[persistent=true]
setblock 337 270 598 minecraft:oak_log
fill 338 270 589 339 270 589 minecraft:oak_leaves[persistent=true]
fill 339 270 590 339 271 591 minecraft:oak_leaves[persistent=true]
setblock 345 270 598 minecraft:oak_leaves[persistent=true]
fill 348 270 581 348 270 585 minecraft:oak_leaves[persistent=true]
fill 349 270 581 349 271 582 minecraft:oak_leaves[persistent=true]
fill 349 270 585 353 270 586 minecraft:oak_leaves[persistent=true]
fill 352 270 587 357 270 587 minecraft:oak_leaves[persistent=true]
fill 353 270 558 353 273 558 minecraft:green_terracotta
fill 353 270 583 353 271 584 minecraft:oak_leaves[persistent=true]
fill 353 270 588 355 270 588 minecraft:oak_leaves[persistent=true]
fill 354 270 583 355 273 585 minecraft:oak_log
fill 355 270 580 356 270 581 minecraft:oak_leaves[persistent=true]
fill 355 270 586 357 271 586 minecraft:oak_leaves[persistent=true]
fill 355 270 591 356 270 592 minecraft:oak_leaves[persistent=true]
setblock 356 270 559 minecraft:oak_log
fill 356 270 582 361 271 582 minecraft:oak_leaves[persistent=true]
fill 356 270 589 357 270 590 minecraft:oak_leaves[persistent=true]
fill 356 270 593 357 270 594 minecraft:oak_leaves[persistent=true]
setblock 356 270 598 minecraft:green_terracotta
setblock 357 270 558 minecraft:oak_log
fill 357 270 559 357 273 559 minecraft:green_terracotta
setblock 357 270 581 minecraft:oak_leaves[persistent=true]
fill 357 270 583 358 270 585 minecraft:oak_leaves[persistent=true]
setblock 357 270 598 minecraft:oak_log
fill 358 270 558 358 273 558 minecraft:green_terracotta
fill 358 270 589 360 270 589 minecraft:oak_leaves[persistent=true]
fill 358 270 594 359 270 595 minecraft:oak_leaves[persistent=true]
fill 359 270 580 361 272 581 minecraft:oak_leaves[persistent=true]
fill 359 270 583 361 272 583 minecraft:oak_leaves[persistent=true]
fill 360 270 590 361 270 590 minecraft:oak_leaves[persistent=true]
fill 360 270 593 361 270 594 minecraft:oak_leaves[persistent=true]
fill 361 270 591 361 271 592 minecraft:oak_leaves[persistent=true]
setblock 364 270 598 minecraft:oak_leaves[persistent=true]
setblock 370 270 565 minecraft:oak_log
fill 370 270 566 370 273 566 minecraft:green_terracotta
setblock 370 270 570 minecraft:oak_log
fill 370 270 586 370 273 586 minecraft:green_terracotta
setblock 370 270 589 minecraft:green_terracotta
setblock 370 270 590 minecraft:oak_log
fill 370 270 591 370 273 591 minecraft:green_terracotta
setblock 370 270 594 minecraft:green_terracotta
setblock 370 270 595 minecraft:oak_log
fill 370 270 596 370 271 598 minecraft:green_terracotta
fill 330 271 565 330 271 568 minecraft:green_terracotta
setblock 330 271 569 minecraft:oak_log
fill 330 271 570 330 271 573 minecraft:green_terracotta
setblock 330 271 574 minecraft:oak_log
setblock 330 271 575 minecraft:oak_leaves[persistent=true]
fill 330 271 582 330 272 582 minecraft:green_terracotta
setblock 330 271 584 minecraft:oak_log
fill 330 271 585 330 273 585 minecraft:green_terracotta
setblock 330 271 589 minecraft:oak_log
fill 330 271 590 330 273 590 minecraft:green_terracotta
setblock 330 271 593 minecraft:green_terracotta
setblock 330 271 594 minecraft:oak_log
fill 330 271 595 330 273 595 minecraft:green_terracotta
setblock 330 271 598 minecraft:green_terracotta
fill 331 271 564 331 272 565 minecraft:oak_leaves[persistent=true]
fill 331 271 569 331 273 570 minecraft:green_terracotta
fill 331 271 584 331 273 584 minecraft:green_terracotta
setblock 331 271 588 minecraft:oak_log
fill 331 271 589 331 273 589 minecraft:green_terracotta
setblock 331 271 593 minecraft:oak_log
fill 331 271 594 331 273 594 minecraft:green_terracotta
setblock 331 271 597 minecraft:green_terracotta
setblock 331 271 598 minecraft:oak_log
fill 332 271 563 334 271 563 minecraft:oak_leaves[persistent=true]
fill 332 271 567 334 272 567 minecraft:oak_leaves[persistent=true]
fill 332 271 585 332 272 585 minecraft:green_terracotta
setblock 332 271 587 minecraft:oak_log
fill 332 271 588 332 273 588 minecraft:green_terracotta
setblock 332 271 592 minecraft:oak_log
fill 332 271 593 333 273 593 minecraft:green_terracotta
fill 332 271 595 332 272 595 minecraft:green_terracotta
setblock 332 271 597 minecraft:oak_log
fill 332 271 598 332 273 598 minecraft:green_terracotta
fill 333 271 587 333 273 587 minecraft:green_terracotta
setblock 333 271 590 minecraft:green_terracotta
setblock 333 271 591 minecraft:oak_log
fill 333 271 592 333 273 592 minecraft:green_terracotta
setblock 333 271 596 minecraft:oak_log
fill 333 271 597 333 273 597 minecraft:green_terracotta
fill 334 271 596 334 273 596 minecraft:green_terracotta
fill 335 271 564 335 271 566 minecraft:oak_leaves[persistent=true]
fill 335 271 589 335 271 592 minecraft:oak_leaves[persistent=true]
fill 336 271 588 337 271 588 minecraft:oak_leaves[persistent=true]
fill 336 271 592 338 271 592 minecraft:oak_leaves[persistent=true]
setblock 336 271 597 minecraft:green_terracotta
setblock 336 271 598 minecraft:oak_log
fill 337 271 598 338 273 598 minecraft:green_terracotta
fill 338 271 589 338 272 589 minecraft:oak_leaves[persistent=true]
fill 348 271 582 348 271 584 minecraft:oak_leaves[persistent=true]
setblock 349 271 558 minecraft:oak_leaves[persistent=true]
fill 349 271 585 352 272 585 minecraft:oak_leaves[persistent=true]
fill 350 271 586 353 271 586 minecraft:oak_leaves[persistent=true]
setblock 351 271 598 minecraft:oak_leaves[persistent=true]
fill 352 271 558 352 273 558 minecraft:green_terracotta
fill 353 271 585 353 273 585 minecraft:oak_log
fill 353 271 587 355 271 587 minecraft:oak_leaves[persistent=true]
setblock 354 271 559 minecraft:green_terracotta
fill 354 271 598 355 271 598 minecraft:green_terracotta
setblock 355 271 559 minecraft:oak_log
fill 355 271 581 356 271 581 minecraft:oak_leaves[persistent=true]
setblock 356 271 558 minecraft:oak_log
fill 356 271 559 356 273 559 minecraft:green_terracotta
fill 356 271 590 356 271 593 minecraft:oak_leaves[persistent=true]
setblock 356 271 598 minecraft:oak_log
fill 357 271 558 357 273 558 minecraft:green_terracotta
fill 357 271 583 357 271 585 minecraft:oak_leaves[persistent=true]
fill 357 271 589 357 271 590 minecraft:oak_leaves[persistent=true]
fill 357 271 593 357 271 594 minecraft:oak_leaves[persistent=true]
fill 357 271 598 360 271 598 minecraft:green_terracotta
setblock 358 271 581 minecraft:oak_leaves[persistent=true]
fill 358 271 589 359 271 589 minecraft:oak_leaves[persistent=true]
fill 358 271 594 360 271 594 minecraft:oak_leaves[persistent=true]
fill 360 271 590 360 272 590 minecraft:oak_leaves[persistent=true]
fill 360 271 593 361 271 593 minecraft:oak_leaves[persistent=true]
setblock 361 271 558 minecraft:oak_log
fill 362 271 581 362 271 582 minecraft:oak_leaves[persistent=true]
fill 368 271 598 369 272 598 minecraft:green_terracotta
setblock 369 271 589 minecraft:green_terracotta
setblock 369 271 590 minecraft:oak_log
fill 369 271 591 369 271 594 minecraft:green_terracotta
setblock 369 271 595 minecraft:oak_log
setblock 370 271 558 minecraft:green_terracotta
fill 370 271 561 370 273 561 minecraft:green_terracotta
setblock 370 271 564 minecraft:oak_log
fill 370 271 565 370 273 565 minecraft:green_terracotta
setblock 370 271 569 minecraft:oak_log
fill 370 271 570 370 272 572 minecraft:green_terracotta
setblock 370 271 581 minecraft:oak_leaves[persistent=true]
fill 370 271 585 370 273 585 minecraft:green_terracotta
setblock 370 271 589 minecraft:oak_log
fill 370 271 590 370 273 590 minecraft:green_terracotta
setblock 370 271 594 minecraft:oak_log
fill 370 271 595 370 273 595 minecraft:green_terracotta
fill 330 272 565 330 272 567 minecraft:green_terracotta
setblock 330 272 568 minecraft:oak_log
fill 330 272 569 330 272 572 minecraft:green_terracotta
setblock 330 272 573 minecraft:oak_log
fill 330 272 574 330 272 577 minecraft:green_terracotta
setblock 330 272 578 minecraft:oak_log
fill 330 272 579 330 273 581 minecraft:green_terracotta
setblock 330 272 583 minecraft:oak_log
fill 330 272 584 330 273 584 minecraft:green_terracotta
setblock 330 272 588 minecraft:oak_log
fill 330 272 589 330 273 589 minecraft:green_terracotta
setblock 330 272 593 minecraft:oak_log
fill 330 272 594 330 273 594 minecraft:green_terracotta
setblock 330 272 598 minecraft:oak_log
setblock 331 272 566 minecraft:oak_leaves[persistent=true]
setblock 331 272 567 minecraft:oak_log
fill 331 272 568 331 273 568 minecraft:green_terracotta
setblock 331 272 571 minecraft:green_terracotta
setblock 331 272 572 minecraft:oak_log
fill 331 272 573 331 273 574 minecraft:green_terracotta
fill 331 272 583 331 273 583 minecraft:green_terracotta
setblock 331 272 586 minecraft:green_terracotta
setblock 331 272 587 minecraft:oak_log
fill 331 272 588 331 273 588 minecraft:green_terracotta
setblock 331 272 592 minecraft:oak_log
fill 331 272 593 331 273 593 minecraft:green_terracotta
setblock 331 272 597 minecraft:oak_log
fill 331 272 598 331 273 598 minecraft:green_terracotta
setblock 332 272 586 minecraft:oak_log
fill 332 272 587 332 273 587 minecraft:green_terracotta
setblock 332 272 591 minecraft:oak_log
fill 332 272 592 332 273 592 minecraft:green_terracotta
setblock 332 272 596 minecraft:oak_log
fill 332 272 597 332 273 597 minecraft:green_terracotta
setblock 333 272 563 minecraft:oak_leaves[persistent=true]
setblock 333 272 590 minecraft:oak_log
fill 333 272 591 333 273 591 minecraft:green_terracotta
setblock 333 272 594 minecraft:green_terracotta
fill 333 272 596 333 273 596 minecraft:green_terracotta
setblock 335 272 565 minecraft:oak_leaves[persistent=true]
fill 335 272 590 335 272 591 minecraft:oak_leaves[persistent=true]
fill 335 272 596 335 273 596 minecraft:green_terracotta
setblock 335 272 598 minecraft:oak_log
fill 336 272 592 337 272 592 minecraft:oak_leaves[persistent=true]
setblock 336 272 597 minecraft:oak_log
fill 336 272 598 336 273 598 minecraft:green_terracotta
fill 337 272 597 337 273 597 minecraft:green_terracotta
setblock 343 272 558 minecraft:oak_leaves[persistent=true]
setblock 349 272 582 minecraft:oak_leaves[persistent=true]
fill 351 272 558 351 273 558 minecraft:green_terracotta
fill 352 272 598 354 272 598 minecraft:green_terracotta
setblock 353 272 559 minecraft:green_terracotta
fill 353 272 583 353 273 584 minecraft:oak_log
setblock 353 272 586 minecraft:oak_leaves[persistent=true]
setblock 354 272 559 minecraft:oak_log
setblock 355 272 558 minecraft:oak_log
fill 355 272 559 355 273 559 minecraft:green_terracotta
setblock 355 272 581 minecraft:oak_leaves[persistent=true]
fill 355 272 586 356 272 586 minecraft:oak_leaves[persistent=true]
setblock 355 272 597 minecraft:green_terracotta
setblock 355 272 598 minecraft:oak_log
fill 356 272 558 356 273 558 minecraft:green_terracotta
setblock 356 272 582 minecraft:oak_leaves[persistent=true]
setblock 356 272 592 minecraft:oak_leaves[persistent=true]
setblock 356 272 597 minecraft:oak_log
fill 356 272 598 359 272 598 minecraft:green_terracotta
fill 357 272 583 357 272 584 minecraft:oak_leaves[persistent=true]
setblock 357 272 590 minecraft:oak_leaves[persistent=true]
setblock 357 272 593 minecraft:oak_leaves[persistent=true]
fill 357 272 597 357 273 597 minecraft:green_terracotta
setblock 358 272 594 minecraft:oak_leaves[persistent=true]
fill 359 272 582 361 272 582 minecraft:oak_leaves[persistent=true]
setblock 360 272 558 minecraft:oak_log
setblock 360 272 593 minecraft:oak_leaves[persistent=true]
setblock 360 272 598 minecraft:oak_log
fill 361 272 558 362 273 558 minecraft:green_terracotta
fill 361 272 598 362 273 598 minecraft:green_terracotta
setblock 365 272 598 minecraft:oak_log
fill 366 272 598 367 273 598 minecraft:green_terracotta
setblock 368 272 558 minecraft:oak_leaves[persistent=true]
fill 368 272 597 370 272 597 minecraft:green_terracotta
setblock 369 272 558 minecraft:green_terracotta
setblock 369 272 588 minecraft:green_terracotta
setblock 369 272 589 minecraft:oak_log
fill 369 272 590 369 272 593 minecraft:green_terracotta
setblock 369 272 594 minecraft:oak_log
fill 369 272 595 369 273 596 minecraft:green_terracotta
setblock 370 272 558 minecraft:oak_log
fill 370 272 559 370 273 560 minecraft:green_terracotta
setblock 370 272 563 minecraft:oak_log
fill 370 272 564 370 273 564 minecraft:green_terracotta
setblock 370 272 568 minecraft:oak_log
fill 370 272 569 370 273 569 minecraft:green_terracotta
setblock 370 272 573 minecraft:oak_log
fill 370 272 574 370 273 574 minecraft:green_terracotta
setblock 370 272 575 minecraft:oak_leaves[persistent=true]
setblock 370 272 588 minecraft:oak_log
fill 370 272 589 370 273 589 minecraft:green_terracotta
setblock 370 272 593 minecraft:oak_log
fill 370 272 594 370 273 594 minecraft:green_terracotta
fill 370 272 596 370 273 596 minecraft:green_terracotta
setblock 370 272 598 minecraft:oak_log
setblock 330 273 562 minecraft:oak_leaves[persistent=true]
fill 330 273 564 330 273 566 minecraft:green_terracotta
setblock 330 273 567 minecraft:oak_log
fill 330 273 568 330 273 571 minecraft:green_terracotta
setblock 330 273 572 minecraft:oak_log
fill 330 273 573 330 273 576 minecraft:green_terracotta
setblock 330 273 577 minecraft:oak_log
fill 330 273 578 331 273 578 minecraft:green_terracotta
setblock 330 273 582 minecraft:oak_log
setblock 330 273 583 minecraft:green_terracotta
setblock 330 273 587 minecraft:oak_log
setblock 330 273 588 minecraft:green_terracotta
setblock 330 273 592 minecraft:oak_log
setblock 330 273 593 minecraft:green_terracotta
setblock 330 273 596 minecraft:green_terracotta
setblock 330 273 597 minecraft:oak_log
setblock 330 273 598 minecraft:green_terracotta
setblock 331 273 567 minecraft:green_terracotta
setblock 331 273 571 minecraft:oak_log
fill 331 273 572 332 273 572 minecraft:green_terracotta
setblock 331 273 575 minecraft:green_terracotta
setblock 331 273 576 minecraft:oak_log
setblock 331 273 577 minecraft:green_terracotta
fill 331 273 579 331 273 580 minecraft:green_terracotta
setblock 331 273 581 minecraft:oak_log
setblock 331 273 582 minecraft:green_terracotta
setblock 331 273 586 minecraft:oak_log
setblock 331 273 587 minecraft:green_terracotta
setblock 331 273 591 minecraft:oak_log
setblock 331 273 592 minecraft:green_terracotta
setblock 331 273 596 minecraft:oak_log
setblock 331 273 597 minecraft:green_terracotta
fill 332 273 558 333 273 558 minecraft:green_terracotta
setblock 332 273 560 minecraft:light[level=14]
setblock 332 273 568 minecraft:light[level=14]
setblock 332 273 569 minecraft:green_terracotta
setblock 332 273 570 minecraft:oak_log
setblock 332 273 571 minecraft:green_terracotta
fill 332 273 573 332 273 574 minecraft:green_terracotta
setblock 332 273 575 minecraft:oak_log
setblock 332 273 576 minecraft:light[level=14]
setblock 332 273 584 minecraft:green_terracotta
setblock 332 273 585 minecraft:oak_log
setblock 332 273 586 minecraft:green_terracotta
setblock 332 273 590 minecraft:oak_log
setblock 332 273 591 minecraft:green_terracotta
setblock 332 273 595 minecraft:oak_log
setblock 332 273 596 minecraft:green_terracotta
setblock 333 273 589 minecraft:oak_log
setblock 333 273 590 minecraft:green_terracotta
setblock 333 273 594 minecraft:oak_log
fill 333 273 595 334 273 595 minecraft:green_terracotta
setblock 334 273 558 minecraft:oak_log
setblock 334 273 597 minecraft:green_terracotta
setblock 334 273 598 minecraft:oak_log
setblock 335 273 597 minecraft:oak_log
setblock 335 273 598 minecraft:green_terracotta
setblock 336 273 596 minecraft:oak_log
setblock 336 273 597 minecraft:green_terracotta
setblock 337 273 558 minecraft:oak_leaves[persistent=true]
setblock 339 273 598 minecraft:oak_log
setblock 340 273 560 minecraft:light[level=14]
setblock 340 273 568 minecraft:light[level=14]
setblock 340 273 576 minecraft:light[level=14]
setblock 340 273 584 minecraft:light[level=14]
setblock 340 273 592 minecraft:light[level=14]
setblock 348 273 560 minecraft:light[level=14]
setblock 348 273 568 minecraft:light[level=14]
setblock 348 273 576 minecraft:light[level=14]
setblock 348 273 584 minecraft:light[level=14]
setblock 348 273 592 minecraft:light[level=14]
setblock 350 273 558 minecraft:green_terracotta
fill 350 273 598 353 273 598 minecraft:green_terracotta
setblock 352 273 559 minecraft:green_terracotta
fill 352 273 597 354 273 597 minecraft:green_terracotta
setblock 353 273 559 minecraft:oak_log
setblock 354 273 558 minecraft:oak_log
setblock 354 273 559 minecraft:green_terracotta
setblock 354 273 598 minecraft:oak_log
setblock 355 273 558 minecraft:green_terracotta
setblock 355 273 597 minecraft:oak_log
fill 355 273 598 358 273 598 minecraft:green_terracotta
setblock 356 273 560 minecraft:light[level=14]
setblock 356 273 568 minecraft:light[level=14]
setblock 356 273 576 minecraft:light[level=14]
setblock 356 273 592 minecraft:light[level=14]
setblock 356 273 597 minecraft:green_terracotta
setblock 358 273 559 minecraft:oak_log
fill 358 273 597 359 273 597 minecraft:green_terracotta
setblock 359 273 558 minecraft:oak_log
setblock 359 273 598 minecraft:oak_log
setblock 360 273 558 minecraft:green_terracotta
setblock 360 273 598 minecraft:green_terracotta
setblock 363 273 558 minecraft:green_terracotta
setblock 363 273 598 minecraft:green_terracotta
setblock 364 273 560 minecraft:light[level=14]
setblock 364 273 568 minecraft:light[level=14]
setblock 364 273 576 minecraft:light[level=14]
setblock 364 273 584 minecraft:light[level=14]
setblock 364 273 592 minecraft:light[level=14]
setblock 364 273 598 minecraft:oak_log
setblock 365 273 598 minecraft:green_terracotta
fill 366 273 597 369 273 597 minecraft:green_terracotta
fill 367 273 558 368 273 558 minecraft:green_terracotta
fill 368 273 591 368 273 593 minecraft:green_terracotta
setblock 368 273 594 minecraft:oak_log
setblock 368 273 595 minecraft:green_terracotta
setblock 368 273 598 minecraft:green_terracotta
setblock 369 273 558 minecraft:oak_log
setblock 369 273 568 minecraft:oak_log
fill 369 273 569 369 273 571 minecraft:green_terracotta
setblock 369 273 587 minecraft:green_terracotta
setblock 369 273 588 minecraft:oak_log
fill 369 273 589 369 273 592 minecraft:green_terracotta
setblock 369 273 593 minecraft:oak_log
setblock 369 273 594 minecraft:green_terracotta
setblock 369 273 598 minecraft:oak_log
setblock 370 273 558 minecraft:green_terracotta
setblock 370 273 562 minecraft:oak_log
setblock 370 273 563 minecraft:green_terracotta
setblock 370 273 567 minecraft:oak_log
setblock 370 273 568 minecraft:green_terracotta
fill 370 273 570 370 273 571 minecraft:green_terracotta
setblock 370 273 572 minecraft:oak_log
setblock 370 273 573 minecraft:green_terracotta
fill 370 273 575 370 273 576 minecraft:green_terracotta
setblock 370 273 584 minecraft:green_terracotta
setblock 370 273 587 minecraft:oak_log
setblock 370 273 588 minecraft:green_terracotta
setblock 370 273 592 minecraft:oak_log
setblock 370 273 593 minecraft:green_terracotta
setblock 370 273 597 minecraft:oak_log
setblock 370 273 598 minecraft:green_terracotta
fill 336 279 580 349 279 580 minecraft:jungle_leaves[persistent=true]
fill 337 279 575 350 279 579 minecraft:jungle_leaves[persistent=true]
fill 337 279 581 350 279 585 minecraft:jungle_leaves[persistent=true]
fill 338 279 573 366 279 574 minecraft:jungle_leaves[persistent=true]
fill 338 279 586 366 279 587 minecraft:jungle_leaves[persistent=true]
fill 339 279 571 365 279 572 minecraft:jungle_leaves[persistent=true]
fill 339 279 588 365 279 589 minecraft:jungle_leaves[persistent=true]
fill 340 279 570 364 279 570 minecraft:jungle_leaves[persistent=true]
fill 340 279 590 364 279 590 minecraft:jungle_leaves[persistent=true]
fill 341 279 569 363 279 569 minecraft:jungle_leaves[persistent=true]
fill 341 279 591 363 279 591 minecraft:jungle_leaves[persistent=true]
fill 342 279 568 362 279 568 minecraft:jungle_leaves[persistent=true]
fill 342 279 592 362 279 592 minecraft:jungle_leaves[persistent=true]
fill 343 279 567 361 279 567 minecraft:jungle_leaves[persistent=true]
fill 343 279 593 361 279 593 minecraft:jungle_leaves[persistent=true]
fill 345 279 566 359 279 566 minecraft:jungle_leaves[persistent=true]
fill 345 279 594 359 279 594 minecraft:jungle_leaves[persistent=true]
fill 347 279 565 357 279 565 minecraft:jungle_leaves[persistent=true]
fill 347 279 595 357 279 595 minecraft:jungle_leaves[persistent=true]
fill 351 279 575 351 279 578 minecraft:jungle_leaves[persistent=true]
fill 351 279 582 351 279 585 minecraft:jungle_leaves[persistent=true]
setblock 352 279 564 minecraft:jungle_leaves[persistent=true]
fill 352 279 575 367 279 577 minecraft:jungle_leaves[persistent=true]
fill 352 279 583 367 279 585 minecraft:jungle_leaves[persistent=true]
setblock 352 279 596 minecraft:jungle_leaves[persistent=true]
fill 353 279 578 367 279 578 minecraft:jungle_leaves[persistent=true]
fill 353 279 582 367 279 582 minecraft:jungle_leaves[persistent=true]
fill 354 279 579 367 279 579 minecraft:jungle_leaves[persistent=true]
fill 354 279 581 367 279 581 minecraft:jungle_leaves[persistent=true]
fill 355 279 580 368 279 580 minecraft:jungle_leaves[persistent=true]
fill 330 280 558 343 280 598 minecraft:oak_leaves[persistent=true]
fill 344 280 558 344 280 575 minecraft:oak_leaves[persistent=true]
fill 344 280 576 344 280 584 minecraft:azalea_leaves[persistent=true]
fill 344 280 585 344 280 598 minecraft:oak_leaves[persistent=true]
fill 345 280 558 345 280 574 minecraft:oak_leaves[persistent=true]
fill 345 280 575 345 280 579 minecraft:azalea_leaves[persistent=true]
fill 345 280 580 348 280 580 minecraft:oak_leaves[persistent=true]
fill 345 280 581 345 280 585 minecraft:azalea_leaves[persistent=true]
fill 345 280 586 345 280 598 minecraft:oak_leaves[persistent=true]
fill 346 280 558 346 280 573 minecraft:oak_leaves[persistent=true]
fill 346 280 574 346 280 576 minecraft:azalea_leaves[persistent=true]
fill 346 280 577 348 280 579 minecraft:oak_leaves[persistent=true]
fill 346 280 581 348 280 583 minecraft:oak_leaves[persistent=true]
fill 346 280 584 346 280 586 minecraft:azalea_leaves[persistent=true]
fill 346 280 587 346 280 598 minecraft:oak_leaves[persistent=true]
fill 347 280 558 347 280 572 minecraft:oak_leaves[persistent=true]
fill 347 280 573 347 280 575 minecraft:azalea_leaves[persistent=true]
fill 347 280 576 357 280 576 minecraft:oak_leaves[persistent=true]
fill 347 280 584 357 280 584 minecraft:oak_leaves[persistent=true]
fill 347 280 585 347 280 587 minecraft:azalea_leaves[persistent=true]
fill 347 280 588 347 280 598 minecraft:oak_leaves[persistent=true]
fill 348 280 558 370 280 571 minecraft:oak_leaves[persistent=true]
fill 348 280 572 348 280 574 minecraft:azalea_leaves[persistent=true]
fill 348 280 575 356 280 575 minecraft:oak_leaves[persistent=true]
fill 348 280 585 356 280 585 minecraft:oak_leaves[persistent=true]
fill 348 280 586 348 280 588 minecraft:azalea_leaves[persistent=true]
fill 348 280 589 370 280 598 minecraft:oak_leaves[persistent=true]
fill 349 280 572 351 280 573 minecraft:azalea_leaves[persistent=true]
fill 349 280 574 355 280 574 minecraft:oak_leaves[persistent=true]
fill 349 280 577 349 280 578 minecraft:oak_leaves[persistent=true]
fill 349 280 579 349 280 581 minecraft:ochre_froglight
fill 349 280 582 349 280 583 minecraft:oak_leaves[persistent=true]
fill 349 280 586 355 280 586 minecraft:oak_leaves[persistent=true]
fill 349 280 587 351 280 588 minecraft:azalea_leaves[persistent=true]
setblock 350 280 577 minecraft:oak_leaves[persistent=true]
fill 350 280 578 350 280 579 minecraft:ochre_froglight
fill 350 280 581 350 280 582 minecraft:ochre_froglight
setblock 350 280 583 minecraft:oak_leaves[persistent=true]
fill 351 280 577 351 280 578 minecraft:ochre_froglight
fill 351 280 582 351 280 583 minecraft:ochre_froglight
fill 352 280 572 356 280 572 minecraft:azalea_leaves[persistent=true]
setblock 352 280 573 minecraft:oak_leaves[persistent=true]
fill 352 280 577 353 280 577 minecraft:ochre_froglight
fill 352 280 583 353 280 583 minecraft:ochre_froglight
setblock 352 280 587 minecraft:oak_leaves[persistent=true]
fill 352 280 588 356 280 588 minecraft:azalea_leaves[persistent=true]
fill 353 280 573 357 280 573 minecraft:azalea_leaves[persistent=true]
fill 353 280 578 354 280 578 minecraft:ochre_froglight
fill 353 280 582 354 280 582 minecraft:ochre_froglight
fill 353 280 587 357 280 587 minecraft:azalea_leaves[persistent=true]
fill 354 280 577 358 280 577 minecraft:oak_leaves[persistent=true]
fill 354 280 579 355 280 579 minecraft:ochre_froglight
fill 354 280 581 355 280 581 minecraft:ochre_froglight
fill 354 280 583 358 280 583 minecraft:oak_leaves[persistent=true]
fill 355 280 578 358 280 578 minecraft:oak_leaves[persistent=true]
setblock 355 280 580 minecraft:ochre_froglight
fill 355 280 582 358 280 582 minecraft:oak_leaves[persistent=true]
fill 356 280 574 358 280 574 minecraft:azalea_leaves[persistent=true]
fill 356 280 579 358 280 581 minecraft:oak_leaves[persistent=true]
fill 356 280 586 358 280 586 minecraft:azalea_leaves[persistent=true]
fill 357 280 572 370 280 572 minecraft:oak_leaves[persistent=true]
fill 357 280 575 359 280 575 minecraft:azalea_leaves[persistent=true]
fill 357 280 585 359 280 585 minecraft:azalea_leaves[persistent=true]
fill 357 280 588 370 280 588 minecraft:oak_leaves[persistent=true]
fill 358 280 573 370 280 573 minecraft:oak_leaves[persistent=true]
fill 358 280 576 360 280 576 minecraft:azalea_leaves[persistent=true]
fill 358 280 584 360 280 584 minecraft:azalea_leaves[persistent=true]
fill 358 280 587 370 280 587 minecraft:oak_leaves[persistent=true]
fill 359 280 574 370 280 574 minecraft:oak_leaves[persistent=true]
fill 359 280 577 360 280 579 minecraft:azalea_leaves[persistent=true]
setblock 359 280 580 minecraft:oak_leaves[persistent=true]
fill 359 280 581 360 280 583 minecraft:azalea_leaves[persistent=true]
fill 359 280 586 370 280 586 minecraft:oak_leaves[persistent=true]
fill 360 280 575 370 280 575 minecraft:oak_leaves[persistent=true]
setblock 360 280 580 minecraft:azalea_leaves[persistent=true]
fill 360 280 585 370 280 585 minecraft:oak_leaves[persistent=true]
fill 361 280 576 370 280 584 minecraft:oak_leaves[persistent=true]
setblock 332 281 560 minecraft:light[level=14]
setblock 332 281 568 minecraft:light[level=14]
setblock 332 281 576 minecraft:light[level=14]
setblock 332 281 584 minecraft:light[level=14]
setblock 332 281 592 minecraft:light[level=14]
setblock 340 281 560 minecraft:light[level=14]
setblock 340 281 568 minecraft:light[level=14]
setblock 340 281 576 minecraft:light[level=14]
setblock 340 281 584 minecraft:light[level=14]
setblock 340 281 592 minecraft:light[level=14]
setblock 348 281 560 minecraft:light[level=14]
setblock 348 281 568 minecraft:light[level=14]
setblock 348 281 576 minecraft:light[level=14]
setblock 348 281 584 minecraft:light[level=14]
setblock 348 281 592 minecraft:light[level=14]
setblock 356 281 560 minecraft:light[level=14]
setblock 356 281 568 minecraft:light[level=14]
setblock 356 281 576 minecraft:light[level=14]
setblock 356 281 584 minecraft:light[level=14]
setblock 356 281 592 minecraft:light[level=14]
setblock 364 281 560 minecraft:light[level=14]
setblock 364 281 568 minecraft:light[level=14]
setblock 364 281 576 minecraft:light[level=14]
setblock 364 281 584 minecraft:light[level=14]
setblock 364 281 592 minecraft:light[level=14]
fill 330 284 558 330 284 560 minecraft:green_terracotta
setblock 330 284 561 minecraft:oak_log
fill 330 284 562 330 287 562 minecraft:green_terracotta
setblock 330 284 565 minecraft:oak_leaves[persistent=true]
setblock 330 284 570 minecraft:green_terracotta
setblock 330 284 571 minecraft:oak_log
fill 330 284 572 330 284 575 minecraft:green_terracotta
setblock 330 284 576 minecraft:oak_log
fill 330 284 577 330 284 580 minecraft:green_terracotta
setblock 330 284 581 minecraft:oak_log
fill 330 284 582 330 284 585 minecraft:green_terracotta
setblock 330 284 586 minecraft:oak_log
fill 330 284 587 330 284 590 minecraft:green_terracotta
setblock 330 284 591 minecraft:oak_log
fill 330 284 592 330 284 595 minecraft:green_terracotta
setblock 330 284 596 minecraft:oak_log
fill 330 284 597 330 286 598 minecraft:green_terracotta
fill 331 284 558 332 284 558 minecraft:green_terracotta
fill 331 284 573 331 284 574 minecraft:green_terracotta
setblock 331 284 575 minecraft:oak_log
fill 331 284 576 331 284 579 minecraft:green_terracotta
setblock 331 284 580 minecraft:oak_log
fill 331 284 581 331 284 584 minecraft:green_terracotta
setblock 331 284 585 minecraft:oak_log
fill 331 284 598 332 284 598 minecraft:green_terracotta
fill 332 284 576 332 284 578 minecraft:green_terracotta
setblock 332 284 579 minecraft:oak_log
fill 332 284 580 332 285 582 minecraft:green_terracotta
setblock 333 284 558 minecraft:oak_log
setblock 333 284 598 minecraft:oak_log
setblock 334 284 558 minecraft:oak_leaves[persistent=true]
fill 338 284 591 339 284 592 minecraft:glowstone
fill 340 284 558 342 284 558 minecraft:green_terracotta
setblock 341 284 598 minecraft:oak_leaves[persistent=true]
setblock 343 284 558 minecraft:oak_log
fill 343 284 559 346 284 559 minecraft:green_terracotta
setblock 343 284 598 minecraft:oak_log
fill 344 284 558 347 284 558 minecraft:green_terracotta
fill 344 284 598 347 284 598 minecraft:green_terracotta
setblock 345 284 560 minecraft:green_terracotta
setblock 346 284 560 minecraft:oak_log
fill 346 284 597 348 284 597 minecraft:green_terracotta
setblock 347 284 559 minecraft:oak_log
fill 347 284 560 350 284 560 minecraft:green_terracotta
setblock 348 284 558 minecraft:oak_log
fill 348 284 559 351 284 559 minecraft:green_terracotta
setblock 348 284 598 minecraft:oak_log
fill 349 284 558 352 284 558 minecraft:green_terracotta
setblock 349 284 597 minecraft:oak_log
fill 349 284 598 352 284 598 minecraft:green_terracotta
fill 350 284 597 353 284 597 minecraft:green_terracotta
setblock 351 284 560 minecraft:oak_log
setblock 352 284 559 minecraft:oak_log
fill 352 284 560 352 287 560 minecraft:green_terracotta
setblock 353 284 558 minecraft:oak_log
fill 353 284 559 356 284 559 minecraft:green_terracotta
setblock 353 284 598 minecraft:oak_log
fill 354 284 558 357 284 558 minecraft:green_terracotta
fill 354 284 598 357 284 598 minecraft:green_terracotta
setblock 358 284 558 minecraft:oak_log
fill 358 284 584 360 300 587 minecraft:oak_log
setblock 358 284 598 minecraft:oak_log
fill 359 284 558 362 284 558 minecraft:green_terracotta
fill 359 284 598 362 284 598 minecraft:green_terracotta
fill 361 284 585 361 300 586 minecraft:oak_log
fill 361 284 597 363 284 597 minecraft:green_terracotta
setblock 362 284 559 minecraft:oak_log
setblock 363 284 558 minecraft:oak_log
fill 363 284 559 366 284 559 minecraft:green_terracotta
setblock 363 284 598 minecraft:oak_log
fill 364 284 558 367 284 558 minecraft:green_terracotta
setblock 364 284 596 minecraft:green_terracotta
setblock 364 284 597 minecraft:oak_log
fill 364 284 598 367 284 598 minecraft:green_terracotta
setblock 365 284 596 minecraft:oak_log
fill 365 284 597 368 284 597 minecraft:green_terracotta
fill 366 284 596 369 284 596 minecraft:green_terracotta
setblock 367 284 559 minecraft:oak_log
setblock 368 284 558 minecraft:oak_log
fill 368 284 559 370 285 559 minecraft:green_terracotta
setblock 368 284 578 minecraft:oak_log
fill 368 284 579 368 284 582 minecraft:green_terracotta
fill 368 284 594 370 284 595 minecraft:green_terracotta
setblock 368 284 598 minecraft:oak_log
fill 369 284 558 370 286 558 minecraft:green_terracotta
fill 369 284 560 370 284 560 minecraft:green_terracotta
fill 369 284 575 369 284 576 minecraft:green_terracotta
setblock 369 284 577 minecraft:oak_log
fill 369 284 578 369 284 581 minecraft:green_terracotta
setblock 369 284 582 minecraft:oak_log
fill 369 284 583 369 284 586 minecraft:green_terracotta
setblock 369 284 587 minecraft:oak_log
fill 369 284 588 369 284 591 minecraft:green_terracotta
setblock 369 284 592 minecraft:oak_log
fill 369 284 593 370 286 593 minecraft:green_terracotta
setblock 369 284 597 minecraft:oak_log
fill 369 284 598 370 286 598 minecraft:green_terracotta
setblock 370 284 561 minecraft:oak_log
fill 370 284 562 370 287 562 minecraft:green_terracotta
setblock 370 284 566 minecraft:oak_leaves[persistent=true]
fill 370 284 572 370 284 575 minecraft:green_terracotta
setblock 370 284 576 minecraft:oak_log
fill 370 284 577 370 284 580 minecraft:green_terracotta
setblock 370 284 581 minecraft:oak_log
fill 370 284 582 370 284 585 minecraft:green_terracotta
setblock 370 284 586 minecraft:oak_log
fill 370 284 587 370 284 590 minecraft:green_terracotta
setblock 370 284 591 minecraft:oak_log
fill 370 284 592 370 287 592 minecraft:green_terracotta
setblock 370 284 596 minecraft:oak_log
fill 370 284 597 370 287 597 minecraft:green_terracotta
fill 330 285 558 330 285 559 minecraft:green_terracotta
setblock 330 285 560 minecraft:oak_log
fill 330 285 561 330 288 561 minecraft:green_terracotta
fill 330 285 563 330 286 563 minecraft:green_terracotta
setblock 330 285 570 minecraft:oak_log
fill 330 285 571 330 285 574 minecraft:green_terracotta
setblock 330 285 575 minecraft:oak_log
fill 330 285 576 330 285 579 minecraft:green_terracotta
setblock 330 285 580 minecraft:oak_log
fill 330 285 581 330 285 584 minecraft:green_terracotta
setblock 330 285 585 minecraft:oak_log
fill 330 285 586 330 285 589 minecraft:green_terracotta
setblock 330 285 590 minecraft:oak_log
fill 330 285 591 330 285 594 minecraft:green_terracotta
setblock 330 285 595 minecraft:oak_log
fill 330 285 596 330 288 596 minecraft:green_terracotta
setblock 331 285 558 minecraft:green_terracotta
setblock 331 285 573 minecraft:green_terracotta
setblock 331 285 574 minecraft:oak_log
fill 331 285 575 331 285 578 minecraft:green_terracotta
setblock 331 285 579 minecraft:oak_log
fill 331 285 580 331 285 583 minecraft:green_terracotta
setblock 331 285 584 minecraft:oak_log
fill 331 285 585 331 287 586 minecraft:green_terracotta
setblock 331 285 598 minecraft:green_terracotta
setblock 332 285 558 minecraft:oak_log
fill 332 285 576 332 285 577 minecraft:green_terracotta
setblock 332 285 578 minecraft:oak_log
fill 332 285 579 332 288 579 minecraft:green_terracotta
setblock 332 285 598 minecraft:oak_log
fill 333 285 558 333 288 558 minecraft:green_terracotta
setblock 333 285 598 minecraft:green_terracotta
fill 339 285 558 341 285 558 minecraft:green_terracotta
setblock 342 285 558 minecraft:oak_log
fill 342 285 559 345 285 559 minecraft:green_terracotta
setblock 342 285 598 minecraft:oak_log
fill 343 285 558 346 285 558 minecraft:green_terracotta
fill 343 285 598 346 285 598 minecraft:green_terracotta
setblock 344 285 560 minecraft:green_terracotta
setblock 345 285 560 minecraft:oak_log
setblock 346 285 559 minecraft:oak_log
fill 346 285 560 349 285 560 minecraft:green_terracotta
fill 346 285 597 347 285 597 minecraft:green_terracotta
setblock 347 285 558 minecraft:oak_log
fill 347 285 559 350 285 559 minecraft:green_terracotta
setblock 347 285 598 minecraft:oak_log
fill 348 285 558 351 285 558 minecraft:green_terracotta
setblock 348 285 561 minecraft:green_terracotta
setblock 348 285 597 minecraft:oak_log
fill 348 285 598 351 285 598 minecraft:green_terracotta
fill 349 285 597 352 285 597 minecraft:green_terracotta
setblock 350 285 560 minecraft:oak_log
setblock 351 285 559 minecraft:oak_log
fill 351 285 560 351 288 560 minecraft:green_terracotta
setblock 352 285 558 minecraft:oak_log
fill 352 285 559 355 285 559 minecraft:green_terracotta
setblock 352 285 598 minecraft:oak_log
fill 353 285 558 356 285 558 minecraft:green_terracotta
fill 353 285 560 353 286 560 minecraft:green_terracotta
setblock 353 285 597 minecraft:oak_log
fill 353 285 598 356 285 598 minecraft:green_terracotta
setblock 356 285 559 minecraft:oak_log
setblock 357 285 558 minecraft:oak_log
fill 357 285 559 360 285 559 minecraft:green_terracotta
fill 357 285 584 357 286 587 minecraft:dark_oak_log
setblock 357 285 598 minecraft:oak_log
fill 358 285 558 361 285 558 minecraft:green_terracotta
fill 358 285 583 360 286 583 minecraft:dark_oak_log
fill 358 285 598 361 285 598 minecraft:green_terracotta
fill 359 285 588 360 286 588 minecraft:dark_oak_log
fill 360 285 597 362 285 597 minecraft:green_terracotta
setblock 361 285 559 minecraft:oak_log
fill 361 285 584 361 286 584 minecraft:dark_oak_log
fill 361 285 587 361 286 587 minecraft:dark_oak_log
setblock 362 285 558 minecraft:oak_log
fill 362 285 559 365 285 559 minecraft:green_terracotta
setblock 362 285 598 minecraft:oak_log
fill 363 285 558 366 285 558 minecraft:green_terracotta
setblock 363 285 597 minecraft:oak_log
fill 363 285 598 366 285 598 minecraft:green_terracotta
setblock 364 285 596 minecraft:oak_log
fill 364 285 597 367 285 597 minecraft:green_terracotta
fill 365 285 596 368 285 596 minecraft:green_terracotta
setblock 366 285 559 minecraft:oak_log
setblock 367 285 558 minecraft:oak_log
fill 367 285 559 367 288 559 minecraft:green_terracotta
setblock 367 285 598 minecraft:oak_log
fill 368 285 558 368 288 558 minecraft:green_terracotta
setblock 368 285 577 minecraft:oak_log
fill 368 285 578 368 285 581 minecraft:green_terracotta
setblock 368 285 582 minecraft:oak_log
fill 368 285 583 370 285 584 minecraft:green_terracotta
fill 368 285 594 369 285 595 minecraft:green_terracotta
setblock 368 285 597 minecraft:oak_log
fill 368 285 598 368 288 598 minecraft:green_terracotta
setblock 369 285 560 minecraft:green_terracotta
setblock 369 285 561 minecraft:oak_log
setblock 369 285 575 minecraft:green_terracotta
setblock 369 285 576 minecraft:oak_log
fill 369 285 577 369 285 580 minecraft:green_terracotta
setblock 369 285 581 minecraft:oak_log
fill 369 285 582 370 287 582 minecraft:green_terracotta
setblock 369 285 585 minecraft:green_terracotta
setblock 369 285 586 minecraft:oak_log
fill 369 285 587 369 285 590 minecraft:green_terracotta
setblock 369 285 591 minecraft:oak_log
fill 369 285 592 369 288 592 minecraft:green_terracotta
setblock 369 285 596 minecraft:oak_log
fill 369 285 597 369 288 597 minecraft:green_terracotta
setblock 370 285 560 minecraft:oak_log
fill 370 285 561 370 288 561 minecraft:green_terracotta
fill 370 285 563 370 286 563 minecraft:green_terracotta
fill 370 285 573 370 285 574 minecraft:green_terracotta
setblock 370 285 575 minecraft:oak_log
fill 370 285 576 370 285 579 minecraft:green_terracotta
setblock 370 285 580 minecraft:oak_log
fill 370 285 581 370 288 581 minecraft:green_terracotta
setblock 370 285 585 minecraft:oak_log
fill 370 285 586 370 285 589 minecraft:green_terracotta
setblock 370 285 590 minecraft:oak_log
fill 370 285 591 370 288 591 minecraft:green_terracotta
setblock 370 285 594 minecraft:green_terracotta
setblock 370 285 595 minecraft:oak_log
fill 370 285 596 370 288 596 minecraft:green_terracotta
setblock 330 286 558 minecraft:green_terracotta
setblock 330 286 559 minecraft:oak_log
fill 330 286 560 330 289 560 minecraft:green_terracotta
setblock 330 286 564 minecraft:oak_log
fill 330 286 565 330 288 566 minecraft:green_terracotta
setblock 330 286 569 minecraft:oak_log
fill 330 286 570 330 286 573 minecraft:green_terracotta
setblock 330 286 574 minecraft:oak_log
fill 330 286 575 330 286 578 minecraft:green_terracotta
setblock 330 286 579 minecraft:oak_log
fill 330 286 580 330 286 583 minecraft:green_terracotta
setblock 330 286 584 minecraft:oak_log
fill 330 286 585 330 286 588 minecraft:green_terracotta
setblock 330 286 589 minecraft:oak_log
fill 330 286 590 330 286 593 minecraft:green_terracotta
setblock 330 286 594 minecraft:oak_log
fill 330 286 595 330 288 595 minecraft:green_terracotta
setblock 331 286 558 minecraft:oak_log
setblock 331 286 573 minecraft:oak_log
fill 331 286 574 331 286 577 minecraft:green_terracotta
setblock 331 286 578 minecraft:oak_log
fill 331 286 579 331 286 582 minecraft:green_terracotta
setblock 331 286 583 minecraft:oak_log
fill 331 286 584 331 289 584 minecraft:green_terracotta
setblock 331 286 598 minecraft:oak_log
fill 332 286 558 332 289 558 minecraft:green_terracotta
setblock 332 286 576 minecraft:green_terracotta
setblock 332 286 577 minecraft:oak_log
fill 332 286 578 332 289 578 minecraft:green_terracotta
fill 332 286 580 332 286 581 minecraft:green_terracotta
setblock 332 286 582 minecraft:oak_log
fill 332 286 583 332 289 583 minecraft:green_terracotta
fill 332 286 598 332 287 598 minecraft:green_terracotta
fill 334 286 558 335 286 558 minecraft:green_terracotta
setblock 334 286 598 minecraft:oak_leaves[persistent=true]
fill 337 286 558 340 286 558 minecraft:green_terracotta
setblock 340 286 559 minecraft:oak_log
setblock 341 286 558 minecraft:oak_log
fill 341 286 559 344 286 559 minecraft:green_terracotta
setblock 341 286 598 minecraft:oak_log
fill 342 286 558 345 286 558 minecraft:green_terracotta
fill 342 286 560 343 286 560 minecraft:green_terracotta
fill 342 286 598 345 286 598 minecraft:green_terracotta
setblock 344 286 560 minecraft:oak_log
setblock 345 286 559 minecraft:oak_log
fill 345 286 560 347 286 561 minecraft:green_terracotta
fill 345 286 597 346 286 597 minecraft:green_terracotta
setblock 346 286 558 minecraft:oak_log
fill 346 286 559 349 286 559 minecraft:green_terracotta
setblock 346 286 598 minecraft:oak_log
fill 347 286 558 350 286 558 minecraft:green_terracotta
setblock 347 286 597 minecraft:oak_log
fill 347 286 598 350 286 598 minecraft:green_terracotta
setblock 348 286 560 minecraft:green_terracotta
setblock 348 286 561 minecraft:oak_log
fill 348 286 597 351 286 597 minecraft:green_terracotta
setblock 349 286 560 minecraft:oak_log
fill 349 286 561 350 288 561 minecraft:green_terracotta
setblock 350 286 559 minecraft:oak_log
fill 350 286 560 350 289 560 minecraft:green_terracotta
setblock 351 286 558 minecraft:oak_log
fill 351 286 559 354 286 559 minecraft:green_terracotta
setblock 351 286 598 minecraft:oak_log
fill 352 286 558 355 286 558 minecraft:green_terracotta
setblock 352 286 597 minecraft:oak_log
fill 352 286 598 355 286 598 minecraft:green_terracotta
setblock 355 286 559 minecraft:oak_log
setblock 356 286 558 minecraft:oak_log
fill 356 286 559 359 286 559 minecraft:green_terracotta
fill 356 286 584 356 286 587 minecraft:dark_oak_log
setblock 356 286 598 minecraft:oak_log
fill 357 286 558 360 286 558 minecraft:green_terracotta
setblock 357 286 583 minecraft:dark_oak_log
fill 357 286 588 358 286 588 minecraft:dark_oak_log
fill 357 286 598 360 286 598 minecraft:green_terracotta
fill 358 286 582 360 286 582 minecraft:dark_oak_log
setblock 359 286 589 minecraft:dark_oak_log
fill 359 286 597 361 286 597 minecraft:green_terracotta
setblock 360 286 559 minecraft:oak_log
setblock 361 286 558 minecraft:oak_log
fill 361 286 559 364 286 559 minecraft:green_terracotta
setblock 361 286 583 minecraft:dark_oak_log
setblock 361 286 588 minecraft:dark_oak_log
setblock 361 286 598 minecraft:oak_log
fill 362 286 558 365 286 558 minecraft:green_terracotta
fill 362 286 584 362 286 587 minecraft:dark_oak_log
setblock 362 286 597 minecraft:oak_log
fill 362 286 598 365 286 598 minecraft:green_terracotta
setblock 363 286 596 minecraft:oak_log
schedule function dropper:buildpart/139_9 1t
