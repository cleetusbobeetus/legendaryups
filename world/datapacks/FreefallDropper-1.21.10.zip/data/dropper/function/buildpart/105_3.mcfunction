setblock 450 274 451 minecraft:light[level=12]
setblock 458 274 419 minecraft:light[level=12]
setblock 458 274 427 minecraft:light[level=12]
setblock 458 274 435 minecraft:light[level=12]
setblock 458 274 443 minecraft:light[level=12]
setblock 458 274 451 minecraft:light[level=12]
fill 437 279 439 443 279 439 minecraft:stone_bricks
fill 438 279 435 443 279 438 minecraft:stone_bricks
fill 438 279 440 443 279 443 minecraft:stone_bricks
fill 439 279 434 453 279 434 minecraft:stone_bricks
fill 439 279 444 453 279 444 minecraft:stone_bricks
fill 440 279 433 452 279 433 minecraft:stone_bricks
fill 440 279 445 452 279 445 minecraft:stone_bricks
fill 441 279 432 451 279 432 minecraft:stone_bricks
fill 441 279 446 451 279 446 minecraft:stone_bricks
fill 442 279 431 450 279 431 minecraft:stone_bricks
fill 442 279 447 450 279 447 minecraft:stone_bricks
fill 444 279 435 444 279 437 minecraft:stone_bricks
fill 444 279 441 444 279 443 minecraft:stone_bricks
fill 445 279 435 454 279 436 minecraft:stone_bricks
fill 445 279 442 454 279 443 minecraft:stone_bricks
fill 446 279 430 446 280 430 minecraft:stone_bricks
fill 446 279 448 446 280 448 minecraft:stone_bricks
fill 448 279 437 454 279 437 minecraft:stone_bricks
fill 448 279 441 454 279 441 minecraft:stone_bricks
fill 449 279 438 454 279 440 minecraft:stone_bricks
fill 455 279 439 455 280 439 minecraft:stone_bricks
fill 424 280 417 436 280 457 minecraft:cobblestone
fill 437 280 417 437 280 438 minecraft:cobblestone
fill 437 280 439 442 280 439 minecraft:stone_bricks
fill 437 280 440 437 280 457 minecraft:cobblestone
fill 438 280 417 438 280 434 minecraft:cobblestone
fill 438 280 435 438 280 438 minecraft:iron_block
fill 438 280 440 438 280 443 minecraft:iron_block
fill 438 280 444 438 280 457 minecraft:cobblestone
fill 439 280 417 439 280 433 minecraft:cobblestone
fill 439 280 434 439 280 435 minecraft:iron_block
fill 439 280 436 442 280 438 minecraft:stone_bricks
fill 439 280 440 442 280 442 minecraft:stone_bricks
fill 439 280 443 439 280 444 minecraft:iron_block
fill 439 280 445 439 280 457 minecraft:cobblestone
fill 440 280 417 440 280 432 minecraft:cobblestone
setblock 440 280 433 minecraft:iron_block
fill 440 280 434 442 280 434 minecraft:cobblestone
setblock 440 280 435 minecraft:stone_bricks
setblock 440 280 443 minecraft:stone_bricks
fill 440 280 444 442 280 444 minecraft:cobblestone
setblock 440 280 445 minecraft:iron_block
fill 440 280 446 440 280 457 minecraft:cobblestone
fill 441 280 417 441 280 431 minecraft:cobblestone
fill 441 280 432 442 280 432 minecraft:iron_block
setblock 441 280 433 minecraft:cobblestone
fill 441 280 435 442 280 435 minecraft:cobblestone
fill 441 280 443 442 280 443 minecraft:cobblestone
setblock 441 280 445 minecraft:cobblestone
fill 441 280 446 442 280 446 minecraft:iron_block
fill 441 280 447 441 280 457 minecraft:cobblestone
fill 442 280 417 445 280 430 minecraft:cobblestone
fill 442 280 431 445 280 431 minecraft:iron_block
fill 442 280 433 450 280 433 minecraft:stone_bricks
fill 442 280 445 450 280 445 minecraft:stone_bricks
fill 442 280 447 445 280 447 minecraft:iron_block
fill 442 280 448 445 280 457 minecraft:cobblestone
fill 443 280 432 449 280 432 minecraft:stone_bricks
fill 443 280 434 449 280 435 minecraft:stone_bricks
setblock 443 280 436 minecraft:cobblestone
fill 443 280 437 443 280 441 minecraft:glowstone
setblock 443 280 442 minecraft:cobblestone
fill 443 280 443 449 280 444 minecraft:stone_bricks
fill 443 280 446 449 280 446 minecraft:stone_bricks
fill 444 280 436 444 280 437 minecraft:glowstone
fill 444 280 441 444 280 442 minecraft:glowstone
fill 445 280 436 448 280 436 minecraft:glowstone
fill 445 280 442 448 280 442 minecraft:glowstone
fill 446 280 417 464 280 429 minecraft:cobblestone
setblock 446 280 431 minecraft:stone_bricks
setblock 446 280 447 minecraft:stone_bricks
fill 446 280 449 464 280 457 minecraft:cobblestone
fill 447 280 430 464 280 430 minecraft:cobblestone
fill 447 280 431 450 280 431 minecraft:iron_block
fill 447 280 447 450 280 447 minecraft:iron_block
fill 447 280 448 464 280 448 minecraft:cobblestone
fill 448 280 437 449 280 437 minecraft:glowstone
fill 448 280 441 449 280 441 minecraft:glowstone
setblock 449 280 436 minecraft:cobblestone
fill 449 280 438 449 280 440 minecraft:glowstone
setblock 449 280 442 minecraft:cobblestone
fill 450 280 432 451 280 432 minecraft:iron_block
fill 450 280 434 451 280 435 minecraft:cobblestone
fill 450 280 436 453 280 442 minecraft:stone_bricks
fill 450 280 443 451 280 444 minecraft:cobblestone
fill 450 280 446 451 280 446 minecraft:iron_block
fill 451 280 431 464 280 431 minecraft:cobblestone
setblock 451 280 433 minecraft:cobblestone
setblock 451 280 445 minecraft:cobblestone
fill 451 280 447 464 280 447 minecraft:cobblestone
fill 452 280 432 464 280 432 minecraft:cobblestone
setblock 452 280 433 minecraft:iron_block
setblock 452 280 434 minecraft:cobblestone
setblock 452 280 435 minecraft:stone_bricks
setblock 452 280 443 minecraft:stone_bricks
setblock 452 280 444 minecraft:cobblestone
setblock 452 280 445 minecraft:iron_block
fill 452 280 446 464 280 446 minecraft:cobblestone
fill 453 280 433 464 280 433 minecraft:cobblestone
fill 453 280 434 453 280 435 minecraft:iron_block
fill 453 280 443 453 280 444 minecraft:iron_block
fill 453 280 445 464 280 445 minecraft:cobblestone
fill 454 280 434 464 280 434 minecraft:cobblestone
fill 454 280 435 454 280 438 minecraft:iron_block
setblock 454 280 439 minecraft:stone_bricks
fill 454 280 440 454 280 443 minecraft:iron_block
fill 454 280 444 464 280 444 minecraft:cobblestone
fill 455 280 435 464 280 438 minecraft:cobblestone
fill 455 280 440 464 280 443 minecraft:cobblestone
fill 456 280 439 464 280 439 minecraft:cobblestone
setblock 426 282 419 minecraft:light[level=12]
setblock 426 282 427 minecraft:light[level=12]
setblock 426 282 435 minecraft:light[level=12]
setblock 426 282 443 minecraft:light[level=12]
setblock 426 282 451 minecraft:light[level=12]
setblock 434 282 419 minecraft:light[level=12]
setblock 434 282 427 minecraft:light[level=12]
setblock 434 282 435 minecraft:light[level=12]
setblock 434 282 443 minecraft:light[level=12]
setblock 434 282 451 minecraft:light[level=12]
setblock 442 282 419 minecraft:light[level=12]
setblock 442 282 427 minecraft:light[level=12]
setblock 442 282 435 minecraft:light[level=12]
setblock 442 282 443 minecraft:light[level=12]
setblock 442 282 451 minecraft:light[level=12]
setblock 450 282 419 minecraft:light[level=12]
setblock 450 282 427 minecraft:light[level=12]
setblock 450 282 435 minecraft:light[level=12]
setblock 450 282 443 minecraft:light[level=12]
setblock 450 282 451 minecraft:light[level=12]
setblock 458 282 419 minecraft:light[level=12]
setblock 458 282 427 minecraft:light[level=12]
setblock 458 282 435 minecraft:light[level=12]
setblock 458 282 443 minecraft:light[level=12]
setblock 458 282 451 minecraft:light[level=12]
fill 424 284 417 426 300 417 minecraft:iron_block
fill 424 284 427 424 300 429 minecraft:iron_block
fill 424 284 439 424 300 441 minecraft:iron_block
fill 424 284 451 424 300 453 minecraft:iron_block
fill 425 284 426 425 285 428 minecraft:iron_block
fill 425 284 438 425 285 440 minecraft:iron_block
fill 425 284 450 425 285 452 minecraft:iron_block
fill 430 284 457 432 300 457 minecraft:iron_block
fill 431 284 456 433 285 456 minecraft:iron_block
fill 435 284 418 437 285 418 minecraft:iron_block
fill 436 284 417 438 300 417 minecraft:iron_block
fill 440 284 417 446 284 426 minecraft:iron_block
fill 442 284 457 444 300 457 minecraft:iron_block
fill 443 284 456 445 285 456 minecraft:iron_block
fill 447 284 418 449 285 418 minecraft:iron_block
fill 448 284 417 450 300 417 minecraft:iron_block
fill 454 284 417 464 284 421 minecraft:iron_block
fill 454 284 457 456 300 457 minecraft:iron_block
fill 455 284 456 457 285 456 minecraft:iron_block
fill 463 284 426 463 285 428 minecraft:iron_block
fill 463 284 438 463 285 440 minecraft:iron_block
fill 463 284 450 463 285 452 minecraft:iron_block
fill 464 284 425 464 300 427 minecraft:iron_block
fill 464 284 437 464 300 439 minecraft:iron_block
fill 464 284 449 464 300 451 minecraft:iron_block
fill 424 285 420 424 285 425 minecraft:cobblestone
fill 424 285 432 424 285 437 minecraft:cobblestone
fill 424 285 444 424 285 449 minecraft:cobblestone
fill 424 285 456 424 285 457 minecraft:cobblestone
fill 425 285 457 428 285 457 minecraft:cobblestone
fill 428 285 417 433 285 417 minecraft:cobblestone
fill 435 285 457 440 285 457 minecraft:cobblestone
fill 440 285 417 445 285 417 minecraft:cobblestone
fill 440 285 418 446 300 426 minecraft:iron_block
fill 446 285 417 446 300 417 minecraft:iron_block
fill 447 285 457 452 285 457 minecraft:cobblestone
fill 452 285 417 457 285 417 minecraft:cobblestone
fill 454 285 418 463 285 421 minecraft:iron_block
fill 458 285 417 463 285 417 minecraft:iron_block
fill 459 285 457 464 285 457 minecraft:cobblestone
fill 464 285 417 464 285 422 minecraft:cobblestone
fill 464 285 429 464 285 434 minecraft:cobblestone
fill 464 285 441 464 285 446 minecraft:cobblestone
fill 464 285 453 464 285 456 minecraft:cobblestone
fill 423 286 422 423 291 425 minecraft:glowstone
fill 423 286 434 423 291 437 minecraft:glowstone
fill 423 286 446 423 291 449 minecraft:glowstone
fill 423 286 458 426 291 458 minecraft:glowstone
fill 430 286 416 433 291 416 minecraft:glowstone
fill 435 286 458 438 291 458 minecraft:glowstone
fill 440 286 417 445 300 417 minecraft:iron_block
fill 442 286 416 445 291 416 minecraft:glowstone
fill 447 286 458 450 291 458 minecraft:glowstone
fill 454 286 416 454 286 417 minecraft:glowstone
fill 454 286 418 454 300 418 minecraft:iron_block
setblock 454 286 419 minecraft:glowstone
fill 454 286 420 454 300 420 minecraft:iron_block
setblock 454 286 421 minecraft:glowstone
fill 455 286 416 457 291 416 minecraft:glowstone
fill 455 286 417 455 300 417 minecraft:iron_block
setblock 455 286 418 minecraft:glowstone
fill 455 286 419 455 300 419 minecraft:iron_block
setblock 455 286 420 minecraft:glowstone
fill 455 286 421 455 300 421 minecraft:iron_block
setblock 456 286 417 minecraft:glowstone
fill 456 286 418 456 300 418 minecraft:iron_block
setblock 456 286 419 minecraft:glowstone
fill 456 286 420 456 300 420 minecraft:iron_block
setblock 456 286 421 minecraft:glowstone
fill 457 286 417 457 300 417 minecraft:iron_block
setblock 457 286 418 minecraft:glowstone
fill 457 286 419 457 300 419 minecraft:iron_block
setblock 457 286 420 minecraft:glowstone
fill 457 286 421 457 300 421 minecraft:iron_block
setblock 458 286 417 minecraft:glowstone
fill 458 286 418 458 300 418 minecraft:iron_block
setblock 458 286 419 minecraft:glowstone
fill 458 286 420 458 300 420 minecraft:iron_block
setblock 458 286 421 minecraft:glowstone
fill 459 286 417 459 300 417 minecraft:iron_block
setblock 459 286 418 minecraft:glowstone
fill 459 286 419 459 300 419 minecraft:iron_block
setblock 459 286 420 minecraft:glowstone
fill 459 286 421 459 300 421 minecraft:iron_block
fill 459 286 458 462 291 458 minecraft:glowstone
setblock 460 286 417 minecraft:glowstone
fill 460 286 418 460 300 418 minecraft:iron_block
setblock 460 286 419 minecraft:glowstone
fill 460 286 420 460 300 420 minecraft:iron_block
setblock 460 286 421 minecraft:glowstone
fill 461 286 417 461 300 417 minecraft:iron_block
setblock 461 286 418 minecraft:glowstone
fill 461 286 419 461 300 419 minecraft:iron_block
setblock 461 286 420 minecraft:glowstone
fill 461 286 421 461 300 421 minecraft:iron_block
setblock 462 286 417 minecraft:glowstone
fill 462 286 418 462 300 418 minecraft:iron_block
setblock 462 286 419 minecraft:glowstone
fill 462 286 420 462 300 420 minecraft:iron_block
setblock 462 286 421 minecraft:glowstone
fill 463 286 417 463 300 417 minecraft:iron_block
setblock 463 286 418 minecraft:glowstone
fill 463 286 419 463 300 419 minecraft:iron_block
setblock 463 286 420 minecraft:glowstone
fill 463 286 421 463 300 421 minecraft:iron_block
fill 464 286 417 465 286 417 minecraft:glowstone
fill 464 286 418 464 300 418 minecraft:iron_block
fill 464 286 419 465 286 419 minecraft:glowstone
fill 464 286 420 464 300 420 minecraft:iron_block
setblock 464 286 421 minecraft:glowstone
fill 465 286 418 465 292 418 minecraft:glowstone
fill 465 286 420 465 291 420 minecraft:glowstone
fill 465 286 429 465 291 432 minecraft:glowstone
fill 465 286 441 465 291 444 minecraft:glowstone
fill 465 286 453 465 291 456 minecraft:glowstone
fill 454 287 416 454 291 416 minecraft:glowstone
fill 454 287 417 454 288 417 minecraft:iron_block
fill 454 287 419 454 288 419 minecraft:iron_block
fill 454 287 421 454 288 421 minecraft:iron_block
fill 455 287 418 455 288 418 minecraft:iron_block
fill 455 287 420 455 288 420 minecraft:iron_block
fill 456 287 417 456 288 417 minecraft:iron_block
fill 456 287 419 456 288 419 minecraft:iron_block
fill 456 287 421 456 288 421 minecraft:iron_block
fill 457 287 418 457 288 418 minecraft:iron_block
fill 457 287 420 457 288 420 minecraft:iron_block
fill 458 287 417 458 288 417 minecraft:iron_block
fill 458 287 419 458 288 419 minecraft:iron_block
fill 458 287 421 458 288 421 minecraft:iron_block
fill 459 287 418 459 288 418 minecraft:iron_block
fill 459 287 420 459 288 420 minecraft:iron_block
fill 460 287 417 460 288 417 minecraft:iron_block
fill 460 287 419 460 288 419 minecraft:iron_block
fill 460 287 421 460 288 421 minecraft:iron_block
fill 461 287 418 461 288 418 minecraft:iron_block
fill 461 287 420 461 288 420 minecraft:iron_block
fill 462 287 417 462 288 417 minecraft:iron_block
fill 462 287 419 462 288 419 minecraft:iron_block
fill 462 287 421 462 288 421 minecraft:iron_block
fill 463 287 418 463 288 418 minecraft:iron_block
fill 463 287 420 463 288 420 minecraft:iron_block
fill 464 287 417 464 288 417 minecraft:iron_block
fill 464 287 419 464 288 419 minecraft:iron_block
fill 464 287 421 464 288 421 minecraft:iron_block
fill 465 287 417 465 291 417 minecraft:glowstone
fill 465 287 419 465 292 419 minecraft:glowstone
setblock 454 289 417 minecraft:glowstone
setblock 454 289 419 minecraft:glowstone
setblock 454 289 421 minecraft:glowstone
setblock 455 289 418 minecraft:glowstone
setblock 455 289 420 minecraft:glowstone
setblock 456 289 417 minecraft:glowstone
setblock 456 289 419 minecraft:glowstone
setblock 456 289 421 minecraft:glowstone
setblock 457 289 418 minecraft:glowstone
setblock 457 289 420 minecraft:glowstone
setblock 458 289 417 minecraft:glowstone
setblock 458 289 419 minecraft:glowstone
setblock 458 289 421 minecraft:glowstone
setblock 459 289 418 minecraft:glowstone
setblock 459 289 420 minecraft:glowstone
setblock 460 289 417 minecraft:glowstone
setblock 460 289 419 minecraft:glowstone
setblock 460 289 421 minecraft:glowstone
setblock 461 289 418 minecraft:glowstone
setblock 461 289 420 minecraft:glowstone
setblock 462 289 417 minecraft:glowstone
setblock 462 289 419 minecraft:glowstone
setblock 462 289 421 minecraft:glowstone
setblock 463 289 418 minecraft:glowstone
setblock 463 289 420 minecraft:glowstone
setblock 464 289 417 minecraft:glowstone
setblock 464 289 419 minecraft:glowstone
setblock 464 289 421 minecraft:glowstone
setblock 426 290 419 minecraft:light[level=12]
setblock 426 290 427 minecraft:light[level=12]
setblock 426 290 435 minecraft:light[level=12]
setblock 426 290 443 minecraft:light[level=12]
setblock 426 290 451 minecraft:light[level=12]
setblock 434 290 419 minecraft:light[level=12]
setblock 434 290 427 minecraft:light[level=12]
setblock 434 290 435 minecraft:light[level=12]
setblock 434 290 443 minecraft:light[level=12]
setblock 434 290 451 minecraft:light[level=12]
setblock 442 290 427 minecraft:light[level=12]
setblock 442 290 435 minecraft:light[level=12]
setblock 442 290 443 minecraft:light[level=12]
setblock 442 290 451 minecraft:light[level=12]
setblock 450 290 419 minecraft:light[level=12]
setblock 450 290 427 minecraft:light[level=12]
setblock 450 290 435 minecraft:light[level=12]
setblock 450 290 443 minecraft:light[level=12]
setblock 450 290 451 minecraft:light[level=12]
fill 454 290 417 454 291 417 minecraft:iron_block
fill 454 290 419 454 291 419 minecraft:iron_block
fill 454 290 421 454 291 421 minecraft:iron_block
fill 455 290 418 455 291 418 minecraft:iron_block
fill 455 290 420 455 291 420 minecraft:iron_block
fill 456 290 417 456 291 417 minecraft:iron_block
fill 456 290 419 456 291 419 minecraft:iron_block
fill 456 290 421 456 291 421 minecraft:iron_block
fill 457 290 418 457 291 418 minecraft:iron_block
fill 457 290 420 457 291 420 minecraft:iron_block
fill 458 290 417 458 291 417 minecraft:iron_block
fill 458 290 419 458 291 419 minecraft:iron_block
fill 458 290 421 458 291 421 minecraft:iron_block
setblock 458 290 427 minecraft:light[level=12]
setblock 458 290 435 minecraft:light[level=12]
setblock 458 290 443 minecraft:light[level=12]
setblock 458 290 451 minecraft:light[level=12]
fill 459 290 418 459 291 418 minecraft:iron_block
fill 459 290 420 459 291 420 minecraft:iron_block
fill 460 290 417 460 291 417 minecraft:iron_block
fill 460 290 419 460 291 419 minecraft:iron_block
fill 460 290 421 460 291 421 minecraft:iron_block
fill 461 290 418 461 291 418 minecraft:iron_block
fill 461 290 420 461 291 420 minecraft:iron_block
fill 462 290 417 462 291 417 minecraft:iron_block
fill 462 290 419 462 291 419 minecraft:iron_block
fill 462 290 421 462 291 421 minecraft:iron_block
fill 463 290 418 463 291 418 minecraft:iron_block
fill 463 290 420 463 291 420 minecraft:iron_block
fill 464 290 417 464 291 417 minecraft:iron_block
fill 464 290 419 464 291 419 minecraft:iron_block
fill 464 290 421 464 291 421 minecraft:iron_block
fill 423 292 422 423 307 422 minecraft:stone_bricks
fill 423 292 423 423 292 424 minecraft:glowstone
fill 423 292 425 423 307 425 minecraft:stone_bricks
fill 423 292 434 423 307 434 minecraft:stone_bricks
fill 423 292 435 423 292 436 minecraft:glowstone
fill 423 292 437 423 307 437 minecraft:stone_bricks
fill 423 292 446 423 307 446 minecraft:stone_bricks
fill 423 292 447 423 292 448 minecraft:glowstone
fill 423 292 449 423 307 449 minecraft:stone_bricks
fill 423 292 458 423 307 458 minecraft:stone_bricks
fill 424 292 458 425 292 458 minecraft:glowstone
fill 426 292 458 426 307 458 minecraft:stone_bricks
fill 430 292 416 430 307 416 minecraft:stone_bricks
fill 431 292 416 432 292 416 minecraft:glowstone
fill 433 292 416 433 307 416 minecraft:stone_bricks
fill 435 292 458 435 307 458 minecraft:stone_bricks
fill 436 292 458 437 292 458 minecraft:glowstone
fill 438 292 458 438 307 458 minecraft:stone_bricks
fill 442 292 416 442 307 416 minecraft:stone_bricks
fill 443 292 416 444 292 416 minecraft:glowstone
fill 445 292 416 445 307 416 minecraft:stone_bricks
fill 447 292 458 447 307 458 minecraft:stone_bricks
fill 448 292 458 449 292 458 minecraft:glowstone
fill 450 292 458 450 307 458 minecraft:stone_bricks
fill 454 292 416 454 307 416 minecraft:stone_bricks
setblock 454 292 417 minecraft:glowstone
setblock 454 292 419 minecraft:glowstone
setblock 454 292 421 minecraft:glowstone
fill 455 292 416 456 292 416 minecraft:glowstone
setblock 455 292 418 minecraft:glowstone
setblock 455 292 420 minecraft:glowstone
setblock 456 292 417 minecraft:glowstone
setblock 456 292 419 minecraft:glowstone
setblock 456 292 421 minecraft:glowstone
fill 457 292 416 457 307 416 minecraft:stone_bricks
setblock 457 292 418 minecraft:glowstone
setblock 457 292 420 minecraft:glowstone
setblock 458 292 417 minecraft:glowstone
setblock 458 292 419 minecraft:glowstone
setblock 458 292 421 minecraft:glowstone
setblock 459 292 418 minecraft:glowstone
setblock 459 292 420 minecraft:glowstone
fill 459 292 458 459 307 458 minecraft:stone_bricks
setblock 460 292 417 minecraft:glowstone
setblock 460 292 419 minecraft:glowstone
setblock 460 292 421 minecraft:glowstone
fill 460 292 458 461 292 458 minecraft:glowstone
setblock 461 292 418 minecraft:glowstone
setblock 461 292 420 minecraft:glowstone
setblock 462 292 417 minecraft:glowstone
setblock 462 292 419 minecraft:glowstone
setblock 462 292 421 minecraft:glowstone
fill 462 292 458 462 307 458 minecraft:stone_bricks
setblock 463 292 418 minecraft:glowstone
setblock 463 292 420 minecraft:glowstone
setblock 464 292 417 minecraft:glowstone
setblock 464 292 419 minecraft:glowstone
setblock 464 292 421 minecraft:glowstone
fill 465 292 417 465 307 417 minecraft:stone_bricks
fill 465 292 420 465 307 420 minecraft:stone_bricks
fill 465 292 429 465 307 429 minecraft:stone_bricks
fill 465 292 430 465 292 431 minecraft:glowstone
fill 465 292 432 465 307 432 minecraft:stone_bricks
fill 465 292 441 465 307 441 minecraft:stone_bricks
fill 465 292 442 465 292 443 minecraft:glowstone
fill 465 292 444 465 307 444 minecraft:stone_bricks
fill 465 292 453 465 307 453 minecraft:stone_bricks
fill 465 292 454 465 292 455 minecraft:glowstone
fill 465 292 456 465 307 456 minecraft:stone_bricks
fill 423 293 423 423 307 424 minecraft:stone_bricks
fill 423 293 435 423 307 436 minecraft:stone_bricks
fill 423 293 447 423 307 448 minecraft:stone_bricks
fill 424 293 458 425 307 458 minecraft:stone_bricks
fill 431 293 416 432 307 416 minecraft:stone_bricks
fill 436 293 458 437 307 458 minecraft:stone_bricks
fill 443 293 416 444 307 416 minecraft:stone_bricks
fill 448 293 458 449 307 458 minecraft:stone_bricks
fill 454 293 417 454 294 417 minecraft:iron_block
fill 454 293 419 454 294 419 minecraft:iron_block
fill 454 293 421 454 294 421 minecraft:iron_block
fill 455 293 416 456 307 416 minecraft:stone_bricks
fill 455 293 418 455 294 418 minecraft:iron_block
fill 455 293 420 455 294 420 minecraft:iron_block
fill 456 293 417 456 294 417 minecraft:iron_block
fill 456 293 419 456 294 419 minecraft:iron_block
fill 456 293 421 456 294 421 minecraft:iron_block
fill 457 293 418 457 294 418 minecraft:iron_block
fill 457 293 420 457 294 420 minecraft:iron_block
fill 458 293 417 458 294 417 minecraft:iron_block
fill 458 293 419 458 294 419 minecraft:iron_block
fill 458 293 421 458 294 421 minecraft:iron_block
fill 459 293 418 459 294 418 minecraft:iron_block
fill 459 293 420 459 294 420 minecraft:iron_block
fill 460 293 417 460 294 417 minecraft:iron_block
fill 460 293 419 460 294 419 minecraft:iron_block
fill 460 293 421 460 294 421 minecraft:iron_block
fill 460 293 458 461 307 458 minecraft:stone_bricks
fill 461 293 418 461 294 418 minecraft:iron_block
fill 461 293 420 461 294 420 minecraft:iron_block
fill 462 293 417 462 294 417 minecraft:iron_block
fill 462 293 419 462 294 419 minecraft:iron_block
fill 462 293 421 462 294 421 minecraft:iron_block
fill 463 293 418 463 294 418 minecraft:iron_block
fill 463 293 420 463 294 420 minecraft:iron_block
fill 464 293 417 464 294 417 minecraft:iron_block
fill 464 293 419 464 294 419 minecraft:iron_block
fill 464 293 421 464 294 421 minecraft:iron_block
fill 465 293 418 465 307 419 minecraft:stone_bricks
fill 465 293 430 465 307 431 minecraft:stone_bricks
fill 465 293 442 465 307 443 minecraft:stone_bricks
fill 465 293 454 465 307 455 minecraft:stone_bricks
setblock 454 295 417 minecraft:glowstone
setblock 454 295 419 minecraft:glowstone
setblock 454 295 421 minecraft:glowstone
setblock 455 295 418 minecraft:glowstone
setblock 455 295 420 minecraft:glowstone
setblock 456 295 417 minecraft:glowstone
setblock 456 295 419 minecraft:glowstone
setblock 456 295 421 minecraft:glowstone
setblock 457 295 418 minecraft:glowstone
setblock 457 295 420 minecraft:glowstone
setblock 458 295 417 minecraft:glowstone
setblock 458 295 419 minecraft:glowstone
setblock 458 295 421 minecraft:glowstone
setblock 459 295 418 minecraft:glowstone
setblock 459 295 420 minecraft:glowstone
setblock 460 295 417 minecraft:glowstone
setblock 460 295 419 minecraft:glowstone
setblock 460 295 421 minecraft:glowstone
setblock 461 295 418 minecraft:glowstone
setblock 461 295 420 minecraft:glowstone
fill 461 295 432 463 296 432 minecraft:iron_bars
setblock 462 295 417 minecraft:glowstone
setblock 462 295 419 minecraft:glowstone
setblock 462 295 421 minecraft:glowstone
setblock 463 295 418 minecraft:glowstone
setblock 463 295 420 minecraft:glowstone
setblock 464 295 417 minecraft:glowstone
setblock 464 295 419 minecraft:glowstone
setblock 464 295 421 minecraft:glowstone
fill 454 296 417 454 297 417 minecraft:iron_block
fill 454 296 419 454 297 419 minecraft:iron_block
fill 454 296 421 454 297 421 minecraft:iron_block
fill 455 296 418 455 297 418 minecraft:iron_block
fill 455 296 420 455 297 420 minecraft:iron_block
fill 456 296 417 456 297 417 minecraft:iron_block
fill 456 296 419 456 297 419 minecraft:iron_block
fill 456 296 421 456 297 421 minecraft:iron_block
fill 457 296 418 457 297 418 minecraft:iron_block
fill 457 296 420 457 297 420 minecraft:iron_block
fill 458 296 417 458 297 417 minecraft:iron_block
fill 458 296 419 458 297 419 minecraft:iron_block
fill 458 296 421 458 297 421 minecraft:iron_block
fill 459 296 418 459 297 418 minecraft:iron_block
fill 459 296 420 459 297 420 minecraft:iron_block
fill 460 296 417 460 297 417 minecraft:iron_block
fill 460 296 419 460 297 419 minecraft:iron_block
fill 460 296 421 460 297 421 minecraft:iron_block
fill 461 296 418 461 297 418 minecraft:iron_block
fill 461 296 420 461 297 420 minecraft:iron_block
fill 462 296 417 462 297 417 minecraft:iron_block
fill 462 296 419 462 297 419 minecraft:iron_block
fill 462 296 421 462 297 421 minecraft:iron_block
fill 463 296 418 463 297 418 minecraft:iron_block
fill 463 296 420 463 297 420 minecraft:iron_block
fill 464 296 417 464 297 417 minecraft:iron_block
fill 464 296 419 464 297 419 minecraft:iron_block
fill 464 296 421 464 297 421 minecraft:iron_block
setblock 426 298 419 minecraft:light[level=12]
setblock 426 298 427 minecraft:light[level=12]
setblock 426 298 435 minecraft:light[level=12]
setblock 426 298 443 minecraft:light[level=12]
setblock 426 298 451 minecraft:light[level=12]
setblock 434 298 419 minecraft:light[level=12]
setblock 434 298 427 minecraft:light[level=12]
setblock 434 298 435 minecraft:light[level=12]
setblock 434 298 443 minecraft:light[level=12]
setblock 434 298 451 minecraft:light[level=12]
setblock 442 298 427 minecraft:light[level=12]
setblock 442 298 435 minecraft:light[level=12]
setblock 442 298 443 minecraft:light[level=12]
setblock 442 298 451 minecraft:light[level=12]
setblock 450 298 419 minecraft:light[level=12]
setblock 450 298 427 minecraft:light[level=12]
setblock 450 298 435 minecraft:light[level=12]
setblock 450 298 443 minecraft:light[level=12]
setblock 450 298 451 minecraft:light[level=12]
setblock 454 298 417 minecraft:glowstone
setblock 454 298 419 minecraft:glowstone
setblock 454 298 421 minecraft:glowstone
setblock 455 298 418 minecraft:glowstone
setblock 455 298 420 minecraft:glowstone
setblock 456 298 417 minecraft:glowstone
setblock 456 298 419 minecraft:glowstone
setblock 456 298 421 minecraft:glowstone
setblock 457 298 418 minecraft:glowstone
setblock 457 298 420 minecraft:glowstone
setblock 458 298 417 minecraft:glowstone
setblock 458 298 419 minecraft:glowstone
setblock 458 298 421 minecraft:glowstone
setblock 458 298 427 minecraft:light[level=12]
setblock 458 298 435 minecraft:light[level=12]
setblock 458 298 443 minecraft:light[level=12]
setblock 458 298 451 minecraft:light[level=12]
setblock 459 298 418 minecraft:glowstone
setblock 459 298 420 minecraft:glowstone
setblock 460 298 417 minecraft:glowstone
setblock 460 298 419 minecraft:glowstone
setblock 460 298 421 minecraft:glowstone
setblock 461 298 418 minecraft:glowstone
setblock 461 298 420 minecraft:glowstone
fill 461 298 429 463 299 429 minecraft:iron_bars
setblock 462 298 417 minecraft:glowstone
setblock 462 298 419 minecraft:glowstone
setblock 462 298 421 minecraft:glowstone
setblock 463 298 418 minecraft:glowstone
setblock 463 298 420 minecraft:glowstone
setblock 464 298 417 minecraft:glowstone
setblock 464 298 419 minecraft:glowstone
setblock 464 298 421 minecraft:glowstone
fill 454 299 417 454 300 417 minecraft:iron_block
fill 454 299 419 454 300 419 minecraft:iron_block
fill 454 299 421 454 300 421 minecraft:iron_block
fill 455 299 418 455 300 418 minecraft:iron_block
fill 455 299 420 455 300 420 minecraft:iron_block
fill 456 299 417 456 300 417 minecraft:iron_block
fill 456 299 419 456 300 419 minecraft:iron_block
fill 456 299 421 456 300 421 minecraft:iron_block
fill 457 299 418 457 300 418 minecraft:iron_block
fill 457 299 420 457 300 420 minecraft:iron_block
fill 458 299 417 458 300 417 minecraft:iron_block
fill 458 299 419 458 300 419 minecraft:iron_block
fill 458 299 421 458 300 421 minecraft:iron_block
fill 459 299 418 459 300 418 minecraft:iron_block
fill 459 299 420 459 300 420 minecraft:iron_block
fill 460 299 417 460 300 417 minecraft:iron_block
fill 460 299 419 460 300 419 minecraft:iron_block
fill 460 299 421 460 300 421 minecraft:iron_block
fill 461 299 418 461 300 418 minecraft:iron_block
fill 461 299 420 461 300 420 minecraft:iron_block
fill 462 299 417 462 300 417 minecraft:iron_block
fill 462 299 419 462 300 419 minecraft:iron_block
fill 462 299 421 462 300 421 minecraft:iron_block
fill 463 299 418 463 300 418 minecraft:iron_block
fill 463 299 420 463 300 420 minecraft:iron_block
fill 464 299 417 464 300 417 minecraft:iron_block
fill 464 299 419 464 300 419 minecraft:iron_block
fill 464 299 421 464 300 421 minecraft:iron_block
fill 425 300 426 425 300 428 minecraft:iron_block
fill 425 300 438 425 300 440 minecraft:iron_block
fill 425 300 450 425 300 452 minecraft:iron_block
fill 431 300 456 433 300 456 minecraft:iron_block
fill 435 300 418 437 300 418 minecraft:iron_block
fill 443 300 456 445 300 456 minecraft:iron_block
fill 447 300 418 449 300 418 minecraft:iron_block
fill 455 300 456 457 300 456 minecraft:iron_block
fill 463 300 426 463 300 428 minecraft:iron_block
fill 463 300 438 463 300 440 minecraft:iron_block
fill 463 300 450 463 300 452 minecraft:iron_block
