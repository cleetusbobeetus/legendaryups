setblock 247 269 500 minecraft:brown_terracotta
setblock 247 269 501 minecraft:bone_block
fill 247 269 502 247 272 502 minecraft:brown_terracotta
fill 248 269 501 248 271 501 minecraft:brown_terracotta
setblock 249 269 464 minecraft:bone_block
setblock 249 269 504 minecraft:bone_block
fill 250 269 464 250 270 464 minecraft:brown_terracotta
setblock 250 269 503 minecraft:bone_block
fill 250 269 504 250 272 504 minecraft:brown_terracotta
setblock 251 269 502 minecraft:bone_block
fill 251 269 503 251 272 503 minecraft:brown_terracotta
setblock 252 269 502 minecraft:brown_terracotta
setblock 254 269 504 minecraft:bone_block
fill 255 269 504 258 269 504 minecraft:brown_terracotta
setblock 259 269 503 minecraft:brown_terracotta
setblock 259 269 504 minecraft:bone_block
setblock 260 269 503 minecraft:bone_block
fill 260 269 504 263 269 504 minecraft:brown_terracotta
fill 261 269 464 263 269 464 minecraft:brown_terracotta
fill 261 269 503 264 269 503 minecraft:brown_terracotta
setblock 264 269 464 minecraft:bone_block
setblock 264 269 504 minecraft:bone_block
fill 265 269 464 265 271 465 minecraft:brown_terracotta
setblock 265 269 502 minecraft:brown_terracotta
setblock 265 269 503 minecraft:bone_block
fill 265 269 504 265 272 504 minecraft:brown_terracotta
fill 266 269 465 267 269 465 minecraft:brown_terracotta
setblock 266 269 502 minecraft:bone_block
fill 266 269 503 266 272 503 minecraft:brown_terracotta
setblock 267 269 502 minecraft:brown_terracotta
setblock 268 269 465 minecraft:bone_block
setblock 269 269 464 minecraft:bone_block
setblock 269 269 504 minecraft:bone_block
fill 270 269 464 270 272 464 minecraft:brown_terracotta
setblock 270 269 503 minecraft:bone_block
fill 270 269 504 270 272 504 minecraft:brown_terracotta
setblock 273 269 504 minecraft:brown_terracotta
setblock 274 269 464 minecraft:bone_block
setblock 274 269 504 minecraft:bone_block
fill 275 269 464 275 272 464 minecraft:brown_terracotta
setblock 275 269 474 minecraft:brown_terracotta
setblock 275 269 478 minecraft:bone_block
fill 275 269 479 275 271 479 minecraft:brown_terracotta
fill 275 269 504 275 272 504 minecraft:brown_terracotta
setblock 276 269 466 minecraft:brown_terracotta
setblock 276 269 467 minecraft:bone_block
setblock 276 269 472 minecraft:bone_block
fill 276 269 473 276 271 473 minecraft:brown_terracotta
setblock 276 269 477 minecraft:bone_block
fill 276 269 478 276 272 478 minecraft:brown_terracotta
setblock 276 269 482 minecraft:bone_block
fill 276 269 483 276 272 483 minecraft:brown_terracotta
fill 276 269 500 276 269 501 minecraft:brown_terracotta
setblock 276 269 502 minecraft:bone_block
fill 276 269 503 276 272 503 minecraft:brown_terracotta
fill 236 270 464 237 270 464 minecraft:brown_terracotta
setblock 236 270 466 minecraft:bone_block
setblock 236 270 476 minecraft:bone_block
setblock 236 270 477 minecraft:brown_terracotta
setblock 236 270 481 minecraft:bone_block
setblock 236 270 497 minecraft:brown_terracotta
setblock 236 270 500 minecraft:brown_terracotta
setblock 236 270 501 minecraft:bone_block
fill 236 270 502 238 270 503 minecraft:brown_terracotta
setblock 237 270 500 minecraft:bone_block
fill 237 270 501 237 273 501 minecraft:brown_terracotta
setblock 238 270 464 minecraft:bone_block
fill 238 270 500 238 271 500 minecraft:brown_terracotta
setblock 238 270 504 minecraft:bone_block
fill 239 270 464 239 272 465 minecraft:brown_terracotta
setblock 239 270 502 minecraft:brown_terracotta
setblock 239 270 503 minecraft:bone_block
fill 239 270 504 242 270 504 minecraft:brown_terracotta
setblock 240 270 501 minecraft:brown_terracotta
setblock 240 270 502 minecraft:bone_block
fill 240 270 503 240 273 503 minecraft:brown_terracotta
setblock 241 270 501 minecraft:bone_block
fill 241 270 502 241 273 502 minecraft:brown_terracotta
setblock 242 270 464 minecraft:brown_terracotta
setblock 242 270 465 minecraft:bone_block
fill 242 270 501 242 273 501 minecraft:brown_terracotta
setblock 243 270 464 minecraft:bone_block
fill 243 270 465 243 273 465 minecraft:brown_terracotta
setblock 243 270 504 minecraft:bone_block
fill 244 270 464 244 273 464 minecraft:brown_terracotta
setblock 244 270 503 minecraft:bone_block
fill 244 270 504 244 273 504 minecraft:brown_terracotta
setblock 245 270 502 minecraft:bone_block
fill 245 270 503 245 273 503 minecraft:brown_terracotta
setblock 246 270 501 minecraft:bone_block
fill 246 270 502 246 273 502 minecraft:brown_terracotta
fill 247 270 501 247 271 501 minecraft:brown_terracotta
setblock 248 270 464 minecraft:bone_block
setblock 248 270 504 minecraft:bone_block
fill 249 270 464 249 271 464 minecraft:brown_terracotta
setblock 249 270 503 minecraft:bone_block
fill 249 270 504 249 273 504 minecraft:brown_terracotta
setblock 250 270 502 minecraft:bone_block
fill 250 270 503 250 273 503 minecraft:brown_terracotta
setblock 251 270 502 minecraft:brown_terracotta
setblock 253 270 504 minecraft:bone_block
fill 254 270 504 257 270 504 minecraft:brown_terracotta
setblock 258 270 504 minecraft:bone_block
setblock 259 270 503 minecraft:bone_block
fill 259 270 504 262 270 504 minecraft:brown_terracotta
fill 260 270 503 263 270 503 minecraft:brown_terracotta
fill 261 270 464 262 270 464 minecraft:brown_terracotta
setblock 263 270 464 minecraft:bone_block
setblock 263 270 504 minecraft:bone_block
fill 264 270 464 264 272 465 minecraft:brown_terracotta
setblock 264 270 503 minecraft:bone_block
fill 264 270 504 264 273 504 minecraft:brown_terracotta
setblock 265 270 502 minecraft:bone_block
fill 265 270 503 265 273 503 minecraft:brown_terracotta
setblock 266 270 465 minecraft:brown_terracotta
setblock 267 270 465 minecraft:bone_block
setblock 268 270 464 minecraft:bone_block
setblock 268 270 465 minecraft:brown_terracotta
setblock 268 270 504 minecraft:bone_block
fill 269 270 464 269 273 464 minecraft:brown_terracotta
setblock 269 270 503 minecraft:bone_block
fill 269 270 504 269 273 504 minecraft:brown_terracotta
setblock 272 270 464 minecraft:brown_terracotta
setblock 273 270 464 minecraft:bone_block
setblock 273 270 504 minecraft:bone_block
fill 274 270 464 274 273 464 minecraft:brown_terracotta
fill 274 270 504 274 273 504 minecraft:brown_terracotta
setblock 275 270 477 minecraft:bone_block
fill 275 270 478 275 271 478 minecraft:brown_terracotta
setblock 276 270 466 minecraft:bone_block
fill 276 270 467 276 273 467 minecraft:brown_terracotta
setblock 276 270 471 minecraft:bone_block
setblock 276 270 472 minecraft:brown_terracotta
setblock 276 270 476 minecraft:bone_block
fill 276 270 477 276 273 477 minecraft:brown_terracotta
setblock 276 270 481 minecraft:bone_block
fill 276 270 482 276 273 482 minecraft:brown_terracotta
fill 276 270 484 276 271 484 minecraft:brown_terracotta
setblock 276 270 500 minecraft:brown_terracotta
setblock 276 270 501 minecraft:bone_block
fill 276 270 502 276 273 502 minecraft:brown_terracotta
setblock 236 271 464 minecraft:brown_terracotta
setblock 236 271 465 minecraft:bone_block
fill 236 271 466 236 273 466 minecraft:brown_terracotta
setblock 236 271 480 minecraft:bone_block
setblock 236 271 481 minecraft:brown_terracotta
setblock 236 271 500 minecraft:bone_block
fill 236 271 501 236 272 503 minecraft:brown_terracotta
setblock 237 271 464 minecraft:bone_block
setblock 237 271 499 minecraft:bone_block
fill 237 271 500 237 273 500 minecraft:brown_terracotta
fill 237 271 502 237 271 503 minecraft:brown_terracotta
setblock 237 271 504 minecraft:bone_block
fill 238 271 464 238 273 465 minecraft:brown_terracotta
setblock 238 271 502 minecraft:brown_terracotta
setblock 238 271 503 minecraft:bone_block
fill 238 271 504 241 271 504 minecraft:brown_terracotta
setblock 239 271 502 minecraft:bone_block
fill 239 271 503 239 273 503 minecraft:brown_terracotta
setblock 240 271 501 minecraft:bone_block
fill 240 271 502 240 273 502 minecraft:brown_terracotta
setblock 241 271 464 minecraft:brown_terracotta
setblock 241 271 465 minecraft:bone_block
fill 241 271 501 241 273 501 minecraft:brown_terracotta
setblock 242 271 464 minecraft:bone_block
fill 242 271 465 242 273 465 minecraft:brown_terracotta
setblock 242 271 504 minecraft:bone_block
fill 243 271 464 243 273 464 minecraft:brown_terracotta
setblock 243 271 503 minecraft:bone_block
fill 243 271 504 243 273 504 minecraft:brown_terracotta
setblock 244 271 502 minecraft:bone_block
fill 244 271 503 244 273 503 minecraft:brown_terracotta
setblock 245 271 501 minecraft:bone_block
fill 245 271 502 245 273 502 minecraft:brown_terracotta
setblock 246 271 465 minecraft:bone_block
fill 246 271 501 246 272 501 minecraft:brown_terracotta
setblock 247 271 464 minecraft:bone_block
setblock 247 271 504 minecraft:bone_block
fill 248 271 464 248 273 464 minecraft:brown_terracotta
setblock 248 271 503 minecraft:bone_block
fill 248 271 504 248 273 504 minecraft:brown_terracotta
setblock 249 271 502 minecraft:bone_block
fill 249 271 503 249 273 503 minecraft:brown_terracotta
setblock 250 271 502 minecraft:brown_terracotta
setblock 252 271 504 minecraft:bone_block
fill 253 271 504 256 271 504 minecraft:brown_terracotta
setblock 257 271 504 minecraft:bone_block
fill 258 271 504 261 271 504 minecraft:brown_terracotta
fill 259 271 503 262 271 503 minecraft:brown_terracotta
fill 260 271 464 261 271 464 minecraft:brown_terracotta
setblock 262 271 464 minecraft:bone_block
setblock 262 271 504 minecraft:bone_block
fill 263 271 464 263 273 464 minecraft:brown_terracotta
setblock 263 271 503 minecraft:bone_block
fill 263 271 504 263 273 504 minecraft:brown_terracotta
fill 264 271 503 264 273 503 minecraft:brown_terracotta
setblock 266 271 465 minecraft:bone_block
setblock 267 271 464 minecraft:bone_block
fill 267 271 465 267 273 465 minecraft:brown_terracotta
setblock 267 271 504 minecraft:bone_block
fill 268 271 464 268 273 464 minecraft:brown_terracotta
setblock 268 271 503 minecraft:bone_block
fill 268 271 504 268 273 504 minecraft:brown_terracotta
setblock 272 271 464 minecraft:bone_block
setblock 272 271 504 minecraft:bone_block
fill 273 271 464 273 273 464 minecraft:brown_terracotta
fill 273 271 504 273 272 504 minecraft:brown_terracotta
setblock 276 271 464 minecraft:brown_terracotta
setblock 276 271 465 minecraft:bone_block
fill 276 271 466 276 273 466 minecraft:brown_terracotta
setblock 276 271 475 minecraft:bone_block
fill 276 271 476 276 272 476 minecraft:brown_terracotta
setblock 276 271 480 minecraft:bone_block
fill 276 271 481 276 273 481 minecraft:brown_terracotta
setblock 276 271 500 minecraft:bone_block
fill 276 271 501 276 272 501 minecraft:brown_terracotta
setblock 236 272 464 minecraft:bone_block
fill 236 272 465 236 273 465 minecraft:brown_terracotta
setblock 236 272 499 minecraft:bone_block
fill 236 272 500 236 273 500 minecraft:brown_terracotta
setblock 236 272 504 minecraft:bone_block
fill 237 272 464 237 273 464 minecraft:brown_terracotta
setblock 237 272 499 minecraft:brown_terracotta
setblock 237 272 502 minecraft:brown_terracotta
setblock 237 272 503 minecraft:bone_block
fill 237 272 504 240 272 504 minecraft:brown_terracotta
setblock 238 272 466 minecraft:light[level=12]
setblock 238 272 474 minecraft:light[level=12]
setblock 238 272 482 minecraft:light[level=12]
setblock 238 272 490 minecraft:light[level=12]
setblock 238 272 498 minecraft:light[level=12]
setblock 238 272 502 minecraft:bone_block
fill 238 272 503 238 273 503 minecraft:brown_terracotta
fill 239 272 502 239 273 502 minecraft:brown_terracotta
setblock 240 272 464 minecraft:brown_terracotta
setblock 240 272 465 minecraft:bone_block
setblock 240 272 501 minecraft:brown_terracotta
setblock 241 272 464 minecraft:bone_block
fill 241 272 465 241 273 465 minecraft:brown_terracotta
setblock 241 272 504 minecraft:bone_block
fill 242 272 464 242 273 464 minecraft:brown_terracotta
setblock 242 272 503 minecraft:bone_block
fill 242 272 504 242 273 504 minecraft:brown_terracotta
setblock 243 272 502 minecraft:bone_block
fill 243 272 503 243 273 503 minecraft:brown_terracotta
setblock 244 272 501 minecraft:bone_block
fill 244 272 502 244 273 502 minecraft:brown_terracotta
setblock 245 272 465 minecraft:bone_block
setblock 245 272 501 minecraft:brown_terracotta
setblock 246 272 464 minecraft:bone_block
setblock 246 272 466 minecraft:light[level=12]
setblock 246 272 474 minecraft:light[level=12]
setblock 246 272 482 minecraft:light[level=12]
setblock 246 272 490 minecraft:light[level=12]
setblock 246 272 498 minecraft:light[level=12]
setblock 246 272 504 minecraft:bone_block
fill 247 272 464 247 273 464 minecraft:brown_terracotta
setblock 247 272 503 minecraft:bone_block
fill 247 272 504 247 273 504 minecraft:brown_terracotta
setblock 248 272 502 minecraft:bone_block
fill 248 272 503 248 273 503 minecraft:brown_terracotta
setblock 249 272 502 minecraft:brown_terracotta
setblock 251 272 504 minecraft:bone_block
fill 252 272 504 255 272 504 minecraft:brown_terracotta
setblock 254 272 466 minecraft:light[level=12]
setblock 254 272 474 minecraft:light[level=12]
setblock 254 272 482 minecraft:light[level=12]
setblock 254 272 490 minecraft:light[level=12]
setblock 254 272 498 minecraft:light[level=12]
setblock 256 272 504 minecraft:bone_block
fill 257 272 504 260 272 504 minecraft:brown_terracotta
fill 259 272 464 260 272 464 minecraft:brown_terracotta
fill 259 272 503 261 272 503 minecraft:brown_terracotta
setblock 261 272 464 minecraft:bone_block
setblock 261 272 504 minecraft:bone_block
fill 262 272 464 262 273 464 minecraft:brown_terracotta
setblock 262 272 466 minecraft:light[level=12]
setblock 262 272 474 minecraft:light[level=12]
setblock 262 272 482 minecraft:light[level=12]
setblock 262 272 490 minecraft:light[level=12]
setblock 262 272 498 minecraft:light[level=12]
setblock 262 272 503 minecraft:bone_block
fill 262 272 504 262 273 504 minecraft:brown_terracotta
fill 263 272 465 263 273 465 minecraft:brown_terracotta
fill 263 272 503 263 273 503 minecraft:brown_terracotta
setblock 265 272 464 minecraft:brown_terracotta
setblock 265 272 465 minecraft:bone_block
setblock 266 272 464 minecraft:bone_block
fill 266 272 465 266 273 465 minecraft:brown_terracotta
setblock 266 272 504 minecraft:bone_block
fill 267 272 464 267 273 464 minecraft:brown_terracotta
setblock 267 272 503 minecraft:bone_block
fill 267 272 504 267 273 504 minecraft:brown_terracotta
setblock 270 272 466 minecraft:light[level=12]
setblock 270 272 474 minecraft:light[level=12]
setblock 270 272 482 minecraft:light[level=12]
setblock 270 272 490 minecraft:light[level=12]
setblock 270 272 498 minecraft:light[level=12]
setblock 271 272 464 minecraft:bone_block
setblock 271 272 504 minecraft:bone_block
fill 272 272 464 272 273 464 minecraft:brown_terracotta
setblock 272 272 504 minecraft:brown_terracotta
setblock 276 272 464 minecraft:bone_block
fill 276 272 465 276 273 465 minecraft:brown_terracotta
setblock 276 272 475 minecraft:brown_terracotta
setblock 276 272 479 minecraft:bone_block
fill 276 272 480 276 273 480 minecraft:brown_terracotta
setblock 276 272 504 minecraft:bone_block
setblock 236 273 464 minecraft:brown_terracotta
setblock 236 273 498 minecraft:bone_block
setblock 236 273 499 minecraft:brown_terracotta
fill 236 273 501 236 273 502 minecraft:brown_terracotta
setblock 236 273 503 minecraft:bone_block
fill 236 273 504 239 273 504 minecraft:brown_terracotta
setblock 237 273 465 minecraft:brown_terracotta
setblock 237 273 502 minecraft:bone_block
setblock 237 273 503 minecraft:brown_terracotta
setblock 238 273 501 minecraft:bone_block
setblock 238 273 502 minecraft:brown_terracotta
setblock 239 273 464 minecraft:brown_terracotta
setblock 239 273 465 minecraft:bone_block
setblock 240 273 464 minecraft:bone_block
setblock 240 273 465 minecraft:brown_terracotta
setblock 240 273 504 minecraft:bone_block
setblock 241 273 464 minecraft:brown_terracotta
setblock 241 273 503 minecraft:bone_block
setblock 241 273 504 minecraft:brown_terracotta
setblock 242 273 502 minecraft:bone_block
setblock 242 273 503 minecraft:brown_terracotta
setblock 243 273 501 minecraft:bone_block
setblock 243 273 502 minecraft:brown_terracotta
setblock 244 273 465 minecraft:bone_block
setblock 244 273 501 minecraft:brown_terracotta
setblock 245 273 464 minecraft:bone_block
setblock 245 273 465 minecraft:brown_terracotta
setblock 245 273 504 minecraft:bone_block
setblock 246 273 464 minecraft:brown_terracotta
setblock 246 273 503 minecraft:bone_block
setblock 246 273 504 minecraft:brown_terracotta
setblock 247 273 502 minecraft:bone_block
setblock 247 273 503 minecraft:brown_terracotta
setblock 250 273 504 minecraft:bone_block
fill 251 273 504 254 273 504 minecraft:brown_terracotta
setblock 255 273 504 minecraft:bone_block
fill 256 273 504 259 273 504 minecraft:brown_terracotta
setblock 259 273 464 minecraft:brown_terracotta
setblock 260 273 464 minecraft:bone_block
setblock 260 273 503 minecraft:brown_terracotta
setblock 260 273 504 minecraft:bone_block
setblock 261 273 464 minecraft:brown_terracotta
setblock 261 273 503 minecraft:bone_block
setblock 261 273 504 minecraft:brown_terracotta
setblock 262 273 465 minecraft:brown_terracotta
setblock 262 273 503 minecraft:brown_terracotta
setblock 264 273 464 minecraft:brown_terracotta
setblock 264 273 465 minecraft:bone_block
setblock 265 273 464 minecraft:bone_block
setblock 265 273 465 minecraft:brown_terracotta
setblock 265 273 504 minecraft:bone_block
setblock 266 273 464 minecraft:brown_terracotta
setblock 266 273 504 minecraft:brown_terracotta
setblock 270 273 464 minecraft:bone_block
setblock 270 273 504 minecraft:bone_block
setblock 271 273 464 minecraft:brown_terracotta
setblock 275 273 464 minecraft:bone_block
setblock 275 273 504 minecraft:bone_block
setblock 276 273 464 minecraft:brown_terracotta
setblock 276 273 468 minecraft:bone_block
setblock 276 273 478 minecraft:bone_block
setblock 276 273 479 minecraft:brown_terracotta
setblock 276 273 483 minecraft:bone_block
setblock 276 273 503 minecraft:bone_block
setblock 276 273 504 minecraft:brown_terracotta
fill 236 279 464 237 280 474 minecraft:soul_soil
fill 236 279 475 276 280 475 minecraft:bone_block
fill 236 279 476 237 280 486 minecraft:soul_soil
fill 236 279 487 252 279 487 minecraft:bone_block
fill 236 279 488 237 280 498 minecraft:soul_soil
fill 236 279 499 276 280 499 minecraft:bone_block
fill 236 279 500 237 280 504 minecraft:soul_soil
fill 238 279 464 238 280 474 minecraft:bone_block
fill 238 279 476 238 280 486 minecraft:bone_block
fill 238 279 488 238 280 498 minecraft:bone_block
fill 238 279 500 238 280 504 minecraft:bone_block
fill 239 279 464 240 280 474 minecraft:soul_soil
fill 239 279 476 240 280 486 minecraft:soul_soil
fill 239 279 488 240 280 498 minecraft:soul_soil
fill 239 279 500 240 280 504 minecraft:soul_soil
fill 241 279 464 241 280 474 minecraft:bone_block
fill 241 279 476 241 280 486 minecraft:bone_block
fill 241 279 488 241 280 498 minecraft:bone_block
fill 241 279 500 241 280 504 minecraft:bone_block
fill 242 279 464 243 280 474 minecraft:soul_soil
fill 242 279 476 243 280 486 minecraft:soul_soil
fill 242 279 488 243 280 498 minecraft:soul_soil
fill 242 279 500 243 280 504 minecraft:soul_soil
fill 244 279 464 244 280 474 minecraft:bone_block
fill 244 279 476 244 280 486 minecraft:bone_block
fill 244 279 488 244 280 498 minecraft:bone_block
fill 244 279 500 244 280 504 minecraft:bone_block
fill 245 279 464 246 280 474 minecraft:soul_soil
fill 245 279 476 246 280 486 minecraft:soul_soil
fill 245 279 488 246 280 498 minecraft:soul_soil
fill 245 279 500 246 280 504 minecraft:soul_soil
fill 247 279 464 247 280 474 minecraft:bone_block
fill 247 279 476 247 280 486 minecraft:bone_block
fill 247 279 488 247 280 498 minecraft:bone_block
fill 247 279 500 247 280 504 minecraft:bone_block
fill 248 279 464 249 280 474 minecraft:soul_soil
fill 248 279 476 249 280 486 minecraft:soul_soil
fill 248 279 488 249 280 498 minecraft:soul_soil
fill 248 279 500 249 280 504 minecraft:soul_soil
fill 250 279 464 250 280 474 minecraft:bone_block
fill 250 279 476 250 280 486 minecraft:bone_block
fill 250 279 488 250 280 498 minecraft:bone_block
fill 250 279 500 250 280 504 minecraft:bone_block
fill 251 279 464 252 280 474 minecraft:soul_soil
fill 251 279 476 252 279 486 minecraft:soul_soil
fill 251 279 488 252 279 498 minecraft:soul_soil
fill 251 279 500 252 280 504 minecraft:soul_soil
fill 253 279 464 253 280 474 minecraft:bone_block
fill 253 279 476 253 279 486 minecraft:bone_block
fill 253 279 488 253 279 498 minecraft:bone_block
fill 253 279 500 253 280 504 minecraft:bone_block
fill 254 279 464 255 280 474 minecraft:soul_soil
fill 254 279 476 254 279 485 minecraft:soul_soil
fill 254 279 489 254 279 498 minecraft:soul_soil
fill 254 279 500 255 280 504 minecraft:soul_soil
fill 255 279 476 255 279 484 minecraft:soul_soil
fill 255 279 490 255 279 498 minecraft:soul_soil
fill 256 279 464 256 280 474 minecraft:bone_block
fill 256 279 476 256 279 485 minecraft:bone_block
fill 256 279 489 256 279 498 minecraft:bone_block
fill 256 279 500 256 280 504 minecraft:bone_block
fill 257 279 464 258 280 474 minecraft:soul_soil
fill 257 279 476 258 279 486 minecraft:soul_soil
fill 257 279 488 258 279 498 minecraft:soul_soil
fill 257 279 500 258 280 504 minecraft:soul_soil
fill 258 279 487 276 279 487 minecraft:bone_block
fill 259 279 464 259 280 474 minecraft:bone_block
fill 259 279 476 259 280 486 minecraft:bone_block
fill 259 279 488 259 280 498 minecraft:bone_block
fill 259 279 500 259 280 504 minecraft:bone_block
fill 260 279 464 261 280 474 minecraft:soul_soil
fill 260 279 476 261 280 486 minecraft:soul_soil
fill 260 279 488 261 280 498 minecraft:soul_soil
fill 260 279 500 261 280 504 minecraft:soul_soil
fill 262 279 464 262 280 474 minecraft:bone_block
fill 262 279 476 262 280 486 minecraft:bone_block
fill 262 279 488 262 280 498 minecraft:bone_block
fill 262 279 500 262 280 504 minecraft:bone_block
fill 263 279 464 264 280 474 minecraft:soul_soil
fill 263 279 476 264 280 486 minecraft:soul_soil
fill 263 279 488 264 280 498 minecraft:soul_soil
fill 263 279 500 264 280 504 minecraft:soul_soil
fill 265 279 464 265 280 474 minecraft:bone_block
fill 265 279 476 265 280 486 minecraft:bone_block
fill 265 279 488 265 280 498 minecraft:bone_block
fill 265 279 500 265 280 504 minecraft:bone_block
fill 266 279 464 267 280 474 minecraft:soul_soil
fill 266 279 476 267 280 486 minecraft:soul_soil
fill 266 279 488 267 280 498 minecraft:soul_soil
fill 266 279 500 267 280 504 minecraft:soul_soil
fill 268 279 464 268 280 474 minecraft:bone_block
fill 268 279 476 268 280 486 minecraft:bone_block
fill 268 279 488 268 280 498 minecraft:bone_block
fill 268 279 500 268 280 504 minecraft:bone_block
fill 269 279 464 270 280 474 minecraft:soul_soil
fill 269 279 476 270 280 486 minecraft:soul_soil
fill 269 279 488 270 280 498 minecraft:soul_soil
fill 269 279 500 270 280 504 minecraft:soul_soil
fill 271 279 464 271 280 474 minecraft:bone_block
fill 271 279 476 271 280 486 minecraft:bone_block
fill 271 279 488 271 280 498 minecraft:bone_block
fill 271 279 500 271 280 504 minecraft:bone_block
fill 272 279 464 273 280 474 minecraft:soul_soil
fill 272 279 476 273 280 486 minecraft:soul_soil
fill 272 279 488 273 280 498 minecraft:soul_soil
fill 272 279 500 273 280 504 minecraft:soul_soil
fill 274 279 464 274 280 474 minecraft:bone_block
fill 274 279 476 274 280 486 minecraft:bone_block
fill 274 279 488 274 280 498 minecraft:bone_block
fill 274 279 500 274 280 504 minecraft:bone_block
fill 275 279 464 276 280 474 minecraft:soul_soil
fill 275 279 476 276 280 486 minecraft:soul_soil
fill 275 279 488 276 280 498 minecraft:soul_soil
fill 275 279 500 276 280 504 minecraft:soul_soil
fill 236 280 487 251 280 487 minecraft:bone_block
fill 251 280 476 251 280 486 minecraft:soul_soil
fill 251 280 488 251 280 498 minecraft:soul_soil
fill 252 280 476 252 280 485 minecraft:soul_soil
fill 252 280 486 252 280 488 minecraft:shroomlight
fill 252 280 489 252 280 498 minecraft:soul_soil
fill 253 280 476 253 280 484 minecraft:bone_block
fill 253 280 485 253 280 486 minecraft:shroomlight
fill 253 280 488 253 280 489 minecraft:shroomlight
fill 253 280 490 253 280 498 minecraft:bone_block
fill 254 280 476 255 280 483 minecraft:soul_soil
fill 254 280 484 254 280 485 minecraft:shroomlight
fill 254 280 489 254 280 490 minecraft:shroomlight
fill 254 280 491 255 280 498 minecraft:soul_soil
fill 255 280 484 256 280 484 minecraft:shroomlight
fill 255 280 490 256 280 490 minecraft:shroomlight
fill 256 280 476 256 280 483 minecraft:bone_block
fill 256 280 485 257 280 485 minecraft:shroomlight
fill 256 280 489 257 280 489 minecraft:shroomlight
fill 256 280 491 256 280 498 minecraft:bone_block
fill 257 280 476 258 280 484 minecraft:soul_soil
fill 257 280 486 258 280 486 minecraft:shroomlight
fill 257 280 488 258 280 488 minecraft:shroomlight
fill 257 280 490 258 280 498 minecraft:soul_soil
setblock 258 280 485 minecraft:soul_soil
setblock 258 280 487 minecraft:shroomlight
setblock 258 280 489 minecraft:soul_soil
fill 259 280 487 276 280 487 minecraft:bone_block
fill 236 284 464 236 284 466 minecraft:brown_terracotta
setblock 236 284 467 minecraft:bone_block
fill 236 284 468 236 284 471 minecraft:brown_terracotta
setblock 236 284 472 minecraft:bone_block
fill 236 284 473 236 284 476 minecraft:brown_terracotta
setblock 236 284 477 minecraft:bone_block
fill 236 284 478 236 284 481 minecraft:brown_terracotta
setblock 236 284 482 minecraft:bone_block
fill 236 284 483 236 284 486 minecraft:brown_terracotta
setblock 236 284 487 minecraft:bone_block
fill 236 284 488 236 284 491 minecraft:brown_terracotta
setblock 236 284 492 minecraft:bone_block
fill 236 284 493 236 284 496 minecraft:brown_terracotta
setblock 236 284 497 minecraft:bone_block
fill 236 284 498 236 284 501 minecraft:brown_terracotta
setblock 236 284 502 minecraft:bone_block
fill 236 284 503 238 284 504 minecraft:brown_terracotta
fill 237 284 464 237 284 465 minecraft:brown_terracotta
setblock 237 284 466 minecraft:bone_block
fill 237 284 467 237 284 470 minecraft:brown_terracotta
setblock 237 284 471 minecraft:bone_block
fill 237 284 472 237 286 473 minecraft:brown_terracotta
fill 237 284 483 237 284 485 minecraft:brown_terracotta
setblock 237 284 486 minecraft:bone_block
fill 237 284 487 237 284 490 minecraft:brown_terracotta
setblock 237 284 491 minecraft:bone_block
fill 237 284 492 237 284 495 minecraft:brown_terracotta
setblock 237 284 496 minecraft:bone_block
fill 237 284 497 237 284 500 minecraft:brown_terracotta
setblock 237 284 501 minecraft:bone_block
fill 237 284 502 237 287 502 minecraft:brown_terracotta
setblock 238 284 464 minecraft:brown_terracotta
setblock 238 284 465 minecraft:bone_block
fill 238 284 466 238 284 469 minecraft:brown_terracotta
setblock 238 284 470 minecraft:bone_block
setblock 238 284 485 minecraft:bone_block
fill 238 284 486 238 284 489 minecraft:brown_terracotta
setblock 238 284 490 minecraft:bone_block
fill 238 284 491 238 284 494 minecraft:brown_terracotta
setblock 238 284 495 minecraft:bone_block
fill 238 284 496 238 284 499 minecraft:brown_terracotta
setblock 238 284 500 minecraft:bone_block
setblock 239 284 464 minecraft:bone_block
fill 239 284 465 239 284 466 minecraft:brown_terracotta
setblock 239 284 488 minecraft:brown_terracotta
setblock 239 284 489 minecraft:bone_block
fill 239 284 490 239 284 493 minecraft:brown_terracotta
setblock 239 284 494 minecraft:bone_block
fill 239 284 495 239 285 495 minecraft:brown_terracotta
setblock 239 284 503 minecraft:brown_terracotta
setblock 239 284 504 minecraft:bone_block
fill 240 284 464 241 284 465 minecraft:brown_terracotta
setblock 240 284 503 minecraft:bone_block
fill 240 284 504 243 284 504 minecraft:brown_terracotta
fill 241 284 499 241 288 499 minecraft:soul_soil
fill 242 284 464 243 284 464 minecraft:brown_terracotta
fill 251 284 464 253 284 464 minecraft:brown_terracotta
setblock 253 284 465 minecraft:bone_block
setblock 254 284 464 minecraft:bone_block
fill 254 284 465 256 284 466 minecraft:brown_terracotta
fill 255 284 464 258 284 464 minecraft:brown_terracotta
fill 255 284 504 258 284 504 minecraft:brown_terracotta
setblock 256 284 467 minecraft:bone_block
setblock 257 284 465 minecraft:brown_terracotta
setblock 257 284 466 minecraft:bone_block
fill 257 284 467 260 284 467 minecraft:brown_terracotta
setblock 258 284 465 minecraft:bone_block
fill 258 284 466 261 284 466 minecraft:brown_terracotta
setblock 259 284 464 minecraft:bone_block
fill 259 284 465 262 284 465 minecraft:brown_terracotta
setblock 259 284 504 minecraft:bone_block
fill 260 284 464 263 284 464 minecraft:brown_terracotta
setblock 260 284 504 minecraft:brown_terracotta
setblock 261 284 467 minecraft:bone_block
setblock 262 284 466 minecraft:bone_block
setblock 263 284 465 minecraft:bone_block
fill 263 284 466 264 284 466 minecraft:brown_terracotta
setblock 264 284 464 minecraft:bone_block
fill 264 284 465 267 284 465 minecraft:brown_terracotta
fill 265 284 464 268 284 464 minecraft:brown_terracotta
setblock 268 284 465 minecraft:bone_block
setblock 269 284 464 minecraft:bone_block
fill 269 284 465 271 284 466 minecraft:brown_terracotta
fill 270 284 464 273 284 464 minecraft:brown_terracotta
fill 271 284 504 273 284 504 minecraft:brown_terracotta
setblock 272 284 465 minecraft:brown_terracotta
setblock 272 284 466 minecraft:bone_block
fill 272 284 467 275 284 467 minecraft:brown_terracotta
setblock 273 284 465 minecraft:bone_block
fill 273 284 466 276 284 466 minecraft:brown_terracotta
fill 273 284 468 273 284 469 minecraft:brown_terracotta
setblock 274 284 464 minecraft:bone_block
fill 274 284 465 276 285 465 minecraft:brown_terracotta
setblock 274 284 468 minecraft:brown_terracotta
setblock 274 284 469 minecraft:bone_block
fill 274 284 470 274 284 473 minecraft:brown_terracotta
setblock 274 284 503 minecraft:brown_terracotta
setblock 274 284 504 minecraft:bone_block
fill 275 284 464 276 286 464 minecraft:brown_terracotta
setblock 275 284 468 minecraft:bone_block
fill 275 284 469 275 284 472 minecraft:brown_terracotta
setblock 275 284 473 minecraft:bone_block
fill 275 284 474 276 285 475 minecraft:brown_terracotta
fill 275 284 486 275 284 487 minecraft:brown_terracotta
setblock 275 284 488 minecraft:bone_block
fill 275 284 489 275 284 492 minecraft:brown_terracotta
setblock 275 284 493 minecraft:bone_block
fill 275 284 494 275 284 497 minecraft:brown_terracotta
setblock 275 284 498 minecraft:bone_block
fill 275 284 499 275 284 502 minecraft:brown_terracotta
setblock 275 284 503 minecraft:bone_block
fill 275 284 504 276 286 504 minecraft:brown_terracotta
setblock 276 284 467 minecraft:bone_block
fill 276 284 468 276 284 471 minecraft:brown_terracotta
setblock 276 284 472 minecraft:bone_block
fill 276 284 473 276 287 473 minecraft:brown_terracotta
setblock 276 284 476 minecraft:brown_terracotta
setblock 276 284 477 minecraft:bone_block
fill 276 284 478 276 284 481 minecraft:brown_terracotta
setblock 276 284 482 minecraft:bone_block
fill 276 284 483 276 284 486 minecraft:brown_terracotta
setblock 276 284 487 minecraft:bone_block
fill 276 284 488 276 284 491 minecraft:brown_terracotta
setblock 276 284 492 minecraft:bone_block
fill 276 284 493 276 284 496 minecraft:brown_terracotta
setblock 276 284 497 minecraft:bone_block
fill 276 284 498 276 284 501 minecraft:brown_terracotta
setblock 276 284 502 minecraft:bone_block
fill 276 284 503 276 287 503 minecraft:brown_terracotta
fill 236 285 464 236 285 465 minecraft:brown_terracotta
setblock 236 285 466 minecraft:bone_block
fill 236 285 467 236 285 470 minecraft:brown_terracotta
setblock 236 285 471 minecraft:bone_block
fill 236 285 472 236 285 475 minecraft:brown_terracotta
setblock 236 285 476 minecraft:bone_block
fill 236 285 477 236 286 478 minecraft:brown_terracotta
setblock 236 285 480 minecraft:brown_terracotta
setblock 236 285 481 minecraft:bone_block
fill 236 285 482 236 285 485 minecraft:brown_terracotta
setblock 236 285 486 minecraft:bone_block
fill 236 285 487 236 285 490 minecraft:brown_terracotta
setblock 236 285 491 minecraft:bone_block
fill 236 285 492 236 285 495 minecraft:brown_terracotta
setblock 236 285 496 minecraft:bone_block
fill 236 285 497 236 285 500 minecraft:brown_terracotta
setblock 236 285 501 minecraft:bone_block
fill 236 285 502 236 286 504 minecraft:brown_terracotta
setblock 237 285 464 minecraft:brown_terracotta
setblock 237 285 465 minecraft:bone_block
fill 237 285 466 237 285 469 minecraft:brown_terracotta
setblock 237 285 470 minecraft:bone_block
fill 237 285 471 237 288 471 minecraft:brown_terracotta
setblock 237 285 474 minecraft:brown_terracotta
setblock 237 285 484 minecraft:brown_terracotta
setblock 237 285 485 minecraft:bone_block
fill 237 285 486 237 285 489 minecraft:brown_terracotta
setblock 237 285 490 minecraft:bone_block
fill 237 285 491 237 285 494 minecraft:brown_terracotta
setblock 237 285 495 minecraft:bone_block
fill 237 285 496 237 285 499 minecraft:brown_terracotta
setblock 237 285 500 minecraft:bone_block
fill 237 285 501 237 288 501 minecraft:brown_terracotta
fill 237 285 503 237 285 504 minecraft:brown_terracotta
setblock 238 285 464 minecraft:bone_block
fill 238 285 465 239 285 465 minecraft:brown_terracotta
fill 238 285 486 238 285 488 minecraft:brown_terracotta
setblock 238 285 489 minecraft:bone_block
fill 238 285 490 238 285 493 minecraft:brown_terracotta
setblock 238 285 494 minecraft:bone_block
fill 238 285 495 238 285 498 minecraft:brown_terracotta
setblock 238 285 499 minecraft:bone_block
setblock 238 285 503 minecraft:brown_terracotta
setblock 238 285 504 minecraft:bone_block
fill 239 285 464 241 285 464 minecraft:brown_terracotta
fill 239 285 489 239 285 492 minecraft:brown_terracotta
setblock 239 285 493 minecraft:bone_block
fill 239 285 494 239 286 494 minecraft:brown_terracotta
setblock 239 285 503 minecraft:bone_block
fill 239 285 504 241 285 504 minecraft:brown_terracotta
setblock 252 285 464 minecraft:brown_terracotta
setblock 253 285 464 minecraft:bone_block
fill 253 285 465 256 285 465 minecraft:brown_terracotta
fill 254 285 464 257 285 464 minecraft:brown_terracotta
setblock 255 285 466 minecraft:brown_terracotta
setblock 256 285 466 minecraft:bone_block
fill 256 285 504 257 285 504 minecraft:brown_terracotta
setblock 257 285 465 minecraft:bone_block
fill 257 285 466 258 285 467 minecraft:brown_terracotta
setblock 258 285 464 minecraft:bone_block
fill 258 285 465 261 285 465 minecraft:brown_terracotta
fill 259 285 464 262 285 464 minecraft:brown_terracotta
fill 259 285 466 260 285 466 minecraft:brown_terracotta
setblock 261 285 466 minecraft:bone_block
setblock 262 285 465 minecraft:bone_block
setblock 262 285 466 minecraft:brown_terracotta
setblock 263 285 464 minecraft:bone_block
fill 263 285 465 266 285 465 minecraft:brown_terracotta
fill 264 285 464 267 285 464 minecraft:brown_terracotta
setblock 267 285 465 minecraft:bone_block
setblock 268 285 464 minecraft:bone_block
fill 268 285 465 271 285 465 minecraft:brown_terracotta
fill 269 285 464 272 285 464 minecraft:brown_terracotta
setblock 270 285 466 minecraft:brown_terracotta
setblock 271 285 466 minecraft:bone_block
fill 271 285 504 272 285 504 minecraft:brown_terracotta
setblock 272 285 465 minecraft:bone_block
fill 272 285 466 275 285 466 minecraft:brown_terracotta
setblock 273 285 464 minecraft:bone_block
fill 273 285 465 273 288 465 minecraft:brown_terracotta
fill 273 285 467 273 285 468 minecraft:brown_terracotta
setblock 273 285 469 minecraft:bone_block
setblock 273 285 504 minecraft:bone_block
fill 274 285 464 274 288 464 minecraft:brown_terracotta
setblock 274 285 467 minecraft:brown_terracotta
setblock 274 285 468 minecraft:bone_block
fill 274 285 469 274 285 472 minecraft:brown_terracotta
setblock 274 285 473 minecraft:bone_block
setblock 274 285 503 minecraft:bone_block
fill 274 285 504 274 288 504 minecraft:brown_terracotta
setblock 275 285 467 minecraft:bone_block
fill 275 285 468 275 285 471 minecraft:brown_terracotta
setblock 275 285 472 minecraft:bone_block
fill 275 285 473 275 288 473 minecraft:brown_terracotta
setblock 275 285 487 minecraft:bone_block
fill 275 285 488 275 285 491 minecraft:brown_terracotta
setblock 275 285 492 minecraft:bone_block
fill 275 285 493 275 285 496 minecraft:brown_terracotta
setblock 275 285 497 minecraft:bone_block
fill 275 285 498 275 285 501 minecraft:brown_terracotta
setblock 275 285 502 minecraft:bone_block
fill 275 285 503 275 288 503 minecraft:brown_terracotta
setblock 276 285 466 minecraft:bone_block
fill 276 285 467 276 285 470 minecraft:brown_terracotta
setblock 276 285 471 minecraft:bone_block
fill 276 285 472 276 288 472 minecraft:brown_terracotta
setblock 276 285 476 minecraft:bone_block
fill 276 285 477 276 286 478 minecraft:brown_terracotta
fill 276 285 483 276 285 485 minecraft:brown_terracotta
setblock 276 285 486 minecraft:bone_block
fill 276 285 487 276 285 490 minecraft:brown_terracotta
setblock 276 285 491 minecraft:bone_block
fill 276 285 492 276 285 495 minecraft:brown_terracotta
setblock 276 285 496 minecraft:bone_block
fill 276 285 497 276 285 500 minecraft:brown_terracotta
setblock 276 285 501 minecraft:bone_block
fill 276 285 502 276 288 502 minecraft:brown_terracotta
setblock 236 286 464 minecraft:brown_terracotta
setblock 236 286 465 minecraft:bone_block
fill 236 286 466 236 286 469 minecraft:brown_terracotta
setblock 236 286 470 minecraft:bone_block
fill 236 286 471 236 286 474 minecraft:brown_terracotta
setblock 236 286 475 minecraft:bone_block
fill 236 286 476 236 289 476 minecraft:brown_terracotta
fill 236 286 482 236 286 484 minecraft:brown_terracotta
setblock 236 286 485 minecraft:bone_block
fill 236 286 486 236 286 489 minecraft:brown_terracotta
setblock 236 286 490 minecraft:bone_block
fill 236 286 491 236 286 494 minecraft:brown_terracotta
setblock 236 286 495 minecraft:bone_block
fill 236 286 496 236 286 499 minecraft:brown_terracotta
setblock 236 286 500 minecraft:bone_block
fill 236 286 501 236 289 501 minecraft:brown_terracotta
setblock 237 286 464 minecraft:bone_block
fill 237 286 465 237 286 468 minecraft:brown_terracotta
setblock 237 286 469 minecraft:bone_block
fill 237 286 470 237 287 470 minecraft:brown_terracotta
fill 237 286 485 237 286 488 minecraft:brown_terracotta
setblock 237 286 489 minecraft:bone_block
fill 237 286 490 237 286 493 minecraft:brown_terracotta
setblock 237 286 494 minecraft:bone_block
fill 237 286 495 237 286 498 minecraft:brown_terracotta
setblock 237 286 499 minecraft:bone_block
fill 237 286 500 237 289 500 minecraft:brown_terracotta
setblock 237 286 503 minecraft:brown_terracotta
setblock 237 286 504 minecraft:bone_block
fill 238 286 464 238 286 465 minecraft:brown_terracotta
setblock 238 286 487 minecraft:brown_terracotta
setblock 238 286 488 minecraft:bone_block
fill 238 286 489 238 286 492 minecraft:brown_terracotta
setblock 238 286 493 minecraft:bone_block
fill 238 286 494 238 286 497 minecraft:brown_terracotta
setblock 238 286 498 minecraft:bone_block
setblock 238 286 503 minecraft:bone_block
fill 238 286 504 240 286 504 minecraft:brown_terracotta
fill 239 286 464 240 286 464 minecraft:brown_terracotta
fill 239 286 490 239 286 491 minecraft:brown_terracotta
setblock 239 286 492 minecraft:bone_block
setblock 239 286 493 minecraft:brown_terracotta
fill 240 286 499 240 288 499 minecraft:soul_soil
fill 241 286 498 241 288 498 minecraft:soul_soil
fill 241 286 500 241 288 500 minecraft:soul_soil
fill 242 286 499 242 288 499 minecraft:soul_soil
setblock 252 286 464 minecraft:bone_block
fill 253 286 464 256 286 464 minecraft:brown_terracotta
fill 254 286 465 255 286 465 minecraft:brown_terracotta
setblock 255 286 466 minecraft:bone_block
setblock 256 286 465 minecraft:bone_block
fill 256 286 466 259 286 466 minecraft:brown_terracotta
setblock 257 286 464 minecraft:bone_block
fill 257 286 465 260 286 465 minecraft:brown_terracotta
fill 258 286 464 261 286 464 minecraft:brown_terracotta
setblock 261 286 465 minecraft:bone_block
setblock 262 286 464 minecraft:bone_block
setblock 262 286 465 minecraft:brown_terracotta
fill 263 286 464 266 286 464 minecraft:brown_terracotta
setblock 267 286 464 minecraft:bone_block
fill 268 286 464 270 286 465 minecraft:brown_terracotta
setblock 271 286 464 minecraft:brown_terracotta
setblock 271 286 465 minecraft:bone_block
fill 271 286 466 274 286 466 minecraft:brown_terracotta
setblock 271 286 504 minecraft:brown_terracotta
setblock 272 286 464 minecraft:bone_block
fill 272 286 465 272 289 465 minecraft:brown_terracotta
setblock 272 286 504 minecraft:bone_block
fill 273 286 464 273 289 464 minecraft:brown_terracotta
fill 273 286 504 273 289 504 minecraft:brown_terracotta
fill 274 286 465 275 286 465 minecraft:brown_terracotta
setblock 274 286 467 minecraft:bone_block
fill 274 286 468 274 286 471 minecraft:brown_terracotta
setblock 274 286 472 minecraft:bone_block
fill 274 286 473 274 287 473 minecraft:brown_terracotta
fill 274 286 493 276 287 493 minecraft:brown_terracotta
fill 274 286 503 274 289 503 minecraft:brown_terracotta
setblock 275 286 466 minecraft:bone_block
fill 275 286 467 275 286 470 minecraft:brown_terracotta
setblock 275 286 471 minecraft:bone_block
fill 275 286 472 275 289 472 minecraft:brown_terracotta
fill 275 286 474 275 286 475 minecraft:brown_terracotta
fill 275 286 487 275 286 490 minecraft:brown_terracotta
setblock 275 286 491 minecraft:bone_block
fill 275 286 492 276 288 492 minecraft:brown_terracotta
fill 275 286 494 275 286 495 minecraft:brown_terracotta
setblock 275 286 496 minecraft:bone_block
fill 275 286 497 275 286 500 minecraft:brown_terracotta
setblock 275 286 501 minecraft:bone_block
fill 275 286 502 275 289 502 minecraft:brown_terracotta
setblock 276 286 465 minecraft:bone_block
fill 276 286 466 276 286 469 minecraft:brown_terracotta
setblock 276 286 470 minecraft:bone_block
fill 276 286 471 276 289 471 minecraft:brown_terracotta
setblock 276 286 474 minecraft:brown_terracotta
setblock 276 286 475 minecraft:bone_block
fill 276 286 476 276 289 476 minecraft:brown_terracotta
setblock 276 286 484 minecraft:brown_terracotta
setblock 276 286 485 minecraft:bone_block
fill 276 286 486 276 286 489 minecraft:brown_terracotta
setblock 276 286 490 minecraft:bone_block
fill 276 286 491 276 289 491 minecraft:brown_terracotta
setblock 276 286 494 minecraft:brown_terracotta
setblock 276 286 495 minecraft:bone_block
fill 276 286 496 276 286 499 minecraft:brown_terracotta
setblock 276 286 500 minecraft:bone_block
fill 276 286 501 276 289 501 minecraft:brown_terracotta
setblock 236 287 464 minecraft:bone_block
fill 236 287 465 236 287 468 minecraft:brown_terracotta
setblock 236 287 469 minecraft:bone_block
fill 236 287 470 236 287 473 minecraft:brown_terracotta
setblock 236 287 474 minecraft:bone_block
fill 236 287 475 236 290 475 minecraft:brown_terracotta
fill 236 287 477 236 288 477 minecraft:brown_terracotta
setblock 236 287 483 minecraft:brown_terracotta
setblock 236 287 484 minecraft:bone_block
fill 236 287 485 236 287 488 minecraft:brown_terracotta
setblock 236 287 489 minecraft:bone_block
fill 236 287 490 236 287 493 minecraft:brown_terracotta
setblock 236 287 494 minecraft:bone_block
fill 236 287 495 236 287 498 minecraft:brown_terracotta
setblock 236 287 499 minecraft:bone_block
fill 236 287 500 236 290 500 minecraft:brown_terracotta
fill 236 287 502 236 287 503 minecraft:brown_terracotta
setblock 236 287 504 minecraft:bone_block
fill 237 287 464 238 287 464 minecraft:brown_terracotta
setblock 237 287 467 minecraft:brown_terracotta
setblock 237 287 468 minecraft:bone_block
setblock 237 287 469 minecraft:brown_terracotta
setblock 237 287 472 minecraft:brown_terracotta
setblock 237 287 473 minecraft:bone_block
fill 237 287 486 237 287 487 minecraft:brown_terracotta
setblock 237 287 488 minecraft:bone_block
fill 237 287 489 237 287 492 minecraft:brown_terracotta
setblock 237 287 493 minecraft:bone_block
fill 237 287 494 237 287 497 minecraft:brown_terracotta
setblock 237 287 498 minecraft:bone_block
fill 237 287 499 237 290 499 minecraft:brown_terracotta
setblock 237 287 503 minecraft:bone_block
fill 237 287 504 239 287 504 minecraft:brown_terracotta
fill 238 287 488 238 287 491 minecraft:brown_terracotta
setblock 238 287 492 minecraft:bone_block
fill 238 287 493 238 287 496 minecraft:brown_terracotta
setblock 238 287 497 minecraft:bone_block
setblock 238 287 498 minecraft:brown_terracotta
fill 253 287 464 255 287 464 minecraft:brown_terracotta
setblock 254 287 465 minecraft:brown_terracotta
setblock 255 287 465 minecraft:bone_block
setblock 256 287 464 minecraft:bone_block
fill 256 287 465 259 287 465 minecraft:brown_terracotta
fill 257 287 464 260 287 464 minecraft:brown_terracotta
setblock 260 287 465 minecraft:bone_block
setblock 261 287 464 minecraft:bone_block
fill 262 287 464 263 287 464 minecraft:brown_terracotta
fill 267 287 464 270 287 464 minecraft:brown_terracotta
setblock 270 287 465 minecraft:bone_block
setblock 271 287 464 minecraft:bone_block
fill 271 287 465 271 289 465 minecraft:brown_terracotta
setblock 271 287 504 minecraft:bone_block
fill 272 287 464 272 290 464 minecraft:brown_terracotta
fill 272 287 466 273 287 466 minecraft:brown_terracotta
fill 272 287 504 272 290 504 minecraft:brown_terracotta
setblock 274 287 465 minecraft:brown_terracotta
setblock 274 287 466 minecraft:bone_block
fill 274 287 467 274 287 470 minecraft:brown_terracotta
setblock 274 287 471 minecraft:bone_block
fill 274 287 472 274 289 472 minecraft:brown_terracotta
fill 274 287 494 274 287 495 minecraft:brown_terracotta
setblock 275 287 464 minecraft:brown_terracotta
setblock 275 287 465 minecraft:bone_block
fill 275 287 466 275 287 469 minecraft:brown_terracotta
setblock 275 287 470 minecraft:bone_block
fill 275 287 471 275 290 471 minecraft:brown_terracotta
setblock 275 287 474 minecraft:brown_terracotta
setblock 275 287 475 minecraft:bone_block
fill 275 287 488 275 287 489 minecraft:brown_terracotta
setblock 275 287 490 minecraft:bone_block
fill 275 287 491 275 290 491 minecraft:brown_terracotta
setblock 275 287 494 minecraft:brown_terracotta
setblock 275 287 495 minecraft:bone_block
fill 275 287 496 275 287 499 minecraft:brown_terracotta
setblock 275 287 500 minecraft:bone_block
fill 275 287 501 275 290 501 minecraft:brown_terracotta
setblock 275 287 504 minecraft:brown_terracotta
setblock 276 287 464 minecraft:bone_block
fill 276 287 465 276 287 468 minecraft:brown_terracotta
setblock 276 287 469 minecraft:bone_block
fill 276 287 470 276 290 470 minecraft:brown_terracotta
setblock 276 287 474 minecraft:bone_block
fill 276 287 475 276 290 475 minecraft:brown_terracotta
fill 276 287 477 276 288 477 minecraft:brown_terracotta
fill 276 287 486 276 287 488 minecraft:brown_terracotta
setblock 276 287 489 minecraft:bone_block
fill 276 287 490 276 290 490 minecraft:brown_terracotta
setblock 276 287 494 minecraft:bone_block
fill 276 287 495 276 287 498 minecraft:brown_terracotta
setblock 276 287 499 minecraft:bone_block
fill 276 287 500 276 290 500 minecraft:brown_terracotta
setblock 276 287 504 minecraft:bone_block
fill 236 288 464 236 288 467 minecraft:brown_terracotta
setblock 236 288 468 minecraft:bone_block
fill 236 288 469 236 288 472 minecraft:brown_terracotta
setblock 236 288 473 minecraft:bone_block
fill 236 288 474 236 291 474 minecraft:brown_terracotta
fill 236 288 484 236 288 487 minecraft:brown_terracotta
setblock 236 288 488 minecraft:bone_block
fill 236 288 489 236 288 492 minecraft:brown_terracotta
setblock 236 288 493 minecraft:bone_block
fill 236 288 494 236 288 497 minecraft:brown_terracotta
setblock 236 288 498 minecraft:bone_block
fill 236 288 499 236 291 499 minecraft:brown_terracotta
setblock 236 288 502 minecraft:brown_terracotta
setblock 236 288 503 minecraft:bone_block
fill 236 288 504 238 288 504 minecraft:brown_terracotta
setblock 237 288 472 minecraft:bone_block
setblock 237 288 487 minecraft:bone_block
fill 237 288 488 237 288 491 minecraft:brown_terracotta
setblock 237 288 492 minecraft:bone_block
fill 237 288 493 237 288 496 minecraft:brown_terracotta
setblock 237 288 497 minecraft:bone_block
fill 237 288 498 237 291 498 minecraft:brown_terracotta
setblock 238 288 466 minecraft:light[level=12]
setblock 238 288 474 minecraft:light[level=12]
setblock 238 288 482 minecraft:light[level=12]
setblock 238 288 490 minecraft:brown_terracotta
setblock 238 288 491 minecraft:bone_block
fill 238 288 492 238 288 495 minecraft:brown_terracotta
setblock 238 288 496 minecraft:bone_block
fill 238 288 497 238 290 497 minecraft:brown_terracotta
setblock 238 288 498 minecraft:light[level=12]
setblock 246 288 466 minecraft:light[level=12]
setblock 246 288 474 minecraft:light[level=12]
setblock 246 288 482 minecraft:light[level=12]
setblock 246 288 490 minecraft:light[level=12]
setblock 246 288 498 minecraft:light[level=12]
fill 253 288 464 254 288 464 minecraft:brown_terracotta
setblock 254 288 466 minecraft:light[level=12]
setblock 254 288 474 minecraft:light[level=12]
setblock 254 288 482 minecraft:light[level=12]
setblock 254 288 490 minecraft:light[level=12]
setblock 254 288 498 minecraft:light[level=12]
setblock 255 288 464 minecraft:bone_block
fill 256 288 464 259 288 464 minecraft:brown_terracotta
setblock 260 288 464 minecraft:bone_block
setblock 262 288 466 minecraft:light[level=12]
setblock 262 288 474 minecraft:light[level=12]
setblock 262 288 482 minecraft:light[level=12]
setblock 262 288 490 minecraft:light[level=12]
setblock 262 288 498 minecraft:light[level=12]
fill 268 288 464 269 288 464 minecraft:brown_terracotta
setblock 270 288 464 minecraft:bone_block
setblock 270 288 465 minecraft:brown_terracotta
setblock 270 288 466 minecraft:light[level=12]
setblock 270 288 474 minecraft:light[level=12]
setblock 270 288 482 minecraft:light[level=12]
setblock 270 288 490 minecraft:light[level=12]
setblock 270 288 498 minecraft:light[level=12]
fill 271 288 464 271 291 464 minecraft:brown_terracotta
fill 271 288 504 271 291 504 minecraft:brown_terracotta
setblock 274 288 465 minecraft:bone_block
fill 274 288 466 274 288 469 minecraft:brown_terracotta
setblock 274 288 470 minecraft:bone_block
fill 274 288 471 274 289 471 minecraft:brown_terracotta
fill 274 288 493 274 288 494 minecraft:brown_terracotta
setblock 274 288 495 minecraft:bone_block
fill 274 288 496 276 289 496 minecraft:brown_terracotta
setblock 275 288 464 minecraft:bone_block
fill 275 288 465 275 288 468 minecraft:brown_terracotta
setblock 275 288 469 minecraft:bone_block
fill 275 288 470 275 291 470 minecraft:brown_terracotta
setblock 275 288 474 minecraft:bone_block
fill 275 288 475 275 291 475 minecraft:brown_terracotta
setblock 275 288 489 minecraft:bone_block
fill 275 288 490 275 290 490 minecraft:brown_terracotta
setblock 275 288 493 minecraft:brown_terracotta
setblock 275 288 494 minecraft:bone_block
fill 275 288 495 276 290 495 minecraft:brown_terracotta
fill 275 288 497 275 288 498 minecraft:brown_terracotta
setblock 275 288 499 minecraft:bone_block
fill 275 288 500 275 291 500 minecraft:brown_terracotta
setblock 275 288 504 minecraft:bone_block
fill 276 288 464 276 288 467 minecraft:brown_terracotta
setblock 276 288 468 minecraft:bone_block
fill 276 288 469 276 291 469 minecraft:brown_terracotta
setblock 276 288 473 minecraft:bone_block
fill 276 288 474 276 291 474 minecraft:brown_terracotta
setblock 276 288 487 minecraft:brown_terracotta
setblock 276 288 488 minecraft:bone_block
fill 276 288 489 276 291 489 minecraft:brown_terracotta
setblock 276 288 493 minecraft:bone_block
fill 276 288 494 276 291 494 minecraft:brown_terracotta
setblock 276 288 497 minecraft:brown_terracotta
setblock 276 288 498 minecraft:bone_block
fill 276 288 499 276 291 499 minecraft:brown_terracotta
setblock 276 288 503 minecraft:bone_block
fill 276 288 504 276 291 504 minecraft:brown_terracotta
setblock 236 289 466 minecraft:brown_terracotta
setblock 236 289 467 minecraft:bone_block
fill 236 289 468 236 289 471 minecraft:brown_terracotta
setblock 236 289 472 minecraft:bone_block
fill 236 289 473 236 292 473 minecraft:brown_terracotta
setblock 236 289 477 minecraft:bone_block
fill 236 289 485 236 289 486 minecraft:brown_terracotta
setblock 236 289 487 minecraft:bone_block
fill 236 289 488 236 289 491 minecraft:brown_terracotta
setblock 236 289 492 minecraft:bone_block
fill 236 289 493 236 289 496 minecraft:brown_terracotta
setblock 236 289 497 minecraft:bone_block
fill 236 289 498 236 292 498 minecraft:brown_terracotta
setblock 236 289 502 minecraft:bone_block
fill 236 289 503 236 291 504 minecraft:brown_terracotta
fill 237 289 488 237 289 490 minecraft:brown_terracotta
setblock 237 289 491 minecraft:bone_block
fill 237 289 492 237 289 495 minecraft:brown_terracotta
setblock 237 289 496 minecraft:bone_block
fill 237 289 497 237 292 497 minecraft:brown_terracotta
setblock 237 289 504 minecraft:brown_terracotta
fill 238 289 491 238 289 494 minecraft:brown_terracotta
setblock 238 289 495 minecraft:bone_block
fill 238 289 496 238 292 496 minecraft:brown_terracotta
setblock 254 289 464 minecraft:bone_block
fill 255 289 464 258 289 464 minecraft:brown_terracotta
setblock 269 289 464 minecraft:bone_block
fill 270 289 464 270 292 464 minecraft:brown_terracotta
setblock 273 289 465 minecraft:bone_block
setblock 274 289 464 minecraft:bone_block
fill 274 289 465 276 289 465 minecraft:brown_terracotta
setblock 274 289 469 minecraft:bone_block
setblock 274 289 470 minecraft:brown_terracotta
setblock 274 289 493 minecraft:brown_terracotta
setblock 274 289 494 minecraft:bone_block
fill 274 289 495 274 292 495 minecraft:brown_terracotta
fill 274 289 497 275 289 497 minecraft:brown_terracotta
setblock 274 289 504 minecraft:bone_block
fill 275 289 464 276 291 464 minecraft:brown_terracotta
fill 275 289 466 275 289 467 minecraft:brown_terracotta
setblock 275 289 468 minecraft:bone_block
fill 275 289 469 275 291 469 minecraft:brown_terracotta
setblock 275 289 473 minecraft:bone_block
fill 275 289 474 275 292 474 minecraft:brown_terracotta
setblock 275 289 492 minecraft:brown_terracotta
setblock 275 289 493 minecraft:bone_block
fill 275 289 494 275 292 494 minecraft:brown_terracotta
setblock 275 289 498 minecraft:bone_block
fill 275 289 499 275 292 499 minecraft:brown_terracotta
setblock 275 289 503 minecraft:bone_block
fill 275 289 504 275 292 504 minecraft:brown_terracotta
setblock 276 289 466 minecraft:brown_terracotta
setblock 276 289 467 minecraft:bone_block
fill 276 289 468 276 292 468 minecraft:brown_terracotta
setblock 276 289 472 minecraft:bone_block
fill 276 289 473 276 292 473 minecraft:brown_terracotta
setblock 276 289 477 minecraft:bone_block
fill 276 289 488 276 290 488 minecraft:brown_terracotta
setblock 276 289 492 minecraft:bone_block
fill 276 289 493 276 292 493 minecraft:brown_terracotta
setblock 276 289 497 minecraft:bone_block
fill 276 289 498 276 292 498 minecraft:brown_terracotta
setblock 276 289 502 minecraft:bone_block
fill 276 289 503 276 292 503 minecraft:brown_terracotta
fill 236 290 468 236 290 470 minecraft:brown_terracotta
setblock 236 290 471 minecraft:bone_block
fill 236 290 472 236 293 472 minecraft:brown_terracotta
setblock 236 290 476 minecraft:bone_block
fill 236 290 477 236 292 478 minecraft:brown_terracotta
setblock 236 290 485 minecraft:brown_terracotta
setblock 236 290 486 minecraft:bone_block
fill 236 290 487 236 290 490 minecraft:brown_terracotta
setblock 236 290 491 minecraft:bone_block
fill 236 290 492 236 290 495 minecraft:brown_terracotta
setblock 236 290 496 minecraft:bone_block
fill 236 290 497 236 293 497 minecraft:brown_terracotta
setblock 236 290 501 minecraft:bone_block
fill 236 290 502 236 293 502 minecraft:brown_terracotta
setblock 237 290 489 minecraft:brown_terracotta
setblock 237 290 490 minecraft:bone_block
fill 237 290 491 237 290 494 minecraft:brown_terracotta
setblock 237 290 495 minecraft:bone_block
fill 237 290 496 237 293 496 minecraft:brown_terracotta
setblock 237 290 500 minecraft:bone_block
fill 238 290 492 238 290 493 minecraft:brown_terracotta
setblock 238 290 494 minecraft:bone_block
fill 238 290 495 238 293 495 minecraft:brown_terracotta
fill 254 290 464 256 290 464 minecraft:brown_terracotta
fill 269 290 464 269 293 464 minecraft:brown_terracotta
fill 270 290 504 270 292 504 minecraft:brown_terracotta
setblock 272 290 465 minecraft:bone_block
setblock 273 290 464 minecraft:bone_block
fill 273 290 465 274 290 465 minecraft:brown_terracotta
setblock 273 290 503 minecraft:brown_terracotta
setblock 273 290 504 minecraft:bone_block
fill 274 290 464 274 293 464 minecraft:brown_terracotta
setblock 274 290 493 minecraft:bone_block
fill 274 290 494 274 293 494 minecraft:brown_terracotta
fill 274 290 496 274 290 497 minecraft:brown_terracotta
setblock 274 290 498 minecraft:bone_block
fill 274 290 499 274 293 499 minecraft:brown_terracotta
setblock 274 290 503 minecraft:bone_block
fill 274 290 504 274 293 504 minecraft:brown_terracotta
setblock 275 290 466 minecraft:brown_terracotta
setblock 275 290 467 minecraft:bone_block
fill 275 290 468 275 291 468 minecraft:brown_terracotta
setblock 275 290 472 minecraft:bone_block
fill 275 290 473 275 293 473 minecraft:brown_terracotta
setblock 275 290 492 minecraft:bone_block
fill 275 290 493 275 293 493 minecraft:brown_terracotta
setblock 275 290 496 minecraft:brown_terracotta
setblock 275 290 497 minecraft:bone_block
fill 275 290 498 275 293 498 minecraft:brown_terracotta
setblock 275 290 502 minecraft:bone_block
fill 275 290 503 275 293 503 minecraft:brown_terracotta
setblock 276 290 465 minecraft:brown_terracotta
setblock 276 290 466 minecraft:bone_block
fill 276 290 467 276 293 467 minecraft:brown_terracotta
setblock 276 290 471 minecraft:bone_block
fill 276 290 472 276 293 472 minecraft:brown_terracotta
setblock 276 290 476 minecraft:bone_block
fill 276 290 477 276 293 477 minecraft:brown_terracotta
setblock 276 290 491 minecraft:bone_block
fill 276 290 492 276 293 492 minecraft:brown_terracotta
setblock 276 290 496 minecraft:bone_block
fill 276 290 497 276 293 497 minecraft:brown_terracotta
setblock 276 290 501 minecraft:bone_block
fill 276 290 502 276 293 502 minecraft:brown_terracotta
setblock 236 291 470 minecraft:bone_block
fill 236 291 471 236 294 471 minecraft:brown_terracotta
setblock 236 291 475 minecraft:bone_block
fill 236 291 476 236 294 476 minecraft:brown_terracotta
setblock 236 291 479 minecraft:brown_terracotta
fill 236 291 486 236 291 489 minecraft:brown_terracotta
setblock 236 291 490 minecraft:bone_block
fill 236 291 491 236 291 494 minecraft:brown_terracotta
setblock 236 291 495 minecraft:bone_block
fill 236 291 496 236 294 496 minecraft:brown_terracotta
setblock 236 291 500 minecraft:bone_block
fill 236 291 501 236 294 501 minecraft:brown_terracotta
setblock 237 291 489 minecraft:bone_block
fill 237 291 490 237 291 493 minecraft:brown_terracotta
setblock 237 291 494 minecraft:bone_block
fill 237 291 495 237 294 495 minecraft:brown_terracotta
setblock 237 291 499 minecraft:bone_block
fill 237 291 500 237 294 500 minecraft:brown_terracotta
setblock 238 291 493 minecraft:bone_block
fill 238 291 494 238 292 494 minecraft:brown_terracotta
fill 254 291 464 255 292 464 minecraft:brown_terracotta
fill 268 291 464 268 294 464 minecraft:brown_terracotta
fill 269 291 504 269 293 504 minecraft:brown_terracotta
fill 271 291 503 272 291 503 minecraft:brown_terracotta
setblock 272 291 464 minecraft:bone_block
fill 272 291 465 273 291 465 minecraft:brown_terracotta
setblock 272 291 504 minecraft:bone_block
fill 273 291 464 273 294 464 minecraft:brown_terracotta
setblock 273 291 503 minecraft:bone_block
fill 273 291 504 273 294 504 minecraft:brown_terracotta
fill 274 291 493 274 294 493 minecraft:brown_terracotta
setblock 274 291 496 minecraft:brown_terracotta
setblock 274 291 497 minecraft:bone_block
fill 274 291 498 274 294 498 minecraft:brown_terracotta
fill 274 291 500 274 292 500 minecraft:brown_terracotta
fill 274 291 503 274 294 503 minecraft:brown_terracotta
setblock 275 291 471 minecraft:bone_block
fill 275 291 472 275 294 472 minecraft:brown_terracotta
setblock 275 291 491 minecraft:bone_block
fill 275 291 492 275 294 492 minecraft:brown_terracotta
setblock 275 291 495 minecraft:brown_terracotta
setblock 275 291 496 minecraft:bone_block
fill 275 291 497 275 294 497 minecraft:brown_terracotta
setblock 275 291 501 minecraft:bone_block
fill 275 291 502 275 294 502 minecraft:brown_terracotta
setblock 276 291 465 minecraft:bone_block
fill 276 291 466 276 292 466 minecraft:brown_terracotta
setblock 276 291 470 minecraft:bone_block
fill 276 291 471 276 294 471 minecraft:brown_terracotta
setblock 276 291 475 minecraft:bone_block
fill 276 291 476 276 294 476 minecraft:brown_terracotta
fill 276 291 478 276 292 478 minecraft:brown_terracotta
setblock 276 291 490 minecraft:bone_block
fill 276 291 491 276 294 491 minecraft:brown_terracotta
setblock 276 291 495 minecraft:bone_block
fill 276 291 496 276 294 496 minecraft:brown_terracotta
setblock 276 291 500 minecraft:bone_block
fill 276 291 501 276 294 501 minecraft:brown_terracotta
setblock 236 292 470 minecraft:brown_terracotta
setblock 236 292 474 minecraft:bone_block
fill 236 292 475 236 295 475 minecraft:brown_terracotta
setblock 236 292 479 minecraft:bone_block
fill 236 292 480 236 294 481 minecraft:brown_terracotta
fill 236 292 485 236 292 488 minecraft:brown_terracotta
setblock 236 292 489 minecraft:bone_block
fill 236 292 490 236 292 493 minecraft:brown_terracotta
setblock 236 292 494 minecraft:bone_block
fill 236 292 495 236 295 495 minecraft:brown_terracotta
setblock 236 292 499 minecraft:bone_block
fill 236 292 500 236 295 500 minecraft:brown_terracotta
setblock 236 292 503 minecraft:brown_terracotta
setblock 236 292 504 minecraft:bone_block
fill 237 292 490 237 292 492 minecraft:brown_terracotta
setblock 237 292 493 minecraft:bone_block
fill 237 292 494 237 295 494 minecraft:brown_terracotta
setblock 237 292 498 minecraft:bone_block
fill 237 292 499 237 295 499 minecraft:brown_terracotta
fill 237 292 501 237 293 501 minecraft:brown_terracotta
fill 253 292 464 253 294 464 minecraft:brown_terracotta
fill 268 292 504 268 294 504 minecraft:brown_terracotta
fill 270 292 503 271 292 503 minecraft:brown_terracotta
setblock 271 292 464 minecraft:bone_block
fill 271 292 465 272 294 465 minecraft:brown_terracotta
setblock 271 292 504 minecraft:bone_block
fill 272 292 464 272 295 464 minecraft:brown_terracotta
setblock 272 292 503 minecraft:bone_block
fill 272 292 504 272 295 504 minecraft:brown_terracotta
setblock 273 292 502 minecraft:bone_block
fill 273 292 503 273 295 503 minecraft:brown_terracotta
setblock 274 292 496 minecraft:bone_block
fill 274 292 497 274 295 497 minecraft:brown_terracotta
setblock 274 292 501 minecraft:bone_block
fill 274 292 502 274 295 502 minecraft:brown_terracotta
setblock 275 292 464 minecraft:brown_terracotta
setblock 275 292 470 minecraft:bone_block
fill 275 292 471 275 293 471 minecraft:brown_terracotta
setblock 275 292 475 minecraft:bone_block
fill 275 292 476 275 295 476 minecraft:brown_terracotta
fill 275 292 491 275 295 491 minecraft:brown_terracotta
setblock 275 292 495 minecraft:bone_block
fill 275 292 496 275 295 496 minecraft:brown_terracotta
setblock 275 292 500 minecraft:bone_block
fill 275 292 501 275 295 501 minecraft:brown_terracotta
setblock 276 292 464 minecraft:bone_block
setblock 276 292 465 minecraft:brown_terracotta
setblock 276 292 469 minecraft:bone_block
fill 276 292 470 276 294 470 minecraft:brown_terracotta
setblock 276 292 474 minecraft:bone_block
fill 276 292 475 276 295 475 minecraft:brown_terracotta
setblock 276 292 489 minecraft:bone_block
fill 276 292 490 276 295 490 minecraft:brown_terracotta
setblock 276 292 494 minecraft:bone_block
fill 276 292 495 276 295 495 minecraft:brown_terracotta
setblock 276 292 499 minecraft:bone_block
fill 276 292 500 276 295 500 minecraft:brown_terracotta
setblock 276 292 504 minecraft:bone_block
setblock 236 293 473 minecraft:bone_block
fill 236 293 474 236 296 474 minecraft:brown_terracotta
setblock 236 293 477 minecraft:brown_terracotta
setblock 236 293 478 minecraft:bone_block
fill 236 293 479 236 296 479 minecraft:brown_terracotta
setblock 236 293 482 minecraft:brown_terracotta
setblock 236 293 483 minecraft:bone_block
fill 236 293 484 236 293 487 minecraft:brown_terracotta
setblock 236 293 488 minecraft:bone_block
fill 236 293 489 236 293 492 minecraft:brown_terracotta
setblock 236 293 493 minecraft:bone_block
fill 236 293 494 236 296 494 minecraft:brown_terracotta
setblock 236 293 498 minecraft:bone_block
fill 236 293 499 236 296 499 minecraft:brown_terracotta
setblock 236 293 503 minecraft:bone_block
fill 236 293 504 236 296 504 minecraft:brown_terracotta
fill 237 293 490 237 293 491 minecraft:brown_terracotta
setblock 237 293 492 minecraft:bone_block
fill 237 293 493 237 296 493 minecraft:brown_terracotta
setblock 237 293 497 minecraft:bone_block
fill 237 293 498 237 296 498 minecraft:brown_terracotta
setblock 238 293 496 minecraft:bone_block
fill 238 293 497 238 294 497 minecraft:brown_terracotta
fill 245 293 473 246 294 474 minecraft:bone_block
fill 251 293 464 252 295 464 minecraft:brown_terracotta
setblock 254 293 464 minecraft:brown_terracotta
setblock 255 293 464 minecraft:bone_block
fill 256 293 464 256 296 464 minecraft:brown_terracotta
fill 266 293 464 267 295 464 minecraft:brown_terracotta
fill 267 293 504 267 295 504 minecraft:brown_terracotta
fill 268 293 503 270 293 503 minecraft:brown_terracotta
setblock 270 293 464 minecraft:bone_block
fill 270 293 465 270 296 465 minecraft:brown_terracotta
fill 270 293 502 271 293 502 minecraft:brown_terracotta
setblock 270 293 504 minecraft:bone_block
fill 271 293 464 271 296 464 minecraft:brown_terracotta
setblock 271 293 503 minecraft:bone_block
fill 271 293 504 271 296 504 minecraft:brown_terracotta
setblock 272 293 502 minecraft:bone_block
fill 272 293 503 272 296 503 minecraft:brown_terracotta
setblock 273 293 496 minecraft:bone_block
fill 273 293 497 273 293 500 minecraft:brown_terracotta
fill 273 293 502 273 296 502 minecraft:brown_terracotta
setblock 274 293 495 minecraft:bone_block
fill 274 293 496 274 296 496 minecraft:brown_terracotta
setblock 274 293 500 minecraft:bone_block
fill 274 293 501 274 296 501 minecraft:brown_terracotta
setblock 275 293 464 minecraft:bone_block
setblock 275 293 474 minecraft:bone_block
fill 275 293 475 275 296 475 minecraft:brown_terracotta
fill 275 293 477 275 294 477 minecraft:brown_terracotta
setblock 275 293 494 minecraft:bone_block
fill 275 293 495 275 296 495 minecraft:brown_terracotta
setblock 275 293 499 minecraft:bone_block
fill 275 293 500 275 296 500 minecraft:brown_terracotta
setblock 275 293 504 minecraft:bone_block
fill 276 293 464 276 296 464 minecraft:brown_terracotta
setblock 276 293 468 minecraft:bone_block
fill 276 293 469 276 294 469 minecraft:brown_terracotta
setblock 276 293 473 minecraft:bone_block
fill 276 293 474 276 296 474 minecraft:brown_terracotta
setblock 276 293 478 minecraft:bone_block
fill 276 293 479 276 296 479 minecraft:brown_terracotta
fill 276 293 489 276 296 489 minecraft:brown_terracotta
setblock 276 293 493 minecraft:bone_block
fill 276 293 494 276 296 494 minecraft:brown_terracotta
setblock 276 293 498 minecraft:bone_block
fill 276 293 499 276 296 499 minecraft:brown_terracotta
setblock 276 293 503 minecraft:bone_block
fill 276 293 504 276 296 504 minecraft:brown_terracotta
setblock 236 294 472 minecraft:bone_block
fill 236 294 473 236 297 473 minecraft:brown_terracotta
setblock 236 294 477 minecraft:bone_block
fill 236 294 478 237 296 478 minecraft:brown_terracotta
setblock 236 294 482 minecraft:bone_block
fill 236 294 483 236 294 486 minecraft:brown_terracotta
setblock 236 294 487 minecraft:bone_block
fill 236 294 488 236 294 491 minecraft:brown_terracotta
setblock 236 294 492 minecraft:bone_block
fill 236 294 493 236 297 493 minecraft:brown_terracotta
setblock 236 294 497 minecraft:bone_block
fill 236 294 498 236 297 498 minecraft:brown_terracotta
setblock 236 294 502 minecraft:bone_block
fill 236 294 503 236 297 503 minecraft:brown_terracotta
setblock 237 294 476 minecraft:bone_block
fill 237 294 477 237 297 477 minecraft:brown_terracotta
setblock 237 294 491 minecraft:bone_block
fill 237 294 492 237 296 492 minecraft:brown_terracotta
setblock 237 294 496 minecraft:bone_block
fill 237 294 497 237 297 497 minecraft:brown_terracotta
setblock 237 294 501 minecraft:bone_block
fill 237 294 504 237 295 504 minecraft:brown_terracotta
setblock 238 294 496 minecraft:brown_terracotta
fill 250 294 464 250 297 464 minecraft:brown_terracotta
fill 250 294 504 253 294 504 minecraft:brown_terracotta
setblock 254 294 464 minecraft:bone_block
setblock 254 294 504 minecraft:bone_block
fill 255 294 464 255 297 464 minecraft:brown_terracotta
fill 255 294 504 255 297 504 minecraft:brown_terracotta
fill 257 294 464 257 295 464 minecraft:brown_terracotta
fill 265 294 464 265 297 464 minecraft:brown_terracotta
fill 265 294 504 266 296 504 minecraft:brown_terracotta
fill 267 294 483 268 295 484 minecraft:bone_block
fill 267 294 503 269 294 503 minecraft:brown_terracotta
setblock 269 294 464 minecraft:bone_block
fill 269 294 465 269 297 465 minecraft:brown_terracotta
fill 269 294 502 270 294 502 minecraft:brown_terracotta
setblock 269 294 504 minecraft:bone_block
fill 270 294 464 270 297 464 minecraft:brown_terracotta
setblock 270 294 503 minecraft:bone_block
fill 270 294 504 270 297 504 minecraft:brown_terracotta
setblock 271 294 501 minecraft:brown_terracotta
setblock 271 294 502 minecraft:bone_block
fill 271 294 503 271 297 503 minecraft:brown_terracotta
setblock 272 294 501 minecraft:bone_block
fill 272 294 502 272 297 502 minecraft:brown_terracotta
setblock 273 294 465 minecraft:bone_block
fill 273 294 496 273 294 499 minecraft:brown_terracotta
setblock 273 294 500 minecraft:bone_block
fill 273 294 501 273 297 501 minecraft:brown_terracotta
setblock 274 294 464 minecraft:bone_block
setblock 274 294 494 minecraft:bone_block
fill 274 294 495 274 297 495 minecraft:brown_terracotta
setblock 274 294 499 minecraft:bone_block
fill 274 294 500 274 297 500 minecraft:brown_terracotta
setblock 274 294 504 minecraft:bone_block
fill 275 294 464 275 297 464 minecraft:brown_terracotta
setblock 275 294 473 minecraft:bone_block
fill 275 294 474 275 295 474 minecraft:brown_terracotta
setblock 275 294 478 minecraft:bone_block
setblock 275 294 493 minecraft:bone_block
fill 275 294 494 275 297 494 minecraft:brown_terracotta
setblock 275 294 498 minecraft:bone_block
fill 275 294 499 275 297 499 minecraft:brown_terracotta
setblock 275 294 503 minecraft:bone_block
fill 275 294 504 275 297 504 minecraft:brown_terracotta
setblock 276 294 472 minecraft:bone_block
fill 276 294 473 276 297 473 minecraft:brown_terracotta
setblock 276 294 477 minecraft:bone_block
fill 276 294 478 276 297 478 minecraft:brown_terracotta
fill 276 294 480 276 294 481 minecraft:brown_terracotta
setblock 276 294 492 minecraft:bone_block
fill 276 294 493 276 297 493 minecraft:brown_terracotta
setblock 276 294 497 minecraft:bone_block
fill 276 294 498 276 297 498 minecraft:brown_terracotta
setblock 276 294 502 minecraft:bone_block
fill 276 294 503 276 297 503 minecraft:brown_terracotta
fill 236 295 472 236 296 472 minecraft:brown_terracotta
setblock 236 295 476 minecraft:bone_block
fill 236 295 477 236 298 477 minecraft:brown_terracotta
setblock 236 295 480 minecraft:brown_terracotta
setblock 236 295 481 minecraft:bone_block
fill 236 295 482 236 295 485 minecraft:brown_terracotta
setblock 236 295 486 minecraft:bone_block
fill 236 295 487 236 295 490 minecraft:brown_terracotta
setblock 236 295 491 minecraft:bone_block
fill 236 295 492 236 298 492 minecraft:brown_terracotta
setblock 236 295 496 minecraft:bone_block
fill 236 295 497 236 298 497 minecraft:brown_terracotta
setblock 236 295 501 minecraft:bone_block
fill 236 295 502 237 297 502 minecraft:brown_terracotta
fill 237 295 476 237 297 476 minecraft:brown_terracotta
setblock 237 295 479 minecraft:brown_terracotta
setblock 237 295 480 minecraft:bone_block
setblock 237 295 491 minecraft:brown_terracotta
setblock 237 295 495 minecraft:bone_block
fill 237 295 496 237 298 496 minecraft:brown_terracotta
setblock 237 295 500 minecraft:bone_block
fill 237 295 501 237 298 501 minecraft:brown_terracotta
setblock 247 295 504 minecraft:brown_terracotta
setblock 248 295 464 minecraft:bone_block
setblock 248 295 504 minecraft:bone_block
fill 249 295 464 249 298 464 minecraft:brown_terracotta
fill 249 295 504 252 295 504 minecraft:brown_terracotta
fill 251 295 503 252 296 503 minecraft:brown_terracotta
setblock 253 295 464 minecraft:bone_block
setblock 253 295 504 minecraft:bone_block
fill 254 295 464 254 298 464 minecraft:brown_terracotta
fill 254 295 504 254 298 504 minecraft:brown_terracotta
fill 256 295 504 256 296 504 minecraft:brown_terracotta
setblock 258 295 464 minecraft:bone_block
setblock 263 295 464 minecraft:bone_block
setblock 263 295 504 minecraft:bone_block
fill 264 295 464 264 298 464 minecraft:brown_terracotta
fill 264 295 504 264 298 504 minecraft:brown_terracotta
fill 265 295 503 268 295 503 minecraft:brown_terracotta
setblock 267 295 465 minecraft:bone_block
fill 267 295 502 269 295 502 minecraft:brown_terracotta
setblock 268 295 464 minecraft:bone_block
fill 268 295 465 268 298 465 minecraft:brown_terracotta
setblock 268 295 504 minecraft:bone_block
fill 269 295 464 269 298 464 minecraft:brown_terracotta
fill 269 295 501 270 295 501 minecraft:brown_terracotta
setblock 269 295 503 minecraft:bone_block
fill 269 295 504 269 298 504 minecraft:brown_terracotta
setblock 270 295 502 minecraft:bone_block
fill 270 295 503 270 298 503 minecraft:brown_terracotta
setblock 271 295 465 minecraft:brown_terracotta
setblock 271 295 501 minecraft:bone_block
fill 271 295 502 271 298 502 minecraft:brown_terracotta
setblock 272 295 465 minecraft:bone_block
fill 272 295 501 272 298 501 minecraft:brown_terracotta
setblock 273 295 464 minecraft:bone_block
fill 273 295 465 273 297 465 minecraft:brown_terracotta
fill 273 295 495 273 295 498 minecraft:brown_terracotta
setblock 273 295 499 minecraft:bone_block
fill 273 295 500 273 298 500 minecraft:brown_terracotta
setblock 273 295 504 minecraft:bone_block
fill 274 295 464 274 298 464 minecraft:brown_terracotta
setblock 274 295 493 minecraft:bone_block
fill 274 295 494 274 297 494 minecraft:brown_terracotta
setblock 274 295 498 minecraft:bone_block
fill 274 295 499 274 298 499 minecraft:brown_terracotta
setblock 274 295 503 minecraft:bone_block
fill 274 295 504 274 298 504 minecraft:brown_terracotta
setblock 275 295 473 minecraft:brown_terracotta
setblock 275 295 477 minecraft:bone_block
fill 275 295 478 275 297 479 minecraft:brown_terracotta
setblock 275 295 492 minecraft:bone_block
fill 275 295 493 275 298 493 minecraft:brown_terracotta
setblock 275 295 497 minecraft:bone_block
fill 275 295 498 275 298 498 minecraft:brown_terracotta
setblock 275 295 502 minecraft:bone_block
fill 275 295 503 275 298 503 minecraft:brown_terracotta
setblock 276 295 471 minecraft:bone_block
fill 276 295 472 276 296 472 minecraft:brown_terracotta
setblock 276 295 476 minecraft:bone_block
fill 276 295 477 276 298 477 minecraft:brown_terracotta
setblock 276 295 480 minecraft:brown_terracotta
setblock 276 295 481 minecraft:bone_block
fill 276 295 482 276 298 482 minecraft:brown_terracotta
setblock 276 295 491 minecraft:bone_block
fill 276 295 492 276 298 492 minecraft:brown_terracotta
setblock 276 295 496 minecraft:bone_block
fill 276 295 497 276 298 497 minecraft:brown_terracotta
setblock 276 295 501 minecraft:bone_block
fill 276 295 502 276 298 502 minecraft:brown_terracotta
setblock 236 296 475 minecraft:bone_block
fill 236 296 476 236 299 476 minecraft:brown_terracotta
setblock 236 296 480 minecraft:bone_block
fill 236 296 481 236 296 484 minecraft:brown_terracotta
setblock 236 296 485 minecraft:bone_block
fill 236 296 486 236 296 489 minecraft:brown_terracotta
setblock 236 296 490 minecraft:bone_block
fill 236 296 491 236 299 491 minecraft:brown_terracotta
setblock 236 296 495 minecraft:bone_block
fill 236 296 496 236 299 496 minecraft:brown_terracotta
setblock 236 296 500 minecraft:bone_block
fill 236 296 501 236 299 501 minecraft:brown_terracotta
setblock 237 296 479 minecraft:bone_block
fill 237 296 480 237 297 482 minecraft:brown_terracotta
setblock 237 296 494 minecraft:bone_block
fill 237 296 495 237 298 495 minecraft:brown_terracotta
setblock 237 296 499 minecraft:bone_block
fill 237 296 500 237 299 500 minecraft:brown_terracotta
setblock 237 296 504 minecraft:bone_block
setblock 238 296 466 minecraft:light[level=12]
setblock 238 296 474 minecraft:light[level=12]
setblock 238 296 482 minecraft:light[level=12]
setblock 238 296 490 minecraft:light[level=12]
setblock 238 296 498 minecraft:light[level=12]
fill 244 296 489 244 297 489 minecraft:bone_block
setblock 246 296 466 minecraft:light[level=12]
setblock 246 296 474 minecraft:light[level=12]
setblock 246 296 482 minecraft:light[level=12]
setblock 246 296 490 minecraft:light[level=12]
setblock 246 296 498 minecraft:light[level=12]
setblock 246 296 504 minecraft:brown_terracotta
setblock 247 296 464 minecraft:bone_block
setblock 247 296 504 minecraft:bone_block
fill 248 296 464 248 299 464 minecraft:brown_terracotta
setblock 248 296 503 minecraft:bone_block
fill 248 296 504 251 296 504 minecraft:brown_terracotta
fill 249 296 503 250 298 503 minecraft:brown_terracotta
setblock 250 296 465 minecraft:brown_terracotta
setblock 251 296 464 minecraft:brown_terracotta
setblock 251 296 465 minecraft:bone_block
setblock 252 296 464 minecraft:bone_block
fill 252 296 465 254 297 465 minecraft:brown_terracotta
setblock 252 296 504 minecraft:bone_block
fill 253 296 464 253 299 464 minecraft:brown_terracotta
setblock 253 296 503 minecraft:bone_block
fill 253 296 504 253 299 504 minecraft:brown_terracotta
setblock 254 296 466 minecraft:light[level=12]
setblock 254 296 474 minecraft:light[level=12]
setblock 254 296 482 minecraft:light[level=12]
setblock 254 296 490 minecraft:light[level=12]
setblock 254 296 498 minecraft:light[level=12]
fill 254 296 503 254 299 503 minecraft:brown_terracotta
setblock 257 296 464 minecraft:bone_block
setblock 257 296 504 minecraft:bone_block
fill 258 296 464 261 296 464 minecraft:brown_terracotta
fill 258 296 504 261 296 504 minecraft:brown_terracotta
setblock 262 296 464 minecraft:bone_block
setblock 262 296 466 minecraft:light[level=12]
setblock 262 296 474 minecraft:light[level=12]
setblock 262 296 482 minecraft:light[level=12]
setblock 262 296 490 minecraft:light[level=12]
setblock 262 296 498 minecraft:light[level=12]
setblock 262 296 504 minecraft:bone_block
fill 263 296 464 263 299 464 minecraft:brown_terracotta
fill 263 296 504 263 299 504 minecraft:brown_terracotta
fill 264 296 503 267 296 503 minecraft:brown_terracotta
setblock 266 296 464 minecraft:brown_terracotta
setblock 266 296 465 minecraft:bone_block
fill 266 296 502 268 296 502 minecraft:brown_terracotta
setblock 267 296 464 minecraft:bone_block
fill 267 296 465 267 299 465 minecraft:brown_terracotta
setblock 267 296 504 minecraft:bone_block
fill 268 296 464 268 299 464 minecraft:brown_terracotta
fill 268 296 501 269 296 501 minecraft:brown_terracotta
setblock 268 296 503 minecraft:bone_block
fill 268 296 504 268 299 504 minecraft:brown_terracotta
setblock 269 296 502 minecraft:bone_block
fill 269 296 503 269 299 503 minecraft:brown_terracotta
setblock 270 296 466 minecraft:light[level=12]
setblock 270 296 474 minecraft:light[level=12]
setblock 270 296 482 minecraft:light[level=12]
setblock 270 296 490 minecraft:light[level=12]
setblock 270 296 498 minecraft:light[level=12]
setblock 270 296 501 minecraft:bone_block
fill 270 296 502 270 299 502 minecraft:brown_terracotta
setblock 271 296 465 minecraft:bone_block
setblock 271 296 500 minecraft:bone_block
fill 271 296 501 271 299 501 minecraft:brown_terracotta
setblock 272 296 464 minecraft:bone_block
fill 272 296 465 272 299 465 minecraft:brown_terracotta
setblock 272 296 499 minecraft:bone_block
fill 272 296 500 272 298 500 minecraft:brown_terracotta
setblock 272 296 504 minecraft:bone_block
fill 273 296 464 273 299 464 minecraft:brown_terracotta
fill 273 296 496 273 296 497 minecraft:brown_terracotta
setblock 273 296 498 minecraft:bone_block
fill 273 296 499 273 299 499 minecraft:brown_terracotta
setblock 273 296 503 minecraft:bone_block
fill 273 296 504 273 299 504 minecraft:brown_terracotta
setblock 274 296 497 minecraft:bone_block
fill 274 296 498 274 299 498 minecraft:brown_terracotta
setblock 274 296 502 minecraft:bone_block
fill 274 296 503 274 299 503 minecraft:brown_terracotta
setblock 275 296 476 minecraft:bone_block
fill 275 296 477 275 297 477 minecraft:brown_terracotta
setblock 275 296 480 minecraft:brown_terracotta
fill 275 296 492 275 297 492 minecraft:brown_terracotta
setblock 275 296 496 minecraft:bone_block
fill 275 296 497 275 299 497 minecraft:brown_terracotta
setblock 275 296 501 minecraft:bone_block
fill 275 296 502 275 299 502 minecraft:brown_terracotta
setblock 276 296 475 minecraft:bone_block
fill 276 296 476 276 299 476 minecraft:brown_terracotta
setblock 276 296 480 minecraft:bone_block
fill 276 296 481 276 299 481 minecraft:brown_terracotta
fill 276 296 483 276 297 483 minecraft:brown_terracotta
setblock 276 296 490 minecraft:bone_block
fill 276 296 491 276 299 491 minecraft:brown_terracotta
setblock 276 296 495 minecraft:bone_block
fill 276 296 496 276 299 496 minecraft:brown_terracotta
setblock 276 296 500 minecraft:bone_block
fill 276 296 501 276 299 501 minecraft:brown_terracotta
setblock 236 297 474 minecraft:bone_block
fill 236 297 475 236 299 475 minecraft:brown_terracotta
setblock 236 297 478 minecraft:brown_terracotta
setblock 236 297 479 minecraft:bone_block
fill 236 297 480 236 297 483 minecraft:brown_terracotta
setblock 236 297 484 minecraft:bone_block
fill 236 297 485 236 297 488 minecraft:brown_terracotta
setblock 236 297 489 minecraft:bone_block
fill 236 297 490 236 299 490 minecraft:brown_terracotta
setblock 236 297 494 minecraft:bone_block
fill 236 297 495 236 300 495 minecraft:brown_terracotta
setblock 236 297 499 minecraft:bone_block
fill 236 297 500 236 300 500 minecraft:brown_terracotta
setblock 236 297 504 minecraft:bone_block
setblock 237 297 478 minecraft:bone_block
fill 237 297 479 237 300 479 minecraft:brown_terracotta
setblock 237 297 483 minecraft:bone_block
setblock 237 297 493 minecraft:bone_block
setblock 237 297 494 minecraft:brown_terracotta
setblock 237 297 498 minecraft:bone_block
fill 237 297 499 237 299 499 minecraft:brown_terracotta
fill 237 297 504 238 299 504 minecraft:brown_terracotta
fill 244 297 504 245 297 504 minecraft:brown_terracotta
setblock 246 297 464 minecraft:bone_block
setblock 246 297 503 minecraft:brown_terracotta
setblock 246 297 504 minecraft:bone_block
fill 247 297 464 247 300 464 minecraft:brown_terracotta
setblock 247 297 503 minecraft:bone_block
fill 247 297 504 250 297 504 minecraft:brown_terracotta
fill 248 297 503 248 300 503 minecraft:brown_terracotta
setblock 249 297 465 minecraft:brown_terracotta
setblock 250 297 465 minecraft:bone_block
setblock 251 297 464 minecraft:bone_block
fill 251 297 465 251 300 465 minecraft:brown_terracotta
setblock 251 297 503 minecraft:brown_terracotta
setblock 251 297 504 minecraft:bone_block
fill 252 297 464 252 300 464 minecraft:brown_terracotta
setblock 252 297 503 minecraft:bone_block
fill 252 297 504 252 300 504 minecraft:brown_terracotta
fill 253 297 503 253 300 503 minecraft:brown_terracotta
fill 255 297 503 255 298 503 minecraft:brown_terracotta
setblock 256 297 464 minecraft:bone_block
setblock 256 297 504 minecraft:bone_block
fill 257 297 464 260 297 464 minecraft:brown_terracotta
fill 257 297 504 260 297 504 minecraft:brown_terracotta
setblock 261 297 464 minecraft:bone_block
setblock 261 297 504 minecraft:bone_block
fill 262 297 464 262 300 464 minecraft:brown_terracotta
setblock 262 297 503 minecraft:bone_block
fill 262 297 504 262 300 504 minecraft:brown_terracotta
fill 263 297 503 266 297 503 minecraft:brown_terracotta
setblock 265 297 465 minecraft:bone_block
fill 265 297 502 267 297 502 minecraft:brown_terracotta
setblock 265 297 504 minecraft:brown_terracotta
setblock 266 297 464 minecraft:bone_block
fill 266 297 465 266 300 465 minecraft:brown_terracotta
setblock 266 297 504 minecraft:bone_block
fill 267 297 464 267 300 464 minecraft:brown_terracotta
fill 267 297 501 268 297 501 minecraft:brown_terracotta
setblock 267 297 503 minecraft:bone_block
fill 267 297 504 267 300 504 minecraft:brown_terracotta
setblock 268 297 502 minecraft:bone_block
fill 268 297 503 268 300 503 minecraft:brown_terracotta
setblock 269 297 500 minecraft:brown_terracotta
setblock 269 297 501 minecraft:bone_block
fill 269 297 502 269 300 502 minecraft:brown_terracotta
setblock 270 297 465 minecraft:bone_block
setblock 270 297 500 minecraft:bone_block
fill 270 297 501 270 300 501 minecraft:brown_terracotta
setblock 271 297 464 minecraft:bone_block
fill 271 297 465 271 300 465 minecraft:brown_terracotta
fill 271 297 500 271 299 500 minecraft:brown_terracotta
setblock 271 297 504 minecraft:bone_block
fill 272 297 464 272 300 464 minecraft:brown_terracotta
setblock 272 297 499 minecraft:brown_terracotta
setblock 272 297 503 minecraft:bone_block
fill 272 297 504 272 300 504 minecraft:brown_terracotta
setblock 273 297 496 minecraft:brown_terracotta
setblock 273 297 497 minecraft:bone_block
fill 273 297 498 273 299 498 minecraft:brown_terracotta
setblock 273 297 502 minecraft:bone_block
fill 273 297 503 273 300 503 minecraft:brown_terracotta
setblock 274 297 496 minecraft:bone_block
fill 274 297 497 274 299 497 minecraft:brown_terracotta
setblock 274 297 501 minecraft:bone_block
fill 274 297 502 274 300 502 minecraft:brown_terracotta
setblock 275 297 476 minecraft:brown_terracotta
setblock 275 297 480 minecraft:bone_block
setblock 275 297 495 minecraft:bone_block
fill 275 297 496 275 300 496 minecraft:brown_terracotta
setblock 275 297 500 minecraft:bone_block
fill 275 297 501 275 300 501 minecraft:brown_terracotta
setblock 276 297 464 minecraft:bone_block
setblock 276 297 474 minecraft:bone_block
fill 276 297 475 276 298 475 minecraft:brown_terracotta
setblock 276 297 479 minecraft:bone_block
fill 276 297 480 276 300 480 minecraft:brown_terracotta
setblock 276 297 484 minecraft:bone_block
fill 276 297 485 276 300 485 minecraft:brown_terracotta
setblock 276 297 489 minecraft:bone_block
fill 276 297 490 276 298 490 minecraft:brown_terracotta
setblock 276 297 494 minecraft:bone_block
fill 276 297 495 276 300 495 minecraft:brown_terracotta
setblock 276 297 499 minecraft:bone_block
fill 276 297 500 276 300 500 minecraft:brown_terracotta
setblock 276 297 504 minecraft:bone_block
setblock 236 298 474 minecraft:brown_terracotta
setblock 236 298 478 minecraft:bone_block
fill 236 298 479 236 298 482 minecraft:brown_terracotta
setblock 236 298 483 minecraft:bone_block
fill 236 298 484 236 298 487 minecraft:brown_terracotta
setblock 236 298 488 minecraft:bone_block
fill 236 298 489 236 300 489 minecraft:brown_terracotta
setblock 236 298 493 minecraft:bone_block
fill 236 298 494 236 300 494 minecraft:brown_terracotta
setblock 236 298 498 minecraft:bone_block
fill 236 298 499 236 300 499 minecraft:brown_terracotta
setblock 236 298 502 minecraft:brown_terracotta
setblock 236 298 503 minecraft:bone_block
fill 236 298 504 236 300 504 minecraft:brown_terracotta
setblock 237 298 477 minecraft:bone_block
fill 237 298 478 237 300 478 minecraft:brown_terracotta
fill 237 298 480 237 298 481 minecraft:brown_terracotta
setblock 237 298 482 minecraft:bone_block
fill 237 298 483 237 300 484 minecraft:brown_terracotta
setblock 237 298 497 minecraft:bone_block
fill 237 298 498 237 299 498 minecraft:brown_terracotta
setblock 237 298 502 minecraft:bone_block
fill 243 298 504 244 298 504 minecraft:brown_terracotta
setblock 245 298 464 minecraft:bone_block
setblock 245 298 503 minecraft:brown_terracotta
setblock 245 298 504 minecraft:bone_block
fill 246 298 464 246 300 464 minecraft:brown_terracotta
setblock 246 298 503 minecraft:bone_block
fill 246 298 504 249 298 504 minecraft:brown_terracotta
fill 247 298 503 247 300 503 minecraft:brown_terracotta
setblock 248 298 465 minecraft:brown_terracotta
setblock 249 298 465 minecraft:bone_block
fill 249 298 502 250 299 502 minecraft:brown_terracotta
setblock 250 298 464 minecraft:bone_block
fill 250 298 465 250 300 465 minecraft:brown_terracotta
setblock 250 298 504 minecraft:bone_block
fill 251 298 464 251 300 464 minecraft:brown_terracotta
setblock 251 298 503 minecraft:bone_block
fill 251 298 504 251 300 504 minecraft:brown_terracotta
fill 252 298 465 253 298 465 minecraft:brown_terracotta
fill 252 298 503 252 300 503 minecraft:brown_terracotta
setblock 254 298 465 minecraft:bone_block
setblock 255 298 464 minecraft:bone_block
setblock 255 298 504 minecraft:bone_block
fill 256 298 464 259 298 464 minecraft:brown_terracotta
fill 256 298 504 259 298 504 minecraft:brown_terracotta
setblock 260 298 464 minecraft:bone_block
setblock 260 298 504 minecraft:bone_block
fill 261 298 464 261 300 464 minecraft:brown_terracotta
setblock 261 298 503 minecraft:bone_block
fill 261 298 504 261 300 504 minecraft:brown_terracotta
fill 262 298 503 265 298 503 minecraft:brown_terracotta
setblock 264 298 465 minecraft:bone_block
fill 264 298 502 266 298 502 minecraft:brown_terracotta
setblock 265 298 464 minecraft:bone_block
fill 265 298 465 265 300 465 minecraft:brown_terracotta
setblock 265 298 504 minecraft:bone_block
fill 266 298 464 266 300 464 minecraft:brown_terracotta
fill 266 298 501 267 298 501 minecraft:brown_terracotta
setblock 266 298 503 minecraft:bone_block
fill 266 298 504 266 300 504 minecraft:brown_terracotta
setblock 267 298 502 minecraft:bone_block
fill 267 298 503 267 300 503 minecraft:brown_terracotta
setblock 268 298 501 minecraft:bone_block
fill 268 298 502 268 300 502 minecraft:brown_terracotta
setblock 269 298 465 minecraft:bone_block
setblock 269 298 500 minecraft:bone_block
fill 269 298 501 269 300 501 minecraft:brown_terracotta
setblock 270 298 464 minecraft:bone_block
fill 270 298 465 270 300 465 minecraft:brown_terracotta
fill 270 298 500 270 299 500 minecraft:brown_terracotta
setblock 270 298 504 minecraft:bone_block
fill 271 298 464 271 300 464 minecraft:brown_terracotta
setblock 271 298 503 minecraft:bone_block
fill 271 298 504 271 300 504 minecraft:brown_terracotta
setblock 272 298 502 minecraft:bone_block
fill 272 298 503 272 300 503 minecraft:brown_terracotta
setblock 273 298 497 minecraft:brown_terracotta
setblock 273 298 501 minecraft:bone_block
fill 273 298 502 273 300 502 minecraft:brown_terracotta
setblock 274 298 495 minecraft:bone_block
fill 274 298 496 274 299 496 minecraft:brown_terracotta
setblock 274 298 500 minecraft:bone_block
fill 274 298 501 274 300 501 minecraft:brown_terracotta
setblock 275 298 464 minecraft:bone_block
setblock 275 298 478 minecraft:brown_terracotta
setblock 275 298 479 minecraft:bone_block
fill 275 298 480 275 298 481 minecraft:brown_terracotta
setblock 275 298 494 minecraft:bone_block
fill 275 298 495 275 299 495 minecraft:brown_terracotta
setblock 275 298 499 minecraft:bone_block
fill 275 298 500 275 300 500 minecraft:brown_terracotta
setblock 275 298 504 minecraft:bone_block
setblock 276 298 478 minecraft:bone_block
fill 276 298 479 276 300 479 minecraft:brown_terracotta
setblock 276 298 483 minecraft:bone_block
fill 276 298 484 276 300 484 minecraft:brown_terracotta
fill 276 298 486 276 299 486 minecraft:brown_terracotta
setblock 276 298 493 minecraft:bone_block
fill 276 298 494 276 300 494 minecraft:brown_terracotta
setblock 276 298 498 minecraft:bone_block
fill 276 298 499 276 300 499 minecraft:brown_terracotta
setblock 276 298 503 minecraft:bone_block
fill 276 298 504 276 300 504 minecraft:brown_terracotta
setblock 236 299 477 minecraft:bone_block
fill 236 299 478 236 299 481 minecraft:brown_terracotta
setblock 236 299 482 minecraft:bone_block
fill 236 299 483 236 299 486 minecraft:brown_terracotta
setblock 236 299 487 minecraft:bone_block
fill 236 299 488 236 300 488 minecraft:brown_terracotta
setblock 236 299 492 minecraft:bone_block
setblock 236 299 493 minecraft:brown_terracotta
setblock 236 299 497 minecraft:bone_block
fill 236 299 498 236 300 498 minecraft:brown_terracotta
setblock 236 299 502 minecraft:bone_block
fill 236 299 503 236 300 503 minecraft:brown_terracotta
setblock 237 299 477 minecraft:brown_terracotta
setblock 237 299 480 minecraft:brown_terracotta
setblock 237 299 481 minecraft:bone_block
fill 237 299 482 237 300 482 minecraft:brown_terracotta
setblock 237 299 497 minecraft:brown_terracotta
setblock 237 299 501 minecraft:bone_block
fill 242 299 504 243 299 504 minecraft:brown_terracotta
setblock 244 299 464 minecraft:bone_block
setblock 244 299 504 minecraft:bone_block
fill 245 299 464 245 300 464 minecraft:brown_terracotta
setblock 245 299 503 minecraft:bone_block
fill 245 299 504 248 299 504 minecraft:brown_terracotta
fill 246 299 503 246 300 503 minecraft:brown_terracotta
setblock 247 299 465 minecraft:brown_terracotta
setblock 248 299 465 minecraft:bone_block
setblock 248 299 502 minecraft:brown_terracotta
setblock 249 299 464 minecraft:bone_block
fill 249 299 465 249 300 465 minecraft:brown_terracotta
setblock 249 299 503 minecraft:brown_terracotta
setblock 249 299 504 minecraft:bone_block
fill 250 299 464 250 300 464 minecraft:brown_terracotta
setblock 250 299 503 minecraft:bone_block
fill 250 299 504 250 300 504 minecraft:brown_terracotta
fill 251 299 503 251 300 503 minecraft:brown_terracotta
setblock 252 299 465 minecraft:brown_terracotta
setblock 253 299 465 minecraft:bone_block
setblock 254 299 464 minecraft:bone_block
setblock 254 299 465 minecraft:brown_terracotta
setblock 254 299 504 minecraft:bone_block
fill 255 299 464 258 299 464 minecraft:brown_terracotta
setblock 255 299 503 minecraft:bone_block
fill 255 299 504 258 299 504 minecraft:brown_terracotta
setblock 259 299 464 minecraft:bone_block
setblock 259 299 504 minecraft:bone_block
fill 260 299 464 260 300 464 minecraft:brown_terracotta
setblock 260 299 503 minecraft:bone_block
fill 260 299 504 260 300 504 minecraft:brown_terracotta
fill 261 299 503 264 299 503 minecraft:brown_terracotta
setblock 263 299 465 minecraft:bone_block
fill 263 299 502 265 299 502 minecraft:brown_terracotta
setblock 264 299 464 minecraft:bone_block
fill 264 299 465 264 300 465 minecraft:brown_terracotta
setblock 264 299 504 minecraft:bone_block
fill 265 299 464 265 300 464 minecraft:brown_terracotta
fill 265 299 501 266 299 501 minecraft:brown_terracotta
setblock 265 299 503 minecraft:bone_block
fill 265 299 504 265 300 504 minecraft:brown_terracotta
setblock 266 299 502 minecraft:bone_block
fill 266 299 503 266 300 503 minecraft:brown_terracotta
setblock 267 299 501 minecraft:bone_block
fill 267 299 502 267 300 502 minecraft:brown_terracotta
setblock 268 299 465 minecraft:bone_block
fill 268 299 501 268 300 501 minecraft:brown_terracotta
setblock 269 299 464 minecraft:bone_block
fill 269 299 465 269 300 465 minecraft:brown_terracotta
setblock 269 299 500 minecraft:brown_terracotta
setblock 269 299 504 minecraft:bone_block
fill 270 299 464 270 300 464 minecraft:brown_terracotta
setblock 270 299 503 minecraft:bone_block
fill 270 299 504 270 300 504 minecraft:brown_terracotta
setblock 271 299 502 minecraft:bone_block
fill 271 299 503 271 300 503 minecraft:brown_terracotta
setblock 272 299 501 minecraft:bone_block
fill 272 299 502 272 300 502 minecraft:brown_terracotta
setblock 273 299 500 minecraft:bone_block
fill 273 299 501 273 300 501 minecraft:brown_terracotta
setblock 274 299 464 minecraft:bone_block
setblock 274 299 499 minecraft:bone_block
fill 274 299 500 274 300 500 minecraft:brown_terracotta
setblock 274 299 504 minecraft:bone_block
setblock 275 299 464 minecraft:brown_terracotta
setblock 275 299 494 minecraft:brown_terracotta
setblock 275 299 498 minecraft:bone_block
fill 275 299 499 275 300 499 minecraft:brown_terracotta
setblock 275 299 503 minecraft:bone_block
fill 275 299 504 275 300 504 minecraft:brown_terracotta
setblock 276 299 477 minecraft:bone_block
fill 276 299 478 276 300 478 minecraft:brown_terracotta
setblock 276 299 482 minecraft:bone_block
fill 276 299 483 276 300 483 minecraft:brown_terracotta
setblock 276 299 492 minecraft:bone_block
fill 276 299 493 276 300 493 minecraft:brown_terracotta
setblock 276 299 497 minecraft:bone_block
fill 276 299 498 276 300 498 minecraft:brown_terracotta
setblock 276 299 502 minecraft:bone_block
fill 276 299 503 276 300 503 minecraft:brown_terracotta
setblock 236 300 476 minecraft:bone_block
fill 236 300 477 236 300 480 minecraft:brown_terracotta
setblock 236 300 481 minecraft:bone_block
fill 236 300 482 236 300 485 minecraft:brown_terracotta
setblock 236 300 486 minecraft:bone_block
setblock 236 300 487 minecraft:brown_terracotta
setblock 236 300 496 minecraft:bone_block
setblock 236 300 497 minecraft:brown_terracotta
setblock 236 300 501 minecraft:bone_block
setblock 236 300 502 minecraft:brown_terracotta
setblock 237 300 480 minecraft:bone_block
setblock 237 300 481 minecraft:brown_terracotta
setblock 237 300 504 minecraft:brown_terracotta
fill 241 300 504 242 300 504 minecraft:brown_terracotta
setblock 243 300 504 minecraft:bone_block
setblock 244 300 464 minecraft:brown_terracotta
setblock 244 300 503 minecraft:bone_block
fill 244 300 504 247 300 504 minecraft:brown_terracotta
setblock 245 300 503 minecraft:brown_terracotta
setblock 246 300 465 minecraft:brown_terracotta
setblock 247 300 465 minecraft:bone_block
setblock 248 300 464 minecraft:bone_block
setblock 248 300 465 minecraft:brown_terracotta
setblock 248 300 504 minecraft:bone_block
setblock 249 300 464 minecraft:brown_terracotta
setblock 249 300 503 minecraft:bone_block
setblock 249 300 504 minecraft:brown_terracotta
setblock 250 300 503 minecraft:brown_terracotta
setblock 252 300 465 minecraft:bone_block
setblock 253 300 464 minecraft:bone_block
setblock 253 300 465 minecraft:brown_terracotta
setblock 253 300 504 minecraft:bone_block
fill 254 300 464 257 300 464 minecraft:brown_terracotta
setblock 254 300 503 minecraft:bone_block
fill 254 300 504 257 300 504 minecraft:brown_terracotta
setblock 258 300 464 minecraft:bone_block
setblock 258 300 504 minecraft:bone_block
setblock 259 300 464 minecraft:brown_terracotta
setblock 259 300 504 minecraft:brown_terracotta
fill 260 300 503 263 300 503 minecraft:brown_terracotta
setblock 263 300 464 minecraft:bone_block
setblock 263 300 465 minecraft:brown_terracotta
fill 263 300 502 264 300 502 minecraft:brown_terracotta
setblock 263 300 504 minecraft:bone_block
setblock 264 300 464 minecraft:brown_terracotta
setblock 264 300 503 minecraft:bone_block
setblock 264 300 504 minecraft:brown_terracotta
setblock 265 300 501 minecraft:brown_terracotta
setblock 265 300 502 minecraft:bone_block
setblock 265 300 503 minecraft:brown_terracotta
setblock 266 300 501 minecraft:bone_block
setblock 266 300 502 minecraft:brown_terracotta
setblock 267 300 465 minecraft:bone_block
setblock 267 300 501 minecraft:brown_terracotta
setblock 268 300 464 minecraft:bone_block
setblock 268 300 465 minecraft:brown_terracotta
setblock 268 300 504 minecraft:bone_block
setblock 269 300 464 minecraft:brown_terracotta
setblock 269 300 503 minecraft:bone_block
setblock 269 300 504 minecraft:brown_terracotta
setblock 270 300 502 minecraft:bone_block
setblock 270 300 503 minecraft:brown_terracotta
setblock 271 300 501 minecraft:bone_block
setblock 271 300 502 minecraft:brown_terracotta
setblock 272 300 501 minecraft:brown_terracotta
setblock 273 300 464 minecraft:bone_block
setblock 273 300 500 minecraft:brown_terracotta
setblock 273 300 504 minecraft:bone_block
setblock 274 300 464 minecraft:brown_terracotta
setblock 274 300 498 minecraft:bone_block
setblock 274 300 499 minecraft:brown_terracotta
setblock 274 300 503 minecraft:bone_block
setblock 274 300 504 minecraft:brown_terracotta
setblock 275 300 497 minecraft:bone_block
setblock 275 300 498 minecraft:brown_terracotta
setblock 275 300 502 minecraft:bone_block
setblock 275 300 503 minecraft:brown_terracotta
setblock 276 300 481 minecraft:bone_block
setblock 276 300 482 minecraft:brown_terracotta
setblock 276 300 486 minecraft:bone_block
setblock 276 300 496 minecraft:bone_block
setblock 276 300 497 minecraft:brown_terracotta
setblock 276 300 501 minecraft:bone_block
setblock 276 300 502 minecraft:brown_terracotta
