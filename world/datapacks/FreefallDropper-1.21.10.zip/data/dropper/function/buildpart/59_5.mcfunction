setblock 544 273 255 minecraft:light[level=11]
setblock 544 273 263 minecraft:light[level=11]
fill 545 273 228 545 275 228 minecraft:purple_terracotta
fill 545 273 270 545 275 270 minecraft:purple_terracotta
fill 549 273 228 549 275 228 minecraft:purple_terracotta
fill 549 273 270 549 275 270 minecraft:purple_terracotta
setblock 552 273 239 minecraft:light[level=11]
setblock 552 273 247 minecraft:light[level=11]
setblock 552 273 255 minecraft:light[level=11]
setblock 552 273 263 minecraft:light[level=11]
fill 553 273 228 553 275 228 minecraft:purple_terracotta
fill 553 273 234 553 275 234 minecraft:dark_oak_planks
fill 553 273 235 553 273 263 minecraft:polished_deepslate
fill 553 273 264 553 275 264 minecraft:dark_oak_planks
fill 553 273 270 553 275 270 minecraft:purple_terracotta
fill 554 273 234 554 274 264 minecraft:deepslate_tiles
fill 556 273 232 556 273 266 minecraft:polished_deepslate
fill 557 273 228 557 275 228 minecraft:purple_terracotta
fill 557 273 270 557 275 270 minecraft:purple_terracotta
setblock 559 273 228 minecraft:purple_terracotta
fill 559 273 232 559 275 232 minecraft:purple_terracotta
fill 559 273 236 559 275 236 minecraft:purple_terracotta
fill 559 273 240 559 275 240 minecraft:purple_terracotta
fill 559 273 244 559 275 244 minecraft:purple_terracotta
fill 559 273 248 559 275 248 minecraft:purple_terracotta
fill 559 273 252 559 275 252 minecraft:purple_terracotta
fill 559 273 256 559 275 256 minecraft:purple_terracotta
fill 559 273 260 559 275 260 minecraft:purple_terracotta
fill 559 273 264 559 275 264 minecraft:purple_terracotta
fill 559 273 268 559 275 268 minecraft:purple_terracotta
setblock 517 274 230 minecraft:magenta_terracotta
setblock 517 274 234 minecraft:magenta_terracotta
setblock 517 274 238 minecraft:magenta_terracotta
fill 517 274 240 517 275 240 minecraft:purple_terracotta
setblock 517 274 242 minecraft:magenta_terracotta
setblock 517 274 246 minecraft:magenta_terracotta
setblock 517 274 250 minecraft:magenta_terracotta
setblock 517 274 254 minecraft:magenta_terracotta
setblock 517 274 258 minecraft:magenta_terracotta
setblock 517 274 262 minecraft:magenta_terracotta
setblock 517 274 266 minecraft:magenta_terracotta
setblock 517 274 270 minecraft:magenta_terracotta
setblock 519 274 228 minecraft:magenta_terracotta
setblock 519 274 270 minecraft:magenta_terracotta
setblock 523 274 228 minecraft:magenta_terracotta
fill 523 274 230 524 274 230 minecraft:spruce_planks
fill 523 274 235 523 275 263 minecraft:deepslate_tiles
setblock 523 274 270 minecraft:magenta_terracotta
fill 524 274 234 552 275 234 minecraft:deepslate_tiles
fill 524 274 235 524 276 235 minecraft:dark_oak_planks
fill 524 274 236 524 274 262 minecraft:polished_deepslate
fill 524 274 263 524 276 263 minecraft:dark_oak_planks
fill 524 274 264 552 275 264 minecraft:deepslate_tiles
fill 525 274 229 526 274 230 minecraft:dark_oak_planks
fill 525 274 235 551 274 235 minecraft:polished_deepslate
fill 525 274 236 525 276 236 minecraft:dark_oak_planks
fill 525 274 237 525 274 261 minecraft:deepslate_tiles
fill 525 274 262 525 276 262 minecraft:dark_oak_planks
fill 525 274 263 551 274 263 minecraft:polished_deepslate
fill 526 274 236 550 274 236 minecraft:deepslate_tiles
fill 526 274 262 550 274 262 minecraft:deepslate_tiles
setblock 527 274 228 minecraft:magenta_terracotta
setblock 527 274 270 minecraft:magenta_terracotta
setblock 531 274 228 minecraft:magenta_terracotta
setblock 531 274 270 minecraft:magenta_terracotta
setblock 535 274 228 minecraft:magenta_terracotta
setblock 535 274 270 minecraft:magenta_terracotta
setblock 539 274 228 minecraft:magenta_terracotta
setblock 539 274 270 minecraft:magenta_terracotta
setblock 543 274 228 minecraft:magenta_terracotta
setblock 543 274 270 minecraft:magenta_terracotta
setblock 547 274 228 minecraft:magenta_terracotta
setblock 547 274 270 minecraft:magenta_terracotta
setblock 551 274 228 minecraft:magenta_terracotta
fill 551 274 236 551 276 236 minecraft:dark_oak_planks
fill 551 274 237 551 274 261 minecraft:deepslate_tiles
fill 551 274 262 551 276 262 minecraft:dark_oak_planks
setblock 551 274 270 minecraft:magenta_terracotta
fill 552 274 235 552 276 235 minecraft:dark_oak_planks
fill 552 274 236 552 274 262 minecraft:polished_deepslate
fill 552 274 263 552 276 263 minecraft:dark_oak_planks
fill 553 274 235 553 275 263 minecraft:deepslate_tiles
setblock 555 274 228 minecraft:magenta_terracotta
setblock 555 274 270 minecraft:magenta_terracotta
setblock 559 274 228 minecraft:magenta_terracotta
setblock 559 274 230 minecraft:magenta_terracotta
setblock 559 274 234 minecraft:magenta_terracotta
setblock 559 274 238 minecraft:magenta_terracotta
setblock 559 274 242 minecraft:magenta_terracotta
setblock 559 274 246 minecraft:magenta_terracotta
setblock 559 274 250 minecraft:magenta_terracotta
setblock 559 274 254 minecraft:magenta_terracotta
setblock 559 274 258 minecraft:magenta_terracotta
setblock 559 274 262 minecraft:magenta_terracotta
setblock 559 274 266 minecraft:magenta_terracotta
setblock 559 274 270 minecraft:magenta_terracotta
fill 517 275 230 517 277 230 minecraft:purple_terracotta
fill 517 275 234 517 277 234 minecraft:purple_terracotta
fill 517 275 238 517 277 238 minecraft:purple_terracotta
fill 517 275 242 517 277 242 minecraft:purple_terracotta
fill 517 275 246 517 277 246 minecraft:purple_terracotta
fill 517 275 250 517 277 250 minecraft:purple_terracotta
fill 517 275 254 517 277 254 minecraft:purple_terracotta
fill 517 275 258 517 277 258 minecraft:purple_terracotta
fill 517 275 262 517 277 262 minecraft:purple_terracotta
fill 517 275 266 517 277 266 minecraft:purple_terracotta
setblock 517 275 270 minecraft:purple_terracotta
fill 519 275 228 519 277 228 minecraft:purple_terracotta
fill 519 275 270 519 277 270 minecraft:purple_terracotta
fill 521 275 230 522 275 230 minecraft:spruce_planks
fill 523 275 228 523 277 228 minecraft:purple_terracotta
fill 523 275 229 524 275 230 minecraft:dark_oak_planks
fill 523 275 270 523 277 270 minecraft:purple_terracotta
fill 524 275 236 524 276 262 minecraft:deepslate_tiles
fill 525 275 235 551 276 235 minecraft:deepslate_tiles
fill 525 275 237 525 275 261 minecraft:polished_deepslate
fill 525 275 263 551 276 263 minecraft:deepslate_tiles
fill 526 275 236 550 275 236 minecraft:polished_deepslate
fill 526 275 237 526 277 237 minecraft:dark_oak_planks
fill 526 275 238 526 275 260 minecraft:deepslate_tiles
fill 526 275 261 526 277 261 minecraft:dark_oak_planks
fill 526 275 262 550 275 262 minecraft:polished_deepslate
fill 527 275 228 527 277 228 minecraft:purple_terracotta
fill 527 275 237 549 275 237 minecraft:deepslate_tiles
fill 527 275 261 549 275 261 minecraft:deepslate_tiles
fill 527 275 270 527 277 270 minecraft:purple_terracotta
fill 531 275 228 531 277 228 minecraft:purple_terracotta
fill 531 275 270 531 277 270 minecraft:purple_terracotta
fill 535 275 228 535 277 228 minecraft:purple_terracotta
fill 535 275 270 535 277 270 minecraft:purple_terracotta
fill 539 275 228 539 277 228 minecraft:purple_terracotta
fill 539 275 270 539 277 270 minecraft:purple_terracotta
fill 543 275 228 543 277 228 minecraft:purple_terracotta
fill 543 275 270 543 277 270 minecraft:purple_terracotta
fill 547 275 228 547 277 228 minecraft:purple_terracotta
fill 547 275 270 547 277 270 minecraft:purple_terracotta
fill 550 275 237 550 277 237 minecraft:dark_oak_planks
fill 550 275 238 550 275 260 minecraft:deepslate_tiles
fill 550 275 261 550 277 261 minecraft:dark_oak_planks
fill 551 275 228 551 277 228 minecraft:purple_terracotta
fill 551 275 237 551 275 261 minecraft:polished_deepslate
fill 551 275 270 551 277 270 minecraft:purple_terracotta
fill 552 275 236 552 276 262 minecraft:deepslate_tiles
fill 555 275 228 555 277 228 minecraft:purple_terracotta
fill 555 275 270 555 277 270 minecraft:purple_terracotta
setblock 559 275 228 minecraft:purple_terracotta
fill 559 275 230 559 277 230 minecraft:purple_terracotta
fill 559 275 234 559 277 234 minecraft:purple_terracotta
fill 559 275 238 559 277 238 minecraft:purple_terracotta
fill 559 275 242 559 277 242 minecraft:purple_terracotta
fill 559 275 246 559 277 246 minecraft:purple_terracotta
fill 559 275 250 559 277 250 minecraft:purple_terracotta
fill 559 275 254 559 277 254 minecraft:purple_terracotta
fill 559 275 258 559 277 258 minecraft:purple_terracotta
fill 559 275 262 559 277 262 minecraft:purple_terracotta
fill 559 275 266 559 277 266 minecraft:purple_terracotta
fill 559 275 270 559 277 270 minecraft:purple_terracotta
setblock 517 276 228 minecraft:magenta_terracotta
setblock 517 276 232 minecraft:magenta_terracotta
setblock 517 276 236 minecraft:magenta_terracotta
setblock 517 276 240 minecraft:magenta_terracotta
setblock 517 276 244 minecraft:magenta_terracotta
setblock 517 276 248 minecraft:magenta_terracotta
setblock 517 276 252 minecraft:magenta_terracotta
setblock 517 276 256 minecraft:magenta_terracotta
setblock 517 276 260 minecraft:magenta_terracotta
setblock 517 276 264 minecraft:magenta_terracotta
setblock 517 276 268 minecraft:magenta_terracotta
setblock 517 276 270 minecraft:magenta_terracotta
fill 519 276 230 520 276 230 minecraft:spruce_planks
setblock 521 276 228 minecraft:magenta_terracotta
fill 521 276 229 522 276 230 minecraft:dark_oak_planks
setblock 521 276 270 minecraft:magenta_terracotta
setblock 525 276 228 minecraft:magenta_terracotta
fill 525 276 237 525 276 261 minecraft:deepslate_tiles
setblock 525 276 270 minecraft:magenta_terracotta
fill 526 276 236 550 276 236 minecraft:deepslate_tiles
fill 526 276 238 526 276 260 minecraft:polished_deepslate
fill 526 276 262 550 276 262 minecraft:deepslate_tiles
fill 527 276 237 549 276 237 minecraft:polished_deepslate
fill 527 276 238 527 278 238 minecraft:dark_oak_planks
fill 527 276 239 527 276 259 minecraft:deepslate_tiles
fill 527 276 260 527 278 260 minecraft:dark_oak_planks
fill 527 276 261 549 276 261 minecraft:polished_deepslate
fill 528 276 238 548 276 238 minecraft:deepslate_tiles
fill 528 276 260 548 276 260 minecraft:deepslate_tiles
setblock 529 276 228 minecraft:magenta_terracotta
setblock 529 276 270 minecraft:magenta_terracotta
setblock 533 276 228 minecraft:magenta_terracotta
setblock 533 276 270 minecraft:magenta_terracotta
setblock 537 276 228 minecraft:magenta_terracotta
setblock 537 276 270 minecraft:magenta_terracotta
setblock 541 276 228 minecraft:magenta_terracotta
setblock 541 276 270 minecraft:magenta_terracotta
setblock 545 276 228 minecraft:magenta_terracotta
setblock 545 276 270 minecraft:magenta_terracotta
setblock 549 276 228 minecraft:magenta_terracotta
fill 549 276 238 549 278 238 minecraft:dark_oak_planks
fill 549 276 239 549 276 259 minecraft:deepslate_tiles
fill 549 276 260 549 278 260 minecraft:dark_oak_planks
setblock 549 276 270 minecraft:magenta_terracotta
fill 550 276 238 550 276 260 minecraft:polished_deepslate
fill 551 276 237 551 276 261 minecraft:deepslate_tiles
setblock 553 276 228 minecraft:magenta_terracotta
setblock 553 276 270 minecraft:magenta_terracotta
setblock 557 276 228 minecraft:magenta_terracotta
setblock 557 276 270 minecraft:magenta_terracotta
setblock 559 276 228 minecraft:magenta_terracotta
setblock 559 276 232 minecraft:magenta_terracotta
setblock 559 276 236 minecraft:magenta_terracotta
setblock 559 276 240 minecraft:magenta_terracotta
setblock 559 276 244 minecraft:magenta_terracotta
setblock 559 276 248 minecraft:magenta_terracotta
setblock 559 276 252 minecraft:magenta_terracotta
setblock 559 276 256 minecraft:magenta_terracotta
setblock 559 276 257 minecraft:light_gray_terracotta
setblock 559 276 260 minecraft:magenta_terracotta
setblock 559 276 264 minecraft:magenta_terracotta
setblock 559 276 268 minecraft:magenta_terracotta
fill 517 277 228 517 278 228 minecraft:purple_terracotta
fill 517 277 232 517 278 232 minecraft:purple_terracotta
fill 517 277 236 517 278 236 minecraft:purple_terracotta
fill 517 277 240 517 278 240 minecraft:purple_terracotta
fill 517 277 244 517 278 244 minecraft:purple_terracotta
fill 517 277 248 517 278 248 minecraft:purple_terracotta
fill 517 277 252 517 278 252 minecraft:purple_terracotta
fill 517 277 256 517 278 256 minecraft:purple_terracotta
fill 517 277 260 517 278 260 minecraft:purple_terracotta
fill 517 277 264 517 278 264 minecraft:purple_terracotta
fill 517 277 268 517 278 268 minecraft:purple_terracotta
setblock 517 277 270 minecraft:purple_terracotta
fill 518 277 229 520 277 230 minecraft:dark_oak_planks
setblock 520 277 231 minecraft:light[level=12]
setblock 520 277 238 minecraft:light[level=12]
setblock 520 277 245 minecraft:light[level=12]
setblock 520 277 252 minecraft:light[level=12]
setblock 520 277 259 minecraft:light[level=12]
setblock 520 277 266 minecraft:light[level=12]
fill 521 277 228 521 278 228 minecraft:purple_terracotta
fill 521 277 270 521 278 270 minecraft:purple_terracotta
fill 525 277 228 525 278 228 minecraft:purple_terracotta
fill 525 277 270 525 278 270 minecraft:purple_terracotta
fill 526 277 238 526 277 260 minecraft:deepslate_tiles
setblock 527 277 231 minecraft:light[level=12]
fill 527 277 237 549 277 237 minecraft:deepslate_tiles
fill 527 277 239 527 277 259 minecraft:polished_deepslate
fill 527 277 261 549 277 261 minecraft:deepslate_tiles
setblock 527 277 266 minecraft:light[level=12]
fill 528 277 238 548 277 238 minecraft:polished_deepslate
fill 528 277 239 528 279 239 minecraft:dark_oak_planks
fill 528 277 240 528 277 258 minecraft:deepslate_tiles
fill 528 277 259 528 279 259 minecraft:dark_oak_planks
fill 528 277 260 548 277 260 minecraft:polished_deepslate
fill 529 277 228 529 278 228 minecraft:purple_terracotta
fill 529 277 239 547 277 239 minecraft:deepslate_tiles
fill 529 277 240 529 279 240 minecraft:dark_oak_planks
fill 529 277 241 529 278 257 minecraft:deepslate_tiles
fill 529 277 258 529 279 258 minecraft:dark_oak_planks
fill 529 277 259 547 277 259 minecraft:deepslate_tiles
fill 529 277 270 529 278 270 minecraft:purple_terracotta
fill 530 277 240 546 278 240 minecraft:deepslate_tiles
fill 530 277 258 546 278 258 minecraft:deepslate_tiles
fill 533 277 228 533 278 228 minecraft:purple_terracotta
fill 533 277 270 533 278 270 minecraft:purple_terracotta
setblock 534 277 231 minecraft:light[level=12]
setblock 534 277 245 minecraft:light[level=12]
setblock 534 277 252 minecraft:light[level=12]
setblock 534 277 266 minecraft:light[level=12]
fill 537 277 228 537 278 228 minecraft:purple_terracotta
fill 537 277 270 537 278 270 minecraft:purple_terracotta
fill 541 277 228 541 278 228 minecraft:purple_terracotta
setblock 541 277 231 minecraft:light[level=12]
setblock 541 277 245 minecraft:light[level=12]
setblock 541 277 266 minecraft:light[level=12]
fill 541 277 270 541 278 270 minecraft:purple_terracotta
fill 545 277 228 545 278 228 minecraft:purple_terracotta
fill 545 277 270 545 278 270 minecraft:purple_terracotta
fill 547 277 240 547 279 240 minecraft:dark_oak_planks
fill 547 277 241 548 277 257 minecraft:deepslate_tiles
fill 547 277 258 547 279 258 minecraft:dark_oak_planks
setblock 548 277 231 minecraft:light[level=12]
fill 548 277 239 548 279 239 minecraft:dark_oak_planks
setblock 548 277 240 minecraft:deepslate_tiles
setblock 548 277 258 minecraft:deepslate_tiles
fill 548 277 259 548 279 259 minecraft:dark_oak_planks
setblock 548 277 266 minecraft:light[level=12]
fill 549 277 228 549 278 228 minecraft:purple_terracotta
fill 549 277 239 549 277 259 minecraft:polished_deepslate
fill 549 277 270 549 278 270 minecraft:purple_terracotta
fill 550 277 238 550 277 260 minecraft:deepslate_tiles
fill 553 277 228 553 278 228 minecraft:purple_terracotta
fill 553 277 270 553 278 270 minecraft:purple_terracotta
setblock 555 277 231 minecraft:light[level=12]
setblock 555 277 238 minecraft:light[level=12]
setblock 555 277 245 minecraft:light[level=12]
setblock 555 277 252 minecraft:light[level=12]
setblock 555 277 259 minecraft:light[level=12]
setblock 555 277 266 minecraft:light[level=12]
fill 557 277 228 557 278 228 minecraft:purple_terracotta
fill 557 277 270 557 278 270 minecraft:purple_terracotta
setblock 559 277 228 minecraft:purple_terracotta
fill 559 277 232 559 278 232 minecraft:purple_terracotta
fill 559 277 236 559 278 236 minecraft:purple_terracotta
fill 559 277 240 559 278 240 minecraft:purple_terracotta
fill 559 277 244 559 278 244 minecraft:purple_terracotta
fill 559 277 248 559 278 248 minecraft:purple_terracotta
fill 559 277 252 559 278 252 minecraft:purple_terracotta
fill 559 277 256 559 278 257 minecraft:purple_terracotta
fill 559 277 260 559 278 260 minecraft:purple_terracotta
fill 559 277 264 559 278 264 minecraft:purple_terracotta
fill 559 277 268 559 278 268 minecraft:purple_terracotta
setblock 517 278 230 minecraft:magenta_terracotta
setblock 517 278 234 minecraft:magenta_terracotta
setblock 517 278 238 minecraft:black_terracotta
setblock 517 278 242 minecraft:magenta_terracotta
setblock 517 278 246 minecraft:magenta_terracotta
setblock 517 278 250 minecraft:magenta_terracotta
setblock 517 278 254 minecraft:magenta_terracotta
setblock 517 278 258 minecraft:magenta_terracotta
setblock 517 278 262 minecraft:magenta_terracotta
setblock 517 278 266 minecraft:magenta_terracotta
setblock 517 278 270 minecraft:magenta_terracotta
setblock 519 278 228 minecraft:magenta_terracotta
setblock 519 278 270 minecraft:magenta_terracotta
setblock 523 278 228 minecraft:magenta_terracotta
setblock 523 278 270 minecraft:magenta_terracotta
setblock 527 278 228 minecraft:magenta_terracotta
fill 527 278 239 527 278 259 minecraft:deepslate_tiles
setblock 527 278 270 minecraft:magenta_terracotta
fill 528 278 238 548 278 238 minecraft:deepslate_tiles
fill 528 278 240 528 278 258 minecraft:polished_deepslate
fill 528 278 260 548 278 260 minecraft:deepslate_tiles
fill 529 278 239 547 278 239 minecraft:polished_deepslate
fill 529 278 259 547 278 259 minecraft:polished_deepslate
fill 530 278 241 530 280 241 minecraft:dark_oak_planks
fill 530 278 242 530 279 256 minecraft:deepslate_tiles
fill 530 278 257 530 280 257 minecraft:dark_oak_planks
setblock 531 278 228 minecraft:magenta_terracotta
fill 531 278 241 545 279 241 minecraft:deepslate_tiles
fill 531 278 257 545 279 257 minecraft:deepslate_tiles
setblock 531 278 270 minecraft:magenta_terracotta
setblock 535 278 228 minecraft:magenta_terracotta
setblock 535 278 270 minecraft:magenta_terracotta
setblock 539 278 228 minecraft:magenta_terracotta
setblock 539 278 270 minecraft:magenta_terracotta
setblock 543 278 228 minecraft:magenta_terracotta
setblock 543 278 270 minecraft:magenta_terracotta
fill 546 278 241 546 280 241 minecraft:dark_oak_planks
fill 546 278 242 547 278 256 minecraft:deepslate_tiles
fill 546 278 257 546 280 257 minecraft:dark_oak_planks
setblock 547 278 228 minecraft:magenta_terracotta
setblock 547 278 241 minecraft:deepslate_tiles
setblock 547 278 257 minecraft:deepslate_tiles
setblock 547 278 270 minecraft:magenta_terracotta
fill 548 278 240 548 278 258 minecraft:polished_deepslate
fill 549 278 239 549 278 259 minecraft:deepslate_tiles
setblock 551 278 228 minecraft:magenta_terracotta
setblock 551 278 270 minecraft:magenta_terracotta
setblock 555 278 228 minecraft:magenta_terracotta
setblock 555 278 270 minecraft:magenta_terracotta
setblock 559 278 228 minecraft:magenta_terracotta
setblock 559 278 230 minecraft:magenta_terracotta
setblock 559 278 234 minecraft:magenta_terracotta
setblock 559 278 238 minecraft:magenta_terracotta
setblock 559 278 242 minecraft:magenta_terracotta
setblock 559 278 246 minecraft:magenta_terracotta
setblock 559 278 250 minecraft:magenta_terracotta
setblock 559 278 254 minecraft:magenta_terracotta
setblock 559 278 258 minecraft:magenta_terracotta
setblock 559 278 262 minecraft:magenta_terracotta
setblock 559 278 266 minecraft:magenta_terracotta
setblock 559 278 270 minecraft:magenta_terracotta
setblock 517 279 228 minecraft:blue_terracotta
fill 517 279 229 517 282 235 minecraft:gray_terracotta
setblock 517 279 236 minecraft:blue_terracotta
fill 517 279 237 517 282 238 minecraft:gray_terracotta
setblock 517 279 239 minecraft:blue_terracotta
fill 517 279 240 517 282 246 minecraft:gray_terracotta
setblock 517 279 247 minecraft:blue_terracotta
fill 517 279 248 517 280 254 minecraft:gray_terracotta
setblock 517 279 255 minecraft:blue_terracotta
fill 517 279 256 517 282 257 minecraft:gray_terracotta
setblock 517 279 258 minecraft:blue_terracotta
fill 517 279 259 517 282 261 minecraft:gray_terracotta
fill 517 279 262 517 280 262 minecraft:blue_terracotta
fill 517 279 263 517 280 269 minecraft:gray_terracotta
setblock 517 279 270 minecraft:blue_terracotta
fill 518 279 228 520 282 228 minecraft:gray_terracotta
fill 518 279 233 521 283 233 minecraft:cobbled_deepslate
fill 518 279 265 521 283 265 minecraft:cobbled_deepslate
fill 518 279 270 518 282 270 minecraft:gray_terracotta
fill 519 279 231 520 280 231 minecraft:ochre_froglight
fill 519 279 232 520 283 232 minecraft:cobbled_deepslate
fill 519 279 234 520 280 234 minecraft:ochre_froglight
fill 519 279 235 520 283 235 minecraft:cobbled_deepslate
fill 519 279 263 520 280 263 minecraft:ochre_froglight
fill 519 279 264 520 283 264 minecraft:cobbled_deepslate
fill 519 279 266 520 280 266 minecraft:ochre_froglight
fill 519 279 267 520 283 267 minecraft:cobbled_deepslate
setblock 519 279 270 minecraft:blue_terracotta
fill 520 279 230 520 283 230 minecraft:cobbled_deepslate
fill 520 279 236 520 280 236 minecraft:ochre_froglight
fill 520 279 262 520 283 262 minecraft:cobbled_deepslate
fill 520 279 268 520 280 268 minecraft:ochre_froglight
fill 520 279 270 540 279 270 minecraft:gray_terracotta
setblock 521 279 228 minecraft:blue_terracotta
fill 521 279 230 521 280 230 minecraft:ochre_froglight
fill 521 279 231 522 283 231 minecraft:cobbled_deepslate
fill 521 279 232 521 280 232 minecraft:ochre_froglight
fill 521 279 234 521 283 234 minecraft:cobbled_deepslate
fill 521 279 235 522 280 235 minecraft:ochre_froglight
fill 521 279 236 521 283 236 minecraft:cobbled_deepslate
fill 521 279 262 521 280 262 minecraft:ochre_froglight
fill 521 279 263 522 283 263 minecraft:cobbled_deepslate
fill 521 279 264 521 280 264 minecraft:ochre_froglight
fill 521 279 266 521 283 266 minecraft:cobbled_deepslate
fill 521 279 267 522 280 267 minecraft:ochre_froglight
fill 521 279 268 521 283 268 minecraft:cobbled_deepslate
fill 522 279 228 548 279 228 minecraft:gray_terracotta
fill 522 279 229 522 283 230 minecraft:cobbled_deepslate
fill 522 279 232 523 283 232 minecraft:cobbled_deepslate
fill 522 279 233 523 280 234 minecraft:ochre_froglight
fill 522 279 236 522 280 237 minecraft:ochre_froglight
fill 522 279 261 522 283 262 minecraft:cobbled_deepslate
fill 522 279 264 523 283 264 minecraft:cobbled_deepslate
fill 522 279 265 523 280 266 minecraft:ochre_froglight
fill 522 279 268 522 280 269 minecraft:ochre_froglight
fill 523 279 230 523 280 231 minecraft:ochre_froglight
fill 523 279 235 523 283 236 minecraft:cobbled_deepslate
fill 523 279 262 523 280 263 minecraft:ochre_froglight
fill 523 279 267 523 283 268 minecraft:cobbled_deepslate
fill 524 279 230 524 283 231 minecraft:cobbled_deepslate
fill 524 279 232 524 280 233 minecraft:ochre_froglight
fill 524 279 234 524 283 234 minecraft:cobbled_deepslate
fill 524 279 235 524 280 236 minecraft:ochre_froglight
fill 524 279 262 524 283 263 minecraft:cobbled_deepslate
fill 524 279 264 524 280 265 minecraft:ochre_froglight
fill 524 279 266 524 283 266 minecraft:cobbled_deepslate
fill 524 279 267 524 280 268 minecraft:ochre_froglight
fill 525 279 231 525 280 231 minecraft:ochre_froglight
fill 525 279 232 525 283 232 minecraft:cobbled_deepslate
fill 525 279 233 525 280 234 minecraft:ochre_froglight
fill 525 279 235 525 283 235 minecraft:cobbled_deepslate
fill 525 279 263 525 280 263 minecraft:ochre_froglight
fill 525 279 264 525 283 264 minecraft:cobbled_deepslate
fill 525 279 265 525 280 266 minecraft:ochre_froglight
fill 525 279 267 525 283 267 minecraft:cobbled_deepslate
fill 526 279 233 526 280 233 minecraft:ochre_froglight
fill 526 279 251 528 284 253 minecraft:red_nether_bricks
fill 526 279 265 526 280 265 minecraft:ochre_froglight
fill 528 279 240 528 279 250 minecraft:deepslate_tiles
fill 528 279 254 528 279 258 minecraft:deepslate_tiles
fill 529 279 239 547 279 239 minecraft:deepslate_tiles
fill 529 279 241 529 279 257 minecraft:polished_deepslate
fill 529 279 259 547 279 259 minecraft:deepslate_tiles
fill 530 279 240 546 279 240 minecraft:polished_deepslate
fill 530 279 258 546 279 258 minecraft:polished_deepslate
fill 531 279 242 531 281 242 minecraft:dark_oak_planks
fill 531 279 243 531 280 255 minecraft:deepslate_tiles
fill 531 279 256 531 281 256 minecraft:dark_oak_planks
fill 532 279 242 544 280 242 minecraft:deepslate_tiles
fill 532 279 243 532 281 243 minecraft:dark_oak_planks
fill 532 279 244 532 279 254 minecraft:polished_deepslate
fill 532 279 255 532 281 255 minecraft:dark_oak_planks
fill 532 279 256 544 280 256 minecraft:deepslate_tiles
fill 533 279 243 543 279 243 minecraft:polished_deepslate
fill 533 279 244 533 281 244 minecraft:dark_oak_planks
fill 533 279 245 533 279 249 minecraft:deepslate_tiles
fill 533 279 251 533 279 253 minecraft:deepslate_tiles
fill 533 279 254 533 280 254 minecraft:dark_oak_planks
fill 533 279 255 543 279 255 minecraft:polished_deepslate
fill 534 279 244 542 279 244 minecraft:deepslate_tiles
fill 534 279 245 534 280 245 minecraft:dark_oak_planks
fill 534 279 246 534 280 247 minecraft:deepslate_tiles
fill 534 279 253 534 280 253 minecraft:dark_oak_planks
fill 534 279 254 542 279 254 minecraft:deepslate_tiles
fill 535 279 245 541 280 245 minecraft:deepslate_tiles
fill 535 279 246 535 280 246 minecraft:dark_oak_planks
setblock 535 279 247 minecraft:polished_deepslate
fill 535 279 253 535 280 253 minecraft:deepslate_tiles
fill 536 279 246 540 279 246 minecraft:polished_deepslate
fill 537 279 247 539 279 247 minecraft:deepslate_tiles
fill 537 279 253 541 280 253 minecraft:deepslate_tiles
fill 539 279 248 539 280 248 minecraft:dark_oak_planks
fill 539 279 249 540 279 249 minecraft:deepslate_tiles
setblock 539 279 251 minecraft:deepslate_tiles
fill 539 279 252 540 279 252 minecraft:polished_deepslate
fill 540 279 247 540 280 247 minecraft:dark_oak_planks
setblock 540 279 248 minecraft:deepslate_tiles
setblock 540 279 250 minecraft:deepslate_tiles
fill 540 279 251 540 280 251 minecraft:dark_oak_planks
fill 541 279 246 541 281 246 minecraft:dark_oak_planks
fill 541 279 247 541 279 251 minecraft:polished_deepslate
fill 541 279 252 541 280 252 minecraft:dark_oak_planks
setblock 541 279 270 minecraft:blue_terracotta
fill 542 279 245 542 281 245 minecraft:dark_oak_planks
fill 542 279 246 543 279 252 minecraft:deepslate_tiles
fill 542 279 253 542 281 253 minecraft:dark_oak_planks
fill 542 279 270 550 282 270 minecraft:gray_terracotta
fill 543 279 244 543 281 244 minecraft:dark_oak_planks
setblock 543 279 245 minecraft:deepslate_tiles
setblock 543 279 253 minecraft:deepslate_tiles
fill 543 279 254 543 281 254 minecraft:dark_oak_planks
fill 544 279 243 544 281 243 minecraft:dark_oak_planks
fill 544 279 244 544 279 254 minecraft:polished_deepslate
fill 544 279 255 544 281 255 minecraft:dark_oak_planks
fill 545 279 242 545 281 242 minecraft:dark_oak_planks
fill 545 279 243 546 279 255 minecraft:deepslate_tiles
fill 545 279 256 545 281 256 minecraft:dark_oak_planks
setblock 546 279 242 minecraft:deepslate_tiles
setblock 546 279 256 minecraft:deepslate_tiles
fill 547 279 241 547 279 257 minecraft:polished_deepslate
fill 548 279 240 548 279 243 minecraft:deepslate_tiles
fill 548 279 244 550 284 246 minecraft:red_nether_bricks
fill 548 279 247 548 279 258 minecraft:deepslate_tiles
setblock 549 279 228 minecraft:blue_terracotta
fill 550 279 228 556 279 228 minecraft:gray_terracotta
fill 550 279 233 553 283 233 minecraft:cobbled_deepslate
fill 550 279 265 553 283 265 minecraft:cobbled_deepslate
fill 551 279 231 552 280 231 minecraft:ochre_froglight
fill 551 279 232 552 283 232 minecraft:cobbled_deepslate
fill 551 279 234 552 280 234 minecraft:ochre_froglight
fill 551 279 235 552 283 235 minecraft:cobbled_deepslate
fill 551 279 263 552 280 263 minecraft:ochre_froglight
fill 551 279 264 552 283 264 minecraft:cobbled_deepslate
fill 551 279 266 552 280 266 minecraft:ochre_froglight
fill 551 279 267 552 283 267 minecraft:cobbled_deepslate
setblock 551 279 270 minecraft:blue_terracotta
fill 552 279 230 552 283 230 minecraft:cobbled_deepslate
fill 552 279 236 552 280 236 minecraft:ochre_froglight
fill 552 279 262 552 283 262 minecraft:cobbled_deepslate
fill 552 279 268 552 280 268 minecraft:ochre_froglight
fill 552 279 270 553 282 270 minecraft:gray_terracotta
fill 553 279 230 553 280 230 minecraft:ochre_froglight
fill 553 279 231 554 283 231 minecraft:cobbled_deepslate
fill 553 279 232 553 280 232 minecraft:ochre_froglight
fill 553 279 234 553 283 234 minecraft:cobbled_deepslate
fill 553 279 235 554 280 235 minecraft:ochre_froglight
fill 553 279 236 553 283 236 minecraft:cobbled_deepslate
fill 553 279 262 553 280 262 minecraft:ochre_froglight
fill 553 279 263 554 283 263 minecraft:cobbled_deepslate
fill 553 279 264 553 280 264 minecraft:ochre_froglight
fill 553 279 266 553 283 266 minecraft:cobbled_deepslate
fill 553 279 267 554 280 267 minecraft:ochre_froglight
fill 553 279 268 553 283 268 minecraft:cobbled_deepslate
fill 554 279 229 554 283 230 minecraft:cobbled_deepslate
fill 554 279 232 555 283 232 minecraft:cobbled_deepslate
fill 554 279 233 555 280 234 minecraft:ochre_froglight
fill 554 279 236 554 280 237 minecraft:ochre_froglight
fill 554 279 261 554 283 262 minecraft:cobbled_deepslate
fill 554 279 264 555 283 264 minecraft:cobbled_deepslate
fill 554 279 265 555 280 266 minecraft:ochre_froglight
fill 554 279 268 554 280 269 minecraft:ochre_froglight
setblock 554 279 270 minecraft:blue_terracotta
fill 555 279 230 555 280 231 minecraft:ochre_froglight
fill 555 279 235 555 283 236 minecraft:cobbled_deepslate
fill 555 279 262 555 280 263 minecraft:ochre_froglight
fill 555 279 267 555 283 268 minecraft:cobbled_deepslate
fill 555 279 270 555 282 270 minecraft:gray_terracotta
fill 556 279 230 556 283 231 minecraft:cobbled_deepslate
fill 556 279 232 556 280 233 minecraft:ochre_froglight
fill 556 279 234 556 283 234 minecraft:cobbled_deepslate
fill 556 279 235 556 280 236 minecraft:ochre_froglight
fill 556 279 262 556 283 263 minecraft:cobbled_deepslate
fill 556 279 264 556 280 265 minecraft:ochre_froglight
fill 556 279 266 556 283 266 minecraft:cobbled_deepslate
fill 556 279 267 556 280 268 minecraft:ochre_froglight
fill 556 279 270 556 280 270 minecraft:blue_terracotta
setblock 557 279 228 minecraft:blue_terracotta
fill 557 279 231 557 280 231 minecraft:ochre_froglight
fill 557 279 232 557 283 232 minecraft:cobbled_deepslate
fill 557 279 233 557 280 234 minecraft:ochre_froglight
fill 557 279 235 557 283 235 minecraft:cobbled_deepslate
fill 557 279 263 557 280 263 minecraft:ochre_froglight
fill 557 279 264 557 283 264 minecraft:cobbled_deepslate
fill 557 279 265 557 280 266 minecraft:ochre_froglight
fill 557 279 267 557 283 267 minecraft:cobbled_deepslate
fill 557 279 270 559 279 270 minecraft:gray_terracotta
fill 558 279 228 559 282 228 minecraft:gray_terracotta
fill 558 279 233 558 280 233 minecraft:ochre_froglight
fill 558 279 265 558 280 265 minecraft:ochre_froglight
fill 559 279 229 559 279 235 minecraft:gray_terracotta
setblock 559 279 236 minecraft:blue_terracotta
fill 559 279 237 559 279 240 minecraft:gray_terracotta
fill 559 279 241 559 279 242 minecraft:blue_terracotta
fill 559 279 243 559 279 250 minecraft:gray_terracotta
setblock 559 279 251 minecraft:blue_terracotta
fill 559 279 252 559 282 252 minecraft:gray_terracotta
setblock 559 279 253 minecraft:blue_terracotta
fill 559 279 254 559 279 260 minecraft:gray_terracotta
setblock 559 279 261 minecraft:blue_terracotta
fill 559 279 262 559 280 269 minecraft:gray_terracotta
fill 517 280 228 517 282 228 minecraft:gray_terracotta
fill 517 280 236 517 282 236 minecraft:gray_terracotta
fill 517 280 239 517 281 239 minecraft:gray_terracotta
fill 517 280 247 517 282 247 minecraft:gray_terracotta
fill 517 280 255 517 282 255 minecraft:gray_terracotta
fill 517 280 258 517 282 258 minecraft:gray_terracotta
fill 517 280 270 517 282 270 minecraft:gray_terracotta
fill 519 280 270 531 280 270 minecraft:gray_terracotta
fill 521 280 228 525 280 228 minecraft:gray_terracotta
setblock 526 280 228 minecraft:blue_terracotta
fill 527 280 228 527 282 228 minecraft:gray_terracotta
setblock 528 280 228 minecraft:blue_terracotta
fill 529 280 228 538 280 228 minecraft:gray_terracotta
fill 530 280 242 530 280 256 minecraft:polished_deepslate
fill 531 280 241 545 280 241 minecraft:polished_deepslate
fill 531 280 257 545 280 257 minecraft:polished_deepslate
fill 532 280 244 532 280 254 minecraft:deepslate_tiles
setblock 532 280 270 minecraft:blue_terracotta
fill 533 280 243 543 280 243 minecraft:deepslate_tiles
fill 533 280 245 533 280 249 minecraft:polished_deepslate
fill 533 280 251 533 280 253 minecraft:polished_deepslate
fill 533 280 255 543 280 255 minecraft:deepslate_tiles
fill 533 280 270 541 280 270 minecraft:gray_terracotta
fill 534 280 244 542 280 244 minecraft:polished_deepslate
fill 534 280 254 542 280 254 minecraft:polished_deepslate
setblock 535 280 247 minecraft:deepslate_tiles
fill 536 280 246 540 280 246 minecraft:deepslate_tiles
fill 537 280 247 539 280 247 minecraft:polished_deepslate
fill 539 280 228 540 280 228 minecraft:blue_terracotta
setblock 539 280 249 minecraft:deepslate_tiles
setblock 539 280 251 minecraft:polished_deepslate
fill 539 280 252 540 280 252 minecraft:deepslate_tiles
fill 540 280 248 540 280 250 minecraft:polished_deepslate
fill 541 280 228 550 280 228 minecraft:gray_terracotta
fill 541 280 247 542 280 251 minecraft:deepslate_tiles
setblock 542 280 246 minecraft:deepslate_tiles
setblock 542 280 252 minecraft:deepslate_tiles
fill 543 280 245 543 280 253 minecraft:polished_deepslate
fill 544 280 244 545 280 254 minecraft:deepslate_tiles
setblock 545 280 243 minecraft:deepslate_tiles
setblock 545 280 255 minecraft:deepslate_tiles
fill 546 280 242 546 280 256 minecraft:polished_deepslate
fill 551 280 228 551 281 228 minecraft:blue_terracotta
fill 551 280 270 551 282 270 minecraft:gray_terracotta
fill 552 280 228 552 283 228 minecraft:gray_terracotta
fill 553 280 228 554 280 228 minecraft:blue_terracotta
setblock 554 280 270 minecraft:gray_terracotta
fill 555 280 228 555 282 228 minecraft:gray_terracotta
setblock 556 280 228 minecraft:blue_terracotta
fill 557 280 228 557 282 228 minecraft:gray_terracotta
fill 557 280 270 558 280 270 minecraft:gray_terracotta
fill 559 280 229 559 280 231 minecraft:gray_terracotta
fill 559 280 232 559 280 233 minecraft:blue_terracotta
fill 559 280 234 559 282 236 minecraft:gray_terracotta
setblock 559 280 237 minecraft:blue_terracotta
fill 559 280 238 559 282 238 minecraft:gray_terracotta
fill 559 280 239 559 280 240 minecraft:blue_terracotta
fill 559 280 241 559 282 246 minecraft:gray_terracotta
setblock 559 280 247 minecraft:blue_terracotta
fill 559 280 248 559 282 251 minecraft:gray_terracotta
fill 559 280 253 559 280 258 minecraft:gray_terracotta
setblock 559 280 259 minecraft:blue_terracotta
fill 559 280 260 559 282 261 minecraft:gray_terracotta
setblock 559 280 270 minecraft:blue_terracotta
fill 517 281 248 517 281 250 minecraft:gray_terracotta
setblock 517 281 251 minecraft:white_concrete
fill 517 281 252 517 282 254 minecraft:gray_terracotta
fill 517 281 262 517 282 266 minecraft:gray_terracotta
setblock 517 281 267 minecraft:blue_terracotta
fill 517 281 268 517 282 269 minecraft:gray_terracotta
fill 519 281 231 520 283 231 minecraft:cobbled_deepslate
fill 519 281 234 520 283 234 minecraft:cobbled_deepslate
fill 519 281 263 520 283 263 minecraft:cobbled_deepslate
fill 519 281 266 520 283 266 minecraft:cobbled_deepslate
fill 519 281 270 519 282 270 minecraft:gray_terracotta
fill 520 281 236 520 283 236 minecraft:cobbled_deepslate
setblock 520 281 239 minecraft:light[level=11]
setblock 520 281 247 minecraft:light[level=11]
setblock 520 281 255 minecraft:light[level=11]
fill 520 281 268 520 283 268 minecraft:cobbled_deepslate
setblock 520 281 270 minecraft:white_concrete
fill 521 281 228 522 282 228 minecraft:gray_terracotta
fill 521 281 230 521 283 230 minecraft:cobbled_deepslate
fill 521 281 232 521 283 232 minecraft:cobbled_deepslate
fill 521 281 235 522 283 235 minecraft:cobbled_deepslate
fill 521 281 262 521 283 262 minecraft:cobbled_deepslate
fill 521 281 264 521 283 264 minecraft:cobbled_deepslate
fill 521 281 267 522 283 267 minecraft:cobbled_deepslate
fill 521 281 270 526 281 270 minecraft:gray_terracotta
fill 522 281 233 523 283 234 minecraft:cobbled_deepslate
fill 522 281 236 522 283 237 minecraft:cobbled_deepslate
fill 522 281 265 523 283 266 minecraft:cobbled_deepslate
fill 522 281 268 522 283 269 minecraft:cobbled_deepslate
setblock 523 281 228 minecraft:blue_terracotta
fill 523 281 230 523 283 231 minecraft:cobbled_deepslate
fill 523 281 262 523 283 263 minecraft:cobbled_deepslate
fill 524 281 228 526 282 228 minecraft:gray_terracotta
fill 524 281 232 524 283 233 minecraft:cobbled_deepslate
fill 524 281 235 524 283 236 minecraft:cobbled_deepslate
fill 524 281 264 524 283 265 minecraft:cobbled_deepslate
fill 524 281 267 524 283 268 minecraft:cobbled_deepslate
fill 525 281 231 525 283 231 minecraft:cobbled_deepslate
fill 525 281 233 525 283 234 minecraft:cobbled_deepslate
fill 525 281 263 525 283 263 minecraft:cobbled_deepslate
fill 525 281 265 525 283 266 minecraft:cobbled_deepslate
fill 526 281 233 526 283 233 minecraft:cobbled_deepslate
fill 526 281 265 526 283 265 minecraft:cobbled_deepslate
setblock 527 281 270 minecraft:blue_terracotta
fill 528 281 228 529 282 228 minecraft:gray_terracotta
setblock 528 281 231 minecraft:light[level=11]
setblock 528 281 239 minecraft:light[level=11]
setblock 528 281 247 minecraft:light[level=11]
setblock 528 281 255 minecraft:light[level=11]
setblock 528 281 263 minecraft:light[level=11]
fill 528 281 270 531 282 270 minecraft:gray_terracotta
setblock 530 281 228 minecraft:blue_terracotta
fill 531 281 228 537 282 228 minecraft:gray_terracotta
fill 531 281 243 531 281 247 minecraft:dark_oak_planks
setblock 531 281 248 minecraft:spruce_planks
setblock 531 281 249 minecraft:dark_oak_planks
setblock 531 281 250 minecraft:spruce_planks
setblock 531 281 251 minecraft:dark_oak_planks
setblock 531 281 252 minecraft:spruce_planks
fill 531 281 253 531 281 255 minecraft:dark_oak_planks
fill 532 281 242 544 281 242 minecraft:dark_oak_planks
fill 532 281 244 532 281 246 minecraft:dark_oak_planks
setblock 532 281 247 minecraft:spruce_planks
setblock 532 281 248 minecraft:dark_oak_planks
fill 532 281 249 532 281 251 minecraft:ochre_froglight
setblock 532 281 252 minecraft:dark_oak_planks
setblock 532 281 253 minecraft:spruce_planks
setblock 532 281 254 minecraft:dark_oak_planks
fill 532 281 256 544 281 256 minecraft:polished_deepslate
setblock 532 281 270 minecraft:white_concrete
fill 533 281 243 543 281 243 minecraft:dark_oak_planks
setblock 533 281 245 minecraft:dark_oak_planks
setblock 533 281 246 minecraft:spruce_planks
fill 533 281 247 533 281 249 minecraft:ochre_froglight
fill 533 281 251 533 281 253 minecraft:ochre_froglight
setblock 533 281 254 minecraft:spruce_planks
setblock 533 281 255 minecraft:dark_oak_planks
setblock 533 281 270 minecraft:sea_lantern
fill 534 281 244 542 281 244 minecraft:dark_oak_planks
setblock 534 281 245 minecraft:spruce_planks
setblock 534 281 246 minecraft:dark_oak_planks
fill 534 281 247 535 281 247 minecraft:ochre_froglight
fill 534 281 253 535 281 253 minecraft:ochre_froglight
setblock 534 281 254 minecraft:dark_oak_planks
setblock 534 281 255 minecraft:spruce_planks
fill 534 281 270 534 282 270 minecraft:gray_terracotta
setblock 535 281 245 minecraft:dark_oak_planks
fill 535 281 246 537 281 246 minecraft:ochre_froglight
fill 535 281 254 537 281 254 minecraft:ochre_froglight
setblock 535 281 255 minecraft:dark_oak_planks
setblock 535 281 270 minecraft:blue_terracotta
setblock 536 281 231 minecraft:light[level=11]
setblock 536 281 239 minecraft:light[level=11]
setblock 536 281 245 minecraft:spruce_planks
setblock 536 281 255 minecraft:spruce_planks
setblock 536 281 263 minecraft:light[level=11]
fill 536 281 270 539 282 270 minecraft:gray_terracotta
setblock 537 281 245 minecraft:dark_oak_planks
fill 537 281 247 539 281 247 minecraft:ochre_froglight
fill 537 281 253 539 281 253 minecraft:ochre_froglight
setblock 537 281 255 minecraft:dark_oak_planks
setblock 538 281 228 minecraft:blue_terracotta
setblock 538 281 245 minecraft:spruce_planks
setblock 538 281 246 minecraft:dark_oak_planks
setblock 538 281 254 minecraft:dark_oak_planks
setblock 538 281 255 minecraft:spruce_planks
fill 539 281 228 542 281 228 minecraft:gray_terracotta
fill 539 281 245 541 281 245 minecraft:dark_oak_planks
setblock 539 281 246 minecraft:spruce_planks
fill 539 281 248 539 281 249 minecraft:ochre_froglight
fill 539 281 251 539 281 252 minecraft:ochre_froglight
setblock 539 281 254 minecraft:spruce_planks
fill 539 281 255 543 281 255 minecraft:dark_oak_planks
setblock 540 281 246 minecraft:dark_oak_planks
setblock 540 281 247 minecraft:spruce_planks
setblock 540 281 248 minecraft:dark_oak_planks
fill 540 281 249 540 281 251 minecraft:ochre_froglight
setblock 540 281 252 minecraft:dark_oak_planks
setblock 540 281 253 minecraft:spruce_planks
fill 540 281 254 542 281 254 minecraft:dark_oak_planks
setblock 540 281 270 minecraft:blue_terracotta
fill 541 281 247 544 281 247 minecraft:dark_oak_planks
setblock 541 281 248 minecraft:spruce_planks
fill 541 281 249 544 281 249 minecraft:dark_oak_planks
setblock 541 281 250 minecraft:spruce_planks
fill 541 281 251 544 281 251 minecraft:dark_oak_planks
setblock 541 281 252 minecraft:spruce_planks
setblock 541 281 253 minecraft:dark_oak_planks
fill 541 281 270 541 284 270 minecraft:gray_terracotta
fill 542 281 246 544 281 246 minecraft:dark_oak_planks
fill 542 281 248 544 281 248 minecraft:dark_oak_planks
fill 542 281 250 544 281 250 minecraft:dark_oak_planks
fill 542 281 252 544 281 252 minecraft:dark_oak_planks
setblock 543 281 228 minecraft:blue_terracotta
fill 543 281 245 544 281 245 minecraft:dark_oak_planks
fill 543 281 253 544 281 253 minecraft:dark_oak_planks
fill 544 281 228 550 281 228 minecraft:gray_terracotta
setblock 544 281 231 minecraft:light[level=11]
setblock 544 281 239 minecraft:light[level=11]
setblock 544 281 244 minecraft:dark_oak_planks
setblock 544 281 254 minecraft:dark_oak_planks
setblock 544 281 263 minecraft:light[level=11]
fill 545 281 243 545 281 255 minecraft:polished_deepslate
fill 551 281 231 552 283 231 minecraft:cobbled_deepslate
fill 551 281 234 552 283 234 minecraft:cobbled_deepslate
fill 551 281 263 552 283 263 minecraft:cobbled_deepslate
fill 551 281 266 552 283 266 minecraft:cobbled_deepslate
fill 552 281 236 552 283 236 minecraft:cobbled_deepslate
setblock 552 281 239 minecraft:light[level=11]
setblock 552 281 247 minecraft:light[level=11]
setblock 552 281 255 minecraft:light[level=11]
fill 552 281 268 552 283 268 minecraft:cobbled_deepslate
fill 553 281 228 554 282 228 minecraft:gray_terracotta
fill 553 281 230 553 283 230 minecraft:cobbled_deepslate
fill 553 281 232 553 283 232 minecraft:cobbled_deepslate
fill 553 281 235 554 283 235 minecraft:cobbled_deepslate
fill 553 281 262 553 283 262 minecraft:cobbled_deepslate
fill 553 281 264 553 283 264 minecraft:cobbled_deepslate
fill 553 281 267 554 283 267 minecraft:cobbled_deepslate
fill 554 281 233 555 283 234 minecraft:cobbled_deepslate
fill 554 281 236 554 283 237 minecraft:cobbled_deepslate
fill 554 281 265 555 283 266 minecraft:cobbled_deepslate
fill 554 281 268 554 283 269 minecraft:cobbled_deepslate
setblock 554 281 270 minecraft:white_concrete
fill 555 281 230 555 283 231 minecraft:cobbled_deepslate
fill 555 281 262 555 283 263 minecraft:cobbled_deepslate
fill 556 281 228 556 282 228 minecraft:gray_terracotta
fill 556 281 232 556 283 233 minecraft:cobbled_deepslate
fill 556 281 235 556 283 236 minecraft:cobbled_deepslate
fill 556 281 264 556 283 265 minecraft:cobbled_deepslate
fill 556 281 267 556 283 268 minecraft:cobbled_deepslate
fill 556 281 270 557 282 270 minecraft:gray_terracotta
fill 557 281 231 557 283 231 minecraft:cobbled_deepslate
fill 557 281 233 557 283 234 minecraft:cobbled_deepslate
fill 557 281 263 557 283 263 minecraft:cobbled_deepslate
fill 557 281 265 557 283 266 minecraft:cobbled_deepslate
fill 558 281 233 558 283 233 minecraft:cobbled_deepslate
fill 558 281 265 558 283 265 minecraft:cobbled_deepslate
setblock 558 281 270 minecraft:blue_terracotta
setblock 559 281 229 minecraft:blue_terracotta
fill 559 281 230 559 282 230 minecraft:gray_terracotta
setblock 559 281 231 minecraft:blue_terracotta
fill 559 281 232 559 282 233 minecraft:gray_terracotta
fill 559 281 237 559 282 237 minecraft:gray_terracotta
fill 559 281 239 559 282 240 minecraft:gray_terracotta
fill 559 281 247 559 282 247 minecraft:gray_terracotta
fill 559 281 253 559 282 253 minecraft:gray_terracotta
setblock 559 281 254 minecraft:blue_terracotta
fill 559 281 255 559 283 255 minecraft:gray_terracotta
setblock 559 281 256 minecraft:blue_terracotta
fill 559 281 257 559 282 259 minecraft:gray_terracotta
fill 559 281 262 559 282 265 minecraft:gray_terracotta
setblock 559 281 266 minecraft:blue_terracotta
fill 559 281 267 559 281 270 minecraft:gray_terracotta
setblock 517 282 239 minecraft:white_concrete
setblock 517 282 248 minecraft:sea_lantern
fill 517 282 249 517 282 251 minecraft:gray_terracotta
setblock 517 282 267 minecraft:gray_terracotta
fill 520 282 270 524 282 270 minecraft:gray_terracotta
fill 523 282 228 523 283 228 minecraft:gray_terracotta
setblock 525 282 270 minecraft:white_concrete
fill 526 282 270 527 282 270 minecraft:gray_terracotta
setblock 530 282 228 minecraft:gray_terracotta
setblock 531 282 242 minecraft:iron_bars
setblock 531 282 244 minecraft:iron_bars
setblock 531 282 246 minecraft:iron_bars
setblock 531 282 248 minecraft:iron_bars
setblock 531 282 250 minecraft:iron_bars
setblock 531 282 252 minecraft:iron_bars
setblock 531 282 254 minecraft:iron_bars
setblock 532 282 255 minecraft:iron_bars
fill 532 282 270 533 282 270 minecraft:gray_terracotta
setblock 533 282 242 minecraft:iron_bars
setblock 534 282 255 minecraft:iron_bars
setblock 535 282 242 minecraft:iron_bars
setblock 535 282 270 minecraft:gray_terracotta
setblock 536 282 255 minecraft:iron_bars
setblock 537 282 242 minecraft:iron_bars
fill 538 282 228 539 282 228 minecraft:sea_lantern
setblock 538 282 255 minecraft:iron_bars
setblock 539 282 242 minecraft:iron_bars
fill 540 282 228 549 282 228 minecraft:gray_terracotta
setblock 540 282 255 minecraft:iron_bars
setblock 540 282 270 minecraft:gray_terracotta
setblock 541 282 242 minecraft:iron_bars
setblock 542 282 255 minecraft:iron_bars
setblock 543 282 242 minecraft:iron_bars
setblock 544 282 243 minecraft:iron_bars
setblock 544 282 245 minecraft:iron_bars
setblock 544 282 247 minecraft:iron_bars
setblock 544 282 249 minecraft:iron_bars
setblock 544 282 251 minecraft:iron_bars
setblock 544 282 253 minecraft:iron_bars
setblock 544 282 255 minecraft:iron_bars
setblock 550 282 228 minecraft:white_concrete
setblock 551 282 228 minecraft:gray_terracotta
setblock 554 282 270 minecraft:sea_lantern
fill 558 282 270 559 282 270 minecraft:gray_terracotta
setblock 559 282 229 minecraft:gray_terracotta
setblock 559 282 231 minecraft:gray_terracotta
setblock 559 282 254 minecraft:gray_terracotta
setblock 559 282 256 minecraft:sea_lantern
setblock 559 282 266 minecraft:gray_terracotta
setblock 559 282 267 minecraft:sea_lantern
fill 559 282 268 559 282 269 minecraft:gray_terracotta
fill 517 283 228 517 283 238 minecraft:blue_terracotta
fill 517 283 239 517 284 239 minecraft:gray_terracotta
fill 517 283 240 517 283 255 minecraft:blue_terracotta
setblock 517 283 256 minecraft:sea_lantern
setblock 517 283 257 minecraft:gray_terracotta
fill 517 283 258 517 288 260 minecraft:blue_terracotta
setblock 517 283 261 minecraft:gray_terracotta
fill 517 283 262 517 295 263 minecraft:blue_terracotta
setblock 517 283 264 minecraft:gray_terracotta
fill 517 283 265 517 283 270 minecraft:blue_terracotta
fill 518 283 228 519 283 228 minecraft:gray_terracotta
fill 518 283 270 525 283 270 minecraft:blue_terracotta
fill 520 283 228 522 283 228 minecraft:blue_terracotta
setblock 520 283 238 minecraft:light[level=12]
setblock 520 283 245 minecraft:light[level=12]
setblock 520 283 252 minecraft:light[level=12]
setblock 520 283 259 minecraft:light[level=12]
fill 524 283 228 525 287 228 minecraft:blue_terracotta
setblock 526 283 228 minecraft:white_concrete
setblock 526 283 270 minecraft:gray_terracotta
fill 527 283 228 544 283 228 minecraft:blue_terracotta
setblock 527 283 231 minecraft:light[level=12]
setblock 527 283 238 minecraft:light[level=12]
setblock 527 283 245 minecraft:light[level=12]
setblock 527 283 259 minecraft:light[level=12]
setblock 527 283 266 minecraft:light[level=12]
fill 527 283 270 527 295 270 minecraft:blue_terracotta
setblock 528 283 270 minecraft:gray_terracotta
fill 529 283 270 539 284 270 minecraft:blue_terracotta
setblock 534 283 231 minecraft:light[level=12]
setblock 534 283 238 minecraft:light[level=12]
setblock 534 283 245 minecraft:light[level=12]
setblock 534 283 259 minecraft:light[level=12]
setblock 534 283 266 minecraft:light[level=12]
setblock 540 283 270 minecraft:sea_lantern
setblock 541 283 231 minecraft:light[level=12]
setblock 541 283 238 minecraft:light[level=12]
setblock 541 283 245 minecraft:light[level=12]
setblock 541 283 252 minecraft:light[level=12]
setblock 541 283 259 minecraft:light[level=12]
setblock 541 283 266 minecraft:light[level=12]
fill 542 283 270 542 293 270 minecraft:blue_terracotta
setblock 543 283 270 minecraft:gray_terracotta
fill 544 283 270 559 283 270 minecraft:blue_terracotta
setblock 545 283 228 minecraft:gray_terracotta
setblock 546 283 228 minecraft:sea_lantern
fill 547 283 228 549 295 228 minecraft:blue_terracotta
setblock 548 283 231 minecraft:light[level=12]
setblock 548 283 238 minecraft:light[level=12]
setblock 548 283 252 minecraft:light[level=12]
setblock 548 283 259 minecraft:light[level=12]
setblock 548 283 266 minecraft:light[level=12]
setblock 550 283 228 minecraft:gray_terracotta
fill 551 283 228 551 289 228 minecraft:blue_terracotta
fill 553 283 228 554 287 228 minecraft:blue_terracotta
setblock 555 283 228 minecraft:sea_lantern
setblock 555 283 238 minecraft:light[level=12]
setblock 555 283 245 minecraft:light[level=12]
setblock 555 283 252 minecraft:light[level=12]
setblock 555 283 259 minecraft:light[level=12]
fill 556 283 228 557 283 228 minecraft:blue_terracotta
fill 558 283 228 558 285 228 minecraft:gray_terracotta
fill 559 283 228 559 284 232 minecraft:blue_terracotta
setblock 559 283 233 minecraft:white_concrete
fill 559 283 234 559 283 254 minecraft:blue_terracotta
fill 559 283 256 559 283 259 minecraft:blue_terracotta
setblock 559 283 260 minecraft:gray_terracotta
fill 559 283 261 559 295 262 minecraft:blue_terracotta
setblock 559 283 263 minecraft:gray_terracotta
fill 559 283 264 559 288 269 minecraft:blue_terracotta
setblock 517 284 228 minecraft:gray_terracotta
fill 517 284 229 517 284 238 minecraft:blue_terracotta
fill 517 284 240 517 284 249 minecraft:blue_terracotta
setblock 517 284 250 minecraft:gray_terracotta
fill 517 284 251 517 292 257 minecraft:blue_terracotta
fill 517 284 261 517 290 261 minecraft:blue_terracotta
fill 517 284 264 517 293 265 minecraft:blue_terracotta
setblock 517 284 266 minecraft:gray_terracotta
fill 517 284 267 517 295 269 minecraft:blue_terracotta
setblock 517 284 270 minecraft:gray_terracotta
fill 518 284 228 519 295 228 minecraft:blue_terracotta
fill 518 284 270 521 288 270 minecraft:blue_terracotta
setblock 520 284 228 minecraft:gray_terracotta
fill 521 284 228 523 288 228 minecraft:blue_terracotta
setblock 522 284 233 minecraft:purple_terracotta
setblock 522 284 265 minecraft:purple_terracotta
setblock 522 284 270 minecraft:gray_terracotta
fill 523 284 270 523 291 270 minecraft:blue_terracotta
setblock 524 284 270 minecraft:white_concrete
fill 525 284 270 525 286 270 minecraft:blue_terracotta
fill 526 284 228 527 286 228 minecraft:blue_terracotta
setblock 526 284 270 minecraft:sea_lantern
setblock 528 284 228 minecraft:gray_terracotta
fill 528 284 270 528 295 270 minecraft:blue_terracotta
fill 529 284 228 539 284 228 minecraft:blue_terracotta
setblock 540 284 228 minecraft:sea_lantern
fill 540 284 270 540 295 270 minecraft:blue_terracotta
fill 541 284 228 543 295 228 minecraft:blue_terracotta
fill 543 284 270 553 284 270 minecraft:blue_terracotta
setblock 544 284 228 minecraft:white_concrete
setblock 545 284 228 minecraft:blue_terracotta
setblock 546 284 228 minecraft:gray_terracotta
fill 550 284 228 550 289 228 minecraft:blue_terracotta
setblock 552 284 228 minecraft:blue_terracotta
setblock 554 284 233 minecraft:purple_terracotta
setblock 554 284 265 minecraft:purple_terracotta
setblock 554 284 270 minecraft:gray_terracotta
fill 555 284 228 556 284 228 minecraft:blue_terracotta
fill 555 284 270 559 289 270 minecraft:blue_terracotta
setblock 557 284 228 minecraft:gray_terracotta
fill 559 284 233 559 289 235 minecraft:blue_terracotta
setblock 559 284 236 minecraft:sea_lantern
fill 559 284 237 559 284 247 minecraft:blue_terracotta
setblock 559 284 248 minecraft:gray_terracotta
fill 559 284 249 559 295 249 minecraft:blue_terracotta
setblock 559 284 250 minecraft:gray_terracotta
fill 559 284 251 559 284 256 minecraft:blue_terracotta
setblock 559 284 257 minecraft:gray_terracotta
fill 559 284 258 559 292 260 minecraft:blue_terracotta
fill 559 284 263 559 291 263 minecraft:blue_terracotta
fill 517 285 228 517 285 234 minecraft:blue_terracotta
setblock 517 285 235 minecraft:gray_terracotta
fill 517 285 236 517 295 236 minecraft:blue_terracotta
setblock 517 285 237 minecraft:gray_terracotta
fill 517 285 238 517 291 240 minecraft:blue_terracotta
setblock 517 285 241 minecraft:gray_terracotta
fill 517 285 242 517 292 245 minecraft:blue_terracotta
setblock 517 285 246 minecraft:gray_terracotta
fill 517 285 247 517 286 250 minecraft:blue_terracotta
fill 517 285 266 517 293 266 minecraft:blue_terracotta
fill 517 285 270 517 296 270 minecraft:blue_terracotta
fill 520 285 228 520 292 228 minecraft:blue_terracotta
setblock 522 285 233 minecraft:polished_deepslate
fill 522 285 260 522 288 260 minecraft:iron_bars
setblock 522 285 265 minecraft:polished_deepslate
fill 522 285 270 522 295 270 minecraft:blue_terracotta
fill 524 285 270 524 295 270 minecraft:blue_terracotta
fill 526 285 251 528 285 253 minecraft:nether_bricks
fill 526 285 270 526 295 270 minecraft:blue_terracotta
fill 528 285 228 533 287 228 minecraft:blue_terracotta
fill 529 285 270 535 285 270 minecraft:blue_terracotta
setblock 534 285 228 minecraft:gray_terracotta
fill 535 285 228 538 286 228 minecraft:blue_terracotta
setblock 536 285 270 minecraft:gray_terracotta
fill 537 285 270 539 291 270 minecraft:blue_terracotta
fill 538 285 267 542 292 267 minecraft:purple_wool
setblock 539 285 228 minecraft:gray_terracotta
fill 540 285 228 540 295 228 minecraft:blue_terracotta
fill 541 285 270 541 293 270 minecraft:blue_terracotta
fill 543 285 270 548 285 270 minecraft:blue_terracotta
fill 544 285 228 544 295 228 minecraft:blue_terracotta
setblock 545 285 228 minecraft:gray_terracotta
fill 546 285 228 546 295 228 minecraft:blue_terracotta
fill 548 285 244 550 285 246 minecraft:nether_bricks
setblock 549 285 270 minecraft:gray_terracotta
fill 550 285 270 552 291 270 minecraft:blue_terracotta
fill 551 285 233 551 288 233 minecraft:iron_bars
setblock 552 285 228 minecraft:sea_lantern
setblock 553 285 270 minecraft:gray_terracotta
setblock 554 285 233 minecraft:polished_deepslate
setblock 554 285 265 minecraft:polished_deepslate
fill 554 285 270 554 291 270 minecraft:blue_terracotta
fill 555 285 228 555 295 228 minecraft:blue_terracotta
setblock 556 285 228 minecraft:gray_terracotta
fill 556 285 245 556 295 249 minecraft:purple_wool
fill 557 285 228 557 295 228 minecraft:blue_terracotta
fill 559 285 228 559 286 231 minecraft:blue_terracotta
setblock 559 285 232 minecraft:sea_lantern
fill 559 285 236 559 291 236 minecraft:blue_terracotta
setblock 559 285 237 minecraft:gray_terracotta
fill 559 285 238 559 293 238 minecraft:blue_terracotta
setblock 559 285 239 minecraft:gray_terracotta
setblock 559 285 240 minecraft:sea_lantern
fill 559 285 241 559 287 246 minecraft:blue_terracotta
setblock 559 285 247 minecraft:white_concrete
fill 559 285 248 559 295 248 minecraft:blue_terracotta
fill 559 285 250 559 295 252 minecraft:blue_terracotta
setblock 559 285 253 minecraft:gray_terracotta
fill 559 285 254 559 295 257 minecraft:blue_terracotta
fill 517 286 228 517 291 230 minecraft:blue_terracotta
setblock 517 286 231 minecraft:white_concrete
fill 517 286 232 517 293 235 minecraft:blue_terracotta
fill 517 286 237 517 288 237 minecraft:blue_terracotta
fill 517 286 241 517 295 241 minecraft:blue_terracotta
fill 517 286 246 517 288 246 minecraft:blue_terracotta
fill 521 286 233 523 287 233 minecraft:purple_terracotta
fill 521 286 265 523 287 265 minecraft:purple_terracotta
fill 522 286 232 522 287 232 minecraft:purple_terracotta
fill 522 286 234 522 287 234 minecraft:purple_terracotta
fill 522 286 264 522 287 264 minecraft:purple_terracotta
fill 522 286 266 522 287 266 minecraft:purple_terracotta
setblock 525 286 233 minecraft:black_concrete
fill 529 286 270 533 291 270 minecraft:blue_terracotta
fill 534 286 228 534 295 228 minecraft:blue_terracotta
setblock 534 286 270 minecraft:sea_lantern
fill 535 286 270 536 287 270 minecraft:blue_terracotta
fill 539 286 228 539 295 228 minecraft:blue_terracotta
fill 543 286 270 546 291 270 minecraft:blue_terracotta
fill 545 286 228 545 295 228 minecraft:blue_terracotta
setblock 547 286 270 minecraft:white_concrete
fill 548 286 270 549 295 270 minecraft:blue_terracotta
fill 552 286 228 552 295 228 minecraft:blue_terracotta
fill 553 286 233 555 287 233 minecraft:purple_terracotta
fill 553 286 265 555 287 265 minecraft:purple_terracotta
setblock 553 286 270 minecraft:sea_lantern
fill 554 286 232 554 287 232 minecraft:purple_terracotta
fill 554 286 234 554 287 234 minecraft:purple_terracotta
fill 554 286 264 554 287 264 minecraft:purple_terracotta
fill 554 286 266 554 287 266 minecraft:purple_terracotta
fill 556 286 228 556 295 228 minecraft:blue_terracotta
fill 558 286 228 558 291 228 minecraft:blue_terracotta
fill 559 286 232 559 291 232 minecraft:blue_terracotta
fill 559 286 237 559 293 237 minecraft:blue_terracotta
fill 559 286 239 559 286 240 minecraft:blue_terracotta
fill 559 286 247 559 295 247 minecraft:blue_terracotta
fill 559 286 253 559 295 253 minecraft:blue_terracotta
fill 517 287 231 517 292 231 minecraft:blue_terracotta
fill 517 287 247 517 288 249 minecraft:blue_terracotta
setblock 517 287 250 minecraft:white_concrete
setblock 521 287 232 minecraft:purple_terracotta
setblock 521 287 234 minecraft:purple_terracotta
setblock 521 287 264 minecraft:purple_terracotta
setblock 521 287 266 minecraft:purple_terracotta
setblock 523 287 232 minecraft:purple_terracotta
setblock 523 287 234 minecraft:purple_terracotta
setblock 523 287 264 minecraft:purple_terracotta
setblock 523 287 266 minecraft:purple_terracotta
setblock 524 287 233 minecraft:black_wool
fill 525 287 270 525 288 270 minecraft:white_concrete
setblock 526 287 228 minecraft:white_concrete
fill 526 287 233 527 287 233 minecraft:black_wool
fill 527 287 228 527 296 228 minecraft:blue_terracotta
fill 534 287 270 534 295 270 minecraft:blue_terracotta
fill 535 287 228 537 293 228 minecraft:blue_terracotta
setblock 538 287 228 minecraft:sea_lantern
setblock 543 287 231 minecraft:black_concrete
fill 547 287 270 547 295 270 minecraft:blue_terracotta
setblock 553 287 232 minecraft:purple_terracotta
setblock 553 287 234 minecraft:purple_terracotta
setblock 553 287 264 minecraft:purple_terracotta
setblock 553 287 266 minecraft:purple_terracotta
fill 553 287 270 553 292 270 minecraft:blue_terracotta
setblock 555 287 232 minecraft:purple_terracotta
setblock 555 287 234 minecraft:purple_terracotta
setblock 555 287 264 minecraft:purple_terracotta
setblock 555 287 266 minecraft:purple_terracotta
fill 559 287 228 559 291 228 minecraft:blue_terracotta
setblock 559 287 229 minecraft:sea_lantern
fill 559 287 230 559 295 231 minecraft:blue_terracotta
setblock 559 287 239 minecraft:white_concrete
fill 559 287 240 559 292 240 minecraft:blue_terracotta
fill 517 288 250 517 296 250 minecraft:blue_terracotta
fill 520 288 233 524 288 233 minecraft:polished_deepslate
fill 520 288 265 524 288 265 minecraft:polished_deepslate
fill 521 288 232 523 288 232 minecraft:polished_deepslate
fill 521 288 234 523 288 234 minecraft:polished_deepslate
fill 521 288 264 523 288 264 minecraft:polished_deepslate
fill 521 288 266 523 288 266 minecraft:polished_deepslate
setblock 522 288 231 minecraft:polished_deepslate
setblock 522 288 235 minecraft:polished_deepslate
setblock 522 288 263 minecraft:polished_deepslate
setblock 522 288 267 minecraft:polished_deepslate
setblock 524 288 228 minecraft:white_concrete
fill 525 288 228 526 295 228 minecraft:blue_terracotta
setblock 528 288 228 minecraft:white_concrete
fill 529 288 228 533 293 228 minecraft:blue_terracotta
setblock 535 288 270 minecraft:sea_lantern
fill 536 288 270 536 296 270 minecraft:blue_terracotta
fill 538 288 228 538 295 228 minecraft:blue_terracotta
fill 541 288 231 542 288 231 minecraft:black_wool
setblock 543 288 265 minecraft:black_concrete
fill 544 288 231 545 288 231 minecraft:black_wool
setblock 549 288 268 minecraft:black_concrete
setblock 551 288 230 minecraft:black_concrete
fill 552 288 233 556 288 233 minecraft:polished_deepslate
fill 552 288 265 556 288 265 minecraft:polished_deepslate
fill 553 288 228 553 292 228 minecraft:blue_terracotta
fill 553 288 232 555 288 232 minecraft:polished_deepslate
fill 553 288 234 555 288 234 minecraft:polished_deepslate
fill 553 288 264 555 288 264 minecraft:polished_deepslate
fill 553 288 266 555 288 266 minecraft:polished_deepslate
setblock 554 288 228 minecraft:white_concrete
setblock 554 288 231 minecraft:polished_deepslate
setblock 554 288 235 minecraft:polished_deepslate
setblock 554 288 263 minecraft:polished_deepslate
setblock 554 288 267 minecraft:polished_deepslate
fill 559 288 229 559 292 229 minecraft:blue_terracotta
fill 559 288 239 559 291 239 minecraft:blue_terracotta
fill 559 288 241 559 289 245 minecraft:blue_terracotta
setblock 559 288 246 minecraft:white_concrete
setblock 517 289 237 minecraft:sea_lantern
setblock 517 289 246 minecraft:sea_lantern
fill 517 289 247 517 290 248 minecraft:blue_terracotta
setblock 517 289 249 minecraft:white_concrete
fill 517 289 258 517 290 259 minecraft:blue_terracotta
setblock 517 289 260 minecraft:sea_lantern
fill 518 289 257 520 289 263 minecraft:dark_oak_planks
fill 518 289 270 518 297 270 minecraft:blue_terracotta
setblock 519 289 270 minecraft:sea_lantern
setblock 520 289 231 minecraft:light[level=11]
fill 520 289 232 524 290 234 minecraft:purple_terracotta
setblock 520 289 238 minecraft:light[level=12]
setblock 520 289 239 minecraft:light[level=11]
setblock 520 289 245 minecraft:light[level=12]
setblock 520 289 247 minecraft:light[level=11]
setblock 520 289 252 minecraft:light[level=12]
setblock 520 289 255 minecraft:light[level=11]
fill 520 289 264 524 290 266 minecraft:purple_terracotta
setblock 520 289 270 minecraft:white_concrete
fill 521 289 228 522 293 228 minecraft:blue_terracotta
fill 521 289 231 523 290 231 minecraft:purple_terracotta
fill 521 289 235 523 290 235 minecraft:purple_terracotta
fill 521 289 257 522 289 262 minecraft:dark_oak_planks
fill 521 289 263 523 290 263 minecraft:purple_terracotta
fill 521 289 267 523 290 267 minecraft:purple_terracotta
fill 521 289 270 521 292 270 minecraft:blue_terracotta
setblock 523 289 228 minecraft:white_concrete
fill 524 289 228 524 295 228 minecraft:blue_terracotta
fill 525 289 270 525 292 270 minecraft:blue_terracotta
setblock 527 289 231 minecraft:light[level=12]
setblock 527 289 238 minecraft:light[level=12]
setblock 527 289 245 minecraft:light[level=12]
setblock 527 289 252 minecraft:light[level=12]
setblock 527 289 259 minecraft:light[level=12]
setblock 527 289 266 minecraft:light[level=12]
fill 528 289 228 528 295 228 minecraft:blue_terracotta
setblock 528 289 231 minecraft:light[level=11]
setblock 528 289 239 minecraft:light[level=11]
setblock 528 289 247 minecraft:light[level=11]
setblock 528 289 255 minecraft:light[level=11]
setblock 528 289 263 minecraft:light[level=11]
setblock 532 289 266 minecraft:black_concrete
setblock 534 289 231 minecraft:light[level=12]
setblock 534 289 238 minecraft:light[level=12]
setblock 534 289 245 minecraft:light[level=12]
setblock 534 289 252 minecraft:light[level=12]
setblock 534 289 259 minecraft:light[level=12]
setblock 534 289 266 minecraft:light[level=12]
fill 535 289 270 535 296 270 minecraft:blue_terracotta
setblock 536 289 231 minecraft:light[level=11]
setblock 536 289 239 minecraft:light[level=11]
setblock 536 289 247 minecraft:light[level=11]
setblock 536 289 255 minecraft:light[level=11]
setblock 536 289 263 minecraft:light[level=11]
setblock 541 289 231 minecraft:light[level=12]
setblock 541 289 238 minecraft:light[level=12]
setblock 541 289 245 minecraft:light[level=12]
setblock 541 289 252 minecraft:light[level=12]
setblock 541 289 259 minecraft:light[level=12]
fill 541 289 265 542 289 265 minecraft:black_wool
setblock 541 289 266 minecraft:light[level=12]
setblock 544 289 231 minecraft:light[level=11]
setblock 544 289 239 minecraft:light[level=11]
setblock 544 289 247 minecraft:light[level=11]
setblock 544 289 255 minecraft:light[level=11]
setblock 544 289 263 minecraft:light[level=11]
fill 544 289 265 545 289 265 minecraft:black_wool
fill 547 289 268 548 289 268 minecraft:black_wool
setblock 548 289 231 minecraft:light[level=12]
setblock 548 289 238 minecraft:light[level=12]
setblock 548 289 245 minecraft:light[level=12]
setblock 548 289 252 minecraft:light[level=12]
setblock 548 289 259 minecraft:light[level=12]
setblock 548 289 266 minecraft:light[level=12]
fill 549 289 230 550 289 230 minecraft:black_wool
fill 550 289 268 551 289 268 minecraft:black_wool
fill 552 289 230 553 289 230 minecraft:black_wool
setblock 552 289 231 minecraft:light[level=11]
fill 552 289 232 556 290 234 minecraft:purple_terracotta
setblock 552 289 239 minecraft:light[level=11]
setblock 552 289 247 minecraft:light[level=11]
setblock 552 289 255 minecraft:light[level=11]
setblock 552 289 263 minecraft:light[level=11]
fill 552 289 264 556 290 266 minecraft:purple_terracotta
fill 553 289 231 555 290 231 minecraft:purple_terracotta
fill 553 289 235 555 290 235 minecraft:purple_terracotta
fill 553 289 263 555 290 263 minecraft:purple_terracotta
fill 553 289 267 555 290 267 minecraft:purple_terracotta
fill 554 289 228 554 291 228 minecraft:blue_terracotta
setblock 555 289 238 minecraft:light[level=12]
setblock 555 289 245 minecraft:light[level=12]
setblock 555 289 252 minecraft:light[level=12]
setblock 555 289 259 minecraft:light[level=12]
fill 559 289 246 559 294 246 minecraft:blue_terracotta
fill 559 289 264 559 296 264 minecraft:blue_terracotta
setblock 559 289 265 minecraft:white_concrete
fill 559 289 266 559 291 269 minecraft:blue_terracotta
fill 517 290 237 517 294 237 minecraft:blue_terracotta
fill 517 290 246 517 291 246 minecraft:blue_terracotta
fill 517 290 249 517 295 249 minecraft:blue_terracotta
setblock 517 290 260 minecraft:blue_terracotta
fill 518 290 257 519 290 263 minecraft:stripped_dark_oak_log
fill 519 290 270 520 295 270 minecraft:blue_terracotta
setblock 520 290 231 minecraft:purple_terracotta
setblock 520 290 235 minecraft:purple_terracotta
fill 520 290 257 522 290 262 minecraft:stripped_dark_oak_log
setblock 520 290 263 minecraft:purple_terracotta
setblock 520 290 267 minecraft:purple_terracotta
fill 523 290 228 523 292 228 minecraft:blue_terracotta
setblock 524 290 231 minecraft:purple_terracotta
setblock 524 290 235 minecraft:purple_terracotta
setblock 524 290 263 minecraft:purple_terracotta
setblock 524 290 267 minecraft:purple_terracotta
fill 530 290 266 531 290 266 minecraft:black_wool
fill 533 290 266 534 290 266 minecraft:black_wool
setblock 550 290 228 minecraft:sea_lantern
setblock 551 290 228 minecraft:white_concrete
setblock 552 290 231 minecraft:purple_terracotta
setblock 552 290 235 minecraft:purple_terracotta
setblock 552 290 263 minecraft:purple_terracotta
setblock 552 290 267 minecraft:purple_terracotta
fill 555 290 270 555 291 270 minecraft:blue_terracotta
setblock 556 290 231 minecraft:purple_terracotta
setblock 556 290 235 minecraft:purple_terracotta
setblock 556 290 263 minecraft:purple_terracotta
setblock 556 290 267 minecraft:purple_terracotta
setblock 556 290 270 minecraft:sea_lantern
fill 557 290 270 559 291 270 minecraft:blue_terracotta
fill 559 290 233 559 291 233 minecraft:blue_terracotta
setblock 559 290 234 minecraft:white_concrete
fill 559 290 235 559 295 235 minecraft:blue_terracotta
setblock 559 290 241 minecraft:sea_lantern
fill 559 290 242 559 292 245 minecraft:blue_terracotta
fill 559 290 265 559 295 265 minecraft:blue_terracotta
setblock 517 291 247 minecraft:white_concrete
fill 517 291 248 517 295 248 minecraft:blue_terracotta
fill 517 291 258 517 295 258 minecraft:blue_terracotta
fill 517 291 259 517 294 261 minecraft:jack_o_lantern
fill 519 291 232 525 291 234 minecraft:polished_deepslate
fill 519 291 264 525 291 266 minecraft:polished_deepslate
fill 520 291 231 524 291 231 minecraft:polished_deepslate
fill 520 291 235 524 291 235 minecraft:polished_deepslate
fill 520 291 263 524 291 263 minecraft:polished_deepslate
fill 520 291 267 524 291 267 minecraft:polished_deepslate
fill 521 291 230 523 291 230 minecraft:polished_deepslate
fill 521 291 236 523 291 236 minecraft:polished_deepslate
fill 521 291 262 523 291 262 minecraft:polished_deepslate
fill 521 291 268 523 291 268 minecraft:polished_deepslate
fill 522 291 257 522 291 261 minecraft:purple_concrete
fill 550 291 228 551 295 228 minecraft:blue_terracotta
fill 551 291 232 557 291 234 minecraft:polished_deepslate
fill 551 291 264 557 291 266 minecraft:polished_deepslate
fill 552 291 231 556 291 231 minecraft:polished_deepslate
fill 552 291 235 556 291 235 minecraft:polished_deepslate
fill 552 291 263 556 291 263 minecraft:polished_deepslate
fill 552 291 267 556 291 267 minecraft:polished_deepslate
fill 553 291 230 555 291 230 minecraft:polished_deepslate
fill 553 291 236 555 291 236 minecraft:polished_deepslate
fill 553 291 262 555 291 262 minecraft:polished_deepslate
fill 553 291 268 555 291 268 minecraft:polished_deepslate
fill 556 291 270 556 297 270 minecraft:blue_terracotta
fill 559 291 234 559 295 234 minecraft:blue_terracotta
fill 559 291 241 559 292 241 minecraft:blue_terracotta
setblock 517 292 228 minecraft:black_concrete
fill 517 292 229 517 293 229 minecraft:blue_terracotta
setblock 517 292 230 minecraft:black_concrete
setblock 517 292 238 minecraft:blue_terracotta
setblock 517 292 239 minecraft:sea_lantern
fill 517 292 240 517 295 240 minecraft:blue_terracotta
setblock 517 292 246 minecraft:black_concrete
fill 517 292 247 517 295 247 minecraft:blue_terracotta
fill 519 292 231 525 293 235 minecraft:purple_terracotta
fill 519 292 263 525 293 267 minecraft:purple_terracotta
fill 520 292 230 524 293 230 minecraft:purple_terracotta
fill 520 292 236 524 293 236 minecraft:purple_terracotta
fill 520 292 262 524 293 262 minecraft:purple_terracotta
fill 520 292 268 524 293 268 minecraft:purple_terracotta
setblock 522 292 257 minecraft:stripped_dark_oak_log
setblock 522 292 260 minecraft:stripped_dark_oak_log
fill 523 292 270 523 293 270 minecraft:black_concrete
fill 529 292 270 531 293 270 minecraft:blue_terracotta
setblock 532 292 270 minecraft:black_concrete
setblock 533 292 270 minecraft:blue_terracotta
fill 537 292 270 537 293 270 minecraft:black_concrete
fill 538 292 270 539 295 270 minecraft:blue_terracotta
fill 543 292 270 545 292 270 minecraft:blue_terracotta
setblock 546 292 270 minecraft:black_concrete
fill 550 292 270 550 295 270 minecraft:blue_terracotta
fill 551 292 231 557 293 235 minecraft:purple_terracotta
fill 551 292 263 557 293 267 minecraft:purple_terracotta
setblock 551 292 270 minecraft:white_concrete
fill 552 292 230 556 293 230 minecraft:purple_terracotta
fill 552 292 236 556 293 236 minecraft:purple_terracotta
fill 552 292 262 556 293 262 minecraft:purple_terracotta
fill 552 292 268 556 293 268 minecraft:purple_terracotta
setblock 552 292 270 minecraft:blue_terracotta
setblock 554 292 228 minecraft:black_concrete
fill 554 292 270 555 292 270 minecraft:black_concrete
fill 557 292 270 557 294 270 minecraft:black_concrete
fill 558 292 228 559 292 228 minecraft:black_concrete
fill 558 292 270 558 294 270 minecraft:blue_terracotta
setblock 559 292 232 minecraft:black_concrete
setblock 559 292 233 minecraft:white_concrete
setblock 559 292 236 minecraft:black_concrete
setblock 559 292 239 minecraft:black_concrete
setblock 559 292 263 minecraft:black_concrete
fill 559 292 266 559 295 266 minecraft:blue_terracotta
fill 559 292 267 559 292 268 minecraft:black_concrete
fill 559 292 269 559 295 269 minecraft:blue_terracotta
setblock 559 292 270 minecraft:black_concrete
fill 517 293 228 517 295 228 minecraft:blue_terracotta
fill 517 293 230 517 295 230 minecraft:blue_terracotta
setblock 517 293 231 minecraft:black_concrete
setblock 517 293 238 minecraft:black_concrete
fill 517 293 239 517 295 239 minecraft:blue_terracotta
setblock 517 293 242 minecraft:black_concrete
fill 517 293 243 517 295 246 minecraft:blue_terracotta
fill 517 293 251 517 293 254 minecraft:blue_terracotta
fill 517 293 255 517 294 255 minecraft:black_concrete
fill 517 293 256 517 295 257 minecraft:blue_terracotta
fill 518 293 232 518 293 234 minecraft:purple_terracotta
fill 518 293 264 518 293 266 minecraft:purple_terracotta
setblock 520 293 228 minecraft:black_concrete
fill 521 293 229 523 293 229 minecraft:purple_terracotta
fill 521 293 237 523 293 237 minecraft:purple_terracotta
fill 521 293 261 523 293 261 minecraft:purple_terracotta
fill 521 293 269 523 293 269 minecraft:purple_terracotta
fill 521 293 270 521 294 270 minecraft:black_concrete
setblock 523 293 228 minecraft:sea_lantern
setblock 525 293 270 minecraft:white_concrete
fill 526 293 232 526 293 234 minecraft:purple_terracotta
fill 526 293 264 526 293 266 minecraft:purple_terracotta
fill 532 293 270 532 294 270 minecraft:blue_terracotta
setblock 533 293 270 minecraft:sea_lantern
fill 537 293 267 543 294 267 minecraft:iron_bars
setblock 543 293 270 minecraft:black_concrete
fill 544 293 270 546 295 270 minecraft:blue_terracotta
fill 550 293 232 550 293 234 minecraft:purple_terracotta
fill 550 293 264 550 293 266 minecraft:purple_terracotta
fill 551 293 270 551 295 270 minecraft:blue_terracotta
fill 552 293 270 553 293 270 minecraft:black_concrete
setblock 553 293 228 minecraft:black_concrete
fill 553 293 229 555 293 229 minecraft:purple_terracotta
fill 553 293 237 555 293 237 minecraft:purple_terracotta
fill 553 293 261 555 293 261 minecraft:purple_terracotta
fill 553 293 269 555 293 269 minecraft:purple_terracotta
fill 554 293 228 554 296 228 minecraft:blue_terracotta
fill 554 293 270 555 294 270 minecraft:blue_terracotta
fill 558 293 228 559 295 228 minecraft:blue_terracotta
fill 558 293 232 558 293 234 minecraft:purple_terracotta
fill 558 293 239 559 293 239 minecraft:light_gray_concrete
fill 558 293 240 559 293 243 minecraft:white_concrete
fill 558 293 264 558 293 266 minecraft:purple_terracotta
setblock 559 293 229 minecraft:black_concrete
fill 559 293 232 559 295 232 minecraft:blue_terracotta
setblock 559 293 233 minecraft:black_concrete
fill 559 293 236 559 294 236 minecraft:blue_terracotta
fill 559 293 244 559 293 245 minecraft:blue_terracotta
fill 559 293 258 559 293 260 minecraft:black_concrete
fill 559 293 263 559 295 263 minecraft:blue_terracotta
fill 559 293 267 559 295 267 minecraft:blue_terracotta
setblock 559 293 268 minecraft:black_concrete
fill 559 293 270 559 295 270 minecraft:blue_terracotta
setblock 517 294 229 minecraft:black_concrete
fill 517 294 231 517 295 233 minecraft:blue_terracotta
setblock 517 294 234 minecraft:sea_lantern
fill 517 294 235 517 295 235 minecraft:blue_terracotta
fill 517 294 238 517 295 238 minecraft:blue_terracotta
fill 517 294 242 517 295 242 minecraft:blue_terracotta
fill 517 294 251 517 294 253 minecraft:blue_terracotta
setblock 517 294 254 minecraft:black_concrete
fill 517 294 264 517 295 264 minecraft:blue_terracotta
fill 517 294 265 517 294 266 minecraft:black_concrete
fill 518 294 231 526 294 235 minecraft:polished_deepslate
fill 518 294 263 526 294 267 minecraft:polished_deepslate
fill 519 294 230 525 294 230 minecraft:polished_deepslate
fill 519 294 236 525 294 236 minecraft:polished_deepslate
fill 519 294 262 525 294 262 minecraft:polished_deepslate
fill 519 294 268 525 294 268 minecraft:polished_deepslate
fill 520 294 228 520 295 228 minecraft:blue_terracotta
fill 520 294 229 524 294 229 minecraft:polished_deepslate
fill 520 294 237 524 294 237 minecraft:polished_deepslate
fill 520 294 261 524 294 261 minecraft:polished_deepslate
fill 520 294 269 524 294 269 minecraft:polished_deepslate
setblock 521 294 228 minecraft:black_concrete
fill 522 294 228 523 295 228 minecraft:blue_terracotta
fill 523 294 270 523 295 270 minecraft:blue_terracotta
fill 525 294 270 525 295 270 minecraft:blue_terracotta
fill 529 294 228 529 295 228 minecraft:blue_terracotta
fill 529 294 270 531 294 270 minecraft:black_concrete
setblock 530 294 228 minecraft:black_concrete
fill 531 294 228 533 294 228 minecraft:blue_terracotta
setblock 533 294 270 minecraft:blue_terracotta
fill 535 294 228 535 295 228 minecraft:blue_terracotta
setblock 536 294 228 minecraft:sea_lantern
fill 537 294 228 537 295 228 minecraft:blue_terracotta
fill 537 294 270 537 296 270 minecraft:blue_terracotta
fill 541 294 270 542 294 270 minecraft:black_concrete
fill 543 294 270 543 295 270 minecraft:blue_terracotta
fill 550 294 231 558 294 235 minecraft:polished_deepslate
fill 550 294 263 558 294 267 minecraft:polished_deepslate
fill 551 294 230 557 294 230 minecraft:polished_deepslate
fill 551 294 236 557 294 236 minecraft:polished_deepslate
fill 551 294 262 557 294 262 minecraft:polished_deepslate
fill 551 294 268 557 294 268 minecraft:polished_deepslate
fill 552 294 229 556 294 229 minecraft:polished_deepslate
fill 552 294 237 556 294 237 minecraft:polished_deepslate
fill 552 294 261 556 294 261 minecraft:polished_deepslate
fill 552 294 269 556 294 269 minecraft:polished_deepslate
fill 552 294 270 553 295 270 minecraft:blue_terracotta
fill 553 294 228 553 295 228 minecraft:blue_terracotta
fill 558 294 237 559 294 240 minecraft:white_concrete
fill 558 294 241 559 294 241 minecraft:light_gray_concrete
fill 558 294 242 559 294 245 minecraft:white_concrete
fill 559 294 229 559 295 229 minecraft:blue_terracotta
fill 559 294 233 559 295 233 minecraft:blue_terracotta
fill 559 294 258 559 295 260 minecraft:blue_terracotta
fill 559 294 268 559 295 268 minecraft:blue_terracotta
setblock 517 295 229 minecraft:sea_lantern
setblock 517 295 234 minecraft:blue_terracotta
setblock 517 295 237 minecraft:white_concrete
fill 517 295 251 517 295 252 minecraft:blue_terracotta
fill 517 295 253 517 296 253 minecraft:white_concrete
fill 517 295 254 517 296 255 minecraft:blue_terracotta
fill 517 295 259 517 295 261 minecraft:blue_terracotta
fill 517 295 265 517 295 266 minecraft:blue_terracotta
setblock 520 295 231 minecraft:light[level=12]
setblock 520 295 238 minecraft:light[level=12]
setblock 520 295 245 minecraft:light[level=12]
setblock 520 295 252 minecraft:light[level=12]
setblock 520 295 259 minecraft:light[level=12]
setblock 520 295 266 minecraft:light[level=12]
setblock 521 295 228 minecraft:blue_terracotta
setblock 521 295 251 minecraft:black_concrete
setblock 521 295 270 minecraft:blue_terracotta
fill 522 295 233 522 297 233 minecraft:iron_bars
fill 522 295 265 522 297 265 minecraft:iron_bars
setblock 527 295 231 minecraft:light[level=12]
setblock 527 295 238 minecraft:light[level=12]
setblock 527 295 245 minecraft:light[level=12]
setblock 527 295 252 minecraft:light[level=12]
setblock 527 295 259 minecraft:light[level=12]
setblock 527 295 266 minecraft:light[level=12]
fill 529 295 270 531 295 270 minecraft:blue_terracotta
setblock 530 295 228 minecraft:blue_terracotta
setblock 531 295 228 minecraft:white_concrete
fill 532 295 228 533 295 228 minecraft:blue_terracotta
setblock 532 295 270 minecraft:sea_lantern
setblock 533 295 270 minecraft:white_concrete
setblock 534 295 231 minecraft:light[level=12]
setblock 534 295 238 minecraft:light[level=12]
setblock 534 295 245 minecraft:light[level=12]
setblock 534 295 252 minecraft:light[level=12]
setblock 534 295 259 minecraft:light[level=12]
setblock 534 295 266 minecraft:light[level=12]
setblock 536 295 228 minecraft:blue_terracotta
setblock 541 295 231 minecraft:light[level=12]
setblock 541 295 238 minecraft:light[level=12]
setblock 541 295 245 minecraft:light[level=12]
setblock 541 295 252 minecraft:light[level=12]
setblock 541 295 259 minecraft:light[level=12]
setblock 541 295 266 minecraft:light[level=12]
fill 541 295 270 542 295 270 minecraft:blue_terracotta
setblock 548 295 231 minecraft:light[level=12]
setblock 548 295 238 minecraft:light[level=12]
setblock 548 295 245 minecraft:light[level=12]
setblock 548 295 252 minecraft:light[level=12]
setblock 548 295 259 minecraft:light[level=12]
setblock 548 295 266 minecraft:light[level=12]
fill 554 295 233 554 297 233 minecraft:iron_bars
fill 554 295 265 554 297 265 minecraft:iron_bars
setblock 554 295 270 minecraft:white_concrete
setblock 555 295 231 minecraft:light[level=12]
setblock 555 295 238 minecraft:light[level=12]
setblock 555 295 245 minecraft:light[level=12]
setblock 555 295 252 minecraft:light[level=12]
setblock 555 295 259 minecraft:light[level=12]
setblock 555 295 266 minecraft:light[level=12]
setblock 555 295 270 minecraft:blue_terracotta
setblock 557 295 270 minecraft:blue_terracotta
fill 558 295 236 559 296 237 minecraft:white_concrete
fill 558 295 238 559 295 238 minecraft:light_gray_concrete
fill 558 295 239 559 295 242 minecraft:white_concrete
fill 558 295 243 559 295 243 minecraft:light_gray_concrete
fill 558 295 244 559 295 246 minecraft:white_concrete
setblock 558 295 270 minecraft:sea_lantern
fill 517 296 228 526 296 228 minecraft:black_concrete
setblock 517 296 229 minecraft:blue_terracotta
fill 517 296 230 517 296 247 minecraft:black_concrete
setblock 517 296 248 minecraft:white_concrete
fill 517 296 249 517 308 249 minecraft:black_concrete
setblock 517 296 251 minecraft:sea_lantern
fill 517 296 252 517 297 252 minecraft:black_concrete
fill 517 296 256 517 296 259 minecraft:black_concrete
setblock 517 296 260 minecraft:blue_terracotta
fill 517 296 261 517 308 261 minecraft:black_concrete
setblock 517 296 262 minecraft:blue_terracotta
fill 517 296 263 517 296 269 minecraft:black_concrete
fill 519 296 270 533 296 270 minecraft:black_concrete
fill 521 296 249 521 296 250 minecraft:black_wool
fill 521 296 252 521 296 253 minecraft:black_wool
fill 528 296 228 546 296 228 minecraft:black_concrete
setblock 534 296 270 minecraft:white_concrete
fill 538 296 270 544 297 270 minecraft:black_concrete
setblock 545 296 270 minecraft:blue_terracotta
setblock 546 296 270 minecraft:white_concrete
setblock 547 296 228 minecraft:blue_terracotta
fill 547 296 270 549 297 270 minecraft:black_concrete
fill 548 296 228 553 297 228 minecraft:black_concrete
setblock 550 296 270 minecraft:white_concrete
fill 551 296 270 555 296 270 minecraft:black_concrete
fill 555 296 228 557 298 228 minecraft:black_concrete
fill 556 296 244 556 297 250 minecraft:iron_bars
fill 557 296 270 559 296 270 minecraft:black_concrete
setblock 558 296 228 minecraft:white_concrete
fill 558 296 238 559 297 239 minecraft:white_concrete
fill 558 296 240 559 296 240 minecraft:light_gray_concrete
fill 558 296 241 559 296 244 minecraft:white_concrete
fill 558 296 245 559 296 245 minecraft:light_gray_concrete
fill 558 296 246 559 298 246 minecraft:white_concrete
fill 559 296 228 559 296 235 minecraft:black_concrete
fill 559 296 247 559 296 263 minecraft:black_concrete
setblock 559 296 265 minecraft:sea_lantern
fill 559 296 266 559 296 269 minecraft:black_concrete
fill 517 297 228 517 308 228 minecraft:black_concrete
setblock 517 297 229 minecraft:white_concrete
fill 517 297 230 517 308 230 minecraft:black_concrete
setblock 517 297 231 minecraft:blue_terracotta
fill 517 297 232 517 297 248 minecraft:black_concrete
fill 517 297 250 517 308 250 minecraft:black_concrete
setblock 517 297 251 minecraft:white_concrete
fill 517 297 253 517 308 253 minecraft:black_concrete
setblock 517 297 254 minecraft:blue_terracotta
fill 517 297 255 517 304 256 minecraft:black_concrete
setblock 517 297 257 minecraft:blue_terracotta
fill 517 297 258 517 302 260 minecraft:black_concrete
fill 517 297 262 517 297 264 minecraft:black_concrete
setblock 517 297 265 minecraft:sea_lantern
fill 517 297 266 517 308 270 minecraft:black_concrete
setblock 518 297 228 minecraft:blue_terracotta
setblock 519 297 228 minecraft:sea_lantern
fill 519 297 270 527 302 270 minecraft:black_concrete
fill 520 297 228 523 297 228 minecraft:black_concrete
setblock 520 297 231 minecraft:light[level=11]
setblock 520 297 239 minecraft:light[level=11]
setblock 520 297 247 minecraft:light[level=11]
setblock 520 297 255 minecraft:light[level=11]
setblock 520 297 263 minecraft:light[level=11]
setblock 524 297 228 minecraft:blue_terracotta
fill 525 297 228 533 297 228 minecraft:black_concrete
setblock 528 297 231 minecraft:light[level=11]
setblock 528 297 239 minecraft:light[level=11]
setblock 528 297 247 minecraft:light[level=11]
setblock 528 297 255 minecraft:light[level=11]
setblock 528 297 263 minecraft:light[level=11]
setblock 528 297 270 minecraft:sea_lantern
setblock 529 297 270 minecraft:blue_terracotta
fill 530 297 270 532 297 270 minecraft:black_concrete
setblock 533 297 270 minecraft:blue_terracotta
setblock 534 297 228 minecraft:blue_terracotta
fill 534 297 270 537 297 270 minecraft:black_concrete
fill 535 297 228 536 297 228 minecraft:black_concrete
setblock 536 297 231 minecraft:light[level=11]
setblock 536 297 239 minecraft:light[level=11]
setblock 536 297 247 minecraft:light[level=11]
setblock 536 297 255 minecraft:light[level=11]
setblock 536 297 263 minecraft:light[level=11]
setblock 537 297 228 minecraft:blue_terracotta
fill 538 297 228 539 299 228 minecraft:black_concrete
fill 540 297 228 540 298 228 minecraft:blue_terracotta
fill 541 297 228 547 297 228 minecraft:black_concrete
setblock 544 297 231 minecraft:light[level=11]
setblock 544 297 239 minecraft:light[level=11]
setblock 544 297 247 minecraft:light[level=11]
setblock 544 297 255 minecraft:light[level=11]
setblock 544 297 263 minecraft:light[level=11]
fill 545 297 270 546 303 270 minecraft:black_concrete
fill 550 297 270 550 308 270 minecraft:black_concrete
setblock 551 297 270 minecraft:blue_terracotta
setblock 552 297 231 minecraft:light[level=11]
setblock 552 297 239 minecraft:light[level=11]
setblock 552 297 247 minecraft:light[level=11]
setblock 552 297 255 minecraft:light[level=11]
setblock 552 297 263 minecraft:light[level=11]
fill 552 297 270 555 297 270 minecraft:black_concrete
fill 554 297 228 554 298 228 minecraft:black_concrete
setblock 556 297 234 minecraft:black_concrete
fill 557 297 270 558 305 270 minecraft:black_concrete
fill 558 297 228 559 297 228 minecraft:black_concrete
fill 558 297 236 559 298 236 minecraft:white_concrete
fill 558 297 237 559 297 237 minecraft:light_gray_concrete
fill 558 297 240 559 298 241 minecraft:white_concrete
fill 558 297 242 559 297 242 minecraft:light_gray_concrete
fill 558 297 243 559 297 245 minecraft:white_concrete
fill 559 297 229 559 308 229 minecraft:black_concrete
setblock 559 297 230 minecraft:white_concrete
fill 559 297 231 559 308 231 minecraft:black_concrete
fill 559 297 232 559 297 233 minecraft:sea_lantern
fill 559 297 234 559 297 235 minecraft:black_concrete
fill 559 297 247 559 297 253 minecraft:black_concrete
setblock 559 297 254 minecraft:white_concrete
fill 559 297 255 559 308 256 minecraft:black_concrete
setblock 559 297 257 minecraft:blue_terracotta
fill 559 297 258 559 299 260 minecraft:black_concrete
setblock 559 297 261 minecraft:blue_terracotta
fill 559 297 262 559 302 266 minecraft:black_concrete
setblock 559 297 267 minecraft:sea_lantern
fill 559 297 268 559 303 268 minecraft:black_concrete
fill 559 297 269 559 297 270 minecraft:blue_terracotta
fill 517 298 229 517 308 229 minecraft:black_concrete
fill 517 298 231 517 302 240 minecraft:black_concrete
setblock 517 298 241 minecraft:blue_terracotta
fill 517 298 242 517 308 242 minecraft:black_concrete
setblock 517 298 243 minecraft:blue_terracotta
fill 517 298 244 517 300 247 minecraft:black_concrete
setblock 517 298 248 minecraft:blue_terracotta
fill 517 298 251 517 308 251 minecraft:black_concrete
setblock 517 298 252 minecraft:blue_terracotta
fill 517 298 254 517 307 254 minecraft:black_concrete
fill 517 298 257 517 308 257 minecraft:black_concrete
setblock 517 298 262 minecraft:blue_terracotta
fill 517 298 263 517 308 265 minecraft:black_concrete
fill 518 298 228 521 308 228 minecraft:black_concrete
fill 518 298 270 518 308 270 minecraft:black_concrete
setblock 522 298 228 minecraft:sea_lantern
fill 523 298 228 526 305 228 minecraft:black_concrete
setblock 527 298 228 minecraft:sea_lantern
fill 528 298 228 535 302 228 minecraft:black_concrete
fill 528 298 270 529 308 270 minecraft:black_concrete
setblock 530 298 270 minecraft:blue_terracotta
fill 531 298 270 531 306 270 minecraft:black_concrete
setblock 532 298 270 minecraft:blue_terracotta
fill 533 298 270 534 299 270 minecraft:black_concrete
setblock 535 298 270 minecraft:blue_terracotta
setblock 536 298 228 minecraft:blue_terracotta
fill 536 298 270 542 298 270 minecraft:black_concrete
fill 537 298 228 537 308 228 minecraft:black_concrete
fill 541 298 228 542 308 228 minecraft:black_concrete
setblock 543 298 228 minecraft:blue_terracotta
setblock 543 298 270 minecraft:blue_terracotta
fill 544 298 228 544 308 228 minecraft:black_concrete
fill 544 298 270 544 308 270 minecraft:black_concrete
setblock 545 298 228 minecraft:blue_terracotta
fill 546 298 228 549 304 228 minecraft:black_concrete
fill 547 298 270 548 304 270 minecraft:black_concrete
setblock 549 298 270 minecraft:blue_terracotta
setblock 550 298 228 minecraft:white_concrete
fill 551 298 228 553 308 228 minecraft:black_concrete
setblock 551 298 270 minecraft:white_concrete
setblock 552 298 270 minecraft:sea_lantern
fill 553 298 270 556 300 270 minecraft:black_concrete
fill 556 298 232 556 298 233 minecraft:black_wool
fill 556 298 235 556 298 236 minecraft:black_wool
fill 558 298 228 559 298 228 minecraft:blue_terracotta
fill 558 298 235 559 299 235 minecraft:white_concrete
fill 558 298 237 559 299 238 minecraft:white_concrete
fill 558 298 239 559 298 239 minecraft:light_gray_concrete
fill 558 298 242 559 299 243 minecraft:white_concrete
fill 558 298 244 559 298 244 minecraft:light_gray_concrete
fill 558 298 245 559 300 245 minecraft:white_concrete
fill 558 298 247 559 299 247 minecraft:white_concrete
fill 559 298 230 559 308 230 minecraft:black_concrete
fill 559 298 232 559 303 234 minecraft:black_concrete
fill 559 298 248 559 299 250 minecraft:black_concrete
setblock 559 298 251 minecraft:sea_lantern
fill 559 298 252 559 308 253 minecraft:black_concrete
setblock 559 298 254 minecraft:blue_terracotta
fill 559 298 257 559 308 257 minecraft:black_concrete
fill 559 298 261 559 308 261 minecraft:black_concrete
fill 559 298 267 559 304 267 minecraft:black_concrete
setblock 559 298 269 minecraft:blue_terracotta
fill 559 298 270 559 308 270 minecraft:black_concrete
fill 517 299 241 517 308 241 minecraft:black_concrete
fill 517 299 243 517 308 243 minecraft:black_concrete
fill 517 299 248 517 308 248 minecraft:black_concrete
fill 517 299 252 517 308 252 minecraft:black_concrete
fill 517 299 262 517 308 262 minecraft:black_concrete
fill 522 299 228 522 302 228 minecraft:black_concrete
fill 527 299 228 527 308 228 minecraft:black_concrete
fill 530 299 270 530 308 270 minecraft:black_concrete
fill 532 299 270 532 307 270 minecraft:black_concrete
fill 535 299 270 540 305 270 minecraft:black_concrete
fill 536 299 228 536 308 228 minecraft:black_concrete
fill 540 299 228 540 308 228 minecraft:black_concrete
setblock 541 299 270 minecraft:sea_lantern
fill 542 299 270 543 308 270 minecraft:black_concrete
fill 543 299 228 543 303 228 minecraft:black_concrete
fill 545 299 228 545 308 228 minecraft:black_concrete
fill 549 299 270 549 308 270 minecraft:black_concrete
fill 550 299 228 550 308 228 minecraft:black_concrete
fill 551 299 270 552 308 270 minecraft:black_concrete
setblock 554 299 228 minecraft:white_concrete
fill 555 299 228 555 308 228 minecraft:black_concrete
setblock 556 299 228 minecraft:sea_lantern
fill 557 299 228 559 308 228 minecraft:black_concrete
fill 558 299 236 559 299 236 minecraft:light_gray_concrete
fill 558 299 239 559 300 240 minecraft:white_concrete
fill 558 299 241 559 299 241 minecraft:light_gray_concrete
fill 558 299 244 559 302 244 minecraft:white_concrete
fill 558 299 246 559 299 246 minecraft:light_gray_concrete
fill 559 299 251 559 308 251 minecraft:black_concrete
fill 559 299 254 559 308 254 minecraft:black_concrete
fill 559 299 269 559 308 269 minecraft:black_concrete
fill 533 300 270 533 306 270 minecraft:black_concrete
setblock 534 300 270 minecraft:white_concrete
setblock 538 300 228 minecraft:white_concrete
fill 539 300 228 539 308 228 minecraft:black_concrete
fill 541 300 270 541 308 270 minecraft:black_concrete
fill 554 300 228 554 308 228 minecraft:black_concrete
fill 556 300 228 556 308 228 minecraft:black_concrete
fill 558 300 236 559 301 237 minecraft:white_concrete
fill 558 300 238 559 300 238 minecraft:light_gray_concrete
fill 558 300 241 559 301 242 minecraft:white_concrete
fill 558 300 243 559 300 243 minecraft:light_gray_concrete
fill 558 300 246 559 302 246 minecraft:white_concrete
fill 559 300 235 559 308 235 minecraft:black_concrete
fill 559 300 247 559 304 249 minecraft:black_concrete
setblock 559 300 250 minecraft:sea_lantern
fill 559 300 258 559 308 258 minecraft:black_concrete
setblock 559 300 259 minecraft:sea_lantern
fill 559 300 260 559 308 260 minecraft:black_concrete
fill 517 301 244 517 308 244 minecraft:black_concrete
setblock 517 301 245 minecraft:white_concrete
setblock 517 301 246 minecraft:sea_lantern
fill 517 301 247 517 308 247 minecraft:black_concrete
setblock 519 301 238 minecraft:black_concrete
setblock 520 301 231 minecraft:light[level=12]
setblock 520 301 238 minecraft:light[level=12]
setblock 520 301 245 minecraft:light[level=12]
setblock 520 301 252 minecraft:light[level=12]
setblock 520 301 259 minecraft:light[level=12]
setblock 520 301 266 minecraft:light[level=12]
setblock 527 301 231 minecraft:light[level=12]
setblock 527 301 238 minecraft:light[level=12]
setblock 527 301 245 minecraft:light[level=12]
setblock 527 301 252 minecraft:light[level=12]
setblock 527 301 259 minecraft:light[level=12]
setblock 527 301 266 minecraft:light[level=12]
setblock 534 301 231 minecraft:light[level=12]
setblock 534 301 238 minecraft:light[level=12]
setblock 534 301 245 minecraft:light[level=12]
setblock 534 301 252 minecraft:light[level=12]
setblock 534 301 259 minecraft:light[level=12]
setblock 534 301 266 minecraft:light[level=12]
fill 534 301 270 534 306 270 minecraft:black_concrete
fill 538 301 228 538 308 228 minecraft:black_concrete
setblock 541 301 231 minecraft:light[level=12]
setblock 541 301 238 minecraft:light[level=12]
setblock 541 301 245 minecraft:light[level=12]
setblock 541 301 252 minecraft:light[level=12]
setblock 541 301 259 minecraft:light[level=12]
setblock 541 301 266 minecraft:light[level=12]
setblock 548 301 231 minecraft:light[level=12]
setblock 548 301 238 minecraft:light[level=12]
setblock 548 301 245 minecraft:light[level=12]
setblock 548 301 252 minecraft:light[level=12]
setblock 548 301 259 minecraft:light[level=12]
setblock 548 301 266 minecraft:light[level=12]
fill 553 301 270 554 308 270 minecraft:black_concrete
setblock 555 301 231 minecraft:light[level=12]
setblock 555 301 238 minecraft:light[level=12]
setblock 555 301 245 minecraft:light[level=12]
setblock 555 301 252 minecraft:light[level=12]
setblock 555 301 259 minecraft:light[level=12]
setblock 555 301 266 minecraft:light[level=12]
setblock 555 301 270 minecraft:sea_lantern
fill 556 301 270 556 302 270 minecraft:black_concrete
fill 558 301 238 559 302 239 minecraft:white_concrete
fill 558 301 240 559 301 240 minecraft:light_gray_concrete
fill 558 301 243 559 303 243 minecraft:white_concrete
fill 558 301 245 559 301 245 minecraft:light_gray_concrete
fill 559 301 250 559 308 250 minecraft:black_concrete
fill 559 301 259 559 308 259 minecraft:black_concrete
fill 517 302 245 517 304 246 minecraft:black_concrete
fill 519 302 236 519 302 237 minecraft:black_wool
fill 519 302 239 519 302 240 minecraft:black_wool
fill 555 302 270 555 308 270 minecraft:black_concrete
fill 558 302 236 559 302 236 minecraft:white_concrete
fill 558 302 237 559 302 237 minecraft:light_gray_concrete
fill 558 302 240 559 303 241 minecraft:white_concrete
fill 558 302 242 559 302 242 minecraft:light_gray_concrete
fill 558 302 245 559 303 245 minecraft:white_concrete
fill 517 303 231 517 306 233 minecraft:black_concrete
setblock 517 303 234 minecraft:sea_lantern
fill 517 303 235 517 303 240 minecraft:black_concrete
fill 517 303 258 517 307 258 minecraft:black_concrete
setblock 517 303 259 minecraft:white_concrete
fill 517 303 260 517 308 260 minecraft:black_concrete
fill 519 303 270 523 304 270 minecraft:black_concrete
setblock 522 303 228 minecraft:sea_lantern
setblock 524 303 270 minecraft:white_concrete
fill 525 303 270 527 306 270 minecraft:black_concrete
fill 528 303 228 529 306 228 minecraft:black_concrete
setblock 530 303 228 minecraft:white_concrete
fill 531 303 228 535 305 228 minecraft:black_concrete
setblock 554 303 265 minecraft:black_concrete
setblock 556 303 270 minecraft:white_concrete
fill 558 303 237 559 303 238 minecraft:white_concrete
fill 558 303 239 559 303 239 minecraft:light_gray_concrete
fill 558 303 242 559 303 242 minecraft:white_concrete
fill 558 303 244 559 303 244 minecraft:light_gray_concrete
fill 559 303 236 559 308 236 minecraft:black_concrete
fill 559 303 246 559 308 246 minecraft:black_concrete
setblock 559 303 262 minecraft:sea_lantern
fill 559 303 263 559 303 266 minecraft:black_concrete
fill 517 304 234 517 307 236 minecraft:black_concrete
fill 517 304 237 517 305 237 minecraft:white_concrete
fill 517 304 238 517 308 240 minecraft:black_concrete
fill 517 304 259 517 308 259 minecraft:black_concrete
fill 522 304 228 522 308 228 minecraft:black_concrete
fill 524 304 270 524 308 270 minecraft:black_concrete
fill 530 304 228 530 308 228 minecraft:black_concrete
setblock 543 304 228 minecraft:sea_lantern
setblock 545 304 270 minecraft:sea_lantern
fill 546 304 270 546 308 270 minecraft:black_concrete
fill 556 304 270 556 308 270 minecraft:black_concrete
setblock 559 304 232 minecraft:sea_lantern
fill 559 304 233 559 304 234 minecraft:black_concrete
fill 559 304 237 559 308 238 minecraft:black_concrete
fill 559 304 239 559 304 240 minecraft:white_concrete
setblock 559 304 241 minecraft:light_gray_concrete
fill 559 304 242 559 304 243 minecraft:white_concrete
fill 559 304 244 559 308 245 minecraft:black_concrete
fill 559 304 262 559 304 265 minecraft:black_concrete
setblock 559 304 266 minecraft:white_concrete
setblock 559 304 268 minecraft:sea_lantern
setblock 517 305 245 minecraft:white_concrete
fill 517 305 246 517 308 246 minecraft:black_concrete
setblock 517 305 255 minecraft:sea_lantern
fill 517 305 256 517 308 256 minecraft:black_concrete
fill 519 305 270 521 305 270 minecraft:black_concrete
setblock 522 305 270 minecraft:white_concrete
fill 523 305 270 523 308 270 minecraft:black_concrete
fill 543 305 228 543 308 228 minecraft:black_concrete
fill 545 305 270 545 308 270 minecraft:black_concrete
fill 546 305 228 546 308 228 minecraft:black_concrete
setblock 547 305 228 minecraft:white_concrete
setblock 547 305 270 minecraft:white_concrete
fill 548 305 228 549 308 228 minecraft:black_concrete
fill 548 305 270 548 308 270 minecraft:black_concrete
fill 559 305 232 559 308 233 minecraft:black_concrete
setblock 559 305 234 minecraft:sea_lantern
fill 559 305 239 559 308 243 minecraft:black_concrete
fill 559 305 247 559 308 247 minecraft:black_concrete
setblock 559 305 248 minecraft:sea_lantern
fill 559 305 249 559 308 249 minecraft:black_concrete
fill 559 305 262 559 308 263 minecraft:black_concrete
setblock 559 305 264 minecraft:sea_lantern
fill 559 305 265 559 307 266 minecraft:black_concrete
setblock 559 305 267 minecraft:white_concrete
fill 559 305 268 559 308 268 minecraft:black_concrete
fill 517 306 237 517 308 237 minecraft:black_concrete
fill 517 306 245 517 308 245 minecraft:black_concrete
fill 517 306 255 517 308 255 minecraft:black_concrete
fill 519 306 270 519 308 270 minecraft:black_concrete
setblock 520 306 270 minecraft:white_concrete
fill 521 306 270 522 308 270 minecraft:black_concrete
fill 523 306 228 523 308 228 minecraft:black_concrete
setblock 524 306 228 minecraft:white_concrete
fill 525 306 228 526 308 228 minecraft:black_concrete
setblock 531 306 228 minecraft:sea_lantern
fill 532 306 228 535 308 228 minecraft:black_concrete
fill 535 306 270 538 308 270 minecraft:black_concrete
setblock 539 306 270 minecraft:white_concrete
fill 540 306 270 540 308 270 minecraft:black_concrete
fill 547 306 228 547 308 228 minecraft:black_concrete
fill 547 306 270 547 307 270 minecraft:black_concrete
fill 557 306 270 557 308 270 minecraft:black_concrete
setblock 558 306 270 minecraft:sea_lantern
fill 559 306 234 559 308 234 minecraft:black_concrete
fill 559 306 248 559 308 248 minecraft:black_concrete
fill 559 306 264 559 308 264 minecraft:black_concrete
fill 559 306 267 559 308 267 minecraft:black_concrete
fill 517 307 231 517 308 232 minecraft:black_concrete
setblock 517 307 233 minecraft:sea_lantern
fill 520 307 270 520 308 270 minecraft:black_concrete
fill 524 307 228 524 308 228 minecraft:black_concrete
setblock 525 307 270 minecraft:white_concrete
fill 526 307 270 527 308 270 minecraft:black_concrete
fill 528 307 228 528 308 228 minecraft:black_concrete
setblock 529 307 228 minecraft:white_concrete
fill 531 307 228 531 308 228 minecraft:black_concrete
setblock 531 307 270 minecraft:sea_lantern
setblock 533 307 270 minecraft:white_concrete
setblock 534 307 270 minecraft:sea_lantern
fill 539 307 270 539 308 270 minecraft:black_concrete
fill 558 307 270 558 308 270 minecraft:black_concrete
fill 517 308 233 517 308 234 minecraft:black_concrete
setblock 517 308 235 minecraft:sea_lantern
setblock 517 308 236 minecraft:black_concrete
setblock 517 308 254 minecraft:sea_lantern
setblock 517 308 258 minecraft:sea_lantern
setblock 525 308 270 minecraft:black_concrete
setblock 529 308 228 minecraft:black_concrete
setblock 531 308 270 minecraft:black_concrete
setblock 532 308 270 minecraft:white_concrete
fill 533 308 270 534 308 270 minecraft:black_concrete
setblock 547 308 270 minecraft:white_concrete
setblock 559 308 265 minecraft:black_concrete
setblock 559 308 266 minecraft:white_concrete
