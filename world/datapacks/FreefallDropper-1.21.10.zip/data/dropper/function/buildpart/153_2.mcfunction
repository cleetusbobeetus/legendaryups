fill 465 250 629 465 307 629 minecraft:white_concrete
setblock 465 250 630 minecraft:light_gray_concrete
fill 465 250 631 465 307 632 minecraft:white_concrete
setblock 465 250 633 minecraft:light_gray_concrete
fill 465 250 634 465 307 636 minecraft:white_concrete
setblock 465 250 637 minecraft:light_gray_concrete
fill 465 250 638 465 307 638 minecraft:white_concrete
setblock 465 250 639 minecraft:light_gray_concrete
fill 465 250 640 465 255 642 minecraft:white_concrete
fill 465 250 646 465 307 646 minecraft:white_concrete
fill 423 251 614 423 307 614 minecraft:white_concrete
fill 423 251 623 423 307 623 minecraft:white_concrete
fill 423 251 644 423 307 644 minecraft:white_concrete
fill 424 251 611 424 273 612 minecraft:quartz_block
fill 424 251 619 424 273 620 minecraft:quartz_block
fill 424 251 627 424 273 628 minecraft:quartz_block
fill 424 251 635 424 273 636 minecraft:quartz_block
fill 424 251 643 424 273 644 minecraft:quartz_block
fill 425 251 605 426 273 605 minecraft:quartz_block
fill 430 251 645 431 273 645 minecraft:quartz_block
fill 431 251 604 431 307 604 minecraft:white_concrete
fill 431 251 619 431 255 620 minecraft:green_terracotta
fill 431 251 632 431 255 633 minecraft:lime_terracotta
fill 433 251 605 434 273 605 minecraft:quartz_block
fill 433 251 617 433 255 617 minecraft:green_terracotta
fill 433 251 622 433 255 622 minecraft:green_terracotta
fill 433 251 630 433 255 630 minecraft:lime_terracotta
fill 433 251 635 433 255 635 minecraft:lime_terracotta
fill 435 251 616 436 254 616 minecraft:green_terracotta
fill 435 251 623 436 252 623 minecraft:green_terracotta
fill 435 251 629 436 252 629 minecraft:lime_terracotta
fill 435 251 636 436 254 636 minecraft:lime_terracotta
fill 438 251 604 438 255 604 minecraft:white_concrete
fill 438 251 645 439 273 645 minecraft:quartz_block
fill 441 251 604 441 307 604 minecraft:white_concrete
fill 441 251 605 442 273 605 minecraft:quartz_block
fill 441 251 646 441 307 646 minecraft:white_concrete
fill 446 251 616 447 254 616 minecraft:green_terracotta
fill 446 251 623 447 253 623 minecraft:green_terracotta
fill 446 251 629 447 253 629 minecraft:lime_terracotta
fill 446 251 636 447 254 636 minecraft:lime_terracotta
fill 446 251 645 447 273 645 minecraft:quartz_block
fill 449 251 604 449 307 604 minecraft:white_concrete
fill 449 251 605 450 273 605 minecraft:quartz_block
fill 449 251 617 449 255 617 minecraft:green_terracotta
fill 449 251 622 449 255 622 minecraft:green_terracotta
fill 449 251 630 449 255 630 minecraft:lime_terracotta
fill 449 251 635 449 255 635 minecraft:lime_terracotta
fill 450 251 646 450 255 646 minecraft:white_concrete
fill 451 251 619 451 255 620 minecraft:green_terracotta
fill 451 251 632 451 255 633 minecraft:lime_terracotta
fill 452 251 646 452 307 646 minecraft:white_concrete
fill 454 251 645 455 273 645 minecraft:quartz_block
fill 457 251 605 458 273 605 minecraft:quartz_block
fill 457 251 646 457 307 646 minecraft:white_concrete
fill 459 251 646 459 307 646 minecraft:white_concrete
fill 462 251 645 463 273 645 minecraft:quartz_block
fill 464 251 606 464 273 607 minecraft:quartz_block
fill 464 251 614 464 273 615 minecraft:quartz_block
fill 464 251 622 464 273 623 minecraft:quartz_block
fill 464 251 630 464 273 631 minecraft:quartz_block
fill 464 251 638 464 273 639 minecraft:quartz_block
fill 464 251 646 464 307 646 minecraft:white_concrete
fill 465 251 607 465 307 607 minecraft:white_concrete
fill 465 251 618 465 307 618 minecraft:white_concrete
fill 465 251 623 465 307 623 minecraft:white_concrete
fill 465 251 628 465 307 628 minecraft:white_concrete
fill 465 251 630 465 307 630 minecraft:white_concrete
fill 465 251 633 465 255 633 minecraft:white_concrete
fill 465 251 637 465 307 637 minecraft:white_concrete
fill 465 251 639 465 307 639 minecraft:white_concrete
fill 424 252 605 424 253 610 minecraft:quartz_block
fill 424 252 613 425 252 618 minecraft:quartz_block
fill 424 252 621 425 252 626 minecraft:quartz_block
fill 424 252 629 425 252 634 minecraft:quartz_block
fill 424 252 637 425 252 642 minecraft:quartz_block
fill 424 252 645 429 253 645 minecraft:quartz_block
fill 425 252 606 425 252 612 minecraft:quartz_block
fill 425 252 619 425 252 620 minecraft:quartz_block
fill 425 252 627 425 252 628 minecraft:quartz_block
fill 425 252 635 425 252 636 minecraft:quartz_block
fill 425 252 643 425 252 644 minecraft:quartz_block
fill 426 252 606 463 252 606 minecraft:quartz_block
fill 426 252 644 464 252 644 minecraft:quartz_block
fill 427 252 605 432 253 605 minecraft:quartz_block
fill 431 252 618 431 254 618 minecraft:green_terracotta
fill 431 252 621 431 254 621 minecraft:green_terracotta
fill 431 252 631 431 254 631 minecraft:lime_terracotta
fill 431 252 634 431 254 634 minecraft:lime_terracotta
fill 432 252 617 432 253 617 minecraft:green_terracotta
fill 432 252 622 432 253 622 minecraft:green_terracotta
fill 432 252 630 432 253 630 minecraft:lime_terracotta
fill 432 252 635 432 253 635 minecraft:lime_terracotta
fill 432 252 645 437 253 645 minecraft:quartz_block
fill 435 252 605 440 253 605 minecraft:quartz_block
setblock 440 252 623 minecraft:green_terracotta
setblock 440 252 629 minecraft:lime_terracotta
fill 440 252 645 445 253 645 minecraft:quartz_block
setblock 442 252 623 minecraft:green_terracotta
setblock 442 252 629 minecraft:lime_terracotta
fill 443 252 605 448 253 605 minecraft:quartz_block
fill 448 252 645 453 253 645 minecraft:quartz_block
fill 450 252 617 450 253 617 minecraft:green_terracotta
fill 450 252 622 450 253 622 minecraft:green_terracotta
fill 450 252 630 450 253 630 minecraft:lime_terracotta
fill 450 252 635 450 253 635 minecraft:lime_terracotta
fill 451 252 605 456 253 605 minecraft:quartz_block
fill 451 252 618 451 254 618 minecraft:green_terracotta
fill 451 252 621 451 254 621 minecraft:green_terracotta
fill 451 252 631 451 254 631 minecraft:lime_terracotta
fill 451 252 634 451 254 634 minecraft:lime_terracotta
fill 456 252 645 461 253 645 minecraft:quartz_block
fill 459 252 605 464 253 605 minecraft:quartz_block
fill 463 252 607 463 252 643 minecraft:quartz_block
fill 464 252 608 464 253 613 minecraft:quartz_block
fill 464 252 616 464 253 621 minecraft:quartz_block
fill 464 252 624 464 253 629 minecraft:quartz_block
fill 464 252 632 464 253 637 minecraft:quartz_block
fill 464 252 640 464 253 643 minecraft:quartz_block
fill 464 252 645 464 253 645 minecraft:quartz_block
fill 424 253 613 424 253 618 minecraft:quartz_block
fill 424 253 621 424 253 626 minecraft:quartz_block
fill 424 253 629 424 253 634 minecraft:quartz_block
fill 424 253 637 424 253 642 minecraft:quartz_block
fill 435 253 623 435 255 623 minecraft:white_concrete
fill 435 253 626 436 254 627 minecraft:white_concrete
fill 435 253 629 435 255 629 minecraft:white_concrete
fill 436 253 623 438 255 623 minecraft:green_terracotta
fill 436 253 629 438 255 629 minecraft:lime_terracotta
fill 439 253 623 439 255 624 minecraft:white_concrete
fill 439 253 628 439 255 629 minecraft:white_concrete
fill 443 253 623 444 254 623 minecraft:green_terracotta
fill 443 253 629 444 254 629 minecraft:lime_terracotta
fill 445 253 623 445 255 624 minecraft:white_concrete
fill 445 253 628 445 255 629 minecraft:white_concrete
fill 448 253 623 448 255 623 minecraft:white_concrete
fill 448 253 629 448 255 629 minecraft:white_concrete
setblock 464 253 644 minecraft:quartz_block
fill 434 254 623 434 255 623 minecraft:white_concrete
fill 434 254 629 434 255 629 minecraft:white_concrete
fill 435 254 624 435 255 624 minecraft:white_concrete
fill 435 254 628 435 255 628 minecraft:white_concrete
fill 440 254 623 440 255 623 minecraft:white_concrete
fill 440 254 628 440 255 629 minecraft:white_concrete
fill 446 254 623 446 255 624 minecraft:white_concrete
fill 446 254 628 446 255 629 minecraft:white_concrete
setblock 447 254 623 minecraft:green_terracotta
setblock 447 254 629 minecraft:lime_terracotta
fill 448 254 624 448 255 624 minecraft:white_concrete
fill 448 254 628 448 255 628 minecraft:white_concrete
fill 425 255 623 426 256 624 minecraft:gold_block
fill 427 255 624 427 256 624 minecraft:gold_block
setblock 434 255 624 minecraft:white_concrete
setblock 434 255 628 minecraft:white_concrete
setblock 436 255 616 minecraft:green_terracotta
setblock 436 255 636 minecraft:lime_terracotta
fill 444 255 623 444 256 623 minecraft:green_terracotta
fill 444 255 629 444 256 629 minecraft:lime_terracotta
setblock 446 255 616 minecraft:green_terracotta
setblock 446 255 636 minecraft:lime_terracotta
fill 423 256 607 423 307 608 minecraft:white_concrete
fill 423 256 609 423 261 609 minecraft:pearlescent_froglight
fill 423 256 610 423 307 612 minecraft:white_concrete
fill 423 256 615 423 307 616 minecraft:white_concrete
fill 423 256 617 423 261 617 minecraft:pearlescent_froglight
fill 423 256 618 423 307 622 minecraft:white_concrete
fill 423 256 624 423 307 624 minecraft:white_concrete
fill 423 256 625 423 261 625 minecraft:pearlescent_froglight
fill 423 256 626 423 307 632 minecraft:white_concrete
fill 423 256 633 423 261 633 minecraft:pearlescent_froglight
fill 423 256 634 423 307 634 minecraft:white_concrete
fill 423 256 640 423 307 640 minecraft:white_concrete
fill 423 256 641 423 261 641 minecraft:pearlescent_froglight
fill 423 256 642 423 307 643 minecraft:white_concrete
fill 424 256 646 425 307 646 minecraft:white_concrete
fill 426 256 646 426 261 646 minecraft:pearlescent_froglight
fill 427 256 646 433 307 646 minecraft:white_concrete
fill 429 256 604 429 307 604 minecraft:white_concrete
fill 430 256 604 430 261 604 minecraft:pearlescent_froglight
fill 432 256 619 432 256 620 minecraft:green_terracotta
fill 432 256 632 432 256 633 minecraft:lime_terracotta
fill 434 256 616 434 257 616 minecraft:black_concrete
fill 434 256 646 434 261 646 minecraft:pearlescent_froglight
fill 435 256 646 439 307 646 minecraft:white_concrete
fill 437 256 623 438 256 623 minecraft:green_terracotta
fill 437 256 629 438 256 629 minecraft:lime_terracotta
fill 438 256 604 438 261 604 minecraft:pearlescent_froglight
fill 438 256 622 440 256 622 minecraft:green_terracotta
fill 438 256 630 440 256 630 minecraft:lime_terracotta
fill 442 256 622 444 256 622 minecraft:green_terracotta
fill 442 256 630 444 256 630 minecraft:lime_terracotta
fill 442 256 646 442 261 646 minecraft:pearlescent_froglight
setblock 445 256 623 minecraft:green_terracotta
setblock 445 256 629 minecraft:lime_terracotta
fill 446 256 604 446 261 604 minecraft:pearlescent_froglight
fill 447 256 604 448 307 604 minecraft:white_concrete
setblock 449 256 618 minecraft:green_terracotta
setblock 449 256 621 minecraft:green_terracotta
setblock 449 256 631 minecraft:lime_terracotta
setblock 449 256 634 minecraft:lime_terracotta
fill 450 256 604 453 307 604 minecraft:white_concrete
fill 450 256 646 450 261 646 minecraft:pearlescent_froglight
fill 454 256 604 454 261 604 minecraft:pearlescent_froglight
fill 455 256 604 461 307 604 minecraft:white_concrete
fill 458 256 646 458 261 646 minecraft:pearlescent_froglight
fill 462 256 604 462 261 604 minecraft:pearlescent_froglight
fill 463 256 604 465 307 604 minecraft:white_concrete
fill 465 256 608 465 307 608 minecraft:white_concrete
fill 465 256 609 465 261 609 minecraft:pearlescent_froglight
fill 465 256 613 465 307 616 minecraft:white_concrete
fill 465 256 617 465 261 617 minecraft:pearlescent_froglight
fill 465 256 624 465 307 624 minecraft:white_concrete
fill 465 256 625 465 261 625 minecraft:pearlescent_froglight
fill 465 256 626 465 307 627 minecraft:white_concrete
fill 465 256 633 465 261 633 minecraft:pearlescent_froglight
fill 465 256 640 465 307 640 minecraft:white_concrete
fill 465 256 641 465 261 641 minecraft:pearlescent_froglight
fill 465 256 642 465 307 642 minecraft:white_concrete
setblock 434 257 617 minecraft:black_concrete
fill 436 257 617 437 257 617 minecraft:green_terracotta
fill 436 257 622 439 257 622 minecraft:green_terracotta
fill 436 257 630 439 257 630 minecraft:lime_terracotta
fill 436 257 635 437 257 635 minecraft:lime_terracotta
fill 442 257 612 442 258 614 minecraft:black_concrete
fill 443 257 613 443 258 614 minecraft:black_concrete
fill 443 257 622 446 257 622 minecraft:green_terracotta
fill 443 257 630 446 257 630 minecraft:lime_terracotta
fill 445 257 617 446 257 617 minecraft:green_terracotta
fill 445 257 635 446 257 635 minecraft:lime_terracotta
setblock 426 258 607 minecraft:light[level=13]
setblock 426 258 615 minecraft:light[level=13]
setblock 426 258 623 minecraft:light[level=13]
setblock 426 258 631 minecraft:light[level=13]
setblock 426 258 639 minecraft:light[level=13]
setblock 434 258 607 minecraft:light[level=13]
setblock 434 258 615 minecraft:light[level=13]
setblock 434 258 623 minecraft:light[level=13]
setblock 434 258 631 minecraft:light[level=13]
setblock 434 258 639 minecraft:light[level=13]
fill 435 258 619 436 258 620 minecraft:green_terracotta
fill 435 258 632 436 258 633 minecraft:lime_terracotta
setblock 436 258 618 minecraft:green_terracotta
setblock 436 258 621 minecraft:green_terracotta
setblock 436 258 631 minecraft:lime_terracotta
setblock 436 258 634 minecraft:lime_terracotta
fill 439 258 617 443 258 617 minecraft:green_terracotta
fill 439 258 635 443 258 635 minecraft:lime_terracotta
setblock 442 258 607 minecraft:light[level=13]
setblock 442 258 615 minecraft:light[level=13]
setblock 442 258 639 minecraft:light[level=13]
fill 444 258 618 446 258 618 minecraft:green_terracotta
fill 444 258 621 446 258 621 minecraft:green_terracotta
fill 444 258 631 446 258 631 minecraft:lime_terracotta
fill 444 258 634 446 258 634 minecraft:lime_terracotta
setblock 446 258 619 minecraft:green_terracotta
fill 446 258 620 448 259 620 minecraft:pearlescent_froglight
fill 446 258 632 448 259 632 minecraft:pearlescent_froglight
setblock 446 258 633 minecraft:lime_terracotta
fill 447 258 619 447 259 619 minecraft:pearlescent_froglight
fill 447 258 621 447 259 621 minecraft:pearlescent_froglight
fill 447 258 631 447 259 631 minecraft:pearlescent_froglight
fill 447 258 633 447 259 633 minecraft:pearlescent_froglight
setblock 450 258 607 minecraft:light[level=13]
setblock 450 258 615 minecraft:light[level=13]
setblock 450 258 623 minecraft:light[level=13]
setblock 450 258 631 minecraft:light[level=13]
setblock 450 258 639 minecraft:light[level=13]
setblock 458 258 607 minecraft:light[level=13]
setblock 458 258 615 minecraft:light[level=13]
setblock 458 258 623 minecraft:light[level=13]
setblock 458 258 631 minecraft:light[level=13]
setblock 458 258 639 minecraft:light[level=13]
fill 427 259 630 427 260 630 minecraft:gold_block
fill 438 259 619 444 259 620 minecraft:green_terracotta
fill 438 259 632 444 259 633 minecraft:lime_terracotta
fill 426 261 622 428 262 623 minecraft:white_concrete
fill 423 262 609 423 269 609 minecraft:white_concrete
fill 423 262 617 423 269 617 minecraft:white_concrete
fill 423 262 625 423 269 625 minecraft:white_concrete
fill 423 262 633 423 269 633 minecraft:white_concrete
fill 423 262 641 423 269 641 minecraft:white_concrete
fill 426 262 646 426 269 646 minecraft:white_concrete
fill 430 262 604 430 269 604 minecraft:white_concrete
fill 434 262 646 434 269 646 minecraft:white_concrete
fill 438 262 604 438 269 604 minecraft:white_concrete
fill 442 262 646 442 269 646 minecraft:white_concrete
fill 446 262 604 446 269 604 minecraft:white_concrete
fill 450 262 646 450 269 646 minecraft:white_concrete
fill 454 262 604 454 269 604 minecraft:white_concrete
fill 458 262 646 458 269 646 minecraft:white_concrete
fill 462 262 604 462 269 604 minecraft:white_concrete
fill 465 262 609 465 269 609 minecraft:white_concrete
fill 465 262 617 465 269 617 minecraft:white_concrete
fill 465 262 625 465 269 625 minecraft:white_concrete
fill 465 262 633 465 269 633 minecraft:white_concrete
fill 465 262 641 465 269 641 minecraft:white_concrete
fill 424 266 605 424 267 610 minecraft:quartz_block
fill 424 266 613 425 266 618 minecraft:quartz_block
fill 424 266 621 425 266 626 minecraft:quartz_block
fill 424 266 629 425 266 634 minecraft:quartz_block
fill 424 266 637 425 266 642 minecraft:quartz_block
fill 424 266 645 429 267 645 minecraft:quartz_block
fill 425 266 606 425 266 612 minecraft:quartz_block
fill 425 266 619 425 266 620 minecraft:quartz_block
fill 425 266 627 425 266 628 minecraft:quartz_block
fill 425 266 635 425 266 636 minecraft:quartz_block
fill 425 266 643 425 266 644 minecraft:quartz_block
fill 426 266 606 463 266 606 minecraft:quartz_block
setblock 426 266 607 minecraft:light[level=13]
setblock 426 266 615 minecraft:light[level=13]
setblock 426 266 623 minecraft:light[level=13]
setblock 426 266 631 minecraft:light[level=13]
setblock 426 266 639 minecraft:light[level=13]
fill 426 266 644 464 266 644 minecraft:quartz_block
fill 427 266 605 432 267 605 minecraft:quartz_block
fill 432 266 645 437 267 645 minecraft:quartz_block
setblock 434 266 607 minecraft:light[level=13]
setblock 434 266 615 minecraft:light[level=13]
setblock 434 266 623 minecraft:light[level=13]
setblock 434 266 631 minecraft:light[level=13]
setblock 434 266 639 minecraft:light[level=13]
fill 435 266 605 440 267 605 minecraft:quartz_block
fill 440 266 645 445 267 645 minecraft:quartz_block
setblock 442 266 607 minecraft:light[level=13]
setblock 442 266 615 minecraft:light[level=13]
setblock 442 266 623 minecraft:light[level=13]
setblock 442 266 631 minecraft:light[level=13]
setblock 442 266 639 minecraft:light[level=13]
fill 443 266 605 448 267 605 minecraft:quartz_block
fill 448 266 645 453 267 645 minecraft:quartz_block
setblock 450 266 607 minecraft:light[level=13]
setblock 450 266 615 minecraft:light[level=13]
setblock 450 266 623 minecraft:light[level=13]
setblock 450 266 631 minecraft:light[level=13]
setblock 450 266 639 minecraft:light[level=13]
fill 451 266 605 456 267 605 minecraft:quartz_block
fill 456 266 645 461 267 645 minecraft:quartz_block
setblock 458 266 607 minecraft:light[level=13]
setblock 458 266 615 minecraft:light[level=13]
setblock 458 266 623 minecraft:light[level=13]
setblock 458 266 631 minecraft:light[level=13]
setblock 458 266 639 minecraft:light[level=13]
fill 459 266 605 464 267 605 minecraft:quartz_block
fill 463 266 607 463 266 643 minecraft:quartz_block
fill 464 266 608 464 267 613 minecraft:quartz_block
fill 464 266 616 464 267 621 minecraft:quartz_block
fill 464 266 624 464 267 629 minecraft:quartz_block
fill 464 266 632 464 267 637 minecraft:quartz_block
fill 464 266 640 464 267 643 minecraft:quartz_block
fill 464 266 645 464 267 645 minecraft:quartz_block
fill 424 267 613 424 267 618 minecraft:quartz_block
fill 424 267 621 424 267 626 minecraft:quartz_block
fill 424 267 629 424 267 634 minecraft:quartz_block
fill 424 267 637 424 267 642 minecraft:quartz_block
setblock 464 267 644 minecraft:quartz_block
fill 435 269 619 435 270 620 minecraft:white_concrete
fill 423 270 609 423 273 609 minecraft:pearlescent_froglight
fill 423 270 617 423 273 617 minecraft:pearlescent_froglight
fill 423 270 625 423 273 625 minecraft:pearlescent_froglight
fill 423 270 633 423 273 633 minecraft:pearlescent_froglight
fill 423 270 641 423 273 641 minecraft:pearlescent_froglight
fill 426 270 646 426 273 646 minecraft:pearlescent_froglight
fill 430 270 604 430 273 604 minecraft:pearlescent_froglight
fill 434 270 646 434 273 646 minecraft:pearlescent_froglight
fill 438 270 604 438 273 604 minecraft:pearlescent_froglight
fill 442 270 646 442 273 646 minecraft:pearlescent_froglight
fill 446 270 604 446 273 604 minecraft:pearlescent_froglight
fill 450 270 646 450 273 646 minecraft:pearlescent_froglight
fill 454 270 604 454 273 604 minecraft:pearlescent_froglight
fill 458 270 646 458 273 646 minecraft:pearlescent_froglight
fill 462 270 604 462 273 604 minecraft:pearlescent_froglight
fill 465 270 609 465 273 609 minecraft:pearlescent_froglight
fill 465 270 617 465 273 617 minecraft:pearlescent_froglight
fill 465 270 625 465 273 625 minecraft:pearlescent_froglight
fill 465 270 633 465 273 633 minecraft:pearlescent_froglight
fill 465 270 641 465 273 641 minecraft:pearlescent_froglight
fill 423 274 609 423 283 609 minecraft:white_concrete
fill 423 274 617 423 283 617 minecraft:white_concrete
fill 423 274 625 423 283 625 minecraft:white_concrete
fill 423 274 633 423 283 633 minecraft:white_concrete
fill 423 274 641 423 283 641 minecraft:white_concrete
setblock 426 274 607 minecraft:light[level=13]
setblock 426 274 615 minecraft:light[level=13]
setblock 426 274 623 minecraft:light[level=13]
setblock 426 274 631 minecraft:light[level=13]
setblock 426 274 639 minecraft:light[level=13]
fill 426 274 646 426 283 646 minecraft:white_concrete
fill 430 274 604 430 283 604 minecraft:white_concrete
setblock 434 274 607 minecraft:light[level=13]
setblock 434 274 615 minecraft:light[level=13]
setblock 434 274 623 minecraft:light[level=13]
setblock 434 274 631 minecraft:light[level=13]
setblock 434 274 639 minecraft:light[level=13]
fill 434 274 646 434 283 646 minecraft:white_concrete
fill 438 274 604 438 283 604 minecraft:white_concrete
setblock 442 274 607 minecraft:light[level=13]
setblock 442 274 615 minecraft:light[level=13]
setblock 442 274 623 minecraft:light[level=13]
setblock 442 274 631 minecraft:light[level=13]
setblock 442 274 639 minecraft:light[level=13]
fill 442 274 646 442 283 646 minecraft:white_concrete
fill 446 274 604 446 283 604 minecraft:white_concrete
setblock 450 274 607 minecraft:light[level=13]
setblock 450 274 615 minecraft:light[level=13]
setblock 450 274 623 minecraft:light[level=13]
setblock 450 274 631 minecraft:light[level=13]
setblock 450 274 639 minecraft:light[level=13]
fill 450 274 646 450 283 646 minecraft:white_concrete
fill 454 274 604 454 283 604 minecraft:white_concrete
setblock 458 274 607 minecraft:light[level=13]
setblock 458 274 615 minecraft:light[level=13]
setblock 458 274 623 minecraft:light[level=13]
setblock 458 274 631 minecraft:light[level=13]
setblock 458 274 639 minecraft:light[level=13]
fill 458 274 646 458 283 646 minecraft:white_concrete
fill 462 274 604 462 283 604 minecraft:white_concrete
fill 465 274 609 465 283 609 minecraft:white_concrete
fill 465 274 617 465 283 617 minecraft:white_concrete
fill 465 274 625 465 283 625 minecraft:white_concrete
fill 465 274 633 465 283 633 minecraft:white_concrete
fill 465 274 641 465 283 641 minecraft:white_concrete
fill 435 278 622 437 278 624 minecraft:redstone_block
fill 437 278 627 439 278 629 minecraft:redstone_block
fill 443 278 619 445 278 621 minecraft:redstone_block
fill 444 278 626 446 278 628 minecraft:redstone_block
fill 425 279 624 434 279 624 minecraft:gold_block
fill 427 279 618 427 280 618 minecraft:gold_block
fill 427 279 630 427 280 630 minecraft:gold_block
fill 428 279 619 432 280 619 minecraft:gold_block
fill 428 279 629 432 280 629 minecraft:gold_block
fill 429 279 620 442 279 620 minecraft:gold_block
fill 429 279 623 434 279 623 minecraft:gold_block
fill 429 279 625 439 279 625 minecraft:gold_block
fill 429 279 628 436 279 628 minecraft:gold_block
fill 430 279 613 430 280 613 minecraft:gold_block
fill 430 279 635 430 280 635 minecraft:gold_block
fill 431 279 614 432 280 615 minecraft:gold_block
fill 431 279 621 442 279 621 minecraft:gold_block
fill 431 279 627 436 279 627 minecraft:gold_block
fill 431 279 633 432 280 634 minecraft:gold_block
fill 432 279 616 434 280 616 minecraft:gold_block
fill 432 279 632 434 280 632 minecraft:gold_block
fill 433 279 615 433 280 615 minecraft:gold_block
fill 433 279 617 435 279 617 minecraft:gold_block
fill 433 279 622 434 279 622 minecraft:gold_block
fill 433 279 626 443 279 626 minecraft:gold_block
fill 433 279 631 435 279 631 minecraft:gold_block
fill 433 279 633 433 280 633 minecraft:gold_block
fill 434 279 618 448 279 618 minecraft:gold_block
fill 434 279 630 448 279 630 minecraft:gold_block
fill 435 279 610 435 280 610 minecraft:gold_block
fill 435 279 619 442 279 619 minecraft:gold_block
fill 435 279 629 436 279 629 minecraft:gold_block
fill 435 279 638 435 280 638 minecraft:gold_block
fill 436 279 611 436 280 615 minecraft:gold_block
fill 436 279 633 436 280 637 minecraft:gold_block
fill 437 279 612 437 279 617 minecraft:gold_block
fill 437 279 631 437 279 636 minecraft:gold_block
fill 438 279 614 438 279 617 minecraft:gold_block
fill 438 279 622 439 279 624 minecraft:gold_block
fill 438 279 631 438 279 634 minecraft:gold_block
fill 439 279 616 445 279 617 minecraft:gold_block
fill 439 279 631 445 279 632 minecraft:gold_block
fill 440 279 612 442 279 615 minecraft:gold_block
fill 440 279 622 449 279 622 minecraft:gold_block
fill 440 279 627 443 279 629 minecraft:gold_block
fill 440 279 633 442 279 636 minecraft:gold_block
fill 441 279 608 441 280 611 minecraft:gold_block
fill 441 279 637 441 280 640 minecraft:gold_block
fill 443 279 623 453 279 625 minecraft:gold_block
fill 444 279 614 446 279 615 minecraft:gold_block
fill 444 279 629 447 279 629 minecraft:gold_block
fill 444 279 633 446 279 634 minecraft:gold_block
fill 445 279 612 446 280 613 minecraft:gold_block
fill 445 279 635 446 280 636 minecraft:gold_block
fill 446 279 611 446 280 611 minecraft:gold_block
fill 446 279 619 447 279 621 minecraft:gold_block
fill 446 279 637 446 280 637 minecraft:gold_block
fill 447 279 610 447 280 610 minecraft:gold_block
fill 447 279 617 449 279 617 minecraft:gold_block
fill 447 279 626 449 279 628 minecraft:gold_block
fill 447 279 631 449 279 631 minecraft:gold_block
fill 447 279 638 447 280 638 minecraft:gold_block
fill 448 279 616 450 280 616 minecraft:gold_block
fill 448 279 620 451 279 621 minecraft:gold_block
fill 448 279 632 450 280 632 minecraft:gold_block
fill 449 279 615 451 280 615 minecraft:gold_block
fill 449 279 633 451 280 633 minecraft:gold_block
fill 450 279 614 451 280 614 minecraft:gold_block
fill 450 279 619 454 280 619 minecraft:gold_block
fill 450 279 627 451 279 629 minecraft:gold_block
fill 450 279 634 451 280 634 minecraft:gold_block
fill 452 279 613 452 280 613 minecraft:gold_block
fill 452 279 620 453 280 620 minecraft:gold_block
fill 452 279 628 453 280 629 minecraft:gold_block
fill 452 279 635 452 280 635 minecraft:gold_block
fill 454 279 624 457 280 624 minecraft:gold_block
fill 454 279 629 454 280 629 minecraft:gold_block
fill 455 279 618 455 280 618 minecraft:gold_block
fill 455 279 630 455 280 630 minecraft:gold_block
fill 424 280 605 424 280 645 minecraft:white_concrete
fill 425 280 605 426 280 623 minecraft:white_concrete
fill 425 280 624 429 280 624 minecraft:gold_block
fill 425 280 625 426 280 645 minecraft:white_concrete
fill 427 280 605 429 280 617 minecraft:white_concrete
fill 427 280 619 427 280 623 minecraft:white_concrete
fill 427 280 625 427 280 629 minecraft:white_concrete
fill 427 280 631 429 280 645 minecraft:white_concrete
fill 428 280 618 433 280 618 minecraft:white_concrete
fill 428 280 620 428 280 623 minecraft:white_concrete
fill 428 280 625 428 280 628 minecraft:white_concrete
fill 428 280 630 433 280 630 minecraft:white_concrete
fill 429 280 620 430 280 620 minecraft:gold_block
fill 429 280 621 430 280 622 minecraft:white_concrete
fill 429 280 623 433 280 623 minecraft:gold_block
fill 429 280 625 433 280 625 minecraft:gold_block
fill 429 280 626 430 280 627 minecraft:white_concrete
fill 429 280 628 430 280 628 minecraft:gold_block
fill 430 280 605 434 280 612 minecraft:white_concrete
fill 430 280 614 430 280 617 minecraft:white_concrete
fill 430 280 624 433 280 624 minecraft:white_concrete
fill 430 280 631 430 280 634 minecraft:white_concrete
fill 430 280 636 434 280 645 minecraft:white_concrete
fill 431 280 613 435 280 613 minecraft:white_concrete
fill 431 280 616 431 280 617 minecraft:white_concrete
fill 431 280 620 433 280 620 minecraft:white_concrete
fill 431 280 621 432 280 621 minecraft:gold_block
fill 431 280 622 432 280 622 minecraft:white_concrete
fill 431 280 626 432 280 626 minecraft:white_concrete
fill 431 280 627 432 280 627 minecraft:gold_block
fill 431 280 628 433 280 628 minecraft:white_concrete
fill 431 280 631 431 280 632 minecraft:white_concrete
fill 431 280 635 435 280 635 minecraft:white_concrete
setblock 432 280 617 minecraft:white_concrete
setblock 432 280 631 minecraft:white_concrete
fill 433 280 614 435 280 614 minecraft:white_concrete
setblock 433 280 617 minecraft:gold_block
fill 433 280 619 439 280 619 minecraft:white_concrete
setblock 433 280 621 minecraft:white_concrete
setblock 433 280 622 minecraft:gold_block
setblock 433 280 626 minecraft:gold_block
fill 433 280 627 435 280 627 minecraft:white_concrete
fill 433 280 629 435 280 629 minecraft:white_concrete
setblock 433 280 631 minecraft:gold_block
fill 433 280 634 435 280 634 minecraft:white_concrete
fill 434 280 615 435 280 615 minecraft:white_concrete
setblock 434 280 617 minecraft:white_concrete
setblock 434 280 618 minecraft:gold_block
fill 434 280 620 435 280 620 minecraft:gold_block
fill 434 280 621 434 280 625 minecraft:pearlescent_froglight
fill 434 280 626 435 280 626 minecraft:white_concrete
fill 434 280 628 435 280 628 minecraft:gold_block
setblock 434 280 630 minecraft:gold_block
setblock 434 280 631 minecraft:white_concrete
fill 434 280 633 435 280 633 minecraft:white_concrete
fill 435 280 605 440 280 609 minecraft:white_concrete
fill 435 280 611 435 280 612 minecraft:white_concrete
fill 435 280 616 438 280 616 minecraft:white_concrete
setblock 435 280 617 minecraft:gold_block
fill 435 280 618 436 280 618 minecraft:white_concrete
fill 435 280 621 442 280 621 minecraft:pearlescent_froglight
fill 435 280 622 437 280 624 minecraft:white_concrete
fill 435 280 625 439 280 625 minecraft:pearlescent_froglight
setblock 435 280 630 minecraft:white_concrete
setblock 435 280 631 minecraft:gold_block
fill 435 280 632 438 280 632 minecraft:white_concrete
fill 435 280 636 435 280 637 minecraft:white_concrete
fill 435 280 639 440 280 645 minecraft:white_concrete
fill 436 280 610 440 280 610 minecraft:white_concrete
setblock 436 280 617 minecraft:white_concrete
fill 436 280 620 440 280 620 minecraft:white_concrete
fill 436 280 626 436 280 630 minecraft:pearlescent_froglight
setblock 436 280 631 minecraft:white_concrete
fill 436 280 638 440 280 638 minecraft:white_concrete
fill 437 280 611 440 280 611 minecraft:white_concrete
fill 437 280 612 437 280 613 minecraft:gold_block
fill 437 280 614 437 280 615 minecraft:white_concrete
fill 437 280 617 437 280 618 minecraft:gold_block
fill 437 280 626 443 280 626 minecraft:pearlescent_froglight
fill 437 280 627 439 280 629 minecraft:white_concrete
fill 437 280 630 440 280 630 minecraft:pearlescent_froglight
setblock 437 280 631 minecraft:gold_block
fill 437 280 633 437 280 634 minecraft:white_concrete
fill 437 280 635 437 280 636 minecraft:gold_block
fill 437 280 637 440 280 637 minecraft:white_concrete
fill 438 280 612 439 280 613 minecraft:white_concrete
fill 438 280 614 438 280 615 minecraft:gold_block
fill 438 280 617 439 280 618 minecraft:white_concrete
fill 438 280 622 439 280 624 minecraft:pearlescent_froglight
fill 438 280 631 439 280 631 minecraft:white_concrete
fill 438 280 633 438 280 634 minecraft:gold_block
fill 438 280 635 439 280 636 minecraft:white_concrete
fill 439 280 614 439 280 615 minecraft:white_concrete
fill 439 280 616 440 280 616 minecraft:gold_block
fill 439 280 632 440 280 632 minecraft:gold_block
fill 439 280 633 439 280 634 minecraft:white_concrete
fill 440 280 612 440 280 615 minecraft:gold_block
fill 440 280 617 440 280 619 minecraft:gold_block
fill 440 280 622 446 280 622 minecraft:pearlescent_froglight
fill 440 280 627 440 280 629 minecraft:pearlescent_froglight
setblock 440 280 631 minecraft:gold_block
fill 440 280 633 440 280 636 minecraft:gold_block
fill 441 280 605 464 280 607 minecraft:white_concrete
fill 441 280 612 442 280 612 minecraft:gold_block
fill 441 280 613 441 280 619 minecraft:white_concrete
fill 441 280 620 442 280 620 minecraft:pearlescent_froglight
fill 441 280 627 441 280 628 minecraft:pearlescent_froglight
fill 441 280 629 441 280 635 minecraft:white_concrete
fill 441 280 636 442 280 636 minecraft:gold_block
fill 441 280 641 464 280 645 minecraft:white_concrete
fill 442 280 608 445 280 611 minecraft:white_concrete
fill 442 280 613 442 280 617 minecraft:gold_block
fill 442 280 618 442 280 619 minecraft:pearlescent_froglight
fill 442 280 627 443 280 627 minecraft:pearlescent_froglight
setblock 442 280 628 minecraft:white_concrete
fill 442 280 629 442 280 635 minecraft:gold_block
fill 442 280 637 445 280 640 minecraft:white_concrete
fill 443 280 612 443 280 615 minecraft:white_concrete
setblock 443 280 616 minecraft:gold_block
fill 443 280 617 444 280 617 minecraft:white_concrete
fill 443 280 618 446 280 618 minecraft:pearlescent_froglight
fill 443 280 619 445 280 621 minecraft:white_concrete
fill 443 280 623 444 280 625 minecraft:pearlescent_froglight
fill 443 280 628 443 280 629 minecraft:pearlescent_froglight
fill 443 280 630 444 280 631 minecraft:white_concrete
setblock 443 280 632 minecraft:gold_block
fill 443 280 633 443 280 636 minecraft:white_concrete
fill 444 280 612 444 280 613 minecraft:white_concrete
fill 444 280 614 444 280 615 minecraft:gold_block
fill 444 280 616 447 280 616 minecraft:white_concrete
fill 444 280 626 446 280 628 minecraft:white_concrete
fill 444 280 629 447 280 629 minecraft:pearlescent_froglight
fill 444 280 632 447 280 632 minecraft:white_concrete
fill 444 280 633 444 280 634 minecraft:gold_block
fill 444 280 635 444 280 636 minecraft:white_concrete
fill 445 280 614 445 280 615 minecraft:white_concrete
setblock 445 280 617 minecraft:gold_block
setblock 445 280 623 minecraft:white_concrete
fill 445 280 624 445 280 625 minecraft:pearlescent_froglight
fill 445 280 630 445 280 631 minecraft:gold_block
fill 445 280 633 445 280 634 minecraft:white_concrete
fill 446 280 608 446 280 610 minecraft:white_concrete
fill 446 280 614 446 280 615 minecraft:gold_block
setblock 446 280 617 minecraft:white_concrete
fill 446 280 619 446 280 621 minecraft:pearlescent_froglight
fill 446 280 623 453 280 623 minecraft:gold_block
fill 446 280 624 452 280 624 minecraft:white_concrete
fill 446 280 625 447 280 625 minecraft:pearlescent_froglight
fill 446 280 630 446 280 631 minecraft:white_concrete
fill 446 280 633 446 280 634 minecraft:gold_block
fill 446 280 638 446 280 640 minecraft:white_concrete
fill 447 280 608 464 280 609 minecraft:white_concrete
fill 447 280 611 448 280 615 minecraft:white_concrete
setblock 447 280 617 minecraft:gold_block
fill 447 280 618 447 280 619 minecraft:white_concrete
fill 447 280 620 448 280 620 minecraft:gold_block
fill 447 280 621 448 280 622 minecraft:white_concrete
fill 447 280 626 447 280 628 minecraft:pearlescent_froglight
setblock 447 280 630 minecraft:white_concrete
setblock 447 280 631 minecraft:gold_block
fill 447 280 633 448 280 637 minecraft:white_concrete
fill 447 280 639 464 280 640 minecraft:white_concrete
fill 448 280 610 464 280 610 minecraft:white_concrete
setblock 448 280 617 minecraft:white_concrete
setblock 448 280 618 minecraft:gold_block
fill 448 280 619 449 280 619 minecraft:white_concrete
fill 448 280 625 453 280 625 minecraft:gold_block
fill 448 280 626 448 280 627 minecraft:white_concrete
setblock 448 280 628 minecraft:gold_block
fill 448 280 629 449 280 629 minecraft:white_concrete
setblock 448 280 630 minecraft:gold_block
setblock 448 280 631 minecraft:white_concrete
fill 448 280 638 464 280 638 minecraft:white_concrete
fill 449 280 611 449 280 614 minecraft:white_concrete
setblock 449 280 617 minecraft:gold_block
fill 449 280 618 454 280 618 minecraft:white_concrete
fill 449 280 620 449 280 621 minecraft:white_concrete
setblock 449 280 622 minecraft:gold_block
setblock 449 280 626 minecraft:gold_block
fill 449 280 627 449 280 628 minecraft:white_concrete
fill 449 280 630 454 280 630 minecraft:white_concrete
setblock 449 280 631 minecraft:gold_block
fill 449 280 634 449 280 637 minecraft:white_concrete
fill 450 280 611 451 280 613 minecraft:white_concrete
fill 450 280 617 464 280 617 minecraft:white_concrete
fill 450 280 620 451 280 620 minecraft:white_concrete
fill 450 280 621 451 280 621 minecraft:gold_block
fill 450 280 622 464 280 622 minecraft:white_concrete
fill 450 280 626 464 280 626 minecraft:white_concrete
fill 450 280 627 451 280 627 minecraft:gold_block
fill 450 280 628 451 280 628 minecraft:white_concrete
fill 450 280 629 451 280 629 minecraft:gold_block
fill 450 280 631 464 280 631 minecraft:white_concrete
fill 450 280 635 451 280 637 minecraft:white_concrete
fill 451 280 616 464 280 616 minecraft:white_concrete
fill 451 280 632 464 280 632 minecraft:white_concrete
fill 452 280 611 464 280 612 minecraft:white_concrete
fill 452 280 614 464 280 615 minecraft:white_concrete
fill 452 280 621 464 280 621 minecraft:white_concrete
fill 452 280 627 464 280 627 minecraft:white_concrete
fill 452 280 633 464 280 634 minecraft:white_concrete
fill 452 280 636 464 280 637 minecraft:white_concrete
fill 453 280 613 464 280 613 minecraft:white_concrete
setblock 453 280 624 minecraft:gold_block
fill 453 280 635 464 280 635 minecraft:white_concrete
fill 454 280 620 464 280 620 minecraft:white_concrete
fill 454 280 623 464 280 623 minecraft:white_concrete
fill 454 280 625 464 280 625 minecraft:white_concrete
fill 454 280 628 464 280 628 minecraft:white_concrete
fill 455 280 619 464 280 619 minecraft:white_concrete
fill 455 280 629 464 280 629 minecraft:white_concrete
fill 456 280 618 464 280 618 minecraft:white_concrete
fill 456 280 630 464 280 630 minecraft:white_concrete
fill 458 280 624 464 280 624 minecraft:white_concrete
setblock 426 282 607 minecraft:light[level=13]
setblock 426 282 615 minecraft:light[level=13]
setblock 426 282 623 minecraft:light[level=13]
setblock 426 282 631 minecraft:light[level=13]
setblock 426 282 639 minecraft:light[level=13]
setblock 434 282 607 minecraft:light[level=13]
setblock 434 282 615 minecraft:light[level=13]
setblock 434 282 623 minecraft:light[level=13]
setblock 434 282 631 minecraft:light[level=13]
setblock 434 282 639 minecraft:light[level=13]
setblock 442 282 607 minecraft:light[level=13]
setblock 442 282 615 minecraft:light[level=13]
setblock 442 282 631 minecraft:light[level=13]
setblock 442 282 639 minecraft:light[level=13]
setblock 450 282 607 minecraft:light[level=13]
setblock 450 282 615 minecraft:light[level=13]
setblock 450 282 623 minecraft:light[level=13]
setblock 450 282 631 minecraft:light[level=13]
setblock 450 282 639 minecraft:light[level=13]
setblock 458 282 607 minecraft:light[level=13]
setblock 458 282 615 minecraft:light[level=13]
setblock 458 282 623 minecraft:light[level=13]
setblock 458 282 631 minecraft:light[level=13]
setblock 458 282 639 minecraft:light[level=13]
fill 423 284 609 423 289 609 minecraft:pearlescent_froglight
fill 423 284 617 423 289 617 minecraft:pearlescent_froglight
fill 423 284 625 423 289 625 minecraft:pearlescent_froglight
fill 423 284 633 423 289 633 minecraft:pearlescent_froglight
fill 423 284 641 423 289 641 minecraft:pearlescent_froglight
fill 424 284 611 424 300 612 minecraft:quartz_block
fill 424 284 619 424 300 620 minecraft:quartz_block
fill 424 284 627 424 300 628 minecraft:quartz_block
fill 424 284 635 424 300 636 minecraft:quartz_block
fill 424 284 643 424 300 644 minecraft:quartz_block
fill 425 284 605 426 300 605 minecraft:quartz_block
fill 426 284 646 426 289 646 minecraft:pearlescent_froglight
fill 430 284 604 430 289 604 minecraft:pearlescent_froglight
fill 430 284 645 431 300 645 minecraft:quartz_block
fill 433 284 605 434 300 605 minecraft:quartz_block
fill 434 284 646 434 289 646 minecraft:pearlescent_froglight
fill 438 284 604 438 289 604 minecraft:pearlescent_froglight
fill 438 284 645 439 300 645 minecraft:quartz_block
fill 441 284 605 442 300 605 minecraft:quartz_block
fill 442 284 646 442 289 646 minecraft:pearlescent_froglight
fill 446 284 604 446 289 604 minecraft:pearlescent_froglight
fill 446 284 645 447 300 645 minecraft:quartz_block
fill 449 284 605 450 300 605 minecraft:quartz_block
fill 450 284 646 450 289 646 minecraft:pearlescent_froglight
fill 454 284 604 454 289 604 minecraft:pearlescent_froglight
fill 454 284 645 455 300 645 minecraft:quartz_block
fill 457 284 605 458 300 605 minecraft:quartz_block
fill 458 284 646 458 289 646 minecraft:pearlescent_froglight
fill 462 284 604 462 289 604 minecraft:pearlescent_froglight
fill 462 284 645 463 300 645 minecraft:quartz_block
fill 464 284 606 464 300 607 minecraft:quartz_block
fill 464 284 614 464 300 615 minecraft:quartz_block
fill 464 284 622 464 300 623 minecraft:quartz_block
fill 464 284 630 464 300 631 minecraft:quartz_block
fill 464 284 638 464 300 639 minecraft:quartz_block
fill 465 284 609 465 289 609 minecraft:pearlescent_froglight
fill 465 284 617 465 289 617 minecraft:pearlescent_froglight
fill 465 284 625 465 289 625 minecraft:pearlescent_froglight
fill 465 284 633 465 289 633 minecraft:pearlescent_froglight
fill 465 284 641 465 289 641 minecraft:pearlescent_froglight
fill 431 285 616 432 286 616 minecraft:white_concrete
fill 423 290 609 423 297 609 minecraft:white_concrete
fill 423 290 617 423 297 617 minecraft:white_concrete
fill 423 290 625 423 297 625 minecraft:white_concrete
fill 423 290 633 423 297 633 minecraft:white_concrete
fill 423 290 641 423 297 641 minecraft:white_concrete
setblock 426 290 607 minecraft:light[level=13]
setblock 426 290 615 minecraft:light[level=13]
setblock 426 290 623 minecraft:light[level=13]
setblock 426 290 631 minecraft:light[level=13]
setblock 426 290 639 minecraft:light[level=13]
fill 426 290 646 426 297 646 minecraft:white_concrete
fill 430 290 604 430 297 604 minecraft:white_concrete
fill 432 290 635 433 291 636 minecraft:white_concrete
fill 433 290 637 433 291 637 minecraft:white_concrete
setblock 434 290 607 minecraft:light[level=13]
setblock 434 290 615 minecraft:light[level=13]
setblock 434 290 623 minecraft:light[level=13]
setblock 434 290 631 minecraft:light[level=13]
setblock 434 290 639 minecraft:light[level=13]
fill 434 290 646 434 297 646 minecraft:white_concrete
fill 438 290 604 438 297 604 minecraft:white_concrete
setblock 442 290 607 minecraft:light[level=13]
setblock 442 290 615 minecraft:light[level=13]
setblock 442 290 623 minecraft:light[level=13]
setblock 442 290 631 minecraft:light[level=13]
setblock 442 290 639 minecraft:light[level=13]
fill 442 290 646 442 297 646 minecraft:white_concrete
fill 446 290 604 446 297 604 minecraft:white_concrete
setblock 450 290 607 minecraft:light[level=13]
setblock 450 290 615 minecraft:light[level=13]
setblock 450 290 623 minecraft:light[level=13]
setblock 450 290 631 minecraft:light[level=13]
setblock 450 290 639 minecraft:light[level=13]
fill 450 290 646 450 297 646 minecraft:white_concrete
fill 454 290 604 454 297 604 minecraft:white_concrete
setblock 458 290 607 minecraft:light[level=13]
setblock 458 290 615 minecraft:light[level=13]
setblock 458 290 623 minecraft:light[level=13]
setblock 458 290 631 minecraft:light[level=13]
setblock 458 290 639 minecraft:light[level=13]
fill 458 290 646 458 297 646 minecraft:white_concrete
fill 462 290 604 462 297 604 minecraft:white_concrete
fill 465 290 609 465 297 609 minecraft:white_concrete
fill 465 290 617 465 297 617 minecraft:white_concrete
fill 465 290 625 465 297 625 minecraft:white_concrete
fill 465 290 633 465 297 633 minecraft:white_concrete
fill 465 290 641 465 297 641 minecraft:white_concrete
fill 424 294 605 424 295 610 minecraft:quartz_block
fill 424 294 613 425 294 618 minecraft:quartz_block
fill 424 294 621 425 294 626 minecraft:quartz_block
fill 424 294 629 425 294 634 minecraft:quartz_block
fill 424 294 637 425 294 642 minecraft:quartz_block
fill 424 294 645 429 295 645 minecraft:quartz_block
fill 425 294 606 425 294 612 minecraft:quartz_block
fill 425 294 619 425 294 620 minecraft:quartz_block
fill 425 294 627 425 294 628 minecraft:quartz_block
fill 425 294 635 425 294 636 minecraft:quartz_block
fill 425 294 643 425 294 644 minecraft:quartz_block
fill 426 294 606 463 294 606 minecraft:quartz_block
fill 426 294 644 464 294 644 minecraft:quartz_block
fill 427 294 605 432 295 605 minecraft:quartz_block
fill 432 294 645 437 295 645 minecraft:quartz_block
fill 435 294 605 440 295 605 minecraft:quartz_block
fill 440 294 645 445 295 645 minecraft:quartz_block
fill 443 294 605 448 295 605 minecraft:quartz_block
fill 448 294 645 453 295 645 minecraft:quartz_block
fill 451 294 605 456 295 605 minecraft:quartz_block
fill 456 294 645 461 295 645 minecraft:quartz_block
fill 459 294 605 464 295 605 minecraft:quartz_block
fill 463 294 607 463 294 643 minecraft:quartz_block
fill 464 294 608 464 295 613 minecraft:quartz_block
fill 464 294 616 464 295 621 minecraft:quartz_block
fill 464 294 624 464 295 629 minecraft:quartz_block
fill 464 294 632 464 295 637 minecraft:quartz_block
fill 464 294 640 464 295 643 minecraft:quartz_block
fill 464 294 645 464 295 645 minecraft:quartz_block
fill 424 295 613 424 295 618 minecraft:quartz_block
fill 424 295 621 424 295 626 minecraft:quartz_block
fill 424 295 629 424 295 634 minecraft:quartz_block
fill 424 295 637 424 295 642 minecraft:quartz_block
setblock 464 295 644 minecraft:quartz_block
fill 434 296 621 434 297 622 minecraft:gold_block
fill 423 298 609 423 300 609 minecraft:pearlescent_froglight
fill 423 298 617 423 300 617 minecraft:pearlescent_froglight
fill 423 298 625 423 300 625 minecraft:pearlescent_froglight
fill 423 298 633 423 300 633 minecraft:pearlescent_froglight
fill 423 298 641 423 300 641 minecraft:pearlescent_froglight
setblock 426 298 607 minecraft:light[level=13]
setblock 426 298 615 minecraft:light[level=13]
setblock 426 298 623 minecraft:light[level=13]
setblock 426 298 631 minecraft:light[level=13]
setblock 426 298 639 minecraft:light[level=13]
fill 426 298 646 426 300 646 minecraft:pearlescent_froglight
fill 430 298 604 430 300 604 minecraft:pearlescent_froglight
setblock 434 298 607 minecraft:light[level=13]
setblock 434 298 615 minecraft:light[level=13]
setblock 434 298 623 minecraft:light[level=13]
setblock 434 298 631 minecraft:light[level=13]
setblock 434 298 639 minecraft:light[level=13]
fill 434 298 646 434 300 646 minecraft:pearlescent_froglight
fill 438 298 604 438 300 604 minecraft:pearlescent_froglight
fill 440 298 640 440 299 642 minecraft:black_concrete
fill 441 298 641 441 299 641 minecraft:black_concrete
setblock 442 298 607 minecraft:light[level=13]
setblock 442 298 615 minecraft:light[level=13]
setblock 442 298 623 minecraft:light[level=13]
setblock 442 298 631 minecraft:light[level=13]
setblock 442 298 639 minecraft:light[level=13]
fill 442 298 646 442 300 646 minecraft:pearlescent_froglight
fill 446 298 604 446 300 604 minecraft:pearlescent_froglight
setblock 450 298 607 minecraft:light[level=13]
setblock 450 298 615 minecraft:light[level=13]
setblock 450 298 623 minecraft:light[level=13]
setblock 450 298 631 minecraft:light[level=13]
setblock 450 298 639 minecraft:light[level=13]
fill 450 298 646 450 300 646 minecraft:pearlescent_froglight
fill 454 298 604 454 300 604 minecraft:pearlescent_froglight
setblock 458 298 607 minecraft:light[level=13]
setblock 458 298 615 minecraft:light[level=13]
setblock 458 298 623 minecraft:light[level=13]
setblock 458 298 631 minecraft:light[level=13]
setblock 458 298 639 minecraft:light[level=13]
fill 458 298 646 458 300 646 minecraft:pearlescent_froglight
fill 462 298 604 462 300 604 minecraft:pearlescent_froglight
fill 465 298 609 465 300 609 minecraft:pearlescent_froglight
fill 465 298 617 465 300 617 minecraft:pearlescent_froglight
fill 465 298 625 465 300 625 minecraft:pearlescent_froglight
fill 465 298 633 465 300 633 minecraft:pearlescent_froglight
fill 465 298 641 465 300 641 minecraft:pearlescent_froglight
fill 423 301 609 423 307 609 minecraft:white_concrete
fill 423 301 617 423 307 617 minecraft:white_concrete
fill 423 301 625 423 307 625 minecraft:white_concrete
fill 423 301 633 423 307 633 minecraft:white_concrete
fill 423 301 641 423 307 641 minecraft:white_concrete
fill 426 301 646 426 307 646 minecraft:white_concrete
fill 430 301 604 430 307 604 minecraft:white_concrete
fill 434 301 646 434 307 646 minecraft:white_concrete
fill 438 301 604 438 307 604 minecraft:white_concrete
fill 442 301 646 442 307 646 minecraft:white_concrete
fill 446 301 604 446 307 604 minecraft:white_concrete
fill 450 301 646 450 307 646 minecraft:white_concrete
fill 454 301 604 454 307 604 minecraft:white_concrete
fill 458 301 646 458 307 646 minecraft:white_concrete
fill 462 301 604 462 307 604 minecraft:white_concrete
fill 465 301 609 465 307 609 minecraft:white_concrete
fill 465 301 617 465 307 617 minecraft:white_concrete
fill 465 301 625 465 307 625 minecraft:white_concrete
fill 465 301 633 465 307 633 minecraft:white_concrete
fill 465 301 641 465 307 641 minecraft:white_concrete
