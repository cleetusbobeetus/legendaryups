fill 297 209 308 297 210 308 minecraft:iron_block
fill 297 209 310 297 210 310 minecraft:iron_block
fill 297 209 312 297 210 312 minecraft:iron_block
fill 297 209 314 297 210 314 minecraft:iron_block
fill 297 209 316 297 210 316 minecraft:iron_block
fill 298 209 277 298 210 277 minecraft:iron_block
fill 298 209 279 298 210 279 minecraft:iron_block
fill 298 209 307 298 210 307 minecraft:iron_block
fill 298 209 309 298 210 309 minecraft:iron_block
fill 298 209 311 298 210 311 minecraft:iron_block
fill 298 209 313 298 210 313 minecraft:iron_block
fill 298 209 315 298 210 315 minecraft:iron_block
fill 298 209 317 298 210 317 minecraft:light_gray_concrete
fill 299 209 276 299 210 276 minecraft:iron_block
fill 299 209 278 299 210 278 minecraft:iron_block
fill 299 209 308 299 210 308 minecraft:iron_block
fill 299 209 310 299 210 310 minecraft:iron_block
fill 299 209 312 299 210 312 minecraft:iron_block
fill 299 209 314 299 210 314 minecraft:iron_block
fill 299 209 316 299 210 316 minecraft:iron_block
fill 300 209 277 300 210 277 minecraft:iron_block
fill 300 209 279 300 210 279 minecraft:iron_block
fill 300 209 307 300 210 307 minecraft:iron_block
fill 300 209 309 300 210 309 minecraft:iron_block
fill 300 209 311 300 210 311 minecraft:iron_block
fill 300 209 313 300 210 313 minecraft:iron_block
fill 300 209 315 300 210 315 minecraft:iron_block
fill 301 209 276 301 210 276 minecraft:iron_block
fill 301 209 278 301 210 278 minecraft:iron_block
setblock 301 209 286 minecraft:light[level=15]
setblock 301 209 294 minecraft:light[level=15]
setblock 301 209 302 minecraft:light[level=15]
fill 301 209 308 301 210 308 minecraft:iron_block
fill 301 209 310 301 210 310 minecraft:iron_block
fill 301 209 312 301 210 312 minecraft:iron_block
fill 301 209 314 301 210 314 minecraft:iron_block
fill 301 209 316 301 210 316 minecraft:iron_block
fill 302 209 277 302 210 277 minecraft:iron_block
fill 302 209 279 302 210 279 minecraft:iron_block
fill 302 209 307 302 210 307 minecraft:iron_block
fill 302 209 309 302 210 309 minecraft:iron_block
fill 302 209 311 302 210 311 minecraft:iron_block
fill 302 209 313 302 210 313 minecraft:iron_block
fill 302 209 315 302 210 315 minecraft:iron_block
fill 303 209 276 303 210 276 minecraft:iron_block
fill 303 209 278 303 210 278 minecraft:iron_block
fill 304 209 277 304 210 277 minecraft:iron_block
fill 304 209 279 304 210 279 minecraft:iron_block
fill 307 209 317 307 210 317 minecraft:light_gray_concrete
fill 309 209 275 309 229 275 minecraft:light_gray_concrete
setblock 309 209 278 minecraft:light[level=15]
setblock 309 209 286 minecraft:light[level=15]
setblock 309 209 294 minecraft:light[level=15]
setblock 309 209 302 minecraft:light[level=15]
setblock 309 209 310 minecraft:light[level=15]
fill 311 209 317 311 229 317 minecraft:light_gray_concrete
fill 317 209 275 317 210 275 minecraft:light_gray_concrete
setblock 317 209 278 minecraft:light[level=15]
setblock 317 209 286 minecraft:light[level=15]
setblock 317 209 294 minecraft:light[level=15]
setblock 317 209 302 minecraft:light[level=15]
setblock 317 209 310 minecraft:light[level=15]
fill 323 209 317 324 229 317 minecraft:light_gray_concrete
fill 324 209 278 324 210 278 minecraft:light_gray_concrete
fill 324 209 280 324 223 280 minecraft:light_gray_concrete
fill 324 209 302 324 229 303 minecraft:light_gray_concrete
fill 324 209 313 324 229 313 minecraft:light_gray_concrete
setblock 283 210 278 minecraft:iron_block
setblock 283 210 288 minecraft:iron_block
setblock 283 210 298 minecraft:iron_block
setblock 283 210 308 minecraft:iron_block
fill 284 210 311 284 210 313 minecraft:iron_block
fill 285 210 311 285 210 314 minecraft:gray_concrete
setblock 285 210 316 minecraft:iron_block
setblock 286 210 278 minecraft:gray_concrete
setblock 286 210 281 minecraft:gray_concrete
fill 286 210 310 288 210 310 minecraft:gray_concrete
setblock 286 210 314 minecraft:gray_concrete
fill 287 210 282 288 210 282 minecraft:gray_concrete
setblock 288 210 314 minecraft:gray_concrete
setblock 289 210 276 minecraft:iron_block
setblock 289 210 278 minecraft:gray_concrete
setblock 289 210 281 minecraft:gray_concrete
fill 289 210 311 289 210 313 minecraft:gray_concrete
fill 290 210 279 290 210 280 minecraft:gray_concrete
fill 298 210 275 299 210 275 minecraft:light_gray_concrete
setblock 300 210 275 minecraft:sea_lantern
setblock 305 210 316 minecraft:iron_block
setblock 309 210 276 minecraft:iron_block
setblock 315 210 316 minecraft:iron_block
setblock 319 210 276 minecraft:iron_block
setblock 323 210 282 minecraft:iron_block
setblock 323 210 292 minecraft:iron_block
setblock 323 210 302 minecraft:iron_block
setblock 323 210 312 minecraft:iron_block
fill 282 211 280 282 229 280 minecraft:light_gray_concrete
fill 282 211 281 282 211 284 minecraft:pearlescent_froglight
fill 282 211 287 282 229 290 minecraft:light_gray_concrete
fill 282 211 291 282 211 294 minecraft:pearlescent_froglight
fill 282 211 295 282 229 300 minecraft:light_gray_concrete
fill 282 211 301 282 211 304 minecraft:pearlescent_froglight
fill 282 211 309 282 229 310 minecraft:light_gray_concrete
fill 282 211 311 282 211 314 minecraft:pearlescent_froglight
fill 282 211 315 282 229 317 minecraft:light_gray_concrete
fill 284 211 275 284 229 275 minecraft:light_gray_concrete
fill 285 211 275 288 211 275 minecraft:pearlescent_froglight
setblock 285 211 278 minecraft:light[level=12]
setblock 285 211 285 minecraft:light[level=12]
setblock 285 211 292 minecraft:light[level=12]
setblock 285 211 299 minecraft:light[level=12]
setblock 285 211 306 minecraft:light[level=12]
fill 285 211 312 285 217 312 minecraft:iron_block
setblock 285 211 313 minecraft:light[level=12]
fill 285 211 317 285 229 317 minecraft:light_gray_concrete
fill 286 211 317 289 211 317 minecraft:pearlescent_froglight
fill 289 211 275 294 221 275 minecraft:light_gray_concrete
setblock 290 211 307 minecraft:pearlescent_froglight
setblock 290 211 309 minecraft:pearlescent_froglight
setblock 290 211 311 minecraft:pearlescent_froglight
setblock 290 211 313 minecraft:pearlescent_froglight
setblock 290 211 315 minecraft:pearlescent_froglight
fill 290 211 317 292 229 317 minecraft:light_gray_concrete
setblock 291 211 308 minecraft:pearlescent_froglight
setblock 291 211 310 minecraft:pearlescent_froglight
setblock 291 211 312 minecraft:pearlescent_froglight
setblock 291 211 314 minecraft:pearlescent_froglight
setblock 291 211 316 minecraft:pearlescent_froglight
setblock 292 211 278 minecraft:light[level=12]
setblock 292 211 285 minecraft:light[level=12]
setblock 292 211 292 minecraft:light[level=12]
setblock 292 211 299 minecraft:light[level=12]
setblock 292 211 306 minecraft:light[level=12]
setblock 292 211 307 minecraft:pearlescent_froglight
setblock 292 211 309 minecraft:pearlescent_froglight
setblock 292 211 311 minecraft:pearlescent_froglight
setblock 292 211 313 minecraft:pearlescent_froglight
setblock 292 211 315 minecraft:pearlescent_froglight
setblock 293 211 308 minecraft:pearlescent_froglight
setblock 293 211 310 minecraft:pearlescent_froglight
setblock 293 211 312 minecraft:pearlescent_froglight
setblock 293 211 314 minecraft:pearlescent_froglight
setblock 293 211 316 minecraft:pearlescent_froglight
setblock 294 211 307 minecraft:pearlescent_froglight
setblock 294 211 309 minecraft:pearlescent_froglight
setblock 294 211 311 minecraft:pearlescent_froglight
setblock 294 211 313 minecraft:pearlescent_froglight
setblock 294 211 315 minecraft:pearlescent_froglight
fill 295 211 275 298 211 275 minecraft:pearlescent_froglight
setblock 295 211 308 minecraft:pearlescent_froglight
setblock 295 211 310 minecraft:pearlescent_froglight
setblock 295 211 312 minecraft:pearlescent_froglight
setblock 295 211 314 minecraft:pearlescent_froglight
setblock 295 211 316 minecraft:pearlescent_froglight
setblock 296 211 307 minecraft:pearlescent_froglight
setblock 296 211 309 minecraft:pearlescent_froglight
setblock 296 211 311 minecraft:pearlescent_froglight
setblock 296 211 313 minecraft:pearlescent_froglight
setblock 296 211 315 minecraft:pearlescent_froglight
fill 296 211 317 299 211 317 minecraft:pearlescent_froglight
setblock 297 211 308 minecraft:pearlescent_froglight
setblock 297 211 310 minecraft:pearlescent_froglight
setblock 297 211 312 minecraft:pearlescent_froglight
setblock 297 211 314 minecraft:pearlescent_froglight
setblock 297 211 316 minecraft:pearlescent_froglight
setblock 298 211 277 minecraft:pearlescent_froglight
setblock 298 211 279 minecraft:pearlescent_froglight
setblock 298 211 307 minecraft:pearlescent_froglight
setblock 298 211 309 minecraft:pearlescent_froglight
setblock 298 211 311 minecraft:pearlescent_froglight
setblock 298 211 313 minecraft:pearlescent_froglight
setblock 298 211 315 minecraft:pearlescent_froglight
fill 299 211 275 304 214 275 minecraft:light_gray_concrete
setblock 299 211 276 minecraft:pearlescent_froglight
setblock 299 211 278 minecraft:pearlescent_froglight
setblock 299 211 285 minecraft:light[level=12]
setblock 299 211 292 minecraft:light[level=12]
setblock 299 211 299 minecraft:light[level=12]
setblock 299 211 306 minecraft:light[level=12]
setblock 299 211 308 minecraft:pearlescent_froglight
setblock 299 211 310 minecraft:pearlescent_froglight
setblock 299 211 312 minecraft:pearlescent_froglight
setblock 299 211 314 minecraft:pearlescent_froglight
setblock 299 211 316 minecraft:pearlescent_froglight
setblock 300 211 277 minecraft:pearlescent_froglight
setblock 300 211 279 minecraft:pearlescent_froglight
setblock 300 211 307 minecraft:pearlescent_froglight
setblock 300 211 309 minecraft:pearlescent_froglight
setblock 300 211 311 minecraft:pearlescent_froglight
setblock 300 211 313 minecraft:pearlescent_froglight
setblock 300 211 315 minecraft:pearlescent_froglight
fill 300 211 317 301 229 317 minecraft:light_gray_concrete
setblock 301 211 276 minecraft:pearlescent_froglight
setblock 301 211 278 minecraft:pearlescent_froglight
setblock 301 211 308 minecraft:pearlescent_froglight
setblock 301 211 310 minecraft:pearlescent_froglight
setblock 301 211 312 minecraft:pearlescent_froglight
setblock 301 211 314 minecraft:pearlescent_froglight
setblock 301 211 316 minecraft:pearlescent_froglight
setblock 302 211 277 minecraft:pearlescent_froglight
setblock 302 211 279 minecraft:pearlescent_froglight
setblock 302 211 307 minecraft:pearlescent_froglight
setblock 302 211 309 minecraft:pearlescent_froglight
setblock 302 211 311 minecraft:pearlescent_froglight
setblock 302 211 313 minecraft:pearlescent_froglight
setblock 302 211 315 minecraft:pearlescent_froglight
setblock 303 211 276 minecraft:pearlescent_froglight
setblock 303 211 278 minecraft:pearlescent_froglight
setblock 304 211 277 minecraft:pearlescent_froglight
setblock 304 211 279 minecraft:pearlescent_froglight
fill 305 211 275 308 211 275 minecraft:pearlescent_froglight
fill 305 211 317 305 213 317 minecraft:light_gray_concrete
setblock 306 211 278 minecraft:light[level=12]
setblock 306 211 285 minecraft:light[level=12]
setblock 306 211 292 minecraft:light[level=12]
setblock 306 211 299 minecraft:light[level=12]
setblock 306 211 306 minecraft:light[level=12]
setblock 306 211 313 minecraft:light[level=12]
fill 306 211 317 309 211 317 minecraft:pearlescent_froglight
fill 310 211 275 314 220 275 minecraft:light_gray_concrete
fill 310 211 317 310 229 317 minecraft:light_gray_concrete
setblock 313 211 278 minecraft:light[level=12]
setblock 313 211 285 minecraft:light[level=12]
setblock 313 211 292 minecraft:light[level=12]
setblock 313 211 299 minecraft:light[level=12]
setblock 313 211 306 minecraft:light[level=12]
setblock 313 211 313 minecraft:light[level=12]
fill 315 211 275 318 211 275 minecraft:pearlescent_froglight
fill 316 211 317 319 211 317 minecraft:pearlescent_froglight
setblock 320 211 278 minecraft:light[level=12]
setblock 320 211 285 minecraft:light[level=12]
setblock 320 211 292 minecraft:light[level=12]
setblock 320 211 299 minecraft:light[level=12]
setblock 320 211 306 minecraft:light[level=12]
setblock 320 211 313 minecraft:light[level=12]
fill 320 211 317 321 229 317 minecraft:light_gray_concrete
fill 324 211 276 324 211 279 minecraft:pearlescent_froglight
fill 324 211 281 324 229 285 minecraft:light_gray_concrete
fill 324 211 286 324 211 289 minecraft:pearlescent_froglight
fill 324 211 290 324 219 292 minecraft:light_gray_concrete
fill 324 211 294 324 219 295 minecraft:light_gray_concrete
fill 324 211 296 324 211 299 minecraft:pearlescent_froglight
fill 324 211 304 324 229 305 minecraft:light_gray_concrete
fill 324 211 306 324 211 309 minecraft:pearlescent_froglight
fill 324 211 315 324 229 315 minecraft:light_gray_concrete
setblock 324 211 316 minecraft:pearlescent_froglight
fill 282 212 281 282 219 284 minecraft:light_gray_concrete
fill 282 212 291 282 219 294 minecraft:light_gray_concrete
fill 282 212 301 282 219 304 minecraft:light_gray_concrete
fill 282 212 311 282 219 314 minecraft:light_gray_concrete
fill 285 212 275 288 216 275 minecraft:light_gray_concrete
fill 286 212 317 289 219 317 minecraft:light_gray_concrete
fill 290 212 307 290 214 307 minecraft:iron_block
fill 290 212 309 290 214 309 minecraft:iron_block
fill 290 212 311 290 214 311 minecraft:iron_block
fill 290 212 313 290 214 313 minecraft:iron_block
fill 290 212 315 290 214 315 minecraft:iron_block
fill 291 212 308 291 214 308 minecraft:iron_block
fill 291 212 310 291 214 310 minecraft:iron_block
fill 291 212 312 291 214 312 minecraft:iron_block
fill 291 212 314 291 214 314 minecraft:iron_block
fill 291 212 316 291 214 316 minecraft:iron_block
fill 292 212 307 292 214 307 minecraft:iron_block
fill 292 212 309 292 214 309 minecraft:iron_block
fill 292 212 311 292 214 311 minecraft:iron_block
fill 292 212 313 292 214 313 minecraft:iron_block
fill 292 212 315 292 214 315 minecraft:iron_block
fill 293 212 308 293 214 308 minecraft:iron_block
fill 293 212 310 293 214 310 minecraft:iron_block
fill 293 212 312 293 214 312 minecraft:iron_block
fill 293 212 314 293 214 314 minecraft:iron_block
fill 293 212 316 293 214 316 minecraft:iron_block
fill 294 212 307 294 214 307 minecraft:iron_block
fill 294 212 309 294 214 309 minecraft:iron_block
fill 294 212 311 294 214 311 minecraft:iron_block
fill 294 212 313 294 214 313 minecraft:iron_block
fill 294 212 315 294 214 315 minecraft:iron_block
fill 295 212 275 296 219 275 minecraft:light_gray_concrete
fill 295 212 308 295 214 308 minecraft:iron_block
fill 295 212 310 295 214 310 minecraft:iron_block
fill 295 212 312 295 214 312 minecraft:iron_block
fill 295 212 314 295 214 314 minecraft:iron_block
fill 295 212 316 295 214 316 minecraft:iron_block
fill 296 212 307 296 214 307 minecraft:iron_block
fill 296 212 309 296 214 309 minecraft:iron_block
fill 296 212 311 296 214 311 minecraft:iron_block
fill 296 212 313 296 214 313 minecraft:iron_block
fill 296 212 315 296 214 315 minecraft:iron_block
fill 296 212 317 299 219 317 minecraft:light_gray_concrete
setblock 297 212 275 minecraft:redstone_block
fill 297 212 308 297 214 308 minecraft:iron_block
fill 297 212 310 297 214 310 minecraft:iron_block
fill 297 212 312 297 214 312 minecraft:iron_block
fill 297 212 314 297 214 314 minecraft:iron_block
fill 297 212 316 297 214 316 minecraft:iron_block
fill 298 212 275 298 219 275 minecraft:light_gray_concrete
fill 298 212 277 298 213 277 minecraft:iron_block
fill 298 212 279 298 213 279 minecraft:iron_block
fill 298 212 307 298 214 307 minecraft:iron_block
fill 298 212 309 298 214 309 minecraft:iron_block
fill 298 212 311 298 214 311 minecraft:iron_block
fill 298 212 313 298 214 313 minecraft:iron_block
fill 298 212 315 298 214 315 minecraft:iron_block
fill 299 212 276 299 213 276 minecraft:iron_block
fill 299 212 278 299 213 278 minecraft:iron_block
fill 299 212 308 299 214 308 minecraft:iron_block
fill 299 212 310 299 214 310 minecraft:iron_block
fill 299 212 312 299 214 312 minecraft:iron_block
fill 299 212 314 299 214 314 minecraft:iron_block
fill 299 212 316 299 214 316 minecraft:iron_block
fill 300 212 277 300 213 277 minecraft:iron_block
fill 300 212 279 300 213 279 minecraft:iron_block
fill 300 212 307 300 214 307 minecraft:iron_block
fill 300 212 309 300 214 309 minecraft:iron_block
fill 300 212 311 300 214 311 minecraft:iron_block
fill 300 212 313 300 270 313 minecraft:iron_block
fill 300 212 315 300 214 315 minecraft:iron_block
fill 301 212 276 301 213 276 minecraft:iron_block
fill 301 212 278 301 213 278 minecraft:iron_block
fill 301 212 308 301 214 308 minecraft:iron_block
fill 301 212 310 301 214 310 minecraft:iron_block
fill 301 212 312 301 214 312 minecraft:iron_block
fill 301 212 314 301 214 314 minecraft:iron_block
fill 301 212 316 301 214 316 minecraft:iron_block
fill 302 212 277 302 213 277 minecraft:iron_block
fill 302 212 279 302 213 279 minecraft:iron_block
fill 302 212 307 302 214 307 minecraft:iron_block
fill 302 212 309 302 214 309 minecraft:iron_block
fill 302 212 311 302 214 311 minecraft:iron_block
fill 302 212 313 302 214 313 minecraft:iron_block
fill 302 212 315 302 214 315 minecraft:iron_block
fill 303 212 276 303 213 276 minecraft:iron_block
fill 303 212 278 303 213 278 minecraft:iron_block
fill 304 212 277 304 213 277 minecraft:iron_block
fill 304 212 279 304 213 279 minecraft:iron_block
fill 305 212 275 308 213 275 minecraft:light_gray_concrete
fill 306 212 317 309 218 317 minecraft:light_gray_concrete
fill 315 212 275 318 219 275 minecraft:light_gray_concrete
fill 316 212 317 319 219 317 minecraft:light_gray_concrete
fill 324 212 276 324 219 279 minecraft:light_gray_concrete
fill 324 212 286 324 219 289 minecraft:light_gray_concrete
fill 324 212 296 324 212 299 minecraft:light_gray_concrete
fill 324 212 306 324 219 309 minecraft:light_gray_concrete
fill 324 212 316 324 219 316 minecraft:light_gray_concrete
fill 297 213 275 297 219 275 minecraft:light_gray_concrete
fill 324 213 296 324 219 297 minecraft:light_gray_concrete
setblock 324 213 298 minecraft:sea_lantern
fill 324 213 299 324 218 299 minecraft:light_gray_concrete
setblock 298 214 277 minecraft:pearlescent_froglight
setblock 298 214 279 minecraft:pearlescent_froglight
setblock 299 214 276 minecraft:pearlescent_froglight
setblock 299 214 278 minecraft:pearlescent_froglight
setblock 300 214 277 minecraft:pearlescent_froglight
setblock 300 214 279 minecraft:pearlescent_froglight
setblock 301 214 276 minecraft:pearlescent_froglight
setblock 301 214 278 minecraft:pearlescent_froglight
setblock 302 214 277 minecraft:pearlescent_froglight
setblock 302 214 279 minecraft:pearlescent_froglight
setblock 303 214 276 minecraft:pearlescent_froglight
setblock 303 214 278 minecraft:pearlescent_froglight
setblock 304 214 277 minecraft:pearlescent_froglight
setblock 304 214 279 minecraft:pearlescent_froglight
fill 305 214 275 307 219 275 minecraft:light_gray_concrete
setblock 305 214 317 minecraft:redstone_block
setblock 308 214 275 minecraft:sea_lantern
fill 324 214 298 324 219 298 minecraft:light_gray_concrete
fill 298 215 277 298 216 277 minecraft:iron_block
fill 298 215 279 298 216 279 minecraft:iron_block
fill 299 215 275 301 229 275 minecraft:light_gray_concrete
fill 299 215 276 299 216 276 minecraft:iron_block
fill 299 215 278 299 216 278 minecraft:iron_block
fill 300 215 277 300 216 277 minecraft:iron_block
fill 300 215 279 300 216 279 minecraft:iron_block
fill 301 215 276 301 216 276 minecraft:iron_block
fill 301 215 278 301 216 278 minecraft:iron_block
setblock 302 215 275 minecraft:sea_lantern
fill 302 215 277 302 216 277 minecraft:iron_block
fill 302 215 279 302 216 279 minecraft:iron_block
fill 303 215 275 304 229 275 minecraft:light_gray_concrete
fill 303 215 276 303 216 276 minecraft:iron_block
fill 303 215 278 303 216 278 minecraft:iron_block
fill 304 215 277 304 216 277 minecraft:iron_block
fill 304 215 279 304 216 279 minecraft:iron_block
fill 305 215 317 305 229 317 minecraft:light_gray_concrete
fill 308 215 275 308 219 275 minecraft:light_gray_concrete
fill 319 215 275 321 229 275 minecraft:light_gray_concrete
setblock 322 215 275 minecraft:redstone_block
fill 323 215 275 324 229 275 minecraft:light_gray_concrete
setblock 283 216 278 minecraft:iron_block
fill 283 216 280 283 216 283 minecraft:iron_block
setblock 283 216 288 minecraft:iron_block
fill 283 216 290 283 216 293 minecraft:iron_block
setblock 283 216 298 minecraft:iron_block
fill 283 216 300 283 216 303 minecraft:iron_block
setblock 283 216 308 minecraft:iron_block
fill 283 216 310 283 216 313 minecraft:iron_block
fill 284 216 276 287 216 276 minecraft:iron_block
fill 284 216 311 284 216 313 minecraft:iron_block
setblock 285 216 311 minecraft:iron_block
setblock 285 216 313 minecraft:iron_block
setblock 285 216 316 minecraft:iron_block
fill 287 216 316 290 216 316 minecraft:iron_block
setblock 289 216 276 minecraft:iron_block
fill 294 216 276 297 216 276 minecraft:iron_block
setblock 295 216 316 minecraft:iron_block
fill 297 216 316 300 216 316 minecraft:iron_block
fill 302 216 275 302 229 275 minecraft:light_gray_concrete
fill 305 216 276 307 216 276 minecraft:iron_block
setblock 305 216 316 minecraft:iron_block
fill 307 216 316 310 216 316 minecraft:iron_block
setblock 309 216 276 minecraft:iron_block
fill 314 216 276 317 216 276 minecraft:iron_block
setblock 315 216 316 minecraft:iron_block
fill 317 216 316 320 216 316 minecraft:iron_block
setblock 319 216 276 minecraft:iron_block
fill 322 216 275 322 229 275 minecraft:light_gray_concrete
fill 323 216 277 323 216 280 minecraft:iron_block
setblock 323 216 282 minecraft:iron_block
fill 323 216 287 323 216 290 minecraft:iron_block
setblock 323 216 292 minecraft:iron_block
fill 323 216 297 323 216 300 minecraft:iron_block
setblock 323 216 302 minecraft:iron_block
fill 323 216 307 323 216 310 minecraft:iron_block
setblock 323 216 312 minecraft:iron_block
setblock 285 217 275 minecraft:sea_lantern
setblock 285 217 278 minecraft:light[level=15]
setblock 285 217 285 minecraft:light[level=12]
setblock 285 217 286 minecraft:light[level=15]
setblock 285 217 292 minecraft:light[level=12]
setblock 285 217 294 minecraft:light[level=15]
setblock 285 217 299 minecraft:light[level=12]
setblock 285 217 302 minecraft:light[level=15]
setblock 285 217 306 minecraft:light[level=12]
setblock 285 217 310 minecraft:light[level=15]
setblock 285 217 313 minecraft:light[level=12]
fill 286 217 275 288 219 275 minecraft:light_gray_concrete
setblock 292 217 278 minecraft:light[level=12]
setblock 292 217 285 minecraft:light[level=12]
setblock 292 217 292 minecraft:light[level=12]
setblock 292 217 299 minecraft:light[level=12]
setblock 292 217 306 minecraft:light[level=12]
setblock 292 217 313 minecraft:light[level=12]
setblock 293 217 278 minecraft:light[level=15]
setblock 293 217 286 minecraft:light[level=15]
setblock 293 217 294 minecraft:light[level=15]
setblock 293 217 302 minecraft:light[level=15]
setblock 293 217 310 minecraft:light[level=15]
fill 296 217 306 296 218 316 minecraft:iron_block
fill 297 217 299 297 218 311 minecraft:iron_block
setblock 298 217 277 minecraft:pearlescent_froglight
setblock 298 217 279 minecraft:pearlescent_froglight
setblock 299 217 276 minecraft:pearlescent_froglight
setblock 299 217 278 minecraft:pearlescent_froglight
setblock 299 217 285 minecraft:light[level=12]
setblock 299 217 292 minecraft:light[level=12]
setblock 299 217 299 minecraft:light[level=12]
setblock 299 217 306 minecraft:light[level=12]
setblock 300 217 277 minecraft:pearlescent_froglight
setblock 300 217 279 minecraft:pearlescent_froglight
fill 300 217 310 300 224 310 minecraft:iron_block
setblock 301 217 276 minecraft:pearlescent_froglight
setblock 301 217 278 minecraft:pearlescent_froglight
setblock 301 217 286 minecraft:light[level=15]
setblock 301 217 294 minecraft:light[level=15]
setblock 301 217 302 minecraft:light[level=15]
setblock 301 217 310 minecraft:light[level=15]
setblock 302 217 277 minecraft:pearlescent_froglight
setblock 302 217 279 minecraft:pearlescent_froglight
setblock 303 217 276 minecraft:pearlescent_froglight
setblock 303 217 278 minecraft:pearlescent_froglight
setblock 304 217 277 minecraft:pearlescent_froglight
setblock 304 217 279 minecraft:pearlescent_froglight
setblock 306 217 278 minecraft:light[level=12]
setblock 306 217 285 minecraft:light[level=12]
setblock 306 217 292 minecraft:light[level=12]
setblock 306 217 299 minecraft:light[level=12]
setblock 306 217 306 minecraft:light[level=12]
setblock 306 217 313 minecraft:light[level=12]
setblock 309 217 278 minecraft:light[level=15]
setblock 309 217 286 minecraft:light[level=15]
setblock 309 217 294 minecraft:light[level=15]
setblock 309 217 302 minecraft:light[level=15]
setblock 309 217 310 minecraft:light[level=15]
setblock 313 217 278 minecraft:light[level=12]
setblock 313 217 285 minecraft:light[level=12]
setblock 313 217 292 minecraft:light[level=12]
setblock 313 217 299 minecraft:light[level=12]
setblock 313 217 306 minecraft:light[level=12]
setblock 313 217 313 minecraft:light[level=12]
setblock 317 217 278 minecraft:light[level=15]
setblock 317 217 286 minecraft:light[level=15]
setblock 317 217 294 minecraft:light[level=15]
setblock 317 217 302 minecraft:light[level=15]
setblock 317 217 310 minecraft:light[level=15]
setblock 320 217 278 minecraft:light[level=12]
setblock 320 217 285 minecraft:light[level=12]
setblock 320 217 292 minecraft:light[level=12]
setblock 320 217 299 minecraft:light[level=12]
setblock 320 217 306 minecraft:light[level=12]
setblock 320 217 313 minecraft:light[level=12]
fill 285 218 275 285 219 275 minecraft:light_gray_concrete
fill 285 218 311 285 218 314 minecraft:gray_concrete
setblock 286 218 278 minecraft:gray_concrete
setblock 286 218 281 minecraft:gray_concrete
fill 286 218 310 288 218 310 minecraft:gray_concrete
setblock 286 218 314 minecraft:gray_concrete
fill 287 218 282 288 218 282 minecraft:gray_concrete
setblock 288 218 314 minecraft:gray_concrete
setblock 289 218 278 minecraft:gray_concrete
setblock 289 218 281 minecraft:gray_concrete
fill 289 218 311 289 218 313 minecraft:gray_concrete
fill 290 218 279 290 218 280 minecraft:gray_concrete
setblock 295 218 315 minecraft:iron_block
fill 296 218 303 296 218 305 minecraft:iron_block
fill 297 218 292 298 218 298 minecraft:iron_block
setblock 297 218 312 minecraft:iron_block
fill 298 218 277 298 219 277 minecraft:iron_block
fill 298 218 279 298 219 279 minecraft:iron_block
fill 298 218 281 299 218 291 minecraft:iron_block
fill 298 218 299 298 218 302 minecraft:iron_block
fill 299 218 276 299 219 276 minecraft:iron_block
fill 299 218 278 299 219 278 minecraft:iron_block
fill 299 218 280 299 219 280 minecraft:iron_block
fill 300 218 277 300 219 277 minecraft:iron_block
fill 300 218 279 300 219 279 minecraft:iron_block
fill 300 218 309 300 223 309 minecraft:iron_block
fill 301 218 276 301 219 276 minecraft:iron_block
fill 301 218 278 301 219 278 minecraft:iron_block
fill 302 218 277 302 219 277 minecraft:iron_block
fill 302 218 279 302 219 279 minecraft:iron_block
fill 303 218 276 303 219 276 minecraft:iron_block
fill 303 218 278 303 219 278 minecraft:iron_block
fill 304 218 277 304 219 277 minecraft:iron_block
fill 304 218 279 304 219 279 minecraft:iron_block
fill 285 219 312 285 225 312 minecraft:iron_block
fill 296 219 308 296 219 316 minecraft:light_gray_concrete
fill 297 219 298 297 219 308 minecraft:light_gray_concrete
fill 298 219 284 298 219 294 minecraft:iron_block
setblock 298 219 295 minecraft:light_gray_concrete
fill 299 219 281 299 219 286 minecraft:iron_block
setblock 306 219 317 minecraft:light_gray_concrete
setblock 307 219 317 minecraft:redstone_block
fill 308 219 317 309 219 317 minecraft:light_gray_concrete
setblock 324 219 299 minecraft:sea_lantern
fill 282 220 281 282 220 284 minecraft:pearlescent_froglight
fill 282 220 291 282 220 294 minecraft:pearlescent_froglight
fill 282 220 301 282 220 304 minecraft:pearlescent_froglight
fill 282 220 311 282 220 314 minecraft:pearlescent_froglight
fill 285 220 275 288 220 275 minecraft:pearlescent_froglight
fill 286 220 317 289 220 317 minecraft:pearlescent_froglight
fill 295 220 275 298 220 275 minecraft:pearlescent_froglight
fill 296 220 317 299 220 317 minecraft:pearlescent_froglight
setblock 298 220 277 minecraft:pearlescent_froglight
setblock 298 220 279 minecraft:pearlescent_froglight
fill 298 220 287 298 220 292 minecraft:light_gray_concrete
setblock 299 220 276 minecraft:pearlescent_froglight
setblock 299 220 278 minecraft:pearlescent_froglight
fill 299 220 280 299 220 284 minecraft:light_gray_concrete
setblock 299 220 312 minecraft:iron_block
setblock 299 220 314 minecraft:iron_block
setblock 300 220 277 minecraft:pearlescent_froglight
setblock 300 220 279 minecraft:pearlescent_froglight
setblock 301 220 276 minecraft:pearlescent_froglight
setblock 301 220 278 minecraft:pearlescent_froglight
setblock 301 220 312 minecraft:iron_block
setblock 301 220 314 minecraft:iron_block
setblock 302 220 277 minecraft:pearlescent_froglight
setblock 302 220 279 minecraft:pearlescent_froglight
setblock 303 220 276 minecraft:pearlescent_froglight
setblock 303 220 278 minecraft:pearlescent_froglight
setblock 304 220 277 minecraft:pearlescent_froglight
setblock 304 220 279 minecraft:pearlescent_froglight
fill 305 220 275 308 220 275 minecraft:pearlescent_froglight
fill 306 220 317 309 220 317 minecraft:pearlescent_froglight
fill 315 220 275 318 220 275 minecraft:pearlescent_froglight
fill 316 220 317 319 220 317 minecraft:pearlescent_froglight
fill 324 220 276 324 220 279 minecraft:pearlescent_froglight
fill 324 220 286 324 220 289 minecraft:pearlescent_froglight
setblock 324 220 290 minecraft:redstone_block
fill 324 220 291 324 229 292 minecraft:light_gray_concrete
setblock 324 220 294 minecraft:sea_lantern
fill 324 220 295 324 229 295 minecraft:light_gray_concrete
fill 324 220 296 324 220 299 minecraft:pearlescent_froglight
fill 324 220 306 324 220 309 minecraft:pearlescent_froglight
setblock 324 220 316 minecraft:pearlescent_froglight
fill 282 221 281 282 228 284 minecraft:light_gray_concrete
fill 282 221 291 282 221 294 minecraft:light_gray_concrete
fill 282 221 301 282 228 304 minecraft:light_gray_concrete
fill 282 221 311 282 228 314 minecraft:light_gray_concrete
fill 285 221 275 288 228 275 minecraft:light_gray_concrete
fill 286 221 317 289 228 317 minecraft:light_gray_concrete
fill 295 221 275 298 228 275 minecraft:light_gray_concrete
fill 296 221 317 299 227 317 minecraft:light_gray_concrete
fill 298 221 277 298 223 277 minecraft:iron_block
fill 298 221 279 298 223 279 minecraft:iron_block
fill 299 221 276 299 223 276 minecraft:iron_block
fill 299 221 278 299 223 278 minecraft:iron_block
fill 300 221 277 300 223 277 minecraft:iron_block
fill 300 221 279 300 223 279 minecraft:iron_block
fill 301 221 276 301 223 276 minecraft:iron_block
fill 301 221 278 301 223 278 minecraft:iron_block
fill 302 221 277 302 223 277 minecraft:iron_block
fill 302 221 279 302 223 279 minecraft:iron_block
fill 303 221 276 303 223 276 minecraft:iron_block
fill 303 221 278 303 223 278 minecraft:iron_block
fill 304 221 277 304 223 277 minecraft:iron_block
fill 304 221 279 304 223 279 minecraft:iron_block
fill 305 221 275 308 228 275 minecraft:light_gray_concrete
fill 306 221 317 309 224 317 minecraft:light_gray_concrete
fill 310 221 275 312 227 275 minecraft:light_gray_concrete
setblock 313 221 275 minecraft:sea_lantern
fill 314 221 275 318 228 275 minecraft:light_gray_concrete
fill 316 221 317 319 228 317 minecraft:light_gray_concrete
fill 324 221 276 324 228 279 minecraft:light_gray_concrete
fill 324 221 286 324 225 290 minecraft:light_gray_concrete
fill 324 221 294 324 229 294 minecraft:light_gray_concrete
fill 324 221 296 324 228 299 minecraft:light_gray_concrete
fill 324 221 306 324 228 309 minecraft:light_gray_concrete
fill 324 221 316 324 228 316 minecraft:light_gray_concrete
fill 282 222 291 282 228 291 minecraft:light_gray_concrete
setblock 282 222 292 minecraft:redstone_block
fill 282 222 293 282 228 294 minecraft:light_gray_concrete
setblock 283 222 278 minecraft:iron_block
setblock 283 222 288 minecraft:iron_block
setblock 283 222 298 minecraft:iron_block
fill 283 222 300 289 223 301 minecraft:iron_block
setblock 283 222 308 minecraft:iron_block
fill 284 222 311 284 222 313 minecraft:iron_block
setblock 285 222 311 minecraft:iron_block
setblock 285 222 313 minecraft:iron_block
setblock 285 222 316 minecraft:iron_block
fill 289 222 275 293 229 275 minecraft:light_gray_concrete
setblock 289 222 276 minecraft:iron_block
fill 290 222 288 290 223 288 minecraft:gray_concrete
fill 290 222 301 290 223 301 minecraft:iron_block
fill 290 222 311 290 223 311 minecraft:gray_concrete
setblock 294 222 275 minecraft:redstone_block
setblock 295 222 316 minecraft:iron_block
fill 302 222 308 302 223 308 minecraft:gray_concrete
setblock 305 222 316 minecraft:iron_block
setblock 309 222 276 minecraft:iron_block
setblock 312 222 317 minecraft:sea_lantern
fill 313 222 275 313 229 275 minecraft:light_gray_concrete
fill 313 222 283 313 223 283 minecraft:gray_concrete
fill 315 222 304 315 223 304 minecraft:gray_concrete
setblock 315 222 316 minecraft:iron_block
setblock 319 222 276 minecraft:iron_block
setblock 323 222 282 minecraft:iron_block
setblock 323 222 292 minecraft:iron_block
setblock 323 222 302 minecraft:iron_block
setblock 323 222 312 minecraft:iron_block
fill 282 223 292 282 228 292 minecraft:light_gray_concrete
setblock 285 223 278 minecraft:light[level=12]
setblock 285 223 285 minecraft:light[level=12]
setblock 285 223 292 minecraft:light[level=12]
setblock 285 223 299 minecraft:light[level=12]
setblock 285 223 306 minecraft:light[level=12]
setblock 285 223 313 minecraft:light[level=12]
fill 289 223 288 289 224 288 minecraft:gray_concrete
fill 289 223 311 289 224 311 minecraft:gray_concrete
fill 290 223 300 301 223 300 minecraft:iron_block
fill 291 223 301 312 223 301 minecraft:iron_block
setblock 292 223 278 minecraft:light[level=12]
setblock 292 223 285 minecraft:light[level=12]
setblock 292 223 292 minecraft:light[level=12]
setblock 292 223 299 minecraft:light[level=12]
setblock 292 223 306 minecraft:light[level=12]
setblock 292 223 313 minecraft:light[level=12]
fill 294 223 275 294 224 275 minecraft:light_gray_concrete
setblock 299 223 285 minecraft:light[level=12]
setblock 299 223 292 minecraft:light[level=12]
setblock 299 223 299 minecraft:light[level=12]
setblock 299 223 306 minecraft:light[level=12]
fill 302 223 309 302 224 309 minecraft:gray_concrete
fill 305 223 300 305 224 300 minecraft:iron_block
setblock 306 223 278 minecraft:light[level=12]
setblock 306 223 285 minecraft:light[level=12]
setblock 306 223 292 minecraft:light[level=12]
setblock 306 223 299 minecraft:light[level=12]
setblock 306 223 306 minecraft:light[level=12]
setblock 306 223 313 minecraft:light[level=12]
fill 312 223 317 312 229 317 minecraft:light_gray_concrete
setblock 313 223 278 minecraft:light[level=12]
fill 313 223 282 313 224 282 minecraft:gray_concrete
setblock 313 223 285 minecraft:light[level=12]
setblock 313 223 292 minecraft:light[level=12]
setblock 313 223 299 minecraft:light[level=12]
setblock 313 223 306 minecraft:light[level=12]
setblock 313 223 313 minecraft:light[level=12]
fill 316 223 304 316 224 304 minecraft:gray_concrete
setblock 320 223 278 minecraft:light[level=12]
setblock 320 223 285 minecraft:light[level=12]
setblock 320 223 292 minecraft:light[level=12]
setblock 320 223 299 minecraft:light[level=12]
setblock 320 223 306 minecraft:light[level=12]
setblock 320 223 313 minecraft:light[level=12]
fill 283 224 300 287 224 301 minecraft:light_gray_concrete
fill 286 224 311 287 224 313 minecraft:iron_block
fill 288 224 288 288 225 288 minecraft:gray_concrete
fill 288 224 301 291 224 301 minecraft:light_gray_concrete
fill 288 224 311 288 225 311 minecraft:gray_concrete
fill 288 224 312 288 270 313 minecraft:iron_block
fill 295 224 301 323 224 301 minecraft:iron_block
fill 298 224 300 301 224 300 minecraft:iron_block
fill 302 224 310 302 225 310 minecraft:gray_concrete
fill 306 224 300 319 224 300 minecraft:iron_block
fill 313 224 281 313 225 281 minecraft:gray_concrete
fill 317 224 304 317 225 304 minecraft:gray_concrete
setblock 324 224 280 minecraft:sea_lantern
fill 283 225 280 283 225 283 minecraft:iron_block
fill 283 225 290 283 225 293 minecraft:iron_block
fill 283 225 300 283 225 303 minecraft:iron_block
fill 283 225 310 283 225 313 minecraft:iron_block
fill 284 225 276 287 225 276 minecraft:iron_block
setblock 285 225 278 minecraft:light[level=15]
setblock 285 225 286 minecraft:light[level=15]
setblock 285 225 294 minecraft:light[level=15]
setblock 285 225 302 minecraft:light[level=15]
setblock 285 225 310 minecraft:light[level=15]
fill 286 225 311 286 225 313 minecraft:iron_block
fill 287 225 288 287 226 288 minecraft:gray_concrete
fill 287 225 311 287 226 311 minecraft:gray_concrete
fill 287 225 312 287 270 313 minecraft:iron_block
fill 287 225 316 290 225 316 minecraft:iron_block
setblock 293 225 278 minecraft:light[level=15]
setblock 293 225 286 minecraft:light[level=15]
setblock 293 225 294 minecraft:light[level=15]
setblock 293 225 302 minecraft:light[level=15]
setblock 293 225 310 minecraft:light[level=15]
setblock 294 225 275 minecraft:sea_lantern
fill 294 225 276 297 225 276 minecraft:iron_block
fill 295 225 313 295 226 315 minecraft:iron_block
fill 297 225 301 312 225 301 minecraft:light_gray_concrete
fill 297 225 316 300 225 316 minecraft:iron_block
setblock 301 225 278 minecraft:light[level=15]
setblock 301 225 286 minecraft:light[level=15]
setblock 301 225 294 minecraft:light[level=15]
setblock 301 225 302 minecraft:light[level=15]
setblock 301 225 310 minecraft:light[level=15]
fill 302 225 311 302 226 311 minecraft:gray_concrete
fill 304 225 276 307 225 276 minecraft:iron_block
fill 306 225 317 307 228 317 minecraft:light_gray_concrete
fill 307 225 316 310 225 316 minecraft:iron_block
setblock 308 225 317 minecraft:sea_lantern
setblock 309 225 278 minecraft:light[level=15]
setblock 309 225 286 minecraft:light[level=15]
setblock 309 225 294 minecraft:light[level=15]
setblock 309 225 302 minecraft:light[level=15]
setblock 309 225 310 minecraft:light[level=15]
fill 309 225 317 309 228 317 minecraft:light_gray_concrete
fill 313 225 280 313 226 280 minecraft:gray_concrete
fill 313 225 301 323 225 301 minecraft:iron_block
fill 314 225 276 317 225 276 minecraft:iron_block
setblock 317 225 278 minecraft:light[level=15]
setblock 317 225 286 minecraft:light[level=15]
setblock 317 225 294 minecraft:light[level=15]
setblock 317 225 302 minecraft:light[level=15]
setblock 317 225 310 minecraft:light[level=15]
fill 317 225 316 320 225 316 minecraft:iron_block
fill 318 225 304 318 226 304 minecraft:gray_concrete
fill 323 225 277 323 225 280 minecraft:iron_block
fill 323 225 287 323 225 290 minecraft:iron_block
fill 323 225 297 323 225 300 minecraft:iron_block
fill 323 225 307 323 225 310 minecraft:iron_block
fill 324 225 280 324 229 280 minecraft:light_gray_concrete
fill 285 226 311 285 226 314 minecraft:gray_concrete
setblock 286 226 278 minecraft:gray_concrete
setblock 286 226 281 minecraft:gray_concrete
fill 286 226 288 286 227 288 minecraft:gray_concrete
fill 286 226 310 286 226 311 minecraft:gray_concrete
fill 286 226 312 286 270 313 minecraft:iron_block
setblock 286 226 314 minecraft:gray_concrete
fill 287 226 282 288 226 282 minecraft:gray_concrete
fill 287 226 310 288 226 310 minecraft:gray_concrete
fill 288 226 311 288 270 311 minecraft:iron_block
setblock 288 226 314 minecraft:gray_concrete
setblock 289 226 278 minecraft:gray_concrete
setblock 289 226 281 minecraft:gray_concrete
fill 289 226 311 289 226 313 minecraft:gray_concrete
fill 290 226 279 290 226 280 minecraft:gray_concrete
fill 294 226 275 294 229 275 minecraft:light_gray_concrete
fill 302 226 312 302 227 312 minecraft:gray_concrete
fill 308 226 317 308 228 317 minecraft:light_gray_concrete
fill 313 226 279 313 227 279 minecraft:gray_concrete
fill 314 226 301 323 226 301 minecraft:light_gray_concrete
fill 319 226 304 319 227 304 minecraft:gray_concrete
fill 324 226 286 324 228 286 minecraft:light_gray_concrete
setblock 324 226 287 minecraft:redstone_block
fill 324 226 288 324 228 290 minecraft:light_gray_concrete
setblock 284 227 317 minecraft:redstone_block
fill 285 227 288 285 228 288 minecraft:gray_concrete
fill 285 227 311 286 227 311 minecraft:gray_concrete
fill 285 227 312 285 233 312 minecraft:iron_block
fill 287 227 311 287 270 311 minecraft:iron_block
fill 302 227 313 302 228 313 minecraft:gray_concrete
fill 313 227 278 313 228 278 minecraft:gray_concrete
fill 320 227 304 320 228 304 minecraft:gray_concrete
fill 324 227 287 324 228 287 minecraft:light_gray_concrete
fill 282 228 305 282 229 305 minecraft:light_gray_concrete
setblock 282 228 306 minecraft:sea_lantern
fill 282 228 307 282 229 308 minecraft:light_gray_concrete
setblock 283 228 278 minecraft:iron_block
setblock 283 228 288 minecraft:iron_block
setblock 283 228 298 minecraft:iron_block
setblock 283 228 308 minecraft:iron_block
fill 284 228 288 284 229 288 minecraft:gray_concrete
fill 284 228 311 285 228 311 minecraft:gray_concrete
fill 284 228 312 284 228 313 minecraft:iron_block
fill 284 228 317 284 229 317 minecraft:light_gray_concrete
setblock 285 228 313 minecraft:iron_block
setblock 285 228 316 minecraft:iron_block
fill 286 228 311 286 270 311 minecraft:iron_block
setblock 289 228 276 minecraft:iron_block
setblock 295 228 316 minecraft:iron_block
fill 296 228 317 297 228 317 minecraft:light_gray_concrete
setblock 298 228 317 minecraft:redstone_block
setblock 299 228 276 minecraft:iron_block
setblock 299 228 312 minecraft:iron_block
setblock 299 228 314 minecraft:iron_block
setblock 299 228 317 minecraft:light_gray_concrete
setblock 301 228 312 minecraft:iron_block
setblock 301 228 314 minecraft:iron_block
fill 302 228 314 302 229 314 minecraft:gray_concrete
setblock 305 228 316 minecraft:iron_block
setblock 309 228 276 minecraft:iron_block
setblock 310 228 275 minecraft:sea_lantern
fill 311 228 275 312 229 275 minecraft:light_gray_concrete
fill 313 228 277 313 229 277 minecraft:gray_concrete
setblock 315 228 316 minecraft:iron_block
setblock 319 228 276 minecraft:iron_block
fill 321 228 304 321 229 304 minecraft:gray_concrete
setblock 323 228 282 minecraft:iron_block
setblock 323 228 292 minecraft:iron_block
setblock 323 228 302 minecraft:iron_block
setblock 323 228 312 minecraft:iron_block
setblock 324 228 293 minecraft:redstone_block
fill 282 229 281 282 229 284 minecraft:pearlescent_froglight
fill 282 229 291 282 229 294 minecraft:pearlescent_froglight
fill 282 229 301 282 229 304 minecraft:pearlescent_froglight
setblock 282 229 306 minecraft:light_gray_concrete
fill 282 229 311 282 229 314 minecraft:pearlescent_froglight
fill 283 229 288 283 230 288 minecraft:gray_concrete
fill 283 229 311 284 229 311 minecraft:gray_concrete
fill 285 229 275 288 229 275 minecraft:pearlescent_froglight
setblock 285 229 278 minecraft:light[level=12]
setblock 285 229 285 minecraft:light[level=12]
setblock 285 229 292 minecraft:light[level=12]
setblock 285 229 299 minecraft:light[level=12]
setblock 285 229 306 minecraft:light[level=12]
setblock 285 229 313 minecraft:light[level=12]
fill 286 229 317 289 229 317 minecraft:pearlescent_froglight
setblock 292 229 278 minecraft:light[level=12]
setblock 292 229 285 minecraft:light[level=12]
setblock 292 229 292 minecraft:light[level=12]
setblock 292 229 299 minecraft:light[level=12]
setblock 292 229 306 minecraft:light[level=12]
setblock 292 229 313 minecraft:light[level=12]
fill 295 229 275 298 229 275 minecraft:pearlescent_froglight
fill 296 229 317 299 229 317 minecraft:pearlescent_froglight
setblock 299 229 278 minecraft:light[level=12]
setblock 299 229 285 minecraft:light[level=12]
setblock 299 229 292 minecraft:light[level=12]
setblock 299 229 299 minecraft:light[level=12]
setblock 299 229 306 minecraft:light[level=12]
fill 302 229 315 302 230 315 minecraft:gray_concrete
fill 305 229 275 308 229 275 minecraft:pearlescent_froglight
setblock 306 229 278 minecraft:light[level=12]
setblock 306 229 285 minecraft:light[level=12]
setblock 306 229 292 minecraft:light[level=12]
setblock 306 229 299 minecraft:light[level=12]
setblock 306 229 306 minecraft:light[level=12]
setblock 306 229 313 minecraft:light[level=12]
fill 306 229 317 309 229 317 minecraft:pearlescent_froglight
setblock 310 229 275 minecraft:light_gray_concrete
fill 313 229 276 313 230 276 minecraft:gray_concrete
setblock 313 229 278 minecraft:light[level=12]
setblock 313 229 285 minecraft:light[level=12]
setblock 313 229 292 minecraft:light[level=12]
setblock 313 229 299 minecraft:light[level=12]
setblock 313 229 306 minecraft:light[level=12]
setblock 313 229 313 minecraft:light[level=12]
setblock 314 229 275 minecraft:light_gray_concrete
fill 315 229 275 318 229 275 minecraft:pearlescent_froglight
fill 316 229 317 319 229 317 minecraft:pearlescent_froglight
setblock 320 229 278 minecraft:light[level=12]
setblock 320 229 285 minecraft:light[level=12]
setblock 320 229 292 minecraft:light[level=12]
setblock 320 229 299 minecraft:light[level=12]
setblock 320 229 306 minecraft:light[level=12]
setblock 320 229 313 minecraft:light[level=12]
fill 322 229 304 322 230 304 minecraft:gray_concrete
fill 324 229 276 324 229 279 minecraft:pearlescent_froglight
fill 324 229 286 324 229 289 minecraft:pearlescent_froglight
setblock 324 229 290 minecraft:light_gray_concrete
setblock 324 229 293 minecraft:light_gray_concrete
fill 324 229 296 324 229 299 minecraft:pearlescent_froglight
fill 324 229 306 324 229 309 minecraft:pearlescent_froglight
setblock 324 229 316 minecraft:pearlescent_froglight
fill 282 230 275 282 231 276 minecraft:yellow_concrete
fill 282 230 277 282 231 278 minecraft:black_concrete
fill 282 230 279 282 231 280 minecraft:yellow_concrete
fill 282 230 281 282 231 282 minecraft:black_concrete
fill 282 230 283 282 231 284 minecraft:yellow_concrete
fill 282 230 285 282 231 286 minecraft:black_concrete
fill 282 230 287 282 231 288 minecraft:yellow_concrete
fill 282 230 289 282 231 290 minecraft:black_concrete
fill 282 230 291 282 231 292 minecraft:yellow_concrete
fill 282 230 293 282 231 294 minecraft:black_concrete
fill 282 230 295 282 231 296 minecraft:yellow_concrete
fill 282 230 297 282 231 298 minecraft:black_concrete
fill 282 230 299 282 231 300 minecraft:yellow_concrete
fill 282 230 301 282 231 302 minecraft:black_concrete
fill 282 230 303 282 231 304 minecraft:yellow_concrete
fill 282 230 305 282 231 306 minecraft:black_concrete
fill 282 230 307 282 231 308 minecraft:yellow_concrete
fill 282 230 309 282 231 310 minecraft:black_concrete
fill 282 230 311 282 231 312 minecraft:yellow_concrete
fill 282 230 313 282 231 314 minecraft:black_concrete
fill 282 230 315 282 231 316 minecraft:yellow_concrete
fill 282 230 317 282 231 317 minecraft:black_concrete
fill 283 230 275 283 231 275 minecraft:yellow_concrete
setblock 283 230 311 minecraft:gray_concrete
fill 283 230 317 283 231 317 minecraft:yellow_concrete
fill 284 230 275 285 231 275 minecraft:black_concrete
fill 284 230 317 285 231 317 minecraft:black_concrete
fill 286 230 275 287 231 275 minecraft:yellow_concrete
fill 286 230 317 287 231 317 minecraft:yellow_concrete
fill 288 230 275 289 231 275 minecraft:black_concrete
fill 288 230 317 289 231 317 minecraft:black_concrete
fill 290 230 275 291 231 275 minecraft:yellow_concrete
setblock 290 230 285 minecraft:pearlescent_froglight
setblock 290 230 291 minecraft:pearlescent_froglight
setblock 290 230 297 minecraft:pearlescent_froglight
setblock 290 230 303 minecraft:pearlescent_froglight
setblock 290 230 309 minecraft:pearlescent_froglight
fill 290 230 317 291 231 317 minecraft:yellow_concrete
fill 292 230 275 293 231 275 minecraft:black_concrete
setblock 292 230 283 minecraft:pearlescent_froglight
fill 292 230 317 293 231 317 minecraft:black_concrete
fill 294 230 275 295 231 275 minecraft:yellow_concrete
fill 294 230 317 295 231 317 minecraft:yellow_concrete
fill 296 230 275 297 231 275 minecraft:black_concrete
setblock 296 230 309 minecraft:pearlescent_froglight
fill 296 230 317 297 231 317 minecraft:black_concrete
fill 298 230 275 299 231 275 minecraft:yellow_concrete
setblock 298 230 283 minecraft:pearlescent_froglight
fill 298 230 317 299 231 317 minecraft:yellow_concrete
fill 300 230 275 301 231 275 minecraft:black_concrete
fill 300 230 317 301 231 317 minecraft:black_concrete
fill 302 230 275 303 231 275 minecraft:yellow_concrete
setblock 302 230 309 minecraft:pearlescent_froglight
fill 302 230 317 303 231 317 minecraft:yellow_concrete
fill 304 230 275 305 231 275 minecraft:black_concrete
setblock 304 230 283 minecraft:pearlescent_froglight
fill 304 230 317 305 231 317 minecraft:black_concrete
fill 306 230 275 307 231 275 minecraft:yellow_concrete
fill 306 230 317 307 231 317 minecraft:yellow_concrete
fill 308 230 275 309 231 275 minecraft:black_concrete
setblock 308 230 309 minecraft:pearlescent_froglight
fill 308 230 317 309 231 317 minecraft:black_concrete
fill 310 230 275 311 231 275 minecraft:yellow_concrete
setblock 310 230 283 minecraft:pearlescent_froglight
fill 310 230 317 311 231 317 minecraft:yellow_concrete
fill 312 230 275 313 231 275 minecraft:black_concrete
fill 312 230 317 313 231 317 minecraft:black_concrete
fill 314 230 275 315 231 275 minecraft:yellow_concrete
setblock 314 230 309 minecraft:pearlescent_froglight
fill 314 230 317 315 231 317 minecraft:yellow_concrete
fill 316 230 275 317 231 275 minecraft:black_concrete
setblock 316 230 283 minecraft:pearlescent_froglight
setblock 316 230 289 minecraft:pearlescent_froglight
setblock 316 230 295 minecraft:pearlescent_froglight
setblock 316 230 301 minecraft:pearlescent_froglight
setblock 316 230 307 minecraft:pearlescent_froglight
fill 316 230 317 317 231 317 minecraft:black_concrete
fill 318 230 275 319 231 275 minecraft:yellow_concrete
fill 318 230 317 319 231 317 minecraft:yellow_concrete
fill 320 230 275 321 231 275 minecraft:black_concrete
fill 320 230 283 322 231 283 minecraft:iron_block
fill 320 230 317 321 231 317 minecraft:black_concrete
fill 322 230 275 323 231 275 minecraft:yellow_concrete
fill 322 230 317 323 231 317 minecraft:yellow_concrete
fill 324 230 275 324 231 275 minecraft:black_concrete
fill 324 230 276 324 231 276 minecraft:yellow_concrete
fill 324 230 277 324 231 278 minecraft:black_concrete
fill 324 230 279 324 231 280 minecraft:yellow_concrete
fill 324 230 281 324 231 282 minecraft:black_concrete
fill 324 230 283 324 231 284 minecraft:yellow_concrete
fill 324 230 285 324 231 286 minecraft:black_concrete
fill 324 230 287 324 231 288 minecraft:yellow_concrete
fill 324 230 289 324 231 290 minecraft:black_concrete
fill 324 230 291 324 231 292 minecraft:yellow_concrete
fill 324 230 293 324 231 294 minecraft:black_concrete
fill 324 230 295 324 231 296 minecraft:yellow_concrete
fill 324 230 297 324 231 298 minecraft:black_concrete
fill 324 230 299 324 231 300 minecraft:yellow_concrete
fill 324 230 301 324 231 302 minecraft:black_concrete
fill 324 230 303 324 231 304 minecraft:yellow_concrete
fill 324 230 305 324 231 306 minecraft:black_concrete
fill 324 230 307 324 231 308 minecraft:yellow_concrete
fill 324 230 309 324 231 310 minecraft:black_concrete
fill 324 230 311 324 231 312 minecraft:yellow_concrete
fill 324 230 313 324 231 314 minecraft:black_concrete
fill 324 230 315 324 231 316 minecraft:yellow_concrete
fill 324 230 317 324 231 317 minecraft:black_concrete
setblock 283 231 276 minecraft:iron_block
fill 283 231 278 283 231 279 minecraft:iron_block
fill 283 231 281 283 231 282 minecraft:iron_block
fill 283 231 284 283 231 285 minecraft:iron_block
setblock 283 231 288 minecraft:iron_block
fill 283 231 290 283 231 291 minecraft:iron_block
fill 283 231 293 283 231 294 minecraft:iron_block
fill 283 231 296 284 231 296 minecraft:iron_block
fill 283 231 299 283 231 300 minecraft:iron_block
fill 283 231 302 283 231 306 minecraft:iron_block
fill 283 231 308 283 231 309 minecraft:iron_block
fill 283 231 311 283 231 312 minecraft:iron_block
fill 283 231 314 283 231 315 minecraft:iron_block
fill 284 231 277 284 231 278 minecraft:iron_block
fill 284 231 280 284 231 281 minecraft:iron_block
fill 284 231 283 284 231 284 minecraft:iron_block
fill 284 231 286 284 231 287 minecraft:iron_block
fill 284 231 289 284 231 290 minecraft:iron_block
fill 284 231 292 284 231 293 minecraft:iron_block
fill 284 231 295 285 231 295 minecraft:iron_block
fill 284 231 298 284 231 299 minecraft:iron_block
fill 284 231 301 284 231 302 minecraft:iron_block
fill 284 231 304 285 231 305 minecraft:iron_block
fill 284 231 307 284 231 308 minecraft:iron_block
fill 284 231 310 284 231 311 minecraft:iron_block
fill 284 231 313 284 231 314 minecraft:iron_block
fill 285 231 276 285 231 277 minecraft:iron_block
fill 285 231 279 285 231 280 minecraft:iron_block
fill 285 231 282 285 231 283 minecraft:iron_block
fill 285 231 285 285 231 286 minecraft:iron_block
fill 285 231 288 285 231 289 minecraft:iron_block
fill 285 231 291 285 231 292 minecraft:iron_block
fill 285 231 294 286 231 294 minecraft:iron_block
fill 285 231 297 285 231 298 minecraft:iron_block
fill 285 231 300 285 231 301 minecraft:iron_block
fill 285 231 303 286 231 303 minecraft:iron_block
fill 285 231 306 285 231 307 minecraft:iron_block
fill 285 231 309 285 231 310 minecraft:iron_block
setblock 285 231 313 minecraft:iron_block
fill 285 231 315 285 231 316 minecraft:iron_block
setblock 286 231 276 minecraft:iron_block
setblock 286 231 278 minecraft:iron_block
fill 286 231 281 286 231 282 minecraft:iron_block
fill 286 231 284 286 231 285 minecraft:iron_block
fill 286 231 287 286 231 288 minecraft:iron_block
fill 286 231 290 286 231 291 minecraft:iron_block
fill 286 231 293 287 231 293 minecraft:iron_block
fill 286 231 296 286 231 297 minecraft:iron_block
fill 286 231 299 286 231 300 minecraft:iron_block
fill 286 231 302 287 231 302 minecraft:iron_block
fill 286 231 305 286 232 306 minecraft:iron_block
fill 286 231 308 286 231 309 minecraft:iron_block
fill 286 231 314 286 231 315 minecraft:iron_block
fill 287 231 277 288 231 277 minecraft:iron_block
fill 287 231 283 287 231 284 minecraft:iron_block
fill 287 231 286 287 231 287 minecraft:iron_block
fill 287 231 289 287 231 290 minecraft:iron_block
fill 287 231 292 288 231 292 minecraft:iron_block
fill 287 231 295 287 231 296 minecraft:iron_block
fill 287 231 298 287 231 299 minecraft:iron_block
fill 287 231 301 288 231 301 minecraft:iron_block
fill 287 231 304 288 231 305 minecraft:iron_block
fill 287 231 307 287 231 308 minecraft:iron_block
fill 287 231 310 288 231 310 minecraft:iron_block
fill 287 231 316 288 231 316 minecraft:iron_block
fill 288 231 276 289 231 276 minecraft:iron_block
fill 288 231 282 288 231 283 minecraft:iron_block
fill 288 231 285 288 231 286 minecraft:iron_block
fill 288 231 288 288 231 289 minecraft:iron_block
fill 288 231 291 289 231 291 minecraft:iron_block
fill 288 231 294 288 231 295 minecraft:iron_block
fill 288 231 297 288 231 298 minecraft:iron_block
fill 288 231 300 289 231 300 minecraft:iron_block
fill 288 231 303 289 231 303 minecraft:iron_block
fill 288 231 306 288 231 307 minecraft:iron_block
fill 288 231 309 289 231 309 minecraft:iron_block
fill 288 231 315 289 231 315 minecraft:iron_block
fill 289 231 278 290 231 278 minecraft:iron_block
fill 289 231 281 289 231 282 minecraft:iron_block
fill 289 231 284 289 231 285 minecraft:iron_block
fill 289 231 287 289 231 288 minecraft:iron_block
fill 289 231 290 290 231 290 minecraft:iron_block
fill 289 231 293 289 231 294 minecraft:iron_block
fill 289 231 296 289 231 297 minecraft:iron_block
fill 289 231 299 290 231 299 minecraft:iron_block
fill 289 231 302 290 231 302 minecraft:iron_block
fill 289 231 305 289 232 306 minecraft:iron_block
fill 289 231 308 290 231 308 minecraft:iron_block
fill 289 231 311 289 231 312 minecraft:iron_block
fill 289 231 314 290 231 314 minecraft:iron_block
fill 290 231 277 291 231 277 minecraft:iron_block
fill 290 231 280 290 231 281 minecraft:iron_block
fill 290 231 283 290 231 284 minecraft:iron_block
fill 290 231 286 290 231 287 minecraft:iron_block
setblock 290 231 289 minecraft:iron_block
fill 290 231 292 290 231 293 minecraft:iron_block
fill 290 231 295 290 231 296 minecraft:iron_block
setblock 290 231 298 minecraft:iron_block
setblock 290 231 301 minecraft:iron_block
fill 290 231 304 290 231 305 minecraft:iron_block
setblock 290 231 307 minecraft:iron_block
fill 290 231 310 290 231 311 minecraft:iron_block
fill 290 231 313 291 231 313 minecraft:iron_block
fill 290 231 316 291 231 316 minecraft:iron_block
fill 291 231 276 292 231 276 minecraft:iron_block
fill 291 231 279 291 231 280 minecraft:iron_block
fill 291 231 282 291 231 283 minecraft:iron_block
fill 291 231 309 291 231 310 minecraft:iron_block
fill 291 231 312 292 231 312 minecraft:iron_block
fill 291 231 315 292 231 315 minecraft:iron_block
fill 292 231 278 292 231 279 minecraft:iron_block
fill 292 231 281 292 231 282 minecraft:iron_block
setblock 292 231 309 minecraft:iron_block
fill 292 231 311 293 231 311 minecraft:iron_block
fill 292 231 314 293 231 314 minecraft:iron_block
fill 293 231 277 293 231 278 minecraft:iron_block
fill 293 231 280 293 231 281 minecraft:iron_block
fill 293 231 283 294 231 283 minecraft:iron_block
fill 293 231 310 294 231 310 minecraft:iron_block
fill 293 231 313 294 231 313 minecraft:iron_block
setblock 293 231 316 minecraft:iron_block
fill 294 231 276 294 231 277 minecraft:iron_block
fill 294 231 279 294 231 280 minecraft:iron_block
fill 294 231 282 295 231 282 minecraft:iron_block
fill 294 231 309 295 231 309 minecraft:iron_block
fill 294 231 312 295 231 312 minecraft:iron_block
fill 294 231 315 295 231 315 minecraft:iron_block
setblock 295 231 276 minecraft:iron_block
fill 295 231 278 295 231 279 minecraft:iron_block
fill 295 231 281 296 231 281 minecraft:iron_block
fill 295 231 311 296 231 311 minecraft:iron_block
fill 295 231 314 296 231 314 minecraft:iron_block
fill 296 231 277 296 231 278 minecraft:iron_block
fill 296 231 280 297 231 280 minecraft:iron_block
fill 296 231 283 297 231 283 minecraft:iron_block
fill 296 231 310 297 231 310 minecraft:iron_block
fill 296 231 313 297 231 313 minecraft:iron_block
fill 296 231 316 297 231 316 minecraft:iron_block
fill 297 231 276 297 231 277 minecraft:iron_block
fill 297 231 279 298 231 279 minecraft:iron_block
fill 297 231 282 298 231 282 minecraft:iron_block
fill 297 231 309 298 231 309 minecraft:iron_block
fill 297 231 312 298 231 312 minecraft:iron_block
fill 297 231 315 298 231 315 minecraft:iron_block
setblock 298 231 276 minecraft:iron_block
fill 298 231 278 299 231 278 minecraft:iron_block
fill 298 231 281 299 231 281 minecraft:iron_block
fill 298 231 311 299 231 311 minecraft:iron_block
fill 298 231 314 299 231 314 minecraft:iron_block
fill 299 231 277 300 231 277 minecraft:iron_block
fill 299 231 280 300 231 280 minecraft:iron_block
fill 299 231 283 300 231 283 minecraft:iron_block
fill 299 231 310 300 231 310 minecraft:iron_block
fill 299 231 316 300 231 316 minecraft:iron_block
fill 300 231 279 301 231 279 minecraft:iron_block
fill 300 231 282 301 231 282 minecraft:iron_block
fill 300 231 309 301 231 309 minecraft:iron_block
fill 300 231 315 301 231 315 minecraft:iron_block
setblock 301 231 276 minecraft:iron_block
fill 301 231 278 302 231 278 minecraft:iron_block
fill 301 231 281 302 231 281 minecraft:iron_block
fill 301 231 311 301 231 312 minecraft:iron_block
fill 301 231 314 302 231 314 minecraft:iron_block
fill 302 231 277 303 231 277 minecraft:iron_block
fill 302 231 280 303 231 280 minecraft:iron_block
fill 302 231 283 303 231 283 minecraft:iron_block
fill 302 231 310 302 231 311 minecraft:iron_block
fill 302 231 313 303 231 313 minecraft:iron_block
fill 302 231 316 303 231 316 minecraft:iron_block
fill 303 231 276 304 231 276 minecraft:iron_block
fill 303 231 279 304 231 279 minecraft:iron_block
fill 303 231 282 304 231 282 minecraft:iron_block
fill 303 231 309 303 231 310 minecraft:iron_block
fill 303 231 312 304 231 312 minecraft:iron_block
fill 303 231 315 304 231 315 minecraft:iron_block
fill 304 231 278 305 231 278 minecraft:iron_block
fill 304 231 281 305 231 281 minecraft:iron_block
setblock 304 231 309 minecraft:iron_block
fill 304 231 311 305 231 311 minecraft:iron_block
fill 304 231 314 305 231 314 minecraft:iron_block
fill 305 231 277 306 231 277 minecraft:iron_block
fill 305 231 280 306 231 280 minecraft:iron_block
fill 305 231 283 306 231 283 minecraft:iron_block
fill 305 231 310 306 231 310 minecraft:iron_block
fill 305 231 313 306 231 313 minecraft:iron_block
fill 305 231 316 306 231 316 minecraft:iron_block
fill 306 231 276 307 231 276 minecraft:iron_block
fill 306 231 279 307 231 279 minecraft:iron_block
fill 306 231 282 307 231 282 minecraft:iron_block
fill 306 231 309 307 231 309 minecraft:iron_block
fill 306 231 312 307 231 312 minecraft:iron_block
fill 306 231 315 307 231 315 minecraft:iron_block
fill 307 231 278 308 231 278 minecraft:iron_block
fill 307 231 281 308 231 281 minecraft:iron_block
fill 307 231 311 308 231 311 minecraft:iron_block
fill 307 231 314 308 231 314 minecraft:iron_block
fill 308 231 277 309 231 277 minecraft:iron_block
fill 308 231 280 309 231 280 minecraft:iron_block
fill 308 231 283 309 231 283 minecraft:iron_block
fill 308 231 310 309 231 310 minecraft:iron_block
fill 308 231 313 309 231 313 minecraft:iron_block
fill 308 231 316 309 231 316 minecraft:iron_block
setblock 309 231 276 minecraft:iron_block
fill 309 231 279 310 231 279 minecraft:iron_block
fill 309 231 282 310 231 282 minecraft:iron_block
fill 309 231 309 310 231 309 minecraft:iron_block
fill 309 231 312 310 231 312 minecraft:iron_block
fill 309 231 315 310 231 315 minecraft:iron_block
fill 310 231 278 311 231 278 minecraft:iron_block
fill 310 231 281 311 231 281 minecraft:iron_block
fill 310 231 311 311 231 311 minecraft:iron_block
fill 310 231 314 311 231 314 minecraft:iron_block
fill 311 231 277 312 231 277 minecraft:iron_block
fill 311 231 280 312 231 280 minecraft:iron_block
fill 311 231 283 312 231 283 minecraft:iron_block
fill 311 231 310 312 231 310 minecraft:iron_block
fill 311 231 313 312 231 313 minecraft:iron_block
fill 311 231 316 312 231 316 minecraft:iron_block
fill 312 231 276 313 231 276 minecraft:iron_block
fill 312 231 279 313 231 279 minecraft:iron_block
fill 312 231 282 313 231 282 minecraft:iron_block
fill 312 231 309 313 231 309 minecraft:iron_block
fill 312 231 312 313 231 312 minecraft:iron_block
fill 312 231 315 313 231 315 minecraft:iron_block
fill 313 231 278 314 231 278 minecraft:iron_block
fill 313 231 281 314 231 281 minecraft:iron_block
fill 313 231 311 314 231 311 minecraft:iron_block
fill 313 231 314 314 231 314 minecraft:iron_block
fill 314 231 277 315 231 277 minecraft:iron_block
fill 314 231 280 315 231 280 minecraft:iron_block
fill 314 231 283 315 231 283 minecraft:iron_block
fill 314 231 310 315 231 310 minecraft:iron_block
fill 314 231 313 315 231 313 minecraft:iron_block
fill 315 231 276 316 231 276 minecraft:iron_block
fill 315 231 279 316 231 279 minecraft:iron_block
fill 315 231 282 316 231 282 minecraft:iron_block
fill 315 231 309 316 231 309 minecraft:iron_block
fill 315 231 312 316 231 312 minecraft:iron_block
fill 315 231 315 315 231 316 minecraft:iron_block
fill 316 231 278 317 231 278 minecraft:iron_block
fill 316 231 281 317 231 281 minecraft:iron_block
fill 316 231 284 316 231 285 minecraft:iron_block
fill 316 231 287 316 231 288 minecraft:iron_block
fill 316 231 290 316 231 291 minecraft:iron_block
fill 316 231 293 316 231 294 minecraft:iron_block
fill 316 231 296 316 231 297 minecraft:iron_block
fill 316 231 299 316 231 300 minecraft:iron_block
fill 316 231 302 316 231 303 minecraft:iron_block
fill 316 231 305 316 231 306 minecraft:iron_block
fill 316 231 308 317 231 308 minecraft:iron_block
fill 316 231 311 317 231 311 minecraft:iron_block
fill 316 231 314 316 231 315 minecraft:iron_block
fill 317 231 277 318 231 277 minecraft:iron_block
fill 317 231 280 318 231 280 minecraft:iron_block
fill 317 231 283 317 231 284 minecraft:iron_block
fill 317 231 286 317 231 287 minecraft:iron_block
fill 317 231 289 317 231 290 minecraft:iron_block
fill 317 231 292 317 231 293 minecraft:iron_block
fill 317 231 295 317 231 296 minecraft:iron_block
fill 317 231 298 317 231 299 minecraft:iron_block
fill 317 231 301 317 231 302 minecraft:iron_block
fill 317 231 304 317 231 305 minecraft:iron_block
fill 317 231 307 318 231 307 minecraft:iron_block
fill 317 231 310 318 231 310 minecraft:iron_block
fill 317 231 313 317 231 314 minecraft:iron_block
fill 317 231 316 318 231 316 minecraft:iron_block
fill 318 231 276 319 231 276 minecraft:iron_block
fill 318 231 279 319 231 279 minecraft:iron_block
fill 318 231 282 318 231 283 minecraft:iron_block
fill 318 231 285 318 231 286 minecraft:iron_block
fill 318 231 288 318 231 289 minecraft:iron_block
fill 318 231 291 318 231 292 minecraft:iron_block
fill 318 231 294 318 231 295 minecraft:iron_block
fill 318 231 297 318 231 298 minecraft:iron_block
fill 318 231 300 318 231 301 minecraft:iron_block
fill 318 231 303 318 231 304 minecraft:iron_block
fill 318 231 306 319 231 306 minecraft:iron_block
fill 318 231 309 319 231 309 minecraft:iron_block
fill 318 231 312 318 231 313 minecraft:iron_block
fill 318 231 315 319 231 315 minecraft:iron_block
fill 319 231 278 320 231 278 minecraft:iron_block
fill 319 231 281 319 231 282 minecraft:iron_block
fill 319 231 284 319 231 285 minecraft:iron_block
fill 319 231 287 319 231 288 minecraft:iron_block
fill 319 231 290 319 231 291 minecraft:iron_block
fill 319 231 293 319 231 294 minecraft:iron_block
fill 319 231 296 319 231 297 minecraft:iron_block
fill 319 231 299 319 231 300 minecraft:iron_block
fill 319 231 302 319 231 303 minecraft:iron_block
fill 319 231 305 320 231 305 minecraft:iron_block
fill 319 231 308 320 231 308 minecraft:iron_block
fill 319 231 311 319 231 312 minecraft:iron_block
fill 319 231 314 320 231 314 minecraft:iron_block
fill 320 231 277 321 231 277 minecraft:iron_block
fill 320 231 280 320 231 281 minecraft:iron_block
setblock 320 231 284 minecraft:iron_block
fill 320 231 286 320 231 287 minecraft:iron_block
fill 320 231 289 320 231 290 minecraft:iron_block
fill 320 231 292 320 231 293 minecraft:iron_block
fill 320 231 295 320 231 296 minecraft:iron_block
fill 320 231 298 320 231 299 minecraft:iron_block
fill 320 231 301 320 231 302 minecraft:iron_block
fill 320 231 304 321 231 304 minecraft:iron_block
fill 320 231 307 321 231 307 minecraft:iron_block
fill 320 231 310 320 231 311 minecraft:iron_block
fill 320 231 313 321 231 313 minecraft:iron_block
fill 320 231 316 321 231 316 minecraft:iron_block
fill 321 231 276 322 231 276 minecraft:iron_block
fill 321 231 279 321 231 280 minecraft:iron_block
fill 321 231 282 322 231 282 minecraft:iron_block
fill 321 231 285 321 231 286 minecraft:iron_block
fill 321 231 288 321 231 289 minecraft:iron_block
fill 321 231 291 321 231 292 minecraft:iron_block
fill 321 231 294 321 231 295 minecraft:iron_block
fill 321 231 297 321 231 298 minecraft:iron_block
fill 321 231 300 321 231 301 minecraft:iron_block
fill 321 231 303 322 231 303 minecraft:iron_block
fill 321 231 306 322 231 306 minecraft:iron_block
fill 321 231 309 321 231 310 minecraft:iron_block
fill 321 231 312 322 231 312 minecraft:iron_block
fill 321 231 315 322 231 315 minecraft:iron_block
fill 322 231 278 322 231 279 minecraft:iron_block
fill 322 231 281 323 231 281 minecraft:iron_block
fill 322 231 284 322 231 285 minecraft:iron_block
fill 322 231 287 322 231 288 minecraft:iron_block
fill 322 231 290 322 231 291 minecraft:iron_block
fill 322 231 293 322 231 294 minecraft:iron_block
fill 322 231 296 322 231 297 minecraft:iron_block
fill 322 231 299 322 231 300 minecraft:iron_block
fill 322 231 302 323 231 302 minecraft:iron_block
fill 322 231 305 323 231 305 minecraft:iron_block
fill 322 231 308 322 231 309 minecraft:iron_block
fill 322 231 311 323 231 311 minecraft:iron_block
fill 322 231 314 323 231 314 minecraft:iron_block
fill 323 231 277 323 231 278 minecraft:iron_block
setblock 323 231 280 minecraft:iron_block
setblock 323 231 284 minecraft:iron_block
fill 323 231 286 323 231 287 minecraft:iron_block
fill 323 231 289 323 231 290 minecraft:iron_block
setblock 323 231 292 minecraft:iron_block
fill 323 231 295 323 231 296 minecraft:iron_block
fill 323 231 298 323 231 299 minecraft:iron_block
setblock 323 231 301 minecraft:iron_block
setblock 323 231 304 minecraft:iron_block
fill 323 231 307 323 231 308 minecraft:iron_block
setblock 323 231 310 minecraft:iron_block
setblock 323 231 316 minecraft:iron_block
fill 282 232 275 282 237 317 minecraft:light_gray_concrete
fill 283 232 275 324 237 275 minecraft:light_gray_concrete
fill 283 232 304 284 232 305 minecraft:iron_block
fill 283 232 317 324 234 317 minecraft:light_gray_concrete
setblock 285 232 305 minecraft:iron_block
fill 287 232 305 288 232 306 minecraft:iron_block
fill 290 232 283 290 232 304 minecraft:light_gray_concrete
fill 290 232 305 296 232 306 minecraft:iron_block
fill 290 232 307 290 232 309 minecraft:light_gray_concrete
fill 291 232 283 316 232 283 minecraft:light_gray_concrete
fill 291 232 309 316 232 309 minecraft:light_gray_concrete
fill 297 232 306 304 232 307 minecraft:iron_block
fill 301 232 314 301 233 315 minecraft:iron_block
fill 305 232 307 311 233 307 minecraft:iron_block
fill 316 232 284 316 232 308 minecraft:light_gray_concrete
fill 324 232 276 324 234 316 minecraft:light_gray_concrete
fill 283 233 305 290 233 305 minecraft:light_gray_concrete
setblock 285 233 278 minecraft:light[level=15]
setblock 285 233 286 minecraft:light[level=15]
setblock 285 233 294 minecraft:light[level=15]
setblock 285 233 302 minecraft:light[level=15]
setblock 285 233 310 minecraft:light[level=15]
fill 292 233 306 293 233 306 minecraft:light_gray_concrete
setblock 293 233 278 minecraft:light[level=15]
setblock 293 233 286 minecraft:light[level=15]
setblock 293 233 294 minecraft:light[level=15]
setblock 293 233 302 minecraft:light[level=15]
setblock 293 233 310 minecraft:light[level=15]
fill 294 233 306 306 233 306 minecraft:iron_block
fill 299 233 307 304 233 307 minecraft:iron_block
setblock 301 233 278 minecraft:light[level=15]
setblock 301 233 286 minecraft:light[level=15]
setblock 301 233 294 minecraft:light[level=15]
setblock 301 233 302 minecraft:light[level=15]
setblock 301 233 310 minecraft:light[level=15]
fill 308 233 308 323 233 308 minecraft:iron_block
setblock 309 233 278 minecraft:light[level=15]
setblock 309 233 286 minecraft:light[level=15]
setblock 309 233 294 minecraft:light[level=15]
setblock 309 233 302 minecraft:light[level=15]
setblock 309 233 310 minecraft:light[level=15]
fill 312 233 307 317 233 307 minecraft:iron_block
setblock 317 233 278 minecraft:light[level=15]
setblock 317 233 286 minecraft:light[level=15]
setblock 317 233 294 minecraft:light[level=15]
setblock 317 233 302 minecraft:light[level=15]
setblock 317 233 310 minecraft:light[level=15]
fill 319 233 309 323 233 309 minecraft:iron_block
setblock 283 234 278 minecraft:iron_block
fill 283 234 280 283 234 283 minecraft:iron_block
setblock 283 234 288 minecraft:iron_block
fill 283 234 290 283 234 293 minecraft:iron_block
setblock 283 234 298 minecraft:iron_block
fill 283 234 300 283 234 303 minecraft:iron_block
setblock 283 234 308 minecraft:iron_block
fill 283 234 310 283 234 313 minecraft:iron_block
fill 284 234 276 287 234 276 minecraft:iron_block
fill 284 234 311 284 234 313 minecraft:iron_block
fill 285 234 311 285 234 314 minecraft:gray_concrete
setblock 285 234 316 minecraft:iron_block
setblock 286 234 278 minecraft:gray_concrete
setblock 286 234 281 minecraft:gray_concrete
fill 286 234 310 288 234 310 minecraft:gray_concrete
setblock 286 234 314 minecraft:gray_concrete
fill 287 234 282 288 234 282 minecraft:gray_concrete
fill 287 234 316 290 234 316 minecraft:iron_block
setblock 288 234 314 minecraft:gray_concrete
setblock 289 234 276 minecraft:iron_block
setblock 289 234 278 minecraft:gray_concrete
setblock 289 234 281 minecraft:gray_concrete
fill 289 234 311 289 234 313 minecraft:gray_concrete
fill 290 234 279 290 234 280 minecraft:gray_concrete
fill 294 234 276 297 234 276 minecraft:iron_block
fill 295 234 306 302 234 306 minecraft:light_gray_concrete
setblock 295 234 316 minecraft:iron_block
fill 297 234 316 300 234 316 minecraft:iron_block
setblock 299 234 276 minecraft:iron_block
fill 302 234 307 311 234 307 minecraft:light_gray_concrete
fill 304 234 276 307 234 276 minecraft:iron_block
setblock 305 234 316 minecraft:iron_block
fill 307 234 316 310 234 316 minecraft:iron_block
setblock 309 234 276 minecraft:iron_block
fill 314 234 276 317 234 276 minecraft:iron_block
fill 314 234 308 323 234 308 minecraft:iron_block
setblock 315 234 316 minecraft:iron_block
fill 317 234 316 320 234 316 minecraft:iron_block
setblock 319 234 276 minecraft:iron_block
fill 321 234 309 323 234 309 minecraft:iron_block
fill 323 234 277 323 234 280 minecraft:iron_block
setblock 323 234 282 minecraft:iron_block
fill 323 234 287 323 234 290 minecraft:iron_block
setblock 323 234 292 minecraft:iron_block
fill 323 234 297 323 234 300 minecraft:iron_block
setblock 323 234 302 minecraft:iron_block
setblock 323 234 307 minecraft:iron_block
setblock 323 234 310 minecraft:iron_block
setblock 323 234 312 minecraft:iron_block
fill 283 235 317 316 237 317 minecraft:light_gray_concrete
setblock 285 235 278 minecraft:light[level=12]
setblock 285 235 285 minecraft:light[level=12]
setblock 285 235 292 minecraft:light[level=12]
setblock 285 235 299 minecraft:light[level=12]
setblock 285 235 306 minecraft:light[level=12]
fill 285 235 312 285 241 312 minecraft:iron_block
setblock 285 235 313 minecraft:light[level=12]
setblock 292 235 278 minecraft:light[level=12]
setblock 292 235 285 minecraft:light[level=12]
setblock 292 235 292 minecraft:light[level=12]
setblock 292 235 299 minecraft:light[level=12]
setblock 292 235 306 minecraft:light[level=12]
setblock 292 235 313 minecraft:light[level=12]
setblock 299 235 278 minecraft:light[level=12]
setblock 299 235 285 minecraft:light[level=12]
setblock 299 235 292 minecraft:light[level=12]
setblock 299 235 299 minecraft:light[level=12]
setblock 299 235 306 minecraft:light[level=12]
setblock 306 235 278 minecraft:light[level=12]
setblock 306 235 285 minecraft:light[level=12]
setblock 306 235 292 minecraft:light[level=12]
setblock 306 235 299 minecraft:light[level=12]
setblock 306 235 306 minecraft:light[level=12]
setblock 306 235 313 minecraft:light[level=12]
setblock 313 235 278 minecraft:light[level=12]
setblock 313 235 285 minecraft:light[level=12]
setblock 313 235 292 minecraft:light[level=12]
setblock 313 235 299 minecraft:light[level=12]
setblock 313 235 306 minecraft:light[level=12]
setblock 313 235 313 minecraft:light[level=12]
fill 315 235 308 322 235 308 minecraft:light_gray_concrete
setblock 317 235 317 minecraft:redstone_block
fill 318 235 317 324 237 317 minecraft:light_gray_concrete
setblock 320 235 278 minecraft:light[level=12]
setblock 320 235 285 minecraft:light[level=12]
setblock 320 235 292 minecraft:light[level=12]
setblock 320 235 299 minecraft:light[level=12]
setblock 320 235 306 minecraft:light[level=12]
setblock 320 235 313 minecraft:light[level=12]
fill 324 235 276 324 235 287 minecraft:light_gray_concrete
setblock 324 235 288 minecraft:sea_lantern
fill 324 235 289 324 237 295 minecraft:light_gray_concrete
setblock 324 235 296 minecraft:redstone_block
fill 324 235 297 324 235 316 minecraft:light_gray_concrete
setblock 299 236 312 minecraft:iron_block
setblock 299 236 314 minecraft:iron_block
setblock 301 236 312 minecraft:iron_block
setblock 301 236 314 minecraft:iron_block
fill 317 236 317 317 237 317 minecraft:light_gray_concrete
fill 324 236 276 324 237 283 minecraft:light_gray_concrete
fill 324 236 284 324 236 285 minecraft:sea_lantern
fill 324 236 286 324 237 288 minecraft:light_gray_concrete
fill 324 236 296 324 237 306 minecraft:light_gray_concrete
setblock 324 236 307 minecraft:sea_lantern
fill 324 236 308 324 236 316 minecraft:light_gray_concrete
fill 324 237 284 324 257 285 minecraft:light_gray_concrete
fill 324 237 307 324 237 309 minecraft:light_gray_concrete
setblock 324 237 310 minecraft:redstone_block
fill 324 237 311 324 237 316 minecraft:light_gray_concrete
fill 282 238 275 282 241 280 minecraft:light_gray_concrete
fill 282 238 281 282 238 284 minecraft:pearlescent_froglight
fill 282 238 285 282 244 290 minecraft:light_gray_concrete
fill 282 238 291 282 238 294 minecraft:pearlescent_froglight
fill 282 238 295 282 245 300 minecraft:light_gray_concrete
fill 282 238 301 282 238 304 minecraft:pearlescent_froglight
fill 282 238 305 282 257 310 minecraft:light_gray_concrete
fill 282 238 311 282 238 314 minecraft:pearlescent_froglight
fill 282 238 315 282 257 317 minecraft:light_gray_concrete
fill 283 238 275 284 257 275 minecraft:light_gray_concrete
fill 283 238 317 285 257 317 minecraft:light_gray_concrete
fill 285 238 275 288 238 275 minecraft:pearlescent_froglight
fill 286 238 317 289 238 317 minecraft:pearlescent_froglight
fill 289 238 275 294 257 275 minecraft:light_gray_concrete
fill 290 238 317 293 246 317 minecraft:light_gray_concrete
setblock 294 238 317 minecraft:sea_lantern
fill 295 238 275 298 238 275 minecraft:pearlescent_froglight
fill 295 238 317 295 257 317 minecraft:light_gray_concrete
fill 296 238 317 299 238 317 minecraft:pearlescent_froglight
fill 299 238 275 304 257 275 minecraft:light_gray_concrete
fill 300 238 317 305 257 317 minecraft:light_gray_concrete
fill 305 238 275 308 238 275 minecraft:pearlescent_froglight
fill 306 238 317 309 238 317 minecraft:pearlescent_froglight
fill 309 238 275 314 257 275 minecraft:light_gray_concrete
fill 310 238 317 315 257 317 minecraft:light_gray_concrete
fill 315 238 275 318 238 275 minecraft:pearlescent_froglight
fill 316 238 317 319 238 317 minecraft:pearlescent_froglight
fill 319 238 275 324 257 275 minecraft:light_gray_concrete
fill 320 238 317 324 257 317 minecraft:light_gray_concrete
fill 324 238 276 324 238 279 minecraft:pearlescent_froglight
fill 324 238 280 324 257 283 minecraft:light_gray_concrete
fill 324 238 286 324 238 289 minecraft:pearlescent_froglight
fill 324 238 290 324 257 295 minecraft:light_gray_concrete
fill 324 238 296 324 238 299 minecraft:pearlescent_froglight
fill 324 238 300 324 239 305 minecraft:light_gray_concrete
fill 324 238 306 324 238 309 minecraft:pearlescent_froglight
fill 324 238 310 324 256 315 minecraft:light_gray_concrete
setblock 324 238 316 minecraft:pearlescent_froglight
fill 282 239 281 282 246 284 minecraft:light_gray_concrete
fill 282 239 291 282 246 294 minecraft:light_gray_concrete
fill 282 239 301 282 242 304 minecraft:light_gray_concrete
fill 282 239 311 282 246 314 minecraft:light_gray_concrete
fill 285 239 275 288 246 275 minecraft:light_gray_concrete
fill 286 239 317 289 246 317 minecraft:light_gray_concrete
fill 294 239 317 294 257 317 minecraft:light_gray_concrete
fill 295 239 275 298 246 275 minecraft:light_gray_concrete
fill 296 239 317 299 243 317 minecraft:light_gray_concrete
fill 305 239 275 308 244 275 minecraft:light_gray_concrete
fill 306 239 317 309 246 317 minecraft:light_gray_concrete
fill 315 239 275 318 240 275 minecraft:light_gray_concrete
fill 316 239 317 319 246 317 minecraft:light_gray_concrete
fill 324 239 276 324 246 279 minecraft:light_gray_concrete
fill 324 239 286 324 242 289 minecraft:light_gray_concrete
fill 324 239 296 324 243 299 minecraft:light_gray_concrete
fill 324 239 306 324 246 309 minecraft:light_gray_concrete
fill 324 239 316 324 246 316 minecraft:light_gray_concrete
setblock 283 240 278 minecraft:iron_block
setblock 283 240 288 minecraft:iron_block
setblock 283 240 298 minecraft:iron_block
setblock 283 240 308 minecraft:iron_block
fill 284 240 311 284 240 313 minecraft:iron_block
setblock 285 240 311 minecraft:iron_block
setblock 285 240 313 minecraft:iron_block
setblock 285 240 316 minecraft:iron_block
setblock 289 240 276 minecraft:iron_block
setblock 295 240 316 minecraft:iron_block
setblock 299 240 276 minecraft:iron_block
setblock 305 240 316 minecraft:iron_block
setblock 309 240 276 minecraft:iron_block
setblock 315 240 316 minecraft:iron_block
setblock 319 240 276 minecraft:iron_block
setblock 323 240 282 minecraft:iron_block
setblock 323 240 292 minecraft:iron_block
setblock 323 240 302 minecraft:iron_block
setblock 323 240 312 minecraft:iron_block
fill 324 240 300 324 257 301 minecraft:light_gray_concrete
setblock 324 240 302 minecraft:sea_lantern
fill 324 240 303 324 257 305 minecraft:light_gray_concrete
setblock 285 241 278 minecraft:light[level=15]
setblock 285 241 285 minecraft:light[level=12]
setblock 285 241 286 minecraft:light[level=15]
setblock 285 241 292 minecraft:light[level=12]
setblock 285 241 294 minecraft:light[level=15]
setblock 285 241 299 minecraft:light[level=12]
setblock 285 241 302 minecraft:light[level=15]
setblock 285 241 306 minecraft:light[level=12]
setblock 285 241 310 minecraft:light[level=15]
setblock 285 241 313 minecraft:light[level=12]
setblock 292 241 278 minecraft:light[level=12]
setblock 292 241 285 minecraft:light[level=12]
setblock 292 241 292 minecraft:light[level=12]
setblock 292 241 299 minecraft:light[level=12]
setblock 292 241 306 minecraft:light[level=12]
setblock 292 241 313 minecraft:light[level=12]
setblock 293 241 278 minecraft:light[level=15]
setblock 293 241 286 minecraft:light[level=15]
setblock 293 241 294 minecraft:light[level=15]
setblock 293 241 302 minecraft:light[level=15]
setblock 293 241 310 minecraft:light[level=15]
setblock 299 241 278 minecraft:light[level=12]
setblock 299 241 285 minecraft:light[level=12]
setblock 299 241 292 minecraft:light[level=12]
setblock 299 241 299 minecraft:light[level=12]
setblock 299 241 306 minecraft:light[level=12]
setblock 301 241 278 minecraft:light[level=15]
setblock 301 241 286 minecraft:light[level=15]
setblock 301 241 294 minecraft:light[level=15]
setblock 301 241 302 minecraft:light[level=15]
setblock 301 241 310 minecraft:light[level=15]
setblock 306 241 278 minecraft:light[level=12]
setblock 306 241 285 minecraft:light[level=12]
setblock 306 241 292 minecraft:light[level=12]
setblock 306 241 299 minecraft:light[level=12]
setblock 306 241 306 minecraft:light[level=12]
setblock 306 241 313 minecraft:light[level=12]
setblock 309 241 278 minecraft:light[level=15]
setblock 309 241 286 minecraft:light[level=15]
setblock 309 241 294 minecraft:light[level=15]
setblock 309 241 302 minecraft:light[level=15]
setblock 309 241 310 minecraft:light[level=15]
setblock 313 241 278 minecraft:light[level=12]
setblock 313 241 285 minecraft:light[level=12]
setblock 313 241 292 minecraft:light[level=12]
setblock 313 241 299 minecraft:light[level=12]
setblock 313 241 306 minecraft:light[level=12]
setblock 313 241 313 minecraft:light[level=12]
fill 315 241 275 317 246 275 minecraft:light_gray_concrete
setblock 317 241 278 minecraft:light[level=15]
setblock 317 241 286 minecraft:light[level=15]
setblock 317 241 294 minecraft:light[level=15]
setblock 317 241 302 minecraft:light[level=15]
setblock 317 241 310 minecraft:light[level=15]
setblock 318 241 275 minecraft:sea_lantern
setblock 320 241 278 minecraft:light[level=12]
setblock 320 241 285 minecraft:light[level=12]
setblock 320 241 292 minecraft:light[level=12]
setblock 320 241 299 minecraft:light[level=12]
setblock 320 241 306 minecraft:light[level=12]
setblock 320 241 313 minecraft:light[level=12]
fill 324 241 302 324 257 302 minecraft:light_gray_concrete
fill 282 242 275 282 257 278 minecraft:light_gray_concrete
setblock 282 242 279 minecraft:redstone_block
fill 282 242 280 282 257 280 minecraft:light_gray_concrete
fill 285 242 311 285 242 314 minecraft:gray_concrete
setblock 286 242 278 minecraft:gray_concrete
setblock 286 242 281 minecraft:gray_concrete
fill 286 242 310 288 242 310 minecraft:gray_concrete
setblock 286 242 314 minecraft:gray_concrete
fill 287 242 282 288 242 282 minecraft:gray_concrete
setblock 288 242 314 minecraft:gray_concrete
setblock 289 242 278 minecraft:gray_concrete
setblock 289 242 281 minecraft:gray_concrete
fill 289 242 311 289 242 313 minecraft:gray_concrete
fill 290 242 279 290 242 280 minecraft:gray_concrete
fill 318 242 275 318 246 275 minecraft:light_gray_concrete
fill 282 243 279 282 257 279 minecraft:light_gray_concrete
fill 282 243 301 282 246 302 minecraft:light_gray_concrete
setblock 282 243 303 minecraft:redstone_block
fill 282 243 304 282 246 304 minecraft:light_gray_concrete
fill 283 243 280 283 243 283 minecraft:iron_block
fill 283 243 290 283 243 293 minecraft:iron_block
fill 283 243 300 283 243 303 minecraft:iron_block
fill 283 243 310 283 243 313 minecraft:iron_block
fill 284 243 276 287 243 276 minecraft:iron_block
fill 285 243 312 285 249 312 minecraft:iron_block
fill 287 243 316 290 243 316 minecraft:iron_block
fill 294 243 276 297 243 276 minecraft:iron_block
fill 297 243 316 300 243 316 minecraft:iron_block
fill 304 243 276 307 243 276 minecraft:iron_block
fill 307 243 316 310 243 316 minecraft:iron_block
fill 314 243 276 317 243 276 minecraft:iron_block
fill 317 243 316 320 243 316 minecraft:iron_block
fill 323 243 277 323 243 280 minecraft:iron_block
fill 323 243 287 323 243 290 minecraft:iron_block
fill 323 243 297 323 243 300 minecraft:iron_block
fill 323 243 307 323 243 310 minecraft:iron_block
fill 324 243 286 324 246 287 minecraft:light_gray_concrete
setblock 324 243 288 minecraft:sea_lantern
fill 324 243 289 324 246 289 minecraft:light_gray_concrete
fill 282 244 303 282 246 303 minecraft:light_gray_concrete
fill 296 244 317 297 246 317 minecraft:light_gray_concrete
setblock 298 244 317 minecraft:sea_lantern
setblock 299 244 312 minecraft:iron_block
setblock 299 244 314 minecraft:iron_block
fill 299 244 317 299 246 317 minecraft:light_gray_concrete
setblock 301 244 312 minecraft:iron_block
setblock 301 244 314 minecraft:iron_block
fill 324 244 288 324 246 288 minecraft:light_gray_concrete
fill 324 244 296 324 246 296 minecraft:light_gray_concrete
setblock 324 244 297 minecraft:sea_lantern
fill 324 244 298 324 246 299 minecraft:light_gray_concrete
fill 282 245 285 282 257 287 minecraft:light_gray_concrete
setblock 282 245 288 minecraft:redstone_block
fill 282 245 289 282 257 290 minecraft:light_gray_concrete
fill 298 245 317 298 246 317 minecraft:light_gray_concrete
setblock 305 245 275 minecraft:light_gray_concrete
setblock 306 245 275 minecraft:sea_lantern
fill 307 245 275 308 246 275 minecraft:light_gray_concrete
fill 324 245 297 324 246 297 minecraft:light_gray_concrete
fill 282 246 288 282 257 288 minecraft:light_gray_concrete
fill 282 246 295 282 257 296 minecraft:light_gray_concrete
setblock 282 246 297 minecraft:sea_lantern
fill 282 246 298 282 256 300 minecraft:light_gray_concrete
setblock 283 246 278 minecraft:iron_block
setblock 283 246 288 minecraft:iron_block
setblock 283 246 298 minecraft:iron_block
setblock 283 246 308 minecraft:iron_block
fill 284 246 311 284 246 313 minecraft:iron_block
setblock 285 246 311 minecraft:iron_block
setblock 285 246 313 minecraft:iron_block
setblock 285 246 316 minecraft:iron_block
setblock 289 246 276 minecraft:iron_block
setblock 295 246 316 minecraft:iron_block
setblock 299 246 276 minecraft:iron_block
setblock 305 246 275 minecraft:redstone_block
setblock 305 246 316 minecraft:iron_block
setblock 306 246 275 minecraft:light_gray_concrete
setblock 309 246 276 minecraft:iron_block
setblock 315 246 316 minecraft:iron_block
setblock 319 246 276 minecraft:iron_block
setblock 323 246 282 minecraft:iron_block
setblock 323 246 292 minecraft:iron_block
setblock 323 246 302 minecraft:iron_block
setblock 323 246 312 minecraft:iron_block
fill 282 247 281 282 247 284 minecraft:pearlescent_froglight
fill 282 247 291 282 247 294 minecraft:pearlescent_froglight
fill 282 247 297 282 257 297 minecraft:light_gray_concrete
fill 282 247 301 282 247 304 minecraft:pearlescent_froglight
fill 282 247 311 282 247 314 minecraft:pearlescent_froglight
fill 285 247 275 288 247 275 minecraft:pearlescent_froglight
setblock 285 247 278 minecraft:light[level=12]
setblock 285 247 285 minecraft:light[level=12]
setblock 285 247 292 minecraft:light[level=12]
setblock 285 247 299 minecraft:light[level=12]
setblock 285 247 306 minecraft:light[level=12]
setblock 285 247 313 minecraft:light[level=12]
fill 286 247 317 289 247 317 minecraft:pearlescent_froglight
fill 290 247 317 291 257 317 minecraft:light_gray_concrete
setblock 292 247 278 minecraft:light[level=12]
setblock 292 247 285 minecraft:light[level=12]
setblock 292 247 292 minecraft:light[level=12]
setblock 292 247 299 minecraft:light[level=12]
setblock 292 247 306 minecraft:light[level=12]
setblock 292 247 313 minecraft:light[level=12]
setblock 292 247 317 minecraft:sea_lantern
fill 293 247 317 293 257 317 minecraft:light_gray_concrete
fill 295 247 275 298 247 275 minecraft:pearlescent_froglight
fill 296 247 317 299 247 317 minecraft:pearlescent_froglight
setblock 299 247 278 minecraft:light[level=12]
setblock 299 247 285 minecraft:light[level=12]
setblock 299 247 292 minecraft:light[level=12]
setblock 299 247 299 minecraft:light[level=12]
setblock 299 247 306 minecraft:light[level=12]
fill 305 247 275 308 247 275 minecraft:pearlescent_froglight
setblock 306 247 278 minecraft:light[level=12]
setblock 306 247 285 minecraft:light[level=12]
setblock 306 247 292 minecraft:light[level=12]
setblock 306 247 299 minecraft:light[level=12]
setblock 306 247 306 minecraft:light[level=12]
setblock 306 247 313 minecraft:light[level=12]
fill 306 247 317 309 247 317 minecraft:pearlescent_froglight
setblock 313 247 278 minecraft:light[level=12]
setblock 313 247 285 minecraft:light[level=12]
setblock 313 247 292 minecraft:light[level=12]
setblock 313 247 299 minecraft:light[level=12]
setblock 313 247 306 minecraft:light[level=12]
setblock 313 247 313 minecraft:light[level=12]
fill 315 247 275 318 247 275 minecraft:pearlescent_froglight
fill 316 247 317 319 247 317 minecraft:pearlescent_froglight
setblock 320 247 278 minecraft:light[level=12]
setblock 320 247 285 minecraft:light[level=12]
setblock 320 247 292 minecraft:light[level=12]
setblock 320 247 299 minecraft:light[level=12]
setblock 320 247 306 minecraft:light[level=12]
setblock 320 247 313 minecraft:light[level=12]
fill 324 247 276 324 247 279 minecraft:pearlescent_froglight
fill 324 247 286 324 247 289 minecraft:pearlescent_froglight
fill 324 247 296 324 247 299 minecraft:pearlescent_froglight
fill 324 247 306 324 247 309 minecraft:pearlescent_froglight
setblock 324 247 316 minecraft:pearlescent_froglight
fill 282 248 281 282 255 284 minecraft:light_gray_concrete
fill 282 248 291 282 249 294 minecraft:light_gray_concrete
fill 282 248 301 282 255 304 minecraft:light_gray_concrete
fill 282 248 311 282 255 314 minecraft:light_gray_concrete
fill 283 248 312 284 249 312 minecraft:iron_block
fill 285 248 275 288 255 275 minecraft:light_gray_concrete
fill 286 248 317 289 255 317 minecraft:light_gray_concrete
fill 292 248 317 292 257 317 minecraft:light_gray_concrete
fill 295 248 275 298 255 275 minecraft:light_gray_concrete
fill 296 248 317 297 255 317 minecraft:light_gray_concrete
setblock 298 248 317 minecraft:redstone_block
fill 299 248 317 299 255 317 minecraft:light_gray_concrete
fill 305 248 275 308 255 275 minecraft:light_gray_concrete
fill 306 248 317 309 255 317 minecraft:light_gray_concrete
fill 315 248 275 318 255 275 minecraft:light_gray_concrete
fill 316 248 317 319 255 317 minecraft:light_gray_concrete
fill 320 248 299 320 259 299 minecraft:iron_block
fill 324 248 276 324 255 279 minecraft:light_gray_concrete
fill 324 248 286 324 255 289 minecraft:light_gray_concrete
fill 324 248 296 324 255 299 minecraft:light_gray_concrete
fill 324 248 306 324 255 309 minecraft:light_gray_concrete
fill 324 248 316 324 255 316 minecraft:light_gray_concrete
setblock 285 249 278 minecraft:light[level=15]
setblock 285 249 286 minecraft:light[level=15]
setblock 285 249 294 minecraft:light[level=15]
setblock 285 249 302 minecraft:light[level=15]
setblock 285 249 310 minecraft:light[level=15]
setblock 293 249 278 minecraft:light[level=15]
setblock 293 249 286 minecraft:light[level=15]
setblock 293 249 294 minecraft:light[level=15]
setblock 293 249 302 minecraft:light[level=15]
setblock 293 249 310 minecraft:light[level=15]
fill 298 249 317 298 255 317 minecraft:light_gray_concrete
setblock 301 249 278 minecraft:light[level=15]
setblock 301 249 286 minecraft:light[level=15]
setblock 301 249 294 minecraft:light[level=15]
setblock 301 249 302 minecraft:light[level=15]
setblock 301 249 310 minecraft:light[level=15]
setblock 309 249 278 minecraft:light[level=15]
setblock 309 249 286 minecraft:light[level=15]
setblock 309 249 294 minecraft:light[level=15]
setblock 309 249 302 minecraft:light[level=15]
setblock 309 249 310 minecraft:light[level=15]
setblock 317 249 278 minecraft:light[level=15]
setblock 317 249 286 minecraft:light[level=15]
setblock 317 249 294 minecraft:light[level=15]
setblock 317 249 302 minecraft:light[level=15]
setblock 317 249 310 minecraft:light[level=15]
fill 282 250 291 282 250 292 minecraft:light_gray_concrete
setblock 282 250 293 minecraft:redstone_block
fill 282 250 294 282 255 294 minecraft:light_gray_concrete
fill 285 250 311 285 250 314 minecraft:gray_concrete
setblock 286 250 278 minecraft:gray_concrete
setblock 286 250 281 minecraft:gray_concrete
fill 286 250 310 288 250 310 minecraft:gray_concrete
setblock 286 250 314 minecraft:gray_concrete
fill 287 250 282 288 250 282 minecraft:gray_concrete
setblock 288 250 314 minecraft:gray_concrete
setblock 289 250 278 minecraft:gray_concrete
setblock 289 250 281 minecraft:gray_concrete
fill 289 250 311 289 250 313 minecraft:gray_concrete
fill 290 250 279 290 250 280 minecraft:gray_concrete
fill 282 251 291 282 255 291 minecraft:light_gray_concrete
setblock 282 251 292 minecraft:redstone_block
fill 282 251 293 282 255 293 minecraft:light_gray_concrete
fill 285 251 312 285 257 312 minecraft:iron_block
fill 300 251 315 300 252 316 minecraft:iron_block
fill 282 252 292 282 255 292 minecraft:light_gray_concrete
setblock 283 252 278 minecraft:iron_block
fill 283 252 280 283 252 283 minecraft:iron_block
setblock 283 252 288 minecraft:iron_block
fill 283 252 290 283 252 293 minecraft:iron_block
setblock 283 252 298 minecraft:iron_block
fill 283 252 300 283 252 303 minecraft:iron_block
setblock 283 252 308 minecraft:iron_block
fill 283 252 310 283 252 313 minecraft:iron_block
fill 284 252 276 287 252 276 minecraft:iron_block
fill 284 252 311 284 252 313 minecraft:iron_block
setblock 285 252 311 minecraft:iron_block
setblock 285 252 313 minecraft:iron_block
setblock 285 252 316 minecraft:iron_block
fill 287 252 316 290 252 316 minecraft:iron_block
setblock 289 252 276 minecraft:iron_block
fill 294 252 276 297 252 276 minecraft:iron_block
setblock 295 252 316 minecraft:iron_block
fill 297 252 316 299 252 316 minecraft:iron_block
setblock 299 252 276 minecraft:iron_block
setblock 299 252 312 minecraft:iron_block
setblock 299 252 314 minecraft:iron_block
setblock 300 252 311 minecraft:pearlescent_froglight
setblock 301 252 312 minecraft:iron_block
setblock 301 252 314 minecraft:iron_block
fill 304 252 276 307 252 276 minecraft:iron_block
setblock 305 252 316 minecraft:iron_block
fill 307 252 316 310 252 316 minecraft:iron_block
setblock 309 252 276 minecraft:iron_block
fill 314 252 276 317 252 276 minecraft:iron_block
setblock 315 252 316 minecraft:iron_block
fill 317 252 316 320 252 316 minecraft:iron_block
setblock 319 252 276 minecraft:iron_block
fill 323 252 277 323 252 280 minecraft:iron_block
setblock 323 252 282 minecraft:iron_block
fill 323 252 287 323 252 290 minecraft:iron_block
setblock 323 252 292 minecraft:iron_block
fill 323 252 297 323 252 300 minecraft:iron_block
setblock 323 252 302 minecraft:iron_block
fill 323 252 307 323 252 310 minecraft:iron_block
setblock 323 252 312 minecraft:iron_block
setblock 285 253 278 minecraft:light[level=12]
setblock 285 253 285 minecraft:light[level=12]
setblock 285 253 292 minecraft:light[level=12]
setblock 285 253 299 minecraft:light[level=12]
setblock 285 253 306 minecraft:light[level=12]
setblock 285 253 313 minecraft:light[level=12]
setblock 292 253 278 minecraft:light[level=12]
setblock 292 253 285 minecraft:light[level=12]
setblock 292 253 292 minecraft:light[level=12]
setblock 292 253 299 minecraft:light[level=12]
setblock 292 253 306 minecraft:light[level=12]
setblock 292 253 313 minecraft:light[level=12]
setblock 299 253 278 minecraft:light[level=12]
setblock 299 253 285 minecraft:light[level=12]
setblock 299 253 292 minecraft:light[level=12]
setblock 299 253 299 minecraft:light[level=12]
setblock 299 253 306 minecraft:light[level=12]
setblock 306 253 278 minecraft:light[level=12]
setblock 306 253 285 minecraft:light[level=12]
setblock 306 253 292 minecraft:light[level=12]
setblock 306 253 299 minecraft:light[level=12]
setblock 306 253 306 minecraft:light[level=12]
setblock 306 253 313 minecraft:light[level=12]
setblock 313 253 278 minecraft:light[level=12]
setblock 313 253 285 minecraft:light[level=12]
setblock 313 253 292 minecraft:light[level=12]
setblock 313 253 299 minecraft:light[level=12]
setblock 313 253 306 minecraft:light[level=12]
setblock 313 253 313 minecraft:light[level=12]
fill 316 253 293 320 254 297 minecraft:gray_concrete
setblock 320 253 278 minecraft:light[level=12]
setblock 320 253 285 minecraft:light[level=12]
setblock 320 253 292 minecraft:light[level=12]
setblock 320 253 306 minecraft:light[level=12]
setblock 320 253 313 minecraft:light[level=12]
fill 321 253 295 322 253 295 minecraft:gray_concrete
fill 283 255 284 284 256 285 minecraft:iron_block
fill 285 255 285 298 256 285 minecraft:iron_block
fill 288 255 286 312 256 286 minecraft:iron_block
fill 303 255 287 323 256 287 minecraft:iron_block
fill 317 255 288 323 256 288 minecraft:iron_block
fill 282 256 281 282 256 284 minecraft:pearlescent_froglight
fill 282 256 291 282 256 294 minecraft:pearlescent_froglight
fill 282 256 301 282 256 304 minecraft:pearlescent_froglight
fill 282 256 311 282 256 314 minecraft:pearlescent_froglight
fill 285 256 275 288 256 275 minecraft:pearlescent_froglight
fill 286 256 317 289 256 317 minecraft:pearlescent_froglight
fill 295 256 275 298 256 275 minecraft:pearlescent_froglight
fill 296 256 317 299 256 317 minecraft:pearlescent_froglight
fill 305 256 275 308 256 275 minecraft:pearlescent_froglight
fill 306 256 317 309 256 317 minecraft:pearlescent_froglight
fill 315 256 275 318 256 275 minecraft:pearlescent_froglight
fill 316 256 317 319 256 317 minecraft:pearlescent_froglight
fill 324 256 276 324 256 279 minecraft:pearlescent_froglight
fill 324 256 286 324 256 289 minecraft:pearlescent_froglight
fill 324 256 296 324 256 299 minecraft:pearlescent_froglight
fill 324 256 306 324 256 309 minecraft:pearlescent_froglight
setblock 324 256 316 minecraft:pearlescent_froglight
fill 282 257 281 282 257 284 minecraft:light_gray_concrete
fill 282 257 291 282 257 294 minecraft:light_gray_concrete
setblock 282 257 298 minecraft:light_gray_concrete
setblock 282 257 299 minecraft:sea_lantern
fill 282 257 300 282 257 304 minecraft:light_gray_concrete
fill 282 257 311 282 257 314 minecraft:light_gray_concrete
fill 283 257 285 293 257 285 minecraft:light_gray_concrete
fill 285 257 275 288 257 275 minecraft:light_gray_concrete
setblock 285 257 278 minecraft:light[level=15]
setblock 285 257 286 minecraft:light[level=15]
setblock 285 257 294 minecraft:light[level=15]
setblock 285 257 302 minecraft:light[level=15]
setblock 285 257 310 minecraft:light[level=15]
fill 286 257 317 289 257 317 minecraft:light_gray_concrete
setblock 293 257 278 minecraft:light[level=15]
fill 293 257 286 307 257 286 minecraft:light_gray_concrete
setblock 293 257 294 minecraft:light[level=15]
setblock 293 257 302 minecraft:light[level=15]
setblock 293 257 310 minecraft:light[level=15]
fill 295 257 275 298 257 275 minecraft:light_gray_concrete
fill 296 257 317 299 257 317 minecraft:light_gray_concrete
setblock 301 257 278 minecraft:light[level=15]
setblock 301 257 294 minecraft:light[level=15]
setblock 301 257 302 minecraft:light[level=15]
setblock 301 257 310 minecraft:light[level=15]
fill 305 257 275 308 257 275 minecraft:light_gray_concrete
fill 306 257 317 309 257 317 minecraft:light_gray_concrete
fill 307 257 287 322 257 287 minecraft:light_gray_concrete
setblock 309 257 278 minecraft:light[level=15]
setblock 309 257 286 minecraft:light[level=15]
setblock 309 257 294 minecraft:light[level=15]
setblock 309 257 302 minecraft:light[level=15]
setblock 309 257 310 minecraft:light[level=15]
fill 315 257 275 318 257 275 minecraft:light_gray_concrete
fill 316 257 317 319 257 317 minecraft:light_gray_concrete
setblock 317 257 278 minecraft:light[level=15]
setblock 317 257 286 minecraft:light[level=15]
setblock 317 257 294 minecraft:light[level=15]
setblock 317 257 302 minecraft:light[level=15]
setblock 317 257 310 minecraft:light[level=15]
setblock 322 257 288 minecraft:light_gray_concrete
fill 324 257 276 324 257 279 minecraft:light_gray_concrete
fill 324 257 286 324 257 289 minecraft:light_gray_concrete
fill 324 257 296 324 257 299 minecraft:light_gray_concrete
fill 324 257 306 324 257 312 minecraft:light_gray_concrete
setblock 324 257 313 minecraft:sea_lantern
fill 324 257 314 324 257 316 minecraft:light_gray_concrete
fill 282 258 275 282 259 276 minecraft:yellow_concrete
fill 282 258 277 282 259 278 minecraft:black_concrete
fill 282 258 279 282 259 280 minecraft:yellow_concrete
fill 282 258 281 282 259 282 minecraft:black_concrete
fill 282 258 283 282 259 284 minecraft:yellow_concrete
fill 282 258 285 282 259 286 minecraft:black_concrete
fill 282 258 287 282 259 288 minecraft:yellow_concrete
fill 282 258 289 282 259 290 minecraft:black_concrete
fill 282 258 291 282 259 292 minecraft:yellow_concrete
fill 282 258 293 282 259 294 minecraft:black_concrete
fill 282 258 295 282 259 296 minecraft:yellow_concrete
fill 282 258 297 282 259 298 minecraft:black_concrete
fill 282 258 299 282 259 300 minecraft:yellow_concrete
fill 282 258 301 282 259 302 minecraft:black_concrete
fill 282 258 303 282 259 304 minecraft:yellow_concrete
fill 282 258 305 282 259 306 minecraft:black_concrete
fill 282 258 307 282 259 308 minecraft:yellow_concrete
fill 282 258 309 282 259 310 minecraft:black_concrete
fill 282 258 311 282 259 312 minecraft:yellow_concrete
fill 282 258 313 282 259 314 minecraft:black_concrete
fill 282 258 315 282 259 316 minecraft:yellow_concrete
fill 282 258 317 282 259 317 minecraft:black_concrete
fill 283 258 275 283 259 275 minecraft:yellow_concrete
setblock 283 258 278 minecraft:iron_block
setblock 283 258 288 minecraft:iron_block
setblock 283 258 298 minecraft:iron_block
setblock 283 258 308 minecraft:iron_block
fill 283 258 317 283 259 317 minecraft:yellow_concrete
fill 284 258 275 285 259 275 minecraft:black_concrete
fill 284 258 311 284 258 313 minecraft:iron_block
fill 284 258 317 285 259 317 minecraft:black_concrete
fill 285 258 311 285 258 314 minecraft:gray_concrete
setblock 285 258 316 minecraft:iron_block
fill 286 258 275 287 259 275 minecraft:yellow_concrete
setblock 286 258 278 minecraft:gray_concrete
setblock 286 258 281 minecraft:gray_concrete
fill 286 258 310 288 258 310 minecraft:gray_concrete
setblock 286 258 314 minecraft:gray_concrete
fill 286 258 317 287 259 317 minecraft:yellow_concrete
fill 287 258 282 288 258 282 minecraft:gray_concrete
fill 288 258 275 289 259 275 minecraft:black_concrete
setblock 288 258 314 minecraft:gray_concrete
fill 288 258 317 289 259 317 minecraft:black_concrete
setblock 289 258 276 minecraft:iron_block
setblock 289 258 278 minecraft:gray_concrete
setblock 289 258 281 minecraft:gray_concrete
fill 289 258 311 289 258 313 minecraft:gray_concrete
fill 290 258 275 291 259 275 minecraft:yellow_concrete
fill 290 258 279 290 258 280 minecraft:gray_concrete
fill 290 258 317 291 259 317 minecraft:yellow_concrete
fill 292 258 275 293 259 275 minecraft:black_concrete
fill 292 258 317 293 259 317 minecraft:black_concrete
fill 294 258 275 295 259 275 minecraft:yellow_concrete
fill 294 258 317 295 259 317 minecraft:yellow_concrete
setblock 295 258 316 minecraft:iron_block
fill 296 258 275 297 259 275 minecraft:black_concrete
fill 296 258 317 297 259 317 minecraft:black_concrete
fill 298 258 275 299 259 275 minecraft:yellow_concrete
fill 298 258 317 299 259 317 minecraft:yellow_concrete
setblock 299 258 276 minecraft:iron_block
fill 300 258 275 301 259 275 minecraft:black_concrete
fill 300 258 317 301 259 317 minecraft:black_concrete
fill 302 258 275 303 259 275 minecraft:yellow_concrete
fill 302 258 317 303 259 317 minecraft:yellow_concrete
fill 304 258 275 305 259 275 minecraft:black_concrete
fill 304 258 317 305 259 317 minecraft:black_concrete
setblock 305 258 316 minecraft:iron_block
fill 306 258 275 307 259 275 minecraft:yellow_concrete
fill 306 258 317 307 259 317 minecraft:yellow_concrete
fill 308 258 275 309 259 275 minecraft:black_concrete
fill 308 258 317 309 259 317 minecraft:black_concrete
setblock 309 258 276 minecraft:iron_block
fill 310 258 275 311 259 275 minecraft:yellow_concrete
fill 310 258 317 311 259 317 minecraft:yellow_concrete
fill 312 258 275 313 259 275 minecraft:black_concrete
fill 312 258 317 313 259 317 minecraft:black_concrete
fill 314 258 275 315 259 275 minecraft:yellow_concrete
fill 314 258 317 315 259 317 minecraft:yellow_concrete
fill 315 258 293 315 259 297 minecraft:iron_block
setblock 315 258 316 minecraft:iron_block
fill 316 258 275 317 259 275 minecraft:black_concrete
fill 316 258 292 316 259 293 minecraft:iron_block
fill 316 258 295 321 259 295 minecraft:iron_block
fill 316 258 297 316 259 298 minecraft:iron_block
fill 316 258 317 317 259 317 minecraft:black_concrete
fill 317 258 292 320 259 292 minecraft:iron_block
fill 317 258 298 320 259 298 minecraft:iron_block
fill 318 258 275 319 259 275 minecraft:yellow_concrete
fill 318 258 293 318 259 294 minecraft:iron_block
fill 318 258 296 318 259 297 minecraft:iron_block
fill 318 258 317 319 259 317 minecraft:yellow_concrete
setblock 319 258 276 minecraft:iron_block
fill 320 258 275 321 259 275 minecraft:black_concrete
fill 320 258 293 321 259 293 minecraft:iron_block
fill 320 258 297 321 259 297 minecraft:iron_block
fill 320 258 317 321 259 317 minecraft:black_concrete
fill 321 258 294 321 259 294 minecraft:iron_block
fill 321 258 296 321 259 296 minecraft:iron_block
fill 322 258 275 323 259 275 minecraft:yellow_concrete
fill 322 258 317 323 259 317 minecraft:yellow_concrete
setblock 323 258 282 minecraft:iron_block
setblock 323 258 292 minecraft:iron_block
setblock 323 258 302 minecraft:iron_block
setblock 323 258 312 minecraft:iron_block
fill 324 258 275 324 259 275 minecraft:black_concrete
fill 324 258 276 324 259 276 minecraft:yellow_concrete
fill 324 258 277 324 259 278 minecraft:black_concrete
fill 324 258 279 324 259 280 minecraft:yellow_concrete
fill 324 258 281 324 259 282 minecraft:black_concrete
fill 324 258 283 324 259 284 minecraft:yellow_concrete
fill 324 258 285 324 259 286 minecraft:black_concrete
fill 324 258 287 324 259 288 minecraft:yellow_concrete
fill 324 258 289 324 259 290 minecraft:black_concrete
fill 324 258 291 324 259 292 minecraft:yellow_concrete
fill 324 258 293 324 259 294 minecraft:black_concrete
fill 324 258 295 324 259 296 minecraft:yellow_concrete
fill 324 258 297 324 259 298 minecraft:black_concrete
fill 324 258 299 324 259 300 minecraft:yellow_concrete
fill 324 258 301 324 259 302 minecraft:black_concrete
fill 324 258 303 324 259 304 minecraft:yellow_concrete
fill 324 258 305 324 259 306 minecraft:black_concrete
fill 324 258 307 324 259 308 minecraft:yellow_concrete
fill 324 258 309 324 259 310 minecraft:black_concrete
fill 324 258 311 324 259 312 minecraft:yellow_concrete
fill 324 258 313 324 259 314 minecraft:black_concrete
fill 324 258 315 324 259 316 minecraft:yellow_concrete
fill 324 258 317 324 259 317 minecraft:black_concrete
setblock 285 259 278 minecraft:light[level=12]
setblock 285 259 285 minecraft:light[level=12]
setblock 285 259 292 minecraft:light[level=12]
setblock 285 259 299 minecraft:light[level=12]
setblock 285 259 306 minecraft:light[level=12]
fill 285 259 312 285 265 312 minecraft:iron_block
setblock 285 259 313 minecraft:light[level=12]
setblock 292 259 278 minecraft:light[level=12]
setblock 292 259 285 minecraft:light[level=12]
setblock 292 259 292 minecraft:light[level=12]
setblock 292 259 299 minecraft:light[level=12]
setblock 292 259 306 minecraft:light[level=12]
setblock 292 259 313 minecraft:light[level=12]
setblock 299 259 278 minecraft:light[level=12]
setblock 299 259 285 minecraft:light[level=12]
setblock 299 259 292 minecraft:light[level=12]
setblock 299 259 299 minecraft:light[level=12]
setblock 299 259 306 minecraft:light[level=12]
setblock 306 259 278 minecraft:light[level=12]
setblock 306 259 285 minecraft:light[level=12]
setblock 306 259 292 minecraft:light[level=12]
setblock 306 259 299 minecraft:light[level=12]
setblock 306 259 306 minecraft:light[level=12]
setblock 306 259 313 minecraft:light[level=12]
setblock 313 259 278 minecraft:light[level=12]
setblock 313 259 285 minecraft:light[level=12]
setblock 313 259 292 minecraft:light[level=12]
setblock 313 259 299 minecraft:light[level=12]
setblock 313 259 306 minecraft:light[level=12]
setblock 313 259 313 minecraft:light[level=12]
setblock 320 259 278 minecraft:light[level=12]
setblock 320 259 285 minecraft:light[level=12]
setblock 320 259 306 minecraft:light[level=12]
setblock 320 259 313 minecraft:light[level=12]
fill 282 260 275 282 264 317 minecraft:light_gray_concrete
fill 283 260 275 324 264 275 minecraft:light_gray_concrete
fill 283 260 317 324 264 317 minecraft:light_gray_concrete
setblock 299 260 312 minecraft:iron_block
setblock 299 260 314 minecraft:iron_block
setblock 301 260 312 minecraft:iron_block
setblock 301 260 314 minecraft:iron_block
fill 324 260 276 324 260 316 minecraft:light_gray_concrete
fill 283 261 280 283 261 283 minecraft:iron_block
fill 283 261 290 283 261 293 minecraft:iron_block
fill 283 261 300 283 261 303 minecraft:iron_block
fill 283 261 310 283 261 313 minecraft:iron_block
fill 284 261 276 287 261 276 minecraft:iron_block
fill 287 261 316 290 261 316 minecraft:iron_block
fill 294 261 276 297 261 276 minecraft:iron_block
fill 297 261 316 300 261 316 minecraft:iron_block
fill 304 261 276 307 261 276 minecraft:iron_block
fill 307 261 316 310 261 316 minecraft:iron_block
fill 314 261 276 317 261 276 minecraft:iron_block
fill 317 261 316 320 261 316 minecraft:iron_block
fill 323 261 277 323 261 280 minecraft:iron_block
fill 323 261 287 323 261 290 minecraft:iron_block
fill 323 261 297 323 261 300 minecraft:iron_block
fill 323 261 307 323 261 310 minecraft:iron_block
fill 324 261 276 324 264 280 minecraft:light_gray_concrete
setblock 324 261 281 minecraft:sea_lantern
fill 324 261 282 324 264 316 minecraft:light_gray_concrete
fill 324 262 281 324 285 281 minecraft:light_gray_concrete
fill 317 263 276 317 264 278 minecraft:iron_block
setblock 283 264 278 minecraft:iron_block
setblock 283 264 288 minecraft:iron_block
setblock 283 264 298 minecraft:iron_block
setblock 283 264 308 minecraft:iron_block
fill 284 264 311 284 264 313 minecraft:iron_block
setblock 285 264 311 minecraft:iron_block
setblock 285 264 313 minecraft:iron_block
setblock 285 264 316 minecraft:iron_block
setblock 289 264 276 minecraft:iron_block
setblock 295 264 316 minecraft:iron_block
setblock 299 264 276 minecraft:iron_block
setblock 305 264 316 minecraft:iron_block
setblock 309 264 276 minecraft:iron_block
setblock 315 264 316 minecraft:iron_block
setblock 319 264 276 minecraft:iron_block
setblock 323 264 282 minecraft:iron_block
setblock 323 264 292 minecraft:iron_block
setblock 323 264 302 minecraft:iron_block
setblock 323 264 312 minecraft:iron_block
fill 282 265 275 282 285 280 minecraft:light_gray_concrete
fill 282 265 281 282 265 284 minecraft:pearlescent_froglight
fill 282 265 285 282 279 288 minecraft:light_gray_concrete
setblock 282 265 289 minecraft:sea_lantern
fill 282 265 290 282 285 290 minecraft:light_gray_concrete
fill 282 265 291 282 265 294 minecraft:pearlescent_froglight
fill 282 265 295 282 285 300 minecraft:light_gray_concrete
fill 282 265 301 282 265 304 minecraft:pearlescent_froglight
fill 282 265 305 282 285 310 minecraft:light_gray_concrete
fill 282 265 311 282 265 314 minecraft:pearlescent_froglight
fill 282 265 315 282 285 317 minecraft:light_gray_concrete
fill 283 265 275 284 282 275 minecraft:light_gray_concrete
fill 283 265 317 285 285 317 minecraft:light_gray_concrete
fill 285 265 275 288 265 275 minecraft:pearlescent_froglight
setblock 285 265 278 minecraft:light[level=15]
setblock 285 265 285 minecraft:light[level=12]
setblock 285 265 286 minecraft:light[level=15]
setblock 285 265 292 minecraft:light[level=12]
setblock 285 265 294 minecraft:light[level=15]
setblock 285 265 299 minecraft:light[level=12]
setblock 285 265 302 minecraft:light[level=15]
setblock 285 265 306 minecraft:light[level=12]
setblock 285 265 310 minecraft:light[level=15]
setblock 285 265 313 minecraft:light[level=12]
fill 286 265 317 289 265 317 minecraft:pearlescent_froglight
fill 289 265 275 294 266 275 minecraft:light_gray_concrete
fill 290 265 317 295 285 317 minecraft:light_gray_concrete
setblock 292 265 278 minecraft:light[level=12]
setblock 292 265 285 minecraft:light[level=12]
setblock 292 265 292 minecraft:light[level=12]
setblock 292 265 299 minecraft:light[level=12]
setblock 292 265 306 minecraft:light[level=12]
setblock 292 265 313 minecraft:light[level=12]
setblock 293 265 278 minecraft:light[level=15]
setblock 293 265 286 minecraft:light[level=15]
setblock 293 265 294 minecraft:light[level=15]
setblock 293 265 302 minecraft:light[level=15]
setblock 293 265 310 minecraft:light[level=15]
fill 295 265 275 298 265 275 minecraft:pearlescent_froglight
fill 296 265 317 299 265 317 minecraft:pearlescent_froglight
fill 299 265 275 304 285 275 minecraft:light_gray_concrete
setblock 299 265 278 minecraft:light[level=12]
setblock 299 265 285 minecraft:light[level=12]
setblock 299 265 292 minecraft:light[level=12]
setblock 299 265 299 minecraft:light[level=12]
setblock 299 265 306 minecraft:light[level=12]
fill 300 265 317 305 274 317 minecraft:light_gray_concrete
setblock 301 265 278 minecraft:light[level=15]
setblock 301 265 286 minecraft:light[level=15]
setblock 301 265 294 minecraft:light[level=15]
setblock 301 265 302 minecraft:light[level=15]
setblock 301 265 310 minecraft:light[level=15]
fill 305 265 275 308 265 275 minecraft:pearlescent_froglight
setblock 306 265 278 minecraft:light[level=12]
setblock 306 265 285 minecraft:light[level=12]
setblock 306 265 292 minecraft:light[level=12]
setblock 306 265 299 minecraft:light[level=12]
setblock 306 265 306 minecraft:light[level=12]
setblock 306 265 313 minecraft:light[level=12]
fill 306 265 317 309 265 317 minecraft:pearlescent_froglight
fill 309 265 275 314 285 275 minecraft:light_gray_concrete
setblock 309 265 278 minecraft:light[level=15]
setblock 309 265 286 minecraft:light[level=15]
setblock 309 265 294 minecraft:light[level=15]
setblock 309 265 302 minecraft:light[level=15]
setblock 309 265 310 minecraft:light[level=15]
fill 310 265 317 315 276 317 minecraft:light_gray_concrete
setblock 313 265 278 minecraft:light[level=12]
setblock 313 265 285 minecraft:light[level=12]
setblock 313 265 292 minecraft:light[level=12]
setblock 313 265 299 minecraft:light[level=12]
setblock 313 265 306 minecraft:light[level=12]
setblock 313 265 313 minecraft:light[level=12]
fill 315 265 275 318 265 275 minecraft:pearlescent_froglight
fill 316 265 317 319 265 317 minecraft:pearlescent_froglight
setblock 317 265 278 minecraft:light[level=15]
setblock 317 265 286 minecraft:light[level=15]
setblock 317 265 294 minecraft:light[level=15]
setblock 317 265 302 minecraft:light[level=15]
setblock 317 265 310 minecraft:light[level=15]
fill 319 265 275 324 285 275 minecraft:light_gray_concrete
setblock 320 265 278 minecraft:light[level=12]
setblock 320 265 285 minecraft:light[level=12]
setblock 320 265 292 minecraft:light[level=12]
setblock 320 265 299 minecraft:light[level=12]
setblock 320 265 306 minecraft:light[level=12]
setblock 320 265 313 minecraft:light[level=12]
fill 320 265 317 324 270 317 minecraft:light_gray_concrete
fill 324 265 276 324 265 279 minecraft:pearlescent_froglight
fill 324 265 280 324 285 280 minecraft:light_gray_concrete
fill 324 265 282 324 285 285 minecraft:light_gray_concrete
fill 324 265 286 324 265 289 minecraft:pearlescent_froglight
fill 324 265 290 324 270 295 minecraft:light_gray_concrete
fill 324 265 296 324 265 299 minecraft:pearlescent_froglight
fill 324 265 300 324 285 305 minecraft:light_gray_concrete
fill 324 265 306 324 265 309 minecraft:pearlescent_froglight
fill 324 265 310 324 285 315 minecraft:light_gray_concrete
setblock 324 265 316 minecraft:pearlescent_froglight
fill 282 266 281 282 282 284 minecraft:light_gray_concrete
fill 282 266 289 282 285 289 minecraft:light_gray_concrete
fill 282 266 291 282 282 294 minecraft:light_gray_concrete
fill 282 266 301 282 282 304 minecraft:light_gray_concrete
fill 282 266 311 282 282 314 minecraft:light_gray_concrete
fill 285 266 275 288 282 275 minecraft:light_gray_concrete
fill 285 266 311 285 266 314 minecraft:gray_concrete
setblock 286 266 278 minecraft:gray_concrete
setblock 286 266 281 minecraft:gray_concrete
fill 286 266 310 288 266 310 minecraft:gray_concrete
setblock 286 266 314 minecraft:gray_concrete
fill 286 266 317 289 282 317 minecraft:light_gray_concrete
fill 287 266 282 288 266 282 minecraft:gray_concrete
setblock 288 266 314 minecraft:gray_concrete
setblock 289 266 278 minecraft:gray_concrete
setblock 289 266 281 minecraft:gray_concrete
fill 289 266 311 289 266 313 minecraft:gray_concrete
fill 290 266 279 290 266 280 minecraft:gray_concrete
fill 295 266 275 298 282 275 minecraft:light_gray_concrete
fill 296 266 317 299 280 317 minecraft:light_gray_concrete
fill 305 266 275 308 282 275 minecraft:light_gray_concrete
setblock 306 266 317 minecraft:sea_lantern
fill 307 266 317 309 282 317 minecraft:light_gray_concrete
fill 315 266 275 318 277 275 minecraft:light_gray_concrete
fill 316 266 317 319 282 317 minecraft:light_gray_concrete
fill 324 266 276 324 281 279 minecraft:light_gray_concrete
fill 324 266 286 324 276 289 minecraft:light_gray_concrete
fill 324 266 296 324 270 299 minecraft:light_gray_concrete
fill 324 266 306 324 282 309 minecraft:light_gray_concrete
fill 324 266 316 324 282 316 minecraft:light_gray_concrete
fill 285 267 312 285 270 312 minecraft:iron_block
fill 289 267 275 292 272 275 minecraft:light_gray_concrete
setblock 293 267 275 minecraft:redstone_block
fill 294 267 275 294 285 275 minecraft:light_gray_concrete
fill 306 267 317 306 282 317 minecraft:light_gray_concrete
fill 293 268 275 293 285 275 minecraft:light_gray_concrete
setblock 299 268 312 minecraft:iron_block
setblock 299 268 314 minecraft:iron_block
setblock 301 268 312 minecraft:iron_block
setblock 301 268 314 minecraft:iron_block
fill 320 268 283 322 269 283 minecraft:iron_block
fill 285 269 311 285 270 311 minecraft:light_gray_concrete
fill 285 269 313 285 270 313 minecraft:light_gray_concrete
fill 286 269 278 286 270 278 minecraft:light_gray_concrete
fill 286 269 281 286 270 281 minecraft:light_gray_concrete
fill 286 269 310 287 270 310 minecraft:light_gray_concrete
fill 286 269 314 286 270 314 minecraft:light_gray_concrete
fill 288 269 314 288 270 314 minecraft:light_gray_concrete
fill 289 269 278 289 270 278 minecraft:light_gray_concrete
fill 289 269 281 289 270 281 minecraft:light_gray_concrete
fill 289 269 312 289 270 313 minecraft:light_gray_concrete
setblock 283 270 278 minecraft:iron_block
fill 283 270 280 283 270 283 minecraft:iron_block
setblock 283 270 288 minecraft:iron_block
fill 283 270 290 283 270 293 minecraft:iron_block
setblock 283 270 298 minecraft:iron_block
fill 283 270 300 283 270 303 minecraft:iron_block
setblock 283 270 308 minecraft:iron_block
fill 283 270 310 283 270 313 minecraft:iron_block
fill 284 270 276 287 270 276 minecraft:iron_block
setblock 285 270 316 minecraft:iron_block
fill 287 270 316 290 270 316 minecraft:iron_block
setblock 289 270 276 minecraft:iron_block
fill 294 270 276 297 270 276 minecraft:iron_block
setblock 295 270 316 minecraft:iron_block
fill 297 270 316 300 270 316 minecraft:iron_block
setblock 299 270 276 minecraft:iron_block
fill 304 270 276 307 270 276 minecraft:iron_block
setblock 305 270 316 minecraft:iron_block
fill 307 270 316 310 270 316 minecraft:iron_block
setblock 309 270 276 minecraft:iron_block
fill 314 270 276 317 270 276 minecraft:iron_block
setblock 315 270 316 minecraft:iron_block
fill 317 270 316 320 270 316 minecraft:iron_block
setblock 319 270 276 minecraft:iron_block
fill 323 270 277 323 270 280 minecraft:iron_block
setblock 323 270 282 minecraft:iron_block
fill 323 270 287 323 270 290 minecraft:iron_block
setblock 323 270 292 minecraft:iron_block
fill 323 270 297 323 270 300 minecraft:iron_block
setblock 323 270 302 minecraft:iron_block
fill 323 270 307 323 270 310 minecraft:iron_block
setblock 323 270 312 minecraft:iron_block
setblock 285 271 278 minecraft:light[level=12]
setblock 285 271 285 minecraft:light[level=12]
setblock 285 271 292 minecraft:light[level=12]
setblock 285 271 299 minecraft:light[level=12]
setblock 285 271 306 minecraft:light[level=12]
setblock 285 271 313 minecraft:light[level=12]
setblock 292 271 278 minecraft:light[level=12]
setblock 292 271 285 minecraft:light[level=12]
setblock 292 271 292 minecraft:light[level=12]
setblock 292 271 299 minecraft:light[level=12]
setblock 292 271 306 minecraft:light[level=12]
setblock 292 271 313 minecraft:light[level=12]
setblock 299 271 278 minecraft:light[level=12]
setblock 299 271 285 minecraft:light[level=12]
setblock 299 271 292 minecraft:light[level=12]
setblock 299 271 299 minecraft:light[level=12]
setblock 299 271 306 minecraft:light[level=12]
setblock 299 271 313 minecraft:light[level=12]
setblock 306 271 278 minecraft:light[level=12]
setblock 306 271 285 minecraft:light[level=12]
setblock 306 271 292 minecraft:light[level=12]
setblock 306 271 299 minecraft:light[level=12]
setblock 306 271 306 minecraft:light[level=12]
setblock 306 271 313 minecraft:light[level=12]
setblock 313 271 278 minecraft:light[level=12]
setblock 313 271 285 minecraft:light[level=12]
setblock 313 271 292 minecraft:light[level=12]
setblock 313 271 299 minecraft:light[level=12]
setblock 313 271 306 minecraft:light[level=12]
setblock 313 271 313 minecraft:light[level=12]
setblock 320 271 278 minecraft:light[level=12]
setblock 320 271 285 minecraft:light[level=12]
setblock 320 271 292 minecraft:light[level=12]
setblock 320 271 299 minecraft:light[level=12]
setblock 320 271 306 minecraft:light[level=12]
setblock 320 271 313 minecraft:light[level=12]
setblock 320 271 317 minecraft:sea_lantern
fill 321 271 317 324 285 317 minecraft:light_gray_concrete
fill 324 271 290 324 285 293 minecraft:light_gray_concrete
setblock 324 271 294 minecraft:redstone_block
fill 324 271 295 324 282 298 minecraft:light_gray_concrete
setblock 324 271 299 minecraft:sea_lantern
fill 320 272 317 320 285 317 minecraft:light_gray_concrete
fill 324 272 294 324 282 294 minecraft:light_gray_concrete
fill 324 272 299 324 282 299 minecraft:light_gray_concrete
setblock 285 273 278 minecraft:light[level=15]
setblock 285 273 286 minecraft:light[level=15]
setblock 285 273 294 minecraft:light[level=15]
setblock 285 273 302 minecraft:light[level=15]
setblock 285 273 310 minecraft:light[level=15]
fill 289 273 275 291 285 275 minecraft:light_gray_concrete
setblock 292 273 275 minecraft:redstone_block
setblock 293 273 278 minecraft:light[level=15]
setblock 293 273 286 minecraft:light[level=15]
setblock 293 273 294 minecraft:light[level=15]
setblock 293 273 302 minecraft:light[level=15]
setblock 293 273 310 minecraft:light[level=15]
setblock 301 273 278 minecraft:light[level=15]
setblock 301 273 286 minecraft:light[level=15]
setblock 301 273 302 minecraft:light[level=15]
setblock 301 273 310 minecraft:light[level=15]
setblock 309 273 278 minecraft:light[level=15]
setblock 309 273 286 minecraft:light[level=15]
setblock 309 273 294 minecraft:light[level=15]
setblock 309 273 302 minecraft:light[level=15]
setblock 309 273 310 minecraft:light[level=15]
setblock 317 273 278 minecraft:light[level=15]
setblock 317 273 286 minecraft:light[level=15]
setblock 317 273 294 minecraft:light[level=15]
setblock 317 273 302 minecraft:light[level=15]
setblock 317 273 310 minecraft:light[level=15]
fill 292 274 275 292 285 275 minecraft:light_gray_concrete
fill 300 275 317 302 285 317 minecraft:light_gray_concrete
setblock 303 275 317 minecraft:redstone_block
fill 304 275 317 305 285 317 minecraft:light_gray_concrete
fill 292 276 285 297 278 306 minecraft:iron_block
fill 298 276 285 298 278 294 minecraft:iron_block
fill 298 276 296 298 278 306 minecraft:iron_block
fill 299 276 285 300 278 292 minecraft:iron_block
fill 299 276 298 300 278 306 minecraft:iron_block
fill 301 276 285 313 278 291 minecraft:iron_block
fill 301 276 299 313 278 306 minecraft:iron_block
fill 302 276 292 313 278 292 minecraft:iron_block
fill 302 276 298 313 278 298 minecraft:iron_block
fill 303 276 317 303 285 317 minecraft:light_gray_concrete
fill 304 276 293 313 278 294 minecraft:iron_block
fill 304 276 296 313 278 297 minecraft:iron_block
fill 305 276 295 313 278 295 minecraft:iron_block
setblock 285 277 278 minecraft:light[level=12]
setblock 285 277 285 minecraft:light[level=12]
setblock 285 277 292 minecraft:light[level=12]
setblock 285 277 299 minecraft:light[level=12]
setblock 285 277 306 minecraft:light[level=12]
setblock 285 277 313 minecraft:light[level=12]
setblock 292 277 278 minecraft:light[level=12]
setblock 292 277 313 minecraft:light[level=12]
setblock 299 277 278 minecraft:light[level=12]
setblock 299 277 313 minecraft:light[level=12]
setblock 306 277 278 minecraft:light[level=12]
setblock 306 277 313 minecraft:light[level=12]
fill 310 277 317 313 285 317 minecraft:light_gray_concrete
setblock 313 277 278 minecraft:light[level=12]
setblock 313 277 313 minecraft:light[level=12]
setblock 314 277 317 minecraft:sea_lantern
fill 315 277 317 315 285 317 minecraft:light_gray_concrete
setblock 320 277 278 minecraft:light[level=12]
setblock 320 277 285 minecraft:light[level=12]
setblock 320 277 292 minecraft:light[level=12]
setblock 320 277 299 minecraft:light[level=12]
schedule function dropper:buildpart/66_5 1t
