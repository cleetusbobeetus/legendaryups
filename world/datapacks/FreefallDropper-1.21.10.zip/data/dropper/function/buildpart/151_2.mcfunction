setblock 365 242 633 minecraft:black_concrete
fill 365 242 637 365 242 638 minecraft:black_concrete
fill 371 242 619 371 284 620 minecraft:purple_concrete
setblock 371 242 621 minecraft:magenta_stained_glass
fill 371 242 622 371 247 629 minecraft:purple_concrete
fill 329 243 612 329 245 612 minecraft:magenta_concrete
fill 329 243 628 329 245 628 minecraft:magenta_concrete
fill 329 243 644 329 245 644 minecraft:magenta_concrete
fill 333 243 604 333 245 604 minecraft:magenta_concrete
fill 333 243 646 333 289 646 minecraft:purple_concrete
setblock 334 243 646 minecraft:white_concrete
setblock 338 243 646 minecraft:crying_obsidian
fill 343 243 646 343 245 646 minecraft:magenta_concrete
fill 349 243 604 349 245 604 minecraft:magenta_concrete
fill 353 243 646 353 268 646 minecraft:purple_concrete
fill 359 243 646 359 245 646 minecraft:magenta_concrete
fill 360 243 635 361 244 636 minecraft:magenta_stained_glass
fill 362 243 619 363 243 619 minecraft:crying_obsidian
fill 365 243 604 365 245 604 minecraft:magenta_concrete
fill 371 243 614 371 245 614 minecraft:magenta_concrete
fill 371 243 621 371 307 621 minecraft:purple_concrete
fill 371 243 630 371 245 630 minecraft:magenta_concrete
fill 334 244 646 334 270 646 minecraft:purple_concrete
fill 335 244 618 336 245 618 minecraft:magenta_concrete
setblock 335 244 646 minecraft:crying_obsidian
fill 336 244 617 336 245 617 minecraft:magenta_concrete
fill 336 244 619 336 245 619 minecraft:magenta_concrete
fill 338 244 646 338 256 646 minecraft:purple_concrete
fill 362 244 617 362 244 619 minecraft:crying_obsidian
fill 363 244 617 363 244 618 minecraft:crying_obsidian
setblock 371 244 609 minecraft:magenta_stained_glass
setblock 329 245 608 minecraft:white_concrete
fill 329 245 609 329 261 611 minecraft:purple_concrete
setblock 329 245 621 minecraft:white_concrete
setblock 329 245 639 minecraft:white_concrete
fill 329 245 640 329 307 640 minecraft:purple_concrete
setblock 329 245 641 minecraft:white_concrete
fill 329 245 642 329 250 643 minecraft:purple_concrete
fill 335 245 646 335 248 646 minecraft:purple_concrete
setblock 339 245 646 minecraft:white_concrete
setblock 360 245 604 minecraft:crying_obsidian
fill 360 245 635 360 245 636 minecraft:magenta_stained_glass
setblock 361 245 635 minecraft:magenta_stained_glass
setblock 361 245 646 minecraft:crying_obsidian
fill 363 245 615 363 245 617 minecraft:crying_obsidian
setblock 371 245 606 minecraft:white_concrete
fill 371 245 609 371 307 609 minecraft:purple_concrete
setblock 371 245 632 minecraft:magenta_stained_glass
fill 371 245 640 371 275 640 minecraft:purple_concrete
setblock 371 245 641 minecraft:white_concrete
fill 329 246 608 329 263 608 minecraft:purple_concrete
fill 329 246 612 329 251 612 minecraft:purple_concrete
fill 329 246 621 329 307 621 minecraft:purple_concrete
fill 329 246 628 329 248 628 minecraft:purple_concrete
fill 329 246 639 329 305 639 minecraft:purple_concrete
fill 329 246 641 329 288 641 minecraft:purple_concrete
fill 329 246 644 329 251 644 minecraft:purple_concrete
setblock 332 246 607 minecraft:light[level=12]
setblock 332 246 615 minecraft:light[level=12]
setblock 332 246 623 minecraft:light[level=12]
setblock 332 246 631 minecraft:light[level=12]
setblock 332 246 639 minecraft:light[level=12]
fill 333 246 604 333 251 604 minecraft:purple_concrete
fill 339 246 646 339 271 646 minecraft:purple_concrete
setblock 340 246 607 minecraft:light[level=12]
setblock 340 246 615 minecraft:light[level=12]
setblock 340 246 623 minecraft:light[level=12]
setblock 340 246 631 minecraft:light[level=12]
setblock 340 246 639 minecraft:light[level=12]
fill 343 246 646 343 248 646 minecraft:purple_concrete
setblock 348 246 607 minecraft:light[level=12]
setblock 348 246 615 minecraft:light[level=12]
setblock 348 246 623 minecraft:light[level=12]
setblock 348 246 631 minecraft:light[level=12]
setblock 348 246 639 minecraft:light[level=12]
fill 349 246 604 349 251 604 minecraft:purple_concrete
fill 354 246 604 354 302 604 minecraft:purple_concrete
setblock 355 246 604 minecraft:white_concrete
fill 356 246 604 356 307 604 minecraft:purple_concrete
setblock 356 246 607 minecraft:light[level=12]
setblock 356 246 615 minecraft:light[level=12]
setblock 356 246 623 minecraft:light[level=12]
setblock 356 246 631 minecraft:light[level=12]
setblock 356 246 639 minecraft:light[level=12]
fill 359 246 646 359 251 646 minecraft:purple_concrete
fill 360 246 604 360 268 604 minecraft:purple_concrete
setblock 360 246 635 minecraft:magenta_stained_glass
fill 361 246 646 361 285 646 minecraft:purple_concrete
fill 363 246 613 363 246 615 minecraft:crying_obsidian
setblock 364 246 607 minecraft:light[level=12]
setblock 364 246 614 minecraft:crying_obsidian
setblock 364 246 615 minecraft:light[level=12]
setblock 364 246 623 minecraft:light[level=12]
setblock 364 246 631 minecraft:light[level=12]
setblock 364 246 639 minecraft:light[level=12]
fill 365 246 604 365 251 604 minecraft:purple_concrete
fill 371 246 606 371 307 606 minecraft:purple_concrete
fill 371 246 614 371 251 615 minecraft:purple_concrete
setblock 371 246 616 minecraft:crying_obsidian
fill 371 246 630 371 249 630 minecraft:purple_concrete
fill 371 246 632 371 271 632 minecraft:purple_concrete
fill 371 246 641 371 256 641 minecraft:purple_concrete
fill 329 247 635 329 307 636 minecraft:purple_concrete
setblock 329 247 637 minecraft:white_concrete
fill 329 247 638 329 284 638 minecraft:purple_concrete
fill 344 247 604 345 263 604 minecraft:purple_concrete
setblock 346 247 604 minecraft:crying_obsidian
fill 347 247 604 348 260 604 minecraft:purple_concrete
fill 355 247 604 355 288 604 minecraft:purple_concrete
fill 363 247 612 363 247 614 minecraft:crying_obsidian
fill 364 247 612 364 247 613 minecraft:crying_obsidian
fill 371 247 616 371 307 616 minecraft:purple_concrete
fill 329 248 637 329 307 637 minecraft:purple_concrete
setblock 331 248 646 minecraft:crying_obsidian
setblock 338 248 604 minecraft:crying_obsidian
setblock 346 248 604 minecraft:purple_concrete
setblock 351 248 646 minecraft:white_concrete
setblock 354 248 646 minecraft:magenta_stained_glass
setblock 364 248 612 minecraft:crying_obsidian
fill 371 248 622 371 254 627 minecraft:purple_concrete
setblock 371 248 628 minecraft:crying_obsidian
fill 371 248 629 371 303 629 minecraft:purple_concrete
setblock 329 249 628 minecraft:magenta_stained_glass
fill 331 249 646 331 307 646 minecraft:purple_concrete
setblock 335 249 646 minecraft:white_concrete
setblock 336 249 646 minecraft:magenta_stained_glass
fill 338 249 604 338 307 604 minecraft:purple_concrete
fill 340 249 635 341 250 636 minecraft:magenta_concrete
setblock 343 249 646 minecraft:crying_obsidian
setblock 346 249 604 minecraft:magenta_stained_glass
fill 351 249 646 351 292 646 minecraft:purple_concrete
fill 354 249 646 354 262 646 minecraft:purple_concrete
fill 371 249 628 371 255 628 minecraft:purple_concrete
fill 329 250 628 329 251 628 minecraft:purple_concrete
fill 335 250 646 336 257 646 minecraft:purple_concrete
setblock 340 250 604 minecraft:crying_obsidian
fill 343 250 646 343 251 646 minecraft:purple_concrete
fill 346 250 604 346 286 604 minecraft:purple_concrete
setblock 371 250 630 minecraft:magenta_stained_glass
setblock 329 251 642 minecraft:white_concrete
fill 329 251 643 329 307 643 minecraft:purple_concrete
fill 340 251 604 340 270 604 minecraft:purple_concrete
fill 343 251 611 343 252 612 minecraft:obsidian
fill 344 251 611 344 252 611 minecraft:obsidian
fill 350 251 604 351 293 604 minecraft:purple_concrete
setblock 352 251 604 minecraft:crying_obsidian
setblock 371 251 630 minecraft:purple_concrete
fill 329 252 612 329 254 612 minecraft:magenta_concrete
fill 329 252 628 329 254 628 minecraft:magenta_concrete
fill 329 252 642 329 261 642 minecraft:purple_concrete
fill 329 252 644 329 254 644 minecraft:magenta_concrete
fill 333 252 604 333 254 604 minecraft:magenta_concrete
fill 343 252 646 343 254 646 minecraft:magenta_concrete
setblock 345 252 646 minecraft:magenta_stained_glass
fill 346 252 646 347 307 646 minecraft:purple_concrete
fill 349 252 604 349 254 604 minecraft:magenta_concrete
setblock 352 252 604 minecraft:magenta_stained_glass
fill 359 252 646 359 254 646 minecraft:magenta_concrete
fill 365 252 604 365 254 604 minecraft:magenta_concrete
fill 371 252 614 371 254 614 minecraft:magenta_concrete
fill 371 252 615 371 273 615 minecraft:purple_concrete
fill 371 252 630 371 254 630 minecraft:magenta_concrete
fill 371 252 634 371 278 634 minecraft:purple_concrete
setblock 371 252 635 minecraft:crying_obsidian
fill 329 253 604 330 307 604 minecraft:purple_concrete
setblock 331 253 604 minecraft:white_concrete
fill 345 253 646 345 307 646 minecraft:purple_concrete
fill 348 253 635 348 254 636 minecraft:magenta_concrete
fill 352 253 604 352 307 604 minecraft:purple_concrete
fill 371 253 635 371 307 635 minecraft:purple_concrete
fill 329 254 626 329 307 626 minecraft:purple_concrete
setblock 329 254 627 minecraft:white_concrete
fill 331 254 604 331 307 604 minecraft:purple_concrete
setblock 332 254 607 minecraft:light[level=12]
setblock 332 254 615 minecraft:light[level=12]
setblock 332 254 623 minecraft:light[level=12]
setblock 332 254 631 minecraft:light[level=12]
setblock 332 254 639 minecraft:light[level=12]
setblock 337 254 646 minecraft:magenta_stained_glass
setblock 340 254 607 minecraft:light[level=12]
setblock 340 254 615 minecraft:light[level=12]
setblock 340 254 623 minecraft:light[level=12]
setblock 340 254 631 minecraft:light[level=12]
setblock 340 254 639 minecraft:light[level=12]
setblock 348 254 607 minecraft:light[level=12]
setblock 348 254 615 minecraft:light[level=12]
setblock 348 254 623 minecraft:light[level=12]
setblock 348 254 631 minecraft:light[level=12]
setblock 348 254 639 minecraft:light[level=12]
setblock 356 254 607 minecraft:light[level=12]
setblock 356 254 615 minecraft:light[level=12]
setblock 356 254 623 minecraft:light[level=12]
setblock 356 254 631 minecraft:light[level=12]
setblock 356 254 639 minecraft:light[level=12]
setblock 364 254 607 minecraft:light[level=12]
setblock 364 254 615 minecraft:light[level=12]
setblock 364 254 623 minecraft:light[level=12]
setblock 364 254 631 minecraft:light[level=12]
setblock 364 254 639 minecraft:light[level=12]
fill 329 255 612 329 258 613 minecraft:purple_concrete
setblock 329 255 614 minecraft:crying_obsidian
fill 329 255 627 329 260 628 minecraft:purple_concrete
fill 329 255 644 329 260 644 minecraft:purple_concrete
setblock 332 255 604 minecraft:crying_obsidian
fill 333 255 604 333 260 604 minecraft:purple_concrete
fill 337 255 646 337 263 646 minecraft:purple_concrete
fill 343 255 646 343 260 646 minecraft:purple_concrete
fill 349 255 604 349 260 604 minecraft:purple_concrete
fill 359 255 646 359 260 646 minecraft:purple_concrete
fill 365 255 604 365 260 604 minecraft:purple_concrete
fill 371 255 614 371 260 614 minecraft:purple_concrete
fill 371 255 622 371 265 624 minecraft:purple_concrete
setblock 371 255 625 minecraft:white_concrete
fill 371 255 626 371 307 627 minecraft:purple_concrete
fill 371 255 630 371 260 630 minecraft:purple_concrete
fill 329 256 614 329 283 614 minecraft:purple_concrete
fill 332 256 604 332 306 604 minecraft:purple_concrete
fill 371 256 625 371 307 625 minecraft:purple_concrete
setblock 371 256 628 minecraft:magenta_stained_glass
setblock 329 257 622 minecraft:magenta_stained_glass
fill 329 257 623 329 258 625 minecraft:purple_concrete
fill 336 257 604 336 271 604 minecraft:purple_concrete
setblock 337 257 604 minecraft:white_concrete
setblock 338 257 646 minecraft:white_concrete
setblock 339 257 604 minecraft:crying_obsidian
setblock 349 257 646 minecraft:white_concrete
fill 350 257 646 350 260 646 minecraft:purple_concrete
setblock 361 257 604 minecraft:magenta_stained_glass
fill 371 257 628 371 307 628 minecraft:purple_concrete
setblock 371 257 641 minecraft:white_concrete
fill 329 258 622 329 287 622 minecraft:purple_concrete
setblock 335 258 646 minecraft:crying_obsidian
fill 336 258 646 336 307 646 minecraft:purple_concrete
fill 337 258 604 337 272 604 minecraft:purple_concrete
fill 338 258 646 338 307 646 minecraft:purple_concrete
fill 339 258 604 339 307 604 minecraft:purple_concrete
fill 344 258 611 345 259 611 minecraft:obsidian
fill 349 258 646 349 277 646 minecraft:purple_concrete
fill 361 258 604 361 307 604 minecraft:purple_concrete
setblock 368 258 646 minecraft:crying_obsidian
fill 371 258 641 371 277 641 minecraft:purple_concrete
fill 329 259 612 329 260 612 minecraft:purple_concrete
setblock 329 259 613 minecraft:white_concrete
fill 329 259 623 329 261 623 minecraft:purple_concrete
setblock 329 259 624 minecraft:magenta_stained_glass
fill 329 259 625 329 307 625 minecraft:purple_concrete
fill 335 259 646 335 307 646 minecraft:purple_concrete
fill 368 259 646 368 266 646 minecraft:purple_concrete
setblock 371 259 637 minecraft:crying_obsidian
setblock 371 259 638 minecraft:white_concrete
setblock 371 259 644 minecraft:magenta_stained_glass
fill 329 260 613 329 278 613 minecraft:purple_concrete
fill 329 260 624 329 270 624 minecraft:purple_concrete
fill 365 260 616 366 261 617 minecraft:obsidian
fill 371 260 637 371 302 638 minecraft:purple_concrete
fill 371 260 644 371 307 644 minecraft:purple_concrete
fill 329 261 612 329 263 612 minecraft:magenta_concrete
fill 329 261 618 329 307 619 minecraft:purple_concrete
setblock 329 261 620 minecraft:magenta_stained_glass
fill 329 261 627 329 307 627 minecraft:purple_concrete
fill 329 261 628 329 263 628 minecraft:magenta_concrete
setblock 329 261 629 minecraft:magenta_stained_glass
setblock 329 261 630 minecraft:white_concrete
setblock 329 261 634 minecraft:crying_obsidian
fill 329 261 644 329 263 644 minecraft:magenta_concrete
fill 333 261 604 333 263 604 minecraft:magenta_concrete
fill 343 261 646 343 263 646 minecraft:magenta_concrete
fill 347 261 604 347 307 604 minecraft:purple_concrete
setblock 348 261 604 minecraft:crying_obsidian
fill 349 261 604 349 263 604 minecraft:magenta_concrete
setblock 350 261 646 minecraft:white_concrete
fill 359 261 646 359 263 646 minecraft:magenta_concrete
fill 365 261 604 365 263 604 minecraft:magenta_concrete
fill 371 261 614 371 263 614 minecraft:magenta_concrete
fill 371 261 630 371 263 630 minecraft:magenta_concrete
setblock 329 262 609 minecraft:white_concrete
fill 329 262 610 329 307 611 minecraft:purple_concrete
fill 329 262 620 329 307 620 minecraft:purple_concrete
setblock 329 262 623 minecraft:crying_obsidian
fill 329 262 629 329 274 630 minecraft:purple_concrete
fill 329 262 634 329 307 634 minecraft:purple_concrete
setblock 329 262 642 minecraft:crying_obsidian
setblock 332 262 607 minecraft:light[level=12]
setblock 332 262 615 minecraft:light[level=12]
setblock 332 262 623 minecraft:light[level=12]
setblock 332 262 631 minecraft:light[level=12]
setblock 332 262 639 minecraft:light[level=12]
fill 333 262 625 333 263 625 minecraft:gold_block
setblock 340 262 607 minecraft:light[level=12]
setblock 340 262 615 minecraft:light[level=12]
setblock 340 262 623 minecraft:light[level=12]
setblock 340 262 631 minecraft:light[level=12]
setblock 340 262 639 minecraft:light[level=12]
setblock 340 262 646 minecraft:magenta_stained_glass
fill 341 262 646 341 268 646 minecraft:purple_concrete
fill 348 262 604 348 307 604 minecraft:purple_concrete
setblock 348 262 607 minecraft:light[level=12]
setblock 348 262 615 minecraft:light[level=12]
setblock 348 262 623 minecraft:light[level=12]
setblock 348 262 631 minecraft:light[level=12]
setblock 348 262 639 minecraft:light[level=12]
fill 350 262 646 350 307 646 minecraft:purple_concrete
setblock 356 262 607 minecraft:light[level=12]
setblock 356 262 615 minecraft:light[level=12]
setblock 356 262 623 minecraft:light[level=12]
setblock 356 262 631 minecraft:light[level=12]
setblock 356 262 639 minecraft:light[level=12]
setblock 364 262 607 minecraft:light[level=12]
setblock 364 262 615 minecraft:light[level=12]
setblock 364 262 623 minecraft:light[level=12]
setblock 364 262 631 minecraft:light[level=12]
setblock 364 262 639 minecraft:light[level=12]
setblock 371 262 613 minecraft:crying_obsidian
fill 329 263 609 329 307 609 minecraft:purple_concrete
fill 329 263 623 329 277 623 minecraft:purple_concrete
fill 329 263 642 329 305 642 minecraft:purple_concrete
fill 340 263 617 340 264 618 minecraft:obsidian
fill 340 263 646 340 307 646 minecraft:purple_concrete
setblock 354 263 646 minecraft:crying_obsidian
setblock 369 263 646 minecraft:crying_obsidian
fill 371 263 613 371 307 613 minecraft:purple_concrete
setblock 329 264 608 minecraft:crying_obsidian
fill 329 264 612 329 269 612 minecraft:purple_concrete
fill 329 264 628 329 269 628 minecraft:purple_concrete
fill 329 264 644 329 269 644 minecraft:purple_concrete
setblock 332 264 646 minecraft:magenta_stained_glass
setblock 333 264 604 minecraft:purple_concrete
setblock 337 264 646 minecraft:white_concrete
fill 343 264 646 343 269 646 minecraft:purple_concrete
setblock 344 264 604 minecraft:magenta_stained_glass
fill 345 264 604 345 266 604 minecraft:purple_concrete
fill 346 264 637 346 265 638 minecraft:gold_block
fill 349 264 604 349 269 604 minecraft:purple_concrete
fill 354 264 646 354 307 646 minecraft:purple_concrete
fill 359 264 646 359 269 646 minecraft:purple_concrete
fill 365 264 604 365 269 604 minecraft:purple_concrete
fill 369 264 646 369 307 646 minecraft:purple_concrete
setblock 371 264 614 minecraft:purple_concrete
fill 371 264 630 371 269 630 minecraft:purple_concrete
fill 329 265 608 329 307 608 minecraft:purple_concrete
fill 332 265 646 332 296 646 minecraft:purple_concrete
setblock 333 265 604 minecraft:magenta_stained_glass
fill 337 265 646 337 270 646 minecraft:purple_concrete
fill 344 265 604 344 271 604 minecraft:purple_concrete
fill 363 265 625 363 266 625 minecraft:crying_obsidian
setblock 371 265 614 minecraft:crying_obsidian
fill 332 266 623 333 267 624 minecraft:obsidian
fill 333 266 604 333 269 604 minecraft:purple_concrete
fill 355 266 646 356 293 646 minecraft:purple_concrete
setblock 357 266 646 minecraft:magenta_stained_glass
fill 358 266 646 358 270 646 minecraft:purple_concrete
fill 363 266 624 364 266 624 minecraft:crying_obsidian
fill 364 266 623 364 267 623 minecraft:crying_obsidian
setblock 371 266 610 minecraft:crying_obsidian
fill 371 266 611 371 307 611 minecraft:purple_concrete
fill 371 266 614 371 269 614 minecraft:purple_concrete
setblock 371 266 622 minecraft:magenta_stained_glass
fill 371 266 623 371 307 624 minecraft:purple_concrete
setblock 345 267 604 minecraft:crying_obsidian
fill 357 267 646 357 307 646 minecraft:purple_concrete
fill 364 267 622 365 267 622 minecraft:crying_obsidian
setblock 365 267 623 minecraft:crying_obsidian
setblock 368 267 646 minecraft:crying_obsidian
fill 371 267 610 371 287 610 minecraft:purple_concrete
fill 371 267 622 371 293 622 minecraft:purple_concrete
fill 329 268 605 329 307 605 minecraft:purple_concrete
setblock 329 268 606 minecraft:white_concrete
fill 345 268 604 345 307 604 minecraft:purple_concrete
fill 365 268 621 365 268 622 minecraft:crying_obsidian
fill 366 268 620 366 268 621 minecraft:crying_obsidian
fill 368 268 646 368 292 646 minecraft:purple_concrete
setblock 370 268 604 minecraft:magenta_stained_glass
fill 329 269 606 329 307 606 minecraft:purple_concrete
setblock 329 269 615 minecraft:white_concrete
setblock 341 269 646 minecraft:crying_obsidian
setblock 353 269 646 minecraft:magenta_stained_glass
setblock 360 269 604 minecraft:white_concrete
fill 366 269 604 366 298 604 minecraft:purple_concrete
fill 366 269 619 366 269 620 minecraft:crying_obsidian
setblock 367 269 604 minecraft:magenta_stained_glass
fill 367 269 619 367 270 619 minecraft:crying_obsidian
fill 368 269 604 370 284 604 minecraft:purple_concrete
fill 329 270 612 329 272 612 minecraft:magenta_concrete
fill 329 270 615 329 307 615 minecraft:purple_concrete
fill 329 270 628 329 272 628 minecraft:magenta_concrete
fill 329 270 644 329 272 644 minecraft:magenta_concrete
setblock 332 270 607 minecraft:light[level=12]
setblock 332 270 615 minecraft:light[level=12]
setblock 332 270 623 minecraft:light[level=12]
setblock 332 270 631 minecraft:light[level=12]
setblock 332 270 639 minecraft:light[level=12]
fill 333 270 604 333 272 604 minecraft:magenta_concrete
setblock 340 270 607 minecraft:light[level=12]
setblock 340 270 615 minecraft:light[level=12]
setblock 340 270 623 minecraft:light[level=12]
setblock 340 270 631 minecraft:light[level=12]
setblock 340 270 639 minecraft:light[level=12]
fill 341 270 646 341 307 646 minecraft:purple_concrete
fill 343 270 646 343 272 646 minecraft:magenta_concrete
setblock 348 270 607 minecraft:light[level=12]
setblock 348 270 615 minecraft:light[level=12]
setblock 348 270 631 minecraft:light[level=12]
setblock 348 270 639 minecraft:light[level=12]
fill 349 270 604 349 272 604 minecraft:magenta_concrete
setblock 352 270 646 minecraft:white_concrete
setblock 353 270 646 minecraft:crying_obsidian
setblock 356 270 607 minecraft:light[level=12]
setblock 356 270 615 minecraft:light[level=12]
setblock 356 270 623 minecraft:light[level=12]
setblock 356 270 631 minecraft:light[level=12]
setblock 356 270 639 minecraft:light[level=12]
fill 359 270 646 359 272 646 minecraft:magenta_concrete
fill 360 270 604 360 307 604 minecraft:purple_concrete
setblock 364 270 607 minecraft:light[level=12]
setblock 364 270 615 minecraft:light[level=12]
setblock 364 270 623 minecraft:light[level=12]
setblock 364 270 631 minecraft:light[level=12]
setblock 364 270 639 minecraft:light[level=12]
fill 365 270 604 365 272 604 minecraft:magenta_concrete
setblock 366 270 619 minecraft:crying_obsidian
fill 367 270 604 367 273 604 minecraft:purple_concrete
fill 367 270 617 367 270 618 minecraft:crying_obsidian
fill 371 270 614 371 272 614 minecraft:magenta_concrete
fill 371 270 630 371 272 630 minecraft:magenta_concrete
setblock 329 271 624 minecraft:crying_obsidian
setblock 334 271 646 minecraft:white_concrete
setblock 337 271 646 minecraft:crying_obsidian
fill 339 271 617 339 272 618 minecraft:obsidian
setblock 340 271 604 minecraft:crying_obsidian
fill 352 271 646 353 307 646 minecraft:purple_concrete
setblock 358 271 646 minecraft:white_concrete
setblock 367 271 617 minecraft:crying_obsidian
setblock 371 271 608 minecraft:crying_obsidian
fill 329 272 624 329 299 624 minecraft:purple_concrete
fill 334 272 646 334 286 646 minecraft:purple_concrete
setblock 336 272 604 minecraft:crying_obsidian
fill 337 272 646 337 307 646 minecraft:purple_concrete
setblock 339 272 646 minecraft:white_concrete
fill 340 272 604 340 276 604 minecraft:purple_concrete
setblock 344 272 604 minecraft:crying_obsidian
fill 347 272 613 347 273 614 minecraft:gold_block
fill 358 272 646 358 307 646 minecraft:purple_concrete
setblock 365 272 646 minecraft:magenta_stained_glass
fill 366 272 646 367 288 646 minecraft:purple_concrete
fill 371 272 608 371 296 608 minecraft:purple_concrete
setblock 371 272 632 minecraft:magenta_stained_glass
fill 329 273 612 329 287 612 minecraft:purple_concrete
fill 329 273 628 329 287 628 minecraft:purple_concrete
fill 329 273 644 329 287 644 minecraft:purple_concrete
fill 333 273 604 333 287 604 minecraft:purple_concrete
fill 336 273 604 336 274 604 minecraft:purple_concrete
setblock 337 273 604 minecraft:white_concrete
fill 339 273 646 339 282 646 minecraft:purple_concrete
fill 343 273 646 343 287 646 minecraft:purple_concrete
fill 344 273 604 344 307 604 minecraft:purple_concrete
fill 349 273 604 349 287 604 minecraft:purple_concrete
fill 359 273 646 359 287 646 minecraft:purple_concrete
setblock 365 273 604 minecraft:purple_concrete
fill 365 273 646 365 307 646 minecraft:purple_concrete
fill 371 273 614 371 287 614 minecraft:purple_concrete
fill 371 273 630 371 279 630 minecraft:purple_concrete
fill 371 273 632 371 307 632 minecraft:purple_concrete
fill 337 274 604 337 307 604 minecraft:purple_concrete
setblock 362 274 604 minecraft:crying_obsidian
setblock 365 274 604 minecraft:crying_obsidian
setblock 367 274 604 minecraft:white_concrete
setblock 371 274 615 minecraft:crying_obsidian
fill 329 275 629 329 298 629 minecraft:purple_concrete
setblock 329 275 630 minecraft:white_concrete
setblock 329 275 633 minecraft:crying_obsidian
setblock 336 275 604 minecraft:white_concrete
fill 362 275 604 362 298 604 minecraft:purple_concrete
fill 365 275 604 365 287 604 minecraft:purple_concrete
fill 367 275 604 367 307 604 minecraft:purple_concrete
fill 371 275 615 371 307 615 minecraft:purple_concrete
setblock 371 275 618 minecraft:magenta_stained_glass
fill 329 276 630 329 307 630 minecraft:purple_concrete
fill 329 276 633 329 293 633 minecraft:purple_concrete
fill 336 276 604 336 307 604 minecraft:purple_concrete
setblock 364 276 604 minecraft:magenta_stained_glass
fill 371 276 618 371 307 618 minecraft:purple_concrete
setblock 371 276 640 minecraft:white_concrete
setblock 340 277 604 minecraft:crying_obsidian
setblock 363 277 646 minecraft:white_concrete
fill 364 277 604 364 307 604 minecraft:purple_concrete
fill 364 277 646 364 287 646 minecraft:purple_concrete
fill 371 277 640 371 307 640 minecraft:purple_concrete
setblock 329 278 623 minecraft:magenta_stained_glass
setblock 332 278 607 minecraft:light[level=12]
setblock 332 278 615 minecraft:light[level=12]
setblock 332 278 623 minecraft:light[level=12]
setblock 332 278 631 minecraft:light[level=12]
setblock 332 278 639 minecraft:light[level=12]
fill 340 278 604 340 289 604 minecraft:purple_concrete
setblock 340 278 607 minecraft:light[level=12]
setblock 340 278 615 minecraft:light[level=12]
setblock 340 278 623 minecraft:light[level=12]
setblock 340 278 631 minecraft:light[level=12]
setblock 340 278 639 minecraft:light[level=12]
setblock 348 278 607 minecraft:light[level=12]
setblock 348 278 615 minecraft:light[level=12]
setblock 348 278 631 minecraft:light[level=12]
setblock 348 278 639 minecraft:light[level=12]
setblock 349 278 646 minecraft:magenta_stained_glass
setblock 356 278 607 minecraft:light[level=12]
setblock 356 278 615 minecraft:light[level=12]
setblock 356 278 623 minecraft:light[level=12]
setblock 356 278 631 minecraft:light[level=12]
setblock 356 278 639 minecraft:light[level=12]
setblock 358 278 604 minecraft:crying_obsidian
fill 363 278 646 363 307 646 minecraft:purple_concrete
setblock 364 278 607 minecraft:light[level=12]
setblock 364 278 615 minecraft:light[level=12]
setblock 364 278 623 minecraft:light[level=12]
setblock 364 278 631 minecraft:light[level=12]
setblock 364 278 639 minecraft:light[level=12]
setblock 371 278 641 minecraft:crying_obsidian
setblock 329 279 613 minecraft:crying_obsidian
fill 329 279 623 329 307 623 minecraft:purple_concrete
fill 335 279 616 341 280 616 minecraft:magenta_concrete
fill 335 279 630 341 280 630 minecraft:magenta_concrete
fill 336 279 617 343 279 618 minecraft:magenta_concrete
fill 336 279 628 343 279 629 minecraft:magenta_concrete
fill 337 279 619 356 279 619 minecraft:magenta_concrete
fill 337 279 627 356 279 627 minecraft:magenta_concrete
fill 338 279 620 358 279 620 minecraft:magenta_concrete
fill 338 279 626 358 279 626 minecraft:magenta_concrete
fill 339 279 621 348 279 621 minecraft:magenta_concrete
fill 339 279 625 348 279 625 minecraft:magenta_concrete
fill 340 279 622 347 279 622 minecraft:magenta_concrete
fill 340 279 624 347 279 624 minecraft:magenta_concrete
fill 342 279 623 346 279 623 minecraft:magenta_concrete
fill 344 279 613 349 279 615 minecraft:magenta_concrete
fill 344 279 618 356 279 618 minecraft:magenta_concrete
fill 344 279 628 356 279 628 minecraft:magenta_concrete
fill 344 279 631 349 279 633 minecraft:magenta_concrete
fill 345 279 609 347 280 612 minecraft:magenta_concrete
fill 345 279 616 357 279 617 minecraft:magenta_concrete
fill 345 279 629 357 279 630 minecraft:magenta_concrete
fill 345 279 634 347 280 637 minecraft:magenta_concrete
fill 346 279 608 346 280 608 minecraft:magenta_concrete
fill 346 279 638 346 280 638 minecraft:magenta_concrete
fill 348 279 610 348 280 612 minecraft:magenta_concrete
fill 348 279 634 348 280 636 minecraft:magenta_concrete
fill 349 279 612 349 280 612 minecraft:magenta_concrete
fill 349 279 634 349 280 634 minecraft:magenta_concrete
fill 349 279 646 349 307 646 minecraft:purple_concrete
fill 350 279 614 350 280 615 minecraft:magenta_concrete
fill 350 279 621 361 279 621 minecraft:magenta_concrete
fill 350 279 625 361 279 625 minecraft:magenta_concrete
fill 350 279 631 350 280 632 minecraft:magenta_concrete
fill 351 279 622 363 279 622 minecraft:magenta_concrete
fill 351 279 624 363 279 624 minecraft:magenta_concrete
fill 352 279 615 358 279 615 minecraft:magenta_concrete
fill 352 279 623 365 279 623 minecraft:magenta_concrete
fill 352 279 631 358 279 631 minecraft:magenta_concrete
fill 353 279 614 358 280 614 minecraft:magenta_concrete
fill 353 279 632 358 280 632 minecraft:magenta_concrete
fill 354 279 613 358 280 613 minecraft:magenta_concrete
fill 354 279 633 358 280 633 minecraft:magenta_concrete
fill 355 279 612 358 280 612 minecraft:magenta_concrete
fill 355 279 634 358 280 634 minecraft:magenta_concrete
fill 358 279 604 358 307 604 minecraft:purple_concrete
fill 358 279 611 358 280 611 minecraft:magenta_concrete
fill 358 279 635 358 280 635 minecraft:magenta_concrete
setblock 371 279 634 minecraft:crying_obsidian
fill 371 279 641 371 280 641 minecraft:purple_concrete
fill 329 280 613 329 307 613 minecraft:purple_concrete
fill 330 280 605 334 280 645 minecraft:black_concrete
fill 335 280 605 343 280 615 minecraft:black_concrete
fill 335 280 617 335 280 629 minecraft:black_concrete
fill 335 280 631 343 280 645 minecraft:black_concrete
fill 336 280 617 339 280 618 minecraft:magenta_concrete
fill 336 280 619 336 280 627 minecraft:black_concrete
fill 336 280 628 339 280 629 minecraft:magenta_concrete
fill 337 280 619 339 280 619 minecraft:magenta_concrete
fill 337 280 620 337 280 626 minecraft:black_concrete
fill 337 280 627 339 280 627 minecraft:magenta_concrete
fill 338 280 620 340 280 620 minecraft:magenta_concrete
fill 338 280 621 338 280 625 minecraft:black_concrete
fill 338 280 626 340 280 626 minecraft:magenta_concrete
fill 339 280 621 340 280 621 minecraft:magenta_concrete
fill 339 280 622 339 280 624 minecraft:black_concrete
fill 339 280 625 340 280 625 minecraft:magenta_concrete
fill 340 280 617 343 280 617 minecraft:magenta_concrete
fill 340 280 618 343 280 619 minecraft:purple_concrete
fill 340 280 622 342 280 622 minecraft:magenta_concrete
fill 340 280 623 341 280 623 minecraft:black_concrete
fill 340 280 624 342 280 624 minecraft:magenta_concrete
fill 340 280 627 343 280 628 minecraft:purple_concrete
fill 340 280 629 343 280 629 minecraft:magenta_concrete
fill 341 280 620 345 280 621 minecraft:purple_concrete
fill 341 280 625 345 280 626 minecraft:purple_concrete
fill 342 280 616 344 280 616 minecraft:black_concrete
fill 342 280 623 343 280 623 minecraft:magenta_concrete
fill 342 280 630 344 280 630 minecraft:black_concrete
fill 343 280 622 345 280 622 minecraft:purple_concrete
fill 343 280 624 345 280 624 minecraft:purple_concrete
fill 344 280 605 344 280 612 minecraft:black_concrete
fill 344 280 613 345 280 615 minecraft:magenta_concrete
setblock 344 280 617 minecraft:black_concrete
fill 344 280 618 345 280 618 minecraft:magenta_concrete
fill 344 280 619 348 280 619 minecraft:purple_concrete
setblock 344 280 623 minecraft:purple_concrete
fill 344 280 627 348 280 627 minecraft:purple_concrete
fill 344 280 628 345 280 628 minecraft:magenta_concrete
setblock 344 280 629 minecraft:black_concrete
fill 344 280 631 345 280 633 minecraft:magenta_concrete
fill 344 280 634 344 280 645 minecraft:black_concrete
fill 345 280 605 345 280 608 minecraft:black_concrete
fill 345 280 616 345 280 617 minecraft:magenta_concrete
fill 345 280 623 346 280 623 minecraft:crying_obsidian
fill 345 280 629 345 280 630 minecraft:magenta_concrete
fill 345 280 638 345 280 645 minecraft:black_concrete
fill 346 280 605 370 280 607 minecraft:black_concrete
setblock 346 280 613 minecraft:magenta_concrete
fill 346 280 614 348 280 618 minecraft:purple_concrete
setblock 346 280 620 minecraft:purple_concrete
fill 346 280 621 347 280 622 minecraft:crying_obsidian
fill 346 280 624 347 280 625 minecraft:crying_obsidian
setblock 346 280 626 minecraft:purple_concrete
fill 346 280 628 348 280 632 minecraft:purple_concrete
setblock 346 280 633 minecraft:magenta_concrete
fill 346 280 639 370 280 645 minecraft:black_concrete
fill 347 280 608 370 280 608 minecraft:black_concrete
setblock 347 280 613 minecraft:purple_concrete
fill 347 280 620 351 280 620 minecraft:crying_obsidian
fill 347 280 626 351 280 626 minecraft:crying_obsidian
setblock 347 280 633 minecraft:purple_concrete
fill 347 280 638 370 280 638 minecraft:black_concrete
fill 348 280 609 370 280 609 minecraft:black_concrete
fill 348 280 613 349 280 613 minecraft:magenta_concrete
setblock 348 280 621 minecraft:crying_obsidian
setblock 348 280 625 minecraft:crying_obsidian
fill 348 280 633 349 280 633 minecraft:magenta_concrete
fill 348 280 637 370 280 637 minecraft:black_concrete
fill 349 280 610 357 280 611 minecraft:black_concrete
setblock 349 280 614 minecraft:magenta_concrete
fill 349 280 615 349 280 618 minecraft:purple_concrete
setblock 349 280 619 minecraft:crying_obsidian
setblock 349 280 627 minecraft:crying_obsidian
fill 349 280 628 349 280 631 minecraft:purple_concrete
setblock 349 280 632 minecraft:magenta_concrete
fill 349 280 635 357 280 636 minecraft:black_concrete
fill 350 280 612 353 280 613 minecraft:black_concrete
fill 350 280 616 350 280 617 minecraft:magenta_concrete
fill 350 280 618 354 280 619 minecraft:purple_concrete
fill 350 280 621 352 280 621 minecraft:crying_obsidian
fill 350 280 625 352 280 625 minecraft:crying_obsidian
fill 350 280 627 354 280 628 minecraft:purple_concrete
fill 350 280 629 350 280 630 minecraft:magenta_concrete
fill 350 280 633 353 280 634 minecraft:black_concrete
fill 351 280 614 351 280 615 minecraft:black_concrete
fill 351 280 616 352 280 616 minecraft:magenta_concrete
fill 351 280 617 355 280 617 minecraft:purple_concrete
fill 351 280 622 352 280 622 minecraft:crying_obsidian
fill 351 280 624 352 280 624 minecraft:crying_obsidian
fill 351 280 629 355 280 629 minecraft:purple_concrete
fill 351 280 630 352 280 630 minecraft:magenta_concrete
fill 351 280 631 351 280 632 minecraft:black_concrete
setblock 352 280 614 minecraft:black_concrete
fill 352 280 615 353 280 615 minecraft:magenta_concrete
fill 352 280 620 354 280 620 minecraft:purple_concrete
fill 352 280 623 353 280 623 minecraft:crying_obsidian
fill 352 280 626 354 280 626 minecraft:purple_concrete
fill 352 280 631 353 280 631 minecraft:magenta_concrete
setblock 352 280 632 minecraft:black_concrete
fill 353 280 616 355 280 616 minecraft:purple_concrete
fill 353 280 621 356 280 622 minecraft:purple_concrete
fill 353 280 624 356 280 625 minecraft:purple_concrete
fill 353 280 630 355 280 630 minecraft:purple_concrete
setblock 354 280 612 minecraft:black_concrete
fill 354 280 615 355 280 615 minecraft:purple_concrete
fill 354 280 623 360 280 623 minecraft:purple_concrete
fill 354 280 631 355 280 631 minecraft:purple_concrete
setblock 354 280 634 minecraft:black_concrete
setblock 355 280 618 minecraft:purple_concrete
fill 355 280 619 356 280 620 minecraft:magenta_concrete
fill 355 280 626 356 280 627 minecraft:magenta_concrete
setblock 355 280 628 minecraft:purple_concrete
fill 356 280 615 356 280 618 minecraft:magenta_concrete
fill 356 280 628 356 280 631 minecraft:magenta_concrete
fill 357 280 615 357 280 617 minecraft:magenta_concrete
fill 357 280 618 370 280 619 minecraft:black_concrete
fill 357 280 620 358 280 621 minecraft:magenta_concrete
fill 357 280 622 358 280 622 minecraft:purple_concrete
fill 357 280 624 358 280 624 minecraft:purple_concrete
fill 357 280 625 358 280 626 minecraft:magenta_concrete
fill 357 280 627 370 280 628 minecraft:black_concrete
fill 357 280 629 357 280 631 minecraft:magenta_concrete
fill 358 280 610 370 280 610 minecraft:black_concrete
setblock 358 280 615 minecraft:magenta_concrete
fill 358 280 616 370 280 617 minecraft:black_concrete
fill 358 280 629 370 280 630 minecraft:black_concrete
setblock 358 280 631 minecraft:magenta_concrete
fill 358 280 636 370 280 636 minecraft:black_concrete
fill 359 280 611 370 280 615 minecraft:black_concrete
fill 359 280 620 370 280 620 minecraft:black_concrete
fill 359 280 621 361 280 622 minecraft:magenta_concrete
fill 359 280 624 361 280 625 minecraft:magenta_concrete
fill 359 280 626 370 280 626 minecraft:black_concrete
fill 359 280 631 370 280 635 minecraft:black_concrete
fill 361 280 623 365 280 623 minecraft:magenta_concrete
fill 362 280 621 370 280 621 minecraft:black_concrete
fill 362 280 622 363 280 622 minecraft:magenta_concrete
fill 362 280 624 363 280 624 minecraft:magenta_concrete
fill 362 280 625 370 280 625 minecraft:black_concrete
fill 364 280 622 370 280 622 minecraft:black_concrete
fill 364 280 624 370 280 624 minecraft:black_concrete
fill 366 280 623 370 280 623 minecraft:black_concrete
setblock 371 280 630 minecraft:magenta_stained_glass
fill 371 280 634 371 307 634 minecraft:purple_concrete
setblock 329 281 632 minecraft:magenta_stained_glass
fill 371 281 630 371 283 630 minecraft:purple_concrete
setblock 371 281 641 minecraft:crying_obsidian
fill 329 282 632 329 307 632 minecraft:purple_concrete
fill 371 282 641 371 307 641 minecraft:purple_concrete
setblock 339 283 646 minecraft:crying_obsidian
setblock 348 283 646 minecraft:magenta_stained_glass
setblock 371 283 617 minecraft:white_concrete
setblock 329 284 614 minecraft:white_concrete
fill 329 284 616 329 307 616 minecraft:purple_concrete
setblock 329 284 617 minecraft:crying_obsidian
fill 339 284 646 339 307 646 minecraft:purple_concrete
fill 348 284 646 348 296 646 minecraft:purple_concrete
fill 359 284 634 360 285 634 minecraft:crying_obsidian
fill 371 284 617 371 307 617 minecraft:purple_concrete
setblock 371 284 630 minecraft:crying_obsidian
fill 329 285 614 329 307 614 minecraft:purple_concrete
fill 329 285 617 329 307 617 minecraft:purple_concrete
setblock 329 285 638 minecraft:crying_obsidian
fill 361 285 633 361 286 634 minecraft:crying_obsidian
fill 368 285 604 368 307 604 minecraft:purple_concrete
setblock 369 285 604 minecraft:white_concrete
fill 370 285 604 371 302 604 minecraft:purple_concrete
setblock 371 285 605 minecraft:white_concrete
setblock 371 285 619 minecraft:magenta_stained_glass
fill 371 285 620 371 304 620 minecraft:purple_concrete
fill 371 285 630 371 287 630 minecraft:purple_concrete
setblock 371 285 642 minecraft:magenta_stained_glass
fill 371 285 643 371 307 643 minecraft:purple_concrete
fill 329 286 638 329 307 638 minecraft:purple_concrete
setblock 332 286 607 minecraft:light[level=12]
setblock 332 286 615 minecraft:light[level=12]
setblock 332 286 623 minecraft:light[level=12]
setblock 332 286 631 minecraft:light[level=12]
setblock 332 286 639 minecraft:light[level=12]
setblock 340 286 607 minecraft:light[level=12]
setblock 340 286 615 minecraft:light[level=12]
setblock 340 286 623 minecraft:light[level=12]
setblock 340 286 631 minecraft:light[level=12]
setblock 340 286 639 minecraft:light[level=12]
setblock 348 286 607 minecraft:light[level=12]
setblock 348 286 615 minecraft:light[level=12]
setblock 348 286 631 minecraft:light[level=12]
setblock 348 286 639 minecraft:light[level=12]
setblock 356 286 607 minecraft:light[level=12]
setblock 356 286 615 minecraft:light[level=12]
setblock 356 286 623 minecraft:light[level=12]
setblock 356 286 631 minecraft:light[level=12]
setblock 356 286 639 minecraft:light[level=12]
setblock 361 286 646 minecraft:magenta_stained_glass
fill 362 286 633 362 286 634 minecraft:crying_obsidian
fill 363 286 633 363 287 633 minecraft:crying_obsidian
setblock 364 286 607 minecraft:light[level=12]
setblock 364 286 615 minecraft:light[level=12]
setblock 364 286 623 minecraft:light[level=12]
setblock 364 286 631 minecraft:light[level=12]
setblock 364 286 639 minecraft:light[level=12]
fill 369 286 604 369 307 604 minecraft:purple_concrete
fill 371 286 605 371 307 605 minecraft:purple_concrete
setblock 371 286 612 minecraft:white_concrete
fill 371 286 619 371 295 619 minecraft:purple_concrete
fill 371 286 642 371 307 642 minecraft:purple_concrete
setblock 334 287 646 minecraft:crying_obsidian
setblock 346 287 604 minecraft:white_concrete
fill 361 287 646 361 296 646 minecraft:purple_concrete
fill 364 287 633 364 288 633 minecraft:crying_obsidian
fill 371 287 612 371 300 612 minecraft:purple_concrete
fill 329 288 612 329 290 612 minecraft:magenta_concrete
setblock 329 288 622 minecraft:white_concrete
fill 329 288 628 329 290 628 minecraft:magenta_concrete
fill 329 288 644 329 290 644 minecraft:magenta_concrete
fill 333 288 604 333 290 604 minecraft:magenta_concrete
fill 334 288 646 334 297 646 minecraft:purple_concrete
fill 343 288 646 343 290 646 minecraft:magenta_concrete
fill 346 288 604 346 307 604 minecraft:purple_concrete
fill 349 288 604 349 290 604 minecraft:magenta_concrete
fill 359 288 646 359 290 646 minecraft:magenta_concrete
setblock 364 288 646 minecraft:magenta_stained_glass
fill 365 288 604 365 290 604 minecraft:magenta_concrete
fill 365 288 632 366 288 633 minecraft:crying_obsidian
setblock 371 288 610 minecraft:crying_obsidian
fill 371 288 614 371 290 614 minecraft:magenta_concrete
fill 371 288 630 371 290 630 minecraft:magenta_concrete
fill 329 289 622 329 307 622 minecraft:purple_concrete
setblock 329 289 641 minecraft:magenta_stained_glass
setblock 342 289 604 minecraft:crying_obsidian
fill 343 289 604 343 307 604 minecraft:purple_concrete
setblock 355 289 604 minecraft:magenta_stained_glass
fill 364 289 646 364 307 646 minecraft:purple_concrete
fill 366 289 632 368 289 632 minecraft:crying_obsidian
fill 366 289 646 366 307 646 minecraft:purple_concrete
setblock 367 289 646 minecraft:white_concrete
fill 371 289 610 371 307 610 minecraft:purple_concrete
fill 329 290 641 329 307 641 minecraft:purple_concrete
setblock 333 290 646 minecraft:white_concrete
setblock 340 290 604 minecraft:white_concrete
fill 342 290 604 342 293 604 minecraft:purple_concrete
fill 355 290 604 355 307 604 minecraft:purple_concrete
fill 367 290 646 367 307 646 minecraft:purple_concrete
setblock 368 290 632 minecraft:crying_obsidian
fill 329 291 612 329 296 612 minecraft:purple_concrete
fill 329 291 628 329 296 628 minecraft:purple_concrete
fill 329 291 644 329 296 644 minecraft:purple_concrete
fill 333 291 604 333 296 604 minecraft:purple_concrete
fill 333 291 646 333 307 646 minecraft:purple_concrete
fill 340 291 604 340 295 604 minecraft:purple_concrete
fill 343 291 646 343 296 646 minecraft:purple_concrete
fill 349 291 604 349 296 604 minecraft:purple_concrete
fill 359 291 646 359 296 646 minecraft:purple_concrete
fill 365 291 604 365 296 604 minecraft:purple_concrete
fill 371 291 614 371 296 614 minecraft:purple_concrete
fill 371 291 630 371 296 630 minecraft:purple_concrete
fill 364 292 628 364 297 628 minecraft:light_blue_concrete
setblock 371 292 645 minecraft:magenta_stained_glass
setblock 351 293 646 minecraft:magenta_stained_glass
setblock 360 293 646 minecraft:magenta_stained_glass
fill 362 293 628 363 296 628 minecraft:light_blue_concrete
setblock 362 293 646 minecraft:magenta_stained_glass
fill 363 293 626 364 296 627 minecraft:light_blue_concrete
fill 363 293 629 365 296 629 minecraft:light_blue_concrete
fill 365 293 627 365 296 628 minecraft:light_blue_concrete
setblock 368 293 646 minecraft:magenta_stained_glass
fill 371 293 645 371 307 645 minecraft:purple_concrete
setblock 329 294 633 minecraft:white_concrete
setblock 332 294 607 minecraft:light[level=12]
setblock 332 294 615 minecraft:light[level=12]
setblock 332 294 623 minecraft:light[level=12]
setblock 332 294 631 minecraft:light[level=12]
setblock 332 294 639 minecraft:light[level=12]
setblock 340 294 607 minecraft:light[level=12]
setblock 340 294 615 minecraft:light[level=12]
setblock 340 294 623 minecraft:light[level=12]
setblock 340 294 631 minecraft:light[level=12]
setblock 340 294 639 minecraft:light[level=12]
setblock 342 294 604 minecraft:white_concrete
setblock 348 294 607 minecraft:light[level=12]
setblock 348 294 615 minecraft:light[level=12]
setblock 348 294 631 minecraft:light[level=12]
setblock 348 294 639 minecraft:light[level=12]
setblock 350 294 604 minecraft:white_concrete
fill 351 294 604 351 307 604 minecraft:purple_concrete
fill 351 294 646 351 307 646 minecraft:purple_concrete
fill 355 294 646 355 307 646 minecraft:purple_concrete
setblock 356 294 607 minecraft:light[level=12]
setblock 356 294 615 minecraft:light[level=12]
setblock 356 294 623 minecraft:light[level=12]
setblock 356 294 631 minecraft:light[level=12]
setblock 356 294 639 minecraft:light[level=12]
setblock 356 294 646 minecraft:magenta_stained_glass
fill 360 294 646 360 307 646 minecraft:purple_concrete
fill 362 294 627 362 295 627 minecraft:light_blue_concrete
fill 362 294 629 362 295 629 minecraft:light_blue_concrete
fill 362 294 646 362 301 646 minecraft:purple_concrete
fill 363 294 630 365 295 630 minecraft:light_blue_concrete
setblock 364 294 607 minecraft:light[level=12]
setblock 364 294 615 minecraft:light[level=12]
setblock 364 294 623 minecraft:light[level=12]
setblock 364 294 631 minecraft:light[level=12]
setblock 364 294 639 minecraft:light[level=12]
fill 365 294 626 365 295 626 minecraft:light_blue_concrete
fill 366 294 627 366 295 629 minecraft:light_blue_concrete
fill 368 294 646 368 307 646 minecraft:purple_concrete
setblock 371 294 622 minecraft:magenta_stained_glass
setblock 371 294 639 minecraft:magenta_stained_glass
fill 329 295 633 329 307 633 minecraft:purple_concrete
fill 342 295 604 342 302 604 minecraft:purple_concrete
fill 350 295 604 350 307 604 minecraft:purple_concrete
fill 356 295 646 356 307 646 minecraft:purple_concrete
fill 371 295 622 371 307 622 minecraft:purple_concrete
fill 371 295 639 371 307 639 minecraft:purple_concrete
setblock 340 296 604 minecraft:magenta_stained_glass
setblock 370 296 646 minecraft:magenta_stained_glass
setblock 371 296 607 minecraft:crying_obsidian
setblock 371 296 619 minecraft:white_concrete
fill 371 296 646 371 307 646 minecraft:purple_concrete
fill 329 297 612 329 299 612 minecraft:magenta_concrete
fill 329 297 628 329 299 628 minecraft:magenta_concrete
fill 329 297 644 329 299 644 minecraft:magenta_concrete
setblock 332 297 646 minecraft:white_concrete
fill 333 297 604 333 299 604 minecraft:magenta_concrete
fill 340 297 604 340 307 604 minecraft:purple_concrete
fill 343 297 646 343 299 646 minecraft:magenta_concrete
setblock 348 297 646 minecraft:crying_obsidian
fill 349 297 604 349 299 604 minecraft:magenta_concrete
fill 359 297 646 359 299 646 minecraft:magenta_concrete
setblock 361 297 646 minecraft:magenta_stained_glass
fill 365 297 604 365 299 604 minecraft:magenta_concrete
fill 370 297 646 370 307 646 minecraft:purple_concrete
fill 371 297 607 371 307 607 minecraft:purple_concrete
setblock 371 297 608 minecraft:crying_obsidian
fill 371 297 614 371 299 614 minecraft:magenta_concrete
fill 371 297 619 371 307 619 minecraft:purple_concrete
fill 371 297 630 371 299 630 minecraft:magenta_concrete
fill 332 298 646 332 307 646 minecraft:purple_concrete
setblock 334 298 646 minecraft:magenta_stained_glass
fill 348 298 646 348 307 646 minecraft:purple_concrete
fill 361 298 646 361 307 646 minecraft:purple_concrete
fill 371 298 608 371 307 608 minecraft:purple_concrete
setblock 329 299 629 minecraft:crying_obsidian
fill 334 299 646 334 306 646 minecraft:purple_concrete
fill 356 299 642 356 300 643 minecraft:obsidian
setblock 362 299 604 minecraft:magenta_stained_glass
setblock 366 299 604 minecraft:magenta_stained_glass
fill 329 300 612 329 307 612 minecraft:purple_concrete
setblock 329 300 624 minecraft:crying_obsidian
fill 329 300 628 329 306 629 minecraft:purple_concrete
fill 329 300 644 329 307 644 minecraft:purple_concrete
fill 333 300 604 333 307 604 minecraft:purple_concrete
fill 343 300 646 343 307 646 minecraft:purple_concrete
fill 349 300 604 349 307 604 minecraft:purple_concrete
fill 359 300 646 359 307 646 minecraft:purple_concrete
fill 362 300 604 362 307 604 minecraft:purple_concrete
fill 365 300 604 366 307 604 minecraft:purple_concrete
fill 371 300 614 371 307 614 minecraft:purple_concrete
fill 371 300 630 371 307 630 minecraft:purple_concrete
fill 329 301 624 329 307 624 minecraft:purple_concrete
setblock 371 301 612 minecraft:crying_obsidian
setblock 332 302 607 minecraft:light[level=12]
setblock 332 302 615 minecraft:light[level=12]
setblock 332 302 623 minecraft:light[level=12]
setblock 332 302 631 minecraft:light[level=12]
setblock 332 302 639 minecraft:light[level=12]
setblock 340 302 607 minecraft:light[level=12]
setblock 340 302 615 minecraft:light[level=12]
setblock 340 302 623 minecraft:light[level=12]
setblock 340 302 631 minecraft:light[level=12]
setblock 340 302 639 minecraft:light[level=12]
setblock 348 302 607 minecraft:light[level=12]
setblock 348 302 615 minecraft:light[level=12]
setblock 348 302 623 minecraft:light[level=12]
setblock 348 302 631 minecraft:light[level=12]
setblock 348 302 639 minecraft:light[level=12]
setblock 356 302 607 minecraft:light[level=12]
setblock 356 302 615 minecraft:light[level=12]
setblock 356 302 623 minecraft:light[level=12]
setblock 356 302 631 minecraft:light[level=12]
setblock 356 302 639 minecraft:light[level=12]
setblock 362 302 646 minecraft:magenta_stained_glass
setblock 364 302 607 minecraft:light[level=12]
setblock 364 302 615 minecraft:light[level=12]
setblock 364 302 623 minecraft:light[level=12]
setblock 364 302 631 minecraft:light[level=12]
setblock 364 302 639 minecraft:light[level=12]
fill 371 302 612 371 307 612 minecraft:purple_concrete
setblock 342 303 604 minecraft:white_concrete
setblock 354 303 604 minecraft:magenta_stained_glass
fill 362 303 646 362 307 646 minecraft:purple_concrete
setblock 370 303 604 minecraft:magenta_stained_glass
fill 371 303 604 371 307 604 minecraft:purple_concrete
setblock 371 303 637 minecraft:white_concrete
fill 371 303 638 371 307 638 minecraft:purple_concrete
fill 342 304 604 342 307 604 minecraft:purple_concrete
fill 354 304 604 354 307 604 minecraft:purple_concrete
fill 370 304 604 370 307 604 minecraft:purple_concrete
setblock 371 304 629 minecraft:crying_obsidian
fill 371 304 637 371 307 637 minecraft:purple_concrete
setblock 371 305 620 minecraft:crying_obsidian
fill 371 305 629 371 307 629 minecraft:purple_concrete
setblock 329 306 639 minecraft:crying_obsidian
setblock 329 306 642 minecraft:magenta_stained_glass
fill 371 306 620 371 307 620 minecraft:purple_concrete
setblock 329 307 628 minecraft:magenta_stained_glass
setblock 329 307 629 minecraft:purple_concrete
setblock 329 307 639 minecraft:purple_concrete
setblock 329 307 642 minecraft:purple_concrete
setblock 332 307 604 minecraft:white_concrete
setblock 334 307 646 minecraft:white_concrete
