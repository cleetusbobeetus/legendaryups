setblock 321 38 207 minecraft:red_nether_bricks
setblock 321 38 208 minecraft:polished_blackstone
fill 321 38 209 321 41 209 minecraft:red_nether_bricks
setblock 322 38 182 minecraft:polished_blackstone
fill 322 38 203 322 41 203 minecraft:red_nether_bricks
setblock 322 38 206 minecraft:red_nether_bricks
setblock 322 38 207 minecraft:polished_blackstone
fill 322 38 208 322 41 208 minecraft:red_nether_bricks
setblock 322 38 212 minecraft:polished_blackstone
fill 322 38 213 322 41 213 minecraft:red_nether_bricks
setblock 322 38 222 minecraft:polished_blackstone
fill 323 38 182 323 38 185 minecraft:red_nether_bricks
setblock 323 38 186 minecraft:polished_blackstone
fill 323 38 187 323 38 190 minecraft:red_nether_bricks
fill 323 38 199 323 39 199 minecraft:red_nether_bricks
setblock 323 38 201 minecraft:polished_blackstone
fill 323 38 202 323 41 202 minecraft:red_nether_bricks
setblock 323 38 206 minecraft:polished_blackstone
fill 323 38 207 323 41 207 minecraft:red_nether_bricks
setblock 323 38 211 minecraft:polished_blackstone
fill 323 38 212 323 41 212 minecraft:red_nether_bricks
setblock 323 38 215 minecraft:red_nether_bricks
setblock 323 38 216 minecraft:polished_blackstone
fill 323 38 217 323 40 218 minecraft:red_nether_bricks
setblock 323 38 221 minecraft:polished_blackstone
fill 323 38 222 323 41 222 minecraft:red_nether_bricks
fill 283 39 182 283 39 184 minecraft:red_nether_bricks
setblock 283 39 185 minecraft:polished_blackstone
fill 283 39 186 283 39 189 minecraft:red_nether_bricks
setblock 283 39 190 minecraft:polished_blackstone
fill 283 39 191 283 39 194 minecraft:red_nether_bricks
setblock 283 39 195 minecraft:polished_blackstone
fill 283 39 196 283 42 196 minecraft:red_nether_bricks
setblock 283 39 199 minecraft:red_nether_bricks
setblock 283 39 200 minecraft:polished_blackstone
fill 283 39 201 283 42 201 minecraft:red_nether_bricks
setblock 283 39 205 minecraft:polished_blackstone
fill 283 39 206 283 42 206 minecraft:red_nether_bricks
setblock 283 39 210 minecraft:polished_blackstone
fill 283 39 211 283 42 211 minecraft:red_nether_bricks
setblock 283 39 215 minecraft:polished_blackstone
setblock 284 39 183 minecraft:red_nether_bricks
setblock 284 39 184 minecraft:polished_blackstone
fill 284 39 185 284 42 185 minecraft:red_nether_bricks
fill 284 39 187 284 39 188 minecraft:red_nether_bricks
setblock 284 39 189 minecraft:polished_blackstone
fill 284 39 190 284 39 193 minecraft:red_nether_bricks
setblock 284 39 194 minecraft:polished_blackstone
fill 284 39 195 284 42 195 minecraft:red_nether_bricks
setblock 284 39 199 minecraft:polished_blackstone
fill 284 39 200 284 42 200 minecraft:red_nether_bricks
setblock 284 39 204 minecraft:polished_blackstone
fill 284 39 205 284 42 205 minecraft:red_nether_bricks
setblock 284 39 208 minecraft:red_nether_bricks
setblock 284 39 209 minecraft:polished_blackstone
fill 284 39 210 284 42 210 minecraft:red_nether_bricks
setblock 284 39 213 minecraft:red_nether_bricks
setblock 285 39 182 minecraft:red_nether_bricks
setblock 285 39 183 minecraft:polished_blackstone
fill 285 39 184 285 42 184 minecraft:red_nether_bricks
setblock 285 39 187 minecraft:red_nether_bricks
setblock 285 39 188 minecraft:polished_blackstone
fill 285 39 189 286 41 189 minecraft:red_nether_bricks
fill 285 39 191 285 39 192 minecraft:red_nether_bricks
setblock 285 39 193 minecraft:polished_blackstone
fill 285 39 194 285 42 194 minecraft:red_nether_bricks
setblock 285 39 203 minecraft:polished_blackstone
fill 285 39 204 285 42 204 minecraft:red_nether_bricks
setblock 285 39 208 minecraft:polished_blackstone
fill 285 39 209 286 41 209 minecraft:red_nether_bricks
fill 285 39 211 285 40 211 minecraft:red_nether_bricks
setblock 285 39 222 minecraft:red_nether_bricks
setblock 286 39 182 minecraft:polished_blackstone
fill 286 39 183 286 42 183 minecraft:red_nether_bricks
setblock 286 39 186 minecraft:red_nether_bricks
setblock 286 39 187 minecraft:polished_blackstone
fill 286 39 188 286 42 188 minecraft:red_nether_bricks
fill 286 39 190 286 40 190 minecraft:red_nether_bricks
setblock 286 39 207 minecraft:polished_blackstone
fill 286 39 208 286 42 208 minecraft:red_nether_bricks
setblock 286 39 222 minecraft:polished_blackstone
fill 287 39 182 287 42 182 minecraft:red_nether_bricks
setblock 287 39 185 minecraft:red_nether_bricks
fill 287 39 222 287 42 222 minecraft:red_nether_bricks
setblock 288 39 185 minecraft:polished_blackstone
setblock 289 39 184 minecraft:polished_blackstone
fill 289 39 185 290 40 185 minecraft:red_nether_bricks
setblock 290 39 183 minecraft:polished_blackstone
fill 290 39 184 290 42 184 minecraft:red_nether_bricks
setblock 291 39 182 minecraft:polished_blackstone
fill 291 39 183 291 42 183 minecraft:red_nether_bricks
fill 292 39 182 292 42 182 minecraft:red_nether_bricks
setblock 294 39 184 minecraft:polished_blackstone
setblock 295 39 183 minecraft:polished_blackstone
setblock 296 39 182 minecraft:polished_blackstone
fill 296 39 183 296 42 183 minecraft:red_nether_bricks
fill 297 39 182 297 42 182 minecraft:red_nether_bricks
setblock 300 39 183 minecraft:polished_blackstone
fill 300 39 184 300 42 184 minecraft:red_nether_bricks
setblock 301 39 182 minecraft:polished_blackstone
fill 301 39 183 301 42 183 minecraft:red_nether_bricks
setblock 301 39 222 minecraft:polished_blackstone
fill 302 39 182 302 42 182 minecraft:red_nether_bricks
fill 302 39 222 302 42 222 minecraft:red_nether_bricks
setblock 303 39 185 minecraft:polished_blackstone
setblock 304 39 184 minecraft:polished_blackstone
fill 304 39 185 307 39 185 minecraft:red_nether_bricks
setblock 305 39 183 minecraft:polished_blackstone
fill 305 39 184 305 42 184 minecraft:red_nether_bricks
setblock 306 39 182 minecraft:polished_blackstone
fill 306 39 183 306 42 183 minecraft:red_nether_bricks
setblock 306 39 222 minecraft:polished_blackstone
fill 307 39 182 307 42 182 minecraft:red_nether_bricks
setblock 307 39 221 minecraft:polished_blackstone
fill 307 39 222 307 42 222 minecraft:red_nether_bricks
setblock 308 39 185 minecraft:polished_blackstone
fill 308 39 221 308 42 221 minecraft:red_nether_bricks
setblock 309 39 184 minecraft:polished_blackstone
setblock 309 39 185 minecraft:red_nether_bricks
setblock 310 39 183 minecraft:polished_blackstone
fill 310 39 184 310 41 184 minecraft:red_nether_bricks
setblock 311 39 182 minecraft:polished_blackstone
fill 311 39 183 311 41 183 minecraft:red_nether_bricks
setblock 311 39 222 minecraft:polished_blackstone
fill 312 39 182 312 42 182 minecraft:red_nether_bricks
setblock 312 39 221 minecraft:polished_blackstone
fill 312 39 222 312 42 222 minecraft:red_nether_bricks
setblock 316 39 222 minecraft:polished_blackstone
setblock 321 39 206 minecraft:red_nether_bricks
setblock 321 39 207 minecraft:polished_blackstone
fill 321 39 208 321 42 208 minecraft:red_nether_bricks
fill 321 39 210 321 39 211 minecraft:red_nether_bricks
fill 322 39 182 323 41 182 minecraft:red_nether_bricks
fill 322 39 202 322 42 202 minecraft:red_nether_bricks
setblock 322 39 206 minecraft:polished_blackstone
fill 322 39 207 322 42 207 minecraft:red_nether_bricks
fill 322 39 209 322 39 210 minecraft:red_nether_bricks
setblock 322 39 211 minecraft:polished_blackstone
fill 322 39 212 322 42 212 minecraft:red_nether_bricks
fill 322 39 214 322 39 215 minecraft:red_nether_bricks
fill 322 39 222 322 42 222 minecraft:red_nether_bricks
fill 323 39 183 323 39 184 minecraft:red_nether_bricks
setblock 323 39 185 minecraft:polished_blackstone
fill 323 39 186 323 39 189 minecraft:red_nether_bricks
setblock 323 39 190 minecraft:polished_blackstone
fill 323 39 191 323 40 193 minecraft:red_nether_bricks
fill 323 39 197 323 40 198 minecraft:red_nether_bricks
setblock 323 39 200 minecraft:polished_blackstone
fill 323 39 201 323 42 201 minecraft:red_nether_bricks
setblock 323 39 205 minecraft:polished_blackstone
fill 323 39 206 323 42 206 minecraft:red_nether_bricks
setblock 323 39 210 minecraft:polished_blackstone
fill 323 39 211 323 42 211 minecraft:red_nether_bricks
setblock 323 39 215 minecraft:polished_blackstone
fill 323 39 216 323 42 216 minecraft:red_nether_bricks
setblock 323 39 219 minecraft:red_nether_bricks
setblock 323 39 220 minecraft:polished_blackstone
fill 323 39 221 323 42 221 minecraft:red_nether_bricks
fill 283 40 182 283 40 183 minecraft:red_nether_bricks
setblock 283 40 184 minecraft:polished_blackstone
fill 283 40 185 283 40 188 minecraft:red_nether_bricks
setblock 283 40 189 minecraft:polished_blackstone
fill 283 40 190 283 40 193 minecraft:red_nether_bricks
setblock 283 40 194 minecraft:polished_blackstone
fill 283 40 195 283 43 195 minecraft:red_nether_bricks
setblock 283 40 199 minecraft:polished_blackstone
fill 283 40 200 283 43 200 minecraft:red_nether_bricks
setblock 283 40 204 minecraft:polished_blackstone
fill 283 40 205 283 43 205 minecraft:red_nether_bricks
setblock 283 40 209 minecraft:polished_blackstone
fill 283 40 210 283 43 210 minecraft:red_nether_bricks
setblock 283 40 214 minecraft:polished_blackstone
fill 283 40 215 283 41 217 minecraft:red_nether_bricks
setblock 284 40 183 minecraft:polished_blackstone
fill 284 40 184 284 43 184 minecraft:red_nether_bricks
setblock 284 40 187 minecraft:red_nether_bricks
setblock 284 40 188 minecraft:polished_blackstone
fill 284 40 189 284 40 192 minecraft:red_nether_bricks
setblock 284 40 193 minecraft:polished_blackstone
fill 284 40 194 284 43 194 minecraft:red_nether_bricks
setblock 284 40 198 minecraft:polished_blackstone
fill 284 40 199 285 42 199 minecraft:red_nether_bricks
setblock 284 40 203 minecraft:polished_blackstone
fill 284 40 204 284 43 204 minecraft:red_nether_bricks
setblock 284 40 208 minecraft:polished_blackstone
fill 284 40 209 284 43 209 minecraft:red_nether_bricks
setblock 284 40 213 minecraft:polished_blackstone
fill 284 40 214 284 43 214 minecraft:red_nether_bricks
setblock 285 40 182 minecraft:polished_blackstone
fill 285 40 183 285 43 183 minecraft:red_nether_bricks
setblock 285 40 187 minecraft:polished_blackstone
fill 285 40 188 285 43 188 minecraft:red_nether_bricks
setblock 285 40 191 minecraft:red_nether_bricks
setblock 285 40 192 minecraft:polished_blackstone
fill 285 40 193 285 43 193 minecraft:red_nether_bricks
fill 285 40 195 285 40 196 minecraft:red_nether_bricks
setblock 285 40 197 minecraft:polished_blackstone
fill 285 40 198 285 43 198 minecraft:red_nether_bricks
setblock 285 40 202 minecraft:polished_blackstone
fill 285 40 203 285 43 203 minecraft:red_nether_bricks
setblock 285 40 206 minecraft:red_nether_bricks
setblock 285 40 207 minecraft:polished_blackstone
fill 285 40 208 285 43 208 minecraft:red_nether_bricks
setblock 285 40 212 minecraft:polished_blackstone
setblock 285 40 222 minecraft:polished_blackstone
fill 286 40 182 286 43 182 minecraft:red_nether_bricks
setblock 286 40 185 minecraft:red_nether_bricks
setblock 286 40 186 minecraft:polished_blackstone
fill 286 40 187 286 43 187 minecraft:red_nether_bricks
setblock 286 40 191 minecraft:polished_blackstone
fill 286 40 192 286 43 192 minecraft:red_nether_bricks
setblock 286 40 206 minecraft:polished_blackstone
fill 286 40 207 286 41 207 minecraft:red_nether_bricks
fill 286 40 222 286 42 222 minecraft:red_nether_bricks
setblock 287 40 185 minecraft:polished_blackstone
setblock 288 40 184 minecraft:polished_blackstone
fill 288 40 185 288 42 185 minecraft:red_nether_bricks
setblock 289 40 183 minecraft:polished_blackstone
fill 289 40 184 289 43 184 minecraft:red_nether_bricks
setblock 290 40 182 minecraft:polished_blackstone
fill 290 40 183 290 43 183 minecraft:red_nether_bricks
fill 291 40 182 291 43 182 minecraft:red_nether_bricks
setblock 293 40 184 minecraft:polished_blackstone
setblock 294 40 183 minecraft:polished_blackstone
setblock 295 40 182 minecraft:polished_blackstone
fill 295 40 183 295 42 183 minecraft:red_nether_bricks
fill 296 40 182 296 43 182 minecraft:red_nether_bricks
setblock 299 40 183 minecraft:polished_blackstone
fill 299 40 184 299 42 184 minecraft:red_nether_bricks
setblock 300 40 182 minecraft:polished_blackstone
fill 300 40 183 300 43 183 minecraft:red_nether_bricks
setblock 300 40 222 minecraft:polished_blackstone
fill 301 40 182 301 43 182 minecraft:red_nether_bricks
fill 301 40 222 301 43 222 minecraft:red_nether_bricks
setblock 302 40 185 minecraft:polished_blackstone
setblock 303 40 184 minecraft:polished_blackstone
fill 303 40 185 306 40 185 minecraft:red_nether_bricks
fill 303 40 221 303 42 221 minecraft:red_nether_bricks
setblock 304 40 183 minecraft:polished_blackstone
fill 304 40 184 304 43 184 minecraft:red_nether_bricks
setblock 305 40 182 minecraft:polished_blackstone
fill 305 40 183 305 43 183 minecraft:red_nether_bricks
setblock 305 40 222 minecraft:polished_blackstone
fill 306 40 182 306 43 182 minecraft:red_nether_bricks
setblock 306 40 221 minecraft:polished_blackstone
fill 306 40 222 306 43 222 minecraft:red_nether_bricks
setblock 307 40 185 minecraft:polished_blackstone
setblock 307 40 220 minecraft:polished_blackstone
fill 307 40 221 307 43 221 minecraft:red_nether_bricks
setblock 308 40 184 minecraft:polished_blackstone
fill 308 40 185 308 41 185 minecraft:red_nether_bricks
fill 308 40 220 308 41 220 minecraft:red_nether_bricks
setblock 309 40 183 minecraft:polished_blackstone
fill 309 40 184 309 42 184 minecraft:red_nether_bricks
setblock 310 40 182 minecraft:polished_blackstone
fill 310 40 183 310 42 183 minecraft:red_nether_bricks
setblock 310 40 222 minecraft:polished_blackstone
fill 311 40 182 311 43 182 minecraft:red_nether_bricks
setblock 311 40 221 minecraft:polished_blackstone
fill 311 40 222 311 43 222 minecraft:red_nether_bricks
setblock 312 40 221 minecraft:red_nether_bricks
setblock 315 40 182 minecraft:polished_blackstone
setblock 315 40 222 minecraft:polished_blackstone
setblock 321 40 205 minecraft:red_nether_bricks
setblock 321 40 206 minecraft:polished_blackstone
fill 321 40 207 321 43 207 minecraft:red_nether_bricks
setblock 321 40 210 minecraft:red_nether_bricks
setblock 321 40 211 minecraft:polished_blackstone
fill 321 40 212 321 42 213 minecraft:red_nether_bricks
fill 322 40 186 322 40 189 minecraft:red_nether_bricks
fill 322 40 201 322 43 201 minecraft:red_nether_bricks
setblock 322 40 205 minecraft:polished_blackstone
fill 322 40 206 322 43 206 minecraft:red_nether_bricks
setblock 322 40 209 minecraft:red_nether_bricks
setblock 322 40 210 minecraft:polished_blackstone
fill 322 40 211 322 43 211 minecraft:red_nether_bricks
setblock 322 40 214 minecraft:red_nether_bricks
setblock 322 40 215 minecraft:polished_blackstone
fill 322 40 216 322 43 216 minecraft:red_nether_bricks
setblock 323 40 183 minecraft:red_nether_bricks
setblock 323 40 184 minecraft:polished_blackstone
fill 323 40 185 323 40 188 minecraft:red_nether_bricks
setblock 323 40 189 minecraft:polished_blackstone
fill 323 40 190 323 43 190 minecraft:red_nether_bricks
setblock 323 40 194 minecraft:polished_blackstone
fill 323 40 195 323 42 196 minecraft:red_nether_bricks
setblock 323 40 199 minecraft:polished_blackstone
fill 323 40 200 323 43 200 minecraft:red_nether_bricks
setblock 323 40 204 minecraft:polished_blackstone
fill 323 40 205 323 43 205 minecraft:red_nether_bricks
setblock 323 40 209 minecraft:polished_blackstone
fill 323 40 210 323 43 210 minecraft:red_nether_bricks
setblock 323 40 214 minecraft:polished_blackstone
fill 323 40 215 323 43 215 minecraft:red_nether_bricks
setblock 323 40 219 minecraft:polished_blackstone
fill 323 40 220 323 43 220 minecraft:red_nether_bricks
setblock 283 41 182 minecraft:red_nether_bricks
setblock 283 41 183 minecraft:polished_blackstone
fill 283 41 184 283 41 187 minecraft:red_nether_bricks
setblock 283 41 188 minecraft:polished_blackstone
fill 283 41 189 283 41 192 minecraft:red_nether_bricks
setblock 283 41 193 minecraft:polished_blackstone
fill 283 41 194 283 44 194 minecraft:red_nether_bricks
setblock 283 41 197 minecraft:red_nether_bricks
setblock 283 41 198 minecraft:polished_blackstone
fill 283 41 199 283 44 199 minecraft:red_nether_bricks
setblock 283 41 203 minecraft:polished_blackstone
fill 283 41 204 283 44 204 minecraft:red_nether_bricks
setblock 283 41 208 minecraft:polished_blackstone
fill 283 41 209 283 44 209 minecraft:red_nether_bricks
setblock 283 41 212 minecraft:red_nether_bricks
setblock 283 41 213 minecraft:polished_blackstone
fill 283 41 214 283 44 214 minecraft:red_nether_bricks
setblock 283 41 218 minecraft:polished_blackstone
setblock 284 41 182 minecraft:polished_blackstone
fill 284 41 183 284 44 183 minecraft:red_nether_bricks
setblock 284 41 186 minecraft:red_nether_bricks
setblock 284 41 187 minecraft:polished_blackstone
fill 284 41 188 284 41 191 minecraft:red_nether_bricks
setblock 284 41 192 minecraft:polished_blackstone
fill 284 41 193 284 44 193 minecraft:red_nether_bricks
setblock 284 41 197 minecraft:polished_blackstone
fill 284 41 198 284 44 198 minecraft:red_nether_bricks
setblock 284 41 202 minecraft:polished_blackstone
fill 284 41 203 284 44 203 minecraft:red_nether_bricks
setblock 284 41 207 minecraft:polished_blackstone
fill 284 41 208 284 44 208 minecraft:red_nether_bricks
setblock 284 41 212 minecraft:polished_blackstone
fill 284 41 213 285 43 213 minecraft:red_nether_bricks
fill 284 41 215 284 42 215 minecraft:red_nether_bricks
setblock 284 41 222 minecraft:polished_blackstone
fill 285 41 182 285 44 182 minecraft:red_nether_bricks
setblock 285 41 186 minecraft:polished_blackstone
fill 285 41 187 285 44 187 minecraft:red_nether_bricks
setblock 285 41 191 minecraft:polished_blackstone
fill 285 41 192 285 44 192 minecraft:red_nether_bricks
setblock 285 41 195 minecraft:red_nether_bricks
setblock 285 41 196 minecraft:polished_blackstone
fill 285 41 197 285 44 197 minecraft:red_nether_bricks
setblock 285 41 201 minecraft:polished_blackstone
fill 285 41 202 285 42 202 minecraft:red_nether_bricks
setblock 285 41 206 minecraft:polished_blackstone
fill 285 41 207 285 44 207 minecraft:red_nether_bricks
setblock 285 41 211 minecraft:polished_blackstone
fill 285 41 212 285 44 212 minecraft:red_nether_bricks
fill 285 41 222 285 42 222 minecraft:red_nether_bricks
setblock 286 41 185 minecraft:polished_blackstone
fill 286 41 186 286 43 186 minecraft:red_nether_bricks
setblock 286 41 190 minecraft:polished_blackstone
fill 286 41 191 286 44 191 minecraft:red_nether_bricks
fill 286 41 193 286 41 194 minecraft:red_nether_bricks
setblock 286 41 205 minecraft:polished_blackstone
setblock 286 41 206 minecraft:red_nether_bricks
setblock 286 41 210 minecraft:polished_blackstone
setblock 287 41 184 minecraft:polished_blackstone
fill 287 41 185 287 42 185 minecraft:red_nether_bricks
setblock 288 41 183 minecraft:polished_blackstone
fill 288 41 184 288 43 184 minecraft:red_nether_bricks
setblock 289 41 182 minecraft:polished_blackstone
fill 289 41 183 289 44 183 minecraft:red_nether_bricks
setblock 289 41 185 minecraft:red_nether_bricks
fill 290 41 182 290 44 182 minecraft:red_nether_bricks
setblock 292 41 184 minecraft:polished_blackstone
setblock 293 41 183 minecraft:polished_blackstone
setblock 294 41 182 minecraft:polished_blackstone
fill 294 41 183 294 42 183 minecraft:red_nether_bricks
fill 295 41 182 295 44 182 minecraft:red_nether_bricks
setblock 298 41 183 minecraft:polished_blackstone
setblock 299 41 182 minecraft:polished_blackstone
fill 299 41 183 299 44 183 minecraft:red_nether_bricks
fill 300 41 182 300 44 182 minecraft:red_nether_bricks
fill 300 41 222 300 44 222 minecraft:red_nether_bricks
setblock 302 41 184 minecraft:polished_blackstone
fill 302 41 185 305 41 185 minecraft:red_nether_bricks
fill 302 41 221 302 43 221 minecraft:red_nether_bricks
setblock 303 41 183 minecraft:polished_blackstone
fill 303 41 184 303 44 184 minecraft:red_nether_bricks
setblock 304 41 182 minecraft:polished_blackstone
fill 304 41 183 304 44 183 minecraft:red_nether_bricks
setblock 304 41 222 minecraft:polished_blackstone
fill 305 41 182 305 44 182 minecraft:red_nether_bricks
setblock 305 41 221 minecraft:polished_blackstone
fill 305 41 222 305 44 222 minecraft:red_nether_bricks
setblock 306 41 185 minecraft:polished_blackstone
setblock 306 41 220 minecraft:polished_blackstone
fill 306 41 221 306 44 221 minecraft:red_nether_bricks
setblock 307 41 184 minecraft:polished_blackstone
setblock 307 41 185 minecraft:red_nether_bricks
fill 307 41 220 307 42 220 minecraft:red_nether_bricks
setblock 308 41 183 minecraft:polished_blackstone
fill 308 41 184 308 42 184 minecraft:red_nether_bricks
setblock 309 41 182 minecraft:polished_blackstone
fill 309 41 183 309 43 183 minecraft:red_nether_bricks
setblock 309 41 222 minecraft:polished_blackstone
fill 310 41 182 310 43 182 minecraft:red_nether_bricks
setblock 310 41 221 minecraft:polished_blackstone
fill 310 41 222 310 44 222 minecraft:red_nether_bricks
setblock 311 41 221 minecraft:red_nether_bricks
setblock 314 41 222 minecraft:polished_blackstone
setblock 321 41 205 minecraft:polished_blackstone
fill 321 41 206 321 44 206 minecraft:red_nether_bricks
setblock 321 41 210 minecraft:polished_blackstone
fill 321 41 211 321 44 211 minecraft:red_nether_bricks
setblock 321 41 214 minecraft:red_nether_bricks
setblock 321 41 222 minecraft:red_nether_bricks
fill 322 41 185 322 41 188 minecraft:red_nether_bricks
setblock 322 41 189 minecraft:polished_blackstone
fill 322 41 190 322 42 192 minecraft:red_nether_bricks
setblock 322 41 204 minecraft:polished_blackstone
fill 322 41 205 322 44 205 minecraft:red_nether_bricks
setblock 322 41 209 minecraft:polished_blackstone
fill 322 41 210 322 44 210 minecraft:red_nether_bricks
setblock 322 41 214 minecraft:polished_blackstone
fill 322 41 215 322 44 215 minecraft:red_nether_bricks
fill 322 41 217 323 41 217 minecraft:red_nether_bricks
setblock 323 41 183 minecraft:polished_blackstone
fill 323 41 184 323 41 187 minecraft:red_nether_bricks
setblock 323 41 188 minecraft:polished_blackstone
fill 323 41 189 323 44 189 minecraft:red_nether_bricks
fill 323 41 191 323 41 192 minecraft:red_nether_bricks
setblock 323 41 193 minecraft:polished_blackstone
fill 323 41 194 323 44 194 minecraft:red_nether_bricks
setblock 323 41 197 minecraft:red_nether_bricks
setblock 323 41 198 minecraft:polished_blackstone
fill 323 41 199 323 44 199 minecraft:red_nether_bricks
setblock 323 41 203 minecraft:polished_blackstone
fill 323 41 204 323 44 204 minecraft:red_nether_bricks
setblock 323 41 208 minecraft:polished_blackstone
fill 323 41 209 323 44 209 minecraft:red_nether_bricks
setblock 323 41 213 minecraft:polished_blackstone
fill 323 41 214 323 44 214 minecraft:red_nether_bricks
setblock 323 41 218 minecraft:polished_blackstone
fill 323 41 219 323 44 219 minecraft:red_nether_bricks
setblock 283 42 182 minecraft:polished_blackstone
fill 283 42 183 283 42 186 minecraft:red_nether_bricks
setblock 283 42 187 minecraft:polished_blackstone
fill 283 42 188 283 42 191 minecraft:red_nether_bricks
setblock 283 42 192 minecraft:polished_blackstone
fill 283 42 193 283 45 193 minecraft:red_nether_bricks
setblock 283 42 197 minecraft:polished_blackstone
fill 283 42 198 283 45 198 minecraft:red_nether_bricks
setblock 283 42 202 minecraft:polished_blackstone
fill 283 42 203 283 45 203 minecraft:red_nether_bricks
setblock 283 42 207 minecraft:polished_blackstone
fill 283 42 208 283 45 208 minecraft:red_nether_bricks
setblock 283 42 212 minecraft:polished_blackstone
fill 283 42 213 283 45 213 minecraft:red_nether_bricks
fill 283 42 215 283 42 216 minecraft:red_nether_bricks
setblock 283 42 217 minecraft:polished_blackstone
fill 283 42 218 283 44 219 minecraft:red_nether_bricks
fill 284 42 182 284 45 182 minecraft:red_nether_bricks
setblock 284 42 186 minecraft:polished_blackstone
fill 284 42 187 284 42 190 minecraft:red_nether_bricks
setblock 284 42 191 minecraft:polished_blackstone
fill 284 42 192 284 45 192 minecraft:red_nether_bricks
setblock 284 42 196 minecraft:polished_blackstone
fill 284 42 197 284 45 197 minecraft:red_nether_bricks
setblock 284 42 201 minecraft:polished_blackstone
fill 284 42 202 284 45 202 minecraft:red_nether_bricks
setblock 284 42 206 minecraft:polished_blackstone
fill 284 42 207 284 45 207 minecraft:red_nether_bricks
setblock 284 42 211 minecraft:polished_blackstone
fill 284 42 212 284 45 212 minecraft:red_nether_bricks
setblock 284 42 216 minecraft:polished_blackstone
setblock 285 42 185 minecraft:polished_blackstone
fill 285 42 186 285 45 186 minecraft:red_nether_bricks
setblock 285 42 189 minecraft:red_nether_bricks
setblock 285 42 190 minecraft:polished_blackstone
fill 285 42 191 285 45 191 minecraft:red_nether_bricks
setblock 285 42 195 minecraft:polished_blackstone
fill 285 42 196 285 45 196 minecraft:red_nether_bricks
setblock 285 42 200 minecraft:polished_blackstone
setblock 285 42 201 minecraft:red_nether_bricks
setblock 285 42 205 minecraft:polished_blackstone
fill 285 42 206 285 44 206 minecraft:red_nether_bricks
setblock 285 42 209 minecraft:red_nether_bricks
setblock 285 42 210 minecraft:polished_blackstone
fill 285 42 211 285 45 211 minecraft:red_nether_bricks
setblock 286 42 184 minecraft:polished_blackstone
setblock 286 42 185 minecraft:red_nether_bricks
setblock 286 42 189 minecraft:polished_blackstone
fill 286 42 190 286 45 190 minecraft:red_nether_bricks
setblock 286 42 193 minecraft:red_nether_bricks
setblock 286 42 194 minecraft:polished_blackstone
setblock 286 42 209 minecraft:polished_blackstone
setblock 287 42 183 minecraft:polished_blackstone
fill 287 42 184 287 43 184 minecraft:red_nether_bricks
setblock 287 42 189 minecraft:red_nether_bricks
setblock 288 42 182 minecraft:polished_blackstone
fill 288 42 183 288 44 183 minecraft:red_nether_bricks
fill 289 42 182 289 45 182 minecraft:red_nether_bricks
setblock 291 42 184 minecraft:polished_blackstone
setblock 292 42 183 minecraft:polished_blackstone
setblock 293 42 182 minecraft:polished_blackstone
setblock 293 42 183 minecraft:red_nether_bricks
fill 294 42 182 294 43 182 minecraft:red_nether_bricks
setblock 297 42 183 minecraft:polished_blackstone
setblock 298 42 182 minecraft:polished_blackstone
fill 298 42 183 298 44 183 minecraft:red_nether_bricks
fill 299 42 182 299 45 182 minecraft:red_nether_bricks
fill 299 42 222 299 45 222 minecraft:red_nether_bricks
setblock 301 42 184 minecraft:polished_blackstone
setblock 302 42 183 minecraft:polished_blackstone
fill 302 42 184 302 42 185 minecraft:red_nether_bricks
setblock 303 42 182 minecraft:polished_blackstone
fill 303 42 183 303 45 183 minecraft:red_nether_bricks
fill 303 42 185 304 42 185 minecraft:red_nether_bricks
setblock 303 42 222 minecraft:polished_blackstone
fill 304 42 182 304 45 182 minecraft:red_nether_bricks
setblock 304 42 221 minecraft:polished_blackstone
fill 304 42 222 304 45 222 minecraft:red_nether_bricks
setblock 305 42 185 minecraft:polished_blackstone
setblock 305 42 220 minecraft:polished_blackstone
fill 305 42 221 305 45 221 minecraft:red_nether_bricks
setblock 306 42 184 minecraft:polished_blackstone
setblock 306 42 185 minecraft:red_nether_bricks
fill 306 42 220 306 43 220 minecraft:red_nether_bricks
setblock 307 42 183 minecraft:polished_blackstone
fill 307 42 184 307 43 184 minecraft:red_nether_bricks
setblock 308 42 182 minecraft:polished_blackstone
fill 308 42 183 308 44 183 minecraft:red_nether_bricks
setblock 308 42 222 minecraft:polished_blackstone
fill 309 42 182 309 44 182 minecraft:red_nether_bricks
setblock 309 42 221 minecraft:polished_blackstone
fill 309 42 222 309 45 222 minecraft:red_nether_bricks
fill 310 42 221 310 43 221 minecraft:red_nether_bricks
setblock 313 42 222 minecraft:polished_blackstone
setblock 320 42 209 minecraft:red_nether_bricks
setblock 320 42 210 minecraft:polished_blackstone
fill 321 42 205 321 43 205 minecraft:red_nether_bricks
setblock 321 42 209 minecraft:polished_blackstone
fill 321 42 210 321 45 210 minecraft:red_nether_bricks
setblock 321 42 214 minecraft:polished_blackstone
fill 321 42 215 321 45 215 minecraft:red_nether_bricks
setblock 322 42 182 minecraft:red_nether_bricks
fill 322 42 185 322 42 187 minecraft:red_nether_bricks
setblock 322 42 188 minecraft:polished_blackstone
fill 322 42 189 322 45 189 minecraft:red_nether_bricks
setblock 322 42 193 minecraft:polished_blackstone
fill 322 42 194 322 44 195 minecraft:red_nether_bricks
fill 322 42 200 322 44 200 minecraft:red_nether_bricks
setblock 322 42 203 minecraft:polished_blackstone
fill 322 42 204 322 45 204 minecraft:red_nether_bricks
setblock 322 42 208 minecraft:polished_blackstone
fill 322 42 209 322 45 209 minecraft:red_nether_bricks
setblock 322 42 213 minecraft:polished_blackstone
fill 322 42 214 322 45 214 minecraft:red_nether_bricks
setblock 322 42 217 minecraft:red_nether_bricks
setblock 322 42 218 minecraft:polished_blackstone
setblock 323 42 182 minecraft:polished_blackstone
fill 323 42 183 323 42 186 minecraft:red_nether_bricks
setblock 323 42 187 minecraft:polished_blackstone
fill 323 42 188 323 45 188 minecraft:red_nether_bricks
setblock 323 42 191 minecraft:red_nether_bricks
setblock 323 42 192 minecraft:polished_blackstone
fill 323 42 193 323 45 193 minecraft:red_nether_bricks
setblock 323 42 197 minecraft:polished_blackstone
fill 323 42 198 323 45 198 minecraft:red_nether_bricks
setblock 323 42 202 minecraft:polished_blackstone
fill 323 42 203 323 45 203 minecraft:red_nether_bricks
setblock 323 42 207 minecraft:polished_blackstone
fill 323 42 208 323 45 208 minecraft:red_nether_bricks
setblock 323 42 212 minecraft:polished_blackstone
fill 323 42 213 323 45 213 minecraft:red_nether_bricks
setblock 323 42 217 minecraft:polished_blackstone
fill 323 42 218 323 45 218 minecraft:red_nether_bricks
setblock 323 42 222 minecraft:polished_blackstone
fill 283 43 182 283 43 185 minecraft:red_nether_bricks
setblock 283 43 186 minecraft:polished_blackstone
fill 283 43 187 283 43 190 minecraft:red_nether_bricks
setblock 283 43 191 minecraft:polished_blackstone
fill 283 43 192 283 46 192 minecraft:red_nether_bricks
setblock 283 43 196 minecraft:polished_blackstone
fill 283 43 197 283 46 197 minecraft:red_nether_bricks
setblock 283 43 201 minecraft:polished_blackstone
fill 283 43 202 283 46 202 minecraft:red_nether_bricks
setblock 283 43 206 minecraft:polished_blackstone
fill 283 43 207 283 46 207 minecraft:red_nether_bricks
setblock 283 43 211 minecraft:polished_blackstone
fill 283 43 212 283 46 212 minecraft:red_nether_bricks
setblock 283 43 215 minecraft:red_nether_bricks
setblock 283 43 216 minecraft:polished_blackstone
fill 283 43 217 283 46 217 minecraft:red_nether_bricks
setblock 284 43 185 minecraft:polished_blackstone
fill 284 43 186 284 43 189 minecraft:red_nether_bricks
setblock 284 43 190 minecraft:polished_blackstone
fill 284 43 191 284 46 191 minecraft:red_nether_bricks
setblock 284 43 195 minecraft:polished_blackstone
fill 284 43 196 284 46 196 minecraft:red_nether_bricks
setblock 284 43 199 minecraft:red_nether_bricks
setblock 284 43 200 minecraft:polished_blackstone
fill 284 43 201 284 46 201 minecraft:red_nether_bricks
setblock 284 43 205 minecraft:polished_blackstone
fill 284 43 206 284 46 206 minecraft:red_nether_bricks
setblock 284 43 210 minecraft:polished_blackstone
fill 284 43 211 284 46 211 minecraft:red_nether_bricks
setblock 284 43 215 minecraft:polished_blackstone
fill 284 43 216 284 46 216 minecraft:red_nether_bricks
setblock 285 43 184 minecraft:polished_blackstone
fill 285 43 185 285 44 185 minecraft:red_nether_bricks
setblock 285 43 189 minecraft:polished_blackstone
fill 285 43 190 285 46 190 minecraft:red_nether_bricks
setblock 285 43 194 minecraft:polished_blackstone
fill 285 43 195 285 46 195 minecraft:red_nether_bricks
setblock 285 43 199 minecraft:polished_blackstone
setblock 285 43 204 minecraft:polished_blackstone
setblock 285 43 205 minecraft:red_nether_bricks
setblock 285 43 209 minecraft:polished_blackstone
fill 285 43 210 285 44 210 minecraft:red_nether_bricks
setblock 286 43 183 minecraft:polished_blackstone
setblock 286 43 184 minecraft:red_nether_bricks
setblock 286 43 188 minecraft:polished_blackstone
fill 286 43 189 286 45 189 minecraft:red_nether_bricks
setblock 286 43 193 minecraft:polished_blackstone
fill 286 43 194 286 45 194 minecraft:red_nether_bricks
setblock 287 43 182 minecraft:polished_blackstone
fill 287 43 183 287 44 183 minecraft:red_nether_bricks
fill 288 43 182 288 45 182 minecraft:red_nether_bricks
setblock 291 43 183 minecraft:polished_blackstone
setblock 292 43 182 minecraft:polished_blackstone
setblock 293 43 182 minecraft:red_nether_bricks
setblock 297 43 182 minecraft:polished_blackstone
setblock 297 43 183 minecraft:red_nether_bricks
fill 298 43 182 298 46 182 minecraft:red_nether_bricks
setblock 300 43 184 minecraft:polished_blackstone
setblock 301 43 183 minecraft:polished_blackstone
fill 301 43 184 302 44 184 minecraft:red_nether_bricks
setblock 302 43 182 minecraft:polished_blackstone
fill 302 43 183 302 46 183 minecraft:red_nether_bricks
setblock 302 43 222 minecraft:polished_blackstone
fill 303 43 182 303 46 182 minecraft:red_nether_bricks
setblock 303 43 221 minecraft:polished_blackstone
fill 303 43 222 303 46 222 minecraft:red_nether_bricks
fill 304 43 221 304 46 221 minecraft:red_nether_bricks
setblock 305 43 184 minecraft:polished_blackstone
fill 305 43 220 305 44 220 minecraft:red_nether_bricks
setblock 306 43 183 minecraft:polished_blackstone
setblock 306 43 184 minecraft:red_nether_bricks
setblock 307 43 182 minecraft:polished_blackstone
fill 307 43 183 307 44 183 minecraft:red_nether_bricks
setblock 307 43 222 minecraft:polished_blackstone
fill 308 43 182 308 45 182 minecraft:red_nether_bricks
setblock 308 43 221 minecraft:polished_blackstone
fill 308 43 222 308 46 222 minecraft:red_nether_bricks
fill 309 43 221 309 44 221 minecraft:red_nether_bricks
setblock 312 43 222 minecraft:polished_blackstone
fill 320 43 210 320 43 211 minecraft:red_nether_bricks
setblock 321 43 208 minecraft:polished_blackstone
fill 321 43 209 321 46 209 minecraft:red_nether_bricks
setblock 321 43 212 minecraft:red_nether_bricks
setblock 321 43 213 minecraft:polished_blackstone
fill 321 43 214 321 46 214 minecraft:red_nether_bricks
setblock 322 43 186 minecraft:red_nether_bricks
setblock 322 43 187 minecraft:polished_blackstone
fill 322 43 188 322 46 188 minecraft:red_nether_bricks
fill 322 43 190 322 43 191 minecraft:red_nether_bricks
setblock 322 43 192 minecraft:polished_blackstone
fill 322 43 193 322 46 193 minecraft:red_nether_bricks
setblock 322 43 196 minecraft:red_nether_bricks
setblock 322 43 197 minecraft:polished_blackstone
fill 322 43 198 322 45 199 minecraft:red_nether_bricks
setblock 322 43 202 minecraft:polished_blackstone
fill 322 43 203 322 46 203 minecraft:red_nether_bricks
setblock 322 43 207 minecraft:polished_blackstone
fill 322 43 208 322 46 208 minecraft:red_nether_bricks
setblock 322 43 212 minecraft:polished_blackstone
fill 322 43 213 322 46 213 minecraft:red_nether_bricks
setblock 322 43 217 minecraft:polished_blackstone
fill 322 43 218 322 46 218 minecraft:red_nether_bricks
setblock 322 43 222 minecraft:polished_blackstone
fill 323 43 182 323 43 185 minecraft:red_nether_bricks
setblock 323 43 186 minecraft:polished_blackstone
fill 323 43 187 323 46 187 minecraft:red_nether_bricks
setblock 323 43 191 minecraft:polished_blackstone
fill 323 43 192 323 46 192 minecraft:red_nether_bricks
setblock 323 43 195 minecraft:red_nether_bricks
setblock 323 43 196 minecraft:polished_blackstone
fill 323 43 197 323 46 197 minecraft:red_nether_bricks
setblock 323 43 201 minecraft:polished_blackstone
fill 323 43 202 323 46 202 minecraft:red_nether_bricks
setblock 323 43 206 minecraft:polished_blackstone
fill 323 43 207 323 46 207 minecraft:red_nether_bricks
setblock 323 43 211 minecraft:polished_blackstone
fill 323 43 212 323 46 212 minecraft:red_nether_bricks
setblock 323 43 216 minecraft:polished_blackstone
fill 323 43 217 323 46 217 minecraft:red_nether_bricks
setblock 323 43 221 minecraft:polished_blackstone
fill 323 43 222 323 44 222 minecraft:red_nether_bricks
fill 283 44 182 283 44 184 minecraft:red_nether_bricks
setblock 283 44 185 minecraft:polished_blackstone
fill 283 44 186 283 44 189 minecraft:red_nether_bricks
setblock 283 44 190 minecraft:polished_blackstone
fill 283 44 191 283 47 191 minecraft:red_nether_bricks
setblock 283 44 195 minecraft:polished_blackstone
fill 283 44 196 283 47 196 minecraft:red_nether_bricks
setblock 283 44 200 minecraft:polished_blackstone
fill 283 44 201 283 47 201 minecraft:red_nether_bricks
setblock 283 44 205 minecraft:polished_blackstone
fill 283 44 206 283 47 206 minecraft:red_nether_bricks
setblock 283 44 210 minecraft:polished_blackstone
fill 283 44 211 283 47 211 minecraft:red_nether_bricks
setblock 283 44 215 minecraft:polished_blackstone
fill 283 44 216 283 47 216 minecraft:red_nether_bricks
setblock 284 44 184 minecraft:polished_blackstone
fill 284 44 185 284 44 188 minecraft:red_nether_bricks
setblock 284 44 189 minecraft:polished_blackstone
fill 284 44 190 284 47 190 minecraft:red_nether_bricks
setblock 284 44 194 minecraft:polished_blackstone
fill 284 44 195 284 47 195 minecraft:red_nether_bricks
setblock 284 44 199 minecraft:polished_blackstone
fill 284 44 200 284 47 200 minecraft:red_nether_bricks
setblock 284 44 204 minecraft:polished_blackstone
fill 284 44 205 284 45 205 minecraft:red_nether_bricks
setblock 284 44 209 minecraft:polished_blackstone
fill 284 44 210 284 47 210 minecraft:red_nether_bricks
setblock 284 44 213 minecraft:red_nether_bricks
setblock 284 44 214 minecraft:polished_blackstone
fill 284 44 215 284 47 215 minecraft:red_nether_bricks
setblock 285 44 183 minecraft:polished_blackstone
setblock 285 44 184 minecraft:light[level=14]
setblock 285 44 188 minecraft:polished_blackstone
fill 285 44 189 285 47 189 minecraft:red_nether_bricks
setblock 285 44 193 minecraft:polished_blackstone
fill 285 44 194 285 47 194 minecraft:red_nether_bricks
setblock 285 44 198 minecraft:polished_blackstone
setblock 285 44 200 minecraft:light[level=14]
setblock 285 44 208 minecraft:polished_blackstone
setblock 285 44 209 minecraft:red_nether_bricks
setblock 285 44 213 minecraft:polished_blackstone
setblock 285 44 216 minecraft:light[level=14]
setblock 286 44 182 minecraft:polished_blackstone
fill 286 44 183 286 45 183 minecraft:red_nether_bricks
setblock 286 44 187 minecraft:polished_blackstone
fill 286 44 188 286 45 188 minecraft:red_nether_bricks
setblock 286 44 192 minecraft:polished_blackstone
fill 286 44 193 286 46 193 minecraft:red_nether_bricks
fill 287 44 182 287 46 182 minecraft:red_nether_bricks
setblock 291 44 182 minecraft:polished_blackstone
setblock 292 44 182 minecraft:red_nether_bricks
setblock 293 44 184 minecraft:light[level=14]
setblock 293 44 192 minecraft:light[level=14]
setblock 293 44 200 minecraft:light[level=14]
setblock 293 44 208 minecraft:light[level=14]
setblock 293 44 216 minecraft:light[level=14]
setblock 296 44 182 minecraft:polished_blackstone
fill 297 44 182 297 46 182 minecraft:red_nether_bricks
setblock 300 44 183 minecraft:polished_blackstone
setblock 301 44 182 minecraft:polished_blackstone
fill 301 44 183 301 46 183 minecraft:red_nether_bricks
setblock 301 44 192 minecraft:light[level=14]
setblock 301 44 200 minecraft:light[level=14]
setblock 301 44 208 minecraft:light[level=14]
fill 301 44 211 301 45 211 minecraft:magma_block
setblock 301 44 216 minecraft:light[level=14]
setblock 301 44 221 minecraft:red_nether_bricks
setblock 301 44 222 minecraft:polished_blackstone
fill 302 44 182 302 47 182 minecraft:red_nether_bricks
setblock 302 44 221 minecraft:polished_blackstone
fill 302 44 222 302 47 222 minecraft:red_nether_bricks
fill 303 44 221 303 47 221 minecraft:red_nether_bricks
setblock 304 44 184 minecraft:polished_blackstone
setblock 305 44 183 minecraft:polished_blackstone
setblock 305 44 184 minecraft:red_nether_bricks
setblock 306 44 182 minecraft:polished_blackstone
fill 306 44 183 306 45 183 minecraft:red_nether_bricks
setblock 306 44 222 minecraft:polished_blackstone
fill 307 44 182 307 46 182 minecraft:red_nether_bricks
setblock 307 44 221 minecraft:polished_blackstone
fill 307 44 222 307 47 222 minecraft:red_nether_bricks
fill 308 44 221 308 45 221 minecraft:red_nether_bricks
setblock 309 44 184 minecraft:light[level=14]
setblock 309 44 192 minecraft:light[level=14]
setblock 309 44 200 minecraft:light[level=14]
setblock 309 44 208 minecraft:light[level=14]
setblock 309 44 216 minecraft:light[level=14]
setblock 311 44 222 minecraft:polished_blackstone
setblock 317 44 184 minecraft:light[level=14]
setblock 317 44 192 minecraft:light[level=14]
setblock 317 44 200 minecraft:light[level=14]
setblock 317 44 208 minecraft:light[level=14]
setblock 317 44 216 minecraft:light[level=14]
setblock 320 44 211 minecraft:red_nether_bricks
setblock 321 44 207 minecraft:polished_blackstone
fill 321 44 208 321 47 208 minecraft:red_nether_bricks
setblock 321 44 212 minecraft:polished_blackstone
fill 321 44 213 321 47 213 minecraft:red_nether_bricks
setblock 322 44 186 minecraft:polished_blackstone
fill 322 44 187 322 45 187 minecraft:red_nether_bricks
setblock 322 44 190 minecraft:red_nether_bricks
setblock 322 44 191 minecraft:polished_blackstone
fill 322 44 192 322 47 192 minecraft:red_nether_bricks
setblock 322 44 196 minecraft:polished_blackstone
fill 322 44 197 322 47 197 minecraft:red_nether_bricks
setblock 322 44 201 minecraft:polished_blackstone
fill 322 44 202 322 47 202 minecraft:red_nether_bricks
setblock 322 44 206 minecraft:polished_blackstone
fill 322 44 207 322 47 207 minecraft:red_nether_bricks
setblock 322 44 211 minecraft:polished_blackstone
fill 322 44 212 322 47 212 minecraft:red_nether_bricks
setblock 322 44 216 minecraft:polished_blackstone
fill 322 44 217 322 47 217 minecraft:red_nether_bricks
fill 323 44 183 323 44 184 minecraft:red_nether_bricks
setblock 323 44 185 minecraft:polished_blackstone
fill 323 44 186 323 47 186 minecraft:red_nether_bricks
setblock 323 44 190 minecraft:polished_blackstone
fill 323 44 191 323 47 191 minecraft:red_nether_bricks
setblock 323 44 195 minecraft:polished_blackstone
fill 323 44 196 323 47 196 minecraft:red_nether_bricks
setblock 323 44 200 minecraft:polished_blackstone
fill 323 44 201 323 47 201 minecraft:red_nether_bricks
setblock 323 44 205 minecraft:polished_blackstone
fill 323 44 206 323 47 206 minecraft:red_nether_bricks
setblock 323 44 210 minecraft:polished_blackstone
fill 323 44 211 323 47 211 minecraft:red_nether_bricks
setblock 323 44 215 minecraft:polished_blackstone
fill 323 44 216 323 47 216 minecraft:red_nether_bricks
setblock 323 44 220 minecraft:polished_blackstone
fill 323 44 221 323 46 221 minecraft:red_nether_bricks
fill 283 45 182 283 45 183 minecraft:red_nether_bricks
setblock 283 45 184 minecraft:polished_blackstone
fill 283 45 185 283 45 188 minecraft:red_nether_bricks
setblock 283 45 189 minecraft:polished_blackstone
fill 283 45 190 283 48 190 minecraft:red_nether_bricks
setblock 283 45 194 minecraft:polished_blackstone
fill 283 45 195 283 48 195 minecraft:red_nether_bricks
setblock 283 45 199 minecraft:polished_blackstone
fill 283 45 200 283 48 200 minecraft:red_nether_bricks
setblock 283 45 204 minecraft:polished_blackstone
fill 283 45 205 283 48 205 minecraft:red_nether_bricks
setblock 283 45 209 minecraft:polished_blackstone
fill 283 45 210 283 48 210 minecraft:red_nether_bricks
setblock 283 45 214 minecraft:polished_blackstone
fill 283 45 215 283 48 215 minecraft:red_nether_bricks
setblock 283 45 218 minecraft:red_nether_bricks
setblock 283 45 219 minecraft:polished_blackstone
setblock 284 45 183 minecraft:polished_blackstone
fill 284 45 184 284 45 187 minecraft:red_nether_bricks
setblock 284 45 188 minecraft:polished_blackstone
fill 284 45 189 284 48 189 minecraft:red_nether_bricks
setblock 284 45 193 minecraft:polished_blackstone
fill 284 45 194 284 48 194 minecraft:red_nether_bricks
setblock 284 45 198 minecraft:polished_blackstone
fill 284 45 199 284 48 199 minecraft:red_nether_bricks
setblock 284 45 203 minecraft:polished_blackstone
setblock 284 45 204 minecraft:red_nether_bricks
setblock 284 45 208 minecraft:polished_blackstone
fill 284 45 209 284 47 209 minecraft:red_nether_bricks
setblock 284 45 213 minecraft:polished_blackstone
fill 284 45 214 284 48 214 minecraft:red_nether_bricks
setblock 285 45 182 minecraft:polished_blackstone
setblock 285 45 183 minecraft:red_nether_bricks
setblock 285 45 187 minecraft:polished_blackstone
fill 285 45 188 285 47 188 minecraft:red_nether_bricks
setblock 285 45 192 minecraft:polished_blackstone
fill 285 45 193 285 48 193 minecraft:red_nether_bricks
setblock 285 45 197 minecraft:polished_blackstone
fill 285 45 206 285 49 206 minecraft:gilded_blackstone
fill 286 45 182 286 46 182 minecraft:red_nether_bricks
setblock 286 45 191 minecraft:polished_blackstone
fill 286 45 192 286 46 192 minecraft:red_nether_bricks
setblock 299 45 183 minecraft:polished_blackstone
setblock 300 45 182 minecraft:polished_blackstone
fill 300 45 183 300 46 183 minecraft:red_nether_bricks
setblock 300 45 222 minecraft:polished_blackstone
fill 301 45 182 301 48 182 minecraft:red_nether_bricks
setblock 301 45 221 minecraft:polished_blackstone
fill 301 45 222 301 48 222 minecraft:red_nether_bricks
fill 302 45 221 302 48 221 minecraft:red_nether_bricks
setblock 304 45 183 minecraft:polished_blackstone
setblock 305 45 182 minecraft:polished_blackstone
setblock 305 45 183 minecraft:red_nether_bricks
setblock 305 45 222 minecraft:polished_blackstone
fill 306 45 182 306 47 182 minecraft:red_nether_bricks
setblock 306 45 221 minecraft:polished_blackstone
fill 306 45 222 306 48 222 minecraft:red_nether_bricks
fill 307 45 221 307 46 221 minecraft:red_nether_bricks
setblock 310 45 222 minecraft:polished_blackstone
setblock 321 45 206 minecraft:polished_blackstone
fill 321 45 207 321 46 207 minecraft:red_nether_bricks
setblock 321 45 211 minecraft:polished_blackstone
fill 321 45 212 321 48 212 minecraft:red_nether_bricks
setblock 321 45 216 minecraft:polished_blackstone
setblock 322 45 190 minecraft:polished_blackstone
fill 322 45 191 322 48 191 minecraft:red_nether_bricks
setblock 322 45 194 minecraft:red_nether_bricks
setblock 322 45 195 minecraft:polished_blackstone
fill 322 45 196 322 48 196 minecraft:red_nether_bricks
setblock 322 45 200 minecraft:polished_blackstone
fill 322 45 201 322 48 201 minecraft:red_nether_bricks
setblock 322 45 205 minecraft:polished_blackstone
fill 322 45 206 322 48 206 minecraft:red_nether_bricks
setblock 322 45 210 minecraft:polished_blackstone
fill 322 45 211 322 48 211 minecraft:red_nether_bricks
setblock 322 45 215 minecraft:polished_blackstone
fill 322 45 216 322 48 216 minecraft:red_nether_bricks
setblock 323 45 184 minecraft:polished_blackstone
fill 323 45 185 323 47 185 minecraft:red_nether_bricks
setblock 323 45 189 minecraft:polished_blackstone
fill 323 45 190 323 48 190 minecraft:red_nether_bricks
setblock 323 45 194 minecraft:polished_blackstone
fill 323 45 195 323 48 195 minecraft:red_nether_bricks
setblock 323 45 199 minecraft:polished_blackstone
fill 323 45 200 323 48 200 minecraft:red_nether_bricks
setblock 323 45 204 minecraft:polished_blackstone
fill 323 45 205 323 48 205 minecraft:red_nether_bricks
setblock 323 45 209 minecraft:polished_blackstone
fill 323 45 210 323 48 210 minecraft:red_nether_bricks
setblock 323 45 214 minecraft:polished_blackstone
fill 323 45 215 323 48 215 minecraft:red_nether_bricks
setblock 323 45 219 minecraft:polished_blackstone
fill 323 45 220 323 48 220 minecraft:red_nether_bricks
setblock 283 46 182 minecraft:red_nether_bricks
setblock 283 46 183 minecraft:polished_blackstone
fill 283 46 184 283 46 187 minecraft:red_nether_bricks
setblock 283 46 188 minecraft:polished_blackstone
fill 283 46 189 283 49 189 minecraft:red_nether_bricks
setblock 283 46 193 minecraft:polished_blackstone
fill 283 46 194 283 49 194 minecraft:red_nether_bricks
setblock 283 46 198 minecraft:polished_blackstone
fill 283 46 199 283 49 199 minecraft:red_nether_bricks
setblock 283 46 203 minecraft:polished_blackstone
fill 283 46 204 283 49 204 minecraft:red_nether_bricks
setblock 283 46 208 minecraft:polished_blackstone
fill 283 46 209 283 49 209 minecraft:red_nether_bricks
setblock 283 46 213 minecraft:polished_blackstone
fill 283 46 214 283 49 214 minecraft:red_nether_bricks
setblock 283 46 218 minecraft:polished_blackstone
fill 283 46 219 283 49 219 minecraft:red_nether_bricks
setblock 284 46 182 minecraft:polished_blackstone
fill 284 46 184 284 46 186 minecraft:red_nether_bricks
setblock 284 46 187 minecraft:polished_blackstone
fill 284 46 188 284 49 188 minecraft:red_nether_bricks
setblock 284 46 192 minecraft:polished_blackstone
fill 284 46 193 284 49 193 minecraft:red_nether_bricks
setblock 284 46 197 minecraft:polished_blackstone
fill 284 46 198 284 49 198 minecraft:red_nether_bricks
fill 284 46 205 286 46 205 minecraft:polished_blackstone
fill 284 46 207 286 46 207 minecraft:polished_blackstone
setblock 284 46 208 minecraft:red_nether_bricks
setblock 284 46 212 minecraft:polished_blackstone
fill 284 46 213 284 48 213 minecraft:red_nether_bricks
fill 285 46 182 285 47 182 minecraft:red_nether_bricks
setblock 285 46 187 minecraft:red_nether_bricks
setblock 285 46 191 minecraft:polished_blackstone
fill 285 46 192 285 49 192 minecraft:red_nether_bricks
setblock 285 46 196 minecraft:polished_blackstone
fill 285 46 197 285 47 197 minecraft:red_nether_bricks
setblock 286 46 190 minecraft:polished_blackstone
setblock 286 46 191 minecraft:red_nether_bricks
setblock 286 46 206 minecraft:polished_blackstone
setblock 299 46 182 minecraft:polished_blackstone
setblock 299 46 222 minecraft:polished_blackstone
fill 300 46 182 300 49 182 minecraft:red_nether_bricks
fill 300 46 222 300 49 222 minecraft:red_nether_bricks
fill 301 46 221 301 49 221 minecraft:red_nether_bricks
setblock 303 46 183 minecraft:polished_blackstone
setblock 304 46 182 minecraft:polished_blackstone
setblock 304 46 183 minecraft:red_nether_bricks
setblock 304 46 222 minecraft:polished_blackstone
fill 305 46 182 305 48 182 minecraft:red_nether_bricks
setblock 305 46 221 minecraft:polished_blackstone
fill 305 46 222 305 49 222 minecraft:red_nether_bricks
fill 306 46 221 306 49 221 minecraft:red_nether_bricks
setblock 309 46 222 minecraft:polished_blackstone
setblock 321 46 210 minecraft:polished_blackstone
fill 321 46 211 321 49 211 minecraft:red_nether_bricks
setblock 321 46 215 minecraft:polished_blackstone
fill 321 46 216 321 49 216 minecraft:red_nether_bricks
setblock 322 46 189 minecraft:polished_blackstone
fill 322 46 190 322 49 190 minecraft:red_nether_bricks
setblock 322 46 194 minecraft:polished_blackstone
fill 322 46 195 322 49 195 minecraft:red_nether_bricks
setblock 322 46 198 minecraft:red_nether_bricks
setblock 322 46 199 minecraft:polished_blackstone
fill 322 46 200 322 49 200 minecraft:red_nether_bricks
setblock 322 46 204 minecraft:polished_blackstone
fill 322 46 205 322 49 205 minecraft:red_nether_bricks
setblock 322 46 209 minecraft:polished_blackstone
fill 322 46 210 322 49 210 minecraft:red_nether_bricks
setblock 322 46 214 minecraft:polished_blackstone
fill 322 46 215 322 49 215 minecraft:red_nether_bricks
setblock 323 46 188 minecraft:polished_blackstone
fill 323 46 189 323 49 189 minecraft:red_nether_bricks
setblock 323 46 193 minecraft:polished_blackstone
fill 323 46 194 323 49 194 minecraft:red_nether_bricks
setblock 323 46 198 minecraft:polished_blackstone
fill 323 46 199 323 49 199 minecraft:red_nether_bricks
setblock 323 46 203 minecraft:polished_blackstone
fill 323 46 204 323 49 204 minecraft:red_nether_bricks
setblock 323 46 208 minecraft:polished_blackstone
fill 323 46 209 323 49 209 minecraft:red_nether_bricks
setblock 323 46 213 minecraft:polished_blackstone
fill 323 46 214 323 49 214 minecraft:red_nether_bricks
setblock 323 46 218 minecraft:polished_blackstone
fill 323 46 219 323 49 219 minecraft:red_nether_bricks
setblock 283 47 182 minecraft:polished_blackstone
fill 283 47 183 283 47 186 minecraft:red_nether_bricks
setblock 283 47 187 minecraft:polished_blackstone
fill 283 47 188 283 49 188 minecraft:red_nether_bricks
setblock 283 47 192 minecraft:polished_blackstone
fill 283 47 193 283 49 193 minecraft:red_nether_bricks
setblock 283 47 197 minecraft:polished_blackstone
fill 283 47 198 283 49 198 minecraft:red_nether_bricks
setblock 283 47 202 minecraft:polished_blackstone
fill 283 47 203 283 49 203 minecraft:red_nether_bricks
setblock 283 47 207 minecraft:polished_blackstone
fill 283 47 208 283 49 208 minecraft:red_nether_bricks
setblock 283 47 212 minecraft:polished_blackstone
fill 283 47 213 283 49 213 minecraft:red_nether_bricks
setblock 283 47 217 minecraft:polished_blackstone
fill 283 47 218 283 49 218 minecraft:red_nether_bricks
setblock 284 47 182 minecraft:red_nether_bricks
setblock 284 47 185 minecraft:red_nether_bricks
setblock 284 47 186 minecraft:polished_blackstone
fill 284 47 187 284 49 187 minecraft:red_nether_bricks
setblock 284 47 191 minecraft:polished_blackstone
fill 284 47 192 284 49 192 minecraft:red_nether_bricks
setblock 284 47 196 minecraft:polished_blackstone
fill 284 47 197 284 49 197 minecraft:red_nether_bricks
setblock 284 47 211 minecraft:polished_blackstone
setblock 284 47 212 minecraft:red_nether_bricks
setblock 285 47 190 minecraft:polished_blackstone
fill 285 47 191 285 49 191 minecraft:red_nether_bricks
setblock 285 47 195 minecraft:polished_blackstone
fill 285 47 196 285 49 196 minecraft:red_nether_bricks
setblock 298 47 182 minecraft:polished_blackstone
setblock 298 47 222 minecraft:polished_blackstone
fill 299 47 182 299 49 182 minecraft:red_nether_bricks
fill 299 47 222 299 49 222 minecraft:red_nether_bricks
fill 300 47 221 300 49 221 minecraft:red_nether_bricks
setblock 303 47 182 minecraft:polished_blackstone
setblock 303 47 222 minecraft:polished_blackstone
fill 304 47 182 304 49 182 minecraft:red_nether_bricks
setblock 304 47 221 minecraft:polished_blackstone
fill 304 47 222 304 49 222 minecraft:red_nether_bricks
fill 305 47 221 305 49 221 minecraft:red_nether_bricks
setblock 308 47 222 minecraft:polished_blackstone
setblock 321 47 193 minecraft:red_nether_bricks
setblock 321 47 194 minecraft:polished_blackstone
fill 321 47 195 321 49 195 minecraft:red_nether_bricks
setblock 321 47 209 minecraft:polished_blackstone
fill 321 47 210 321 48 210 minecraft:red_nether_bricks
setblock 321 47 214 minecraft:polished_blackstone
fill 321 47 215 321 49 215 minecraft:red_nether_bricks
setblock 322 47 188 minecraft:polished_blackstone
fill 322 47 189 322 49 189 minecraft:red_nether_bricks
setblock 322 47 193 minecraft:polished_blackstone
fill 322 47 194 322 49 194 minecraft:red_nether_bricks
setblock 322 47 198 minecraft:polished_blackstone
fill 322 47 199 322 49 199 minecraft:red_nether_bricks
setblock 322 47 203 minecraft:polished_blackstone
fill 322 47 204 322 49 204 minecraft:red_nether_bricks
setblock 322 47 208 minecraft:polished_blackstone
fill 322 47 209 322 49 209 minecraft:red_nether_bricks
setblock 322 47 213 minecraft:polished_blackstone
fill 322 47 214 322 49 214 minecraft:red_nether_bricks
setblock 322 47 218 minecraft:polished_blackstone
setblock 323 47 187 minecraft:polished_blackstone
fill 323 47 188 323 49 188 minecraft:red_nether_bricks
setblock 323 47 192 minecraft:polished_blackstone
fill 323 47 193 323 49 193 minecraft:red_nether_bricks
setblock 323 47 197 minecraft:polished_blackstone
fill 323 47 198 323 49 198 minecraft:red_nether_bricks
setblock 323 47 202 minecraft:polished_blackstone
fill 323 47 203 323 49 203 minecraft:red_nether_bricks
setblock 323 47 207 minecraft:polished_blackstone
fill 323 47 208 323 49 208 minecraft:red_nether_bricks
setblock 323 47 212 minecraft:polished_blackstone
fill 323 47 213 323 49 213 minecraft:red_nether_bricks
setblock 323 47 217 minecraft:polished_blackstone
fill 323 47 218 323 49 218 minecraft:red_nether_bricks
fill 283 48 182 283 48 185 minecraft:red_nether_bricks
setblock 283 48 186 minecraft:polished_blackstone
fill 283 48 187 283 49 187 minecraft:red_nether_bricks
setblock 283 48 191 minecraft:polished_blackstone
fill 283 48 192 283 49 192 minecraft:red_nether_bricks
setblock 283 48 196 minecraft:polished_blackstone
fill 283 48 197 283 49 197 minecraft:red_nether_bricks
setblock 283 48 201 minecraft:polished_blackstone
fill 283 48 202 283 49 202 minecraft:red_nether_bricks
setblock 283 48 206 minecraft:polished_blackstone
fill 283 48 207 283 49 207 minecraft:red_nether_bricks
setblock 283 48 211 minecraft:polished_blackstone
fill 283 48 212 283 49 212 minecraft:red_nether_bricks
setblock 283 48 216 minecraft:polished_blackstone
fill 283 48 217 283 49 217 minecraft:red_nether_bricks
setblock 284 48 186 minecraft:red_nether_bricks
setblock 284 48 190 minecraft:polished_blackstone
fill 284 48 191 284 49 191 minecraft:red_nether_bricks
setblock 284 48 195 minecraft:polished_blackstone
fill 284 48 196 284 49 196 minecraft:red_nether_bricks
setblock 284 48 200 minecraft:polished_blackstone
setblock 284 48 215 minecraft:polished_blackstone
setblock 285 48 189 minecraft:polished_blackstone
fill 285 48 190 285 49 190 minecraft:red_nether_bricks
setblock 285 48 194 minecraft:polished_blackstone
fill 285 48 195 285 49 195 minecraft:red_nether_bricks
setblock 297 48 222 minecraft:polished_blackstone
fill 298 48 182 298 49 182 minecraft:red_nether_bricks
fill 298 48 222 298 49 222 minecraft:red_nether_bricks
fill 299 48 221 299 49 221 minecraft:red_nether_bricks
setblock 302 48 182 minecraft:polished_blackstone
fill 302 48 220 303 48 220 minecraft:red_nether_bricks
setblock 302 48 222 minecraft:polished_blackstone
fill 303 48 182 303 49 182 minecraft:red_nether_bricks
setblock 303 48 221 minecraft:polished_blackstone
fill 303 48 222 303 49 222 minecraft:red_nether_bricks
setblock 304 48 220 minecraft:polished_blackstone
fill 304 48 221 304 49 221 minecraft:red_nether_bricks
setblock 307 48 222 minecraft:polished_blackstone
fill 308 48 222 308 49 222 minecraft:red_nether_bricks
setblock 321 48 192 minecraft:red_nether_bricks
setblock 321 48 193 minecraft:polished_blackstone
fill 321 48 194 321 49 194 minecraft:red_nether_bricks
fill 321 48 196 321 49 196 minecraft:red_nether_bricks
setblock 321 48 213 minecraft:polished_blackstone
fill 321 48 214 321 49 214 minecraft:red_nether_bricks
setblock 322 48 192 minecraft:polished_blackstone
fill 322 48 193 322 49 193 minecraft:red_nether_bricks
setblock 322 48 197 minecraft:polished_blackstone
fill 322 48 198 322 49 198 minecraft:red_nether_bricks
setblock 322 48 202 minecraft:polished_blackstone
fill 322 48 203 322 49 203 minecraft:red_nether_bricks
setblock 322 48 207 minecraft:polished_blackstone
fill 322 48 208 322 49 208 minecraft:red_nether_bricks
setblock 322 48 212 minecraft:polished_blackstone
fill 322 48 213 322 49 213 minecraft:red_nether_bricks
setblock 322 48 217 minecraft:polished_blackstone
fill 322 48 218 322 49 218 minecraft:red_nether_bricks
setblock 323 48 186 minecraft:polished_blackstone
fill 323 48 187 323 49 187 minecraft:red_nether_bricks
setblock 323 48 191 minecraft:polished_blackstone
fill 323 48 192 323 49 192 minecraft:red_nether_bricks
setblock 323 48 196 minecraft:polished_blackstone
fill 323 48 197 323 49 197 minecraft:red_nether_bricks
setblock 323 48 201 minecraft:polished_blackstone
fill 323 48 202 323 49 202 minecraft:red_nether_bricks
setblock 323 48 206 minecraft:polished_blackstone
fill 323 48 207 323 49 207 minecraft:red_nether_bricks
setblock 323 48 211 minecraft:polished_blackstone
fill 323 48 212 323 49 212 minecraft:red_nether_bricks
setblock 323 48 216 minecraft:polished_blackstone
fill 323 48 217 323 49 217 minecraft:red_nether_bricks
fill 283 49 182 283 49 184 minecraft:red_nether_bricks
setblock 283 49 185 minecraft:polished_blackstone
setblock 283 49 186 minecraft:red_nether_bricks
setblock 283 49 190 minecraft:polished_blackstone
setblock 283 49 191 minecraft:red_nether_bricks
setblock 283 49 195 minecraft:polished_blackstone
setblock 283 49 196 minecraft:red_nether_bricks
setblock 283 49 200 minecraft:polished_blackstone
setblock 283 49 201 minecraft:red_nether_bricks
setblock 283 49 205 minecraft:polished_blackstone
setblock 283 49 206 minecraft:red_nether_bricks
setblock 283 49 210 minecraft:polished_blackstone
setblock 283 49 211 minecraft:red_nether_bricks
setblock 283 49 215 minecraft:polished_blackstone
setblock 283 49 216 minecraft:red_nether_bricks
setblock 283 49 220 minecraft:polished_blackstone
setblock 284 49 189 minecraft:polished_blackstone
setblock 284 49 190 minecraft:red_nether_bricks
setblock 284 49 194 minecraft:polished_blackstone
setblock 284 49 195 minecraft:red_nether_bricks
setblock 284 49 199 minecraft:polished_blackstone
setblock 284 49 200 minecraft:red_nether_bricks
setblock 285 49 193 minecraft:polished_blackstone
setblock 285 49 194 minecraft:red_nether_bricks
setblock 296 49 222 minecraft:polished_blackstone
setblock 297 49 182 minecraft:red_nether_bricks
setblock 297 49 222 minecraft:red_nether_bricks
setblock 298 49 221 minecraft:red_nether_bricks
fill 300 49 220 302 49 220 minecraft:red_nether_bricks
setblock 301 49 182 minecraft:polished_blackstone
setblock 301 49 222 minecraft:polished_blackstone
setblock 302 49 182 minecraft:red_nether_bricks
setblock 302 49 221 minecraft:polished_blackstone
setblock 302 49 222 minecraft:red_nether_bricks
setblock 303 49 220 minecraft:polished_blackstone
setblock 303 49 221 minecraft:red_nether_bricks
setblock 304 49 220 minecraft:red_nether_bricks
setblock 306 49 222 minecraft:polished_blackstone
setblock 307 49 222 minecraft:red_nether_bricks
setblock 321 49 192 minecraft:polished_blackstone
setblock 321 49 193 minecraft:red_nether_bricks
setblock 321 49 197 minecraft:polished_blackstone
setblock 321 49 198 minecraft:red_nether_bricks
setblock 321 49 212 minecraft:polished_blackstone
setblock 321 49 213 minecraft:red_nether_bricks
setblock 322 49 191 minecraft:polished_blackstone
setblock 322 49 192 minecraft:red_nether_bricks
setblock 322 49 196 minecraft:polished_blackstone
setblock 322 49 197 minecraft:red_nether_bricks
setblock 322 49 201 minecraft:polished_blackstone
setblock 322 49 202 minecraft:red_nether_bricks
setblock 322 49 206 minecraft:polished_blackstone
setblock 322 49 207 minecraft:red_nether_bricks
setblock 322 49 211 minecraft:polished_blackstone
setblock 322 49 212 minecraft:red_nether_bricks
setblock 322 49 216 minecraft:polished_blackstone
setblock 322 49 217 minecraft:red_nether_bricks
setblock 322 49 219 minecraft:red_nether_bricks
setblock 323 49 190 minecraft:polished_blackstone
setblock 323 49 191 minecraft:red_nether_bricks
setblock 323 49 195 minecraft:polished_blackstone
setblock 323 49 196 minecraft:red_nether_bricks
setblock 323 49 200 minecraft:polished_blackstone
setblock 323 49 201 minecraft:red_nether_bricks
setblock 323 49 205 minecraft:polished_blackstone
setblock 323 49 206 minecraft:red_nether_bricks
setblock 323 49 210 minecraft:polished_blackstone
setblock 323 49 211 minecraft:red_nether_bricks
setblock 323 49 215 minecraft:polished_blackstone
setblock 323 49 216 minecraft:red_nether_bricks
setblock 323 49 220 minecraft:polished_blackstone
setblock 323 49 221 minecraft:red_nether_bricks
setblock 285 52 184 minecraft:light[level=14]
setblock 285 52 192 minecraft:light[level=14]
setblock 285 52 200 minecraft:light[level=14]
setblock 285 52 208 minecraft:light[level=14]
setblock 285 52 216 minecraft:light[level=14]
setblock 293 52 184 minecraft:light[level=14]
setblock 293 52 192 minecraft:light[level=14]
setblock 293 52 200 minecraft:light[level=14]
setblock 293 52 208 minecraft:light[level=14]
setblock 293 52 216 minecraft:light[level=14]
setblock 301 52 184 minecraft:light[level=14]
setblock 301 52 192 minecraft:light[level=14]
setblock 301 52 200 minecraft:light[level=14]
setblock 301 52 208 minecraft:light[level=14]
setblock 301 52 216 minecraft:light[level=14]
setblock 309 52 184 minecraft:light[level=14]
setblock 309 52 192 minecraft:light[level=14]
setblock 309 52 200 minecraft:light[level=14]
setblock 309 52 208 minecraft:light[level=14]
setblock 309 52 216 minecraft:light[level=14]
setblock 317 52 184 minecraft:light[level=14]
setblock 317 52 192 minecraft:light[level=14]
setblock 317 52 200 minecraft:light[level=14]
setblock 317 52 208 minecraft:light[level=14]
setblock 317 52 216 minecraft:light[level=14]
fill 283 55 182 284 56 222 minecraft:magma_block
fill 285 55 182 285 56 222 minecraft:nether_bricks
fill 286 55 182 287 56 222 minecraft:magma_block
fill 288 55 182 288 56 222 minecraft:nether_bricks
fill 289 55 182 290 56 222 minecraft:magma_block
fill 291 55 182 291 56 222 minecraft:nether_bricks
fill 292 55 182 293 56 222 minecraft:magma_block
fill 294 55 182 294 56 222 minecraft:nether_bricks
fill 295 55 182 295 55 222 minecraft:magma_block
fill 296 55 182 296 55 204 minecraft:magma_block
fill 296 55 206 296 55 222 minecraft:magma_block
fill 297 55 182 297 55 202 minecraft:nether_bricks
fill 297 55 208 297 55 222 minecraft:nether_bricks
fill 298 55 182 298 55 202 minecraft:magma_block
fill 298 55 208 298 55 222 minecraft:magma_block
fill 299 55 182 299 55 201 minecraft:magma_block
fill 299 55 209 299 55 222 minecraft:magma_block
fill 300 55 182 300 55 202 minecraft:nether_bricks
fill 300 55 208 300 55 222 minecraft:nether_bricks
fill 301 55 182 302 55 202 minecraft:magma_block
fill 301 55 208 302 55 222 minecraft:magma_block
fill 302 55 203 302 55 204 minecraft:magma_block
fill 302 55 206 302 55 207 minecraft:magma_block
fill 303 55 182 303 55 222 minecraft:nether_bricks
fill 304 55 182 305 56 222 minecraft:magma_block
fill 306 55 182 306 56 222 minecraft:nether_bricks
fill 307 55 182 308 56 222 minecraft:magma_block
fill 309 55 182 309 56 222 minecraft:nether_bricks
fill 310 55 182 311 56 222 minecraft:magma_block
fill 312 55 182 312 56 222 minecraft:nether_bricks
fill 313 55 182 314 56 222 minecraft:magma_block
fill 315 55 182 315 56 222 minecraft:nether_bricks
fill 316 55 182 317 56 222 minecraft:magma_block
fill 318 55 182 318 56 222 minecraft:nether_bricks
fill 319 55 182 320 56 222 minecraft:magma_block
fill 321 55 182 321 56 222 minecraft:nether_bricks
fill 322 55 182 323 56 222 minecraft:magma_block
fill 295 56 182 295 56 203 minecraft:magma_block
fill 295 56 204 295 56 206 minecraft:shroomlight
fill 295 56 207 295 56 222 minecraft:magma_block
fill 296 56 182 296 56 201 minecraft:magma_block
fill 296 56 202 296 56 204 minecraft:shroomlight
fill 296 56 206 296 56 208 minecraft:shroomlight
fill 296 56 209 296 56 222 minecraft:magma_block
fill 297 56 182 297 56 201 minecraft:nether_bricks
fill 297 56 202 298 56 202 minecraft:shroomlight
fill 297 56 208 298 56 208 minecraft:shroomlight
fill 297 56 209 297 56 222 minecraft:nether_bricks
fill 298 56 182 299 56 200 minecraft:magma_block
fill 298 56 201 300 56 201 minecraft:shroomlight
fill 298 56 209 300 56 209 minecraft:shroomlight
fill 298 56 210 299 56 222 minecraft:magma_block
fill 300 56 182 300 56 200 minecraft:nether_bricks
fill 300 56 202 302 56 202 minecraft:shroomlight
fill 300 56 208 302 56 208 minecraft:shroomlight
fill 300 56 210 300 56 222 minecraft:nether_bricks
fill 301 56 182 302 56 201 minecraft:magma_block
fill 301 56 209 302 56 222 minecraft:magma_block
fill 302 56 203 302 56 204 minecraft:shroomlight
fill 302 56 206 302 56 207 minecraft:shroomlight
fill 303 56 182 303 56 203 minecraft:nether_bricks
fill 303 56 204 303 56 206 minecraft:shroomlight
fill 303 56 207 303 56 222 minecraft:nether_bricks
fill 283 60 182 283 60 183 minecraft:red_nether_bricks
setblock 283 60 184 minecraft:polished_blackstone
fill 283 60 185 283 61 187 minecraft:red_nether_bricks
fill 283 60 196 283 60 198 minecraft:red_nether_bricks
setblock 283 60 199 minecraft:polished_blackstone
fill 283 60 200 283 60 203 minecraft:red_nether_bricks
fill 283 60 220 283 60 222 minecraft:red_nether_bricks
setblock 284 60 182 minecraft:red_nether_bricks
setblock 284 60 183 minecraft:polished_blackstone
setblock 284 60 222 minecraft:red_nether_bricks
setblock 285 60 182 minecraft:polished_blackstone
fill 285 60 183 288 60 183 minecraft:red_nether_bricks
setblock 285 60 184 minecraft:light[level=14]
setblock 285 60 192 minecraft:light[level=14]
setblock 285 60 200 minecraft:light[level=14]
setblock 285 60 208 minecraft:light[level=14]
setblock 285 60 216 minecraft:light[level=14]
setblock 285 60 222 minecraft:polished_blackstone
fill 286 60 182 289 60 182 minecraft:red_nether_bricks
fill 286 60 221 287 60 221 minecraft:magma_block
fill 286 60 222 289 60 222 minecraft:red_nether_bricks
fill 287 60 218 289 60 220 minecraft:magma_block
fill 288 60 217 288 61 217 minecraft:magma_block
fill 288 60 221 290 60 221 minecraft:red_nether_bricks
setblock 289 60 183 minecraft:polished_blackstone
setblock 290 60 182 minecraft:polished_blackstone
fill 290 60 183 293 60 183 minecraft:red_nether_bricks
fill 290 60 197 291 61 198 minecraft:magma_block
setblock 290 60 222 minecraft:polished_blackstone
fill 291 60 182 294 60 182 minecraft:red_nether_bricks
setblock 291 60 220 minecraft:red_nether_bricks
setblock 291 60 221 minecraft:polished_blackstone
fill 291 60 222 294 60 222 minecraft:red_nether_bricks
setblock 292 60 220 minecraft:polished_blackstone
fill 292 60 221 295 60 221 minecraft:red_nether_bricks
setblock 293 60 184 minecraft:polished_blackstone
setblock 293 60 192 minecraft:light[level=14]
setblock 293 60 200 minecraft:light[level=14]
setblock 293 60 208 minecraft:light[level=14]
setblock 293 60 216 minecraft:light[level=14]
fill 293 60 220 296 60 220 minecraft:red_nether_bricks
setblock 294 60 183 minecraft:polished_blackstone
fill 294 60 184 296 60 184 minecraft:red_nether_bricks
setblock 295 60 182 minecraft:polished_blackstone
fill 295 60 183 298 60 183 minecraft:red_nether_bricks
fill 295 60 219 297 60 219 minecraft:red_nether_bricks
setblock 295 60 222 minecraft:polished_blackstone
fill 296 60 182 299 60 182 minecraft:red_nether_bricks
setblock 296 60 221 minecraft:polished_blackstone
fill 296 60 222 299 60 222 minecraft:red_nether_bricks
setblock 297 60 220 minecraft:polished_blackstone
fill 297 60 221 300 60 221 minecraft:red_nether_bricks
fill 298 60 220 301 60 220 minecraft:red_nether_bricks
setblock 299 60 183 minecraft:polished_blackstone
setblock 300 60 182 minecraft:polished_blackstone
setblock 300 60 183 minecraft:red_nether_bricks
fill 300 60 218 300 136 218 minecraft:gilded_blackstone
setblock 300 60 222 minecraft:polished_blackstone
fill 301 60 182 303 60 182 minecraft:red_nether_bricks
setblock 301 60 184 minecraft:light[level=14]
setblock 301 60 192 minecraft:light[level=14]
setblock 301 60 200 minecraft:light[level=14]
setblock 301 60 208 minecraft:light[level=14]
setblock 301 60 216 minecraft:light[level=14]
setblock 301 60 221 minecraft:polished_blackstone
fill 301 60 222 304 60 222 minecraft:red_nether_bricks
fill 302 60 221 304 60 221 minecraft:red_nether_bricks
setblock 305 60 222 minecraft:polished_blackstone
fill 306 60 222 309 60 222 minecraft:red_nether_bricks
setblock 309 60 184 minecraft:light[level=14]
setblock 309 60 192 minecraft:light[level=14]
setblock 309 60 200 minecraft:light[level=14]
setblock 309 60 208 minecraft:light[level=14]
setblock 309 60 216 minecraft:light[level=14]
setblock 310 60 222 minecraft:polished_blackstone
fill 311 60 182 314 60 182 minecraft:red_nether_bricks
fill 311 60 184 313 65 184 minecraft:gilded_blackstone
setblock 311 60 221 minecraft:polished_blackstone
fill 311 60 222 314 60 222 minecraft:red_nether_bricks
fill 312 60 183 312 63 183 minecraft:gilded_blackstone
fill 312 60 185 312 96 185 minecraft:gilded_blackstone
fill 312 60 186 312 61 186 minecraft:blackstone
fill 312 60 221 315 60 221 minecraft:red_nether_bricks
setblock 314 60 183 minecraft:polished_blackstone
setblock 315 60 182 minecraft:polished_blackstone
fill 315 60 183 318 60 183 minecraft:red_nether_bricks
setblock 315 60 222 minecraft:polished_blackstone
fill 316 60 182 319 60 182 minecraft:red_nether_bricks
setblock 316 60 221 minecraft:polished_blackstone
fill 316 60 222 319 60 222 minecraft:red_nether_bricks
setblock 317 60 184 minecraft:light[level=14]
setblock 317 60 192 minecraft:light[level=14]
setblock 317 60 200 minecraft:light[level=14]
setblock 317 60 208 minecraft:light[level=14]
setblock 317 60 216 minecraft:light[level=14]
fill 317 60 221 318 60 221 minecraft:red_nether_bricks
setblock 319 60 183 minecraft:polished_blackstone
fill 319 60 189 323 61 189 minecraft:magma_block
setblock 320 60 182 minecraft:polished_blackstone
fill 320 60 183 320 61 183 minecraft:red_nether_bricks
fill 320 60 188 323 61 188 minecraft:magma_block
fill 320 60 190 323 61 190 minecraft:magma_block
setblock 320 60 222 minecraft:polished_blackstone
fill 321 60 182 323 61 182 minecraft:red_nether_bricks
fill 321 60 198 321 60 200 minecraft:red_nether_bricks
setblock 321 60 201 minecraft:polished_blackstone
fill 321 60 202 323 60 203 minecraft:red_nether_bricks
fill 321 60 222 322 60 222 minecraft:red_nether_bricks
setblock 322 60 187 minecraft:magma_block
setblock 322 60 191 minecraft:magma_block
fill 322 60 196 322 60 199 minecraft:red_nether_bricks
setblock 322 60 200 minecraft:polished_blackstone
fill 322 60 201 323 62 201 minecraft:red_nether_bricks
setblock 322 60 204 minecraft:red_nether_bricks
setblock 322 60 205 minecraft:polished_blackstone
setblock 323 60 183 minecraft:red_nether_bricks
setblock 323 60 184 minecraft:polished_blackstone
fill 323 60 185 323 62 186 minecraft:red_nether_bricks
setblock 323 60 193 minecraft:red_nether_bricks
setblock 323 60 194 minecraft:polished_blackstone
fill 323 60 195 323 60 198 minecraft:red_nether_bricks
setblock 323 60 199 minecraft:polished_blackstone
fill 323 60 200 323 63 200 minecraft:red_nether_bricks
setblock 323 60 204 minecraft:polished_blackstone
fill 323 60 205 323 60 206 minecraft:red_nether_bricks
setblock 283 61 182 minecraft:red_nether_bricks
setblock 283 61 183 minecraft:polished_blackstone
fill 283 61 184 283 64 184 minecraft:red_nether_bricks
fill 283 61 221 283 61 222 minecraft:red_nether_bricks
setblock 284 61 182 minecraft:polished_blackstone
fill 284 61 183 287 61 183 minecraft:red_nether_bricks
setblock 284 61 222 minecraft:polished_blackstone
fill 285 61 182 288 61 182 minecraft:red_nether_bricks
fill 285 61 222 288 61 222 minecraft:red_nether_bricks
fill 287 61 219 288 61 221 minecraft:magma_block
setblock 288 61 183 minecraft:polished_blackstone
setblock 288 61 218 minecraft:magma_block
setblock 289 61 182 minecraft:polished_blackstone
fill 289 61 183 292 61 183 minecraft:red_nether_bricks
fill 289 61 219 289 61 220 minecraft:magma_block
setblock 289 61 221 minecraft:red_nether_bricks
setblock 289 61 222 minecraft:polished_blackstone
fill 290 61 182 293 61 182 minecraft:red_nether_bricks
setblock 290 61 221 minecraft:polished_blackstone
fill 290 61 222 293 61 222 minecraft:red_nether_bricks
fill 291 61 221 294 61 221 minecraft:red_nether_bricks
setblock 292 61 184 minecraft:polished_blackstone
fill 292 61 220 295 61 220 minecraft:red_nether_bricks
setblock 293 61 183 minecraft:polished_blackstone
fill 293 61 184 295 62 184 minecraft:red_nether_bricks
setblock 294 61 182 minecraft:polished_blackstone
fill 294 61 183 297 61 183 minecraft:red_nether_bricks
setblock 294 61 222 minecraft:polished_blackstone
fill 295 61 182 298 61 182 minecraft:red_nether_bricks
setblock 295 61 221 minecraft:polished_blackstone
fill 295 61 222 298 61 222 minecraft:red_nether_bricks
setblock 296 61 220 minecraft:polished_blackstone
fill 296 61 221 299 61 221 minecraft:red_nether_bricks
fill 297 61 220 299 61 220 minecraft:red_nether_bricks
setblock 298 61 183 minecraft:polished_blackstone
setblock 299 61 182 minecraft:polished_blackstone
setblock 299 61 183 minecraft:red_nether_bricks
setblock 299 61 222 minecraft:polished_blackstone
fill 300 61 182 302 61 182 minecraft:red_nether_bricks
setblock 300 61 221 minecraft:polished_blackstone
fill 300 61 222 303 61 222 minecraft:red_nether_bricks
fill 301 61 221 302 61 221 minecraft:red_nether_bricks
setblock 304 61 222 minecraft:polished_blackstone
fill 305 61 222 308 61 222 minecraft:red_nether_bricks
setblock 309 61 222 minecraft:polished_blackstone
fill 310 61 182 313 61 182 minecraft:red_nether_bricks
fill 310 61 222 313 61 222 minecraft:red_nether_bricks
fill 313 61 221 314 61 221 minecraft:red_nether_bricks
setblock 314 61 182 minecraft:polished_blackstone
fill 314 61 183 317 61 183 minecraft:red_nether_bricks
setblock 314 61 222 minecraft:polished_blackstone
fill 315 61 182 318 61 182 minecraft:red_nether_bricks
setblock 315 61 221 minecraft:polished_blackstone
fill 315 61 222 318 61 222 minecraft:red_nether_bricks
setblock 316 61 221 minecraft:red_nether_bricks
setblock 318 61 183 minecraft:polished_blackstone
fill 318 61 189 318 62 189 minecraft:magma_block
setblock 319 61 182 minecraft:polished_blackstone
fill 319 61 183 319 64 183 minecraft:red_nether_bricks
setblock 319 61 188 minecraft:magma_block
setblock 319 61 190 minecraft:magma_block
setblock 319 61 222 minecraft:polished_blackstone
fill 320 61 182 320 64 182 minecraft:red_nether_bricks
fill 320 61 222 321 61 222 minecraft:red_nether_bricks
setblock 321 61 201 minecraft:red_nether_bricks
setblock 322 61 198 minecraft:red_nether_bricks
setblock 322 61 199 minecraft:polished_blackstone
setblock 322 61 200 minecraft:red_nether_bricks
fill 322 61 202 322 61 203 minecraft:red_nether_bricks
setblock 322 61 204 minecraft:polished_blackstone
setblock 323 61 183 minecraft:polished_blackstone
fill 323 61 184 323 64 184 minecraft:red_nether_bricks
fill 323 61 195 323 61 197 minecraft:red_nether_bricks
setblock 323 61 198 minecraft:polished_blackstone
fill 323 61 199 323 63 199 minecraft:red_nether_bricks
setblock 323 61 202 minecraft:red_nether_bricks
setblock 323 61 203 minecraft:polished_blackstone
fill 323 61 204 323 62 205 minecraft:red_nether_bricks
setblock 283 62 182 minecraft:polished_blackstone
fill 283 62 183 286 62 183 minecraft:red_nether_bricks
fill 283 62 185 283 62 186 minecraft:red_nether_bricks
setblock 283 62 187 minecraft:polished_blackstone
setblock 283 62 222 minecraft:polished_blackstone
fill 284 62 182 287 62 182 minecraft:red_nether_bricks
fill 284 62 222 287 62 222 minecraft:red_nether_bricks
setblock 287 62 183 minecraft:polished_blackstone
setblock 288 62 182 minecraft:polished_blackstone
fill 288 62 183 291 62 183 minecraft:red_nether_bricks
setblock 288 62 222 minecraft:polished_blackstone
fill 289 62 182 292 62 182 minecraft:red_nether_bricks
setblock 289 62 221 minecraft:polished_blackstone
fill 289 62 222 292 62 222 minecraft:red_nether_bricks
fill 290 62 221 293 62 221 minecraft:red_nether_bricks
setblock 292 62 183 minecraft:polished_blackstone
fill 292 62 184 292 65 184 minecraft:red_nether_bricks
fill 292 62 220 294 62 220 minecraft:red_nether_bricks
setblock 293 62 182 minecraft:polished_blackstone
fill 293 62 183 296 62 183 minecraft:red_nether_bricks
setblock 293 62 222 minecraft:polished_blackstone
fill 294 62 182 297 62 182 minecraft:red_nether_bricks
setblock 294 62 221 minecraft:polished_blackstone
fill 294 62 222 297 62 222 minecraft:red_nether_bricks
setblock 295 62 220 minecraft:polished_blackstone
fill 295 62 221 298 62 221 minecraft:red_nether_bricks
fill 296 62 220 298 62 220 minecraft:red_nether_bricks
setblock 297 62 183 minecraft:polished_blackstone
setblock 298 62 182 minecraft:polished_blackstone
fill 298 62 183 298 63 183 minecraft:red_nether_bricks
setblock 298 62 222 minecraft:polished_blackstone
fill 299 62 182 301 63 182 minecraft:red_nether_bricks
fill 299 62 217 299 62 219 minecraft:polished_blackstone
setblock 299 62 221 minecraft:polished_blackstone
fill 299 62 222 302 62 222 minecraft:red_nether_bricks
fill 300 62 217 301 62 217 minecraft:polished_blackstone
fill 300 62 219 301 62 219 minecraft:polished_blackstone
fill 300 62 221 301 62 221 minecraft:red_nether_bricks
setblock 301 62 218 minecraft:polished_blackstone
setblock 303 62 222 minecraft:polished_blackstone
setblock 304 62 222 minecraft:red_nether_bricks
setblock 308 62 222 minecraft:polished_blackstone
fill 309 62 222 312 62 222 minecraft:red_nether_bricks
fill 310 62 182 312 62 182 minecraft:red_nether_bricks
setblock 311 62 183 minecraft:polished_blackstone
setblock 311 62 185 minecraft:polished_blackstone
setblock 313 62 182 minecraft:polished_blackstone
fill 313 62 183 316 62 183 minecraft:red_nether_bricks
setblock 313 62 185 minecraft:polished_blackstone
setblock 313 62 222 minecraft:polished_blackstone
fill 314 62 182 317 62 182 minecraft:red_nether_bricks
fill 314 62 222 317 62 222 minecraft:red_nether_bricks
setblock 317 62 183 minecraft:polished_blackstone
setblock 318 62 182 minecraft:polished_blackstone
fill 318 62 183 318 65 183 minecraft:red_nether_bricks
setblock 318 62 222 minecraft:polished_blackstone
fill 319 62 182 319 65 182 minecraft:red_nether_bricks
fill 319 62 189 321 62 189 minecraft:magma_block
setblock 319 62 222 minecraft:red_nether_bricks
fill 321 62 182 322 62 182 minecraft:red_nether_bricks
setblock 322 62 202 minecraft:red_nether_bricks
setblock 323 62 182 minecraft:polished_blackstone
fill 323 62 183 323 65 183 minecraft:red_nether_bricks
setblock 323 62 197 minecraft:polished_blackstone
setblock 323 62 198 minecraft:red_nether_bricks
setblock 323 62 202 minecraft:polished_blackstone
fill 323 62 203 323 65 203 minecraft:red_nether_bricks
fill 283 63 182 285 63 183 minecraft:red_nether_bricks
setblock 283 63 185 minecraft:red_nether_bricks
setblock 283 63 186 minecraft:polished_blackstone
fill 283 63 187 283 66 187 minecraft:red_nether_bricks
fill 284 63 222 286 63 222 minecraft:red_nether_bricks
setblock 286 63 182 minecraft:red_nether_bricks
setblock 286 63 183 minecraft:polished_blackstone
setblock 287 63 182 minecraft:polished_blackstone
fill 287 63 183 290 63 183 minecraft:red_nether_bricks
setblock 287 63 222 minecraft:polished_blackstone
fill 288 63 182 291 63 182 minecraft:red_nether_bricks
fill 288 63 222 291 63 222 minecraft:red_nether_bricks
fill 289 63 221 292 63 221 minecraft:red_nether_bricks
setblock 291 63 183 minecraft:polished_blackstone
fill 291 63 184 291 66 184 minecraft:red_nether_bricks
setblock 292 63 182 minecraft:polished_blackstone
fill 292 63 183 295 63 183 minecraft:red_nether_bricks
fill 292 63 220 293 63 220 minecraft:red_nether_bricks
setblock 292 63 222 minecraft:polished_blackstone
fill 293 63 182 296 63 182 minecraft:red_nether_bricks
fill 293 63 184 294 63 184 minecraft:red_nether_bricks
setblock 293 63 221 minecraft:polished_blackstone
fill 293 63 222 296 63 222 minecraft:red_nether_bricks
setblock 294 63 220 minecraft:polished_blackstone
fill 294 63 221 297 63 221 minecraft:red_nether_bricks
fill 295 63 220 296 63 220 minecraft:red_nether_bricks
setblock 296 63 183 minecraft:polished_blackstone
setblock 297 63 182 minecraft:polished_blackstone
fill 297 63 183 297 66 183 minecraft:red_nether_bricks
setblock 297 63 222 minecraft:polished_blackstone
fill 298 63 182 298 66 182 minecraft:red_nether_bricks
setblock 298 63 221 minecraft:polished_blackstone
fill 298 63 222 301 63 222 minecraft:red_nether_bricks
setblock 299 63 221 minecraft:red_nether_bricks
setblock 302 63 222 minecraft:polished_blackstone
setblock 303 63 222 minecraft:red_nether_bricks
fill 309 63 222 311 63 222 minecraft:red_nether_bricks
fill 310 63 182 311 63 182 minecraft:red_nether_bricks
setblock 312 63 182 minecraft:polished_blackstone
setblock 312 63 222 minecraft:polished_blackstone
fill 313 63 182 315 63 183 minecraft:red_nether_bricks
fill 313 63 222 316 63 222 minecraft:red_nether_bricks
setblock 316 63 182 minecraft:red_nether_bricks
setblock 316 63 183 minecraft:polished_blackstone
setblock 317 63 182 minecraft:polished_blackstone
fill 317 63 183 317 66 183 minecraft:red_nether_bricks
setblock 317 63 222 minecraft:polished_blackstone
fill 318 63 182 318 66 182 minecraft:red_nether_bricks
setblock 318 63 222 minecraft:red_nether_bricks
setblock 321 63 182 minecraft:red_nether_bricks
setblock 322 63 182 minecraft:polished_blackstone
fill 323 63 182 323 66 182 minecraft:red_nether_bricks
setblock 323 63 185 minecraft:red_nether_bricks
setblock 323 63 186 minecraft:polished_blackstone
fill 323 63 187 323 66 187 minecraft:red_nether_bricks
setblock 323 63 201 minecraft:polished_blackstone
fill 323 63 202 323 64 202 minecraft:red_nether_bricks
fill 323 63 204 323 64 204 minecraft:red_nether_bricks
fill 283 64 182 284 64 183 minecraft:red_nether_bricks
setblock 283 64 185 minecraft:polished_blackstone
fill 283 64 186 283 67 186 minecraft:red_nether_bricks
setblock 284 64 184 minecraft:polished_blackstone
setblock 285 64 182 minecraft:red_nether_bricks
setblock 285 64 183 minecraft:polished_blackstone
setblock 285 64 222 minecraft:red_nether_bricks
setblock 286 64 182 minecraft:polished_blackstone
fill 286 64 183 289 64 183 minecraft:red_nether_bricks
setblock 286 64 222 minecraft:polished_blackstone
fill 287 64 182 290 64 182 minecraft:red_nether_bricks
fill 287 64 222 290 64 222 minecraft:red_nether_bricks
fill 289 64 221 291 64 221 minecraft:red_nether_bricks
setblock 290 64 183 minecraft:polished_blackstone
fill 290 64 184 290 67 184 minecraft:red_nether_bricks
setblock 291 64 182 minecraft:polished_blackstone
fill 291 64 183 294 64 183 minecraft:red_nether_bricks
setblock 291 64 222 minecraft:polished_blackstone
fill 292 64 182 295 64 182 minecraft:red_nether_bricks
setblock 292 64 221 minecraft:polished_blackstone
fill 292 64 222 295 64 222 minecraft:red_nether_bricks
setblock 293 64 184 minecraft:red_nether_bricks
setblock 293 64 220 minecraft:polished_blackstone
fill 293 64 221 296 64 221 minecraft:red_nether_bricks
setblock 294 64 184 minecraft:polished_blackstone
fill 294 64 220 295 64 220 minecraft:red_nether_bricks
setblock 295 64 183 minecraft:polished_blackstone
setblock 296 64 182 minecraft:polished_blackstone
fill 296 64 183 296 67 183 minecraft:red_nether_bricks
setblock 296 64 222 minecraft:polished_blackstone
fill 297 64 182 297 67 182 minecraft:red_nether_bricks
setblock 297 64 221 minecraft:polished_blackstone
fill 297 64 222 300 64 222 minecraft:red_nether_bricks
fill 298 64 221 298 65 221 minecraft:red_nether_bricks
fill 299 64 182 300 64 182 minecraft:red_nether_bricks
setblock 301 64 222 minecraft:polished_blackstone
fill 309 64 182 310 64 182 minecraft:red_nether_bricks
fill 309 64 222 310 64 222 minecraft:red_nether_bricks
setblock 311 64 182 minecraft:polished_blackstone
setblock 311 64 222 minecraft:polished_blackstone
fill 312 64 182 314 64 183 minecraft:red_nether_bricks
fill 312 64 222 315 64 222 minecraft:red_nether_bricks
setblock 315 64 182 minecraft:red_nether_bricks
setblock 315 64 183 minecraft:polished_blackstone
setblock 316 64 182 minecraft:polished_blackstone
fill 316 64 183 316 67 183 minecraft:red_nether_bricks
setblock 316 64 222 minecraft:polished_blackstone
fill 317 64 182 317 67 182 minecraft:red_nether_bricks
setblock 317 64 222 minecraft:red_nether_bricks
setblock 321 64 182 minecraft:polished_blackstone
fill 322 64 182 322 67 182 minecraft:red_nether_bricks
setblock 323 64 185 minecraft:polished_blackstone
fill 323 64 186 323 67 186 minecraft:red_nether_bricks
fill 323 64 188 323 65 188 minecraft:red_nether_bricks
setblock 323 64 201 minecraft:red_nether_bricks
fill 283 65 182 283 65 183 minecraft:red_nether_bricks
setblock 283 65 184 minecraft:polished_blackstone
fill 283 65 185 284 67 185 minecraft:red_nether_bricks
setblock 283 65 188 minecraft:red_nether_bricks
setblock 284 65 182 minecraft:red_nether_bricks
setblock 284 65 183 minecraft:polished_blackstone
fill 284 65 184 284 68 184 minecraft:red_nether_bricks
setblock 285 65 182 minecraft:polished_blackstone
fill 285 65 183 288 65 183 minecraft:red_nether_bricks
setblock 285 65 222 minecraft:polished_blackstone
fill 286 65 182 289 65 182 minecraft:red_nether_bricks
fill 286 65 222 289 65 222 minecraft:red_nether_bricks
setblock 288 65 184 minecraft:polished_blackstone
fill 288 65 221 290 65 221 minecraft:red_nether_bricks
setblock 289 65 183 minecraft:polished_blackstone
fill 289 65 184 289 68 184 minecraft:red_nether_bricks
setblock 290 65 182 minecraft:polished_blackstone
fill 290 65 183 293 65 183 minecraft:red_nether_bricks
setblock 290 65 222 minecraft:polished_blackstone
fill 291 65 182 294 65 182 minecraft:red_nether_bricks
setblock 291 65 221 minecraft:polished_blackstone
fill 291 65 222 294 65 222 minecraft:red_nether_bricks
fill 292 65 221 295 65 221 minecraft:red_nether_bricks
setblock 293 65 184 minecraft:polished_blackstone
setblock 293 65 220 minecraft:red_nether_bricks
setblock 294 65 183 minecraft:polished_blackstone
fill 294 65 184 294 68 184 minecraft:red_nether_bricks
setblock 295 65 182 minecraft:polished_blackstone
fill 295 65 183 295 68 183 minecraft:red_nether_bricks
setblock 295 65 222 minecraft:polished_blackstone
fill 296 65 182 296 68 182 minecraft:red_nether_bricks
setblock 296 65 221 minecraft:polished_blackstone
fill 296 65 222 299 65 222 minecraft:red_nether_bricks
fill 297 65 221 297 66 221 minecraft:red_nether_bricks
setblock 299 65 182 minecraft:red_nether_bricks
setblock 300 65 222 minecraft:polished_blackstone
fill 308 65 182 309 65 182 minecraft:red_nether_bricks
setblock 309 65 222 minecraft:red_nether_bricks
setblock 310 65 182 minecraft:polished_blackstone
setblock 310 65 222 minecraft:polished_blackstone
fill 311 65 182 313 65 183 minecraft:red_nether_bricks
fill 311 65 222 314 65 222 minecraft:red_nether_bricks
setblock 314 65 182 minecraft:red_nether_bricks
setblock 314 65 183 minecraft:polished_blackstone
setblock 315 65 182 minecraft:polished_blackstone
fill 315 65 183 315 68 183 minecraft:red_nether_bricks
setblock 315 65 222 minecraft:polished_blackstone
fill 316 65 182 316 68 182 minecraft:red_nether_bricks
setblock 316 65 222 minecraft:red_nether_bricks
setblock 319 65 183 minecraft:polished_blackstone
setblock 320 65 182 minecraft:polished_blackstone
fill 321 65 182 321 68 182 minecraft:red_nether_bricks
setblock 323 65 184 minecraft:polished_blackstone
fill 323 65 185 323 68 185 minecraft:red_nether_bricks
setblock 323 65 189 minecraft:polished_blackstone
setblock 323 65 204 minecraft:polished_blackstone
setblock 283 66 182 minecraft:red_nether_bricks
setblock 283 66 183 minecraft:polished_blackstone
fill 283 66 184 283 69 184 minecraft:red_nether_bricks
setblock 283 66 188 minecraft:polished_blackstone
fill 283 66 189 283 69 189 minecraft:red_nether_bricks
setblock 284 66 182 minecraft:polished_blackstone
fill 284 66 183 287 66 183 minecraft:red_nether_bricks
setblock 284 66 186 minecraft:red_nether_bricks
setblock 284 66 222 minecraft:polished_blackstone
fill 285 66 182 288 66 182 minecraft:red_nether_bricks
fill 285 66 222 288 66 222 minecraft:red_nether_bricks
setblock 287 66 184 minecraft:polished_blackstone
setblock 288 66 183 minecraft:polished_blackstone
fill 288 66 184 288 69 184 minecraft:red_nether_bricks
fill 288 66 221 289 66 221 minecraft:red_nether_bricks
setblock 289 66 182 minecraft:polished_blackstone
fill 289 66 183 292 66 183 minecraft:red_nether_bricks
setblock 289 66 222 minecraft:polished_blackstone
fill 290 66 182 293 66 182 minecraft:red_nether_bricks
setblock 290 66 221 minecraft:polished_blackstone
fill 290 66 222 293 66 222 minecraft:red_nether_bricks
fill 291 66 221 294 66 221 minecraft:red_nether_bricks
setblock 292 66 184 minecraft:polished_blackstone
setblock 293 66 183 minecraft:polished_blackstone
fill 293 66 184 293 69 184 minecraft:red_nether_bricks
setblock 294 66 182 minecraft:polished_blackstone
fill 294 66 183 294 69 183 minecraft:red_nether_bricks
setblock 294 66 222 minecraft:polished_blackstone
fill 295 66 182 295 69 182 minecraft:red_nether_bricks
setblock 295 66 221 minecraft:polished_blackstone
fill 295 66 222 298 66 222 minecraft:red_nether_bricks
fill 296 66 221 296 68 221 minecraft:red_nether_bricks
setblock 299 66 182 minecraft:polished_blackstone
setblock 299 66 222 minecraft:polished_blackstone
setblock 300 66 222 minecraft:red_nether_bricks
setblock 308 66 182 minecraft:red_nether_bricks
setblock 309 66 182 minecraft:polished_blackstone
setblock 309 66 222 minecraft:polished_blackstone
fill 310 66 182 312 66 183 minecraft:red_nether_bricks
fill 310 66 222 313 66 222 minecraft:red_nether_bricks
fill 311 66 184 312 66 184 minecraft:gilded_blackstone
setblock 313 66 182 minecraft:red_nether_bricks
setblock 313 66 183 minecraft:polished_blackstone
fill 313 66 184 315 67 184 minecraft:red_nether_bricks
setblock 314 66 182 minecraft:polished_blackstone
fill 314 66 183 314 69 183 minecraft:red_nether_bricks
setblock 314 66 222 minecraft:polished_blackstone
fill 315 66 182 315 69 182 minecraft:red_nether_bricks
fill 315 66 222 315 67 222 minecraft:red_nether_bricks
setblock 318 66 183 minecraft:polished_blackstone
setblock 319 66 182 minecraft:polished_blackstone
fill 319 66 183 320 68 183 minecraft:red_nether_bricks
fill 320 66 182 320 69 182 minecraft:red_nether_bricks
setblock 322 66 184 minecraft:polished_blackstone
fill 322 66 185 322 67 187 minecraft:red_nether_bricks
setblock 323 66 183 minecraft:polished_blackstone
fill 323 66 184 323 69 184 minecraft:red_nether_bricks
setblock 323 66 188 minecraft:polished_blackstone
fill 323 66 189 323 68 190 minecraft:red_nether_bricks
fill 323 66 204 323 69 204 minecraft:red_nether_bricks
setblock 283 67 182 minecraft:polished_blackstone
fill 283 67 183 286 67 183 minecraft:red_nether_bricks
setblock 283 67 187 minecraft:polished_blackstone
fill 283 67 188 284 69 188 minecraft:red_nether_bricks
fill 283 67 190 283 68 190 minecraft:red_nether_bricks
setblock 283 67 222 minecraft:polished_blackstone
fill 284 67 182 287 67 182 minecraft:red_nether_bricks
setblock 284 67 186 minecraft:polished_blackstone
fill 284 67 187 284 70 187 minecraft:red_nether_bricks
fill 284 67 222 287 67 222 minecraft:red_nether_bricks
setblock 286 67 184 minecraft:polished_blackstone
setblock 287 67 183 minecraft:polished_blackstone
fill 287 67 184 287 70 184 minecraft:red_nether_bricks
fill 287 67 221 288 67 221 minecraft:red_nether_bricks
setblock 288 67 182 minecraft:polished_blackstone
fill 288 67 183 291 67 183 minecraft:red_nether_bricks
setblock 288 67 222 minecraft:polished_blackstone
fill 289 67 182 292 67 182 minecraft:red_nether_bricks
setblock 289 67 221 minecraft:polished_blackstone
fill 289 67 222 292 67 222 minecraft:red_nether_bricks
fill 290 67 221 293 67 221 minecraft:red_nether_bricks
setblock 291 67 184 minecraft:polished_blackstone
setblock 292 67 183 minecraft:polished_blackstone
fill 292 67 184 292 70 184 minecraft:red_nether_bricks
fill 292 67 220 292 69 220 minecraft:red_nether_bricks
setblock 293 67 182 minecraft:polished_blackstone
fill 293 67 183 293 70 183 minecraft:red_nether_bricks
setblock 293 67 222 minecraft:polished_blackstone
fill 294 67 182 294 70 182 minecraft:red_nether_bricks
setblock 294 67 221 minecraft:polished_blackstone
fill 294 67 222 297 67 222 minecraft:red_nether_bricks
fill 295 67 221 295 70 221 minecraft:red_nether_bricks
setblock 297 67 183 minecraft:polished_blackstone
setblock 298 67 182 minecraft:polished_blackstone
setblock 298 67 222 minecraft:polished_blackstone
setblock 299 67 182 minecraft:red_nether_bricks
fill 299 67 222 299 68 222 minecraft:red_nether_bricks
setblock 307 67 182 minecraft:red_nether_bricks
setblock 308 67 182 minecraft:polished_blackstone
fill 309 67 182 311 67 183 minecraft:red_nether_bricks
fill 309 67 222 312 67 222 minecraft:red_nether_bricks
setblock 311 67 184 minecraft:polished_blackstone
setblock 312 67 182 minecraft:red_nether_bricks
setblock 312 67 183 minecraft:polished_blackstone
fill 312 67 184 312 70 184 minecraft:red_nether_bricks
setblock 313 67 182 minecraft:polished_blackstone
fill 313 67 183 313 70 183 minecraft:red_nether_bricks
setblock 313 67 222 minecraft:polished_blackstone
fill 314 67 182 314 70 182 minecraft:red_nether_bricks
fill 314 67 222 314 68 222 minecraft:red_nether_bricks
setblock 316 67 184 minecraft:polished_blackstone
setblock 317 67 183 minecraft:polished_blackstone
setblock 318 67 182 minecraft:polished_blackstone
fill 318 67 183 318 70 183 minecraft:red_nether_bricks
fill 319 67 182 319 70 182 minecraft:red_nether_bricks
setblock 321 67 183 minecraft:red_nether_bricks
setblock 322 67 183 minecraft:polished_blackstone
fill 322 67 184 322 70 184 minecraft:red_nether_bricks
setblock 322 67 188 minecraft:polished_blackstone
setblock 323 67 182 minecraft:polished_blackstone
fill 323 67 183 323 70 183 minecraft:red_nether_bricks
setblock 323 67 187 minecraft:polished_blackstone
fill 323 67 188 323 70 188 minecraft:red_nether_bricks
setblock 323 67 191 minecraft:red_nether_bricks
setblock 323 67 192 minecraft:polished_blackstone
fill 323 67 205 323 67 206 minecraft:red_nether_bricks
fill 282 68 181 283 68 181 minecraft:red_nether_bricks
fill 282 68 182 282 71 184 minecraft:blackstone
fill 282 68 185 283 68 185 minecraft:red_nether_bricks
fill 282 68 186 282 71 200 minecraft:blackstone
setblock 282 68 201 minecraft:red_nether_bricks
fill 282 68 202 282 68 215 minecraft:blackstone
setblock 282 68 216 minecraft:red_nether_bricks
fill 282 68 217 282 68 223 minecraft:blackstone
fill 283 68 182 285 68 183 minecraft:red_nether_bricks
setblock 283 68 186 minecraft:polished_blackstone
fill 283 68 187 283 71 187 minecraft:red_nether_bricks
setblock 283 68 191 minecraft:polished_blackstone
fill 283 68 222 286 68 222 minecraft:red_nether_bricks
fill 283 68 223 286 71 223 minecraft:blackstone
fill 284 68 181 284 71 181 minecraft:blackstone
setblock 284 68 185 minecraft:polished_blackstone
fill 284 68 186 285 70 186 minecraft:red_nether_bricks
setblock 284 68 189 minecraft:red_nether_bricks
setblock 285 68 181 minecraft:red_nether_bricks
setblock 285 68 184 minecraft:polished_blackstone
fill 285 68 185 285 71 185 minecraft:red_nether_bricks
setblock 285 68 192 minecraft:light[level=14]
setblock 285 68 200 minecraft:light[level=14]
setblock 285 68 208 minecraft:light[level=14]
setblock 285 68 216 minecraft:light[level=14]
fill 286 68 181 290 68 181 minecraft:blackstone
setblock 286 68 182 minecraft:red_nether_bricks
setblock 286 68 183 minecraft:polished_blackstone
fill 286 68 184 286 71 184 minecraft:red_nether_bricks
setblock 287 68 182 minecraft:polished_blackstone
fill 287 68 183 290 68 183 minecraft:red_nether_bricks
setblock 287 68 221 minecraft:red_nether_bricks
setblock 287 68 222 minecraft:polished_blackstone
fill 287 68 223 288 68 223 minecraft:red_nether_bricks
fill 288 68 182 291 68 182 minecraft:red_nether_bricks
setblock 288 68 221 minecraft:polished_blackstone
fill 288 68 222 291 68 222 minecraft:red_nether_bricks
fill 289 68 221 292 68 221 minecraft:red_nether_bricks
fill 289 68 223 289 71 223 minecraft:blackstone
setblock 290 68 184 minecraft:polished_blackstone
fill 290 68 185 290 70 185 minecraft:red_nether_bricks
fill 290 68 220 291 70 220 minecraft:red_nether_bricks
fill 290 68 223 291 68 223 minecraft:red_nether_bricks
setblock 291 68 181 minecraft:red_nether_bricks
setblock 291 68 183 minecraft:polished_blackstone
fill 291 68 184 291 71 184 minecraft:red_nether_bricks
fill 292 68 181 292 69 181 minecraft:blackstone
setblock 292 68 182 minecraft:polished_blackstone
fill 292 68 183 292 71 183 minecraft:red_nether_bricks
setblock 292 68 222 minecraft:polished_blackstone
fill 292 68 223 293 71 223 minecraft:blackstone
fill 293 68 181 293 69 182 minecraft:red_nether_bricks
setblock 293 68 192 minecraft:light[level=14]
setblock 293 68 200 minecraft:light[level=14]
setblock 293 68 208 minecraft:light[level=14]
setblock 293 68 216 minecraft:light[level=14]
setblock 293 68 221 minecraft:polished_blackstone
fill 293 68 222 296 68 222 minecraft:red_nether_bricks
fill 294 68 181 300 71 181 minecraft:blackstone
fill 294 68 221 294 71 221 minecraft:red_nether_bricks
setblock 294 68 223 minecraft:red_nether_bricks
fill 295 68 223 309 68 223 minecraft:blackstone
setblock 296 68 183 minecraft:polished_blackstone
setblock 297 68 182 minecraft:polished_blackstone
setblock 297 68 222 minecraft:polished_blackstone
fill 298 68 182 298 69 182 minecraft:red_nether_bricks
fill 298 68 222 298 69 222 minecraft:red_nether_bricks
setblock 301 68 181 minecraft:red_nether_bricks
setblock 301 68 184 minecraft:light[level=14]
setblock 301 68 192 minecraft:light[level=14]
setblock 301 68 200 minecraft:light[level=14]
setblock 301 68 208 minecraft:light[level=14]
setblock 301 68 216 minecraft:light[level=14]
fill 302 68 181 311 68 181 minecraft:blackstone
setblock 306 68 182 minecraft:red_nether_bricks
setblock 307 68 182 minecraft:polished_blackstone
fill 308 68 182 310 68 183 minecraft:red_nether_bricks
fill 308 68 222 311 68 222 minecraft:red_nether_bricks
setblock 309 68 184 minecraft:light[level=14]
setblock 309 68 192 minecraft:light[level=14]
setblock 309 68 200 minecraft:light[level=14]
setblock 309 68 208 minecraft:light[level=14]
setblock 309 68 216 minecraft:light[level=14]
setblock 310 68 184 minecraft:polished_blackstone
setblock 310 68 223 minecraft:red_nether_bricks
setblock 311 68 182 minecraft:red_nether_bricks
setblock 311 68 183 minecraft:polished_blackstone
fill 311 68 184 311 71 184 minecraft:red_nether_bricks
fill 311 68 223 314 69 223 minecraft:blackstone
setblock 312 68 181 minecraft:red_nether_bricks
setblock 312 68 182 minecraft:polished_blackstone
fill 312 68 183 312 71 183 minecraft:red_nether_bricks
setblock 312 68 222 minecraft:polished_blackstone
fill 313 68 181 323 68 181 minecraft:blackstone
fill 313 68 182 313 71 182 minecraft:red_nether_bricks
fill 313 68 184 314 68 184 minecraft:red_nether_bricks
fill 313 68 222 313 70 222 minecraft:red_nether_bricks
setblock 315 68 184 minecraft:polished_blackstone
fill 315 68 223 315 69 223 minecraft:red_nether_bricks
setblock 316 68 183 minecraft:polished_blackstone
fill 316 68 184 316 69 184 minecraft:red_nether_bricks
fill 316 68 223 319 68 223 minecraft:blackstone
setblock 317 68 182 minecraft:polished_blackstone
fill 317 68 183 317 71 183 minecraft:red_nether_bricks
setblock 317 68 184 minecraft:light[level=14]
setblock 317 68 192 minecraft:light[level=14]
setblock 317 68 200 minecraft:light[level=14]
setblock 317 68 208 minecraft:light[level=14]
setblock 317 68 216 minecraft:light[level=14]
fill 318 68 182 318 71 182 minecraft:red_nether_bricks
setblock 320 68 223 minecraft:red_nether_bricks
setblock 321 68 183 minecraft:polished_blackstone
fill 321 68 223 324 69 223 minecraft:blackstone
setblock 322 68 182 minecraft:polished_blackstone
fill 322 68 183 322 71 183 minecraft:red_nether_bricks
fill 322 68 185 322 68 186 minecraft:red_nether_bricks
setblock 322 68 187 minecraft:polished_blackstone
fill 322 68 188 322 69 190 minecraft:red_nether_bricks
fill 323 68 182 323 71 182 minecraft:red_nether_bricks
setblock 323 68 186 minecraft:polished_blackstone
fill 323 68 187 323 71 187 minecraft:red_nether_bricks
setblock 323 68 191 minecraft:polished_blackstone
fill 323 68 192 323 70 193 minecraft:red_nether_bricks
setblock 323 68 205 minecraft:red_nether_bricks
setblock 323 68 206 minecraft:polished_blackstone
fill 323 68 207 323 70 208 minecraft:red_nether_bricks
setblock 324 68 181 minecraft:red_nether_bricks
fill 324 68 182 324 68 195 minecraft:blackstone
setblock 324 68 196 minecraft:red_nether_bricks
fill 324 68 197 324 71 199 minecraft:blackstone
fill 324 68 200 324 68 201 minecraft:red_nether_bricks
fill 324 68 202 324 71 202 minecraft:blackstone
setblock 324 68 203 minecraft:red_nether_bricks
fill 324 68 204 324 68 218 minecraft:blackstone
fill 324 68 219 324 69 219 minecraft:red_nether_bricks
fill 324 68 220 324 68 221 minecraft:blackstone
setblock 324 68 222 minecraft:red_nether_bricks
fill 282 69 181 283 71 181 minecraft:blackstone
fill 282 69 185 282 71 185 minecraft:blackstone
fill 282 69 201 282 69 206 minecraft:blackstone
fill 282 69 207 283 69 207 minecraft:red_nether_bricks
fill 282 69 208 282 69 218 minecraft:blackstone
setblock 282 69 219 minecraft:red_nether_bricks
fill 282 69 220 282 71 223 minecraft:blackstone
fill 283 69 182 284 69 183 minecraft:red_nether_bricks
setblock 283 69 185 minecraft:polished_blackstone
fill 283 69 186 283 72 186 minecraft:red_nether_bricks
setblock 283 69 190 minecraft:polished_blackstone
fill 283 69 191 283 71 192 minecraft:red_nether_bricks
fill 283 69 206 283 72 206 minecraft:red_nether_bricks
fill 283 69 208 283 69 209 minecraft:red_nether_bricks
setblock 283 69 210 minecraft:polished_blackstone
fill 283 69 211 283 71 212 minecraft:red_nether_bricks
fill 283 69 221 283 71 222 minecraft:red_nether_bricks
setblock 284 69 184 minecraft:polished_blackstone
fill 284 69 185 284 72 185 minecraft:red_nether_bricks
setblock 284 69 189 minecraft:polished_blackstone
fill 284 69 190 284 72 190 minecraft:red_nether_bricks
fill 284 69 222 285 69 222 minecraft:red_nether_bricks
fill 285 69 181 288 71 181 minecraft:blackstone
setblock 285 69 182 minecraft:red_nether_bricks
setblock 285 69 183 minecraft:polished_blackstone
fill 285 69 184 285 72 184 minecraft:red_nether_bricks
setblock 285 69 187 minecraft:red_nether_bricks
setblock 286 69 182 minecraft:polished_blackstone
fill 286 69 183 289 69 183 minecraft:red_nether_bricks
setblock 286 69 221 minecraft:red_nether_bricks
setblock 286 69 222 minecraft:polished_blackstone
fill 287 69 182 290 69 182 minecraft:red_nether_bricks
setblock 287 69 221 minecraft:polished_blackstone
fill 287 69 222 290 69 222 minecraft:red_nether_bricks
fill 287 69 223 288 71 223 minecraft:blackstone
setblock 288 69 185 minecraft:polished_blackstone
fill 288 69 221 291 69 221 minecraft:red_nether_bricks
fill 289 69 181 289 70 181 minecraft:red_nether_bricks
setblock 289 69 184 minecraft:polished_blackstone
fill 289 69 185 289 70 185 minecraft:red_nether_bricks
fill 289 69 220 289 72 220 minecraft:red_nether_bricks
fill 290 69 181 291 71 181 minecraft:blackstone
setblock 290 69 183 minecraft:polished_blackstone
fill 290 69 184 290 72 184 minecraft:red_nether_bricks
fill 290 69 223 291 69 223 minecraft:blackstone
setblock 291 69 182 minecraft:polished_blackstone
fill 291 69 183 291 72 183 minecraft:red_nether_bricks
setblock 291 69 222 minecraft:polished_blackstone
fill 292 69 182 292 72 182 minecraft:red_nether_bricks
setblock 292 69 221 minecraft:polished_blackstone
fill 292 69 222 295 69 222 minecraft:red_nether_bricks
fill 293 69 221 293 72 221 minecraft:red_nether_bricks
setblock 294 69 184 minecraft:polished_blackstone
fill 294 69 223 295 71 223 minecraft:blackstone
setblock 295 69 183 minecraft:polished_blackstone
setblock 296 69 182 minecraft:polished_blackstone
setblock 296 69 183 minecraft:red_nether_bricks
setblock 296 69 222 minecraft:polished_blackstone
fill 296 69 223 297 69 223 minecraft:red_nether_bricks
fill 297 69 182 297 70 182 minecraft:red_nether_bricks
fill 297 69 222 297 70 222 minecraft:red_nether_bricks
fill 298 69 223 305 71 223 minecraft:blackstone
fill 301 69 181 303 69 181 minecraft:blackstone
setblock 304 69 181 minecraft:red_nether_bricks
fill 305 69 181 313 71 181 minecraft:blackstone
setblock 306 69 182 minecraft:polished_blackstone
setblock 306 69 223 minecraft:red_nether_bricks
fill 307 69 182 309 69 183 minecraft:red_nether_bricks
fill 307 69 223 308 71 223 minecraft:blackstone
fill 308 69 222 310 69 222 minecraft:red_nether_bricks
setblock 309 69 184 minecraft:polished_blackstone
setblock 309 69 223 minecraft:red_nether_bricks
setblock 310 69 182 minecraft:red_nether_bricks
setblock 310 69 183 minecraft:polished_blackstone
fill 310 69 184 310 72 184 minecraft:red_nether_bricks
fill 310 69 223 310 71 223 minecraft:blackstone
setblock 311 69 182 minecraft:polished_blackstone
fill 311 69 183 311 72 183 minecraft:red_nether_bricks
setblock 311 69 185 minecraft:polished_blackstone
setblock 311 69 222 minecraft:polished_blackstone
fill 312 69 182 312 72 182 minecraft:red_nether_bricks
fill 312 69 222 312 70 222 minecraft:red_nether_bricks
setblock 313 69 184 minecraft:red_nether_bricks
setblock 313 69 185 minecraft:polished_blackstone
setblock 314 69 181 minecraft:red_nether_bricks
setblock 314 69 184 minecraft:polished_blackstone
fill 315 69 181 324 69 181 minecraft:blackstone
setblock 315 69 183 minecraft:polished_blackstone
fill 315 69 184 315 70 184 minecraft:red_nether_bricks
setblock 316 69 182 minecraft:polished_blackstone
fill 316 69 183 316 71 183 minecraft:red_nether_bricks
fill 316 69 223 316 71 223 minecraft:blackstone
fill 317 69 182 317 72 182 minecraft:red_nether_bricks
fill 317 69 223 318 69 223 minecraft:red_nether_bricks
setblock 319 69 183 minecraft:red_nether_bricks
fill 319 69 223 320 71 223 minecraft:blackstone
setblock 320 69 183 minecraft:polished_blackstone
setblock 321 69 182 minecraft:polished_blackstone
fill 321 69 183 321 71 183 minecraft:red_nether_bricks
setblock 321 69 187 minecraft:polished_blackstone
fill 322 69 182 322 72 182 minecraft:red_nether_bricks
setblock 322 69 185 minecraft:red_nether_bricks
setblock 322 69 186 minecraft:polished_blackstone
fill 322 69 187 322 72 187 minecraft:red_nether_bricks
setblock 322 69 191 minecraft:polished_blackstone
setblock 323 69 185 minecraft:polished_blackstone
fill 323 69 186 324 69 186 minecraft:red_nether_bricks
setblock 323 69 189 minecraft:red_nether_bricks
setblock 323 69 190 minecraft:polished_blackstone
fill 323 69 191 323 72 191 minecraft:red_nether_bricks
fill 323 69 194 324 69 194 minecraft:red_nether_bricks
setblock 323 69 205 minecraft:polished_blackstone
fill 323 69 206 323 71 206 minecraft:red_nether_bricks
setblock 323 69 209 minecraft:red_nether_bricks
fill 324 69 182 324 71 185 minecraft:blackstone
fill 324 69 187 324 70 187 minecraft:red_nether_bricks
fill 324 69 188 324 69 193 minecraft:blackstone
fill 324 69 195 324 71 196 minecraft:blackstone
setblock 324 69 200 minecraft:red_nether_bricks
fill 324 69 201 324 71 201 minecraft:blackstone
fill 324 69 203 324 72 203 minecraft:blackstone
setblock 324 69 204 minecraft:red_nether_bricks
fill 324 69 205 324 69 218 minecraft:blackstone
fill 324 69 220 324 69 221 minecraft:red_nether_bricks
fill 324 69 222 324 72 222 minecraft:blackstone
fill 282 70 201 282 71 205 minecraft:blackstone
setblock 282 70 206 minecraft:red_nether_bricks
fill 282 70 207 282 71 207 minecraft:blackstone
fill 282 70 208 283 70 208 minecraft:red_nether_bricks
fill 282 70 209 282 71 219 minecraft:blackstone
fill 283 70 182 283 70 183 minecraft:red_nether_bricks
setblock 283 70 184 minecraft:polished_blackstone
fill 283 70 185 283 73 185 minecraft:red_nether_bricks
setblock 283 70 188 minecraft:red_nether_bricks
setblock 283 70 189 minecraft:polished_blackstone
fill 283 70 190 283 73 190 minecraft:red_nether_bricks
fill 283 70 207 283 71 207 minecraft:red_nether_bricks
setblock 283 70 209 minecraft:polished_blackstone
fill 283 70 210 284 72 210 minecraft:red_nether_bricks
setblock 283 70 213 minecraft:red_nether_bricks
setblock 283 70 214 minecraft:polished_blackstone
fill 283 70 215 283 73 215 minecraft:red_nether_bricks
setblock 284 70 182 minecraft:red_nether_bricks
setblock 284 70 183 minecraft:polished_blackstone
fill 284 70 184 284 73 184 minecraft:red_nether_bricks
setblock 284 70 188 minecraft:polished_blackstone
fill 284 70 189 284 73 189 minecraft:red_nether_bricks
fill 284 70 191 284 71 191 minecraft:red_nether_bricks
setblock 284 70 208 minecraft:polished_blackstone
fill 284 70 209 284 73 209 minecraft:red_nether_bricks
fill 284 70 211 284 70 212 minecraft:red_nether_bricks
setblock 284 70 222 minecraft:red_nether_bricks
setblock 285 70 182 minecraft:polished_blackstone
fill 285 70 183 288 70 183 minecraft:red_nether_bricks
setblock 285 70 187 minecraft:polished_blackstone
fill 285 70 188 285 73 188 minecraft:red_nether_bricks
setblock 285 70 221 minecraft:red_nether_bricks
setblock 285 70 222 minecraft:polished_blackstone
fill 286 70 182 289 70 182 minecraft:red_nether_bricks
setblock 286 70 221 minecraft:polished_blackstone
fill 286 70 222 289 70 222 minecraft:red_nether_bricks
fill 287 70 221 290 70 221 minecraft:red_nether_bricks
setblock 288 70 184 minecraft:polished_blackstone
setblock 288 70 185 minecraft:red_nether_bricks
setblock 289 70 183 minecraft:polished_blackstone
fill 289 70 184 289 72 184 minecraft:red_nether_bricks
setblock 290 70 182 minecraft:polished_blackstone
fill 290 70 183 290 73 183 minecraft:red_nether_bricks
setblock 290 70 222 minecraft:polished_blackstone
fill 290 70 223 290 71 223 minecraft:blackstone
fill 291 70 182 291 73 182 minecraft:red_nether_bricks
setblock 291 70 221 minecraft:polished_blackstone
fill 291 70 222 291 70 223 minecraft:red_nether_bricks
setblock 292 70 181 minecraft:red_nether_bricks
setblock 292 70 220 minecraft:polished_blackstone
fill 292 70 221 292 72 222 minecraft:red_nether_bricks
fill 293 70 181 293 71 181 minecraft:blackstone
fill 293 70 182 293 71 182 minecraft:red_nether_bricks
setblock 293 70 184 minecraft:polished_blackstone
fill 293 70 222 294 70 222 minecraft:red_nether_bricks
setblock 294 70 183 minecraft:polished_blackstone
setblock 295 70 182 minecraft:polished_blackstone
setblock 295 70 183 minecraft:red_nether_bricks
setblock 295 70 222 minecraft:polished_blackstone
fill 296 70 182 296 71 182 minecraft:red_nether_bricks
fill 296 70 222 296 71 222 minecraft:red_nether_bricks
fill 296 70 223 297 71 223 minecraft:blackstone
fill 299 70 217 299 70 219 minecraft:polished_blackstone
fill 300 70 217 301 70 217 minecraft:polished_blackstone
fill 300 70 219 301 70 219 minecraft:polished_blackstone
fill 301 70 181 301 71 181 minecraft:blackstone
setblock 301 70 218 minecraft:polished_blackstone
setblock 302 70 181 minecraft:red_nether_bricks
fill 303 70 181 304 71 181 minecraft:blackstone
setblock 305 70 182 minecraft:polished_blackstone
fill 306 70 182 309 70 182 minecraft:red_nether_bricks
fill 306 70 223 306 71 223 minecraft:blackstone
fill 307 70 183 308 70 183 minecraft:red_nether_bricks
fill 308 70 222 309 70 222 minecraft:red_nether_bricks
setblock 309 70 183 minecraft:polished_blackstone
fill 309 70 184 309 71 184 minecraft:red_nether_bricks
fill 309 70 223 309 71 223 minecraft:blackstone
setblock 310 70 182 minecraft:polished_blackstone
fill 310 70 183 310 73 183 minecraft:red_nether_bricks
setblock 310 70 222 minecraft:polished_blackstone
fill 311 70 182 311 73 182 minecraft:red_nether_bricks
fill 311 70 222 311 71 222 minecraft:red_nether_bricks
fill 311 70 223 313 71 223 minecraft:blackstone
setblock 313 70 184 minecraft:polished_blackstone
fill 314 70 181 316 71 181 minecraft:blackstone
setblock 314 70 183 minecraft:polished_blackstone
fill 314 70 184 314 71 184 minecraft:red_nether_bricks
setblock 314 70 223 minecraft:red_nether_bricks
setblock 315 70 182 minecraft:polished_blackstone
fill 315 70 183 315 72 183 minecraft:red_nether_bricks
fill 315 70 223 315 71 223 minecraft:blackstone
fill 316 70 182 316 72 182 minecraft:red_nether_bricks
fill 317 70 181 318 70 181 minecraft:red_nether_bricks
fill 317 70 223 318 71 223 minecraft:blackstone
fill 319 70 181 324 71 181 minecraft:blackstone
setblock 319 70 183 minecraft:polished_blackstone
setblock 320 70 182 minecraft:polished_blackstone
setblock 320 70 183 minecraft:red_nether_bricks
fill 321 70 182 321 73 182 minecraft:red_nether_bricks
setblock 321 70 186 minecraft:polished_blackstone
fill 321 70 187 321 71 189 minecraft:red_nether_bricks
fill 321 70 223 322 71 223 minecraft:blackstone
setblock 322 70 185 minecraft:polished_blackstone
fill 322 70 186 323 72 186 minecraft:red_nether_bricks
fill 322 70 188 322 70 189 minecraft:red_nether_bricks
setblock 322 70 190 minecraft:polished_blackstone
fill 322 70 191 322 72 192 minecraft:red_nether_bricks
setblock 323 70 184 minecraft:polished_blackstone
fill 323 70 185 323 73 185 minecraft:red_nether_bricks
setblock 323 70 189 minecraft:polished_blackstone
fill 323 70 190 323 73 190 minecraft:red_nether_bricks
setblock 323 70 194 minecraft:polished_blackstone
fill 323 70 195 323 73 195 minecraft:red_nether_bricks
setblock 323 70 205 minecraft:red_nether_bricks
setblock 323 70 209 minecraft:polished_blackstone
fill 323 70 210 323 72 211 minecraft:red_nether_bricks
setblock 323 70 223 minecraft:red_nether_bricks
fill 324 70 186 324 71 186 minecraft:blackstone
setblock 324 70 188 minecraft:red_nether_bricks
fill 324 70 189 324 71 190 minecraft:blackstone
setblock 324 70 191 minecraft:red_nether_bricks
fill 324 70 192 324 71 194 minecraft:blackstone
fill 324 70 200 324 71 200 minecraft:blackstone
fill 324 70 204 324 71 205 minecraft:blackstone
setblock 324 70 206 minecraft:red_nether_bricks
fill 324 70 207 324 71 212 minecraft:blackstone
setblock 324 70 213 minecraft:red_nether_bricks
fill 324 70 214 324 71 221 minecraft:blackstone
fill 324 70 223 324 71 223 minecraft:blackstone
fill 282 71 206 282 74 206 minecraft:blackstone
setblock 282 71 208 minecraft:blackstone
setblock 283 71 182 minecraft:red_nether_bricks
setblock 283 71 183 minecraft:polished_blackstone
fill 283 71 184 283 74 184 minecraft:red_nether_bricks
setblock 283 71 188 minecraft:polished_blackstone
fill 283 71 189 283 74 189 minecraft:red_nether_bricks
setblock 283 71 193 minecraft:polished_blackstone
setblock 283 71 208 minecraft:polished_blackstone
fill 283 71 209 283 74 209 minecraft:red_nether_bricks
setblock 283 71 213 minecraft:polished_blackstone
fill 283 71 214 284 73 214 minecraft:red_nether_bricks
fill 283 71 216 283 71 217 minecraft:red_nether_bricks
setblock 283 71 218 minecraft:polished_blackstone
fill 283 71 219 283 73 220 minecraft:red_nether_bricks
setblock 284 71 182 minecraft:polished_blackstone
fill 284 71 183 287 71 183 minecraft:red_nether_bricks
setblock 284 71 186 minecraft:red_nether_bricks
setblock 284 71 187 minecraft:polished_blackstone
fill 284 71 188 284 74 188 minecraft:red_nether_bricks
fill 284 71 208 284 74 208 minecraft:red_nether_bricks
setblock 284 71 211 minecraft:red_nether_bricks
setblock 284 71 212 minecraft:polished_blackstone
fill 284 71 213 284 74 213 minecraft:red_nether_bricks
fill 284 71 215 284 72 215 minecraft:red_nether_bricks
setblock 284 71 222 minecraft:polished_blackstone
fill 285 71 182 288 71 182 minecraft:red_nether_bricks
setblock 285 71 186 minecraft:polished_blackstone
fill 285 71 187 285 73 187 minecraft:red_nether_bricks
fill 285 71 189 285 72 189 minecraft:red_nether_bricks
setblock 285 71 211 minecraft:polished_blackstone
setblock 285 71 221 minecraft:polished_blackstone
fill 285 71 222 288 71 222 minecraft:red_nether_bricks
fill 286 71 221 289 71 221 minecraft:red_nether_bricks
setblock 287 71 184 minecraft:polished_blackstone
setblock 288 71 183 minecraft:polished_blackstone
fill 288 71 184 288 73 184 minecraft:red_nether_bricks
fill 288 71 220 288 73 220 minecraft:red_nether_bricks
setblock 289 71 181 minecraft:blackstone
setblock 289 71 182 minecraft:polished_blackstone
fill 289 71 183 289 74 183 minecraft:red_nether_bricks
setblock 289 71 222 minecraft:polished_blackstone
fill 290 71 182 290 74 182 minecraft:red_nether_bricks
setblock 290 71 220 minecraft:red_nether_bricks
setblock 290 71 221 minecraft:polished_blackstone
fill 290 71 222 291 73 222 minecraft:red_nether_bricks
setblock 291 71 220 minecraft:polished_blackstone
fill 291 71 221 291 74 221 minecraft:red_nether_bricks
fill 291 71 223 291 72 223 minecraft:blackstone
setblock 292 71 181 minecraft:blackstone
setblock 292 71 184 minecraft:polished_blackstone
setblock 293 71 183 minecraft:polished_blackstone
setblock 293 71 222 minecraft:red_nether_bricks
setblock 294 71 182 minecraft:polished_blackstone
setblock 294 71 183 minecraft:red_nether_bricks
setblock 294 71 222 minecraft:polished_blackstone
setblock 295 71 182 minecraft:red_nether_bricks
fill 295 71 222 295 72 222 minecraft:red_nether_bricks
fill 302 71 181 302 73 181 minecraft:blackstone
fill 305 71 182 308 71 182 minecraft:red_nether_bricks
setblock 307 71 183 minecraft:red_nether_bricks
setblock 308 71 183 minecraft:polished_blackstone
setblock 308 71 222 minecraft:red_nether_bricks
setblock 309 71 182 minecraft:polished_blackstone
fill 309 71 183 309 73 183 minecraft:red_nether_bricks
setblock 309 71 222 minecraft:polished_blackstone
fill 310 71 182 310 74 182 minecraft:red_nether_bricks
setblock 310 71 222 minecraft:red_nether_bricks
setblock 312 71 184 minecraft:polished_blackstone
setblock 313 71 183 minecraft:polished_blackstone
setblock 313 71 184 minecraft:red_nether_bricks
setblock 314 71 182 minecraft:polished_blackstone
fill 314 71 183 314 72 183 minecraft:red_nether_bricks
setblock 314 71 223 minecraft:blackstone
fill 315 71 182 315 73 182 minecraft:red_nether_bricks
fill 317 71 181 318 71 181 minecraft:blackstone
setblock 319 71 182 minecraft:polished_blackstone
fill 320 71 182 320 73 182 minecraft:red_nether_bricks
setblock 321 71 186 minecraft:red_nether_bricks
setblock 321 71 190 minecraft:polished_blackstone
setblock 322 71 184 minecraft:polished_blackstone
fill 322 71 185 322 74 185 minecraft:red_nether_bricks
setblock 322 71 188 minecraft:red_nether_bricks
setblock 322 71 189 minecraft:polished_blackstone
fill 322 71 190 322 74 190 minecraft:red_nether_bricks
setblock 322 71 193 minecraft:red_nether_bricks
setblock 323 71 183 minecraft:polished_blackstone
fill 323 71 184 323 74 184 minecraft:red_nether_bricks
setblock 323 71 188 minecraft:polished_blackstone
fill 323 71 189 323 74 189 minecraft:red_nether_bricks
setblock 323 71 192 minecraft:red_nether_bricks
setblock 323 71 193 minecraft:polished_blackstone
fill 323 71 194 323 74 194 minecraft:red_nether_bricks
fill 323 71 196 323 72 196 minecraft:red_nether_bricks
setblock 323 71 207 minecraft:red_nether_bricks
setblock 323 71 208 minecraft:polished_blackstone
fill 323 71 209 323 74 209 minecraft:red_nether_bricks
setblock 323 71 212 minecraft:red_nether_bricks
setblock 323 71 223 minecraft:blackstone
fill 324 71 187 324 71 188 minecraft:blackstone
setblock 324 71 191 minecraft:blackstone
setblock 324 71 206 minecraft:blackstone
setblock 324 71 213 minecraft:blackstone
fill 282 72 181 282 185 185 minecraft:red_nether_bricks
setblock 282 72 186 minecraft:blackstone
fill 282 72 187 282 189 187 minecraft:red_nether_bricks
setblock 282 72 188 minecraft:blackstone
fill 282 72 189 282 189 189 minecraft:red_nether_bricks
setblock 282 72 190 minecraft:blackstone
fill 282 72 191 282 73 192 minecraft:red_nether_bricks
setblock 282 72 193 minecraft:blackstone
fill 282 72 194 282 185 203 minecraft:red_nether_bricks
setblock 282 72 204 minecraft:blackstone
fill 282 72 205 282 189 205 minecraft:red_nether_bricks
fill 282 72 207 282 72 215 minecraft:red_nether_bricks
fill 282 72 216 282 74 216 minecraft:blackstone
fill 282 72 217 282 72 223 minecraft:red_nether_bricks
fill 283 72 181 301 72 181 minecraft:red_nether_bricks
setblock 283 72 182 minecraft:polished_blackstone
fill 283 72 183 286 72 183 minecraft:red_nether_bricks
setblock 283 72 187 minecraft:polished_blackstone
fill 283 72 188 283 75 188 minecraft:red_nether_bricks
setblock 283 72 191 minecraft:red_nether_bricks
setblock 283 72 192 minecraft:polished_blackstone
fill 283 72 193 283 74 194 minecraft:red_nether_bricks
setblock 283 72 207 minecraft:polished_blackstone
fill 283 72 208 283 75 208 minecraft:red_nether_bricks
setblock 283 72 211 minecraft:red_nether_bricks
setblock 283 72 212 minecraft:polished_blackstone
fill 283 72 213 283 75 213 minecraft:red_nether_bricks
setblock 283 72 216 minecraft:red_nether_bricks
setblock 283 72 217 minecraft:polished_blackstone
fill 283 72 218 283 75 218 minecraft:red_nether_bricks
setblock 283 72 221 minecraft:red_nether_bricks
setblock 283 72 222 minecraft:polished_blackstone
fill 283 72 223 290 73 223 minecraft:red_nether_bricks
fill 284 72 182 287 72 182 minecraft:red_nether_bricks
setblock 284 72 186 minecraft:polished_blackstone
fill 284 72 187 284 75 187 minecraft:red_nether_bricks
setblock 284 72 191 minecraft:polished_blackstone
fill 284 72 192 284 75 192 minecraft:red_nether_bricks
setblock 284 72 211 minecraft:polished_blackstone
fill 284 72 212 285 74 212 minecraft:red_nether_bricks
setblock 284 72 216 minecraft:polished_blackstone
fill 284 72 217 284 75 217 minecraft:red_nether_bricks
fill 284 72 222 287 72 222 minecraft:red_nether_bricks
setblock 285 72 185 minecraft:polished_blackstone
fill 285 72 186 285 73 186 minecraft:red_nether_bricks
setblock 285 72 190 minecraft:polished_blackstone
setblock 285 72 210 minecraft:polished_blackstone
fill 285 72 211 285 75 211 minecraft:red_nether_bricks
fill 285 72 213 285 72 214 minecraft:red_nether_bricks
fill 285 72 221 288 72 221 minecraft:red_nether_bricks
setblock 286 72 184 minecraft:polished_blackstone
setblock 287 72 183 minecraft:polished_blackstone
fill 287 72 184 287 73 184 minecraft:red_nether_bricks
setblock 288 72 182 minecraft:polished_blackstone
fill 288 72 183 288 74 183 minecraft:red_nether_bricks
setblock 288 72 222 minecraft:polished_blackstone
fill 289 72 182 289 75 182 minecraft:red_nether_bricks
setblock 289 72 221 minecraft:polished_blackstone
fill 289 72 222 289 75 222 minecraft:red_nether_bricks
setblock 290 72 220 minecraft:polished_blackstone
fill 290 72 221 290 75 221 minecraft:red_nether_bricks
setblock 292 72 183 minecraft:polished_blackstone
fill 292 72 223 295 187 223 minecraft:red_nether_bricks
setblock 293 72 182 minecraft:polished_blackstone
setblock 293 72 222 minecraft:polished_blackstone
setblock 294 72 182 minecraft:red_nether_bricks
fill 294 72 222 294 73 222 minecraft:red_nether_bricks
setblock 296 72 223 minecraft:blackstone
fill 297 72 223 318 72 223 minecraft:red_nether_bricks
fill 303 72 181 308 186 181 minecraft:red_nether_bricks
fill 306 72 182 307 72 182 minecraft:red_nether_bricks
setblock 308 72 182 minecraft:polished_blackstone
fill 308 72 183 308 73 183 minecraft:red_nether_bricks
setblock 309 72 181 minecraft:blackstone
fill 309 72 182 309 75 182 minecraft:red_nether_bricks
setblock 309 72 222 minecraft:red_nether_bricks
fill 310 72 181 315 73 181 minecraft:red_nether_bricks
setblock 311 72 184 minecraft:polished_blackstone
setblock 312 72 183 minecraft:polished_blackstone
setblock 312 72 184 minecraft:red_nether_bricks
setblock 313 72 182 minecraft:polished_blackstone
setblock 313 72 183 minecraft:red_nether_bricks
fill 313 72 184 313 93 184 minecraft:gilded_blackstone
fill 314 72 182 314 73 182 minecraft:red_nether_bricks
fill 316 72 181 317 72 181 minecraft:blackstone
fill 318 72 181 324 72 181 minecraft:red_nether_bricks
setblock 318 72 182 minecraft:polished_blackstone
setblock 319 72 182 minecraft:red_nether_bricks
fill 319 72 223 319 73 223 minecraft:blackstone
fill 320 72 223 324 185 223 minecraft:red_nether_bricks
fill 321 72 187 321 72 188 minecraft:red_nether_bricks
setblock 321 72 189 minecraft:polished_blackstone
fill 321 72 190 321 73 190 minecraft:red_nether_bricks
setblock 322 72 183 minecraft:polished_blackstone
fill 322 72 184 322 74 184 minecraft:red_nether_bricks
setblock 322 72 188 minecraft:polished_blackstone
fill 322 72 189 322 75 189 minecraft:red_nether_bricks
setblock 322 72 193 minecraft:polished_blackstone
setblock 323 72 182 minecraft:polished_blackstone
fill 323 72 183 324 75 183 minecraft:red_nether_bricks
setblock 323 72 187 minecraft:polished_blackstone
fill 323 72 188 324 72 188 minecraft:red_nether_bricks
setblock 323 72 192 minecraft:polished_blackstone
fill 323 72 193 324 75 193 minecraft:red_nether_bricks
setblock 323 72 207 minecraft:polished_blackstone
fill 323 72 208 323 73 208 minecraft:red_nether_bricks
setblock 323 72 212 minecraft:polished_blackstone
fill 323 72 213 324 73 214 minecraft:red_nether_bricks
setblock 324 72 182 minecraft:red_nether_bricks
fill 324 72 184 324 187 187 minecraft:red_nether_bricks
fill 324 72 189 324 185 192 minecraft:red_nether_bricks
fill 324 72 194 324 186 202 minecraft:red_nether_bricks
fill 324 72 204 324 72 207 minecraft:red_nether_bricks
setblock 324 72 208 minecraft:blackstone
fill 324 72 209 324 189 212 minecraft:red_nether_bricks
fill 324 72 215 324 186 215 minecraft:red_nether_bricks
setblock 324 72 216 minecraft:blackstone
fill 324 72 217 324 72 221 minecraft:red_nether_bricks
fill 282 73 186 282 189 186 minecraft:red_nether_bricks
fill 282 73 188 282 189 188 minecraft:red_nether_bricks
fill 282 73 190 282 190 190 minecraft:red_nether_bricks
fill 282 73 193 282 187 193 minecraft:red_nether_bricks
fill 282 73 204 282 189 204 minecraft:red_nether_bricks
fill 282 73 207 283 75 207 minecraft:red_nether_bricks
setblock 282 73 208 minecraft:blackstone
fill 282 73 209 282 185 212 minecraft:red_nether_bricks
setblock 282 73 213 minecraft:blackstone
fill 282 73 214 282 73 215 minecraft:red_nether_bricks
fill 282 73 217 283 76 217 minecraft:red_nether_bricks
fill 282 73 218 282 74 218 minecraft:blackstone
fill 282 73 219 282 187 222 minecraft:red_nether_bricks
setblock 282 73 223 minecraft:blackstone
fill 283 73 181 285 73 183 minecraft:red_nether_bricks
setblock 283 73 186 minecraft:polished_blackstone
fill 283 73 187 283 76 187 minecraft:red_nether_bricks
setblock 283 73 191 minecraft:polished_blackstone
fill 283 73 192 283 76 192 minecraft:red_nether_bricks
setblock 283 73 210 minecraft:red_nether_bricks
schedule function dropper:buildpart/42_4 1t
